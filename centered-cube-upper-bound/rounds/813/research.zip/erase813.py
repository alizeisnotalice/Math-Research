#!/usr/bin/env python3
"""Recompute information after one physical coordinate is erased in each label."""
import argparse
from collections import defaultdict
from fractions import Fraction as F
from hashlib import sha256
from itertools import product
import json
from pathlib import Path

from cells813 import actual_arms, log2_bound
from info813 import conditional_rows, information, weighted_bounds
from trade813 import total


def changed(v, axis):
    return tuple(None if i == axis else x for i,x in enumerate(v))


def entropy_given(weights):
    observed = defaultdict(F)
    for (x,y),w in weights.items():
        observed[y] += w
    mass = total(observed.values())
    return weighted_bounds((w/mass,log2_bound(observed[y]/w)) for (x,y),w in weights.items())


def check(stage):
    n=stage["dimension"]
    parents,arms,_=actual_arms(stage,F(1,4),F(0))
    rows,_,_,_,mass=conditional_rows(stage,parents,arms)
    positions={t:tuple(F(x)//F(1,4) for x in p["center"]) for t,p in parents.items()}
    cases=[(-1,-1)]+list(product(range(n),repeat=2))+[("joint","joint")]
    values={}
    for axes in cases:
        scores=[]
        for row, table in rows.items():
            by_label=defaultdict(F)
            for (t,p),w in table.items():
                by_label[positions[t],p]+=w
            # String encodings keep pairs comparable in the upstream witness finder.
            encode=lambda v:tuple("e" if x is None else str(x) for x in v)
            full=information(by_label)["I_bits"]
            projected=defaultdict(F)
            old_to_g=defaultdict(F)
            old_to_p=defaultdict(F)
            for (g,p),w in by_label.items():
                if axes==("joint","joint"):
                    i=max(range(n),key=lambda k:(abs(g[k]-p[k]),-k))
                    j=max(range(n),key=lambda k:(abs(g[k]+p[k]),-k))
                else:
                    i,j=axes
                x,y=changed(g,i),changed(p,j)
                assert sum(a!=b for a,b in zip(x,g))<=1 and sum(a!=b for a,b in zip(y,p))<=1
                projected[encode(x),encode(y)]+=w
                old_to_g[g,x]+=w
                old_to_p[p,y]+=w
            kept=information(projected)["I_bits"]
            loss_g,loss_p=entropy_given(old_to_g),entropy_given(old_to_p)
            assert full[0]<=kept[1]+loss_g[1]+loss_p[1]
            if axes!=("joint","joint"):
                assert kept[0]<=full[1]
            scores.append((total(by_label.values())/mass,kept,loss_g,loss_p))
        name=",".join(map(str,axes))
        values[name]={key:weighted_bounds((entry[0],entry[i]) for entry in scores)
                      for i,key in enumerate(("I","H_G_given_Ghat","H_P_given_Phat"),1)}
    fixed=[v["I"] for k,v in values.items() if k not in ("-1,-1","joint,joint")]
    return dict(n=n,rows=len(rows),conditional_bits=values,
                fixed_min_lower=min(x[0] for x in fixed),fixed_min_upper=min(x[1] for x in fixed),
                fixed_max_lower=max(x[0] for x in fixed),fixed_max_upper=max(x[1] for x in fixed))


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--comb",type=Path,required=True)
    g=p.add_mutually_exclusive_group(required=True)
    g.add_argument("--output",type=Path)
    g.add_argument("--check",type=Path)
    a=p.parse_args()
    raw=a.comb.read_bytes()
    rows=[check(s) for s in json.loads(raw)["stages"]]
    result=dict(input_sha256=sha256(raw).hexdigest(),stages=rows,
                scope="Cross-bin continuous inputs, physical quarter grids. The fixed erasures use one coordinate on each side. The joint rule chooses each erasure by looking at both true labels. Conditional on the entire small arm and central volume bin; no additional large-n gate.")
    blob=(json.dumps(result,indent=2,sort_keys=True,default=str)+"\n").encode()
    if a.output:
        a.output.write_bytes(blob)
    else:
        assert a.check.read_bytes()==blob
    for row in rows:
        print(row["n"],"unmodified",float(row["conditional_bits"]["-1,-1"]["I"][0]),
              "fixed erase min/max",float(row["fixed_min_lower"]),float(row["fixed_max_upper"]),
              "joint edit",float(row["conditional_bits"]["joint,joint"]["I"][0]))


if __name__=="__main__":
    main()
