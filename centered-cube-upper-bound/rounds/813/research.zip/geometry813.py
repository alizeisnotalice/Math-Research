#!/usr/bin/env python3
"""Exact repair of coordinate excess and genuine receiver pairs sharing one source price."""
import argparse
from collections import defaultdict
from fractions import Fraction as F
from functools import lru_cache
from hashlib import sha256
from itertools import combinations, product
import json
from math import comb, factorial, prod
from pathlib import Path

ZERO = F(0)
ONE = F(1)


def total(items):
    return sum(items,ZERO)


def rectangle(parent, field):
    return tuple((F(lo), F(hi)) for lo,hi in parent[field])


def volume(box):
    return prod(max(ZERO,b-a) for a,b in box)


def common(*boxes):
    return tuple((max(x[0] for x in coord),min(x[1] for x in coord)) for coord in zip(*boxes))


@lru_cache(maxsize=None)
def inside_halo(probe, target, excess):
    """Integrate 1{sum distances to target intervals <= excess} on a rectangle."""
    dist = {(0,ZERO):ONE}
    for (a,b),(l,r) in zip(probe,target):
        atoms = ((0,ZERO,max(ZERO,min(b,r)-max(a,l))),)
        terms = list(atoms)
        if a < min(b,l):
            terms += [(1,max(ZERO,l-b),ONE),(1,l-a,-ONE)]
        if b > max(a,r):
            terms += [(1,max(ZERO,a-r),ONE),(1,b-r,-ONE)]
        updated = defaultdict(F)
        for (k,h),v in dist.items():
            for delta,d,w in terms:
                if w and h+d <= excess:
                    updated[k+delta,h+d] += v*w
        dist = updated
    measure = total(w*((excess-h)**k)/factorial(k) for (k,h),w in dist.items())
    assert ZERO <= measure <= volume(probe)
    if excess == 0:
        assert measure == volume(common(probe,target))
    farthest = sum(max(ZERO,l-a,b-r) for (a,b),(l,r) in zip(probe,target))
    if excess >= farthest:
        assert measure == volume(probe)
    return measure/volume(probe)


def analytic_kernel_checks():
    checks = []
    for n in (2,3,4,7,12):
        cube = ((-ONE,ONE),)*n
        for tau in (F(1,32), F(1,4), F(1,2)):
            probe = ((-1-tau,1+tau),)*n
            actual = inside_halo(probe,cube,tau)*volume(probe)
            formula = 2**n*sum(F(comb(n,k),factorial(k))*tau**k for k in range(n+1))
            assert actual == formula
            skinny = ((1+tau/2,1+3*tau/4),) + ((-F(1,4),F(1,4)),)*(n-1)
            assert inside_halo(skinny,cube,tau) == 1
            assert inside_halo(skinny,cube,0) == 0
            checks.append([n,tau,actual])
    return checks


def observations(stage, law):
    """Price z and actual t,u after integrating q,g, with the original full degree."""
    true_mass = {c["mask"]:F(c["mass"]) for c in stage["cells"]}
    labels = {p["id"]:p for p in stage["parents"]}
    rows = defaultdict(lambda:defaultdict(F))
    for root in stage["roots_"+law]:
        t,u,g = (root[k] for k in ("t","u","g"))
        component = F(root["coefficient"])
        checked = F(labels[t]["j"])/F(labels[t]["full_d"])
        for i in (u,g):
            checked *= F(labels[i]["j"])/(F(labels[i]["m"])*F(labels[t]["m"]))
        assert component == checked and total(map(F,root["sectors_00_01_10_11"])) == F(root["root_mass"])
        accum = ZERO
        for z in root["z_masks"]:
            amount = component*true_mass[z]*total(true_mass[q] for q in root["q_masks"])
            rows[z][t,u] += amount
            accum += amount
        assert accum == F(root["root_mass"])
    mother = total(total(edges.values()) for edges in rows.values())
    assert mother == F(stage["benchmarks"][law]["mother"])
    return rows,mother


def stage_check(stage, law, budgets):
    parents = {p["id"]:p for p in stage["parents"]}
    target = {i:rectangle(p,"expanded_box") for i,p in parents.items()}
    owners = {i:rectangle(p,"owner") for i,p in parents.items()}
    raw = {i:rectangle(p,"box") for i,p in parents.items()}
    old = [i for i in parents if parents[i]["role"]=="old"]
    radii = {i:F(p["radius"]) for i,p in parents.items()}
    rows,mother = observations(stage,law)
    def hit(probe,j,tau):
        return inside_halo(probe,target[j],tau*radii[j])
    result = []
    for tau in budgets:
        sums = defaultdict(F)
        gap = ZERO
        for z,edges in rows.items():
            subtotal = total(edges.values())
            posterior = {edge:w/subtotal for edge,w in edges.items()}
            donors = [i for i in old if z & parents[i]["bit"]]
            assert donors
            for (t,u),w in edges.items():
                joint = total(pr*hit(owners[j],t,tau)*hit(owners[k],u,tau) for (j,k),pr in posterior.items())
                swapped = total(pr*hit(owners[k],t,tau)*hit(owners[j],u,tau) for (j,k),pr in posterior.items())
                indep = total(pr*hit(owners[j],t,tau) for (j,k),pr in posterior.items())*total(
                    pr*hit(owners[k],u,tau) for (j,k),pr in posterior.items())
                cross_parent = total(pr*hit(owners[j],t,tau)*hit(owners[k],u,tau)
                                     for (j,k),pr in posterior.items() if j != t)
                sums["same_source_joint"] += w*joint
                sums["cross_parent_joint"] += w*cross_parent
                sums["swapped_roles"] += w*swapped
                sums["independent_marginals"] += w*indep
                gap = max(gap,abs(joint-indep))
                sums["supplier_left"] += w*total(hit(raw[i],u,tau) for i in donors)/len(donors)
                sums["supplier_joint_split"] += w*total(hit(raw[i],t,tau)*hit(raw[i],u,tau) for i in donors)/len(donors)
        result.append(dict(relative_excess=tau, rates={k:v/mother for k,v in sorted(sums.items())},
                           largest_conditional_dependence_gap=gap))
    for prev,cur in zip(result,result[1:]):
        assert all(cur["rates"][k]>=v for k,v in prev["rates"].items())
    return dict(n=stage["dimension"],law=law,source_masks=len(rows),mother=mother,results=result)


def mixed_owners():
    """Two true middles with the same size, two different small bins and independent Lebesgue owners."""
    props = ((F(3,2),F(2)),(-F(3,2),F(2)),(F(7,8),ONE),(-F(5,8),F(3,4)))
    def cube(i,scale=ONE):
        c,r=props[i]
        s=scale*r
        return ((c-s,c+s),(-s,s))
    m=[volume(cube(i)) for i in range(4)]
    j=[volume(cube(i,F(1,64))) for i in range(4)]
    for a,b in combinations(range(4),2):
        assert volume(common(cube(a,F(1,64)),cube(b,F(1,64)))) == 0
    d={t:total(j[k]*volume(common(cube(t),cube(k)))/(m[t]*m[k])
               for k in range(4) if k!=t) for t in range(2)}
    shared = common(*(cube(i) for i in range(4)))
    assert volume(shared)>0
    w={}
    for t in range(2):
        for u,g in ((2,3),(3,2)):
            w[t,u]=volume(shared)*j[t]*j[u]*j[g]*volume(common(cube(t),cube(g)))/(d[t]*m[t]**2*m[u]*m[g])
    mass=total(w.values())
    pi={e:v/mass for e,v in w.items()}
    left={t:total(v for (a,_),v in pi.items() if a==t) for t in range(2)}
    right={u:total(v for (_,a),v in pi.items() if a==u) for u in (2,3)}
    for A in (range(2),(2,3)):
        for i,k in product(A,repeat=2):
            assert inside_halo(cube(k,F(1,64)),cube(i,ONE+F(1,64)),ZERO)==(i==k)
    joint=total(v*v for v in pi.values())
    independent=total(v*left[t]*right[u] for (t,u),v in pi.items())
    assert all(v>0 for v in w.values()) and joint!=independent
    return dict(family=props,m=m,j=j,full_degree=d,source_region=shared,mother=mass,
                labels=[[t,u,v] for (t,u),v in pi.items()],
                joint_hit=joint,independent_hit=independent,
                max_row_difference=max(abs(v-left[t]*right[u]) for (t,u),v in pi.items()),
                scope="Uniform Lebesgue source on [-8,8]^2. Compare full roots conditional on the same genuine shared z in the four-parent intersection. Only opposite old volume bins admitted, actual owners disjoint. No large-dimension gates.")

def scalar_checks():
    import flint
    from flint import arb, ctx
    results = []
    for k in (16,64,128,256,512,1024):
        def calc(prec):
            ctx.prec = prec
            n = arb(2)**k
            ell = (n+2).log()
            eps = arb(1)/4
            kap = eps/64
            a = kap**2/64
            gamma = (kap*ell)**2/n
            # 2*ceil(16ell)*a*ell/n is an upper bound for the total relative overflow.
            geometric = 2*(16*ell+1)*a*ell/(n*gamma)
            beta = (8*kap- eps + arb(1)/32)*ell
            return geometric,beta.exp(),gamma
        first = calc(192)
        second = calc(384)
        assert all(x.overlaps(y) for x,y in zip(first,second))
        assert 0 < second[0] < 1 and 0 < second[1] < 1
        results.append([k,*[x.str(21) for x in second]])
    return dict(flint=flint.__version__,bits=[192,384],rows=results)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--comb",type=Path,required=True)
    modes=parser.add_mutually_exclusive_group(required=True)
    modes.add_argument("--output",type=Path)
    modes.add_argument("--check",type=Path)
    args=parser.parse_args()
    raw=args.comb.read_bytes()
    budgets = (ZERO,F(1,64),F(1,16),F(1,4))
    records=[stage_check(stage,law,budgets) for stage in json.loads(raw)["stages"] for law in ("all","cross")]
    result=dict(input_sha256=sha256(raw).hexdigest(),sphere_formulas=analytic_kernel_checks(),
                arb=scalar_checks(),tests=records,mixed=mixed_owners(),
                scope="Conditional on the exact first source member mask, resample a whole real path including middle and old labels. Target probes are actual uniform owners. Diagnostic relative excess in addition to the original isotropic expansion. The far jump and large-n gates are not assumed by these examples.")
    data=(json.dumps(result,default=str,indent=2,sort_keys=True)+"\n").encode()
    if args.output:
        args.output.write_bytes(data)
    else:
        assert data==args.check.read_bytes()
    for r in records:
        for x in (r["results"][0],r["results"][-1]):
            print(r["n"],r["law"],x["relative_excess"],
                  *(round(float(x["rates"][k]),10) for k in ("same_source_joint","cross_parent_joint","independent_marginals","supplier_joint_split")),
                  round(float(x["largest_conditional_dependence_gap"]),10))


if __name__=="__main__":
    main()
