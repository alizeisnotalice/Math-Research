#!/usr/bin/env python3
"""Replay the true receiver, two-source and coordinate information certificates."""
import argparse
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys
from zipfile import ZipFile


def verify(data, expected, label):
    actual=sha256(data).hexdigest()
    if actual!=expected:
        raise ValueError(f"SHA-256 mismatch for {label}: {actual} != {expected}")
    return data


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--rounds",type=Path,required=True,help="project rounds directory with 811 and 812")
    parser.add_argument("--work",type=Path,required=True,help="fresh output directory")
    args=parser.parse_args()
    here=Path(__file__).resolve().parent
    manifest=json.loads((here/"MANIFEST.json").read_bytes())
    files={k:verify((here/k).read_bytes(),v,k) for k,v in manifest["members"].items()}
    for number,rec in manifest["previous"].items():
        archive=args.rounds/number/"research.zip"
        verify(archive.read_bytes(),rec["archive_sha256"],f"round {number}")
        with ZipFile(archive) as zipfile:
            for name,digest in rec["programs"].items():
                files[name]=verify(zipfile.read(name),digest,name)
    out=args.work.resolve()
    out.mkdir(parents=True,exist_ok=False)
    for name,data in files.items():
        if name.endswith(".py") or name in ("trade813.json","edge813.json"):
            (out/name).write_bytes(data)
    def run(stem,*args):
        subprocess.run([sys.executable,"-B",stem+".py",*args],cwd=out,check=True)
    run("comb811","--output","comb811.json")
    verify((out/"comb811.json").read_bytes(),manifest["input_sha256"],"rebuilt comb811.json")
    for stem in manifest["order"]:
        name=stem+".json"
        mode="--check" if stem in ("trade813","edge813") else "--output"
        run(stem,"--comb","comb811.json",mode,name)
        verify((out/name).read_bytes(),manifest["results"][name],name)
        print("SHA256",name,manifest["results"][name],flush=True)
    print("Verified two frozen archives, three prior programs, one rebuilt input and six round 813 reports.")


if __name__=="__main__":
    main()
