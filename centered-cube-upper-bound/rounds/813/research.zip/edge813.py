#!/usr/bin/env python3
"""Exact original two-price edge clearing and marked cross-middle square."""
import argparse
from collections import defaultdict
from fractions import Fraction as F
from hashlib import sha256
from itertools import combinations, product
import json
from math import lcm
from pathlib import Path
import platform
import sys

from trade813 import box, comb_mass, intersection, source_law, total, volume

ZERO=F(0)
D_GATES=(F(1),F(4,3))


def original_cells(stage,parents,supply,lam,joint):
    memberships={c["mask"]:F(c["mass"]) for c in stage["cells"]}
    bits={i:parents[i]["bit"] for i in supply}
    incidence={s:[i for i in supply if s&bits[i]] for s in memberships}
    raw,marked=defaultdict(F),defaultdict(F)
    all_mass=ZERO
    for e in stage["roots_cross"]:
        t,u,g=(e[k] for k in ("t","u","g"))
        T,U,G=(parents[k] for k in (t,u,g))
        p=F(T["j"])*F(U["j"])*F(G["j"])/(F(T["full_d"])*F(T["m"])**2*F(U["m"])*F(G["m"]))
        assert p==F(e["coefficient"]) and U["volume_bin"]!=G["volume_bin"]
        mass=ZERO
        for z,q in product(e["z_masks"],e["q_masks"]):
            d=p*memberships[z]*memberships[q]
            mass+=d
            L,R=incidence[z],incidence[q]
            assert u in L and g in R
            Fz,Fq=lam*len(L),lam*len(R)
            for i,j in product(L,R):
                raw[t,i,j]+=d
                marked[t,i,j]+=d*lam**2/(Fz*Fq)
        assert mass==F(e["root_mass"])
        all_mass+=mass
    check=defaultdict(F)
    for ((t,u,i),(s,g,j)),value in joint.items():
        assert t==s
        check[t,i,j]+=value
    assert dict(check)==dict(marked)
    assert all_mass==total(marked.values())==F(stage["benchmarks"]["cross"]["mother"])
    return raw,marked,all_mass


def explicit_plans(stage,parents,supply,lam,a):
    masses={c["mask"]:F(c["mass"]) for c in stage["cells"]}
    bits={i:parents[i]["bit"] for i in supply}
    diag={(i,i):v for i,v in a.items()}
    mu,leb,delta={}, {}, {}
    intersections=[]
    for i,j in product(supply,repeat=2):
        C=intersection(box(parents[i],"box"),box(parents[j],"box"))
        cover=bits[i]|bits[j]
        M=total(w for s,w in masses.items() if s&cover==cover)
        assert M==comb_mass(C,stage["density"])
        L=volume(C)
        mu[i,j]=lam**2*M
        leb[i,j]=lam**2*L
        delta[i,j]=abs(mu[i,j]-leb[i,j])/2
        if M or L:
            intersections.append(dict(i=i,j=j,mu=M,Lebesgue=L))
    return {"diagonal":diag,"true_mu_intersection":mu,"Lebesgue_intersection":leb,
            "half_absolute_difference":delta},intersections


def projection(table,parents,supply,d):
    values=defaultdict(F)
    by_t={t:defaultdict(F) for t,p in parents.items() if p["role"]=="middle"}
    for (t,i,j),w in table.items():
        m=max(F(parents[i]["m"]),F(parents[j]["m"]))
        if F(parents[t]["m"])>=d*m:
            values[i,j]+=w
            by_t[t][i,j]+=w
    assert all(values[i,j]==values[j,i] for i,j in product(supply,repeat=2))
    return values,by_t


def linear_value(plan,a,pay):
    out=defaultdict(F)
    inp=defaultdict(F)
    for (i,j),v in plan.items():
        assert i in a and j in a and v>=0
        out[i]+=v
        inp[j]+=v
    assert all(out[i]<=a[i] and inp[i]<=a[i] for i in a)
    return total(w*pay[i,j] for (i,j),w in plan.items())


def optimum(solver,a,pay,saved):
    labels=tuple(a)
    n=len(labels)
    pairs=tuple(product(labels,repeat=2))
    sink=2*n+1
    mass_den=lcm(*(v.denominator for v in a.values()))
    cost_den=lcm(*(v.denominator for v in pay.values()))
    big=1+total(a.values())
    arcs=[(0,k+1,int(a[i]*mass_den),0) for k,i in enumerate(labels)]
    for (r,i),(s,j) in product(enumerate(labels),repeat=2):
        arcs.append((r+1,n+s+1,int(big*mass_den),-int(pay[i,j]*cost_den)))
    arcs.extend((k+n+1,sink,int(a[i]*mass_den),0) for k,i in enumerate(labels))
    middle=list(range(n,n+n*n))
    cert=solver.solve(arcs,sink) if saved is None else saved["certificate"]
    value,_,flow=solver.exact_optimum(arcs,middle,sink,cert)
    plan={ij:F(flow[k],mass_den) for ij,k in zip(pairs,middle) if flow[k]}
    val=F(value,mass_den*cost_den)
    assert linear_value(plan,a,pay)==val
    return val,plan,dict(certificate=cert,labels=labels,mass_denominator=mass_den,cost_denominator=cost_den)


def marked_square(P,by_t,denom,M):
    value=total(v*v/denom[i,j] for (i,j),v in P.items())
    self_terms={t:total(v*v/denom[i,j] for (i,j),v in part.items()) for t,part in by_t.items()}
    cross={}
    edge_cross=defaultdict(F)
    for (t,x),(s,y) in combinations(by_t.items(),2):
        for (i,j),v in x.items():
            added=2*v*y.get((i,j),ZERO)/denom[i,j]
            if added:
                cross[t,s]=cross.get((t,s),ZERO)+added
                edge_cross[i,j]+=added
    C=total(cross.values())
    assert C==total(edge_cross.values()) and value==total(self_terms.values())+C
    assert all(v==P[j,i] and v==total(part.get((i,j),ZERO) for part in by_t.values()) for (i,j),v in P.items())
    return dict(raw_quadratic=value,normalized_by_original_Gamma_squared=value/M**2,
                summed_individual_middle_squares=total(self_terms.values()),all_cross_middle_terms=C,
                cross_middle_fraction_of_exact_quadratic=(C/value if value else ZERO),
                exact_individual_middle_squares=self_terms,
                cross_by_shared_middles=[dict(middles=[t,s],raw=v,share=v/value) for (t,s),v in sorted(cross.items())],
                cross_by_supplier_edge=[dict(edge=[i,j],raw=v,share=v/value,
                  positive_middles=[t for t,weights in by_t.items() if weights.get((i,j),ZERO)])
                  for (i,j),v in sorted(edge_cross.items(),key=lambda item:(-item[1],item[0]))])


def example(stage,solver,past):
    parents,supply,lam,a,_,_,joint,_=source_law(stage)
    I,P,M=original_cells(stage,parents,supply,lam,joint)
    explicit,contacts=explicit_plans(stage,parents,supply,lam,a)
    minimum={(i,j):min(F(parents[i]["m"]),F(parents[j]["m"])) for i,j in product(supply,repeat=2)}
    fees=defaultdict(F)
    previous={} if past is None else {d["d"]:d for d in past["gates"]}
    rows=[]
    for d in D_GATES:
        G,by_t=projection(I,parents,supply,d)
        Pgate,mark_t=projection(P,parents,supply,d)
        assert all(Pgate.get(ij,ZERO)<=G.get(ij,ZERO) for ij in minimum)
        score={ij:G.get(ij,ZERO)/m for ij,m in minimum.items()}
        alternatives={}
        for name,plan in explicit.items():
            val=linear_value(plan,a,score)
            alternatives[name]=dict(raw_original_fee=val,original_Gamma_normalized_fee=val/M,
                                    total_edge_mass=total(plan.values()),plan=[[*k,w] for k,w in sorted(plan.items()) if w])
        save=previous.get(str(d),{}).get("optimal")
        opt,plan,cert=optimum(solver,a,score,save)
        assert opt>=max(x["raw_original_fee"] for x in alternatives.values())
        alternatives["original_Gamma_optimum"]=dict(raw_original_fee=opt,original_Gamma_normalized_fee=opt/M,
                                   total_edge_mass=total(plan.values()),plan=[[*k,w] for k,w in sorted(plan.items())])
        quad=marked_square(Pgate,mark_t,{ij:lam**2*m for ij,m in minimum.items()},M)
        assert total(Pgate.values())<=M
        rows.append(dict(d=d,original_Gamma=M,marked_gate_mass=total(Pgate.values()),marked_gate_rate=total(Pgate.values())/M,
                         plans=alternatives,optimal=cert,quadratic=quad,
                         edge_values=[dict(i=i,j=j,raw_indicator_mass=G.get((i,j),ZERO),P=Pgate.get((i,j),ZERO),
                            by_middle_indicator={t:w.get((i,j),ZERO) for t,w in by_t.items()},
                            by_middle_P={t:w.get((i,j),ZERO) for t,w in mark_t.items()})
                            for i,j in minimum]))
    return dict(dimension=stage["dimension"],law="cross",lambda_i=lam,shared_row_and_column_caps=a,
                calibrating_auxiliary_intersections=contacts,gates=rows)


def certificate(path,solver_dir,saved):
    sys.path.insert(0,str(solver_dir.resolve()))
    import coupled812 as solver

    stages=json.loads(path.read_text())["stages"]
    old={} if saved is None else {s["dimension"]:s for s in saved["stages"]}
    files={"comb811.json":path,"coupled812.py":solver_dir/"coupled812.py","pairs812.py":solver_dir/"pairs812.py",
           "trade813.py":Path(__file__).with_name("trade813.py")}
    return dict(runtime={"python":platform.python_version(),"architecture":platform.machine()},
                frozen_input_sha256={n:sha256(p.read_bytes()).hexdigest() for n,p in files.items()},
                scope="No distance gate. Both slots are genuine prices from the original cross-bin continuous comb law. The strict sensitivity gate compares actual central and auxiliary source volumes. Auxiliary cubes and weights are the calibrated old parents and reciprocal maximum overlap.",
                normalization="The fee uses the original pair weight with unnormalized membership indicators divided by min(m_i,m_j); the quadratic instead uses true source-choice probability zeta=lambda_i/F(z). Both use the original full degree. Fees and squares are recorded in physical units as well as normalized by Gamma or Gamma squared.",
                certificate="The exact ordinary transportation algorithm uses integer scaling only. Saved feasible flows and exact residual node potentials give matching primal and dual values. Cross-middle quadratic expansion is independently summed by middle pairs and by common supplier edges.",
                reproduce="python -B edge813.py --comb <verified-final/comb811.json> --check edge813.json",
                stages=[example(stage,solver,old.get(stage["dimension"])) for stage in stages])


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--comb",required=True,type=Path)
    p.add_argument("--solver-dir",type=Path)
    g=p.add_mutually_exclusive_group(required=True)
    g.add_argument("--output",type=Path)
    g.add_argument("--check",type=Path)
    args=p.parse_args()
    old=json.loads(args.check.read_text()) if args.check else None
    data=certificate(args.comb,args.solver_dir or args.comb.parent,old)
    text=(json.dumps(data,default=str,sort_keys=True,indent=2)+"\n").encode()
    if args.output:
        args.output.write_bytes(text)
    else:
        assert args.check.read_bytes()==text
    for s in data["stages"]:
        for g in s["gates"]:
            print(s["dimension"],g["d"],"gate",f"{float(g['marked_gate_rate']):.9g}",
                  "payments",[(k,f"{float(v['original_Gamma_normalized_fee']):.9g}") for k,v in g["plans"].items()],
                  "raw quad",f"{float(g['quadratic']['raw_quadratic']):.9g}",
                  "cross",f"{float(g['quadratic']['cross_middle_fraction_of_exact_quadratic']):.9g}")
    if args.check:
        print("byte-identical exact primal/dual replay")


if __name__=="__main__":
    main()
