#!/usr/bin/env python3
"""Conditional center/price information from the genuine cross-bin comb roots."""
import argparse
from collections import defaultdict
from fractions import Fraction as F
from hashlib import sha256
import json
from pathlib import Path
import platform

from cells813 import GRIDS, actual_arms, log2_bound
from trade813 import total

ZERO=F(0)
ONE=F(1)


def signed_log(x):
    if x>=1:
        return log2_bound(x)
    a,b=log2_bound(1/x)
    return -b,-a


def weighted_bounds(items):
    lo,hi=ZERO,ZERO
    for w,(a,b) in items:
        assert w>=0 and a<=b
        lo+=w*a
        hi+=w*b
    return lo,hi


def density_by_membership(stage,parents,arms):
    """Profiles relative to mu(dz) times the normalized true owner law of u."""
    pair_bins={}
    old_live=defaultdict(list)
    for t,p in parents.items():
        if p["role"]!="middle":
            continue
        labels=stage["degrees"][t]["old_terms"]
        for u in labels:
            gset=[g for g in labels if parents[g]["volume_bin"]!=parents[u]["volume_bin"]]
            if gset:
                old_live[u,p["volume_bin"]].append(t)
                pair_bins[t,u]=gset
    single={}
    for (t,u),choices in pair_bins.items():
        T,U=parents[t],parents[u]
        coef=F(T["j"])*F(U["j"])/(F(T["full_d"])*F(T["m"])**2*F(U["m"]))
        density=defaultdict(F)
        for g in choices:
            G=parents[g]
            for P,w in arms[t,g].items():
                density[t,P]+=coef*F(G["j"])/F(G["m"])*w
        single[t,u]=dict(density)
    return old_live,single


def conditional_rows(stage,parents,arms):
    z_mass={s["mask"]:F(s["mass"]) for s in stage["cells"]}
    middle_options,profiles=density_by_membership(stage,parents,arms)
    true_fine=defaultdict(lambda:defaultdict(F))
    preliminary=defaultdict(F)
    for e in stage["roots_cross"]:
        t,u,g=(e[k] for k in ("t","u","g"))
        T,U,G=(parents[k] for k in (t,u,g))
        coeff=F(T["j"])*F(U["j"])*F(G["j"])/(F(T["full_d"])*F(T["m"])**2*F(U["m"])*F(G["m"]))
        assert coeff==F(e["coefficient"])
        mother=coeff*total(z_mass[x] for x in e["z_masks"])*total(arms[t,g].values())
        assert mother==F(e["root_mass"])
        # The unscreened real owner halves on both arms are independent uniforms.
        halves=list(map(F,e["sectors_00_01_10_11"]))
        assert len(halves)==4 and all(w==mother/4 for w in halves)
        d=T["volume_bin"]
        for fine in e["z_masks"]:
            assert fine&T["bit"] and fine&U["bit"]
            for P,w in arms[t,g].items():
                true_fine[u,d,fine][t,P]+=coeff*w
        preliminary[t,u]+=mother
    mu_coarse=defaultdict(F)
    fine_count=defaultdict(int)
    by_fine=defaultdict(lambda:defaultdict(F))
    expected={}
    options={}
    for (u,d),middles in middle_options.items():
        subset=sum(parents[t]["bit"] for t in middles)
        for fine,m in z_mass.items():
            h=fine&subset
            if not h or not fine&parents[u]["bit"]:
                continue
            key=u,d,h
            if key not in expected:
                eligible=[t for t in middles if h&parents[t]["bit"]]
                expected[key]={i:w for t in eligible for i,w in profiles[t,u].items()}
                options[key]=tuple(eligible)
            # Equality here certifies the absence of conditioning on other parent bits.
            assert expected[key]==true_fine[u,d,fine]
            mu_coarse[key]+=m
            fine_count[key]+=1
            for i,w in true_fine[u,d,fine].items():
                by_fine[key][i]+=m*w
    assert sum(fine_count.values())==len(true_fine)
    rows={key:{e:w*mu_coarse[key] for e,w in density.items()} for key,density in expected.items()}
    assert rows==by_fine
    M=total(total(d.values()) for d in rows.values())
    assert M==total(preliminary.values())==F(stage["benchmarks"]["cross"]["mother"])
    return rows,mu_coarse,fine_count,options,M


def information(P):
    W=total(P.values())
    Gmass,Pmass=defaultdict(F),defaultdict(F)
    for (g,p),w in P.items():
        Gmass[g]+=w
        Pmass[p]+=w
    full_product={(g,p):x*y/W**2 for g,x in Gmass.items() for p,y in Pmass.items()}
    joint={k:x/W for k,x in P.items()}
    assert total(full_product.values())==total(joint.values())==ONE
    hit=total(full_product[key] for key in joint)
    assert 0<hit<=1
    direct=weighted_bounds((w,signed_log(w/full_product[key])) for key,w in joint.items())
    support_lower=log2_bound(1/hit)
    remainder=weighted_bounds((w,signed_log(w*hit/full_product[key])) for key,w in joint.items())
    leftH=weighted_bounds((w/W,log2_bound(W/w)) for w in Pmass.values())
    rightH=weighted_bounds((w/W,log2_bound(Gmass[g]/w)) for (g,p),w in P.items())
    via_entropy=(leftH[0]-rightH[1],leftH[1]-rightH[0])
    via_support=(support_lower[0]+remainder[0],support_lower[1]+remainder[1])
    lo=max(ZERO,direct[0],via_entropy[0],via_support[0])
    hi=min(direct[1],via_entropy[1],via_support[1])
    assert lo<=hi
    missing=max(((w,key) for key,w in full_product.items() if key not in joint),default=None)
    return dict(mass=W,center_cells=len(Gmass),opposite_price_cells=len(Pmass),genuine_positive_pairs=len(P),
                genuine_compatible_support_probability=total(joint.values()),shuffled_independent_compatible_probability=hit,
                I_bits=(lo,hi),I_direct_KL_bits=direct,I_entropy_difference_bits=via_entropy,
                support_LB_bits=support_lower,I_minus_support_LB_bits=(max(ZERO,remainder[0]),remainder[1]),
                absent_joint_pair_example=None if missing is None else
                    dict(G=missing[1][0],P=missing[1][1],true_probability=ZERO,shuffled_probability=missing[0]))


def observe(stage,step,origin):
    parents,arms,_=actual_arms(stage,step,origin)
    rows,z_mass,n_fine,options,Gamma=conditional_rows(stage,parents,arms)
    centercell={t:tuple((F(x)-origin)//step for x in p["center"])
                for t,p in parents.items() if p["role"]=="middle"}
    measures=[]
    table={}
    for key,weights in sorted(rows.items()):
        u,d,selector=key
        matrix=defaultdict(F)
        for (t,P),w in weights.items():
            matrix[centercell[t],P]+=w
        result=information(matrix)
        table[key]=matrix
        assert set(options[key])=={t for t,P in weights}
        measures.append(dict(u=u,d=d,own_price_middle_mask=selector,middle_parents=options[key],
                            true_mu_of_conditioning_cell=z_mass[key],fine_masks_merged=n_fine[key],**result))
    W=total(r["mass"] for r in measures)
    assert W==Gamma
    multi=[r for r in measures if len(r["middle_parents"])>1]
    both=[r for r in measures if r["center_cells"]>1]
    pos=[r for r in measures if r["I_bits"][0]>0]
    assert pos and both
    active=total(r["mass"] for r in multi)
    M_I=weighted_bounds((r["mass"]/W,r["I_bits"]) for r in measures)
    M_LB=weighted_bounds((r["mass"]/W,r["support_LB_bits"]) for r in measures)
    M_res=weighted_bounds((r["mass"]/W,r["I_minus_support_LB_bits"]) for r in measures)
    assert M_I[0]<=M_LB[1]+M_res[1] and M_LB[0]+M_res[0]<=M_I[1]
    avg_hit=total(r["mass"]/W*r["shuffled_independent_compatible_probability"] for r in measures)
    hi=max(measures,key=lambda r:r["I_bits"][0])
    ident=(hi["u"],hi["d"],hi["own_price_middle_mask"])
    return dict(dimension=stage["dimension"],law="cross",physical_grid_step=step,physical_grid_origin=origin,
                original_Gamma=Gamma,number_conditioning_cells=len(measures),
                within_each_cell_common_density_verified=True,number_multimiddle_same_bin_rows=len(multi),
                multimiddle_same_bin_raw_mass=active,multimiddle_same_bin_original_mass_fraction=active/W,
                number_rows_with_two_or_more_physical_G=len(both),number_positive_information_rows=len(pos),
                true_joint_compatible_support_probability=ONE,shuffled_independent_compatible_probability=avg_hit,
                I_G_P_given_X_d_bits=M_I,weighted_support_LB_bits=M_LB,
                I_minus_weighted_support_LB_bits=M_res,
                minus_log_of_averaged_shuffled_hit_LB_bits=log2_bound(1/avg_hit),
                I_bits_given_a_multimiddle_row=weighted_bounds((r["mass"]/active,r["I_bits"]) for r in multi),
                middle_center_physical_cells=centercell,all_conditioning_rows=measures,
                max_positive_information_row=hi,
                max_information_row_positive_joint_masses=[(G,P,w) for (G,P),w in sorted(table[ident].items())])


def certificate(path):
    data=json.loads(path.read_text())
    _,step,phase=next(g for g in GRIDS if g[0]=="quarter_aligned")
    base=Path(__file__).resolve().parent
    chosen=[observe(stage,step,phase) for stage in data["stages"]]
    return dict(runtime={"python":platform.python_version(),"architecture":platform.machine()},
                inputs_sha256={"comb811.json":sha256(path.read_bytes()).hexdigest(),
                               "cells813.py":sha256((base/"cells813.py").read_bytes()).hexdigest(),
                               "trade813.py":sha256((base/"trade813.py").read_bytes()).hexdigest()},
                scope="The frozen genuine cross-bin comb price laws with full original degree, actual owner halves and quarter-step physical grid. G is the actual grid location of a middle center; P is the grid location of the true opposite price. No extra long-jump filter is imposed.",
                conditioning="The observation retains old u, its actual price z and actual owner U, plus the absolute middle volume bin d. Profiles are densities relative to mu(dz) times the uniform law of U on its actual owner. Inside each cell, only the membership of z in genuinely eligible middle parents of the same (u,d) is needed. This density is independently reconstructed from every finer original physical membership atom.",
                support_test="Compatibility is positive mass under the actual conditional discrete (G,P) law. Product shuffling uses the exact marginals in that same conditioned row. The logarithm of the inverse product hit is a lower bound on row KL, with a separate residual KL certificate. Overall weights are the original row masses.",
                proof="All physical masses and probability weights are exact rational numbers. Outward rational logarithm intervals certify direct KL, the difference of conditional entropies, and the separate support lower bound.",
                replay="python -B info813.py --comb <verified-final/comb811.json> --check info813.json",
                examples=chosen)


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--comb",required=True,type=Path)
    mode=p.add_mutually_exclusive_group(required=True)
    mode.add_argument("--output",type=Path)
    mode.add_argument("--check",type=Path)
    args=p.parse_args()
    data=certificate(args.comb)
    text=(json.dumps(data,default=str,indent=2,sort_keys=True)+"\n").encode()
    if args.output:
        args.output.write_bytes(text)
    else:
        assert args.check.read_bytes()==text
    for d in data["examples"]:
        fmt=lambda a:f"{float(a):.11g}"
        h=d["max_positive_information_row"]
        print(d["dimension"],d["number_conditioning_cells"],d["number_multimiddle_same_bin_rows"],
              "multimiddle",fmt(d["multimiddle_same_bin_original_mass_fraction"]),
              "I",fmt(d["I_G_P_given_X_d_bits"][0]),"support hit",fmt(d["shuffled_independent_compatible_probability"]),
              "LB",fmt(d["weighted_support_LB_bits"][0]),"residual",fmt(d["I_minus_weighted_support_LB_bits"][0]),
              "max",h["u"],h["d"],h["own_price_middle_mask"],fmt(h["I_bits"][0]),
              "max row hit",fmt(h["shuffled_independent_compatible_probability"]))
    if args.check:
        print("byte-identical rational replay")


if __name__=="__main__":
    main()
