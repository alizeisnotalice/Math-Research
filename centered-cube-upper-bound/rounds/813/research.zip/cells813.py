#!/usr/bin/env python3
"""Exact physical-grid price pair ledgers and rational conditional entropy bounds."""
import argparse
from collections import defaultdict
from fractions import Fraction as F
from functools import lru_cache
from hashlib import sha256
from itertools import product
import json
from math import prod
from pathlib import Path
import platform

from trade813 import box, comb_mass, intersection, total

ZERO=F(0)
GRIDS=(("half_aligned",F(1,2),ZERO),("quarter_aligned",F(1,4),ZERO),
       ("quarter_shifted",F(1,4),F(1,8)))
FIXED=1<<96
LOG_TERMS=32


def ceil_ratio(a,b):
    return -(-a//b)


def floor_ceil_units(q):
    a=q.numerator*FIXED
    return a//q.denominator,ceil_ratio(a,q.denominator)


def unit_log(y):
    """Fixed-point outward ln(y) enclosure, valid for 1 <= y <= 2."""
    assert 1<=y<=2
    q=(y-1)/(y+1)
    l,h=floor_ceil_units(q)
    l2,h2=l*l//FIXED,ceil_ratio(h*h,FIXED)
    assert 2*h<FIXED
    lo,hi=0,0
    for k in range(LOG_TERMS):
        lo+=2*l//(2*k+1)
        hi+=ceil_ratio(2*h,2*k+1)
        l=l*l2//FIXED
        h=ceil_ratio(h*h2,FIXED)
    # ln((1+q)/(1-q)) has a positive atanh series; 2/(1-q^2) <= 3.
    return lo,hi+ceil_ratio(3*h,2*LOG_TERMS+1)


LN2=unit_log(F(2))


@lru_cache(maxsize=12000)
def log2_bound(x):
    assert x>=1
    if x==1:
        return ZERO,ZERO
    k=x.numerator.bit_length()-x.denominator.bit_length()
    y=x/(1<<k)
    if y<1:
        y*=2
        k-=1
    assert 1<=y<2 and k>=0
    lo,hi=unit_log(y)
    return k+F(lo,LN2[1]),k+F(hi,LN2[0])


def primitive(x,density):
    period=F(density["period"])
    bump=F(density["bump_center_mod_period"])
    width=F(density["bump_half_width"])
    base=F(density["density_floor_one_axis"])
    high=F(density["density_peak_one_axis"])-base
    k=x//period
    s=x-k*period
    return base*x+high*(k*2*width+min(2*width,max(ZERO,s-bump+width)))


def line_mass(lo,hi,density):
    a,b=map(F,density["support"])
    lo,hi=max(lo,a),min(hi,b)
    return primitive(hi,density)-primitive(lo,density) if hi>lo else ZERO


def grid_interval(index,step,phase):
    lo=phase+index*step
    return lo,lo+step


def rectified_grid(H,step,phase,density):
    coord_weights=[]
    for lo,hi in H:
        if hi<=lo:
            return {}
        z=(hi-phase)/step
        first=(lo-phase)//step
        last=ceil_ratio(z.numerator,z.denominator)
        weights={}
        for k in range(first,last):
            a,b=grid_interval(k,step,phase)
            w=line_mass(max(lo,a),min(hi,b),density)
            if w:
                weights[k]=w
        assert total(weights.values())==line_mass(lo,hi,density)
        coord_weights.append(weights)
    return {C:prod(w[q] for q,w in zip(C,coord_weights)) for C in product(*coord_weights)}


def actual_arms(stage,step,phase):
    p={x["id"]:x for x in stage["parents"]}
    density=stage["density"]
    out={}
    physical_mass={}
    for t,deg in stage["degrees"].items():
        if p[t]["role"]!="middle":
            continue
        for u in deg["old_terms"]:
            H=intersection(box(p[t],"box"),box(p[u],"box"))
            real=rectified_grid(H,step,phase,density)
            assert total(real.values())==comb_mass(H,density)==F(deg["true_mu_intersections"][u])>0
            for C,w in real.items():
                A=tuple(grid_interval(k,step,phase) for k in C)
                assert w==comb_mass(intersection(H,A),density)
                if C not in physical_mass:
                    physical_mass[C]=comb_mass(A,density)
                    assert prod(line_mass(*iv,density) for iv in A)==physical_mass[C]
                assert 0<w<=physical_mass[C]
            out[t,u]=real
    return p,out,physical_mass


def root_order(stage,parents,arms):
    result=defaultdict(F)
    by_t=defaultdict(F)
    for e in stage["roots_cross"]:
        t,u,g=(e[k] for k in ("t","u","g"))
        T,U,G=(parents[k] for k in (t,u,g))
        coeff=F(T["j"])*F(U["j"])*F(G["j"])/(F(T["full_d"])*F(T["m"])**2*F(U["m"])*F(G["m"]))
        assert coeff==F(e["coefficient"]) and U["volume_bin"]!=G["volume_bin"]
        left,right=arms[t,u],arms[t,g]
        mother=coeff*total(left.values())*total(right.values())
        assert mother==F(e["root_mass"])==total(map(F,e["sectors_00_01_10_11"]))
        for (C,x),(D,y) in product(left.items(),right.items()):
            result[C,D]+=coeff*x*y
        by_t[t]+=mother
    assert total(result.values())==total(by_t.values())==F(stage["benchmarks"]["cross"]["mother"])
    return result,by_t


def middle_first(parents,arms):
    whole=defaultdict(lambda:defaultdict(F))
    split=defaultdict(lambda:defaultdict(lambda:defaultdict(F)))
    for (t,u),grid in arms.items():
        p=parents[u]
        b=F(p["j"])/F(p["m"])
        for C,w in grid.items():
            whole[t][C]+=b*w
            split[t][p["volume_bin"]][C]+=b*w
    result=defaultdict(F)
    by_t=defaultdict(F)
    for t,S in whole.items():
        p=parents[t]
        scale=F(p["j"])/(F(p["full_d"])*F(p["m"])**2)
        for (C,x),(D,y) in product(S.items(),repeat=2):
            ordered_cross=x*y-total(V.get(C,ZERO)*V.get(D,ZERO) for V in split[t].values())
            assert ordered_cross>=0
            if ordered_cross:
                result[C,D]+=scale*ordered_cross
                by_t[t]+=scale*ordered_cross
    return result,by_t


def menu_right(row,physical_mass,budget):
    at_cost=defaultdict(list)
    for D,w in row.items():
        if physical_mass[D]<=budget:
            at_cost[physical_mass[D]].append(w)
    frontier={ZERO:ZERO}
    for cost,values in sorted(at_cost.items()):
        values.sort(reverse=True)
        prefix=[ZERO]
        for value in values:
            prefix.append(prefix[-1]+value)
        next_frontier={}
        for pay,benefit in frontier.items():
            for k,x in enumerate(prefix):
                spend=pay+k*cost
                if spend>budget:
                    break
                next_frontier[spend]=max(next_frontier.get(spend,ZERO),benefit+x)
        # A cheaper menu with at least the same reward dominates for later classes.
        frontier={}
        best=F(-1)
        for v,p in sorted(next_frontier.items()):
            if p>best:
                frontier[v]=p
                best=p
    return max(frontier.values()),len(frontier)


def summary(label,step,phase,arms,physical_mass,P,by_t):
    mother=total(P.values())
    row=defaultdict(dict)
    assert all(P[C,D]==P[D,C]>0 for C,D in P)
    cap,Cmax,Dmax=max((w/min(physical_mass[C],physical_mass[D]),C,D)
                     for (C,D),w in P.items())
    for (C,D),w in P.items():
        row[C][D]=w
    pd={C:total(vals.values()) for C,vals in row.items()}
    assert total(pd.values())==mother and set(row)==set(physical_mass)
    choices=[]
    shannon=[ZERO,ZERO]
    best_absolute=ZERO
    menu_values={M:ZERO for M in (1,2)}
    cap_bounds={M:ZERO for M in menu_values}
    max_frontier=0
    for C,companions in sorted(row.items()):
        p_C=pd[C]
        D=max(companions,key=lambda D:(companions[D],D))
        r=companions[D]
        best_absolute+=r
        physical=physical_mass[C]
        choices.append([C,D,physical,p_C,r/p_C])
        for w in companions.values():
            lo,hi=log2_bound(p_C/w)
            shannon[0]+=w*lo/mother
            shannon[1]+=w*hi/mother
        for M in menu_values:
            benefit,frontier_size=menu_right(companions,physical_mass,M*physical)
            cap_limit=min(p_C,M*physical*cap)
            assert ZERO<=benefit<=cap_limit
            menu_values[M]+=benefit
            cap_bounds[M]+=cap_limit
            max_frontier=max(max_frontier,frontier_size)
    assert shannon[0]<=shannon[1] and shannon[1]-shannon[0]<F(1,1<<72)
    picked=best_absolute/mother
    # The cap controls any collection by its true source masses, independent of a count cutoff.
    assert log2_bound(1/picked)[0]<=shannon[1]
    return dict(grid=label,step=step,origin_in_each_axis=phase,all_original_pair_mass=mother,
                original_pair_mass_by_middle=by_t,positive_grid_price_pair_count=len(P),
                positive_left_grid_cells=len(row),total_true_mu_of_positive_grid_cells=total(physical_mass.values()),
                active_arm_cell_count=len(arms),arm_grid_cell_count=sum(len(a) for a in arms.values()),
                exact_max_pair_density_cap=cap,cap_over_original_Gamma=cap/mother,
                cap_witness=dict(C=Cmax,D=Dmax,P_CD=P[Cmax,Dmax],m_C=physical_mass[Cmax],m_D=physical_mass[Dmax]),
                exact_one_partner_success=picked,highest_single_conditional_probability=max(x[-1] for x in choices),
                one_partner_row_fields=["C","best_D","true_mu_of_C","original_P_C","best_conditional_probability"],
                one_partner_rows=choices,conditional_entropy_bits_interval=shannon,
                exact_per_row_neighbor_menu_globalized_rate={k:v/mother for k,v in menu_values.items()},
                maximum_menu_frontier_size=max_frontier,
                density_cap_upper_bound_on_menu_rate={k:v/mother for k,v in cap_bounds.items()})


def check_stage(stage):
    grids=[]
    for label,step,phase in GRIDS:
        parents,arms,physical_mass=actual_arms(stage,step,phase)
        P,by_t=root_order(stage,parents,arms)
        again,again_t=middle_first(parents,arms)
        assert P==again and by_t==again_t
        witness=summary(label,step,phase,arms,physical_mass,P,by_t)
        # With this calibrated comb and aligned grids, each active cell has the same true cost.
        if label.endswith("_aligned"):
            assert len(set(physical_mass.values()))==1
            assert witness["exact_per_row_neighbor_menu_globalized_rate"][1]==witness["exact_one_partner_success"]
        grids.append(witness)
    assert len({x["all_original_pair_mass"] for x in grids})==1
    return dict(dimension=stage["dimension"],law="cross",grids=grids)


def audit(path):
    data=json.loads(path.read_text())
    return dict(runtime={"python":platform.python_version(),"architecture":platform.machine()},
                input_sha256=sha256(path.read_bytes()).hexdigest(),
                helper_sha256=sha256(Path(__file__).with_name("trade813.py").read_bytes()).hexdigest(),
                scope="Original cross-bin peak measure on the actual finite periodic-comb cubes, with true price, full central degree and true auxiliary receiver weight. No extra long-jump distance gate is imposed.",
                geometry="Half-open physical grid cells are indexed by integer n-tuples; origin and step are recorded. Source masses m_C refer to the full grid cell under the original mu. Each arm mass is cut by both true parents. The supports crossing grid boundaries lose no mass.",
                second_pass="The pointwise pair matrix from original roots equals the matrix obtained by summing original old-leg weights by middle, subtracting same-old-bin products, then summing middles.",
                entropy="Shannon H(right cell | left cell) under the original pair law, in bits. All log bounds use the closed-form positive atanh series with a certified residual and outward rational fixed-point arithmetic.",
                menu="For each observed C, any positive-mass partner cell D costs its full true mu(D). The exact optimum at budgets mu(C) and 2 mu(C) is computed by same-cost prefixes and a Pareto frontier. Menus are independent of the hidden old or middle label.",
                replay="python -B cells813.py --comb <verified-final/comb811.json> --check cells813.json",
                stages=[check_stage(stage) for stage in data["stages"]])


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--comb",type=Path,required=True)
    mode=p.add_mutually_exclusive_group(required=True)
    mode.add_argument("--output",type=Path)
    mode.add_argument("--check",type=Path)
    args=p.parse_args()
    data=audit(args.comb)
    contents=(json.dumps(data,indent=2,sort_keys=True,default=str)+"\n").encode()
    if args.output:
        args.output.write_bytes(contents)
    else:
        assert args.check.read_bytes()==contents
    for s in data["stages"]:
        for g in s["grids"]:
            fmt=lambda v:f"{float(v):.9g}"
            print(s["dimension"],g["grid"],g["positive_left_grid_cells"],g["positive_grid_price_pair_count"],
                  "raw cap",fmt(g["exact_max_pair_density_cap"]),"best",fmt(g["exact_one_partner_success"]),
                  "entropy bits",fmt(g["conditional_entropy_bits_interval"][0]),
                  "menus",[(M,fmt(v)) for M,v in g["exact_per_row_neighbor_menu_globalized_rate"].items()])
    if args.check:
        print("byte-identical rational replay")


if __name__=="__main__":
    main()
