#!/usr/bin/env python3
"""Exact receiver-or-source flow and type-cut certificate on true marked intervals."""
import argparse
from collections import deque
from fractions import Fraction as F
from itertools import product
import json
from pathlib import Path
import platform


SOURCE = (F(-8),F(8))
PERIOD = F(1,2)
L = F(1,128)
SHRINK = 32


def total(xs):
    return sum(xs,F(0))


def iv(a,b):
    return F(a),F(b)


def length(q):
    return max(F(0),q[1]-q[0])


def intersection(*q):
    return max(x[0] for x in q),min(x[1] for x in q)


def contained(p,q):
    return q[0]<=p[0]<=p[1]<=q[1]


def owner(q):
    c=total(q)/2
    r=length(q)/(2*SHRINK)
    return c-r,c+r


def dilation(q,epsilon):
    c=total(q)/2
    r=(1+epsilon)*length(q)/2
    return c-r,c+r


def exterior(q,excluded):
    """Positive interval pieces outside a closed interval, up to null endpoints."""
    return [bd for bd in ((q[0],min(q[1],excluded[0])),
                          (max(q[0],excluded[1]),q[1])) if length(bd)]


def mass(q,amplitude):
    a,b=intersection(q,SOURCE)
    if a>=b:
        return F(0)

    def primitive(x):
        s=x%PERIOD
        return x+amplitude*min(s,PERIOD-s)

    return primitive(b)-primitive(a)


def actual_old_prefix(q,w,amplitude):
    """Invert the true positive density on the old price interval."""
    assert 0<w<=mass(q,amplitude)
    lo,hi=q
    x=lo
    half=PERIOD/2
    left=w
    while x<hi:
        k=x//half
        r=min(hi,(k+1)*half)
        density=1+amplitude if k%2==0 else 1-amplitude
        v=(r-x)*density
        if left<=v:
            stop=x+left/density
            box=(lo,stop)
            assert contained(box,q) and mass(box,amplitude)==w
            return box
        x=r
        left-=v
    raise AssertionError("old-price prefix exceeds its range")


def finite_maxflow(demand, receivers, price_atoms, price_cap, receiver_cap, redraw=False):
    """Edmonds-Karp over rational supplies and actual physical resource cells."""
    first_record=1
    first_receiver=first_record+len(demand)
    first_price=first_receiver+len(receivers)
    terminal=first_price+len(price_atoms)
    n=terminal+1
    graph=[[] for _ in range(n)]
    initial={}
    residual={}

    def edge(u,v,capacity):
        graph[u].append(v)
        graph[v].append(u)
        initial[u,v]=residual[u,v]=capacity
        residual[v,u]=F(0)

    M=total(q["supply"] for q in demand)
    extra=M+1
    for i,r in enumerate(demand):
        k=first_record+i
        edge(0,k,r["supply"])
        for j,R in enumerate(receivers):
            if r["receiver"]==j or (redraw and receivers[r["receiver"]]["physical_u"]==R["physical_u"]):
                edge(k,first_receiver+j,extra)
        for a in r["source_ids"]:
            edge(k,first_price+a,extra)
    for k,v in enumerate(receiver_cap):
        edge(first_receiver+k,terminal,v)
    for k,v in enumerate(price_cap):
        edge(first_price+k,terminal,v)

    value=F(0)
    augmentations=0
    while True:
        prev={0:-1}
        queue=deque([0])
        while queue and terminal not in prev:
            u=queue.popleft()
            for v in graph[u]:
                if residual[u,v]>0 and v not in prev:
                    prev[v]=u
                    queue.append(v)
        if terminal not in prev:
            reachable=set(prev)
            break
        v=terminal
        path=[]
        while v:
            u=prev[v]
            path.append((u,v))
            v=u
        change=min(residual[uv] for uv in path)
        for u,v in path:
            residual[u,v]-=change
            residual[v,u]+=change
        value+=change
        augmentations+=1

    cut=total(c for (u,v),c in initial.items() if u in reachable and v not in reachable)
    assert cut==value
    receiver_paid=total(residual[terminal,k] for k in range(first_receiver,first_price))
    source_paid=total(residual[terminal,k] for k in range(first_price,terminal))
    assert value==receiver_paid+source_paid
    inside=F(0)
    outside=F(0)
    for i,r in enumerate(demand):
        k=first_record+i
        used=total(residual.get((v,k),F(0)) for v in range(first_receiver,terminal))
        assert used==residual[k,0]<=r["supply"]
        for j in r["source_ids"]:
            used=residual[first_price+j,k]
            atom=price_atoms[j]["box"]
            if contained(atom,r["old_I"]):
                inside+=used
            else:
                assert not length(intersection(atom,r["old_I"]))
                outside+=used
    assert inside+outside==source_paid
    return dict(paid=value,min_cut=cut,unpaid=M-value,receiver_paid=receiver_paid,
                source_paid=source_paid,source_paid_in_actual_old_overlap=inside,
                source_paid_outside_actual_old_overlap=outside,augmentations=augmentations,
                physical_cut_records=[i for i in range(len(demand)) if first_record+i in reachable],
                physical_cut_receivers=[j for j in range(len(receivers)) if first_receiver+j in reachable],
                physical_cut_sources=[j for j in range(len(price_atoms)) if first_price+j in reachable])


def subset_exact(indices, demand, receiver_cap, source_cap):
    rec={demand[i]["receiver"] for i in indices}
    src={a for i in indices for a in demand[i]["source_ids"]}
    w=total(demand[i]["supply"] for i in indices)
    return w-total(receiver_cap[j] for j in rec)-total(source_cap[a] for a in src)


def test(name,tt,uu,spec,amplitude,parts,P,exterior_eps=None):
    owners_t=list(map(owner,tt))
    owners_u=list(map(owner,uu))
    allowners=sorted(owners_t+owners_u)
    assert all(x[1]<y[0] for x,y in zip(allowners,allowners[1:]))
    assert all(mass(A,amplitude)==length(A) for A in tt+uu)
    neighbors={}
    for t,u in product(range(len(tt)),range(len(uu))):
        shared=intersection(tt[t],uu[u])
        m=mass(shared,amplitude)
        if m:
            assert length(uu[u])<length(tt[t])
            neighbors[t,u]=m/(length(tt[t])*length(uu[u])),shared
    d=[total(length(owners_u[u])*K for (j,u),(K,_) in neighbors.items() if j==t) for t in range(len(tt))]
    source_choices=[]
    for t,u,old_prefix_masses,Bt,Bu in spec:
        assert contained(Bt,tt[t]) and contained(Bu,uu[u])
        left,right=[Bt],[Bu]
        fallback=False
        if exterior_eps is not None:
            D_t,D_u=dilation(tt[t],exterior_eps),dilation(uu[u],exterior_eps)
            left,right=exterior(Bt,D_u),exterior(Bu,D_t)
            if not (left or right):
                fallback=True
                left,right=exterior(tt[t],D_u),exterior(uu[u],D_t)
            assert all(contained(b,tt[t]) and length(intersection(b,D_u))==0 for b in left)
            assert all(contained(b,uu[u]) and length(intersection(b,D_t))==0 for b in right)
        source_choices.append((left,right,fallback))
    breaks=[*SOURCE,*(p for q in tt+uu for p in q),
            *(p for _,_,_,a,b in spec for q in (a,b) for p in q),
            *(p for left,right,_ in source_choices for q in left+right for p in q)]
    ends=sorted(set(breaks))
    price_atoms=[dict(box=q,mu=mass(q,amplitude)) for q in zip(ends,ends[1:])]
    price_cap=[P*a["mu"] for a in price_atoms]
    pay_types=[]
    receivers=[]
    for u,A in enumerate(owners_u):
        step=length(A)/parts
        for j in range(parts):
            receivers.append(dict(physical_u=u,box=(A[0]+j*step,A[0]+(j+1)*step)))
    rc=[L*length(q["box"]) for q in receivers]
    demand=[]
    for e,(t,u,old_prefix_masses,Bt,Bu) in enumerate(spec):
        assert contained(Bt,tt[t]) and contained(Bu,uu[u])
        assert len(old_prefix_masses)==parts and len(set(old_prefix_masses))>1
        K,I=neighbors[t,u]
        w=length(owners_t[t])*length(owners_u[u])*K
        projected=total(length(owners_t[t])*length(owners_u[u])*length(owners_u[v])*K*K2/d[t]
                        for (l,v),(K2,_) in neighbors.items() if l==t)
        assert projected==w
        left,right,fallback=source_choices[e]
        union_B=[j for j,a in enumerate(price_atoms) if any(contained(a["box"],b) for b in left+right)]
        assert union_B
        union_weight=total(price_atoms[j]["mu"] for j in union_B)
        left_mass=total(mass(b,amplitude) for b in left)
        right_mass=total(mass(b,amplitude) for b in right)
        shared=total(mass(intersection(b,c),amplitude) for b,c in product(left,right))
        assert union_weight==left_mass+right_mass-shared
        if exterior_eps is not None:
            assert shared==0
        raw=[]
        rows=[]
        for j,m in enumerate(old_prefix_masses):
            prefix=actual_old_prefix(I,m,amplitude)
            receiver=parts*u+j
            g=w/length(owners_u[u])*m/mass(I,amplitude)
            assert g==m/(SHRINK*length(uu[u]))
            h=length(receivers[receiver]["box"])
            assert g*h==w*(h/length(owners_u[u]))*mass(prefix,amplitude)/mass(I,amplitude)
            demand.append(dict(type=e,receiver=receiver,supply=g*h,density=g,source_ids=union_B,
                               old_I=I,actual_prefix=prefix))
            raw.append(mass(prefix,amplitude))
            rows.append(dict(receiver=receiver,density=g,old_true_price_prefix=prefix,source_prefix_mu=m))
        assert raw==list(old_prefix_masses)
        pay_types.append(dict(e=e,t=t,u=u,g_rows=rows,original_K=K,full_old_d=d[t],old_intersection=I,
                              old_original_marginal=w,source_B_t=Bt,source_B_u=Bu,source_ids=union_B,
                              eligible_prices_t=left,eligible_prices_u=right,
                              true_masses_by_source_side=[left_mass,right_mass],
                              shared_mass_between_source_sides=shared,
                              fallback_to_full_parents_before_exclusion=fallback,
                              mu_B_union=union_weight,
                              mu_B_inside_true_old_intersection=total(price_atoms[j]["mu"] for j in union_B
                                                                     if contained(price_atoms[j]["box"],I))))
    n=len(pay_types)
    M=total(r["supply"] for r in demand)
    exact=finite_maxflow(demand,receivers,price_atoms,price_cap,rc)
    pooled=finite_maxflow(demand,receivers,price_atoms,price_cap,rc,redraw=True)
    all_F=[]
    for seq in product((0,1),repeat=n):
        Fset={i for i,q in enumerate(seq) if q}
        covered={a for i in Fset for a in pay_types[i]["source_ids"]}
        src=total(price_cap[a] for a in covered)
        by_u=[total(r["supply"] for r in demand if r["type"] in Fset and r["receiver"]==u)
              for u in range(len(receivers))]
        overflow=total(max(F(0),v-cap) for v,cap in zip(by_u,rc))
        selected=[i for i,r in enumerate(demand)
                  if r["type"] in Fset and by_u[r["receiver"]]>rc[r["receiver"]]]
        physical=subset_exact(selected,demand,rc,price_cap)
        assert physical>=overflow-src
        assert physical<=exact["unpaid"]
        private_spill=total(max(F(0),r["supply"]-rc[r["receiver"]]) for r in demand if r["type"] in Fset)
        average=max(F(0),total(by_u)-total(c for w,c in zip(by_u,rc) if w))
        owner_pool=total(max(F(0),total(by_u[parts*u:parts*(u+1)])
                             -total(rc[parts*u:parts*(u+1)]))
                         for u in {pay_types[i]["u"] for i in Fset})
        assert private_spill<=overflow and average<=owner_pool<=overflow
        all_F.append(dict(types=sorted(Fset),true_source_union_mu=src/P,source_budget=src,
                          overflow=overflow,deficit=overflow-src,
                          wrong_individual_positive_deficit=private_spill-src,
                          wrong_global_average_deficit=average-src,owner_pool_deficit=owner_pool-src,
                          realizing_physical_record_set=selected,actual_cut_set_deficit=physical))
    sorted_F=sorted(all_F,key=lambda r:(-r["deficit"],r["types"]))
    delta=sorted_F[0]["deficit"]
    maximum=lambda field:max(q[field] for q in all_F)
    assert 0<delta==exact["unpaid"]<M
    assert 0<exact["receiver_paid"] and 0<exact["source_paid"]
    assert delta==sorted_F[0]["actual_cut_set_deficit"]
    assert exact["unpaid"]>=pooled["unpaid"]==maximum("owner_pool_deficit")
    assert maximum("wrong_individual_positive_deficit")<=delta
    assert maximum("wrong_global_average_deficit")<=delta
    if len(demand)<=12:
        direct=max(subset_exact([i for i,f in enumerate(seq) if f],demand,rc,price_cap)
                   for seq in product((0,1),repeat=len(demand)))
        assert direct==delta
    else:
        direct=None

    if name=="initial":
        assert delta==F(53,524288)
        assert maximum("wrong_individual_positive_deficit")==maximum("wrong_global_average_deficit")==0
        assert pooled["unpaid"]==0
    if name=="pressure":
        assert sorted_F[0]["types"]==[0,1] and sorted_F[1]["types"]==[0,1,2]
        assert sorted_F[0]["deficit"]>sorted_F[1]["deficit"]>0
    if name=="expanded":
        assert len({r["u"] for r in pay_types})>=2
        if exterior_eps is None:
            assert any(0<e["mu_B_inside_true_old_intersection"]<e["mu_B_union"] for e in pay_types)
    if exterior_eps is not None:
        assert all(e["mu_B_inside_true_old_intersection"]==0 for e in pay_types)
        assert exact["source_paid_in_actual_old_overlap"]==pooled["source_paid_in_actual_old_overlap"]==0
        assert exact["source_paid_outside_actual_old_overlap"]==exact["source_paid"]
    return dict(stage=name, exterior_relative_expansion=exterior_eps,
                terminal_boxes=tt, small_boxes=uu, actual_owners_t=owners_t, actual_owners_u=owners_u,
                amplitude=amplitude, original_degrees=d, original_received_weight=M, original_types=pay_types,
                receiver_cells=receivers, receiver_caps=rc, price_cells=price_atoms, source_density_cap=P,
                actual_maxflow=exact, invalid_receiving_same_owner_redraw=pooled,
                type_cut_delta=delta, best_type_cut=sorted_F[0], runner_up_type_cut=sorted_F[1],
                all_type_cuts=sorted_F, independent_all_record_subset_cut=direct,
                maximum_wrong_individual_positive=maximum("wrong_individual_positive_deficit"),
                maximum_wrong_global_integrated=maximum("wrong_global_average_deficit"))


def suite():
    bonds=[iv(F(t,4),4+F(t,4)) for t in range(5)]
    outer=iv("-3/4","-1/4")
    s0,s1=iv(2,"5/2"),iv("9/4","11/4")
    initial=[(0,0,(F(3,8),F(1,16)),s0,outer),
             (1,0,(F(3,8),F(1,16)),s1,outer)]
    pressure=[(0,0,(F(1,2),F(1,2),F(1,32),F(1,32)),s0,outer),
              (1,0,(F(3,8),F(1,16),F(3,8),F(1,32)),s1,outer),
              (2,0,(F(1,16),F(3,8),F(1,8),F(1,32)),iv(1,4),outer)]
    expanded=pressure+[
          (2,1,(F(1,16),F(1,2),F(1,8),F(1,8)),iv(2,"7/2"),iv("19/4",5)),
          (3,1,(F(1,16),F(1,4),F(1,2),F(1,16)),iv("5/2","7/2"),iv("9/2",5)),
          (4,1,(F(1,16),F(1,8),F(5,8),F(1,16)),iv(2,3),iv("9/2",5)),
          (1,2,(F(1,32),F(1,8),F(1,32),F(1,16)),iv(2,"5/2"),iv("9/4","11/4")),
    ]
    u0=iv(-1,1)
    fixtures=[
      ("initial",bonds[:2],[u0],initial,F(1,2),2,F(1,65536)),
      ("pressure",bonds[:3],[u0],pressure,F(1,2),4,F(1,16384)),
      ("expanded",bonds,[u0,iv(3,5),iv("9/8","25/8")],expanded,F(3,4),4,F(1,32768)),
    ]
    baseline=[test(*row) for row in fixtures]
    corrected=[test(*row,exterior_eps=F(1,64)) for row in fixtures]
    assert all(x["original_received_weight"]==y["original_received_weight"] for x,y in zip(baseline,corrected))
    return baseline,corrected


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    cli=parser.add_mutually_exclusive_group()
    cli.add_argument("--output",type=Path)
    cli.add_argument("--check",type=Path)
    args=parser.parse_args()
    stages,exterior_stages=suite()
    data=dict(runtime=dict(python=platform.python_version(),architecture=platform.machine()),
              precision="exact continuous fractions and exact network augmentations",
              command="python -B cut797.py --check cut797.json",
              scope=dict(true_mu_support=SOURCE,density="1±amplitude on alternating half periods of length 1/4",
                         L=L,leg_record="old genuine short-parent probe U and actual old intersection price z; a fixed old-price threshold changes at rational U cuts",
                         price_capacity="one physical mu cap shared by both source roles and all types",
                         acceptance="only the finite physical old-price screen is enforced; no high-dimensional gates"),
              stages=stages,
              exterior_constraint=dict(relative_expansion=F(1,64),
                   true_sets="B_t minus the closed dilated A_u, and B_u minus the closed dilated A_t",
                   endpoints="excluded by definition; all omitted endpoints have zero true mass",
                   fallback="only when both displayed initial roles are empty, apply the same external requirement to the two full real parents"),
              exterior_stages=exterior_stages)
    encoded=json.dumps(data,indent=2,sort_keys=True,default=str)+"\n"
    if args.output:
        args.output.write_text(encoded)
    if args.check:
        assert args.check.read_text()==encoded
    if args.output or args.check:
        for c in stages:
            m=c["actual_maxflow"]
            print(c["stage"],"paid",m["paid"],"deficit",m["unpaid"],"F",c["best_type_cut"]["types"],
                  "redraw deficit",c["invalid_receiving_same_owner_redraw"]["unpaid"])
        for row in exterior_stages:
            m=row["actual_maxflow"]
            print(row["stage"],"strictly external deficit",m["unpaid"],
                  "source paid",m["source_paid"],"in-overlap source paid",m["source_paid_in_actual_old_overlap"])
        if args.check:
            print("byte-identical")
    else:
        print(encoded,end="")


if __name__=="__main__":
    main()
