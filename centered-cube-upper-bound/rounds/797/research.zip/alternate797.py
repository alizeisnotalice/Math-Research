#!/usr/bin/env python3
"""Exact finite test of fresh-source versus genuine old-small-parent source payment."""
import argparse
from fractions import Fraction as F
from itertools import product
import json
from pathlib import Path
import platform


PERIOD = F(1, 2)
SUPPORT = (F(-8), F(8))
OWNER_SHRINK = 32


def total(xs):
    return sum(xs, F(0))


def interval(a, b):
    return F(a), F(b)


def length(box):
    return max(F(0), box[1]-box[0])


def intersect(*boxes):
    return max(x[0] for x in boxes), min(x[1] for x in boxes)


def mid(box):
    return total(box)/2


def inside(a, b):
    return b[0] <= a[0] <= a[1] <= b[1]


def owner(box):
    r = length(box)/(2*OWNER_SHRINK)
    return mid(box)-r, mid(box)+r


def mass(box, amplitude):
    lo, hi = intersect(box, SUPPORT)
    if lo >= hi:
        return F(0)

    def primitive(x):
        rem = x % PERIOD
        return x + amplitude*min(rem, PERIOD-rem)

    return primitive(hi)-primitive(lo)


def cells_for(*families):
    breaks = sorted({x for family in families for box in family for x in box})
    return list(zip(breaks, breaks[1:]))


def tally(t_boxes, u_boxes, normalized, H, amplitude):
    by_t = [[F(0)]*5 for _ in t_boxes]
    for (t, u), weight in normalized.items():
        A, B = t_boxes[t], u_boxes[u]
        py = mass(intersect(H,A),amplitude)/length(A)
        px = mass(intersect(H,B),amplitude)/length(B)
        outside_H_A = (length(B)-mass(intersect(B,H),amplitude)-mass(intersect(B,A),amplitude)
                       +mass(intersect(B,H,A),amplitude))/length(B)
        values = (py*px, py*(1-px), (1-py)*px, (1-py)*(1-px), py*outside_H_A)
        assert 0 <= values[4] <= values[1]
        for j, v in enumerate(values):
            by_t[t][j] += weight*v
    return [total(col) for col in zip(*by_t)], by_t


def verify_physical_cells(t_boxes, u_boxes, normalized, H, amplitude, expected):
    atoms = cells_for(t_boxes,u_boxes,[H], [SUPPORT])
    mu = [mass(a, amplitude) for a in atoms]
    direct = [F(0)]*5
    for (t,u), weight in normalized.items():
        A, B = t_boxes[t], u_boxes[u]
        for (x, mx), (y, my) in product(zip(atoms,mu), repeat=2):
            if not (inside(x,B) and inside(y,A)):
                continue
            in_y, in_x = inside(y,H), inside(x,H)
            w = weight*mx*my/(length(A)*length(B))
            bucket = {(True,True):0,(True,False):1,(False,True):2,(False,False):3}[in_y,in_x]
            direct[bucket] += w
            if bucket == 1 and not inside(x,A):
                direct[4] += w
    assert direct == expected
    assert total(direct[:4]) == 1
    return atoms, mu


def true_source_capacity(t_boxes,u_boxes, normalized,H,amplitude,atoms,mu):
    # One shared capacity for each *physical* source atom, in units of total raw branch mass.
    rate = F(1,32)
    _, by_t = tally(t_boxes,u_boxes, normalized,H,amplitude)
    requested = [[F(0)]*len(atoms) for _ in t_boxes]
    primal_available = {}
    for (t,u), weight in normalized.items():
        A, B = t_boxes[t], u_boxes[u]
        spent_y = mass(intersect(A,H),amplitude)/length(A)
        for a,(box, m) in enumerate(zip(atoms,mu)):
            if inside(box,B) and not inside(box,A) and not inside(box,H):
                arc = weight*spent_y*m/length(B)
                requested[t][a] += arc
                if arc:
                    primal_available[t,u,a] = arc
    assert [total(row) for row in requested] == [row[4] for row in by_t]
    joint = [total(col) for col in zip(*requested)]
    caps = [rate*m for m in mu]
    winners = [int(R>c) for R,c in zip(joint,caps)]
    primal = {(t,u,a):v*min(F(1),caps[a]/joint[a])
              for (t,u,a),v in primal_available.items()}
    assert all(0<=w<=primal_available[k] for k,w in primal.items())
    for a in range(len(atoms)):
        assert total(w for (t,u,j),w in primal.items() if j==a) <= caps[a]
    for (t,u), weight in normalized.items():
        assert total(w for (i,j,a),w in primal.items() if (i,j)==(t,u)) <= weight
    # For each arc the source-cap dual plus its own arc-cap dual is exactly one.
    dual = total(c*w for c,w in zip(caps,winners)) + total(
        v*(1-winners[a]) for (t,u,a),v in primal_available.items())
    optimum = total(primal.values())
    assert optimum == dual == total(min(r,c) for r,c in zip(joint,caps))
    resetting = total(min(v,c) for row in requested for v,c in zip(row,caps))
    assert 0<optimum<=resetting<=total(joint)
    return dict(density_cap=rate, paid_primal=optimum, paid_dual=dual,
                all_real_external_requests=total(joint), incorrectly_reset_per_t=resetting,
                atoms=[dict(interval=b, raw_request=R, shared_cap=c, dual_source=v)
                       for b,R,c,v in zip(atoms,joint,caps,winners) if R])


def shared_old(t_boxes,u_boxes,H,amplitude,raw,raw_t,old_z):
    A_u = u_boxes[0]
    E_u = owner(A_u)
    observation_U = E_u[0], E_u[0]+length(E_u)/3
    z_mass = mass(old_z,amplitude)
    observed = []
    for t,A in enumerate(t_boxes):
        assert inside(old_z,intersect(A,A_u))
        weight, _, box = raw[t,0]
        observed.append(weight*z_mass/mass(box,amplitude)*length(observation_U)/length(E_u))
    evidence = total(observed)
    posterior = [w/evidence for w in observed]
    assert evidence>0 and total(posterior)==1
    point = mid(observation_U)
    assert E_u[0] < point < E_u[1]

    incorrect, correct = [], []
    for t,A in enumerate(t_boxes):
        p = [raw.get((t,u),(F(0),))[0]/raw_t[t] for u in range(len(u_boxes))]
        assert total(p)==1
        fake_hits_old_price = total(w*mass(intersect(B,old_z),amplitude)/z_mass for w,B in zip(p,u_boxes))
        fake_x_in_real_u = total(w*mass(intersect(B,A_u),amplitude)/length(B) for w,B in zip(p,u_boxes))
        fake_x_H = total(w*mass(intersect(B,H),amplitude)/length(B) for w,B in zip(p,u_boxes))
        fake_x_A = total(w*mass(intersect(B,A),amplitude)/length(B) for w,B in zip(p,u_boxes))
        true_x_H = mass(intersect(A_u,H),amplitude)/length(A_u)
        true_x_A = mass(intersect(A_u,A),amplitude)/length(A_u)
        fake_replays_owner = total(w for w,i in zip(p,map(owner,u_boxes)) if i[0]<=point<=i[1])
        assert fake_replays_owner==p[0]<1
        assert fake_x_in_real_u < 1 and fake_hits_old_price < 1
        # More than a relabeling: the true conditional x law is rho_u even
        # though its observed old z is restricted to a narrow tiny overlap.
        correct.append(dict(u_given_old_price_and_owner=F(1), x_still_in_old_parent=F(1),
                            x_in_H=true_x_H, x_in_terminal=true_x_A))
        incorrect.append(dict(independent_u_given_t=p, accepts_observed_old_z=fake_hits_old_price,
                              accepts_same_physical_U=fake_replays_owner,
                              x_still_in_old_parent=fake_x_in_real_u, x_in_H=fake_x_H,x_in_terminal=fake_x_A))
    true_inH = total(w*r["x_in_H"] for w,r in zip(posterior,correct))
    fake_inH = total(w*r["x_in_H"] for w,r in zip(posterior,incorrect))
    assert true_inH != fake_inH

    common = intersect(*t_boxes)
    common_mass = mass(common,amplitude)
    assert common_mass>0 and inside(common,H)
    beta = [common_mass/length(A) for A in t_boxes]
    assert len(set(beta))==1
    # On the overlap component every true rho_t can use exactly the same y.
    # Since its weight beta is common, observing this component leaves t|z,U unchanged.
    exterior_amount = []
    count = [F(0)]*(len(t_boxes)+1)
    for cell in cells_for(t_boxes,[A_u],[H]):
        if inside(cell,A_u):
            k = sum(not inside(cell,A) and not inside(cell,H) for A in t_boxes)
            count[k] += mass(cell,amplitude)/length(A_u)
    assert total(count)==1
    for A in t_boxes:
        amount = total(mass(cell,amplitude)/length(A_u) for cell in cells_for([A_u,A,H])
                       if inside(cell,A_u) and not inside(cell,A) and not inside(cell,H))
        exterior_amount.append(amount)
    shared_union = 1-count[0]
    repeated = total(exterior_amount)
    assert repeated == total(k*p for k,p in enumerate(count))
    assert 0<shared_union<repeated and count[-1]>0
    return dict(true_u_box=A_u, true_E_u=E_u, fixed_old_z_cell=old_z, same_U_subinterval=observation_U,
                old_joint_observation_masses=observed, t_given_old_z_and_U=posterior,
                true_branch=correct, independently_redraw_u=incorrect,
                true_x_in_H_given_observation=true_inH, resampled_x_in_H_given_observation=fake_inH,
                shared_y_component=common, probability_shared_y_component=beta[0],
                y_in_H_when_shared=F(1),
                true_external_x_by_terminal_on_shared_y=exterior_amount,
                one_shared_x_charges_at_least_one=shared_union,
                one_shared_x_charges_all=count[-1],
                repeated_sum_across_terminals=repeated,
                shared_x_distribution_of_number_of_eligible_t=count)


def scenario(name, t_boxes, u_boxes, Hstarts, amplitude, old_z):
    source_measure=mass(SUPPORT,amplitude)
    assert source_measure==length(SUPPORT)
    all_parents = t_boxes+u_boxes
    true_owners = list(map(owner,all_parents))
    assert all(mass(A,amplitude)==length(A) for A in all_parents)
    assert all(a[1]<b[0] for a,b in zip(sorted(true_owners),sorted(true_owners)[1:]))
    t_sizes = [length(owner(A)) for A in t_boxes]
    u_sizes = [length(owner(A)) for A in u_boxes]
    neighbors = {}
    for i,j in product(range(len(t_boxes)),range(len(u_boxes))):
        shared = intersect(t_boxes[i],u_boxes[j])
        m = mass(shared,amplitude)
        if m:
            assert length(u_boxes[j]) < length(t_boxes[i])
            neighbors[i,j] = m/(length(t_boxes[i])*length(u_boxes[j])), shared
    d = [total(K*u_sizes[j] for (t,j),(K,_) in neighbors.items() if t==i)
         for i in range(len(t_boxes))]
    raw = {}
    for (t,u),(K,I) in neighbors.items():
        # This is the exact marginal of the ordered two-arm peak using the full allowed central degree.
        projected = total(t_sizes[t]*u_sizes[u]*u_sizes[v]*K*K2/d[t]
                          for (t0,v),(K2,_) in neighbors.items() if t0==t)
        assert projected == t_sizes[t]*u_sizes[u]*K
        raw[t,u] = projected,K,I
    raw_t = [total(r for (t,u),(r,_,_) in raw.items() if t==i) for i in range(len(t_boxes))]
    m_all = total(raw_t)
    weights = {tu:data[0]/m_all for tu,data in raw.items()}
    assert total(weights.values())==1
    assert all(Q>0 for Q in raw_t)
    menus = [interval(a,a+4) for a in Hstarts]
    assert all(mass(H,amplitude)==4 for H in menus)
    tested = [tally(t_boxes,u_boxes,weights,H,amplitude) for H in menus]
    states, by_t = tested[0]
    assert all(x>0 for x in states)
    atom_boxes, atom_mu = verify_physical_cells(t_boxes,u_boxes,weights,menus[0],amplitude,states)
    candidate_values = [row[0][0] for row in tested]
    terminal_specific = [[row[1][t][0] for row in tested] for t in range(len(t_boxes))]
    separate_low = total(min(opts) for opts in terminal_specific)
    separate_high = total(max(opts) for opts in terminal_specific)
    assert separate_low <= min(candidate_values) <= max(candidate_values) <= separate_high
    shared_test = shared_old(t_boxes,u_boxes,menus[0],amplitude,raw,raw_t,old_z)
    capacity = true_source_capacity(t_boxes,u_boxes,weights,menus[0],amplitude,atom_boxes,atom_mu)
    assert capacity["incorrectly_reset_per_t"]>capacity["paid_primal"]
    return dict(stage=name, amplitude=amplitude, terminal_parents=t_boxes, old_small_parents=u_boxes,
                compact_true_source_mass=source_measure, physical_owners=true_owners,
                fully_retained_d=d, total_original_branch_weight=m_all,
                branches=[dict(t=t,u=u,raw=r, normalized=weights[t,u], K=K, true_old_price_box=I,
                               old_intersection_mass=mass(I,amplitude))
                          for (t,u),(r,K,I) in raw.items()],
                shared_H=menus[0], input_H_same_true_mass=menus,
                true_outcome_shared_H=dict(zip(
                    ("both_in_H","y_in_H_x_escapes","y_escapes_x_in_H","both_escape",
                     "y_in_H_and_x_outside_H_and_terminal"),states)),
                independent_after_forgetting_branch_both_in_H=(states[0]+states[1])*(states[0]+states[2]),
                failure_by_common_H=candidate_values, failure_by_H_then_terminal=terminal_specific,
                common_H_best=min(candidate_values), common_H_worst=max(candidate_values),
                optimistically_select_H_per_t=separate_low,pessimistically_select_H_per_t=separate_high,
                shared_old_and_reused_fresh=shared_test, shared_external_capacity=capacity)


def suite():
    spread = [interval(F(i,4),F(i,4)+4) for i in range(6)]
    result = [
        scenario("initial",[interval(0,4),interval("3/2","11/2")],
                 [interval("-3/4","9/4"),interval("5/2","11/2")],
                 [F(0),F(3,2),F(-3,4),F(9,4)],F(1,4),interval("7/4",2)),
        scenario("low_overlap_reuse",spread[:3],
                 [interval("-7/4","3/4"),interval("13/4","21/4"),interval("9/8","25/8")],
                 [F(0),F(1,2),F(-1),F(3,2)],F(1,2),interval("1/2","3/4")),
        scenario("expanded",spread,
                 [interval(-2,"3/2"),interval(3,"13/2"),interval("9/8","25/8"),interval("-3/4","3/4")],
                 [F(0),F(5,4),F(-1),F(2)],F(3,4),interval("5/4","3/2")),
    ]
    assert any(s["optimistically_select_H_per_t"] < s["common_H_best"] or
               s["pessimistically_select_H_per_t"] > s["common_H_worst"] for s in result)
    return result


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    action=parser.add_mutually_exclusive_group()
    action.add_argument("--output",type=Path)
    action.add_argument("--check",type=Path)
    args=parser.parse_args()
    stages=suite()
    data=dict(runtime=dict(python=platform.python_version(),architecture=platform.machine()),
              precision="exact fractions throughout, standard library only",
              command="python -B alternate797.py --check alternate797.json",
              input=dict(source_support=SUPPORT, period=PERIOD, density="1±amplitude on alternating half periods",
                         genuine_receiving_owner="strictly disjoint centered intervals, each radius divided by 32",
                         perspective="conditional on the actual old terminal/leaf branch, old z, actual U, x and y use the indicated genuine conditional laws",
                         compared_H="all candidate occupied sets have exactly the same mu-mass within a stage",
                         scope="physical one-dimensional, finite unscreened original two-arm marginals; no near-extreme or high-dimensional masks"),
              stages=stages)
    text=json.dumps(data,indent=2,sort_keys=True,default=str)+"\n"
    if args.output:
        args.output.write_text(text)
    if args.check:
        assert args.check.read_text()==text
    if args.output or args.check:
        for c in stages:
            e=c["true_outcome_shared_H"]
            d=c["shared_external_capacity"]
            print(c["stage"], "inH",e["both_in_H"],"external rescue", e["y_in_H_and_x_outside_H_and_terminal"],
                  "shared/reset",d["paid_primal"],d["incorrectly_reset_per_t"])
        if args.check:
            print("byte-identical")
    else:
        print(text,end="")


if __name__=="__main__":
    main()
