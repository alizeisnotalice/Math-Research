#!/usr/bin/env python3
"""Public partition kernels on authentic two-dimensional price and owner geometry."""
import argparse
from fractions import Fraction as F
from itertools import product
import json
from pathlib import Path
import platform


N = 8
EPS = F(1, 16)
THETA = F(1, 2)
SQRT_CORE_SHRINK = 32


def total(xs):
    return sum(xs, F(0))


def square(x, y, side):
    x, y, side = F(x), F(y), F(side)
    return ((x,x+side),(y,y+side))


def area(box):
    result = F(1)
    for a,b in box:
        result *= max(F(0), b-a)
    return result


def clip(a,b):
    return tuple((max(u,p),min(v,q)) for (u,v),(p,q) in zip(a,b))


def contains(inside, outer):
    return all(a <= p <= q <= b for (p,q),(a,b) in zip(inside,outer))


def owner(box):
    return tuple(((lo+hi)/2-(hi-lo)/(2*SQRT_CORE_SHRINK),
                  (lo+hi)/2+(hi-lo)/(2*SQRT_CORE_SHRINK)) for lo,hi in box)


def atoms_on(lo,hi,breaks):
    a = sorted({lo,hi,*(x for x in breaks if lo < x < hi)})
    return list(zip(a,a[1:]))


def partition(xcuts,ycuts):
    return [((a,b),(c,d)) for (a,b),(c,d) in product(zip(xcuts,xcuts[1:]),zip(ycuts,ycuts[1:]))]


def dyadic(m):
    D = F(1)
    while m >= 2*D:
        D *= 2
    while m < D:
        D /= 2
    assert D <= m < 2*D
    return D


def source_patches():
    return [square(F(x)+F(1,2)-EPS, F(y)+F(1,2)-EPS,2*EPS)
            for x,y in product(range(N),repeat=2)]


def price_atoms(A,B,public,patches,extra=()):
    breaks = [set() for _ in range(2)]
    for box in A+B+list(extra)+[box for p in public.values() for box in p]:
        for q,ax in zip(breaks,box):
            q.update(ax)
    patch_density = 1/area(patches[0])
    atoms = []
    for p,box in enumerate(patches):
        physical = list(product(*(atoms_on(lo,hi,ends) for (lo,hi),ends in zip(box,breaks))))
        weighted = [area(q)*patch_density for q in physical]
        assert total(weighted)==1
        for q,w in zip(physical,weighted):
            a = tuple(t for t,P in enumerate(A) if contains(q,P))
            b = tuple(t for t,P in enumerate(B) if contains(q,P))
            assert set(b) <= set(a)
            atoms.append((p,q,w,a,b))
    return atoms


def patch_distances(patches, cutoff):
    near = []
    margin = None
    for p,q in product(patches,repeat=2):
        low = total(max(F(0),a-d,c-b) for (a,b),(c,d) in zip(p,q))
        high = total(max(abs(a-d),abs(b-c)) for (a,b),(c,d) in zip(p,q))
        assert 0 <= low <= high
        assert high < cutoff or low > cutoff
        near.append(high < cutoff)
        gap = cutoff-high if high < cutoff else low-cutoff
        margin = gap if margin is None else min(margin,gap)
    assert margin > 0
    return near, margin


def cell_groups(names, atoms):
    out={}
    for i,k in enumerate(names):
        out.setdefault(k,[]).append(atoms[i])
    assert sum(map(len,out.values()))==len(atoms)
    return out


def compute(groups, weights, bmass, bins, relations, near, patch_count, geometry=None, parents=None):
    ns = len(weights)
    row_t = [F(0)]*ns
    qualified = [F(0)]*ns
    near_t,far_t = [F(0)]*ns,[F(0)]*ns
    near_q,far_q = [F(0)]*ns,[F(0)]*ns
    b_ratios = [{} for _ in weights]
    full,partial,active,eq = F(0),F(0),0,0
    boundary_record = None
    for name, atoms in groups.items():
        v = total(a[2] for a in atoms)
        assert v > 0
        A = [F(0)]*ns
        B = [F(0)]*ns
        patch_A,patch_B = {},{}
        for p,box,m,a,b in atoms:
            for t in a:
                A[t] += m
                patch_A.setdefault(p,[F(0)]*ns)[t] += m
            for t in b:
                B[t] += m
                patch_B.setdefault(p,[F(0)]*ns)[t] += m

        support = [t for t in range(ns) if B[t]]
        constants = {t:weights[t]/(bmass[t]*v) for t in support}
        q = {t:v >= THETA*bins[t] for t in support}
        for t in support:
            b_ratios[t][str(name)] = B[t]/bmass[t]
            part = constants[t]*B[t]*A[t]
            assert 0 < B[t] <= A[t] <= v
            if geometry and contains(geometry[name],parents[t]):
                assert A[t]==v
            if A[t]==v:
                assert part==weights[t]*B[t]/bmass[t]
                full += part
            else:
                partial += part
                if boundary_record is None:
                    boundary_record = dict(t=t, group=str(name), mu_B=B[t],
                                           mu_A=A[t], mu_group=v, conditional=A[t]/v)
            row_t[t] += part
            if q[t]:
                qualified[t] += part
                active += 1
                eq += (v == THETA*bins[t])

        # Independent order: each true pair of physical price patches is
        # shared across all t whose source and target roles it can serve.
        for (i,left),(j,right) in product(patch_B.items(),patch_A.items()):
            is_near = near[i*patch_count+j]
            for t in support:
                term = constants[t]*left[t]*right[t]
                if is_near:
                    near_t[t] += term
                    if q[t]:
                        near_q[t] += term
                else:
                    far_t[t] += term
                    if q[t]:
                        far_q[t] += term

    assert all(n+f==row for n,f,row in zip(near_t,far_t,row_t))
    assert all(n+f==row for n,f,row in zip(near_q,far_q,qualified))
    assert full+partial==total(row_t)
    assert all(total(box.values())==1 for box in b_ratios)
    assert all(0 <= q <= h <= w for w,h,q in zip(weights,row_t,qualified))
    categories={}
    for i, relation in enumerate(relations):
        entry=categories.setdefault(relation,[F(0)]*4)
        for j,v in enumerate((near_t[i],far_t[i],near_q[i],far_q[i])):
            entry[j] += v
    assert total(x[0]+x[1] for x in categories.values())==total(row_t)
    return dict(total=total(row_t), qualified=total(qualified), true_near=total(near_t),true_far=total(far_t),
                qualified_near=total(near_q), qualified_far=total(far_q), by_t=row_t, qualified_by_t=qualified,
                by_scale_category=categories, full=full, partial=partial, boundary_witness=boundary_record,
                qualifying_terminal_cell_count=active, threshold_equal_terminal_cell_count=eq,
                source_group_fractions=b_ratios, group_count=len(groups))



def top_price_integral(scores, atoms, capacity):
    """Exact continuous fractional knapsack, with zero payoff for unused capacity."""
    assert capacity>0 and all(v>=0 for v in scores)
    order=sorted(range(len(atoms)),key=lambda j:(-scores[j],j))
    remaining=capacity
    value=F(0)
    partial=None
    for j in order:
        _,box,m,_,_=atoms[j]
        used=min(m,remaining)
        value+=scores[j]*used
        remaining-=used
        if 0<used<m:
            # The physical mu density is constant on the actual atom.
            (a,b),other=box
            slab=((a,a+(b-a)*used/m),other)
            assert area(slab)==area(box)*used/m
            assert area(slab)/((2*EPS)**2)==used
            partial=dict(atom=j, score=scores[j], used_mu=used, full_atom_mu=m, source_slab=slab)
        if not remaining:
            break
    levels=sorted({F(0),*scores})
    dual,threshold=min((capacity*q+total(m*max(F(0),p-q) for p,(_,_,m,_,_) in zip(scores,atoms)),q)
                       for q in levels)
    assert value==dual
    return value,dict(threshold=threshold,physical_partial_cell=partial,zero_mass_slack=remaining)


def posterior_diagnostic(A,U,B,public,patches,weights,bmass,bins):
    atoms=price_atoms(A,B,public,patches,extra=U)
    total_mu=total(r[2] for r in atoms)
    beta=F(9,10)
    source_rows={}
    for p,box,m,parents,sources in atoms:
        for D in sorted({bins[t] for t in sources}):
            labels=tuple(t for t in sources if bins[t]==D)
            n,mass=source_rows.get((D,labels),(0,F(0)))
            source_rows[D,labels]=n+1,mass+m

    def indicator(family):
        return [F(any(contains(atom[1],box) for box in family)) for atom in atoms]

    tests={f"A{t}":indicator([box]) for t,box in enumerate(A)}
    tests.update({f"U{u}":indicator([box]) for u,box in enumerate(U)})
    tests["two_quadrants_union"]=indicator(public["quadrants"][::3])
    tests["three_public_columns_union"]=indicator(public["inner_strips"][:3])
    tests["overlapping_parents_union"]=indicator(A[:2])
    tests["true_soft_source_reuse"]=[total(weights[t]/bmass[t] for t in r[4]) for r in atoms]
    tests["overlapping_soft_terminal_load"]=[
        total(weights[t] for t in atom[3])+F(1,3)*tests["two_quadrants_union"][j]
        for j,atom in enumerate(atoms)
    ]
    assert total(m*g for (_,_,m,_,_),g in zip(atoms,tests["true_soft_source_reuse"]))==1
    assert any(len(z[4])>1 for z in atoms)

    def calculate(theta, inspect_loads):
        weighted,kept,mass_kept=F(0),F(0),F(0)
        mass_above=F(0)
        rows=[]
        total_row_weight=F(0)
        for (D,labels),(count,source_mass) in sorted(source_rows.items()):
            h=total(weights[t]/bmass[t] for t in labels)
            source_weight=h*source_mass
            total_row_weight+=source_weight
            posterior={t:weights[t]/(bmass[t]*h) for t in labels}
            assert total(posterior.values())==1
            scores=[total(v for t,v in posterior.items() if t in active) for _,_,_,active,_ in atoms]
            assert all(0<=p<=1 for p in scores)
            capacity=theta*D
            raw_top,proof=top_price_integral(scores,atoms,capacity)
            hit=raw_top/capacity
            dual=proof["threshold"]+total(
                m*max(F(0),p-proof["threshold"]) for p,(_,_,m,_,_) in zip(scores,atoms))/capacity
            assert 0<=hit==dual<=1
            weighted+=source_weight*hit
            keep=hit<=beta
            load_results=None
            if keep:
                mass_kept+=source_weight
                kept+=source_weight*hit
                excess=[max(F(0),p-beta) for p in scores]
                assert all(0<=e<=1 for e in excess)
                assert total(m for p,(_,_,m,_,_) in zip(scores,atoms) if p>beta)<=capacity
                positive_excess=total(m*e for e,(_,_,m,_,_) in zip(excess,atoms))
                assert positive_excess<=beta*capacity
                if inspect_loads:
                    load_results={}
                    for name,g in tests.items():
                        true_integral=total(p*v*r[2] for p,v,r in zip(scores,g,atoms))
                        through_parents=total(prob*total(v*r[2] for v,r in zip(g,atoms) if t in r[3])
                                              for t,prob in posterior.items())
                        assert true_integral==through_parents
                        baseline=beta*total(v*r[2] for v,r in zip(g,atoms))
                        tail,tail_proof=top_price_integral(g,atoms,beta*capacity)
                        excess_cost=total(e*v*r[2] for e,v,r in zip(excess,g,atoms))
                        assert true_integral<=baseline+excess_cost<=baseline+tail
                        load_results[name]=dict(original_conditional_integral=true_integral,
                                                beta_base=baseline, excess_integral=excess_cost,
                                                top_mass_beta_c=beta*capacity, top_price_integral=tail,
                                                exact_upper=baseline+tail,
                                                physical_partial_cell=tail_proof["physical_partial_cell"])
            else:
                mass_above+=source_weight
            if inspect_loads:
                rows.append(dict(absolute_D=D, identical_profile_source_atom_count=count,
                                 true_source_mass=source_mass,row_density_h=h,weighted_row_mass=source_weight,
                                 t_posterior=posterior,capacity=capacity,hit_optimal=hit,
                                 hit_dual=dual,threshold_proof=proof,retained=keep,
                                 excess_source_mass=positive_excess if keep else None,
                                 load_tests=load_results))
        assert total_row_weight==1==mass_kept+mass_above and 0<=kept<=weighted
        return dict(theta=theta,beta=beta,optimal_weighted_total=weighted,retained_row_mass=mass_kept,
                    removed_row_mass=mass_above,optimal_weighted_retained=kept,
                    optimal_weighted_loss=weighted-kept,weighted_optimal_share_retained=kept/weighted,
                    cutoff="retain s<=beta",rows=rows)

    main=calculate(F(1),True)
    smaller=calculate(F(1,2),False)
    assert 0<main["retained_row_mass"]<1
    assert any(r["retained"] for r in main["rows"])
    # One strictly fractional physical last cell and one shortage of physical mu.
    witness=next(row for row in main["rows"] if row["retained"])
    active=witness["t_posterior"]
    scores=[total(prob for t,prob in active.items() if t in a[3]) for a in atoms]
    fractional_capacity=witness["capacity"]+F(1,37)
    fv,fc=top_price_integral(scores,atoms,fractional_capacity)
    assert fc["physical_partial_cell"] is not None and fc["physical_partial_cell"]["score"]>0
    shortage_capacity=2*total_mu
    zv,zc=top_price_integral(scores,atoms,shortage_capacity)
    assert zc["zero_mass_slack"]==total_mu and zc["threshold"]==0
    assert zv==total(p*r[2] for p,r in zip(scores,atoms))
    return dict(primary=main,half_capacity_comparison=smaller,posterior_source_atom_count=len(atoms),
                fractional_probe=dict(capacity=fractional_capacity, source_top_integral=fv,
                                      proof=fc),
                zero_fill_probe=dict(capacity=shortage_capacity,actual_mu=total_mu,
                                     optimum_hit=zv/shortage_capacity,proof=zc),
                load_budget="For retained s<=beta, integrate p*g <= beta*integral g + integral_0^(beta*theta*D) g_star(a) da. Last integral is unnormalized.")


def actual_input(name, td, ud, assigning, cutoff):
    A = [square(*x) for x in td]
    U = [square(*x) for x in ud]
    B = [clip(x,U[u]) for x,u in zip(A,assigning)]
    patches = source_patches()
    density = 1/area(patches[0])

    def mu(box):
        return density*total(area(clip(box,p)) for p in patches)

    world = square(0,0,N)
    assert all(contains(x,world) for x in A+U)
    assert all(mu(x)==area(x) for x in A+U)
    owners = list(map(owner,A+U))
    assert all(area(clip(p,q))==0 for i,p in enumerate(owners) for q in owners[i+1:])
    bmass = list(map(mu,B))
    assert min(bmass)>0
    weights_raw = []
    degrees=[]
    for i,C in enumerate(A):
        chosen = assigning[i]
        neighbors = {j:mu(clip(C,D))/(area(C)*area(D)) for j,D in enumerate(U) if area(D)<area(C)}
        d = total(v*area(owners[len(A)+i]) for i,v in neighbors.items())
        assert d>0 and neighbors[chosen]>0
        degrees.append(d)
        selected = neighbors[chosen]*area(owners[len(A)+chosen])
        raw_weight = total(area(owners[i])*selected*v*area(owners[len(A)+j])/d
                           for j,v in neighbors.items())
        assert raw_weight==area(owners[i])*selected
        weights_raw.append(raw_weight)
    weights = [w/total(weights_raw) for w in weights_raw]
    bins = list(map(dyadic,map(area,A)))
    ubins = [dyadic(area(U[i])) for i in assigning]
    relations = [f"D={a};U={u};{'same' if a==u else 'cross'}" for a,u in zip(bins,ubins)]

    public = dict(vertical=partition([0,2,4,6,8],[0,8]),
                  horizontal=partition([0,8],[0,2,4,6,8]),
                  quadrants=partition([0,4,8],[0,4,8]),
                  corner=partition([0,1,8],[0,1,8]),
                  tail_columns=partition([0,5,6,7,8],[0,8]),
                  inner_strips=partition([0,F(5,2)-F(1,64),F(5,2)+F(1,64),5,8],[0,8]))
    records = price_atoms(A,B,public,patches)
    assert total(x[2] for x in records)==N*N
    assert [total(r[2] for r in records if i in r[4]) for i in range(len(B))]==bmass
    near,margin=patch_distances(patches,cutoff)
    checks = {}
    for tag,rect in public.items():
        groups=[]
        for price in records:
            member=[j for j,p in enumerate(rect) if contains(price[1],p)]
            assert len(member)==1
            groups+=member
        mapped=cell_groups(groups,records)
        assert len(mapped)==4
        # Kernel is row-normalized and symmetric with respect to the true
        # source on every group. The public mixture preserves the same mu.
        for g in mapped.values():
            den=total(r[2] for r in g)
            assert total(r[2]/den for r in g)==1
        checks[tag]=compute(mapped,weights,bmass,bins,relations,near,len(patches),rect,A)

    members=cell_groups([r[3] for r in records],records)
    fine=compute(members,weights,bmass,bins,relations,near,len(patches))
    assert fine["total"]==fine["full"]==1 and not fine["partial"]
    microscopic=compute(cell_groups(range(len(records)),records),weights,bmass,bins,relations,near,len(patches))
    assert microscopic["total"]==microscopic["full"]==1 and microscopic["qualified"]==0
    assert any(x["partial"] and 0<x["qualified"]<x["total"] for x in checks.values())
    assert all(x["true_near"]>0 and x["true_far"]>0 for x in checks.values())

    mixture=[F(1,len(public))]*len(public)
    assert total(mixture)==1
    mix_total=total(w*p["total"] for w,p in zip(mixture,checks.values()))
    mix_qualified=total(w*p["qualified"] for w,p in zip(mixture,checks.values()))
    listed=list(checks)
    winners=[max(listed,key=lambda tag:checks[tag]["by_t"][i]) for i in range(len(A))]
    gated_winners=[max(listed,key=lambda tag:checks[tag]["qualified_by_t"][i]) for i in range(len(A))]
    private=total(checks[tag]["by_t"][i] for i,tag in enumerate(winners))
    private_q=total(checks[tag]["qualified_by_t"][i] for i,tag in enumerate(gated_winners))
    public_best=max(p["total"] for p in checks.values())
    public_best_q=max(p["qualified"] for p in checks.values())
    assert mix_total<=public_best<=private<=1 and mix_qualified<=public_best_q<=private_q<=1
    assert total(P["total"] for P in checks.values())==mix_total*len(checks)
    info=dict(stage=name, terminal_parents=A, old_source_parents=U,selected_actual_old_sources=assigning,
              price_source_B=B, actual_all_neighbor_d=degrees, true_source_B_mass=bmass,
              original_branch_weights=weights_raw, normalized_weights=weights, absolute_D=bins,
              old_absolute_D=ubins, source_l1_threshold=cutoff, strict_near_far_margin=margin,
              public_input=public, source_patch_count=len(patches), actual_price_atom_count=len(records),
              public=checks, fine_geometric_membership=fine, fine_physical_atoms=microscopic,
              mixture_weights=mixture, public_mix_total=mix_total, public_mix_qualified=mix_qualified,
              public_best=public_best,public_best_qualified=public_best_q,
              individual_winners=winners, gated_individual_winners=gated_winners,
              private_best=private,private_best_qualified=private_q,
              capped_posterior=posterior_diagnostic(A,U,B,public,patches,weights,bmass,bins))
    if name=="expanded":
        t=4
        dispersion=checks["tail_columns"]["source_group_fractions"][t]
        overlap=total(r[2] for r in records if t in r[4] and len(r[4])>1)/bmass[t]
        assert len(dispersion)==4 and max(dispersion.values())==F(2,7) and overlap==F(1,49)
        assert private>public_best and len(set(bins))>=2 and any(a==b for a,b in zip(bins,ubins))
        info["wide_weak_reuse_witness"]=dict(terminal=t,source_m=bmass[t],source_partition_fractions=dispersion,
                                         largest=max(dispersion.values()),source_overlap_with_other_B=overlap)
    return info


def suite():
    pressure=[(1,1,3),("3/2","3/2","7/2"),("7/2","3/2","5/2"),("5/2",3,"5/2")]
    old=[(2,"3/2",2),(2,2,3),("7/2","7/2","3/2")]
    choose=[0,1,0,2]
    return [
      actual_input("initial",[(0,0,2),(1,"1/2",2)],[("1/2","1/2","3/2")],[0,0],F(3,2)),
      actual_input("pressure",pressure,old,choose,F(3,2)),
      actual_input("expanded",pressure+[(4,4,4),(0,4,3)],
                   old+[("9/2","9/2","7/2"),("1/2","9/2","5/2")],choose+[3,4],F(5,2)),
    ]


def main():
    p=argparse.ArgumentParser(description=__doc__)
    cli=p.add_mutually_exclusive_group()
    cli.add_argument("--output",type=Path)
    cli.add_argument("--check",type=Path)
    args=p.parse_args()
    stages=suite()
    data=dict(runtime=dict(python=platform.python_version(),architecture=platform.machine()),
              precision="standard library Fraction",
              command="python -B cells797.py --check cells797.json",
              input=dict(world=square(0,0,N), source_patch_halfside=EPS, patch_density=1/(2*EPS)**2,
                 nonzero_only_on_patches="8-by-8 disjoint patches, unit mass per patch; boundaries have zero mass",
                 threshold_theta=THETA, threshold="mu(P_a)>=theta D_t, D_t dyadic floor of m_t",
                 diagnostic_scope="true two-dimensional parents, sources, and disjoint receiving cores; old two-arm diagnostic with all physically allowed smaller source neighbors, no high-dimensional masks"),
              stages=stages)
    encoded=json.dumps(data,indent=2,sort_keys=True,default=str)+"\n"
    if args.output:
        args.output.write_text(encoded)
    if args.check:
        assert args.check.read_text()==encoded
    if args.output or args.check:
        for x in stages:
            print(x["stage"],"public",x["public_best"],"mix",x["public_mix_total"],"private",x["private_best"],
                  "gated",x["public_best_qualified"],x["private_best_qualified"],
                  "gated_geom_member",x["fine_geometric_membership"]["qualified"])
            main=x["capped_posterior"]["primary"]
            print("  capped posterior",main["optimal_weighted_total"],"row mass retained",
                  main["retained_row_mass"],"optimal kept",main["optimal_weighted_retained"])
        if args.check:
            print("byte-identical")
    else:
        print(encoded,end="")


if __name__=="__main__":
    main()
