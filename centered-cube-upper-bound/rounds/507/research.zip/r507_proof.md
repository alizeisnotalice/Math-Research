# R507：同一后验 anchor 的逐坐标质量分裂与完整来源列

保原 \(\mu=f\,dx\)、实际 \(Q_A=Q(A,R_A)\)、\(m_A=\mu(Q_A)=q_AR_A^n\)、\(q\le q_A\le\lambda\)、\(a\le R_A\le b\le2a\)，以及 \(\nu(dA)=t(A)q_A\,dA\)、\(0\le t\le S\)。记 \(W=\mu(\mathbb R^n)\)、\(A_n=1+n\log(b/a)\)。所有 anchor 使用原 \(\pi_A=1_{Q_A}\mu/m_A\)，不在中途重抽条件来源，不给辅助矩形迁移 history。

本稿证明实际质量分裂、有限斜率熵及来源列的完整联合账。它避免按坐标重复支付同一来源，但只得到旧 \(O(nW)\) 的全来源包络；尚未把完整收缩损失降为根阶。

## 1. 精确两点阈值与首次失捕

固定 \(0<\delta<1\)、\(c=1-\delta\)，anchor \(x\sim\pi_A\)，另取原 \(z\sim\pi_A\)。令 \(u_i=2(z_i-A_i)/R_A\)、\(v_i=2(x_i-A_i)/R_A\)。同心坐标表达给
\[
z\in Q_\delta(A,x):=x+c(Q_A-x)
\iff \delta\le\min_i\left\{
\frac{1-u_i}{1-v_i},\frac{1+u_i}{1+v_i}\right\}.\tag{1}
\]
分母零时对应原不等式为 \(0\le1\mp u_i\)，不施限制，比例取 \(+\infty\)，包括 \(0/0\)。实际来源在盒边界的质量为零，但无需靠此删除端点。

按固定坐标顺序令 \(Q_j(A,x)\) 只收缩前 \(j\) 个坐标，\(Q_0=Q_A\)、\(Q_n=Q_\delta\)。这些是真实嵌套矩形，剥离条带
\(D_j(A,x)=Q_{j-1}(A,x)\setminus Q_j(A,x)\) 互不相交。于是
\[
1_{z\notin Q_n}=\sum_{j=1}^n1_{z\in D_j},\qquad
1-\pi_A(Q_n)=\sum_j\frac{\mu(D_j)}{m_A}.\tag{2}
\]
这里没有将坐标事件概率相乘；\(f\) 可任意相关。也没有逐 pair 重选坐标顺序。

## 2. 实际质量、平均密度与有限斜率熵

定义
\[
V_j=R_A^n c^j,\quad m_j=\mu(Q_j),\quad g_j=m_j/V_j,
\quad h_j=\frac{\mu(D_j)}{\delta V_{j-1}}.
\]
原 \(g_0=q_A\)。完整分母与真实体积给出准确二分式
\[
g_{j-1}=c g_j+\delta h_j.\tag{3}
\]
这里 \(g_j\) 或 \(h_j\) 没有新的 qband 保证；不能把它们当作原接收者。

取凸 \(F\) 满足 \(F(0)=0\)、\(0\le F'_+\le L_F<\infty\)，并记其 Bregman 差 \(D_F\)。例如可用 R505 的输出带熵，\(L_F=\log(2\lambda/q)\)。其他有限斜率凸函数只有在减去合法仿射项后满足这些条件时才套用；Jensen 差不受该仿射归一影响。由 (3)，
\[
\begin{aligned}
&\sum_{j=1}^n c^{j-1}
\left[cD_F(g_j,g_{j-1})+\delta D_F(h_j,g_{j-1})\right]\\
&\quad=c^nF(g_n)+\sum_{j=1}^n\delta c^{j-1}F(h_j)-F(g_0)
\le L_Fg_0-F(g_0).\tag{4}
\end{aligned}
\]
这是逐步 Jensen 差乘真实存活体积 \(c^{j-1}\) 后的望远镜；等式中的条带费用不可漏。上界使用完整来源守恒
\(c^ng_n+\sum_j\delta c^{j-1}h_j=g_0\)。零质量子块合法，未使用对数质量或无穷熵。

原待控制损失则是另一项，准确为
\[
\begin{aligned}
\mathcal L_\delta
&:=\int\nu(dA)\mathbb E_{x\sim\pi_A}[1-\pi_A(Q_n(A,x))]\\
&=\int_Et(A)\,dA\int\pi_A(dx)[g_0-c^ng_n]\\
&=(1-c^n)R_\tau+c^n\int_Et(A)\,dA\int\pi_A(dx)[g_0-g_n].\tag{5}
\end{aligned}
\]
第二项有符号，不可只收其正部后声称保留抵消。第一项是体积收缩的完整基项；即使 \(g_j=h_j=g_0\) 导致 (4) 的熵完全为零，(5) 仍有 \((1-c^n)R_\tau\)。故有限斜率熵不能单独替代完整捕获损失。\(g_n\le c^{-n}g_0\) 保证此处的有限输入下无 \(\infty-\infty\)。\(\delta=0\) 为零损失的平凡端点；本稿不在 \(\delta=1\) 的零体积盒上定义 \(g_n\)。

## 3. 保原 anchor 后验的真实来源列与总价

将 (2) 乘原 \(\nu\)，并先积分被捕获来源 \(z\)，得到
\[
\mathcal L_\delta=\int\mu(dz)\int_E
\frac{t(A)1_{Q_A}(z)}{R_A^n}
\int\pi_A(dx)\sum_j1_{D_j(A,x)}(z)\,dA.\tag{6}
\]
\(\pi_A(dx)\) 中仍是原 \(m_A\)，没有变成各 \(m_j\)。条带首次失捕使内和至多1；加入最后核心 \(1_{Q_n}\) 后恰等于1。因此完整来源列——核心与所有条带合计——准确为
\[
\int_E\frac{t(A)1_{Q_A}(z)}{R_A^n}\,dA
\le S A_n.\tag{7}
\]
这是实际中心单 octave 包络，没有按 \(n\) 个条带分别再付该上界。其对 \(\mu\) 的积分准确等于 \(R_\tau\)。

同样，把 (4) 按 \(t(A)dA\,\pi_A(dx)\) 积分，真正累计分裂熵满足
\[
0\le\mathfrak D_F
\le L_FR_\tau-\int_Et(A)F(q_A)\,dA
\le L_F S A_nW.\tag{8}
\]
原基底是 \(t\,dA\,\pi_A\)，不是 \(\nu\pi_A\) 下又多乘一份 \(q_A\)。式 (8) 相比把每坐标单独估成 \(O(A_nW)\)，确实避免额外的坐标重数，但尚非根阶来源价；也不能把其乘回一个免费的逆存活权。

若要用 (4) 推进 (5)，必须把有符号密度修正与真实体积基项在**同一个原来源列**下结算，或者证明 (6) 的实际首次失捕概率在该列上有额外平均节省。当前仅用质量守恒、凸性及 (7) 不能做到：舍去该概率后得到的是原 \(R_\tau\) 本身，保留熵又不含体积基项。这是本路线具体未证的一步，不把 \(\mathfrak D_F\) 重新命名成完整损失的价格。

若另引随机 \(\delta\)，(1) 给准确保留概率 \(\mathbb P(\delta\le\delta_*(A,x,z))\)，须按明确分布积分 (4)–(6)；不能据此恢复某个固定 \(\delta\) 的完整损失而删除相应逆权。本稿没有采用随机 \(\delta\) 或更新 anchor 的辅助过程。

## 4. 本机真实局部质量核验

完整来源取 \(f(u,v)=(1+uv/2)1_{[-1,1]^2}\)，不是乘积密度；\(m_0=4\)、\(g_0=1\)。使用原后验 \(f/4\) 的 anchor，\(\delta=1/3\)。对每个 anchor \(x\)，\(g_1=1\)、\(g_2=1+\delta^2x_1x_2/2\)。实际平均损失为 \(404/729\)，体积基项为 \(5/9\)，有符号修正为 \(-1/729\)。对在这些密度值上等于 \(s^2\)、超过2后线性延伸的有限斜率凸 \(F\)，平均累计分裂熵为 \(1/2187\)。这保留了真实原后验的相关项，不把 anchor 改为均匀点。

下面代码实际运行：有限点仅检查每个 anchor 的矩形身份；最后两项对完整连续 anchor 后验作符号积分。它不声称实现正中心场的原 history；一般中心积分由前述解析证明给出。

```python
from fractions import Fraction as F
import sympy as s
c=F(2,3);delta=1-c
Q=[(F(-1),F(1)),(F(-1),F(1))]
def mass(box):
    (a,b),(d,e)=box
    return (b-a)*(e-d)+(b*b-a*a)*(e*e-d*d)/8
checks=0
for x in [(F(1,4),F(-1,4)),(F(3,4),F(1,2)),(F(0),F(0))]:
    box=list(Q);prev=mass(box);gprev=prev/4
    entropy=F(0);loss=F(0);stripFs=F(0)
    for j in range(1,3):
        box[j-1]=(delta*x[j-1]-c,delta*x[j-1]+c)
        m=mass(box);g=m/(4*c**j)
        h=(prev-m)/(delta*4*c**(j-1))
        assert gprev==c*g+delta*h;checks+=1
        entropy+=c**(j-1)*(c*(g-gprev)**2+delta*(h-gprev)**2)
        stripFs+=delta*c**(j-1)*h*h
        loss+=(prev-m)/4
        prev=m;gprev=g
    assert entropy==c*c*g*g+stripFs-1;checks+=1
    assert loss==(1-c*c)+c*c*(1-g);checks+=1
    for z in [(F(-3,4),F(1,2)),(F(1,4),F(-1,4)),(F(3,4),F(3,4))]:
        thresh=min(min((1-z[i])/(1-x[i]),(1+z[i])/(1+x[i])) for i in range(2))
        flags=[box[i][0]<=z[i]<=box[i][1] for i in range(2)]
        assert all(flags)==(delta<=thresh);checks+=1
        assert (not all(flags))==((not flags[0])+(flags[0] and not flags[1]));checks+=1
u,v=s.symbols('u v',real=True)
d=s.Rational(1,3);cc=1-d
f=1+u*v/2;g2=1+d*d*u*v/2
avg=lambda expr:s.integrate(expr*f/4,(u,-1,1),(v,-1,1))
assert avg(1-cc**2*g2)==s.Rational(404,729);checks+=1
assert avg(cc**2*d**3*u*u*v*v/4)==s.Rational(1,2187);checks+=1
print(f'{checks} exact mass/threshold/posterior assertions PASS')
print('average loss=404/729; volume baseline=5/9; signed correction=-1/729')
print('finite-slope quadratic split entropy=1/2187')
```

实际 stdout：

```text
32 exact mass/threshold/posterior assertions PASS
average loss=404/729; volume baseline=5/9; signed correction=-1/729
finite-slope quadratic split entropy=1/2187
```

结论：同 anchor 的真实坐标分裂可一次结清全部条带，且保留负密度修正；但当前总来源列仍只有 \(SA_n\) 帽。尚未证明式 (5) 或 (6) 的根阶预算，未新增原母账付款。
