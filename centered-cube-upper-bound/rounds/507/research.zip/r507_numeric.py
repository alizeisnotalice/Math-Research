#!/usr/bin/env python3
"""Exact continuous corner-source contraction diagnostic, no history claim."""
from fractions import Fraction as F
from pathlib import Path
import itertools,json,sys,platform,time
import sympy as sp
import flint
from flint import arb,ctx
ctx.prec=256
ROOT=Path(__file__).resolve().parent
checks=0

def ck(x):
 global checks
 assert bool(x)
 checks+=1

def aa(x):
 x=F(x);return arb(x.numerator)/x.denominator

def info(x):return {'fraction':str(x),'arb':str(aa(x))}

def cdf3(t,lengths):
 total=F(0)
 for bits in itertools.product([0,1],repeat=3):
  shift=sum((b*l for b,l in zip(bits,lengths)),F(0))
  total+=(-1)**sum(bits)*max(F(0),t-shift)**3
 return total/(6*lengths[0]*lengths[1]*lengths[2])

def cdf2(t,a,b):
 return (max(F(0),t)**2-max(F(0),t-a)**2-max(F(0),t-b)**2+max(F(0),t-a-b)**2)/(2*a*b)

def cdf3_integral(t,lengths):
 # Independent integration of 2-uniform CDF over third coordinate;
 # Simpson is exact on each quadratic polynomial segment.
 a,b,c=lengths
 points=sorted({F(0),c,*[w for w in [t,t-a,t-b,t-a-b] if 0<w<c]})
 total=F(0)
 for lo,hi in zip(points,points[1:]):
  mid=(lo+hi)/2
  total+=(hi-lo)*(cdf2(t-lo,a,b)+4*cdf2(t-mid,a,b)+cdf2(t-hi,a,b))/6
 return total/c

def capture(delta,h,eta,xsign,zsign):
 # Corner interval lower/upper endpoints, labels -/+.
 xl,xu=(F(-1,2),F(-1,2)+h) if xsign==0 else (F(1,2)-h,F(1,2))
 zl,zu=(F(-1,2),F(-1,2)+h) if zsign==0 else (F(1,2)-h,F(1,2))
 lengths=[h,delta*h,2*(1-delta)*eta]
 minimum=zl-delta*xu-(1-delta)*eta
 R=1+2*eta;bound=(1-delta)*R/2
 upper=bound-minimum;lower=-bound-minimum
 a=cdf3(upper,lengths)-cdf3(lower,lengths)
 b=cdf3_integral(upper,lengths)-cdf3_integral(lower,lengths)
 ck(a==b);ck(0<=a<=1)
 ck(cdf3(F(0),lengths)==0 and cdf3(sum(lengths),lengths)==1)
 return a

def labels(n):
 raw=[(tuple([0]*n),1),(tuple([1]*n),2),(tuple(i%2 for i in range(n)),3),(tuple(1-i%2 for i in range(n)),5)]
 out={}
 for x,w in raw:out[x]=out.get(x,F(0))+F(w,11)
 return out

def main():
 start=time.perf_counter()
 # Symbolic normalization and cubic positive-part primitive for three uniforms.
 t,a,b,c=sp.symbols('t a b c',positive=True)
 cubic=sum((-1)**sum(bits)*(t-sum(bit*l for bit,l in zip(bits,[a,b,c])))**3 for bits in itertools.product([0,1],repeat=3))/(6*a*b*c)
 ck(sp.expand(cubic)==1)
 ck(sp.integrate(t*t/2,t)==t**3/6)
 # Tensor pair formula from independent label draw.
 s,o=sp.symbols('s o')
 ck(sp.expand((s*s+2*s*o+o*o)/4-(s+o)**2/4)==0)
 cases=[]
 for n in [1,2,8,32]:
  for delta in [F(1,4*(n+1)),F(1,n+1)]:
   for htag,h in [('1/8',F(1,8)),('delta^2/16',delta*delta/16)]:
    eta=h/4;R=1+2*eta
    ck(0<delta<1 and 0<h<=F(1,4))
    # All real receivers, not just representative centers, capture entire source box.
    ck(eta-R/2==F(-1,2) and -eta+R/2==F(1,2))
    cs=capture(delta,h,eta,0,0);co=capture(delta,h,eta,0,1)
    ck(cs==capture(delta,h,eta,1,1))
    ck(co==capture(delta,h,eta,1,0))
    if delta<=F(1,3):ck(cs==1-delta*delta/(3*(1-delta)))
    if htag=='delta^2/16':ck(delta-h*(3+delta)/2>0 and co==0)
    vol=(2*eta)**n;q=R**(-n);Rtau=vol*q
    ck(Rtau==(h/(2+h))**n)
    law=labels(n);ck(sum(law.values())==1)
    correlated=sum((w1*w2*cs**(n-sum(a!=b for a,b in zip(l1,l2)))*co**sum(a!=b for a,b in zip(l1,l2)) for l1,w1 in law.items() for l2,w2 in law.items()),F(0))
    uniform=((cs+co)/2)**n;opposite=(cs**n+co**n)/2
    laws=[]
    for name,cap in [('all_uniform_corners',uniform),('two_opposite_equal',opposite),('correlated_four_labels',correlated)]:
     ck(0<=cap<=1)
     loss=1-cap;full=loss*Rtau
     ck(0<=full<=Rtau)
     laws.append({'law':name,'capture':info(cap),'L_over_Rtau':info(loss),'L_over_W':info(full)})
    cases.append({'phase':('initial' if n==1 else ('boundary/shrinking-h pressure' if n==2 else 'expanded_dimension')),'n':n,'delta':str(delta),'h_formula':htag,'h':str(h),'eta':str(eta),'R':str(R),'q_B':str(q),'t':'1','W':'1','receiver_Lebesgue_volume':info(vol),'Rtau':info(Rtau),'c_same':info(cs),'c_opposite':info(co),'correlated_labels':[{'bits':''.join(map(str,l)),'weight':str(w)} for l,w in law.items()],'pair_laws':laws})
 out={'scope':'actual continuous L1 corner boxes and full positive Lebesgue receiver cube; static conditional pair contraction only; no original rank/history/firstcross','environment':{'executable':sys.executable,'python':platform.python_version(),'sympy':sp.__version__,'python_flint':flint.__version__,'arb_precision_bits':ctx.prec},'command':f'{sys.executable} r507_numeric.py','checks':checks,'count_meaning':'3 symbolic identities +16 configurations x24 exact guards +14 small-delta same-corner identities +8 strict opposite-exclusion margins; configurations/laws not counted as general proof','one_coordinate_formula':'P=z-delta*x-(1-delta)B = minimum+sum Uniform[0,length_i]; lengths=(h,delta*h,2(1-delta)eta); CDF=1/(6prodlength) sum_subset(-1)^size(t-sumlength)_+^3','independent_verification':'integrate 2-uniform CDF piecewise quadratic by exact Fraction Simpson; both tails independently checked','source_definition':'mixture uniform on corner boxes of side h; each law mass sums1; q_B=R^-n since all full source is captured','cases':cases,'compute_index':{'seconds':time.perf_counter()-start}}
 (ROOT/'r507_numeric.json').write_text(json.dumps(out,indent=2)+'\n')
 print(f'PASS {checks} exact assertions;16 continuous geometries x3 source laws;true receiver volume retained;static-only')
 for case in cases:
  print(case['n'],case['delta'],case['h_formula'],'same',float(F(case['c_same']['fraction'])),'opposite',float(F(case['c_opposite']['fraction'])),'loss ratios',[round(float(F(z['L_over_Rtau']['fraction'])),8) for z in case['pair_laws']])
if __name__=='__main__':main()
