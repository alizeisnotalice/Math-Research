import sympy as s

c,R,m,mp=s.symbols('c R m mp',positive=True)
checks=0
for n in [1,2,3]:
    B=s.symbols(f'B0:{n}')
    x=s.symbols(f'x0:{n}')
    image=s.Matrix([c*B[i]+(1-c)*x[i] for i in range(n)])
    assert s.simplify(image.jacobian(B).det()-c**n)==0
    checks+=1
assert s.simplify(c**(-2)*R**(-2)-(c*R)**(-2))==0
checks+=1
assert s.simplify((mp/m)/((c*R)**2*mp)-1/((c*R)**2*m))==0
checks+=1
B,x,y=s.symbols('B x y')
assert s.expand((x+c*(y-x))-(x+c*(B-x))-c*(y-B))==0
checks+=1
print(f'PASS {checks} exact affine-Jacobian, normalization and retained-pair identities; no source-loss bound or history certificate')
