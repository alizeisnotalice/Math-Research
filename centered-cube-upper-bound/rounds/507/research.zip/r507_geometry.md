# R507：固定质量锚点变换、两笔原接收分支费用与剩余层间费用

本附件保留完整来源 \(d\mu=f\,dx\)、\(f\ge0\)、\(W<\infty\)。原中心选择器满足
\[
 a\le R_B\le b\le2a,\quad m_B=\mu(Q(B,R_B))=q_BR_B^n,
 \quad q\le q_B\le\lambda,\quad d\nu=tq_B\,dB,\quad 0\le t\le S.
\]
记 \(R_\tau=\nu(E)\)、\(r=\lambda/q\)、\(A_n=1+n\log(b/a)\)。原接受记录、旧来源和历史作为标签保留。以下量化删除是原 \(\nu\) 的正限制；辅助后验不继承这些标签的历史资格。

## 1. 原后验锚点变换：保列不等于第二来源损失小

固定同一个 \(\delta\in(0,1)\)，\(c=1-\delta\)。对原 \(x\sim\pi_B\)，置
\[
 B'=cB+\delta x,\qquad R'=cR_B,\qquad Q'_x=x+c(Q_B-x)\subset Q_B.
\]
锚点 \(x\) 仍在 \(Q'_x\)。令 \(m'_x=\mu(Q'_x)\)、\(q'_x=m'_x/(cR_B)^n\)。第二个原来源的失捕量精确为
\[
 L_\delta=\int\nu(dB)\pi_B(dx)(1-m'_x/m_B)
 =(1-c^n)R_\tau+c^n\int\nu(dB)\pi_B(dx)(1-q'_x/q_B).       \tag{1}
\]
最后一项是有符号项；\(q'_x/q_B\le c^{-n}\)，故有限，不作两个无穷量的相减。不能因 \(\delta\) 小而删掉密度下降项。

第一来源联合测度为
\[
 d\Xi=t(B)R_B^{-n}1_{Q_B}(x)\,dB\,d\mu(x).
\]
固定 \(x\) 换元 \(B\mapsto B'\) 的 Jacobian 为 \(c^n\)，与 \(R_B^{-n}\) 精确抵消。因此推前保持每个 \(x\) 的原来源列质量。不过推前半径
\[
 R'_{x}(B')=cR_{\,x+(B'-x)/c}
\]
依赖 \(x\)，不是一个共同的新中心选择器；\(q'_x\) 也没有原密度带保证。若再保留第二来源，推前恰为
\(d\Xi'\,(m'_x/m_B)\,\pi_{Q'_x}(dz)\)：\(z\) 可以这样条件化，但 \(x\) 不因此成为新父的完整后验。

这也给出原问题的精确几何缺口：例如取 \(\delta=O(\epsilon/n)\) 可使 (1) 的显式尺度项可吸收；尚须以同一个 \(\Xi\) 支付有符号密度下降，而不是给每个锚点另选半径。若 \(\delta\) 依赖 \(B\) 或质量，上述 Jacobian 已不适用，本稿没有作这种选择。

## 2. 固定绝对质量的共同选择器：旧工具的必要重述

历史核对确认以下固定质量几何已在 R098 出现，本轮不把它重新计为新付款。为说明当前接口，给出自含证明。

对 \(0<m<W\)，定义
\[
 r_m(B)=\inf\{R>0:\mu(Q(B,R))\ge m\}.
\]
\(L^1\) 绝对连续性给小盒质量趋零；大盒质量趋 \(W\)；盒质量对中心和正边长连续。因此 \(0<r_m(B)<\infty\)，首次达到处质量恰为 \(m\)，平台不影响这个等式。小集合绝对连续性还给固定 \(m\) 下 \(r_m\) 的全局正下界。由立方体包含关系，
\[
 |r_m(B)-r_m(C)|\le2\|B-C\|_\infty.                         \tag{2}
\]
固定 \(u\in[-1/2,1/2]^n\)，取
\(T_u(B)=B+\delta r_m(B)u\)。扰动的 \(\ell^\infty\)-Lipschitz 常数至多 \(\delta<1\)，故映射双 Lipschitz；方程
\(B=Y-\delta r_m(B)u\) 的压缩映射定理给全局逆。几乎处处 \(\|\nabla r_m\|_1\le2\)，于是矩阵行列式引理给
\[
 J_u(B)=\det DT_u(B)=1+\delta u\cdot\nabla r_m(B)
 \in[1-\delta,1+\delta].                                    \tag{3}
\]
面积公式因而给 \((1-\delta)|D|\le|T_u(D)|\le(1+\delta)|D|\)，以及 Lebesgue 推前密度在 \([(1+\delta)^{-1},(1-\delta)^{-1}]\) 内。这是维数无关的中心体积费用。

但记 \(q_m=m/r_m^n\)，有
\[
 (1-\delta)r_m(B)\le r_m(T_uB)\le(1+\delta)r_m(B),
 \quad
 \frac{d(T_u)_*(q_m\,dB)}{q_m(Y)\,dY}
 \le\frac{(1+\delta)^n}{1-\delta}.                           \tag{4}
\]
所以中心体积的维数无关结论不能直接升级为质量密度的同样结论。原后验写成相对位置 \(x=B+r_m(B)u\) 时，\(u\) 的密度是
\(f(B+r_m(B)u)r_m(B)^n/m\)，并非均匀分布。固定 \(u\) 的换元不允许删掉这个来源权。

## 3. 新接口：两项原接收正分支一次支付

设 \(m_-=qa^n\)、\(m_+=\lambda b^n\)，令
\[
 N=1+\left\lceil\log_2(m_+/m_-)\right\rceil,
 \qquad m_j=2^{j-1}m_-\quad(0\le j<N).
\]
按唯一半开质量窗选择 \(j(B)\)，使
\(m_j<m_B\le2m_j\)。只对非空窗使用 \(r_{m_j}\)；这些窗均有 \(m_j<m_B\le W\)，所以没有用到可能不存在的 \(r_W\)。置
\[
 \widetilde R(B)=r_{m_{j(B)}}(B),\qquad
 \widetilde q(B)=m_{j(B)}/\widetilde R(B)^n.
\]
它是可测的单一选择器，\(\widetilde R\le R_B\)，且
\(\widetilde q\ge q_B/2\)。

**第一项。** 在 \(E_{\rm small}=\{\widetilde R<a\}\)，
\(g_a(B)\ge m_j/a^n\ge q_B/2\)。因此对原记录正限制，
\[
 \nu(E_{\rm small})\le2S\int g_a(B)\,dB=2SW.                 \tag{5}
\]
这是对全部质量窗一次支付，不乘 \(N\)。

**第二项。** 固定 \(M\ge1\)，在余下 \(\widetilde R\in[a,b]\) 中取
\(E_{\rm peak}=\{\widetilde q>Mq_B\}\)。直接保留原 \(q_B\) 得
\[
 \nu(E_{\rm peak})\le\frac S M\int_{E\setminus E_{\rm small}}
 \widetilde q(B)\,dB\le\frac{SA_n}{M}W.                      \tag{6}
\]
最后一步是实际单选择器的 Tonelli 界：固定来源 \(x\)，
\(\int1_{Q(B,\widetilde R)}(x)\widetilde R^{-n}dB\le A_n\)，由
\(\min\{a^{-n},(2\|B-x\|_\infty)^{-n}\}\) 在半径 \(b/2\) 内积分得到。这里各窗先合并成唯一 \(\widetilde R(B)\)，所以没有层数，也无额外 \(r\) 因子。

取 \(M=\max\{1,A_n/\sqrt n\}\)，两项互斥，故
\[
 \boxed{R_\tau\le S(2+\sqrt n)W+\nu(E_{\rm rem}).}           \tag{7}
\]
在 \(E_{\rm rem}\) 上有完整的共同选择器匹配
\[
 a\le\widetilde R\le b,\quad
 \mu(Q(B,\widetilde R))=m_{j(B)},\quad
 q/2\le\widetilde q\le M\lambda,
 \qquad d\nu=\widetilde t\widetilde q\,dB,
 \quad\widetilde t=tq_B/\widetilde q\le2S.                    \tag{8}
\]
新密度带比至多 \(2Mr\)，其对数为 \(O(\log r+\log(n+2))\)。这是真实原中心分支费用；若用于 \(L_\delta\)，因每条原记录失捕比例不超过 1，同样可支付这两个子部分，但不再叠加领取 (7) 的同一费用。

余支还有实际尺度贴近：由 \(m_j\ge m_B/2\) 及 \(\widetilde q\le Mq_B\)，
\[
 (2M)^{-1/n}\le\widetilde R/R_B\le1,
 \qquad 0\le\log(R_B/\widetilde R)\le\log(2M)/n.              \tag{9}
\]
固定原 \(r\) 时，这是 \(O(\log(n+2)/n)\) 的对数尺度误差。但量化立方体仍可能只捕获约一半原父来源质量，不能把 (9) 自动用于硬捕获门。新带比 \(2Mr\) 随维数增长；线性依赖带比的旧估计不能无代价导入，必须保留 \(\widetilde t=tq_B/\widetilde q\) 的真实权重以获得抵消，或另行支付带比费用。

## 4. 剩余的唯一层间／来源费用

式 (8) 是原中心边缘的精确重写，不是原来源的刷新。辅助量化后验满足
\(d\widetilde\pi_B/d\pi_B=(m_B/m_j)1_{Q(B,\widetilde R)}\le2\)，但反向支配不成立，原接受门可集中在被删除的来源部分。故不能把 (8) 当作旧双来源／历史合同已经转移。

对于直接接收质量目标，(8) 可以作为真实新场；但固定质量变换 (3) 只能逐 \(j\) 使用。分片函数 \(r_{m_{j(B)}}(B)\) 不自动满足 (2)，不同窗的 \(T_{u,j}\) 图像可能重叠。分别付每窗 \(W\) 会留下
\(N=O(1+\log r+n\log(b/a))\) 的费用，(3) 没有消掉它。

所以需要的实质下一桥是：对同一原中心边缘的这些质量窗，共同控制变换图像与真实来源权的重复，或直接支付 (1) 的同权密度下降。现有体积 Jacobian、来源列恒等式及两笔正分支费用未给出这个联合界。本稿证明 (7)，不宣称 \(\nu(E_{\rm rem})\) 或完整 \(L_\delta\) 已有根阶预算。

## 5. 实际有限核验

下列代码已在指定本机 Python 运行；8 项为秩一行列式与范围核验，4 项为带可行质量比的失捕恒等式。它们只核代数，不是实际选择器、连续来源或历史验证。首次运行中一组输入违反 \(c^nq'_x/q_B\le1\)，被可行性断言拒绝；修正该输入后以下自含版本通过。

```python
import sympy as s
from fractions import Fraction as F
checks = 0
for n in (1, 2, 3, 4):
    delta = s.Rational(1, 7)
    u = s.Matrix([(-1)**i*s.Rational(1, 2) for i in range(n)])
    grad = s.Matrix([s.Rational(2, n) for _ in range(n)])
    det = (s.eye(n)+delta*u*grad.T).det()
    assert det == 1+delta*(u.T*grad)[0]
    assert 1-delta <= det <= 1+delta
    checks += 2
for n, delta, q0, q1 in (
    (1,F(1,10),F(2),F(1)), (2,F(1,8),F(3),F(7,2)),
    (8,F(1,32),F(1),F(1,2)), (3,F(1,9),F(2),F(5,2))):
    c=1-delta; w=c**n*q1/q0
    assert 0 <= w <= 1
    assert 1-w == (1-c**n)+c**n*(1-q1/q0)
    checks += 1
print(f'PASS {checks}: 8 rank-one Jacobian checks; 4 signed capture identities. Algebra only, not a native selector or history test.')
```

实际 stdout：
```text
PASS 12: 8 rank-one Jacobian checks; 4 signed capture identities. Algebra only, not a native selector or history test.
```
