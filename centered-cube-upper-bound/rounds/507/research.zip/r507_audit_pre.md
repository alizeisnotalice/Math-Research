# R507 独立预审：固定来源的收缩推前

先于阅读 R507 作者稿。取 \(0\le\delta<1\)、\(c=1-\delta>0\)；δ=1为奇异映射，不使用以下 Jacobian。保完整 \(\mu=f\,dx\)、真实 \(\nu=tq_BdB\)、\(m_B=q_BR_B^n\)、\(\pi_B=1_{Q_B}\mu/m_B\)。概率mark可在原条件下同时积分，原历史仅作为旧标签保留。

## 1. 最精确的一来源 joint 合同

原 joint 为
\[
d\eta(B,x)=\nu(dB)\pi_B(dx)
=t(B)R_B^{-n}1_{Q_B}(x)\,dB\,d\mu(x).
\]
变换 \(B'=cB+\delta x\)、\(R'=cR_B\)，x不变。固定x时 Jacobian 是 \(dB'=c^n dB\)。记
\[
B_x=(B'-\delta x)/c,
\quad r_x=cR_{B_x},\quad Q'_x=Q(B',r_x).
\]
则推前的准确密度为
\[
d\eta'(B',x)
=t(B_x)r_x^{-n}1_{Q'_x}(x)\,dB'\,d\mu(x).
\tag{1}
\]
c⁻ⁿ只与旧R⁻ⁿ合成r_x⁻ⁿ，不能再多收一次。旧父可由(B',x)恢复，故附带旧记录的任意非负测试亦有同式：保其原条件分布，在逆像B_x上评价，不在B'上重新生成history。

**关键量词：r_x一般依赖x。** 式(1)不是一个已证的 single-selector 接收场，也未证明新条件来源为π_(B',r)。把半径附成mark不自动使该mark独立于x或具有免费概率密度帽。即使原R固定，t(B_x)仍可倾斜新来源后验；此时只有对固定新半径参考的正支配≤S，而非自动同律。原R与t都固定的特殊情况可以恢复matching形式，但它不能代表一般合同。

几何上 \(Q'=x+c(Q_B-x)\subset Q_B\)，且x∈Q'。新真实质量 \(m'=\mu(Q')\le m_B\)，其平均为
\[
q'=\frac{m'}{(cR_B)^n}
=c^{-n}\frac{m'}{m_B}q_B\le c^{-n}\lambda.
\tag{2}
\]
没有由包含关系推出q'≥q。同尺度窗只变为[ca,cb]；若用原归一化而非r_x归一化，c⁻ⁿ不能忽略。主合同不允许把新的q'、rank或源捕获门认作原门。

另一方面，保x不动的推前**准确保留原实际来源边缘**：
\[
\eta'_x(dx)=\eta_x(dx)=L_t(x)d\mu(x),
\quad L_t(x)=\int t(B)R_B^{-n}1_{Q_B}(x)dB\le SA_n,
\quad A_n=1+n\log(b/a).
\tag{3}
\]
这是已有来源列的保持，不是声称边缘等于μ，也不是新的根阶来源价。总质量也恰为Rτ。

## 2. 第二来源必须在原双来源 joint 中计损

在原 \(\nu(dB)\pi_B(dx)\pi_B(dz)\) 上附上述收缩。未经筛选的推前密度为
\[
\frac{t(B_x)}{r_x^n m_{B_x}}
1_{Q'_x}(x)1_{Q_{B_x}}(z)\,dB'\,d\mu(x)d\mu(z).
\tag{4}
\]
若只保z∈Q'_x，则第二个指示改为新Q'。给定原(B,x)，保留率及z条件律准确是
\[
\theta(B,x)=m'(B,x)/m_B,\qquad z\mid\mathrm{kept},B,x\sim\pi_{Q'}.
\]
保留密度可写成 \(\theta\,t(B_x)/(r_x^n m')\) 乘两个新捕获指示，但这个matching参照仍是x依赖半径的fiber表达。m'=0时保留部分按零处理，不定义π'或作0/0消去。保留后x亦受θ倾斜，不能宣称两个来源是新父的独立π'样本。

完整损失必须支付
\[
\mathcal L_\delta
=\int\nu(dB)\pi_B(dx)\pi_B(dz)1_{z\notin Q'(B,x)}
=R_\tau-\int\nu(dB)\pi_B(dx)\frac{m'(B,x)}{m_B}.
\tag{5}
\]
若实际余流另有接受权或历史限制L，必须保原L于(4)–(5)；只在明确正支配时才能以上式未标记损失上放，不能把旧L移到新盒重新判断。未保留z的整流仍须列入总账。

固定完整场、固定原selector且δ↓0时，μ绝对连续使原x,z在原盒边界的质量为零，故由有限Rτ及支配收敛有 \(\mathcal L_\delta\to0\)。这不给对任意输入统一的δ速率，也不能按此免费选一个依赖输入的δ后沿用既定维数／Jacobian费用。若需要一个统一可用δ，必须另证明(5)在**同一实际原流**上有 \(\eta X+C_\eta\sqrt n\,\mathrm{polylog}(n)W\) 或可吸收的真实量价。

## 3. 能用于整合的正信息与仍需付的费用

式(1)、(3)、(5)是真正source-preserving的共同合同：原中心/来源/历史可以作为旧标签全留，原实际来源列不增，第二来源保留率完全显式。但把它接到一般根阶接收预算还需支付：源依赖半径到合法共同接收参考的比较、真实qband与质量门的变化、第二来源损失、以及任何硬捕获/旧路径门改变。R506首穿辅助来源不等于原π_B，不能直接替入(5)。若仅作Lipschitz测试，几何位移界本身仍以Rτ或其原joint计价，不能自动改成W。

本机指定Python实际运行 `/tmp/r507_audit_math_check.py` 的6项SymPy恒等式：n=1,2,3仿射Jacobian、归一化、双来源保留因子、立方体仿射偏移。它们只核代数，不认证损失价、single-selector恢复或原history。独立预审交付后等待作者后审。
