# R507 独立终审

FINAL PASS（限定两项已付原接收子支及精确联合工具）。在任意非负L1来源、真实中心与原qband下，两项互斥正限制确有合计≤S(2+√n)W的费用。**余支、完整失捕量、原J及全尺度一般根阶上界仍未付款。**

独立 PRE 先于作者阅读形成；已审白名单10件最终文件，未改作者或仓库。

- 半开质量窗覆盖全部原质量，m_j<m_B≤2m_j确保只调用m_j<W的精确逆质量半径。r̃≤R_B且q̃≥q_B/2。r̃<a的全部标签一次付2SW；其补集的q̃>Mq_B支先合成同一selector、再用Tonelli包络付SA_nW/M。M=max(1,A_n/√n)确给S√nW，无额外N或r。两支互斥，不可在父量和失捕量上重复收同一费用。
- 余支是原中心边缘的精确重写：t̃≤2S、q/2≤q̃≤Mλ、带比2Mr；后者随n增长，不能藏进fixed-r常数。尺度误差log(2M)/n正确，但质量可能只保约一半。π̃≤2π仅单向成立，旧来源／双来源门和history不迁移。质量片内2-Lipschitz／Jacobian不能使分片图像免于重叠或免费消掉N。
- 固定anchor收缩的Jacobian、source-preserving原列与第二来源保留率均准确；推前半径依x，不是自动single-selector。逐坐标首次失捕条带互斥，g_prev=cg_j+δh_j及带c权熵望远镜保完整质量。损失保体积基项(1−c^n)Rτ与有符号密度修正，熵零不能替代体积基项；原t dA π_A基底没有多乘q_A。核心与全部条带合计来源列仍为SA_n，未冒称根阶。
- geometry的固定绝对质量半径／秩一Jacobian证明自含且合法，按历史限定作为旧工具重述。history仅索引；第486建议的E1/H2不在本轮重新领付款。原母倍率、τX、初始／删除／未来来源／宽距离／低强度／极端比与尺度拼接均保留，直接路线和旧J槽是替代结算。

实际独立-I隔离重放geometry12、proof32、PRE6、numeric409，共459个报告核验单位；四stdout逐字一致，numeric JSON仅去compute_index.seconds后逐字段一致。规范SHA256为 `5e08f860a49e14c6692899b5c116ac477c1400103294c28b8c88e47a9096fd45`。精确有理体积的两种实现一致；Arb256仅作显示。16个连续角块／正中心配置各有3种标签律，保真实Rτ和L/W；条件失捕近1不构成全局反例。局部相关来源的proof32及所有有限检查均未认证原rank/history、firstcross或一般层间费用。

本轮可入账的仅上述两正子支；真正剩余为同一原中心边缘下的质量窗图像重复及真实来源权／密度修正联合结算。审查到此停止。

最终输入 SHA256：

- `r507_main.md`: `c675d41afaa1775fc450a785a9984fa56e09786b5acba824b5e92d3c75c839c1`
- `r507_geometry.md`: `41cebe0d3ec4f1cdc75299b4819b862aa06463ca8f49da52360c15d53fa7488c`
- `r507_proof.md`: `fdb83a259619530c2f0f44a1115a1a78204d9ed1b43b262da9d37e77e608c5bc`
- `r507_audit_pre.md`: `acef91becfb797963bbe4ffd7296cf07558ff31cc094bf5345909f00e1ec00b5`
- `r507_audit_math_check.py`: `fbc846caa5b6c60fe026f44161c02d646f112b49ea1b1c220a187baba86a50f5`
- `r507_numeric.py`: `a000cb2e95d7a99d92f2ea3ee0fe9ac0a8dfca32310ffbfc0bb34d262aa1e6f1`
- `r507_numeric.json`: `767b7d7e991983720b8019cfd17db2417888b973b3bf0b3127bbd2a60b603940`
- `r507_numeric.md`: `7f4a3eee058a91b8732e8476fd3bf25650776b4426d1b3c05caee7428ba897cb`
- `r507_history.md`: `ffea1f902daa062017c632ef575d5606dfb63a21949b8d6b8102d04708e11341`
- `r507_replay.json`: `690e2cbfeb9cfcabcf4c8536cbf3cf59d9e2e6f50c92941cd30c044fe146fe85`
