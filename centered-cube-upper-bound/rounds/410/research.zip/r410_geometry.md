# R410：原质量差项的跨时钟比值容量与反向强制性

2026-10-19。**得到严格的全积分几何估计，但没有得到 M_H 的根阶上界付款。**实际质量比值容量和原完整时钟共同证明：高秩的质量差项 M_H 已经承载几乎全部 X_q。因此不能把质量 CDF 的 Gini 表达当作一个自动更弱的目标。以下保留完整 full f、真实 du、原 prefix 和物理终点原子，不引入新选择器。

## 1. 精确对象与结论

设 f≥0 属于 L1，W=∫f，E 为有限测度的实际接收集，Q_u 以 u 为中心、边长 R_u∈[a,b]，0<a≤b<∞。完整匹配为

\[
m_u=f(Q_u)=q_uR_u^n,\qquad0<q_-\le q_u\le\lambda,
\quad\mu(du)=du/m_u,\quad X_q=\int_Eq_u du.
\]

本证明不需要 b≤2a；实际应用继续使用冻结 octave。记 E_r={u:R_u≤r}、c_u=1_{Q_u}、J_y(r)=∫_{E_r}c_u(y)μ(du)，原物理时钟为

\[
\ell(dr)=nr^{-n-1}1_{[a,b]}dr+b^{-n}\delta_b.
\]

对 H>0，S_H(r,u,v)=∫f(y)1_{J_y(r)≥H}c_u(y)c_v(y)/J_y(r)dy，零 J 项取零。原正质量差为

\[
M_H=\int\ell(dr)\int_{E_r^2,m_u>m_v}
 (m_u-m_v)S_H(r,u,v)\mu(du)\mu(dv).
\]

则严格有

\[
\boxed{
\left(1-\frac{2\lambda}{q_-^2H}\right)X_q-\lambda HW
 \le M_H\le X_q.} \tag{1}
\]

当 H≥4λ/q_-² 时，特别得到

\[
X_q\le2M_H+2\lambda HW. \tag{2}
\]

因此对于 H 处于允许根阶多对数范围且满足上述下限的原场，统一的 M_H 根阶 W 上界将直接给同阶 X_q 上界；反向由 M_H≤X_q 自动成立。**(1)是反向定位和真实跨时钟估计，不是新的 BH/G_core 付款。**

## 2. Gini 恒等式与三个有限正项

固定原 (y,r)，令 ρ_y^r(du)=1_{E_r}c_u(y)μ(du)，总量 J=J_y(r)，质量闭 CDF 为 F(t)=ρ_y^r{m_u≤t}。若 J>0，则

\[
\int_{m_u>m_v}(m_u-m_v)\rho_y^r(du)\rho_y^r(dv)
=\int_0^\infty F(t)(J-F(t))dt
=J\int m_u\rho_y^r(du)-\iint\min(m_u,m_v)\rho_y^r(du)\rho_y^r(dv).
\tag{3}
\]

例如对 m_v<m_u，质量差是 ∫1_{m_v≤t<m_u}dt。质量原子和等号不会产生额外项：t 的单点对 Lebesgue dt 无质量，m_u=m_v 的差为零。式(3)没有把实际质量轴积分当成半径选择器积分。

定义

\[
\begin{split}
L_{\rm low}&=\int\ell(dr)\int f(y)1_{0<J_y(r)<H}
 \left[\int_{E_r}c_u(y)du\right]dy,\\
N_H&=\int\ell(dr)\int\frac{f(y)1_{J_y(r)\ge H}}{J_y(r)}
 \iint_{E_r^2}\min(m_u,m_v)c_u(y)c_v(y)\mu(du)\mu(dv)dy.
\end{split}
\]

完整匹配及含终点原子的时钟尾给

\[
\int_{[R_u,b]}\ell(dr)=R_u^{-n},\quad
\int\ell(dr)\int f(y)\int_{E_r}c_u(y)du\,dy
=\int_E m_uR_u^{-n}du=X_q.
\tag{4}
\]

因此三个正项均有限，且

\[
\boxed{M_H+L_{\rm low}+N_H=X_q.} \tag{5}
\]

这是对原积分的结算，不是额外负信用。后续 N_H 的上界不允许拿来再减旧 BH 平方。

## 3. 原生质量比值容量：同一个中心积分一次支付

对任意来源 y 与任意固定 M>0，

\[
\boxed{\int_E\frac{c_v(y)}{m_v}
 \frac{\min(M,m_v)}{\max(M,m_v)}dv\le\frac2{q_-}.} \tag{6}
\]

证明保留实际半径场。令 t=(2||v−y||_∞)^n；若 c_v(y)=1，则 m_v≥q_-t。函数

\[
g_M(x)=\frac1x\frac{\min(M,x)}{\max(M,x)}
=\begin{cases}1/M,&x\le M,\\M/x^2,&x\ge M\end{cases}
\]

非增。对真实中心积分，体积变量 t 的分布是 dt，故

\[
\int_E c_v(y)g_M(m_v)dv
\le\int_0^\infty g_M(q_-t)dt
=\int_0^{M/q_-}\frac{dt}{M}
 +\int_{M/q_-}^\infty\frac{M}{q_-^2t^2}dt
=\frac2{q_-}.
\]

这一步把所有质量尺度一并结算；没有每窗各付一份 W，没有自由半径积分，也没有用体积约束 f 的点态密度。实际匹配只需其真实下界 m_v≥q_-R_v^n。等质量原子在两个分段相接处取同一值。

## 4. 用原完整时钟得到 N_H 的小 X 价格

固定真实 u,v，设 R_*=max(R_u,R_v)。包含终点原子给精确式

\[
\int\ell(dr)1_{u,v\in E_r}=R_*^{-n}
\le\frac\lambda{\max(m_u,m_v)}. \tag{7}
\]

末步因每个 m_w≤λR_w^n≤λR_*^n。现在才对 N_H 使用 1_{J≥H}/J≤1/H；Tonelli、(7)、(6) 依次给

\[
\begin{aligned}
N_H
&\le\frac\lambda H\int f(y)
 \iint c_u(y)c_v(y)
 \frac{\min(m_u,m_v)}{\max(m_u,m_v)}\mu(du)\mu(dv)dy\\
&\le\frac{2\lambda}{q_-H}\int f(y)Z(y)dy
=\frac{2\lambda}{q_-H}|E|
\le\frac{2\lambda}{q_-^2H}X_q,
\end{aligned}\tag{8}
\]

其中 Z(y)=∫c_u(y)μ(du)，∫fZ=|E| 来自完整匹配。**没有先按每个 r 或每个质量层付费；没有取平方的 A_n 包络。**(8)是本轮真正跨时钟、质量比值的联合估计。它控制的是(5)中已从 M_H 扣除的正差额 N_H，因此给 M_H 的下界，不能反过来当上界付款。

## 5. 低秩项必须先交换时钟，不能逐半径累加

固定 y。若 u∈E_r 且 J_y(r)<H，由原 inclusive prefix 单调性有 J_y(R_u)≤J_y(r)<H。因此

\[
\begin{aligned}
\int\ell(dr)1_{0<J_y(r)<H}\int_{E_r}c_u(y)du
&\le\int_E c_u(y)1_{J_y(R_u)<H}R_u^{-n}du\\
&\le\lambda\int_Ec_u(y)1_{J_y(R_u)<H}\mu(du)\\
&\le\lambda H. 
\end{aligned}\tag{9}
\]

最后一步将 c_u(y)μ(du) 推至**实际半径轴**。J_y(R_u) 是其闭 CDF 值；闭 CDF 小于 H 的完整初始段质量至多 H。跨过 H 的半径原子整块不属于低秩支；等于 H 的原子归高秩。可用递增初始截断和单调收敛处理不存在最大半径的情况。

这里先交换 u,r 再用精确尾 R_u^{-n}，故没有 n 或 log(b/a) 重数。终点原子在(4)、(7)、(9)都保留。积分来源得到

\[
L_{\rm low}\le\lambda HW. \tag{10}
\]

用(5)、(8)、(10)即得(1)。

## 6. 准确收获与仍未付步骤

本轮没有证明 M_H≤εX_q+C_ε√n log^A(n+2)W，也没有支付当前 R408/R406 余项。反向式表明，在 H 足够大时 M_H 自身就是主要的 X_q 费用；不是一个仅靠质量 CDF 排序和减去 min-mass 差额就会变小的剩余。

原任务所需的几何仍必须控制同一实际全来源选择器的接收总量/质量差主量：真实质量分布在全来源平均下不能长期贡献大量第一矩而只取得(8)这么小的 min-mass 差额，或者须在原更强带标记 flow 中使用已被无标记 M_H 外放松丢失的信息。这里没有证明这一步，也不把它改名为已付的新目标。

旧母账全部保持。若未来有人证明完整 M_H 上界，(1)可回代检验其强度和参数；本轮不能先假定这个上界来认领 root 费用。

## 7. 实际数学工具核验

执行 `/tmp/r410_geometry_check.py`：

```
PASS radial/pointwise/prefix: 16 304 72 total: 392
```

16 项 Fraction 精确计算 native 中心体积变量的内段与无限平方尾，均为 2/q_-；304 项核(6)的实际质量下界包络；72 个有限 full-source incidence 模型逐 inclusive prefix 核质量原子 Gini、(5)、低秩费及(8)所用时钟比较。物理时钟以 R^n 的有理值实现区间差 1/R_k^n−1/R_{k+1}^n，末端保留 1/R_max^n。

有限 incidence 的 receiver 是 quadrature，故其比值容量用该模型自身的精确值，没有把 native 2/q_- 强加给任意离散权。它们不是原 cube/history 合格场；真实中心容量由解析式(6)证明。数字仅作代数核验，不构成根阶上界证据。本轮停止于上述严格结果与明确缺口。
