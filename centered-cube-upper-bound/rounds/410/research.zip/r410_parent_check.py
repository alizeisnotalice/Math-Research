from fractions import Fraction as F
from itertools import product
counts={}
for label,menu in [('initial',[1,2]),('atoms',[F(1,4),1,4]),('expanded',[F(1,100),2,100])]:
 c=0
 for f0,f1,q0,q1,H in product(map(F,menu),map(F,menu),[F(3,4),F(1)],[F(3,4),F(1)],[F(1,4),F(1),F(4)]):
  f=[f0,f1];C=[[1,1],[0,1]];m=[f0,f0+f1];q=[q0,q1];v=[m[i]/q[i] for i in range(2)];du=[F(1,3),F(2,5)];mu=[du[i]/m[i] for i in range(2)];ts=sorted(set(v));low=F(0)
  for k,t in enumerate(ts):
   ell=1/t-(1/ts[k+1] if k+1<len(ts) else 0)
   E=[i for i in range(2) if v[i]<=t]
   for y in range(2):
    J=sum(mu[i]*C[y][i] for i in E)
    if J<H:low+=ell*f[y]*sum(du[i]*C[y][i] for i in E)
  assert low<=H*sum(f)
  c+=1
 counts[label]=c
# Native envelope radial integral split at m/q; exact primitive over infinite tail.
for m,q in product([F(1,100),F(1),F(100)],[F(1,3),F(1),F(7)]):
 cut=m/q
 assert cut/m+m/(q*q*cut)==2/q
print('PASS low-prefix clock checks',counts,'total',sum(counts.values()))
print('PASS native radial-envelope primitive 9 exact cases')
print('Finite clock identities and analytic primitive only; no native full-core or root-order claim.')
