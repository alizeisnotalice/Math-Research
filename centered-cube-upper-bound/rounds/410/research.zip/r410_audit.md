# R410 independent audit — FINAL PASS

FINAL PASS within the stated scope: native cross-mass capacity, original-clock coercivity, and the near-containment limitation. Main/readme accurately report no new root-order payment; the complete R408 ledger remains unchanged. This audit certifies neither a general weak-type upper bound nor a new bound for the current marked core. Only this audit file was edited.

## Independent main proof and author post-review

The main result was derived before reading R410 author proofs. Subsequently read both proofs, main/readme and all three delivered scripts in full. No outstanding substantive defect was found.

All objects use full matched f, true receiver du, μ=du/m, original inclusive prefixes/high gate J≥H, and physical ℓ including b^(−n)δ_b. For fixed y and M>0, capture implies m_v≥q_-(2||v−y||∞)^n. Since

`μ-density × min(M,m_v)/max(M,m_v) = min(1/M,M/m_v²)`,

the exact radial volume variable t=(2||v−y||∞)^n gives an upper envelope with integral2/q_-. This holds for arbitrary actual selected radii and all mass scales together; it is not an identity for the actual selector, nor a source-density cap. Equal-mass atoms are included. The lemma itself does not require an octave.

N_H is the full ordered-pair integral with min(m_u,m_v), without1/2. Retain the original high gate before using1/J≤1/H. The inclusive physical tail is exactly max(R_u,R_v)^(−n)≤λ/max(m_u,m_v), including when either radius equals b. Tonelli and the native capacity therefore give

`N_H≤2λ|E|/(q_-H)≤2λX_q/(q_-²H)`.

The exact matching identity is ∫f(y)J_y(b)dy=|E|, not W or an f² quantity. The high first moment is X_q−L_low, and symmetric mass splitting gives

`M_H+N_H+L_low=X_q`.

Equal-mass pairs remain in N_H. All terms are finite positive quantities before subtraction; zero-J terms vanish by the already audited Tonelli convention.

For L_low, first exchange receiver and clock. A receiver in a strict low prefix has J_y(R_u)<H; its complete tail is R_u^(−n). Using q_u≤λ, the remaining μ_y mass is the closed-radius-CDF sublevel {J_y(R_u)<H}, of mass≤H. Crossing/threshold atoms are not split or charged to the strict low branch. Thus `L_low≤λHW` with no radius-layer multiplicity. Consequently

`(1−2λ/(q_-²H))X_q−λHW≤M_H≤X_q`.

The coefficient is useful only when positive; H≥4λ/q_-² yields X_q≤2M_H+2λHW. This is a lower/coercivity estimate, not an M_H upper payment. It cannot be passed to G0 merely from G0≤M_H, nor to BH(f,ν) for ν≤f. Original BH square/cross/clock credits were already used in R409 and are not reused here. No original H or other frozen parameter was reselected.

## Auxiliary and full-report scope

For strict far mass and source-mass near containment, the symmetric boundary component has both orientations, giving `Cδ≤2δMδ/(K−1)`. This reduces a positive boundary term, not the mass-difference component. The actual tail/matching calculation correctly uses `(mu−mv)μu=du(1−mv/mu)` and then σ=qdu. The strict mass window is empty when mu/K≤q_-a^n, including equality. Otherwise its native capacity is `[1+log(mu/(Kq_-a^n))]/q_-`. The worst O(n/(q_-H))X_q price and missing joint geometric estimate are accurately stated; no new receipt follows.

Main/readme preserve all R408 mother coefficients:16Fδ for G0,32Fδ for BH,64Fδ at the entrance; source and X terms remain as in the frozen parent. The lower bound does not replace a marked residual, and the all-source symdiff decomposition does not pay that residual. Full-source/ν, actual du/quadrature and original clock distinctions are maintained. Literature/E03 mentions are scope records and are not mathematical inputs or independent theorem verification in this audit.

## Actual local evidence and limits

Reviewer independently executed27 Fraction assertions before reading authors:12 radial-envelope primitive evaluations and15 exact finite-receiver clock identities/positivity/low-bound assertions. The source intervals are exact, but receiver weights are quadrature. These are not added to delivered counts.

Reviewer then read and actually reran all delivered scripts:

- parent:264 low-prefix parameter cases (48/108/108) plus9 radial primitives;
- geometry:392 grouped checks (16 radial,304 pointwise envelope,72 finite-incidence prefix);
- auxiliary:48 grouped checks (36 near-containment scalar,12 inclusive-clock).

All passed:713 delivered Fraction checks, matching saved stdout. Parent/reviewer reruns repeat the same cases and are not new experiments. Finite incidence is not a native single-valued continuous cube/core/history fixture; the code deliberately uses its own finite ratio capacity rather than imposing native2/q_- on arbitrary discrete weights. General geometric validity rests on the analytic argument, not these counts. No new numerical experiment, asymptotic fit or root-order conclusion is claimed.

## Final byte bindings

- `/tmp/r410_main.md`: `c5b253eb2c5f55d2c4211a6526de204f38d86cd155a324fe719a459a63bc2eaf`
- `/tmp/r410_readme.md`: `64b78368286fad71029042ab594225a0f885b281d93bd3666b8a28e4ffb4b493`
- `/tmp/r410_geometry.md`: `0ef0c4be235af7a9f9f256982e526173c46c935f9cabfa5b081ce8544bea405a`
- `/tmp/r410_aux.md`: `3fd661cd0deea272106f361d86aa019c709861e0512cc853f4481a468f61092c`
- `/tmp/r410_parent_check.py`: `7395e8813b267a1dfc4e21d3a18bfb9a9d37ac00c715eea4ee010cc7559cd91c`
- `/tmp/r410_parent.result.txt`: `d4c5b5be4ee09fed1c16716f62d5a1efea3c9c60a21625e7f2a898bf45bd5b76`
- `/tmp/r410_geometry_check.py`: `a88f9e95cbab81e11452c509785acdde1a33982b303a652300f6a58337191761`
- `/tmp/r410_geometry.result.txt`: `0081163d94e8c18f52eba48c6ceadbf2bc394cbf2ae356847fef29dae97c402e`
- `/tmp/r410_aux_check.py`: `8dd154dfb6db16da34d3943ba1980ba9f6df294af059d0681e97c1632e66082d`
- `/tmp/r410_aux.result.txt`: `3f03bd6edfd6b966bc245f61312304656f1fc7c32590de3007f1ef2927e771dd`
- `/tmp/r408_main.md`: `29e41de32db722d89962f3f3593155b7e298bb02350e50cdab4a2a4fd12f3253`
- `/tmp/r409_joint.md`: `737b488fb34578a00ff8cdd84fc2afb8c9ba2fbca74467ec767016c09928c14e`

Bindings refer to current frozen bytes. The R409 original-clock chain and R408 historical proof were not reaudited beyond the necessary inherited definitions and displayed ledger comparison. No further work is pending within this bounded review.
