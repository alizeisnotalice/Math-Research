# 第410轮：跨时钟共同质量界与原质量差的强制性

2026-10-19。目标仍是一般中心立方体 n^(1/2+o(1)) 一致弱型上界。本轮没有新的根阶付款；严格证明一个跨质量、跨物理时钟的共同质量估计，并据此确定：完整无标记质量差的根阶预算与原接收量根阶预算同难。不能把它当作更容易的替代目标。第408轮已付总账保持不变。

## 1. 冻结原量

完整f≥0属于L1，W=∫f；真实有限接收集E，m_u=f(Q_u)=q_uR_u^n，q_-≤q_u≤λ，a≤R_u≤b≤2a，μ(du)=du/m_u，X_q=∫q_u du。物理前缀E_r={R≤r}，J_y(r)=∫_{E_r}c_u(y)μ(du)，H>0，Y_r={J≥H}，
\[
\ell(dr)=nr^{-n-1}1_{[a,b]}dr+b^{-n}\delta_b(dr),\qquad
S_H(r,u,v)=\int f(y)1_{Y_r}(y)c_u(y)c_v(y)/J_y(r)dy.
\]
零J项取零，所有接收对积分均含1_{E_r²}。第409轮已核的原净量为
\[
B_H(f,f)=M_H+C_H,
\quad M_H=\int\ell\int_{m_u>m_v}(m_u-m_v)S_H\,d\mu_u d\mu_v,
\]
\[
C_H=\int\ell\int[\min(m_u,m_v)-f(Q_u\cap Q_v)]S_H\,d\mu_u d\mu_v\ge0.
\]
原Rcross/Rclock等信用已经使用一次，不再扣除。下文只讨论同一full-source量；ν≤f只给既有上界比较，不把下界转给ν。

## 2. 原生中心的衰减质量窗

对固定来源y和任意锚质量m>0，完整匹配与中心捕获给
\[
m_v\ge q_-(2\|v-y\|_\infty)^n\quad(c_v(y)=1).
\]
函数g(x)=min(m,x)/(x max(m,x))等于1/m（x≤m），等于m/x²（x≥m），非增。真实中心体积变量t=(2||v-y||∞)^n因此给
\[
\int c_v(y)\frac{\min(m,m_v)}{\max(m,m_v)}\mu(dv)
\le\int_0^\infty\min\{1/m,m/(q_-t)^2\}dt=\frac2{q_-}.\tag{1}
\]
这是对所有质量窗一次积分，未逐窗收费；保真实du，没有密度帽，也没有独立半径积分。可测有限场已足够，界不依赖octave宽度或维数。

## 3. 跨时钟共同质量预算

定义全有序接收对量（不加1/2）
\[
N_H=\int\ell\int\min(m_u,m_v)S_H\,d\mu_u d\mu_v.\tag{2}
\]
保留高J来源门后用1/J≤1/H，交换正积分。包括终点原子的真实尾满足
\[
\int_{[\max(R_u,R_v),b]}\ell(dr)=\max(R_u,R_v)^{-n}
\le\lambda/\max(m_u,m_v).
\]
于是由(1)和完整匹配
\[
\begin{aligned}
N_H&\le\frac\lambda H\int f(y)dy\int c_u(y)\mu(du)
 \int c_v(y)\frac{\min(m_u,m_v)}{\max(m_u,m_v)}\mu(dv)\\
&\le\frac{2\lambda}{q_-H}\int f(y)J_y(b)dy
=\frac{2\lambda}{q_-H}|E|
\le\frac{2\lambda}{q_-^2H}X_q.\tag{3}
\end{aligned}
\]
质量相等对在N_H中完整保留；真实连续接收对对角无需另加离散自重。有限模型的对角仅用于代数检查。

## 4. 低秩来源、方向与意义

原低秩第一矩为L_low=∫ell∫f1_{J<H}∫_{E_r}c_u(y)du dy。不能先对每个r给一个H价再累加；那会引入维数费用。先交换u,r，利用J_y(r)<H且r≥R_u推出J_y(R_u)<H，再用完整尾：
\[
L_{\rm low}\le\int f(y)dy\int c_u(y)R_u^{-n}1_{J_y(R_u)<H}du
\le\lambda H W.\tag{4}
\]
最后一步是物理半径的inclusive-CDF子水平容量：μ_y质量满足J_y(R_u)<H的接收者总量≤H，包括同半径原子；跨越阈值的原子不能拆成免费部分。

由匹配行和、接收对对称化，严格有
\[
M_H=X_q-L_{\rm low}-N_H.
\]
因此
\[
\boxed{M_H\ge\left(1-\frac{2\lambda}{q_-^2H}\right)X_q-\lambda HW.}\tag{5}
\]
同时0≤M_H≤X_q。若另证明M_H≤εX_q+C_ε√n log^A(n+2)W，并取H与所有原合同兼容且1−2λ/(q_-²H)−ε>0，则(5)直接给X_q的同阶预算；这说明完整M_H上界不能仅靠上述归约解决。式(3)是共同质量的上界，代入M_H时变成下界，不能倒转符号作付款。H还未在原总账中重选。

实际核心G_0≤M_H,far≤M_H并不将(5)传为G_0下界，也不证明G_0的上界。将原带标记余项放成完整M_H会失去其可利用结构。本轮没有作这个放松的总账替换。

## 5. 近包含的独立检查

在m_u>K m_v、I_uv=f(Q_u∩Q_v)≥(1−δ)m_v的有序支，边界对称支Cδ与质量差支Mδ满足
\[
0\le C_\delta\le\frac{2\delta}{K-1}M_\delta.
\]
它缩小的是正边界项，不缩小Mδ，也不产生负信用。由实际strict质量窗和时钟尾只能得到
\[
M_\delta\le H^{-1}\int q_u B(u)du,
\quad B(u)=\begin{cases}0,&m_u/K\le q_-a^n,\\
[1+\log(m_u/(Kq_-a^n))]/q_-,&m_u/K>q_-a^n.
\end{cases}
\]
最坏仍为O(n/(q_-H))X_q。未证明来源近包含使接收中心处于薄几何层；对任意集中f不能这样推断。附件保留所缺的父输入g_u=f1_Qu、小盒匹配和原1/J联合约束，不把旧低过去分支重复收费。

## 6. 保持完整总账与下一步对象

第408轮的C_406、V_406、Fδ=(1−32δ)^−1及全部原参数不变。n≥9时仍为
\[
G_0\le16F_\delta R_{408}+16F_\delta C_{406}X_q+16F_\delta V_{406}W,
\]
\[
B_H\le32F_\delta R_{408}+[E_{387}+32F_\delta C_{406}]X_q
+[S_{390}+8s+32F_\delta V_{406}]W,
\]
\[
\mathrm{入口}\le\Lambda\{8\lambda HW+2d_{\rm eff}A_{\rm entrance,n}W_\nu/H
+64F_\delta R_{408}+[2E_{387}+64F_\delta C_{406}]X_q
+[2S_{390}+16s+64F_\delta V_{406}]W\}.
\]
低维沿用原完整core替换。未付早期标记余项、原H入口兼容、soft/crossing/entry、重尾/宽距离/低pe/极端尺度比、原历史初始/跳跃/未来删除、全尺度与极限、总吸收及来源重数全部保留。

下一步须直接保留原带标记交通的联合几何，而非先要求完整无标记M_H或全空间能量的小界。本轮没有否定一般几何路线，只查明两个辅助量的正确强度与费用方向。

## 7. 本机工具与证据范围

本机Python Fraction实际运行parent三阶段48、108、108个低prefix检查及9个原生径向积分primitive检查；geometry与aux的实际结果见对应附件及stdout。有限incidence不是连续完整核心；原生径向积分的证明由(1)给出，不以参数网格替代。

沿用64项E03的有限和、共同测度和终端审查，不调用未验证的树定理迁移。补充文献检索仍只核实Spector–Stockdale arXiv:2609.05377摘要的欧氏球范围，未将该结果用于本轮证明或立方体目标。所有本轮数学由上述原生中心积分、正Tonelli和原匹配给出。无新一般上界闭合、无PDF编译、无实际模型扣额数据。
