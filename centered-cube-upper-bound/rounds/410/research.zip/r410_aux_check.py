from fractions import Fraction as F
from itertools import product
count=0
for K,ratio,delta,leakfrac in product((F(2),F(4),F(8)),(F(2),F(3)),(F(1,10),F(1,2)),(F(0),F(1,2),F(1))):
    mv=F(3,5); mu=K*ratio*mv
    I=mv*(1-leakfrac*delta)
    mass=mu-mv; boundary=2*(mv-I)
    assert (1-delta)*mv<=I<=mv
    assert 0<=boundary<=2*delta*mass/(K-1)
    assert mass<=mass+boundary<=(1+2*delta/(K-1))*mass
    count+=1
# One exact complete physical clock with a continuous layer and terminal atom:
# integral_[Ru,b] n r^(-n-1)dr+b^(-n)=Ru^(-n).
clock=0
for n,Ru,b in product((1,2,4),(F(1),F(3,2)),(F(3,2),F(2))):
    if Ru>b: continue
    continuous=Ru**(-n)-b**(-n); terminal=b**(-n)
    assert continuous+terminal==Ru**(-n)
    clock+=1
print('PASS near_containment_scalar',count,'inclusive_clock',clock,'total',count+clock)
print('Fraction scalar/antiderivative identities only; not a native field or a new capacity receipt.')
