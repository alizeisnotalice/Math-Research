from fractions import Fraction as F
from itertools import combinations, product
counts=[0,0,0]
# Native radial center-volume envelope, with exact infinite-tail integration.
for q,M in product([F(1,3),F(3,4),F(1),F(2)], [F(1,7),F(1),F(3),F(20)]):
    split=M/q
    inside=split/M
    outside=M/(q*q*split)
    assert inside+outside==2/q
    counts[0]+=1
    for t,excess in product([F(0),split/2,split,2*split,7*split], [F(0),M/3,M,4*M]):
        mass=q*t+excess
        if not mass: continue
        actual=min(M,mass)/max(M,mass)/mass
        envelope=F(1,M) if q*t<=M else M/(q*q*t*t)
        assert actual<=envelope
        counts[1]+=1
# Finite full-source matching incidences, exact inclusive physical clock.
# Quadrature receivers, not a native cube/capacity fixture.
sets=[set(c) for k in range(1,4) for c in combinations(range(3),k)]
for f,pattern,wp in product([(F(1),F(2),F(3)),(F(1,2),F(3),F(4))],range(3),range(2)):
    mass=[sum(f[y] for y in Q) for Q in sets]
    q=[F(3,4) if (i+pattern)%3==0 else F(1) for i in range(len(sets))]
    du=[F(1+(i+wp)%3,7) for i in range(len(sets))]
    mu=[du[i]/mass[i] for i in range(len(sets))]
    volumes=[mass[i]/q[i] for i in range(len(sets))]
    levels=sorted(set(volumes))
    clocks=[1/levels[k]-(1/levels[k+1] if k+1<len(levels) else 0) for k in range(len(levels))]
    X=sum(q[i]*du[i] for i in range(len(sets)))
    W=sum(f)
    Z=[sum(mu[i] for i,Q in enumerate(sets) if y in Q) for y in range(3)]
    empiricalC=[max(sum(mu[j]*min(mass[i],mass[j])/max(mass[i],mass[j]) for j,Q in enumerate(sets) if y in Q) for i in range(len(sets))) for y in range(3)]
    for H in [F(1,10),F(1,2),F(1),F(2),Z[0],Z[1]]:
        MH=low=NH=F(0)
        for vol,clock in zip(levels,clocks):
            inds=[i for i,v in enumerate(volumes) if v<=vol]
            for y in range(3):
                cap=[i for i in inds if y in sets[i]]
                J=sum(mu[i] for i in cap)
                if not J: continue
                V=sum(du[i] for i in cap)
                if J<H:
                    low+=clock*f[y]*V
                    continue
                minor=sum(mu[i]*mu[j]*min(mass[i],mass[j]) for i in cap for j in cap)
                ordered=sum(mu[i]*mu[j]*(mass[i]-mass[j]) for i in cap for j in cap if mass[i]>mass[j])
                assert ordered==J*V-minor
                # Atomic Gini layer cake, use adjacent distinct mass levels.
                ms=sorted(set(mass[i] for i in cap))
                gini=F(0)
                for a,b in zip(ms,ms[1:]):
                    cdf=sum(mu[i] for i in cap if mass[i]<=a)
                    gini+=(b-a)*cdf*(J-cdf)
                assert gini==ordered
                MH+=clock*f[y]*ordered/J
                NH+=clock*f[y]*minor/J
        assert MH+low+NH==X
        assert low<=H*W # lambda=1 in these fixtures.
        assert NH<=sum(f[y]*empiricalC[y]*Z[y] for y in range(3))/H
        assert 0<=MH<=X
        counts[2]+=1
print('PASS radial/pointwise/prefix:',*counts,'total:',sum(counts))
