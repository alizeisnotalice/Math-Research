#!/usr/bin/env python3
"""R677: exact positive-cell static witness routing; no root-order inference."""
from fractions import Fraction as F
from pathlib import Path
import hashlib,json,sys,platform,time
BASE=Path(__file__).resolve().parent

def f(x): return F(str(x))
def cube(n,x,s=1,y=0):
    return {'y':tuple([f(x)]+([f(y)] if n>=2 else [])+[F(0)]*max(0,n-2)), 's':f(s)}
def family(name,stage,n,kappa,rows):
    return dict(name=name,stage=stage,n=n,kappa=f(kappa), cubes=[cube(n,*r) for r in rows])
FIXTURES=[
 family('initial_line_half',1,1,'1/2',[(i/4,1) for i in range(4)]),
 family('initial_planar_three_halves',1,2,'3/2',[(i/2,1) for i in range(5)]),
 family('initial_3d_five_halves',1,3,'5/2',[(i/4,1,(i%2)/4) for i in range(7)]),
 family('boundary_touching_faces',2,2,'1/2',[(0,1),(2,1),(4,1),(6,1)]),
 family('equal_radius_many_saturation_cells',2,4,'3/2',[(i/4,1,(i%3)/4) for i in range(9)]),
 family('separated_cliques',2,3,'1/2',[(4*j+i/4,1) for j in range(3) for i in range(3)]),
 family('multiscale_upper_boundary',2,4,'1/2',[(0,4),('1/4',2),('1/2',1),('3/4','1/2'),(1,'1/4')]),
 family('larger_line_18',3,3,'5/2',[(i/4,1) for i in range(18)]),
 family('six_dim_reused_coordinates',3,6,'3/2',[(i/4,1,(i%3)/4) for i in range(12)]),
 family('rational_multiscale_12',3,4,'3/2',[(i/3,s,(i%2)/3) for i,s in enumerate([3,'5/2',2,'3/2',1,'3/4','2/3','1/2','1/3','1/4','1/5','1/6'])]),
]
# Avoid binary-float construction: all loop float inputs above have small denominators
# except i/3, which is replaced exactly before any geometry is used.
FIXTURES[-1]['cubes']=[cube(4,F(i,3),s,F(i%2,3)) for i,s in enumerate([3,'5/2',2,'3/2',1,'3/4','2/3','1/2','1/3','1/4','1/5','1/6'])]

def inside(z,A,dilate=F(1),strict=True):
    return all(abs(x-y)<dilate*A['s'] if strict else abs(x-y)<=dilate*A['s'] for x,y in zip(z,A['y']))
def masks(A,n):
    # Coordinate positive intervals, deduplicated by incidence; zero incidence
    # can be discarded because bitwise intersections can never restore a bit.
    state={(1<<len(A))-1:()}; coordcounts=[]
    for d in range(n):
        endpoints=sorted({C['y'][d]+sg*C['s'] for C in A for sg in (-1,1)})
        cm={}
        for lo,hi in zip(endpoints,endpoints[1:]):
            z=(lo+hi)/2
            mask=sum(1<<i for i,C in enumerate(A) if abs(z-C['y'][d])<C['s'])
            if mask: cm.setdefault(mask,z)
        coordcounts.append(len(cm)); new={}
        for old,p in state.items():
            for m,z in cm.items():
                both=old&m
                if both:new.setdefault(both,p+(z,))
        state=new
    for m,z in state.items():
        assert m==sum(1<<i for i,C in enumerate(A) if inside(z,C))
        assert all(z[d] not in {C['y'][d]+sg*C['s'] for C in A for sg in (-1,1)} for d in range(n))
    return state,coordcounts

def check_fixture(fi):
    n=fi['n']; a=32*n; w=F(1,a**n); tau=fi['kappa']*w;c0=1+F(1,a)
    A=sorted(fi['cubes'],key=lambda C:-C['s']);N=len(A)
    # stable radius sort preserves original tie order
    for i in range(N):
        for j in range(i):
            assert any(abs(A[i]['y'][d]-A[j]['y'][d])>(A[i]['s']+A[j]['s'])/a for d in range(n)), 'closed B cubes intersect'
    cells,cc=masks(A,n);ordered=sorted(cells,key=lambda m:(cells[m],m)); q=[]; maxes=[]
    def rate(m,stop):return sum((q[i] for i in range(stop) if m>>i&1),F(0))
    for j in range(N):
        maxpre=max((rate(m,j) for m in cells if m>>j&1),default=F(0))
        maxes.append(maxpre);q.append(min(w,max(F(0),tau-maxpre)))
        assert all(rate(m,j+1)<=tau for m in cells)
    admission=[sum((q[i] for i in range(j) if inside(A[j]['y'],A[i],c0,False)),F(0)) for j in range(N)]
    if any(x>1 for x in admission):return dict(name=fi['name'],rejected='original center admission fails',admission=admission)
    bv=[(2*C['s']/a)**n for C in A]; xv=[bv[i]*(1-q[i]/w) for i in range(N)]
    # Actual F_i is the left first-coordinate strip; X_i is the right remainder.
    strips=[]
    for i,C in enumerate(A):
        cut=C['y'][0]-C['s']/a+2*C['s']/a*q[i]/w
        strips.append(dict(left=C['y'][0]-C['s']/a,cut=cut,right=C['y'][0]+C['s']/a,F_volume=bv[i]*q[i]/w,X_volume=xv[i]))
    losses=[i for i,x in enumerate(q) if x<w]; policies={}
    for policy in ('canonical','maximize_unassigned_receiver_volume'):
        unassigned=set(losses);groups=[];assign={};previous_points=[]
        while unassigned:
            r=min(unassigned)
            candidates=[m for m in ordered if m>>r&1 and rate(m,r+1)==tau]
            assert candidates, 'loss has no positive-cell prefix witness'
            def members(m):return [h for h in sorted(unassigned) if h>=r and m>>h&1]
            if policy=='canonical':m=candidates[0]
            else:m=min(candidates,key=lambda m:(-sum((xv[h] for h in members(m)),F(0)),cells[m],m))
            z=cells[m];H=members(m)
            assert r==H[0]
            assert all(not inside(p,A[r]) for p in previous_points),'later anchor contains earlier point'
            assert all(not inside(p,A[h]) for p in previous_points for h in H),'later group member contains earlier point'
            positive=[i for i in range(N) if m>>i&1 and q[i]>0]
            assert all(i<=r and A[i]['s']>=A[r]['s'] for i in positive)
            assert rate(m,N)==tau
            statuses=[]
            for h in H:
                assert h not in assign
                if h>r:assert q[h]==0
                assert inside(z,A[h]) and rate(m,h+1)==tau
                far=sum((q[i] for i in positive if A[i]['s']>=n*A[h]['s']),F(0))
                upper=sum((q[i] for i in positive if F(n,2)*A[h]['s']<=A[i]['s']<n*A[h]['s']),F(0))
                status='far' if far>=tau/2 else ('upper_paid' if upper>=tau/8 else 'unpaid')
                if status=='unpaid':assert 2*A[r]['s']/n<A[h]['s']<=A[r]['s']
                statuses.append(dict(h=h,far=far,upper=upper,status=status))
                assign[h]=len(groups)
                # Entire B_h, hence X_h, lies in Q(z,c0*s_r).
                assert all(abs(A[h]['y'][d]-z[d])+A[h]['s']/a<=c0*A[r]['s'] for d in range(n))
            if statuses[0]['status']=='far':assert all(s['status']=='far' for s in statuses)
            env=(2*c0*A[r]['s'])**n;v=sum((xv[h] for h in H),F(0));assert v<=env
            groups.append(dict(anchor=r,members=H,witness=z,witness_mask=m,positive_sources=positive,final_rate=rate(m,N),members_rates=statuses,receiver_volume=v,clique_envelope_volume=env,clique_ratio=v/env))
            previous_points.append(z);unassigned.difference_update(H)
        assert sorted(assign)==losses
        policies[policy]=dict(groups=groups,group_count=len(groups),covered_losses=len(assign),all_checks_passed=True)
    return dict(name=fi['name'],stage=fi['stage'],n=n,N=N,a=a,w=w,tau=tau,kappa=fi['kappa'],c0=c0,c=c0**n,cubes=A,positive_masks=[dict(mask=m,representative=cells[m],prefix_loads=[rate(m,j) for j in range(N+1)]) for m in ordered],positive_mask_count=len(cells),coordinate_mask_counts=cc,q=q,prefix_esssup=maxes,source_center_admission=admission,source_center_prefix_loads=[[sum((q[i] for i in range(k) if inside(A[j]['y'],A[i],F(1),False)),F(0)) for k in range(N+1)] for j in range(N)],receiver_strips=strips,losses=losses,policies=policies,all_checks_passed=True)

def enc(v):
    if isinstance(v,F):return str(v)
    if isinstance(v,dict):return {str(k):enc(x) for k,x in v.items()}
    if isinstance(v,(tuple,list)):return [enc(x) for x in v]
    return v

def main():
    started=time.time();results=[]
    for fi in FIXTURES:
        try:res=check_fixture(fi)
        except Exception as e:
            res=dict(name=fi['name'],failure=repr(e));results.append(res);write(results,started);raise
        results.append(res)
        print(json.dumps(enc(dict(name=res['name'],stage=fi['stage'],masks=res.get('positive_mask_count'),losses=len(res.get('losses',[])),groups={k:v['group_count'] for k,v in res.get('policies',{}).items()},passed=res.get('all_checks_passed',False)))),flush=True)
        if fi['stage']==1 and fi==FIXTURES[2]:print('PHASE1_DONE: no algorithm failure detected',flush=True)
    write(results,started)

def write(results,started):
    passed=all(x.get('all_checks_passed') for x in results)
    obj=dict(title='R677 exact static finite-input witness routing',python=sys.executable,python_version=sys.version,platform=platform.platform(),script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),elapsed_seconds=time.time()-started,all_checks_passed=passed,fixture_count=len(results),fixtures=results,scope='Exact rational finite positive-volume arrangements. Low tau=kappa*(32*n)^(-n), kappa in {1/2,3/2,5/2}. Not tau=16384*sqrt(n), not R673/root-order proof. Dimensions 3,4,6 reuse last coordinates at zero; only first one or two centers vary.',checks=['closed B cubes disjoint; actual first-coordinate strips','original c0 center admission <=1; reject inadmissible','all realizable nonzero positive-volume membership masks and rational face-free representatives','all prefix rates <=tau and exact greedy qi','every loss assigned exactly once','later assigned h has qh=0','shared points are actual prefix-saturation witnesses','final positive sources at witness have i<=r, si>=sr, total tau','later group parents and members avoid earlier chosen points','far and upper sums recomputed for each member','unpaid: 2sr/n<sh<=sr','anchor far implies whole group far','all receiver boxes in Q(z,c0 sr); disjoint total volume <=c0^n*(2sr)^n'])
    (BASE/'WITNESS_RESULT.json').write_text(json.dumps(enc(obj),indent=2)+'\n')
    statuscounts={}
    for R in results:
        for p,P in R.get('policies',{}).items():
            C=statuscounts.setdefault(p,{})
            for G in P['groups']:
                for h in G['members_rates']:C[h['status']]=C.get(h['status'],0)+1
    text=f'''# R677 finite exact witness-routing check\n\nExecuted with `{sys.executable}` ({platform.python_version()}). Script SHA256 `{obj['script_sha256']}`.\n\n{len(results)} fixtures; all checks passed: **{passed}**. Two deterministic static finite-input policies: canonical face-free representative, and maximal remaining receiver volume with fixed rational tie order. Full inputs, rational masks/representatives, qi, prefix maxima, centers, strips and groups are in WITNESS_RESULT.json.\n\nAll nonzero positive-volume membership masks are constructed by per-coordinate endpoint intervals followed by bitwise intersection; no random point grid. Exact Fraction arithmetic is used throughout. Sources and receiver strips are actual cubes/boxes with pairwise disjoint closed small cubes (strip boundary choices are null sets). `c0=1+1/(32n)`, `c=c0^n`; actual receiver total is compared to `c*(2sr)^n`.\n\nMember classification totals by policy: `{statuscounts}`.\n\nThe fixtures span n=1,2,3,4,6, N<=18, touching faces, equal radii, multiple saturation cells, separated cliques and rational multiscale radii. For n>=3 the last coordinates of centers are zero: this does not explore independent center positions in every dimension. tau=kappa*(32n)^(-n), kappa in {{1/2,3/2,5/2}}, deliberately triggers losses. It is not the hard regime tau=16384*sqrt(n) and supplies no R673 or root-order estimate. No random/nonanticipative interpretation of the maximizing policy is claimed. Anchor-upper is never used to infer whole-group payment. These finite checks are not a proof over all families.\n'''
    (BASE/'NUMERIC.md').write_text(text)
if __name__=='__main__': main()
