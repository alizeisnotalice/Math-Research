# R677 S3 independent bounded review

Status: FINAL PASS within the bounded scope below. No mandatory mathematical correction found in the finalized report and three author notes. No global packing conclusion is certified.

## Scope and independence

Before reading author files, independently derived the static witness-routing implications, self/prefix chronology, recomputed far/up residual radius range, cross-scale overlap price and its unpaid-return limitation. The whole-group common-low-core proposal was also independently checked when supplied, before reading its author treatment. The inherited R660 full-prefix saturation/far theorem, R670 whole-family upper theorem, admission inequality and R673 short-sample theorem are accepted as supplied; their historical proofs are not reopened.

Only this review file is written. No source file, Git/PDF task, MATLAB session, subagent or numerical rerun is involved. The static fixture script was inspected, not executed. The large result JSON was not read in full and is not represented as a complete independent fixture audit.

## 1. Static chronology and the anchor self term

Let r be the earliest still-unassigned loss. A genuine loss has a positive-volume prefix-after-r saturation set inside A_r by the supplied R660 result. Refine by the faces of the ENTIRE finite family and choose z_r in one positive full-arrangement cell in that set. Membership in every parent, including future parents, is locally constant there. The a.e. final load bound therefore also applies at this representative.

Since the prefix through r already has load tau at z_r and all later increments are nonnegative, every i>r whose parent contains z_r has q_i=0. Thus the final positive source population

    P_a={i:q_i>0, z_r in A_i}

has all indices at most r, total rate exactly tau, and all source radii at least s_r. Every assigned later loss h has q_h=0. Its prefix through h has the same load tau at the shared point, so the witness is legal for its ORIGINAL static prefix. For h=r it is the prefix AFTER r, including a possible nonzero self term q_r; replacing this by a before-r identity would be wrong.

Every later group member avoids all earlier chosen points: otherwise it would already have been assigned when that earlier group was formed. This applies to later anchors and all their members. The construction can depend on the entire fixed finite input and does not assert randomized/nonanticipative legality. It changes neither original q nor E_i/F_i/X_h or their history.

The full-family positive-cell choice is essential to this argument; an arbitrary boundary point cannot be justified using only an a.e. cap.

## 2. New witnesses require new branch classifications

Far and upper sums must be recomputed for every member at its new shared witness. All positive sources there are P_a. For any residual member h after BOTH new payments, its far rate is strictly below tau/2 and its upper rate on [n s_h/2,n s_h) is strictly below tau/8.

If s_h<=2s_r/n, every source of P_a has radius at least n s_h/2. Then far plus upper would have total rate tau, contradicting the strict combined bound 5tau/8. Hence

    2s_r/n < s_h <= s_r.

The right inequality is original radius ordering. If the anchor is far, the same far sources remain far for every smaller member, so the whole group is far. Anchor-upper alone does not ensure all members are paid: moved mass can enter far without reaching the far threshold.

Reapplying the supplied far and whole-family upper tools once to the complete NEW classifications preserves their intended total account. Old near/residual labels must not be retained. New residual demand is distinguished from the previous round's Vrem. No old I_h or Poisson law is inherited from this deterministic re-witnessing.

## 3. One common low core for a nonempty NEW residual group

Let rho_min be the minimum remaining target radius, R_max the maximum, and s_r the original anchor radius. Define

    K=P_a intersect {i:s_i<n rho_min/2}.

At the minimum-radius residual member, the complement in P_a is exactly far plus upper, so q(K)>3tau/8. Every source radius is at least s_r, which dominates every member radius.

Delete the possible self label r. Since q_r<=w_r<=a^(-n), a=32n, the resulting K' has

    q(K')>3tau/8-a^(-n)>nu=5tau/16

in the stated n>=256 regime. All remaining indices are strictly below r, hence strictly before every group member h, including the anchor when it remains unpaid.

For any x in B_h intersect A_i with i in K',

    ||y_h-y_i||_infinity <=s_i+s_h/a <=(1+1/a)s_i.

The actual center-admission inequality for the ORIGINAL prefix therefore gives sum_{i in K'}q_i 1_Ai(x)<=1 on the ENTIRE B_h. This is precisely where deleting the anchor self term is needed to make the same prefix argument uniform over the group.

For every i in K' the exact geometric chain is

    2s_i/n < rho_min <= R_max <= s_r <= s_i.

This is a genuine shared core for the complete remaining group, without an equal-log subdivision. The definition requires a nonempty new residual group. It is a local hypothesis improvement, not a cumulative budget.

If the supplied R673 theorem is invoked with expansion radius R_max, all core parents contain the same group witness and have radii at least R_max. Every remaining receiver is within c0 R_max of that witness. Detection is deterministic, giving the local corollary V_group<=3exp(-2k)U_K'. No sum over different groups is licensed by this corollary.

## 4. Cross-scale captured union

Fix an earlier group a. Its full P_a has genuine common-point source rate tau and minimum radius at least s_{r_a}. For any later group b with q(P_a intersect P_b)>=4tau/5, one iid label drawn with law q_i/tau from P_a contains z_b with probability at least 4/5.

For every actual receiver in that later group, s_h<=s_{r_b}<=s_{r_a}, so its piece lies within z_b+c0 s_{r_a}Q. One shared k-tuple therefore detects that receiver with probability at least (4/5)^k. Actual receiver disjointness and Tonelli yield

    (4/5)^k |union_b Y_b| <=3 U_Pa exp(-2k),
    |union_b Y_b| <=3exp(-(2-log(5/4))k) U_Pa.

Different receivers' success events need not be independent. The later-group collection is fixed by the deterministic input, not adaptively selected after seeing the sampled tuple. This prices the full chosen union for ONE earlier group without a target count, but not the same sources' repeated prices across many earlier groups.

If the union is restricted to the NEW unpaid receivers, every such h also obeys s_h>2s_{r_a}/n. Otherwise all the >=4tau/5 overlap lies in that member's far-plus-upper region, whose total is strictly below 5tau/8. This stronger cross-scale confinement uses new unpaid status, not an obsolete residual label.

## 5. The global fee is still missing

Later parents avoid earlier witness points, but a large source parent can still return at many later anchors. Low-overlap or uncaptured returns are not priced by the displayed captured-union estimate. Even prices for disjoint receiver unions cannot be summed by repeatedly spending the same U_Pa without a genuine cumulative source-debit theorem. No such estimate follows from the above chronology, core or local R673 application.

## 6. Finite-computation boundary

Read NUMERIC.md and WITNESS_CHECK.py without executing them. The script builds realizable positive-volume parent membership masks from coordinate endpoint intervals, uses exact Fraction arithmetic, and checks the static greedy q chain, original center admission, actual disjoint B boxes/receiver strips, complete loss assignment, later q_h=0, prefix-after-h witnesses, positive-source timing, avoidance, recomputed member classifications, the residual radius implication, anchor-far implication and the actual clique envelope.

The stated ten fixtures use n in {1,2,3,4,6}, N<=18 and tau=kappa a^(-n), with kappa in {1/2,3/2,5/2}. Coordinates beyond the first two are reused at zero. They are finite static routing checks and do not test the n>=256 hard near regime, R673, the new whole-core theorem or a root-order estimate. No random/nonanticipative meaning is assigned to the maximizing finite-input policy. The result JSON was only partially viewed because of its size; full-fixture verification is not claimed.

## 7. Earliest-core multi-index cover: exact conditional reduction

Independently checked this additional proposition before reading an author treatment. Let m be a nonnegative multi-index on the finite positive source labels with |m|=k, including repeated-label multiplicities. Declare it eligible when its support is contained in at least one nonempty residual group's K'_a, and let a(m) be the earliest such group in original anchor order. Define

    H_m=(intersection_{i in support(m)} A_i)+c0 s_{r_a(m)} Q.

These are actual finite-parent intersections and Minkowski sums, hence measurable finite-volume sets. Eligibility makes the intersections nonempty. For k>=1 there is no empty-support convention to resolve.

Fix b, h in its NEW residual group, and y in X_h. Every multi-index supported in K'_b is eligible and has a(m)<=b. Original radius order gives s_{r_a(m)}>=s_{r_b}>=s_h. Its parent intersection contains z_b, so y belongs to H_m. The use of the ORIGINAL anchor radius is essential; a residual maximum radius from an earlier group need not dominate later groups' radii.

The exact multinomial identity therefore gives, for y in Y_b,

    sum_{eligible m} (q^m/m!) 1_H_m(y)
       >= sum_{|m|=k, support(m) subset K'_b} q^m/m!
        = T_b^k/k!,

where T_b=q(K'_b). All repeated-label multi-indices must be included. Since the actual receiver groups are disjoint, integration yields

    T_min^k V/k! <= S,
    S=sum_{eligible m} (q^m/m!) |H_m|.

Here V is the total NEW residual demand over the groups to which this construction is applied. The inequality would not follow by treating overlapping receiver copies as disjoint, but the supplied actual X_h partition has the required disjointness.

The proved core-rate bound implies T_b>kappa tau for kappa=119/320, since 3/8-kappa=1/320 and tau/320>a^(-n) in the stipulated regime. Consequently the CONDITIONAL estimate

    S<=C U tau^k exp(-2k)/k!

would give V<=C U(exp(-2)/kappa)^k. The factorials and tau normalization cancel exactly. This is a valid finite combinatorial/integral implication with no Poisson law or nonanticipative selection requirement.

No global bound on S has been established here. Assigning each multi-index to its earliest eligible core removes duplicate ownership of that multi-index; it does not by itself control the total enlarged-intersection volume or cumulative genuine source mass. Applying local short-sample bounds separately and summing still leaves a repeated-core/source cost. The displayed reduction is not certified as a completed packing result.

## 8. Final-report additions: full-P first hit and exact marking

Read the current REPORT chain and A1_ORDERED_WITNESSES.md after the independent derivations. Their stated static construction, new classification accounting, whole-core theorem, local/cross-scale prices and conditional core-key reduction agree with those derivations. The finalized report and author artifacts are bound by the SHA-256 list below.

First-core eligibility need not be a first spatial hit: a source parent can contain an earlier witness while being excluded from that earlier K' by cutoff or self deletion. Keeping the SAME core-eligible key set but selecting the earliest original group with support(m) subset P_b (including fully paid groups) corrects that issue. All earlier selected witnesses then lie outside the actual source intersection. The earlier anchor radius is at least the first-core anchor radius, so its full-P-first halo contains the core-first halo and S_full>=S_core. This is a valid larger kernel. It is not legitimate to combine the larger kernel's first-hit geometry with the smaller kernel's cost without an additional comparison. Both A1 and REPORT correctly retain this limitation.

For noneligible W_m=0, the exact source-marking identity is

    S_k=(1/k) sum_i q_i sum_{|v|=k-1}(q^v/v!) W_{v+e_i}.

For each |m|=k, the coefficient contributed by source i is m_i q^m/m!, and sum_i m_i=k. This proves the formula including repeated labels and the factor 1/k. Substituting q_i=|F_i|/d_i gives a genuine owner integral with that same outer factor. The selected first group still depends on the ENTIRE marked key v+e_i; the identity does not create iid remaining labels from a fixed eligible pool. No old conditional Poisson law is asserted.

Without halos, the original load bound gives only

    integral g^k/k! <=tau^(k-1)U/k!,

since integral g=U. The identity supplies no exponential short-sample gain for the differently expanded H_m. The report correctly records the global halo-key cost as unproved.

A1's additional ordered-avoidance consequence ||y-z_a||>(1-1/a_geom)s_h for a later receiver follows from z_a outside its original A_h and y in B_h. The box hull of x and a later witness lies inside their common representative parent, so excludes earlier witnesses. Neither consequence proves disjoint key halos or a dimension-free group count. The earlier-source admission bound on a tagged owner's B_i follows from original radius order and the same center-dilation argument; transport from that small box to moving key witnesses remains unproved.

## 9. Supplementary finite-key source inspection

Read KEY_CHECK.py's complete algorithm and the KEY_RESULT.json header/metadata, not the full large JSON. It reuses WITNESS_RESULT.json without rerunning the original fixture generation. For degrees 1,2,3 it enumerates all unordered label multisets with repetitions, verifies ordered-tuple multiplicities and multinomial coefficients, deduplicates complete multi-indices (not merely their supports), selects earliest eligibility in the ORIGINAL full P populations, and checks containment of each closed B_h in the actual earliest-anchor halo.

The metadata reports 264 group-degree identities, 276 deduplicated keys (180 with repeated labels), 806 supported group/key relations, and 1318 receiver-box containments over ten fixtures/twenty policy families. This matches REPORT's stated scope and counts. It tests full-P low-threshold finite routing with original anchor radii, not the high-threshold K' construction, R673, the global halo budget or a root-order estimate. No numerical script was rerun by this reviewer. Script/input hashes and the final report will be included in the final binding rather than treating metadata or hashes as mathematical proofs.


## 10. Final S2 global-key comparison and disposition

Read S2_GLOBAL_KEY.md in full. Its finite ordered-tuple normalization, union of nested earliest-anchor halos, k=1 sanity check, exact owner-Palm kernel and unexpanded-capacity inequality agree with the deductions above. It correctly distinguishes total spatial load tau from the unrestricted all-family sum of q_i.

Its pure single-label diagonal payment is also valid: q_i<=a^(-n) gives

    S_diag<=[a^(-n(k-1))(1+c0)^n/k!] U.

For the intended k>=2048 this coefficient is at most 1/k!, while 3exp(-2k)tau^k>1. Thus those pure diagonals fit within the stated candidate global scale. This does not bound mixed keys with repetitions or distinct-label keys. The author explicitly leaves the main sum unpaid and does not use the k=1 envelope as a lower bound or counterexample.

KEY_SUMMARY.json was read in full. Its recorded KEY script hash and WITNESS input hash match the actual source hashes below. Its counts/scope match the report and the inspected KEY algorithm. WITNESS_RESULT.json and the reproducible full KEY_RESULT.json were not manually checked item by item; only metadata, selected visible contents and source algorithms were inspected. The supplementary check did not rerun the original experiment, as recorded in the compact summary. No numerical calculations were rerun by this reviewer.

Final PASS covers: historically legal static routing and self correction; fresh far/up payment accounting; the nonempty whole-group common low core; local and cross-scale union prices; exact core-key weighted coverage; full-P versus core-first distinction; source-marking/Palm normalization; pure-diagonal subpayment; and report/source/metadata consistency within the finite evidence scope. Historical tools are accepted as supplied. The global expanded-key budget, mixed-key settlement, cumulative source reuse, general root bound and any impossibility/counterexample claim are NOT certified. The unchanged complete account retains the NEW residual demand.

## Final artifact binding

All paths below are under /Volumes/data/CodexTemp/centered-cube-r677-20261115. SHA-256 values were read from the actual finalized files after the final author comparison:

- REPORT.tex: e085caeb2617be5f74882bfd0566971f00ada616c2e8d0880683c7147b43884b
- A1_ORDERED_WITNESSES.md: 574c50f4a234c9c4091beb4add190c8af644b70849d66265525fbeec8dbb6e19
- S2_WITNESS_CONSTRUCTION.md: 63432278f37f74e4e1d075e98d789f62d20bde7e52cb7dc219c0ba5bf5931f3b
- S2_GLOBAL_KEY.md: 3d61f3da508ecd1059f52aa5b9048e671f57b2a57fbd5668fb3073ccdaaa0d65
- WITNESS_CHECK.py: 6ce6d46f9425e03b7519ecb7fa9e8b8aea6e324768c3d217b44fe72d792c9da4
- WITNESS_RESULT.json: 51133281e98e46889690d01d1a3a47a114c6dad79ec123cb9d3929f95e16d642
- KEY_CHECK.py: 93bf066bcdc4587030cacc2c23ee9dc819998dcccce7a3cb651c8feeb119cfcf
- KEY_SUMMARY.json: 181fcc8cec2907cec559e87d74a075ae2858af38c777cd75600cdfc54d94da02

Hashes bind reviewed artifacts; they do not certify mathematical correctness or full JSON data independently. Only S3_REVIEW.md was edited by this reviewer. Bounded task complete; no further route is opened.
