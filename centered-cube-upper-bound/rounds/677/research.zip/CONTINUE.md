# R677 checkpoint and reproduction

General pure square-root bound is unproved. Preserve full original-family P0 and new residual classification. Next: prove an actual joint first-hit halo-key budget, or an adequate original-family packing alternative. Do not spend another round optimizing Poisson scalar constants, generic clique dilation or only single-group estimates.

Read REPORT.tex, then A1_ORDERED_WITNESSES.md for the exact distinction between core eligibility and full-population spatial first hit. S2 files prove chronological legality and identify the source-marked kernel. The decisive estimate (G) is UNPROVED. Ordered exclusion alone has not bounded source reuse. Full-P first-hit halos can be larger than core-first halos; no free comparison in the opposite direction.

Execution: `/Users/zzh/.local/share/math-research-tools/venv/bin/python verify.py` checks archived integrity. `WITNESS_CHECK.py` reproduces the finite actual-cube routing experiment and writes WITNESS_RESULT.json/NUMERIC.md. Then `KEY_CHECK.py` reproduces the exact finite key check and writes KEY_RESULT.json. Its 2.2 MB detailed output is intentionally not archived; KEY_SUMMARY.json retains the executed totals and script/input hashes. Timing/platform metadata means regenerated file hashes need not equal original hashes. Compare mathematical results, not volatile timestamps. All calculations use standard-library Fraction rational arithmetic. No MATLAB session or PDF was created.

These fixtures use low tau, not the hard root-regime threshold. The k=1,2,3 key calculations use full P_a, not K'_a; they test routing and factorial coefficients, not (G). Do not infer a high-dimensional estimate from them.

Only 1 Astra and 3 GPT-6.1 Sol may be active at once under the current user configuration. Reuse existing agents with precise tasks. Current work is under the data-volume temp directory; repository receives only a round README, compact research.zip and the project README update. Complete independent review and verify before committing; preserve one commit per round and verify remote receipt.
