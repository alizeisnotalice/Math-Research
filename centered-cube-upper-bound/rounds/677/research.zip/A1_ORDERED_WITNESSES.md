# R677 A1 — ordered witnesses and the first-eligible-key budget

## Status

The newly aligned common-source groups support a genuine cross-scale joint certificate and a deterministic weighted-key cover of the complete remaining receiver. The global key cost is not bounded here. This note records that exact cost, its possible source-owner budget, and the obstruction encountered when trying to freeze a smallest-radius owner layer. No full V_0/P_0<=C sqrt(n) conclusion is claimed.

The legal ordered construction and its reclassified far/upper payments are separately audited by the parent and Sol. They are hypotheses of the deductions below; their proofs are not duplicated. Original q, owner pieces, radius order and prefix saturation are unchanged. All new sampling, if mentioned, is auxiliary and does not alter the original process.

## 1. The aligned data used in the argument

Write a_geom=32n, c0=1+1/a_geom, c=c0^n, tau=16384 sqrt(n), and k=ceil(128 sqrt(n)), in the nonempty regime n>=256.

Ordered groups have anchors r_a in increasing original index, so s_{r_a} is nonincreasing. Their points z_a lie in positive-volume genuine prefix-saturation cells. The complete active positive source pool is

    P_a={i<=r_a:q_i>0, z_a in A_i},
    sum_{i in P_a}q_i=tau,
    s_i>=s_{r_a} for i in P_a.                              (1)

No later positive source can contain z_a, so P_a also equals the set of all final positive sources containing z_a. Every parent assigned to group a contains z_a. A later group's target parents avoid every earlier chosen z_b. Reassigned target witnesses are exactly the corresponding z_a.

After recomputing far and upper classifications, let H_a be the remaining targets of a nonempty group, r_min,a=min_{h in H_a}s_h, and Y_a=union_{h in H_a}X_h. These actual sets partition the whole remaining receiver Y. The inherited one-time far/upper fees are separate. The new common core, with the possible anchor-self label deleted, is

    K'_a=(P_a intersect {i:s_i<n r_min,a/2})\{r_a},
    T_a=sum_{i in K'_a}q_i >3tau/8-a_geom^(-n).              (2)

Every source in K'_a strictly precedes every target in H_a. It contains z_a, has radius at least s_{r_a}, and g_{K'_a}<=1 throughout every corresponding B_h. In particular the whole group has 100-percent common-core capture, including all its actual target scales.

The radius used below is always the **original anchor radius s_{r_a}**. The maximum radius of the remaining members after classification need not be nonincreasing between groups and cannot replace s_{r_a} in an earliest-key construction.

Two direct consequences of the ordered avoidance are useful scope constraints. If b>a, h belongs to group b, and y is in X_h, then

    ||y-z_a||_infinity >(1-1/a_geom)s_h,
    ||y-z_b||_infinity <=c0 s_h.                            (3)

The exclusion radius is the later target's own s_h, not the earlier anchor radius. It therefore does not give disjoint early-anchor balls. Also, if a fixed x lies in representative A_{r_b}, then the box hull of x and z_b is contained in A_{r_b}; hence no earlier z_a lies in that hull. This yields an orthant-wise forbidden coordinate order when several representatives contain x. It does not exclude antichains or establish a dimension-free count.

## 2. A valid cross-scale joint capture statement

For an earlier group a and any collection of later groups b satisfying

    sum_{i in P_a intersect P_b}q_i >=(4/5)tau,              (4)

one iid k-sample from P_a detects each group's entire actual receiver with probability at least (4/5)^k. All later target radii are at most s_{r_a}; the sampled source radii are at least s_{r_a}. Thus the same halo parameter s_{r_a} is legal for every detected group. The R673 theorem gives

    |union of those actual Y_b|
       <=3 exp[-(2-log(5/4))k] U_{P_a}.                     (5)

This is one joint price for the union, not a sum of individual group prices. It uses true receiver disjointness when integrating the individual detection probabilities. No common source containing every later witness is required for (5).

The certificate is genuinely cross-scale; no n-fold target subdivision is needed here. Nevertheless selecting uncaptured anchors merely forces a quantitative profile miss. It does not bound reuse of a shared old source, so (5) is not the global budget.

## 3. A deterministic first-eligible-key cover

Let m=(m_i) be a nonnegative integer multiindex, |m|=k, with finite support. Repeated occurrences of a source are retained. Set

    q^m=product_i q_i^(m_i),       m!=product_i m_i!.

Call m eligible if its support is contained in K'_a for at least one nonempty remaining group. Define

    a_core(m)=min{a:support(m) subset K'_a},
    H_m^core=(intersection_{i in support(m)} A_i)
                  +c0 s_{r_{a_core(m)}} Q,
    W_m^core=|H_m^core|,
    S_k^core=sum_{eligible m} (q^m/m!) W_m^core.             (6)

The family is finite. Every intersection in (6) is nonempty, contains the corresponding witness, and its source radii are at least the indicated halo parameter.

For y in an actual Y_a, every multiindex supported on K'_a has a_core(m)<=a. Its intersection contains z_a and its halo radius is at least s_{r_a}, hence at least the radius of the actual target containing y. Therefore y belongs to H_m^core. The multinomial formula gives the pointwise weighted cover

    sum_{eligible m}(q^m/m!) 1_{H_m^core}(y)
       >= sum_{support(m) subset K'_a, |m|=k} q^m/m!
       =T_a^k/k!.                                         (7)

Put T_*=3tau/8-a_geom^(-n)>0. Integration, preserving the actual disjoint Y_a, yields

    T_*^k V_rem/k! <=S_k^core.                             (8)

This is stronger than lowering the multi-key coverage to a single Poisson success event. No Poisson clock, median estimate, Stirling approximation, or 1/e threshold is needed. An earlier exploratory entropy-window calculation incurred that unnecessary probability loss; it is not used as a new mechanism here.

The local theorem separately supplies, for each fixed a,

    sum_{|m|=k, support(m) subset K'_a}
       (q^m/m!) |(intersection_{support(m)}A_i)+c0s_{r_a}Q|
       <=3 U_{K'_a} T_a^k exp(-2k)/k!.                     (9)

Dropping the first-eligibility restriction in (6), then using (9), only returns a repeated sum of U_{K'_a}. It does not establish a global bound.

A concrete, stronger-than-necessary sufficient global owner inequality is

    S_k^core <=C0 U tau^k exp(-2k)/k!,                      (G)

with absolute C0. Together with (8), it would give

    V_rem<=C0 U [exp(-2)tau/T_*]^k.                         (10)

More generally, a bound S_k^core<=C T_*^k tau P0/k! would directly pay the desired remaining volume using the full original-family packing optimum P0. Neither this broader bound nor (G) is proved here. Formula (G) is an accurately normalized missing proposition, not a consequence of (9) or of the original q-load bound.

## 4. First core eligibility is not automatically a spatial first hit

There is a distinction relevant to any attempted record or disjointness argument. If an earlier b is not eligible for m in (6), then a source can be missing from K'_b because of the upper-scale cutoff n r_min,b/2 or the deleted anchor-self label. Its parent need not avoid z_b. Thus the first-core index in (6) is not automatically the first chosen witness inside the source intersection.

A legal spatial-record variant is available. Keep the eligible key set from (6), but set

    a_full(m)=min{b:support(m) subset P_b},
    H_m^full=(intersection_{support(m)}A_i)
                  +c0 s_{r_{a_full(m)}}Q.                  (11)

The minimum can run over every original ordered group, including groups with no remaining members after reclassification. It exists and is at most a_core(m). All its source radii are at least s_{r_{a_full(m)}}. By (1), every earlier witness lies outside the key intersection. This is an actual first spatial hit.

The halos in (11) are at least as large as those in (6), and the same weighted-cover proof works. Consequently

    S_k^full>=S_k^core,
    T_*^k V_rem/k!<=S_k^full.                              (12)

Proving the analogue of (G) for S_k^full would suffice but is stronger. One cannot use the first-hit geometry of (11) while retaining the smaller cost from (6) without proving a comparison that pays this halo change. No such comparison or global estimate is asserted.

## 5. The smallest-owner layer does not yet fix the moving witness

The attempted owner tagging was to assign each key its largest original source index i. This fixes a smallest-radius source (ties resolved by the original order); all other key labels are earlier. Layering d_i, or its genuine owner mass q_i d_i, makes that charge explicit, but neither tag determines a_core(m) or a_full(m). Changing another key label can change the earliest eligible group and its halo, even when the tagged source and its mass layer are unchanged.

The ordinary q-load bound does give a valid fixed-point tensor estimate. For example,

    integral_{A_i} (sum_j q_j 1_{A_j}(x))^(k-1) dx
       <=tau^(k-1)d_i.                                    (13)

It counts unexpanded common intersections. The cost in (6) is their halo volume, not their intersection volume. A positive-volume saturation cell can be arbitrarily thin; no uniform ratio between those two volumes has been established. Replacing (13) by the corresponding expanded-parent field reintroduces an uncontrolled spatial expansion. The coarse containment H_m subset A_i+c0 s_i Q only gives the exponential volume (1+c0)^n d_i.

Actual source-center admission even gives low earlier-source load throughout the tagged source's small owner box: for u in B_i,

    sum_{j<i}q_j1_{A_j}(u)<=1,

by the original expanded-center admission test and s_j>=s_i. This is retained, but the common key witness can be elsewhere in A_i. There is no proved owner-to-witness transport estimate converting this small-box bound, the original global load tau, and the first-hit condition into (G).

For the spatial-record version, earlier chosen witnesses lie outside each key intersection; this still does not make different key halos disjoint. Distinct keys can have different first groups and overlap. For the core version even the first-hit statement needs the correction in Section 4. These are the precise reasons that a fixed owner tag and its original q-capacity do not yet supply the required global factorial count.

## Checkpoint and stop

The ordered alignment repairs the R676 source-capture mismatch and gives the valid full-scale formulas (5) and (8). The remaining mathematical task is an actual global halo-key estimate such as (G), or an adequate full-original-family packing substitute. It has not been proved in this bounded task. No source repetition, key multiplicity, owner mass, halo radius, or scale-exclusion cost is omitted from the stated missing proposition.

No new scalar computation was needed: the multinomial identity removes the proposed Poisson probability loss exactly. No historical scan, child agent, Git operation, PDF, MATLAB session, or edit to another agent's file was performed. Work stops here for independent review and integration.
