# R677 S2 — first-eligible global k-key budget: exact kernel, diagonal payment, open main sum

**Status.** The proposed full sum bound

    S<=3exp(-2k) tau^k U/k!                                (1)

is not proved or refuted in this bounded task. The exact source-Palm identity below isolates the unpaid selection kernel. Pure one-label diagonals are globally paid, but they do not replace the MAIN sum or control mixed/distinct-label keys. No pool-by-pool iid price is summed as a proof of (1).

The original anchor radius must be used: rho_a=s_{r_a}, not the largest remaining radius R_a. The rho_a are nonincreasing in anchor order. The remaining R_a need not be monotone.

Only this assigned new file is written. No source data, earlier proof file, Git state, agent tree or numerical process is changed. Further local factorial or threshold estimates are not pursued.

## 1. Precise finite sum and radius

Let K'_a be the proved whole-group cores, ordered by their original anchors r_a. They consist of positive-q original labels, have rate greater than nu, and every source in K'_a has radius at least rho_a. The original all-space load is

    Q(x)=sum_i q_i1_{A_i}(x)<=tau a.e.,
    U=sum_i q_i d_i.

For a nonnegative integer multi-index m with |m|=k>=1, call it eligible if its support lies in at least one K'_a. Define

    a(m)=the earliest such group,
    I_m=intersection_{i:m_i>0}A_i,
    W_m=|I_m+c0rho_{a(m)}[-1,1]^n|,
    q^m/m!=product_i(q_i^(m_i)/m_i!).

Eligibility ensures I_m is nonempty. The exact candidate is

    S=sum_{|m|=k, eligible} (q^m/m!)W_m.                    (2)

All sums are finite. At the intended theorem parameters, n>=256 and k=ceil(128sqrt(n)). The original all-family rate sum need not be at most tau; tau bounds the spatial q load, not sum_iq_i.

For a fixed eligible key, all its eligible group witnesses lie in I_m. Because rho_a is nonincreasing,

    I_m+c0rho_{a(m)}Q
       =union_{a:support(m) subset K'_a}
             (I_m+c0rho_aQ).                               (3)

Thus the first-eligible convention keeps the largest of these nested halo regions and avoids a separate charge for every eligible group. Equation (3) would not be justified by earliest remaining R_a.

The coefficient q^m/m! is also exact: there are k!/m! ordered label tuples with multiplicities m. Therefore

    S=(1/k!)sum_{eligible ordered k-tuples}
          (product_j q_{i_j})W_{multiset(i_1,...,i_k)}.      (4)

Repeated labels alter this coefficient but not the geometric intersection.

## 2. k=1 sanity check

For a positive source i appearing in a core, let a_i be its first such group. At k=1, equation (2) is exactly

    S_1=sum_{eligible i}q_i |A_i+c0rho_{a_i}Q|
       =sum_{eligible i}q_i d_i
            (1+c0rho_{a_i}/s_i)^n.                         (5)

There is no extra factorial, completion factor, or T_a normalization. Since rho_{a_i}<=s_i, the immediate envelope is (1+c0)^nU.

The R673 exponential short-sample theorem is NOT an all-k theorem and is not applicable at k=1. Accordingly (5) is a normalization/selection check, not a claim that the intended fixed-k inequality (1) fails. Nor is its large envelope a lower bound on S_1.

## 3. Pure repeated-label keys are globally paid

For the pure diagonal m=k e_i, the first eligible group is again a_i and the halo is the same as in (5). Hence

    S_diag=(1/k!)sum_{eligible i}q_i^k d_i
                      (1+c0rho_{a_i}/s_i)^n
       <=a^(-n(k-1))(1+c0)^n U/k!,   a=32n.                (6)

This uses the original genuine-owner bound q_i<=a^(-n), once. For the intended k>=2048, even the simpler bound S_diag<=U/k! suffices: k>=2, a>=32 and 1+c0<=3 imply a^(-n(k-1))(1+c0)^n<=1.

Also e^2<9 and tau>=16384, so

    3exp(-2k)tau^k=3(tau/e^2)^k>1.

Thus the pure diagonals satisfy the entire right-side scale of (1). This does NOT prove the corresponding claim for all keys containing some repeated label, and does not control the main sum of mixed or distinct labels. No such extension is asserted.

## 4. Exact owner-Palm identity and the missing selection kernel

For any eligible m of total size k,

    sum_{i:m_i>0} q_i q^(m-e_i)/(m-e_i)!
       =k q^m/m!.

Consequently the full sum has the identity

    S=(1/k)sum_i q_i
        sum_{|ell|=k-1, ell+e_i eligible}
                (q^ell/ell!) W_{ell+e_i}.                  (7)

Define

    Gamma_i=(1/d_i)
        sum_{|ell|=k-1, ell+e_i eligible}
                (q^ell/ell!) W_{ell+e_i}.

Using the TRUE source owner |F_i|=q_i d_i, (7) becomes

    S=(1/k)sum_i |F_i| Gamma_i.                            (8)

This is a real source-mass accounting identity, not a fresh probability law on owners or keys. When U>0, the desired bound would require the weighted average in (8) to be at most

    [sum_i|F_i|Gamma_i]/U
       <=3exp(-2k)tau^k/(k-1)!.                            (9)

Equation (9) is recorded only to specify the exact unpaid kernel; it is not proposed as a renamed achievement.

The obstruction to applying the allowed iid theorem to Gamma_i is precise:

- The earliest eligible population is a(ell+e_i), a function of the COMPLETE other k-1 labels.
- Fixing i does not make those other labels iid from any one fixed common-point core.
- Taking the union of all cores containing i does not cure this: their witnesses lie in A_i, but the union's other parents are only known to contain their respective witness. They need not have one common point, and its total rate is not bounded by the old pointwise tau.
- Integrating over F_i merely records q_i d_i. It neither supplies that missing common-point population nor removes the selection dependence of the halo radius.

Replacing the selected population by separately priced fixed cores loses the sharing already represented by (3) and returns a repeated-source sum. Factoring selection probability from W is unjustified, because both depend on the same full label tuple. No such step is used.

A uniform sourcewise bound on Gamma_i would be sufficient but is not claimed necessary; only its actual owner-weighted mean is sought in (1).

## 5. What original pointwise q capacity pays directly

Let S_0 be (2) with W_m replaced by the UNEXPANDED |I_m|. Nonnegative integration and (4) give

    S_0
      <=(1/k!)integral Q(x)^k dx
      <=tau^(k-1)U/k!.                                    (10)

This retains the original all-space packing cap exactly. But compared with (1), the elementary certificate (10) is still larger by the missing exponential-scale gain; it does not produce the factor 3tau exp(-2k). A large upper certificate is again not a lower bound on S_0 or a disproof of (1).

The nonnegative halo remainder S-S_0 is also unpaid. Source-dependent expansion cannot be replaced by the original Q(x): membership in A_i+c0rho_{a(m)}Q depends on both the source and the complete key's selected group. A single common original-parent pointwise multinomial identity is therefore unavailable for the expanded integral.

## 6. Bounded stop

The exact first-eligible convention, factorial normalization, k=1 check, owner-Palm identity and pure-diagonal payment are established. They leave the full selected-key kernel in (7)-(8) unpaid. The allowed local iid estimate does not by itself control that global conditional geometry.

No new global bound, counterexample, poolwise-sum closure, or factorial optimization is claimed. The main report's complete-budget status remains open. This task stops here so the next effort can focus on the larger genuine spatial first-encounter geometry, rather than more local multiplicity bookkeeping.

