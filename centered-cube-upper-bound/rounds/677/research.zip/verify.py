from pathlib import Path
import ast,hashlib,json,re
p=Path(__file__).resolve().parent
names=['WITNESS_CHECK.py','KEY_CHECK.py','verify.py']
for n in names:ast.parse((p/n).read_text())
w=json.loads((p/'WITNESS_RESULT.json').read_text());k=json.loads((p/'KEY_SUMMARY.json').read_text())
assert w['all_checks_passed'] and k['all_checks_passed']
assert len(w['fixtures'])==10 and sum(x['positive_mask_count'] for x in w['fixtures'])==223
for stem,obj in [('WITNESS',w),('KEY',k)]:assert obj['script_sha256']==hashlib.sha256((p/(stem+'_CHECK.py')).read_bytes()).hexdigest()
assert k['input_sha256']==hashlib.sha256((p/'WITNESS_RESULT.json').read_bytes()).hexdigest()
assert k['totals']==dict(fixtures=10,policy_families=20,group_degree_identities=264,deduplicated_keys=276,supported_group_keys=806,receiver_halo_containments=1318,repeated_label_keys=180)
s=(p/'REPORT.tex').read_text();stack=[]
for m in re.finditer(re.escape(chr(92))+r'(begin|end)\{([^}]+)\}',s):
 if m[1]=='begin':stack.append(m[2])
 else:assert stack and stack.pop()==m[2]
assert not stack
review=(p/'S3_REVIEW.md').read_text()
for n in ['REPORT.tex','A1_ORDERED_WITNESSES.md','S2_WITNESS_CONSTRUCTION.md','S2_GLOBAL_KEY.md','WITNESS_CHECK.py','WITNESS_RESULT.json','KEY_CHECK.py','KEY_SUMMARY.json']:
 assert hashlib.sha256((p/n).read_bytes()).hexdigest() in review,n
if (p/'MANIFEST.json').exists():
 for n,v in json.loads((p/'MANIFEST.json').read_text())['members'].items():
  b=(p/n).read_bytes();assert len(b)==v['bytes'] and hashlib.sha256(b).hexdigest()==v['sha256']
print(json.dumps(dict(pass_integrity=True,manifest_checked=(p/'MANIFEST.json').exists(),scope='integrity, recorded finite counts and source bindings; not a proof checker')))
