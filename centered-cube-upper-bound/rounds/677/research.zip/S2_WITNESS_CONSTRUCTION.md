# R677 S2 — historically legal shared saturation witnesses and whole-group low cores

**Proved construction.** Keep the original R660 recursion, q, E_i, F_i and X_i fixed. Static reselection of the saturation witnesses yields ordered groups of ALL positive-loss labels with a shared historically legal witness z_a. Their full final positive source population P_a has rate exactly tau, comes entirely from labels i<=r_a, and has s_i>=s_{r_a}; the self source r_a is included when positive.

After recomputing far and upper-rim classes from THESE witnesses, every unpaid group has radii

    2s_{r_a}/n < r_min,a <= s_h <= R_a <= s_{r_a}.

It admits the WHOLE-GROUP common core

    K_a=P_a intersect {i:s_i<n r_min,a/2},
    K'_a=K_a minus {r_a},

with

    T(K_a)>3tau/8,
    T(K'_a)>3tau/8-a^(-n)>nu=5tau/16.                       (1)

Every i in K'_a is strictly before every group target, contains the shared witness, and satisfies

    2s_i/n<r_min,a<=R_a<=s_{r_a}<=s_i.                      (2)

Consequently the original center admission proves g_{K'_a}<=1 on EVERY whole receiving box B_h in that group. No equal-log target-radius subdivision is needed for these whole-group properties.

These are new simultaneous geometry/ordering properties compared with an arbitrary target-clique cover. They do NOT prove a common global packing or a paid repeated-source total. The exact reclassified receiving account and remaining debit are given below.

## 1. Original fixed state and the full arrangement

Write a=32n, c0=1+1/a, c=c0^n<=32/31 and tau=16384sqrt(n). The original family is ordered by nonincreasing radius with its original tie order. Its fixed recursion is

    w_j=|E_j|/d_j,  d_j=(2s_j)^n,
    ell_j=ess sup_{A_j} sum_{i<j}q_i1_{A_i},
    q_j=min(w_j,(tau-ell_j)_+).

Genuine disjoint F_j subset E_j subset B_j have |F_j|=q_jd_j, and X_j=E_j minus F_j. Let H consist of the actual loss labels |X_j|>0, equivalently q_j<w_j. Zero-volume loss pieces play no role.

The already proved original all-space feasibility is

    sum_i q_i1_{A_i}<=tau a.e.,   P0>=U/tau,
    U=sum_iq_id_i.

Use the finite full arrangement of ALL original parent faces, not just an old prefix arrangement or an old witness list. For any loss label r, ell_r+q_r=tau. A positive-volume prefix membership cell inside A_r attains ell_r. Refining by the remaining original faces leaves a positive-volume full-arrangement cell on which

    sum_{i<=r}q_i1_{A_i}=tau.                               (3)

Choose a point in such a cell, avoiding every original parent boundary. This is possible because the input is finite.

## 2. Group ALL losses by earliest unassigned labels

Start with every label in H unassigned. Repeatedly:

1. Choose the earliest unassigned loss label r_a.
2. Choose z_a as in (3) for r_a.
3. Assign to this group EVERY currently unassigned h with h>=r_a and z_a in A_h.
4. Give all assigned labels the shared auxiliary witness z_h=z_a.

The seed is assigned, so this finite construction terminates. It partitions the same original actual loss pieces. Nothing about q or owner selection is rerun.

### 2.1 Later assigned labels have zero q

Suppose h>r_a and z_a in A_h. Because z_a avoids all parent faces, a positive-volume full-arrangement neighborhood lies in A_h and has the prefix-r_a load tau. The prefix before h therefore has load at least tau there. Original feasibility gives ell_h<=tau, so ell_h=tau and q_h=0.

Equivalently any later positive-q parent containing z_a would make final load exceed tau on a positive-volume cell, contradicting original feasibility. This argument uses the entire neighborhood, not a measure-zero saturation point.

Define

    P_a={i:q_i>0 and z_a in A_i}.

The same argument gives

    P_a subset {i:i<=r_a},
    sum_{i in P_a}q_i=tau,
    s_i>=s_{r_a} for every i in P_a.                       (4)

The seed self source r_a may have positive q_r_a; it is not dropped from (3)-(4). A later assigned loss h>r_a has q_h=0.

### 2.2 Every assigned witness is historically legal

For every assigned h, z_a lies in the interior of A_h. All final positive parents containing it come from P_a and have labels i<=r_a<=h. Their prefix load including the current h is exactly tau. Thus z_h=z_a is a legitimate complete prefix-saturation witness for h, in the original historical order.

All parents A_h of the group contain z_a; all source parents in P_a contain the SAME shared witness. For y in X_h,

    ||y-z_a||_infinity<=s_h/a+s_h=c0s_h.                    (5)

The original receiver pieces remain disjoint.

### 2.3 Ordered exclusion of earlier chosen points

When a group is formed, it takes every remaining loss parent containing z_a. Therefore every target parent in every LATER group avoids z_a. In particular later representatives avoid earlier chosen points.

This is stronger than merely partitioning an arbitrary family into parent cliques. No symmetric exclusion or disjointness of group source populations follows from it.

## 3. Recompute every classification; no old class is inherited

For a newly assigned h in group a, define using its NEW shared witness

    F_h^rate=sum_{i in P_a:s_i>=n s_h}q_i.

Call h FAR if F_h^rate>=tau/2. Otherwise its exact near pool is

    I_h^new={i in P_a:s_i<n s_h},
    T(I_h^new)=tau-F_h^rate>tau/2.                          (6)

All P_a sources already have s_i>=s_{r_a}>=s_h, so no missing lower-radius restriction is hidden in (6).

Among the new nonfar labels define

    R_h^up=sum_{i in P_a:n s_h/2<=s_i<n s_h}q_i.

Call h UPPER-RIM when R_h^up>=tau/8. The remaining labels form H_rem^new, and

    V_rem^new=sum_{h in H_rem^new}|X_h|.

This need not equal the old Vrem, nor be a subset of the old class. The new labels are classified afresh from the shared witnesses. No old source pools, auxiliary keys or completion/flux law is silently inherited.

### 3.1 Far payment, once globally

For a newly far h and y in X_h, (5) shows that every source in its far population satisfies

    y in (1+c0/n)A_i.

Therefore the original q load in that fixed dilation is at least tau/2 throughout the union of the new far receiver pieces. Integrate the actual disjoint pieces ONCE:

    V_far^new<=[2(1+c0/n)^n/tau]U
              <=K_far U/tau,
    K_far=2exp(33/32).                                     (7)

This is the original proof with newly chosen legal witnesses, not an appeal to an old classification. Each actual original source is integrated once.

### 3.2 Upper-rim payment, once globally

For a newly upper-rim h, the incident sources satisfy s_i>=n s_h/2. Equation (5) gives

    X_h subset (1+2c0/n)A_i.

The source load on the new upper-rim receiver union is therefore at least tau/8 in this dilation. A single global integration yields

    V_up^new<=K_up(n)U/tau,
    K_up(n)=8(1+2c0/n)^n<=8exp(33/16).                      (8)

Only new nonfar labels enter this branch, so there is no double counting. Again no group-by-group or scale-by-scale fee is introduced.

## 4. Unpaid group scales and the correct representative

If s_h<=s_{r_a}/n, every source in P_a has s_i>=n s_h, so F_h^rate=tau and h is far.

If s_{r_a}/n<s_h<=2s_{r_a}/n, every source in its near pool has s_i>=s_{r_a}>=n s_h/2. Thus a nonfar h has R_h^up=T(I_h^new)>tau/2, and is upper-rim. Hence every unpaid member satisfies

    2s_{r_a}/n<s_h<=s_{r_a}.                               (9)

If the ORIGINAL seed r_a is far, the whole group is far: decreasing s_h only enlarges the threshold set {s_i>=n s_h}. No analogous window monotonicity is used for upper-rim sources, whose interval [n s_h/2,n s_h) moves at both ends. In particular an upper-rim seed is not used to delete its whole group.

For a group with unpaid members let

    r_min,a=min remaining s_h,
    R_a=max remaining s_h,

and choose a REAL remaining target rho_a attaining R_a. The original seed might have been paid; rho_a is not assumed to equal r_a. The historical source lower bound in (4) continues to use s_{r_a}, not the possibly smaller R_a.

## 5. Whole-group common low core, including the self correction

Take an unpaid member attaining r_min,a. Its source population P_a is partitioned EXACTLY into

    low:   s_i<n r_min,a/2,
    rim:   n r_min,a/2<=s_i<n r_min,a,
    far:   s_i>=n r_min,a.

For this unpaid member the last two rates are strictly below tau/8 and tau/2 respectively. Since the complete P_a rate is tau,

    K_a=P_a intersect {i:s_i<n r_min,a/2},
    T(K_a)>tau-tau/8-tau/2=3tau/8.                         (10)

This conclusion uses the minimum remaining radius, not the seed's old classification.

Now remove the seed self label from this AUXILIARY core:

    K'_a=K_a minus {r_a}.

The original q and F_r_a are unchanged. The deleted auxiliary rate is at most q_r_a<=a^(-n). Therefore

    T(K'_a)>3tau/8-a^(-n)>5tau/16=nu.                       (11)

The last inequality is tau/16>a^(-n), immediate from tau/16=1024sqrt(n) and a^(-n)<=1/32. No implicit cap is imposed on future original packing weights.

For every i in K'_a,

    i<r_a<=h for every group target h,
    s_{r_a}<=s_i<n r_min,a/2.

This proves exactly the scale chain (2). In particular each core source belongs to the NEAR, NON-UPPER part for every remaining group target:

    s_h<=s_i<n s_h/2.

All these source parents contain the shared z_a. Their radii are at least s_{r_a}>=R_a, so they give one WHOLE-GROUP common source population. No n equal-log subdivisions are needed.

### 5.1 Whole-box low load uses strict historical priority

For y in B_h and i in K'_a, if y in A_i then

    ||y_h-y_i||_infinity<=s_i+s_h/a<=c0s_i.

Every such i is strictly before h. The ORIGINAL center-admission inequality thus gives

    g_{K'_a}(y)
      =sum_{i in K'_a}q_i1_{A_i}(y)
      <=sum_{i<h}q_i1_{Q(y_i,c0s_i)}(y_h)
      <=1                                                 (12)

throughout every whole B_h.

This is the reason the self label was explicitly removed. If the original seed remains unpaid and q_r_a>0, applying only an i<h admission inequality to a core still containing r_a would omit its true self contribution.

## 6. Exact account and still-unpaid global combination

The inherited admission reduction, (7), and (8) give the reclassified complete account

    V0<=C_adm[U+(K_far+K_up(n))U/tau+V_rem^new],
    P0>=U/tau,
    C_adm=1+exp(1/16).                                     (13)

This is the SAME original all-input finite problem, with newly chosen auxiliary witnesses and newly paid receiver classes. It is not an identity with the old Vrem. No old Poisson/key assertion is used in deriving (13).

For n<256 the inherited common-point near-load cap rules out a near population of rate greater than tau/2, for any legal witness choice; hence no new unpaid branch arises there. The whole-group discussion relevant to the certified short-sample tool is n>=256.

For a nonempty unpaid group define its actual receiver union Y_a^new. Every core parent contains z_a, and (5) gives

    Y_a^new subset intersection_{i in K'_a}A_i+c0R_a[-1,1]^n.

Apply the certified R673 theorem with r=R_a, genuine original owners, rate T(K'_a)>nu>=mu and k=ceil(128sqrt(n)). Every sampled expanded intersection covers the whole real group. Thus

    |Y_a^new|<=3exp(-2k)U_{K'_a},
    U_{K'_a}=sum_{i in K'_a}|F_i|,

and summing the actual group partition gives the EXACT available debit

    V_rem^new<=3exp(-2k)sum_a U_{K'_a}
       =3exp(-2k)sum_i|F_i| #{a:i in K'_a}.                 (14)

The last repeated-source coefficient is NOT paid here. Old q packing controls sum_iq_i1_{A_i}, not repeated copies of a source over groups.

Alternatively all remaining TARGET parents within one group contain z_a, so |Y_a^new|<=c(2R_a)^n and its largest remaining original target can individually pay that group. Different groups' target parents need not be disjoint. These individual packing choices are not claimed jointly feasible.

The new structure beyond R676 is precise: historically legal common saturation, a full common low core of rate above nu, original strict-priority whole-box admission, a common radius window for the ENTIRE group, and exclusion of earlier chosen points by ALL later group target parents. Source reuse between groups and the simultaneous original-family packing remain open.

No scale-factor saving is inserted into the final global constant merely because equal-log subdivision is absent. This construction supplies genuine whole-group geometry; paying or jointly packing those groups is still required.

## Verification and bounded stop

The original saturation recursion and far proof were read from R660. The upper-rim integration is the already proved R670 argument re-established here for the new witnesses. Only the certified static R673 short-sample theorem is used for (14); no old shared-Poisson law is transferred to the reselected pools.

No computation beyond exact analytic accounting was requested or launched. No new process, child agent, Git operation or PDF compilation was used. This author proof is complete and is sent for independent audit. The general global receiver/packing bound is not claimed.
