#!/usr/bin/env python3
"""Read-only reuse of WITNESS_RESULT.json: finite multi-index and first-eligible halo checks."""
from fractions import Fraction as F
from pathlib import Path
from itertools import combinations_with_replacement,product
from collections import Counter
from math import factorial,prod
import json,hashlib,sys,platform,time
BASE=Path(__file__).resolve().parent
INPUT=BASE/'WITNESS_RESULT.json'
def encode(x):
    if isinstance(x,F):return str(x)
    if isinstance(x,dict):return {str(k):encode(v) for k,v in x.items()}
    if isinstance(x,(tuple,list)):return [encode(v) for v in x]
    return x

def main():
    start=time.time();raw=INPUT.read_bytes();source=json.loads(raw);results=[]
    totals=dict(fixtures=0,policy_families=0,group_degree_identities=0,deduplicated_keys=0,supported_group_keys=0,receiver_halo_containments=0,repeated_label_keys=0)
    for fixture in source['fixtures']:
        assert fixture['all_checks_passed']
        n=fixture['n'];a=fixture['a'];c0=F(fixture['c0']);tau=F(fixture['tau']);q=list(map(F,fixture['q']))
        A=[dict(y=list(map(F,C['y'])),s=F(C['s'])) for C in fixture['cubes']]
        fres=dict(name=fixture['name'],n=n,tau=tau,policies={});totals['fixtures']+=1
        for policy,rec in fixture['policies'].items():
            groups=rec['groups'];P=[set(G['positive_sources']) for G in groups]
            # Original full positive-source sets only, with original anchors/radii.
            for j,G in enumerate(groups):
                z=list(map(F,G['witness']));r=G['anchor']
                actual={i for i,C in enumerate(A) if q[i]>0 and all(abs(z[d]-C['y'][d])<C['s'] for d in range(n))}
                assert actual==P[j] and all(i<=r for i in P[j])
                assert sum((q[i] for i in P[j]),F(0))==tau
            degree_records=[]
            for k in (1,2,3):
                key_targets={};identities=[]
                for b,labels in enumerate(P):
                    # Unordered label multisets represent multi-indices; no deletion
                    # of repeated labels and no quotient by support alone.
                    terms=[]
                    ordered_counts=Counter(tuple(sorted(t)) for t in product(sorted(labels),repeat=k))
                    for tup in combinations_with_replacement(sorted(labels),k):
                        counts=Counter(tup);key=tuple(sorted(counts.items()))
                        den=prod(factorial(v) for v in counts.values())
                        coeff=prod(q[i]**v for i,v in counts.items())/den
                        multiplicity=factorial(k)//den
                        assert ordered_counts[tup]==multiplicity
                        ordered_weight=prod(q[i] for i in tup)
                        assert coeff*factorial(k)==ordered_weight*multiplicity
                        terms.append(dict(multi_index=key,coefficient=coeff,ordered_tuple_multiplicity=multiplicity))
                        key_targets.setdefault(key,[]).append(b)
                    total=sum((t['coefficient'] for t in terms),F(0));expected=tau**k/factorial(k)
                    assert total==expected
                    identities.append(dict(group=b,anchor=groups[b]['anchor'],full_P=sorted(labels),terms=terms,sum=total,expected=expected,passed=True))
                    totals['group_degree_identities']+=1
                keys=[]
                for key,targets in sorted(key_targets.items()):
                    support={i for i,m in key};eligible=[b for b,labels in enumerate(P) if support<=labels]
                    assert targets==eligible
                    first=min(eligible);r=groups[first]['anchor'];sr=A[r]['s']
                    lo=[max(A[i]['y'][d]-A[i]['s'] for i in support) for d in range(n)]
                    hi=[min(A[i]['y'][d]+A[i]['s'] for i in support) for d in range(n)]
                    assert all(lo[d]<hi[d] for d in range(n))
                    halo_lo=[x-c0*sr for x in lo];halo_hi=[x+c0*sr for x in hi]
                    witnesses=[]
                    for b in eligible:
                        G=groups[b];z=list(map(F,G['witness']))
                        assert first<=b and A[G['anchor']]['s']<=sr
                        assert all(lo[d]<z[d]<hi[d] for d in range(n))
                        receiver_checks=[]
                        for h in G['members']:
                            C=A[h];blo=[y-C['s']/a for y in C['y']];bhi=[y+C['s']/a for y in C['y']]
                            assert C['s']<=sr
                            lower_margin=[blo[d]-halo_lo[d] for d in range(n)];upper_margin=[halo_hi[d]-bhi[d] for d in range(n)]
                            assert min(lower_margin+upper_margin)>=0
                            receiver_checks.append(dict(receiver=h,closed_B_lower=blo,closed_B_upper=bhi,lower_margin=lower_margin,upper_margin=upper_margin,contained=True))
                            totals['receiver_halo_containments']+=1
                        witnesses.append(dict(target_group=b,witness=z,receiver_checks=receiver_checks))
                        totals['supported_group_keys']+=1
                    den=prod(factorial(m) for i,m in key);coeff=prod(q[i]**m for i,m in key)/den
                    keys.append(dict(multi_index=key,support=sorted(support),coefficient=coeff,first_eligible_group=first,original_anchor=r,original_anchor_radius=sr,intersection_lower=lo,intersection_upper=hi,halo_lower=halo_lo,halo_upper=halo_hi,eligible_groups=eligible,coverage=witnesses,passed=True))
                    totals['deduplicated_keys']+=1
                    if any(m>1 for i,m in key):totals['repeated_label_keys']+=1
                degree_records.append(dict(k=k,group_identities=identities,deduplicated_keys=keys,passed=True))
            fres['policies'][policy]=dict(group_count=len(groups),degrees=degree_records,passed=True)
            totals['policy_families']+=1
        results.append(fres)
    out=dict(title='R677 finite multi-index coefficient and first-eligible halo certificate',python=sys.executable,python_version=platform.python_version(),script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),input_path=str(INPUT),input_sha256=hashlib.sha256(raw).hexdigest(),original_experiment_rerun=False,elapsed_seconds=time.time()-start,degrees=[1,2,3],scope='Original loss groups and full positive-source sets P_a at low tau; original anchor radii. No K-prime/hard-core claim, no exponential budget or root-order estimate.',key_definition='Within each fixture and policy: the complete multi-index tuple ((source_index,multiplicity),...), not merely its support. a(m) is the earliest group with supp(m) subset P_a.',coefficient_identity='sum_{supp(m) subset P_a, |m|=k} product_i q_i^m_i / product_i m_i! = tau^k/k!',halo_definition='H_m = (intersection_{i in supp(m)} A_i) + [-c0*s_anchor(a(m)),c0*s_anchor(a(m))]^n',totals=totals,fixtures=results,all_checks_passed=True)
    (BASE/'KEY_RESULT.json').write_text(json.dumps(encode(out),indent=2)+'\n')
    print(json.dumps(encode(dict(all_checks_passed=True,totals=totals,script_sha256=out['script_sha256'],input_sha256=out['input_sha256'],elapsed_seconds=out['elapsed_seconds']))))
if __name__=='__main__':main()
