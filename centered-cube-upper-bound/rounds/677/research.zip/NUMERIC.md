# R677 finite exact witness-routing check

Executed with `/Users/zzh/.local/share/math-research-tools/venv/bin/python` (3.12.14). Script SHA256 `6ce6d46f9425e03b7519ecb7fa9e8b8aea6e324768c3d217b44fe72d792c9da4`.

10 fixtures; all checks passed: **True**. Two deterministic static finite-input policies: canonical face-free representative, and maximal remaining receiver volume with fixed rational tie order. Full inputs, rational masks/representatives, qi, prefix maxima, centers, strips and groups are in WITNESS_RESULT.json.

All nonzero positive-volume membership masks are constructed by per-coordinate endpoint intervals followed by bitwise intersection; no random point grid. Exact Fraction arithmetic is used throughout. Sources and receiver strips are actual cubes/boxes with pairwise disjoint closed small cubes (strip boundary choices are null sets). `c0=1+1/(32n)`, `c=c0^n`; actual receiver total is compared to `c*(2sr)^n`.

Member classification totals by policy: `{'canonical': {'far': 12, 'upper_paid': 10, 'unpaid': 47}, 'maximize_unassigned_receiver_volume': {'far': 12, 'upper_paid': 10, 'unpaid': 47}}`.

The fixtures span n=1,2,3,4,6, N<=18, touching faces, equal radii, multiple saturation cells, separated cliques and rational multiscale radii. For n>=3 the last coordinates of centers are zero: this does not explore independent center positions in every dimension. tau=kappa*(32n)^(-n), kappa in {1/2,3/2,5/2}, deliberately triggers losses. It is not the hard regime tau=16384*sqrt(n) and supplies no R673 or root-order estimate. No random/nonanticipative interpretation of the maximizing policy is claimed. Anchor-upper is never used to infer whole-group payment. These finite checks are not a proof over all families.
