# R664 A1 — global geometric payment attempt

## First quantitative candidate and its disposition

The first proposed globally payable inequality was

\[
 \mathcal E_2:=\sum_{i<j}q_iq_j
       \int_{E_{ij}}e^{-bL(x)}\,dx\ \le CnU,
 \qquad b=8,\quad L(x)=\sum_\ell q_\ell\mathbf1_{A_\ell}(x),
 \tag{A1}
\]
where

\[
 E_{ij}=\big((A_i\cap A_j)+c_0\min(s_i,s_j)[-1,1]^n\big)
                         \setminus(A_i\cup A_j).
\]
This candidate would pay the *same original* residual, without uniform caps on the Janossy source coefficients: every point of `S_b` has a distinct-label covering key of size `k`; each of its `binom(k,2)` pairs has the point in `E_ij`. Counting all globally marked pairs is therefore a valid positive majorant. For fixed `x in E_ij`, the processes of labels `i,j` are independent of the processes whose parents contain `x`. Thus

\[
 \mathbb E|S_b|
 \le \frac{b^2}{\binom{k}{2}}\mathcal E_2.
 \tag{A2}
\]
No independence of a selected pair or selected receiver is asserted here. If (A1) held, then `k >= 32768 sqrt(n)` would make (A2) an absolute multiple of `U`.

**The proposed estimate (A1) is false for actual admitted source inputs.** The precise construction and calculation are below. This closes the pair-majorant route, not the original residual estimate. No new complete-family payment or summable contraction was proved by this attempt.

## Exact actual-input obstruction to the pair energy

Take `s_i=1`, `a=32n`, and the `a^n` centers in the product grid

\[
 y_{i,m}\in\left\{-1+\frac{2\ell-1}{a}:1\le\ell\le a\right\}.
\]
Their receivers `B_i` tile `[-1,1]^n`, up to null boundaries. Consequently

\[
 E_i=F_i=B_i,\qquad w_i=q_i=a^{-n},\qquad
 \sum_iq_i=1,\qquad U=2^n.
\]
These are genuine equal-radius finite inputs. Every source is admitted: at every candidate center, the preceding raw expanded-parent load is at most the total preceding weight, hence at most one. Residual weights at the frozen `tau` are unchanged, since the global parent load is at most one. In particular the construction satisfies all mutual admission restrictions and the actual owner cap. It has no near targets and `S_b` is empty.

Let `Y,Y'` be independent uniform coordinates on that grid. The exact one-coordinate average is

\[
 \mathbb E|Y-Y'|=\frac23-\frac{2}{3a^2},
 \quad
 M:=\mathbb E[2+2c_0-|Y-Y'|]
    =\frac{10}{3}+\frac2a+\frac{2}{3a^2}.
 \tag{A3}
\]
All parent intersections contain the origin. The product grid makes the sum over **all actual grid labels** a product of these finite one-coordinate sums; this is an exact feature of this diagnostic construction, not an assumption on general source coordinates. Therefore

\[
 \sum_{i,j}q_iq_j
    |(A_i\cap A_j)+c_0[-1,1]^n|=M^n.
\]
Remove the diagonal and subtract the union of the two original parents. Since `L(x)<=1`,

\[
 \boxed{
 \frac{\mathcal E_2}{U}
 \ge e^{-8}\left[
  \frac12\left(\frac M2\right)^n
  -\frac12\left(\frac{4+2/a}{2a}\right)^n-1
 \right].
 }
 \tag{A4}
\]
Its leading growth is at least `(5/3)^n/2`. Hence no absolute `C` can make (A1) true. The independent S2 reviewer checked the input qualification, diagonal correction, and union subtraction, and actually checked (A3) by exact local SymPy summation. No simulation or large-dimensional enumeration was used.

This is a concrete decision test: a reduction retaining only pairs destroys the necessary full-key condition even on actual admitted sources. The construction is **not** a counterexample to `E|S_b|<=AU`, since its original `S_b` is empty.

## The full-key geometric majorant that was retained

The subsequent attempt retained the complete `k`-source common intersection and the near-scale restriction. Put

\[
 M_b=\{i:N_i(b)=1\}.
\]
For a source set `J` of size `k`, define

\[
 K_J=\bigcap_{j\in J}A_j,
 \quad r_J=\min_{j\in J}s_j,
 \quad
 E_J=(K_J+c_0r_J[-1,1]^n)\setminus\bigcup_{j\in J}A_j,
\]
with `E_J` empty when `K_J` is empty. Only sets satisfying

\[
 \frac{\max_{j\in J}s_j}{\min_{j\in J}s_j}<n
 \tag{A5}
\]
are kept. This restriction is legitimate for every original key: all its radii lie in `[s_h,n s_h)`.

Let

\[
 H_k=\left[\bigcup_{\substack{J\subset M_b, |J|=k\\(A5)}}
                  (K_J+c_0r_J[-1,1]^n)\right]
                   \setminus(P_b^{\rm mark}\cup Q_b^{\rm rep}).
\]
Then `S_b subset H_k` pathwise. The original representative has radius at most `r_J`; the entire original key, rather than just its pair marginals, remains in this containment. Replacing `S_b` by `H_k` is an upper bound, not a claim of equality and not a claim that `H_k` has been paid.

One sufficient full-key moment estimate is

\[
 \boxed{
 \mathcal M_k:=b^k\sum_{\substack{|J|=k\\(A5)}}
       \left(\prod_{j\in J}q_j\right)e^{-b\sum_{j\in J}q_j}
       \int_{E_J}e^{-bL(x)}\,dx
       \le A U.
 }
 \tag{A6}
\]
Indeed, all labels in `J` have count one with probability
`b^k (product q_j) exp(-b sum q_j)`. For `x in E_J`, none of their parents contains `x`, so the void event for **all** marked original parents contributes the independent factor `exp(-b L(x))`. Summing the resulting subset indicators gives

\[
 \mathbb E|S_b|\le\mathbb E|H_k|\le\mathcal M_k.
 \tag{A7}
\]
The sum in (A6) also discards overlap between different sets `J`. Consequently (A6) is a stronger sufficient condition, not a necessary reformulation of the original target. Failure to prove it does not identify a failure of the original `E|S_8| <= A U` estimate. The original `S_8`, with its real first visibility, remains the true objective.

The pruning by `Q_b^rep` was discarded only in the last positive upper bound. It can instead be retained exactly. With

\[
 C(x)=\{\ell:x\in A_\ell\},\qquad
 R(x)=\{\ell:x\in A_\ell+c_0s_\ell[-1,1]^n\}\setminus C(x),
\]
put

\[
 V(x)=e^{-bL(x)}\prod_{\ell\in R(x)}e^{-bq_\ell}(1+bq_\ell),
 \qquad p_\ell=\frac{bq_\ell}{1+bq_\ell}.
\]
For every `x in E_J`, one has `J subset R(x)`, and the exact fixed-subset probability of global count one on `J` and exclusion from both paid sets is

\[
 V(x)\prod_{j\in J}p_j.
 \tag{A8}
\]
Thus replacing the integrand and coefficient in (A6) by (A8) is another legitimate, smaller factorial-moment majorant. Neither version has a proved absolute budget.

## Exact remaining geometric check

The candidate needing a new argument is the **complete cross-scale weighted moment** (A6), or its smaller version (A8), over the actual mutually admitted owners. A uniform conditional estimate for an individual minimum source is neither assumed nor required.

An attempted adaptive allocation assigned each set `J` fractions

\[
 \theta_i(J)=\frac{d_i}{\sum_{j\in J}d_j}\quad(i\in J),
\]
so large-volume sources absorb most of a widely separated tuple's fee. This avoids insisting that the minimum source must pay every halo. It does **not**, by itself, prove a bound: a large source can participate in many different admissible sets `J`, and their cross-scale fees still need a joint spatial or probabilistic budget. Taking only the sum of the fractions, or inserting the R662 unconditional single-pool intersection estimate separately for each original anchor, supplies no such bound.

The precise unproved operation would be a domination or summable allocation that takes (A6)/(A8), uses **all** original center-admission constraints and the disjoint actual `F_i`, and pays the whole sum by `sum |F_i|`. At present no verified inequality turns those mutual-admission constraints into that global moment budget. The frozen R662 theorem is for a specified common-point iid source pool; the background-selected original representative, or the family of all `J` in (A6), does not automatically have that law.

For the actual original source pool `I_h`, common-point nonemptiness is already deterministic because all its parents contain `z_h`. It cannot be counted again as a rare Helly event. For the relaxed all-source family in (A6), it remains a genuine geometric restriction; no suppression factor for it was invented.

The fixed-receiver count/void analysis is assigned to A3; this author did not continue a duplicate halo-count reduction after that coordination. No all-source uniform-capacity theorem, new birth/death contraction, or new source-integral identity is being reported as a solution.

## Bounded conclusion

- The pair majorant was quantitatively formulated, shown to pay the same objective if its energy bound held, and rigorously rejected on a qualified actual input.
- The full-key, common-intersection, near-scale, global-single, all-marked-parent-exterior conditions were retained in (A6)–(A8), but their cross-scale payment remains unproved.
- Volume-adaptive source fractions did not supply a new budget and are not counted as progress toward the final dimension bound.

No new absolute inequality or fully summable contraction was obtained. Stop after this deliverable pending reassignment.
