"""R664: exact full-key tiling formula and six 256-bit Arb signs."""
from fractions import Fraction as F
from itertools import product
from math import isqrt
from pathlib import Path
import json, sys
import flint
from flint import arb, ctx

# In each coordinate J_1,...,J_k are iid uniform on {0,...,a-1}.
# The closed intersection, enlarged by c0=1+1/a, has normalized length
# 2+1/a - (max(J)-min(J))/a. This holds even for touching endpoints.
def enumeration(a,k):
    return sum((2+F(1,a)-F(max(t)-min(t),a)
                for t in product(range(a),repeat=k)),F(0))/a**k

def cdf_formula(a,k):
    return 1+F(2,a)+F(2,a)*sum((F(j,a)**k for j in range(1,a)),F(0))

cases=[]
for a in range(2,6):
    for k in range(1,5):
        e=enumeration(a,k); m=cdf_formula(a,k); bound=1+F(2,a)+F(2,k+1)
        assert e==m and m<=bound
        cases.append({'a':a,'k':k,'enumerated':str(e),'cdf':str(m),'riemann_bound':str(bound)})

ctx.prec=256
values=[]
for n in (1,16,256,2**20,2**40,2**80):
    a=32*n
    k=32768*isqrt(n)
    assert isqrt(n)**2==n
    # log(k!) >= k log(k)-k from monotonicity of log and integration.
    # This is an upper bound on the requested log F expression, not equality.
    N=arb(n); K=arb(k)
    upper=N*(1+arb(2)/a+arb(2)/(K+1)).log()+K*(arb(8).log()-K.log()+1)
    assert upper < 0
    values.append({'n':str(n),'a':str(a),'k':str(k),'logF_upper_enclosure':str(upper),'strictly_negative':True})
result={'scope':'fixed equal-scale tiled model; no near branch; not a general S8 theorem',
        'python':sys.version,'python_flint':flint.__version__,'arb_precision_bits':ctx.prec,
        'command':'/Users/zzh/.local/share/math-research-tools/venv/bin/python FULLKEY_MODEL.py',
        'exact_formula':'1+2/a+(2/a)*sum((j/a)^k, j=1..a-1)',
        'riemann_proof':'x^k increasing implies (1/a)*sum_(j=1)^(a-1) (j/a)^k <= integral_0^1 x^k dx = 1/(k+1)',
        'factorial_bound':'log(k!) >= k*log(k)-k',
        'exact_cases':cases,'arb_cases':values}
Path('FULLKEY_MODEL.json').write_text(json.dumps(result,indent=2)+'\n')
print('exact Fraction enumeration and CDF agree; Riemann bounds verified:',len(cases),'cases')
for v in values: print('n='+v['n'],'k='+v['k'],'logF upper:',v['logF_upper_enclosure'],'< 0')
print('Python',sys.version.split()[0],'python-flint',flint.__version__,'Arb bits',ctx.prec)
