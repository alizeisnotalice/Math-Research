#!/usr/bin/env python3
"""R664 independent reproduction. Prints JSON only; never rewrites archive members."""
import ast, hashlib, json, os, re, shutil, subprocess, sys, tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
MODEL = ROOT / 'FULLKEY_MODEL.py'
FROZEN = ROOT / 'FULLKEY_MODEL.json'
REPORT = ROOT / 'REPORT.tex'
MATH_FIELDS = ('scope', 'arb_precision_bits', 'exact_formula', 'riemann_proof',
               'factorial_bound', 'exact_cases', 'arb_cases')

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def report_checks():
    data = REPORT.read_bytes()
    bad = [(i, b) for i, b in enumerate(data) if b < 32 and b not in (9, 10, 13)]
    text = data.decode('utf-8')
    lines=[]
    for line in text.splitlines():
        # Ignore unescaped TeX comments; retain escaped percent signs.
        line = re.split(r'(?<!\\)(?:\\\\)*%', line, maxsplit=1)[0]
        lines.append(line)
    tokens=re.finditer(r'\\(begin|end)\s*\{([^{}]+)\}', '\n'.join(lines))
    stack=[]; errors=[]
    for token in tokens:
        op, name=token.groups()
        if op == 'begin': stack.append(name)
        elif not stack or stack[-1] != name:
            errors.append({'unexpected_end':name,'open':stack[-1] if stack else None})
        else: stack.pop()
    return {'sha256':digest(REPORT),'control_characters':bad,
            'unclosed_environments':stack,'mismatched_environments':errors,
            'passed':not (bad or stack or errors),
            'scope':'control bytes and begin/end nesting only; not TeX compilation or mathematical review'}

def manifest_checks():
    manifest=ROOT/'MANIFEST.json'
    if not manifest.exists(): return {'status':'skipped', 'reason':'MANIFEST.json absent'}
    m=json.loads(manifest.read_text()); errors=[]; checked=[]
    for entry in m['files']:
        name=entry['path']; path=(ROOT/name).resolve()
        if ROOT not in path.parents or not path.is_file():
            errors.append({'path':name,'error':'missing, non-file, or outside package'}); continue
        actual_hash=digest(path); actual_bytes=path.stat().st_size
        checked.append(name)
        if actual_hash != entry['sha256'] or actual_bytes != entry['bytes']:
            errors.append({'path':name,'actual_sha256':actual_hash,'actual_bytes':actual_bytes})
    return {'status':'passed' if not errors else 'failed','files_checked':checked,'errors':errors}

def main():
    ast.parse(MODEL.read_text(),filename=str(MODEL))
    frozen=json.loads(FROZEN.read_text())
    # Never silently fall back to the system temporary directory.
    temp_root=os.environ.get('R664_TEMP_ROOT', '/Volumes/data/CodexTemp')
    if not temp_root or not Path(temp_root).is_dir():
        raise RuntimeError(f'configured temporary directory does not exist: {temp_root!r}')
    with tempfile.TemporaryDirectory(prefix='r664-verify-',dir=temp_root) as work:
        copied=Path(work)/MODEL.name
        shutil.copy2(MODEL,copied)
        command=[sys.executable,copied.name]
        p=subprocess.run(command,cwd=work,text=True,capture_output=True,timeout=120)
        if p.returncode: raise RuntimeError(f'model exit {p.returncode}: {p.stderr}')
        observed=json.loads((Path(work)/'FULLKEY_MODEL.json').read_text())
        differences=[field for field in MATH_FIELDS if frozen.get(field)!=observed.get(field)]
    report=report_checks(); manifest=manifest_checks()
    out={'model_ast':'passed', 'interpreter':sys.executable,
         'python_version':sys.version, 'python_flint_version':observed.get('python_flint'),
         'command':[sys.executable,'FULLKEY_MODEL.py'], 'execution':'independent temporary copy',
         'exit_code':p.returncode,'model_stdout':p.stdout.strip().splitlines(),
         'mathematical_fields_compared':list(MATH_FIELDS),
         'mathematical_field_differences':differences,
         'mathematical_comparison':'passed' if not differences else 'failed',
         'report_checks':report,'manifest':manifest,
         'integration_review':'not assessed by this verification',
         'model_scope':'same-scale diagnostic; no evidence of actual near case'}
    print(json.dumps(out,indent=2,ensure_ascii=False))
    if differences or not report['passed'] or manifest['status']=='failed': return 1
    return 0

if __name__=='__main__': sys.exit(main())
