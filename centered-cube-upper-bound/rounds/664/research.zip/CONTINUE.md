# R664 handoff: retain the full actual union

The general pure C_n<=Ksqrt(n) and the former general n^(1/2+o(1)) bound remain OPEN. This round did not pay a new part of E|S8|. Its report records a meaningful strategy filter, exact conditional laws, and unclosed geometric bridges, not a new dimension-order result.

## Unchanged authoritative target

Use R663 REPORT sections 2–4/7 and R664 REPORT (1). Actual finite sources, original order, disjoint Fi, qi=|Fi|/di, a=32n, tau=16384sqrt(n), k=ceil(2tau), every actual high-T_h witness and near window, true Lebesgue receivers, all-source mutual admission, one shared Poisson history, first keys, and original representative L_h all remain. The proven complete fee is

(1-exp(-tau/4))*V_near <= (8+delta_n)U + E|S8|.

The genuine open target remains E|S8|<=A U with A absolute. It is sufficient to control its weighted aggregate; no uniform individual invoice cap is required. No local identity in this round discharges it.

## Decisions that should change the next work

1. Do not replace full keys by a sum of exterior pair energies: the exact admitted grid source family has exponential pair energy, even though it has no near targets and original S8=0. This defeats that relaxation only.
2. Retaining all k sources fixes that same diagnostic. The scalar formula and factorial suppression are proved for the product-grid model and checked exactly/with Arb, but no arbitrary-family or multiscale result follows. Do not continue studying this easy family after the decision is made.
3. Summing all full-k subsets is still a stronger sufficient target; it loses true overlap and high-T target selection. Keep original union/first visibility if the moment sum cannot be paid. Do not treat another majorant failure as rejection of the original S8 target.
4. The all-admission path capacity has expectation <=16U, but no geometric receiver payment into that capacity exists yet. Do not spend another round only deriving its marginals or graph expansion.
5. Fixed-x paid-set exclusion is exactly an independent zero/singleton/original-Poisson law with weight w_x; all sources' original q,I_h,L_h remain fixed. At each actual h common intersection already holds through z_h, so Helly nonemptiness supplies no new rare-event factor. The difficulty is the full coordinate tests AND the shared union over actual high-depth races. Removing outside-K_x bad events gives an upper bound only; it changes active rates and does not preserve per-source first-visibility charges.
6. Added forbidden-set death is at most already-paid (8+delta_n)U. This does not bound original geometric split death or savings from an existing forbidden set screening repeated births. No new birth-minus-death estimate was established.

A useful next proof must turn full coordinate geometry plus actual ownership/mutual admission into a globally summable spatial estimate for the SAME union, with all sources/receivers/scale fees kept. A new conditional law, capacity name, simple family, or coefficient rearrangement is not enough. Before another extended computation, freeze the quantitative candidate that the computation can accept or reject. Important candidates still require exploratory, obstacle and enlarged-range checks; finite evidence never certifies the general bound.

## Actual reproduction

FULLKEY_MODEL.py uses the local math interpreter and python-flint/Arb. The saved JSON lists all 16 rational enumeration checks and all six 256-bit scalar enclosures through n=2^80; no high-dimensional geometric simulation was performed. Python 3.12.14, python-flint 0.9.0. In this round MATLAB and Mathematica were not run. No Monte Carlo or PDF compilation.

Run `python verify.py` using /Users/zzh/.local/share/math-research-tools/venv/bin/python in an extracted bundle. Reproduction uses a fresh /Volumes/data/CodexTemp subdirectory and leaves frozen data untouched. The archive manifest includes hashes of all required files except itself. Reviewer hashes bind the corresponding version; earlier author-version hashes are retained when a later quantity/wording clarification was audited.

## Collaboration / archive

Four existing Astra core roles, three existing Sol reviewers and two existing Terra roles performed bounded tasks. They stopped after delivery; no completed agent is counted as actively computing. Additional roles may be used for distinct needed tasks, not to fill slots or duplicate an expensive computation. No billing data were available. Current local computation was decision-specific, not a CPU burn.

Each finished round is separately committed and pushed, with only the project README and this round's README/research.zip at Git level. The full report and needed proof/audit/reproduction support are inside one small ZIP; no caches or intermediate experiment files. Keep the goal active and do not claim closure.
