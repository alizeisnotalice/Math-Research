# R664 A3: complete receiver exclusion and the shared high-depth race

**Outcome.** The complete paid-set exclusion has an exact independent Bernoulli-singleton source law at each fixed receiver x. Under that law the full cube-coordinate condition and the original first-key union reduce to the shared races in (A4) below. All mutual-admission inequalities remain, but no globally integrable estimate for that union of races has been proved. Thus this investigation does **not** prove E|S_8|<=A U. It does not claim a new identity as payment and does not replace the full keys by pair conditions.

## Proposed quantitative closure and its status

The desired closure for this route is the following weighted estimate for the *actual* high-depth target family:
\[
 \boxed{\int w_x\,
   \mathbb P_x^{0/1}\!\left\{
      \exists h:\ x\in L_h,\ \sigma_{h,k}(x)\le8,
                              \ \sigma_{h,k}(x)<\beta_h(x)
                         \right\}\,dx\le A U,\quad A<\infty
                         \text{ absolute}.}                  \tag{A1}
\]
All quantities are defined below. The left side is exactly E|S_8|, with all selected labels, full first-k order, true witnesses and all coordinates retained. Consequently proving A1 would pay the same original object. What follows verifies its source law and its exact geometric content, and identifies the unclosed step. A1 has not been proved and is not presented as a new budget or an improvement.

## Exact complete paid-set conditioning

Fix deterministic x, and define
\[
 C_x=\{i:x\in A_i\},\qquad
 K_x=\{i:x\in A_i+c_0s_i[-1,1]^n\},\qquad
 f(x)=\sum_{i\in C_x}q_i.
\]
Here C_x is contained in K_x. The event that x is outside **both** paid sets is exactly
\[
 E_x=\{N_i(8)=0\ (i\in C_x),\quad
                N_i(8)\le1\ (i\in K_x\setminus C_x)\}.
\]
By independence across original source labels,
\[
 \Pr(E_x)=w_x
   =e^{-8f(x)}
       \prod_{i\in K_x\setminus C_x}e^{-8q_i}(1+8q_i).          \tag{A2}
\]
Conditionally on E_x, different source processes remain independent *before further selection*. Denote the conditional law by P_x^{0/1}:

* every source in C_x has zero events;
* a source i in K_x minus C_x has one event with probability p_i=8q_i/(1+8q_i), and otherwise zero; its single-event time is uniform on [0,8];
* every source outside K_x retains its independent original Poisson process on [0,8].

All histories, first keys, representatives, first coverage and final regions are recomputed under this law. Original q, I_h, z_h, radii and L_h are not regenerated or changed. In particular L_h continues to be defined by the original deterministic prefix load, not by a load with the deleted sources removed.

This proves
\[
 \Pr\{x\in S_8\}=w_x\,\mathbb P_x^{0/1}\{x\in\Omega_8\}.       \tag{A3}
\]
Any key covering x uses only labels in K_x minus C_x: for a selected source i and its representative h, s_h<=s_i, so the entire key halo is contained in A_i+c_0s_i Q. Each such selected label consequently has exactly one global event. Sources outside K_x can still enter a target's first-k list and prevent that target from covering x. Their processes therefore remain in the exact formula.

## Full coordinates, true witnesses, and the first-k race

For each actual target h put delta_h=c_0s_h and
\[
 G_h(x)=\{i\in I_h\setminus C_x:
                |x_m-y_{im}|\le s_i+\delta_h\ \text{for all }m\}.
\]
This is a complete n-coordinate condition, not a pair-incidence test. Let sigma_{h,k}(x) be the kth event time of the retained sources in G_h(x), with value infinity if fewer than k occur by time 8. Let beta_h(x) be the first event time among the retained sources in I_h minus (C_x union G_h(x)), again infinity if none occurs by 8.

For every complete deterministic history satisfying E_x (hence under P_x^{0/1}),
\[
 \boxed{x\in\Omega_8\quad\Longleftrightarrow\quad
   \exists h:\ x\in L_h,\ \sigma_{h,k}(x)\le8,
                                \ \sigma_{h,k}(x)<\beta_h(x).} \tag{A4}
\]
Ties between different original events have probability zero. This equivalence follows in two exact steps.

First, the original representative union equals the union of the own halos of *all* completed actual targets. If h<j share a key, then s_h>=s_j and L_h contains L_j; hence the earlier representative's halo contains the later own halo. This terminal union identity does not make a representative's tuple unbiased or independent of its selection.

Second, every source in I_h contains the actual witness z_h. Thus every candidate key from I_h already has a nonempty common intersection. For its selected labels S,
\[
 \left(\bigcap_{i\in S}A_i\right)+\delta_h Q
       =\bigcap_{i\in S}(A_i+\delta_h Q).
\]
Coordinatewise, membership of x means
\[
 \max_{i\in S}(y_{im}-s_i)\le x_m+\delta_h,
 \qquad
 \min_{i\in S}(y_{im}+s_i)\ge x_m-\delta_h
 \quad\text{for every }m.                            \tag{A5}
\]
These are exactly the conditions S subset G_h(x). The true first k events are all in G_h(x) precisely when its kth event precedes the first bad event. This proves A4.

The full high-depth condition remains
\[
 \tau/2<T_h=\sum_{i\in I_h}q_i\le\tau,
 \qquad s_h\le s_i<ns_h\ (i\in I_h),
 \qquad k=\lceil2\tau\rceil.
\]
No target is replaced by an arbitrary cube clique. The common-point part of box Helly supplies **no additional random penalty** at a fixed actual h: it was already guaranteed by z_h before sampling. The random geometric condition is the simultaneous collection of all inequalities A5, equivalently the full G_h(x) race in A4. The difficult operation is the union over h, with different true witnesses, scales and rate sets, under one shared source law.

## All mutual admission restrictions survive, but do not give independent races

For every actual source i,
\[
 J_i^{\rm in}=\{j<i:y_i\in c_0A_j\},\qquad
 \lambda_i=\sum_{j\in J_i^{\rm in}}q_j\le1.                    \tag{A6}
\]
These and all other original admission constraints remain deterministic conditions on the same family after receiver conditioning. For theta>=0 their exact marginal consequence under P_x^{0/1} is
\[
 \begin{split}
 \mathbb E_x^{0/1}e^{\theta N_i^{\rm in}(8)}
 ={}&\exp\!\left(8(e^\theta-1)
             \sum_{j\in J_i^{\rm in}\setminus K_x}q_j\right)\\
 &\times\prod_{j\in J_i^{\rm in}\cap(K_x\setminus C_x)}
             \frac{1+8q_je^\theta}{1+8q_j}\\
 \le{}&\exp(8(e^\theta-1)\lambda_i)
 \le\exp(8(e^\theta-1)).
 \end{split}                                                   \tag{A7}
\]
Each Bernoulli factor is 1+p_j(e^theta-1)<=exp(8q_j(e^theta-1)). Counts for different centers share original source variables and do not factor. The target races also overlap in their original source variables. A7 is an unselected marginal statement, not the distribution conditioned on a source becoming the minimum-volume source of the first-visible key.

The natural attempted closure was to combine the independent singleton marks, the all-coordinate test A5, high T_h, and the entire collection of capacities A6 to integrate the probability of the union in A4. No implication bounding this spatial union by sum_i d_i q_i has been obtained. In particular:

1. Box Helly does not add a missing factor at fixed h, because its common intersection is already deterministic.
2. A7 only gives the known Poisson(8)-type marginal incoming-count ceiling. It does not supply a joint packing or a multiplicity bound for the geometrically selected high-depth target clusters.
3. Summing the fixed-h intersection estimate repeats the same F_i across targets. The Bernoulli product law does not justify factoring a fixed-h estimate from the probability that h supplies first visibility.
4. Deleting sources outside K_x is not an equality: these sources can be the first bad event beta_h in A4. Enlarging to arbitrary pair-compatible keys also discards the full high-T_h first-key problem.

Thus the precise missing theorem is a weighted spatial estimate for the **union of these actual shared races**, using the complete mutual-admission geometry. No such estimate has been derived here. The step is not repaired by renaming that union, treating receiver-dependent conditional laws as independent across x, or assigning its volume to the expected total marked-source volume.

## Auxiliary check on the zero-event factor alone

This paragraph is only diagnostic, not the main output or a closure of A1. If only C_x is zeroed and all other processes retain their original law, set
\[
 p_x^{\rm del}=\Pr^{\rm del(C_x)}
                      \{x\in\Omega_8\setminus Q_8^{\rm rep}\}.
\]
Then exactly
\[
 \Pr\{x\in S_8\}=e^{-8f(x)}p_x^{\rm del}.                     \tag{A8}
\]
For gamma>0 this yields
\[
 \mathbb E|S_8\cap\{f\ge\gamma\}|
       \le e^{-8\gamma}U/\gamma.                              \tag{A9}
\]
But on f<1/8 the factor lies between e^{-1} and 1, all original L_h contain x, and each retained near-source rate decreases by at most 1/8. Therefore the C_x-zero-event factor alone leaves the same hard low-load receiver branch, up to constants. The complete singleton conditioning A2--A4 retains additional global information; no proof that it pays that branch has been found.

For selection discipline, adding events in C_x is pointwise monotone for membership of x in Omega_8: any such inserted source is x-good for every target using it, and can only replace a good event in a successful first-k list. This is not monotonicity of S_8, since its paid exclusions change. It confirms that the conditional construction is a full-history operation, not a declaration of independence between a selected representative and receiver exclusion.

No numerical computation was commissioned; none would change the identified quantifier/geometry gap at this stage. Only A3_RECEIVER.md was written. Bounded investigation complete, with no A3/AU claim.
