# R664 S3: global budget audit and exact acceptance condition

## Scope and current status

The R663 results (6), (9), and (11) are frozen tools and are not re-audited here. The target remains the same original random S_8. No author-supplied new mutual-admission contraction has yet been received. This note first fixes the weakest algebraic acceptance condition for such a contraction; that condition is not itself a new estimate or research improvement.

Write V=V_near, W=E|S_8|, epsilon=exp(-tau/4), and c=8+delta_n. The already proved complete account is

    (1-epsilon)V <= c U + W.                         (A)

The sufficient estimate W<=A U with absolute A is one acceptable endpoint. There is no requirement that every source, every representative, or every conditional history have its own uniform fee cap.

## 1. Minimal quantitative contraction contract

Suppose a proposed same-process birth/death argument yields, after all initial, terminal, and unfinished fees have been included,

    W <= A_n U + rho_n W + theta_n V,                 (B)

where A_n>=0, 0<=rho_n<1, and theta_n>=0 are deterministic and uniform over all finite actual inputs in dimension n. Let

    g_n = (1-rho_n)(1-epsilon) - theta_n.

The exact recoverable coefficient is

    V <= [(1-rho_n)c + A_n] U / g_n.                 (C)

Thus the weakest algebraic acceptance condition for the form (B) is

    g_n>0,   sup_{n>=256} [(1-rho_n)c+A_n]/g_n < infinity.   (D)

Low dimensions already have no near branch. A uniform positive lower bound on g_n and bounded A_n are convenient sufficient conditions, but are stronger than necessary. For example rho_n may approach one if A_n and theta_n shrink proportionally to 1-rho_n. Equivalently, normalize Abar_n=A_n/(1-rho_n) and thetabar_n=theta_n/(1-rho_n); the needed uniform ratio is

    (c+Abar_n)/(1-epsilon-thetabar_n).

In the usual absolute-constant case, Abar_n<=Abar and thetabar_n<=theta<1-sup epsilon suffice. The ordinary direct budget is rho=theta=0. A V term is allowed only within this exact absorption margin. A rho=1 estimate, a zero denominator, or an uncontrolled dimension-dependent ratio does not close the account.

Combining a valid absolute upper bound M for (C)'s ratio with the frozen outer account and P_0>=U/tau would give

    C_n <= C_adm [16384(1+M)+K_far] sqrt(n).

This is only a conditional recovery statement; no such M has been established in this audit.

## 2. How a summed birth/death proof would meet the contract

A proposed predictable signed account must first establish its own exact same-process identity. If beta_i,d_i are its actual spatial union births/deaths for S_t, and Psi is an auxiliary potential, the required identity has the form

    W + E Psi_8 = E Psi_0
        + E integral_0^8 sum_i q_i [beta_i-d_i+delta_i Psi] dt.  (E)

A future-dependent terminal-filtered set cannot simply be inserted into a predictable compensator; an exact Janossy or equivalent full-history conditioning is needed in that case. The frozen formula (9) is available for the original terminal S_8.

For example, it would suffice to prove the genuinely new weighted aggregate estimate

    E integral_0^8 sum_i q_i [beta_i-d_i+delta_i Psi] dt
       <= a_n U + rho_n W + eta_n V,                (F)

together with endpoints

    E Psi_0 <= a0_n U + eta0_n V,
    E Psi_8 >= -a8_n U - eta8_n V.

Then (B) holds with A_n=a_n+a0_n+a8_n and theta_n=eta_n+eta0_n+eta8_n. Nonnegative terminal potential and zero initial potential set their fees to zero. Any incomplete-target error introduced by this new proof must also be charged to these constants; it cannot reuse the already spent epsilon margin without appearing in (D).

Formula (F) is an acceptance template, not a proof: replacing its integrand by a signed identity or renaming W leaves exactly the original unpaid quantity. A proof must show a strict, dimension-controlled estimate such as (F), with actual coefficients, using a new consequence of the full mutual admission and geometry.

## 3. Precise proof obligations for the proposed A4 argument

1. **Whole-family quantifiers.** The new inequality must hold for every original finite admitted family, its actual residual q and disjoint F_i, the shared first-k processes, and fixed horizon 8. It may be averaged with weights |F_i| or q_i; no individual source cap is required.
2. **Mutual admission.** It must state exactly which all-source admission inequalities yield the summed gain. The frozen single-center bound sum_{j<i:y_i in c0 A_j}q_j<=1 is only an unconditional incoming-rate fact. Its count cannot be treated as independent of a selected receiver or first-visible key. Applying that one-source fact repeatedly is not yet a globally summable proof.
3. **Multiple children.** At each arrival all surviving child regions and all newly completed key regions must be unioned before computing the lost region. A region retained by any other child or completed key cannot be charged as death. The same overlap cannot be debited once per child.
4. **First visibility.** Birth uses the actual newly visible union after all old coverage and the relevant paid sets have been removed. A selected representative's tuple cannot be replaced by an unconditional iid tuple, and a terminal-filtered key cannot be declared predictable.
5. **Terminal and absorption.** The argument ends at time 8 with the actual unfinished state. It neither forces completion nor sends the horizon to infinity for free. Every initial, terminal, promotion, incomplete-target, or history-switching fee must enter (B), and (D) must then hold.

These obligations specify the missing estimate and how to repair a proof that omits a fee. They do not assert that a currently absent estimate is true.

## 4. Communication and bounded stopping rule

The independent algebraic contract was sent to /root/joint_source_gain before reading any new author proof. The author was asked only for a new quantitative mutual-admission estimate and exact definitions of its children, first visibility, and endpoints. In the absence of such a step, this review stops at (B)–(F) and does not expand the old local potential or repeat frozen audits.

## 5. Actual local algebra check

A Python standard-library Fraction run checked the elimination in (C) exactly on 24 rational parameter combinations: epsilon in {0,1/100}, rho in {0,1/2,99/100}, A in {1,1-rho}, and theta/(1-rho) in {0,1/2}. With c=11 and U=1, the value V from (C) made both (A) and (B) equalities in every case. It also checked rho=1-1/s for s=100,10000,1000000, A=1-rho, theta=epsilon=0; the recoverable coefficient stayed exactly 12 even though the unnormalized gap tends to zero. This computation changed the acceptance formulation from a needlessly strong uniform raw-gap condition to (D).

Actual output:

    {'exact_absorption_checks': 24, 'all_pass': True,
     'vanishing_raw_gap_can_still_close': True}

This verifies coefficient manipulation only. It supplies no evidence for an unproved geometric drift inequality.

## 6. A4's received quantitative screening and final verdict

A4 supplied only the following new screening statement, and explicitly reported no new AU net budget. Let

    M_t=P_t^mark union Q_t^rep.

This paid set is increasing. Remove M_t from the author's same active/completed spatial union. Every actual union portion K_t killed by the new paid-set increment lies in

    K_t subset M_t minus M_{t-}.

Therefore

    sum_{events t<=8} |K_t| <= |M_8|,
    E sum |K_t| <= (8+delta_n)U.                    (G)

**PASS for (G), with actual union deaths.** The increments of the increasing M are pairwise disjoint. No source-conditional cap or selected-set independence is needed. This reuses the frozen two payments only to bound the union of swallowed points; it does not re-prove them or change the original keys.

There is one precise bookkeeping repair if split-deaths are listed separately. Write T_old for the raw active/completed union before the event, T_new for its structural update with all surviving children and completed keys already unioned, M_old for the old paid set, and M_new for the new one. A disjoint split of actual old-survivor deaths is

    G = (T_old minus M_old) minus T_new,
    K = (T_old minus M_old) intersect T_new intersect (M_new minus M_old).

G and K are disjoint and their union is

    (T_old minus M_old) minus (T_new minus M_new).

Thus K is the portion still structurally retained and only then killed by the paid-set growth. Counting all child-specific deaths, or counting (T_old minus M_old) intersect (M_new minus M_old) as an extra death in addition to G, could double-charge a region already lost under structural splitting. The corrected K still satisfies (G).

The upper bound (G) is not the needed lower recovery or net drift estimate. In particular, it supplies no inequality of the form (B) or (F) with coefficients satisfying (D). It does not prove that the actual net budget is impossible, because the actual immigration may itself be much smaller than the exponential envelope. It only shows that paid-set swallowing does not create an additional uncharged, arbitrarily large death account.

**Final status: NO NEW GLOBAL PAYMENT.** A4 reports no new inequality from all sources' mutual admission controlling the true aggregate of spatial births minus geometric split deaths, with the endpoint and any promotion fees retained. That is the precise remaining missing step. The whole-family first visibility and all-children union must remain inside it. Since the author has no further quantitative step, this bounded review stops here and does not extend the local potential.
