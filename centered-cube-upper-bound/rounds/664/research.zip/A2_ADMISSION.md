# R664 A2: an integrable all-source admission capacity; geometric bridge unproved

Status: the all-source graph capacity below is proved and independently checked by S2. It does not bound the actual residual receiver set. The required joint geometric comparison remains unproved. No reduction of the final dimension dependence is claimed.

## 1. The proposed payment, before introducing auxiliary quantities

Keep exactly the actual finite sources, their original order, their common Poisson processes at `b=8`, and `S8` from R663 (5). In particular the actual first keys, their representative radii, `Lh`, original high-load witnesses and receiver exclusion from every marked parent remain in the left side.

The candidate geometric inequality investigated here is

\[
\boxed{\quad |S_8(\eta)|\le C\,\mathcal P(\eta),
\qquad
\mathcal P(\eta)=\sum_i d_i B_i P_i,
\quad C\ \text{absolute},\quad}                              \tag{A2-G}
\]

where

\[
B_i=\mathbf1_{\{N_i(8)=1\}},\qquad
c_{ij}=\mathbf1_{\{j<i,\ y_i\in c_0A_j\}},
\]

\[
P_i=1+\frac1{16}\sum_{j<i}c_{ij}B_jP_j.                       \tag{A2-P}
\]

The recursion is finite because edges point backwards in the original source order. It involves every selected source and every mutual center-capture edge, not only incoming counts at a chosen minimum source.

If (A2-G) held for the actual complete states, then the proved estimate

\[
\boxed{\quad \mathbb E\mathcal P\le16\sum_i|F_i|=16U\quad}     \tag{A2-C}
\]

would immediately pay the same original `E|S8|` with constant `16C`. The pathwise proposal is stronger than the expected bound actually needed. There is presently no proof that it holds; no claim of equivalence is made.

## 2. Proof of the all-source graph capacity

The real admission conditions give, separately at every vertex,

\[
\sum_{j<i}c_{ij}q_j\le1.                                    \tag{1}
\]

The Bernoulli variables `Bi` are independent across source labels and

\[
p_i:=\mathbb EB_i=8q_i e^{-8q_i}\le8q_i.
\]

`Pj` is measurable with respect to `B1,...,B(j-1)`. Therefore `Bj` is independent of `Pj`. Induction over the original finite order gives

\[
\mathbb EP_i
=1+\frac1{16}\sum_{j<i}c_{ij}p_j\mathbb EP_j
\le1+\frac12\sup_{j<i}\mathbb EP_j
\le2.                                                       \tag{2}
\]

Likewise `Bi` is independent of `Pi`, so

\[
\mathbb E\mathcal P
=\sum_i d_i p_i\mathbb EP_i
\le16\sum_i d_iq_i=16U.
\]

No selected receiver set occurs inside the factorization in (2). In particular, this is not an independence assertion about `Zi^8`, the representative, or first visibility.

The source-volume factors are precisely `di`, so the final cost is the genuine sum `sum di qi=sum|Fi|`. The proof does not substitute a number of targets, a number of groups, or a fictitious density bound for that cost.

More generally, at a fixed time `b`, replacing `1/16` by any `alpha>=0` with `alpha*b<1` gives

\[
\mathbb E\sum_i d_i\mathbf1_{\{N_i(b)=1\}}P_i
\le\frac{b}{1-\alpha b}\,U.                                 \tag{3}
\]

The path expansion of `Pi` is

\[
P_i=1+
\sum_{m\ge1}16^{-m}
\sum_{j_m<\cdots<j_1<i}
 c_{i j_1}c_{j_1j_2}\cdots c_{j_{m-1}j_m}
 B_{j_1}\cdots B_{j_m}.
\]

Thus (A2-C) pays all directed admission paths simultaneously. It is not obtained by bounding a single incoming Poisson count and then conditioning that bound on selection.

## 3. A precise joint box constraint and its limitation

Let `C=intersection_{j in J} Aj` be any nonempty common intersection of actual selected parents. Write its full coordinate side lengths as `ell_m(C)`. For any selected pair `j<i`, if the earlier parent does not capture the later center, then in at least one coordinate

\[
|y_{i,m}-y_{j,m}|>c_0s_j.
\]

Since `si<=sj`, the projection of `Ai intersect Aj` in that coordinate has length at most

\[
s_i+s_j-|y_{i,m}-y_{j,m}|
<s_i-\frac{s_j}{a}.
\]

Consequently, for the full common intersection,

\[
c_{ij}=0\quad\Longrightarrow\quad
\exists m:\ \ell_m(C)<s_i-s_j/a\le s_i.                     \tag{4}
\]

This implication retains the full same intersection `C`; it does not add a separate price for each possible offending coordinate. Conversely, if `ell_m(C)>=si` in every coordinate, all earlier selected parents capture `yi`.

Equation (4) explains a real connection between the whole capture graph and the product volume

\[
|C+c_0s_h[-1,1]^n|
=\prod_{m=1}^n(\ell_m(C)+2c_0s_h).                          \tag{5}
\]

It is insufficient to prove (A2-G). Many missing capture edges may all be explained by the same small set of coordinates. Equation (4) gives no distinct-coordinate allocation and does not license such an allocation. Conversely, many capture paths can arise from a geometrically concentrated selected family, but their number alone carries no dimension-free comparison with (5).

The actual source pieces supply more than a graph: they are disjoint and lie in the small `Bi`. A useful bridge must couple that spatial packing, the original high-`Th` witness, and the first-key law to (5). Neither (1) nor (4) alone supplies this coupling.

## 4. Exact point where the proof stops

The missing step is a quantitative full-family geometric transport or allocation showing that the original, Lebesgue-measured `S8`, including all first-visibility exclusions, can be paid by the capacity in (A2-C), or by a similarly integrable spatial refinement.

In particular, the following replacements have not been made:

- The common intersection point used in a geometric map is not treated as a new actual high-load witness. Moving within a sampled intersection need not preserve the original near load `Th>tau/2`.
- The residual receivers are not replaced by the single-source expanded-parent envelope; that costs `2^n` and removes the full-key constraint.
- The factors in (2) are not multiplied by the selected receiver set. Such multiplication would invalidate the proved independence.
- No bound on a pairwise geometric energy is substituted for the full `k`-source event.
- No product law is assumed for source coordinates.

A possible full-`k` change of variables would lift each source label to a point of its actual `Fi`, then attempt to spread a receiver displacement over all source points. The legal density fact is only `sum_i 1_{Fi}<=1`. A translation of a lifted point need not remain in its same `Fi`, and changing the source label can change its radius, admission order, witness membership and first-event exclusions. There is presently no invertible map with controlled multiplicity that preserves those constraints. A formal Jacobian gain such as `exp(Cn/k)` without this preservation is not a proof.

This identifies a specific unresolved geometric step rather than a new name for the Janossy remainder. The all-source capacity (A2-C) is independently valid; its adequacy to price the original full receiver geometry is OPEN.

## 5. Verification and scope

S2 independently checked the original-order measurability, each independence used in (2), the admission row-sum bound, and the resulting exact constant `16`. This proof is analytic and finite; no numerical experiment is offered as evidence for (A2-G). No expensive experiment, new source family, or altered Poisson model was introduced.

Only this file was written for A2. Work stops at the explicit unproved bridge (A2-G).
