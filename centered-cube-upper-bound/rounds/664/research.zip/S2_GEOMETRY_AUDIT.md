# R664 S2：新几何步骤的独立验收标准

已先读本轮 `TASK.md`，未先读A1/A2本轮作者文件；沿用已通过的R663定义与恒等式，不重审其证明。本文件只审本轮新增定量步骤的合法性。完整目标仍是对**全部实际有限状态**、同一全局共享Poisson律证明 `E|S_8|≤AU`，A不依赖n、source/target数、尺度范围或最小正q。聚合支付足够，不要求每个source系数统一有界。

## 四个最可能决定合法性的验收点

1. **分母必须保留实际来源体积，不能由选中后的代理质量代替。** 原预算是 `U=Σ_i|F_i|=Σ_i d_iq_i`，`F_i⊂B_i`真实不交；对固定规则的first-visible/minimum-source assignment，目标为 `Σ_i q_i e^{-8q_i}∫_0^8 E|Z_i^8(u;η_{-i})|du≤AΣ_i d_iq_i`。可换一个路径上不重复的分配、用可证明上包络、或直接付union，但必须明确新左端逐路径/期望支配原目标且右端仍只收同一U。对每个代表或每个tuple重复收来源体积，或将`Σd_i`/expanded parent体积视为U，均不能验收。真实F_i不交的Lebesgue控制不得移植成任意q标签密度或任意f的密度帽。

2. **all-source mutual admission是输入合同；削弱它须明说方向，不能以弱模型反例否定原问题。** 对每个实际接受source i，原测试为 `Σ_{j<i}w_j1_{c_0A_j}(y_i)≤1`，并有 `q_j≤w_j`；故每个中心均有相应q-rate限制。只检查所选minimum source的一行是可用的必要条件，但丢掉其他中心的限制后得到的是较大类。若能在较大类上同U证明上界，它合法；若构造在该较大类中的失败图形，除非恢复所有实际owner、admission及残余q资格，否则只否定该放松断言。共同cube-coordinate intersections、原半径序和所有来源的相互限制不能由任意incidence data替换。

3. **receiver是full Lebesgue x，residual是同时的空间排除。** `S_8`包含完成key区域halo后所有仍可见的x，不限于`B_i`、`F_i`、原损失`X_h`、parent内或某个共同点。它在**所有**globally marked parents之外；而每个覆盖该x的key中所有标签均全局恰一次（含完成后到8的future repeat pruning）。可删除这些限制以作非负上包络，但随后必须独立支付该更大空间对象，不能再用原排除带来的概率或几何增益。薄边界体积只能对确有Lebesgue背景的对象积分；q-overlap不能直接代空间volume。

4. **共享first visibility和source conditioning必须留在同一联合律中。** `Z_i^8`依赖完整[0,8]历史、代表和同一arrival完成的全部key，exact-one密度是 `q_i e^{-8q_i}du`；此future-dependent积分不能套predictable compensator。给定单个i恰一次后，其余未选择背景保持原Poisson律；中心incoming rate≤1仅给未选择背景count法则，不与所选`Z_i^8`/其体积独立。新的Poisson tail×体积、iid intersection或conditional contraction必须给出合法联合不等式；不能重抽每个target的key、把selected tuple宣称iid，或把first-visible切分改为重叠sum而丢失费用。允许全局可求和递推，但需保留initial、terminal、unfinished和simultaneous-union费用。

## 已发出的针对性审核请求

已分别向A1 `/root/r663_minvolume`、A2 `/root/r663_admission` 请求：第一个定量新不等式、变量与准确条件、如何支付同一完整对象，以及该步使用上述哪些输入。不索取整份历史、不先阅读作者本轮文件，不作无目标反例或数值扫描。

初始检查点时尚无新证明输入。上述四点是验收标准，不是新引理，也不证明AU支付。随后A1给出具体步骤及其精确失败族，针对审核见下；没有将未给出证明的作者探索方向判为已否定。

## A1 首个定量步骤：pair majorant接口PASS，支付强式被准确否定

A1消息给出的首步（未先读其本轮文件）：

`E_ij=((A_i∩A_j)+c_0 min(s_i,s_j)Q)\(A_i∪A_j)`，`L(x)=Σq_ℓ1_{A_ℓ}(x)`，

`E|S_b|≤[b²/binom(k,2)] Σ_{i<j}q_iq_j∫_{E_ij}e^{-bL(x)}dx`，`b=8`。

**上界接口独立审核通过。** 对任何`x∈S_b`，选中key有k个distinct globally-single标签；其每个pair的parent交集以`c_0min(s_i,s_j)`扩张包含原key halo，因原代表`s_h≤min(s_i,s_j)`，且x在这两个parents外。故路径上至少有`binom(k,2)`个合法marked pairs。先数**全部**marked pairs、并保留x在所有marked parents之外的事件，再对原过程求期望。对固定`x∈E_ij`，i、j不在`{ℓ:x∈A_ℓ}`中，因此原未选择process independence给

`P(N_i≥1,N_j≥1,∀ℓ:x∈A_ℓ,N_ℓ=0)=(1−e^{-bq_i})(1−e^{-bq_j})e^{-bL(x)}≤b²q_iq_j e^{-bL(x)}`。

这里没有声称selected pair与visibility独立。它确实是支配同一原对象的较强上包络；同时丢掉full-key、near以及其他global-single约束。若该pair能量真有绝对`CnU`界便足够，因为`binom(k,2)≥τ²=16384²n`，`b²n/binom(k,2)≤1/4194304`。但该能量界是额外强断言，不是已证结论。

**A1随后给出的精确否决族独立核对通过。** 取所有`s_i=1`，`a=32n`，用`a^n`个边长`2/a`的小`B_i`在`[-1,1]^n`铺砖，令`q_i=a^{-n}`。每个实际owner都是对应小砖（面界无关）；总q为1，所以对任意原次序，每个source中心的完整前admission负载≤1。残余阈值远大于1，q无截断，`F_i=E_i`，`U=2^n`。这是满足所有mutual admission与真实owners的族，但没有near损失，故`S_8=0`。

网格两独立中心每坐标平均距离为`2/3−2/(3a²)`，所以扩大pair intersection的平均边长

`M=10/3+2/a+2/(3a²)`。

全部有序pairs去掉diagonal，再用`|A_i∪A_j|≤2·2^n`减去parent interiors，且`L≤1`，得到

`pair_energy/U≥e^{-8}{(1/2)(M/2)^n−(1/2)[(4+2/a)/(2a)]^n−1}`。

其首项以至少`(5/3)^n`增长，因此不存在全n绝对`CnU`能量界。该族既然`S_8=0`，它只否定粗pair majorant预算，不反驳真实目标；将它描述为原near-state反例会错误。这个准确失败决定无需追加搜索或模拟。

本机已有Python 3.12.14 / SymPy 1.14.0只运行了上述网格一维求和与回代系数的精确核验，无高维枚举：

```python
import sympy as sp
A=sp.symbols('A', integer=True, positive=True)
r=sp.symbols('r', integer=True, nonnegative=True)
mean_abs=sp.simplify(4*sp.summation(r*(A-r),(r,1,A-1))/A**3)
M=sp.simplify(4+sp.Rational(2,1)/A-mean_abs)
assert mean_abs == sp.Rational(2,3)-sp.Rational(2,3)/A**2
assert M == sp.Rational(10,3)+sp.Rational(2,1)/A+sp.Rational(2,3)/A**2
print(mean_abs, M, sp.Rational(64,16384**2))
```

实际输出：`2/3−2/(3*A**2)`；`10/3+2/A+2/(3*A**2)`；`1/4194304`。这里A是网格每坐标砖数的求和变量，执行后代入`a=32n`，不是目标绝对常数。

已将上界PASS及准确失败范围反馈A1与主代理；A1若转向保留full key的自适应分配，则该新路线不受此pair失败自动否定。

## A2首个定量步骤：全图路径容量PASS，几何桥仍OPEN

A2在收尾时发来首步，仍未先读其本轮文件。这里以`J_i=1{N_i(8)=1}`重命名其原消息的Bernoulli符号，避免与prefix birth B_i混淆。各`J_i`是原process下独立Bernoulli，均值`p_i=8q_i e^{-8q_i}≤8q_i`；固定有向捕获关系`C(i,j)=1{j<i,y_i∈c_0A_j}`，并定义

`P_i=1+(1/16)Σ_{j<i}C(i,j)J_jP_j`。

候选定量结论为`EΣ_i d_iJ_iP_i≤16U`。**独立审核PASS。** DAG顺序使P_j只依赖索引小于j的Bernoulli，所以J_j与P_j独立。按i归纳，用每个实际source中心的`Σ_{j<i}C(i,j)q_j≤1`，

`EP_i=1+(1/16)ΣC(i,j)p_jEP_j≤1+(8/16)·2=2`。

同理J_i独立P_i，故`EΣd_iJ_iP_i≤Σd_i(8q_i)·2=16Σd_iq_i=16U`。所有求和有限、非负，不需要selected tuple、Zi或first visibility与incoming count独立。该结论在更大的确定有序图类（每行incoming q-rate≤1）也成立；它是合法上层容量预算，不改变真实分母，也没有从弱模型反例倒推原问题。

A2明确尚未证明的几何桥是`|S_8|≤CΣ_i d_iJ_iP_i`（或足够的聚合期望版本）。若以绝对C证明，便给`E|S_8|≤16C U`；但容量公式本身没有覆盖full-Lebesgue exterior、整key及first-visible分配，不能当作这座桥。对桥的审核必须回到前述四条验收标准。当前不存在该桥的证明输入，本审查没有签署它。

## 最终处分

本次决定性结果：四条原对象验收标准；A1 pair上界接口合法，但全pair能量CnU强式被真实低载铺砖族准确否定；A2全图路径容量`16U`通过，但尚缺支配原residual的定量几何桥。当前原`E|S_8|≤AU`仍OPEN。按任务边界交付后停止。
