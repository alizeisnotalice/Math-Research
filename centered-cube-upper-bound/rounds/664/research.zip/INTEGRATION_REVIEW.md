# R664 独立整合审查 — S2

**PASS（限报告实际声称的上界、模型结论及条件接受标准）；无必须修正的数学正文点。新的`E|S_8|≤AU`仍未证明。**

绑定`REPORT.tex` SHA-256：
`a4d4b024df1edb53a4d722facf1956cae77d34bff0682293d00d710fb8321e18`。

先审Conclusion与(1)(4)(12)，再读其余证明；必要对照A1、A3和`FULLKEY_MODEL.py/json`。初读旧hash后只复核Terra协作人数记录的修改，数学未变。既有S1/S2/S3数学套件、16例模型枚举及6例Arb均未重跑。只写本文件，未改报告或Git。

- **Conclusion与(1)：PASS。** 报告保留同一实际q、真实不交F_i、全部mutual admission、原代表/L_h、共享Poisson律和b=8。继承的两项付款与未付S_8界线准确，没有将模型检查或新恒等式写成一般维数改进。目标是全族加权预算，无须每个conditional source分别uniform。
- **完整矩上界(4)：PASS，但其AU预算OPEN。** 原S_b点的真实k-label key给一个J，common intersection和near-scale条件成立，原代表半径≤min_J s_j，故原halo包含于未扣parents的扩张交集，而原S_b点本来在所有已标记parents外，故该点属于E_J。对固定x∈E_J，J与`C_x={i:x∈A_i}`不交；原未选择process independence给exact-one因子`b^k e^{-bΣ_Jq_j}∏_Jq_j`和void因子`e^{-bL(x)}`。对所有J求正sum合法，未对selected代表分解独立性。repeat排除、L_h和跨J重合均只向上放松。因此(4)是更强的充分目标，不是原union的等价式；其失败也不否定原目标。
- **模型(5)–(7)：PASS，仅限等尺度product-grid铺砖模型。** 有限range tail-sum给(5)，递增x^k的左Riemann sum给其上界；只有此product grid可tensorize。distinct ordered sums扩为with-replacement sums并除k!只增加非负量，故(6)成立。由`log(k!)≥k log k−k`、a=32n及k≥32768√n，得`logF≤1/16+2n/(k+1)+k log(8e/k)`。进一步`2n/(k+1)≤k/2^29`、`8e/k<1/1024`和`log2>1/2`给`logF<1/16+k/2^29−5k<0`，所以all-n负号不是六点外推。JSON的scope、16项精确结果、六项256-bit scalar intervals及版本与报告一致；n=2^80不是高维几何模拟。模型本身无near，不能迁移为一般multiscale的AU界。
- **条件化、容量与(12)：PASS。** (8)在固定x对逐来源排除条件化，保留原q/I_h/L_h及完整历史；(9)未宣称selected代表独立。删除K_x外来源仅是overall membership上界，不是等式或selected-invoice单调性。common witness使固定目标的非空交集确定，不能再收Helly概率。graph capacity的独立步骤限原Bernoulli与更早DAG变量，`16U`未被当作几何付款；缺少graph-to-S_8桥。(11)先结构更新再算新增paid-set death，避免重记。对`A_n,θ_n≥0,0≤ρ_n<1`，两式消元确得`g_nV_near≤[(1−ρ_n)(8+δ_n)+A_n]U`，其中`g_n=(1−ρ_n)(1−e^{-τ/4})−θ_n`，故(12)正确；raw gap无需统一离零，但比值须统一受控，所有端点费用须先计入。低维near空，报告的全n版本是合法的更强充分要求。

唯一新增本机运算是对(7)最后一行的精确Fraction检查，不复跑模型：`slope=1/2^29−5=−2684354559/536870912`；在最小k=32768处，`1/16+k*slope=−2684353535/16384<0`。使用已有Python 3.12.14；这是标量代数核验，不是新几何证据。

**剩余缺口：** 对任意multiscale实际状态，仍无full-key/first-visible union的聚合几何支付。矩sum(4)、shared-race积分(9)、graph-to-geometry比较或满足(12)的新recurrence，均未得到足以支付同一S_8的AU控制。报告已明确这一点，可以按当前hash封版。
