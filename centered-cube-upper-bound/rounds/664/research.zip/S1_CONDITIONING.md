# S1 — fixed-receiver zero-event conditioning

Independent review, 2026-11-15. Input read before contacting A3: R664 TASK.md and R663 REPORT §§2–4, 7, in particular (5), (9), (13). No R664 author file was read in forming the conclusions below. Only this file is owned and written by S1.

## Decisive statement and what would pay

For the same complete finite actual input, put b=8. For every **deterministic** spatial point x, define the fixed label set and its fixed rate

C_x={i:q_i>0 and x in A_i},   ell(x)=sum_{i in C_x}q_i.

Let eta^{(x)} be the following whole-horizon configuration: every label in C_x has zero events on [0,b]; every remaining label retains its original independent rate-q_i Poisson process on [0,b]. All deterministic input data, including q, the original source/target order, I_h, L_h and the cubes, remain unchanged. Recompute the true first-k keys, their real representatives, first coverage and Q_b^rep from this one shared configuration. Define

Psi_b(x)=P{x in Omega_b(eta^{(x)}) minus Q_b^rep(eta^{(x)})}.

Then the exact identity is

E|S_b| = integral_R^n exp(-b ell(x)) Psi_b(x) dx.             (S1)

In particular 0<=Psi_b<=1. A quantitative estimate that would pay the same object is

integral exp(-8 ell(x)) Psi_8(x) dx <= A U,                  (S2)

with A absolute over all actual finite states. This review proves the conditioning identity and its scope, **not** (S2). The exponential factor is a valid new interface; its existence alone is not a complete-family payment.

## Proof with the full history retained

For each fixed x, the event x outside P_b^mark is exactly

E_x={N_i(b)=0 for every i in C_x}.

Indeed P_b^mark is the union of A_i for labels with at least one global event. The source-label processes are independent and the input is finite, so

P(E_x)=product_{i in C_x} exp(-b q_i)=exp(-b ell(x))>0.

For every nonnegative measurable functional H_x of the complete configuration on [0,b], ordinary conditioning gives

E[1_{E_x} H_x(eta)]
 =exp(-b ell(x)) E[H_x(eta^{(x)})].                         (S3)

To prove this, regard the independent process coordinates indexed by C_x and its complement as a product probability space. On E_x the former coordinates are exactly the empty configurations; conditioning does not change the latter product law. H_x may depend on all event times, future counts up to b, actual first visibility, all representatives, and the simultaneous completion of several keys. No adaptedness or predictability is needed.

Take H_x=1_{x in Omega_b(eta)}1_{x outside Q_b^rep(eta)}. The left side is P{x in S_b}. Under eta^{(x)}, x is already outside P_b^mark, so the remaining event is precisely that defining Psi_b. This proves the pointwise form of (S1). Tonelli then proves the spatial identity. The finite input has a deterministic bounded spatial envelope for all possible completed-key regions, so the spatial integrals are finite as well.

The order of operations matters: condition the complete process first, then evaluate the unchanged construction on that process. One cannot take a previously selected representative or key and assume its law survives the conditioning unchanged. Defining H_x by the full original construction is what preserves the correct selection correlations.

## Source-Janossy version

The same factor can be inserted into R663 (9)/(13) without changing the assignment rule. Fix a deterministic label i and a deterministic u in (0,b), force exactly one i-event at u, and otherwise use the original independent processes. If x in A_i, the forced event marks A_i and x cannot lie in the assigned residual; its contribution is zero.

For x outside A_i, kill all labels in C_x (which then does not contain i), force the single i-event, keep all remaining labels independent, and recompute the full construction. Let theta_i^b(x,u) be the probability that x belongs to the resulting residual and is assigned to i by the true first-coverage/minimum-volume/latest-index rule. Then 0<=theta<=1 and

E|S_b|
 =sum_i q_i exp(-b q_i) integral_0^b integral_{x outside A_i}
            exp(-b ell(x)) theta_i^b(x,u) dx du.              (S4)

This is just repeated nonnegative conditioning. The factor exp(-b q_i) belongs to the globally exact-one i-event; exp(-b ell(x)) belongs to the globally zero-event labels containing x. The two label sets are disjoint because x is restricted to A_i^c. There is no double counting of the i-rate. This identity retains the same true Janossy source invoice and hence the same aggregate target.

The source index i, the forced time u and the point x must be fixed when this conditioning is applied. Summing/integrating the resulting formula is legitimate by Tonelli. Applying a fixed-i or fixed-x independence assertion *after* choosing i or x from the random visible set is not justified.

## Quantifiers, edge cases and restrictions

- **Actual finite deterministic input.** Statements (S1)–(S4) hold for every actual finite state with its fixed q and fixed cubes. There is no assumption that a selected random representative is independent of the remaining processes. The identities would hold for any finite deterministic rate family; using that fact to replace the actual near construction by arbitrary incidence data would be an additional, unjustified step.

- **Empty and zero-rate cases.** If C_x is empty, ell(x)=0, E_x is the sure event, and the remaining law is unchanged. Zero-rate labels may be removed from C_x and from all processes. If all potentially useful streams are killed, no corresponding first-k key can complete, since k>=1. Any normalized active-label law with zero total rate is undefined and must be replaced by this zero-completion statement. For b=0, all keys are unfinished and the same identities are trivial. The current task uses b=8 and positive k.

- **Boundary conventions.** Use the same chosen cube membership convention in C_x, P_b, all I_h and all displayed events. With that convention, E_x equivalence and (S3) are pointwise for every fixed x, including cube boundaries. If geometric packing or low-load inequalities are known only Lebesgue-a.e., they remain only a.e.; the conditioning identity does not strengthen them at boundary points. For fixed original pools, witnesses and all other deterministic input, the finite union of cube boundaries is null, so changing only the spatial x-membership convention on those boundaries does not change the integrals. This does not authorize changing witness membership or regenerating I_h under another boundary convention. Event times at 0 or b, or simultaneous arrivals of distinct independent streams, have probability zero; impose a deterministic tie convention anyway. Simultaneous completion of several keys at one ordinary arrival can have positive probability and must still be handled by the prescribed union/tie rule.

- **Original deterministic low-load sets stay fixed.** Killing an event stream does not remove its q_j from L_h={x:sum_{j<h}q_j1_{A_j}(x)<=1}, from residual feasibility, from admission, or from the saturation witness data. In particular, a point excluded by the original L_h does not become admissible merely because all streams of parents containing x have been conditioned empty. This is a critical restriction on any use of Psi or theta.

- **Representatives are recomputed, not frozen or redrawn.** Targets retain their original source pools I_h, but their first-k event lists may change when streams in C_x are empty. Equal-key groups, earliest representatives and first-coverage competition must be computed in that same shared conditioned history. No independent resampling across targets is allowed. A representative selected under this law is generally biased.

- **What independence remains.** Before selecting a representative or visible point, all non-C_x source processes are independent with their original rates. For a fixed target h its available stream has total rate T_h^out(x)=sum_{j in I_h minus C_x}q_j. If positive, its first-k labels under this unselected background have the usual iid normalized law; if zero its key cannot complete. Conditioning further on being the winning representative, being first visible at x, repeat pruning, or membership in an assigned source set can bias the labels and their event times. The unconditional iid statement cannot be imported after that selection.

- **Repeat pruning is a future condition.** Under the killed law Q_b^rep is still built from all surviving labels' total counts up to b. It is generally not determined at a key's completion time. The same is true of S_b and the assigned Z_i^b. This is why (S3)/(S4) use ordinary product/Janossy conditioning and not a predictable compensator. The extraction of exp(-b ell) remains valid despite this future dependence because it conditions on the entire finite interval.

- **No second factorization is automatic.** Psi_b(x) is a probability under a law depending on x. It can correlate strongly with the deterministic load ell(x) through the geometry and which streams were removed. One cannot replace it by the original unconditioned coverage probability, a selected-anchor iid intersection estimate, or a probability independent of x. After selecting a key, the remaining source processes need not retain an independent law conditional on that selection.

- **Admission count after both conditionings.** For fixed i,x outside A_i, the original incoming set J_i^in={j<i:y_i in c0 A_j} remains fixed. Under the law used in (S4), its surviving background count is Poisson with mean b sum_{j in J_i^in minus C_x}q_j<=b, by actual admission. This is an unselected background statement. The event measured by theta can bias this count, so a selected-volume/tail product still needs proof.

## Independent conclusion and handoff

The precise extraction of exp(-8 ell(x)) is legitimate while preserving the complete true construction, provided the rest of the process is the unmodified independent law only on labels outside C_x and all keys/representatives/paid sets are recomputed there. The conditioned event has positive probability for every finite input; no regular-conditional-distribution ambiguity is needed. Spatial and time integrations follow from nonnegativity and the finite envelope.

The unproved quantitative step is (S2), or the equivalent weighted source formula (S4) bounded by A U. This document establishes legal conditioning and rejects the possible additional independence shortcuts; it does not claim the factor pays the high-dimensional halo.

A3 was sent the independent conclusions before any author proof was read and invited to send a concrete payment candidate for checking. No such candidate had been received when this initial delivery was written.

## Additional review — complete paid-set conditional law

Reviewed author: A3, `A3_RECEIVER.md`, SHA-256 `27df6aa8f3a619cff50ba667b58a0d03bdccb49ab3d59fcc8b8c3968356c13a6`. This is a review of its added complete paid-set law, outside-K processes and possible deletion; it does not rerun the earlier basic zero-event argument or commission computation.

**PASS for the exact conditional law and its claimed aggregate scope.** For fixed deterministic x, write K_x={i:x in A_i+c0 s_i[-1,1]^n}. Since C_x is contained in K_x, exclusion from both paid sets is precisely

E_x={N_i(8)=0 for i in C_x; N_i(8)<=1 for i in K_x minus C_x}.

Thus its probability is exactly

w_x=exp(-8 ell(x)) product_{i in K_x minus C_x} exp(-8q_i)(1+8q_i).

Each condition uses only its own original source-label process. Conditional independence therefore survives across labels before further key/receiver selection. On K_x minus C_x the count is Bernoulli with success probability 8q_i/(1+8q_i), and, given success, the single time is uniform on [0,8]. The uniform time is independent of all other labels' retained histories; an arbitrary auxiliary uniform variable may be attached to a failed Bernoulli trial without changing anything. C_x streams are empty. Outside K_x, all source processes remain their independent original rate-q_i Poisson processes, since E_x places no condition on them. Zero-rate labels give degenerate zero trials and factors one. The finite product is positive for every finite input.

For this conditional full-history law, and with the original q, I_h, L_h, witnesses and order unchanged, the exact statement is

P{x in S_8}=w_x P_x^{0/1}{x in Omega_8}.

All first keys, equal-key groups, earliest representatives and first visibility must be recomputed in that one shared conditional history. This is an ordinary full-interval conditional law; neither future repeat pruning nor representative selection invalidates it. Conversely these selections do not preserve label independence after they have been conditioned on. No independence across different receiver points x is asserted or needed for Tonelli.

### Outside-K deletion: a valid upper bound, not the exact law

For a target h using a source j, its source radius satisfies s_j>=s_h. If j is outside K_x, then x is outside A_j+c0 s_j Q and hence outside A_j+c0 s_h Q. Thus every outside-K event is x-bad for every actual target that uses it.

With q, I_h and L_h fixed, couple the exact conditional history to one in which all outside-K events are erased. For each completed target whose own halo contains x before erasure, its first k events were all x-good. Removing x-bad events cannot remove any of those first k successful events, cannot delay their completion and cannot make that own halo fail at x. This proves monotonicity target by target. The actual representative union is the same as the union of all completed targets' own halos: within an equal-key group, the earliest representative has larger radius and a superset L_h. Hence changes of group/representative under erasure do not invalidate the resulting global membership comparison. Almost surely there are no equal arrival times; prescribed fixed tie rules handle the null exceptional configurations.

Consequently, with `del(K_x^c)` denoting this common erasure,

P_x^{0/1}{x in Omega_8}
 <=P_x^{0/1,del(K_x^c)}{x in Omega_8}.                       (S5)

This is an upper bound, generally not equality: an outside-K event can be an early bad event that blocks a target's original first-k list. At this fixed x, erasing outside-K streams changes neither paid-set exclusion: those parents do not contain x, and their self-expanded parents do not contain x either. Therefore fixed-x residual membership has the same upper-bound monotonicity under this coupling.

The selected source, assigned Z_i, first-coverage time and representative can nevertheless change. No source-by-source or assignment-volume monotonicity follows from (S5). Erasing outside-K events also erases their useful bad-event interference: the original high T_h remains a deterministic input parameter but is no longer the total active stream rate after erasure. A proof using the enlarged law cannot silently retain the original first-k race denominator, a Poisson(8T_h) count, or the original bad-event survival probability. These are precisely the scope costs of this otherwise legal upper bound.

Similarly, adding C_x events is monotone for Omega_8 membership at x, because those labels are x-good whenever used; this says nothing analogous for the paid residual when its exclusions change. Original deterministic L_h and q remain fixed in both comparisons.

### Remaining gap and disposition

The complete conditioning law adds genuine singleton information while retaining all outside-K blockers in its exact form. It still gives only the representation of E|S_8| as the spatial integral of w_x times the conditional probability of the actual shared union. No absolute integral bound, cross-target independence, selected-representative iid law, or per-source payment follows from this review. The A3 manuscript itself states that its weighted shared-race estimate is open; this is the correct scope.

Disposition: complete paid-set source law PASS; original outside-K processes are required for equality; monotone deletion is allowed only as the aggregate upper bound (S5), with the above loss of active-rate information. No budget payment or dimension improvement is certified. Only S1_CONDITIONING.md was appended; A3's file was not changed.

### Final binding addendum — A4 quantifier restriction

Only the notified A4 quantifier change was checked at finalization: the author now states `For every complete deterministic history satisfying E_x (hence under P_x^{0/1})`. The current A3_RECEIVER.md SHA-256 was verified as `25079fd428e0f10c0d55b734b2393d9a4e7a479ac2b3fd00c879c59ed726b6f6`. This restriction supplies the C_x-zero-stream premise needed for the displayed good/bad race that omits C_x, and is consistent with the conditional-law scope audited above. The previous bound version and its hash remain recorded in this file as review history. No other claim was re-reviewed and no computation was rerun. The PASS disposition for the complete paid-set conditional law and the OPEN disposition for global payment are unchanged.
