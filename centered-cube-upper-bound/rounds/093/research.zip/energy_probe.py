"""R93 public continuum all-scale excess-energy certificates, stdlib only.
New axial/radial positive atomic inputs; no original Fnew qualification.
"""
from fractions import Fraction as F
from functools import lru_cache
from itertools import product
from math import inf, log, sqrt
import argparse
import json
import time

BITS = 44
DEN = 1 << BITS

def floorq(x):
    return x.numerator // x.denominator

def ceilq(x):
    return -floorq(-x)

def series_log(q):
    assert 1 <= q <= 2
    t = (q - 1) / (q + 1)
    s = F(0)
    p = t
    for j in range(40):
        s += 2 * p / (2*j + 1)
        p *= t*t
    tail = 2*p / (81*(1-t*t))
    return s, s+tail

LOG2 = series_log(F(2))

@lru_cache(None)
def log_bounds(q):
    assert q > 0
    k = 0
    z = q
    while z >= 2:
        z /= 2
        k += 1
    while z < 1:
        z *= 2
        k -= 1
    lo, hi = series_log(z)
    if k >= 0:
        lo, hi = lo+k*LOG2[0], hi+k*LOG2[1]
    else:
        lo, hi = lo+k*LOG2[1], hi+k*LOG2[0]
    return F(floorq(lo*DEN), DEN), F(ceilq(hi*DEN), DEN)

@lru_cache(None)
def energy(n, arrivals):
    """Integral (sum mass 1_{L>=r}/L**n - 1)_+**2 dL/L.
    arrivals is sorted tuple (full-side distance, mass), mass sums to one.
    Returns rigorous fixed-dyadic bounds or None for +infinity.
    """
    grouped = {}
    for r, m in arrivals:
        grouped[r] = grouped.get(r, F(0)) + m
    points = sorted(grouped)
    if points[0] == 0:
        return None
    total = F(0)
    elo = ehi = F(0)
    for i, r in enumerate(points):
        total += grouped[r]
        u0 = r**n
        u1 = min(total, points[i+1]**n) if i+1 < len(points) else total
        if u0 >= u1:
            continue
        rational = total*total*(1/u0**2-1/u1**2)/(2*n) - 2*total*(1/u0-1/u1)/n
        l0, h0 = log_bounds(u0)
        l1, h1 = log_bounds(u1)
        elo += rational+(l1-h0)/n
        ehi += rational+(h1-l0)/n
    return max(F(0), F(floorq(elo*DEN), DEN)), max(F(0), F(ceilq(ehi*DEN), DEN))


from pathlib import Path
import hashlib
import base64
import zlib

def rational(x):
    return str(x)

def interval(lo, hi):
    assert 0 <= lo <= hi
    return {'lower':str(lo),'upper':str(hi),
            'display_only':[float(lo),float(hi)]}

def compressed_cells(n, atoms, mesh):
    """Full dx partition, not receiver samples or dimension reduction.

    atoms are (first coordinate, mass), all other source coordinates zero.
    For n>1 the radial coordinate represents every transverse orthant.
    """
    assert n >= 1 and sum(m for _,m in atoms)==1 and all(m>0 for _,m in atoms)
    h=F(1,mesh)
    axlo=floorq((min(z for z,_ in atoms)-F(1,2))*mesh)
    axhi=ceilq((max(z for z,_ in atoms)+F(1,2))*mesh)
    assert mesh%2==0
    cells=[]
    for i in range(axlo,axhi):
        a=i*h
        radial=[None] if n==1 else range(mesh//2)
        for j in radial:
            t0,t1=(F(0),F(0)) if j is None else (j*h,(j+1)*h)
            volume=h if n==1 else h*((2*t1)**(n-1)-(2*t0)**(n-1))
            assert volume>0
            near=tuple(sorted((2*max(max(a-z,z-a-h,F(0)),t0),m) for z,m in atoms))
            far=tuple(sorted((2*max(abs(a-z),abs(a+h-z),t1),m) for z,m in atoms))
            elo=energy(n,far)
            ehi=energy(n,near)
            assert elo is not None
            if ehi is not None:assert elo[0]<=ehi[1]
            cells.append({'id':[i,j], 'volume':volume, 'energy_lower':elo[0],
                          'energy_upper':None if ehi is None else ehi[1]})
    actual_domain=F(axhi-axlo,mesh)
    assert sum(c['volume'] for c in cells)==actual_domain
    return cells,actual_domain

def trim_bound(cells,budget,key):
    """Fractional density sorting is exact for the piecewise constant envelope."""
    assert budget>=0
    ordered=sorted(cells,key=lambda c:(c[key] is None,
                   F(0) if c[key] is None else c[key],str(c['id'])),reverse=True)
    remaining=budget; deleted=F(0); value=F(0); singular_remaining=False
    full=[];partial=None
    for c in ordered:
        take=min(remaining,c['volume'])
        remaining-=take;deleted+=take
        if take==c['volume']:full.append(c['id'])
        elif take>0:
            assert partial is None
            partial={'cell':c['id'],'deleted_volume':str(take),
                     'axial_slice_fraction':str(take/c['volume'])}
        kept=c['volume']-take
        if kept and c[key] is None:singular_remaining=True
        elif kept:value+=kept*c[key]
    assert deleted<=budget
    payload=json.dumps(full,separators=(',',':')).encode()
    return None if singular_remaining else value,{
        'actual_cap_volume':str(deleted),
        'fully_deleted_cells_zlib_base85':base64.b85encode(zlib.compress(payload,9)).decode(),
        'fully_deleted_cell_count':len(full),
        'fully_deleted_cell_ids_sha256':hashlib.sha256(payload).hexdigest(),
        'witness_codec':'base85(zlib(UTF8 compact JSON list of exact [axial_index,radial_index] IDs))',
        'partial_cell':partial,'single_cap_independent_of_scale':True,
        'partial_realization':'left axial slice of stated fraction, same entire transverse ring',
        'singular_upper_cells_remaining':singular_remaining}

BUDGETS=(F(1,16),F(1,4),F(1,2),F(1))

def continuum_case(name,n,atoms,mesh):
    cells,domain=compressed_cells(n,atoms,mesh)
    encoded=[{'id':c['id'],'volume':str(c['volume']),
              'lower':str(c['energy_lower']),
              'upper':None if c['energy_upper'] is None else str(c['energy_upper'])} for c in cells]
    digest=hashlib.sha256(json.dumps(encoded,sort_keys=True,separators=(',',':')).encode()).hexdigest()
    curves=[]
    for budget in BUDGETS:
        lower,_=trim_bound(cells,budget,'energy_lower')
        upper,cap=trim_bound(cells,budget,'energy_upper')
        assert lower is not None
        if upper is not None:assert lower<=upper
        curves.append({'cap_budget':str(budget),'optimum_over_all_measurable_caps_lower':str(lower),
            'selected_single_cap_upper':None if upper is None else str(upper),
            'status':'FINITE_UPPER_CERTIFIED' if upper is not None else 'UPPER_UNKNOWN_SINGULAR_CELL',
            'display_only':[float(lower),None if upper is None else float(upper)],'selected_cap':cap})
    return {'name':name,'n':n,'atoms_axis_mass':[[str(z),str(m)] for z,m in atoms],
       'mesh':mesh,'compressed_cells':len(cells),'cell_payload_sha256':digest,
       'full_receiver_domain_volume':str(domain),
       'transverse_volume':'h*((2*t1)^(n-1)-(2*t0)^(n-1)); every orthant, n=1 separately h',
       'outside_receiver_domain_energy':'exactly zero',
       'scale_complement':'L>=1 exactly zero; all 0<L<1 integrated by arrival primitive',
       'infinite_upper_cells':sum(c['energy_upper'] is None for c in cells),
       'infinite_upper_total_volume':str(sum((c['volume'] for c in cells if c['energy_upper'] is None),F(0))),
       'budgets':curves}

def separated_optimum(n,budget):
    """Exact continuum rearrangement formula, not a quadrature."""
    if budget>=1:return F(0),F(0)
    lo,hi=log_bounds(budget)
    r=2+1/(2*budget)-F(5,2)*budget
    return max(F(0),(r+(2+budget)*lo)/n),max(F(0),(r+(2+budget)*hi)/n)

def separated_case(n):
    masses=[F(1,2),F(1,4),F(1,8),F(1,16),F(1,32),F(1,64),F(1,128),F(1,128)]
    assert sum(masses)==1
    atoms=[(F(2*j),m) for j,m in enumerate(masses)]
    assert all(atoms[j+1][0]-atoms[j][0]>=2 for j in range(len(atoms)-1))
    return {'name':'separated_unequal_exact_calibration','n':n,
       'atoms_axis_mass':[[str(z),str(m)] for z,m in atoms],
       'positive_support_union_volume':'1',
       'no_joint_positive_excess_capture':'pair axis distance>=2 while L<1',
       'higher_dimensional_operation':'implicit product cube volumes; no 2^n enumeration',
       'curves':[{'cap_budget':str(a),'optimal_energy_interval':interval(*separated_optimum(n,a)),
          'single_cap':'union_i centered cube with side (a*mass_i)^(1/n)',
          'actual_cap_volume':str(a),
          'each_component_cap_volume':[str(a*m) for m in masses],
          'optimum_and_selected_cap_coincide':True} for a in BUDGETS]}

def run():
    nested=[(F(0),F(1,2)),(F(1,16),F(1,4)),(F(1,4),F(1,8)),(F(3,4),F(1,8))]
    halo=[(F(-1,4),F(1,8)),(F(-1,64),F(3,8)),(F(1,64),F(3,8)),(F(1,4),F(1,8))]
    clustered=[(F(0),F(15,32)),(F(1,128),F(1,32)),(F(1,8),F(1,4)),
               (F(3,4),F(1,8)),(F(3,2),F(1,8))]
    stages=[
      ('pilot',[('nested_unequal',1,nested,128),('cluster_and_halo',2,halo,16)],[4]),
      ('stress',[('tiny_satellite_and_far_halo',1,clustered,128),('nested_unequal',4,nested,32)],[16,64]),
      ('expanded',[('cluster_and_halo',8,halo,32),('nested_unequal',16,nested,32),
                    ('nested_unequal',32,nested,64),
                    ('tiny_satellite_and_far_halo_refined',1,clustered,256)],[256,4096])]
    out=[]
    for stage,cases,ns in stages:
        row={'stage':stage,'continuum_certificates':[continuum_case(*x) for x in cases],
             'analytic_calibrations':[separated_case(n) for n in ns]}
        out.append(row)
        print(json.dumps({'stage':stage,'new_inputs':len(cases),'compressed_cells':sum(x['compressed_cells'] for x in row['continuum_certificates'])}),flush=True)
    return {'schema':'R93-neutral-continuum-all-scale-energy-v1','mass':'1','kappa':'1',
       'public_neutral_inputs':True,'original_Fnew_gates_claimed':False,
       'cap_budget_unit':'actual Lebesgue volume A*W/kappa, W=kappa=1',
       'optimization_direction':'arbitrary measurable cap optimum lower versus one fixed-in-L measurable selected cap upper',
       'log_certificate':'40-term rational atanh with rigorous tail, outward dyadic44',
       'stages':out,'total_new_compressed_cells':sum(c['compressed_cells'] for s in out for c in s['continuum_certificates']),
       'total_grid_energy_budget_certificates':sum(len(c['budgets']) for s in out for c in s['continuum_certificates']),
       'total_analytic_budget_certificates':sum(len(c['curves']) for s in out for c in s['analytic_calibrations']),
       'unknown_remainder':'none for finite-input energy domain/scales; possible upper UNKNOWN only if singular cells not fully removed',
       'general_uniform_cap_energy_bound':'UNPROVED; no asymptotic fit or diffuse energy-limit transfer'}

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--output',default=str(Path(__file__).with_name('energy_results.json')))
    args=parser.parse_args();start=time.perf_counter();result=run()
    Path(args.output).write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
    print(json.dumps({'output':args.output,'cells':result['total_new_compressed_cells'],
                      'seconds_diagnostic':time.perf_counter()-start}),flush=True)

