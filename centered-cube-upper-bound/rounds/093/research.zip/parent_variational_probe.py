"""Exact finite simple-field probes. These are NOT physical cube examples."""
from fractions import Fraction as F
from pathlib import Path
import itertools,json,random,time

def encode(x):return 'infinity' if x is None else [x.numerator,x.denominator]

def trim(field,a):
    """None denotes positive infinity; every cell has a genuine volume."""
    assert a>=0 and all(w>=0 and (v is None or v>=0) for w,v in field)
    infinite=sum((w for w,v in field if v is None),F(0))
    if infinite>a:return None
    left=a-infinite;ans=F(0)
    for w,v in sorted(((w,v) for w,v in field if v is not None),key=lambda z:z[1],reverse=True):
        take=min(w,left);left-=take;ans+=(w-take)*v
    return ans

def dual(field,a):
    infinite=sum((w for w,v in field if v is None),F(0))
    if infinite>a:return None # exact positive asymptotic slope, not a sampled maximum
    levels={F(0)}|{v for w,v in field if v is not None}
    return max(sum((w*(t if v is None else min(v,t)) for w,v in field),F(0))-a*t for t in levels)

def layer(field,a):
    infinite=sum((w for w,v in field if v is None),F(0))
    if infinite>a:return None
    levels=sorted({F(0)}|{v for w,v in field if v is not None})
    ans=F(0)
    for lo,hi in zip(levels,levels[1:]):
        d=sum((w for w,v in field if v is None or v>lo),F(0))
        ans+=(hi-lo)*max(F(0),d-a)
    return ans

def main():
    start=time.monotonic();rng=random.Random(930012);records=[];counts={}
    def stage(name,num,mmax,allow_inf):
        checks=0
        for q in range(num):
            m=1+rng.randrange(mmax)
            fields=[[(F(rng.randrange(0,9),8),F(rng.randrange(0,49),1+rng.randrange(9))) for _ in range(m)] for j in range(3)]
            if allow_inf and q%4==0:fields[0][q%m]=(fields[0][q%m][0],None)
            a=F(rng.randrange(0,8*m+1),8)
            for f in fields:
                assert trim(f,a)==dual(f,a)==layer(f,a);checks+=1
            # common physical cell volumes, three finite energy components
            weights=[F(1+rng.randrange(8),8) for _ in range(m)]
            parts=[[(weights[i],F(rng.randrange(17),1+rng.randrange(5))) for i in range(m)] for j in range(3)]
            total=[(weights[i],sum((parts[j][i][1] for j in range(3)),F(0))) for i in range(m)]
            phi=trim(total,a)
            assert phi>=sum((trim(p,a) for p in parts),F(0));checks+=1
            # Any budget split is a legitimate union-cap upper; tagged-space optimum is sharper.
            alloc=[a/F(6),a/F(3),a/F(2)]
            assert phi<=sum((trim(p,b) for p,b in zip(parts,alloc)),F(0));checks+=1
            tagged=[cell for p in parts for cell in p]
            assert phi<=trim(tagged,a)==dual(tagged,a);checks+=1
            # Phi is convex in deletion volume and concave/homogeneous in its energy field.
            aa=a/F(2);bb=a+F(1,3)
            assert 2*trim(total,(aa+bb)/2)<=trim(total,aa)+trim(total,bb);checks+=1
            average=[(weights[i],(parts[0][i][1]+parts[1][i][1])/2) for i in range(m)]
            assert 2*trim(average,a)>=trim(parts[0],a)+trim(parts[1],a);checks+=1
            records.append(dict(stage=name,cells=m,budget=encode(a),common=encode(phi),tagged=encode(trim(tagged,a))))
        counts[name]=checks
    stage('pilot',12,4,False)
    stage('known_obstruction_stress',32,12,True)
    stage('expanded',96,64,True)
    # Shared-cap and labelled-space mistakes: new exact generic witnesses, not cube counterexamples.
    for m in [2,3,8,32,128]:
        H=F(m+1,3);a=F(1)
        separate=[(F(1),H) for _ in range(m)]
        identical=[(F(1),m*H)]
        assert trim(separate,a)==(m-1)*H and trim(identical,a)==0
        counts['obstruction_witnesses']=counts.get('obstruction_witnesses',0)+2
    # Nonattainment model: e=infinity on volume a; outside levels 2^j on volume 2^(-2j).
    # For tau=2^J, entire infinite tail is exactly summable, not discarded.
    tails=[]
    for J in [1,2,4,8,16,64]:
        clamped=F(1)-F(2,3)*F(1,2**J)
        # sum_{j<=J}2^-j + tau*sum_{j>J}4^-j
        direct=sum((F(1,2**j) for j in range(1,J+1)),F(0))+F(2**J,3*4**J)
        assert clamped==direct<1
        tails.append(dict(J=J,value=encode(clamped),gap=encode(1-clamped)))
        counts['nonattainment_exact_tails']=counts.get('nonattainment_exact_tails',0)+1
    result=dict(status='PASS',scope='Finite exact generic simple-energy fields and one explicitly summable infinite-field model; NOT actual cube geometry, no general energy bound.',
        assertions=sum(counts.values()),counts=counts,records=records,nonattainment=tails,runtime_seconds=time.monotonic()-start)
    return result

if __name__=='__main__':
    result=main();out=Path(__file__).with_name('parent_variational_results.json')
    out.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k not in ['records','nonattainment']},ensure_ascii=False))
