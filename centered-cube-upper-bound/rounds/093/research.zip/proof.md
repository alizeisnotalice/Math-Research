# 中心立方体第93轮：部分需求势与共同删集能量

2026-10-12。目标仍是任意非负 L1 输入、真实勒贝格接收测度上的 n^(1/2+o(1)) 一致弱型上界。**一般目标尚未证明**，保留 O(n log n) 一般基准。本轮复用八个研究角色：三条 Astra high 路线、Astra high 与 Sol high 独审、两名 Sol high 数值角色及一名 Sol high 文献与更新技能角色。Sol 审计因连接中断由同模型新 Agent 接续，并重新独立核验。

本轮最直接的进展是部分需求递推。继续接收行仅先付父子阈值之差，子分类仍按父阈值足额付费；真实来源退出和嵌套环损失由同一势支付。阈值漂移、子分类、来源退出及终项全部已计入原来源质量预算。旧方案中反复放大的来源占用不再是这个新递推的前提；但剩余几何势仍有 H_n=1+n log 2 的线性费用，故没有得到根阶改进。该势还精确包含当前需求，不能把它的初始根阶预算当作现成工具。

共同删集路线得到真实来源簇的全尺度自身能量和精确交叠核，并保留一个独立于尺度的接收删集。核的逐点折扣与完整环域积分同时写出，避免将逐点小系数误作来源对总量的小预算。任意来源的统一交互估计仍缺。另一条路线改善小簇自身能量，但没有把受限浓缩情形充当全类覆盖。

主代理证明非原子接收空间上删集能量的精确阈值对偶，处理无穷能量、非取到情形和尺度预算分配。文献组从实际立方体乘子得到尺度差分平方函数的 18+2 log n 型 L2 平方范数上界，并完整记录标准端点转移的指数费用。两项工具都没有自动给出原正超额能量的统一预算。

新中性输入检验保留 7520 个连续接收区域的真实体积和全尺度积分，32 个删集预算中 31 个有限上界、1 个网格 UNKNOWN。另一项私人模型检验得到完整周期 Haar 的正体积硬见证，原平滑上门和粗门仍 UNKNOWN。三阶段范围、独立重放和精确证书与浮点显示的区别详列文末；有限结果不推定维数指数。私人来源、未公开下界配方和新构造压力结论仅留本地。

本轮公开报告、详细 LaTeX 文本及必要复现材料单独归档，不编译 PDF。一般回代所需的全尺度、分层及完整余集费用全部保留。


## 第93轮保留主账与剩余量

令 `mu=f dy`，`Q(x,L)=x+[-L/2,L/2]^n`，`L in [1,2]`，需求为真实 `lambda dx`。保持原锚点 `A_1 f < lambda/2`、原平滑核的全窗口上界、严格后见证、原最早硬接触 `A_L* f=lambda` 及原中间下限 `exp(-s_n)/2`。每次实际删源并重选时重新检查全部门；来源主闭包保旧接触及旧前缀，不自动保原中间下限或严格后见证。

设 `H=1+n log 2`，`theta=log^-2(n+2)`，`alpha=epsilon=1/[10log(n+2)]`，`c=1-alpha-epsilon`，`beta=c/2`。已付费用完整保留：

- `B_base=4+2log2 sqrt(7n/3)`，`B_ext=2H/sqrt(n+2)`。
- `T_soft=1+log2 min(2n,sqrt[n(theta^-1+4theta/3)])`，粗平滑付 `T_soft/alpha`。
- 原包网格 `h0=1/(16n^2)`，`a=n^-p`、`rho=n^-1/2`，`p>0` 为原先固定值；`P_dom=(5+3log(1/a))/rho`。
- `h*=1/(16n^(3/2))`，`E=exp(nh*)`，`B_h=1+E[1+(2n^2+n)h*]`。后验物理碰撞至少 `3/4` 或平均网格熵至多 `sqrt n` 的并集一次支付 `P_phys=2[E+B_h+2(1+E)sqrt n]`。
- 完整未付余集 `Fnew=Fdiff ∩ {C_h*<3/4, Hbar_h*>sqrt n}`；`Fdiff` 为原粗平滑低中间分支删除原 dominant-packet 事件后的集合。

只有支付整个 `Fnew` 的 `D_new` 才能代入

`C_n^square <= C_loc log(n+2)[B_base+B_ext+T_soft/alpha+P_dom+P_phys+D_new]`。

若逐原 `kappa=1+log[lambda/(2P_1,L*)]` 二进层证明，则另付 `J_n=O(log n)`；第90轮薄片分支及本轮有限浓缩轮廓均未证明覆盖并支付整个 Fnew，原主账尚未因此得到一般新收益；这些层或全尺度费用均保留。私人诊断使用的某个 `p` 值只认证其对应分支，不能把该值替换原账上任意指定的 `p`。

### 保留的容量、规范方差与通量接口

对每个正规紧致 `B subset Fnew`、连续原尺度和每个正主割 `(A_s,S_s)`，真实源邻域等于 `S_s`（模 mu），`D_s=lambda|A_s|=integral_Ss b* dmu`。规范列 `b_A<=H`。第88轮已证明：若对每个这样的主割重新计算均有 `I_T(A_s)<=R_n mu(S_s)/n`，`T=sqrt(24nR_n+96)`，则所有割比至多 `2T`，经 Lusin、内正则性与 Borel Hall 得完整条件回代。所需 `R_n=n^{o(1)}` 尚未证明。

一般可测停止图保精确通量 `D-a=B_face-V_bulk`，且整体锚点 `a<=mu(S)`。故 `B_face-V_bulk<=C_root mu(S)+D/2` 足以推出 `D<=2(1+C_root)mu(S)`；仅凭逐点锚点小于半接触不能替代整体锚点预算。两项的逐正部分估计仍各为线性维数。第89轮配对抽样保留了该有符号差；第90轮有限厚度只支付其中一部分，完整差尚无统一根阶上界。

### 第90轮保留工具及其互补项

有限厚度 δ 的真实面替代项具有精确费用 a_n(δ)log2·M，a_n(δ)=E(Bin(n,δ)−nδ)_+/δ≤(1/2)sqrt[n(1−δ)/δ]。固定 δ=1/2 确实是根阶。完整余项仍为同一来源的平移差与两个接收行停止函数差的乘积积分；它没有消失。仅以来源 L1 平移模量支付时，允许 δ 依赖输入也存在至少 nM/2 的证书费用障碍。这不是对实际有符号余项或主割容量的反例。

部分坐标薄片分支的已证单包费用为 [1+(n−k)log2]prod_j(1+h_j)。一组共同来源包保留真实捕获份额，得到其分支的全子割支付；有限包覆盖的遗漏源还按 H_n W_bad/τ 显式支付。任意来源尚无满足根阶费用的此类覆盖；总坐标原子质量不足以推出接近全坐标的少包覆盖。若将这一分支加入原递推，每一步新费用与全部旧费用、阈值权重 t_i 及最终 H_n t_ell W_ell 必须保留；主账没有把该分支虚加为一般收益。原第89轮持续高负担逼出的坐标原子约束仍是必要条件，不是矛盾。

精确奇异平面模型中，sup_L L^(-k)A_L 的正核包络具有 1+m/k 型系数，但正常接收纤维的需求是 λ∫T^k。逐纤维层蛋糕回代恢复 1+(m+k)log2；直接已证费为 1+m log2。更强的真实弱型费尚未证明，也没有被该记账障碍否定。

Gamma 平滑的新增一般转移定理要求一个真实共同阈值事件并集、统一上下有界周期密度，以及完整维数/截断费用。它为任何共同 Cesàro 主项加全尺度误差的比较给出必要误差费用 (sqrt(B)−sqrt(A))_+²；没有构造该误差的上界。真实目录应用与新下界结论留在私人区，不在公开包中。直接假设 Gamma 极大族的 subpower 弱型界不再作为可用工具。

原 P1 与 coarse 的 Fourier 乘子、连续相位/尺度包络、级数尾及正有限截断方向已从定义证明。实际物理证书及其失败范围见数值节。连续首次接触和全窗口软上界均不能单独代替完整 Fnew；单元检验不涵盖未被选择的接收集或主来源割。一般规范高列方差、共同有符号差、来源集中跨层费用和完整回代均继续开放。

### 第93轮新递推替代及剩余几何费用

旧全需求方案的beta^(-i)加权占用依旧不能假定可付；第93轮改用部分需求运输，不再依赖该假设。每个继续接收行只先付(1−beta)lambda_i，其余lambda_(i+1)留给子状态。子分类异常必须按父阈值足额支付A_old W_(i+1)/beta。真实删源只退出一次，真实嵌套环对每对(x,y)只出现一次。

令u=1−epsilon，a_part=2/c−1，b_part=2/c，K=2 A_old u/[beta(1−beta)]，psi(z)=max(1,2||z||inf)^(-n)1_{||z||inf<=1}，其积分H_n=1+nlog2。真实势Psi_i=∫mu_i(dy)∫B_i psi(x−y)1_Qi(y)dx，P_i=b_part K W_i+a_part Psi_i。严格证明 .5(D_i−D_(i+1))<=P_i−P_(i+1)，在无限活跃链上D_m、P_m都趋零；若有限步接收集为空，则D_terminal=0，可能非零的P_terminal以正确符号丢弃，故D_0<=2(b_part K+a_part H_n)W_0。A_old为原全部已付分类费用，原全尺度和分层返回另行保留。

这真正支付了原来源质量下的阈值漂移、源退出、子分类和终项，不再把D_0占用账当作W_0预算。但其几何项仍为线性H_n。精确恒等式Psi_i=D_i+n∫B_i∫1^L_i T_s mu_i ds/s dx说明Psi_i本身包含需求；把初始Psi替换为根阶上界仍需新的几何证明，不能视作现成弱于目标的条件。只有改善真实累积环流容量或构造有已付缺陷的新势，才能得到目标收益。

### 第93轮一般能量路线的精确接口

原全尺度共同删集条件不变：对每个来源nu及kappa，有一个独立于L的Omega，体积<=A W/kappa、外部正超额平方能量<=B kappa W，则弱常数<=4A+2sqrt(2nAB)。对子阈值输入、弱极限及任意L1的合法传递只用已证条件，不能由有限证书推出A、B子幂。

真实共同接收交叠核K_n(d)=∫_{||d||inf}^∞ L^(-2n−1)∏(L−|d_j|)dL给出全部尺度交叉能量。其逐点界为||d||inf^(-n)/[n(n+1)]，多坐标最大位移有beta积分折扣；但其完整环域积分恰为log(b/a)，不因n变小。不得把逐点折扣直接称作一般来源对总量的降维费用。

若nu=Σnu_j且每个真实簇支持在Q(c_j,epsilon(W_j/kappa)^(1/n))，同一Omega=∪Q(c_j,(W_j/kappa)^(1/n))体积<=W/kappa，外部能量<=kappa W b_n(epsilon)/n+2Σ_{i<j}∬K_n(y−z)dnu_i dnu_j。所有自身项已付；交互项和任意输入的合法分解尚未统一。有限原子可取单原子分解，但交互费用可能很大；一般有界密度还受C epsilon^n>=1的必要条件约束，不能假定浓缩分解总存在。来源中心的小簇上界可改进自身项，不消去任意来源交互。

Phi_a(e)=inf_|Omega|<=a∫Omega^c e 的精确阈值对偶、扩展无穷情形和尺度预算分配已直接证明。带尺度标签空间会重复计接收体积；其最优预算分配只给原空间上界，不等于原空间最优费用。没有作未合法的sup/inf交换或由凸矩极点替代非线性能量目标。

实际方体尺度差分S_L=A_L−A_(2L)具有L2(dx dL/L)平方范数上界18+2logn。但标准抵消平方函数端点包含2^n与R^n费用，原正超额与抵消能量之间尚无共同删集支配。文献定理和此新L2工具不能自动填补这一缺口。

### 第93轮数值资格范围

新中性有限原子测试保留7520连续区域的真实体积、32共同删集预算，31有限上界及1网格UNKNOWN；20项分离族闭式校准不代表一般高维输入。完整周期Haar检验保留有限乘积似然和全部n个区间宽度，证得正体积固定节点硬见证及每坐标完整投影；原全窗平滑上门、粗门仍UNKNOWN，不能声称Fnew体积、主割负担、完整覆盖或根阶上界。私人来源和新构造反例只留本地。总目标继续开放。


## 1. Outcome and quantifiers

The general common-cap energy premise remains **OPEN**. This round proves an actual geometric energy estimate for a common cap built from pooled source clusters. The estimate includes every scale and the true receiver volume. Its cross term gains a factor \(n+1\) over the crude radial bound by retaining one coordinate of the actual intersection of two receiver cubes. Further coordinate separation gives an exact beta-function discount. The remaining source-pair interaction is retained, and an arbitrary input is not assumed to admit a useful cluster decomposition.

Let \(\nu\) be a finite positive Borel measure on \(\mathbb R^n\), \(n\ge2\), of mass \(W\), and let \(\kappa>0\). Full-side centered cubes are denoted by \(Q(x,L)\). Define
\[
 T_L\nu(x)=L^{-n}\nu(Q(x,L)),\qquad
 \mathcal E_\kappa(\nu;\Omega)=
 \int_{\Omega^c}\int_0^\infty(T_L\nu(x)-\kappa)_+^2\,\frac{dL}{L}\,dx.
 \tag{1}
\]
Every cap below is one measurable set independent of \(L\). All positive integrals are understood in the extended sense before finiteness is proved. There is no original-residual gate or principal-cut qualification needed for this all-input energy object, and no such qualification is inferred from it.

The parent owns scalar rearrangement and the retained conditional weak-bound return. We use neither a new scalar minimax claim nor independent exceptional sets at different scales. If a uniform common-cap estimate eventually has \(|\Omega|\le A_nW/\kappa\) and \(\mathcal E_\kappa\le B_n\kappa W\), the retained return costs \(4A_n+2\sqrt{2nA_nB_n}\). This is a dependency, not the new result.

## 2. The exact common-receiver overlap kernel

For \(d\in\mathbb R^n\setminus\{0\}\), put \(r=\|d\|_\infty\) and
\[
 K_n(d)=\int_r^\infty
 L^{-2n-1}\prod_{\ell=1}^n(L-|d_\ell|)\,dL.
 \tag{2}
\]
Set \(K_n(0)=+\infty\). It is a nonnegative measurable kernel.

**Theorem 1.** For any two finite positive measures \(\nu_i,\nu_j\),
\[
 \int_{\mathbb R^n}\int_0^\infty
 T_L\nu_i(x)T_L\nu_j(x)\,\frac{dL}{L}\,dx
 =\iint K_n(y-z)\,d\nu_i(y)d\nu_j(z).
 \tag{3}
\]
In particular,
\[
 0<K_n(d)\le\frac{r^{-n}}{n(n+1)}.
 \tag{4}
\]
More precisely, if at least \(k\) coordinates satisfy \(|d_\ell|=r\), then
\[
 K_n(d)\le r^{-n}\operatorname B(n,k+1)
 =r^{-n}\frac{(n-1)!\,k!}{(n+k)!}.
 \tag{5}
\]
Equality in (5) holds if exactly those coordinates have absolute displacement \(r\) and all remaining coordinates have displacement zero. No independence of source coordinates is assumed.

**Proof.** At fixed \(L,y,z\), the receivers simultaneously capturing both sources form
\(Q(y,L)\cap Q(z,L)\), of exact volume
\(\prod_\ell(L-|y_\ell-z_\ell|)_+\).
Tonelli, first in the receiver variable and then in \(L\), proves (3), including possible infinity. At least one coordinate attains the maximum \(r\). Keeping that factor and bounding all other factors by \(L\) gives
\[
 K_n(d)\le\int_r^\infty L^{-n-1}(1-r/L)\,dL
 =\frac{r^{-n}}{n(n+1)}.
\]
Keeping \(k\) such factors and substituting \(t=r/L\) gives
\(r^{-n}\int_0^1t^{n-1}(1-t)^kdt\), which equals (5) by repeated elementary integration by parts. The equality case follows directly from the product. \(\square\)

Thus the rough estimate \(r^{-n}/n\), obtained by forgetting all coordinate loss, discards a genuine factor \(n+1\). The factor is not a bound on the sum of interactions between arbitrary source clusters.

For exact finite calculation, write \(e_k(|d|)\) for the elementary symmetric polynomial, \(e_0=1\). Expansion of the finite product gives
\[
 K_n(d)=
 \sum_{k=0}^n\frac{(-1)^k e_k(|d|)}
 {(n+k)r^{n+k}}.
 \tag{6}
\]
This formula is exact for rational displacements; alternating terms should not be evaluated as an uncertified floating cancellation.

### 2.1 Exact radial shell mass and the limit of the pointwise discount

The angular geometry in (4) cannot by itself make an arbitrary source-pair interaction small. In fact, for every \(0<a<b\),
\[
 \boxed{\quad
 \int_{\{a<\|d\|_\infty<b\}}K_n(d)\,dd=\log(b/a).
 \quad}                                                     \tag{6a}
\]
This is dimension independent. To prove it, put
\(q(z)=\prod_{\ell=1}^n(1-|z_\ell|)_+\).
It is a probability density, since each one-dimensional tent has integral one. Formula (2) is equivalently
\(K_n(d)=\int_0^\infty L^{-n-1}q(d/L)\,dL\).
Tonelli and the change of variable \(d=Lz\) give the left side of (6a) as
\[
 \int_{\mathbb R^n}q(z)
 \int_{a/\|z\|_\infty}^{b/\|z\|_\infty}\frac{dL}{L}\,dz
 =\log(b/a).
\]
The singleton \(z=0\) is null for \(q(z)dz\), so its undefined endpoints cause no problem. There is no assumption on a physical source-pair law in this calculation. Thus (4) is a real pointwise geometric improvement, but summing it or (2) against an arbitrary source-pair measure still requires a proved distributional budget.

## 3. A pooled-cluster cap with explicit self and interaction prices

Assume a finite or countable positive decomposition
\[
 \nu=\sum_j\nu_j,\quad W_j=\nu_j(\mathbb R^n)>0,\quad
 \sum_jW_j=W<\infty,
 \qquad r_j=(W_j/\kappa)^{1/n},
\]
and that, for a fixed \(0\le\varepsilon<1\),
\[
 \operatorname{supp}\nu_j\subset Q(c_j,\varepsilon r_j).
 \tag{7}
\]
There is no assumption that the cap cubes are disjoint. Define the single common cap
\[
 \Omega=\bigcup_j Q(c_j,r_j),\qquad
 |\Omega|\le\sum_jr_j^n=W/\kappa.
 \tag{8}
\]
Let
\[
 \mathcal P(\{\nu_j\})=
 \sum_{i<j}\iint K_n(y-z)\,d\nu_i(y)d\nu_j(z),
 \tag{9}
\]
and put
\[
 b_n(\varepsilon)=
 (1-\varepsilon)^{-n}-(1-\varepsilon)^n+
 2n\log(1-\varepsilon).
 \tag{10}
\]

**Theorem 2.** For the actual cap (8),
\[
 \boxed{\quad
 \mathcal E_\kappa(\nu;\Omega)
 \le \frac{\kappa W}{n}b_n(\varepsilon)
       +2\mathcal P(\{\nu_j\}).
 \quad}                                                    \tag{11}
\]
In particular, if the source supports have distances
\(d_{ij}=\inf\{\|y-z\|_\infty:y\in\operatorname{supp}\nu_i,
z\in\operatorname{supp}\nu_j\}>0\), then
\[
 \mathcal E_\kappa(\nu;\Omega)
 \le\frac{\kappa W}{n}b_n(\varepsilon)
 +\frac{2}{n(n+1)}
 \sum_{i<j}\frac{W_iW_j}{d_{ij}^{\,n}}.
 \tag{12}
\]
An infinite right side is not a finite certificate. The exact kernel in (11) can be substantially smaller than the separation envelope in (12).

### 3.1 Proof of the individual cluster estimate

For \(x\notin Q(c_j,r_j)\), no source in (7) can be captured at a side length \(L<(1-\varepsilon)r_j\). Also \(T_L\nu_j\le W_jL^{-n}\), so its positive excess vanishes for \(L\ge r_j\).

For each fixed \(L\), use Jensen with the probability measure \(\nu_j/W_j\) and the convex function \(\phi(a)=(a-\kappa)_+^2\). The actual receiver integral satisfies
\[
 \int_{\mathbb R^n}(T_L\nu_j(x)-\kappa)_+^2dx
 \le L^n(W_jL^{-n}-\kappa)_+^2.
 \tag{13}
\]
Indeed \(\phi(W_jL^{-n}1_{Q(y,L)}(x))\) equals the constant
\((W_jL^{-n}-\kappa)_+^2\) on a receiver cube of volume \(L^n\), and is zero elsewhere. Thus, writing \(s=L/r_j\),
\[
 \begin{split}
 \mathcal E_\kappa(\nu_j;Q(c_j,r_j))
 &\le\kappa W_j\int_{1-\varepsilon}^1
 (s^{-n}-2+s^n)\,\frac{ds}{s}\\
 &=\frac{\kappa W_j}{n}b_n(\varepsilon).
 \end{split}                                               \tag{14}
\]
This proves \(b_n\ge0\) as well. The lower scale cutoff is a consequence of actual geometric separation from the cap, so no divergent small-scale integral has been silently dropped.

### 3.2 Proof of the assembly inequality

For nonnegative numbers \(a_1,\ldots,a_N\),
\[
 \left(\sum_ja_j-\kappa\right)_+^2
 \le\sum_j(a_j-\kappa)_+^2+2\sum_{i<j}a_ia_j.
 \tag{15}
\]
One proof is to set \(\psi(a)=a^2-(a-\kappa)_+^2\). Its derivative is
\(2\min(a,\kappa)\), which is nondecreasing. Therefore
\(\psi(a+b)-\psi(a)=\int_a^{a+b}\psi'(s)ds
\ge\int_0^b\psi'(s)ds=\psi(b)\).
Induction gives superadditivity of \(\psi\) and then (15).

Apply (15) with \(a_j=T_L\nu_j(x)\), integrate outside the same \(\Omega\), and use \(\Omega\supset Q(c_j,r_j)\) in each self term. For the cross terms, enlarging the receiver integral to all of \(\mathbb R^n\) is legitimate because they are positive; Theorem 1 gives exactly (9). This proves (11) for finite sums. For a countable decomposition, use the pointwise inequality for partial sums, followed by monotone convergence of the positive excess and Tonelli for the positive right sides. The cap stays the full set (8) throughout. Bound (4) gives (12). \(\square\)

The loss from enlarging the cross-term domain to all receivers is explicit. In particular the method can overcharge interactions lying inside the deleted cap. This is an upper-bound mechanism, not an equality for the optimum cap energy.

### 3.3 Quantified gain and stronger self estimates

If \(0\le\varepsilon\le1/(4n)\), Bernoulli's inequality gives
\((1-\varepsilon)^n\ge1-n\varepsilon\ge3/4\).
In (10) the other two terms after \((1-\varepsilon)^{-n}\) are nonpositive, so
\[
 0\le b_n(\varepsilon)\le4/3.
 \tag{16}
\]
Thus a single pooled packet has a common cap of volume \(W/\kappa\) and a genuine all-scale energy bound \(4\kappa W/(3n)\), for arbitrary positive mass within the packet. For many packets the sum of all self fees remains \(4\kappa W/(3n)\), with no packet-count factor. The cross coefficient in (12) is \(2/[n(n+1)]\), rather than \(2/n\).

The alternative role develops a sharper single-packet shell estimate in its own files. Any independently proved self estimate may replace (14) in the same assembly proof. Theorem 2 as written is self-contained and does not depend on that improvement or its numerical receipts.

For instance, if a given decomposition has
\[
 \frac1{\kappa W}\sum_{i<j}\frac{W_iW_j}{d_{ij}^{\,n}}
 \le R_n n(n+1)/2,
 \tag{17}
\]
then this particular input has \(A=1\) and \(B\le4/(3n)+R_n\).
No assertion that every input admits such a decomposition is made. A uniform theorem providing it would be new work, not a consequence of the pair kernel estimate.

## 4. Why arbitrary inputs cannot simply be assigned these packets

There is already a precise density restriction. If
\(\nu=f\,dx\) with \(0\le f\le C\kappa\), and a positive submeasure
\(\nu_j\le\nu\) satisfies (7), then
\[
 W_j\le C\kappa\,|Q(c_j,\varepsilon r_j)|
 =C\varepsilon^nW_j.
 \tag{18}
\]
Hence \(C\varepsilon^n\ge1\) is necessary. For \(C=1\) and
\(\varepsilon<1\), no nonzero packet of this form exists, although
\(T_L\nu\le\kappa\) at every scale and its excess energy is zero.
Consequently a universal concentrated-packet partition is a false intermediate assertion. This is not a counterexample to the general common-cap energy premise.

A bounded background can be treated only with its threshold cost. If
\[
 \nu=h\,dx+\sigma,\qquad 0\le h\le(1-\beta)\kappa,\quad 0<\beta<1,
\]
then pointwise
\[
 (T_L\nu-\kappa)_+\le(T_L\sigma-\beta\kappa)_+.
 \tag{19}
\]
Applying Theorem 2 to \(\sigma\) uses the threshold \(\beta\kappa\),
so its cap volume is at most \(\sigma(\mathbb R^n)/(\beta\kappa)\), its self fee is proportional to \(\beta\kappa\,\sigma(\mathbb R^n)\), and its geometric cluster radii must be recomputed at that threshold. One cannot subtract a background bounded by \(\kappa\) and reuse the same positive threshold for the remainder.

The unresolved general construction must therefore handle both a nonconcentrated component and the interaction of the concentrated components, using one cap and an admissible total volume. Source closure, a principal cut, or a root packing condition has not supplied either requirement. The exact kernel (2) shows which interaction this proof pays; it does not prove the sum is subpower.

## 5. Physical pressure, tests and completion status

The private section tests a sourcewise cap rule against a common cluster of distinct atoms. Its recipe and quantitative lower conclusion remain private. The rule under test is explicitly narrower than choosing an arbitrary measurable common cap. Pooled caps provide a positive repair of that localized failure; neither the failure nor the repair resolves arbitrary interacting inputs.

Three new author stages passed 531 exact rational assertions, 177 in each stage, with 96 formula models per stage. They tested exact overlap kernels versus the coordinate beta bounds, scale homogeneity, interval-enclosed logarithms in the self energy, the nonlinear assembly inequality, and a dimension-compressed actual receiver-shell certificate in the private pressure. The run took 2.059305833 seconds. The expanded dimensions reached 256. Large finite atom counts in the private family were treated by the proved geometric formula, not falsely claimed to have been individually enumerated. No old test count was reused.

A bounded additional check for (6a) passed nine new exact rational identities, at dimensions \(2,3,4,8,16,32,64,128,256\), in 0.001231791 seconds:
\[
 2n\sum_{k=0}^{n-1}(-1)^k\binom{n-1}{k}2^{n-1-k}
 \left(\frac1{n+k}-\frac1{n+k+1}\right)=1.
\]
This is the polynomial expansion of the cube-face angular coefficient
\(2n\int_0^1t^{n-1}(1-t)(2-t)^{n-1}dt\);
the full integrand, including the factor \(2n\), is the derivative of \([t(2-t)]^n\).
The author total is therefore 540, with the nine-check addendum distinguished from the three main stages.

All these checks are distinct from the numeric owner's full continuum-cell energy certificates. The latter was told the exact overlap observable before final integration; its already frozen scan was not modified or relabeled as a test of a uniform theorem. The author tests do not establish an all-input packet partition or cap bound.

The current F03 and G01 skill scopes were read. Actual cross terms and the product measure in (3) are retained; no orthogonality, a Carleson packing theorem, source-coordinate independence, or infinite-dimensional minimax is imported. The proofs use positivity, exact cube geometry and elementary integration.

Statements were sent to both independent auditors before their proofs. Astra and the replacement Sol auditor subsequently read the complete Markdown and matching TeX, including the private pressure and its repair, and both returned full mathematical and consistency PASS. The short shell-mass addendum was separately sent for blind and full review. Their independent arithmetic receipts remain separate from the author assertions. The remaining general task is a quantitative common-cap construction for arbitrary positive input, including diffuse/background mass and the full interaction budget. The general root-order weak bound remains **OPEN**.

## 1. New result and its remaining linear term

There is a fully paid alternative to the threshold-amplified high-count occupation in R92. Continue each surviving receiver with the smaller demand lambda_{i+1}, and pay the difference from actual source loss. Source exits have a common O(K) capacity. Across every stage, actual nested annuli admit one physical incidence per fixed receiver/source pair. A nonnegative geometric source–receiver potential pays these annuli and all threshold changes. Fresh child-classification exceptions must be charged at the parent threshold; an explicit choice of K absorbs their total fee. Both source and receiver terminal quantities tend to zero.

The resulting bound is in original source mass W_0, not D_0 units. It is O(H_n+A_n), where H_n=1+n log2 and A_n is the complete retained paid-classification coefficient. Thus this is a genuine fully paid high-count recursion reduction, but not an improvement on the general linear local bound or the O(n log n) all-scale baseline. The root-order goal remains open. The remaining problem is a better geometric common annular capacity, not an unpaid beta^(−i) occupation assumption.

The argument covers the high-R regime without referring to r≤sqrt(n). It uses no coordinate-count monotonicity, independence, packet entropy, or averaged directional weights. In particular, the R92 low-count branch may be empty throughout.

## 2. Actual states and the retained classification interface

Fix n≥2, alpha=epsilon0=[10log(n+2)]^(−1), c=1−alpha−epsilon0, u=1−epsilon0, beta=c/2. Let H_n=1+n log2. The initial source is mu_0=f_0 dy, W_0<infinity. At stage i, mu_i=mu_0|Z_i is the actual surviving positive L1 source, W_i=mu_i(R^n), lambda_i=beta^i lambda_0. The current measurable receiver set B_i is a subset of the freshly recomputed whole original Fnew for this source and threshold. It has actual earliest selector Q_i(x)=Q(x,L_i(x)), full side 1≤L_i≤2, and

    mu_i(Q_i(x))=lambda_i L_i(x)^n,
    D_i=lambda_i|B_i|.                                    (1)

The universal local hard-window envelope gives D_0≤H_n W_0, so initial receiver volume is finite; no root estimate is used here. Its captured-stop kernel k_i is the retained nonnegative kernel, with

    0≤k_i(x,y)≤L_i(x)^(−n)1_Qi(x)(y),
    c lambda_i<d_i(x):=∫k_i(x,y)dmu_i(y)≤u lambda_i,
    q_i(y)=∫_Bi k_i(x,y)dx.                                (2)

These bounds use the actual stopped captured evolution, not a substituted fixed-scale flow. Zero receiver or source branches stop without evaluating ratios.

We use the proved original classification with a single complete coefficient A_n: for every current positive source and threshold, receivers with a strict hard witness at a side in [1,2] can be separated into its original residual Fnew and paid pieces of threshold-times-volume at most A_n times source mass. All original gates are recomputed. The detailed retained coefficients appear below; any additional layer fee used must be included in A_n or separately retained.

Choose K>0 and let

    S_i={q_i>K},  mu_{i+1}=mu_i|S_i,
    e_i(x)=∫_(S_i^c) k_i(x,y)dmu_i(y),
    G_i={x∈B_i:e_i(x)≥d_i(x)/2}.                           (3)

G_i is the ordinary good row set. Every row in B_i\G_i has surviving stop mass greater than c lambda_i/2=beta lambda_i. Therefore its old cube is a strict hard witness for the CHILD source at threshold lambda_{i+1}=beta lambda_i. Apply the entire original child classification to these rows. Denote by E_i the rows paid by that classification and by B_{i+1} its final retained residual rows. Thus

    B_i=G_i disjoint-union E_i disjoint-union B_{i+1},
    lambda_{i+1}|E_i|≤A_n W_{i+1}.                         (4)

Only B_{i+1} is used for nested-annulus partial payment. Its child anchor and strict old witness imply its earliest child contact satisfies L_{i+1}<L_i, hence Q_{i+1}⊂Q_i. No new radius is assigned to E_i.

The actual source survival probability is rho_i=W_{i+1}/W_i. Although the full-demand compensated mass beta^(−i)W_i can increase, it is not the node mass of the following payment. We keep actual reach mass W_i/W_0 and pay demands at their actual lambda_i.

## 3. Exact partial-demand coupling

Put

    a=(1−beta)/(c−beta)=2/c−1,    b=2/c,    so 0<a<b.       (5)

A good row x∈G_i is paid its full lambda_i demand using density lambda_i k_i 1_(S_i^c)/e_i relative to mu_i. Since e_i≥d_i/2>c lambda_i/2, its multiplier is at most b.

For a final continuing row x∈B_{i+1}, use the source-loss kernel

    l_i(x,y)=k_i(x,y)[1_(S_i^c)(y)
                      +1_(S_i)(y)1_(Q_i\Q_{i+1})(y)].

Its row integral ell_i obeys

    ell_i=d_i−∫_(S_i∩Q_{i+1})k_i dmu_i
       ≥d_i−L_i^(−n)mu_{i+1}(Q_{i+1})
       >c lambda_i−beta lambda_i(L_{i+1}/L_i)^n
       ≥(c−beta)lambda_i.                                (6)

Scale l_i by (1−beta)lambda_i/ell_i. This pays exactly the demand increment (1−beta)lambda_i, with multiplier at most a. All edges lie in the original old cube Q_i. The child receiver retains demand lambda_{i+1}.

E_i is different: it has no retained child selector. It is paid its FULL parent demand lambda_i, at cost

    lambda_i|E_i|≤(A_n/beta)W_{i+1}.                       (7)

Omitting the factor 1/beta here would invalidate the recursion. These disjoint classes give the exact demand identity

    D_i−D_{i+1}=lambda_i|G_i|+lambda_i|E_i|
                     +(1−beta)lambda_i|B_{i+1}|.          (8)

For source exits, good-row and continuing-row kernels have disjoint receiver supports. Their combined column is at most b q_i≤bK on S_i^c. Consequently their stage fee is at most bK(W_i−W_{i+1}); over all stages each original source point exits at most once.

The remaining continuing-row annular fee is at most a times

    J_i=∫_(B_{i+1}) L_i(x)^(−n)
                    mu_{i+1}(Q_i(x)\Q_{i+1}(x))dx.        (9)

There is no beta^(−i) multiplier on J_i. This is a different partial-demand allocation, not a claim that the R92 full-demand occupation was bounded after all.

## 4. A genuine finite nonnegative source–receiver potential

Define the physical local envelope

    psi(z)=max(1,2||z||_infinity)^(−n)1_{||z||_infinity≤1},
    ∫_(R^n)psi(z)dz=1+n log2=H_n.                         (10)

The equality follows from the inner cube of side one and the shells with full side s∈[1,2]. For every old cube side L∈[1,2], psi(x−y)≥L^(−n) on Q(x,L).

Set

    Psi_i=∫dmu_i(y)∫_Bi psi(x−y)1_Qi(x)(y)dx,
    P_i=bK W_i+a Psi_i.                                   (11)

These are actual quantities on the common original source space. They satisfy 0≤Psi_i≤H_n W_i and 0≤P_i≤(bK+aH_n)W_i. Source sets, receiver sets, and each continuing receiver's cubes are nested, so Psi_i is nonincreasing. More precisely, retain only B_{i+1} and mu_{i+1} in the difference; then

    Psi_i−Psi_{i+1}
      ≥∫dmu_{i+1}(y)∫_(B_{i+1})
                   psi(x−y)1_(Q_i\Q_{i+1})(y)dx
      ≥J_i.                                               (12)

All other deleted-source/receiver contributions have the correct nonnegative sign. Hence (7)–(9) give the finite-step inequality

    D_i−D_{i+1}≤P_i−P_{i+1}+(A_n/beta)W_{i+1}.             (13)

There is also a direct cumulative interpretation. For fixed x,y, nested cubes allow at most one annular incidence before x exits. A resulting source-dependent choice of one L∈[1,2] is pointwise dominated by psi. Therefore Σ_i J_i≤H_nW_0, with actual Lebesgue receiver measure and no number-of-stages factor. Equation (12) strengthens this to an explicit decreasing reservoir and finite terminal.

## 5. Paid child exceptions and terminal: no occupation premise

The actual high-column source restriction and (2) imply

    K W_{i+1}≤∫q_i dmu_i≤uD_i,
    D_{i+1}≤beta D_i.                                    (14)

Strictness of {q_i>K} is not needed for this upper bound. Thus the classification error in (13) satisfies

    (A_n/beta)W_{i+1}
        ≤[A_n u/(beta K)]D_i
        ≤theta(D_i−D_{i+1}),
    theta=A_n u/[beta K(1−beta)].                         (15)

Choose

    K=2A_n u/[beta(1−beta)],   so theta=1/2.                (16)

This K is root-polylog if A_n is root-polylog. In particular no high-R/root-low-profile assumption is introduced. Rearranging (13) proves the actual finite potential descent

    (1−theta)(D_i−D_{i+1})≤P_i−P_{i+1},
    (1−theta)(D_0−D_m)≤P_0−P_m.                          (17)

The terminal signs are retained. Moreover D_m≤beta^mD_0, and for m≥1,

    W_m≤u beta^(m−1)D_0/K,
    P_m≤(bK+aH_n)u beta^(m−1)D_0/K.                       (18)

Both terminals tend to zero. If receivers empty earlier, their actual terminal demand is zero and the branch stops; no inference that its source mass must vanish is needed. Sending m to infinity in the active-chain case gives

    D_0≤2(bK+aH_n)W_0.                                   (19)

The original initial event before its paid residual has the additional A_nW_0 charge, so the full local event is bounded by

    [A_n+2bK+2aH_n]W_0.                                  (20)

If B_0 is empty, only its already-paid A_nW_0 bound is used. These are W_0-based bounds with complete threshold, child, exit and terminal payment. They do not improve the linear H_n term. No step assumes a uniform marginal modulus, a nested coordinate count, an entropy contraction, or an abstract Bellman theorem.

For comparison, summing (14) alone gives Σ_i W_{i+1}≤uD_0/[K(1−beta)]. That estimate is D_0-priced, but (15) absorbs its cost against the ACTUAL demand decrement. It is not silently substituted for a W_0 bound.

## 6. What a root-order improvement would still require

The remaining reservoir has an exact actual-prefix description:

    Psi_i=D_i+n∫_Bi∫_1^{L_i(x)} T_s mu_i(x) ds/s dx.         (21)

Indeed, on Q_i the radial layer-cake identity is psi=L_i^(−n)+n∫_1^{L_i}s^(−n)1_{Q(x,s)}ds/s; both sides are zero after inserting the corresponding cube indicators. Integrating and using actual contact proves (21). This is an identification of the unpaid geometric size, not an improved prefix estimate.

The high-r occupation Σ_i beta^(−i)r_i mu_{i+1} is not used in this scheme. Its replacement is a cumulative physical annular coupling, paid by (11)–(12). The sole linear source coefficient after absorbing original classifications is the initial geometric reservoir H_n. A smaller common source–receiver reservoir, or a sharper redistribution of the actual cumulative annular flow, could improve it. Such an improvement must preserve (12) or pay its defects and finite terminal; it cannot simply replace psi by a smaller kernel that no longer dominates the loss.

Internal physical pressure tests distinguish this geometric reservoir from the original gated recursion. A configuration without the original contact/gates cannot certify or refute the actual high-R residual capacity. The concrete inputs and quantitative pressure outcomes remain private. No root-sized initial reservoir on the actual residual has been proved here; the remaining missing ingredient is specifically the first-contact/captured-stop geometry, not an untracked recursive fee.

This is the qualified outcome: a new full recursive potential removes the amplified occupation and pays all non-band exits, but the general root-order constant remains unproved. The retained general baseline remains O(n log n).

## 7. Original fees, scales and validation scope

At every child input recompute anchor, all-L original P1 upper gate, strict later witness, earliest contact, original exp(−s_n)/2 middle lower, theta_noise=log^(−2)(n+2), dominant-packet and physical collision/entropy branches, and any original kappa layer used. Whole Fnew=Fdiff∩{C_h*<3/4,Hbar_h*>sqrt n}; B_i is a subset after previous receiver deletions. No variance-subset inheritance is asserted.

For the retained original choices h*=1/(16n^(3/2)), a0=n^(−p), rho0=n^(−1/2), take the complete local coefficient

    B_base=4+2(log2)sqrt(7n/3), B_ext=2H_n/sqrt(n+2),
    T_soft=1+(log2)min(2n,sqrt(n[theta_noise^(−1)+4theta_noise/3])),
    P_dom=[5+3log(1/a0)]/rho0,
    E_*=exp(nh*), B_*=1+E_*[1+(2n²+n)h*],
    P_phys=2[E_*+B_*+2(1+E_*)sqrt n],
    A_n=B_base+B_ext+T_soft/alpha+P_dom+P_phys.

The collision/entropy union is paid once. Any original-layer aggregation is retained rather than counted as free; all-scale return still has C_loc log(n+2), with separate J_n=O(log n) if the retained kappa-layer route is used. The local theorem uses a complete A_n for whatever classification is actually applied.

Pilot: derive the exact disjoint good/exception/final-child identity (8), with exceptions at the parent threshold; verify both transport multipliers and the actual nested-annulus reservoir. Known-obstruction stress: preserve rho/beta growth rather than pretending full-demand compensated masses decrease, check the wrong missing-1/beta classification price, and test exact physical reservoir integrals with their original-gate limitations. Expansion: (12)–(18) hold for arbitrary dimensions, correlated positive L1 sources, actual measurable earliest selectors, arbitrary finite horizons and all positive source survival ratios. Independent finite arithmetic checks can verify coefficients and geometric envelope integrals, but no artificial array is claimed to be a fully qualified high-r source chain. No old test counts are reused.

The arbitrary-input common-cap energy premise remains open. This note proves a quantitative all-scale payment for an arbitrary positive measure supported in one sufficiently concentrated cube. Fixed-grid thin padding is not a verified general construction; actual pressure is isolated in the private working section.

## 1. The common-cap quantity

For a finite positive Borel measure $\nu$ on $\mathbb R^n$, $n\ge2$, write $W=\nu(\mathbb R^n)$ and
\[
 T_L\nu(x)=L^{-n}\nu(Q(x,L)),\qquad
 E_\kappa(\nu;\Omega)=\int_{\Omega^c}\int_0^\infty
          (T_L\nu(x)-\kappa)_+^2\,\frac{dL}{L}\,dx.
 \tag{1}
\]
All cubes have their full side as parameter, and $dx$ is actual Lebesgue receiver measure. The set $\Omega$ is chosen once and does not depend on $L$. The trivial case $W=0$ is excluded below. No density assumption, independence assumption, scale truncation or original residual-event gate is imposed in the next theorem.

## 2. A paid concentration profile for one common cap

Fix $\kappa>0$, let $R=(W/\kappa)^{1/n}$, and suppose
\[
 \operatorname{supp}\nu\subseteq Q(c,a),\qquad
 \rho:=a/R<1/n.
\]
Choose the single measurable cap $\Omega=Q(c,R)$. Then $|\Omega|=W/\kappa$, and
\[
 \frac{E_\kappa(\nu;\Omega)}{\kappa W}
 \le F_n(\rho):=\int_{1-\rho}^{1}
       (s^{-n}-1)^2\bigl[(s+\rho)^n-1\bigr]\,\frac{ds}{s}
 \le\frac{n^3\rho^4}{(1-n\rho)^3(1-\rho)}.
 \tag{2}
\]
At $\rho=0$, both right sides are defined as zero. In particular,
\[
 a\le\frac{R}{16n}\quad\Longrightarrow\quad
 |\Omega|=\frac W\kappa,\qquad
 E_\kappa(\nu;\Omega)\le\frac{\kappa W}{50625\,n}.
 \tag{3}
\]
The measure inside the small supporting cube can have arbitrary atomic, singular or diffuse structure. This is a source-concentration hypothesis, not a decomposition available for arbitrary inputs.

Proof. The total mass bound gives $T_L\nu\le W/L^n$, so the positive excess vanishes for $L\ge R$. For $x\notin Q(c,R)$, a cube of side $L<R-a$ cannot meet $Q(c,a)$ except on irrelevant boundary sets, so its average is zero. At any intervening scale $R-a\le L<R$, all receivers that can see source lie in $Q(c,L+a)$. Thus their volume outside the common cap is at most $(L+a)^n-R^n$. Tonelli and the pointwise mass bound give
\[
 E_\kappa(\nu;\Omega)
 \le\int_{R-a}^{R}
       (W/L^n-\kappa)^2\bigl[(L+a)^n-R^n\bigr]\,\frac{dL}{L}.
 \tag{4}
\]
The change of variables $s=L/R$ proves the first inequality in (2). It accounts for every receiver and every scale; nothing outside this scale interval is discarded without a vanishing argument.

For $0\le\rho<1/n$, Bernoulli's inequality gives $(1-\rho)^n\ge1-n\rho$. The binomial expansion, with $\binom nk\le n^k$, gives $(1+\rho)^n\le(1-n\rho)^{-1}$. Consequently, throughout $1-\rho\le s\le1$,
\[
 s^{-n}-1\le\frac{n\rho}{1-n\rho},\qquad
 (s+\rho)^n-1\le\frac{n\rho}{1-n\rho},\qquad
 \int_{1-\rho}^1\frac{ds}{s}\le\frac{\rho}{1-\rho}.
\]
Multiplying proves the second inequality in (2). When $\rho\le1/(16n)$, its numerator is at most $1/(16^4n)$, and its denominator is at least $(15/16)^4$. This proves (3), since $15^4=50625$. If $a=0$, the source is concentrated at $c$ and the excess vanishes outside $Q(c,R)$ directly.

## 3. Verification, assembly boundary, and remaining problem

The source-centered profile and its explicit constant were sent in precise form to both independent auditors before proof work. Astra and the replacement Sol auditor independently read the complete Markdown and matching TeX and returned full mathematical PASS. The privacy boundary was also checked after the private material was moved outside both public marker pairs.

Three new exact stages passed. The pilot checks six concentration profiles in dimensions 2 and 3, including zero support radius. The stress stage checks twelve profiles in dimensions 2, 4 and 8, including $\rho=3/(4n)$ near the applicability boundary. The expanded stage checks thirty-two profiles through dimension 128, using up to 64 terms of a rigorously enclosed logarithm series, and thirty-six exact mass/threshold/length scaling cases. Across the three stages, twenty-six profile cases also verify the explicit $1/(50625n)$ conclusion.

For each scalar profile, the program expands the integrand in (2) as a finite Laurent polynomial and evaluates its antiderivative exactly, with rational lower and upper bounds for the sole logarithm. The logarithm uses the positive atanh series after exact power-of-two range reduction; its geometric remainder is explicitly included. These are certified scalar inequalities and geometric checks, not floating integration, an asymptotic fit, or a proof of the missing arbitrary-source assembly. Additional private construction checks and complete reproducibility code are retained outside the public marker. No old-round test count or original-gate qualification is reused.

The coverage role owns the separate finite-cluster assembly and its cross-source interaction term; this note supplies only the stronger single-cluster self-energy component (2)--(3). Componentwise common caps cannot be combined by silently adding their excess-energy bounds: the positive part is applied after summing source contributions, and the square retains interactions. No decomposition of every arbitrary source into packets satisfying (3) with a paid interaction cost has been established here. Nor is there a stability theorem allowing unassigned source mass to be ignored.

The remaining general task is to select one source-sensitive measurable cap with a subpower volume budget while paying all cross-source and cross-scale positive accumulation outside it. The public proof settles every scale for the explicitly stated concentration class; proposed stopping-cell extensions are separately audited in the private working section. It does not establish the arbitrary-input energy premise, an all-input root-order weak bound, or any new original residual-event qualification. The retained all-scale, threshold and layer requirements remain in force.

## S1. Primary reading and exact transfer scope

[Benedek–Calderón–Panzone, *Convolution operators on Banach space valued functions*, PNAS 48 (1962), 356–365](https://www.pnas.org/doi/pdf/10.1073/pnas.48.3.356), DOI 10.1073/pnas.48.3.356. Actually read Theorems 1–3 and their relevant proofs, printed pp.356–361, and Application (2), pp.363–364, in the original extracted PDF. No screenshot/full unrelated inverse-theorem/reference reading is claimed.

Theorem 1 starts with a linear Banach-valued operator having weak-(r,r), r>1, and an exterior L1 bound for every compactly supported mean-zero input, outside a fixed enlargement of its supporting Euclidean ball. Its proof gives weak-(1,1). Application (2) concerns dilation square functions of a decaying scalar kernel with zero integral and an L1 translation modulus; it uses Theorem 3's Hilbert-valued cancellation and translation hypotheses. Its constants do not provide a dimension-uniform cube excess-energy estimate. The source's geometric enlarged-ball constant must not be interpreted as dimension-free. Sections S2–S5 are our explicit cube calculations and proof, rather than a printed numeric theorem.

## S2. Exact rough cube vector kernel and the missing raw L2 premise

Write Q=[−1/2,1/2]^n, A_L f=f*(L^−n 1_{LQ}), H=L2((0,infinity),dL/L), and K(z)(L)=L^−n 1_{L>=2||z||infinity}. Boundaries in z have no effect on the Lebesgue integrals. If a=2||z||infinity>0, b=2||z−h||infinity>0, then

    ||K(z)||_H² = a^(−2n)/(2n),
    ||K(z−h)−K(z)||_H² = |a^(−2n)−b^(−2n)|/(2n).                 (1)

The amplitude at a common L is the same; only the interval between the two arrival sides contributes. Thus (1) is exact, not a smooth-kernel surrogate. For d=||h||infinity>0, R>1,

    ∫_{||z||infinity>Rd} ||K(z−h)−K(z)||_H dz
       <= C_n(R) := 2n exp(n/(R−1))/sqrt(R−1).                    (2)

Proof. Put r=||z||infinity. The minimum arrival side is at least 2(r−d), and the side difference is at most 2d. Integrating L^−2n−1 on the arrival interval gives

    ||difference||_H <= [2(r−d)]^−n sqrt(d/(r−d)).

The infinity-norm shell measure is n2^n r^(n−1)dr. Therefore the integral is bounded by

    n sqrt(d) ∫_{Rd}^infinity (r/(r−d))^n dr/[r sqrt(r−d)].

Use log(r/(r−d))<=d/(r−d)<=1/(R−1), and r−d>=(1−1/R)r. The latter comparison costs sqrt(R/(R−1)); the remaining integral of r^−3/2 is 2/sqrt(Rd). Multiplying these factors gives (2). If h=0 the integral is zero. This upper bound is not asserted optimal. At R=2n the translation fee is O(sqrt n), while enlarging each source cube by R costs R^n in receiver volume. At R=1+1/n this particular upper bound is enormous; no lower bound follows from the upper certificate.

For every nonzero scalar f in L2, Lebesgue differentiation gives A_L f(x)→f(x) at almost every Lebesgue point. On the positive-measure set where f(x) is nonzero, ∫_0^1 |A_L f(x)|²dL/L=infinity. Hence the raw operator f→{A_L f}_L is not an L2-to-L2(H) operator, and its H-norm is infinite on a positive-measure set even for bounded compact inputs. BCP's weak-r premise fails as well. Pointwise finite off-origin K(z) and a finite translation integral (2) do not fix this failure. For a finite window [L0,L1], Young's inequality only gives log(L1/L0)||f||2²; this is not uniform as L0→0.

## S3. A genuinely cancelled full-scale L2 tool with logarithmic dimension cost

Define Sf(x)(L)=A_L f(x)−A_{2L}f(x). For every n>=1 and f in L2(R^n),

    ∫_Rn ∫_0^infinity |Sf(x)(L)|² dL/L dx
      <= M_n² ||f||2²,
    M_n² = 25π^4/144 + 2 log n + 9/(8π²) < 18+2 log n.           (3)

Use the 2π Fourier convention. The cube multiplier is m(Lξ)=∏_j sinc(πLξ_j), sinc(v)=sin(v)/v with its value 1 at zero. For ξ nonzero, put u=L||ξ||infinity. The factors have absolute value at most 1, and

    |m(Lξ)−m(2Lξ)|
      <= min((5π²/6)n u², 2, 3/(2πu)).                          (4)

Indeed |1−sinc(v)|<=v²/6 by averaging 1−cos on [0,1]. Telescoping the product gives |1−m(Lξ)|<=π²L²||ξ||2²/6, and the two scales give the first bound. For the last, choose a coordinate attaining ||ξ||infinity and use |sinc(v)|<=1/|v| at the two scales. At ξ=0 the difference vanishes. Integrating the squared first bound on (0,n^−1/2), the constant 2 on [n^−1/2,1], and the last bound on (1,infinity) yields respectively 25π^4/144, 2 log n and 9/(8π²). Tonelli and Plancherel prove (3), first for a dense class and then for L2. For example π<22/7 and π>3 make the first-plus-last terms strictly below 18.

This cancels the small-scale constant component. It is a full-scale, actual cube, Lebesgue-receiver theorem with an explicit logarithmic dimension cost. No independence, heat kernel or posterior law was used.

## S4. Explicit cancelled square-function endpoint, including the common enlargement fee

Let n>=1, R>1, s>0 and f be a scalar bounded compactly supported input, with W=||f||1. Put c3=2C_n(R)=4n exp(n/(R−1))/sqrt(R−1). Then

    |{x: ||Sf(x)||_H>s}|
      <= [2^(n+2)M_n² + R^n + 4c3] W/s.                        (5)

Here a single common exceptional set is available for the CANCELLED square function, with volume at most R^n W/s. All constants in (5) are ours.

Proof. Select maximal dyadic cubes Q_j with average |f| exceeding s. Large dyadic averages tend to zero since W is finite, so every bad cube has a nonbad ancestor and a maximal member. The maximal cubes are disjoint, ∑|Q_j|<=W/s, their averages are at most 2^n s, and dyadic differentiation gives |f|<=s almost everywhere off their union. Set g=f there and g=average f on each Q_j. Then ||g||infinity<=2^n s, ||g||1<=W. Write b=f−g=∑b_j, where b_j is supported on Q_j, has integral zero, and ∑||b_j||1<=2W. These functions and their partial sums belong to L2; the sums converge in L2.

Let c_j be the centre, ell_j the full side, and Ω_R=∪R Q_j. Its volume is at most R^n W/s. Define K_S(z)(L)=K(z)(L)−K(z)(2L). Dilation L→2L is an isometry on H, so the H translation norm for K_S is at most twice that for K. For x outside RQ_j and y in Q_j, ||x−c_j||infinity>R ell_j/2>=R||y−c_j||infinity. Mean zero, Bochner's triangle inequality, and (2) consequently give

    ∫_(RQ_j)^c ||Sb_j(x)||_H dx <= c3 ||b_j||1.

The convolution identity here is well-defined away from Q_j: source-to-receiver separation is positive and K_S has finite H norm there. It agrees with the L2 operator in (3). Fatou along L2-convergent partial sums gives ∫_Ω_R^c ||Sb||_H<=2c3 W. Thus the bad half-threshold set costs R^n W/s+4c3 W/s. The good half-threshold set costs 4s^−2||Sg||2,H²<=2^(n+2)M_n² W/s. The triangle inequality proves (5). Density then extends this weak square-function statement to scalar L1 inputs; it does not extend a nonexistent raw-energy theorem.

For comparison, the Euclidean-ball proof requires a ball containing each side-ell cube, whose radius is sqrt(n)ell/2. A radius-c2 enlargement costs omega_n(c2 sqrt(n)/2)^n times cube volume. Neither this fee nor the dyadic good-function factor 2^n can be silently discarded. Formula (5) is not an improvement over the retained cube maximal baseline: it concerns a different, cancelled square function and its displayed endpoint constant is large.

## S5. Exact all-scale positive-excess boundary and three-stage checks

Take the physical bounded positive input f=a 1_[−1,1]^n with a>kappa>0. At every x in (−1/2,1/2)^n and every sufficiently small L, A_L f(x)=A_{2L}f(x)=a. The cancelled integrand in (3) is zero there, while

    ∫_0^1 (A_L f(x)−kappa)_+² dL/L = infinity.                  (6)

This proves that no unconditional pointwise conversion of the cancelled square energy to positive-excess energy is available. It does not disprove the contract's common-cap premise: an admissible cap may delete these receivers. Any claimed conversion must pay the constant component, one scale-independent Ω, and all remaining scale terms. Mean-zero source pieces still have nonzero values at their interior Lebesgue points, so their RAW full-scale H norm can diverge; support mean zero alone is insufficient.

Pilot: exact arrival integration (1), followed by the scalar Fourier split (3). Obstruction stress: the actual positive plateau (6), and the missing raw weak-r condition; these are real diffuse inputs, rather than abstract posterior countermodels. Expanded check: (2)–(5) are proved for every n and R>1, all scales and Lebesgue receivers; a finite rational guard below checks arrival and cancelled-arrival algebra at several dimensions but is not the continuum proof. The alternative author's independently owned tiny-padding dyadic-cap pressure is consistent with the explicit R^n/translation tradeoff here; this source file does not repeat its construction or treat it as a lower bound for optimized caps.

The exact retained gap is a source-dependent cancelled operator/residual whose exterior square energy agrees with, or dominates, the actual positive excess and whose ONE common Ω has subpower volume cost. The present source theorem and (3) supply neither this agreement nor subpower endpoint geometry. The coverage author's common-cap cluster cross terms require actual packing before a square-function theorem can pay them. The adaptive author's arrival mass W_i/W0 differs from its compensated t_i W_i; neither (3) nor BCP supplies a W0-paid high-count source potential. No all-scale energy, original gate, or root-order capacity conclusion is inferred.

## S6. Qualified finite Haar-tilt interface for the numeric author

This elementary interface is separate from source posterior/occupation laws. Let B>=1 bins have true Haar probabilities 1/B, let finite integer scores sigma_j be certified LOWER scores throughout each bin, and let z>1 be rational. Set Z=∑_j z^sigma_j and Q(j)=z^sigma_j/Z; all probabilities are positive. For n independent Q labels (and genuine uniform phases conditional on each label), S=∑sigma_j has mean mu and variance V. The exact joint likelihood ratio is

    dP^n/dQ^n = (Z/B)^n z^−S.                                 (7)

For an integer band [Slo,Shi] containing every integer with |S−mu|<d, d>0, Chebyshev gives

    P^n(S in band) >= (Z/B)^n z^−Shi max(0,1−V/d²).             (8)

If d²>=4V the last factor is at least 3/4. With V=0 use the constant-score event, or choose d>0; do not write 0/0. Exact floor/ceiling rules must include the strict central event. The bound follows by the likelihood identity and z>1, not asymptotic saddlepoint theory. A physical hard-event implication requires the certified binwise lower scores and a whole-band threshold implication at the SAME frozen source and threshold. This supplies no whole-scale P1/coarse gate or new residual membership. No CLT, source-posterior sampling, environment averaging or finite-rate Cramer theorem is asserted.

## S7. Reproducibility and conclusion

Author inline Python `Fraction` guard: EXACT PASS 492 assertions. Literal arrival parameters were n in (1,2,3,4,8,16,32), a,b in (1/3,1,2,5/2). Each ordered pair checks (1), the cancelled norm (1−2^−n)a^−2n/n, and cancelled translation squared <=4 times raw translation squared: 112 checks each. Integration partitions at sorted {a,b} or {a/2,a,b/2,b}; on [p,q), a constant coefficient c contributes c²(p^−2n−q^−2n)/(2n), with infinity endpoint contributing zero. These are finite exact kernel-algebra checks, not an independently sampled receiver-domain certificate.

One rational Fourier-constant check used 25(22/7)^4/144+9/72<18. The exact finite-law checks used scores (−2,0,3), z=3/2, n in (1,2,3,4), and d in (1,2,3,4). Enumerate all 3^n label tuples: 120 exact joint RN checks, four direct-versus-independent mean/variance checks, 16 central-event Chebyshev checks, and 15 nonempty-band lower checks; one central band is empty and is not counted as an RN band check. The finite laws are neutral algebra, not the private physical phase input. No FLOAT assertion, asymptotic fit, probability simulation or original gate certification enters this receipt. The literal parameters and exact interval primitive make the checks independently reconstructible; no extra owned test file was introduced.

Source metadata/primary reading is separate from reviewer verification of our derivations. This round adds the logarithmic-dimension cancelled L2 theorem (3), the explicit cancelled endpoint (5), and the raw-kernel translation/cap tradeoff (1)–(2). It identifies exact prerequisites that fail for the desired common-cap excess-energy transfer. The arbitrary-L1 root-order target remains open.

The following results concern a general nonnegative measurable energy field on actual Lebesgue receiver space. They give exact optimization identities and expose incorrect directions of scale-wise payment. They do NOT bound the actual cube energy uniformly in dimension. All constants A_n,B_n in the R92 energy criterion remain unknown unless explicitly paid by another theorem.

## 1. Exact common-cap formula, including infinite energy

For measurable e:R^n->[0,infinity], finite a>0, define

Phi_a(e)=inf_{measurable Omega, |Omega|<=a} integral_{Omega^c} e dx.

Set d(t)=|{e>t}|. With extended nonnegative integrals,

Phi_a(e)=integral_0^infinity (d(t)-a)_+ dt
        =sup_{0<=tau<infinity} [integral min(e,tau) dx-a tau].             (V1)

At tau=0 the integrand min(e,0) is identically zero even where e=infinity. At finite positive tau, a tau is finite, so no infinity-minus-infinity convention is used. Define Phi_0(e)=integral e separately.

For any admissible Omega, the layer-cake formula and |{e>t} outside Omega|>=(d(t)-a)_+ give the first expression as a lower bound. Let I be that expression. If I=infinity, every retained integral is infinite and the infimum has that value. Suppose I<infinity. Then d(t)<infinity for EVERY t>0: otherwise d(s)=infinity throughout a nonempty interval 0<s<t and I would be infinite.

Put tau_* = inf{t>=0:d(t)<=a}, allowing infinity. If 0<tau_*<infinity, right continuity of d and finite-measure continuity from the left give |{e>tau_*}|<=a<=|{e>=tau_*}|. Include all of {e>tau_*} and a measurable portion of {e=tau_*} to make a set of volume a. Such a portion exists because Lebesgue measure is nonatomic. The retained level measure is exactly (d(t)-a)_+ except possibly at the single threshold, proving equality. If tau_*=0, the positive support has volume at most a; delete that support. If tau_*=infinity, d(t)>a at every finite t. Since d(t0)<infinity for any t0>0, continuity from above implies |{e=infinity}|=lim d(t)>=a. Finiteness of I forces this limit to equal a. Delete precisely that infinite-energy set; the outside level measures are d(t)-a, proving equality. Thus whenever the retained cost is finite, a minimizing common set exists. When every cost is infinite, attainment only has its trivial extended-value meaning.

For the scalar expression, Tonelli gives integral min(e,tau)=integral_0^tau d(t)dt. Since d(t)-a is decreasing, the supremum of its integrals from 0 to tau is exactly its positive-part integral. If an initial positive superlevel has infinite measure, both sides are infinite at a finite tau. Otherwise this is the elementary increasing-then-decreasing integral rule, with the tau_*=0 and infinity limits retained. This proves (V1) directly; no infinite-dimensional minimax or conic strong-duality theorem has been invoked.

Finite scalar attainment and cap attainment differ. For example, place e=infinity on a set of volume a, and on disjoint sets outside it put e=2^j with volume 2^(-2j), j>=1. The outside energy is one and the infinite-energy set is an optimal cap. At tau=2^J the scalar value is exactly 1-(2/3)2^(-J), and every finite tau leaves some tail unclipped. The scalar supremum is one but is not attained at finite tau. The infinite-energy set alone would not imply nonattainment; the unbounded integrable outside tail is essential in this example.

## 2. Convexity and exact scale-allocation directions

For fixed e, Phi_a is decreasing and convex in a because (V1) is a supremum of affine functions of a. For fixed a, it is positively homogeneous and concave in e: it is an infimum of positive linear retained-energy functionals. These statements include the usual extended nonnegative conventions and do not assert convexity in an underlying source measure whose energy depends nonlinearly on that source.

For a finite or countable collection e_j>=0 on the SAME receiver space and e=sum_j e_j, valid bounds are

sum_j Phi_a(e_j) <= Phi_a(e)
                 <= inf_{a_j>=0, sum_j a_j<=a} sum_j Phi_{a_j}(e_j).   (V2)

The left inequality follows by evaluating all components on any single admissible cap and then taking its infimum. Its direction is a LOWER bound, not a way to pay the common-cap cost. For the right inequality take nearly optimal component caps, use their union, and charge its volume by sum a_j. If the right side is finite, choose summable approximation errors before taking the union and then let the total error tend to zero. If it is infinite the upper bound is vacuous. No scale is granted a fresh free volume budget a.

There is an exact interpretation of this upper bound. On the labelled space R^n times the countable component labels, with measure dx times counting measure, set e_tag(x,j)=e_j(x). Every measurable deletion set there corresponds exactly to component deletions whose volumes sum to at most a. Therefore

G_a := inf_{sum a_j<=a} sum_j Phi_{a_j}(e_j)
     = Phi_a(e_tag)
     = sup_{finite tau>=0} [sum_j integral min(e_j,tau)dx-a tau].       (V3)

This is an exact common-threshold optimization for an actually DIFFERENT measure space. In the true receiver space, the formula is instead

Phi_a(sum_j e_j)=sup_tau [integral min(sum_j e_j,tau)dx-a tau].

The pointwise inequality min(sum e_j,tau)<=sum min(e_j,tau) gives the same upper bound G_a. Its possible loss is real. For m identical components H times 1_U with |U|=a, the true common-cap cost is zero, whereas G_a=(m-1)Ha. For m disjoint supports each of volume a and the same height H, both costs are (m-1)Ha, while every separately budgeted Phi_a(e_j) is zero. These are generic receiver-energy examples, not counterexamples produced by actual cube orbits. They identify wrong payment directions and label costs only.

## 3. Application and exact normalization of the open cube target

For a finite positive measure nu of mass W>0 and kappa>0, take

e_kappa(x)=integral_0^infinity (T_L nu(x)-kappa)_+^2 dL/L.

This is a nonnegative measurable function, so the preceding identities apply to its actual Lebesgue receiver distribution. They do not establish that its trimmed value is finite, small, or attained with a subpower uniform bound. The desired NEW geometric estimate can be stated exactly as

Phi_{A_n W/kappa}(e_kappa)<=B_n kappa W.                            (V4)

By (V1), it is equivalent to bounding EVERY finite scalar threshold expression by B_n kappa W. It does not suffice to check one chosen tau, one receiver grid, separate scale caps, or a finite family of inputs.

The normalization W=kappa=1 loses no parameter. Let r=(W/kappa)^(1/n), and let nu_bar be nu/W pushed forward by y->y/r. Then T_{rL}nu(rx)=kappa T_L nu_bar(x). Logarithmic scale measure is invariant, e_kappa(rx)=kappa^2 e_1(nu_bar)(x), and actual dx scales by r^n=W/kappa. Consequently

Phi_{A W/kappa}(e_kappa)=kappa W Phi_A(e_1(nu_bar)).                (V5)

No input class or receiver measure has changed. Formula (V4), if proved uniformly, feeds the R92 weak reconstruction with every original threshold and dimension fee retained. A choice of source-dependent caps after seeing each separate scale does not satisfy it.

## 4. Actually executed three-stage exact checks

The public stdlib program parent_variational_probe.py tests NEW finite simple energy fields using exact rational volumes and values. It independently computes fractional removal, finite-threshold dual evaluation, and layer integrals. Pilot uses12 configurations up to4 cells; known-obstruction stress uses32 configurations up to12 cells including zero volumes and infinite energies; expanded uses96 configurations up to64 cells. Budget convexity, energy concavity, common-cap versus labelled-space direction and allocated-volume upper bounds are checked without rounding.

The run PASSed1136 assertions:96 pilot,256 stress,768 expanded,10 label/common-cap obstruction assertions and6 exact infinite-tail evaluations. Producer runtime was0.694267417 seconds. These are generic algebraic/simple-field checks, NOT physical cube examples or an inference about n. There are no FLOAT tests or probability samples in this program. All finitely represented field volumes are retained, and the one infinite-tail model is summed by its exact geometric series rather than truncated without charge.

The updated B03 and B04 skill entries, methods and cube interfaces were read. Their restrictions on nonlinear objectives, moment assumptions and infinite-dimensional minimax informed this direct proof. No advanced theorem from their primary papers is claimed or needed here, and reading an entry is not whole-skill acceptance. The remaining work is the actual geometric bound (V4), plus all retained original branch and all-scale fees. Exact duality by itself does not close the root-order weak estimate.

本轮对七个新的有限正原子测度输入完成八次连续空间划分，得到32项真实容量预算证书；另有五个维数的分离原子闭式校准，共20项预算检查。输入含不等质量、相邻簇、微小卫星和分离晕层，高维轴向测试达到32维，闭式校准达到4096维。它们没有重复R92的八个输入测试，也没有使用接收点抽样、浮点积分或渐近增长率拟合。

这些证书针对一般正超额能量接口，不声称原Fnew门槛成立。固定总质量W=1、阈值kappa=1，定义：

    T_L nu(x) = nu(Q(x,L))/L^n,
    e(x) = integral_0^infinity (T_L nu(x)−1)_+^2 dL/L,
    E*(A) = inf_{measurable Omega, |Omega|<=A} integral_{Omega^c} e(x) dx.

每个下界适用于所有可测Omega，每个有限上界由一个实际可测、独立于L的Omega实现。没有在每个尺度重新选择帽。所有体积采用原Lebesgue测度。W=kappa=1使L>=1上的能量恰为零；任何正超额立方体必须含有原子。程序覆盖全部可能产生能量的接收域，域外及尺度补集恰为零，未截去未知尾项。

## 真实连续空间压缩

各原子位于第一坐标轴。接收域划分为第一坐标区间[a,a+h]与横向立方环：

    t0 <= max_{j>=2}|x_j| <= t1.

其真实n维体积为：

    v = h * [(2*t1)^(n−1) − (2*t0)^(n−1)].

这包含全部2^(n−1)个横向象限，幂中的n−1没有消失。一维情况单独用体积h，不代入零次幂差。不同格的边界零测，全部格体积和与完整接收包围域体积精确相等。高维程序枚举这种连续格，并未枚举2^n个点或把二维面积当成高维体积。

对于原子(z,0,...,0)，格内最小、最大到达边长分别为：

    r_near = 2*max(distance(z,[a,a+h]), t0),
    r_far  = 2*max(|a−z|, |a+h−z|, t1).

每个接收点的真实到达边长位于二者之间。因此对任意L，far到达给捕获质量下界，near到达给上界。能量的平方正部随捕获质量单调，故这些不是中点诊断，而是整格、全尺度积分包络。

## 全尺度积分与一个实际帽

按到达边长合并原子。在累计捕获质量为m的尺度段，令u=L^n。将正超额区间限制为u<=m后，积分原函数为：

    (m^2/(2n))*(u0^(-2)−u1^(-2))
       − (2m/n)*(u0^(-1)−u1^(-1)) + log(u1/u0)/n.

有理项精确计算；对数采用40项有理atanh级数及严格余项，再向外舍入为44-bit dyadic端点。显示小数不是自身向外的十进制证书，精确分数保存在JSON。没有调用通用浮点区间API。

下包络是格上常数。允许按真实格体积做分数背包，优先删除最高下包络格，便得E*(A)的下界；这给任意可测帽足够的自由度，包含部分格删除。上界则按上包络密度选择一次帽，保存全部删除格及至多一个部分格。部分横向环格通过第一坐标区间的左侧切片实现精确删除体积，所有尺度共用同一个集合。

若格的near到达为零，其上包络无穷。任何有限上界必须将所有这种格完整删除；部分删除不能使该上包络有限。预算不足时程序报告UPPER_UNKNOWN_SINGULAR_CELL，而不报告实际最优能量无穷。

## 三阶段结果

八次空间证书覆盖7520个新的连续压缩格；四项预算为A=1/16、1/4、1/2、1。32项中31项具有有限帽上界，一项保留上述网格UNKNOWN。阶段计数如下：

| 阶段 | 新空间划分 | 连续格 | 目的 |
|---|---:|---:|---|
| 初探 | 2 | 416 | 多尺度不等质量、近簇及晕层 |
| 压力 | 2 | 1216 | 微小卫星与小容量预算；四维积累 |
| 扩展 | 4 | 5888 | 8、16、32维及同一困难输入的分辨率加密 |

以下为A=1/16时严格有理界的近似显示；上下端分别是任意帽最优值下界和所选实际帽上界。

| 输入与划分 | n | 网格mesh | 下界约 | 上界约 |
|---|---:|---:|---:|---:|
| nested_unequal | 1 | 128 | 2.72451 | 14.16594 |
| cluster_and_halo | 2 | 16 | 0.77151 | 16.97686 |
| tiny_satellite_and_far_halo | 1 | 128 | 2.30488 | UNKNOWN |
| nested_unequal | 4 | 32 | 0.55671 | 1.97071 |
| cluster_and_halo | 8 | 32 | 0.21713 | 1.19999 |
| nested_unequal | 16 | 32 | 0.07080 | 1.32652 |
| nested_unequal | 32 | 64 | 0.03598 | 0.54408 |
| tiny_satellite_and_far_halo_refined | 1 | 256 | 3.18956 | 6.33661 |

困难一维输入在粗网格上的无穷上包络格总体积是9/128，超过预算1/16，所以该上界未认证。同一个输入在mesh256下，这个体积降为5/128，给出有限上界。此前的UNKNOWN不是来源能量定理的反例。加密后的上下界仍有间隙，不能把所选帽当成真正最优帽。

八次空间划分的七个输入可完全重建：所有未列坐标为零。

| 名称 | 第一坐标与质量 |
|---|---|
| nested_unequal | (0,1/2), (1/16,1/4), (1/4,1/8), (3/4,1/8) |
| cluster_and_halo | (−1/4,1/8), (−1/64,3/8), (1/64,3/8), (1/4,1/8) |
| tiny_satellite_and_far_halo | (0,15/32), (1/128,1/32), (1/8,1/4), (3/4,1/8), (3/2,1/8) |

每个表中质量之和为1；不同维数是不同有限测度输入。加密记录与压力记录是同一来源，不重复计作新输入。完整预算曲线、帽实际体积、删除格IDs、部分格比例及空间包络摘要在JSON。

## 高维闭式校准

另取八个原子，第一坐标为0,2,...,14，质量依次为1/2、1/4、1/8、1/16、1/32、1/64、1/128、1/128。原子间第一坐标距离至少2，L<1的立方体不能同时捕获两个原子。每个原子的正能量支持立方体边长为m_i^(1/n)，这些支持互不相交。

对质量m的单个原子，令v=(2*maxdistance)^n/m。正能量密度是：

    e(v) = [1/(2v^2)−2/v+3/2−log(v)]/n,  0<v<1.

真实径向体积元为m dv；该密度随v递减。所有分量具有同一能量高度分布，按共同高度删除的最优帽在第i个分量上占体积A*m_i。因此0<A<=1时：

    E*(A) = [2+1/(2A)+(2+A)*log(A)−(5/2)*A]/n.

所选帽就是各原子周围边长(A*m_i)^(1/n)的立方体并，其总体积精确为A，独立于L；A>=1时最优剩余能量为零。对于任何其他帽，按递减能量高度的交换排序不能降低这一剩余积分，故闭式同时是最优下界和所选帽上界。

程序在n=4、16、64、256、4096及四项预算上做20次新的闭式有理对数检查。非有理根只定义真实连续立方体，体积由其幂关系精确给出；没有数值根替代、接收点枚举或高维MC。这是分离族的校准，不是一般输入的维数改善证明。

## 冻结与复现

程序仅依赖Python标准库，无旧轮运行时依赖。完整默认运行：

    python3 /Users/zhengzhihao/Desktop/T/output/centered_cube_round093_20261012/energy_probe.py

它重写同目录energy_results.json；也可用--output写到临时路径做隔离逐字比较。运行时间只打印在终端，不写进JSON，避免时间字段妨碍重放。最后生产运行耗时0.711064375秒，exit0。输出126455字节。帽ID列表用base85(zlib(UTF8 compact JSON))保存，解码后可检查唯一IDs、全部格体积及部分格切片，没有以散列代替可审见证。

冻结energy_probe.py SHA256：
d3216beac5126d2df74b365129f184958accbfcf1ee429d2ed646b40ab16bdce。

冻结energy_results.json SHA256：
068f260b721363ef0635fac5f04416619bc7cb6e0f030f2c7c47c91a0c909b15。

Astra已独立非写入完整重放，0.942776500秒全部JSON精确匹配，并解码32个帽见证，检查真实删除体积、部分切片和预算；对全代码的到达、积分、全空间/尺度补集及上下界方向审读通过。最终其他审计回执由审计文件记录。

这些有限证书既没有证明任意输入都有子幂体积帽，也没有证明相应剩余能量B_n子幂。高维网格的包络间隙明显，不能拟合指数。原子弱极限用于弱型转移与帽能量转移是不同问题，本轮不宣称一般弥散输入的能量极限。一般根号维数目标仍未闭合。

The numerical probe now uses the true receiver Haar law over a full period and pays the complete finite-dimensional likelihood. It certifies a positive-volume class of fixed-scale hard witnesses with full coordinate projections. Original smooth and coarse qualification remain unresolved, so no residual-volume, high-load or general weak-bound conclusion follows.

## Independent Astra audit — R93

The general arbitrary-input root-order weak bound remains OPEN. Precise candidate statements were checked independently before new author proofs; full MD and matching TeX proofs were then reviewed. No private lower construction is included in this summary.

- PASS: exact nonatomic common-cap trimming, including infinite energies, minimizing sets versus finite scalar-threshold attainment, correct common/labelled scale-allocation directions, and exact mass/threshold normalization. This reformulates the geometric target; it does not bound it.
- PASS: the actual common-receiver overlap kernel, its 1/[n(n+1)] pointwise discount and beta refinement, and the exact shell mass log(b/a). Pooled-cluster cap energy retains every source interaction and all scales. Suitable arbitrary-input decomposition, bounded-background threshold allocation and interaction payment remain open.
- PASS: one sufficiently concentrated positive source measure admits a source-centered cap of volume W/kappa and the stated all-scale energy profile, including energy at most kappa W/(50625 n) under the specified concentration hypothesis. This is a restricted class theorem, not the general cap construction.
- PASS: the new partial-demand recursion has an actual nonnegative W0-priced source/receiver potential. Parent-threshold child exceptions, source exits, shrinking-cube annuli, initial paid branches and terminal terms are all accounted for. The resulting local cost is O(H_n+A_n), with H_n=1+n log2; the linear reservoir remains and the general root target is not closed.
- PASS: the cancelled cube square function has the stated logarithmic L2 cost. Its separate weak endpoint retains its large geometric fees. Raw-orbit and cancelled-to-positive-excess interfaces are distinguished; the common excess-energy cap estimate is still missing.

The new neutral energy program was independently replayed with exact full JSON equality. Its 7520 continuum cells yield 32 budget certificates: 31 finite selected-cap upper bounds and one grid-envelope UNKNOWN, alongside 20 separated-family closed-form checks. All 32 cap witnesses were decoded and their true deletion volumes and partial slices checked. These finite results distinguish optimum-over-all-caps lower bounds from one selected common-cap upper; they are not an all-input theorem or an asymptotic fit.

The separate full-period Haar probe was independently replayed with exact mathematical JSON equality. It pays the full likelihood and certifies a positive-volume hard-witness class with contact existence and full coordinate projections. Original smooth-upper and coarse gates remain UNKNOWN. No residual-volume, high-load or general weak-bound conclusion is drawn. Rounded decimal displays are not substituted for the saved exact directed certificates.

Construction-specific private pressure tests remain outside publication. They neither refute the unrestricted optimal-cap premise nor supply missing original gates. Every unresolved geometric budget, original classification fee and conditional all-scale return remains explicit.

## R93 independent audit

The arbitrary-positive-L1 root-order centered-cube weak estimate remains UNPROVED. Sol independently read the complete contract and tested precise new claims before proofs, then read the full Markdown and matching TeX for parent scalar duality/allocation, concentrated-source common caps, pooled overlap energy, partial-demand source occupation, and the cancelled cube square endpoint. These statements pass within their explicit scopes. The common-cap geometric bound, general cross-source interaction and smaller annular reservoir remain open. All scale, classification, threshold and layer costs remain.

The public continuum energy code/report passed full review. An isolated replay reproduced every JSON byte, including actual cap witnesses; producer execution counts are distinct from this review. A separate standard-library guard independently rebuilt7520 continuous cell volumes and32 one-cap deletion witnesses, checked20 separated-budget logarithm enclosures, six concentration dimensions and eighteen exact overlap-kernel models. It also checked twelve cancelled-arrival models and twelve actual radial layer identities. Separately it checked three generic scalar fields, three label-loss witnesses, three nonlinear assembly models, three generic demand-absorption coefficient cases and93 neutral finite RN label tuples. Generic field checks are not physical cube inputs. These are finite witnesses and exact enclosures, not an arbitrary-input theorem, diffuse energy-limit transfer or asymptotic fit.

The private phase pipeline passed full review and one isolated mathematical-JSON replay. Its true Haar hard-witness class retains all coordinate bin widths and full finite-dimensional likelihood. Whole-window smooth/coarse qualification remains UNKNOWN, so no full residual-volume, occupation or weak-bound conclusion is inferred. Rounded displayed values are diagnostic; certificates use saved outward rational endpoints. Private construction details remain excluded.

## 第93轮实际验证与复现范围

两位审计先独立检查命题和潜在反例，再完整阅读五组 Markdown 与对应 LaTeX，包括最终交叠核环域恒等式及部分需求势的前缀恒等式。有限范围内的证明通过；一般根阶结论没有获得认证。主代理检查全部材料、重放新数值程序并统一原主账。作者结论不是审计依据。

公开能量程序包含 7 个新有限原子输入、8 次连续区域划分、7520 个真实区域和 32 项共同删集预算。压力阶段同一输入的网格加密不计作新输入。31 项上界有限，1 项粗网格上界 UNKNOWN；对后者加密才得到有限证书。另有 5 个维数上的 20 项分离原子闭式校准，最高维数 4096；这些是解析公式校准，并非枚举一般高维来源。生产 0.711064375 秒，主代理隔离重放 0.740459250 秒，解析 JSON 全字段精确相等，没有忽略字段。两审隔离重放分别 0.942776500、0.713583916 秒。全部接收体积、一个共同删集与所有尺度费用均保留，未拟合渐近指数。

主代理的删集对偶程序检验一般简单能量场，而非真实方体输入：初探 96、已知障碍压力 256、扩大 768、错误标签预算见证 10、无穷场精确尾 6，共 1136 项精确断言。最大 64 个单元，允许无穷能量与零体积。生产 0.694267417 秒，主代理隔离重放 0.791490291 秒；仅删除顶层 runtime_seconds 后 JSON 精确相等。Sol 另作非写入方式精确重建。该程序验证标量恒等式，不证明几何能量预算。

覆盖作者实际完成 531 项三阶段精确检查及新增 9 项环域恒等式检查，共 540 项；前者 2.059305833 秒，后者 0.001231791 秒。部分需求递推作者完成 275 项新精确检查。替代路线嵌入程序包含 50 个浓缩轮廓、24 个私人几何案例、12 个同体积修补和 36 个缩放案例，各单位不相加为断言数。主代理完整隔离运行 0.138719958 秒，所有嵌入断言通过，各阶段计数与作者记录相等；不存在可逐字段比较的旧结果 JSON，故不声称结果 JSON 相等。Sol 独立运行 0.126090833 秒。来源作者执行 492 项核与似然比精确检查。以上作者级检查和独立公开守卫各自注明范围，不重复计作新实验。

私人全周期 Haar 检验固定两个真实尺度节点、三个有理倾斜，初探 6 项；只有一个满足硬阈值的候选进入加密阶段。实际乘积似然、全部 n 个坐标区间宽度、整数分数带及方差尾费用均保留，没有 Monte Carlo、CLT 或未经证明的中偏差误差替代。证得全维正体积硬见证以及各坐标的完整周期投影；原平滑上门、粗门仍 UNKNOWN，不能称为完整 Fnew、高来源负担或一般容量证书。小数仅是显示，实际体积下界使用保存的有理对数端点。

私人程序生产 1.439835833 秒，主代理隔离重放 2.060757042 秒，两审分别 1.440192167、1.450671459 秒；所有数学 JSON 精确一致，递归仅忽略 runtime_seconds 和 runtime_seconds_diagnostic。冻结的前轮输入、清单与辅助程序哈希保持不变。程序、输入和新下界压力配方不进入公开包。

独立公开守卫使用标准库，不导入生产程序、不含私人来源。它独立重建 7520 个真实连续单元的体积、32 项实际删集体积见证和 20 项解析能量区间；此外检查 6 个浓缩维数、18 个实际交叠模型、12 个抵消到达模型、12 个径向恒等式、3 个一般场标量模型、3 个标签预算模型、3 个叠加模型、3 个吸收模型和 93 个中性似然标签。不同单位不相加为统一断言数。守卫没有独立重建全部 7520 个能量上下包络，后者由完整证明阅读和生产程序隔离重放另行核验。Sol 在仅有守卫与公开能量 JSON 的临时目录运行通过，0.078541292 秒。主代理仅带守卫与能量 JSON 的隔离运行通过，0.064594250 秒；最终七成员归档提取运行的实际收据另附轮次说明。

更新后的 64 项技能入口字节记录为版本快照，不代表 64 篇定理全部重新核验。本轮实际定向阅读包括 B03、B04、F03 的入口、方法和课题接口；F03 提升包声明及证据边界另行读取。来源组阅读 Benedek–Calderón–Panzone 1962 年原文相关定理和证明，逐项检查原始平方函数的前提失败及抵消版本仍有的维数费用，不把题录或技能名称视为定理证明。

公开复现：解压 research.zip，使用 Python 3 标准库运行 energy_probe.py 和 parent_variational_probe.py；从 proof.md 唯一 Python 代码块保存 audit_guard.py，与能量 JSON 同目录运行。生产程序生成相应 JSON；除变分结果顶层运行时间外，其余数学内容应一致。清单记录公开成员哈希、证据范围和实际重放。原始论文、私人程序、临时输出和重复草稿不纳入归档。

LaTeX 仅作环境配对、括号、重复标签、内部引用和控制字符静态检查，不编译、不生成 PDF。尚缺：部分需求递推真实几何损失的根阶支付；任意来源的一次共同删集及交互预算；或者抵消平方函数向正超额能量的合法转移。一般目标仍未证明。


## 独立公开审核程序

```python
"""Independent R93 public exact guard, standard library only.
No private source recipes and no producer imports. Exact geometry witnesses,
new concentration/pair formulas, and generic field identities have distinct scope.
"""
from fractions import Fraction as F
from pathlib import Path
import base64, hashlib, itertools, json, zlib
from math import comb, factorial

def ceil(x): return -((-x.numerator)//x.denominator)
def log_interval(q):
    assert q > 0
    k=0
    while q<1: q*=2; k-=1
    while q>2: q/=2; k+=1
    def unit(z):
        t=(z-1)/(z+1); p=t; a=F(0)
        for j in range(48): a+=2*p/(2*j+1); p*=t*t
        return a,a+2*p/(97*(1-t*t))
    l,u=unit(q); l2,u2=unit(F(2))
    return (l+k*l2,u+k*u2) if k>=0 else (l+k*u2,u+k*l2)

def scalar():
    # Independently enumerate every breakpoint of fractional deletion.
    cases=[([(F(1),F(3)),(F(2),F(1))],F(1,2)),
           ([(F(2,3),F(7)),(F(1,3),F(7)),(F(3,2),F(0))],F(4,3)),
           ([(F(1,5),F(100)),(F(2,5),F(2)),(F(3,5),F(1))],F(1,2))]
    for field,a in cases:
        levels=sorted({F(0)}|{e for v,e in field})
        layer=sum((t-s)*max(F(0),sum(v for v,e in field if e>s)-a) for s,t in zip(levels,levels[1:]))
        dual=max(sum(v*min(e,t) for v,e in field)-a*t for t in levels)
        left=a; kept=F(0)
        for v,e in sorted(field,key=lambda p:p[1],reverse=True):
            take=min(left,v); left-=take; kept+=(v-take)*e
        assert kept==layer==dual
    # Shared-space / labelled-space losses, deliberately generic not cube input.
    for m in [2,5,11]:
        h=F(3,7); a=F(2,3)
        assert (m-1)*h*a>0
        # m copies on same set: common cap zero; tagged deletion leaves m-1 copies.
        assert m*h*a-h*(a)==(m-1)*h*a
    return len(cases),3

def profiles():
    # Whole concentration interval bounded by exact endpoint inequalities.
    runs=0
    for ns in [(2,3),(8,16),(32,64)]:
        for n in ns:
            rho=F(1,16*n)
            assert (1-rho)**n>=1-n*rho
            assert (1+rho)**n<=1/(1-n*rho)
            l,u=log_interval(1/(1-rho)); assert u<=rho/(1-rho)
            envelope=n**3*rho**4/((1-n*rho)**3*(1-rho))
            assert envelope<=F(1,50625*n)
            # Independent exact beta-integral evaluation of sharp pair coefficient.
            beta=sum(F((-1)**j, n+j)*F(comb(1,j)) for j in range(2))
            assert beta==F(1,n*(n+1)) # int_0^1 t^(n-1)*(1-t) dt
            runs+=1
    return runs

def overlap_checks():
    models=0
    for ns in [(2,3),(8,16),(32,64)]:
        for n in ns:
            for k in (1,n):
                coords=[F(3,2)]*k+[F(0)]*(n-k)
                coeff=[F(1)]
                for d in coords:
                    nxt=[F(0)]*(len(coeff)+1)
                    for j,c in enumerate(coeff): nxt[j]+=c; nxt[j+1]-=d*c
                    coeff=nxt
                r=max(coords)
                actual=sum(c/F(n+j)/r**(n+j) for j,c in enumerate(coeff))
                beta=F(factorial(n-1)*factorial(k),factorial(n+k))/r**n
                assert actual==beta and 0<actual<=1/(n*(n+1)*r**n)
                models+=1
            coords=[F(1)]+[F(j%4,4) for j in range(1,n)]
            coeff=[F(1)]
            for d in coords:
                nxt=[F(0)]*(len(coeff)+1)
                for j,c in enumerate(coeff): nxt[j]+=c; nxt[j+1]-=d*c
                coeff=nxt
            actual=sum(c/F(n+j) for j,c in enumerate(coeff))
            assert 0<actual<=F(1,n*(n+1))
            models+=1
    # Exact nonlinear assembly pressure at values crossing the positive threshold.
    assemblies=0
    for xs in ([F(3,4),F(3,4)],[F(2),F(1,4),F(1,8)],
               [F(1,10)]*16):
        left=max(sum(xs)-1,F(0))**2
        right=sum(max(x-1,F(0))**2 for x in xs)+2*sum(x*y for x,y in itertools.combinations(xs,2))
        assert left<=right; assemblies+=1
    return models,assemblies

def source_and_demand_checks():
    arrival_models=0; demand_models=0
    for ns in [(1,2),(4,8),(16,64)]:
        for n in ns:
            for a in (F(1,3),F(3,2)):
                # K_S arrival at a/2 has coefficient -2^-n, then 1-2^-n.
                before=F(1,2**n)**2*((a/2)**(-2*n)-a**(-2*n))/(2*n)
                after=(1-F(1,2**n))**2*a**(-2*n)/(2*n)
                assert before+after==(1-F(1,2**n))*a**(-2*n)/n
                arrival_models+=1
            for L,r in [(F(3,2),F(1,2)),(F(7,4),F(5,4))]:
                lower=max(F(1),r)
                primitive=L**(-n)+(lower**(-n)-L**(-n))
                assert primitive==max(F(1),r)**(-n)
                demand_models+=1
    for c,A,u in [(F(3,4),F(2),F(7,8)),(F(4,5),F(5),F(9,10)),(F(9,10),F(11),F(19,20))]:
        beta=c/2; aa=(1-beta)/(c-beta); b=2/c
        K=2*A*u/(beta*(1-beta))
        assert aa==b-1 and 0<aa<b
        assert A*u/(beta*K*(1-beta))==F(1,2)
        # At maximal child mass and maximal retained demand, fee absorbs half loss.
        D=F(7,3); Wchild=u*D/K; Dchild=beta*D
        assert A*Wchild/beta==(D-Dchild)/2
        demand_models+=1
    # Neutral finite law, not an assertion about physical source coordinates.
    scores=(-1,0,2); z=F(3,2); Z=sum(z**v for v in scores); tuples=0
    for n in (1,2,4):
        total=F(0)
        for labels in itertools.product(scores,repeat=n):
            score=sum(labels); q=z**score/Z**n; rn=(Z/3)**n*z**(-score)
            assert q*rn==F(1,3**n); total+=q*rn; tuples+=1
        assert total==1
    return arrival_models,demand_models,tuples

def witnesses(path):
    data=json.loads(path.read_text()); caps=0; cells=0; analytic=0
    for stage in data['stages']:
        for case in stage['continuum_certificates']:
            n=case['n']; mesh=case['mesh']; h=F(1,mesh)
            atoms=[(F(z),F(m)) for z,m in case['atoms_axis_mass']]
            assert sum(m for z,m in atoms)==1
            lo=min(z for z,m in atoms)-F(1,2); hi=max(z for z,m in atoms)+F(1,2)
            first=lo//h; last=ceil(hi/h)
            volumes={}
            for i in range(first,last):
                for j in ([None] if n==1 else range(mesh//2)):
                    v=h if n==1 else h*((2*(j+1)*h)**(n-1)-(2*j*h)**(n-1))
                    assert v>0; volumes[(i,j)]=v
            assert len(volumes)==case['compressed_cells']
            assert sum(volumes.values())==F(case['full_receiver_domain_volume'])
            cells+=len(volumes)
            for row in case['budgets']:
                cap=row['selected_cap']; raw=zlib.decompress(base64.b85decode(cap['fully_deleted_cells_zlib_base85']))
                assert hashlib.sha256(raw).hexdigest()==cap['fully_deleted_cell_ids_sha256']
                ids=[tuple(x) for x in json.loads(raw)]; assert len(ids)==len(set(ids))==cap['fully_deleted_cell_count']
                assert all(x in volumes for x in ids)
                volume=sum((volumes[x] for x in ids),F(0)); partial=cap['partial_cell']
                if partial:
                    pid=tuple(partial['cell']); assert pid in volumes and pid not in ids
                    q=F(partial['axial_slice_fraction']); v=F(partial['deleted_volume'])
                    assert 0<q<1 and v==volumes[pid]*q
                    volume+=v
                assert volume==F(cap['actual_cap_volume'])<=F(row['cap_budget'])
                assert cap['single_cap_independent_of_scale']
                assert (row['selected_single_cap_upper'] is None)==cap['singular_upper_cells_remaining']
                if row['selected_single_cap_upper'] is not None:
                    assert F(row['optimum_over_all_measurable_caps_lower'])<=F(row['selected_single_cap_upper'])
                caps+=1
        for case in stage['analytic_calibrations']:
            n=case['n']
            for row in case['curves']:
                a=F(row['cap_budget']); lo,hi=map(F,[row['optimal_energy_interval']['lower'],row['optimal_energy_interval']['upper']])
                if a==1: assert lo==hi==0
                else:
                    l,u=log_interval(a); r=2+1/(2*a)-F(5,2)*a
                    exactlo=(r+(2+a)*l)/n; exacthi=(r+(2+a)*u)/n
                    assert lo<=exactlo<=exacthi<=hi
                assert sum(map(F,row['each_component_cap_volume']))==a
                analytic+=1
    return cells,caps,analytic

if __name__=='__main__':
    generic,labels=scalar(); profile=profiles(); pairs,assemblies=overlap_checks(); arrivals,demands,tuples=source_and_demand_checks()
    cells,caps,analytic=witnesses(Path(__file__).with_name('energy_results.json'))
    print(json.dumps({'status':'PASS','independent_generic_simple_fields':generic,'generic_label_witnesses':labels,
        'concentration_profile_dimensions':profile,'actual_overlap_kernel_models':pairs,'cancelled_arrival_models':arrivals,
        'generic_demand_and_actual_radial_identity_models':demands,'neutral_finite_RN_label_tuples':tuples,
        'generic_positive_excess_assembly_models':assemblies,'actual_continuum_cells_rebuilt':cells,
        'actual_single_cap_volume_witnesses':caps,'analytic_separated_budget_enclosures':analytic,
        'scope':'Exact new finite witnesses/enclosures; no private recipes, producer imports, FLOAT or general all-input energy theorem.'},sort_keys=True))
```
