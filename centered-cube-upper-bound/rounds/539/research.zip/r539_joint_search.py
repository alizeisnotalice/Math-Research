import ast,json,time,sys,platform
from pathlib import Path
from fractions import Fraction
import numpy as np, scipy, sympy as sp
from scipy.optimize import minimize,differential_evolution
def model(N):
    bits = np.array([[bool(mask >> i & 1) for i in range(N)] for mask in range(1, 1 << N)])

    def rectangles(x, w):
        spanlo = np.min(np.where(bits[:, :, None], x[None, :, :], np.inf), axis=1)
        spanhi = np.max(np.where(bits[:, :, None], x[None, :, :], -np.inf), axis=1)
        r = np.sqrt(bits @ w)
        lo = spanhi - r[:, None] / 2
        hi = spanlo + r[:, None] / 2
        ok = np.all(hi > lo, axis=1)
        return (lo[ok], hi[ok])

    def area(x, w):
        lo, hi = rectangles(x, w)
        edges = np.unique(np.r_[lo[:, 0], hi[:, 0]])
        total = 0.0
        for left, right in zip(edges[:-1], edges[1:]):
            mid = (left + right) / 2
            ids = np.flatnonzero((lo[:, 0] < mid) & (hi[:, 0] > mid))
            if not len(ids):
                continue
            ids = ids[np.argsort(lo[ids, 1])]
            bottom = lo[ids[0], 1]
            top = hi[ids[0], 1]
            length = 0.0
            for i in ids[1:]:
                if lo[i, 1] > top:
                    length += top - bottom
                    bottom = lo[i, 1]
                    top = hi[i, 1]
                else:
                    top = max(top, hi[i, 1])
            length += top - bottom
            total += (right - left) * length
        return total
    return area
T=time.monotonic(); deadline=T+112; results=[]; count=0
base=[{'N': 4, 'positions': [['0', '0'], ['-sqrt(2)/4 - 1/4', '0'], ['-sqrt(2)/4 - 1/4', '-sqrt(2)/4 - 1/4'], ['0', '1/4 + sqrt(2)/4']], 'masses': ['1/4', '1/4', '1/4', '1/4'], 'final_area': '-sqrt(3)/4 + sqrt(2)/8 + 3/2'}, {'N': 4, 'positions': [['0', '0'], ['0', '1/4 + sqrt(2)/4'], ['1/4 + sqrt(2)/4', '0'], ['-sqrt(2)/4 - 1/4', '0']], 'masses': ['1/4', '1/4', '1/4', '1/4'], 'final_area': '-sqrt(3)/4 + sqrt(2)/8 + 3/2'}, {'N': 6, 'positions': [['0', '0'], ['0', '-sqrt(30)/12 - sqrt(2)/4 + sqrt(6)/12'], ['sqrt(6)/12 + sqrt(3)/6', '-1/2 - sqrt(3)/6 - sqrt(6)/12 + sqrt(30)/12'], ['-sqrt(3)/6 - sqrt(6)/12', '-sqrt(2)/4 - sqrt(3)/6 + sqrt(6)/12'], ['-sqrt(6)/4', '-sqrt(2)/4 + sqrt(6)/6'], ['sqrt(6)/12 + sqrt(3)/6', '-1/2 + sqrt(30)/12']], 'masses': ['1/6', '1/6', '1/6', '1/6', '1/6', '1/6'], 'final_area': '-sqrt(6)/6 - sqrt(15)/24 + sqrt(2)/24 + sqrt(5)/12 + 19/12'}]
def decode(z,N):
 w=np.exp(np.r_[0,z[2*N-2:]]);w/=w.sum();return np.r_[[[0.,0.]],z[:2*N-2].reshape(N-1,2)],w
def encode(x,w):return np.r_[x[1:].ravel(),np.log(w[1:]/w[0])]
for b in [base[1],base[2]]:
 N=b['N'];A=model(N);x=np.array([[float(sp.sympify(v)) for v in p] for p in b['positions']]);w=np.ones(N)/N;z0=encode(x,w); best=z0.copy();bestval=A(x,w);runs=[]
 def obj(z):
  global count,best,bestval
  if time.monotonic()>deadline:raise TimeoutError
  count+=1;xx,ww=decode(z,N);a=A(xx,ww)
  if a>bestval:bestval=a;best=z.copy()
  return -a
 bounds=[(-1.1,1.1)]*(2*N-2)+[(-1.3,1.3)]*(N-1)
 for stage,seed in [('initial',53901+N),('contact_collision_pressure',53911+N),('expanded_seed',53921+N)]:
  start=time.monotonic();before=count;initial=bestval;rng=np.random.default_rng(seed)
  try:
   if stage=='initial':
    opt=minimize(obj,best,method='Powell',bounds=bounds,options={'maxfev':1800,'xtol':1e-8,'ftol':1e-10})
   elif stage=='contact_collision_pressure':
    # Small joint perturbations probe loss of equal mass contacts. Includes almost-collision layouts.
    for k in range(90):
     z=best.copy();z[:2*N-2]+=rng.normal(0,10**rng.uniform(-5,-1),2*N-2);z[2*N-2:]+=rng.normal(0,.1,N-1);obj(z)
    for k in range(20):
     xx,ww=decode(best,N);i,j=rng.choice(N,2,replace=False);xx[i]=xx[j]+rng.normal(0,.0001,2);xx-=xx[0].copy();obj(encode(xx,ww))
    opt=minimize(obj,best,method='Nelder-Mead',bounds=bounds,options={'maxfev':1800,'xatol':1e-8,'fatol':1e-10,'initial_simplex':np.r_[best[None,:],best[None,:]+np.diag(np.r_[np.full(2*N-2,.015),np.full(N-1,.10)])]})
   else:
    # Wider location/mass range, deterministic DE seeded with best and random population.
    bd=[(-1.5,1.5)]*(2*N-2)+[(-2.,2.)]*(N-1);pop=rng.uniform(np.array(bd)[:,0],np.array(bd)[:,1],(max(30,3*len(best)),len(best)));pop[0]=best
    opt=differential_evolution(obj,bd,seed=seed,maxiter=20,popsize=3,init=pop,polish=False,tol=1e-8)
   status=str(opt.message)
  except TimeoutError:status='total 112 second time budget reached'
  runs.append(dict(stage=stage,seed=seed,area_before=initial,best_area_after=bestval,evaluations=count-before,elapsed_seconds=time.monotonic()-start,status=status));print(N,runs[-1],flush=True)
  if time.monotonic()>deadline:break
 xx,ww=decode(best,N)
 results.append(dict(N=N,baseline=float(sp.sympify(b['final_area'])),best_area=bestval,positions=xx.tolist(),masses=ww.tolist(),encoded=best.tolist(),runs=runs))
 if time.monotonic()>deadline:break
# Bounded diagnostic ablations distinguish a new mass effect from a position contact effect.
for r in results:
 N=r['N'];A=model(N);xx=np.array(r['positions']);ww=np.array(r['masses']);diagnostics=[]
 diagnostics.append(dict(mode='same_joint_positions_equal_masses',area=A(xx,np.ones(N)/N)))
 if N==6:
  z=encode(xx,ww); before=count;st=time.monotonic()
  def joint_obj(z):
   global count
   count+=1
   x1,w1=decode(z,N);return -A(x1,w1)
  joint=minimize(joint_obj,z,method='Nelder-Mead',options={'maxfev':12000,'xatol':1e-10,'fatol':1e-12})
  diagnostics.append(dict(mode='joint_refinement',area=float(-joint.fun),evaluations=count-before,elapsed_seconds=time.monotonic()-st,status=str(joint.message)))
  if -joint.fun>r['best_area']:
   xx,ww=decode(joint.x,N);r.update(best_area=float(-joint.fun),positions=xx.tolist(),masses=ww.tolist(),encoded=joint.x.tolist())
  for mode,xstart,wfix in [('equal_mass_position_refinement',xx,np.ones(N)/N),('fixed_joint_mass_position_refinement',xx,ww)]:
   before=count;st=time.monotonic()
   def posobj(p):
    global count
    count+=1
    return -A(np.r_[[[0.,0.]],p.reshape(N-1,2)],wfix)
   rr=minimize(posobj,xstart[1:].ravel(),method='Nelder-Mead',options={'maxfev':8000,'xatol':1e-10,'fatol':1e-12})
   if mode=='fixed_joint_mass_position_refinement' and -rr.fun>r['best_area']:
    r.update(best_area=float(-rr.fun),positions=np.r_[[[0.,0.]],rr.x.reshape(N-1,2)].tolist())
   diagnostics.append(dict(mode=mode,area=float(-rr.fun),evaluations=count-before,elapsed_seconds=time.monotonic()-st,status=str(rr.message),positions=np.r_[[[0.,0.]],rr.x.reshape(N-1,2)].tolist(),masses=wfix.tolist()))
 r['encoded']=encode(np.array(r['positions']),np.array(r['masses'])).tolist()
 r['ablations']=diagnostics
# Independently compute area by all x-y grid cells, rather than one-dimensional merged intervals.
def grid_area(x,w):
 N=len(w);rect=[]
 for mask in range(1,1<<N):
  ids=[i for i in range(N) if mask>>i&1];r=np.sqrt(sum(w[i] for i in ids))/2;lo=np.max(x[ids],axis=0)-r;hi=np.min(x[ids],axis=0)+r
  if np.all(hi>lo):rect.append((lo,hi))
 ex=np.unique([p[j][0] for p in rect for j in (0,1)]);ey=np.unique([p[j][1] for p in rect for j in (0,1)]);cx=(ex[:-1]+ex[1:])/2;cy=(ey[:-1]+ey[1:])/2;covered=np.zeros((len(cx),len(cy)),bool)
 for lo,hi in rect:covered|=((cx[:,None]>lo[0])&(cx[:,None]<hi[0])&(cy[None,:]>lo[1])&(cy[None,:]<hi[1]))
 return float(np.sum(covered*np.diff(ex)[:,None]*np.diff(ey)[None,:]))
for r in results:
 qx=[[Fraction(float(v)).limit_denominator(10**8) for v in p] for p in r['positions']];qw=[Fraction(round(float(v)*10**8),10**8) for v in r['masses'][:-1]];qw.append(1-sum(qw));xx=np.array(qx,dtype=float);ww=np.array(qw,dtype=float)
 r['rationalized_positions']=[[str(v) for v in p] for p in qx];r['rationalized_masses']=[str(int(v*10**8))+'/100000000' for v in qw];r['rationalized_sweep_area']=model(r['N'])(xx,ww);r['rationalized_independent_grid_area']=grid_area(xx,ww);r['cross_check_abs_difference']=abs(r['rationalized_sweep_area']-r['rationalized_independent_grid_area'])
out=dict(budget='Initial three-stage loop checks elapsed 112 seconds before each objective; later diagnostic optimizations have maxfev 12000, 8000, 8000 and no wall-time limit. Measured complete elapsed time reported.',diagnostic_bounds='Joint and position-only diagnostic Nelder-Mead runs are unbounded, initialized at tracked joint candidate; no global best side effects inside diagnostic objectives. Initial joint refinement maxfev 12000; independent equal-mass and fixed-mass refinements each maxfev 8000.',scope='Full all-subset receiving union area, mass and positions jointly variable. Numerical bounded candidate search only; no global optimality or exact rationalized area certification.',command='/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/r539_joint_search.py',executable=sys.executable,versions=dict(python=platform.python_version(),numpy=np.__version__,scipy=scipy.__version__,sympy=sp.__version__),parameterization='first position fixed at origin, masses softmax of (0, logits); all positive summing to one',initial_pressure_bounds=dict(positions=[-1.1,1.1],log_mass_ratio=[-1.3,1.3]),expanded_bounds=dict(positions=[-1.5,1.5],log_mass_ratio=[-2,2]),total_evaluations=count,total_seconds=time.monotonic()-T,results=results)
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2));print(json.dumps(out),flush=True)
