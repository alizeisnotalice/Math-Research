from pathlib import Path
import json,sys,platform,functools
from fractions import Fraction
import sympy as s
import flint
from flint import arb,ctx
ctx.prec=256
src=json.loads(Path(__file__).with_name('r539_joint_search.json').read_text())
checks=0
@functools.lru_cache(None)
def ball(e):
 if e.is_Rational:return arb(int(e.p))/int(e.q)
 if e.is_Add:return sum((ball(v) for v in e.args),arb(0))
 if e.is_Mul:
  a=arb(1)
  for v in e.args:a*=ball(v)
  return a
 if e.is_Pow and e.exp==s.Rational(1,2):return ball(e.base).sqrt()
 raise ValueError(e)
def cmp(a,b):
 global checks
 checks+=1
 if a==b:return 0
 q=ball(a)-ball(b)
 if q>0:return 1
 if q<0:return -1
 if s.simplify(a-b)==0:return 0
 raise ValueError(('unresolved order',a,b,str(q)))
def cert(x,w):
 N=len(w); boxes=[]
 for mask in range(1,1<<N):
  ids=[i for i in range(N) if mask>>i&1]; r=s.sqrt(sum(w[i] for i in ids))/2
  lo=[max(x[i][j] for i in ids)-r for j in range(2)];hi=[min(x[i][j] for i in ids)+r for j in range(2)]
  if all(cmp(hi[j],lo[j])>0 for j in range(2)):boxes.append((lo,hi))
 edges=[sorted(set(b[k][j] for b in boxes for k in (0,1)),key=functools.cmp_to_key(cmp)) for j in range(2)]
 # Remove any algebraically coincident distinct expressions after certified sorting.
 for j in range(2):edges[j]=[e for i,e in enumerate(edges[j]) if i==0 or cmp(e,edges[j][i-1])!=0]
 ix=[{e:i for i,e in enumerate(es)} for es in edges]
 def loc(e,j):
  if e in ix[j]:return ix[j][e]
  return next(i for i,v in enumerate(edges[j]) if cmp(e,v)==0)
 boxes=[(loc(lo[0],0),loc(hi[0],0),loc(lo[1],1),loc(hi[1],1)) for lo,hi in boxes]
 area=arb(0);cells=0
 for i in range(len(edges[0])-1):
  cov=[False]*(len(edges[1])-1)
  for l,h,b,t in boxes:
   if l<=i<h:
    for k in range(b,t):cov[k]=True
  y=sum((ball(edges[1][k+1])-ball(edges[1][k]) for k,v in enumerate(cov) if v),arb(0))
  area+=(ball(edges[0][i+1])-ball(edges[0][i]))*y;cells+=sum(cov)
 return dict(area_interval=str(area),positive_boxes=len(boxes),covered_grid_cells=cells,endpoint_counts=list(map(len,edges))),area
out=[]
for row in src['results']:
 x=[[s.Rational(v) for v in a] for a in row['rationalized_positions']];w=[s.Rational(v) for v in row['rationalized_masses']]
 assert sum(w)==1 and all(v>0 for v in w)
 record,a=cert(x,w)
 record.update(N=len(w),positions=row['rationalized_positions'],masses=row['rationalized_masses'])
 if len(w)==6:
  old=ball(s.Rational(19,12)-s.sqrt(6)/6-s.sqrt(15)/24+s.sqrt(2)/24+s.sqrt(5)/12)
  assert a>arb('1.28') and a-old>arb('.02')
  record.update(strictly_above_1_28=True,improvement_over_r538_interval=str(a-old))
 out.append(record)
result=dict(executable=sys.executable,python=platform.python_version(),sympy=s.__version__,flint=flint.__version__,precision_bits=256,order_comparisons=checks,scope='Certified continuous receiving union for rationalized finite atomic candidates only; no global optimum or general weak bound.',results=out)
Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
