from fractions import Fraction as F
from itertools import product
padding=tail=0
for n in (1,2,4,8,16,32,64,128):
 for denom in (4,8,16):
  M=n*denom
  assert (1-F(1,M))**n>=1-F(n,M)==1-F(1,denom)
  padding+=1
# Exact finite distribution test of forcing high-row prior mass from its mean.
for A in (F(1),F(3),F(10)):
 for h in (A/4,A/2,3*A/4):
  for j in range(1,16):
   high=F(j,16)
   lowvalue=h/2; highvalue=(A+h)/2
   mean=(1-high)*lowvalue+high*highvalue
   if mean>h:
    assert high >= (mean-h)/(A-h)
    tail+=1
print({'padding_Bernoulli':padding,'mean_to_high_source_mass':tail,'total':padding+tail,'status':'PASS','scope':'exact bridge algebra; no high-dimensional halo measure computed'})
