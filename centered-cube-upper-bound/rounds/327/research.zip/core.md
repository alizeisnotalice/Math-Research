# R327 — a genuine periodic-input selector and positive high-J source mass

## Proved result and scope

A verified periodic maximal-level fixture can be converted into a positive-volume, finite-L1, genuinely centered-cube hard shared-kernel input with

    alpha=1, s=0, L(x)=R(x), beta=nu=f,
    q(x)=h_(R(x))*f(x)=lambda on E,
    rho=1_E.

The selected radius is the largest actual root of q_r(x)=lambda. No old selector or fixed residual is reset. Finite truncation has an exact source-mass cost. If the resulting certified level ratio L=lambda|E|/W_f exceeds lambda H, then a quantitative positive f-mass of the ORIGINAL rows has J_z(b)>=H.

This is a constructive entry theorem and a nonvacuity certificate for genuine high-J tests. It is not a bound on the full scalar B_nu, not a lower bound for B_nu, and not a proof of the R326 weak-L2 capacity estimate. In particular a large J can still be offset by the original capture square. No literature lower asymptotic or unverified level-set measure is assumed.

## 1. Periodic fixture and exact finite truncation

Let F>=0 be measurable, Z^n-periodic, locally integrable, with

    integral_[0,1)^n F=1.

Fix 0<a<=b_0<2 and lambda>1. For example the proposed testing radii are a=25/24 and b_0=11/8. Define the periodic level set and its actual one-cell measure by

    E_per={x:max_(a<=r<=b_0) h_r*F(x)>lambda},
    theta=|E_per intersection [0,1)^n|.

No particular value or dimension growth of theta is assumed. For every x, integration over an axis-aligned cube of side 2 covers exactly two full periods in each coordinate, and therefore

    h_2*F(x)=1.                                        (1)

Take an integer M>=2. Let Q_l be the centered cube of side l, and define

    f=F 1_(Q_(2M)),
    Omega=Q_(2M-2),
    E=Omega intersection E_per.

Boundary choices do not affect any integral. Every cube Q_r(x) with x in Omega and r<=2 is contained in Q_(2M), up to null boundaries. Thus

    h_r*f(x)=h_r*F(x),  x in Omega, 0<r<=2.             (2)

Both truncation cubes have integer side length. Periodicity gives the EXACT identities

    W_f=integral f=(2M)^n,
    |E|=(2M-2)^n theta,
    L:=lambda|E|/W_f=lambda theta(1-1/M)^n.              (3)

For any 0<delta<1, choosing integer M>=max(2,n/delta) yields, by Bernoulli's inequality,

    L>=lambda theta(1-delta).                          (4)

The boundary source mass is already included in W_f in (3); it is not discarded or treated as free. A certified lower bound theta>=theta_* supplies the correspondingly certified lower bound L>=lambda theta_*(1-1/M)^n. All later conditional conclusions must use that actual certificate, including its errors.

## 2. Largest-root selector, measurability, and exact normalization

For x in E write q_r(x)=h_r*f(x) and set

    R(x)=max{r in [a,2]:q_r(x)>=lambda}.                 (5)

The map (x,r)->q_r(x) is continuous for r>0 when f is L1: translation continuity and absolute continuity of the integral control the moving cube, and division by r^n is continuous away from zero. For each x in E there is some r_0 in [a,b_0] with q_(r_0)(x)>lambda, whereas (1)-(2) give q_2(x)=1<lambda. The set in (5) is therefore nonempty and compact, R(x)<2, and continuity forces

    q_(R(x))(x)=lambda.                                 (6)

Indeed a strict value greater than lambda at its largest point would persist at a slightly larger radius. Equation (5) is also the largest root of q_r=lambda; it is not merely a discretized approximate root.

The selector is Borel measurable. For fixed t in [a,2], its superlevel event is

    {x in E:R(x)>=t}
       ={x in E:max_(t<=r<=2)q_r(x)>=lambda},

and the compact-parameter maximum is continuous in x. Define R arbitrarily outside E, where the receiver fields vanish. Setting b=2, L(x)=R(x), s(x)=0 and alpha=1 now gives a genuine centered-cube instance satisfying every stated hard-branch field identity.

This construction creates NEW test data. If used as an alternative original entrance, its full low-J/high-J bridge must be reconstructed. It cannot change the selector, alpha, or negative square of an old fixed residual.

## 3. Same-source FIRST, cap, and high-J mass

Use beta=nu=f as measures and

    U_y(x)=1_E(x)h_(R(x))(x-y)/lambda,
    J_y(r)=integral_(R(x)<=r) U_y(x)dx,
    A_yz(r)=integral_(R(x)<=r) U_y(x)c_x(z)dx.

By (6), exactly

    rho(x)=integral U_y(x)f(y)dy=1_E(x),
    f(Q_(R(x))(x))=lambda R(x)^n,
    X_rho=lambda|E|.                                   (7)

In particular the required same-radius cap with constant 4 holds with constant 1, and q lies in [3lambda/4,lambda]. The source order nu<=beta<=f holds as equality in this SAME slot. These facts do not assert realization of any earlier soft/history eligibility construction.

Let

    A_n=1+nlog(2/a),   Z(z)=lambda J_z(2).

The true geometric radial envelope gives the pointwise bound

    0<=Z(z)<=integral sup_(a<=r<=2)h_r(x-z)dx=A_n.        (8)

Its integral is exactly 1+nlog(2/a), including the terminal envelope contribution. Tonelli and FIRST give the SAME-source moment identity

    integral f(z)Z(z)dz=lambda|E|=L W_f.                 (9)

Hence, for every H>=0 with lambda H<L,

    f({z:J_z(2)>=H})/W_f
        >= (L-lambda H)/(A_n-lambda H)>0.                (10)

To prove (10), put h=lambda H. On the complementary source set Z<h, while on the indicated set Z<=A_n. Thus L W_f<=h W_f+(A_n-h)f({Z>=h}). Since h<L<=A_n, the denominator is positive. Inclusive equality at the threshold is retained. The source rows in (10) qualify for the original high-J gate at the terminal layer r=b, whose ell_n atom remains present.

For an externally prescribed original threshold H=sqrt(d A_n/(4lambda)), the condition is explicitly

    L>(1/2)sqrt(lambda d A_n).

It must be verified; it is not implied just by theta>0 or by an unquantified statement that some lower ratio grows. No lambda d or aspect factor is suppressed. Formula (10) only certifies positive high-J source mass; it does not quantify its positive full-square cost.

## 4. Exact column relation, and the remaining budget problem

In this genuine hard matched branch, the UNGATED linear column is

    N_0(z)=integral ell_n(dr) integral f(y)A_yz(r)dy
          =integral_E c_x(z)/R(x)^n dx
          =lambda J_z(2)=Z(z).                         (11)

The equality uses the actual inclusive tail ell_n([R,2])=R^(-n). Since q is exactly lambda here, (11) is an equality, stronger than the variable-q inequality N_0<=lambda J_z(2). For the original high-row full-square cost bcost(z),

    0<=bcost(z)<=Z(z),
    Z(z)-bcost(z)
       =the low-J linear column + the ORIGINAL high-J square. (12)

Thus B_nu<=X_rho, but this has receiver coefficient 1. Paying epsilon X_rho plus a root source fee requires a quantitative lower control of the right side of (12), or a comparable geometric first-moment argument. Positive high-J mass from (10) does not provide that control automatically.

The R326 remaining parameter can now be tested on genuinely admissible high-J data:

    D_epsilon=sup_(t>0)
       t^2 f({z:[bcost(z)-epsilon Z(z)]_+>t})/W_f.

Only D_epsilon<=A_n^2 is presently proved. No O(n polylog^2 n) estimate or weaker sufficient first-moment estimate is established here.

The attempted positive-Gram shortcut was screened and not used: A is symmetric with A_yy=J_y, but reciprocal posterior affinity only reexpresses A_yz<=J_z. Scalar positivity, prefix volume caps and selected-operator L2 alone do not encode literal cube incidence. Genuine cube traces on N source points are bounded by (N+1)^(2n), since each coordinate has only N+1 possible lower/upper cuts. This is additional geometric information, but no conversion from that trace count to the required f-weighted full-square budget has been proved. No conditional affinity class, generic compression identity, or artificial range model is counted as a payment.

## 5. Executed positive-volume periodic diagnostic

A local exact Fraction calculation used the genuine one-dimensional periodic function F=4 on [0,1/4) mod 1 and 0 elsewhere, with a=25/24, b_0=11/8, lambda=6/5. It verified q_2=1 at 160 rational centers and exact largest-root normalization at all 47 centers whose radius maximum exceeded lambda. By piecewise-affine integration it also computed

    |{x in [0,1):q_(11/8)(x)>6/5}|=3/10.

This last exact value is a lower certificate theta>=3/10 for the full radius maximum, not an asserted equality for that maximum. With M=3, (3) yields L>=6/25. Thus this finite fixture gives a genuine positive high-J source fraction for, for example, H=1/10:

    f({J>=1/10})/W_f
       >= (3/25)/[1+log(48/25)-3/25]>0.

This low-dimensional check supplies no dimension-growing lower ratio and no full-square budget. The primitive handles negative arguments by the mathematical floor, so the periodic boundary crossings are exact. Root checks use all piecewise-linear breakpoints, not a numerical root finder.

```python
from fractions import Fraction as F
A=F(25,24); B=F(11,8); lam=F(6,5)
def primitive(t):
    k=t.numerator//t.denominator
    return F(k)+4*min(t-k,F(1,4))
def q(x,r):
    return (primitive(x+r/2)-primitive(x-r/2))/r
def breaks_r(x,lo,hi):
    s={lo,hi}
    for k in range(-3,5):
        for c in (F(k),F(k)+F(1,4)):
            r=2*abs(x-c)
            if lo<r<hi:s.add(r)
    return sorted(s)
count=0
for i in range(160):
    x=F(i,160)
    assert q(x,F(2))==1
    if max(q(x,r) for r in breaks_r(x,A,B))<=lam:continue
    cuts=breaks_r(x,A,F(2)); roots=[]
    for lo,hi in zip(cuts,cuts[1:]):
        fl=(q(x,lo)-lam)*lo; fh=(q(x,hi)-lam)*hi
        if fl==0:roots.append(lo)
        if fh==0:roots.append(hi)
        if fl*fh<0:roots.append(lo-fl*(hi-lo)/(fh-fl))
    R=max(roots)
    assert A<=R<2 and q(x,R)==lam
    count+=1
cuts={F(0),F(1)}
for k in range(-3,5):
    for c in (F(k),F(k)+F(1,4)):
        for x in (c-B/2,c+B/2):
            if 0<x<1:cuts.add(x)
cuts=sorted(cuts); theta=F(0)
for lo,hi in zip(cuts,cuts[1:]):
    fl=q(lo,B)-lam; fh=q(hi,B)-lam
    if fl>=0 and fh>=0:
        if fl>0 or fh>0:theta+=hi-lo
    elif fl*fh<0:
        z=lo-fl*(hi-lo)/(fh-fl)
        theta+=(z-lo if fl>0 else hi-z)
assert count==47 and theta==F(3,10)
print('q2 checks',160,'exact largest roots',count,
      'fixed-radius level measure',theta,
      'M3 ratio lower bound',lam*theta*F(2,3))
```

## 6. Delivery ledger

Only /tmp/r327_core.md is authored. The theorem preserves the full original dx integrals and radius range [a,2]; no scale or source mass is omitted. Its exact truncation multiplier is (1-1/M)^n and its envelope cost is A_n. It supplies legitimate test/entrance data and the mass certificate (10), not a new B_nu payment. If inserted into an original proof, the authentic low-J/high-J entrance, source recovery and all outer factors remain to be accounted for separately. General soft/mismatched kernels and fixed historical alpha masks are not settled by this hard-branch construction. Work stops at this bounded positive result.
