#!/usr/bin/env python3
"""R327 actual growing-dimensional geometry with explicit root-H relevance gate."""
from fractions import Fraction as F
from pathlib import Path
from collections import Counter
import json,hashlib
counts=Counter()
def ck(key,test):
 counts[key]+=1
 assert test,key

def volume(B):
 v=F(1)
 for lo,hi in B:v*=max(F(0),hi-lo)
 return v

def intersection(A,B):return tuple((max(a,c),min(b,d)) for (a,b),(c,d) in zip(A,B))
def minus_boxes(A,B):
 cut=intersection(A,B)
 if not volume(cut):return [A]
 pieces=[];current=list(A)
 for axis,(lo,hi) in enumerate(cut):
  if current[axis][0]<lo:
   p=list(current);p[axis]=(current[axis][0],lo);pieces.append(tuple(p));current[axis]=(lo,current[axis][1])
  if hi<current[axis][1]:
   p=list(current);p[axis]=(hi,current[axis][1]);pieces.append(tuple(p));current[axis]=(current[axis][0],hi)
 return pieces

def root_upper(N,n):
 den=2**16;lo=den;hi=2*den
 while lo<hi:
  mid=(lo+hi)//2
  if mid**n>=N*den**n:hi=mid
  else:lo=mid+1
 return F(lo,den)
def logtwo_interval():
 t=F(1,3);lo=2*sum((t**(2*j+1)/F(2*j+1) for j in range(32)),F(0));return lo,lo+2*t**65/(65*(1-t*t))
def run(n):
 k=max(1,n.bit_length()-2);active=2*k;N=3**k;s=F(1,100*n);R=root_upper(N,n);q=F(N)/R**n
 ck('physical_dimension',active<=n)
 ck('mixed_scale_legal',1<R<=2)
 ck('actual_q_band',F(3,4)<=q<=1)
 # Per-gadget actual geometry. Tensor products yield3^k distinct sourceboxes.
 triangle=[(-1,-1),(1,-1),(-1,1)]
 for own in triangle:
  for src in triangle:
   if src==own:ck('all_own_source_captured',all(abs(F(a,2)-F(b,4))+(F(1,2)-s)/2+s/2<=F(1,2) for a,b in zip(own,src)))
   else:ck('all_other_source_excluded',any(abs(F(a,2)-F(b,4))-(F(1,2)-s)/2-s/2>=F(1,2) for a,b in zip(own,src)))
 ck('big_active_capture',F(1,4)+(R-F(1,2)-s)/2+s/2==R/2)
 ck('big_passive_capture',(R-s)/2+s/2==R/2)
 ck('source_boxes_disjoint',s<F(1,2))
 own=tuple([(F(-1,2)-(F(1,2)-s)/2,F(-1,2)+(F(1,2)-s)/2)]*active+[(-(1-s)/2,(1-s)/2)]*(n-active))
 big=tuple([(-(R-F(1,2)-s)/2,(R-F(1,2)-s)/2)]*active+[(-(R-s)/2,(R-s)/2)]*(n-active))
 pieces=minus_boxes(own,big);a=sum((volume(p) for p in pieces),F(0));V=volume(big);c=V/N;J=a+c
 delta=max(F(0),(R-1)/2-s);expected=((F(1,2)-s)**active-delta**active)*(1-s)**(n-active)
 ck('actual_receiver_volume_formula',a==expected>0)
 ck('rectangle_partition_volume',a==volume(own)-volume(intersection(own,big)))
 for i,p in enumerate(pieces):
  ck('receiver_piece_not_big',volume(intersection(p,big))==0)
  for pp in pieces[:i]:ck('receiver_pieces_disjoint',volume(intersection(p,pp))==0)
 ck('actual_kernel_FIRST',F(1)/1==1 and F(N)/N==1)
 ck('same_radius_actual_caps',1<=4 and F(N)<=4*R**n)
 X=N*a+V;W=F(N)
 ck('actual_occupation_ledger',X==N*J)
 ck('physical_atom_small_bound',a<=1)
 ck('physical_atom_big_bound',c<=1/q<=F(4,3))
 llo,lhi=logtwo_interval();H2lo=(1+n*llo)/4;H2hi=(1+n*lhi)/4
 ck('root_H_strictly_excludes_all_rows',J*J<H2lo)
 # Root choice lambda=d=1 is DECLARED representative, not a history-derived d.
 ungated=(N-1)*R**(-n)*a*c/J
 ck('ungated_column_occupation_bound',ungated<=J)
 sensitivities=[]
 for cc in [F(1,8),F(1,4),F(1,2)]:
  H2=cc*cc*n;gate=J*J>=H2;b=ungated if gate else F(0)
  first=1 if a*a>=H2 else R if gate else None
  if first is not None:
   ck('first_crossing_atom_bound',J<=F(4,3) or (J-F(4,3))**2<=H2)
   ck('crossing_test_only_low_H',H2<1)
   for theta in [F(1),F(1,2)]:
    init=F(0) if first==1 else theta*ungated
    ck('actual_whole_cross_initializer',init<=J<=F(4,3))
  for epsilon in [F(1,16),F(1,8),F(1,4)]:
   h=max(F(0),b-epsilon*J);D=h*h
   for theta in [F(1),F(1,2)]:
    Bnu=theta*N*b;res=max(F(0),Bnu-epsilon*X)
    ck('occupancy_priced_bound_squared',res*res<=4*D*W*(theta*W))
   sensitivities.append(dict(c_sqrt_n=str(cc),final_J_gate=gate,first_crossing_radius=str(first) if first is not None else None,epsilon=str(epsilon),b_column=str(b),h_column=str(h),D_epsilon=str(D),D_over_n=str(D/n)))
 return dict(n=n,active_coordinates=active,triangle_factors=k,source_boxes=N,source_side=str(s),source_mass_each='1',source_definition='Cartesian product of triangle{(-1/4,-1/4),(1/4,-1/4),(-1/4,1/4)}^k, remaining coordinates0; uniform side-s cube at each center.',receiver_definition='Own receiver mother boxes centered at twice active source coordinates, widths1/2-s active and1-s passive, with central big receiverbox removed; fixedR1. Centralbox widthsR-1/2-s active,R-s passive, fixedR.',representative_own_rectangle_pieces=len(pieces),R=str(R),q_big=str(q),own_receiver_volume=str(a),central_receiver_volume=str(V),own_receiver_occupation=str(a),central_receiver_occupation=str(c),J_final=str(J),X_actual=str(X),W_beta=str(W),ungated_b_for_geometry_only=str(ungated),root_H2_lower=str(H2lo),root_H2_upper=str(H2hi),root_BH='0',root_D_epsilon='0',relevance='FAIL: all original representative-root high-J gates empty. Ungated/sensitivity values are geometry diagnostics only, not remaining-hard-budget evidence.',sensitivity=sensitivities)
def main():
 rows=[];stages=[]
 for stage,ns in [('initial_geometry',[2,4]),('known_low_occupation_trap',[8,16]),('expanded_gate_only',[32,64])]:
  before=sum(counts.values());rows.extend(run(n) for n in ns);stages.append(dict(stage=stage,n=ns,checks=sum(counts.values())-before))
 result=dict(status='PASS',check_counts=dict(counts),total_checks=sum(counts.values()),stages=stages,models=rows,scope='True positive-L1 sources, actual endpoint kernel and Lebesgue receiver rectangle volumes, full dimensional bookkeeping. Declaredlambda=d1 root gate is empty in every model; this is an inadequacy diagnosis, not a high-J construction or general dimension budget.',history_recipe_status='History located a wide-window cluster lower-bound source but did not certify positive-dx high-J/q-band applicability; no such claim is made here.')
 Path(__file__).with_suffix('.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
 print(json.dumps({k:result[k] for k in ['status','check_counts','total_checks','stages']},sort_keys=True))
if __name__=='__main__':main()
