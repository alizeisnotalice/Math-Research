# R327 independent preauthor screen — hard shared-kernel prefix budgets

Ownership: only /tmp/r327_audit.md. No Git or other-author edits. No new R327 author proof was read. This is the actual special hard shared contract alpha=1,s=0,L=R,beta=f, q(u)=h_R(u)*f(u) in[q_-,lambda], finite original E and original inclusive ell_n. Any hard-source use of nu<=f is explicitly stated. This special contract is not automatically a native hard-winner/lower-band or old low-pe/history realization.

## 1. Correct full and prefix identities; a preliminary missing factor is corrected

The hard shared row is U_y(u)=1_E c_u(y)/(q(u)R(u)^n), so integral f(dy)U_y(u)=1_E(u) EXACTLY. Keep full original J,A and all original radius groups.

Define C_z(r)=integral f(dy)A_yz(r). By Tonelli,

 C_z(r)=integral_(E,R(u)<=r)c_u(z)du
       =integral_(R(u)<=r) q(u)R(u)^n U_z(u)du.

The factor R(u)^n is necessary at a prefix. A preliminary message incorrectly omitted it and was immediately withdrawn/corrected before writing this file. No dimension-free prefix bound C_z(r)<=lambda J_z(r) is certified. Correct bounds are

 q_- a^n J_z(r)<=C_z(r)<=lambda r^n J_z(r),
 C_z(r)<=r^n.

Only AFTER integrating the whole inclusive physical layer tail does that factor cancel:

 N_z=integral ell_n(dr)C_z(r)
    =integral_E c_u(z)R(u)^(-n)du
    =integral_E q(u)U_z(u)du,
 q_- J_z(b)<=N_z<=lambda J_z(b).

Thus bcost(z)=integral f(dy)ell_n(dr)1{J_y(r)>=H}(A-A²/J)<=N_z<=lambda J_z(b). Original high-J gates and squares only reduce the complete first moment. Terminal b and actual R=a,b are included by ell([R,b])=R^(-n).

For nu<=f the integrated first moment is exactly integral_E h_R*nu du<=integral_E q du<=X=lambda|E|. Therefore Bnu<=X and the same-source price integral lambda J_z(b)nu(dz)<=X. This is a valid receiver budget of coefficient1, not a small-epsilon absorption or source-root payment. In R326's priced-column language, h_epsilon<=max(0,1-epsilon)b gives only D_epsilon<=max(0,1-epsilon)^2 A_n²; it does not supply the missing n-polylog improvement. All source/outer coefficients remain explicit.

## 2. Exact prefix variance keeps both intrinsic blocks and prediction innovation

For one original y,z put F=A-A²/J, zero on J=0. At an actual radius atom, old mass J, old captured fraction p=A/J, new mass h, new captured fraction v, exact addition gives

 Delta F=h v(1-v)+[J h/(J+h)](v-p)².

For J=0 the initial contribution is h v(1-v). The hard shared Gram structure does not make that intrinsic same-radius block variance vanish: v is the conditional capture proportion within the WHOLE actual radius group, not one binary receiver. A group can contain many genuine receivers despite every pointwise c being binary.

On the continuous part of the actual J-radius measure, with v=dA/dJ and p=A/J,

 dF=[v(1-v)+(v-p)²]dJ.

This includes singular-continuous radius laws and does not assume differentiability in Lebesgue r. All terms are nonnegative. It follows that F is nondecreasing, but that fact is an exact potential representation, not a paid bound on its innovations.

For the full physical layer,

 integral ell_n(dr)F(r)=integral_[a,b] s^(-n)dF(s),

where F(a-)=0. The right side includes initialization at a and every actual radius atom. The left ell has its essential explicit terminal b atom. One may not drop the endpoint term or reinterpret radius atoms as old history deletion-time atoms.

For a high-J gate W(r)=1{J(r)>=H}F(r), W is nondecreasing, and the same identity holds with dW. At its first crossing tau it initializes with the ENTIRE original F(tau), not zero. A partial common-radius mass-order stop at H can isolate a paid warm initialization, but leaves the rest of the crossing block and all later intrinsic/prediction innovations. This is not a reason to omit them.

Under nu<=f and the stronger actual hard cap f(Q_R)=qR^n<=lambda R^n, the known common-mass initialization argument sharpens its coefficient: its stopped mass H has capture first moment<=lambda tau^n H, so its weighted initialization is<=lambda H per beta row. Thus B_H<=lambda H Wbeta+B_after with a precisely retained nonnegative rank-innovation remainder. If only the original4lambda cap is available the coefficient remains4lambda H. This only pays initialization, not the full layer sum; it is an adaptation of the existing initialization tool, not a new general root theorem.

## 3. A legitimate quantitative shared-source square lower bound

The hard A_yz(r) is a symmetric Gram kernel and A_yy=J_y. Positivity/PSD gives upper Cauchy bounds, not an automatic lower correlation estimate. A valid lower bound retaining actual shared-source geometry is obtained by local Cauchy:

 Q_z(r)=integral f(dy) A_yz(r)^2/J_y(r),
 M_z(r)=integral_{A_yz(r)>0} J_y(r)f(dy),
 Q_z(r)>=C_z(r)^2/M_z(r),

with zero convention if M=0 (then C=0). The corresponding bcost bound is

 bcost(z)<=integral ell_n(dr)[C_z(r)-C_z(r)^2/M_z(r)],

after dropping only positive high-J restrictions consistently if using an ungated full version; for the original high-J version restrict C and M to the SAME rows J_y(r)>=H before Cauchy. One must not subtract an ungated square from a gated positive moment. This distinction is essential.

A_yz>0 implies |y-z|infinity<=r. Therefore in the ungated case

 M_z(r)<=|E intersect{R<=r} intersect Q_(3r)(z)|.

Proof: restrict y to Q_(2r)(z), expand J, use f(Q_R)/(qR^n)=1, and note any receiver capturing such a y lies in Q_(3r)(z). The same halo bound applies to a row-gated M by positivity. It is an ACTUAL occupancy parameter, not a source density bound at a translated center. Its crude volume can be exponential in n; no root estimate is supplied.

If the SAME gated masses obey C/M>=1-delta on an authenticated subset, that subset's loss is<=delta C and can be charged through its actual first moment. All complementary domains and coefficients must be retained. This gives a quantified missing overlap/halo ratio, not a universal guarantee. More elaborate shared-Gram/projection bounds may strengthen this actual lower estimate but require an independent quantitative geometric proof; known source order alone does not provide it.

## 4. The general-soft gap remains explicit

With alpha=1,beta=f and actual full-soft q=P_s,L*f, FIRST can still be an equality, so the hard-source FIRST column C_z(r)=integralprefix c_z du persists. But q(u)R(u)^n U_z(u)=c_u(z) is special to s=0,L=R. General soft or unequal scales give a different source kernel, and original alpha may also remove rows. Thus the own-row price comparison bcost<=lambda J_z(b), the symmetric Gram identity and its special algebra cannot be silently transferred to current general Phi_next. A valid comparison needs its actual soft/hard likelihood or commutator cost and all original masks. Restarting alpha=1 is a separate authorized whole-entrance route, not a replacement negative square in a fixed residual.

## 5. Actual bounded local evidence and initial verdict

Actually executed a Fraction check with genuine constant-density tensor source-cell cube integrals at finitely many receiver quadrature points in n=1,2:6 actual source-response normalizations,87 prefix R^n-weight identities and29 full-layer cancellations. These are exact source geometry plus finite receiver quadrature diagnostics, not a claimed full continuous receiver/history construction. A further105 exact old/new radius-block tests verified the atom-variance formula including J=0 and mixed v. Total227 exact assertions PASS. Analytic Tonelli/Stieltjes/variance identities above supply the continuous dx statements.

Initial verdict: the exact hard-shared full-price identity and corrected prefix bounds PASS. Radius initialization, same-radius intrinsic variance and later innovations remain mandatory. There is no proven whole scale-sum root payment; only the stated paid initialization and conditional quantitative occupancy criterion. Await authors/numeric for bounded comparison; no broad counterexample search or prior history rerun was conducted.

## 6. Independent whole-physical-crossing receipt (before final author proof)

The new proposal pays the ENTIRE physical first crossing, rather than stopping a fraction of its mass at H. In the exact hardshared contract, for every radius atom r,

 Delta J_y(r)=integral_{E,R(u)=r} c_u(y)/(q(u)r^n)du
             <=|Q_r(y)|/(q_-r^n)<=1/q_-.

Let tau=inf{r:J_y(r)>=H} for a row that reaches H. Right-continuity makes the crossing attained; J(tau-)<=H (not necessarily strict), so J(tau)<=H+1/q_-. If no crossing there is no gated contribution. For F_y(r)=integral[A-A²/J]nu(dz), positivity gives F_y(tau)<=M_y(tau). Under nu<=f and actual h_R*f=q<=lambda,

 M_y(tau)<=integral_prefix U_y(u)lambda R(u)^n du
          <=lambda tau^n J_y(tau).

The exact high-J layer account is

 B_H=integral beta(dy){tau^(-n)F_y(tau)
                    +integral_(tau,b] r^(-n)dF_y(r)},

with zero contribution for non-crossing rows. Hence its WHOLE initialization is source-paid by

 (lambda H+lambda/q_-)Wbeta=(lambda H+4/3)Wbeta.

This includes the complete crossing radius atom, with no leftover crossing-block cost. All later continuous/singular-continuous and physical-radius-atom innovations remain in the positive remainder. tau=a includes the bottom initialization, tau=b includes the essential ell top atom and has no later remainder; a=b is consistent. This is an alternative to §2's common-mass-H initializer, not a fee to add to it.

The proof is specific to the original compact hard row L=R and the actual full hard response q. General soft rows lack the receiver support Q_r(y) needed for the1/q_- atom bound, and shared soft q need not give h_R*f<=lambda. Neither property is granted by renaming fields. These physical radius atoms are not original chronological I/J/D history atoms, and no payment of those old slots follows.

Actual local Fraction diagnostic:162 finite cumulative-radius accounts checked the first-crossing overshoot and exact inclusive-layer/Stieltjes sum, with zero increments, crossing/boundary equality, no-cross cases, and n=1,3. All PASS. These are algebra/prefix diagnostics, not full original history/source realizations. The whole-cube atom and actual-source cap arguments above are analytic. Together with the earlier227, reviewer has389 bounded exact checks; primary/author counts remain separate.

Verdict for this new candidate: PASS with the stated exact hard-shared/source-order contract, complete later innovation remainder, and no double use of the previous warm initializer. It pays a genuine whole initialization at root H but does not pay the full scale sum.

## 7. Independent periodic lower-halo validation bridge screen (before author main proof)

For a nonnegative Z^n-periodic locally integrable F of unit fundamental-cell mean, h_2*F=1 at every center: a side2 cube contains two full periods per coordinate; this does not require product F. A finite compact truncation f=F on E+Q_2 likewise gives h_2*f=1 on E. To avoid a circular/global-padding claim, either choose a bounded interior Omega first and E=Omega intersect{max_[a,b0]h_r*f>lambda}, with f=F on Omega+Q_2, or use a global truncation0<=f<=F, which guarantees h_2*f<=1 everywhere (equality need not hold near truncation boundaries). The weaker endpoint inequality suffices.

For a>0 and f in L1, (x,r)->h_r*f(x) is jointly continuous for r>=a. Dominated convergence at a convergent(x,r) uses the f-a.e. null cube boundary and the uniform a^(-n)f domination; this does not assume f continuous. The compact-r maximum is measurable/continuous. Finite E follows from compact source support, or from the integrable finite-band hard envelope. At x in the halo and lambda>1, some r<=b0<2 has response>lambda, while r=2 response<=1<lambda. Hence the compact nonempty lambda-root set exists; its largest root R(x) is measurable, e.g. by compact max/min tests on[t,2]. It is not an argmax selector. It gives true hardshared q=lambda and FIRST equality on E.

The resulting full own-source price satisfies0<=lambda J_z(b)<=A_n, b=2, A_n=1+nlog(2/a), and integral f lambda J= lambda|E|. With Lhalo=lambda|E|/Wf and h=lambda H, the exact bounded-price argument gives

 f{J_z(b)>=H} >=[(Lhalo-h)/(A_n-h)]Wf

whenever Lhalo>h (which itself forces A_n>h). The total Wf includes actual padding, so there is no hidden periodic-cell source normalization. The high-J mass conclusion alone does not prove a positive B_H or high-dimensional root-budget relevance. No actual halo with that large Lhalo is asserted by this conditional bridge, and no old low-pe/history, fullsoft FIRST, winning-scale or native-entry identity is supplied. This is a legitimate analytic validation procedure GIVEN a certified lower halo, not a new asymptotic lower construction.

## 8. Full auxiliary author proof comparison

Read /tmp/r327_aux.md in full after the independent screens. SHA25692b2fee24199e33dfc226e1dfbe86cb37bc3d1975ed712eaae82a2906f5aa549. PASS. The SAME hard shared compact kernel gives the1/q_- physical-atom bound; first-crossing left limit<=H, whole crossing source bill(lambda H+4/3)Wbeta, exact inclusive Stieltjes account and complete strictly-later innovation remainder are correct. The optional overshoot output charge is bounded byX_rho/(q_-H) using H beta(Y_H)<=integral beta J_b=|E|. It is an ALTERNATIVE overshoot bill, not another source credit.

The raw insertion is correctly conditional on an independently proved T<=4S(B+N)+2B_H with H=S/(2lambda); substituting gives(5S+8/3)Wbeta+4S Wnu+2I_H. Any later outer recovery multiplies every term. Changing H changes the high-J target and its low-J complement; it is not a free optimizer. R313/R317 partial-rank initialization and this whole physical initializer have different residuals and are not added.

The source Markov normalization is correctly repaired: T=A/J has real-source row mass V_y/J_y, where V_y=integral_prefix c_y du is weighted by qR^n, not by q alone. P=A beta/V is Markov, reversible for beta(dy)V_y(r), with changing prefix measure. A fixed-prior martingale/square-function estimate cannot be inferred from that name. The full allscale first moment<=X_rho is only an output budget. No general-soft or chronological-atom payment is claimed.

The embedded306 diagnostics use actual full beta=f, not the earlier central f|D prior, and a finite periodic positive-L1 source with real dx integration. Its low-hard-band/history limitations are explicit. The positive source interval with V/J!=1 certifies the normalization distinction; its finite computations do not establish a root bound for later innovation.

## 9. Actual growing-dimensional numeric code and scope review

Read /tmp/r327_numeric.py and /tmp/r327_numeric.md fully; no full replay was performed. Triangle tensor geometry proves whole matching source-box capture and foreign source mass exclusion. Contact at a cube boundary is a source/receiver null set and causes no mass error. Passive dimensions retain their complete volume factors. Every source has mass1, actual density s^(-n), rather than an unweighted point atom. Own mother receiver boxes are disjoint; removing the central box via disjoint rectangle subtraction leaves a single-valued true radius field and preserves source incidences.

The overlap volume formula is correct: active intersection width is[(R-1)/2-s]_+, passive intersection is the whole own width1-s. Thus a is exactly the own mother volume minus the central intersection, c=centralvolume/N, and each source row has J=a+c. The binary-search upper rational radius certifies q=N/R^n in[3/4,1]. Own q=1 and actual FIRST equality follow from exact whole-source capture, not sampled densities. Selected source caps hold; hard-winner/all-radius ceilings are not asserted.

At the first own radius the Gram matrix is diagonal and its variance is zero. After the central radius, diagonal A=J and off-diagonal A=c, so b_ungated=(N-1)R^(-n)ac/(a+c), including the complete terminal-layer tail. Root-H comparisons use an exact rational log2 enclosure; all tested genuine source rows fail that representative gate. Hence the actual root-gated B_H and priced-tail D are ZERO in these examples. This is a failed-relevance diagnostic, not high-J or general-core evidence. The four low-H sensitivity cases illustrate only the limited initializer receipt and retain the full receiver volume; they are not a large-H test. Discrete D=h² uses one-sided cost ties correctly because every source column has the same h.

The report's396 exact checks/stages106+115+175 are consistent. It explicitly avoids a full-original-history or exponent claim. Isolated finite geometry plus a declared d=1 does not certify an original-history normalization. The future periodic bridge requires independently certified halo mass; this numeric packet does not supply it.

Status before main integration: auxiliary and numeric proofs PASS at bounded scope. The general post-crossing innovation and the general-soft/shared-source translation remain unpaid.

## 10. Final periodic author proof and integration comparison

Read /tmp/r327_core.md (SHA256245b0b3a96ed843bc9beab0f40966a83a9c02e92c33cd51e886d367f4df69a9d) completely, after the independent bridge screen. PASS: periodic F is locally L1 with unit-cell mass1, exact integer-side average1, compact-padding source mass(2M)^n and true receiver measure(2M-2)^n theta. The largest >=lambda radius is a compact nonempty measurable selector whose final value is exactly lambda; it is a new hard threshold selector, not an old winner or fullsoft FIRST selector. The exact weighted source moment and bounded price force the displayed high-J mass only when the stated actual Lhalo>lambda H has been certified. A positive theta alone does not imply that root-threshold condition.

The explicit1D periodic primitive has correct negative-argument floor and all interval breakpoints. On a fixed r segment, r(q_r-lambda) is affine, so endpoint tests and exact linear root interpolation cover all roots; taking the largest is valid. The fixed-radius cell measure3/10 is a rigorous LOWER bound for the full radius-max halo, not its equality. M=3 gives Lhalo>=6/25 and certifies positive high-J source mass at the separately stated H=1/10. It does not give a high-dimensional representative-root example or a positive full-square cost. The original full first moment Z=lambda J=N_0 and its deficit decomposition preserve the old low-J column and high-J square; neither deficit has been paid generically.

Read final combined.md fully, including both corrected passages. The periodic assumption is now stated as unit-cell-integrable/local-L1 (not nonzero periodic global L1), and996 counted checks are not called independent inputs. PASS for all formulas and scope: whole physical initializer replaces earlier partial initializer, later innovation I_H remains; no crossing block is omitted. Optional overshoot receiver charge and source charge are alternatives. Conditional target insertion(5S+8/3)Wbeta+4S Wnu+2I_H multiplies every later outer factor and requires its separately proved entrance/H. The pure source choice adds ZERO new epsilon; the old1/256 is unchanged and not globally absorbed.

The positive periodic bridge and tensor gate-failure diagnostics are kept distinct. The diagnostic all-zero high-J fields are not booked as new high-J/core evidence. General soft/mismatched/alpha/history/native mappings remain open. The compact hard shared physical atoms do not settle chronological I/J/D initial/deletion/future-source obligations.

Inspected source_recipe.md as a bounded supplied normalization/provenance lookup; the entire proposed asymptotic lower-bound proof was not independently re-audited. It does not supply the missing high-dimensional halo certificate. Its period-one/side-length/mean normalization is consistent with the new bridge, and the bridge has its own self-contained proof.

## 11. Evidence count and frozen bindings

Primary's actual log reports996 counted exact checks=396 growing-dimensional geometry/gate diagnostics+306 actual continuous1D crossing/innovation identities+87 padding/high-mass algebra+207 selector cases(160 integer-side averages,47 exact roots). The fixed-radius3/10 level measure is a separate exact assertion, disclosed separately. No reviewer replay of those scripts is claimed; reviewer's own227+162=389 bounded exact checks above remain separate. Finite tests do not certify the root order of I_H, general high-dimensional halo measure or whole weak-type closure.

Final SHA256 bindings:

- /Users/zhengzhihao/Desktop/T/output/centered_cube_round327_20261018_final_checkpoint/bridge_checks.py: e1a5163a04a24a63c0021ecdc2e0f28e358f79c945f4611e042bc086ed36523f

- /Users/zhengzhihao/Desktop/T/output/centered_cube_round327_20261018_final_checkpoint/combined.md: 611b9bc843244fef22746b2e7027fd153cb86ee5e949228e1f014aa78c3d8565

- /Users/zhengzhihao/Desktop/T/output/centered_cube_round327_20261018_final_checkpoint/core.md: 245b0b3a96ed843bc9beab0f40966a83a9c02e92c33cd51e886d367f4df69a9d

- /Users/zhengzhihao/Desktop/T/output/centered_cube_round327_20261018_final_checkpoint/geometry.md: 92b2fee24199e33dfc226e1dfbe86cb37bc3d1975ed712eaae82a2906f5aa549

- /Users/zhengzhihao/Desktop/T/output/centered_cube_round327_20261018_final_checkpoint/geometry_checks.py: 0714610b7e71a190eea1a25090c2f0f41dcbd38fd72ea0f78795cfe2fa98993d

- /Users/zhengzhihao/Desktop/T/output/centered_cube_round327_20261018_final_checkpoint/numeric.json: 9d5565b5f739289e4c2ba51bc5b35be731d7c5c1a36546dc288759bb2367157a

- /Users/zhengzhihao/Desktop/T/output/centered_cube_round327_20261018_final_checkpoint/numeric.py: d0ae0eae494a8c2921d3f40cd14ae7f400f253adaa96e23fd2ff9eff0e69eabc

- /Users/zhengzhihao/Desktop/T/output/centered_cube_round327_20261018_final_checkpoint/numeric_notes.md: fa47f2f1b200e281b0ca334fc01ff739fb8b9bcea1942d74b44b284f1045c46a

- /Users/zhengzhihao/Desktop/T/output/centered_cube_round327_20261018_final_checkpoint/numeric_summary.json: 75a29ab64bfc5cf57ddaceab4d7f9ed9fedec7de0fdb55a1aaecc67e39477f57

- /Users/zhengzhihao/Desktop/T/output/centered_cube_round327_20261018_final_checkpoint/primary_checks.log: 9551a770420a6d29f32dd013f38873b3a48da597dd3da7c9274a7fe8f939b31e

- /Users/zhengzhihao/Desktop/T/output/centered_cube_round327_20261018_final_checkpoint/selector_checks.py: 6e0f7d3e140acb2106428e25de63b17f58111fe926a0a98ea9e38689443b5774

- /Users/zhengzhihao/Desktop/T/output/centered_cube_round327_20261018_final_checkpoint/source_recipe.md: 28280bb785bad1c1ab57bf422961795dfd5e5d56a84fa706abca15f5b1b7de70

Primary-owned later TeX metadata ONLY: /Users/zhengzhihao/Desktop/T/output/centered_cube_round327_20261018_final_checkpoint/research.tex: 4eb54d6dd3d44a91f353a48fd110359cf4f0950e89486be913150f4fd66d304d. It was not read line-by-line or compiled by this reviewer.


FINAL VERDICT: PASS for the corrected hard-shared normalization, whole physical-radius crossing source payment, atom-correct post-crossing account and conditional periodic validation bridge, together with the explicitly failed-root-gate numeric scope and final integration. No generally root-priced later innovation, generalsoft Phi_next budget, historical/native entrance, allscale/outer/small-dimension closure or payment of chronological atoms is certified. Freeze the bound mathematics/integration bytes; subsequent changes require an explicit amended receipt.
