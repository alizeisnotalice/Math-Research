from fractions import Fraction as F
A=F(25,24); B=F(11,8); lam=F(6,5)
def primitive(t):
    k=t.numerator//t.denominator
    return F(k)+4*min(t-k,F(1,4))
def q(x,r):
    return (primitive(x+r/2)-primitive(x-r/2))/r
def breaks_r(x,lo,hi):
    s={lo,hi}
    for k in range(-3,5):
        for c in (F(k),F(k)+F(1,4)):
            r=2*abs(x-c)
            if lo<r<hi:s.add(r)
    return sorted(s)
count=0
for i in range(160):
    x=F(i,160)
    assert q(x,F(2))==1
    if max(q(x,r) for r in breaks_r(x,A,B))<=lam:continue
    cuts=breaks_r(x,A,F(2)); roots=[]
    for lo,hi in zip(cuts,cuts[1:]):
        fl=(q(x,lo)-lam)*lo; fh=(q(x,hi)-lam)*hi
        if fl==0:roots.append(lo)
        if fh==0:roots.append(hi)
        if fl*fh<0:roots.append(lo-fl*(hi-lo)/(fh-fl))
    R=max(roots)
    assert A<=R<2 and q(x,R)==lam
    count+=1
cuts={F(0),F(1)}
for k in range(-3,5):
    for c in (F(k),F(k)+F(1,4)):
        for x in (c-B/2,c+B/2):
            if 0<x<1:cuts.add(x)
cuts=sorted(cuts); theta=F(0)
for lo,hi in zip(cuts,cuts[1:]):
    fl=q(lo,B)-lam; fh=q(hi,B)-lam
    if fl>=0 and fh>=0:
        if fl>0 or fh>0:theta+=hi-lo
    elif fl*fh<0:
        z=lo-fl*(hi-lo)/(fh-fl)
        theta+=(z-lo if fl>0 else hi-z)
assert count==47 and theta==F(3,10)
print('q2 checks',160,'exact largest roots',count,
      'fixed-radius level measure',theta,
      'M3 ratio lower bound',lam*theta*F(2,3))
