# R327 bounded lookup: candidate high-J geometry

## Located existing lower-bound recipe

The strongest directly relevant primary recipe found is `Desktop/T/output/cube_general_20261003/inputs/centered_cube_wide_window_cluster_lower_bound_20261001(1).txt` (SHA256 `1edcae8168482f25991581deceb58dcdf59a807be84bc3464cce75f9530b8243`; also indexed in `cube_general_20261003/inputs/manifest.json`). It is a complete centered, axis-parallel cube weak-type lower-bound construction, but it is **not already a high-J fixture**.

- Lines 64–95 define the maximal operator, scale interval (I=[25/24,11/8]), and asymptotic parameters. Lines 97–183 give a period-one 24-step profile (h), with ∫ h=0, ∫ h²=49, and its explicitly tabulated autocovariance/platform.
- Lines 202–249 construct jittered atomic probability μ_U on a period-one grid, its exact interval-average fluctuation (e_{L,U}), and mixed source density ρ_{U,K}=K/(K+20)μ_U +(20+h/\sqrt{3D})/(K+20)dx. This is the closest existing candidate for a fixed-prior spatial source recipe.
- Lines 278–296 map scales into ξ(L) and place a finite mesh; lines 516–550 give the finite cluster recipe, and lines 553–612 turn the finite maxima into a smoothed, truncated (L^1) input (f_n). The measurable receiver region used for the weak-type lower bound is obtained from high values at that finite set of scales, then replicated periodically and truncated.
- Lines 41–61 explicitly label the result as an asymptotic weak-type lower bound and state that independent mathematical review remains; the numerical experiments are diagnostics, not a certified fixture.

## Requested J_y/q-band check

I did not locate a statement or computed certificate in this construction for the requested
\[
J_y=\int_E \frac{c_{R(u)}(y)}{q(u)R(u)^n}\,du,
\qquad \beta=f,\quad q=h_{R(u)}*f\in[.75,1],
\]
with positive Lebesgue measure of receivers satisfying (J_y\gtrsim\sqrt n) (or any stated high-J interval), common β=f, α=1, (L=R), (s=0), and octave radii. The located lower-bound construction uses a continuum of radii in (I=[25/24,11/8]), not a certified dyadic/octave menu, and selects receivers by high product averages at a finite ξ-net. Its proofs do not identify this receiver set with E for the requested J-integral or establish the q band on all contributing receivers.

Consequently this is a candidate recipe that a numerical agent can instantiate, not evidence that the high-J qualification is met. In particular, the profile's source maximum (\|h\|_\infty\) or positive lower bound on its 24 step-values does not imply (q=h_R*f\le1) (or ≤λ) pointwise. No J_y value or positive-measure high-J set can be certified from the located document without a fresh calculation of actual E, selector R, q, and the integral above. This report makes no such calculation and no new lower-bound claim.

Bounded search used the indexed wide-window lower-bound text plus targeted `rg` over relevant lower-bound/capture files in the repo and `cube_general_20261003`; it did not inspect the full historical archive.

## Follow-up: period, side convention, and mean normalization

- Period is exactly one: the source uses Τ with 24-step profile (h) and explicitly says “再作一周期延拓” at lines 118–124; the jittered atomic law is “一周期延拓” at lines 204–209. Its one-period mean profile is ∫_Τ h=0 (line 139).
- The weak-type maximal operator uses **side length** (L): (Q_L(x)=x+[-L/2,L/2]^n), with average (L^{-n}\int_{Q_L(x)}|f|), lines 65–71. The one-coordinate centered interval average is likewise length (L): (b_L(x)=[H(x+L/2)-H(x-L/2)]/L), lines 167–170; the atom fluctuation uses endpoints (x\pm L/2), lines 217–221.
- The random one-dimensional periodic probability is ρ_{U,K}=\frac K{K+20}\mu_U+\frac{20+h/\sqrt{3D}}{K+20}dx, lines 238–245. Since μ_U is a probability per period, ∫_Τμ_U=1; since ∫_Τ h=0 and ∫_Τ 20dx=20, this density integrates to ((K+20)/(K+20)=1) on the period. Smoothing preserves each period's mass 1 and (g_n=\prod_i\rho_i^\eta), lines 581–588; truncation is (f_n=g_n1_{[-Q_n,Q_n]^n}), lines 604–612.
- Therefore, for the untruncated periodic product (g_n), every centered cube of integer side (L) has average exactly 1 at every center: each coordinate interval covers an integer number of periods, and the product separates. In particular side (L=2) gives 1. For truncated (f_n), the same is exact at centers whose cube is contained in the truncation box; for the report's scale window (L\le11/8), the source explicitly retains all candidate cubes on ([-Q_n+1,Q_n-1]^n), lines 604–611. This normalization alone only gives the value at that fixed integer side; it does not establish the existence, location, or positive measure of a largest-root selector for λ>1, nor any J_y lower bound.
