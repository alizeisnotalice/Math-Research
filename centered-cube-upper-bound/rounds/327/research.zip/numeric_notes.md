# R327 actual-volume construction: root-gate inadequacy certificate

The bounded script passes396 exact Fraction checks in three stages: n2,4 geometry106; n8,16 low-occupation trap115; n32,64 gate-only expansion175. The substantive result is NEGATIVE RELEVANCE: every source row is below the declared representative root threshold. Thus original gated B_H and D_epsilon are exactly zero. Ungated/sensitivity data must not be cited as evidence about a remaining high-J budget.

## Actual growing-dimensional L1 geometry

Let k=max(1,log2(n)-1) for the listed powers of2, with2k active coordinates. Source centers are the Cartesian product of the triangle{(-1/4,-1/4),(1/4,-1/4),(-1/4,1/4)}^k, remaining coordinates0. There are N=3^k disjoint uniform source cubes, each side s=1/(100n) and mass1. Take beta=f and nu=theta beta, theta=1 or1/2. This is a finite positive-L1 input, not source atoms; all n-dimensional source volumes are retained.

For each source label, its R1 receiver mother box is centered at twice the active source coordinates, active widths1/2-s, passive widths1-s. Exact coordinate extremes prove it captures the complete matching source cube and excludes every other source cube. The tensor product argument is checked on every two-coordinate triangle incidence, not postulated as an arbitrary matrix.

Choose R as the smallest multiple of2^-16 at least N^(1/n), certified by integer powers. The central R receiver box has active widths R-1/2-s and passive widths R-s, so it captures ALL complete source boxes. Its actual q=N/R^n lies in[3/4,1]. On own receivers q=1. With s0,L=R,alpha1,U=C/M, the actual FIRST is exactly rho=1_E. Selected-radius nu hard caps hold on every receiver interior point. No true hard-winner or all-radius cap is claimed.

To make a genuine receiver field, remove the central box from each own receiver mother box. The script constructs the resulting disjoint axis rectangles and checks their volumes and intersections. No source incidence changes under this restriction. Other own mother boxes are already disjoint by an active coordinate. Define

    a=[(1/2-s)^(2k)-((R-1)/2-s)_+^(2k)](1-s)^(n-2k),
    c=|E_central|/N.

These are actual dx occupation contributions; they are not freely chosen weights. Every source row has J(1)=a,J(R)=a+c. The active coordinate count grows from2 to10. Remaining coordinates are passive but their full volume factors are retained; this is not a claim of a full-dimensional lower-bound mechanism.

## Root relevance gate comes FIRST

Declare lambda=d=1,a1,b2 and test H²=(1+n log2)/4. This is a representative original-form root threshold; d=1 is NOT asserted to be the actual complete-history normalization. The script encloses log2 with32 exact rational atanh-series terms and a rational remainder. In every case,

    (a+c)² < lower_bound(H²).

Hence no prefix reaches H. Both the original full-square column b and h=(b-epsilon J)_+ vanish, so B_H=D_epsilon=D_epsilon/n=0 for epsilon1/16,1/8,1/4. The matched hard-side K is the same row occupation, so this does not furnish a double-high construction either.

|n|N=W_beta|active coordinates|actual X=|E||J_final|root B_H,D_epsilon|
|---|---:|---:|---:|---:|---:|
|2|3|2|1.849717316|.616572439|0,0|
|4|3|2|1.808743754|.602914585|0,0|
|8|9|4|1.866252865|.207361429|0,0|
|16|27|6|1.579167062|.058487669|0,0|
|32|81|8|1.135423261|.014017571|0,0|
|64|243|10|.752605285|.003097141|0,0|

Decimals describe exact stored fractions. The receiver measure itself remains substantial over this bounded list, but its source-normalized row occupation becomes too small. Ignoring dx and assigning arbitrary receiver weights would conceal this failure.

## Limited sensitivity and crossing checks

For H=c0 sqrt(n), c0=1/8,1/4,1/2, gates are tested by exact squared comparisons. Only four n2/4 parameter cases cross, and all have H<1. Their actual whole crossing initializer is computed from the real Gram incidences, with nu=beta and beta/2. It is <=J<=4/3, hence <=H+4/3. Physical atom occupations separately satisfy a<=1 and c<=1/q<=4/3. These eight actual initializer checks illustrate the crossing receipt only in this limited low-H range; they do not test a large-H crossing or prove its general theorem.

For geometry comparison ONLY, the ungated full column is

    b_ungated=(N-1)R^-n a c/(a+c).

Indeed diagonal A=J gives zero variance, off-diagonal A=c, and the ell tail from R through b2 is R^-n INCLUDING the terminal atom. The first-scale potential is zero. In each sensitivity experiment either this column survives the high-J gate or it is zero. All source columns are equal, so the exact occupancy-priced functional is D_epsilon=h² (the upper-tail beta mass is all N). The source-priced inequality is checked without floating square roots by squaring the nonnegative residual, for both theta choices. It is NOT presented as new remaining-hard-budget evidence.

## What is still needed

The required next construction is a shared actual input f and a positive-Lebesgue receiver field with a certified q band AND genuinely high J at the representative root threshold. The history lookup found a finite-cluster/wide-window lower-bound recipe, but did not certify the needed q-band/high-J receiver occupation bridge. This note makes no usable-high-J claim from that material and does not expand into another toy family.

Scope: true L1 sources, actual s0 kernel, exact q/FIRST/selected caps and receiver volumes, but no original full-history/low-pe qualification, all-radius hard ceiling, hard-winner selection or complete weak-event coverage. No exponent is fitted from the bounded dimension list.

Reproduce:

```
/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 /tmp/r327_numeric.py
```

The self-contained standard-library script writes exact deterministic `/tmp/r327_numeric.json`. All decisions use rational/integer arithmetic.
