from fractions import Fraction as F
ct=dict(actual_markov_mass=0,diagonal=0,atom_cap=0,innovation=0,
        source_variance_monotone=0,crossing=0,layer_identity=0,
        entry_fee=0,never_cross=0)
Eparts=[(F(-1),F(0),F(1)),(F(0),F(1),F(3,2))]
f=[]
for k in range(-3,5):
    shift=F(k,2)
    f.extend([(F(-1,2)+shift,F(-3,8)+shift,F(3)),
              (F(-3,8)+shift,F(-1,4)+shift,F(1))])
nu=[(F(-1,2),F(-3,8),F(3,2)),(F(-3,8),F(-1,4),F(1,2))]
def length(lo,hi): return max(F(0),hi-lo)
def interval(y,R,part):
    return max(part[0],y-R/2),min(part[1],y+R/2)
def A(y,z,prefix):
    out=F(0)
    for l,h,R in Eparts[:prefix]:
        out+=length(max(l,y-R/2,z-R/2),min(h,y+R/2,z+R/2))/R
    return out
for y in [F(-1,2)+F(k,32) for k in range(9)]:
    J=[A(y,y,i) for i in (1,2)]
    V=[sum(length(*interval(y,R,(l,h)))
           for l,h,R in Eparts[:i]) for i in (1,2)]
    for pre in (1,2):
        cuts=set()
        for l,h,R in Eparts[:pre]:
            lo,hi=interval(y,R,(l,h))
            cuts.update((lo-R/2,lo+R/2,hi-R/2,hi+R/2))
        mass=F(0)
        for l,h,d in f:
            knots=sorted({l,h}|{z for z in cuts if l<z<h})
            mass+=sum(d*(b-a)*(A(y,a,pre)+A(y,b,pre))/2
                      for a,b in zip(knots,knots[1:]))
        assert mass==V[pre-1]; ct['actual_markov_mass']+=1
        assert A(y,y,pre)==J[pre-1]; ct['diagonal']+=1
    assert V[1]==F(5,4) and V[1]/J[1]!=1
    ct['actual_markov_mass']+=1
    for j in (J[0],J[1]-J[0]):
        assert 0<=j<=1<=F(4,3); ct['atom_cap']+=1
    for z in [F(-1,2)+F(k,32) for k in range(9)]:
        a1,a2=A(y,z,1),A(y,z,2)
        j=J[1]-J[0]; v=(a2-a1)/j; p=a1/J[0]
        F1=a1-a1*a1/J[0]; F2=a2-a2*a2/J[1]
        assert F2-F1==j*v*(1-v)+J[0]*j/J[1]*(v-p)**2>=0
        ct['innovation']+=1
    Fs=[]
    for pre in (1,2):
        moments=[F(0),F(0)]
        for l,h,d in nu:
            knots=sorted({l,h}|({y} if l<y<h else set()))
            for a,b in zip(knots,knots[1:]):
                av,bv=A(y,a,pre),A(y,b,pre)
                moments[0]+=d*(b-a)*(av+bv)/2
                moments[1]+=d*(b-a)*(av*av+av*bv+bv*bv)/3
        Fs.append(moments[0]-moments[1]/J[pre-1])
    assert 0<=Fs[0]<=Fs[1]; ct['source_variance_monotone']+=1
    for H in (F(1,8),F(3,4),J[0],J[0]+F(1,100),
              J[1],J[1]+F(1,100),F(2)):
        actual=(F(1,3)*Fs[0] if J[0]>=H else 0)
        actual+=(F(2,3)*Fs[1] if J[1]>=H else 0)
        if J[1]<H:
            assert actual==0; ct['never_cross']+=1; continue
        k=0 if J[0]>=H else 1; t=(F(1),F(3,2))[k]
        assert J[k]<=H+F(4,3); ct['crossing']+=1
        entry=Fs[k]/t
        tail=F(2,3)*(Fs[1]-Fs[0]) if k==0 else F(0)
        assert actual==entry+tail; ct['layer_identity']+=1
        assert entry<=H+F(4,3); ct['entry_fee']+=1
print('PASS',ct,'total',sum(ct.values()))
