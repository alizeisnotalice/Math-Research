# R327 — hard-matched physical-radius crossing is source-paid; the later innovation is not

**Proved new receipt.** In the exact hard shared-kernel slot `α=1,s=0,L=R,β=f,q=h_R*f∈[q_-,λ]`, `q_-=3λ/4`, every physical-radius atom of an original row has mass at most `1/q_-`. Therefore the ENTIRE first atom crossing `J≥H` is paid together with its old prefix:

\[
 B_H\le(\lambda H+4/3)W_\beta+\mathcal I_H.              \tag{0}
\]

Here `𝓘_H` is the nonnegative original variance innovation strictly AFTER the first crossing radius; no fraction of the crossing atom is left in it. An alternative overshoot payment is `X_ρ/(q_-H)`. This is a physical-radius statement, not a payment of chronological/source-history initialization or deletion terms. No general root estimate for `𝓘_H` is proved.

The exact Stieltjes innovation algebra reuses the R313/R317 variance identity and is not claimed as new. The new input is the dimension-free physical-atom cap from the hard kernel, and its resulting full-crossing payment. A proposed source Markov interpretation is also corrected below.

## 1. Exact matched contract and the source normalization

Let `f≥0∈L¹`, `β(dy)=f(y)dy`, `0≤ν≤β`, `E` have finite Lebesgue measure, and fix the ORIGINAL actual measurable `R:E→[a,b]`, `0<a≤b<∞`. On `E` assume the SAME hard response

\[
 q(u)=R(u)^{-n}f(Q_{R(u)}(u))\in[q_-,\lambda],
 \quad U_y(u)=\frac{1_E(u)1_{Q_{R(u)}(u)}(y)}{q(u)R(u)^n}.
\]

Thus actual FIRST is equality:

\[
 \rho(u)=\int U_y(u)\beta(dy)=1_E(u),\qquad
 X_\rho=\lambda|E|,\qquad\int J_y(b)\beta(dy)=|E|.       \tag{1}
\]

Keep the full original prefixes

\[
 J_y(r)=\int_{E,R(u)\le r}U_y(u)du,\quad
 A_{yz}(r)=\int_{E,R(u)\le r}U_y(u)c_u(z)du,
 \quad c_u(z)=1_{Q_{R(u)}(u)}(z),
\]
\[
 \ell_n=b^{-n}\delta_b+nr^{-n-1}1_{[a,b]}dr,
 \qquad\ell_n([R,b])=R^{-n}.                            \tag{2}
\]

These rows are finite, for instance `J_y(b)≤|E|/(q_-a^n)`. All existing target/endpoint qualifications remain original; the theorem concerns the full-square `B_H` interface and never rebuilds `J` from a restricted endpoint.

Here `A` is a symmetric positive Gram kernel and `A_yy=J_y`. However `T_yz=A_yz/J_y` is NOT generally a source Markov kernel with respect to the real source `β`. Indeed

\[
 \int A_{yz}(r)\beta(dz)
 =V_y(r):=\int_{E,R(u)\le r}c_u(y)du,\qquad
 \int T_{yz}\beta(dz)=V_y(r)/J_y(r).                     \tag{3}
\]

The ratio in (3) is the row's weighted average of `q(u)R(u)^n`; it lies between `q_-a^n` and `λr^n`, rather than equalling one. The legitimate source Markov kernel is

\[
 P_r(y,dz)=A_{yz}(r)\beta(dz)/V_y(r)\quad(V_y(r)>0).
\]

It is reversible for `β(dy)V_y(r)`; zero-volume rows carry zero reversible measure. Both the reversible measure and the factor `V_y/J_y` change with the prefix. For a newly added block, `P_r` is the `V_y`-weighted mixture of the old source law and the block's source law, not a justified fixed-prior martingale. No spectral or square-function estimate follows from calling `T` Markov.

The actual shared source does remove a scale factor from the FULL first moment:

\[
 \int\beta(dy)\nu(dz)\ell_n(dr)A_{yz}(r)
 =\int_E h_{R(u)}*\nu(u)du
 \le\int_Eq(u)du\le X_\rho.                            \tag{4}
\]

This is an output budget, not a source-root bill or a free absorbable small multiple of `X_ρ`.

## 2. Dimension-free atom cap and measurable full crossing

For any fixed physical radius `t∈[a,b]`,

\[
 \Delta J_y(t)=\int_{E,R(u)=t}
              \frac{c_u(y)}{q(u)t^n}du
 \le\frac{|E\cap\{R=t\}\cap Q_t(y)|}{q_-t^n}
 \le1/q_-.                                             \tag{5}
\]

This uses the true compact hard-kernel support; no source density cap is involved. It is not automatically a dimension-free bound for a general shared-softness selector.

Let `Y_H={y:J_y(b)≥H}`, where `H>0` is the threshold from the actual chosen ledger. For `y∈Y_H` define

\[
 \tau_y=\inf\{r\in[a,b]:J_y(r)\ge H\}.
\]

The inclusive CDF is increasing and right-continuous, so `τ_y∈[a,b]`, `J_y(τ_y)≥H`, and `J_y(τ_y−)≤H`. The latter need not be strict. The crossing and its left limit are measurable, using rational radii and the endpoint convention `J_y(a−)=0`. Thus

\[
 0\le o_y:=J_y(\tau_y)-H\le\Delta J_y(\tau_y)\le1/q_-.
                                                               \tag{6}
\]

If there is no crossing atom, `o_y=0` and `J_y(τ_y)=H`. If the first crossing is at `a`, its entire `R=a` receiver block is included. If it is at `b`, its entire `R=b` block is included. Rows outside `Y_H` contribute zero to `B_H`. This does not fractionally sort or discard an original radius atom.

## 3. Exact Stieltjes settlement, including every atom

For each row set

\[
 F_y(r)=\int\left[A_{yz}(r)-A_{yz}(r)^2/J_y(r)\right]\nu(dz),
\]

with zero when `J_y(r)=0`, and `F_y(a−)=0`. It is an increasing right-continuous finite function. To check monotonicity and the exact jumps, add one physical-radius block with mass `h=ΔJ`, source-specific captured fraction `v_z=ΔA_z/h`, and old `j=J(t−)`, `p_z=A_z(t−)/j`. Then

\[
 \Delta F_y(t)=\int\left[
 h v_z(1-v_z)+\frac{jh}{j+h}(v_z-p_z)^2\right]\nu(dz).   \tag{7}
\]

The second term is zero if the old row is empty; a zero-mass block contributes zero. The first term is the real within-block variance and must not be dropped. On the continuous part of the actual radius pushforward, write `v_z=dA_z^c/dJ_y^c`. The Stieltjes chain rule gives

\[
 dF_y^c=\int[v_z(1-v_z)+(v_z-p_z)^2]\nu(dz)\,dJ_y^c.    \tag{8}
\]

This is a running-average innovation identity, not a martingale assumption. Near an initially empty continuous row one may start at positive `J` and pass to the limit, using `F_y≤J_yWν`; no singular initial term is lost.

Positive Stieltjes Fubini and the inclusive tail (2) give, for every crossing row,

\[
 \int\ell_n(dr)1_{J_y(r)\ge H}F_y(r)
 =\tau_y^{-n}F_y(\tau_y)
       +\int_{(\tau_y,b]}r^{-n}dF_y(r).                 \tag{9}
\]

The physical crossing atom is wholly inside the first term. The second contains the complete later jumps (7), including a jump at `b` if `τ_y<b`. If `τ_y=b`, it is empty. The measure `ell_n` has only its explicit terminal `b` atom; a physical `R=a` atom instead appears in `dF_y`, and is priced correctly by the inclusive tail. These two different kinds of atoms are not conflated.

Define

\[
 \mathcal E_H=\int_{Y_H}\tau_y^{-n}F_y(\tau_y)\beta(dy),
 \qquad \mathcal I_H=\int_{Y_H}\beta(dy)
                     \int_{(\tau_y,b]}r^{-n}dF_y(r).
\]

Then the original full-square loss satisfies the exact positive identity

\[
 \boxed{\quad B_H=\mathcal E_H+\mathcal I_H.\quad}        \tag{10}
\]

## 4. Source-once payment of the entire physical crossing

By `ν≤f` and the SAME actual hard response,

\[
 F_y(r)\le\int A_{yz}(r)\nu(dz)
 =\int_{E,R(u)\le r}U_y(u)\nu(Q_{R(u)}(u))du
 \le V_y(r)\le\lambda r^nJ_y(r).                        \tag{11}
\]

Combining (6), (9), (11),

\[
 \mathcal E_H\le\lambda H\beta(Y_H)
                 +\lambda\int_{Y_H}o_y\beta(dy)
 \le(\lambda H+\lambda/q_-)W_\beta
 =(\lambda H+4/3)W_\beta.                               \tag{12}
\]

Only one original source mass is charged. All physical scale atoms are covered, irrespective of their number or locations. For rows with continuous crossings the fee is only `λH` per unit source mass. With only an actual `ν(Q_R)≤4λR^n` cap, (11) would instead have `4λ`, and the corresponding coefficient would be `4λ(H+1/q_-)`; the sharper (12) uses the exact matched contract.

There is a useful OUTPUT alternative for the overshoot. From (1), `Hβ(Y_H)≤|E|`. Thus

\[
 \lambda\int_{Y_H}o_y\beta(dy)
 \le\min\left\{\frac\lambda{q_-}W_\beta,
                     \frac{X_\rho}{q_-H}\right\}.
\]

Consequently

\[
 \boxed{\ B_H\le\lambda H W_\beta+
    \min\left\{\frac43W_\beta,\frac{X_\rho}{q_-H}\right\}
    +\mathcal I_H.\ }                                  \tag{13}
\]

For an admissible common choice `H=√A_n/λ`, this is a `√A_nWβ` entry fee plus either `4Wβ/3` or `4Xρ/(3√A_n)` overshoot. A finite octave has `A_n≤1+n log2`. Changing `H` changes the original high-row target and its complementary low-row payment; this choice is not free if a previous ledger has already frozen a different threshold.

If an independently certified raw entrance has the form `T≤4S(Wβ+Wν)+2B_H` with its actual `H=S/(2λ)`, (12) replaces that ONE `B_H` slot by

`T≤(5S+8/3)Wβ+4S Wν+2I_H`.

This is a conditional insertion rule, not a certification of the original global entrance. A subsequent recovery factor multiplies all displayed terms; the output alternative in (13) consumes its actual multiplied absorption budget. Earlier R313/R317 rank-initializer payments must be replaced, not added: (12) pays the whole physical crossing with a different residual strictly after `τ`.

## 5. The exact uncompensated later term

Equations (7),(8),(10) specify `𝓘_H` as actual within-radius capture variance plus changes of the running capture fractions after the crossing. They retain original `β,ν,dx,q,R,J` and the full square. No chronological/source-history atom is settled by (12).

The presently justified bounds are only

\[
 0\le\mathcal I_H\le B_H
       \le\min\{X_\rho,A_nW_\nu\}.                     \tag{14}
\]

The first output bound is (4); the source bound is the ordinary full radial envelope. Neither is the desired generally absorbable small output term plus source-root fee. The changing reversible measure in §1 does not turn (8) into a fixed-source martingale dissipation theorem. A successful continuation must price the actual later innovation in (7),(8) or supply a valid correlation/overlap mechanism. The compact-support atom cap proves the crossing receipt and no more. No general-soft extension is asserted.

## 6. Executed actual hard-kernel diagnostics

The following local Fraction reproduction passed **306 exact assertions**. It uses the existing periodic positive-L¹ hard fixture with a changed, explicitly FULL row source `β=f`, not the earlier `f|D` row source. The finite complete input repeats density `3` on the first eighth and density `1` on the next eighth of each half-unit period inside `[-2,2]`, zero on the remaining quarter. Actual `E=[−1,1]`, `R=L=1` on negative receivers and `3/2` on nonnegative receivers give `q=h_R*f=1`: each receiver window is an integer number of complete periods and lies inside the finite input range. Take `ν=(1/2)f|D`, `D=[−1/2,−1/4]`.

The test integrates actual `A` against full `β` to verify (3), and against positive-volume `ν` to obtain `F`. It checks atom caps, full first crossing/equality/never-cross cases, and the exact inclusive layer identity. At full prefix, `V_y=5/4`, `J_y=1−y/3`, so `T` has nonunit source row mass on a positive-measure source interval. This is not an original lower-hard-band/history realization or a general root test.

```python
from fractions import Fraction as F
ct=dict(actual_markov_mass=0,diagonal=0,atom_cap=0,innovation=0,
        source_variance_monotone=0,crossing=0,layer_identity=0,
        entry_fee=0,never_cross=0)
Eparts=[(F(-1),F(0),F(1)),(F(0),F(1),F(3,2))]
f=[]
for k in range(-3,5):
    shift=F(k,2)
    f.extend([(F(-1,2)+shift,F(-3,8)+shift,F(3)),
              (F(-3,8)+shift,F(-1,4)+shift,F(1))])
nu=[(F(-1,2),F(-3,8),F(3,2)),(F(-3,8),F(-1,4),F(1,2))]
def length(lo,hi): return max(F(0),hi-lo)
def interval(y,R,part):
    return max(part[0],y-R/2),min(part[1],y+R/2)
def A(y,z,prefix):
    out=F(0)
    for l,h,R in Eparts[:prefix]:
        out+=length(max(l,y-R/2,z-R/2),min(h,y+R/2,z+R/2))/R
    return out
for y in [F(-1,2)+F(k,32) for k in range(9)]:
    J=[A(y,y,i) for i in (1,2)]
    V=[sum(length(*interval(y,R,(l,h)))
           for l,h,R in Eparts[:i]) for i in (1,2)]
    for pre in (1,2):
        cuts=set()
        for l,h,R in Eparts[:pre]:
            lo,hi=interval(y,R,(l,h))
            cuts.update((lo-R/2,lo+R/2,hi-R/2,hi+R/2))
        mass=F(0)
        for l,h,d in f:
            knots=sorted({l,h}|{z for z in cuts if l<z<h})
            mass+=sum(d*(b-a)*(A(y,a,pre)+A(y,b,pre))/2
                      for a,b in zip(knots,knots[1:]))
        assert mass==V[pre-1]; ct['actual_markov_mass']+=1
        assert A(y,y,pre)==J[pre-1]; ct['diagonal']+=1
    assert V[1]==F(5,4) and V[1]/J[1]!=1
    ct['actual_markov_mass']+=1
    for j in (J[0],J[1]-J[0]):
        assert 0<=j<=1<=F(4,3); ct['atom_cap']+=1
    for z in [F(-1,2)+F(k,32) for k in range(9)]:
        a1,a2=A(y,z,1),A(y,z,2)
        j=J[1]-J[0]; v=(a2-a1)/j; p=a1/J[0]
        F1=a1-a1*a1/J[0]; F2=a2-a2*a2/J[1]
        assert F2-F1==j*v*(1-v)+J[0]*j/J[1]*(v-p)**2>=0
        ct['innovation']+=1
    Fs=[]
    for pre in (1,2):
        moments=[F(0),F(0)]
        for l,h,d in nu:
            knots=sorted({l,h}|({y} if l<y<h else set()))
            for a,b in zip(knots,knots[1:]):
                av,bv=A(y,a,pre),A(y,b,pre)
                moments[0]+=d*(b-a)*(av+bv)/2
                moments[1]+=d*(b-a)*(av*av+av*bv+bv*bv)/3
        Fs.append(moments[0]-moments[1]/J[pre-1])
    assert 0<=Fs[0]<=Fs[1]; ct['source_variance_monotone']+=1
    for H in (F(1,8),F(3,4),J[0],J[0]+F(1,100),
              J[1],J[1]+F(1,100),F(2)):
        actual=(F(1,3)*Fs[0] if J[0]>=H else 0)
        actual+=(F(2,3)*Fs[1] if J[1]>=H else 0)
        if J[1]<H:
            assert actual==0; ct['never_cross']+=1; continue
        k=0 if J[0]>=H else 1; t=(F(1),F(3,2))[k]
        assert J[k]<=H+F(4,3); ct['crossing']+=1
        entry=Fs[k]/t
        tail=F(2,3)*(Fs[1]-Fs[0]) if k==0 else F(0)
        assert actual==entry+tail; ct['layer_identity']+=1
        assert entry<=H+F(4,3); ct['entry_fee']+=1
print('PASS',ct,'total',sum(ct.values()))
```

Only `/tmp/r327_aux.md` is authored. No other agent's files or Git were changed.
