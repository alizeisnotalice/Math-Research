"""R760 exact terminal marked-law uniformization and one-dimensional constants."""

import argparse
from collections import defaultdict
from fractions import Fraction as Q
from hashlib import sha256
from itertools import combinations, product
import json
from pathlib import Path
from platform import python_version

from flint import arb, ctx, fmpq, __version__ as flint_version


ctx.prec = 256
GRID = range(4)


def ball(x):
    q = Q(x)
    return arb(fmpq(q.numerator,q.denominator))


def interval(center,radius):
    return center-radius,center+radius


def cell_lengths(E,first):
    lo,hi = E
    mid = lo+first*(hi-lo)
    return ((lo,mid),(mid,hi))


def normalized(law):
    total = sum(law.values())
    return {key: value/total for key,value in law.items() if value}


def marked_path():
    labels = ("s","t","k0","k1")
    centers = (Q(0),Q(1,4),Q(-1,2),Q(1,2))
    radii = (Q(4),Q(2),Q(1),Q(3,4))
    A = {j:interval(x,r) for j,x,r in zip(labels,centers,radii)}
    E = {j:interval(x,r/32) for j,x,r in zip(labels,centers,radii)}
    v = {j:E[j][1]-E[j][0] for j in labels}
    assert all(v[j]>0 for j in labels)
    assert all(max(E[j][0],E[k][0])>=min(E[j][1],E[k][1]) for j,k in combinations(labels,2))
    prices, priced_mass = (Q(-1,8),Q(1,8)),(Q(4),Q(12))
    m = {j:sum(w for z,w in zip(prices,priced_mass) if A[j][0]<z<A[j][1]) for j in labels}
    assert all(m[j]==16 and m[j]>=A[j][1]-A[j][0] for j in labels)
    assert all(A[j][0] < z < A[j][1] for j,z in product(labels,prices))
    beta = Q(32,65)
    g = {j:v[j]/m[j] for j in labels}
    lam = {j:beta*g[j] for j in labels}
    assert sum(lam.values()) <= 1 and sum(lam.values())/sum(g.values())==beta
    edges = {frozenset(edge) for edge in ((labels[0],labels[1]),(labels[1],labels[2]),(labels[1],labels[3]))}

    def marked(j,k,z):
        # The original marked row is (F/W)*g_k times the original rho_j price.
        return beta*g[k]*priced_mass[z]/m[j] if frozenset((j,k)) in edges else Q(0)

    assert all(v[j]*marked(j,k,z)==v[k]*marked(k,j,z) for j,k,z in product(labels,labels,range(2)))
    assert all(sum(marked(j,k,z) for k,z in product(labels,range(2)))<=1 for j in labels)
    owner1 = cell_lengths(E[labels[1]],Q(1,4))
    owner2 = [cell_lengths(E[k],Q(1,3)) for k in labels[2:]]
    raw = {}
    target = {}
    for z1,r1,b,z2,r2 in product(range(2),repeat=5):
        upper,mid,child = labels[0],labels[1],labels[2+b]
        a1,b1 = owner1[r1]
        a2,b2 = owner2[b][r2]
        key = (z1,r1,b,z2,r2)
        raw[key] = v[upper]*marked(upper,mid,z1)*(b1-a1)/v[mid]*marked(mid,child,z2)*(b2-a2)/v[child]
        if b==r1:
            p_zero = Q(3,4) if z1==r1 else Q(1,4)
            p_first_owner = Q(1,4) if z2==0 else Q(3,4)
            target[key] = (priced_mass[z1]/m[mid]/2
                           *(p_zero if z2==0 else 1-p_zero)
                           *(p_first_owner if r2==0 else 1-p_first_owner))
    assert sum(target.values())==1
    raw_normalized = normalized(raw)
    gate = {key:target.get(key,Q(0))/(32*weight) for key,weight in raw_normalized.items()}
    assert min(gate.values())==0 and 0<max(gate.values())<=1
    terminal = {key:mass*gate[key] for key,mass in raw.items()}
    law = normalized(terminal)
    assert law==target and sum(terminal.values())==sum(raw.values())/32
    return law, (owner1,owner2), {
        "parents":{j:list(map(str,I)) for j,I in A.items()},
        "owners":{j:list(map(str,I)) for j,I in E.items()},
        "owner_1_cells":[list(map(str,I)) for I in owner1],
        "owner_2_cells_by_label":[[list(map(str,I)) for I in cells] for cells in owner2],
        "price_points": list(map(str,prices)), "price_masses":list(map(str,priced_mass)),
        "actual_parent_m":{j:str(value) for j,value in m.items()},
        "preturn_path_mass":str(sum(raw.values())), "terminal_path_mass":str(sum(terminal.values())),
        "max_terminal_gate":str(max(gate.values())),
        "terminal_atoms_z1_owner1_label2_z2_owner2": [
            [list(key),str(value),str(gate[key])] for key,value in sorted(law.items())
        ],
    }


def rank_band(law,coordinate,value,context):
    """The rank interval for the indicated mark with preceding information fixed."""
    raw = [Q(0),Q(0)]
    for key,mass in law.items():
        if all(key[i]==val for i,val in context.items()):
            raw[key[coordinate]] += mass
    denominator = sum(raw)
    start = sum(raw[:value])/denominator
    width = raw[value]/denominator
    assert width>0 and (4*start).denominator==(4*width).denominator==1
    return start,width


def grid_bins(band):
    start,width = band
    return range(int(4*start),int(4*(start+width)))


def preimage_of_bin(band,index):
    start,width = band
    return max(Q(0),(Q(index,4)-start)/width),min(Q(1),(Q(index+1,4)-start)/width)


def overlap(I,J):
    return max(Q(0),min(I[1],J[1])-max(I[0],J[0]))


def matrix_strings(table):
    return [[str(table[i,j]) for j in GRID] for i in GRID]


def owner_rank_weights(physical,band):
    """Use lengths of the actual owner subintervals cut by the rank grid."""
    origin,end = physical
    width = end-origin
    cursor = origin
    weights = {}
    for index in grid_bins(band):
        lo,hi = preimage_of_bin(band,index)
        left,right = origin+width*lo,origin+width*hi
        assert cursor==left<right<=end
        weights[index] = (right-left)/width
        cursor = right
    assert cursor==end and sum(weights.values())==1
    return weights


def rank_audit(law,owner_cells):
    adjacent, reused, wrong_prior = (defaultdict(Q) for _ in range(3))
    reconstructed, by_future, u_given_past, v1_given_price, v2_given_price = (
        defaultdict(Q) for _ in range(5)
    )
    owner1,owner2 = owner_cells
    for key,mass in law.items():
        z1,r1,b,z2,r2 = key
        h = {0:z1,1:r1,2:b}
        bands = (rank_band(law,0,z1,{}),
                 rank_band(law,1,r1,{0:z1}),
                 rank_band(law,3,z2,h),
                 rank_band(law,4,r2,{**h,3:z2}))
        U1,U2 = grid_bins(bands[0]),grid_bins(bands[2])
        V1 = owner_rank_weights(owner1[r1],bands[1])
        V2 = owner_rank_weights(owner2[b][r2],bands[3])
        # U1 and U2 use new tie jitters, whereas V1 and V2 come from the
        # positions in the original continuous owner cells.
        for u1,v1,u2,v2 in product(U1,V1,U2,V2):
            rank_mass = mass*V1[v1]*V2[v2]/(len(U1)*len(U2))
            reconstructed[key] += rank_mass
            adjacent[v1,u2] += rank_mass
            by_future[b,v1] += rank_mass
            u_given_past[z1,r1,b,u1,v1,u2] += rank_mass
            v1_given_price[z1,u1,v1] += rank_mass
            v2_given_price[z1,r1,b,z2,u1,v1,u2,v2] += rank_mass
        for i,j in product(GRID,repeat=2):
            # Wrong jitter: re-use the fractional position of actual Y1.
            reused[i,j] += mass*overlap(preimage_of_bin(bands[1],i),preimage_of_bin(bands[2],j))
        fixed_marginal_band = rank_band(law,3,z2,{})
        wrong_U2 = grid_bins(fixed_marginal_band)
        for i,j in product(V1,wrong_U2):
            wrong_prior[i,j] += mass*V1[i]/len(wrong_U2)

    assert reconstructed==law
    assert all(value==Q(1,16) for value in adjacent.values()) and len(adjacent)==16
    for grouped in (u_given_past,v1_given_price,v2_given_price):
        histories = {key[:-1] for key in grouped}
        for fixed in histories:
            row = [grouped[fixed+(i,)] for i in GRID]
            assert all(w==sum(row)/4 for w in row)
    future_conditioned = [[by_future[b,i]/sum(by_future[b,j] for j in GRID) for i in GRID]
                          for b in range(2)]
    assert future_conditioned == [[Q(1,2),Q(1,2),0,0],[0,0,Q(1,2),Q(1,2)]]
    for comparison in (reused,wrong_prior):
        assert all(sum(comparison[i,j] for j in GRID)==Q(1,4) for i in GRID)
        assert all(sum(comparison[i,j] for i in GRID)==Q(1,4) for j in GRID)
    assert reused[0,0]==Q(5,64)
    assert sum(wrong_prior[i,j] for i,j in product(range(2),repeat=2))==Q(3,16)
    return {
        "rows_V_previous_columns_U_next":matrix_strings(adjacent),
        "same_actual_Y1_fraction_reused":matrix_strings(reused),
        "using_unconditional_next_price_CDF":matrix_strings(wrong_prior),
        "V_previous_given_future_label":[list(map(str,row)) for row in future_conditioned],
        "terminal_mark_law_recovered":True,
        "predictable_next_U_histories":len({key[:-1] for key in u_given_past}),
        "V_conditioned_on_current_price_and_current_U_histories": [
            len({key[:-1] for key in grouped}) for grouped in (v1_given_price,v2_given_price)
        ],
    }


def quantile_audit():
    result = []
    for name,lengths,masses in (
        ("first_owner",(Q(1,4),Q(3,4)),(Q(1,2),Q(1,2))),
        ("second_owner_low_price",(Q(1,3),Q(2,3)),(Q(1,4),Q(3,4))),
        ("second_owner_high_price",(Q(1,3),Q(2,3)),(Q(3,4),Q(1,4))),
    ):
        tv = sum(abs(p-r) for p,r in zip(masses,lengths))/2
        shifts = [Q(0)]
        for r,p in zip(lengths,masses):
            shifts.append(shifts[-1]+2*(p-r))
        displacement = max(map(abs,shifts))
        w2 = sum(p*(a*a+a*b+b*b)/3 for p,a,b in zip(masses,shifts,shifts[1:]))
        kl = sum(ball(p)*ball(p/r).log() for p,r in zip(masses,lengths))
        assert displacement==2*tv and 0<w2<4*tv*tv
        assert ball(4*tv*tv)<2*kl
        result.append({"law":name,"TV":str(tv),"max_quantile_displacement":str(displacement),
                       "W2_squared":str(w2),"four_TV_squared":str(4*tv*tv),"KL":kl.str(20)})
    return result


def uniform_gap():
    area = []
    for s in (Q(0),Q(1,8),Q(1,2),Q(7,8),Q(1)):
        width = 1-s
        triangular_tail = 2*(width*(1-s)-width**2/2)
        assert triangular_tail==(1-s)**2
        area.append([str(s),str(triangular_tail),str(2*(1-s))])
    mean_s_from_tail = 1-2*Q(1,2)+Q(1,3)
    mean_s_from_density = 2*(Q(1,2)-Q(1,3))
    assert mean_s_from_tail==mean_s_from_density==Q(1,3)

    capped = []
    for M in map(ball,(Q(0),Q(1,4),Q(1),Q(4),Q(16))):
        u = (-M).exp()
        density_integral = arb(1)/2-(-u**2*u.log()+u**2/2)+M*u**2
        tail_integral = (1-(-2*M).exp())/2
        assert density_integral.overlaps(tail_integral) and abs(density_integral-tail_integral)<arb(2)**-200
        capped.append([M.str(8),tail_integral.str(20)])
    return {"tail_and_density_at_s":area,"expected_abs_U_minus_V":str(2*mean_s_from_tail),
            "cap_M_and_expected_min_negative_log":capped}


def report():
    law,owner_cells,input_cert = marked_path()
    return {
        "scope":(
            "Finite-price two-step terminal gate on genuine 1D disjoint full owners. "
            "U uses a fresh conditional price tie jitter. V uses the contemporaneous actual owner. "
            "In the correct construction the paired continuous ranks are uniform on each occupied grid rectangle."
        ),
        "python":python_version(),"python_flint":flint_version,"arb_bits":ctx.prec,
        "source_sha256":sha256(Path(__file__).read_bytes()).hexdigest(),
        "commands":["python -B verify.py --out verify.json","python -B verify.py --check verify.json"],
        "marked_path":input_cert,"ranks":rank_audit(law,owner_cells),"quantile":quantile_audit(),"uniform_gap":uniform_gap(),
    }


def main():
    parser = argparse.ArgumentParser()
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--out",type=Path)
    group.add_argument("--check",type=Path)
    args = parser.parse_args()
    result = report()
    data = (json.dumps(result,indent=2,sort_keys=True)+"\n").encode()
    if args.out:
        args.out.write_bytes(data)
        print(f"wrote {args.out} ({len(data)} bytes)")
    else:
        assert args.check.read_bytes()==data, "certificate differs"
        print(f"identical rerun of {args.check} ({len(data)} bytes)")
    print("Adjacent uniform rank cells 1/16 each. Reusing actual Y1 gives the (0,0) cell 5/64.")


if __name__=="__main__":
    main()

