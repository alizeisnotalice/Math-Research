"""Exact triangle normalization; a true concentrated source inside one child."""
from fractions import Fraction as Q
from flint import arb, ctx
import sympy as sp

ctx.prec = 256
u, M = sp.symbols('u M', positive=True)
assert sp.integrate(2*(1-u),(u,0,1))==1
assert sp.integrate(4*u*(1-u),(u,0,1))==Q(2,3)
v = sp.symbols('v', nonnegative=True)
assert sp.simplify(sp.integrate(sp.exp(-2*v),(v,0,M))-(1-sp.exp(-2*M))/2)==0

def ball(x):
    return arb(x.numerator)/x.denominator

for n in (16,64,256,1024):
    h = 1+Q(1,32*n)
    r, center = Q(1,16),Q(1)
    # True source uniformly fills the inward quarter of the child in every axis.
    # Its total mass is the whole parent volume. Outside this child one may add
    # a price packet at x=0 independently.
    uniform = 1-center/(2*h)
    true = 1-(center-3*r/4)/(2*h)
    atom_free_ratio = (true/uniform)**n
    assert atom_free_ratio > (1+r/2)**n
    volume_one_dim = 2*(2*h-Q(1,2)*(2*h)**2/(2*h))
    assert volume_one_dim == 2*h
    interval = ball(atom_free_ratio).log()
    assert -ball(1-(center-r)/(2*h)).log() > arb(1)/2
    print("n",n,"log(true/uniform)",interval.str(12),"same radius",str(r))
