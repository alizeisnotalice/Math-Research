# 第107轮：共同空间叶与多尺度邻域容量

2026-10-13。本轮继承已推送的第106轮提交1365616568488b12e6d3d02baa9c7431d2ac3316，继续任意正L1输入的一般中心立方体n^(1/2+o(1))一致弱型上界。一般目标尚未证明；本轮交付可付款的新全输入几何分解和精确剩余条件。

## 从来源支撑走向局部邻域容量

在每个空间叶内，把原出生细格截成真实的叶内片。有限邻格网络在位移预算内，将一部分原来源正输运到有界密度目标。最大流的可行计划给出实际可提取来源，残余可达割给精确浓度缺口；目标容量按真实截片体积计算，邻接空格也可承接质量。人工目标密度只用于比较，不取得原FULL资格。

几何位移成本、最大函数强L2常数及真实接收体积共同给提取来源的根阶费用。将多个尺度作用于同一原来源，再逐片取最大提取比例，用其增量分配到相应正计划；这样同一质量份额只付一次。全部尺度的成本显式求和，选择几何级数菜单后仍为根阶。共同余源必须同时满足所有尺度的浓度缺口，并由小体积细格集及小叶内厚邻域承载。厚度只有约a log(n)/n，不能直接当成完整接收cube邻域。

## 原软端与整个硬赢家共同落叶

从原联合软硬表示出发，先支付软端远尾，再引入独立平移，使原软来源点与整个硬winner共同落入一个空间叶。此处最细叶边长改为256na；联合边界费为9/128，吸收系数为128/119，不能继续使用第106轮的8/7。

在同一个叶内，原完整高软来源和当前硬尾来源是两份不同的冻结测度。自含平方列估计支付一个新的真实尾质量分支，价格按原软来源质量收取，不需要叶属于原森林parent。相对原软质量很小的硬尾叶另由有限窗口付款；与平方列叶类别不交，因而可共用较大来源系数。未付当前硬尾由此获得归一化细格质量限制，但原软来源不因此具有同样的rank界。

## 总账与未解责任

两条路线在同一个原联合门下组合：远软尾先付，共同树停止，多尺度来源提取，deep top-k删格、低实际尾行及轻尾窗口，随后相对小尾和双来源平方列付款。所有新增小量误差保留，按同一共同树的128/119系数回代；旧P104、R105来源费、旧X/768及先剥离的远软费用保持原位置。

来源及所有尺度的质量账在后文逐项给出。新增几何限制适用于一般输入，但没有保证某一尺度必提取固定比例，也没有证明最终质量可比的重尾交通具有根阶预算。原有限窗口价格仍作为真实未付终端保留。后续“长坐标管”候选单列下一轮，不与本轮成果或数值混合。

## 本机工具与证据边界

按用户要求，本轮启用本机MATLAB R2026a的最大流和线性规划工具生成候选，并用独立Python Fraction程序核验容量、守恒、割和物理交通；不把浮点求解状态当作证明。更新64项技能中的正输运、有限预算、可测性和证明型数值流程按实际需要使用。工具可用性检测、研究执行和一般解析证明分别记录；未借用未核的优化强对偶黑箱。

固定三个非原子来源检验一般输运引理的机制，包括边界截片、格内峰、共同目标容量以及跨尺度提取比例交叉变化。精确张量压缩仍保留全维真实体积。它们不认证原FULL，不数值认证新的联合软硬远尾或平方列估计，也不以低维机制例子代替一般上界。详细实际结果与复现命令见后文。LaTeX只保存文本，不编译PDF；每轮独立提交紧凑报告和必要证书。


## R107：局部邻域容量输运

本节构造可按显式根阶预算提取的真实来源，给余来源同时成立的多尺度浓度缺口与叶内厚邻域界；未证明一般余项的根阶费用。

## 1. 原实际对象与两个独立参数

设 `n≥1`、`a,λ>0`，原出生细格为全边长 `d=a/n` 的半开平移格
\[
 C_i=u+d(i+[0,1)^n),\qquad i\in\mathbb Z^n.
 \tag{D1}
\]
原 FULL 应用仍要求 `n≥512`；本文的输运引理本身不据此扩大 FULL 的维数范围。所有原种子及 nested-tree 的新种子合称 `ω`。任取预先固定的 `c≥16`，其每个种子取值下有有限个互不交半开终端叶 `V`，边长 `cna`；当前预冻结来源为
\[
 \mu_\omega=\sum_V\mu_{V,\omega},\qquad
 0\le\mu_V\le1_V\mu_{\rm hi}\le1_Vf\,dz,
 \qquad
 \mu_V(V)\le\frac{K_c\lambda}{\sqrt n}|V|,
 \quad K_c=4e^{2/c}\le K:=4e^{1/8}.
 \tag{D2}
\]
来源可以是 tree/cap/top-k/peeling 后的真实子来源；只要 (D2) 仍成立即可。以下所有公式为统一常数使用较宽的 `K`，每处均可保留更准确的 `K_c`。特别 `c=256` 时 `K_c=4e^{1/128}`。子来源不要求具有点态密度上界。有限性来自当前有限来源截断和有限层树，允许节点数随维数指数增长。下述流、cut 和输运证明仅使用低叶均值、叶及其 pieces 的不交性、有限有界性和 whole cube 的唯一叶归属；没有其它对数值 `16` 的依赖，原细格边长始终为 `d=a/n`。

实际交通为
\[
 T_\mu=\mathbb E\int_E\int
 J(x,z,\omega)h_{R(x)}(x-z)d\mu_\omega(z)dx,
 \quad h_R(v)=R^{-n}1_{Q(0,R)}(v),
 \quad a\le R(x)\le2a,
 \tag{D3}
\]
其中 `0≤J≤1` 保留原规范表示的全部 FULL、deep 及当前其它门；`E` 有限，`X=λ|E|`。每个正实际 row 的 whole cube `Q_x` 在唯一叶内。原完整 `f`、原选择器、原 `q,H_C,t_C` 均不改变。本节不要求当前 `r_μ` 已具有固定正下界。

固定整数 `m≥0` 和容量密度 `τ>0`。它们先于 receiver 选定，不由当前 `x` 或其接受后的来源后验决定。它们分别控制可搬运的细格层数和目标密度，不能只记一个参数而隐藏另一个的价格。记
\[
 F_{n,m}=\left(1+\frac{2(m+1)}n\right)^n\le e^{2(m+1)}.
 \tag{D4}
\]

## 2. 有限邻格流与精确浓度缺口

固定 `ω,V`。对每个与 `V` 有正体积交集的旧细格取 piece
\[
 P_i=C_i\cap V,\qquad
 \alpha_i=\mu_V(P_i),\qquad \beta_i=\tau|P_i|.
 \tag{D5}
\]
这些 pieces 构成 `V` 的有限半开分区，差一个 Lebesgue 零集；由于 `μ_V≤f dz`，来源同样不遗漏。跨叶的同一个旧细格须按各个 `C_i∩V` 分开，不能给每片使用整个 `d^n` 目标容量。

允许从源节点 `i` 向目标节点 `j` 搬运，当且仅当
\[
 \|i-j\|_\infty\le m.
 \tag{D6}
\]
仅在同一个叶内连边。所有目标 pieces 均入图，包括没有来源的目标格。取一个最大化 `Σ_{ij}f_{ij}` 的有限非负流矩阵，满足
\[
 \sum_j f_{ij}\le\alpha_i,\qquad
 \sum_i f_{ij}\le\beta_j,\qquad
 f_{ij}=0\quad\text{若 (D6) 不成立}.
 \tag{D7}
\]
可行集非空且紧，故最大值存在。共同变量的可测选择在 §6 自含说明。这里使用一般实容量，不假设质量有共同整数单位。

置 `F_i=Σ_j f_{ij}`、`G_j=Σ_i f_{ij}`，以 `α_i=0` 时比例为零的约定定义
\[
 d\eta_V(z)=\sum_i\frac{F_i}{\alpha_i}1_{P_i}(z)d\mu_V(z),
 \qquad \zeta_V=\mu_V-\eta_V,
 \qquad s_V(y)=\sum_j\frac{G_j}{|P_j|}1_{P_j}(y).
 \tag{D8}
\]
于是 `η_V,ζ_V` 是真实预冻结子来源，`0≤s_V≤τ`，且
\[
 \|\eta_V\|=\int_Vs_V=\sum_{ij}f_{ij}.
 \tag{D9}
\]
人工比较密度 `s_V` 不必被原 `f` 支配，也不会因此取得任何原 FULL 或出生资格。

对源节点集 `A` 定义
\[
 U_A=\bigcup_{i\in A}P_i,\qquad
 N_m(A)=\{j:\exists i\in A,\ \|i-j\|_\infty\le m\},
 \qquad U_{N_m(A)}=\bigcup_{j\in N_m(A)}P_j.
 \tag{D10}
\]
空集的邻域为空。精确的有限尺度浓度缺口为
\[
 \mathcal D_{m,\tau}(\mu_V)
 =\max_A\{\mu_V(U_A)-\tau|U_{N_m(A)}|\}.
 \tag{D11}
\]
最大值非负，因为允许 `A=∅`。它同时比较每个聚集块的来源量和该块可达的邻格容量；不以单格最大质量或整叶均值替代这份空间条件。

**有限流结论。** 可从同一最大流构造一个源节点集 `A_V`，使
\[
 \boxed{
 \zeta_V(V\setminus U_{A_V})=0,\qquad
 \|\zeta_V\|=\mathcal D_{m,\tau}(\mu_V)
 =\mu_V(U_{A_V})-\tau|U_{N_m(A_V)}|.}
 \tag{D12}
\]
特别由 (D2) 有
\[
 \boxed{
 |U_{N_m(A_V)}|
 \le\frac{\mu_V(U_{A_V})}{\tau}
 \le\frac{K\lambda}{\sqrt n\,\tau}|V|.}
 \tag{D13}
\]
若余源为零可以并且以下构造会取 `A_V=∅`。若余源非零，(D12) 是严格正的容量缺口，不能把它解释为已经支付的密度停止块。

**证明。** 令 `M=μ_V(V)`；零来源叶取零流及空集。把 (D7) 看作网络：起点至源节点容量 `α_i`，目标节点至终点容量 `β_j`，允许的源至目标边统一给有限容量
\[
 B=M+\tau|V|>M.
\]
所有可行源至目标边的流至多 `M`，因此该有限容量从不截断允许边，每条这种正向边都在残余图中仍有正容量。

最大流的残余图不能有起点至终点的路径：若有，去环得到有限简单路径，对路径上正的残余容量取最小值，就可沿正向边增加、反向边减少一个正流量，使总流增大，矛盾。令 `A_V` 为起点可达的源节点。源节点外于 `A_V` 时，起点至该源的边必饱和，故其残余来源为零。

可达目标恰为 `N_m(A_V)`。一方面，每条允许正向内部边仍有正残余量，所以 `A_V` 的每个邻目标都可达；另一方面，未经过终点的首次到达目标必经一个可达源节点的允许边。每个可达目标到终点的边必饱和，否则终点也可达。若有从 `A_V` 外源节点向可达目标的正流，其反向残余边又会使该源可达，矛盾。故可达目标收到的全部流来自 `A_V`，且这部分流准确为 `τ|U_N|`。因此 `η_V(U_A)=τ|U_N|`，外于 `U_A` 的源完全抽出，得到 (D12) 的来源支撑和等式。

最后，对任意节点集 `A` 和任意可行流，该组源送出的总质量不超过 `τ|U_{N_m(A)}|`，故未抽来源总量至少 `μ_V(U_A)−τ|U_N|`。取最大值，再代已经构造的等号 cut，就证明余质量准确等于 (D11)。证毕。

这也证明：如果所有节点集都满足 `μ_V(U_A)≤τ|U_N|`，则整叶来源可抽出。若条件不成立，本文明确交付容量缺口及其承载空间，不假设该条件自动由低叶均值推出。`m=0` 时 (D11) 退化为逐 piece 超容量质量之和；`m>0` 时相邻空格可共同承接质量，最大可抽质量至少不小于 `m=0` 的对应值。

## 3. 真正的厚邻域及跨叶边界

令 `U_V=U_{A_V}`。对 `m≥1`，格指标的定义给
\[
 \boxed{
 \bigl(U_V+(-md,md)^n\bigr)\cap V
 \subset U_{N_m(A_V)}.}
 \tag{D14}
\]
若 `y∈P_j` 距某 `z∈P_i` 的 `ℓ∞` 距离严格小于 `md`，则每个坐标上的格指标差至多 `m`；指标差至少 `m+1` 时该坐标距离至少 `md`，与严格不等式矛盾。以开邻域写 (D14) 避开无意义的网格端点约定。`m=0` 仅使用 `U_V⊂U_{N_0(A_V)}=U_V`。

因此 (D13) 控制的是余源承载集在叶内厚度 `md` 的实际空间邻域，超出了原先只控制来源格并体积的结论。此邻域明确与 `V` 取交；跨叶边界外的体积没有被本结论控制。流也不会跨叶借用另一个叶的容量。相邻叶中的目标 pieces 无论来自同一个旧细格还是不同格，均不交。

若输入还由原叶高格并 `S_V` 承载，例如已有 `|S_V|≤K|V|/n`，则 `ζ_V` 同时由 `S_V∩U_V` 承载；(D14) 对这个更小承载集继续成立。不得据此声称当前 `ζ_V(P_i)` 仍超过原细格容量。

## 4. 显式正输运与真实来源付款

对 `α_i>0` 的允许边定义正计划
\[
 d\pi_V(z,y)
 =\sum_{i,j}\frac{f_{ij}}{\alpha_i|P_j|}
   1_{P_i}(z)d\mu_V(z)\,1_{P_j}(y)dy;
 \tag{D15}
\]
零流边以及零来源行取零。它的第一、第二边缘分别为 `η_V` 和 `s_Vdy`。每对有正计划质量的点满足
\[
 \|z-y\|_\infty\le(m+1)d.
 \tag{D16}
\]
这是因为格指标差至多 `m`，每个格本身边长 `d`；截成叶内 pieces 只会缩小几何范围。

令 `η=Σ_Vη_V`、`ζ=Σ_Vζ_V`、`s=Σ_Vs_V`。目标叶不交，故
\[
 0\le s\le\tau,\qquad
 \int s=\|\eta\|,\qquad
 \|s\|_2^2\le\tau\|\eta\|.
 \tag{D17}
\]
先跨叶形成这一个比较密度，再使用强 `L²`；不是给每个叶各支付一次 `εX`。

由 (D15)–(D16) 的第一边缘，对任何 `R≥a` 都有
\[
 \eta(Q(x,R))
 \le\int_{Q(x,R+2(m+1)d)}s(y)dy.
\]
因此
\[
 A_R\eta(x)\le F_{n,m}\,Ms(x),
 \tag{D18}
\]
其中 `M` 是全尺度中心 cube 最大算子。解析比较半径允许超出原 `[a,2a]`；原实际选择器与原交通的半径均不改变。记原项目已核的维数一致强 `L²` 常数为 `C_2`，则
\[
 \|Ms\|_2\le C_2\|s\|_2.
 \tag{D19}
\]
本文只使用该既有强型接口；有限流、浓度缺口及其几何证明均为上述自含推导。

记 `W_η=E‖η‖`。由于原 `J≤1`，先在真实接收 measure `dx dP` 上用 Cauchy–Schwarz，再用 (D17)–(D19)，得到
\[
 \begin{split}
 T_\eta
 &\le F_{n,m}\mathbb E\int_E Ms_\omega(x)dx\\
 &\le F_{n,m}C_2\sqrt{\tau W_\eta |E|}
  =F_{n,m}C_2\sqrt{\frac\tau\lambda W_\eta X}.
 \end{split}
\]
对任意固定 `ε>0`，Young 不等式遂给
\[
 \boxed{
 T_\mu=T_\eta+T_\zeta
 \le\epsilon X+
 P_{n,m,\tau}(\epsilon)W_\eta+T_\zeta,
 \quad
 P_{n,m,\tau}(\epsilon)=
 \frac{C_2^2F_{n,m}^2\tau}{4\epsilon\lambda}.}
 \tag{D20}
\]
余项准确为以 `ζ` 积分的原 `J` 子交通，其系数是 `1`。`εX` 是新增接收费用，不能与既有低 row 或 tree 边界费用重用。也没有来源数、邻格数、叶数、流的边数或算法步数因子。

原规范 FULL 缺口和原 deep 门因 `η,ζ≤μ≤μhi` 与 `J` 未放大而继承。`s` 只用作正比较，不进入原门。抽出 `η` 后，`ζ` 的实际 row 下界可能变小；若后续需要固定正 row 下界，应明示筛去低 residual row 的费用，或使用 §7 的真实 tail-row 筛选，不能继承抽出前的下界。

## 5. 参数权衡、全维整数选择与局部尺度

式 (D13)、(D20) 给完整的 `m,τ` 权衡：更远的邻格搬运增大几何放大 `F²`；降低目标密度会降低来源价格，但使余源邻域占比上界增大。

一种准确归一化是
\[
 \tau=\frac{\sqrt n\lambda}{F_{n,m}^2}.
\]
此时
\[
 P_{n,m,\tau}(\epsilon)=\frac{C_2^2}{4\epsilon}\sqrt n,
 \qquad
 \frac{|U_{N_m(A_V)}|}{|V|}
 \le\frac{KF_{n,m}^2}{n}.
 \tag{D21}
\]
第二个上界可以大于 `1`；这种情形只有付款有用，不能把它称为额外稀疏性。

若希望余源的厚邻域始终保留 `O(n^{-1/2})` 体积比例，可直接取 `τ=λ`。以下全维合法整数选择保证邻域至少厚一层：
\[
 m=1+\left\lfloor\frac{\log n}{8}\right\rfloor\ge1.
 \tag{D22}
\]
因为 `m+1≤2+(log n)/8`，有
\[
 F_{n,m}^2\le e^{4(m+1)}\le e^8\sqrt n.
\]
所以 (D20) 和 (D13) 化为
\[
 \boxed{
 T_\mu\le\epsilon X+
 \frac{e^8C_2^2}{4\epsilon}\sqrt n\,W_\eta+T_\zeta,
 \qquad
 \left|\bigl(U_V+(-ma/n,ma/n)^n\bigr)\cap V\right|
 \le\frac K{\sqrt n}|V|.}
 \tag{D23}
\]
这里 `e^8` 是显式统一常数，不藏于一个依 `n` 的记号。小维数时 (D22) 自动取 `m=1`；本独立引理仍成立，实际 FULL 应用仍维持 `n≥512`。若只要较小常数而允许小维 `m=0`，可以取 `m=floor((log n)/8)`、`τ=λ`，则 (D23) 的 `e^8` 改成 `e^4`；当 `n<e^8` 时该选项没有厚邻域的额外一层。若 `n≥e^8` 并取 `m=floor((log n)/8)−1`，则还可得 `F²≤√n`，但这种选择不能在小维直接沿用。

所控制的厚度约为 `a log n/(8n)`，不是 `a`。本文没有把 (D23) 的空间邻域改写成 winner 半径尺度的接收 halo。

## 6. 全部来源构造的共同可测性

当前来源支持有固定有界截断，叶边长固定，所有随机平移在固定有界基本域内。因而可以取一个共同有限的叶指标库和旧细格指标库，覆盖所有可能的非零输入叶与各叶内部的全部目标 pieces。没有出现的叶、空 pieces 均补为零；这些补零节点不影响流。若原代码选择逐种子不同的有限库，也可按有限库型号分片执行以下构造，结论相同。

补零 pieces 的来源提取、比较密度与计划系数均直接定义为零，不对零体积取商。在每个固定有限图上把允许的 `f_{ij}` 排成一个向量 `v`。约束 (D7) 是
\[
 Av\le b(\omega),
\]
其中完整约束矩阵包括 `v≥0`（写作 `−v≤0`），其系数固定；右端由来源 piece 质量和 Lebesgue 体积及这些零下界组成，为共同可测函数。不存在的节点以零容量处理。记流变量数为 `N`；从完整约束矩阵中枚举每组 `N` 个线性独立的行，保留全部 `N` 个变量列，形成一个 `N×N` 可逆矩阵 `A_I`，产生候选
\[
 v_I(\omega)=A_I^{-1}b_I(\omega).
\]
候选是否满足所有约束由有限个可测不等式判断。在所有可行候选中，取目标 `Σf_ij` 最大者，再取预定枚举中第一项。候选数有限，故这份选择可测。

为何该规则确能取到最大流，而非仅取到某个流：非空有界有限多面体的线性最大值可以取在一个顶点。直接证明如下。在最大值面内，从任一点开始；若活跃约束法向尚未张成整个变量空间，则存在非零方向保持所有活跃等式。小幅正负移动均保持其它严格约束。最大性迫使目标沿此方向不变；沿该方向移动至首次遇到新约束，有界性保证端点存在，新活跃法向增加秩。有限次后得到满秩活跃约束的最优点，恰在上述候选中。零变量图单独取零流。这里不援引一个未核的可测最优化黑箱。

从选定流构造残余可达集也可测：残余边是否存在只用有限个流量或容量差的严格正性判断；在有限图上依次加入当前可达节点的邻节点，最多图节点数步即稳定。由此 `A_V`、`η_V,ζ_V`、计划及比较密度均共同可测。这个存在性选择允许指数乃至更大的有限成本；本文没有声称维数多项式实现，也没有执行数值算法。

## 7. 接 top-k 后的分散重尾与准确剩余项

若 (D3) 保留原出生 deep 门，则可将已审的 `birth_occupancy.md` (B1)–(B12) 应用于这里的新真实来源 `ζ=Σζ_V`，同一 `J` 与 whole-cube 唯一叶不改变。为避免隐藏费用，下面完整写出组合接口。

固定整数 `k≥0`。在每叶按 `ζ_V(C_i∩V)` 的质量删去最大的至多 `k` 个 pieces，等质量用原固定编号破同，记来源为 `ζ_V^top`、`ζ_V^tail`。因为整个 cube 属于唯一叶，且每个参与旧细格的实际 deep 贡献至多
\[
 \kappa_n\lambda,
 \qquad\kappa_n=e^2e^{-\sqrt n}/\sqrt n,
\]
这些 top 来源的原实际交通合计至多 `kκ_n X`，没有叶数因子。

以原 `J` 定义 `r_tail`，支付 `r_tail≤δλ` 的交通，费用至多 `δX`；剩余 row 满足真实 `r_tail>δλ`。若某叶的尾质量不超过
\[
 M_*=\lambda a^ne^{\sqrt n},
\]
则该高 row 上 `R^n<m_V^tail/(δλ)`，有限半径正包络给来源价格
\[
 A_n(\delta)=1+\min\{n\log2,\sqrt n+\log(1/\delta)\},
 \qquad0<\delta\le1.
\]
这是对当前真实 tail row 重新筛选所得，未继承旧来源的贡献下门。

记 `W_tail,light` 为这些轻尾叶的 tail 来源总质量期望，`T_*` 为其余重尾叶高 tail-row 上以 `ζ^tail` 为来源的原 `J` 交通。准确总式为
\[
 \boxed{
 T_\mu\le
 (\epsilon+k\kappa_n+\delta)X+
 P_{n,m,\tau}(\epsilon)W_\eta+
 A_n(\delta)W_{\rm tail,light}+T_* .}
 \tag{D24}
\]
`η+ζ=μ` 且 `ζ^tail≤ζ`，故这两类来源付款可以按其最大系数共享输入质量预算：
\[
 W_\eta+W_{\rm tail,light}\le W_\mu.
 \tag{D25}
\]
这里使用的是加法分解 `μ=η+ζ` 的质量份额；`η` 与 `ζ` 的空间支撑可以重叠。这不是重用质量份额，也没有把 top 删除质量额外乘一个来源 coupon。

对 (D24) 的每个未付叶，同时有
\[
 \begin{gathered}
 \|\zeta_V^{\rm tail}\|>M_*,\qquad
 r_{\rm tail}(x)>\delta\lambda\quad\text{在其未付 rows 上},\\
 \zeta_V^{\rm tail}\text{ 由 }U_V\text{ 承载},\qquad
 |U_{N_m(A_V)}|\le\frac{K\lambda}{\sqrt n\tau}|V|,\\
 \mathcal D_{m,\tau}(\mu_V)=\|\zeta_V\|
   >M_*+\|\zeta_V^{\rm top}\|,\\
 k\max_i\zeta_V^{\rm tail}(P_i)\le\|\zeta_V^{\rm top}\|,
 \qquad(k+1)\max_i\zeta_V^{\rm tail}(P_i)\le\|\zeta_V\|.
 \end{gathered}
 \tag{D26}
\]
因此重尾的分散性与厚邻域的空间集中性可以在同一个预冻结来源上同时保存。这个组合不是把 top-k 后某一格质量偷换成 `tail/k`。此外 `\mathcal D` 的输入仍是抽出前的 `μ_V`；不能用余源 `ζ_V` 重新领取同一份已经被 `η_V` 用过的目标容量。

若还需高实际列价核心，应在 (D24) 的具体余项上调用既有累计行删除的来源一次剥离，保留其全部系数与新增费用。该调用不会证明余项必然收缩。本引理自身不产生树吸收因子；把 (D24) 或下述 (D30) 的组合预算代入哪一份实际终端项，就必须继承那份主线已经证明的外部系数，包括全部新增 `X` 费用和余项。旧 hard-only 树的系数为 `(1−2/c)^{-1}`，其 `c=16` 特例才是 `8/7`。R107 联合软硬树采用 `c=256`，实际边界费为 `18/c`，故依 `fullgate_next.md` (N11)–(N14) 使用 `(1−18/256)^{-1}=128/119`，不能照抄 `8/7` 或改用 hard-only 的 `128/127`。联合树在吸收之前已经剥离的远软费用不再乘该因子。本稿没有把这笔未来集成计入 R106 主账。

## 8. 付清所有尺度的共同来源提取

同一构造还允许有限多尺度浓度测试，不必在源依不同尺度的缺口集合之间重新归一化。取预先固定的有限有序参数表
\[
 \mathcal I=\{(m_\ell,\tau_\ell):1\le\ell\le L\},
 \quad m_\ell\in\mathbb Z_{\ge0},\quad\tau_\ell>0,
 \quad F_\ell=F_{n,m_\ell}.
\]
对**同一输入** `μ_V` 分别做 §2 的全部流，得到 piece 提取比例 `θ_{V,i}^{ℓ}∈[0,1]`、原单尺度提取源 `η_V^{[ℓ]}`、余源 `ζ_V^{[ℓ]}`、cut `A_V^{[ℓ]}`。这些单尺度来源一般重叠，不能把它们的质量直接相加收费。改定义逐 piece 的最大保留比例及其增量
\[
 q_{V,i}^{0}=0,\qquad
 q_{V,i}^{\ell}=\max\{q_{V,i}^{\ell-1},\theta_{V,i}^{\ell}\},
 \qquad
 \Delta_{V,i}^{\ell}=q_{V,i}^{\ell}-q_{V,i}^{\ell-1}.
 \tag{D27}
\]
于是 `0≤Δ^ℓ≤θ^ℓ` 且 `ΣℓΔ^ℓ=q^L≤1`。定义实际质量份额
\[
 d\widehat\eta_V^{(\ell)}
   =\sum_i\Delta_{V,i}^{\ell}1_{P_i}d\mu_V,
 \qquad
 \widehat\eta_V=\sum_\ell\widehat\eta_V^{(\ell)},
 \qquad
 \widehat\zeta_V=\mu_V-\widehat\eta_V.
 \tag{D28}
\]
每个增量份额均被 `η_V^{[ℓ]}` 支配。将该原流计划的第 `i` 个源行乘 `Δ^ℓ/θ^ℓ`（分母零时取零），就给出 `\widehatη_V^(ℓ)` 至某 `s_V^(ℓ)≤τℓ` 的正计划，仍满足位移 `(mℓ+1)d`。这不是给整份原交通放大 kernel；它只把不重付的来源质量份额路由到某一份已建计划。空间支撑可以相交，质量份额之和准确为 `\widehatη`。

对每个 `ℓ`，跨叶相加后的 `s^(ℓ)` 仍满足 `s^(ℓ)≤τℓ`。记 `Wℓ=E‖\widehatη^(ℓ)‖`，则 `ΣWℓ=Wwidehatη`。依 §4 的 Cauchy 界并在有限尺度索引上再用一次 Cauchy，
\[
 \begin{split}
 T_{\widehat\eta}
 &\le C_2\sqrt{|E|}\sum_{\ell=1}^L
          F_\ell\sqrt{\tau_\ell W_\ell}\\
 &\le C_2\sqrt{|E|}
     \left(\sum_\ell F_\ell^2\tau_\ell\right)^{1/2}
     \left(\sum_\ell W_\ell\right)^{1/2}.
 \end{split}
\]
因此只要明确支付尺度预算
\[
 \sum_{\ell=1}^LF_\ell^2\tau_\ell\le B\lambda\sqrt n,
 \tag{D29}
\]
其中 `B` 与维数无关，就有
\[
 \boxed{
 T_\mu\le\epsilon X+
 \frac{BC_2^2}{4\epsilon}\sqrt n\,W_{\widehat\eta}
 +T_{\widehat\zeta}.}
 \tag{D30}
\]
这里没有再出现一个 `L`；尺度成本已完整记在 (D29)，并没有把多份目标容量当作同一份免费容量。

另一方面，`q^L≥θ^ℓ` 给 `\widehatζ_V≤ζ_V^[ℓ]`。所以所有尺度的真实余源条件同时保留：
\[
 \boxed{
 \widehat\zeta_V\left(V\setminus
                 \bigcap_{\ell=1}^LU_{A_V^{[\ell]}}\right)=0,
 \qquad
 \mathcal D_{m_\ell,\tau_\ell}(\mu_V)
   \ge\|\widehat\zeta_V\|\quad(1\le\ell\le L).}
 \tag{D31}
\]
每个 `U_A^[ℓ]` 的 `mℓ` 层邻域仍满足 (D13)。若再对共同余源 `\widehatζ` 做 §7 的 top-k，未付重尾会强迫**每一个**已列尺度满足
`\mathcal D_{mℓ,τℓ}(μ_V)≥‖\widehatζ_V‖>M_*+‖\widehatζ_V^top‖`。这是一份多尺度局部浓度必要条件，原输入、来源份额和所有实际门始终相同。

组合时以 (D30) **替代** (D20)，仅对 `\widehatζ` 应用 §7 的 top-k、低 tail-row 和轻尾窗口三个步骤，不再对 `\widehatζ` 重作流。于是直接得到
\[
 T_\mu\le(\epsilon+k\kappa_n+\delta)X
 +\frac{BC_2^2}{4\epsilon}\sqrt n\,W_{\widehat\eta}
 +A_n(\delta)W_{\widehat{\rm tail},\rm light}
 +T_{\widehat *}.
\]
这里 `T_{\widehat *}` 是共同余源 top-k 后重尾高真实 row 的原门交通，`W_{\widehat\eta}+W_{\widehat{\rm tail},\rm light}≤W_μ`；没有再次使用已经提取的来源质量或计划容量。

一个无需隐藏尺度数的具体表是：先取 `(m,τ)=(0,√nλ)`，再对每个整数
\[
 1\le m\le M_n:=1+\lfloor(\log n)/8\rfloor
\]
取 `(m,λ)`。利用 `F_{n,m}²≤e^{4(m+1)}` 和几何级数，有
\[
 \begin{split}
 F_{n,0}^2\sqrt n\lambda
    +\lambda\sum_{m=1}^{M_n}F_{n,m}^2
 &\le\left(e^4+\frac{e^8}{1-e^{-4}}\right)
          \lambda\sqrt n.
 \end{split}
 \tag{D32}
\]
故 (D30) 可取明确统一常数 `B=e^4+e^8/(1−e^{-4})`。共同余源同时由原 piece 高容量集合承载（`|U_A^[0]|≤K|V|/n`），并有厚度 `M_na/n` 的叶内邻域体积至多 `K|V|/√n`。前者的高质量测试作用于本节**原输入** `μ_V(P_i)>√nλ|P_i|`；不对进一步删除后的当前余质量重新断言同一阈值。对所有尺度构造、最大值和增量都只是有限可测操作，§6 已覆盖。

这个多尺度版本仍没有证明任何一个尺度必抽出固定质量比例；它提供的是付清尺度成本后的共同来源提取与同时残留证书。

## 9. 尚未闭合的确切位置

本文支付了一份由有限空间容量问题决定的真实子来源，不要求其格内密度有上界；并给所有未付来源一个可测的空间缺口证书及厚邻域界。这一结论覆盖任意当前叶来源，且对 `m>0` 允许质量进入相邻空格，严格扩大了逐 piece 原地均匀化的可行集合。

但这里没有证明 `W_η` 占 `W_μ` 的维数一致正比例，也没有证明 (D26) 的重尾不可能存在。缺口集可同时有很大的质量和很小的可达邻域。所获 `md=O(a log n/n)` 邻域体积上界不控制 `|(U_V+Q_{2a})∩V|`，更不能直接控制满足原 FULL 与真实高 row 的 `dx` 接收体积。因此不能由 (D13) 或 (D23) 推出 `T_*≲√n W_*`。

余项仍须保留原有限窗口的 `T_*≤(1+n log2)W_*` 包络。将本操作反复施于 `ζ` 会重新使用目标容量，且每轮另有接收误差和来源系数；本文不执行这种免费迭代。一般根阶高列核心仍未解决。

## R107：原软端与硬赢家共同空间分包

本节支付原软远尾，构造原软点与整个硬赢家共同落叶的几何事件，证明任意固定双来源的平方列付款，并保留明确的未付终端；未证明一般闭合。

## N1. 原联合表示与固定核

从未依赖下述新随机平移的原实际 `T=T_mid` 出发，保留原初始软来源 `y`、硬来源 `z`、完整历史、原森林种子、原 `σ,L_s,R,q`。更精确地，先把原历史积分但保留 `y`，对每个固定 `x,z,ω` 得到软端子测度 `Γ_{x,z,ω}(dy)`；原逐来源边际支配是 `Γ_{x,z,ω}(dy)≤q^{-1}P_{σ,L_s}(x−y)dμ_hi(y)`。因此规范联合交通由

\[
 \frac1q P_{\sigma(x),L_s(x)}(x-y)
 h_{R(x)}(x-z)\,d\mu_{\rm hi}(y)d\eta_\omega(z)dx,dP(\omega)
 \tag{N1}
\]

支配，且对每个固定 `x,z,ω`、任意原软来源可测集合 `B` 都有上述 `Γ(B)` 测度支配，并非只知总质量不超过一。实际历史门可能依赖两端，未假定接受后独立；(N1) 仅在取正上界时使用。所有门和原来源身份继续保留在实际交通中。`η_ω` 是 receiver 前冻结的 R105 中间段来源，`η≤μ_hi≤f dz`。`q∈[3λ/4,λ]` 是整个 `E` 上共同常数，两选择器同时继承同一固定窗口 `a≤L_s,R≤b≤2a`，`h_R f≤4λ≤C_hq`，`C_h=16/3`。记 `W_hi=E||μ_hi||`；当前原输入中 `μ_hi` 不依新种子，故该期望没有新增质量。

准确软核为

\[
 h=\mathbf1_{[-1/2,1/2]},\quad
 w(u)=\int_0^1 e^{-|u|/t}dt,
 \quad\phi=h*w,\quad
 \psi_s=(1-s)h+s\phi,\quad P_s=\psi_s^{\otimes n}.
 \tag{N2}
\]

`w` 是 Laplace 概率密度的混合：混合参数 `t∈(0,1)` 的概率密度为 `2t`。`h,φ` 都是偶函数且在正半轴单调不增；硬面取原闭面值。原出处是 tex 1200–1203、2095–2098；以下远尾界另给自含证明。

## N2. 一个完整全软度、全物理尺度的远软来源费

设 `U` 具有密度 `h`，`Z_t` 为尺度 `t≤1` 的 Laplace 变量。由 `|U|≤1/2`，

\[
 \int e^{|u|/2}h(u)du\le e^{1/4}<3/2,
 \qquad \mathbb E e^{|Z_t|/2}=(1-t/2)^{-1}\le2.
\]

因此 `φ` 为 `U+Z_t` 的混合密度及三角不等式给

\[
 \int e^{|u|/2}\phi(u)du\le2e^{1/4}<3.
 \tag{N3}
\]

这只是核先验积分，不是来源后验的独立性。令

\[
 F(v)=\prod_{i=1}^n[h(v_i)+\phi(v_i)].
\]

所有 `s∈[0,1]` 有 `P_s≤F`，并且

\[
 \int_{\|v\|_1>8n}F(v)dv
 \le e^{-4n}\int e^{\|v\|_1/2}F(v)dv
 \le(5e^{-4})^n.
 \tag{N4}
\]

现在取 `N=ceil(n log(b/a))`，物理网格

\[
 L_j=\min\{b,ae^{j/n}\},\qquad 0\le j\le N.
 \tag{N5}
\]

当 `a=b`，网格仅含 `a`。最后节点明确截到 `b≤2a`，没有借助越过原窗口的节点保留 `8n` 阈值。网格节点数 `N+1≤n log2+2`。任意 `L∈[a,b]` 有向上节点 `L_j≥L` 且 `L_j/L≤e^{1/n}`。由 `P_s` 沿每条射线不增，

\[
 P_{s,L}(v)\le eP_{s,L_j}(v)\le eL_j^{-n}F(v/L_j).
\]

对 `||v||_1>16na`，因为所有 `L_j≤2a`，有 `||v/L_j||_1>8n`。向上网格正求和、换元及 (N4) 因而给完整包络

\[
 \boxed{
 \int_{\|v\|_1>16na}
 \sup_{\substack{0\le s\le1\\a\le L\le b}}
 P_{s,L}(v)dv
 \le A_n^{\rm far}:=
 e(n\log2+2)(5e^{-4})^n.}
 \tag{N6}
\]

不存在软度网格费用：`F` 已同时支配全部软度。物理网格的全部节点费用则完整保留。可测性可直接由 (N5) 的有限正包络保证；实际原选择器仍为原可测版本，未重选 FIRST。

把实际原联合交通按 `||x−y||_1>16na` 与其补集分为 `T_far+T_near`。先在固定 `x` 对硬端取原行上界，再用原软边际支配，得到

\[
 \boxed{T_{\rm far}\le C_h A_n^{\rm far}W_{\rm hi}.}
 \tag{N7}
\]

`C_h` 只出现一次，来源仍是原 `μ_hi`；没有第一跳 reference 的因子二，没有额外 `q^{-1}`，也没有 `X` 误差。该收费只删原软端 `y` 的远距离子交通，不能改用 landing `w`。

## N3. 一个同时覆盖原软点与整个硬 cube 的随机叶

在 `T_near` 上加独立种子 `ξ`，沿 R106 density-tree 同一构造，但取新最细边长

\[
 s_*=cna,
 \qquad D=\min\{d\ge0:2^d s_*\ge(L-3)a\},
 \quad S=2^Ds_*,\quad\xi\sim\mathrm{Unif}([0,S)^n).
 \tag{N8}
\]

各层共用这个平移并二等分；`ξ` 独立于原输入、原森林、所有原历史和整个 `T_near`。不在已经依赖 `ξ` 的后续余项上重新宣称独立。

定义 `Good_2(x,y,ξ)` 为 `Q(x,R(x))∪{y}` 整体包含在同一个最细格中。每个坐标必须覆盖的区间长度为

\[
 \ell_i=R+(|x_i-y_i|-R/2)_+
 \le R+|x_i-y_i|.
\]

对固定原 `x,y,ω`，模 `s_*` 的各坐标平移独立均匀。一个坐标区间跨格面的概率为 `min(1,ℓ_i/s_*)`，端点相等为零概率。并集界给

\[
 \boxed{\mathbb P_\xi(Good_2^c)
 \le\min\left\{1,\frac{nR+\|x-y\|_1}{s_*}\right\}
 \le\frac{18}{c}\quad\text{on }T_{\rm near}.}
 \tag{N9}
\]

因为硬端实际 `z∈Q(x,R)`，`Good_2` 自动使 `y,z` 与整个赢家 cube 同格。最细格被所有祖先包含，故同一事件同时处理全部树层，不乘 `D`。在原完整联合测度上正 Tonelli 才得到

\[
 \boxed{T_{\rm bad,2}\le(18/c)T_{\rm near}.}
 \tag{N10}
\]

这不是原 hard-only 的 `2/c` 界；新增软点的代价不可漏掉。为保留小于 `1/8` 的吸收，可取

\[
 \boxed{c=256,\qquad18/c=9/128,\qquad
 (1-18/c)^{-1}=128/119.}
 \tag{N11}
\]

因此不能继续抄旧 `c=16` 或 `8/7` 的树系数。

树的来源质量始终按旧 `η` 冻结。先在质量 `m(Q)≤M_*:=λa^ne^{√n}` 时停止为轻节点；否则在 `m(Q)≥4λ(s_Q+2a)^n/√n` 时停止为密度节点；最后才在最细层终止。沿原 `b_0=β/2=1/12288` raw 捕获门，原两种停止付款仍成立，

\[
 P_{\rm stop}\le A_n^{\rm tree}W_{\rm stop},\qquad
 A_n^{\rm tree}=1+\sqrt n+\log(4/b_0^2).
 \tag{N12}
\]

理由是 `Good_2` 蕴含原 hard-only Good，且更小实际子交通可使用同一正上界；light/higher-density 的来源反链没有被重复收费。设 `T_{\rm term,2}` 是 `Good_2` 上终端叶交通，则

\[
 \boxed{T_{\rm mid}\le
 C_hA_n^{\rm far}W_{\rm hi}
 +\frac{128}{119}
 [A_n^{\rm tree}W_{\rm stop}+T_{\rm term,2}].}
 \tag{N13}
\]

远软费用在本模块吸收之前已剥离，故 (N13) 未再乘 `128/119`。终端叶 `V` 的新准确几何为

\[
 |V|=(256na)^n,\qquad
 M_*<\eta(V)<\frac{4λ((256n+2)a)^n}{\sqrt n},
 \quad\frac{\eta(V)}{|V|}<\frac{4e^{1/128}λ}{\sqrt n}.
 \tag{N14}
\]

每个实际终端联合对同时满足 `Q_R⊂V` 与原 `y∈V`。叶反链仍预先由硬来源质量选定，不把这项联合资格吸收进新来源。

若在叶内继续 fine-cell cap，原格边 `d=a/n`、扩张比 `e²` 和强 L² 常数均不变；高细格完整并 `S_V` 的体积界变为 `|S_V|<4e^{1/128}|V|/n`。叶内 cap、top-k 删除或低实际 row 付款若写为 `P_pre`，其费用在 (N13) 的终端括号内，必须整体再乘 `128/119`。这包括新增 `X` 误差，不能使用旧 `8/7` 或漏掉新吸收系数。

## N4. 任意固定两种来源的平方列引理：不要求原 parent

本节单独证明所需迁移。令 `α,ν` 为任意 receiver 前冻结的有限正测度，质量分别为 `M,m`，并保留同一原 `σ,L_s,R,q`。不要求 `α=ν`，不要求支撑在原 parent，也不要求其重新满足 FIRST。只取实际正子交通的上界

\[
 \frac1q(P_{\sigma,L_s}*α)(x)(h_R*ν)(x).
 \tag{N15}
\]

记 `β_0=3/(4e)`。由 (N2) 的偶单调性，`||φ||_∞=φ(0)`。其尾质量满足

\[
 1-\phi(0)=2\int_0^1te^{-1/(2t)}dt
 \ge2e^{-1}\int_{1/2}^1t\,dt=\frac3{4e}.
\]

故 `||φ||_∞≤1−β_0`、`∫φ=1`，所以

\[
 r(s):=\|\psi_s\|_2^2\le1-β_0s,
 \quad\|P_s\|_2=r(s)^{n/2},
 \quad\|\partial_sP_s\|_2\le n\sqrt2\,r(s)^{(n-1)/2}.
\]

第一式是 Hilbert 空间凸性；最后一式用 `||φ−h||_2≤√2` 及张量导数的 `n` 项三角不等式，没有使用来源后验坐标独立性。正 FTC、Tonelli 和 Cauchy–Schwarz 给任意 `s_0∈[0,1]`

\[
 \begin{aligned}
 \int\sup_{s_0\le s\le1}P_s(v)^2dv
 &\le r(s_0)^n+2n\sqrt2\int_{s_0}^1r(s)^{n-1/2}ds\\
 &\le C_{\rm BA}(1-β_0s_0)^n,
 \qquad C_{\rm BA}=1+\frac{2\sqrt2}{β_0}.
 \end{aligned}
 \tag{N16}
\]

形状 `G(v)=sup_{s≥s_0}P_s(v)^2` 沿射线不增。对任意具有此性质的非负可积 `G` 和 `ρ>0`，层蛋糕及沿射线积分给

\[
 \int\sup_{L\geρ}L^{-2n}G(v/L)dv
 \le2ρ^{-n}\int G.
 \tag{N17}
\]

具体地，对任一星形超水平集 `K`，`v∈ρK` 的起点贡献是 `ρ^{-n}|K|`；其外部把 `L` 取该射线上首次进入 `K` 的尺度，径向 `r^{-2n}` 积分也为 `ρ^{-n}|K|`。先将上确界移入非负层积分，得 (N17)。硬面上跳按闭面处理，不需要参数可微。

故任意固定 `ρ>0` 有

\[
 \int\sup_{\substack{s\ge s_0\\L\geρ}}P_{s,L}^2
 \le2C_{\rm BA}(1-β_0s_0)^nρ^{-n},
 \quad\int\sup_{R\geρ}h_R^2=2ρ^{-n}.
 \tag{N18}
\]

对来源有限测度分别使用 Jensen，得到对应软、硬卷积的平方积分分别不超过 (N18) 乘 `M²,m²`。再在真实 `dx` 空间用 Cauchy–Schwarz，遂有

\[
 \boxed{
 \frac1q\int_{\substack{x\in E,\ \sigma\ge s_0\\L_s,R\geρ}}
 (P_{\sigma,L_s}*α)(h_R*ν)dx
 \le C_{\rm mix}(1-β_0s_0)^{n/2}
 \frac{Mm}{qρ^n},
 \quad C_{\rm mix}=2\sqrt{C_{\rm BA}}.}
 \tag{N19}
\]

所有选择器只被相应固定包络支配；没有放大 `E` 后要求新 FIRST。`C_h` 不出现在 (N19)：本步没有先使用完整硬行帽。把 (N19) 用于原 leaf 而非原 parent 是合法的，原因正是证明只用了两份预冻结来源及其质量。

## N5. 双端共同叶内的实际尾质量付款

在 N3 的终端叶内完成已有正删支后，令 `ν_V` 为真正预冻结的硬尾来源，例如 fine-cap excess 再删该叶最大的 `k` 个旧出生细格来源。保留原 deep 门和所有 FULL 条件。`ν_V≤μ_hi|V`，不同叶的 `ν_V` 不交。

设 `T_tail,2` 为尚余原联合交通；每份来源对满足原 `y∈V` 与硬 `z∈V`。记

\[
 α_V=\mu_{\rm hi}|V,\qquad M_V=\mu_{\rm hi}(V),\qquad
 m_V=\nu_V(V).
 \tag{N20}
\]

`M_V` 可以远大于 `m_V`；二者不混同。对每个新格种子，终端叶构成反链，故 `Σ_V M_V≤W_hi`。这一步只有在原软端已限制于同一叶后才能对叶应用 (N19)，不会把同一 soft source 复制给很多 hard leaves。

原 soft 度带取

\[
 s_{\min}=\frac{\log2}{2n},\quad
 K_s=1+\lfloor\log_2(1/s_{\min})\rfloor,\quad
 s_j=2^js_{\min},\quad v_j=(1-β_0s_j)^{n/2}.
 \tag{N21}
\]

前 `K_s−1` 带为半开区间 `[s_j,s_{j+1})`，最后一带闭到 `1`。当前 FULL 原事件的 `σ>s_min` 已保留，不新增低软度删除。每个 receiver 只属一带。

对固定 `V,j` 及正 `m_V`，定义

\[
 ρ_{V,j}=\max\left\{a,
 \left(\frac{v_jm_V}{q\sqrt n}\right)^{1/n}\right\}.
\]

新平方列 paid 分支是

\[
 v_jm_V\le q\min(L_s,R)^n\sqrt n
 \quad\Longleftrightarrow\quad
 \min(L_s,R)\geρ_{V,j}.
 \tag{N22}
\]

`m_V=0` 时没有实际交通；`ρ>b` 时该分支为空；等号保留。将该实际分支先正放大到 (N15)，再在 (N19) 取 `s_0=s_j,ρ=ρ_{V,j}`，得

\[
 T_{V,j,\rm paid}\le C_{\rm mix}v_j
 \frac{M_Vm_V}{qρ_{V,j}^n}
 \le C_{\rm mix}\sqrt n M_V.
\]

对 disjoint leaves 求和、对原与新种子取平均，再对确有的 `K_s` 个带求和：

\[
 \boxed{T_{\rm tail,2}\le
 C_{\rm mix}K_s\sqrt n W_{\rm hi}
 +T_{\rm leaf,heavy}.}
 \tag{N23}
\]

没有原 forest 深度 `J` 或叶数因子。`K_s` 是实际使用多个固定软度尾包络的费用，不能以 receiver 带唯一为由删掉。每个分支的原 parent、strict CP/GP、失败币、出生、FIRST 和全部历史门始终保留；(N22) 是新的两份来源平方列付款判据，**没有把新 leaf 声称为原 parent，没有用 `m_V` 改写旧 CP/GP 的 `h(P)`**。

假设已有叶内模块实际证明 `T_term,2≤P_pre+T_tail,2`，则 N13 的准确接合为

\[
 \boxed{T_{\rm mid}\le C_hA_n^{\rm far}W_{\rm hi}
 +\frac{128}{119}\left[
 A_n^{\rm tree}W_{\rm stop}+P_{\rm pre}
 +C_{\rm mix}K_s\sqrt n W_{\rm hi}
 +T_{\rm leaf,heavy}\right].}
 \tag{N24}
\]

`P_pre` 的所有 source 与 `X` 费用均在括号内。本文件未把 R106 的 `c=16` 已算终式直接粘贴进 (N24)；采用时须按 N11、N14 更新同一次树构造的全部参数。

## N6. 与 distributed-tail 的确切联立及仍未付处

这里的实际尾行必须在 **新的 near、Good_2 以及当前 `ν_V` 尾来源** 上计算。固定原与新种子后，记

\[
 r_V(x)=\int h_{R(x)}(x-z)\int
  \mathbf1_{\{\|x-y\|_1\le16na\}}
  \mathbf1_{Good_2(x,y,\xi)}
  \Gamma^{\rm pre}_{x,z,\omega}(dy)\,d\nu_V(z),
\]

其中 `Γ^pre≤Γ` 保留所有原门及此前实际删支门。每个 `x` 最多有一个这样的活跃叶。对这个新量重新支付 `r_V≤δλ` 的行，费用至多 `δX`，列入 `P_pre`；不能继承 R106 hard-only 交通的旧 row cutoff。若 `P_pre` 已在此新量上使用 top-k、低实际 row 及轻尾源付款，则真实余项有

\[
 m_V>M_*=λa^ne^{\sqrt n},\qquad
 r_V(x)>δλ,\qquad
 \nu_V(C\cap V)\le m_V^{\rm before}/(k+1).
 \tag{N25}
\]

最后一式中的分子仍是删 top-k 之前的实际硬来源叶质量，不能改成 `m_V`。每份仍接受的旧细格还保留原 deep bound；`m_V>M_*` 不是当前赢家的捕获下界。

N23 进一步留下严格的真实尾质量条件

\[
 \boxed{m_V>q\min(L_s,R)^n\sqrt n/v_j.}
 \tag{N26}
\]

这是新原 soft–hard 共叶结构作用于 **实际 tail** 的约束，与原 CP 的旧父组质量不同。在新共叶的高实际 row 上，设

\[
 S_V=P_{\sigma,L_s}(\mu_{\rm hi}|V),\quad
 H_V=h_R\nu_V,\quad u=h_Rf.
\]

因为 `r_V≤S_VH_V/q`、`S_V≤q`、`H_V≤u≤4λ`，准确得到

\[
 \boxed{s_V:=S_V/q>δ/4,\qquad
 t_V^{\rm tail}:=H_V/u>δ/4,\qquad
 \nu_V(Q_R)>δλR^n.}
 \tag{N27}
\]

它们是由真实 row 下门推出的两份共同后验捕获，而非假设两者同分布。

若 `L_s≥R`，N26 和原 hard 行帽再给

\[
 \boxed{\frac{\nu_V(Q_R)}{m_V}
 <\frac{C_h v_j}{\sqrt n}.}
 \tag{N28}
\]

若 `L_s≤R`，准确的另一个小响应比是

\[
 \boxed{\frac{L_s^n S_V}{m_V}<\frac{v_j}{\sqrt n}.}
 \tag{N29}
\]

N29 的分母为实际硬尾质量，分子为原完整高软来源在该叶的响应，不能将其误称两者共同概率密度。

原 F1–F9 的禁同块约束现在可以在相同叶内收紧成

\[
 J_V(x,z)\le s_x(V\cap T(z))-s_x(V\cap A_x(z)),
 \tag{N30}
\]

因为所有实际 `y` 已在 `V`。其 `L_s≥R` 的 capture 平方下界仍成立，因为 `ν_V≤μ_hi|V` 且 `Q_R⊂V`。但是 N25 的分散 **叶总尾量** 没有自动给该 receiver 下 `Σ_A b_A²` 的强下界；也没有把原软后验换成 hard-tail 后验。真正尚余是同一 (N25)–(N30) 联合约束下 `T_leaf,heavy` 的来源预算。

本候选的已计算收益是 N7 的原软远尾费、N9 的双端共同叶几何，以及 N23 的原软质量—实际硬尾质量交叉付款。没有给 N28 的小捕获比例免费赋予源尾收缩，也没有宣称 distributed-tail 已整体付清。

## N7. 相对小尾叶付款与当前尾自身的 rank 界

仍使用 N20 的同一预冻结 `ν_V`、`m_V=ν_V(V)` 和 `M_V=μ_hi(V)`。不得在本节换成另一个未保留原门的近似尾源。置

\[
 H_n=1+n\log(b/a)\le1+n\log2,
 \qquad\mathcal L_{\rm rel}=\{V:m_V\le M_V/\sqrt n\}.
 \tag{N31}
\]

该测试只依两份固定来源的叶总质量，故先于当前 receiver。对每个这样的叶，删除软端及其它 `[0,1]` 门，有限窗口的完整硬核列积分给

\[
 T_{V,\rm tail,2}\le H_nm_V
 \le\frac{H_n}{\sqrt n}M_V.
 \tag{N32}
\]

这支付该叶的整个当前尾交通，包括 N22 的严格补集；不需要高 row、当前 capture、两端同分布或新 FIRST。它使用与 N25 相同的实际尾来源，`H_n` 不能换成未证明的根阶硬核列帽。因为这些叶的 `μ_hi|V` 不交，总费至多 `(H_n/√n)W_hi`，没有新 `X` 误差。

为避免重复收同一叶软来源，先整叶支付 `𝓛_rel`，只对其补集使用 N22 的平方列支付。令

\[
 W_{\rm rel}^{s}=\mathbb E\sum_{V\in\mathcal L_{\rm rel}}M_V,
 \quad W_{\rm comp}^{s}=\mathbb E\sum_{V\notin\mathcal L_{\rm rel}}M_V,
 \quad W_{\rm rel}^{s}+W_{\rm comp}^{s}\le W_{\rm hi}.
\]

当 `n≥512` 时，`H_n≤n`，而 `C_mix K_s≥1`，故 `H_n/√n≤C_mix K_s√n`。因此 N23 可在**同一个来源系数**下增强为

\[
 \begin{aligned}
 T_{\rm tail,2}
 &\le\frac{H_n}{\sqrt n}W_{\rm rel}^{s}
    +C_{\rm mix}K_s\sqrt n W_{\rm comp}^{s}
    +T_{\rm balanced,heavy}\\
 &\le C_{\rm mix}K_s\sqrt n W_{\rm hi}
    +T_{\rm balanced,heavy}.
 \end{aligned}
 \tag{N33}
\]

这里 `T_balanced,heavy` 同时保留 N25–N30 以及 `M_V<√n m_V`。N24 中仅将 `T_leaf,heavy` 换成这个真子交通，所有旧费用和 `128/119` 保持原位。所谓系数不增加来自两类叶的软来源反链账，绝不是给 N32 零价格。

若 `ν_V` 确为 N25 中那次 top-k 删除后的当前尾，则删前来源仍满足 `m_V^before≤M_V`。因此每个原出生细格都有

\[
 \boxed{
 \frac{\nu_V(C\cap V)}{m_V}
 \le\frac{m_V^{\rm before}}{(k+1)m_V}
 \le\frac{M_V}{(k+1)m_V}
 <\frac{\sqrt n}{k+1}.}
 \tag{N34}
\]

令 `p_{V,C}=ν_V(C∩V)/m_V`。它们非负且和为一，于是 `Σ_C p_{V,C}²<√n/(k+1)`，以及有效尾细格数 `(Σ_C p_{V,C}²)^{-1}>(k+1)/√n`。当右端小于一时，该限制可能无信息，未宣称所有参数都有实质收益。

(N34) 的分母是 **当前尾总量**，其合法性来自 N32 已实际支付所有相对小尾叶。没有直接把旧 top-k rank 的分母改名。这个结论仍只是叶内总来源的分布约束：它不给单个 receiver 的 `Σ_A b_A²` 下界，不把旧出生细格等同原 FULL 分区块，也不把两份来源总质量可比升级为后验概率分布可比。余项的一般根阶付款仍未证明。

## R107：共同软硬叶、多尺度来源运输与双来源付款的统一主式

本轮在原中间段上先支付远软端，再将原软点和整个硬赢家放入同一随机叶。在低均值叶中，用有限邻格流从同一原硬来源提取可运输的质量份额；余源依次经过原出生最大细格删除、真实低尾行及轻尾来源付款，最后按软硬两份叶质量支付相对小尾与平方列分支。所有新来源价格、尺度成本及接收误差均进入统一预算。最终仍保留一个明确的均衡重尾交通；没有证明一般根阶闭合。

## 1. 输入、原联合交通与旧起点

取原 FULL 适用维数 \(n\ge512\)，\(a,\lambda>0\)，原有限接收集 \(E\)，\(X=\lambda|E|\)。沿用原完整 \(f\ge0\)、真实 \(dx\)、全部原种子 \(\omega\)、原软度 \(s(x)\)、两个原物理选择器 \(L_s(x),R(x)\)，以及整个 \(E\) 上的共同常数
\[
 \frac34\lambda\le q\le\lambda,\qquad
 a\le L_s(x),R(x)\le b\le2a,\qquad
 P_{s(x),L_s(x)}f(x)=q,\qquad
 h_{R(x)}f(x)\le4\lambda\le C_hq,\quad C_h=16/3.
 \tag{R1}
\]
这里 \(h_R=R^{-n}\mathbf1_{[-R/2,R/2]^n}\)，\(Q_x=x+[-R(x)/2,R(x)/2]^n\)。令 \(\sigma_\omega\) 为 R105 走廊删除后、限制到原未付中间质量 canonical 盒并的冻结硬来源，\(\sigma_\omega\le\mu_{{\rm hi},\omega}\le f\,dz\)，并记
\[
 W_{\rm tree}=\mathbb E\|\sigma_\omega\|\le W_\mu,
 \qquad W_{\rm hi}=\mathbb E\|\mu_{{\rm hi},\omega}\|.
\]
软来源始终是原 \(\mu_{\rm hi}\)，不随后续硬来源提取而改成尾源。

保留原初始软来源点 \(y\)，在原历史积分后得到子测度核 \(\Gamma_{x,z,\omega}(dy)\)。实际交通为
\[
 T_{\rm mid}=\mathbb E_\omega\int_E\int h_{R(x)}(x-z)
       \int\Gamma_{x,z,\omega}(dy)\,d\sigma_\omega(z)dx.
 \tag{R2}
\]
规范原联合接口给逐硬来源、逐软集合的测度支配
\[
 \Gamma_{x,z,\omega}(dy)
 \le q^{-1}P_{s(x),L_s(x)}(x-y)d\mu_{{\rm hi},\omega}(y),
 \qquad 0\le\Gamma_{x,z,\omega}(\mathbb R^n)=G_0(x,z,\omega)\le1.
 \tag{R3}
\]
所有 FULL、FIRST、原 parent、strict CP/GP、出生 deep、失败币及实际历史门均已保留在 \(\Gamma\)。这是逐集合支配，不能只用总质量上界替代；也不假设接受后的软硬来源独立。软核取原
\[
 h=\mathbf1_{[-1/2,1/2]},\quad
 w(u)=\int_0^1e^{-|u|/t}dt,\quad\phi=h*w,\quad
 P_s=((1-s)h+s\phi)^{\otimes n}.
 \tag{R4}
\]
原出生细格全边长 \(d=a/n\)，\(H_C=\mu_{\rm hi}(C)\)、\(t_C=(H_C\sqrt n/(e^2q))^{1/n}\) 始终按旧输入定义。在正实际交通的细格上有
\[
 H_C<e^2qR(x)^ne^{-\sqrt n}/\sqrt n.
 \tag{R5}
\]

旧起点保持为
\[
 R_{\rm out}\le P_{104}+B_{105}W_\mu+X/768+T_{\rm mid},
 \qquad B_{105}=2+3\sqrt n+\log(16/\beta^2),\quad\beta=1/6144.
 \tag{R6}
\]
\(P_{104}\) 是旧已证明确价格，本轮不重新推导或放大它。

## 2. 先支付远软端，再吸收共同树边界

定义
\[
 A_n^{\rm far}=e(n\log2+2)(5e^{-4})^n.
\]
原软核的全软度、原物理窗口包络满足
\[
 \int_{\|v\|_1>16na}\sup_{0\le s\le1,\ a\le L\le b}P_{s,L}(v)dv
 \le A_n^{\rm far}.
 \tag{R7}
\]
该界来自软核指数矩、形状 \(\prod_i(h+\phi)\) 的统一软度支配，以及含至多 \(n\log2+2\) 个节点的向上物理网格；这些节点费用已包含在 \(A_n^{\rm far}\) 中。由 (R3) 先对硬端使用原 \(h_Rf\le C_hq\)，再按真实 \(dx\) 积分，
\[
 T_{\rm far}\le C_hA_n^{\rm far}W_{\rm hi}.
 \tag{R8}
\]
此处远端是原 \(y\) 满足 \(\|x-y\|_1>16na\)，不是过程后来的落地点。

在余下 near 联合交通上独立引入随机平移 \(\xi\)，取共同嵌套格的最细边长 \(cna\)，固定
\[
 c=256,\qquad\Lambda=(1-18/c)^{-1}=128/119.
 \tag{R9}
\]
树质量始终用 \(\sigma\)。先在节点质量不超过 \(M_*:=\lambda a^ne^{\sqrt n}\) 时轻停止，否则在质量至少为 \(4\lambda(s_Q+2a)^n/\sqrt n\) 时密度停止，其余继续至最细层。停止节点来源质量记为 \(W_{\rm stop}\)，终端叶记为 \(V\)。它们构成硬来源分区。

令 \(\operatorname{Good}_2(x,y,\xi)\) 表示 \(Q_x\cup\{y\}\) 整体落在同一个最细格。固定原 \(x,y\) 时，第 \(i\) 坐标所需区间长度至多 \(R+|x_i-y_i|\)，故在 near 上
\[
 \mathbb P_\xi(\operatorname{Good}_2^c)
 \le\frac{nR+\|x-y\|_1}{256na}\le\frac9{128}.
 \tag{R10}
\]
同一最细事件控制全部祖先层，没有树深度因子。此独立性只在原 near 联合交通上使用一次；不对已经依赖 \(\xi\) 的后续余项重用。令
\[
 A_n^{\rm tree}=1+\sqrt n+\log(4/b_0^2),\qquad b_0=\beta/2.
\]
原贡献门与两类停止节点的正付款给
\[
 \boxed{T_{\rm mid}\le C_hA_n^{\rm far}W_{\rm hi}
       +\Lambda\big[A_n^{\rm tree}W_{\rm stop}+T_{\rm term,2}\big].}
 \tag{R11}
\]
远软費在吸收前已剥离，不乘 \(\Lambda\)。

固定 \(\alpha=(\omega,\xi)\)。终端叶输入为 \(\sigma_V=\sigma_\omega|_V\)，具有
\[
 |V|=(256na)^n,\qquad
 M_*<\|\sigma_V\|<\frac{K_{256}\lambda}{\sqrt n}|V|,
 \qquad K_{256}=4e^{1/128}\le K:=4e^{1/8}.
 \tag{R12}
\]
实际终端的 \(Q_x\) 整体位于唯一叶，原 \(y\) 也在该叶。把 near、\(\operatorname{Good}_2\) 与终端资格乘入 \(\Gamma\)，记所得子测度为 \(\Gamma^2\)，并令
\[
 J_2(x,z,\alpha)=\int\Gamma^2_{x,z,\alpha}(dy).
 \tag{R13}
\]
于是 \(0\le J_2\le G_0\le1\)，且
\[
 T_{\rm term,2}=\mathbb E_\alpha\sum_V\int_E\int
                 J_2(x,z,\alpha)h_{R(x)}(x-z)d\sigma_V(z)dx.
 \tag{R14}
\]
每个 \(x\) 至多有一个非零叶行。\(J_2\) 保留实际软积分；不能用原 hard-only 的旧行密度替代它。后续任何硬来源子测度都使用这一固定 \(J_2\)。

## 3. 对同一硬输入支付全部运输尺度

在每叶中取 pieces \(P_i=C_i\cap V\)，按真实体积使用目标容量。参数表固定为
\[
 (m,\tau_m)=(0,\sqrt n\lambda),\qquad
 (m,\tau_m)=(m,\lambda),\quad1\le m\le M_n:=1+\lfloor(\log n)/8\rfloor.
 \tag{R15}
\]
对每个尺度都用同一原输入 \(\sigma_V\)：源容量 \(\sigma_V(P_i)\)，目标容量 \(\tau_m|P_j|\)，允许边 \(\|i-j\|_\infty\le m\)。有限最大流的残余可达 cut 记为 \(A_{V,m}\)，其来源集合及邻格并记为 \(U_{V,m}\)、\(N_{V,m}\)。精确缺口是
\[
 \mathcal D_{m,\tau_m}(\sigma_V)
 =\max_A\{\sigma_V(U_A)-\tau_m|U_{N_m(A)}|\}.
 \tag{R16}
\]
单尺度提取源记为 \(\eta_V^{[m]}\)，余源为 \(\zeta_V^{[m]}\)；最大流证明给
\[
 \|\zeta_V^{[m]}\|=\mathcal D_{m,\tau_m}(\sigma_V),\quad
 \zeta_V^{[m]}(V\setminus U_{V,m})=0,\quad
 |N_{V,m}|\le\frac{K_{256}\lambda}{\sqrt n\tau_m}|V|.
 \tag{R17}
\]

各尺度的提取源可能重叠，不能直接把质量相加。若其第 \(i\) 个 piece 提取比例为 \(\theta_i^{[m]}\)，依参数表顺序取运行最大值 \(q_i^{[m]}\)，并用增量 \(\Delta_i^{[m]}=q_i^{[m]}-q_i^{[m-1]}\) 定义真正的来源份额
\[
 d\widehat\eta_V^{(m)}=\sum_i\Delta_i^{[m]}\mathbf1_{P_i}d\sigma_V,
 \quad\widehat\eta_V=\sum_m\widehat\eta_V^{(m)},\quad
 \widehat\zeta_V=\sigma_V-\widehat\eta_V.
 \tag{R18}
\]
初始运行最大值为零。由于 \(0\le\Delta_i^{[m]}\le\theta_i^{[m]}\)，缩小该尺度原流的对应源行即得到这份增量的正运输计划；目标密度不超过 \(\tau_m\)，位移不超过 \((m+1)d\)。不同叶的目标 pieces 不交。

令
\[
 F_{n,m}=(1+2(m+1)/n)^n,\qquad
 B=e^4+\frac{e^8}{1-e^{-4}},\qquad
 W_{\widehat\eta}=\mathbb E_\alpha\sum_V\|\widehat\eta_V\|.
\]
具体表 (R15) 满足完整尺度预算
\[
 \sum_{m=0}^{M_n}F_{n,m}^2\tau_m\le B\lambda\sqrt n.
 \tag{R19}
\]
每尺度的正运输与原 \(R\ge a\) 给 \(A_R\widehat\eta^{(m)}\le F_{n,m}Ms^{(m)}\)。跨叶、真实 \(dx\) 与概率空间的 Cauchy–Schwarz，再对有限尺度求和用 Cauchy–Schwarz，得到
\[
 T_{\widehat\eta}\le C_2\sqrt{B\sqrt n\,W_{\widehat\eta}X}
 \le\frac{BC_2^2}{4\varepsilon}\sqrt n\,W_{\widehat\eta}+\varepsilon X,
 \quad\varepsilon>0.
 \tag{R20}
\]
\(C_2\) 是原已核固定 \(p=2\) 中心 cube 强型常数。所有尺度成本已在 \(B\) 内，没有免费删去尺度数。准确来源分解给
\[
 T_{\rm term,2}=T_{\widehat\eta}+T_{\widehat\zeta}.
 \tag{R21}
\]
本轮没有另外执行 R106 的全细格容量多数行付款。尤其 \(m=0\) 使用的是 \(\tau_0|C_i\cap V|\) 的 piece 容量，和旧逐叶使用完整 \(d^n\) 容量不同；它是 (R15)–(R20) 内的一份尺度，不能再收旧 cap 整行价格。

## 4. 最大细格删除、一次真实低尾行和轻尾窗口

固定有限整数 \(k\ge0\)，每叶按 \(\widehat\zeta_V(P_i)\) 选最大的至多 \(k\) 个正质量出生 pieces，等值按固定编号选择。定义
\[
 \widehat\zeta_V^{\rm top}=\widehat\zeta_V|_{\text{所选 pieces 并}},\quad
 \nu_V=\widehat\zeta_V-\widehat\zeta_V^{\rm top},\quad
 m_V=\|\nu_V\|,\quad
 W_{\rm top}=\mathbb E_\alpha\sum_V\|\widehat\zeta_V^{\rm top}\|.
 \tag{R22}
\]
该选择在 receiver 前冻结；原出生质量 \(H_C\) 和资格不重算。由 (R5)，每个参与旧细格的实际 \(J_2\) 行贡献至多 \(\kappa_n\lambda\)，其中
\[
 \kappa_n=e^2e^{-\sqrt n}/\sqrt n.
\]
每个 receiver 只见唯一叶，故 top 交通至多 \(k\kappa_nX\)。

固定 \(0<\delta\le1\)，以新联合门定义真实尾行
\[
 r_V(x,\alpha)=\int J_2(x,z,\alpha)h_{R(x)}(x-z)d\nu_V(z).
 \tag{R23}
\]
所有 \(r_V\le\delta\lambda\) 的尾交通合计至多 \(\delta X\)。不继承旧 hard-only 交通的任何低行 cutoff。余下高行满足
\[
 \delta\lambda<r_V\le R(x)^{-n}\nu_V(Q_x)\le R(x)^{-n}m_V.
 \tag{R24}
\]
将叶分为轻尾 \(m_V\le M_*\) 与重尾 \(m_V>M_*\)，记对应硬来源质量为 \(W_{\rm light}\)、\(W_{\rm heavy}\)。轻尾高行上原 \(R\) 落在固定窗口
\[
 a\le R\le\min\{b,(m_V/(\delta\lambda))^{1/n}\}.
\]
有限半径包络积分 \(1+n\log(r^+/a)\) 因而给
\[
 T_{\rm light,high}\le A_n^{\rm tail}(\delta)W_{\rm light},
 \qquad A_n^{\rm tail}(\delta)=1+\min\{n\log2,\sqrt n+\log(1/\delta)\}.
 \tag{R25}
\]
低于 \(\delta\lambda a^n\) 的尾质量没有高行；零来源叶同样为空。令 \(T_{\rm heavy,2}\) 为重尾叶高行的真实联合交通，则
\[
 \boxed{T_{\rm term,2}\le
 \frac{BC_2^2}{4\varepsilon}\sqrt nW_{\widehat\eta}
 +A_n^{\rm tail}(\delta)W_{\rm light}
 +(\varepsilon+\delta+k\kappa_n)X+T_{\rm heavy,2}.}
 \tag{R26}
\]
此后不再做硬来源列剥离，也不更换 \(\nu_V\)。因此下一步的尾质量与归一化分布始终来自 (R22) 的同一真实尾源。

## 5. 软来源单独分账：相对小尾与平方列

仅在重尾叶中定义原软来源与质量
\[
 \alpha_V=\mu_{{\rm hi},\omega}|_V,\qquad
 M_V=\|\alpha_V\|,\qquad0<m_V\le M_V.
 \tag{R27}
\]
对每个样本这些叶不交，故 \(\mathbb E\sum_VM_V\le W_{\rm hi}\)。\(M_V\) 不等于树的硬输入质量 \(\|\sigma_V\|\)。由 (R3) 和共叶资格，原联合交通的正上界是
\[
 q^{-1}(P_{s,L_s}\alpha_V)(x)(h_R\nu_V)(x).
 \tag{R28}
\]
这只在付款时作正上界；保留的实际余项继续使用 \(\Gamma^2\)。

先整叶支付
\[
 \mathcal H_{\rm rel}=\{V:m_V>M_*,\ m_V\le M_V/\sqrt n\}.
\]
令 \(H_n=1+n\log2\)。其真实尾交通至多 \(H_nm_V\)，因此收费
\[
 \frac{H_n}{\sqrt n}W_{\rm rel}^s,\qquad
 W_{\rm rel}^s=\mathbb E\sum_{V\in\mathcal H_{\rm rel}}M_V.
 \tag{R29}
\]
该步骤没有新 \(X\) 费。只在互补重尾叶
\[
 \mathcal H_{\rm comp}=\{V:m_V>M_*,\ M_V<\sqrt n m_V\},\qquad
 W_{\rm comp}^s=\mathbb E\sum_{V\in\mathcal H_{\rm comp}}M_V
\]
使用下一份平方列付款；于是 \(W_{\rm rel}^s+W_{\rm comp}^s\le W_{\rm hi}\)。

定义明确常数及原软度带
\[
 \beta_0=3/(4e),\quad C_{\rm BA}=1+2\sqrt2/\beta_0,\quad
 C_{\rm mix}=2\sqrt{C_{\rm BA}},
\]
\[
 s_{\min}=\frac{\log2}{2n},\quad
 K_s=1+\lfloor\log_2(1/s_{\min})\rfloor,\quad
 s_j=2^js_{\min},\quad v_j=(1-\beta_0s_j)^{n/2},\quad0\le j<K_s.
 \tag{R30}
\]
前面各带是 \([s_j,s_{j+1})\)，末带闭至 \(1\)；原 FULL 已有 \(s(x)>s_{\min}\)。对任意两份预冻结来源 \(\alpha,\nu\)，质量 \(M,m\)，原软硬双核的平方包络给
\[
 \frac1q\int_{\{s\ge s_j,\ L_s,R\ge\rho\}}
 (P_{s,L_s}\alpha)(h_R\nu)dx
 \le C_{\rm mix}v_j\frac{Mm}{q\rho^n}.
 \tag{R31}
\]
它只依两份来源及质量，不要求新叶是原 parent。对每个 \(V,j\) 取
\[
 \rho_{V,j}=\max\{a,(v_jm_V/(q\sqrt n))^{1/n}\}.
\]
于是可付的实际行判据是
\[
 v_jm_V\le q\min\{L_s(x),R(x)\}^n\sqrt n.
 \tag{R32}
\]
在该分支用 (R31) 给 \(C_{\rm mix}\sqrt nM_V\)。跨叶反链共享软质量，跨 \(K_s\) 带则保留全部价格。记严格补集的实际交通为 \(T_{\rm balanced,heavy}\)，则
\[
 \boxed{T_{\rm heavy,2}\le
 \frac{H_n}{\sqrt n}W_{\rm rel}^s
 +C_{\rm mix}K_s\sqrt nW_{\rm comp}^s
 +T_{\rm balanced,heavy}
 \le C_{\rm mix}K_s\sqrt nW_{\rm hi}+T_{\rm balanced,heavy}.}
 \tag{R33}
\]
最后一步用 \(n\ge512\) 时 \(H_n\le n\) 与 \(C_{\rm mix}K_s\ge1\)。两个价格可以在软来源反链分账后取最大；不是免费支付相对小尾。\(K_s\) 不能因为每个 receiver 只属一个带就删去，因为每带使用的是不同固定软度尾包络。

## 6. 完整一般定理与质量预算

对上述任意原合法输入、任意 \(\varepsilon>0\)、\(0<\delta\le1\) 及有限整数 \(k\ge0\)，构造均联合可测，来源质量有精确恒等式
\[
 \boxed{W_{\rm stop}+W_{\widehat\eta}+W_{\rm top}
          +W_{\rm light}+W_{\rm heavy}=W_{\rm tree}\le W_\mu.}
 \tag{R34}
\]
其中多尺度提取与余源按正测度份额相加，允许同一点上的支撑重叠。\(W_{\rm top}\) 对应交通已经由 \(k\kappa_nX\) 支付，不能从质量账本消失。平方列是接收行分支，不将 \(W_{\rm heavy}\) 再假分为互不重用的“已付来源”与“余来源”。

结合 (R6)、(R11)、(R26)、(R33)，本轮完整主式为
\[
\boxed{
\begin{aligned}
 R_{\rm out}\le{}&P_{104}+B_{105}W_\mu+C_hA_n^{\rm far}W_{\rm hi}\\
 &+\left[\frac1{768}+\frac{128}{119}(\varepsilon+\delta+k\kappa_n)\right]X\\
 &+\frac{128}{119}\left[
 A_n^{\rm tree}W_{\rm stop}
 +\frac{BC_2^2}{4\varepsilon}\sqrt nW_{\widehat\eta}
 +A_n^{\rm tail}(\delta)W_{\rm light}
 +C_{\rm mix}K_s\sqrt nW_{\rm hi}
 +T_{\rm balanced,heavy}\right].
\end{aligned}}
 \tag{R35}
\]
这里 \(B,C_h,C_2,C_{\rm mix},K_s,A_n^{\rm far},A_n^{\rm tree},A_n^{\rm tail},\kappa_n\) 均已显式定义。更精细版本用 (R33) 第一行保留 \(W_{\rm rel}^s,W_{\rm comp}^s\) 的不同价格。

令
\[
 K_{\rm hard}=\max\{A_n^{\rm tree},BC_2^2\sqrt n/(4\varepsilon),A_n^{\rm tail}(\delta)\}.
\]
主式内三份已付硬来源费用可界为
\[
 K_{\rm hard}(W_{\rm tree}-W_{\rm top}-W_{\rm heavy}).
 \tag{R36}
\]
原软来源 \(\mu_{\rm hi}\) 与硬来源通常重叠，不能把 (R35) 的 \(W_{\rm hi}\) 费用放进这个最大值。远软与共叶平方列两笔同用软来源，其系数也须相加。旧 \(P_{104},B_{105}W_\mu,X/768\) 以及吸收前的远软费用均不乘 \(128/119\)；所有树后的新费、\(X\) 误差和余项均乘它。

## 7. 最终余项的准确联合几何与所有尺度证书

对 \(V\in\mathcal H_{\rm comp}\)，令 \(j(x)\) 为原软度所属带。最终余项准确为
\[
\begin{aligned}
 T_{\rm balanced,heavy}
 =\mathbb E_\alpha\sum_{V\in\mathcal H_{\rm comp}}\int_E
 &\mathbf1_{\{r_V(x)>\delta\lambda\}}
 \mathbf1_{\{v_{j(x)}m_V>q\min(L_s,R)^n\sqrt n\}}\\
 &\cdot\int h_{R(x)}(x-z)\int\Gamma^2_{x,z,\alpha}(dy)d\nu_V(z)dx.
\end{aligned}
 \tag{R37}
\]
所有门都使用原选择器与固定 \(q\)。\(\Gamma^2\) 保留原 FULL/历史/CP/GP/deep、near、共同好叶和终端标签。之后的两份判据只依叶及 receiver，未改变尾来源。因此保留行仍确有 (R24) 的真实行下界，而非仅有删支前的行下界。

每个余项叶及活跃行同时满足
\[
 m_V>M_*,\qquad m_V\le M_V<\sqrt n m_V,\qquad
 v_jm_V>q\min(L_s,R)^n\sqrt n,\qquad Q_x\subset V,
 \quad y\in V.
 \tag{R38}
\]
定义 \(S_V=P_{s,L_s}\alpha_V\)、\(H_V=h_R\nu_V\)、\(u=h_Rf\)。由 \(r_V\le S_VH_V/q\)、\(S_V\le q\)、\(H_V\le u\le4\lambda\)，得到
\[
 S_V/q>\delta/4,\qquad H_V/u>\delta/4,\qquad
 \nu_V(Q_x)>\delta\lambda R^n.
 \tag{R39}
\]
若 \(L_s\ge R\)，还有 \(\nu_V(Q_x)/m_V<C_hv_j/\sqrt n\)；若 \(L_s\le R\)，则 \(L_s^nS_V/m_V<v_j/\sqrt n\)。两种量的分子不同，不能把软响应误称硬尾的概率密度。

设 \(m_V^{\rm before}=\|\widehat\zeta_V\|\)。top-k 的固定排序和 \(m_V^{\rm before}\le M_V\) 给当前硬尾的归一化细格分布
\[
 p_{V,C}:=\frac{\nu_V(C\cap V)}{m_V},\qquad
 \sum_Cp_{V,C}=1,\qquad
 p_{V,C}\le\frac{m_V^{\rm before}}{(k+1)m_V}
            \le\frac{M_V}{(k+1)m_V}<\frac{\sqrt n}{k+1}.
 \tag{R40}
\]
故 \(\sum_Cp_{V,C}^2<\sqrt n/(k+1)\)，其倒数大于 \((k+1)/\sqrt n\)。这是**当前硬尾**的归一化限制；两来源质量可比不赋予原软来源同样的归一化 rank，也不赋予每个 receiver 的后验分布同样限制。

由于 \(\widehat\zeta_V\le\zeta_V^{[m]}\)，所有尺度 cut 同时保留在同一尾源上：
\[
 \nu_V\left(V\setminus\bigcap_{m=0}^{M_n}U_{V,m}\right)=0,
 \qquad
 \mathcal D_{m,\tau_m}(\sigma_V)\ge\|\widehat\zeta_V\|
 =m_V+\|\widehat\zeta_V^{\rm top}\|
 >M_*+\|\widehat\zeta_V^{\rm top}\|.
 \tag{R41}
\]
每个缺口的输入始终是运输之前的 \(\sigma_V\)，不能换成当前尾源重新领取目标容量。\(m=0\) 的承载集合是原 piece 高容量并
\[
 U_{V,0}=\bigcup_{i:\sigma_V(P_i)>\sqrt n\lambda|P_i|}P_i,
 \qquad |U_{V,0}|\le K_{256}|V|/n.
 \tag{R42}
\]
对 \(1\le m\le M_n\)，开厚邻域满足
\[
 \left|(U_{V,m}+(-ma/n,ma/n)^n)\cap V\right|
 \le|N_{V,m}|\le K_{256}|V|/\sqrt n.
 \tag{R43}
\]
交集承载集的各尺度厚邻域也受相应右端控制。这是叶内、厚度最多 \(M_na/n\) 的真实邻域界，不是半径 \(a\) 的接收 halo。高容量测试、cut 与缺口均针对原 \(\sigma_V\)，不声称当前 \(\nu_V(P_i)\) 仍高于任何目标容量。

原禁同块资格可在实际共叶子门中保留为
\[
 J_{2,V}(x,z)\le s_x(V\cap T(z))-s_x(V\cap A_x(z)),
 \qquad s_x(B)=q^{-1}P_{s,L_s}(\mu_{\rm hi}|B)(x),
 \tag{R44}
\]
其中 \(T(z),A_x(z)\) 仍是原森林和原来源定义的 top 与禁同块，未把新叶或新尾量代入旧 CP/GP。此约束、两源捕获 (R39)、硬尾 rank (R40) 与全部局部浓度缺口 (R41) 是同一实际余项的联合限制；不能从其中任一条免费推出一般费用。

有限余项始终有
\[
 \boxed{T_{\rm balanced,heavy}\le H_nW_{\rm heavy}.}
 \tag{R45}
\]
也可把右端限制为 \(\mathcal H_{\rm comp}\) 的硬尾质量，但不能将 \(H_n\) 改为未证明的根阶列价。本文没有证明某尺度必抽出固定来源比例，没有证明所有尾叶相对变轻，也没有从小厚邻域或归一化 rank 推出原 CP/GP 的接收平方缺口。一般 \(n^{1/2+o(1)}\) 目标仍未闭合。

所有新构造来自有限可测树、piece 质量、可测最大流及 cut、有限运行最大值和固定编号排序；接收筛选均为原可测积分的阈值测试。它们没有按当前 receiver 重选来源，没有核高度放大，没有免费重复运输目标容量，也没有新增未计的叶数或树深度费用。

## R107 numerical protocol — FROZEN; PRODUCER, EXACT VERIFIER, INDEPENDENT AUDIT AND ISOLATED REPLAY PASS

## Fixed scope and two levels of verification

The three newly specified compactly supported, non-atomic L1 families below test the distributed-source maxflow/cut/transport lemma, including its multiple-scale running maximum. All have a=λ=R=1, d=1/n, k=√n, f=g≥0 and μ=(g−k)+. A real receiver box E is fixed before all routing decisions, Q(x,1) lies wholly in one leaf V on E, A1f=3, and A1μ is explicitly constant on E. Sources, peaks, full physical volumes and actual dx traffic are retained. These are actual geometric transport-lemma inputs, not merely abstract solver graphs. They do not construct the original FULL/FIRST forest or certify original component/corridor provenance. No original joint soft–hard source is constructed, so fullgate_next.md N7/N23/N24 is outside this numerical menu; its c=256 and 128/119 are not mixed into these c=16 leaves.

Every V has side s=16n. The current finite-flow lemma requires μ(V)≤4e^(1/8)|V|/√n; each example will certify the stronger rational μ(V)≤4|V|/√n. We do not require or claim that these leaves were generated by an original random stopping tree. J=1_E on captured source pairs, and T=∫E A1μ dx. The original input μ and E are unchanged across the parameter list; scales do not repeatedly operate on a previous residual. The verified scope is the geometric transport/payment D20 and running-max D27–D31, which do not need a birth-deep assumption. No deep gate, D24 top-k conclusion or all-original-D3-gates instance is certified: in stage 1 the full-f cell mass is 3, exceeding the q=1 deep threshold e, so that example explicitly fails that extra condition.

For a scale (m,τ), P_i=C_i∩V and target capacity is exactly β_i=τ|P_i|. A source piece has α_i=μ(P_i); zero-source pieces remain available as targets. Allowed transport has ||i−j||∞≤m and stays within V. The finite network uses source→i capacity α_i, i→j capacity B=μ(V)+τ|V|, and j→sink capacity β_j. MATLAB supplies a candidate flow only. Python Fraction independently verifies every capacity, sign, allowed edge, conservation equation, total flow, exact residual reachable cut, residual-source support, and flow=cut. No floating objective or solver status by itself is a certificate.

## Exact tensor compression and the graph actually solved

In all three stages, the source is a finite union of first-coordinate microintervals, with constant density along all transverse coordinates of V. Write V=I×V_perp, L=|V_perp|=s^(n−1), with L=1 when n=1. The reduced first-coordinate piece P_i^1=C_i^1∩I has length l_i, source mass a_i=μ(P_i^1×V_perp)/L, and target mass b_j=τl_j. Solve this rational one-dimensional neighbor graph with |i−j|≤m.

This is an exact reduction, not an uncontrolled approximation. Given a reduced flow f_ij, for each transverse clipped grid piece P_p^perp of volume v_p assign full-grid flow f_ij v_p from (i,p) to (j,p), using identical transverse indices. Then full source/target masses are a_i v_p and τl_j v_p, and all full nD neighbor constraints hold. The total lifted flow is LΣf_ij. Conversely, sum any full nD flow over transverse indices: its first-coordinate source and target marginals satisfy the same reduced constraints with total capacities multiplied by L. A reduced cut A lifts to A×all transverse pieces, whose full target neighborhood is exactly N_m(A)×V_perp. Thus the same feasible flow and cut prove the exact full-grid optimum, even though many cross-transverse allowed edges were not needed by the chosen flow.

Only positive source indices and their reachable target indices need be stored. All other sources have zero mass and all omitted targets have no edge from any positive source; they cannot increase the objective or change the cut. Their volume remains in |V| and in the finite internal capacity B. The reduced internal capacity is B_red=Σa_i+τs; multiplying by each transverse volume gives a valid nonbinding internal edge capacity, and the lifted flow is also feasible under the original full B. No tensor dimension is normalized out of the physical report.

## Stage 1: n=1, elementary extraction and exact optimal cut

Let V=[0,16), C_i=[i,i+1), and H=[59/8,61/8)⊂C_7. Set f=g=12·1_H, μ=11·1_H. Use E=[57/8,63/8], so every length-one receiver interval contains H and lies in V. Then |H|=1/4, |E|=3/4, W_f=3, W_μ=11/4, initial point-cap mass=1/4, A1f=3, A1μ=11/4 and T=33/16.

Frozen ordered scales: (m,τ)=(0,1),(1,1). At scale zero the only target C_7 has capacity 1, so expected exact optimum is 1 and cut residual 7/4. At scale one targets C_6,C_7,C_8 have total capacity 3, so expected optimum is 11/4 and residual zero. The source extraction fractions are 4/11 and 1; running-max increments are 4/11 and 7/11. This gives positive additional extraction and fully paid final source. Multiply all reduced capacities by 4 for the integer MATLAB network (source capacity 11, target capacities 4); the scaling is inverted exactly in Python.

Run both digraph.maxflow and linprog on these two small graphs. The LP solves the same allowed source-to-target edge-variable transportation constraints with objective −Σf_ij, A containing source-row and target-column sums, b containing the scaled integer capacities, and no equality constraints or additional upper bounds. The fixed call is linprog(-ones(edge_count,1),A,b,[],[],zeros(edge_count,1),[],r107LPFixedOptions), where r107LPFixedOptions uses Algorithm='dual-simplex-highs', Display='none'. Its status/objective/flow are saved as candidate data, not separately counted as another geometric experiment. Each returned near-integer edge candidate is accepted only after the fixed integer reconstruction and full exact verification below. Compare the two exact objective values; do not require identical optimal routes.

## Stage 2: n=4, clipped leaf boundaries and concentrated density

Here d=1/4, k=2, s=64 and V=[1/8,64+1/8)^4. Original grid C_i=d(i+[0,1)^4). In coordinate one, the first piece P_0^1=[1/8,1/4) has length 1/8, not d; the last is likewise clipped. Let H=[3/16,1/4)×[1/8,64+1/8)^3, f=g=48·1_H, μ=46·1_H. The source occupies only the upper half of the first clipped piece, with a genuine point peak well above k.

Take E=[5/8,11/16]×[5/8,63+5/8]^3. Then each Q(x,1) lies in V and contains the full source microinterval in coordinate one. |E|=(1/16)63^3, |H|=(1/16)64^3, W_f=3·64^3, W_μ=(23/8)64^3, initial point-cap mass=(1/8)64^3, A1f=3 and A1μ=23/8. T=(23/128)63^3.

Frozen ordered scales: (0,2),(1,1). Reduced source mass a_0=23/8. At scale zero target capacity is 2·(1/8)=1/4 and exact optimum is 1/4. At scale one the reachable clipped+full target lengths are 1/8 and 1/4, so exact optimum is 3/8. Hence θ^0=2/23, θ^1=3/23 and running-max increments 2/23,1/23. Final reduced residual is 5/2, strictly positive; N_1(A) has actual first-coordinate length 3/8. The full positive residual is (5/2)64^3 and full cut-neighborhood volume is (3/8)64^3. Integer capacities use scale 8. This explicitly catches the incorrect use of full d-volume for a clipped target, including all clipped transverse pieces through the tensor proof.

Only digraph.maxflow runs for these graphs. Actual extracted and residual traffic use each source fraction times the complete original μ-row; |E| is never replaced by a source volume. Verify the positive transport contribution, positive surviving original traffic, exact source ledger, and the genuine leaf-intersected thick-neighborhood inclusion.

## Stage 3: n=1024, high-dimensional tensor lift and genuine running-max pressure

Set d=1/1024, k=32, s=16384, V=[0,s)^n and transverse volume L=s^1023. Positive source first-coordinate indices are i=0 and i=4. In each C_i^1 use H_i=[(i+1/4)d,(i+3/4)d), of length d/2. Set H=(H_0∪H_4)×[0,s)^1023, f=g=3072·1_H and μ=3040·1_H. Thus |H|=dL, W_f=3L, W_μ=(95/32)L and initial point-cap mass=(1/32)L. Each reduced source mass is 95/64 and every reachable target has length d.

Use E=[1/2,1/2+d/4]×[1/2,s−1/2]^1023. Every Q(x,1) lies in V and contains both microintervals; A1f=3, A1μ=95/32, |E|=(d/4)(s−1)^1023, and T=(95d/128)(s−1)^1023. The shortened first-coordinate receiver interval is a real physical volume and remains in every traffic value.

Frozen ordered scales: (0,5/2),(1,1),(2,1). This uses the general finite parameter-list theorem D27–D31, not the particular D32 menu: at n=1024, D32 has M_n=1, so the m=2 experiment carries its own additional exact scale cost below and is not called the D32 root menu. Integer capacity scale is 2048, giving source capacity 3040 at each source. Each target has integer capacity 5 at m=0 and capacity 2 at m=1,2. The first-coordinate target unions have 2,5,7 members. Expected exact maximum flows are 5d,5d,7d, with positive defects (95/32)−5d, (95/32)−5d, (95/32)−7d. The cuts include both source nodes at every scale.

At m=0 each source sends exactly (5/2)d. At m=1 the boundary source i=0 has only targets 0 and 1, so it sends 2d; the source i=4 has targets 3,4,5 and sends 3d. The second-scale running maximum therefore extracts ((5/2)+3)d=(11/2)d, strictly exceeding both scalar maxima 5d while being strictly below their sum 10d. This tests the piecewise maximum rather than merely a monotone increase in all source rows. At m=2 the target index 2 is shared by both source neighborhoods and receives its capacity only once.

All later source fractions come from the verified candidate. Tie-dependent optimal routes need not coincide between solvers or MATLAB versions. Compute q_i^ℓ=max(q_i^(ℓ−1),θ_i^ℓ), Δ_i^ℓ=q_i^ℓ−q_i^(ℓ−1), row-scaled increment plans f_ij^ℓ·Δ_i^ℓ/θ_i^ℓ and final residual a_i(1−q_i^L), all as exact Fraction. The first two running-max totals are exactly 5d and (11/2)d; the third lies in [7d,(15/2)d], depending on the allocation of shared target 2. Thus each increment is positive. Do not replace the final running-max mass by the largest scalar optimum or the sum of optimum masses. Verify positive final residual, support in the intersection of all cuts, and domination of final residual by every single-scale defect.

## Common transport, real receiver, and payment ledger

For every certified scale and running-max increment, the full positive plan is the distributed.md formula using the actual nonuniform μ inside source pieces and uniform target piece density. Verify source marginal, target marginal, s≤τ, total mass equality and coordinate displacement≤(m+1)d from exact interval endpoints. For the actual receiver set E, all source microintervals are captured and transverse unit cubes stay inside V. Extraction fractions depend only on the first-coordinate piece. Consequently the exact original, each increment, and final residual row densities are constant on E and are computed from their first-coordinate extracted masses. Their dx integrals add exactly to T. This is a genuine receiver check, not a substitute receiver probability measure.

Also verify direct positive transport domination η^(ℓ)(Q(x,1))≤∫_{Q(x,1+2(m+1)d)}s^(ℓ) for every x∈E. It suffices to check exact first-coordinate interval inclusion for every routed source–target pair; in transverse coordinates, the full uniform target marginal factors and the expanded cube covers at least one unit length inside V for each x∈E. This analytically verifies all receivers in E, not a floating sample of receiver points. Record the actual R=1, expanded full side 1+2(m+1)d, and exact F_nm=(1+2(m+1)/n)^n.

Report the full frozen scale budget B_n=(ΣℓF_nmℓ²τℓ)/√n and do not drop scale counts or target capacities. The three menus satisfy the simple common upper bound B_n<e^4+e^8+e^12, because m≤2 and τ≤√n. This is a paid common bound, not an optimized constant. Keep C2 symbolic and choose one fixed ε=1/100; display εX+[C2²ΣF²τ/(4ε)]W_hatη+T_hatζ with X=|E|. Do not numerically invent C2, discard εX, or infer a dimension-uniform extracted fraction from these examples. No tree boundary absorption factor is used because the leaf is given as a deterministic transport-lemma input.

## Fixed tools, exactness, stops and execution budget

MATLAB R2026a digraph.maxflow supplies each frozen graph candidate, with integer capacities below 2^53; its default algorithm is used without adaptive retries. Stage 1 additionally runs linprog with Algorithm='dual-simplex-highs', Display='none', recorded in the candidate file. No graph topology, density, dimension, receiver box or parameter list changes after approval. Save all original edge capacities and returned directed flows in compact JSON, including MATLAB version and solver return data.

Python builds exact inputs using Fraction, then verifies MATLAB output independently. Raw numeric capacities/flows must lie within 10^−9 of an integer; nearest-integer reconstruction is only a proposal, and all capacity/conservation/cut/transport equalities must subsequently pass exactly. Any failed reconstruction or equality yields UNKNOWN and stops; no parameter scan, different solver option, rounding relaxation or precision escalation follows. linprog is cross-check candidate generation only; the exact verifier gives its own independent capacity/conservation/objective certificate and compares the exact graph optimum established by maxflow/cut.

Only exp parameters {4,8,12} are evaluated, each with exactly 256 Taylor terms and a geometric remainder t^256/256!/(1−t/257). No floating log/exp enters certificates. Giant physical quantities retain exact Fraction values; compact output uses exact expressions, numerator/denominator SHA256 and directed integer log10 brackets obtained by comparisons to powers of ten. Ratio decimals use fixed 18-place rational outward enclosures. Tensor repetition counts and physical volumes are explicit.

After parent plus independent protocol PASS: write Python input/verifier and MATLAB script; perform static checks; one Python input-build invocation, one MATLAB producer invocation for this fixed menu (7 maxflow calls and 2 stage-1 linprog calls inside it), one Python verification invocation, and one parent isolated replay of verification using the saved candidates. The MATLAB producer never reruns during isolated verification replay. Report solver failure/UNKNOWN instead of substituting an unapproved menu. A technical tool-call issue before executing the script may be corrected without changing mathematical inputs, with an explicit receipt; once a research solver run begins, no new research run occurs without reporting the limitation first.

## Single-producer results

The fixed execution completed without a retry: seven MATLAB maxflow calls and two stage-1 linprog calls, followed by one Python exact verification. All **688 code checks passed**; this count includes geometry, reconstruction, conservation, cut, display and bookkeeping checks, not 688 independent mathematical experiments. The two LP candidates reached the independently certified min-cut values exactly after integer reconstruction. MATLAB static analysis reported no code issues.

All entries in the next table are reduced first-coordinate masses; every physical source mass is multiplied by L=(16n)^(n−1), and every actual traffic is multiplied by the stated |E|. These factors remain in numeric_output.json and are never set to one in the mathematical result.

| Stage | Exact scale optima | Exact running-max extraction after each scale | Final extracted fraction of original μ and T | Final original-source residual |
|---|---|---|---|---|
| n=1 | 1, 11/4 | 1, 11/4 | 1 | 0 |
| n=4 | 1/4, 3/8 | 1/4, 3/8 | 3/23 | (5/2)L, with traffic (5/2)|E| |
| n=1024 | 5d, 5d, 7d | 5d, (11/2)d, 7d | 7/3040 | (3033/3040)Wμ, with traffic (3033/3040)T |

For n=1024, the first two source fraction vectors returned by MATLAB are `(1/608,1/608)` and `(1/760,3/1520)`. Their componentwise maximum is `(1/608,3/1520)`, proving a real gain over either scalar optimum. The third vector is `(3/1520,1/380)`; its increment over the previous maximum is `(1/3040,1/1520)`. Target index 2 is charged once, and all increment plans remain bounded by their original per-scale target capacities. Positive common residual remains after all three scales.

The boundary test uses target length 1/8 at the first clipped n=4 piece; its scale-zero capacity is 1/4, and scale-one total reachable length is 3/8. The n=1024 receiver volume is exactly `(d/4)(16383)^1023`; the total traffic is `(95d/128)(16383)^1023`. Thus no thin receiver volume, high-dimensional transverse factor, εX payment, or positive cut residual was discarded. The result remains a validation of these structured transport inputs, with no general uniform extraction or endpoint conclusion.

Reproduction uses files beside the scripts, with no machine-specific absolute paths:

1. `python3 numeric.py build` builds the fixed integer inputs once.
2. Run `numeric_matlab.m` once in MATLAB to create the candidate JSON.
3. `python3 numeric.py verify --record` independently certifies and saves numeric_output.json once.
4. An isolated verifier replay copies numeric.py, numeric_input.json and numeric_candidate.json to a clean directory, runs `python3 numeric.py verify`, and compares stdout byte-for-byte with numeric_output.json. It does not rerun MATLAB or rebuild inputs.

| File | Bytes | SHA256 |
|---|---:|---|
| numeric.py | 20726 | 9e0f321cb85da5488efedc0f6c73503de22fc0c2c5695ef5787a9fba2a57419a |
| numeric_matlab.m | 4585 | f4438c403f311ea3bbd5c949e42edafef3ba912ae36179030b24f32ef70ef95a |
| numeric_input.json | 12019 | 57dc665a54754b0332b6a196bf645f07ae2276c9594f8091556090b30a7e1e02 |
| numeric_candidate.json | 16766 | 24fabe48128ddcdade760b36ad2cb2bc4579b39041f0d894b5a906a09cb74d7c |
| numeric_output.json | 71875 | 7dd402e21e63f6cb122e9932dfc3f01984977cd54b304f7bc009c8fbd6870ede |

## 实际验证、复现与证据边界

一般中心立方体根阶目标状态为 **UNPROVED**。解析主式和原联合接口已经独立全文审核：运输模块的有限流、cut、多尺度份额与来源账由一位独审核验；原软联合、共同 q、双尺度窗口和最终接合由另一位独审核验。主代理另全文核对统一总式。审核范围互补，不将某位审查者未重复阅读的模块算成其独立重证。

数值采用执行前冻结的三个非原子真实来源输入，维数 n=1、4、1024。一次 MATLAB R2026a 生产包含 7 次 maxflow、2 次第一阶段 linprog；一次 Python Fraction 精确验证报告 688 项代码检查通过。这些检查包含真实几何、整数重构、容量、守恒、残余割、运输边缘、跨尺度份额、实际接收交通及显示记账，不能称为 688 个独立数学实验。阶段 3 使用自付尺度预算的通用 D27–D31 菜单，不能误称为具体 D32 菜单。数值不认证原 FULL/deep、top-k D24 或原软硬联合 N 系列，也不证明任意输入有统一提取比例。

主代理已把程序、固定输入和 MATLAB 候选复制至干净目录，仅重放一次只读验证命令。该隔离重放 exit 0、stderr 为空，stdout 71875 字节，与已保存 numeric_output.json 逐字节相同，SHA256 为 `7dd402e21e63f6cb122e9932dfc3f01984977cd54b304f7bc009c8fbd6870ede`。隔离重放没有重新运行 MATLAB 或重建输入。归档生产仅核对这些既有收据、原样字节和结构，不再次执行研究数值。

归档恰含 proof.md、proof.tex.txt、inventory.json 三个成员。proof.md 的“原样复现文件”附录内嵌 numeric.py、numeric_matlab.m、numeric_input.json、numeric_candidate.json、numeric_output.json 五个文件的完整原始 UTF-8 字节，保留最后换行；文件头给出字节数和 SHA256。下面的提取程序按记录长度切取字节并复核哈希，避免复制时丢失换行或更改 JSON 缩进。

解压后在空输出目录执行以下提取脚本（输入是当前目录的 proof.md，输出到 reproduced 子目录）：

```python
from pathlib import Path
import hashlib, re
raw = Path('proof.md').read_bytes()
out = Path('reproduced')
out.mkdir(exist_ok=True)
pat = rb'<!-- REPRO-FILE-BEGIN name="([A-Za-z0-9_.]+)" bytes="([0-9]+)" sha256="([0-9a-f]{64})" -->\n````[a-z]+\n'
allowed = {'numeric.py', 'numeric_matlab.m', 'numeric_input.json',
           'numeric_candidate.json', 'numeric_output.json'}
seen = set()
for hit in re.finditer(pat, raw):
    name = hit[1].decode()
    assert name in allowed and name not in seen
    data = raw[hit.end():hit.end() + int(hit[2])]
    assert hashlib.sha256(data).hexdigest() == hit[3].decode()
    assert raw[hit.end() + len(data):].startswith(b'````\n<!-- REPRO-FILE-END -->')
    (out / name).write_bytes(data)
    seen.add(name)
assert seen == allowed
print('Extracted five byte-exact reproduction files.')
```

通常复核只需进入 reproduced 并执行 `python3 numeric.py verify`，将 stdout 与 numeric_output.json 比较；这是 Python 标准库验证，不调用 MATLAB。完整重建实验须另建一个空目录，只复制 numeric.py 和 numeric_matlab.m，然后依次使用 `python3 numeric.py build`、MATLAB 运行 numeric_matlab.m、`python3 numeric.py verify --record`。不要在已提取五文件的目录直接重建：程序会拒绝已有的输入、候选或输出，避免覆盖证据。完整重建是额外生产，不能与本归档已经完成的一次生产混计。Python 需支持 `sys.set_int_max_str_digits`（例如 Python 3.11+）；MATLAB 候选生产使用已记录的 R2026a Update 4 和 Optimization Toolbox。

LaTeX 文件是保留完整数学正文的 UTF-8 文本，不编译、不生成 PDF。生产程序将各 PUBLIC 模块的显示公式按出现次序逐式与 proof.md、proof.tex.txt 比较，并核对结构环境、括号、数学分隔符和引用。嵌入程序及数据的原样字节另从报告和压缩包中提取验证；压缩包成员再次逐字节核对。

公开材料仅包含本轮 overview、已审 transport/joint_geometry/integration/numeric 的 PUBLIC 正文、此验证说明和必要复现文件。PRIVATE 工作记录、下一轮 halo 候选、工具能力探测、原始文献 PDF 均不纳入。数值通过与归档结构通过都不能替代一般均衡重尾的根阶预算。


## 原样复现文件

以下代码块内容按原始字节保存；先按验证章节的长度及哈希提取，再运行所需命令。

### numeric.py

<!-- REPRO-FILE-BEGIN name="numeric.py" bytes="20726" sha256="9e0f321cb85da5488efedc0f6c73503de22fc0c2c5695ef5787a9fba2a57419a" -->
````python
#!/usr/bin/env python3
"""R107 frozen geometry -> MATLAB integer candidates -> exact certificates.
Commands: build, verify. verify is read-only unless --record is explicitly used.
No third-party Python packages, floating math, parameter scans, or solver calls.
"""
from fractions import Fraction as F
from pathlib import Path
from hashlib import sha256
from math import isqrt
from decimal import Decimal
import json
import sys

sys.set_int_max_str_digits(0)
ROOT = Path(__file__).resolve().parent
CHECKS = []


def ck(label, ok):
    if not ok:
        raise ArithmeticError('UNKNOWN: ' + label)
    CHECKS.append(label)


def canonical(obj):
    return json.dumps(obj, sort_keys=True, indent=2, ensure_ascii=False) + '\n'


def sha(x):
    return sha256(x).hexdigest()


def frac(x):
    return F(str(x))


def fs(x):
    x = F(x)
    return str(x.numerator) + '/' + str(x.denominator)


def quantities(expr, x, small=False):
    x = F(x)
    ck('nonnegative reported physical quantity', x >= 0)
    o = {'expression':expr,'fraction_sha256':sha(fs(x).encode())}
    if x == 0:
        o['log10_bracket'] = None
    else:
        k = len(str(x.numerator))-len(str(x.denominator))
        ten = lambda j: F(10**j) if j >= 0 else F(1,10**(-j))
        if x < ten(k):
            k -= 1
        elif x >= ten(k+1):
            k += 1
        ck('directed integer log10 bracket', ten(k) <= x < ten(k+1))
        o['log10_bracket'] = [k,k+1]
    if small:
        o['exact_fraction'] = fs(x)
        scale = 10**18
        low = (x.numerator*scale)//x.denominator
        high = low if F(low,scale)==x else low+1
        fmt = lambda z: str(z//scale)+'.'+str(z%scale).zfill(18)
        o['decimal_interval'] = [fmt(low),fmt(high)]
    return o


def cases():
    return [
      dict(id='stage1',n=1,left=F(0),fpeak=F(12),scale=4,
           hot=[(7,F(59,8),F(61,8))],E1=(F(57,8),F(63,8)),
           menu=[(0,F(1)),(1,F(1))],expected=[F(1),F(11,4)]),
      dict(id='stage2',n=4,left=F(1,8),fpeak=F(48),scale=8,
           hot=[(0,F(3,16),F(1,4))],E1=(F(5,8),F(11,16)),
           menu=[(0,F(2)),(1,F(1))],expected=[F(1,4),F(3,8)]),
      dict(id='stage3',n=1024,left=F(0),fpeak=F(3072),scale=2048,
           hot=[(0,F(1,4096),F(3,4096)),(4,F(17,4096),F(19,4096))],
           E1=(F(1,2),F(1,2)+F(1,4096)),
           menu=[(0,F(5,2)),(1,F(1)),(2,F(1))],
           expected=[F(5,1024),F(5,1024),F(7,1024)])]


def piece(c, i):
    return max(c['left'],F(i,c['n'])), min(c['left']+16*c['n'],F(i+1,c['n']))


def geometry(c):
    n = c['n']; k = isqrt(n); s = 16*n; d = F(1,n)
    ck(c['id']+' integer sqrt', k*k==n)
    mp = c['fpeak']-k
    a = [mp*(hi-lo) for _,lo,hi in c['hot']]
    hlen = sum((hi-lo for _,lo,hi in c['hot']), F(0))
    row = sum(a,F(0)); L = F(s**(n-1))
    E = (c['E1'][1]-c['E1'][0]) * (s-1)**(n-1)
    for i,lo,hi in c['hot']:
        pl,pr = piece(c,i)
        ck(c['id']+' hot microinterval inside clipped piece', pl<=lo<hi<=pr)
        ck(c['id']+' all real receiver cubes capture every hot interval',
           c['E1'][1]-F(1,2)<=lo and hi<=c['E1'][0]+F(1,2))
    ck(c['id']+' all first-coordinate cubes lie in leaf',
       c['E1'][0]-F(1,2)>=c['left'] and c['E1'][1]+F(1,2)<=c['left']+s)
    ck(c['id']+' actual f row is 3', c['fpeak']*hlen==3)
    ck(c['id']+' exact initial cap ledger', row+k*hlen==3)
    ck(c['id']+' strong rational low leaf mean', row/s<=F(4,k))
    ck(c['id']+' positive source and dx receiver', mp>0 and row>0 and E>0)
    return dict(n=n,k=k,s=s,d=d,mp=mp,a=a,row=row,L=L,E=E,W=row*L,
                T=row*E,hlen=hlen,sourcevol=hlen*L)


def graph(c, ordinal, m, tau):
    g = geometry(c)
    srcindices = [v[0] for v in c['hot']]
    targetindices = sorted({j for i in srcindices for j in range(i-m,i+m+1)
                            if piece(c,j)[1]>piece(c,j)[0]})
    lengths = [piece(c,j)[1]-piece(c,j)[0] for j in targetindices]
    scale = c['scale']
    asint = lambda v: int(v) if F(v).denominator==1 else None
    ac = [asint(a*scale) for a in g['a']]
    bc = [asint(tau*v*scale) for v in lengths]
    B = asint((g['row']+tau*g['s'])*scale)
    ck(c['id']+' integer scaled capacities', all(v is not None and v>0 for v in ac+bc+[B]))
    ck(c['id']+' integer capacities below 2^53', max(ac+bc+[B])<2**53)
    ns=len(ac); nt=len(bc); sink=ns+nt+2
    allowed = [[i,j] for i,si in enumerate(srcindices) for j,tj in enumerate(targetindices) if abs(si-tj)<=m]
    edges = [[1,2+i,ac[i]] for i in range(ns)]
    edges += [[2+i,2+ns+j,B] for i,j in allowed]
    edges += [[2+ns+j,sink,bc[j]] for j in range(nt)]
    return dict(id=c['id']+'_m'+str(m),stage=c['id'],ordinal=ordinal,n=c['n'],m=m,
                tau=fs(tau),integer_scale=scale,source_indices=srcindices,target_indices=targetindices,
                source_capacity=ac,target_capacity=bc,internal_capacity=B,node_count=sink,
                source_node=1,sink_node=sink,allowed=allowed,edges=edges,
                edge_from=[e[0] for e in edges],edge_to=[e[1] for e in edges],
                edge_capacity=[e[2] for e in edges],
                allowed_source=[p[0] for p in allowed],allowed_target=[p[1] for p in allowed],
                run_linprog=(c['id']=='stage1'))


def build_data():
    graphs=[]
    for c in cases():
        graphs += [graph(c,j,m,tau) for j,(m,tau) in enumerate(c['menu'])]
    ck('exact frozen graph count',len(graphs)==7)
    return {'protocol':'R107 frozen residual geometry v1',
            'linprog_algorithm':'dual-simplex-highs','linprog_display':'none',
            'integer_rounding_tolerance':'1/1000000000','graphs':graphs}


def integers(values, label):
    if not isinstance(values,list):
        values=[values]
    out=[]
    for v in values:
        x=frac(v); r=round(x)
        ck(label+' fixed reconstruction tolerance',abs(x-r)<=F(1,10**9))
        out.append(r)
    return out


def vector(x):
    return x if isinstance(x,list) else [x]


def verify_graph(expected, found):
    name=expected['id']; edges=expected['edges']; N=expected['node_count']
    ck(name+' candidate id',found['id']==name)
    flow=integers(found['edge_flow'],name+' maxflow')
    ck(name+' edge vector length',len(flow)==len(edges))
    balance=[0]*(N+1)
    residual=[[] for _ in range(N+1)]
    for (u,v,cap),f in zip(edges,flow):
        ck(name+' edge feasibility',0<=f<=cap)
        balance[u]-=f; balance[v]+=f
        if cap>f: residual[u].append(v)
        if f>0: residual[v].append(u)
    src=1; sink=N; value=balance[sink]
    ck(name+' all node flow conservation',balance[src]==-value and all(balance[v]==0 for v in range(2,N)))
    ck(name+' MATLAB objective agrees after reconstruction',integers(found['maxflow_value'],name+' objective')==[value])
    reached={src}; queue=[src]
    for u in queue:
        for v in residual[u]:
            if v not in reached:
                reached.add(v); queue.append(v)
    ck(name+' no residual augmenting path',sink not in reached)
    cut=sum(cap for u,v,cap in edges if u in reached and v not in reached)
    ck(name+' exact flow equals exact cut',value==cut)
    # MATLAB's reported mincut may differ from the canonical residual cut.
    mcut=set(integers(found['cut_source_nodes'],name+' MATLAB cut'))
    ck(name+' MATLAB cut separates terminals',src in mcut and sink not in mcut)
    mcutvalue=sum(cap for u,v,cap in edges if u in mcut and v not in mcut)
    ck(name+' MATLAB reported cut is independently optimal',mcutvalue==value)
    ns=len(expected['source_capacity']); nt=len(expected['target_capacity'])
    Frows=flow[:ns]
    Gcols=flow[-nt:]
    internal=flow[ns:ns+len(expected['allowed'])]
    ck(name+' internal source marginals',all(sum(f for (ii,j),f in zip(expected['allowed'],internal) if ii==i)==Frows[i] for i in range(ns)))
    ck(name+' internal target marginals',all(sum(f for (i,jj),f in zip(expected['allowed'],internal) if jj==j)==Gcols[j] for j in range(nt)))
    A={i for i in range(ns) if 2+i in reached}
    neighbor={j for i,j in expected['allowed'] if i in A}
    targetreach={j for j in range(nt) if 2+ns+j in reached}
    ck(name+' reachable targets equal entire neighbor union',neighbor==targetreach)
    defect=sum(expected['source_capacity'])-value
    cutdefect=sum(expected['source_capacity'][i] for i in A)-sum(expected['target_capacity'][j] for j in neighbor)
    ck(name+' exact concentration defect and residual support',defect==cutdefect and
       all(expected['source_capacity'][i]==Frows[i] for i in range(ns) if i not in A))
    if expected['run_linprog']:
        ck(name+' fixed LP method',found['linprog_algorithm']=='dual-simplex-highs')
        ck(name+' positive LP exitflag',int(found['linprog_exitflag'])>0)
        lp=integers(found['linprog_edge_flow'],name+' LP')
        ck(name+' LP route vector',len(lp)==len(internal) and all(v>=0 for v in lp))
        ck(name+' LP source feasibility',all(sum(f for (ii,j),f in zip(expected['allowed'],lp) if ii==i)<=expected['source_capacity'][i] for i in range(ns)))
        ck(name+' LP target feasibility',all(sum(f for (i,jj),f in zip(expected['allowed'],lp) if jj==j)<=expected['target_capacity'][j] for j in range(nt)))
        ck(name+' LP exact objective reaches independently proved cut',sum(lp)==value)
        ck(name+' LP raw objective reconstruction',integers(-frac(found['linprog_objective']),name+' LP objective')==[value])
    scale=expected['integer_scale']
    return dict(value=F(value,scale),defect=F(defect,scale),rows=[F(v,scale) for v in Frows],
                internal=[F(v,scale) for v in internal],A=A,neighbor=neighbor,
                cut_nodes=sorted(reached),integer_flow=flow)


def exp_bounds(t):
    term=F(1); total=F(0)
    for j in range(256):
        total+=term
        term*=F(t,j+1)
    return total,total+term/(1-F(t,257))


def verify_all(data,candidate):
    ck('MATLAB producer status',candidate['status']=='CANDIDATE')
    ck('MATLAB candidate binds full exact input',json.loads(candidate['input_text'])==data)
    ck('candidate graph count',len(candidate['graphs'])==7)
    certified={g['id']:verify_graph(g,r) for g,r in zip(data['graphs'],candidate['graphs'])}
    exp={t:exp_bounds(t) for t in [4,8,12]}
    B_lower=sum((v[0] for v in exp.values()),F(0))
    stage_reports=[]
    for c in cases():
        g=geometry(c); n=g['n']; prefix=c['id']; q=[F(0)]*len(g['a'])
        total_incr=[F(0)]*len(q); scale_reports=[]; budget=F(0); cutsets=[]
        graphlist=[x for x in data['graphs'] if x['stage']==prefix]
        mass_running=[]
        for ordinal,(m,tau) in enumerate(c['menu']):
            gr=graphlist[ordinal]; v=certified[gr['id']]
            ck(gr['id']+' expected exact optimum',v['value']==c['expected'][ordinal])
            theta=[v['rows'][i]/g['a'][i] for i in range(len(q))]
            qnext=[max(q[i],theta[i]) for i in range(len(q))]
            delta=[qnext[i]-q[i] for i in range(len(q))]
            ck(gr['id']+' runningmax increments dominated by original shares',all(0<=delta[i]<=theta[i]<=1 for i in range(len(q))))
            incflow=[f*delta[i]/theta[i] if theta[i] else F(0) for (i,j),f in zip(gr['allowed'],v['internal'])]
            incr=[g['a'][i]*delta[i] for i in range(len(q))]
            cap=[tau*(piece(c,j)[1]-piece(c,j)[0]) for j in gr['target_indices']]
            ck(gr['id']+' increment source marginals',all(sum(f for (ii,j),f in zip(gr['allowed'],incflow) if ii==i)==incr[i] for i in range(len(q))))
            ck(gr['id']+' increment target marginals and density cap',all(sum(f for (i,jj),f in zip(gr['allowed'],incflow) if jj==j)<=cap[j] for j in range(len(cap))))
            incmass=sum(incr,F(0))
            ck(gr['id']+' positive increment',incmass>0)
            # All E captures the full first-coordinate source support. Prove that
            # its enlarged cubes contain every used target piece, for every x.
            expanded=1+2*F(m+1,n); radius=expanded/2
            for (i,j),f in zip(gr['allowed'],incflow):
                if not f: continue
                targetindex=gr['target_indices'][j]
                tl,tr=piece(c,targetindex)
                si,sl,sr=c['hot'][i]
                ck(gr['id']+' actual allowed index displacement',abs(si-targetindex)<=m)
                ck(gr['id']+' exact physical displacement',max(abs(sl-tr),abs(sr-tl))<=F(m+1,n))
                ck(gr['id']+' all receiver expanded intervals cover targets',c['E1'][1]-radius<=tl and tr<=c['E1'][0]+radius)
            ck(gr['id']+' transverse target integration covers at least unit volume',expanded>=1 and g['s']>=1)
            for i in range(len(q)): total_incr[i]+=incr[i]
            q=qnext
            maxmass=sum((q[i]*g['a'][i] for i in range(len(q))),F(0))
            mass_running.append(maxmass)
            Fnm=expanded**n
            budget+=Fnm*Fnm*tau
            neighborlength=sum((piece(c,gr['target_indices'][j])[1]-piece(c,gr['target_indices'][j])[0] for j in v['neighbor']),F(0))
            Amass=sum((g['a'][i] for i in v['A']),F(0))
            ck(gr['id']+' true cut neighborhood volume bound',tau*neighborlength<=Amass)
            # First-coordinate open md-neighborhood of every full cut piece is
            # covered by exactly the finite neighbor-index union, clipped to V.
            for i in v['A']:
                si=c['hot'][i][0]
                required={j for j in range(si-m,si+m+1) if piece(c,j)[1]>piece(c,j)[0]}
                actual={gr['target_indices'][j] for j in v['neighbor']}
                ck(gr['id']+' entire clipped thick neighborhood retained',required<=actual)
            cutsets.append(v['A'])
            scale_reports.append({
                'm':m,'tau':fs(tau),'integer_scale':gr['integer_scale'],
                'target_indices':gr['target_indices'],'optimal_integer_edge_flow':v['integer_flow'],
                'canonical_residual_cut_nodes':v['cut_nodes'],
                'source_fraction_theta':[fs(x) for x in theta],
                'runningmax_q':[fs(x) for x in q],
                'increment_delta':[fs(x) for x in delta],
                'increment_internal_flow_reduced':[fs(x) for x in incflow],
                'maxflow_reduced':quantities('reduced maxflow',v['value'],True),
                'cut_defect_reduced':quantities('reduced exact cut defect',v['defect'],True),
                'runningmax_extracted_reduced':quantities('sum_i a_i max_{j<=scale}theta_i^j',maxmass,True),
                'increment_physical_mass':quantities('reduced increment * transverse volume',incmass*g['L']),
                'increment_actual_dx_traffic':quantities('reduced increment * receiver volume',incmass*g['E']),
                'cut_neighbor_full_volume':quantities('neighbor first length * transverse volume',neighborlength*g['L']),
                'expanded_receiver_full_side':fs(expanded),
                'F_nm':quantities('(1+2(m+1)/n)^n',Fnm),
            })
        extracted=sum(total_incr,F(0)); residual=g['row']-extracted
        ck(prefix+' full input source conservation',extracted+residual==g['row'])
        ck(prefix+' source maximum not double counted',all(total_incr[i]==q[i]*g['a'][i] for i in range(len(q))))
        ck(prefix+' real dx traffic conservation',extracted*g['E']+residual*g['E']==g['T'])
        ck(prefix+' common remaining source supported in all cuts',all(q[i]==1 or all(i in A for A in cutsets) for i in range(len(q))))
        ck(prefix+' final remaining source bounded by every defect',all(residual<=certified[x['id']]['defect'] for x in graphlist))
        ck(prefix+' full finite scale budget paid',budget/g['k']<B_lower)
        if n==1:
            ck('stage1 final full extraction',residual==0 and mass_running==[F(1),F(11,4)])
        if n==4:
            ck('stage2 clipped exact outcomes',mass_running==[F(1,4),F(3,8)] and residual==F(5,2))
        if n==1024:
            d=g['d']
            ck('stage3 nonmonotone source extraction at second scale',
               certified[graphlist[1]['id']]['rows'][0]<certified[graphlist[0]['id']]['rows'][0])
            ck('stage3 genuine maximum exceeds both scalar optima',mass_running[1]==F(11,2)*d and mass_running[1]>5*d)
            ck('stage3 maximum is below overlapping scalar sum',mass_running[1]<10*d)
            ck('stage3 final runningmax allowed range',7*d<=mass_running[2]<=F(15,2)*d)
            ck('stage3 positive common cut residual',residual>0)
        stage_reports.append({
            'stage':prefix,'n':n,'leaf_side':g['s'],'leaf_left':fs(c['left']),
            'source_indices':[i for i,_,_ in c['hot']],
            'hot_intervals':[[fs(lo),fs(hi)] for _,lo,hi in c['hot']],
            'first_receiver_interval':[fs(x) for x in c['E1']],
            'transverse_repetition':n-1,'transverse_interval':[fs(c['left']),fs(c['left']+g['s'])],
            'f_peak':fs(c['fpeak']),'residual_peak':fs(g['mp']),
            'Af':fs(F(3)),'A_mu':fs(g['row']),
            'full_leaf_volume':quantities('(16n)^n',g['s']**n),
            'transverse_volume':quantities('(16n)^(n-1)',g['L']),
            'occupied_source_volume':quantities('total hot length * transverse volume',g['sourcevol']),
            'receiver_volume':quantities('first receiver length*(16n-1)^(n-1)',g['E']),
            'f_mass':quantities('3*transverse volume',3*g['L']),
            'initial_point_cap_mass':quantities('sqrt_n*occupied source volume',g['k']*g['sourcevol']),
            'input_mu_mass':quantities('A_mu*transverse volume',g['W']),
            'actual_T_mu':quantities('A_mu*receiver volume',g['T']),
            'scales':scale_reports,
            'runningmax_final_extracted_mass':quantities('runningmax reduced extraction*transverse volume',extracted*g['L']),
            'runningmax_final_residual_mass':quantities('remaining reduced source*transverse volume',residual*g['L']),
            'runningmax_actual_extracted_traffic':quantities('runningmax reduced extraction*receiver volume',extracted*g['E']),
            'runningmax_actual_residual_traffic':quantities('remaining reduced source*receiver volume',residual*g['E']),
            'extracted_fraction_of_mu_and_T':quantities('runningmax extraction / original source',extracted/g['row'],True),
            'exact_scale_budget_over_sqrt_n':quantities('sum F_nm^2*tau/sqrt_n',budget/g['k']),
            'epsilon':fs(F(1,100)),
            'new_epsilon_X':quantities('|E|/100',g['E']/100),
            'source_payment_coefficient_divided_by_C2_squared':quantities('25*sum F_nm^2*tau',25*budget),
            'unpaid_residual_kept_with_coefficient_one':True,
            'FULL_or_deep_certified':False,
        })
    return {'status':'PASS','protocol':data['protocol'],'matlab_version':candidate['matlab_version'],
            'maxflow_calls':7,'linprog_calls':2,'physical_input_families':3,
            'stages':stage_reports,'fixed_exp_bounds':{str(t):[sha(fs(lo).encode()),sha(fs(hi).encode())] for t,(lo,hi) in exp.items()},
            'input_sha256':sha(canonical(data).encode()),
            'candidate_sha256':sha((ROOT/'numeric_candidate.json').read_bytes()),
            'checks_passed':len(CHECKS),'check_labels':CHECKS,
            'scope':'D20 and D27-D31 geometric transport; not FULL/deep/D24 or soft-hard N1-N30',
            'C2':'symbolic, not numerically assigned',
            'no_claim':'These three structured examples do not imply a uniform extracted fraction or general root-order closure.'}


def main():
    try:
        if len(sys.argv)<2 or sys.argv[1] not in ['build','verify']:
            print('Usage: numeric.py build | verify [--record]'); return 2
        data=build_data()
        if sys.argv[1]=='build':
            p=ROOT/'numeric_input.json'
            ck('refuse second input build',not p.exists())
            payload=canonical(data); p.write_text(payload)
            print(canonical({'status':'BUILT','graphs':7,'sha256':sha(payload.encode())}),end=''); return 0
        disk=json.loads((ROOT/'numeric_input.json').read_text())
        ck('saved input equals independent frozen reconstruction',disk==data)
        candidate=json.loads((ROOT/'numeric_candidate.json').read_text(),parse_float=Decimal)
        report=verify_all(data,candidate)
        payload=canonical(report)
        if '--record' in sys.argv[2:]:
            p=ROOT/'numeric_output.json'; ck('refuse second verification record',not p.exists())
            p.write_text(payload)
            print(canonical({'status':'PASS','checks_passed':report['checks_passed'],'sha256':sha(payload.encode())}),end='')
        else:
            print(payload,end='')
        return 0
    except Exception as exc:
        print(canonical({'status':'UNKNOWN','reason':str(exc),'checks_completed':len(CHECKS)}),end='')
        return 2


if __name__=='__main__':
    sys.exit(main())
````
<!-- REPRO-FILE-END -->

### numeric_matlab.m

<!-- REPRO-FILE-BEGIN name="numeric_matlab.m" bytes="4585" sha256="f4438c403f311ea3bbd5c949e42edafef3ba912ae36179030b24f32ef70ef95a" -->
````matlab
% R107 frozen candidate producer: 7 maxflow + 2 initial-stage linprog calls.
% All paths resolve beside this script. No clear, path changes, or package installs.
% MATLAB returns candidates only; numeric.py independently checks exact certificates.
r107Directory = fileparts(mfilename('fullpath'));
r107InputPath = fullfile(r107Directory, 'numeric_input.json');
r107CandidatePath = fullfile(r107Directory, 'numeric_candidate.json');
if isfile(r107CandidatePath)
    error('R107:AlreadyExecuted', 'Candidate file already exists; no second producer.');
end
r107InputText = fileread(r107InputPath);
r107Data = jsondecode(r107InputText);
r107Result = struct();
r107Result.status = 'CANDIDATE';
r107Result.matlab_version = version;
r107Result.input_text = r107InputText;
r107Result.maxflow_calls = 0;
r107Result.linprog_calls = 0;
r107Result.graphs = cell(1, numel(r107Data.graphs));
r107LPFixedOptions = optimoptions('linprog', 'Algorithm', ...
    'dual-simplex-highs', 'Display', 'none');
try
    for r107Index = 1:numel(r107Data.graphs)
        r107GraphInput = r107Data.graphs(r107Index);
        r107Edges = [r107GraphInput.edge_from(:), r107GraphInput.edge_to(:), ...
            r107GraphInput.edge_capacity(:)];
        r107Graph = digraph(r107Edges(:, 1), r107Edges(:, 2), ...
            r107Edges(:, 3), r107GraphInput.node_count);
        [r107FlowValue, r107FlowGraph, r107CutSource, r107CutSink] = ...
            maxflow(r107Graph, r107GraphInput.source_node, r107GraphInput.sink_node);
        r107Result.maxflow_calls = r107Result.maxflow_calls + 1;
        r107FlowEdges = zeros(size(r107Edges, 1), 1);
        for r107EdgeIndex = 1:size(r107Edges, 1)
            r107FoundEdge = findedge(r107FlowGraph, ...
                r107Edges(r107EdgeIndex, 1), r107Edges(r107EdgeIndex, 2));
            if r107FoundEdge > 0
                r107FlowEdges(r107EdgeIndex) = r107FlowGraph.Edges.Weight(r107FoundEdge);
            end
        end
        r107GraphResult = struct();
        r107GraphResult.id = r107GraphInput.id;
        r107GraphResult.maxflow_value = r107FlowValue;
        r107GraphResult.edge_flow = r107FlowEdges';
        r107GraphResult.cut_source_nodes = r107CutSource';
        r107GraphResult.cut_sink_nodes = r107CutSink';
        r107GraphResult.linprog_algorithm = 'not requested';
        r107GraphResult.linprog_exitflag = 0;
        r107GraphResult.linprog_objective = 0;
        r107GraphResult.linprog_edge_flow = [];
        r107GraphResult.linprog_message = '';
        if r107GraphInput.run_linprog
            r107SourceCount = numel(r107GraphInput.source_capacity);
            r107TargetCount = numel(r107GraphInput.target_capacity);
            r107Allowed = [r107GraphInput.allowed_source(:), r107GraphInput.allowed_target(:)];
            r107VariableCount = size(r107Allowed, 1);
            r107A = zeros(r107SourceCount + r107TargetCount, r107VariableCount);
            for r107Variable = 1:r107VariableCount
                r107A(r107Allowed(r107Variable, 1) + 1, r107Variable) = 1;
                r107A(r107SourceCount + r107Allowed(r107Variable, 2) + 1, r107Variable) = 1;
            end
            r107b = [r107GraphInput.source_capacity(:); r107GraphInput.target_capacity(:)];
            [r107LPFlow, r107LPObjective, r107LPExitflag, r107LPOutput] = ...
                linprog(-ones(r107VariableCount, 1), r107A, r107b, ...
                [], [], zeros(r107VariableCount, 1), [], r107LPFixedOptions);
            r107Result.linprog_calls = r107Result.linprog_calls + 1;
            r107GraphResult.linprog_algorithm = r107LPFixedOptions.Algorithm;
            r107GraphResult.linprog_exitflag = r107LPExitflag;
            r107GraphResult.linprog_objective = r107LPObjective;
            r107GraphResult.linprog_edge_flow = r107LPFlow';
            r107GraphResult.linprog_message = r107LPOutput.message;
        end
        r107Result.graphs{r107Index} = r107GraphResult;
    end
catch r107Exception
    r107Result.status = 'UNKNOWN';
    r107Result.error_identifier = r107Exception.identifier;
    r107Result.error_message = r107Exception.message;
end
r107CandidateText = jsonencode(r107Result, 'PrettyPrint', true);
r107FileID = fopen(r107CandidatePath, 'w');
if r107FileID < 0
    error('R107:CannotWrite', 'Cannot write candidate file.');
end
fprintf(r107FileID, '%s\n', r107CandidateText);
fclose(r107FileID);
disp(jsonencode(struct('status', r107Result.status, ...
    'maxflow_calls', r107Result.maxflow_calls, ...
    'linprog_calls', r107Result.linprog_calls, ...
    'candidate_file', 'numeric_candidate.json')));
````
<!-- REPRO-FILE-END -->

### numeric_input.json

<!-- REPRO-FILE-BEGIN name="numeric_input.json" bytes="12019" sha256="57dc665a54754b0332b6a196bf645f07ae2276c9594f8091556090b30a7e1e02" -->
````json
{
  "graphs": [
    {
      "allowed": [
        [
          0,
          0
        ]
      ],
      "allowed_source": [
        0
      ],
      "allowed_target": [
        0
      ],
      "edge_capacity": [
        11,
        75,
        4
      ],
      "edge_from": [
        1,
        2,
        3
      ],
      "edge_to": [
        2,
        3,
        4
      ],
      "edges": [
        [
          1,
          2,
          11
        ],
        [
          2,
          3,
          75
        ],
        [
          3,
          4,
          4
        ]
      ],
      "id": "stage1_m0",
      "integer_scale": 4,
      "internal_capacity": 75,
      "m": 0,
      "n": 1,
      "node_count": 4,
      "ordinal": 0,
      "run_linprog": true,
      "sink_node": 4,
      "source_capacity": [
        11
      ],
      "source_indices": [
        7
      ],
      "source_node": 1,
      "stage": "stage1",
      "target_capacity": [
        4
      ],
      "target_indices": [
        7
      ],
      "tau": "1/1"
    },
    {
      "allowed": [
        [
          0,
          0
        ],
        [
          0,
          1
        ],
        [
          0,
          2
        ]
      ],
      "allowed_source": [
        0,
        0,
        0
      ],
      "allowed_target": [
        0,
        1,
        2
      ],
      "edge_capacity": [
        11,
        75,
        75,
        75,
        4,
        4,
        4
      ],
      "edge_from": [
        1,
        2,
        2,
        2,
        3,
        4,
        5
      ],
      "edge_to": [
        2,
        3,
        4,
        5,
        6,
        6,
        6
      ],
      "edges": [
        [
          1,
          2,
          11
        ],
        [
          2,
          3,
          75
        ],
        [
          2,
          4,
          75
        ],
        [
          2,
          5,
          75
        ],
        [
          3,
          6,
          4
        ],
        [
          4,
          6,
          4
        ],
        [
          5,
          6,
          4
        ]
      ],
      "id": "stage1_m1",
      "integer_scale": 4,
      "internal_capacity": 75,
      "m": 1,
      "n": 1,
      "node_count": 6,
      "ordinal": 1,
      "run_linprog": true,
      "sink_node": 6,
      "source_capacity": [
        11
      ],
      "source_indices": [
        7
      ],
      "source_node": 1,
      "stage": "stage1",
      "target_capacity": [
        4,
        4,
        4
      ],
      "target_indices": [
        6,
        7,
        8
      ],
      "tau": "1/1"
    },
    {
      "allowed": [
        [
          0,
          0
        ]
      ],
      "allowed_source": [
        0
      ],
      "allowed_target": [
        0
      ],
      "edge_capacity": [
        23,
        1047,
        2
      ],
      "edge_from": [
        1,
        2,
        3
      ],
      "edge_to": [
        2,
        3,
        4
      ],
      "edges": [
        [
          1,
          2,
          23
        ],
        [
          2,
          3,
          1047
        ],
        [
          3,
          4,
          2
        ]
      ],
      "id": "stage2_m0",
      "integer_scale": 8,
      "internal_capacity": 1047,
      "m": 0,
      "n": 4,
      "node_count": 4,
      "ordinal": 0,
      "run_linprog": false,
      "sink_node": 4,
      "source_capacity": [
        23
      ],
      "source_indices": [
        0
      ],
      "source_node": 1,
      "stage": "stage2",
      "target_capacity": [
        2
      ],
      "target_indices": [
        0
      ],
      "tau": "2/1"
    },
    {
      "allowed": [
        [
          0,
          0
        ],
        [
          0,
          1
        ]
      ],
      "allowed_source": [
        0,
        0
      ],
      "allowed_target": [
        0,
        1
      ],
      "edge_capacity": [
        23,
        535,
        535,
        1,
        2
      ],
      "edge_from": [
        1,
        2,
        2,
        3,
        4
      ],
      "edge_to": [
        2,
        3,
        4,
        5,
        5
      ],
      "edges": [
        [
          1,
          2,
          23
        ],
        [
          2,
          3,
          535
        ],
        [
          2,
          4,
          535
        ],
        [
          3,
          5,
          1
        ],
        [
          4,
          5,
          2
        ]
      ],
      "id": "stage2_m1",
      "integer_scale": 8,
      "internal_capacity": 535,
      "m": 1,
      "n": 4,
      "node_count": 5,
      "ordinal": 1,
      "run_linprog": false,
      "sink_node": 5,
      "source_capacity": [
        23
      ],
      "source_indices": [
        0
      ],
      "source_node": 1,
      "stage": "stage2",
      "target_capacity": [
        1,
        2
      ],
      "target_indices": [
        0,
        1
      ],
      "tau": "1/1"
    },
    {
      "allowed": [
        [
          0,
          0
        ],
        [
          1,
          1
        ]
      ],
      "allowed_source": [
        0,
        1
      ],
      "allowed_target": [
        0,
        1
      ],
      "edge_capacity": [
        3040,
        3040,
        83892160,
        83892160,
        5,
        5
      ],
      "edge_from": [
        1,
        1,
        2,
        3,
        4,
        5
      ],
      "edge_to": [
        2,
        3,
        4,
        5,
        6,
        6
      ],
      "edges": [
        [
          1,
          2,
          3040
        ],
        [
          1,
          3,
          3040
        ],
        [
          2,
          4,
          83892160
        ],
        [
          3,
          5,
          83892160
        ],
        [
          4,
          6,
          5
        ],
        [
          5,
          6,
          5
        ]
      ],
      "id": "stage3_m0",
      "integer_scale": 2048,
      "internal_capacity": 83892160,
      "m": 0,
      "n": 1024,
      "node_count": 6,
      "ordinal": 0,
      "run_linprog": false,
      "sink_node": 6,
      "source_capacity": [
        3040,
        3040
      ],
      "source_indices": [
        0,
        4
      ],
      "source_node": 1,
      "stage": "stage3",
      "target_capacity": [
        5,
        5
      ],
      "target_indices": [
        0,
        4
      ],
      "tau": "5/2"
    },
    {
      "allowed": [
        [
          0,
          0
        ],
        [
          0,
          1
        ],
        [
          1,
          2
        ],
        [
          1,
          3
        ],
        [
          1,
          4
        ]
      ],
      "allowed_source": [
        0,
        0,
        1,
        1,
        1
      ],
      "allowed_target": [
        0,
        1,
        2,
        3,
        4
      ],
      "edge_capacity": [
        3040,
        3040,
        33560512,
        33560512,
        33560512,
        33560512,
        33560512,
        2,
        2,
        2,
        2,
        2
      ],
      "edge_from": [
        1,
        1,
        2,
        2,
        3,
        3,
        3,
        4,
        5,
        6,
        7,
        8
      ],
      "edge_to": [
        2,
        3,
        4,
        5,
        6,
        7,
        8,
        9,
        9,
        9,
        9,
        9
      ],
      "edges": [
        [
          1,
          2,
          3040
        ],
        [
          1,
          3,
          3040
        ],
        [
          2,
          4,
          33560512
        ],
        [
          2,
          5,
          33560512
        ],
        [
          3,
          6,
          33560512
        ],
        [
          3,
          7,
          33560512
        ],
        [
          3,
          8,
          33560512
        ],
        [
          4,
          9,
          2
        ],
        [
          5,
          9,
          2
        ],
        [
          6,
          9,
          2
        ],
        [
          7,
          9,
          2
        ],
        [
          8,
          9,
          2
        ]
      ],
      "id": "stage3_m1",
      "integer_scale": 2048,
      "internal_capacity": 33560512,
      "m": 1,
      "n": 1024,
      "node_count": 9,
      "ordinal": 1,
      "run_linprog": false,
      "sink_node": 9,
      "source_capacity": [
        3040,
        3040
      ],
      "source_indices": [
        0,
        4
      ],
      "source_node": 1,
      "stage": "stage3",
      "target_capacity": [
        2,
        2,
        2,
        2,
        2
      ],
      "target_indices": [
        0,
        1,
        3,
        4,
        5
      ],
      "tau": "1/1"
    },
    {
      "allowed": [
        [
          0,
          0
        ],
        [
          0,
          1
        ],
        [
          0,
          2
        ],
        [
          1,
          2
        ],
        [
          1,
          3
        ],
        [
          1,
          4
        ],
        [
          1,
          5
        ],
        [
          1,
          6
        ]
      ],
      "allowed_source": [
        0,
        0,
        0,
        1,
        1,
        1,
        1,
        1
      ],
      "allowed_target": [
        0,
        1,
        2,
        2,
        3,
        4,
        5,
        6
      ],
      "edge_capacity": [
        3040,
        3040,
        33560512,
        33560512,
        33560512,
        33560512,
        33560512,
        33560512,
        33560512,
        33560512,
        2,
        2,
        2,
        2,
        2,
        2,
        2
      ],
      "edge_from": [
        1,
        1,
        2,
        2,
        2,
        3,
        3,
        3,
        3,
        3,
        4,
        5,
        6,
        7,
        8,
        9,
        10
      ],
      "edge_to": [
        2,
        3,
        4,
        5,
        6,
        6,
        7,
        8,
        9,
        10,
        11,
        11,
        11,
        11,
        11,
        11,
        11
      ],
      "edges": [
        [
          1,
          2,
          3040
        ],
        [
          1,
          3,
          3040
        ],
        [
          2,
          4,
          33560512
        ],
        [
          2,
          5,
          33560512
        ],
        [
          2,
          6,
          33560512
        ],
        [
          3,
          6,
          33560512
        ],
        [
          3,
          7,
          33560512
        ],
        [
          3,
          8,
          33560512
        ],
        [
          3,
          9,
          33560512
        ],
        [
          3,
          10,
          33560512
        ],
        [
          4,
          11,
          2
        ],
        [
          5,
          11,
          2
        ],
        [
          6,
          11,
          2
        ],
        [
          7,
          11,
          2
        ],
        [
          8,
          11,
          2
        ],
        [
          9,
          11,
          2
        ],
        [
          10,
          11,
          2
        ]
      ],
      "id": "stage3_m2",
      "integer_scale": 2048,
      "internal_capacity": 33560512,
      "m": 2,
      "n": 1024,
      "node_count": 11,
      "ordinal": 2,
      "run_linprog": false,
      "sink_node": 11,
      "source_capacity": [
        3040,
        3040
      ],
      "source_indices": [
        0,
        4
      ],
      "source_node": 1,
      "stage": "stage3",
      "target_capacity": [
        2,
        2,
        2,
        2,
        2,
        2,
        2
      ],
      "target_indices": [
        0,
        1,
        2,
        3,
        4,
        5,
        6
      ],
      "tau": "1/1"
    }
  ],
  "integer_rounding_tolerance": "1/1000000000",
  "linprog_algorithm": "dual-simplex-highs",
  "linprog_display": "none",
  "protocol": "R107 frozen residual geometry v1"
}
````
<!-- REPRO-FILE-END -->

### numeric_candidate.json

<!-- REPRO-FILE-BEGIN name="numeric_candidate.json" bytes="16766" sha256="24fabe48128ddcdade760b36ad2cb2bc4579b39041f0d894b5a906a09cb74d7c" -->
````json
{
  "status": "CANDIDATE",
  "matlab_version": "26.1.0.3312084 (R2026a) Update 4",
  "input_text": "{\n  \"graphs\": [\n    {\n      \"allowed\": [\n        [\n          0,\n          0\n        ]\n      ],\n      \"allowed_source\": [\n        0\n      ],\n      \"allowed_target\": [\n        0\n      ],\n      \"edge_capacity\": [\n        11,\n        75,\n        4\n      ],\n      \"edge_from\": [\n        1,\n        2,\n        3\n      ],\n      \"edge_to\": [\n        2,\n        3,\n        4\n      ],\n      \"edges\": [\n        [\n          1,\n          2,\n          11\n        ],\n        [\n          2,\n          3,\n          75\n        ],\n        [\n          3,\n          4,\n          4\n        ]\n      ],\n      \"id\": \"stage1_m0\",\n      \"integer_scale\": 4,\n      \"internal_capacity\": 75,\n      \"m\": 0,\n      \"n\": 1,\n      \"node_count\": 4,\n      \"ordinal\": 0,\n      \"run_linprog\": true,\n      \"sink_node\": 4,\n      \"source_capacity\": [\n        11\n      ],\n      \"source_indices\": [\n        7\n      ],\n      \"source_node\": 1,\n      \"stage\": \"stage1\",\n      \"target_capacity\": [\n        4\n      ],\n      \"target_indices\": [\n        7\n      ],\n      \"tau\": \"1/1\"\n    },\n    {\n      \"allowed\": [\n        [\n          0,\n          0\n        ],\n        [\n          0,\n          1\n        ],\n        [\n          0,\n          2\n        ]\n      ],\n      \"allowed_source\": [\n        0,\n        0,\n        0\n      ],\n      \"allowed_target\": [\n        0,\n        1,\n        2\n      ],\n      \"edge_capacity\": [\n        11,\n        75,\n        75,\n        75,\n        4,\n        4,\n        4\n      ],\n      \"edge_from\": [\n        1,\n        2,\n        2,\n        2,\n        3,\n        4,\n        5\n      ],\n      \"edge_to\": [\n        2,\n        3,\n        4,\n        5,\n        6,\n        6,\n        6\n      ],\n      \"edges\": [\n        [\n          1,\n          2,\n          11\n        ],\n        [\n          2,\n          3,\n          75\n        ],\n        [\n          2,\n          4,\n          75\n        ],\n        [\n          2,\n          5,\n          75\n        ],\n        [\n          3,\n          6,\n          4\n        ],\n        [\n          4,\n          6,\n          4\n        ],\n        [\n          5,\n          6,\n          4\n        ]\n      ],\n      \"id\": \"stage1_m1\",\n      \"integer_scale\": 4,\n      \"internal_capacity\": 75,\n      \"m\": 1,\n      \"n\": 1,\n      \"node_count\": 6,\n      \"ordinal\": 1,\n      \"run_linprog\": true,\n      \"sink_node\": 6,\n      \"source_capacity\": [\n        11\n      ],\n      \"source_indices\": [\n        7\n      ],\n      \"source_node\": 1,\n      \"stage\": \"stage1\",\n      \"target_capacity\": [\n        4,\n        4,\n        4\n      ],\n      \"target_indices\": [\n        6,\n        7,\n        8\n      ],\n      \"tau\": \"1/1\"\n    },\n    {\n      \"allowed\": [\n        [\n          0,\n          0\n        ]\n      ],\n      \"allowed_source\": [\n        0\n      ],\n      \"allowed_target\": [\n        0\n      ],\n      \"edge_capacity\": [\n        23,\n        1047,\n        2\n      ],\n      \"edge_from\": [\n        1,\n        2,\n        3\n      ],\n      \"edge_to\": [\n        2,\n        3,\n        4\n      ],\n      \"edges\": [\n        [\n          1,\n          2,\n          23\n        ],\n        [\n          2,\n          3,\n          1047\n        ],\n        [\n          3,\n          4,\n          2\n        ]\n      ],\n      \"id\": \"stage2_m0\",\n      \"integer_scale\": 8,\n      \"internal_capacity\": 1047,\n      \"m\": 0,\n      \"n\": 4,\n      \"node_count\": 4,\n      \"ordinal\": 0,\n      \"run_linprog\": false,\n      \"sink_node\": 4,\n      \"source_capacity\": [\n        23\n      ],\n      \"source_indices\": [\n        0\n      ],\n      \"source_node\": 1,\n      \"stage\": \"stage2\",\n      \"target_capacity\": [\n        2\n      ],\n      \"target_indices\": [\n        0\n      ],\n      \"tau\": \"2/1\"\n    },\n    {\n      \"allowed\": [\n        [\n          0,\n          0\n        ],\n        [\n          0,\n          1\n        ]\n      ],\n      \"allowed_source\": [\n        0,\n        0\n      ],\n      \"allowed_target\": [\n        0,\n        1\n      ],\n      \"edge_capacity\": [\n        23,\n        535,\n        535,\n        1,\n        2\n      ],\n      \"edge_from\": [\n        1,\n        2,\n        2,\n        3,\n        4\n      ],\n      \"edge_to\": [\n        2,\n        3,\n        4,\n        5,\n        5\n      ],\n      \"edges\": [\n        [\n          1,\n          2,\n          23\n        ],\n        [\n          2,\n          3,\n          535\n        ],\n        [\n          2,\n          4,\n          535\n        ],\n        [\n          3,\n          5,\n          1\n        ],\n        [\n          4,\n          5,\n          2\n        ]\n      ],\n      \"id\": \"stage2_m1\",\n      \"integer_scale\": 8,\n      \"internal_capacity\": 535,\n      \"m\": 1,\n      \"n\": 4,\n      \"node_count\": 5,\n      \"ordinal\": 1,\n      \"run_linprog\": false,\n      \"sink_node\": 5,\n      \"source_capacity\": [\n        23\n      ],\n      \"source_indices\": [\n        0\n      ],\n      \"source_node\": 1,\n      \"stage\": \"stage2\",\n      \"target_capacity\": [\n        1,\n        2\n      ],\n      \"target_indices\": [\n        0,\n        1\n      ],\n      \"tau\": \"1/1\"\n    },\n    {\n      \"allowed\": [\n        [\n          0,\n          0\n        ],\n        [\n          1,\n          1\n        ]\n      ],\n      \"allowed_source\": [\n        0,\n        1\n      ],\n      \"allowed_target\": [\n        0,\n        1\n      ],\n      \"edge_capacity\": [\n        3040,\n        3040,\n        83892160,\n        83892160,\n        5,\n        5\n      ],\n      \"edge_from\": [\n        1,\n        1,\n        2,\n        3,\n        4,\n        5\n      ],\n      \"edge_to\": [\n        2,\n        3,\n        4,\n        5,\n        6,\n        6\n      ],\n      \"edges\": [\n        [\n          1,\n          2,\n          3040\n        ],\n        [\n          1,\n          3,\n          3040\n        ],\n        [\n          2,\n          4,\n          83892160\n        ],\n        [\n          3,\n          5,\n          83892160\n        ],\n        [\n          4,\n          6,\n          5\n        ],\n        [\n          5,\n          6,\n          5\n        ]\n      ],\n      \"id\": \"stage3_m0\",\n      \"integer_scale\": 2048,\n      \"internal_capacity\": 83892160,\n      \"m\": 0,\n      \"n\": 1024,\n      \"node_count\": 6,\n      \"ordinal\": 0,\n      \"run_linprog\": false,\n      \"sink_node\": 6,\n      \"source_capacity\": [\n        3040,\n        3040\n      ],\n      \"source_indices\": [\n        0,\n        4\n      ],\n      \"source_node\": 1,\n      \"stage\": \"stage3\",\n      \"target_capacity\": [\n        5,\n        5\n      ],\n      \"target_indices\": [\n        0,\n        4\n      ],\n      \"tau\": \"5/2\"\n    },\n    {\n      \"allowed\": [\n        [\n          0,\n          0\n        ],\n        [\n          0,\n          1\n        ],\n        [\n          1,\n          2\n        ],\n        [\n          1,\n          3\n        ],\n        [\n          1,\n          4\n        ]\n      ],\n      \"allowed_source\": [\n        0,\n        0,\n        1,\n        1,\n        1\n      ],\n      \"allowed_target\": [\n        0,\n        1,\n        2,\n        3,\n        4\n      ],\n      \"edge_capacity\": [\n        3040,\n        3040,\n        33560512,\n        33560512,\n        33560512,\n        33560512,\n        33560512,\n        2,\n        2,\n        2,\n        2,\n        2\n      ],\n      \"edge_from\": [\n        1,\n        1,\n        2,\n        2,\n        3,\n        3,\n        3,\n        4,\n        5,\n        6,\n        7,\n        8\n      ],\n      \"edge_to\": [\n        2,\n        3,\n        4,\n        5,\n        6,\n        7,\n        8,\n        9,\n        9,\n        9,\n        9,\n        9\n      ],\n      \"edges\": [\n        [\n          1,\n          2,\n          3040\n        ],\n        [\n          1,\n          3,\n          3040\n        ],\n        [\n          2,\n          4,\n          33560512\n        ],\n        [\n          2,\n          5,\n          33560512\n        ],\n        [\n          3,\n          6,\n          33560512\n        ],\n        [\n          3,\n          7,\n          33560512\n        ],\n        [\n          3,\n          8,\n          33560512\n        ],\n        [\n          4,\n          9,\n          2\n        ],\n        [\n          5,\n          9,\n          2\n        ],\n        [\n          6,\n          9,\n          2\n        ],\n        [\n          7,\n          9,\n          2\n        ],\n        [\n          8,\n          9,\n          2\n        ]\n      ],\n      \"id\": \"stage3_m1\",\n      \"integer_scale\": 2048,\n      \"internal_capacity\": 33560512,\n      \"m\": 1,\n      \"n\": 1024,\n      \"node_count\": 9,\n      \"ordinal\": 1,\n      \"run_linprog\": false,\n      \"sink_node\": 9,\n      \"source_capacity\": [\n        3040,\n        3040\n      ],\n      \"source_indices\": [\n        0,\n        4\n      ],\n      \"source_node\": 1,\n      \"stage\": \"stage3\",\n      \"target_capacity\": [\n        2,\n        2,\n        2,\n        2,\n        2\n      ],\n      \"target_indices\": [\n        0,\n        1,\n        3,\n        4,\n        5\n      ],\n      \"tau\": \"1/1\"\n    },\n    {\n      \"allowed\": [\n        [\n          0,\n          0\n        ],\n        [\n          0,\n          1\n        ],\n        [\n          0,\n          2\n        ],\n        [\n          1,\n          2\n        ],\n        [\n          1,\n          3\n        ],\n        [\n          1,\n          4\n        ],\n        [\n          1,\n          5\n        ],\n        [\n          1,\n          6\n        ]\n      ],\n      \"allowed_source\": [\n        0,\n        0,\n        0,\n        1,\n        1,\n        1,\n        1,\n        1\n      ],\n      \"allowed_target\": [\n        0,\n        1,\n        2,\n        2,\n        3,\n        4,\n        5,\n        6\n      ],\n      \"edge_capacity\": [\n        3040,\n        3040,\n        33560512,\n        33560512,\n        33560512,\n        33560512,\n        33560512,\n        33560512,\n        33560512,\n        33560512,\n        2,\n        2,\n        2,\n        2,\n        2,\n        2,\n        2\n      ],\n      \"edge_from\": [\n        1,\n        1,\n        2,\n        2,\n        2,\n        3,\n        3,\n        3,\n        3,\n        3,\n        4,\n        5,\n        6,\n        7,\n        8,\n        9,\n        10\n      ],\n      \"edge_to\": [\n        2,\n        3,\n        4,\n        5,\n        6,\n        6,\n        7,\n        8,\n        9,\n        10,\n        11,\n        11,\n        11,\n        11,\n        11,\n        11,\n        11\n      ],\n      \"edges\": [\n        [\n          1,\n          2,\n          3040\n        ],\n        [\n          1,\n          3,\n          3040\n        ],\n        [\n          2,\n          4,\n          33560512\n        ],\n        [\n          2,\n          5,\n          33560512\n        ],\n        [\n          2,\n          6,\n          33560512\n        ],\n        [\n          3,\n          6,\n          33560512\n        ],\n        [\n          3,\n          7,\n          33560512\n        ],\n        [\n          3,\n          8,\n          33560512\n        ],\n        [\n          3,\n          9,\n          33560512\n        ],\n        [\n          3,\n          10,\n          33560512\n        ],\n        [\n          4,\n          11,\n          2\n        ],\n        [\n          5,\n          11,\n          2\n        ],\n        [\n          6,\n          11,\n          2\n        ],\n        [\n          7,\n          11,\n          2\n        ],\n        [\n          8,\n          11,\n          2\n        ],\n        [\n          9,\n          11,\n          2\n        ],\n        [\n          10,\n          11,\n          2\n        ]\n      ],\n      \"id\": \"stage3_m2\",\n      \"integer_scale\": 2048,\n      \"internal_capacity\": 33560512,\n      \"m\": 2,\n      \"n\": 1024,\n      \"node_count\": 11,\n      \"ordinal\": 2,\n      \"run_linprog\": false,\n      \"sink_node\": 11,\n      \"source_capacity\": [\n        3040,\n        3040\n      ],\n      \"source_indices\": [\n        0,\n        4\n      ],\n      \"source_node\": 1,\n      \"stage\": \"stage3\",\n      \"target_capacity\": [\n        2,\n        2,\n        2,\n        2,\n        2,\n        2,\n        2\n      ],\n      \"target_indices\": [\n        0,\n        1,\n        2,\n        3,\n        4,\n        5,\n        6\n      ],\n      \"tau\": \"1/1\"\n    }\n  ],\n  \"integer_rounding_tolerance\": \"1/1000000000\",\n  \"linprog_algorithm\": \"dual-simplex-highs\",\n  \"linprog_display\": \"none\",\n  \"protocol\": \"R107 frozen residual geometry v1\"\n}\n",
  "maxflow_calls": 7,
  "linprog_calls": 2,
  "graphs": [
    {
      "id": "stage1_m0",
      "maxflow_value": 4,
      "edge_flow": [
        4,
        4,
        4
      ],
      "cut_source_nodes": [
        1,
        2,
        3
      ],
      "cut_sink_nodes": 4,
      "linprog_algorithm": "dual-simplex-highs",
      "linprog_exitflag": 1,
      "linprog_objective": -4,
      "linprog_edge_flow": 4,
      "linprog_message": "找到最优解。"
    },
    {
      "id": "stage1_m1",
      "maxflow_value": 11,
      "edge_flow": [
        11,
        4,
        4,
        3,
        4,
        4,
        3
      ],
      "cut_source_nodes": 1,
      "cut_sink_nodes": [
        2,
        3,
        4,
        5,
        6
      ],
      "linprog_algorithm": "dual-simplex-highs",
      "linprog_exitflag": 1,
      "linprog_objective": -11,
      "linprog_edge_flow": [
        3,
        4,
        4
      ],
      "linprog_message": "找到最优解。"
    },
    {
      "id": "stage2_m0",
      "maxflow_value": 2,
      "edge_flow": [
        2,
        2,
        2
      ],
      "cut_source_nodes": [
        1,
        2,
        3
      ],
      "cut_sink_nodes": 4,
      "linprog_algorithm": "not requested",
      "linprog_exitflag": 0,
      "linprog_objective": 0,
      "linprog_edge_flow": [],
      "linprog_message": ""
    },
    {
      "id": "stage2_m1",
      "maxflow_value": 3,
      "edge_flow": [
        3,
        1,
        2,
        1,
        2
      ],
      "cut_source_nodes": [
        1,
        2,
        3,
        4
      ],
      "cut_sink_nodes": 5,
      "linprog_algorithm": "not requested",
      "linprog_exitflag": 0,
      "linprog_objective": 0,
      "linprog_edge_flow": [],
      "linprog_message": ""
    },
    {
      "id": "stage3_m0",
      "maxflow_value": 10,
      "edge_flow": [
        5,
        5,
        5,
        5,
        5,
        5
      ],
      "cut_source_nodes": [
        1,
        2,
        3,
        4,
        5
      ],
      "cut_sink_nodes": 6,
      "linprog_algorithm": "not requested",
      "linprog_exitflag": 0,
      "linprog_objective": 0,
      "linprog_edge_flow": [],
      "linprog_message": ""
    },
    {
      "id": "stage3_m1",
      "maxflow_value": 10,
      "edge_flow": [
        4,
        6,
        2,
        2,
        2,
        2,
        2,
        2,
        2,
        2,
        2,
        2
      ],
      "cut_source_nodes": [
        1,
        2,
        3,
        4,
        5,
        6,
        7,
        8
      ],
      "cut_sink_nodes": 9,
      "linprog_algorithm": "not requested",
      "linprog_exitflag": 0,
      "linprog_objective": 0,
      "linprog_edge_flow": [],
      "linprog_message": ""
    },
    {
      "id": "stage3_m2",
      "maxflow_value": 14,
      "edge_flow": [
        6,
        8,
        2,
        2,
        2,
        0,
        2,
        2,
        2,
        2,
        2,
        2,
        2,
        2,
        2,
        2,
        2
      ],
      "cut_source_nodes": [
        1,
        2,
        3,
        4,
        5,
        6,
        7,
        8,
        9,
        10
      ],
      "cut_sink_nodes": 11,
      "linprog_algorithm": "not requested",
      "linprog_exitflag": 0,
      "linprog_objective": 0,
      "linprog_edge_flow": [],
      "linprog_message": ""
    }
  ]
}
````
<!-- REPRO-FILE-END -->

### numeric_output.json

<!-- REPRO-FILE-BEGIN name="numeric_output.json" bytes="71875" sha256="7dd402e21e63f6cb122e9932dfc3f01984977cd54b304f7bc009c8fbd6870ede" -->
````json
{
  "C2": "symbolic, not numerically assigned",
  "candidate_sha256": "24fabe48128ddcdade760b36ad2cb2bc4579b39041f0d894b5a906a09cb74d7c",
  "check_labels": [
    "stage1 integer sqrt",
    "stage1 hot microinterval inside clipped piece",
    "stage1 all real receiver cubes capture every hot interval",
    "stage1 all first-coordinate cubes lie in leaf",
    "stage1 actual f row is 3",
    "stage1 exact initial cap ledger",
    "stage1 strong rational low leaf mean",
    "stage1 positive source and dx receiver",
    "stage1 integer scaled capacities",
    "stage1 integer capacities below 2^53",
    "stage1 integer sqrt",
    "stage1 hot microinterval inside clipped piece",
    "stage1 all real receiver cubes capture every hot interval",
    "stage1 all first-coordinate cubes lie in leaf",
    "stage1 actual f row is 3",
    "stage1 exact initial cap ledger",
    "stage1 strong rational low leaf mean",
    "stage1 positive source and dx receiver",
    "stage1 integer scaled capacities",
    "stage1 integer capacities below 2^53",
    "stage2 integer sqrt",
    "stage2 hot microinterval inside clipped piece",
    "stage2 all real receiver cubes capture every hot interval",
    "stage2 all first-coordinate cubes lie in leaf",
    "stage2 actual f row is 3",
    "stage2 exact initial cap ledger",
    "stage2 strong rational low leaf mean",
    "stage2 positive source and dx receiver",
    "stage2 integer scaled capacities",
    "stage2 integer capacities below 2^53",
    "stage2 integer sqrt",
    "stage2 hot microinterval inside clipped piece",
    "stage2 all real receiver cubes capture every hot interval",
    "stage2 all first-coordinate cubes lie in leaf",
    "stage2 actual f row is 3",
    "stage2 exact initial cap ledger",
    "stage2 strong rational low leaf mean",
    "stage2 positive source and dx receiver",
    "stage2 integer scaled capacities",
    "stage2 integer capacities below 2^53",
    "stage3 integer sqrt",
    "stage3 hot microinterval inside clipped piece",
    "stage3 all real receiver cubes capture every hot interval",
    "stage3 hot microinterval inside clipped piece",
    "stage3 all real receiver cubes capture every hot interval",
    "stage3 all first-coordinate cubes lie in leaf",
    "stage3 actual f row is 3",
    "stage3 exact initial cap ledger",
    "stage3 strong rational low leaf mean",
    "stage3 positive source and dx receiver",
    "stage3 integer scaled capacities",
    "stage3 integer capacities below 2^53",
    "stage3 integer sqrt",
    "stage3 hot microinterval inside clipped piece",
    "stage3 all real receiver cubes capture every hot interval",
    "stage3 hot microinterval inside clipped piece",
    "stage3 all real receiver cubes capture every hot interval",
    "stage3 all first-coordinate cubes lie in leaf",
    "stage3 actual f row is 3",
    "stage3 exact initial cap ledger",
    "stage3 strong rational low leaf mean",
    "stage3 positive source and dx receiver",
    "stage3 integer scaled capacities",
    "stage3 integer capacities below 2^53",
    "stage3 integer sqrt",
    "stage3 hot microinterval inside clipped piece",
    "stage3 all real receiver cubes capture every hot interval",
    "stage3 hot microinterval inside clipped piece",
    "stage3 all real receiver cubes capture every hot interval",
    "stage3 all first-coordinate cubes lie in leaf",
    "stage3 actual f row is 3",
    "stage3 exact initial cap ledger",
    "stage3 strong rational low leaf mean",
    "stage3 positive source and dx receiver",
    "stage3 integer scaled capacities",
    "stage3 integer capacities below 2^53",
    "exact frozen graph count",
    "saved input equals independent frozen reconstruction",
    "MATLAB producer status",
    "MATLAB candidate binds full exact input",
    "candidate graph count",
    "stage1_m0 candidate id",
    "stage1_m0 maxflow fixed reconstruction tolerance",
    "stage1_m0 maxflow fixed reconstruction tolerance",
    "stage1_m0 maxflow fixed reconstruction tolerance",
    "stage1_m0 edge vector length",
    "stage1_m0 edge feasibility",
    "stage1_m0 edge feasibility",
    "stage1_m0 edge feasibility",
    "stage1_m0 all node flow conservation",
    "stage1_m0 objective fixed reconstruction tolerance",
    "stage1_m0 MATLAB objective agrees after reconstruction",
    "stage1_m0 no residual augmenting path",
    "stage1_m0 exact flow equals exact cut",
    "stage1_m0 MATLAB cut fixed reconstruction tolerance",
    "stage1_m0 MATLAB cut fixed reconstruction tolerance",
    "stage1_m0 MATLAB cut fixed reconstruction tolerance",
    "stage1_m0 MATLAB cut separates terminals",
    "stage1_m0 MATLAB reported cut is independently optimal",
    "stage1_m0 internal source marginals",
    "stage1_m0 internal target marginals",
    "stage1_m0 reachable targets equal entire neighbor union",
    "stage1_m0 exact concentration defect and residual support",
    "stage1_m0 fixed LP method",
    "stage1_m0 positive LP exitflag",
    "stage1_m0 LP fixed reconstruction tolerance",
    "stage1_m0 LP route vector",
    "stage1_m0 LP source feasibility",
    "stage1_m0 LP target feasibility",
    "stage1_m0 LP exact objective reaches independently proved cut",
    "stage1_m0 LP objective fixed reconstruction tolerance",
    "stage1_m0 LP raw objective reconstruction",
    "stage1_m1 candidate id",
    "stage1_m1 maxflow fixed reconstruction tolerance",
    "stage1_m1 maxflow fixed reconstruction tolerance",
    "stage1_m1 maxflow fixed reconstruction tolerance",
    "stage1_m1 maxflow fixed reconstruction tolerance",
    "stage1_m1 maxflow fixed reconstruction tolerance",
    "stage1_m1 maxflow fixed reconstruction tolerance",
    "stage1_m1 maxflow fixed reconstruction tolerance",
    "stage1_m1 edge vector length",
    "stage1_m1 edge feasibility",
    "stage1_m1 edge feasibility",
    "stage1_m1 edge feasibility",
    "stage1_m1 edge feasibility",
    "stage1_m1 edge feasibility",
    "stage1_m1 edge feasibility",
    "stage1_m1 edge feasibility",
    "stage1_m1 all node flow conservation",
    "stage1_m1 objective fixed reconstruction tolerance",
    "stage1_m1 MATLAB objective agrees after reconstruction",
    "stage1_m1 no residual augmenting path",
    "stage1_m1 exact flow equals exact cut",
    "stage1_m1 MATLAB cut fixed reconstruction tolerance",
    "stage1_m1 MATLAB cut separates terminals",
    "stage1_m1 MATLAB reported cut is independently optimal",
    "stage1_m1 internal source marginals",
    "stage1_m1 internal target marginals",
    "stage1_m1 reachable targets equal entire neighbor union",
    "stage1_m1 exact concentration defect and residual support",
    "stage1_m1 fixed LP method",
    "stage1_m1 positive LP exitflag",
    "stage1_m1 LP fixed reconstruction tolerance",
    "stage1_m1 LP fixed reconstruction tolerance",
    "stage1_m1 LP fixed reconstruction tolerance",
    "stage1_m1 LP route vector",
    "stage1_m1 LP source feasibility",
    "stage1_m1 LP target feasibility",
    "stage1_m1 LP exact objective reaches independently proved cut",
    "stage1_m1 LP objective fixed reconstruction tolerance",
    "stage1_m1 LP raw objective reconstruction",
    "stage2_m0 candidate id",
    "stage2_m0 maxflow fixed reconstruction tolerance",
    "stage2_m0 maxflow fixed reconstruction tolerance",
    "stage2_m0 maxflow fixed reconstruction tolerance",
    "stage2_m0 edge vector length",
    "stage2_m0 edge feasibility",
    "stage2_m0 edge feasibility",
    "stage2_m0 edge feasibility",
    "stage2_m0 all node flow conservation",
    "stage2_m0 objective fixed reconstruction tolerance",
    "stage2_m0 MATLAB objective agrees after reconstruction",
    "stage2_m0 no residual augmenting path",
    "stage2_m0 exact flow equals exact cut",
    "stage2_m0 MATLAB cut fixed reconstruction tolerance",
    "stage2_m0 MATLAB cut fixed reconstruction tolerance",
    "stage2_m0 MATLAB cut fixed reconstruction tolerance",
    "stage2_m0 MATLAB cut separates terminals",
    "stage2_m0 MATLAB reported cut is independently optimal",
    "stage2_m0 internal source marginals",
    "stage2_m0 internal target marginals",
    "stage2_m0 reachable targets equal entire neighbor union",
    "stage2_m0 exact concentration defect and residual support",
    "stage2_m1 candidate id",
    "stage2_m1 maxflow fixed reconstruction tolerance",
    "stage2_m1 maxflow fixed reconstruction tolerance",
    "stage2_m1 maxflow fixed reconstruction tolerance",
    "stage2_m1 maxflow fixed reconstruction tolerance",
    "stage2_m1 maxflow fixed reconstruction tolerance",
    "stage2_m1 edge vector length",
    "stage2_m1 edge feasibility",
    "stage2_m1 edge feasibility",
    "stage2_m1 edge feasibility",
    "stage2_m1 edge feasibility",
    "stage2_m1 edge feasibility",
    "stage2_m1 all node flow conservation",
    "stage2_m1 objective fixed reconstruction tolerance",
    "stage2_m1 MATLAB objective agrees after reconstruction",
    "stage2_m1 no residual augmenting path",
    "stage2_m1 exact flow equals exact cut",
    "stage2_m1 MATLAB cut fixed reconstruction tolerance",
    "stage2_m1 MATLAB cut fixed reconstruction tolerance",
    "stage2_m1 MATLAB cut fixed reconstruction tolerance",
    "stage2_m1 MATLAB cut fixed reconstruction tolerance",
    "stage2_m1 MATLAB cut separates terminals",
    "stage2_m1 MATLAB reported cut is independently optimal",
    "stage2_m1 internal source marginals",
    "stage2_m1 internal target marginals",
    "stage2_m1 reachable targets equal entire neighbor union",
    "stage2_m1 exact concentration defect and residual support",
    "stage3_m0 candidate id",
    "stage3_m0 maxflow fixed reconstruction tolerance",
    "stage3_m0 maxflow fixed reconstruction tolerance",
    "stage3_m0 maxflow fixed reconstruction tolerance",
    "stage3_m0 maxflow fixed reconstruction tolerance",
    "stage3_m0 maxflow fixed reconstruction tolerance",
    "stage3_m0 maxflow fixed reconstruction tolerance",
    "stage3_m0 edge vector length",
    "stage3_m0 edge feasibility",
    "stage3_m0 edge feasibility",
    "stage3_m0 edge feasibility",
    "stage3_m0 edge feasibility",
    "stage3_m0 edge feasibility",
    "stage3_m0 edge feasibility",
    "stage3_m0 all node flow conservation",
    "stage3_m0 objective fixed reconstruction tolerance",
    "stage3_m0 MATLAB objective agrees after reconstruction",
    "stage3_m0 no residual augmenting path",
    "stage3_m0 exact flow equals exact cut",
    "stage3_m0 MATLAB cut fixed reconstruction tolerance",
    "stage3_m0 MATLAB cut fixed reconstruction tolerance",
    "stage3_m0 MATLAB cut fixed reconstruction tolerance",
    "stage3_m0 MATLAB cut fixed reconstruction tolerance",
    "stage3_m0 MATLAB cut fixed reconstruction tolerance",
    "stage3_m0 MATLAB cut separates terminals",
    "stage3_m0 MATLAB reported cut is independently optimal",
    "stage3_m0 internal source marginals",
    "stage3_m0 internal target marginals",
    "stage3_m0 reachable targets equal entire neighbor union",
    "stage3_m0 exact concentration defect and residual support",
    "stage3_m1 candidate id",
    "stage3_m1 maxflow fixed reconstruction tolerance",
    "stage3_m1 maxflow fixed reconstruction tolerance",
    "stage3_m1 maxflow fixed reconstruction tolerance",
    "stage3_m1 maxflow fixed reconstruction tolerance",
    "stage3_m1 maxflow fixed reconstruction tolerance",
    "stage3_m1 maxflow fixed reconstruction tolerance",
    "stage3_m1 maxflow fixed reconstruction tolerance",
    "stage3_m1 maxflow fixed reconstruction tolerance",
    "stage3_m1 maxflow fixed reconstruction tolerance",
    "stage3_m1 maxflow fixed reconstruction tolerance",
    "stage3_m1 maxflow fixed reconstruction tolerance",
    "stage3_m1 maxflow fixed reconstruction tolerance",
    "stage3_m1 edge vector length",
    "stage3_m1 edge feasibility",
    "stage3_m1 edge feasibility",
    "stage3_m1 edge feasibility",
    "stage3_m1 edge feasibility",
    "stage3_m1 edge feasibility",
    "stage3_m1 edge feasibility",
    "stage3_m1 edge feasibility",
    "stage3_m1 edge feasibility",
    "stage3_m1 edge feasibility",
    "stage3_m1 edge feasibility",
    "stage3_m1 edge feasibility",
    "stage3_m1 edge feasibility",
    "stage3_m1 all node flow conservation",
    "stage3_m1 objective fixed reconstruction tolerance",
    "stage3_m1 MATLAB objective agrees after reconstruction",
    "stage3_m1 no residual augmenting path",
    "stage3_m1 exact flow equals exact cut",
    "stage3_m1 MATLAB cut fixed reconstruction tolerance",
    "stage3_m1 MATLAB cut fixed reconstruction tolerance",
    "stage3_m1 MATLAB cut fixed reconstruction tolerance",
    "stage3_m1 MATLAB cut fixed reconstruction tolerance",
    "stage3_m1 MATLAB cut fixed reconstruction tolerance",
    "stage3_m1 MATLAB cut fixed reconstruction tolerance",
    "stage3_m1 MATLAB cut fixed reconstruction tolerance",
    "stage3_m1 MATLAB cut fixed reconstruction tolerance",
    "stage3_m1 MATLAB cut separates terminals",
    "stage3_m1 MATLAB reported cut is independently optimal",
    "stage3_m1 internal source marginals",
    "stage3_m1 internal target marginals",
    "stage3_m1 reachable targets equal entire neighbor union",
    "stage3_m1 exact concentration defect and residual support",
    "stage3_m2 candidate id",
    "stage3_m2 maxflow fixed reconstruction tolerance",
    "stage3_m2 maxflow fixed reconstruction tolerance",
    "stage3_m2 maxflow fixed reconstruction tolerance",
    "stage3_m2 maxflow fixed reconstruction tolerance",
    "stage3_m2 maxflow fixed reconstruction tolerance",
    "stage3_m2 maxflow fixed reconstruction tolerance",
    "stage3_m2 maxflow fixed reconstruction tolerance",
    "stage3_m2 maxflow fixed reconstruction tolerance",
    "stage3_m2 maxflow fixed reconstruction tolerance",
    "stage3_m2 maxflow fixed reconstruction tolerance",
    "stage3_m2 maxflow fixed reconstruction tolerance",
    "stage3_m2 maxflow fixed reconstruction tolerance",
    "stage3_m2 maxflow fixed reconstruction tolerance",
    "stage3_m2 maxflow fixed reconstruction tolerance",
    "stage3_m2 maxflow fixed reconstruction tolerance",
    "stage3_m2 maxflow fixed reconstruction tolerance",
    "stage3_m2 maxflow fixed reconstruction tolerance",
    "stage3_m2 edge vector length",
    "stage3_m2 edge feasibility",
    "stage3_m2 edge feasibility",
    "stage3_m2 edge feasibility",
    "stage3_m2 edge feasibility",
    "stage3_m2 edge feasibility",
    "stage3_m2 edge feasibility",
    "stage3_m2 edge feasibility",
    "stage3_m2 edge feasibility",
    "stage3_m2 edge feasibility",
    "stage3_m2 edge feasibility",
    "stage3_m2 edge feasibility",
    "stage3_m2 edge feasibility",
    "stage3_m2 edge feasibility",
    "stage3_m2 edge feasibility",
    "stage3_m2 edge feasibility",
    "stage3_m2 edge feasibility",
    "stage3_m2 edge feasibility",
    "stage3_m2 all node flow conservation",
    "stage3_m2 objective fixed reconstruction tolerance",
    "stage3_m2 MATLAB objective agrees after reconstruction",
    "stage3_m2 no residual augmenting path",
    "stage3_m2 exact flow equals exact cut",
    "stage3_m2 MATLAB cut fixed reconstruction tolerance",
    "stage3_m2 MATLAB cut fixed reconstruction tolerance",
    "stage3_m2 MATLAB cut fixed reconstruction tolerance",
    "stage3_m2 MATLAB cut fixed reconstruction tolerance",
    "stage3_m2 MATLAB cut fixed reconstruction tolerance",
    "stage3_m2 MATLAB cut fixed reconstruction tolerance",
    "stage3_m2 MATLAB cut fixed reconstruction tolerance",
    "stage3_m2 MATLAB cut fixed reconstruction tolerance",
    "stage3_m2 MATLAB cut fixed reconstruction tolerance",
    "stage3_m2 MATLAB cut fixed reconstruction tolerance",
    "stage3_m2 MATLAB cut separates terminals",
    "stage3_m2 MATLAB reported cut is independently optimal",
    "stage3_m2 internal source marginals",
    "stage3_m2 internal target marginals",
    "stage3_m2 reachable targets equal entire neighbor union",
    "stage3_m2 exact concentration defect and residual support",
    "stage1 integer sqrt",
    "stage1 hot microinterval inside clipped piece",
    "stage1 all real receiver cubes capture every hot interval",
    "stage1 all first-coordinate cubes lie in leaf",
    "stage1 actual f row is 3",
    "stage1 exact initial cap ledger",
    "stage1 strong rational low leaf mean",
    "stage1 positive source and dx receiver",
    "stage1_m0 expected exact optimum",
    "stage1_m0 runningmax increments dominated by original shares",
    "stage1_m0 increment source marginals",
    "stage1_m0 increment target marginals and density cap",
    "stage1_m0 positive increment",
    "stage1_m0 actual allowed index displacement",
    "stage1_m0 exact physical displacement",
    "stage1_m0 all receiver expanded intervals cover targets",
    "stage1_m0 transverse target integration covers at least unit volume",
    "stage1_m0 true cut neighborhood volume bound",
    "stage1_m0 entire clipped thick neighborhood retained",
    "nonnegative reported physical quantity",
    "directed integer log10 bracket",
    "nonnegative reported physical quantity",
    "directed integer log10 bracket",
    "nonnegative reported physical quantity",
    "directed integer log10 bracket",
    "nonnegative reported physical quantity",
    "directed integer log10 bracket",
    "nonnegative reported physical quantity",
    "directed integer log10 bracket",
    "nonnegative reported physical quantity",
    "directed integer log10 bracket",
    "nonnegative reported physical quantity",
    "directed integer log10 bracket",
    "stage1_m1 expected exact optimum",
    "stage1_m1 runningmax increments dominated by original shares",
    "stage1_m1 increment source marginals",
    "stage1_m1 increment target marginals and density cap",
    "stage1_m1 positive increment",
    "stage1_m1 actual allowed index displacement",
    "stage1_m1 exact physical displacement",
    "stage1_m1 all receiver expanded intervals cover targets",
    "stage1_m1 actual allowed index displacement",
    "stage1_m1 exact physical displacement",
    "stage1_m1 all receiver expanded intervals cover targets",
    "stage1_m1 actual allowed index displacement",
    "stage1_m1 exact physical displacement",
    "stage1_m1 all receiver expanded intervals cover targets",
    "stage1_m1 transverse target integration covers at least unit volume",
    "stage1_m1 true cut neighborhood volume bound",
    "nonnegative reported physical quantity",
    "directed integer log10 bracket",
    "nonnegative reported physical quantity",
    "nonnegative reported physical quantity",
    "directed integer log10 bracket",
    "nonnegative reported physical quantity",
    "directed integer log10 bracket",
    "nonnegative reported physical quantity",
    "directed integer log10 bracket",
    "nonnegative reported physical quantity",
    "nonnegative reported physical quantity",
    "directed integer log10 bracket",
    "stage1 full input source conservation",
    "stage1 source maximum not double counted",
    "stage1 real dx traffic conservation",
    "stage1 common remaining source supported in all cuts",
    "stage1 final remaining source bounded by every defect",
    "stage1 full finite scale budget paid",
    "stage1 final full extraction",
    "nonnegative reported physical quantity",
    "directed integer log10 bracket",
    "nonnegative reported physical quantity",
    "directed integer log10 bracket",
    "nonnegative reported physical quantity",
    "directed integer log10 bracket",
    "nonnegative reported physical quantity",
    "directed integer log10 bracket",
    "nonnegative reported physical quantity",
    "directed integer log10 bracket",
    "nonnegative reported physical quantity",
    "directed integer log10 bracket",
    "nonnegative reported physical quantity",
    "directed integer log10 bracket",
    "nonnegative reported physical quantity",
    "directed integer log10 bracket",
    "nonnegative reported physical quantity",
    "directed integer log10 bracket",
    "nonnegative reported physical quantity",
    "nonnegative reported physical quantity",
    "directed integer log10 bracket",
    "nonnegative reported physical quantity",
    "nonnegative reported physical quantity",
    "directed integer log10 bracket",
    "nonnegative reported physical quantity",
    "directed integer log10 bracket",
    "nonnegative reported physical quantity",
    "directed integer log10 bracket",
    "nonnegative reported physical quantity",
    "directed integer log10 bracket",
    "stage2 integer sqrt",
    "stage2 hot microinterval inside clipped piece",
    "stage2 all real receiver cubes capture every hot interval",
    "stage2 all first-coordinate cubes lie in leaf",
    "stage2 actual f row is 3",
    "stage2 exact initial cap ledger",
    "stage2 strong rational low leaf mean",
    "stage2 positive source and dx receiver",
    "stage2_m0 expected exact optimum",
    "stage2_m0 runningmax increments dominated by original shares",
    "stage2_m0 increment source marginals",
    "stage2_m0 increment target marginals and density cap",
    "stage2_m0 positive increment",
    "stage2_m0 actual allowed index displacement",
    "stage2_m0 exact physical displacement",
    "stage2_m0 all receiver expanded intervals cover targets",
    "stage2_m0 transverse target integration covers at least unit volume",
    "stage2_m0 true cut neighborhood volume bound",
    "stage2_m0 entire clipped thick neighborhood retained",
    "nonnegative reported physical quantity",
    "directed integer log10 bracket",
    "nonnegative reported physical quantity",
    "directed integer log10 bracket",
    "nonnegative reported physical quantity",
    "directed integer log10 bracket",
    "nonnegative reported physical quantity",
    "directed integer log10 bracket",
    "nonnegative reported physical quantity",
    "directed integer log10 bracket",
    "nonnegative reported physical quantity",
    "directed integer log10 bracket",
    "nonnegative reported physical quantity",
    "directed integer log10 bracket",
    "stage2_m1 expected exact optimum",
    "stage2_m1 runningmax increments dominated by original shares",
    "stage2_m1 increment source marginals",
    "stage2_m1 increment target marginals and density cap",
    "stage2_m1 positive increment",
    "stage2_m1 actual allowed index displacement",
    "stage2_m1 exact physical displacement",
    "stage2_m1 all receiver expanded intervals cover targets",
    "stage2_m1 actual allowed index displacement",
    "stage2_m1 exact physical displacement",
    "stage2_m1 all receiver expanded intervals cover targets",
    "stage2_m1 transverse target integration covers at least unit volume",
    "stage2_m1 true cut neighborhood volume bound",
    "stage2_m1 entire clipped thick neighborhood retained",
    "nonnegative reported physical quantity",
    "directed integer log10 bracket",
    "nonnegative reported physical quantity",
    "directed integer log10 bracket",
    "nonnegative reported physical quantity",
    "directed integer log10 bracket",
    "nonnegative reported physical quantity",
    "directed integer log10 bracket",
    "nonnegative reported physical quantity",
    "directed integer log10 bracket",
    "nonnegative reported physical quantity",
    "directed integer log10 bracket",
    "nonnegative reported physical quantity",
    "directed integer log10 bracket",
    "stage2 full input source conservation",
    "stage2 source maximum not double counted",
    "stage2 real dx traffic conservation",
    "stage2 common remaining source supported in all cuts",
    "stage2 final remaining source bounded by every defect",
    "stage2 full finite scale budget paid",
    "stage2 clipped exact outcomes",
    "nonnegative reported physical quantity",
    "directed integer log10 bracket",
    "nonnegative reported physical quantity",
    "directed integer log10 bracket",
    "nonnegative reported physical quantity",
    "directed integer log10 bracket",
    "nonnegative reported physical quantity",
    "directed integer log10 bracket",
    "nonnegative reported physical quantity",
    "directed integer log10 bracket",
    "nonnegative reported physical quantity",
    "directed integer log10 bracket",
    "nonnegative reported physical quantity",
    "directed integer log10 bracket",
    "nonnegative reported physical quantity",
    "directed integer log10 bracket",
    "nonnegative reported physical quantity",
    "directed integer log10 bracket",
    "nonnegative reported physical quantity",
    "directed integer log10 bracket",
    "nonnegative reported physical quantity",
    "directed integer log10 bracket",
    "nonnegative reported physical quantity",
    "directed integer log10 bracket",
    "nonnegative reported physical quantity",
    "directed integer log10 bracket",
    "nonnegative reported physical quantity",
    "directed integer log10 bracket",
    "nonnegative reported physical quantity",
    "directed integer log10 bracket",
    "nonnegative reported physical quantity",
    "directed integer log10 bracket",
    "stage3 integer sqrt",
    "stage3 hot microinterval inside clipped piece",
    "stage3 all real receiver cubes capture every hot interval",
    "stage3 hot microinterval inside clipped piece",
    "stage3 all real receiver cubes capture every hot interval",
    "stage3 all first-coordinate cubes lie in leaf",
    "stage3 actual f row is 3",
    "stage3 exact initial cap ledger",
    "stage3 strong rational low leaf mean",
    "stage3 positive source and dx receiver",
    "stage3_m0 expected exact optimum",
    "stage3_m0 runningmax increments dominated by original shares",
    "stage3_m0 increment source marginals",
    "stage3_m0 increment target marginals and density cap",
    "stage3_m0 positive increment",
    "stage3_m0 actual allowed index displacement",
    "stage3_m0 exact physical displacement",
    "stage3_m0 all receiver expanded intervals cover targets",
    "stage3_m0 actual allowed index displacement",
    "stage3_m0 exact physical displacement",
    "stage3_m0 all receiver expanded intervals cover targets",
    "stage3_m0 transverse target integration covers at least unit volume",
    "stage3_m0 true cut neighborhood volume bound",
    "stage3_m0 entire clipped thick neighborhood retained",
    "stage3_m0 entire clipped thick neighborhood retained",
    "nonnegative reported physical quantity",
    "directed integer log10 bracket",
    "nonnegative reported physical quantity",
    "directed integer log10 bracket",
    "nonnegative reported physical quantity",
    "directed integer log10 bracket",
    "nonnegative reported physical quantity",
    "directed integer log10 bracket",
    "nonnegative reported physical quantity",
    "directed integer log10 bracket",
    "nonnegative reported physical quantity",
    "directed integer log10 bracket",
    "nonnegative reported physical quantity",
    "directed integer log10 bracket",
    "stage3_m1 expected exact optimum",
    "stage3_m1 runningmax increments dominated by original shares",
    "stage3_m1 increment source marginals",
    "stage3_m1 increment target marginals and density cap",
    "stage3_m1 positive increment",
    "stage3_m1 actual allowed index displacement",
    "stage3_m1 exact physical displacement",
    "stage3_m1 all receiver expanded intervals cover targets",
    "stage3_m1 actual allowed index displacement",
    "stage3_m1 exact physical displacement",
    "stage3_m1 all receiver expanded intervals cover targets",
    "stage3_m1 actual allowed index displacement",
    "stage3_m1 exact physical displacement",
    "stage3_m1 all receiver expanded intervals cover targets",
    "stage3_m1 transverse target integration covers at least unit volume",
    "stage3_m1 true cut neighborhood volume bound",
    "stage3_m1 entire clipped thick neighborhood retained",
    "stage3_m1 entire clipped thick neighborhood retained",
    "nonnegative reported physical quantity",
    "directed integer log10 bracket",
    "nonnegative reported physical quantity",
    "directed integer log10 bracket",
    "nonnegative reported physical quantity",
    "directed integer log10 bracket",
    "nonnegative reported physical quantity",
    "directed integer log10 bracket",
    "nonnegative reported physical quantity",
    "directed integer log10 bracket",
    "nonnegative reported physical quantity",
    "directed integer log10 bracket",
    "nonnegative reported physical quantity",
    "directed integer log10 bracket",
    "stage3_m2 expected exact optimum",
    "stage3_m2 runningmax increments dominated by original shares",
    "stage3_m2 increment source marginals",
    "stage3_m2 increment target marginals and density cap",
    "stage3_m2 positive increment",
    "stage3_m2 actual allowed index displacement",
    "stage3_m2 exact physical displacement",
    "stage3_m2 all receiver expanded intervals cover targets",
    "stage3_m2 actual allowed index displacement",
    "stage3_m2 exact physical displacement",
    "stage3_m2 all receiver expanded intervals cover targets",
    "stage3_m2 actual allowed index displacement",
    "stage3_m2 exact physical displacement",
    "stage3_m2 all receiver expanded intervals cover targets",
    "stage3_m2 actual allowed index displacement",
    "stage3_m2 exact physical displacement",
    "stage3_m2 all receiver expanded intervals cover targets",
    "stage3_m2 actual allowed index displacement",
    "stage3_m2 exact physical displacement",
    "stage3_m2 all receiver expanded intervals cover targets",
    "stage3_m2 actual allowed index displacement",
    "stage3_m2 exact physical displacement",
    "stage3_m2 all receiver expanded intervals cover targets",
    "stage3_m2 actual allowed index displacement",
    "stage3_m2 exact physical displacement",
    "stage3_m2 all receiver expanded intervals cover targets",
    "stage3_m2 transverse target integration covers at least unit volume",
    "stage3_m2 true cut neighborhood volume bound",
    "stage3_m2 entire clipped thick neighborhood retained",
    "stage3_m2 entire clipped thick neighborhood retained",
    "nonnegative reported physical quantity",
    "directed integer log10 bracket",
    "nonnegative reported physical quantity",
    "directed integer log10 bracket",
    "nonnegative reported physical quantity",
    "directed integer log10 bracket",
    "nonnegative reported physical quantity",
    "directed integer log10 bracket",
    "nonnegative reported physical quantity",
    "directed integer log10 bracket",
    "nonnegative reported physical quantity",
    "directed integer log10 bracket",
    "nonnegative reported physical quantity",
    "directed integer log10 bracket",
    "stage3 full input source conservation",
    "stage3 source maximum not double counted",
    "stage3 real dx traffic conservation",
    "stage3 common remaining source supported in all cuts",
    "stage3 final remaining source bounded by every defect",
    "stage3 full finite scale budget paid",
    "stage3 nonmonotone source extraction at second scale",
    "stage3 genuine maximum exceeds both scalar optima",
    "stage3 maximum is below overlapping scalar sum",
    "stage3 final runningmax allowed range",
    "stage3 positive common cut residual",
    "nonnegative reported physical quantity",
    "directed integer log10 bracket",
    "nonnegative reported physical quantity",
    "directed integer log10 bracket",
    "nonnegative reported physical quantity",
    "directed integer log10 bracket",
    "nonnegative reported physical quantity",
    "directed integer log10 bracket",
    "nonnegative reported physical quantity",
    "directed integer log10 bracket",
    "nonnegative reported physical quantity",
    "directed integer log10 bracket",
    "nonnegative reported physical quantity",
    "directed integer log10 bracket",
    "nonnegative reported physical quantity",
    "directed integer log10 bracket",
    "nonnegative reported physical quantity",
    "directed integer log10 bracket",
    "nonnegative reported physical quantity",
    "directed integer log10 bracket",
    "nonnegative reported physical quantity",
    "directed integer log10 bracket",
    "nonnegative reported physical quantity",
    "directed integer log10 bracket",
    "nonnegative reported physical quantity",
    "directed integer log10 bracket",
    "nonnegative reported physical quantity",
    "directed integer log10 bracket",
    "nonnegative reported physical quantity",
    "directed integer log10 bracket",
    "nonnegative reported physical quantity",
    "directed integer log10 bracket"
  ],
  "checks_passed": 688,
  "fixed_exp_bounds": {
    "12": [
      "258c46e6481e84796f21d852e5c524475b832cba1a5eb5d771097b4585d3130e",
      "ee11bacc206200b476e66861a77d64febd3960e691795d145fc4cf425da88479"
    ],
    "4": [
      "fd3f6ad63f0f3dc8f4f2f80be799117ac26f688c150a453dae2d900af6675b61",
      "6b112b070031ab9c02c997274b348468ce7e803c0e0ce8320f5e6a804f9882e7"
    ],
    "8": [
      "6a2822efa7cc6f57c866f5314236ad9a4d719e7fabbc3baa6508688a8a29c55d",
      "4b77eb3bfdcac1d604d3a07c6543881f69ef3a18469620b884b486b4556848f4"
    ]
  },
  "input_sha256": "57dc665a54754b0332b6a196bf645f07ae2276c9594f8091556090b30a7e1e02",
  "linprog_calls": 2,
  "matlab_version": "26.1.0.3312084 (R2026a) Update 4",
  "maxflow_calls": 7,
  "no_claim": "These three structured examples do not imply a uniform extracted fraction or general root-order closure.",
  "physical_input_families": 3,
  "protocol": "R107 frozen residual geometry v1",
  "scope": "D20 and D27-D31 geometric transport; not FULL/deep/D24 or soft-hard N1-N30",
  "stages": [
    {
      "A_mu": "11/4",
      "Af": "3/1",
      "FULL_or_deep_certified": false,
      "actual_T_mu": {
        "expression": "A_mu*receiver volume",
        "fraction_sha256": "27d158a7e8a73ece5dd6cddbae66a5d8b135410640fad042af503fb35102e2dd",
        "log10_bracket": [
          0,
          1
        ]
      },
      "epsilon": "1/100",
      "exact_scale_budget_over_sqrt_n": {
        "expression": "sum F_nm^2*tau/sqrt_n",
        "fraction_sha256": "81e79233405db12412ab26539ba04beb3f25ba7cbc4908b30cde78020ac1fe15",
        "log10_bracket": [
          1,
          2
        ]
      },
      "extracted_fraction_of_mu_and_T": {
        "decimal_interval": [
          "1.000000000000000000",
          "1.000000000000000000"
        ],
        "exact_fraction": "1/1",
        "expression": "runningmax extraction / original source",
        "fraction_sha256": "253d950f11ebdbeb4c2d54c57803deb69869b832a2e03010620d462a85d15290",
        "log10_bracket": [
          0,
          1
        ]
      },
      "f_mass": {
        "expression": "3*transverse volume",
        "fraction_sha256": "02925afd44e2946e583a7f6434585a77c146fcf4533cd4b3793f62f0d5b7c60c",
        "log10_bracket": [
          0,
          1
        ]
      },
      "f_peak": "12/1",
      "first_receiver_interval": [
        "57/8",
        "63/8"
      ],
      "full_leaf_volume": {
        "expression": "(16n)^n",
        "fraction_sha256": "aa02a54d34887d0cbf45005a369f86260c589b6c30d45d105474a4e1915cba43",
        "log10_bracket": [
          1,
          2
        ]
      },
      "hot_intervals": [
        [
          "59/8",
          "61/8"
        ]
      ],
      "initial_point_cap_mass": {
        "expression": "sqrt_n*occupied source volume",
        "fraction_sha256": "f70b94aeb67de2a5eb4bd8c2ea85128f13776cb545a661abe422b378a6cf3099",
        "log10_bracket": [
          -1,
          0
        ]
      },
      "input_mu_mass": {
        "expression": "A_mu*transverse volume",
        "fraction_sha256": "426064218d85a94e3ed90462441c4dbfa7c1641d7430ff6b60d252bf81824b5c",
        "log10_bracket": [
          0,
          1
        ]
      },
      "leaf_left": "0/1",
      "leaf_side": 16,
      "n": 1,
      "new_epsilon_X": {
        "expression": "|E|/100",
        "fraction_sha256": "a0cd789f26c57fcdb9f69a0ab30cd39972978dab488e7a4d283fc1e84317992f",
        "log10_bracket": [
          -3,
          -2
        ]
      },
      "occupied_source_volume": {
        "expression": "total hot length * transverse volume",
        "fraction_sha256": "f70b94aeb67de2a5eb4bd8c2ea85128f13776cb545a661abe422b378a6cf3099",
        "log10_bracket": [
          -1,
          0
        ]
      },
      "receiver_volume": {
        "expression": "first receiver length*(16n-1)^(n-1)",
        "fraction_sha256": "5132a20379415fe98f3a0700afc2a901e9b01af839b5454a8659152f0782c223",
        "log10_bracket": [
          -1,
          0
        ]
      },
      "residual_peak": "11/1",
      "runningmax_actual_extracted_traffic": {
        "expression": "runningmax reduced extraction*receiver volume",
        "fraction_sha256": "27d158a7e8a73ece5dd6cddbae66a5d8b135410640fad042af503fb35102e2dd",
        "log10_bracket": [
          0,
          1
        ]
      },
      "runningmax_actual_residual_traffic": {
        "expression": "remaining reduced source*receiver volume",
        "fraction_sha256": "a93875fe509ac2fae0e0939d3ec71c4d978244c7398dd7185ca68c393426a5a6",
        "log10_bracket": null
      },
      "runningmax_final_extracted_mass": {
        "expression": "runningmax reduced extraction*transverse volume",
        "fraction_sha256": "426064218d85a94e3ed90462441c4dbfa7c1641d7430ff6b60d252bf81824b5c",
        "log10_bracket": [
          0,
          1
        ]
      },
      "runningmax_final_residual_mass": {
        "expression": "remaining reduced source*transverse volume",
        "fraction_sha256": "a93875fe509ac2fae0e0939d3ec71c4d978244c7398dd7185ca68c393426a5a6",
        "log10_bracket": null
      },
      "scales": [
        {
          "F_nm": {
            "expression": "(1+2(m+1)/n)^n",
            "fraction_sha256": "02925afd44e2946e583a7f6434585a77c146fcf4533cd4b3793f62f0d5b7c60c",
            "log10_bracket": [
              0,
              1
            ]
          },
          "canonical_residual_cut_nodes": [
            1,
            2,
            3
          ],
          "cut_defect_reduced": {
            "decimal_interval": [
              "1.750000000000000000",
              "1.750000000000000000"
            ],
            "exact_fraction": "7/4",
            "expression": "reduced exact cut defect",
            "fraction_sha256": "64209b4db9fbe2249b534a6def33e737ddffcc08162dcd83aaf58f9554bc7e8b",
            "log10_bracket": [
              0,
              1
            ]
          },
          "cut_neighbor_full_volume": {
            "expression": "neighbor first length * transverse volume",
            "fraction_sha256": "253d950f11ebdbeb4c2d54c57803deb69869b832a2e03010620d462a85d15290",
            "log10_bracket": [
              0,
              1
            ]
          },
          "expanded_receiver_full_side": "3/1",
          "increment_actual_dx_traffic": {
            "expression": "reduced increment * receiver volume",
            "fraction_sha256": "5132a20379415fe98f3a0700afc2a901e9b01af839b5454a8659152f0782c223",
            "log10_bracket": [
              -1,
              0
            ]
          },
          "increment_delta": [
            "4/11"
          ],
          "increment_internal_flow_reduced": [
            "1/1"
          ],
          "increment_physical_mass": {
            "expression": "reduced increment * transverse volume",
            "fraction_sha256": "253d950f11ebdbeb4c2d54c57803deb69869b832a2e03010620d462a85d15290",
            "log10_bracket": [
              0,
              1
            ]
          },
          "integer_scale": 4,
          "m": 0,
          "maxflow_reduced": {
            "decimal_interval": [
              "1.000000000000000000",
              "1.000000000000000000"
            ],
            "exact_fraction": "1/1",
            "expression": "reduced maxflow",
            "fraction_sha256": "253d950f11ebdbeb4c2d54c57803deb69869b832a2e03010620d462a85d15290",
            "log10_bracket": [
              0,
              1
            ]
          },
          "optimal_integer_edge_flow": [
            4,
            4,
            4
          ],
          "runningmax_extracted_reduced": {
            "decimal_interval": [
              "1.000000000000000000",
              "1.000000000000000000"
            ],
            "exact_fraction": "1/1",
            "expression": "sum_i a_i max_{j<=scale}theta_i^j",
            "fraction_sha256": "253d950f11ebdbeb4c2d54c57803deb69869b832a2e03010620d462a85d15290",
            "log10_bracket": [
              0,
              1
            ]
          },
          "runningmax_q": [
            "4/11"
          ],
          "source_fraction_theta": [
            "4/11"
          ],
          "target_indices": [
            7
          ],
          "tau": "1/1"
        },
        {
          "F_nm": {
            "expression": "(1+2(m+1)/n)^n",
            "fraction_sha256": "b8db3faf75728b2b9ec1e1dc23d41abc67c2e69b1b753437e374178995ae0d3b",
            "log10_bracket": [
              0,
              1
            ]
          },
          "canonical_residual_cut_nodes": [
            1
          ],
          "cut_defect_reduced": {
            "decimal_interval": [
              "0.000000000000000000",
              "0.000000000000000000"
            ],
            "exact_fraction": "0/1",
            "expression": "reduced exact cut defect",
            "fraction_sha256": "a93875fe509ac2fae0e0939d3ec71c4d978244c7398dd7185ca68c393426a5a6",
            "log10_bracket": null
          },
          "cut_neighbor_full_volume": {
            "expression": "neighbor first length * transverse volume",
            "fraction_sha256": "a93875fe509ac2fae0e0939d3ec71c4d978244c7398dd7185ca68c393426a5a6",
            "log10_bracket": null
          },
          "expanded_receiver_full_side": "5/1",
          "increment_actual_dx_traffic": {
            "expression": "reduced increment * receiver volume",
            "fraction_sha256": "e6bb345fcb32363751e011b3c14925c114fe8599036c025923a80db50407e3fa",
            "log10_bracket": [
              0,
              1
            ]
          },
          "increment_delta": [
            "7/11"
          ],
          "increment_internal_flow_reduced": [
            "7/11",
            "7/11",
            "21/44"
          ],
          "increment_physical_mass": {
            "expression": "reduced increment * transverse volume",
            "fraction_sha256": "64209b4db9fbe2249b534a6def33e737ddffcc08162dcd83aaf58f9554bc7e8b",
            "log10_bracket": [
              0,
              1
            ]
          },
          "integer_scale": 4,
          "m": 1,
          "maxflow_reduced": {
            "decimal_interval": [
              "2.750000000000000000",
              "2.750000000000000000"
            ],
            "exact_fraction": "11/4",
            "expression": "reduced maxflow",
            "fraction_sha256": "426064218d85a94e3ed90462441c4dbfa7c1641d7430ff6b60d252bf81824b5c",
            "log10_bracket": [
              0,
              1
            ]
          },
          "optimal_integer_edge_flow": [
            11,
            4,
            4,
            3,
            4,
            4,
            3
          ],
          "runningmax_extracted_reduced": {
            "decimal_interval": [
              "2.750000000000000000",
              "2.750000000000000000"
            ],
            "exact_fraction": "11/4",
            "expression": "sum_i a_i max_{j<=scale}theta_i^j",
            "fraction_sha256": "426064218d85a94e3ed90462441c4dbfa7c1641d7430ff6b60d252bf81824b5c",
            "log10_bracket": [
              0,
              1
            ]
          },
          "runningmax_q": [
            "1/1"
          ],
          "source_fraction_theta": [
            "1/1"
          ],
          "target_indices": [
            6,
            7,
            8
          ],
          "tau": "1/1"
        }
      ],
      "source_indices": [
        7
      ],
      "source_payment_coefficient_divided_by_C2_squared": {
        "expression": "25*sum F_nm^2*tau",
        "fraction_sha256": "db3f09d12fe39e0c4698c001e0735f3c696119c58a5e9812cd8586f0aeeed1a5",
        "log10_bracket": [
          2,
          3
        ]
      },
      "stage": "stage1",
      "transverse_interval": [
        "0/1",
        "16/1"
      ],
      "transverse_repetition": 0,
      "transverse_volume": {
        "expression": "(16n)^(n-1)",
        "fraction_sha256": "253d950f11ebdbeb4c2d54c57803deb69869b832a2e03010620d462a85d15290",
        "log10_bracket": [
          0,
          1
        ]
      },
      "unpaid_residual_kept_with_coefficient_one": true
    },
    {
      "A_mu": "23/8",
      "Af": "3/1",
      "FULL_or_deep_certified": false,
      "actual_T_mu": {
        "expression": "A_mu*receiver volume",
        "fraction_sha256": "bfbeb6528a4f97d58ec307c6e0ebee5a3a13cb5c0927722201aca339b590d5bd",
        "log10_bracket": [
          4,
          5
        ]
      },
      "epsilon": "1/100",
      "exact_scale_budget_over_sqrt_n": {
        "expression": "sum F_nm^2*tau/sqrt_n",
        "fraction_sha256": "dda6e02484a4bf8b3a46cf2efdbce628cd41ef8ae5cb399d700d6577565043cb",
        "log10_bracket": [
          2,
          3
        ]
      },
      "extracted_fraction_of_mu_and_T": {
        "decimal_interval": [
          "0.130434782608695652",
          "0.130434782608695653"
        ],
        "exact_fraction": "3/23",
        "expression": "runningmax extraction / original source",
        "fraction_sha256": "d68b48a523719788ec003737500907056a2bcce272c47dc77b7eae7b04e08bda",
        "log10_bracket": [
          -1,
          0
        ]
      },
      "f_mass": {
        "expression": "3*transverse volume",
        "fraction_sha256": "fb6b7d7c758992e595ee0514a594d51b39ec9bd870640cca257674436bdc65a1",
        "log10_bracket": [
          5,
          6
        ]
      },
      "f_peak": "48/1",
      "first_receiver_interval": [
        "5/8",
        "11/16"
      ],
      "full_leaf_volume": {
        "expression": "(16n)^n",
        "fraction_sha256": "1ff99a57d6078bfd67da127a59c767c15e2917cbda17788d5a3a59ce1e809598",
        "log10_bracket": [
          7,
          8
        ]
      },
      "hot_intervals": [
        [
          "3/16",
          "1/4"
        ]
      ],
      "initial_point_cap_mass": {
        "expression": "sqrt_n*occupied source volume",
        "fraction_sha256": "ce66b34e6c105eeb66145faf766b099d94ef3d99d300e618e2fdd93c2194cd52",
        "log10_bracket": [
          4,
          5
        ]
      },
      "input_mu_mass": {
        "expression": "A_mu*transverse volume",
        "fraction_sha256": "18f284621f03c5cd6f9b0e6ee4bd9f3c5e8aff6d1e370a34d701afb9180faba7",
        "log10_bracket": [
          5,
          6
        ]
      },
      "leaf_left": "1/8",
      "leaf_side": 64,
      "n": 4,
      "new_epsilon_X": {
        "expression": "|E|/100",
        "fraction_sha256": "5609cba9bf73de6ecc79ecdb98b4c85e1f632de7467e33007543d5c1e5d3e423",
        "log10_bracket": [
          2,
          3
        ]
      },
      "occupied_source_volume": {
        "expression": "total hot length * transverse volume",
        "fraction_sha256": "051693690154487209c609ce3189a0a1b95b189c0b7388e0dcae718ef4d34e1a",
        "log10_bracket": [
          4,
          5
        ]
      },
      "receiver_volume": {
        "expression": "first receiver length*(16n-1)^(n-1)",
        "fraction_sha256": "aeed939832e601a164b2b7da40ebd60cc1628cd3da5e98716d6240acbb028350",
        "log10_bracket": [
          4,
          5
        ]
      },
      "residual_peak": "46/1",
      "runningmax_actual_extracted_traffic": {
        "expression": "runningmax reduced extraction*receiver volume",
        "fraction_sha256": "2e3ff66a3ec2a2e0938e5dd48519c0c2f5084c26efd4b8e8d0706e7b9ea7fd36",
        "log10_bracket": [
          3,
          4
        ]
      },
      "runningmax_actual_residual_traffic": {
        "expression": "remaining reduced source*receiver volume",
        "fraction_sha256": "f3c068a8f0c489d8f66409eb1f2e55eb0c8435ef61a433d9bbd53fff3635792c",
        "log10_bracket": [
          4,
          5
        ]
      },
      "runningmax_final_extracted_mass": {
        "expression": "runningmax reduced extraction*transverse volume",
        "fraction_sha256": "dcb9f546db554d1f2b1a66095766408e1ece33f2da5b38932146cb98273a66f3",
        "log10_bracket": [
          4,
          5
        ]
      },
      "runningmax_final_residual_mass": {
        "expression": "remaining reduced source*transverse volume",
        "fraction_sha256": "51434294c63eb46f475e3d8c3cd6bbb22fcee801a2231ad818bba8cbb3be4d7b",
        "log10_bracket": [
          5,
          6
        ]
      },
      "scales": [
        {
          "F_nm": {
            "expression": "(1+2(m+1)/n)^n",
            "fraction_sha256": "c216a336abc09a52618cddf51440b4848f08694185a94855f5b367f72f493dfc",
            "log10_bracket": [
              0,
              1
            ]
          },
          "canonical_residual_cut_nodes": [
            1,
            2,
            3
          ],
          "cut_defect_reduced": {
            "decimal_interval": [
              "2.625000000000000000",
              "2.625000000000000000"
            ],
            "exact_fraction": "21/8",
            "expression": "reduced exact cut defect",
            "fraction_sha256": "e676c6c5b06fa9d758f2aed7f34ae397aa2cbfcf62ba204782ac84a0ca7d7535",
            "log10_bracket": [
              0,
              1
            ]
          },
          "cut_neighbor_full_volume": {
            "expression": "neighbor first length * transverse volume",
            "fraction_sha256": "ce66b34e6c105eeb66145faf766b099d94ef3d99d300e618e2fdd93c2194cd52",
            "log10_bracket": [
              4,
              5
            ]
          },
          "expanded_receiver_full_side": "3/2",
          "increment_actual_dx_traffic": {
            "expression": "reduced increment * receiver volume",
            "fraction_sha256": "64ed4ca28cf810b361a4a5729a2e93b873cdf9430653df6f0467ff1bad710ce3",
            "log10_bracket": [
              3,
              4
            ]
          },
          "increment_delta": [
            "2/23"
          ],
          "increment_internal_flow_reduced": [
            "1/4"
          ],
          "increment_physical_mass": {
            "expression": "reduced increment * transverse volume",
            "fraction_sha256": "c3df10c834c3a4abd0bd4ebac7fc361fa378f167d271050db652d3c448e8d52b",
            "log10_bracket": [
              4,
              5
            ]
          },
          "integer_scale": 8,
          "m": 0,
          "maxflow_reduced": {
            "decimal_interval": [
              "0.250000000000000000",
              "0.250000000000000000"
            ],
            "exact_fraction": "1/4",
            "expression": "reduced maxflow",
            "fraction_sha256": "f70b94aeb67de2a5eb4bd8c2ea85128f13776cb545a661abe422b378a6cf3099",
            "log10_bracket": [
              -1,
              0
            ]
          },
          "optimal_integer_edge_flow": [
            2,
            2,
            2
          ],
          "runningmax_extracted_reduced": {
            "decimal_interval": [
              "0.250000000000000000",
              "0.250000000000000000"
            ],
            "exact_fraction": "1/4",
            "expression": "sum_i a_i max_{j<=scale}theta_i^j",
            "fraction_sha256": "f70b94aeb67de2a5eb4bd8c2ea85128f13776cb545a661abe422b378a6cf3099",
            "log10_bracket": [
              -1,
              0
            ]
          },
          "runningmax_q": [
            "2/23"
          ],
          "source_fraction_theta": [
            "2/23"
          ],
          "target_indices": [
            0
          ],
          "tau": "2/1"
        },
        {
          "F_nm": {
            "expression": "(1+2(m+1)/n)^n",
            "fraction_sha256": "aa02a54d34887d0cbf45005a369f86260c589b6c30d45d105474a4e1915cba43",
            "log10_bracket": [
              1,
              2
            ]
          },
          "canonical_residual_cut_nodes": [
            1,
            2,
            3,
            4
          ],
          "cut_defect_reduced": {
            "decimal_interval": [
              "2.500000000000000000",
              "2.500000000000000000"
            ],
            "exact_fraction": "5/2",
            "expression": "reduced exact cut defect",
            "fraction_sha256": "06a89c05b4eae0f2acac44075fe7d5dcde1e2d1a23aeb7270b11556c42a39315",
            "log10_bracket": [
              0,
              1
            ]
          },
          "cut_neighbor_full_volume": {
            "expression": "neighbor first length * transverse volume",
            "fraction_sha256": "dcb9f546db554d1f2b1a66095766408e1ece33f2da5b38932146cb98273a66f3",
            "log10_bracket": [
              4,
              5
            ]
          },
          "expanded_receiver_full_side": "2/1",
          "increment_actual_dx_traffic": {
            "expression": "reduced increment * receiver volume",
            "fraction_sha256": "f9e84313b8d4ccd402a0cb1ffe3b034be5aa86dd82ceeaf79a2b598d68fdc46c",
            "log10_bracket": [
              3,
              4
            ]
          },
          "increment_delta": [
            "1/23"
          ],
          "increment_internal_flow_reduced": [
            "1/24",
            "1/12"
          ],
          "increment_physical_mass": {
            "expression": "reduced increment * transverse volume",
            "fraction_sha256": "ce66b34e6c105eeb66145faf766b099d94ef3d99d300e618e2fdd93c2194cd52",
            "log10_bracket": [
              4,
              5
            ]
          },
          "integer_scale": 8,
          "m": 1,
          "maxflow_reduced": {
            "decimal_interval": [
              "0.375000000000000000",
              "0.375000000000000000"
            ],
            "exact_fraction": "3/8",
            "expression": "reduced maxflow",
            "fraction_sha256": "896af01783cc4ba66a114b2b1cc0284bad63a52fca0571dafbbed491c95972c5",
            "log10_bracket": [
              -1,
              0
            ]
          },
          "optimal_integer_edge_flow": [
            3,
            1,
            2,
            1,
            2
          ],
          "runningmax_extracted_reduced": {
            "decimal_interval": [
              "0.375000000000000000",
              "0.375000000000000000"
            ],
            "exact_fraction": "3/8",
            "expression": "sum_i a_i max_{j<=scale}theta_i^j",
            "fraction_sha256": "896af01783cc4ba66a114b2b1cc0284bad63a52fca0571dafbbed491c95972c5",
            "log10_bracket": [
              -1,
              0
            ]
          },
          "runningmax_q": [
            "3/23"
          ],
          "source_fraction_theta": [
            "3/23"
          ],
          "target_indices": [
            0,
            1
          ],
          "tau": "1/1"
        }
      ],
      "source_indices": [
        0
      ],
      "source_payment_coefficient_divided_by_C2_squared": {
        "expression": "25*sum F_nm^2*tau",
        "fraction_sha256": "7f38f4bc706d875a824cf7d0693abf62f4f9b9ba328bea8a4e2e2b9def68315d",
        "log10_bracket": [
          3,
          4
        ]
      },
      "stage": "stage2",
      "transverse_interval": [
        "1/8",
        "513/8"
      ],
      "transverse_repetition": 3,
      "transverse_volume": {
        "expression": "(16n)^(n-1)",
        "fraction_sha256": "73b08dd21a601863035f1394bc9323d55351c3ae867c1941ad7a1f1c7ebf87dc",
        "log10_bracket": [
          5,
          6
        ]
      },
      "unpaid_residual_kept_with_coefficient_one": true
    },
    {
      "A_mu": "95/32",
      "Af": "3/1",
      "FULL_or_deep_certified": false,
      "actual_T_mu": {
        "expression": "A_mu*receiver volume",
        "fraction_sha256": "7416e2e651dd365ef83e4d2a5b1b46ea127c7480011736f071d54c5a9565f5c4",
        "log10_bracket": [
          4308,
          4309
        ]
      },
      "epsilon": "1/100",
      "exact_scale_budget_over_sqrt_n": {
        "expression": "sum F_nm^2*tau/sqrt_n",
        "fraction_sha256": "d456cb9b273dc2f476960eb7ff6cf2a4d56a9ccf6d72b0eb60798149effc1ee0",
        "log10_bracket": [
          3,
          4
        ]
      },
      "extracted_fraction_of_mu_and_T": {
        "decimal_interval": [
          "0.002302631578947368",
          "0.002302631578947369"
        ],
        "exact_fraction": "7/3040",
        "expression": "runningmax extraction / original source",
        "fraction_sha256": "63ff368e47a413c91878091b15388828d96d9d003c2120583905967cbf0a7784",
        "log10_bracket": [
          -3,
          -2
        ]
      },
      "f_mass": {
        "expression": "3*transverse volume",
        "fraction_sha256": "8d33f33392fe5325664c92e369296299db92f53b7c26fe83df3a3d4a8d685fd4",
        "log10_bracket": [
          4311,
          4312
        ]
      },
      "f_peak": "3072/1",
      "first_receiver_interval": [
        "1/2",
        "2049/4096"
      ],
      "full_leaf_volume": {
        "expression": "(16n)^n",
        "fraction_sha256": "a14e25017a035df8467002a8ba54f881fd7e7fe9618e9b57477ae27b99daf426",
        "log10_bracket": [
          4315,
          4316
        ]
      },
      "hot_intervals": [
        [
          "1/4096",
          "3/4096"
        ],
        [
          "17/4096",
          "19/4096"
        ]
      ],
      "initial_point_cap_mass": {
        "expression": "sqrt_n*occupied source volume",
        "fraction_sha256": "45114f1c4f7204a27f36fd653951cd23c5607987666d29c7a905037175f32cb0",
        "log10_bracket": [
          4309,
          4310
        ]
      },
      "input_mu_mass": {
        "expression": "A_mu*transverse volume",
        "fraction_sha256": "55c60f9b6033ab32dc4eee7aba9082b4d86997e19936606a60570a6a00bf9de8",
        "log10_bracket": [
          4311,
          4312
        ]
      },
      "leaf_left": "0/1",
      "leaf_side": 16384,
      "n": 1024,
      "new_epsilon_X": {
        "expression": "|E|/100",
        "fraction_sha256": "1efe712c26f1f3347599fa0ae554b1e7fbdaae2b3b7584e2b0f37196e4d759ce",
        "log10_bracket": [
          4305,
          4306
        ]
      },
      "occupied_source_volume": {
        "expression": "total hot length * transverse volume",
        "fraction_sha256": "bc6d9acbc90ab807d44786a2e6296a7ab172ba4b22abd7da0007f757e76ff8c8",
        "log10_bracket": [
          4308,
          4309
        ]
      },
      "receiver_volume": {
        "expression": "first receiver length*(16n-1)^(n-1)",
        "fraction_sha256": "f676cb719c3468ae1aad350b63aa5b28c21874c848137a032c01ab072bb62ced",
        "log10_bracket": [
          4307,
          4308
        ]
      },
      "residual_peak": "3040/1",
      "runningmax_actual_extracted_traffic": {
        "expression": "runningmax reduced extraction*receiver volume",
        "fraction_sha256": "769f635262877c17901869dafbe423c702c4e77246f458567b54217f3a1a192f",
        "log10_bracket": [
          4305,
          4306
        ]
      },
      "runningmax_actual_residual_traffic": {
        "expression": "remaining reduced source*receiver volume",
        "fraction_sha256": "1be4a64978f330e58c61c063b55f4b90be46c8ceae9f1aea6efbf6657e1e08c9",
        "log10_bracket": [
          4308,
          4309
        ]
      },
      "runningmax_final_extracted_mass": {
        "expression": "runningmax reduced extraction*transverse volume",
        "fraction_sha256": "77f1fb247fc88c88c57d730524f104e676c3b846f25f72e53253c4e18299664a",
        "log10_bracket": [
          4309,
          4310
        ]
      },
      "runningmax_final_residual_mass": {
        "expression": "remaining reduced source*transverse volume",
        "fraction_sha256": "11546c29be5f80b8b12c6a0e47ca1551bb80bd8bd8c15f1b04cce041591ab9dd",
        "log10_bracket": [
          4311,
          4312
        ]
      },
      "scales": [
        {
          "F_nm": {
            "expression": "(1+2(m+1)/n)^n",
            "fraction_sha256": "0a032d04f6e735b54d797e83d898d8b4727631004271b3b759bc06b52dadced8",
            "log10_bracket": [
              0,
              1
            ]
          },
          "canonical_residual_cut_nodes": [
            1,
            2,
            3,
            4,
            5
          ],
          "cut_defect_reduced": {
            "decimal_interval": [
              "2.963867187500000000",
              "2.963867187500000000"
            ],
            "exact_fraction": "3035/1024",
            "expression": "reduced exact cut defect",
            "fraction_sha256": "195cf71672be96c9c78a463e041bf34868da87eba6944a08d3b9dbd67e716019",
            "log10_bracket": [
              0,
              1
            ]
          },
          "cut_neighbor_full_volume": {
            "expression": "neighbor first length * transverse volume",
            "fraction_sha256": "0854202b7d610ce69621cb93f53d8eb31671bde30f601a1c2866ee598a23e6d4",
            "log10_bracket": [
              4308,
              4309
            ]
          },
          "expanded_receiver_full_side": "513/512",
          "increment_actual_dx_traffic": {
            "expression": "reduced increment * receiver volume",
            "fraction_sha256": "bc7c4a466b24a5c802c1b932a607fa0d09cc0afbfb3cb843d82979b1dd658dee",
            "log10_bracket": [
              4305,
              4306
            ]
          },
          "increment_delta": [
            "1/608",
            "1/608"
          ],
          "increment_internal_flow_reduced": [
            "5/2048",
            "5/2048"
          ],
          "increment_physical_mass": {
            "expression": "reduced increment * transverse volume",
            "fraction_sha256": "5a8cbfc397ba1834487bf93ad2f1578d153e3768aa20f9fb441bf9d6fdfde1cf",
            "log10_bracket": [
              4309,
              4310
            ]
          },
          "integer_scale": 2048,
          "m": 0,
          "maxflow_reduced": {
            "decimal_interval": [
              "0.004882812500000000",
              "0.004882812500000000"
            ],
            "exact_fraction": "5/1024",
            "expression": "reduced maxflow",
            "fraction_sha256": "fc49def024ce8d3a08303465fc72db4f0f56d3a1cd5fb8fd904c31b8dc0c0661",
            "log10_bracket": [
              -3,
              -2
            ]
          },
          "optimal_integer_edge_flow": [
            5,
            5,
            5,
            5,
            5,
            5
          ],
          "runningmax_extracted_reduced": {
            "decimal_interval": [
              "0.004882812500000000",
              "0.004882812500000000"
            ],
            "exact_fraction": "5/1024",
            "expression": "sum_i a_i max_{j<=scale}theta_i^j",
            "fraction_sha256": "fc49def024ce8d3a08303465fc72db4f0f56d3a1cd5fb8fd904c31b8dc0c0661",
            "log10_bracket": [
              -3,
              -2
            ]
          },
          "runningmax_q": [
            "1/608",
            "1/608"
          ],
          "source_fraction_theta": [
            "1/608",
            "1/608"
          ],
          "target_indices": [
            0,
            4
          ],
          "tau": "5/2"
        },
        {
          "F_nm": {
            "expression": "(1+2(m+1)/n)^n",
            "fraction_sha256": "b344cb8fc66ec6097a3018d3a0af5368edb46153a25e3cf169f265ba94b889a3",
            "log10_bracket": [
              1,
              2
            ]
          },
          "canonical_residual_cut_nodes": [
            1,
            2,
            3,
            4,
            5,
            6,
            7,
            8
          ],
          "cut_defect_reduced": {
            "decimal_interval": [
              "2.963867187500000000",
              "2.963867187500000000"
            ],
            "exact_fraction": "3035/1024",
            "expression": "reduced exact cut defect",
            "fraction_sha256": "195cf71672be96c9c78a463e041bf34868da87eba6944a08d3b9dbd67e716019",
            "log10_bracket": [
              0,
              1
            ]
          },
          "cut_neighbor_full_volume": {
            "expression": "neighbor first length * transverse volume",
            "fraction_sha256": "5a8cbfc397ba1834487bf93ad2f1578d153e3768aa20f9fb441bf9d6fdfde1cf",
            "log10_bracket": [
              4309,
              4310
            ]
          },
          "expanded_receiver_full_side": "257/256",
          "increment_actual_dx_traffic": {
            "expression": "reduced increment * receiver volume",
            "fraction_sha256": "6c28a4ccdb8755503ffa974b980c1dbc731e758304707acacfea80efa49f5271",
            "log10_bracket": [
              4304,
              4305
            ]
          },
          "increment_delta": [
            "0/1",
            "1/3040"
          ],
          "increment_internal_flow_reduced": [
            "0/1",
            "0/1",
            "1/6144",
            "1/6144",
            "1/6144"
          ],
          "increment_physical_mass": {
            "expression": "reduced increment * transverse volume",
            "fraction_sha256": "c786dffbf2e03d3acd92854e3d79d14843aaf63df8a34a0e226adfebfce98614",
            "log10_bracket": [
              4308,
              4309
            ]
          },
          "integer_scale": 2048,
          "m": 1,
          "maxflow_reduced": {
            "decimal_interval": [
              "0.004882812500000000",
              "0.004882812500000000"
            ],
            "exact_fraction": "5/1024",
            "expression": "reduced maxflow",
            "fraction_sha256": "fc49def024ce8d3a08303465fc72db4f0f56d3a1cd5fb8fd904c31b8dc0c0661",
            "log10_bracket": [
              -3,
              -2
            ]
          },
          "optimal_integer_edge_flow": [
            4,
            6,
            2,
            2,
            2,
            2,
            2,
            2,
            2,
            2,
            2,
            2
          ],
          "runningmax_extracted_reduced": {
            "decimal_interval": [
              "0.005371093750000000",
              "0.005371093750000000"
            ],
            "exact_fraction": "11/2048",
            "expression": "sum_i a_i max_{j<=scale}theta_i^j",
            "fraction_sha256": "7c82f6390d3f6bd8e6af66c1daef6e62be35cd908e405f7efa5472546534ba96",
            "log10_bracket": [
              -3,
              -2
            ]
          },
          "runningmax_q": [
            "1/608",
            "3/1520"
          ],
          "source_fraction_theta": [
            "1/760",
            "3/1520"
          ],
          "target_indices": [
            0,
            1,
            3,
            4,
            5
          ],
          "tau": "1/1"
        },
        {
          "F_nm": {
            "expression": "(1+2(m+1)/n)^n",
            "fraction_sha256": "db799c67987d5ec6051b7f7761cc2b6a5d9f31e23c8f0729805da4c009f394ea",
            "log10_bracket": [
              2,
              3
            ]
          },
          "canonical_residual_cut_nodes": [
            1,
            2,
            3,
            4,
            5,
            6,
            7,
            8,
            9,
            10
          ],
          "cut_defect_reduced": {
            "decimal_interval": [
              "2.961914062500000000",
              "2.961914062500000000"
            ],
            "exact_fraction": "3033/1024",
            "expression": "reduced exact cut defect",
            "fraction_sha256": "bcfc7a585bb550ecc50025d2ece1e709adf105b1b38861f9b0a8e549b053292b",
            "log10_bracket": [
              0,
              1
            ]
          },
          "cut_neighbor_full_volume": {
            "expression": "neighbor first length * transverse volume",
            "fraction_sha256": "77f1fb247fc88c88c57d730524f104e676c3b846f25f72e53253c4e18299664a",
            "log10_bracket": [
              4309,
              4310
            ]
          },
          "expanded_receiver_full_side": "515/512",
          "increment_actual_dx_traffic": {
            "expression": "reduced increment * receiver volume",
            "fraction_sha256": "58b7ff9083b0023670c7f1e1413bec6475b66e727a688a34e32f1e67b10de77e",
            "log10_bracket": [
              4304,
              4305
            ]
          },
          "increment_delta": [
            "1/3040",
            "1/1520"
          ],
          "increment_internal_flow_reduced": [
            "1/6144",
            "1/6144",
            "1/6144",
            "0/1",
            "1/4096",
            "1/4096",
            "1/4096",
            "1/4096"
          ],
          "increment_physical_mass": {
            "expression": "reduced increment * transverse volume",
            "fraction_sha256": "71fd06d0c0a5b82e7416bdc92bdae3871de83f3dd7f70a0709e8201eda651773",
            "log10_bracket": [
              4308,
              4309
            ]
          },
          "integer_scale": 2048,
          "m": 2,
          "maxflow_reduced": {
            "decimal_interval": [
              "0.006835937500000000",
              "0.006835937500000000"
            ],
            "exact_fraction": "7/1024",
            "expression": "reduced maxflow",
            "fraction_sha256": "95e188922d2d84834a9a0147eca2d9ccbd4b345d1fb43e9bd7c30152872d6eeb",
            "log10_bracket": [
              -3,
              -2
            ]
          },
          "optimal_integer_edge_flow": [
            6,
            8,
            2,
            2,
            2,
            0,
            2,
            2,
            2,
            2,
            2,
            2,
            2,
            2,
            2,
            2,
            2
          ],
          "runningmax_extracted_reduced": {
            "decimal_interval": [
              "0.006835937500000000",
              "0.006835937500000000"
            ],
            "exact_fraction": "7/1024",
            "expression": "sum_i a_i max_{j<=scale}theta_i^j",
            "fraction_sha256": "95e188922d2d84834a9a0147eca2d9ccbd4b345d1fb43e9bd7c30152872d6eeb",
            "log10_bracket": [
              -3,
              -2
            ]
          },
          "runningmax_q": [
            "3/1520",
            "1/380"
          ],
          "source_fraction_theta": [
            "3/1520",
            "1/380"
          ],
          "target_indices": [
            0,
            1,
            2,
            3,
            4,
            5,
            6
          ],
          "tau": "1/1"
        }
      ],
      "source_indices": [
        0,
        4
      ],
      "source_payment_coefficient_divided_by_C2_squared": {
        "expression": "25*sum F_nm^2*tau",
        "fraction_sha256": "cd9521bf6a41eadd56ab184e1045351925c53de0bd88446908717a0f5ff9f7d5",
        "log10_bracket": [
          6,
          7
        ]
      },
      "stage": "stage3",
      "transverse_interval": [
        "0/1",
        "16384/1"
      ],
      "transverse_repetition": 1023,
      "transverse_volume": {
        "expression": "(16n)^(n-1)",
        "fraction_sha256": "606f104cf3fbfc5a8c4b0bebf325eec16712698a2564faceb5806b9808ca4c92",
        "log10_bracket": [
          4311,
          4312
        ]
      },
      "unpaid_residual_kept_with_coefficient_one": true
    }
  ],
  "status": "PASS"
}
````
<!-- REPRO-FILE-END -->
