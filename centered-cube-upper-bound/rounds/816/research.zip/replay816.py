"""Replay the three finite checks without changing the archived interval certificate."""
from hashlib import sha256
import json
from pathlib import Path
import shutil
import subprocess
import sys
from tempfile import TemporaryDirectory

import flint
from flint import arb, ctx

ROOT = Path(__file__).resolve().parent
SCRIPTS = ("rank816.py", "geometry816.py", "transport816.py")


def main():
    print("Python", sys.version.split()[0], "at", sys.executable, flush=True)
    print("python-flint", flint.__version__, "FLINT", flint.__FLINT_VERSION__, flush=True)
    with TemporaryDirectory(prefix="replay-", dir=ROOT) as work_dir:
        work = Path(work_dir)
        for filename in SCRIPTS:
            shutil.copyfile(ROOT / filename, work / filename)
            subprocess.run([sys.executable, "-B", str(work / filename)], cwd=work, check=True)

        archived = (ROOT / "transport816.json").read_bytes()
        reproduced = (work / "transport816.json").read_bytes()
        reference = json.loads(archived)
        actual = json.loads(reproduced)
        assert actual["dimensions"] == reference["dimensions"] == [16, 32, 64, 128, 256, 512]
        ctx.prec = 384
        for expected, obtained in zip(reference["results"], actual["results"], strict=True):
            for key in ("n", "event_count", "first_feasible_j", "nonempty_subset_union_over_mu_lower"):
                assert obtained[key] == expected[key], (obtained["n"], key)
            for key in ("coverage_fraction", "hard_lower", "hard_union_upper"):
                assert arb(obtained[key]["ball"]).overlaps(arb(expected[key]["ball"])), (obtained["n"], key)
        print("Archived certificate SHA-256", sha256(archived).hexdigest())
        print("Reproduced certificate SHA-256", sha256(reproduced).hexdigest())
        print("All six dimensions have compatible interval certificates.")


if __name__ == "__main__":
    main()
