"""Arb certificates for the symmetric atomic source configuration.

The source cube has side length r, D dilates its side length, and a is the
witness scale. Returned balls enclose all rounding error; the JSON schema is
kept stable for comparison with the original computation.
"""

from flint import arb, ctx
import flint
import json
import math
import pathlib

NS = (16, 32, 64, 128, 256, 512)


def rep(x):
    # Arb's midpoint +/- radius printed with guaranteed error enclosure.
    return {
        "ball": x.str(45),
        "internal_abs_radius": x.rad().str(8),
        "internal_relative_radius_bound": (
            (x.rad() / abs(x)).str(8) if not x.contains(0) else None
        ),
    }


def calc(n, bits):
    ctx.prec = bits
    one = arb(1)
    two = arb(2)
    h = one / (8 * arb(n).sqrt())
    H = one / h
    r = (H.log() / n).exp() / 2
    D = (two.log() / n).exp()
    a = ((2 * arb(n).sqrt()).log() / n).exp()
    ratio = ((a + r - arb(3) / 4) / (2 * r)) ** n
    # Maximal root 1 on |x|_inf<=1/32: all atoms at distance <=13/32.
    # Exterior to Omega_D if Dr<11/16. D r<3/4 also gives pairwise disjoint inflated cubes.
    exterior = arb(11) / 16 - D * r
    source_separation = arb(3) / 4 - r
    inflated_separation = arb(3) / 4 - D * r
    overlap_low = a + r - arb(3) / 4
    overlap_high = arb(3) / 4 + r - a
    assert exterior > 0
    assert source_separation > 0
    assert inflated_separation > 0
    assert overlap_low > 0
    assert overlap_high > 0
    # In E_n=(-1/8,1/8)^n, subtract the pairwise-disjoint intersections
    # with Omega_D.  Each 1D intersection has length Dr/2 - 1/4.
    assert D * r > arb(1) / 2
    lower = (arb(1) / 4) ** n - (D * r - arb(1) / 2) ** n
    assert lower > 0
    # Exact event j: root t_j = 2^(j/n-1), j two-valued coordinates.
    # For t_j>3/4: |x_i|<U=t_j/2+3/8, and >=j coordinates
    # |x_i|<L=t_j/2-3/8.  Its entire-space volume is the binomial sum below.
    # j=0 event is inside Omega_D, and 1<=j<n with t_j<=3/4 are empty.
    upper = arb(0)
    terms = []
    for j in range(1, n + 1):
        t = (two.log() * arb(j) / n).exp() / 2
        if t <= arb(3) / 4:
            continue
        if not t > arb(3) / 4:
            raise RuntimeError("undetermined feasibility")
        x = t - arb(3) / 4
        y = arb(3) / 2
        vol = sum(
            (arb(math.comb(n, k)) * x**k * y ** (n - k) for k in range(j, n + 1)),
            arb(0),
        )
        terms.append((j, vol))
        upper += vol
    assert upper >= lower
    return {
        "n": n,
        "precision_bits": bits,
        "H": rep(H),
        "h": rep(h),
        "D": rep(D),
        "a": rep(a),
        "r": rep(r),
        "coverage_fraction": rep(ratio),
        "Omega_exterior_margin_11over16_minus_Dr": rep(exterior),
        "source_cube_disjoint_margin": rep(source_separation),
        "inflated_cube_disjoint_margin": rep(inflated_separation),
        "coverage_overlap_margins": [rep(overlap_low), rep(overlap_high)],
        "nonempty_subset_union_over_mu_lower": str(7**n) + "/" + str(4**n),
        "requested_lower": str(3**n) + "/" + str(2**n),
        "hard_lower": rep(lower),
        "hard_union_upper": rep(upper),
        "first_feasible_j": terms[0][0],
        "event_count": len(terms),
        "single_event_max": rep(
            max((x for _, x in terms), key=lambda x: float(x.mid()))
        ),
        "_vals": (ratio, lower, upper),
    }


results = []
for n in NS:
    lo = calc(n, 256)
    hi = calc(n, 384)
    assert all(a.overlaps(b) for a, b in zip(lo.pop("_vals"), hi["_vals"]))
    hi.pop("_vals")
    hi["precision_crosscheck"] = (
        "256-bit and 384-bit enclosures overlap for coverage and both bounds"
    )
    results.append(hi)
    print(
        "n",
        n,
        "coverage",
        hi["coverage_fraction"]["ball"],
        "hard lower",
        hi["hard_lower"]["ball"],
        "upper",
        hi["hard_union_upper"]["ball"],
        "j_min",
        hi["first_feasible_j"],
    )
out = {
    "error_note": "The printed ball includes decimal serialization error; internal radii describe the 384-bit ball before decimal printing.",
    "algorithm": "python-flint Arb rigorous interval balls; integer binomial exact; 384-bit primary and 256-bit cross-check",
    "python_flint_version": flint.__version__,
    "flint_version": flint.__FLINT_VERSION__,
    "dimensions": list(NS),
    "three_batches": [
        "geometry and source disjointness",
        "origin coverage fraction and overlap inequalities",
        "whole-space unpaid receiver bounds via exact root-event binomial union",
    ],
    "proof_scope": "For n listed only. Source mass 2^-n, lambda=1. Q side lengths. E_hard={M mu>1} minus Omega_D. Lower = |(-1/8,1/8)^n minus Omega_D|, upper is sum of multi-source root event volumes. E0 subset Omega_D. Bounds include root j=n; no claim that upper events are disjoint.",
    "subset_proof": "For each source p in A, Q1(p) includes an orthant box of side 7/8. These 2^n orthant boxes are disjoint; |union Q1(p)| >= |A|(7/8)^n = (7/4)^n mu(A).",
    "origin_proof": "On |x|_inf<=1/32 all atoms in Q1(x) with strict margin; for t>1 total mass < t^n, so the largest physical threshold root equals 1; exterior margin certifies distance from Omega_D.",
    "results": results,
}
pathlib.Path(__file__).with_suffix(".json").write_text(json.dumps(out, indent=2) + "\n")
