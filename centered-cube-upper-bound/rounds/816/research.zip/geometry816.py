"""Finite exact checks of the correctly quantified one-axis cube rule.

All coordinates, side lengths and frozen heights are rational. Each tested
axis witnesses one prescribed unique opposite box k. This is a finite test,
not a proof of the rule or of its high-dimensional concentration estimate.
"""

from fractions import Fraction as F
from itertools import product


def interval(t, u):
    # p=0, y=t*(u-1/2), so the true centered interval has these endpoints.
    return (t * (u - 1), t * u)


def length(boxes):
    return max(F(0), min(b for a, b in boxes) - max(a for a, b in boxes))


triple_checks = 0
pair_checks = 0
invalid_normalizations = 0
for R in (2, 4, 8, 16):
    rare = F(1, 8 * R)
    assert 2 * rare * F(1, 8) ** 2 == F(1, 256 * R)
    source_values = [F(0), rare / 2, rare]
    other_values = [F(7, 8), F(15, 16), F(1)]
    for sides in product((F(1), F(R)), repeat=3):
        for top_choices in product((0, 1), repeat=3):
            heights = tuple(F(R) if c else t for c, t in zip(top_choices, sides))
            for unique in range(3):
                for reflected in (False, True):
                    for values in product(source_values, other_values, other_values):
                        V = []
                        j = 1
                        for i in range(3):
                            if i == unique:
                                v = values[0]
                            else:
                                v = values[j]
                                j += 1
                            V.append(1 - v if reflected else v)
                        # V = 1/2 + (t/h)*(u-1/2).
                        u = tuple(
                            F(1, 2) + h * (v - F(1, 2)) / t
                            for v, h, t in zip(V, heights, sides)
                        )
                        if any(x < 0 or x > 1 for x in u):
                            invalid_normalizations += 1
                            continue
                        boxes = tuple(interval(t, x) for t, x in zip(sides, u))
                        rest = [boxes[i] for i in range(3) if i != unique]
                        assert 2 * length(boxes) <= length(rest)
                        triple_checks += 1
                        for other in range(3):
                            if other == unique or sides[unique] < sides[other]:
                                continue
                            assert (
                                2 * length((boxes[unique], boxes[other]))
                                <= sides[other]
                            )
                            pair_checks += 1

# Guard against the incorrect quantifier: this single axis witnesses only k=0.
# The duplicate nonunique box adds no further shrinkage to the other pair.
guard = [interval(F(1), u) for u in (F(0), F(7, 8), F(7, 8))]
assert length(guard) == length((guard[0], guard[1])) == F(1, 8)
assert 2 * length(guard) > length((guard[0], guard[1]))

# Also record an example outside either specified extreme-pattern condition.
outside = [interval(F(1), F(1, 2))] * 3
assert length(outside) == length(outside[:2]) == 1

hole_dimensions = (128, 256, 512, 4096, 2**18)
for n in hole_dimensions:
    # 99n/250 > 4*sqrt(n)+4 iff 99n-1000 > 1000*sqrt(n).
    residual = 99 * n - 1000
    assert residual > 0
    assert residual**2 > 1000**2 * n
n = 2**18
assert n % 4096 == 0
assert 648 * n**2 < 2 ** (n // 4096)

print("R = 2,4,8,16; sides = {1,R}; frozen heights = {t,R};")
print(
    "unique-opposite boxes = 3; both common reflections; three points per threshold interval"
)
print(
    "valid triple checks:",
    triple_checks,
    "pair checks:",
    pair_checks,
    "excluded nonphysical normalizations:",
    invalid_normalizations,
)
print("positive-L1 hole dimensions:", *hole_dimensions)
print("n=2^18: 648*n^2*2^(-n/4096) =", F(648 * n**2, 2 ** (n // 4096)))
print(
    "PASS; finite verification only; incorrect-quantifier and outside-pattern guards included"
)
