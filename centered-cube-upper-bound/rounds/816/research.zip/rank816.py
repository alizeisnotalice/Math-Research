"""Exact two-sided rank coupling on discrete receiver rows.

Each source label supplies rows (physical_id, witness_log_price, row_rank_mass).
The row mass is its rank interval length; source weight scales its contribution
when capacities are aggregated. Equal prices use physical_id as a tie-breaker.
The central rank is restricted by rank_cutoff = Lcut at both ends.
"""

from fractions import Fraction as F
from collections import defaultdict


def overlap(a, b, c, d):
    return max(F(0), min(b, d) - max(a, c))


def evaluate(T, groups):
    window_width = F(T)
    minimum_gap = F(T + 2)
    rank_cutoff = F(2 * T + 2)
    total_source_weight = sum(q["weight"] for q in groups)
    capacities = defaultdict(F)
    totals = [defaultdict(F) for _ in range(3)]
    discarded = F(0)
    triple_mass = F(0)
    segments = 0
    nonzero = 0
    for g in groups:
        source_weight = g["weight"]
        rows = sorted(g["rows"], key=lambda r: (r[1], r[0]))
        bounds = []
        rank_length = F(0)
        for name, witness_log_price, row_rank_mass in rows:
            assert row_rank_mass > 0
            assert source_weight > 0
            bounds.append((rank_length, rank_length + row_rank_mass))
            rank_length += row_rank_mass
            capacities[name] += source_weight * row_rank_mass
        z0 = rank_cutoff
        z1 = rank_length - rank_cutoff
        active = max(F(0), z1 - z0)
        discarded += source_weight * (rank_length - active)
        M = len(rows)
        side = [defaultdict(F), defaultdict(F)]
        center = defaultdict(F)
        pair = defaultdict(F)
        pure_center = defaultdict(F)
        local_total = F(0)
        for c, (ca, cb) in enumerate(bounds):
            begin = max(z0, ca)
            end = min(z1, cb)
            if begin >= end:
                continue
            cuts = {begin, end}
            for a, b in bounds:
                for v in (
                    a + minimum_gap,
                    a + rank_cutoff,
                    b + minimum_gap,
                    b + rank_cutoff,
                    a - minimum_gap,
                    a - rank_cutoff,
                    b - minimum_gap,
                    b - rank_cutoff,
                ):
                    if begin < v < end:
                        cuts.add(v)
            cuts = sorted(cuts)
            for u, v in zip(cuts, cuts[1:]):
                segments += 1
                du = v - u

                def lengths(t):
                    return (
                        [
                            overlap(a, b, t - rank_cutoff, t - minimum_gap)
                            / window_width
                            for a, b in bounds
                        ],
                        [
                            overlap(a, b, t + minimum_gap, t + rank_cutoff)
                            / window_width
                            for a, b in bounds
                        ],
                    )

                left0, right0 = lengths(u)
                left1, right1 = lengths(v)
                # Both full windows lie in [0,L] throughout the active domain.
                assert sum(left0) == 1
                assert sum(left1) == 1
                assert sum(right0) == 1
                assert sum(right1) == 1
                pure_center[c] += du
                for i in range(M):
                    side[0][i] += du * (left0[i] + left1[i]) / 2
                    side[1][i] += du * (right0[i] + right1[i]) / 2
                for i in range(M):
                    if left0[i] == 0 and left1[i] == 0:
                        continue
                    for j in range(M):
                        if right0[j] == 0 and right1[j] == 0:
                            continue
                        # Exact integral of product of two affine functions.
                        integral = (
                            du
                            * (
                                2 * left0[i] * right0[j]
                                + left0[i] * right1[j]
                                + left1[i] * right0[j]
                                + 2 * left1[i] * right1[j]
                            )
                            / 6
                        )
                        assert integral >= 0
                        pair[i, j] += integral
                        center[c] += integral
                        local_total += integral
                        nonzero += bool(integral)
        assert local_total == active
        assert (
            sum(center.values())
            == sum(side[0].values())
            == sum(side[1].values())
            == active
        )
        for i, (name, witness_log_price, row_rank_mass) in enumerate(rows):
            assert center[i] == pure_center[i]
            assert center[i] <= row_rank_mass
            assert side[0][i] <= row_rank_mass
            assert side[1][i] <= row_rank_mass
            totals[0][name] += source_weight * center[i]
            totals[1][name] += source_weight * side[0][i]
            totals[2][name] += source_weight * side[1][i]
        for (i, j), value in pair.items():
            assert value <= rows[i][2] * rows[j][2] / window_width
        triple_mass += source_weight * local_total
    for side in totals:
        for name, amount in side.items():
            assert amount <= capacities[name]
    assert discarded <= 2 * rank_cutoff * total_source_weight
    assert triple_mass + discarded == sum(
        g["weight"] * sum(r[2] for r in g["rows"]) for g in groups
    )
    print(
        "T",
        T,
        "groups",
        len(groups),
        "rows",
        sum(len(g["rows"]) for g in groups),
        "physical_rows",
        len(capacities),
        "segments",
        segments,
        "pair_pieces",
        nonzero,
        "triple",
        triple_mass,
        "discarded",
        discarded,
        "discard_cap",
        2 * rank_cutoff * total_source_weight,
    )


def make(q, rows):
    return {
        "weight": F(q),
        "rows": [
            (name, witness_log_price, F(row_rank_mass))
            for name, witness_log_price, row_rank_mass in rows
        ],
    }


# Batch 1: three labels; P1 and P3 are physical rows shared across labels.
first = [
    make("1", [("P0", 0, 4), ("P1", 1, 5), ("P2", 2, 6), ("P3", 3, 7)]),
    make("2/3", [("P1", 0, 3), ("P4", 0, 4), ("P3", 1, 5), ("P5", 2, 6)]),
    make("1/4", [("P6", 0, 2), ("P7", 1, 3)]),
]
# Batch 2: a large equal-price atom split across physical rows; rational pieces.
ties = [
    make(
        "3/5",
        [
            (f"P{i}", 0, row_rank_mass)
            for i, row_rank_mass in enumerate(
                ["3/2", "7/3", "17/6", "9/2", "13/3", "11/2", "19/3", "23/6"]
            )
        ],
    ),
    make(
        "5/4",
        [
            (f"P{i}", 0, row_rank_mass)
            for i, row_rank_mass in enumerate(
                ["5/2", "8/3", "13/6", "7/2", "17/3", "11/2", "25/6", "31/6"]
            )
        ],
    ),
]
# Batch 3: expanded size, distinct and tied prices, shared rows, fractional lengths.
large = []
for k in range(5):
    entries = []
    for j in range(10):
        entries.append(
            (f"P{(j+2*k)%13}", (j // 3) % 4, F(2 + (j + k) % 4) + F((j + 2 * k) % 3, 3))
        )
    large.append(make(F(k + 2, k + 3), entries))
for T in (1, 2):
    for groups in (first, ties, large):
        evaluate(T, groups)
print(
    "PASS: exact rational interval integration; all assertions passed; no geometric input is claimed."
)
