from fractions import Fraction as F
from pathlib import Path
import json
ins=json.loads(Path(__file__).with_name('r371_lp_input.json').read_text())['cases']
outs=json.loads(Path(__file__).with_name('r371_lp_output.json').read_text())['cases']
rows=balance=push=energy=0
for data,out in zip(ins[-2:],outs[-2:]):
 A=data['A'][:-1];m=list(map(F,data['b_exact'][:-1]))
 w=[F(z['quadrature']) for z in data['receivers']]
 V=[F(z['R']) for z in data['receivers']]
 cells=[(F(a),F(b)) for a,b in data['source_cells']]
 vol=[b-a for a,b in cells]
 x=[F(str(v)).limit_denominator(10**9) for v in out['x']]
 assert all(sum(F(a)*v for a,v in zip(row,x))==mi for row,mi in zip(A,m))
 rho=[sum(w[u]*A[u][i]/m[u] for u in range(len(m))) for i in range(len(x))]
 kap=[sum(w[u]*A[u][i]*V[u]/m[u]**2 for u in range(len(m))) for i in range(len(x))]
 ids=[i for i in range(len(x)) if rho[i]]
 P={(i,j):sum(w[u]*A[u][i]*A[u][j]*x[j]/m[u]**2 for u in range(len(m)))/rho[i] for i in ids for j in ids}
 nu={i:rho[i]*x[i] for i in ids};zeta={i:rho[i]*vol[i] for i in ids}
 for i in ids:
  assert sum(P[i,j] for j in ids)==1;rows+=1
  for j in ids:
   assert nu[i]*P[i,j]==nu[j]*P[j,i];balance+=1
 for j in ids:
  assert sum(nu[i]*P[i,j] for i in ids)==nu[j]
  assert sum(zeta[i]*P[i,j] for i in ids)==x[j]*kap[j]
  assert kap[j]==rho[j]  # all q=1 in these two actual finite fixtures
  push+=1
 assert sum(nu.values())==sum(w)
 for pattern in range(5):
  phi=[F((i*(pattern+1)+3)%11,7) for i in range(len(x))]
  lhs=sum(nu[i]*P[i,j]*(phi[i]-phi[j])**2 for i in ids for j in ids)/2
  rhs=F(0)
  for u in range(len(m)):
   mean=sum(F(A[u][i])*x[i]*phi[i] for i in range(len(x)))/m[u]
   second=sum(F(A[u][i])*x[i]*phi[i]**2 for i in range(len(x)))/m[u]
   rhs+=w[u]*(second-mean**2)
  assert lhs==rhs;energy+=1
 print(data['name'],'rho_cells',len(ids),'uniform_reference_norm',max(x[i]*kap[i]/zeta[i] for i in ids))
radial=0
for n in range(1,6):
 for R in [F(1),F(3,2)]:
  lam=F(7,5);m=lam*R**n
  for pat in range(1,8):
   H=F(pat,3)
   ts=[R*(1+F(j,8)) for j in range(1,5)]
   beta=[F((j*pat)%5,9) for j in range(1,5)]
   alpha=H-sum(beta)
   cost=alpha*m+sum(b*lam*t**n for b,t in zip(beta,ts))
   excess=sum(b*lam*(t**n-R**n) for b,t in zip(beta,ts))
   assert alpha+sum(beta)==H
   assert cost==m*H+excess>=m*H
   radial+=1
print('PASS',dict(markov_rows=rows,detailed_balance=balance,pushforward=push,dirichlet=energy,radial_prices=radial))
