# R373: one common surplus coupling can strictly improve independent-p payment

## Exact conclusion and the common-coupling identity

Three exact finite diagnostics below use actual piecewise-constant L1 sources, real intervals/squares, and positive-volume source and target cells. Each uses ONE coupling for all big cubes simultaneously. All three strictly lower the remaining cost relative to the product coupling which gives the R371 independent overlap fractions. The second example forces a real compromise: the common optimizer worsens one big-cube component, while improving their weighted sum. Independent per-cube optimizers are incompatible there.

This verifies the coupling mechanism only. These examples do not realize the original high-dimensional hard field, its diagonal J, strict past, physical scale atoms, or all historical gates. They do not prove a general fee or coverage fraction. In particular, the finite objective called the original diagonal functional below is the exact frozen common-coupling interface, not a claim to have evaluated the original full hard G.

Let Q_v have volume one and let f=2 on a half-volume rectangle F⊂Q_v, zero elsewhere. This is an actual finite L1 input. Its actual q_v=m_v=1, and

    μ_+=(f−q_v)_+dy/m_v=1_F dy,    d=μ_+(Q_v)=1/2,
    U_v=1_{Q_v}dz,                dU_v=(1/2)1_{Q_v}dz.

For the specified real big cubes Q_k, nonnegative weights a_k, and marks 0≤ω_k(y)≤1, fix the t=0 cost

    c(y,z)=Σ_k a_k ω_k(y)1_{Q_k}(y)1_{z∉Q_k}.

No enlargement of Q_k is used. For every ONE positive coupling τ with first marginal μ_+ and second marginal dU_v, define

    S=∫μ_+(dy) Σ_k a_kω_k(y)1_{Q_k}(y),
    R(τ)=∫c(y,z)dτ(y,z),
    P(τ)=∫Σ_k a_kω_k(y)1_{Q_k}(y)1_{Q_k}(z)dτ(y,z).

The first marginal gives the exact positive identity S=P(τ)+R(τ). The floor

    F_floor=∫[min(f,q_v)/m_v]Σ_k a_kω_k1_{Q_k}dy

is unaffected by τ. Thus the original frozen diagonal value

    G_diag=F_floor+S=F_floor+P(τ)+R(τ)

is unchanged. For the product τ_0=μ_+⊗U_v,

    P(τ_0)=Σ_k p_k a_k∫ω_k1_{Q_k}dμ_+,
    p_k=U_v(Q_k),

which is precisely the independent-p overlap share in this finite interface. A lower R(τ) therefore increases the common paid share P(τ), without changing the source, floor, original captures, or original diagonal value. No signed negative-excess term is reused.

## Continuous feasible couplings from exact cell masses

All source cells Y_i below partition F up to null boundaries, and all target cells Z_j partition Q_v. Let r_i=|Y_i| and s_j=|Z_j|/2. A nonnegative matrix T with row sums r_i and column sums s_j defines an actual absolutely continuous coupling by

    dτ/(dy dz)=T_ij/(|Y_i||Z_j|) on Y_i×Z_j.

Its marginals are exactly μ_+ and dU_v. Thus there are no source or target atoms, no quadrature interpretation, and no approximation error. Our marks and capture indicators are constant almost everywhere on each cell pair, so the complete continuum integrals equal their rational matrix sums. The product matrix is T^0_ij=r_i s_j/d.

For additional verification, every displayed common cost has an elementary finite weak-dual certificate: row potentials A_i and column potentials B_j satisfy A_i+B_j≤c_ij, and Σr_iA_i+Σs_jB_j equals the explicit feasible common cost. Integrating that pointwise inequality proves optimality for this frozen objective. The feasible primal coupling, not the dual alone, supplies the upper bound. This optional optimality assertion does not add a general source-budget theorem.

## Stage 1: two distinct intervals, a strict common improvement

Take Q_v=[0,1], F=[0,1/2], source cells

    Y_1=[0,1/4], Y_2=[1/4,1/2], r=(1/4,1/4),

and target cells Z_1=[0,1/4], Z_2=[1/4,1], with s=(1/8,3/8). Use real big intervals

    Q_1=[−1,1/4], Q_2=[1/4,3/2],

both of length 5/4, weights a=(1,1), and marks ω_1=ω_2=1 on F. Their actual full-source averages are q_1=q_2=2/5; no original q-band for those big cubes is asserted. Their marked surplus captures are (1/4,1/4) and uniform target captures are p=(1/4,3/4).

The full cost matrix and ONE common coupling are

    c=[[0,1],[1,0]],
    T=[[1/8,1/8],[0,1/4]].

The product cost is 1/4, while R(T)=1/8. Dual potentials A=(1,0), B=(−1,0) certify the latter. The unchanged floor is 1/2, S=1/2, and G_diag=1. Consequently the paid surplus grows from 1/4 to 3/8 and the remainder falls from 1/4 to 1/8.

## Stage 2: incompatible per-cube optima and a genuine shared compromise

Keep Q_v,F,Y_1,Y_2, but use target cells Z_1=[0,1/2], Z_2=[1/2,1], so s=(1/4,1/4). Take the distinct big intervals

    Q_1=[−1,1/2], Q_2=[−3/4,1/2],

with respective lengths 3/2,5/4 and actual source averages 2/3,4/5. Both capture F and the same left half of Q_v. Set

    a=(2,1), ω_1=1_{Y_1}, ω_2=1_{Y_2}.

Then p_1=p_2=1/2 and each marked surplus capture is 1/4. The cost and common coupling are

    c=[[0,2],[0,1]],
    T=[[1/4,0],[0,1/4]].

The product cost is 3/8; the common cost is 1/4. Potentials A=(1,0), B=(−1,1) prove optimality. More concretely, each big cube considered in isolation could attain zero cost by sending its own marked source quarter into Z_1. These two choices cannot both hold in one coupling: they demand mass 1/2 in a target set of capacity only 1/4.

The displayed common coupling prioritizes the weight-two component. Its two component costs change from (1/4,1/8) under product to (0,1/4) under the common coupling. Thus the second component becomes WORSE. Only the actual weighted sum improves; no pointwise/per-cube dominance is claimed.

Here F_floor=3/4, S=3/4, and G_diag=3/2 remain unchanged. The paid surplus grows from 3/8 to 1/2, and the exact remainder decreases from 3/8 to 1/4. This is the requested pressure test against accidentally using a different coupling for each big cube.

## Stage 3: expanded two-dimensional real cells and three active big squares

Take Q_v=[0,1]^2, F=[0,1]×[0,1/2], f=2·1_F. Use the four source rectangles

    Y_i=[(i−1)/4,i/4]×[0,1/2], i=1,…,4,

of volume 1/8, and eight target rectangles

    Z_(i,j)=[(i−1)/4,i/4]×[j/2,(j+1)/2],
    i=1,…,4, j=0,1,

of volume 1/8. Every target mass s_(i,j) is 1/16. The actual big squares are

    Q_1=[−1,1/2]×[−1/4,5/4],
    Q_2=[1/2,2]×[−1/4,5/4],
    Q_3=[−1/4,5/4]×[−1,1/2],

all of side 3/2, with actual full-source averages (2/9,2/9,4/9). Set a=(3,2,1) and mark values on (Y_1,Y_2,Y_3,Y_4) as

    ω_1=(1,1/2,0,0),
    ω_2=(0,0,1,1/2),
    ω_3=(1,1,1,1).

The marked surplus captures are (3/16,3/16,1/2); all three uniform target capture fractions equal 1/2. One common coupling sends mass 1/16 from each Y_i to each of the two Z_(i,0),Z_(i,1), and zero to the other six target cells. This is an actual density on eight positive-volume product cells, with both marginals exactly satisfied.

This common coupling has zero cost for the left/right square components. Its bottom-square cost is exactly the total target mass in the top half, 1/4. Under product, the component costs are (9/32,3/16,1/4), totaling 23/32. Hence

    R(product)=23/32,  R(common)=1/4,
    strict gain=15/32.

Dual potentials A_i=0 and B_(i,j)=j certify the common cost: the bottom square contributes exactly one on every top target cell, and all other costs are nonnegative. Thus no independent choice of source-specific/cube-specific target marginal is hidden here.

The unchanged floor and surplus diagonal both equal 23/16, with G_diag=23/8. The paid surplus increases from 23/32 to 19/16. Directly,

    23/16+23/32+23/32=23/8,
    23/16+19/16+1/4=23/8.

## Canonical double-centered tilt on the SAME cells

Each of the three cases also uses the prescribed explicit coupling, rather than selecting the optimal coupling above. Let P=μ_+/d, U=U_v and the actual finite reward be

    K(y,z)=Σ_k a_kω_k(y)1_{Q_k}(y)1_{Q_k}(z).

In each example take B=Σ_k a_k, a valid upper bound 0≤K≤B. This B is the finite sum of the displayed weights, not the general hard-field envelope A_n/h or any unproved global price. Write

    D(y,z)=K(y,z)−E_U K(y,Z)−E_P K(Y,z)+E_(P⊗U)K,
    dτ_tilt=d[1+D/(2B)]dP dU.

The script checks zero P/U conditional means of D and both exact marginals of τ_tilt. Nonnegativity follows also from D≥−2B. Since K differs from D by a row function and a column function, their centered cross moment satisfies E(DK)=E(D²). Hence the exact decrease in remainder cost relative to product is

    R(product)−R(τ_tilt)=d E(D²)/(2B)>0.

This is ONE common tilt based on the SUM of all big-cube rewards; no separate tilt is chosen per cube. Its complete integral values are:

| actual-cell case | finite B | E(D²) | exact tilt gain | tilt remainder | certified optimal common remainder |
|---|---:|---:|---:|---:|---:|
| Stage 1 | 2 | 3/16 | 3/128 | 29/128 | 1/8 |
| Stage 2 | 3 | 1/16 | 1/192 | 71/192 | 1/4 |
| Stage 3 | 6 | 251/256 | 251/6144 | 4165/6144 | 1/4 |

Thus the canonical construction itself strictly improves R371's product-p payment on actual positive-volume source/target cells in all three stages. Its gain is smaller than the optimized common-coupling gain, as expected. The floor and G_diag remain exactly unchanged for the tilt as well. The output JSON records the full rational D and tilt matrices, rather than only objective values.

## Execution and interpretation

The self-contained `/tmp/r373_coupling_check.py` computes actual box intersections, all actual q values, positive cell volumes, marked captured masses, uniform capture fractions, both exact marginals, the full cost matrices, product/common costs, and finite primal/dual equality. It also verifies the original diagonal and floor identities, the component worsening in Stage 2, and the full canonical-tilt matrices, marginals, and exact quadratic credits above. The output is `/tmp/r373_coupling.json`.

Two fresh local Python processes each passed 369 exact Fraction assertions: 60 in Stage 1, 62 in Stage 2, and 247 in Stage 3. The resulting objective values are rational exact complete integrals, not float fits. The three-stage task stopped here; no broad example search or new optimization run was used.

The conclusion is strictly limited but positive: a single feasible common surplus coupling can strictly improve the R371 product-p split even under genuine multiple-cube competition. Turning this freedom into a generally priced payment for the original marked hard field remains the main theorem's task. Our examples neither certify that fee nor supply the original high-dimensional gates.
