#!/usr/bin/env python3
"""Exact actual-cell common-surplus couplings; no optimizer or old imports."""
from fractions import Fraction as F
from collections import Counter
import json

count=0; stages=Counter()
def ck(stage,tag,truth):
    global count
    assert truth,tag
    count+=1;stages[stage]+=1

def box(*intervals): return tuple((F(a),F(b)) for a,b in intervals)
def volume(B):
    out=F(1)
    for a,b in B: out*=max(F(0),b-a)
    return out

def intersect(A,B):
    return tuple((max(a,c),min(b,d)) for (a,b),(c,d) in zip(A,B))
def captured(B,C):
    v=volume(intersect(B,C)); w=volume(C)
    assert v in (0,w)
    return int(v==w)

def solve_case(name,Q,Fbox,Y,Z,big,weights,marks,T,dual_a,dual_b):
    st=name
    q=2*volume(intersect(Q,Fbox))/volume(Q)
    m=q*volume(Q)
    d=volume(Fbox)/m
    ck(st,'actual_unit_q_and_mass',q==m==1)
    ck(st,'actual_positive_surplus_mass',d==F(1,2))
    for boxes,label,total in [(Y,'source',volume(Fbox)),(Z,'target',volume(Q))]:
        for C in boxes: ck(st,label+'_positive_volume',volume(C)>0)
        ck(st,label+'_full_cover_volume',sum(map(volume,boxes))==total)
        for i,C in enumerate(boxes):
            ck(st,label+'_contained',volume(intersect(C,Fbox if label=='source' else Q))==volume(C))
            for D in boxes[:i]: ck(st,label+'_disjoint_interiors',volume(intersect(C,D))==0)
    rows=[volume(C)/m for C in Y]
    cols=[d*volume(C)/volume(Q) for C in Z]
    capY=[[captured(B,C) for C in Y] for B in big]
    capZ=[[captured(B,C) for C in Z] for B in big]
    p=[volume(intersect(Q,B))/volume(Q) for B in big]
    actual_q_big=[2*volume(intersect(B,Fbox))/volume(B) for B in big]
    for B in big:
        sides=[b-a for a,b in B]
        ck(st,'actual_big_cube',all(s==sides[0] for s in sides) and sides[0]>1)
    for k in range(len(big)):
        ck(st,'mark_range',all(0<=w<=1 for w in marks[k]))
        ck(st,'uniform_capture_fraction',sum(volume(Z[j])*capZ[k][j] for j in range(len(Z)))/volume(Q)==p[k])
    cost=[[sum(weights[k]*marks[k][i]*capY[k][i]*(1-capZ[k][j]) for k in range(len(big))) for j in range(len(Z))] for i in range(len(Y))]
    original_surplus=sum(rows[i]*sum(weights[k]*marks[k][i]*capY[k][i] for k in range(len(big))) for i in range(len(Y)))
    floor=sum(volume(Y[i])*sum(weights[k]*marks[k][i]*capY[k][i] for k in range(len(big))) for i in range(len(Y)))/m
    original_G=2*floor
    ck(st,'floor_plus_surplus_original',floor+original_surplus==original_G)
    ck(st,'total_surplus_marginal',sum(rows)==sum(cols)==d)
    for i in range(len(Y)):
        ck(st,'common_source_marginal',sum(T[i])==rows[i])
        for v in T[i]:ck(st,'nonnegative_coupling',v>=0)
    for j in range(len(Z)): ck(st,'common_uniform_target_marginal',sum(T[i][j] for i in range(len(Y)))==cols[j])
    product=[[rows[i]*cols[j]/d for j in range(len(Z))] for i in range(len(Y))]
    product_cost=sum(product[i][j]*cost[i][j] for i in range(len(Y)) for j in range(len(Z)))
    common_cost=sum(T[i][j]*cost[i][j] for i in range(len(Y)) for j in range(len(Z)))
    # Explicit common canonical tilt, with P=mu_+/d and U=uniform Q_v.
    # B=sum a_k is a safe bound for reward K; this finite B is not An/h.
    prob_y=[v/d for v in rows]; prob_z=[v/d for v in cols]
    reward=[[sum(weights[k]*marks[k][i]*capY[k][i]*capZ[k][j] for k in range(len(big))) for j in range(len(Z))] for i in range(len(Y))]
    B=sum(weights)
    row_mean=[sum(prob_z[j]*reward[i][j] for j in range(len(Z))) for i in range(len(Y))]
    col_mean=[sum(prob_y[i]*reward[i][j] for i in range(len(Y))) for j in range(len(Z))]
    mean=sum(prob_y[i]*row_mean[i] for i in range(len(Y)))
    Dc=[[reward[i][j]-row_mean[i]-col_mean[j]+mean for j in range(len(Z))] for i in range(len(Y))]
    tilt=[[product[i][j]*(1+Dc[i][j]/(2*B)) for j in range(len(Z))] for i in range(len(Y))]
    for i in range(len(Y)):
        ck(st,'tilt_zero_row_center',sum(prob_z[j]*Dc[i][j] for j in range(len(Z)))==0)
        ck(st,'tilt_source_marginal',sum(tilt[i])==rows[i])
        for j in range(len(Z)):
            ck(st,'reward_bound',0<=reward[i][j]<=B)
            ck(st,'tilt_nonnegative',tilt[i][j]>=0)
    for j in range(len(Z)):
        ck(st,'tilt_zero_column_center',sum(prob_y[i]*Dc[i][j] for i in range(len(Y)))==0)
        ck(st,'tilt_target_marginal',sum(tilt[i][j] for i in range(len(Y)))==cols[j])
    variance=sum(prob_y[i]*prob_z[j]*Dc[i][j]**2 for i in range(len(Y)) for j in range(len(Z)))
    cross=sum(prob_y[i]*prob_z[j]*Dc[i][j]*reward[i][j] for i in range(len(Y)) for j in range(len(Z)))
    tilt_cost=sum(tilt[i][j]*cost[i][j] for i in range(len(Y)) for j in range(len(Z)))
    tilt_gain=d*variance/(2*B)
    ck(st,'double_center_credit_identity',variance==cross)
    ck(st,'tilt_strict_quadratic_gain',tilt_gain>0 and product_cost-tilt_cost==tilt_gain)
    ck(st,'tilt_common_not_better_than_certified_optimum',common_cost<=tilt_cost<product_cost)
    ck(st,'tilt_floor_and_original_preserved',floor+(original_surplus-tilt_cost)+tilt_cost==original_G)
    product_p_cost=sum(rows[i]*sum(weights[k]*marks[k][i]*capY[k][i]*(1-p[k]) for k in range(len(big))) for i in range(len(Y)))
    ck(st,'R371_product_p_equivalence',product_cost==product_p_cost)
    ck(st,'strict_common_cost_gain',common_cost<product_cost)
    for i in range(len(Y)):
        for j in range(len(Z)):ck(st,'finite_weak_dual_feasible',dual_a[i]+dual_b[j]<=cost[i][j])
    dual_value=sum(rows[i]*dual_a[i] for i in range(len(Y)))+sum(cols[j]*dual_b[j] for j in range(len(Z)))
    ck(st,'exact_dual_certificate',dual_value==common_cost)
    paid_product=original_surplus-product_cost
    paid_common=original_surplus-common_cost
    ck(st,'positive_common_paid',paid_common>paid_product>=0)
    ck(st,'floor_unchanged',floor+paid_product+product_cost==floor+paid_common+common_cost==original_G)
    component_cost=[]
    for k in range(len(big)):
        old=sum(product[i][j]*weights[k]*marks[k][i]*capY[k][i]*(1-capZ[k][j]) for i in range(len(Y)) for j in range(len(Z)))
        new=sum(T[i][j]*weights[k]*marks[k][i]*capY[k][i]*(1-capZ[k][j]) for i in range(len(Y)) for j in range(len(Z)))
        component_cost.append([str(old),str(new)])
    return dict(name=name,dimension=len(Q),q_v=str(q),m_v=str(m),d=str(d),q_big=list(map(str,actual_q_big)),
      source_volumes=list(map(str,map(volume,Y))),target_volumes=list(map(str,map(volume,Z))),
      marked_surplus_capture=[str(sum(rows[i]*marks[k][i]*capY[k][i] for i in range(len(Y)))) for k in range(len(big))],
      uniform_target_capture=list(map(str,p)),
      common_matrix=[[str(v) for v in row] for row in T],cost_matrix=[[str(v) for v in row] for row in cost],
      product_cost=str(product_cost),common_cost=str(common_cost),strict_gain=str(product_cost-common_cost),
      floor=str(floor),surplus_diagonal=str(original_surplus),original_G=str(original_G),
      product_paid=str(paid_product),common_paid=str(paid_common),component_cost_product_common=component_cost,
      weak_dual_a=list(map(str,dual_a)),weak_dual_b=list(map(str,dual_b)),exact_optimum=str(dual_value),
      canonical_tilt=dict(B=str(B),B_scope='finite sum of a_k; not the general An/h envelope',
          E_double_center_squared=str(variance),gain=str(tilt_gain),cost=str(tilt_cost),paid=str(original_surplus-tilt_cost),
          double_center=[[str(v) for v in row] for row in Dc],matrix=[[str(v) for v in row] for row in tilt]))

Q=box((0,1));Fbox=box((0,F(1,2)))
Y=[box((0,F(1,4))),box((F(1,4),F(1,2)))]
initial=solve_case('stage1_initial',Q,Fbox,Y,
 [box((0,F(1,4))),box((F(1,4),1))],
 [box((-1,F(1,4))),box((F(1,4),F(3,2)))],
 [F(1),F(1)],[[F(1),F(1)],[F(1),F(1)]],
 [[F(1,8),F(1,8)],[F(0),F(1,4)]],
 [F(1),F(0)],[F(-1),F(0)])
ck('stage1_initial','expected_values',initial['product_cost']=='1/4' and initial['common_cost']=='1/8')
pressure=solve_case('stage2_incompatible',Q,Fbox,Y,
 [box((0,F(1,2))),box((F(1,2),1))],
 [box((-1,F(1,2))),box((F(-3,4),F(1,2)))],
 [F(2),F(1)],[[F(1),F(0)],[F(0),F(1)]],
 [[F(1,4),F(0)],[F(0),F(1,4)]],
 [F(1),F(0)],[F(-1),F(1)])
ck('stage2_incompatible','expected_values',pressure['product_cost']=='3/8' and pressure['common_cost']=='1/4')
ck('stage2_incompatible','independent_zero_costs_incompatible',F(1,4)+F(1,4)>F(1,4))
ck('stage2_incompatible','one_component_can_worsen',pressure['component_cost_product_common'][1]==['1/8','1/4'])
Q2=box((0,1),(0,1));F2=box((0,1),(0,F(1,2)))
Y2=[box((F(i,4),F(i+1,4)),(0,F(1,2))) for i in range(4)]
Z2=[box((F(i,4),F(i+1,4)),(F(j,2),F(j+1,2))) for i in range(4) for j in range(2)]
big2=[box((-1,F(1,2)),(F(-1,4),F(5,4))),
      box((F(1,2),2),(F(-1,4),F(5,4))),
      box((F(-1,4),F(5,4)),(-1,F(1,2)))]
T2=[[F(1,16) if j//2==i else F(0) for j in range(8)] for i in range(4)]
expanded=solve_case('stage3_expanded_2D',Q2,F2,Y2,Z2,big2,[F(3),F(2),F(1)],
 [[F(1),F(1,2),F(0),F(0)],[F(0),F(0),F(1),F(1,2)],[F(1)]*4],
 T2,[F(0)]*4,[F(j%2) for j in range(8)])
ck('stage3_expanded_2D','expected_values',expanded['product_cost']=='23/32' and expanded['common_cost']=='1/4')
print(json.dumps(dict(status='PASS',assertions=count,stage_counts=dict(stages),cases=[initial,pressure,expanded],
 scope='Exact actual L1 positive-volume cell integrations and one common feasible surplus coupling per case; no original high-dimensional J/past/hard-field gates or general new fee claimed.'),sort_keys=True,indent=2))
