% Candidate LPs only; Python independently certifies every rational inequality.
r373_base=fileparts(mfilename('fullpath'));
r373_data=jsondecode(fileread(fullfile(r373_base,'r373_lp_input.json')));
r373_options=optimoptions('linprog','Display','none');
r373_results=cell(numel(r373_data.cases),1);
for r373_i=1:numel(r373_data.cases)
 r373_c=r373_data.cases(r373_i);r373_A=double(r373_c.A);r373_g=double(r373_c.g_numeric(:));r373_m=double(r373_c.m_numeric(:));r373_W=double(r373_c.W_numeric);
 r373_result=struct();r373_result.name=r373_c.name;
 [r373_p,r373_val,r373_flag,r373_info,r373_mult]=linprog([r373_m;r373_W],-[r373_A;ones(1,numel(r373_g))]',-r373_g,[],[],[-Inf(size(r373_A,1),1);0],[],r373_options);
 r373_result.signed=struct('prices',r373_p,'lower_source',r373_mult.ineqlin,'exitflag',r373_flag,'value',r373_val);
 r373_F=double(r373_c.features);r373_cost=double(r373_c.cost_numeric(:));
 [r373_p,r373_val,r373_flag,r373_info,r373_mult]=linprog(r373_cost,-r373_F',-r373_g,[],[],zeros(numel(r373_cost),1),[],r373_options);
 r373_result.nested=struct('prices',r373_p,'lower_source',r373_mult.ineqlin,'exitflag',r373_flag,'value',r373_val);
 r373_results{r373_i}=r373_result;
end
r373_fid=fopen(fullfile(r373_base,'r373_lp_output.json'),'w');fwrite(r373_fid,jsonencode(struct('cases',[r373_results{:}])),'char');fclose(r373_fid);
fprintf('R373 completed %d signed and %d nested-cone candidate LPs.\n',numel(r373_results),numel(r373_results));
