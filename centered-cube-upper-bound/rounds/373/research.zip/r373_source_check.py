from fractions import Fraction as F
from itertools import product

checks=0; strict=0
xs=[F(2*i+1,16)-F(1,2) for i in range(8)]
U=[F(1,8)]*8
profiles=((4,0,0,0,0,0,0,4),(2,0,2,0,2,0,2,0),(0,0,1,3,0,0,1,3),(1,1,1,1,1,1,1,1))
receivers=((F(-3,4),F(3,2)),(F(3,4),F(3,2)),(F(0),F(2)),(F(1,2),F(5,4)))
cap=[[F(int(abs(x-c)<=R/2)) for x in xs] for c,R in receivers]
for raw in profiles:
    f=list(map(F,raw)); q=sum(U[i]*f[i] for i in range(8))
    plus=[U[i]*max(f[i]-q,F(0))/q for i in range(8)]
    dv=sum(plus)
    P=[a/dv for a in plus] if dv else U[:]
    for weights in ((F(1),F(1),F(1),F(1)),(F(1,3),F(2,5),F(1,7),F(3,4)),(F(1),F(1),F(0),F(0))):
        B=sum(weights)
        for mode in range(4):
            om=[[F(1) if mode==0 else (F(0) if mode==1 else F((i+2*k+mode)%5,4)) for i in range(8)] for k in range(4)]
            aa=[[om[k][i]*cap[k][i] for i in range(8)] for k in range(4)]
            K=[[sum(weights[k]*aa[k][i]*cap[k][j] for k in range(4)) for j in range(8)] for i in range(8)]
            L=[sum(weights[k]*aa[k][i] for k in range(4)) for i in range(8)]
            assert all(0<=K[i][j]<=B and K[i][j]<=L[i] for i,j in product(range(8),repeat=2)); checks+=1
            row=[sum(U[j]*K[i][j] for j in range(8)) for i in range(8)]
            col=[sum(P[i]*K[i][j] for i in range(8)) for j in range(8)]
            mean=sum(P[i]*row[i] for i in range(8))
            D=[[K[i][j]-row[i]-col[j]+mean for j in range(8)] for i in range(8)]
            assert all(sum(U[j]*D[i][j] for j in range(8))==0 for i in range(8))
            assert all(sum(P[i]*D[i][j] for i in range(8))==0 for j in range(8)); checks+=1
            T=[[dv*P[i]*U[j]*(1+D[i][j]/(2*B)) for j in range(8)] for i in range(8)]
            assert all(x>=0 for rr in T for x in rr)
            assert [sum(rr) for rr in T]==plus
            assert [sum(T[i][j] for i in range(8)) for j in range(8)]==[dv*x for x in U]; checks+=1
            energy=sum(P[i]*U[j]*D[i][j]**2 for i,j in product(range(8),repeat=2))
            gain=dv*energy/(2*B)
            reward=sum(T[i][j]*K[i][j] for i,j in product(range(8),repeat=2))
            assert reward==dv*mean+gain; checks+=1
            old=sum(dv*P[i]*U[j]*(L[i]-K[i][j]) for i,j in product(range(8),repeat=2))
            new=sum(T[i][j]*(L[i]-K[i][j]) for i,j in product(range(8),repeat=2))
            assert 0<=new==old-gain; checks+=1
            if gain>0: strict+=1
            for k in range(4):
                p=sum(U[j]*cap[k][j] for j in range(8))
                floor=sum(U[i]*min(f[i],q)*aa[k][i]/q for i in range(8))
                good=sum(T[i][j]*aa[k][i]*cap[k][j] for i,j in product(range(8),repeat=2))
                assert floor+good<=2*p-p*p
            checks+=1
            for i,j in product(range(8),repeat=2):
                fact=sum(weights[k]*(aa[k][i]-sum(P[x]*aa[k][x] for x in range(8)))*(cap[k][j]-sum(U[z]*cap[k][z] for z in range(8))) for k in range(4))
                assert fact==D[i][j]
            checks+=1
assert strict>0
print('PASS',checks,'exact Fraction aggregate checks;',strict,'strict-gain cases')
