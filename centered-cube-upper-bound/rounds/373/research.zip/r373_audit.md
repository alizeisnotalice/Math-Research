# R373 independent audit — FINAL PASS

Status: FINAL PASS for the explicit common-surplus coupling, exact nonnegative quadratic gain at the unchanged joint-template price, final main/ledger and bounded auxiliary/code/results review. No unresolved correction was found. The initial independent screens below preceded author proofs. Only this audit file was edited; no repository/other author file was changed. No general closure, uniformly strict gain, covered proportion or optimal common coupling is certified.

## Exact source measures and common coupling
Start from the original pre-joint-split R369/R370 remainder G, NOT merely an upper bound already involving Gjoint. Freeze full f, actual R,q,m,original J,H,global strict past, all pair masks and physical clock including its b atom. Its representation is

G=(1/h*) integral du/Ru^n integral dv Auv integral omega_u(y)c_u(y) f(y)c_v(y)/m_v dy,

where0<=Auv<=1,0<=omega<=1 and A>0 implies a<=Rv<Ru<=b<=2a. The floor min(f,qv) remains a positive component with cost Gamma_n|E|/h*.

For each ACTUAL v define mu_v^+=(f-qv)+ c_v dy/m_v, d_v=mass(mu_v^+) in[0,1], and the probability U_v=c_v dz/Rv^n. A chosen finite coupling tau_v must have first marginal mu_v^+ and second marginal d_v U_v. Its total mass is d_v, not1 or d_v^2. The zero-mass case has tau_v=0. The simple always-valid measurable choice is tau_v=mu_v^+ tensor U_v (NOT mu_v^+ tensor d_v U_v). Joint measurability in actual v is needed to integrate tau_v against dv; standard Borel/measurable finite kernels suffice. The same tau_v must serve ALL actual u and sources/clock terms. An independent plan chosen per u is not a lawful common coupling and cannot be used in the proposed receipt.

## Positive good/bad split and inflation coefficient
Fix t>=0, finite, Q_u^t the same-center cube of SIDE Ru+2t. In the positive surplus integral replace the source measure mu_v^+ by its coupling and partition according to z in Q_u^t versus z outside. The first-marginal identity proves exact G_surplus=G_good+G_bad, with original omega_u(y)c_u(y) at the ORIGINAL source y. No mark is evaluated at transported z and no J,q,m,strict past or receiver is recomputed.

For good, positively drop omega*c_u,A<=1, then the second marginal gives

integral omega_u(y)c_u(y)1_{Q_u^t}(z) tau_v(dy,dz)
<=d_v U_v(Q_u^t)<=U_v(Q_u^t).

Consequently G_good<=(1/h*) integral_E du/Ru^n integral_{v:Rv<Ru} |Q_u^t intersect Q_v|/Rv^n dv. Apply the R370 ALL-SCALE template with fixed reference side Ru+2t, actual smaller-side selector Rv and lower bound a. The restricted eligible-v set can be extended measurably for this deterministic positive upper bound; no extra receiver is given a matched f mass. The fixed-u capacity is at most(Ru+2t)^n C_n(a/(Ru+2t)). Since Ru>=a,Ru<=b<=2a and C_n decreases in its argument,

G_good <= (1+2t/a)^n C_n(1/(2+2t/a)) |E|/h*.

The full original G is therefore at most G_bad+[Gamma_n+(1+2t/a)^n C_n(1/(2+2t/a))]|E|/h*, at the SAME h*/epsilon0. The conversion |E|<=Xq/qminus is still required. Inflation has a real receiver-center volume cost; it is not a source-density estimate. Any parameter reallocation must change h*,C338 and the precise remaining gates consistently.

On bad tuples y in Q_u and z notin Q_u^t, triangle inequality gives ||y-z||infinity>t. Equality lies on the good side for closed cubes. This is a geometric constraint on the transported pair, not a density cap, a proof that bad is small, or permission to reset source qualifications at z. All original source/pair marks remain on y inside the exact bad measure.

## Recovery and ledger priorities
At t=0 with the product coupling, good=p_uv times the old surplus and bad=(1-p_uv) times it, exactly recovering R371's joint source decomposition. The total coarse price is2Gamma_n, replacing the old joint receipt; it is NOT an extra fee after the R3712Gamma_n was charged. The sharper same-pair2p-p^2 saving may be retained for this special product case, but cannot be claimed for an arbitrary coupling solely from its marginals.

For t>0 the inflated price replaces the good component; product coupling alone can change bad by its enlarged geometric fraction but pays the displayed inflation. A proposed optimized coupling is only useful when it lowers the AGGREGATE original marked bad functional relative to its price. No such gain follows from the marginal existence/product plan. A pointwise infimum over plans does not establish a jointly measurable minimizer; an explicit plan, a justified measurable selection, or a measurable epsilon-optimal construction is needed before any optimizer is substituted. This is a conditional coupling tool, not an unconditional new general paid family.

The inherited complete hard-slot receiver coefficient, if this alternative is adopted from the original G, is epsilon0[2+(Cplus_n+Gamma_n+Gamma_inflated)/(1+sqrt(n))], not that amount plus the old2Gamma_n. Original entrance2,outerLambda128/119,8lambda H W and2d_eff A_nWnu/H remain. The exact coupled bad term and all soft/entry/history/scale/exterior/limiting obligations are unbudgeted until separately proved.

## Actual local arithmetic evidence
Reviewer-local standard-library Fraction checks actually passed76 scalar kernel-marginal/product-split assertions on four nonnegative source profiles and all three-bit captures, including d_v=0. They verify both marginals, the positive split, good<=d_v p<=p and exact product recovery. These are finite scalar arrays, not original native hard-field realizations, and are not included in any author/parent count. No R373 author proof was read before this initial screen; final author review and byte binding follow below.

## Additional independent screen: explicit common coupling and quadratic gain
Screened BEFORE the author proof. PASS for the proposed explicit direction, with no claim that its credit controls the whole remainder.

At t=0 and d_v>0, define P_v=mu_v^+/d_v and retain the same U_v. The aggregate actual reward kernel is

K_v(y,z)=(1/h*) integral_E du/Ru^n Auv omega_u(y)c_u(y)c_u(z).

It is jointly measurable in(v,y,z) from the original measurable field and Tonelli. Dropping positive factors bounds it by(1/h*) integral_E c_u(z)du/Ru^n<=A_clock/h*=:B, A_clock=1+nlog(b/a). This is the actual arbitrary-selector CENTER envelope at z, not an assumption on source f. B>0 is global and has density units; all original omega/past/J/clock information stays in K. K need not be symmetric.

Let row(y)=E_U K(y,Z),col(z)=E_P K(Y,z),mean=E_PU K and D=K-row-col+mean. Both conditional expectations of D vanish. Since0<=K,row,col,mean<=B, -2B<=D<=2B. Thus tau_v=d_v[1+D/(2B)]P_v tensor U_v is a NONNEGATIVE finite coupling with first mu_v^+, second d_v U_v, and density at most2 relative to the product plan. At d_v=0 choose tau_v=0; taking P_v=U_v there makes a measurable total definition if needed. There is no separately chosen u-dependent plan or optimizer-selection assertion.

Orthogonality of D to functions of y alone and z alone gives E(KD)=E(D^2) exactly. Therefore aggregate transported good reward increases relative to product by

Delta=(1/(2B)) integral_E dv d_v E_(P_v tensor U_v)D_v^2>=0.

The original surplus total is unchanged by the first marginal. Consequently the exact new positive bad integral is Gjoint-Delta>=0; in particular Delta<=Gjoint<=X_q. The sign does not rely on comparing a new input or a separately optimized receiver family. This square is a reference-coupling covariance improvement, not original captured-source variance or a twice-used old square credit.

At each actual pair, the unchanged floor integral is<=min(p,1-d_v), because its total normalized mass in Q_v is1-d_v. The transported good integral is<=d_v p by the second marginal. For ALL p,d in[0,1], min(p,1-d)+dp<=2p-p^2 (split at d=1-p). Hence floor plus this new good part costs at most the SAME explicit template2T0-T2<=2Gamma_n|E|/h*. One must not add another floor/transport bill; start from original G, split with this tau, and replace the R371 residual by Gjoint-Delta at its existing fee. The new remainder retains all original y marks plus the transported z-outside restriction. No uniform nonzero Delta or useful fraction has been proved. Finite E,B makes the construction and all reward/square integrals finite; the bound Delta<=Gjoint also follows directly from the positive split.

A second reviewer-local Fraction exercise actually passed108 scalar configurations for conditional centering, both coupling marginals, nonnegativity, the exact reward-square identity and the(p,d) paid-envelope inequality. These are nonnative finite arrays. Combined reviewer scalar checks are184, separate from author/parent counts. The new explicit construction is universally valid within the frozen contract; any claim of global closure, optimality or a full residual budget still needs a separate proof.


## Final source theorem and triple-covariance review
Read final /tmp/r373_source.md in full, including the complete embedded336-check code. PASS; it agrees with the independent construction above. Its source kernel is the original marked R369 pre-split G, while Gjoint is precisely the R371 product-plan bad part. The complete actual-u reward K is formed BEFORE selecting one plan per small v. Actual center-envelope bound B=A_clock/h is uniform, finite and independent of source-density assumptions. The d=0 convention, joint measurability, conditional centering and marginal calculations are legitimate with the actual L1 source and bounded measurable original omega. No source-private u plan, new receiver, or measurable optimizer is assumed.

The new bad integrand L_v(y)-K_v(y,z) is pointwise nonnegative, not just a difference of bounded objectives. Thus its exact identity Gnew=Gjoint-Delta gives0<=Delta<=Gjoint<=X_q. The sum of old floor and this plan's captured target still satisfies the SAME per-pair2p-p^2 bound using a<=min(p,1-d) and good<=dp. No extra Gamma, mark-oscillation fee, Dminus, original source square or path credit is spent. It is essential that this is rederived from the original positive G; the final source/main/ledger do so.

Equations(9)-(10) are correct. Since K=(1/h)integral A a_u(y)c_u(z)du/Ru^n, its double centering factors into[a_u-E_P a_u][c_u-p_uv]. Squaring and integrating in the PRODUCT P_v tensor U_v yields the full actual-u,w integral of Cov_P(a_u,a_w)Cov_U(c_u,c_w), with the exact h^-2 and radius denominators. The uniform covariance is actual triple-intersection volume/Rv^n minus p_uv p_wv. Bounded capture/omega and finite E justify the signed double Fubini. Individual covariance products need not be nonnegative; only their integrated squared norm is. Both original omega marks retain their complete integrated physical-clock information. This is a new coupling square, not a claim that two physical clocks have been identified or that an old same-clock captured-source square can be deducted again.

The optional finite relative-cell plan is also a legal common kernel: inside each cell consume equal min(source,target) mass using normalized products, then couple the equal residual marginals by their normalized product, omitting zero masses. Finite tie-rule selection among measurable candidate aggregate costs is measurable. This optional construction is not needed in the displayed main ledger and no claimed improvement from it is charged. The initial inflation variant is likewise an alternative, not an extra fee or credit in the preferred t=0 theorem.

## Finite common-coupling diagnostic review
Read /tmp/r373_coupling.md, its entire script and supplied JSON. PASS within the stated mechanism-only scope. Each source/target partition has genuine positive-volume real cells, with piecewise-constant f=2 on a half-volume rectangle, q_v=m_v=1,d=1/2. The coupling matrix corresponds to an actual absolutely continuous density T_ij/(|Y_i||Z_j|), and all cube/mark factors are cell-constant. Hence the rational values are complete finite-cell continuum integrals, not sampled source atoms. They are still not the full original receiver-Lebesgue/high-past hard field: big-cube q values and arbitrary marks are expressly different.

The three one-COMMON-plan product/optimal costs1/4 to1/8,3/8 to1/4,23/32 to1/4 follow the specified matrices and feasible lower dual potentials. Stage2 correctly forces a common target-capacity compromise and worsens the second component from1/8 to1/4 while reducing the aggregate; no per-big-cube dominance is asserted. The canonical tilt uses finite B=sum weights (NOT the general hard-field A_clock/h) and its exact gains3/128,1/192,251/6144 and positive remainders agree with JSON. Both marginals, unchanged floor/diagonal and exact gain identities are checked. These examples show strict mechanism gain but do not certify nonzero Delta on every original hard field or any fixed fraction.

## Auxiliary geometry review — not a main payment
Read /tmp/r373_geometry.md in full and its saved code. PASS for its explicit identities/class optimum, not a general bound. For actual subfamily D, nu=f rho dy is finite and reversible, with the stated capture-square/Dirichlet identity. The uniform reference zeta=rho dy instead pushes to f kappa dy; kappa/rho lies between1/lambda and1/qminus. Thus unrestricted zeta domination really imports a density bound, whereas tests restricted to the explicitly observable sigma-field give the conditional density stated in(6). Since rho is observable, E_zeta[f] equals the R371 normalization rho E_zeta[f/rho]. No assertion that large invisible peaks obstruct the actual special load is made.

The last-radius construction is measurable and has exact boundary average lambda by continuity in radius and finite-source large-radius decay, but it is a DIFFERENT selector contract from frozen R371. Within that separate one-center price class, every enlargement covers the entire base cube, forcing alpha+total(beta)>=esssup H and cost>=m esssup H. Base-only price attains it; the source relaxation approaching this value need not preserve OTHER centers. These statements do not disprove a joint cross-center method and do not add any new original-flow fee. The actual-target mean conservation is an identity, not a bound by Gamma_n. Its656 reported exact checks concern finite quadrature identities and scalar radial prices, not an original native hard input.

## Finite price LP code and results review
Read /tmp/r373_numeric.md,/tmp/r373_verify.py,/tmp/r373_lp.m and their input/output/verified JSON. PASS for the six finite certificates. The complete Cartesian source cells cover the whole domain, including zero-load states; uniform L1 f gives exact cube masses and W. All source-matching data and the prefix/J/strict-past diagnostic load are frozen. The compressed clock weights are exact physical radius-interval integrals plus b atom. Receivers are finite QUADRATURE, and kappa=6/5 with reduced H/h is explicitly not the original K/highpast/outside/notBplus contract.

Full signed upper prices use arbitrary cube coefficients with NONNEGATIVE W intercept C, so their exact lower source has every cube equality and total mass<=W. Nested upper prices use actual nonnegative cubes,shells and W; their relaxed lower source has all corresponding upper capacities, not matching equalities. Shell deficit monotonicity is correctly oriented delta_parent>=delta_child. MATLAB inequality multipliers supply candidate lower sources for these respective classes, and the Python verifier independently requires every rational feasibility condition, full-source-cell upper cover and exact zero gap. Upward W-intercept repair has the correct direction; no solver flag is treated as a certificate.

The three verified zero gaps compare only these tested finite cones. The supplied results give equal signed/nested optima41/4224,143287/11128320,1099/310080. The nested sources have unfilled matching deficits and are not admissible all-matching original inputs. The weighted1D actual nested shell explains that sample's signed-price advantage over cube-only nonnegative prices, but neither equality for arbitrary data nor a global signed-shell restriction theorem follows. Main/numeric state these limitations. No second MATLAB execution or independent optimization search was performed by this reviewer.

## Final integration, executed checks and byte consistency
Read final main,ledger and README in full. PASS. The only new preferred replacement is Gjoint toGjoint-Delta>=0 at unchanged C338 and2Gamma_n. The entire original hard coefficient, L_n allocation, synchronized epsilon0/h/C338, entrance8lambda H W+2d_eff A_clockWnu/H+2B_H and outerLambda128/119 are retained. Thus the credit after all outside factors is exactly2Lambda Delta, ONCE. The old R371 coefficient and remaining independent slots are not duplicated. Initial inflated transport,candidate optimal plans, auxiliary Gibbs/last-radius identities and finite signed-shell prices are not additional ledger payments. No claim controls Gjoint-Delta at the required scale or proves total absorption.

The parent reports actual local reruns: source336 aggregate Fraction checks with27 strict cases; coupling369 Fraction checks; square203 matrix cases; numeric preparation67 plus certificate verification55 exact grouped assertions; geometry656 exact checks. These scopes are separate, counts are not theorem/native-field counts, and repeated runs are not added. Reviewer184 actual scalar assertions remain separately recorded. The source standalone script matches its unique final embedded block after stripping outer whitespace. Geometry standalone differs ONLY by replacing its two absolute/tmp R371 JSON references with same-folder paths; both frozen dependency JSONs are bound below. The finite verified/coupling JSON statuses, zero gaps and displayed gain values match the final notes. No full pipeline was redundantly rerun during this audit.

The precise remaining positive coupled bad measure retains actual source y,reference target z and all original full-f fields/marks; it is not a truncated new input or a requalified old path. Delta can vanish when the reward has no double-centered interaction. All independent general soft/crossing/entry, contract-exterior heavy/distance/low-pe/scale/threshold regimes, historical initial/deletion/future-source time atoms, H choice, source and physical-scale aggregation, outer integration,truncation and limiting interfaces remain unproved. No original high-dimensional qualification is imported from finite mechanisms. No PDF compilation, archive/Git or publication is certified. No outstanding correction; final bounded disposition PASS.

## Final frozen byte bindings
SHA256 binds the exact reviewed bytes; this audit is hashed separately after saving.

- `/tmp/r373_main.md` — `525c767a678882369118f23f8175878bbfcbd5d58adf2ff40a8f942ddfc8adfd`
- `/tmp/r373_ledger.md` — `55230deac9288f647b39c78022c39ebbe0564c1f7fe4fc6b4577f2c38075b66d`
- `/tmp/r373_readme.md` — `1cf81cdd031a599043303be5306050d494d37eedcc47eb2b3f1d11b069ffee87`
- `/tmp/r373_source.md` — `beae8a77dc6f4fbcbf06d1b6747c46365cb7754011064be220d59d6e8f3c237a`
- `/tmp/r373_coupling.md` — `2ae0ac320944a69cc63f65286dfda48e8884258ea641cad5c82d4c4f05c269d5`
- `/tmp/r373_geometry.md` — `2ed92db90181bcdef2d98185f71040cfe98443d041cfe95a84e9c4f34d0c156d`
- `/tmp/r373_numeric.md` — `b164165e745e1791f26c3609e6593522adc5e1579da964b30b15ad51c71fb78a`
- `/tmp/r373_source_check.py` — `3709a8a127e3a1a72e059393565cd98ffd3d7653bd3bcdc2e0eace3b6b029bcd`
- `/tmp/r373_coupling_check.py` — `4c45380f7cfa6b4d8cf15a0d3c8dd1c317fd61b732ecb347ca00ae7b7621a420`
- `/tmp/r373_coupling.json` — `cca9bfbc8b08f7be031498f0575ba79d6694e1f9d62042efbaf84905012485df`
- `/tmp/r373_geometry_check.py` — `352935dafcd015d3a56f3e917ed64dd883ff94fc2a25bf99802db98595145c5e`
- `/tmp/r373_square_check.py` — `d291635c9e663717c9264c98245a57dacf2c09d58160db7f08d1f7a017152ce7`
- `/tmp/r373_verify.py` — `af862961265ff11530aa0cb9d21541907274a4ad1f3fc52f421f9bf1c1df8354`
- `/tmp/r373_lp.m` — `ac284bfd2620d1b125de3ec73068aa66db55cf8925a360248bb25bbeb125d817`
- `/tmp/r373_lp_input.json` — `00277b5dbeae37484787da6f622ced7a51ac04aee6f4d7d3edbbb170adda226d`
- `/tmp/r373_lp_output.json` — `012fa453ef6677301a0f147a7681cbd8cdecc3475ca90c7b29800ed189992f05`
- `/tmp/r373_verified.json` — `af40ccbe75a92d88ca5b645d15e462cb0d47baefde3e8331c5dba1cf96c4113e`

Necessary inherited contracts / auxiliary input dependencies:

- `/tmp/r371_main.md` — `fab564727af22c6a95f90f25678875b67cfd02084f0abd1a03a5004df9a2c558`
- `/tmp/r371_ledger.md` — `4ad01abea21c4afe8d84fb50ddfb306cde298381f62065cbd39b6891875655d3`
- `/tmp/r371_audit.md` — `17061699676853791326b4bed45017af5100b6b55c96c62c1aa57bf19e1b3490`
- `/tmp/r370_geometry.md` — `fac02a43e18ed5dc3d5be7ef67a8ac9e34cbd4dd1e69912d6e29dffda597d81a`
- `/tmp/r370_main.md` — `150cea9386d50fd023f66948992b86ee482857888ed7e027802cab2aaaf26ed1`
- `/tmp/r371_lp_input.json` — `4b3c79631b526510c48f875656c1bd01f31346394fdeaa4a93f773c7caabca53`
- `/tmp/r371_lp_output.json` — `5fd57177164394f5cdc6e561bfdf0d1c5af1a71083bb65affb9c9736d674ce4c`

Frozen FINAL PASS; subsequent mathematical/byte changes require renewed review/binding. No further bounded task work remains.
