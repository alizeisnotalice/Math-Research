from fractions import Fraction as F
from itertools import product
import random
rng=random.Random(373)
counts={'initial':0,'stress':0,'expanded':0}
def test(K,P,U,d,stage):
    assert sum(P)==sum(U)==1 and 0<d<=1
    B=max(max(row) for row in K)
    if not B:B=F(1)
    assert all(0<=v<=B for row in K for v in row)
    nr,nc=len(P),len(U)
    rows=[sum(U[j]*K[i][j] for j in range(nc)) for i in range(nr)]
    cols=[sum(P[i]*K[i][j] for i in range(nr)) for j in range(nc)]
    mean=sum(P[i]*rows[i] for i in range(nr))
    D=[[K[i][j]-rows[i]-cols[j]+mean for j in range(nc)] for i in range(nr)]
    tau=[[d*P[i]*U[j]*(1+D[i][j]/(2*B)) for j in range(nc)] for i in range(nr)]
    assert all(x>=0 for row in tau for x in row)
    assert all(sum(tau[i])==d*P[i] for i in range(nr))
    assert all(sum(tau[i][j] for i in range(nr))==d*U[j] for j in range(nc))
    square=sum(P[i]*U[j]*D[i][j]**2 for i in range(nr) for j in range(nc))
    gain=d*square/(2*B)
    reward=sum(tau[i][j]*K[i][j] for i in range(nr) for j in range(nc))
    assert reward-d*mean==gain>=0
    source=sum(d*P[i]*max(K[i]) for i in range(nr))
    assert source-reward>=0 and source-d*mean>=gain
    counts[stage]+=1
    return gain
for vals in product([F(0),F(1,2),F(1)],repeat=4):
    test([list(vals[:2]),list(vals[2:])],[F(1,3),F(2,3)],[F(3,4),F(1,4)],F(2,5),'initial')
for vals in product(range(1,5),repeat=2):
    p=F(vals[0],sum(vals));u=F(vals[1],sum(vals))
    assert test([[F(1),F(0)],[F(0),F(1)]],[p,1-p],[u,1-u],F(1,2),'stress')>0
    assert test([[F(1,4),F(1,2)],[F(1,2),F(3,4)]],[p,1-p],[u,1-u],F(1,2),'stress')==0
for nr,nc in [(2,4),(3,5),(5,7)]:
    for _ in range(30):
        ps=[rng.randrange(1,10) for i in range(nr)];us=[rng.randrange(1,10) for j in range(nc)]
        P=[F(x,sum(ps)) for x in ps];U=[F(x,sum(us)) for x in us]
        K=[[F(rng.randrange(11),10) for j in range(nc)] for i in range(nr)]
        test(K,P,U,F(rng.randrange(1,10),10),'expanded')
print('PASS exact common-coupling matrix tests',counts,'total',sum(counts.values()))
print('Scope: finite algebra of two marginals and new square credit; not native cube hard-gate certification.')
