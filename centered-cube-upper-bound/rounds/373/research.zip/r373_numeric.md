# R373: actual cube price cones, finite exact certificates

The three bounded tests give **equal nested-shell and full signed optima**. This supports studying nested-shell prices before introducing general crossing prices; it does not establish equality of the price classes for other data. No optional two-parent cover was added because no gap arose.

## Models and matching

The script is self-contained. The first two stages use the R371 geometry regenerated from its recipe: 15 intervals at centres −1, −1/2, 0, 1/2, 1, each of side 1, 3/2, 2. Initial quadrature weights are 1/8; stress weights vary between 1/16 and 3/16 by the declared index rule. The expanded stage has twelve true 2D cubes: centres (−3/4,0), (0,0), (3/4,0), (0,3/4), each with sides 1, 3/2, 2 and weights 1/32, 2/32, 3/32 by its declared index rule.

All cube endpoints partition the entire source domain [−2,2]^n into positive-volume Cartesian cells: 16 cells in each 1D model and 208 in 2D. The zero-load source cells remain in every constraint. Uniform density one gives the actual compact positive-L1 feasible source, with m_u=R_u^n and W=4^n. Any nonnegative matching source-cell masses correspond to genuine piecewise-constant compact L1 sources with the same actual q_u=1. Receiver weights are **finite quadrature**, not receiver Lebesgue integration.

The frozen load is the R371 diagnostic ordered mass-gap expression: κ=6/5, outside condition 2||u−v||∞>R_u, H=h=1/16 in 1D and 1/64 in 2D; strict global past m_t<m_u/κ. Physical prefix clock uses r^(−n)−r_next^(−n), plus the true terminal b^(−n) atom. The diagnostic load has 16,16,12 active pair/cell/layer terms respectively. These gates are not the original exp(√n) hard branch, nor a full history realization.

## Precisely compared cones

Full signed upper certificates use arbitrary receiver prices t_u and a **nonnegative** total-mass intercept C:

    Σ_u t_u c_u(z)+C ≥ g(z),  price=Σ_u m_u t_u+W C.

Their lower certificates have x≥0, every cube matching Ax=m, and total mass≤W. Thus the W intercept has the correct sign.

Nested upper certificates have nonnegative prices for every actual cube, every true inclusion shell c_parent−c_child with Q_child⊆Q_parent, and W. There are 23,23,12 true inclusion shells. All features are checked nonnegative on every complete cell. Nested lower certificates satisfy cube/shell mass≤their actual costs and total mass≤W. They need not satisfy matching: the reported deficits δ_u=m_u−∫c_u x are nonnegative and obey δ_parent≥δ_child for every true inclusion. All three returned nested lower sources have nonzero deficits; they are auxiliary cone lower certificates, not matching sources.

## Exact results

| Stage | Receivers / cells | Full signed optimum | Nested-shell optimum | Gap |
|---|---:|---:|---:|---:|
| Initial equal 1D | 15 / 16 | 41/4224 | 41/4224 | 0 |
| Stress weighted 1D | 15 / 16 | 143287/11128320 | 143287/11128320 | 0 |
| Expanded crossing 2D | 12 / 208 | 1099/310080 | 1099/310080 | 0 |

Every optimum has an independently verified exact rational primal lower and dual upper certificate with zero gap. All C=0; all floating-to-rational coverage repairs are zero. MATLAB solver success is not used as proof.

For weighted 1D the returned nonzero nested prices (zero-based receiver indices) are:

- cube 6: 467/60480; cube 7: 31/20160; cube 9: 31/20160;
- shell 5−4: 14579/5564160. These are concentric intervals at centre −1/2, outer side 2 and inner side 3/2.

For 2D they are cube 4: 21/24320, shell 4−3: 189/358720, and shell 7−6: 581/770304. Each shell is concentric with outer side 3/2 and inner side 1. This is a genuinely 2D complete-source-cell computation, though the fixed diagnostic load can still be sparse.

The R371 nonnegative-cube-only optimum for weighted 1D was 26311/1854720, which exceeds its signed optimum by 14579/11128320. The present result locates a sufficient structural remedy on that same sample: an actual nested shell already closes the gap. General nonnested crossing prices are unnecessary on these tests. This is sample evidence, not a restriction theorem for general signed prices.

## Execution and reproduction

Actual local MATLAB linprog ran three signed and three nested LPs. Standard-library Python checked **67 construction assertions plus 55 certificate assertions = 122 exact grouped assertions**. These count grouped vector inequalities as one assertion, not individual scalar comparisons. There are no numerical/Decimal assertions included in that count. Fresh prepare→MATLAB→verify was run after implementation; all six zero gaps remained exact.

Use the bundled Python executable:

    /Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 r373_verify.py prepare
    # Run r373_lp.m in MATLAB, from its own directory.
    /Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 r373_verify.py

The scripts resolve data paths from their own directory and do not reset MATLAB's global workspace/path. Minimum reproduction materials: r373_verify.py and r373_lp.m; prepare regenerates r373_lp_input.json. The saved r373_lp_output.json preserves the actual six solver candidates, and r373_verified.json preserves rational prices, lower sources, all deficits and concise scope. Nothing here certifies a general root bound, an actual continuum receiver field, or original hard/history admissibility.
