#!/usr/bin/env python3
"""Complete cube cells, two finite price cones; MATLAB supplies candidates only."""
from fractions import Fraction as F
from itertools import product
from pathlib import Path
from collections import Counter
import json,sys,hashlib
BASE=Path(__file__).resolve().parent; COUNTS=Counter()
def ck(k,v):
 COUNTS[k]+=1
 assert v,k
def dot(a,b):return sum((F(x)*y for x,y in zip(a,b)),F(0))
def rat(v):return F(0) if abs(v)<1e-10 else F(str(v)).limit_denominator(10**9)
def contained(a,b):
 ca,ra,_=a;cb,rb,_=b
 return all(abs(x-y)+rb/2<=ra/2 for x,y in zip(ca,cb))
def cases():
 out=[]
 for stage,kind in [('initial','equal'),('stress','weighted')]:
  out.append((stage,'grid15_'+kind,[((F(j,2),),r,F(1,8) if kind=='equal' else F((j+2+k)%3+1,16)) for j in range(-2,3) for k,r in enumerate([F(1),F(3,2),F(2)])]))
 centers=[(F(-3,4),F(0)),(F(0),F(0)),(F(3,4),F(0)),(F(0),F(3,4))]
 out.append(('expanded','crossing_cubes2d',[(c,r,F((j+2*k)%3+1,32)) for j,c in enumerate(centers) for k,r in enumerate([F(1),F(3,2),F(2)])]))
 return out
def fixture(stage,name,rec):
 n=len(rec[0][0]);N=len(rec); axes=[]
 for d in range(n):
  pts=sorted(set([F(-2),F(2)]+[v for c,r,w in rec for v in (c[d]-r/2,c[d]+r/2)]));axes.append(list(zip(pts,pts[1:])))
 cells=list(product(*axes));x0=[]
 for cell in cells:
  v=F(1)
  for a,b in cell:v*=b-a
  x0.append(v)
 A=[[int(all(c[d]-r/2<=a and b<=c[d]+r/2 for d,(a,b) in enumerate(cell))) for cell in cells] for c,r,w in rec]
 m=[r**n for c,r,w in rec];mu=[w/z for (_,_,w),z in zip(rec,m)];radii=sorted({r for c,r,w in rec});H=h=F(1,16) if n==1 else F(1,64);kappa=F(6,5);g=[F(0)]*len(cells);active=0
 for l,r in enumerate(radii):
  ell=r**(-n)-(radii[l+1]**(-n) if l+1<len(radii) else 0)
  for j in range(len(cells)):
   J=sum(mu[u]*A[u][j] for u in range(N) if rec[u][1]<=r)
   if J<H:continue
   for u,(cu,ru,wu) in enumerate(rec):
    if ru>r or not A[u][j]:continue
    past=sum(mu[t]*A[t][j] for t in range(N) if m[t]<m[u]/kappa)
    if past<=h:continue
    for v,(cv,rv,wv) in enumerate(rec):
     if rv<=r and A[v][j] and m[u]>kappa*m[v] and 2*max(abs(a-b) for a,b in zip(cu,cv))>ru:
      g[j]+=ell/J*(m[u]-m[v])*mu[u]*mu[v];active+=1
 W=F(4)**n
 ck('uniform_source_all_matching',all(dot(row,x0)==rhs for row,rhs in zip(A,m)))
 ck('complete_positive_source_cells',all(x>0 for x in x0) and sum(x0)==W)
 features=[list(row) for row in A];cost=list(m);labels=[['cube',u] for u in range(N)]
 for u in range(N):
  for v in range(N):
   if u!=v and contained(rec[u],rec[v]):
    feat=[a-b for a,b in zip(A[u],A[v])]
    ck('true_nested_shell_nonnegative_on_complete_cells',all(a>=0 for a in feat))
    features.append(feat);cost.append(m[u]-m[v]);labels.append(['shell',u,v])
 features.append([1]*len(cells));cost.append(W);labels.append(['W'])
 ck('diagnostic_load_nonempty',active>0 and max(g)>0)
 return dict(stage=stage,name=name,n=n,A=A,m=list(map(str,m)),W=str(W),g=list(map(str,g)),x0=list(map(str,x0)),cells=[[[str(a),str(b)] for a,b in cell] for cell in cells],receivers=[dict(center=list(map(str,c)),R=str(r),weight=str(w)) for c,r,w in rec],features=features,cost=list(map(str,cost)),labels=labels,H=str(H),h=str(h),kappa=str(kappa),active_pair_cell_layers=active)
def numeric(c):
 d=dict(c);d['m_numeric']=list(map(float,map(F,c['m'])));d['W_numeric']=float(F(c['W']));d['g_numeric']=list(map(float,map(F,c['g'])));d['cost_numeric']=list(map(float,map(F,c['cost'])));return d
def prepare():
 data=[numeric(fixture(*v)) for v in cases()]
 (BASE/'r373_lp_input.json').write_text(json.dumps(dict(cases=data,scope='Actual cube-complete positive-volume source cells; finite receiver quadrature and diagnostic gates, not original hard branch.'),sort_keys=True,indent=2)+'\n')
 print(json.dumps(dict(status='PREPARED',checks=sum(COUNTS.values()),counts=dict(COUNTS),cases=[dict(name=c['name'],n=c['n'],receivers=len(c['A']),cells=len(c['g']),shells=len(c['features'])-len(c['A'])-1) for c in data])))
def aslist(v):return [v] if isinstance(v,dict) else v
def verify():
 inp=json.loads((BASE/'r373_lp_input.json').read_text())['cases'];raw=aslist(json.loads((BASE/'r373_lp_output.json').read_text())['cases']);rows=[]
 ck('all_three_cases_present',len(inp)==len(raw)==3)
 for case,cand in zip(inp,raw):
  ck('case_identity',case['name']==cand['name']);A=case['A'];m=list(map(F,case['m']));g=list(map(F,case['g']));W=F(case['W']);x0=list(map(F,case['x0']));feat=case['features'];cost=list(map(F,case['cost']));N=len(A)
  solutions={}
  for mode in ['signed','nested']:
   z=cand[mode];p=list(map(rat,z['prices']));x=list(map(rat,z['lower_source']));ck(mode+'_nonnegative_lower_source',all(a>=0 for a in x));ck(mode+'_source_total_cap',sum(x)<=W)
   if mode=='signed':
    ck(mode+'_matching_all_cubes',all(dot(row,x)==rhs for row,rhs in zip(A,m)));ck(mode+'_nonnegative_W_intercept',p[-1]>=0);Fmat=A+[[1]*len(g)];pricecost=m+[W]
   else:
    ck(mode+'_all_cube_and_shell_capacities',all(dot(row,x)<=rhs for row,rhs in zip(feat,cost)));ck(mode+'_nonnegative_prices',all(a>=0 for a in p));Fmat=feat;pricecost=cost
   deficit=max([F(0)]+[g[j]-sum(F(row[j])*t for row,t in zip(Fmat,p)) for j in range(len(g))]);p[-1]+=deficit
   ck(mode+'_exact_coverage_all_cells_including_zero_load',all(sum(F(row[j])*t for row,t in zip(Fmat,p))>=g[j] for j in range(len(g))))
   upper=dot(pricecost,p);lower=dot(g,x);ck(mode+'_weak_duality',upper>=lower);ck(mode+'_exact_zero_gap',upper==lower)
   solutions[mode]=dict(upper=str(upper),lower=str(lower),prices=list(map(str,p)),source=list(map(str,x)),W_intercept=str(p[-1]),coverage_repair=str(deficit),exitflag=z['exitflag'])
  S=F(solutions['signed']['upper']);T=F(solutions['nested']['upper']);ck('nested_cone_not_cheaper_than_full_signed',T>=S)
  x=list(map(F,solutions['nested']['source']));deficits=[rhs-dot(row,x) for row,rhs in zip(A,m)]
  ck('nested_relaxed_source_nonnegative_cube_deficits',all(v>=0 for v in deficits))
  ck('nested_deficits_monotone_on_every_true_inclusion',all(deficits[l[1]]>=deficits[l[2]] for l in case['labels'] if l[0]=='shell'))
  # Bounded one-cover followup: select only a genuine nonnested two-parent cover.
  covers=[]
  if T>S:
   for a in range(N):
    for b in range(a+1,N):
     for c in range(N):
      if c in (a,b) or all(A[c][j]<=A[a][j] for j in range(len(g))) or all(A[c][j]<=A[b][j] for j in range(len(g))):continue
      f=[A[a][j]+A[b][j]-A[c][j] for j in range(len(g))];cc=m[a]+m[b]-m[c]
      if min(f)>=0 and cc>=0:
       violation=dot(f,x)-cc
       if violation>0:covers.append((violation,a,b,c,f,cc))
  best=max(covers,key=lambda z:z[0]) if covers else None
  rows.append(dict(stage=case['stage'],name=case['name'],n=case['n'],receivers=N,source_cells=len(g),true_shells=len(feat)-N-1,active_pair_cell_layers=case['active_pair_cell_layers'],uniform_objective=str(dot(g,x0)),signed=solutions['signed'],nested=solutions['nested'],gap=str(T-S),nested_lower_is_actual_matching=all(v==0 for v in deficits),nested_deficits=list(map(str,deficits)),one_nonnested_cover_to_test=dict(parents=[best[1],best[2]],child=best[3],cost=str(best[5]),violation=str(best[0]),feature=best[4]) if best else None))
 out=dict(status='PASS',exact_checks=sum(COUNTS.values()),check_counts=dict(COUNTS),cases=rows,scope='Exact certificates for frozen finite receiver quadrature and complete positive-volume real cube source cells. Nested lower sources obey inequalities, not all matching. No general root or native hard-branch claim.')
 (BASE/'r373_verified.json').write_text(json.dumps(out,sort_keys=True,indent=2)+'\n');print(json.dumps({**out,'cases':[{k:v for k,v in c.items() if k not in ['signed','nested','nested_deficits']}|{'signed':c['signed']['upper'],'nested':c['nested']['upper']} for c in rows]},sort_keys=True,indent=2))
if __name__=='__main__':prepare() if len(sys.argv)>1 and sys.argv[1]=='prepare' else verify()
