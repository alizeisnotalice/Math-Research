# R373 — Exact screening of source Gibbs transport and last-radius prices

**Bounded outcome.** No new general bound for G or G_joint was obtained. Two precise mechanisms were screened. The full-matching Gibbs operator is exactly reversible, but its action on the uniform reference relevant to geometric templates is explicitly source weighted. Independently, the entire class of one-center last-radius enlargement prices has an exact optimum that gives no improvement for an interior source load. These results locate the missing cross-center estimate; they are not additional ledger payments or a counterexample campaign.

## 1. Frozen target and candidate to be screened

Keep the R371 input, actual Lebesgue receivers E, full f, m_u=q_uR_u^n, μ(du)=du/m_u, original J, strict past and complete clock. The original pre-floor remainder has the exact form
\[
 G=\int f(y)L(y)\,dy,\qquad
 L(y)=\int_E\frac{dv}{m_v}c_v(y)F_v(y),
\]
with F_v and all its sourcewise marks as in R370. The current R371 remaining G_joint has the additional exact factors (1-p_uv)(f-q_v)_+. Nothing below replaces these factors, sets their gates independent of y, or adds credit to the R371 joint-floor fee.

The first candidate was to use a genuine full-matching source transport to transfer R370's geometric template control to L. The required type of transfer would have to compare integration against the uniform capture reference with its transported measure. Section 2 computes this comparison exactly, rather than assuming invariance.

## 2. Full-matching source Gibbs operator: exact formulas

For any fixed actual receiver subfamily D⊂E of finite measure, put
\[
 \rho(y)=\int_D\frac{c_u(y)}{m_u}\,du,\qquad
 \kappa(y)=\int_D\frac{c_u(y)}{q_um_u}\,du,\qquad \Omega=\{\rho>0\}.
\]
In particular D may equal E_r, so ρ=J_r. Let
\[
 \pi_u(dz)=\frac{f(z)c_u(z)}{m_u}\,dz,\qquad
 P\phi(y)=\frac1{\rho(y)}
   \int_D\frac{c_u(y)}{m_u}\left(\int\phi\,d\pi_u\right)du
 \quad(y\in\Omega).
\]
All these are the actual full-f measures. P1=1 on Ω. Define two finite source measures
\[
 d\nu=f\rho\,dy,\qquad d\zeta=\rho\,dy.
\]
Their masses are ν(Ω)=|D| and ζ(Ω)=∫D du/q_u. Neither measure is m du.

The transition measure is symmetric:
\[
 \nu(dy)P(y,dz)=
 f(y)f(z)\left[\int_D\frac{c_u(y)c_u(z)}{m_u^2}du\right]dy\,dz. \tag{1}
\]
Thus P is ν-reversible and ν-stationary. For bounded real φ, direct expansion gives the genuine capture-square identity
\[
 \langle\phi,P\phi\rangle_\nu
 =\int_D\left(\int\phi\,d\pi_u\right)^2du,\qquad
 \langle\phi,(I-P)\phi\rangle_\nu
 =\int_D\operatorname{Var}_{\pi_u}(\phi)\,du. \tag{2}
\]
These are identities, not a separately spendable negative square in the original objective.

The UNIFORM reference has a different, equally exact evolution:
\[
 \int_\Omega P\phi\,d\zeta=\int_\Omega f(z)\kappa(z)\phi(z)\,dz,
 \qquad
 \frac{d(\zeta P)}{d\zeta}(z)
 = f(z)\frac{\kappa(z)}{\rho(z)}. \tag{3}
\]
To verify this, first integrate c_u(y) over y; its integral is R_u^n=m_u/q_u. Then apply Tonelli. In particular
\[
 \frac{f(z)}{\lambda}\le
 \frac{d(\zeta P)}{d\zeta}(z)\le\frac{f(z)}{q_-}. \tag{4}
\]
If all actual q_u=λ, the derivative is exactly f/λ.

Consequently the inequality
\[
 \int P\phi\,d\zeta\le C\int\phi\,d\zeta
 \quad\hbox{for every nonnegative measurable }\phi \tag{5}
\]
holds if and only if fκ/ρ≤C almost everywhere. In particular (5) implies f≤λC on Ω, and f≤q_-C is sufficient. This proves that an unrestricted uniform-reference transport argument would import a source-density cap. The R370 geometric theorem is source free and provides no such cap. It therefore cannot be transported by this route with a claimed universal operator constant.

This conclusion is deliberately limited: it does NOT rule out an inequality for the special actual target. If tests are restricted to a completed frozen source-observable σ-field ℱ containing ρ, κ and the actual target weights, the correct comparison density is
\[
 \mathbb E_\zeta[f\kappa/\rho\mid\mathcal F]
 =\frac{\kappa}{\rho}\,\mathbb E_\zeta[f\mid\mathcal F]. \tag{6}
\]
Here g=Eζ[f|ℱ] is exactly R371's lawful normalization, because ρ is observable. Large within-cell peaks can disappear in (6); they are not a valid obstruction to the actual target. What remains needed is a quantitative bound for this observable inter-cell density, or a special signed target inequality bypassing it. Neither is proved by reversibility or (2).

For the original G one can take φ=L/ρ on Ω, obtaining the exact conservation ∫νPφ=G. This changes neither the mean nor the source dependence of the target. No conclusion relating that conserved mean to Γ_n follows from conservation alone. Treating (2) as a new negative credit would require a proved identity embedding it in the original objective, which is absent.

## 3. Last-radius strengthening is a different admissible contract

For a general weak-type entrance one may instead select, at a point of the strict λ-superlevel set,
\[
 R(x)=\sup\{s>0:s^{-n}f(Q_x(s))>\lambda\}.
\]
For integrable f this is positive and finite; continuity in s>0 gives
\[
 f(Q_x(R(x)))=\lambda R(x)^n,\qquad
 f(Q_x(t))\le\lambda t^n\quad(t\ge R(x)). \tag{7}
\]
Measurability follows by testing rational s>t in {R>t}. Thus the enlargement constraints are genuine, and imply the full-source shell bound
\[
 f(Q_x(t)\setminus Q_x(R(x)))\le\lambda(t^n-R(x)^n).
\]
They are not constraints of the frozen arbitrary R371 selector. Applying them to that problem would require rebuilding its entrance and all downstream selections, or proving a direct new weak-type route. No such transfer is asserted here.

The relevant screening result is not merely (7), but the sharp price calculation in the next section.

## 4. Exact optimality of all one-center enlargement prices

Fix one center v with base side R and actual base mass m=λR^n, satisfying all (7). Let H≥0 be a bounded measurable load supported in Q_v(R), with h=ess sup H on that cube. Permit an arbitrary signed price α for the base equality, and any finite nonnegative measure β on [R,∞) for the upper enlargement constraints, with ∫t^n β(dt)<∞. The proposed source cover is
\[
 H(y)\le \alpha\,1_{Q_v(R)}(y)
       +\int_{[R,\infty)}1_{Q_v(t)}(y)\,\beta(dt). \tag{8}
\]
Its legal full-source cost is
\[
 \alpha m+\lambda\int t^n\beta(dt).
\]
Every enlarged cube covers the entire base cube. Therefore (8) forces α+β([R,∞))≥h, and consequently
\[
 \alpha m+\lambda\int t^n\beta(dt)
 \ge mh+\lambda\int(t^n-R^n)\beta(dt)\ge mh. \tag{9}
\]
The base-only choice α=h, β=0 attains mh. Thus the optimum of this entire price class is exactly
\[
 \boxed{m\,\operatorname*{ess\,sup}_{Q_v(R)} H.} \tag{10}
\]
Allowing α to be negative cannot improve it.

This is also the exact optimum of the corresponding one-center source relaxation: sources of total mass m supported on a set where H>h−δ satisfy all enlargement constraints and approach mh. This is a statement about that relaxation only; these sources need not preserve other centers' matching equations. It is not a counterexample to simultaneous all-center constraints.

Apply the screening to H=c_vF_v (or any actual residual source load supported in Q_v). It shows that applying last-radius inequalities separately at each small endpoint and then integrating in v gives only the already trivial bound by its worst interior load. Thus a successful last-radius argument must use constraints centered elsewhere, which separate different parts of Q_v and whose overlaps are priced jointly. Merely admitting arbitrarily many positive radii at the same center does not supply that separation.

The same point explains why the raw outer-shell bound does not automatically help outside pairs: a cube centered at a different receiver can reach well into a costly enlarged radius, and its signed subtraction must be checked on the full source space. There is no volume-times-density substitution here.

## 5. Exact outstanding estimate and ledger status

The two screened mechanisms leave a specific common issue:

- Source Gibbs mixing does provide a true reversible matching structure, but on the reference measure used for source-free geometry its exact derivative is (3), or the observable conditional version (6). Reversibility does not bound that derivative on the actual target.
- Last-radius selection gives a rich family of genuine inequalities, but all one-center interior prices collapse exactly to (10). Any improvement must exploit simultaneous different-center constraints. It cannot be obtained by optimizing one small endpoint at a time.

No estimate with a smaller general coefficient of X_q, no root-order source receipt, and no controlled replacement kernel for G_joint has been established in this bounded investigation. The R371 ledger remains unchanged. The negative square, R370 template, R369 geometry and R338 fees have not been resold.

## 6. Actual reproducible local verification

The code below was actually run with local Python Fraction arithmetic. Its two actual finite interval fixtures and matching sources are the R371 files; their receiver measure is quadrature and their gates are diagnostic, so they are not native high-dimensional hard-branch evidence. The checks verify the mathematical identities (1)–(3) and (9), not a general bound. No new fixture search was run.

Output:
grid15_equal rho_cells 16 uniform_reference_norm 2
grid15_weighted rho_cells 16 uniform_reference_norm 2
PASS {'markov_rows': 32, 'detailed_balance': 512, 'pushforward': 32, 'dirichlet': 10, 'radial_prices': 70}

~~~python
from fractions import Fraction as F
from pathlib import Path
import json
ins=json.loads(Path('/tmp/r371_lp_input.json').read_text())['cases']
outs=json.loads(Path('/tmp/r371_lp_output.json').read_text())['cases']
rows=balance=push=energy=0
for data,out in zip(ins[-2:],outs[-2:]):
 A=data['A'][:-1];m=list(map(F,data['b_exact'][:-1]))
 w=[F(z['quadrature']) for z in data['receivers']]
 V=[F(z['R']) for z in data['receivers']]
 cells=[(F(a),F(b)) for a,b in data['source_cells']]
 vol=[b-a for a,b in cells]
 x=[F(str(v)).limit_denominator(10**9) for v in out['x']]
 assert all(sum(F(a)*v for a,v in zip(row,x))==mi for row,mi in zip(A,m))
 rho=[sum(w[u]*A[u][i]/m[u] for u in range(len(m))) for i in range(len(x))]
 kap=[sum(w[u]*A[u][i]*V[u]/m[u]**2 for u in range(len(m))) for i in range(len(x))]
 ids=[i for i in range(len(x)) if rho[i]]
 P={(i,j):sum(w[u]*A[u][i]*A[u][j]*x[j]/m[u]**2 for u in range(len(m)))/rho[i] for i in ids for j in ids}
 nu={i:rho[i]*x[i] for i in ids};zeta={i:rho[i]*vol[i] for i in ids}
 for i in ids:
  assert sum(P[i,j] for j in ids)==1;rows+=1
  for j in ids:
   assert nu[i]*P[i,j]==nu[j]*P[j,i];balance+=1
 for j in ids:
  assert sum(nu[i]*P[i,j] for i in ids)==nu[j]
  assert sum(zeta[i]*P[i,j] for i in ids)==x[j]*kap[j]
  assert kap[j]==rho[j]  # all q=1 in these two actual finite fixtures
  push+=1
 assert sum(nu.values())==sum(w)
 for pattern in range(5):
  phi=[F((i*(pattern+1)+3)%11,7) for i in range(len(x))]
  lhs=sum(nu[i]*P[i,j]*(phi[i]-phi[j])**2 for i in ids for j in ids)/2
  rhs=F(0)
  for u in range(len(m)):
   mean=sum(F(A[u][i])*x[i]*phi[i] for i in range(len(x)))/m[u]
   second=sum(F(A[u][i])*x[i]*phi[i]**2 for i in range(len(x)))/m[u]
   rhs+=w[u]*(second-mean**2)
  assert lhs==rhs;energy+=1
 print(data['name'],'rho_cells',len(ids),'uniform_reference_norm',max(x[i]*kap[i]/zeta[i] for i in ids))
radial=0
for n in range(1,6):
 for R in [F(1),F(3,2)]:
  lam=F(7,5);m=lam*R**n
  for pat in range(1,8):
   H=F(pat,3)
   ts=[R*(1+F(j,8)) for j in range(1,5)]
   beta=[F((j*pat)%5,9) for j in range(1,5)]
   alpha=H-sum(beta)
   cost=alpha*m+sum(b*lam*t**n for b,t in zip(beta,ts))
   excess=sum(b*lam*(t**n-R**n) for b,t in zip(beta,ts))
   assert alpha+sum(beta)==H
   assert cost==m*H+excess>=m*H
   radial+=1
print('PASS',dict(markov_rows=rows,detailed_balance=balance,pushforward=push,dirichlet=energy,radial_prices=radial))
~~~
