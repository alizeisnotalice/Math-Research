"""Reproduce the finite and scalar checks of round 745. No PDF or network."""
from fractions import Fraction as F
from collections import Counter
import json
import platform
import sys

import flint
from flint import arb, ctx

ctx.prec = 256


def greedy_pilot(multiplier):
    # Actual one-dimensional interval owners. The first two are donors.
    a = 32
    cells = [(F(-1) + F(i, 16), F(-1) + F(i + 1, 16)) for i in range(32)]
    parents = [(F(-2), F(2)), (F(-3, 2), F(3, 2))]
    reserved = [(F(-1, 16), F(0)), (F(0), F(1, 32))]
    volumes = [r - l for l, r in reserved]
    for left, right in cells:
        center = (left + right) / 2
        parents.append((center - 1, center + 1))
        volumes.append(right - left - sum(max(F(0), min(right, r) - max(left, l))
                                           for l, r in reserved))
    assert all(l >= p / a and r <= q / a
               for (l, r), (p, q) in zip(reserved, parents))
    assert sum(volumes) == 2
    ends = sorted({b for pair in parents for b in pair})
    atoms = [(l + r) / 2 for l, r in zip(ends, ends[1:])]
    contained = [[j for j, z in enumerate(atoms) if l < z < r] for l, r in parents]
    slack = [F(1) for z in atoms]
    active = {i for i, v in enumerate(volumes) if v > 0}
    d = [r - l for l, r in parents]
    order, received, theta = [], {}, {}
    while active:
        cur = {i: min(slack[j] for j in contained[i]) for i in active}
        i = max(active, key=lambda k: (d[k] * cur[k], -k))
        exponent = volumes[i] * 192 * multiplier / d[i]
        assert exponent.denominator == 1
        received[i] = cur[i]
        theta[i] = cur[i] * (1 - F(1, 2 ** int(exponent)))
        for j in contained[i]:
            slack[j] -= theta[i]
        order.append(i)
        active.remove(i)
    assert min(slack) >= 0 and order[:2] == [0, 1]
    donor_slack = 1 - theta[0] - theta[1]
    assert donor_slack == F(1, 2 ** (5 * multiplier))
    assert all(received[i] <= donor_slack for i in order[2:])
    assert max(sum(i >= 2 for i, mask in enumerate(contained) if j in mask)
               for j in range(len(atoms))) <= a
    bill = sum(theta[i] * d[i] for i in order)
    bad = sum(volumes[i] for i in order if received[i] <= F(1, 2))
    return dict(multiplier=multiplier, owners_with_positive_volume=len(order),
                donor_slack=str(donor_slack), V="2", bad_volume=str(bad),
                feasible_packing="2", greedy_D_display=float(bill),
                greedy_D_times_1000_floor=(1000*bill).__floor__())


def max_shell_checks():
    checks, aligned, min_ratio = 0, 0, F(1)
    for N in (3, 8, 17):
        step = F(1, 10*N)
        for ell in (1, (N+1)//2, N):
            s = F(21, 20) + step*ell
            for g in (7, 41, 90):
                for offset in (F(0), F(1, 3)):
                    u = s / (2 * (g + offset))
                    last = (s / (2*u)).__ceil__() - 1
                    # Centers on the boundary are excluded by the open test.
                    cap = min(s, (2*last+1)*u)
                    for m in (1, 3, 16, 64):
                        exact = (cap/s)**m - (min(s-step, cap)/s)**m
                        continuous = 1 - ((s-step)/s)**m
                        assert exact <= continuous
                        assert exact >= continuous - m*u/s
                        checks += 1
                        if offset == 0:
                            aligned += 1
                        min_ratio = min(min_ratio, exact/continuous)
    return dict(checks=checks, boundary_aligned=aligned,
                minimum_ratio=float(min_ratio))


def receiver_and_packing_checks():
    endpoint_checks = 0
    packing_checks = 0
    for n in (2, 8, 16, 64, 256):
        a = 32*n
        for radius in (1, 2):
            # Coordinates below are in units of 1/a.
            centers = range(-radius*a+1, radius*a, 2)
            edges = Counter()
            for y in centers:
                for x in (y-1, y, y+1):
                    w = F(0) if radius == 1 else F(x, 2)
                    assert abs(w-y) <= a
                    if x == y:
                        assert abs(w-y) < a
                    endpoint_checks += 1
                edges[y-a] += 1
                edges[y+a] -= 1
            active = 0
            for edge in sorted(edges):
                active += edges[edge]
                assert 0 <= active <= a
                packing_checks += 1
            assert active == 0
    return dict(endpoints_and_centers=endpoint_checks, packing_intervals=packing_checks)


def ab(x):
    return arb(x.numerator) / arb(x.denominator) if isinstance(x, F) else arb(x)


def txt(x):
    return x.str(10)


def scalars(e, c):
    # n=2^(3e) gives an exact integer N=n^(2/3).
    n = 2 ** (3*e)
    m = n//16
    d = n-m
    N = 2 ** (2*e)
    t = ab(c)*ab(n).sqrt()
    delta = ab(F(1, 10*N))
    hi = ab(F(23, 20))
    # exp(-m*step/s+) is a certified upper bound on the head miss.
    head = (-ab(m)*delta/hi).exp()
    tail = (-2*ab(d)*ab(F(43, 1200))**2/ab(F(43, 20))**4).exp()
    unit = (-ab(n)*ab(2).log()).exp()
    sphere = ab(F(91, 100))*(2*arb.pi()*ab(1).exp()).sqrt()/4
    vol = (ab(m)*ab(F(29,25)).log()+ab(d)*sphere.log()).exp()
    priority = ab(n)*(delta/hi).log1p() - ab(2*N)/t
    receiver_priority = ab(n)*ab(F(21,20)).log() - ab(2*N)/t
    order = bool(priority > 0 and receiver_priority > 0)
    # Conditional on the checked order, this bounds t^2 D / |X|.
    bill = t*(head+tail+3*unit+2/t+(-ab(N)/t).exp()+vol)
    return dict(n_power_of_two=3*e, c=c, log_priority_margin=txt(priority),
                priority_certified=order, head_log_upper=txt(-ab(m)*delta/hi),
                log_volume_upper_over_n=txt(ab(m)/n*ab(F(29,25)).log()+ab(d)/n*sphere.log()),
                conditional_t_squared_D_over_volume_upper=txt(bill),
                bound_below_three_certified=bool(order and bill < 3))


def main():
    assert F(81,100)-(1+F(23,20)**2)/3 == F(43,1200)
    assert (F(91,100)**2 * 2 * F(22,7) * F(11,4) / 16) < F(9,10)
    results = dict(
        runtime=dict(executable=sys.executable, python=platform.python_version(),
                     python_flint=flint.__version__, arb_precision_bits=ctx.prec),
        pilots=[greedy_pilot(m) for m in (1,2,4)],
        singular_witness=max_shell_checks(),
        receiver_geometry=receiver_and_packing_checks(),
        scalar_bounds=[scalars(e,c) for e in (4,8,16,32,48,64) for c in (1, 524288)],
    )
    assert sum(x['bound_below_three_certified'] for x in results['scalar_bounds']) > 0
    print(json.dumps(results, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
