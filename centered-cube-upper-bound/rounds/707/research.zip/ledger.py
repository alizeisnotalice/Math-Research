"""Monte Carlo on the R707 truncated true common-anchor shell. Natural logs."""
import json,math,os,random,socket,sys
from multiprocessing import get_context

def trial(job):
    b,alpha,seed=job
    n=2**b;a=32*n;t=math.sqrt(n);L=math.log(n);k=int(.4*b)
    radius=n/(alpha*L);step=math.log1p(-2/a)
    w=-math.expm1(n*step);thin=math.ldexp(w,-k)
    j=math.floor(t*math.log(2)/thin)
    residual=t*math.log(2)-j*thin
    assert thin*1e-12<residual<thin*(1-1e-12)
    rng=random.Random(701532+b*10**6+int(alpha*100)*100+seed)
    ell=int(-t*math.log1p(rng.random()*math.expm1(-j*thin/t))/thin)
    s=radius*math.exp(ell*step)
    first=min(n-1,int(math.log1p(-w*rng.random())/step))
    edge=(a-1)*rng.randrange(2);obs=[[],[]]
    for axis in range(n):
        digit=(rng.randrange(1,a-1) if axis<first else edge if axis==first else rng.randrange(a))
        if axis<k: digit=max(digit,a-1-digit)
        y=s*((2*digit+1)/a-1); half=(1+6/n)*s
        for row,x in enumerate((rng.uniform(-1,1),(1-2*rng.random()/a)*(1 if axis%2 else -1))):
            lo=y-half-x;hi=y+half-x
            if lo>-1:obs[row].append((lo,0))
            if hi<1:obs[row].append((hi,1))
    def pava(marks):
        blocks=[]
        for _,v in sorted(marks):
            blocks.append((v,1))
            while len(blocks)>=2:
                p,m=blocks[-2];q,l=blocks[-1]
                if p*l<=q*m:break
                blocks[-2:]=[(p+q,m+l)]
        return -sum(v*math.log(v/m) for p,m in blocks for v in (p,m-p) if v)/L
    logr=n*step-thin/t
    source=(-math.expm1(-thin/t))*(-math.expm1(j*logr))/(-math.expm1(logr))
    source+=math.exp(j*logr)*(-math.expm1(-residual/t))
    logDV=n*math.log(radius)+math.log(source)
    # Receiver term is exactly exp(-clock/t)*(1-exp(-1/t)) in units V_T.
    logDV+=math.log1p(math.exp(-logDV)*.5*(-math.expm1(-1/t)))
    return [b,alpha,seed,pava(obs[0]),pava(obs[1]),logDV,thin/t,os.getpid()]

if __name__=='__main__':
    parity,workers=map(int,sys.argv[1:3])
    exps=tuple(map(int,sys.argv[3:])) or (10,14,18)
    jobs=[(b,a,j) for b in exps for a in (1.1,1.5,1.9) for j in range(parity,48,2)]
    with get_context('fork').Pool(workers) as pool: rows=pool.map(trial,jobs,1)
    print(json.dumps(dict(host=socket.gethostname(),python=sys.version,args=sys.argv[1:],
                          workers=len(set(r[-1] for r in rows)),rows=[r[:-1] for r in rows])))
