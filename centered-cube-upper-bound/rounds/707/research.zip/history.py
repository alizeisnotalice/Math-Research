"""R707: genuine two-parent n=16 first-hit history; exact owner integration.

Run: python3 /Volumes/data/CodexTemp/centered-cube-r707-20261118/history.py
Only history.json is written. Fractions certify the geometry, capacities and
integral; exp/log evaluation checks the specified coefficient update numerically.
"""
from fractions import Fraction as F
from pathlib import Path
import hashlib
import json
import math
import platform


def encoded(q):
    return {"exact": str(q), "decimal": float(q)}


def main():
    n = 16
    a = 32 * n
    r = F(1, a)
    h = 1 + r
    padding = 1 + F(6, n)
    s = F(1)
    d = F(2) ** n
    b = F(a) ** (-n)
    owner_volume = d * b
    # t=b/log(2), c=t/sqrt(16), so alpha=1-exp(-b/t)=1/2.
    t = float(b) / math.log(2)
    c = t / math.sqrt(n)
    alpha_numeric = -math.expm1(-float(b) / t)
    assert abs(alpha_numeric - 0.5) < 1e-15
    offset = padding + r / 2
    centers = [[offset, -offset] + [F(0)] * (n - 2), [F(0)] * n]
    # Tiny cores have radius r and are disjoint in coordinate 1.
    assert offset - r > r
    # Parents overlap on a positive-volume open box; use its center as witness.
    witness = [offset / 2, -offset / 2] + [F(0)] * (n - 2)
    for center in centers:
        assert all(abs(z - y) < s for z, y in zip(witness, center))
    overlap_lengths = [2 - abs(y0 - y1) for y0, y1 in zip(*centers)]
    assert all(length > 0 for length in overlap_lengths)
    first_hit_cell_volume = math.prod(overlap_lengths)

    # Equal-volume tie: index 0 first. The exact overlap arrangement has the
    # empty cell, either-parent cells and the positive both-parent cell.
    histories = []
    remaining = {0, 1}
    theta = [F(0), F(0)]
    residual_at_selection = [None, None]
    while remaining:
        caps = {}
        for i in remaining:
            # All earlier parent contributions meet A_i on one common open cell.
            caps[i] = 1 - sum(theta)
        chosen = max(remaining, key=lambda i: (d * caps[i], -i))
        ri = caps[chosen]
        residual_at_selection[chosen] = ri
        theta[chosen] = ri / 2
        remaining.remove(chosen)
        histories.append({
            "selected": chosen,
            "candidates": {str(i): {"r": str(caps[i]), "price": str(d * caps[i])}
                           for i in sorted(caps)},
            "theta": str(theta[chosen]),
            "max_load_after": str(sum(theta)),
        })
    assert theta == [F(1, 2), F(1, 4)]
    assert residual_at_selection == [F(1), F(1, 2)]
    assert sum(theta) <= 1
    beta = q = F(1, 2)
    bad = [j for j in range(2) if residual_at_selection[j] <= beta]
    assert bad == [1]
    assert theta[0] == q  # Genuine first hit before target 1's selection.
    D = d * sum(theta)
    V_T = owner_volume

    # The pre-fixed singleton menu is z=witness, pool={0}, u=h.
    # On the target core x in [-r,r]^n, only two J coordinates are nonfull:
    # J_1=[(r/2-x_1)/h,1], J_2=[-1,(-r/2-x_2)/h].
    # Every remaining J is all [-1,1] since h+r <= padding.
    assert h + r <= padding
    assert -1 < -r / (2 * h) < 3 * r / (2 * h) < 1
    assert max(abs(z) for z in witness) + r <= h
    # J_1 and J_2 are disjoint iff x_1-x_2<r. If disjoint, optimal
    # probabilities are (1/2,1/2), hence B=2 log 2; otherwise B=0.
    eps = F(1, 8)
    high_threshold = (0.5 - float(eps)) * math.log(n)
    loss_positive = 2 * math.log(2)
    assert loss_positive > high_threshold > 0
    cutoff = 2 * float(h) * n / math.log(n)
    assert 1 <= cutoff
    # The low-loss triangle x_1-x_2>=r has legs r in a square of side 2r.
    low_fraction = (r * r / 2) / ((2 * r) ** 2)
    high_fraction = 1 - low_fraction
    assert high_fraction == F(7, 8)
    R_high = theta[0] * high_fraction * V_T
    eta_H = F(1, 4)
    excess = max(F(0), R_high - eta_H * V_T)
    root_normalized = excess / (4 * D)  # sqrt(16)=4 exactly.
    assert R_high / V_T == F(7, 16)
    assert excess / V_T == F(3, 16)
    assert t * float(d * theta[0]) <= float(owner_volume)
    assert t * float(d * theta[1]) <= float(owner_volume)
    assert float(sum(owner_volume * ri for ri in residual_at_selection)) / (t + float(b)) <= float(D)

    # Independent directional Riemann brackets on x1,x2. Other coordinates
    # factor out exactly. Strict threshold cells crossing x1-x2=r go into
    # the uncertainty budget. Brackets control the fixed-menu integral.
    brackets = []
    for N in [8, 16, 32, 64, 128, 256]:
        always_high = possibly_high = midpoint_high = 0
        for i in range(N):
            xlo, xhi = -r + 2 * r * F(i, N), -r + 2 * r * F(i + 1, N)
            for j in range(N):
                ylo, yhi = -r + 2 * r * F(j, N), -r + 2 * r * F(j + 1, N)
                always_high += xhi - ylo < r
                possibly_high += xlo - yhi < r
                midpoint_high += (xlo + xhi - ylo - yhi) / 2 < r
        lower = theta[0] * F(always_high, N * N) * V_T
        upper = theta[0] * F(possibly_high, N * N) * V_T
        mid = theta[0] * F(midpoint_high, N * N) * V_T
        assert lower <= R_high <= upper
        brackets.append({"grid_side": N, "R_lower_over_VT": str(lower / V_T),
                         "R_upper_over_VT": str(upper / V_T),
                         "midpoint_over_VT": str(mid / V_T),
                         "direction": "lower <= exact fixed-menu integral <= upper; midpoint has no certified direction"})

    result = {
        "status": "passed genuine-history exact finite certificate",
        "python": platform.python_version(),
        "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "parameters": {"n": n, "a": a, "h": str(h), "s": str(s), "d": str(d),
                       "b": str(b), "t_definition": "b/log(2)", "t_numeric": t,
                       "c_definition": "b/(sqrt(16)*log(2))", "c_numeric": c,
                       "epsilon": str(eps), "eta_H": str(eta_H)},
        "input": {"centers": [[str(y) for y in row] for row in centers],
                  "radii": ["1", "1"], "owner_definition": "each full tiny core Q(y_i,1/a), mutually disjoint",
                  "v_each": encoded(owner_volume), "tie_rule": "smallest original label"},
        "history": histories,
        "alpha_numeric": alpha_numeric,
        "actual_bad_labels": bad,
        "menu": {"target_1": [{"point": [str(z) for z in witness], "pool": [0],
                               "first_hit_step": 1, "positive_cell_volume": str(first_hit_cell_volume)}],
                 "selection": "singleton pre-fixed before receiver integration", "u": str(h)},
        "loss_certificate": {"J1": "[(1/(2a)-x1)/h,1]", "J2": "[-1,(-1/(2a)-x2)/h]",
                             "other_J": "[-1,1]", "B": "2 log 2 if x1-x2<1/a; 0 otherwise",
                             "high_threshold": high_threshold, "positive_B": loss_positive,
                             "radius_cutoff": cutoff, "high_region_fraction": str(high_fraction),
                             "positive_measure_low_region_fraction": str(low_fraction)},
        "values": {"V_T": encoded(V_T), "D": encoded(D), "R_high": encoded(R_high),
                   "R_over_VT": str(R_high / V_T), "excess": encoded(excess),
                   "excess_over_sqrt_n_D": encoded(root_normalized)},
        "directional_quadrature": brackets,
        "scope": ["One real finite input; does not prove a dimension-uniform bound or refute one.",
                  "The specified c is extremely small but positive and fixed for this experiment; this is not evidence for a customary order-one c.",
                  "R_high is exact for the stated legal singleton menu and default u; no infimum over other displacement scales is claimed.",
                  "No sampled receiver point or fabricated pool is used for the exact integral.",
                  "All exact arithmetic assertions and a numerical exp/log check were actually executed."]
    }
    path = Path(__file__).with_name("history.json")
    path.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"status": result["status"], "output": str(path), "values": result["values"]}, indent=2))


if __name__ == "__main__":
    main()
