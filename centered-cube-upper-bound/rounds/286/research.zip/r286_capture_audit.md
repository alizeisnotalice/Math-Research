# R286 independent capture-branch audit

**PASS for the stated capture branch. No correction requested. The low-capture complement remains unpaid; this does not close the general problem.**

Only `/tmp/r286_capture_audit.md` was written. No author file, repository, Git, or PDF state was changed.

## 1. Independent statement screen, before reading the author proof

The following derivation was independently completed and sent to the parent before opening `/tmp/r286_joint_mass.md`.

Fix a physical clock xi, a near pair (y,z) with positive degrees M=M(z), N=N(y), and fixed positive capture thresholds theta_rho,theta_nu. Restrict both actual point functions to the SAME capture gate and actual receiver set E_xi:

    f=1_E 1_capture p_y/q,       g=1_E 1_capture h_z.

The original response caps and capture definitions imply heights

    f<=u=1/(theta_rho M),
    g<=v=4lambda/(theta_nu N).

The direct soft point-envelope weak constant B_point<=B and the direct hard point-envelope weak constant 1 imply weak constants A=B/q_- and C=1 for f,g, where q_-=3lambda/4. Variable q causes no issue because p_y/q<=p_y/q_-; the maximal envelopes receive no actual cap.

The general-height rearrangement bound is

    integral fg<=uv I(A/u,C/v)=I(vA,uC),
    I(x,y)=min(x,y)[2+log(max(x,y)/min(x,y))].

Thus the edge integral is at most

    I(B*16/(3theta_nu N),1/(theta_rho M))
    <=16/(3theta_nu N)+(1+log B)/(theta_rho M),

using I(Bx,y)<=x+(1+log B)y. Integrating on the original near product measure gives exactly the screened price

    16 W_rho/(3theta_nu)+(1+log B)W_nu/theta_rho.

The reciprocal-N term integrates to rho{N>0} and the reciprocal-M term to nu{M>0}. No comparison between sources, packet aggregation theorem, or geometric covering is needed.

## 2. Author and dependency bindings

The author proof was then read in full. Its checked SHA256 is

`/tmp/r286_joint_mass.md`: `1131fcd3db17c40d69b151632c005775dbf8a1c463105f3fd435ca9c5df496ec`.

Relevant previously read dependencies were hash-checked again:

- `/tmp/r285_symmetric.md`: `a632df6cfd3ca30c8e89fc27032835be998a56baee7909973310df1671746811`.
- `/tmp/r285_soft_packet.md`: `74332cdc1e1b11ff6f66437e10b0ab9ae661ad9b534254a4f2f18d455953d24c`.
- `/tmp/r285_soft_audit.md`: `fc6597d764eabfebd4602c20617f8a5311cb6dc6d31b0d9c7f35b2fc46f0a1a1`.

The direct point weak bound is the geometric rectangle-point argument of the symmetric dependency, not an application of its L1 packet theorem to a Dirac mass. Its fixed common-soft menu includes all allowed common s, all L>=a_xi, off-core response, and all shape tails. The source-independent mixture and entropy estimate give B_point<=B uniformly in the anchor and physical clock. No re-audit of the separately audited packet proof is claimed here.

## 3. Quantifiers, degrees, actual captures, and measurability

The proof applies to arbitrary finite nonnegative L1 sources, n>=1 integer, lambda>0, a>0, D>=0, and the stated original actual selectors and response caps. No positivity away from zero and no rho-to-nu domination is needed. The author takes 0<theta_rho,theta_nu<=1; the screened algebra is valid for any positive thresholds. Its concrete theta=1/log(n+2) lies in (0,1) for n>=1.

N(y) and M(z) are Borel functions obtained from the closed-ball incidence kernel. Original near product measure on N=0 is zero, since its total is integral 1_{N=0}N(y)rho(dy)=0; the reverse identity gives the same conclusion for M=0. These null sets are independent of the receiver and clock. Source masses are finite, so M and N are finite everywhere. The capture convention off p_y h_z>0 and MN>0 changes no original traffic.

The source convolution F_z is an actual positive restriction of the original soft response, hence F_z<=q(x). Likewise G_y is a positive restriction of the original hard response at the actual R(x) in [a,b], hence G_y<=4lambda. No cap is asserted for an envelope, reweighted source, or latent component. On a contributing edge h_z=R(x)^-n, so c_nu is indeed the hard mass fraction in the actual cube, between zero and one. c_rho may exceed one; the proof never assumes otherwise. At original scales bounded below by a, the actual kernels and neighborhood responses are finite, and the ratio conventions define measurable capture gates.

All point weak bounds are taken only after retaining the physical receiver qualification L,R>=a_xi. Arbitrary measurable variation of actual L,R,s and q with the receiver is dominated by those fixed envelopes. The same indicator multiplies both point functions, so their product contains the capture gate once. Further current positive masks may be dropped only in the majorant.

## 4. General-height algebra, score, clock, and ledger

Author equation (7) is the correct integral of min(u,A/t)min(v,C/t). Homogeneity makes its equation (9) agree exactly with the independent screen. All factors theta_rho,theta_nu,M,N and 4lambda/q_-=16/3 have the right positions. The two exact Tonelli marginals conserve the original source ledgers and yield the claimed separate source prices, with no kappa_xi or neighborhood-overlap factor.

The captures are defined on each original physical row using its actual selectors before xi=c_jt/b substitution. They have no auxiliary-slot dependence. The original full posterior and explicit upper-slot mask 1{R2(y,v)<=D}, together with ns<=D, therefore permit the stated original score bound before source integration and before clock change. The physical receiver set and unique j indicator are kept until their respective lower-scale and multiplicity qualifications are used. No posterior independence after substitution is inferred.

With the stated existing score integral B_D<=min(nlog2,4sqrt(nD)), the one original outside factor 2Lambda gives

    P_current,capture<=2Lambda B_D
      [16 W_rho/(3theta_nu)+(1+log B)W_nu/theta_rho].

For theta_rho=theta_nu=1/log(n+2), the coefficient in author (12) follows exactly. There is no new grid, j, physical-scale, or Lambda factor. Each outer source pair uses its original weight and source ledger once; varying D,B_D,B remain inside that original sum until a common bound is established. Neither dense-degree condition is used in the majorant, so this also validly pays the capture part of the exact R285 both-high remainder. It does not recharge the earlier disjoint paid branches.

## 5. Actual bounded diagnostic

A fresh local Python calculation was actually run using Fraction arithmetic for both reciprocal-degree identities on the finite unequal-mass near graph from R285. A positive isolated rho vertex was retained. The general-height expression was also checked in ordinary floating point for 256 combinations: B in {1,2,100,1e8}, M,N in {1e-5,.1,1,1e5}, and threshold pairs (1,1),(.1,.3),(.7,.02),(.001,.8), with lambda=1.7 and q_-=.75lambda.

Actual output:

    PASS exact reciprocal-degree identities=2 general-height price checks=256
    rho marginal=17/28 nu marginal=1
    Finite exact algebra and ordinary floating diagnostics only; no capture-coverage claim or interval certificate.

These are bounded algebra diagnostics. The analytic proof supplies the universal conclusion; the calculations establish neither a continuous original-history example nor a capture fraction.

## 6. Exact unpaid residual

Let I_dense be the exact SAME current original positive integrand after R285's disjoint low-N and low-M payments. R286 pays I_dense 1{c_rho>=theta,c_nu>=theta}. Its exact unpaid residual is

    I_dense 1{c_rho<theta}
      +I_dense 1{c_rho>=theta,c_nu<theta}.

I_dense still contains both original high-degree gates, every original source cut, near condition, actual selector, positive current mask, physical clock, unique j qualification, and full posterior with its upper-slot mask. The new split does not prove either residual term is small or absent. A source payment for those low-capture branches, or a justified transfer to already paid branches with bounded original source cost, remains necessary. No positive coverage fraction and no general root-polylog closure is asserted.

**Final receipt: PASS at the author hash above, with the precise two-term low-capture residual remaining unpaid.**

## 7. Bounded final integration review

**PASS for integration of the audited claims.** The following checkpoint files were read in full and hash-checked:

- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round286_20261017_final_checkpoint/proof.tex.txt`: `0647a2953b429056bd623d9e742e0a32405f8e368998340a62946234aaf6f3ec`.
- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round286_20261017_final_checkpoint/advice_integration.md`: `2322caf7ffe656d2e93624bfbeca1b802bedd0ff735b9d7d31e5c99aea15905e`.

They were compared against the frozen capture author hash in Section 2 and the separately audited geometry files:

- `/tmp/r286_dense.md`: `119696cd0199f082f0d2bd0dbf9c823e6fd31cfbd14959b0f1bd9460d5979353`.
- `/tmp/r286_dense_audit.md`: `77ba523de31e418f401e3bbd1b780ecbcd333ef7d8c0d78f2688217ddad54b31`.

The checkpoint reproduces the capture price with the correct orientation: 16/(3theta_nu) on W_rho, and (1+log B)/theta_rho on W_nu. The formulas for B, B_point, H and E match the audited dependencies. It retains actual response caps, physical L,R>=a_xi, common-soft ns<=D, original full posterior and explicit upper-slot R2<=D, score bound before clock substitution, unique actual j, and the single outside 2Lambda. Its reciprocal-degree expressions have the null-degree conventions justified immediately before the theorem; pairs with vanishing actual product contribute no traffic. There is no new source comparison, source replication, or normalized-channel claim.

The geometric paragraph agrees with the separate geometry audit: anchor measure rho/(4lambda)+nu/q_-, radius-2r first-anchor disjoint clusters, coincidence ratio I/U, witness lower bound J=M/(4lambda)+N/q_-, and expansion gate U<=KJ. Its raw price is K kappa_2[(16/3)W_rho+(1+log B)W_nu], with kappa_2=6+8sqrt(nr/a_xi)<=6+2n^(1/4). The checkpoint explicitly says the surviving kappa_2 prevents a root budget and that this branch is NOT included in the root-paid ledger. The advice file preserves the same distinction. No geometric-gate traffic is silently removed from the exact root-level residual.

The checkpoint's exact remaining root-level residual remains the SAME I_dense times 1{c_rho<theta}, plus that SAME I_dense times 1{c_rho>=theta,c_nu<theta}. I_dense denotes the current original jointly dense remainder after the earlier disjoint low-degree payments, with its original masks retained. The checkpoint explicitly allows this residual to carry all remaining traffic and claims neither a coverage fraction nor global closure. The advice's two proposed next interfaces—pay low-capture traffic or remove the geometric kappa_2 loss—are consistent with the proved state.

This review checks mathematical integration and scope against the frozen audited files. It does not re-audit upstream results or independently establish the advice file's attachment-retrieval provenance. No further numerical run was needed: no new inequality or constant was introduced by the integration. Only this owned audit file was appended; no checkpoint, author, repository, Git, or PDF state was changed.

**Integration receipt: PASS at the checkpoint hashes above; kappa_2 geometry remains outside the root-paid ledger and the exact two-term low-capture residual remains unpaid.**
