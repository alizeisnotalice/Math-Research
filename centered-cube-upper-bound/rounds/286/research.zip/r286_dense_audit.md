# R286 independent audit — joint-density first-anchor partition

## Verdict

PASS for the stated bounded geometric branch and its explicit cost. The coefficients in `/tmp/r286_dense.md` are correct. The result costs an additional O(n^(1/4)) before the existing clock integral, and therefore does not prove a root-polylog theorem.

I screened the proposed statement and derived its probability and product coefficients independently before reading the author file. I then checked the completed author proof. No blocking mathematical defect was found. This audit writes only this temporary Markdown file; no repository, Git or PDF operations were performed.

## 1. Geometry and same-cluster probability

Fix the original source pair, lambda>0, q_-=3lambda/4 and

    mu=rho/(4lambda)+nu/q_-.

If mu is nonzero and finite, iid anchors with law mu/||mu|| define Borel clusters

    C_k=B_1(A_k,2r) minus union_{j<k}B_1(A_j,2r).

For mu-almost every source point w, mu(B_1(w,2r))>0. The probability of never hitting this ball is zero. Fubini therefore supplies one full-probability set of anchor realizations on which the clusters cover mu-almost every point. Because both rho and nu are absolutely continuous with respect to mu, the same realization gives exact source identities

    sum rho|C_k=rho,    sum nu|C_k=nu,
    sum ||rho|C_k||=W_rho,    sum ||nu|C_k||=W_nu.

The partition is sampled before the receiver or physical clock; there is no receiver-dependent allocation.

For a fixed near pair |y-z|_1<=r, let U be the mu mass of the union of their 2r balls, and I the mass of their intersection. If U>0, the earliest anchor landing in the union is distributed according to mu restricted to that union. Its landing in the intersection is equivalent to the endpoints receiving the same first-anchor label. Hence

    Pr(same cluster)=I/U.

Both B_1(z,r) and B_1(y,r) lie inside the intersection. Taking the rho part of mu from the first ball and the nu part from the second gives

    I>=M(z)/(4lambda)+N(y)/q_-=J.

These two terms are different summands of mu, so this is valid even when the witness balls overlap. On U<=KJ with J>0, the coincidence probability is at least 1/K. On the jointly dense branch J>0 automatically. More generally, near edges with either N(y)=0 or M(z)=0 have zero original rho x nu product mass by Tonelli, so null-edge conventions introduce no charge. The author's probability-to-traffic step is a direct nonnegative Tonelli inequality and preserves all original masks on its left.

## 2. Both actual caps and the exact orientation coefficient

For a fixed admissible partition realization and cluster k, set m_rho=||rho|C_k|| and m_nu=||nu|C_k||. Each source restriction is positive L1, supported in the closed ball B_1(A_k,2r). Let F_k,H_k be their actual selected soft and hard responses. On the original receiver set E_xi, positivity and the actual full caps give

    F_k/q<=1,    H_k/(4lambda)<=1.

Only these actual functions receive height caps. The packet envelopes give weak constants

    A=kappa_2 B m_rho/q_-,
    C=kappa_2 m_nu/(4lambda).

Writing I_0 for the capped weak-product function, its homogeneity gives exactly

    integral_E (F_k/q) H_k
       <=4lambda I_0(A,C)
       =kappa_2 I_0((4lambda/q_-)B m_rho,m_nu)
       =kappa_2 I_0((16/3)B m_rho,m_nu).

Thus the amplification inequality applied with u=(16/3)m_rho and v=m_nu yields

    integral_E (F_k/q) H_k
       <=kappa_2[(16/3)m_rho+(1+log B)m_nu].

The author's orientation is correct: the 16/3 multiplies the rho source term, while the logarithmic B factor multiplies the nu source term. Both weak constants have the SAME kappa_2, so homogeneity removes it from the logarithm. There is no extra log kappa_2, no kappa_2 squared, and no additional 16/3 on the nu term.

Summing these already integrated bounds uses the exact disjoint mass sums. It does not sum packet weak norms as if they were L1 norms. A zero source mass gives a zero product and fits the zero convention for I_0.

## 3. Clock cost, restrictions and scope

The source partition and the U<=KJ gate do not depend on the auxiliary slots. They can be retained while applying the original full posterior score bound, with its explicit upper-slot qualification, before the existing physical-clock substitution. Other original positive cuts may be dropped only in the upper majorant. The actual selector assumptions needed for each packet response are precisely the ones stated in the author file: common actual s(x),L(x),R(x) for the fixed original row, ns<=D, and L,R>=a_xi.

The proved raw source price is therefore

    K kappa_2(xi)[(16/3)W_rho+(1+log B)W_nu].

The outside 2Lambda and the existing score integral each occur once. Since

    kappa_2(xi)=6+8sqrt(nr/a_xi)
               <=6+2n^(1/4),

at r=a/(16sqrt(n)), the author's displayed full price follows. For fixed K and D=O(log n), it is O(n^(3/4) polylog n). The author explicitly retains that limitation.

The residual gate U>KJ is exact for this additional split of the current dense integrand. The proof does not assert that the original joint-density lower bounds control local expansion, nor that G_K captures positive traffic. Those are correctly left outside the result.

## 4. Actual computational diagnostics

A local Python run used nonuniform rational rho,nu on finite one-dimensional source sets. For all seven contributing near pairs it verified exactly, with Fraction arithmetic, that I>=J and that twelve first-hit terms plus the exact geometric tail equal I/U. It also checked the kappa substitution at six dimensions. Output:

    PASS exact near-pair intersection / first-hit identities=7
    PASS geometric kappa substitutions=6

These are local algebra and geometry diagnostics. The analytic proof above establishes the measure-theoretic statement; the finite checks are not evidence for a uniform small K or a root theorem.
