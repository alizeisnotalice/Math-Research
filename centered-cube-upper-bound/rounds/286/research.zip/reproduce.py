from pathlib import Path
import hashlib,json,subprocess,sys
p=Path(__file__).resolve().parent
for name,h in json.loads((p/'manifest.json').read_text()).items():
 assert hashlib.sha256((p/name).read_bytes()).hexdigest()==h,name
before=(p/'r286_checks.json').read_bytes()
for name in ['r286_checks.py','r286_partition_checks.py']:
 subprocess.run([sys.executable,str(p/name)],check=True)
assert (p/'r286_checks.json').read_bytes()==before,'numerical JSON mismatch'
print('ALL PASS; stored JSON reproduced byte-identically')
