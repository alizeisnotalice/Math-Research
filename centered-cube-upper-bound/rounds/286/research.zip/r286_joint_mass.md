# R286 — pay the common-neighborhood capture branch by two actual caps

## Bounded deliverable

For the SAME original source pair and actual selectors, a branch on which both local neighborhoods have adequate actual capture has a source-paid bound with only a logarithm of the full-soft point constant. The proof is an edgewise capped weak-product argument followed by two exact reciprocal-degree marginal identities. It uses no source covering, no new packet overlap price, and no comparison between rho and nu.

Retain every original qualification of `/tmp/r285_joint.md` and `/tmp/r285_symmetric.md`: positive finite L1 sources rho,nu, near radius r=a/(16 sqrt(n)), q_-=3lambda/4<=q(x)<=lambda, original full-soft response <=q(x), original hard maximal response <=4lambda on [a,b], ns<=D, and actual physical L,R>=a_xi=max(a,b xi/gamma). Let B>=1 be the full-soft constant in `/tmp/r285_soft_packet.md`. All current positive masks and the original full auxiliary posterior remain in force.

Write p_y(x)=P_{s(x),L(x)}(x-y), h_z(x)=h_{R(x)}(x-z), and

    N(y)=nu(B_1(y,r)),             M(z)=rho(B_1(z,r)),
    F_z(x)=integral_{B_1(z,r)} p_w(x) rho(dw),
    G_y(x)=integral_{B_1(y,r)} h_v(x) nu(dv).

On a contributing near edge, where p_y h_z>0 and M(z)N(y)>0, define the ACTUAL relative captures

    c_rho(x,y,z)=F_z(x)/(M(z)p_y(x)),
    c_nu(x,y,z)=G_y(x)/(N(y)h_z(x)).                     (1)

Because h_z=R(x)^(-n) on such an edge, c_nu is precisely

    nu(B_1(y,r) intersect Q_{R(x)}(x))/N(y),

hence lies in [0,1]. The soft relative capture c_rho may exceed one; no upper bound on it is needed. Set both captures to zero off the contributing positive domain; that convention changes no traffic. The zero-N or zero-M near edges have zero original rho x nu product mass, by Tonelli.

For any 0<theta_rho,theta_nu<=1 let C be the original-integrand gate

    C=1{c_rho>=theta_rho, c_nu>=theta_nu}.                (2)

For every physical xi, the raw receiver traffic on this gate satisfies

    T_C(xi)
      =integral_{E_xi} dx integral_{|y-z|_1<=r}
             [p_y(x)/q(x)] h_z(x) C rho(dy)nu(dz)
      <= (16/(3 theta_nu)) W_rho
           + ((1+log B)/theta_rho) W_nu.                (3)

The same bound holds after retaining any current unpaid positive masks. In particular it applies to the R285 jointly dense remainder, with its exact original conditions

    N(y)>q_- a_xi^n/kappa_xi,
    M(z)>4lambda a_xi^n/kappa_xi.

Neither density condition is needed for the proof of (3), so discarding them only in its majorant is legitimate.

## 1. Direct soft POINT weak bound

Use the direct point-envelope statement proved in `/tmp/r285_symmetric.md`, section 1. This does NOT apply an L1 packet theorem to a delta. For each fixed rectangle shape, the nested scaling point envelope has weak-L1 constant <=1. The source-independent soft menu, rounded shape law and countable weak-sum estimate therefore give

    ||sup_{ns<=D,L>=a_xi} P_{s,L}(.-y)||_(1,infty)
       <=B_point<=B,                                  (4)

where

    B_point=e^2 M_menu[3+2log 2+2log M_menu+2H_*],
    M_menu=min(n,floor(D)+1).

This direct bound includes all soft off-core response and all allowed L. The actual hard point envelope over R>=a_xi has weak-L1 constant <=1. Consequently, for each fixed original edge (y,z), any receiver restriction of the actual functions p_y/q and h_z has weak constants at most

    A=B/q_-,                  C_hard=1.                 (5)

No actual response cap is assigned to either maximal envelope.

## 2. Both actual caps give edgewise heights

Positivity and the ORIGINAL full responses give on E_xi

    F_z(x)<=q(x),              G_y(x)<=4lambda.

On the gate (2), equations (1) therefore imply

    p_y(x)/q(x)<=u=1/(theta_rho M(z)),
    h_z(x)<=v=4lambda/(theta_nu N(y)).                   (6)

These are heights of the gated ACTUAL point functions, derived from actual captured responses. They are not caps on a reweighted source or a latent kernel component. Define both point functions with the same gate C and E_xi; their product then equals the gated integrand because C is an indicator. Further original positive masks can be dropped in the upper estimate.

## 3. General-height capped weak product

For nonnegative f,g of heights u,v and weak constants A,C, respectively, rearrangement or layer cake gives

    integral f g <=u v I(A/u,C/v),
    I(x,y)=min(x,y)[2+log(max(x,y)/min(x,y))],            (7)

with the usual zero convention. This is the integral of
min(u,A/t)min(v,C/t) over t>0. The already established scalar amplification inequality is

    I(Bx,y)<=x+(1+log B)y,              B>=1.            (8)

Apply (7) with (5)-(6), then (8). For each fixed original near pair,

    integral_{E_xi} [p_y/q] h_z C dx
      <= [4lambda/(theta_rho theta_nu M(z)N(y))]
           I(B theta_rho M(z)/q_-, theta_nu N(y)/(4lambda))
      <= 4lambda/(q_- theta_nu N(y))
           +(1+log B)/(theta_rho M(z)).                 (9)

The two capture thresholds occur in separate source prices. No geometric kappa_xi factor is incurred.

Now Tonelli gives the exact reciprocal-degree identities

    integral_{|y-z|_1<=r,N(y)>0} rho(dy)nu(dz)/N(y)
      =rho{N>0}<=W_rho,
    integral_{|y-z|_1<=r,M(z)>0} rho(dy)nu(dz)/M(z)
      =nu{M>0}<=W_nu.                                  (10)

Integrating (9) and using 4lambda/q_-=16/3 proves (3). These identities conserve the two original source ledgers; neither max(N,M) normalization nor an unpaid recovery multiplier is used.

## 4. Original score, clock and explicit price

Define the captures (1) on each original row using its actual s,L,R BEFORE changing xi=c_jt/b. The new gate depends on the original receiver, source pair and physical row, and not on auxiliary slots v,u. Keep the original full Pi_t x Pi_t and explicit upper-slot qualification R2(y,v)<=D. Thus the existing score estimate can be applied before source integration, exactly as in the two R285 payments. Keep the physical receiver gate E_xi and the unique j indicator until its sum is <=1. No new posterior or selected channel is introduced.

With B_D<=min(nlog 2,4sqrt(nD)), the resulting original positive branch satisfies

    P_current,C
       <=2Lambda B_D [16 W_rho/(3theta_nu)
                      +(1+log B) W_nu/theta_rho].        (11)

For the concrete symmetric choice

    theta_rho=theta_nu=theta=1/log(n+2),

this is

    P_current,C
       <=2Lambda B_D log(n+2)
             [16 W_rho/3+(1+log B)W_nu]
       <=8Lambda sqrt(nD) log(n+2)
             [16 W_rho/3+(1+log B)W_nu].                (12)

For D=O(log(n+2)), this is sqrt(n) times a polylogarithmic source price. The outside 2Lambda occurs once; there is no new grid or physical-scale multiplicity. Apply the argument to each original outer source pair and sum its linear masses with the original weights, retaining D-dependent constants inside that sum unless a common bound is available.

## 5. Exact residual and the remaining capture bridge

Let I_dense denote the SAME current original positive integrand after the R285 sequential low-N and low-M payments, retaining every original source cut, full posterior, physical selector and positive mask. With theta=1/log(n+2), the exact disjoint split is

    I_dense
      =I_dense 1{c_rho>=theta,c_nu>=theta}
       +I_dense 1{c_rho<theta}
       +I_dense 1{c_rho>=theta,c_nu<theta}.               (13)

The first term is paid by (12). The remaining exact integrand is the sum of the last two terms. The additional bridge now required is an original-source payment for those two low-capture branches, or an original-integrand mechanism transferring them to already paid branches with an explicitly bounded source cost. No positive coverage fraction is asserted here. The result is a constructive paid branch and a precise capture-based remaining interface, rather than a replacement of the joint-density problem by a total-neighbor-mass normalization.

## 6. Actual local diagnostics and evidence boundary

A local Python calculation was actually run. It verified both reciprocal-degree identities exactly on a finite l1 incidence graph with nonuniform rational masses, including an isolated soft vertex, and 256 general-height scalar price instances spanning B in {1,2,100,1e8}, unequal capture thresholds, and neighbor masses across ten orders of magnitude. Output:

    PASS exact incidence identities=2 capped weak-product price checks=256
    rho marginal=17/28 nu marginal=1

The exact identities and analytic inequalities above prove the lemma. The finite diagnostics are algebra checks, not a continuous-history model, numerical proof of a capture fraction, or interval certificate. Only this temporary Markdown deliverable was written; no repository, Git, or PDF operation was performed.
