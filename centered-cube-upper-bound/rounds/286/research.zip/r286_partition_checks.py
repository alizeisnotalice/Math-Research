from fractions import Fraction as Q
from itertools import permutations
from math import sqrt

def check(name, xs, rw, nw):
    X=list(map(Q,xs));m=len(X);r=Q(1,4)
    rho=[Q(50*k) for k in rw];nu=[Q(50*k) for k in nw]
    mu=[rho[i]/4+nu[i]/Q(3,4) for i in range(m)];W=sum(mu)
    near=[(i,j) for i in range(m) for j in range(m) if abs(X[i]-X[j])<=r]
    hit=[[abs(X[w]-X[k])<=2*r for k in range(m)] for w in range(m)]
    same={e:Q(0) for e in near};psum=Q(0);count=0
    for order in permutations(range(m)):
        p=Q(1);left=W
        for k in order:p*=mu[k]/left;left-=mu[k]
        psum+=p
        labels=[next(k for k in order if hit[w][k]) for w in range(m)]
        cells=[[i for i in range(m) if labels[i]==k] for k in range(m)]
        assert sum(sum(rho[i] for i in c) for c in cells)==sum(rho)
        assert sum(sum(nu[i] for i in c) for c in cells)==sum(nu)
        assert all(abs(X[i]-X[k])<=2*r for k,c in enumerate(cells) for i in c)
        for e in near:
            if labels[e[0]]==labels[e[1]]:same[e]+=p
        count+=1
    assert psum==1
    ratios=[];dense=0;n=2;a=16*float(r)*sqrt(n);kap=6+4*sqrt(2*n*float(r)/a)
    for i,j in near:
        U=sum(mu[k] for k in range(m) if hit[i][k] or hit[j][k])
        I=sum(mu[k] for k in range(m) if hit[i][k] and hit[j][k])
        N=sum(nu[k] for k in range(m) if abs(X[i]-X[k])<=r)
        M=sum(rho[k] for k in range(m) if abs(X[j]-X[k])<=r)
        J=M/4+N/Q(3,4)
        assert I>=J>0 and same[i,j]==I/U and same[i,j]>=J/U
        ratios.append(U/J)
        dense+=float(N)>.75*a*a/kap and float(M)>4*a*a/kap
    print(dict(stage=name,status='PASS',permutations=count,near_pairs=len(near),
               total_probability=str(psum),jointly_dense_pairs=dense,max_U_over_J=str(max(ratios))))

check('simple',['0','1/8'],[1,1],[1,1])
check('unequal',['0','1/8','3/8','5/8'],[1,2,1,3],[2,1,3,1])
check('disconnected_enlarged',['0','1/8','3/8','3','25/8','27/8'],[1,2,1,3,1,1],[2,1,3,1,2,1])
print('Exact finite atomic incidence diagnostics; not an original L1 history or an asymptotic proof.')
