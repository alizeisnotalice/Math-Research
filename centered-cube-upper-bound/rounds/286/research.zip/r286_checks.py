#!/usr/bin/env python3
"""R286 deterministic finite algebra and scalar diagnostics; no continuous model."""
import json, random
from fractions import Fraction as F
import mpmath as mp

SEED=28620261017
rng=random.Random(SEED)

def frac(a):
    return F(str(a))

def near_case(n,m,spread):
    # Rational l1 incidence, with a guaranteed isolated soft vertex.
    ys=[(F(rng.randrange(-12,13),4),F(rng.randrange(-12,13),4)) for _ in range(n-1)] + [(F(100),F(100))]
    zs=[ys[0]] + [(F(rng.randrange(-12,13),4),F(rng.randrange(-12,13),4)) for _ in range(m-1)]
    r=F(rng.choice([1,2,4]),2)
    edges=[(i,j) for i,y in enumerate(ys) for j,z in enumerate(zs) if sum(abs(a-b) for a,b in zip(y,z))<=r]
    rho=[F(rng.randrange(1,20),rng.randrange(1,20))*F(10)**rng.randint(-spread,spread) for _ in ys]
    nu=[F(rng.randrange(1,20),rng.randrange(1,20))*F(10)**rng.randint(-spread,spread) for _ in zs]
    N=[sum((nu[j] for ii,j in edges if ii==i),F(0)) for i in range(n)]
    M=[sum((rho[i] for i,jj in edges if jj==j),F(0)) for j in range(m)]
    left=sum((rho[i]*nu[j]/N[i] for i,j in edges),F(0))
    right=sum((rho[i] for i in range(n) if N[i]),F(0))
    left2=sum((rho[i]*nu[j]/M[j] for i,j in edges),F(0))
    right2=sum((nu[j] for j in range(m) if M[j]),F(0))
    assert left==right and left2==right2 and N[-1]==0
    return edges,rho,nu,N,M

def finite_stage(cases,spread,max_n,rows):
    out={'incidence_cases':cases,'exact_marginal_identities':2*cases,'receiver_rows':cases*rows,'contributing_edges':0,'gated_edge_rows':0,'max_marginal_error':'0','max_height_violation':'0','max_full_response_cap_violation':'0'}
    for _ in range(cases):
        n=rng.randint(3,max_n); m=rng.randint(2,max_n)
        edges,rho,nu,N,M=near_case(n,m,spread)
        out['contributing_edges']+=len(edges)
        for row in range(rows):
            lam=F(rng.randrange(1,12),rng.randrange(1,12))*F(10)**rng.randint(-spread,spread)
            q=lam*F(rng.randint(3,4),4)
            assert F(3,4)*lam<=q<=lam
            rawp=[F(rng.randrange(0,21),rng.randrange(1,21))*F(10)**rng.randint(-spread,spread) for _ in rho]
            # Hard values are a common height times a 0/1 support incidence.
            hard_support=[rng.choice([0,1,1]) for _ in nu]
            rawsum=sum((nu[j]*hard_support[j] for j in range(m)),F(0))
            hardheight=4*lam/(1+rawsum)*F(rng.randrange(1,11),10)
            h=[hardheight*t for t in hard_support]
            softsum=sum((a*b for a,b in zip(rawp,rho)),F(0))
            p=[a*q/(1+softsum)*F(3,4) for a in rawp]
            assert all(a>=0 for a in p+h)
            assert sum((a*b for a,b in zip(p,rho)),F(0))<=q
            assert sum((a*b for a,b in zip(h,nu)),F(0))<=4*lam
            tr=F(rng.choice([1,2,3,7]),rng.choice([8,10,16]))
            tn=F(rng.choice([1,2,3,7]),rng.choice([8,10,16]))
            for i,j in edges:
                if not(p[i] and h[j]): continue
                fz=sum((p[k]*rho[k] for k,jj in edges if jj==j),F(0))
                gy=sum((h[k]*nu[k] for ii,k in edges if ii==i),F(0))
                cr=fz/(M[j]*p[i]); cn=gy/(N[i]*h[j])
                assert 0<=cn<=1
                if cr>=tr and cn>=tn:
                    out['gated_edge_rows']+=1
                    assert p[i]/q<=1/(tr*M[j])
                    assert h[j]<=4*lam/(tn*N[i])
    assert out['gated_edge_rows']>0
    return out

def piecewise_integral(u,v,A,C):
    # Integrate min(u,A/t)min(v,C/t) on its three exact power-law intervals.
    a=A/u; b=C/v
    lo=min(a,b); hi=max(a,b)
    first=u*v*lo
    middle=(A*v if a<=b else C*u)*mp.log(hi/lo)
    tail=A*C/hi
    return first+middle+tail

def scalar_value(case,dps):
    B,M,N,lam,tr,tn=case
    with mp.workdps(dps):
        B,M,N,lam,tr,tn=[mp.mpf(str(v)) for v in (B,M,N,lam,tr,tn)]
        qm=3*lam/4; u=1/(tr*M); v=4*lam/(tn*N); A=B/qm; C=mp.mpf(1)
        integral=piecewise_integral(u,v,A,C)
        x=A/u; y=C/v
        formula=u*v*min(x,y)*(2+mp.log(max(x,y)/min(x,y)))
        price=4*lam/(qm*tn*N)+(1+mp.log(B))/(tr*M)
        assert integral<=price*(1+mp.mpf('1e-35'))
        err=abs(integral-formula)/max(mp.mpf(1),abs(integral))
        assert err<mp.mpf('1e-35')
        return +integral,+price,+err

def scalar_stage(count,spread,bmax):
    cases=[]
    # Include B=1 and boundary x=y, as well as unequal thresholds and extreme masses.
    for k in range(count):
        B='1' if k%8==0 else '1e'+str(rng.randint(0,bmax))
        M='1e'+str(rng.randint(-spread,spread)); N='1e'+str(rng.randint(-spread,spread))
        lam='1e'+str(rng.randint(-spread,spread))
        tr=str(F(rng.choice([1,2,7]),rng.choice([8,16,100,10000])))
        tn=str(F(rng.choice([1,3,5]),rng.choice([8,32,1000])))
        # Decimal strings avoid any binary-float input.
        with mp.workdps(90):
            tr=mp.nstr(mp.mpf(tr.split('/')[0])/mp.mpf(tr.split('/')[1]) if '/' in tr else mp.mpf(tr),85)
            tn=mp.nstr(mp.mpf(tn.split('/')[0])/mp.mpf(tn.split('/')[1]) if '/' in tn else mp.mpf(tn),85)
            if k%16==0: # A/u=C/v when B=1, using original q_-=3lambda/4.
                N=mp.nstr(16*mp.mpf(M)*mp.mpf(tr)/(3*mp.mpf(tn)),85)
        cases.append((B,M,N,lam,tr,tn))
    maxformula=mp.mpf(0); maxprecision=mp.mpf(0); maxratio=mp.mpf(0)
    for case in cases:
        a,p,e=scalar_value(case,40); b,p2,e2=scalar_value(case,60)
        with mp.workdps(80):
            pe=abs(a-b)/max(mp.mpf(1),abs(b))
            assert pe<mp.mpf('1e-35')
            maxformula=max(maxformula,e,e2); maxprecision=max(maxprecision,pe); maxratio=max(maxratio,b/p2)
    with mp.workdps(80):
        return {'cases':count,'precision_runs':2*count,'decimal_precisions':[40,60],'mass_and_lambda_decimal_exponent_range':[-spread,spread],'B_decimal_exponent_range':[0,bmax],'max_normalized_formula_error':mp.nstr(maxformula,12),'max_normalized_40_vs_60_error':mp.nstr(maxprecision,12),'max_product_to_price_ratio':mp.nstr(maxratio,12),'max_price_violation':'0'}

stages=[]
for name,cases,spread,max_n,rows,scalars,bmax in [('simple',8,1,6,3,64,4),('nonuniform_multiscale_stress',48,6,12,4,256,12),('enlarged_ranges',96,15,22,5,1024,50)]:
    stages.append({'name':name,'finite_algebra':finite_stage(cases,spread,max_n,rows),'scalar':scalar_stage(scalars,spread,bmax)})
result={'status':'PASS','seed':SEED,'scope':'Exact finite rational incidence and actual-response gated heights; analytic scalar capped weak-product integral at 40/60 decimal digits. This is not a FULL or continuous L1 history model, capture-coverage proof, or interval certificate.','stages':stages}
from pathlib import Path
with Path(__file__).with_suffix('.json').open('w') as f: json.dump(result,f,indent=2,sort_keys=True); f.write('\n')
print(json.dumps(result,indent=2,sort_keys=True))
