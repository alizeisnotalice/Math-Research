# R286 — a joint-density random-partition capacity bridge

## Precise statement (new estimate; bounded scope)

Fix one original source pair rho,nu, lambda>0, q_-=3lambda/4, a<=L,R<=b<=2a, r=a/(16sqrt(n)). Keep the actual FIRST response <=q, q_-<=q<=lambda, original hard maximal cap <=4lambda, all actual source/history cuts and masks, the unique actual j, full original Pi x Pi, upper-slot R2<=D and ns<=D. No original source or posterior is replaced.

Write

N(y)=nu(B_1(y,r)),  M(z)=rho(B_1(z,r)),
a_xi=max(a,b xi/gamma),
kappa_1(xi)=6+4sqrt(2nr/a_xi),
kappa_2(xi)=6+8sqrt(nr/a_xi).

For this fixed source pair define the finite ANCHOR measure

mu=rho/(4lambda)+nu/q_-.

This is used only to randomize a source partition. For |y-z|_1<=r set

J(y,z)=M(z)/(4lambda)+N(y)/q_-,
U(y,z)=mu(B_1(y,2r) union B_1(z,2r)).

For any K>=1, let the NEW geometric gate be

G_K(y,z)=1{U(y,z)<=K J(y,z)}.

For every current original positive jointly dense near integrand, its G_K part obeys

P_dense,G_K <= 2Lambda K [integral_middle f_D(xi) kappa_2(xi) dxi/xi]
                          [(16/3)W_rho+(1+log B)W_nu]
 <= 2Lambda K(6+2n^(1/4)) B_D
                          [(16/3)W_rho+(1+log B)W_nu].                 (A)

Here f_D=min(n,D/(1-xi)^2), B_D<=4sqrt(nD), and B is the FULL-soft packet factor from r285_soft_packet.md. At each clock the original joint-density gates are

N(y)>q_-a_xi^n/kappa_1(xi),
M(z)>4lambda a_xi^n/kappa_1(xi).

Thus J>2a_xi^n/kappa_1 on the branch, but there is NO upper bound on either density in (A). The geometric gate is scale-invariant in the two original source masses; it measures local expansion of their weighted union relative to the TWO separate witness masses. It is not a renamed traffic norm or a low-degree condition.

The source allocations below are disjoint for every realization, at every clock. There is no covering multiplicity or repeated-source charge in (A). The proof gives an independent geometric capacity criterion: sufficiently large probability that the two endpoints belong to one bounded-radius disjoint source packet. It does NOT establish G_K for every dense pair, and the factor kappa_2 remains. For fixed K and D=O(log n), (A) is O(n^(3/4) polylog n), not the sought O(sqrt(n) polylog n).

## 1. Exact random partition of BOTH original sources

If mu=0 there is no traffic. Otherwise take an iid sequence of anchors A_1,A_2,... with law mu/||mu||. For every source location w assign the index

ell(w)=min{k>=1: |w-A_k|_1<=2r}.

For mu-almost every w, mu(B_1(w,2r))>0; hence ell(w)<infinity almost surely. Fubini gives, almost surely, a full-mu-measure partition C_k={w:ell(w)=k}. The C_k are Borel and

C_k subset B_1(A_k,2r).

Define rho_k=1_{C_k}rho and nu_k=1_{C_k}nu. For every admissible partition realization,

sum_k rho_k=rho,  sum_k nu_k=nu,
sum_k ||rho_k||=W_rho,  sum_k ||nu_k||=W_nu.                 (1)

These are original positive restrictions. Sources are not copied to every anchor ball: each point is assigned to its FIRST containing anchor only. The countable random construction is a proof device and introduces no original seed/terminal averaging or new physical clock.

## 2. Joint density is a lower bound for SAME-packet probability

For a fixed near pair y,z, write

I(y,z)=mu(B_1(y,2r) intersection B_1(z,2r)).

The first anchor landing in the union assigns both points the same label precisely when it lands in the intersection. Therefore, whenever U>0,

Pr{ell(y)=ell(z)}=I/U.                                    (2)

Since |y-z|_1<=r, BOTH B_1(z,r) and B_1(y,r) lie inside that intersection. Reading the rho mass from the first ball and the nu mass from the second gives

I >= rho(B_1(z,r))/(4lambda)+nu(B_1(y,r))/q_-=J.            (3)

There is no double counting problem: the two terms are the two different summands of the measure mu. In particular G_K implies

Pr{ell(y)=ell(z)}>=1/K.                                   (4)

The exact stronger gate I/U>=1/K could also be used; G_K is its explicitly joint-density-certified subgate. Equation (4) holds pointwise in the original pair and independently of x, xi, auxiliary slots, source cuts and original masks. For a nonnegative ORIGINAL traffic density F, Tonelli consequently gives

integral F G_K <=K E_partition integral F G_K 1{ell(y)=ell(z)}
               <=K E_partition integral F 1{ell(y)=ell(z)}. (5)

This retains true receiver Lebesgue measure dx. It is not an assertion that a normalized selected channel has total mass one.

## 3. One packet pair, retaining both actual caps

Fix xi and one partition. Keep the actual receiver qualifications E_xi, including L,R>=a_xi and ns<=D. Put

F_k(x)=integral P_{s(x),L(x)}(x-y)rho_k(dy),
H_k(x)=integral h_{R(x)}(x-z)nu_k(dz).

Positivity and the ORIGINAL caps give F_k/q<=1 and H_k/(4lambda)<=1 on E_xi. No cap is assigned to either maximal envelope or to a latent soft component.

Both sources are supported in B_1(A_k,2r). The general-radius packet theorem from r285_soft_packet.md and its hard input version give valid weak-L1 constants

||1_E F_k/q||_(1,infty) <= kappa_2 B ||rho_k||/q_-,
||1_E H_k/(4lambda)||_(1,infty) <= kappa_2 ||nu_k||/(4lambda).

The capped weak-product function I_0(u,v)=min(u,v)[2+log(max(u,v)/min(u,v))], with zero convention, therefore yields

integral_E (F_k/q) H_k dx
 <=kappa_2 I_0((16/3)B||rho_k||,||nu_k||)
 <=kappa_2[(16/3)||rho_k||+(1+log B)||nu_k||].               (6)

The last step is I_0(Bu,v)<=u+(1+log B)v. Summing (6) uses EXACTLY (1), and gives

integral_E dx integral rho(dy)nu(dz)
       [P_{s,L}(x-y)/q]h_R(x-z)1{ell(y)=ell(z)}
 <=kappa_2[(16/3)W_rho+(1+log B)W_nu].                     (7)

The near gate and all other positive masks can be dropped only on the right-hand majorant. Thus (7) remains valid with every original gate retained on the left. There is no summation of weak norms as L1 norms: the product inequality is applied to each packet PAIR, and only the resulting two linear mass terms are summed.

## 4. Original score and clock accounting

Apply (5) on the actual current jointly dense traffic, retaining its G_K gate. Within each original row, first bound the full original Pi x Pi upper-slot score by f_D(xi), using the actual R2<=D gate. Same-packet membership is independent of the auxiliary slots. Then make the original physical substitution xi=c_j t/b and retain the unique actual j until its sum is at most one. On each actual E_xi, use (7).

The partition was sampled once before x or xi, and its source identities (1) hold at every clock. The outside factor remains the single original 2Lambda. Integrating (7) against f_D dxi/xi proves (A). If outer data change D, B or the source pair, prove the estimate for each original pair and keep its constants inside the original weighted sum until a valid common bound is available.

## 5. What the bridge settles and its remaining gap

This gives a new positive source payment whenever the two dense witnesses jointly control the mass of their 2r-neighborhood union. Both conditions enter the explicit lower bound (3). Arbitrarily large local source masses are allowed; multiplying rho and nu by the same constant preserves G_K. For example, if the two witness balls contain all of their respective source masses and their 2r-neighborhood union contains no additional source, J=U and K=1, irrespective of the density size.

The leftover after this additional split is exactly the previous current dense traffic times 1{U>KJ}. This is an explicit geometric expansion condition, not an unknown response budget. No uniform small K follows merely from the two lower-density inequalities. Even on G_K, the proved packet estimate costs kappa_2=O(n^(1/4)), so this bridge alone does not close the root goal. A root-level completion needs an improvement in the actual capped two-packet product (6), or a different allocation whose total geometric price is polylogarithmic; merely asserting that the random clusters have bounded overlap would be incorrect, since the actual argument uses their disjoint FIRST-anchor allocation instead.

## 6. Zero sets, measurability, and executed finite diagnostics

For clarity, the exceptional set in Section 1 is harmless for both original sources: rho<=4lambda mu and nu<=q_-mu. The set of w with mu(B_1(w,2r))=0 is mu-null because mu is a finite Borel measure on separable Euclidean space and is concentrated on its support. For every other w the failure probability after m anchors is (1-mu(B_1(w,2r))/||mu||)^m, decreasing to zero. Tonelli first over the joint anchor/source space shows that the never-assigned set has zero mu measure almost surely, then absolute continuity gives zero rho and nu measure. Thus it creates no pair traffic even before applying any receiver bound. If mu=0, both original sources vanish. If U=0, J=0 and I=0; such a pair cannot satisfy the stipulated joint-density gates.

The sets {(A,w):|w-A_k|_1<=2r} are Borel. The first-hit cells are finite Boolean combinations of these sets; ell and each common-label indicator are jointly measurable. U,I,J are Borel functions by integrating the Borel ball-incidence kernels against finite measures. Countable sums, expectations and all nonnegative receiver/source integrals therefore use Tonelli without an unproved measurable selection.

The actual local Python execution of /tmp/r286_partition_checks.py used exact Fraction arithmetic, enumerating weighted first-appearance permutations. For finite iid anchor laws, this permutation has probability product_j w_(pi_j)/(sum of weights not yet seen), so this is an exact finite probability calculation rather than Monte Carlo. Every permutation checked both source sums, cluster support, and every near-pair common-label probability. Outputs:

simple: PASS; 2 permutations; 4 near pairs; total probability 1; max U/J=1.
unequal: PASS; 24 permutations; 10 near pairs; total probability 1; max U/J=133/60.
disconnected_enlarged: PASS; 720 permutations; 14 near pairs; total probability 1; max U/J=36/19.

All 28 tested near pairs also met the two dense inequalities with n=2, r=1/4, a=4sqrt(2), lambda=1 and the displayed source weights, checked numerically. The allocation and probability equalities themselves used exact rational arithmetic. These atomic finite incidence diagnostics check the partition algebra only; they are not original L1 histories, interval certificates, or a substitute for the analytic proof.
