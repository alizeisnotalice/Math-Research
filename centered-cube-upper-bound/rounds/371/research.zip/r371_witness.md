# R371: arbitrarily high-density actual witness for both overlap-excess pieces

## 1. Exact claim and scope

For every real M≥2, the construction below is one actual finite L1 full source and a positive-volume Lebesgue receiver field in the R371 full hard contract. On the SAME original far-mass, high-past, high-J, outside-center, not-B-plus domain, both positive source factors

    p_uv (f(y)−q_v)_+   and   (1−p_uv)(f(y)−q_v)_+

have strictly positive actual terminal-clock contributions. The first is the new overlap share of the old excess complement; the second is its exact retained complement. The joint paid factor is min(f,q_v)+p_uv(f−q_v)_+, without double-counting the floor.

This proves nonemptiness at arbitrarily high source height, not a useful fraction of the full remainder, not an extremal input, and not a failure of a general upper bound. In particular it is NOT a positivity claim for a full signed integral with f−q_v: the pulse source also has a negative signed deviation between its pulses.

## 2. The actual source and its averages

Fix

    n=10000, a=1, b=2, τ=1/16,
    λ=17/16, q_-=51/64=3λ/4, ε_0=1/20,
    K=exp(100), α=101^(1/10000),
    H=h_*=(1+√n)/(ε_0 q_-)=129280/51.

For arbitrary real M≥2 let

    δ=min(10^(-6),1/(64M)),  ρ=δ/10,
    f(y)=M 1_{dist(y_1,τZ)≤1/(32M)} 1_{[-3,3]^n}(y).

The periodic first-coordinate density has pulse width τ/M and integral τ in every period. Hence its mean is exactly one. For any interval of length s wholly inside [-3,3], write s=Nτ+r, 0≤r<τ. The N consecutive full periods have mass Nτ, while the remaining interval has mass between 0 and τ. Thus

    |∫_I f_1−s|≤τ,
    15/16≤s^(-1)∫_I f_1≤17/16       whenever s≥1.

The support qualification is essential: no such lower bound is asserted for intervals outside [-3,3]. All actual cubes used below lie strictly inside the full support box. Their n-dimensional average reduces to this first-coordinate average. Moreover any interval of length 2=32τ or 5/4=20τ has average EXACTLY one, independently of its center. Since 6=96τ,

    W=∫f=6^n,

independent of M. On Y=[−δ,δ]^n, δ≤1/(64M)<1/(32M), so f(y)=M throughout Y and the positive excess relative to q_v=1 is M−1.

## 3. One real receiver field and the unchanged full prefixes

Set

    E=[−3/4+δ,3/4−δ]^n,
    R_0(w)=max(1,2||w||∞+2δ),
    U=(−1/2,0,…,0)+[−ρ,ρ]^n,
    V=(3/5,1/2,…,1/2)+[−ρ,ρ]^n.

Use the actual selector R=2 on U, R=5/4 on V, and R=R_0 elsewhere. U and V are disjoint positive-volume boxes inside E. Both overrides exceed their baseline values. Every actual cube lies inside [-3,3]^n, and every actual side is in [1,2]. The actual q is therefore in [15/16,17/16]⊂[q_-,λ], with q_u=q_v=1 on U×V. In particular

    m_u=2^n on U,   m_v=(5/4)^n on V.

Every receiver captures every y∈Y. For the baseline this follows from |w_i−y_i|≤||w||∞+δ≤R_0(w)/2. The overrides satisfy the same inequalities strictly: the worst first/other coordinates are 1/2+ρ+δ<1 on U, and 3/5+ρ+δ<5/8, 1/2+ρ+δ<5/8 on V.

All J_y(r), global strict-past gates, μ=du/m, and clock factors remain those of this entire actual pulse source and entire continuum receiver field. They are not recomputed from the probe Y×U×V.

## 4. Original strict past and physical terminal atom

Every receiver outside U has actual radius at most 3/2 and q≤17/16. The rational inequalities

    (4/3)^4>3>exp(1),  n/4=2500>101,  λ<3

give (4/3)^n>λ exp(100). Thus every non-U receiver has mass strictly less than m_u/K for each u∈U. All these receivers therefore belong to the ORIGINAL global strict past for every y∈Y.

The baseline radial integral is

    ∫_E R_0(w)^(-n)dw
      =(1−2δ)^n+n∫_1^(3/2) (r−2δ)^(n−1)r^(-n)dr
      >49n/150.

Indeed δ≤10^(-6) gives (1−2δ)^(n−1)≥1−2δ(n−1)>49/50, and log(3/2)>1/3. Removing the baseline U and V contributions loses less than 2, since R_0≥1 and each box volume is less than one. On the remaining baseline field, q≤17/16 gives μ-density at least (16/17)R_0^(-n). Consequently

    Z_y(m_u/K−) > (16/17)(49n/150−2)
                  =156704/51 >129280/51=H=h_*.

This lower bound is uniform in M≥2. At the original physical atom r=b, J_y(b)≥Z_y>H. Its weight is exactly 2^(-n)>0. The argument uses the full baseline continuum, not finitely many receiver probes.

For the upper denominator needed only in the positive lower bound below, actual q≥15/16 and R≥R_0 give

    J_y(b)≤(16/15)∫_E R_0^(-n)
            ≤(16/15)(1+n log 2)<(16/15)(1+n)=:J_max.

No small-softness restriction, new time clock, or chronological deletion-time property is being asserted.

## 5. Original exterior and B-plus-complement gates

On U×V, the first-coordinate separation is in [11/10−2ρ,11/10+2ρ], while every other separation is in [1/2−2ρ,1/2+2ρ]. The first remains maximal. Since (21/20)^100>101 and n≥100, α<21/20, while 11/10−2ρ>21/20. Hence

    2||u−v||∞>αR_u

throughout U×V. The far mass gate already holds by Section 4. Also R_v/R_u=5/8<3/4, so the former radius-ratio paid branch does not apply.

For e_i=(2|u_i−v_i|−(R_u−R_v))_+, the first excess is at least 29/20−4ρ and each other excess is at least 1/4−4ρ>0. Since ρ≤10^(-7),

    Σ_i e_i≥29/20+(n−1)/4−4n·10^(-7)
            =625299/250=2501.196.

The unchanged B-plus threshold, with β=1+1/n and w=max(a,R_v/β)=12500/10001, is

    T_plus=n[(1+β)w−R_u]^2/(4βw)
           =49985001125/100020001.

The difference between the displayed uniform excess lower bound and T_plus is greater than 2000. Thus the whole positive-volume pair box lies strictly outside B-plus, not on its equality boundary. The earlier tiny N/A excess conditions also fail. The construction does not add other historical masks that are absent from this full hard-slot contract.

## 6. Both positive overlap-excess terms survive on the same original traffic

The geometric fraction is the original

    p_uv=|Q_u∩Q_v|/R_v^n.

All coordinate overlaps are in the partial-overlap regime. Their lengths are in [21/40−2ρ,21/40+2ρ] in the first coordinate and [9/8−2ρ,9/8+2ρ] in the remaining coordinates. Therefore

    p_uv≥p_low(M):=[(21/40−2ρ)/(5/4)]
                         ·[(9/8−2ρ)/(5/4)]^(n−1)>0,
    p_uv≤(21/40+2ρ)/(5/4)<1/2.

In the upper bound, the other normalized overlap factors are at most one; no large power is numerically approximated. Thus throughout Y×U×V,

    p_uv(f−q_v)_+≥p_low(M)(M−1)>0,
    (1−p_uv)(f−q_v)_+>(M−1)/2>0.

To spell out the actual integrated conclusion, define the strictly positive terminal probe coefficient

    C_M=2^(-n)(2δ)^n(2ρ)^(2n)
          ·[2^n−(5/4)^n]/[2^n(5/4)^n J_max].

Every original source/receiver/past/physical/exterior/not-B-plus gate on this probe equals one. Hence the NEW overlap payment restricted from the old positive-excess remainder is at least

    C_M p_low(M)(M−1)>0,

and its retained positive complement is at least

    C_M(M−1)/2>0.

These are lower bounds for the corresponding FULL nonnegative integrals, obtained by retaining a positive-volume part of the actual full source. They do not replace f by a source packet, reset J, or infer positivity of a full signed f−q_v expression. The pulse source vanishes between pulses, so that signed expression has a negative part too; it supplies no free additional credit in this proof.

All factors of C_M can be extremely small. The certified geometric overlap p_low(M) is also extremely small in n=10000. No significant fraction, normalized lower bound relative to W, or general obstruction follows. In particular the positive result persists for unbounded M because δ,ρ shrink with M; it does not give a uniform positive constant in M.

## 7. Reproducible exact checks and analytic quantifiers

The self-contained standard-library script `/tmp/r371_witness_check.py` uses Fraction arithmetic and writes no additional files. It checks M=2,16,10000,10^8,2^100. It tests actual periodic interval integrals at arbitrary rational phases, exact q=1 for both selected U/V radii, the full-source period count, pulse containment, all geometric/high-past/exterior/excess margins, and positivity of the factored overlap lower bound and retained half bound. It never evaluates the huge overlap power as a floating number.

Two fresh local Python processes returned `PASS` with 725 exact assertions each: 15 common, 90 profile geometry, 550 periodic integrals, 40 old-gate checks, and 30 positive-split checks. These finite checks support the stated margins. The proof for EVERY real M≥2 is the uniform analytic period, geometry, and capacity argument in Sections 2–6, not interpolation or a fit to the five tested heights.

This note and its check script are the only authored files. The construction adapts the R370 actual hard witness, with the source and λ,q_-,ε_0,H changed consistently; it does not modify the source-split theorem or establish its general upper-bound closure.
