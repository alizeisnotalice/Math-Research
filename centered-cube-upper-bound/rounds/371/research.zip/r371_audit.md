# R371 independent audit — FINAL PASS

Status: FINAL PASS for the joint positive source receipt, the explicitly observable normalization, actual high-density witness, auxiliary identities, finite LP mapping/code and final main/ledger within their stated scopes. No unresolved correction was found. The initial independent screen below preceded author proofs; the later reviews bind final bytes. Only this audit file was edited; no author/repository file was changed. No global closure, fixed covered proportion or comprehensive historical revalidation follows.

Freeze actual full-f masses m=qR^n, positive q-band, full original J,H,global strict past and all physical-clock/exterior/notBplus masks. After the original inclusive clock integration, write

G=(1/h*) integral_E du/Ru^n integral_E dv Auv integral_I omega_u(y) f(y)/m_v dy,

where I=Qu intersect Qv, Auv=S(1-m_v/m_u) in[0,1],0<=omega_u<=1,actualRv<Ru. Define p_uv=|I|/Rv^n in[0,1], f0=min(f,qv), fplus=(f-qv)+. The fraction p is actual geometric Lebesgue overlap, independent of source y; f may be arbitrarily concentrated. All these data remain defined from the same FULL f. Source factors f0+p fplus and(1-p)fplus are nonnegative, sum exactly to f, and each is <=f. Thus they form a genuine positive restriction of the original integrand, not a source reset, quadrature or unmarked-template equality.

At a fixed actual pair, dropping ONLY the nonnegative omega<=1 gives a=integral_I f0/mv<=qv|I|/mv=p, b=integral_I fplus/mv>=0, a+b=integral_I f/mv<=1 by actual cube matching. Therefore

a+p b=p(a+b)+(1-p)a<=p+(1-p)p=2p-p^2<=2p.

No relation between an extra source beta and f is needed. The bound uses actual small-cube total source mass, not a density bound on f. Integrating the original positive A<=1 and the screened R370 template yields

G_paid<=(1/h*) integral_E du/Ru^n integral_E (2p-p^2)dv
<=2Gamma_n |E|/h*<=2epsilon0 Gamma_n Xq/(1+sqrt(n)).

All integral exchanges are positive Tonelli. The last quantity is finite since E is finite Lebesgue measure, q_->0,a>0. No signed infinity subtraction is required. Boundary p=0 has zero Lebesgue intersection and, because f is L1, zero source overlap; p=1 has no remaining source factor. No positive fraction is guaranteed for intermediate p or arbitrary fields.

The new exact remainder is the SAME original marked kernel with source factor(1-p_uv)(f(y)-qv)+. It is pointwise <=the former R370 concentration excess, but that domination alone is not a proof of a new complete bound: the original G must be decomposed afresh as above, and the inherited R369 hard-slot budget then substituted. The new preferred receiver coefficient is epsilon0[2+(Cplus_n+2Gamma_n)/(1+sqrt(n))], Cplus_n<72. This REPLACES the prior Gamma_n floor coefficient, not adds a second2Gamma_n to it. If epsilon0 is reallocated, original h* and C338 must again use that same new epsilon0; original entrance2, outerLambda and all independent fees remain.

Separately, p_uv G is a legal positive fraction of the original source integrand. Since integral_I omega f/mv<=1, it alone costs at most Gamma_n|E|/h*. It cannot be charged independently on top of the joint receipt as though disjoint. The exact joint paid source factor may be written p f+(1-p)f0, making that overlap explicit. Neither fact grants any unproved cancellation of source-dependent omega, or reuse of old square/negative-source credit. The notBplus mask is retained throughout, so the previous Bplus payment is not repeated.

Reviewer-local Python Fraction actually tested2125 feasible scalar(p,a,b) configurations on denominators4,8,16. Every case checked a+pb<=2p-p^2<=2p, exact positive remainder addition, and domination of the old floor part. This is bounded scalar evidence only, not actual cube/source/highpast realization and not an author/parent pipeline total. The analytic proof above is the general argument. At this initial screen no author proof had yet been read; final author review and byte binding follow below.

## Bounded author review: source covariance and marks
After the independent statement screen, read /tmp/r371_source.md in full (SHA2569ada26c567107dbb21d4bb74bf38a761bdb685c3ad48531c5052afc7e2b3ad6f). PASS within its stated scope. Its Section2B even retains omega inside a,b, which remains valid since0<=omega<=1: a<=p and a+b<=1 still hold. The main joint price is2T0-T2<=2T0, with T2 a saving internal to that template bound, not original capture-square credit. It replaces the old floor or p-only alternative without summing overlapping bills.

The actual-source probability pi_v and UNIFORM reference U_v are distinct and normalized by actual full matching. D=E_pi F-E_U F and its symmetric covariance (1/(2q_v))E_(U times U)[(f(y)-f(z))(F(y)-F(z)) are exact. Replacing the uniform reference by an independent f-posterior would be wrong; the manuscript does not do so. Bounded F and finite receiver measure make each positive/signed term absolutely integrable in the stated contract.

The expansion omega_y c_y-omega_z c_z=omega_y(c_y-c_z)+c_z(omega_y-omega_z) produces the displayed Cplus,Cminus and M=Tmix-T exactly. Tmix<=T0 uses only E_pi omega<=1. Thus G=Cplus-Cminus+Tmix and the positive p-only split agree, without reusing T or Dminus as credit. These are alternative views of the same source correlation, not a second receipt after the joint split.

For each physical r the past-difference case, both-past but differing high-H case, and both-active reciprocal-J case partition |k_y-k_z| exactly. Their sum is<=1 since all k in[0,1]. Integrating the SAME probability clock xi_u, including the terminal b atom, and then pi_y U_z c_u(z), gives the single combined Vpast+VH+VJ<=T0. There is no hidden smoothing, threshold Lipschitz assumption, or loss of an atom. The strict-past/equality and inclusive J>=H conventions remain; H<=h indeed makes the high-H difference case empty. A difference of threshold indicators is NOT estimated by a small cumulative difference, which the text correctly warns. The auxiliary reciprocal-J estimate is safe on active rows J>h.

Read its full embedded code. The finite arrays supply J>Z to respect k<=1, exact strict/inclusive threshold conventions, positive clock weights summing1 and all finite covariance identities. The2529 aggregate Fraction checks were actually rerun by the parent in the final record; inner per-clock assertions are explicitly not separately counted. They are algebra diagnostics, not actual outside-center/notBplus/high-dimensional hard fixtures. This reviewer has not repeated that script. No correction found; no general source-correlation budget is inferred. Final integration and byte bindings follow below.

## Observable normalization author review
Independently checked the conditional-expectation construction before reading /tmp/r371_geometry.md in full. PASS under its EXPLICIT enlarged completed source sigma-field. It includes rho and every capture/clock/threshold/target weight whose preservation is asserted; the result does not infer joint observability from separately indexed capture measurability. Since rho dy is finite and rho>0 on Omega, f/rho is integrable there; conditional expectation defines a Lebesgue-measurable g after completion, with unchanged total mass and g=f off Omega. For each retained nonnegative observable L, integral gL=integral fL on Omega follows directly by testing in rho dy. The capture functions and their products therefore preserve actual masses and overlaps, and hence the fixed R,q,mu,J,Z and recomputed original marks. Original joint measurability for subsequent Tonelli is separately retained.

The full matched B_H(f,f) is invariant because both its symmetric-difference source masses and its observable weighted source factor are preserved. This does NOT establish invariance for an arbitrary separately fixed nu<=f. The manuscript makes that restriction. For Dplus/Dminus, localizing to the observable cube event is necessary and sufficient to make q_v/rho integrable even when Omega has infinite Lebesgue volume. Conditional Jensen gives both decreases, and invariance of G,T forces them to be equal. Thus the removed Delta cannot simply be subtracted again from f's fixed floor ledger; the legitimate use replaces the ENTIRE full matched functional by that of g. On a positive sigma-atom, rho is constant and g equals its actual Lebesgue cell mean, giving the stated min(two signs) identity. General continuous fields may give g=f and no reduction. The final main joint ledger does not assume this normalization supplies a fee or an arbitrary-nu improvement.

Read the276-check embedded finite code: exact matching/pair overlap, original source-dependent marks and equal Jensen decrease are checked on quadrature arrays with common capture classes. These do not prove the general theorem by numerics or realize a native hard branch. No correction found.

## Arbitrarily high pulse-source witness review
Read /tmp/r371_witness.md and its full725-assertion script. PASS for the stated analytic every-real-M>=2 construction, and finite script scope. The periodic first-coordinate pulse has period1/16,width1/(16M),height M and mean1. Any wholly supported interval s>=1 differs from its length by at most1/16; all actual cubes lie strictly inside Q6, so actual q lies in[15/16,17/16] and the selected U/V sides2,5/4 have q=1 at every center. The chosen qminus51/64=3lambda/4 is compatible, and delta=min(1e-6,1/(64M)) puts all of positive-volume Y inside a pulse without changing the uniform capacity margins.

Every actual receiver captures Y. The baseline inverse-radius capacity and q<=17/16 give strict global past>(16/17)(49n/150-2)=156704/51>H=h*=129280/51, using ALL non-U receivers and the actual continuum selector. The far mass estimate retains the extra lambda factor, and the whole-box exterior/notBplus inequalities from R370 remain valid. Upper J_max=(16/15)(1+n) follows actual q>=15/16 and R>=R0, and physical b atom is retained.

Coordinate overlaps really are partial at all coordinates: first length21/40 plus/minus2rho, other lengths9/8 plus/minus2rho. Their factored normalized product has strictly positive lower bound while the first factor alone gives p<1/2. On Y, f-q_v=M-1>0. Thus BOTH the newly paid p-excess share and retained(1-p)-excess share have the displayed strictly positive actual terminal probes. Tiny positive products are never replaced by floating large-power evaluation or useful global fractions. The proof for every real M is analytic, not interpolation from the five tested rational heights. The witness has its own epsilon0=1/20,H and lambda; it is not a claim for every joint-ledger reallocation or every additional historical qualification. Signed deviation is negative between pulses, so no full signed-integral positivity is claimed.

## Finite source LP mapping and certificate-code review
Read /tmp/r371_lp.md,/tmp/r371_lp_verify.py,/tmp/r371_lp.m and both JSON inputs/outputs. PASS for the explicitly finite receiver-quadrature diagnosis. All actual interval endpoints, including source-domain endpoints, induce complete positive-length source cells. The all-matching rows and W row constrain x>=0; x_j/length_j is a genuine compact piecewise-constant L1 source. Every matched q=1,full prefix J and strict past is fixed under these constraints. Radius-level clock weights are the exact integrated continuous ell between unchanged prefixes plus its terminal atom. No source cell, zero-J state or nonobjective matching constraint is omitted.

The MATLAB source maximization is min(-g*x). Its equality multiplier is the correct MAX dual price with A'price>=g, not its negative. Exact rational reconstruction, RREF residual correction and optional mixing with the strictly positive uniform feasible source preserve ALL matching and W; any negative reconstructed coordinate is repaired by the specified convex mixture. The upward W-price correction repairs every source column. Only exact primal/dual feasibility and a computed zero gap justify a finite optimum; solver exitflag alone does not. The code can allow a small certified gap in another run, so the notes' zero-gap claims are tied to the supplied current results.

For the restricted nonnegative receiver-price LP, its W intercept is free. Its independent lower source certificate has nonnegative masses, W=4 and receiver inequalities A_receiver z<=m, NOT all-matching equalities. This is the correct dual-class lower bound, not an admissible original source competitor. Positive-class zero gaps certify that the equal grid needs no negative receiver price despite a degenerate signed solution; the varying-weight extra cost only establishes necessity WITHIN this finite price class. The seven input case identities and the two auxiliary candidate dimensions/exitflags agree with the supplied files. No continuum-price necessity or native n1 hard gate is inferred. Original K=exp(sqrt(n)),outside/highpast/notBplus gates are NOT claimed: kappa=6/5,H=h=1/16 and finite receiver weights are openly diagnostic. No optimization pipeline was rerun by this reviewer.


## Final main/ledger and weak-dual interface
Read the final main, ledger, numeric notes and README in full. PASS. The joint positive contribution replaces R370's floor coefficient Gamma_n by2Gamma_n inside the SAME original R369 remainder. The sharper2T0-T2 is an internal template bound; neither T2 nor the auxiliary marked oscillation/covariance estimate is spent again. The exact remaining factor is(1-p_uv)(f-q_v)+, while original full-f masses,q,R,J,H,global strict past, outside/notBplus and physical clock/terminal atom stay fixed. The prior Bplus branch remains separate; no old D/N/A/C or path/square credit is duplicated.

The displayed hard-slot coefficient epsilon0[2+(Cplus_n+2Gamma_n)/(1+sqrt(n))] and C338 are consistent with the proofs. Choosing Ljoint_n=2+(72+2Gamma_n)/(1+sqrt(n)) and epsilon0=eta/Ljoint_n synchronizes the actual h* and inherited C338. This gives only this slot's entrance/outer coefficient2Lambda eta and O_eta(sqrt(n log(n+2)))W source fee. The original8lambda H W,2d_eff A_n Wnu/H, entrance2, outerLambda128/119 and all independent unresolved fees remain. Different allocations define different gates; the pulse witness is only at its own specified parameters.

The added finite signed-price inequality is a correct WEAK-dual sufficient condition for the ORIGINAL linear G load under frozen ALL-matching fields. For nonnegative f, a Lebesgue-a.e inequality L(y)<=C+sum finite t_j c_uj(y),C>=0, immediately integrates to G<=CW+sum t_j m_uj. The finite signed sum is integrable and uses genuine matching equalities. It is not asserted for nonlinear Gjoint under arbitrary changing sources and is not an infinite-dimensional attainment theorem. A cheap common dominating price remains unconstructed. Negative matching prices require the full pointwise domination; they are not independent free credits.

## Final execution counts and reproducibility limits
Final parent actual local reruns: source2529,geometry276,witness725,LP prepare14,LP exact verify76; total3620 counted Fraction checks, with repeated executions excluded. The MATLAB7 source LPs plus2 price LPs were actually executed by the worker, and the parent independently reran exact Python verification; the audit does not claim a second MATLAB optimization execution. Input regeneration matched frozen bytes. The supplied seven source candidates and two restricted-price candidates have the reported exact zero-gap certificates according to the executed verifier; finite scalar feasibility and exact gaps, not solver flags, certify these finite optima. No near-zero numerical gap is silently called exact zero.

The source/geometry standalone scripts exactly match their unique final embedded tilde-fenced blocks after stripping outer whitespace. All three standalone check scripts, the preparation/verifier, MATLAB script, and input/output JSON were read. Their stated quadrature/non-native limitations agree with final notes. The reviewer2125 exact scalar feasible configurations are separately recorded, not added to3620. No full pipeline was redundantly rerun during this audit. Counts are assertions, not actual hard-input samples or theorem counts. The actual every-real-M pulse argument remains analytic, supported by five tested heights; no huge overlap power is treated as a floating probability or a useful fixed fraction.

## Exact remaining obligations and disposition
The joint remainder can remain positive at arbitrarily high M; no uniform overlap or paid fraction is proved. Observable normalization may be identity and only preserves the fully matched hard slot unless additional source invariants are supplied. Auxiliary mark variation and finite dual price diagnostics do not pay concentration across different actual capture-observable states. The source-dependent omega prevents free mean-zero cancellation.

All general soft/crossing, original entrance compatibility, contract-exterior heavy/distance/low-pe/scale/threshold regimes, historical initial/deletion/future-source time atoms, H choice, source and physical-scale aggregation, outer integration, truncation and limits remain explicit unpaid obligations in the ledger. Neither finite source-LP optima nor the all-scale center-template theorem close the original global problem. No PDF compilation, packaging, Git status or publication is audited. No outstanding correction; FINAL PASS within these contracts and evidence boundaries.

## Frozen final byte bindings
SHA256 applies to the exact reviewed final bytes; this audit is hashed separately after saving.

- `/tmp/r371_main.md` — `fab564727af22c6a95f90f25678875b67cfd02084f0abd1a03a5004df9a2c558`
- `/tmp/r371_ledger.md` — `4ad01abea21c4afe8d84fb50ddfb306cde298381f62065cbd39b6891875655d3`
- `/tmp/r371_readme.md` — `955b89d5ccb95464bc52d95df3edb0a74b392dc55060acbfff278bdd6bc27d85`
- `/tmp/r371_numeric.md` — `23bd0fe664bf8246a8ec921262e8ec779697ea5d0a4397aa0f55c6c1c736f05e`
- `/tmp/r371_source.md` — `9ada26c567107dbb21d4bb74bf38a761bdb685c3ad48531c5052afc7e2b3ad6f`
- `/tmp/r371_geometry.md` — `40914994c9f2b281d843a2ada4d115a821a7c6bf7fef82b9b5732a9d3dd4012b`
- `/tmp/r371_witness.md` — `cbdb36498458c3cb4d94106ab9be09d0624d2c75a1317b1917eb07104ef243ca`
- `/tmp/r371_lp.md` — `d4951e7597c181be5a2497abd7827d93a03a0ebb3e65d51832620ea9d690d50c`
- `/tmp/r371_source_check.py` — `25bf17faa09bf5f9a0db464564c8ab06cb5da43327c1c6f1c08985bfba4771bc`
- `/tmp/r371_geometry_check.py` — `2ad2eb4da2f15ce71e906a60a23ead5bf9632d2b4b8c75014a5ff5bc13e2f460`
- `/tmp/r371_witness_check.py` — `97ad3d3f663decff8080a807da3c2f6b6c5af2098786e39fd84c0990637385ee`
- `/tmp/r371_lp_verify.py` — `dae1b87b369178c54301ad777f39ce6c742a07a6ee3f6e4b8d5d319e3ed96ce2`
- `/tmp/r371_lp.m` — `a1eff3b30200bb7e6a256d2ab7cf35cb1b014e64211ebad9b642c06b48f57abd`
- `/tmp/r371_lp_input.json` — `4b3c79631b526510c48f875656c1bd01f31346394fdeaa4a93f773c7caabca53`
- `/tmp/r371_lp_output.json` — `5fd57177164394f5cdc6e561bfdf0d1c5af1a71083bb65affb9c9736d674ce4c`

Necessary inherited contracts (bounded dependence review, not a new full-history audit):

- `/tmp/r370_geometry.md` — `fac02a43e18ed5dc3d5be7ef67a8ac9e34cbd4dd1e69912d6e29dffda597d81a`
- `/tmp/r370_main.md` — `150cea9386d50fd023f66948992b86ee482857888ed7e027802cab2aaaf26ed1`
- `/tmp/r370_ledger.md` — `a926a7c33566bddb4fd7858c3aeabd118b7221ab7d9223179fa0ec8a1858731e`
- `/tmp/r370_audit.md` — `863ccad98c26a83ad7d3ab902944feb357f434b383f12bb4e3dfaaadc154de7d`
- `/tmp/r369_main.md` — `12d0c216cf1dab0ec7b975b0b622aa7d64efc0a0a2e08f1cda50cfcfa2491c45`
- `/tmp/r338_main.md` — `69d779d69b422fe80e0ebfc92c9fe0eabe45bff783be6ce7eda8fdee9380a357`

Frozen FINAL PASS. Later mathematical/byte changes require renewed review/binding. No further task work remains.
