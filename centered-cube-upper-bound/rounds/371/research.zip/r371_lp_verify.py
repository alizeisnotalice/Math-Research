#!/usr/bin/env python3
"""Prepare real-interval finite LPs; independently verify rational certificates."""
from fractions import Fraction as F
from pathlib import Path
from collections import Counter
import json,sys
BASE=Path(__file__).resolve().parent;C=Counter()
def ck(k,v):
 C[k]+=1
 assert v,k
def cases():
 base=[(F(-1,2),F(2),F(1,8)),(F(3,4),F(1),F(1,8))]
 mid=base+[(F(0),F(3,2),F(1,8))]
 return [('initial','two_receivers',base),('initial','with_intermediate',mid),('stress','mirror_intermediate',[(-x,r,w) for x,r,w in mid]),('stress','two_sides',mid+[(F(-3,4),F(1),F(1,8))]),('stress','nonuniform_quadrature',[(x,r,F(i+1,16)) for i,(x,r,w) in enumerate(mid)])]+[('expanded','grid15_'+kind,[(F(j,2),r,F(1,8) if kind=='equal' else F((j+2+k)%3+1,16)) for j in range(-2,3) for k,r in enumerate([F(1),F(3,2),F(2)])]) for kind in ['equal','weighted']]
def fixture(stage,name,rec):
 pts=sorted(set([F(-2),F(2)]+[v for x,r,w in rec for v in [x-r/2,x+r/2]]));cells=list(zip(pts,pts[1:]));A=[[int(x-r/2<=a and b<=x+r/2) for a,b in cells] for x,r,w in rec];m=[r for x,r,w in rec];mu=[w/r for x,r,w in rec];radii=sorted(set(m));H=h=F(1,16);kappa=F(6,5);g=[F(0)]*len(cells);activepairs=0
 for k,r in enumerate(radii):
  ell=1/r-(1/radii[k+1] if k+1<len(radii) else 0)
  for j in range(len(cells)):
   J=sum(mu[u]*A[u][j] for u in range(len(rec)) if m[u]<=r)
   if J<H:continue
   for u,(xu,Ru,wu) in enumerate(rec):
    if Ru>r or not A[u][j]:continue
    past=sum(mu[t]*A[t][j] for t in range(len(rec)) if m[t]<m[u]/kappa)
    if past<=h:continue
    for v,(xv,Rv,wv) in enumerate(rec):
     if Rv<=r and A[v][j] and m[u]>kappa*m[v] and 2*abs(xu-xv)>Ru:
      g[j]+=ell/J*(m[u]-m[v])*mu[u]*mu[v];activepairs+=1
 AA=A+[[1]*len(cells)];b=m+[F(4)];x0=[z-a for a,z in cells]
 ck('uniform_source_all_matching_feasible',all(sum(F(t)*x for t,x in zip(row,x0))==rhs for row,rhs in zip(AA,b)))
 ck('all_source_cells_positive_and_full_domain',all(x>0 for x in x0) and sum(x0)==4)
 return dict(stage=stage,name=name,A=AA,b_numeric=list(map(float,b)),b_exact=list(map(str,b)),g_numeric=list(map(float,g)),g_exact=list(map(str,g)),uniform_exact=list(map(str,x0)),source_cells=[[str(a),str(b)] for a,b in cells],receivers=[dict(centre=str(x),R=str(r),quadrature=str(w)) for x,r,w in rec],H=str(H),h=str(h),kappa=str(kappa),active_pair_cell_layers=activepairs)
def prepare():
 data=[fixture(*args) for args in cases()];(BASE/'r371_lp_input.json').write_text(json.dumps(dict(cases=data,scope='Real positive-L1 cell densities, complete interval capture partition and all matching+W constraints. Finite receiver quadrature; diagnostic n1 gates, not native exp(sqrt(n)) hard branch.'),sort_keys=True,indent=2)+'\n');print('PREPARED',len(data),'cases',sum(C.values()),'exact feasibility checks')
def rref_solve(A,b):
 M=[list(map(F,row))+[F(v)] for row,v in zip(A,b)];nr=len(M);nc=len(M[0])-1;piv=[];i=0
 for j in range(nc):
  k=next((k for k in range(i,nr) if M[k][j]),None)
  if k is None:continue
  M[i],M[k]=M[k],M[i];v=M[i][j];M[i]=[x/v for x in M[i]]
  for k in range(nr):
   if k!=i:
    v=M[k][j];M[k]=[x-v*y for x,y in zip(M[k],M[i])]
  piv.append(j);i+=1
  if i==nr:break
 assert all(any(row[:nc]) or row[nc]==0 for row in M)
 x=[F(0)]*nc
 for k,j in enumerate(piv):x[j]=M[k][-1]
 return x
def rat(v):return F(0) if abs(v)<1e-11 else F(str(v)).limit_denominator(10**9)
def verify():
 inputs=json.loads((BASE/'r371_lp_input.json').read_text())['cases'];allraw=json.loads((BASE/'r371_lp_output.json').read_text());raw=allraw['cases'];raw=[raw] if isinstance(raw,dict) else raw;rows=[]
 ck('all_cases_present',len(inputs)==len(raw))
 for case,cand in zip(inputs,raw):
  ck('case_identity',case['name']==cand['name']);A=case['A'];b=list(map(F,case['b_exact']));g=list(map(F,case['g_exact']));x0=list(map(F,case['uniform_exact']));x=list(map(rat,cand['x']));ck('primal_dimensions',len(x)==len(g));res=[rhs-sum(F(t)*v for t,v in zip(row,x)) for row,rhs in zip(A,b)];corr=rref_solve(A,res);x=[a+d for a,d in zip(x,corr)];mix=max([F(0)]+[-v/(x0[j]-v) for j,v in enumerate(x) if v<0]);x=[(1-mix)*v+mix*u for v,u in zip(x,x0)]
  ck('exact_reconstructed_primal_nonnegative',all(v>=0 for v in x));ck('all_matching_and_W_exact',all(sum(F(t)*v for t,v in zip(row,x))==rhs for row,rhs in zip(A,b)))
  # MATLAB minimizes -g*x: its equality multiplier lambda gives A'lambda>=g.
  dual=list(map(rat,cand['dual_eqlin']));ck('dual_dimensions',len(dual)==len(A));deficit=max([F(0)]+[g[j]-sum(F(A[i][j])*dual[i] for i in range(len(A))) for j in range(len(g))]);dual[-1]+=deficit
  ck('correct_max_dual_price_direction',all(sum(F(A[i][j])*dual[i] for i in range(len(A)))>=g[j] for j in range(len(g))))
  primal=sum(a*v for a,v in zip(g,x));upper=sum(v*rhs for v,rhs in zip(dual,b));baseline=sum(a*v for a,v in zip(g,x0));gap=upper-primal
  ck('exact_weak_duality_gap_nonnegative',gap>=0);ck('uniform_comparator_below_candidate',baseline<=primal)
  if gap==0:ck('exact_zero_gap_certificate',upper==primal)
  else:ck('certified_gap_small',gap<=F(1,10**7))
  slacks=[sum(F(A[i][j])*dual[i] for i in range(len(A)))-g[j] for j in range(len(g))]
  if baseline==upper:ck('uniform_positive_source_zero_gap_implies_all_column_slacks_zero',all(v==0 for v in slacks))
  rows.append(dict(stage=case['stage'],name=case['name'],receiver_count=len(case['receivers']),source_cells=len(x),active_pair_cell_layers=case['active_pair_cell_layers'],uniform_objective=str(baseline),primal_objective=str(primal),dual_upper=str(upper),exact_gap=str(gap),uniform_to_primal_ratio=str(baseline/primal) if primal else None,objective_constant_on_matching_affine_space=all(v==0 for v in slacks),dual_prices=list(map(str,dual)),negative_dual_rows=[i for i,v in enumerate(dual) if v<0],primal_masses=list(map(str,x)),primal_repair_mix=str(mix),dual_W_price_repair=str(deficit),matlab_exitflag=cand['exitflag']))
 positive=[]
 ck('both_positive_price_tests_present',{x['name'] for x in allraw['nonnegative_duals']}=={'grid15_equal','grid15_weighted'})
 for cand in allraw['nonnegative_duals']:
  case=next(c for c in inputs if c['name']==cand['name']);free=next(r for r in rows if r['name']==cand['name']);A=case['A'];b=list(map(F,case['b_exact']));g=list(map(F,case['g_exact']));y=list(map(rat,cand['prices']));t=list(map(rat,cand['lower_source']))
  ck('positive_price_class_receiver_prices_nonnegative',all(v>=0 for v in y[:-1]))
  deficit=max([F(0)]+[g[j]-sum(F(A[i][j])*y[i] for i in range(len(A))) for j in range(len(g))]);y[-1]+=deficit
  ck('positive_price_class_all_source_cells_feasible',all(sum(F(A[i][j])*y[i] for i in range(len(A)))>=g[j] for j in range(len(g))))
  upper=sum(a*v for a,v in zip(b,y));lower=sum(a*v for a,v in zip(g,t));valid=all(v>=0 for v in t) and sum(t)==b[-1] and all(sum(F(a)*v for a,v in zip(row,t))<=rhs for row,rhs in zip(A[:-1],b[:-1]))
  ck('positive_class_relaxed_source_lower_certificate',valid)
  ck('positive_class_exact_zero_gap',upper==lower)
  ck('positive_class_cost_not_below_free_class',upper>=F(free['primal_objective']))
  positive.append(dict(name=case['name'],nonnegative_receiver_prices=list(map(str,y[:-1])),free_W_price=str(y[-1]),positive_class_optimum=str(upper),free_price_optimum=free['primal_objective'],extra_cost=str(upper-F(free['primal_objective'])),negative_prices_needed_to_attain_free_optimum=upper>F(free['primal_objective']),relaxed_source_lower=list(map(str,t)),exact_class_gap=str(upper-lower)))
 print(json.dumps(dict(status='PASS',exact_checks=sum(C.values()),check_counts=dict(C),summary=rows,nonnegative_price_necessity=positive,scope='Exact finite primal/dual certificates only. Source x gives genuine piecewise-constant compact L1 with all q=1 frozen matching. Receiver quadrature and diagnostic kappa/H/past are not original native hard branch.'),sort_keys=True,indent=2))
if __name__=='__main__':
 if len(sys.argv)>1 and sys.argv[1]=='prepare':prepare()
 else:verify()
