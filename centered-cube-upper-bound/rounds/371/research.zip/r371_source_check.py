from fractions import Fraction as F
from itertools import product

checks=0
vol=[F(1),F(2),F(1)]
U=[v/sum(vol) for v in vol]
clock=[F(1,2),F(1,3),F(1,6)]
Z=[F(1,2),F(1),F(3)]
Js=[[z+F(1,4)+F(r,2)*(i+1) for i,z in enumerate(Z)] for r in range(3)]
for fs in ((0,0,1),(0,1,3),(1,1,1),(4,0,2)):
    f=list(map(F,fs)); m=sum(f[i]*vol[i] for i in range(3))
    q=m/sum(vol); pi=[f[i]*vol[i]/m for i in range(3)]
    for h in (F(1,2),F(1),F(3)):
        for H in (F(0),F(3,4),F(13,4)):
            past=[int(z>h) for z in Z]
            high=[[int(j>=H) for j in row] for row in Js]
            ks=[[h*past[i]*high[r][i]/Js[r][i] for i in range(3)] for r in range(3)]
            omega=[sum(clock[r]*ks[r][i] for r in range(3)) for i in range(3)]
            for c in product((0,1),repeat=3):
                p=sum(U[i]*c[i] for i in range(3))
                G=sum(pi[i]*omega[i]*c[i] for i in range(3))
                T=sum(U[i]*omega[i]*c[i] for i in range(3))
                defect=G-T
                cov=sum(U[i]*U[j]*(f[i]-f[j])*(omega[i]*c[i]-omega[j]*c[j]) for i in range(3) for j in range(3))/(2*q)
                assert defect==cov; checks+=1
                cp=(1-p)*G
                cm=p*sum(pi[i]*omega[i]*(1-c[i]) for i in range(3))
                mix=p*sum(pi[i]*omega[i] for i in range(3))
                M=mix-T
                assert defect==cp-cm+M; checks+=1
                costs=[F(0),F(0),F(0)]
                for i in range(3):
                    for j in range(3):
                        for r in range(3):
                            dif=abs(ks[r][i]-ks[r][j])
                            jp=dif*int(past[i]!=past[j])
                            jh=dif*int(past[i]==past[j]==1 and high[r][i]!=high[r][j])
                            jj=F(0)
                            if past[i]==past[j]==high[r][i]==high[r][j]==1:
                                jj=h*abs(Js[r][i]-Js[r][j])/(Js[r][i]*Js[r][j])
                            assert jp+jh+jj==dif<=1
                            fac=pi[i]*U[j]*c[j]*clock[r]
                            for k,a in enumerate((jp,jh,jj)): costs[k]+=fac*a
                assert abs(M)<=sum(costs)<=p; checks+=1
                assert G==cp+p*G and 0<=p*G<=p; checks+=1
                assert G==cp-cm+mix<=cp+p; checks+=1
                if H<=h: assert costs[1]==0
                checks+=1
                aa=sum(U[i]*min(f[i],q)*omega[i]*c[i]/q for i in range(3))
                bb=sum(U[i]*max(f[i]-q,F(0))*omega[i]*c[i]/q for i in range(3))
                assert 0<=aa<=p and aa+bb==G<=1
                assert aa+p*bb<=2*p-p*p; checks+=1
                assert G==aa+p*bb+(1-p)*bb
                assert aa+p*bb>=max(aa,p*G); checks+=1
for ip in range(9):
    p=F(ip,8)
    for ia in range(5):
        aa=p*F(ia,4)
        for ib in range(5):
            bb=(1-aa)*F(ib,4)
            assert aa+p*bb<=2*p-p*p
            assert aa+bb==aa+p*bb+(1-p)*bb
            checks+=1
print('PASS',checks,'exact Fraction aggregate checks')
