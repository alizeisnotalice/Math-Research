# 第370轮完整优先费用与剩余积分

同一完整 $f,E,R,q,m,J$、严格过去、原时钟及终端原子；第369轮 $G=G_{out,\neg B^+}$ 不改定义。定义 $G_{floor}$、$G_{excess}$ 为 main 的精确正来源拆分。设
\[
\mathfrak a_n=\sqrt{1/4+(1/2)\log(1+\sqrt n)},\quad
\Gamma_n=1+\frac{n}{4(\sqrt n+1)}+2\sqrt n\mathfrak a_n(1-1/\sqrt2).
\]
本轮 $G_{floor}\le\varepsilon_0\Gamma_nX_q/(1+\sqrt n)$，没有新的来源费。故同一个硬槽满足
\[
B_H(f,\nu)\le G_{excess}
+\varepsilon_0\left[2+\frac{C_n^++\Gamma_n}{1+\sqrt n}\right]X_q+C_{338}W,
\quad \nu\le f,
\]
\[
C_n^+<72,\quad
C_{338}=\frac\lambda{q_-}\left\{\frac{2+3\sqrt n+2e^{-\sqrt n}}{\varepsilon_0}+1+\sqrt n\right\}.
\]
这是对第369轮未付正积分内部来源的分解；旧 $B^+$ 已付门与新 floor 支不交，不再添加旧 D/N/A/C 费用。$D_-$ 已通过 $G_{floor}=T-D_-$ 使用；不再次购买原负平方或路径回捕信用。

对任意拟分配硬槽系数 $\eta>0$，可取
\[
L_n=2+\frac{72+\Gamma_n}{1+\sqrt n},\qquad
\varepsilon_0=\eta/L_n.
\]
然后必须同步设置 $h_*=(1+\sqrt n)L_n/(\eta q_-)$，并在 $C_{338}$ 中用同一个 $\varepsilon_0$。此时硬槽接收系数至多 $\eta$，来源费为 $O_\eta(\sqrt{n\log(n+2)})W$。这里 $L_n$ 是本轮分配因子，非旧路径长度。改变参数会改变剩余门；不能将一个固定参数的数值见证说成所有分配参数的见证。

原入口及外乘完整保留：
\[
T_{entrance}\le8\lambda HW+2d_{eff}A_nW_\nu/H+2G_{excess}
+2\varepsilon_0\left[2+\frac{C_n^++\Gamma_n}{1+\sqrt n}\right]X_q+2C_{338}W,
\quad A_n=1+n\log(b/a),\quad\Lambda=128/119.
\]
全式再乘 $\Lambda$。上述参数分配只将这一硬槽的接收系数控制为 $2\Lambda\eta$；不证明其他独立槽的总系数已可吸收。没有隐去 $H,d_{eff}$ 或原来源外积分。

## 精确未付对象

$G_{excess}$ 是原 $G_{out,\neg B^+}$ 积分中把来源因子 $f(y)$ 换为 $(f(y)-q_v)_+$，其余全部维持完整 $f$ 定义。仍要求严格远质量 $m_u>e^{\sqrt n}m_v$、全局 strict past、$J\ge H$、真正 outside 中心门及超过 $B^+$ 的总外突；全部边界等号归属沿用第369轮。接收测度仍为真实 Lebesgue，物理终端原子未删除。

独立未付仍包括一般 soft $C_H-S_H$、crossing $I_H$、不同原始入口与匹配硬合同连接、合同外重尾、宽距离/低pe/其他比例及阈值补集；初始、删除跳跃及未来被删来源的历史时间项；$H$ 选择、来源/物理尺度/分层聚合、外积分、截断与极限。全尺度几何模板定理不自动支付这些实际来源与时间费用。

本轮二来源工具不新增费用或信用；旧路径 $F_{shell}$ 仍是替代路线而非本式的追加项。历史完整账沿用第369轮 ledger（归档中保留原文），本文件优先式替换其最前面的未付项，不混加后续历史备选账。
