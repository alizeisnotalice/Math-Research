% Finite interval LP candidate generation; no workspace/path reset.
r371_base = fileparts(mfilename('fullpath'));
r371_input = jsondecode(fileread(fullfile(r371_base,'r371_lp_input.json')));
r371_options = optimoptions('linprog','Display','none');
r371_cases = r371_input.cases;
r371_results = repmat(struct('name','','exitflag',0,'x',[],'dual_eqlin',[],'fval',0,'iterations',0),numel(r371_cases),1);
for r371_idx=1:numel(r371_cases)
    r371_case = r371_cases(r371_idx);
    r371_A = double(r371_case.A);
    r371_b = double(r371_case.b_numeric(:));
    r371_g = double(r371_case.g_numeric(:));
    [r371_x,r371_fval,r371_exitflag,r371_output,r371_lambda] = linprog(-r371_g,[],[],r371_A,r371_b,zeros(numel(r371_g),1),[],r371_options);
    r371_result = struct();
    r371_result.name = r371_case.name;
    r371_result.exitflag = r371_exitflag;
    r371_result.x = r371_x;
    % min -g*x: stationarity gives A'*eqlin = g + lower >= g.
    r371_result.dual_eqlin = r371_lambda.eqlin;
    r371_result.fval = r371_fval;
    r371_result.iterations = r371_output.iterations;
    r371_results(r371_idx) = r371_result;
end
% Bounded necessity test: nonnegative receiver prices, free W intercept.
r371_positive = repmat(struct('name','','prices',[],'lower_source',[],'exitflag',0,'fval',0),2,1);
for r371_j=1:2
    r371_case = r371_cases(numel(r371_cases)-2+r371_j);
    r371_A = double(r371_case.A);
    r371_b = double(r371_case.b_numeric(:));
    r371_g = double(r371_case.g_numeric(:));
    [r371_y,r371_val,r371_flag,r371_info,r371_mult] = linprog(r371_b,-r371_A',-r371_g,[],[],[zeros(numel(r371_b)-1,1);-Inf],[],r371_options);
    r371_pos = struct();
    r371_pos.name = r371_case.name;
    r371_pos.prices = r371_y;
    r371_pos.lower_source = r371_mult.ineqlin;
    r371_pos.exitflag = r371_flag;
    r371_pos.fval = r371_val;
    r371_positive(r371_j) = r371_pos;
end
r371_fid = fopen(fullfile(r371_base,'r371_lp_output.json'),'w');
fwrite(r371_fid,jsonencode(struct('cases',r371_results,'nonnegative_duals',r371_positive)),'char');
fclose(r371_fid);
fprintf('R371 MATLAB completed %d source LPs + 2 nonnegative-price LPs.\n',numel(r371_cases));
