from fractions import Fraction as F
counts={'matching':0,'pair_overlap':0,'marked_invariance':0,'jensen_balance':0}
strict=0
base=[{0,1},{1,2,3},set(range(8)),set(range(4,12)),set(range(12)),{0,2,4,6,8,10}]
sets=[{2*y+k for y in A for k in range(2)} for A in base]
vol=[F(1,2)]*24
V=[sum(vol[y] for y in A) for A in sets]
du=[F(i+1,3) for i in range(6)]
patterns=[tuple(int(y in A) for A in sets) for y in range(24)]
groups={}
for y,p in enumerate(patterns):groups.setdefault(p,[]).append(y)
levels=sorted(set(V))
clock=[1/R-(1/levels[k+1] if k+1<len(levels) else F(0)) for k,R in enumerate(levels)]
for phase in range(3):
 means=[F(6+(sum(patterns[y])+phase)%3,8) for y in range(24)]
 f=[F(0) if y%2==0 else 2*means[y] for y in range(24)]
 m=[sum(vol[y]*f[y] for y in A) for A in sets]
 q=[m[i]/V[i] for i in range(6)]
 mu=[du[i]/m[i] for i in range(6)]
 rho=[sum(mu[u] for u in range(6) if y in sets[u]) for y in range(24)]
 g=[F(0)]*24
 for cell in groups.values():
  cmean=sum(vol[y]*f[y] for y in cell)/sum(vol[y] for y in cell)
  rmean=sum(vol[y]*rho[y]*(f[y]/rho[y]) for y in cell)/sum(vol[y]*rho[y] for y in cell)
  for y in cell:
   g[y]=rho[y]*rmean
   assert g[y]==cmean
 assert sum(vol[y]*f[y] for y in range(24))==sum(vol[y]*g[y] for y in range(24))
 for u in range(6):
  assert m[u]==sum(vol[y]*g[y] for y in sets[u])
  counts['matching']+=1
  for v in range(6):
   assert sum(vol[y]*f[y] for y in sets[u]&sets[v])==sum(vol[y]*g[y] for y in sets[u]&sets[v])
   counts['pair_overlap']+=1
 K=F(2)
 J=[[sum(mu[u] for u in range(6) if V[u]<=R and y in sets[u]) for y in range(24)] for R in levels]
 past=[[sum(mu[v] for v in range(6) if m[v]<m[u]/K and y in sets[v]) for y in range(24)] for u in range(6)]
 for H in [F(0),F(1,4),F(1,2),F(1),F(2)]:
  for h in [F(1,8),F(1,4),F(1,2),F(1),F(2)]:
   omega=[[F(0)]*24 for _ in range(6)]
   for k,R in enumerate(levels):
    for u in range(6):
     if V[u]>R:continue
     for y in range(24):
      if J[k][y] and J[k][y]>=H and past[u][y]>h:
       assert J[k][y]>h
       omega[u][y]+=h*V[u]*clock[k]/J[k][y]
   def calc(source):
    G=T=P=N=F(0)
    for u in range(6):
     for v in range(6):
      if not(m[u]>K*m[v]) or (u+2*v)%3==0:continue
      coef=du[u]*du[v]*(1-m[v]/m[u])/(h*V[u])
      for y in sets[u]&sets[v]:
       w=coef*omega[u][y]*vol[y]
       G+=w*source[y]/m[v]
       T+=w/V[v]
       P+=w*max(F(0),source[y]-q[v])/m[v]
       N+=w*max(F(0),q[v]-source[y])/m[v]
    assert G==T+P-N
    return G,T,P,N
   Gf,Tf,Pf,Nf=calc(f);Gg,Tg,Pg,Ng=calc(g)
   assert Gf==Gg and Tf==Tg
   counts['marked_invariance']+=1
   assert Pf>=Pg and Nf>=Ng and Pf-Pg==Nf-Ng
   strict+=Pf>Pg
   counts['jensen_balance']+=1
print('PASS',counts,'total',sum(counts.values()),'strict_reductions',strict)
