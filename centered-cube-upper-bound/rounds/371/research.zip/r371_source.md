# R371 — Paid marked oscillation and an overlap-fraction source split

**Outcome.** A positive source split pays the overlap fraction p_uv=|Q_u∩Q_v|/R_v^n of the original G at ONE R370 template price, without a density bound. Combined disjointly with the old floor split, its exact remaining source factor is (1−p_uv)(f−q_v)_+ and the same-pair paid bound is 2p_uv−p_uv². Separately, the signed defect has an exact two-source covariance expansion: all changed J/H/strict-past mark costs together have an absolute bound by ONE template. There is no uniform lower bound on p_uv established here, and no general root closure.

The p-only split is an alternative to R370's floor split; the combined split in Section 2B explicitly handles their overlap. Neither supplies an additional negative-square credit.

## 1. Frozen definitions and an exact covariance

All full-f fields, actual receivers and original residual masks are exactly those in R370 geometry §§1,5–7. In particular m_u=f(Q_u)=q_uR_u^n, q_-≤q_u≤λ, a≤R_u≤b≤2a, μ(du)=du/m_u, K=exp(√n), and h=h_*=(1+√n)/(ε_0q_-). S(u,v) is the far-mass, outside-center, not-Bplus mask. Put A(u,v)=S(u,v)(1−m_v/m_u), so 0≤A≤1 and A>0 implies R_v<R_u. Define the probability clock

    ξ_u(dr)=R_u^n 1_[R_u,b](r) ell(dr),

including the original terminal atom, and

    p_u(y)=1_(Z_y(m_u/K-)>h), b_r(y)=1_(J_y(r)≥H),
    k_(u,r)(y)=h p_u(y)b_r(y)/J_y(r),
    ω_u(y)=∫ξ_u(dr) k_(u,r)(y).

Zero-J quotients are zero. Original mass matching makes every receiver in this strict past have radius <R_u; hence p_u(y)=1 implies J_y(r)>h for r≥R_u. Therefore 0≤k≤1 and 0≤ω≤1. No past gate is transferred to another source.

For each actual v, let

    U_v(dy)=1_(Q_v)(y)dy/R_v^n,
    π_v(dy)=f(y)1_(Q_v)(y)dy/m_v,
    p_uv=U_v(Q_u)=|Q_u∩Q_v|/R_v^n.

Both are probabilities by the SAME matching equation. U_v is a uniform reference on the actual small cube, not another f-posterior. With

    F_v(y)=(1/h)∫du/R_u^n A(u,v)ω_u(y)c_u(y),

the signed defect is exactly

    D=∫dv ∫π_v(dy)U_v(dz)[F_v(y)−F_v(z)].             (1)

Equivalently its symmetric two-position form is

    D=∫dv [1/(2q_v)]∫U_v(dy)U_v(dz)
                       [f(y)−f(z)][F_v(y)−F_v(z)].    (2)

These are identities for the actual full f, including regions where f=0. Replacing U_v by an independent f-posterior would not preserve them. All functions are bounded except integrable f, and the finite-measure contract and R370 template bound justify Fubini.

## 2. Changed capture versus changed marks

Use the exact pointwise expansion

    ω_u(y)c_u(y)−ω_u(z)c_u(z)
      =ω_u(y)[c_u(y)−c_u(z)]
                         +c_u(z)[ω_u(y)−ω_u(z)].      (3)

Let C be the integral of the first term in (3) with the positive measure

    (1/h)du/R_u^n dv A(u,v) π_v(dy)U_v(dz),

and M that of the second. Then D=C+M. The capture term has the exact positive decomposition

    C=C_+−C_-,
    C_+=(1/h)∫du/R_u^n dv A(1−p_uv) E_(π_v)[ω_u c_u],
    C_-=(1/h)∫du/R_u^n dv A p_uv E_(π_v)[ω_u(1−c_u)]. (4)

In particular C_+ is precisely the original positive G with the extra scalar factor 1−p_uv. It does not reset J, q, past, or the clock.

The mark term also has an exact signed form:

    M=T_mix−T,
    T_mix=(1/h)∫du/R_u^n dv A p_uv E_(π_v)ω_u,
    T=(1/h)∫du/R_u^n dv A E_(U_v)[ω_u c_u].           (5)

Here T is EXACTLY R370's original marked uniform template. Since 0≤ω≤1,

    T_mix ≤ T_0,
    T_0=(1/h)∫du/R_u^n dv A p_uv
       ≤ Γ_n |E|/h
       ≤ ε_0 Γ_n X_q/(1+√n),                        (6)

where Γ_n=C_oct,n from R370. The last estimate is the proved global actual-selector uniform-overlap theorem; the real measures are du and dv. This does not bound f by volume.

Combining G=T+D with (4)–(5), without spending T twice, gives

    G=C_+−C_-+T_mix≤C_++T_0.                         (7)

There is a direct positive version of exactly the same cancellation:

    G=G_overlap+G_complement,
    G_overlap=(1/h)∫du/R_u^n dv A p_uv E_(π_v)[ω_u c_u],
    G_complement=C_+,
    0≤G_overlap≤T_0.                                 (8)

Thus the paid term is an actual nonnegative fraction of the original residual, not just an absolute-value estimate for a renamed signed expression. This fraction differs from min(f,q_v): it is defined even where f>q_v throughout a part of the overlap. Conversely it need not dominate the floor split. No coverage fraction bounded below has been proved.

## 2B. Disjoint combination with the floor: exact bound 2p−p²

For each actual pair, keep the SAME common mark 0≤ω_u≤1 and write

    a_uv=∫_(Q_u∩Q_v) min(f(y),q_v) ω_u(y)dy/m_v,
    b_uv=∫_(Q_u∩Q_v) (f(y)−q_v)_+ ω_u(y)dy/m_v.

Then 0≤a_uv≤p_uv and a_uv+b_uv≤1 by actual matching. The elementary but exact useful bound is

    a_uv+p_uv b_uv ≤ p_uv+(1−p_uv)a_uv
                         ≤2p_uv−p_uv².              (13)

It holds for every common measurable mark in [0,1]; no independence of the mark and f is required. The original pair source integral splits positively as

    a_uv+b_uv = [a_uv+p_uv b_uv] + (1−p_uv)b_uv.       (14)

The bracket first pays the old floor and then ONLY the overlap fraction of its excess complement. Thus there is no duplicated source traffic. Integrating with the unchanged positive measure (1/h)du/R_u^n dv A(u,v), define P_joint as the bracket integral and G_joint as the last term. Then

    G=P_joint+G_joint,
    P_joint≤T_joint:=(1/h)∫du/R_u^n dv A(2p_uv−p_uv²)
                    =2T_0−T_2≤2T_0,
    T_2=(1/h)∫du/R_u^n dv A p_uv²≥0.                 (15)

T_2 is a saving inside this explicit positive template bound; it is not original capture-square credit. It must not be added as a separate negative term to another already relaxed ledger.

The exact new remaining integral G_joint is the original G with source factor (1−p_uv)(f(y)−q_v)_+, all f-defined fields frozen. It is at most both the old excess remainder and the p-only complement. Its payment is at most 2ε_0Γ_n X_q/(1+√n), and the sharper actual template 2T_0−T_2 may be retained. This is a strict algebraic enlargement of the paid traffic whenever the corresponding positive floor/excess and overlap factors occur; no assertion gives such traffic a uniform positive fraction for arbitrary input.

## 3. Exact threshold-jump and reciprocal-J costs

For each u,r,y,z abbreviate p_y=p_u(y), b_y=b_r(y), k_y=k_(u,r)(y), and define three nonnegative quantities:

    j_p=1_(p_y≠p_z)|k_y−k_z|,
    j_H=1_(p_y=p_z=1)1_(b_y≠b_z)|k_y−k_z|,
    j_J=1_(p_y=p_z=b_y=b_z=1)
                              h|J_y(r)−J_z(r)|/[J_y(r)J_z(r)].

They give the exact partition

    |k_y−k_z|=j_p+j_H+j_J≤1.                         (9)

This handles strict-past equality and the inclusive high-J boundary without smoothing them. For each label a∈{p,H,J}, let

    V_a=(1/h)∫du/R_u^n dv A ∫π_v(dy)U_v(dz)c_u(z)
                                       ∫ξ_u(dr) j_a(u,r,y,z).

Then

    |M|≤V_p+V_H+V_J≤T_0.                             (10)

The three costs are NOT charged as three copies of T_0: their sum uses (9) before integration. This is a genuinely uniform bound on all marked oscillation, despite the lack of regularity of ω. The crucial factor is c_u(z) at the uniform reference location; integrating π_v gives exactly one using matching.

For clarity, the reciprocal part is controlled by actual capture changes,

    j_J≤1_(both active) min(1, |J_y(r)−J_z(r)|/h),
    |J_y(r)−J_z(r)|≤∫_(E_r)|c_w(y)−c_w(z)| μ(dw).     (11)

The analogous bound holds for the strict-past cumulative Z with its ORIGINAL mass restriction. A small cumulative difference alone does not bound a threshold indicator difference, since the sources may straddle the threshold. Formula (9) keeps that jump as its own cost; no Lipschitz assertion is made. If H≤h, then V_H=0, since p=1 already implies J>h≥H. No such ordering of H and h is assumed in (10).

## 4. Complete price and remaining capture correlation

Replacing the R369 residual G by (7) gives the legitimate alternative hard-slot ledger

    B_H(f,ν)≤G_complement
       +ε_0[2+(C_n^++Γ_n)/(1+√n)]X_q+C338 W,
    ν≤f,
    C338=(λ/q_-)[(2+3√n+2exp(−√n))/ε_0+1+√n].        (12)

All original entrance terms, outer factor 128/119, source outer integration, H, and unproved soft/other slots remain as in R370's ledger. Equation (12) uses the same price as R370's floor alternative, but a DIFFERENT remaining integral. It does not add Γ_n again to the floor ledger and does not reuse D_minus. Parameter specialization must change ε_0, h and C338 consistently.

For the p-only ledger (12), the precise unpaid term is the original G with weight 1−p_uv, or equivalently C_+ in (4). For the joint ledger use G_joint and replace Γ_n by 2Γ_n in (12), or retain the sharper positive bill 2T_0−T_2 before taking its bound. This is a replacement of the floor ledger, not a third template fee.

The p-only remainder correlates the f-posterior location with actual capture. The same uniform-overlap theorem does not pay it: its c_u(y) is at the nonuniform source location, while its uniform reference is outside Q_u with probability 1−p_uv. Equations (9)–(10) remove no source mass and make no claim that this remaining correlation is small. No further root-order source budget is established here.

## 5. Exact local checks

The code tests the covariance, the two signed decompositions, the single combined variation budget, strict/inclusive threshold equalities, and the positive overlap split. The normalized clock includes a terminal atom. These are finite algebra diagnostics, not a realization of the original outside-center radius selector. Full L1 geometry is handled by the proof and the previously proved R370 template theorem.

~~~python
from fractions import Fraction as F
from itertools import product

checks=0
vol=[F(1),F(2),F(1)]
U=[v/sum(vol) for v in vol]
clock=[F(1,2),F(1,3),F(1,6)]
Z=[F(1,2),F(1),F(3)]
Js=[[z+F(1,4)+F(r,2)*(i+1) for i,z in enumerate(Z)] for r in range(3)]
for fs in ((0,0,1),(0,1,3),(1,1,1),(4,0,2)):
    f=list(map(F,fs)); m=sum(f[i]*vol[i] for i in range(3))
    q=m/sum(vol); pi=[f[i]*vol[i]/m for i in range(3)]
    for h in (F(1,2),F(1),F(3)):
        for H in (F(0),F(3,4),F(13,4)):
            past=[int(z>h) for z in Z]
            high=[[int(j>=H) for j in row] for row in Js]
            ks=[[h*past[i]*high[r][i]/Js[r][i] for i in range(3)] for r in range(3)]
            omega=[sum(clock[r]*ks[r][i] for r in range(3)) for i in range(3)]
            for c in product((0,1),repeat=3):
                p=sum(U[i]*c[i] for i in range(3))
                G=sum(pi[i]*omega[i]*c[i] for i in range(3))
                T=sum(U[i]*omega[i]*c[i] for i in range(3))
                defect=G-T
                cov=sum(U[i]*U[j]*(f[i]-f[j])*(omega[i]*c[i]-omega[j]*c[j]) for i in range(3) for j in range(3))/(2*q)
                assert defect==cov; checks+=1
                cp=(1-p)*G
                cm=p*sum(pi[i]*omega[i]*(1-c[i]) for i in range(3))
                mix=p*sum(pi[i]*omega[i] for i in range(3))
                M=mix-T
                assert defect==cp-cm+M; checks+=1
                costs=[F(0),F(0),F(0)]
                for i in range(3):
                    for j in range(3):
                        for r in range(3):
                            dif=abs(ks[r][i]-ks[r][j])
                            jp=dif*int(past[i]!=past[j])
                            jh=dif*int(past[i]==past[j]==1 and high[r][i]!=high[r][j])
                            jj=F(0)
                            if past[i]==past[j]==high[r][i]==high[r][j]==1:
                                jj=h*abs(Js[r][i]-Js[r][j])/(Js[r][i]*Js[r][j])
                            assert jp+jh+jj==dif<=1
                            fac=pi[i]*U[j]*c[j]*clock[r]
                            for k,a in enumerate((jp,jh,jj)): costs[k]+=fac*a
                assert abs(M)<=sum(costs)<=p; checks+=1
                assert G==cp+p*G and 0<=p*G<=p; checks+=1
                assert G==cp-cm+mix<=cp+p; checks+=1
                if H<=h: assert costs[1]==0
                checks+=1
                aa=sum(U[i]*min(f[i],q)*omega[i]*c[i]/q for i in range(3))
                bb=sum(U[i]*max(f[i]-q,F(0))*omega[i]*c[i]/q for i in range(3))
                assert 0<=aa<=p and aa+bb==G<=1
                assert aa+p*bb<=2*p-p*p; checks+=1
                assert G==aa+p*bb+(1-p)*bb
                assert aa+p*bb>=max(aa,p*G); checks+=1
for ip in range(9):
    p=F(ip,8)
    for ia in range(5):
        aa=p*F(ia,4)
        for ib in range(5):
            bb=(1-aa)*F(ib,4)
            assert aa+p*bb<=2*p-p*p
            assert aa+bb==aa+p*bb+(1-p)*bb
            checks+=1
print('PASS',checks,'exact Fraction aggregate checks')
~~~

Execution record: the final embedded script was actually run with local Python 3 and returned `PASS 2529 exact Fraction aggregate checks` (exit status 0). The per-clock pointwise assertions run inside each aggregate case and are not separately counted. The earlier 1728-check version was extended; the reported count is only for the final script.
