#!/usr/bin/env python3
"""R371 high-density actual-L1 witness: exact rational checks, no result files."""
from fractions import Fraction as F
from math import factorial
from collections import Counter
import json

n=10000; root=100; a=F(1); b=F(2); Ru=F(2); Rv=F(5,4)
tau=F(1,16); lam=F(17,16); qminus=F(51,64); eps=F(1,20)
H=(1+root)/(eps*qminus)
counts=Counter(); count=0

def ck(stage,name,condition):
    global count
    assert condition,name
    counts[stage]+=1; count+=1

def primitive(M,x):
    width=tau/M
    shifted=x+width/2
    k=shifted//tau
    rem=shifted-k*tau
    return k*tau+M*min(rem,width)

def integral(M,center,side):
    return primitive(M,center+side/2)-primitive(M,center-side/2)

def logbounds(x,N=80):
    z=(x-1)/(x+1)
    lo=2*sum((z**(2*j+1)/F(2*j+1) for j in range(N)),F(0))
    return lo,lo+2*z**(2*N+1)/(F(2*N+1)*(1-z*z))

ck('common','dimension',root**2==n)
ck('common','lambda_qminus',3*lam/4==qminus)
ck('common','band_contains_true_q',qminus<F(15,16)<1<F(17,16)==lam)
ck('common','H_exact',H==F(129280,51))
past=F(16,17)*(F(49*n,150)-2)
ck('common','past_exact',past==F(156704,51))
ck('common','strict_highpast_margin',past>H)
eupper=sum((F(1,factorial(k)) for k in range(11)),F(0))+F(1,factorial(11))*F(12,11)
ck('common','exp_one_upper',eupper<3)
ck('common','mass_base',F(4,3)**4>3)
ck('common','mass_exponents_with_qfactor',n//4>root+1 and lam<3 and n%4==0)
ck('common','outside_alpha_bound',F(21,20)**100>101 and n>=100)
lo32,hi32=logbounds(F(3,2)); lo2,hi2=logbounds(F(2))
ck('common','radial_log_lower',lo32>F(1,3))
ck('common','J_log_upper',hi2<1)
beta=F(n+1,n); w=max(a,Rv/beta)
Tplus=F(n,4)*((1+beta)*w-Ru)**2/(beta*w)
ck('common','threshold_exact',Tplus==F(49985001125,100020001))
ck('common','threshold_positive',Tplus>0 and (1+beta)*w>Ru)
ck('common','full_source_period_count',F(6)/tau==96 and Ru/tau==32 and Rv/tau==20)

rows=[]
for M in map(F,[2,16,10000,10**8,2**100]):
    delta=min(F(1,10**6),1/(64*M)); rho=delta/10
    ck('profile_geometry','height',M>=2)
    ck('profile_geometry','positive_scales',0<rho<delta<=F(1,10**6))
    ck('profile_geometry','all_Y_in_pulse',delta<=1/(64*M)<1/(32*M))
    ck('profile_geometry','period_width',M*(tau/M)==tau and tau/M<=tau/2)
    ck('profile_geometry','Bernoulli_uniform',1-2*delta*(n-1)>F(49,50))
    for label,u,v in [('first',F(-1,2),F(3,5)),('other',F(0),F(1,2))]:
        ck('profile_geometry','U_E_'+label,abs(u)+rho<F(3,4)-delta)
        ck('profile_geometry','V_E_'+label,abs(v)+rho<F(3,4)-delta)
        ck('profile_geometry','U_capture_'+label,abs(u)+rho+delta<Ru/2)
        ck('profile_geometry','V_capture_'+label,abs(v)+rho+delta<Rv/2)
    ck('profile_geometry','U_override',2*(F(1,2)+rho)+2*delta<F(3,2))
    ck('profile_geometry','V_override',2*(F(3,5)+rho)+2*delta<Rv)
    ck('profile_geometry','full_support',F(3,4)-delta+b/2<3)
    ck('profile_geometry','boxes_disjoint',F(11,10)>2*rho)
    ck('profile_geometry','remove_override_volumes',0<2*rho<1)
    # Actual periodic-source integrals, including arbitrary rational phases.
    centers=[F(0),F(-1,2)-rho,F(-1,2)+rho,F(3,5)-rho,F(3,5)+rho,F(3,4)-delta,
             F(-3,4)+delta,F(1,97),F(-11,101)]
    for center in centers:
        for side in [Ru,Rv]:
            ck('period_integrals','exact_UV_q',integral(M,center,side)==side)
        for side in [F(1),F(6,5),F(13,10),F(1499,1000),F(3,2)]:
            value=integral(M,center,side)
            ck('period_integrals','source_error_tau',abs(value-side)<=tau)
            ck('period_integrals','actual_q_band',F(15,16)<=value/side<=F(17,16))
    ck('period_integrals','full_source_mass_first_coordinate',integral(M,0,F(6))==6)
    ck('period_integrals','pulse_Y_value',integral(M,0,2*delta)==M*2*delta)
    separation=F(11,10)-2*rho
    ck('old_gates','exterior',separation>F(21,20))
    ck('old_gates','max_coordinate',separation>F(1,2)+2*rho)
    ck('old_gates','reverse_center_miss',separation>Rv/2)
    ck('old_gates','outside_radius_ratio',Rv<F(3,4)*Ru)
    firstlo=F(29,20)-4*rho; otherlo=F(1,4)-4*rho
    total=firstlo+(n-1)*otherlo
    ck('old_gates','positive_excess_coordinates',otherlo>0 and firstlo>0)
    ck('old_gates','whole_box_excess_uniform',total>=F(625299,250))
    ck('old_gates','strict_Bplus_complement',total-Tplus>2000)
    ck('old_gates','legacy_tiny_threshold_complement',firstlo>F(19,4*n) and firstlo>F(361,64*n))
    pfirstlo=(F(21,40)-2*rho)/Rv
    potherlo=(F(9,8)-2*rho)/Rv
    pfirsthi=(F(21,40)+2*rho)/Rv
    potherhi=(F(9,8)+2*rho)/Rv
    ck('positive_overlap_split','positive_first_overlap_base',0<pfirstlo<=pfirsthi<F(1,2))
    ck('positive_overlap_split','positive_other_overlap_base',0<potherlo<=potherhi<1)
    ck('positive_overlap_split','factored_p_lower_positive',n>1 and pfirstlo>0 and potherlo>0)
    ck('positive_overlap_split','complement_lower_half',pfirsthi<F(1,2) and potherhi<1)
    ck('positive_overlap_split','positive_excess',M-1>0)
    ck('positive_overlap_split','probe_positive_factors',2*delta>0 and 2*rho>0 and Ru>Rv>0 and F(16,15)*(1+n)>0)
    rows.append(dict(M=str(M),delta=str(delta),rho=str(rho),excess=str(M-1),
         p_lower_factored=[str(pfirstlo),str(potherlo),n-1],
         p_upper_less_than_half=True,retained_excess_lower='(M-1)/2',
         sum_excess_lower=str(total)))
print(json.dumps(dict(status='PASS',assertions=count,stage_counts=dict(counts),n=n,H=str(H),past_lower=str(past),Tplus=str(Tplus),profiles=rows,
    scope='Exact scalar margins and actual 1D periodic integrals. Analytic proof supplies arbitrary real M>=2 and positive full-source/receiver probe. No huge p power evaluated; no significant global fraction or upper bound certified.'),sort_keys=True,indent=2))
