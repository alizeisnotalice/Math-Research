#!/usr/bin/env python3
"""Full-space receiver probes for genuine midpoint Cartesian atomic grids.
The mn coordinate distances compress exact integer arrival counts. No spatial
or time-scale cutoff is used. Decimal checks are numerical, not interval proofs.
Run with --pilot for 256/512 sample stages; default includes fixed refinements.
"""
from fractions import Fraction as F
from decimal import Decimal as D, localcontext
from itertools import product
from pathlib import Path
import argparse, math, random, json, time
Q=math.exp(-1); C=1-Q

def geometry(n,m,x):
    assert n>0 and m>0 and m&(m-1)==0
    pairs=[v.as_integer_ratio() for v in x]
    bits=max((2*m).bit_length()-1,*(d.bit_length()-1 for a,d in pairs));R=1<<bits
    xs=[a<<(bits-(d.bit_length()-1)) for a,d in pairs]
    sites=[(2*j+1-m)*(R//(2*m)) for j in range(m)]
    events=sorted((abs(xi-y),i) for i,xi in enumerate(xs) for y in sites)
    counts=[0]*n;prev=0;rows=[];k=0
    while k<len(events):
        r=events[k][0]
        while k<len(events) and events[k][0]==r:
            counts[events[k][1]]+=1;k+=1
        count=math.prod(counts)
        if count>prev:rows.append((r,count-prev,count));prev=count
    assert prev==m**n
    return rows,R,xs

def cap_data(n,m,rows,R,H):
    N=m**n;Rp=R**n;vols=[];bestc=0;bestv=1
    if rows[0][0]==0:return False,(False,False),None,None
    for r,jump,count in rows:
        v=(2*r)**n;vols.append(v)
        if count*bestv>bestc*v:bestc,bestv=count,v
    num=bestc*Rp*H.denominator;den=N*bestv*H.numerator
    cap=num<=den
    bands=tuple(num*K>den for K in (2,16)) if cap else (False,False)
    return cap,bands,vols,(bestc,bestv)

def energy_float(n,N,rows):
    rmin=rows[0][0];events=[]
    for r,jump,count in rows:
        v=(r/rmin)**n
        events.extend(((v*Q,0,jump),(v,1,jump)))
    events.sort();enter=exit=0;i=0;terms=[]
    while i<len(events):
        left=events[i][0]
        while i<len(events) and events[i][0]==left:
            _,kind,jump=events[i]
            if kind:exit+=jump
            else:enter+=jump
            i+=1
        coef=(Q*enter-exit)/N
        right=events[i][0] if i<len(events) else math.inf
        ratio=left/right
        terms.append(.5*(coef/left)**2*(1-ratio)*(1+ratio))
    return math.fsum(terms)

def energy_decimal(n,N,rows,precision,gram=False):
    with localcontext() as ctx:
        ctx.prec=precision;q=(-D(1)).exp();c=1-q
        rmin=rows[0][0]
        data=[((D(r)/rmin)**n,D(jump)/N) for r,jump,count in rows]
        if gram:
            terms=[]
            for v,p in data:
                for w,z in data:
                    lo,hi=sorted((v,w));ratio=hi/lo
                    kernel=(2-q-q*ratio*ratio)/(2*hi*hi) if ratio<=1/q else -c*c/(2*q*hi*hi)
                    terms.append(p*z*kernel)
            return +sum(terms,D(0))
        events=[]
        for v,p in data:events.extend(((v*q,p*q),(v,-p)))
        events.sort();coef=D(0);ans=D(0);i=0
        while i<len(events):
            left=events[i][0]
            while i<len(events) and events[i][0]==left:coef+=events[i][1];i+=1
            ratio=left/events[i][0] if i<len(events) else D(0)
            ans+=(coef/left)**2*(1-ratio*ratio)/2
        return +ans

def evaluate(n,m,H,beta,x,guard=False):
    N=m**n;rows,R,xs=geometry(n,m,x)
    cap,bands,vols,maxpair=cap_data(n,m,rows,R,H)
    if maxpair is None:return dict(cap=False,energy_score=0.,diagonal_score=0.,tie_fee_score=0.,strict_tie_cross_score=0.,raw_diagonal_score=0.,band_scores=[0.,0.],arrival_count=len(rows))
    rmin=rows[0][0];Rp=R**n
    supports=[v*N*H.numerator>=Rp*H.denominator for v in vols]
    invs=[(rmin/r)**n for r,jump,count in rows]
    atomcore=math.fsum((jump/N)/N*inv*inv for (r,jump,count),inv,support in zip(rows,invs,supports) if support)
    vmin=(2*rmin/R)**n;origin=max(abs(z) for z in xs)
    inner=(2*origin)**n*H.numerator<=Rp*H.denominator
    globalcore=.5*(float(H)*vmin)**2 if inner else .5*(rmin/origin)**(2*n)
    denom=(1-beta)*atomcore+beta*globalcore
    if not cap:
        out=dict(cap=False,energy_score=0.,diagonal_score=0.,tie_fee_score=0.,strict_tie_cross_score=0.,raw_diagonal_score=0.,band_scores=[0.,0.],arrival_count=len(rows))
    else:
        assert all(supports) and denom>0
        ecore=energy_float(n,N,rows);score=ecore/denom
        bound=C*N/(1-beta)
        assert 0<=score<=bound*(1+1e-10)
        bs=[float(H)**2*vmin*vmin/(K*denom) if flag else 0. for K,flag in zip((2,16),bands)]
        for K,b in zip((2,16),bs):assert b<=N*K/(1-beta)*(1+1e-10)
        tiecore=math.fsum((jump/N)**2*inv*inv for (r,jump,count),inv in zip(rows,invs))
        tief= tiecore/denom;rawdiag=atomcore/denom
        assert tief<=N/(1-beta)*(1+1e-10) and tief>=rawdiag*(1-1e-12)
        if beta==0:assert tief>=1-1e-12
        out=dict(cap=True,energy_score=score,diagonal_score=C*rawdiag,tie_fee_score=tief,strict_tie_cross_score=max(0.,tief-rawdiag),raw_diagonal_score=rawdiag,band_scores=bs,arrival_count=len(rows))
    if guard:
        f=energy_float(n,N,rows);a=energy_decimal(n,N,rows,120);b=energy_decimal(n,N,rows,180)
        with localcontext() as ctx:
            ctx.prec=180
            err=abs(D.from_float(f)-b)/b;perr=abs(a-b)/b
            atomD=sum((D(jump)/D(N)**2*(D(rmin)/r)**(2*n) for (r,jump,count),support in zip(rows,supports) if support),D(0))
            vD=(D(2*rmin)/R)**n
            globalD=(D(H.numerator)/H.denominator*vD)**2/2 if inner else (D(rmin)/origin)**(2*n)/2
            atomerr=abs(D.from_float(atomcore)-atomD)/atomD if atomD else D(0)
            globalerr=abs(D.from_float(globalcore)-globalD)/globalD if globalD else D(0)
            betaD=D.from_float(beta);denomD=(1-betaD)*atomD+betaD*globalD
            expected_score=b/denomD if cap else D(0)
            scoreerr=abs(D.from_float(out['energy_score'])-expected_score)/expected_score if expected_score else D(0)
            tieD=sum(((D(jump)/N)**2*(D(rmin)/r)**(2*n) for r,jump,count in rows),D(0))
            expected_tie=tieD/denomD if cap else D(0)
            tieerr=abs(D.from_float(out['tie_fee_score'])-expected_tie)/expected_tie if expected_tie else D(0)
            expected_bands=[(D(H.numerator)/H.denominator*vD)**2/(K*denomD) if flag else D(0) for K,flag in zip((2,16),bands)]
            banderrs=[abs(D.from_float(score)-target)/target if target else D(0) for score,target in zip(out['band_scores'],expected_bands)]
        assert err<D('2e-9') and perr<D('1e-100')
        assert atomerr<D('2e-12') and globalerr<D('2e-12')
        assert scoreerr<D('2e-9') and tieerr<D('2e-12') and all(err<D('2e-12') for err in banderrs)
        out['guard']=dict(n=n,m=m,N=N,H=str(H),beta=beta,cap=cap,receiver_exact=[str(F(v)) for v in x],arrival_count=len(rows),M_exact=str(F(maxpair[0]*Rp,N*maxpair[1])),energy_float_vs_decimal180_relative_error=str(err),decimal120_vs180_relative_error=str(perr),atom_density_float_vs_decimal180_relative_error=str(atomerr),global_density_float_vs_decimal180_relative_error=str(globalerr),atom_density_core=atomcore,global_density_H_core=globalcore,all_atom_supports_on_G_checked=cap,normalized_energy_decimal180=str(expected_score),normalized_energy_float_vs_decimal180_relative_error=str(scoreerr),normalized_tie_fee_decimal180=str(expected_tie),normalized_tie_fee_float_vs_decimal180_relative_error=str(tieerr),normalized_cap_band_decimal180=[str(v) for v in expected_bands],normalized_cap_band_float_vs_decimal180_relative_errors=[str(v) for v in banderrs])
    return out

def sample(n,m,H,beta,rng):
    global_component=rng.random()<beta
    U=rng.random()
    while U==0:U=rng.random()
    if global_component:
        inner=rng.getrandbits(1)==0
        logv=-math.log(float(H))+(math.log(U) if inner else -math.log(U))
        center=[0.]*n;component='global_inner' if inner else 'global_tail'
    else:
        logv=-n*math.log(m)-math.log(float(H))-math.log(U)
        center=[(2*rng.randrange(m)+1-m)/(2*m) for i in range(n)];component='atom'
    side=math.exp(logv/n);face=rng.randrange(n);sign=1 if rng.getrandbits(1) else -1
    x=tuple(center[i]+side*(sign*.5 if i==face else rng.random()-.5) for i in range(n))
    return x,component

def summarize(values,bound):
    S=len(values);mean=math.fsum(values)/S
    var=math.fsum((v-mean)**2 for v in values)/(S-1)
    radius=bound*math.sqrt(math.log(40)/(2*S))
    return dict(estimate=mean,sample_standard_error=math.sqrt(var/S),sample_variance=var,score_upper_bound=bound,formal_pointwise_95_Hoeffding_radius=radius,formal_pointwise_95_Hoeffding_interval=[max(0.,mean-radius),min(bound,mean+radius)],maximum_observed_score=max(values),minimum_observed_score=min(values),nonzero_score_count=sum(v!=0 for v in values),positive_score_count=sum(v>0 for v in values),coefficient_of_variation=math.sqrt(var)/mean if mean else None)

def bilateral_integration_guards():
    """Finite one-dimensional analytic antiderivatives, not interval certificates."""
    cases=[('single',[('0','1')],'1'),('two',[('0','0.5'),('1','0.5')],'2'),('unequal',[('-1','0.125'),('0','0.625'),('0.5','0.25')],'3'),('nested',[('0','0.25'),('0.03125','0.25'),('0.125','0.25'),('1','0.25')],'4'),('lattice',[(str(k),'0.125') for k in range(8)],'0.5')]
    rows=[]
    for name,data,h in cases:
      vals=[]
      for precision in (70,110):
       with localcontext() as ctx:
        ctx.prec=precision
        source=[(D(y),D(p)) for y,p in data];H=D(h);one=D(1);e=one.exp();q=1/e;c=1-q
        intervals=[]
        for i in range(len(source)):
         mass=D(0)
         for j in range(i,len(source)):
          mass+=source[j][1];a=source[j][0]-mass/(2*H);b=source[i][0]+mass/(2*H)
          if a<b:intervals.append((a,b))
        ends={t for ab in intervals for t in ab}
        def good(x):return not any(a<x<b for a,b in intervals)
        def mass(center,radius,closed=True):return sum((p for y,p in source if abs(center-y)<=radius),D(0)) if closed else sum((p for y,p in source if abs(center-y)<radius),D(0))
        def pieces(breaks):
         bs=sorted(set(breaks));return list(zip([None]+bs,bs+[None]))
        def midpoint(a,b):return b-1-abs(b) if a is None else a+1+abs(a) if b is None else (a+b)/2
        def integral(y,a,b):
         assert a!=y and b!=y
         left=D(0) if a is None else -1/(4*(a-y))
         right=D(0) if b is None else -1/(4*(b-y))
         return right-left
        bilateral=D(0)
        for yi,pi in source:
         breaks=set(ends)|{yi}
         for s in (one,e,q):
          breaks.update(yi+(b-yi)/s for b in ends)
          for yj,pj in source:
           for sign in (one,-one):
            if s!=sign:breaks.add(yi+(yj-yi)/(s-sign))
         for a,b in pieces(breaks):
          x=midpoint(a,b);r=abs(x-yi);xp=yi+e*(x-yi);xm=yi+q*(x-yi)
          coeff=pi*(2*int(good(x))*mass(x,r)-int(good(xp))*mass(xp,r,False)-int(good(xm))*mass(xm,r)-pi*int(good(x)))
          if coeff:bilateral+=coeff*integral(yi,a,b)
        breaks=set(ends)|{y for y,p in source}
        for i,(yi,pi) in enumerate(source):
         for yj,pj in source[i+1:]:
          breaks.add((yi+yj)/2)
          for ratio in (e,q):
           for sign in (one,-one):breaks.add((yi-sign*ratio*yj)/(1-sign*ratio))
        energy=D(0)
        for a,b in pieces(breaks):
         x=midpoint(a,b)
         if not good(x):continue
         coeff=[c*p*p for y,p in source]
         for i,(yi,pi) in enumerate(source):
          for j in range(i+1,len(source)):
           yj,pj=source[j];small,big=(i,j) if abs(x-yi)<=abs(x-yj) else (j,i)
           ratio=abs(x-source[big][0])/abs(x-source[small][0])
           if ratio<=e:coeff[small]-=q*pi*pj;coeff[big]+=(2-q)*pi*pj
           else:coeff[big]-=c*c/q*pi*pj
         energy+=sum((a_i*integral(source[i][0],a,b) for i,a_i in enumerate(coeff) if a_i),D(0))
        error=abs(energy-bilateral)/max(abs(energy),D('1e-100'))
        assert error<D(10)**(-precision+12),(name,precision,energy,bilateral,error)
        vals.append((+energy,+bilateral,+error))
      with localcontext() as ctx:
       ctx.prec=110
       precision_error=abs(vals[0][0]-vals[1][0])/abs(vals[1][0]);assert precision_error<D('1e-55')
      rows.append(dict(source=name,atoms=data,H=h,precision_digits=[70,110],cap_energy_antiderivative=str(vals[1][0]),bilateral_antiderivative=str(vals[1][1]),relative_difference=str(vals[1][2]),precision_relative_difference=str(precision_error),source_ties='Distinct one-dimensional atoms have equal radii only at isolated midpoint receivers; the subtraction pi here is a.e. valid. General tensor identity requires tied batch mass.',scope='One-dimensional actual source, cap is union-complement of exact block intervals; piecewise inverse-square antiderivatives, no receiver box cutoff. Decimal guards are not outward-rounded certificates.'))
    return rows


def fixed_atom_tie_continuity_guards():
    """A genuine two-dimensional source; no integration claim from one receiver."""
    rows=[]
    for k in (4,8,16,32,64,128):
      answers=[]
      for precision in (100,180):
       with localcontext() as ctx:
        ctx.prec=precision;e=D(1).exp();q=1/e;c=1-q
        eps=D(2)**(-k);v1=D(16);v2=(4-2*eps)**2
        # y1=(0,0), y2=(eps,1), x=(2,1/2); weights 1/2.
        small,big=v2,v1
        cross=(2-q-q*(big/small)**2)/(2*big*big)
        energy=c*(1/(v1*v1)+1/(v2*v2))/4+cross/2
        limiting=c/256
        diag=(1/(v1*v1)+1/(v2*v2))/4
        # At eps>0 all radii are distinct; at eps=0 the batch has mass1.
        tie=diag;limiting_perturbed_tie=D(1)/512;unperturbed_tie=D(1)/256
        M=max(D('0.5')/v2,1/v1)
        assert M==D(1)/16 and M<1
        assert energy>0 and tie==diag
        assert abs(energy-limiting)/limiting<10*eps
        assert abs(tie-limiting_perturbed_tie)/limiting_perturbed_tie<10*eps
        answers.append((+energy,+tie,+limiting,+eps,+M))
      with localcontext() as ctx:
       ctx.prec=180
       relative=abs(answers[0][0]-answers[1][0])/answers[1][0]
       assert relative<D('1e-95')
      a=answers[1]
      rows.append(dict(n=2,atoms=[['0','0','1/2'],[f'2^-{k}','1','1/2']],receiver=['2','1/2'],H='1',epsilon_power=k,M_exact='1/16',energy_decimal=str(a[0]),energy_limit=str(a[2]),tie_fee_integrand_decimal=str(a[1]),perturbed_tie_limit='1/512',exactly_tied_integrand='1/256',precision_relative_difference=str(relative),interpretation='Energy continuous at fixed atom count; exact-tie term jumps. Point guards support separately proved fixed-N DCT, not numerical integration.'))
    return rows


def validation():
    explicit=[];high=[];boundary=[];one=[];open_ties=[]
    for n,m in ((1,2),(1,4),(2,2),(2,4),(3,2),(3,4),(4,2)):
        rng=random.Random(591000+n*100+m)
        for trial in range(5):
            x=tuple(rng.uniform(-1,1) for i in range(n));rows,R,xs=geometry(n,m,x)
            sites=[(2*j+1-m)*(R//(2*m)) for j in range(m)]
            hist={}
            for y in product(sites,repeat=n):
                r=max(abs(xs[i]-y[i]) for i in range(n));hist[r]=hist.get(r,0)+1
            assert [(r,j) for r,j,c in rows]==sorted(hist.items())
            explicitrows=[];count=0
            for r,j in sorted(hist.items()):count+=j;explicitrows.append((r,j,count))
            assert rows==explicitrows
            e=energy_decimal(n,m**n,rows,120);g=energy_decimal(n,m**n,rows,120,True)
            with localcontext() as ctx:
                ctx.prec=120;err=abs(e-g)/e
            assert err<D('1e-105')
            # Multiplicity diagonal is jump/N^2, distinct from squared jump mass.
            rmin=rows[0][0]
            compressed=math.fsum(j/(m**n)**2*(rmin/r)**(2*n) for r,j,c in rows)
            enumerated=math.fsum(1/(m**n)**2*(rmin/max(abs(xs[i]-y[i]) for i in range(n)))**(2*n) for y in product(sites,repeat=n))
            assert abs(compressed-enumerated)<=1e-14*compressed
            out=evaluate(n,m,F(4),.5,x,True)
            explicit.append(dict(n=n,m=m,trial=trial,arrival_multiset_exact=True,diagonal_multiplicity_checked=True,event_vs_gram120_relative_error=str(err),numeric_guard=out['guard']))
    for n,m in ((8,4),(16,8),(32,16),(64,2),(64,4),(64,8),(64,16)):
        for beta in (0.,.5):
            rng=random.Random(592000+100*n+m+int(1000*beta));x,component=sample(n,m,F(16),beta,rng)
            out=evaluate(n,m,F(16),beta,x,True)
            high.append(dict(component=component,**out['guard']))
    for n,m in ((1,2),(2,2),(4,2),(8,2),(16,4),(64,16)):
        N=m**n;x=(0.,)*n;rows,R,xs=geometry(n,m,x)
        Mtarget=2**n
        cap,bands,vols,pair=cap_data(n,m,rows,R,F(Mtarget))
        M=F(pair[0]*R**n,N*pair[1]);assert M==Mtarget and cap
        rejected=cap_data(n,m,rows,R,F(Mtarget)-F(1,2))[0];assert not rejected
        boundary.append(dict(n=n,m=m,N=N,receiver='origin',M_exact=str(M),H_equal=str(Mtarget),cap_equality_accepted=True,cap_below_rejected=True,arrival_count=len(rows)))
    for n in (1,2,16,64):
        rng=random.Random(593000+n)
        for H in (F(1,4),F(1),F(16)):
            errors=[]
            for trial in range(8):
                x,component=sample(n,1,H,0.,rng);out=evaluate(n,1,H,0.,x)
                assert out['cap'];errors.append(abs(out['energy_score']-C))
            assert max(errors)<1e-12
            one.append(dict(n=n,m=1,H=str(H),samples=8,max_point_score_minus_oneatom_constant=max(errors)))
    for x in ((1.,.125),(1.,.1875),(1.125,.125)):
        rows,R,xs=geometry(2,2,x);assert len(rows)==2 and all(j==2 for r,j,c in rows)
        out=evaluate(2,2,F(4),.5,x,True)
        open_ties.append(dict(receiver=[str(F(v)) for v in x],group_multiplicities=[j for r,j,c in rows],source_diagonal_counting='DeltaC/N^2',group_energy_mass='DeltaC/N',tie_region='x1>3/4 and abs(x2)<1/4 is an open positive-measure region of equal source radii',numeric_guard=out['guard']))
    return dict(fixed_atom_tie_continuity_point_guards=fixed_atom_tie_continuity_guards(),bilateral_allspace_antiderivative_guards=bilateral_integration_guards(),open_receiver_region_equal_radius_guards=open_ties,explicit_compression_guards=explicit,high_dimension_decimal_guards=high,origin_equal_distance_cap_guards=boundary,oneatom_guards=one,decimal_precision_digits=[120,180],outward_rounding=False)

def plan(pilot=False):
    cases=[]
    for n in (2,4,8,16,32,64):
        for m in (2,4):
            for H in (1,4):
                for beta in (0.,.5):
                    S=256 if n==64 else 512
                    if not pilot and H==4 and (beta==.5 or n>=16):S=4096 if n>=8 else 1024
                    cases.append((n,m,H,beta,S,'base_dimension_grid'))
    for n in (8,16,32,64):
        for m in (2,4):cases.append((n,m,16,.5,512 if pilot else 2048,'height_pressure'))
    for n in (16,32,64):
        for m in (8,16):
            for H in (4,16):cases.append((n,m,H,.5,256 if pilot else 2048,'grid_window_pressure'))
    return cases

def run_case(n,m,H,beta,S,stage):
    H=F(H);N=m**n;allvalues=[[] for j in range(8)];seedrows=[];extremes={name:[] for name in ('energy','band_K2','band_K16','tie_fee')}
    pilotS=256 if n==64 and stage=='base_dimension_grid' or stage=='grid_window_pressure' else 512
    for replicate in (0,1):
        seed=59000000+n*100000+m*1000+int(H)*10+int(beta*2)+replicate*100000000
        rng=random.Random(seed);values=[[] for j in range(8)];accept=0;components={k:dict(samples=0,cap_accepted=0,energy_sum=0.) for k in ('atom','global_inner','global_tail')};arrivals=[]
        for t in range(S):
            x,component=sample(n,m,H,beta,rng);out=evaluate(n,m,H,beta,x)
            accept+=out['cap'];arrivals.append(out['arrival_count']);comp=components[component];comp['samples']+=1;comp['cap_accepted']+=out['cap'];comp['energy_sum']+=out['energy_score']
            row=[out['energy_score'],out['diagonal_score'],out['energy_score']-out['diagonal_score'],*out['band_scores'],out['tie_fee_score'],out['strict_tie_cross_score'],out['raw_diagonal_score']]
            for j,v in enumerate(row):values[j].append(v);allvalues[j].append(v)
            for metric,value in zip(('energy','band_K2','band_K16','tie_fee'),(row[0],row[3],row[4],row[5])):
                top=extremes[metric]
                if len(top)<3 or value>top[-1]['score']:
                    top.append(dict(score=value,seed=seed,sample_index_zero_based=t,component=component,receiver_exact=[str(F(z)) for z in x],cap=out['cap'],energy_score=out['energy_score'],tie_fee_score=out['tie_fee_score'],band_scores=out['band_scores']))
                    top.sort(key=lambda r:(r['score'],r['seed'],r['sample_index_zero_based']),reverse=True);del top[3:]
        names=('cap_energy','source_diagonal','signed_offdiagonal','cap_band_K2','cap_band_K16','tie_fee','strict_tie_cross_fee','raw_source_diagonal')
        bounds=(C*N/(1-beta),C/(1-beta),C*N/(1-beta),N*2/(1-beta),N*16/(1-beta),N/(1-beta),N/(1-beta),1/(1-beta))
        summaries={name:summarize(v,b) for name,v,b in zip(names,values,bounds)}
        # Offdiagonal can be negative. Hoeffding needs interval length B+C/(1-beta).
        summaries['signed_offdiagonal']['formal_pointwise_95_Hoeffding_interval']=None
        summaries['signed_offdiagonal']['formal_pointwise_95_Hoeffding_radius']=None
        pilot_energy=summarize(values[0][:pilotS],bounds[0])
        seedrows.append(dict(pilot_prefix_samples=min(S,pilotS),pilot_prefix_cap_energy=pilot_energy,seed=seed,samples=S,cap_accepted=accept,cap_acceptance=accept/S,components=components,arrival_count_mean=math.fsum(arrivals)/S,arrival_count_max=max(arrivals),**summaries))
    totals={name:summarize(v,b) for name,v,b in zip(names,allvalues,bounds)}
    totals['signed_offdiagonal']['formal_pointwise_95_Hoeffding_interval']=None;totals['signed_offdiagonal']['formal_pointwise_95_Hoeffding_radius']=None
    pilotvalues=[]
    for replicate in (0,1):pilotvalues.extend(allvalues[0][replicate*S:replicate*S+min(S,pilotS)])
    pilot_summary=summarize(pilotvalues,bounds[0])
    return dict(extreme_receivers=extremes,pilot_prefix_samples=len(pilotvalues),pilot_prefix_cap_energy=pilot_summary,n=n,m=m,N=N,source_mass=1,H=str(H),global_mixture_weight=beta,stage=stage,samples=2*S,cap_accepted=sum(row['cap_accepted'] for row in seedrows),cap_acceptance=sum(row['cap_accepted'] for row in seedrows)/(2*S),seed_rows=seedrows,**totals)

def audit_global_extremes(cases):
    audited={};ranks={}
    for metric in ('energy','band_K2','band_K16','tie_fee'):
        records=[(record['score'],case,record) for case in cases for record in case['extreme_receivers'][metric]]
        records.sort(key=lambda t:(t[0],t[1]['n'],t[1]['m'],t[1]['H'],t[1]['global_mixture_weight'],t[2]['seed'],t[2]['sample_index_zero_based']),reverse=True)
        rank=[]
        for score,case,record in records[:3]:
            key=(case['n'],case['m'],case['H'],case['global_mixture_weight'],record['seed'],record['sample_index_zero_based'])
            if key not in audited:
                x=tuple(float(F(z)) for z in record['receiver_exact']);out=evaluate(case['n'],case['m'],F(case['H']),case['global_mixture_weight'],x,True)
                assert out['cap']==record['cap'] and out['energy_score']==record['energy_score'] and out['tie_fee_score']==record['tie_fee_score'] and out['band_scores']==record['band_scores']
                audited[key]=dict(case_key=list(key[:4]),seed=record['seed'],sample_index_zero_based=record['sample_index_zero_based'],component=record['component'],numeric_guard=out['guard'])
            rank.append(dict(case_key=list(key[:4]),seed=record['seed'],sample_index_zero_based=record['sample_index_zero_based'],score=score))
        ranks[metric]=rank
    return dict(global_top3_by_metric=ranks,distinct_receivers_audited=list(audited.values()),method='Exact dyadic cap plus independent Decimal120/180 event integration and Decimal180 complete atom/global densities and normalized energy/tie/band scores; not interval certificates.')

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--pilot',action='store_true');args=parser.parse_args();start=time.monotonic()
    guards=validation();print('validation PASS',flush=True);cases=[]
    for config in plan(args.pilot):
        row=run_case(*config);cases.append(row)
        print('case',row['n'],row['m'],row['H'],row['global_mixture_weight'],row['samples'],'E',round(row['cap_energy']['estimate'],8),'SE',round(row['cap_energy']['sample_standard_error'],8),'accept',row['cap_accepted'],flush=True)
    outlier_audit=audit_global_extremes(cases);print('outlier audit PASS',len(outlier_audit['distinct_receivers_audited']),flush=True)
    data=dict(outlier_audit=outlier_audit,schema='round059_tensor_fullspace_v1',pilot=args.pilot,normalization='E_G/(H W), W=1',constant_oneatom=C,formulas=dict(sites='(2j+1-m)/(2m), 0<=j<m, mu uniform over true Cartesian grid, N=m^n',arrival='C(r)=product_i count{j:abs(x_i-y_j)<=r}; grouped jump mass DeltaC/N',maximal='max positive arrivals C(r)/(N*(2r)^n), exact dyadic rational receiver comparisons',energy='D(t)=C_time/t, enter volume vi/e with mass pi/e, exit vi with mass -pi; E=sum C_time^2/2*(left^-2-right^-2)',atom_density='q_atom=1/(N^2 H) sum_i vi^-2 1{vi>=1/(N H)}; count multiplicity is DeltaC, not DeltaC squared',global_density='a=1/H; q0=1/(2a) for v0<=a, a/(2v0^2) for v0>a; radial dx=dv d_sigma; inner and tail integrate 1/2 each',mixture='q=(1-beta)q_atom+beta q0; beta=0 or 1/2; each component full density evaluated',tie_fee='J_H/H: grouped sum (DeltaC/N)^2/vi^2 integrated on G, divided by H; actual source diagonal uses DeltaC/N^2. strict_tie_cross_fee=J_H/H minus raw_source_diagonal',bounds='on G tie fee/(Hq)<=N/(1-beta); raw source diagonal/(Hq)<=1/(1-beta); energy/(Hq)<=c N/(1-beta), diagonal/(Hq)<=c/(1-beta), band_lambda/(q)<=N K/(1-beta), c=1-exp(-1)',bands='lambda=H/K, lambda<M<=H only; these sampled cap bands are not the full weak constant'),evidence_limits=['Actual finite positive atomic product sources and Lebesgue receivers; no source-measure replacement, spatial cutoff or time grid.', 'Exact integers certify arrival multiplicities and cap at binary floating receiver coordinates; proposal roots and energy are floating approximations.', 'Decimal 120/180 agreement and event/Gram agreement are numerical guards, not outward-rounded certificates.', 'Sample SE and displayed Hoeffding intervals describe ideal independent importance sampling with formal score bounds; no machine-bias or simultaneous guarantee.', 'Huge N makes score bounds and rare-event diagnostics essential; zero or small sampled contributions cannot certify small integrals.', 'n, grid window parameter m and H are independent pressure axes; no exponent fit and no arbitrary-source theorem or continuous-grid migration claim.'],counts=dict(cases=len(cases),seed_rows=2*len(cases),principal_receivers=sum(c['samples'] for c in cases),explicit_compression_guards=len(guards['explicit_compression_guards']),high_dimension_decimal_guards=len(guards['high_dimension_decimal_guards']),open_tie_guards=len(guards['open_receiver_region_equal_radius_guards']),bilateral_antiderivative_guards=len(guards['bilateral_allspace_antiderivative_guards']),fixed_atom_tie_continuity_point_guards=len(guards['fixed_atom_tie_continuity_point_guards']),extreme_receivers_audited=len(outlier_audit['distinct_receivers_audited'])),validation=guards,cases=cases)
    path=Path(__file__).with_name('results.json');path.write_text(json.dumps(data,indent=2,sort_keys=True)+'\n');print('PASS',data['counts'],'runtime_seconds',round(time.monotonic()-start,3),flush=True)
if __name__=='__main__':main()
