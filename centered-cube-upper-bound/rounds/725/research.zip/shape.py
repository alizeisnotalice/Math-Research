"""Check union volumes of boxes with any k exceptional axes, no simplex tail."""
import json
from math import comb
from fractions import Fraction as F
from flint import arb, ctx

ctx.prec = 192

def exact_volume(n, k, s, b):
    return sum(comb(n,j)*(2*(1-b))**j*(2*(s+b))**(n-j) for j in range(k+1))

def partition_count(n,k):
    # Grid cells of unit side in a box with ordinary half-width 2,
    # exceptional half-width 3. Count by the number of outside axes.
    import itertools
    return sum(sum(abs(2*x+1)>4 for x in v)<=k
               for v in itertools.product(range(-3,3),repeat=n))

small=[]
for n in range(1,6):
    for k in range(n+1):
        v=exact_volume(n,k,F(2),F(0))
        assert v==partition_count(n,k)
        small.append([n,k,int(v)])
# Baseline s=1/6 is slightly smaller than the worst allowable s/R=1/(2e).
# This increases the ratio of the union to baseline volume.
large=[]
for power in [20,24,32,40,48]:
    n=2**power
    u=256*2**(power//2)
    b=arb(u)/(512*n)
    k=int(u//(16*(power+3)))
    # Integrated binomial bound on the union. The exact formula above
    # implies the sum is <= (k+1)(6en/k)^k when k>=1.
    logratio=n*(1+6*b).log()+(arb(k+1)).log()+k*(6*arb(1).exp()*n/k).log()
    assert logratio<u/2
    old=F(u*u,128*n)
    total=F(3*k,4)+(n-k)*F(u,512*n)
    large.append(dict(n=n,u=u,k=k,full_gap=str(total),old_cutoff=str(old),
                      exceeds_old=total>old,log_ratio_over_u=str(logratio/u)))
print(json.dumps(dict(precision=ctx.prec,grid=small,examples=large),indent=2))
