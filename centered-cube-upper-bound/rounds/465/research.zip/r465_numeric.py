from fractions import Fraction as F
from pathlib import Path
from collections import deque,Counter
import json,sys,platform,time
ROOT=Path(__file__).resolve().parent
start=time.perf_counter();checks=0
def ck(z):
 global checks
 assert z
 checks+=1
H=F(1,100);R=F(6,5)
inputs=[('nested_full_reallocation',[0,1],[F(1,2),0],[1,1]),('nested_Hall_deficit',[0,1],[F(1,2),0],[F(1,2),F(3,2)]),('three_packet_chain',[0,1,2],[F(1,2),F(3,2),1],[1,1,1])]
models=[]
for name,sources,parents,d in inputs:
 sources=list(map(F,sources));parents=list(map(F,parents));d=list(map(F,d));B=[];margins=[]
 for a in parents:
  br=[];mr=[]
  for x in sources:
   hi=abs(a-x)+2*H;lo=max(F(0),abs(a-x)-2*H)
   if hi<R/2:br.append(1);mr.append(R/2-hi)
   else:ck(lo>R/2);br.append(0);mr.append(lo-R/2)
  B.append(br);margins.append(mr)
 for centers in (sources,parents):
  for i,x in enumerate(centers):
   for y in centers[i+1:]:ck(abs(x-y)>2*H)
 f=[F(1)]*len(sources);m=[sum(B[j][i]*f[i] for i in range(len(f))) for j in range(len(d))]
 pi=[[f[i]*B[j][i]/m[j] for i in range(len(f))] for j in range(len(d))]
 for row in pi:ck(sum(row)==1)
 a0=[[d[j]*pi[j][i] for i in range(len(f))] for j in range(len(d))]
 models.append(dict(name=name,sources=sources,parent_centers=parents,d=d,f=f,B=B,geometry_margins=margins,pi=pi,a0=a0))

def maxflow(model,M,Lambda):
 d=model['d'];f=model['f'];a0=model['a0'];J=len(d);I=len(f);src=0;rec=list(range(1,J+1));cols=list(range(J+1,J+I+1));sink=J+I+1;N=sink+1
 residual=[[F(0)]*N for _ in range(N)];original=[[F(0)]*N for _ in range(N)];adj=[[] for _ in range(N)]
 def edge(a,b,c):
  original[a][b]=c;residual[a][b]=c;adj[a].append(b);adj[b].append(a)
 for j in range(J):edge(src,rec[j],d[j])
 for j in range(J):
  for i in range(I):
   if a0[j][i]:edge(rec[j],cols[i],M*a0[j][i])
 for i in range(I):edge(cols[i],sink,Lambda*f[i])
 value=F(0);augmentations=0
 while True:
  prev=[None]*N;prev[src]=src;q=deque([src])
  while q and prev[sink] is None:
   u=q.popleft()
   for v in adj[u]:
    if prev[v] is None and residual[u][v]>0:prev[v]=u;q.append(v)
  if prev[sink] is None:break
  v=sink;path=[]
  while v!=src:path.append((prev[v],v));v=prev[v]
  delta=min(residual[u][v] for u,v in path);ck(delta>0)
  for u,v in path:residual[u][v]-=delta;residual[v][u]+=delta
  value+=delta;augmentations+=1
 primal=[[original[rec[j]][cols[i]]-residual[rec[j]][cols[i]] for i in range(I)] for j in range(J)]
 for j in range(J):
  ck(sum(primal[j])<=d[j]);ck(all(0<=primal[j][i]<=M*a0[j][i] for i in range(I)))
 for i in range(I):ck(sum(primal[j][i] for j in range(J))<=Lambda*f[i])
 ck(sum(map(sum,primal))==value)
 # Exhaustive graph cuts are independent of source-subset elimination.
 minimum=None;cutmask=None
 for mask in range(1<<(N-2)):
  Sset={src}|{k+1 for k in range(N-2) if mask>>k&1}
  cost=sum(original[u][v] for u in Sset for v in range(N) if v not in Sset)
  if minimum is None or cost<minimum:minimum=cost;cutmask=mask
 ck(value==minimum)
 return primal,value,minimum,augmentations

rows=[]
for model in models:
 J=len(model['d']);I=len(model['f']);total=sum(model['d'])
 for M in (F(1),F(3,2),F(2)):
  for Lambda in (F(1,2),F(1),F(3,2)):
   primal,value,graphcut,aug=maxflow(model,M,Lambda)
   subsets=[]
   for mask in range(1<<I):
    Bs=[i for i in range(I) if mask>>i&1];comp=[i for i in range(I) if not mask>>i&1]
    pis=[sum(model['pi'][j][i] for i in comp) for j in range(J)]
    terms=[model['d'][j]*max(F(0),1-M*pis[j]) for j in range(J)]
    defect=sum(terms)-Lambda*sum(model['f'][i] for i in Bs)
    subsets.append((defect,Bs,pis,terms))
   defect,Bs,pis,terms=max(subsets,key=lambda z:z[0]);ck(defect>=0)
   ck(total-value==defect)
   rowS=[j for j in range(J) if M*pis[j]<1]
   cut_source=Lambda*sum(model['f'][i] for i in Bs)
   cut_records=sum(model['d'][j] for j in range(J) if j not in rowS)
   cut_edges=sum(M*model['a0'][j][i] for j in rowS for i in range(I) if i not in Bs)
   cut=cut_source+cut_records+cut_edges
   ck(cut==value==graphcut);ck(total-cut==defect)
   phase='exploratory' if M==1 and Lambda==1 else ('pressure' if M==1 or Lambda==F(1,2) else 'expanded')
   positive_ratios=[primal[j][i]/model['a0'][j][i] for j in range(J) for i in range(I) if model['a0'][j][i]]
   ck(max(positive_ratios,default=F(0))<=M)
   rows.append(dict(geometry=model['name'],phase=phase,M=M,Lambda=Lambda,demand_total=total,source_capacities=[Lambda*f for f in model['f']],
    edge_capacities=[[M*a for a in rr] for rr in model['a0']],primal=primal,kept=value,deficit=defect,
    maximizing_source_subset=Bs,subset_pi_complement=pis,positive_deficit_row_terms=terms,
    cut_source_side_records=rowS,dual_cut_parts=dict(source_capacity=cut_source,excluded_record_demand=cut_records,edge_capacity=cut_edges),
    dual_cut_value=cut,all_graph_cut_min=graphcut,duality_gap=cut-value,subset_count=1<<I,augmentations=aug,
    max_unnormalized_distortion=max(positive_ratios,default=F(0))))
ck(len(rows)==27)
# Sanity: for M=2,Lambda=1 recover R464 unrestricted optima with capped certified primal availability.
expected={'nested_full_reallocation':F(2),'nested_Hall_deficit':F(3,2),'three_packet_chain':F(3)}
for row in rows:
 if row['M']==2 and row['Lambda']==1:ck(row['kept']==expected[row['geometry']])
out=dict(scope='Exact finite transport cut identity, actual interval wholeblock incidence; no continuous existence theorem or original target-cap/history claim',
 executable=sys.executable,python=platform.python_version(),checks=checks,geometries=models,source_halfwidth=H,center_halfwidth=H,parent_side=R,
 formula='total demand - maxflow = max_B [sum_j d_j(1-M*pi_j(Bcomplement))_+ - Lambda sum_{i in B} f_i]',
 phase_counts=dict(Counter(row['phase'] for row in rows)),cases=rows,
 caveats=['M is unnormalized edge distortion relative a0; no retained-conditional density bound asserted',
 'Lambda is abstract source capacity multiplier, not the project s=1+sqrt(n)',
 'Partial retained records do not preserve full parent/record marginal',
 'No original P demands or existence of target-cap allocation inferred'],
 compute_index=dict(status='complete',command='/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python r465_numeric.py',
 arithmetic='Fraction BFS residual augmenting paths, exhaustive all graph cuts, independent source-subset formula; no floating solver',seconds=time.perf_counter()-start))
(ROOT/'r465_numeric.json').write_text(json.dumps(out,default=str,indent=2)+'\n')
print(sys.executable,'Python',platform.python_version())
for name,*_ in inputs:
 print(name)
 for row in rows:
  if row['geometry']==name:print(' M',row['M'],'Lambda',row['Lambda'],'kept',row['kept'],'deficit',row['deficit'],'B',row['maximizing_source_subset'])
print('PASS',checks,'exact assertions;',len(rows),'fixed cases; phases',out['phase_counts'])
