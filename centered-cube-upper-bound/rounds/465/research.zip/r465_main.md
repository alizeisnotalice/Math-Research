# 第465轮：连续有界来源分配的精确缺额及厚父比较

## 原问题与本轮结论

一般n^(1/2+o(1))弱型目标仍未证明。本轮在同一实际保留流P上，将R464的有界来源分配可行性写成所有可测来源集合的精确判据，并证明与原双来源限制流的比较误差。完整实际需求未被替换为有限矩阵或任意历史；以下判据不等于已经满足目标容量。

固定mu=f dx、W<infty，nu=P_A、R=nu(E)，nu<=S sigma，pi_A=1_QA mu/m_A，kappa(dA,dx)=nu(dA)pi_A(dx)。原单比例带保证m_A>=q a^n>0，所有核可测，R<=SX<=S A_n W有限。取有限M>=1、Lambda>=0。

## 精确连续极值公式

令V(M,Lambda)为所有可测psi的最大保留质量，条件为
\[
0\le\psi\le M\ (\kappa\text{-a.e.}),\qquad
\int\psi(A,x)\pi_A(dx)\le1\ (\nu\text{-a.e.}),\qquad
(\psi\kappa)_x\le\Lambda\mu.
\]
则最大值实际达到，且
\[
\boxed{R-V(M,\Lambda)=
\sup_{B\ \mathrm{measurable}}
\left\{\int_E(1-M\pi_A(B^c))_+\nu(dA)-\Lambda\mu(B)\right\}.}
\]
右侧称delta(M,Lambda)；空B给0，故不需再取正部。固定输入的最大缺额集合B也达到；不声称随外部参数可测选择最优解。该式覆盖连续真实接收测度、任意L1来源和质量原子。

证明要点：0<=psi<=M的L∞(kappa)弱星紧集上，所有可测父集/来源集的边缘不等式与目标质量均弱星闭，因此最大保留量达到。任意t>V的不可行性可由有限个集合边缘约束见证；其有限维紧凸可达集加上边缘正松弛/目标负松弛锥仍闭，严格分离给非负简单对偶alpha(A),beta(x)。目标系数必须严格正，因为同样的约束预算与零目标属于该集合。归一化得到
\[
 V=\inf_{\alpha,\beta\ge0}
 \left[\int\alpha\,d\nu+\Lambda\int\beta\,d\mu
 +M\int(1-\alpha-\beta)_+\,d\kappa\right].
\]
可将alpha,beta截到[0,1]而不增费用。对t∈(0,1)取I_t={alpha<t}、B_t={beta>1−t}，对偶费用恰为
\[
\int_0^1[\nu(I_t^c)+\Lambda\mu(B_t)+M\kappa(I_t\times B_t^c)]dt.
\]
二值对偶给反向比较，得到连续cut等式。固定B逐父选择I={M pi_A(Bc)<1}便得到方框公式。对偶成本是弱星下半连续函数（正部积分为连续仿射式的上确界），紧对偶域上也达到。最优对偶的阈值割几乎处处达到最优，因此最大缺额集合存在。完整拓扑、零分支和量词见complement。没有把有限计算或未验证的一般输运强对偶作为证明。

## 对实际原记录与首入费用的回代

取达到V的psi，附加来源后旧记录边缘为r(A)P，r=E_pi psi<=1；删除量准确是delta。由来源列帽
\[
R\le\Lambda W+\delta(M,\Lambda).
\]
因此需要实际证明delta<=eta X，或同一原流的受控收缩。取Lambda=C_eta sqrt(n)polylog(n)本身不会使缺额自动变小。保持M有限使首入0原子仍至多2MS A_n/K² W；若使用全部来源容量LambdaW则不另加该原子费。所有原history保留，人工x不继承其资格。

## 厚父集合与原双来源的误差比较

令p_A=pi_A(B)，T_M(B)=int(1−M(1−p_A))_+dnu，R_BB=P{y,z∈B}。geometry附件证明对同一P的全部可测B，M>=2时
\[
T_M(B)\le R_{BB}+S e_M X\le R_{BB}+\frac S{2M}X,
\quad e_M=\max_{0\le p\le1}(Mp-M+1)_+(1-p^2).
\]
这里利用实际来源对静态帽，不假设受接受筛选后的两来源独立。可取M>=max(2,S/(2eta_0))将比较误差付为eta_0 X；M依赖必须保留。剩下仍需控制R_BB−Lambda mu(B)的全体集合上确界。

取B为全来源，该要求已包含原一般目标，故不把这一转换宣称降低了证明难度。它的作用是明确重分配所需的全部几何条件，避免用逐行强界代替整体容量。父对f1_B密度可比并不保持小接收者质量、秩和阶段历史，不能无条件调用受限输入的旧收据。现有严格局部来源价格仍仅S A_n mu(B)，根阶改进未证。

## 完整总账与验证

R433<=[S zeta+2S eps0/s+2S delta_rounding]X+R不变；此处用delta_rounding区分旧rounding参数与本轮最优缺额。全部母入口、宽距离、低pe、初始/删除、极端尺度费用保留。若未来证明集合预算误差eta_1 X，上述比较新增S/(2M)X须同其他吸收系数相加，不能逐项默认可吸收。

本轮复用1 Astra high、2 Sol high、1 Sol medium；无独立Luna任务。实际计算使用指定Python，费用数据不可得，不估算模型成本。D01/A02规范用于边缘、外放松方向审查；一般连续等式用上述自含证明，不引用未经核验的外部输运定理。精确计算及最终独审见附件，不编译PDF。

## 实际复现与证据范围

指定Python隔离复现geometry的3612项有理标量检查、complement的12项流/割/阈值等式和numeric的495项精确断言，stdout逐字一致，numeric JSON除计时完全一致。numeric只有三个实际区间捕获模型的27组固定(M,Lambda)，有理增广路、全部割穷举及来源集合公式三路同值；不作为连续定理或原hard需求的证明。连续证明由上面的弱星紧性、有限维分离与阈值积分独立承担。

本轮没有新的根阶主项付款。下一步须直接利用原历史估计厚集合需求，尤其受限来源后小接收者质量与原阶段权的兼容；不能只反复重证极值公式。
