# R465：连续容量分配的精确缺额与达到性

本稿证明指定连续分配问题的强对偶；不据此宣称原几何缺额已有来源预算。

## 1. 定理及可测范围

父空间为实际可测 \(E\subset\mathbb R^n\)，来源空间为 \(\mathbb R^n\)，均用完成的 Borel 测度。设有限正测度 \(\nu\) 与 \(\mu=f\,dx\)，
\[
 m_A=\mu(Q_A)\ge m_0>0\quad(\nu\text{-a.e.}),\qquad
 \pi_A(dx)=c_A(x)\mu(dx)/m_A,\qquad
 \kappa(dA,dx)=\nu(dA)\pi_A(dx).
\]
实际可测边长选择器保证 \((A,x)\mapsto c_A(x)\) 可测。原条件
\(\nu\le S\sigma\)、\(m_0=qa^n\) 足够；证明只用上述有限性和核结构。固定 \(1\le M<\infty\)、\(0\le\Lambda<\infty\)。

令 \(V\) 为
\[
 \max_\psi\int\psi\,d\kappa,\quad
 0\le\psi\le M,\quad
 \int\psi(A,x)\pi_A(dx)\le1\ \nu\text{-a.e.},\quad
 (\psi\kappa)_x\le\Lambda\mu.                               \tag{1}
\]
则最大值达到，且
\[
 \boxed{\nu(E)-V
 =\sup_{B\ {\rm measurable}}\!
 \left\{\int_E(1-M\pi_A(B^c))_+\,d\nu(A)-\Lambda\mu(B)\right\}. \tag{2}
\]
该上确界也达到。最优 \(\psi\) 可选共同可测代表；所有不等式为相应测度 a.e.，不要求逐点版本。此处只对固定输入证明存在，不额外声称随一族外部参数可测选择最优解。

源边缘密度可具体写成
\[
 g_\psi(x)=\int_E\psi(A,x)c_A(x)m_A^{-1}\,\nu(dA).
\]
Tonelli 给其可测性，(1) 最后一项等价于 \(g_\psi\le\Lambda\) \(\mu\)-a.e.。此外
\(\kappa_x\le\nu(E)m_0^{-1}\mu\)，所以所有下述配对有限。若 \(\nu(E)=0\)，结论均为零；\(\Lambda=0\) 时 \(V=0\)，(2) 取全来源空间即达到。

## 2. 弱星紧性与连续强对偶

在 \(L^\infty(\kappa)=(L^1(\kappa))^*\) 中，
\(\mathcal K=\{\psi:0\le\psi\le M\}\) 弱星紧。行约束等价于对所有可测 \(I\subset E\)
\[
 \int 1_I(A)\psi\,d\kappa\le\nu(I),
\]
源约束等价于对所有可测 \(B\)
\(\int1_B(x)\psi\,d\kappa\le\Lambda\mu(B)\)。
指标函数属于 \(L^1(\kappa)\)，每个约束弱星闭。零函数可行，目标弱星连续，故最优解达到。

准确对偶为
\[
 V=\inf_{0\le\alpha,\beta\le1}
 \left[
 \int\alpha\,d\nu+\Lambda\int\beta\,d\mu
 +M\int(1-\alpha(A)-\beta(x))_+\,d\kappa
 \right].                                                  \tag{3}
\]
先说明强对偶，不从有限网络直接外推。弱对偶由逐点
\(\psi\le\alpha\psi+\beta\psi+M(1-\alpha-\beta)_+\) 得到。

给定 \(t>V\)，所有约束与目标 \(\int\psi\ge t\) 的交在紧集 \(\mathcal K\) 上为空。有限交性质提供有限个行/源集合约束，使该有限问题也不可能达到 \(t\)。写这些约束为
\(\int\phi_j\psi\,d\kappa\le b_j\)，其中 \(\phi_j\) 是行或源集合指标。有限维集合
\[
 \left\{\big((\int\phi_j\psi-b_j)_j,\int\psi\big):
                  \psi\in\mathcal K\right\}
       +(\mathbb R_+^k\times\mathbb R_-)
\]
是闭凸集：前一部分紧，后一部分是闭锥。它不含 \((0,t)\)，但包含 \((0,0)\)（用 \(\psi=0\) 后补非负约束松弛）。严格分离给法向量
\((-\lambda_1,\ldots,-\lambda_k,\gamma)\)，其中 \(\lambda_j\ge0,\gamma\ge0\)；若 \(\gamma=0\)，无法把同一约束坐标的 \((0,t)\) 与 \((0,0)\) 严格分开，故 \(\gamma>0\)。

除以 \(\gamma\)，按父/源集合分别合并乘子为非负有界简单函数 \(\alpha,\beta\)。再对 \(0\le\psi\le M\) 逐点取上确界，得到
\[
 \int\alpha\,d\nu+\Lambda\int\beta\,d\mu
 +M\int(1-\alpha-\beta)_+\,d\kappa<t.
\]
把 \(\alpha,\beta\) 各截为与 1 的较小者不会增加该成本：某个变量原来超过 1 的点，截后正部仍为零。令 \(t\downarrow V\) 即证 (3)，不需要 Slater 条件或未经证明的无限网络定理。

## 3. 阈值分层严格给出集合割

对于 \(0\le\alpha,\beta\le1\)，令
\[
 I_t=\{A:\alpha(A)<t\},\qquad B_t=\{x:\beta(x)>1-t\},
 \qquad 0<t<1.
\]
定义实际割成本
\[
 C(I,B)=\nu(I^c)+M\kappa(I\times B^c)+\Lambda\mu(B).
\]
Tonelli 和区间长度给
\[
 \int_0^1 C(I_t,B_t)\,dt
 =\int\alpha\,d\nu+\Lambda\int\beta\,d\mu
 +M\int(1-\alpha-\beta)_+\,d\kappa.                         \tag{4}
\]
第二项的阈值区间是 \(\alpha<t\le1-\beta\)，长度恰为正部；原子只改变零 Lebesgue 长度的端点。因此某些割的成本不大于 (4) 的平均值。反向取
\(\alpha=1_{I^c},\beta=1_B\)，(3) 成本就是 \(C(I,B)\)，从而
\[
 V=\inf_{I,B}C(I,B).                                       \tag{5}
\]

固定 \(B\)，可测地取 \(I=\{A:M\pi_A(B^c)<1\}\)，等号处任选，便有
\[
 \inf_I C(I,B)
 =\nu(E)-\int(1-M\pi_A(B^c))_+\,d\nu+\Lambda\mu(B).
\]
这证明 (2)，且 \(B=\varnothing\) 使缺额至少为零（使用 \(M\ge1\)）。

为证明集合达到，(3) 的对偶也达到：单位区间在
\(L^\infty(\nu)\times L^\infty(\mu)\) 中弱星紧。其成本是弱星下半连续函数，因为最后一项等于
\[
 \sup_{0\le\psi\le M}
 \int(1-\alpha(A)-\beta(x))\psi\,d\kappa,
\]
每个固定 \(\psi\) 给弱星连续仿射函数；对应行密度在 \(L^1(\nu)\)，源密度在 \(L^1(\mu)\)。取最优 \(\alpha,\beta\) 后，(4) 中每个割成本至少为 \(V\)，平均值等于 \(V\)，故几乎每个阈值产生最优割。再按固定 \(B\) 的点态规则优化 \(I\)，便得到达到 (2) 的集合。

最优 \(L^\infty(\kappa)\) 元素有共同可测代表，必要时在零集外截到 \([0,M]\)。行、源测试约束分别推出其 a.e. 条件；不需要把一个父的零集选择迁移给另一个父。

## 4. 本机有限代数复核

实际运行了 3 个 Fraction 容量实例，分别含 \(\Lambda=0\)、零父权/零源列和分数容量：最大流、全枚举最小割及 (2) 缺额三者一致；另核 9 组阈值分层恒等式。合计 12 项准确等式检查通过。它们不承担上述连续强对偶证明，也不认证原几何预算。最小复现代码如下。

~~~python
from fractions import Fraction as F
from collections import deque
from itertools import product
def flow(nu,mu,pi,M,L):
    n=len(nu);m=len(mu);N=n+m+2;s=N-2;t=N-1
    c=[[F(0) for _ in range(N)] for _ in range(N)]
    for i in range(n):
        c[s][i]=nu[i]
        for j in range(m):c[i][n+j]=M*nu[i]*pi[i][j]
    for j in range(m):c[n+j][t]=L*mu[j]
    ans=F(0)
    while True:
        prev=[-1]*N;prev[s]=s;todo=deque([s])
        while todo and prev[t]<0:
            u=todo.popleft()
            for v in range(N):
                if prev[v]<0 and c[u][v]>0:prev[v]=u;todo.append(v)
        if prev[t]<0:return ans
        d=None;v=t
        while v!=s:
            u=prev[v];d=c[u][v] if d is None else min(d,c[u][v]);v=u
        v=t
        while v!=s:
            u=prev[v];c[u][v]-=d;c[v][u]+=d;v=u
        ans+=d
cases=[
([F(1),F(2)],[F(1),F(1),F(0)],
 [[F(1,3),F(2,3),F(0)],[F(3,4),F(1,4),F(0)]],F(1),F(0)),
([F(1),F(0),F(2)],[F(2),F(1),F(0)],
 [[F(1,2),F(1,2),F(0)],[F(0),F(1),F(0)],[F(1,4),F(3,4),F(0)]],F(2),F(1,3)),
([F(2,3),F(5,4)],[F(1),F(2),F(1)],
 [[F(1,2),F(1,3),F(1,6)],[F(1,4),F(1,4),F(1,2)]],F(3,2),F(2))]
checks=0
for nu,mu,pi,M,L in cases:
    n=len(nu);m=len(mu)
    def cut(I,B):
        return (sum(nu[i] for i in range(n) if not I[i])
          +M*sum(nu[i]*pi[i][j] for i in range(n) for j in range(m) if I[i] and not B[j])
          +L*sum(mu[j] for j in range(m) if B[j]))
    cuts=[];defs=[]
    for B in product([0,1],repeat=m):
        defs.append(sum(nu[i]*max(F(0),1-M*sum(pi[i][j] for j in range(m) if not B[j])) for i in range(n))
                    -L*sum(mu[j] for j in range(m) if B[j]))
        cuts.extend(cut(I,B) for I in product([0,1],repeat=n))
    assert flow(nu,mu,pi,M,L)==min(cuts)==sum(nu)-max(defs);checks+=1
    for shift in range(3):
        alpha=[F((i+shift)%5,4) for i in range(n)]
        beta=[F((2*j+shift)%5,4) for j in range(m)]
        direct=(sum(nu[i]*alpha[i] for i in range(n))
          +L*sum(mu[j]*beta[j] for j in range(m))
          +M*sum(nu[i]*pi[i][j]*max(F(0),1-alpha[i]-beta[j]) for i in range(n) for j in range(m)))
        bp=sorted({F(0),F(1),*alpha,*[1-x for x in beta]})
        integral=F(0)
        for lo,hi in zip(bp,bp[1:]):
            t=(lo+hi)/2
            integral+=(hi-lo)*cut([x<t for x in alpha],[x>1-t for x in beta])
        assert direct==integral;checks+=1
print("PASS",checks,"exact checks: 3 flow/cut/deficit and 9 threshold identities")
~~~
