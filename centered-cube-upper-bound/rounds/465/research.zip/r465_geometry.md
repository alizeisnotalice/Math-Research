# R465：厚父需求与实际双来源局部流的比较

**结论范围。** 以下不使用待审的连续 min-cut 等式。对任意可测来源集给出保原接受权的厚需求比较及全部误差；尚未证明其根阶来源预算。此处没有将新来源场赋予原历史。

## 1. 唯一候选：把厚父需求转到实际双来源

沿用实际保留流 \(P\)，父边缘 \(\nu\le S\sigma\)，静态三元投影 \(P_{A,y,z}\le S\sigma(dA)\pi_A(dy)\pi_A(dz)\)。固定任意可测 \(B\)，令
\[
 p_A=\pi_A(B),\qquad g_M(p)=(1-M(1-p))_+,\qquad M\ge2,
\]
\[
 T_M(B)=\int g_M(p_A)\nu(dA),\qquad
 R_{BB}=P\{y\in B,z\in B\}.
\]
所有旧来源、阶段、时钟、canonical 路径、父外与接受权都仍在 \(P\)。可证
\[
 \boxed{T_M(B)\le R_{BB}+S e_M X
                  \le R_{BB}+\frac{S}{2M}X,}
\tag{1}
\]
其中
\[
 e_M=\max_{0\le p\le1}(Mp-M+1)_+(1-p^2).
\tag{2}
\]
此量词对同一原流的**所有**可测 \(B\) 成立，不要求 \(B\) 与来源、父或历史独立。

证明：在 \(S>0\) 时写 \(a_A=d\nu/d(S\sigma)\in[0,1]\)，并令 \(q_A^B\) 为实际双来源在 \(B\) 内的父边缘相对于 \(S\sigma\) 的密度（此符号不代表匹配密度 \(q_A\)）。原静态帽仅在上界使用，给
\[
 a_A-q_A^B\le1-p_A^2,
 \qquad q_A^B\ge(a_A-(1-p_A^2))_+.
\]
对 \(c=1-p^2\)、\(0\le a,g\le1\)，
\[
 ga-(a-c)_+\le gc.
\tag{3}
\]
若 \(a\le c\) 显然；否则左端为 \(c-(1-g)a\le gc\)。积分即得第一式。置 \(t=1-p\)，当 \(g>0\) 时 \(0\le t<1/M\)，且
\[
 gc=(1-Mt)(2t-t^2)\le2t(1-Mt)\le1/(2M).
\]
\(S=0\) 时原流为空。

还可在每父将 \(g_M(p_A)\nu\) 尽可能配给原 \(P\) 的 \(BB\) 正限制；其未配量恰为
\(\int(g_M(p_A)a_A-q_A^B)_+S\sigma(dA)\)，由上述证明不超过 \(Se_MX\)。这只是对实际正流的削减与质量比较，不移动原来源，不修改历史。

## 2. 完整费用及尚未取得的几何步骤

对 \(M=2\)，(2) 的最大值位于
\[
 p_*=(1+\sqrt{13})/6,
 \qquad e_2=(2p_*-1)(1-p_*^2)\approx0.21985494.
\]
因此单靠静态接受帽不能把 (1) 的误差变成任意小 \(\eta X\)：(3) 对标量选择 \(a=1-p^2\) 达到等号。这里的标量极值**不是**满足原几何历史的反例。若允许固定失真常数依赖 \(\eta\)，选
\(M\ge\max(2,S/(2\eta))\) 可将这笔比较误差控制为 \(\eta X\)。这仍没有付掉 \(R_{BB}\)。

现有无损的来源局部上界只有
\[
 R_{BB}\le S\int\sigma(dA)p_A^2
 \le S\int_B f(x)D(x)dx
 \le SA_n\mu(B),
 \quad D(x)=\int_E c_A(x)R_A^{-n}dA.
\tag{4}
\]
它保完整 \(f\) 及实际中心，但在 octave 中是线性维数价。

若能利用同一 \(P\) 的 high-rank、low-common、stage 与终端条件证明
\[
 R_{BB}\le\eta_1 X+
 C_{\eta_1}\sqrt n\,\operatorname{polylog}(n+2)\mu(B)
 \quad\text{对每个可测 }B,
\tag{5}
\]
则 (1) 直接给所需厚需求不等式，误差为
\((\eta_1+S/(2M))X\)。这里 (5) 是**唯一尚缺的几何比较**，不是已证输入；取 \(B\) 为全来源已包含完整目标，故不能将此转换称为降难度或新付款。

尝试利用厚度时，\(p_A>1-1/M\) 确实使该父对 \(f1_B\) 的匹配密度落在 \([(1-1/M)q,\lambda]\)。但 small receivers 的匹配质量也变了，原严格质量门、\(Z\) 分母、阶段 \(D_i\) 及接受历史不随之保持。因此不能在 \(f1_B\) 场调用原历史收据来证明 (5)。同样，两个终端的小质量只说明每条记录内大部分 \(B\cap Q_A\) 来源未被它们捕获，不能消去 (4) 中这些来源跨不同实际父的重复 \(D(x)\)。本轮未得到这个共享费用的新增控制。

**决策。** 厚父后验本身不等于实际被接受来源对的厚度；(1) 精确补上这个差别。继续路线必须直接估计带原接受权的 \(BB\) 来源重复，而非把受限来源场当成具有原历史的新输入。未证明一般 root 价格，也未使用或重证 min-cut 存在定理。

## 3. 实际有限核验

指定本机 Python 实跑如下 3612 项 Fraction 断言；只校验 (3) 与 \(1/(2M)\) 常数，不作原生几何或历史认证。最后浮点数仅显示解析 \(e_2\) 的近似值。

```python
from fractions import Fraction as F
checks=0
for M in (2,3,4,8):
 for ip in range(21):
  p=F(ip,20);g=max(F(0),1-M*(1-p));c=1-p*p
  for ia in range(21):
   a=F(ia,20);qmin=max(F(0),a-c)
   assert g*a-qmin<=g*c;checks+=1
   assert g*c<=F(1,2*M);checks+=1
  assert g*c-max(F(0),c-c)==g*c;checks+=1
print('PASS',checks,'Fraction inequalities; scalar actual-cap alignment only, not native geometry/history.')
from math import sqrt
p=(1+sqrt(13))/6
print('M=2 maximizing p and loss (diagnostic):',p,(2*p-1)*(1-p*p))
```

```text
PASS 3612 Fraction inequalities; scalar actual-cap alignment only, not native geometry/history.
M=2 maximizing p and loss (diagnostic): 0.7675918792439983 0.21985493668577522
```
