# R465：带边容量的source-set缺额公式——27例精确证书

结果：27个固定参数例中，独立有理增广路maxflow、全部graph cuts穷举、消去record cut后的source-subset公式完全一致，gap均为0。分数M=3/2保留了真实部分缺额，未被错误舍成无失真或无限失真情形。这验证有限公式与实现，不证明连续一般存在性或原目标容量可行。

## 模型与缺额公式

复用R464三实际区间几何，但所有常数已复制入自含脚本，无旧文件依赖。source packets半宽1/100、质量1、密度50，parent side6/5，centerblocks半宽1/100。两source图的parent中心为1/2、0，capture分别{0,1}、{0}；需求分别(1,1)或(1/2,3/2)。三source链parent中心1/2、3/2、1，capture{0,1}、{1,2}、{1}，需求(1,1,1)。全部整packet/centerblock捕获或未捕获有严格距离边距；仅各域内部两两不交，center域和source域允许相交。

原固定行分配a0_ji=d_jπ_ji，π_ji=f_iB_ji/ΣfB。maxflow约束：row≤d_j，source column≤Λ f_i，edge≤M a0_ji。M∈{1,3/2,2}、Λ∈{1/2,1,3/2}，3几何共27例。

对source侧cut集合B，record可独立选择cut一条需求边d_j，或cut通向Bc的边容量Md_jπ_j(Bc)。故

cut(B)=Λf(B)+Σ_j min(d_j,Md_jπ_j(Bc))，

total demand−maxflow=max_B[Σ_j d_j(1−Mπ_j(Bc))_+−Λf(B)]。

空B给非负候选0（因本任务M≥1），无须另忘记positive part。记录落source-side当Mπ_j(Bc)<1；tie任选。本脚本同时枚举所有record/source graph cuts，独立核该消元未遗漏cut。输出每例一组最大缺额B、cut的record/source/edge三部分、最优primal及全容量，直接验证零gap。

## 全部最优保留量

每格按Λ=(1/2,1,3/2)列出，行按M=(1,3/2,2)。缺额为该几何总需求减此量：前两图总2，三source图总3。

| 几何 | M | Λ=1/2 | Λ=1 | Λ=3/2 |
|---|---:|---:|---:|---:|
| 两source等需求 | 1 | 1 | 3/2 | 2 |
| 同上 | 3/2 | 1 | 7/4 | 2 |
| 同上 | 2 | 1 | 2 | 2 |
| 两source压力 | 1 | 3/4 | 5/4 | 7/4 |
| 同上 | 3/2 | 7/8 | 11/8 | 15/8 |
| 同上 | 2 | 1 | 3/2 | 2 |
| 三source链 | 1 | 3/2 | 2 | 5/2 |
| 同上 | 3/2 | 3/2 | 5/2 | 3 |
| 同上 | 2 | 3/2 | 3 | 3 |

例如M=3/2、Λ=1：第一图最大缺额1/4，B={source0}；压力图缺额5/8，B={source0}；链图缺额1/2，B={source1}。它们精确区分边distortion与source容量的限制。M=2、Λ=1恢复R464三个unrestricted最优2、3/2、3。

## 实际计算及边界

共495项精确断言，含几何、augmentations、primal、cuts和目标比较；不是495个独立样本。exploratory为M=Λ=1的3例；pressure为其余M=1或Λ=1/2的12例；expanded为剩余12例。只做这27组，不扫描。

所有flow/capacity/cut均为Fraction。实现为BFS残量增广路（含反向边），不调用浮点solver。primal按row、column、edge逐项核验；枚举所有内部节点cut与全部source subsets独立对照。只认证未归一edge失真a≤Ma0，未断言保留后条件source密度≤M。部分row被删时不称原parent/record边缘全保。Λ是一般capacity参数，不是项目s=1+√n。

geometry可把每条edge流提升为centerblock×sourcepacket的常密度conditional product，从而保持此有限模型的真实capture和容量；这不证明原P需求、history lift或全局目标source cap有可行解。root连续定理与目标可行性仍须独立证明。

实际命令：

```
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/r465_numeric.py
```

Python3.12.14，标准库Fraction，无数学浮点误差，只有JSON运行计时使用浮点。输入自含，输出写脚本同目录。冻结白名单：r465_numeric.py、r465_numeric.json、r465_numeric.md。完成停止。
