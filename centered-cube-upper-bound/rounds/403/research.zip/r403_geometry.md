# R403 — Shared failure coordinates and a further count-weighted receipt

## 1. Frozen contract and exact candidate

Use the FINAL R402 contract in `/tmp/r402_main.md`, including its proved two-end inner extension; the auxiliary note alone only treated the small end. Keep full f, actual Lebesgue receiver measure, m_a=f(Q_a)=q_a R_a^n, q_-≤q_a≤λ, a≤R_a≤b≤2a, and every original source, clock, χ, rank, stage and edge mark. No receiver is introduced. Write ε=ε_0≤1/2, K=exp(√n), h=(1+√n)/(εq_-), S=β+C_col. Choose L≥4 and a fixed 0<ζ≤1. Near means ||y−z||∞≤d0=ζa/n throughout, not the larger a/n domain. The argument is for n≥2; the existing high-dimensional ledger uses n≥9 and its direct low-dimensional alternative remains.

For endpoint A and a live pair (y,z) in R400, let

 E_y=Z_A(y)−C_A(y,z),  E_z=Z_A(z)−C_A(y,z),  E=E_y E_z.

These are strictly positive on the actual soft-complement support. Attach the SAME probability product Q_y⊗Q_z used in R402:

 Q_y(dw)=1_{m_w<m_A/K}c_w(y)(1−c_w(z))μ(dw)/E_y,
 Q_z(dt)=1_{m_t<m_A/K}c_t(z)(1−c_t(y))μ(dt)/E_z.

The symbols w,t are actual exclusive witnesses, not original transitions. They inherit neither χ nor any original history qualification. Define their complete nonempty failure sets

 S_w(y,z)={j: |z_j−w_j|>R_w/2},
 S_t(z,y)={j: |y_j−t_j|>R_t/2},
 p=|S_w|, q=|S_t|.

Here q is only the integer cardinality in this paragraph; all density parameters retain subscripts q_a or q_-. All sets, counts and kernels are measurable because the selector is measurable and there are only finitely many coordinates. Closed capture and strictly failed capture are complementary; faces are not deleted as null sets.

The candidate to prove is that near witnesses sharing ANY failed coordinate can replace the old first-same receipt at the same d_face price, and the additional disjoint soft fraction min(1,p q/n) has price at most (1−1/n)d_face. These are unconditional actual positive branches, with a complete complement. They do not assert that any fixed fraction of the traffic satisfies either condition.

## 2. Actual receiver capacity and the two new branches

For each coordinate define the unrestricted face occupation

 F_j(y,z)=∫1_{m_w<m_A/K}c_w(y)1_{j∈S_w(y,z)}μ(dw).

The R402 native one-face theorem applies without a first-coordinate restriction:

 F_j(y,z)≤2/q_-,  F_j(z,y)≤2/q_-                 (1)

whenever ||y−z||∞≤a/n. This is a theorem for the actual radius field, proved by integration over real centers with the max(a,t,ρ) envelope. It does not replace source mass by a boundary volume. The strict far restriction only reduces the nonnegative integral. If y_j=z_j this face occupation is exactly zero.

Write dM_y,dM_z for the unnormalized numerator measures of Q_y,Q_z. Let

 D_sh=∫∫1_{S_w∩S_t≠∅} dM_y(w)dM_z(t),
 D_big=∫∫1_{S_w∩S_t=∅} min(1,|S_w||S_t|/n) dM_y(w)dM_z(t).

Both are ≤E, their supports are disjoint, and D_sh+D_big≤E. Positive Tonelli and a union bound give

 D_sh≤Σ_j F_j(y,z)F_j(z,y)≤4n/q_-².             (2)

Overlapping coordinates in the upper bound are counted more than once only as a majorant. The ACTUAL paid event is its single union indicator, so it is charged once. Equality of first failure coordinates implies this union event. Thus (2) strictly enlarges the old selector as a set of labels; it is a replacement, not an additional old-face fee.

There is also a genuinely further branch inside the disjoint sets. Pointwise on arbitrary nonempty coordinate sets,

 1_{S_w∩S_t=∅} min(1,|S_w||S_t|/n)
 ≤(1/n)Σ_{j≠k}1_{j∈S_w}1_{k∈S_t}.

On disjoint sets the sum is exactly |S_w||S_t|, and min(1,x)≤x; on intersecting sets the left side is zero. Hence

 D_big≤(1/n)Σ_{j≠k}F_j(y,z)F_k(z,y)
       ≤4(n−1)/q_-².                                  (3)

No independence of source coordinates is used. The factorization in (2),(3) is Tonelli for the explicitly attached product of the two actual witness measures. No positivity of an arbitrary matrix or quadratic form is assumed.

The new selector is not merely the first-same selector with another name. For example S_w={1,2}, S_t={2,3} has different first coordinates but is now in D_sh; in n=4 the disjoint sets {1,2},{3,4} belong to D_big. These are set-level strict-inclusion diagnostics, not an assertion of a fully marked core fixture or positive uniform traffic proportion.

## 3. Single joint partition, with both actual collars

Use the same radius bins r_j=a exp(j/√n) and actual r(w) from the FINAL R402 contract, including b in the final bin and one bin if b=a. On each actual witness pair put

 I_y=1_{y∈Q_{r(w)}(w)},  I_z=1_{z∈Q_{r(t)}(t)},
 sh=1_{S_w∩S_t≠∅},  big=min(1,|S_w||S_t|/n).

On the near set the following five nonnegative weights sum to one pointwise:

 sh;
 (1−sh) I_y;
 (1−sh)(1−I_y) I_z;
 (1−sh)(1−I_y)(1−I_z) big;
 (1−sh)(1−I_y)(1−I_z)(1−big).                            (4)

Outside the near set retain the entire original far cost. This partition is applied separately under the actual external and small-end original integrands, keeping the same w,t until all choices are made. In particular, sh is NOT averaged out before independently resampling the inner tags. The final two weights fractionally split the SAME disjoint double-collar submeasure; they are not disjoint indicators when 0<big<1. The two actual collars in these terms mean capture at R_w,R_t but noncapture at their own r(w),r(t).

Denote the resulting costs by P_sh, P_in, P_big, R403, where R403 includes both far costs. The identity is

 R400=P_sh+P_in+P_big+R403.                              (5)

The first-same R402 receipt is replaced entirely. P_big here includes the two collar restrictions, so it is a positive submeasure of the raw D_big soft fraction in (3).

For completeness the inherited two-end inner proof works unchanged: after dropping the positive (1−sh) restriction, the inner union has conditional mass p_y+p_z−p_y p_z. Its marginal bounds are

 p_y≤η_y=ζε/(1−ε),  p_z≤η_z=ζε/(L−1−ε).

They follow from the bin geometric sum C_*≤ζ(1+√n)/q_-, and E_y>(1−ε)h, E_z>(L−1−ε)h at the small end. At the external end the stronger E_y>h,E_z>(L−1)h implies the same bounds. Each bound lies in [0,1]. The total two-end original cost is at most 2G0≤2βX_q, using nested actual stages and Σ_i b_i≤1. Therefore

 P_in≤α_bin X_q,
 α_bin=2β(η_y+η_z−η_yη_z)≤4βζ.                         (6)

This is the existing FINAL R402 two-end receipt, not a new fee or two copies of the auxiliary small-end estimate.

## 4. Transfer of the new geometry to original marked costs

Set

 B_L=β/(2L)+C_col/[(2−ε)(L−ε)],
 d_face=4ε² B_L≤S/L.

For either witness selector, its conditional mean is the corresponding raw mass divided by E. The R401 soft-complement inequalities on the original rank supports give

 (1−φ_u)/E≤1/(2Lh²),
 (1−ψ_v)/E≤1/[(2−ε)(L−ε)h²].                            (7)

The inequalities hold on positive soft support, where C<h; elsewhere the paid component is zero. They use BOTH original ranks, not ranks assigned to w,t.

Keep dΓ_i=σ(du)π_u(dy)ℓ_i(u,y,dv) with ℓ_i(E)≤β pointwise in the OLD y, and the corresponding incoming k_i(v,y)≤C_col. Inserting (2) or (3) in (7), the remaining actual π_A⊗π_A integral is bounded by its total one. Sum b_i(z) at the same new source before using Σ_i b_i(z)≤1. All other positive marks may be dropped only for the upper bound. Consequently

 P_sh≤[4n/(q_-²h²)] B_L X_q
      = [n/(1+√n)²]d_face X_q≤d_face X_q,
 P_big≤[4(n−1)/(q_-²h²)] B_L X_q
      ≤(1−1/n)d_face X_q.                              (8)

For P_big, the prior exclusion of shared and inner events only reduces the raw mass, so (3) is valid without an independence assumption after that exclusion. The two original receiver fields have not been replicated, and there is no fee per stage, bin or original edge.

At the external end all these selectors may also be written using the exact conditional E_uv/Z_u lift. For fixed old (y,u,v), integrate the additional selector over Q_y⊗Q_z as a function g(y,z), then use

 π_u[b_i(1−c_v)1_{Z_u>Lh}g(y,·)]
 =E_uv∫b_i(z)g(y,z)1_{Z_u(z)>Lh}ν_uv^z(dz)/Z_u(z).

The old y remains conditioned; E_uv/Z_u is never set to one. This is the unchanged identity, not a new history-qualified transition or source transport.

## 5. Full price and remaining scope

Define

 Δ403=(2−1/n)d_face+α_bin≤2S/L+4βζ.                    (9)

The slightly sharper coefficient [n/(1+√n)²](2−1/n)d_face is also valid, but (9) is the conservative main price. By (5)–(8), R400≤R403+Δ403 X_q. The old d_face+α_bin price is replaced, not added. The only additional fee beyond the enlarged shared-coordinate replacement is (1−1/n)d_face.

With ζ_n=2(λ/q_-)Sε/[K(1+√n)] and P_L=λh[β(L+ε)+C_col L], the original ledger for n≥9 becomes

 G0≤16R403+16(ζ_n+Δ403)X_q+16(s+P_L)W,
 BH≤32R403+[E387+32(ζ_n+Δ403)]X_q+[S390+40s+32P_L]W,
 entrance≤Λ{8λHW+2d_eff A_n W_ν/H+64R403
       +[2E387+64(ζ_n+Δ403)]X_q+[2S390+80s+64P_L]W}.

Here Λ=128/119; every old fee is retained once. For Δ403≤δ, one sufficient choice is L≥max(4,4S/δ) and ζ≤min(1,δ/(8β)); if β=0 there is no restriction from the zero inner fee. Any change of L requires replacing the ENTIRE original R398 mother split and P_L, including the intermediate rank bands. A smaller ζ enlarges the far complement. No extra W fee is added, but the displayed current P_L remains. Original entrance absorption requires an actual allocation of 64ΛΔ403; it is not free. The same direct low-dimensional bound G0≤S(1+N log2)W/2 replaces this whole slot where applicable.

The exact unpriced remainder comprises:

* the full original far source-pair traffic ||y−z||∞>d0;
* near traffic whose SAME two exclusive witnesses have nonempty DISJOINT failure-coordinate sets, whose product of cardinalities is <n, and whose two captured sources lie in their actual radius-bin collars, with the precise surviving weight (1−|S_w||S_t|/n)_+.

All original low-common-capture, high-rank, stage and clock conditions are still attached. Since a disjoint pair has product at most floor(n²/4), no disjoint pair in n=2,3 has product ≥n; the new SOFT fraction nevertheless pays part of those pairs. The entire high-product portion is paid in all dimensions where it exists, along with a soft portion of every remaining near disjoint double-collar pair. No dimension-independent positive fraction of the total original traffic is asserted. This bound pays a new positive general branch, but gives no payment for the complete small-product double-collar integral. In particular, neither the small count product nor a thin collar licenses a cap on f. No further multi-face or source-mass claim is made.

## 6. Executed checks and status

Ran locally with Python standard-library Fraction:

    python3 /tmp/r403_geometry_check.py
    PASS {'subset_indicators': 21342, 'weighted_capacity': 64,
          'single_joint_partition': 3600, 'coefficients': 64} total 25070

The first group checks the exact union-indicator and disjoint-count soft-selector inequalities for all nonempty coordinate subsets in dimensions 2 through 7. The second uses positive rational witness weights normalized so each unrestricted face marginal is at most 2, in dimensions 2 through 9; it verifies both capacity majorants, including the n−1 improvement. The third checks the single joint partition with inner flags and the precise remainder support. The last checks price inequalities with rational parameters. These are algebraic diagnostics, not claims that every weighted array is a native receiver/core model. The actual-center input is the already proved R402 native face theorem, used in (1); its endpoint correction and arbitrary-selector domain remain in force.

Status: proved shared-coordinate replacement at the same fee, plus the further disjoint count-weighted receipt with its displayed fee. The full root-order theorem remains open on the exact remainder above. Work stops here.
