from fractions import Fraction as F
from itertools import product
counts={'subset_indicators':0,'weighted_capacity':0,'single_joint_partition':0,'coefficients':0}
for n in range(2,8):
    sets=[frozenset(j for j in range(n) if k>>j&1) for k in range(1,1<<n)]
    for A in sets:
        for B in sets:
            overlap=len(A&B); dis=not overlap
            shared=int(bool(overlap)); wide=int(dis)*min(F(1),F(len(A)*len(B),n))
            assert shared<=overlap
            assert wide<=F(sum(j!=k for j in A for k in B),n)
            assert shared+wide<=1
            counts['subset_indicators']+=1
for n in range(2,10):
    sets=[frozenset(j for j in range(n) if k>>j&1) for k in range(1,min(1<<n,61))]
    for seed in range(1,9):
        raw=[F((i*seed+3)%11+1,17) for i in range(len(sets))]
        raw2=[F((i*(seed+1)+5)%13+1,19) for i in range(len(sets))]
        scale=max(sum(x for A,x in zip(sets,raw) if j in A) for j in range(n))
        scale2=max(sum(x for A,x in zip(sets,raw2) if j in A) for j in range(n))
        # q=1; real face theorem is analytic, arrays test its positive consequences.
        w=[2*x/scale for x in raw]; t=[2*x/scale2 for x in raw2]
        face=[sum(x for A,x in zip(sets,w) if j in A) for j in range(n)]
        face2=[sum(x for A,x in zip(sets,t) if j in A) for j in range(n)]
        sh=wi=F(0)
        for A,x in zip(sets,w):
            for B,z in zip(sets,t):
                sh+=x*z*bool(A&B)
                wi+=x*z*(not A&B)*min(F(1),F(len(A)*len(B),n))
        assert sh<=sum(x*y for x,y in zip(face,face2))<=4*n
        assert wi<=sum(face[j]*face2[k] for j in range(n) for k in range(n) if j!=k)/n<=4*(n-1)
        counts['weighted_capacity']+=1
for n in (2,3,4,6):
    sets=[frozenset(j for j in range(n) if k>>j&1) for k in range(1,min(1<<n,15))]
    for A,B,iy,iz,near in product(sets,sets,(0,1),(0,1),(0,1)):
        sh=near*int(bool(A&B))
        yin=near*(1-sh)*iy
        zin=near*(1-sh)*(1-iy)*iz
        wide=near*(1-sh)*(1-iy)*(1-iz)*min(F(1),F(len(A)*len(B),n))
        rem=near*(1-sh)*(1-iy)*(1-iz)*max(F(0),1-F(len(A)*len(B),n))
        far=1-near
        assert far+sh+yin+zin+wide+rem==1
        if rem: assert not A&B and len(A)*len(B)<n and not iy and not iz
        counts['single_joint_partition']+=1
for n,eps,L,beta,col in product((2,3,9,16), (F(1,10),F(1,2)),(F(4),F(10)),(F(1,3),F(3,4)),(F(1),F(5,2))):
    base=4*eps**2*(beta/(2*L)+col/((2-eps)*(L-eps)))
    union=(2-F(1,n))*base
    assert base<=(beta+col)/L
    assert union<=2*(beta+col)/L
    counts['coefficients']+=1
print('PASS',counts,'total',sum(counts.values()))
