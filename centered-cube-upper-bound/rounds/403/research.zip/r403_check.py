from fractions import Fraction as F
counts={'initial':0,'threshold_stress':0,'expanded':0}
positive_shared_gain=positive_high=0
for n in range(2,9):
 masks=list(range(1,1<<n));sizes={m:m.bit_count() for m in masks}
 for seed in range(1,5):
  aw={m:(seed*m+sizes[m])%7 for m in masks}
  bw={m:((seed+2)*m+sizes[m]*2)%11 for m in masks}
  ca=[sum(aw[m] for m in masks if m>>j&1) for j in range(n)]
  cb=[sum(bw[m] for m in masks if m>>j&1) for j in range(n)]
  scale=F(4,max(ca)*max(cb)) # q_-=1; each raw face capacity <=2
  parts=[F(0)]*5;oldpaid=0;sharedgain=0;hardpaid=0
  for a in masks:
   for b in masks:
    weight=aw[a]*bw[b]
    common=bool(a&b);samefirst=(a&-a)==(b&-b)
    iy=(a+seed)%3==0;iz=(b+2*seed)%4==0
    high=sizes[a]*sizes[b]>=n
    assert not samefirst or common
    if common:k=0
    elif iy:k=1
    elif iz:k=2
    else:k=3
    if k<3:parts[k]+=weight
    else:
     tau=min(F(1),F(sizes[a]*sizes[b],n))
     parts[3]+=weight*tau;parts[4]+=weight*(1-tau)
     hardpaid+=weight*high
     assert tau>=int(high)
     if 1-tau:assert sizes[a]*sizes[b]<n and not(a&b) and not iy and not iz
    oldpaid+=weight*(samefirst or iy or iz)
    sharedgain+=weight*(common and not samefirst and not iy and not iz)
  assert parts[3]>=hardpaid
  total=sum(aw.values())*sum(bw.values())
  assert sum(parts)==total
  assert oldpaid<=sum(parts[:4])
  assert scale*parts[0]<=scale*sum(x*y for x,y in zip(ca,cb))<=4*n
  cross=sum(ca[j]*cb[k] for j in range(n) for k in range(n) if j!=k)
  assert n*parts[3]<=cross
  assert scale*parts[3]<=4*(n-1)
  p=F(sum(aw[a] for a in masks if (a+seed)%3==0),sum(aw.values()))
  q=F(sum(bw[b] for b in masks if (b+2*seed)%4==0),sum(bw.values()))
  assert F(parts[1]+parts[2],total)<=p+q-p*q
  positive_shared_gain+=sharedgain>0
  positive_high+=parts[3]>0
  phase='initial' if n<=3 else 'threshold_stress' if n<=5 else 'expanded'
  counts[phase]+=1
print('PASS weighted same-joint partitions and face certificates:',counts,'total',sum(counts.values()))
print('strict_shared_expansion_cases',positive_shared_gain,'positive_soft_count_cases',positive_high)
assert positive_shared_gain>0 and positive_high>0
# Exact coefficient accounting, including raw incoming/outgoing totals.
fees=0
for n in [2,3,4,9,16,64]:
 for eps in [F(1,8),F(1,2)]:
  for L in [F(4),F(8),F(32)]:
   beta=F(3,4);C=F(5,3);S=beta+C;zeta=F(1,10)
   face=4*eps**2*(beta/(2*L)+C/((2-eps)*(L-eps)))
   ey=zeta*eps/(1-eps);ez=zeta*eps/(L-1-eps)
   inner=2*beta*(ey+ez-ey*ez)
   joint=(2-F(1,n))*face+inner
   assert face<=S/L and inner<=4*beta*zeta
   assert joint<=2*S/L+4*beta*zeta
   assert 4*16*joint==64*joint
   fees+=1
print('PASS exact combined fee checks:',fees)
