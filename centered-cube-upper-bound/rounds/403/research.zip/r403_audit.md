# R403 independent audit — FINAL PASS

FINAL PASS for the shared-failure-coordinate replacement, additional disjoint count-soft receipt, exact single-joint remainder and complete parameter-dependent ledger. No general root-order bound for the final far/double-collar remainder is certified. Only this audit file was edited.

Only this file is edited. The mathematical derivation below precedes reading any R403 author proof. The parent candidate was read after the independent derivation. The R402 actual single-face capacity is inherited; no general root-order closure is asserted.

## 1. Full failure sets and unpartitioned face measures

Keep the same complete full-f field, actual receiver centers, strict far-mass cutoff, original stage/source/clock/history marks, and the SAME conditional exclusive-witness product law Q_y tensor Q_z at each actual endpoint A. On its first support w captures y and misses z; define the nonempty full failure set

    S_w(y,z)={j: |z_j-w_j|>R_w/2}.

On the reverse exclusive support define S_t(z,y) analogously. These are measurable finite-valued sets using the same closed-cube conventions as R402. A first-failure index is merely the least element; it is not needed to define this stronger event.

For a fixed source pair define the unrestricted single-coordinate occupation

    F_A,j(y,z)=integral_{m_w<m_A/K}c_w(y)
                               1_{j in S_w(y,z)}mu(dw).

Failing in coordinate j already implies noncapture of z, so no global noncapture factor is missing. The R402 native face bound (6) applies directly to this unpartitioned quantity. For n>=2 and ||y-z||infinity<=d0<=a/n,

    F_A,j(y,z)<=2/q_-, F_A,j(z,y)<=2/q_-.

This estimate originally precedes the first-index restriction; it is not being generalized from a bound that held only after that restriction. If y_j=z_j the actual coordinate failure event is empty. There is only one possible face orientation for a fixed signed source pair, so no factor of two is missing.

## 2. Exact shared-coordinate positive fraction

Let E_y and E_z be the actual exclusive normalizations of R402. Define the raw shared-set occupation

    A_shared,A(y,z)=integral exclusive_y(dw) exclusive_z(dt)
                                  1_{S_w(y,z) intersect S_t(z,y) nonempty}.

It satisfies the two simultaneous bounds

    0<=A_shared,A<=E_y E_z,
    A_shared,A<=sum_j F_A,j(y,z)F_A,j(z,y)<=4n/q_-^2.

The second bound is a positive union bound over common coordinates, followed by Tonelli on the ACTUAL product occupation. Multiple shared coordinates are overcounted only upwards. No coordinate independence of f, source-volume bound or private selection of a receiver is assumed.

Therefore rho_shared=1_near A_shared/(E_y E_z), with zero at zero denominator, is an actual measurable mark in [0,1]. It is the marginal of the shared-set indicator on the original explicit exclusive product lift. It dominates the first-index-equality mark pointwise under that same lift, since equal first index is necessarily a shared coordinate. No original qualification is transferred to either witness.

## 3. Same soft-complement receipt with no extra fee

Multiply the original R400 low-common soft complement by rho_shared before removing original labels. The R401 scalar inequality, using the actual old/new source rank supports, gives

    (1-C_A/h)_+rho_shared
       <=1_near A_shared/(A0 B0 h^2),

where A0 B0=2L at the external large endpoint and (2-epsilon0)(L-epsilon0) at the small endpoint, with L>=4 and epsilon0<=1/2. The sourcewise outgoing beta/incoming C_col estimates and the global sum_i b_i(z)<=1 then imply precisely the R402 face price

    P_shared <=d_face Xq,
    d_face=4epsilon0^2[beta/(2L)
                    +C_col/((2-epsilon0)(L-epsilon0))] <=S/L.

The sharper n/(1+sqrt(n))^2 factor may be retained as before. This proof replaces the first-same receipt by the larger shared-set receipt at the SAME conservative bound. The two face prices are alternatives, not fees to add; the same original negative capture square and common-past receipts are not spent again.

## 4. Single-joint ordered inner decomposition

Use the SAME uniform cut d0 and actual conditional witness pair used for this shared event. On the near set the four exact disjoint tags are

    shared failure coordinate;
    disjoint failure sets and I_y(w)=1;
    disjoint failure sets and I_y(w)=0,I_z(t)=1;
    disjoint failure sets and I_y(w)=I_z(t)=0.

The far set is retained in full. These tags cover the original joint lift pointwise. An averaged rho_shared must not be substituted and the two witnesses resampled before claiming the last tags refer to that same pair. After dropping the disjoint restriction upwards, the old inner-union bound still applies without any changed normalization. Thus its two-endpoint alpha_bin price is unchanged, using total R400<=2G0<=2beta Xq, and it must not be added a second time from R402.

The final paid event on the near joint lift is shared OR I_y OR I_z. The old R402 paid event was first-index-equality OR I_y OR I_z. The latter is a subset of the former, so for identical full field, stages, parameters, bins and original marks, the new positive remainder is a subset of the old one. Its near tags have FULL failure sets disjoint and both actual radius-bin collar events; its far tags are unchanged. This inclusion is exact and does not assert a strict or uniformly positive improvement for every input. If parameters are changed, this same-field inclusion is not freely transported across those changes.

The complete displayed price remains Delta=d_face+alpha_bin<=S/L+4beta zeta, not oldDelta plus a new face charge. At the R398-derived entrance it still costs 64Lambda Delta, with the existing zeta_n and full current P_L retained once. Any symbolic absorption selection needs the same reserved global budget and low-dimensional whole-core alternative as before. No budget for the new far/disjoint-double-collar remainder follows from this screen.

## Actual bounded local computation

Reviewer actually ran 84 Fraction mask/product-law tests in dimensions 2-8, verifying first-same subset shared, shared occupation bounded by the sum of coordinate products, exact coordinate-product multiplicity expansion, and the corresponding ordered-inner total paid-event inclusion. Eighty finite cases had strictly larger total paid weight, but these are finite witness algebra with synthetic inner flags, not native matched continuum core or high-history fixtures. No separate test file was saved, and these cases are not mixed with later author/parent counts.

Independent screen PASS; the completed author and final report review below supersedes the preliminary screen.

## Screen dependency

- `/tmp/r403_candidate.md`: `bf0978282bf003f0e763746cbfccff76598e091d0d585b6167a2626453f5b2ba`
- `/tmp/r402_geometry.md`: `586017741954884bbf6b7f76b476cc6a6f4994223567bb3353e1723ce790c2ef`
- `/tmp/r402_main.md`: `f9a996b77ef3cac5f71f1dc6260e50b031dd8e52c8c16e0af3423c2bc63ec93f`


## Later independent screen: disjoint high-product double-collar branch

After shared failure sets and both ordered inner tags are removed on the SAME near witness pair, consider the surviving event |S_w||S_t|>=n. On a disjoint pair,

    |S_w||S_t|=sum_(j!=k)1_{j in S_w}1_{k in S_t}.

The indicator of the high-product event is at most this count divided by n. Its raw exclusive occupation, retaining double collars or dropping them only upwards, is consequently at most

    (1/n)sum_(j!=k)F_A,j(y,z)F_A,k(z,y)
      <=4(n-1)/q_-^2.

This bound is derived on actual disjoint tags before enlarging to unrestricted coordinate products; it does not assume source independence. Multiplying the existing soft complement by its exact conditional probability and using the same actual sourcewise endpoint estimates gives an additional price <=(1-1/n)d_face Xq. The unchanged n/(1+sqrt(n))^2 factor could still be retained for a sharper display. The high-product tag is disjoint from shared and ordered-inner tags, so this is a distinct new price rather than a repeated charge for the shared event.

The exact order is shared, disjoint old-inner, disjoint old-collar/new-inner, disjoint double-collar/high-product, then disjoint double-collar/low-product. The far complement remains unchanged. Thus the new near residual satisfies |S_w||S_t|<n in addition to disjoint full sets and both actual collars. Nonempty exclusive failure sets persist; no new outgoing history condition is inferred. For n=2 or 3 this high-product disjoint event may be empty, so no strict improvement at every dimension is claimed.

The complete price is now

    Delta403=(2-1/n)d_face+alpha_bin<=2S/L+4beta zeta,

replacing the preceding complete Delta display, not adding an additional old face fee. L>=max(4,4S/delta) and zeta<=min(1,delta/(8beta)) ensure Delta403<=delta while retaining the full current P_L and reserved entrance balance. At the original entrance the incremental displayed bill is still 64Lambda times the NEW complete Delta403, with all earlier coefficients once. The general residual remains unpriced.

Reviewer actually executed 28 further exact weighted-mask checks for this high-product count bound and ordered-inner exclusions in dimensions 2-8; 19 finite algebra cases were positive. These are not native full-f continuum history certificates and are separate from the 84 earlier reviewer checks and any later parent/author counts.

Independent later screen PASS. Its hard-selector discussion is strengthened by the final soft proof and review below.


## Frozen author proof reviewed: final soft strengthening

After the independent screens, read frozen r403_geometry.md (SHA 794dc9667d94ba78f3203c52fb4e023311831758c2ed4f4a68fdd025dea79932) and its standalone script. The author strengthens the preliminary hard high-product event to the actual fraction big=min(1,|S_w||S_t|/n). This supersedes the earlier hard-selector-only discussion above: the final residual is weighted by (1-|S_w||S_t|/n)_+, not just its support indicator.

The soft strengthening is valid at the same price since big<=|S_w||S_t|/n. With disjoint sets, the count equals the sum over j!=k. The raw soft occupation is bounded by 4(n-1)/q_-^2 independently of the actual collar and original mark restrictions, which may only reduce it. The author does not infer product independence after restricting to disjoint sets; its factorization is taken only after the positive majorant drops that restriction.

The complete same-joint near partition has weights shared, disjoint I_y, disjoint (1-I_y)I_z, disjoint (1-I_y)(1-I_z)big and disjoint (1-I_y)(1-I_z)(1-big). Together with the unmodified far part these sum to one pointwise. When big is fractional, the last two weights are complementary positive fractions, not disjoint indicator sets. The original source, receiver, clock, strict mass and high-rank labels remain attached. The frozen normalized E_y E_z law is never restarted or renormalized after an earlier branch is removed.

The transfer inequalities (7),(8) retain the actual soft complement and both rank supports. The exact sourcewise outgoing beta and incoming C_col bounds apply at the old source, before integrating the new witness source. Summing source-stage b_i first prevents any stage fee. The resulting two estimates are P_shared<=d_face Xq and P_big<=(1-1/n)d_face Xq; the optional n/(1+sqrt(n))^2 refinement is arithmetically correct. The external old-y conditional E_uv/Z_u identity is unchanged and remains conditioned on y. There is no reused negative capture square.

The conditional R402 inner receipt remains alpha_bin, now applied after the enlarged shared selector. Its actual paid submeasure can change, but the same bound is retained rather than duplicated. The complete price (2-1/n)d_face+alpha_bin, parameter choice, full P_L replacement and 16/32/64 core/BH/entrance multipliers are correct in the author proof. This bound does not assert that the full displayed RHS improves input by input relative to every previous complete estimate; it gives a smaller exact positive residual with its stated changed upper charge.

The final near residual has nonempty disjoint full failure sets, actual double collars, count product<n, AND precise remaining amplitude (1-product/n)_+. For n=2,3 the hard high-product event is absent but the new soft fraction can still be positive; no every-dimension strict enlargement of the hard event is claimed. No uniform positive fraction of all original traffic, no source density cap and no root price for this final residual is proved.

Reviewer actually ran r403_geometry_check.py to completion, exit 0:

    PASS subset_indicators21342 + weighted_capacity64
         +single_joint_partition3600 +coefficients64 =25070.

All arithmetic is Fraction. These are finite subset/weighted-array/partition/coefficient diagnostics, not native full high-rank core realizations. The actual center-geometric input is the inherited R402 unpartitioned single-face theorem; the arrays test consequences of its face marginal capacities. Parent and reviewer reruns are the same test cases, not additional experiments. The 84 and 28 independent reviewer screen cases are separate and not pooled with this count.

Author proof PASS within the stated scope. The final parent report and evidence review follows and completes this audit.


## Final parent report, second script and exact accounting

Read final r403_main.md and r403_readme.md, together with r403_check.py, its saved result and the author script result. The final report accurately uses the soft min(1,|S_w||S_t|/n) and retains its precise complement. It does not confuse the preliminary hard high-product event with the final fractional selector. The uniform near threshold d0 is unchanged across shared, ordered-inner and count-soft stages; far traffic is retained in full.

The parent source-labeled and actual receiver contract agrees with the author proof. The new shared selector replaces the old first-same selector, so its d_face charge is not added twice. The inherited alpha_bin two-end inner bound remains once, using the FINAL R402 main proof rather than falsely extending the auxiliary small-end theorem without proof. The count-soft branch is restricted to disjoint double-collar tags and is charged only its separate (1-1/n)d_face upper bound. The complete Delta403=(2-1/n)d_face+alpha_bin therefore REPLACES the preceding complete Delta price. Neither old common-past chi_n nor an old source-collar or negative-square credit is repeated.

The parameter allocation L>=max(4,4S/delta), zeta<=min(1,delta/(8beta)) is valid in the original beta>0 contract, with the stated beta=0 zero-flow exception. Every changed L must retain the full current mother-split P_L and relevant intermediate rank bands. Shrinking zeta changes the far complement; it is not a free improvement of a fixed covered proportion. The 16/32/64 core/BH/entrance factors in main match the already audited R398 slot exactly. All original outer/source fees remain. Global absorption requires its actual available original-entrance balance, and the low-dimensional direct whole-core estimate is an alternative rather than a stacked charge. No new W fee is introduced apart from the declared existing P_L parameter dependence.

The same-field exact positive residual is smaller than the earlier one because shared contains first-same and the soft-count split removes a further positive fraction. This does NOT imply that every full displayed numerical RHS improves input by input after its changed conservative upper charge; final main states this limitation. There is no claimed uniformly positive paid fraction of arbitrary original traffic, nor a budget for the far/disjoint-small-product actual two-collar residual.

Reviewer actually executed the parent script to exit 0:

    PASS weighted same-joint partitions and face certificates:
         initial8 +threshold_stress8 +expanded12 =28
    strict_shared_expansion_cases25 positive_soft_count_cases26
    PASS exact combined fee checks36.

This script enumerates all nonempty masks for each of its finite weighted cases, preserves the same inner flags, verifies the actual union/soft partitions, capacity majorants, old-to-new paid inclusion, soft>=hard comparison, inner-union bound and full coefficient arithmetic. Its scale=4/(max face_left*max face_right) is equivalent to separately scaling each witness marginal so its face capacity is <=2; no individual native geometry of the arrays is asserted. The recorded 25/26 positive counts are finite algebra features, not original-core existence or uniform-proportion statements.

Together with the separately run 25070 author-script grouped Fraction checks recorded above, both delivered scripts pass. Reviewer/parent repetitions are not additional cases. No new MATLAB run is claimed; the inherited all-selector R402 face theorem is the analytic native-center input, not a conclusion inferred from these mask arrays. These finite tests do not certify realization of all historical, synchronized rank or surplus gates. Their reporting and reproducibility scope in main/readme are accurate.

## Frozen byte bindings

The following SHA-256 values bind the exact final files reviewed. Later edits require updating this audit.

- `/tmp/r403_main.md`: `fb3af092319eb219ddce7e60068b20834298a72b7ce49988d6a02f4867911180`
- `/tmp/r403_readme.md`: `97e2dd1fb79c172dd4ddc8dfb8b0f992dfe366313c521034b91dba48bcaeb2b7`
- `/tmp/r403_geometry.md`: `794dc9667d94ba78f3203c52fb4e023311831758c2ed4f4a68fdd025dea79932`
- `/tmp/r403_geometry_check.py`: `b657dd18a5d36586db51d306249fe526d0a5aca4180f27727bc11ec11a53939d`
- `/tmp/r403_geometry.result.txt`: `8c434b399f295ebea9ba7145725d0c741d87b0904c67183059211d1cfe09b7ce`
- `/tmp/r403_check.py`: `6e055d548f862a9a23b57cb37619dce980e28ea2b6c86e4d2e567c7d89e71bce`
- `/tmp/r403_check.result.txt`: `507feb28bbb801d247e7ad873c03b2b1558033c690fbee2b2b22763d26c9b7fd`
- `/tmp/r402_main.md`: `f9a996b77ef3cac5f71f1dc6260e50b031dd8e52c8c16e0af3423c2bc63ec93f`


The parent candidate binding above records the prior screen, not an additional authority for the final theorem. The inherited R402 report supplies the complete unchanged external/internal mother contract and prior fee definitions; no historical full reduction is reaudited wholesale here.

FINAL PASS within this bounded actual positive-payment and report scope. The precise final residual and global absorption remain open. Freeze and stop; no further search, experiments or proof expansion are part of this audit.
