# R518 独立 PRE：完整首达的能量增量与真正缺失的壳capture

先独立推导，未读r518作者。得到真实能量增量下界（自然新壳score系数为正）、旧/新窗壳score的软平方有价比较，以及完整同质量比首达时的共同平移等距身份。它们仍不将旧α加权壳费自动变成正能量增长；精确缺口是同一旧场在新壳与旧后验上的加权capture比较，加上实际归一损失。仅本文件写入，不改仓库或他人文件。

## 1. 原对象与“完整”量词

固定R516一格的原Li=L，Q_i=||L||²，0≤L≤C；所有score用此同一场。原核 k_B=a_B1_QB1_IB，a_B=t_BR_B^(−n)，m_B=q_BR_B^n，α_B=ψ_B/(Ct_Bq_B)（t_B=0分支零）。取可测F⊂E_i，保原t_B。

这里“完整首达”明确要求每个所选父实际满足

m'_B=(1+u)m_B，R_B≤R'_B≤b，g_B=(R'_B/R_B)^n∈[1,G]，
0<u≤1，1<G≤2，h=log_γ(1+u)。

于是新窗恰为I_B+h，共同h；真实新密度 q'_B=q_B(1+u)/g_B∈[q/2,2λ]。仅“取T_B^+并在b或体积帽截断”不保证完整质量等式。未到阈值、端点R_B=b或g超限者，若未处理，其原score留在miss；若另用固定b场，须沿R517保其与其余场的cross。平台不要求逆函数唯一，只要实际等式成立即可。

记空间壳S_B=Q(B,R'_B)\Q_B，L_F=∫F k_B，H_F=〈L,L_F〉。定义真实实际新场A_F=∫F k_t(B,R'_B)dB。

## 2. 真实交叉score增量与正壳系数

自然新窗壳score为

J_new=∫F (t_B/R'_B^n)∫_(S_B)∫_(I_B+h)L(y,σ)dσdμ(y)dB≥0。

旧空间部分只移窗且新系数至少为旧系数/G，新源壳非负，故R517直接给

〈L,A_F〉≥G^(−1)[H_F−3hQ_i]+J_new。

因此严格有

〈L,A_F−L_F〉≥J_new−(1−G^(−1))H_F−(3h/G)Q_i。            (E1)

替换F、其余父保持原动作的新完整场 L'=L−L_F+A_F，能量增量准确展开，得到

||L'||²−Q_i≥2J_new−2(1−G^(−1))H_F−(6h/G)Q_i
                  +||A_F−L_F||²。                     (E2)

正系数2是真实自然壳score的系数；尚不是旧α壳收据的系数。全体F=E_i时H_F=Q_i。可随机选择达到同一完整质量比、满足同一g范围的可测半径，以上按每父概率平均仍成立，无需两source独立。

另保更精确归一：N=∫F(1−g_B^(−1))k_B，Nscore=〈L,N〉。精确增量是J_new−Nscore减去g_B^(−1)加权的旧空间窗亏损；该窗亏损由R517至多3hQ_i。故另有下界J_new−Nscore−3hQ_i。它与(E1)是两种合法估计，不能把各自较好项无证明拼接。

## 3. 完整同u首达的共同平移：实际软平方不付窗修正

定义旧窗壳场及旧窗测试平均

S_old=∫F (t_B/R'_B^n)1_SB1_IB dB，
Â_F=L_F−N+S_old。

全部所选父实际质量比同为1+u，因此精确

A_F=U_h Â_F，||A_F||²=||Â_F||²，                        (E3)

U_h是σ上的共同平移。这保真实新质量窗，只在**自范数**上使用Lebesgue平移等距；不是任意改成冻结父窗的历史过程。g_B可以随B变；共同窗位移不能随B变。未完整到阈值的截断父不能直接并入(E3)。F为真子集时，A_F自范数仍等距，但保留的L−L_F未共同平移，所以全场L'的cross不能据此删除。

特别F=E_i时，J_old=〈L,S_old〉，有精确能量身份

||A_F||²−Q_i=2J_old−2Nscore+||S_old−N||²。                (E4)

这是真实正系数的能量增量lemma，没有3h窗费；共同真实窗平移在自能量中完全抵消。但仍须比较J_old与Nscore/原α费，(E4)本身不是付款。任意F的同类身份以L_F作自能量测试场，不可把它的测试场无价换成完整Li。

## 4. 自然壳的新/旧窗score可按软能量比较

令B_S=||S_old||²。对每y，新壳旧窗流为另一正测度η_y，原场流为ν_y。两正测度的近邻pair由三个tent平移及mixed Cauchy给

∫∫1_{|s−t|≤1}dη_y(s)dν_y(t)
 ≤3||η_y*1_[0,1]||₂||ν_y*1_[0,1]||₂。

共同移位h的两个方向分别应用单边tent界；η_y共同平移的范数不变。再对同一μ用Cauchy，严格得到

|J_new−J_old|≤3h√(Q_i B_S)。                            (E5)

该比较无需壳列L1帽；B_S是实际软壳场平方，仍须有价控制。η_y为真实外壳来源权，不是ν_y的子测度，故不能直接写成3hQ_i。因Â_F≥S_old≥0，B_S≤||Â_F||²=||A_F||²，可进一步用实际A_F软平方计价，但不能把这个未知预算改名后视为已付。所有来源始终是一次μ，未抽取独立新source。

## 5. 旧α壳总费究竟是什么；真正缺的正比较

完整首达仅给Δ_B=u m_B，故旧α收据准确为

P_α=∫dμ∫F α_B t_BR_B^(−n)1_SB dB
    =u∫F α_Bt_Bq_BdB=(u/C)H_F。                         (E6)

它控制的是旧后验平均 ̄L_old=Cα_B。自然J_new/old却用真实新壳上的同一L平均：

J_new=∫F(u/g_B)t_Bq_B ̄L_shell,new(B)dB，
J_old=∫F(u/g_B)t_Bq_B ̄L_shell,old(B)dB。

mass等式不比较这两个shell均值与旧后验均值；高α>1/A_n只限制旧均值，没有新壳的下界。帽C给的是新壳score上界，方向不能倒置。q'_B/q_B=(1+u)/g_B或密度增长本身也不提供Li加权capture。

一个具体可验、足够的额外条件是实际旧窗壳capture

∫SB∫IB L dσdμ ≥κu∫QB∫IB L dσdμ

（可改为相应g加权的积分版本）。若在全格F=E_i确能证明它，则J_old≥κu∫ψ_B/g_B，而Nscore≤(1−1/G)Q_i；(E4)严格给

||A_F||²−Q_i≥2[κu−(G−1)]Q_i/G+||S_old−N||²。            (E7)

只有κu>G−1时该保守系数为正。若另证明**新窗版本**的同类capture，走真实新窗交叉式(E1)的保守正系数阈值是κu>G−1+3h；只有旧窗capture时还须显式支付(E5)，不能只保这笔3h窗费。该capture是新增真实几何前提，既不由完整首达也不由原后验定义自动推出。本PRE没有将条件模板当一般结论，也未作无目的反例扫描。

## 6. 工具证据与停止范围

实际使用本机 `/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python -I`。SymPy核旧窗能量展开与(E7)系数；Fraction以两正非等权原子窗流、三共同h共12种组合精确核(E5)的平方形式。stdout：`PASS 12 exact mixed-tent absolute cross-price checks; old-window energy identity and positive capture coefficient`，退出0。有限质量坐标测度只是代数核验，不是原子接收替代；一般式由tent正部、mixed Cauchy、平移等距、真实首达质量及Tonelli证明。未运行MATLAB。

可用新增接口是(E1)—(E5)，特别完整同u首达的实际B_A自能量可直接按旧窗测试场研究。未付仍是同一动作族的capture、归一/公共能量付款及未完成父score；没有得到原α壳费的无条件正能量增长，也未完成根阶。交付后停止等作者。

## 7. 新rapid分支：真实selector提供实际一次W付款

父代理随后提出的付款独核通过，且无需先把旧α壳费变成能量增长。仍固定R516原Li、α_B∈[0,1]、t_B和An=1+nlog(b/a)。令

V_B=min{G^(1/n)R_B,b}，K_B=max{1+u,Anα_B}，
rapid={m(B,V_B)≥K_Bm_B}。

在rapid上取真实首次达到K_Bm_B的P_B。K_B>1、m_B>0及质量连续非减保证P_B>R_B、P_B≤V_B且m(B,P_B)=K_Bm_B，包含P_B=V_B或b恰好达到的情况，平台不破等式。可从整个[a,b]的单调质量超水平集定义首次点，其可测性由稠密有理点及端点给出；不能把变上限处的孤立达到点遗漏。P_B只依赖B、固定输入及固定Li，完全先于来源抽样。

写g_P=(P_B/R_B)^n≤G，真实q_P=K_Bq_B/g_P，则

q_B≤Gq_P/K_B，α_B/K_B≤1/An。

按原rapid局部交叉score精确得

E_rapid=C∫rapid α_Bt_Bq_BdB
 ≤(CG/An)∫rapid t_Bq_PdB≤CSGW。                         (P1)

最后一步是任意真实Lebesgue中心selector P_B∈[a,b]的原空间列帽：∫t_Bq_P≤SAnW。它不要求q_P落在固定密度带；P_B可只作付款核，不冒称原合法替代，未使用EX或新的后验。计数可数源格时把P_B合成同一个全中心selector后只付一次W，不能每格重收全局W。

RB=b时V_B=RB且K>1，所以rapid为空；a=b同理。t=0或α=0的score为零，按零分支处理无逆费用。W=0或原零场也单列。首次阈值超过总µ质量的中心自然不是rapid。若先前low已付，可只取剩余high中的rapid，(P1)对其任意子集仍成立；不得重复记同一分支收据。此为raw交叉score付款，不重新生成原accepted history，和R509旧来源分支保持分账。

rapid保证首次u质量壳存在且在P_B之前：其目标(1+u)m_B≤K_Bm_B。对该壳真实Δ=u m_B，任意rapid子集的原α壳权准确为

∫dµ∫α_Bt_BR_B^(−n)1_first-u-shell dB=(u/C)E_rapid≤uSGW。  (P2)

它不要求壳上Li均值有下界，故与前述capture缺口不矛盾；付款来自另一个真实selector的空间总列。

剩余slow必须按原α依赖描述：由rapid取≥，slow给 m(B,V_B)<K_Bm_B，且对所有R∈[R_B,V_B]有同一严格上界，K_B≤max(1+u,An)。若Anα_B≤1+u，则K=1+u，整段确在固定u门内；若Anα_B>1+u，slow仍可很早达到首个u壳，只是到V未达到Anα倍质量。此时不能声称全段移窗≤h、全段仍c=2、首u区间必有固定宽度或slow已付。剩余上限是O(Anα)，没有消除全部α依赖。付款后仍需实际slow动作/BA与miss联合预算。

本人实际指定Python-I/Fraction核192个正比例/零权pointwise场景的α/K、原密度向qP比较及score付款系数；SymPy核首次u壳的(u/C)系数。输出 `PASS 192 exact rapid-payer pointwise scenarios and first-u weighted shell identity`，退出0。一般真实Lebesgue付款由连续首次选择、Tonelli及原空间包络证明，有限算术不替代证明。未读作者稿。新增rapid为实际已付分支，slow及一般根阶预算仍未闭合。

## 8. 作者后审：慢支相位放宽及实际平方价格

在先独核命题后，获授权读取 `/tmp/r518_proof.md`、main与geometry后稿。主proof对未付high中的slow允许任意来源前概率动作于全[R_B,V_B]，明确新密度不必仍c=2；旧原场与history未改，也未用域外EX。这是有价比较域放宽，不是虚称旧合法替代。

z=log_γ(m'/m)∈[0,log_γKmax)、Kmax=max{1+u,An}。真实A_ij保原新质量窗及分相的未归一概率质量；每父总概率仍1。J=1+floor(log_γKmax/h)是安全上界（端点可多计空相），固定参数时O(log(n+2))。Z_i=Σ_jU_(-jh)A_ij只作比较，残移z−jh∈[0,h)。对全部slow及其全部动作一次用R517，故只付3hQi；不能逐相重复收费。

有限Hilbert Cauchy给 ||Z_i||²≤JΣ_j||A_ij||²，J必须保留。各phase不自动正交；其实际真实密度带为[qγ^(jh)/G,λγ^((j+1)h))，比值≤Gγ^h r，因此统一phase帽C*=S[1+log(Gγ^(1+h)r)]正确。粗B=Σij||Aij||²≤C*SA_nW使用的是全部概率selector的原空间包络，不是新密度总上帽，仍只线性维数。

完整slow每父都有非空动作区间（包含旧半径），原score精确为Qg−Elow−Erapid，无额外miss。Young严格给作者(7)：

Q≤{G²J B/(1−3h)²+2CS(1+G)W/(1−3h)}/(1−β)²。

这里B是实际phase场平方和，不是Zi平方，也不等于合并实际候选场的平方。若仅选择部分slow，则未选score必须恢复；作者已限定。B的多对数预算尚未证明，相数为对数不替它付款。

geometry把rapid扩展到任意ζ>0，阈值max{1+u,Anα/ζ}、付款CSGζW及原首u壳uSGζW正确。其严格slow结论K=Anα/ζ>1+u依赖该稿H本来已完成首u；这不同于proof全high slow，未被混用。主proof取ζ=1，故其Kmax/J相容。共同平移的E_F≤G√(QgBT)、原分母壳与父场的tildeA恒等式及≤G²BT方向正确，未反用成BT上界。

本人实际用指定Python-I从proof正文经stdin重放，输出 `PASS 144 exact phase/probability/unitary/paid-overlap checks; algebra only`；从geometry重放输出 `PASS 95 exact adaptive-capture and real-source aligned-window square checks`，均退出0。phase标签模型明确仅代数接口，geometry另有真实连续中心/来源积分，二者不冒用。当前未见实质错误，等待最终九文件冻结；此前独立内缩/capture接口不等于当前slow预算已付。
