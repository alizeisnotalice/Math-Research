#!/usr/bin/env python3
"""R518 mixed positive-window bridge and true-L1 uniform-mass first-hit model."""
from fractions import Fraction as Q
from pathlib import Path
import json,sys,time,platform
import sympy as sp
import flint
from flint import arb,ctx
ctx.prec=256
ROOT=Path(__file__).resolve().parent
checks=0

def ck(x):
 global checks
 assert bool(x)
 checks+=1

def tent(x):return max(Q(0),1-abs(x))
def finite_mixed():
 ns=[Q(0),Q(1,2)];nw=[Q(1),Q(1)]
 ks=[Q(-1,4),Q(3,4),Q(3,2)];kw=[Q(1),Q(1,2),Q(3,2)]
 def cross(h):return sum((wi*wj*tent(si-sj-h) for si,wi in zip(ns,nw) for sj,wj in zip(ks,kw)),Q(0))
 def selfenergy(ss,ww):return sum((wi*wj*tent(si-sj) for si,wi in zip(ss,ww) for sj,wj in zip(ss,ww)),Q(0))
 def near(h):return sum((wi*wj for si,wi in zip(ns,nw) for sj,wj in zip(ks,kw) if abs(si-sj-h)<=1),Q(0))
 qn=selfenergy(ns,nw);qk=selfenergy(ks,kw);base=cross(Q(0));rows=[]
 for h in [Q(-1),Q(-1,2),Q(-1,4),Q(0),Q(1,4),Q(1,2),Q(1)]:
  cp=cross(h);diff=cp-base;oldnear=near(Q(0));newnear=near(h)
  ck(oldnear**2<=9*qn*qk);ck(newnear**2<=9*qn*qk)
  ck(diff**2<=9*h*h*qn*qk)
  ck(base-cp<=abs(h)*oldnear);ck(cp-base<=abs(h)*newnear)
  rows.append({'h':h,'mixed_correlation':cp,'signed_difference':diff,'squared_difference':diff**2,'squared_3h_bound':9*h*h*qn*qk,'old_near_mass':oldnear,'shifted_near_mass':newnear})
 # Generic algebra: polarization and expansion, not a numerical universal proof.
 x,y,H=sp.symbols('x y H',real=True)
 ck(sp.expand((x-y)**2-(x*x+y*y-2*x*y))==0)
 return {'scope':'finite independent positive window flows only, not atomic receivers','nu_starts':ns,'nu_weights':nw,'kappa_starts':ks,'kappa_weights':kw,'Q_nu':qn,'Q_kappa':qk,'unshifted_cross':base,'rows':rows,'bridge':'abs(<F,U_hG>-<F,G>)^2<=9*h^2*Qnu*Qkappa; finite checks do not replace general positive-measure proof'}

def ball(x):
 x=sp.sympify(x)
 if x.is_Rational:return arb(int(x.p))/int(x.q)
 if x.func==sp.Add:return sum((ball(a) for a in x.args),arb(0))
 if x.func==sp.Mul:
  z=arb(1)
  for a in x.args:z*=ball(a)
  return z
 if x.func==sp.Pow and x.args[1].is_Integer:return ball(x.args[0])**int(x.args[1])
 if x.func==sp.log:return ball(x.args[0]).log()
 raise ValueError(x)
def st(x):return ball(x).str(35,radius=True)

def real_model():
 eps=sp.Rational(1,1024);length=2*eps;xstar=sp.Rational(85,96);Rold=sp.Rational(3,2)
 B=sp.symbols('B',real=True);Rnew=2*(xstar-B)
 # Source intervals are true positive-length constant-density L1 pieces.
 I=(sp.Rational(-1,32),sp.Rational(1,32));J=(sp.Rational(19,32),sp.Rational(21,32));K=(sp.Rational(27,32),sp.Rational(29,32));dens=[48,16,48]
 ck(48*(xstar-K[0])==2);ck(K[0]<xstar<K[1])
 for b in [-eps,eps]:
  rn=Rnew.subs(B,b);ck(1<=rn<=2);ck(sp.Rational(8,3)<=6/rn<=sp.Rational(16,3))
  ck(b-Rold/2<=I[0] and b+Rold/2>=J[1] and b+Rold/2<K[0])
  ck(b-rn/2<=I[0] and b+rn/2==xstar)
 old_platform_start=sp.Rational(21,16)-2*B;old_platform_sup=sp.Rational(27,16)-2*B
 ck(sp.expand(Rnew-old_platform_sup)==sp.Rational(1,12))
 # m=4 throughout old plateau. Thereafter K has density48, so derivative dm/dR=24.
 target_mass=4+24*(Rnew-old_platform_sup);ck(sp.expand(target_mass)==6)
 a0=length/Rold
 a1=sp.log((xstar+eps)/(xstar-eps))/2
 # Exact primitive verified, followed by explicit endpoints (avoids logcombine blowup).
 primitive=-sp.log(xstar-B)/2;ck(sp.simplify(sp.diff(primitive,B)-1/Rnew)==0)
 h=sp.log(sp.Rational(3,2))/sp.log(4);ck(ball(h)>0 and ball(1-h)>0)
 # Coefficients on actual source regions I,J,K_prefix,K_rest; masses are true integrals.
 masses=[3,1,2,1]
 def comp(vec,mass):return (vec,mass)
 F=comp([a0,a0,0,0],4);Ahat=comp([a1,a1,a1,0],4);A=comp([a1,a1,a1,0],6)
 Z=comp([a0-a1,a0-a1,0,0],4);N=comp([0,0,a1,0],4)
 Znew=comp(Z[0],6);Nnew=comp(N[0],6)
 def inner(X,Y):
  ov=1 if X[1]==Y[1] else 1-sp.log(sp.Rational(max(X[1],Y[1]),min(X[1],Y[1])))/sp.log(4)
  return sum((m*x*y for m,x,y in zip(masses,X[0],Y[0])),sp.Integer(0))*ov
 def norm(X):return inner(X,X)
 q0=norm(F);qhat=norm(Ahat);qnew=norm(A)
 ck(sp.expand(qnew-qhat)==0)
 ck(sp.expand(qhat-q0+2*inner(F,Z)-norm(Z)-norm(N))==0)
 ck(inner(F,N)==inner(F,Nnew)==0)
 ck(sp.expand(inner(A,Nnew)-inner(Ahat,N))==0)
 ck(sp.expand(inner(A,N)-(1-h)*inner(A,Nnew))==0)
 old_cross_frozen=inner(F,Ahat);old_cross_actual=inner(F,A)
 window_cross_loss=old_cross_frozen-old_cross_actual
 ck(sp.expand(window_cross_loss-h*old_cross_frozen)==0)
 ck(sp.expand(window_cross_loss**2-16*a0*a0*a1*a1*h*h)==0)
 ck(ball(9*h*h*q0*qhat-window_cross_loss**2)>0)
 ck(ball(qnew-q0)>0);ck(ball(old_cross_actual-q0)<0);ck(ball(a0-a1)>0)
 C=1+sp.log(8);alpha=a0/C;An=1+sp.log(2);ck(ball(alpha)<ball(1/An))
 ck(ball(An*alpha)<arb(3)/2)
 G=sp.Rational(4,3);Krapid=sp.Rational(3,2);g=Rnew/Rold
 ck(g.subs(B,-eps)<=G)
 ck(sp.cancel(6/Rnew-Krapid*sp.Rational(8,3)/g)==0)
 return {'source_intervals':[I,J,K],'source_densities':dens,'source_masses':[3,1,3],'W':7,'E':[-eps,eps],'E_Lebesgue_length':length,'radius_window':[1,2],'density_band':[sp.Rational(8,3),sp.Rational(16,3)],'old_radius':Rold,'old_mass':4,'uniform_mass_multiplier':sp.Rational(3,2),'new_mass':6,'first_hit_radius':Rnew,'old_mass4_plateau_start':old_platform_start,'old_mass4_plateau_true_sup':old_platform_sup,'new_target_first_hit_sup_definition':'sup{r in [Rold,2]:mu Q(B,r)<=6}; unique hit inside positive-density K','new_radius_minus_old_platform_sup':sp.Rational(1,12),'new_right_edge_xstar':xstar,'K_prefix_mass':2,'old_window':[1,2],'new_window_start':'1+h','uniform_h':h,'uniform_h_arb':st(h),'field_coeff_a0':a0,'field_coeff_a1':a1,'field_coeff_a1_arb':st(a1),'field_relation':'A=U_h Ahat, Ahat=F-Z+N; all kernels use actual center-integrated coefficients','Qold':q0,'Qnew':qnew,'Qfrozen_new':qhat,'Qnew_over_Qold_arb':st(qnew/q0),'Qold_arb':st(q0),'Qnew_arb':st(qnew),'old_field_cross_frozen_new':old_cross_frozen,'old_field_cross_actual_new':old_cross_actual,'old_field_cross_actual_arb':st(old_cross_actual),'normalizer_L1_mu_sigma_loss':4*(a0-a1),'oldscore_normalizer_loss':inner(F,Z),'newscore_normalizer_loss_same_new_window':inner(A,Znew),'normalizer_loss_energy':norm(Z),'old_window_shellcross_oldfield':inner(F,N),'new_window_shellcross_oldfield':inner(F,Nnew),'old_window_shellcross_frozen_newfield':inner(Ahat,N),'new_window_shellcross_actual_newfield':inner(A,Nnew),'frozen_shellcross_actual_newfield_mixed_windows':inner(A,N),'shell_energy_old_and_new_windows':norm(N),'actual_old_cross_window_loss':window_cross_loss,'actual_old_cross_window_loss_arb':st(window_cross_loss),'squared_mixed_3h_bound':9*h*h*q0*qhat,'rapid_payment_relevance':{'An':An,'alpha':alpha,'K':Krapid,'G':G,'g_radius_ratio':g,'classification':'K=max(1+u,An*alpha)=1+u=3/2; complete true rapid first hit, also all soft; not remaining slow-high test','old_score_integral':q0,'candidate_coefficient_payment_integral':C*G/An*6*a1,'source_payment_once_CSGW_if_source_envelope_applies':C*G*7},'soft_relevance':{'C':C,'L_infty':a0,'alpha_all_E':alpha,'alpha_arb':st(alpha),'soft_threshold':1/(1+sp.log(2)),'scope':'whole model soft; no high-budget validation'},'scope':'true L1 source and real positive-Lebesgue centers; full same-u first hit, not globally maximal configuration'}

def rapid_parameter_logic():
 # Bounded exact branch checks, not a certification of the general source envelope.
 rows=[]
 for An,alpha in [(Q(1),Q(1,4)),(Q(4),Q(1)),(Q(8),Q(1,2)),(Q(4),Q(0))]:
  u=Q(1,2);G=Q(4,3);g=Q(5,4);K=max(1+u,An*alpha);qold=Q(2);qnew=K*qold/g;C=Q(3);t=Q(1)
  ck(alpha/K<=1/An);ck(C*alpha*t*qold<=C*G/An*t*qnew)
  rows.append({'An':An,'alpha':alpha,'u':u,'K':K,'g':g,'G':G,'qold':qold,'qnew':qnew,'left_score':C*alpha*t*qold,'right_coefficient_payment':C*G/An*t*qnew})
 C,G,A,S,W=sp.symbols('C G A S W',positive=True)
 ck(sp.cancel(C*G/A*(S*A*W)-C*S*G*W)==0)
 return {'scope':'exact parameter implication only; not finite verification of a general source-envelope theorem','logic':'K>=An*alpha, qnew=K*qold/g, g<=G imply alpha/K<=1/An and C*alpha*t*qold<=(C*G/An)*t*qnew','assumed_source_envelope':'integral t*qnew <= S*An*W gives once payment C*S*G*W','rows':rows}

def main():
 start=time.perf_counter();mixed=finite_mixed();model=real_model();rapid=rapid_parameter_logic()
 def ser(x):
  if isinstance(x,Q):return str(x)
  if isinstance(x,sp.Basic):return str(x)
  raise TypeError(type(x))
 out={'scope':'bounded mixed-window bridge and real uniform-mass first-hit payment study; no universal theorem from finite checks','environment':{'executable':sys.executable,'python':platform.python_version(),'sympy':sp.__version__,'python_flint':flint.__version__,'arb_precision_bits':ctx.prec},'rapid_parameter_logic':rapid,'mixed_window_certificate':mixed,'real_model':model,'checks':checks,'seconds':time.perf_counter()-start}
 (ROOT/'r518_numeric.json').write_text(json.dumps(out,default=ser,indent=2)+'\n')
 print('REAL Qold',model['Qold_arb'],'Qnew',model['Qnew_arb'],'old-cross-new',model['old_field_cross_actual_arb'],flush=True)
 print('REAL Qnew/Qold',model['Qnew_over_Qold_arb'],'uniform h',model['uniform_h_arb'],flush=True)
 print('PASS finite independent-flow mixed bound and true-L1 same-u first-hit field identities; no general high theorem')
if __name__=='__main__':main()
