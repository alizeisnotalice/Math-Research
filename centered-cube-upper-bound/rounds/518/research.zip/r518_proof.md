# R518：慢捕获部分的质量相位分组与有价比较

## 1. 固定原场，先付款再比较

沿R516—517，μ=f dx≥0、W<∞，真实源格C_i与中心E_i不变。旧半径a≤R_B≤b≤2a，m_B=q_BR_B^n，q≤q_B≤λ=rq，0≤t_B≤S。原单位窗起点s_B=log_γ m_B，k_B=t_BR_B^−n1_QB1_[sB,sB+1]，L_i=∫E_i k_B，Qi=||Li||²。Qg=ΣQi≥(1−β)²Q，C=S[1+log(γr)]，A_n=1+nlog(b/a)。固定α_i(B)=〈Li,kB〉/(Ct_Bq_B)∈[0,1]；t=0为零支。

原低层α≤1/A_n只支付一次E_low≤CSW。本稿仅在其余high内定义rapid/slow，使两付款不重叠。取固定1<G≤2、0<h<min{1/6,log_γ2}，u=γ^h−1，

V_B=min{G^(1/n)R_B,b}，K_B=max{1+u,A_nα_i(B)}。

rapid={m(B,V_B)≥K_Bm_B}，slow为high中的补集。geometry证明真实payer半径首达P_B满足

E_rapid≤CSGW。                                           (1)

payer不要求仍处于原固定扩带；它只用于来源包络，不能冒作旧合法动作。α固定，不在删除rapid后重算。

## 2. 在整个固定体积邻域选择动作

在slow上，每个B可以选任意来源抽样前的可测概率核π_B，支持整个[R_B,V_B]。不再要求每个动作只捕获首个u比例质量，也不要求新密度仍在[q/2,2λ]。所有真实新质量及新窗照常保留。

这组概率核总是非空。一个不使用来源点的具体选择是：若R_B<b/G^(1/n)，在[R_B,G^(1/n)R_B]取归一log半径律 n/(logG) dR/R；否则取端点δ_b。R_B=b也取δ_b。不规定必须用这个律；本轮没有证明该具体律的平方预算。

slow给全部候选的真实质量比

1≤m(B,R)/m_B<K_B≤Kmax:=max{1+u,A_n}。                    (2)

一般不能把(2)改成≤1+u。它也不使完整候选仍在固定c=2带内。下面显式支付质量相位分组费用，避免这一错误。

## 3. 真实场先分组，再用酉平移作比较

令z(B,R)=log_γ(m(B,R)/m_B)，j(B,R)=floor(z/h)。取

J=1+floor(log_γ Kmax/h)，j∈{0,…,J−1}。

定义真实候选子场

A_ij=∫_(slow∩E_i)∫_(jh≤z<(j+1)h) k_t(B,R)π_B(dR)dB。

这里k_t仍用真实新源盒、真实新质量窗与原t_B。父可以在多个j上分配概率，但总概率是1；不是重复中心。每个候选盒仍在原源格。

令(U_c F)(y,σ)=F(y,σ−c)。它在同一μ_i×dσ上是酉平移。定义比较场

Z_i=Σ_j U_(-jh) A_ij。                                  (3)

Z_i不是实际新质量窗场；这是显式比较操作，不替换实际质量。对属于j的真实动作，移回jh后，剩余窗位移为z−jh∈[0,h)。新盒包含旧盒且新系数≥旧系数/G，所以Z_i≥D_i/G，其中D_i保旧盒与旧系数，只按同一动作概率移动剩余窗。

R517的正窗损失引理一次应用于slow全部父和全部动作，给

〈Li,Z_i〉≥[〈Li,L_slow,i〉−3hQi]/G。                    (4)

不能逐j分别收3hQi。正性证明中的每父总权仍是1，故一次(4)没有J倍窗损失。

## 4. 对相位重叠支付明确的对数费用

定义真实分组平方

\[
\mathcal B=\sum_{i,j}\|A_{ij}\|^2.
\]

每个i内的相位组不自动正交。有限Hilbert Cauchy及酉性准确给

||Zi||²≤JΣ_j||Aij||²。                                 (5)

不同源格在来源变量上正交，故Σ_i||Zi||²≤J B。J=O_(h,γ)(log(n+2))是明确费用，不省略。所需付款对象B由真实候选核构成，不是冻结窗或独立来源的替代。

每个相位的真实密度带为

γ^(jh)q/G≤q(B,R)<γ^((j+1)h)λ，

带比≤Gγ^h r。因此原窗帽可逐相位用统一

C_*=S[1+log(Gγ^(1+h)r)]。

它不依赖j或n；但不能将各相位场的帽直接视为合场的同一个帽。粗界仍只有B≤C_*SA_nW，由真实概率selector总列积分给出，尚无多对数付款。不能仅因为相位数为对数就声称B已经支付。

## 5. 无遗漏选择的完整回代

slow被概率动作完整覆盖，因此在本构造里没有额外miss：

Σ_i〈Li,L_slow,i〉=Qg−E_low−E_rapid。

由(1)、(4)、(5)及同一真实来源直和Cauchy，

(1−3h)Qg−CS(1+G)W≤G√(Qg J B)。                         (6)

记d=1−3h>0，Young给

\[
\boxed{Q\le\frac1{(1-\beta)^2}
\left[\frac{G^2J}{d^2}\mathcal B+
\frac{2CS(1+G)}d W\right].}                            (7)
\]

若只对slow的一部分提供动作，其余原score必须加回并相应吸收；(7)的无miss版本只用于本稿完整覆盖的概率族。没有将首达窗门不满足者删除。

这把R517逐父受首达限制的动作域放宽到完整固定体积邻域，代价是明确的J对数因子，快速质量增长部分已有真实W付款。成功标准仍是对同一slow输入及选择核证明B≤polylog(n)W，或者足够小的同Q收缩。当前没有这个估计，粗B界反而仍线性n，不能当最终进展。

原R_*≤2√(DWQ)、D=1+log_γr+nlog_γ(b/a)、完整入口及所有未付旧费用保持。一般根阶目标未完成。

## 6. 本机有限相位代数核验

以下Fraction程序只核有限Hilbert窗标签与概率的相位比较，不把标签原子冒作真实接收中心或满足实际质量方程的立方体。测试保每父总概率1、不同父/动作相位、残移门、每相位酉性及J合并价格。一般几何合法性由第1—5节负责。

```python
from fractions import Fraction as F
from itertools import product
T=lambda x:max(F(0),1-abs(x))
def ip(a,b):return sum(w*v*T(x-y) for x,w in a for y,v in b)
count=0
for loc in ([F(0),F(1,2),F(5,4)],[F(0),F(1),F(2)]):
 L=list(zip(loc,[F(1),F(2,3),F(3,2)]));Q=ip(L,L)
 for h,G in product((F(1,8),F(1,4)),(F(3,2),F(2))):
  for pattern in ((0,1,2),(2,0,1),(1,1,0)):
   phases=[[],[],[]];aligned=[];frozen=[]
   for k,(s,w) in enumerate(L):
    for action,p in enumerate((F(1,3),F(2,3))):
     j=(pattern[k]+action)%3;d=h*F(k+action,4)
     g=1+(G-1)*F(action+1,2)
     phases[j].append((s+j*h+d,w*p/g))
     aligned.append((s+d,w*p/g))
     frozen.append((s+d,w*p))
   assert ip(L,frozen)>=Q-3*h*Q;count+=1
   assert ip(L,aligned)>=(Q-3*h*Q)/G;count+=1
   B=sum(ip(a,a) for a in phases)
   assert ip(aligned,aligned)<=3*B;count+=1
   for j,a in enumerate(phases):
    shifted=[(x-j*h,w) for x,w in a]
    assert ip(a,a)==ip(shifted,shifted);count+=1
print('PASS',count,'exact phase/probability/unitary/paid-overlap checks; algebra only')
```
