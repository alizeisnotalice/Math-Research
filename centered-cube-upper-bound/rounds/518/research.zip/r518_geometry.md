# R518：保 α 的自适应快速捕获付款与首达场的精确平方连接

本轮证明一项实际 O(W) 付款：若短体积区间内捕获的质量倍数达到 max{1+u,A_nα_B/ζ}，则该中心族在原第一层首达壳 K_α 中的费用≤uSGζW。阈值保留原 α，故不要求所有父都捕获到 A_n 倍。

另证明：在同一固定增量 u 的首达端点，全部真实质量窗有同一个平移。把实际新场作这个共同单位平移后，原父场与原分母壳场准确相加，给 K_α 与实际新场软平方的无 3h 损失连接。该连接尚未提供新场平方的上界；慢捕获部分的重复仍未支付。

## 1. 冻结对象与准确待付款

沿 R517/R516 的固定源格与原局部场 L_i，保原 μ、t_B≤S、中心 E_i、原 R_B、m_B=q_BR_B^n、q≤q_B≤λ。记

\[
C=S[1+\log(\gamma r)],\qquad A_n=1+n\log(b/a),\qquad
\alpha_i(B)=\frac{\psi_i(B,R_B)}{Ct_Bq_B}\in[0,1].
\]

t_B=0、ψ_i=0 对应的零费分支单列。α 始终由原 L_i 和原父窗定义，不因本轮筛选而重算。

固定 u∈(0,1)，h=log_γ(1+u)，1<G≤2。H_i 是已有真实首达中心族；其原第一层首达 T_B 满足

\[
R_B\le T_B\le V_B:=\min\{G^{1/n}R_B,b\},\qquad
\mu Q(B,T_B)=(1+u)m_B.
\]

所有盒仍在原源格内。准确原壳列为

\[
K_\alpha(y)=\sum_i\int_{H_i}\alpha_i(B)t_BR_B^{-n}
1_{Q(B,T_B)\setminus Q_B}(y)dB,
\]

\[
E_H:=\sum_i\int_{H_i}\psi_i(B,R_B)dB
=\frac C{u}\int K_\alpha\,d\mu.\tag{1}
\]

下面付的仍是这个原第一层壳列，不把它换成后来更大的壳后声称完成。

## 2. 新付款命题：按原 α 自适应的快速捕获

给定 ζ>0，定义真实质量倍率阈值

\[
\mathcal K_B=\max\{1+u,A_n\alpha_i(B)/\zeta\},
\]

以及快速捕获父族

\[
H_{i,\rm rapid}=\{B\in H_i:\mu Q(B,V_B)\ge\mathcal K_Bm_B\}.
\tag{2}
\]

**命题。** 对这些中心，原交叉 score 和原第一层壳列满足

\[
\boxed{E_{\rm rapid}\le CSG\zeta W,\qquad
\int K_{\alpha,\rm rapid}d\mu\le uSG\zeta W.}\tag{3}
\]

证明：μ=f dx 使径向质量连续。在每个快速中心取首次达到质量 K_Bm_B 的半径 P_B。该半径来源抽样前可测，且

R_B≤P_B≤V_B≤b，m(B,P_B)=K_Bm_B。

写 g_B=(P_B/R_B)^n≤G，q_P=m(B,P_B)/P_B^n，准确有

\[
\alpha_i(B)t_Bq_B
=\frac{\alpha_i(B)g_B}{\mathcal K_B}t_Bq_P
\le\frac{G\zeta}{A_n}t_Bq_P.\tag{4}
\]

这里始终保留 α，关键是 α/K_B≤ζ/A_n。所有源格的快速中心互斥，P_B 是同一个真实中心域上的半径 selector，因此原接收中心包络一次给

\[
\int_{\cup_iH_{i,\rm rapid}}t_Bq_PdB
=\int d\mu(y)\int_{\cup_iH_{i,\rm rapid}}
 t_BP_B^{-n}1_{Q(B,P_B)}(y)dB
\le SA_nW.
\]

与(4)相乘并用 ψ_i=Cα_i t_Bq_B，得第一式(3)。第二式直接对**原第一层壳**使用(1)；没有用 P_B 替换 T_B。证明完成。

P_B 是一次来源付款的辅助 selector，不是声称满足 [q/2,2λ] 的比较动作。其密度可很高，本证明只用半径窗与真实来源列帽，完全不对它套固定扩大带的 C₂ 帽或旧 EX。因此没有暗中扩大动作带并沿用旧合法性。

取 ζ=1 即得到独立常数 W 费。相较统一要求 K≈A_n，本命题较强：小 α 父只需常数量级的真实捕获，中间 α 父只需 A_nα 倍；不能先用 α≤1 抹掉这项改进。若 K_B=1+u，则 H_i 的原首达已经保证(2)，所以这类父全部被本命题实际支付。

## 3. 慢捕获部分留下的准确约束

剩余 H_(i,slow)=H_i\H_(i,rapid) 满足

\[
\mathcal K_B=A_n\alpha_i(B)/\zeta>1+u,
\qquad
\frac{\mu Q(B,V_B)}{m_B}<\frac{A_n\alpha_i(B)}\zeta.\tag{5}
\]

所以在固定短体积区间 [R_B,V_B] 中可完成的固定倍率 (1+u) 首达数不超过

\[
\left\lfloor\log_{1+u}\bigl(A_n\alpha_i(B)/\zeta\bigr)\right\rfloor,
\]

统一为 O_u(log(A_n/ζ+1))。这只是一个真实捕获次数约束；次数为对数不自动支付同格来源重复，也不自动给出半径覆盖测度或实际软平方上界。本稿不继续迭代到新动作域。

## 4. 同一个 u 的首达端点：实际场的窗平移是单位算子

对任意保留的首达父族 F_i⊂H_i（可以选 slow，也可以其他预先固定子集），定义其**实际**首达场

\[
A_i^T(y,\sigma)=\int_{F_i}t_BT_B^{-n}1_{Q(B,T_B)}(y)
1_{[s_B+h,s_B+h+1]}(\sigma)dB,
\quad s_B=\log_\gamma m_B.
\tag{6}
\]

因为 T_B≤G^(1/n)R_B 且 m_T=(1+u)m_B，真实新密度在 [q/G,(1+u)λ]⊂[q/2,2λ]。这一次端点动作完全符合固定扩大带。

令 U_-h 表示把所有新窗同时移回旧窗的平移：在当前函数约定下，(U_-hF)(y,σ)=F(y,σ+h)。它在 H_i=L²(μ_i×dσ) 上保范数。记

\[
L_{F_i}=\int_{F_i}t_BR_B^{-n}1_{Q_B}1_{[s_B,s_B+1]}dB,
\quad B_T=\sum_i\|A_i^T\|^2.
\]

由空间包含与系数比，逐点有

\[
U_{-h}A_i^T\ge G^{-1}L_{F_i}.
\tag{7}
\]

因而保同一个原测试场 L_i，

\[
E_F:=\sum_i\langle L_i,L_{F_i}\rangle
\le G\sum_i\langle L_i,U_{-h}A_i^T\rangle
\le G\sqrt{Q_gB_T},\qquad Q_g=\sum_i\|L_i\|^2.
\tag{8}
\]

利用原首层捕获等式，也得到

\[
\boxed{\int K_{\alpha,F}d\mu
\le\frac{uG}{C}\sqrt{Q_gB_T}.}\tag{9}
\]

这里没有逐层付 3hQ_g：同一 u 使全部窗端点准确平移 h，整场单位变换不改变实际能量。移回后的比较场不宣称是实际质量窗的合法选择器；用于付款的 B_T 仍是式(6)原样的实际场范数，二者由单位变换精确相等。没有把原 history 移到新父或更改真实来源。

## 5. 原分母壳与实际平方的准确分解

令 g_B=(T_B/R_B)^n∈[1,G]，定义带 g_B 权的实际首达场

\[
\widetilde A_i^T=\int_{F_i}g_B\,k_t(B,T_B)dB,
\]

以及原分母、旧窗的壳场

\[
J_i(y,\sigma)=\int_{F_i}t_BR_B^{-n}
1_{Q(B,T_B)\setminus Q_B}(y)1_{[s_B,s_B+1]}(\sigma)dB.
\]

严格恒等式为

\[
U_{-h}\widetilde A_i^T=L_{F_i}+J_i.
\tag{10}
\]

因此

\[
\|L_{F_i}\|^2+2\langle L_{F_i},J_i\rangle+\|J_i\|^2
=\|\widetilde A_i^T\|^2
\le G^2\|A_i^T\|^2.
\tag{11}
\]

这个式子保留实际旧盒—新壳交叉项及壳平方。它不是 B_T 的上界，而是说明实际新平方具体包含哪些正能量；不能把方向倒用为已付款。式(8)/(9)是 K_α 与实际 B_T 的有价连接，未强求 K_α 的逐来源 L1 小帽。

## 6. 本轮付款如何进入原完整预算，及仍缺哪一步

对当前 H，准确拆分

\[
E_H=E_{\rm rapid}+E_{\rm slow}
\le CSG\zeta W+G\sqrt{Q_g B_{T,\rm slow}}.
\tag{12}
\]

对应原 K_α 也按(1)拆分。第一项已实付；第二项没有通过改名消失。若以后同一实际构造得到

B_(T,slow)≤κQ_g+BW，

则(12)给 E_H≤G√κ Q_g+G√(BQ_gW)+CSGζW；是否足以吸收要与完整母账中该 H 的 score 份额、其余已覆盖场的费用共同核算，不能独取最有利构造拼接。当前没有证明足够小的 κ 或多对数 B。

因此已改变的真实付款是 α 自适应快速捕获部分；慢支仍需对同格重复或实际首达软平方作进一步几何估计。R516 的空间边界、低 α 的 CSW、原窗口/历史及全部旧入口费用继续保留，本稿未宣称根阶闭合。

## 7. 本机精确核验

实际用 Fraction 核验 α/K_B≤1/A_n、真实密度换算、同一首壳收据及软平方 Cauchy。另用真实一维 μ=1_[−4,4]dy：中心区间 [−1,0] 的旧半径 1，[0,1] 的旧半径 4/3，所有父的真实首达倍率为 1+u=4/3，γ=(4/3)^4，因此新窗统一平移 1/4。按中心交集长度准确积分来源 piecewise 线性列，检验单位平移保范数、旧盒＋新壳恒等式及(8)/(11)。输出：`PASS 95 exact adaptive-capture and real-source aligned-window square checks`。

```python
from fractions import Fraction as F
count=0
u=F(1,3);G=F(4,3)
for An in (F(1),F(4),F(16),F(64)):
 for alpha in (F(1,128),F(1,8),F(1,2),F(1)):
  K=max(1+u,An*alpha)
  assert alpha/K<=1/An;count+=1
  for g in (F(1),F(7,6),G):
   qold=F(3,2);qnew=K*qold/g
   assert alpha*qold<=G*qnew/An;count+=1
  C=F(5,2);t=F(2,3);qold=F(3,2)
  E=C*alpha*t*qold;receipt=u*alpha*t*qold
  assert receipt==u*E/C;count+=1
blocks=[(F(-1),F(0),F(1),F(0)),(F(0),F(1),F(4,3),F(1,4))]
xs={F(-4),F(4)}
for l,r,R,s in blocks:
 for radius in (R,G*R):xs.update((l-radius/2,l+radius/2,r-radius/2,r+radius/2))
xs=sorted(xs)
def vec(which,expanded=False,weighted=False,shifted_back=False):
 out=[]
 for j in which:
  l,r,R,s=blocks[j];radius=G*R if expanded else R
  denom=R if weighted else radius
  vals=[max(F(0),min(r,y+radius/2)-max(l,y-radius/2))/denom for y in xs]
  start=s+(F(1,4) if expanded and not shifted_back else 0)
  out.append((start,vals))
 return out
def inner(A,B):
 out=F(0)
 for s,a in A:
  for t,b in B:
   w=max(F(0),1-abs(s-t))
   out+=w*sum((xs[k+1]-xs[k])*(2*a[k]*b[k]+a[k]*b[k+1]+a[k+1]*b[k]+2*a[k+1]*b[k+1])/6 for k in range(len(xs)-1))
 return out
L=vec((0,1));Q=inner(L,L)
for subset in ((0,),(1,),(0,1)):
 LH=vec(subset);A=vec(subset,True);back=vec(subset,True,False,True)
 weighted=vec(subset,True,True,True)
 assert inner(A,A)==inner(back,back);count+=1
 J=[(s,[v-o for v,o in zip(vals,LH[k][1])]) for k,(s,vals) in enumerate(weighted)]
 assert all(v>=0 for s,vals in J for v in vals);count+=1
 assert inner(weighted,weighted)==inner(LH,LH)+2*inner(LH,J)+inner(J,J);count+=1
 E=inner(L,LH);BA=inner(A,A)
 assert E*E<=G*G*Q*BA;count+=1
 assert inner(weighted,weighted)<=G*G*BA;count+=1
print('PASS',count,'exact adaptive-capture and real-source aligned-window square checks')
```
