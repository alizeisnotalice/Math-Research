"""R836 linear source-rank diagnostics on the exact R835 candidate partition."""

import argparse
from collections import defaultdict
from decimal import Context, Decimal, ROUND_CEILING, ROUND_FLOOR
from fractions import Fraction as F
from functools import cache
from hashlib import sha256
from itertools import product
from math import isqrt, prod
from pathlib import Path
from platform import python_version
from zipfile import ZipFile


ROUNDS = Path(
    "/Volumes/data/CodexProjects/T/Math-Research-cube-sqrt-20261114/"
    "centered-cube-upper-bound/rounds"
)
PINS = {
    814: "891d8cbcbd35537e6abc18c938e53b1b4f300327357c24c8d14a51a46ad5e190",
    832: "3eef2e83aab159531aa5b1049715568779e8c599998dde494ce0ea0e238c0303",
    833: "8c37039dba896615b13e4de9c1bfe2a56ee8f539e192c11386285237f2537b17",
    834: "15b8e65b789dbe30cd08ce0b376ae93fd19fa2341b895d15c50a2ed9cee284e8",
    835: "b9d5caf5ecc41d12ec739e513e65d285e07da3109f0601c5f890335cd45a51c3",
}
FLOOR = Context(prec=14, rounding=ROUND_FLOOR)
CEIL = Context(prec=14, rounding=ROUND_CEILING)
WIDE = (F(1), F(5, 4), F(2))
GATES = ("co-parent", *WIDE)
FRACTIONS = (F(1, 4), F(1, 2), F(3, 4))
ZERO = F(0)


def show(lo, hi):
    assert 0 <= lo <= hi
    return [str(c.divide(Decimal(v.numerator), Decimal(v.denominator)))
            for c, v in zip((FLOOR, CEIL), (lo, hi), strict=True)]


def load(path, member):
    with ZipFile(path) as archive:
        code = archive.read(member)
    print("MEMBER SHA256", member, sha256(code).hexdigest())
    env = {"__name__": "archived_" + member.removesuffix(".py")}
    exec(compile(code, member, "exec"), env)
    return env


def partition_outer(rows, atoms, mu, bits, degree_bin, rho, kernel, groups):
    """Aggregate after retaining the threshold parent i and its old D."""
    outside = defaultdict(lambda: defaultdict(F))
    inside = defaultdict(lambda: defaultdict(F))
    for g, keys in groups.items():
        mass = sum(rows[k] for k in keys)
        anchors, tests = defaultdict(F), defaultdict(F)
        for t, x, _ in keys:
            weight = rows[t, x, g]
            anchors[t] += weight
            tests[t, x[1]] += weight
        support = {z for _, z in tests}
        for j, aj in anchors.items():
            for (i, z), ti in tests.items():
                if z & bits[j]:
                    continue
                d = degree_bin[i]
                # The original two samplings share the full right arm;
                # both assignments of its two indices have the same law.
                weight = 2 * aj * ti / (mass * rho[j] * F(2)**d * mu[g[1]])
                for y in support:
                    if y & bits[j]:
                        continue
                    key = y, g[1], d
                    outside[key][i] += weight
                    for (_, idx), prob in kernel.get((j, z, y), {}).items():
                        inside[key][idx, i] += weight * prob
    result = {}
    for key, parents in outside.items():
        y, _, _ = key
        bounds = inside[key]
        result[key] = tuple(tuple((i, bounds.get((a, i), ZERO), u) for i, u in sorted(parents.items()))
                            for a in range(len(atoms[y])))
    assert result.keys() == outside.keys()
    assert all(0 <= lo <= hi for v in result.values() for atom in v for _, lo, hi in atom)
    return result


def coarse_q(atoms):
    """Coarsen only the one-sided totals. Match with all 992 fine atoms."""
    coarse = {}
    for mask, cells in atoms.items():
        assert len(cells) % 16 == 0
        groups = []
        for start in range(0, len(cells), 16):
            batch = cells[start:start+16]
            axes = [set(box[i] for box, _ in batch) for i in range(4)]
            assert all(len(a) == 2 for a in axes) and len({box for box, _ in batch}) == 16
            for a in axes:
                left, right = sorted(a)
                assert left[1] == right[0]
            bound = tuple((min(lo for lo, _ in a), max(hi for _, hi in a)) for a in axes)
            groups.append((bound, sum(w for _, w in batch)))
        coarse[mask] = tuple(groups)
    return coarse


@cache
def intersection_scale(d):
    # The R813/R835 parent convention, with n=4 and the real fourth root.
    nbits = 56
    unit = 1 << nbits
    power = F(2)**(d + 1)
    k = isqrt(isqrt((power.numerator << (4*nbits)) // power.denominator))
    lo = F(k, unit)
    hi = lo if lo**4 == power else lo + F(1, unit)
    assert lo**4 <= power <= hi**4
    return lo * F(129, 128), hi * F(129, 128)


def overlap(left, right, scale):
    alo, ahi = scale
    lower, upper = F(1), F(1)
    for (l, h), (a, b) in zip(left, right, strict=True):
        d0, d1 = max(ZERO, a-h, l-b), max(abs(l-b), abs(h-a))
        if lower:
            lower *= max(ZERO, 1-d1/alo)
        if upper:
            upper *= max(ZERO, 1-d0/ahi)
    assert 0 <= lower <= upper <= 1
    return lower, upper


@cache
def inflation(box, cube):
    low, high = F(1), F(1)
    for (a, b), (c, d) in zip(box, cube, strict=True):
        center = (c+d)/2
        radius = (d-c)/2
        low = max(low, max(a-center, center-b, ZERO)/radius)
        high = max(high, max(abs(a-center), abs(b-center))/radius)
    assert 1 <= low <= high
    return low**4, high**4


def combine_weights(parents, tests):
    """By gate: certified inside/outside coefficients and their upper caps."""
    lo_all = sum(lo for _, lo, _ in parents)
    hi_all = sum(hi for _, _, hi in parents)
    weighted = []
    for decision in tests:
        lo_in, hi_in, lo_out, hi_out = ZERO, ZERO, ZERO, ZERO
        for ((_, lo, hi), flag) in zip(parents, decision, strict=True):
            if flag is True:
                lo_in += lo
                hi_in += hi
            elif flag is False:
                lo_out += lo
                hi_out += hi
            else:
                hi_in += hi
                hi_out += hi
        weighted.append((lo_in, hi_in, lo_out, hi_out))
    return (lo_all, hi_all), weighted


def weighted_gates(y, geometry, parents, bits, plow, phigh):
    tests = [tuple(bool(y & bits[i]) for i, _, _ in parents)]
    for cap in WIDE:
        if cap == plow == phigh == 1:
            # At theta=0, g_i=1 is exactly true cube membership a.e.
            tests.append(tests[0])
            continue
        tests.append(tuple(True if gh*phigh <= cap else False if gl*plow > cap else None
                           for gl, gh in geometry))
    return combine_weights(parents, tests)


def share(weights):
    li, ui, lo, uo = weights
    return (li/(li+uo) if li else ZERO, ui/(ui+lo) if ui else ZERO)


def actual_original(rows, d_bin, mu):
    out = defaultdict(F)
    for (t, (_, z), (_, q)), w in rows.items():
        out[z, q, d_bin[t]] += w / (mu[z]*mu[q])
    assert all(out[q, z, d] == w for (z, q, d), w in out.items())
    return out


def gates_for_point(theta, scale, y, y_box, q_box, parents, bits, cubes):
    p = (F(1), F(1)) if theta == 0 else overlap(y_box, q_box, scale)
    geometry = tuple(inflation(y_box, cubes[i]) for i, _, _ in parents)
    total, gates = weighted_gates(y, geometry, parents, bits, *p)
    return p, total, gates


def one_side(theta, fields, atoms, q_coarse, bits, cubes, raw):
    total, summary = [ZERO, ZERO], [[ZERO]*4 for _ in GATES]
    visited = 0
    for (y, q, d), table in sorted(fields.items()):
        scale = intersection_scale(d)
        for (ybox, yw), parents in zip(atoms[y], table, strict=True):
            for qbox, qw in q_coarse[q]:
                visited += 1
                (pl, pu), (al, au), gates = gates_for_point(theta, scale, y, ybox, qbox,
                                                         parents, bits, cubes)
                lm, um = pl*yw*qw, pu*yw*qw
                total[0] += lm*al
                total[1] += um*au
                for acc, (li, ui, lo, uo) in zip(summary, gates, strict=True):
                    acc[0] += lm*li
                    acc[1] += um*ui
                    acc[2] += lm*lo
                    acc[3] += um*uo
    print("ONE SIDE theta", theta, "coarse-q by fine-y pieces", visited,
          "total tilted load / original mass", show(*(x/raw for x in total)))
    for g, weights in zip(GATES, summary, strict=True):
        denominator = (weights[0]+weights[3], weights[1]+weights[2])
        assert min(denominator) > 0
        print("  CANDIDATE GATE", g, "share of this tilted load", show(*share(weights)),
              "tilted load in gate / original mass", show(weights[0]/raw, weights[1]/raw))
    if theta == 0:
        assert summary[0] == summary[1]


def matched(theta, fields, atoms, bits, cubes, original, raw):
    # Work on genuine physical microcell pairs, with both directions summed
    # over all compatible full observation groups at the same absolute D.
    original_positive = [ZERO, ZERO]
    all_min = [ZERO, ZERO]
    candidate_min = [[ZERO, ZERO] for _ in GATES]
    admitted = {g: [[ZERO, ZERO] for _ in FRACTIONS] for g in GATES}
    paid_cost = {g: [[ZERO, ZERO] for _ in FRACTIONS] for g in GATES}
    matched_labels = {key for key in fields if (key[1], key[0], key[2]) in fields}
    assert matched_labels == {(35, 77, 7), (77, 35, 7)}
    visited = 0
    for y, q, d in sorted(matched_labels):
        if y >= q:
            continue
        j = original[y, q, d]
        forward, reverse = fields[y, q, d], fields[q, y, d]
        scale = intersection_scale(d)
        for ((ybox, yw), f), ((qbox, qw), r) in product(zip(atoms[y], forward, strict=True),
                                                      zip(atoms[q], reverse, strict=True)):
            visited += 2
            pf, (fl, fu), fg = gates_for_point(theta, scale, y, ybox, qbox, f, bits, cubes)
            pr, (rl, ru), rg = gates_for_point(theta, scale, q, qbox, ybox, r, bits, cubes)
            assert pf == pr
            pl, pu = pf
            cell = 2*yw*qw
            original_cell = cell*j
            both_low, both_upper = min(fl, rl)*pl, min(fu, ru)*pu
            all_min[0] += cell*both_low
            all_min[1] += cell*both_upper
            if both_low > 0:
                original_positive[0] += original_cell
            if both_upper > 0:
                original_positive[1] += original_cell
            for ix, g in enumerate(GATES):
                a, b = fg[ix], rg[ix]
                min_lo, min_hi = min(a[0], b[0])*pl, min(a[1], b[1])*pu
                candidate_min[ix][0] += cell*min_lo
                candidate_min[ix][1] += cell*min_hi
                lh, uh = share(a)
                rh, vh = share(b)
                for idx, delta in enumerate(FRACTIONS):
                    if both_low > 0 and max(lh, rh) >= delta:
                        admitted[g][idx][0] += original_cell
                        paid_cost[g][idx][0] += cell*both_low
                    if both_upper > 0 and max(uh, vh) >= delta:
                        admitted[g][idx][1] += original_cell
                        paid_cost[g][idx][1] += cell*both_upper

    print("MATCHED theta", theta, "fine ordered microcell pairs", visited,
          "matched labels", sorted(matched_labels), "original fraction on positive support",
          show(*(x/raw for x in original_positive)), "all tilted min / original mass",
          show(*(x/raw for x in all_min)))
    for ix, g in enumerate(GATES):
        assert 0 <= candidate_min[ix][0] <= candidate_min[ix][1] <= all_min[1]
        print("  GATE", g, "min of the two candidate-in tilted fields / original mass",
              show(*(x/raw for x in candidate_min[ix])))
        for delta, mass, fee in zip(FRACTIONS, admitted[g], paid_cost[g], strict=True):
            assert 0 <= mass[0] <= mass[1] <= original_positive[1] <= raw
            print("   MAX SIDE GATE SHARE >=", str(delta),
                  "projected original fraction", show(*(x/raw for x in mass)),
                  "matching all-pool min load on certified event / original mass",
                  show(*(x/raw for x in fee)))
    if theta == 0:
        assert admitted["co-parent"] == admitted[F(1)]


def fixture(name, stage, src, traffic, row):
    rows, cubes, _, m, j, bits, mu = src["reconstruct"](stage)
    assert stage["dimension"] == 4 and rows == traffic["transpose"](rows)
    raw = sum(rows.values())
    degree_bin = {t: traffic["bin_volume"](m[t]) for t in stage["middle_labels"]}
    rho = {t: sum(w for e, w in rows.items() if e[0] == t)/j[t] for t in degree_bin}
    assert min(rho.values()) > 0
    assert 0 < max(F(stage["degrees"][t]["full_d"]) for t in degree_bin) < 1
    active = {arm[1] for _, x, g in rows for arm in (x, g)}
    atoms = src["source_atoms"](cubes, stage["density"], mu, active, row["axis_intervals"])
    assert sum(map(len, atoms.values())) == 992
    groups = src["grouped_flow"](rows)
    certificate = src["source_kernel"](cubes, bits, atoms, mu, groups)
    fields = partition_outer(rows, atoms, mu, bits, degree_bin, rho, certificate, groups)
    original = actual_original(rows, degree_bin, mu)
    shared = {(y, q, d): {i for atom in v for i, _, hi in atom if hi}
              for (y, q, d), v in fields.items() if (q, y, d) in fields}
    assert shared == {(35, 77, 7): {"t0"}, (77, 35, 7): {"t0"}}
    assert all(y & bits["t0"] and q & bits["t0"] for y, q, _ in shared)
    assert intersection_scale(7)[0] > max(b-a for a, b in cubes["t0"])
    print("STRUCTURAL BOTH-DIRECTION SUPPORT", sorted(shared),
          "threshold parent t0 contains both physical prices, P_D strictly positive")
    q_coarse = coarse_q(atoms)
    assert all(sum(w for _, w in q_coarse[q]) == mu[q] for q in q_coarse)
    print("FIXTURE", name, "raw original mass", show(raw, raw),
          "rows", len(rows), "full right groups", len(groups), "fine source cells", 992,
          "geometric blocks", len(fields), "R813 high-degree gate empty")
    for theta in (0, 1):
        one_side(theta, fields, atoms, q_coarse, bits, cubes, raw)
        matched(theta, fields, atoms, bits, cubes, original, raw)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for n in PINS:
        parser.add_argument(f"--archive-{n}", type=Path,
                            default=ROUNDS / str(n) / "research.zip")
    args = parser.parse_args()
    paths = {n: getattr(args, f"archive_{n}") for n in PINS}
    print("PYTHON", python_version(), "exact rational candidate and tilt enclosures;"
          " theta=1 is a numerical endpoint only")
    for n, expected in PINS.items():
        digest = sha256(paths[n].read_bytes()).hexdigest()
        assert digest == expected
        print("ARCHIVE SHA256", n, digest)
    src = load(paths[834], "potential834.py")
    traffic = load(paths[835], "traffic835.py")
    stages, row = src["load_inputs"](paths[814], paths[833])
    for name, stage in stages:
        fixture(name, stage, src, traffic, row)
    print("PASS linear source-rank loads with exact original-history weights")


if __name__ == "__main__":
    main()

