"""R836 exact threshold bounds for endpoint-local menus on all R814 source cells.

Both original price histories, masses, signed arms and physical receiver
laws are unchanged. Rectangles partition the actual positive continuous
source cells. Limits of interval refinement are recorded as mass intervals.
"""

import argparse
from collections import defaultdict
from fractions import Fraction as F
from functools import cache
from hashlib import sha256
from itertools import product
from math import isqrt, prod
from pathlib import Path
from zipfile import ZipFile


ROUNDS = Path("/Volumes/data/CodexProjects/T/Math-Research-cube-sqrt-20261114/"
              "centered-cube-upper-bound/rounds")
PINS = {
    814: "891d8cbcbd35537e6abc18c938e53b1b4f300327357c24c8d14a51a46ad5e190",
    833: "8c37039dba896615b13e4de9c1bfe2a56ee8f539e192c11386285237f2537b17",
    834: "15b8e65b789dbe30cd08ce0b376ae93fd19fa2341b895d15c50a2ed9cee284e8",
    835: "b9d5caf5ecc41d12ec739e513e65d285e07da3109f0601c5f890335cd45a51c3",
}
THRESHOLDS = (F(1), F(1,2))
POLICIES = ("one-best-mask", "one-merged-box", "all-mask-uniform",
            "all-mask-posterior", "overlapping-merged-plus-mask")


def archived_module(path, member):
    with ZipFile(path) as archive:
        namespace = {"__name__": f"archived_{member.removesuffix('.py')}"}
        exec(compile(archive.read(member), member, "exec"), namespace)
    return namespace


def hull(boxes):
    return tuple((min(a for a,_ in pairs),max(b for _,b in pairs))
                 for pairs in zip(*boxes,strict=True))


def coarse_partition(atoms, mu):
    coarse = {}
    for z, rectangles in atoms.items():
        assert len(rectangles) % 16 == 0
        cells = []
        for i in range(0,len(rectangles),16):
            pieces = tuple(rectangles[i:i+16])
            box = hull([b for b,_ in pieces])
            # Recovery of the Cartesian product of true coordinate half-pieces.
            for coordinate, (a,b) in enumerate(box):
                split = (a+b)/2
                assert {p[coordinate] for p,_ in pieces} == {(a,split),(split,b)}
            assert len({p for p,_ in pieces}) == 16
            cells.append((box,pieces))
        assert sum(w for _,pieces in cells for _,w in pieces) == mu[z]
        coarse[z] = tuple(cells)
    return coarse


def absolute_bin(m):
    d = m.numerator.bit_length() - m.denominator.bit_length()
    d -= (m < F(2)**d)
    assert F(2)**d <= m < F(2)**(d+1)
    return d


@cache
def arrival_scale(d):
    bits = 72
    den = 1 << bits
    v = F(2)**(d+1)
    a = isqrt(isqrt((v.numerator << (4*bits)) // v.denominator))
    lo = F(a,den)
    hi = lo if lo**4 == v else lo+F(1,den)
    assert lo**4 <= v <= hi**4
    return F(129,128)*lo, F(129,128)*hi


@cache
def phi_interval(d, z, q):
    lo_scale,hi_scale = arrival_scale(d)
    distances = tuple((max(F(0),a-y,x-b),max(abs(a-y),abs(b-x)))
                      for (a,b),(x,y) in zip(z,q,strict=True))
    lo = prod(max(F(0),1-w/lo_scale) for _,w in distances)
    hi = prod(max(F(0),1-w/hi_scale) for w,_ in distances)
    assert 0 < lo <= hi <= 1
    return lo,hi


@cache
def inverse_volume(d, box):
    lo,hi = arrival_scale(d)
    # Translating K=B-z does not change the arrival volume.
    return (1/prod(1+(b-a)/lo for a,b in box),
            1/prod(1+(b-a)/hi for a,b in box))


def schedules(rows, bins, atoms):
    totals, scale, mass = defaultdict(F), defaultdict(F), defaultdict(lambda: defaultdict(F))
    for (t,x,g), weight in rows.items():
        d,z = bins[t],g[1]
        totals[x] += weight
        scale[x,d] += weight
        mass[x,d][z] += weight
    qbox = {z:hull([box for box,_ in cells]) for z,cells in atoms.items()}
    merged, winner, posterior, conditional = {}, {}, {}, {}
    for (x,d), by_q in mass.items():
        merged[x,d] = hull([qbox[z] for z in by_q])
        # Rank candidate single masks by the local expected one-column
        # 1/sqrt(U) proxy. Squaring removes the radical. No test row's q
        # or actual central bin is read by the forecasting rule.
        winner[x,d] = max(sorted(by_q),key=lambda z: by_q[z]**2*inverse_volume(d,qbox[z])[0])
        posterior[x,d] = scale[x,d]/totals[x]
        conditional[x,d] = {z:w/scale[x,d] for z,w in by_q.items()}
        assert sum(conditional[x,d].values()) == 1
    for x in totals:
        assert sum(w for (a,_),w in posterior.items() if a == x) == 1
        assert sum(posterior[x,d]*sum(conditional[x,d].values())
                   for a,d in conditional if a == x) == 1
    return qbox,merged,winner,posterior,conditional


def prices_for_row(left, right, d, schedules):
    qbox,merged,winner,posterior,conditional = schedules
    q = right[1]
    assert q in conditional[left,d]
    # The right arm allocates only to its own observed physical source-mask
    # label and, for the overlap menu, to the single global merged label.
    local = inverse_volume(d,qbox[q])
    broad = inverse_volume(d,merged[left,d])
    d_budget = posterior[left,d]*posterior[right,d]
    q_budget = conditional[left,d][q]

    def term(weight, inverse):
        return tuple(weight*b for b in inverse)

    return (
        (term(d_budget, local),) if q==winner[left,d] else (),
        (term(d_budget,broad),),
        (term(F(1,4*len(conditional[left,d])),local),),
        (term(d_budget*q_budget,local),),
        (term(d_budget/4,broad), term(d_budget*q_budget/4,local)),
    ), merged[left,d] != qbox[q]


def passes(terms, threshold_square):
    # For the two-price menu, compare (sqrt(a)+sqrt(b))^2 with T.
    assert len(terms) <= 2
    if not terms:
        return False
    residual = threshold_square-sum(terms)
    if residual <= 0:
        return True
    return len(terms)==2 and 4*terms[0]*terms[1] >= residual**2


def verdict(prices, interval, threshold, distinct):
    plo,phi = interval
    cuts = threshold**2
    lower = tuple(passes(tuple(a for a,_ in p),cuts*phi) for p in prices)
    upper = tuple(passes(tuple(b for _,b in p),cuts*plo) for p in prices)
    assert all(a <= b for a,b in zip(lower,upper,strict=True))
    # Can the planned overlapping menu pay when even its largest single
    # contribution cannot? Also compare with the stronger of the two
    # precommitted one-forecast benchmark policies (not a per-row menu).
    max_lo = max(a for a,_ in prices[-1])
    max_hi = max(b for _,b in prices[-1])
    overlap = (distinct and lower[-1] and max_hi < cuts*plo,
               distinct and upper[-1] and max_lo < cuts*phi)
    new = (lower[-1] and not (upper[0] or upper[1]),
           upper[-1] and not (lower[0] or lower[1]))
    all_new = (lower[3] and not (upper[0] or upper[1]),
               upper[3] and not (lower[0] or lower[1]))
    return tuple(zip(lower,upper,strict=True))+(overlap,new,all_new)


@cache
def split_piece(piece, axis):
    box,atoms = piece
    a,b = box[axis]
    mid = (a+b)/2
    below = tuple((r,w) for r,w in atoms if r[axis][1] <= mid)
    above = tuple((r,w) for r,w in atoms if r[axis][0] >= mid)
    assert below and above and len(below)+len(above)==len(atoms)
    return tuple((hull([r for r,_ in items]),items) for items in (below,above))


def split_axis(left, right):
    # Only split axes at which the archived half-piece actually separates.
    candidates = []
    for side,(box,atoms) in enumerate((left,right)):
        for k,(l,h) in enumerate(box):
            if len({r[k] for r,_ in atoms}) == 2:
                candidates.append((h-l,side,k))
    return max(candidates,default=None)


def rectangle_results(left, right, prices, d, distinct, depth):
    interval = phi_interval(d,left[0],right[0])
    decisions = tuple(verdict(prices,interval,x,distinct) for x in THRESHOLDS)
    uncertain = any(lo!=hi for region in decisions for lo,hi in region)
    if depth and uncertain:
        axis = split_axis(left,right)
        if axis is not None:
            _,side,k = axis
            if side == 0:
                for child in split_piece(left,k):
                    yield from rectangle_results(child,right,prices,d,distinct,depth-1)
            else:
                for child in split_piece(right,k):
                    yield from rectangle_results(left,child,prices,d,distinct,depth-1)
            return
    yield sum(w for _,w in left[1])*sum(w for _,w in right[1]), decisions


def run_fixture(name, stage, archive, row_tools, depth):
    rows,cubes,_,m,_,_,mu = archive["reconstruct"](stage)
    bins = {t:absolute_bin(m[t]) for t in stage["middle_labels"]}
    assert set(bins.values()) == {6,7}
    assert rows == {(t,g,x):w for (t,x,g),w in rows.items()}
    masks = {arm[1] for _,x,g in rows for arm in (x,g)}
    atoms = archive["source_atoms"](cubes,stage["density"],mu,masks,row_tools["axis_intervals"])
    coarse = coarse_partition(atoms,mu)
    menu = schedules(rows,bins,atoms)
    total = sum(rows.values())
    num = len(POLICIES)+3
    accum = [[[F(0),F(0)] for _ in range(num)] for _ in THRESHOLDS]
    source_coverage = [F(0)]*len(POLICIES)
    blocks = 0
    # Grouping preserves both summed receiver factors and each original row;
    # thresholds depend solely on the same physical pair and own-arm labels.
    for (t,left,right), weight in rows.items():
        z,q = left[1],right[1]
        coefficient = weight/(mu[z]*mu[q])
        prices,distinct = prices_for_row(left,right,bins[t],menu)
        for i,p in enumerate(prices):
            if p:
                source_coverage[i] += weight
        covered = F(0)
        for z_piece,q_piece in product(coarse[z],coarse[q]):
            for rectangle_mass, results in rectangle_results(z_piece,q_piece,prices,bins[t],
                                                              distinct,depth):
                blocks += 1
                mass = coefficient*rectangle_mass
                covered += mass
                for th,region in enumerate(results):
                    for i,(lo,hi) in enumerate(region):
                        if lo:
                            accum[th][i][0] += mass
                        if hi:
                            accum[th][i][1] += mass
        assert covered == weight
    assert source_coverage[0] < total and all(w==total for w in source_coverage[1:])
    interval_text = row_tools["interval_text"]
    print("MARKETS",name,"rows",len(rows),"source positive coarse/fine cells",
          sum(map(len,coarse.values())),sum(map(len,atoms.values())),"tested rectangles",blocks,
          "depth",depth,"history high-dimensional gate empty")
    print("  original row geometry covered 1; prediction support by policy",
          dict(zip(POLICIES,(format(float(w/total),".12g") for w in source_coverage),strict=True)))
    extra = ("overlap sum pays but every component fails",
             "overlap newly pays beyond both fixed single benchmarks",
             "all-mask posterior newly pays beyond both fixed single benchmarks")
    for threshold,results in zip(THRESHOLDS,accum,strict=True):
        print(" threshold",threshold)
        for label,(lo,hi) in zip(POLICIES+extra,results,strict=True):
            assert 0 <= lo <= hi <= total
            print(" ",label,"mother fraction",interval_text((lo/total,hi/total),13),
                  "absolute original mass",interval_text((lo,hi),38))
    return accum


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for number in PINS:
        parser.add_argument(f"--archive-{number}",type=Path,default=ROUNDS/str(number)/"research.zip")
    parser.add_argument("--depth",type=int,choices=range(5),default=2,
                        help="Adaptive halvings using verified continuous source subcells")
    args = parser.parse_args()
    paths = {n:getattr(args,f"archive_{n}") for n in PINS}
    for n,path in paths.items():
        assert sha256(path.read_bytes()).hexdigest() == PINS[n]
    with ZipFile(paths[835]) as prior:
        assert b"traffic_extra_checks" in prior.read("traffic835.py")
    archive = archived_module(paths[834],"potential834.py")
    fixtures,row_tools = archive["load_inputs"](paths[814],paths[833])
    for name,stage in fixtures:
        run_fixture(name,stage,archive,row_tools,args.depth)
    print("PASS continuous original rows, local budgets, and exact score inequalities")


if __name__ == "__main__":
    main()
