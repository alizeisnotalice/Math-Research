"""Exact-width true last-root tests for repeated physical source forecasts.

Replay: python3 -B multisource836.py
The input is uniform on the two displayed cubes, or a product of uniform
two-interval coordinates, with the specified masses. Decisions use exact
rationals and outward Decimal enclosures of exp, ln and square root.
"""

from decimal import Context, Decimal, ROUND_CEILING, ROUND_FLOOR, ROUND_HALF_EVEN
from fractions import Fraction as F
from functools import cache
from itertools import product
from math import comb


DOWN = Context(prec=58, rounding=ROUND_FLOOR)
UP = Context(prec=58, rounding=ROUND_CEILING)
NEAR = Context(prec=58, rounding=ROUND_HALF_EVEN)
DEPTHS = (0, 1, 2, 4, 8, 16)


def unary(interval, name):
    operation = getattr(NEAR, name)
    result = []
    for value, ctx, step in zip(interval, (DOWN, UP), (DOWN.next_minus, UP.next_plus), strict=True):
        arg = ctx.divide(Decimal(value.numerator), Decimal(value.denominator))
        result.append(F(step(operation(arg))))
    return tuple(result)


def show(interval):
    texts = []
    for bound, rounding in zip(interval, (ROUND_FLOOR, ROUND_CEILING), strict=True):
        ctx = Context(prec=11, rounding=rounding)
        x = ctx.divide(Decimal(bound.numerator), Decimal(bound.denominator))
        texts.append(format(x.normalize(ctx), "E"))
    return "[" + ", ".join(texts) + "]"


def mix(a, b, p):
    assert 0 <= p <= 1
    return tuple(p*x + (1-p)*y for x, y in zip(a, b, strict=True))


def power(a, k):
    return tuple(x**k for x in a)


def times(a, b):
    return tuple(x*y for x, y in zip(a, b, strict=True))


def gate(n, score):
    # Every point of this subcell passes, every point fails, or unresolved.
    lo, hi = score
    assert 0 <= lo <= hi
    if n*lo**2 >= 1:
        return "+"
    if n*hi**2 < 1:
        return "-"
    return "?"


@cache
def source_geometry(n):
    assert 4 <= n <= 256
    center, source_half, receiving_half = F(7, 16), F(1, 128), F(1, 64)
    assert center + source_half + receiving_half == F(59, 128) < F(1, 2)
    # Full mass 1 is inside every receiver-core cube already at side 59/64.
    # Hence the root v=t^n=1 on the core, and total mass caps every side>1.
    # Likewise the interior of the full unit-root cube has a strict cap
    # margin before side 1. Outside its closure, Q_1 misses positive mass.
    root_one_half = F(1, 2) - center - source_half
    assert root_one_half == F(7, 128) > receiving_half
    assert (2*receiving_half)/(2*root_one_half) == F(2, 7)
    # Source-local cubes of centers have a smaller positive root. A side
    # 1/16 cube captures one tile of either model while the unit cube
    # misses all other tiles. The single product tile mass is 2^-n.
    source_local_test_side = F(1, 16)
    assert 2*source_half < source_local_test_side/2
    assert F(1, 2)**n > source_local_test_side**n
    assert F(1, 16) > source_local_test_side**n
    assert 2*center-2*source_half > F(1, 2)
    same_gap, different_min, different_max = 2*source_half, 2*(center-source_half), 2*(center+source_half)
    assert (same_gap, different_min, different_max) == (F(1, 64), F(55, 64), F(57, 64))
    log2 = unary((F(2), F(2)), "ln")
    decay = unary((-log2[1]/n, -log2[0]/n), "exp")
    assert 0 < decay[0] <= decay[1] < 1
    # D=1, a=2^(1/n); universal physical K=[-a,a]^n gives U=3^n.
    # The support of all real displacements is within K.
    same_p = 1 - decay[1]*same_gap, F(1)
    mixed_p = 1 - decay[1]*different_max, 1 - decay[0]*different_min
    assert 0 < mixed_p[0] <= mixed_p[1] < same_p[0] <= same_p[1]
    same = unary((F(1, 3)/same_p[1], F(1, 3)/same_p[0]), "sqrt")
    mixed = unary((F(1, 3)/mixed_p[1], F(1, 3)/mixed_p[0]), "sqrt")
    assert 0 < same[0] <= same[1] < mixed[0] <= mixed[1] < 2
    print("TRUE ROOT GEOMETRY", n, "D=v=t=1", "a^-1", show(decay), "U", f"3^{n}",
          "receiver-core volume", f"(1/32)^{n}", "full t=1 strata a.e. volume", f"(7/64)^{n}",
          "core fraction of t=1 stratum", f"(2/7)^{n}",
          "smaller positive roots exist on source-local boxes",
          "positive source intervals [55/128,57/128] and mirror",
          "one-axis P_k same tile", show(same_p), "mixed tiles", show(mixed_p))
    return same_p, mixed_p, same, mixed


def coherent_sources(n):
    _, _, factors_same, factors_mixed = source_geometry(n)
    same, different = power(factors_same, n), power(factors_mixed, n)
    assert gate(n, same) == "-"
    for p in (F(1, 2), F(3, 4), F(15, 16)):
        rows = []
        weights = p*p, (1-p)**2, 2*p*(1-p)
        assert sum(weights) == 1
        for m in (0, 1, 2, 4, 8):
            plus_pair = mix(same, different, p**m)
            minus_pair = mix(same, different, (1-p)**m)
            mean = mix(same, different, p**(m+2)+(1-p)**(m+2))
            by_class = plus_pair, minus_pair, different
            assert mean == tuple(sum(w*value[k] for w, value in zip(weights, by_class, strict=True))
                                 for k in range(2))
            labels = tuple(gate(n, score) for score in by_class)
            mass = (sum(w for w, label in zip(weights, labels, strict=True) if label == "+"),
                    sum(w for w, label in zip(weights, labels, strict=True) if label != "-"))
            rows.append((m, show(plus_pair), show(minus_pair), labels, tuple(map(str, mass)), show(mean)))
            if p == F(1, 2) and m == 1:
                assert labels == ("+", "+", "+")
            if p == F(15, 16) and n == 4 and m == 1:
                assert labels == ("-", "+", "+")
        print("COHERENT TWO SOURCES", n, "majority mass", p,
              "(m, score same-major, score same-minor, gates major/minor/cross, "
              "gate mass interval, mean original score)", rows)


def first_true(fn, n):
    lo, hi = -1, n+1
    while lo+1 < hi:
        mid = (lo+hi)//2
        if fn(mid):
            hi = mid
        else:
            lo = mid
    return hi


def product_gates(n, equal, different):
    both = [first_true(lambda j: n*(equal[k]**(n-j) * different[k]**j)**2 >= 1, n)
            for k in range(2)]
    certain, possible = both
    assert possible <= certain
    mass = tuple(F(sum(comb(n, j) for j in range(cut, n+1)), 2**n)
                 for cut in (certain, possible))
    return (certain, possible), mass



def independent_low_dim_sign_check():
    """Literal independent sign-vector tuples, with initially fixed true labels."""
    n = 4
    for m in (1, 2):
        share = F(1, 2**m)
        for opposite in range(n+1):
            initial = (1 << opposite) - 1
            counts = [0]*(n+1)
            for masks in product(range(1 << n), repeat=m):
                final = initial
                for mask in masks:
                    final |= mask
                counts[final.bit_count()] += 1
            denominator = 2**(n*m)
            assert sum(counts) == denominator
            law = [F(0)]*opposite + [
                comb(n-opposite, k) * (1-share)**k * share**(n-opposite-k)
                for k in range(n-opposite+1)
            ]
            assert tuple(F(count, denominator) for count in counts) == tuple(law)
    print("INDEPENDENT 4D ENUMERATION", "m=1,2", "10 fixed initial sign profiles",
          "all fresh sign-vector tuples match exact mixed-axis laws")


def product_sources(n):
    same_p, mixed_p, same, mixed = source_geometry(n)
    rows = []
    for m in DEPTHS:
        # Once fixed y and q share a sign on an axis, all new signs match
        # that axis with probability 2^-m. Independent coordinate laws let
        # the expectation of the product factorize at the fixed true pair.
        share = F(1, 2**m)
        conditional_axis = mix(same, mixed, share)
        cut, mass = product_gates(n, conditional_axis, mixed)
        mean = power(mix(same, mixed, share/2), n)
        all_equal_score = power(conditional_axis, n)
        all_equal_pk = power(mix(same_p, mixed_p, share), n)
        # Exact chance that every axis originally equal becomes mixed.
        all_mixed_probability = (1-share)**n
        assert 0 <= all_mixed_probability <= 1
        # Constant joint right density beta=1 with respect to mu_x^m and
        # lambda*D=1 has integral one, rather than m independent full budgets.
        joint_right_paid = F(1)**m
        assert joint_right_paid == 1
        rows.append((all_equal_score, mean, mass))
        print("UNIFORM PRODUCT", n, "m fresh", m, "all-equal original signs score", show(all_equal_score),
              "all-equal conditional E[P_(m+2)]", show(all_equal_pk),
              "all mixed chance given all original signs equal", show((all_mixed_probability,)*2),
              "mother mean score", show(mean),
              "certain/possible min number original opposite axes", cut,
              "whole-mother admitted fraction", show(mass),
              "normalized integrated joint-right weight", str(joint_right_paid))
        if m == 0:
            assert mass[1] < 1 and gate(n, all_equal_score) == "-"
        if m >= 4:
            assert mass == (1, 1) and gate(n, all_equal_score) == "+"
    # A simultaneous hierarchy has a single terminal budget. Splitting
    # both ends equally multiplies each depth's score by 1/len(DEPTHS);
    # it does not let us sum all the individually unit-budget scores.
    allocation = F(1, len(DEPTHS))
    assert sum(allocation for _ in DEPTHS) == 1
    hierarchy = tuple(sum(allocation * all_equal[k] for all_equal, _, _ in rows) for k in range(2))
    mean_hierarchy = tuple(sum(allocation * mean[k] for _, mean, _ in rows) for k in range(2))
    assert max(x[0][0] for x in rows) >= hierarchy[0] > rows[0][0][1]
    assert mean_hierarchy[1] * (F(7, 64)**n) < 1
    print("DEPTH HIERARCHY", n, "weights alpha=gamma", str(allocation), "depths", DEPTHS,
          "sum left and integrated right", (1, 1), "all-equal score", show(hierarchy),
          "mean score", show(mean_hierarchy), "gate on all-equal original signs", gate(n, hierarchy))


def dyadic_ceiling(x):
    """Smallest absolute dyadic at least x, for a strict positive mass."""
    assert x > 0
    exponent = x.numerator.bit_length() - x.denominator.bit_length()
    result = F(2)**exponent
    if result < x:
        result *= 2
    assert result/2 < x <= result
    return result


def empirical_learn_lower(n, draws):
    """Sufficient lower bound from all independent uniform rank ranges."""
    assert draws >= 2
    rank_span = 1 - F(1, 2*n)
    assert rank_span**n > F(1, 2)
    # P(max-min < r) for iid continuous U[0,1] is r^(m-1)[m-(m-1)r].
    failure_one_axis = rank_span**(draws-1) * (draws-(draws-1)*rank_span)
    assert 0 < failure_one_axis < 1
    return (1-failure_one_axis)**n


def empirical_scale_forecast():
    """Two positive-width, independently simulated source blocks on each band."""
    n = 4
    sides = F(1), F(1, 2), F(1, 4)
    centers = tuple(F(8*j) for j in range(len(sides)))  # first-axis shifts
    receiver_side = sides[-1]/32
    source_center, source_pad = F(7, 16), F(1, 128)
    volumes = tuple(b**n for b in sides)
    assert sum(volumes) < 2 < 2**n
    assert all(source_center + source_pad + receiver_side/(2*b) < F(1, 2) for b in sides)
    assert all(y-x == 8 for x,y in zip(centers, centers[1:]))
    assert 8-source_center-source_pad-receiver_side/2 > 1
    # For s<=2 each receiving core only sees its own band, and sees all
    # its D=b^n mass for s<b sufficiently close to b. At s>=2 the mass
    # cap rules out any return. This is a true root on each whole core.
    # Within a band the source is a symmetric product of uniform pairs
    # with strictly positive density on all 2^n boxes, scaled by its D.
    for d in volumes:
        assert dyadic_ceiling(d) == d
        assert dyadic_ceiling(F(7, 8)*d) == d
        assert dyadic_ceiling(d/2) == d/2
    _, mixed_p, _, _ = source_geometry(n)
    product_p = power(mixed_p, 2*n)
    scores = 1/mixed_p[1]**n, 1/mixed_p[0]**n
    assert scores[0]**2 * product_p[1] == scores[1]**2 * product_p[0] == 1
    assert scores[0] > 1  # Correct absolute label forces both signs in every axis.
    root_threshold = F(1, 2)
    assert n*root_threshold**2 == 1

    print("EMPIRICAL TWO-END TRUE SCALES", n, "roots", tuple(map(str, sides)),
          "absolute D", tuple(map(str, volumes)), "all future caps",
          "equal receiving-core and two-arm mother mass per scale", str(receiver_side**n),
          "bound P_L*P_R or nested P_L*P_all", show(product_p),
          "score per successful pair of simulated blocks", show(scores))
    for left_size, right_size in ((16, 256), (32, 512), (64, 2048)):
        k, ell = left_size-1, right_size-1
        prior_left = empirical_learn_lower(n, k)
        prior_right = empirical_learn_lower(n, ell)
        # The draw laws are independent, so this is uniform in both fixed
        # original anchors; they can only expand their respective boxes.
        both_learn_conditional_lower = prior_left * prior_right
        unconditional_lower = both_learn_conditional_lower * scores[0]
        assert unconditional_lower > root_threshold

        # The exact unconditional nesting probability uses all samples,
        # including the original y,q. Both combined extrema on each axis
        # must come from the right block; axes are genuinely independent.
        total = left_size + right_size
        nest = F(right_size*(right_size-1), total*(total-1))**n
        union_loss = F(2*n*left_size, total)
        assert 1-nest <= union_loss
        learned_left = empirical_learn_lower(n, left_size)
        learned_right = empirical_learn_lower(n, right_size)
        nested_learn_lower = max(F(0), nest-(1-learned_left)-(1-learned_right))
        assert nested_learn_lower <= nest
        nested_admitted_lower = max(
            F(0), (nested_learn_lower-root_threshold/scores[0])/(1-root_threshold/scores[0])
        )
        # Main no-inclusion forecast score integrates over the actual
        # three root cores under the unnormalized original mother.
        actual_mother = len(sides)*receiver_side**n
        no_gate_integral = actual_mother*unconditional_lower, actual_mother*scores[1]
        nested_integral = actual_mother*nested_learn_lower*scores[0], actual_mother*nest*scores[1]
        assert nested_integral[1] <= no_gate_integral[1]
        scale_inflation = []
        for j, d in enumerate(volumes):
            alpha, gamma = d**(-k), d**(-ell)  # On each matching forecast label.
            assert d**k*alpha == d**ell*gamma == d**(k+ell)*alpha*gamma == 1
            # Squared score inflation if BOTH true-scale factors are dropped.
            assert alpha*gamma == F(2)**(j*n*(k+ell))
            assert (j*n*(k+ell)) % 2 == 0
            scale_inflation.append(j*n*(k+ell)//2)
        if left_size == 64:
            assert both_learn_conditional_lower > F(99, 100)
            assert nested_learn_lower > F(3, 4)
        print("EMPIRICAL TWO-END DEPTH", (k, ell),
              "companion-only uniform learning lower", show((both_learn_conditional_lower,)*2),
              "exact original-mother nesting probability", show((nest,)*2),
              "nested joint success interval", show((nested_learn_lower, nest)),
              "nested admitted original-mother fraction lower", show((nested_admitted_lower,)*2),
              "no nesting conditional score lower at each true y,q",
              show((unconditional_lower,)*2), "all original core rows pass", True,
              "true unnormalized no-nesting integral interval", show(no_gate_integral),
              "true unnormalized nested integral interval", show(nested_integral),
              "wrong score multiplier if both mass factors omitted", tuple(f"2^{e}" for e in scale_inflation))
    print("EMPIRICAL BUDGET", "each anchor recognizes its own spatial cluster before sampling",
          "independent companions use that raw source restriction divided by D",
          "sample bbox mass >D/2 learns D by dyadic ceiling",
          "each of the two terminal sums of prior integrals is at most 1",
          "learned tag rates are bounds, not an exact continuous score integral")


def main():
    for n in (4, 8, 16):
        coherent_sources(n)
    independent_low_dim_sign_check()
    for n in (4, 16, 64, 256):
        product_sources(n)
    empirical_scale_forecast()
    print("PASS true last roots, positive source widths, physical multiway overlaps and joint budgets")
    print("SCOPE one-band scores extend to t=1 a.e.; three-band scores use only explicit receiver cores; no R813 qualification")


if __name__ == "__main__":
    main()
