# R431：可预测父质量门把反事实邻近风险接到来源预算

2026-10-20。本附件证明一个新的实际风险一阶矩来源预算，并由此支付原 R430 上的一项正分支。它不要求统一命中率，不重新支付实际邻近路径，也没有证明整个剩余量闭合。

## 1. 原对象、较小邻域与主命题

全部使用 R430 的同一完整 \(f\)、真实 Lebesgue 中心、实际匹配与原标签：
\[
m_v=f(Q_v)=q_vR_v^n,\quad q=q_-\le q_v\le\lambda,\quad
a\le R_v\le b\le2a,
\]
\[
\rho_x(dv)=1_{Q_v}(x)\frac{dv}{m_v},\quad
\pi_A(dx)=\frac{f(x)1_{Q_A}(x)}{m_A}dx,\quad
\sigma(dA)=q_A\,dA,\quad W=\int f.
\]
参数沿用
\[
\ell=\sqrt n,\quad K=e^\ell,\quad s=1+\ell,\quad
h=\frac{s}{\varepsilon _0q},\quad
M=\frac{J_*}{h},\quad J_*=\frac{1+n\log(b/a)}q,\quad
r=\lambda/q,\quad S=\beta+C_{\rm col}.
\]
\(\Pi430\) 是主稿 R430 最终正余流：保全部原阶段 \(i\)、首次删除、旧新来源、父与完整路径、soft/clipping 权，且保全部节点父远、原避开似然 \(\mathcal P>t\)、父质量尾 \(m_A>e^{\sqrt n}H_{\rm mass}\)。以下上界可以正删除最后这个质量尾，但不退款其已付窗口。

每条保源路径从原 active 初始节点 \(v_0\) 出发，proper transition 的目标代数记 \(j\ge1\)：
\[
P_x(v_{j-1},du)=
\frac{1_{\{m_u<m_{v_{j-1}}/K\}}\rho_x(du)}{Z_{v_{j-1}}(x)},
\qquad Z_{v_{j-1}}(x)>h.
\]
首次 \(Z\le h\) 停止，终端只计一次。路径代数 \(j\) 和原删除阶段 \(i\) 区分。

为使反事实下一跳也保有付款所需的父质量门，定义
\[
\bar\alpha_j^n=sK^{j+2},\qquad
\bar{\mathcal N}_j(A)=\{u\in E:A\in\bar\alpha_jQ_u\},
\]
\[
\bar p_j(A,x,v_{j-1})=
P_x(v_{j-1},\bar{\mathcal N}_j(A)).
\tag{1}
\]
因为 \(\kappa_j\ge K^{j+2}\)，有 \(\bar\alpha_j\le\alpha_j\)。所以 \(\Pi430\) 的实际两条路径从未命中这些较小邻域；但 (1) 是原**未过滤下一跳**的真实概率，可能为正。定义原票据上的量
\[
\mathcal C=
\sum_{x\in\{y,z\}}\sum_{j=1}^{T_x}
\bar p_j(A,x,v_{j-1}),
\tag{2}
\]
按两条有标签路径求和；来源恰相等时也不合并标签。

记已证代数函数
\[
\Theta(M)=\sum_{j\ge1}\min(1,M2^{-(j-1)}),
\]
\[
I_k(M)=\int_1^M\frac{du}{u}\min(1,M/(2^ku)),\quad
\Psi(M)=\sum_{k\ge0}I_k(M)\qquad(M>1);
\]
\(M\le1\) 时令 \(\Psi=0\)，且实际 active 输入为空。

**主命题：**
\[
\boxed{\quad
\int\mathcal C\,d\Pi430
\le\Omega_{\rm cf}W,\qquad
\Omega_{\rm cf}
=2Sr\,s\,[\Psi(M)+(1+\varepsilon _0)\Theta(M)].
\quad}
\tag{3}
\]
因此对任意 \(\gamma>0\)，在同一实际正流上
\[
P_{\rm cf}(\gamma):=\Pi430\{\mathcal C\ge\gamma\}
\le\frac{\Omega_{\rm cf}}{\gamma}W.
\tag{4}
\]
没有新增 \(X_q\) 价。\(\Psi=O(1+\log_+^2M)\)、\(\Theta=O(1+\log_+M)\)，故固定所示原参数与 \(\gamma\) 时，(4) 是 \(O(s\log^2(n+2))W\) 付款。所有阶段和路径长度均已求和。

## 2. 必须保留的可预测门

原 R425 初始门给 \(m_A>K^2m_{v_0}\)，每步严格 \(K\) 降质量。因此在 \(\Pi430\) 的每个 proper 前态，
\[
m_A>K^{j+1}m_{v_{j-1}}\qquad(j\ge1).
\tag{5}
\]
回到原 raw 生成法时，不能假定所有反事实路径仍满足原 soft 权。显式保留可预测指标
\[
\mathcal I_{j-1}
=1_{\{j\le T_x\}}\,
 1_{\{m_A>K^{j+1}m_{v_{j-1}}\}}.
\tag{6}
\]
它只依赖父、原来源和已生成的前缀，在原 actual 正支等于 active 指标。

固定原完整初始记录以及原阶段，原 Markov 核的条件期望给精确补偿
\[
\mathbb E_{\rm raw}\sum_{j\ge1}
\mathcal I_{j-1}\bar p_j
=
\mathbb E_{\rm raw}\sum_{j\ge1}
\mathcal I_{j-1}
1_{\{A\in\bar\alpha_jQ_{v_j}\}}.
\tag{7}
\]
有限严格质量下降保证这是有限和；不增加一个初始 Dirac，不在终端后重复转移。源、初始节点、父及原阶段在条件期望中均固定。

式 (7) 本身不允许直接带一个依赖完整未来的权 \(F\)。正确顺序是：实际费用中保留旧 \(b_i\) 与原来源进入权；其余未来正权 \(F\le1\) 仅在上界中删除，并先把实际 \(\bar p_j\) 换为 \(\mathcal I_{j-1}\bar p_j\)，然后才对 raw 生成法用 (7)。

反事实命中的下一节点仍来自真实严格前缀。因此在 (7) 右侧的每个正项，
\[
m_{v_j}<m_{v_{j-1}}/K,\quad
m_A>K^{j+1}m_{v_{j-1}}
\quad\Longrightarrow\quad
\boxed{m_A>K^{j+2}m_{v_j}.}
\tag{8}
\]
这就是新桥的关键。反事实节点不需要满足原未来历史、R425 完整软权、当前 \(D_i\) 或旧父质量窗；它只有 (8) 和其真实来源捕获。若删掉 (6)，则不能使用 (8)，后面的父体积价无根据。

## 3. 反事实 proper 访问的全部代数预算

固定一个来源端 \(x\) 和目标代数 \(j\ge1\)，将 (7) 右端按目标节点 active/terminal 作不交分拆。利用 (8)，可上放为原第 \(j\) 步访问律，同时保留
\[
m_A>K^{j+2}m_u,\qquad A\in\bar\alpha_jQ_u.
\tag{9}
\]
初始节点始终 active；初始的实际子概率质量不归一化。

对于 active 目标 \(u\)，引用 R429 已审的联合秩—代数界：
\[
Q_{x,j}(v_0,du)\,1_{\{Z_u(x)>h\}}
\le
\frac{\rho_x(du)}{T_u(x)}
\min\!\left(1,\frac{J(x)}{2^{j-1}T_u(x)}\right)
1_{\{Z_u(x)>h\}},
\tag{10}
\]
其中 \(T_u(x)=\rho_x\{v:m_v\le m_u\}\)。其来源积分不大于 \(I_{j-1}(M)\)。active 目标有 \(T_u^-(x)\ge Z_u(x)>h\)，因此完整质量原子的秩区间在 \(h\) 以上；没有切开跨越 \(h\) 的原子。

对于恰在第 \(j\) 步达到的 terminal 目标，引用 R428：
\[
Q_{x,j}^{\rm term}(v_0,du)
\le a_j\,\rho_x(du)1_{\{Z_u(x)\le h\}}/h,\qquad
a_j=\min(1,M2^{-(j-1)}).
\tag{11}
\]
普遍闭质量窗给
\(\rho_x\{Z_u(x)\le h\}\le(1+\varepsilon _0)h\)，所以来源积分不大于 \((1+\varepsilon _0)a_j\)。

式 (10)、(11) 对每个原 active 初始记录一致，故对原初始子概率混合仍成立；不需要假定受限路径重新独立。尤其没有把初始核当成 proper 访问，因此本轮没有 \(2\log M\) 初始项。

现在固定 \(x,u,j\)，保留 (9)，使用真实父中心和完整匹配：
\[
\begin{aligned}
&\int_E\frac{q_A1_{Q_A}(x)}{m_A}
 1_{\{m_A>K^{j+2}m_u,\ A\in\bar\alpha_jQ_u\}}\,dA\\
&\quad\le
\frac{\lambda}{K^{j+2}m_u}|\bar\alpha_jQ_u|
=\frac{\lambda sR_u^n}{m_u}
=\frac{\lambda s}{q_u}\le rs.
\end{aligned}
\tag{12}
\]
没有把立方体体积当作 \(f\) 的质量上界；所用等式是实际 \(m_u=q_uR_u^n\)。实际父选择器可任意可测，并没有积分一个独立的边长参数。

最后是原阶段计价。另一条原生成路径可在正上界中积分至至多 1，另一来源后验积分至 1。保留原 \(b_i\) 至阶段求和，使用 \(\sum_i b_i\le1\) 与两个原父端逐来源帽 \(\beta,C_{\rm col}\)，只产生一次 \(S\)。在应用 (10)、(11) 后，这些界已不依赖初始记录，可合法作上述求和。仅有初始记录**总质量**上界 \(SX_q\) 不足以证明 (3)；这里实际使用的是原带 \(\sigma(dA)\pi_A(dx)\) 的来源合同。

结合 (10)–(12)，单个方向第 \(j\) 代的上界为
\[
Sr\,s\,[I_{j-1}(M)+(1+\varepsilon _0)a_j]W.
\tag{13}
\]
两条链、全部 \(j\ge1\) 求和得到 (3)。系数 2 只来自两条来源路径，\(S\) 不再乘一次两父端因子。所有换序是非负积分，原质量原子、零访问、停止节点和初始子概率都保留。

这里原实际票据从未命中 \(\bar{\mathcal N}_j\)，(7) 的命中是 raw 反事实访问；我们没有把它说成 R428 或 R429 已付的**实际**命中质量。新费用依据 (12)、(13) 独立计价，旧邻近付款不退款，也不作为一份可重复使用的负信用。

## 4. 新实际分拆、参数与完整剩余

定义中间余流
\[
\Pi^{\prime}=1_{\{\mathcal C<\gamma\}}\Pi430,\qquad
R^{\prime}=\Pi^{\prime}(1).
\]
则
\[
R430=P_{\rm cf}(\gamma)+R^{\prime},\qquad
P_{\rm cf}(\gamma)\le\Omega_{\rm cf}W/\gamma.
\tag{14}
\]
这是发生在原低风险、全路径父远票据上的正分支，并非另一普通邻近事件。

由于 \(\bar\alpha_j\le\alpha_j\)，有 \(\bar p_j\le p_j\)。原 \(\mathcal P>t\) 给
\[
0\le\mathcal C\le\sum_{x,j}p_j<\log(1/t).
\tag{15}
\]
因此可选择 \(0<\gamma<\log(1/t)\) 得到不被原支持条件自动排空的测试范围；若 \(\gamma\ge\log(1/t)\)，所付事件为空，(14) 仍成立。没有证明每个原场中该事件非空，也没有证明统一正比例删除。

剩余完整保留 \(\Pi430\) 的全部标签与父质量尾，并增加
\[
\sum_{x,j}
\frac{\rho_x(\bar{\mathcal N}_j(A)\cap\{m_u<m_{v_{j-1}}/K\})}
     {Z_{v_{j-1}}(x)}
<\gamma.
\tag{16}
\]
这是真实原前缀中父邻近容量的累计小条件。它不保证附近没有接收者，不给父后验密度帽，也不给后继新的原历史资格。整个 (16) 余项仍未获得一般根阶预算。

若仅作本附件分拆，记
\[
C^{\prime}=C430,\qquad
V^{\prime}=V430+\Omega_{\rm cf}/\gamma.
\]
继承原反馈与所有外费：
\[
G_0\le16\widehat F\{R^{\prime}+C430X_q+V^{\prime}W\},
\]
\[
B_H\le32\widehat F R^{\prime}
 +(E387+32\widehat F C430)X_q
 +(S390+8s+32\widehat F V^{\prime})W,
\]
\[
\mathrm{入口}\le\Lambda\{8\lambda HW+
2d_{\rm eff}A_{{\rm entrance},n}W_\nu/H+
64\widehat F R^{\prime}
 +(2E387+64\widehat F C430)X_q
 +(2S390+16s+64\widehat F V^{\prime})W\}.
\tag{17}
\]
新增入口来源价恰 \(64\Lambda\widehat F\,\Omega_{\rm cf}W/\gamma\)，没有新增 \(X_q\)。本附件用带撇中间符号，最终 R431 的命名由组合主稿决定，避免重复或混合计费。

## 5. 本机检查与证据范围

实际执行 `/tmp/r431_geometry_check.py`，输出保存于 `/tmp/r431_geometry.result.txt`，全部 Fraction：

1. 12 个含重复质量的严格前缀模型。精确核可预测补偿等式，含真、假前态质量门；逐条核 432 个反事实质量蕴含 (8)。
2. 9 个非均匀完整 \(f\) 的原生连续父中心积分。实际质量为均匀背景加中心正包的完整捕获量，验证 (12) 的真实中心体积、质量分母消去。该诊断使用有理 \(K=11/10\)、一维边长和 \(j=1,2,3\)，不冒充当前高维完整原历史。
3. 12 个双来源、双原生成链模型。保任意可耦合完整未来的正权，并限于全远、前态门全真、原避开乘积 \(>1/20\)；核原风险矩支配与 48 个阈值付款，其中 43 个实际所付有限质量为正。

这些检查不认证原生全历史非空、原 \(D_i\)/stage 或最终全局闭合。实际 \(W\) 价格来自 (8)、(10)–(13) 的解析证明，不以有限测试代替。系统 `python3` 没有 SymPy；本次正式检查只用标准库 Fraction，无安装或未运行软件结果。

本轮新增内容是可预测父质量门保留下的反事实风险 **\(W\) 一阶矩预算**及其实际正分支 (14)。它补上了仅有 first-hit 似然 \(X_q\) 收据所没有的来源计价，但不把低累计风险补集宣称已付。
