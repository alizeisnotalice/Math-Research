"""R431 exact finite compensation and native parent-capacity checks.
The finite paths are not a certification of full original native history.
"""
from fractions import Fraction as F


def enumerate_paths(masses, rho, K, h, start, father, seed):
    prefixes = [[u for u, m in enumerate(masses) if m < mv/K]
                for mv in masses]
    Z = [sum((rho[u] for u in us), F(0)) for us in prefixes]
    assert Z[start] > h
    output = []
    implications = 0

    def walk(v, generation, probability, risk, hits, all_far,
             all_prefix, likelihood, raw_risk, path):
        nonlocal implications
        if Z[v] <= h:
            output.append((probability, risk, hits, all_far,
                           all_prefix, likelihood, raw_risk, tuple(path)))
            return
        j = generation+1  # proper target generation
        predictable = father > K**(j+1)*masses[v]
        near = {u for u in prefixes[v] if (u+2*j+seed) % 5 < seed % 4}
        p = sum((rho[u] for u in near), F(0))/Z[v]
        for u in prefixes[v]:
            if predictable:
                assert father > K**(j+2)*masses[u]
                implications += 1
            walk(u, j, probability*rho[u]/Z[v],
                 risk+int(predictable)*p,
                 hits+int(predictable and u in near),
                 all_far and u not in near,
                 all_prefix and predictable,
                 likelihood*(1-p), raw_risk+p, path+[u])
    walk(start, 0, F(1), F(0), 0, True, True, F(1), F(0), [start])
    assert sum((row[0] for row in output), F(0)) == 1
    erisk = sum((row[0]*row[1] for row in output), F(0))
    ehits = sum((row[0]*row[2] for row in output), F(0))
    assert erisk == ehits
    return output, erisk, implications


# Stage 1: predictable compensation with both true and false predecessor gates.
models = implications = 0
zero_gate_records = 0
for seed in range(12):
    masses = list(map(F, [1,1,2,3,4,8,9,16,32]))
    rho = [F(1+(i+seed) % 5, 4) for i in range(len(masses))]
    K = [F(3,2), F(2), F(3)][seed % 3]
    father = K**[1,2,4][seed % 3]*masses[-1]
    rows, erisk, count = enumerate_paths(masses, rho, K, F(1,4),
                                         8, father, seed)
    zero_gate_records += sum(not row[4] for row in rows)
    models += 1
    implications += count
assert zero_gate_records > 0 and implications > 0
print("Stage 1 PASS:", models, "exact predictable-compensation models;",
      implications, "counterfactual mass implications")


# Stage 2: actual continuous parent centers with full f matching.
# Nonuniform f=background plus centered packet; selected child side 1,
# parent side 2. Parent center interval [-.5,.5] has actual Lebesgue length 1.
# K here is diagnostic 11/10, so j=1 has D=K^3 m_child; s=2.
native = 0
K = F(11,10)
for packet in [F(1,20), F(1,10), F(1,5)]:
    mw, ma = 1+packet, 2+packet
    qw, qa = mw, ma/2
    lam, q, s = qw, F(1), F(2)
    for j in [1,2,3]:
        gap = K**(j+2)
        alpha_to_n = s*gap  # n=1, exact test enlargement
        assert ma > gap*mw
        assert alpha_to_n > 1
        # Entire actual parent interval is in alpha Q_child and captures x=0.
        actual = qa/ma
        raw_bound = lam*alpha_to_n/(gap*qw)
        final_bound = lam/q*s
        assert 0 < actual <= raw_bound <= final_bound
        native += 1
print("Stage 2 PASS:", native, "nonuniform full-f native parent-center bounds")


# Stage 3: two original fixed-source chains, arbitrary coupled future marks,
# all-far, all true predecessor gates and low original risk.
# No independent conditional law is asserted for the retained paths.
models = threshold_checks = positive = 0
for seed in range(12):
    masses = list(map(F, [1,1,2,3,4,8,9,16,32]))
    rho = [F(1+(2*i+seed) % 5, 4) for i in range(len(masses))]
    K = [F(3,2), F(2), F(3)][seed % 3]
    father = K**4*masses[-1]
    left, ey, _ = enumerate_paths(masses, rho, K, F(1,4), 8, father, seed)
    right, ez, _ = enumerate_paths(masses, rho[::-1], K, F(1,4),
                                    8, father, seed+1)
    t = F(1,20)
    moment = F(0)
    rows = []
    for a, y in enumerate(left):
        for b, z in enumerate(right):
            keep = y[3] and z[3] and y[4] and z[4] and y[5]*z[5] > t
            mark = F((2*a+3*b+seed) % 7, 6) if keep else F(0)
            weight = y[0]*z[0]*mark
            risk = y[6]+z[6]
            if keep:
                assert risk == y[1]+z[1]
            moment += weight*risk
            rows.append((weight, risk))
    assert moment <= ey+ez
    for gamma in [F(1,10), F(1,4), F(1,2), F(1)]:
        paid = sum((w for w, risk in rows if risk >= gamma), F(0))
        assert gamma*paid <= moment
        threshold_checks += 1
        positive += int(paid > 0)
    models += 1
assert positive > 0
print("Stage 3 PASS:", models, "joint retained-flow models;",
      threshold_checks, "threshold checks;", positive, "positive paid checks")
print("No full native stage/history or global closure certified; W price is analytic.")
