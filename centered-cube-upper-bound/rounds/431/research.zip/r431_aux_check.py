from fractions import Fraction as F
from decimal import Decimal, localcontext

# Positive Taylor series and a rational geometric majorant of its tail.
def exp_bounds(x):
    assert x >= 0
    N=max(60,2*(x.numerator//x.denominator)+4)
    term=F(1); lo=term
    for k in range(1,N+1):
        term*=x/k; lo+=term
    first=term*x/(N+1)
    assert x < N+2
    return lo,lo+first/(1-x/F(N+2))

single=0
for T in map(F, ['1/4','1','4','16','256']):
    for x in map(F,['1/100','1','8']):
        p=x/T; elo,ehi=exp_bounds(x)
        # Exact lower bound for exp(pT) A_T(p).
        cost_lo=elo+(elo-1)/p
        assert cost_lo >= 1+T
        single+=1

mixtures=0; normalizations=0
for T in map(F,['1/4','4','64']):
    xs=list(map(F,['1/16','1/2','2']))
    weights=[F(1,6),F(1,3),F(1,2)]
    cs=[]; ps=[]; los=[]; his=[]
    for w,x in zip(weights,xs):
        lo,hi=exp_bounds(x)
        cs.append(w*hi); ps.append(x/T);los.append(lo);his.append(hi)
    # Rational coefficients dominate the endpoint; decreasing positive mixtures
    # therefore cover every depth between zero and T.
    assert sum(c/hi for c,hi in zip(cs,his))==1
    cost_lo=sum(c*(1+(1-1/lo)/p) for c,p,lo in zip(cs,ps,los))
    assert cost_lo >= 1+T
    mixtures+=1
    # Algebraic attenuation/centering: for any positive factors e^{-pB},
    # uncentered coefficients d=c/factor have exactly the same effective bill.
    for factor in [F(1),F(1,3),F(1,100)]:
        ds=[c/factor for c in cs]
        assert [d*factor for d in ds]==cs
        assert sum(d*factor*(1+(1-1/lo)/p) for d,p,lo in zip(ds,ps,los))==cost_lo
        normalizations+=1
print(f'PASS: {single} exact single-power certificates, {mixtures} exact mixture covers, {normalizations} centering algebra checks.')
print('Scalar certificate optimization only; no native geometry/history fixture and no global payment claimed.')
print('Decimal diagnostics: T, x=pT, finite-window single-power cost, ratio to 1+T')
with localcontext() as ctx:
    ctx.prec=60
    for T in [Decimal(1),Decimal(16),Decimal(256)]:
        for x in [Decimal(1),Decimal(1)/4,Decimal(1)/16,Decimal(1)/64,Decimal(1)/1024]:
            p=x/T; ex=x.exp(); cost=ex+(ex-1)/p
            print(f'{T}, {x}, {cost:.18E}, {cost/(1+T):.18E}')
