% R431 floating parameter exploration, not interval arithmetic.
r431_rows=zeros(27,8);r431_idx=0;
for r431_n=[16 64 256 1024 4096 65536 1048576 1073741824 1099511627776]
 for r431_eps=[.5 .125 .03125]
  r431_idx=r431_idx+1;r431_s=1+sqrt(r431_n);
  r431_M=r431_eps*(1+r431_n*log(2))/r431_s;
  if r431_M<=1
   r431_Theta=2*r431_M;r431_Psi=0;
  else
   r431_L=ceil(log2(r431_M));
   r431_Theta=r431_L+2*r431_M*2^(-r431_L);
   r431_Psi=r431_L*(1+log(r431_M))-log(2)*r431_L*(r431_L-1)/2-2+2*r431_M*2^(-r431_L);
  end
  r431_Omega=4*r431_s*(r431_Psi+(1+r431_eps)*r431_Theta);
  r431_gamma=.25;r431_paid=r431_Omega/r431_gamma;
  r431_rows(r431_idx,:)=[r431_n r431_eps r431_M r431_Theta r431_Psi r431_Omega r431_paid r431_paid/(r431_s*log(r431_n+2)^2)];
 end
end
writematrix(r431_rows,'/tmp/r431_matlab_parameters.csv');
r431_text=sprintf('R431 n eps0 M Theta Psi Omega Gamma-quarter-price normalized\n');
for r431_idx=1:size(r431_rows,1)
 r431_text=[r431_text sprintf('%.12g %.12g %.12g %.12g %.12g %.12g %.12g %.12g\n',r431_rows(r431_idx,:))];
end
r431_text=[r431_text version newline];r431_fid=fopen('/tmp/r431_matlab.result.txt','w');assert(r431_fid>=0);
fwrite(r431_fid,uint8(r431_text),'uint8');fclose(r431_fid);disp(r431_text);
