"""Exact symbolic-series and ledger checks; independent float CSV cross-check.
No claim of original-history validation or full residual closure.
"""
from fractions import Fraction as F
from pathlib import Path
import csv, math

def add(a,b):return tuple(x+y for x,y in zip(a,b))
def mul(c,a):return tuple(c*x for x in a)
def psi_coeff(m):
 if m<=1:return (F(0),)*3
 l=0
 while F(2)**l<m:l+=1
 return F(l),-F(l*(l-1),2),F(l-2)+2*m/F(2)**l

def theta(m):
 if m<=1:return 2*m
 l=0
 while F(2)**l<m:l+=1
 return l+2*m/F(2)**l
cases=[[F(1,4),F(1),F(2),F(3),F(4),F(7)],
       [F(15,16),F(17,16),F(31,8),F(33,8),F(127,16),F(129,16)],
       [F(2)**k+F(d,3) for k in [8,16,32] for d in [-1,1]]]
for phase in cases:
 for m in phase:
  part=(F(0),)*3
  if m>1:
   for k in range(80):
    # At equality log(m/2^k)=0: use the identical rational tail expression.
    term=(F(1),F(-k),1-F(1,2)**k) if F(2)**k<m else (F(0),F(0),(m-1)/F(2)**k)
    part=add(part,term)
   part=add(part,(F(0),F(0),2*(m-1)/F(2)**80))
  assert part==psi_coeff(m)
  S=F(2);r=F(3,2);s=F(11);eps=F(1,8);gamma=F(1,4)
  omcf=mul(2*S*r*s,add(part,(F(0),F(0),(1+eps)*theta(m))))
  om428=(F(0),F(0),2*S*r*s*(1+eps)*theta(m))
  logterm=(F(2),F(0),F(0)) if m>1 else (F(0),)*3
  om429=mul(2*S*r*s,add(part,logterm))
  assert omcf==add(add(om428,om429),mul(-2*S*r*s,logterm))
  # Compare every coefficient in the full mother substitution; X price unchanged.
  C=F(1,100);V=F(31);X=F(17);W=F(13);R=F(19)
  fh=1/(1-32*F(1,128)-16*F(1,256));Lam=F(128,119)
  price=mul(1/gamma,omcf);oldR=add((F(0),F(0),R),mul(W,price))
  for scale in [16*fh,32*fh,64*Lam*fh]:
   left=mul(scale,add(oldR,(F(0),F(0),C*X+V*W)))
   right=mul(scale,add((F(0),F(0),R+C*X+V*W),mul(W,price)))
   assert left==right
print('Exact series/ledger PASS: 18 parameter configurations in phases 6/6/6; log coefficients symbolic, infinite tails retained.')
rows=list(csv.reader((Path(__file__).parent/'r431_matlab_parameters.csv').open()));assert len(rows)==27
norm=[]
for row in rows:
 n,eps,m,th,ps,om,paid,no=map(float,row);s=1+math.sqrt(n)
 mm=eps*(1+n*math.log(2))/s
 th2=sum(min(1,mm/(2.**k)) for k in range(80))+2*mm/2.**80
 if mm<=1:ps2=0
 else:
  ps2=sum((math.log(mm)-k*math.log(2)+1-2.**(-k)) if 2.**k<=mm else (mm-1)*2.**(-k) for k in range(80))+2*(mm-1)/2.**80
 om2=4*s*(ps2+(1+eps)*th2);paid2=4*om2
 for actual,expected in zip([m,th,ps,om,paid,no],[mm,th2,ps2,om2,paid2,paid2/(s*math.log(n+2)**2)]):
  assert math.isclose(actual,expected,rel_tol=4e-13,abs_tol=1e-13)
 norm.append(no)
print('MATLAB floating CSV PASS: 27 rows, n=16 through 2^40; gamma=1/4, S=2,r=1. Not interval certificates.')
print('Normalized paid coefficient range %.9g through %.9g'%(min(norm),max(norm)))
print('No new X coefficient; no global absorption or low-compensator residual closure certified.')
