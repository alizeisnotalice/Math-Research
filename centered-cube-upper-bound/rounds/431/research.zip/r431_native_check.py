from fractions import Fraction as F
import json

def overlap(a,b):return max(F(0),min(a[1],b[1])-max(a[0],b[0]))
def mass_at(c,R,spikes):
    box=(c-R/2,c+R/2)
    return overlap(box,(-F(4),F(4)))+sum(m*overlap(box,I)/(I[1]-I[0]) for I,m in spikes)
def constant_mass(I,R,spikes):
    pts={I[0],I[1]}
    for Q,m in spikes:
        for e in Q:
            for t in [e-R/2,e+R/2]:
                if I[0]<t<I[1]:pts.add(t)
    pts=sorted(pts);pts+= [(a+b)/2 for a,b in zip(pts,pts[1:])]
    vals={mass_at(c,R,spikes) for c in pts}
    assert len(vals)==1,(I,R,vals)
    return vals.pop()
def piecewise_p_moments(A,targets,rad,Z):
    cuts={A[0],A[1]}
    for I,m in targets:
        for e in I:
            for a in [e-rad,e+rad]:
                if A[0]<a<A[1]:cuts.add(a)
    cuts=sorted(cuts)
    def p(a):return sum(overlap(I,(a-rad,a+rad))/m for I,m in targets)/Z if Z else F(0)
    one=two=F(0)
    for a,b in zip(cuts,cuts[1:]):
        pa,pb=p(a),p(b)
        assert p((a+b)/2)==(pa+pb)/2
        one+=(b-a)*(pa+pb)/2
        two+=(b-a)*(pa*pa+pa*pb+pb*pb)/3
    return one/(A[1]-A[0]),two/(A[1]-A[0])

def run(name,K,RP,RA,common=F(0),extra=F(0),pos=(F(1,8),F(1,4)),A=None):
    spikes=[]
    if common:spikes.append(((F(0),F(1,100)),common))
    if extra:spikes.append(((F(2,5),F(41,100)),extra))
    P=(-F(1,50),-F(3,200))
    if A is None:A=(RA/2-F(1,500),RA/2)
    rows=[('negative',(-F(1,4),-F(1,8)),F(1)),('positive',pos,F(1)),('previous',P,RP),('parent',A,RA)]
    for k,(_,I,R) in enumerate(rows):
        assert I[0]<I[1] and I[0]-R/2>=-4 and I[1]+R/2<=4
        assert I[1]-R/2<=0 and I[0]+R/2>=F(1,100)
        for _,J,_ in rows[k+1:]:assert overlap(I,J)==0
    masses={label:constant_mass(I,R,spikes) for label,I,R in rows}
    qs=[masses[label]/R for label,I,R in rows]
    assert max(qs)/min(qs)<=F(4,3)
    assert max(R for _,_,R in rows)/min(R for _,_,R in rows)<=2
    # Initial father-far for every actual parent/previous center pair.
    assert A[0]-P[1]>K*K*RP/2
    mp=masses['previous'];ma=masses['parent'];gate=ma>K*K*mp
    candidates=[(I,masses[label]) for label,I,R in rows if label in ('negative','positive') and masses[label]<mp/K]
    # Parent and previous rows do not secretly enter the strict prefix.
    assert masses['previous']>=mp/K and masses['parent']>=mp/K
    Z=sum((I[1]-I[0])/m for I,m in candidates)
    rad=K**3/2 # n=1, s=1, target side=1, proper generation j=1
    p,p2=piecewise_p_moments(A,candidates,rad,Z)
    raw_pred=F(gate)*p
    raw_hit=F(gate)*p # independent direct integration of near lengths below
    if Z:
        cuts={A[0],A[1]}
        for I,m in candidates:
            for e in I:
                for a in [e-rad,e+rad]:
                    if A[0]<a<A[1]:cuts.add(a)
        cuts=sorted(cuts);near_int=F(0)
        for l,r in zip(cuts,cuts[1:]):
            for I,m in candidates:
                near_int+=(r-l)*(overlap(I,(l-rad,l+rad))+overlap(I,(r-rad,r+rad)))/(2*m)
        raw_hit=F(gate)*near_int/(Z*(A[1]-A[0]))
    assert raw_pred==raw_hit
    retained_pred=F(gate)*(p-p2) # F=1_{next far}; initial far already checked
    retained_hit=F(0) # identical target cannot be near and far
    assert 0<=retained_pred<=raw_pred
    max_parent_cost=F(0)
    if gate and Z:
        for I,m in candidates:
            assert ma>K**3*m
            assert all(masses[label]>=m/K for label,_,_ in rows) # targets have own strict rank zero
            probes={I[0],I[1]}
            for e in A:
                for v in [e-rad,e+rad]:
                    if I[0]<v<I[1]:probes.add(v)
            local=max(overlap(A,(v-rad,v+rad))*(ma/RA)/ma for v in probes)
            assert local<=max(qs)/min(qs) # s=1: actual father-volume certificate
            max_parent_cost=max(max_parent_cost,local)
    return {'name':name,'K':str(K),'s':'1','RA':str(RA),'RP':str(RP),
            'masses':{k:str(v) for k,v in masses.items()},'qrange':[str(min(qs)),str(max(qs))],
            'source_total_mass':str(8+common+extra),'prefix_mass_Z':str(Z),'Iprev':gate,
            'max_actual_parent_volume_cost':str(max_parent_cost),'raw_compensation':str(raw_pred),'retained_Fp':str(retained_pred),
            'retained_Fhit':str(retained_hit),'strict_failure_visible':retained_pred>0}

K=F(11,10);RP=F(6,5)
stage1=[run('uniform_balanced',K,RP,F(3,2)),
        run('variable_near_fraction',K,RP,F(3,2),pos=(F(1,20),F(1,5))),
        run('common_concentrated',K,RP,F(3,2),common=F(1,10))]
# Exact parent-gate atom, strict-prefix endpoint, and actual near threshold crossing.
stage2=[run('parent_gate_equality',K,RP,K*K*RP),
        run('strict_prefix_equality',K,K,F(3,2)),
        run('near_boundary_integrated',K,RP,F(3,2),pos=(F(1,20),F(1,5)),A=(F(73,100),F(3,4)))]
stage3=[run('source_asymmetric_overlap',K,RP,F(3,2),common=F(1,10),extra=F(1,20)),
        run('changed_K_and_concentration',F(9,8),RP,F(8,5),common=F(1,5)),
        run('changed_K_and_window',F(21,20),RP,F(8,5),common=F(1,10),pos=(F(1,10),F(3,10)))]
allcases=stage1+stage2+stage3
assert sum(x['strict_failure_visible'] for x in allcases)==7
assert stage2[0]['Iprev'] is False and stage2[0]['raw_compensation']=='0'
assert stage2[1]['prefix_mass_Z']=='0'
print('PASS: 9 continuous full-source matched selector models; stages 3/3/3; 7 strictly positive Fp versus zero Fhit cases.')
print('n=1, rational K, s=1 diagnostics only: not n>=9, original own-high, full stage/history or Pi430 realization.')
print('Raw compensation uses original prefix and keeps the predictable Iprev; retained future all-far F must be removed for the upper bound.')
print(json.dumps({'stage1':stage1,'stage2':stage2,'stage3':stage3},indent=2))
