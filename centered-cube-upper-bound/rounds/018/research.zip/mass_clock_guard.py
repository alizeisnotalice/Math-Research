#!/usr/bin/env python3
"""Exact finite tests of real cube capture and the mass-clock maximal bound.
Python standard library; no random sampling, fitted exponents, or spatial-volume claim.
"""
from fractions import Fraction as F
from itertools import product
import json
from pathlib import Path

def signs(c):
    return product((-1, 1), repeat=c)

def dot(s, row):
    return sum((u*v for u,v in zip(s,row)), F(0))

def test_rows(rows, weights, auxiliary=False):
    c=len(weights); q=max(weights); masses=list(map(sum,rows))
    assert all(all(u<=v for u,v in zip(rows[i],rows[i+1])) for i in range(len(rows)-1))
    assert all(v<=w for row in rows for v,w in zip(row,weights))
    ss=list(signs(c)); z=[[dot(s,row) for row in rows] for s in ss]
    cap_ratios=[]; norm_ratios=[]; captests=0
    # Include exact jumps and thresholds strictly between jumps.
    caps=sorted(set(masses+[v/2 for v in masses if v>0]))
    for cap in caps:
        ix=[i for i,m in enumerate(masses) if m<=cap]
        if not ix or cap==0: continue
        k=rows[ix[-1]]
        actual=sum(max(zs[i]**2 for i in ix) for zs in z)/len(ss)
        collision=4*sum(v*v for v in k)
        assert actual<=collision<=4*q*cap
        cap_ratios.append(actual/(4*q*cap)); captests+=1
    for m0 in sorted(set(m for m in masses if m>0)):
        ix=[i for i,m in enumerate(masses) if m>=m0]
        actual=sum(max((zs[i]/masses[i])**2 for i in ix) for zs in z)/len(ss)
        assert actual<=16*q/m0
        norm_ratios.append(actual/(16*q/m0))
    auxcases=0
    if auxiliary:
        k=rows[-1]; choices=[]
        for j in range(c):
            prev=F(0); cc=[]
            for i,row in enumerate(rows):
                delta=row[j]-prev
                if delta: cc.append((i,delta/k[j]))
                prev=row[j]
            choices.append(cc)
        auxmax=F(0)
        for s,zs in zip(ss,z):
            avg=[F(0)]*len(rows); avmax=F(0)
            for ts in product(*choices):
                prob=F(1)
                for _,p in ts: prob*=p
                path=[sum((s[j]*k[j] for j,(ti,_) in enumerate(ts) if ti<=i),F(0)) for i in range(len(rows))]
                for i,val in enumerate(path): avg[i]+=prob*val
                avmax+=prob*max(v*v for v in path); auxcases+=1
            assert avg==zs  # Exact conditional-average identity at every real capture.
            assert max(v*v for v in zs)<=avmax
            auxmax+=avmax/len(ss)
        assert auxmax<=4*sum(v*v for v in k)
    return {'cells':c,'candidates':len(rows),'signs':len(ss),'cap_tests':captests,
            'normalized_tests':len(norm_ratios),'auxiliary_cases':auxcases,
            'max_cap_ratio':str(max(cap_ratios,default=F(0))),
            'max_normalized_ratio':str(max(norm_ratios,default=F(0)))}

def atomic(n,c,depth,xshift,aux=False):
    # Each j is an actual unit grid cell; four atoms in that cell enter at different radii.
    # Other coordinates are deterministically correlated with the first coordinate.
    atoms=[]
    for j in range(c):
        for h in range(4):
            y=[F(2*j)+F(h+1,8)] + [F(((j+1)*(k+2)+h)%7+1,9) for k in range(n-1)]
            w=F((j+1)*(h+1),2**(depth*h))
            cell=tuple(v.numerator//v.denominator for v in y)
            atoms.append((tuple(y),w,cell))
    cells=sorted(set(cell for _,_,cell in atoms)); assert len(cells)==c
    x=(xshift,)+tuple(F(1,3) for _ in range(n-1))
    distances=[2*max(abs(yi-xi) for yi,xi in zip(y,x)) for y,_,_ in atoms]
    a=F(1,8); b=max(distances)+1
    scales=sorted(set([a,b]+[r for r in distances if a<=r<=b]))
    weights=[sum(w for _,w,cc in atoms if cc==cell) for cell in cells]
    rows=[[sum(w for (_,w,cc),r in zip(atoms,distances) if cc==cell and r<=L) for cell in cells] for L in scales]
    out=test_rows(rows,weights,aux)
    masses=list(map(sum,rows)); responses=[m/L**n for m,L in zip(masses,scales)]
    M=max(responses); R=responses.index(M)
    # Since captured mass is constant between arrivals, these are complete continuous winners.
    # Gate U > M/2 corresponds to g < log 2; p constant between arrivals.
    eligible=[i for i,U in enumerate(responses) if U>M/2]
    actual=F(0)
    for s in signs(c):
        pR=dot(s,rows[R])/masses[R]
        actual+=max((dot(s,rows[i])/masses[i]-pR)**2 for i in eligible)/2**c
    bound=128*max(weights)/(M*a**n)
    assert actual<=bound
    out.update(n=n,atoms=len(atoms),depth=depth,xshift=str(xshift),
               eligible_count=len(eligible),posterior_square=str(actual),posterior_bound=str(bound),
               winner_scale=str(scales[R]),full_window=[str(a),str(b)])
    return out

def interval_refinement(c):
    # Genuine L1 input: uniform density on [0,1], receiver -1/2, window [1,3].
    # Every mass/posterior is affine or linear-fractional between listed breakpoints,
    # so absolute posterior extrema occur at breakpoints; t-perturbed response does too.
    # Gate U > M/2 starts at L>3/2; include its limiting boundary for an upper guard.
    scales=sorted(set([F(1),F(3,2),F(3)]+[1+F(2*j,c) for j in range(c+1)]))
    rows=[[max(F(0),min(F(j+1,c),L/2-F(1,2))-F(j,c)) for j in range(c)] for L in scales]
    masses=list(map(sum,rows)); M=F(1,3); t=F(1,2)
    epost=F(0); egain_excess=F(0)
    for s in signs(c):
        pR=sum(s,F(0))/c
        ix=[i for i,L in enumerate(scales) if L>=F(3,2)]
        epost+=max((dot(s,rows[i])/masses[i]-pR)**2 for i in ix)/2**c
        for pm in (-1,1):
            Mp=max((m+pm*t*dot(s,row))/L for m,row,L in zip(masses,rows,scales))
            egain_excess+=(Mp/(M*(1+pm*t*pR))-1)/2**c
    assert epost<=384/F(c)
    return {'cells':c,'q':str(F(1,c)),'signs':2**c,'posterior_square':str(epost),
            'sum_exact_multiplicative_gain_excess':str(egain_excess),
            'gain_excess_decimal':float(egain_excess)}

def main():
    stages={
      'initial':[atomic(n,c,1,F(-1,5),True) for n in (1,2) for c in (2,3)],
      'stress':[atomic(n,c,d,x,c<=3) for n in (2,4,8) for c in (3,5) for d in (0,8) for x in (F(-1,5),F(1,8))],
      'expanded':[atomic(n,c,d,F(-1,7)) for n in (16,32,64,256) for c in (4,8) for d in (1,16)]}
    refinement=[interval_refinement(c) for c in (1,2,4,8,12)]
    flat=sum(stages.values(),[])
    data={'status':'all_exact_assertions_passed','arithmetic':'Fraction; float display only for gain excess',
          'seed':None,'monte_carlo':False,'stages':stages,'L1_refinement':refinement,
          'totals':{k:sum(r[k] for r in flat) for k in ('signs','cap_tests','normalized_tests','auxiliary_cases')},
          'fixtures':len(flat),'scope':'Finite numerical evidence only; no spatial weak-ratio estimate or asymptotic fit.'}
    Path(__file__).with_name('results.json').write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'fixtures':len(flat),'totals':data['totals'],'refinement':refinement},ensure_ascii=False))
if __name__=='__main__': main()
