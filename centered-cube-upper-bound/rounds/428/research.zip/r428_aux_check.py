from fractions import Fraction as F
from pathlib import Path
import json

def run(N,h,mode):
    masses=[F(3,2)**j for j in range(N)]
    fm=[masses[0]]+[masses[j]-masses[j-1] for j in range(1,N)]
    rho=[h/F(4) for _ in range(N)]
    if mode=='zero':rho=[r if j%4 else F(0) for j,r in enumerate(rho)]
    dw=[masses[j]*rho[j] for j in range(N)]
    J=[sum(rho[j] for j in range(x,N)) for x in range(N)]
    Z=[[sum(rho[j] for j in range(x,N) if masses[j]<masses[w]/2) for w in range(N)] for x in range(N)]
    low=[[w>=x and Z[x][w]<=h for w in range(N)] for x in range(N)]
    B=[sum(rho[w] for w in range(N) if low[x][w]) for x in range(N)]
    active=[any(rho[w]>0 and w>=x and Z[x][w]>h for w in range(N)) for x in range(N)]
    for x in range(N):
        T=[sum(rho[j] for j in range(x,w+1)) if w>=x else F(0) for w in range(N)]
        assert max(T[w]-Z[x][w] for w in range(x,N))<=h/2
        assert B[x]<=min(J[x],3*h/2)
        if active[x]:assert B[x]>=h
    K=[[F(int(active[x] and low[x][w]),1)/(masses[w]*B[x]) if B[x] else F(0) for x in range(N)] for w in range(N)]
    for x in range(N):assert sum(dw[w]*K[w][x] for w in range(N))==int(active[x])
    for w in range(N):assert sum(fm[x]*K[w][x] for x in range(N))<=1/h
    gtests=[[F(1)]*N,J,[F((-1)**j*(j+1),N) for j in range(N)],fm,[F(int(j%2==0)) for j in range(N)]]
    for g in gtests:
        out=[sum(fm[x]*K[w][x]*g[x] for x in range(N)) for w in range(N)]
        lhs=sum(dw[w]*out[w]**2 for w in range(N))
        rhs=sum(fm[x]*g[x]**2 for x in range(N) if active[x])/h
        assert lhs<=rhs
    a=J;out=[sum(fm[x]*K[w][x]*a[x] for x in range(N)) for w in range(N)]
    mass=sum(dw[w]*out[w] for w in range(N));incoming=sum(fm[x]*a[x] for x in range(N) if active[x])
    assert mass==incoming
    for w in range(N):assert out[w]<=max(J)/h
    # Exact reference low/high flux with rational square amplitudes.
    roots=[F((x%5)+1) if active[x] else F(0) for x in range(N)]
    forward=reverse=energy=cross=F(0);marked_forward=marked_zero_energy=F(0)
    for w in range(N):
        pi=[fm[x]/masses[w] if x<=w else F(0) for x in range(N)]
        assert sum(pi)==1
        lo=[x for x in range(N) if low[x][w]]
        hi=[x for x in range(N) if x<=w and not low[x][w]]
        lp=sum(pi[x] for x in lo);hp=sum(pi[x] for x in hi)
        assert lp*hp==hp*lp
        fw=sum(pi[x]*roots[x]**2 for x in lo)*hp
        rv=lp*sum(pi[x]*roots[x]**2 for x in hi)
        cr=sum(pi[x]*roots[x] for x in lo)*sum(pi[x]*roots[x] for x in hi)
        en=sum(pi[x]*pi[z]*(roots[x]-roots[z])**2 for x in lo for z in hi)
        assert en==fw+rv-2*cr
        forward+=dw[w]*fw;reverse+=dw[w]*rv;energy+=dw[w]*en;cross+=dw[w]*cr
        # Genuine mark only given on low domain: zero extension makes energy tautological.
        marked=sum(pi[x]*roots[x]**2*F((x+w)%3,2) for x in lo)*hp
        marked_forward+=dw[w]*marked;marked_zero_energy+=dw[w]*marked
    assert (forward-reverse)**2<=energy*(2*(forward+reverse)-energy)
    delta=F(1,3)
    assert forward<=(1+delta)*reverse+(1+1/delta)*energy
    assert marked_forward==marked_zero_energy
    return {'N':N,'h':str(h),'mode':mode,'active_sources':sum(active),'input_mass':str(incoming),'output_mass':str(mass),'max_weighted_column':str(max(out)),'norm_checks':len(gtests),'reference_forward':str(forward),'reference_reverse':str(reverse),'reference_sqrt_energy':str(energy),'marked_zero_extension_energy':str(marked_zero_energy),'flux_verified':True}
stages={'initial':[run(N,F(1),'full') for N in [8,10,12]],'zero_atom':[run(N,F(h),'zero') for N in [10,14,18] for h in [1,2]],'expanded':[run(N,F(3),'full') for N in [20,28,40]]}
summary={'cases':{k:len(v) for k,v in stages.items()},'total':sum(map(len,stages.values())),'norm_checks':sum(r['norm_checks'] for v in stages.values() for r in v),'flux_checks':sum(r['flux_verified'] for v in stages.values() for r in v),'PASS':True}
Path(__file__).with_name('r428_aux_result.json').write_text(json.dumps({'summary':summary,'results':stages},indent=2)+'\n')
print(summary)
print('Finite matched incidence and actual rank-stop algebra. Not native Lebesgue centers, original K=e^sqrt(n), or full-history fixtures.')
print('r428_aux_result.json')
