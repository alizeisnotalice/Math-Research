from fractions import Fraction as F
import json
# Exact account and OR-union model checks; not native geometry/history.
counts={k:0 for k in ['initial','pressure','expanded']}
for stage,pars in [('initial',[F(1,2),F(1,4),F(1,8)]),('pressure',[F(1,3),F(1,10),F(1,32)]),('expanded',[F(1,64),F(1,256),F(1,1024)])]:
 for eps in pars:
  for s in [4,10,101,1001]:
   for overlap in [F(0),F(1,3),F(1)]:
    S=F(7,3);r=F(4,3);W=F(5,7);X=F(11,5)
    Fhat=F(8,7);Lam=F(128,119)
    M=eps*(s-1)**2/s
    if M<=1:
     Theta=2*M
    else:
     L=0
     while F(2)**L<M:L+=1
     Theta=L+2*M*F(2)**(-L)
    single=S*r*s*(1+eps)*Theta*W
    both=overlap*single
    paid=2*single-both
    rem=F(2,9)*W
    raw=paid+rem
    Om=2*S*r*s*(1+eps)*Theta
    assert paid<=Om*W
    C=eps;V=F(3,2)
    old=raw+C*X+V*W
    new=rem+C*X+(V+Om)*W
    assert old<=new
    for mult in [16,32,64*Lam]:
     assert mult*Fhat*(new-old)==mult*Fhat*(Om*W-paid)
    assert 64*Lam*Fhat*((V+Om)-V)==64*Lam*Fhat*Om
    counts[stage]+=1
print('PASS',json.dumps(counts,sort_keys=True),'total',sum(counts.values()))
print('Exact OR-union and unchanged-X/increased-W 16/32/64-Lambda accounts; no native flow or general closure certified.')
# Genuine finite strict-rank chains: atoms, skipped windows and terminal step.
gcounts={k:0 for k in ['initial','pressure','expanded']}; starts=0; density_checks=0
for stage,ns in [('initial',[6,8]),('pressure',[12,16]),('expanded',[24,40])]:
 for N in ns:
  for ratio,K in [(F(3),F(2)),(F(3,2),F(2)),(F(2),F(3))]:
   for den in [4,8]:
    masses=[ratio**i for i in range(N)]
    weights=[F(1+(i*7)%5,1+i%3) for i in range(N)]
    J=sum(weights); h=J/den
    past=[[k for k in range(N) if masses[k]<masses[i]/K] for i in range(N)]
    Z=[sum(weights[k] for k in past[i]) for i in range(N)]
    for i,z in enumerate(Z):
     if z<=h:continue
     starts+=1
     ez=sum(weights[k]*Z[k] for k in past[i])/z
     assert ez<=z/2
     live={i:F(1)};absorbed=F(0)
     for j in range(1,N+1):
      assert sum(live.values())<=min(F(1),J/h/F(2)**(j-1))
      nxt={}; terminal={}
      for v,pv in live.items():
       for k in past[v]:
        prob=pv*weights[k]/Z[v]
        target=nxt if Z[k]>h else terminal
        target[k]=target.get(k,F(0))+prob
      aj=min(F(1),J/h/F(2)**(j-1))
      for k,p in terminal.items():
       assert p/weights[k]<=aj/h
       density_checks+=1
      absorbed+=sum(terminal.values());live=nxt
     assert not live and absorbed==1
    # Exact upper on infinite geometric-majorant sum.
    A=J/h;L=0
    while F(2)**L<A:L+=1
    # j-1 = 0,...,L-1 contributes 1, remaining tail=A*2^(1-L).
    asum=L+A*F(2)**(1-L)
    assert asum<=L+2
    gcounts[stage]+=1
print('PASS strict-rank generation models',json.dumps(gcounts,sort_keys=True),'active starts',starts,'terminal density assertions',density_checks)
print('Atomic rank chains use rational K and masses; the universal moment/terminal-density theorem is analytic, not a native full-history claim.')
