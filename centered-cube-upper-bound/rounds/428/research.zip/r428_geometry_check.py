"""R428 exact checks. Decimal chooses candidate side lengths only;
all stated certificate assertions then use Fraction and rational bounds on e.
No model certifies original full stage/occupation/history.
"""
from fractions import Fraction as F
from decimal import Decimal, localcontext
from math import factorial
from random import Random


# Stage 1: actual continuous parent centers, nonuniform full source.
# f=1_[-3,3]+packet of total p in [-.1,.1].
# Child side 1 at 0; parent side 2, centers [-.75,.75].
# Every parent contains packet and source y=0. The point 0 is assigned to
# the child selector, not the parent selector; deletion has zero center volume.
n_native=0
for p in [F(1,20),F(1,10),F(1,5)]:
    mw,ma=1+p,2+p
    q_child, q_parent=mw,ma/2
    qmin,lam=F(1),q_child
    kappa=F(3,2)
    assert ma>kappa*mw and q_parent<=lam<=F(4,3)
    for alpha in [F(1),F(5,4),F(3,2)]:
        true_center_length=2*min(F(3,4),alpha/2)
        actual=q_parent*true_center_length/ma
        cap=lam*alpha/(kappa*qmin)
        assert 0<actual<=cap
        n_native+=1
print("Stage 1 PASS:",n_native,"nonuniform full-f native parent-center integrals")


# Stage 2: finite full-source, source-retaining U probabilities.
# Actual matching masses are used; finite parent weights do not get a native
# volume claim. Their exact measured parent constant replaces that estimate.
rng=Random(428)
finite=0
for trial in range(12):
    ns=6
    f=[F(rng.randint(1,4),3) for _ in range(ns)]
    child=[{i,(i+1)%ns} for i in range(ns)]
    parent=[set(range(ns)),set(range(4)),set(range(2,6))]
    mc=[sum(f[x] for x in C) for C in child]
    mp=[sum(f[x] for x in C) for C in parent]
    da=[F(rng.randint(1,3),5) for _ in parent]
    q=[F(1)]*len(parent)
    U=[]
    for x in range(ns):
        weights=[F(int(x in C),1)/mc[j] for j,C in enumerate(child)]
        total=sum(weights)
        U.append([w/total for w in weights])
    assert all(sum(row)==1 for row in U)
    # Geometry labels below are arbitrary finite masks; constants are measured.
    near=[[bool(rng.randint(0,1)) for _ in child] for _ in parent]
    kap=F(3,2)
    near=[[near[a][w] and mp[a]>kap*mc[w] for w in range(ns)]
          for a in range(len(parent))]
    cap=max([sum(da[a]*q[a]/mp[a]
                 for a,C in enumerate(parent) if x in C and near[a][w])
             for x in range(ns) for w in range(ns) if U[x][w]>0]+[F(0)])
    left=F(0)
    for a,C in enumerate(parent):
        for y in C:
            for z in C:
                for w in range(ns):
                    for t in range(ns):
                        # Retained joint mass <= U_y U_z; not re-normalized.
                        retained=F(1+(a+y+2*z+w+t)%3,3)
                        event=near[a][w] or near[a][t]
                        if event:
                            left+=da[a]*q[a]*f[y]*f[z]/mp[a]**2*U[y][w]*U[z][t]*retained
    assert 0<=left<=2*cap*sum(f)
    finite+=1
print("Stage 2 PASS:",finite,"finite exact terminal-reference/parent reweight checks")
print("Stage 2 uses measured parent constants, not native volume or history.")


# Rational enclosure for e: after 1/40!, tail <= (1/41!)/(1-1/42).
elo=sum((F(1,factorial(k)) for k in range(41)),F(0))
ehi=elo+F(1,factorial(41))/(1-F(1,42))
assert F(8,3)<elo<ehi<3
base_lo=elo**2*(1+elo)
base_hi=ehi**2*(1+ehi)


def side_candidate(d):
    # Decimal only generates a rational candidate; all claims checked below.
    with localcontext() as ctx:
        ctx.prec=70
        e=Decimal(1).exp()
        n=Decimal(d*d)
        kstar=(e*e*(1+e))**d
        rt=2*((-(Decimal(2)*kstar).ln()/n).exp())
        ri=rt*((Decimal(1)/d+Decimal("1.01").ln()/n).exp())
        scale=Decimal(10)**10
        return F(int(rt*scale),10**10),F(int(ri*scale),10**10)


def overlap_upper(ca,ra,cb,rb,eta,n):
    factors=[max(F(0),min(ra,rb,(ra+rb)/2-abs(ca[j]-cb[j])+2*eta))
             for j in range(3)]
    return factors[0]*factors[1]*factors[2]**(n-2)


geometric=0
for d in [32,48,64]:
    n=d*d
    s=1+d
    eta=F(1,10000*n)
    eps=F(1,100*n)
    rt,ri=side_candidate(d)
    assert 1<rt<ri<2
    kw_lo,kw_hi=base_lo**d,base_hi**d
    # Both whole f=1 and every side length are actual, so masses are side^n.
    assert (F(2)/rt)**n>kw_hi
    assert (ri/rt)**n>ehi**d
    assert (F(2)/ri)**n>ehi**(2*d)
    assert F(3,2)**n>ehi**d
    assert F(4,3)**n>ehi**(2*d)
    cw=1+F(1,n)
    ci=cw+(ri-rt)/2+F(1,4*d)
    # Compact coordinate groups: first, second, and repeated remaining n-2.
    parent_center=[F(0)]*3
    wi=[ci,F(-3,5),F(-3,5)]
    ti=[F(11,10),F(3,5),F(3,5)]
    wt=[cw,F(-1,5),F(-1,5)]
    tt=[F(11,10),F(-1,5),F(4,5)]
    y=[ci-ri/2+eps,F(-3,5),F(-3,5)]
    z=[F(13,20),F(-3,20)+eps,F(9,10)]
    for source in [y,z]:
        assert all(abs(x)+eta<1 for x in source)
    for source,center,side in [(y,wi,ri),(y,wt,rt),
                               (z,ti,F(3,2)),(z,tt,F(1))]:
        assert all(abs(x-c)+eta<side/2 for x,c in zip(source,center))
    assert all(c[0]-2*eta>1 for c in [wi,ti,wt,tt])
    # New event: parent center in alpha Q_terminal, alpha^n=s*kstar.
    # Use lower bound kstar and worst center-block distance.
    assert (2*(cw+2*eta)/rt)**n < s*kw_lo
    # R427 terminal mutual separation alpha_term=e^(2/d).
    assert (2*(1-2*eta)/max(rt,F(1)))**d > ehi**2
    # Initial mutual separation alpha=e^(1/d).
    assert (2*(F(6,5)-2*eta)/max(ri,F(3,2)))**d > ehi
    assert abs(y[2]-ti[2])-eta>F(3,4)
    assert abs(z[2]-wi[2])-eta>ri/2
    # Initial source collars, preserving their actual unequal side lengths.
    assert ((ri/2-eps-eta)/(ri/2))**(2*n)>F(1,n+2)
    assert ((F(3,4)-eps-eta)/F(3,4))**(2*n)>F(1,n+2)
    nodes=[ri,rt,F(3,2),F(1)]
    # R425 B: e^2 sum(mv/mA)^(1/d) = e^2 sum(Rv/2)^d.
    assert ehi**2*sum((R/2)**d for R in nodes)<1
    # R425 A: rigorous log lower bound log x >= 2(x-1)/(x+1).
    rlower=[2*n*((2/R)-1)/((2/R)+1)-d for R in nodes]
    assert all(r>0 for r in rlower)
    assert sum((1+r/3)**-3 for r in rlower)<1
    pairs=[(wi,ri,ti,F(3,2)),(wi,ri,tt,F(1)),
           (wt,rt,ti,F(3,2)),(wt,rt,tt,F(1))]
    cross=sum(overlap_upper(ca,ra,cb,rb,eta,n)/(ra*rb)**(n//2)
              for ca,ra,cb,rb in pairs)
    assert cross<F(1,8)
    initial_overlap=overlap_upper(wi,ri,ti,F(3,2),eta,n)
    assert initial_overlap/min(ri**n,F(3,2)**n)<2/ehi**d
    assert initial_overlap/max(ri**n,F(3,2)**n)<1/ehi**d
    geometric+=1
print("Stage 3 PASS:",geometric,"exact native center-block geometry certificates")
print("Stage 3 has rational selected side lengths and rigorous rational e bounds.")
print("It certifies matching, new event, terminal separation, old geometry and soft gates;")
print("not initial own-high, original stage/D/heavy-source/history or reference ticket positivity.")
print("ALL R428 CHECKS PASS")
