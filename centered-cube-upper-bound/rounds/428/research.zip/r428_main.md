# 第428轮：全代际父—终端邻近事件的根阶对数来源付款

2026-10-20。一般一致弱型上界仍未闭合。本轮在R427原费用上支付一个覆盖**所有原路径代数**的实际几何分支，价格为O(s log(n+2))W，无新增X_q系数。不是对特殊输入族的上界，也不宣称支付整个余项或固定比例。

## 1. 固定原场与合同

完整f≥0，W=∫f，实际中心选择器Q_v边长R_v∈[a,b]、b≤2a，m_v=f(Q_v)=q_vR_v^n、q_-≤q_v≤λ。中心测度是真实Lebesgue；σ(dA)=q_A dA，π_A=f1_QA/m_A，ρ_x(dv)=1_Qv(x)dv/m_v。设n≥9、ℓ=√n、s=1+ℓ、K=e^ℓ、h=s/(ε_0q_-)、0<ε_0≤1/2，r=λ/q_-、S=β+C_col、A_n=1+n log(b/a)。

R427保留原阶段i、首次删除、初始active双路径、完整历史及R423–425软权，并经R427正分拆裁剪；其C427已包括该轮A/B两笔X价，V427=V425。原Π427≤Π425。这里路径代数j不是原删除阶段i。

已证合同：每条固定来源路径在active节点v从ρ_x|{m_u<m_v/K}/Z_v(x)转移，Z_v=ρ_x{m_u<m_v/K}>h；至Z≤h停止。初始点均active，不增加停止点Dirac。有限质量上下界保证路径统一有限。原阶段与两父端一次上放给Sσ(dA)π_A(dy)π_A(dz)，初始子概率总量≤1，不归一化。生成时两路径独立；未来限制后的流不独立。本轮只在正上界中删除限制。

真实中心径向积分给J(x)=ρ_x(E)≤J_*=A_n/q_-。R427的普遍闭窗给B_x:=ρ_x{Z_v(x)≤h}≤(1+ε_0)h；适用于全部来源及质量原子。

## 2. 原子安全的代数衰减

固定active节点，记z=Z_v。下一节点u分布为ρ_x/z在质量初段D_v={m_u<m_v/K}上。Z_u至多为D_v内u质量的严格左CDF。若该初段各质量原子权为a_k，则
\[
\int_{D_v}Z_u\,d\rho_x(u)\le\frac12\left(z^2-\sum_k a_k^2\right)\le\frac{z^2}{2}.
\]
连续部分由Tonelli计数两个不同质量的有序对，等质量原子整块保留。因此E[Z_next|v]≤z/2。对原过程在停止时杀死，仅保active状态，得到
\[
\mathbb P(T\ge j)\le a_j:=\min\{1,M2^{-(j-1)}\},\qquad M=J_*/h=\varepsilon_0A_n/s,\quad j\ge1.
\]
T为首次达到own-low所需的步数；初始active故T≥1。第j步落到终端的单步密度≤ρ_x|low/h，因此精确终端代数子核满足
\[
H_{x,j}(v,dw)\le a_j\,1_{\{Z_w(x)\le h\}}\rho_x(dw)/h.\tag{1}
\]
这是原未过滤核的子概率上界，不按T=j条件归一。对全部初始active子概率平均后仍成立。

令Θ(M)=Σ_{j≥1}a_j。若0<M≤1，则Θ=2M；若M>1，设L=ceil(log_2 M)，则Θ=L+2M2^{-L}≤L+2。于是
\[
\Theta(M)\le 2+\lceil\log_2^+ M\rceil=O(1+\log(n+2)).\tag{2}
\]
M≤1时实际上无active起点，原余流为空；正上界仍安全。所有有限路径和先成立，再以非负和上放到无穷代数，不删原删除过程的终端原子。

## 3. 与原软权同步的代际质量门

对一条j步路径，节点v_0,…,v_j=w；原每步严格质量下降K。R425第二软权为正意味着对两链全部节点
\[
e^2\sum_v(m_v/m_A)^{1/\ell}<1.
\]
其中任何一条链已给
\[
\sum_{k=0}^j(m_{v_k}/m_A)^{1/\ell}
> (m_w/m_A)^{1/\ell}\sum_{k=0}^j e^k.
\]
定义
\[
G_j=\sum_{k=0}^j e^k,\quad \kappa_j=(e^2G_j)^\ell,
\quad\alpha_j=(s\kappa_j)^{1/n}.
\]
原正支必有m_A>κ_j m_w。j=1时κ_1=K²(1+e)^ℓ。终端的实际代数和原父始终保留，不改生成核；不把较强门当另一次随机转移。

## 4. 新的一般实际付款

对两条路径的终端(w,T_y)、(t,T_z)，定义
\[
\mathcal E=\{A\in\alpha_{T_y}Q_w\}\cup\{A\in\alpha_{T_z}Q_t\}.
\]
只扩张几何测试盒；不改真实cube及其质量。令
\[
P428=\Pi427(\mathcal E),\quad R428=\Pi427(\mathcal E^c),\quad R427=P428+R428.
\]
对于固定一端和j，保留事件及m_A>κ_jm_w，其他未来门正删除。另一条原生成路径总概率≤1，其来源π_A积分亦≤1；不是把其终端law换成独立保留law。原stage帽S一次和(1)给
\[
P_{y,j}\le\frac{Sa_j}{h}\int f(y)dy\int_{low}\rho_y(dw)
\int_{\substack{m_A>\kappa_jm_w\\A\in\alpha_jQ_w}}
\frac{q_Ac_A(y)}{m_A}\,dA.
\]
内层是真实父中心积分，利用实际m_w=q_wR_w^n：
\[
\int\frac{q_Ac_A(y)}{m_A}1_{\{m_A>\kappa_jm_w,A\in\alpha_jQ_w\}}dA
\le\frac{\lambda}{\kappa_jm_w}|\alpha_jQ_w|
=\frac{\lambda\alpha_j^n}{\kappa_jq_w}\le r s.
\]
这是来源完整匹配后的中心体积消去，不是薄层体积控制f。故
\[
P_{y,j}\le Sr s(1+\varepsilon_0)a_j W.
\]
同端各j事件互斥；两端交集实际只删除一次，求上界可用union bound。因此
\[
\boxed{P428\le\Omega428 W,\qquad
\Omega428=2Sr s(1+\varepsilon_0)\Theta(\varepsilon_0A_n/s).}\tag{3}
\]
固定S,r,ε_0时Ω428=O(√n log(n+2))。无阶段数、路径最大深度或额外τ^{-1}；S已含原两父端，式(3)的2仅为两条来源路径。

证明可以直接对Π425的该事件上放，并未使用R427裁剪的全部强度；现仍在Π427上正分拆，**不退还**R427已经支付的X价。与只取j=1的分支不同，(3)覆盖所有原代数。未证明每个输入上的该分支非零，也未证明它占固定比例。

## 5. 完整总账

设置C428=C427，V428=V425+Ω428。保持Fhat=(1−32δ−16η)^−1与Λ=128/119，
\[
G_0\le16\widehat F\{R428+C427X_q+(V425+\Omega428)W\},
\]
\[
B_H\le32\widehat F R428+(E387+32\widehat F C427)X_q
 +(S390+8s+32\widehat F(V425+\Omega428))W,
\]
\[
\mathrm{入口}\le\Lambda\{8\lambda HW+2d_{\rm eff}A_{{\rm entrance},n}W_\nu/H
+64\widehat F R428+(2E387+64\widehat F C427)X_q
+(2S390+16s+64\widehat F(V425+\Omega428))W\}.
\]
新增入口来源价64ΛFhatΩ428W，X槽不变；原初始、跳跃、低pe、极端尺度比、全尺度与清空极限均不由本分支代替。总吸收未认证。

## 6. 剩余对象与辅助路线结论

R428仍有所有原历史和R427终端互分离条件，另有
\[
A\notin\alpha_{T_y}Q_w,\qquad A\notin\alpha_{T_z}Q_t.
\]
质量比可以远大于代际最小κ_j，故不能由这些条件断言补集为空。剩余全来源—共同父—双终端积分仍缺一般根阶预算；下一步需利用上述真实双远位移，而非继续把父占用单列取最大值。

辅助稿核验了终端Schur两侧测度和low→high通量。标准Schur仍保原进入权a；真正通量差使用a/B，而不是a。原历史标记仅在low终端有原意义，高端零延拓令Dirichlet能量退化为正流，因而未提供另一份可用信用。这些仅定位未采用的桥，不另列付款。

## 7. 验证范围

父脚本实际运行36个严格秩原子链（三阶段各12），456个active起点，23963项终端密度检查；以及108个OR/16–32–64Λ总账配置。原子链使用有理K，证明(1)依赖上述一般解析推导，不能以有限模型替代原生历史。几何作者与辅助的独立本机检查及实际输出、独审见附件。保留LaTeX源，不编译PDF；实际模型扣额数据不可用，不猜测费用比例。
