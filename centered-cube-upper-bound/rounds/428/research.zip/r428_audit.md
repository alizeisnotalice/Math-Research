# R428 independent audit — FINAL PASS (bounded scope)

FINAL PASS for the all-generation actual parent-center/terminal event payment, its unchanged-X/increased-W mother account, and the stated auxiliary scope. The general remainder and total absorption balance remain unproved; no full-history numerical fixture is certified. Only this audit file was edited.

Sections 1–4 record the initial independent terminal-column screen, which by itself supplies no payment. Sections 5–6 record independent pre-author derivations of the new event and its all-generation extension. Section 7 gives the completed post-author review and final bindings.

## 1. Kernel and active-source quantifiers

Freeze the original full matched field. Write H for the measurable set of sources having positive active input support, e.g. H={x:∫ρ_x(dv)1_{Z_v(x)>h}>0}; actual active initial tickets are supported there up to the relevant null sets. Define B_x={v:Z_v(x)≤h}, b_x=ρ_x(B_x). On H, R427 proves h≤b_x≤(1+ε_0)h. Set U_x=1_{B_x}ρ_x/b_x on H and set U_x=0 off H. Then U is a measurable subprobability kernel with total 1_H. Measurability follows by parameter-dependent Tonelli: captures, masses and strict/closed rank predicates are measurable, so b_x and the positive denominator restriction are measurable. No probability is defined by dividing by b_x=0. One may separately extend U off H, but the column estimate below is for this zero extension; an arbitrary probability extension has no such automatic bound.

For any measurable nonnegative center test g,

    ∫ f(x) U_x(g) dx
    = ∫ [1/m_w ∫ f(x)c_w(x)1_H(x)1_{Z_w(x)≤h}/b_x dx] g(w)dw
    ≤ (1/h)∫ g(w)dw.

The bracket is the exact column density k(w), and matching f(Q_w)=m_w gives k(w)≤1/h. No λ, q, or source-density cap appears. The total identities/bounds are

    ∫ f(x)U_x(E)dx = ∫_H f ≤ W,
    ∫_H f ≤ |E|/h.

The second is a consequence on the active-source mass, not a bound on the original nonnormalized active traffic entering these sources. If H has zero f mass all such tickets vanish. Own-low inclusion remains a SOURCE-dependent predicate; the U_x are not one common source-independent probability.

A stronger exact weighted version, valid for every measurable a(x)≥0, is

    ∫ f(x)a(x)U_x(dw)dx
    = dw/m_w ∫ f(x)a(x)c_w(x)1_H1_{Z_w≤h}/b_x dx
    ≤ dw/(h m_w) ∫_{Q_w} f(x)a(x)dx.

Only if a is uniformly bounded can it be replaced by that bound. This is the correct place to retain any initial source-rank or parent likelihood.

## 2. One- and two-sided tests that really follow

For 1≤p<∞, Jensen (with the zero extension) and the column bound imply

    ∫ f(x)|U_xg|^p dx ≤ h^(-1)∫|g(w)|^p dw.

For two INDEPENDENT full-f source integrations, Tonelli gives

    ∫ f(y)f(z) U_y(dw)U_z(dt)dy dz ≤ dw dt/h².

Thus a nonnegative terminal test integrated against that exact product-source measure has this two-sided column price. A correlated source measure, a same-source diagonal, or a parent-posterior mixture is not the product f(y)dy f(z)dz. The tensor inequality may only be used after keeping its genuine source density: for any H(y,z)≥0 the exact output is ∫ff H(y,z)U_yU_z, and H cannot be suppressed unless a valid domination is proved. There is no source independence hidden in the original full matching.

## 3. Original R427 tickets: remaining parent weight

Let Λ_0(dr) be the ORIGINAL nonnormalized active initial-ticket measure, as in R427. For fixed r=(A,y,z,other original labels), the retained conditional terminal measure V_r is ≤U_y⊗U_z after the paid excess-density mark. Hence for each nonnegative terminal test F,

    ∫Λ_0(dr)V_r(F) ≤ ∫Λ_0(dr)(U_y⊗U_z)(F).

This is a legitimate positive upper comparison, preserving the initial weight. It is not a replacement of Λ_0 by f⊗f or by a probability source measure. In the history-free common-stage enlargement, the available bound is Sσ(dA)π_A(dy)π_A(dz), not S f(y)f(z)dy dz. Therefore define

    L_A(dw)=∫π_A(dx)U_x(dw)
           = dw/(m_A m_w)∫ f(x)c_A(x)c_w(x)1_H1_{Z_w≤h}/b_x dx.

The strongest immediate joint majorant is

    S ∫σ(dA) L_A(dw)L_A(dt),

with total at most S X_q. Its valid one-sided column is

    S∫σ(dA)L_A(dw)
    = S dw/m_w ∫ f(x)c_w(x)1_H1_{Z_w≤h}J_q(x)/b_x dx,
    J_q(x)=∫ q_A c_A(x)dA/m_A ≤ λJ(x).

Consequently it is bounded by Sλ J_max dw/h in the original octave field, while its total is also bounded by SX_q. The factor J_q cannot be dropped merely because w is own-low: own-low bounds mass-prefix rank at m_w, not the full rank J(x). If the actual retained labels imply m_A>K²m_w or w∉Q_A, keep those restrictions inside the A integral; do not independently transfer their history qualification to a U-generated ticket.

For the two-sided majorant, a safe relaxation retaining parent matching is

    S/h² ∫ q_A dA [I_Aw I_At/(m_A²m_wm_t)] dw dt,

where I_Aw=f(Q_A∩Q_w). This is the same actual shared-parent structure that remains in R427; it has not become a product of two independently paid source columns. Equivalently the source-pair kernel is f(y)f(z)∫q_A c_A(y)c_A(z)dA/m_A², with all additional retained labels still potentially present. One must prove a cross-parent estimate for this object, or a sharper actual marked version, before declaring a W payment. R413's unnormalized a_i/s_i≤1/τ bound does not by itself bound this whole parent/path/source likelihood after conditioning.

## 4. Exact local computation and present conclusion

Actually ran nine Fraction configurations of a matched nested-incidence model (N=8,12,16 and h=1,2,3), with positive masses 2^j, source increments matching each prefix mass, center volumes m_j h/4, strict K=2 mass past, and zero extension outside active sources. All exact full-f column inequalities, total identities and all terminal-pair product column inequalities passed; 99 columns were positive. These are bounded algebra/measure checks, not a native center/octave/history realization, and are excluded from parent/author totals.

The analytic full-f column and product-source tensor bounds pass. The actual once-only comparison keeps Λ_0 and the shared parent posterior, and hence currently gives an X_q total bound plus weighted column formulas, not the requested root-order W budget. Neither R427's paid A/B branches nor their X slots may be charged again. At that initial PRE stage no formal-account change was approved. The subsequent geometric event has an additional parent-center integral, reviewed independently in §§5–6 and finalized in §7.


## 5. Independent new parent-center payment screen

The new proposition PASSES independently, unlike the unweighted column inference in §§1–3. It uses a specific PARENT-center event to integrate away the parent weight, rather than suppressing that weight. This screen precedes the new author proof.

For any positive κ for which the actual retained ticket satisfies m_A>κm_w, define E_w={A∈αQ_w}. R427 gives, for each fixed original initial ticket r=(A,y,z,initial nodes,labels), retained conditional terminal submeasure V_r≤U_y⊗U_z. Since U_y,U_z depend only on the original source and frozen field (not the parent or initial nodes), summing the ORIGINAL unnormalized active initial records and common stages gives the valid upper envelope

    S∫σ(dA)π_A(dy)π_A(dz) U_y(dw)U_z(dt).

This enlarges the retained measure only for an upper bound; it does not reassign historical qualification. One may keep E_w and m_A>κm_w. Integrating z,t costs at most one, so the directed event is bounded by

    S∫ f(y)dy ∫U_y(dw)
       ∫ [q_A c_A(y)/m_A]1_{A∈αQ_w}1_{m_A>κm_w}dA.

For each fixed y,w, the last integral is at most

    λ |αQ_w|/(κm_w) = λ α^n/(κq_w)
    ≤ (λ/q_-)α^n/κ.

This is actual center Lebesgue volume, with m_w=q_wR_w^n; it uses neither a source-density cap nor the pointwise full-f column dw/h. Its integral against f(y)U_y(dw) is at most W because U_y has mass at most one. Hence

    P_directed ≤ S(λ/q_-)α^n W/κ,
    P_OR ≤ 2S(λ/q_-)α^n W/κ.

The factor two is only the OR of the two terminal directions; S already combines the two old endpoints/stage capacities. The original auxiliary active probabilities/initial weights were retained until the common-stage enlargement, not normalized away. No extra τ or second S appears.

### Exact terminal gap from the existing R425 soft mark

Let ℓ=logK=√n and r_v=log(m_A/(Km_v)). On the positive final R425 B remainder,

    e∑_{all nodes of both chains} exp(−r_v/ℓ)<1,
    equivalently e²∑(m_v/m_A)^(1/ℓ)<1.

Every terminal has a predecessor: the original initial node is active, so even immediate own-low stopping occurs after one genuine transition. Both predecessor and terminal are counted once, with no terminal padding. Strict K descent gives m_pre>K m_term, and therefore

    (m_pre/m_A)^(1/ℓ)+(m_term/m_A)^(1/ℓ)
    >(e+1)(m_term/m_A)^(1/ℓ).

Consequently for EACH terminal,

    m_A>κ_*m_term,
    κ_*=[e²(1+e)]^ℓ=K²(1+e)^√n.

This is a derived retained-ticket inequality, not a change of the original K transition kernel or its denominator. Positive descendants of Π425, including R427, inherit it. No initial inactive Dirac path may be included in this argument.

Choose α^n=sκ_*, s=1+√n. The exact two-direction price becomes

    P_parent-center ≤ Ω428 W,   Ω428=2S(λ/q_-)s.

There is no new X price for this proposed positive event. It is different from R427's terminal-mutual-center event and from the old condition that terminal centers lie outside Q_A: A∈αQ_w is the reverse incidence with an expanded terminal box. It is not automatically supported for every input and no fixed removed fraction is asserted. Its complement would keep both parent centers outside the corresponding expanded terminal boxes together with all existing actual labels. The general remaining source budget is still open.

Executed 36 temporary exact Fraction configurations verifying the parent-center volume/mass-gate bound and its integral against finite normalized source-terminal laws; all passed. These are envelope/probability algebra checks, not native matched geometry or complete-history fixtures, and are excluded from the author/parent totals. This was the static candidate screen, subsequently incorporated as one term of the all-generation event rather than charged separately.


## 6. Independent all-path-length extension

The stronger extension also PASSES independently. Let j≥1 be the number of actual transitions from an active initial node to its terminal. No terminal padding is allowed. For a fixed active node v, put z=Z_v(x) and restrict ρ_x to its actual strict prefix m_u<m_v/K, of total z. For u in that prefix, Z_u(x) is bounded by its left mass-CDF within the same prefix. Integrating that left CDF yields at most z²/2 (exactly (z²−Σmass-atom-weights²)/2); therefore E_v Z_next≤z/2. This keeps whole atoms. Kill the process when own-low is reached; dropping its nonnegative future rank only improves this expectation.

Consequently, with J_max=A_n/q_-, the active survival before transition j is at most

    a_j=min(1,J_max/(h 2^(j−1))).

For its exact-j terminal density, integrate the actual surviving previous-state subprobability and use its denominator Z>h. This gives H_{x,j}(v,db)≤a_j 1_low(b)ρ_x(db)/h. This is a survival probability bound, not an integral of ρ/Z over all possible states. All j are uniformly finite in the actual positive finite mass range; extension of the sum by zero or by the positive infinite majorant is safe. For R=J_max/h,

    Σ_{j≥1}a_j≤ceil(log_2^+ R)+2,

including R≤1; active flow is actually absent when the global bound is ≤h.

The original B soft mark on a retained path of j transitions counts all j+1 nodes. Strict mass descent implies

    Σ_{i=0}^j(m_{v_i}/m_A)^(1/ℓ)
    >(m_terminal/m_A)^(1/ℓ)Σ_{k=0}^j e^k.

Thus the retained terminal obeys

    m_A>κ_jm_terminal,
    κ_j=[e²Σ_{k=0}^j e^k]^ℓ.

This condition may be retained while the rest of the B filter is dropped for an upper bound. It does not replace the original transition denominator or regenerate a κ_j-descending path.

Define α_j^n=sκ_j and the actual positive event in either direction using that terminal's own realized j. For a directed event, bound its original generation measure by H_{y,j} and integrate the entire OTHER original generated path, whose total is at most one, before any future conditioning. Therefore only one (1+ε_0) factor is needed: ∫f(y)ρ_y(low)/h≤(1+ε_0)W. The same stage S envelope remains valid with j retained since Σb_i(z)≤1 and the original old-source cap is pointwise. Parent-center integration from §5 costs S(λ/q_-)s for each j, so the two-direction union has price

    Ω_all=2S(λ/q_-)s(1+ε_0)Σ_{j≥1}a_j,

or its explicit logarithmic majorant. A two-sided ρ/h bound is valid but would unnecessarily square (1+ε_0). Alternatively the paid R427 clipped joint has the same single marginal upper bound; it need not be renormalized or recomputed. The generation argument does not require R427's B payment, yet no already-paid B fee is refunded. The path-length union replaces the short-chain/geometric proposal if adopted; it is not an additional independent charge for that same short branch.

Actual local Fraction execution checked 63 nonzero atomic rank-contraction rows and 1647 active-survival/exact-generation terminal-density steps. All passed. These are finite mass-axis diagnostics with diagnostic K=2, not native center or original history realizations. They are reviewer execution only, not parent/author totals. This completed the independent all-generation screen; final author/main bytes were then reviewed below.


## 7. Completed post-author review and actual account

Read the full final main, README, geometry, auxiliary and all three scripts. The geometry proof includes the left-CDF argument for every θ>0; its θ=1 specialization gives the required active survival and exact-j terminal density. Atom endpoints are retained, zero ranks never become transition denominators, and each actual terminal is counted once. Path length j is separate from deletion stage i. The actual finite mass range bounds every path length, while countable stage/generation upper sums are legitimate by Tonelli and the unchanged Σ_i b_i≤1. The new κ_j support comes from the retained original R425 soft mark; it never modifies the actual K transition law.

The actual event is the OR of A∈α_{T_y}Q_w and A∈α_{T_z}Q_t on the original Π427. For a directed event the other complete original generated path is integrated to at most one BEFORE any retained-law conditioning; the uniform exact-j bound then removes dependence on the initial node, and the original stage sourcewise cap is used once. The actual parent integral is q_Ac_A(x)/m_A, not a normalized parent probability or an unweighted center surrogate. Its mass gate and volume give rα_j^n/κ_j=rs; full source integration costs only b(x)/h≤1+ε_0 and W. Thus there is exactly one (1+ε_0), one stage factor S, and one final OR factor 2.

The approved exact price and account are

    M=ε_0A_n/s,
    Θ(M)=Σ_{j≥1}min(1,M2^{-(j−1)}),
    Θ(M)=2M for M≤1,
    Θ(M)=L+2M2^(-L), L=ceil(log_2 M), for M>1,
    Ω428=2Sr s(1+ε_0)Θ(M),
    R427=P428+R428,  P428≤Ω428 W,
    C428=C427,  V428=V425+Ω428.

For M≤1 there are in fact no active starting tickets, so the positive upper expression is safe. Θ≤ceil(log_2^+M)+2, A_n≤s² and fixed S,r,ε_0 give the stated O(s log(n+2)) source price. The static §5 one-generation candidate is not separately added. R427's actual A/B X payments remain in C427, even though the new upper bound may drop their positive filters; no old fee is refunded or recharged. No new X price or feedback multiplier is introduced.

The inherited G0/BH/entry residual coefficients remain 16Fhat, 32Fhat, 64ΛFhat. The W slot alone increases by Ω428, and its entry increment is exactly 64ΛFhatΩ428W. Old exterior/source/clock/atom slots stay unchanged. The displayed geometry entry formula has the required plus sign before 64FhatR428 in the bound final bytes. No global absorption or new source-stage qualification is inferred. The final remainder is the same original positive measure with the two parent-center incidences removed, not a newly generated process.

The auxiliary proofs correctly distinguish dw from σ, f dx from weighted entering source mass, and T from its adjoint. Its norm bound and conservation retain a(x); the spatial low–high identity uses a/B. The signed covariance estimate and its Cauchy–Schwarz factor are valid. Zero extension of an otherwise undefined high-source history mark makes the energy tautologically equal to the positive flow; neither that analysis nor R426's temporal normalized kernel creates a second payment. Its formal no-payment statement concerns this auxiliary route and does not contradict the main new geometric receipt.

### Isolated actual execution and evidence scope

Copied all final scripts into a fresh temporary directory and actually reran them. Current source scripts, all three stdout files and the auxiliary JSON are byte-identical to the isolated reproduction. No author file/output was modified. The final parent script uses the correct piecewise Θ for its account tests; its rational M is an account parameter, not a native A_n assertion.

- Parent: 108 exact OR/account configurations; 36 atomic strict-rank models, 456 active starts and 23963 generation-terminal density assertions. These are finite rational-K chain/ledger checks, not native matched history fixtures.
- Geometry: 9 nonuniform full-f continuous parent-center integrals; 12 finite joint/reference models with measured finite parent constants; 3 positive-volume native center-block geometry certificates. The latter use rational selected side lengths, while Decimal only chooses candidates and rational Taylor bounds certify the e inequalities. They show compatibility of actual matching, geometric and soft gates, not own-high/stage/D/heavy-source/history or positive R427 ticket mass. The fixed child in the 1D inner-integral checks is not claimed to carry positive original terminal flow.
- Auxiliary: 12 finite matched incidence/rank models, 60 norm checks and 12 flux checks. Their matched discrete masses are not a native Lebesgue/octave/history realization.

The independent temporary computations in §§4–6 are reviewer checks only and excluded from those totals. General assertions rely on the analytic proofs and the explicit inherited contracts, not test counts. The complete main and README accurately state these limits and the still-unpaid general double-far source/parent/terminal remainder. Within this bounded scope no required correction remains.

## 8. SHA-256 final byte bindings

- `r428_main.md`: `6284c12c14dd526c8f08e0a08a792d27e7fa1a0d5add299255f80368996793ab`
- `r428_readme.md`: `e6d9bf58d84df9aca1093834521153f68e8522098d204ecb95626328e2029df4`
- `r428_geometry.md`: `b4a23365625c87b27b7d6af07d0e9afd9ae75d123305d344ec1ebca0011bd3f4`
- `r428_aux.md`: `4550673333490db12389b3686561712a38fab0950e9aa17ed5ece2fce122e212`
- `r428_parent_check.py`: `3f4e67ec1fd0fc9486c6fb92c0b76d6f49ce6be18b5f2c7368f612bfe5d3d7da`
- `r428_aux_check.py`: `1e277d22851be390fc3b42e6cbdef57390f488ca5b0c1abb3802c17f77875d69`
- `r428_geometry_check.py`: `02b1aebe7768f856844463168b82fd6559cf9c7c213654c47e43683b62118b8f`
- `r428_parent.result.txt`: `2d299ab4f95595d6931d45a356272bf866f9528850de3ccbfd5a05d847d6fa51`
- `r428_aux.result.txt`: `21201ea3485b31519a0a235051f82620d4c23e706567c466fcb318d953eea637`
- `r428_geometry.result.txt`: `269383d0b45fb1ac4142ef34d5ea2079f06e66c928f31514dcfc4b09d60d0304`
- `r428_aux_result.json`: `20d593e9e647b948ee71bfb2c2eb99836c6a03e090a4e13b09eabd38c3d46c61`

These bindings cover the reviewed final bytes. Any substantive proof/scope/code change requires corresponding re-audit; archive assembly is outside this audit. FINAL PASS; bounded task complete.
