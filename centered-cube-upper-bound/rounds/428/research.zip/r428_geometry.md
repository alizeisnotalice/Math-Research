# R428：按实际终端代数求和的父中心—终端接近分支

2026-10-20。本附件证明原 R427 上一项新的、覆盖全部终端代数的根阶乘对数 \(W\) 付款。没有证明整个余项闭合，没有删去原来源、阶段、历史或路径标签。静态单代数估计是统一证明的一部分，不单独再收费。

## 1. 冻结对象与主结论

沿用 R425、R427 的同一完整 \(f\)、实际 Lebesgue 接收中心及边长选择器：
\[
m_v=f(Q_v)=q_vR_v^n,\quad q=q_-\le q_v\le\lambda,\quad
a\le R_v\le b\le2a.
\]
记
\[
\mu(dv)=dv/m_v,\quad \sigma(dA)=q_A\,dA,\quad
\pi_A(dx)=f(x)1_{Q_A}(x)dx/m_A,\quad
\rho_x(dv)=1_{Q_v}(x)\mu(dv).
\]
\[
W=\int f,\quad X_q=\int\sigma,\quad
A_n=1+n\log(b/a),\quad J_{\max}=A_n/q,\quad r=\lambda/q.
\]
这里 \(A_n\) 是占用包络，和旧入口常数 \(A_{{\rm entrance},n}\) 不混用。参数仍为
\[
n\ge9,\quad \ell=\sqrt n,\quad K=e^\ell,\quad
s=1+\sqrt n,\quad h=\frac{s}{\varepsilon _0q},\quad
0<\varepsilon _0\le\tfrac12,\quad S=\beta+C_{\rm col}.
\]
\(S\) 已含原两父端的逐来源容量；下文另一个系数 2 只来自两条保源路径。

令 \(\Pi427\) 为 R427 最终实际正测度，其总量为 \(R427\)。它保留 R425 两软权、R423 联合路径、全部原 \(\Gamma_i,b_i,D_i\)、首次删除、旧新来源和空间门，并保留 R427 的终端互中心事件补集及实际终端容量裁剪。每条路径从 active 初始节点 \(v_0\) 出发，在固定来源 \(x\) 下按
\[
P_x(v,du)=\frac{1_{\{m_u<m_v/K\}}\rho_x(du)}{Z_v(x)},\qquad
Z_v(x)=\rho_x\{u:m_u<m_v/K\},
\tag{1}
\]
运行到首次 \(Z\le h\)。初始节点满足 \(Z_{v_0}(x)>h\)，故终端代数 \(j\ge1\)；终端不重复计数。有限 octave 质量范围保证路径有限，但我们不按最坏长度逐层收费。

定义对每个整数 \(j\ge1\)
\[
\kappa_j=\left(e^2\sum_{r'=0}^{j}e^{r'}\right)^\ell,\qquad
\alpha_j=(s\kappa_j)^{1/n},\qquad
a_j=\min\left(1,\frac{J_{\max}}{h\,2^{j-1}}\right).
\tag{2}
\]
在每条实际票据上使用其自身的终端代数 \(j_y,j_z\) 和终端 \(w,t\)，不重新选择停止时刻。取正事件
\[
\mathcal N=
\{A\in\alpha_{j_y}Q_w\}\ \cup\
\{A\in\alpha_{j_z}Q_t\}.
\tag{3}
\]
这表示**父中心落在终端立方体的扩大中**；既不是终端中心落在父立方体内，也不是终端彼此接近。

令
\[
P428=\Pi427(\mathcal N),\qquad
\Pi428=1_{\mathcal N^c}\Pi427,\qquad R428=\Pi428(1).
\]
则有精确正分拆及统一来源价
\[
R427=P428+R428,\qquad
\boxed{\ P428\le\Omega428\,W,\quad
\Omega428=2Sr\,s(1+\varepsilon _0)\sum_{j\ge1}a_j.\ }
\tag{4}
\]
且
\[
\sum_{j\ge1}a_j
\le 2+\left\lceil\log_{2,+}\frac{J_{\max}}h\right\rceil.
\tag{5}
\]
由于 \(J_{\max}/h=\varepsilon _0 A_n/s\) 且 \(A_n\le s^2\)，这在所示原参数固定时为 \(O(Sr\,s\log(n+2))\)。没有新增 \(X_q\) 价。没有声称此分支占原费用的固定比例。

## 2. 原子也成立的秩下降与逐代终端密度

固定来源 \(x\) 及 active 节点 \(v\)，置 \(z=Z_v(x)>h\)。在有限测度
\[
\nu=1_{\{m_u<m_v/K\}}\rho_x,\qquad \nu(E)=z
\]
中按质量排序，记左 CDF \(F_-(m)=\nu\{u:m_u<m\}\)。对其支撑中的 \(u\)，
\[
Z_u(x)\le F_-(m_u).
\]
这是严格质量下降的集合包含；不需要给 \(u\) 任何原历史资格。对任意 \(\theta>0\)，原子版积分不等式为
\[
\int F_-(m_u)^\theta\,\nu(du)
\le\int_0^z t^\theta dt=\frac{z^{\theta+1}}{1+\theta}.
\]
每个质量原子的贡献等于其秩区间左端值乘原子质量，因单调性不大于该区间上的积分；连续部分是通常的 CDF 换元。因此
\[
\mathbb E[Z_{u}(x)^\theta\mid v]\le
\frac{Z_v(x)^\theta}{1+\theta}.
\tag{6}
\]
质量原子不切开，严格前缀不改为闭前缀。

停止后把 active 秩变量置零。删除下一步已经停止的非负项只会加强 (6)。取 \(\theta=1\)，从任意实际 active 初始记录出发，
\[
\mathbb E[Z_{v_k}(x)1_{\{v_k\ {\rm active}\}}]
\le 2^{-k}J_{\max}.
\]
所以第 \(j-1\) 步仍 active 的概率不大于 \(a_j\)。给定该 active 前驱，最后一步的终端次概率核满足
\[
1_{\{Z_w(x)\le h\}}P_x(v_{j-1},dw)
\le \frac{1_{\{Z_w(x)\le h\}}\rho_x(dw)}h.
\]
于是**恰于第 \(j\) 步终止**的原生成次概率律满足
\[
Q_{x,j}^{\rm term}(dw)
\le \frac{a_j}{h}1_{L_x}(w)\rho_x(dw),\qquad
L_x=\{w:Z_w(x)\le h\}.
\tag{7}
\]
此界对每个初始 active 记录一致，因此也适用于实际初始次概率的混合。没有初始 Dirac 项，因为初始 own-high 被保留。零秩节点只能为终端；不会除以零。

引用 R427 已证闭质量窗结论：在有 active 输入的来源上，
\[
h\le b(x):=\rho_x(L_x)\le(1+\varepsilon _0)h.
\tag{8}
\]
因此 \(U_x=1_{L_x}\rho_x/b(x)\) 是概率，且 (7) 也给
\(Q_{x,j}^{\rm term}\le(1+\varepsilon _0)a_jU_x\)。
本轮不重复收取 R427 的容量裁剪价；证明 (7) 使用其裁剪前的原生成法作为上界。

为核 (5)，令 \(A=J_{\max}/h\)。若 \(A\le1\)，级数等于 \(2A\le2\)，且实际 active 输入为空。若 \(A>1\)，置 \(m=\lceil\log_2A\rceil\)，前 \(m\) 项至多 \(m\)，其余几何尾至多 \(2A2^{-m}\le2\)。即得 (5)。这是全代数求和，不是把最长路径长度当免费守恒。

## 3. 原 R425 软权给出的实际终端质量间隔

在 \(\Pi427\) 的正支上，原 R425 权仍保证
\[
e^2\sum_{\text{两链全部节点 }v}
(m_v/m_A)^{1/\ell}<1.
\tag{9}
\]
若一条链在第 \(j\) 步终止于 \(w\)，严格每步 \(K\) 下降给
\[
m_{v_k}>K^{j-k}m_w\quad(0\le k<j).
\]
结合终端自身的项和 \(K^{1/\ell}=e\)，(9) 蕴含
\[
1>
e^2\sum_{k=0}^{j}(m_{v_k}/m_A)^{1/\ell}
\ge e^2(m_w/m_A)^{1/\ell}\sum_{r'=0}^{j}e^{r'},
\]
故
\[
\boxed{\quad m_A>\kappa_jm_w.\quad}
\tag{10}
\]
同式适用于另一条链。这只是原正软余支的支持性质，不额外扣费，不把路径的生成核 \(K\) 改为 \(\kappa_j\)。
特别 \(j=1\) 时 \(\kappa_1=[e^2(1+e)]^\ell>K^2\)。仅使用 \(K^2\) 来选择父—终端近域，可能得到与更强实际间隔不相容的较弱事件；这里使用 (10) 选择 \(\alpha_j\)。

## 4. 真正的联合抵消：父中心体积、终端匹配与一次来源质量

先证可复用的原生几何式。固定 \(x,w\)、任意 \(\kappa>1,\alpha\ge1\)，有
\[
\begin{aligned}
&\int_E\frac{q_A1_{Q_A}(x)}{m_A}
 1_{\{m_A>\kappa m_w,\ A\in\alpha Q_w\}}\,dA\\
&\qquad\le\frac{\lambda}{\kappa m_w}|\alpha Q_w|
=\frac{\lambda\alpha^n}{\kappa q_w}
\le r\,\frac{\alpha^n}{\kappa}.
\end{aligned}
\tag{11}
\]
中心域 \(\alpha Q_w\) 在实际 \(w\) 与其实际选定边长 \(R_w\) 下固定。实际父选择器可以任意变化；没有积分一个独立选定边长变量。使用的等式是完整匹配 \(m_w=q_wR_w^n\)，不是把边界体积当来源质量。式 (11) 对所有真实实际接收集的正限制成立。

现在固定其中一个来源端 \(x\)，以及其实际终端代数 \(j\)。事件 \(A\in\alpha_jQ_w\) 不依赖另一条路径的终端。为求上界，可删去所有非必要的未来正限制（包括 R427 裁剪因子），但保留 (10) 与该几何事件；再把另一条**未重新归一的原生成路径**积分至至多 1。原两链仅在完整初始记录下按生成法独立，已过滤的两链不被宣称独立。

对剩余这一链使用一致的 (7)。按原共同阶段合同对 \(i\) 求和：两父端 sourcewise 上界分别为 \(\beta,C_{\rm col}\)，且 \(\sum_i b_i\le1\)。若事件在旧来源端，先对新来源的 \(b_i\) 求和；若在新来源端，先积分旧来源再对 \(b_i\) 求和。两种情况都留下同一个 \(S\)，并可把另一父来源后验积分到 1。因此其精确费用的上界为
\[
\begin{aligned}
P_{x,j}
&\le\frac{S a_j}{h}\int_{\rm active}f(x)\,dx
 \int_{L_x}\rho_x(dw)
 \int_E\frac{q_A1_{Q_A}(x)}{m_A}
 1_{\{m_A>\kappa_jm_w,\ A\in\alpha_jQ_w\}}\,dA\\
&\le\frac{Sr a_j}{h}\frac{\alpha_j^n}{\kappa_j}
 \int_{\rm active}f(x)b(x)\,dx\\
&\le Sr(1+\varepsilon _0)a_j
 \frac{\alpha_j^n}{\kappa_j}W.
\end{aligned}
\tag{12}
\]
所有交换均是正积分 Tonelli。父权为 \(q_A/m_A\)，正好来自 \(\sigma(dA)\pi_A(dx)\)；未剩下另一个父来源质量分母。终端的 \(\rho_x\) 仍是实际 \(\mu(dw)\)，没有自动刷新成 \(\pi_w\)。

注意 (12) **仅含一个 \(1+\varepsilon _0\)**。另一链先积分到 1；若先用双终端粗支配再积分，会不必要地损失第二个因子。也没有用 \(\int fU_x(dw)dx\le dw/h\) 后去估 \(|E|\)：此处保留概率归一，最后正好只有一次 \(\int f\)。

对一般一列 \(\alpha_j\ge1\)，(12) 已给两来源总价
\[
2Sr(1+\varepsilon _0)
\sum_{j\ge1}a_j\frac{\alpha_j^n}{\kappa_j}\,W.
\tag{13}
\]
取 (2) 的 \(\alpha_j^n=s\kappa_j\)，即得 (4)。两个事件的交集在实际分拆中只删一次；证明用 union 上界，不是两次收实际费用。原实际某代数若不可能发生，其项为零；无限上界仍合法。

## 5. 原账与完整补集

保留 R427 的全部旧费用与反馈，设置
\[
C428=C427,\qquad V428=V425+\Omega428.
\]
这里不另加静态 \(j=1\) 的 \(2Sr\,sW\) 价，不退款或重收 R427 的任何正支。原母账变为
\[
G_0\le16\widehat F\{R428+C427X_q+V428W\},
\]
\[
B_H\le32\widehat F R428+(E387+32\widehat F C427)X_q
 +(S390+8s+32\widehat F V428)W,
\]
\[
\mathrm{入口}\le\Lambda\{8\lambda HW+
2d_{\rm eff}A_{{\rm entrance},n}W_\nu/H
+64\widehat F R428+(2E387+64\widehat F C427)X_q
 +(2S390+16s+64\widehat F V428)W\}.
\tag{14}
\]
\(\widehat F=(1-32\delta-16\eta)^{-1}\)、\(\Lambda=128/119\) 和全部旧参数不改。新增入口费恰为 \(64\Lambda\widehat F\Omega428W\)，无新增 \(X_q\)。

新余项为**原 \(\Pi427\) 的同一正限制**，并额外满足
\[
A\notin\alpha_{j_y}Q_w,\qquad
A\notin\alpha_{j_z}Q_t.
\tag{15}
\]
它仍有父外、终端互中心分离、所有初始历史、阶段、来源、两软权及 R427 原裁剪，且终端质量满足各自 (10)。原有门并未因此传给中途或终端接收者。此补集尚未得到一般根阶 \(W\) 预算；(4) 不保证其为空或被删除固定比例。

## 6. 本机验证与非空范围

作者实际运行 `/tmp/r428_geometry_check.py`，三个阶段均通过：

1. 9 个一维连续父中心积分，完整来源为均匀背景加非均匀正包。精确有理计算实际 \(m_w,m_A,q_w,q_A\) 和 (11)，积分严格为正。它们核原生中心与匹配抵消，不冒充本轮高维完整历史。
2. 12 个有限完整来源模型，质量严格由来源捕获求出，\(U_x\) 真归一。以有限模型**实际测得**的父常数核联合正限制、union 及一次 \(W\) 计价；不将离散父权称为 Lebesgue 几何容量。
3. 3 个正体积中心块几何证书，\(n=1024,2304,4096\)。完整 \(f=1_{[-4,4]^n}\)，所有所用实际立方体在其支撑内，故 \(m_v=R_v^n,q_v=1\)。中心块、边长及来源点用有理数；Decimal 只选候选边长，所有断言随后用 Fraction 与 \(e\) 的 Taylor 有理包围认证。每链为一条初始节点到终端的几何路径，即实际候选标签 \(j=1\)。认证严格每步质量下降、父与所有节点的间隔、R425 两软余权正性、双链低 affinity、终端父外及终端互中心分离，并有新事件 \(A\in\alpha_1Q_w\) 的严格正余量。选取更小正来源邻域仍保所有已核严格几何不等式，因此不是一个孤立零来源测度的点。

第 3 阶段只证明这些**完整匹配几何与本轮新事件相容**；没有认证 initial own-high、原 \(D_i\)/stage/heavy-source/history 或 R427 裁剪后的实际票据为正。因而不把它称为原全历史正余项实例。该范围限制不影响 (1)–(14) 的一般证明。

另实际复跑父脚本 `/tmp/r428_parent_check.py`：36 个严格质量前缀原子链模型，三阶段各 12，456 个 active 初始点、23963 个终端密度断言，验证秩期望减半、(7) 的逐代 RN 上界与级数价；另 108 个 exact union 和 16/32/64–\(\Lambda\) 账算术通过。原子链采用有理 \(K\) 与质量，是生成核的有限精确诊断，不是原生完整历史模型。任意实 \(\theta>0\)、任意原生维数和全部阶段的证明依据上文解析推导。

本轮成果是 (4) 的真实全代数正分支付款，来源总质量只计一次；没有将未付补集改名宣称闭合。
