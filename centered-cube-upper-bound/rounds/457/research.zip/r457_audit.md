# R457 最终独立审计

**FINAL PASS（仅限已列明的全路径排斥提升、费用比较及有限验证）。** 原一般根阶弱型上界与双父外联合余项的根阶源预算仍未证明；本报告不认证这些整体目标。没有待修数学阻断项。2026-10-21。

## 已核准的精确范围

1. **真实去 soft 合同。** 实读 R411 原显式 soft、R413 原逐阶段 `a_i^e<=B_e`/同源 `sum b_i<=1`、R433 sourcewise 证明。`Pi0=Pi/b` 的静态帽 `<=S sigma pi_A²` 是从原记录的 soft 外合同重新正上放得到，绝非从带 soft 不等式直接相除。原 exclusive 初始核和既有生成核仍为概率/子概率，新增路径未获得原 history。
2. **Ever-cross 使用总 successor Green。** 固定来源严格K降质量、有限深度；旧 R423 Green 包括终端、排除初始 Dirac，支配 `rho/max(h,Tclosed)`。初始 exclusive 排对侧，所有后继在原父 strict past 内，故曾捕对侧概率 `<=C_A/h`。原子与 `Z=h` 停止均保留，未拿 terminal-only 帽代替 occupation。
3. **单侧一次 soft。** 新条件 avoid 路径概率 `s_y>=b>0`，附加后原完整 record 边缘精确保留；相对 `Pi0 Q_y` 的路径 RN `b 1_avoid/s_y<=1`。Doob因子有限望远镜。新链不同于旧受 future 筛选的链，不刷新来源或旧记录，也不把旧 proper-near、质量 profile、未来条件移交新节点。
4. **双侧整体增强。** 先付 `b<zeta` 价 `S zeta X`，其余附加独立双 conditional-avoid 概率。相对 `Pi0 Q_y Q_z` 联合 RN `b/(s_y s_z)<=1/zeta`，相对带 soft 的 `Pi Q_y Q_z` 则是 `1/(s_y s_z)<=zeta^-2`；没有用一份 soft 冒充两份单位联合帽。对单边测试，另一条件路径积分1，剩 `b/s_y<=1`，故新终端任一返回父盒仍价 `2S/(qh)X`，不额外乘 `1/zeta`。完整比较为

\[
R\le R_{\rm barrier,out}+\Delta X,\qquad
\Delta=S\zeta+2S\varepsilon_0/(1+\sqrt n).
\]

这里 return 事件属于本轮新增辅助终端，旧路径 return 付款不退款。余项保原全部记录，并附两条全程分别捕本源、排对侧原来源的路径；终端 own-low、中心均父外。“排对侧来源”不等于两终端盒彼此不相交。
5. **接受权与联合核。** `a0` 是去 soft 原记录的真实静态 RN，`a_zeta=a0 1_{b>=zeta}`。对每个合法起点均匀的 raw terminal 帽与新增双链的给定 record 独立性，给 joint-kernel(1)；这不要求旧已筛路径独立。own-high 起点至少跳一次，`m_terminal<m_initial/K<m_A/K²`，无初始Dirac混入。积分旧起点后接受权仍为同一 `a_zeta`。展开 `q_A/m_A²=1/(m_A R_A^n)`、低秩标记及两交叉排斥因子均正确。所有积分非负，真实中心、完整 f 和正质量下界使粗上包络有限。`E[a_zeta]` 只是充分上界，没有已证根阶价格；不可删接受权并分解来源后继续声称保留原联合信息。

## 回代及适用界限

`S=0` 先零流。固定维度一致的原 S、eps0，给定局部额度 delta>0，`zeta=min(1/2,delta/(2S))` 且 `s>=4S eps0/delta` 时，新增 `Delta<=delta`。有限其余维数用 `R<=SX<=S A_n W`，常数可依 delta、S 与固定原参数；这不是全维原余项已经付款。

原母账若取 R 槽，G0/BH/入口的新增 X 系数分别为 `16 Fhat Delta`、`32 Fhat Delta`、`64 Lambda0 Fhat Delta`，分别在各自账式使用，不能三种系数累加或漏乘。其他旧槽不变；入口局部额度须先除以其槽倍率。本轮全局未付项仍是 `R_barrier,out<=tX+C_t s polylog(n+2)W`，未由新 RN 或有限实验推出。

历史范围只确认已指明旧工具及有界去重；不把 R411/R412/R423 重证算新增数学，不声明穷尽全部历史。

## 实际复现与有限证据

指定本机 Python `/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python`。独审隔离目录：

`/var/folders/lq/2c4qbz2n0354_tnttkv_qsz00000gn/T/r457_audit_isolated_c4zg75ah`。

- mainproof：258 Fraction 原子链断言，实际隔离重放，stdout逐字节一致。
- geometry：162 Fraction coupling cases（27/27/108），实际隔离重放，stdout逐字节一致。最终核其脚本字节未变，未重复运行。
- numeric：554 Fraction/256-bit Arb checks，一个真实full-capture n1字段家族的4个指定case；实际隔离重放，stdout及生成JSON均逐字节一致。

上述三个计数类型不同，不合称高维原历史样本。numeric完整f的5个来源packet、互不交接收中心块、真实边长1/2、完整mass(100,20,4,2,1)与qband[1,50]均核清；strict K=e由Arb认证。实际原父K与K² cutoff下的共同捕获量在此字段相同（唯一可达cross块为common），未把较窄cutoff当一般C定义。h自选，未满足原n1 high-h及全部阶段/未来合同；zero-soft case `C=h` 不属原strict支。四case的精确continuous lumping成立于整个中心块和来源packet，不只是中心点采样。条件Green可超过raw闭秩帽，必须保soft；双copy `132/125>1` 仅同一y-chain的两个概率复制，不是真实双来源几何反例。资源文件仅作者实际运行记录，不作为数学证据或独审测得资源。

独立PRE中的临时算术仅辅助审查，未纳入上述归档覆盖。未运行MATLAB、未写repo或作者文件、未新增代理/PDF。

## 最终字节绑定

以下为白名单全部15输入；审计自身不自绑定。先前PRE和阶段性记录保留在报告末尾，其中“尚待最终”的状态现由本节FINAL及本清单取代。

- `r457_main.md`: `7c70e586d4eca77ba8885de28ee4a7791cc4703fdfd699c281cddfa42a81e135`
- `r457_joint_kernel.md`: `ae311f753ec3d598eede149c43f0ca77dc28727186943920a3157be55c99f4c9`
- `r457_geometry.md`: `58694e022a0844a4836c0f94cb89dbde25ecf26c577a4d048391e07780ed53ab`
- `r457_geometry_check.py`: `d1b87744b7a3e2aead1049d4ab271e2075941248356e0027371bf3d78d2d0614`
- `r457_geometry.result.txt`: `670f52a9818a7c8e47611e0719174a956dafbc54afbcba077a3cf0824a2c404b`
- `r457_mainproof.md`: `89b9a38da58a10647e043b6c3e79a262545d101e74003ae6bb0c86a4bfda618a`
- `r457_mainproof_check.py`: `dc2795ebe589c0bd1e0d1ae537bddc8cc9c283643174c377fbdcc0a8baa61538`
- `r457_mainproof.result.txt`: `386346de10546585638f8d8e7dfc8fc21bc8a2343eef3580565bcac24ba98d33`
- `r457_numeric.md`: `23563d5c1289741cc5a29ef20c754f498f411b7e8632b1c261202790f68c7694`
- `r457_numeric.py`: `a3614faf633ab5f17606d7187a2a6283f606f714fdfd9ac42110724e187c1555`
- `r457_numeric_certificate.json`: `e73ad8551ae425fccf8fc68437912e5f34c508be6e53198db97747a7534874ba`
- `r457_numeric_run.txt`: `1a1eb0ab3f6106ac719d5c2778b32ddc3cd59d405e84ca036b1adb990dded549`
- `r457_numeric_resources.txt`: `5e5dd487eb82f569ec28eda973bc06b88f01f32afa9ff34c52607d3da8672126`
- `r457_numeric_compute_index.md`: `377c3aca1b08331ed365ca9f04ef1af337f2e94c6a67843551b25a3818b6aab0`
- `r457_history.md`: `3796254d8c08c41653d3fb3e4ed1af12a0811cd71c9e36e704216149dc60b5ad`

---

# 独立PRE与阶段性核验原记录

# R457 独立预审：ever-cross Green 界与一份 soft 的耦合合同

状态：PRE，仅独立命题筛查，非 FINAL；未阅读 R457 作者新证明。2026-10-21。

本次仅读取 `/tmp/r457_history.md`、旧 `/tmp/r412_aux.md`、`/tmp/r423_aux.md` 与 R411 双 exclusive 定义。没有修改作者文件、仓库或开设子代理。

## 1. 可成立的原单链命题

固定原父与来源对 `(A,y,z)`，原共同 strict-past 量为

\[
C=C_A(y,z)=\int 1_{m_u<m_A/K}c_u(y)c_u(z)\,\mu(du)<h,
\qquad b=1-C/h\in(0,1].
\]

初始 exclusive `w` 捕获 `y` 不捕获 `z`，反向初始 `v` 捕获 `z` 不捕获 `y`，且两者质量严格小于 `m_A/K`。以下每条固定来源链始终用原核

\[
P_x(a,du)=1_{m_u<m_a/K}\rho_x(du)/Z_a(x),\quad Z_a(x)>h,
\]

在 `Z<=h` 停止。质量统一上下界给有限统一深度。这里的 Green 必须是**所有后继 occupation，包括到达终端，不含初始 Dirac**，不能只引用总 terminal 帽。

对任意 active 起点，旧 R423 证明的强界为

\[
G_x(a,du)\le
1_{m_u<m_a/K}\frac{\rho_x(du)}{\max(h,T_x(m_u))}
\le \rho_x(du)/h.
\tag{P1}
\]

独立核查 `1/h` 的短证明：质量轴底部可取一个总质量恰 `h` 的子测度 `beta<=rho_x`，必要时只取 crossing 原子的一部分。它支持停止段，并由每个 active 下跳前缀完整支配；原子拆分仅为证明，不改变实际转移。令 `O` 是起点开始、仅 active 节点的 occupation，`c=∫O(da)/Z_a`。总终端律支配 `c beta`，终端总概率为1，故 `c<=1/h`。每个后继的密度是 `∫O(da)1_{m_u<m_a/K}/Z_a<=c`，得到 (P1) 的弱版本。原子、`Z=h` 停止和严格 mass cutoff 均保留；无 active 时没有此输入。

由首次命中计数不超过 occupation，且所有后继仍在原父 strict past，

\[
a_y:=\mathbb P_y^w\{\exists j\ge1:c_{V_j}(z)=1\}
\le G_y(w,\{c_u(z)=1,m_u<m_A/K\})\le C/h.
\tag{P2}
\]

另一链同样 `a_z<=C/h`。初始节点本身不 cross；即使把它纳入 ever-hit 定义也不增加事件。`C=0` 时两链 cross 概率均为0。若再有未来/history 正限制，只能先在原完整生成 law 下取界再正删除；不能在限制后归一化，宣称同一个 (P2) 仍是条件概率界。

## 2. 保完整路径边缘的共享坏事件耦合

对固定完整初始 record，记两条原**未过滤完整路径概率 law** 为 `P_y,P_z`；`G_y,G_z` 为不 cross 事件，`q_y=1-a_y>=b`、`q_z>=b`。

把两个 good/bad 旗标作同序（comonotone）耦合：

\[
\gamma(GG)=\min(q_y,q_z),\quad
\gamma(GB)=(q_y-q_z)_+,\quad
\gamma(BG)=(q_z-q_y)_+,\quad
\gamma(BB)=\min(a_y,a_z).
\tag{P3}
\]

在每个非零旗标块内使用各自原路径条件 law 的乘积。这是显式共同可测核；零块直接取零，不做除零。两条完整路径边缘精确为 `P_y,P_z`，所以

\[
\gamma\{\text{任一 cross}\}=\max(a_y,a_z)\le C/h,
\quad \gamma(GG)\ge b.
\tag{P4}
\]

此为合法的**新辅助 joint law**；它并非原独立 product 的正限制。单链原核/边缘保持，不等于原两链联合历史分布保持。

### 密度合同，不能略去

在 good-good 块，

\[
\frac{d\gamma_{GG}}{d(P_y\otimes P_z)}
=\frac{\min(q_y,q_z)}{q_yq_z}1_{GG}
=\frac{1}{\max(q_y,q_z)}1_{GG}\le b^{-1}1_{GG}.
\tag{P5}
\]

因此原一份 soft `b` 可给 `b gamma_GG <= P_y⊗P_z`。该加权 good 块的总量是 `b min(q_y,q_z)>=b²`，不是未经权重的 `b`。整个耦合则没有由 `b` 给出的统一 RN 帽：bad-bad 块密度为 `1/max(a_y,a_z)`（非零时），可远大于 `1/b`。

等价地，可直接取支持 GG 的子耦合

\[
\Gamma_b=\frac{b}{q_yq_z}1_{GG}(P_y\otimes P_z).
\tag{P6}
\]

它质量恰 `b`，两边缘分别为 `(b/q_y)P_y|G_y`、`(b/q_z)P_z|G_z`，均不超过原 law，并且 joint density `<=1/b`。它的边缘是**子边缘**，不是完整原概率边缘。剩余边缘可补成完整耦合，补入部分不再全 good。若把 (P6) 归一化成概率，其 joint density 最多 `1/b²`，两边缘变成条件 good law；不能仍称完整原路径边缘。

原独立 product 自身的 good-good 质量只保证 `q_yq_z>=b²`，没有 `>=b` 的结论；边界代数 `q_y=q_z=b` 已显示两者差别。此处仅说明必要费用方向，不作几何反例扫描。

## 3. 对原 Pi/history 可合法使用到哪一步

1. 原 static record/来源 `y,z`、旧边、stage、首次删除及原物理标记可以作为耦合旁带保留；辅助路径节点不得获得原历史资格。
2. 如果耦合在首次增加辅助路径标签时定义，且原被估费用仅依固定 record，则替换 joint law 的总质量确实不变。但所有已付 path-dependent 分支必须重新核算，不能假定旧独立 product 证明自动仍适用。
3. 对已经固定原 product lift 与全部未来门 `0<=F(record,path_y,path_z)<=1` 的 Pi，换成 (P3) 一般改变 `∫F`。保两条边缘不能保 joint F、joint terminal event 或原 signed cost。应显式给同一原 Pi 上的 RN 拉回，或给所需 joint domination，并在费用中保留其因子。
4. 仅 (P5) 可在 good-good 块用一份 `b` 抵消 `1/b` 的 joint 密度上放；不能把该抵消同时算成新的全量安全概率或再次取 negative credit。原票据若本已含 soft b，必须逐式说明其在参考测度与新耦合中出现的位置，不能写成 `b` 同时用于质量归一与密度消去。
5. 固定 record 的 (P2) 与 (P3) 均未产生跨父 `W` 列预算。真实 joint center/source 付款仍需完整 matching/Tonelli 合同；`C<h` 只给 record 内事件概率控制。

可审建设性下一步：作者若仅需要支持双不 cross 的子耦合，(P6) 已给显式最优可用合同；若需要保完整双路径 law 且控制原 Pi，应精确给出 joint RN/拉回及 path-dependent F 的费用比较。没有这些，不能从 (P4) 直接支付当前完整双父外余流。

## 4. 本机有限算术辅助

使用本机指定 Python 实际运行 Fraction 枚举：18 个严格质量轴模型，含重复质量原子、严格 cutoff 等号、不同停止阈值；30 个 active 起点。逐代 Green 与首次命中递推检查合计1110断言通过。另16组 good/bad 旗标耦合检查边缘、非负、GG密度与 (P6) 子边缘通过。

这些仅为审查辅助临时执行，未保存独立脚本、不纳入最终归档新增覆盖；一般结论由上述有限核证明支持。未模拟真实高维 cube/原历史，不以检查数认证原预算。

## 5. PRE 结论

- **PASS（准确命题）：** 单链 ever-hit 对侧来源 `<=C_A/h`，需要总 successor Green，原 atom/strictness 合法。
- **PASS（辅助耦合）：** 可以保两条完整单链边缘，使坏事件嵌套、union-cross `<=C_A/h`；good-good 子块有 `1/b` joint 密度帽。
- **尚需作者证明：** 原一份 soft 的完整联合费用比较、未来门/原 Pi 的同测度拉回，以及跨父源价。未提出这些已闭合，不给本轮最终 PASS。

完成此有界预审，等待作者实际命题/最终审任务；不扩展新路线。

## 6. 父代理后发的单侧推进：一次 soft 换独立新辅助链（独立筛查）

此节只核父代理准确命题，仍未读 R457 作者新稿。假设已在原测度上核实 `b=1-C_A/h>0` 且 `P0=Pi/b` 的 static projection `<=S beta`（`beta=σπ_A²`）；不能仅从 `Pi<=S beta` 推出该去 soft 合同。

固定原完整 record `r`（允许包含旧路径及旧 future 标记），保 exclusive 初始 `w`、来源 `y,z`。**另加一条新辅助链**，在给定 `r` 后按原未过滤 `Q_y^w` 生成，独立于旧 path 的后续随机量；原 record 不重抽样、不归一化。令

\[
s_w(r)=Q_y^w\{\text{全链不捕获旧 }z\}\ge b(r),\qquad
Q_r^{\rm avoid}=1_{\rm avoid}Q_y^w/s_w(r).
\]

这是概率核（`s_w>=b>0`），因此 `Pi(dr)Qavoid` 质量与原 Pi 精确相同，原 record 的全部边缘及原 history 保留。并有同测度正支配

\[
\boxed{\quad Pi(dr)Q_r^{\rm avoid}(d\omega)
\le P0(dr)Q_y^w(d\omega),\quad
\frac{d[Pi Q^{\rm avoid}]}{d[P0 Q]}=
\frac{b(r)}{s_w(r)}1_{\rm avoid}\le1.\quad}
\tag{P7}
\]

所以**单侧**可用原一份 soft 一次性换成全避 cross 的新链，无新的 `1/b` 列损失；此比把两条链都条件化更省。若两侧各自独立条件 avoid，所需倍率是 `b/(s_w s_v)`，只由 `s_w,s_v>=b` 不能证明它<=1；不能重复消去同一份 soft。

Doob 写法也精确：设 `H(a)` 为从状态 a 开始、包含当前节点的剩余安全概率。cross 状态 H=0，安全 terminal H=1；active 安全状态有 `H(a)=∫1_safe(u)Q_y(a,du)H(u)`。在 `H>0` 上转移为 `1_safe(u)H(u)Q/H(a)`，行和1；可达路径的因子望远镜为 `1/s_w`，终端 H=1。零 H 状态无需定义归一核。有限深度避免无限条件存活与可选停止的额外假设。

### 同一旧链与新增链必须区分

- 若确实另加上述新链，旧 future labels 可作为原旁带完全保留；reference `P0 Q` 的 Q 也必须是这一条给定 record 新生成的 Q。没有把旧 future 事件的条件分布冒充原 Q。
- 若要改造**原已有**路径，且 Pi 含依该路径的未来过滤，则其给定 record 条件 law 一般不是 Q。证明支配时可删除该正过滤并回到共同生成 measure；不能在筛过的起点 law 上免费恢复 Q，更不能声称原 path-dependent 联合费用保持精确。
- 新辅助链的安全性质只属于新链；原 terminal/旧节点、原以旧 terminal v 定义的 U 或容量需求没有被自动替换。若之后要用新末端替代旧末端，应另给原费用/目标比较；(P7) 本身只提供保旧 record 的安全分析扩展。
- (P7) 未支付跨父、来源对 `f(y)f(z)C2(y,z)` 或双父外全部余项，仍需真实联合中心容量估计。

结论：**单侧一次 soft 的新增辅助路径接口 PASS（以上明确假设与量词）**；不等同双侧完整费用闭合。等待作者把该接口用于原目标后的具体证明再后审。

## 7. 作者结果后审阶段的双 barrier 独立核查（尚非最终字节绑定）

已获准读取单侧 mainproof 与双侧 geometry；实际复读 R411 原 soft 定义、R413 §3b 原 `a_i^e<=B_e` 及 R433 原 static sourcewise 证明。去 soft 帽确可由原阶段合同重新正上放，不是非法除静态不等式。

双侧增强可成立，且不与§2–3警告冲突：先支付原 `b<zeta` 的整支，其价 `<=S zeta X`。在 `b>=zeta` 上给每个原完整 record **新增**两条独立的 conditional-avoid 辅助路径。原 record 边缘精确保留，联合相对 `Pi0 Q_y Q_z` 的 RN 为

\[
b1_{E_yE_z}/(s_y s_z)\le1/b\le1/\zeta.
\]

这一次 `1/zeta` 联合损失有明确预算，不能声称双侧都由一份 soft 免费消掉。相对已带 soft 的 `Pi Q_y Q_z` 的 RN 则为 `1/(s_y s_z)<=zeta^{-2}`，两种 reference 分清。

任意单侧路径测试可先积分另一条 conditional probability 为1，剩 RN `b/s_y<=1`。因此返回原父盒的 OR 事件先用单侧 union，再用原 terminal `rho/h` 与完整匹配消内分母，得

\[
P_{return}\le 2S|E|/h\le2S X/(qh),
\]

没有 `1/zeta`。它只用于本轮**新增**辅助终端，旧已付原终端 return 不退款、不重复解释为同一事件。故完整同流比较

\[
R\le [S\zeta+2S\varepsilon_0/s]X+R_{barrier,out}
\]

正确，余项保原全部 records，并附两条全程捕本源、排对侧原来源的新路径，own-low 终端均父外。附加路径不继承旧 proper-near、质量 profile 或 future 门；联合参考只有 `S/zeta` 帽，不是来源 W 价。

大维吸收：S=0为空；S>0时给定 delta>0，取 `zeta=min(1/2,delta/(2S))`，`s>=4S eps0/delta` 即本轮新增系数<=delta。有限小n用 `R<=SX<=S A_n W`，允许常数依delta,S、固定原参数；入口实际槽倍率须整乘，不能忽略 `64 Lambda0 Fhat`，也不宣称旧全部X系数已吸收。geometry最终已明确此点。

已隔离运行作者两个固定脚本（非新增数学覆盖）：mainproof258 Fraction与geometry162 coupling cases，stdout均逐字节等于各自冻结result。目录 `/var/folders/lq/2c4qbz2n0354_tnttkv_qsz00000gn/T/r457_audit_isolated_c4zg75ah`。脚本hash分别 `dc2795ebe589c0bd1e0d1ae537bddc8cc9c283643174c377fbdcc0a8baa61538`、`d1b87744b7a3e2aead1049d4ab271e2075941248356e0027371bf3d78d2d0614`。最终需对最终白名单核字节，尚未绑定rootmain/numeric或给FINAL。
