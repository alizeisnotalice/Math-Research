from fractions import Fraction as F
checks=0
models=[
 ('positive_cross', [F(1,5)]*4+[F(1,10),F(1,5),F(1,5),F(1,10)],F(1,2),{0,4}),
 ('zero_cross', [F(1,5)]*4+[F(1,10),F(1,5),F(1,5),F(1,10)],F(1,2),set()),
 ('atomic_threshold', [F(1,10),F(1,5),F(1,5),F(1,10),F(1,10),F(1,5),F(1,10),F(1,10)],F(1,2),{0,4}),
]
for name,a,h,cross in models:
 n=len(a);m=[2**j for j in range(n)];K=2
 C=sum(a[j] for j in cross)
 assert C<h;checks+=1
 P=[];G=[];good=[];terminal=[];avoid=[]
 for i in range(n):
  pred=[j for j in range(i) if K*m[j]<m[i]]
  Z=sum(a[j] for j in pred)
  row=[a[j]/Z if Z>h and j in pred else F(0) for j in range(n)]
  P.append(row)
  gi=[row[j]+sum(row[k]*G[k][j] for k in range(i)) for j in range(n)]
  G.append(gi)
  if Z<=h:
   ti=[F(int(i==j)) for j in range(n)]
   goodi=[F(0) if i in cross else x for x in ti]
  else:
   ti=[sum(row[k]*terminal[k][j] for k in range(i)) for j in range(n)]
   goodi=[F(0) if i in cross else sum(row[k]*good[k][j] for k in range(i)) for j in range(n)]
  terminal.append(ti);good.append(goodi);avoid.append(sum(goodi))
  assert sum(ti)==1;checks+=1
  if i not in cross:
   occ=sum(gi[j] for j in cross)
   hit=1-avoid[i]
   assert hit<=occ<=C/h;checks+=2
   b=1-C/h
   assert avoid[i]>=b>0;checks+=1
   for j in range(n):
    assert b*goodi[j]/avoid[i]<=ti[j];checks+=1
   if Z>h:
    assert sum(row[j]*avoid[j]/avoid[i] for j in range(i))==1;checks+=1
 print(name,'start_mass=',m[-1],'C/h=',C/h,'ever_cross=',1-avoid[-1],
       'cross_occupation=',sum(G[-1][j] for j in cross),'avoid=',avoid[-1])
 if name=='positive_cross':
  assert sum(G[-1][j] for j in cross)>1-avoid[-1];checks+=1
print('PASS',checks,'Fraction assertions.')
print('Scope: exact atomic fixed-source chain and cross-tag arithmetic; not a native cube or original-history realization.')
