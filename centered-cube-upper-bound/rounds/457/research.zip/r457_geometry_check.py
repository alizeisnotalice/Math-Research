from fractions import Fraction as F
import json
counts = {}
for name, cs in [('basic',[F(0),F(1,4),F(1,2)]),('boundary',[F(3,4),F(9,10),F(99,100)]),('expanded',[F(j,13) for j in range(1,13)])]:
    count=0
    for c in cs:
        b=1-c
        for rp in [F(0),F(1,3),F(1)]:
            for rq in [F(0),F(1,2),F(1)]:
                p,q=c*rp,c*rq
                a,d=1-p,1-q
                cells=[min(p,q),max(p-q,0),max(q-p,0),1-max(p,q)]
                assert sum(cells)==1 and min(cells)>=0
                assert cells[0]+cells[1]==p and cells[0]+cells[2]==q
                g=cells[3]
                assert g>=b and b*g/(a*d)<=1
                assert b/(a*d)<=1/b
                assert b/a<=1 and b/d<=1
                assert (b/(a*d))*a*d==b
                assert b*(g/(a*d))*a*d==b*g
                if p==c and q==c:
                    assert b/(a*d)==1/b
                # Whole-input single-side marginal keeps exactly one normalizer.
                for event_p in [F(0),a/2,a]:
                    assert b*event_p/a<=event_p
                count+=1
    counts[name]=count
print(json.dumps({'status':'PASS','cases':counts,'total':sum(counts.values()),'scope':'Fraction coupling and marginal identities only; not native/history fixtures'},sort_keys=True))
