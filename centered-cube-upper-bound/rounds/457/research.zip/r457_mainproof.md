# R457 — single-chain opposite-source barrier and one-use soft cancellation

## 1. Original records and the factor that can actually be removed

Let \(\Pi\) be the original \(\Pi_{433}\), its double-low-\(p\) restriction, or any subsequent positive restriction on the same complete record space. Keep the actual father \(A\), sources \(y,z\), initial old-side witness \(w_0\), all original stages, clocks and both old paths. Write
\[
 \rho_y(db)=c_b(y)\frac{db}{m_b},\quad
 Z_v(y)=\rho_y\{m_b<m_v/K\},\quad
 C=C_A(y,z)=\int_{m_b<m_A/K}c_b(z)\rho_y(db),
 \qquad b_*=(1-C/h)_+.
\]
On positive original records, \(C<h\); \(w_0\) captures \(y\), excludes \(z\), has \(Z_{w_0}(y)>h\), and \(m_A>K^2m_{w_0}\). The latter stronger mass gate is preserved; the estimates below only need \(m_{w_0}<m_A/K\).

The exact original soft factor is documented in r411_geometry.md, line 21: each original \(\Theta_i^e\) multiplies \((1-C_A/h)_+\) once. The cumulative bound uses r413_main.md, lines 81–97, and r433_main.md, lines 15–21: \(a_i^e\le B_e\), \(\sum_eB_e=S\), and \(\sum_i b_i(z)\le1\) at the same source \(z\). Initial witness kernels and unfiltered generation kernels are probabilities or subprobabilities; later retained weights are at most one.

Consequently, defining \(d\widehat\Pi=b_*^{-1}d\Pi\) on \(b_*>0\) and zero otherwise, the same positive upper-bound proof gives
\[
 (\widehat\Pi)_{A,y,z}
 \le S\,\sigma(dA)\pi_A(dy)\pi_A(dz).                            \tag{1}
\]
This removes exactly the displayed soft factor, not a density-stage \(b_i\). It does not condition or renormalize any old history.

## 2. A total-occupation barrier, not a terminal-only argument

Attach an auxiliary copy of the original unfiltered fixed-\(y\) chain
\[
 Q_y(v,db)=1_{\{Z_v(y)>h\}}\,
       \frac{1_{\{m_b<m_v/K\}}\rho_y(db)}{Z_v(y)}.
\]
It stops at \(Z_v(y)\le h\). Matching and the octave give positive finite mass bounds, so the number of jumps is uniformly finite. Original proper-near and future restrictions remain on the original record; they are not conditions on this fresh auxiliary chain.

Use the audited **total Green** theorem r423_aux.md, §1, (1)–(2), with \(T_y(m)=\rho_y\{m_b\le m\}\):
\[
 G_y(w_0,db)\le
 \frac{1_{\{m_b<m_{w_0}/K\}}\rho_y(db)}
      {\max(h,T_y(m_b))}.                                      \tag{2}
\]
It counts every proper successor, including the terminal, but not the initial Dirac. Strict mass atoms and equality \(Z=h\) are included in that theorem. Since the initial witness excludes \(z\), a union bound over all proper successors yields
\[
 \mathbb P_{w_0}^{y}\{\text{ever capture }z\}
 \le\int c_b(z)G_y(w_0,db)
 \le C/h.
\]
Thus, for the event \(\mathcal A\) that every auxiliary node excludes \(z\),
\[
 s_{w_0}:=\mathbb P_{w_0}^{y}(\mathcal A)\ge1-C/h=b_*>0.          \tag{3}
\]
The result has no path-length, \(J/h\), or logarithmic factor. A terminal density alone would not prove it; (2) is essential. Arbitrary positive path restrictions remain dominated without renormalization, but their conditional laws are not asserted to be \(Q_y\).

## 3. Full-mass exclusive path lift, with one denominator

For every original record \(r\), attach \(Q_y\) conditioned on \(\mathcal A\). The resulting measure
\[
 d\widetilde\Pi(r,\gamma)
 =d\Pi(r)\,\frac{1_{\mathcal A}(\gamma)}{s_{w_0}}\,dQ_y^{w_0}(\gamma)
\]
has marginal exactly \(\Pi\) on the original complete record. Moreover,
\[
 \frac{d\widetilde\Pi}{d(\widehat\Pi\otimes Q_y)}
 =\frac{b_*1_{\mathcal A}}{s_{w_0}}\le1.                         \tag{4}
\]
Therefore the single original soft factor pays the entire conditioning cost. No \(1/b_*\) cost is repeated at each generation.

Explicitly, define \(s(v)\) to be the raw probability of avoiding \(z\) until stopping, with value zero if \(c_v(z)=1\) and value one at an exclusive stopping state. On exclusive active states,
\[
 \widetilde Q(v,db)=Q_y(v,db)\frac{s(b)}{s(v)}.
\]
Finite backward recursion proves measurability and row mass one. Multiplication along a complete surviving path telescopes to \(1/s(w_0)\), since its terminal has \(s=1\). All new nodes are actual receivers with unchanged \(m_b,q_b,R_b\), but capture only \(y\), not \(z\); none is assigned the original father's history.

This is a full-mass **single-side** representation. The auxiliary nodes do not automatically satisfy the old proper-near exclusion, all-node father-distance gates, or terminal profile gates: those remain true only of the retained original paths. Any later use of such a gate on the new auxiliary path requires a separate argument. Independently conditioning both chains would generally introduce two denominators; the same \(b_*\) cannot be spent twice. No such double-chain assertion is made here.

## 4. Correct joint terminal measure and the remaining price

From (2), its terminal consequence, and (4), the auxiliary old-side terminal \(b\) obeys
\[
 (\widetilde\Pi)_{A,y,z,b}
 \le\frac S h\,\sigma(dA)\pi_A(dy)\pi_A(dz)\,
 1_{\{m_b<m_A/K,\ Z_b(y)\le h,\ c_b(z)=0\}}\rho_y(db).            \tag{5}
\]
The exact pre-projection support is stronger, \(m_b<m_{w_0}/K\); (5) is a positive enlargement. It preserves the opposite-source label. It is not a \(\sigma(db)\pi_b(dy)\pi_b(dz)\) reference, which would vanish on \(c_b(z)=0\).

After integrating out the original father, the reference in (5) is
\[
 \frac S h f(y)f(z)\,
 C_2^{>Km_b}(y,z)\,
 \frac{c_b(y)(1-c_b(z))1_{\{Z_b(y)\le h\}}}{m_b}\,dy\,dz\,db,
\quad
 C_2^{>t}(y,z)=\int_{m_A>t}\frac{q_Ac_A(y)c_A(z)}{m_A^2}\,dA.    \tag{6}
\]
In particular the untruncated pair reference is \(f(y)f(z)C_2(y,z)dy\,dz\), whose \(y\)-marginal is \(f(y)D(y)dy\), where \(D(y)=\int c_A(y)R_A^{-n}dA\), not \(f(y)dy\).

For clarity, the total right side of (5) equals
\[
 \frac S h\int\sigma(dA)\int_{m_b<m_A/K}
 \frac{I_{Ab}^{\rm low}}{m_A}
 \left(1-\frac{I_{Ab}}{m_A}\right)\frac{db}{m_b},                \tag{7}
\]
where \(I_{Ab}=\int f c_Ac_b\) and
\(I_{Ab}^{\rm low}=\int f c_Ac_b1_{\{Z_b(y)\le h\}}\).
Dropping the low-rank mark returns the previously known R450 exclusive moment divided by \(h\), not a new \(W\) price. No cross-father estimate of (7) at root scale is proved here. Thus the new usable interface is (3)–(5), not a complete remainder payment or an additional subtraction from the mother ledger.

## 5. Actual computation

The local math Python ran r457_mainproof_check.py; stdout r457_mainproof.result.txt records **258 Fraction assertions** on three exact atomic chain models: positive cross-capture, zero cross-capture, and a stopping-threshold atom. They check complete occupation versus ever-hit, the \(C/h\) barrier, row mass of the Doob kernel, and the soft-weighted terminal domination.

In the positive-cross model, \(C/h=3/5\), ever-hit probability is \(7/22\), while cross occupation is \(23/66>7/22\); this explicitly distinguishes occupation from first hit. The initial attempted script run had an indexing error in the finite conditional-row check; it was corrected before the successful recorded run. These are atomic-kernel checks, not native cube or original-history realizations. The actual-field proof uses the cited Green theorem and the verified original soft-factor/cumulative-capacity definitions.
