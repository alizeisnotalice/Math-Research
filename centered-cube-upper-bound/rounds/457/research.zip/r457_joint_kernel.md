# R457：保原接受权的双终端几何核

本文只展开已经构造的双排斥提升的一个正上包络，**不声称该上包络已有根阶价格，也不以换名的核代替证明**。它用于明确下一步全局几何必须控制的同一来源对、同一父与同一接受权。

沿用几何稿的 \(\Pi^0=\Pi/b\)，其中 \(b=1-C_A(y,z)/h\)。令其实际静态投影为
\[
 d(\Pi^0)_{A,y,z}=S a_0(A,y,z)\,\sigma(dA)\pi_A(dy)\pi_A(dz),
 \quad 0\le a_0\le1.
\]
\(a_0\) 是原完整记录在投影后的实际接受权，仍包含原静态门；旧路径、阶段和历史依赖已经按其真实条件分布积分。不是任意新选的可分离权。定义 \(a_\zeta=a_0 1_{\{b\ge\zeta\}}\)。若 \(S=0\) 则全部为零。

对给定原记录，新双路径条件化密度相对去soft的原记录乘未条件路径至多 \(1/\zeta\)。两条未条件路径给定原完整记录独立；各终端为总Green的子测度，且旧起点均own-high、严格小于原父质量的 \(1/K\)。因此两新终端 \(u,v\) 的父外剩余投影满足
\[
\begin{aligned}
d\Xi_{\rm out}(A,y,z,u,v)
\le{}&\frac{S}{\zeta h^2}a_\zeta(A,y,z)
 \sigma(dA)\pi_A(dy)\pi_A(dz)\\
&\times 1_{\mathcal D_A}(u,v)
 \frac{c_u(y)(1-c_u(z))}{m_u}
 \frac{c_v(z)(1-c_v(y))}{m_v}\\
&\times 1_{\{Z_u(y)\le h\}}1_{\{Z_v(z)\le h\}}\,du\,dv,
\end{aligned}\tag{1}
\]
其中
\[
 \mathcal D_A=\{u,v\in E\setminus Q_A:\ m_u,m_v<m_A/K^2\}.
\]
如果原起点另有更强质量门，它仍保留在原记录中；(1)只使用这里显示的较松支持。新终端至少经历一次跳跃，因此没有把初始Dirac误塞进后继Green。应用 \(1/\zeta\) 以后仍可保留终端排斥事件：先在整个路径的正支配中保留该事件，再对其端点集合积分。初始节点可随旧历史变化，但Green上界对这些合法节点一致，故积分旧标签后仍保 \(a_\zeta\)，不需要假称旧两路径条件独立。

把全部真实来源密度展开，可将(1)总质量写成
\[
 R_{\rm barrier,out}\le\frac{S}{\zeta h^2}\,\mathcal E[a_\zeta],\tag{2}
\]
\[
\begin{aligned}
\mathcal E[a]=\int_E\frac{dA}{m_AR_A^n}
 \int_{\mathcal D_A}\frac{du\,dv}{m_um_v}
 \int_{\mathbb R^n\times\mathbb R^n}& f(y)f(z)a(A,y,z)
 c_A(y)c_A(z)c_u(y)c_v(z)\\
 &\times(1-c_u(z))(1-c_v(y))
 1_{Z_u(y)\le h}1_{Z_v(z)\le h}\,dy\,dz.
\end{aligned}\tag{3}
\]
等式使用 \(q_A/m_A^2=1/(m_AR_A^n)\)。所有积分非负，可用Tonelli；单octave下 \(m_u\ge qa^n>0\)、\(|E|\le X/q<\infty\)、\(f\in L^1\) 保证这里的粗上包络有限。没有把真实Lebesgue中心改成离散计数，也没有使用来源密度帽。

特别不能把(3)中的接受权删掉后将两来源积分分开，再宣称仍使用了原low-common、双低p或历史信息。只有在 \(a\equiv1\) 这个更松上包络中，内部积分才分解成
\[
 I_A^{\rm low}(u\setminus v)\,I_A^{\rm low}(v\setminus u),\qquad
 I_A^{\rm low}(u\setminus v)
 =\int f(y)c_A(y)c_u(y)(1-c_v(y))1_{Z_u(y)\le h}\,dy.
\]
这不是本轮证明的根阶不等式；它可能丢失决定性接受信息。下一步优先对(1)的真实联合接收量及其 \(a_\zeta\) 保留版本进行几何结算，而不要求无标记的更强式成立。式(2)仅为可用上界，既不声称必要条件，也不因该式暂时未估出而否定其他全局路线。
