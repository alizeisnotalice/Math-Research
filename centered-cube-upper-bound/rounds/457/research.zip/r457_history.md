# R457 历史去重

**旧已证最佳联合接口与单边帽。** `/tmp/r411_geometry.md:54-79` 在原费用标签 ((A,y,z)) 上取双 exclusive 子核：(w) 捕 (y)、排 (z)，(t) 捕 (z)、排 (y)，各严格 (m<m_A/K)；可加 (w,t\notin Q_A)，不在该门后重归一。按 1/2 分至 ((w,y))、((t,z)) 保总费。单边列帽 (7)、守恒半分帽 (8)，`/tmp/r411_geometry.md:97-115`，仍带 (\log_+(J(x)/a_x))，对 (\sigma(dw)\pi_w(dx)) 量级 (O(S\lambda q_-^{-1}\log n))，不是 (W) 的单位列容量。

**已明示的迭代缺口。** `/tmp/r411_geometry.md:255-263`：孩子的条件来源分布是带权推前，非完整 (\pi_w)；排斥的对侧来源不能原样延续；列帽总量 (X_q) 且无跨父重复子节点一次收费控制。因此一步双 exclusive 不能据此续成双树或得终端联合价。

**已有单树与双树付款。** `/tmp/r412_aux.md:55-96` 固定来源严格 K 下降，给有限 Green 终端律 (L_x1=1)、(L_x(A,D)\le\rho_x(D\cap B_x)/h)。但 `:100-117` 总终端仍有 (M(x)/h) 放大，来源积分仅 (O(nW)) 量级，非根阶联合容量。`/tmp/r412_aux.md:138-175` 再把两条固定来源路径作条件乘积 lift，付最终任一终端返回 (Q_A)，价格 Δ_return (X_q)；最终双 outside 补集未付，中间节点可捕对侧来源。全程 (y,z) 固定，不刷新。

R430 仅另付 all-far 风险支与父质量窗支；`/tmp/r430_main.md:137` 保留低风险、大跨度余流并明确缺跨父/跨来源/跨质量层的联合根阶预算。R433 的 (\Pi\le S\sigma\pi_A^2) 是静态 sourcewise 上界（`/tmp/r433_main.md:15-21`），不改变孩子来源law，也不给其原 history。

**唯一确切未付接口：** 在 R411 实际带权双见证输出上，控制两条固定来源子树的**联合终端仍双父外、own-low/交叉捕获限制**之费用，并以完整匹配/中心容量把其跨父累计从带 (J/h) 的单边 Green 帽降到可付 (O(\sqrt n\,\mathrm{polylog}\,n)W+\epsilon X_q)。现有付款只删“至少一终端回父”，没有给这项双 outside 交叉联合流价格。

## 对“整路径 never-opposite + 保 soft 联合 cap”的二次去重

限定查阅 `/tmp/r414–r456` 范围内的 avoid / 不捕获 / 对侧 / 全路径 / soft 命中段及相邻公式；未发现已有“对两条新 fixed-source 辅助链各自条件化整条路径始终排斥对侧原来源，再以 (1/\eta) 控制联合路径密度，并同时保留原 unsoft 票据与 (b=(1-C_A/h)_+) 的联合列帽”这一机制。

最接近的旧接口并不等同：R411 只在**初始**见证核用 (1-c_w(z))、(1-c_t(y))（`:54-76`）；R412 的终端核分别按各自 (y,z) 捕获，审计明确终端“need NOT exclude the opposite original source”，中间节点也可能捕对侧（`/tmp/r412_audit.md:45-59`；aux `:138-175`）。R415/416 的 (b/soft) 是原父上的固定双来源共同捕获 CDF 或 additive soft-loss 上界，未沿新链传播（`/tmp/r415_main.md:13-36`；`/tmp/r416_audit.md:25-37`）。R430 的 all-far 风险避的是父邻近，非对侧来源捕获（`/tmp/r430_main.md:55-73`）。R456 另有 Gibbs 父/来源 pair 刷新及 first-hit 公式，但事件是 (p_y(B)\vee p_z(B)\ge\tau)，没有 never-opposite 路径门，也没有该 (1/\eta) 联合 cap（`/tmp/r456_mainproof.md:19-54`）。

因此新增差异精确在“整段路径交叉排斥的似然损失能否有统一 (1/\eta) 上限，且乘回原 soft 后仍保留联合 (S\sigma\pi_A^2) 列帽”这一接口；上述旧收据未给出它。此处只作历史去重，不认证新估计。
