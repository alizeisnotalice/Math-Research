# R457：保留双来源的全路径交叉排斥与完整费用

本稿只给原正余流的整体增强，不证明根阶总预算。取原 Π433 的任意正限制 Π（包括 R455 双低 p 支），R=|Π|。全部原阶段、旧路径、时钟、首次删除及未来标签保留；下面附加的路径不是这些旧路径，也不继承其筛选资格。

## 1. 输入与准确候选

沿用 q≤q_A≤λ、σ=q_A dA、π_A=f1_QA/m_A、X=∫σ、K=e^{√n}、s=1+√n、h=s/(ε₀q)、S=β+Ccol。固定一个原完整记录 ξ，含 A,y,z 及两个实际初始 exclusive、own-high 节点 w₀,t₀。置
\[
c=C_A(y,z)/h<1,\qquad b=1-c>0,\qquad d\Pi=b\,d\Pi^0.
\tag{1}
\]
这里 Π⁰ 是只除去这一份 soft 的实际记录测度。由 R411 §1 的显式 soft、R413 的 a_i^e≤B_e、Σ_i b_i≤1 及 R433 (1) 的正上放，其静态推前满足
\[
\operatorname{pr}_{A,y,z}\Pi^0\le S\sigma(dA)\pi_A(dy)\pi_A(dz).
\tag{2}
\]
(2)不是由 Π≤Sσπ² 作除法推得；它使用 soft 外的原阶段合同。不另除 exclusive 接受概率，故无 c_* 因子。

对任意 0<ζ<1，本稿证明一个保留全部原质量的附加双路径构造，并给
\[
\boxed{R\le\left(S\zeta+\frac{2S}{qh}\right)X+R_{\mathrm{barrier,out}}.}
\tag{3}
\]
新剩余两条附加路径始终分别捕 y 排 z、捕 z 排 y，终端各自 own-low 且中心均在 Q_A 外；原两来源从不刷新。其联合参考帽为 S/ζ，不称已取得 W 价。

## 2. 全路径交叉概率：使用总 Green，不累加单代帽

从 w₀ 运行原固定 y 的严格 K 下降核 P_y，到 Z_v(y)≤h 停止；从 t₀ 对 z 同样运行。记完整路径概率为 Q_y^ξ,Q_z^ξ。初始节点已经排斥对侧来源。R423_aux (1) 的总后继 Green（含终端，不含初始 Dirac）给
\[
G_x(v,du)\le
1_{m_u<m_v/K}\frac{\rho_x(du)}{\max(h,T_x(m_u))}
\le\rho_x(du)/h.
\tag{4}
\]
所有后继在原父的严格质量过去中，因此
\[
Q_y^\xi\{\exists j:c_{V_j}(z)=1\}
\le\int c_u(z)G_y(w_0,du)\le C_A(y,z)/h=c.
\tag{5}
\]
反向亦然。原子、停止阈值等号和有限深度均已包括在所引 Green 定理中。令 E_y,E_z 为 never-opposite 事件，a_y=Q_y^ξ(E_y),a_z=Q_z^ξ(E_z)，则 a_y,a_z≥b>0。

## 3. 完整质量的双条件路径与联合帽

在 b≥ζ 的原记录上附加概率
\[
\widehat Q^\xi=
\frac{1_{E_y}}{a_y}Q_y^\xi\otimes
\frac{1_{E_z}}{a_z}Q_z^\xi.
\tag{6}
\]
这是给定完整 ξ 后的条件产品；保留原记录总质量。可测性由有限可测核复合及正的 a_y,a_z 得到。相对未带 soft 的 Π⁰Q_yQ_z，完整提升的密度为
\[
\frac{b\,1_{E_y\times E_z}}{a_ya_z}
\le\frac1b\le\frac1\zeta.
\tag{7}
\]
此处只一次联合条件化，没有逐代放大。然而相对已带 soft 的 ΠQ_yQ_z，密度是 1/(a_ya_z)，帽为 ζ^{-2}；两种参考不可混淆。

单边边缘更强：对任意非负单边路径测试 F，
\[
b\,\widehat Q^\xi(F_y)=\frac b{a_y}Q_y^\xi(1_{E_y}F_y)
\le Q_y^\xi(F_y),
\tag{8}
\]
反向同理。它不推出无 ζ 损失的联合产品帽。把两个 bad 指示耦合到同一 uniform 也不能解决这一点：其 good-good 块乘 b 后被原产品支配，但质量仅为 b min(a_y,a_z)，没有搬运完整的 b。故正式构造用(6)，不把丢失块隐去。

新路径的终端 u,v 满足 Z_u(y),Z_v(z)≤h，分别捕 y 排 z、捕 z 排 y；这里的“交叉排斥”不声称 u,v 的中心或立方体相互排斥。原记录已有的终端几何只留在原标签上。

## 4. 小 soft 与返回父盒的实际付款

由(2)，Π{b<ζ}≤ζSX。对 b≥ζ 的提升，令 P_return 为新终端任一中心返回 Q_A 的质量，R_barrier,out 为其完整补集；故 R=Π{b<ζ}+P_return+R_barrier,out 精确。

使用单边(8)、终端作为(4)的子测度、再用实际完整 f 匹配，
\[
\begin{aligned}
P_{\rm return}
&\le\frac{2S}{h}\int\sigma(dA)
  \int\pi_A(dx)\int_{u\in E\cap Q_A}\frac{c_u(x)}{m_u}\,du\\
&=\frac{2S}{h}\int\sigma(dA)\frac1{m_A}
  \int_{E\cap Q_A}\frac{f(Q_A\cap Q_u)}{m_u}\,du\\
&\le\frac{2S}{h}\int\frac{\sigma(dA)}{q_A}
\le\frac{2S}{qh}X.
\end{aligned}\tag{9}
\]
仅用了 f(Q_A∩Q_u)≤m_u 与真实中心体积 |E∩Q_A|≤R_A^n，没有边界来源密度帽。两方向已经由 2 计全，阶段 S 只用一次。ζ^{-1} 无需用于单边 union 事件；较松的 2S/(ζqh)X 也成立但不采用。

因为 qh=s/ε₀，(3)的新增 X 系数为 Sζ+2Sε₀/s。S=0 时原流为零。若 S>0、ε₀ 为固定维度一致参数，给定 δ>0，取 ζ=min(1/2,δ/(2S))，并在 s≥4Sε₀/δ 时得到
\[
R\le\delta X+R_{\mathrm{barrier,out}}.
\tag{10}
\]
有限低维直接用 R≤SX≤SA_nW，A_n≤1+n log2；例如 n<⌈(4Sε₀/δ)²⌉ 的费用并入 C_{δ,S}W。不改变 h 或旧参数，不退款旧来源费。回原母账时仅将 R 槽替换为(3)；若该槽乘 M_old=64Λ₀Fhat，新增正项就是 M_old(Sζ+2Sε₀/s)X。要使本次入口新增费用≤ε_abs X，取 δ=ε_abs/M_old，并要求 s≥4M_old Sε₀/ε_abs。所有旧 X 费用照保；这不宣布旧总账已经吸收。

## 5. 已推进与唯一未付项

(3)使原全部余流在可吸收 X 费用后，带有两条全程排斥对侧原来源、最终父外且 own-low 的附加路径；这是整体提升，不是固定正比例假设。仍未证明
\[
R_{\mathrm{barrier,out}}\le tX+C_t s\,\operatorname{polylog}(n+2)W.
\]
其两路径联合参考仍为原父 σπ_A² 的 ζ^{-1} 放大，不能改成孩子完整后验或终端 W 容量。必须对同一父、保留 y,z 的双终端父外交通作跨父结算。原有路径门不自动传给新路径，(7)也不支付这一全局结算。本稿未宣称一般弱型闭合。

## 6. 本机检查与证据范围

`/tmp/r457_geometry_check.py` 已用指定 math-research-tools Python 实跑，stdout 保存于 `/tmp/r457_geometry.result.txt`。三阶段 basic 27、boundary 27、expanded 108，共 162 个 Fraction 标量耦合检查全部 PASS，核 Bernoulli 耦合边缘、good 块质量、完整 b 质量、联合 ζ 帽前的精确 b/(a_y a_z)、以及单边 b/a≤1。包括 c=0、p=0、p=c 与 c=99/100。它们只验证耦合代数，不是原生立方体或完整历史实例；原生(9)由上述 Tonelli/完整匹配证明，(4)直接引用已审总 Green。
