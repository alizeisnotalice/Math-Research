#!/usr/bin/env python3
"""Native fixed-(y,z) single-chain Doob audit; double-copy is probability-only."""
from fractions import Fraction as Q
from pathlib import Path
import json,sys,platform
import flint
from flint import arb,ctx
ctx.prec=256
ROOT=Path(__file__).resolve().parent
checks=0
def ck(x):
 global checks
 assert x
 checks+=1
def ar(x):return arb(x.numerator)/x.denominator
K=arb(1).exp()
NAMES=['A','w','mid','common','leaf']
SPOINTS=list(map(Q,['0','3/5','-3/5','-4/5','9/10']))
SMASS=list(map(Q,['1','1','3','16','79']))
CENTERS=list(map(Q,['1/50','-2/5','-1/5','3/20','0']))
SIDES=list(map(Q,['2','1','1','1','1']))
PH=Q(1,1000)
def mm(A,B):return [[sum((x*y for x,y in zip(row,col)),Q(0)) for col in zip(*B)] for row in A]
def paths(P,start):
 if not any(P[start]):return [([start],Q(1))]
 out=[]
 for nxt,p in enumerate(P[start]):
  if p:
   for tail,w in paths(P,nxt):out.append(([start]+tail,p*w))
 return out
def green_from_paths(rows,start,n):
 occ=[Q(0)]*n;term=[Q(0)]*n
 for path,p in rows:
  for v in path:occ[v]+=p
  term[path[-1]]+=p
 green=occ[:];green[start]-=1
 return occ,green,term

def run(stage,name,common_half,h_factor=None,h_value=None):
 half=[Q(1,500)]*5;half[3]=common_half
 ck(all(abs(x-y)>2*PH for i,x in enumerate(SPOINTS) for y in SPOINTS[i+1:]))
 ck(all(abs(x-y)>half[i]+half[j] for i,x in enumerate(CENTERS) for j,y in enumerate(CENTERS) if i<j))
 B=[];margin=Q(10)
 for c,R,hc in zip(CENTERS,SIDES,half):
  row=[]
  for x in SPOINTS:
   d=abs(c-x);hit=d+hc+PH<R/2;miss=d-hc-PH>R/2
   ck(hit!=miss);row.append(int(hit))
   margin=min(margin,R/2-d-hc-PH if hit else d-hc-PH-R/2)
  B.append(row)
 mass=[sum((a*b for a,b in zip(SMASS,row)),Q(0)) for row in B]
 ck(mass==list(map(Q,[100,20,4,2,1])))
 volume=[2*x for x in half];rho=[v*row[0]/m for v,row,m in zip(volume,B,mass)]
 bad=[bool(row[1]) for row in B]
 ck(bad==[True,False,False,True,False])
 far=[];lowA=[]
 for i,m in enumerate(mass):
  row=[]
  for j,t in enumerate(mass):
   lower=ar(t)*K<ar(m);upper=ar(t)*K>ar(m)
   ck(lower or upper);row.append(bool(lower))
  far.append(row)
  lower=ar(m)*K*K<ar(mass[0]);upper=ar(m)*K*K>ar(mass[0]);ck(lower or upper);lowA.append(bool(lower))
 ck([NAMES[j] for j,b in enumerate(far[1]) if b]==['mid','common','leaf'])
 ck([NAMES[j] for j,b in enumerate(far[2]) if b]==['leaf'])
 C=sum((r for r,iscross,low in zip(rho,bad,lowA) if iscross and low),Q(0))
 ck(C==rho[3])
 h=h_value if h_value is not None else h_factor*C
 ck(h>0);b=max(Q(0),1-C/h)
 Z=[sum((r for r,take in zip(rho,row) if take),Q(0)) for row in far]
 active=[z>h for z in Z]
 P=[[rho[j]/Z[i] if active[i] and far[i][j] else Q(0) for j in range(5)] for i in range(5)]
 H=[Q(0)]*5
 for i in sorted(range(5),key=lambda i:mass[i]):
  if bad[i]:H[i]=Q(0)
  elif not active[i]:H[i]=Q(1)
  else:H[i]=sum((p*H[j] for j,p in enumerate(P[i])),Q(0))
 for i in range(5):
  if not bad[i]:ck(H[i]>=b)
 Doob=[[P[i][j]*H[j]/H[i] if active[i] and H[i]>0 else Q(0) for j in range(5)] for i in range(5)]
 for i in range(5):
  if active[i] and H[i]>0:ck(sum(Doob[i])==1)
 rank_closed=[sum((r for r,m in zip(rho,mass) if m<=mass[j]),Q(0)) for j in range(5)]
 all_original=[];G=[]
 for i in range(5):
  ps=paths(P,i);ck(sum(p for path,p in ps)==1)
  occ,g,term=green_from_paths(ps,i,5);G.append(g)
  ck(sum(term)==1)
  for j in range(5):
   ck(g[j]<=rho[j]/max(h,rank_closed[j]))
   if not far[i][j]:ck(g[j]==0)
  if active[i]:ck(ar(sum(g))<=1+(ar(Z[i])/ar(h)).log())
  all_original.append(dict(start=NAMES[i],paths=[dict(nodes=[NAMES[k] for k in p],probability=w) for p,w in ps],occupation=occ,green=g,terminal=term))
 # Independent finite kernel-power full successor Green, terminal included once.
 power=[row[:] for row in P];series=[[Q(0)]*5 for _ in range(5)]
 for step in range(1,6):
  for i in range(5):
   for j in range(5):series[i][j]+=power[i][j]
  power=mm(power,P)
 ck(not any(x for row in power for x in row) and series==G)
 start=1;original=paths(P,start);conditioned=paths(Doob,start)
 avoid=sum((p for path,p in original if all(not bad[v] for v in path)),Q(0))
 ck(avoid==H[start] and avoid>0 and avoid>=b)
 cond_dict={tuple(path):p for path,p in conditioned}
 pathrows=[]
 for path,p in original:
  survives=all(not bad[v] for v in path);cp=cond_dict.get(tuple(path),Q(0))
  ck(cp==(p/avoid if survives else 0))
  rn=b*cp/p
  ck(rn<=1)
  telescope=Q(1)
  if survives:
   for i,j in zip(path,path[1:]):telescope*=H[j]/H[i]
   ck(telescope==1/H[start] and cp/p==telescope)
  pathrows.append(dict(nodes=[NAMES[v] for v in path],original_probability=p,avoid=survives,conditional_probability=cp,
   soft_conditional_probability=b*cp,soft_path_RN=rn,H_telescope=telescope if survives else None,
   fixed_labels=dict(parent='A',y_packet=0,z_packet=1,initial='w')))
 occ,g,term=green_from_paths(original,start,5);co,cg,ct=green_from_paths(conditioned,start,5)
 ck(sum(ct)==1 and sum(b*t for t in ct)==b)
 ck(all(b*x<=y for x,y in zip(co,occ)))
 ck(all(b*x<=y for x,y in zip(cg,g)))
 ck(all(b*x<=y for x,y in zip(ct,term)))
 # Two independent copies of this same y-chain are probability-only, not native y/z chains.
 joint_rn=b/(avoid*avoid);copied_soft_rn=(b/avoid)**2
 ck(copied_soft_rn<=1)
 return dict(stage=stage,name=name,n=1,K_interval=str(K),source_centers=SPOINTS,source_halfwidth=PH,source_mass=SMASS,W=sum(SMASS),
 receiver_names=NAMES,receiver_centers=CENTERS,receiver_halfwidth=half,receiver_side=SIDES,receiver_volume=volume,
 full_mass=mass,q_min=min(m/R for m,R in zip(mass,SIDES)),q_max=max(m/R for m,R in zip(mass,SIDES)),capture=B,
 strict_capture_margin=margin,rho_y=rho,common_C=C,h=h,b=b,strict_common_gate=C<h,Z=Z,active=active,
 far=far,rank_closed=rank_closed,P=P,H_avoid=H,Doob=Doob,original_all_starts=all_original,
 w_original_paths=pathrows,w_success_probability=avoid,w_conditioned_occupation=co,w_conditioned_green=cg,w_conditioned_terminal=ct,
 w_soft_occupation=[b*x for x in co],w_soft_green=[b*x for x in cg],w_soft_terminal=[b*x for x in ct],single_soft_RN=b/avoid,
 conditional_unsoft_green_exceeds_original_rank=any(cg[j]>rho[j]/max(h,rank_closed[j]) for j in range(5)),
 independent_double_copy=dict(scope='pure product-probability certificate, not native dual-source paths',
 success_product=avoid*avoid,soft_once_mass=b,soft_once_RN=joint_rn,one_soft_dominates_product_path=joint_rn<=1,
 hypothetical_two_soft_factors_RN=copied_soft_rn))
results=[run('initial','native_baseline',Q(1,500),h_factor=Q(3,2)),
 run('tie_zero_pressure','strict_active_tie_mid_stops',Q(1,500),h_value=Q(1,250)),
 run('tie_zero_pressure','zero_soft_common_boundary',Q(1,500),h_factor=Q(1)),
 run('expanded','smaller_common_block_double_copy_pressure',Q(1,1000),h_factor=Q(15,4))]
ck(results[0]['single_soft_RN']==Q(7,15))
ck(not results[1]['active'][2] and results[1]['Z'][2]==results[1]['h'])
ck(results[2]['b']==0 and not results[2]['strict_common_gate'])
ck(results[3]['single_soft_RN']==Q(22,25) and results[3]['independent_double_copy']['soft_once_RN']==Q(132,125))
out=dict(scope='genuine fullcapture single fixed-(y,z) kernel models, not original high-h/history; double-copy only probability interface',
 executable=sys.executable,python=platform.python_version(),python_flint=flint.__version__,arb_bits=ctx.prec,checks=checks,cases=results)
def enc(x):
 if isinstance(x,Q):return str(x)
 raise TypeError(type(x).__name__)
(ROOT/'r457_numeric_certificate.json').write_text(json.dumps(out,default=enc,indent=2)+'\n')
print('executable:',sys.executable,'Python:',platform.python_version(),'python-flint:',flint.__version__,'Arb bits:',ctx.prec)
for a in results:
 print(a['stage'],a['name'],'C=',a['common_C'],'h=',a['h'],'b=',a['b'],'strictC<h=',a['strict_common_gate'])
 print(' H(w)=',a['w_success_probability'],'singleRN=',a['single_soft_RN'],'double_once_RN=',a['independent_double_copy']['soft_once_RN'])
 print(' conditioned green=',a['w_conditioned_green'],'soft terminal=',a['w_soft_terminal'],'active=',a['active'])
print('PASS',checks,'Fraction/Arb checks; one geometry family/four purposeful cases, no scan')
