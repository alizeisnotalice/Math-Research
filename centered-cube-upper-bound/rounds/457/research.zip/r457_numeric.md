# R457 保固定来源对的单链Doob与soft一次抵消（冻结）

一个真实fullcapture一维kernel家族的四个有目的case全部通过：554项Fraction/Arb检查。单链在本例中满足s=P(avoid)≥b，Doob路径RN的H因子精确望远镜，乘一次原soft b后相对未加soft的原路径律密度≤1，完整occupation/terminal均保留原label并受支配。独立同链双copy的纯概率压力例却给一次soft的RN=132/125>1；它不是真实(y,z)两条native路径的反例。

## 1. 真几何与资格边界

source packets中心 `(0,3/5,−3/5,−4/5,9/10)`，半宽1/1000，质量 `(1,1,3,16,79)`，每packet内常密度，W100。receiver blocks如下，彼此严格不交：

| 名称 | center | side | 基线半宽 | 完整mass |
|---|---:|---:|---:|---:|
| A | 1/50 | 2 | 1/500 | 100 |
| w | −2/5 | 1 | 1/500 | 20 |
| mid | −1/5 | 1 | 1/500 | 4 |
| common | 3/20 | 1 | 1/500 | 2 |
| leaf | 0 | 1 | 1/500 | 1 |

A已移到.02，避免与leaf的center block冲突；真实receiver体积是半宽的两倍。扩大case仅common半宽改1/1000。每个完整packet×整个receiverblock都逐项严格全捕获或全排除，最小几何边距正；完整m由同一个f计算。实际qband `[1,50]`、octave2，source质量和体积都没有归一替代。

固定原source标签 y∈packet0、z∈packet1，父A和起点w在所有路径中保持。y被所有receiver捕获；z仅被A和common捕获。K=e的全部strict far比较用256-bit Arb核符号。父A的strict `m_v<m_A/K²`低质量common交集仅包含common，故 `C_A=ρ_y(common)`。起点w捕y而不捕z，保持exclusive。

这里h自选而且qband很宽；未实现原n1 high-h、proper-near、stage/history等合同。不能把这个真实kernel模型称为原剩余流非空证书或一般定理。

## 2. 原过程、avoid与Doob

`ρ_y(v)=|E_v|c_v(y)/m_v`，`Z_v=Σ_(m_u<m_v/K)ρ_y(u)`。原核仅在Z_v>h时 active，`P_vu=ρ_y(u)/Z_v`，否则停止；所有终端到达计一次，之后不传播。

实测w的完整prefix为{mid,common,leaf}，mid的为{leaf}。avoid事件是整条路径不进入捕获z的receiver（A或common）；从w出发A不可能被访问。设H(v)=avoid成功概率：forbidden态H0，合法停止态H1，其他合法active态 `H(v)=ΣP_vuH(u)`。H0态不作除法，Doob只在H>0的合法态定义

`P^H_vu=P_vu H(u)/H(v)`。

对从w到合法终端的每条完整路径，严格核

`∏P^H/∏P = ∏H(next)/H(current)=H(terminal)/H(w)=1/s`。

因此原soft标记b乘**一次**后，路径RN是 `b·1_avoid/s≤1`。本轮起始未加soft的质量为1，可取真实w block上的均匀初始law；kernel及H在整个block上常数，故block质量计算就是连续law的精确lumping。任意额外非负初始标量可同乘，但未构造原历史入量。

## 3. 初探、tie/zero、扩大四case

| 阶段/case | C | h | b=(1−C/h)+ | H(w)=s | 单链soft RN=b/s | 独立双copy一次soft RN=b/s² |
|---|---:|---:|---:|---:|---:|---:|
| 初探基线 | 1/500 | 3/1000 | 1/3 | 5/7 | 7/15 | 49/75 |
| active阈值tie | 1/500 | 1/250 | 1/2 | 5/7 | 7/10 | 49/50 |
| soft零边界 | 1/500 | 1/500 | 0 | 5/7 | 0 | 0 |
| common半宽减半 | 1/1000 | 3/800 | 11/15 | 5/6 | 22/25 | 132/125 |

初探及扩大均h<ρ(leaf)=1/250，允许w→mid→leaf的两跳。tie case严格采用Z>h：mid满足Z_mid=h而停止，不能继续到leaf。其条件终端law在(mid,leaf)上是(1/5,4/5)，乘b后为(1/10,2/5)，总量仍b=1/2。soft零边界C=h**不满足原strict C<h**，仅核边界约定；其H仍有意义但soft measure为零，未把它当strict-gate实例。

基线原路径及条件law为：

| path | 原概率 | avoid条件概率 | 乘一次soft后的概率 |
|---|---:|---:|---:|
| w→common | 2/7 | 0 | 0 |
| w→leaf | 4/7 | 4/5 | 4/15 |
| w→mid→leaf | 1/7 | 1/5 | 1/15 |

两条成功路径的RN都7/15；source/parent标签未刷新。扩大case的条件law仍(4/5,1/5)，但原avoid总概率5/6，故RN为22/25。完整路径表、H与Doob矩阵保存在JSON。

## 4. 完整successor Green与terminal

按R423准确版本，对所有原active起点（不仅w）计算完整Green `G=P+P²+…`，排除初始项、包含terminal到达一次；独立用全路径枚举核同一矩阵。逐列核

`G(v,u)≤1_(m_u<m_v/K) ρ_y(u)/max(h,T(m_u))`，`T(m)=Σ_(m_u≤m)ρ_y(u)`，

以及总后继数 `ΣG(v,·)≤1+log(Z_v/h)`（Arb核log）。所有质量秩使用真实全E和完整m，没有逐步重复乘列帽。

初探w的原Green在(mid,common,leaf)为(1/7,2/7,5/7)，包含中间态及terminal，合计8/7；条件Green在(mid,leaf)为(1/5,1)，合计6/5。特别mid的条件Green 1/5大于原闭秩帽1/7，说明**条件化本身不能无soft直接套原Green帽**。乘一次b后mid=1/15、leaf=1/3，逐节点受原Green支配。

每case都另外逐节点核 `b·Occ^H≤Occ^P`（含相同初始label）、`b·G^H≤G^P`、`b·Terminal^H≤Terminal^P`，且终端总量精确为b。没有丢initial项，也没有把条件law的terminal总量1错记成原soft质量1。

## 5. 双链不能自动再用同一个soft

这里只取**同一y-chain的两个独立概率复制**，各自condition avoid；它不是原y/z两条真实native路径，也不附给第二复制新几何或history资格。未加soft的both-avoid概率是s²，而两个条件law乘积相对原product路径律的密度是1/s²。原soft若只有一个b，RN便是b/s²；s≥b并不推出s²≥b。

扩大case给 `s=5/6,b=11/15`，所以 `b/s²=132/125>1`。甚至总mass已冲突：一次soft质量11/15大于原both-avoid质量25/36，相差7/180。假想再乘第二个b会给 `(b/s)²=484/625≤1`，但那把原标记改成b²，不能免费复制原soft。

该概率证书只否定“从单链b≤s自动得双份conditioning一次soft支配”的推理，不证明原native双链必然失败，也不支付原全history积分。

## 6. 复现与冻结

```sh
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/r457_numeric.py
```

实际Python3.12.14、python-flint0.9.0、Arb256bits。所有几何、m、核、路径、Green、Doob与RN均Fraction精确；Arb只核K=e的strict比较及log后继数界。554checks PASS，实际.05秒，最大RSS32,276,480bytes。一个几何家族四个指定目的case，无scan、agent、git、repo或他人修改。

冻结白名单：`r457_numeric.py`、`r457_numeric_certificate.json`、`r457_numeric_run.txt`、`r457_numeric_resources.txt`、`r457_numeric.md`、`r457_numeric_compute_index.md`。自含输入、脚本同目录写证书；完成停止。
