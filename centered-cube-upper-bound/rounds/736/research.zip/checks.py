"""Exact union, overlap and width tests. --mac reads the script on stdin."""
from fractions import Fraction as F
from itertools import product
from math import comb,isqrt
import json, platform, subprocess, sys
from pathlib import Path

def volumes(dim,steps,radius,kind,mac):
    centers=[tuple(j if kind=='chain' or k==0 else ((-1)**j if k%2 else j%3) for k in range(dim)) for j in range(steps)]
    rs=[radius if kind=='chain' else radius+j%2 for j in range(steps)]
    boxes=[[(x-r,x+r) for x in c] for c,r in zip(centers,rs)]
    def overlap(indices):
        v=1
        for axis in range(dim):
            v*=max(0,min(boxes[j][axis][1] for j in indices)-max(boxes[j][axis][0] for j in indices))
        return v
    if mac:
        v=sum((-1)**(mask.bit_count()+1)*overlap([j for j in range(steps) if mask>>j&1]) for mask in range(1,1<<steps))
    else:
        # Recursive coordinate slabs with active boxes.
        def slabs(active,k):
            if not active:return 0
            if k==dim:return 1
            ends=sorted({x for j in active for x in boxes[j][k]})
            return sum((b-a)*slabs([j for j in active if boxes[j][k][0]<=a<b<=boxes[j][k][1]],k+1) for a,b in zip(ends,ends[1:]))
        v=slabs(list(range(steps)),0)
    total=sum((2*r)**dim for r in rs)
    forest=total-sum(max(overlap([i,j]) for i in range(j)) for j in range(1,steps))
    assert v<=forest<=total
    if kind=='chain':
        assert v==forest==(2*radius)**dim+(steps-1)*((2*radius)**dim-(2*radius-1)**dim)
    return [dim,steps,radius,kind,v,forest,total]

def small(mac):
    return [volumes(n,m,r,k,mac) for n,m,r in [(2,4,1),(3,6,2),(5,8,2)] for k in ['chain','fold']]
if '--mac' in sys.argv:
    print(json.dumps([platform.python_version(),small(True)]));sys.exit()
local=small(False)
cmd=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=8','macbook-math','/Users/zhengzhihao/.venv/bin/python -B - --mac']
remote=subprocess.run(cmd,input=Path(__file__).read_text(),text=True,capture_output=True,check=True,timeout=100)
version,data=json.loads(remote.stdout)
assert data==local
from flint import arb,ctx
ctx.prec=256
profiles=[]
for n in [256,1024,4096]:
    a=32*n;K=4096*isqrt(n)*a**n;J=2**n;delta=F(1,4*a);r=F(1,16);u=r/a;x=F(3,50)
    assert u<delta and x+delta+u<r and x-delta-u+F(63,64)>1+F(6,n)
    assert x+delta+u-r*(1+F(1,a))+F(63,64)<1
    eta=arb(2).log()/K
    vt=arb(J)/(8*a)**n;rh=vt*eta.expm1()/2
    lg=n*arb(a).log()+(K-5)*n*arb(4).log()+(-(-eta).expm1()).log()
    assert rh>0 and rh<vt/4 and lg>(4*arb(8)**n+1).log()
    profiles.append(dict(n=n,log2_rows=n,width_bits=comb(n,n//2).bit_length(),V_T=str(vt),high=str(rh),excess=0,logD_div_K=[str(lg/K),str((lg+arb(3).log())/K)]))
print(json.dumps(dict(python=sys.executable,version=platform.python_version(),remote_cmd=cmd,remote_version=version,exact_union=local,histories=profiles),indent=2))
