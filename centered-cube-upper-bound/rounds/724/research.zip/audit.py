"""R724 conditional exit tables and tent exponential envelope.

Only audit.json is generated. Exact Fraction type volumes, Arb256/384 scalar
checks, local80-digit quadrature, and independent MacBook exact/Decimal checks.
"""
from fractions import Fraction as F
from itertools import product
from math import comb,factorial,isqrt
from pathlib import Path
import hashlib,json,platform,socket,subprocess,sys


def compositions(n):
    return [(minus,inside,n-minus-inside,
             factorial(n)//(factorial(minus)*factorial(inside)*factorial(n-minus-inside)))
            for minus in range(n+1) for inside in range(n-minus+1)]


def type_tests():
    rows=[]
    for first in [(4,0,0),(3,3,3),(6,5,5)]:
        n=sum(first);root=isqrt(n);assert root*root==n
        options=[compositions(x) for x in first]
        Nt=__import__('math').prod(comb(x+2,2) for x in first)
        for d in [F(1,2),F(65,128),F(33,64)]:
            total=marked=F(0);count=0;marked_count=0;max_accepted=F(0)
            for table in product(*options):
                coefficient=__import__('math').prod(x[3] for x in table)
                outside=sum(x[0]+x[2] for x in table)
                volume=coefficient*d**outside;total+=volume;count+=1
                pi=F(1,Nt)
                if volume<=root*pi:
                    marked+=volume;marked_count+=1;max_accepted=max(max_accepted,volume/pi)
            assert count==Nt and F(count,Nt)==1
            assert total==(1+2*d)**n
            assert marked<=root and max_accepted<=root
            rows.append({'n':n,'frozen_first_class_counts':list(first),'d_exact':str(d),
                         'type_count':Nt,'universal_pi_exact':str(F(1,Nt)),
                         'total_volume_over_source_di_exact':str(total),
                         'marked_type_count':marked_count,'marked_volume_over_di_exact':str(marked),
                         'sqrt_n_exact':str(root),'largest_marked_volume_over_pi':str(max_accepted),
                         'marked_fraction_of_dominating_domain_exact':str(marked/total),
                         'conditional_payment_pass':True})
    return rows


def independent_decimal():
    from decimal import Decimal as D,localcontext
    with localcontext() as c:
        c.prec=110;optimizers=[];genuine=[]
        for e in [F(0),F(1,1<<40),F(1,1000000),F(1,4096),F(1,64),F(1,10),F(8,27),F(1)]:
            if not e:optimizers.append({'e':str(e),'values':['0']});continue
            ee=D(e.numerator)/e.denominator;C=D(4)
            s=max(D(3),((2*C/ee).ln()/3).exp());cost=s*ee+C/(s*s)
            optimizers.append({'e':str(e),'values':[str(s),str(cost)]})
        for b in [32,48,64]:
            n=1<<b;a=32*n;root=1<<(b//2);l2=D(2).ln();lh=(1+D(1)/a).ln();g=(1-D(2)/a).ln()
            Q=(D(n-1)*g).exp();W=(1-Q)/8+Q/a;JA=int(D(root)/W);JB=int(D(16*root)/W)
            logRA=2*lh+l2/n-D(JA+JB)*g
            volume_bin=n+int(D(n)*logRA/l2);logSmax=D(volume_bin+1)*l2/n-l2
            logd=lh+logSmax-logRA-l2;types=3*n*(n+1)//2
            outside=D(types).ln()+D(n)*logd-D(n).ln()/2
            inside=D(types).ln()-D(n).ln()/2
            genuine.append({'b':b,'values':[str(outside),str(inside)]})
        return {'host':socket.gethostname(),'python':sys.version,'types':type_tests(),
                'optimizers':optimizers,'genuine':genuine}


if '--remote' in sys.argv:
    print(json.dumps(independent_decimal()));raise SystemExit(0)


from flint import arb,ctx
import mpmath as mp
BASE=Path(__file__).resolve().parent
def cv(x):return arb(x.numerator)/x.denominator
def st(x):return x.str(38)


def tent_envelope(s,x):
    # Inputs s,x are exact Fractions, making the join test exact.
    threshold=1-1/s
    if abs(x)<=threshold:return cv(1-abs(x))
    return (cv(s)*(1-cv(abs(x)))-1).exp()/cv(s)


def envelope_tests():
    ctx.prec=384;mp.mp.dps=80;point_checks=0;quadratures=[]
    for s in [F(1),F(3),F(4),F(8),F(64)]:
        for j in range(-32,33):
            x=F(j,16)
            for v in [F(-1,2),F(-1,8),F(0),F(1,8),F(1,2)]:
                left=max(F(0),1-abs(x-v));right=(cv(s*abs(v))).exp()*tent_envelope(s,x)
                gap=right-cv(left)
                assert gap>0 or gap.contains(0)
                point_checks+=1
        ss=mp.mpf(s.numerator)/s.denominator;join=1-1/ss
        def env(x):return 1-abs(x) if abs(x)<=join else mp.exp(ss*(1-abs(x))-1)/ss
        integral=mp.quad(env,[-mp.inf,-join,0,join,mp.inf])
        exact=1+1/ss**2
        assert abs(integral-exact)<mp.mpf('1e-65')
        # Independent symbolic piecewise integration with exact rational s.
        symbolic=2*((1-1/s)-(1-1/s)**2/2)+2/s**2
        assert symbolic==1+1/s**2
        quadratures.append({'s_exact':str(s),'ordinary_tent_join_exact':str(1-1/s),
                            'integral_exact':str(symbolic),'quadrature':mp.nstr(integral,40),
                            'absolute_error':mp.nstr(abs(integral-exact),8),'mpmath_dps':80})
    return {'pointwise_shift_checks':point_checks,'quadratures':quadratures}


def optimizer(e,bits,C=F(4)):
    ctx.prec=bits
    if not e:return {'e_exact':'0','C_exact':str(C),'s_constraint':'>=3','s_optimizer':'infinity (infimum)',
                     'minimum_cost_exact':'0','_values':(arb(0),)}
    if e>=2*C/F(27):s=arb(3)
    else:s=(cv(2*C/e).log()/3).exp()
    cost=s*cv(e)+cv(C)/s**2
    derivative=cv(e)-2*cv(C)/s**3
    if e>=2*C/F(27):assert derivative>=0 or derivative.contains(0)
    else:assert derivative.contains(0)
    for scale in [F(11,10),F(2)]:
        larger=s*cv(scale);other=larger*cv(e)+cv(C)/larger**2
        assert other>cost
    return {'e_exact':str(e),'C_exact':str(C),'s_constraint':'>=3','s_optimizer':st(s),
            'minimum_cost':st(cost),'boundary_optimizer':e>=2*C/F(27),
            'exact_log_integral_cost_at_optimizer':st(s*cv(e)+cv(C)*(1+1/s**2).log()),
            'precision_bits':bits,'_values':(s,cost)}


def error_models():
    ctx.prec=384;rows=[]
    for n in [4,16,64]:
        rho=F(1,64*n)
        proxy=optimizer(n*rho,384,F(n))
        proxy_cost=arb(proxy['minimum_cost'])
        for label,active in [('sparse',1),('intermediate',isqrt(n)),('fat',n)]:
            result=optimizer(active*rho,384,F(n));cost=arb(result['minimum_cost'])
            assert cost<=proxy_cost or cost.overlaps(proxy_cost)
            rows.append({'dimension':n,'stage':label,'active_error_axes':active,
                         'same_Linfinity_error_exact':str(rho),'actual_L1_error_exact':str(active*rho),
                         'max_based_L1_proxy_exact':str(n*rho),
                         'actual_product_optimizer_s':result['s_optimizer'],
                         'actual_product_log_cost_upper':result['minimum_cost'],
                         'actual_product_exact_log_integral_cost':result['exact_log_integral_cost_at_optimizer'],
                         'max_proxy_log_cost_upper':proxy['minimum_cost'],
                         'max_proxy_over_L1_cost':st(proxy_cost/cost),
                         'scope':'Actual n-fold tent product uses C=n; this is a geometric error model, not a cube history.'})
    return rows


def genuine(b,bits):
    ctx.prec=bits;n=1<<b;a=32*n;root=1<<(b//2);l2=arb(2).log();lh=(arb(1)/a).log1p();g=(-arb(2)/a).log1p()
    Q=((n-1)*g).exp();W=-((n-1)*g).expm1()/8+Q/a
    JA=int((arb(root)/W).floor().unique_fmpz());JB=int((arb(16*root)/W).floor().unique_fmpz())
    logRA=2*lh+l2/n-(JA+JB)*g;RA=logRA.exp()
    volume_bin=n+int((n*logRA/l2).floor().unique_fmpz())
    logSmax=arb(volume_bin+1)*l2/n-l2;d=(lh+logSmax-logRA-l2).exp();Nt=3*n*(n+1)//2
    assert 1<RA<2
    assert arb('.5')-RA/a>arb('.125') and RA-RA/a>arb('.75')
    outside=arb(Nt).log()+n*d.log()-arb(n).log()/2
    inside=arb(Nt).log()-arb(n).log()/2
    assert outside<0 and inside>0
    return {'b':b,'n':f'2^{b}','frozen_first_class_counts':['1',str(n-1),'0'],
            'genuine_source':'A first full shell word: first digit a-1, all other digits a/2; positive actual source theta',
            'genuine_receivers':'Every retained R717 receiver point is negative-outside in coordinate1 and inside this source on all other axes.',
            'actual_K':16,'source_radius_RA':st(RA),'actual_source_volume_bin':str(volume_bin),
            'd_definition':'h*smax/(2si), si=RA and smax=2^((volume_bin+1)/n)/2 (actual dyadic bin upper radius)',
            'actual_d':st(d),
            'universal_type_count':str(Nt),'universal_pi_exact':f'1/{Nt}',
            'log_all_second_outside_volume_over_sqrt_n_pi':st(outside),
            'log_all_second_inside_volume_over_sqrt_n_pi':st(inside),
            'all_outside_type_marked':True,'all_inside_type_unmarked':True,
            'total_marked_volume_over_di_at_most':'sqrt(n) by normalized type threshold, not enumerated at this n',
            'precision_bits':bits,'_values':(outside,inside)}


def main():
    types=type_tests();env=envelope_tests();opts=[];hist=[]
    for e in [F(0),F(1,1<<40),F(1,1000000),F(1,4096),F(1,64),F(1,10),F(8,27),F(1)]:
        lo=optimizer(e,256);hi=optimizer(e,384)
        for x,y in zip(lo['_values'],hi['_values']):assert x.overlaps(y)
        hi['_check']=[float(x) for x in hi['_values']];del hi['_values'];opts.append(hi)
    errors=error_models()
    for b in [32,48,64]:
        lo=genuine(b,256);hi=genuine(b,384)
        for x,y in zip(lo['_values'],hi['_values']):assert x.overlaps(y)
        hi['_check']=[float(x) for x in hi['_values']];del hi['_values'];hist.append(hi)
    command=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=5','macbook-math','/Users/zhengzhihao/.venv/bin/python -B - --remote']
    run=subprocess.run(command,input=Path(__file__).read_text(),text=True,capture_output=True,timeout=45)
    remote={'command':command,'exit_code':run.returncode,'stderr':run.stderr}
    if run.returncode==0:check=json.loads(run.stdout);remote['result']=check
    else:check=independent_decimal();remote['local_fallback']=check
    assert types==check['types']
    for left,right in [(opts,check['optimizers']),(hist,check['genuine'])]:
        for local,other in zip(left,right):
            for x,y in zip(local['_check'],other['values']):assert abs(x-float(y))<=max(1e-12,abs(x)*1e-12)
            del local['_check']
    remote['independent_crosscheck_passed']=True
    result={'host':socket.gethostname(),'python':sys.executable,'python_version':platform.python_version(),
            'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'conditional_type_tests':types,'tent_envelope_tests':env,'C4_scalar_optimizers':opts,
            'sparse_fat_product_error_models':errors,'genuine_source_type_checks':hist,'remote':remote,
            'type_proof':['Freeze the entire first x-status partition of the coordinates of one source. The3 row sizes n_a sum to n; do NOT multiply by the number of possible first partitions.',
                          'For each row of the3x3 exit table, second statuses have relative lengths(d,1,d). A table has V_type/di=product multinomial(n_a;counts)*d^(number of outside outputs).',
                          'The exact multinomial sum is(1+2d)^n. There are Nt=product binom(n_a+2,2) table types. Assign the normalized universal pi=1/Nt independently of d.',
                          'Mark a type only if V_type/di<=sqrt(n)*pi. Disjoint conditional cells then have total marked volume<=sqrt(n)*di; every finite fixture computes this sum exactly.',
                          'The genuine huge-n example verifies the known first partition and two contrasting type decisions. Its total budget follows the normalized threshold algebra; no enormous type space is numerically enumerated.'],
            'tent_proof':['tent_s(x)=sup_v(1-|v|)_+*exp(-s|x-v|). For s>=1 it is the ordinary tent on|x|<=1-1/s and exp(s(1-|x|)-1)/s outside.',
                          'The ordinary part integrates to1-1/s^2 and the two tails to2/s^2, yielding1+s^-2 exactly.',
                          'A shift vector obeys product tent(x-v)<=exp(s*||v||1)*product tent_s(x). Its exact integral penalty is s*||v||1+n*log(1+s^-2)<=s*||v||1+n/s^2.',
                          'The scaled scalar benchmark se+C/s^2, s>=3, has optimizer max(3,(2C/e)^(1/3)), and infimum0 at e0. C4 is separate from actual product models, which correctly use C=n.',
                          'At fixed Linfinity error, sparse/intermediate/fat vectors have different L1 costs. Replacing L1 by n*Linfinity produces the recorded overestimates; these are pure geometry tests.'],
            'scope':['Nine exact conditional type-volume fixtures with frozen first classes,1625 one-dimensional envelope point tests, five actual80-digit quadratures, scalar optimizers and three product-error stages.',
                     'The true R715/R717 source example is a genuine source/receiver first-status check; it does not claim that a large fraction of all original high sources is marked by these thresholds.',
                     'Only one frozen conditional first pattern is charged per source/anchor fixture. No global union over all patterns or anchors is inferred from these finite checks.',
                     'Local Arb256/384 and independent exact/Decimal110 backend agree; the actual host is recorded. Only audit.py/json are created, with no Git or remote files.']}
    output=BASE/'audit.json';output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'output':str(output),'remote_exit':run.returncode,'independent_crosscheck':True,
                      'type_rows':types,'optimizer_count':len(opts),'product_error_models':errors},indent=2))


if __name__=='__main__':main()
