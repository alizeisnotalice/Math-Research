"""A compressed two-site genuine first-half history; all witnesses and owners are real."""
from fractions import Fraction as F
from decimal import Decimal as D, localcontext
from flint import arb,ctx
from math import prod,isqrt
import json,sys
def arbq(x): return arb(x.numerator)/x.denominator

def run(n):
    a=32*n; h=1+F(1,a)
    with localcontext() as c:
        c.prec=80
        z=[]
        for k in range(n):
            p=(D(k)+D('0.5'))/n
            v=(2*p).sqrt()-1 if p<D('0.5') else 1-(2*(1-p)).sqrt()
            z.append(F(int((v*8*a).to_integral_value()),8*a))
    z[0]=F(3,4)
    digits=[int(v*8*a) for v in z]
    allowed=[(abs(digits[k]-digits[j]),k,j) for k in range(1,n) for j in range(1,k)
             if a<=abs(digits[k]-digits[j])<=3*a//2]
    used=set(); gaps=[]
    for dist,k,j in sorted(allowed,reverse=True):
        if k in used or j in used: continue
        used.update((k,j));gaps.append(F(dist,8*a))
    gap=max(gaps); mean_gap=2*sum(gaps)/n
    assert mean_gap>F(1,25)
    sz=[int(a*(1-abs(v))) for v in z]
    count=prod(sz); available=a**n
    base_count=4096*isqrt(n)*available-count
    assert base_count>0 and all(sz) and isqrt(n)**2==n
    t=4096*isqrt(n)/arb(2).log()
    R=arbq(h)*(arb(2).log()/n).exp()
    layer=arb(count)/(arb(available)*t)
    q=layer.expm1()/2
    logvol=sum((R-arbq(abs(v))).log() for v in z)
    J=logvol.exp()/(t*q)
    assert J>=1 and J<32
    return {'n':n,'source_grid_counts_min_max':[min(sz),max(sz)],
            'log10_shell_source_count':str(arb(count).log()/arb(10).log()),
            'log10_baseline_count':str(arb(base_count).log()/arb(10).log()),
            'log_true_common_shell_theta':str(q.log()),'lens_density_ratio_J':str(J),
            'number_of_swapped_axes':len(used),'mean_coordinate_error_lower_normalized':str(arbq(mean_gap-F(1,2*a))/R),'linfty_error_lower_normalized':str(arbq(gap-F(1,2*a))/R),
            'wasserstein_error_upper_normalized':str(arbq(F(1,4*a))/R),
            'actual_two_receiver_volume_log':str(arb(2).log()+n*arbq(F(1,2*a)).log()),
            'scope':'Genuine first-half history. Baseline is rich in very far sources; original high integral is not evaluated.'}
if __name__=='__main__':
    ctx.prec=256
    rows=[run(n) for n in (16,64,256,1024)]
    print(json.dumps({'python':sys.version,'precision_bits':ctx.prec,'rows':rows},indent=2))
