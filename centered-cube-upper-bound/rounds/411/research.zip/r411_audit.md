# R411 independent audit — FINAL PASS

FINAL PASS for the two specified once-only positive receipts and their displayed full-ledger substitution. Both were screened independently before reading their R411 author proofs. Main/readme, final proofs and all three scripts were subsequently read; the delivered3014 Fraction model/check groups were actually rerun and passed. The final joint remainder remains unpaid. No general root-order upper bound, automatic total absorption or legal iterated history is certified. Only this audit file was edited.

## 1. Exact measure and lift

All three final reports use the same Θ: the COMPLETE R408 actual two-source early cost, including the original soft factor(1−C_A(y,z)/h)_+, original full-f matching/du/clock/J/H, old source and stage/history/spatial/rank/fractional marks. Θ is not redefined as its σπ_A² envelope. On positive support C_A<h and both exclusive masses E_y=Z_A(y)−C_A, E_z=Z_A(z)−C_A are positive.

The normalized exclusive kernels Q_y and Q_z retain actual receiver centers and strict masses m_w,m_t<m_A/K. The single conditional product ΘQ_yQ_z preserves all original labels. Zero-soft contributions carry no cost; kernels may be assigned any measurable convention there. All kernels and events are measurable by parameterized positive integration. Every later event is a positive restriction of this SAME joint lift. Restricting both centers outside the parent never triggers renormalization or resampling. Auxiliary receivers w,t acquire no original history eligibility.

The final three exact disjoint events are: inside union; bothoutside and own-low union; bothoutside and both-own-high. Aux R_out is only the intermediate bothoutside residual; final R411 is the third event. Final naming patches and the geometry's explicit soft-factor patch were reviewed.

## 2. Independent inside-union proof

For fixed parent A define Z_in,A(x)=∫_{w center∈Q_A,strictfar}c_w(x)μ(dw). Actual matching gives

E_{π_A}Z_in,A=(1/m_A)∫_{center w∈Q_A,far}I_Aw/m_w dw≤|Q_A|/m_A=1/q_A.

This cancels the true child mass by I_Aw≤m_w BEFORE using real Lebesgue center volume. No source-density bound or free-radius integration is used. With Z_A≤A_n/q_-, the raw exclusive witness union U_A satisfies

U_A(y,z)≤Z_in,A(y)Z_A(z)+Z_A(y)Z_in,A(z),
∫σ(dA)E_{π_A²}U_A≤2A_n|E|/q_-≤2A_nX_q/q_-².

The union subtraction in the exact U_A formula charges intersections once. Equal mass/radius atoms cause no omission; strictfar is retained. The optional bothinside raw moment≤X_q/q_-² is correct and is NOT a third charge.

For original source ranks Z_y>d1h,Z_z>d2h and c=C/h<1, the condition1/d1+1/d2≤1 implies

E_yE_z≥d1d2h²(1−c).

Hence actual soft×inside probability≤U_A/(d1d2h²). The external pair(2,L) and small pair(2−ε0,L−ε0) meet the condition, including the weakest small pair(3/2,7/2). Apply the old sourcewise β/C_col capacities only after this bound. Early first-deletion fractions are bounded by the original b_i; on the common old-label space sum the nested stages first using Σb_i(z)≤1. There is no stage-count cost, no averaged-to-pointwise substitution, and no deletion of external E_uv/Z reweighting. Thus

P_in≤Δ_in X_q,
Δ_in=2A_nB_L/(q_-²h²)=2ε0²A_nB_L/s²,
B_L=β/(2L)+C_col/[(2−ε0)(L−ε0)].

No extra λ or factor2 is missing. Δ_in≤S/(2L) under the stated frozen bounds, but changing L requires the complete old P_L/rank split and available absorption balance to be reconsidered.

The actual input is already in R404 SOURCE-far displacement. The present event concerns auxiliary witness CENTERS in the parent cube, so it is not the old source-near receipt. Current common-capture paid fractions remain removed. R402/403 near-only collar/failure receipts are not revived after their R404 replacement. This audit confirms the explicit current-residual split; it asserts neither first-ever historical coverage nor a uniform positive paid proportion. No old BH square/variance credit is reused.

## 3. Independent column and whole-anylow proof

Let a_y=(2−ε0)h,a_z=(L−ε0)h and B0=ε0h. The closed native mass window gives0≤T_A−Z_A≤B0, valid with arbitrary mass atoms. For x=y or z the pushed witness measure, with all original weights retained in its definition, is bounded by

S f(x)c_w(x)μ(dw)dx ∫q_Ac_A(x)1_{Z_A>a_x}1_{m_A>Km_w} μ(dA)/(Z_A−h).

For the y channel sum original b_i at the other source z BEFORE integrating it; for the z channel b_i is at the retained x. Both give one S=β+C_col, with no extra stage or source factor. The positive bothoutside restriction can be dropped only for this upper bound.

Since T_A≤Z_A+B0,

1/(Z_A−h)≤[(a_x+B0)/(a_x−h)]/T_A on Z_A>a_x.

Strictfar makes Z_A a subset of the STRICT past of mass m_A, so the parent atom's LEFT rank exceeds a_x. This is essential: merely retaining the right-rank condition T_A>a_x would miss a crossing-atom term. Whole rank-atom intervals now lie above a_x, giving ∫1_{Z_A>a_x}ρ_x(dA)/T_A≤log_+(J(x)/a_x), including continuous/singular parts. Changing to σ(dw)π_w(dx) costs exactly q_A/q_w≤λ/q_-. Consequently

C_x*=Sλ/q_- ·(a_x+B0)/(a_x−h)·log_+(Jmax/a_x),
Jmax=A_n/q_-.

If Jmax≤a_x the support is empty and the logarithm/column is zero. For witness ownpast Z_w(x)≤h, the same mass-window inequality gives T_w(x)≤h+B0. The inclusive-CDF sublevel mass is at most h+B0, even at equality atoms. Exact matching and q_w≤λ therefore give

∫σ(dw)π_w(dx)1_{Z_w(x)≤h}≤λ(h+B0)f(x)dx.

Thus the WHOLE low union in the same outside joint restriction costs

P_low,actual≤P_low W,
P_low=λ(h+B0)(C_y*+C_z*).

There is no1/2: the half-split construction pays a different half cost and cannot deliver the same both-high complement for half this price. Union upper bounds may count its intersection twice, while the actual removal occurs only once. The remaining ownpast conditions are genuine occupation statements, not restored full π_w posteriors or new history qualifications. With dimension-uniform frozen S,λ/q_-,ε0^−1,L this is O(√n log(n+2))W; otherwise the explicit parameter expression must be used.

## 4. Main/readme and complete ledger

The exact positive split plus the two upper prices give

R408≤R411+Δ_in X_q+P_low W.

The final main correctly substitutes this into R408:16Fδ at G0,32Fδ at BH,64ΛFδ at the entrance. Both Δ_in and P_low retain Fδ=(1−32δ)^−1, as do inherited C406/V406 in the core replacement. External E387/S390/8s and old H/entrance terms stay exactly as displayed; the initially overbroad 'all old bills multiplyFδ' wording was corrected. A_entrance,n is distinguished from occupancy A_n. The low-dimensional complete-core replacement is retained as an alternative, not summed into the large-dimensional formula. No H,L,h or original field is silently reset.

The original external conditional source law is not replaced by independent π_u⊗π_v. Same-parent π_A² appears only in the permitted envelope after the exact original sourcewise representation. Bothoutside witnesses still exclude opposite original sources and have strict smaller masses; none of these facts authorize an iteration, source refresh, unit column, or W-price terminal tree. Final main/readme accurately retain the unpaid R411 root budget and all older soft/crossing/entry, history, parameter, extreme-geometry/scale, limit and absorption/source-multiplicity obligations. A smaller remainder alone is not asserted to improve the total RHS for every input.

## 5. Actual local evidence

Before R411 author reading, reviewer executed81 Fraction assertions:9 exact native one-dimensional fixed-side average evaluations and72 scalar exclusive-soft-lift inequalities. These support bounded arithmetic only, not an original synchronized high-dimensional history fixture, and are NOT added to delivered counts.

Read and actually reran all delivered scripts, matching frozen stdout:

- parent12 finite source/cube-incidence models, stages2/6/4; observed finite Zmax used rather than imposing native A_n/q_-;
- aux26 models, stages6/12/8; exact real source-cell volumes/matching with finite receiver quadrature, plus a rational exponential far certificate;
- geometry2976 groups:2916 atomic rank/column cases and60 full-source finite-incidence exclusive models.

Total delivered3014 Fraction groups passed, not3014 independent native fields. The log checks use rational atanh-series LOWER bounds; verifying the stronger rational inequality is legitimate, not floating-point certification. Finite atomic models use their own exact mass-window gap B rather than forcing nativeB0 on arbitrary discrete weights. Receiver quadrature, arbitrary masks and lack of original clock/high-rank/history qualification are explicitly disclosed. Parent/reviewer reruns repeat cases and are not counted as new experiments. Analytic Tonelli/native-center and rank proofs, not counts, establish the general claims.

## Final byte bindings

- `/tmp/r411_main.md`: `91fb6468e3951e6474f3324c403434a296e6c3512a381106e97b2b45c3ed4172`
- `/tmp/r411_readme.md`: `866fc4f2f6d1d375c0966bd9aac625b23e4337335f88df07e3ce3f6a02360f59`
- `/tmp/r411_aux.md`: `08877dd6346771a4711a454fbf7704db27d0fd3a05f2dfbab45d69e0ac2c3823`
- `/tmp/r411_geometry.md`: `ed66744b47257f04b5188de053f9638b6dabbe38088a7996150e4166d84d38c6`
- `/tmp/r411_parent_check.py`: `1ade9d3e07d152ee6f41e4507aaead24bf606db7bc8e13abd59eb9c202a29dff`
- `/tmp/r411_parent.result.txt`: `9815542b5501946eca6d7dd6d3e145998700dc7eada8d877d82ae4a1c8c73c2b`
- `/tmp/r411_aux_check.py`: `0a1202cc2c0da8e382436404277bb8001545558fb522f6f982aaf2ea5017231b`
- `/tmp/r411_aux.result.txt`: `c4bd7198e7420159bd845ef163da0c970845b4c4b1a049372e40ebba17836913`
- `/tmp/r411_geometry_check.py`: `3eb1726ff8677d15a808bb9b10ce099908bcaf0ace30800214d2fe218fe48cee`
- `/tmp/r411_geometry.result.txt`: `ad577bda02915a8e2a005c3102a7c8a3c5c61bef34267ef6d4d7873592c71149`
- `/tmp/r408_main.md`: `29e41de32db722d89962f3f3593155b7e298bb02350e50cdab4a2a4fd12f3253`
- `/tmp/r404_main.md`: `d4914c5995deaa1b692ebb3c09928771e36cee8ca6a4b5c2604c85daad440b77`
- `/tmp/r400_geometry.md`: `041cec14e395f8e79fe23fd87e16b3aedabb6ca91d734b3326501dd080080e8c`
- `/tmp/r401_geometry.md`: `ea28d2fa8acb65c03f7d9cc38748724c6e054d1ceb2de2a09074e0dd03d471b0`

The inherited definitions above were used narrowly; no full historical proof re-audit or literature theorem verification is claimed. All requested R411 post-review and final binding work is complete. No further work is pending within this bounded review.
