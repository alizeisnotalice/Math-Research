from fractions import Fraction as F
from itertools import product
counts={};positives={}
for phase,n,weights_menu in [('initial',1,[1]),('mass_pressure',1,[1,2,5]),('expanded',2,[1,3])]:
 count=positive=0
 ys=list(product([F(-5,2),F(-3,2),F(-1,2),F(1,2),F(3,2),F(5,2)],repeat=n))
 ws=list(product([F(-11,4)+F(i,2) for i in range(12)],repeat=n))
 for skew in weights_menu:
  f=[F(skew if all(abs(x)<2 for x in y) else 1,1 if all(abs(x)<2 for x in y) else 4) for y in ys]
  parent=[all(abs(x)<=2 for x in y) for y in ys];ma=sum(p*v for p,v in zip(parent,f));pi=[p*v/ma for p,v in zip(parent,f)]
  dv=F(1,2)**n;cap=F(4)**n
  for radius in [F(4,5),F(6,5)]:
   inc=[[all(abs(y[k]-w[k])<=radius for k in range(n)) for w in ws] for y in ys]
   mw=[sum(f[j]*inc[j][k] for j in range(len(ys))) for k in range(len(ws))]
   mu=[dv/m if m and m<ma/F(3,2) else F(0) for m in mw]
   inside=[all(abs(x)<=2 for x in w) for w in ws]
   assert sum(dv for b in inside if b)<=cap
   Z=[sum(mu[k]*inc[j][k] for k in range(len(ws))) for j in range(len(ys))]
   Zi=[sum(mu[k]*inc[j][k]*inside[k] for k in range(len(ws))) for j in range(len(ys))]
   assert sum(pi[j]*Zi[j] for j in range(len(ys)))<=cap/ma
   unionmoment=F(0);totalfraction=F(0)
   for a in range(len(ys)):
    if not pi[a]:continue
    for b in range(len(ys)):
     if not pi[b]:continue
     ey=[mu[k]*inc[a][k]*(not inc[b][k]) for k in range(len(ws))]
     ez=[mu[k]*inc[b][k]*(not inc[a][k]) for k in range(len(ws))]
     A=sum(ey);B=sum(ez);Ai=sum(x*inside[k] for k,x in enumerate(ey));Bi=sum(x*inside[k] for k,x in enumerate(ez))
     moment=Ai*B+A*Bi-Ai*Bi
     assert 0<=moment<=A*B
     assert moment<=Zi[a]*Z[b]+Z[a]*Zi[b]
     unionmoment+=pi[a]*pi[b]*moment
     if A*B:
      frac=moment/(A*B);assert 0<=frac<=1
      assert frac+(A-Ai)*(B-Bi)/(A*B)==1
      positive+=frac>0
   assert unionmoment<=2*max(Z)*cap/ma
   count+=1
 counts[phase]=count;positives[phase]=positive
print('PASS exclusive-center union models',counts,'total',sum(counts.values()))
print('positive source-pair fractions',positives)
print('Fraction full-mass finite cube incidences with inside volume weights; not native continuum/history qualification. Observed Zmax used, not assumed An/q.')
