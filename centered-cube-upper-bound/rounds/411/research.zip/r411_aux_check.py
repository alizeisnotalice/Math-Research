from fractions import Fraction as F
from itertools import product

def cube(c,r): return tuple((x-r/2,x+r/2) for x in c)
def inter(*boxes): return tuple((max(b[j][0] for b in boxes),min(b[j][1] for b in boxes)) for j in range(3))
def vol(b):
    v=F(1)
    for lo,hi in b: v*=max(F(0),hi-lo)
    return v

def inside(c,b): return all(lo<=x<=hi for x,(lo,hi) in zip(c,b))
def mass(b,field): return sum(d*vol(inter(b,s)) for d,s in field)
def dotmask(y,b): return int(inside(y,b))

def fixtures(kind,shift,weight,fullgrid=False):
    parent=cube((shift,F(0),F(0)),F(2))
    big=cube((F(0),)*3,F(8))
    field=[(F(1),big)] if kind==0 else [(F(3,4),big),(F(1,4),cube((F(0),)*3 if kind==1 else (F(1),)*3,F(1)))]
    if fullgrid: offsets=product((F(-5,4),F(-3,4),F(3,4),F(5,4)),repeat=3)
    else: offsets=[tuple(sign[j]*r for j in range(3)) for r in (F(3,4),F(5,4)) for sign in product((-1,1),repeat=3)]
    centers=[(x[0]+shift,x[1],x[2]) for x in offsets]
    boxes=[cube(c,F(1)) for c in centers]
    mA=mass(parent,field); ms=[mass(b,field) for b in boxes]
    flags=[inside(c,parent) for c in centers]
    assert F(3,4)<=mA/8<=1
    assert all(F(3,4)<=m<=1 and mA>6*m for m in ms)
    weights=[weight]*len(boxes)
    return parent,field,centers,boxes,mA,ms,flags,weights

def verify_model(data):
    A,field,centers,boxes,mA,ms,flags,weights=data
    Is=[mass(inter(A,b),field) for b in boxes]
    mus=[w/m for w,m in zip(weights,ms)]
    cap=sum(mus); Vin=sum(w for w,flag in zip(weights,flags) if flag)
    Zavg=sum(mus[j]*Is[j] for j in range(len(boxes)) if flags[j])/mA
    assert Zavg<=Vin/mA and Vin<=vol(A)
    Jall=Jun=Jboth=Jout=F(0)
    for j,k in product(range(len(boxes)),repeat=2):
        overlap=mass(inter(A,boxes[j],boxes[k]),field)
        x,y=Is[j]-overlap,Is[k]-overlap
        assert 0<=x<=ms[j] and 0<=y<=ms[k]
        value=mus[j]*mus[k]*x*y/(mA*mA)
        Jall+=value
        if flags[j] or flags[k]: Jun+=value
        if flags[j] and flags[k]: Jboth+=value
        if not flags[j] and not flags[k]: Jout+=value
    assert Jall==Jun+Jout
    assert Jun<=2*cap*Zavg
    assert Jboth<=(Vin/mA)**2
    # Finite quadrature has cap<=1/q_- by explicit chosen weights, not by claiming native du.
    assert cap<=F(4,3)
    assert Jun<=2*F(4,3)**2 and Jboth<=F(4,3)**2
    assert Jun>0 and Jout>0
    return Jun,Jout

counts={'initial_joint_and_source':0,'boundary_pressure':0,'expanded_cubes':0}
base=fixtures(1,F(0),F(1,32))
A,field,centers,boxes,mA,ms,flags,weights=base
# Initial exact joint probability, with the SAME witness pair throughout.
for t in (F(3,10),F(9,10),F(19,20)):
    y=(-t,-t,-t); z=(t,t,t)
    ey=[weights[j]/ms[j]*dotmask(y,b)*(1-dotmask(z,b)) for j,b in enumerate(boxes)]
    ez=[weights[j]/ms[j]*dotmask(z,b)*(1-dotmask(y,b)) for j,b in enumerate(boxes)]
    sy,sz=sum(ey),sum(ez)
    if sy and sz:
        pu=sum(ey[j] for j in range(len(boxes)) if flags[j])/sy
        pv=sum(ez[j] for j in range(len(boxes)) if flags[j])/sz
        joint=sum(ey[j]*ez[k] for j,k in product(range(len(boxes)),repeat=2) if flags[j] or flags[k])/(sy*sz)
        out=sum(ey[j]*ez[k] for j,k in product(range(len(boxes)),repeat=2) if not flags[j] and not flags[k])/(sy*sz)
        assert joint==pu+pv-pu*pv and joint+out==1
    else: assert sy*sz==0
    counts['initial_joint_and_source']+=1
# Independent rectangular source integration of the exclusive two-source product.
for j,k in ((0,7),(0,15),(8,15)):
    cuts=[]
    for axis in range(3):
        cuts.append(sorted(set([A[axis][0],A[axis][1]]+[x for b in [boxes[j],boxes[k]]+[s for d,s in field] for x in b[axis] if A[axis][0]<x<A[axis][1]])))
    buckets={(a,b):F(0) for a,b in product((0,1),repeat=2)}
    for cell in product(*(list(zip(c,c[1:])) for c in cuts)):
        mid=tuple((lo+hi)/2 for lo,hi in cell)
        pattern=(dotmask(mid,boxes[j]),dotmask(mid,boxes[k]))
        buckets[pattern]+=mass(cell,field)
    direct=sum(vy*vz*py[0]*(1-pz[0])*pz[1]*(1-py[1]) for py,vy in buckets.items() for pz,vz in buckets.items())
    Ij=mass(inter(A,boxes[j]),field); Ik=mass(inter(A,boxes[k]),field); Ijk=mass(inter(A,boxes[j],boxes[k]),field)
    assert direct==(Ij-Ijk)*(Ik-Ijk)
    assert sum(buckets.values())==mA
    counts['initial_joint_and_source']+=1
for kind,shift,weight in product(range(3),(F(0),F(1,4)),(F(1,32),F(1,64))):
    verify_model(fixtures(kind,shift,weight))
    counts['boundary_pressure']+=1
for kind,shift,weight in product((1,2),(F(0),F(-1,4)),(F(1,128),F(1,256))):
    verify_model(fixtures(kind,shift,weight,True))
    counts['expanded_cubes']+=1
# Rational exp certificate: sqrt(3)<7/4 and exp(7/4)<6, hence native K<6.
x=F(7,4);term=F(1);partial=term
for j in range(1,11): term*=x/j;partial+=term
nextterm=term*x/11
assert F(3)<x*x and partial+nextterm/(1-x/12)<6
print('PASS',counts,'total',sum(counts.values()))
print('All Fraction; actual full-f cube masses and source volumes, finite receiver quadrature only.')
print('Native exponential far follows K=exp(sqrt(3))<6; original history/rank/clock gates not certified.')
