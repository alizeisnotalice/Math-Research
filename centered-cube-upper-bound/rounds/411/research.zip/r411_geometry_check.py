from fractions import Fraction as F
from itertools import product, combinations

def log_lower(x,N=80):
    assert x>=1
    t=(x-1)/(x+1)
    return 2*sum((t**(2*k+1)/F(2*k+1) for k in range(N)),F(0))
counts=[0,0]
# Inclusive rank, strict far left rank, and the corrected column coefficient.
masses=[F(1),F(2),F(4),F(8),F(16)]
for ws,K,h,a in product(product([F(1,2),F(1),F(2)],repeat=5),[F(2),F(3)], [F(1,4),F(1,2)], [F(1),F(2),F(3)]):
    J=sum(ws)
    T=[sum(ws[j] for j,m in enumerate(masses) if m<=M) for M in masses]
    Z=[sum(ws[j] for j,m in enumerate(masses) if m<M/K) for M in masses]
    B=max(T[i]-Z[i] for i in range(5))
    assert sum(ws[i] for i in range(5) if Z[i]<=h)<=h+B
    lhs=sum(ws[i]/(Z[i]-h) for i in range(5) if Z[i]>a)
    rhs=F(0) if J<=a else (a+B)/(a-h)*log_lower(J/a)
    assert lhs<=rhs
    for i in range(5):
        if Z[i]>a:
            left=sum(ws[j] for j,m in enumerate(masses) if m<masses[i])
            assert left>a
            assert 1/(Z[i]-h)<=(a+B)/(a-h)/T[i]
    counts[0]+=1
# Actual full-mass finite incidence pairs: exclusive laws and source conservation.
for f,K in product([(F(1),F(2),F(3),F(4)),(F(1),F(1),F(2),F(8))],[F(2),F(3)]):
    Q=[set(c) for k in range(1,5) for c in combinations(range(4),k)]
    m=[sum(f[x] for x in q) for q in Q]
    mu=[F(1,5)/mass for mass in m]
    for A in range(len(Q)):
        for y,z in product(Q[A],repeat=2):
            far=[w for w in range(len(Q)) if m[w]<m[A]/K]
            Zy=sum(mu[w] for w in far if y in Q[w])
            Zz=sum(mu[w] for w in far if z in Q[w])
            C=sum(mu[w] for w in far if y in Q[w] and z in Q[w])
            if Zy==C or Zz==C: continue
            py={w:mu[w]/(Zy-C) for w in far if y in Q[w] and z not in Q[w]}
            pz={t:mu[t]/(Zz-C) for t in far if z in Q[t] and y not in Q[t]}
            assert sum(py.values())==sum(pz.values())==1
            full=left=right=F(0)
            for w,pw in py.items():
                for t,pt in pz.items():
                    # Prescribed positive mask tests nonrenormalized restriction.
                    mask=F((w+t+A)%3!=0)
                    weight=pw*pt*mask
                    full+=weight;left+=weight/2;right+=weight/2
                    union=sum(f[x] for x in Q[A]&(Q[w]|Q[t]))/m[A]
                    assert union<2/K
                    assert z not in Q[w] and y not in Q[t]
            assert full==left+right and full<=1
            for a0 in [F(0),F(1,100),F(1,10)]:
                paid=remaining=sidey=sidez=F(0)
                for w,pw in py.items():
                    for t,pt in pz.items():
                        weight=pw*pt*F((w+t+A)%3!=0)
                        owny=sum(mu[k] for k in range(len(Q)) if y in Q[k] and m[k]<m[w]/K)
                        ownz=sum(mu[k] for k in range(len(Q)) if z in Q[k] and m[k]<m[t]/K)
                        ly=owny<=a0;lz=ownz<=a0
                        paid+=weight*int(ly or lz)
                        remaining+=weight*int(not ly and not lz)
                        sidey+=weight*int(ly);sidez+=weight*int(lz)
                assert paid+remaining==full and paid<=sidey+sidez
            counts[1]+=1
print('PASS column/exclusive:',*counts,'total:',sum(counts))
