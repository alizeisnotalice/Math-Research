#!/usr/bin/env python3
"""Frozen scalar product-integral floating probes; no geometric/Gram certificate."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
import argparse,hashlib,json,math,platform,resource,shlex,signal,sys,time
from pathlib import Path
import numpy as np
import scipy
from scipy.integrate import quad

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=Path(__file__).with_suffix('.json'));args=ap.parse_args();start=time.perf_counter()
 def timeout(*_):raise TimeoutError('60 second guard, no expansion')
 signal.signal(signal.SIGALRM,timeout);signal.alarm(60)
 def profile(n,kind):
  if kind=='equal':d=np.ones(n)
  elif kind=='single':d=np.zeros(n);d[0]=1
  elif kind=='geometric_12_decades':d=np.geomspace(1.,1e-12,n)
  elif kind=='alternating_zeros':d=(np.arange(n)%2==0).astype(float)
  elif kind=='all_zero':return np.zeros(n)
  else:raise ValueError(kind)
  return d/d.sum()
 def integrate(n,G,kind):
  d=profile(n,kind);log_s=math.log(G)/n;c=1+math.expm1(log_s)/2;log_c=math.log1p(math.expm1(log_s)/2)
  B=1+log_c+math.log1p(n*log_c)+math.exp(-1)/(1+n*log_c)
  if G==1 or kind=='all_zero':return {'n':n,'G':G,'profile':kind,'c':c,'B':B,'integral':0.,'scipy_quad_error_estimate':0.,'zero_by_identity':True,'breakpoint_count':0,'evaluations':0}
  cap=c/d.max();bp={0.,cap}
  for v in d[d>0]:
   for t in (1/v,c/v,(c-1)/v):
    if 0<t<cap:bp.add(float(t))
  points=sorted(bp);evals=0
  def f(t):
   nonlocal evals
   evals+=1
   if t==0:return float(d.sum()) # exact right limit when c>1
   if t>=cap:return 0.
   z=d*t;first=c-z
   if np.any(first<=0):return 0.
   L1=float(np.log(np.minimum(first,1.)).sum())
   if np.any(z>=1):return math.exp(L1)/t
   L2=float(np.log1p(-z).sum())
   gap=L2-L1
   if gap>1e-12:raise ArithmeticError('Product order failed numerically')
   return math.exp(L1)*(-math.expm1(min(gap,0.)))/t
  value=error=0.
  for lo,hi in zip(points,points[1:]):
   v,e=quad(f,lo,hi,epsabs=1e-10/max(1,len(points)-1),epsrel=1e-10,limit=100)
   value+=v;error+=e
  # The single-active case has an elementary integral, independently derived piecewise.
  single_exact=None;single_difference=None
  if kind=='single':
   # If c<=2: [0,c-1] gives1, [c-1,1] gives(c-1)/t,
   # [1,c] gives c/t-1. If c>2: [0,1] gives1,
   # [1,c-1] gives1/t, [c-1,c] gives c/t-1.
   if c<=2:single_exact=(c-1)*math.log(1/(c-1))+c*math.log(c)
   else:single_exact=math.log(c-1)+c*math.log(c/(c-1))
   single_difference=abs(value-single_exact);assert single_difference<1e-8
  slack=B-value
  if slack < -max(1e-8,20*error):raise AssertionError('Candidate upper bound numerically violated; stop without expanding')
  return {'n':n,'G':G,'profile':kind,'d_normalization_sum_float':float(d.sum()),'nonzero_d':int(np.count_nonzero(d)),'d_max':float(d.max()),'d_min_positive':float(d[d>0].min()),'c':c,'log_c':log_c,'B':B,'integral':value,'B_minus_integral':slack,'integral_over_B':value/B,'scipy_quad_error_estimate':error,'single_active_elementary_value_float':single_exact,'single_active_absolute_discrepancy':single_difference,'support_t_cutoff':cap,'breakpoint_count':len(points),'evaluations':evals,'zero_by_identity':False}
 jobs=[]
 for n in (2,8):
  for G in (2,16):jobs.append(('initial',n,G,'equal'))
 for n in (2,8):
  for G in (2,16):
   for kind in ('single','geometric_12_decades','alternating_zeros'):jobs.append(('pressure',n,G,kind))
 for n in (32,128,512):
  for G in (2,16,256):
   for kind in ('equal','single','geometric_12_decades','alternating_zeros'):jobs.append(('expanded',n,G,kind))
 for n in (2,8,512):jobs.append(('identity_guard',n,1,'equal'))
 for n,G in ((2,2),(512,256)):jobs.append(('identity_guard',n,G,'all_zero'))
 assert len(jobs)==57
 rows=[]
 for stage,n,G,kind in jobs:
  row=integrate(n,G,kind);row['stage']=stage;rows.append(row)
 nonzero=[r for r in rows if not r['zero_by_identity']]
 d={'scope':'57 frozen scalar product-integral probes only; no actual receiver geometry, continuous Gram, original root budget or dimension-order conclusion.','formula':'s=G^(1/n);c=(1+s)/2;S=sum d=1 unless separate zero identity. I=int_0^(c/maxd) [prod min(1,(c-dj*t)+)-prod(1-dj*t)+] dt/t. B=1+logc+log(1+n logc)+exp(-1)/(1+n logc).','numerics':'float64 products via log/expm1; every effective t=1/dj,c/dj,(c-1)/dj breakpoint included; origin right-limit S. scipy.integrate.quad errors are numerical estimates, NOT rigorous enclosures, exact errors or certified bound residuals.','profiles':'equal; single active; geometric decay from1 to1e-12 normalized S1; alternating nonzero equal weights and zeros; identity allzero handled separately outside sumS>0 hypothesis. G1 gives c1 and identically D0.','results':rows,'summary':{'case_count':len(rows),'positive_profile_cases':len(nonzero),'identity_cases':len(rows)-len(nonzero),'smallest_observed_slack':min(r['B_minus_integral'] for r in nonzero),'largest_observed_integral_over_B':max(r['integral_over_B'] for r in nonzero),'largest_scipy_error_estimate':max(r['scipy_quad_error_estimate'] for r in rows),'largest_single_elementary_discrepancy':max(r['single_active_absolute_discrepancy'] or 0 for r in nonzero)},'execution':{'interpreter':sys.executable,'python':platform.python_version(),'numpy':np.__version__,'scipy':scipy.__version__,'processes':1,'runtime_seconds':time.perf_counter()-start,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'command':shlex.join([sys.executable,*sys.argv])}}
 args.output.write_text(json.dumps(d,indent=2,sort_keys=True)+'\n');print(json.dumps({'summary':d['summary'],'execution':d['execution']}))
if __name__=='__main__':main()
