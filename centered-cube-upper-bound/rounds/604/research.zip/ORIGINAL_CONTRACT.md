# R604：R520 母账／R558–559 正 Gram 的最小原合同

**范围。** 仅抽取已归档定义及假设，不给新估计。关键答案：slow 不普遍强制 μQ_B(G)/m_old<G；同一固定 G、同一 bulk 上的 δ₁ 确切恢复 Q_bulk，且不换相位。δ₁ 不因此自动满足全行动 low-gap。

归档根路径为 `/Users/zhengzhihao/Math-Research-centered-cube-work/centered-cube-upper-bound/rounds/`。下文“Rk/member §”均指该目录 `k/research.zip` 中原成员及小节，直接只读核对；R559 的 `/tmp/ccu_r604_baseline559.tex` 与归档 `559/REPORT.tex` 的数学段一致。没有用后来 atomic/new-H 合同替代这里的 L¹ 合同。

## 1. 原输入、中心、t 和旧平方

- μ=f dy≥0，W<∞，μ≪Lebesgue；真实中心 B 属原可测 E，积分是**未归一的真实 Lebesgue dB**。原可测边长 R_B∈[a,b]，0<a≤b≤2a；Q(B,R)=B+[-R/2,R/2]ⁿ。
- m_B^old=μQ(B,R_B)=q_BR_Bⁿ>0，q≤q_B≤λ_band，q>0；r_band=λ_band/q。μ无额外密度帽，体积薄不能代替源质量小。
- t_B 是原父的固定可测权，0≤t_B≤S；它不依赖随后抽取的来源 y，不随动作 g 改变，不随删 low/rapid/top 或优化重算、归一或放大。没有 t_B 的正下界要求；t_B=0 是零核、零 score 分支，定义 α 时另列。正 Gram 证明只用此界；连接母账时必须用原 t_B，不能另选一个方便的权。
- γ>1 固定，s_B=log_γ m_B^old，旧核 k_B=t_BR_B⁻ⁿ1_{Q_B}(y)1_[s_B,s_B+1](σ)，真实窗变量用 Lebesgue dσ；源变量用原 dμ(y)。完整旧场 L=∫_E k_BdB，Q=||L||²_{L²(μ×dσ)}。

出处：R516/r516_proof.md §1；R518/r518_proof.md §1；R558/cover_next.tex “定义和真实测度约定”行31–64。t 的原边缘记法 ν=tσ、0≤t≤S 见 R495/r495_fractional.md §1；不需也不额外推断 t 的新可选自由。

## 2. 源格先固定，α 必须由冻结旧场定义

固定 0<β<1/2，以边长 ℓ=nb/β 的一个共同平移网格，保留距每个格面至少 b/2 的中心 E_i，源格为 C_i。由原完整交叉 score 选好这一个平移后冻结；所有候选边长≤b 的源盒均在对应 C_i。

L_i=∫_{E_i}k_BdB，Q_g=Σ_i||L_i||²≥(1−β)²Q。不同源格在来源变量上正交；μ≪dy 保格面 μ 零。定义

C=S[1+ln(γ r_band)]，A_n=1+n ln(b/a)，
ψ_i(B)=〈L_i,k_B〉，α_i(B)=ψ_i(B)/(C t_B q_B)∈[0,1]（t_B>0）。

α 测的是原冻结 L_i 对原核的 score，不是当前辅助 A_π 的价格或某优化投影的价格。不可删父后重新计算 L_i 或 α，再沿用原分支费用。

出处：R516/r516_proof.md §§2–3；R516/r516_geometry.md §§1–3；R518/r518_proof.md §1。

## 3. low → rapid → top → bulk：互斥原 score 分账

取 h 满足 0<h<min{1/6,log_γ2}，u₀=γ^h−1∈(0,1)。固定同一个有限 G>1；R518 原先写 G≤2，R520 已核准任意有限共同 G（可取固定对数幂），但所有下面费用保留。

1. low：α_i(B)≤1/A_n；其原交叉 score E_low≤CSW。
2. 在其补集 high 内，V_B=min{G^{1/n}R_B,b}，K_B=max{1+u₀,A_nα_i(B)}。rapid：μQ(B,V_B)≥K_Bm_B^old；slow 为 high 内补集，等号归 rapid。其原 score E_rapid≤CSGW。
3. 在 slow 内取 top={R_B≥b/G^{1/n}}，E_top≤CSGW。
4. 真正 bulk=slow\top，即 R_B<b/G^{1/n}，故 V_B=G^{1/n}R_B<b，完整动作 [1,G] 可用。

后文写 a≤R_B≤b/G^{1/n} 是对实际 bulk 的可用放松；它不把已付的等号 top 父重新纳入。若 G>(b/a)ⁿ，bulk 必空；按实际严格 top 定义，等号时也无 bulk。

所有 E_low,E_rapid,E_top 都是 Σ_i∫对应父 ψ_i(B)dB 的**原交叉 score**，不是各自子场的自平方。费用总计≤CS(1+2G)W，只付一次。rapid 付款用 μ 连续性选首达 K_Bm_B 的真实 P_B∈[R_B,V_B]；q_B≤G q(B,P_B)/K_B。top 用固定 b；两种 payer 不要求仍在原 density band，不能因此把它们当 bulk 中新的合法原带父。

出处：R518/r518_proof.md §§1–2；R518/r518_geometry.md §2；R519/r519_proof.md §1（top 的准确 ≥ 与付款）；R520/r520_geometry.md §1（任意有限 G 及完整母账）。

## 4. 全部 g 的真实质量合同；g=G 的确切答案

对原 bulk 和每个 g∈[1,G]，令 Q_B(g)=Q(B,g^{1/n}R_B)，

κ_B(g)=μQ_B(g)/m_B^old，u_B(g)=log_γ κ_B(g)，j_B(g)=floor(u_B(g)/h)。

μ≪dy 给真实质量曲线连续非降。唯一普遍质量窗是

1≤κ_B(g)≤κ_B(G)<K_B=max{γ^h,A_nα_i(B)}≤K_max=max{γ^h,A_n}。             (1)

**不是** κ_B(g)≤γ^h，也不是 κ_B(G)<G。只有额外 K_B≤G 时才由 (1) 推出 sub-G；一般高 α 时 K_B 可为 A_n 量级。新旧 density 真实比为 q_new(g)/q_B=κ_B(g)/g，故 slow 同样不普遍给 endpoint density 降低。

也没有一般下界 κ_B(G)≥γ^h：零增量 κ_B(G)=1 的父仍留在 bulk 的真实 phase 0，见 R522/r522_proof.md §1。R518/r518_geometry.md §3 的 K_B=A_nα_i>γ^h 只针对该稿另有原首达 T_B、已达 γ^h 倍的 H_i 子族；不可把该 H_i 合同加给 R520 的全部 high-slow bulk。

J=1+floor(log_γ K_max/h)，j∈{0,…,J−1}。在同一真实 j 内，

γ^{jh}q/G ≤ q_new(g) < γ^{(j+1)h}λ_band。

扩大 G 会改变 rapid/top/bulk，且相位 density band 比放大 G；不能冻结旧 bulk 同时声称相同分类仍成立。

出处：R518/r518_proof.md §§2–4，尤其行25–27；R520/r520_geometry.md §1；R520/r520_audit_pre.md 的“G扩大接口”亦明确保这些费用；R522/r522_proof.md §1。

## 5. 真实动作、测度及 R558 探索

Hilbert 空间是 H=⊕_{i,j}L²(μ|C_i×dσ)。对 B∈bulk∩E_i，动作唯一非零分量为

v(B,g)_{ij}(y,σ)= t_B/(gR_Bⁿ) ·1_{Q_B(g)}(y)
 ·1_[s_B+u_B(g),s_B+u_B(g)+1](σ) ·1_{j=j_B(g)}。

相位区间按 jh≤u<(j+1)h；每动作使用自己的实际 phase 与实际质量窗。π_B 是来源抽样前、可测、每父总概率恰为1、支持 [1,G] 的概率核；可为原子，不要求全支撑。中心仍为 dB，源仍为 dμ，窗仍为 dσ；不得改成源独立平方或父对角和。

A_π=∫_bulk∫v(B,g)π_B(dg)dB，E_π=||A_π||²=Σ_{ij}||A_{ij}||²，保同 (i,j) 内所有跨父 Gram。phase 是本定义的直和标签；比较回旧合场所需的 J 已在母账支付，不是物理上自动正交。

R558 合法完整探索为 p_G dg/g+p_Gδ_G，p_G=1/(1+lnG)。原终端 atom 保留；每父总质量1。全部场的帽 C_*(G)=S[1+ln(Gγ^{1+h}r_band)]。G=1 时此探索退为 δ₁；但“同 G 上选 δ₁”与“把 G 改成1再重分原分支”是两件事。

出处：R518/r518_proof.md §§3–4；R519/r519_proof.md §§2–3（可测性/端点）；R520/r520_geometry.md §2；R558/cover_next.tex 定义小节及“具体完整探索律”；R559/REPORT.tex §§1–3。

## 6. δ₁ 与 Q_bulk：无隐藏 phase，三个平方/score 不混

在同一固定 G 的**原 bulk** 上定义

L_{bulk,i}=∫_{bulk∩E_i}k_BdB，Q_bulk=Σ_i||L_{bulk,i}||²。

取 π_B=δ₁ 时 κ_B(1)=1，u_B(1)=0，j_B(1)=0；盒、系数、质量窗全部是旧的。因此

(A_{δ₁})_{i0}=L_{bulk,i}，(A_{δ₁})_{ij}=0(j≠0)，E_{δ₁}=Q_bulk。        (2)

这里没有按 endpoint phase 预分旧场，也没有做窗平移。Q_bulk≤Σ_i〈L_i,L_{bulk,i}〉=Q_g−E_low−E_rapid−E_top≤Q_g≤Q；一般这些量不相等。

R522 为 endpoint g=G 证明时才把旧父按终端 j_B(G) 预分为 L_{ij}^{old}；其 Q_group=Σ_{ij}||L_{ij}^{old}||²≤Q_bulk，有 Credit=Q_bulk−Q_group≥0，起点是 Q_group/G²。不能把这个辅助预分组误认为 (2) 中 δ₁ 的定义。

δ₁ 的支持内两抽价格振幅为0，但其**全行动** gap 仍为 E−∫inf_{1≤g≤G}〈A,v(B,g)〉dB，未必小。故不能自动对它套 R558/R559 的 low-full-gap 结论；其合法性只保证可直接代任意概率母账。

出处：R518/r518_proof.md §3（z=0 的真实 phase）；R522/r522_proof.md §§1,4（Q_group、Q_bulk 及 Credit）；R558/cover_next.tex 开头全 gap 定义；R520/r520_geometry.md §3 也明确两抽与全 oracle gap 的区别。

## 7. 母账和哪些费用没有消失

对覆盖**全部原 bulk** 的任意上述合法 π_B，记 d_h=1−3h，b₀=1−β：

Q ≤ b₀⁻²[G²J E_π/d_h² + 2CS(1+2G)W/d_h]，
R_*≤2√(D_clk WQ)，D_clk=1+log_γ r_band+n log_γ(b/a)。

此式含原空间边界、一次 low/rapid/top、真实 phase Cauchy 与正窗比较；没有新 miss。若只给部分 bulk 动作，余下原 score 必须显式加回，不能沿用无 miss 式。原入口、初始/删除/跳跃/未来被删来源、低强度、宽距离、极端比例、全部时间原子及极限费用继续保留；本最小合同没有重推或免除这些历史费。

充分吸收式仍需 E_π≤ξQ_bulk/G²+L(n)W，ξJ/(b₀²d_h²)<1，或另一实际全付款；δ₁ 的 (2) 本身当然不提供此严格吸收。R559 完整探索的新帽/平方估计仍带 A_n；不能从 (1)、(2) 或合法动作身份宣称已获 polylog W。

出处：R520/r520_geometry.md §1 式(3)；R558/cover.tex “首次进入、旧信用与母账回代”式 cover-ledger；R558/REPORT.tex §2；R559/REPORT.tex §4。R518 早期无 top 账为 1+G；R519/520 加上互斥 top 后准确为 1+2G，不可混用。

## 定向核验记录

只读上述必要归档小节和 R559 baseline，没有通读完整历史、改 repo 或其他作者文件。实际本机数学 venv Python/SymPy 1.14.0 核验 p_G(lnG+1)=1、q_new/q_old=κ/g、g=1 的 log 质量位移为0；均为精确代数。分支与定义由归档原文核对，不靠这些代数检查补造。没有新定理、LP、模型扫描或 PDF。本合同抽取完成，停止。
