# R672 S2 — an all-space slack-aware batch exchange, with the gain still unpaid

**Conclusion.** There is an explicit feasible batch modification, with new target weights not capped by the old q. It shares each old-source deduction across the entire batch and respects every positive-volume arrangement cell. Its exact objective gain is

    Delta = sum_h d_h t_h
            -(1/tau) sum_{i:q_i>0}|F_i| a_i,                 (1)
    a_i = ess sup_{x in A_i} R(x),
    R(x) = (H(x)+b(x)-1)_+/b(x) if b(x)>0, and 0 otherwise,
    H=sum_h t_h 1_{A_h},     b=sum_i(q_i/tau)1_{A_i}.

This holds whenever t_h>=0 and H<=1 a.e. The gain in (1) is **not** proved positive for a batch carrying the full Vrem. No all-space bound on its actual supremum deduction cost has been established. Thus this note does not prove Vrem<=AU+B tau(P0-U/tau), nor count an equivalent packing characterization as progress.

The route is independent of core counting, hull entropy and any unproved Astra construction. It gives the precise feasible correction first, then evaluates the complete available local-to-global fee and stops.

## 1. Frozen original variables

All A_i and d_i are the ORIGINAL packing parents and volumes. Write

    p_i=q_i/tau,   b(x)=sum_i p_i1_{A_i}(x)<=1 a.e.,
    sum_i d_i p_i=U/tau.

The packing variables range over the original finite family, including lost labels; unused labels have p_i=0. The additions t_h below are supported on actual remaining receiver labels, but may exceed q_h/tau, q_h, or the rate of any retained owner portion. For example an individual t_h=1 is allowed by the condition H<=1.

Original owners, source order, witnesses and pools are unchanged. The real target is the sum of the actual remaining disjoint receiver volumes, over every occupied subinterval, not one local group.

## 2. Exact full-space batch correction

Take any nonnegative addition vector t with H<=1. Define R and a_i by (1), and define the original packing weights

    theta_i=p_i(1-a_i)+t_i,                                  (2)

where t_i=0 outside the chosen remaining target labels. Since 0<=b,H<=1,

    0<=R<=H<=1,   0<=a_i<=1.                                (3)

To check the middle inequality when b>0 and H+b>1,

    R=1-(1-H)/b <= 1-(1-H)=H.

When H+b<=1, R=0; b=0 is harmless since H<=1.

At almost every x in each A_i, a_i>=R(x). Finiteness of the original family allows a common null set to be discarded. Therefore the deleted baseline load satisfies

    sum_i p_i a_i1_{A_i}(x)
       >=b(x)R(x)
       =(H(x)+b(x)-1)_+.

Consequently the new load obeys

    sum_i theta_i1_{A_i}
       <=b+H-(b+H-1)_+
       =min(b+H,1)
       <=1.                                                 (4)

All theta_i are nonnegative. This is a feasible vector in the ORIGINAL P0 problem, not a packing on auxiliary primed cubes. Formula (1) follows by expanding its objective. Hence

    P0-U/tau >= Delta.                                      (5)

The finite arrangement proof is completely explicit: subdivide by every original A_i and added A_h face; b,H,R are constant on each positive-volume open cell. Each a_i is the maximum R among the cells meeting the interior of A_i. The finitely many cell faces are null for the original a.e. constraints. No boundary value, pointwise witness alone, or selected subfamily of cells replaces this test.

This improves the cruder always-feasible correction a_i=ess sup_{A_i}H by using actual baseline slack. It also deducts from each source ONCE through a maximum over the whole batch, rather than summing a separate deduction for every target. Thus shared deductions are genuinely retained.

## 3. What the low-load receiver condition does and does not control

For a remaining target h in a fixed subinterval, the known geometry says g_G<=1 throughout B_h, with G the corresponding earlier fixed-scale ground set. The correction above needs R over all of A_i, and its b includes every positive original source, including sources outside that G.

The condition on B_h therefore does not itself bound a_i. A_h is a large parent containing its saturation cell as well as B_h. Its other cells can have baseline load b=1. An overlap of an old source A_i with A_h also does not imply that i is in J_h: it need not contain z_h and need not belong to the fixed source radius range.

Thus replacing the supremum deduction in (1) by an integral over X_h, by a low g_G value, or by a deduction only from incident core sources would lose the all-space feasibility proof (4). No such replacement is made.

At the actual positive-volume saturated cell for a lost target, b=1. There R=H. So a single-target addition cannot exploit baseline slack on that cell. The parent independently audits the stronger general single-target obstruction. The construction here is not claimed to evade it; only a JOINT batch could possibly amortize a deduction over multiple receiving parents.

## 4. The exact available one-subinterval batch and its full fee

Fix one actual subinterval B=[alpha,beta), beta/alpha=2^(1/n), and set

    w_h=|X_h|/d_h   for its remaining targets,
    t_h=w_h/(2c),    c=c0^n.                                (6)

This is a legitimate addition vector with no old-q cap. To prove H<=1, fix x. For each h with x in A_h, every point of X_h lies in Q(x,c0 beta). Also d_h>=(2alpha)^n and the actual X_h are disjoint. Hence

    sum_{h in B} w_h1_{A_h}(x)
      <=(2c0 beta)^n/(2alpha)^n
      =2c.

Thus the new target objective is exactly

    sum_{h in B}d_h t_h=V_B/(2c).                            (7)

Equations (1)-(5) give the valid net gain

    Delta_B = V_B/(2c)
              -(1/tau) sum_i|F_i| a_{i,B}.                  (8)

In particular a_{i,B}<=1 yields

    P0-U/tau >= V_B/(2c)-U/tau.                             (9)

This is the already recognized local packing payment. It is not a global bound for the sum Vrem.

One can retain a smaller source neighborhood cost by writing

    N_B={i:q_i>0 and |A_i intersect {R_B>0}|>0},
    U_{N_B}=sum_{i in N_B}|F_i|.

Then (8) implies Delta_B>=V_B/(2c)-U_{N_B}/tau. However the frozen nL_n incidence count does not bound how many N_B contain the same source. That count applies to sources in the target's fixed near pool. N_B instead includes ALL original parents meeting an actual overload cell. These two relations have not been compared by a proved estimate.

The exact local source-cost improvement therefore does not yet sum over all scales.

## 5. Evaluate the straightforward global combination

Let K be the number of occupied remaining subintervals. If K=0 then Vrem=0; the following discussion assumes K>=1. Combining their feasible target batches with coefficients gamma_B>=0 and sum_B gamma_B<=1 preserves H<=1. But its target objective is only

    sum_B gamma_B V_B/(2c),

which can be as small as Vrem/(2cK) for the uniform choice. The resulting unconditional full-family packing statement is merely

    P0>=Vrem/(2cK),
    Vrem<=2cK[U/tau+(P0-U/tau)].                            (10)

This explicit K fee depends on the number of occupied scales. The original problem permits arbitrary finite scale spans and gives no absolute bound on K. Hence (10) cannot be presented as the required absolute A,B inequality. This calculation spells out the loss rather than suppressing it by averaging over subintervals.

Taking larger coefficients to recover the complete Vrem requires a new proof of a global target load bound, or a different jointly feasible addition. Likewise, summing the local gains (8) would require a proved bound on the cumulative all-space deduction costs, with each old source treated correctly. Neither has been obtained.

## 6. Precise stopping point

The proposed batch mechanism is concrete and feasible; its additions are genuine original packing variables, its deletion is slack-aware, and the same source is never automatically deducted once per target. However there is no quantitative geometric settlement for

    sum_i|F_i| ess sup_{A_i}
        [(H+b-1)_+/b]

for a jointly feasible H with target objective comparable to the COMPLETE Vrem/tau. The actual high-witness/low-entire-B_h condition only controls a restricted earlier source field at the small receiving boxes, whereas this fee tests every overload cell in the original full parents.

I have not assumed that this supremum cost is necessary for every packing exchange; (2) is only one explicit sufficient construction. Its failure to yield the desired estimate is not an impossibility theorem for another joint modification. No tautological LP dual, generic hull count, selected-source column bound, abstract incidence scan or unverified geometric model is used as a substitute.

There is no new global positive-gain inequality in this bounded attempt. The one-subinterval bound (9) and global K-dependent bound (10) are stated with their full costs. The missing all-space batch settlement remains unproved, and this task stops here. No numerical experiment was warranted for that analytic gap; the parent owns any subsequent scripts and all integration.

