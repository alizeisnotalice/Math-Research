"""Exact all-open-cell checks of the batch repair, NOT R670 near-family instances."""
from fractions import Fraction as F
from pathlib import Path
import sys, json, hashlib

def fmt(x): return str(x)
def cells(cubes, n):
    # Every membership word of an open full-dimensional arrangement cell.
    # Each coordinate contributes an interval membership mask; intersect masks.
    reachable={(1<<len(cubes))-1}
    counts=[]
    for k in range(n):
        endpoints=sorted({y[k]+sgn*r for y,r in cubes for sgn in (-1,1)})
        mids=[endpoints[0]-1]+[(a+b)/2 for a,b in zip(endpoints,endpoints[1:])]+[endpoints[-1]+1]
        masks={sum(1<<i for i,(y,r) in enumerate(cubes) if y[k]-r<x<y[k]+r) for x in mids}
        reachable={a&b for a in reachable for b in masks}
        counts.append(len(reachable))
    return sorted(reachable),counts

def load(v,mask):return sum((x for i,x in enumerate(v) if mask>>i&1),F(0))
def run(n, radius, p0, tleft, tright, name, stage):
    zero=(F(0),)*n
    cubes=[(zero,F(1)),(( -radius,)+(F(0),)*(n-1),radius),((radius,)+(F(0),)*(n-1),radius)]
    masks,counts=cells(cubes,n)
    d=[(2*r)**n for _,r in cubes]
    p=[p0,F(0),F(0)]; t=[F(0),tleft,tright]
    assert all(load(p,m)<=1 and load(t,m)<=1 for m in masks)
    a=[F(0)]*3; simple=[F(0)]*3
    for m in masks:
        b,H=load(p,m),load(t,m)
        R=max(F(0),b+H-1)/b if b else F(0)
        assert 0<=R<=H<=1
        for i in range(3):
            if m>>i&1:
                a[i]=max(a[i],R);simple[i]=max(simple[i],H)
    theta=[p[i]*(1-a[i])+t[i] for i in range(3)]
    assert min(theta)>=0 and all(load(theta,m)<=1 for m in masks)
    gain=sum(d[i]*(theta[i]-p[i]) for i in range(3))
    deletion=sum(d[i]*p[i]*a[i] for i in range(3))
    crude=sum(d[i]*p[i]*simple[i] for i in range(3))
    assert deletion<=crude
    if name=='joint':assert gain>0
    if name=='single_saturated':assert gain<0
    if name=='loose':assert deletion==0 and crude>0
    if name=='boundary_equal':assert gain==0
    return dict(stage=stage,name=name,n=n,radius=str(radius),p=list(map(fmt,p)),added=list(map(fmt,t)),volumes=list(map(fmt,d)),open_membership_masks=masks,coordinate_state_counts=counts,slack_coefficients=list(map(fmt,a)),theta=list(map(fmt,theta)),gain=str(gain),deletion=str(deletion),crude_deletion=str(crude),all_open_cells_exact=True)

out=[]
for stage,dims in [('initial',[1,2]),('expanded',[4,16,256])]:
    for n in dims:
        r=1-F(1,4*n)
        out.append(run(n,r,F(1),F(1),F(1),'joint',stage))
        out.append(run(n,r,F(1),F(1),F(0),'single_saturated',stage))
        out.append(run(n,r,F(1,2),F(1,4),F(1,4),'loose',stage))
for n in [1,2,8]:
    out.append(run(n,F(1,2),F(3,4),F(1,2),F(1,2),'partial_overlap','boundary'))
out.append(run(1,F(1,2),F(1),F(1),F(1),'boundary_equal','boundary'))
# Bernoulli exact finite checks supplement (do not replace) the all-n proof.
assert all((1-F(1,4*n))**n>=F(3,4) for n in [1,2,4,16,256])
import sympy as sp
A,B,U,G,K,tau=sp.symbols('A B U G K tau', nonnegative=True)
account=(1+A)*U+B*G+K*U/tau
residuals=[sp.expand((1+A)*(U+G)+K*(U+G)/tau-account),sp.expand(B*(U+G)+K*(U+G)/tau-account)]
assert sp.simplify(residuals[0]-((1+A-B)*G+K*G/tau))==0
assert sp.simplify(residuals[1]-((B-1-A)*U+K*G/tau))==0
record=dict(sympy_version=sp.__version__,account_branch_residuals=list(map(str,residuals)),interpreter=sys.executable,python=sys.version,arithmetic='fractions.Fraction exact rational',script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),scope='Repair-rule fixtures only: baseline p0=1 or fractions, NOT actual admitted owners/q cap/high near-rate inputs. No C_n bound or near-family certificate.',stages=['initial','boundary','expanded'],case_count=len(out),cases=out)
Path(__file__).with_name('EXCHANGE_RESULT.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'cases':len(out),'all_open_cells':'PASS','n':[1,2,4,8,16,256],'arithmetic':'exact rational','scope':record['scope']}))
