# R672 A1 — global packing exchange: bounded geometric checkpoint

## Status

No new all-scale nonnegative feasible packing with a quantitative gain on the same full V_rem has been constructed. No new AU or uniformly absorbable receiver bound is claimed. The two concrete constructions considered below stop at exact all-space load inequalities; neither is promoted to a theorem about the packing surplus.

The original family and packing problem are retained:

    P0=max Σ_i d_i theta_i,
    theta_i≥0,   Σ_i theta_i1_{A_i}≤1 a.e.

The baseline p_i=q_i/tau is feasible and has objective U/tau. New packing weights are not required to obey theta_i≤q_i or theta_i≤|E_i|/d_i. Original self sources, actual owners and receivers, full original pools, histories and masks remain unchanged. The R670 fixed-subinterval geometry and R671 auxiliary minimum-mass certificates are used in their already audited scope.

## 1. A real packing for one fixed subinterval does not combine automatically

For a fixed remaining-target subinterval [a,b) with (b/a)^n=2, define

    r_h=|X_h|/(2c0^n d_h)

for its actual remaining targets, and set every other coordinate to zero. This is a concrete original-family packing, without reference to P0 or a dual optimizer.

Indeed, if x∈A_h then the whole small receiver box B_h is contained in Q(x,c0b). The actual X_h are disjoint, and d_h≥(2a)^n. Therefore for every x outside irrelevant boundaries,

    Σ_h r_h1_{A_h}(x)
       ≤|Q(x,c0b)|/[2c0^n(2a)^n]=1.                      (1.1)

Its objective is exactly the total remaining receiver measure in this subinterval divided by 2c0^n. The construction uses the true receiver masses and is feasible on every arrangement cell, not merely on B_h or at a witness.

This does not pay the full V_rem. Summing these packings over all subintervals may violate the all-space capacity constraint. Taking a convex combination preserves feasibility but loses the desired unweighted sum of all receiver measures. The old fact that each source belongs to only finitely many near-scale target buckets does not bound how many of these **new target-parent packings** can overlap at an arbitrary point: it concerns membership in actual near source pools, not arbitrary containment by target parents across all scales.

No geometric combination with a dimension-independent loss was found. Applying P0 separately to (1.1) and summing its objective bounds would repeatedly spend the same global P0; that is not an admissible global argument.

## 2. Why the local-damping exchange was not pursued further

An independently identified joint-damping formula takes an already feasible added packing r, with H_r=Σr_h1_{A_h}≤1, and attenuates old p using source-wise suprema of H_r, or its slack-aware variant. The complementary Sol owns the exact all-cell feasibility formula and proof; it is not duplicated here.

Its geometric limitation is decisive for this task. The added r must itself already solve an original-family packing constraint. A corrected packing of the form theta=p(1−alpha)+r has objective at most d·p+d·r, hence at most twice the larger of the two already feasible objectives. This cannot resolve the dimension bottleneck without first constructing a globally useful r. Optimizing the suprema alone would not supply that missing construction.

Moreover, an original target witness certifies only one saturation region of its parent. Adding positive weight on A_h must respect every saturated arrangement cell intersecting A_h, including cells involving other source pools. A common core at z_h is not a pointwise domination certificate throughout A_h. This prevents replacing the global deletion cost by the local minimum-mass core fee without a separate geometric inequality.

From the original greedy baseline, the independently audited obstruction rules out a positive gain from one residual-loss positive-coordinate move of the displayed form: its positive-measure saturated cell forces enough old-weight deletion to cancel that target's objective gain. Sequences that first change the baseline are not analyzed here. A quantitative all-space packing construction is still required.

## 3. The weaker aggregate-core packing route remains precisely unproved

Let a genuine cover of the same remaining receivers have nonnegative weights lambda_C and legal R671 auxiliary source weights t_i,C of total mu=tau/4 per core. Its actual optimized certificate cost is

    B_trim=e^(−mu/8) Σ_i d_i Σ_C lambda_C t_i,C.

Define the original-family nonnegative coefficients

    b_i=e^(−mu/8) Σ_C lambda_C t_i,C.                      (3.1)

A proof of the genuinely weaker all-space estimate

    Σ_i b_i1_{A_i}(x)≤A tau      for a.e. x               (3.2)

would immediately make theta_i=b_i/(A tau) a feasible original-family packing and give B_trim≤A tau P0. Together with the already paid branch and the full receiver cover, this would recover a global estimate of the intended kind. No upper bound b_i≤Cq_i would be necessary.

However, (3.2) was not established. Its exact relation to the known old-source load is, for positive q_i,

    Σ_i b_i1_{A_i}(x)
      =e^(−mu/8) Σ_i q_i1_{A_i}(x) R_i,
    R_i=Σ_C lambda_C t_i,C/q_i.                            (3.3)

The inherited inequality Σ_i q_i1_{A_i}(x)≤tau controls the measure in this weighted sum, not the cumulative fractions R_i. It therefore does not by itself prove (3.2). A uniform bound on all R_i would be sufficient but is stronger than necessary; what is missing is a jointly geometric bound on their q-weighted average over the parents containing each point.

The actual cube constraints retained in this attempt are substantial: cores are intersections containing their true witnesses; source owners are genuinely disjoint; all sources are in the fixed real scale range; the original source-center admission holds; g_G(z_h)>5tau/16 whereas g_G≤1 on every actual B_h; and later seeds in the concrete capture procedure lie outside earlier selected intersections. None was converted here into the needed weighted-average bound in (3.3).

In particular, cores containing a common point can have different witness hulls, and exclusion of a later seed from an earlier core can be caused by arbitrarily small retained rate. The legal capture rule supplies no quantitative missing-load separation. Counting orthants or using an exponential-in-n arrangement bound would not be absorbed by the available exponential-in-sqrt(n) local fee. No such count is used as a payment.

Equation (3.2) is recorded only as the exact unproved inequality for a concrete prospective packing (3.1), not as new progress obtained by renaming P0 or its dual. Its verification must cover all positive-measure arrangement cells. The low load on true receiver boxes or the high load at selected witnesses alone is insufficient.

## Final stopping point

The single-subinterval construction (1.1) is feasible but not combined across scales. The aggregate-core construction (3.1) is nonnegative but has no proved all-space load bound. Neither yields a quantitative net gain on the full V_rem over the baseline U/tau. The requested global packing exchange remains open.

No additional numerical experiment was run: no finite incidence scan or one-cell feasibility test could establish either missing all-scale geometric estimate. No MATLAB session, Git operation, PDF compilation, child agent, or edit to another agent's file was performed. This bounded task stops without expanding the equivalent-LP or local-deletion routes.
