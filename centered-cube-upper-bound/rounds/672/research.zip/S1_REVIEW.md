# R672：packing gain目标与single-target repair的独立前置审查

**结论：新gain目标对原完整总账充分，但改写本身没有新增估计。** 若真实全族Vrem≤AU+B·τ(P₀−U/τ)，A,B为绝对非负常数，则原all-L1/all-scale目标可闭合；其关键仍是构造同一original family上的非负全空间可行向量，并为同一完整remaining receivers证明定量gain。一般LP等价表述、baseline slack非负或局部exchange不能替代该步骤。

先读本轮TASK及必要R671 CONTINUE/原完整账，独立核验后写本文件；未读作者A1/S2候选结论。父代理随后另给的single-target命题也在读其未来稿之前独立核验，结论见第6–7节。只写本S1，不spawn/Git/PDF/MATLAB，不改他人文件。

## 1. 原family、admitted family及baseline不可混同

令O是原有限packing family，P₀=max{Σ_{i∈O}dᵢθᵢ: θ≥0，Σθᵢ1_Aᵢ≤1 Lebesgue-a.e.}。A是radius-descending admission留下的subfamily。残余qᵢ在A上产生，将其在O\A上延拓为0，pᵢ=qᵢ/τ是O上的全空间可行向量，Σdᵢpᵢ=U/τ。

admission-discarded labels与actual residual-loss labels是两回事：后者仍是A中的原变量，qₕ<wₕ但qₕ可正可零，当前h也可在其完整Iₕ中。不能把所有“loss labels”一律当作零baseline或原LP外的变量。

若P_A只优化admitted variables、仍要求全空间可行，则

P₀≥P_A≥U/τ。

A上的任何可行向量可zero-extend到O，objective保持，故在A上构造足够gain是更强的充分路线。但P₀与P_A不能宣称相等；在A上找不到gain不排除使用原未admit cubes改善P₀。

反过来，使用O\A的变量是允许的，但必须检查其完整原parent Aᵢ上的load。不能给这些labels编造原Fi owner容量；也不能把Ai′、Bi或新增任意方体当成同一P₀的packing变量。原V₀与原P₀的finite recovery接口需保持。

## 2. proposed surplus目标的精确充分性

写K(n)=Kfar+Kup(n)，继承

V₀≤Cadm[U+K(n)U/τ+Vrem]， P₀≥U/τ。

令G=τP₀−U≥0。假设对全部真实原输入和维数统一证明

Vrem≤AU+B G， A,B≥0。

取非负常数不失一般性，因为U,G≥0。令D=max(1+A,B)，则

(1+A)U+B G≤D(U+G)=DτP₀，

K(n)U/τ≤K(n)P₀。

所以

V₀/P₀≤Cadm[τ max(1+A,B)+Kfar+Kup(n)]。

用τ=16384√n、Kup(n)≤8e^(33/16)、n≥1，原all-input finite recovery给充分的统一bound

Cₙ≤Cadm[16384max(1+A,B)+Kfar+8e^(33/16)]√n。

原空family/零质量情形按既有finite recovery平凡处理，无需在P₀=0时作除法。这里没有重复R670 rim fee或先前mask费，也没有把Vrem改成单个group、selected-source重复上包络或某个bucket。

一个常见错误是展开成(1+A−B+K/τ)U+BτP₀后，不论系数正负都用U≤τP₀；当B>1+A+K/τ时这会反向。上述max形式避开此问题。

## 3. constructive gain必须说明什么

若B>0，一个足够的concrete结果是给出O上的θ≥0、全空间可行，且

Σdᵢθᵢ≥U/τ+(Vrem−AU)₊/(Bτ)。

P₀至少为该objective，便推出第2节target。若Vrem≤AU，则baseline已足够，不需要每个instance都存在strict gain。若P₀=U/τ，则target直接要求Vrem≤AU，不能无证假定surplus严格为正。B=0时退化为直接Vrem≤AU路线。

仅证明P₀−U/τ≥0、宣称“重复capture应带来gain”、写出LP dual、或在某个group上找到正gain，尚未把完整Vrem支付。不同局部exchanges可能重复使用同一baseline减权，不能把其objective gains独立相加。

从逻辑上，该uniform target不是自动弱于原main problem的新定理：若既有finite problem已经有V₀≤D₀τP₀，且Vrem≤V₀，则取A=B=D₀就得到Vrem≤D₀(U+G)。所以在absolute constants存在性的层面它与原uniform finite packing目标具有同等难度，不能将这种等价/充分改写列为成果。定量几何构造才可能新增进展。固定q的column cap仍不是原目标的必要条件。

## 4. 全空间可行性的有限精确核验

对原O的Ai取全部coordinate endpoints yᵢ,ℓ±sᵢ，形成finite axis-parallel arrangement。每个full-dimensional open cell上membership vector恒定。packing可行等价于

对每个正n维体积cell C， Σ_{i:C⊂Ai}θᵢ≤1，且θᵢ≥0。

只在lower-dimensional faces出现的load对Lebesgue-a.e.约束无影响；可选每个open cell内一个点检查，但任意有限采样点或普通grid未必代表全部cells。也可用analytic pointwise domination证明同一全空间约束，不必真的枚举指数多cells；证明范围不能缩水。

对exchange θ=p+Δ，需要

p+Δ≥0， Σ_iΔᵢ1_Aᵢ≤1−Σpᵢ1_Aᵢ 在每个full-dimensional cell，

以及ΣdᵢΔᵢ满足第3节量化要求。Δ可有负分量，候选θ不需要逐项≤qᵢ/τ或source-owner cap；那些是baseline的性质，不是原packing LP的约束。

以下不足以代替上述检查：source centers上的admission；仅Xh/Bh上的low-load；仅selected common intersections；把原Ai改为primed parents；只检pairwise overlaps；从同一baseline分别可行的几项局部改动未经协调一起相加。每个加权原parent都影响其整个Ai，包括Y外的区域。

## 5. 本机实际总账代数核对

使用已有Python数学环境/SymPy，未跑LP/matrix/反例扫描。对account F=(1+A)U+B G+KU/τ，实际符号输出：

- 当D=1+A时，D(U+G)+K(U+G)/τ−F=(1+A−B)G+KG/τ；在B≤1+A时非负。
- 当D=B时，同差为(B−1−A)U+KG/τ；在B≥1+A时非负。
- surplus代入展开残差为0。

它只核对本次新增fee代数，uniform geometry/gain尚无数值或解析证据。一般LP最优值的存在不等于已经证明所需下界。

## 6. 追加独审：single-target repair无正gain的精确范围

父代理在作者未来稿形成前给出statement；独立结论PASS。必须把“lost h”限定为actual **residual-loss admitted row** qₕ<wₕ，不是任意admission-discarded original label。后者未必有此饱和cell，不能套用本命题。

R660完整饱和前缀定理保证：对这样的h，可在Ah内选正n维体积membership cell，其prefix包含当前h且总q-load恰τ。最终positive q来源若覆盖该cell只能来自i≤h、故sᵢ≥sₕ、dᵢ≥dₕ；未来positive q不能在正测度部分进入，否则与最终全空间load≤τ矛盾。

即使原定理先按admitted-parent arrangement取cell，也可再用O全部有限parent faces细分，选其中一个正体积full-dimensional cell C⊂Ah。原额外labels的q为0，不改变baseline saturation。避免所有faces后所有membership在C恒定；不需要以单个零测度饱和点代替cell。由此baseline Σpᵢ1_Aᵢ=1在整个C上成立（a.e.足够）。

## 7. single-target exchange的gain证明及不能推出的结论

令θ=p+t e_h−δ，t>0、δ≥0、θ≥0，且θ对原O全空间可行。允许δₕ非零。令S_C={i∈O:C⊂Ai}，包括h。C上的packing约束给

Σ_{i∈S_C}δᵢ≥t。

“active”若只指positive baseline sources，会在qₕ=0但δₕ>0时漏项；必须像这里包括h或单独保留δₕ。

对i≠h，若δᵢ>0，则θᵢ=pᵢ−δᵢ≥0迫使pᵢ>0。若此i还在S_C，则饱和cell定理给dᵢ≥dₕ。i=h不论pₕ是否为0，都有dᵢ=dₕ。因此

Σ_{i∈O}dᵢδᵢ
≥Σ_{i∈S_C}dᵢδᵢ
≥dₕΣ_{i∈S_C}δᵢ
≥dₕt。

所以objective gain为

Σdᵢθᵢ−Σdᵢpᵢ=dₕt−Σdᵢδᵢ≤0。

若δₕ≥t导致h净减权，结论仍成立；无需额外禁止此表达。原O\A的零baseline variables也不能通过δ贡献减权（除h这个显式加权坐标外）；它们不破坏该证明。

这只说明单个residual target的这种one-positive-coordinate repair不能获正gain。对多个positive target additions，同一δ可能同时解除多个cell约束，逐target的cost估计不能无证相加；此命题不排除多target共享减权、其他原family labels或不同全空间交换。它不证明baseline P₀最优，也不支付Vrem。

## 8. 独立阶段交付

baseline/目标充分性、original-versus-admitted范围、全空间约束及single-target命题已在不读作者候选前审清。无新的gain、packing exchange或AU已被证明；第6–7节只是一个明确受限方向的阻碍。待具体候选形成只按授权实质审核，不把等价目标或finite LP表述当成果。本文件以外无写入，交付后停止等待候选。

## 9. S2候选：全空间batch repair与完整K费用

已在前置独立审查后读取S2_EXCHANGE.md。其repair数学公式PASS。

给定本身已满足H=Σrᵢ1_Aᵢ≤1 a.e.的非负addition packing r，令b=Σpᵢ1_Aᵢ≤1，R=(H+b−1)₊/b（b=0时0）。当overload正时R=1−(1−H)/b≤H，因为0<b≤1；其他点R=0。因此0≤R≤H≤1。aᵢ=ess sup_Aᵢ R∈[0,1]，有限family可选共同null set，使Σpᵢaᵢ1_Aᵢ≥bR=(H+b−1)₊。故θᵢ=pᵢ(1−aᵢ)+rᵢ非负，whole-space load≤min(b+H,1)≤1。

objective gain精确为d·r−Σdᵢpᵢaᵢ=d·r−(1/τ)Σ|Fi|aᵢ。aᵢ按entire batch取一次sup，没有逐target重复扣同一source，但真正需要的sup仍遍整个Ai，不能换成Xh/Bh积分、固定Jh或只在witness处扣费。S2对该缺口的说明准确。

单fixed subinterval的r_h=|Xh|/(2cdh)确是独立packing：若x∈Ah，则Xh⊂Q(x,c₀β)，真实Xh不交且dh≥(2α)ⁿ，给Σ(|Xh|/dh)1_Ah≤c(β/α)ⁿ=2c。其objective=V_B/(2c)，不限制新r_h为old q_h的fraction。对N个occupied subintervals，只作convex average给Vrem/(2cN)，N无uniform upper bound。N=0时Vrem=0，后续N分母只对N≥1使用；父代理已要求S2显式补此branch。

source-neighborhood N_B={old Ai与{R_B>0}有positive-volume交集}比原near pool incidence广，原nL_n source/target尺度计数不能直接控制它。S2没有漏掉这项global K/N费用，也未给出同一完整Vrem的正gain。

## 10. factor-two筛选：精确成立但不排除有用几何

独立核验父代理新statement，结论PASS。在S2构造中p和r都已经是original-family packings，且aᵢ≥0，所以

d·θ=d·p−d·(pa)+d·r≤d·p+d·r≤2max(d·p,d·r)。

更一般，对任意same-family feasible p,θ≥0，定义r=(θ−p)₊、δ=(p−θ)₊。componentwise 0≤r≤θ，因此packing可行域的downward closure给r也全空间可行；θ=p−δ+r，仍得同一个objective bound。

因此对已构造的θ，直接选p或r中objective较大者至少保留θ的一半。若希望改变维数阶，只优化扣减公式而不提供valuable all-scale r不能做到这一点；一个高价值θ也必给高价值的p/r之一。

这个筛选不证明exchange思路完全无用：构造r本身可能依赖joint cube geometry或exchange/optimality推理，且局部常数改进仍可能有用。general r的提取也以已有θ为前提，不能凭这个identity宣称新的packing已经构造。该结论不是P₀ upper bound，更没有支付Vrem。

## 11. A1 aggregate-b候选：具体但全空间bound未证

实际读取A1_EXCHANGE.md。one-subinterval packing与第9节相同；未通过convex averaging无成本拼成全尺度，处分准确。

对真实R671 receiver cover，bᵢ=e^(−μ/8)Σ_Cλ_Ctᵢ,C是explicit original-family非负vector，其objective正好Btrim。若另证H_b=Σbᵢ1_Aᵢ≤Aτ a.e.（A>0绝对），则b/(Aτ)为packing，给

Vrem≤Btrim=d·b≤AτP₀=A U+A(τP₀−U)。

这是第2节充分gain目标的A=B情形；不是已证结果。它不同于必须先证明Btrim≤AU的旧路线，也不要求每个bᵢ≤Cqᵢ或uniform fixed-q column cap。

该candidate的actual load仍是e^(−μ/8)Σ_{qᵢ>0}qᵢ1_Aᵢ·[Σ_Cλ_Ctᵢ,C/qᵢ]。旧Σqᵢ1_Aᵢ≤τ没有控制方括号的累计fraction，故全空间weighted-average bound仍未证明。不得称此式为新的budget或以只在receiver boxes上的low load认证它。所谓aggregate route“更弱”只应相对uniform per-source cap等足够条件理解，不能说所有旧weighted-total source预算与这个pointwise load目标之间已有必要蕴含。

## 12. single-target正文对照与顺序scope

MAIN_SINGLE_TARGET.md及REPORT的single-target证明与第6–7节独立证明一致，尤其D为full-dimensional positive-volume cell、包括self、qh=0时δh仍在S_D内、所有unadmitted变量zero-baseline不能被无中生有扣减。不是只在孤立witness点检查capacity。

需要保持一个额外scope：该阻碍针对原greedy baseline p的一次θ=p+t eh−δ，不是对任意已变化baseline的迭代定理。它不分析先作zero/negative-gain moves、改变饱和structure后再作单坐标动作的序列。已向父代理指出MAIN_SINGLE_TARGET/A1中“one at a time”应收紧为“from the original greedy baseline, a single residual-loss positive-coordinate move of the displayed form”，避免全局顺序结论过强。主报告正式命题本来已用固定p，数学公式无须改。

## 13. 最终脚本和19个fixture的证据范围

已读取EXCHANGE_CHECK.py原版和最终重跑版，并读取EXCHANGE_RESULT.json的全部case metadata与compact sign summary；未重跑作者fixtures。结果所录script_sha256与实际最终script相符，记录Python3.12.14、SymPy1.14.0、exact Fraction、19 cases及initial/boundary/expanded stages。

代码的all-open-cell检查是真正完整的有限fixture检查：每coordinate按全部端点分interval，取每interval内部点得到该坐标membership mask；不同坐标interval可独立组合，n维cube-membership恰是这些masks的bitwise AND。合并同membership words不丢任何load constraint，故不是任意grid抽样。它只枚举3cube有限membership words，不实际枚举dimension256的指数多点。

fixture中central cube半径1、两邻cube半径ρ且centers±ρ，其interiors不交。joint例ρ=1−1/(4n)满足Bernoulli ρⁿ≥3/4，因此joint value≥1.5倍old central value，single addition value较小。boundary_equal的closed cubes可在共享face上load>1，但该face为null，原a.e. packing允许，open-cell检查正确。其他case的正/零/负gain都按名称/结果记录，不被统一宣称positive。

这些p₀=1或simple fractions的3cube fixtures不满足R670真实admitted-owner/small-q/high-near-rate合同；dimension256这个数本身不会改变这一点。它们验证普遍repair公式及有限全cell实现，不证明任何actual near gain、global packing value或一般sqrt(n)定理。两分支SymPy residual只验证第2节总账代数，亦不认证geometry。

## 14. 最终简明签署

**PASS，无剩余必改项。** 已核对：gain目标完整总账、single-target正测饱和cell、S2全空间repair、factor-two筛选、A1 aggregate-b的未证load条件及19个fixture的有限scope。REPORT/A1已明确只排除从原greedy p直接作单residual-target正增益，不分析先改变baseline的zero/negative intermediate序列；S2已补K=0分支。未声称AU或新全尺度高价值packing。

最终实际读取并绑定：

- REPORT.tex：`9658d0238d51acf9557ed7037a41cd60d6d8234e62b2b2835bb89f0cb77912da`
- A1_EXCHANGE.md：`863d39a639e23383dcd5d1fa051fa705c50fa14d21f5483511d658e1eb84df46`
- S2_EXCHANGE.md：`10cc16c27ed844c77b4af3dcbd046dfcce537a268538bd9451766672861d5bd9`
- EXCHANGE_CHECK.py：`17d1720e5a85da91d3c9abe60a44b9c53a0bebe3c2ea203f0e5be01e2badd981`
- EXCHANGE_RESULT.json：`cdd88cb0d47f0c025cd159243b0a4fcc3e085d02ee81bfa050be3d61f2501587`

结果中19case及script digest与实际文件一致。未重跑fixtures；数学审核来自前述解析检查，不以hash替代证明。只写本S1，无spawn/Git/PDF/MATLAB，交付停止。
