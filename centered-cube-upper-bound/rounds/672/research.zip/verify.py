from pathlib import Path
import ast,hashlib,json,re
p=Path(__file__).resolve().parent
for name in ('EXCHANGE_CHECK.py','verify.py'):ast.parse((p/name).read_text())
r=json.loads((p/'EXCHANGE_RESULT.json').read_text())
assert r['case_count']==len(r['cases'])==19
assert all(c['all_open_cells_exact'] for c in r['cases'])
assert set(c['stage'] for c in r['cases'])=={'initial','boundary','expanded'}
assert r['script_sha256']==hashlib.sha256((p/'EXCHANGE_CHECK.py').read_bytes()).hexdigest()
s=(p/'REPORT.tex').read_text()
assert s.count(r'\begin{document}')==s.count(r'\end{document}')==1
stack=[]
for m in re.finditer(re.escape(chr(92))+r'(begin|end)\{([^}]+)\}',s):
 if m[1]=='begin':stack.append(m[2])
 else:assert stack and stack.pop()==m[2]
assert not stack
for name in ('REPORT.tex','A1_EXCHANGE.md','S2_EXCHANGE.md','EXCHANGE_CHECK.py','EXCHANGE_RESULT.json'):
 assert hashlib.sha256((p/name).read_bytes()).hexdigest() in (p/'S1_REVIEW.md').read_text(),name
m=p/'MANIFEST.json'
if m.exists():
 for name,v in json.loads(m.read_text())['members'].items():
  b=(p/name).read_bytes();assert len(b)==v['bytes'] and hashlib.sha256(b).hexdigest()==v['sha256']
print(json.dumps({'pass':True,'scope':'artifact integrity, saved exact-check records and audit bindings; not mathematical proof verification','manifest_checked':m.exists()}))
