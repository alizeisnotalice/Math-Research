"""Replay in a new temporary tree; never overwrite the frozen records."""
from pathlib import Path
import argparse,zipfile,tempfile,shutil,subprocess,sys
p=argparse.ArgumentParser();p.add_argument('mode',choices=['mass','transport','scale','verify']);p.add_argument('--r138',type=Path);p.add_argument('--r139',type=Path);a=p.parse_args()
root=Path(__file__).resolve().parent
if a.mode=='verify':
 subprocess.run([sys.executable,str(root/'verify_mass_direction.py')],check=True)
else:
 work=Path(tempfile.mkdtemp(prefix='cube-r140-replay-'));dest=work/'centered_cube_round140_20261015';dest.mkdir()
 if a.mode in ['mass','transport']:
  if not(a.r138 and a.r139):p.error('--r138 and --r139 point to prior research.zip archives')
  deps=[(a.r138,'core_capacity_probe.json','centered_cube_round138_20261015'),(a.r139,'active_traffic_v2.json','centered_cube_round136_20261014')]
  if a.mode=='mass':deps.append((a.r139,'joint_objective_probe.json','centered_cube_round139_20261015'))
  for archive,name,folder in deps:
   with zipfile.ZipFile(archive) as z:
    candidates=[f for f in z.namelist() if Path(f).name==name];assert len(candidates)==1
    d=work/folder;d.mkdir(exist_ok=True);(d/name).write_bytes(z.read(candidates[0]))
 script={'mass':'mass_direction.py','transport':'transport_check.py','scale':'scale_price_check.py'}[a.mode]
 extras={'mass':['mass_direction.md'],'transport':['transport_check_protocol.md'],'scale':['scale_price_protocol.md']}[a.mode]
 for f in [script]+extras:shutil.copy2(root/f,dest/f)
 print('Fresh replay directory:',dest,flush=True)
 subprocess.run([sys.executable,str(dest/script)],check=True)
