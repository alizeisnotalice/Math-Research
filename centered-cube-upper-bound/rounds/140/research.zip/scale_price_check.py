from pathlib import Path
import sys,json,hashlib
sys.path.insert(0,'/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor')
import mpmath as mp
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'scale_price_check.json'
if OUT.exists():raise SystemExit('Refuse overwrite')
def calc(n,which,dps):
 mp.mp.dps=dps;nmp=mp.mpf(n);g=1+1/nmp;ell=1+mp.log(nmp);jstar=int(mp.ceil(4*mp.log(nmp+1)/(nmp*mp.log(g))));j=[jstar-1,jstar,jstar+1,n//4][which]
 cj=g**(-j);r=g**(-mp.mpf('.5'));L=cj*cj*r*r;H0=mp.mpf('.9')*L;phi=mp.mpf('.5')-mp.expint(3,1);ms=H0/(mp.sqrt(cj)*r*ell**(1/(2*nmp)));s=(1-ms)/(1-phi)
 logratio=nmp*mp.log(H0/ms);logbound=mp.log(ell)/2+nmp*mp.log(cj)/2;price=36*mp.log(2)
 checks={'soft':0<s<1 and s>1-2**(-1/nmp),'dimension':nmp>4e6*mp.log(nmp+2),'no_clamp_reverse':mp.mpf('.5')<=H0<L<min(1,g*L),'proportional_band':cj/g<mp.sqrt(L)<cj,'kernel_price':logratio<=logbound,'constant':price<25,'planned_branch':(nmp*mp.log(cj)/2<=-2*mp.log(nmp+1))==(which!=0)}
 return {'n':n,'j':j,'jstar':jstar,'L':L,'H0':H0,'s':s,'logratio':logratio,'logbound':logbound,'constant':price,'new_branch':which!=0,'checks':checks}
rows=[]
for stage,n in [('initial',10**8),('pressure',10**9),('expanded',10**10)]:
 for which in range(4):
  a=calc(n,which,60);b=calc(n,which,90);err=max(abs(a[k]-b[k]) for k in ['L','H0','s','logratio','logbound','constant'])
  checks=b.pop('checks');passed=all(checks.values()) and err<mp.mpf('1e-35')
  row={k:(mp.nstr(v,90) if isinstance(v,mp.mpf) else v) for k,v in b.items()};row.update(stage=stage,checks=checks,precision_error=mp.nstr(err,15),pass_all=passed);rows.append(row)
out={'protocol_sha256':hashlib.sha256((ROOT/'scale_price_protocol.md').read_bytes()).hexdigest(),'scope':'parameter and core-kernel scalar checks, not FULL or general proof','dps':[60,90],'tolerance':'1e-35','cases':rows,'passed':sum(r['pass_all'] for r in rows)}
OUT.write_text(json.dumps(out,indent=2)+'\n');print('PASS',out['passed'],'/',len(rows))
