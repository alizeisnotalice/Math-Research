from pathlib import Path
from fractions import Fraction as F
import json,hashlib
ROOT=Path(__file__).resolve().parent
BASE=ROOT.parent
paths=[BASE/'centered_cube_round136_20261014/active_traffic_v2.json',BASE/'centered_cube_round138_20261015/core_capacity_probe.json']
src,cap=[json.loads(p.read_text()) for p in paths]
def fr(x):return F(str(x))
def jf(x):return F(int(x['numerator']),int(x['denominator']))
def dec(x):return format(float(x),'.12g')
results=[]
for case,cc in zip(src['cases'],cap['cases']):
 assert case['id']==cc['id']
 m=jf(cc['winner_cells'][0]['lower']);atoms=case['atoms'];D=fr(case['parameters']['D']);T=fr(case['derived']['T']);nu=[fr(a['nu']) for a in atoms[:4]];nu += [1-sum(nu)-m,m]
 K=[fr(a['K0']) for a in atoms];J=[fr(a['J']) for a in atoms];A=[fr(a['A']) for a in atoms];U=[jf(x['rebuilt']) for x in cc['rebuilt_U_audit']]
 sums={lab:jf(v['slope'])*m+jf(v['intercept']) for lab,v in cc['affine_coefficients'].items()}
 q=max(sums[k] for k in ['Q0','QJ','Qstar']);Q0=sum(ni*ki for ni,ki in zip(nu,K));alpha=(D*q-sum(ni*ui for ni,ui in zip(nu,U)))/sums['QJ'];zeta=alpha*sums['QJ']/(D*q)
 eta0=[ni*ki/q for ni,ki in zip(nu,K)];etaU=[ni*ui/(D*q) for ni,ui in zip(nu,U)];etaR=[a-b for a,b in zip(eta0,etaU)]
 assert all(x>=0 for x in etaR) and 0<=zeta<=1
 assert sum(etaU)==1-zeta and sum(etaR)==zeta-(1-Q0/q)
 assert all(U[i]==0 or atoms[i]['E'] for i in range(6))
 c=[U[i]/(T*A[i]) if A[i]>0 else F(0) for i in range(6)]
 rho=[max(1-(U[i]+alpha*J[i])/(T*A[i]),F(0)) if atoms[i]['good'] and A[i]>0 else F(0) for i in range(6)]
 assert all(c[i]+rho[i]<=1 for i in range(6))
 for seg in case['score_segments']:
  t=(fr(seg['lo'])+fr(seg['hi']))/2;w=[fr(ci)*t**(-ki) for ci,ki in zip(seg['c'],seg['k'])];e=sum(ni*wi for ni,wi in zip(nu,w));pi=[ni*wi/e for ni,wi in zip(nu,w)]
  assert all(e*U[i]/(D*q*w[i])*pi[i]==etaU[i] for i in range(6))
 results.append({'id':case['id'],'stage':case['stage'],'time_midpoints':len(case['score_segments']),'pass':True,'zeta':dec(zeta),'etaU_mass':dec(sum(etaU)),'hard_CORE_consumed_fraction':dec(U[5]/(D*K[5])),'hard_CORE_c':str(c[5]),'positive_rho_names':[atoms[i]['name'] for i in range(6) if rho[i]>0]})
out={'scope':'exact identities for saved rational coefficients only; not FULL, original transcendental enclosure, or global estimate','input_sha256':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths},'cases':results,'passed':len(results),'score_midpoints':sum(c['time_midpoints'] for c in results)}
(ROOT/'transport_check.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(out['passed'],out['score_midpoints'])
