# R140：外硬来源的捕获测度、三来源缺陷与第二时间接口

状态：JT1–JT10为来源检查点，JT11–JT18给真实core比例带付款及统一选择器接合；本文不声称大Γ补集的一般根阶闭合。仅处理原RT2正交通的准确分解，负项原位保留。固定比例带的[a,b]先于V、y、t，禁止跨绝对尺度免费取上确界。以下共同核、容量与集合在外硬z积分前选定，不能逐z重选。

## JT1. 原行、支持及零行

固定合法有限截断中的ω,V,j,x,y及共同实际s,L,R,g,H,T,D,q,ν,E,U,J,Q_J,α，再固定t∈J_far⊂[τ,h]。记u为内bad来源、v为内good来源、z为外hard来源。ν任意相关。使用原合同

\[
Q_0=\int K_0d\nu\le q,\quad Q_J=\int Jd\nu\le q,
\quad U=1_E\min(TA,DK_0),\quad A=w_\tau-w_h,
\quad E\subset S_g\subset Z_g\subset Z_t,
\]
\[
\alpha Q_J=Dq-\int U d\nu
=D(q-Q_0)+\int(DK_0-U)d\nu.
\tag{JT1}
\]

实际s>0使K₀,J严格正，原C使w_t严格正。q=0或Q_J=0迫使ν=0，沿原零交通约定处理，不计算0/0。e_t=0时ν(E)=0，捕获支为零，原两后验交通按原约定为零。以下仅在q,Q_J,e_t>0行使用商。

## JT2. 将外hard来源拆为已捕获与剩余

令

\[
\eta_0=K_0\nu/q,\quad \eta_U=U\nu/(Dq),\quad
\eta_R=(DK_0-U)\nu/(Dq),\quad \zeta=\alpha Q_J/(Dq).
\]

则是测度恒等式η₀=η_U+η_R，且

\[
\|\eta_0\|=Q_0/q\le1,\quad \|\eta_U\|=1-\zeta,
\quad \|\eta_R\|=\zeta-(1-Q_0/q)\in[0,\zeta],\quad0\le\zeta\le1.
\tag{JT2}
\]

η_U支持E，故η₀(Z_tᶜ)=η_R(Z_tᶜ)≤ζ。这只支付K₀加权的丢失存活支持质量，不支付hard质量。精确外源转换为

\[
q^{-1}h_R(x-z)d\nu(z)
=\frac{h_R(x-z)}{K_0(x-z)}(d\eta_U+d\eta_R)(z).
\tag{JT3}
\]

剩余支仍带h_R/K₀；FIRST松弛1−Q₀/q不能再作为一份来源或容量。ζ=1时η_U=0，不作其条件归一化。

## JT3. 同一Π_t下的真实三来源表示

令c(z)=U(z)/(TA(z))于A>0，并于A=0置0。E外c=0。在E上

\[
c=\min(1,DK_0/(TA)),\qquad
\rho=[1-c-\alpha J/(TA)]_+.
\]

沿原约定在E外ρ=0，令d=1−c−ρ≥0。E上d=min(αJ/(TA),1−c)，E外d=1。于是c+ρ+d=1逐源成立。

实际正w_t给η_U≪Π_t，且

\[
\frac{d\eta_U}{d\Pi_t}(z)
=\frac{e_tU(z)}{Dq w_t(z)}
=\frac{Te_t}{Dq}\frac{A(z)}{w_t(z)}c(z).
\tag{JT4}
\]

密度积分恰为1−ζ，非1。保留Te_t/(Dq)和A/w_t；high提供的e_t下界不构成该密度的上界。

把原RT2在H<L⁺、C_J(v)≤3及R139已付子支补集上的其余非负门写为G_t(z,v,u)。它完整包含原截断、1_{j(x)=j}、high、a_ω(x,y,z)、Ψ(v,u)、χ_FA(v,u)、1_{D_g}(u)1_{S_g}(v)以及该补集门；0≤G≤1，允许其真实z依赖。定义

\[
W_t(z,v,u)=\frac{h_R(x-z)A(z)}{K_0(x-z)w_t(z)}
\delta_t(v,u)G_t(z,v,u),\quad
\delta_t(v,u)=[k_t(v)-k_t(u)]_+.
\]

则捕获外hard支的固定t正积分，连同原p，精确等于

\[
p\,\frac{Te_t}{Dq}
\int W_t(z,v,u)c(z)\rho(v)
\,d\Pi_t(z)d\Pi_t(v)d\Pi_t(u).
\tag{JT5}
\]

外面仍为原EΣ_{V,j}、dx、dβ_V(y)、dt/t。此为额外外源的换测度，两份内来源所含e_t分母没有删除；Te_t只是第三份Π转换产生的精确系数。β没有替换为ν。

## JT4. 跨来源互补的精确加权缺陷

固定u，置W^σ(z,v,u)=W(v,z,u)、M=min(W,W^σ)、R_W=(W−W^σ)_+。交换z,v的同一Π_t乘积给

\[
\begin{aligned}
\int Wc_z\rho_v
={}&\frac12\int M\{c_z(1-c_z)+c_v(1-c_v)
 +(c_z-c_v)^2-c_zd_v-c_vd_z\}\\
&+\int R_Wc_z\rho_v .
\end{aligned}\tag{JT6}
\]

所有积分均对Π_t³。证明：W=M+R_W，M对z,v对称；对称部分为½∫M(c_zρ_v+c_vρ_z)，代入ρ=1−c−d展开即得。无需任何可积性即可将JT6写成非负扩展积分身份：把½∫M(c_zd_v+c_vd_z)移到左边，其余右边项全部非负，Tonelli成立。只有两边相关项有限时才用显示的减法形式，不作∞−∞。

交换必须连同δ(v,u)变δ(z,u)、FA、Ψ、hard支持、history及补集门全部交换，不能只交换c和ρ。式中负量是同一正积分的代数分解，不是N_del或已消费N_Z的可领取负账。

在H₀≥a、D≥1时，H≤H₀。设κ=(H₀/H)^n，m_s=1−s+sφ(1/2)，TH₀^n=m_s^n。z∈Q_H(x)时K₀(x−z)≥Tκ≥T。若另z∈E，则c_z=1；同一核心上ρ_z=0。因此ρ_v>0必有v∉Q_H(x)。对额外限制外z∈Q_H的捕获正交通，交换后的外v不满足该核心门，W^σ=0。故在c_zρ_v>0的实际正贡献支有M=0；准确的全域结论为M c_zρ_v=0几乎处处，全部正贡献由R_W承载。同源互补不能免费支付跨源交通。这也说明有限模型的hardCORE在Z_t且U=TA，并不自行消去残留。

本节没有断言一般下钳位H=a>H₀时核心ρ为零；该断言至少需Dκ≥1。

## JT5. 捕获时间流：不得把第二时间r压成原t

先区分两种捕获系数：c_U=U/(TA)用于同源互补，而原hard质量的消费比例是χ_U=U/(DK₀)。两者不同；核心c_U=1仍可能χ_U≪1。JT3中η_U只代表χ_U份hard交通，η_R代表1−χ_U份，未覆盖后者。

固定z∈E⊂Z_g。对r∈[τ,h]，原乘积w_r绝对连续，除有限个阈值外满足−r∂_r w_r=k_r w_r；故

\[
A(z)=\int_\tau^h k_r(z)w_r(z)\frac{dr}{r}.
\tag{JT7}
\]

E上的来源在整个区间存活，因而w_r1_Eν=e_r1_EΠ_r。定义同一接收点上的非负捕获流

\[
d\mathcal C_x(r,z)=\frac{T}{Dq}
 e_r1_E(z)c_U(z)k_r(z)d\Pi_r(z)\frac{dr}{r},
\qquad \tau\le r\le h.
\tag{JT8}
\]

c_U由该行终端A=w_τ−w_h定义，不随新积分r重选。e_r=0的切片按原零源约定置零；等价原始写法为(T/(Dq))1_E c_U k_r w_r dν dr/r，消除了该切片的概率商。Tonelli及JT7给

\[
\int_\tau^h\mathcal C_x(dr,dz)=d\eta_U(z),
\qquad \|\mathcal C_x\|=1-\zeta.
\tag{JT9}
\]

记F_t(x,z)=∫G_t(z,v,u)ρ(v)δ_t(v,u)dΠ_t(v)dΠ_t(u)。则捕获正交通准确为

\[
P_U=\mathbb E\sum_{V,j}\int p(x-y)dx\,d\beta_V(y)
\int\frac{h_R(x-z)}{K_0(x-z)}d\mathcal C_x(r,z)
\int_{J_{far}}F_t(x,z)\frac{dt}{t}.
\tag{JT10}
\]

这是在非负积分中对z、r、t换序；r和t是两个不同时间。原δ_t、两份Π_t、FA/Ψ仍位于t层；不以k_r(z)替代k_t(z)，不假设Π_r=Π_t。C_x依赖x、E、共同α/终端数据，不能把它移到dx外。JT10没有赋予U任何N_del身份。

## JT6. 捕获核心的真实核价和全部选择费用

在原hard支，B=1_{R≤L}1_{Q_R(x)}。R≤L时hard来源上U=0，故其捕获交通为空。考虑R>L及z∈Q_R(x)∩Q_H(x)。真实核在H盒中给K₀≥H^{-n}m_s^n，而h_R=R^{-n}。使用准确H₀=g c_j^{-1/2}m_s ell^{1/(2n)}，g²=LR和L/g≤c_j，得到

\[
\frac{h_R(x-z)}{K_0(x-z)}
\le\left(\frac{H}{Rm_s}\right)^n
=\sqrt\ell\left(\frac{g}{R\sqrt{c_j}}\right)^n
 \left(\frac H{H_0}\right)^n
\le\sqrt\ell\,c_j^{n/2}\left(\frac H{H_0}\right)^n.
\tag{JT11}
\]

H₀≥a时H≤H₀，包括未钳位及上钳位，最后因子≤1。H₀<a的下钳位必须保留该因子；H<L⁺本身不等同下钳位。本核比系旧真实尺度恒等式的直接应用，不单独登记为新几何定理。它对η₀=η_U+η_R均成立，不局限捕获份额。

由JT2及JT9，当前实际行的核心hard质量满足

\[
\int_{Q_H}\frac{h_R}{K_0}d\eta_0
\le\sqrt\ell\,c_j^{n/2}\frac{Q_0}{q}
\le\sqrt\ell\,c_j^{n/2}
\quad(H_0\ge a,R>L).
\tag{JT12}
\]

捕获份额可将Q₀/q换成1−ζ，储备份额可换成ζ−(1−Q₀/q)。三者不能各自算一份全质量。JT12直接控制整份核心hard来源，不要求z∈Z_t，不使用e_t下界或ν总质量帽。这一加强由FIRST核质量产生；第二时间流用于保留细致来源关联，并非JT12成立的必要条件。

使用R117/R139已证的接收选择器包络

\[
D_n=1+\frac\pi2\sqrt n\le3\sqrt n,
\qquad \int\sup_{s\in[0,1],L\in[a,b]}P_{s,L}(x-y)dx
\le3(2n+3)D_n.
\tag{JT13}
\]

这是固定尺度带的真实dx费用，含连续soft参数及至多2n+3个L网格点；不视为免费。作为核验：固定L用潜在Bernoulli混合展开得∫|∂_sP|≤√n/√(s(1−s))，积分s给π√n；函数变差包络再加两端质量给D_n。L向上γ网格使用p_{s,L}≤γ^n p_{s,L_grid}≤3p_{s,L_grid}。此工具已有历史，不计新定理。

仅用δ_t≤n、Π_t概率质量及JT12可给全比例带核心的粗价；下节明确共同时间窗和唯一j的合并顺序。

## JT7. 统一接收付款引理：消源后再合并唯一j

对每个ω,V,x,y,j,t，设原正项在积分外hard来源及两份Π_t之后，得到非负量I_j(x,y,t)，其中保留了原ρ、history及任何欲支付子支的门。假设已逐行证明I_j≤B，B为与j,x,y,t,V无关的共同数值；p不包含在I_j内。则

\[
\boxed{
2\Lambda\mathbb E\sum_{V,j}\int p\,dx\,d\beta_V(y)
 1_{\{j(x)=j\}}\int_{J_{far,j}}I_j\frac{dt}{t}
\le6\Lambda B\log2\,(2n+3)D_nW_\beta.}
\tag{JT14}
\]

证明次序不可倒置：先完成三来源积分及其上界I_j≤B。实际τ_j=a/c_j≥a，h≤g≤bc_j≤b，故所有J_far,j⊂[a,b]。把时间门放松为共同[a,b]后，对每个x有Σ_j1_{j(x)=j}≤1。再用∫_a^b dt/t≤log2、JT13和原Wβ=EΣ_V∥β_V∥。若p原先按j表示，唯一j所选p仍受同一个sup_{s,L∈[a,b]}P_{s,L}支配。β_V在接收点前构造，既不依j(x)也不被改成ν_V。

这里没有在仍带来源或history时提前删除j，没有将不同j的概率或时间窗识别为同一个；它们先被同一数值帽消去。既然如此，R139粗付款中在此阶段额外乘j数不是必要费用。这不授权对仍含Π_t、FA、共同α或不同j能量的表达式免费合并j。

例如JT12及δ≤n给B=n√ell，故整份core在R>L,H₀≥a上的粗价格为

\[
2\Lambda P_{core,H_0\ge a}
\le6\Lambda n\log2\,(2n+3)D_n\sqrt\ell W_\beta.
\tag{JT14a}
\]

仍为O(n^{5/2}√ell)，不是一般目标。

## JT8. 无需小Γ的整份core比例带付款

**量词与覆盖。** 对每个实际合法输入及有限正交通截断，在H<L⁺、C_J(v)≤3和原R139已付支补集内，进一步限制R>L、H₀≥a、外z∈Q_H，以及共同实际比例带条件

\[
\mathcal J_*:\qquad c_j^{n/2}\le(n+1)^{-2}.
\tag{JT15}
\]

这次包括整份η₀，既含捕获也含储备；不要求外hard来源存活Z_t，不要求Γ小。条件只依共同j，不能逐当前外z重选。保留全部t∈J_far、原低score、FA/Ψ与ρ。所得交通记P_{core,*}，则

\[
\boxed{2\Lambda P_{core,*}\le25\Lambda\sqrt{n\ell}\,W_\beta,
\qquad \ell=1+\log n.}
\tag{JT16}
\]

证明：先以JT12完成外hard来源积分，原门至多1；再以ρ≤1、δ_t≤n及两份Π_t的总质量1得到共同数值B=n√ell/(n+1)²。此后方可用JT14。于是

\[
2\Lambda P_{core,*}
\le\frac{6\Lambda n\log2(2n+3)}{(n+1)^2}
 D_n\sqrt\ell W_\beta
\le36\Lambda\log2\sqrt{n\ell}W_\beta
<25\Lambda\sqrt{n\ell}W_\beta,
\]

因为n(2n+3)/(n+1)²≤2、D_n≤3√n。无来源独立性、e_t下界或β/ν互换；没有使用负项或重领α容量。

JT15等价j≥ceil[4 log(n+1)/(n log(1+1/n))]，约为j≥4 log n。它必须与真实可用j带相交；窄尺度带或小n可能为空，不能声称每个输入都有覆盖。尺度比允许时，覆盖整个原t窗口和允许soft范围，不依赖t→g的窄条带，也不只覆盖hard消费份额。本文不据此认证现有数值点已落入JT15。

## JT9. 同一付款引理放宽HM阈值，仍保留原联合容量

R139 HM5/HM8对外z积分前共同选定的S及λ_S>0给

\[
q^{-1}\int_S h_R(x-z)a_\omega(x,y,z)d\nu(z)\,\rho(v)
\le\Gamma_S(v).
\]

S、λ_S可依ω,V,j,x,y,t,v和共同容量数据，但不能依当前z逐源重选。若将正支门改为Γ_S(v)≤(n+1)^{-2}，先完成该外源联合上界，再用δ≤n及Π_t²质量，得到B=n/(n+1)²。应用JT14可得

\[
\boxed{2\Lambda P_{HM,\Gamma\le(n+1)^{-2}}
\le25\Lambda\sqrt n\,W_\beta.}
\tag{JT17}
\]

原HM共享α容量和hard×ρ优化完整保留，只减少消源后的冗余j计数。在R139旧已付支补集内可登记的新增范围是(n+1)^{-3}<Γ_S≤(n+1)^{-2}，或对重新选定合法S的尚未付款来源域；不得将旧支价格再领取。与JT16相交时先从其中一个正支删除交集，然后分别记价。若直接对并集记价，安全总价为25Λ(√ell+1)√n Wβ，各负项仍只使用原一次。

这个放宽没有证明Γ大域的一般质量界，也没有证明12个有限模型被新增阈值覆盖。

## JT10. 保留的单一几何接口及未覆盖账

本稿两项有实际外测度价格的结果是JT16整份core的高j子支与JT17放宽后的共同hard–ρ阈值；它们在原R139补集内先去重再登记，未要求e_t下界或hard z∈Z_t。JT16基于准确H₀尺度和FIRST；JT17沿用原共同α容量，新的接合是三来源消去后使用唯一j与共同时间窗，避免额外n费用。来源捕获桥JT5–JT10本身仍只是精确结构，不冒充整类付款。

未覆盖账始终是上述两个实际付款子支的精确补集，包括未被选中的hard外壳、H₀<a下钳位、低j且Γ_S>(n+1)^{-2}的来源，以及R≤L方向未被既有付款或JT17选中的核心（不能不分方向地把高j核心全部删去）。对这些域，η_R质量≤ζ仍不能去掉h_R/K₀；不能把ζ当新负账。消费系数c_U=U/(TA)与hard消费比例χ_U=U/(DK₀)始终不同；核心c_U=1也可有χ_U≪1，故捕获来源桥不能替代储备份额的预算。

对本稿继续筛查的低j捕获核心，尚缺的具体一步是：在JT10中，第二时间r的捕获流与原t层剩余good/bad score，能否在真实p(x−y)dx及原β下得到联合抑制。必须保留k_r(z)w_r(z)与δ_t(v,u)、共同终端c_U/α、hard核心及原门，或证明合法未消费负项的匹配。现有∥C_x∥≤1和同源c_U+ρ≤1没有这种跨时间、跨来源估计；核心正交通甚至全落JT6的交换失配。C_x依赖x，不能固定来源张量化后免费平均它。仅逐行δ≤n及实际选择费用给JT14a，多出的n²不能称为已付。

本文没有证明该接口不可能，没有以一个新命名的能量假设充作闭合，也没有声称处理上述全部未覆盖域。一般ε_rem X+Cε√n log^A(n+2)Wβ目标仍待证。到此停止；仅写本文件，无Git、无PDF。
