"""Read-only independent check of the saved derivative sign witnesses."""
from fractions import Fraction as F
from pathlib import Path
import json
root=Path(__file__).resolve().parent
cert=json.loads((root/'mass_direction.json').read_text())
def rat(o):return F(int(o['numerator']),int(o['denominator']))
counts={'cases':0,'time_pieces':0,'right_polynomials':0}
for c in cert['cases']:
 sigma=rat(c['sigma']);sup=rat(c['sup']);assert 0<sigma<sup
 assert rat(c['left_L'])>=0
 for w in c['winner_evidence']:assert all(rat(x)>=0 for x in w['differences'])
 zeros=[]
 for r in c['right_rho_evidence']:
  co=list(map(rat,r['A_coefficients']));assert co[0]>0>co[1] and co[2]<0
  value=sum(v*sigma**i for i,v in enumerate(co));assert value==rat(r['A_at_sigma'])<0
  f,g=rat(r['N_intercept']),rat(r['N_slope']);assert f>0>g and rat(r['left_N_intercept'])>0
  zero=-f/g;assert zero==rat(r['N_zero']) and zero>sigma;zeros.append(zero);counts['right_polynomials']+=1
 assert max(zeros)>=sup
 for p in c['effective_pieces']:
  lo,hi=rat(p['lo']),rat(p['hi']);assert 0<lo<hi and p['delta']>0
  assert rat(p['FA_endpoint_margin'])>=0
  for name,stored,strict in [('d_times_tn','d_lower',False),('E_minus_Cd_times_tn','E_minus_Cd_lower',True)]:
   terms={int(k):rat(v) for k,v in p[name].items()};assert all(k>=0 for k in terms)
   bound=sum(v*(lo if v>=0 else hi)**k for k,v in terms.items());assert bound==rat(p[stored]);assert bound>0 if strict else bound>=0
  counts['time_pieces']+=1
 counts['cases']+=1
assert counts=={'cases':3,'time_pieces':9,'right_polynomials':9}
print(json.dumps({'pass':True,**counts,'scope':'saved derivative-sign witnesses; formulas/input bindings also require documented code review'},indent=2))
