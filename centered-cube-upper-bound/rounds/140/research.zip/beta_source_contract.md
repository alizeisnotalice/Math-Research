# R140 β–ν 来源关系定位账

## 范围与结论口径

只核对 R117 `TASK_CONTEXT.md`、R117 本轮的 `joint_geometry.md` / `capacity_low.md` / `sources_scope.md`、R113 `coupled_transport.md` / `integration_main.md`，以及 R128 `joint_receiver_tail.md` 的 RT1–4。以下是这些明确定位所支持的关系；不外推到未读的历史来源文件。

**可确认的共同结构**：R113 实际采用的软余源是同一冻结来源空间上的残余测度 \(\beta^c=\alpha-\eta_\alpha^c\)，原硬尾 \(\nu\) 在该构造中保持不变，并有测度支配 \(\nu\le\beta^c\le\alpha\)。因此在有限测度条件下，\(\nu\ll\beta^c\)，其 Radon–Nikodym 密度满足 \(0\le d\nu/d\beta^c\le1\)（这是测度支配的直接推论）。这比仅分别记录 \(\nu\le f\) 和总 \(\beta\)-质量控制更具体：两者是同一来源空间、同一软提取构造下的共同支配关系。

**该关系没有给出的内容**：原文明确说 I1 是测度意义的支配而非点态密度帽；\(\beta^c\) 不自动继承硬尾的 born 支持、rank、低叶均值或捕获门，也没有逐点比例、独立性、\(\beta^c=\nu\) 或对辅助来源的耦合身份。读到的内容没有证明一种可把 \(\int e_t(y)\operatorname{Var}_{\Pi_t} k\,dy\) 按同一来源点改写/控制为 \(d\beta(y)\) 的恒等式或额外密度估计；不得把上述支配误写成该种能量接桥。

## 可逐句追踪的原文位置

1. **R117 任务范围及原实际母式。** [TASK_CONTEXT.md](/Users/zhengzhihao/Desktop/T/output/centered_cube_round117_20261014/TASK_CONTEXT.md:3) 第3–10行给出实际参数范围、\(\nu_V\le\beta_V\le f\)、原叶不交，以及
   \[
   d\mathcal T=q^{-1}P_{s,L}(x-y)h_R(x-z)a_\omega(x,y,z)\,dx\,d\beta_V(y)d\nu_V(z).
   \]
   原因子 \(a_\omega\in[0,1]\)保留原全部门；同处第9行还明确辅助点 \(z'\) 不继承原硬捕获门，且不能丢 \(1/e\)。这是原接收交通母式，不是把 y 与 z 识别为同一变量的式子。

2. **R113 对实际 \(\beta^c\) 的定义与已证联系。** [integration_main.md](/Users/zhengzhihao/Desktop/T/output/centered_cube_round113_20261014/integration_main.md:7) 第7–13行定义共同耦合构造的 \(\beta^c=\alpha-\eta_\alpha^c\)，并记
   \[
   \nu\le\zeta_\sigma^*\le\beta^c\le\alpha,
   \qquad W_{\eta_\alpha^c}+W_{\beta^c}=W_\alpha\le W_{\rm hi}.
   \]
   第13行称软计划由原硬网络和冻结来源构造，先于接收点选择，且原 \(\nu\) 不变。

3. **为何该支配不是“任意两份流自然有此关系”。** [coupled_transport.md](/Users/zhengzhihao/Desktop/T/output/centered_cube_round113_20261014/coupled_transport.md:49) 第49–72行给出同一终端叶 / pieces 上以 \(\alpha\) 为共同支配测度的构造：C6 定义扩张后的软提取，C7–C8 推出 \(\nu\le\zeta_\alpha^*\le\alpha\)，并说明当前软提取一般不是每 piece 上 \(\alpha\) 的常数倍。第82–84行进一步说原硬尾 rank 仍只属于 \(\nu\)，不继承 R112 J27 的逐来源正比例提取。这排除将共同支配升级成点态常数比例或独立性。

4. **原硬尾的 born 支持只给 \(\nu\)。** [sources_scope.md](/Users/zhengzhihao/Desktop/T/output/centered_cube_round117_20261014/sources_scope.md:89) 第89–105行追踪 \(\nu_V\le\sigma_V\le\nu_{h,\omega}\le\mu_{\rm hi}\mathbf1_B\) 及对原节点 \(A\) 的质量界。第105行明确：“新soft余源 β 不自动有 born 支持”；若第三来源 \(z'\) 是原 \(\nu\) 的采样，仅可得 source-born 支持，仍不继承原 z 的当前 x 捕获、LCA 或历史门。

5. **R117 归一化来源的确切定义。** [joint_geometry.md](/Users/zhengzhihao/Desktop/T/output/centered_cube_round117_20261014/joint_geometry.md:9) 第9–23行定义 \(Z_t\)、\(w_t\)、
   \[
   \mu_t(dz')=1_{Z_t}w_t(z')d\nu_V(z'),\quad e_t=\mu_t(\mathbb R^n),\quad \Pi_t=\mu_t/e_t.
   \]
   第23行说 \(\nu\) 是有限原硬尾，且第三来源有 source-born 支持但不继承硬捕获/其余门。这里 \(e_t\) 和 \(\Pi_t\) 是以 \(\nu_V\) 为来源的 y-依赖对象；定义中没有将 \(\nu_V\) 换成 \(\beta_V\)。

6. **低支对缺少能量桥的原文限定。** [capacity_low.md](/Users/zhengzhihao/Desktop/T/output/centered_cube_round117_20261014/capacity_low.md:30) 第30–53行区分 \(d\pi=q^{-1}p(x,y)d\beta_V(y)\) 与 \(e\) 所用的来源相关权重 \(W,Z,\nu\)。第51行说密度帽不能推出 \(\pi(B)\) 小，且 \(\nu\le\beta\) 不允许把 \(d\beta/e\) 当作有统一总质量的测度；第53行再次说明辅助点不具有原硬捕获门。这是对不能直接做该转换的明确限制，不是 FULL 反例。

7. **R128 RT1–4 对积测度和可移出对象的限定。** [joint_receiver_tail.md](/Users/zhengzhihao/Desktop/T/output/centered_cube_round128_20261014/joint_receiver_tail.md:20) 第20–27行重列真实外测度 \(d\mathcal T_I\propto dx\,d\beta_V(y)d\nu_V(z)\)，并说 \(W_\beta=\mathbb E\sum_V\|\beta_V\|\)、\(\beta-\nu\) 不删除。RT2 第32–42行的归一化二重积分仍相对 \(d\nu_V(v)d\nu_V(z')/e_t(y)^2\)。RT4 第53–66行明确固定 \((\omega,V,j,y,t)\) 后，可移出 x 积分的是 \(\nu_V,Z_t,w_t,e_t,\Pi_t\)；这些量在接收点前构造且不依赖 x 或硬 z。该接口保留 y 上的真实 \(d\beta_V(y)\)，并未给出以 \(\beta\) 替代 \(\nu\) 的辅助来源耦合或同点能量恒等式。

## 有界检索说明

R117 `TASK_CONTEXT.md` 是本次定位到的正确任务上下文路径。未通读完整历史；除上述列出的 R113、R117、R128 文件及行段外，不据此声称更早全库中不存在其他关系。就这条可见证明链而言，已证的加强是共同来源测度支配 \(\nu\le\beta^c\le\alpha\)，但尚未定位到可将所问 \(e_t\operatorname{Var}_{\Pi_t}k\) 能量直接接成 \(d\beta(y)\) 付款的额外结构。

## 历史查重补记：hard core 付款与“消去唯一 j”

本补记按 R140 追加要求，只检索 R117–R139 中名称/内容相关的 joint、geometry、scale、ratio-column 文档及 R139 审计稿；用 `rg` 定位 `c_j^{n/2}`、核心、\(Q_H\)、\(H_0\)、\(K_0\)、\(\delta_t\)、唯一 j、\(\sqrt n\log n\) 等词后，只读取下列命中段，不通读完整历史。结论限定为“定位到/未定位到”，不把未命中说成不存在。

### 已定位的付款

- **已付的条件性近项，非所问那条同假设账。** R139 [joint_hard_margin.md](/Users/zhengzhihao/Desktop/T/output/centered_cube_round139_20261015/joint_hard_margin.md:89) 第89–106行定义 \(\mathcal G_S=\{\lambda_S>0,\Gamma_S\le(n+1)^{-3}\}\)，并对原正项仅截取 \(z\in S\)、good \(v\in\mathcal G_S\)，登记 \(2\Lambda P_I^{hard-joint}\le40\Lambda\sqrt n W_\beta\)。其门还包含 \(H<L_+\)、\(C_J(v)\le3\) 及原 high/FA/\(\Psi/\rho\)。第178–182行确认这是已通过的新条件子支付款，同时准确列出外壳、\(\lambda_S\le0\) 与 \(\Gamma_S>(n+1)^{-3}\) 的余项仍未付；没有声称覆盖多数交通。
- **核心何时可作该条件子支的 S。** R139 同稿第13–40行定义核心 \(C_x=Q_{\min(R,H)}(x)\)，列出真实核心余量；第40行说明 \(R>L,H_0\ge a,D\ge1\) 时 \(D\kappa-1+\omega_c>0\)，故该具体核心有 \(\lambda_c>0\)。第60行另指出 \(R\le\min(L,H)\) 时核心等于全部外hard载体，但这是相反尺度侧。故在所问的 \(R>L,H_0\ge a\) 侧，若再满足 HM8 的共同 \(\Gamma_C\le(n+1)^{-3}\) 条件及完整实际门，R139 的确可支付**核心内该阈值子支**；这不是仅凭 \(c_j^{n/2}\le(n+1)^{-2}\) 即对整个所问子域付款。
- **R139 的来源积分和 j 账不同于候选的“无额外 j 因子”。** [joint_hard_margin.md](/Users/zhengzhihao/Desktop/T/output/centered_cube_round139_20261015/joint_hard_margin.md:151) 第151–174行先固定同一 \((\omega,V,j,x,y,t,v)\)，再积外hard \(z\)，由 HM12 与两份 \(\Pi_t\) 的质量 1、\(\delta_t\le n\) 控制源对；但其接收核菜单显式付 \(N_j\le n+2\)（第149、165–172行），所得是 \(40\Lambda\sqrt n W_\beta\)。所以它不是所问“源积分全上放后直接消去唯一 \(j(x)\)、不乘 j 菜单数”的同一证明步骤。
- **另有已付 R>L 空间捕获支，但对象/价格不相同。** R121 [reversed_scale_private.md](/Users/zhengzhihao/Desktop/T/output/centered_cube_round121_20261014/reversed_scale_private.md:61) 第61–95行给 \(R>L\) 的新参数门与 \(z''\in Q_L(x)\) 辅助空间门下的 \(\varepsilon_{RS}X+C_{\varepsilon_{RS}}\sqrt n W_{hi}\) 付款；第173行保留唯一 j 后用 \(T_{small}\le4X\) 付款，第177–191行有限维回退先合并唯一 j、再积分原hard z。它既不是外来源 \(z\in Q_H\) 的整个hard核心账，也不是 \(c_j^{n/2}\le(n+1)^{-2}\) 的所述核心条件。R117 [capacity_low.md](/Users/zhengzhihao/Desktop/T/output/centered_cube_round117_20261014/capacity_low.md:55) 第55–93行只给低 \(pe\) 且重度 \(m\le M\) 的旧根法价格，并明说 \(m>M\) 的 CL6 未证；不是该核心付款。

### 查重判定

就所问的**精确条件组** \(R>L, H_0\ge a, z\in Q_H, c_j^{n/2}\le(n+1)^{-2}\) 及所述 \(\eta_0=K_0\nu/q\)、\(h_R/K_0\)、两 \(\Pi\) 与 \(\delta_t\) 操作：在本次限定命中范围内，未定位到以这些准确门、完整hard core和 \(\sqrt{n\log n}\,W_\beta\) 登记的既有付款。可确证的最近结果是上面的 R139 小-\(\Gamma\) 条件付款，条件、接收菜单和常数均有差别；并且 R139 明说其余核心相关区域仍待付。因此应标为“**相邻的条件子支已付；精确候选未定位**”，不能写成“此前不存在”。

“源积分全部上放后消去唯一 j”的**一般步骤**也未在上述限定范围内定位到同一套结论：R139 已证明的是先逐个固定 \(j\) 再对 hard z/source pair 积分，并将合法 j 数 \(N_j\le n+2\) 计入账；R121/119 的若干逐原交通子支确实保留唯一 \(j(x)\)，但依赖各自捕获门/实际交通付款，不能据此抽出所问的通用核步骤。R139 HM6 的积分次序可参考 [joint_hard_margin.md](/Users/zhengzhihao/Desktop/T/output/centered_cube_round139_20261015/joint_hard_margin.md:151)，R121 对应定位见上。以上只记录有限查重结果，不对更早或未命中文件作不存在判断。
