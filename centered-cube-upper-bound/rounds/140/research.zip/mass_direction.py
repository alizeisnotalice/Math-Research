#!/usr/bin/env python3
"""Exact saved-coefficient mass-direction screening; no quadrature/kernel calls."""
import json,hashlib,sys,traceback
from fractions import Fraction as F
from pathlib import Path
sys.set_int_max_str_digits(0)
BASE=Path(__file__).resolve().parent; ROOT=BASE.parent
PATHS={'R136':ROOT/'centered_cube_round136_20261014/active_traffic_v2.json','R138':ROOT/'centered_cube_round138_20261015/core_capacity_probe.json','R139':ROOT/'centered_cube_round139_20261015/joint_objective_probe.json'}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def jf(x):return F(int(x['numerator']),int(x['denominator']))
def fr(x):return F(str(x))
def enc(x):
 if isinstance(x,F):return {'numerator':str(x.numerator),'denominator':str(x.denominator)}
 if isinstance(x,dict):return {str(k):enc(v) for k,v in x.items()}
 if isinstance(x,(list,tuple)):return [enc(v) for v in x]
 return x
def save(out): (BASE/'mass_direction.json').write_text(json.dumps(enc(out),indent=2)+'\n')
def at(l,m):return l[0]*m+l[1]
def lower(poly,lo,hi):return sum(c*(lo if c>=0 else hi)**k for k,c in poly.items())
def run(c,cap):
 checks={}; evidence={}
 def ck(name,value):checks[name]=bool(value)
 n=c['n']; atoms=c['atoms']; fixed=[fr(a['nu']) for a in atoms[:4]]; f0=1-sum(fixed)
 lines={k:(jf(v['slope']),jf(v['intercept'])) for k,v in cap['affine_coefficients'].items()}
 j1,j0=lines['QJ']; b,a=lines['Q0']; u1,u0=lines['Utotal']; sup=jf(cap['mass_supremum']);sigma=(j0-a)/(b-j1)
 ck('crossing_in_domain',0<sigma<sup);ck('j0_positive_j_slope_nonnegative',j0>0 and j1>=0)
 winner=[]
 for lab,lo,hi in [('QJ',F(0),sigma),('Q0',sigma,sup)]:
  for other in ['Q0','QJ','Qstar']:
   vals=[at(lines[lab],m)-at(lines[other],m) for m in [lo,hi]];winner.append(dict(winner=lab,competitor=other,bounds=[lo,hi],differences=vals));ck('winner_'+lab+'_'+other,min(vals)>=0)
 L=u1*j0-u0*j1;ck('left_rho_derivative_nonnegative',L>=0)
 D=fr(c['parameters']['D']);T=fr(c['derived']['T']);p=fr(c['derived']['p']);BFA=fr(c['parameters']['B_FA']);U=[jf(x['rebuilt']) for x in cap['rebuilt_U_audit']]
 ck('core_U_equals_TA',U[5]==T*fr(atoms[5]['A']));ck('far_mass_positive',sup<f0)
 for lab,lo,hi in [('QJ',F(0),sigma),('Q0',sigma,sup)]:
  ck('alpha_nonnegative_'+lab,min(D*at(lines[lab],m)-at(lines['Utotal'],m) for m in [lo,hi])>=0)
 Cs=sigma*(1+2*sigma*j1/j0);right=[]
 for i in range(3):
  TA=T*fr(atoms[i]['A']);J=fr(atoms[i]['J']);f=(TA-U[i])*j0-J*(D*a-u0);g=(TA-U[i])*j1-J*(D*b-u1)
  fl=(TA-U[i])*j0-J*(D*j0-u0)
  uu=a*j0;vv=a*j1+b*j0;ww=b*j1;Acoef=[f*uu,2*g*uu,g*vv-f*ww];As=sum(co*sigma**k for k,co in enumerate(Acoef))
  ck('left_N_positive_'+str(i),fl>0);ck('right_sign_'+str(i),f>0 and g<0 and a>0 and b>=0 and Acoef[0]>0 and Acoef[1]<0 and Acoef[2]<0 and As<0)
  right.append(dict(source=atoms[i]['name'],N_intercept=f,N_slope=g,N_zero=-f/g,left_N_intercept=fl,A_coefficients=Acoef,A_at_sigma=As))
 segs=[]
 for s in c['score_segments']:
  lo,hi=fr(s['lo']),fr(s['hi']);ks=s['k'];cs=list(map(fr,s['c']))
  ck('score_'+str(len(segs)),[sum(fr(x)**2<lo*hi for x in a['thresholds']) for a in atoms]==ks)
  segs.append((lo,hi,ks,cs))
 pieces=[];positive_pairs=set();psi=[]
 for i,v in enumerate(atoms):
  for z,u in enumerate(atoms):
   inc=[]
   for lo,hi,ks,cs in segs:
    power=ks[i]+ks[z];diff=ks[i]-ks[z];inc.append(diff*cs[i]*cs[z]*(lo**(-power)-hi**(-power))/power if power else F(0))
   su=F(0);suffix=[su]
   for x in reversed(inc):su+=x;suffix.append(su)
   ps=max(suffix)>0;old=c['pairs'][i*6+z];ck('Psi_'+str(i*6+z),ps==old['Psi'] and not old['suffix_ambiguous']);psi.append(dict(pair=[v['name'],u['name']],Psi=ps,max_suffix=max(suffix)))
   if not(v['good'] and u['bad'] and ps) or i==5:continue
   for si,(lo,hi,ks,cs) in enumerate(segs):
    delta=ks[i]-ks[z]
    if delta<=0:continue
    Kfa=BFA*delta*p*cs[i]/fr(v['Q'])
    if Kfa<=lo**ks[i]:continue
    ck('fixed_pair_'+str(i*6+z),i in range(3) and z==3);ck('FA_full_'+str(i*6+z)+'_'+str(si),Kfa>=hi**ks[i])
    positive_pairs.add((v['name'],u['name']))
    E={};dd={}
    for ii in range(6):
     exponent=n-ks[ii];E[exponent]=E.get(exponent,F(0))+(fixed[ii] if ii<4 else f0 if ii==4 else F(0))*cs[ii]
    for ii,sgn in [(5,1),(4,-1)]:
     exponent=n-ks[ii];dd[exponent]=dd.get(exponent,F(0))+sgn*cs[ii]
    ed={k:E.get(k,F(0))-Cs*dd.get(k,F(0)) for k in E.keys()|dd.keys()};dl=lower(dd,lo,hi);el=lower(ed,lo,hi)
    ck('d_nonnegative_'+str(i*6+z)+'_'+str(si),dl>=0);ck('E_Cd_strict_'+str(i*6+z)+'_'+str(si),el>0)
    pieces.append(dict(pair=[v['name'],u['name']],segment=si,lo=lo,hi=hi,delta=delta,FA_K=Kfa,FA_endpoint_margin=Kfa-hi**ks[i],E_times_tn=E,d_times_tn=dd,E_minus_Cd_times_tn=ed,d_lower=dl,E_minus_Cd_lower=el))
 ck('exactly_three_nonzero_pair_types',positive_pairs=={('G1','G4'),('G2','G4'),('G3','G4')});ck('positive_time_pieces',len(pieces)>0)
 # R138 cells are part of the certificate; ensure their feasible union covers the domain.
 intervals=sorted((jf(x['lower']),jf(x['upper'])) for x in cap['winner_cells'] if x['feasible']);end=F(0)
 for lo,hi in intervals:
  ck('cell_union_no_gap_'+str(lo),lo<=end);end=max(end,hi)
 ck('cell_union_reaches_sup',end==sup)
 best=next(x for x in original['cases'] if x['id']==c['id']);node=best['points'][best['summary']['best_verified_node_id']];md=node['mass_definition'];ck('sample_best_exact_crossing',md['kind']=='R138_cell_endpoint' and jf(cap['winner_cells'][md['cell']][md['bound']])==sigma)
 return dict(id=c['id'],status='PASS' if all(checks.values()) else 'FAIL',checks=checks,sigma=sigma,sup=sup,sigma_over_sup=sigma/sup,left_L=L,C_sigma=Cs,winner_evidence=winner,right_rho_evidence=right,effective_pieces=pieces,Psi_audit=psi,R138_all_winner_cells=cap['winner_cells'],sample_best_definition=md,continuity='q=max affine is continuous; rho=max(N/(TA QJ),0) is continuous since QJ>0; et is positive for 0<=m<=sup since all source masses and weights are nonnegative, first four strictly positive. Fixed FA/Psi/time boundaries do not depend on m. Thus clipping and winner transitions preserve mass continuity.')
if __name__=='__main__':
 previous=json.loads((BASE/'mass_direction.json').read_text()) if (BASE/'mass_direction.json').exists() else None
 data={k:json.loads(p.read_text()) for k,p in PATHS.items()};original=data['R139']
 out=dict(scope='I1 I2 P1 only; exact arithmetic on saved rational coefficients; no integration or kernel recomputation',input_sha256={k:sha(p) for k,p in PATHS.items()},protocol_pre_run_sha256=sha(BASE/'mass_direction.md'),script_sha256=sha(Path(__file__)),cases=[],exceptions=[])
 if previous:out['recovery_history']={'first_run_exceptions':previous['exceptions'],'first_script_sha256':previous['script_sha256'],'first_summary':previous.get('summary'),'cause':'R139 mass_definition field is kind, not type; corrected schema access only.'}
 for name in ['I1','I2','P1']:
  try:out['cases'].append(run(next(c for c in data['R136']['cases'] if c['id']==name),next(c for c in data['R138']['cases'] if c['id']==name)))
  except Exception:out['exceptions'].append(dict(id=name,traceback=traceback.format_exc()))
  save(out)
 out['summary']={'pass':sum(c['status']=='PASS' for c in out['cases']),'fail':sum(c['status']=='FAIL' for c in out['cases']),'exceptions':len(out['exceptions'])};save(out)
 print(json.dumps(out['summary']))
 for c in out['cases']:print(c['id'],c['status'],[k for k,v in c['checks'].items() if not v])
