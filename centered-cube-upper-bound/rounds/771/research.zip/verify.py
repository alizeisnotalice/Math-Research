"""R771 true interval history kernels, monotone segments, and prior-price hits."""

import argparse
from collections import defaultdict
from fractions import Fraction as Q
from hashlib import sha256
from itertools import combinations, product
import json
from pathlib import Path
from platform import python_version


def length(interval):
    return max(Q(0),interval[1]-interval[0])


def intersect(*intervals):
    return max(a for a,b in intervals),min(b for a,b in intervals)


def contains(interval,x):
    return interval[0]<=x<=interval[1]


def centered(y,s):
    return y-s,y+s


def geometry(name):
    if name=="chain":
        A = [(0,4),(3,8),(7,13),(12,19)]
        low = Q(1,2)
    elif name=="crowded":
        A = [(0,4),(Q(1,4),Q(21,4)),(Q(-3,4),Q(21,4)),(Q(-1,4),Q(27,4))]
        low = Q(1,4)
    else:
        A = [(0,4),(Q(1,2),Q(11,2)),(Q(9,4),Q(33,4)),(Q(11,2),Q(25,2))]
        low = Q(3,4)
    A = [tuple(map(Q,I)) for I in A]
    E = [centered((a+b)/2,(b-a)/64) for a,b in A]
    D = [centered((a+b)/2,Q(17,16)*(b-a)/2) for a,b in A]
    d = list(map(length,A))
    v = list(map(length,E))
    assert d==[4,5,6,7] and all(2<=r/2<4 for r in d)
    assert all(length(intersect(I,J))==0 for I,J in combinations(E,2))
    price = []
    for j in range(-4,23):
        left,mid,right = Q(j),Q(j)+Q(1,2),Q(j+1)
        price.extend([((left,mid),low),((mid,right),2-low)])

    def mu(I):
        return sum(w*length(intersect(I,J)) for J,w in price)

    m = list(map(mu,A))
    assert m==d and all(intersect(X,Y)==X for X,Y in zip(A,D))
    records = []
    for i,((a,b),value) in enumerate(zip(A,v)):
        if name=="chain" or (name=="staggered" and i in (0,3)):
            records.append((i,0,value,A[i]))
        else:
            theta=Q(3+i%3,8)
            trim = d[i]/4 if name=="crowded" else Q(1,4)
            records.extend([(i,0,theta*value,(a,b-trim)),(i,1,(1-theta)*value,(a+trim,b))])
    assert all(value>0 and intersect(C,A[i])==C and mu(C)>0 for i,side,value,C in records)
    assert all(sum(w for i,side,w,C in records if i==j)==vj for j,vj in enumerate(v))

    def gate(a,b):
        i,s,w,C = records[a]
        j,t,p,B = records[b]
        return i!=j and (name!="crowded" or s!=t or (i+j)%2==1)

    cuts = sorted({x for I in (*A,*D,*(C for i,s,w,C in records),*(I for I,w in price)) for x in I})
    price_cells = [((a+b)/2,mu((a,b))) for a,b in zip(cuts,cuts[1:])]
    reps = cuts+[(a+b)/2 for a,b in zip(cuts,cuts[1:])]+[cuts[0]-1,cuts[-1]+1]
    return A,E,D,d,m,v,records,gate,mu,price_cells,reps,low


def audit(name):
    A,E,D,d,m,v,records,gate,mu,cells,reps,low = geometry(name)
    labels = [i for i,tag,w,C in records]
    I = [w for i,tag,w,C in records]
    C = [box for i,tag,w,box in records]
    states = range(len(I))
    measure = {(a,b):mu(intersect(C[a],C[b])) for a,b in product(states,repeat=2)}
    K = {(a,b):(measure[a,b]/(m[labels[a]]*m[labels[b]]) if gate(a,b) else Q(0))
         for a,b in product(states,repeat=2)}
    assert all(K[a,b]==K[b,a] for a,b in K)
    assert all(a!=b and d[labels[a]]!=d[labels[b]] for (a,b),weight in K.items() if weight)
    r = [sum(K[a,b]*I[b] for b in states) for a in states]
    assert all(x>0 for x in r)
    B = sum(mass*row for mass,row in zip(I,r))
    W = {(a,b):K[a,b]*I[a]*I[b] for a,b in K}
    assert sum(W.values())==B
    pi = [I[a]*r[a]/B for a in states]
    P = {(a,b):K[a,b]*I[b]/r[a] for a,b in K}
    assert all(sum(P[a,b] for b in states)==1 for a in states)
    assert all(sum(pi[a]*P[a,b] for a in states)==pi[b] for b in states)
    assert all(pi[a]*P[a,b]==W[a,b]/B==pi[b]*P[b,a] for a,b in K)
    up = lambda a,b: d[labels[a]]<d[labels[b]]
    ascend = sum(W[a,b]/B for a,b in W if up(a,b))
    descend = sum(W[a,b]/B for a,b in W if up(b,a))
    assert ascend==descend==Q(1,2)
    sub_margins = ([sum(W[a,b]/B for b in states if up(a,b)) for a in states],
                   [sum(W[a,b]/B for a in states if up(a,b)) for b in states])
    assert all(all(x<=y for x,y in zip(side,pi)) and sum(side)==Q(1,2) for side in sub_margins)
    height = [(d[j]-d[0])/(d[-1]-d[0]) for j in labels]
    gain = sum(W[a,b]/B*(height[b]-height[a]) for a,b in W if up(a,b))
    assert 0<gain<=sum(p*h for p,h in zip(pi,height))

    triple = {}
    valley = peak = uphill = downhill = Q(0)
    for a,b,c in product(states,repeat=3):
        t = pi[a]*P[a,b]*P[b,c]
        assert t/pi[b]==P[b,a]*P[b,c]
        if not t:
            continue
        triple[a,b,c]=t
        valley += t*(up(b,a) and up(b,c))
        peak += t*(up(a,b) and up(c,b))
        uphill += t*(up(a,b) and up(b,c))
        downhill += t*(up(b,a) and up(c,b))
    assert valley>=Q(1,4) and peak>=Q(1,4)
    assert uphill==downhill and valley+peak+uphill+downhill==1 and uphill+downhill<=Q(1,2)
    greater = [sum(P[a,b] for b in states if up(a,b)) for a in states]
    assert valley==sum(w*q*q for w,q in zip(pi,greater))
    assert peak==sum(w*(1-q)**2 for w,q in zip(pi,greater))
    states_ascending = sorted(states,key=lambda i:d[labels[i]])
    full_up = full_down = Q(0)
    paths = 0
    for a,b,c,e in product(states_ascending,repeat=4):
        weight = pi[a]*P[a,b]*P[b,c]*P[c,e]
        assert weight==pi[e]*P[e,c]*P[c,b]*P[b,a]
        paths+=bool(weight)
        full_up += weight*(up(a,b) and up(b,c) and up(c,e))
        full_down += weight*(up(e,c) and up(c,b) and up(b,a))
    assert full_up==full_down and full_up>0
    if name=="chain":
        assert valley==peak==uphill+downhill==Q(1,3)
        assert full_up==Q(1,24)

    # The old price is sampled from the actual previous overlap, before the next label.
    hit_lebesgue = defaultdict(Q)
    priced_triangle = defaultdict(Q)
    hit_right = Q(0)
    for a,b,c in triple:
        g=labels[c]
        overlap=intersect(C[a],C[b])
        conditional=mu(intersect(overlap,D[g]))/measure[a,b]
        hit_right+=triple[a,b,c]*conditional
        previous_density = I[a]*I[b]/(B*m[labels[a]]*m[labels[b]])
        for x,price_mass in cells:
            if contains(C[a],x) and contains(C[b],x):
                weight=previous_density*price_mass*P[b,c]
                priced_triangle[a,b,c]+=weight
                if contains(D[g],x):
                    hit_lebesgue[a,b,c]+=weight
    assert priced_triangle==triple
    hit = sum(hit_lebesgue.values())
    assert 0<hit==hit_right<=1
    best = Q(0)
    witness = None
    for a,x in product(states,reps):
        eligible = [c for c in states if K[a,c] and contains(D[labels[c]],x)]
        val = sum(K[a,c]*I[c] for c in eligible)
        if val>best:
            best = val
            witness = a,x,sorted({labels[c] for c in eligible})
    assert best>0 and B*hit<=best*sum(I)
    largest_single = max(K[a,c]*I[c] for a,c in K)
    if name=="crowded":
        assert len(witness[2])>=2 and best>largest_single
    alternate = sum(pi[b]*P[b,c]*mu(intersect(A[labels[b]],D[labels[c]]))/m[labels[b]]
                    for b,c in product(states,repeat=2))
    assert alternate!=hit
    return {
        "model":name,"parents": [list(map(str,R)) for R in A],"owners": [list(map(str,R)) for R in E],
        "d_equals_m":list(map(str,d)),"D": [list(map(str,R)) for R in D],
        "periodic_density_first_second_half":list(map(str,(low,2-low))),
        "histories_label_tag_I_C":[[i,tag,str(w),list(map(str,R))] for i,tag,w,R in records],
        "B_total_edge_mass":str(B),"stationary_pi":list(map(str,pi)),
        "r":list(map(str,r)),
        "positive_K_entries":[[a,b,str(k)] for (a,b),k in K.items() if k],
        "one_step_up_and_down":[str(ascend),str(descend)],
        "strict_valley_peak_two_hop_up_down":list(map(str,(valley,peak,uphill,downhill))),
        "strict_3_hop_up_and_down":list(map(str,(full_up,full_down))),
        "positive_two_hop_histories":len(triple),"positive_three_hop_histories":paths,
        "ascending_subcoupling_height_gain":str(gain),
        "previous_common_price_hit_D":str(hit),"replacing_previous_price_by_parent_rho":str(alternate),
        "alpha_row_sup":str(best),"alpha_witness_state_z_parent_labels":[witness[0],str(witness[1]),witness[2]],
        "B_times_actual_hit":str(B*hit),"alpha_times_sum_I":str(best*sum(I)),
        "largest_single_neighbor_row_weight":str(largest_single),
    }


def report():
    return {
        "scope":(
            "All three models use a true 1D family with lengths 4,5,6,7, periodic finite AC prices with m=d, "
            "and real pairwise disjoint shrink owners. Symmetric gates are chosen to test the finite original-pair kernel."
        ),
        "python":python_version(),"source_sha256":sha256(Path(__file__).read_bytes()).hexdigest(),
        "commands":["python -B verify.py --out verify.json","python -B verify.py --check verify.json"],
        "models":[audit(case) for case in ("chain","crowded","staggered")],
    }


def main():
    parser = argparse.ArgumentParser()
    action = parser.add_mutually_exclusive_group(required=True)
    action.add_argument("--out",type=Path)
    action.add_argument("--check",type=Path)
    args = parser.parse_args()
    cert = report()
    data = (json.dumps(cert,indent=2,sort_keys=True)+"\n").encode()
    if args.out:
        args.out.write_bytes(data)
        print(f"wrote {args.out} ({len(data)} bytes)")
    else:
        assert args.check.read_bytes()==data,"certificate differs"
        print(f"identical rerun of {args.check} ({len(data)} bytes)")
    for m in cert["models"]:
        print(f"{m['model']}: {len(m['stationary_pi'])} histories, "
              f"{m['positive_two_hop_histories']} two-hop and {m['positive_three_hop_histories']} three-hop paths")


if __name__=="__main__":
    main()

