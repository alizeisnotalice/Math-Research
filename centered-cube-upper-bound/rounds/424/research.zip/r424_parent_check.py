from fractions import Fraction as F
from math import isqrt
from random import Random
rng=Random(424)
counts={}
for stage,dims in [('initial',[9,16,25]),('parameter_pressure',[36,64,100]),('expanded',[256,1024,10000,1000000])]:
    count=0
    for n in dims:
        k=isqrt(n);assert k*k==n
        s=F(1+k);Klo=F(2**k)
        for S,eps,r in [(F(1),F(1,2),F(1)),(F(3),F(1,8),F(2)),(F(5,2),F(1,32),F(4,3))]:
            # An<=1+n and K=e^sqrt(n)>2^sqrt(n), so this is a rational upper certificate.
            omega_up=4*S*r*eps*F(1+n)/s*Klo/(Klo-1)
            root_up=4*S*r*eps*s*Klo/(Klo-1)
            assert omega_up<=root_up
            assert (Klo+1)/Klo<=Klo/(Klo-1)
            for trial in range(4):
                vals=[F(rng.randint(0,100),100)/Klo for _ in range(7)]
                weights=[F(rng.randint(1,7),11) for _ in vals]
                paid=sum(w*min(F(1),Klo*v) for w,v in zip(weights,vals))
                rem=sum(w*max(F(0),1-Klo*v) for w,v in zip(weights,vals))
                total=sum(weights)
                assert paid+rem==total
                assert paid<=Klo*sum(w*v for w,v in zip(weights,vals))
                assert all(v<1/Klo for v in vals if 1-Klo*v>0)
                # Original mother account; new source payment does not create an X fee.
                Fhat=F(8,5);Lam=F(128,119);W=F(3,2);oldV=F(4,7)
                fee=paid/W
                assert 64*Lam*Fhat*(total+oldV*W)==64*Lam*Fhat*(rem+(oldV+fee)*W)
            count+=1
    counts[stage]=count
print('PASS rational parameter bounds',counts,'soft/full-account cases',4*sum(counts.values()))
print('Analytic parameter upper envelopes and finite positive-label algebra only; no native original history or global absorption certificate.')
