from fractions import Fraction as F
from random import Random
rng=Random(424)
def psd(M):
 A=[r[:] for r in M];n=len(A)
 for k in range(n):
  assert A[k][k]>=0
  if A[k][k]==0:
   assert all(A[k][j]==0 for j in range(k+1,n));continue
  for i in range(k+1,n):
   for j in range(i,n):
    A[i][j]-=A[i][k]*A[k][j]/A[k][k];A[j][i]=A[i][j]
 return True
count=0
for N in [8,12]:
 for trial in range(6):
  f=[F(rng.randint(1,4),3) for _ in range(N)]
  sets=[set(range(j)) for j in range(1,N+1)]
  sets += [set(rng.sample(range(N),rng.randint(1,N))) for _ in range(4)]
  V=len(sets);m=[sum(f[x] for x in C) for C in sets]
  sig=[F(rng.randint(1,3),7) for _ in sets];mu=[sig[i]/m[i] for i in range(V)]
  K=F(2);h=F(1,10)
  order=sorted(range(V),key=lambda i:m[i])
  Z=[[sum(mu[b] for b in range(V) if x in sets[b] and m[b]<m[a]/K) for x in range(N)] for a in range(V)]
  J=max(sum(mu[b] for b in range(V) if x in sets[b]) for x in range(N))
  initial={}
  for x in range(N):
   occ={}
   for a in order:
    vec=[F(int(a==b)) for b in range(V)]
    if Z[a][x]>h:
     for b in range(V):
      if x in sets[b] and m[b]<m[a]/K:
       for d in range(V):vec[d]+=mu[b]/Z[a][x]*occ[b][d]
    occ[a]=vec
    initial[a,x]=[vec[b]-F(int(a==b)) for b in range(V)] if Z[a][x]>h else [F(0)]*V
  weights=[F(0)]*V
  for a in range(V):
   active=sum(f[x]/m[a] for x in sets[a] if Z[a][x]>h)
   for x in sets[a]:
    for b in range(V):weights[b]+=2*sig[a]/m[a]*active*f[x]/m[a]*initial[a,x][b]
  env=[F(0)]*V; thresholds=[]
  for b in range(V):
   j=0
   while m[b]*K**(j+1)<max(m):
    H=m[b]*K**(j+1);thresholds.append(H)
    env[b]+=2*mu[b]/h*sum(sig[a]*sum(f[x] for x in sets[a]&sets[b])/m[a]**2 for a in range(V) if m[a]>H)
    j+=1
   assert weights[b]<=env[b]
  Ctail=max([H*sum(sig[a]/m[a]**2 for a in range(V) if x in sets[a] and m[a]>H) for H in thresholds for x in range(N)]+[F(0)])
  C=2*Ctail*J/(h*(K-1))
  for b in range(V):assert env[b]<=2*Ctail*mu[b]/(h*(K-1))
  # All-g global matrix inequality in source coordinates (metric diag(f)).
  Q=[[f[x]*f[y]*sum(weights[b]/m[b] for b in range(V) if x in sets[b] and y in sets[b]) for y in range(N)] for x in range(N)]
  diff=[[F(int(x==y))*C*f[x]-Q[x][y] for y in range(N)] for x in range(N)]
  assert psd(diff)
  count+=1
print('PASS global weighted child-analysis matrices:',count)
print('Finite matched full-source incidence and positive center weights; measured Ctail,J replace native bounds. No native geometry/history claim.')
# One exact diagnostic: Riesz and mass-gap do not force the constant-test projection sign.
G=[[F(10001),F(1),F(1)],[F(1),F(10001),F(1)],[F(1),F(1),F(101,100)]]
A=[G[i]+[G[i][i]] for i in range(3)]
for i in range(3):
 pivot=A[i][i];A[i]=[x/pivot for x in A[i]]
 for j in range(3):
  if j!=i:
   factor=A[j][i];A[j]=[A[j][k]-factor*A[i][k] for k in range(4)]
c=[A[i][-1] for i in range(3)]
eps=F(1,1000000);parent_intersection=[eps,2*eps,F(1,100)+eps]
sign=sum(c[i]*parent_intersection[i] for i in range(3))
assert sign==F(-4948969999,505001000000)<0
# Triangle-of-affinities and within-chain gap hold in this source-set model.
assert F(1,10001)+F(1,100)<F(1,8)
assert F(10001)/F(101,100)>729
print('PASS one finite source-Gram projection sign check:',sign)
print('This is not a counterexample to the full native historical contract.')
# Two exact positive soft-branch models with a single common full source on25 cells.
# Actual incidence masses: two disjoint triples (3 each), their singleton descendants,
# and parent supports of masses7 and25. K=2,h=1/2 are diagnostic parameters.
# For opposite sources, initial exclusive law selects the triple with probability1/4;
# each retained own-high triple then jumps deterministically to that source singleton.
paid=F(0);rem=F(0);raw=F(0);weighted=F(0)
for ma in [F(7),F(25)]:
 gamma=F(18,16)/ma**2
 Fmass=F(8)/ma
 chi=min(F(1),2*Fmass)
 assert 0<chi<=1
 assert (chi==1)==(ma==7)
 paid+=gamma*chi;rem+=gamma*(1-chi);raw+=gamma;weighted+=gamma*Fmass
 assert gamma*chi<=2*gamma*Fmass
assert paid>0 and rem>0 and paid+rem==raw and paid<=2*weighted
print('PASS positive full-matching finite soft split: 2 parents; full and partial payment both positive')
print('These finite centers and diagnostic K,h do not certify native original stage/rank/history.')
