# R424 independent final audit

FINAL PASS — for the actual cross-parent WEIGHTED fixed-test analysis bound, its same-label node-mass soft payment Ω424W, the displayed complete account, and the explicitly conditional auxiliary norm statements. The full R424 source budget, general weak-type closure and complete native-history numerical fixture remain unproved. The formal payment does not depend on the auxiliary product-absolute-continuity assumption. Independent screening preceded author proof reading; this final record supersedes PRE where needed. Only reviewer audit files were edited.

## 1. Fixed-test cross-parent theorem

Independently derived and then read the entire main, geometry and auxiliary proofs. For a single fixed global g∈L²(f), Cauchy and full matching give ∫μ(dv)|⟨g,e_v⟩|²≤(A_n/q_-)||g||². The actual selected-center tail is ∫_{m_A>d}q_Ac_A(x)dA/m_A²≤2λ/(q_-d); one may prove it by the pointwise max(d,q_-u) envelope or positive layercake. Both retain true Lebesgue centers, strict cutoffs and mass atoms. No source-density bound or independent chosen-radius integration is used.

For one path generation j, the original probability-kernel domination and complete source exchange yield exactly
(S/h)∫μ(dv)|⟨g,e_v⟩|²∫_{m_A>K^(j+1)m_v}q_AI_Av dA/m_A².
The TWO parent-mass denominators are respectively the theorem's 1/m_A weight and the parent posterior. Tail integration over the full Q_v source cancels m_v and bounds the inner integral by 2λ/[q_-K^(j+1)]. Each generation includes the initial node, while a stopped node is counted once and absent in later generations. The original initial exclusive denominators exceed h; each subsequent bound uses an actual subprobability of total at most 1.

After removing future restrictions only for an upper bound, the same-z stage sum and original β/C_col capacities give S once. The two paths give the other factor 2, and Σ_jK^(-j-1)=1/(K−1). Therefore
C_child=4SλA_n/[hq_-²(K−1)]
is correct. There is no extra stage/layer/length factor, union factor, τ^(-1), or omitted q conversion. The remaining actual restrictions are retained in the theorem's left side. The fixed g and 1/m_A hypotheses are substantive; a source-, parent- or path-dependent test cannot be substituted without its actual integrated norm/change of measure.

## 2. Actual positive source-priced split and mother account

The globally fixed constant test g=1 belongs to L²(f), with ||1||²=W and |⟨1,e_v⟩|²=m_v. Thus the theorem directly controls the actual ticket function F_mass=Σ_{both full chains}m_v/m_A. On the SAME Π423, χ=min(1,KF_mass) and 1−χ form an exact positive split. The payment is
Ω424=4SλA_nK/[hq_-²(K−1)]
=4S(λ/q_-)ε_0(A_n/s)K/(K−1)≤4S(λ/q_-)ε_0sK/(K−1).
The inequality uses A_n≤1+n≤s². No posterior point-value substitution, renewed sampling or filter normalization is present. Positive R424 retains (1−KF_mass)_+, all original fields/history/paths and R423's joint Gram bounds, and satisfies Σm_v<m_A/K. A uniform deleted fraction or closure of the complement is not claimed.

The optional X bound 2SK/[hq_-(K−1)]X_q is independently correct: full matching bounds the per-generation first-mass integral by m_A/[q_-K^(j+1)]. It is another upper bound for this SAME P424 and is not charged alongside Ω424W. The formal account chooses Ω424W only.

Read all complete G0/BH/entrance substitutions. V424=V413+Ω424, with C423 and Fhat unchanged, gives exactly the displayed 16/32/64 Fhat coefficients. The sole new entrance price is 64ΛFhatΩ424 W. No X fee, feedback change, refund of old square credit, or certification of the old global absorption balance occurs. Old external terms, physical-time atoms and low-dimensional/full-scale qualifications remain.

## 3. Projection companion and conditional-source correction

The projection companion is valid only in its precise fixed-g weighted form. With p=Proj_children e_A, α=G^(-1)b and c0=5/24, ||α||²≤2/[c0²(K−1)]. Combining this with C_child gives C_proj=8SλA_n/[c0²hq_-²(K−1)²]. For g=1 this controls ∫Π423|⟨1,p⟩/√m_A|² by C_projW. The constant-test innovation difference retains an unsigned cross term; the finite sign diagnostic supplies no general native-history counterexample and no second receipt. Main does not substitute g=e_A into the fixed-global-g theorem.

A necessary auxiliary repair was made before this final approval. Merely omitting x itself from a record γ does NOT guarantee Ξ_A≪π_A⊗ν_A: a recorded deterministic continuous function φ(x) may produce a singular graph. Aux now explicitly assumes product AC for its conditional-source statements, does not infer it for every original clock/history record, and requires separate verification for a specific coarse record. Main states the same condition; the artificial likelihood models satisfy it. This final scope also restricts any broader PRE wording about common path-density arguments: center-sequence product domination cannot automatically be extended to arbitrary retained deterministic source-dependent records.

Under that stated condition the auxiliary identities pass: g_γ=r_γe_A has norm² L_γ, coefficients √(m_A/m_v), and L_γ=m_A/f(D_γ)+the displayed nonnegative orthogonal fluctuation. Infinite L_γ is not treated as a free Hilbert test. The minimal norm t*G^(-1)t and its spectral bounds are valid on the original path span; all averaged prices retain the unnormalized record weight Z_Aν_A. These are conditional norm-cost statements, not a source budget. They are independent of the formal fixed-g=1 payment above.

## 4. Independent execution and evidence categories

Read all three scripts and executed isolated temporary copies. Every stdout matched the final supplied .result.txt bytes exactly; the regenerated aux JSON also matched exactly. No author script/output was overwritten.

Parent: 30 rational parameter-envelope configurations (9/9/12) and 120 soft-split/entrance algebra configurations. Klo=2^√n bounds the decreasing factor K/(K−1) from above; it is not an exact exponential evaluation. Geometry: 12 finite matched-incidence all-g matrix checks by exact LDL, two positive finite full/partial soft-branch models, and one finite projection-sign check. Those matrices use measured finite-center Ctail/J constants, not assumed native tail constants; the soft examples use diagnostic K,h and do not realize the complete original history. Aux: 20 positive-volume continuous-center/full nonuniform L1 matching models (4/8/8), 17 positive orthogonal-extra costs and 20 exact minimum norms, with artificial bounded record likelihoods. The native matching evidence and finite conditional algebra are not merged into a full active-path/history claim.

The general theorem and payment follow from the analytic proof, not sample counts. Temporary PRE Bayesian arithmetic is not added to these author/parent counts. No final ZIP extraction, PDF compilation or Git operation was performed by this auditor. The unpriced R424 complement remains explicit.

## 5. Final byte bindings (SHA-256)

- `r424_main.md`: `64094d03f54e658d43fe05128f3ac6a323c962f1f8a672a46a5f94eb66851093`
- `r424_readme.md`: `349fc4b4ba8ecf3c7483ea868c9708b325a7888d1fe73cc796c2420ba45bd9a1`
- `r424_geometry.md`: `34856dcb3448893b29e64a41a0b1872bcfbafe467685c06c7f702afe82e6b975`
- `r424_aux.md`: `4713dfd4090880f6ab2dbd42356669f64f78f4d52c415a572ff3df3af2c754cc`
- `r424_parent_check.py`: `c5eb5135369bc6ffb9f8f3d2be03992065585ac18fce56d46539d28b5ad8b740`
- `r424_geometry_check.py`: `134c2de0e654d725c286a24be4868e825ebe8b5f816924f060c98e191908f92f`
- `r424_aux_check.py`: `650fb533bde5841ec366b25a5f564870e2de5131f850edafe7b1c44d941afb5f`
- `r424_parent.result.txt`: `4feb29283b2dd1076fde0f59395e554149cb696104e19bdfe91e14b6cfed0fb0`
- `r424_geometry.result.txt`: `2630da06889b988a3e2755b8dfd40e6b0a99a33a665a0525bacd6ea7514f7109`
- `r424_aux.result.txt`: `8360f6bad2de17cfd4486fe6fbb403482a57270158533d28d8f7ada32948c167`
- `r424_aux_result.json`: `9ebca95aed9433544b3fc1dbdc73a761043f185969a94f1af8f03c8988a26900`
- `r423_main.md`: `e52bfc72017e1531968661bf6319760a665c9fa2046c0d306b803786dd8b4caf`
- `r413_main.md`: `ed03c99fbea15e831c6250832a9fc1f48f04d92cba3475fa60266542badf593f`
- `r411_aux.md`: `08877dd6346771a4711a454fbf7704db27d0fd3a05f2dfbab45d69e0ac2c3823`
