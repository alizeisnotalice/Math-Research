# R424：跨父的全局子向量分析预算与子质量软付款

2026-10-20。本轮证明一个对同一全局测试函数成立的、保留实际父测度与两条保源路径的加权来源预算。取全局函数 g=1 后，得到原 R423 上新的根阶 W 正分数付款。未证明其完整补集的占用层一致上界。

## 1. 原测度与准确命题

沿用 R423 的原完整标签正测度 Θ423，其总质量为 R423；全部 f、实际 Lebesgue 中心、m_v=f(Q_v)=q_vR_v^n、q_-≤q_v≤λ、a≤R_v≤b≤2a、Γ_i、D_i、stage、首次删除、early、old y/new z、原 clock 和历史门不变。μ=dv/m_v，σ=q_AdA，π_A=f1_QA/m_A，X_q=∫σ，W=∫f。记 A_n=1+n log(b/a)，K=e^{√n}，s=1+√n，h=s/(ε_0q_-)，S=β+C_col。

同一标签上的两条原路径为 b0=w,…,bNy 和 d0=t,…,dNz；后继不刷新来源，不获得原 Γ 历史。定义 e_v=1_Qv/√m_v∈L²(f dx)。本轮的全局命题是：对于**同一个固定的** g∈L²(f dx)，
\[
 \boxed{\mathcal A(g):=
 \int\frac{d\Theta_{423}}{m_A}
 \left[\sum_{j=0}^{N_y}|\langle g,e_{b_j}\rangle|^2+
       \sum_{k=0}^{N_z}|\langle g,e_{d_k}\rangle|^2\right]
 \le C_{\rm child}\|g\|_{L^2(f)}^2,} \tag{1}
\]
\[
 C_{\rm child}=\frac{4S\lambda A_n}{h q_-^2(K-1)}.
\]
这不是逐路径 Bessel 界乘以未知总交通，而是已经积分所有实际父及原标签的来源预算。1/m_A 权不可删除；g 不得依赖父、路径、阶段或其他标签。本命题实际上适用于同一原合同下的正限制；证明上界时可删除 R423 额外 Gram 门，但实际左侧始终保留。

## 2. 两项原生中心输入

### 2.1 父接收者平方尾

对固定 x、H>0，完整匹配和真实中心体积给
\[
 \int_{m_A>H}\frac{q_Ac_A(x)}{m_A^2}dA
 \le\frac{2\lambda}{q_-H}. \tag{2}
\]
证明使用正层饼 1/m²=∫_m^∞2r^{-3}dr。m_A≤r 且捕获 x 时，R_A≤(r/q_-)^{1/n}，所有实际中心 A 位于该边长的中心盒，体积≤r/q_-。故左侧至多2λ∫_H^∞r^{-3}(r/q_-)dr。它是实际选择器的中心子水平上包络，不把边长独立积分，不对 f 设密度帽。严格 m_A>H、质量原子均无需边界修正。

### 2.2 子向量的全空间分析

对同一 g，Cauchy–Schwarz 与完整匹配给
\[
 |\langle g,e_b\rangle|^2
 =\frac{|\int_{Q_b}gf|^2}{m_b}\le\int_{Q_b}|g|^2f.
\]
因此
\[
 \int|\langle g,e_b\rangle|^2\mu(db)
 \le\int |g(x)|^2f(x)J(x)dx
 \le\frac{A_n}{q_-}\|g\|_{L^2(f)}^2, \tag{3}
\]
其中 J(x)=∫c_b(x)μ(db)≤A_n/q_- 是包括最小边长基底的原生包络。此处的线性 A_n 保留，随后由原路径归一化 h 产生根阶来源价。

## 3. 原父权、来源和各代核的完整交换

R423 已证，在给定 A,y,z 的原未条件化生成核下，每一代 j≥0（含初始见证）满足
\[
 \Pi_j^y(db)\le\rho_y(db)/h,
 \quad \rho_y(db)=c_b(y)\mu(db),
 \quad m_b<m_A/K^{j+1}. \tag{4}
\]
初始 exclusive 分母>h 来自原 R413 的旧 T_v>4h、新 L≥4 及 soft C_A<h。后继(4)使用上一代真实 active 子概率 ν 的总量≤1：∫ν(dv)ρ_y(db)1_far/Z_v≤ρ_y(db)/h；不将 ν 替换成 ρ/h 后积分ρ/Z。已停止路径在后续代为零。

原 Θ423 可含依赖未来路径的限制。证明上界时删去这些正限制，恢复原条件路径核，再用(4)；不条件化后重新归一。对共同 stage/first-death 标签先用 early≤b_i、Γ_i 嵌套和同一 z 上 Σ_i b_i(z)≤1，继而用原逐来源 β/Ccol，得到父双来源上包络 Sσ(dA)π_A(dy)π_A(dz)。这一步只为上界，不是改写实际 Θ423。固定 g 的分析量与冻结原路径核不依赖被求和的阶段。

对 y 路径第 j 代，其对(1)的贡献至多
\[
 \frac Sh\int\frac{\sigma(dA)}{m_A}
 \int\pi_A(dy)\int_{m_b<m_A/K^{j+1}}
 c_b(y)|\langle g,e_b\rangle|^2\mu(db).
\]
另一来源 π_A 积分为1；未把 b_i 转移到旧来源。交换完整 y，令 IAb=f(QA∩Qb)，得到精确的上界表达式
\[
 \frac Sh\int |\langle g,e_b\rangle|^2\mu(db)
 \int_{m_A>K^{j+1}m_b}\frac{q_AI_{Ab}}{m_A^2}dA. \tag{5}
\]
两次 1/m_A 分别来自命题中的父权和 π_A 的归一。子 μ(db)=db/m_b 仍原样保留。

对(5)内层再交换完整 x∈Qb，按(2)取 H=K^{j+1}m_b：
\[
 \int_{m_A>K^{j+1}m_b}\frac{q_AI_{Ab}}{m_A^2}dA
 \le\int_{Q_b}f(x)\frac{2\lambda}{q_-K^{j+1}m_b}dx
 =\frac{2\lambda}{q_-K^{j+1}}. \tag{6}
\]
此处 m_b 通过真实完整匹配抵消，并非将来源交叠当几何体积。用(3)，该代贡献≤2SλA_n/[h q_-²K^{j+1}]||g||²。

z 路径完全同价；两个方向给因子2。最后 Σ_{j≥0}K^{-j-1}=1/(K−1)，证明(1)。其中父平方尾的因子2与两路径因子2各出现一次；S 已包含原两个父端，不再乘2。全体阶段、路径及占用层合计一次，没有隐藏长度或层编号。非负积分用 Tonelli；一般 L²(f) 函数可由截断和该有限上界通过，复值时用绝对平方。

## 4. 同一全局 g=1 的正式根阶正分拆

由于 W<∞，常数1属于 L²(f)，且 |〈1,e_v〉|²=m_v。定义同一实际路径标签上的
\[
 F_{\rm mass}=\frac1{m_A}
 \left(\sum_{j=0}^{N_y}m_{b_j}+\sum_{k=0}^{N_z}m_{d_k}\right).
\]
(1)立即给
\[
 \int F_{\rm mass}\,d\Theta_{423}\le C_{\rm child}W. \tag{7}
\]
只取一个软分拆：
\[
 \chi_{\rm mass}=\min(1,KF_{\rm mass}),\quad
 P_{424}=\int\chi_{\rm mass}d\Theta_{423},\quad
 R_{424}=\int(1-\chi_{\rm mass})d\Theta_{423}. \tag{8}
\]
R423=P424+R424 精确且非负。原路径完全不变，不新增质量阈值程序，也不重算任何场。
\[
 \boxed{P_{424}\le\Omega_{424}W,\qquad
 \Omega_{424}=K C_{\rm child}
 =\frac{4S\lambda A_nK}{h q_-^2(K-1)}.} \tag{9}
\]
设 r=λ/q_-；因 A_n≤s²，显示的根阶价格为
\[
 \Omega_{424}\le4Sr\varepsilon_0\frac K{K-1}\,s.
\]
所有冻结参数依赖保留。没有新增 X 费，不声称每个输入都有固定比例被支付。特别地，它整付整个路径子质量和≥m_A/K 的事件，同时同价付低和支的真实软份额；不能再次为该硬事件收费。

作为同一支的可选上界，(4)和原实际中心质量容量还给
\[
 \int F_{\rm mass}d\Theta_{423}\le\frac{2S}{h q_-(K-1)}X_q,
 \quad P_{424}\le\frac{2SK}{h q_-(K-1)}X_q. \tag{10}
\]
具体每代先交换来源得 ∫π_Aρ_y(db)m_b=(1/m_A)∫IAb db≤m_A/[q_-K^{j+1}]，再乘父权1/m_A、1/h及两方向求和。本主账仅采用(9)；可以写两价格的 min，但绝不累加或付两次。

## 5. 完整回代和剩余

取 V424=V413+Ω424，C423 和 Fhat=(1−32δ−16η)^{-1} 不变。原母式变为
\[
 G_0\le16\widehat F[R_{424}+C_{423}X_q+V_{424}W],
\]
\[
 B_H\le32\widehat F R_{424}+[E_{387}+32\widehat F C_{423}]X_q
 +[S_{390}+8s+32\widehat F V_{424}]W.
\]
完整入口保持
\[
 \Lambda\{8\lambda HW+2d_{\rm eff}A_{{\rm entrance},n}W_\nu/H
 +64\widehat F R_{424}
 +[2E_{387}+64\widehat F C_{423}]X_q
 +[2S_{390}+16s+64\widehat F V_{424}]W\}.
\]
本轮唯一新增入口价为64ΛFhatΩ424 W。原 X 吸收、反馈与其他旧费用不重算，不退款。

R424保留R423的全部历史、双来源、路径及联合Gram条件，并带精确余权
\[
 \left(1-\frac K{m_A}\left[\sum_jm_{b_j}+\sum_km_{d_k}\right]\right)_+.
\]
其正支上整个双路径子质量和严格小于m_A/K。严格 far 原来只逐节点限制 m_v<m_A/K^{j+1}，不强制此总和条件；本轮支付的是新实际正份额。补集仍可能承载全部困难，不能由小总和声称跨父不交、历史可继承或占用层 P 已证。

## 6. 父投影核查（不另收费用）

仅说明本轮起始投影想法的适用边界。设 p 为 e_A 到同一全部子向量 span 的正交投影，h_A=e_A−p，c0=5/24。由 R423 Gram 下界和 strict mass gap，投影系数的欧氏平方和≤2/[c0²(K−1)]。将(1)用于同一 g，便有
\[
 \int\frac{|\langle g,p\rangle|^2}{m_A}d\Theta_{423}
 \le C_{\rm proj}\|g\|^2,
 \quad C_{\rm proj}=\frac{8S\lambda A_n}{c_0^2h q_-^2(K-1)^2}.
\]
对常数1记 d=〈1,p〉/√m_A，Jinnov=∫(1−d)²dΘ423。则
\[
 J_{\rm innov}-R_{423}=-2\int d\,d\Theta_{423}+\int d^2d\Theta_{423},
\]
\[
 |J_{\rm innov}-R_{423}|\le2\sqrt{C_{\rm proj}WR_{423}}+C_{\rm proj}W.
\]
没有证明交叉项具有所需符号，因而不将投影式称为新的负信用，也不提出更强全算子根阶界为默认目标。本轮正式付款只来自第4节，不将投影修正再加入母账。

## 7. 实际本机检查与证据范围

运行 `/tmp/r424_geometry_check.py`，stdout同前缀保存：

```
PASS global weighted child-analysis matrices: 12
Finite matched full-source incidence and positive center weights; measured Ctail,J replace native bounds. No native geometry/history claim.
PASS one finite source-Gram projection sign check: -4948969999/505001000000
This is not a counterexample to the full native historical contract.
PASS positive full-matching finite soft split: 2 parents; full and partial payment both positive
These finite centers and diagnostic K,h do not certify native original stage/rank/history.
```

12个 Fraction 全局模型使用同一个非均匀完整来源、多个匹配接收者与正中心权，计算真实 source-retaining 子概率路径、所有父共同的分析矩阵，并以有理 LDL 消元验证对全部全局 g 的矩阵界。有限模型用实测的父尾常数 Ctail 和 Jmax；不把任意离散中心权误称满足原生(2)。其界为2 Ctail Jmax/[h(K−1)]，与一般证明中 Ctail=2λ/q_-、Jmax=A_n/q_-完全对应，S=1。

另有两个正软分拆模型：同一25个来源cell、两个父支持质量7与25、两个互不相交的三cell初始见证及各自单cell后继；K=2、h=1/2为诊断参数。原exclusive初始law选三cell见证的概率各1/4，保 own-high 初始后再跳到单cell；每方向两节点总质量4。源后验、原概率及软份额精确计算，整付与部分付款均正，剩余亦正。这些是 full-f matching 的有限中心模型，未认证原生Lebesgue、原固定K/h及完整阶段历史。

最后一个三集合有理投影例只检查 Gram 条件本身不能推出常数测试投影项的符号，不是一般原合同反例，也不参与正式付款。一般新收据由第2–5节证明；不以有限计数代证。不追加新的密度门或分支，冻结后停止。
