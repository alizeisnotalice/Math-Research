from fractions import Fraction as F
from itertools import product
from math import isqrt
from pathlib import Path
import json

def box(c,s):return tuple((x-s/2,x+s/2) for x in c)
def inc(C,B,R):
    yes=all(l>=v-R/2 and r<=u+R/2 for (l,r),(u,v) in zip(C,B))
    no=any(r<=u-R/2 or l>=v+R/2 for (l,r),(u,v) in zip(C,B))
    assert yes or no
    return int(yes)
def solve(A,b):
    N=len(b);R=[list(A[i])+[b[i]] for i in range(N)]
    for j in range(N):
        p=next(i for i in range(j,N) if R[i][j]);R[j],R[p]=R[p],R[j]
        v=R[j][j];R[j]=[x/v for x in R[j]]
        for i in range(N):
            if i!=j:
                v=R[i][j];R[i]=[x-v*y for x,y in zip(R[i],R[j])]
    return [row[-1] for row in R]
def run(n,split,a,b,cellside):
    sides=[F(2),F(3,2),F(5,4),F(1)]
    mass=[r**n for r in sides];root=[r**(n//2) for r in sides]
    center=[(F(0),F(j,1024))+(F(0),)*(n-2) for j in range(4)]
    blocks=[box(c,F(1,4096)) for c in center]
    source=[]
    def add(x,m):source.append((box((x,)+(F(0),)*(n-1),cellside),m))
    add(F(-1,8),split);add(F(1,8),1-split)
    add(F(57,100),mass[2]-mass[3]);add(F(68,100),mass[1]-mass[2]);add(F(7,8),mass[0]-mass[1])
    capture=[[inc(C,blocks[j],sides[j]) for j in range(4)] for C,m in source]
    for j in range(4):assert sum(m*capture[i][j] for i,(C,m) in enumerate(source))==mass[j]
    k=isqrt(n)+(isqrt(n)**2<n);K=F(3**k)
    assert all(mass[j]>K*mass[j+1] for j in range(3))
    # Parent pi, fixed recorded chain, bounded likelihood supported on full intersection.
    pi=[m/mass[0] for C,m in source];lik=[a,b,F(0),F(0),F(0)]
    Z=sum(p*l for p,l in zip(pi,lik));r=[l/Z for l in lik]
    assert sum(p*x for p,x in zip(pi,r))==1
    d=sum(m for i,(C,m) in enumerate(source) if all(capture[i]))
    leverage=sum(p*x*x for p,x in zip(pi,r))
    base=mass[0]/d
    fluct=sum(pi[i]*(r[i]-(base if all(capture[i]) else F(0)))**2 for i in range(5))
    assert leverage==base+fluct
    gram=[[sum(m*capture[k][i]*capture[k][j] for k,(C,m) in enumerate(source))/(root[i]*root[j]) for j in range(1,4)] for i in range(1,4)]
    target=[root[0]/root[j] for j in range(1,4)]
    coeff=[]
    for j in range(1,4):
        coeff.append(sum(m*r[i]*capture[i][0]*capture[i][j]/(root[0]*root[j]) for i,(C,m) in enumerate(source)))
    assert coeff==target
    rhs=sum(x*x for x in target);B=F(43,24);lower=F(5,24)
    assert rhs<=B*leverage
    invt=solve(gram,target);minnorm=sum(x*y for x,y in zip(target,invt))
    assert rhs/B<=minnorm<=rhs/lower and minnorm<=leverage
    assert minnorm==base # nested model: last vector is exact minimal reference.
    parentenergy=sum(mass[j]/mass[0] for j in range(1,4))
    assert parentenergy<=1/(K-1)
    # Density can change by cell compression without changing these mass identities.
    densities=[m/cellside**n for C,m in source]
    return {'n':n,'split':str(split),'likelihood':[str(a),str(b)],'cellside':str(cellside),'leverage':str(leverage),'minimum_norm':str(minnorm),'orthogonal_extra':str(fluct),'parent_energy':str(parentenergy),'joint_weighted_leverage':str(Z*leverage),'density_min':str(min(densities))}
stages={
'initial':[(64,F(1,2),a,b,F(1,8192)) for a,b in product([F(1,4),F(1)],[F(1,3),F(1)])],
'likelihood_pressure':[(64,p,a,b,F(1,16384)) for p,a,b in product([F(1,4),F(2,3)],[F(1,16),F(1)],[F(1,8),F(1)])],
'expanded':[(n,p,F(1,8),F(1),d) for n,p,d in product([100,144],[F(1,3),F(3,4)],[F(1,8192),F(1,32768)])]
}
results={name:[run(*row) for row in rows] for name,rows in stages.items()}
flat=[r for rows in results.values() for r in rows]
summary={'counts':{k:len(v) for k,v in results.items()},'total':len(flat),'positive_orthogonal_extra':sum(F(r['orthogonal_extra'])>0 for r in flat),'exact_minimum_norm':len(flat)}
Path(__file__).with_name('r424_aux_result.json').write_text(json.dumps({'summary':summary,'results':results},indent=2)+'\n')
print('PASS',summary)
print('Native continuous-center octave matching and full nonuniform L1 sources. Artificial bounded conditional likelihood; not original active path/history realization.')
print('r424_aux_result.json')
