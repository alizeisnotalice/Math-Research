import json
from mpmath import mp
rows=[]
for ks,ts in [([0,1,2],[mp.mpf('.01'),mp.mpf('1'),mp.mpf('4')]),([0,1,2,8,32],[mp.mpf('1e-8'),mp.mpf('.2'),mp.mpf('20'),mp.mpf('100')]),([0,1,4,64,256],[mp.mpf('1e-20'),mp.mpf('1e-4'),mp.mpf('50'),mp.mpf('1000')])]:
 err=mp.mpf(0);count=0
 for k in ks:
  for t in ts:
   with mp.workdps(70):
    tau=mp.exp(-t)
    finite=tau*mp.fsum(t**r/mp.factorial(r) for r in range(k+1))
    integral=tau if k==0 else tau*t**k/mp.factorial(k)+mp.gammainc(k,t,mp.inf)/mp.factorial(k-1)
    e=abs(finite-integral)/max(abs(finite),abs(integral),mp.mpf('1e-10000'))
    assert e<mp.mpf('1e-60');err=max(err,e);assert 0<=finite<=1+mp.mpf('1e-60')
    if k:assert finite>=tau
    count+=1
 rows.append(dict(cases=count,k_max=max(ks),relative_identity_error=str(err)))
print(json.dumps(dict(status='PASS',scope='Finite70digit gamma integral vs polynomial identity checks, no interval/whole-input certificate.',stages=rows),indent=2))
