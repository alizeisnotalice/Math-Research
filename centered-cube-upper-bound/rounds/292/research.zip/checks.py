#!/usr/bin/env python3
"""One-dimensional actual kernel entropy/Renyi profiles; no n-dimensional quadrature."""
import json
from pathlib import Path
import mpmath as m
THETAS=['.5','.75','.9','.99']
def phi(x):
 x=abs(x)
 return 1-m.expint(3,m.mpf('.5')-x)-m.expint(3,m.mpf('.5')+x) if x<=m.mpf('.5') else m.expint(3,x-m.mpf('.5'))-m.expint(3,x+m.mpf('.5'))
def fcore(s,x):return 1-s+s*phi(x)
def xlog(x,p):return x*m.log(x)**p if x else m.mpf(0)
def baseline(dp):
 with m.workdps(dp):
  tailmass=2*(m.mpf(1)/3-m.expint(4,1))
  measured=2*m.quad(phi,[m.mpf('.5'),m.inf]);mass=2*m.quad(phi,[0,m.mpf('.5')])+measured
  assert abs(measured-tailmass)<m.mpf('1e-30') and abs(mass-1)<m.mpf('1e-30')
  k1=2*m.quad(lambda x:xlog(phi(x),1),[m.mpf('.5'),m.inf]);k2=2*m.quad(lambda x:xlog(phi(x),2),[m.mpf('.5'),m.inf])
  tails={theta:2*m.quad(lambda x:phi(x)**m.mpf(theta),[m.mpf('.5'),m.inf]) for theta in THETAS}
  return tailmass,k1,k2,tails

def oned(sstr,dp,base):
 with m.workdps(dp):
  s=m.mpf(sstr);T,k1,k2,tails=base
  if not s:return {'entropy':m.mpf(0),'variance':m.mpf(0),'Z':{theta:m.mpf(1) for theta in THETAS},'tail_mass':m.mpf(0)}
  ls=m.log(s)
  ent=-2*m.quad(lambda x:xlog(fcore(s,x),1),[0,m.mpf('.5')])-s*(ls*T+k1)
  second=2*m.quad(lambda x:xlog(fcore(s,x),2),[0,m.mpf('.5')])+s*(ls*ls*T+2*ls*k1+k2)
  var=second-ent*ent;assert ent>=0 and var>=0
  Z={}
  for theta in THETAS:
   th=m.mpf(theta);z=2*m.quad(lambda x:fcore(s,x)**th,[0,m.mpf('.5')])+s**th*tails[theta]
   assert z>=1 and z<=1+s**th*tails[theta]+m.mpf('1e-30')
   assert m.log(z)/(1-th)>=ent-m.mpf('1e-30')
   Z[theta]=+z
  return {'entropy':+ent,'variance':+var,'Z':Z,'tail_mass':+(s*T)}

with m.workdps(100):
 settings=[('initial',16,['0','1/16','1']),('pressure_stress',512,['0','1/512','logn/n','1/16','1']),('expanded',1000000,['0','1/n','logn/n','1/16','1'])]
 specs=[]
 for name,n,choices in settings:
  cs=[]
  for choice in choices:
   s=m.mpf(0) if choice=='0' else (m.mpf(1)/n if choice=='1/n' else (m.log(n+2)/n if choice=='logn/n' else (m.mpf(1)/512 if choice=='1/512' else (m.mpf(1)/16 if choice=='1/16' else m.mpf(1)))))
   cs.append((choice,m.nstr(s,95)))
  specs.append((name,n,cs))

bases={dp:baseline(dp) for dp in [40,60]};cache={};stages=[];worst=m.mpf(0)
for name,n,choices in specs:
 profiles=[];previous=None
 for label,sstr in choices:
  if sstr not in cache:
   cache[sstr]={dp:oned(sstr,dp,bases[dp]) for dp in [40,60]}
  low=cache[sstr][40];hi=cache[sstr][60]
  with m.workdps(100):
   fields=[(low[k],hi[k]) for k in ['entropy','variance','tail_mass']]+[(low['Z'][th],hi['Z'][th]) for th in THETAS]
   err=max(abs(a-b)/max(1,abs(b)) for a,b in fields);assert err<m.mpf('1e-28');worst=max(worst,err)
   s=m.mpf(sstr);h=hi['entropy'];var=hi['variance'];ns=n*s
   if previous:
    assert all(hi['Z'][th]>=previous['Z'][th]-m.mpf('1e-28') for th in THETAS)
   previous=hi
   # Cutoff tau=e^-t; finite theta-grid minima are computable upper bounds, not optimized infima.
   cutoff=[('fixed_tau_1_over_16',m.log(16)),('t_equals_ns',ns),('t_equals_ns_log_e_n_over_max_ns_1',ns*m.log(m.e*n/max(ns,1))),('entropy_guided_t_equals_2nh',2*n*h)]
   rows=[]
   for cname,t in cutoff:
    candidates=[((1-m.mpf(th))*(-t)+n*m.log(hi['Z'][th]),th) for th in THETAS]
    logbound,theta=min(candidates);logbound=min(m.mpf(0),logbound)
    rows.append({'cutoff':cname,'t':m.nstr(t,25),'t_over_n':m.nstr(t/n,25),'entropy_minus_t_over_n':m.nstr(h-t/n,25),'best_grid_theta':theta,'log_computable_clip_upper_bound':m.nstr(logbound,25),'computable_clip_upper_bound':m.nstr(m.exp(logbound),25)})
   profiles.append({'s_label':label,'s':sstr,'ns':m.nstr(ns,25),'entropy_per_coordinate':m.nstr(h,25),'entropy_total_nh':m.nstr(n*h,25),'variance_per_coordinate':m.nstr(var,25),'hard_core_outside_probability':m.nstr(hi['tail_mass'],25),'entropy_over_s_log_e_over_s':m.nstr(h/(s*m.log(m.e/s)),25) if s else '0','max_normalized_40_vs_60_error':m.nstr(err,12),'Renyi':[{'theta':th,'Z':m.nstr(hi['Z'][th],25),'log_Z':m.nstr(m.log(hi['Z'][th]),25),'rate_log_Z_over_1_minus_theta':m.nstr(m.log(hi['Z'][th])/(1-m.mpf(th)),25)} for th in THETAS],'cutoffs':rows})
  print('PASS',name,label,flush=True)
 stages.append({'name':name,'n':n,'profiles':profiles,'one_dimensional_precision_runs':2*len(choices),'cutoff_profiles':4*len(choices)})
out={'status':'PASS','scope':'Actual one-dimensional E3 kernel quadrature at40/60 digits, analytically tensorized Renyi upper bounds. Finite ordinary precision evidence only, not outward intervals, n-dimensional integration, fitted n exponents, or a FULL source/history certificate. Grid minima are upper bounds, not claimed continuous-theta optima.','baseline_outside_phi_mass':m.nstr(bases[60][0],25),'baseline_outside_phi_logphi_integral':m.nstr(bases[60][1],25),'baseline_outside_phi_logphi_squared_integral':m.nstr(bases[60][2],25),'theta_grid':THETAS,'exact_formulas':{'phi_inside':'1-E3(.5-x)-E3(.5+x)','phi_outside':'E3(x-.5)-E3(x+.5)','outside_mass_of_phi':'2*(1/3-E4(1))','Renyi_clip_upper':'min(1,exp((1-theta)*log(tau)+n*log(Z_s(theta))))','entropy_identity':'For X~P_s, clip(P_s,e^-t)=E exp(-(t-sum_i log(1/f_s(X_i)))_+).','tail_entropy_decomposition':'outside entropy=-s*(log(s)*T+int_outside phi*log(phi))'},'max_normalized_40_vs_60_error':m.nstr(worst,12),'stages':stages}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,sort_keys=True,indent=2)+'\n')
print(json.dumps({'status':'PASS','profiles':sum(len(s['profiles']) for s in stages),'cutoff_profiles':sum(s['cutoff_profiles'] for s in stages),'max_error':out['max_normalized_40_vs_60_error']}))
