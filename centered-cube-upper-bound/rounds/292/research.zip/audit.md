# R292 independent audit

## Independent preauthor screen

Written before opening either R292 author proof. The original object is the positive low-pe traffic of R289, with all original masks, beta FIRST, hard cap, q in [3lambda/4,lambda], g=sqrt(LR), and full weighted accepted mass e_g over original Z_g. Put ell=1+log n, c_j=gamma^{-j}, gamma=1+1/n. On m=e_g/(ell q c_j^{-n/2}g^n)>M and p e_g<2Kq, exactly

 p < 2K c_j^{n/2}/(m ell g^n) <= 2K c_j^{n/2}/(M ell g^n).

Hence replacing p by min(p,2K c_j^{n/2}/(M ell g^n)) in a positive majorant is safe. This does not insert a multiplicative 1/M in the original p-kernel, and e_g is not localized to the actual pair LCA or a hard ball. The mass lower bound and small-parent side bound do not give such localization.

A safe fixed majorant is L_M(w)=sup over all LEGAL source-independent point parameters (s,L,R,j) of the clipped point kernel, retaining the ratio-band relation. The source row estimate is (16/3)||L_M||_1 W_beta: integrate the actual hard source first using h_R*nu<=4lambda and q>=3lambda/4. Independently the column FIRST estimate remains A_h W_nu, A_h=1+n log(b/a), by consuming beta with actual FIRST then integrating the hard point-scale envelope. Their minimum is valid. No inverse-e_g posterior normalization is free.

The fully paid fixed R291 all-soft envelope K_soft gives
 L_M <= min(K_soft,2K/(ell M a^n)),
where ||K_soft||_1=Csoft_n A_h<infinity, Csoft_n is the exact sum of maximal binomial probabilities. Therefore a finite source-linear row coefficient and convergence to zero for fixed n as M tends to infinity follow by dominated convergence. This by itself gives no root-order uniform dimension rate or polylogarithmic M.

The exact mapping to hard scale is
 [2K c_j^{n/2}/(ell M g^n)]R^n=(2K/(ell M))(sqrt(c_j)R/g)^n.
The original ratio band is c_j/gamma <= min(L,R)/g <= c_j. If R<=L this factor is <=c_j^{3n/2}<=1. If R>=L, it need not be bounded by an absolute constant: it is <=gamma^n c_j^{-n/2}, with sharper legal-scale bound <=gamma^{n/2}(R/L)^{n/4}<=sqrt(e)2^{n/4}. Orientation must be retained. Uniformly the threshold is <=2K/[ell M min(L,R)^n], but replacing min(L,R) by R is not free.

Selectors are actual measurable x-dependent parameters. For a valid fixed kernel bound their supremum must include every legal value and all menu/shape/scale costs. Clipping a latent mixture cannot be moved inside as an upper bound: min is concave, so min(EH,t)>=E min(H,t). Any author claim using the reverse inequality needs repair. Masks are only dropped in positive majorants; no change to the original e_g or low gate is authorized.

Original outer integration costs Lambda=128/119 ONCE for this low traffic. There is no high-branch factor 2 and no moving high-score clock fee. Original source sums remain disjoint leaf/seed sums. No wide closure or uniform root source price has yet been established by the independent screen.

## Executed local diagnostic

Python 3 checked 80 legal scale/band combinations at n=1,2,8,64,512 and L,R in {1,1.25,1.5,2}. Both orientation-specific inequalities above passed (0 failures). The hard-R normalized factor for L=1,R=2 reached 4.63557e+38, confirming that an orientation-free absolute constant is unavailable from the band alone. This finite diagnostic supplements the displayed algebra; it is not a proof of a dimension-uniform bound.

## Information-profile author review

PASS for /tmp/r292_information_profile.md SHA256 1cae0985165aca0b3162731dcf3e46ba6c1e6194d6b79b5e74cada85459d5163. The clipped-product identity follows directly by dividing min(p,e^-t) by p on its auxiliary product support. The fractional-moment bound has the correct direction and finite moment domain delta in (0,1). At s=0 the unit-box support convention also gives the stated identity. The small-s entropy expansion has exact outside term and inside error in [-s² A2,0]; the series argument is valid on v<=1/2. T=2/3-2E4(1) and both phi formulas are correct. The actual normalized cap uses (L/g)^n (not R/g), with tau>=1 giving no improvement. No scale/softness supremum is integrated for free and no original-input independence is inferred.

Executed mpmath at 35 digits: direct one-dimensional T integral versus E4 expression error 3.7616e-37, five direct phi integrals versus E3 formulas maximum error 7.5232e-37, and 101 scalar entropy bounds passed. T=0.4945416840175452101620387. Numerical checks supplement the exact derivations.

This information calculation supplies valid finite kernel bounds, but does not yet establish the uniform root source payment for the original wide high-m branch.

## Independent fixed-profile payment screen

Before author proof availability: for a frozen softness band I_h subset [0,S_h], put U_S(u)=sup_{0<=s<=S} product f_s(u_i), V_h=min(U_S,tau_h), J_h=integral V_h. These profiles are nonnegative, even and coordinatewise decreasing. Layercake into star-shaped superlevel sets gives the scale-envelope upper bound integral sup_{a<=L<=b} L^{-n}V_h(w/L)dw <=A_h J_h. For any star body K the corresponding indicator envelope has exact mass A_h|K|; supremum and profile layercake need only be interchanged in the upper-bound direction.

On actual rows with normalized cap tau_row=(2K/(ell m))c_j^{n/2}(L/g)^n<=tau_h, the original density is majorized by the scaled V_h. Consuming the original hard cap on E before extending x to all space gives (16/3)A_h J_h W_beta. Frozen disjoint softness bands may be summed at their explicit costs; the actual m gate remains selector-dependent and is never replaced by an unjustified fixed number. The original low outer price multiplies once by Lambda.

If a separately proved finite coefficient R_h gives J_h<=R_h tau_h^delta for delta in (0,1), then the explicit gate m>=(2K/ell)c_j^{n/2}(L/g)^n(R_h/epsilon_h)^{1/delta} gives J_h<=epsilon_h. This is a valid paid branch, with the exact complement retained. Verification of the proposed coefficient R_h awaits the author proof.

## Original accepted-tree dependence warning

The original threshold H_j(t)=q(x)max{t^n,sqrt(n)c_(j+1)^n t^n,sqrt(n)(t²/b)^n} makes the original accepted exclusion node and Z_j depend on actual q(x). A receiver-independent root(y) cannot be introduced without a proved monotone envelope or frozen outer q. Under the documented monotonicity of tree exclusions, replacing q by q_- may enlarge Z and e, so it can majorize a necessary high-e set. It does not preserve low p e<2Kq: enlarging e reverses the useful low-gate implication. Actual clipping must therefore stay separately justified. Likewise a scale enlargement at the capped parameter endpoints needs an explicit capped-kernel construction and comparison. No common dilation beyond the legal interval is authorized.

## Independent clipped-acceptance root screen

Before reading the author file: a NEW gate using the fixed q_- enlarged exclusion set is valid, provided actual low clipping remains justified by actual e_g separately. Let Gamma_t be the integrated supremum of the clipped product over legal selectors with g>=t and full ratio band. The feasible g interval is [a/c_j,b c_j]; empty bands contribute zero. For g<t'<=b c_j and L>=R, L'=max(L,t'/c_j), R'=t'^2/L' enlarges BOTH scales, stays in [a,b], and retains min/g in [c_(j+1),c_j]. Swapping orientation handles R>=L. Thus Gamma_t<= (t'/t)^(2n)Gamma_t' for feasible t<=t', as well as monotonicity. This ensures right continuity.

The thresholded original tree with q_- has smaller excluded node than actual q, hence larger accepted set. Its product with Gamma_t has nonincreasing right-continuous E^-_t. If a crossing exists, its first root is attained; if it does not exist, the corresponding new gate is empty and must be assigned zero traffic. The endpoint t=b c_j must be included explicitly. On the NEW actual gate E^-_g<=A0 q_- c_j^(n/2), g>=root and original accepted z belongs to the root's enlarged set. Positive Tonelli then charges A0 c_j^(n/2) W_beta, summed over bands at sum c_j^(n/2)<4. This pays only that new allocation, and the E^-_g>threshold complement remains even on low pe and high m. It does not prove that all old high-m traffic satisfies the new gate or that a crossing always exists.

Executed Python: 625 legal both-scale enlargements at five n and 25 scale pairs, with five target levels each, passed coordinate enlargement, scale caps, product, and full ratio-band checks. The algebra above supplies the proof.

## Truncated-kernel author audit

PASS for /tmp/r292_truncated_kernel.md SHA256 e6d48782e23371b7131c8ded1d0b241169af0e30f91b1117f6593fc37349b83f. Equations T1--T15 are valid with their stated gates and finite predetermined softness bins. T5 has the correct layercake upper-bound direction and pays the full scale selection A_n. For the finite menu, take k in {1,...,n} with s in [(k-1)/n,k/n]; both mixture coefficients are at most gamma times those at sigma_k=k/(n+1), so K_s<=gamma^n K_sigma_k, and at most M_S=min(n,floor(nS)+1) indices are needed. Theta-power subadditivity, monotonic Z_s(theta), and the positive endpoint comparison establish T6--T9. The derivative lower bound for Z_s has the correct sign on both core and tail.

T10 consumes the actual hard cap before extending receiver space; no FIRST property is asserted for V. T11 is an explicit selector-dependent ORIGINAL gate, with actual m,j,L/g all retained. T12 sums source fees across bins rather than treating disjoint receiver bands as disjoint source budgets. The original outer price is Lambda once. T14's worst ratio factor is correct and may grow exponentially; T15 requires its source-only envelopes as additional proved hypotheses. The analytic one-dimensional moment bound is safe and can certify explicit gates without treating floating quadrature as a rigorous upper bound.

The exact remainder is T13 within the previous original low-pe, far-distance, m>M traffic, including every previous original mask. This theorem pays a constructive wide-source JOINT entropy gate only. No dimension-uniform inverse-M gain or coverage of all old m>M follows. The fixed-s entropy and peak observations concern the kernel relaxation, not original admissible-history counterexamples. No new computational rerun was needed beyond the executed independent diagnostics above and the parent-reported author tests.

## Low-pe geometry author audit

PASS for /tmp/r292_lowpe_geometry.md SHA256 6b0ffd97362b85e5957ad21a85ba18a920d0a4f17103040f17120731821d7dcf. Independently verified the actual clipping inequality, common-soft envelope, full legal scale band, BOTH-scale enlargement and monotonic comparison, q_- tree inclusion, right-continuous finite-tree root, endpoint/singleton/empty-root cases, Tonelli source charge and sum_j c_j^(n/2)<=2+sqrt(2)<4. Every source fee is explicit; this low route uses Lambda once and no score clock. Measurability is supplied by the closed compact scale sets and the explicit common-soft envelope; upper semicontinuity also gives the scale supremum directly.

The cited R114 ratio-column dependency was inspected directly in ratio_column.md (SHA256 0c15c95a25eab1e3eaed705a891197f532d48cb9eb280439dc6e5183f7b42ee0), RC2/RC6: it controls the SAME-receiver scale/common-soft supremum. Dropping the lower ratio endpoint from the closed band in (4) leaves exactly its ratio lower gate, so author (5) has the correct direction and constant. Independently the fixed soft profile envelope is pointwise at most a^-n, giving Gamma<=a^-n A, so finiteness does not need any unproved normalization.

Section 6 correctly moves the profile layercake supremum only as an upper bound, and its product envelopes yield integral_z Gamma<=A² D_sigma(tau), with D_sigma<=Csoft_n<=n+1. The finite formula B_k follows by integrating a clipped exponential against the k-dimensional simplex gamma density; k=0 and sigma=0 conventions are correct. Section 7 correctly gives old product-overlap volume at least (b M_F)^n and V/g^n>=M_F^n, M_F=1+T>1. These are kernel-volume statements, not original-history counterexamples.

Exact residual after this allocation: the SAME original low-pe, m>M traffic with E^-_(j,M)(y,g)>A0 q_- c_j^(n/2), retaining prior far-distance and all original source/tree/history masks. A source need not belong to Y_j, and no root crossing or new-gate coverage is asserted for every old row. Polynomial spatial column volume alone does not control beta-weighted superlevel traffic. Therefore no full low-pe or global closure follows.

## README integration scope check

The draft /tmp/r292_README.md (SHA256 8c06ceaf2dfc8b09d74c4c82b8294b3d96029c42e8baf43746cde3c3a1086a28) has correct source constants, Lambda once, actual selector factor, polynomial-column interpretation, numeric-evidence limitations and explicit global gaps. Two precise-domain clarifications were reported before freezing: attach 0<s<=1/2 to the displayed entropy bounds to match the audited information theorem; state that the geometry column is Gamma_(j,M) for frozen M>=1 and its paid allocation retains BOTH original low pe and m>M as well as the new column threshold. These are integration precision edits, not proof repairs. Final receipt will bind the clarified README hash.

## Final frozen receipt

PASS. The final geometry addition (5a), Gamma<=a^-n[1+n log(b/a)], is independently valid and explicitly supplies root finiteness/regularity; optional original comparison (5) remains valid. The README now states the entropy range 0<s<=1/2 and the fixed-M original low-pe,m>M qualifications of the new geometry allocation. The additional 49 B_k diagnostics are reported as local numerical checks, not substituted for the exact gamma-integral proof. No other mathematical scope changed.

Bound files:
- /tmp/r292_information_profile.md: SHA256 1cae0985165aca0b3162731dcf3e46ba6c1e6194d6b79b5e74cada85459d5163
- /tmp/r292_truncated_kernel.md: SHA256 e6d48782e23371b7131c8ded1d0b241169af0e30f91b1117f6593fc37349b83f
- /tmp/r292_lowpe_geometry.md: SHA256 09f31aa38236032141bb7fcbb6dd880d5c0a87dd094edc4227b79fe9fea908d1
- /tmp/r292_README.md: SHA256 c79d2edf310a483245615dce31078b28814916b08a867fcd3ad61c2c8293e304

The two valid new allocations can be applied sequentially with each actual gate and its complement retained: the explicit joint entropy/mass/ratio gate has source fee (16Lambda/3)A_n sum_h epsilon_h W_beta; the clipped-geometry gate on the remaining original low,m>M traffic has source fee Lambda A0 sum_j c_j^(n/2) W_beta<4Lambda A0 W_beta. Sources may be reused across allocations and their fees must be added. The exact unpaid intersection is the prior original low-pe/far/high-m traffic below its assigned entropy threshold AND above the new clipped-column threshold, with all prior original masks. No theorem showing that intersection is empty or cheaply source-paid is proved. Original other global/prefix/high-score terms remain outside this bounded result.

Audit frozen after bounded final integration; no repository, Git, PDF or upstream author file was edited.

Final editorial hash update: README Section 3 now says “的原交通子分配上”, avoiding any suggestion that time atoms were paid. Formula and scope verdict unchanged; final README SHA256 cc74738763f1889520a322e6ffeefdef046b704d814546a544defe4567a12069. No mathematical re-audit or new test required.
