# R292 — mixed kernel/density clipping and an original wide-source entropy gate

## 1. Result and exact original normalization

The low-pe restriction can be used together with the original kernel, rather than replacing the kernel solely by a constant density. This gives an explicit source-paid JOINT high-m/softness/scale-ratio branch for arbitrary source distances. A bare condition m>M is not given an unproved inverse-m source gain.

I read `/tmp/r289_low_pe.md` and the original kernels/ratio bands/weights in rounds 114 and 116 `research.zip`, `proof.md`. The exact kernels and original weight are

    h=1_[-1/2,1/2], w(u)=integral_0^1 exp(-|u|/t)dt,
    phi=h*w, f_s=(1-s)h+s phi,
    K_s(u)=product_i f_s(u_i), P_(s,L)(x-y)=L^(-n)K_s((x-y)/L),
    gamma=1+1/n, c_j=gamma^(-j), g=sqrt(LR), ell_n=1+log n,
    w_(j,g)(y,v)=product_i min(1,b C(|y_i-v_i|/b)/(c_j g)),
    C(r)=integral_[-1/2,1/2] max(h,phi)(u-r)du.

The original e_g integrates this weight against nu over the FULL original Z_g. Define the actual normalized mass

    m(x,y)=e_g(y)/(ell_n q(x)c_j^(-n/2)g(x)^n)>1.

On the original low gate p e_g<2Kq,

    p<2K c_j^(n/2)/(ell_n g^n m),
    tau_row(x,y)= [2K/(ell_n m(x,y))]
                    c_j^(n/2)(L/g)^n,                 (T1)
    p_low<=L^(-n)min(K_s((x-y)/L),tau_row).

All original accepted-source/history, FIRST, CP/GP, heavy, small-parent, source-distance and other positive masks remain on the left. No Z_g, e_g or posterior is changed. This low slot has original outside factor Lambda ONCE and no auxiliary score/clock fee.

## 2. Exact frozen clipping profile and its finite Chernoff bound

For FIXED s and normalized cap tau>0 define

    eta_(s,n)(tau)=integral_Rn min(K_s(u),tau)du.

Scaling gives exactly

    integral min(P_(s,L)(x),tau L^(-n))dx=eta_(s,n)(tau),

independently of L. Under X_i iid with density f_s, put Y_i=log(1/f_s(X_i))>=0 and t=-log tau. Then

    eta_(s,n)(tau)
       =E exp[-(t-sum_i Y_i)_+].                       (T2)

For every delta in (0,1), or theta=1-delta,

    Z_s(theta)=integral_R f_s(u)^theta du,
    eta_(s,n)(tau)
       <=min(1,tau^delta Z_s(1-delta)^n).              (T3)

This follows directly from min(z,tau)<=tau^delta z^(1-delta). Taking the infimum over delta is a rigorous optimization within this finite Chernoff family; no large-deviation theorem is needed.

For s=0, eta=min(1,tau) exactly. For any fixed s, if tau>=f_s(0)^n, eta=1 exactly: clipping does nothing because this is the kernel peak. In particular f_1(0)=phi(0)<1, so a cap only polynomially small in n can leave the ENTIRE all-soft kernel unchanged. This is a statement about the clipping relaxation, not a FULL-history counterexample.

The relevant typical log-density scale is n h_s, where h_s=E Y_i. If T_out=integral_|u|>1/2 phi(u)du and H_out=integral_|u|>1/2 phi(u)log(1/phi(u))du, then as s decreases to zero,

    h_s=s T_out log(1/s)+s(T_out+H_out)+O(s^2).         (T4)

Indeed the outside density is s phi exactly, and the inside contribution expands to s T_out+O(s^2). Thus ns log(1/s), rather than ns alone, appears at small softness. The log moment log Z_s(1-delta) has derivative h_s at delta=0; all required moments are finite by the exponential tail.

## 3. A fixed profile that handles the ACTUAL softness and scale selections

Fix S in [0,1] and tau>0 BEFORE receiver integration. Set

    U_S(u)=sup_(0<=s<=S)K_s(u),
    V_(S,tau)(u)=min(U_S(u),tau),
    J_S(tau)=integral V_(S,tau).

The original f_s are even and coordinatewise nonincreasing in absolute value, so U_S and V are coordinatewise nonincreasing. Their positive superlevel sets are star shaped and have finite volume. Put A_n=1+n log(b/a). Positive level-set scaling gives

    integral sup_(a<=L<=b)L^(-n)V_(S,tau)(x/L)dx
       <=A_n J_S(tau).                                (T5)

Proof: for each fixed star-shaped level set E_t, its scaling envelope has exact integral A_n|E_t| (one inner aE_t mass, then n dL/L on the shells up to bE_t). Move the supremum through layer cake only as an UPPER BOUND and integrate in t. Equality is not claimed for a general profile V.

Here are finite explicit bounds for J_S. Define

    a_(n,k)(S)=max_(0<=s<=S) s^k(1-s)^(n-k),
    Csoft_n(S)=sum_(k=0)^n binom(n,k)a_(n,k)(S)<=n+1.

The maximizing s is min(S,k/n), with the usual endpoint conventions. The original positive expansion of K_s gives integral U_S<=Csoft_n(S).

Let c_n=gamma^n<=e and M_S=min(n,floor(nS)+1). The established common-soft menu selects sigma_k=k/(n+1), k<=M_S, with

    K_s<=c_n K_sigma_k, sigma_k<=S'=min(1,S+1/n).

For theta in (0,1), subadditivity of the theta power and the product kernel therefore give

    integral U_S^theta<=c_n^theta M_S Z_(S')(theta)^n. (T6)

The moment Z_s(theta) is nondecreasing in s. To check this, let c=phi(1/2)>0. Core values f_s>=1-s+sc and outside values f_s<=sc. Their transferred masses satisfy integral_core(1-phi)=integral_outside phi=T_out. Since theta-1<0,

    dZ_s/ds>=theta T_out[(sc)^(theta-1)
                        -(1-s+sc)^(theta-1)]>=0,

for s>0; continuity supplies s=0. This is an elementary density calculation, not an assumed convex-order theorem.

For S<1 there is also endpoint domination K_s<=(1-S)^(-n)K_S for s<=S, by comparing both nonnegative kernel coefficients. Combining these facts yields

    J_S(tau)<=min{Csoft_n(S), inf_(0<delta<1)
                           tau^delta R_S(delta)},     (T7)

where one valid choice is

    R_S(delta)=c_n^(1-delta) M_S
                       Z_(S')(1-delta)^n.             (T8)

For S<1 this may be replaced by the smaller of (T8) and

    (1-S)^[-n(1-delta)] Z_S(1-delta)^n.                (T9)

For S=0 use the sharper J_0(tau)=min(1,tau). All constants depend only on frozen parameters, not the source point or receiver. The finite menu in (T6) pays the softness selection explicitly, and (T5) pays the entire physical scale selection.

## 4. Actual original source payment and a concrete joint high-m gate

First restrict the ACTUAL original low-pe integrand to

    s(x)<=S, tau_row(x,y)<=tau.

Its density p is bounded by the selected dilation of the fixed V_(S,tau). Integrate the original hard source on the ORIGINAL receiver set, using its true cap BEFORE extending that receiver domain:

    (h_R*nu)(x)/q(x)<=16/3.

Only after this step extend to all receivers and apply (T5). Positive Tonelli gives, at every fixed original source pair,

    T_low,restricted <=(16/3)A_n J_S(tau)W_beta.         (T10)

This includes arbitrary source distances; no tiny-source-near gate is used. No FIRST is assigned to V, a maximal envelope or a cut source. The original beta measure and actual hard cap suffice. Source/history and far-distance masks are retained on the left and dropped only in this majorant. Sum the original terminal and seed ledgers once, then multiply by the original Lambda once.

For an entropy-adaptive source-paid branch, choose a FINITE predetermined partition of softness values into bins I_h subset [0,S_h]. Choose delta_h in (0,1) and epsilon_h>0 before the receiver, and let R_h be a valid (T8)/(T9) value. Add to the actual h-th bin the gate

    m(x,y)>= [2K/ell_n]c_j^(n/2)(L/g)^n
                          (R_h/epsilon_h)^(1/delta_h). (T11)

Then tau_row<=(epsilon_h/R_h)^(1/delta_h), so (T7) gives profile mass <=epsilon_h. The full ORIGINAL outer price of the union of these disjoint softness-bin subbranches is

    P_jointgate <=(16Lambda/3)A_n(sum_h epsilon_h)W_beta.
                                                               (T12)

For a target epsilon W_beta, choose sum_h epsilon_h<=3epsilon/(16Lambda A_n). A finite-grid minimum over candidate delta values can be chosen for each bin in advance without an additional union fee. For example, dyadic upper-softness bins require at most 1+ceil(log_2 n) bins, but every source use is paid through the displayed sum; disjoint receiver bins do not by themselves make source charges disjoint.

This is a genuine global wide-source JOINT m/softness/scale-ratio payment. The threshold is not represented as a simple 1/m multiplier: its one-dimensional moment term carries the actual entropy cost. It can be much larger than a polylogarithmic m floor. Its exact leftover, if applied to the previous m>M residual, is the SAME original low-pe integrand with m>M and, in its assigned bin h,

    m(x,y)<[2K/ell_n]c_j^(n/2)(L/g)^n
                          (R_h/epsilon_h)^(1/delta_h). (T13)

Any prior unpaid masks, including far source distance and the original small-parent gate, remain inside this residual. No claim that it is empty or already paid is made.

## 5. Frozen m versus the actual m(x,y)

For a truly frozen normalized cap tau, the exact formulas (T2)-(T3) are independent of L. The actual original m depends on y, g and the original q; replacing it by a constant is legitimate only through an explicit lower gate or a source-only lower envelope.

The ratio band has c_(j+1)g<=min(L,R)<=c_jg. Consequently, for a fixed lower cutoff m>M,

    tau_row<= [2K gamma^(n/2)/(ell_n M)](b/a)^(n/4).    (T14)

For L>=R use c_j<=gamma g/L, giving c_j^(n/2)(L/g)^n<=gamma^(n/2)(L/R)^(n/4). For L<=R the same factor is <=1. The exact row factor in (T1) is preferable to this worst-case bound, which can already be exponential in n. Even when b=a, the all-soft peak observation in section 2 prevents a uniform inverse-M clipping-mass conclusion at polynomial M.

If source-only measurable bounds S_0(y),M_0(y),A_0(y) are actually proved on a retained branch, with s<=S_0(y), m>=M_0(y)>0 and c_j^(n/2)(L/g)^n<=A_0(y), the same proof instead gives

    T_branch<=(16/3)A_n integral
       J_(S_0(y))(2K A_0(y)/(ell_n M_0(y))) beta(dy).   (T15)

The source weight is integrable whenever the displayed integral is finite; the general bound J_S<=n+1 guarantees finiteness for finite beta. The original definitions alone do not supply an advantageous source-only M_0. In particular d beta/e_g is not declared a probability measure, and the receiver-varying m is never passed through the source integral as a constant.

## 6. Practical one-dimensional formulas and numeric evidence

Let E_3(z)=integral_1^infinity exp(-zt)t^(-3)dt. For u>=0 the exact convolution is

    phi(u)=1-E_3(1/2-u)-E_3(1/2+u), 0<=u<=1/2,
    phi(u)=E_3(u-1/2)-E_3(u+1/2),   u>=1/2.

Thus Z_s(theta), h_s and the variance of log(1/f_s) require only one-dimensional quadrature split at 1/2. A fully analytic, coarser substitute is

    Z_s(theta)<=1+[2^(1-theta)/theta]s^theta,

from f_s<=1 on the core and phi(u)<=(1/2)exp[-(u-1/2)] on each outside tail. This makes (T8)-(T11) explicit without relying on noncertified floating values. Numerical quadratures can inform rate selection; proving a numerical gate constant requires a valid upper bound on Z_s, not merely a floating estimate.

The numerical agent actually ran 13 one-dimensional profiles and 52 cutoffs at 40 and 60 digits in `/tmp/r292_checks.py` and `/tmp/r292_checks.json`; reported maximum precision discrepancy was <=5.16e-41. For n=512,s=1/512 it found n h_s=4.60517353595, although ns=1; for n=1000000,s=1/n it found n h_s=8.35264887391. For s=1, h_1=1.368285852741123158099266; at n=512 and t=ns=512 the finite Chernoff grid only gave the upper bound one, while t=2n h_s gave a much smaller upper bound. These are finite upper-bound diagnostics, not an n-dimensional integral or an interval certificate.

I separately ran 284 finite checks of common-soft positive domination and the scalar clipping/Chernoff inequality, using exact Fractions for the menu checks. They passed. The analytic inequalities above prove the bounded result. This file retains only the kernel-clipping contribution; the numeric and other author files were not modified, and no Git operation was performed.
