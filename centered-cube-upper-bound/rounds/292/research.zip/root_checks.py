from fractions import Fraction as F
import json, random
rng=random.Random(292)
out=[]
for name,N in [('initial',24),('boundary',96),('expanded',384)]:
    count=0;tree=0
    for _ in range(N):
        a=F(1);b=F(2);c=rng.choice([F(1),F(3,4),F(4,5),F(9,10)])
        lo=a/c;hi=b*c
        if lo>hi:continue
        g=lo+(hi-lo)*F(rng.randrange(101),100)
        # L>=R, ratio at least1/c², legal scales.
        L=g/c+(b-g/c)*F(rng.randrange(101),100)
        if L>g*g/a: L=g*g/a
        R=g*g/L
        assert a<=R<=L<=b and L/R>=1/(c*c)
        t=g+(hi-g)*F(rng.randrange(101),100)
        Lp=max(L,t/c);Rp=t*t/Lp
        assert Lp>=L and Rp>=R and a<=Rp<=Lp<=b
        assert Lp/Rp>=1/(c*c) and Lp*Rp==t*t
        # Closed tree thresholds on a fixed nested finite path; fallback0.
        masses=[F(1,16),F(1,4),F(1),F(4),F(16)]
        H=F(rng.randrange(1,401),100)
        qlo=F(3,4);q=qlo+F(rng.randrange(101),400)
        def node(th):return max([i for i,m in enumerate(masses) if m<=th],default=0)
        assert node(qlo*H)<=node(q*H)
        # right continuity at closed mass threshold from above
        idx=rng.randrange(5);threshold=masses[idx]
        assert node(threshold)==node(threshold+F(1,10**12))
        count+=1;tree+=1
    out.append(dict(stage=name,scale_enlargements=count,tree_threshold_checks=tree))
print(json.dumps(dict(status='PASS',scope='Exact Fraction finite scale/threshold algebra. No original FULL/history reconstruction or root-existence certificate.',stages=out),indent=2))
