# R292: exact clipped-kernel information profile (new analytic derivation)
This is a kernel calculation, not a theorem about independence of the original source input or receiver history. It is intended to choose legitimate cutoffs without guessing an exponent.

Let h=1_{[-1/2,1/2]}, w(u)=integral_0^1 exp(-|u|/r)dr, phi=h*w and f_s=(1-s)h+s phi. Both w and phi integrate to one, 0<phi<=1. For s>0 f_s is a positive probability density <=1. At s=0 its support is the unit interval, and all statements use that support.
For independent auxiliary U_i with density f_s, put Z_i=-log f_s(U_i)>=0 and S_n=sum Z_i. This auxiliary product law represents the kernel only. For any t>=0 the EXACT full-space clipped integral is
  C_n(s,t)=integral min(product_i f_s(u_i),exp(-t)) du
          =E exp(-(t-S_n)_+).
For 0<delta<1, min(1,exp(S_n-t))<=exp(delta*(S_n-t)), giving
  C_n(s,t)<=min(1, exp(-delta*t+n*Lambda_s(delta))),
  Lambda_s(delta)=log integral f_s(u)^(1-delta)du.
This is a finite integral bound. No LDP, saddlepoint equivalence or sharp probability asymptotic is claimed. All moments and Lambda on delta<1 are finite from exponential tails of phi. For actual scale L, the same calculation applies to cap L^(-n)exp(-t), after the exact change of variables x=L*u; this alone does not interchange a scale/softness supremum with integration.

## Small-softness entropy and the correct scale for density clipping
Let I=[-1/2,1/2], a(u)=1-phi(u) on I,
  T=integral_(I^c) phi = integral_I a,
  H_out=integral_(I^c) phi log(1/phi),
  A2=integral_I a^2.
All are fixed finite constants, T>0 and 0<=A2<=T.
For 0<s<=1/2 the information mean h_s=E Z_1 obeys
  s*T*log(1/s)+s*(T+H_out)-s^2*A2
  <=h_s<=s*T*log(1/s)+s*(T+H_out).
Proof: outside I, f_s=s phi gives exactly s*T*log(1/s)+s*H_out. Inside, f_s=1-sa. For v in[0,1/2],
  v-v^2 <= -(1-v)log(1-v) <=v.
Indeed its series is v-sum_{k>=2}v^k/[k(k-1)], and the sum lies between0 and v^2/[2(1-v)]<=v^2. Integrate with v=sa.
Thus replacing the information mean by only O(s), uniformly as s downarrow0, would lose a real logarithmic term. This observation does NOT by itself imply that an original heavy-m row behaves like independent samples; it describes the exact auxiliary normalized kernel.

The outside mass constant has an exact one-dimensional representation:
  T=E[min(|W|,1)] for W with density w
   =2 integral_0^1 r^2(1-exp(-1/r))dr
   =2/3-2 E_4(1),
where E_p(x)=integral_1^infinity exp(-xv)v^(-p)dv.
To see the first equality, translate the unit interval by W: the lost overlap fraction is min(|W|,1). Positive Tonelli then gives the second equality by integrating min(u,1)exp(-u/r).
The density itself is explicitly
  phi(u)=1-E_3(1/2+|u|)-E_3(1/2-|u|), |u|<=1/2,
  phi(u)=E_3(|u|-1/2)-E_3(|u|+1/2), |u|>1/2.
These exact formulas support local one-dimensional diagnostics without n-dimensional quadrature.

## Re-entry restriction
The original low gate on m>M gives p<2K*c_j^(n/2)/(ell_n*g^n*M). Relative to L^-n the normalized cap is
  tau=(2K/(ell_n*M))*c_j^(n/2)*(L/g)^n.
If tau>=1, this clip introduces no reduction because the dimensionless kernel is <=1. If tau<1, t=-log(tau). Any original-input estimate must still pay the actual s,L selection, the hard capture response, the ratio-band index and original source ledger. The entropy computation cannot insert a factor1/m into original traffic, cannot replace full e_g by local mass, and does not establish the general root budget.
