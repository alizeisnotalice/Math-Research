#!/usr/bin/env python3
"""R292 common-soft domination, nested profile scale envelope, fixed gate algebra."""
import json,random
from pathlib import Path
from fractions import Fraction as F
import mpmath as mp
R=random.Random(29220261018)
def mm(x):return mp.mpf(x.numerator)/x.denominator if isinstance(x,F) else mp.mpf(str(x))
def grid(ns,samples):
 count=0;band=0
 for n in ns:
  ks=list(range(n)) if not samples else sorted(set([0,n-1,n//2]+[R.randrange(n) for _ in range(samples)]))
  gamma=F(n+1,n)
  for k in ks:
   sigma=F(k+1,n+1)
   for z in [F(0),F(1,7),F(1,2),F(1)]:
    s=(k+z)/n
    assert 1-s<=gamma*(1-sigma) and s<=gamma*sigma;count+=1
  for S in [F(0),F(1,n),F(1,7),F(1,2),F(1)]:
   M=min(n,(n*S).numerator//(n*S).denominator+1);Sp=min(F(1),S+F(1,n))
   assert M>=1
   # Largest possible selected node, also valid if the endpoint belongs to the lower bin.
   kmax=min(n-1,(n*S).numerator//(n*S).denominator)
   assert F(kmax+1,n+1)<=Sp and kmax+1<=M;band+=1
 return {'n_values':ns,'coefficient_cases':count,'soft_band_cases':band,'max_exact_coefficient_violation':'0'}

def segments(a,b,boxes):
 points=sorted(set([F(0)]+[v for width,w in boxes for v in [a*width,b*width]]))
 def candidate(t,width,w):
  if t>b*width:return F(0),0
  if t<a*width:return w/a,0
  return w*width,1
 def value(pair,t):return pair[0]/t if pair[1] else pair[0]
 allpieces=[]
 for lo,hi in zip(points,points[1:]):
  mid=(lo+hi)/2;forms=[candidate(mid,*box) for box in boxes];extra=[]
  for c,p in forms:
   for d,q in forms:
    if p==1 and q==0 and d:
     cross=c/d
     if lo<cross<hi:extra.append(cross)
  sub=sorted(set([lo,hi]+extra))
  for u,v in zip(sub,sub[1:]):
   t=(u+v)/2;fs=[candidate(t,*box) for box in boxes];best=max(fs,key=lambda f:value(f,t));allpieces.append((u,v,*best))
 return allpieces

def scaleprofiles(count,spread):
 cases=[]
 for j in range(count):
  a=F(R.randint(1,20),R.randint(1,20));b=a*F(R.randint(2,8),2)
  l1=F(R.randint(1,20),R.randint(1,20))*F(10)**R.randint(-spread,spread);w1=F(R.randint(1,20),R.randint(1,20))
  if j%2: # Two nested boxes: outer contributes both inside; re-express candidate heights.
   l2=l1*F(R.randint(2,10),2);w2=F(R.randint(1,20),R.randint(1,20));boxes=[(l1,w1+w2),(l2,w2)];mass=w1*l1+w2*l2
  else:boxes=[(l1,w1)];mass=w1*l1
  cases.append((a,b,boxes,mass,j%2))
 maxratio=mp.mpf(0);minratio=mp.mpf(1);pe=mp.mpf(0);eqerr=mp.mpf(0);strict=0
 for a,b,boxes,mass,two in cases:
  pieces=segments(a,b,boxes);vals=[]
  for dp in [40,60]:
   with mp.workdps(dp):
    integral=sum(mm(c)*(mp.log(mm(v)/mm(u)) if power else mm(v-u)) for u,v,c,power in pieces if c)
    bound=(1+mp.log(mm(b/a)))*mm(mass);assert integral<=bound+mp.mpf('1e-30')*max(1,bound)
    ratio=integral/bound;maxratio=max(maxratio,ratio);minratio=min(minratio,ratio)
    if not two:
     e=abs(integral-bound)/max(1,bound);assert e<mp.mpf('1e-30');eqerr=max(eqerr,e)
    elif dp==60 and bound-integral>mp.mpf('1e-25')*max(1,bound):strict+=1
    vals.append(+integral)
  with mp.workdps(90):pe=max(pe,abs(vals[0]-vals[1])/max(1,abs(vals[1])))
 assert pe<mp.mpf('1e-30')
 return {'cases':count,'single_box_cases':sum(not c[-1] for c in cases),'two_nested_box_cases':sum(bool(c[-1]) for c in cases),'strict_two_box_cases':strict,'exact_rational_piece_partition':True,'max_profile_to_A1_mass_ratio':mp.nstr(maxratio,12),'min_profile_to_A1_mass_ratio':mp.nstr(minratio,12),'max_single_box_equality_error':mp.nstr(eqerr,12),'max_normalized_40_vs_60_error':mp.nstr(pe,12),'max_violation':'0'}

def gates(count,ns):
 cases=[]
 for j in range(count):
  n=ns[j%len(ns)];K=F(10)**R.randint(-12,12);c=F(R.randint(1,8),R.randint(1,8));ratio=F(R.randint(1,8),R.randint(1,8));Rh=F(10)**R.randint(-10,10);eps=F(R.randint(1,10),R.randint(11,100));q=R.choice([2,4,8]);mult=F(R.randint(1,20),1)
  cases.append((n,K,c,ratio,Rh,eps,q,mult))
 pe=mp.mpf(0);mappingerr=mp.mpf(0);maxpr=mp.mpf(0)
 for case in cases:
  vals=[]
  for dp in [40,60]:
   with mp.workdps(dp):
    n,K,c,ratio,Rh,eps,q,mult=case;K,c,ratio,Rh,eps,mult=map(mm,[K,c,ratio,Rh,eps,mult]);ell=1+mp.log(n);delta=mp.mpf(1)/q
    logT=mp.log(2*K/ell)+mp.mpf(n)/2*mp.log(c)+n*mp.log(ratio)
    loggate=logT+q*mp.log(Rh/eps);logm=loggate+mp.log(mult)
    logtau=mp.log(2*K/(ell*mp.exp(logm)))+mp.mpf(n)/2*mp.log(c)+n*mp.log(ratio)
    expected=-q*mp.log(Rh/eps)-mp.log(mult)
    err=abs(logtau-expected)/max(1,abs(expected));assert err<mp.mpf('1e-28');mappingerr=max(mappingerr,err)
    profile_ratio=mp.exp(mp.log(Rh)+delta*logtau-mp.log(eps));assert profile_ratio<=1+mp.mpf('1e-28');maxpr=max(maxpr,profile_ratio)
    vals.append(+logtau)
  with mp.workdps(90):pe=max(pe,abs(vals[0]-vals[1])/max(1,abs(vals[1])))
 assert pe<mp.mpf('1e-28')
 return {'cases':count,'precision_runs':2*count,'K_decimal_exponent_range':[-12,12],'n_values':ns,'max_normalized_ratio_mapping_error':mp.nstr(mappingerr,12),'max_normalized_40_vs_60_error':mp.nstr(pe,12),'max_R_tau_delta_over_epsilon':mp.nstr(maxpr,12),'max_violation':'0','Rh_scope':'Arbitrary positive frozen input; validity as a Renyi/profile bound is assumed for this algebra diagnostic, not independently certified.'}

def budget(count,ns):
 maxratio=mp.mpf(0)
 for j in range(count):
  n=ns[j%len(ns)];Lambda=F(128,119);target=F(R.randint(1,100),R.randint(1,100));btoa=F(R.randint(2,4),2)
  Aupper=1+n*(btoa-1);weights=[F(R.randint(1,20),R.randint(1,20)) for _ in range(1+j%8)];total=sum(weights);weights=[w/(total+1) for w in weights]
  eps=[3*target*w/(16*Lambda*Aupper) for w in weights]
  exactprice=F(16,3)*Lambda*Aupper*sum(eps);assert exactprice==target*sum(weights)<=target
  with mp.workdps(60):
   An=1+n*mp.log(mm(btoa));assert An<=mm(Aupper)+mp.mpf('1e-40')
   actualprice=mp.mpf(16)/3*mm(Lambda)*An*sum(mm(e) for e in eps);assert actualprice<=mm(target);maxratio=max(maxratio,actualprice/mm(target))
 return {'cases':count,'exact_fraction_allocations':True,'Lambda':'128/119','conservative_An_majorant':'1+n*(b/a-1)','max_price_to_target_ratio':mp.nstr(maxratio,12),'max_source_epsilon_budget_violation':'0'}
settings=[('initial',list(range(1,17)),0,12,2,[1,2,16]),('boundary_stress',[63,64,65,511,512,513,1023,1024,1025],12,24,8,[1,512,1024]),('expanded',[10000,100000,1000000],32,36,20,[1,10000,1000000])]
stages=[]
for name,ns,samples,count,spread,gns in settings:
 stages.append({'name':name,'common_soft_grid':grid(ns,samples),'nested_scale_profiles':scaleprofiles(count,spread),'actual_ratio_gate':gates(count,gns),'source_epsilon_budget':budget(count,gns)})
out={'status':'PASS','seed':29220261018,'scope':'Exact Fraction common-soft coefficients, rational breakpoint scale-envelope profiles with40/60 logarithms, frozen-threshold scalar mapping and finite epsilon source-budget allocation. No fresh moment integrals, original source simulation, score/clock factor, or FULL/history certificate. Existing frozen numerical files untouched.','scale_profile':'Integral sup_{a<=L<=b} L^-1 F(x/L)<= (1+log(b/a))*integral F, tested for one interval or two nested centered interval mixture.','actual_tau':'(2K/((1+log n)*m_actual))*c_j^(n/2)*(L/g)^n','stages':stages}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,sort_keys=True,indent=2)+'\n');print(json.dumps(out,sort_keys=True,indent=2))
