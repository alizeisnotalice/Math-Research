# R292: a mixed kernel-height/overlap root for original low-pe traffic

## 1. Precise proved payment and its scope

Retain the ORIGINAL positive traffic

    dT=q(x)^(-1) P_(s(x),L(x))(x-y) h_(R(x))(x-z)
                          a_omega(x,y,z) dx beta_V(dy)nu_V(dz),

with 0<=a_omega<=1, true receiver dx, all original FULL/FIRST, accepted-hard, cut/rank, small-parent and history gates, and the unique ratio band j(x). Write g=sqrt(LR), ell=1+log n, q_-=3lambda/4, q(x) in [q_-,lambda], and

    c_j=(1+1/n)^(-j),
    e_g(y)=integral_(Z_(j,V)(y,g)) w_(j,g)(y,z)nu_V(dz),
    m=e_g/[ell q(x)c_j^(-n/2)g^n]>1.

The original e_g, Z_g and w_g in this definition are NEVER replaced by local or pair-parent masses. Fix M>=1 and a coefficient A0>0 before receiver selection. The theorem below constructs an explicit frozen clipped-column mass E^-_(j,M)(y,t). Its corresponding actual gate has the source payment

    T_{low,m>M, E^-_(j,M)(y,g)<=A0 q_- c_j^(n/2)}
       <=A0 sum_j c_j^(n/2) W_beta <4A0 W_beta.             (P1)

Here low means the ORIGINAL p_y e_g<2Kq(x). A wide-distance indicator, or any other original positive mask, may remain on the left. Thus (P1) is a new general allocation on the wide, high-m low branch, not a fixed displacement class. Choosing A0 of root-polylog size gives that source price. The original outer fee is Lambda once. No assertion is made that the new gate covers all old high-m traffic.

The improvement is that E^- retains the ACTUAL common-soft, same-receiver clipped kernel column. Its unnormalized spatial volume is at most polynomial in n; it does not use the exponential-volume coordinatewise-max overlap weight defining the old e_g. The larger frozen source set in E^- is only a positive majorant for this new allocation, not a replacement in the original low gate.

## 2. The low-pe height inequality and an explicit common-soft envelope

Let h(u)=1_[−1/2,1/2](u), phi=h*w, w(u)=integral_0^1 exp(−|u|/r)dr, and p_s=(1−s)h+s phi. These are the original R114 kernels. For a frozen sigma in [0,1] covering the actual softness (sigma=1 always works), define

    H_sigma(v)=sup_(0<=s<=sigma) product_(i=1)^n p_s(v_i).

This uses ONE common s. It satisfies 0<=H_sigma<=1 and is nonincreasing along every ray from zero. It is measurable and integrable. A completely explicit positive majorant is obtained by setting

    Q_k=binom(n,k)^(-1) sum_(|S|=k)
                 product_(i in S)phi(v_i) product_(i notin S)h(v_i),
    a_(n,k)=max_(0<=s<=1) binom(n,k)s^k(1−s)^(n−k),
    Csoft_n=sum_(k=0)^n a_(n,k)<=n+1.

Then H_sigma<=sum_k a_(n,k)Q_k and integral H_sigma<=Csoft_n. The endpoint a_(n,0)=a_(n,n)=1; other coefficients equal binom(n,k)(k/n)^k(1−k/n)^(n−k). No asymptotic coefficient estimate is needed here.

On original low pe with m>M,

    p_y L^n < (2K/(ell M)) c_j^(n/2) (L/g)^n
            <=tau_(j,M),
    tau_(j,M)=(2K/(ell M))c_j^(n/2)c_(j+1)^(-n).           (2)

The second bound uses the original band lower bound min(L,R)>=c_(j+1)g, so L/g<=c_(j+1)^(-1). Define the explicitly clipped common-soft function

    G_(j,M)(v)=min{H_sigma(v),tau_(j,M)}.                   (3)

For the actual low,m>M row, the true unnormalized soft product is <=G_(j,M). This is the joint use of the actual kernel and the inverse-m density cap; clipping each coordinate separately would be a different and invalid operation.

The envelope H_sigma is computable by scalar optimization. If all coordinates lie in the hard core, its maximum is 1. If k coordinates are outside, for s>0 the logarithmic derivative of the product is

    k/s − sum_(inside i) (1−phi(v_i))/(1−s+s phi(v_i)),

which is decreasing. Its zero, or the endpoint sigma, determines the maximum. At s=0 an off-core product is zero. This does not introduce independent coordinate softness choices.

## 3. Exact column, legal scale window and regularity

Put

    t_j^-=a/c_j,  t_j^+=b c_j.

If t_j^->t_j^+ the band has no admissible scales and contributes zero. Otherwise for t in [t_j^-,t_j^+] define

    Gamma_(j,M)(t;y,z)
      =integral_(R^n) sup_{a<=L,R<=b, sqrt(LR)>=t,
                     c_(j+1)<=min(L,R)/sqrt(LR)<=c_j}
         (LR)^(-n) G_(j,M)((x-y)/L) 1_{Q_R(z)}(x) dx.       (4)

The closed band is a harmless majorant of the original unique half-open band; the actual j(x) indicator remains in traffic and is not duplicated. The last original band may have a narrower upper ratio endpoint, which is only relaxed positively in (4). Empty parameter sets have supremum zero. All common softness and the two physical scales occur in the SAME receiver integral. Thus (4) is not a fixed-parameter integral with actual selectors substituted afterwards.

By (2)-(3), Gamma majorizes the actual low,m>M product kernel for any actual g>=t. Also G<=H_sigma, so R114's original ratio-column theorem gives

    Gamma_(j,M)(t;y,z)
      <=C_n c_j^n t^(-n) w_(j,t)(y,z),
    C_n=4+pi sqrt(n).                                     (5)

The comparison (5) is the optional original R114 RC6/S6 comparison. Independently, G<=1 gives the simpler bound

    Gamma_(j,M)(t;y,z)<=a^(-n)[1+n log(b/a)].                (5a)

Indeed L^(-n)G<=a^(-n), while the hard scale envelope has integral 1+n log(b/a). This independent uniform finite bound is all that the root regularity argument below needs. Gamma decreases with t.

There is also the useful comparison, for t<t' in the same legal window,

    Gamma(t')<=Gamma(t)<=(t'/t)^(2n)Gamma(t').              (6)

To prove it, consider any allowed scales with g in [t,t'). If L>=R, enlarge them to

    L'=max{L,t'/c_j},  R'=t'^2/L'.

If L'=L, then R'>=R. Otherwise R'=t'c_j>=R, since R<=c_j g. In both cases L'>=L, R'>=R, L'<=b (because t'<=b c_j), and both remain >=a. The ratio min(L',R')/t' stays between its old value and c_j, hence remains in [c_(j+1),c_j]. Swap the two roles when R>=L. The unnormalized G and the hard indicator can only increase, while the normalization changes by (g/t')^(2n). Scales already satisfying g>=t' require no change. Taking the supremum and integrating proves (6). This also proves continuity of Gamma in t, including one-sided endpoint continuity, without interchanging an integral and a selector supremum.

Measurability follows from the explicit common-soft scalar envelope and compact scale menus. Equivalently the nonnegative scale supremum can be recovered using a countable approximation from enlarging legal scales; hard boundary values are preserved by that enlargement. No measure-zero assertion about an arbitrary selector graph is needed.

## 4. Freezing the forbidden source set safely when q varies

The original finite tree and its hard mass h are frozen outer data. Define an AUXILIARY threshold using q_-, not q(x):

    H^-_j(t)=q_- max{t^n,sqrt(n)c_(j+1)^n t^n,
                                  sqrt(n)(t^2/b)^n}.

Let A^-_(j,t)(y) be the coarsest original path node with h(A)<=H^-_j(t), with the same finest-cell fallback when none exists. Put

    Z^-_(j,t)(y)=T_0(y) minus A^-_(j,t)(y).                 (7)

The original distance restriction D_V(y) has been dropped positively in this auxiliary set. Since q(x)>=q_-, the original light threshold is at least H^-_j. The coarsest original light block is therefore at least as large as A^-; fallback cases preserve the same inclusion. Consequently

    Z_original(y,g) subset Z^-_(j,g)(y).                   (8)

This is exactly the direction required for a positive majorant. Both the auxiliary set (7) and the new root below are independent of receiver q(x). The actual e_g, m and low-pe condition continue to use the original q(x), original Z_g, and original weight w_g.

The sets Z^-_t decrease in t and, on the finite original path, are right-continuous with finitely many true deletions. Define the new frozen mass

    E^-_(j,M)(y,t)
      =integral_(Z^-_(j,t)(y)) Gamma_(j,M)(t;y,z)nu_V(dz). (9)

It is finite, nonincreasing, right-continuous, and jointly measurable in frozen data and y,t. These properties follow from (6), the finite tree convention, and the independent domination (5a). No point of Z^- has been granted an original hard capture gate; its kernel contribution is bounded through the explicit column (4).

## 5. Root construction and the actual source payment

Let theta_j=A0 q_- c_j^(n/2). On the nonempty legal window put

    Y_j={y:E^-_(j,M)(y,t_j^+)<=theta_j},
    rho_j(y)=inf{t in [t_j^-,t_j^+]:E^-_(j,M)(y,t)<=theta_j}
                    for y in Y_j.

Right continuity gives E^-(y,rho_j)<=theta_j and the exact feasible interval [rho_j,t_j^+]. The case rho_j=t_j^+ is retained; if the legal window is a singleton, it is a valid single-scale root exactly when its mass is <=theta_j. If Y_j fails, this new branch contains no receiver for that source. Measurability follows by rational scale tests together with the actual upper endpoint. If the mass is zero, no division by it occurs anywhere.

At an actual row in the new gate of (P1), y belongs to Y_j and g>=rho_j(y). The actual hard source is in Z_original(y,g), hence by (8) and monotonicity in Z^-_(j,rho_j)(y). Keep the original low,m>M gate until applying (2), then use q(x)^(-1)<=q_-^(-1), (4), and nonnegative Tonelli. The j contribution is bounded by

    q_-^(-1) integral_(Y_j) beta_V(dy)
       integral_(Z^-_(j,rho_j)(y)) Gamma_(j,M)(rho_j;y,z)nu_V(dz)
      <=A0 c_j^(n/2) beta_V(Y_j).                          (10)

Sum original terminal leaves and seed expectations once. Different j may reuse beta mass, and their coefficients are explicitly summed:

    sum_j c_j^(n/2)<=2+sqrt(2)<4.

This proves (P1). It uses neither a local replacement for e_g nor a posterior supported on a packet. FIRST and the hard cap remain original qualifications; this particular source-column proof does not need to consume them again. The low raw outer price is Lambda times (10), not the high branch's 2Lambda or a continuous score/clock multiplier.

## 6. Polynomial column volume and explicit clipped-mass control

Let D_sigma(tau)=integral min(H_sigma(v),tau)dv and A=1+n log(b/a). The common-soft coefficient bound gives D_sigma(tau)<=Csoft_n<=n+1. The stronger clipped value is retained rather than automatically replacing it by this bound.

For any nonnegative integrable ray-decreasing G, its scale envelope is positively dominated by

    G_b+n integral_a^b G_L dL/L,

whose integral is A integral G. This follows by applying the exact scale-envelope identity to each star-shaped superlevel set of G and then positive layer cake. Apply it to G=min(H_sigma,tau) and to the hard cube. Their fixed product-envelope column dominates Gamma, giving

    integral_(R^n) Gamma_(j,M)(t;0,z)dz
       <=A^2 D_sigma(tau_(j,M))
       <=(n+1)[1+n log(b/a)]^2.                            (11)

All scale and common-soft selector fees in this polynomial upper bound are explicit. It is NOT a source-density theorem: beta may concentrate on large values of (9), so (11) alone does not prove Y_j contains all original sources.

There is an elementary explicit finite upper bound for the clipped mass. Since phi(v)<=exp(−(|v|−1/2)) outside the hard core, a point with exactly k outside coordinates has

    H_sigma(v)<=sigma^k exp(−sum_outside(|v_i|−1/2)).

For Abar>=0 define

    B_k(Abar,tau)=Abar                         if tau>=Abar,
    B_k(Abar,tau)=tau sum_(r=0)^k [log(Abar/tau)]^r/r!
                                                   if 0<tau<Abar.

Then

    D_sigma(tau)
      <=min{Csoft_n, sum_(k=0)^n binom(n,k)2^k
                                      B_k(sigma^k,tau)}.   (12)

For k>=1, B_k is exactly the integral of min(Abar exp(−u),tau) against u^(k−1)/(k−1)! on [0,infinity); for k=0 it is min(Abar,tau). This proves (12) by the decomposition according to outside coordinates. It includes sigma=0, when D_0(tau)=min(1,tau), and sigma=1. It does not assert dimension-free decay in M; the displayed n, sigma and tau dependence must be retained.

## 7. Why the old weighted mass is not already a small-capacity packet

The original R114 weight uses

    F=max(h,phi), C(d)=integral_(-1/2)^(1/2)F(v-d)dv,
    w_(j,g)(y,z)=product_i min{1,C(|y_i-z_i|/b)/alpha},
    alpha=c_j g/b<=1.

Its full translation volume is

    V_(j,g)=[b integral_R min{1,C(|u|)/alpha}du]^n.

Because 0<C<=1, alpha<=1, and integral C=integral F,

    V_(j,g)>=(b M_F)^n,
    M_F=integral F=1+integral_(outside hard core)phi>1.       (13)

The exact constant is

    M_F=1+2 integral_0^1 r^2(1−exp(−1/r))dr.

Thus V_(j,g)/g^n>=M_F^n. Normalizing e_g by g^n is not the same as normalizing by this product overlap's effective volume. The legitimate averaged density scale is e_g/V_(j,g), with the ratio in (13) retained. The old forbidden source set can reduce e_g, but its definition does not reduce the full kernel volume in (13). This is a kernel normalization statement, not a constructed FULL counterexample.

By contrast, (11) retains common softness and has polynomial column volume. The new payment (P1) therefore tests the actual clipped common-soft overlap rather than presuming that original high m itself certifies a concentrated nu packet. No comparison making the new gate automatic has been proved.

## 8. Actual computation and exact remaining bridge

The ordinary and bundled Python environments lacked mpmath. MATLAB was actually used for the one-dimensional normalization integral and an independent exponential-integral form. It returned

    integral_outside phi =0.4945416840175452,
    M_F=1.494541684017545,
    log M_F=0.4018195939671741,
    residual versus 2/3−2 integral_1^infinity exp(−u)u^(−4)du =0

at the displayed double precision. These are numerical diagnostics; formulas (11)-(13) are analytic statements. No numerical model of the original FULL history was claimed.

After this payment, the exact additional remainder is the original low,m>M traffic with

    E^-_(j,M)(y,g)>A0 q_- c_j^(n/2).

The still-needed source-capacity estimate must bound that SAME original traffic, exploiting this large clipped overlap together with the original caps/geometry, or prove an original source-conserving grouping that makes its source price root-polylog. The polynomial spatial integral (11), alone, does not control beta-weighted mass on its superlevel set. The root gate is a proved new allocation and a sharper geometric interface; it is not global low-pe closure.
