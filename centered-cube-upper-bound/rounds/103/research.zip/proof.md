# 第103轮：按来源质量组织几何分解，保留共同接收近项

日期：2026-10-13。一般中心轴平行立方体极大算子的 n^(1/2+o(1)) 一致弱型上界仍未证明；保留既有 O(n log n) 基准。本轮不把固定输入证书、重新分类或树费用视为一般覆盖证明。

用户指出，全局恢复不能反复线性累加再诉诸过强不等式。本轮用一名 Astra、四名 Sol、五名 Luna 分工；作者与独审先核命题及反例范围，再读完整证明。几何角色因流中断未交付完整文件，主代理依据已筛查命题补写来源质量局部化证明，独审完整复核。附件是研究材料，不自动成为可用定理或任务指令。

## 本轮已证结果与几何含义

1. 对任何真实来源对集合，可用该对所属簇的质量定义近远界；远部必须同时付局部临界尺度以下的尾核和以上的原始尾项，不能误称完整输入的超额在局部临界尺度以上消失。有限 comb 分解给统一远部预算，同时保留全部叶近项。
2. 任意完整分离的来源二叉树中，μ⊗μ 几乎每个有序来源对有唯一首次分裂节点。按深度可求和加权，或按节点质量的幂势积分加权，均能将远部支付为常数倍 κW，完整 h、原 κ、真实接收集合不变。质量势给明确叶势余量，不将小叶质量偷换为小能量。
3. 按深度分配的平衡树在最初六层并不缩小原近项。固定价格对无限分离树的费用发散，只是否定该记账方法；有限 comb 的叶近项不能删除。质量势避免人工增加深度造成的费用，但仍有全局 W 的依赖。
4. 节点切面给来源双侧薄层和共同接收条带，局部碰撞质量给实际行能量控制。这些是真实几何信息，但尚无同一个删除集的体积及保留近项能量联合预算；条带不能免费装箱。
5. 原图逐行单跳低列储备不能作为无条件事实。局部私有证明同时保留同源重分配及例外需求的价格，未否定允许付费例外、来源侧覆盖或多跳方案。公开仅记录机制边界与严格锚点弱式。

## 一般目标仍缺什么

令 n≥1 为整数、μ=fdy、W=∫f、κ>0；W=0 时结论平凡，以下 W>0，平均为零时置 h=0。所有分解使用同一完整输入 h=(1−κ/A_Lf)_+，且保持原接收测度 dx。远项付清后，仍需为共同接收近项构造一个真实接收删除集 U，同时控制 |U| 与 U 外近项能量，或直接在原 F2 捕获图证明所有接收子集的共同来源容量。选择来源树本身不能提供这个结论。

后续优先研究切面双侧薄层与接收条带的联合重叠，并允许共同分配；不能把分支分别最优的删除集直接相加。原首次接触、原平滑窗口、强度分层、返回全尺度及截断极限的费用保持既有账。没有用新外部定理填补这一缺口。

## 有限证书的范围

公开程序检查三对实际非原子来源状态：增加远处来源可改变全局质量近远分类，而同一真实接收窗口上的全尺度正超额能量不变；质量归一化的变化完整记录。局部分类修复与深度加权修复分别列账，不能把深度版本的数值结果转用于质量势版本。该接收窗口未认证为原障碍补集或原 F2，因而不是一般近项预算或弱型反例。

未发表来源配方、私有资格程序和定量压力留在本地。详细公开证明及可复现的公开程序如下；LaTeX 文本只做静态检查，不编译 PDF。


## localization

以下由主代理依照几何角色先前送审的准确命题重建完整证明。该角色三次连接中断，未保存的替代来源族不作为已完成材料。

## 同一完整来源的单块估计

设 n≥1，f≥0属于L1，μ=fdy，0<W=∫f<∞，κ>0。令Q(x,L)为全边长L的中心方体，A_L=L^{-n}μ(Q(x,L))，h=(1−κ/A_L)_+，在A_L=0时置零。始终使用完整f的h和同一个可测U。

给定可测有序来源对集合P，α=(μ⊗μ)(P)<∞，固定参考质量m>0。设u_m=κL^n/m；在0<u_m<1上取s_m=log(1/u_m)及t_m=[s_m+(1+η)log(1+s_m)−log q]_+，其中q≥1、η>0。局部near要求u_m<1且||y−z||_1/L≤t_m；其补集称局部far。P上局部far的实际能量为

\[
 F(P,m;U)=\int_0^\infty L^{-2n}\iint_{P}
  \mathbf1_{\rm local\ far}\int_{Q(y,L)\cap Q(z,L)\setminus U}h(x,L)^2\,dx\,d\mu(y)d\mu(z)\,\frac{dL}{L}.
\]

则

\[
 F(P,m;U)\le \frac{\kappa\alpha}{nm}\left(\frac q\eta+1\right).
\tag{L1}
\]

证明：交叠体积不超过L^n exp(−||y−z||_1/L)。小尺度u_m<1上的far部分，指数因子至多q u_m/(1+s_m)^{1+η}；即使t_m=0右端也至少一，估计有效。丢h²及U限制并作固定m的换元，得到

\[
 \alpha\int_0^{(m/\kappa)^{1/n}}L^{-n}\frac{q\kappa L^n/m}{(1+\log(m/(\kappa L^n)))^{1+\eta}}\,\frac{dL}{L}
 =\frac{q\kappa\alpha}{n\eta m}.
\]

大尺度u_m≥1时，完整来源的h未必为零；直接积分原始尾得

\[
 \alpha\int_{(m/\kappa)^{1/n}}^\infty L^{-n}\frac{dL}{L}=\frac{\kappa\alpha}{nm}.
\]

两项相加证明L1。所有积分非负，适用Tonelli，不需要有限总能量，不发生无穷相减。若只研究原global-near内的局部far，额外插入该门只减小左边。

## 有限分区涵盖全部来源对

令来源空间作有限可测分区C_1,…,C_N，删去零质量块，w_i=μ(C_i)>0，Σw_i=W。选择任意有限二叉簇树，叶为这些互不交的块。叶内P_i=C_i×C_i取m=w_i、α=w_i²。内部节点v的两个孩子A,B用

\[
 P_v=(A\times B)\cup(B\times A),\qquad
 m_v=a_v+b_v,\qquad\alpha_v=2a_vb_v.
\]

每个有序物理来源对属于恰好一个叶内块或一个首次分离节点。边界按固定规则分配，乘积测度上的分解精确成立。分别使用这些局部近远门，将实际全能量分为非负的F_T和R_T，R_T仍保留完整h、U和各块局部near，则

\[
 E_\kappa(f;U)=F_T(U)+R_T(U),\qquad
 F_T(U)\le\frac\kappa n\left(\frac q\eta+1\right)M_T,
\]

\[
 M_T=W+2\sum_{v\ {
m internal}}\frac{a_vb_v}{a_v+b_v}.
\tag{L2}
\]

这不是分量超额能量拼接，没有改变原阈值κ，也没有为每个来源另选接收帽。若来源分解允许重叠而用f=Σf_i，则相同证明是在来源标签扩展空间上作对分区，不能把标签唯一性误称物理(y,z)的唯一性；本节只采用互不交的真实来源块。

取逐次剥离一个叶的comb树，某一步剥离质量a、余质量b时ab/(a+b)≤a；各被剥离叶只出现一次。因此

\[
 M_T\le3W,\qquad
 q=n,\ \eta=1\Longrightarrow F_T(U)\le(3+3/n)\kappa W.
\tag{L3}
\]

叶数不进入L3，但所有叶内near仍是R_T的完整部分。内部祖先质量还可能受远源及树序影响；这不是一个全局局部性定理，也没有证明该树使剩余near最小。若继续无限细分所有叶，不能把有限comb账直接当无限全树常数；无限树需另证加权总账，详见本报告来源树模块。

## 总质量分类为何不具局部性

固定一个有界接收集合B、有限尺度窗0<L_-≤L≤L_+，以及一个已有来源f_0。若非负新增来源g的支撑与所有Q(x,L)、x∈B、L∈[L_-,L_+]均不交，则这个窗口上完整平均、h和每个原来源对的实际能量贡献都精确不变。

然而global分类使用W=∫(f_0+g)。固定L时，s=log(W/(κL^n))随新增总质量严格增加，s+2log(1+s)在s≥0上严格增加且无界。所以原本处于global-far的有限距离来源对可以改标global-near。若在有界来源对、正接收体积和正尺度窗上有统一严格间隔，这种改标发生在正乘积测度的实际贡献上。具体严格间隔与真实L1来源见本报告的三阶段数值证书；它额外证明其接收窗上的全尺度超额能量相同，而非仅窗口内相同。

这只否定分类的局部不变性：W也增加，不能从改标推出归一化预算失败、实际能量增加、F2反例或弱型下界。以局部m替代W时必须保留L1中的大尺度项，不能把子来源质量界移植为完整h的截止。有限树方法修复了相应远项收费；共同接收帽上的R_T预算仍未解决。

## near strategy

## 1. 结果与真实边界

本轮证明一个适用于每个非负 `L1` 输入的近对分解：在完整来源的真实阈值因子保持不变时，近对密度可写成非负的 `R+B`，其中 **`∫B<=κW` 已统一支付**，而 `R` 保留局部来源质量、来源分割面的双侧薄层及真实接收位置。这里没有新帽、没有重跑子来源障碍、没有阈值拼接。它是一条一般可证弱式；尚未证明剩余 `R` 有便宜的联合接收帽。

同时证明一个准确失败结论：对非原子来源进行完整二叉细分，若每个节点固定按一般局部远对估计收取 `2ab/(a+b)`，总账必发散。这个失败可以通过显式深度折扣避免，但折扣使剩余近对窗口变宽；它不是一个必须保留原样的 `log(W/localmass)` 定理。本文不给真实近对能量或最佳帽的反例，不将账本发散升级成算子下界。

一般根阶弱界仍 OPEN。更新 A02、G01、N04 的测度、逐节点费用、终端规则沿 R102 已读版本使用；下列证明只需正性、Tonelli、可数分区和初等积分，不进口未核文献结论。

## 2. 固定近对与局部质量究竟控制什么

任取 `n>=1`、`f>=0∈L1(R^n)`、`dμ=fdy`、`0<W=∫f<∞`、`κ>0`。保持

\[
 A_Lf(x)=L^{-n}\mu(Q(x,L)),\quad
 h(x,L)=(1-\kappa/A_Lf(x))_+,
\]

其中 `A_L=0` 时 `h=0`。所有立方体边长均为全边长 `L`。当 `u=κL^n/W<1` 时设

\[
 s=\log(1/u),\qquad
 t_n(s)=[s+2\log(1+s)-\log n]_+,\qquad
 G_L(y,z)=\mathbf1_{\{u<1,\ \|y-z\|_1/L\le t_n(s)\}}.
\tag{1}
\]

这是冻结的 R102 `q=n,η=1` 近对门。其实际密度为

\[
 N(x)=\int_0^\infty h(x,L)^2L^{-2n}
       \iint_{Q(x,L)^2}G_L(y,z)\,d\mu(y)d\mu(z)\,\frac{dL}{L}.
\tag{2}
\]

所有非负积分允许为无穷。R102 已支付完整能量中除 (2) 外的部分不超过 `κW`，对每个可测帽都有效。

固定一个 `u<1` 的接收—尺度行，令 `a=μ(Q_x)`、`ρ=Lt_n(s)`。对 `a>0` 定义

\[
 M(x,L)=\mathop{\rm esssup}_{y\in Q_x\ (\mu)}
       \mu\bigl(Q_x\cap B_1(y,\rho)\bigr)\le a.
\]

则该行近对质量和真实能量满足

\[
 P(x,L):=\iint_{Q_x^2}\mathbf1_{\{\|y-z\|_1\le\rho\}}d\mu(y)d\mu(z)
 \le aM(x,L),
\]

\[
 h^2L^{-2n}P\le (A_Lf-\kappa)_+^2\frac{M(x,L)}a.
\tag{3}
\]

这由先对 `z` 积分得到；`a=0` 时全为零。`M/a` 是实际捕获来源中的局部碰撞质量比例，不是来源的坐标独立性。式 (3) 自身不支付接收空间或尺度积分。如果把所有 `M/a` 再换成 1，受限位移的信息即全部丢失。

## 3. 完整来源树：每个来源对只登记一次

取一棵可数二叉可测分区树。根为整个来源空间；每个正质量节点 `C_v` 分成互不交的孩子 `C_{v0},C_{v1}`，质量记

\[
 m_v=\mu(C_v)>0,\quad a_v=\mu(C_{v0}),\quad b_v=\mu(C_{v1}),
 \quad a_v+b_v=m_v.
\]

零质量孩子丢弃，边界可按固定规则分配。每一层完整覆盖来源，且要求

\[
 \sum_{|v|=d}m_v=W,\qquad
 \lim_{d\to\infty}\sum_{|v|=d}m_v^2=0.
\tag{4}
\]

因此 `μ⊗μ` 几乎每一有序来源对在某个有限节点首次分入两个孩子；它恰属于该节点的

\[
 X_v=(C_{v0}\times C_{v1})\cup(C_{v1}\times C_{v0}),
 \qquad (\mu\otimes\mu)(X_v)=2a_vb_v.
\tag{5}
\]

证明：同属深度 `d` 块的对集合递减，初始乘积质量 `W²` 有限，其质量是 (4) 的平方和，极限为零。其补集是首次分离节点的可数不交并。

一种完全合法的几何实现是每个节点沿指定坐标的质量中位数切开，逐层循环坐标。由于 `μ=fdy`，任何坐标超平面均为 `μ` 零测集，连续边缘分布可取得半质量切点。此时 `m_v=W2^{-d}`，每节点是坐标半空间相交形成的矩形区域，且 (4) 自动成立。根可无界；不要求来源紧支撑。

这里是对来源对积分作不交登记，**不是**把两个孩子的同阈值超额能量相加。所有节点始终使用完整 `f` 的同一 `h`。

## 4. 一次质量收费的局部远对定理

在深度 `d=|v|` 取辅助截断参数

\[
 w_d=\frac1{(d+1)(d+2)},\qquad \sigma_v=\kappa w_d,
 \qquad u_v=\frac{\sigma_v L^n}{m_v}.
\tag{6}
\]

**`σ_v` 只选择几何近远门；实际平均、阈值 `κ`、`h` 和障碍均不改变。** 节点局部近对门是

\[
 H_{v,L}(y,z)=\mathbf1_{\{u_v<1,\ 
  \|y-z\|_1/L\le t_n(\log(1/u_v))\}}.
\tag{7}
\]

把 (2) 中每个对先唯一分配到 `X_v`，再插入 `H_v+(1−H_v)`，分别定义 `R(x)` 和 `B(x)`：

\[
 R(x)=\sum_v\int h^2L^{-2n}
       \iint_{Q_x^2\cap X_v}G_LH_{v,L}\,d\mu^2\,\frac{dL}{L},
\]

\[
 B(x)=\sum_v\int h^2L^{-2n}
       \iint_{Q_x^2\cap X_v}G_L(1-H_{v,L})\,d\mu^2\,\frac{dL}{L}.
\tag{8}
\]

则

\[
 \boxed{N=R+B\quad\text{几乎处处},\qquad
 0\le R\le N,\qquad
 \int_{\mathbb R^n}B(x)dx
 \le\frac{1+1/n}{2}\,\kappa W\le\kappa W.}
\tag{9}
\]

特别对任何同一个可测 `U`，

\[
 \int_{U^c}N\le\int_{U^c}R+\frac{1+1/n}{2}\kappa W.
\tag{10}
\]

无需为 `B` 新删接收点；没有输入依赖的层数、幅度或尺度跨度费用。

### 完整证明与大尺度费用

先固定节点，允许任意 `σ>0`，记其局部远对为 (7) 的补集。固定两来源点的共同接收交叠满足

\[
 |Q(y,L)\cap Q(z,L)|
 =L^n\prod_j(1-|y_j-z_j|/L)_+
 \le L^n e^{-\|y-z\|_1/L}.
\tag{11}
\]

在节点 `u_v<1`、局部远对上，R102 的几何计算给

\[
 e^{-\|y-z\|_1/L}\le
       \frac{n u_v}{(1+\log(1/u_v))^2}.
\]

若截断阈值为零，右端至少一，仍成立。丢去 `G`、`h²<=1` 及任何帽限制，只会增大此非负部分。节点有序交叉对质量是 `2ab`，所以小尺度远对全积分不超过

\[
 2ab\int_0^{(m/\sigma)^{1/n}}
     L^{-n}\frac{n\sigma L^n/m}{(1+\log(m/(\sigma L^n)))^2}
          \frac{dL}{L}
 =\sigma\frac{2ab}{m}.
\tag{12}
\]

**节点 `u_v>=1` 不能再声称 `h=0`。** 根来源仍可大量进入同一接收立方体。此部分直接保留原始平方尾，付

\[
 2ab\int_{(m/\sigma)^{1/n}}^\infty L^{-n}\frac{dL}{L}
 =\frac\sigma n\frac{2ab}{m}.
\tag{13}
\]

合计每个节点的全空间局部远对收费是

\[
 \int B_v\le\sigma_v\,r_v(1+1/n),
 \qquad r_v:=\frac{2a_vb_v}{m_v}\le\frac{m_v}{2}.
\tag{14}
\]

每层的 `r_v` 总和至多 `W/2`；又 `Σ_{d>=0}w_d=1`（望远镜），因而求和得到 (9)。节点共同交叠用的是真实 `dx`，未将后验独立。节点对集合的可数不交分解与一切积分交换均用非负 Tonelli。

无限细分的合法性来自 (4) 下来源对集合被直接可数穷尽，不是“剩余来源对质量很小所以剩余能量很小”。有限层截断时，叶内能量仍须完整保留；若原能量无穷，不能凭平方质量趋零调用不适用的有限测度上连续性去删除能量终端。

## 5. 来源质量缩小后的窗口与实际薄层

在半质量树上，节点深度 `d` 的局部对数尺度为

\[
 s_v=s-d\log2+\log((d+1)(d+2)).
\tag{15}
\]

负或零 `s_v` 对应局部大尺度，已由 (13) 支付。正 `s_v` 的近对仍用 (7)。这明确减少全质量 `W` 对小块的影响；为保持总费用有限，付出的窗口修正是 `log((d+1)(d+2))`，即质量比例的双对数级修正。该表达只适用于半质量树，不能套在任意不平衡树上。

也有不能省略的局限：`d=0,...,5` 时 `(d+1)(d+2)/2^d>=1`，于是 `s_v>=s`，`G=1` 必推出 `H_v=1`。这些粗层的原近对贡献**完全没有**被 (9) 的已付部分移走。新机制不能替代粗层近对的接收帽。它从深层取得严格的可能改善，不证明剩余能量按某个比例缩小。半质量树上的免费项前六层实际为零，若只优化此证书常数，可把 (9) 的右端降为 `(1+1/n)κW/14`；这不是必要主结论。

若节点沿坐标 `j` 的超平面 `y_j=c_v` 切开，则在局部近对事件中，两来源端各位于厚度 `Lt_n(s_v)` 的对应侧薄层：

\[
 y\in C_{v0}\cap\{c_v-Lt_n(s_v)\le y_j\le c_v\},\qquad
 z\in C_{v1}\cap\{c_v\le z_j\le c_v+Lt_n(s_v)\}.
\tag{16}
\]

理由是 `z_j−y_j<=||z−y||_1<=Lt_n(s_v)`。更强的实际接收定位来自**同时捕获两个分居切面两侧的点**：

\[
 x_j\in[z_j-L/2,y_j+L/2]\subseteq[c_v-L/2,c_v+L/2].
\tag{17}
\]

式 (17) 不需要近对门，且没有 `t` 膨胀因子。对给定接收行，记 (16) 两侧来源薄层再与 `Q_x` 相交的质量为 `a_v^{\rm col}(x,L), b_v^{\rm col}(x,L)`，则节点局部近对有序质量不超过

\[
 2a_v^{\rm col}(x,L)b_v^{\rm col}(x,L),
\tag{18}
\]

并仅在 (17) 的真实接收条带出现。更精细的 (3) 式局部质量可在两侧之间交叉使用。这里的薄层质量、接收条带的重合程度及原 `h` 均保留；它们尚无子幂积分上界。

这指出下一步真正需要的几何，而非新假设包装：为各粗层切面和其局部薄层选择**同一个**接收帽，测算 (17) 所对应的热点是否重叠、是否能用实际并集体积一次覆盖。条带本身可能无界，其质量并不由“薄”字保证；不同层条带不能先分别扩大、分别收费再猜一个根阶修正。由本轮已经支付的只是 (9)，没有给 (16)–(18) 免费的 Carleson 或全子树 packing。

## 6. 递归费用的准确失败：固定节点价必发散

对满足 (4) 的任意二叉来源树，

\[
 \boxed{\sum_v\frac{2a_vb_v}{a_v+b_v}=\infty.}
\tag{19}
\]

这说的是把 (14) 中的 `σ_v` 固定为同一正常数时，其**一般逐节点上界账本**不可求和；不声称真实局部远能量无穷。

证明：在每节点把质量较小的孩子称为少数孩子，质量相同时固定选一侧。`r_v>=min(a_v,b_v)`。若 `Σr_v<∞`，则少数孩子集合的指示函数总和对 `μ` 可积。因此几乎每个来源点仅进入有限多个少数孩子，此后始终跟随质量较大孩子。这样的最终路径仅可数：由开始一直跟随多数孩子的有限节点即可枚举。但由 (4)，任何固定无限路径的节点质量趋零，其交集为 `μ` 零测。可数个此类路径不能覆盖正总质量 `W`，矛盾。

因此不能把“每节点费用看似 `κm_v`，所以总共只付一次 `κW`”当作证明；同一来源会经过无限多个节点。半质量树截到 `D` 层时确有 `Σ_{d<D}Σr_v=WD/2`，显示 `log(W/m_leaf)` 级**证书**费用。(6) 将这项费用转成可求和权重，并准确保留 (15) 的窗口代价；没有把日志费藏进“常数”。

**与 comb 分区的区别。** 单次链式剥叶的跨叶节点满足 `Σ2a_ib_i/(a_i+b_i)<=2Σa_i<=2W`，所以这部分可固定阈值付款；但剥出的正质量叶的内部对尚在终端。若按几何角色的有限树公式给每叶另外付其局部远尾，总全树远对常数仍可为常数，叶内近对却仍保留。若进一步完整细分所有叶且继续固定逐节点一般价格，(19) 又适用。不得把“跨叶远对已付”写成“所有内部近对已处理”，也不得把 finite-comb 的叶近对说成遗漏了所有叶对。

## 7. 对原目标的影响和结束判据

本轮没有改变任何帽。在正规输入的同一 R100 障碍 `Ω` 上，任取 `U⊃Ω`，完整实际超额能量满足

\[
 E_\kappa(f;U)\le
 \int_{U^c}R(x)dx+
 \left[1+\frac{1+1/n}{2}\right]\kappa W.
\tag{20}
\]

第一项仍未付。若将来证明它与 `|U|` 有统一子幂预算，R100 帽返回可继续使用；本文不把这个条件句列作新增进展。新增的一般内容是 (9)、(14)、(16)–(19) 的准确付款、空间限制和失败结论。

下一阶段若尝试按尺度局部累计质量 `m_y(L)` 取代树节点质量，不能照搬 (12) 的 `ds=−n dL/L`：那时 `d log(m_y(L)/(κL^n))=d log m_y(L)−n dL/L`，`dm/m` 的额外项必须实际计入。本轮各节点 `m_v` 是固定质量，因此积分换元没有这个错误；节点间费用则通过 (14) 和可求和深度权明确支付。这里尚未证明自适应连续 `m_y(L)` 比离散节点更便宜。

数值应先验证同一完整来源的正接收体积、正尺度窗内确有 `G=1,H_v=0` 且 `h>0`，再评估同一帽上的剩余 `R`；只看新的窗口更小或原 near/far 分类变化不够。远源增加使原局部对变成 global-near，但同一接收行的 `A,h` 未变，这仅说明全质量分类不局部，并非真实能量增长。有限证书不能把一般帽预算写成已付。

## mass potential

## 1. 增量与不变对象

这是 `near_strategy.md` 深度折扣的另一种、已可一般证明的收费方式。辅助参数只依赖节点真实质量 `m` 与总质量 `W`，不依赖人为树深度。所有节点局部远对的总费用不超过 `(1+1/n)κW`；它从原近对中移出一个可积部分，剩余近对的联合接收帽仍未支付。

固定 `n>=1`、`f>=0∈L1(R^n)`、`μ=fdy`、`W=∫f>0` 和 `κ>0`。完整来源平均、根阈值因子及 R102 原近对门均不变：

\[
 A_Lf=L^{-n}\mu(Q(x,L)),\qquad h=(1-\kappa/A_Lf)_+,
\]

\[
 s=\log(W/(\kappa L^n)),\quad
 G_L(y,z)=\mathbf1_{\{s>0,\ \|y-z\|_1/L\le [s+2\log(1+s)-\log n]_+\}}.
\tag{1}
\]

式 (1) 的截断表达式只在 `s>0` 时定义和求值；若 `s<=0`，直接置 `G_L=0`，不求 `log(1+s)`。`A_L=0` 时 `h=0`。实际近对密度 `N` 仍是 `h²L^{-2n}` 乘以 `Q_x²` 上带 `G` 的来源对质量，再对 `dL/L` 积分。树节点的分区、对的首次分离登记沿 `near_strategy.md` §3；以下收费引理本身不要求树穷尽每个来源对，能量分解另明确这个条件。

## 2. 正权、闭式与准确界

对 `0<m<=W` 记 `ℓ=log(W/m)>=0`，定义

\[
 \beta(\ell)=\int_0^1\alpha e^{-\alpha\ell}\,d\alpha,
 \qquad
 \gamma(\ell)=\int_0^1e^{-\alpha\ell}\,d\alpha.
\tag{2}
\]

有 `β(0)=1/2`、`γ(0)=1`；当 `ℓ>0`，

\[
 \beta(\ell)=\frac{1-(1+\ell)e^{-\ell}}{\ell^2},\qquad
 \gamma(\ell)=\frac{1-e^{-\ell}}\ell.
\tag{3}
\]

两者处处正且递减；`β` 严格递减。以下全范围界避免在 `ℓ=0` 使用不定商：

\[
 \frac{e^{-1}}{2(1+\ell)^2}\le\beta(\ell)
 \le\frac4{(1+\ell)^2},\qquad \beta(\ell)\le\tfrac12.
\tag{4}
\]

证明：下界仅积分 `0<=α<=1/(1+ℓ)`，此区间 `e^{-αℓ}>=e^{-1}`。若 `ℓ<=1`，`β<=1/2<=2/(1+ℓ)^2`；若 `ℓ>=1`，将积分扩到正半轴给 `β<=1/ℓ²<=4/(1+ℓ)^2`。闭式由直接积分得到，单调性由正积分或求导得到。

## 3. 有限质量势账本与可数延拓

对一个节点，质量为 `m=a+b>0`，定义

\[
 r(m;a,b)=\frac{2ab}{m}.
\tag{5}
\]

允许一个孩子质量为零，此时 `r=0`，零质量项直接置零。给任意有限完整二叉分区子树，其根质量为 `W`、内部节点集合为 `I`、终端叶集合为 `T`，证明

\[
 \boxed{\sum_{v\in I}\beta(\log(W/m_v))r_v
 \le W-\sum_{v\in T}m_v\gamma(\log(W/m_v))\le W.}
\tag{6}
\]

这里的 `W` 是从头固定的原总质量，不在子节点重新归一化。

固定 `0<α<=1`，令 `p=a/m`。凹函数 `t^α` 在 1 的切线上界为

\[
 p^\alpha\le1-\alpha+\alpha p,
 \qquad (1-p)^\alpha\le1-\alpha+\alpha(1-p).
\]

分别乘以 `p,1−p` 再相加，得到

\[
 1-p^{1+\alpha}-(1-p)^{1+\alpha}
 \ge 2\alpha p(1-p).
\]

因此准确节点势降满足

\[
 m^{1+\alpha}-a^{1+\alpha}-b^{1+\alpha}
 \ge\alpha m^\alpha r(m;a,b).
\tag{7}
\]

将 (7) 对有限树的内部节点相加，所有中间节点幂势抵消，保留真实叶终端：

\[
 \sum_{v\in I}\alpha(m_v/W)^\alpha r_v
 \le W-W^{-\alpha}\sum_{v\in T}m_v^{1+\alpha}.
\tag{8}
\]

对 `dα` 在 `(0,1]` 积分即是 (6)。**没有再乘一个额外的 `α` 权重**；(8) 左端已经含有定义 `β` 所需的 `α`。右端叶项积分是 `m_vγ(log(W/m_v))`。无需处理 `α=0` 的除零式，也没有引用熵极限。

对一棵可数树，任意有限节点集合可嵌入包含祖先及必要兄弟叶的有限完整子树；各节点收费均非负。对越来越大的有限前缀用单调收敛/Tonelli，得到

\[
 \sum_v\beta(\log(W/m_v))r_v\le W.
\tag{9}
\]

该收费界不要求来源对都最终分离；它也不擅自删除没分离的来源对。若额外有每层平方质量和趋零，则各层最大质量趋零，且

\[
 \sum_{|v|=d}m_v\gamma(\log(W/m_v))
 \le W\gamma\!\left(\log\frac{W}{\max_{|v|=d}m_v}\right)\longrightarrow0.
\tag{10}
\]

这是质量势终端趋零，不是能量终端趋零。能量的无限分解仍靠来源对的直接可数穷尽；有限层叶内近对能量必须保留。

## 4. 对实际根近对的统一付款

每节点改用辅助几何参数

\[
 \sigma_v=\kappa\beta(\ell_v),\quad
 \ell_v=\log(W/m_v),\quad
 u_v=\frac{\sigma_v L^n}{m_v}.
\tag{11}
\]

局部近对是 `u_v<1` 且

\[
 \|y-z\|_1/L\le
 [\log(1/u_v)+2\log(1+\log(1/u_v))-\log n]_+.
\tag{12}
\]

`σ_v` 不取代实际 `κ`，完整 `h` 不改。每对分配给首次分离节点，并只在原 `G=1` 的部分再按 (12) 切分。设所得剩余密度为 `R_mass`，移入节点局部远对的密度为 `B_mass`。若树满足来源对穷尽条件，

\[
 N=R_{\rm mass}+B_{\rm mass},\qquad 0\le R_{\rm mass}\le N.
\tag{13}
\]

共同接收交叠的几何上界和 `near_strategy.md` 式 (12)–(14) 的直接积分，对任意 `σ_v>0` 已证明单节点费用

\[
 \int B_v\le(1+1/n)\sigma_v r_v.
\]

具体而言，局部 `u_v<1` 的远对用乘积交叠衰减支付 `σ_vr_v`；局部 `u_v>=1` 的原始平方尾另付 `σ_vr_v/n`。后者不能假称被完整来源的 `h` 自动杀掉。用 (9) 求和，得

\[
 \boxed{\int B_{\rm mass}\le(1+1/n)\kappa W.}
\tag{14}
\]

整个证明只放大非负项并用真实 `dx` 的交叠体积，不改变来源或接收测度。因而对任何同一个可测帽 `U`，

\[
 \int_{U^c}N\le\int_{U^c}R_{\rm mass}+(1+1/n)\kappa W.
\tag{15}
\]

加上 R102 已付的根远对 `κW`，完整实际能量满足

\[
 E_\kappa(f;U)\le\int_{U^c}R_{\rm mass}+(2+1/n)\kappa W.
\tag{16}
\]

有限树版本保留各终端叶的原近对能量，不能因 (6) 有界就删去它们。没有任何接收帽体积从 (14) 自动得到；一般根阶仍取决于剩余 `R_mass` 的真实联合接收几何。

## 5. 质量窗口的效果和未消除的全质量依赖

写根尺度 `s=log(W/(κL^n))`，则节点局部尺度准确为

\[
 s_v=s-\ell_v-\log\beta(\ell_v).
\tag{17}
\]

由 (4)，代价项满足

\[
 -\log\beta(\ell)\le2\log(1+\ell)+\log(2e).
\tag{18}
\]

因此几何局部化把根 `s` 中的 `log(W/m)` 减去，同时保留明确的双对数修正；不是免费把 `W` 换成 `m`。与深度折扣不同，长的近空分支或人为插入的零质量兄弟节点不会单凭深度增大这个修正。

还有一项准确单调性。设

\[
 g(\ell)=\ell+\log\beta(\ell).
\]

对有限 `ℓ>=0`，

\[
 g'(\ell)=1-
 \frac{\int_0^1\alpha^2e^{-\alpha\ell}d\alpha}
      {\int_0^1\alpha e^{-\alpha\ell}d\alpha}\in(0,1).
\tag{19}
\]

分式是落在 `(0,1)` 的 `α` 的正加权均值。故在 `W,κ,L` 不变时，节点质量下降会使 `s_v=s−g(ℓ_v)` 严格下降，局部近对门随之缩小（若 `s_v<=0` 则为空）。但根处 `g(0)=−log2`，其局部近对比原根近对宽。实际分解始终与 `G` 相交，因此剩余不会大于原 `N`；它并不保证每个节点都移走正能量。

**它仍不是纯局部的分类。** 固定一个不变的局部节点质量 `m`、来源对及接收尺度，添加足够远而不会被该行捕获的来源，使总质量 `W` 增大，则 `ℓ` 增大、`β(ℓ)` 减小，而

\[
 s_v=\log(m/(\kappa L^n))-\log\beta(\log(W/m))
\]

仍会增大。其增长是渐近双对数级，但没有消失；真实 `A_L,h` 可以同时完全不变。这说明质量权缓和了分类的全质量影响，不证明已消除所有远源依赖。

同样，(19) 只比较固定 `W` 下两个给定节点质量的门；它不表示任意改换来源分区都会产生更小残余。真实切分会改变哪些来源对在何处首次分离、改变切面及接收条带。只有插入零质量兄弟的一元链、且原非平凡分割仍保留时，原对的分离节点质量和对应门保持不变；任意人工细分不变性没有被证明。

质量权也不必逐节点优于原深度权 `1/((d+1)(d+2))`。它们的总费用和局部窗口不同，不能把两者最有利的窗口与最小的费用任意组合。本轮数值生产协议继续测试原深度权；不把它冒称为质量权的实际来源验证。

## 6. 仍需支付的接收几何

若来源树采用真实坐标切面，`near_strategy.md` 的源侧薄层和接收侧定位仍逐字成立，只需将厚度改用 (12) 的实际 `s_v`：跨切面对被同一立方体捕获时，其接收坐标必在切面两侧 `L/2` 内；局部近对两来源还各在切面相应侧 `Lt_n(s_v)` 内。这里使用完整来源的 `h`，不会再犯同阈值分量零能量拼接错误。

(14) 回答了“递归来源质量能否一次付完”的一个部分：这一类节点局部远对可以，且 (6) 保留了准确有限终端。它没有回答剩余薄层近对的接收热点能否共用一份子幂帽体积。下一步若忽略这些真实条带的重合、先逐节点扩大帽再相加，就会再次丢失联合几何；本质量势不能修补那个遗漏。

## mass accounting

## 问题与定义

取有限 rooted tree，叶为 source labels，叶质量 \(w_i>0\)，总质量 \(W=\sum_i w_i\)。每个节点 \(C\) 的质量是其后代叶质量之和 \(m_C\)。对每个内部节点 \(C\)，其孩子簇记为 \(A_1,\ldots,A_k\)，并定义节点 cross-child 账单
\[
\mathfrak f(C)=\frac{1}{m_C}\sum_{r<s}m_{A_r}m_{A_s}
=\frac{m_C}{2}\left(1-\sum_r p_{r|C}^2\right),\qquad p_{r|C}=m_{A_r}/m_C.
\]
总账单为 \(\mathfrak F(T)=\sum_{C\text{ internal}}\mathfrak f(C)\)。二叉树是 \(k=2\) 的特例，此时节点费正是 \(m_Am_B/m_C\)。

这只是 LCA 质量泛函：每一对不同叶质量 \(w_i,w_j\) 在其唯一最低共同祖先处相遇，并在那里缴纳 \(w_iw_j/m_C\)。所以有精确重排
\[
\mathfrak F(T)=\sum_{i<j}\frac{w_iw_j}{m_{\operatorname{LCA}(i,j)}}.
\]

## 锐利的通用上界

令 \(p_i=w_i/W\)，\(H(p)=-\sum_i p_i\log p_i\)（自然对数）。则对任意有限树、任意节点度数，
\[
\boxed{\quad \mathfrak F(T)\le \frac{W}{4\log 2}H(p)\le\frac{W}{4}\log_2 N,\quad}
\]
其中 \(N\) 为叶数。二叉树中的常数 \(1/(4\log2)\) 锐利；以底数 2 写时，叶数界的系数 (1/4) 也锐利。

**证明。** 先看二叉树。对节点 \(C\)，写 \(t=m_A/m_C\)，则
\[
\frac{m_Am_B}{m_C}=m_Ct(1-t).
\]
二元熵 \(h(t)=-t\log t-(1-t)\log(1-t)\) 满足
\[
t(1-t)\le \frac{h(t)}{4\log2},\qquad 0\le t\le1.
\]
这是一个一元微积分不等式。令 \(g(t)=h(t)-4\log2\,t(1-t)\)。在 \(0<t<1/2\) 上，
\[
g'(t)=\log\frac{1-t}{t}-4\log2(1-2t),\qquad g''(t)=-\frac1{t(1-t)}+8\log2.
\]
所以 \(g''\) 先负后正且只变号一次；\(g'(1/2)=0\)，故变号点之后 \(g'<0\)，而变号点之前 \(g'\) 严格递减并由 \(+\infty\) 降到负值，恰有一次零点。于是 \(g\) 先增后减，并由 \(g(0)=g(1/2)=0\) 得 \(g\ge0\) 于 \([0,1/2]\)；另一半由对称性得到。对子节点条件概率作熵链式分解，
\[
H(p)=\sum_{C\text{ internal}}\frac{m_C}{W}h(t_C).
\]
逐节点相加即得 \(\mathfrak F(T)\le WH(p)/(4\log2)\)。

若节点有 \(k>2\) 个孩子，把其孩子任取顺序，逐个拆成二叉分割。原节点费不超过该二叉细化在此节点产生的费用：在细化时，已分出的质量 \(u\) 与余质量 \(v\) 产生 \(uv/m_C\)；递归拆余簇的分母不超过 \(m_C\)，故对子簇对的相应费用至少为原来以 \(m_C\) 为分母的费用。所有节点细化后得到相同叶质量向量 \(p\) 的二叉树，且不改变叶熵。应用二叉结论得到一般树的熵界。最后由 \(H(p)\le\log N\) 得叶数界。

锐利性由完美平衡二叉树、等质量叶达到：每一深度总节点费恰为 \(W/4\)，故 \(N=2^d\) 时 \(\mathfrak F=W d/4=(W/4)\log_2N\)，同时 \(H(p)=\log N\)。

## 人工碎分的精确后果

固定总质量 \(W\)，把一个 label 在账本中拆成 \(N=2^d\) 个等质量 labels，并取完美二叉树，则
\[
\mathfrak F=\frac W4\log_2N=\frac W4d\longrightarrow\infty.
\]
故这项收费对固定 \(W\) 不是与碎分数无关的一致常数；对树取最坏情形时，其锐利增长正是 \(W\log N\)，或更精细的 \(WH(p)\)。这不是每一棵树都必须支付的下界：comb tree 每次剥出叶 \(i\) 的费用为 \(w_i m_{rest}/(w_i+m_{rest})\le w_i\)，故沿该树总费用至多 \(W\)，无论叶数多少。固定 \(N\) 时通用上界有限且锐利；发散只在 \(N\to\infty\) 且选取高账单树（例如平衡树）时发生。

这证明的是**标签树质量账本**会受人工碎分影响。若 labels 对应同一物理 source、真实空间支撑完全重合，实际 \(h(x,L)\) 不随人为改名而改变；因此不能把 \(\mathfrak F\to\infty\) 当作 source-pair 真实贡献、\(h\) 积分发散、F2 反例或弱型下界。相反，它指出若采用此账本，必须先固定有几何含义的 leaves，或额外商去同源细分；该要求本身也不能取代对真实积分的估计。

## 与真实 source-pair / \(h(x,L)\) 的区分

上面的 \(w_iw_j/m_C\) 是给定后代质量后的**代数交互额度**。先验证用户所提的固定簇 far 费：对节点 \(C=A\cup B\)，令 \(u_C=\kappa L^n/m_C\)、\(s_C=\log(1/u_C)\)，仅在 \(0<u_C<1\) 上定义
\[
t_C(u_C)=\bigl[s_C+(1+\eta)\log(1+s_C)-\log q\bigr]_+.
\]
将 \(A\times B\) 中满足 \(d_L(y,z)>t_C(u_C)\) 的来源对称作簇 far 对。R102 的核界与指数门给出
\[
\begin{aligned}
\iint_{A\times B,\,d_L>t_C} L^{-n}e^{-d_L(y,z)}\,d\mu(y)d\mu(z)
&\le \frac{q\kappa m_Am_B}{m_C(1+s_C)^{1+\eta}},\\
\int_{0<L<R_C}\cdots\,\frac{dL}{L}
&\le \frac{q\kappa}{n\eta}\frac{m_Am_B}{m_C},\qquad R_C=(m_C/\kappa)^{1/n}.
\end{aligned}
\]
第二行由 \(dL/L=-ds_C/n\) 积分。故在局部定义域 \(0<L<R_C\) 内，固定 cluster fee 确为 \(m_Am_B/m_C\)，前面乘 R102 明示的 \(q\kappa/(n\eta)\)；全源双重积分还包括反向块 \(B\times A\)，再乘 2（若账本从一开始按有序对定义，则在每个节点同时计入两向）。当 \(L\ge R_C\) 时 \(u_C\ge1\)，局部阈值公式不再定义；若被积量仍是由完整 \(f\) 形成的 \(h\)，它也不因此自动为零。故把局部 far mask 延伸到该段，须另行支付其 \(u_C\ge1\) 尾项；上式没有覆盖它。

另一个独立账目是 R102 的**全源 far mask**：用全源变量 \(u_W=\kappa L^n/W\)、\(s_W=\log(1/u_W)\)，只在其 global-far 域内限制到一个有序子对块 \(A\times B\)。R102 的 \(|I_L|\le L^n e^{-d_L}\) 与全源指数门给出
\[
E_{\mathrm{far},A\times B}(U)\le \frac{q\kappa}{n\eta}\frac{m_Am_B}{W}.
\]
原二重积分是有序的，故 global-far 域内的 \(A\times B\) 与 \(B\times A\) 合计至多为右侧的两倍。该分母 \(W\) 只适用于全源门定义的 global-far 子集，不能移用到以 \(u_C,s_C,t_C\) 定义的 local-far 域。对 global-far 子集沿有限树分配 LCA 后，按全源质量账求和；所有有序叶块的归一化质量和不超过 \(W\)，故此部分对人工细分稳定。以上只支付各自 mask 下的 **R102 far 对部分**。它不推出近对或全能量的账单，也不推出实际 source-pair 核在每个 \((x,L)\) 上被 LCA 费控制。完整支付仍须把实际 pair integrand 的来源归属、同一帽/接收删除和 near/far 尺度逐项保留；有限树求和本身没有支付近场或空间重叠。

## 全源 cutoff \(R_W\) 与簇 cutoff \(R_C\)

令 \(R_m=(m/\kappa)^{1/n}\)，全源 cutoff 为 \(R_W\)，节点自身质量 cutoff 为 \(R_C\)，其中 \(m_C\le W\)，故 \(R_C\le R_W\)。全源质量只给出 \(A_Lf\le W/L^n\le\kappa\) 于 \(L\ge R_W\)；节点质量只给出簇平均 \(A_Lf_C\le m_C/L^n\le\kappa\) 于 \(L\ge R_C\)。因此，若旧 far integral 的论证依赖簇自身 cutoff \(L\ge R_C\)，用全源 cutoff 代替时，中间带
\[
R_C\le L<R_W,\qquad \int_{R_C}^{R_W}\frac{dL}{L}=\log\frac{R_W}{R_C}=\frac1n\log\frac{W}{m_C}
\]
不会被 cutoff 消掉；该带在 \(dL/L\) 下长度为 \(\frac1n\log(W/m_C)\)。若用不带尺度衰减的逐尺度粗界支付，它可能带来对数质量比；但 R102 far 估计保留权重 \((1+s_W)^{-1-\eta}\)，故该全源 far 子集在此带的积分仅为
\[
\frac{q\kappa m_Am_B}{nW}\int_0^{\log(W/m_C)}\frac{ds}{(1+s)^{1+\eta}}
=\frac{q\kappa m_Am_B}{nW\eta}\left[1-\left(1+\log(W/m_C)\right)^{-\eta}\right]
\le\frac{q\kappa m_Am_B}{nW\eta}.
\]
因此，对 **global-far 子集**，全源 cutoff 不使 R102 的旧全尺度积分失效，也不必另付裸 \(\log(W/m_C)\)。这是保持 global mask 后的结论，不是把局部门改写成全源门。对局部门，\(R_C\le L<R_W\) 已满足 \(u_C\ge1\)，局部阈值不再适用；若 \(h\) 仍由 full \(f\) 形成，不能由此推断其为零，须单独估计该局部定义域之外的尾项。该缺口需要真实 integrand 衰减或独立预算，不能把区间长度直接当成能量下界，也不能把它直接当成能量费用。

因此不能仅凭半径替换声称“簇门已支付 full \(h\)”：被积量保持 full \(f\) 不代表 mask 也使用 global \(W\)。对全源 far mask，中间带的 global-far 部分已有上述衰减积分；但簇质量界 \(A_Lf_C\le\kappa\) 只说明簇自身平均低于阈值，不说明完整来源产生的 \(h(x,L)\) 为零。局部门在 \(u_C\ge1\) 时没有阈值公式；其局部 far 尾或相应未覆盖项须另行支付，且不由 global-far 估计自动覆盖。必须按实际 \(h(x,L)\)、接收帽和尺度范围处理，不能只凭 cutoff 半径替换。

## 结论边界

已证明：固定有限树上的 LCA 质量收费有精确 pair 重排、熵界及锐利碎分例。

未证明：这项收费支配任意真实 source-pair 贡献或 \(h\) 的积分；也未证明任何 F2 capacity、一般 weak bound 或目标问题的反例。本文未运行数值实验，未使用外部定理，未引用 PRIVATE 配方。

## scale cutoff

以下 n 为正整数，假设 W>0；W=0 时 f=0 几乎处处，所有能量为零，单独平凡处理。

令 \(\mu=f(y)\,dy\ge0\)、\(W=\mu(\mathbb R^n)<\infty\)、\(\kappa>0\)。对立方体 \(Q(x,L)=x+[-L/2,L/2]^n\)，记
\[
A_Lf(x)=L^{-n}\mu(Q(x,L)),\qquad
h(x,L)=\left(1-\frac{\kappa}{A_Lf(x)}\right)_+,
\]
其中当平均为零时置 \(h=0\)。给定任意可测收费帽 \(U\)，source-pair 能量为
\[
\mathcal E_U=\int_0^\infty L^{-2n}
 \iint\int_{Q(y,L)\cap Q(z,L)\setminus U}h(x,L)^2\,dx\,d\mu(y)d\mu(z)\,\frac{dL}{L}.
\tag{1}
\]

取一个有限或可数的两两不交源簇 \(C_i\)，令 \(m_i=\mu(C_i)>0\)，并只先计同簇有序对 \(C_i\times C_i\)。若 \(m_i<W\)，它的中间尺度是
\[
\frac{m_i}{\kappa}\le L^n<\frac{W}{\kappa}.
\]
把该尺度上的 (1) 限制到 \(C_i\times C_i\)，用 \(0\le h\le1\)、\(U^c\subseteq\mathbb R^n\) 及两个边长 \(L\) 的立方体交体积至多 \(L^n\)，得
\[
\begin{aligned}
\mathcal E^{\rm mid}_{i}
&\le m_i^2\int_{(m_i/\kappa)^{1/n}}^{(W/\kappa)^{1/n}}
 L^{-2n}L^n\,\frac{dL}{L}\\
&=\frac{\kappa m_i^2}{n}\left(\frac1{m_i}-\frac1W\right)
=\frac{\kappa m_i}{n}\left(1-\frac{m_i}{W}\right)
\le\frac{\kappa m_i}{n}.
\tag{2}
\end{aligned}
\]
区间为空时贡献为零。若只计其中一个有序对集合 \(P_i\subseteq C_i\times C_i\)，也可保留其实际 pair mass \(\alpha_i=(\mu\otimes\mu)(P_i)\)：右端可 sharpen 为
\[
\frac{\kappa\alpha_i}{n}\left(\frac1{m_i}-\frac1W\right)
=\frac{\kappa}{n}\frac{\alpha_i}{m_i}\left(1-\frac{m_i}{W}\right).
\tag{3}
\]

因此，对两两不交且总质量 \(\sum_i m_i\le W\) 的有限源簇，所有同簇中间尺度项可直接相加：
\[
\sum_i\mathcal E_i^{\rm mid}
\le\frac{\kappa}{n}\sum_i m_i\left(1-\frac{m_i}{W}\right)
\le\frac{\kappa W}{n}.
\tag{4}
\]
这笔账没有子树重计：每个同簇有序源对只属于一个不交簇；Tonelli 与非负性允许逐簇求和。若簇是树状嵌套集合，则同一对可能出现在每个祖先节点，(4) 不能直接按节点相加。把 pair classes 划成互不交集合后，按 (3) 求和需要另证实际加权预算 \(\sum_i\alpha_i/m_i\)；至于 \(\sum_i m_i\le W\) 且 \(\alpha_i\le m_i^2\)，只是推出该预算的一种充分办法。不同簇之间的 cross-pairs 也不在 (4) 内，需另行分配或收费。

端点的逻辑边界很关键：仅当 \(L^n\ge W/\kappa\) 才能由全局质量推出 \(A_Lf\le\kappa\) 从而 \(h=0\)。把 \(W\) 换成严格较小的簇质量 \(m_i\) 不会使全局 \(h\) 在 \(L^n\ge m_i/\kappa\) 消失；区间 \([m_i/\kappa,W/\kappa)\) 正是 (2) 所支付的中间尺度。此证明只界定这部分 source-pair 能量，不估计 near scales，也不推出一般 root 弱界。

## tools

## Finding

The outer source-pair measure in this problem is already `μ⊗μ`: the two source points are sampled as a product of the full source measure. Coordinate dependence inside `f` does not change this product across the two source-point variables. Thus the local LCA product algebra below is available without assuming coordinate independence or adding a conditional-independence hypothesis. If an accepted `h²` factor is imposed, it can couple the pair; the actual accepted-pair measure is then not a product. Where the established estimate drops `h²` using its pointwise bound, the unweighted `μ⊗μ` calculation is a valid upper bound.

There are already two stated payment routes for the aggregate local bill: the verified **unordered** comb account `F=Σ_{unordered {a,b}}ab/m` is at most `W`, so its ordered cross-pair counterpart is `2F≤2W`; when the leaf-diagonal contribution is included, the corresponding full local-far bracket is at most `3W`. The Astra depth-weighted `τ_d` account is also summable, with its own `2ab/m` and `σ` weights retained. These pay only the terms they actually dominate; they do not make every `h²`-accepted pair product-valued or supply an E03 Bellman mapping. A separate subtree-packing premise is needed only for a proposed route that invokes E03's Carleson embedding, not as a universal requirement for this source-pair budget.

## Exact local identity and what it costs

Let a finite rooted tree carry a conserved nonnegative mass `m_C`, with children `A` of each internal node `C` partitioning its mass: `Σ_{A child of C}m_A=m_C`. Write `p_A=m_A/m_C` when `m_C>0`. Under the outer product source-pair measure `μ⊗μ`, its restriction to `C×C` has mass `m_C²`; normalizing by `m_C²` gives `(μ|_C/m_C)⊗(μ|_C/m_C)`, the conditional product of the two child mass laws. Multiplying the resulting conditional pair probability by the single-node mass `m_C` gives the LCA charge `m_A m_B/m_C`. Therefore

\[
\sum_{A\ne B\text{ child of }C}\frac{m_A m_B}{m_C}
=m_C\left(1-\sum_Ap_A^2\right)
\le m_C H(p_C),\qquad H(p_C)=-\sum_Ap_A\log p_A.
\]

The identity is direct expansion; the inequality follows termwise from `-log p >= 1-p`. For unordered pairs, the left side is halved. This pays one LCA node by its conditional child entropy, but the global bill is still `Σ_C m_C H(p_C)`. On a finite tree this equals root mass times the Shannon entropy of the terminal path label, by the ordinary finite chain rule. Thus it is finite for a finite tree, but can grow with depth and branching absent another bound. This entropy route is optional here: the already established unordered comb account `F≤W` pays ordered cross-pairs at `2F≤2W`; with leaf diagonals the stated local-far bracket is `≤3W`. The depth-weighted `τ_d` account is separately summable with its `2ab/m` and `σ` factors.

Alternatively, the pointwise rough bound at each node is the ordered sum `Σ_{A≠B}m_Am_B/m_C≤m_C`. A generic tree sum of this estimate can cost `Σ_Cm_C`, but for the present argument the verified unordered comb account gives only `F≤W`; preserve the factor two when converting to ordered cross-pairs (`2F≤2W`), and include the leaf diagonal only under the separately stated full-bracket bound `≤3W`. The Astra depth-weighted `τ_d` terms retain their `2ab/m` and `σ` weights and are summable. Thus one must match the actual local terms to those accounts and preserve their weights; no generic subtree-packing assertion is needed for these already-paid branches. If neither account covers a proposed remainder, then an additional packing, depth, or entropy bound is still required for that remainder.

## Screened tools

| Tool | Precisely usable statement and required inputs | Match and unpaid step |
|---|---|---|
| **D04 entropy chain rule** | For standard Borel spaces with joint probability laws `P_{XY},Q_{XY}` and their regular conditional kernels, `D(P_{XY}||Q_{XY})=D(P_X||Q_X)+∫D(P_{Y|x}||Q_{Y|x})P_X(dx)`. The chain uses the `P`-history weight and the actual `Q` conditional reference. Finite-value derivation requires the stated absolute-continuity/integrability conditions; the extended version sums nonnegative KL terms without entropy subtraction. Iteration over finitely many levels is valid with the true conditional reference at each level. Infinite depth needs a consistent process law and a relative-entropy limit theorem. | It can telescope a *specified* source/branch label law and bound cumulative conditional KL by a known joint KL. It does not identify an `h²`-accepted pair measure with the unweighted product, create a reference kernel, or bound terminal KL/entropy. The outer unweighted pair measure is already `μ⊗μ`; the accepted-pair dependence must instead be controlled by the established `h²≤1` domination or its actual joint law. A uniform entropy fee requires an independently established bound on terminal-label/joint KL, including depth and `n`. |
| **E03 tree Bellman embedding** | The verified source is a finite/truncated standard binary tree with its tree measure `Λ`, nonnegative node coefficients `α_I`, square-integrable `φ`, state conditions `f²≤Fv`, `0≤A≤v`, and every subtree satisfying `|I|^{-1}Σ_{K⊂I}α_K(Λ)_K²≤(Λ)_I`. Its source-checked Bellman potential is `B=4(F−f²/(v+A))`, with the factor 4 multiplying the entire parentheses. Under the source's specified parent/child increments, the local charge `c f²/v²` is bounded by parent potential minus child potentials. The embedding constants are 4; the separate Hardy-type maximal theorem gives 32 under its own stated packing condition. Zero state `v=A=0` is not defined by the printed potential and needs a separate branch. | This is a genuine mechanism to pay an already encoded square/Carleson increment by a telescoping potential. It does not directly pay `m_A m_B/m_C`: no verified mapping from pair masses to `c,f,v` and the required increment is given. It also requires the subtree Carleson inequality as input and a controlled terminal term. Non-nested center cubes, multiple centers, and arbitrary LCA trees are not automatically its binary-tree model. Therefore any use still needs a proved source-pair-to-state mapping and a separately verified subtree packing condition. |
| **N04 summable-error telescope** | If `H_{k+1}≤H_k−d_k+ε_k`, `d_k≥0`, `inf_k H_k>−∞`, and the partial sums `Σ_{k≤m}ε_k` are uniformly bounded above, then `Σd_k≤H_0−inf_k H_k+sup_mΣ_{k≤m}ε_k`. This uses the infimum as a uniform lower bound; it assumes no limit of `H_k` exists. | Useful only after a geometric/entropy argument has supplied the actual `H_k,d_k,ε_k` and a uniform accumulated-error budget. N04 cannot create the pair charge estimate or make scale/tree truncation errors summable. Its reviewed neighboring papers do not supply those missing geometric inputs. |

The Bellman formula is stated above in unambiguous parentheses because an older history entry records a transcription error. Its source-checked form is `4(F−f²/(v+A))`, not `4F−f²/(v+A)`.

## Decision for a proposed source-pair budget

1. **Keep outer and accepted pair measures distinct.** The outer measure is `μ⊗μ`, so coordinate dependence in `f` is irrelevant to the product over the two source points. If a factor `h²` is imposed, keep that accepted joint measure distinct; dropping it is an upper bound only under the established pointwise domination `0≤h²≤1`.
2. **Show mass conservation and the LCA partition.** Verify child masses sum to `m_C`, and every pair is charged exactly once at its first common ancestor. Boundary, root, and zero-mass nodes need explicit conventions.
3. **Match the charge to its existing account.** The established unordered comb account is `F≤W`; its ordered cross-pair cost is `2F≤2W`, and the full local-far bracket including diagonals is bounded by `3W`. Preserve the Astra depth-weighted `τ_d` account's `2ab/m` and `σ` weights when summing it. For an entropy route, additionally bound terminal joint/label entropy. For a Bellman route, identify `α,Λ,F,f,A,v`, verify every subtree Carleson inequality and parent-child increment, and control terminal potential. A new packing estimate is needed only for an unpaid remainder or an E03 application.
4. **Do not claim the fee closed until its growth is paid.** If the intended allowance is `n^{o(1)}` or root-order, report the actual `Λ(n)`, entropy, branching, depth, truncation and boundary fees. A finite-tree identity or a tree having been registered supplies none of those uniform bounds.

## Reading boundary

Read the installed `math-d04-entropy-chain-rule`, `math-e03-tree-bellman-cross-layer-budget`, and `math-n04-summable-error-entropy-descent` entries, their `references/provenance.md`, `references/cube-interface.md`, and each relevant `references/method.md`. Also read E03's `references/papers/EG-P-ee5e7f1d2f3397ce.json` source card and its verification log to retain the corrected Bellman formula. D04 provenance marks the Vigneaux source full-read in the installed audit record; this task relied on that record and the standard-Borel KL chain identity, and did not independently reread the paper. E03 provenance marks the Bellman tree paper full-read in its audit record and identifies its exact tree/Carleson domain; this task relied on the source card and audit record, and did not independently reread the paper. N04's audit confirms its result is only the numerical-sequence telescoping lemma, not a geometric entropy estimate. No external search, paper download, new numerical run, or un-read theorem was used.

## reservoir geometry

## 公开机制与准确范围

原 F2 的 gates 与原 canonical 图，不应被解释为“每一个 receiver 都能直接捕获低 canonical 列来源”。本稿给一个完整审核通过的真实连续来源证明：该逐行单跳要求会失败，而同一来源图仍有显式低列的重分配。重要区别是：原行完全捕获高列来源，并不意味着那些高列无法由其他行先释放。

因此需要区分逐行单跳覆盖、来源侧加权覆盖、允许付费例外的单跳方案、若干跳增广。下文只否定第一个，给同源修复，并计算例外需求的实际价格。没有否定 R102 来源侧覆盖条件，没有证明任意输入的一般有限跳数或根阶容量，也没有下界 operator/Hall 常数。

对任意原 F2 的一条无需新增假设的弱式是：若 x,z 为原 receiver，r 是对 x eligible 且有原 A_rf(x)<λ/2 的 mesh anchor，则
\[
\mu(Q_z\cap Q(x,r))\le\mu(Q(x,r))<\lambda r^n/2,
\quad
\pi_{0,z}(Q(x,r))<\tfrac12(r/L_z)^n. \tag{P0}
\]
当右端大于1时该上界不支付任何改善；当 r≤Lz 时至少半数 z 的捕获来源在 x 的 prefix 外。若 Qz⊂Q(x,r)，则 Lz<2^(−1/n)r；相应立方体包含条件直接给接收点位移排斥。单位 r=1 仅在保留原严格 A1f<λ/2 时纳入；单独 A1f<λ/√n 在 n<4 不可替代该前提。这保留实际 source mass，但 prefix 外不等于低列，不能据此推低储备。没有付费删除、谱隙或 comparator 假设隐藏于此式。

一般任意非负 L1、真实 Lebesgue 接收、全部尺度的一致根阶目标仍 **OPEN**。原 Aold、额外 Cext、unit/mesh、全尺度及强度分层费用保持 R101 ledger/adaptive 原账。私人配方及定量方法负担仅在以下本地部分。

已与sol_geometry对齐totalW近远分类非局部性与修复，独立采用此slab family而不执行几何角色的copies/tent替代构造。本轮认证的有限机制：同一正测度pair/receiver/scale盒上h>0，新增远处分量改变globalW，使该固定贡献先Far后Near；窗口实际Af/h不变，而且receiver盒全尺度真实正超额能量有限并不变。这仅压力globalW-mask的非局部性，非弱型、原F2或Near统一预算反例；κW分母随新增质量增加严格披露。

实际构造：κ=1，f0=(5/4)2^n·1_[−1/4,1/4]^n，B中心(5/16,0,…,0)、halfwidth1/128；B严格在来源外，避免正密度内部receiver导致small-scale无限energy。pair盒中心first坐标±1/8、其余0，halfwidth1/(128n)；L∈[1,1+1/(64n)]。远新增density1/4 slab位于first坐标≥4，质量由下方各阶段固定。B上的smallscale≤7/64不capture；远源首次capture要求L≥471/64，该段f0平均≤1/4、远源平均≤1/4，故不改变全尺度positive excess。窗口Af=(5/4)L^−n(L+1/2−2x1)>1，pair共同capture，体积均精确非零。来源测度fdy真实非原子；不声称分段常数密度f是连续函数。

## 冻结protocol与连续证明

以下固定菜单已于实现前获主代理与独审statement/protocol筛查PASS并实际一次执行。新增weighted修复接口由Astra提供：一般二叉树root depth0，local子节点depth1，σ1=κ/6；将local来源沿x1=0分两个孩子，使选定pair的LCA确为depth1。root local/remote质量不等，不使用balanced corollary。plain localκ分类与weighted σ1分类分别核验，不能混用。

| 阶段 | n | 新总质量W1 | 目的 |
|---|---:|---:|---|
| 初探 | 2 | 2 | 同一正测度pair/window rootFar→rootNear，plain-local仍Far |
| 边界压力 | 3 | 55/32 | 紧贴rootNear阈值的严格正margin，以有理log端点判定，不用float |
| 扩展 | 72 | 16 | 同一rootNear pair也被σ1=κ/6的weighted-local Far剥去；n72由该加权cutoff的显式门要求选择，不拟合维数阶 |

每阶段2个真实非原子source states：f0与f1=f0+g，共3对/6来源状态，无额外输入或refinement。κ=1、q=n、η=1。local mass W0=5/4，local density H=(5/4)2^n on C=[−1/4,1/4]^n。remote g=(1/4)1_G，

G=[4,4+4(W1−5/4)]×[−1/2,1/2]^(n−1)，恰有mass W1−W0，来源真实非原子且有限L1∩L2。

B=Q((5/16,0,…,0),1/64)，volume(1/64)^n；first坐标[39/128,41/128]在C之外。I=[1,Lhi]，Lhi=1+1/(64n)，具有严格正log-scale测度。pair P_−,P_+=Q((∓1/8,0,…,0),1/(64n))，volume各(1/(64n))^n，在C内且分别位于x1<0和x1>0。两pair对全部B×I均被同一receiver cube捕获。该ordered pair贡献不加未经登记的对称因子2。

### 全连续域与能量身份

B×I上remote不capture，且local平均精确为A_L f0=(5/4)L^(−n)(L+1/2−2x1)。取Amin=(5/4)(55/64)Lhi^(−n)>1，hmin=1−1/Amin>0；所有x,y,z,L保留相同完整来源的h，新增前后window Af和h点态相同。

对B，L≤7/64没有local capture；L≥2时local mass bound使A_Lf0<1。任何remote capture要求L≥471/64，此时A_Lf0≤(5/4)(471/64)^(−n)≤1/4，A_Lg≤1/4，故aggregate A≤1/2。于是D_L(f1)=D_L(f0)对B×所有L点态成立，B全尺度能量有限且准确相同。Af本身只在window及remote未capture区域相同，不声称全部尺度Af相同。

真实局部energy E_B=∫B∫D²dL/Ldx的认证bounds为

volume(B)(Amin−1)²·log(Lhi) ≤ E_B(f0)=E_B(f1)
≤ volume(B)(H−1)²·log(128/7)，

上下log均包围，small/large scale尾部全域零由上述capture/mass证明付清。这里R=B只是实际receiver窗口，未验证B属于原障碍Ω补集；若形式上令U=Bc，其体积无穷，不是有偿帽。故E_B不作为原帽返回或Near统一budget反例。

### 分类与实际移动贡献

pair归一化距离d=||y−z||1/L在B×P_−×P_+×I上的范围为

rmin=(1/4−1/(64n))/Lhi >0，rmax=17/64。

global cutoff使用s=log(W/L^n)，t=[s+2log(1+s)−log n]+。旧W0对I的cutoff upper需认证≤0，所以选定pair全部Far。新W1对I的cutoff lower需认证>rmax，所以同一pair全部Near。plain-local仍用W0,κ1，保持Far；weighted-local用W0,σ1=1/6，s_local=log(6W0/L^n)，扩展n72需认证cutoff upper≤0，故同一rootNear pair严格localFar。基准/边界的weighted分类只记录真实区间，不预判修复结果。

选定实际ordered pair/receiver/scale贡献C具有严格正lower：

C≥volume(B)·[H·volume(P_−)]·[H·volume(P_+)]·hmin²·Lhi^(−2n)·log(Lhi)>0。

这是实际双来源正超额核里的正测度贡献，新增前后数值不变，却从global Far转global Near；所有μ、dx、dL/L体积和full-source h保留。global κW分母从5/4增至W1，必须同时报normalized bounds，不能把移动贡献当总预算失败。local树孩子只分拆同一physical source，不新增physical输入。

### 认证算术与输出

全部输入、volume、mass、capture与sign residual使用Fraction。log(x)>0按2幂归一化到z∈[1,2]，以u=(z−1)/(z+1)的atanh级数96项与严格余项2u^(193)/[193(1−u²)]包围；log2同法。最终向外floor/ceil到共同2^160；负2幂指数按端点方向组合。nested log(1+s)用有理s端点+单调性包围，不能以float或同一近似符号判严格margin。所有lower/upper及相应residual写入确定性JSON stdout，计时单独stderr；完整输出入本文件，不增加其他作者文件或临时依赖。

成功仅为各阶段真实来源/receiver/pair/scale全盒严格分类与positive贡献、全尺度E_B有限不变和扩展weighted-local Far证书通过；若残差区间含0，则记录未决且不追加输入/分辨率；不从有限n拟合幂，不声称weak/F2/一般Near budget反例。实际只执行一次已批准完整producer。

## 实际执行、结果与可追溯来源

主代理和独立Sol审核者在实现前完整读取固定statement/protocol，均PASS。主代理明确授权实现并执行一次该固定slab菜单。代码实现后本数值角色实际完整自审再执行；没有执行旧n64、geometry的copies/tent候选、R101/R102 producer或第四阶段。复用几何原理不计为新source；本次的新输入是这里明确列出的六个函数状态。

| 回执 | 实际结果 |
|---|---|
| producer SHA-256 | `1f094702ac7e179716347da289484b706faa4d1bd290d4f71dd32ca7cc74fa7e` |
| deterministic stdout SHA-256 | `0734ecb307dc7e8b644e182aa13a6a8f9def44127734e892a59ad758c52531de` |
| stdout bytes | 47814（含末尾换行） |
| exit code | 0 |
| 本producer内部perf_counter | 0.3442898330004027秒 |
| 本角色子进程外部perf_counter | 0.36524670900053025秒 |
| stderr | 仅`{"runtime_seconds_diagnostic": 0.3442898330004027}\n`，非空 |
| 实际运行次数 | 1，固定完整菜单；没有failed run/refinement或额外输入 |

确定性stdout不包含计时，无字段需要排除。程序不写任何相邻JSON或其他作者文件；完整结果直接存入本报告下方。没有instrumented assertion counter，报告不编造断言数量或sample数。

主代理已另行隔离复制重放一次，`parent_numeric_receipt.json`记exit0、外0.36495366700000886秒、stderr仅内计时0.34458591699967656秒；确定性stdout仍为47814字节，SHA`0734ecb307dc7e8b644e182aa13a6a8f9def44127734e892a59ad758c52531de`，与本producer归档输出精确一致。本角色实际读取该父回执，但未执行这次重放；其耗时不是本producer耗时。同码重放不增加这六个输入、三个证书或本作者一次生产记录，JSON additional_inputs_or_runs=0是本固定producer菜单内的计数。

### 真实来源数、全连续体积与尺度账

最终3个source-state pairs、6个实际非原子L1∩L2函数状态、3份B×P_−×P_+×I完整证书。每阶段的f0只包含local component，f1包含同local component加新增remote density slab；component和树child不是额外physical inputs。n72没有做72维receiver grid或tensor marginal采样，所有体积是实际n次宽度，连续capture和符号残差从完整盒端点与解析积分严格推出。source pair质量为H·volume(P)；双来源使用同一full-source h，未偷换成独立posterior。

冻结三阶段均PASS，无UNKNOWN或追加菜单。实际分类为：

| 阶段 | n | baseline global | added global | plain-local | depth1 weighted-local σ=1/6 |
|---|---:|---|---|---|
| 初探 | 2 | Far | Near | Far | Near |
| 边界压力 | 3 | Far | Near | Far | Near |
| 扩展参数 | 72 | Far | Near | Far | Far |

加权修复仅在n72的这份菜单认证了选定pair为Far；不能把n2/n3 plain-local Far转写成weighted Far。root将local/remote分成两个质量不等的孩子，local节点再沿x1=0分成两个mass5/8孩子，pair真实LCA为depth1。因此使用的是一般非平衡二叉树接口，不是balanced-tree corollary。整个计算保留f1的κ=1能量门h，σ1=1/6只用于局部分类型阈值。

下表小数仅供阅读，严格判断全部依据下方有理端点：

| n | Af lower | h lower | 新global Near严格margin lower | weighted原cutoff表达式upper |
|---:|---:|---:|---:|---:|
| 2 | 1.05762874827 | 0.05448863636 | 0.75351873357 | 3.52889116799 |
| 3 | 1.05760741638 | 0.05446956545 | 0.00709222635128 | 3.12342605988 |
| 72 | 1.05756632470 | 0.05443282691 | 0.86189742182 | −0.0546277704654 |

n3的正strict lower认证完整尺度窗，而非在某一个L采样得符号。n72 weighted表达式upper<0，所以正部cutoff严格认证为0；pair距离lower>0，故Far。对应的ordered pair贡献上下界均严格正且有限；精确端点可长达数百位，保留在JSON，未用浮点小数决定正性。

### 精确身份与积分证书的区别

窗口Af是精确公式；E_B(f1)=E_B(f0)和C_pair(f1)=C_pair(f0)是解析点态/积分身份。JSON中的energy/contribution intervals是方向正确的有理+log上下证书，不是实际能量精确积分值，也不是优化过的帽能量。E_B lower利用完整窗口的真实positive excess；upper利用整个有效尺度范围[7/64,2]及密度界H，可能很粗，作用是证明有限性。两处small/large tail在全B上均为零；新增remote首次能capture时full average≤1/2，不能误称Af在所有尺度不变。

固定ordered pair贡献使用μ(P_−)μ(P_+)·volume(B)·log(Lhi)，没有省略n维体积、scale logarithm或擅加对称factor2。旧global分类把它列入Far，新global列入Near，plain-local及n72weighted-local将该global-near贡献归入局部far。这只显示global mass标号的非局部性和有限菜单里的修复信息，不否定已证global Far预算，也不证明一般局部Near joint budget。

κW分母增加同样严格记录。相同E_B和C_pair除新κW的归一化值相对旧值分别乘：
n2为5/8，n3为8/11，n72为5/64。因而“Near贡献被改名”不能直接推出归一化能量增长或弱界失败。

### 假设、资格和全部费用边界

来源fdy是真实Lebesgue非原子正测度；f本身为分段常密度，不谎称是continuous density function。所有source质量、receiver/pair volume及source interfaces明确；这不是抽象posterior、原子或零measure pair。B在local source支撑外，但**未认证B在原R100障碍帽外**；formal U=Bc为无限体积，不提供paid-cap证书。没有原F2 earliest/gates、Hall下界、弱常数下界或一般Near failure。

globalW、局部W0、κ和σ1分别保留；q=n、η=1没有隐藏费用。log对数96项正级数余项和外向2^160舍入共同包住端点；nested logs使用单调有理区间，负指数的log2组合保持正确方向。体积与尺度的全部费用都在bounds里，n72只检验weighted门，不拟合n幂。finite partition/一般树的uniform Far付款来自理论角色的已证命题，本producer只检验这组真实机制及局部标签，不能把条件接口/有限证书写成一般估计已付。

### 复现及独立审核

```sh
python3 numeric.py  # 先提取本报告末尾 Python 代码
```

stdout应是下方47814字节确定性JSON；计时只在stderr，值随运行变化。复现同一程序是复制重放，不是新physical input或另一积分算法。截止本报告保存，code与完整report已发送独立Sol审核实际读取；其读后回执须分开登记，statement PASS不冒充code/result full-read。

## 完整确定性stdout

```json
{
  "arithmetic": {
    "inputs_volumes_masses": "exact Fraction",
    "log_outward_grid_denominator": "1461501637330902918203684832716283019655932542976",
    "log_tail": "2*z^(193)/(193*(1-z^2)), z=(x-1)/(x+1) after dyadic normalization",
    "log_terms": 96,
    "nested_logs": "monotone rational endpoints; no float sign decisions"
  },
  "counts": {
    "actual_nonatomic_source_states": 6,
    "actual_source_state_pairs": 3,
    "additional_inputs_or_runs": 0,
    "full_continuum_receiver_pair_scale_certificates": 3,
    "global_far_to_near_switches": 3,
    "plain_local_far_repairs": 3,
    "weighted_local_far_repairs": 1
  },
  "menu_rule": "fixed three stages; n72 selected to test depth-one sigma=1/6, no dimension-power fit or adaptive additions",
  "publication": "PUBLIC independent new density-box construction; no historical private recipes",
  "records": [
    {
      "all_scale_energy_identity_on_B": {
        "D_f1_equals_D_f0_pointwise": true,
        "added_energy_over_kappa_W": {
          "lower": "5230046968126897101945267840679978437741720280735135/1657746407407168661259353082641597028001793919150367677874176",
          "upper": "4247299306154451752105966249668107302729073887145/748288838313422294120286634350736906063837462003712"
        },
        "aggregate_A_above_remote_first_capture_upper": "242321/887364",
        "average_itself_not_identical_on_all_scales": true,
        "baseline_energy_over_kappa_W": {
          "lower": "1046009393625379420389053568135995687548344056147027/207218300925896082657419135330199628500224239893795959734272",
          "upper": "849459861230890350421193249933621460545814777429/93536104789177786765035829293842113257979682750464"
        },
        "common_finite_energy_interval": {
          "lower": "5230046968126897101945267840679978437741720280735135/828873203703584330629676541320798514000896959575183838937088",
          "upper": "4247299306154451752105966249668107302729073887145/374144419156711147060143317175368453031918731001856"
        },
        "local_mass_kills_positive_excess_at_and_above": "2",
        "log_finite_energy_scale_range": {
          "lower": "530912413269306469013245781208513412841134235893/182687704666362864775460604089535377456991567872",
          "upper": "4247299306154451752105966249668107302729073887145/1461501637330902918203684832716283019655932542976"
        },
        "remote_first_possible_capture_L": "471/64",
        "small_scale_no_local_capture_until": "7/64"
      },
      "certificate_status": "PASS",
      "classification": {
        "added_global": {
          "classification": "ALL_NEAR",
          "classification_threshold": "1",
          "eta": "1",
          "far_strict_residual_lower": "-153253019026177768486323131485385281355787825514799/188533711215686476448275343420400509535615298043904",
          "mass": "2",
          "near_strict_residual_lower": "1101268862872903826693428307395415690938384147859/1461501637330902918203684832716283019655932542976",
          "positive_part_cutoff": {
            "lower": "1489480235288924914341282091085678368034491229587/1461501637330902918203684832716283019655932542976",
            "upper": "1539221471189424487989436909299147712907920421295/1461501637330902918203684832716283019655932542976"
          },
          "q": "2",
          "raw_cutoff_expression": {
            "lower": "1489480235288924914341282091085678368034491229587/1461501637330902918203684832716283019655932542976",
            "upper": "1539221471189424487989436909299147712907920421295/1461501637330902918203684832716283019655932542976"
          },
          "s_interval": {
            "lower": "123786064662956797763758487747527352550869671253/182687704666362864775460604089535377456991567872",
            "upper": "1013035739299659071135698605846798551586536899367/1461501637330902918203684832716283019655932542976"
          }
        },
        "baseline_global": {
          "classification": "ALL_FAR",
          "classification_threshold": "1",
          "eta": "1",
          "far_strict_residual_lower": "31/129",
          "mass": "5/4",
          "near_strict_residual_lower": "-17/64",
          "positive_part_cutoff": {
            "lower": "0",
            "upper": "0"
          },
          "q": "2",
          "raw_cutoff_expression": {
            "lower": "-158327986657318732578094559248711415752980355175/1461501637330902918203684832716283019655932542976",
            "upper": "-98147400920641963413634441743570670543769950923/1461501637330902918203684832716283019655932542976"
          },
          "s_interval": {
            "lower": "151688721804772611348192730007296367101094643963/730750818665451459101842416358141509827966271488",
            "upper": "326124665605549911722016163881172465381768817269/1461501637330902918203684832716283019655932542976"
          }
        },
        "plain_local_cluster": {
          "classification": "ALL_FAR",
          "classification_threshold": "1",
          "eta": "1",
          "far_strict_residual_lower": "31/129",
          "mass": "5/4",
          "near_strict_residual_lower": "-17/64",
          "positive_part_cutoff": {
            "lower": "0",
            "upper": "0"
          },
          "q": "2",
          "raw_cutoff_expression": {
            "lower": "-158327986657318732578094559248711415752980355175/1461501637330902918203684832716283019655932542976",
            "upper": "-98147400920641963413634441743570670543769950923/1461501637330902918203684832716283019655932542976"
          },
          "s_interval": {
            "lower": "151688721804772611348192730007296367101094643963/730750818665451459101842416358141509827966271488",
            "upper": "326124665605549911722016163881172465381768817269/1461501637330902918203684832716283019655932542976"
          }
        },
        "weighted_local_cluster": {
          "classification": "ALL_NEAR",
          "classification_threshold": "1/6",
          "eta": "1",
          "far_strict_residual_lower": "-620008397620290589537296168075904030193114891039327/188533711215686476448275343420400509535615298043904",
          "mass": "5/4",
          "near_strict_residual_lower": "4731392687501998357912467570030136242902187597505/1461501637330902918203684832716283019655932542976",
          "positive_part_cutoff": {
            "lower": "5119604059918019445560321353720398919998294679233/1461501637330902918203684832716283019655932542976",
            "upper": "5157480219980996744198530216202393827925959688927/1461501637330902918203684832716283019655932542976"
          },
          "q": "2",
          "raw_cutoff_expression": {
            "lower": "5119604059918019445560321353720398919998294679233/1461501637330902918203684832716283019655932542976",
            "upper": "5157480219980996744198530216202393827925959688927/1461501637330902918203684832716283019655932542976"
          },
          "s_interval": {
            "lower": "1461018420794748584898253142152149169668299131899/730750818665451459101842416358141509827966271488",
            "upper": "2944784063585501858822136988170878070516177793141/1461501637330902918203684832716283019655932542976"
          }
        }
      },
      "eta": "1",
      "kappa": "1",
      "n": 2,
      "ordered_source_pair": {
        "both_boxes_captured_everywhere_on_B_times_I": true,
        "center_others": "0",
        "each_mass": "5/16384",
        "each_volume": "1/16384",
        "half_width": "1/256",
        "negative_center_first": "-1/8",
        "normalized_l1_distance": {
          "lower": "31/129",
          "upper": "17/64"
        },
        "ordered_only_no_extra_factor_two": true,
        "positive_center_first": "1/8"
      },
      "q": "2",
      "receiver_B": {
        "center_first": "5/16",
        "center_others": "0",
        "first_interval": [
          "39/128",
          "41/128"
        ],
        "formal_U_B_complement_has_infinite_volume_not_paid_cap": true,
        "half_width": "1/128",
        "not_qualified_as_original_obstacle_complement": true,
        "volume": "1/4096"
      },
      "same_actual_window_average": {
        "exact_formula": "(5/4)*L^(-n)*(L+1/2-2*x1)",
        "full_source_h_lower": "959/17600",
        "interval": {
          "lower": "17600/16641",
          "upper": "575/512"
        },
        "remote_capture_zero_on_window": true
      },
      "same_positive_ordered_pair_window_contribution": {
        "actual_contribution_equal_in_both_states": true,
        "added_global_assignment": "ALL_NEAR",
        "baseline_global_assignment": "ALL_FAR",
        "contribution_over_added_kappa_W": {
          "lower": "1046009393625379420389053568135995687548344056147027/4108028217267556516093577687032488763150685475168143135186438062080",
          "upper": "284340274950058612820383798332246639744744116775/3213876088517980551083924184682325205044405987565585670602752"
        },
        "contribution_over_baseline_kappa_W": {
          "lower": "1046009393625379420389053568135995687548344056147027/2567517635792222822558486054395305476969178421980089459491523788800",
          "upper": "56868054990011722564076759666449327948948823355/401734511064747568885490523085290650630550748445698208825344"
        },
        "interval": {
          "lower": "1046009393625379420389053568135995687548344056147027/2054014108633778258046788843516244381575342737584071567593219031040",
          "upper": "284340274950058612820383798332246639744744116775/1606938044258990275541962092341162602522202993782792835301376"
        },
        "plain_local_assignment": "ALL_FAR",
        "weighted_local_assignment": "ALL_NEAR"
      },
      "scale_window": {
        "L_lower": "1",
        "L_upper": "129/128",
        "log_measure": {
          "lower": "5686805499001172256407675966644932794894882335/730750818665451459101842416358141509827966271488",
          "upper": "11373610998002344512815351933289865589789764671/1461501637330902918203684832716283019655932542976"
        }
      },
      "scope": "Real non-atomic source mechanism pressure and local-cut repair only; no paid obstacle cap, F2 or weak/Near budget counterexample.",
      "source_states": {
        "added_f1": {
          "W": "2",
          "components": [
            {
              "density": "5",
              "density_function_continuous": false,
              "first_coordinate_interval": [
                "-1/4",
                "1/4"
              ],
              "mass": "5/4",
              "other_coordinate_interval": [
                "-1/4",
                "1/4"
              ],
              "type": "actual density times axis-box indicator; Lebesgue non-atomic",
              "volume": "1/4"
            },
            {
              "density": "1/4",
              "density_function_continuous": false,
              "first_coordinate_interval": [
                "4",
                "7"
              ],
              "mass": "3/4",
              "other_coordinate_interval": [
                "-1/2",
                "1/2"
              ],
              "type": "actual density times axis-box indicator; Lebesgue non-atomic",
              "volume": "3"
            }
          ]
        },
        "baseline_f0": {
          "W": "5/4",
          "components": [
            {
              "density": "5",
              "density_function_continuous": false,
              "first_coordinate_interval": [
                "-1/4",
                "1/4"
              ],
              "mass": "5/4",
              "other_coordinate_interval": [
                "-1/4",
                "1/4"
              ],
              "type": "actual density times axis-box indicator; Lebesgue non-atomic",
              "volume": "1/4"
            }
          ]
        }
      },
      "stage": "pilot",
      "tree_qualification": {
        "full_f1_h_retained_not_child_h": true,
        "local_children": "f0 restricted to x1<0 and x1>=0, each mass5/8",
        "local_node_depth": 1,
        "not_balanced_tree_corollary": true,
        "ordered_pair_LCA_is_local_depth_one": true,
        "root_local_vs_remote": "actual non-balanced binary tree",
        "sigma_at_local_node": "1/6"
      }
    },
    {
      "all_scale_energy_identity_on_B": {
        "D_f1_equals_D_f0_pointwise": true,
        "added_energy_over_kappa_W": {
          "lower": "1302177536999036820594309502511900075922592037382234205859/34032652041241811238663677164822170070713007049902549225769994813440",
          "upper": "68806248759702118384116653244623338304210996971749/131698835543162323765170447645729695467235393312653312"
        },
        "aggregate_A_above_remote_first_capture_upper": "105797831/417948444",
        "average_itself_not_identical_on_all_scales": true,
        "baseline_energy_over_kappa_W": {
          "lower": "1302177536999036820594309502511900075922592037382234205859/24751019666357680900846310665325214596882186945383672164196359864320",
          "upper": "68806248759702118384116653244623338304210996971749/95780971304118053647396689196894323976171195136475136"
        },
        "common_finite_energy_interval": {
          "lower": "1302177536999036820594309502511900075922592037382234205859/19800815733086144720677048532260171677505749556306937731357087891456",
          "upper": "344031243798510591920583266223116691521054984858745/383123885216472214589586756787577295904684780545900544"
        },
        "local_mass_kills_positive_excess_at_and_above": "2",
        "log_finite_energy_scale_range": {
          "lower": "530912413269306469013245781208513412841134235893/182687704666362864775460604089535377456991567872",
          "upper": "4247299306154451752105966249668107302729073887145/1461501637330902918203684832716283019655932542976"
        },
        "remote_first_possible_capture_L": "471/64",
        "small_scale_no_local_capture_until": "7/64"
      },
      "certificate_status": "PASS",
      "classification": {
        "added_global": {
          "classification": "ALL_NEAR",
          "classification_threshold": "1",
          "eta": "1",
          "far_strict_residual_lower": "-9181348293892901551957055921893305764235799866063/141034908002432131606655586357121311396797490397184",
          "mass": "55/32",
          "near_strict_residual_lower": "5182650212356726387503210260905683260195874655/730750818665451459101842416358141509827966271488",
          "positive_part_cutoff": {
            "lower": "199288336420367270211430102106037021808249415519/730750818665451459101842416358141509827966271488",
            "upper": "225526615394658653521987821195471278373835308943/730750818665451459101842416358141509827966271488"
          },
          "q": "3",
          "raw_cutoff_expression": {
            "lower": "199288336420367270211430102106037021808249415519/730750818665451459101842416358141509827966271488",
            "upper": "225526615394658653521987821195471278373835308943/730750818665451459101842416358141509827966271488"
          },
          "s_interval": {
            "lower": "96096076866857279214150046947863792580348803193/182687704666362864775460604089535377456991567872",
            "upper": "791545315049423362709833251124897054887976832821/1461501637330902918203684832716283019655932542976"
          }
        },
        "baseline_global": {
          "classification": "ALL_FAR",
          "classification_threshold": "1",
          "eta": "1",
          "far_strict_residual_lower": "47/193",
          "mass": "5/4",
          "near_strict_residual_lower": "-17/64",
          "positive_part_cutoff": {
            "lower": "0",
            "upper": "0"
          },
          "q": "3",
          "raw_cutoff_expression": {
            "lower": "-93874275800032874472756440302311724541376142503/182687704666362864775460604089535377456991567872",
            "upper": "-345367660150637884121179027169839586252552564031/730750818665451459101842416358141509827966271488"
          },
          "s_interval": {
            "lower": "37918495686373097840672911042398218892072801249/182687704666362864775460604089535377456991567872",
            "upper": "326124665605549911722016163881172465381768817269/1461501637330902918203684832716283019655932542976"
          }
        },
        "plain_local_cluster": {
          "classification": "ALL_FAR",
          "classification_threshold": "1",
          "eta": "1",
          "far_strict_residual_lower": "47/193",
          "mass": "5/4",
          "near_strict_residual_lower": "-17/64",
          "positive_part_cutoff": {
            "lower": "0",
            "upper": "0"
          },
          "q": "3",
          "raw_cutoff_expression": {
            "lower": "-93874275800032874472756440302311724541376142503/182687704666362864775460604089535377456991567872",
            "upper": "-345367660150637884121179027169839586252552564031/730750818665451459101842416358141509827966271488"
          },
          "s_interval": {
            "lower": "37918495686373097840672911042398218892072801249/182687704666362864775460604089535377456991567872",
            "upper": "326124665605549911722016163881172465381768817269/1461501637330902918203684832716283019655932542976"
          }
        },
        "weighted_local_cluster": {
          "classification": "ALL_NEAR",
          "classification_threshold": "1/6",
          "eta": "1",
          "far_strict_residual_lower": "-203083409265329402535699871839586941496835925313803/70517454001216065803327793178560655698398745198592",
          "mass": "5/4",
          "near_strict_residual_lower": "517344454190625371370704240340055962985044029289/182687704666362864775460604089535377456991567872",
          "positive_part_cutoff": {
            "lower": "565870875742628007326685963301338797622057414505/182687704666362864775460604089535377456991567872",
            "upper": "1141223075150090734842451650901571331491156127947/365375409332725729550921208179070754913983135744"
          },
          "q": "3",
          "raw_cutoff_expression": {
            "lower": "565870875742628007326685963301338797622057414505/182687704666362864775460604089535377456991567872",
            "upper": "1141223075150090734842451650901571331491156127947/365375409332725729550921208179070754913983135744"
          },
          "s_interval": {
            "lower": "365250920433867091228188014078611419533873923233/182687704666362864775460604089535377456991567872",
            "upper": "2944784063585501858822136988170878070516177793141/1461501637330902918203684832716283019655932542976"
          }
        }
      },
      "eta": "1",
      "kappa": "1",
      "n": 3,
      "ordered_source_pair": {
        "both_boxes_captured_everywhere_on_B_times_I": true,
        "center_others": "0",
        "each_mass": "5/3538944",
        "each_volume": "1/7077888",
        "half_width": "1/384",
        "negative_center_first": "-1/8",
        "normalized_l1_distance": {
          "lower": "47/193",
          "upper": "17/64"
        },
        "ordered_only_no_extra_factor_two": true,
        "positive_center_first": "1/8"
      },
      "q": "3",
      "receiver_B": {
        "center_first": "5/16",
        "center_others": "0",
        "first_interval": [
          "39/128",
          "41/128"
        ],
        "formal_U_B_complement_has_infinite_volume_not_paid_cap": true,
        "half_width": "1/128",
        "not_qualified_as_original_obstacle_complement": true,
        "volume": "1/262144"
      },
      "same_actual_window_average": {
        "exact_formula": "(5/4)*L^(-n)*(L+1/2-2*x1)",
        "full_source_h_lower": "414143/7603200",
        "interval": {
          "lower": "7603200/7189057",
          "upper": "215/192"
        },
        "remote_capture_zero_on_window": true
      },
      "same_positive_ordered_pair_window_contribution": {
        "actual_contribution_equal_in_both_states": true,
        "added_global_assignment": "ALL_NEAR",
        "baseline_global_assignment": "ALL_FAR",
        "contribution_over_added_kappa_W": {
          "lower": "1302177536999036820594309502511900075922592037382234205859/19673816785917699211600096782134796614156442919664706942769204248567670112256000",
          "upper": "3163430571467379027310121603053710311831445455/137451052553736992208757269530493684369339155276204967960338497536"
        },
        "contribution_over_baseline_kappa_W": {
          "lower": "1302177536999036820594309502511900075922592037382234205859/14308230389758326699345524932461670264841049396119786867468512180776487354368000",
          "upper": "3163430571467379027310121603053710311831445455/99964401857263267060914377840359043177701203837239976698427998208"
        },
        "interval": {
          "lower": "1302177536999036820594309502511900075922592037382234205859/11446584311806661359476419945969336211872839516895829493974809744621189883494400",
          "upper": "15817152857336895136550608015268551559157227275/399857607429053068243657511361436172710804815348959906793711992832"
        },
        "plain_local_assignment": "ALL_FAR",
        "weighted_local_assignment": "ALL_NEAR"
      },
      "scale_window": {
        "L_lower": "1",
        "L_upper": "193/192",
        "log_measure": {
          "lower": "7592233371521709665544291847328904748395469091/1461501637330902918203684832716283019655932542976",
          "upper": "1898058342880427416386072961832226187098867273/365375409332725729550921208179070754913983135744"
        }
      },
      "scope": "Real non-atomic source mechanism pressure and local-cut repair only; no paid obstacle cap, F2 or weak/Near budget counterexample.",
      "source_states": {
        "added_f1": {
          "W": "55/32",
          "components": [
            {
              "density": "10",
              "density_function_continuous": false,
              "first_coordinate_interval": [
                "-1/4",
                "1/4"
              ],
              "mass": "5/4",
              "other_coordinate_interval": [
                "-1/4",
                "1/4"
              ],
              "type": "actual density times axis-box indicator; Lebesgue non-atomic",
              "volume": "1/8"
            },
            {
              "density": "1/4",
              "density_function_continuous": false,
              "first_coordinate_interval": [
                "4",
                "47/8"
              ],
              "mass": "15/32",
              "other_coordinate_interval": [
                "-1/2",
                "1/2"
              ],
              "type": "actual density times axis-box indicator; Lebesgue non-atomic",
              "volume": "15/8"
            }
          ]
        },
        "baseline_f0": {
          "W": "5/4",
          "components": [
            {
              "density": "10",
              "density_function_continuous": false,
              "first_coordinate_interval": [
                "-1/4",
                "1/4"
              ],
              "mass": "5/4",
              "other_coordinate_interval": [
                "-1/4",
                "1/4"
              ],
              "type": "actual density times axis-box indicator; Lebesgue non-atomic",
              "volume": "1/8"
            }
          ]
        }
      },
      "stage": "boundary_pressure",
      "tree_qualification": {
        "full_f1_h_retained_not_child_h": true,
        "local_children": "f0 restricted to x1<0 and x1>=0, each mass5/8",
        "local_node_depth": 1,
        "not_balanced_tree_corollary": true,
        "ordered_pair_LCA_is_local_depth_one": true,
        "root_local_vs_remote": "actual non-balanced binary tree",
        "sigma_at_local_node": "1/6"
      }
    },
    {
      "all_scale_energy_identity_on_B": {
        "D_f1_equals_D_f0_pointwise": true,
        "added_energy_over_kappa_W": {
          "lower": "3148888781490371821421744275391259103823656041597863692375337284316302727393002074521143337613536364264320691577949458049220905649503147091446071777454493788043175032356205752415390885869847996523167007102976892485543359204364867002774456322125947197197511156727095049219608803844828389832250552525756710964862678623102995051309805798241768205187791335266737487392206646599972757734576573070836849892848801661769714329756417997295745119009459019193009948266943988867731087014282213878526700688630390262313527434283654167065007680717315240448785921871078512523810077601/777066193659301332169041910868370052896142536747739890143958631521556942127756501638869437079365938131053758021077603461847818090728053542504145646377047577393901970968524316261008958109949553192362027592925830689840690974850223451921211011701444357517545493687708220636036785499434115164869952249212646044225289456957937083022173256906702670674237336733961308242301033162155840799279993703587190284707538799038302359272948796047132923067828633187430026418194978496400630765383685528826616549295794216611542552824264743661235766678540930089794683466851783990999717707657318225005597686907675048380643696509738751221471097629161404637989461073651452595786189310203378976156664021467896346233974402974744576",
          "upper": "147996780638197401653034176891824097782977073415335538023924371406801721799045444351424530345/259344723055062059907025491480697571938277889515152306249728583105665800713306759149981690559193987143012367913206299323899696942213235956742929677132122730441323862712594345230336"
        },
        "aggregate_A_above_remote_first_capture_upper": "2867512457318543690577128553204717064186396573081006117625673040745950468840157474769512336873161815617734302571412455478607488646063080936765931878553402481477499280386934313106365089044230721/11470049829274174762308514212818868256745586292324024470502691941170226345695441132804914616045950987555971180220323808276063505414547699297013884316261121594743749330250860340139714038244296964",
        "average_itself_not_identical_on_all_scales": true,
        "baseline_energy_over_kappa_W": {
          "lower": "3148888781490371821421744275391259103823656041597863692375337284316302727393002074521143337613536364264320691577949458049220905649503147091446071777454493788043175032356205752415390885869847996523167007102976892485543359204364867002774456322125947197197511156727095049219608803844828389832250552525756710964862678623102995051309805798241768205187791335266737487392206646599972757734576573070836849892848801661769714329756417997295745119009459019193009948266943988867731087014282213878526700688630390262313527434283654167065007680717315240448785921871078512523810077601/60708296379632916575706399286591410382511135683417178917496768087621636103730976690536674771825463916488574845396687770456860788338129183008136378623206841983898591481915962207891324852339808843153283405697330522643803982410173707181344610289175340431058241694352204737190373867143290247255465019469737972205100738824838834611107285695836146146424791932340727206429768215793425062443749508092749240992776468674867371818199124691182259614674111967767970813921482695031299278545600431939579417913733923172776761939395683098534044271761010163265209645847795624296852945910727986328562319289662113154737788789823339939177429502278234737342926646379019734045796039859638982512239376677179402049529250232401920",
          "upper": "29599356127639480330606835378364819556595414683067107604784874281360344359809088870284906069/4052261297735344686047273304385899561535592023674254785152009111026028136145418111718463914987406049109568248643848426935932764722081811824108276205189417663145685354884286644224"
        },
        "common_finite_energy_interval": {
          "lower": "3148888781490371821421744275391259103823656041597863692375337284316302727393002074521143337613536364264320691577949458049220905649503147091446071777454493788043175032356205752415390885869847996523167007102976892485543359204364867002774456322125947197197511156727095049219608803844828389832250552525756710964862678623102995051309805798241768205187791335266737487392206646599972757734576573070836849892848801661769714329756417997295745119009459019193009948266943988867731087014282213878526700688630390262313527434283654167065007680717315240448785921871078512523810077601/48566637103706333260565119429273128306008908546733743133997414470097308882984781352429339817460371133190859876317350216365488630670503346406509102898565473587118873185532769766313059881871847074522626724557864418115043185928138965745075688231340272344846593355481763789752299093714632197804372015575790377764080591059871067688885828556668916917139833545872581765143814572634740049954999606474199392794221174939893897454559299752945807691739289574214376651137186156025039422836480345551663534330987138538221409551516546478827235417408808130612167716678236499437482356728582389062849855431729690523790231031858671951341943601822587789874341317103215787236636831887711186009791501341743521639623400185921536",
          "upper": "147996780638197401653034176891824097782977073415335538023924371406801721799045444351424530345/16209045190941378744189093217543598246142368094697019140608036444104112544581672446873855659949624196438272994575393707743731058888327247296433104820757670652582741419537146576896"
        },
        "local_mass_kills_positive_excess_at_and_above": "2",
        "log_finite_energy_scale_range": {
          "lower": "530912413269306469013245781208513412841134235893/182687704666362864775460604089535377456991567872",
          "upper": "4247299306154451752105966249668107302729073887145/1461501637330902918203684832716283019655932542976"
        },
        "remote_first_possible_capture_L": "471/64",
        "small_scale_no_local_capture_until": "7/64"
      },
      "certificate_status": "PASS",
      "classification": {
        "added_global": {
          "classification": "ALL_NEAR",
          "classification_threshold": "1",
          "eta": "1",
          "far_strict_residual_lower": "-3037009270577374672349986760119133822560058120708275/3368030523229065775000391696994674218797096545288192",
          "mass": "16",
          "near_strict_residual_lower": "629832246599227513419999607143918991896835987747/730750818665451459101842416358141509827966271488",
          "positive_part_cutoff": {
            "lower": "823937932807238057243926498989050330444889528611/730750818665451459101842416358141509827966271488",
            "upper": "841419714224627750439619739932166348529409264307/730750818665451459101842416358141509827966271488"
          },
          "q": "72",
          "raw_cutoff_expression": {
            "lower": "823937932807238057243926498989050330444889528611/730750818665451459101842416358141509827966271488",
            "upper": "841419714224627750439619739932166348529409264307/730750818665451459101842416358141509827966271488"
          },
          "s_interval": {
            "lower": "4029309471617490104906484734174666876952321641801/1461501637330902918203684832716283019655932542976",
            "upper": "2026071478599318142271397211693597103173073798733/730750818665451459101842416358141509827966271488"
          }
        },
        "baseline_global": {
          "classification": "ALL_FAR",
          "classification_threshold": "1",
          "eta": "1",
          "far_strict_residual_lower": "1151/4609",
          "mass": "5/4",
          "near_strict_residual_lower": "-17/64",
          "positive_part_cutoff": {
            "lower": "0",
            "upper": "0"
          },
          "q": "72",
          "raw_cutoff_expression": {
            "lower": "-5395875919959001153601855548026240504471919311203/1461501637330902918203684832716283019655932542976",
            "upper": "-5335466196880545857613876090322981880812587902667/1461501637330902918203684832716283019655932542976"
          },
          "s_interval": {
            "lower": "75822795006100933021426618667161283996985715401/365375409332725729550921208179070754913983135744",
            "upper": "326124665605549911722016163881172465381768817269/1461501637330902918203684832716283019655932542976"
          }
        },
        "plain_local_cluster": {
          "classification": "ALL_FAR",
          "classification_threshold": "1",
          "eta": "1",
          "far_strict_residual_lower": "1151/4609",
          "mass": "5/4",
          "near_strict_residual_lower": "-17/64",
          "positive_part_cutoff": {
            "lower": "0",
            "upper": "0"
          },
          "q": "72",
          "raw_cutoff_expression": {
            "lower": "-5395875919959001153601855548026240504471919311203/1461501637330902918203684832716283019655932542976",
            "upper": "-5335466196880545857613876090322981880812587902667/1461501637330902918203684832716283019655932542976"
          },
          "s_interval": {
            "lower": "75822795006100933021426618667161283996985715401/365375409332725729550921208179070754913983135744",
            "upper": "326124665605549911722016163881172465381768817269/1461501637330902918203684832716283019655932542976"
          }
        },
        "weighted_local_cluster": {
          "classification": "ALL_FAR",
          "classification_threshold": "1/6",
          "eta": "1",
          "far_strict_residual_lower": "1151/4609",
          "mass": "5/4",
          "near_strict_residual_lower": "-17/64",
          "positive_part_cutoff": {
            "lower": "0",
            "upper": "0"
          },
          "q": "72",
          "raw_cutoff_expression": {
            "lower": "-117858521928726566329101789455931342668585053333/1461501637330902918203684832716283019655932542976",
            "upper": "-79838575978907150001711432377017382342858262817/1461501637330902918203684832716283019655932542976"
          },
          "s_interval": {
            "lower": "730487644501088919796456824739587685280587959369/365375409332725729550921208179070754913983135744",
            "upper": "2944784063585501858822136988170878070516177793141/1461501637330902918203684832716283019655932542976"
          }
        }
      },
      "eta": "1",
      "kappa": "1",
      "n": 72,
      "ordered_source_pair": {
        "both_boxes_captured_everywhere_on_B_times_I": true,
        "center_others": "0",
        "each_mass": "5/502109193657962595992742625942541917155438466412525665761805931514943387806218303337240256333967349824783385010854569571127062051220469019264829598755921559342816313242106658715560486402352689178243284238256657126524480336670925770019269771264",
        "each_volume": "1/592785906717766598185810105431951795414448364190518200632546681966866631662701527590193261483989115892343120941905340133475604557019650759499480114118595787022202261339358568559820683158501311348921978936478946820730304564913459583102144332107870395879188580007936",
        "half_width": "1/9216",
        "negative_center_first": "-1/8",
        "normalized_l1_distance": {
          "lower": "1151/4609",
          "upper": "17/64"
        },
        "ordered_only_no_extra_factor_two": true,
        "positive_center_first": "1/8"
      },
      "q": "72",
      "receiver_B": {
        "center_first": "5/16",
        "center_others": "0",
        "first_interval": [
          "39/128",
          "41/128"
        ],
        "formal_U_B_complement_has_infinite_volume_not_paid_cap": true,
        "half_width": "1/128",
        "not_qualified_as_original_obstacle_complement": true,
        "volume": "1/11090678776483259438313656736572334813745748301503266300681918322458485231222502492159897624416558312389564843845614287315896631296"
      },
      "same_actual_window_average": {
        "exact_formula": "(5/4)*L^(-n)*(L+1/2-2*x1)",
        "full_source_h_lower": "3151075454623424189333285709781094774729093464299120797623919793027183537284021947721906993935708088616016032186569643368757038127181100554940115046028183611771905709661135075595436262193702004683829078436758643099066725285260973198075833353031080452231020430429/57889248702906894354083018108589042520942223065480293030522136910826819498310696053729810691795812098861632904482943372409727007521450269482371104894394119826386939583921735210919988589697393686418162005515522150461943805167330037412318782432409218347577009766400",
        "interval": {
          "lower": "57889248702906894354083018108589042520942223065480293030522136910826819498310696053729810691795812098861632904482943372409727007521450269482371104894394119826386939583921735210919988589697393686418162005515522150461943805167330037412318782432409218347577009766400/54738173248283470164749732398807947746213129601181172232898217117799635961026674106007903697860104010245616872296373729040969969394269168927430989848365936214615033874260600135324552327503691681734332927078763507362877079882069064214242949079378137895345989335971",
          "upper": "20525/18432"
        },
        "remote_capture_zero_on_window": true
      },
      "same_positive_ordered_pair_window_contribution": {
        "actual_contribution_equal_in_both_states": true,
        "added_global_assignment": "ALL_NEAR",
        "baseline_global_assignment": "ALL_FAR",
        "contribution_over_added_kappa_W": {
          "lower": "3148888781490371821421744275391259103823656041597863692375337284316302727393002074521143337613536364264320691577949458049220905649503147091446071777454493788043175032356205752415390885869847996523167007102976892485543359204364867002774456322125947197197511156727095049219608803844828389832250552525756710964862678623102995051309805798241768205187791335266737487392206646599972757734576573070836849892848801661769714329756417997295745119009459019193009948266943988867731087014282213878526700688630390262313527434283654167065007680717315240448785921871078512523810077601/9042735138183638584092835552349268222574273940249975863800359027869190232408109185046266629157223045252529693816826837881000505556397150101574790941356090210924155061644168021938602227720997505313373121443350842544610704615502244253095535017651304384351794235190499892056676160392411801890492770060476273376051125225127187226468534691341426630110068986682881548966651669876469306819646330436754541736622085482220702062897502723307742370998000465563594391018154487142045029859328175301328538421646937079511350937926410631825867967892894943758188175737689581826700088370124320839793682637983896841218406274361633128202905943610930636507220587775721465162310877672039324607119183671516146691824448141686034960638330643333653121545199115395656341945563745036956181977752289450460127326382596272352134281130339515812382912409826229941292590910483636902533254650369417751942916253761132281809384763348432064332752357052853170226404328412682591537843562942060797916987928453722484633605239171099295279808356854054335006271262300182933303496462851833302281390587756041498261660865973183526788218420893902122883498344727207296955979139858777825105809561926097503013785845570840469770313144886886400",
          "upper": "3964146802282322853525987710508216908650339525/32692171377590361412239833601387893654518226963961568922094812731655991499859923712681617850028164751883149996481864789944736278208156779328817449651004906462620015855658596477837696056287847070891557182875460287963770170098151581998922852985229766689213751989095655126998918985791669952946893025109369000243847494940892083719661527687564496265047496482362110907498210698984574674104660604855184560867060722958113877063012561418742432079271406506735734748274998416619962139034276733314854813672046486243339391043959420686058936956432348205618592853307881804484987567468079936285902355699588938581630123494790650762460995315367519376407627479667017502917368561532928"
        },
        "contribution_over_baseline_kappa_W": {
          "lower": "3148888781490371821421744275391259103823656041597863692375337284316302727393002074521143337613536364264320691577949458049220905649503147091446071777454493788043175032356205752415390885869847996523167007102976892485543359204364867002774456322125947197197511156727095049219608803844828389832250552525756710964862678623102995051309805798241768205187791335266737487392206646599972757734576573070836849892848801661769714329756417997295745119009459019193009948266943988867731087014282213878526700688630390262313527434283654167065007680717315240448785921871078512523810077601/706463682670596764382252777527286579888615151582029364359403049052280486906883530081739580402908050410353882329439596709453164496593527351685530542293444547728449614190950626713953299040702930102607275112761784573797711298086112832273088673254008155027483924624257804066927825030657172022694747660974708857503994158213061502067854272761048955477349139584600121013019661709099164595284869565371448573173600428298492348663867400258417372734218786372155811798293319307972267957760013695416292064191166959336824292025500830611395934991632417481108451229506998580210944403915962565608881456092491940720187990184502588140852026844603955977126608419978239465805537318128072234931186224337198960298785011069221481299869581510441650120718680890285651714497167581012201717011897613317197447373640333777510490713307774672842415032017674214163483664881534133010410519560110761870540332325088459516358184636596255025996277894754153923937838157240827463894028354848499837264681910447069112000409310242132443735027879222994922364942367201791664335661160299476740733639668440742051692255154154963030329564132336103350273308181813070074685870301467017586391372025476367422952019185221911700805714444288000",
          "upper": "792829360456464570705197542101643381730067905/510815177774849397066247400021685838351847296311899514407731448932124867185311308010650278906690074248174218695029137342886504347002449677012772650796951663478437747744665569966214000879497610482680580982429066999433908907783618468733169577894215104518964874829619611359358109152994843014795203517333890628810117108451438808119711370118195254141367132536907982929659542171633979282885321950862258763547823796220529329109571272167850501238615726667745855441796850259686908422410573958044606463625726347552177985061865948219670889944255440712790513332935653195077930741688749004467224307806077165337970679606103918163453051802617490256369179369797148483083883773952"
        },
        "interval": {
          "lower": "3148888781490371821421744275391259103823656041597863692375337284316302727393002074521143337613536364264320691577949458049220905649503147091446071777454493788043175032356205752415390885869847996523167007102976892485543359204364867002774456322125947197197511156727095049219608803844828389832250552525756710964862678623102995051309805798241768205187791335266737487392206646599972757734576573070836849892848801661769714329756417997295745119009459019193009948266943988867731087014282213878526700688630390262313527434283654167065007680717315240448785921871078512523810077601/565170946136477411505802222021829263910892121265623491487522439241824389525506824065391664322326440328283105863551677367562531597274821881348424433834755638182759691352760501371162639232562344082085820090209427659038169038468890265818470938603206524021987139699406243253542260024525737618155798128779767086003195326570449201654283418208839164381879311667680096810415729367279331676227895652297158858538880342638793878931093920206733898187375029097724649438634655446377814366208010956333033651352933567469459433620400664489116747993305933984886760983605598864168755523132770052487105164873993552576150392147602070512681621475683164781701286735982591572644429854502457787944948979469759168239028008855377185039895665208353320096574944712228521371597734064809761373609518090653757957898912267022008392570646219738273932025614139371330786931905227306408328415648088609496432265860070767613086547709277004020797022315803323139150270525792661971115222683878799869811745528357655289600327448193705954988022303378395937891953893761433331468528928239581392586911734752593641353804123323970424263651305868882680218646545450456059748696241173614069113097620381093938361615348177529360644571555430400",
          "upper": "3964146802282322853525987710508216908650339525/2043260711099397588264989600086743353407389185247598057630925795728499468741245232042601115626760296992696874780116549371546017388009798708051090603187806653913750990978662279864856003517990441930722323929716267997735635631134473874932678311576860418075859499318478445437432436611979372059180814069335562515240468433805755232478845480472781016565468530147631931718638168686535917131541287803449035054191295184882117316438285088671402004954462906670983421767187401038747633689642295832178425854502905390208711940247463792878683559777021762851162053331742612780311722966754996017868897231224308661351882718424415672653812207210469961025476717479188593932335535095808"
        },
        "plain_local_assignment": "ALL_FAR",
        "weighted_local_assignment": "ALL_FAR"
      },
      "scale_window": {
        "L_lower": "1",
        "L_upper": "4609/4608",
        "log_measure": {
          "lower": "317131744182585828282079016840657352692027161/1461501637330902918203684832716283019655932542976",
          "upper": "158565872091292914141039508420328676346013581/730750818665451459101842416358141509827966271488"
        }
      },
      "scope": "Real non-atomic source mechanism pressure and local-cut repair only; no paid obstacle cap, F2 or weak/Near budget counterexample.",
      "source_states": {
        "added_f1": {
          "W": "16",
          "components": [
            {
              "density": "5902958103587056517120",
              "density_function_continuous": false,
              "first_coordinate_interval": [
                "-1/4",
                "1/4"
              ],
              "mass": "5/4",
              "other_coordinate_interval": [
                "-1/4",
                "1/4"
              ],
              "type": "actual density times axis-box indicator; Lebesgue non-atomic",
              "volume": "1/4722366482869645213696"
            },
            {
              "density": "1/4",
              "density_function_continuous": false,
              "first_coordinate_interval": [
                "4",
                "63"
              ],
              "mass": "59/4",
              "other_coordinate_interval": [
                "-1/2",
                "1/2"
              ],
              "type": "actual density times axis-box indicator; Lebesgue non-atomic",
              "volume": "59"
            }
          ]
        },
        "baseline_f0": {
          "W": "5/4",
          "components": [
            {
              "density": "5902958103587056517120",
              "density_function_continuous": false,
              "first_coordinate_interval": [
                "-1/4",
                "1/4"
              ],
              "mass": "5/4",
              "other_coordinate_interval": [
                "-1/4",
                "1/4"
              ],
              "type": "actual density times axis-box indicator; Lebesgue non-atomic",
              "volume": "1/4722366482869645213696"
            }
          ]
        }
      },
      "stage": "expanded_parameter",
      "tree_qualification": {
        "full_f1_h_retained_not_child_h": true,
        "local_children": "f0 restricted to x1<0 and x1>=0, each mass5/8",
        "local_node_depth": 1,
        "not_balanced_tree_corollary": true,
        "ordered_pair_LCA_is_local_depth_one": true,
        "root_local_vs_remote": "actual non-balanced binary tree",
        "sigma_at_local_node": "1/6"
      }
    }
  ],
  "round": 103,
  "scope": "Finite physical mechanism certificates only; global denominator grows, B not original obstacle exterior, all-input target OPEN.",
  "status": "PASS"
}
```

一般任意非负L1、真实Lebesgue接收、全部尺度根阶目标仍OPEN。后续动作应联合支付full-source h、source质量与实际有偿receiver cap；不能以本finite external-B机制证书代替这些资格和预算。

## 主代理复核与证书边界

公开数值程序 numeric.py 为 14596 字节，SHA-256 为 `1f094702ac7e179716347da289484b706faa4d1bd290d4f71dd32ca7cc74fa7e`。生产者实际执行一次；主代理实际读取完整代码后，在隔离临时目录复制同一代码执行一次，退出码均为 0。确定性 stdout 为 47814 字节，SHA-256 为 `0734ecb307dc7e8b644e182aa13a6a8f9def44127734e892a59ad758c52531de`，逐字节完全一致，无剔除字段。主代理运行外部计时约 0.365 秒，stderr 只有约 0.345 秒的内部计时 JSON。

公开固定菜单共三对、六个实际非原子来源状态，认证整个连续接收盒、来源对盒及尺度窗口；不是抽样积分。全局分类三次变化，原 κ 的局部分类三次归远，加权深度版本一次归远、两次仍近。六十六组有理端点均有序。输出完整列出真实体积、来源质量和新增后归一化损失。没有增加第四对来源，没有认证原障碍外部/F2资格，没有从有限维数外推一般阶数。

独立 Sol 先筛查精确协议，然后实际阅读全文、全部代码及完整输出数据，核对对数级数有向余项、单调外包、真实几何及质量归一化。审核者未执行生产程序，其静态审阅不冒充运行。主代理与独审分别实际阅读主要一般证明；主代理补写的局部化模块另经独审完整审阅。

更新后的数学技能用于核验条件：来源外积 μ⊗μ 不要求 f 坐标独立，但接收权 h² 会耦合两端；正核不自动具有振荡消去；树势与可求和误差必须有实在的根预算和终端。读取技能及来源卡不等于本轮完整阅读原论文。本轮没有依赖未经核验的新外部定理。

代码与报告中的 PASS 均限于明确协议。质量势版本尚未执行新的专门来源实验；其结论依赖本文给出的解析证明。一般共同接收近项仍开放。未发表来源配方、私有数值实现、参数与定量压力不在本公开报告；它们不改变公开证书的来源计数或覆盖范围。


## 公开几何核验证程序

```python
"""R103 PUBLIC fixed real non-atomic source mechanism certificates.

Three source-state pairs only: n=2,3,72, added total mass=2,55/32,16.
Same positive receiver/pair/scale box: global Far -> Near, unchanged full h.
Exterior receiver all-scale positive-excess energy finite and unchanged.
Local plain cutoff and depth-one weighted sigma=kappa/6 are distinguished.
No obstacle-cap/F2/weak-bound qualification or dimensional extrapolation.
Stdlib exact Fraction plus outward logarithm enclosures; deterministic stdout.
"""
from fractions import Fraction as F
from functools import lru_cache
import json
import sys
import time

LOG_TERMS = 96
LOG_GRID = 1 << 160
W_LOCAL = F(5, 4)
KAPPA = F(1)
SIGMA_DEPTH_ONE = F(1, 6)


def floor_rational(x):
    return x.numerator // x.denominator


def ceil_rational(x):
    return -floor_rational(-x)


def outward(lower, upper):
    assert lower <= upper
    return F(floor_rational(lower * LOG_GRID), LOG_GRID), F(ceil_rational(upper * LOG_GRID), LOG_GRID)


def atanh_log_unit(x):
    """Exact positive series plus explicit positive remainder; 1 <= x <= 2."""
    assert 1 <= x <= 2
    z = (x - 1) / (x + 1)
    square = z * z
    power = z
    partial = F(0)
    for j in range(LOG_TERMS):
        partial += 2 * power / (2 * j + 1)
        power *= square
    # Now power=z^(2m+1); every remaining denominator is >=2m+1.
    tail = 2 * power / ((2 * LOG_TERMS + 1) * (1 - square))
    return partial, partial + tail


LOG_TWO_RAW = atanh_log_unit(F(2))


@lru_cache(None)
def log_interval(x):
    assert x > 0
    z = x
    exponent = 0
    while z < 1:
        z *= 2
        exponent -= 1
    while z >= 2:
        z /= 2
        exponent += 1
    lower, upper = atanh_log_unit(z)
    if exponent >= 0:
        lower += exponent * LOG_TWO_RAW[0]
        upper += exponent * LOG_TWO_RAW[1]
    else:
        lower += exponent * LOG_TWO_RAW[1]
        upper += exponent * LOG_TWO_RAW[0]
    return outward(lower, upper)


def interval_record(lower, upper):
    assert lower <= upper
    return {'lower': str(lower), 'upper': str(upper)}


def classify_full_box(n, mass, threshold, scale_hi, distance_lo, distance_hi):
    """Classify every fixed physical pair/scale point; no sampled scale."""
    mass_log = log_interval(mass / threshold)
    scale_log = log_interval(scale_hi)
    dimension_log = log_interval(F(n))
    s_lower = mass_log[0] - n * scale_log[1]
    s_upper = mass_log[1]  # L>=1.
    assert s_lower > 0  # All selected scale windows have u<1.
    nested_lower = log_interval(1 + s_lower)[0]
    nested_upper = log_interval(1 + s_upper)[1]
    expression_lower = s_lower + 2 * nested_lower - dimension_log[1]
    expression_upper = s_upper + 2 * nested_upper - dimension_log[0]
    cutoff_lower = max(F(0), expression_lower)
    cutoff_upper = max(F(0), expression_upper)
    if cutoff_upper < distance_lo:
        classification = 'ALL_FAR'
    elif cutoff_lower > distance_hi:
        classification = 'ALL_NEAR'
    else:
        classification = 'UNKNOWN_STOP_NO_ADDITIONAL_MENU'
    return {'mass': str(mass), 'classification_threshold': str(threshold),
            'q': str(n), 'eta': '1', 's_interval': interval_record(s_lower, s_upper),
            'raw_cutoff_expression': interval_record(expression_lower, expression_upper),
            'positive_part_cutoff': interval_record(cutoff_lower, cutoff_upper),
            'far_strict_residual_lower': str(distance_lo - cutoff_upper),
            'near_strict_residual_lower': str(cutoff_lower - distance_hi),
            'classification': classification}


def source_box_record(n, density, first, other, mass):
    lengths = [first[1] - first[0]] + [other[1] - other[0]] * (n - 1)
    volume = F(1)
    for width in lengths:
        assert width > 0
        volume *= width
    assert density > 0 and density * volume == mass
    return {'type': 'actual density times axis-box indicator; Lebesgue non-atomic',
            'density': str(density), 'first_coordinate_interval': list(map(str, first)),
            'other_coordinate_interval': list(map(str, other)), 'volume': str(volume),
            'mass': str(mass), 'density_function_continuous': False}


def physical_case(stage, n, total_added_state_mass):
    density = W_LOCAL * 2 ** n
    local = source_box_record(n, density, (F(-1, 4), F(1, 4)), (F(-1, 4), F(1, 4)), W_LOCAL)
    remote_mass = total_added_state_mass - W_LOCAL
    remote_right = 4 + 4 * remote_mass
    remote = source_box_record(n, F(1, 4), (F(4), remote_right), (F(-1, 2), F(1, 2)), remote_mass)
    receiver_volume = F(1, 64) ** n
    pair_half_width = F(1, 128 * n)
    pair_volume = (2 * pair_half_width) ** n
    pair_mass = density * pair_volume
    scale_hi = 1 + F(1, 64 * n)
    first_receiver_lo, first_receiver_hi = F(39, 128), F(41, 128)
    scale_small_zero = F(7, 64)
    scale_remote_first_possible = F(471, 64)

    # Whole physical domains: first local coordinate is partially captured,
    # remaining source coordinates wholly captured on the selected scale window.
    assert first_receiver_lo > F(1, 4)
    assert first_receiver_lo - scale_hi / 2 > F(-1, 4)
    assert first_receiver_hi - F(1, 2) < F(1, 4)
    assert F(1, 128) + F(1, 4) < F(1, 2)
    assert first_receiver_hi + scale_hi / 2 < 4
    assert first_receiver_lo - F(1, 4) == scale_small_zero / 2
    assert 4 - first_receiver_hi == scale_remote_first_possible / 2
    # Both pair boxes belong to the same actual captures for all B x I.
    assert F(-1, 8) - pair_half_width > first_receiver_hi - F(1, 2)
    assert F(1, 8) + pair_half_width < first_receiver_lo + F(1, 2)
    assert pair_half_width < F(1, 4) and F(1, 8) > pair_half_width
    assert W_LOCAL / scale_remote_first_possible ** n <= F(1, 4)
    assert W_LOCAL / F(2) ** n < KAPPA
    # g<=1/4 everywhere: above its first capture scale aggregate A<=1/2.
    remote_active_average_upper = W_LOCAL / scale_remote_first_possible ** n + F(1, 4)
    assert remote_active_average_upper <= F(1, 2)

    average_lower = W_LOCAL * F(55, 64) / scale_hi ** n
    average_upper = W_LOCAL * (scale_hi - F(7, 64))
    assert average_lower > KAPPA and average_lower <= average_upper
    h_lower = 1 - KAPPA / average_lower
    distance_lower = (F(1, 4) - F(1, 64 * n)) / scale_hi
    distance_upper = F(17, 64)
    assert distance_lower > 0 and distance_lower <= distance_upper

    old_global = classify_full_box(n, W_LOCAL, KAPPA, scale_hi, distance_lower, distance_upper)
    new_global = classify_full_box(n, total_added_state_mass, KAPPA, scale_hi, distance_lower, distance_upper)
    local_plain = classify_full_box(n, W_LOCAL, KAPPA, scale_hi, distance_lower, distance_upper)
    local_weighted = classify_full_box(n, W_LOCAL, SIGMA_DEPTH_ONE, scale_hi, distance_lower, distance_upper)
    expected_checks = [(old_global, 'ALL_FAR'), (new_global, 'ALL_NEAR'), (local_plain, 'ALL_FAR')]
    if stage == 'expanded_parameter':
        expected_checks.append((local_weighted, 'ALL_FAR'))
    certificate_status = 'PASS'
    for observed, expected in expected_checks:
        if observed['classification'] == 'UNKNOWN_STOP_NO_ADDITIONAL_MENU':
            certificate_status = 'UNKNOWN_STOP_NO_ADDITIONAL_MENU'
        else:
            assert observed['classification'] == expected

    scale_measure = log_interval(scale_hi)
    finite_scale_measure = log_interval(F(128, 7))
    energy_lower = receiver_volume * (average_lower - 1) ** 2 * scale_measure[0]
    energy_upper = receiver_volume * (density - 1) ** 2 * finite_scale_measure[1]
    contribution_lower = receiver_volume * pair_mass ** 2 * h_lower ** 2 / scale_hi ** (2 * n) * scale_measure[0]
    contribution_upper = receiver_volume * pair_mass ** 2 * scale_measure[1]
    assert 0 < contribution_lower <= contribution_upper
    assert 0 < energy_lower <= energy_upper
    assert contribution_lower <= energy_upper
    return {'stage': stage, 'certificate_status': certificate_status, 'n': n, 'kappa': '1', 'q': str(n), 'eta': '1',
            'source_states': {'baseline_f0': {'components': [local], 'W': str(W_LOCAL)},
                              'added_f1': {'components': [local, remote], 'W': str(total_added_state_mass)}},
            'receiver_B': {'center_first': '5/16', 'center_others': '0', 'half_width': '1/128',
                           'first_interval': ['39/128', '41/128'], 'volume': str(receiver_volume),
                           'not_qualified_as_original_obstacle_complement': True,
                           'formal_U_B_complement_has_infinite_volume_not_paid_cap': True},
            'ordered_source_pair': {'negative_center_first': '-1/8', 'positive_center_first': '1/8',
                                    'center_others': '0', 'half_width': str(pair_half_width),
                                    'each_volume': str(pair_volume), 'each_mass': str(pair_mass),
                                    'normalized_l1_distance': interval_record(distance_lower, distance_upper),
                                    'ordered_only_no_extra_factor_two': True,
                                    'both_boxes_captured_everywhere_on_B_times_I': True},
            'scale_window': {'L_lower': '1', 'L_upper': str(scale_hi),
                             'log_measure': interval_record(*scale_measure)},
            'same_actual_window_average': {'exact_formula': '(5/4)*L^(-n)*(L+1/2-2*x1)',
                                           'interval': interval_record(average_lower, average_upper),
                                           'full_source_h_lower': str(h_lower),
                                           'remote_capture_zero_on_window': True},
            'all_scale_energy_identity_on_B': {'D_f1_equals_D_f0_pointwise': True,
                                               'small_scale_no_local_capture_until': str(scale_small_zero),
                                               'local_mass_kills_positive_excess_at_and_above': '2',
                                               'remote_first_possible_capture_L': str(scale_remote_first_possible),
                                               'aggregate_A_above_remote_first_capture_upper': str(remote_active_average_upper),
                                               'log_finite_energy_scale_range': interval_record(*finite_scale_measure),
                                               'common_finite_energy_interval': interval_record(energy_lower, energy_upper),
                                               'baseline_energy_over_kappa_W': interval_record(energy_lower / W_LOCAL, energy_upper / W_LOCAL),
                                               'added_energy_over_kappa_W': interval_record(energy_lower / total_added_state_mass, energy_upper / total_added_state_mass),
                                               'average_itself_not_identical_on_all_scales': True},
            'classification': {'baseline_global': old_global, 'added_global': new_global,
                               'plain_local_cluster': local_plain, 'weighted_local_cluster': local_weighted},
            'tree_qualification': {'root_local_vs_remote': 'actual non-balanced binary tree',
                                    'local_node_depth': 1, 'sigma_at_local_node': '1/6',
                                    'local_children': 'f0 restricted to x1<0 and x1>=0, each mass5/8',
                                    'ordered_pair_LCA_is_local_depth_one': True,
                                    'full_f1_h_retained_not_child_h': True,
                                    'not_balanced_tree_corollary': True},
            'same_positive_ordered_pair_window_contribution': {
                'interval': interval_record(contribution_lower, contribution_upper),
                'baseline_global_assignment': old_global['classification'], 'added_global_assignment': new_global['classification'],
                'plain_local_assignment': local_plain['classification'], 'weighted_local_assignment': local_weighted['classification'],
                'contribution_over_baseline_kappa_W': interval_record(contribution_lower / W_LOCAL, contribution_upper / W_LOCAL),
                'contribution_over_added_kappa_W': interval_record(contribution_lower / total_added_state_mass, contribution_upper / total_added_state_mass),
                'actual_contribution_equal_in_both_states': True},
            'scope': 'Real non-atomic source mechanism pressure and local-cut repair only; no paid obstacle cap, F2 or weak/Near budget counterexample.'}


def run():
    menu = [('pilot', 2, F(2)), ('boundary_pressure', 3, F(55, 32)), ('expanded_parameter', 72, F(16))]
    records = [physical_case(stage, n, mass) for stage, n, mass in menu]
    status = 'PASS' if all(r['certificate_status'] == 'PASS' for r in records) else 'UNKNOWN_STOP_NO_ADDITIONAL_MENU'
    return {'round': 103, 'status': status, 'publication': 'PUBLIC independent new density-box construction; no historical private recipes',
            'counts': {'actual_source_state_pairs': 3, 'actual_nonatomic_source_states': 6,
                       'full_continuum_receiver_pair_scale_certificates': 3,
                       'global_far_to_near_switches': sum(r['classification']['baseline_global']['classification'] == 'ALL_FAR' and r['classification']['added_global']['classification'] == 'ALL_NEAR' for r in records),
                       'plain_local_far_repairs': sum(r['classification']['plain_local_cluster']['classification'] == 'ALL_FAR' for r in records),
                       'weighted_local_far_repairs': sum(r['classification']['weighted_local_cluster']['classification'] == 'ALL_FAR' for r in records),
                       'additional_inputs_or_runs': 0},
            'arithmetic': {'inputs_volumes_masses': 'exact Fraction', 'log_terms': LOG_TERMS,
                           'log_outward_grid_denominator': str(LOG_GRID),
                           'log_tail': '2*z^(193)/(193*(1-z^2)), z=(x-1)/(x+1) after dyadic normalization',
                           'nested_logs': 'monotone rational endpoints; no float sign decisions'},
            'menu_rule': 'fixed three stages; n72 selected to test depth-one sigma=1/6, no dimension-power fit or adaptive additions',
            'records': records,
            'scope': 'Finite physical mechanism certificates only; global denominator grows, B not original obstacle exterior, all-input target OPEN.'}


if __name__ == '__main__':
    started = time.perf_counter()
    result = run()
    print(json.dumps(result, sort_keys=True, indent=2) + '\n', end='')
    print(json.dumps({'runtime_seconds_diagnostic': time.perf_counter() - started}), file=sys.stderr)
```
