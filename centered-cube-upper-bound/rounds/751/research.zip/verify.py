from __future__ import annotations

import argparse
import hashlib
import json
import platform
import sys
from dataclasses import dataclass
from fractions import Fraction as F
from itertools import combinations, product
from math import prod
from pathlib import Path

import flint
import scipy
from flint import arb, ctx, fmpq
from scipy.optimize import linprog


PRECISION = 256


def pts(*values):
    return tuple(F(x) for x in values)


def total(values):
    return sum(values, F(0))


def ball(value):
    value = F(value)
    return arb(fmpq(value.numerator, value.denominator))


def interval(value):
    return value.str(24)


@dataclass(frozen=True)
class Box:
    bounds: tuple

    @property
    def volume(self):
        return prod(hi-lo for lo, hi in self.bounds)

    def has(self, x, closed=False):
        if closed:
            return all(lo <= v <= hi for (lo, hi), v in zip(self.bounds, x))
        return all(lo < v < hi for (lo, hi), v in zip(self.bounds, x))


@dataclass(frozen=True)
class Cube:
    center: tuple
    radius: F

    def box(self, shrink=F(1)):
        return Box(tuple((x-shrink*self.radius, x+shrink*self.radius) for x in self.center))


def intersection(*boxes):
    return prod(
        max(F(0), min(hi for _, hi in axis)-max(lo for lo, _ in axis))
        for axis in zip(*(box.bounds for box in boxes))
    )


def endpoints(boxes):
    return [sorted({end for pair in axis for end in pair}) for axis in zip(*(b.bounds for b in boxes))]


def maximal(masks):
    masks = set(masks)-{frozenset()}
    return sorted((q for q in masks if not any(q < v for v in masks)), key=lambda q: tuple(sorted(q)))


def destination_maps(boxes):
    axes = endpoints(boxes)
    positive = [[(l+r)/2 for l, r in zip(line, line[1:])] for line in axes]
    all_reps = [sorted(set(line+regular)) for line, regular in zip(axes, positive)]
    interior, closed_patterns = {}, {}
    for z in product(*positive):
        mask = frozenset(j for j, A in enumerate(boxes) if A.has(z))
        if mask:
            interior.setdefault(mask, z)
    for z in product(*all_reps):
        open_mask = frozenset(j for j, A in enumerate(boxes) if A.has(z))
        closed_mask = frozenset(j for j, A in enumerate(boxes) if A.has(z, closed=True))
        if open_mask:
            assert any(open_mask <= m for m in interior)
        if closed_mask:
            closed_patterns.setdefault(closed_mask, z)
    for closed, mapping in ((False, interior),(True, closed_patterns)):
        independent = []
        for k in range(1, len(boxes)+1):
            for selection in combinations(range(len(boxes)), k):
                intervals = zip(*(boxes[i].bounds for i in selection))
                if all(
                    (max(lo for lo, _ in row) <= min(hi for _, hi in row)) if closed
                    else (max(lo for lo, _ in row) < min(hi for _, hi in row))
                    for row in intervals
                ):
                    independent.append(frozenset(selection))
        assert maximal(mapping) == maximal(independent)
    forced_boundaries = [
        {"rows": sorted(m), "point": list(map(str, closed_patterns[m]))}
        for m in maximal(closed_patterns) if not any(m <= q for q in interior)
    ]
    return {
        "open": interior,
        "closed": closed_patterns,
        "extra_closed_boundary_masks": forced_boundaries,
    }


def options(mapping, active):
    projected = {mask & active for mask in mapping}
    choices = []
    for m in maximal(projected):
        full = next(mask for mask in mapping if mask & active == m)
        choices.append((m, full, mapping[full]))
    return choices


def integer_placement(choices, weights, L):
    best = F(0)
    chosen = ()
    for size in range(1, min(L, len(choices))+1):
        for sequence in combinations(range(len(choices)), size):
            coverage = set().union(*(choices[i][0] for i in sequence))
            objective = total(weights[j] for j in coverage)
            if objective > best:
                best, chosen = objective, sequence
    return best, [F(1) if k in chosen else F(0) for k in range(len(choices))]


def fractional_profile(choices, active, weights, L):
    # Primal variables are masses of types of sites, followed by capped row heights.
    if not choices:
        return F(0), [], None
    rows = sorted(active)
    n, m = len(choices), len(rows)
    scale = max(weights[j] for j in rows)
    goal = [F(0)]*n + [weights[j]/scale for j in rows]
    matrix = [[1]*n + [0]*m]
    rhs = [L]
    for u, j in enumerate(rows):
        own = [int(h == u) for h in range(m)]
        matrix.append([0]*n+own)
        rhs.append(1)
        matrix.append([-int(j in q[0]) for q in choices]+own)
        rhs.append(0)
    result = linprog([-float(p) for p in goal], A_ub=matrix, b_ub=rhs,
                     bounds=(0,None), method="highs")
    assert result.success
    # Floating-point solver output only proposes the certificates.
    primal = [F(float(x)).limit_denominator(10**7) for x in result.x]
    dual = [F(-float(y)).limit_denominator(10**7) for y in result.ineqlin.marginals]
    assert all(x >= 0 for x in primal+dual)
    for row, bound in zip(matrix, rhs):
        assert total(x*y for x,y in zip(row,primal)) <= bound
    for i in range(len(goal)):
        assert total(row[i]*x for row,x in zip(matrix,dual)) >= goal[i]
    value = total(x*y for x,y in zip(primal,goal))
    assert value == total(x*y for x,y in zip(dual,rhs))
    amounts = primal[:n]
    actual_score = total(
        weights[j]*min(F(1), total(x for x,c in zip(amounts,choices) if j in c[0])) for j in rows
    )
    assert actual_score == scale*value
    return scale*value, amounts, {
        "price_scale": str(scale),
        "budget_dual_scaled": str(dual[0]),
        "cap_dual_scaled": [str(x) for x in dual[1::2]],
        "transport_dual_scaled": [str(x) for x in dual[2::2]],
        "primal_heights": list(map(str,primal[n:])),
        "active_row_order": rows,
    }


def cell_masses(boxes, price_regions, source_count):
    axes = endpoints(boxes+[A for A, _ in price_regions])
    axis_cells = [list(zip(a,a[1:])) for a in axes]
    price_cells = {}
    count = 0
    for cell in product(*axis_cells):
        x = tuple((l+r)/2 for l,r in cell)
        I = frozenset(i for i,A in enumerate(boxes[:source_count]) if A.has(x))
        J = frozenset(j for j,A in enumerate(boxes[source_count:]) if A.has(x))
        density = total(w for A,w in price_regions if A.has(x))
        if I or J:
            assert density >= 1
            price_cells[I,J] = price_cells.get((I,J), F(0))+density*prod(r-l for l,r in cell)
            count += 1
    return price_cells,count


def flow_check(name,sending,receiving,q,price_regions,make_cut):
    nc = len(sending)
    sources = [c.box() for c in sending]
    targets = [c.box() for c in receiving]
    original = sources+targets
    a = 32*len(sending[0].center)
    shrink = [c.box(F(1,a)) for c in sending+receiving]
    assert all(not intersection(A,B) for A,B in combinations(shrink,2))
    owner = [A.volume for A in shrink]
    physical = [A.volume for A in original]
    m = [
        total(weight*intersection(A,region) for region,weight in price_regions)
        for A in original
    ]
    assert all(x>=y for x,y in zip(m,physical))
    w = [v/p for v,p in zip(owner[nc:],m[nc:])]
    G = F(2)
    lam = [owner[i]/(G*m[i]*(i+2)) for i in range(nc)]
    assert sum(lam)<1 and all(lam[i]*m[i] <= owner[i]/G for i in range(nc))

    base, origin_count = cell_masses(original,price_regions,nc)
    nrows = len(targets)
    for i in range(nc):
        assert total(p for (I,J),p in base.items() if i in I)==m[i]
    for j in range(nrows):
        assert total(p for (I,J),p in base.items() if j in J)==m[nc+j]
    union_sources = destination_maps([c.box(q) for c in sending])
    union_targets = destination_maps([c.box(q) for c in receiving])
    original_forward = total(x*total(lam[i] for i in I)*total(w[j] for j in J) for (I,J),x in base.items())
    original_reverse = total(
        lam[i]*w[j]*total(weight*intersection(A,B,C) for C,weight in price_regions)
        for i,A in enumerate(sources) for j,B in enumerate(targets)
    )
    assert original_reverse == original_forward > 0
    cache = {}
    witness_reports = {}
    comparison = []
    cut = make_cut(w)
    mark = [F(2),cut] if cut is not None else [F(2)]
    policies = []

    def policy(direction, mode, active, weights, L, kind):
        key = (direction,mode,tuple(sorted(active)),L,kind)
        if key not in cache:
            mapping = union_targets[mode] if direction=="forward" else union_sources[mode]
            available = options(mapping,active)
            if kind=="integer":
                result, amounts = integer_placement(available,weights,L)
                proof = None
            else:
                result, amounts, proof = fractional_profile(available,active,weights,L)
            assert total(amounts) <= L
            cache[key] = result, [(v,full) for v,(_,full,_) in zip(amounts,available) if v]
            if active:
                witness_reports[key] = {
                    "direction": direction, "mode": mode, "active_rows": sorted(active),
                    "L": L, "kind": kind, "local_optimum": str(result),
                    "chosen_sites": [
                        {"x": list(map(str,z)), "mass": str(v), "rows": sorted(full)}
                        for (productive,full,z),v in zip(available,amounts) if v
                    ],
                    "rational_LP_certificate": proof,
                }
        return cache[key]

    def run_forward(L, mode, kind):
        true_mass = F(0)
        incoming = [F(0)]*nrows
        raw = [F(0)]*nrows
        outgoing = F(0)
        missing_factor = []
        for (I,J),price in base.items():
            src = price*total(lam[i] for i in I)
            if not src or not J:
                continue
            value, kernel = policy("forward",mode,J,w,L,kind)
            true_mass += src*value
            outgoing += src*total(v for v,_ in kernel)
            for j in range(nrows):
                transported = src*total(v for v,mask in kernel if j in mask)
                raw[j] += transported
                if j in J:
                    incoming[j] += src*min(F(1),transported/src)
        assert true_mass == total(w[j]*incoming[j] for j in range(nrows))
        assert outgoing <= L*total(lam[i]*m[i] for i in range(nc))
        for j in range(nrows):
            h_j = incoming[j]/m[nc+j]
            assert h_j <= raw[j]/m[nc+j] == L*(raw[j]/L)/m[nc+j]
            if h_j > (raw[j]/L)/m[nc+j]:
                missing_factor.append(j)
        return true_mass, incoming, raw, missing_factor

    def run_reverse(L, mode, kind, threshold):
        true_mass = F(0)
        discarded = F(0)
        incoming = [F(0)]*nc
        raw_normalized = [F(0)]*nc
        equality_origin_categories = 0
        max_outgoing_probability = F(0)
        for (I,J),price in base.items():
            W = total(w[j] for j in J)
            if not W or not I:
                continue
            if W > threshold:
                discarded += price * W * total(lam[i] for i in I)
                continue
            if W == threshold:
                equality_origin_categories += 1
            value, kernel = policy("reverse",mode,I,lam,L,kind)
            prob = (W/threshold)*total(v for v,_ in kernel)/L
            assert 0 <= prob <= W/threshold <= 1
            max_outgoing_probability = max(max_outgoing_probability,prob)
            true_mass += price*W*value
            for i in range(nc):
                mass_to_i = total(v for v,mask in kernel if i in mask)
                raw_normalized[i] += price*W*mass_to_i/(threshold*L)
                if i in I:
                    incoming[i] += price*W*min(F(1),mass_to_i)
        assert true_mass == total(lam[i]*incoming[i] for i in range(nc))
        assert true_mass <= original_reverse-discarded
        for i in range(nc):
            assert incoming[i]/m[i] <= threshold*L*raw_normalized[i]/m[i]
        return {
            "threshold_HG": str(threshold),
            "true_capture": str(true_mass),
            "actual_original_flow_discarded": str(discarded),
            "equality_origin_categories_kept": equality_origin_categories,
            "max_normalized_outgoing_probability": str(max_outgoing_probability),
            "h_by_original_m_i": [str(v/p) for v,p in zip(incoming,m[:nc])],
            "raw_transported_by_original_m_i_average": [str(v/p) for v,p in zip(raw_normalized,m[:nc])],
        }

    for L,mode in product((1,2,3),("open","closed")):
        d_opt,d_ch,d_m,d_bad = run_forward(L,mode,"integer")
        r_opt,r_ch,r_m,r_bad = run_forward(L,mode,"fractional")
        assert d_opt <= r_opt <= original_forward
        comparison.append({
            "L": L, "destinations": mode,
            "forward_integer_shared_capture": str(d_opt),
            "forward_fractional_kernel_capture": str(r_opt),
            "h_original_denominator_integer": [str(x/p) for x,p in zip(d_ch,m[nc:])],
            "h_original_denominator_fractional": [str(x/p) for x,p in zip(r_ch,m[nc:])],
            "transport_average_original_denominator_fractional": [
                str(x/(p*L)) for x,p in zip(r_m,m[nc:])
            ],
            "rows_where_factor_L_is_needed_after_averaging": sorted(set(d_bad+r_bad)),
            "reverse_fractional_transport": [run_reverse(L,mode,"fractional",t) for t in mark],
        })

    if name.startswith("cycle"):
        total_weight = sum(w)
        assert len(set(w)) == 1
        d,r = policy("forward","open",frozenset(range(6)),w,3,"integer")[0], \
              policy("forward","open",frozenset(range(6)),w,3,"fractional")[0]
        assert d == 5*w[0] and r == F(11,2)*w[0]
        assert total_weight == 6*w[0]
    if cut is not None:
        assert any(F(x["reverse_fractional_transport"][1]["actual_original_flow_discarded"])>0
                   for x in comparison)
        assert any(x["reverse_fractional_transport"][1]["equality_origin_categories_kept"]>0
                   for x in comparison)
    if not name.startswith("cycle"):
        assert union_targets["extra_closed_boundary_masks"]
        assert F(comparison[1]["forward_integer_shared_capture"]) > F(comparison[0]["forward_integer_shared_capture"])

    # A feasible budget-2 overload at one location induces one unit of true capture.
    visible = next(mask for mask in union_targets["open"] if mask)
    artificial_mass = F(2)
    clipped = total(w[j]*min(F(1),artificial_mass) for j in visible)
    uncut = total(w[j]*artificial_mass for j in visible)
    assert uncut == 2*clipped > 0
    return {
        "name": name, "dimension": len(sending[0].center), "rational_geometry_q": str(q),
        "source_cubes": [[list(map(str, c.center)),str(c.radius)] for c in sending],
        "receiver_cubes": [[list(map(str,c.center)),str(c.radius)] for c in receiving],
        "price_rectangles_bounds_and_density": [
            [[list(map(str, p)) for p in c.bounds],str(wi)] for c,wi in price_regions
        ],
        "origin_positive_price_cells": origin_count, "distinct_origin_membership_categories": len(base),
        "owner_volumes": list(map(str,owner)), "d": list(map(str,physical)), "m": list(map(str,m)),
        "lambda": list(map(str,lam)), "w_on_receiver_parents": list(map(str,w)),
        "original_forward_and_reverse_uncaptured_cap_mass": str(original_forward),
        "extra_receiver_closed_boundary_masks": union_targets["extra_closed_boundary_masks"],
        "extra_source_closed_boundary_masks": union_sources["extra_closed_boundary_masks"],
        "local_repeated_atom_mass_cap_example": {
            "raw_weighted_transport": str(uncut), "true_capped_weight": str(clipped)
        },
        "comparisons": comparison,
        "point_placements_and_exact_optimality_certificates": [
            witness_reports[key] for key in sorted(witness_reports)
        ],
        "explicit_cutoff_note": (
            "HG=2 is the H=1,G=2 normalization in this test. The second cut intentionally probes boundary/equality algebra at a smaller diagnostic HG."
            if cut is not None else "HG=2 is the H=1,G=2 normalization in this test."
        ),
    }


def finite_fixtures():
    cycle_points = [pts(0,0),pts("3/2",0),pts("5/2","3/2"),pts(1,3),pts("-3/4","3/2"),pts(5,"3/2")]
    cycle = flow_check(
        "cycle_of_five_open_targets_and_one_isolated_target",
        [Cube(pts(2,"3/2"),F(1,2)), Cube(pts("5/2",2),F(3,4))],
        [Cube(x,F(4)) for x in cycle_points], F(1,4),
        [(Cube(pts(2,1),F(10)).box(),F(1)),
         (Cube(pts("9/4","7/4"),F(1,8)).box(),F(2))],
        lambda w: None,
    )
    contact = flow_check(
        "shrunk_closed_face_and_vertex_contacts_with_cutoff",
        [Cube(pts("3/8",0),F(3,4)), Cube(pts("9/8","1/4"),F(1,2))],
        [Cube(pts(0,0),F(1)),Cube(pts(1,0),F(1)),Cube(pts("3/2","1/2"),F(3,2)),Cube(pts(1,1),F(1))],
        F(1,2),
        [(Cube(pts(0,0),F(5)).box(),F(1)),(Cube(pts("1/4","1/8"),F(1,8)).box(),F(2))],
        lambda w: w[0]+w[1]+w[2],
    )
    return [cycle,contact]


def actual_direction_cost():
    n = 5
    shrink = F(15,16)
    gamma = F(1,4)
    motion = (1+gamma)*(1-shrink)
    thick = (1+(1+gamma)**2)*(1-shrink)
    price_halfside = F(1,4096)
    a = 32*n
    # Each sign points from this entire positive-price cell into the receiver.
    patterns = ((1,0,-1,0,0), (-1,1,0,0,0), (1,-1,0,1,0),
                (0,1,0,-1,1), (0,0,1,0,-1), (1,0,0,1,1),
                (-1,0,1,-1,0), (1,1,0,0,0))
    radii = tuple((F(1),F(4,5),F(7,8))[j%3] for j in range(len(patterns)))
    centers = [tuple(F(63,64)*r*t for t in row) for row,r in zip(patterns,radii)]
    cubes = [Cube(center,r) for center,r in zip(centers,radii)]
    owners = [c.box(F(1,a)) for c in cubes]
    assert all(intersection(A,B) == 0 for A,B in combinations(owners,2))
    weights = []
    for row,r,c,A in zip(patterns,radii,centers,owners):
        for sign,coordinate in zip(row,c):
            if sign:
                assert (1-thick)*r < abs(coordinate)-price_halfside
                assert abs(coordinate)+price_halfside < r
            else:
                assert price_halfside < (1-thick)*r
        # Unit background on [-3,3]^n and one extra unit of mass on the price cell.
        weights.append(A.volume/((2*r)**n+1))
    norm = total(weights)
    weights = [w/norm for w in weights]
    probs = []
    face_entropy = arb(0)
    for k in range(n):
        pos = total(w for w,row in zip(weights,patterns) if row[k] == 1)
        neg = total(w for w,row in zip(weights,patterns) if row[k] == -1)
        assert pos and neg
        u=pos/(pos+neg)
        probs.append(u)
        face_entropy -= ball(pos)*ball(u).log()+ball(neg)*ball(1-u).log()
    probabilities = [F(0)]*len(cubes)
    for signs in product((-1,1), repeat=n):
        prob = prod(u if t == 1 else 1-u for t,u in zip(signs,probs))
        for j,(row,r,c) in enumerate(zip(patterns,radii,centers)):
            good = all(v == 0 or v == t for v,t in zip(row,signs))
            whole_cell_hits = all(abs(motion*t-y)+price_halfside < shrink*r for t,y in zip(signs,c))
            if not good:
                assert any(abs(motion*t-y)-price_halfside > shrink*r for t,y in zip(signs,c))
            assert good == whole_cell_hits
            if good:
                probabilities[j] += prob
    expected_loss = -sum((ball(w)*ball(x).log() for w,x in zip(weights,probabilities)),arb(0))
    assert expected_loss.overlaps(face_entropy)
    cases=[]
    for budget in (2,4,16,128):
        captured=total(w*min(F(1),budget*x) for w,x in zip(weights,probabilities))
        full=total(w for w,x in zip(weights,probabilities) if budget*x >= 1)
        markov=1-face_entropy/arb(budget).log()
        assert captured >= full and ball(full) > markov
        if face_entropy < arb(budget).log()/2:
            assert full >= F(1,2)
        cases.append({"per_bin_mass": budget, "actual_capture": str(captured),
                      "fully_hit_row_weight": str(full), "entropy_lower_candidate": interval(markov)})
    return {"dimension":n,"open_shrink":str(shrink),"price_cell_halfside":str(price_halfside),
            "readout": "All checks hold on the whole price cell; finite hit probabilities are exact.",
            "receiver_face_signs":patterns,"receiver_radii":list(map(str,radii)),
            "sign_probabilities":list(map(str,probs)),
            "actual_weights_normalized":list(map(str,weights)),
            "per_row_success":list(map(str,probabilities)),
            "entropy_from_marginals":interval(face_entropy),"cost_from_rows":interval(expected_loss),
            "budget_cases":cases}


def Phi(u):
    if u.is_zero():
        return arb(0)
    if u >= 1:
        return arb(1)
    assert 0 < u < 1
    return u*(1-u.log())


def scales(n):
    nd = arb(n)
    logsize = arb(n+2).log()
    H = 3*logsize
    tail = H*(1-H).exp()
    tail_closed = 3*arb(1).exp()*logsize/arb((n+2)**3)
    assert tail.overlaps(tail_closed)
    envelope = 1/(nd.sqrt()*logsize**3)
    shrink_cases = []
    for L in (1,n*n):
        loss = arb(L).log()+nd.log()/2+3*logsize.log()
        q = (-loss/nd).exp()
        assert 0 < q < 1
        assert (L*q**n).overlaps(envelope)
        displacement = -nd*(-loss/nd).expm1()
        assert loss-loss**2/(2*nd) < displacement < loss
        halo = (1+1/(32*nd*q))**n
        assert 1 < halo < (1/(32*q)).exp()
        shrink_cases.append({
            "L": L, "q": interval(q), "L_q_power_n": interval(L*q**n),
            "n_times_one_minus_q": interval(displacement),
            "actual_halo_factor_at_a_eq_32n": interval(halo),
        })
    price_input = []
    for R,g in ((F(1,2),F(1)),(F(1,2),F(8)),(F(1,64),F(1))):
        G_proxy = ball(g)*nd.sqrt()
        Gprime_proxy = nd*logsize
        u = envelope*Gprime_proxy/(ball(R)*G_proxy)
        assert u.overlaps(1/(ball(R*g)*logsize**2))
        forward = Phi(u)
        price_input.append({
            "R_V_over_GM": str(R), "g_G_over_sqrt_n": str(g),
            "proxy_u": interval(u), "Phi_forward_fraction": interval(forward),
            "reverse_K_1": interval(tail+H*forward),
            "reverse_K_4": interval(tail+4*H*forward),
        })
    return {"n": n, "H": interval(H), "discarded_fraction_tail": interval(tail),
            "shrink_cases": shrink_cases, "price_scale_proxies": price_input}


def report():
    ctx.prec = PRECISION
    script = Path(__file__)
    return {
        "schema": "r751-shared-destination-verification-v1",
        "runtime": {
            "python": platform.python_version(), "python_executable": sys.executable,
            "scipy_proposal_only": scipy.__version__, "python_flint": flint.__version__,
            "arb_precision_bits": PRECISION,
            "script_sha256": hashlib.sha256(script.read_bytes()).hexdigest(),
            "working_directory_for_commands": "directory containing verify.py and verify.json",
            "write_command": [sys.executable,"-B",script.name,"--out","verify.json"],
            "rerun_command": [sys.executable,"-B",script.name,"--check","verify.json"],
        },
        "exact_finite_destination_fixtures": finite_fixtures(),
        "actual_coordinate_conflict_cost": actual_direction_cost(),
        "Arb_scalar_only_theorems_q_and_tail": [scales(n) for n in (16,64,256,4096,2**20,2**40,2**60)],
        "scope": [
            "Finite fixtures use the indicated rational q. The theoretical shrink formula is checked separately with Arb.",
            "Point choices enumerate potentially shared destinations. Positive kernels with total mass <= L permit more than L atoms.",
            "The proposed fractional optima are accepted only after exact Fraction primal and dual feasibility and equality.",
            "All parent prices and owner volumes in finite fixtures are computed with absolutely continuous price and actual shrinks.",
            "The scalar Gprime=n*log(n+2) is an explicit test normalization only; this is not a measurement of the true C_n.",
        ],
    }


def main():
    parser = argparse.ArgumentParser()
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--out",type=Path)
    mode.add_argument("--check",type=Path)
    args = parser.parse_args()
    raw = json.dumps(report(),indent=2,sort_keys=True)+"\n"
    if args.out:
        args.out.write_text(raw,encoding="utf-8")
        print(f"wrote {args.out} ({len(raw)} bytes)")
    else:
        if args.check.read_text(encoding="utf-8") != raw:
            raise SystemExit("rerun differs from saved output")
        print(f"identical rerun of {args.check} ({len(raw)} bytes)")


if __name__ == "__main__":
    main()
