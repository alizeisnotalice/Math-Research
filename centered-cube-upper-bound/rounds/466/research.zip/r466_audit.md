# R466 FINAL PASS（限定已证结论）

独立 PRE 先行，后核最终七输入。PASS 限于最优 cut 的阈值/lattice/互补性、近优 margin 估计、own-low 三块父负载及有限复现。**未认证最优缺额的根阶价格、跨父负载的可求和上界或完整一般预算；原母账与所有旧费保持。**

完整 cut−flow 恒等式包含四个非负项：\(I^c\) 行余量、\(B\) 列余量、\(I\times B^c\) 边帽余量、\(I^c\times B\) backflow。最后一项不可省。对任意最优分配、最优 cut 四项各零；近优分配/cut 的四项总和只付 \(\varepsilon_p+\varepsilon_c\) 一次。两侧各自 best-response 的错误边距积分正确且分别≤cut gap，二者之和不能自动用一份 gap。全部仍在真实 \(\nu,\mu,\kappa\) 及 a.e. 单位下。

submodularity (7) 的交叉边符号正确，故最优 cut 对交并封闭。有限 \(\nu+\mu\) 下取近极值序列并递减交/递增并；\(\kappa\) 有限保证 cut 成本随该极限收敛，得到模零最小/最大最优 cut。再去掉/补入各侧 ties 得同时 strict/weak 响应，论证成立。任意最优 cut 只有夹逼包含，不能把任意 strict fixedpoint 当最优或声称交替迭代收缩。固定输入的可测最优 cut 已由 R465 证明，本轮未额外声称参数化选择。

几何三块估计正确。own-low 支付严格 \(m_A<m_u/K\) 部分；中间闭窗由真实 center 子水平体积 \(t/q\) 和含 base 的 layer-cake 给 \(q^{-1}[1+\log(H/l)]\)，保两端质量原子；高质量且父中心在 \(Q_u\) 内的项由 \(|Q_u|\) 给 \(Sr/\kappa\)。合计扣项、\(\kappa=K\) 根尺度参数及正部负载下界无遗漏因子。来源阈值的 \(\mu\)-a.e. 结论可迁移原 \(P\) 的来源边缘，因为该边缘绝对连续于 \(\mu\)。新增父无原历史，且 \(A\notin Q_u\) 不能改写成 \(u\notin Q_A\)；稿件正确保留该区别。下界及实际积分式不支付右侧跨父重复。

必要范围修正已完成：一维 geometry 代码的 \(K_{\rm test}=2\) 明示为辅助阈值，非 \(n=1\) 原 \(K=e\)。其真实 matching 分层例未通过原高秩/history，也未认证最优厚 cut。

隔离目录
`/var/folders/lq/2c4qbz2n0354_tnttkv_qsz00000gn/T/r466_audit_cyk76hwk`
使用指定 Python 重放 geometry/complement 代码块和 numeric 脚本：36、116、1652项均通过，三 stdout 与 replay 逐字一致，numeric JSON 只运行 seconds 不同。36为九组一维匹配参数，116为三个容量模型52cuts，1652为三个区间捕获图七组容量208cuts/24最优cuts；断言数不是独立几何样本数。有限证书仅核容量接口、ties 和互补性，不替代一般连续证明或原 hard 需求/history。PRE 临时96cut/192响应检查不加入归档统计。未改作者/仓库，未编译 PDF。

最终七输入 SHA256：

- `r466_main.md`: `007440185f9ab266dfee80508880c6d39b622f5c7d418ea13220b9f09b896abc`
- `r466_geometry.md`: `bb285277db64b304609a2cdcbcd207da355c949d08ac30f5ca7323e00a430794`
- `r466_complement.md`: `cc491713b49e92f4046d58a50e7b1a14a91abfd0ea7fc060f5e5200e97f00cff`
- `r466_numeric.md`: `a89a07affb9c3fbad4d3e0812627e44f1c43775231ce8f538deff6527b6d0dce`
- `r466_numeric.py`: `191f035755c37519cbf32864b328141f158a392f5bf04e87004d16885b504eb5`
- `r466_numeric.json`: `9c83390bdd1f002278d338e1f0cf62d33535a5ba74eab13f83a41701258430a4`
- `r466_replay.json`: `9467d7f053bc8ed97a33beec0e82012a3bbec20a704a3fb66ad9b1a84a66c3e1`
