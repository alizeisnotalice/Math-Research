from fractions import Fraction as F
from pathlib import Path
from collections import deque
import json,sys,platform,time
ROOT=Path(__file__).resolve().parent
start=time.perf_counter();checks=0

def ck(z):
 global checks
 assert z
 checks+=1
H=F(1,100);R=F(6,5)
inputs=[('nested_full_reallocation',[0,1],[F(1,2),0],[1,1]),('nested_Hall_deficit',[0,1],[F(1,2),0],[F(1,2),F(3,2)]),('three_packet_chain',[0,1,2],[F(1,2),F(3,2),1],[1,1,1])]
models=[]
for name,sources,parents,d in inputs:
 sources=list(map(F,sources));parents=list(map(F,parents));d=list(map(F,d));B=[];margins=[]
 for a in parents:
  br=[];mr=[]
  for x in sources:
   hi=abs(a-x)+2*H;lo=max(F(0),abs(a-x)-2*H)
   if hi<R/2:br.append(1);mr.append(R/2-hi)
   else:ck(lo>R/2);br.append(0);mr.append(lo-R/2)
  B.append(br);margins.append(mr)
 for cs in (sources,parents):
  for k,x in enumerate(cs):
   for y in cs[k+1:]:ck(abs(x-y)>2*H)
 f=[F(1)]*len(sources);mass=[sum(br) for br in B]
 pi=[[F(z,mass[j]) for z in br] for j,br in enumerate(B)]
 a0=[[d[j]*pi[j][i] for i in range(len(f))] for j in range(len(d))]
 models.append(dict(name=name,sources=sources,parent_centers=parents,d=d,f=f,capture=B,geometry_margins=margins,pi=pi,a0=a0))

def maxflow(model,M,Lambda):
 d=model['d'];f=model['f'];a0=model['a0'];J=len(d);K=len(f);src=0;rn=list(range(1,J+1));cn=list(range(J+1,J+K+1));sink=J+K+1;N=sink+1
 cap=[[F(0)]*N for _ in range(N)];res=[[F(0)]*N for _ in range(N)];adj=[[] for _ in range(N)]
 def edge(u,v,c):cap[u][v]=res[u][v]=c;adj[u].append(v);adj[v].append(u)
 for j in range(J):edge(src,rn[j],d[j])
 for j in range(J):
  for i in range(K):
   if a0[j][i]:edge(rn[j],cn[i],M*a0[j][i])
 for i in range(K):edge(cn[i],sink,Lambda*f[i])
 value=F(0)
 while True:
  prev=[None]*N;prev[src]=src;q=deque([src])
  while q and prev[sink] is None:
   u=q.popleft()
   for v in adj[u]:
    if prev[v] is None and res[u][v]>0:prev[v]=u;q.append(v)
  if prev[sink] is None:break
  path=[];v=sink
  while v!=src:path.append((prev[v],v));v=prev[v]
  delta=min(res[u][v] for u,v in path);ck(delta>0)
  for u,v in path:res[u][v]-=delta;res[v][u]+=delta
  value+=delta
 p=[[cap[rn[j]][cn[i]]-res[rn[j]][cn[i]] for i in range(K)] for j in range(J)]
 for j in range(J):ck(sum(p[j])<=d[j]);ck(all(0<=p[j][i]<=M*a0[j][i] for i in range(K)))
 for i in range(K):ck(sum(p[j][i] for j in range(J))<=Lambda*f[i])
 ck(sum(map(sum,p))==value)
 return p,value

def certify(model,M,Lambda):
 J=len(model['d']);K=len(model['f']);d=model['d'];f=model['f'];a0=model['a0'];pi=model['pi'];p,opt=maxflow(model,M,Lambda)
 def cost(I,B):return sum(d[j] for j in range(J) if j not in I)+Lambda*sum(f[i] for i in B)+M*sum(a0[j][i] for j in I for i in range(K) if i not in B)
 allcuts=[];optimal=[];maxgap=F(0);maxrowimp=F(0);maxcolimp=F(0)
 def data(I,B):
  rowmargin=[d[j]*(1-M*sum(pi[j][i] for i in range(K) if i not in B)) for j in range(J)]
  colmargin=[M*sum(a0[j][i] for j in I)-Lambda*f[i] for i in range(K)]
  return rowmargin,colmargin
 for imask in range(1<<J):
  I={j for j in range(J) if imask>>j&1}
  for bmask in range(1<<K):
   B={i for i in range(K) if bmask>>i&1};c=cost(I,B);gap=c-opt;ck(gap>=0)
   unused_rows=sum(d[j]-sum(p[j]) for j in range(J) if j not in I)
   unused_sources=sum(Lambda*f[i]-sum(p[j][i] for j in range(J)) for i in B)
   unused_edges=sum(M*a0[j][i]-p[j][i] for j in I for i in range(K) if i not in B)
   backflow=sum(p[j][i] for j in range(J) if j not in I for i in B)
   slacks=[unused_rows,unused_sources,unused_edges,backflow];ck(all(x>=0 for x in slacks));ck(sum(slacks)==gap)
   rm,cm=data(I,B)
   Ibest={j for j in range(J) if rm[j]>0};Bbest={i for i in range(K) if cm[i]>0}
   rowwrong=sum(max(F(0),-rm[j]) if j in I else max(F(0),rm[j]) for j in range(J))
   colwrong=sum(max(F(0),-cm[i]) if i in B else max(F(0),cm[i]) for i in range(K))
   rowimp=c-cost(Ibest,B);colimp=c-cost(I,Bbest)
   ck(rowimp==rowwrong);ck(colimp==colwrong);ck(0<=rowimp<=gap);ck(0<=colimp<=gap)
   maxgap=max(maxgap,gap);maxrowimp=max(maxrowimp,rowimp);maxcolimp=max(maxcolimp,colimp)
   record=dict(I=I,B=B,cost=c,row_margins=rm,column_margins=cm,slacks=slacks)
   allcuts.append(record)
   if gap==0:
    ck(all(x==0 for x in slacks))
    strictI={j for j in range(J) if rm[j]>0};weakI={j for j in range(J) if rm[j]>=0}
    strictB={i for i in range(K) if cm[i]>0};weakB={i for i in range(K) if cm[i]>=0}
    ck(strictI<=I<=weakI);ck(strictB<=B<=weakB)
    optimal.append(record)
 ck(len(optimal)>0);ck(min(z['cost'] for z in allcuts)==opt)
 Imin=set.intersection(*(z['I'] for z in optimal));Imax=set.union(*(z['I'] for z in optimal));Bmin=set.intersection(*(z['B'] for z in optimal));Bmax=set.union(*(z['B'] for z in optimal))
 ck(cost(Imin,Bmin)==opt);ck(cost(Imax,Bmax)==opt)
 def cert(I,B):
  rm,cm=data(I,B)
  return dict(I=sorted(I),B=sorted(B),cost=cost(I,B),row_margins=rm,column_margins=cm,
   strict_row_bestresponse=sorted(j for j in range(J) if rm[j]>0),weak_row_bestresponse=sorted(j for j in range(J) if rm[j]>=0),
   strict_source_bestresponse=sorted(i for i in range(K) if cm[i]>0),weak_source_bestresponse=sorted(i for i in range(K) if cm[i]>=0))
 return dict(geometry=model['name'],M=M,Lambda=Lambda,primal=p,optimum=opt,deficit=sum(d)-opt,
  source_capacities=[Lambda*z for z in f],edge_capacities=[[M*z for z in rr] for rr in a0],
  cut_count=len(allcuts),optimal_cut_count=len(optimal),minimal_optimal_cut=cert(Imin,Bmin),maximal_optimal_cut=cert(Imax,Bmax),
  all_optimal_slack_max=max(max(z['slacks']) for z in optimal),
  optimal_row_tie_count_range=[min(sum(v==0 for v in z['row_margins']) for z in optimal),max(sum(v==0 for v in z['row_margins']) for z in optimal)],
  optimal_column_tie_count_range=[min(sum(v==0 for v in z['column_margins']) for z in optimal),max(sum(v==0 for v in z['column_margins']) for z in optimal)],
  max_cut_gap=maxgap,max_row_bestresponse_improvement=maxrowimp,max_source_bestresponse_improvement=maxcolimp,
  gap=F(0))
rows=[certify(model,M,F(1)) for model in models for M in (F(3,2),F(2))]
rows.append(certify(models[0],F(1),F(3,2)))
ck(len(rows)==7)
out=dict(scope='Exact finite complementarity and tie-safe bestresponse certificates on three actual interval incidence models; no continuous/history/root claim',
 executable=sys.executable,python=platform.python_version(),checks=checks,geometry=models,source_halfwidth=H,center_halfwidth=H,side=R,cases=rows,
 identities=dict(complementarity='cut-flow=unused rows Ic + unused sources B + unused edges I x Bc + backflow Ic x B',
 row_margin='d_j(1-M*pi_j(Bc))',column_margin='f_i(M*b_I(i)-Lambda), b_I=sum_I a0_ji/f_i',
 bestresponse='each row-only or column-only cut improvement equals weighted wrong-side margins and is <=current cut-opt; improvements are not added',
 tie_safe='strict row bestresponse subset I subset weak row bestresponse; strict source bestresponse subset B subset weak source bestresponse'),
 caveats=['All optimal cuts checked, not just chosen primal residual cut','No strictsets equality required on ties','M only unnormalized edge distortion; no retained conditional bound claimed','Lambda abstract source capacity, not project s','Partial records do not preserve full original marginal'],
 compute_index=dict(status='complete',command='/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python r466_numeric.py',
 arithmetic='Fraction BFS maxflow, exhaustive all cuts and all optimal cuts; compact extrema/slack certificates only',seconds=time.perf_counter()-start))
(ROOT/'r466_numeric.json').write_text(json.dumps(out,default=str,indent=2)+'\n')
print(sys.executable,'Python',platform.python_version())
for z in rows:print(z['geometry'],'M',z['M'],'Lambda',z['Lambda'],'opt',z['optimum'],'optimal cuts',z['optimal_cut_count'],'I extrema',z['minimal_optimal_cut']['I'],z['maximal_optimal_cut']['I'],'B extrema',z['minimal_optimal_cut']['B'],z['maximal_optimal_cut']['B'])
print('PASS',checks,'exact assertions; 7 cases;',sum(z['cut_count'] for z in rows),'cuts;',sum(z['optimal_cut_count'] for z in rows),'optimal cuts')
