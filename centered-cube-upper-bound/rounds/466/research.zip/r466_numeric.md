# R466：最优cut互补性、best response与tie-safe阈值

指定7例全部通过。对208个cuts验证精确四项互补性、行/列各自best-response改进及误差界；对全部24个最优cuts验证tie-safe包含关系。最优cut不唯一时，strict阈值集不必等于该cut。本结果是有限几何输运接口，不证明连续存在、原history或root价格。

## 输入与精确实现

同R464/465三个interval几何常数已复制入自含脚本：source中心0、1（第三图另加2），半宽1/100，各质量1；parent side6/5、centerblocks半宽1/100。父中心1/2、0分别捕获{0,1}、{0}；第三图父中心1/2、3/2、1分别捕获{0,1}、{1,2}、{1}。整块捕获/不捕获严格边距重核，各域内部两两不交（跨域允许相交）。d依次(1,1)、(1/2,3/2)、(1,1,1)。

a0_ji=d_jπ_ji。容量为row d_j、source Λ f_i、edge M a0_ji。每图仅(M,Λ)=(3/2,1),(2,1)，另第一图(1,3/2) tiecase，共7例。Fraction BFS残量增广路得primal；随后穷举全部record/source cuts，不依赖某一个残量cut。无浮点solver。

## 精确核验对象

令I、B为cut source-side的record和source集合。对每个cut、同一最优primal a，检查

cut−flow=Σ_{j∉I}(d_j−row_j)
+Σ_{i∈B}(Λf_i−col_i)
+Σ_{j∈I,i∉B}(Ma0_ji−a_ji)
+Σ_{j∉I,i∈B}a_ji。

四项各非负，最后一项是backflow，不能遗漏。所有最优cuts四项均零。

固定B的行side margin为r_j=d_j[1−Mπ_j(Bc)]；固定I的source margin为q_i=f_i[Mb_I(i)−Λ]，b_I(i)=Σ_{j∈I}a0_ji/f_i。行best-response改进精确等于Σ_{j∉I}(r_j)_++Σ_{j∈I}(−r_j)_+，列类似用q_i。分别核两种改进都≤cut−opt；没有把两个独立改进之和误称≤gap。

每个最优cut均满足

{Mπ_j(Bc)<1}⊆I⊆{Mπ_j(Bc)≤1}，
{Mb_I(i)>Λ}⊆B⊆{Mb_I(i)≥Λ}。

包含由同一cut自己的I、B计算。tie可以放任一侧；不能强求strictsets等于cut。

## 最小证书摘要

下表I_min/I_max、B_min/B_max分别为全部最优cuts的交/并；其配对本身也验证为最优cuts。编号均从0开始。

| 图 | M,Λ | opt | 最优cut数 | I_min → I_max | B_min → B_max |
|---|---|---:|---:|---|---|
| 两source等需求 | 3/2,1 | 7/4 | 1 | {0,1}→{0,1} | {0}→{0} |
| 同上 | 2,1 | 2 | 4 | ∅→{0,1} | ∅→{0,1} |
| 两source压力 | 3/2,1 | 11/8 | 1 | {0,1}→{0,1} | {0}→{0} |
| 同上 | 2,1 | 3/2 | 2 | {1}→{0,1} | {0}→{0} |
| 三source链 | 3/2,1 | 5/2 | 1 | {0,1,2}→{0,1,2} | {1}→{1} |
| 同上 | 2,1 | 3 | 10 | ∅→{0,1,2} | ∅→{0,1,2} |
| 第一图tiecase | 1,3/2 | 2 | 5 | ∅→{0,1} | ∅→{0} |

因此M=3/2的三个缺额图有明确且唯一的cut core，而饱和/端点参数包含非唯一ties。近优cut的每项补偿及单独best-response错误侧边距都由其cut−opt控制，但这是当前有限模型结论，不提供原几何cut的全局价格。

## 执行、范围与归档

实际1652项精确断言，包含geometry、flow、每cut及每optimal-cut断言；不是1652个独立样本。只有7参数例、208 cuts、24最优cuts。JSON只归档每例primal、容量、极端最优cuts的margins/bestresponse集、tie数范围、slack最大值0及gap0，未存巨大逐cut列表。

实际命令：

```
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/r466_numeric.py
```

Python3.12.14，标准库Fraction；无数学浮点误差，计时仅元数据。输出至脚本自身目录，无跨轮输入依赖。M只为未归一edge失真，未断言保留后条件密度≤M；Λ不是项目s。部分记录被删不称原边缘全保，未认证原目标容量存在性或history lift。

冻结白名单：r466_numeric.py、r466_numeric.json、r466_numeric.md。已完成停止。
