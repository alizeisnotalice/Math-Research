# R466：连续最优割的阈值、流支撑与定量稳定性

沿用 R465：有限 \(\nu,\mu\)，\(\pi_A=c_A\mu/m_A\)、\(m_A\ge m_0>0\)，\(\kappa=\nu\pi_A\)，\(1\le M<\infty\)、\(0\le\Lambda<\infty\)。最优流值为 \(V\)，最优割成本
\[
 C(I,B)=\nu(I^c)+M\kappa(I\times B^c)+\Lambda\mu(B),\qquad
 V=\min_{I,B}C(I,B).
\]
所有集合结论按 \(\nu\)、\(\mu\) 的零集理解。本稿给最优分配的支撑/出口结构，不证明几何缺额的根阶价格。

## 定理

定义实际可测负载
\[
 a_B(A)=M\pi_A(B^c),\qquad
 b_I(x)=\frac{d\kappa(I,\cdot)}{d\mu}(x)
       =\int_I\frac{c_A(x)}{m_A}\,\nu(dA).
\]
对任意最优割 \((I,B)\)，有安全阈值夹逼
\[
 \{a_B<1\}\subset I\subset\{a_B\le1\},\qquad
 \{Mb_I>\Lambda\}\subset B\subset\{Mb_I\ge\Lambda\}.          \tag{1}
\]
等号集合可以有正测度，不能任意丢弃而仍保持另一侧原严格公式。

存在模零集意义的最小最优割 \((I_-,B_-)\) 和最大最优割 \((I_+,B_+)\)，分别同时满足
\[
 I_-=\{a_{B_-}<1\},\quad B_-=\{Mb_{I_-}>\Lambda\},           \tag{2}
\]
\[
 I_+=\{a_{B_+}\le1\},\quad B_+=\{Mb_{I_+}\ge\Lambda\}.      \tag{3}
\]
这里是最小/最大的**最优割**，不是所有阈值固定点中的最小/最大者。特别当 \(M>1,\Lambda>0\) 时，空割总是严格响应的固定点，却未必最优，不能据此宣称从空集迭代求解。

令 \(\psi\) 为任意最优流，行密度
\(r_\psi(A)=\int\psi\,d\pi_A\)，源密度 \(g_\psi=d(\psi\kappa)_x/d\mu\)。
对任意割，有精确非负松弛恒等式
\[
 \begin{split}
 C(I,B)-V={}&\int_{I^c}(1-r_\psi)\,d\nu
 +\int_B(\Lambda-g_\psi)\,d\mu\\
 &+\int_{I\times B^c}(M-\psi)\,d\kappa
 +\int_{I^c\times B}\psi\,d\kappa.                          \tag{4}
 \end{split}
\]
所以最优割上四项分别为零：\(I^c\) 行饱和、\(B\) 来源饱和、正向跨割 \(I\times B^c\) 边达到 \(M\)、反向跨割 \(I^c\times B\) 不载流。缺额为
\[
 \delta=\nu(E)-V
 =\nu(I)-M\kappa(I\times B^c)-\Lambda\mu(B)
 =\int_I(1-r_\psi)\,d\nu.                                  \tag{5}
\]
这些是同一实际 \(\kappa\) 下的结论，不把辅助最优流称为原历史。

若 \(C(I,B)\le V+\varepsilon\)，则
\[
 \begin{split}
 \mathcal E_I&=\int_I(a_B-1)_+d\nu+\int_{I^c}(1-a_B)_+d\nu
 \le\varepsilon,\\
 \mathcal E_B&=\int_B(\Lambda-Mb_I)_+d\mu
              +\int_{B^c}(Mb_I-\Lambda)_+d\mu
 \le\varepsilon.                                          \tag{6}
 \end{split}
\]
因此任意 \(d>0\)，两侧各自“错边且阈值余量至少 \(d\)”的总测度分别至多 \(\varepsilon/d\)。这是相对于该割另一侧负载的稳定性，不是到某个固定最优割的无条件集合距离界。两项相加可用 \(2\varepsilon\)，不擅自改成 \(\varepsilon\)。若所用可行流也只有 \(\varepsilon'\)-最优，则 (4) 右侧之和至多 \(\varepsilon+\varepsilon'\)。

## 证明

固定 \(B\)，成本关于 \(I\) 的变量部分是
\(\int_I(a_B-1)d\nu\)。逐点最小化得到 (1) 第一式，且
\[
 C(I,B)-\inf_J C(J,B)=\mathcal E_I.
\]
固定 \(I\)，变量部分是 \(\int_B(\Lambda-Mb_I)d\mu\)，给第二式及
\(C(I,B)-\inf_D C(I,D)=\mathcal E_B\)。
两个单侧最小值均至少为 \(V\)，于是 (6) 成立。有限测度、核可测性及 \(m_0>0\) 保证这些负载和集合可测。

为同时处理 ties，设两割为 \((I_1,B_1),(I_2,B_2)\)。直接逐边展开：
\[
 \begin{split}
 C(I_1,B_1)+C(I_2,B_2)
 -C(I_1\cap I_2,B_1\cap B_2)-C(I_1\cup I_2,B_1\cup B_2)\\
 =M\kappa((I_1\setminus I_2)\times(B_2\setminus B_1))
  +M\kappa((I_2\setminus I_1)\times(B_1\setminus B_2))
 \ge0.                                                     \tag{7}
 \end{split}
\]
因此最优割对有限交、并封闭。取最优割序列，其
\(\nu(I)+\mu(B)\) 趋于所有最优割的下确界；依次取交。有限交仍最优，递减极限由有限测度支配收敛仍最优，而且达到该下确界。它与任何另一最优割相交仍最优；最小总测度迫使交集与它模零相同，所以它是最小最优割。递增并和上确界同理给最大者。

在最小最优割中，若 \(I_-\cap\{a_{B_-}=1\}\) 有正 \(\nu\) 测度，单侧删除它不改变成本却减小总测度，矛盾。对 \(B_-\cap\{Mb_{I_-}=\Lambda\}\) 同理。结合 (1) 得 (2)。最大割把遗漏的等号集合加入，得 (3)。

不能把这一步替换为任意一次交替严格响应。例如单父单源、\(\nu=\mu=1\)、\(M=\Lambda=1\) 时，割“全父、全源”最优；先对父作严格响应不变，再对源作严格响应得到“全父、空源”，仍最优，但父集合已包含等号点。规范极小选择是同时严格的“空父、空源”。

最后，把 \(\int\psi\,d\kappa\) 按 \(I/I^c\)、\(B/B^c\) 四块拆开，即得 (4)；四项非负来自原可行性。最优时各项为零，结合 \(\delta=\int(1-r_\psi)d\nu\) 得 (5)。没有假设来源之间独立或对实际 cube 的来源质量作密度上界。

## 本机复核及范围

实际运行 3 个 Fraction 容量模型，枚举 52 个割，116 项断言通过：核 (4)、(6) 及规范最小/最大最优割的同时严格/弱响应。包含正测度 ties、分数容量和零父权。它们是有限代数验证，不代替上述连续证明，也不是原 cube/history 模型。复现代码：

~~~python
from fractions import Fraction as F
from itertools import product
from collections import deque
def maxflow(nu,mu,pi,M,L):
    n=len(nu);m=len(mu);N=n+m+2;s=N-2;t=N-1
    r=[[F(0)]*N for _ in range(N)]
    for i in range(n):
        r[s][i]=nu[i]
        for j in range(m):r[i][n+j]=M*nu[i]*pi[i][j]
    for j in range(m):r[n+j][t]=L*mu[j]
    initial=[row[:] for row in r];V=F(0)
    while True:
        p=[-1]*N;p[s]=s;q=deque([s])
        while q and p[t]<0:
            u=q.popleft()
            for v in range(N):
                if p[v]<0 and r[u][v]>0:p[v]=u;q.append(v)
        if p[t]<0:break
        v=t;d=None
        while v!=s:
            u=p[v];d=r[u][v] if d is None else min(d,r[u][v]);v=u
        v=t
        while v!=s:
            u=p[v];r[u][v]-=d;r[v][u]+=d;v=u
        V+=d
    return V,[[initial[i][n+j]-r[i][n+j] for j in range(m)] for i in range(n)]
cases=[
([F(1)],[F(1)],[[F(1)]],F(1),F(1)),
([F(1),F(2)],[F(2),F(1)],[[F(1,3),F(2,3)],[F(3,4),F(1,4)]],F(2),F(1,2)),
([F(1),F(0),F(1,2)],[F(1),F(2)],[[F(1,4),F(3,4)],[F(1,2),F(1,2)],[F(2,3),F(1,3)]],F(3,2),F(3,4))]
checks=cutsn=0
for nu,mu,pi,M,L in cases:
    n=len(nu);m=len(mu);V,flow=maxflow(nu,mu,pi,M,L);opts=[]
    for I in product([0,1],repeat=n):
        for B in product([0,1],repeat=m):
            cost=(sum(nu[i] for i in range(n) if not I[i])
              +M*sum(nu[i]*pi[i][j] for i in range(n) for j in range(m) if I[i] and not B[j])
              +L*sum(mu[j] for j in range(m) if B[j]))
            gap=cost-V
            a=[M*sum(pi[i][j] for j in range(m) if not B[j]) for i in range(n)]
            t=[M*sum(nu[i]*pi[i][j] for i in range(n) if I[i])/mu[j] for j in range(m)]
            ei=sum(nu[i]*(max(F(0),a[i]-1) if I[i] else max(F(0),1-a[i])) for i in range(n))
            eb=sum(mu[j]*(max(F(0),L-t[j]) if B[j] else max(F(0),t[j]-L)) for j in range(m))
            assert 0<=ei<=gap and 0<=eb<=gap;checks+=1
            sl=[sum(nu[i]-sum(flow[i]) for i in range(n) if not I[i]),
                sum(L*mu[j]-sum(flow[i][j] for i in range(n)) for j in range(m) if B[j]),
                sum(M*nu[i]*pi[i][j]-flow[i][j] for i in range(n) for j in range(m) if I[i] and not B[j]),
                sum(flow[i][j] for i in range(n) for j in range(m) if not I[i] and B[j])]
            assert min(sl)>=0 and sum(sl)==gap;checks+=1;cutsn+=1
            if gap==0:opts.append((I,B))
    for mode in [0,1]:
        I=[(all if mode==0 else any)(o[0][i] for o in opts) for i in range(n)]
        B=[(all if mode==0 else any)(o[1][j] for o in opts) for j in range(m)]
        a=[M*sum(pi[i][j] for j in range(m) if not B[j]) for i in range(n)]
        t=[M*sum(nu[i]*pi[i][j] for i in range(n) if I[i])/mu[j] for j in range(m)]
        assert all(nu[i]==0 or I[i]==(a[i]<1 if mode==0 else a[i]<=1) for i in range(n));checks+=1
        assert all(B[j]==(t[j]>L if mode==0 else t[j]>=L) for j in range(m));checks+=1
print("PASS",checks,"Fraction checks over",cutsn,"cuts and 3 capacity models")
~~~
