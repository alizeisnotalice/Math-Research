# R466：最优拥挤来源的高质量外父负载

**范围。** 同一实际接受流 \(P\) 的父边缘为 \(\nu\le S\sigma\)，\(\sigma=q_A dA\)，\(m_A=f(Q_A)=q_AR_A^n\)，\(q\le q_A\le\lambda\)，\(r=\lambda/q\)。取 R465 达到的最优割 \((I,B)\)。只使用其来源端最佳响应
\[
 b_I(y):=\int_I\frac{c_A(y)}{m_A}\nu(dA)
 \ge\Lambda/M\quad(\mu\text{-a.e. }y\in B),\qquad\mu=fdy.
\tag{1}
\]
等号来源可属于任一侧；不要求严格不等式。父端仍有 \(M\pi_A(B^c)\le1\) 对 \(\nu\)-几乎所有 \(A\in I\)。下述新定量桥适用于任意满足 (1) 的割，不额外假设最优割可测选择随参数变化。

## 1. 一个实际几何估计

对任意实际接收者 \(u\) 和来源 \(y\in Q_u\)，假设其原 own-past
\[
 Z_u(y)=\int_{m_A<m_u/K}c_A(y)\frac{dA}{m_A}\le h.
\]
该条件适用于原 canonical 终端来源，不给新接收者任何历史资格。任意 \(\kappa\ge1\)，定义保实际父边缘的外父负载
\[
 F_{I,u}^{\kappa}(y)=
 \int_{\substack{A\in I,\ m_A>\kappa m_u\\A\notin Q_u}}
 \frac{c_A(y)}{m_A}\nu(dA).
\]
则
\[
 \boxed{F_{I,u}^{\kappa}(y)\ge
 \left[\frac\Lambda M-S\lambda h
       -Sr\{1+\log(\kappa K)\}-\frac{Sr}{\kappa}\right]_+}
 \quad(y\in B).
\tag{2}
\]
**方向不可交换：**这里的外侧是父中心 \(A\notin Q_u\)，不是原终端外父门 \(u\notin Q_A\)。较大父仍可能捕获中心 \(u\)。本结论不将 R462 的终端外父条件或任何原历史移植到新增父关联。

这个结论同时使用真实来源、匹配质量和实际中心 Lebesgue 体积；它不是将某个边界体积当成 \(f\) 质量。

**完整分层证明。** 将 \(b_I(y)\) 的父精确分成
\[
 m_A<m_u/K;\quad m_u/K\le m_A\le\kappa m_u;\quad
 m_A>\kappa m_u, A\in Q_u;\quad
 m_A>\kappa m_u, A\notin Q_u.
\]
第一项由 \(\nu\le S\lambda dA\) 和原 own-past 至多 \(S\lambda h\)。

对第二项，固定 \(y\)，实际中心集合满足
\[
 |\{A:c_A(y)=1,m_A\le t\}|\le t/q.
\tag{3}
\]
因为 \(R_A^n\le t/q\)，这些中心全在以 \(y\) 为中心、边长 \((t/q)^{1/n}\) 的盒内。对任何闭质量窗 \([l,H]\)，用
\(m^{-1}=H^{-1}+\int_m^H t^{-2}dt\) 和非负 Tonelli，得到
\[
 \int_{l\le m_A\le H}c_A(y)\frac{dA}{m_A}
 \le\frac1q\{1+\log(H/l)\}.
\tag{4}
\]
这包含上下端质量原子，不要求半径分布连续。代 \(l=m_u/K,H=\kappa m_u\)，再乘 \(S\lambda\)，得到第二项价格。

第三项直接用**中心**限制 \(A\in Q_u\)：
\[
 \int_{\substack{A\in I\cap Q_u\\m_A>\kappa m_u}}
 \frac{c_A(y)}{m_A}\nu(dA)
 \le\frac{S\lambda|Q_u|}{\kappa m_u}
 =\frac{S\lambda}{\kappa q_u}\le Sr/\kappa.
\tag{5}
\]
没有对来源密度作上界。第四项正是 \(F\)，故 (1)–(5) 证明 (2)。

## 2. 根尺度参数与原流上的准确作用

取 \(\kappa=K=e^{\sqrt n}\)、\(h=s/(\varepsilon_0q)\)、\(s=1+\sqrt n\)。则 (2) 的三个减项合计为
\[
 Sr\left[\frac{s}{\varepsilon_0}+1+2\sqrt n+e^{-\sqrt n}\right].
\tag{6}
\]
若 \(\Lambda=C_\eta s\)，所有减项都是显式根尺度，而非线性 \(n\)。例如选 \(C_\eta/M>Sr(\varepsilon_0^{-1}+3)\) 即使方括号下界为正。设其正部为 \(d_\Lambda\)。保原全部记录、终端及接受权时，(2) 可以直接积分成
\[
 d_\Lambda P\{y\in B\}
 \le\int 1_B(y)F_{I,u}^{K}(y)\,P(d\xi).
\tag{7}
\]
这里 \((u,y)\) 是该记录中实际 own-low 终端与其固定来源；另一端同理。没有独立刷新来源或用父后验替换实际条件分布。式 (7) 的右侧是新父与原记录之间的实际共同来源负载，新增父来自 \(\nu|_I\)，但 \((A,u)\) **不是**因此取得原历史的边。

**未付步骤。** (2) 证明：最优割的高拥挤来源不能只由 own-past、可比质量或位于小接收者内的父中心解释；足够大的拥挤阈值迫使来源同时被大量更重、中心在 \(Q_u\) 外的实际割父捕获。但目前没有原流合同能把 (7) 右侧的跨父重复结算为 \(\mu(B)\) 的根阶费用。正删除接受权后仅剩 \(F\le b_I\le SA_n\)，从而是 \(SA_nP\{y\in B\}\)；这不是所需上界。

父端厚度并不保证这些额外父构成来源不交家族。强制它们承担原记录、或把 \(f1_B\) 重新当输入，会改变质量秩和阶段合同。因此本附件给一项全类定量几何桥，不宣称缺额已付，也不额外添加任何旧费用。下一步确切需要为 (7) 中同一原来源通过不同 \(I\)-父的实际重复提供可加列预算。

## 3. 本机核验与范围

指定 Python 实跑 36 项 Fraction 断言。原生一维场为 \(f=1_{[-10,10]}\)，\(E=[-1,1]\)，\(R_A=1\) 若 \(|A|\le d\)，否则 \(R_A=2\)。全部 \(m_A=R_A\)、\(q_A=1\)。选 \(u=y=0,R_u=1\)，诊断中取辅助质量阈值 \(K_{\rm test}=2\)；它不是 \(n=1\) 时原合同的 \(K=e\)。代码只核这个辅助阈值下的分层，一般 \(\kappa=K\) 的解析结论始终使用原 \(K=e^{\sqrt n}\)，不受影响。九组 \((d,\kappa)\) 精确核质量分层及中心内部项 (5)。这只核真实匹配几何，不满足原高秩历史，不认证存在最优厚割。

```python
from fractions import Fraction as F
count=0
for d in (F(1,8),F(1,4),F(3,8)):
 for kappa in (F(1),F(5,4),F(3,2)):
  low=F(0)
  middle=2*d
  high_inside=(1-2*d)/2
  high_outside=F(1,2)
  total=2*d+(2-2*d)/2
  assert total==low+middle+high_inside+high_outside;count+=1
  assert high_inside<=1/kappa;count+=1
  assert all(m>kappa for m in [F(2)]);count+=1
  assert high_outside==total-middle-high_inside;count+=1
print('PASS',count,'Fraction checks: 9 native matched 1D parameter cases; no original high-rank/history claim.')
```

```text
PASS 36 Fraction checks: 9 native matched 1D parameter cases; no original high-rank/history claim.
```
