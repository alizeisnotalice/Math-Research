# 第466轮：最优缺额集合的双侧几何与低秩落点

## 目标与本轮边界

第465轮已证明连续容量极值公式。本轮不重证存在性，而研究最优集合必须满足的两侧条件，以及这些条件如何与实际own-low终端相遇。目标仍为同一完整原流R<=eta X+C_eta sqrt(n)polylog(n)W；没有把固定点条件或有限模型当作该预算的证明。

固定mu=f dx、nu=P_A<=S sigma、kappa=nu pi_A、有限M>=1及Lambda>=0。对cut父集I和来源集B，成本
\[
C(I,B)=\nu(I^c)+M\kappa(I\times B^c)+\Lambda\mu(B),
\quad V=\min C,\quad\delta=R-V.
\]
所有nu来自实际原记录；对辅助来源的最优分配不重建旧历史。

## 双侧最优性与可计量的近优误差

令b_I(x)=int_I 1_QA(x)/m_A nu(dA)。任意最优cut有
\[
\{M\pi_A(B^c)<1\}\subset I\subset\{M\pi_A(B^c)\le1\}
\quad(\nu\text{-a.e.}),
\]
\[
\{Mb_I>\Lambda\}\subset B\subset\{Mb_I\ge\Lambda\}
\quad(\mu\text{-a.e.}).
\]
等号位置不能随意当严格不等式。固定另一侧时，错误放置的边距积分准确等于该侧最佳响应的成本改善。例如a_B(A)=1−M pi_A(Bc)，
\[
C(I,B)-\min_J C(J,B)
=\int_{I^c}(a_B)_+d\nu+\int_I(-a_B)_+d\nu.
\]
来源侧以Mb_I−Lambda作同样表达。若C<=V+epsilon，每个改善分别<=epsilon；不能把两个独立改善之和也写成epsilon。

最优cut对交并封闭；有限测度下可选mod-null最小与最大最优cut。最小最优cut可同时满足两侧严格阈值式，最大者同时满足两侧非严格式（详见complement）。这不是最小/最大固定点定理。尤其空集合可成为非最优固定点，不能从空集合交替迭代就宣称求出最优cut。

## 四项互补性保全部回流

令a=psi kappa为任意可行分配，r_a和c_a为其行/列边缘。直接分块得到
\[
C(I,B)-a(E\times\mathbb R^n)
=[\nu(I^c)-r_a(I^c)]
+[\Lambda\mu(B)-c_a(B)]
+[M\kappa(I\times B^c)-a(I\times B^c)]
+a(I^c\times B).
\]
四项非负，最后回流项不能丢。最优分配及最优cut下四项均为零。若分配差epsilon_p、cut差epsilon_c，四项之和<=epsilon_p+epsilon_c，只记一次误差。此式保持真实接收measure与所有源质量分母，但没有自动减小delta。

## 真实低秩落点给出的定量父负载

设原终端u与来源y满足y∈Q_u、Z_u(y)<=h，且y∈B。采用任意最优cut的非严格源阈值即可得b_I(y)>=Lambda/M（在mu及实际source边缘意义下）。对κ0>=1，按父质量和父中心位置分三块：

- m_A<m_u/K，用原own-low秩，费用<=S lambda h；
- m_u/K<=m_A<=κ0 m_u，用真实中心子水平体积界，费用<=S r[1+log(κ0 K)]；
- m_A>κ0 m_u且A∈Q_u，用真实中心体积|Q_u|，费用<=S r/κ0。

这里r=lambda/q，K=exp(sqrt(n))。因而实际剩余父负载
\[
\int_{I:\,m_A>\kappa_0m_u,\ A\notin Q_u}
 \frac{1_{Q_A}(y)}{m_A}\nu(dA)
\ge\left[\frac\Lambda M-S\lambda h
-Sr(1+\log(\kappa_0K))-\frac{Sr}{\kappa_0}\right]_+.
\]
取κ0=K时扣除的三项都是显式根阶量（保eps0、r、S），故足够大的根阶Lambda会迫使这些高质量、中心外置的实际父继续承受负载。中间块是中心Lebesgue子水平估计，不是对f的密度帽；完整证明见geometry。

关键区别：A∉Q_u表示父中心在child cube外，**并不推出u∉Q_A**。新增父也不继承原记录的stage/路径资格。因此这条强制负载下界不能直接塞回旧父外积分作为递推或收缩。尚需对这份共享负载证明实际可求和上界，或找到保持原记录的收费映射。本轮未得到该步骤。

## 完整总账与实际核验

原R433拆分、母入口倍率及全部旧费用保留；最优cut缺额delta仍未到eta X，故未支付一般中间硬层。局部最优性和容量互补性是后续可用的几何约束，不替代一般根阶预算。

实际有限计算使用指定Python，仅三个旧区间模型的7组参数，枚举208cuts、24最优cuts，1652项精确断言；不是1652个独立样本。原hard需求/history未被模拟。其他作者有限复核及主代理隔离复现见最终附件。复用1 Astra high、2 Sol high、1 Sol medium；无独立Luna任务，实际扣额不可得。保详细LaTeX和必要复现，不编译PDF。

主代理已在隔离目录实际重放geometry的36项分层检查、complement的116项阈值/互补性检查及numeric的1652项断言；stdout一致，完整numeric JSON除计时相同。有限分层中的K=2仅作辅助参数，不能当n=1时原K=e的历史样本。一般根尺度式使用原K=exp(sqrt(n))的解析证明。
