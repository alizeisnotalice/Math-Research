#!/usr/bin/env python3
"""Finite real-profile diagnostics for R295; mathematical proof is in the note."""
import sys
try:
 import mpmath as mp
except ImportError:
 sys.path.insert(0,'/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor')
 import mpmath as mp
mp.mp.dps=35
half=mp.mpf('.5')
def phi(x):
 x=abs(x)
 if x<=half: return 1-mp.expint(3,half-x)-mp.expint(3,half+x)
 return mp.expint(3,x-half)-mp.expint(3,x+half)
def outside(fun): return 2*mp.quad(lambda t:fun(phi(half+t)),[0,1,4,12,40,mp.inf])
def core(fun): return 2*mp.quad(lambda x:fun(phi(x)),[0,half])
c=phi(half); d=phi(mp.mpf(0)); T=mp.mpf(2)/3-2*mp.expint(4,1)
C=outside(lambda p:mp.sqrt(p)*mp.log(1/p))
A=2*T+mp.sqrt(mp.e)*C
Q=mp.sqrt(mp.e)*(T+C/2)
CL=mp.pi*mp.sqrt(Q)/2+(d-c)/(4*c)
print('c,d,T,C,A,Q,C_L=',*[mp.nstr(x,20) for x in [c,d,T,C,A,Q,CL]],flush=True)
count=0
for alpha in map(mp.mpf,['0.5','0.9','0.99']):
 B=outside(lambda p:p**alpha)
 prev=mp.mpf(1)
 for s in [mp.mpf(1)/512,mp.mpf('.1'),mp.mpf(1)]:
  aa=core(lambda p:(1-s+s*p)**alpha)
  Z=aa+s**alpha*B
  q=s**alpha*B/Z
  length=2*mp.asin(mp.sqrt(q))+alpha*mp.log((1-s+s*d)/(1-s+s*c))/2
  exact_R_n1=1+s**alpha*B
  assert Z>=prev-mp.mpf('1e-28')
  assert Z<=exact_R_n1+mp.mpf('1e-28')
  assert exact_R_n1<=Z*(1+length/2)+mp.mpf('1e-28')
  delta=1-alpha
  rhs=delta*s*(c**(-delta)*T+s**(-delta)*(T*mp.log(1/s)+C))
  assert Z-1<=rhs+mp.mpf('1e-28')
  # Exact escort Fisher decomposition, using the same actual phi.
  m1=core(lambda p:(1-s+s*p)**alpha*(p-1)/(1-s+s*p))
  m2=core(lambda p:(1-s+s*p)**alpha*((p-1)/(1-s+s*p))**2)
  outside_mass=s**alpha*B
  mean=(m1+outside_mass/s)/Z
  second=(m2+outside_mass/s**2)/Z
  J=alpha**2*(second-mean**2)
  core_mean=m1/aa
  core_var=m2/aa-core_mean**2
  qp=alpha*q*(1-q)*(1/s-core_mean)
  decomposed=qp**2/(q*(1-q))+(1-q)*alpha**2*core_var
  assert abs(J-decomposed)<=mp.mpf('1e-26')*max(1,abs(J))
  prev=Z; count+=1
  print('profile alpha,s,Z,length=',*[mp.nstr(x,12) for x in [alpha,s,Z,length]],flush=True)
for n,S in [(512,1),(1000000,1),(1000000,mp.log(1000002)),(1000000,mp.log(1000002)**2)]:
 sigma=max(min(mp.mpf(S)/n,1),mp.mpf(1)/n)
 D=n*sigma; ell=mp.log(1/sigma)
 delta=1/(2*(1+A)*(1+D)*(1+ell)); alpha=1-delta
 B=outside(lambda p:p**alpha)
 Z=core(lambda p:(1-sigma+sigma*p)**alpha)+sigma**alpha*B
 q=sigma**alpha*B/Z
 length=2*mp.asin(mp.sqrt(q))+alpha*mp.log((1-sigma+sigma*d)/(1-sigma+sigma*c))/2
 assert n*mp.log(Z)<=mp.mpf('.5')+mp.mpf('1e-25')
 assert 1+mp.sqrt(n)*length/2<=1+CL*mp.sqrt(D)+mp.mpf('1e-25')
 count+=1
 print('adaptive n,D,delta,nlogZ,prefactor=',n,*[mp.nstr(x,12) for x in [D,delta,n*mp.log(Z),1+mp.sqrt(n)*length/2]],flush=True)
gate_count=0
for n,D in [(512,1),(1000000,1),(1000000,mp.log(1000002)),(1000000,mp.log(1000002)**2)]:
 ell=mp.log(mp.mpf(n)/D)
 P=2*(1+A)*(1+D)*(1+ell)
 for r in map(mp.mpf,['1e-100','1','1e100','1e10000']):
  Qr=1+max(0,mp.log(r))
  delta=1/max(P,Qr)
  assert delta<=1/P
  assert delta*mp.log(r)<=1
  assert 1/delta<=P+Qr
  gate_count+=1
print('PASS real-phi moment, escort Fisher, cancellation, and adaptive checks=',count,flush=True)
print('PASS arbitrary-M logarithmic threshold checks=',gate_count,flush=True)
