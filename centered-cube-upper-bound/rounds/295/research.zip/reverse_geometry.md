# R295: reverse hard-scale source payment on the large-soft orientation

## 1. Precise general joint inequality

Keep the ORIGINAL positive traffic

    dT=q(x)^(-1)p_(s(x),L(x))(x-y)h_(R(x))(x-z)
             a_omega(x,y,z) dx beta(dy)nu(dz),

with true receiver Lebesgue measure, a<=L,R<=b<=2a, q_-=3lambda/4<=q(x)<=lambda, the original FIRST condition integral p_(s,L)(x-y)beta(dy)<=q(x), the original maximal hard cap, and all original accepted, forbidden-source, history, and terminal masks. The original unique band is

    c_(j+1)<=min(L,R)/sqrt(LR)<=c_j,
    c_j=gamma^(-j), gamma=1+1/n, j>=0.

Let g=sqrt(LR), ell=1+log n, and retain the FULL original mass

    e_g(y)=integral_(Z_g(y)) w_g(y,z)nu(dz),
    m=e_g(y)/(ell q(x)c_j^(-n/2)g^n).

Fix M>0. Throughout this note the actual branch is

    low: p_y e_g(y)<2Kq(x),  high: m>M,  orientation: L>R.

No q_+ freezing or O(sqrt(n)) threshold shift is necessary for the following theorem. In particular it also applies to the narrower m>M+d0 branch studied in R294.

Let omega(y,z) be ANY measurable frozen fractional pair allocation with 0<=omega<=1, independent of receiver x, actual scale selection, and the auxiliary clock. It may depend on the original frozen sources and outer data. Put

    b_omega(z)=integral omega(y,z)beta(dy),
    X_omega(z)=2K b_omega(z)/(ell M q_- a^n),
    A=(b/a)^n,
    d=(3n/2)log gamma,
    F_A(u)=min(1,u)+integral_1^A min(1,u/v)dv/v,
    Psi_(n,A)(u)=sum_(j=0)^infinity F_A(u exp(-dj)).

Then the original traffic weighted by omega satisfies the GENERAL mixed-source estimate

    T_(low,m>M,L>R;omega)
        <=integral nu(dz) Psi_(n,A)(X_omega(z)).          (R1)

This is a source-weighted geometric estimate, not merely a weak norm of a point kernel. It uses the actual original FIRST only, never a symmetric FIRST assertion for nu. The actual hard cap remains an original qualification; this proof does not need to consume it. It requires neither a density bound nor nu<=beta. Its right side is explicit and contains no receiver selector or surrogate posterior.

There is an all-band root-priced consequence. If the frozen allocation satisfies, for nu-almost every z,

    b_omega(z)<= [ell M q_- a^n/(2K)] exp(n^(1/4)),        (R2)

then

    T_(low,m>M,L>R;omega)<=8sqrt(n) W_nu.                 (R3)

The original low-raw outer factor Lambda multiplies (R1) or (R3) once. All-softness and arbitrary wide displacement are allowed; there is no R_delta or Csoft_n fee in these bounds. There is no claim that omega=1 always meets (R2). The remaining source-concentration issue is stated precisely in section 6.

## 2. Original low-pe creates a small hard-scale height

On actual low and high, the two original inequalities give

    p_y<2K c_j^(n/2)/(ell M g^n).

For L>R, the smaller scale is R, and R/g<=c_j. Therefore g>=R/c_j and

    p_y<alpha_j R^(-n),
    alpha_j=2K c_j^(3n/2)/(ell M).                        (R4)

This is the key orientation change. Normalizing at the larger soft scale L gave the growing factor c_j^(-n/2) in R294. Normalizing the very same actual p at the hard physical scale R gives the decreasing factor c_j^(3n/2). The complete original e cancels algebraically between its actual low gate and actual m definition. It has not been localized, replaced by beta mass, or compared to a pair-parent mass.

For fixed original receiver x and hard source z, first integrate beta, retaining low, high, and band masks until using (R4). Original FIRST yields

    integral omega(y,z)(p_y/q(x))1_actual_branch beta(dy)<=1.

The height bound also yields

    integral omega(y,z)(p_y/q(x))1_actual_branch beta(dy)
        <=alpha_j b_omega(z)/(q_- R(x)^n).

Thus their combination is

    integral omega(y,z)(p_y/q(x))1_actual_branch beta(dy)
        <=min{1,B_j(z)/R(x)^n},
    B_j(z)=alpha_j b_omega(z)/q_-.                        (R5)

The first bound follows because omega and all positive masks are at most one; it does not assert FIRST for a new source at other receivers. The second follows from the actual gate before any masks are dropped. Both therefore hold simultaneously at every originally qualified receiver. All fractions are harmless when b_omega=0: the corresponding contribution is zero.

## 3. Exact hard physical-scale envelope

For any B>=0 and z, the exact scale-envelope integral is

    integral_(R^n) sup_(a<=R<=b)
          R^(-n)1_(Q_R(z))(x)min{1,B/R^n}dx
        =F_A(B/a^n).                                    (R6)

To prove it, write r=2|x-z|_infinity. The coefficient R^(-n)min(1,B/R^n) is nonincreasing in R. On Q_a(z), the supremum is its value at a. For a<r<=b, it is its value at R=r, and it is zero for r>b. Since |Q_r|=r^n, positive radial integration gives

    min(1,B/a^n)+n integral_a^b min(1,B/R^n)dR/R.

Substitution v=(R/a)^n proves (R6), including B=0, a=b, hard faces, and all threshold equalities. Hard faces have fixed source z and a geometric supremum; no assertion about a null selector graph is needed. The supremum is explicitly measurable.

For later numerical evaluation, the exact scalar function is

    F_A(u)=u(2-1/A),                   0<=u<=1;
    F_A(u)=2+log u-u/A,                1<=u<=A;
    F_A(u)=1+log A,                    u>=A.              (R7)

These branches agree at the endpoints. When A=1 use F_1(u)=min(1,u).

Apply (R5), then bound the selected hard scale by the supremum in (R6), and use positive Tonelli over the original nu. This gives

    T_(branch,j;omega)
       <=integral nu(dz)F_A(X_omega(z)c_j^(3n/2)).

Now sum the original unique bands. There is no source-disjointness claim: the right side explicitly sums their costs. Extending to all j>=0 only enlarges the sum. Since c_j^(3n/2)=exp(-dj), this proves (R1). In contrast to the previous large-soft orientation, this all-band sum is convergent, with no softness moment.

## 4. Explicit logarithmic price and the root threshold

The elementary majorant

    F_A(u)<=f(u),
    f(u)=2u                  for 0<=u<=1,
    f(u)=2+log u             for u>=1

is uniform over A>=1. If 0<=u<=1, the geometric series gives

    Psi_(n,A)(u)<=2u/(1-exp(-d)).                         (R8)

For u>=1, the function t↦f(u exp(-dt)) decreases, so comparison of the sum after its first term with an integral gives

    Psi_(n,A)(u)
      <=f(u)+(1/d)integral_0^u f(v)dv/v
      =2+log u+[2+2log u+(log u)^2/2]/d.                 (R9)

This bound is source linear in nu, with an explicit logarithmic-square dependence on the beta column mass. It is not a claim that such a dependence is universally bounded independently of sources.

By the binomial inequality gamma^n=(1+1/n)^n>=2,

    d>=(3/2)log 2=:d_min.

For 1<=u<=exp(n^(1/4)), set t=n^(1/4)>=1. Equations (R9) and t^2=sqrt(n) give

    Psi(u)<=[3+4.5/d_min]sqrt(n)<8sqrt(n).

For 0<=u<=1, (R8) is at most 2/(1-2^(-3/2))<8<=8sqrt(n). This proves (R3). The constants are not optimized. In particular all fees associated with the original scale window and all ratio bands have been retained before this numerical simplification.

## 5. What source conservation permits

The pair allocation omega is frozen before receiver integration. No arbitrary favorable allocation can be chosen independently for each receiver. Once omega is fixed, (R1) uses its actual beta column masses and charges each original hard-source point z once through the integral against nu. A source may occur in many original bands, but the convergent series in Psi is its full fee.

For example, omega=1 satisfies (R2) whenever the TOTAL original beta mass is at most the displayed capacity. In that case (R3) pays the entire large-soft, low, high-m branch, regardless of source geometry or separation. More generally, omega may select any measurable beta subset separately for each z, or use fractional weights, as long as its actual mass b_omega(z) is bounded. No spatial box, fixed offset, density cap, or local replacement of e is required.

If several such allocations are summed, their nu fees must also be summed unless an explicit source allocation prevents duplication. In particular, partitioning beta into many pieces and applying (R3) separately to every piece against the full nu would charge W_nu once per piece. That is not a free coverage argument.

There is a canonical frozen allocation with a particularly transparent exact ledger. Let Qcap=ell M q_- a^n exp(n^(1/4))/(2K), and choose any measurable omega satisfying its column budget. Then

    original traffic = original traffic times omega
                     + original traffic times (1-omega).

The first part is paid by (R3). Nothing in the argument makes the second term vanish. Thus the theorem proves a genuine all-orientation-band source payment under an explicit column capacity, rather than claiming a global root bound from free splitting.

## 6. Exact remaining issue and bounded outcome

The generic estimate (R1) applies directly to omega=1 and gives

    T_(low,m>M,L>R)
       <=W_nu Psi_(n,A)(2K W_beta/(ell M q_- a^n)).        (R10)

It improves the former growing-band and full-soft-moment interface to a logarithmic-square concentration cost. It is not uniformly bounded by root-polylog times W_beta+W_nu, because the displayed global source-mass scale remains. No unsupported relation between W_nu, lambda a^n and W_beta is assumed.

A sufficient further source-conserving bridge would allocate the actual original large-soft traffic into frozen pair weights omega_k with controlled beta column masses and total charged hard-source mass of root-compatible size, or exploit spatial kernel decay to replace the global column mass in (R10) by a localized one while proving its nu-weighted logarithmic budget. Such a bridge must pay repeated source use and preserve original low/pe and FIRST. It is not supplied by simply partitioning beta, or by replacing original e with that local mass.

The proved result of this note is (R1), with the exact hard-envelope formula (R6)-(R7), the convergent all-band price (R8)-(R9), and the explicit arbitrary-displacement root branch (R2)-(R3). The small-soft orientation is not re-proved here. The original complementary m<=M traffic and the source-concentration remainder beyond (R2) remain unpaid by this note.

## 7. Reproducible finite verification and freeze

The script /tmp/r295_reverse_checks.py was actually run. It verifies the scalar column sum and its logarithmic/root bounds at 40 and 60 Decimal digits in three stages: initial dimensions 1,2,3; boundary/scale cases at 8,32,100; and wider dimensions 1000,10000. Each precision checks 120 parameter cases, including A=1, x=0, x=1, x=A, and the root-capacity endpoint exp(n^(1/4)). Once a summand's argument falls below one, the remaining series is summed by its exact geometric formula, rather than using a finite truncation as the infinite sum. The maximum normalized 40/60 difference was 2.356076833145487190114002381e-39.

In addition, 150 exact Fraction calculations check finite hard-scale envelope integrals on nested menus against (R6)-(R7), including scale/height threshold equalities and monotone menu refinement. All checks passed. Results are saved in /tmp/r295_reverse_checks.json. These are finite numerical diagnostics; the general proofs are sections 2-4. The diagnostics do not certify that the original complete traffic satisfies the column budget (R2).

The reverse mechanism was independently screened before this freeze: the c_j^(3n/2) exponent, FIRST integration order, hard-scale envelope, convergent band sum, and conditional nu-source root price all passed. Final file-level audit is requested on the frozen artifact.
