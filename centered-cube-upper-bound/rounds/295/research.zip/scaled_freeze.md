# R295: scale-compensated freezing removes the additive mass threshold loss

## 1. Exact task and inherited objects

Retain original positive traffic T with integrand p_y h_R/q, original beta and nu, true receiver dx, all original masks, FIRST integral p beta<=q, and accepted hard cap h_R*nu<=4lambda. Let q in[q_-,lambda], q_-=3lambda/4, g=sqrt(LR), a<=L,R<=b, and the original unique ratio band c_+<=min(L,R)/g<=c, c=c_j, c_+=c/gamma, gamma=1+1/n. Let ell=1+log n. The ORIGINAL mass and gate are

    e_(j,g;q)(y)=integral_(Z_(j,g;q)(y)) w_(j,g)(y,z)nu(dz),
    m=e_(j,g;q)/(ell q c^(-n/2)g^n),
    low: p_y e_(j,g;q)<2Kq.

The source weight is nonincreasing in g, lies in[0,1], and the original tree threshold is

    H_j(t;q)=q t^n J_j(t),
    J_j(t)=max{1,sqrt(n)c_+^n,sqrt(n)(t/b)^n}.

The light block is the coarsest path cell of nu-mass <=H_j, with the same finest-cell fallback if none qualifies. Z uses its complement intersected with the original frozen D_V(y). All original source data and the posterior mass remain unchanged.

R294 froze the tree threshold at lambda at the SAME scale, losing an additive d0=4sqrt(n)/(3ell) in m. The following compensation removes that loss by paying a short scale strip instead. It does not assume a bound on individual tree jumps.

## 2. Compensated source comparison

Put rho_q=(lambda/q)^(1/n), rho_0=(4/3)^(1/n), and t=g/rho_q. Extend the AUXILIARY frozen source mass e^+_j(y,t), defined by the same original tree, distance restriction and overlap weight at threshold H_j(t;lambda), to

    I_j^ext=[a/(c rho_0),bc].

This is a source-only extension of explicit formulas. No receiver kernel or FIRST/hard cap is invoked outside its original physical window. Here alpha=c t/b remains positive and at most one, so the original overlap weight formula remains valid and monotone. Empty original bands are omitted.

Because J_j is nondecreasing,

    H_j(t;lambda)=lambda t^n J_j(t)
                 =q g^n J_j(t)<=q g^n J_j(g)=H_j(g;q).

Thus A^+_(j,t)(y) subset A_(j,g;q)(y), Z^+_(j,t)(y) superset Z_(j,g;q)(y), and w_(j,t)>=w_(j,g). The coarsest-node convention preserves inclusion also under fallback: the smaller threshold cannot have a larger selected path cell. Therefore

    e^+_j(y,g/rho_q)>=e_(j,g;q)(y).                     (S1)

In the opposite direction at an unchanged or larger scale, e^+_j(y,u)<=e_(j,g;q)(y) whenever u>=g. These two comparisons serve DIFFERENT roles and are not substituted for one another.

For original m>M, (S1) gives

    e^+_j(y,t)>ell M lambda c^(-n/2)t^n.                (S2)

The factor lambda is exact, since qg^n=lambda t^n. There is no additive sqrt(n)/ell loss.

## 3. Root and the expanded terminal strip

Fix M>0 before receiver selection. Let h_j=ell M lambda c^(-n/2), and define on I_j^ext

    S_j(y)={t:e^+_j(y,t)>h_j t^n}.

If S_j is empty there is no corresponding original m>M traffic, by (S2). Otherwise let r_j(y)=sup S_j(y). Monotonicity makes S_j an initial interval; right continuity and the original finite-tree convention give measurability. On every point of the extended window strictly below r_j, e^+(t)>h_j t^n. If a left side exists, e^+(r_j-)>=h_j r_j^n; e^+(r_j) itself may be smaller and is not used as a lower bound.

The actual compensated t belongs to S_j, so

    g<=rho_q r_j<=rho_0 r_j.                            (S3)

For L>=R, split the actual scales into

    long: L<r_j/c,
    top: r_j/c<=L<=rho_0 r_j/c_+.

Keep the actual feasibility L>=a/c^2 on the long interval, as implied by R>=a and R/L<=c^2. Use u=cL there: it is in the extended source window, g<=u<r_j, and u<=bc. Consequently

    p_y<=min{L^(-n)H_sigma((x-y)/L),2Klambda/e^+(cL)}.

For L<=R, use

    long: L<c_+ r_j,
    top: c_+ r_j<=L<=c rho_0 r_j,

and u=L/c_+ on the long interval. There too g<=u<r_j and u is in the extended window. All intervals are intersected with the actual physical [a,b]. Empty intervals cost zero. Root endpoint traffic is assigned to the top interval; singleton windows are included. If r_j lies below the original g-window, any surviving actual scales are in the top interval, not an illegal long interval.

The ratio of the top strip's endpoints is at most gamma rho_0 in BOTH orientations. Its exact ordinary dilation fee is therefore

    A_top=1+n log gamma+log(4/3),                        (S4)

not a full octave factor. This is the entire cost of accommodating variable q and arbitrary tree jumps.

## 4. Actual source payment with no additive mass cutoff

Write H_sigma=sup_(s<=sigma) product f_s, D_sigma(u)=integral min(H_sigma,u), and R_delta=integral H_sigma^(1-delta), 0<delta<1. Use the R294 inverse-variation theorem, with its original hard cap consumed before extending dx. The long interval's cap height in normalized soft coordinates is at most

    Theta_large=2K c^(-n/2)/(ell M),
    Theta_small=2K c^(n/2)c_+^n/(ell M).                 (S5)

A left-limit cap closes the interval if necessary; no actual endpoint is lost. The long source envelope price is at most (1+1/delta)Theta_orientation^delta R_delta.

On the original top interval, the unchanged low and high gates imply

    tau_large=2K gamma^n c^(-n/2)/(ell M),
    tau_small=2K c^(3n/2)/(ell M).                       (S6)

Its envelope price is at most A_top D_sigma(tau_orientation). In both orientations Theta=gamma^(-n)tau. The original hardcap/q contributes16/3, and the raw outside Lambda is multiplied once only. Thus

    T_(low,m>M,orientation,j)
       <=(16/3) R_delta B_delta tau_orientation^delta W_beta,
    B_delta=(1+1/delta)gamma^(-n delta)+A_top.            (S7)

No source-density premise, fixed source displacement or new favorable gate appears in this estimate. It is the original m>M threshold, not m>M+d0. When using both orientations choose L<=R and L>R disjointly; positive bounds also hold with the endpoint equality included in either.

For the SMALL-soft-scale orientation, sum ALL original bands with their coefficients:

    T_(low,m>M,L<=R)
       <=(16/3) R_delta B_delta
         (2K/(ell M))^delta/[1-gamma^(-3n delta/2)] W_beta. (S8)

For 0<delta<1, n log gamma is between log2 and1. In particular B_delta<=5/delta and [1-gamma^(-3n delta/2)]^(-1)<=2/delta. A convenient universal consequence is

    T_(low,m>M,L<=R)
       <=(160/3) delta^(-2) R_delta
                            (2K/(ell M))^delta W_beta. (S9)

The original upper-source ledger and seed weights are used once. For L>R the growing c^(-n delta/2) sum remains if using this beta-source proof. The companion reverse hard-scale estimate treats that orientation differently; it is not obtained by swapping the two sources or their caps.

## 5. Consequence for the existing small-softness part of the middle layer

The companion actual-common-soft moment theorem supplies constants A,C_L independent of n and an upper parameter hatsigma=max(sigma,1/n), Dhat=n hatsigma>=1, with

    delta_*=[2(1+A)(1+Dhat)(1+log(1/hatsigma))]^(-1).

For every 0<delta<=delta_*, it proves

    R_delta<=sqrt(e)(1+C_L sqrt(Dhat)).                  (S10)

The actual moment proof, not a deterministic rate-function conjecture, is needed for (S10). Set r=2K/(ell M), and choose

    delta=min{delta_*, [1+log_+ r]^(-1)}.

Then r^delta<=e and (S9) gives a density-free source payment

    T_(low,m>M,L<=R)
       <=(160/3)e^(3/2)(1+C_L sqrt(Dhat))
          [2(1+A)(1+Dhat)(1+log(1/hatsigma))
                                +1+log_+ r]^2 W_beta. (S11)

The sum in brackets safely bounds delta^(-1). If n sigma, log_+K and the original outer fees have their stated polylog bounds, (S11) is a polylog raw source price. Taking M=1 covers ALL original high-m traffic in this orientation under those existing softness qualifications; there is no extra sqrt(n)/ell gap. This does not impose a special function class on beta or nu. It applies to their arbitrary L1 sources at the indicated actual-softness slots.

It does NOT assert that every unresolved slot has n sigma polylog, that L>R is covered, or that initial/jump/deletion/high-score terms have been paid. Full general-input closure remains open.

## 6. Evidence and scope

The source compensation and root-strip proposition was independently screened before this proof. Three-stage exact Fraction diagnostics use volume variables g^n and t^n=(q/lambda)g^n to avoid floating nth roots, including threshold equality, absent light cells, source complements, monotone weights, root jumps and both orientations. Other agents separately verify the actual soft moment and reverse-scale source integral.

The original e_g, q, posterior, accepted-hard mask and source/history ledger are never rebuilt. Source-only auxiliary extension has been separated from all physical kernel/cap uses. This is a constructive replacement for R294's additive mass loss, not an assertion that the old sqrt(n) loss could be ignored.
