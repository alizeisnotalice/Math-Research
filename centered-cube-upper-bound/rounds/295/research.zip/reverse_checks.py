"""Reproducible finite diagnostics for R295; analytic proof remains in the note."""
from decimal import Decimal as D, localcontext
from fractions import Fraction as F
import json
from pathlib import Path

def fd(value):
    return D(value.numerator) / D(value.denominator)

def fa(x, A):
    if x <= 1:
        return x * (2 - 1 / A)
    if x <= A:
        return 2 + x.ln() - x / A
    return 1 + A.ln()

def run(precision):
    rows=[]
    with localcontext() as ctx:
        ctx.prec=precision
        for stage, dims in [(1,[1,2,3]),(2,[8,32,100]),(3,[1000,10000])]:
            for n in dims:
                nd=D(n); gamma=1+1/nd; d=D('1.5')*nd*gamma.ln()
                ratio=(-d).exp()
                for A in [D(1),(nd*gamma.ln()).exp(),(nd*D(2).ln()).exp()]:
                    for x in [D(0),D('0.125'),D(1),A,nd.sqrt().sqrt().exp()]:
                        total=D(0); term_x=x; j=0
                        while term_x > 1:
                            total += fa(term_x,A)
                            term_x *= ratio; j+=1
                            assert j<20000
                        total += fa(term_x,A)/(1-ratio)
                        upper=total
                        if x<=1:
                            bound=2*x/(1-ratio)
                        else:
                            logx=x.ln()
                            bound=2+logx+(2+2*logx+logx*logx/2)/d
                        tol=D(10)**(-precision+5)*max(D(1),bound)
                        assert total <= bound+tol
                        if x<=nd.sqrt().sqrt().exp():
                            assert upper<=8*nd.sqrt()+tol
                        rows.append((stage,n,str(A),str(x),str(total),str(upper)))
        return rows
r40=run(40); r60=run(60)
assert len(r40)==len(r60)
maxerr=D(0)
for a,b in zip(r40,r60):
    err=abs(D(a[4])-D(b[4]))/max(D(1),abs(D(b[4])))
    assert err<D('1e-32')
    maxerr=max(maxerr,err)
finite_count=0
with localcontext() as ctx:
    ctx.prec=60
    for n in [1,2,3,8,16]:
        for B in [F(0),F(1,8),F(1),F(3,2)**n,F(2)**n,F(3)**n]:
            previous=F(0)
            for mesh in [2,4,8,16,32]:
                scales=[1+F(k,mesh) for k in range(mesh+1)]
                value=min(F(1),B)
                for r0,r1 in zip(scales,scales[1:]):
                    value+=(r1**n-r0**n)/(r1**n)*min(F(1),B/(r1**n))
                assert value>=previous
                assert fd(value)<=fa(fd(B),D(2)**n)+D('1e-50')
                previous=value; finite_count+=1
result={'status':'PASS','stages':{'initial':[1,2,3],'boundary_scale':[8,32,100],'wide_dimensions':[1000,10000]},'scalar_cases_at_each_precision':len(r40),'precisions':[40,60],'max_normalized_precision_difference':str(maxerr),'exact_fraction_finite_scale_cases':finite_count,'checks':'convergent all-band sum, exact scalar envelope formula, log-square upper bound, root threshold, finite scale envelope monotonic refinement'}
Path('/tmp/r295_reverse_checks.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
