# R295 — the common-softness fractional moment and a paid small-softness orientation

## 1. All-parameter theorem, with the same softness in every coordinate

Use the ACTUAL one-dimensional R292 profile

    I=[-1/2,1/2], h=1_I, phi=h*w,
    w(x)=integral_0^1 exp(-|x|/r)dr,
    f_s=(1-s)h+s phi.

For n>=1, 0<=sigma<=1, put

    Q_s(x)=product_(i=1)^n f_s(x_i),
    H_sigma(x)=sup_(0<=s<=sigma) Q_s(x),
    R_delta(sigma)=integral H_sigma^(1-delta),
    D_sigma(tau)=integral min(H_sigma,tau).

The common s is preserved throughout. These are deterministic kernel integrals, not assertions about the original source/history law.

Fix 0<delta<1 and alpha=1-delta. Define the exact one-dimensional quantities

    B_alpha=integral_(I^c) phi^alpha,
    A_s(alpha)=integral_I (1-s+s phi)^alpha,
    Z_s(alpha)=A_s(alpha)+s^alpha B_alpha,
    q_s(alpha)=s^alpha B_alpha/Z_s(alpha),
    c=phi(1/2), d=phi(0).

For s=0 set Z_0=1, q_0=0. The numbers satisfy 0<c<=d<1. Define

    L_alpha(sigma)
       =2 arcsin(sqrt(q_sigma(alpha)))
          +(alpha/2) log[(1-sigma+sigma d)/(1-sigma+sigma c)].

Then for ALL these parameters,

    Z_sigma(alpha)^n <= R_delta(sigma)
       <= Z_sigma(alpha)^n [1+(sqrt(n)/2)L_alpha(sigma)]. (1)

In particular L_alpha<=pi+(alpha/2)log(d/c). The n-dependence outside the exact exponential moment is at most O(sqrt(n)), replacing an n-point grid fee. It is not an unconditional polynomial bound for R_delta: for fixed sigma>0 and delta>0, Z_sigma>1 and the lower bound in (1) is exponential in n.

A sharper, still one-dimensional computable upper bound is

    R_delta(sigma)
       <=Z_sigma^n+(sqrt(n)/2)
                       integral_0^sigma Z_s^n sqrt(J_alpha(s))ds, (2)

where J_alpha(s) is the Fisher information of the normalized escort density

    g_s(u)=f_s(u)^alpha/Z_s,
    J_alpha(s)=alpha^2 Var_(g_s)[(phi-h)/f_s].

The integral is finite, including its s=0 limit. Bound (1) follows from (2). All endpoint and sigma costs are displayed; no number of grid nodes is hidden.

For tau>=0 the actual clipped mass has the rigorous bound

    D_sigma(tau)
       <=min{C_sigma, inf_(0<delta<1) tau^delta R_delta(sigma)}, (3)

with the usual zero value at tau=0. An available explicit endpoint constant is

    C_sigma:=1+(sqrt(n)/2)L_1(sigma),
    q_sigma(1)=sigma T,
    T=integral_(I^c) phi.

Thus integral H_sigma<=C_sigma. For sigma=0 the exact answers are R_delta=1 and D_0(tau)=min(1,tau). For tau>=1, since H_sigma<=1, D_sigma=integral H_sigma; (3) retains this endpoint through C_sigma.

## 2. Exact profile and strict computability

The real profile is retained, with E_p(x)=integral_1^infinity exp(-xt)t^(-p)dt:

    phi(u)=1-E_3(1/2+|u|)-E_3(1/2-|u|), |u|<=1/2,
    phi(u)=E_3(|u|-1/2)-E_3(|u|+1/2),   |u|>1/2.

In particular

    c=1/2-E_3(1)>(1-e^(-1))/2>1/4,
    d=1-2E_3(1/2),
    T=2/3-2E_4(1).

All moments in (1)-(2) reduce to finite-interval core integrals and ONE outside integral B_alpha. For t>=0 the exact outside representation gives

    k_* exp(-2t)<=phi(1/2+t)<=(1/2)exp(-t),
    k_*=(1-e^(-1))/4.                                  (4)

Indeed restrict its defining integral to r in [1/2,1] for the lower bound; use r<=1 for the upper bound. Hence, after truncating B_alpha at t=R, its omitted two-sided tail is at most

    [2^(1-alpha)/alpha] exp(-alpha R).                  (5)

This supplies an explicit rigorous tail error, while the retained finite-interval integrals have the displayed continuous real-profile integrands. Standard interval quadrature can enclose them to any requested accuracy. The numerical diagnostics below are ordinary high-precision checks, not interval certificates.

We will also need the fixed finite constant

    C=integral_(I^c) sqrt(phi)log(1/phi).

Its omitted two-sided tail beyond |u|=1/2+R is at most

    sqrt(2) exp(-R/2)[4R+8+2log(1/k_*)].                (6)

This follows by multiplying sqrt(phi)<=2^(-1/2)e^(-t/2) by log(1/phi)<=2t+log(1/k_*). In particular the wholly explicit upper bound

    C<=C_bar:=sqrt(2)[8+2log(1/k_*)]

can replace C wherever certified finite constants are preferred. The theorem does not replace phi by the envelope (4) and guess an order; its main exponential factor is the exact Z_sigma of the actual phi.

## 3. Proof of the common-parameter moment bound

First Z_s is nondecreasing. For 0<s<=1, let a(u)=1-phi(u) on I. Then integral_I a=T. On the core f_s>=1-s+sc, and outside f_s=s phi<=sc. Since alpha-1=-delta<0,

    Z_s'(alpha)
      =alpha[integral_(I^c) phi (s phi)^(-delta)
                -integral_I a(1-sa)^(-delta)]
      >=alpha T[(sc)^(-delta)-(1-s+sc)^(-delta)]>=0.    (7)

Continuity at zero follows from the displayed exact Z_s formula. For alpha=1, Z_s=1 identically. Derivatives at s=0 itself need not be bounded.

For s>0, write r_s=(phi-h)/f_s and m_s=(log Z_s)'=alpha E_(g_s)r_s>=0. At a fixed x, the derivative of Q_s(x)^alpha is Q_s(x)^alpha alpha sum_i r_s(x_i). Under the product escort law, this last sum has mean n m_s and variance n J_alpha(s). For any random variable X with mean m>=0,

    E X_+ <= m+(1/2)sqrt(Var X).

For example, E X_+=(m+E|X|)/2 and Cauchy gives E|X|<=sqrt(m^2+Var X)<=m+sqrt(Var X). Therefore

    integral (partial_s Q_s^alpha)_+
       <=partial_s Z_s^n+(sqrt(n)/2)Z_s^n sqrt(J_alpha(s)).

The pointwise fundamental theorem and positive Tonelli give

    integral sup_(0<=s<=sigma) Q_s^alpha
       <=1+integral_0^sigma integral (partial_s Q_s^alpha)_+ ds,

which is (2). One can first start at epsilon>0 and pass epsilon down to zero; the finite length proved next justifies the integrable variation. The lower bound in (1) uses the single admissible endpoint s=sigma.

To control that length, the escort is a mixture on DISJOINT sets:

    g_s=(1-q_s) g_(s,in) on I,
    g_s=q_s g_out on I^c,
    g_out=phi^alpha/B_alpha.

This decomposition is an identity for the one-dimensional escort, not a replacement of shared softness by independent coordinate choices. Here q_s is increasing, since s^alpha B_alpha increases while A_s decreases. The exact Fisher decomposition is

    J_alpha(s)
       =q_s'^2/[q_s(1-q_s)]+(1-q_s)J_in(s).             (8)

On I the range of r_s is

    rho_s=(1-c)/(1-s+sc)-(1-d)/(1-s+sd).

The variance of a variable in an interval of width rho_s is at most rho_s^2/4. Consequently sqrt(J_in)<=alpha rho_s/2. Taking square roots in (8), using sqrt(A+B)<=sqrt(A)+sqrt(B), and integrating gives

    integral_0^sigma sqrt(J_alpha(s))ds
       <=integral_0^sigma q_s'/sqrt(q_s(1-q_s))ds
                           +(alpha/2)integral_0^sigma rho_s ds
       =L_alpha(sigma).                                (9)

The first endpoint is q_0=0; the last q_sigma is less than one because the core integral is positive. The second integral is exactly the logarithm in Section 1. Both are finite, proving the required variation control. Since Z_s<=Z_sigma, (2) and (9) prove (1).

The same proof at alpha=1 gives the endpoint bound integral H_sigma<=C_sigma. Finally min(z,tau)<=tau^delta z^(1-delta) proves (3). No scale supremum or original source law is introduced in these arguments.

## 4. Small-softness cancellation at delta=0

A bound of the form Z_s<=1+constant*s^(1-delta) loses the real cancellation at delta=0. The following stronger bound retains it. For 0<s<=1 and 0<delta<=1/2,

    0<=Z_s(1-delta)-1
       <=delta s[c^(-delta)T
                    +s^(-delta)(T log(1/s)+C)].          (10)

Proof on I: f_s=1-sa>=c, and

    f_s^(1-delta)-f_s
       <=delta f_s^(1-delta)log(1/f_s)
       <=delta s a f_s^(-delta)
       <=delta s a c^(-delta).

The first inequality is e^v-1<=v e^v; the second uses -log(1-sa)<=sa/(1-sa). Integrate. Outside I the difference is exactly

    s[s^(-delta)B_(1-delta)-T].

Since phi<=1 and delta<=1/2,

    B_(1-delta)-T
       <=delta integral_(I^c) phi^(1-delta)log(1/phi)
       <=delta C.

Together with s^(-delta)-1<=delta s^(-delta)log(1/s), this proves (10). The lower bound follows from f_s<=1 and integral f_s=1.

Here are explicit all-n parameters. Choose ANY upper softness hat_sigma in [sigma,1], with hat_sigma>0, and write

    D_hat=n hat_sigma, l_hat=log(1/hat_sigma),
    A=2T+sqrt(e)C,
    delta_*=[2(1+A)(1+D_hat)(1+l_hat)]^(-1).             (11)

Then delta_*<=1/2, delta_* l_hat<=1/2, c^(-delta_*)<=2, and hat_sigma^(-delta_*)<=sqrt(e). The numerator in (10), divided by 1+l_hat, is at most

    [2T+sqrt(e)C+sqrt(e)T l_hat]/(1+l_hat)<=A,

because 2T>=sqrt(e)T. Thus (10) yields the uniform bound

    n log Z_(hat_sigma)(1-delta_*)<=A/[2(1+A)]<1/2.      (12)

Moment monotonicity in sigma lets this upper parameter bound H_sigma as well. In particular the endpoint exponential cost is now at most sqrt(e), not a guessed polynomial in n.

For the escort length at hat_sigma, put

    Q=sqrt(e)(T+C/2),
    C_L=(pi/2)sqrt(Q)+(d-c)/(4c).

Indeed B_(1-delta_*)<=T+delta_* C, so q_(hat_sigma)<=Q hat_sigma. The elementary inequality arcsin(x)<=pi x/2 and log(1+x)<=x give

    1+(sqrt(n)/2)L_(1-delta_*)(hat_sigma)
       <=1+C_L sqrt(D_hat).                            (13)

For the core logarithm use log[(1-hat_sigma+hat_sigma d)/(1-hat_sigma+hat_sigma c)]<=hat_sigma(d-c)/c, and sqrt(n)hat_sigma<=sqrt(D_hat). The proofs of (12)-(13) use only 0<delta<=delta_*, so they hold UNIFORMLY for every smaller positive delta. Combining them with (1) proves the useful adaptive theorem

    R_delta(sigma)<=sqrt(e)[1+C_L sqrt(D_hat)],
                         0<delta<=delta_*.              (14)

Equations (11)-(14) remain rigorous if C is replaced everywhere in their constants by its explicit upper bound C_bar. The resulting constants are less sharp, but require no numerical certification.

For sigma>0 take hat_sigma=max(sigma,1/n). Then

    D_hat=max(n sigma,1), 0<=l_hat<=log n,
    delta_*^(-2)=4(1+A)^2(1+D_hat)^2(1+l_hat)^2.          (15)

This covers arbitrarily tiny sigma without charging log(1/sigma). At sigma=0 use the exact hard-profile result instead. In particular n sigma<=a fixed power of log(n+2) gives a polylog bound for BOTH R_(delta_*) and delta_*^(-2). No fixed-s positive-softness statement is inferred from this small-softness regime.

## 5. Actual substitution into the small-soft-scale source payment

The original R294 joint-geometry Section 7 receipt applied to m>M+d0. The independent scale-compensated freezing proof in /tmp/r295_scaled_freeze.md, Sections 3-4 and (S7)-(S9), now gives the following stronger receipt for the SAME original high-m condition m>M, without d0. This section uses that proved geometric input; it does not reprove its inverse-time, compensated comparison or root argument.

Keep all original source, low-pe, full m, accepted-hard and history masks, the unique original band j, the actual q, and the original hard cap. For orientation L<=R the raw source price across ALL original j is

    (16/3) R_delta(sigma) B_delta
       (2K/(ell M))^delta
       [1-gamma^(-3n delta/2)]^(-1) W_beta,              (16)

where gamma=1+1/n and NOW the compensated-freeze constants are

    A_top=1+n log gamma+log(4/3),
    B_delta=(1+1/delta)gamma^(-n delta)+A_top.            (16a)

The extra log(4/3) is the explicit enlarged terminal-strip cost. It is not dropped. There is no source disjointness assumption across j in (16). The geometric sum is paid in its denominator.

For 0<delta<1, B_delta<=5/delta. Since n log gamma>=log 2,

    [1-gamma^(-3n delta/2)]^(-1)<=2/delta.

Thus a convenient safe form, with no hidden band fee, is

    T_(low,m>M,L<=R)
       <=(160/3)delta^(-2)R_delta(sigma)
                         (2K/(ell M))^delta W_beta.     (17)

First take delta=delta_* from (11). Equations (14)-(15) give

    T_(low,m>M,L<=R)
       <=(640sqrt(e)/3)(1+A)^2
          (1+D_hat)^2(1+l_hat)^2[1+C_L sqrt(D_hat)]
          (2K/(ell M))^(delta_*) W_beta.                (18)

For n sigma bounded by any fixed power of log(n+2) and M>=2K/ell, this entire original high-m orientation is paid by a polylog source coefficient, hence also by a root-polylog budget. The normalized M condition and all K/ell dependence in this first choice are explicit.

There is no need to assume M>=2K/ell. For arbitrary M>0, define

    r=2K/(ell M),
    P=2(1+A)(1+D_hat)(1+l_hat),
    Q=1+log_+ r,
    delta=1/max(P,Q).                                  (18a)

Then 0<delta<=delta_*, r^delta<=e, and the UNIFORM version of (14) gives

    T_(low,m>M,L<=R)
       <=(160e^(3/2)/3) max(P,Q)^2
                               [1+C_L sqrt(D_hat)]W_beta. (18b)

One may replace max(P,Q) by P+Q for the simpler bound used in the parent scale-freezing note. If n sigma and log_+(2K/(ell M)) are polylog, (18b) is a polylog raw source price. Taking hat_sigma=max(sigma,1/n) yields D_hat=max(n sigma,1) and l_hat<=log n. In particular M=1 covers ALL original m>1 in this orientation under those stated softness and logarithmic qualifications; there is no additive sqrt(n)/ell loss. This is a source-linear original-input payment over all bands for arbitrary positive L1 sources, not merely a statement about an auxiliary product density.

The envelope parameter sigma must be a valid common upper bound for the ORIGINAL selected s on this suballocation. Delta is chosen from n and this frozen upper bound before receiver/source extension. If the upper bound differs by original outer datum, keep (18) or (18b) inside that original weighted sum until a valid common estimate is proved. An original outside Lambda multiplies these raw receipts ONCE. No additional score/clock price is introduced.

## 6. Exact full-softness threshold and the remaining prices

For general sigma and delta, (1) inserted in (17) gives the fully explicit coefficient

    (160/3)delta^(-2)
       [1+(sqrt(n)/2)L_(1-delta)(sigma)]
       exp{n log Z_sigma(1-delta)-delta log(ell M/(2K))}. (19)

One may replace (1) here by the sharper weighted integral (2), and optimize over delta. In particular a sufficient condition to remove its exponential cost is

    log(ell M/(2K))>=n log Z_sigma(1-delta)/delta.        (20)

Any additional desired source fee must still include the explicitly displayed delta^(-2) and escort factor. No unconditional polynomial-M claim follows for fixed positive softness.

There is also a sharp warning for THIS displayed moment strategy. Let h_sigma=integral f_sigma log(1/f_sigma)>0 for fixed sigma>0. The true profile satisfies

    log Z_sigma(1-delta)
       =log E_(f_sigma) exp(delta log(1/f_sigma))
       >=delta h_sigma.

Hence, writing t=log(ell M/(2K)),

    delta^(-2) R_delta(sigma) exp(-delta t)
       >=delta^(-2) exp(delta(nh_sigma-t)).              (21)

If nh_sigma-t>=2, the infimum of this lower expression over 0<delta<1 is e^2(nh_sigma-t)^2/4. Thus when sigma is fixed and t=O(log n), the sufficient coefficient delta^(-2)R_delta exp(-delta t) itself cannot be root-polylog. This diagnoses the moment receipt; it is not a lower bound for the actual original traffic or a disproof of a different allocation. Adaptive small-softness selection avoids that diagnosis because h_sigma shrinks with sigma, with its real sigma log(1/sigma) term retained by (10).

The following costs remain unclosed here:

* the large-soft-scale orientation L>=R, whose R294 factor is (2K gamma^n/(ell M))^delta sum_(legal j)c_j^(-n delta/2), with the opposite sign of band growth;
* the complementary original m<=M traffic;
* softness above the proved small-softness range unless the exact threshold (19)-(20), or another original allocation, pays its price;
* any global outer-source and score ledger not already included in the cited R294 raw receipt.

No price in this list is suppressed by the new one-dimensional moment theorem.

## 7. Actual finite diagnostics and reproducibility

The companion /tmp/r295_soft_moment_checks.py was run with local Python/mpmath at 35 digits. It uses the actual E_3 profile, finite core integration and the actual outside integral, rather than an independently chosen coordinate softness. Nine profiles alpha=0.5,0.9,0.99 and sigma=1/512,0.1,1 checked monotonicity, exact n=1 envelope moments, the escort Fisher decomposition (8), and the cancellation bound (10). Four adaptive cases used n=512 or 10^6 and D_hat=1, log(10^6+2), log(10^6+2)^2. All 13 profiles passed. Sixteen additional scalar threshold checks, with normalized r from 10^(-100) to 10^(10000), verified delta<=delta_*, r^delta<=e, and the maximum-versus-sum fee in (18a)-(18b).

Computed diagnostic constants were

    T=0.49454168401754521016,
    C=5.5947438512425917036,
    A=10.213256559697504937,
    C_L=3.7661017647740063331.

At n=10^6, D_hat=1 the selected delta was 0.00150484450725, n log Z was 0.0127126107428, and the escort prefactor was 1.71173683412. At D_hat=log(10^6+2)^2, the corresponding values were 0.0000242995702647, 0.0266973001995, and 10.7249270786. These are finite numerical diagnostics; the inequalities above and the optional C_bar prove the all-parameter bounds.

Only this temporary author note and its companion reproduction script were written. Other authors and Git state were preserved. The analytic inputs were the exact R292 information profile and R294 joint-geometry Section 7. Section 5 also uses the independently proved R295 scale-compensated freezing receipt (S7)-(S9), including its extra log(4/3) terminal-strip fee.
