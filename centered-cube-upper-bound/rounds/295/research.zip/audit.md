# R295 independent preauthor audit

## Scope and independent source-ledger screen

Written before reading any new R295 author proof. Read R294 main geometry, R294 joint Section 7 and R292 information profile. The two distinct costs remain: the large-soft-scale L>R band cap grows as c_j^(-n/2), while the full common-soft fractional moment R_delta has real dimension dependence. The small-soft-scale geometric series cannot be applied to the opposite sign.

The original beta FIRST safely gives the independent SAME-suballocation price A_n W_nu, A_n=1+n log(b/a), by consuming beta at actual receivers before integrating the hard point-scale envelope. Its minimum with any valid beta-source price is legitimate. Source pieces of original nu may be split positively with all original e,m,history and gates kept fixed. A genuinely receiver/soft-source-independent hard scale window [r0,r1] gives [1+n log(r1/r0)]W_nu by this same argument.

The R294 terminal strip is centered at g*(y), depending on the beta source point. Its width at most log gamma per y does NOT by itself give an A_gamma W_nu payment: FIRST integrates many y with different strip centers, whose union may be the full hard scale window. A transfer requires an explicit scale occupation/matching budget or a frozen common window before beta is consumed. Unique j or narrow per-y strips are not source-disjointness.

Relabeling beta and nu is not justified by L>R alone. Even if an original source bridge proves nu<=beta, this gives only soft response inheritance to nu; it does not give the required hard cap to beta, exchange the original soft/hard kernel roles, or replace the full original nu-weighted e_g by a new beta-weighted mass. The original q,full e,m,low membership and unique j must remain. No undocumented source ordering is used here.

The auxiliary tilted product law below is a kernel calculation. It supplies no original-source independence, new FIRST for a parameter supremum/derivative, or source-conserving payment. A moment coefficient may be transferred to the nu ledger only by proving a genuine source-integral inequality for the SAME actual traffic, not by renaming the row coefficient.

## Independent exact common-soft variation identity

Fix theta=1-delta in (0,1), f_s=(1-s)h+s phi, p_s(u)=product_i f_s(u_i), H_sigma=sup_(0<=s<=sigma)p_s. For s>0 define
 Z_s=integral f_s^theta,
 a_s(u)=(phi(u)-h(u))/f_s(u),
 pi_s(du)=f_s(u)^theta du/Z_s,
 mu_s=E_pi a_s, v_s=Var_pi a_s.
For auxiliary iid U_i under pi_s, let S_n=sum_i a_s(U_i). Then
 integral (partial_s p_s^theta)_+=theta Z_s^n E(S_n)_+.

The candidate variation domination is valid, and in fact EXACT for this family: log p_s is concave in s>0 because partial_s² log p_s=-sum_i a_s²<=0. For a point outside the hard cube, p_0=0, p_s is continuous at zero, increases then decreases (or stays monotone), and positive variation equals its maximum. Inside the hard cube, p_s decreases from1, so there is no positive variation. Each off-core coordinate supplies a power s^theta near zero, making pointwise variation integrable. Hence
 H_sigma^theta=p_0^theta+integral_0^sigma(partial_s p_s^theta)_+ds,
 R_delta=1+theta integral_0^sigma Z_s^n E(S_n)_+ ds.
This uses positive Tonelli, not a derivative/integral cancellation of signed terms.

## Exact mean/variance constants

For any square-integrable random S of mean m and variance v,
 E S_+=(m+E|S|)/2 <=(m+sqrt(m²+v))/2
 <=m_++sqrt(v)/2.
For S_n the exact mean and variance are n mu_s,n v_s. Thus the sharp general first-two-moments expression is
 E(S_n)_+ <=[n mu_s+sqrt(n² mu_s²+n v_s)]/2
 <=(n mu_s)_++(sqrt(n)/2)sqrt(v_s).
The positive part is on the MEAN, not E(a_s)_+. Replacing it by E(a_s)_+ is a valid but weaker bound. The variance coefficient may be1/2, rather than1.

Here mu_s>=0 because Z_s is nondecreasing. One direct proof uses c=phi(1/2): outside the core f_s<=sc, inside f_s>=1-s+sc, and theta-1<0. The masses integral_out phi and integral_core(1-phi) agree. Therefore Z'_s>=theta T[(sc)^(theta-1)-(1-s+sc)^(theta-1)]>=0. Also mu_s=Z'_s/(theta Z_s). Integrating the mean term exactly gives the useful bound
 R_delta<=Z_sigma^n+(theta sqrt(n)/2) integral_0^sigma Z_s^n sqrt(v_s)ds.
The tighter square-root expression may be retained before this simplification. No unexplained strong logarithmic prefactor or loss is inferred.

## Endpoint integrability with explicit formulas

Write I=hard interval, a=1-phi on I, T_theta=integral_(I^c)phi^theta<infinity. Then for s>0,
 Z_s=integral_I(1-sa)^theta+s^theta T_theta,
 mu_s=[s^(theta-1)T_theta-integral_I a(1-sa)^(theta-1)]/Z_s,
 E_pi a_s²=[s^(theta-2)T_theta+integral_I a²(1-sa)^(theta-2)]/Z_s.
The core f_s is bounded below by c>1/4 for s in[0,1], so all core terms stay bounded through both endpoints. As s downarrow0, Z_s->1, mu_s=O(s^(theta-1)), and sqrt(v_s)=O(s^(theta/2-1)); both are integrable because theta>0. For each fixed n, Z_s^n stays bounded on[0,sigma]. At s=1 all terms are finite: outside score=1/s and the core denominator stays >=c. Thus no fake (1-s)^-1 endpoint singularity is needed. Constants need not be uniform as theta downarrow0, and the original full-dimensional factor Z_s^n remains. At sigma=0, R_delta=1 exactly.

The real n s log(1/s) information scale from R292 is not removed by the common-soft variation bound. The factor Z_sigma^n and the weighted variance integral must be estimated with their actual n,delta,sigma dependence before any root/polylog conclusion.

## Executed independent score diagnostic

mpmath at30 digits evaluated the actual one-dimensional phi/E3 kernel, fractional core/tail moments, score mean and variance for theta in {.5,.9} and s in {10^-6,.001,.2,1} (8 cases). Every mu>=0, variance>=0, and the exact one-dimensional E(score)_+ satisfied both the sharp mean/second-moment bound and the simplified mu+sqrt(variance)/2 bound. This is a finite kernel diagnostic, not an original-source independence test or a dimension-uniform rate proof.

## Independent scaled q-freeze high-m root screen

Before the new author proof, this candidate is valid and removes the additive R294 d0. Set rho_q=(lambda/q)^(1/n), rho0=(4/3)^(1/n), t=g/rho_q. Extend only the original source-tree/weight formulas to the auxiliary source interval [a/(c_j rho0),b c_j]. Since J_j is nondecreasing, H_j(t;lambda)=q g^n J_j(t)<=H_j(g;q). The coarsest light block at the smaller threshold is contained in the actual block, including finest-fallback cases. Thus Z+_t contains Zactual_g, and t<=g gives w_t>=w_g, so e+(t)>=eactual(g).

Original m>M implies e+(t)>ell M lambda c_j^-n/2 t^n. For the initial strict superlevel set of e+(t)/t^n, its root r therefore satisfies actual g<=rho0 r. No positive lower bound at a downward jump of e+(r) is assumed. For long parts, the old maps u=c_j L or u=L/c_(j+1) still obey u>=actual g, so e+(u)<=eactual(g), giving a valid original low-pe cap. While u<r, their terminal normalized caps are
 Theta_large=2K c_j^-n/2/(ell M),
 Theta_small=2K c_j^(n/2)c_(j+1)^n/(ell M).
The large long part is restricted to feasible L>=a/c_j². All root endpoint/jump traffic remains in the strips [r/c_j,rho0 r/c_(j+1)] or [c_(j+1)r,c_j rho0 r], clipped to actual physical scales. Their ratio is gamma rho0, hence fee 1+n log gamma+log(4/3). Old low-pe strip caps still use actual m>M; the ratio Theta/strip_tau is gamma^-n. The auxiliary t extension never receives a kernel cap or an actual response interpretation. This yields the small-orientation all-m>M sum with no d0 loss, retaining R_delta and the opposite-sign large-orientation costs.

## Independent reverse-FIRST large-orientation screen

Before the reverse author proof: for original low,m>M and L>R, g>=R/c_j gives p_y<=alpha_j R^-n with alpha_j=2K c_j^(3n/2)/(ell M). For any fixed receiver-independent pair mask omega(y,z) in[0,1], put m_omega(z)=integral omega(y,z)beta(dy). Actual beta FIRST and the point height cap give
 integral omega p_y/q 1_original-low/high/j beta(dy)
 <=min(1,alpha_j m_omega(z)/(q_-R^n)).
Consume beta before extending receiver space. The remaining exact hard scale envelope for B_j=alpha_j m_omega/q_- has integral
 F_A(B_j/a^n), A=(b/a)^n,
 F_A(x)=min(1,x)+integral_1^A min(1,x/u)du/u.
It is bounded by F_infinity(x)=2x for x<=1 and 2+log x for x>=1.

Writing x_j=x0 exp(-dj), d=(3n/2)log gamma>=1.5log2>1, a decreasing-sum/first-term-plus-integral estimate gives
 sum_(j>=0) F_infinity(x_j)<=4+3log_+x0+(1/2)(log_+x0)².
For x0>=1, this follows from F(x0)+d^-1[2+2log x0+(log x0)²/2]; for x0<1 use the direct geometric tail, which is below4. Thus log_+x0<=n^(1/4) gives at most7.5sqrt(n)<8sqrt(n). This is a genuine original nu-source conditional price without full-soft moment or a density cap. The normalized ORIGINAL beta mass in x0, the receiver-independent mask, the unchanged original e,m and all source reuse fees remain explicit. If omega is allowed to depend on x through a moving root or actual selectors, replacing it by m_omega(z) requires a fixed positive majorant and its true mass; no free source occupation is supplied.

Executed 40-digit mpmath diagnostics for the reverse-FIRST screen: 35 cases across n=1,2,3,8,64,512,10000 verified the finite hard-envelope formula against log-scale piecewise quadrature, the exact infinite-band sum against 4+3log_+x0+0.5log_+²x0, and the stated8sqrt(n) bound under log_+x0<=n^(1/4). Maximum finite-envelope formula/quadrature error 9.1835e-41. An initial direct-u quadrature over exponentially wide intervals did not meet an overly tight tolerance; changing to the exact variable v=log u resolved it. No theorem or constant changed. These are scalar diagnostics, not original-history tests.

## Frozen reverse-geometry author audit

PASS for /tmp/r295_reverse_geometry.md SHA256 a46f0b5f0c3d378b2bf3e3867eb77a88cd4bbaab802e0d2ea1602146b1723ccf. R1--R10 match the independent reverse-FIRST screen. The exact actual low/high algebra produces c_j^(3n/2) relative to R^-n; no q freeze, d0 shift or source ordering is used. The pointwise beta integral is bounded simultaneously by actual FIRST and alpha_j b_omega/(q_-R^n), with all old gates retained until each bound is applied. Positive receiver extension follows this step.

The exact hard envelope F_A has all three branches and includes A=1, B=0 and physical hard faces. Summing original j fees gives the convergent Psi with source mass b_omega(z) explicit; the infinite extension is positive and no source-disjointness is claimed. The root simplification [3+4.5/d_min]sqrt(n)<8sqrt(n), d_min=1.5log2, is correct for log_+X<=n^(1/4). The full-soft moment is absent from this reverse proof, rather than relabeled as a nu cost.

The frozen receiver-independent allocation omega is essential to its source ledger. Any family of allocations adds its actual nu fees, and omega versus1-omega is an exact original-traffic decomposition. The condition on b_omega, global mass logarithm for omega=1, and complementary m<=M source traffic are retained. R1 supplies a genuine selector-free mixed-source concentration bound; no automatic all-source root coverage follows. The original low-raw outer cost is Lambda once. No correction requested.

## Final common-soft moment author audit

PASS for /tmp/r295_soft_moment.md SHA256 44484d2d617c2b0e58247e289342b99b114eb970d4e5d28c5c4c610ff4884c71. The all-parameter bound is valid with the actual shared softness: Z_sigma^n<=R_delta<=Z_sigma^n[1+sqrt(n)L_alpha/2]. The weighted variation bound matches the independent mean/variance proof above, with J_alpha=alpha² Var(score). The disjoint core/outside escort decomposition gives exact Fisher information q'^2/[q(1-q)]+(1-q)J_in. Its square root is bounded by the Bernoulli length plus alpha/2 times the exact core-score range integral. This proves L_alpha=2arcsin(sqrt(q_sigma))+(alpha/2)log[f_sigma(d)/f_sigma(c)], with finite endpoints including s downarrow0 and s=1. No original-source law is substituted for the auxiliary escort.

The analytic tail enclosures (4)--(6), including C_bar, have correct exponents and constants. The cancellation estimate (10) follows by retaining f_s^(1-delta)-f_s on the core and exact outside mass cancellation. Delta_* ensures c^-delta<=2 and hatsigma^-delta<=sqrt(e), hence n log Z<=A/[2(1+A)]<1/2. The escort q bound uses B_(1-delta)<=T+delta C, giving Q=sqrt(e)(T+C/2); the resulting C_L=(pi/2)sqrt(Q)+(d-c)/(4c) is correct. The proof applies UNIFORMLY to all smaller positive delta, which is essential for the later log-r adjustment. Constants may use the explicit analytic C_bar, so no unproved floating constant is required.

With hatsigma=max(sigma,1/n), Dhat=max(nsigma,1) and lhat<=log n, the adaptive moment bound is rigorous. At sigma=0 the exact hard result may be used; the main's positive upper-parameter bound is also harmless. The source substitution keeps the compensated top fee log(4/3), all j fees and the original hard cap. The arbitrary-r choice delta=1/max(P,1+log_+r) has delta<=delta*, r^delta<=e and retains its squared logarithmic fee. Taking M=1 covers original m>1 only in the stated valid-small-softness L<=R allocation.

The full-soft lower diagnosis is also correct: R_delta>=Z_sigma^n and log Z_sigma>=delta h_sigma. If nh_sigma-t>=2, inf_(0<delta<1) delta^-2 exp(delta(nh_sigma-t))=e²(nh_sigma-t)²/4. This concerns the displayed sufficient moment coefficient, not a lower bound on actual original traffic. The opposite orientation and global ledgers remain outside this theorem. No correction requested.

## Final compensated-freeze source proof audit

PASS for /tmp/r295_scaled_freeze.md SHA256 fd990bc7b432e5ae76b03c4ddc1789fe9c6bd9449d0c2720bd15e7a6723448f8. S1--S8 match the independent source-only scaled-freeze/root screen. Threshold compensation qg^n=lambda t^n is exact and removes the additive d0; the extended t interval is only an original source-tree/weight evaluation, never a physical response cap. Fallback inclusion, root emptiness, left limits, singleton/endpoints, large-long feasible L>=a/c², and both top strips are all retained. The top fee is exactly 1+n log gamma+log(4/3), with no lost q-range factor.

For S9, B_delta<=5/delta and [1-gamma^(-3n delta/2)]^-1<=2/delta are safe, so the factor160/3 is correct. S10 is now bound to the audited moment theorem above. The S11 adjustment has r^delta<=e and delta^-1<=P+1+log_+r, and combining R<=sqrt(e)(1+C_L sqrt(Dhat)) gives e^(3/2) exactly. Source/seed-dependent bounds stay inside the original ledger unless a common bound is proved. Lambda multiplies the raw low price once. No original input density assumption, fake FIRST or source swap is used.

Moment notation-only final update: final SHA256 e026597be5e06ab828b2e8359fbbfe12916a7ece146743d08e3f9b591006b0b9. Reversing clipped-mass D_sigma/D_0 to the previous U_sigma/U_0 reproduces the previously audited SHA256 44484d2d617c2b0e58247e289342b99b114eb970d4e5d28c5c4c610ff4884c71 exactly. This removes conflict with the unsaturated-tail U notation in the main inverse-variation theorem. Mathematics and PASS unchanged; no test rerun required.

## Final README scope and frozen receipt

PASS. The current README accurately integrates the three mathematical proofs: compensated q freezing removes d0 at an explicit log(4/3) strip fee; the common-soft fractional moment retains exact Z_sigma and a proved escort-length factor, with a uniform small-softness/log-r adaptation; the reverse-FIRST large orientation has an exact source-mass logarithmic-square budget and its explicit column-capacity condition. The README now distinguishes the fixed moment constant A_soft from A_win=(b/a)^n and defines q_-=3lambda/4. No formula or scope correction remains.

Taking M=1 pays the entire ORIGINAL low,m>1,L<=R part only on original slots possessing the stated n sigma and log_+K polylog bounds. The statement applies to arbitrary original L1 sources at those actual parameter slots; it does not assert that all unresolved slots qualify. On L>R, arbitrary displacement and softness are allowed in the reverse theorem, but omega's beta-column capacity (or its explicit nu-weighted logarithmic-square cost) remains. Splitting beta cannot duplicate nu responsibility for free. These restrictions and all original masks, q,full e,m, source/seed sums and Lambda once are retained.

Parent reports actual exit0 reruns for all three final scripts. Existing main and reverse JSONs were inspected at the final receipt, and the real-kernel rerun log confirms13 profiles plus16 scalar gate checks PASS. Numerical evidence remains finite diagnostics rather than interval certification or a proof of arbitrary-input closure. No new computation was launched at this final integration step.

Final mathematical/integration bindings:
- /tmp/r295_scaled_freeze.md: SHA256 fd990bc7b432e5ae76b03c4ddc1789fe9c6bd9449d0c2720bd15e7a6723448f8
- /tmp/r295_soft_moment.md: SHA256 e026597be5e06ab828b2e8359fbbfe12916a7ece146743d08e3f9b591006b0b9
- /tmp/r295_reverse_geometry.md: SHA256 a46f0b5f0c3d378b2bf3e3867eb77a88cd4bbaab802e0d2ea1602146b1723ccf
- /tmp/r295_README.md: SHA256 38d679fbdd7b1cb234aadb4363c959ff2a4a50bdc6614e6fd492de7f033d88f1

Final remaining obligations: pay arbitrary-softness slots outside the proved small-softness receipt; establish a root-compatible nu-weighted beta-column mass logarithmic budget or source-conserving coverage for the reverse orientation; and close the original continuous high-score, initial/jump/deletion and global outer-source ledgers. The moment lower diagnosis concerns its sufficient coefficient, not actual traffic or impossibility of another allocation. No general centered-cube root weak-type theorem is claimed.

Final verdict PASS. Audit frozen. Only this owned temporary audit was edited; no repository, Git, PDF or upstream author files were modified.
