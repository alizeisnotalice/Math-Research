#!/usr/bin/env python3
"""R295 exact volume compensation, nested-source inheritance, jump-root and top strips."""
import json,random
from fractions import Fraction as F
from pathlib import Path
import mpmath as mp
R=random.Random(29520261018)
def mm(x):return mp.mpf(x.numerator)/x.denominator

def threshold(lam,u,sqrtn,cnpow,B):return lam*u*max(F(1),sqrtn*cnpow,sqrtn*u/B)
def choose(prefix,H):
 valid=[i for i,p in enumerate(prefix) if p<=H]
 return (max(valid),False) if valid else (0,True)
def response(masses,prefix,H,vol,omega,mask):
 i,fallback=choose(prefix,H)
 e=sum((mass*min(F(1),w/vol) for k,(mass,w) in enumerate(zip(masses,omega)) if k>i and mask[k]),F(0))
 return e,i,fallback

def tree_stage(ns,count,spread):
 thresholds=0;fallback=0;inherit=0;high=0;equality=0;mono=0;branches=[0,0,0]
 const={}
 for n in ns:
  root=int(n**.5);assert root*root==n
  gamma=F(n+1,n);croot=F(n,n+1);c=croot*croot;cn=c/gamma
  const[n]=(root,gamma,croot,c,cn,cn**n,croot**(-n))
 for j in range(count):
  n=ns[j%len(ns)];sqrtn,gamma,croot,c,cn,cnpow,cf=const[n]
  lam=F(R.randint(1,10),R.randint(1,10))*F(10)**R.randint(-spread,spread);q=lam*[F(3,4),F(7,8),F(1)][j%3]
  masses=[F(R.randint(1,10),R.randint(1,10))*F(10)**R.randint(-spread,spread) for _ in range(6)]
  prefix=[];s=F(0)
  for mass in masses:s+=mass;prefix.append(s)
  K=max(F(1),sqrtn*cnpow)
  if j%4==0:
   u=prefix[j%len(prefix)]/(q*K);B=100*sqrtn*u # Exact original tree-threshold equality; third term inactive.
  else:
   u=prefix[j%len(prefix)]/(q*K)*[F(1,100),F(1,2),F(2),F(100)][j%4]
   B=u*max(F(1),F(sqrtn,2)) # legal u<=B, with active third branch when possible.
  v=q/lam*u;assert F(3,4)*u<=v<=u and lam*v==q*u
  Hq=threshold(q,u,sqrtn,cnpow,B);Hp=threshold(lam,v,sqrtn,cnpow,B);assert Hp<=Hq;thresholds+=1
  if Hq in prefix:equality+=1
  choices=[F(1),sqrtn*cnpow,sqrtn*u/B];branches[choices.index(max(choices))]+=1
  omega=[u*F(R.randint(1,20),R.randint(1,20)) for _ in masses];mask=[bool(R.randrange(2)) for _ in masses];mask[-1]=True
  eactual,ia,fa=response(masses,prefix,Hq,u,omega,mask);eplus,ip,fp=response(masses,prefix,Hp,v,omega,mask)
  assert ip<=ia and eplus>=eactual;assert all(min(1,w/v)>=min(1,w/u) for w in omega);inherit+=1;fallback+=fa+fp
  # ell*M is a positive frozen scalar. Choosing it >=20 also permits M>=1 for tested n.
  ellM=max(F(20),eactual/(2*q*cf*u))
  if eactual>ellM*q*cf*u:
   assert eplus>ellM*lam*cf*v;high+=1
  for f1,f2 in [(F(1,4),F(1,2)),(F(1,2),F(1)),(F(1),F(2))]:
   va=u*f1;vb=u*f2
   ea,_,_=response(masses,prefix,threshold(lam,va,sqrtn,cnpow,B),va,omega,mask)
   eb,_,_=response(masses,prefix,threshold(lam,vb,sqrtn,cnpow,B),vb,omega,mask)
   assert ea>=eb;mono+=1
 assert high>0
 return {'cases':count,'dimensions':ns,'exact_threshold_compensation_checks':thresholds,'exact_source_complement_inheritance_checks':inherit,'fallback_occurrences_actual_and_plus':fallback,'positive_original_high_m_implications':high,'threshold_equals_node_mass_cases':equality,'source_response_monotonicity_checks':mono,'active_threshold_branches_1_fixedratio_volume':branches,'max_exact_violation':'0'}

def roots():
 masses=[F(1),F(1),F(2),F(4)];prefix=[F(1),F(2),F(4),F(8)]
 def e(v):return sum(masses[choose(prefix,v)[0]+1:])
 def root(lo,hi):
  pts=sorted(set([lo,hi]+[p for p in prefix if lo<p<hi]));candidates=[v for v in pts if e(v)>v]
  for a,b in zip(pts,pts[1:]):
   ev=e((a+b)/2)
   if ev>a:candidates.append(min(b,ev))
  return max(candidates) if candidates else None
 r=root(F(3,4),F(6));assert r==4 and e(r)==r # Jump/equality endpoint is not accepted.
 count=0;endpoint=0
 for qratio in [F(3,4),F(7,8),F(1)]:
  for u in [F(1),F(2),F(3),F(4),F(5),F(6),F(16,3)]:
   if not 1<=u<=6:continue
   v=qratio*u;assert F(3,4)<=v<=6
   # Hq=qratio*u=Hplus(v), constant weights; exact same source response here.
   if e(v)>qratio*u:
    assert v<=r and u<=F(4,3)*r;count+=1
   if qratio==F(3,4):assert u==F(4,3)*v;endpoint+=1
 # Actual physical singleton window; extended source domain is [3/4 umin,umax].
 singleton=root(F(9,4),F(3));assert singleton==3 and e(3)>3
 assert root(F(4),F(4)) is None and root(F(3),F(3))==3
 return {'jump_root_volume':'4','response_at_jump_equals_boundary':True,'strict_root_endpoint_not_accepted':True,'accepted_actual_volume_tests':count,'rho0_endpoint_mapping_tests':endpoint,'physical_singleton_window_tests':3,'max_exact_root_or_window_violation':'0'}

def orientation(ns):
 count=0;eq=0;logerr=mp.mpf(0);pe=mp.mpf(0)
 for n in ns:
  gamma=F(n+1,n);c=F(n*n,(n+1)**2);cn=c/gamma;cp=c**n;np=cn**n;gn=gamma**n
  V=F(R.randint(1,10),R.randint(1,10));large_lo=V/cp;large_hi=F(4,3)*V/np;small_lo=np*V;small_hi=F(4,3)*cp*V
  assert large_hi/large_lo==small_hi/small_lo==F(4,3)*gn
  for rr in [cn,(cn+c)/2,c]:
   rp=rr**n
   for u in [V/10,V,F(4,3)*V,V*(rr/c)**n,V*(cn/rr)**n]:
    assert u<=F(4,3)*V
    for L,lo,hi in [(u/rp,large_lo,large_hi),(u*rp,small_lo,small_hi)]:
     if L>=lo:assert L<=hi
     else:assert L<lo
     if L==lo or L==hi:eq+=1
     count+=1
  vals=[]
  for dp in [40,60]:
   with mp.workdps(dp):
    width=mp.log(mm(large_hi/large_lo));expected=n*mp.log1p(mp.mpf(1)/n)+mp.log(mp.mpf(4)/3)
    err=abs(width-expected);assert err<mp.mpf('1e-30');logerr=max(logerr,err);vals.append(+width)
  with mp.workdps(90):pe=max(pe,abs(vals[0]-vals[1]))
 return {'dimensions':ns,'exact_two_orientation_cover_tests':count,'exact_top_boundary_equalities':eq,'exact_volume_width':'(4/3)*gamma^n','n_times_log_radius_width':'n*log(gamma)+log(4/3)','max_log_identity_error':mp.nstr(logerr,12),'max_40_vs_60_log_difference':mp.nstr(pe,12),'max_exact_cover_violation':'0'}
def soft_scalar(ns,count):
 worst=mp.mpf(0);maxfee=mp.mpf(0);maxr=mp.mpf(0)
 for j in range(count):
  n=ns[j%len(ns)];lr_exp=[-10000,-100,0,10,10000][j%5];values=[]
  for dp in [40,60]:
   with mp.workdps(dp):
    # Explicit analytic upper constants from author's C_bar, not new kernel quadrature.
    kstar=(1-mp.exp(-1))/4;Cbar=mp.sqrt(2)*(8+2*mp.log(1/kstar));Tbar=mp.mpf(1);cbar=mp.mpf(1)/4;dbar=mp.mpf(1)
    Abar=2*Tbar+mp.sqrt(mp.e)*Cbar
    CLbar=mp.pi/2*mp.sqrt(mp.sqrt(mp.e)*(Tbar+Cbar/2))+(dbar-cbar)/(4*cbar)
    desired=[mp.mpf(1),mp.log(n+2),mp.log(n+2)**2][j%3];sigma=min(mp.mpf(1),desired/n)
    hatsigma=max(sigma,mp.mpf(1)/n);D=n*hatsigma;lhat=mp.log(1/hatsigma)
    P=2*(1+Abar)*(1+D)*(1+lhat);logr=lr_exp*mp.log(10);Q=1+max(0,logr);den=max(P,Q);delta=1/den
    assert 0<delta<=1/P and delta<=mp.mpf('.5')
    rdelta=mp.exp(delta*logr);assert rdelta<=mp.e*(1+mp.mpf('1e-35'));maxr=max(maxr,rdelta/mp.e)
    ng=n*mp.log1p(mp.mpf(1)/n);Atop=1+ng+mp.log(mp.mpf(4)/3)
    Bdelta=(1+1/delta)*mp.exp(-ng*delta)+Atop
    invseries=1/(-mp.expm1(-mp.mpf('1.5')*ng*delta))
    assert Bdelta<=5/delta and invseries<=2/delta
    Rbound=mp.sqrt(mp.e)*(1+CLbar*mp.sqrt(D))
    fee=mp.mpf(16)/3*Rbound*Bdelta*rdelta*invseries
    safe=mp.mpf(160)/3*mp.exp(mp.mpf('1.5'))*den**2*(1+CLbar*mp.sqrt(D))
    assert fee<=safe;maxfee=max(maxfee,fee/safe);values.append((+delta,+fee))
  with mp.workdps(90):
   err=max(abs(a-b)/max(1,abs(b)) for a,b in zip(values[0],values[1]));assert err<mp.mpf('1e-30');worst=max(worst,err)
 return {'cases':count,'precision_runs':2*count,'log10_r_range':[-10000,10000],'uses_analytic_Cbar_constants':True,'max_r_power_delta_over_e':mp.nstr(maxr,12),'max_exact_band_receipt_to_safe_adaptive_fee':mp.nstr(maxfee,12),'max_normalized_40_vs_60_error':mp.nstr(worst,12),'max_violation':'0','scope':'Scalar consequences of supplied analytic R_delta bound only; no fresh moment integration.'}

settings=[('initial',[1,4,9],18,2),('fallback_equality_jump_stress',[16,64,100],36,8),('expanded',[256,1024,10000],54,20)]
stages=[]
for name,ns,count,spread in settings:
 stages.append({'name':name,'tree_volume_compensation':tree_stage(ns,count,spread),'root_physical_window':roots(),'top_orientation_cover':orientation(ns),'small_orientation_adaptive_scalar':soft_scalar(ns,count//2)})
out={'status':'PASS','seed':29520261018,'scope':'Exact finite Fraction volume compensation and nested source-complement response algebra, jump-root/singleton diagnostics and two orientation volume covers;40/60 log-width checks. Tree nodes are nested prefixes, coarsest mass<=threshold, fallback finest; response uses the complement and monotone volume weights. No FULL/source closure or original-history certificate.','definitions':{'u':'g^n','v':'t^n=(q/lambda)*u','rho0_power_n':'4/3','Hq':'q*u*max(1,sqrt(n)*cnext^n,sqrt(n)*u/b^n)','highm':'e_actual>ell*M*q*c^(-n/2)*u => e_plus>ell*M*lambda*c^(-n/2)*v','extended_source_lower_volume':'(3/4)*original_lower_volume'},'stages':stages}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,sort_keys=True,indent=2)+'\n');print(json.dumps(out,sort_keys=True,indent=2))
