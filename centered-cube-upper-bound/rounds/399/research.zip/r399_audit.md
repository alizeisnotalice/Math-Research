# R399 independent audit — FINAL PASS

FINAL PASS within the precise scope below: the actual marked H_small receipt, its complete positive complement, dimensional alternative and exact inherited ledger substitution are valid. No general root-order bound for the remaining core is certified. Only this audit file was edited; author files and repository were not changed.

Only this file is edited. This derivation precedes the new R399 author proof. Freeze the actual R398 cumulative H_small, all old f/q/m/receiver/rank/clock/history fields, nested gamma_i and global b_i. Let sigma=qdu and pi_v=f c_v/m_v. All mass gaps below are strict m_v>K m_w with actual global receivers.

## Incoming old-source density must be sourcewise

The exact oldsource endpoint disintegration is

    dGamma_i(y,*,v)=sigma(dv) pi_v(dy) k_i(v,y),
    k_i(v,y)=q_v^(-1) integral q_u chi_i(y,u,v)c_u(y)
                              dmu(u)/T_y(m_u).

Here chi_i is the original nonnegative averaged mark times endpoint restrictions, not a normalized conditional probability. Thus k_i<=k_0 pointwise. The R390 rank-strip proof is uniform for each fixed y and v before pi_v integration and yields k_i<=C_col. The weaker averaged statement integral pi_v k_i<=C_col ALONE would not justify the proposed source-correlated payment. Zero marked ranks are zero, as in the original operator.

The endpoint witness z of the switching cost is an independent full pi_v draw conditional on v and old labels. Therefore the actual cumulative H_small is the stated integral over sigma(v) pi_v(y) pi_v(z), with k_i(v,y)b_i(z)1_{T_v(z)>Lh}. This conditional product is an exact construction of the existing switch measure; it is not an assumption that f has independent coordinates or that the old transported source is uniform.

## Shared full-source two-posterior statistic

Put

    C_v(y,z)=integral_{m_w<m_v/K} c_w(y)c_w(z)dmu(w),
    calM=integral sigma(dv) E_(pi_v tensor pi_v) C_v.

Positive Tonelli expands this exactly to

    calM=integral q_v dv/m_v^2
                  integral_{m_w<m_v/K} I_vw^2 dmu(w),
    I_vw=integral f c_v c_w.

Since I_vw<=m_w by the SAME full matching, I_vw^2<=m_w I_vw cancels the small-end m_w in dmu(w)=dw/m_w. Using q_v<=lambda then leaves

    calM<=lambda integral dw integral f(y)c_w(y)
              [integral_{m_v>K m_w} c_v(y)dv/m_v^2]dy.

For fixed w,y, capture implies m_v>=q_-(2||v-y||infinity)^n. The actual-center density is bounded by max(Km_w,q_-rho^n)^(-2). The radial-volume variable t=rho^n has actual Lebesgue measure dt, so

    integral_0^infinity dt/max(Km_w,q_-t)^2
       =2/(q_- K m_w).

Thus

    calM<=2lambda |E|/(q_- K)
         <=2lambda X_q/(q_-^2 K).

No f-squared norm is assumed: the double full-source integral factors as the finite intersection mass squared, after which the matching inequality above reduces it to a single f. Strict mass atoms can be included in the envelope to enlarge the integral without introducing a crossing correction. Actual m_w>=q_-a^n and h>0 prevent zero denominators; null receivers/sources have zero cost. This lemma is actual dv geometry, not a quadrature-column assumption.

## Actual soft switching component

Define the common fixed mark psi(v,y,z)=min(1,C_v(y,z)/h). Since gamma_i are nested and sum_i b_i(z)<=1,

    sum_i k_i(v,y)b_i(z)<=k_0(v,y)<=C_col.

Multiplying the EXISTING H_small cost by psi and dropping only positive restrictions gives

    H_small,paid<=C_col calM/h
       <=eta_n X_q,
    eta_n=2lambda C_col/(q_-^2 K h)
         =2(lambda/q_-)C_col epsilon0/[K(1+sqrt(n))].

The remainder is exactly H_small*(1-psi), carrying all old labels and the high-T witness gate. H_ext is unchanged. The source-pair kernel C_v is fixed from full f/E rather than rebuilt per stage, which is essential for this once-only cumulative estimate. This is a real positive component of ORIGINAL H_small, not automatically a paid gamma/core subflow.

For fixed frozen absorption parameters (or a uniform prescribed upper bound on epsilon0), eta_n tends to zero exponentially in sqrt(n). Choosing a finite N_delta gives eta_n<=delta for larger dimensions; n<=N_delta can use G<=S(1+N_delta log2)W/2 as a separate whole-core estimate from 2G=integral fD. This does not justify retuning old h/f/marks after payment. Inserting into the R398 ledger costs 64Lambda delta X_q at the original entrance. That extra absorption must be explicitly reserved/accounted, not treated as free if an earlier total allowance was already exhausted.

No price for H_ext or the complementary H_small is supplied. No new smaller receiver is assigned original source/history eligibility, and no blanket root theorem is proved.

## Actual independent bounded arithmetic

Reviewer ran 42 Fraction checks before reading a new R399 proof: 27 exact radial-envelope integrals, 3 real-contained-4D-box geometry/statistic checks and 12 conditional soft-mark inequalities. The contained-box illustration has uniform compact f, q=1, actual disjoint center boxes with large R=1 and small R=1/2 and all smaller cubes contained; its calM is exactly V_large V_small/16. It is only a native check of this statistic, not a positive original-history fixture (uniform f has no surplus source). The scalar tests do not certify the general analytic theorem. No separate test file was saved and these checks are not mixed with author/parent counts.

Independent statement screen PASS with the pointwise incoming-density requirement above. The final author review below supersedes the preliminary waiting status.


## Final author and report review

Read the complete frozen r399_geometry.md and its standalone check script, then the final main/readme, the cluster checkpoint and MATLAB script/result. The independent derivation above agrees with the author proof. Specifically:

- The sourcewise R390 rank-strip bound gives k_i(v,y)<=C_col before averaging over the old source; no average-to-pointwise inference is used. Nested restrictions and the globally fixed sum b_i<=1 give one cumulative price, including infinitely many stages by positive monotone convergence.
- The exact double-posterior identity (9), I_vw^2<=m_w I_vw, native squared-mass tail and true dmu(w)=dw/m_w cancellation give precisely 2lambda|E|/(q_-K). No L2 norm of f, density cap or independent-selector-radius integration is inserted. All masses remain the original full-f masses.
- The mark psi and 1-psi form an exact positive split of H_small. The unused external witness w receives no clock/history eligibility. Positive residual retains C_v<h and both displayed individual source ranks, which do not imply spatial separation or a uniform paid fraction.
- For epsilon0<=1/2 and dimension-uniform rank constants, the stated N_delta is a valid conservative cutoff: eta_n<=A_* exp(-sqrt(n))<=delta for n>N_delta. A varying C_col requires a uniform bound. The low-dimensional whole-core estimate is an alternative, not an extra charge added to the switching route.
- The author equations (13)-(15) and final main/readme preserve exact eta_n and entrance 64Lambda eta_n. The low-dimensional BH coefficient S390+8s+S(1+N_delta log2), and entrance coefficient Lambda[2S390+16s+2S(1+N_delta log2)], are the direct old 2G0/4Lambda G0 substitution. Original H/W_nu fees and E387 absorption remain. No unallocated absorption balance is presumed; no original negative square is reused.

The final main/readme therefore pass in this limited mathematical and reporting scope. Historical full reductions are inherited rather than independently reaudited in this round. The remaining H_ext and H_small^(1-psi), all other original unpriced slots and global absorption are not certified paid.

## Actual execution and evidence boundary

Reviewer executed `python3 /tmp/r399_geometry_check.py` to completion (exit 0): 210 joint_capture + 336 marked_stages + 26 native_integrals = 572 Fraction assertions PASS; native interval value 35/384. The conditional equality counters 58/3424/4032 are exercised features, not additional assertions or independent fields. Author/parent reruns of the same script are not accumulated as new experiments.

The finite interval-incidence and synthetic bounded stage marks do not realize the original high-history core. The continuous-center one-dimensional two-radius calculation is native dv, but its rational K=3/2 is diagnostic and does not realize the original K=exp(sqrt(n)) or all original gates. The corrected hand-entered expected value and transparent successful rerun are accurately reported. These checks corroborate algebra; the analytic proof establishes the general result.

The reviewer also reproduced two Fraction cluster-spectrum terminal integrals, 9/4 and 23/12, separately from the 572 main script assertions and the 42 preliminary reviewer checks. This checkpoint has no new receipt: its common-source allocation is exact, while the established envelope retains the full O(n) mass width. Its conditional/spectrum conclusions are not inserted into the main ledger.

The MATLAB file and recorded output were reviewed, not independently rerun by this reviewer: nine ordinary-double quadratures with recorded maximum relative error 2.2204460492503131e-16. They check a scalar radial envelope only; they are neither rational/interval certificates nor a native full-history test. Their reporting in main/readme is accurate.

## Frozen byte bindings

SHA-256 below binds the exact files reviewed. No later author change is covered without an updated audit.

- `/tmp/r399_main.md`: `697fe7eeb12cd66240bf96d767b96f4714f96faa1b42ba4eb0d92bf531ad433e`
- `/tmp/r399_readme.md`: `cb7a03c2dd9922d86cb9a93dade4f7cb5f09a6f34a511ebe2715eecb776d3276`
- `/tmp/r399_geometry.md`: `84e9b4885011479d3da8a4bd7959389e1cf299a41a383d977ff087fbed6cba33`
- `/tmp/r399_geometry_check.py`: `d660bab70d34815fef770290e5769420cddd7f16e9b2219849f0d52a40012eb8`
- `/tmp/r399_geometry.result.txt`: `8c6b73658ad41db947183d77bc9990ab114e39c2fe0a451fcaba4454263d3ad2`
- `/tmp/r399_cluster.md`: `1dde3811fb382d0cf40597297f76cfdd605a4878aee51db7e7da684bebc41e29`
- `/tmp/r399_radial_check.m`: `1e92cfe8fd010b5b53ad8eb82ae656cbc4ff4780456c09708fb76dba8222d802`
- `/tmp/r399_radial.result.txt`: `bfb90bbc1b222bc551ba1b30f59e8174a180c9489034e8415b74804a8e9b872a`


Necessary inherited contracts are the already audited R398 bridge and R390 sourcewise strip theorem; no new statement of their validity is inferred from finite tests. The preserved R392 ledger supplies the old slot coefficients. These are existing dependencies, not additional new receipts.

FINAL PASS: freeze this bounded receipt and report. General closure remains open; no further research or additional pipeline run is required for this audit.
