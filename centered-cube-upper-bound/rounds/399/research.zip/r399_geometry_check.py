from fractions import Fraction as F
from itertools import product
Q=[set(range(8)),set(range(6)),set(range(2,8))]
Q += [set(range(i,i+2)) for i in range(7)]
rw=[F(i+1,20) for i in range(len(Q))]
counts={'joint_capture':0,'marked_stages':0,'native_integrals':0}
features={'strict_mass_equalities':0,'psi_equalities':0,'high_rank_equalities':0}

def poly_mul(a,b):
    out=[F(0)]*(len(a)+len(b)-1)
    for i,x in enumerate(a):
        for j,y in enumerate(b): out[i+j]+=x*y
    return out

def integral(p,a,b):
    return sum(x*(b**(j+1)-a**(j+1))/F(j+1) for j,x in enumerate(p))

for k in range(1,8):
    f=[F(1+(k*z)%3) for z in range(8)]
    for Kgap in [F(3,2),F(2),F(3)]:
        m=[sum(f[z] for z in q) for q in Q]
        mu=[rw[v]/m[v] for v in range(len(Q))]
        sigma=[rw[v]*m[v]/len(Q[v]) for v in range(len(Q))]
        features['strict_mass_equalities']+=sum(m[w]==m[v]/Kgap for v in range(len(Q)) for w in range(len(Q)))
        C=[]
        moment=[]
        for v in range(len(Q)):
            cv=[[sum(mu[w] for w in range(len(Q))
                     if m[w]<m[v]/Kgap and y in Q[w] and z in Q[w])
                 for z in range(8)] for y in range(8)]
            C.append(cv)
            source=sum(f[y]*f[z]*cv[y][z]/m[v]**2
                       for y in Q[v] for z in Q[v])
            cubes=sum(mu[w]*sum(f[z] for z in Q[v]&Q[w])**2/m[v]**2
                      for w in range(len(Q)) if m[w]<m[v]/Kgap)
            relaxed=sum(mu[w]*m[w]*sum(f[z] for z in Q[v]&Q[w])/m[v]**2
                        for w in range(len(Q)) if m[w]<m[v]/Kgap)
            assert source==cubes and cubes<=relaxed
            moment.append(source)
            counts['joint_capture']+=1
        # Actual form of the density-slice marks, with decreasing auxiliary D_i.
        thresholds=[F(0),F(1,2),F(1),F(2),F(4)]
        bs=[]
        for i in range(1,len(thresholds)):
            bi=[]
            for z in range(8):
                Di=F(10+z,2+i)
                bi.append((min(f[z],thresholds[i])-min(f[z],thresholds[i-1]))
                          /f[z]*max(F(0),1-1/Di))
            bs.append(bi)
        assert all(sum(b[z] for b in bs)<=1 for z in range(8))
        positiveC=sorted({C[v][y][z] for v in range(len(Q)) for y in Q[v] for z in Q[v] if C[v][y][z]>0})
        hs=[F(1,10),F(1,3),F(1)]+positiveC[:1]
        exactrank=sum(mu[w] for w in range(len(Q)) if m[w]<=m[0] and 0 in Q[w])
        cuts=[F(0),F(1,10),F(1,2),exactrank]
        for h,cut in product(hs,cuts):
            Ccol=F(3,2)
            paid=F(0)
            unweighted=F(0)
            residual=F(0)
            for v in range(len(Q)):
                Tv=[sum(mu[w] for w in range(len(Q)) if m[w]<=m[v] and z in Q[w]) for z in range(8)]
                for i,bi in enumerate(bs):
                    for y in Q[v]:
                        # A nested bounded incoming-source mark. It is not a claim
                        # to realize the original history kernel in this diagnostic.
                        ki=Ccol*F(1+(v+y+k)%3,3) if i<=v%4 else F(0)
                        for z in Q[v]:
                            wt=sigma[v]*f[y]*f[z]/m[v]**2*ki*bi[z]*(Tv[z]>cut)
                            psi=min(F(1),C[v][y][z]/h)
                            if C[v][y][z]==h:
                                assert psi==1
                                features['psi_equalities']+=1
                            if Tv[z]==cut:
                                assert wt==0
                                features['high_rank_equalities']+=1
                            paid+=wt*psi
                            residual+=wt*(1-psi)
                            unweighted+=wt
            bound=Ccol/h*sum(sigma[v]*moment[v] for v in range(len(Q)))
            assert paid+residual==unweighted and 0<=paid<=bound
            counts['marked_stages']+=1

# Native center envelope: x=(2||v-z||_infinity)^n has center-volume dx.
for q,M in product([F(1,3),F(3,4),F(1),F(2),F(5)],repeat=2):
    x0=M/q
    central=x0/M**2
    # Exact antiderivative of 1/(q*x)^2 from x0 to infinity.
    tail=1/(q*q*x0)
    assert central==tail==1/(q*M)
    assert central+tail==2/(q*M)
    counts['native_integrals']+=1

# Native one-dimensional two-source moment with f=1 on [-4,4],
# big centers v in [-1,0], R_v=2, small centers w in [0,1], R_w=1.
# q=1, m_v=2,m_w=1 and rational K=3/2. The difference t=w-v
# has density t on [0,1], 2-t on [1,2]. Intersection length is
# 1 for t<=1/2 and (3/2-t)_+ thereafter.
ramp2=poly_mul([F(3,2),F(-1)],[F(3,2),F(-1)])
joint=(integral([F(0),F(1)],F(0),F(1,2))
       +integral(poly_mul([F(0),F(1)],ramp2),F(1,2),F(1))
       +integral(poly_mul([F(2),F(-1)],ramp2),F(1),F(3,2)))/4
assert integral([F(0),F(1)],F(0),F(1,2))==F(1,8)
assert integral(poly_mul([F(0),F(1)],ramp2),F(1,2),F(1))==F(13,64)
assert integral(poly_mul([F(2),F(-1)],ramp2),F(1),F(3,2))==F(7,192)
assert joint==F(35,384)
# The proof's receiver-w bound before replacing its set by all E.
assert joint<=F(2)/F(3,2)
counts['native_integrals']+=1
print('PASS',counts,'total',sum(counts.values()))
print('native_interval_joint_moment',joint)
assert all(features.values())
print('boundary_features',features)
