# R399 — shared-source cluster allocation: finite checkpoint

No additional root-order receipt is proved here. The allocation below preserves the actual endpoint weights and source sharing, but its established global price still has the full O(n) mass-spectrum width. It is not added to the R398 ledger.

## Exact allocation and single-cluster geometry

Freeze the R398 field and original marked core γ0. Let η=γ0,out+γ0,in, so η(E)=2G0 and η(du)=s(u)q_u du with 0≤s≤S. All original marks have only been projected, not changed. Set E*={s>0}, m_-=q_-a^n and m_+=λb^n. For z and t∈[m_-,m_+], define the actual common-point cluster

A_z(t)={u∈E*: c_u(z)=1, m_u≤t},
V_z(t)=|A_z(t)|,
M_z(t)=ess sup_{u∈A_z(t)} m_u,

where the essential supremum is with respect to real du, and M=0 for a null cluster. These quantities are jointly measurable: for instance {M_z(t)>r} is detected by the positive integral of 1_{A_z(t)}1_{m_u>r}. No new intersection cube is treated as a receiver constraint.

Every center in A_z(t) lies, up to a null set, in the cube centered at z of side ess sup_{A_z(t)} R_u. Actual full-f matching therefore gives

V_z(t)≤(ess sup R_u)^n≤M_z(t)/q_-≤min(t,W)/q_-.       (1)

The essential-supremum limit is harmless: each actual m_u≤W and R_u^n=m_u/q_u. No source-density estimate is used in (1).

Use the original posterior π_u(dz)=f(z)c_u(z)dz/m_u. The elementary positive identity

1/m_u=1/m_+ + ∫_{m_-}^{m_+}1_{m_u≤t} dt/t²             (2)

gives an exact common-source cluster allocation of ηπ. In particular

2G0 = ∫ f(z) [m_+^{-1}∫_{A_z(m_+)}s(u)q_u du
             +∫_{m_-}^{m_+}t^{-2}∫_{A_z(t)}s(u)q_u du dt] dz.  (3)

For each endpoint u, its total coefficient in (2), multiplied by m_u, is one. Thus (3) does not pay its source independently at every cluster: the nested clusters are combined by one positive layer integral. All source/time/history weights of η remain in s. Tonelli justifies (3), including arbitrary atoms of the actual mass selector.

## What the integrated cluster maxima presently cost

Applying (1) after (3), with s q≤Sλ, yields

2G0≤(Sλ/q_-)∫f(z) Θ(z) dz,
Θ(z)=M_z(m_+)/m_+ + ∫_{m_-}^{m_+}M_z(t) dt/t².          (4)

This is a concrete upper price for this allocation, not an identity defining the original cost. Its available general estimate is only

Θ(z)≤1+log(m_+/m_-)
      ≤1+log(λ/q_-)+n log2.                              (5)

The obstruction to using the single-cluster W bound globally is precise: the same source z can belong to clusters whose maxima track t throughout the full admissible mass interval. Integrating the upper envelope M_z(t)≤t then leaves dt/t. The common-point condition alone has not compressed this interval.

For clarity, if a particular source's essential captured mass spectrum is finitely supported on x1<...<xk, then the SAME functional, with the empty intervals and the terminal part retained, is exactly

Θ(z)=1+Σ_{j=1}^{k−1}(1−x_j/x_{j+1}).                    (6)

When the spectrum fills an interval [l,u], it is instead 1+log(u/l). These observations only audit the layer cost; no sparse-spectrum hypothesis is asserted for the actual core. The original strict mass gap concerns pairs of endpoints on an edge. It does not by itself remove the intermediate masses of other actual receivers from A_z(t). Similarly, high source rank is a lower occupancy condition and does not supply the missing upper estimate for the integrated maxima in (4).

The unresolved geometric step for this specific allocation is to bound ∫fΘ at root order, or to construct a different shared allocation whose maxima can be charged jointly at that order. Neither follows from (1)–(3). We have not proved that the actual integral in (4) must be large; only that its present general envelope is linear in n. Thus this checkpoint does not price H_ext, H_small, or a new positive core subflow, and adds no source fee or absorption term to the main ledger.

## Minimal local arithmetic check

Python standard-library Fraction was actually run on the finite spectra (1,2,8) and (1,3/2,2,3), with terminal upper cutoff twice the largest mass. Direct integration of the piecewise-constant maximum profile agrees with (6), giving 9/4 and 23/12 respectively. This checks only the terminal/crossing algebra, not a full native core configuration. No larger numerical campaign or sparse-spectrum branch was undertaken.
