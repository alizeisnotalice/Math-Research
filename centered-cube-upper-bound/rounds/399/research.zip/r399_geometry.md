# R399 — An absorbable common-far-past part of the actual two-source small-end bill

## 1. Precise receipt and full complement

Keep the complete R398 field, original core γ_0, decreasing actual restrictions γ_i, and switching marks b_i. In particular ∑_i b_i(z)≤1, all masses are the complete matched masses m_v=f(Q_v)=q_v R_v^n, and receiver integration is actual Lebesgue dv. Put K=exp(√n), s=1+√n and h=s/(ε_0q_-), as already frozen.

For two sources y,z in Q_v define the occupation of a **common** actual much smaller receiver:

 C_v(y,z)=∫_E c_w(y)c_w(z)1_{m_w<m_v/K} μ(dw),
 ψ_v(y,z)=min{1,C_v(y,z)/h}.                              (1)

The letter C_v in (1) denotes a rank quantity, not the incoming constant C_col. The extra receiver w receives no original χ, clock or history qualification.

Use the exact old-source disintegration

 γ_i(dv,dy after integrating u)=σ(dv)π_v(dy)k_i(v,y),
 k_i(v,y)=1_{A_i}(v)∫_E1_{A_i}(u)(q_u/q_v)c_u(y)
                    χ_0(y,u,v) μ(du)/T_y(m_u).           (2)

Here χ_0 includes all the original R389–391 marks, including the physical-clock average and middle ranks. Zero denominators are assigned zero off their live support. The already audited **pointwise in the old source** bound is

             0≤k_i(v,y)≤k_0(v,y)≤C_col.                 (3)

This is the sourcewise incoming estimate underlying R390, not an inference of a pointwise bound from an averaged receiver column. Its constant is
C_col=(λ/q_-)[1−β+log(β/α)], 0<α<β<1. If the middle-rank interval is empty, the traffic here is zero.

The actual high-small bill equals

 H_small=∑_i∫σ(dv)π_v(dy)π_v(dz)
               k_i(v,y)b_i(z)1_{T_v(z)>Lh}.              (4)

Let H_small^ψ and H_small^(1−ψ) insert ψ_v and 1−ψ_v, respectively, in (4). Then the new receipt is

 H_small^ψ ≤ η_n X_q,
 η_n=2λ C_col/(q_-²Kh)
     =2(λ/q_-)C_col ε_0/[K(1+√n)].                      (5)

This is a newly priced component of the actual cumulative switching bill. In particular it pays the entire double-source portion where C_v(y,z)≥h, as well as its stated soft fraction below h. The full remainder is exactly

             R_new=H_ext+H_small^(1−ψ),
             R_L=H_small^ψ+R_new.                       (6)

There is no assertion that ψ is uniformly large: two sources can each have large individual rank without having large common far-past. The argument does not close R_new. On the positive H_small^(1−ψ) remainder, C_v(y,z)<h, while the original source still has T_v(y)>2h and the new source has T_v(z)>Lh. These are simultaneous actual two-source rank conditions; they imply no additional spatial separation or inherited history.

## 2. A genuine native-center squared-mass tail

For every source z and mass threshold M>0, the actual selected cubes satisfy

 ∫_E q_v c_v(z)1_{m_v>M} dv/m_v² ≤ 2λ/(q_- M).           (7)

Indeed let ρ=2||v−z||_∞ and t=ρ^n. Capture implies R_v≥ρ and m_v≥q_-t. On the indicated mass tail,

 q_v c_v(z)1_{m_v>M}/m_v²
                ≤ λ/max{M,q_-t}².

The cube of center points with (2||v−z||_∞)^n≤t has volume exactly t. Hence integration of this radial envelope over all real centers is exactly

 λ∫_0^∞ dt/max{M,q_-t}²
 = λ[∫_0^(M/q_-)dt/M²+∫_(M/q_-)^∞dt/(q_-²t²)]
 = 2λ/(q_-M).

This bounds arbitrary actual selector fields; it never integrates the chosen radius as an independent variable. Closed equality in the envelope and the strict original mass cutoff cause no atom loss. No source-volume or density estimate is used. Extending the center integral only enlarges a nonnegative integrand.

## 3. The joint source moment has an exponential far-mass gain

The key integrated geometric/matching estimate is

 J_2:=∫_E σ(dv) E_(π_v⊗π_v)[C_v(y,z)]
                 ≤ 2λ|E|/(q_-K)
                 ≤ 2λ X_q/(q_-²K).                     (8)

Proof. Write I_vw=f(Q_v∩Q_w). Positive Tonelli and the two independent full-f posterior integrations give the exact square

 J_2=∫_E μ(dw)∫_{m_v>K m_w} q_v I_vw² dv/m_v².           (9)

Full matching gives I_vw≤m_w, so I_vw²≤m_w I_vw. For fixed w, apply (7) with M=K m_w to obtain

 ∫_{m_v>K m_w}q_v I_vw² dv/m_v²
 ≤m_w∫f(z)c_w(z)
          [∫ q_v c_v(z)1_{m_v>K m_w}dv/m_v²]dz
 ≤m_w · m_w · 2λ/(q_-K m_w)
 =2λ m_w/(q_-K).

Integrating against μ(dw)=dw/m_w proves the first inequality in (8). The second uses |E|≤X_q/q_-. All exchanges concern nonnegative quantities; the finite right side also proves finiteness. Arbitrary concentration of f is allowed: the square in (9) is the square of an intersection **mass**, not ∫f².

The price uses the actual common receiver w only once after swapping the complete integrals. There is no count of cubes or stages. This is the simultaneous-reuse estimate missing from a purely pointwise overlap statement: the center tail integrates v while the strict mass ratio supplies 1/K, and then m_w cancels its true receiver measure.

## 4. Proof of the actual marked receipt

The fields in (1) are fixed across the density stages because all original cubes and masses are fixed. Inserting ψ≤C_v/h in (4), using (3), and summing the b_i at the same source z FIRST gives

 H_small^ψ
 ≤(C_col/h)∫σ(dv)π_v(dy)π_v(dz)C_v(y,z)
                    ∑_i b_i(z)1_{T_v(z)>Lh}
 ≤(C_col/h)J_2.

Equation (8) gives (5). For finite stages this is ordinary positive integration, and monotone convergence gives the full infinite bill. In particular no stage receives a separate W charge.

The old source y still carries its actual k_i(v,y); the new source z carries its actual b_i(z) and high-rank indicator. They are integrated under two copies of the complete π_v. We only drop their positive restrictions for a proved upper bound. We do not assert independence of the coordinates of f, or transplant χ from y to z or w.

This proof uses a new positive double-source moment to pay a marked piece of H_small. It does not subtract the original BH negative capture square again. It also differs from the R398 low-rank price: the whole branch C_v≥h is a **high common occupation** branch, and its cost is controlled by full matching plus the squared native-center tail.

## 5. Arbitrary small absorption and exact ledger substitution

Equation (5) states the exact price at the already frozen h; it does not silently consume an unallocated ε. For a prescribed δ>0, suppose the frozen rank constants have dimension-uniform values as in the present contract. Since ε_0≤1/2, put

 A_*=(λ/q_-)C_col,
 N_δ=ceil(max{3, log_+(A_*/δ)}²),
 log_+ x=max{0,log x}.                                   (10)

For n>N_δ, √n>max{3,log_+(A_*/δ)}, and therefore η_n≤A_*e^(−√n)≤δ. This uses a uniform upper bound on ε_0, so remains valid when ε_0 is chosen synchronously as a function of n. If all parameters, including ε_0, are fixed independently of n, A_* can instead be replaced by 2(λ/q_-)C_col ε_0. If a rank constant is allowed to vary with n, a uniform upper bound must be supplied before claiming a fixed N_δ.

For the full complementary dimension range n≤N_δ, use the existing native center bound directly on the entire core:

 2G_0=∫fD_0≤S A_n W≤S(1+N_δ log2)W,
 S=β+C_col.                                              (11)

Thus these dimensions need no new switching argument. They are not omitted. Also H_small^ψ≤H_small≤G_0, since γ_i≤γ_0 and ∑b_i≤1. Consequently the standalone all-dimensional receipt

 H_small^ψ≤δX_q+[S(1+N_δ log2)/2]W                       (12)

is valid, although direct replacement of the entire low-dimensional G_0 slot by (11) is cheaper. One uses one of these routes, not both.

In the large-dimensional branch n>N_δ≥9, the R398 formula becomes

 G_0≤16R_new+16η_nX_q+16(s+P_L)W,
 P_L=λh[β(L+ε_0)+C_col L].                               (13)

Therefore its actual BH slot is

 BH≤32R_new+(E387+32η_n)X_q
                  +[S390+40s+32P_L]W.                  (14)

At the original entrance, the complete inherited expression is

 Λ{8λHW+2d_eff A_nW_ν/H+64R_new
       +(2E387+64η_n)X_q+[2S390+80s+64P_L]W}.            (15)

No other coefficient changes. A global allowable new entrance absorption κ_rem requires choosing δ so that 64Λδ≤κ_rem; this note does not assert that such an unallocated global balance has already been established. In the low-dimensional branch, substitute (11) directly into the R392 2G_0 slot, or 4ΛG_0 at the entrance, and withdraw the R398 switching replacement there.

The complete unpriced high-rank part is (6), retaining every factor 1−ψ, every stage, all original marks, and H_ext with its original E_uv/Z_u reweighting if that representation is used. No uniform positive proportion of R_L is claimed paid.

## 6. Reproducible local checks and their exact scope

Executed on the local machine:

    python3 /tmp/r399_geometry_check.py
    PASS {'joint_capture': 210, 'marked_stages': 336,
          'native_integrals': 26} total 572
    native_interval_joint_moment 35/384
    boundary_features {'strict_mass_equalities': 58,
                       'psi_equalities': 3424,
                       'high_rank_equalities': 4032}

All arithmetic is Fraction. Stage 1 independently computes the π_v⊗π_v joint occupation and the squared-intersection representation (9), then checks I_vw²≤m_wI_vw on full piecewise-constant source cells and actual interval incidences, with three rational strict far gaps. Its receiver integration is quadrature, not native dv. Stage 2 keeps nested bounded incoming-source marks, density-slice b_i of the actual displayed form with decreasing D_i, high-rank cuts and soft ψ; it checks the exact paid/complement split and the marked bound by C_col J_2/h. Those finite marks are algebraic diagnostics, not a claimed realization of the original χ/history. Exact mass, rank and ψ threshold equalities are explicitly exercised.

Stage 3 checks the native radial integral in (7) exactly for 25 rational (q_-,M) pairs, using the true center-volume variable t=(2||v−z||_∞)^n. It also computes one actual continuous-center interval model: f=1 on [-4,4], big centers v∈[-1,0] with side 2, small centers w∈[0,1] with side 1, and rational K=3/2. The normalized two-source joint moment equals 35/384 by piecewise polynomial integration. This is native center integration, but not a full core/high-history example and not the original K=exp(√n).

The first run stopped at an incorrectly hand-entered expected value 19/192 for that last interval integral. Independently evaluating its three pieces gives 1/8, 13/64 and 7/192, whose sum divided by 4 is 35/384. The expected value was corrected, the three component identities added, and the full expanded script rerun successfully. The theorem relies on the analytic proof (7)–(9), not numerical fitting or the number of checks.

**Status.** A specific actual two-source fraction of H_small now has the explicit absorbable price (5), with complete complement and ledger above. The remaining high-rank sources with little common far-past, together with H_ext, have not received a general root-order bound. Work stops at this proved branch.
