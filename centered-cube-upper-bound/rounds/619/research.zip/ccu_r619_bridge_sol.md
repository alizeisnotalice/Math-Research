# R619：坐标 conditional-clique 合并的准确竞争项

**结论。** crossing 族可以无损转换为半径加权的低一维 packing，但没有得到 crossing 与左右族的统一有利合并。本次给出准确的未付款容量项，以及一个同一真实来源、约束全紧的实际 greedy 族，说明 source 双侧平衡和 receiver 无重叠仍不能自动消除此项。不声称新的 C_n 估计。

## 1. 可用的准确降维接口

固定坐标切面 `x_i=h`。将 selected stars `A_j=aB_j` 分成全部在左侧 L、全部在右侧 R，以及严格穿越切面的 C。对 C，记投影为 `A'_j=aB'_j`，原半径 r_j。

由于每个 C 中 star 的第 i 个区间都包含 h，投影中在同一 x' 命中的全部 stars 在 `(h,x')` 共同相交。因此 C 的全维 packing 约束与投影 packing 约束严格等价，且

`Q_n(C)=2a·max{Σ_{j∈C}λ_j r_j |A'_j|: Σλ_j1_A'j<=1 a.e.}`。 (1)

这保留半径权 r_j；不能用普通低维常数替代右侧的加权问题。

相应的 selected 小 receiver 满足

`|union_{j∈C}B_j| <=2(a+1)∫max_{j∈C}[r_j1_B'j(x')]dx'`。    (2)

因为每个 crossing receiver 点都满足 `|x_i−h|<(a+1)r_j`。若只计实际 increments，其体积更小，(2)仍成立。式(1)–(2)不需要来源坐标独立。原全部 supplied receiver 仍必须保留 R616 的 `R<=C_cov V`，`C_cov=1+A_a/τ`，不能把它默认为仅 selected crossing 小 cubes。

## 2. 未付款的联合容量

取左右两族各自的一个全局可行 packing，其合并 profile 为 `p=p_L+p_R<=1`；左右 star 支持分离，所以其目标可以准确相加为 `Q_S=Q_L+Q_R`。再取 crossing 可行 packing，profile 为 q≤1，目标 Q_C。

欲用非负比例 α、β合并原 star 权，准确条件是

`ess sup_x[αp(x)+βq(x)]<=1`，                        (3)

得到目标 `αQ_S+βQ_C`。只知 p,q≤1 时，安全条件仍是 α+β≤1，目标保证仅为 `max(Q_S,Q_C)`。没有证明 source 双侧占比迫使(3)放松。

一个可检验但尚无统一下界的收益量是

`ε=2−ess sup(p+q)>=0`。

若 ε>0，同权合并给 `(Q_S+Q_C)/(2−ε)`；但 ε可以为0。另一方面小 receiver 的分支 union 若有实际交叠，可在 receiver 端扣除；该交叠不能由 star/source 支持相交替代。需要同时证明(3)的 collision deficit、receiver 交叠或额外半径加权支付中的至少一项，才能付掉 max 损失。把各 source 约束的左右比例当成逐 receiver 容量比例，会跳过(3)。

## 3. 为什么“最佳 source + 平衡 + 无松弛”仍不免费合并

以下只是针对上述推断的有限精确限制，绝非根阶反例。取 n=1、a=8、t=3、τ=1/4，切面为0；选中 stars 为

`A_C=(-16,16)`，`A_L=(-25,-9)`，`A_R=(9,25)`。

对应原小 cubes（区间）分别为

`B_C=(-2,2)`，`B_L=(-18,-16)`，`B_R=(16,18)`。

按半径2、1、1顺序实际 greedy 可全部选入：各 `w_j=1/8`，左右中心到 C 中心距离17小于 `b·2=64/3`，两侧之间距离34大于 b，故入选时负载分别0、1/8、1/8，均≤τ。三个小 receivers 真正不交，实际 increments 体积为4、2、2。

令同一 L1 source 在 `(-16,-9)` 与 `(9,16)` 上分别取常密度16/7，其余为0。总质量为32，且

`μ(A_C)=32=|A_C|`，`μ(A_L)=μ(A_R)=16=|A_L|=|A_R|`。

左右 star 不交，所以任何满足这三个需求的 source 质量至少32；上述 source 达到最优。三个约束全紧，C 的 source 左右各占1/2。若要严格 bad-star，用 `(1+δ)μ` 并令δ趋零，几何不变。

侧向最优 packing 取 L、R 权各1，目标32；crossing 最优取 C 权1，目标也32。两个 profile 在 `(-16,-9)` 和 `(9,16)` 上均等于1，所以(3)确实强制 α+β≤1，即 ε=0。与此同时 receiver 交叠为0。这个 connected path 族不是 clique：L与R无交，不能使用 pairwise-overlap 的 Helly2 把全 connected 族当成共同 source clique。

本例实际 receiver/packing 比为8/32=1/4，远不困难。它只严格表明：这些结构条件本身不提供额外合并容量或 receiver 交叠，不能据此写出无损联合归纳。

## 4. 与主路对齐及停止点

已向 global_sol 交换(3)及上例。其独立 active-clique 匹配机制能用真实不交 star 对传递 exclusive λ 质量；那仍需处理 zero-dual/slack stars 的 receiver 新增，不能由 active flux 直接付款。本稿没有把该未证项转成结论。

本次没有得到从共同 source 双侧比例控制 ε、receiver 交叠或半径加权max-envelope 的新一般估计，故停止，不制造进一步局部归纳。完整目标仍是统一构造 packing Q 使 `R/Q` 为根阶；若用 cover，则应估计 `(1+A_a/τ)V/Q`，所有 a 与 τ 费用保留。

**实际数学核验。** 在已有数学 venv 用 Python Fraction 精确检查上述单个固定族的 greedy 资格、source 三个紧约束、最佳质量32的可行上界、receiver 不交和实际比1/4，全部通过。没有输入扫描、仓库修改或一般维数外推。
