# R619 all-source logarithmic barrier diagnostics

40 positive-increment cubes per family; exact endpoint face cells encoded as uint64 incidence patterns. Every star participates; incidence is reused across alpha values. The full-source covering LP is solved once per geometry. Finite floating solver results are diagnostics, not rigorous KKT certificates.

| seed | εV/mLP | status | min λ | max 1/λ | mass identity error | stationarity relative | min λ/(εv/M) |
|---:|---:|:---|---:|---:|---:|---:|---:|
| 61901 | 0.1 | optimal | 0.0002873881 | 3479.615 | 0.000198 | 0.000243 | 2.574531 |
| 61901 | 0.01 | optimal | 3.134098e-05 | 31907.11 | 0.000564 | 0.000287 | 2.657513 |
| 61901 | 0.001 | optimal | 3.15764e-06 | 316692.2 | 7.17e-05 | 0.000514 | 2.66571 |
| 61901 | 0.0001 | optimal | 3.104461e-07 | 3221171 | 2.6e-05 | 0.0259 | 2.585127 |
| 61902 | 0.1 | optimal | 0.002165812 | 461.7205 | 1.09e-05 | 1.36e-06 | 2.363653 |
| 61902 | 0.01 | optimal | 0.0002272494 | 4400.453 | 0.000117 | 0.000302 | 2.41216 |
| 61902 | 0.001 | optimal | 2.280276e-05 | 43854.33 | 4.32e-05 | 0.000668 | 2.414404 |
| 61902 | 0.0001 | optimal | 2.281333e-06 | 438340.2 | 5.45e-06 | 0.000922 | 2.416098 |
| 61903 | 0.1 | optimal | 0.0005056899 | 1977.497 | 0.000556 | 3.8e-05 | 2.662963 |
| 61903 | 0.01 | optimal | 5.204027e-05 | 19215.89 | 2.6e-06 | 6.28e-06 | 2.666349 |
| 61903 | 0.001 | optimal | 5.214468e-06 | 191774.1 | 4.3e-05 | 0.000293 | 2.667043 |
| 61903 | 0.0001 | optimal | 5.280362e-07 | 1893810 | 1.51e-05 | 0.00712 | 2.700295 |
