# R619 全局 packing 路线：独立审计

日期：2026-10-28。先从父任务准确命题独立推导，初审时不读R619作者新稿；之后按第8–12节核对新增机制、作者最终稿及整合报告。仅沿用已核R618有限source LP及完整cover合同。未改他人文件，未运行Git，未扫描实例或反例。

## 1. 准确全局对象与算子入口

任意非空有限supplied小cubes B_j=B(y_j,r_j)，A_j=aB_j，a>1；U=∪B_j。设η>0，同一个非负L1来源f满足∫_(A_j)f≥η|A_j|。令

Q*(A)=max{Σ_jλ_j|A_j|:λ_j≥0，Σ_jλ_j1_(A_j)≤1 a.e.}。

R618给最小source质量m(η)=ηQ*(A)。任意真正可行packing都给ηQ≤||f||1。因此若能对所有有限supplied家族证明Q≥|U|/K_n，就直接得到该完整receiver上界；这里**不另付Ccov**。只有先转为greedy selected子家族、再用|U|≤Ccov·V桥接时，才必须保留Ccov=1+A_a/τ及其参数可行条件。不能重复付，也不能漏付。R619直接命题本身没有τ或selected-radius顺序。

从有限全supplied命题恢复全尺度时：对紧K⊂{M_nf>η}，每个x∈K选实际bad半径R_x，供给B_x=B(x,R_x/a)。这些小cubes覆盖K，取有限子覆盖后，其a-stars恰为原真实bad cubes。由η|K|≤η|U|≤K_nηQ≤K_n||f||1，再用内正则性恢复全超水平集。不能只控制有限centers的数量或测度；有限centers本身是零体积，不是receiver预算。

同一来源条件并不先验排除某种有限几何：任意有限星族都可由f=(η+δ)1_(∪A_j)变为同源strict bad。因此面向所有任意f的source-free全局命题，仍必须处理所有有限几何。

## 2. a的敏感性与一个准确等价夹逼

定义全局常数

Kpack(n,a)=sup_(全部有限cube家族) |∪B_j|/Q*(aB_j)。

则有严格关系

C_n≤Kpack(n,a)≤P(a) C_n，P(a)=(1+1/a)^n。              (1)

左边是第1节完整有限cover入口。右边：对给定家族取η=1的LP最优L1来源f*，质量Q*。对任意x∈B_j，A_j⊂B(x,(a+1)r_j)，故M_nf*(x)≥1/P。使用任意低于1/P的strict水平并取极限，得到|U|/Q*≤P C_n。这里不是把U误认作原水平1的超水平集。

所以a≫n时，这个全局packing命题已几乎等价于原算子常数问题，不能由“精确LP”或Helly本身宣称降阶。对固定stars A_j重写receiver为A_j/a，可见Kpack(n,a)随a非增；由(1)，固定n时a→∞准确趋向C_n。注意这个单调性指对全部家族取sup后的常数，不是固定B家族的各个LP系数必逐项单调。

**最重要的N/a量词。** 对固定N个cubes，Q*≥max_j|aB_j|，|U|≤N max_j|B_j|，故

|U|/Q*≤N/a^n。                                         (2)

固定规模的比值随a增大可以趋零，但Kpack≥C_n并不会趋零。有限cover的N必须允许依a、f、尺度及紧receiver增长；sup全部有限族和固定N的a极限不可交换。实际bad stars若保持R_x，增大a缩小的是供给receiver cubes，需要重新取覆盖，不能继续假定旧有限centers覆盖原K。

共同交簇成本P(a)对a敏感：a约n时P有常数界，a≫n时P→1；欲只付polylog损失需n/a=O(loglog n)，欲n^(o(1))损失需n/a=o(log n)。但仅由“与更大star相交”的R618粗成本(2+1/a)^n仍趋近2^n，不会靠增大a变成根阶。

a还改变star体积、incidence cells、cliques、LP及任何冻结权。不能固定一次source/λ/选中族的证书，修改a后仍沿用。若转回R616 greedy-cover路线，须同时保留a>2t>2和完整Ccov，而不能将其当a>1直接命题的无条件免费子步骤。

## 3. λ与来源的合法依赖

对给定实际f、η、有限家族，λ可以依赖整个输入、所有平均、几何、n、a及全局优化结果；只要在对source变量y积分前是一套固定系数，并对所有y满足packing。它不能在每个来源点y或每个局部receiver配置上重新选一套后，仍把右侧||f||1只付一次。

更强的纯几何定理是“对每个有限家族存在全局λ”，这正是本轮目标。最小来源f*则是该家族的另一个输入：可用于给原f的质量下界，但其LP最优性/互补松弛不能自动加给原任意f。保持全部supplied约束与只保持selected约束也不能混用。

L1最优可由正体积cell上的常数密度实现；strict bad由缩放1+ε逼近。因此不存在可免费忽略的原子密度帽或源独立性条件。不同clique/source patch可以有不同密度，但均属于同一个总质量，只能进行一份全局结算。

## 4. Cube Helly-2给什么，不给什么

有限开轴平行boxes（尤其cubes）的pairwise非空相交蕴含共同非空开交：逐坐标看有限开区间，最大左端严格小于最小右端。故intersection graph的每个clique都对应共同正体积source区域。仅闭面接触不能当作开stars的edge。

于是packing精确等价于所有clique约束

Σ_(j∈C)λ_j≤1，对每个clique C。

任一点的membership是clique；反向每个clique确有正体积共同交，所以a.e.约束也必覆盖它。最大cliques已足够。source primal也可写成以cliques为列、覆盖各star体积需求的分数覆盖：共同交允许同一块source质量同时满足一组stars，但各star的需求仍跨不同clique列共同求和。

这只是LP incidence的精确组合化，不是非局部收费定理。不能为每个clique独立发满额预算，再把所得packings直接相加；同一个star以及同一个source点会跨预算重复出现。若用R618共同交分组，仍必须证明代表的全空间重数D可控；Helly-2只保证组内共同点，不控制组间拥挤、不同半径代表、receiver体积或分数分组的总成本。也不能凭Helly-2宣称packing LP自动整数化。

Q*由clique incidence及star体积决定，而目标receiver U还保留真实小cube几何。只分析抽象clique预算而遗失U、a和半径尺度，尚不足以证明目标不等式。

## 5. 互补松弛及可使用的真正全局耦合

归一化η=1。取最优cell source质量z_C与最优λ，令M_jC为incidence，d_j=|A_j|。有限LP的准确gap恒等式是

Σ_Cz_C−Σ_jλ_jd_j
 =Σ_Cz_C(1−Σ_jλ_jM_jC)
  +Σ_jλ_j(Σ_CM_jCz_C−d_j)。                              (3)

两边最优时各非负项均为0。因此z_C>0⇒该source cell packing饱和；λ_j>0⇒该star平均需求在f*上紧。原任意f只满足非负gap，不自动满足这些等式；strict bad输入更不能在同一η下被当作精确最优source。

实际原f也有相应准确恒等式

||f||1−ηΣλ_j|A_j|
 =∫f(y)[1−Σλ_j1_(A_j)(y)]dy
  +Σ_jλ_j[∫_(A_j)f−η|A_j|]。

未使用packing容量与bad-star slack是同一gap的两部分，不能把它们再次当成两笔免费收益。

在最优对上，ζ_Cj=z_Cλ_jM_jC给一份可供作者使用的全局耦合：

Σ_jζ_Cj=z_C，Σ_Cζ_Cj=λ_jd_j。                            (4)

总量只有Q*。这严格连接饱和source cliques与有价stars，但尚未连接整个receiver U的体积。若用它收费，就必须再证明receiver向这同一份容量的分配/运输有统一成本，而不是每个C独立获得完整代表体积预算。

一种更强但可检验的收费证书是：细分receiver U成cells，向上述source cells输送其体积，source cell总收费≤K z_C，且所有receiver需求均被覆盖。若限定合法边来自同一supplied star，则需要验证相应的所有容量cut，而非只看单star或单clique；这是一条可能更强的充分路径，不是已证明的结论，也不宣称为根阶的唯一必要形式。

## 6. 新候选/递推必须保留的检验门槛

1. **全空间可行性：** 同一套λ覆盖所有source incidence，不能只测centers、一个suffix、一个clique或随机点；cells必须保留正体积及正确开边界。
2. **完整receiver：** 直接对全部supplied U收费，或明确selected cover的Ccov与rejected cubes；不以有限centers或selected union替代。
3. **统一量词：** 常数独立于N、输入密度/集中程度、半径跨度及receiver选择；a(n)引起的cover规模增长不得隐藏。
4. **真正几何联系：** 将clique/LP最优性连接到receiver体积、尺度与共享source容量；不能把LP强对偶、互补松弛或饱和权存在本身当作根阶估计。
5. **若用递推：** 写明receiver覆盖/剩余项、同一原source的子预算组合方式、所有重叠和尺度费用，以及统一收缩率与可求和总费用。多个局部clique各自收缩，不等于整个共享source预算收缩。
6. **数值证据：** 固定N、固定a的LP/冻结结果不能验证(2)背后的无限族量词。primal可行质量是最小source成本的上界；真正质量下界须由全空间dual可行证书给出。

按用户数学工具偏好，实际调用指定数学venv的SymPy，对形式3-star/4-cell矩阵核验(3)的primal-dual gap展开，残差为0；没有求解新LP、参数扫描或反例搜索。Helly、(1)的算子入口与量词及(4)的收费限制由本稿解析推导给出。

**预审停止点：** 路线准确且是充分控制原全尺度输入的全局几何命题；a大时甚至几乎等价原问题。尚未看到可保证根阶Q*、或完整统一收缩的新非局部收费机制。等待候选后仅审其是否跨过上述缺口，不以局部预算替换全局问题。

## 7. 新候选：全正对数正则化packing（独立审查通过）

本节仅依据父任务给定候选作独立核验，尚未借用作者R619新稿。固定任意有限supplied family的顺序，令v_j=|B_j\∪_(i<j)B_i|。删去v_j=0项后保留的receiver union与原U a.e.相同；逐项归纳也知保留项的v_j不变，故V=Σv_j=|U|。仅零测面的遗漏不影响弱型Lebesgue receiver预算。

**须明确的删除量词：** 删除receiver冗余项不保证它的a-star source约束也冗余。以下m*必须指保留stars的source LP；不能无证明宣称与删除前的全约束最优值相同。原实际f仍满足所有保留约束，所以作为上界路线的放松合法，保留packing可给删除项λ=0而扩展到原全族。

归一化η=1，d_j=|A_j|，所有保留v_j>0，ε>0。考虑

max Fε(λ)=Σ_jd_jλ_j+εΣ_jv_j logλ_j，
λ_j>0，M^Tλ≤1。

每个star含正体积cell，故λ_j≤1。小的全正常数向量严格可行；任一λ_j→0时相应log项趋−∞。线性项有界，因而最优在全正域内达到。Hessian为−ε diag(v_j/λ_j²)，严格负定，所以λ唯一。Slater在这个有限、开log定义域上成立，KKT有非负cell乘子z_C；**λ唯一不意味着z或构造source唯一**。

Stationarity与互补松弛准确给

Σ_C M_jC z_C=d_j+εv_j/λ_j，
z_C>0 ⇒Σ_j M_jCλ_j=1。

在每个正体积cell C取密度z_C/|C|，得到真实非负L1 source μ。每个保留star严格bad，因为μ(A_j)>d_j。将stationarity乘λ_j再求和，得到

μtotal=Σ_Cz_C=Q+εV，Q=Σ_jd_jλ_j，
λ_j[μ(A_j)−d_j]=εv_j，
Σ_jλ_j[μ(A_j)−d_j]=εV。                                (5)

Q是合法packing目标，μ是真实primal可行source，故

Q≤m*≤Q+εV。                                             (6)

这对任意有限n、a>1都成立，没有density cap或算法复杂度假设。任意η通过source乘η恢复。若V=0或空家族则receiver结论平凡，不需log程序；保留零v却仍宣称全正/严格凹/每star严格bad是不合法的。

**ε极限。** 固定有限几何时，Qε→m*，误差≤εV。λ在紧polytope中，任一积聚点是未正则化对偶最优。source质量z的总量≤m*+εV，亦有收敛子列到primal最优。strict bad可在每个ε>0成立，但极限不必严格；也不保证对偶极限各λ_j仍正。

尤其不能把δ_j=μ(A_j)−d_j=εv_j/λ_j误当逐项小量。λ_j可随ε趋零，δ_j不必趋零；当前得到的是**逐项加权**λ_jδ_j=εv_j及其总和。任何把误差改成Σδ_j、maxδ_j或引入1/λmin的收费，都需要额外控制，不能由正性免费推出。

新的真正全局耦合为ζ_Cj=z_Cλ_jM_jC：

Σ_jζ_Cj=z_C，Σ_Cζ_Cj=λ_jd_j+εv_j。                      (7)

每个必要receiver star现都有正的列预算，故确实修复未正则化λ_j=0时仍有receiver体积被遗漏的问题。但列预算仍可能只有O(εv_j)，(7)本身不保证用根阶成本覆盖v_j或所有receiver cut；它只是使后续Hall/运输命题的对象完整。

**准确吸收条件。** 若后续真能证明

V≤K_n Qε+L_F(ε) εV，                                   (8)

且对每个固定有限家族F有εL_F(ε)→0（例如L_F有限且独立ε），则可取ε→0得到V≤K_n m*，前提是K_n对所有family统一。这一纯存在性路线允许ε依赖有限family，不必额外强求L_F独立N/几何。若要预先固定ε(n,a)，才需要更强的uniform控制。特别，L若含1/λmin，则必须证明εL→0；不能因每个ε的λmin>0就完成吸收。

若有Lε≤ρ<1，则(8)直接给V≤K_n Qε/(1−ρ)，packing收费随即有效。当前尚未证明(8)或其Hall cut控制，亦未证明K_n为根阶。因此该候选严格改进了全对象的非退化性和误差账，但不是已经取得的receiver几何估计。

实际调用数学venv SymPy核验了有限形式矩阵的KKT mass/excess分解，残差0；没有新LP或采样。独立审查结论：候选在上述删减/ε/乘子条件下成立；全局非局部收费仍待候选证明。

## 8. 两来源cliques的Hall运输：一般结构通过

独立审查父任务给定机制后，再读最终 `/tmp/ccu_r619_main_sol.md`。λ必须是对**全部source空间**可行的clique packing，不能仅在当前正质量source cells检查。设两个正source cells的membership cliques为C,D，λ(C)=λ(D)=1；共享部分按同label对角质量λ_j匹配。独占E=C\D、F=D\C均有总权δ=1−λ(C∩D)。

在E,F间只连真正不交的stars。任意S⊂E，D\N(S)与S内部及交叉均pairwise相交；有限开cubes的Helly-2给共同正体积交。全空间packing因而给

λ(S)+1−λ(N(S))≤1。

故weighted Hall容量条件成立；存在只沿不交star边的运输，行/列边际分别为E/F的λ，质量恰δ。若δ=0，空运输即可。该存在性没有额外N或source-cell数的乘法费用；实现复杂度可以依赖有限对象规模，不构成维数成本证明。

每条不交边(j,l)至少有一坐标满足中心间距≥a(r_j+r_l)，小receiver在该坐标的间隙至少(a−1)(r_j+r_l)。不需要两项半径相等。可为每条边固定一个坐标；如果使用有序source对，概率为π_Cπ_D，无序对则需相应两倍权，不能混淆。

置π_C=z_C/M并独立抽两个source cells。完整Hall+shared diagonal coupling有各自conditional star marginal λ1_C、λ1_D，故全局star marginal

ρ_j=λ_j μ(A_j)/M=(λ_jd_j+εv_j)/M。

两个source cells独立，**star labels因coupling一般不独立**。裸不交坐标通量满足

ΣΦ_i=Eδ=1−Σ_jλ_j[μ(A_j)/M]^2≤1。

一次(C,D,J,K)两点联合确实可构造。所有pairwise couplings不自动给三点/多点共同selector；如后续用树、鞅或多点比较，须另证所需一致性。该结构本身尚未将分离边的质量转成receiver体积。

## 9. receiver曝光倾斜Ψ：归一与边际通过

以下ε>0且v_j>0。记p_j=μ(A_j)/M，

e_j=εv_j/[λ_jμ(A_j)]∈(0,1)，β=εV/M=Σ_jρ_je_j∈(0,1)。

对**完整**两点coupling以(e_J+e_K)/(2β)倾斜。未除β时的总加权期望是E[(e_J+e_K)/2]=β；除后全局总质量为1。每个给定source-cell pair的倾斜总质量不必是1。共享同label对角质量扣除后，得到不交边上的方向通量

Σ_iΨ_i
 =1−Σ_jλ_je_jp_j²/β
 =1−Σ_jv_jμ(A_j)/(VM)∈[0,1]。                           (9)

ΣΦ只是未加权δ的期望；Ψ不能简单写成δ/β，必须保留各exclusive端点的e_j。由于边权可分成两端点相加，式(9)不依赖具体Hall流如何在合法边间选择；各坐标Ψ_i仍依赖流及分离坐标选择。

普通倾斜后的J或K边际一般**不是**v_j/V。准确解释是另标记被exposure权选中的端点：左端标记权e_J/(2β)、右端e_K/(2β)。标记star的边际准确为ρ_je_j/β=v_j/V；再在真实I_j上均匀采样，得到receiver U的归一化Lebesgue边际。partner端点不自动有同一receiver边际，不能免费当作两个独立均匀receivers。

原先的source→star sampler也准确分解ρ=(1−β)(λ_jd_j/Q)_j+β(v_j/V)_j。receiver分支产生未归一密度ε1_U，其余分支在A_j均匀产生Σλ_j1_Aj；两者总质量Q+εV=M。这是从辅助source经同一star的传输，不是宣称原任意f已独立化。

逆λ虽保留在e_j中，但总倾斜质量由上述恒等式归一，无额外λmin或N因子。ε→0时不得先丢掉λ_j=O(ε)的rare labels，再除β；β→0本身更不控制β/ε=V/M。Ψ在ε=0的原定义无意义，须先保留ε>0并证明所需统一几何界。

作者明确未证明的候选(G)为β≤εP[1+C log^k(2+n)Σ√Ψ_i]。若它成立，ΣΨ≤1才可结合Cauchy–Schwarz与M=Q+εV吸收；仅归一ΣΨ≤1不能推出(G)。本文没有把这项缺失几何bridge作为错误归于作者，也没有将它算作已证结论。

数学venv的SymPy已实际验证曝光归一、shared-diagonal代数及marked receiver marginal，残差为0；没有LP或几何采样。

## 10. 最终main的高κ完整family收费与范围

令κ=1−ΣΨ_i=Σ_jv_jμ(A_j)/(VM)。对固定source点y，所有含y的stars共同相交；全部真实receiver increments互不交，因此

Σ_(j:y∈A_j)v_j≤|∪_(j:y∈A_j)B_j|
 ≤P max_(j:y∈A_j)d_j≤PM。

最后一步使用每个保留star的d_j≤μ(A_j)≤M；空集合按0。对**同一个**μ/M积分得到

κV≤PM。

没有逐clique各领一次M，没有重复source预算，也没有Ccov，因为V就是全supplied receiver union（删零行仅a.e.改变）。预先给θ>0并取ε=θ/(2P)，再构造barrier；若所得κ≥θ，则

(κ−Pε)V≤PQ，故V≤2PQ/θ。                                (10)

这是严格、可检验的完整family条件界。取a≥n等使P≤e，再取θ约[√n log^k(n+2)]^(−1)，该高κ分支得到条件性根阶packing。任意固定a仍只能保留P费用；不能把带指数P的版本直接称根阶。κ由唯一λ与μ(A_j)=d_j+εv_j/λ_j决定，不因KKT cell source乘子不唯一而任意改变。

低κ的receiver体积分位说明也正确：若κ<θ，则v_j/V权下p_j的平均<θ，故p_j>√θ的行只占小于√θ的receiver体积比例。这不是剩余receiver已获付款。

**允许全局可加分解。** star intersection graph不同连通分量之间的star unions互不交，receiver也不交；Q、V、M可按分量相加，barrier目标分解。准确有

κ_global=Σ_c V_c M_c κ_c/(V M)。

L个相同分离分量可将κ稀释为κ_c/L，即便各分量本身很容易。因此不能从global低κ推断每个component都是困难态；也不能给每个component同一个parent M。若分别用M_c、Q_c建立收费后相加，可无重复地组合；相互重叠source cliques则不能照搬该独立分解。本轮尚未解决connected低κ或更一般互相竞争cliques的全局预算。

## 11. 最终作者稿核验与小型表述补全

最终 `/tmp/ccu_r619_main_sol.md` 的KKT、Hall、Φ/Ψ恒等式、高κ收费及其停止范围与本审独立推导一致。需要明确的两处归一文字已通知root：

* 第2节m*应指**删去零receiver行后保留stars**的未正则化source LP；若“原”被理解为删前所有source约束，m*≤M不保成立。
* 第5节包括shared diagonal的未除β加权期望为β；归一倾斜后的总质量才是1。marked endpoint有receiver边际，普通倾斜标签边际一般没有该性质。

高κ分支称root须选择控制P的a(n)，作者第1节a=max(2,n²)例已可做到。其余一般目标仍是候选(G)或完整低κ非局部收费，不是已取得的普遍维数新界。完整supplied-family、有限cover规模随a变化、全L1输入与source固定积分等关键量词在上述条件下保留。

**当前最终通过范围：** 全正log-barrier及准确excess账；一般clique Hall不交运输；receiver曝光Ψ的无N/λmin归一；高共同来源比例完整family的条件性packing界。**未证范围：** 一般(G)、全局多点一致selector、低κ共同source竞争的root收费或完整统一收缩。未读/认证本轮数值实例、最终归档包或commit。审查完成，等待必要文字补全，不扩展扫描。


## 12. 最终整合报告核对与最终通过范围

已读 `/tmp/ccu_r619_final/REPORT.tex`，并核对作者最终main中相关修正。第11节提出的删后m*、global tilt总质量及marked endpoint三点均已落实；整合报告还明确a≥n以控制P，及分离components必须分别付M_c/Q_c后相加。未把全家族小κ直接当作每个component困难，也未把pairwise Hall升级成共同多点selector。

整合报告的独立全尺度入口、固定N/a量词、全正barrier、excess、Hall、Ψ和高κ条件family界均与本审已核推导一致。根阶仅用于预设ε后满足κ≥θ_n的完整family；一般低κ桥、统一receiver几何及最终算子目标仍明确未证。没有额外Ccov的理由是V本来就是全supplied union，并非少付selected cover费。

报告新增数值/精确实验只核其证据表述，不重审或重跑求解器：浮点残差不等于KKT；首例准确rational residual identity明确残差非0、primal/dual区间非最优证书；C4的符号及几何实例仅定位有限代数检查，不证明缺失一般bridge。这些证据边界正确。其具体数值端点、运行收据及新验证脚本由root另行核验，不归属本审独立复算。

一个不影响已证结果的文字建议已通知root：整合稿中“family-dependent error coefficients ... only if εL tends to zero”不是必要条件。准确充分吸收条件是每个family可选择ε使εL≤同一个ρ<1；εL→0是一种足够保证，εL恒1/2同样可吸收。应避免以“only if”排除后者。本轮高κ取ε=θ/(2P)恰直接给固定半量吸收，不依赖这句过强要求。

**最终已核：** R619准确全supplied/source量词；与真实弱型常数的P夹逼及a/N风险；全正barrier与严格加权excess；全clique Hall不交运输；无N/λmin总费的receiver曝光Ψ归一；高κ完整family的条件性根阶packing及正确source加法。**仍未证：** 一般(G)或替代低κ联合收费、根阶全家族界、多点一致selector与原算子最终目标。未认证最终归档包、commit或本轮求解器输出最优性。当前没有阻断已证明结论的数学错误。独立审计完成，停止，不扩展扫描。
