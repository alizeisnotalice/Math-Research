# R619 固定 source 数值证书

对所提供的 40 个二维 stars 与 727 个非负均匀矩形 source，精确有理核验了 packing、各 star 负载与残差恒等式。原 source 已满足所有 μ(S_j)≥d_j，因此不需增加质量。对未加障碍项的有限 source LP，所得严格原始–对偶区间约为 [1969.650262440343, 2174.450460270399]；准确分数及全部约束见 JSON。这个区间较宽，并不声称求出了 LP 最优值。

严格恒等式为

`μtotal − Q − εV = Σ_j λ_j e_j + Σ_c z_c (1−load_c)`,

其中 `Q=Σd_jλ_j`、`V=Σv_j`、`e_j=μ(S_j)−d_j−εv_j/λ_j`。对于给定的均匀 source 矩形，`load_c` 是该矩形上 packing 密度的准确面积平均，因而允许它与 star 边界部分相交。两边作为有理数完全相等；数值约为 0.000197830055521，右侧加权残差约 0.000180372700，加互补缺陷约 0.000017457356。各 e_j 的范围约为 [−0.12715, 0.26698]，故不能把此结果称为精确 KKT 或将残差忽略。

λ 的所有值严格为正，最小值约 0.0002873881094。逐个 star 端点形成的 72×55 正面积单元用整数差分精确验证总 λ 负载不超过 1；原 λ 的恢复后缩放系数为 1。所有 source 覆盖由有理交面积计算；准确验证各 μ(S_j)≥d_j。对一般近似数据，如果某约束不足，程序在该 star 内加入总质量 `max(0,d_j−μ(S_j))` 的均匀 source，其总修复质量之和提供严格可行的上界；本例该和恰为 0。对偶可行性给下界 Q，故无需以求解器最优状态作证。

几何数据按 SHA-256 与输入绑定，并以 seed=61901 选取唯一记录；直接由每条整数坐标记录和 a=8 重建 stars，逐序重算四分之一网格的新覆盖格数，核验每项 v=count/16>0、d=star 面积及 V=3375/16。故此处权重对应所给实际 increments。

原输入 SHA-256 `5087310c2db92a8d87af7f25e37716785290bff7e766cd499947bbf674f45124`；脚本 SHA-256 `711f0b1d10c3947dab766254f753fb6057281c9fe458717d226049930376233d`。实际运行：

`OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 /Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/ccu_r619_certificate.py --input /tmp/ccu_r619_barrier_case0_certificate.json --geometry-data /tmp/ccu_r619_barrier.json --output /tmp/ccu_r619_certificate.json`

Python 3.12.14、Fraction 有理运算；墙钟 0.20467 秒、CPU 0.200359 秒、峰值 RSS 28,000,256 字节。证书仅适用于该有限实例、给定正面积 source 矩形及其均匀密度，不证明障碍优化器的全局最优性或一般维数界。

几何输入 SHA-256 `82444d7ad5d4f9125ee84c422279dd502695f19a193376b24cf12bb83c3b77b8`。加强验证前的实际运行记录保留为 `/tmp/ccu_r619_certificate.legacy.json`；新旧全部共同数学字段完全一致。
