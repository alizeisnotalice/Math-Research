# R619 有界资源与证据账目

- **Barrier 阶段：** 索引记录 12/12 个 remaining tasks 完成，8 workers，合并墙钟 0.622294 秒，worker CPU 合计 0.183906 秒。每任务含 40 个二维 cubes；3 个 geometry seeds × 4 个 ε/α 设置。全部 Clarabel 状态显示 optimal。Python 3.12.14、NumPy 2.5.4、SciPy/CVXPY/Clarabel 版本见 `barrier.json`；Clarabel 0.11.1。最大单 worker 峰值 RSS 为 118,210,560 bytes（约112.7 MiB）。`conservative_8_worker_peak_sum_bytes=945,684,480` 是八倍单 worker 峰值的保守聚合估算，不是同时 RSS 测量。
- Barrier 的数值是浮点对数障碍/Clarabel诊断。Markdown 明确写明非严格 KKT 证书。结果用来观察有限二维样例的 barrier 正性、残差与逆 λ（最小 λ很小、最大 1/λ 可达百万量级）；不能把 `optimal` 状态或近似残差当成精确最优性证明。
- **有理 certificate：** 单一 seed=61901 的有限几何，40 stars、727 source rectangles，72×55 网格、3,375 个 union grid cells。记录 Python 3.12.14；Fraction exact arithmetic。墙钟 0.204674 秒，CPU 0.200359 秒，峰值 RSS 28,000,256 bytes。Markdown 声称对该输入逐项有理核验 packing、star load、残差恒等式、source coverage；修复总质量为0。
- 证书给未加障碍项有限 source LP 的有理 primal/dual 界，报告近似为 `[1969.650262440343, 2174.450460270399]`，区间较宽；它**没有**证明 LP 最优值相等，也不是 barrier 全局最优性的证书。精确核验对象限于这一个输入的恒等式、可行性和几何绑定。
- **Root certificate replay：** 同一输入 SHA、几何 SHA、证书脚本 SHA 与原 certificate 相同；数学字段逐项一致，只有 runtime（输出路径、墙钟/CPU/RSS）有差别。重放实测墙钟 0.204230 秒，CPU 0.200450 秒，峰值 RSS 27,983,872 bytes。此为同脚本同输入的复跑，不是独立算法或独立数学证明。
- **适用范围限制：** 这些是二维、每族固定 40 cubes、固定 a=8 的有限案例。此处 `N/a^2=40/64=0.625`，所以既不核验 n 阶 receiver/cube 几何桥接，也不排除固定规模下的 a 依赖。用途限于指定案例的 barrier 正性/残差/逆 λ 诊断，以及单个有限实例有理可行性/恒等式重放；一般维数 proof 由 Sol 审核。
- 8 workers 在约0.62秒完成，是短批次，不代表持续满载。CPU 合计明显少于总墙钟时间所暗示的持续多核利用；不能写成持续满CPU。worker 峰值 RSS 求和也不能冒充同步采样的批次总 RAM。
