import argparse,json,sys,time,hashlib,platform,resource,math
from pathlib import Path
from fractions import Fraction as Q
from bisect import bisect_left
start=time.perf_counter();cpu=time.process_time();parser=argparse.ArgumentParser();parser.add_argument('--input',type=Path,required=True);parser.add_argument('--geometry-data',type=Path,required=True);parser.add_argument('--output',type=Path,default=Path(__file__).with_suffix('.json'));a=parser.parse_args(); data=json.loads(a.input.read_text())
def rect(x):
 r=tuple(map(Q,x));assert len(r)==4 and r[0]<r[1] and r[2]<r[3];return r
def area(r):return (r[1]-r[0])*(r[3]-r[2])
def intersection(r,s):return max(Q(),min(r[1],s[1])-max(r[0],s[0]))*max(Q(),min(r[3],s[3])-max(r[2],s[2]))
stars=[rect(x) for x in data['stars']];n=len(stars); ds=list(map(Q,data['d']));vs=list(map(Q,data['v']));lam=list(map(Q,data['lambda']));eps=Q(data['epsilon']); source=[(*rect(x[:4]),Q(x[4])) for x in (data['source_cells'] if 'source_cells' in data else data['cells'])]
assert n>0 and len(ds)==len(vs)==len(lam)==n and eps>0 and all(x>0 for x in lam) and all(x>=0 for x in ds) and all(x>0 for x in vs) and source and all(x[4]>=0 for x in source)
assert all(d==area(r) for d,r in zip(ds,stars))
geo_bytes=a.geometry_data.read_bytes(); geo_hash=hashlib.sha256(geo_bytes).hexdigest();assert geo_hash==data['source_input_sha256'];geo=json.loads(geo_bytes);geos=[g for g in geo['geometries'] if g['seed']==data['seed']];assert len(geos)==1;g=geos[0];records=g['records'];assert len(records)==n==g['N']
occupied=set(); rebuilt=[]; rebuiltv=[]
for r,x,y,count in records:
 assert all(isinstance(z,int) for z in (r,x,y,count)) and r>0
 new={(i,j) for i in range(x-r,x+r) for j in range(y-r,y+r)}-occupied
 assert len(new)==count and count>0
 occupied.update(new);rebuiltv.append(Q(count,16))
 rebuilt.append((Q(x-8*r,4),Q(x+8*r,4),Q(y-8*r,4),Q(y+8*r,4)))
assert rebuilt==stars and rebuiltv==vs and sum(vs,Q())==Q(len(occupied),16)==Q(g['V'])
assert [Q(z) for z in g['v']]==vs and [Q(z) for z in g['d']]==ds and [rect(z) for z in g['stars']]==stars

# Exact common-denominator difference grid; packing is normalized down only as necessary.
D=math.lcm(*(q.denominator for q in lam)); ns=[q.numerator*(D//q.denominator) for q in lam];xs=sorted({v for r in stars for v in r[:2]});ys=sorted({v for r in stars for v in r[2:]});nx=len(xs);ny=len(ys);assert nx*ny<=350000
grid=[[0]*ny for _ in range(nx)]
for (x0,x1,y0,y1),num in zip(stars,ns):
 i=bisect_left(xs,x0);j=bisect_left(xs,x1);k=bisect_left(ys,y0);l=bisect_left(ys,y1);grid[i][k]+=num;grid[j][k]-=num;grid[i][l]-=num;grid[j][l]+=num
maxload=0
for i in range(nx):
 for j in range(ny):
  grid[i][j]+=(grid[i-1][j] if i else 0)+(grid[i][j-1] if j else 0)-(grid[i-1][j-1] if i and j else 0)
  if i<nx-1 and j<ny-1:maxload=max(maxload,grid[i][j])
scale=max(Q(1),Q(maxload,D));lam=[x/scale for x in lam];assert min(lam)>0
mu=[sum((c[4]*intersection(r,c)/area(c) for c in source),Q()) for r in stars]
total=sum((c[4] for c in source),Q());Qobj=sum((x*y for x,y in zip(ds,lam)),Q()); V=sum(vs,Q()); residual=[m-d-eps*v/l for m,d,v,l in zip(mu,ds,vs,lam)]
# averaged loads for each uniform rectangle; overlap interpretation handles partial overlaps exactly.
loads=[sum((l*intersection(r,c)/area(c) for r,l in zip(stars,lam)),Q()) for c in source];assert all(Q()<=x<=1 for x in loads)
defect=sum((c[4]*(1-load) for c,load in zip(source,loads)),Q()); correction=sum((l*e for l,e in zip(lam,residual)),Q()); lhs=total-Qobj-eps*V;assert lhs==correction+defect and defect>=0
repairs=[max(Q(),d-m) for d,m in zip(ds,mu)]; repaired_total=total+sum(repairs,Q());assert Qobj<=repaired_total
f=lambda x:[str(x.numerator),str(x.denominator)]
out={'stars':n,'source_cells':len(source),'grid_shape':[nx-1,ny-1],'packing_scale':f(scale),'min_lambda':f(min(lam)),'lambda':list(map(f,lam)),'epsilon':f(eps),'d':list(map(f,ds)),'v':list(map(f,vs))}

out.update({'source_coverage':list(map(f,mu)),'stationarity_residual':list(map(f,residual)),'source_average_load':list(map(f,loads)),'complementarity_defect':f(defect),'weighted_residual':f(correction),'identity_left':f(lhs),'identity_right':f(correction+defect),'source_total':f(total),'Q':f(Qobj),'V':f(V),'repairs':list(map(f,repairs)),'repair_total':f(sum(repairs,Q())),'repaired_source_total':f(repaired_total),'primal_dual_gap':f(repaired_total-Qobj),'input_sha256':hashlib.sha256(a.input.read_bytes()).hexdigest(),'geometry_sha256':geo_hash,'geometry_seed':data['seed'],'union_grid_cells':len(occupied),'geometry_binding':'records, stars, positive ordered increments, d, v and union verified','script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'runtime':{'sys_executable':sys.executable,'python':sys.version,'platform':platform.platform(),'argv':[sys.executable]+sys.argv,'wall_seconds':time.perf_counter()-start,'cpu_seconds':time.process_time()-cpu,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss},'scope':'finite planar stars and uniform source rectangles; exact residual identity does not imply exact KKT'})
a.output.write_text(json.dumps(out,indent=2)+'\n');print('stars',n,'minlambda',float(min(lam)),'Q',float(Qobj),'source',float(total),'correction',float(correction),'defect',float(defect),'repair',float(sum(repairs,Q())),'gap',float(repaired_total-Qobj))
