# R619：全 receiver 曝光、Helly 加权 Hall 匹配与尚缺的全局几何桥

本稿只研究全供给 stars 的同一次来源 packing，不把各 common clique 分开付来源预算。新证明是：正来源 cliques 之间的全部独占 packing 权重，可沿真实不交 stars 作加权完美匹配；配合 root 提出的 receiver-volume log barrier，可把此结构覆盖到每个实际新增 receiver，而非仅原 LP 的正 dual 行。给出一个可检验的方向通量候选引理与完整吸收费用，但该几何引理尚未证明，故没有一般根阶新界。未读本轮数值候选，未改其他文件、未执行 Git、未另派 agent。

## 1. 精确要证明的新全局引理

本稿的 receiver 是全部 supplied 小立方体的 U=∪_jB_j，不是只选中子族。按一个固定顺序取实际 I_j=B_j\∪_{i<j}B_i，v_j=|I_j|，V=Σv_j=|U|。删去 v_j=0 的行，U仅改零测集；这些行的 packing 权最后扩为0，所以未借此放宽最终全族 packing 可行性。若改用 R617 selected-only increments，则下文 V仅为 selected union，仍需另付 Ceff；两者不得混同。

记 A_j=aB_j、d_j=|A_j|，来源阈值归一为1。root 提出的全曝光构造在第2节核验；它给出 λ_j>0、来源 μ及总量

  Q=Σ_jλ_jd_j， M=μ(R^n)=Q+εV，
  Σ_jλ_j1_{A_j}≤1， μ(A_j)=d_j+εv_j/λ_j。          (A)

每个正 μ-cell的 stars 是 λ总权1的真实 common clique。第3节对每对正 μ-cells构造匹配；第5节再按真实receiver曝光权重和分离坐标分配通量 Ψ_1,…,Ψ_n，满足 ΣΨ_i≤1。原先仅按λ加权的Φ不足以保留rare-label的receiver费用。

一个准确可测、尚未证明的全局 receiver 曝光引理是：存在维数无关 C,k≥0，对(A)产生的全几何数据，存在一组满足第3节的pairwise couplings和真实分离坐标（整族固定），使

  β:=εV/M
   ≤ εP[1+C log^k(2+n) Σ_{i=1}^n sqrt(Ψ_i)]，
  P=((a+1)/a)^n。                                  (G)

这里 β 是同一个 source-star sampler 中真实 receiver-increment 部分的概率，不是任意独立坏部；Ψ使用真实共交 cliques、真实不交 stars、全部来源质量及逐项receiver曝光权。引理需要实际 cube 位置与半径，不能只对抽象 cell incidence 宣称成立。

(G)若成立，则 Cauchy–Schwarz给

  V≤L_nM， L_n=P[1+C sqrt(n)log^k(2+n)]。

取 ε=1/(2L_n)，由 M=Q+εV准确吸收得到

  V≤2L_nQ， 即同一可行 λ 给 Q≥|U|/(2L_n)。         (B)

例如 a=max(2,n²)，n≥2时P≤exp(1/n)，没有 family数量、cell数量、最小半径、λ_min费用。对一般 L¹ 的原有限覆盖入口，所有保留 stars 均为原来源的真实 bad-stars，故 ηQ≤||f||₁；原紧集K⊂U。因此(B)若证即给 C_n≤2L_n，不再额外乘Ceff。此处P已包含在L_n；不能再把有限 receiver 实验比值直接当成同水平 weak 下界。

(G)是一个明确较强的候选全局引理，不是本稿已获结论，也不声称它是根阶证明唯一必需形式。接下来的严格推导只证明它所用结构与预算全部真实存在。

## 2. receiver-volume log barrier：准确 KKT 与曝光费用

有限 packing polytope沿 R618 的正体积 cells定义，令 N为保留行数。对 ε>0最大化

  F_ε(λ)=Σ_jd_jλ_j+εΣ_jv_j log λ_j

并要求λ≥0、所有 cell load≤1。λ_j=1/(2N)严格可行；各λ_j≤1；任何正 v_j 的λ_j趋0使目标趋负无穷。因此最优存在且全部λ_j>0。有限 cell KKT 给 z_C≥0，使

  Σ_C M_jC z_C=d_j+εv_j/λ_j，
  z_C>0 ⇒ Σ_jM_jCλ_j=1。                          (2.1)

将 z_C摊到相应正体积 cell 得到一个真实 L¹ 来源μ，不是无条件给任意来源密度帽。乘λ求和并用正 z-cell饱和，得

  M=Σ_Cz_C=Σ_jλ_jd_j+εΣ_jv_j=Q+εV。               (2.2)

令m*为删除零receiver增量行后、该保留有限家族的最小来源质量；不声称它与删前全部约束的sourceLP同值。则Q≤m*≤M，故0≤m*−Q≤εV。各star的真实松弛

  δ_j=μ(A_j)−d_j=εv_j/λ_j

必须逐项保留；它没有免费点态帽。仅有准确加权预算 Σλ_jδ_j=εV。另一方面 μ(A_j)≤M给出合法曝光下界

  λ_j≥εv_j/M。                                    (2.3)

不能把(2.3)改成与v_j无关的λ_min下界。

## 3. 新的严格结构：两来源 cliques 的独占权重沿不交 stars 全量匹配

令C,D为正 z-cells，

  K_C={j:C⊂A_j}， K_D={j:D⊂A_j}。

两者都是真实 common cliques，且λ(K_C)=λ(K_D)=1。设共享权 q_CD=λ(K_C∩K_D)，独占集合 E=K_C\K_D、F=K_D\K_C，故λ(E)=λ(F)=δ_CD=1−q_CD。

在E,F之间连边，当且仅当两 stars真正不交。对任何H⊂E，令N(H)⊂F为与H中至少一star不交的邻集。则

  λ(N(H))≥λ(H)。                                  (3.1)

证明：K_D\N(H)中的每个star与H中每个star相交；两侧内部本来也是cliques。开轴平行方体的Helly数为2：各坐标有限开区间两两相交即有共同交。因此H∪(K_D\N(H))有真实共同交，packing可行性给

  λ(H)+1−λ(N(H))≤1，

即(3.1)。共享stars不可能属于N(H)，因为它们与整个K_C共交。

由有限加权Hall/最大流，有非负 ξ_CD(j,l)，只沿 A_j∩A_l=∅ 的边，满足

  Σ_l ξ_CD(j,l)=λ_j (j∈E)，
  Σ_j ξ_CD(j,l)=λ_l (l∈F)。                        (3.2)

其总质量为δ_CD。再将共享每行j按质量λ_j匹配给同一个j，得到K_C与K_D两套完整λ分布的coupling：所有匹配对不是同一star，就是真正不交stars。

这比“两个cliques有一对不交stars”强：独占权重没有丢失，没有每clique另付一份来源费，也没有最小λ的损失。反过来，若两cliques并集仍是clique，则δ_CD=0；因此不同正权 incidence型不能免费合并。共享stars原有的tight来源需求不能因合并而漏付。

## 4. 全来源配对与坐标通量：总费用不超过1

置π_C=z_C/M。对每个不交匹配对(j,l)，指定一个真实分离坐标κ(j,l)，满足

  |(y_j)_κ−(y_l)_κ|≥a(r_j+r_l)。

此坐标必存在。小 receivers B_j、B_l在该坐标的间隙至少(a−1)(r_j+r_l)，所以这不是抽象图着色，而是真实 receiver分离。

定义

  Φ_i=Σ_{C,D}π_Cπ_D
       Σ_{j,l}ξ_CD(j,l)1_{κ(j,l)=i}。

于是准确有

  Σ_iΦ_i=E_{C,D}δ_CD
   =1−Σ_jλ_j[μ(A_j)/M]²≤1。                       (4.1)

最后等式用独立source cells与共享λ权求和；非负性也由δ≥0直接给出。这个归一不随source atoms数增长。若需要对称coupling，可平均ξ_CD与ξ_DC的转置，不改变费用。

在普通最优LP中，zero-dual但仍贡献receiver的stars不在此结构内；仅用positive-dual cliques会漏账。第2节的全曝光barrier恰修补此点：所有v_j>0行均λ_j>0，故(3)–(4)真正涵盖全部receiver行。但它尚没有把分离通量变成receiver体积上界。

## 5. receiver曝光加权通量：保留rare-label而不付λ_min

在source cell C以概率λ_j选择其包含的star j（cell load=1）。所得star边际为

  ρ_j=λ_jμ(A_j)/M=(λ_jd_j+εv_j)/M。

令p_j=λ_jd_j/Q、q_j=v_j/V，则

  ρ=(1−β)p+βq， β=εV/M。                          (5.1)

所以β准确是全source sampler中实际receiver新增体积所占部分；每个receiver标签获得εv_j/M的曝光质量。没有把星形来源独立化，也没有只统计witness数量。

更显式地，在选中j后，以概率εv_j/[λ_jμ(A_j)]将该次标记为receiver部分，随后在真实I_j上均匀采样。此概率≤1，由(A)保证。其receiver边际密度为ε1_U/M。其余部分可在A_j上均匀采样，边际密度为Σλ_j1_Aj/M≤1/M。这是同一来源经实际stars的共同传输，源总量和目标总量均为M。

必须修正一个量化问题：原zero-dual行在barrier中可只有λ_j=O(ε)，裸通量Φ便可随ε消失，而其receiver新增体积并不随ε消失。因此不能仅因全λ>0就把Φ当完整receiver势。

令 e_j=εv_j/[λ_jμ(A_j)]∈[0,1] 为上述真实标记概率。对第3节每对coupling的不交部分，改用receiver曝光权，定义

  Ψ_i=(1/(2β))Σ_{C,D}π_Cπ_D
       Σ_{j,l}ξ_CD(j,l)(e_j+e_l)1_{κ(j,l)=i}。

这里逆λ完整保留在e_j中。两侧star边际均为ρ，故包括共享对角的总加权质量准确为β；扣去共享同star对角，得到

  σ:=Σ_iΨ_i
    =1−[Σ_jλ_j e_j(μ(A_j)/M)²]/β
    =1−Σ_j v_j μ(A_j)/(VM)， 0≤σ≤1。              (5.2)

这个势不会把rare label洗掉：λ_j=O(ε)时e_j/β可补回receiver曝光权；没有另付λ_min或N。它也有直接几何解释：σ正是按实际receiver增量v_j抽star时，source落在该star之外的平均比例。

归一语义必须精确：对固定source pair(C,D)，按(e_j+e_l)/(2β)倾斜后的coupling总质量未必为1；只有再对全部π_Cπ_D平均，其包含共享对角在内的总质量才为1。将每个pair的权拆成两个带mark的项e_j/(2β)与e_l/(2β)，分别标记承担e权的端点；全source-pair平均后，这个marked-star边缘才准确为v_j/V。未标记的普通J边缘、另一partner边缘一般均不等于v_j/V，不能据此假设两端都是同一receiver分布。

每对Hall coupling只分别存在。本文没有构造、也没有默认存在对全部source cells同时一致的共同随机selector；(4.1)、(5.2)只需要pairwise couplings。后续若采用三点比较、树或鞅，必须另证多点一致性，不能从两点matching免费继承。

到这里概率身份只给β≤1。要获得(G)，仍必须证明cube几何将receiver曝光压到ε乘方向通量的根阶成本。不能仅凭ΣΨ≤1宣称这个receiver-to-flux不等式。

加权excess εV在代数上足够吸收，准确条件是所证receiver inequality对M统一，系数无额外λ_min、source-cell数量或逐starδ_j帽。若新证明出现Σδ_j、max δ_j/λ_j或每clique各付M，则现有加权预算不够，必须重新付费。(G)尚未证明，因此不能把“weighted excess可吸收”说成已得根阶。

一个无条件但粗的checkpoint是R618的disjoint代表star分组：它确实给V≤(2+1/a)^nM，即β≤ε(2+1/a)^n。该全来源曝光界能按同样方式吸收，但仍指数阶；本轮未把它改善为(G)。新的困难已精确集中到共同source配对所对应的receiver几何通量，而不是LP等价或局部cap常数。

## 6. 一项本轮真正完成的定量全局合并：共同来源比例足够时已可付款

令 κ=1−σ=Σ_jv_jμ(A_j)/(VM)。对任意source点 x，将所有满足 x∈A_j 的行共同合并。这些stars是真实common clique，不能逐行各付M。其真实increments不交，R618共同交体积引理给

  Σ_{j:x∈A_j}v_j≤P max_{j:x∈A_j}d_j≤PM，

因为每个d_j≤μ(A_j)≤M。对同一个μ/M积分，准确得到

  κV=Σ_jv_jμ(A_j)/M≤PM，
  即 V≤PM/κ（κ>0）。                              (6.1)

这是一个量化的全局共同来源合并界，没有每clique独立领M，也没有点态W假设。特别是σ=0时全部receiver stars含同一个正质量来源交集，回到已付的共同交极限V≤PM。

为避免ε与事后κ互相选择，预先固定阈值θ_n>0，取ε=θ_n/(2P)，再构造barrier。若所得κ≥θ_n，则由(6.1)、M=Q+εV立即吸收得

  V≤(2P/θ_n)Q。                                   (6.2)

取θ_n=1/[sqrt(n)log^k(2+n)]，这一真实定量机制已在“共同来源比例至少θ_n”的完整family上给目标packing证书。它不是一般根阶结论；剩余κ<θ_n还需先排除下面可直接逐组件付款的质量稀释，不能一概视为困难。

该剩余情形也被精确定量：按v_j/V抽行，μ(A_j)/M的均值<θ_n，所以除至多sqrt(θ_n)的receiver增量外，其余stars每个捕获的source比例≤sqrt(θ_n)。但小κ可以仅由许多互不相交star-graph组件的来源质量稀释造成。对star交图的不同连通组件，stars并集互不相交，且a>1使对应小receivers也不交；packing polytope、log-barrier目标与来源KKT均按组件分解。应在各组件内分别计算M_c,Q_c,V_c及κ_c，再将已得V_c≤K_nQ_c求和；全局κ小不妨碍这种付款。分离共同交簇正是可解特例，不能包装成复杂全局困难。真正未解决的是组件内部多个交叠cliques交织且κ_c仍低的情形，需要Hall真实分离通量或其他全局重分配，而不是对彼此交织的每个clique独立领预算。

这给下一决策一个严格分界：κ≥θ_n不用再优化，已由(6.2)付款；先按互不相交star组件拆分，仅在组件内部κ_c<θ_n且source cliques互相交叠的情形研究(G)或替代可求和递推。本轮没有证明该剩余情形的root预算。

## 7. 下一决策与证据边界

本轮已取得严格的加权Hall匹配、无family数量损失且保留rare-label的receiver曝光通量、共同来源比例充分情形的真实packing界(6.2)，以及完整吸收费用。尚未取得(G)或其他严格可求和根阶递推。下一步有内容的证明应直接攻source-pair分离如何控制receiver新增体积，且保留共享clique约束；如果该桥不成立，需要找替代全局势，不能再次冻结weights或把各clique独立收一份来源预算。

本机研究venv的SymPy实际检查了两个source cliques K_C={1,2}、K_D={2,3}，λ_1=λ_3=t、λ_2=1−t、source概率p和1−p时，(4.1)右侧准确等于2p(1−p)t，符号残差为0。未运行几何数值候选或反例扫描。所有一般结论由本文有限KKT、Helly、加权Hall和显示的恒等式证明；(G)明确排除于已证结果。
