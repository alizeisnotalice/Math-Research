from fractions import Fraction as F
from pathlib import Path
import json,hashlib,sys,time,sympy as s
start=time.monotonic();eps=s.symbols('epsilon',positive=True)
centers=[(0,0),(1,1),(2,0),(1,-1)];r=F(3,4);a=F(4);small=r/a;d=(2*r)**2;v=(2*small)**2
adj={(i,j) for i in range(4) for j in range(i+1,4) if all(abs(centers[i][k]-centers[j][k])<2*r for k in range(2))};assert adj=={(0,1),(0,3),(1,2),(2,3)}
assert all(any(abs(centers[i][k]-centers[j][k])>=2*small for k in range(2)) for i in range(4) for j in range(i+1,4))
cliques=[{0,1},{1,2},{2,3},{3,0}];lam=[F(1,2)]*4
for mask in range(1,16):
 J=[j for j in range(4) if mask>>j&1]
 if all((min(i,j),max(i,j)) in adj for i in J for j in J if i<j):assert sum(lam[j] for j in J)<=1
D=s.Rational(d.numerator,d.denominator);W=s.Rational(v.numerator,v.denominator);z=D/2+eps*W;M=4*z;Qobj=2*D;V=4*W
assert s.simplify(M-Qobj-eps*V)==0
assert s.simplify(2*z-D-2*eps*W)==0
# Equal source-clique probabilities 1/4, full pairwise couplings (diagonal + nonedge).
flux=[F(),F()]
for C in cliques:
 for E in cliques:
  shared=C&E;left=C-E;right=E-C
  assert sum(lam[j] for j in shared)+sum(lam[j] for j in left)==1
  matched=set()
  for i in sorted(left):
   j=next(j for j in sorted(right) if j not in matched and (min(i,j),max(i,j)) not in adj)
   matched.add(j);k=next(k for k in range(2) if abs(centers[i][k]-centers[j][k])>=2*r)
   flux[k]+=F(1,16)*F(1,2)
  assert matched==right
assert flux==[F(1,4),F(1,4)]
beta=eps*V/M;e=eps*W/((D+2*eps*W)/2)
assert s.simplify(e-beta)==0 # all receiver exposure factors coincide here; Psi=Phi
p=s.Rational(1,2)
assert s.simplify(1-sum(lam)*p*p-s.Rational(1,2))==0
out={'scope':'exact finite C4 packing/KKT/pairwise Hall algebra, not a general receiver estimate','a':str(a),'star_radius':str(r),'small_radius':str(small),'d':str(d),'v':str(v),'edges':sorted(adj),'lambda':list(map(str,lam)),'source_mass_per_edge':str(z),'M':str(M),'Q':str(Qobj),'V':str(V),'Phi':list(map(str,flux)),'Psi':list(map(str,flux)),'beta':str(beta),'identities':'all zero symbolically, all finite graph and geometry tests exact','python':sys.version,'executable':sys.executable,'sympy':s.__version__,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'wall_seconds':time.monotonic()-start}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
