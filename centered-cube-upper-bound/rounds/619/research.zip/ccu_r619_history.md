# R619 有界历史去重：有限原子超水平的 subset-receiver 表示

## 本次范围与结论

仅查了 `cube-r040-cover-selector/cube-dim-7-bounds` 的 `STATE.md`、`README.md`、R031–R036 报告/计划、R032 general-cover 审计摘要，以及 R032/R035 的有限几何证明和对应少量审计命中。未通读长轮次档案。

在上述已查来源中，**未找到**你写出的原子测度超水平集合等于有限个 subset receiver boxes 并集的同一表示；也未找到针对该完整 union 体积的旧计算。这个“未找到”只对本次有界检索范围成立，不是整个资料库/600轮全史的否定性结论。候选表示本身可能只是有限原子下的直接精确恒等式；本报告不独立认证模型证明，边界证明交由 Sol/root。

## 最接近的既有结果

1. **R032 joint-cover theory：任意有限真实见证盒族的 incidence-cell LP 与 joint flow。**
   - 位置：`cube-dim-7-bounds/upper/round032/joint_cover_theory/proof.md`，特别是 §2（有限 incidence cells/LP）、§4–5（选择及覆盖 flow）；接受审计摘要：`audit/round032/general_cover/README.md`、`audit/round032/general_cover/joint_cover_review.md`。
   - 精确对象是有限盒族 (V_i=aQ_i) 的覆盖/质量 LP。以每个非空 incidence subset σ 对应的正体积 cell (E_σ={x:{i:x\in V_i}=σ}) 作变量；proof 明确称 cell 可由坐标端点有限求得，LP 使用完整 incidence 集合而非抽样列。报告还给出 finite-family (K_{n,a}) 与 (C_n) 的等价接口及一组共同支付 flow。
   - **差别：** 这是对既有 witness boxes 的交叠 arrangement/LP，不是从原子 μ 的全部子集 (S) 构造 receiver boxes，也未将 ({Mμ>η}) 直接写成那些盒的 union 后估其完整并集体积。审计明确限制：margin alone 无统一正间隙；需对每个有限几何有统一证书才能变成改进 (C_n) 的结论。R032 本身没有新统一数值界。

2. **R035 joint-cover：已识别并处理 (N/a^n) 是 own-witness 支付的局部方案障碍。**
   - 位置：`cube-dim-7-bounds/upper/round035/joint_cover/proof.md`，§2–5，特别是 §5 nested-cube example；摘要在 `upper/round035/REPORT.md`。该轮几何/理论审核：`audit/round035/joint_cover/`。
   - 精确结论：嵌套 inflated witnesses 有 common positive-volume intersection；local own-witness flow 的 load 是 (N/a^n)，但 clique-module compression 可把支付移至 anchor，得到与 (N) 无关的界。它说明 (N/a^n) 的增长是该局部支付方案的缺陷，不是算子下界。另有任意 clique 的 boundary penalty Δ；忽略它会使负载反增，有限例达到等号。
   - **未完成处：** 报告明说仍缺对一般几何中 compressible cliques 的强迫存在性、aggregate Δ 账单控制，以及统一全维度 savings；该模块没有单独给新 (C_n) 常数。它不是你提出的完整 μ 超水平并集体积法。

3. **项目当前索引状态：** `STATE.md` 说 R037 继续处理真实选择历史的 pointwise envelope 障碍与 joint-payment compression 的有限批次；R032 审计摘要也把逐点包络/有限 flow 的适用障碍写清。这个状态与“仍在处理一般选择历史”，不等于已有 subset-receiver exact-union 结果。

## 本次检索没有覆盖的内容

没有扫描所有历史轮次、所有 sibling clones、归档资料或其它维数项目；没有尝试实现 subset union-volume 算法、跑数值实验或审计关键引理。因此无法据此声称整个工作区没有同类旧恒等式。就本次选中的项目来源而言，可用于去重的最近前序是 **R032 finite incidence/flow LP** 与 **R035 clique-compression / (N/a^n) obstruction**，但应把 proposed receiver-box union 精确身份与“完整 union 体积可直接获得好界”视为两个不同主张：前者或为直接恒等式，后者在所查材料里未见已完成。
