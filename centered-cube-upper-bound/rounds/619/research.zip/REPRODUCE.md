# Round 619 reproduction

Use the recorded independent math-research Python interpreter. No PDF compilation.

Strict stored-data replay (no solver):

```
python ccu_r619_certificate.py --input ccu_r619_barrier_case0_certificate.json --geometry-data ccu_r619_barrier.json --output certificate_replay.json
python ccu_r619_exact_cycle.py
```

The main agent actually ran both. The first verifies source and packing feasibility, actual receiver geometry, and a rational residual identity; its nonzero residual is NOT a KKT optimum certificate. The second is an exact finite four-cycle algebra and geometry check, not a general receiver bound. For the strengthened certificate, d equals star area, every v is positive and actual, the stored geometry bytes are hash-bound, and quarter-grid increments are reconstructed in the original order.

Floating exploration was run using CVXPY/Clarabel and SciPy/HiGHS. Its phases were prepare, preflight, remaining; three ordinary LPs were reused across twelve log-regularized problems. To rerun optionally use ccu_r619_barrier.py --phase prepare/preflight/remaining --output-dir NEW_DIRECTORY, adding --workers 8 only for the remaining phase within the memory budget. Use a fresh directory so saved evidence is not overwritten. Exact stored geometry is authoritative; regenerating randomized input is unnecessary for verification. All positive-volume source cells are included through their incidence patterns, not sampled.

MANIFEST.json binds all archived members. REPORT.tex contains the integrated mathematical result; author and independent audit files retain detailed arguments and scope. General weak type remains unproved: the low-common-source fraction inside interacting components is still unpaid. Source matching, sum of directional costs <=1, finite floating optimal labels and a conditional high-common-source estimate do not prove the missing general bridge.

No new external paper theorem is claimed from a skills bibliography. B04 was consulted for qualification and finite/infinite-dimensional boundaries; logarithmic KKT was checked directly. All sources in the analytic construction are genuine finite-cell L1 densities, not bounds on arbitrary original source density.
