import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[k]='1'
import argparse,concurrent.futures,hashlib,json,math,platform,resource,shlex,sys,time,random
from fractions import Fraction as F
from pathlib import Path
import numpy as np,scipy,cvxpy as cp,clarabel
from scipy.optimize import linprog
SPECS=[{'seed':61901,'anchors':[[-90,0],[-45,6],[0,0],[45,-6],[90,0]],'spread':10,'rw':[1,1,1]},{'seed':61902,'anchors':[[-100,-12],[-50,12],[0,-10],[50,10],[100,-12]],'spread':12,'rw':[1,2,2]},{'seed':61903,'anchors':[[-100,0],[-50,15],[0,-15],[50,15],[100,0]],'spread':14,'rw':[2,1,2]}]
ALPHA=(.1,.01,.001,.0001)
def generate(spec):
 rng=random.Random(spec['seed']);raw=set()
 while len(raw)<100:
  R=rng.choices((8,6,4),weights=spec['rw'])[0];c=rng.choice(spec['anchors']);raw.add((R,c[0]+rng.randint(-spec['spread'],spec['spread']),c[1]+rng.randint(-spec['spread'],spec['spread'])))
 raw=sorted(raw,key=lambda x:-x[0]); lo=np.min(np.array([z[1:] for z in raw]),axis=0)-8; hi=np.max(np.array([z[1:] for z in raw]),axis=0)+8;cover=np.zeros(tuple(hi-lo),bool);selected=[]
 # Interleave radii after sampling so genuinely multiple scales survive 40 positive increments.
 by={R:[z for z in raw if z[0]==R] for R in (8,6,4)};raw=[]
 while any(by.values()):
  for R in (8,6,4):
   if by[R]:raw.append(by[R].pop())
 for R,x,y in raw:
  block=cover[x-R-lo[0]:x+R-lo[0],y-R-lo[1]:y+R-lo[1]];cnt=block.size-int(block.sum())
  if cnt: selected.append([R,x,y,cnt]);block[:]=True
  if len(selected)==40:break
 assert len(selected)==40
 R=np.array([z[0] for z in selected]);xy=np.array([z[1:3] for z in selected]);lower=xy-8*R[:,None];upper=xy+8*R[:,None]
 common_empty=bool(np.any(lower.max(axis=0)>=upper.min(axis=0)));adj=np.all((lower[:,None,:]<upper[None,:,:])&(lower[None,:,:]<upper[:,None,:]),axis=2);np.fill_diagonal(adj,False)
 visited={0};stack=[0]
 while stack:
  i=stack.pop()
  for j in np.flatnonzero(adj[i]):
   j=int(j)
   if j not in visited:visited.add(j);stack.append(j)
 tri=next(([i,j,k] for i in range(40) for j in range(i+1,40) if adj[i,j] for k in range(j+1,40) if adj[i,k] and adj[j,k]),None)
 assert common_empty and len(visited)==40 and tri
 edges=[np.unique(np.r_[lower[:,k],upper[:,k]]) for k in range(2)]; nx=len(edges[0])-1;ny=len(edges[1])-1
 # A cell's positive-area incidence mask is computed for every endpoint cell; no quadrature.
 masks=np.zeros((nx,ny),np.uint64)
 for j in range(40):
  x0=np.searchsorted(edges[0],lower[j,0]);x1=np.searchsorted(edges[0],upper[j,0]);y0=np.searchsorted(edges[1],lower[j,1]);y1=np.searchsorted(edges[1],upper[j,1]);masks[x0:x1,y0:y1] |= np.uint64(1)<<np.uint64(j)
 unique,idx=np.unique(masks.ravel(),return_index=True);keep=unique!=0;unique=unique[keep];idx=idx[keep];xs=idx//ny;ys=idx%ny
 pattern=[{'mask':int(m),'cell':[str(F(int(edges[0][i]),4)),str(F(int(edges[0][i+1]),4)),str(F(int(edges[1][j]),4)),str(F(int(edges[1][j+1]),4))]} for m,i,j in zip(unique,xs,ys)]
 d=((4*R)**2).tolist();v=[str(F(z[-1],16)) for z in selected];V=str(sum(map(F,v),F()))
 stars=[[str(F(int(lower[j,0]),4)),str(F(int(upper[j,0]),4)),str(F(int(lower[j,1]),4)),str(F(int(upper[j,1]),4))] for j in range(40)]
 return {'seed':spec['seed'],'spec':spec,'N':40,'records':selected,'d':d,'v':v,'V':V,'stars':stars,'patterns':pattern,'all_face_grid_cells':nx*ny,'grid_dimensions':[nx,ny],'connected':True,'triangle':tri,'graph_edge_count':int(adj.sum()//2),'empty_common':True,'common_bounds_quarter_units':[lower.max(axis=0).tolist(),upper.min(axis=0).tolist()]}
def matrix(g):
 masks=np.array([q['mask'] for q in g['patterns']],dtype=np.uint64);return ((masks[:,None]>>np.arange(40,dtype=np.uint64))&1).astype(float)
def solve_lp(g):
 A=matrix(g);sol=linprog(-np.array(g['d'],float),A_ub=A,b_ub=np.ones(len(A)),bounds=(0,None),method='highs');assert sol.success;return float(-sol.fun)
def task(payload):
 g,alpha,lp=payload;wall=time.monotonic();cpu=time.process_time();A=matrix(g);d=np.asarray(g['d'],float);v=np.array([float(F(z)) for z in g['v']]);V=float(F(g['V']));eps=alpha*lp/V
 lam=cp.Variable(len(d),pos=True);con=A@lam<=1;problem=cp.Problem(cp.Maximize(d@lam+eps*cp.sum(cp.multiply(v,cp.log(lam)))),[con])
 problem.solve(solver='CLARABEL',max_iter=500,tol_gap_abs=1e-9,tol_gap_rel=1e-9,tol_feas=1e-9)
 if lam.value is None or con.dual_value is None:return {'seed':g['seed'],'alpha':alpha,'status':problem.status,'error':'solver returned no solution'}
 lv=np.asarray(lam.value);z=np.maximum(np.asarray(con.dual_value),0);loads=A@lv;mu=A.T@z;Q=float(d@lv);M=float(z.sum());station=mu-d-eps*v/lv;bound=eps*v/M
 return {'seed':g['seed'],'alpha':alpha,'epsilon':eps,'mLP':lp,'status':problem.status,'objective':float(problem.value),'lambda':[format(x,'.17g') for x in lv],'source_z':[format(x,'.17g') for x in z],'Q':Q,'M':M,'Q_plus_epsV':Q+eps*V,'mass_identity_abs_error':abs(M-Q-eps*V),'max_constraint_violation':max(0.,float(loads.max()-1)),'stationarity_inf_abs':float(np.max(np.abs(station))),'stationarity_inf_relative':float(np.max(np.abs(station)/np.maximum(1.,np.abs(d+eps*v/lv)))),'complementarity_max':float(np.max(np.abs(z*(1-loads)))),'lower_bound_min_ratio':float(np.min(lv/bound)),'lambda_min':float(lv.min()),'lambda_max':float(lv.max()),'inverse_lambda_max':float(1/lv.min()),'positive_source_cells':int(np.count_nonzero(z>0)),'solver_iterations':problem.solver_stats.num_iters,'elapsed_seconds':time.monotonic()-wall,'cpu_seconds':time.process_time()-cpu,'peak_rss_bytes_macos':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--phase',choices=('prepare','preflight','remaining'),required=True);ap.add_argument('--workers',type=int,default=1);ap.add_argument('--output-dir',type=Path,default=Path('/tmp'));a=ap.parse_args();assert 1<=a.workers<=8;a.output_dir.mkdir(parents=True,exist_ok=True)
 index=a.output_dir/'ccu_r619_index.json';data=a.output_dir/'ccu_r619_barrier.json';report=a.output_dir/'ccu_r619_barrier.md';start=time.monotonic()
 if a.phase=='prepare':
  gs=[generate(s) for s in SPECS]
  for g in gs:g['mLP']=solve_lp(g)
  x={'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'python':sys.version,'numpy':np.__version__,'scipy':scipy.__version__,'cvxpy':cp.__version__,'clarabel':clarabel.__version__,'geometries':gs,'results':[],'commands':[shlex.join([sys.executable]+sys.argv)]};data.write_text(json.dumps(x));index.write_text(json.dumps({'phase':'prepared','tasks':12,'geometries':[{'seed':g['seed'],'N':g['N'],'patterns':len(g['patterns']),'cells':g['all_face_grid_cells'],'edges':g['graph_edge_count'],'triangle':g['triangle'],'mLP':g['mLP']} for g in gs],'budget_bytes':2*1024**3,'preflight_workers':1,'max_workers':8},indent=2));print(index.read_text());return
 x=json.loads(data.read_text());gs=x['geometries'];x['commands'].append(shlex.join([sys.executable]+sys.argv));pairs=[(gs[0],ALPHA[0],gs[0]['mLP'])] if a.phase=='preflight' else [(g,alpha,g['mLP']) for g in gs for alpha in ALPHA if not(g['seed']==gs[0]['seed'] and alpha==ALPHA[0])]
 with concurrent.futures.ProcessPoolExecutor(max_workers=a.workers) as pool:
  for f in concurrent.futures.as_completed([pool.submit(task,t) for t in pairs]):
   r=f.result();x['results'].append(r);data.write_text(json.dumps(x));print('done',r['seed'],r['alpha'],r['status'],flush=True)
 x['last_elapsed_seconds']=time.monotonic()-start;data.write_text(json.dumps(x));lines=['# R619 all-source logarithmic barrier diagnostics','','40 positive-increment cubes per family; exact endpoint face cells encoded as uint64 incidence patterns. Every star participates; incidence is reused across alpha values. The full-source covering LP is solved once per geometry. Finite floating solver results are diagnostics, not rigorous KKT certificates.','','| seed | εV/mLP | status | min λ | max 1/λ | mass identity error | stationarity relative | min λ/(εv/M) |','|---:|---:|:---|---:|---:|---:|---:|---:|']
 for r in sorted(x['results'],key=lambda r:(r['seed'],-r['alpha'])):
  if 'lambda_min' not in r:lines.append(str(r));continue
  lines.append('| %d | %.4g | %s | %.7g | %.7g | %.3g | %.3g | %.7g |'%(r['seed'],r['alpha'],r['status'],r['lambda_min'],r['inverse_lambda_max'],r['mass_identity_abs_error'],r['stationarity_inf_relative'],r['lower_bound_min_ratio']))
 report.write_text('\n'.join(lines)+'\n');i=json.loads(index.read_text());i['phase']=a.phase;i['completed']=len(x['results']);i['last_workers']=a.workers;i['last_elapsed_seconds']=x['last_elapsed_seconds'];i['max_worker_peak_rss_bytes']=max((r.get('peak_rss_bytes_macos',0) for r in x['results']),default=0);index.write_text(json.dumps(i,indent=2))
if __name__=='__main__':main()
