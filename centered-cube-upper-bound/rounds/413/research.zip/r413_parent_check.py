from fractions import Fraction as F

def loglo(x):
    assert x>=1
    k=0
    while x>=2: x/=2;k+=1
    def series(v):
        t=(v-1)/(v+1)
        return 2*sum((t**(2*j+1)/F(2*j+1) for j in range(48)),F(0))
    return k*series(F(2))+series(x)

counts={};positive=0
for phase,Ns in [('initial',[16,32]),('atomic_pressure',[48,64]),('expanded',[128,256])]:
    count=0
    for N in Ns:
      for pattern in [1,3]:
       for scale in [F(1,3),F(1),F(7)]:
        rho=[scale*F(1+i%pattern,pattern) for i in range(N)]
        T=[];v=F(0)
        for x in rho:v+=x;T.append(v)
        J=T[-1]
        Z=[T[i-2] if i>=2 else F(0) for i in range(N)]
        B=max(t-z for t,z in zip(T,Z));eps=F(1,2);h=B/eps
        for L in [4,8]:
         az=(L-eps)*h;cz=F(L)/(L-eps-1)
         for kap in [F(1,16),F(1,4),F(1,2)]:
          low=sum((rho[i] for i in range(N) if T[i]<=kap*J),F(0))
          assert low<=kap*J
          theta=kap/(1+B/az)
          selected=[i for i in range(N) if T[i]>kap*J and Z[i]>az]
          if selected: positive+=1
          for i in selected:
            left=T[i]-rho[i]
            assert left>=Z[i]>theta*J
            assert F(1)/(Z[i]-h)<=cz/T[i]
          col=sum((rho[i]/(Z[i]-h) for i in selected),F(0))
          assert col<=cz*loglo(1/theta)
          count+=1
    counts[phase]=count
print('PASS relative-new gate and uniform column:',counts,'total',sum(counts.values()))
print('Nonempty selected configurations:',positive)
print('Exact Fraction atoms and rational log lower bounds; native geometry/history not simulated.')

# Independent current-source kernel / cumulative low-degree checks.
source=[F(1),F(2),F(1),F(3)]
masks=[{0,1},{1,2},{2,3},{0,3}]
pi=[[source[y]/sum(source[j] for j in mask) if y in mask else F(0) for y in range(4)] for mask in masks]
rows=0
for stages in [3,5,8]:
 for tau in [F(1,8),F(1,2)]:
  for d0 in [F(1,8),F(1,2),F(2)]:
   sigma=[F(1),F(2),F(1),F(3)];X=sum(sigma);W=sum(source);B=F(2)
   a=[[[B*F(stages-i,stages)*F(1+(A+2*y)%4,4) for y in range(4)] for A in range(4)] for i in range(stages)]
   ss=[[sum(pi[A][y]*a[i][A][y] for y in range(4)) for A in range(4)] for i in range(stages)]
   b=[[F(1,2) if i==z%stages else F(0) for z in range(4)] for i in range(stages)]
   D=[[sum(sigma[A]*ss[i][A]*pi[A][y] for A in range(4))/source[y] for y in range(4)] for i in range(stages)]
   low=F(0);oldlow=F(0)
   for i in range(stages):
    for A in range(4):
     for y in range(4):
      for z in range(4):
       cost=sigma[A]*pi[A][y]*a[i][A][y]*pi[A][z]*b[i][z]
       if ss[i][A]<=tau*B:low+=cost
       else:
        assert a[i][A][y]<=ss[i][A]/tau
        if D[i][y]<=d0:oldlow+=cost
   assert low<=tau*B*X
   assert oldlow<=d0*W/tau
   rows+=1
print('PASS current-kernel cumulative low-marginal and low-old-occupation:',rows,'configurations')
print('Finite common-posterior density interfaces; not original cube/clock/history fixtures.')
