# R413：原旧来源相对秩门的一次收费与维数一致的旧来源见证列

2026-10-20。本稿证明两件事：在当前 R412 实际正限制及其完整路径标签上，删除 \(T_v(y)\le\kappa J(y)\) 只需一次 \(2C_{\rm col}(\lambda/q_-)\kappa X_q\)；其补门使 **旧来源 y 通道**的 R411 初始见证列从对数维度上界改为显式 \(O_\kappa(1)\)。保留 R406 平方根门，不替换其已付费用。新来源 z 列、全部终端列及一般剩余费用不由本稿闭合。

## 1. 原场、完整标签和所增加的门

冻结 full \(f\)、实际中心 \(du\)、\(m_u=f(Q_u)=q_uR_u^n\)、\(q_-\le q_u\le\lambda\)、\(a\le R_u\le b\le2a\)。记

\[
\mu(du)=du/m_u,\quad \sigma(du)=q_u du,\quad
\pi_u(dy)=f(y)c_u(y)dy/m_u,\quad r_q=\lambda/q_-,
\]
\[
J(y)=\int c_w(y)\mu(dw),\quad
T_v(y)=\int c_w(y)1_{m_w\le m_v}\mu(dw),\quad
Z_A(y)=\int c_w(y)1_{m_w<m_A/K}\mu(dw).
\]

这里 \(J(y)\) 是完整终时来源占用；原物理累计 \(J_y(r)\) 及其 clock 没有改写。\(K=e^{\sqrt n}\)，\(h=(1+\sqrt n)/(\varepsilon_0q_-)\)，\(0<\varepsilon_0\le1/2\)。已证闭窗

\[
0\le T_A(y)-Z_A(y)\le B_0=\varepsilon_0h.
\tag{1}
\]

原旧边 \((y,u,v)\) 满足 \(m_u>Km_v\)。R406 已保留

\[
T_v(y)>4h+\sqrt{hJ(y)}>4h.
\tag{2}
\]

当前输入 \(\mathcal R\) 可取 R412，也可取它的任意未重新归一化正限制。父 \(A=u\) 或 \(A=v\)、新来源 z、原 exclusive 见证 w,t、其固定来源下降路径与终端、early/首次删除/物理时钟及其他旧标记均保留。原 \(\Gamma_i\) 与 \(b_i\) 冻结，不因新门重算。

给定 \(0<\kappa<1\)，在同一个完整标签空间分拆

\[
\mathcal R=\mathcal R_{\rm low,old}+\mathcal R_{\rm rel,old},
\quad \mathrm{low}:T_v(y)\le\kappa J(y),\quad
\mathrm{rel}:T_v(y)>\kappa J(y).
\tag{3}
\]

新门仅作用原旧来源 y 和原小端 v，不赋给 z、w、t 或终端。所有后添路径都是原条件概率核；(3) 与这些扩充 commute，因为门在原标签上可测。已经停止或路径长度不足的情况不需额外尾费：R412 路径有限、每个初始 own-high 的全路径核总概率1；限制后概率只会变小。

## 2. 累计旧来源低相对秩收据

对固定 y，把 \(\rho_y(dw)=c_w(y)\mu(dw)\) 推到质量轴。对任意 \(a\ge0\)，闭 CDF 满足

\[
\rho_y\{T_w(y)\le a\}\le a.
\tag{4}
\]

含完整质量原子时仍成立：左侧集合是初始段，超过 a 的第一跨越原子整块排除；由有限初始截断再单调收敛即可。现在取对固定 y 为常数的 \(a=\kappa J(y)\)，得到

\[
\int\sigma(dv)\pi_v(dy)1_{T_v(y)\le\kappa J(y)}
\le\lambda\kappa f(y)J(y)dy.
\tag{5}
\]

不能逐 stage 收费。原 nested \(\Gamma_i\le\Gamma_0\)、\(\sum_i b_i(z)\le1\) 给每条旧边两个父端的全部切换费用至多2。early、双提升、内层/外层与完整路径限制均为≤1的正限制，故

\[
\mathcal R_{\rm low,old}\le2\Gamma_0[T_v(y)\le\kappa J(y)].
\]

使用原逐旧来源入列 \(\Gamma_0(E,dy,dv)\le C_{\rm col}\sigma(dv)\pi_v(dy)\)，以及真实匹配恒等式

\[
\int f(y)J(y)dy=\int\frac{f(Q_w)}{m_w}dw=|E|,
\]

结论为

\[
\boxed{\mathcal R\le\mathcal R_{\rm rel,old}
 +2C_{\rm col}\lambda\kappa|E|
 \le\mathcal R_{\rm rel,old}+2C_{\rm col}r_q\kappa X_q.}
\tag{6}
\]

因此取 \(\kappa=\eta_2/(2C_{\rm col}r_q)\in(0,1)\) 时，新费≤\(\eta_2X_q\)。若此值≥1，可以 κ=1 删除整个输入且仍≤\(\eta_2X_q\)；此时没有需估计的高补门，也不使用下面的 logarithm。\(C_{\rm col}=0\) 时原入流已为零。\(J(y)=0\) 的来源没有原费用；所有零流结论直接为0，不作归一化除0。\(|E|\) 有限由原 \(X_q\) 有限得到；无限情形只能作截断/扩展实数陈述。

这延续 R406 的 sourcewise CDF 工具，但实际支付的是当前保留流的新相对旧秩支。它不把 R406 原平方根费用退回，也不重收 R398 的新来源低秩价格。

## 3. 相对旧门使两个父的旧来源 strict rank 占总秩固定比例

令

\[
c_0=1-\varepsilon_0/4\ge7/8,\qquad
 a_\kappa(y)=\max\{(4-\varepsilon_0)h,\ c_0\kappa J(y)\}.
\tag{7}
\]

在高补门，外端 \(A=u\) 因 \(m_u>Km_v\) 有
\(Z_u(y)\ge T_v(y)>\max(4h,\kappa J(y))\)。小端 \(A=v\) 由 (1)–(2) 有

\[
Z_v(y)\ge T_v(y)-\varepsilon_0h
>c_0T_v(y)>c_0\kappa J(y),\qquad
Z_v(y)>(4-\varepsilon_0)h.
\]

所以两种父均满足

\[
Z_A(y)>a_\kappa(y),\qquad
\frac1{Z_A(y)-h}\le\frac4{3-\varepsilon_0}\frac1{T_A(y)}.
\tag{8}
\]

后一式来自 \(T_A\le Z_A+\varepsilon_0h\) 以及 \((Z+\varepsilon_0h)/(Z-h)\) 随 Z>h 递减。外端若单独估计也可用 \((4+\varepsilon_0)/3\)，且
\((4+\varepsilon_0)/3\le4/(3-\varepsilon_0)\)；没有误用忽略闭窗误差的4/3。

## 4. 旧来源初始见证列的新界：原子积分没有额外 +1

令 \(\Lambda_{y,\rm rel}(dw,dy)\) 为相对高旧门下，原双 exclusive lift 中 **w 携带 y** 的单边推前；允许任何当前正限制及完整路径扩充后积分全部后继标签。每份费用仍保整份 y 通道，不与半分守恒方案混同。

原 exclusive 分母 \(Z_A(y)-C_A(y,z)\ge Z_A(y)-h\)。对旧 y 通道，\(b_i\) 位于被积分的新来源 z：必须先按同一个 z 累积 \(\sum_i b_i(z)\le1\)，再用 \(\pi_A\) 的概率归一化。原阶段与 first-deletion 的累计方式同 R411 aux (5)。这给

\[
d\Lambda_{y,\rm rel}(w,y)
\le S f(y)c_w(y)\mu(dw)dy
\int\frac{q_Ac_A(y)}{Z_A(y)-h}
 1_{Z_A(y)>a_\kappa(y)}1_{m_A>Km_w}\mu(dA).
\tag{9}
\]

其余 old-v 门/空间/clock/path 条件仅为上界而正删除；没有改变原流。对固定 y，\(a_\kappa(y)\) 是常数。质量原子右秩为 T，左秩为 \(T_-\)。严格过去 \(Z_A\le T_-\)，故 (9) 的原子必有 \(T_->a_\kappa\)。因此将原子展开为 \([T_-,T]\)，

\[
\frac{T-T_-}{T}\le\int_{T_-}^{T}\frac{dr}{r},\qquad
\int 1_{Z_A>a_\kappa}\frac{\rho_y(dA)}{T_A(y)}
\le\log_+\frac{J(y)}{a_\kappa(y)}.
\tag{10}
\]

无原子部分作 CDF 换元。跨越下限的原子因 strict Z 门已排除，故没有被漏掉的 +1；只有闭 T 门时不能这样说。\(J\le a_\kappa\) 时左边为空，取值0。

由 (8)–(10)、\(q_A\le\lambda\) 和 \(q_w\ge q_-\)，

\[
\boxed{d\Lambda_{y,\rm rel}\le C_{y,\rm rel}(y)\,
       \sigma(dw)\pi_w(dy),\quad
C_{y,\rm rel}(y)=Sr_q\frac4{3-\varepsilon_0}
       \log_+\frac{J(y)}{a_\kappa(y)}.}
\tag{11}
\]

在 \(J=0\) 处定义该系数0。特别

\[
C_{y,\rm rel}(y)\le\overline C_{y,\rm rel}
:=Sr_q\frac4{3-\varepsilon_0}\log\frac1{c_0\kappa}.
\tag{12}
\]

固定 \(\kappa\) 和显示参数时，(12) 不含 n。可同时保留旧列上界并取最小值；本稿不要求原新来源 z 的列也改善。在 z 通道，保留来源是 z，旧 y 相对门不推出 \(Z_A(z)\gtrsim\kappa J(z)\)，所以不能照抄 (11)。

(11)是初始 w 的列界，不是 R412 最终 b 的列界。固定来源全路径虽有限，其总终端密度仍受 \(M(y)\rho_y/h\) 控制；相对旧门没有证明 \(M(y)\lesssim h\)，不能由此自动支付全部当前终端外侧槽。

## 5. 当前回代、可重建价格与严格边界

对当前 R412 直接用 (6)，原余流槽 \(64\Lambda F_{\rm late}\mathcal R\) 仅新增

\[
64\Lambda F_{\rm late}\eta_2X_q,
\]

并改为 \(64\Lambda F_{\rm late}\mathcal R_{\rm rel,old}\)。R406 平方根门、其 \(D_\eta sW\)、R411 和 R412 已付费用全部保持一次。此处是实际一次付款；(11)给剩余流更强的可用列容量，但不等于整个剩余槽已有新根阶预算。

若要用 (12) 将此前旧来源通道的 root-log 价格降为 root，必须把新增门前置至 R408 后，**重新执行同一组分拆**。因为门只依赖原 \((y,v)\)，且不改变 full f、\(\Gamma_i,b_i\)、exclusive 核和路径核，它与这些概率扩充可交换；但若已经按末端门应用 (6)，不得追溯退款。前置重建时，旧 y 方向可分别使用显示来源价格

\[
\overline C_{y,\rm rel}\lambda(h+B_0)W
\quad\text{和}\quad
\overline C_{y,\rm rel}\frac{\lambda\alpha_{\rm inner}^{n}A_n}{q_-}W
\]

代替该方向原初始 own-low 与 source-inner 收据。新 z 方向仍须保留其原列价格，除非另证其自己的相对门。上述两支须依原先后次序正分拆，各付一次；本稿不把这些可重建价额外加入当前末端账，更不独立重建主稿全部母账。

若 \(\eta_2\) 固定且其他参数维度一致，\(\kappa=\eta_2/(2C_{\rm col}r_q)\) 固定，旧 y 列费为 \(O(1+\log(1/\eta_2))\)；若参数随 n 变化，必须保留 (12) 的完整依赖。

## 6. 本机三阶段 Fraction 检查

`/tmp/r413_aux_check.py` 实际输出：

```
PASS {'receipt': 18, 'atoms_coefficients': 27, 'prefix_integrals': 24, 'expanded_nonzero': 9} total 78
positive receipt cases 13 positive expanded prefix cases 9
All Fraction. Finite mass/rank and marked-flow interfaces; not native cube/history realizations.
```

初步18例核闭CDF、原平方根门（用平方的有理条件核验）、nested stage 与两端 b_i 累计，并保额外 path 正限制；13例实际低支费用正。原子压力27例核严格左秩排除 crossing atom、q/闭窗系数和统一 \(4/(3-\varepsilon_0)\)。扩大阶段24+9例核真实 finite strict-prefix 求和；9个长质量序列的原积分均非零。对 logarithm 使用 \(\log x=2\sum_{j\ge0}a^{2j+1}/(2j+1)\)、\(a=(x-1)/(x+1)\) 的100项有理下界来认证所检验上界，非浮点近似。

这些是有限质量秩/标记接口模型，未声称实现真实 cube 选择器、octave 或原完整历史。连续原场结论由 (4)–(12) 的正测度、CDF和匹配证明给出。没有替新辅助节点继承原资格，没有更改物理/历史时间原子。
