from fractions import Fraction as F
from collections import Counter
C=Counter(); positive=0

def log_lower(x,terms=100):
    assert x>=1
    a=(x-1)/(x+1); v=a; out=F(0)
    for k in range(terms):
        out+=v/F(2*k+1); v*=a*a
    return 2*out

def ranks(m,r,K):
    T=[sum((r[j] for j in range(len(m)) if m[j]<=m[i]),F(0)) for i in range(len(m))]
    Z=[sum((r[j] for j in range(len(m)) if m[j]*K<m[i]),F(0)) for i in range(len(m))]
    return T,Z

# 1. Exact cumulative old-source receipt; nested stages and two endpoint laws.
for r in ([F(1),F(2),F(1),F(3)],[F(1,2),F(1,3),F(2),F(3,2)]):
 for kap in (F(1,4),F(1,2),F(3,4)):
  for h in (F(0),F(1,100),F(1,10)):
   m=[1,1,3,9]; J=sum(r); T,Z=ranks(m,r,F(3)); lam=F(1); ccol=F(3,2)
   q=[F(3,4),F(1),F(4,5),F(7,8)]
   assert sum((r[i] for i in range(4) if T[i]<=kap*J),F(0))<=kap*J
   total=F(0)
   for v in range(4):
    # Prior square-root gate tested exactly, no floating square root.
    prior=T[v]>4*h and (T[v]-4*h)**2>h*J
    if not(prior and T[v]<=kap*J): continue
    gamma=ccol*q[v]*r[v]*F(v+1,4)
    theta=[F(1),F(2,3),F(1,3)]
    b=[[F(1,4),F(1,3)],[F(1,4),F(1,6)],[F(1,2),F(1,2)]]
    for endpoint in (0,1):
     law=[F(1+endpoint,3),F(2-endpoint,3)]
     # Current extra / path events are positive factors, not renormalized.
     for i in range(3):
      for z in range(2):
       total+=gamma*theta[i]*law[z]*b[i][z]*F((v+i+z)%3+1,3)
   assert total<=2*ccol*lam*kap*J
   positive+=total>0; C['receipt']=C['receipt']+1

# 2. Fraction certificates for crossing atoms and coefficient conversion.
for eps in (F(1,8),F(1,4),F(1,2)):
 for kap in (F(1,4),F(1,2),F(3,4)):
  for J in (F(3),F(8),F(30)):
   h=F(1); c=1-eps/4; fac=4/(3-eps)
   # The first atom crossing c*kappa*J is excluded by Z > threshold.
   a=c*kap*J
   intervals=[(F(0),a+1),(a+1,a+2),(a+2,a+5)]
   for left,right in intervals:
    z=left
    if z>a:
     assert left>a
     assert (right-left)/right <= 2*(right-left)/(right+left)
   assert (4+eps)/3<=fac
   for tv in (F(5),F(9),F(40)):
    if tv>max(4*h,kap*J):
     zv=tv-eps*h
     assert zv>c*tv and zv>max((4-eps)*h,c*kap*J)
     assert tv/(zv-h)<fac
   C['atoms_coefficients']+=1

# 3. Actual finite strict-prefix integral under the closed-window cap.
# Mass ratios chosen close to1 so K-window has at most3 levels; duplicate atoms retained.
for N in (8,12,18,24):
 for eps in (F(1,4),F(1,2)):
  m=[F(3,2)**(i//2) for i in range(N)]
  r=[F((i%3)+1,4) for i in range(N)]
  J=sum(r); T,Z=ranks(m,r,F(2)); B=max(t-z for t,z in zip(T,Z)); h=B/eps
  for kap in (F(1,4),F(1,2),F(3,4)):
   c=1-eps/4; a=max((4-eps)*h,c*kap*J); fac=4/(3-eps)
   active=[i for i in range(N) if Z[i]>a]
   val=sum((r[i]/(Z[i]-h) for i in active),F(0))
   hardy=sum((r[i]/T[i] for i in active),F(0))
   assert val<=fac*hardy
   assert hardy<=log_lower(1/(c*kap))
   if J<=a: assert val==0
   C['prefix_integrals']+=1
# Extra long ranks give nonzero cases while preserving the exact window cap.
nonzero=0
for N in (48,96,144):
 m=[F(3,2)**i for i in range(N)];r=[F(1)]*N;T,Z=ranks(m,r,F(2));h=F(4);eps=F(1,2)
 assert max(t-z for t,z in zip(T,Z))<=eps*h
 for kap in (F(1,4),F(1,2),F(3,4)):
  c=1-eps/4;a=max((4-eps)*h,c*kap*N);fac=4/(3-eps)
  val=sum((r[i]/(Z[i]-h) for i in range(N) if Z[i]>a),F(0))
  assert val<=fac*log_lower(1/(c*kap))
  nonzero+=val>0;C['expanded_nonzero']+=1
print('PASS',dict(C),'total',sum(C.values()))
print('positive receipt cases',positive,'positive expanded prefix cases',nonzero)
print('All Fraction. Finite mass/rank and marked-flow interfaces; not native cube/history realizations.')
