# R413 independent audit — FINAL PASS

FINAL PASS for the two relative-rank receipts, their dimension-uniform initial-witness columns, the original-stage low-marginal/current-old-low receipts, and the final pre-gated ledger rebuild. Each candidate was independently screened before its corresponding author treatment. Final main/readme/proofs/code were read; all458 delivered Fraction model/certificate records were actually rerun and passed. The joint high-current-occupation remainder and layer-uniform P remain unpaid. No general weak-type closure or total-absorption availability is certified. Only this audit file was edited.

## 1. Fixed original measure and independent relative-gate proofs

Keep full matched f, true du/m, σ=qdu, original physical clock/J/H, original old-source y/new-source z, u/v endpoint and parent-direction tags, original Γ_i, b_i, D_i, first-deletion/early/soft/far/history marks and the existing R406 square-root gate. Every auxiliary witness/path is a probability extension or an unrenormalized positive restriction; original sources or historical eligibility are never refreshed.

At fixed old y the inclusive mass-CDF sublevel satisfiesρ_y{T_v(y)≤κ_yJ(y)}≤κ_yJ(y), including equal-rank atoms. Use the ORIGINAL sourcewise incoming C_col and the once-only two-endpoint switching estimate (at most2 original edge costs after cumulative stages), then q_v≤λ and ∫fJ=|E|≤X_q/q_-. Thus the old relative-low branch costs

2C_col(λ/q_-)κ_yX_q.

The factor2 is a safe bound for the two actual endpoint bills, not a stage count. It applies to arbitrary current positive/path restrictions. C_col=0 gives empty original flow and avoids division; κ_y≥1 has no high complement. The existing Tv>4h+sqrt(hJ) gate is retained, not replaced or refunded.

For new z use its ORIGINAL parent tag A=u orv. After common stage summation the whole parent envelope is Sσ(dA)π_A(dy)π_A(dz), S=β+C_col. The closed-CDF low event T_A(z)≤κ_zJ(z) costs

S(λ/q_-)κ_zX_q.

There is no2S: both parent types are already included by S. This branch is applied after the old-relative high event, so the low payments are disjoint. All CDFs and full-field J stay fixed. J=0 sources carry no original cost.

## 2. Atomic-safe dimension-uniform initial columns

After the old relative high gate, strict m_u>Km_v gives Z_u(y)≥T_v(y). At the small parent Z_v(y)≥T_v(y)−ε0h, and original Tv>4h is essential. Both parents therefore satisfy

Z_A(y)>(1−ε0/4)κ_yJ(y),
T_A(y)/(Z_A(y)−h)≤4/(3−ε0).

The large-parent alternative coefficient(4+ε0)/3 is indeed no greater. For new z, retain Z_A(z)>(L−ε0)h and T_A−Z_A≤ε0h. Its relative high gate gives

Z_A(z)>(1−ε0/L)κ_zJ(z),
T_A(z)/(Z_A(z)−h)≤L/(L−ε0−1).

Strict far past is contained in the FULL parent's strict left mass rank, so each selected complete parent atom starts above its respective θ_xJ(x). Expanding whole atom rank intervals and the continuous/singular parts gives ∫ρ_x(dA)/T_A(x)≤log(1/θ_x), with NO crossing-atom+1. Merely keeping the right closed-rank high gate would not suffice. The strict past and retained absolute gates are not dropped prematurely.

Old/new source positions and b_i(z) are kept until legitimate cumulative summation; changing σπ measures costs exactly q_A/q_w≤r=λ/q_-. Hence

C_y,rel=Sr·4/(3−ε0)·log[1/((1−ε0/4)κ_y)],
C_z,rel=Sr·L/(L−ε0−1)·log[L/((L−ε0)κ_z)].

These are WHOLE-channel initial witness-column dominations, not equalities or terminal-column bounds. They have no dimension/stage/layer dependence for fixed displayed parameters. Positive later restrictions preserve their use, but conditional renormalization can increase densities and is not authorized.

## 3. Independent stage low-marginal/current-source bridge

Let a_i^e(A,y) be the ORIGINAL Γ_i old-source marginal density relative toσπ_A, with0≤a_i^e≤B_e, B_u=β,B_v=C_col. Let s_i^e=Eπ_A a_i^e. For a stage/direction cost unit, pay s_i^e(A)≤τB_e first. Sum deleted-edge/early restrictions at fixed i to≤Γ_i, integrate old y, and keep b_i at the SAME new z. Then

low_e≤Σ_i∫σs_i^e1_low π_A(b_i)
≤τB_e∫σπ_A(Σ_i b_i)≤τB_eX_q.

Both orientations costτS X_q, without an additional2 or stage count. Zero B_e/s_i rows have zero actual cost. The i dependence ofπ_A(b_i) is handled by summing at the same A,z, not by treating it as constant across stages.

On the high stage units a_i^e/s_i^e≤1/τ. This is the ORIGINAL Γ_i conditional old-source law. The FINAL filtered and renormalized conditional law need not obey it. Retaining z gives the source-projection upper envelope

τ^−1σ(dA)s_i^e(A)π_A(dy)π_A(dz)b_i(z).

For other saved labels the author correctly keeps the ORIGINAL conditional kernel, with zero subkernel at a_i^e=0; the envelope is not asserted to be a label-preserving equality or a free π refresh. Consequently old-current source marginal is dominated byτ^−1f(y)D_i(y)dy.

Original Γ_i nesting makes common versions of s_i^e(A) decrease in i. Define the unmodified source kernel

M_i(dy,dz)=Σ_e∫σs_i^eπ_A(dy)π_A(dz),
K_i(y,z)=∫σ(dA)s_i(A)c_A(y)c_A(z)/m_A².

Then M_i=f(y)f(z)K_i dy dz, K_i decreases pointwise in a common countable-stage version, and its first marginal is exactly f(y)D_i(y)dy. This includes both directions already.

For j(y)=first i with D_i(y)≤d0, no such index means no selected branch. Otherwise all selected i≥j(y); use K_i≤K_j and SAME-z Σ_i b_i(z)≤1. Integrating gives the all-stage price

τ^−1Σ_i∫M_i b_i(z)1_{D_i(y)≤d0}≤d0W/τ.

There is no additional factor2 and no repeated d0W per stage. j(y) is a measurable posthoc grouping of positive integrals, not a historical/predictable stopping qualification. Finite truncations retain separate frozen terminal costs; positive Tonelli and original clearing justify the infinite stage sum. Zero-f sources contribute zero. None of s_i,D_i,M_i is rebuilt after adding high-degree or relative gates; such a rebuilt density need not be monotone.

Take d0=s. This is a real new root-order W receipt. The remaining charged units have high s_i^e and BOTH D_i(y)>s,D_i(z)>s, the latter already forced by b_i(z)>0. These are source/charge-stage conditions, not assertions that all full endpoint-posterior sources are high. This still does not cancel the layer factor2^k.

## 4. Final pre-gated rebuild, parameter dependence and full ledger

Main correctly starts again with original R408: pay the two relative-low gates, stage low-marginal, and old-current-low; THEN on the remainder redo the same R411/R412 joint decomposition (initial inside, own-low, source-inner, terminal return). All kernels/fields stay the same. The final event is the old R412 event intersected with four original charge-label gates. Commutation of events with probability extensions does not itself permit retroactive refunds; the entire disjoint pre-gated calculation is explicitly rebuilt.

With D_rel=C_y,rel+C_z,rel, main uses

P_low,rel=λ(h+B0)D_rel,
P_inner,rel=(λ/q_-)A_nD_rel/sqrt(n+2).

They REPLACE the old P_low/P_inner, not add to them. Inside Δ_in and terminal-return Δ_return keep their old safe bounds once. Therefore

R408≤R413+[η_gate+τS+Δ_in+Δ_return]X_q
+[s/τ+P_low,rel+P_inner,rel]W,
η_gate=2C_col rκ_y+Srκ_z.

The formal C413/V413 in main add these prices to C406/V406 and retain16Fδ/32Fδ/64ΛFδ at G0/BH/entrance. External E387/S390/8s/H/A_entrance,n coefficients stay unchanged. Low-dimensional complete-core replacement is an alternative, not an additional charge. Old square/cross/clock credits and source-near prices are never reused.

The geometry attachment's C_end,V_end are a separate looser post-R412 option retaining OLD source prices. They are now explicitly distinguished from the main pre-R408 repriced C413,V413 and cannot be combined. That naming/price patch and aux's exponent-only patch were reviewed.

For0<t<min(1,2C_col r,Sr), chooseκ_y=t/(4C_col r),κ_z=t/(2Sr):η_gate=t and D_rel=O(1+log(1/t)) with fixed displayed constants. If also t<S,τ=t/S gives another tX_q and(S/t)sW. Thus combined new gates cost2tX_q; use t/2 throughout if a total tX_q gate budget is desired. No h/H/field is silently reset and no uniform total-absorption balance is inferred. Neither the repriced complete RHS nor every individual parameter version is claimed to be smaller for every input.

## 5. What remains unpaid

The exact positive current-density bridge is now supplied; it is no longer correct to say only full-field J columns are available. Nevertheless source-marginal integration of the high-current joint kernel recovers f(z)D_i(z), leaving the layer bound2^{k+1}sW. The layer-uniform P estimate with fixed polynomial t dependence for the ENTIRE remaining joint cost is still unproved. Initial/source/terminal/far/low-common/relative-rank/current-high constraints and all original history remain; no descendant may inherit original Γ eligibility or a refreshed posterior.

The retained positive-information diagnostic uses log_+ (a/s), E_i≤s_i log(B_e/s_i)≤B_e/e, hence its all-stage weighted information is≤SX_q/e. It is finite, involves no infinity-minus-infinity and is not a lower bound for R_k or a newly spendable arbitrary-small credit. The paid stage/current-low proofs do not rely on this information bound. Main/readme correctly retain the unpaid global root budget, all old entry/soft/crossing/history/extreme-scale/limit/source multiplicity and total absorption obligations. External route/skill mentions are workflow/candidate records, not extra proved inputs in this audit.

## 6. Actual local evidence and strict scope

Before author treatments, reviewer separately executed768 atomic relative-column configurations (744 selected),12 cumulative low-degree configurations with288 row/density checks, and81 sourcewise first-low configurations (9 positive paid). All Fraction/rational-log checks passed. These reviewer-only diagnostics are NOT pooled with delivered counts.

Read and actually reran FINAL delivered scripts, matching final stdout:

- parent234 records:216 relative-new/column configurations (162 selected) plus18 current-kernel cumulative configurations;
- aux78 records:18 receipt,27 atom/coefficient,24 prefix and9 expanded nonzero cases;
- geometry146 records:36 positive-information interval,24 nested matching/current-D graphs,50 occupancy-layer records,36 new stage-gate/first-source-stopping configurations.

Total458 delivered records passed. Parent/reviewer reruns repeat cases and are not new experiments. Rational atanh-series lower bounds/explicit remainders and factorial e bounds are used as described; these are not ordinary floating-point fits. Positive-information log truncation uses log_+, not an invalid signed-KL deletion.

All finite receiver/atomic/source-cell fixtures have their disclosed limits: they do not certify actual continuous native-du, original far/rank/clock/history qualification or general extremal/asymptotic behavior. The36 new geometry configurations include exactly ONE positive dynamic-old-low case after addingτ=1/20; the initial all-zero grid is transparently disclosed and not sold as positive coverage. General receipts are analytic measure/CDF/kernel arguments above, not conclusions extrapolated from counts. No new MATLAB experiment or broad mathematical search was performed for this bounded audit.

## Final byte bindings

- `/tmp/r413_main.md`: `ed03c99fbea15e831c6250832a9fc1f48f04d92cba3475fa60266542badf593f`
- `/tmp/r413_readme.md`: `9cdaeaec62104477c8157b1681439ace1cad8bf701861d45e116e663b505b35a`
- `/tmp/r413_aux.md`: `96034276b547b73951dc50ff8432b9db171cede12c3b6447bf29aa59a4c8e84b`
- `/tmp/r413_geometry.md`: `67be48a59388d5fdcef01049b5098148cbad3a32dddc03abbcd6b7a4d6e0b64c`
- `/tmp/r413_parent_check.py`: `559935b2590196f25ea62277b6df809d09b34867c7d48565bfd41d3bb5c3c15e`
- `/tmp/r413_parent.result.txt`: `70e9996a0deb4945ea6167da324f32dd851b5b387435adf18df241521a79877c`
- `/tmp/r413_aux_check.py`: `7528d17066cb1bbeb8cf79ddde68a00446d5f28c117f9fdcc431f3ddcc7e1758`
- `/tmp/r413_aux.result.txt`: `4e017f5da52c9b9847268521bfbd44d970300516e956bb4cbe188cc9ef1ed1d1`
- `/tmp/r413_geometry_check.py`: `96a720b0376c09176756832cd250f9311854107711b5c5820bbf8217bbe19cd5`
- `/tmp/r413_geometry.result.txt`: `8f13cb585f2d747436436578d79c535881b96882dc1adf02a2d104cfd9f02800`
- `/tmp/r412_main.md`: `ffcddcbeadfe45481d6fb52ea953c7e35bf24ae2451fa001bae2c17883fe7fef`
- `/tmp/r411_geometry.md`: `ed66744b47257f04b5188de053f9638b6dabbe38088a7996150e4166d84d38c6`
- `/tmp/r408_main.md`: `29e41de32db722d89962f3f3593155b7e298bb02350e50cdab4a2a4fd12f3253`

Current final bytes are bound above. Inherited results were used narrowly; no full historical re-audit or blanket closure is asserted. All requested bounded R413 work is complete.
