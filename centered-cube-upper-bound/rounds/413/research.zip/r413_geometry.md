# R413：实际阶段低边缘付款与当前旧来源低占用的累计付款

2026-10-20。**本轮给出两项实际正分支付款：阶段低 endpoint 边缘的 τS X_q 价格，以及其高补集内、旧来源当前占用低的 d₀W/τ 价格。**取 d₀=s 得根阶 W 价；它对所有阶段和占用层合计收费一次。占用层一致引理 P 仍未证明，不能把本轮补集称为已付。

已读取用户建议文件《Pro_410轮后闭合路线与攻坚任务_20261019.md》第4–7节及 R412 最终主稿。建议中的 P 是待证目标，不是外部定理。初始检查点指出的 conditional-density 缺口由下述第一项付款填补；本稿以此最终版本替换此前未收费的偏置检查。

## 1. 同一原流、原占用与准确命题

完整 f、m_A=f(Q_A)=q_AR_A^n、真实中心 dA、q_-≤q_A≤λ、R_A∈[a,b] 全部固定。记 σ(dA)=q_A dA、π_A(dx)=f(x)c_A(x)dx/m_A、W=∫f、X_q=∫σ。Γ_i 是原 Γ₀ 的实际嵌套 endpoint 限制；原物理时钟、旧来源 y、首次删除和历史标签均保留。

R412 是 R408 费用在同一双见证提升及固定来源路径空间上的最终正限制。它保留原 b_i(z)、D_i(z)、early 分数、soft、原远域与双秩门；初始双见证在父外、own-high、exclusive、来源处于 child collar；终端各在原父外、own-low。没有免费刷新 π 或给辅助路径历史资格。

父/辅助另证的相对门 T_v(y)>κ_yJ(y)、原父 T_A(z)>κ_zJ(z) 可先加入，价格为

\[
\eta_{\rm rel}X_q,
\qquad\eta_{\rm rel}=2C_{\rm col}(\lambda/q_-)\kappa_y
 +S(\lambda/q_-)\kappa_z.
\]

本稿不重证或重收该价格；旧平方根门保留。新增门不重算 Γ_i、D_i 或 b_i。以下证明对任何这样的原正限制均有效，特别适用于其后的实际 R412。

原两端逐旧来源容量为

\[
\begin{split}
\Gamma_i(du,dy,E)&=\sigma(du)\pi_u(dy)a_i^u(u,y),
 &0\le a_i^u\le B_u:=\beta,\\
\Gamma_i(E,dy,dv)&=\sigma(dv)\pi_v(dy)a_i^v(v,y),
 &0\le a_i^v\le B_v:=C_{\rm col},
\end{split}\tag{1}
\]

B_u+B_v=S。这里 a_i^u 为原 ℓ_i 的总量，a_i^v 为原 k_i。定义原、未加新门的 endpoint 密度

\[
s_i^e(A)=\int a_i^e(A,y)\pi_A(dy),\qquad e=u,v.
\tag{2}
\]

它们分别是 Γ_i 的出/入边缘相对 σ 的密度，因 Γ_i 嵌套而各自随 i 递减；s_i^u+s_i^v=s_i。原当前占用正好为

\[
D_i(x)=\int_E[s_i^u(A)+s_i^v(A)]c_A(x)R_A^{-n}\,dA.
\tag{3}
\]

这不是完整 receiver 计数 J。所有新门只能限制实际费用，不能把限制后投影的另一组密度拿来替代(2)–(3)。

对 0<τ<1、d₀>0，在原实际费用中按以下顺序分：

1. 对发生于阶段 i、方向 e、父 A 的费用，先付 s_i^e(A)≤τB_e；
2. 在其高补集中，付旧来源 D_i(y)≤d₀；
3. 保留其余实际全部标签、路径和新门。

准确收据是

\[
\boxed{R_{\rm pre}\le R_{\rm rem}+\tau S X_q+\frac{d_0}{\tau}W.}\tag{4}
\]

R_pre 可取加相对门后的 R412；若第一项前置于 R408，后续使用同一原核和正限制仍保持此价格。两项实际分支互斥，没有改变阶段或重新构造计划。

## 2. 第一步：低阶段边缘付款，及高补集的 current-density 桥

把除 b_i(z) 外的所有实际正分数、历史/空间门和概率路径写在原费用内。只在上界时用它们≤1。固定 e，低边缘费用满足

\[
\begin{split}
R_{\rm marg,low}^e
&\le\sum_i\int\sigma(dA)1_{s_i^e(A)\le\tau B_e}
 \left[\int\pi_A(dy)a_i^e(A,y)\right]
 \int\pi_A(dz)b_i(z)\\
&\le\tau B_e\int\sigma(dA)\int\pi_A(dz)\sum_i b_i(z)
\le\tau B_e X_q.
\end{split}\tag{5}
\]

关键是所有 i 使用同一完整 π_A，且标记始终在同一新来源 z 上相加，Σ_i b_i(z)≤1。没有逐阶段收 X_q，也没有把 b_i(z) 移到旧 y。两方向合计为 τS X_q；B_e=0 的方向是零流。

高补集 s_i^e(A)>τB_e 上，

\[
a_i^e(A,y)\le B_e< s_i^e(A)/\tau.\tag{6}
\]

当 s_i^e(A)>0 时，真实旧来源条件概率为

\[
\eta_{i,A}^e(dy)=\frac{a_i^e(A,y)}{s_i^e(A)}\pi_A(dy)
\le\tau^{-1}\pi_A(dy).\tag{7}
\]

零行无费用，可任意补定义条件概率。聚合两方向的高端旧来源边缘因而≤τ^{-1}f(y)D_i(y)dy。该结论仅针对对应 stage 高端费用，不是声称全 Γ_i 具有此密度界。

更重要的是，保新来源后得到实际双来源正上包络

\[
\tau^{-1}\sigma(dA)s_i^e(A)\pi_A(dy)\pi_A(dz)b_i(z).
\tag{8}
\]

它来自原旧来源 disintegration，并非无损刷新 π_A。(8)首先是来源投影的支配，不是仍带另一端点和时钟的实际 joint 等式。若需显式保留其他旧标签 ζ，在 a_i^e(A,y)>0 处使用原 Γ_i 的条件概率核 \(\mathcal K_i^e(A,y,d\zeta)\)；在 a_i^e=0 处实际费用为零，令该核为零 subkernel。把同一条件核乘在(8)上仍是正支配；没有在零行任意填入历史。实际费用的定义始终保留标签，上界证明才积分掉条件总质量≤1的部分。high 条件本身也只在上界中放松。不能把已经加 high 门的 endpoint 密度当作(2)的单调密度。

## 3. 第二步：旧来源低当前占用的累计一次价格

使用未重算的原密度定义

\[
M_i(dy,dz)=\sum_{e=u,v}\int\sigma(dA)s_i^e(A)
 \pi_A(dy)\pi_A(dz).\tag{9}
\]

这是证明上界使用的共同来源核，不是另一个原历史流。它对称、非负，且 M_{i+1}≤M_i，因为各 s_i^e 递减，所有 π_A 固定。完整匹配给精确边缘

\[
M_i(dy,\mathbb R^n)=f(y)D_i(y)dy.\tag{10}
\]

特别没有遗漏两方向的因子：两方向已经包含于 D_i 中。

由(8)，第二支的全部实际费用至多

\[
\frac1\tau\sum_i\int M_i(dy,dz)b_i(z)1_{D_i(y)\le d_0}.
\tag{11}
\]

**共同停止估计。**固定旧来源 y，定义可测的首个阶段

\[
j(y)=\inf\{i\ge1:D_i(y)\le d_0\},\qquad \inf\varnothing=\infty.
\tag{12}
\]

索引起点与 b_i 的实际编号一致；若编号从0开始，仅将下限同时改为0。D_i 随 i 递减，故有限 j 之后恰是该旧来源的低占用后缀。j 是事后对正积分分组，不是新的原历史停止资格。

为明确可测性和点态比较，取 M_i 的共同核密度

\[
M_i(dy,dz)=f(y)f(z)K_i(y,z)dy dz,\quad
K_i(y,z)=\int\sigma(dA)s_i(A)c_A(y)c_A(z)/m_A^2.
\]

可取所有 i 一致的非负可测版本，K_i 逐点递减；Tonelli 给其 y 边缘(10)。于是对 j(y)<∞，

\[
\sum_{i\ge j(y)}K_i(y,z)b_i(z)
\le K_{j(y)}(y,z)\sum_{i\ge j(y)}b_i(z)
\le K_{j(y)}(y,z).\tag{13}
\]

j(y)=∞ 时左边为零，不调用一个不存在的 K_∞。乘 f(y)f(z) 后积分 z，使用(10)，再按可测集合 {j(y)=j} 相加，得

\[
\begin{split}
\sum_i\int M_i(dy,dz)b_i(z)1_{D_i(y)\le d_0}
&\le\sum_{j\ge1}\int_{\{j(y)=j\}} f(y)D_j(y)dy\\
&\le d_0W.
\end{split}\tag{14}
\]

这是全部阶段合计的 d₀W，绝不是每阶段一个 d₀W。对有限阶段只使用有限求和，未进入低占用的来源不产生该支；原尚存边终端费用不在(14)中被删除。对实际已清空的无限母式，通过非负单调收敛延拓；若仍在有限终端合同，原终端项原样保留。f=0 的来源不贡献任何项。

(11)与(14)证明第二支≤d₀W/τ，连同(5)证明(4)。所有几何、early、soft、相对秩和路径门都能保在原支中：证明只是对该实际正支作上包络，没有让新来源继承旧历史。

取 d₀=s 后，新补集除 R412 和相对门外还有

\[
s_i^e(A)>\tau B_e,\qquad D_i(y)>s,\qquad D_i(z)>s.
\tag{15}
\]

最后一项由原 b_i(z)>0 自动给出；前两项是本轮已付支的真实补集。原 y 的相对完整秩高并不自动等于 D_i(y)>s，因此(14)不是旧 global-J 低秩付款的改名。

## 4. 完整费用与占用层 P 的剩余缺口

在 R412 冻结账后，把相对门、高阶段边缘、旧当前占用高依次保留，将最终余项记为 R413。取 d₀=s，有

\[
R412\le R413+(\eta_{\rm rel}+\tau S)X_q+(s/\tau)W.
\tag{16}
\]

相对门的费用引用主/辅助已审收据；本稿新项仅为 τS 与 s/τ。主稿把相对门和 stage 门前置于 R408，再使用同一 411/412 核，得到同一最终正限制，但可用改进的相对列常数重拆旧停止支，来源价格与下面的末端账不同。以下仅保留旧价格作较松上界，不能与主稿的替代价格相加。

令 C_end=C412+η_rel+τS，V_end=V412+s/τ，原 F_δ=(1−32δ)^{-1} 不变。这里 V412 包含旧 P_low、P_inner；这是本附件展示的较松末端账。主稿采用前置门后重新拆分的替代价 V413=V406+P_low_rel+P_inner_rel+s/τ，两账不得相加。n≥9 的末端母式为

\[
G_0\le16F_\delta R413+16F_\delta C_{\rm end}X_q+16F_\delta V_{\rm end}W,
\]

\[
B_H\le32F_\delta R413+[E387+32F_\delta C_{\rm end}]X_q
 +[S390+8s+32F_\delta V_{\rm end}]W.\tag{17}
\]

本稿两项新付款在原入口的增量分别是 64ΛF_δτS X_q 与 64ΛF_δ(s/τ)W，Λ=128/119。旧 E387、S390、8s 和原入口 H、A_{entrance,n} 不另乘系数；低维全槽替换继续保留。τ 可为固定小参数或按剩余 X 余额选择，来源损失是明确的 τ^{-1}。不宣称全部 X 吸收余额已核完。

对最终剩余仍按原新来源 D_i(z) 分层：I_k=1_{2^ks<D_i(z)≤2^{k+1}s}。当前粗费用上界仍为 2^{k+1}sW。高端桥(8)现在合法，但直接积分旧 y 只恢复 f(z)D_i(z)，不能删除 2^k。新(14)支付了旧 y 先进入低占用的全后缀；余项两份来源在费用发生时都当前高占用。尚需把同一实际 low-common/far/relative-rank、双 child-collar 和终端外侧几何，与这个双 current-high 来源核联合结算，证明层一致的 tX_q+Ct^{-p}sW。**这一行仍未证明。**不能从有限质量下降深度、一个无标记完整能量或新的条件律上包络自动得到它。

## 5. 正信息检查的保留范围

此前检查的正信息仍正确，但不再作为主结果。令

\[
E_i^e(A)=\int\pi_A(dy)a_i^e(A,y)
 \log_+[a_i^e(A,y)/s_i^e(A)].
\]

零行取零，则 E_i^e≤s_i^e log(B_e/s_i^e)≤B_e/e。将原实际费用乘该非负对数后，才能正删除耦合门；以同 z 的 Σ_i b_i≤1 得全部阶段和层的正信息≤SX_q/e。这里用的是 log_+，不是把截断后可能带负号的有符号 KL 当成非负费用。该信息量并不下界原费用，本轮(5)、(14)不使用它，也不另入账。

## 6. 实际三阶段检查及新增付款核验

实际执行 `/tmp/r413_geometry_check.py`，stdout 为 `/tmp/r413_geometry_check.stdout`：

```
Stage 1 PASS: 36 conditional-density and positive-information interval models
Stage 2 PASS: 24 nested finite full-source matching graphs with actual D_i and b_i
Stage 3 PASS: 50 nonempty dyadic occupancy-layer information records; exact sum preserved
Additional PASS: 36 stage-marginal/first-source-stopping models; 1 positive actual dynamic-low costs
Scope: finite density/information diagnostics only; not native-du/history samples or a proof of P.
```

前三阶段分别核条件密度与正信息有理区间、嵌套原边的实际 D_i/b_i、同一费用的 dyadic 分层，未把它们当作 P。新增36个 Fraction 模型核(5)、(6)、M_i 单调、精确边缘(10)、首低后缀比较(13)、合计(14)与两步正分支。它们来自三个 side-4 区间的有限 receiver quadrature：五个来源 cell 各完整质量1，三个接收者各质量3、q=3/4；Γ 保共同旧来源与实际 endpoint 嵌套限制。一个参数模型出现严格正的 high-marginal 后 dynamic-old-low 费用，其余模型也按原算式核验。初次参数网格的该支全零，随后加入更小 τ=1/20 才得到正费用；没有将空分支样本冒充正覆盖证据。

这些是有限 quadrature/来源 cell 代数模型，不是原连续 du、far/rank/history 全合同实例。一般收据依靠(5)和(9)–(14)的正测度证明；数值仅核所声明的局部代数。按有界任务停止，不再扩展下一步高占用路线。
