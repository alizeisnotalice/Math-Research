#!/usr/bin/env python3
"""Exact finite diagnostics for R413 density and weighted information only."""
from fractions import Fraction as F
from math import factorial

def log_bounds(x, N=40):
    assert x>=1
    k=0
    while x>=2:
        x/=2; k+=1
    def core(v):
        t=(v-1)/(v+1)
        low=2*sum((t**(2*j+1)/F(2*j+1) for j in range(N)),F(0))
        return low,low+2*t**(2*N+1)/(F(2*N+1)*(1-t*t))
    l,u=core(x); l2,u2=core(F(2))
    return l+k*l2,u+k*u2

e_low=sum((F(1,factorial(j)) for j in range(42)),F(0))
e_high=e_low+F(1,factorial(42))/(1-F(1,43))

def row(pi,a,B):
    assert sum(pi)==1 and all(0<=x<=B for x in a)
    s=sum((p*x for p,x in zip(pi,a)),F(0))
    if s==0:
        assert all(x==0 for p,x in zip(pi,a) if p>0)
        return s,F(0),F(0)
    eta=[p*x/s for p,x in zip(pi,a)]
    assert sum(eta)==1
    pl=pu=F(0)
    for p,x in zip(pi,a):
        if x>s:
            l,u=log_bounds(x/s)
            pl+=p*x*l; pu+=p*x*u
        if x>0:
            assert x/s<=B/s
    _,u=log_bounds(B/s)
    assert pl<=s*u
    # This is a genuine interval certificate below the analytic universal B/e.
    assert pu<=B/e_high
    return s,pl,pu

def basic_rows():
    count=0
    pis=[[F(1,2),F(1,3),F(1,6)],[F(1,3)]*3]
    vectors=[[F(0)]*3,[F(1)]*3,[F(1),F(0),F(0)],
             [F(1),F(1,2),F(0)],[F(1,8),F(3,8),F(7,8)],
             [F(0),F(1),F(1)]]
    for pi in pis:
        for v in vectors:
            for B in [F(1,4),F(1),F(7,3)]:
                row(pi,[B*x for x in v],B);count+=1
    return count

def graphs():
    whole_count=layer_count=0
    c=[[1,1,0,0],[0,1,1,0],[0,0,1,1]]
    pi=[[F(x,2) for x in cr] for cr in c]
    endpoint_sets=[{0,1,2},{0,1},{0,1},{1}]
    for seed in range(1,5):
        for fs in [F(1),F(3)]:
            f=[fs*F(2**j) for j in range(4)]
            # Each source cell has measure 1/f_j: source mass exactly 1.
            assert sum(f[j]/f[j] for j in range(4))==4
            # Every receiver captures mass 2, side 2, density q=1.
            for cr in c: assert sum(cr)==2
            gamma=[]
            for u in range(3):
                for v in range(3):
                    if u!=v:
                        for y in range(4):
                            if c[u][y] and c[v][y]:
                                gamma.append((u,v,y,F(seed,100*(u+v+1))))
            for floor in [F(1,1000),F(1,100),F(1,50)]:
                T=[F(0),fs/4,fs/2,fs,2*fs]
                bsum=[F(0)]*4
                total_info=F(0); layer_info={}
                for i,A in enumerate(endpoint_sets):
                    g=[e for e in gamma if e[0] in A and e[1] in A]
                    D=[sum((v*(F(c[u][z],2)+F(c[w][z],2))
                            for u,w,y,v in g),F(0)) for z in range(4)]
                    b=[(min(f[z],T[i+1])-min(f[z],T[i]))/f[z]
                       *max(F(0),1-floor/D[z]) if D[z]>0 else F(0)
                       for z in range(4)]
                    bsum=[x+y for x,y in zip(bsum,b)]
                    for direction in [0,1]:
                        for u in range(3):
                            a=[]
                            for y in range(4):
                                gy=sum((v for x,w,yy,v in g
                                        if yy==y and (x if direction==0 else w)==u),F(0))
                                a.append(gy/pi[u][y] if pi[u][y] else F(0))
                            s,_,info=row(pi[u],a,F(1))
                            edge_marginal=sum((v for x,w,yy,v in g
                                               if (x if direction==0 else w)==u),F(0))
                            assert s==edge_marginal
                            for z in range(4):
                                weight=pi[u][z]*b[z]
                                total_info+=weight*info
                                if b[z]>0:
                                    assert D[z]>floor
                                    k=0
                                    while D[z]>2**(k+1)*floor:k+=1
                                    assert 2**k*floor<D[z]<=2**(k+1)*floor
                                    layer_info[k]=layer_info.get(k,F(0))+weight*info
                assert all(x<=1 for x in bsum)
                assert sum(layer_info.values(),F(0))==total_info
                # S=1+1, X_q=3, hence the exact universal price is 6/e.
                assert total_info<=F(6)/e_high
                whole_count+=1
                for value in layer_info.values():
                    assert value<=total_info
                    layer_count+=1
    return whole_count,layer_count

def stage_gate_and_stopping():
    # Actual finite incidence from intervals centered 0,1,2 with side 4;
    # five source cells at -1.5,-.5,1,2.5,3.5 each have full mass 1.
    c=[[1,1,1,0,0],[0,1,1,1,0],[0,0,1,1,1]]
    pi=[[F(x,3) for x in cr] for cr in c]
    sigma=F(3,4); X=3*sigma; W=F(5); B=F(1,8)
    count=positive=0
    for seed in range(1,5):
        # Only pair-exclusive old sources carry flow; middle source is new too.
        gamma=[(0,1,1,F(seed,200)),(1,0,1,F(seed,200)),
               (1,2,3,F(seed,400)),(2,1,3,F(seed,400))]
        for floor in [F(1,1000),F(1,100),F(1,60)]:
            f=[F(2**j) for j in range(5)]
            T=[F(0),F(1,4),F(1,2),F(1),F(2)]
            records=[]; bsum=[F(0)]*5
            for i,A in enumerate([{0,1,2},{0,1,2},{0,1},set()]):
                g=[e for e in gamma if e[0] in A and e[1] in A]
                D=[sum((weight*F(c[u][z]+c[v][z],3)
                        for u,v,y,weight in g),F(0)) for z in range(5)]
                b=[(min(f[z],T[i+1])-min(f[z],T[i]))/f[z]
                   *max(F(0),1-floor/D[z]) if D[z]>0 else F(0)
                   for z in range(5)]
                bsum=[x+y for x,y in zip(bsum,b)]
                degrees={}; densities={}
                for e in [0,1]:
                    for A in range(3):
                        ss=sum((weight for u,v,y,weight in g
                                if (u if e==0 else v)==A),F(0))/sigma
                        degrees[e,A]=ss
                        densities[e,A]=[
                            sum((weight for u,v,yy,weight in g
                                 if yy==y and (u if e==0 else v)==A),F(0))
                            /(sigma*pi[A][y]) if pi[A][y] else F(0)
                            for y in range(5)]
                        assert max(densities[e,A])<=B
                M=[[sum((sigma*ss*pi[A][y]*pi[A][z]
                         for (e,A),ss in degrees.items()),F(0))
                    for z in range(5)] for y in range(5)]
                assert [sum(mr,F(0)) for mr in M]==D
                records.append((g,D,b,degrees,densities,M))
            assert max(bsum)<=1
            for prev,nxt in zip(records,records[1:]):
                assert all(nxt[5][y][z]<=prev[5][y][z]
                           for y in range(5) for z in range(5))
            for tau in [F(1,20),F(1,4),F(1,2)]:
                low=dynamic=F(0)
                for i,(g,D,b,deg,den,M) in enumerate(records):
                    for u,v,y,weight in g:
                        for e,A in [(0,u),(1,v)]:
                            ss=deg[e,A]
                            for z in range(5):
                                mask=F(1+(i+y+2*z)%3,3)
                                cost=weight*pi[A][z]*b[z]*mask
                                if ss<=tau*B:low+=cost
                                else:
                                    assert den[e,A][y]<=ss/tau
                                    if D[y]<=floor:dynamic+=cost
                assert low<=tau*(2*B)*X
                # Sourcewise first low-occupation stage: no per-stage W fee.
                stopped=F(0); kernel_cost=F(0)
                for y in range(5):
                    j=next((i for i,r in enumerate(records) if r[1][y]<=floor),None)
                    if j is not None:
                        stopped+=records[j][1][y]
                        for z in range(5):
                            val=sum((r[5][y][z]*r[2][z] for r in records[j:]),F(0))
                            assert val<=records[j][5][y][z]
                            kernel_cost+=val
                assert kernel_cost<=stopped<=floor*W
                assert dynamic<=kernel_cost/tau<=floor*W/tau
                positive+=int(dynamic>0)
                count+=1
    return count,positive

if __name__=='__main__':
    a=basic_rows();b,cnt=graphs()
    print('Stage 1 PASS:',a,'conditional-density and positive-information interval models')
    print('Stage 2 PASS:',b,'nested finite full-source matching graphs with actual D_i and b_i')
    print('Stage 3 PASS:',cnt,'nonempty dyadic occupancy-layer information records; exact sum preserved')
    d,pos=stage_gate_and_stopping()
    print('Additional PASS:',d,'stage-marginal/first-source-stopping models;',pos,'positive actual dynamic-low costs')
    print('Scope: finite density/information diagnostics only; not native-du/history samples or a proof of P.')
