# R412：真实小接收立方体内缩来源的联合付款

2026-10-20。**本轮得到 R411 实际双见证余项的一个一般、完整正分支付款，没有证明整个余项的根阶预算。**付款后，两份原来源分别被限制在各自真实小立方体的相对宽度约为 log(n+2)/n 的外圈。这里控制的是接收中心积分；不由外圈体积推断任意集中 f 的来源质量，不声称支付固定比例。

## 1. 冻结输入与准确命题

使用 R411 最终合同，不改变接收场或计划。完整 f≥0 属于 L¹，W=∫f；E 是实际 Lebesgue 接收中心集合，边长 a≤R_A≤b≤2a，m_A=f(Q_A)=q_AR_A^n，0<q_-≤q_A≤λ。记

\[
\mu(dA)=dA/m_A,\quad \sigma(dA)=q_A dA,\quad
\pi_A(dx)=f(x)c_A(x)dx/m_A,\quad X_q=\int_E\sigma,
\]

\[
A_n=1+n\log(b/a),\quad K=e^{\sqrt n},\quad s=1+\sqrt n,
\quad h=s/(\varepsilon_0q_-),\quad 0<\varepsilon_0\le1/2,\quad L\ge4.
\]

A_n 是当前占用包络常数，不是原入口的 A_{entrance,n}。后者保持原定义。

保留原带标签费用 Θ：原 Γ、旧来源 y、新来源 z、父 A=u 或 v、阶段 b_i(z)、R408 early 正分数、soft 因子 (1−C_A(y,z)/h)_+、物理时钟及全部原秩、空间和历史门均在 Θ 中。定义

\[
Z_A(x)=\int c_w(x)1_{m_w<m_A/K}\mu(dw),\quad
C_A(y,z)=\int c_w(y)c_w(z)1_{m_w<m_A/K}\mu(dw).
\]

R411 已构造的实际条件概率核为

\[
P_y(dw)=\frac{c_w(y)(1-c_w(z))1_{m_w<m_A/K}}
 {Z_A(y)-C_A(y,z)}\mu(dw),\qquad
P_z(dt)=\frac{c_t(z)(1-c_t(y))1_{m_t<m_A/K}}
 {Z_A(z)-C_A(y,z)}\mu(dt). \tag{1}
\]

分母在实际正费用支严格为正。令

\[
d\mathcal R_{411}=d\Theta P_y(dw)P_z(dt)
1_{w,t\notin Q_A}1_{Z_w(y)>h}1_{Z_t(z)>h}. \tag{2}
\]

这里 w,t 表示真实中心，Z_w,Z_t 均来自同一个完整原场。(2)不在限制后重新归一化，其总量为原 R411。所有原双范数来源 far 条件及 old/new 标签仍保留。新 w,t 未被授予任何下一步历史资格。

令 Λ_y、Λ_z 是 R411 完整双 lift 分别推到 (w,y)、(t,z) 的**整份**单边测度。已审 R411 列界及其正限制给

\[
d\Lambda_x(w,x)\le C_x^*\,\sigma(dw)\pi_w(dx),\qquad x=y,z, \tag{3}
\]

\[
\begin{split}
J_{\max}&=A_n/q_-,\quad B_0=(1+\log K)/q_-=\varepsilon_0h,\\
a_y&=(2-\varepsilon_0)h,\quad a_z=(L-\varepsilon_0)h,\\
c_y&=2/(1-\varepsilon_0),\quad c_z=L/(L-\varepsilon_0-1),\\
C_x^*&=\frac{S\lambda}{q_-}c_x\log_+(J_{\max}/a_x),
\qquad S=\beta+C_{\rm col}.
\end{split} \tag{4}
\]

这些是已证明的列支配，不是目标分布等于完整 π_w 的断言。R411 的证明保留了旧来源通道中 b_i 仍在新来源 z，随后用同一 z 上 Σ_i b_i(z)≤1；本轮直接用该已审结论，不重建或重复支付阶段费用。

**准确新命题。**对任意预先固定的 0<α≤1，令 αQ_w 表示关于真实中心 w 内缩、边长 αR_w 的闭立方体。在同一 (2) 上取整份 union

\[
R_{\rm inner}=\mathcal R_{411}
 [\,y\in\alpha Q_w\ \text{或}\ z\in\alpha Q_t\,],\qquad
R_{\rm collar}=\mathcal R_{411}
 [\,y\notin\alpha Q_w,\ z\notin\alpha Q_t\,]. \tag{5}
\]

则 R411=R_inner+R_collar 是精确正分解，且

\[
\boxed{R_{\rm inner}\le P_{\rm inner}(\alpha)W,\qquad
P_{\rm inner}(\alpha)=(C_y^*+C_z^*)\frac{\lambda}{q_-}\alpha^n A_n.} \tag{6}
\]

这是实际全部父、全部阶段和两端共同收费后的来源线性价格。它不以来源密度帽、有限小立方体数或新见证历史为假设。

## 2. 可变半径的 native 中心容量，含基底项

对每个固定来源 x 及任意可测选择器 R_w∈[a,b]，有

\[
\boxed{\int_E\frac{1_{x\in\alpha Q_w}}{m_w}\,dw
\le\frac{\alpha^n}{q_-}\,[1+n\log(b/a)].} \tag{7}
\]

**证明。**置 r(w)=2\|w−x\|_∞。真实包含关系是 r(w)≤αR_w，而匹配给 m_w≥q_-R_w^n。因此逐中心

\[
\frac{1_{x\in\alpha Q_w}}{m_w}
\le\frac1{q_-}\frac{1_{r(w)\le\alpha b}}
 {\max(a,r(w)/\alpha)^n}. \tag{8}
\]

右侧是对实际选择器的点态包络，不是把 R_w 当作一个独立可积分变量。包络的合法 layer-cake 为

\[
\frac{1_{r\le\alpha b}}{\max(a,r/\alpha)^n}
=b^{-n}1_{r\le\alpha b}
 +\int_a^b n t^{-n-1}1_{r\le\alpha t}\,dt. \tag{9}
\]

在 r≤αa 上，右边为 a^{-n}；在 αa<r≤αb 上为 (r/α)^{-n}；r>αb 时为零。端点 r=αa、αb 均正确。式(9)包含终端 b 的 layer-cake 原子；将实际中心积分分为内基底和外壳时，等价地得到下述不能省略的基底贡献 α^n：

\[
\begin{split}
\int_{\mathbb R^n}\frac{1_{r(w)\le\alpha b}}
 {\max(a,r(w)/\alpha)^n}\,dw
&=a^{-n}|Q_{\alpha a}|+
\int_{\alpha a}^{\alpha b}\frac{n r^{n-1}}{(r/\alpha)^n}\,dr\\
&=\alpha^n+n\alpha^n\log(b/a).
\end{split} \tag{10}
\]

也可直接对(9)作正序 Tonelli，用 |Q_{αt}|=α^nt^n 得同式。扩大 E 到全空间只增加非负积分。(8)–(10)证明(7)。特别 b=a 时壳积分为零，但(7)右侧仍是 α^n/q_-，不能只保留对数壳。任意维数 n≥1、任意选择器的非单调半径场均允许；不要求各半径层是实际独立接收族。

此证明也给较精确的

\[
\int_E 1_{x\in\alpha Q_w}R_w^{-n}\,dw\le\alpha^nA_n. \tag{11}
\]

原生中心变量始终是 dw；未把来源质量 f(dx) 替换成空间体积。

## 3. 同一个双 lift 上的 union 付款及根阶选择

由(3)，先对两个整份单边列分别上界，再使用(7)，

\[
\begin{split}
R_{\rm inner}
&\le C_y^*\int\sigma(dw)\pi_w(dy)1_{y\in\alpha Q_w}
 +C_z^*\int\sigma(dt)\pi_t(dz)1_{z\in\alpha Q_t}\\
&\le(C_y^*+C_z^*)\lambda\int f(x)dx
   \int_E1_{x\in\alpha Q_w}\mu(dw)\\
&\le(C_y^*+C_z^*)\frac{\lambda}{q_-}\alpha^n A_n W.
\end{split} \tag{12}
\]

这证明(6)。实际交集在(5)只删除一次；union 上界允许两个边际同时计入交集，所以不需要重建条件核或对残余重新归一化。此处用整份列界，没有混入 R411 可选半分方案。

完整匹配还使 σ(dw)π_w(dx)=f(x)c_w(x)R_w^{-n}dw dx，故(11)实际上可把(6)中的 λ/q_- 去掉。本稿主账保留(6)的安全价格；两个版本是替代界，不能相加收费。

固定

\[
\alpha=\alpha_n=(n+2)^{-1/(2n)},\qquad
\alpha_n^n=(n+2)^{-1/2}. \tag{13}
\]

则所有维数上的主价为

\[
P_{\rm inner}=(C_y^*+C_z^*)\frac{\lambda}{q_-}
 \frac{1+n\log(b/a)}{\sqrt{n+2}}. \tag{14}
\]

对于 octave，A_n≤1+nlog2≤n+2；又 c_y≤4、c_z≤8/5，并且 Jmax/a_x≤A_n（因为 a_y≥3h/2、a_z≥7h/2、ε_0≤1/2、s≥2）。因此可明确写成

\[
\boxed{P_{\rm inner}\le\frac{28}{5}S
 \left(\frac\lambda{q_-}\right)^2
 \sqrt{n+2}\log(n+2).} \tag{15}
\]

当某个对数的参数≤1时，该 C_x^* 为零，按 log_+ 处理；没有借用一个不存在的正秩层。对(15)不需要假设 ε_0 随维数变小；若 S、λ/q_- 随 n 变化则必须保留显示依赖。原应用沿用已经冻结的参数，不重新选择 h 或 L。

## 4. 完整补集和意义边界

由(1)、(2)、(5)，R_collar 的正支同时满足

\[
\begin{gathered}
w,t\notin Q_A,\qquad m_w,m_t<m_A/K,\qquad
Z_w(y)>h,\quad Z_t(z)>h,\\
y\in Q_w\setminus\alpha_n Q_w,\qquad
z\in Q_t\setminus\alpha_n Q_t,\\
y\notin Q_t,\qquad z\notin Q_w.
\end{gathered} \tag{16}
\]

它仍是原 Θ 全部标记上的正限制：old y 和 new z 没有交换；原 b_i、early、soft、双秩、双范数 far、clock 及历史均保留。并没有声称这两份来源属于任意下一步原交通。

设 t_n=log(n+2)/(2n)。由 α_n=e^{-t_n}，

\[
\frac{t_n}{1+t_n}\le1-\alpha_n\le t_n. \tag{17}
\]

故每个 child 外圈的相对全边长差是 1−α_n，单面厚度是 R_child(1−α_n)/2，量级为 log(n+2)/n。**这是关于来源所在几何区域的结论，不是关于该区域 f 质量小的结论。**双外圈内仍允许任意集中的完整来源；目前没有对该补集的共同重用费用给出根阶预算。

本轮付的是原双见证中的 child-source 内缩事件，并非原父 A 的来源内缩事件。旧 R402/403 针对 near 来源的分类已由 R404 账替换；当前 Θ 保留的是 far 来源。R411 的前两支是见证中心在父内及见证自身过去低，都不同于(5)。因而(5)直接作用于 R411 剩余，不另卖旧 parent-inner 付款，也没有假定它占当前余项的固定正比例。

## 5. 原母式唯一回代：不新增 X 价格

沿用 R411 冻结值 F_δ=(1−32δ)^{-1}、0<δ<1/32、C406、V406、Δ_in、P_low。所有此前已付支保持原顺序，唯一替换是

\[
R411\le R_{\rm collar}+P_{\rm inner}W. \tag{18}
\]

在原适用的 n≥9 合同中，

\[
G_0\le16F_\delta R_{\rm collar}
 +16F_\delta(C406+\Delta_{\rm in})X_q
 +16F_\delta(V406+P_{\rm low}+P_{\rm inner})W, \tag{19}
\]

\[
\begin{split}
B_H\le{}&32F_\delta R_{\rm collar}
 +[E387+32F_\delta(C406+\Delta_{\rm in})]X_q\\
&+[S390+8s+32F_\delta(V406+P_{\rm low}+P_{\rm inner})]W.
\end{split} \tag{20}
\]

原入口的新增来源价恰为 **64ΛF_δP_inner W**，余项槽替换成 **64ΛF_δR_collar**，Λ=128/119。没有新 X_q 项，没有再次乘外部旧费用，也不改变旧入口 A_{entrance,n}、H 或其他项。n<9 沿用旧完整低维替换；本轮 native 几何引理本身对 n≥1 成立。旧 X 吸收余额、全尺度与历史等未付事项不会因(18)自动消失。

主稿在此中间余项 R_collar 上另付辅助稿的 terminal-return 正分支 Δ_return X_q，才将其最终补集命名为 R412；该最终补集还保留辅助稿规定的终端双 outside 与 own-low 条件。本文(18)–(20)只记录 inner 付款后的中间账，不冒充该最终 R412，也不在此重复证明或重收 Δ_return。

## 6. 本机三阶段核验与范围

实际执行 `/tmp/r412_geometry_check.py`，stdout 保存为 `/tmp/r412_geometry_check.stdout`：

```
Stage 1 PASS: 576 native center-shell selector models; n=1,2,3,8,16,32; b=a included
Stage 2 PASS: 1936 atomic full-matching union models; 1448 positive paid; 1448 empty complements
Stage 3 PASS: 69 exact dimension/root/log certificates; n=1..64,96,128,256,512,1024
TOTAL model/certificate records: 2581
Scope: diagnostics only. Native theorem is analytic; original history is not certified by finite models.
```

第一阶段用 Fraction 对真实 Lebesgue 中心径向壳作精确积分，半径选择器可非单调；核逐点包络、含终端原子的 layer-cake 反导数、αa 内基底及 b=a 退化情况。壳积分与上界比较使用 atanh 正级数及显式有理余项构造 log 的下界，核的是比浮点上界更强的有理不等式。这些中心模型按 m=qR^n 赋质量，不声称该任意选择器由一个完整 f 实现。

第二阶段为三原子完整来源的有限几何模型：父 side 2、两 child side 1，中心在父外，child 各捕获一份来源而排斥另一份，中央来源补足父质量，使父及两 child 的 q 都为 1。核 union 与完整补集的精确相加、交集仅删一次、两个单边上界、闭内缩边界和双外圈支撑。源是原子而非 L¹ 密度，receiver 是有限模型而非连续 du；这些样本没有认证原时钟、ownpast 或历史门。

第三阶段完全不用浮点求根：有理二分认证 α_n 的 2n 次幂区间，有理 log 区间认证(17)，维度扩大到 1024，并检查 A_n/√(n+2)≤√(n+2) 的 octave 价格包络。记录数不等于理论贡献；一般场证明是(7)–(12)，有限检查不替代它。

本轮成功范围是(6)/(14)的实付一般几何分支及(16)的完整双 child-collar 补集。整个 R_collar 的联合根阶预算仍未证明；没有继续扩树、刷新 child 来源或重复旧平方信用。
