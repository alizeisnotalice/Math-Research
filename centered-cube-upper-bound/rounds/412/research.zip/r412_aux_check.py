from fractions import Fraction as F
from itertools import product
from collections import Counter
C=Counter()
def check(m,r,h,K,label,enumerate_paths=False):
    N=len(m); J=sum(r,F(0)); Z=[sum((r[j] for j in range(N) if m[j]*K<m[i]),F(0)) for i in range(N)]
    T=[sum((r[j] for j in range(N) if m[j]<=m[i]),F(0)) for i in range(N)]
    active=[i for i in range(N) if Z[i]>h]; terminal=[i for i in range(N) if Z[i]<=h]
    B=max((T[i]-Z[i] for i in range(N)),default=F(0)); t0=sum((r[i] for i in terminal),F(0))
    assert t0<=h+B
    if active: assert t0>=h
    Q=[[r[j]/Z[i] if Z[i]>h and m[j]*K<m[i] else F(0) for j in range(N)] for i in range(N)]
    laws={}
    for i in sorted(range(N),key=lambda k:m[k]):
        if i in terminal: laws[i]=[F(int(i==j)) for j in range(N)]
        else:
            laws[i]=[sum((Q[i][k]*laws[k][j] for k in range(N) if Q[i][k]),F(0)) for j in range(N)]
            assert sum(laws[i])==1
            assert all(laws[i][j]<=r[j]/h for j in range(N))
    if enumerate_paths:
        def walk(i):
            if i in terminal: return {i:F(1)}
            out={}
            for j in range(N):
                if Q[i][j]:
                    for k,v in walk(j).items():out[k]=out.get(k,F(0))+Q[i][j]*v
            return out
        for i in active: assert laws[i]==[walk(i).get(j,F(0)) for j in range(N)]
    inp=[r[i]*F((i%3)+1,3) if i in active else F(0) for i in range(N)]
    M=sum(inp); occ=inp[:]
    for i in sorted(active,key=lambda k:m[k],reverse=True):
        for j in range(N):occ[j]+=occ[i]*Q[i][j]
    out=[occ[j] if j in terminal else F(0) for j in range(N)]
    assert out==[sum((inp[i]*laws[i][j] for i in active),F(0)) for j in range(N)]
    assert sum(out)==M
    assert all(out[j]<=M*r[j]/h for j in range(N))
    # Every active row contains the entire bottom rank interval (0,h).
    density=sum((occ[i]/Z[i] for i in active),F(0))
    assert M<=density*t0 and density*h<=M
    before=F(0)
    for i in sorted(range(N),key=lambda k:m[k]):
        if before<h and i in terminal: assert out[i]==density*r[i]
        before+=r[i]
    C[label]+=1
# Stage 1: independent complete path enumeration, exact strict K boundary.
for h in (F(1,4),F(1),F(3,2)):
    for K in (F(1),F(2)):
        check([F(1),F(2),F(4),F(8)],[F(1),F(1,2),F(3,2),F(2)],h,K,'initial',True)
# Stage 2: equal-mass atoms, zero weights, terminal crossing, no-active cases.
for r in ([F(2),F(1),F(3),F(1,2)],[F(0),F(3),F(1),F(2)],[F(1,7)]*4):
    for h in (F(1,10),F(1),F(3),F(20)):
        check([F(1),F(1),F(3),F(9)],r,h,F(3),'atoms',True)
# Stage 3: expanded finite mass/rank cases; exact Green vs full terminal law.
for N in range(3,12):
    for a in (1,2,3):
        for h in (F(1,3),F(2),F(5)):
            check([F(2**(i//2)) for i in range(N)],
                  [F((i*a)%7+1,(i%3)+1) for i in range(N)],h,F(2),'expanded')
# Actual full-f cube source cancellation; finite positive receiver quadrature.
# f=1 on [-4,4]^4, parent Q_2(0); all witness cubes contained in support.
def inter(a,b):
    return product_width(a,b)
def product_width(a,b):
    out=F(1)
    for (lo,hi),(lj,hj) in zip(a,b):out*=max(F(0),min(hi,hj)-max(lo,lj))
    return out
def cube(c,R):return [(x-R/2,x+R/2) for x in c]
parent=cube([F(0)]*4,F(2)); ma=F(16)
for shift in (F(0),F(1,2),F(1)):
    ws=[]
    for c in product((F(-3,2),F(-1,2),F(1,2),F(3,2)),repeat=4):
        cc=(c[0]+shift,)+c[1:]; R=F(1) if sum(x>0 for x in cc)%2 else F(3,2)
        inside=all(abs(x)<=1 for x in cc)
        ws.append((cube(cc,R),R**4,inside,F(1,2)**4))
    # Native source integration is exact; centers are explicitly quadrature.
    val=sum((weight*inter(parent,Q)/mw/ma for Q,mw,inside,weight in ws if inside),F(0))
    centervol=sum((weight for Q,mw,inside,weight in ws if inside),F(0))
    assert val<=centervol/ma and centervol<=ma
    # Two terminal laws dominated by rho/h: union is <= sum, without recoupling.
    for h in (F(1),F(2),F(5)):
        p=min(F(1),val/h); qq=min(F(1),val/(2*h))
        assert p+qq-p*qq<=p+qq<=2/h
        C['matched_cube']+=1
print('PASS',dict(C),'total',sum(C.values()))
print('Fraction throughout. Rank checks are scalar laws, not native-history realizations.')
print('Cube source integrals use full positive L1 f; receiver weights are finite quadrature only.')
