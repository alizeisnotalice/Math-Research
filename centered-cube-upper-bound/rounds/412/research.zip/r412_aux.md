# R412：固定来源严格降质量的总终端核，以及返回原父盒的正分支付款

2026-10-20。**新付款是原 R411 任意正限制中，至少一个最终低秩见证中心返回原父盒的一支**，价格为

\[
\Delta_{\rm return}X_q,\qquad \Delta_{\rm return}=\frac{2S}{q_-h}.
\tag{1}
\]

证明先给整个有限下降链的终端核统一上界 \(\rho_x/h\)，不逐步相乘单步对数列界。无几何限制的全部终端费用仍等于原注入费用；其一般来源价格没有闭合。本文不刷新来源，不将辅助节点授予原历史资格。

## 1. 冻结原场与真正输入

沿用 R411：完整 \(f\ge0\in L^1\)，\(m_A=f(Q_A)=q_AR_A^n\)，\(q_-\le q_A\le\lambda\)，\(a\le R_A\le b\le2a\)，真实中心测度 \(dA\)。记

\[
\mu(dA)=dA/m_A,\quad \sigma(dA)=q_A dA,\quad
\pi_A(dx)=f(x)c_A(x)dx/m_A,\quad X_q=\sigma(E),\quad W=\int f,
\]
\[
K=e^{\sqrt n},\quad A_n=1+n\log(b/a),\quad
h=(1+\sqrt n)/(\varepsilon_0q_-),\quad S=\beta+C_{\rm col}.
\]

固定来源 \(x\)，令

\[
\rho_x(dA)=c_A(x)\mu(dA),\quad J(x)=\rho_x(E)\le A_n/q_-,
\]
\[
T_A(x)=\rho_x\{m_B\le m_A\},\qquad Z_A(x)=\rho_x\{m_B<m_A/K\}.
\tag{2}
\]

已证真实闭质量窗为 \(0\le T_A-Z_A\le B_0=\varepsilon_0h\)。本稿总终端核的证明甚至不需要这个窗帽；它仅用于说明最终低秩集合的来源容量。

输入 \(\mathcal I\) 是 R411 已有同一双 exclusive lift 的**任意不重新归一化正限制**。它保留父 \(A\)、旧边另一端、原来源 \(y,z\)、原见证 \(w,t\)、阶段/首次删除、early 标记、物理时钟/J/H及所有原门；并满足

\[
w,t\notin Q_A,\quad Z_w(y)>h,\quad Z_t(z)>h.
\tag{3}
\]

这里 \(w,t\notin Q_A\) 指中心位置。特别允许先删除主稿的 any-source-interior 见证支，再以剩余作输入。原 \(w\) 捕获 \(y\) 不捕获 \(z\)，\(t\) 反向；这些旧标签一直保留。

积分原辅助见证和其他标签后，R411 的累计容量为

\[
\mathcal I(dA,dy,dz)\le S\,\sigma(dA)\pi_A(dy)\pi_A(dz).
\tag{4}
\]

(4)只作为上界，未用右端替换原流。其来源是原 \(\Gamma_i\) 嵌套、early 标记不超过 \(b_i\)、\(\sum_i b_i(z)\le1\)，先在共同原标签上累计，再用外出 \(\beta\) 与入列 \(C_{\rm col}\)。因此不是逐阶段重复支付。R411 aux (5)及 geometry (1)给出这个累计步骤。

## 2. 同一来源的有限下降链：总 Green 核

对捕获 \(x\) 且 \(Z_A(x)>h\) 的真实接收者定义

\[
Q_x(A,dB)=\frac{1_{m_B<m_A/K}\rho_x(dB)}{Z_A(x)}.
\tag{5}
\]

在 \(Z_A(x)\le h\) 停止，不在零分母上定义跳转。每一步仍是原实际接收者且严格质量降 \(K\)。令

\[
m_-=q_-a^n,\quad m_+=\lambda b^n,\quad
N=1+\left\lfloor\frac{\log(m_+/m_-)}{\log K}\right\rfloor.
\]

长度 \(N\) 的连续下降不可能，故无需无限时终端假设。设 \(H_x=\{Z_A(x)>h\}\)、\(B_x=H_x^c\)，分解 (5) 为 \(Q_{x,H}\)、\(Q_{x,B}\)。从 active 起点出发的总终端概率核精确为

\[
L_x=\sum_{j=0}^{N-1}Q_{x,H}^{\,j}Q_{x,B},\qquad L_x1=1.
\tag{6}
\]

总 occupation 核 \(\sum_{j=0}^{N-1}Q_{x,H}^{j}\) 不是概率核；本文没有把它的行和当成1。核、终端集和有限复合均共同可测，不需要选取最优路径。所有原标签只作为旁带标签，来源 \(x\) 从不改变。

**原子安全总终端定理：** 对任意 active 起点和可测接收集合 \(D\)，

\[
L_x(A,D)\le\frac{\rho_x(D\cap B_x)}h.
\tag{7}
\]

证明：质量排序下 \(Z_A\) 非降，因此 \(B_x\) 是初始质量段。记 \(t_0=\rho_x(B_x)\)。若存在 active 起点，则 \(t_0\ge h\)。严谨的原子表达是将每个质量原子摊成秩区间 \([T(m-),T(m)]\)；对区间中的秩 \(r\)，严格过去满足 \(Z(m)\le T(m-)\le r\)。所以底部秩 \([0,h]\) 均属终端段。这个摊开只用于证明，实际核 (5) 在同质量原子中仍按原 \(\rho_x\) 分配。

对剩余可跳次数归纳。设当前下跳前缀质量 \(z=Z_A>h\)。若 \(z\le t_0\)，整个目标前缀已终端，\(L_x(A,D)\le\rho_x(D\cap B_x)/z\le\rho_x(D\cap B_x)/h\)。若 \(z>t_0\)，下跳前缀包含全部终端段，直接终端部分为 \(\rho_x(D\cap B_x)/z\)，继续部分质量为 \((z-t_0)/z\)。归纳上界给

\[
L_x(A,D)\le\rho_x(D\cap B_x)
\left[\frac1z+\frac{z-t_0}{zh}\right]\le\frac{\rho_x(D\cap B_x)}h.
\]

有限下降使归纳结束。严格 \(m_B<m_A/K\)、\(Z=h\) 停止、跨过阈值的完整质量原子全部被保留。若 \(H_x\) 为空，则没有本稿 active 输入。

## 3. 总列放大与未自动产生的来源付款

设真实某一方向输入按来源分解为 \(f(x)dx\,I_x(dA)\)，只在 \(H_x\)，\(M(x)=I_x(E)\)。由 (6)–(7)，

\[
I_xL_x\le\frac{M(x)}h\rho_x|_{B_x},\qquad
(I_xL_x)(E)=M(x).
\tag{8}
\]

所以没有单步 \(\log n\) 乘上链深的损失。若仅使用 R411 的列界 \(I_x\le C_xq_A\rho_x\)，则相对 \(\sigma(dA)\pi_A(dx)=f(x)q_A\rho_x(dA)dx\) 的总终端放大至多 \(C_x(\lambda/q_-)J(x)/h\)。更好的是直接保原父总量：由 (4)，每一方向

\[
M(x)\le S\int q_A\rho_x(dA)\le S\lambda J(x),
\tag{9}
\]

省掉先使用 \(C_x\) 所带的对数。两方向各保整份输入会有两份质量；若作守恒单边分配应各乘 \(1/2\)，不能遗漏此区别。

闭窗还给 \(\rho_x(B_x)\le h+B_0\)，因为 \(B_x\subset\{T_A\le h+B_0\}\) 且闭 CDF 初始段质量不超过阈值。但 (8) 的终端密度中仍有 \(M(x)/h\)，不能以低终端秩直接重新套 R411 单步低秩价格。无几何条件时 (9) 仅给量级 \(S\lambda A_nW/q_-\)，而终端总费用精确保留 \(\int fM\)。这没有证明一般根阶价格。

总 Green 的放大量也可精确定位。令 \(O_x=\sum_{j=0}^{N-1}I_xQ_{x,H}^j\)，并设

\[
c(x)=\int_{H_x}\frac{O_x(dA)}{Z_A(x)}.
\]

最终密度相对 \(\rho_x\) 在整个底部秩区间 \([0,h]\) 等于 \(c(x)\)，在其余终端段不超过 \(c(x)\)：每个 active 前缀均包含底部 \(h\)。因此

\[
\frac{M(x)}{h+B_0}\le\frac{M(x)}{t_0}\le c(x)\le\frac{M(x)}h.
\tag{10}
\]

(10) 的含 t_0 分母写法限 M(x)>0；若 M(x)=0，则 O_x=0、c(x)=0，直接用零测度结论，不作 0/0 运算。

这是原核的真实终端放大公式，不是声称原输入必须饱和 \(M\simeq J\)。它说明仅靠固定来源降质量、有限深度与低终端秩，不能把到达密度免费恢复成原 \(q\rho_x\)。需要使用原注入或父几何；下面实际使用后者。

## 4. 返回原父盒：原费用的新正分支

在每个 \(\mathcal I\) 的完整标签上，分别从 \(w\) 以同一 \(y\) 和从 \(t\) 以同一 \(z\) 运行 (5)，取条件产品路径 law。记最终接收者为 \(b,d\)。这只是给原费用增加概率标签，总质量不变；不把更新后的节点作为原 \(\Theta\) 的新合格入口。

在这一个固定的联合路径 lift 上定义

\[
P_{\rm return}=\widehat{\mathcal I}\{b\in Q_A\ \text{或}\ d\in Q_A\},
\quad
R_{\rm endout}=\widehat{\mathcal I}\{b\notin Q_A,\ d\notin Q_A\}.
\tag{11}
\]

故 \(|\mathcal I|=P_{\rm return}+R_{\rm endout}\) 精确。联合 union 概率为 \(p+q-pq\)，上界只用 \(p+q\)。由 (7)，不论初始 \(w,t\) 具体位置，

\[
p\le\frac1h\int_{b\in Q_A}c_b(y)\mu(db),\qquad
q\le\frac1h\int_{d\in Q_A}c_d(z)\mu(dd).
\]

在此去掉 terminal 低秩标记只是正上界。一次使用 (4)，再用完整来源匹配而不是密度帽：

\[
\int\pi_A(dx)\int_{b\in Q_A}c_b(x)\mu(db)
=\frac1{m_A}\int_{b\in Q_A}\frac{f(Q_A\cap Q_b)}{m_b}\,db
\le\frac{|Q_A|}{m_A}=\frac1{q_A}.
\tag{12}
\]

这里中心集合是实际 \(E\cap Q_A\)，其体积不超过 \(|Q_A|\)。由此

\[
P_{\rm return}\le\frac{2S}{h}\int\frac{\sigma(dA)}{q_A}
=\frac{2S|E|}{h}\le\frac{2S}{q_-h}X_q.
\tag{13}
\]

两原来源方向均已计入，阶段只累计一次，全部旧物理/历史标记只在上界中正删除。初始见证已在父外，所以此事件不同于 R411 已付的“初始见证中心在父内”。其几何消去步骤与旧 inside 收据同源，但 (7) 是使其可以用于整个合法固定来源路径的新总核控制。

若 \(\mathcal I\) 取主稿先删除 any-source-interior 后的余流，(11) 的最终余项同时保留初始 \(w,t\) 双 outside、双 own-high、来源双 collar，以及原 far/early/clock/history；最终 \(b,d\) 双 outside 且各自 own-rank≤h。中间节点可能进出父盒，也可能捕获另一来源；本文不宣称这些性质沿途保留。所有原来源 \(y,z\) 固定不刷新。

原 R411 槽的价格是 \(64\Lambda F_{\rm late}\)。因此本收据若插回该槽，入口只增加

\[
64\Lambda F_{\rm late}\Delta_{\rm return}X_q,
\]

并把相应余流换为 \(R_{\rm endout}\)；先行的 interior 来源费留一次。参数 \(\varepsilon_0\) 已固定时，\(\Delta_{\rm return}=2S\varepsilon_0/(1+\sqrt n)\)；仍须检查原整体吸收余额。本文没有新增 W 费，不重复扣任何 BH 负平方，也未支付终端仍 outside 的剩余。

## 5. 本机三阶段精确检查与范围

脚本 `/tmp/r412_aux_check.py` 实际输出：

```
PASS {'initial': 6, 'atoms': 12, 'expanded': 81, 'matched_cube': 9} total 108
Fraction throughout. Rank checks are scalar laws, not native-history realizations.
Cube source integrals use full positive L1 f; receiver weights are finite quadrature only.
```

初步6例独立枚举完整路径并与有限 Green 展开比较；原子压力12例含同质量多点、严格 cutoff 等号、零权、跨 h 原子和无 active 场；扩大81例核终端守恒、总密度≤Mρ/h及底部 rank 的精确常密度。另9例以四维完整 \(f=1_{[-4,4]^4}\)、真实父/子 cube、移动接收中心、真实 \(m_b=R_b^4\) 精确核 (12) 及 terminal 支配数值所用的标量 union 上界；未在该 cube fixture 中实际构造 terminal 路径。后者是有限正中心 quadrature，不是原连续单值 selector 或原历史/高秩/指数 far 合同的实现。数值不代替 (6)–(13) 的一般证明。
