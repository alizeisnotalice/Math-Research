# R412 independent audit — FINAL PASS

FINAL PASS for the fixed-source active-start terminal theorem and the two stated positive receipts, including the final full-ledger substitution. These statements were screened independently before reading their R412 author proofs. Final main/readme/proofs and delivered code were read; all2743 delivered Fraction model/certificate records were actually rerun and passed. The final terminal-outside joint remainder is unpaid; no general root-order closure, automatic total absorption or new original-history eligibility is certified. Only this audit file was edited.

## 1. Exact input and once-only order

Use the same complete f, actual du, matched m=qR^n, qband, original clocks/J/H, original old/new sources, stages, first-deletion and early/soft/far/rank/history marks as R411. Its same exclusive double-lift remainder has initial w,t outside parent Q_A, each ownpast>h, each capturing its own source and excluding the opposite source, and strict m_w,m_t<m_A/K. It is not redefined by a σπ_A² envelope.

The precise order is: whole initial source-inner union; on its unrenormalized positive complement extend by the two fixed-source path probability laws; whole FINAL-terminal-center-return union; then the final complement. No stage count is charged, initial constraints remain labels, no intermediate source refresh or new original Γ eligibility occurs. Parent/old-label space is retained. Whole unions have no1/2 price; an optional conservative single-recipient half-split describes a different allocation and is not added here.

The geometry attachment now names its inner-only intermediate residual R_collar. Main's final R412 additionally removes terminal return; these two quantities and their ledgers are no longer conflated. Aux's evidence correction was reviewed: its nine cube records verify source cancellation and scalar union bounds, not actual full terminal-path construction in those cube fixtures.

## 2. Independent initial-inner proof and geometry post-review

For fixed x and0<α≤1, the true-center change w=x+αv contributes exactlyα^n and leaves an actual [a,b]-valued selected-radius field. Equivalently use the pointwise envelope

1_{x∈αQ_w}/m_w≤q_-^−1 1_{r≤αb}/max(a,r/α)^n,
r=2||w−x||∞.

Its center integral is α^n[1+nlog(b/a)]/q_-. The layer-cake atom at b and the inner a-core each remain; b=a gives α^n/q_- rather than zero. Closed containment endpoints are valid. This is a center-volume bound, not a source-density cap or independent-radius integral, and requires no product assumption on f.

Apply the established R411 WHOLE-channel bounds C_y*,C_z* relative to σ(dw)π_w(dx), and q_w≤λ, only after the exact union restriction. This gives

P_inner,actual≤P_inner W,
P_inner=(C_y*+C_z*)λ α^n A_n/q_-.

For α^n=(n+2)^−1/2 this is root-log at dimension-uniform frozen parameters. The explicit28/5 bound in geometry(15) is correct from c_y≤4,c_z≤8/5,A_n≤n+2 and log-positive bounds. Geometry's optional sharper bound withoutλ/q_- follows from σπ=f c/R^n; it is not an extra credit or a second charge. Main consistently uses the displayed safe price.

The positive inner complement puts each ORIGINAL source in its INITIAL child's collar. The bounds t/(1+t)≤1−α≤t, t=log(n+2)/(2n), are correct. Neither thin collar nor its volume implies small f mass. No positive fixed paid proportion is asserted.

## 3. Independent terminal theorem and aux post-review

At fixed source x let ρ_x=c_w(x)dw/m_w, Z(w)=ρ_x{m_b<m_w/K}, B_x={Z≤h}. On active states jump by the strict mass-prefix probabilityρ_x/Z; on B_x stop. Actual positive masses are bounded between q_-a^n andλb^n. Strict factor-K descent therefore gives a uniform finite path length; the delivered finite Green expansion conserves probability. Occupation Green row sums are not asserted to equal1. All kernels, finite compositions and stopping sets are measurable. Zero denominators need no active transition.

The central atom-safe fact is that every active child prefix contains stopped mass≥h. In mass-CDF order B_x is an initial segment containing the bottom h ranks, with the whole crossing atom included. If an active prefix lies entirely in B_x its mass>h already gives domination. Otherwise it contains all B_x of mass t0≥h. Finite-depth induction then bounds the terminal law by

L_x(w,D)≤ρ_x(D∩B_x)/h,  Z_w(x)>h.

The direct-stop coefficient1/Z plus the continuing coefficient(Z−t0)/(Zh) is≤1/h. This retains strict mass cutoffs, equal-mass atoms, Z=h stopping and continuous/singular CDF parts. There is no assumed spectral gap, infinite-time clearing, or artificial cemetery deletion.

The theorem is ONLY for active starts. Arbitrary history-weighted or singular initial measures supported there may be mixed: after writing their source disintegration as f(x)dx I_x(dA), with M(x)=I_x(E), the terminal measure is≤M(x)ρ_x|B/h and has total mass M(x). Initially stopped Dirac laws must be retained separately. The current R411 input has exactly the required own-high support.

Aux's refined total terminal-density coefficient c(x) and bounds M/(h+B0)≤M/t0≤c≤M/h are valid for M>0, with the stated zero-input convention. They follow from constant density on the bottom h rank segment and dominance by c on the entire stopped segment. The original-parent envelope improves M(x)≤SλJ(x), but is not a root W budget. Merely using R411's incoming column gives a J(x)/h amplification, not a new unit column or free π_w restoration. Both proofs/main accurately retain this unpaid congestion.

## 4. Independent terminal-return receipt

On the initial-collar restriction attach L_y(w,db)L_z(t,dd) without normalizing that restriction. The paths preserve their respective original sources. A terminal captures its own source and has ownpast≤h; it need NOT exclude the opposite original source. Intermediate nodes may enter or leave the parent. The paid event concerns FINAL terminal centers inside Q_A, not first hitting or ever visiting the parent.

Terminal masses remain below the initial witnesses and hence<m_A/K. Density domination therefore bounds the conditional whole-return probability by

[Z_in,A(y)+Z_in,A(z)]/h,
Z_in,A(x)=∫_{b center∈Q_A,strictfar}c_b(x)μ(db).

Dropping terminal low or other positive restrictions only enlarges the upper bound. Actual full matching gives E_{π_A}Z_in,A≤|Q_A|/m_A=1/q_A, by I_Ab≤m_b BEFORE center volume. After the existing common-label stage summation, the original two-end capacity Sσπ_A² yields

P_return,actual≤2S|E|/h≤Δ_return X_q,
Δ_return=2S/(q_-h)=2Sε0/(1+√n).

No C_x*, additionalλ, chain-depth factor or stage count is missing. This is disjoint from R411's INITIAL-center-inside receipt because the starting witnesses here remain outside; it does not reuse old negative BH credit. It gives no general price for terminal centers still outside.

## 5. Final report and complete ledger

Main correctly states

R411≤R412+P_inner W+Δ_return X_q,
C412=C406+Δ_in+Δ_return,
V412=V406+P_low+P_inner.

All preceding receipts appear once. For n≥9, R408 feedback remains16Fδ in G0,32Fδ in BH,64ΛFδ at the entrance, with Fδ=(1−32δ)^−1. Thus new increments are exactly64ΛFδΔ_return X_q and64ΛFδP_inner W. External E387/S390/8s/H terms retain their original coefficients; A_entrance,n is distinct from occupancy A_n. The complete old low-dimensional replacement remains an alternative, not an extra high-dimensional term. No H/L/ε field/gate is silently reset, and total absorption is not asserted.

Final R412 preserves initial outside/own-high/exclusive/collar and all original labels, plus full fixed-source paths and terminal outside/own-low. It does not inherit terminal exclusivity or parent historical qualification. The source/target congestion, source-change mechanism, global root budget, old entry/soft/crossing/history/extreme-scale/limit and total absorption/source multiplicity obligations remain open.

Main's newly received410-round-after route advice is explicitly a future candidate: no relative-rank or occupancy-layer estimate is inserted into this bill. This audit checks that scope separation, not the external advice as a proved theorem or a claimed read-history event. Tool/skill mentions are workflow records, not additional mathematical inputs.

## 6. Actual evidence and limits

Reviewer independently executed384 atomic configurations before author reading, checking1144 active terminal rows with exact Fraction arithmetic. They verified finite probability conservation, stopped-prefix capacity and terminal density domination. These are abstract fixed-source atomic measures, not native/history fixtures, and are NOT added to delivered counts.

Read and actually reran the delivered scripts, matching saved stdout:

- parent54 mass-chain models, phases18/18/18,449 active starts;
- aux108 records:6 direct path-enumeration,12 atom/zero/no-active pressure,81 expanded finite Green,9 full-L1 cube-source intersection/scalar-union records with finite receiver quadrature;
- geometry2581 records:576 true center-shell selector integrals,1936 atomic matching/union records,69 rational root/log certificates through n1024.

Total2743 delivered Fraction model/certificate records passed; neither assertion multiplicity nor parent/reviewer reruns is an additional experiment. The native shell selectors are assigned m=qR^n without asserting realization by one common f. Atomic source records are not L1/native-du models. The matched cube source volumes are exact but receiver integration is quadrature and no native terminal paths/history are claimed there. Rational logarithm bounds/root bisection are used as stated; native general proofs remain analytic. Initial K=1 diagnostic rows only test finite strict-order algebra, not the original exponential-K contract.

Read the MATLAB parameter script and its9-row CSV. Its formulas agree with the displayed safe P_inner andΔ_return at the declared fixed parameters. Parent's actual MATLAB execution is ordinary floating-point parameter exploration, not outward-rounded certification, a native core construction, a geometry sample or an asymptotic proof. The zero displayed column is not taken to settle the whole original problem. Reviewer did not claim a new MATLAB execution or add its9 rows to the Fraction count.

## Final byte bindings

- `/tmp/r412_main.md`: `ffcddcbeadfe45481d6fb52ea953c7e35bf24ae2451fa001bae2c17883fe7fef`
- `/tmp/r412_readme.md`: `8f9dae9c1533484432e5e7c3df50ffdbefb090466d3a9a404a7acbf08fff605f`
- `/tmp/r412_geometry.md`: `b0e3d8bd3ff7d6ed407b13f24049afe5dbf4adbe87c94819e761ba79e66a6670`
- `/tmp/r412_aux.md`: `64cdd965dcfa54f1ac9c56bc3443327a520c00d8f0b41374a7260e95c7316ec1`
- `/tmp/r412_parent_check.py`: `1651e8c8c370d83e900e3cacc41a967114b338426eb967a1abfb01e88848665a`
- `/tmp/r412_parent.result.txt`: `18f902ec25e2d26876023fddec1b947fcab290a66d52135face790ee7ae20b6d`
- `/tmp/r412_geometry_check.py`: `778d798ff61963a7a54648f3207a748b816c47a0a2fee3499a0ece8db7cee60f`
- `/tmp/r412_geometry.result.txt`: `3d26627758a8a4daf16beb7951ab74276e3e1a080c8d7273f5ffea9fe3544606`
- `/tmp/r412_aux_check.py`: `82205f7a75150703f43ec0ded39ce1ef88c9ee2374cb629c70afe9aa29fc46f2`
- `/tmp/r412_aux.result.txt`: `266e6de231bf6e034471e8754e052c57627fe69a0a311ab8158dd7c91cb3384d`
- `/tmp/r412_parameters.m`: `582e6478dbe8267ac2af4c97012a8b21e3c81a664a5742195f037eb8dcf30e69`
- `/tmp/r412_matlab_parameters.csv`: `4ad7dccb4abcdb844f69b0d615852dea508c7cc6d3f5bf3ab85f7663551194bd`
- `/tmp/r411_main.md`: `91fb6468e3951e6474f3324c403434a296e6c3512a381106e97b2b45c3ed4172`
- `/tmp/r411_geometry.md`: `ed66744b47257f04b5188de053f9638b6dabbe38088a7996150e4166d84d38c6`
- `/tmp/r408_main.md`: `29e41de32db722d89962f3f3593155b7e298bb02350e50cdab4a2a4fd12f3253`

Current final bytes are bound above. The inherited proofs were used narrowly; no full-history re-audit or general closure is claimed. All requested bounded R412 review work is complete.
