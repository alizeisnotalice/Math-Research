#!/usr/bin/env python3
"""R412: exact local diagnostics, not certification of the original history.
Stage 1 uses genuine Lebesgue radial center shells with a step radius selector;
the assigned mass q R^n is not asserted to come from a common full f.
Stage 2 uses atomic full-source matching, hence is not a continuous-du model.
Stage 3 certifies the dimension choice using rational root/log intervals.
"""
from fractions import Fraction as F
from itertools import product


def log_interval(x, terms=32):
    assert x >= 1
    k = 0
    while x >= 2:
        x /= 2
        k += 1
    def core(v):
        z = (v-1)/(v+1)
        lo = 2*sum((z**(2*j+1)/F(2*j+1) for j in range(terms)), F(0))
        rem = 2*z**(2*terms+1)/(F(2*terms+1)*(1-z*z))
        return lo, lo+rem
    l, u = core(x)
    l2, u2 = core(F(2))
    return l+k*l2, u+k*u2


def stage1():
    count = 0
    # Integral over a radial shell [l,u] of 1_{r<=alpha R}/(q R^n) dw.
    # The volume of {2||w-x||_infty<=r} is exactly r^n.
    for n, ratio, alpha, q in product(
            [1, 2, 3, 8, 16, 32], [F(1), F(3,2), F(2)],
            [F(1,4), F(1,2), F(3,4), F(1)], [F(3,4), F(1)]):
        a, b = F(2,3), F(2,3)*ratio
        lo_log, hi_log = log_interval(ratio)
        assert lo_log <= hi_log
        for mode in range(4):
            # Includes the inner a-core and 12 outer shells; nonmonotone modes.
            cuts = [F(0), alpha*a]
            cuts += [alpha*(a+(b-a)*F(j,12)) for j in range(1,13)]
            val = F(0)
            for j, (l,u) in enumerate(zip(cuts,cuts[1:])):
                frac = [F(0), F(1), F(j % 2), F((5*j+3) % 13,12)][mode]
                radius = a+(b-a)*frac
                top = min(u, alpha*radius)
                if top > l:
                    val += (top**n-l**n)/(q*radius**n)
                for r in [l, (l+u)/2, u, alpha*radius]:
                    envelope = F(0) if r > alpha*b else 1/max(a,r/alpha)**n
                    actual = (1/radius**n) if r <= alpha*radius else F(0)
                    assert actual <= envelope
                    # Exact layer-cake antiderivative, with its terminal atom.
                    if r <= alpha*b:
                        lower = max(a,r/alpha)
                        layered = 1/b**n + 1/lower**n - 1/b**n
                        assert layered == envelope
            cap_lower = alpha**n*(1+n*lo_log)/q
            assert val <= cap_lower
            if a == b:
                assert val == alpha**n/q  # the base term must not disappear
            count += 1
    return count


def stage2():
    count = positive = empty = 0
    # Parent side 2, children side 1, outside centers +/-c.  Atomic full f has
    # masses 1 at y and z and 2^n-2 at 0; all three matching densities equal 1.
    # Original clock, own-past and stage history are NOT claimed by this model.
    for n, py, pz, cw, ct in product(
            [3,4,8,16], [F(3,5),F(3,4),F(9,10),F(99,100)],
            [F(3,5),F(3,4),F(9,10),F(99,100)],
            [F(101,100),F(11,10),F(5,4)],
            [F(101,100),F(11,10),F(5,4)]):
        if abs(py-cw)>F(1,2) or abs(pz-ct)>F(1,2):
            continue
        mass = F(2**n)
        assert cw>1 and ct>1
        assert cw>F(1,2) and ct>F(1,2)  # central atom not captured
        assert py+ct>F(1,2) and pz+cw>F(1,2)  # exclusivity
        assert (mass-2)+1+1 == mass and mass/F(2**n)==1
        for alpha in [F(1,4),F(1,2),F(3,4),F(1)]:
            # Two actual orientations, with unequal nonnegative retained marks.
            rows = [(py,cw,pz,ct,F(2,7)/mass**2),
                    (pz,ct,py,cw,F(3,11)/mass**2)]
            total = paid = rem = marginal_y = marginal_z = overlap = F(0)
            for y,w,z,t,weight in rows:
                iy = abs(y-w)<=alpha/2
                iz = abs(z-t)<=alpha/2
                total += weight
                marginal_y += weight*iy
                marginal_z += weight*iz
                overlap += weight*(iy and iz)
                paid += weight*(iy or iz)
                rem += weight*(not iy and not iz)
                if not iy and not iz:
                    assert alpha/2<abs(y-w)<=F(1,2)
                    assert alpha/2<abs(z-t)<=F(1,2)
            assert total==paid+rem
            assert paid==marginal_y+marginal_z-overlap
            assert paid<=marginal_y+marginal_z
            positive += int(paid>0)
            empty += int(rem==0)
            count += 1
    return count, positive, empty


def stage3():
    count = 0
    _, l2_hi = log_interval(F(2))
    assert l2_hi<1
    dimensions = list(range(1,65))+[96,128,256,512,1024]
    for n in dimensions:
        # Exact interval for alpha=(n+2)^(-1/(2n)); no floating root or exp.
        lo, hi = F(0), F(1)
        for _ in range(44):
            mid = (lo+hi)/2
            if mid**(2*n)*F(n+2)<=1:
                lo=mid
            else:
                hi=mid
        assert lo**(2*n)*(n+2)<=1<=hi**(2*n)*(n+2)
        log_lo, log_hi = log_interval(F(n+2))
        tlo, thi = log_lo/(2*n), log_hi/(2*n)
        assert 0<tlo<=thi<1
        assert 1-hi >= tlo/(1+tlo)
        assert 1-lo <= thi
        # A_n/sqrt(n+2) <= sqrt(n+2), including all n>=1.
        assert 1+n*l2_hi <= n+2
        count += 1
    return count


if __name__ == '__main__':
    a=stage1()
    print('Stage 1 PASS:',a,'native center-shell selector models; n=1,2,3,8,16,32; b=a included')
    b,p,e=stage2()
    print('Stage 2 PASS:',b,'atomic full-matching union models;',p,'positive paid;',e,'empty complements')
    c=stage3()
    print('Stage 3 PASS:',c,'exact dimension/root/log certificates; n=1..64,96,128,256,512,1024')
    print('TOTAL model/certificate records:',a+b+c)
    print('Scope: diagnostics only. Native theorem is analytic; original history is not certified by finite models.')
