# 第411轮：实际双见证的中心容量与低自身秩付款

2026-10-19。一般中心立方体极大算子的 n^(1/2+o(1)) 一致弱型上界仍未闭合。本轮在原 R408 远域早期费用上构造同一个双见证概率提升，支付两个不交的实际正分支：至少一见证中心在父盒内，及两中心在父外但至少一见证自身过去低。前者给显式小系数 X_q 价格，后者在冻结参数下一致为根阶乘对数 W 价格。不是对原余项重命名而已，但补集仍未支付。

## 1. 原始合同、原费用与本轮唯一分拆

完整 f≥0 属于 L1，W=∫f，真实接收中心 dA，边长 a≤R_A≤b≤2a，m_A=f(Q_A)=q_AR_A^n，q_-≤q_A≤λ。记 μ=dA/m_A、σ=q_A dA、π_A=f1_QA/m_A、X_q=∫σ，A_n=1+n log(b/a)，K=e^(√n)，s=1+√n，h=s/(ε_0q_-)，0<ε_0≤1/2，L≥4。原 C_col 包含原子项，S=β+C_col。所有原物理时钟、J/H、质量秩、旧来源 y、新来源 z、阶段、首次删除、空间与历史标记保留。

R408 已排除 R404 来源近域并保留 R406 高旧秩门及 R408 early 密度分数；不是任意无标记流。对父 A=u 或 v，设
\[
Z_A(x)=\int c_w(x)1_{m_w<m_A/K}\mu(dw),\quad
C_A(y,z)=\int c_w(y)c_w(z)1_{m_w<m_A/K}\mu(dw).
\]
原软因子为 (1−C_A/h)_+。统一较弱后果是 Z_A(y)>(2−ε_0)h、Z_A(z)>(L−ε_0)h；大端另有更强的 2h、Lh 门。完整质量闭窗给 T_A−Z_A≤B_0=ε_0h，原中心包络给 J(x)≤A_n/q_-。

在原完整费用测度 Θ 上保留软因子，仅在其正支 C_A<h 定义
\[
Q_y(dw)=\frac{c_w(y)(1-c_w(z))1_{m_w<m_A/K}}{Z_A(y)-C_A(y,z)}\mu(dw),\quad
Q_z(dt)=\frac{c_t(z)(1-c_t(y))1_{m_t<m_A/K}}{Z_A(z)-C_A(y,z)}\mu(dt).
\]
两者是概率核。同一条件乘积提升 \widehat Θ=Θ Q_y Q_z 的总质量恰为 R408，不改变任何原标签。按顺序分为：

1. P_in：w 或 t 的真实中心位于 Q_A 内；
2. P_low_actual：两中心都在父外，且 Z_w(y)≤h 或 Z_t(z)≤h；
3. R411：两中心都在父外，且 Z_w(y)>h、Z_t(z)>h。

三支互斥且穷尽。这里第二支在未重新归一化的外侧子测度上定义。附件 aux 中 R_out 仅表示第一步后的中间余项；最终 R411 始终指第三支。见证 w,t 不被赋予原 u,v 的历史资格。

## 2. 第一笔：中心内真实容量

完整来源匹配先消去质量分母：
\[
\int\pi_A(dx)\int_{w\in Q_A}c_w(x)1_{m_w<m_A/K}\mu(dw)
=\frac1{m_A}\int_{w\in Q_A,m_w<m_A/K}\frac{f(Q_A\cap Q_w)}{m_w}dw
\le\frac1{q_A}.
\]
先用 f(Q_A∩Q_w)≤m_w，之后才使用中心体积，完全不需要来源密度帽。另一见证的秩≤A_n/q_-，故双 exclusive 的未归一 union 矩≤2A_n X_q/q_-²。原软因子结合双秩分母给
\[
P_{\rm in}\le\Delta_{\rm in}X_q,\quad
\Delta_{\rm in}=\frac{2A_nB_L}{q_-^2h^2},\quad
B_L=\frac\beta{2L}+\frac{C_{\rm col}}{(2-\varepsilon_0)(L-\varepsilon_0)}.
\]
完整证明及原阶段求和见 aux。来源近域 Δ404 与此价格数值相同但分支不同：当前 Θ 已在来源远域，故不是重复收费。Δin≤S/(2L)，但改 L 会影响旧 P_L，不能凭此宣称全局已经吸收。

## 3. 第二笔：低自身过去的根阶对数价格

令 a_y=(2−ε_0)h，a_z=(L−ε_0)h，Jmax=A_n/q_-。对 x=y 或 z，双提升的单边见证测度满足
\[
d\Lambda_x(w,x)\le C_x\,\sigma(dw)\pi_w(dx),\quad
C_x=\frac{S\lambda}{q_-}\frac{a_x+B_0}{a_x-h}\log_+(J_{\max}/a_x).
\]
证明要点：先按原新来源 z 求和 Σ_i b_i(z)≤1，使用原逐来源外出/入列容量；对父质量闭秩 T_A，有
\[
\frac1{Z_A-h}\le\frac{a_x+B_0}{a_x-h}\frac1{T_A}.
\]
严格 Z_A>a_x 还保证父质量原子的左秩>a_x，因此原子展开给 ∫1_{Z_A>a_x}dT_A/T_A≤log_+(J/a_x)，没有遗漏跨阈值原子。然后 q_A/q_w≤λ/q_-。完整证明见 geometry。

见证自身 Z_w(x)≤h 蕴含 T_w(x)≤h+B0；闭 CDF 初始段容量给
\[
\int\sigma(dw)\pi_w(dx)1_{Z_w(x)\le h}\le\lambda(h+B_0)f(x)dx.
\]
故 whole any-low union 满足
\[
P_{\rm low,actual}\le P_{\rm low}W,\quad
P_{\rm low}=\lambda(h+B_0)(C_y+C_z).
\]
这是整份 union 价格，不带 1/2。两侧上界可重复计交集，实际分支只删除一次。若 S、λ/q_-、ε_0^{-1}、L 维度一致，P_low=O(√n log(n+2))；否则必须保留显示参数式。特别 λ²/q_-² 的齐次比不能丢掉。该结论不依赖见证是否能成为下一条历史边。

## 4. 完整回代与尚未结清总账

因此
\[
R408\le R411+\Delta_{\rm in}X_q+P_{\rm low}W.
\]
沿用 Fδ=(1−32δ)^−1、C406=χ_n+Δ404+η、V406=s+P_L+D_ηs，不重选 H、L、h。n≥9 时
\[
G_0\le16F_\delta R411+16F_\delta(C406+\Delta_{\rm in})X_q+16F_\delta(V406+P_{\rm low})W,
\]
\[
B_H\le32F_\delta R411+[E387+32F_\delta(C406+\Delta_{\rm in})]X_q
+[S390+8s+32F_\delta(V406+P_{\rm low})]W.
\]
完整原入口是
\[
\begin{split}
\mathrm{入口}\le\Lambda\{&8\lambda HW+2d_{\rm eff}A_{\rm entrance,n}W_\nu/H+64F_\delta R411\\
&+[2E387+64F_\delta(C406+\Delta_{\rm in})]X_q\\
&+[2S390+16s+64F_\delta(V406+P_{\rm low})]W\},\quad\Lambda=128/119.
\end{split}
\]
新增 X 系数为64ΛFδΔin，新增 W 系数为64ΛFδP_low。R408 core替换中的 C406、V406 与本轮新增 Δin、P_low 统一保留晚期反馈 Fδ；外部 E387、S390、8s 等按原式不变；A_entrance,n 与 A_n 不混用。低维仍用此前完整 core 替换，不混加高维式。没有宣称总吸收余额已经通过。

剩余总账：本轮 R411 的联合终端根阶预算；原 H 入口与参数兼容；soft/crossing/entry；重尾、宽距离、低pe、极端尺度比；原历史初始、删除跳跃、未来被删来源；全尺度拼接、截断与极限；所有 X 吸收系数和 W 重复次数。辅助见证提升和端点删除都不是原历史删除。

## 5. 下一步准确瓶颈

本轮给出一个可付款的停止支，但未构造可迭代合法树。余项的两个见证都在父外、各自自身过去>h，又分别捕获旧/新来源而排斥另一来源，且质量严格下降 K。下一步需要在这个实际带权子来源分布上构造来源更换及共同容量的结算，而不是把它免费刷新为 π_w 或授予父历史。当前一步列容量是 O(log n) 相对 σπ，σ 的总量是 X_q，不能把它直接称为 W 终端价格。必须在同一真实中心几何和来源测度中获得跨父重复收益或可求和势差。

## 6. 核验与来源范围

使用更新64项工具 E03 的共同测度、有限层守恒及终端核验方法；未调用树 Bellman 外部定理或其常数。用户13页397轮建议此前已全文读取，作为候选路线；本轮仍以最新 R408 原账为准。材料不是已证明定理。PDF SHA256：9b5abd480baf9c5b0e04c94e808282c0fccd4f343079e0652a208390e52b73ad；不重复上传。

实际本机 Python Fraction 检查：parent 12模型分2/6/4三阶段；aux 26模型分6/12/8，来源质量与体积精确、接收测度有限quadrature；geometry 2916原子模型及60 finite-incidence 模型，含有理对数下界、低自身秩CDF及union分拆。全部重跑通过。有限模型不认证原连续历史资格或一般维数渐近；一般结论依靠上述证明及独审。解压重跑和stdout比对另在打包时执行。保留LaTeX源、不编译PDF。缺少实际模型扣额数据，不估计成本比例。
