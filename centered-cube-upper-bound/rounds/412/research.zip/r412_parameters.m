% R412 floating-point parameter exploration; not interval certification.
n=[16;64;256;1024;4096;16384;65536;262144;1048576];
eps0=.5; q=1; lambda=1; S=2; L=4;
h=(1+sqrt(n))/(eps0*q); An=1+n*log(2);
ay=(2-eps0)*h; az=(L-eps0)*h;
Cy=S*lambda/q*(ay+eps0*h)./(ay-h).*max(0,log((An/q)./ay));
Cz=S*lambda/q*(az+eps0*h)./(az-h).*max(0,log((An/q)./az));
inner=(Cy+Cz).*lambda.*An./(q*sqrt(n+2));
ret=2*S./(q*h); ratio=inner./(sqrt(n).*log(n+2));
tab=table(n,inner,ret,ratio); disp(tab);
writetable(tab,fullfile(fileparts(mfilename('fullpath')),'r412_matlab_parameters.csv'));
