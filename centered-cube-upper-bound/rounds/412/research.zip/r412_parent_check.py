from fractions import Fraction as F

def case(N,pattern,hfrac):
    weights=[F(1+(i%pattern),pattern) for i in range(N)]
    # Geometric mass levels and K=2: strictfar predecessors have index < i-1.
    total=sum(weights); h=total*hfrac
    past=[list(range(max(0,i-1))) for i in range(N)]
    Z=[sum((weights[j] for j in p),F(0)) for p in past]
    B=[i for i in range(N) if Z[i]<=h]
    hit=[]
    for i in range(N):
        law=[F(0)]*N
        if i in B: law[i]=F(1)
        else:
            for j in past[i]:
                for k in B: law[k]+=weights[j]/Z[i]*hit[j][k]
            assert all(law[k]<=weights[k]/h for k in B)
        assert sum(law)==1
        hit.append(law)
    active=[i for i in range(N) if i not in B]
    if active: assert sum(weights[i] for i in B)>=h
    parent=[i for i in range(N) if i%3==0]
    cap=sum((weights[k] for k in parent),F(0))/h
    for i in active:
        p=sum(hit[i][k] for k in parent)
        assert p<=cap
        for j in active:
            q=sum(hit[j][k] for k in parent)
            returned=p+q-p*q
            remaining=(1-p)*(1-q)
            assert returned+remaining==1 and returned<=2*cap
            # Positive restriction before path lift, with no renormalization.
            inner=F((i+j)%5,5)
            assert inner+(1-inner)*returned+(1-inner)*remaining==1
    return len(active)

counts={};active_total=0
for phase,Ns in [('initial',[6,8]),('atomic_pressure',[9,12]),('expanded',[20,32])]:
    count=0
    for N in Ns:
        for pattern in [1,2,5]:
            for hfrac in [F(1,8),F(1,4),F(1,2)]:
                active_total+=case(N,pattern,hfrac);count+=1
    counts[phase]=count
print('PASS terminal probability, atomic bound and sequential union:',counts,'total',sum(counts.values()))
print('Active start rows checked:',active_total)
print('Finite rational rank chains only; not native center/history fixtures or a general root budget.')
