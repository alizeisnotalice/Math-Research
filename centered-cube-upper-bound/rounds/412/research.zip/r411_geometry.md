# R411：保留阶段的双 exclusive 一步分配与真实列容量

2026-10-19。**结果是实际的一步守恒列容量，以及“至少一见证自身严格过去低”的完整正分支付款；未得到一般根阶树预算。**本稿不扩大到无标记 M_H 或全 Hellinger 能量。原 b_i、early 密度分数、旧来源、物理时钟及全部原门均在分配的定义中保留。父代理本轮另审的“至少一个见证中心在父立方体内”付款不在此重复收费；这里允许直接加入“两中心均在父外”的正限制。

## 1. 精确输入和所筛命题

沿用 R400/R406 和 R408：真实 E、完整 f、m_A=f(Q_A)=q_AR_A^n、q_-≤q_A≤λ、μ=dA/m_A、σ=q_A dA、π_A=f c_A/m_A，K=e^{√n}，s=1+√n，h=s/(ε_0q_-)，0<ε_0≤1/2，L≥4。

定义

\[
T_A(x)=\int c_w(x)1_{m_w\le m_A}\mu(dw),\quad
Z_A(x)=\int c_w(x)1_{m_w<m_A/K}\mu(dw),\quad
J(x)=\int c_w(x)\mu(dw),
\]

\[
C_A(y,z)=\int c_w(y)c_w(z)1_{m_w<m_A/K}\mu(dw).
\]

实际两端费用分别以 A=u 和 A=v 为父。用 dΘ_i^e 表示原 Γ_i 乘相应 π_A(dz)b_i(z)、R408 early 正分数、原 soft 因子 (1−C_A(y,z)/h)_+ 及 R408 全部保留门的费用；e=u,v。该符号不定义新放松流，Θ 中保留原另一接收者和所有来源/时钟标签。设 Θ=Σ_{e,i}Θ_i^e，其总质量正好是 R408；原 soft 因子保证其正费用支撑满足 C_A(y,z)<h。

已审逐来源列/行容量给，在积分掉其他原标签后，

\[
d\Theta_i^u\le\beta\,\sigma(dA)\pi_A(dy)\pi_A(dz)b_i(z),
\quad
d\Theta_i^v\le C_{\rm col}\,\sigma(dA)\pi_A(dy)\pi_A(dz)b_i(z),
\quad\sum_i b_i(z)\le1. \tag{1}
\]

这些仅用于上界，实际构造不丢标签。R408 early 分数≤原 b_i，故同样满足(1)。记 S=β+C_col。

当前低共同捕获、高双秩支有 C_A(y,z)<h。对两种父可统一取

\[
a_y=(2-\varepsilon_0)h>h,\qquad
 a_z=(L-\varepsilon_0)h>h,
\quad Z_A(y)>a_y,\quad Z_A(z)>a_z. \tag{2}
\]

原因是大端 Z_u(y)≥T_v(y)>2h，小端 T_v(y)>2h；新端分别为 Z_u(z)>Lh 或 T_v(z)>Lh。实际闭质量窗容量给

\[
0\le T_A(x)-Z_A(x)\le B_0:=\frac{1+\log K}{q_-}=\varepsilon_0h. \tag{3}
\]

更强的 R406/R407 门仍保留，证明不需要把它们授予新见证。

所筛命题：将每个实际费用单位分给 y-only 和 z-only 严格小质量见证，保费用守恒，并给它们真实目标测度的统一列界。下面证明这个一步命题；它没有证明后继节点具备再次分配原 Θ 的条件。

## 2. 真实双见证和中心外侧正限制

在每个原父标签 (A,y,z) 上，定义概率核

\[
P_y^{A,y,z}(dw)
=\frac{c_w(y)(1-c_w(z))1_{m_w<m_A/K}}{Z_A(y)-C_A(y,z)}\mu(dw),
\quad
P_z^{A,y,z}(dt)
=\frac{c_t(z)(1-c_t(y))1_{m_t<m_A/K}}{Z_A(z)-C_A(y,z)}\mu(dt).
\tag{4}
\]

分母由(2)及 C<h 严格为正；Tonelli 给概率归一化，所有核可测。取它们的条件乘积并保留全部父标签。两个子见证都是实际 E 中的接收者，且 m_w,m_t<m_A/K；不是人为加入平移立方体。

令 0≤χ(A,y,z,w,t,\mathrm{oldlabels})≤1 为任意已指定的可测正限制，特别可取

\[
\chi=1_{w\notin Q_A}1_{t\notin Q_A}.
\]

这里 w、t 是真实接收中心坐标，条件不是来源点是否在父内。定义

\[
d\mathcal L=d\Theta\,P_y(dw)P_z(dt)\chi. \tag{5}
\]

**不在 χ 后重新归一化。**其总量就是原 Θ 中该双见证正分量。以各 1/2 的权重，分别推至 (w,y) 和 (t,z)，得到子测度 Λ_y/2、Λ_z/2；两者相加后的总量恰为 \mathcal L 的总量。若两边各保整份费用则会加倍，不能称守恒。

完整匹配还给

\[
\pi_A(Q_w\cup Q_t)\le(m_w+m_t)/m_A<2/K. \tag{6}
\]

这只是实际来源质量关系；子测度的费用权不等于 m_w、m_t，故(6)不自动成为沿树的费用守恒或 W 价格。

## 3. 新的一步列容量，包含正确的原子系数

对 x=y 或 z，定义

\[
c_x=\frac{a_x+B_0}{a_x-h}.
\]

则实际推前的单边测度满足

\[
\boxed{d\Lambda_x(w,x)
\le\frac{S\lambda}{q_-}\,c_x
 \log_+\frac{J(x)}{a_x}\;\sigma(dw)\pi_w(dx).} \tag{7}
\]

均匀参数为 c_y=2/(1−ε_0)≤4，c_z=L/(L−ε_0−1)。因此守恒的半分子测度列界为

\[
d\Lambda_{\rm split}(w,x)
\le\frac{S\lambda}{2q_-}
 \left[c_y\log_+\frac{J(x)}{a_y}
       +c_z\log_+\frac{J(x)}{a_z}\right]
 \sigma(dw)\pi_w(dx). \tag{8}
\]

真实 octave 有 J≤[1+nlog(b/a)]/q_-，故列界为 O(S(λ/q_-)log(n+2))，所有常数如上，不是假定单位列容量。

**证明。**先在(5)保留 χ 和所有实际条件；为得上界，才用 χ≤1、另一见证总概率≤1，并删去当前见证不捕获另一来源的因子。在保留来源 x 上，分母至少 Z_A(x)−h。利用(1)、Σb_i≤1 和另一来源的完整 π_A 概率，得到

\[
d\Lambda_x(w,x)
\le S f(x)c_w(x)\mu(dw)dx
 \int_E\frac{q_Ac_A(x)}{Z_A(x)-h}
 1_{Z_A(x)>a_x}1_{m_A>Km_w}\mu(dA). \tag{9}
\]

对 y 通道，b_i 位于被积分的新来源 z；先对同一 z 求和再用 Σb_i(z)≤1。对 z 通道，b_i 就位于保留来源 x。两种情形都只收费一次，未将 b_i(x) 与 b_i(z) 混写。

由(3)，对 Z_A>a_x，

\[
\frac1{Z_A-h}\le\frac{a_x+B_0}{a_x-h}\frac1{T_A}.
\tag{10}
\]

这是因为 T_A≤Z_A+B_0，且 (Z+B_0)/(Z−h) 随 Z>h 递减。

固定 x，将 c_A(x)μ(dA) 推到实际质量轴，闭 CDF 为 T。**Z_A>a_x 保证该质量原子的左秩 T(m_A−)>a_x**，因为严格 far 集合是严格小于 m_A 的过去。将每个质量原子展开为其秩区间，则

\[
\int\frac{c_A(x)}{T_A(x)}1_{Z_A(x)>a_x}\mu(dA)
\le\int_{a_x}^{J(x)}\frac{dr}{r}
=\log(J(x)/a_x) \tag{11}
\]

（J≤a_x 时左边为零）。对原子，原子质量/T_right≤其完整秩区间上的 ∫dr/r；对无原子部分按 CDF 换元。这里没有漏掉“首个跨越原子”：Z_A>a_x 已把它排除，故不需要额外 +1。仅有 T_A>a_x 时不能作同样断言。

最后在(9)取 q_A≤λ，用(10)–(11)，并以 σ(dw)π_w(dx)=q_w f(x)c_w(x)μ(dw)dx、q_w≥q_- 得(7)。原实际 m_A>Km_w 和中心外限制只是上界中被放松，始终在原构造(5)保留。

## 4. 实际 root-log 来源付款：至少一个见证自身过去低

本节直接应用在同一次原 Θ 双见证 lift，不改变任何历史。记原完整场的见证自身秩为

\[
Z_w(x)=\int_E c_b(x)1_{m_b<m_w/K}\mu(db),\qquad
T_w(x)=\int_E c_b(x)1_{m_b\le m_w}\mu(db).
\]

这里 b 只是积分变量；不混同阶段标记 b_i。任意 a_0≥0，由(3)和闭 CDF 子水平容量，

\[
\begin{aligned}
\int_E\sigma(dw)\pi_w(dx)1_{Z_w(x)\le a_0}
&=f(x)dx\int q_wc_w(x)1_{Z_w(x)\le a_0}\mu(dw)\\
&\le\lambda(a_0+B_0)f(x)dx.
\end{aligned}\tag{P1}
\]

证明：Z_w≤a_0 蕴含 T_w≤a_0+B_0；完整闭 CDF≤a_0+B_0 的初始段质量至多该数。等号原子允许整块进入，但仍遵守此容量；跨越阈值的原子被排除。没有把该条件称为新 w 的历史资格。

令 J_max=A_n/q_-，A_n=1+nlog(b/a)，定义维数显式的常数

\[
C_y^*=\frac{S\lambda}{q_-}c_y\log_+(J_{\max}/a_y),\qquad
C_z^*=\frac{S\lambda}{q_-}c_z\log_+(J_{\max}/a_z). \tag{P2}
\]

(7)与(P1)给两个通道的实际低自身过去费用分别至多
C_y^*λ(a_0+B_0)W、C_z^*λ(a_0+B_0)W。

**主收据采用 whole union，不用半分方案：**在(5)同一完整联合测度上支付

\[
\mathcal L_{\rm low}
=\mathcal L[Z_w(y)\le a_0\ \text{或}\ Z_t(z)\le a_0].
\]

用两个通道的 union 上界，严格有

\[
\boxed{\mathcal L_{\rm low}(\mathrm{all})
\le P_{\rm low}(a_0)W,
\quad P_{\rm low}(a_0)=\lambda(a_0+B_0)(C_y^*+C_z^*).} \tag{P3}
\]

交集可以在上界中出现两次，但实际分解只删除一次；不存在实际重复付款。完整正补集为

\[
\mathcal L_{\rm rem}=\mathcal L[Z_w(y)>a_0,\ Z_t(z)>a_0]. \tag{P4}
\]

取 a_0=h，则价格完全显示为

\[
P_{\rm low}
=\frac{S\lambda^2}{q_-}(1+\varepsilon_0)h
 \left[\frac{2}{1-\varepsilon_0}\log_+\frac{A_n}{q_-(2-\varepsilon_0)h}
 +\frac{L}{L-\varepsilon_0-1}\log_+\frac{A_n}{q_-(L-\varepsilon_0)h}\right]. \tag{P5}
\]

当 S、λ/q_-、ε_0^{-1}、L 为维度一致的冻结参数，h=(1+√n)/(ε_0q_-) 且 b≤2a，(P5)是 O(√n log(n+2)) 的来源价格。若参数随 n 变化，必须使用(P5)，不能隐去其依赖。

这个分支是新见证 w/t 的自身过去低，而原父上的旧/新来源各自秩仍高。它不等于原小端 v 低秩分支，也没有给新见证授予下一条原 Γ 资格。若只用半分子测度，可将费用减半，但只能支付对应通道的一半；为使补集具有(P4)的双高条件，本稿采用(P3)，两方案不相加。

### 与中心内付款和原母式的唯一结算

先在原完整双 lift 上支付至少一个见证中心在 Q_A 内的分支，将另稿已证明的价格记为

\[
\Delta_{\rm in}X_q,\quad
\Delta_{\rm in}=\frac{2A_n B_L}{q_-^2h^2},\qquad
B_L=\frac\beta{2L}+\frac{C_{\rm col}}{(2-\varepsilon_0)(L-\varepsilon_0)}.
\]

该中心内收据由父/辅助稿独立证明，本稿不重证或重收。然后只在 χ=1_{w,t\notin Q_A} 的正限制上应用(P3)。两步顺序不交，得到

\[
R_{408}\le\Delta_{\rm in}X_q+P_{\rm low}W+R_{411}, \tag{P6}
\]

其中 R_411 保留原 Θ 的全部标签及概率核，并额外满足

\[
w,t\notin Q_A,\qquad Z_w(y)>h,\qquad Z_t(z)>h.
\]

原高 parent-rank、low common、双范数 far、early 分数和全部 stage/clock 均保留；没有近域专用 collar 条件。这里没有将 child own-rank 条件递推为新历史。

写 F_δ=(1−32δ)^{-1}，C_406、V_406 保持 R408 原值。直接代入冻结原母式，n≥9 时

\[
G_0\le16F_\delta R_{411}
 +16F_\delta(C_{406}+\Delta_{\rm in})X_q
 +16F_\delta(V_{406}+P_{\rm low})W,
\]

\[
B_H\le32F_\delta R_{411}
 +[E_{387}+32F_\delta(C_{406}+\Delta_{\rm in})]X_q
 +[S_{390}+8s+32F_\delta(V_{406}+P_{\rm low})]W.
\tag{P7}
\]

原入口的增量为 64ΛF_δΔ_in X_q 与 64ΛF_δP_low W，余项槽为 64ΛF_δR_411；其他原入口项不变。Δ_in 的 X 吸收仍须核原剩余余额，不能宣称已经自动吸收。原低维全槽替换继续保留。

## 5. 新补集仍不能自动变成树的终端价格

(5) 是一条实际守恒边，不是一个已经合法可迭代的树。三个缺口必须分开：

1. 接收目标 w 的来源条件分布是从(5)推来的带权来源分布，通常不是完整 π_w。(7)仅给支配密度，未给等式或重新抽样的无损性。恢复完整 π_w 必须保留相关密度和补流费用。
2. y-only 子 w 明确不捕获原 z；z-only 子 t 明确不捕获原 y。因此原双来源对不能在子接收者上原样继续。若引入第二个新来源，必须证明它的 rank、低共同捕获和阶段标记关系，不能直接继承父 Θ 或 b_i。
3. (8)仍是相对于 σ(dw)π_w(dx) 的列容量。其总质量为 X_q，不是 W。沿质量下降 K 的有限高度或(6)的小子质量并没有证明不同父到同一子/来源的费用只收费一次；重复套对数列界也不是终端根阶预算。

所以本轮将(7)与(P1)用于(P3)的实际正分支付款，而不宣称整个 ΣΘ_i≤εX_q+C√nlog^A W。中心内与 low-own-past 两支支付后，(P4)保留 both-centers-outside、两个见证自身过去高；该余项的联合终端价格尚未证明。最窄的构造接口是：**在上述实际带权子来源分布上，建立一个保留费用的下一步来源更换及共同容量结算；当前完整 π_w、历史资格和单位列容量三者都不能免费使用。**

这不是引入一个新的未标记等价目标，而是说明这条已构造一步路径究竟缺哪个合法延续。没有新增旧平方信用，没有改变 full f 或重新筛选原 receiver，也没有把新 w 当作原 core endpoint。

## 6. 实际本机检查与结束

执行 `/tmp/r411_geometry_check.py`：

```
PASS column/exclusive: 2916 60 total: 2976
```

2916 个 Fraction 原子模型核验严格 far 左秩、(10)和(11)后的实际列上界，以及(P1)的闭 CDF 低自身过去容量。log 的验证使用正项 atanh 级数的有理下界，故检查的是更强的有理不等式，不是浮点拟合；质量窗宽使用模型自身的精确 B，而不将 native B_0 强加给任意离散权。60 个完整来源匹配 finite-incidence 模型核 exclusive 概率、对向不捕获、(6)、不重新归一化的半分守恒，并在三个自身过去阈值核 whole any-low union 与 both-high 补集的精确分解。

这些不是 native 立方体中心或原历史样本；测试中的任意正 mask 只核算分配代数，不冒充 both-centers-outside 几何。真实场证明由(1)–(11)给出。本轮取得(P3)的实际根阶多对数正分支付款；完整补集仍未付。按有界任务要求停止，不扩新树。
