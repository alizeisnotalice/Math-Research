# R674 A1 — the actual low shared-load transport remains unpaid

## Result and scope

No uniform O(tau) bound for the complete actual-volume-weighted load has been proved in this bounded task. The separately developed high shared-load estimate is a new pointwise bound, but the complementary low part still carries almost all of the transported receiver mass. It is not a small error left after the main receiver mass has been paid.

The main variant used here is the parent's legal rate

    nu=5tau/16,     mu=tau/4=(4/5)nu,
    k=ceil(128 sqrt(n)),     rho=9/10.

Each seed has an actual fixed-range pool of rate greater than nu. Its auxiliary profile t_i,a satisfies 0≤t_i,a≤q_i, is supported in that pool and has total rate nu. Actual groups Y_a are formed by the 80-percent witness test, and remain disjoint subsets of the true remaining receiver Y. All original q, owners, source/target order, corrected self convention, I_h, clips, Poisson histories and masks remain unchanged.

## 1. The exact actual candidate and the relevant split

Write

    v_a=|Y_a|,
    M_a=Σ_i d_i t_i,a>0,
    m_a(x)=Σ_i t_i,a1_{A_i}(x),
    L(x)=Σ_a v_a m_a(x)/M_a.                               (1.1)

The corresponding original-family coefficients are

    b_i=Σ_a(v_a/M_a)t_i,a.

They are nonnegative and have the exact objective

    Σ_i d_i b_i=Σ_a v_a=V_rem,
    ∫L(x)dx=V_rem.                                        (1.2)

The factors v_a/M_a are actual payment factors, not fractional-cover weights. They are not replaced by the uniform short-sample envelope in this note. A proof L≤A tau a.e. would make b/(A tau) a genuine original-family packing. No old q_i upper cap is imposed on these new b_i.

For this same candidate define

    L_high(x)=Σ_a [v_a m_a(x)/M_a]1{m_a(x)≥rho nu},
    L_low(x)=Σ_a [v_a m_a(x)/M_a]1{m_a(x)<rho nu}.           (1.3)

The pointwise high-load estimate is the subject of the final REPORT.tex and S2_JOINT_PAYMENT.md. It is not re-proved here. The missing inequality is a uniform all-space bound for the full L_low in (1.3), or a different genuinely feasible packing paying the same V_rem.

## 2. The high part has very little integrated mass

This scope check follows directly from the certified R673 short-sample theorem. For one profile, iid labels of law t_i,a/nu satisfy

    ∫(m_a(x)/nu)^k dx
       =E|intersection_{j≤k}A_{i_j}|
       ≤3M_a e^(−2k).                                    (2.1)

The equality is an ordinary probability/Fubini identity; the inequality follows because the unexpanded intersection is contained in its c0 beta halo, to which the theorem applies. The genuine auxiliary owner pieces, rate nu≥mu and source radius at least beta meet the theorem's hypotheses.

On m_a≥rho nu,

    m_a/M_a
       ≤(nu/M_a)rho^(1−k)(m_a/nu)^k.

Hence, with

    delta_n=3nu rho^(1−k)e^(−2k),                          (2.2)

one has

    ∫L_high≤delta_n V_rem,
    ∫L_low≥(1−delta_n)V_rem.                              (2.3)

For example delta_n≤120k e^(−15k/8), using nu≤40k and log(10/9)<1/8. Thus this coefficient is extremely small in the actual regime k≥2048. No numerical extrapolation is needed for (2.1)–(2.3).

A small integral for L_high is compatible with its separately proved pointwise bound. It shows that the pointwise low-load problem is still responsible for nearly the entire packing objective in (1.2). It must not be described as a negligible receiver remainder.

## 3. The precise common-point obstruction in the low part

For every actual receiver target h assigned to anchor a, the capture condition is

    W_a(h):=Σ_i t_i,a1_{A_i}(z_h)≥(4/5)nu.

The profile rate simultaneously containing x and z_h has the lower bound

    Σ_i t_i,a1_{A_i}(x)1_{A_i}(z_h)
       ≥m_a(x)+W_a(h)−nu
       ≥m_a(x)−nu/5.                                    (3.1)

This retains the actual witness; it does not assume that all anchor parents contain every captured witness.

The parent high-load argument combines (3.1) with a mass truncation. When m_a(x)≥.9nu, deleting at most .1nu of large-d_i rate leaves a common-point-at-x pool of rate at least .8nu=mu, while keeping enough overlap with each captured witness for the short-sample joint estimate. The cumulative receiver-volume bound can then retain the denominator M_a.

The complete low part has two distinct missing links.

* If m_a(x)≤nu/5, (3.1) gives no positive simultaneous-source guarantee at all. The sources contributing to the load at x may be different from those certifying the captured witness. They still share the original anchor seed as a common point, but that two-parent relation is not the common-source hypothesis needed by the high-load joint estimate.
* If nu/5<m_a(x)<.9nu, the overlap in (3.1) may be positive, but a uniformly mass-truncated source pool at x need not have rate at least mu. For m_a(x)<mu even the original anchor's untruncated contribution at x is below that threshold. For m_a(x) just above mu there is no supplied margin for the truncation loss. Additional original sources at x can exist, but their owner mass is not bounded by the anchor-mass cutoff for the receiver collection under consideration.

These statements do not assert that the desired low bound is impossible. They identify the exact geometric estimate missing from this particular joint-common-point proof. The actual profile/source geometry has not been discarded: all profile parents contain the seed, receivers lie near their own witnesses, the actual owners and receivers are disjoint, and g_G≤1 throughout the true small receiver boxes. None of these facts was converted here into a quantitative bound for the two-parent low-overlap transport in the first bullet, or into a mass-controlled augmentation at x in the second.

## 4. Why source-load feasibility and the actual volume alone do not finish the estimate

For positive original q_i, the load can also be written

    L(x)=Σ_i q_i1_{A_i}(x)
           Σ_a (v_a/M_a)(t_i,a/q_i).                      (4.1)

The original all-space inequality Σ_i q_i1_{A_i}≤tau controls the measure in this weighted sum, not the cumulative payment factor following it. Actual receiver disjointness supplies (1.2) and is used decisively by the high-load argument, but it has not supplied an essential-supremum estimate for (4.1). A finite L1 mass is not an all-space packing capacity certificate.

At the same time, a uniform source-column bound would be only a sufficient stronger statement. The target remains the actual q-weighted pointwise average in (4.1), with v_a and M_a intact. No necessity of the old worst-envelope column condition is asserted.

The bounded analysis considered extending a seed's original minimum-mass profile into its larger original seed pool, with a corresponding change of payment denominator. Such a normalized kernel splits into an attenuated old-prefix component and a discarded-tail component. This was an independent candidate, not a bound on the present L_low: the tail does not inherit the old 80-percent witness overlap, and a contraction of the prefix component does not control the full new kernel. It is not inserted into (1.3), and no claim that it pays the low part is made.

Direct geometric localization through two different seed-sharing parents also preserves the real v_a but leads, in the attempted coarse bound, to enlarged-cube volume factors rather than an absolute source budget. Those envelopes are not substituted for the exact kernel and are not counted as a quantitative improvement.

## Final checkpoint

The complete low shared-load kernel remains unbounded by A tau in this task. The high pointwise estimate and the integrated diagnostic (2.3) have different roles: the former controls a genuine portion of the candidate's pointwise load, while the latter proves that the unhandled low portion still contains nearly all of its objective mass.

No change to the original problem, a source-dependent measure, a reordered original process, or an unverified packing was used. No new scalar optimization, numerical scan, MATLAB session, Git operation, PDF compilation, child agent or edit to another agent's file was performed. The needed next geometric step is an actual all-space control of the low shared-load transport in §3, not another normalization or a smaller uniform bound replacing v_a/M_a. This bounded task stops here.
