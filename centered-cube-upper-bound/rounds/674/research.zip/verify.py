from pathlib import Path
import ast,hashlib,json,re
p=Path(__file__).resolve().parent
for name in ('HIGH_LOAD_CHECK.py','verify.py'):ast.parse((p/name).read_text())
r=json.loads((p/'HIGH_LOAD_RESULT.json').read_text())
assert r['precision_bits']==256 and r['absolute_high_constant']=='1575/65011712'
for name,count in [('constants',7),('dimension_probes',8),('cdf_identity_fixtures',4)]:
 assert len(r[name])==count and all(x['pass'] for x in r[name])
assert r['script_sha256']==hashlib.sha256((p/'HIGH_LOAD_CHECK.py').read_bytes()).hexdigest()
s=(p/'REPORT.tex').read_text();stack=[]
assert s.count(chr(92)+'begin{document}')==s.count(chr(92)+'end{document}')==1
for m in re.finditer(re.escape(chr(92))+r'(begin|end)\{([^}]+)\}',s):
 if m[1]=='begin':stack.append(m[2])
 else:assert stack and stack.pop()==m[2]
assert not stack
for name in ('REPORT.tex','A1_ACTUAL_LOAD.md','S2_JOINT_PAYMENT.md','HIGH_LOAD_CHECK.py','HIGH_LOAD_RESULT.json'):
 assert hashlib.sha256((p/name).read_bytes()).hexdigest() in (p/'S1_REVIEW.md').read_text(),name
m=p/'MANIFEST.json'
if m.exists():
 for name,v in json.loads(m.read_text())['members'].items():
  b=(p/name).read_bytes();assert len(b)==v['bytes'] and hashlib.sha256(b).hexdigest()==v['sha256']
print(json.dumps({'pass':True,'scope':'artifact integrity, saved exact/interval records, syntax and final audit bindings; not mathematical proof verification','manifest_checked':m.exists()}))
