# R674 S2 — a genuine global bound for the high-coincidence part of the actual load

**Proved partial result.** Use legal auxiliary profiles of rate nu=5tau/16 and robust capture at 4nu/5. For the SAME actual-volume-weighted candidate

    L(x)=sum_a v_a m_a(x)/M_a,
    m_a(x)=sum_i t_i,a 1_{A_i}(x),
    M_a=sum_i d_i t_i,a,    v_a=|Y_a|,

define

    L_H(x)=sum_{a:m_a(x)>=9nu/10} v_a m_a(x)/M_a.

Then, for almost every x in the original full space and with ALL actual subintervals included,

    L_H(x)<=640(32/31)8!/32^8
           =1575/65011712.                                  (1)

This is an absolute bound on one pointwise part of the candidate load. It uses the REAL receiver volumes, a common-x cutoff source population, one joint short-sample experiment per cutoff, and actual source-incidence bookkeeping. It does not replace v_a by eta M_a and does not sum per-anchor upper prices.

The remaining L_low, with m_a(x)<9nu/10, is not paid here. The high/low split depends on x. It is NOT a fixed receiver branch or, by itself, a collection of original packing coefficients whose objective can be separately credited. Thus the general packing/receiver conclusion remains open.

## 1. Legal auxiliary variant and exact candidate

Keep every original parent, q, owner F_i, actual receiver X_h, source ordering, saturation witness and original pool unchanged. Write

    tau=16384sqrt(n),  n>=256,
    c0=1+1/(32n),  c=c0^n<=32/31,
    mu=tau/4,  nu=5tau/16,
    k=ceil(128sqrt(n)).

Within an actual fixed subinterval B=[alpha,beta), beta/alpha=2^(1/n), the ground set is

    G_B={i:q_i>0, beta<=s_i<n alpha}.

Every remaining target has J_h={i in G_B:z_h in A_i} of rate greater than nu. Therefore a genuine profile t_a can be chosen with

    support(t_a) subset J_a,
    0<=t_i,a<=q_i,   sum_i t_i,a=nu.                         (2)

Minimum-mass sorting is optional for this proof. The profile portions are realizable inside the genuine F_i and disjoint across labels for this one profile. Portions from different anchors are NOT assumed disjoint.

Capture all currently uncovered actual targets satisfying

    W_a(h):=sum_i t_i,a1_{A_i}(z_h)>=4nu/5.                  (3)

The seed is captured. The finite procedure therefore partitions the actual remaining receiver pieces into Y_a=union of the assigned X_h, with v_a=|Y_a|. In particular the Y_a are disjoint, across anchors AND subintervals, and sum_a v_a=Vrem.

This changes only the legal auxiliary profile/capture construction. It does not change the original q, histories or full receiving account. Since nu>=mu, the certified short-sample theorem is applicable to the profiles. The usual joint upper price also remains valid, but is not used in the payment below.

Define the actual payment coefficients

    b_i=sum_a (v_a/M_a)t_i,a.                               (4)

Because M_a>0,

    sum_i d_i b_i=sum_a v_a=Vrem.

The weights b_i need not obey the old q cap. The targeted packing would be b/(A tau) if its complete all-space load were bounded. Equation (1) proves only the high-coincidence part of that load.

## 2. Fix x and one subinterval; build a new common-x population

Work outside the original packing null set, so

    sum_i q_i1_{A_i}(x)<=tau.                               (5)

One may additionally discard the finitely many original parent faces. Fix such an x and a fixed B.

For m>0 let

    A_x,B(m)={a in B: m_a(x)>=9nu/10 and M_a<=m},
    F_x,B(m)=sum_{a in A_x,B(m)}v_a.                         (6)

If this set is empty, all the cumulative estimates below are immediate. Otherwise set

    D=10m/nu,
    S_x(D)={i in G_B:x in A_i and d_i<=D}.                   (7)

For every anchor in (6), the rate on labels with d_i>D is at most

    sum_{d_i>D}t_i,a <= M_a/D <= nu/10.

Thus the profile's rate on the original population S_x(D) is at least

    9nu/10-nu/10=4nu/5=mu.

Since t_i,a<=q_i and (5) holds, the ORIGINAL rate of this single cutoff population satisfies

    mu<=T_S:=sum_{i in S_x(D)}q_i<=tau.                     (8)

All its original parents contain x, all its source radii are at least beta, and its actual source owners remain disjoint. Hence this is a valid input to the certified R673 short-sample theorem with r=beta and total T_S>=mu=4096sqrt(n).

## 3. One joint draw pays the entire cumulative real receiver collection

Take any target h assigned to an anchor a in (6). Inclusion-exclusion for the profile rate and (3) give

    sum_i t_i,a1_{A_i}(x)1_{A_i}(z_h)
       >=(9/10+4/5-1)nu
       =7nu/10.

Deleting the d_i>D rate loses at most nu/10. Therefore

    sum_{i in S_x(D) intersect J_h}q_i
       >=6nu/10
       =3tau/16.                                          (9)

The use of q instead of t is in the valid domination direction. Every h here belongs to this SAME fixed B, so J_h is exactly the original G_B section at its witness.

Draw k labels iid, with replacement, from the ORIGINAL cutoff population S_x(D), with probabilities q_i/T_S. The chance that every sampled parent contains z_h is at least

    [(3tau/16)/T_S]^k >=(3/16)^k.                           (10)

On this event the sampled intersection contains z_h; actual receiver geometry gives

    X_h subset z_h+c0s_h[-1,1]^n
        subset (sampled intersection)+c0beta[-1,1]^n.

Use ONE draw for all targets assigned to all anchors in (6). The actual X_h are disjoint. Integrating only those pieces, rather than their parents or arbitrary neighborhoods, gives

    (3/16)^k F_x,B(m)
      <=E | (sampled intersection)+c0beta[-1,1]^n |.
    
No independence between different h's success events is required. The short-sample theorem and (8) yield

    F_x,B(m)
      <=3 exp(-(2-log(16/3))k) U_S,                         (11)
    U_S=sum_{i in S_x(D)}|F_i|.

The cutoff population also has a genuine volume cap. Its owners lie in Q(x,c0D^(1/n)/2), since x lies in every source parent and d_i<=D. Disjointness therefore gives

    U_S<=cD=10cm/nu.                                       (12)

Finally log(16/3)<7/4. One exact proof uses e>8/3 and

    (8/3)^7/(16/3)^4=32/27>1.

Equations (11)-(12) prove the cumulative estimate

    F_x,B(m)<=(30c/nu)exp(-k/4) m
                  for every m>0.                          (13)

This is a joint estimate for an arbitrary number of high anchors, with their ACTUAL v_a. There is no anchor-count factor or eta sum_a M_a step. A different proof draw may be used for each fixed x,m; all conclusions are deterministic. No common random experiment for uncountably many x,m is claimed or needed.

## 4. Full mass range and Stieltjes payment

Every profile in B obeys

    M0:=nu(2beta)^n <=M_a<=M1:=c(2n alpha)^n.               (14)

The lower bound follows from s_i>=beta and total profile rate nu. For the upper bound, the profile portions share the seed witness and have s_i<n alpha, hence lie in Q(z_a,c0n alpha); genuine disjointness bounds their total volume by M1. No source portions from different anchors are assumed disjoint.

If there are no high anchors, the high load in B is zero. Otherwise M1>=M0>0. Moreover

    log(M1/M0)
      =log(c/nu)+n log(n alpha/beta)
      <=n log n,                                         (15)

because nu>=c and alpha<beta.

For the finite positive measure sum_high v_a delta_{M_a}, the exact layer identity, including possible endpoint atoms, is

    sum_high v_a/M_a
      =F_x,B(M1)/M1
         +integral_{M0}^{M1} F_x,B(m)/m^2 dm.

It remains valid when M0=M1, with zero integral. Apply (13):

    sum_high v_a/M_a
      <=(30c/nu)exp(-k/4)
           [1+log(M1/M0)].

Since m_a(x)<=nu, (15) gives the complete high contribution from this B:

    L_H,B(x)
      <=30c exp(-k/4)(1+n log n).                           (16)

The factor one in the brackets pays the Stieltjes endpoint; it is not omitted.

## 5. All-subinterval summation through ORIGINAL q capacity

An actual B can contribute a high anchor at x only if

    Q_B(x):=sum_{i in G_B}q_i1_{A_i}(x)
       >=9nu/10
       =9tau/32.                                          (17)

A fixed original source belongs to at most nL_n ground sets, where L_n=ceil(log_2 n)+2 and nL_n<=3n^2. Together with the full-space old-q feasibility (5),

    sum_B Q_B(x)
      =sum_i q_i1_{A_i}(x) #{B:i in G_B}
      <=3n^2 tau.

Therefore the number of subintervals with a high anchor at this x is at most

    (32/(9tau)) sum_B Q_B(x) <=32n^2/3.                    (18)

This step is essential: an absolute one-subinterval bound alone would not sum over arbitrary scale spans. The original q incidence supplies the payment for the number of active B.

Multiply (16) by (18):

    L_H(x)
      <=320c n^2(1+n log n)exp(-k/4)
      <=640c n^4 exp(-32sqrt(n)).                           (19)

Here 1+n log n<=2n^2 for n>=1 and k>=128sqrt(n). Finally, from the eighth term of the exponential series,

    exp(32sqrt(n)) >=(32sqrt(n))^8/8!,
    n^4exp(-32sqrt(n)) <=8!/32^8.

Using c<=32/31 proves (1). All-source/all-scale dependence has been paid in (18)-(19); no scale count is left unrecorded.

## 6. What is and is not settled

Equation (1) is a genuine global all-space estimate for the HIGH part of the same actual L in (4). It is stronger than a polynomial-in-n local estimate: all actual occupied subintervals were included and the final constant is absolute.

However L_H is selected by the x-dependent condition m_a(x)>=9nu/10. It is not the load of a fixed subvector of b obtained simply by keeping some anchor labels, and it does not identify a receiver-volume branch to remove from Vrem. The low part

    L_low(x)=sum_{a:m_a(x)<9nu/10}v_a m_a(x)/M_a

remains wholly unbounded by an absolute multiple of tau in this note. A bound for that part, or another genuine complete packing construction, is still needed before b/(A tau) can be claimed feasible.

No hypothetical common core of all captured targets was used. No mass/rate comparability, fresh owner capacity, source-coordinate independence, source-count estimate or generic LP assertion was introduced. The allowed tools were the genuine R673 short-sample theorem, true owner/receiver disjointness, original all-space q packing, the fixed subinterval incidence count, and elementary finite-measure integration.

The scalar comparisons in the author proof are exact. The main agent owns the requested actual Arb computation and certificate archive; this note does not claim that run as its own. No numerical geometric simulation, child agent, MATLAB session, Git operation or PDF compilation was performed. This bounded high-load proof is complete; the remaining low-load task is not pursued here.

