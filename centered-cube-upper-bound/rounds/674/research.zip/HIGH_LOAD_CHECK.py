"""Exact algebra/CDF checks and Arb scalar probes, not spatial input simulations."""
from pathlib import Path
from fractions import Fraction as F
from math import factorial,isqrt
import sys,json,hashlib
import flint
from flint import arb,ctx
ctx.prec=256
CH=F(640)*F(32,31)*factorial(8)/32**8
assert CH==F(1575,65011712) and CH<F(1,32768)
cert=[]
def eq(name,left,right):
 assert left==right
 cert.append({'name':name,'left':str(left),'right':str(right),'pass':True})
eq('cut_pool_rate_over_tau',(F(9,10)-F(1,10))*F(5,16),F(1,4))
eq('joint_rate_over_tau',(F(9,10)+F(4,5)-1-F(1,10))*F(5,16),F(3,16))
eq('active_interval_coefficient',F(3)/(F(9,10)*F(5,16)),F(32,3))
eq('absolute_high_constant',CH,F(1575,65011712))
eq('transport_high_mass_bound_at_n256',F(2*15360,192**2*16),F(5,96))
assert F(5,96)<F(1,16)
for name,gap in [('log16over3_below7over4',arb(7)/4-(arb(16)/3).log()),('log10over9_below_half',arb(1)/2-(arb(10)/9).log())]:
 assert gap>0
 cert.append({'name':name,'positive_gap':str(gap),'pass':True})
cases=[]
for stage,ns in [('initial',[256,257]),('boundary',[1024,4096,4097]),('expanded',[2**20,2**32,2**48])]:
 for n in ns:
  k=isqrt(16384*n)
  if k*k<16384*n:k+=1
  sn=arb(n).sqrt();nu=5120*sn;c=(1+arb(1)/(32*n))**n
  loghigh=(320*c).log()+2*arb(n).log()+(1+n*arb(n).log()).log()-arb(k)/4
  delta_log=(3*nu).log()+(1-k)*(arb(9)/10).log()-2*k
  high=loghigh.exp();delta=delta_log.exp()
  assert high < arb(CH.numerator)/CH.denominator
  assert delta < arb(5)/96
  cases.append({'stage':stage,'n':n,'k':k,'high_load_bound':str(high),'transport_high_mass_fraction':str(delta),'pass':True})
fixtures=[('initial_single',F(1),F(4),[(F(2),F(1))]),('boundary_degenerate',F(3),F(3),[(F(3),F(1,5)),(F(3),F(3,10))]),('boundary_atoms',F(1),F(8),[(F(1),F(1,5)),(F(3),F(2,7)),(F(3),F(1,11)),(F(8),F(1,2))]),('expanded_mass_span',F(1,2**21),F(2**21),[(F(1,2**20),F(1,17)),(F(1),F(2,19)),(F(2**20),F(3,23))])]
cdf=[]
for name,lower,upper,atoms in fixtures:
 assert 0<lower<=upper and all(lower<=m<=upper and v>=0 for m,v in atoms)
 knots=sorted({lower,upper}|{m for m,v in atoms})
 integral=sum((sum(v for m,v in atoms if m<=lo)*(1/lo-1/hi) for lo,hi in zip(knots,knots[1:])),F(0))
 endpoint=sum(v for m,v in atoms)/upper
 lhs=sum((v/m for m,v in atoms),F(0));assert lhs==endpoint+integral
 alpha=max(sum(v for m,v in atoms if m<=u)/u for u in knots)
 bound=(arb(alpha.numerator)/alpha.denominator)*(1+(arb(upper.numerator)*lower.denominator/(upper.denominator*lower.numerator)).log())
 if lower==upper:assert lhs==alpha
 else:assert arb(lhs.numerator)/lhs.denominator<bound
 cdf.append({'name':name,'lower':str(lower),'upper':str(upper),'atoms':[[str(m),str(v)] for m,v in atoms],'lhs':str(lhs),'endpoint':str(endpoint),'integral':str(integral),'linear_envelope_alpha':str(alpha),'envelope_bound':str(bound),'pass':True})
r={'interpreter':sys.executable,'python':sys.version,'python_flint':flint.__version__,'precision_bits':ctx.prec,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'scope':'Rational identities, exact finite-measure layer integration and finite scalar interval probes. CDF fixtures are not real source/receiver geometry. No low-load budget or general C_n certificate.','constants':cert,'dimension_probes':cases,'cdf_identity_fixtures':cdf,'absolute_high_constant':str(CH)}
Path(__file__).with_name('HIGH_LOAD_RESULT.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps({'constants':len(cert),'dimension_probes':len(cases),'cdf_fixtures':len(cdf),'absolute_high_constant':str(CH),'precision_bits':ctx.prec,'all_pass':True}))
