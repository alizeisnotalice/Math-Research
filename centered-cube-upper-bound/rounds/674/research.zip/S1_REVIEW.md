# R674：actual-payment向量的独立前置审查

**结论：精确candidate与完整回代PASS；尚未证明任何新全空间load界。** payment λa=va/Ma不是fractional-cover权重。原实际partition本身覆盖Yrem，向量bi=Σaλat_i,a的packing objective恰等Vrem；要完成原目标仍须一个统一的全空间L∞估计或另一真实packing构造。这个normalization/identity本身不算新预算。

先读本轮TASK与R673必要CONTINUE，独立完成下述审查，未读R674作者候选。只写本S1，无child/spawn/Git/PDF/MATLAB，不改其他文件，不作抽象反例或数值扫描。

## 1. 实际partition、payment factor与零分支

冻结一个真实R673 greedy cover的全部profiles与actual assigned groups；对所有occupied subintervals都保留。每个Ya是其实际Xh之并，groups互不交且⋃aYa=Yrem，va=|Ya|，Σva=Vrem。

每个seed profile满足0≤t_i,a≤qi、Σit_i,a=μ=τ/4>0、di=(2si)ⁿ>0，所以Ma=Σdi t_i,a>0。真实portions跨labels不交，但可跨anchors重复；min-mass canonical choice可用而不属于新identity的必要条件。任意符合commonpoint/threshold/scale的profile仍可使用已证R673 joint bound。

定义λa=va/Ma；va=0时λa=0。R673已证va≤ηMa、η=3e^(−3k/2)，因此0≤λa≤η。没有对零Ma作除法，也没有从finite输入外推无限anchor family。

λa是payment multiplier，不是fractional-cover weight：通常Σaλa1_Ya(y)=λ_owner(y)，并不≥1。覆盖来自Σa1_Ya=1在Yrem上，而不是λa。禁止以λa小为由宣称它们自身给fractional coverage，或把原分组的实际receiver measure改成source law。

## 2. objective恒等式及exact kernel

令bi=Σaλat_i,a。它是同一original finite packing family上的非负coefficient vector；profile外labels的bi=0。有限求和与真正di=|Ai|给

Σi di bi=ΣaλaΣi di t_i,a=Σa va=Vrem。

qi=0只能t_i,a=0，故该来源bi=0；含ti/qi的重写只在qi>0来源使用。

定义ma(x)=Σi t_i,a1_Ai(x)，L(x)=Σi bi1_Ai(x)=Σa va ma(x)/Ma。另有

π_i,a=di t_i,a/Ma， Σiπ_i,a=1，

L(x)=Σa va Σi π_i,a1_Ai(x)/di。

π是owner-mass law，而不是R673 auxiliary sample的rate law t_i,a/μ。每个1_Ai/di是unit Lebesgue density，因此∫L=Vrem；这个L1恒等式没有给L∞上界。

也可解释为从y∈Ya向test point x的Markov kernel K(y,x)=Σiπ_i,a1_Ai(x)/di：每个y-row总质量1，actual receiver measure被transport为L(x)dx。Row normalization不控制column density；要使用L∞ contraction需另证column约束，不能把mass conservation当成该约束。

## 3. 原family全空间packing条件

若对所有真实输入/全部occupied intervals的同一个L证明

L(x)≤Aτ Lebesgue-a.e.， A>0为绝对常数，

则θi=bi/(Aτ)≥0且Σθi1_Ai≤1，是original P₀的真实packing，objective=Vrem/(Aτ)。这里不能改用Ai′、Bi、仅selected intersections或每点另选不同的profile family。

必须检查所有原parents的full-dimensional open arrangement cells；L在每cell恒定，null faces可忽略。Analytic pointwise domination亦可替代实际枚举，但约束必须是整个原空间，不只Yrem、Bh、source centers或witnesses。若算法适应最坏cell来选profiles，最终仍需输出一套固定的coefficients并同时满足全部cells，不能对每个x用不同b却称为同一packing。

原family O含admitted与nonadmitted labels。当前b只用实际positive-q source variables，可zero-extend到O；P₀≥admitted-family optimum而非相等。新θ不必≤qi或qi/τ；旧qcap只约束auxiliary t≤q。所有原source order、self correction、Fi/Xh、Ih、clips与first-key histories保持。

## 4. 完整回代：没有重复费用

继承原完整账

V₀≤Cadm[U+(Kfar+Kup(n))U/τ+Vrem]， P₀≥U/τ。

第3节若成立，便有Vrem≤AτP₀。于是

V₀/P₀≤Cadm[(1+A)τ+Kfar+Kup(n)]。

用τ=16384√n、Kup(n)≤8e^(33/16)，原finite recovery给充分的uniform all-L1/all-positive-scale bound

Cₙ≤Cadm[16384(1+A)+Kfar+8e^(33/16)]√n。

没有再次加入旧marked/repeat或ηlocal费用；η只用于λa≤η的已证比较。小维n<256的near为空，b=0，按原baseline账处理。空family/无remaining receivers也平凡，不在P₀=0时作未定义除法。

用R672 notation G=τP₀−U≥0，Vrem≤AτP₀等于Vrem≤AU+A G，是充分gain目标的一种实现。θ不必每个instance都比baseline更大；P₀同时支配baseline和新packing，完整账已使用二者。候选若不能证明load，objective恒等式本身不会给gain。

## 5. worst-envelope只是更强的充分条件

旧b^worst_i=ηΣat_i,a满足bi≤b^worst_i逐source、L≤L_worst逐点，因为0≤λa≤η。所以旧worst-envelope load bound若成立足以证明当前目标，但没有证明它是必要条件。actual tiny receiver groups可有λa远小于η，不能为方便再抹去va并声称仍在处理同一个精确payment对象。

原固定-q column cap或Btrim≤AU仍是其他充分路线，不是原general theorem的必要条件。也没有从one scalar identity证明某个特殊profile/seed选择必可达到新的load bound。该候选的价值在于记录精确付款，真正新的估计仍待提供。

## 6. 后续几何估计必须保留的区别

1. R673 80%捕获是Σ_{zh∈Ai}t_i,a≥.8μ的rate statement，不是所有profile parents都含captured witness，更不是都含Xh。Owner law π带di因子，80% rate不能免费变成80% owner-mass capture。
2. 仅对含zh的parents可用Xh⊂Ai+c₀βQ；不能把该containment无条件赋给profile全部positive labels。Profile中未含zh的少量rate可能承载显著owner mass，当前没有uniform mass/rate comparability。
3. 全Bh low field为g_G≤1，且ma≤g_G在同interval成立，但不能因此控制Σaλama在所有旧parents或整个空间的sup。每profile individually ma≤τ也不能无成本对anchors求和。
4. min-mass/seed选择是可选design；若允许非canonical任意eligible profiles，R673 joint theorem仍有效，但R673“一partial所以L2 correction≤(32n)^(-n)/2”不能自动继承。只有具该canonical结构才可使用那一额外bound。
5. Pair missing rate、min-M顺序、actualreceiver不交与source-owner不交分别有效，但尚无证明把它们组合成当前L的global uniform bound。跨anchors重复Fi片仍必须保留payment fractions，不能假作globally fresh。

## 7. 前置阶段交付

exact objective、payment-vs-cover区分、mass-vs-rate kernel、all-space/original-family条件与完整回代均独立审清。未读作者具体估计，尚无新AU、全空间load或一般√n结论。后续只按授权检查具体geometry claim，不把等价目标、mass conservation或旧worst-envelope当作已付预算。

## 8. 新增有界独审：合法ν-profile变体与high-load字段

按父代理追加指令先读取MAIN_HIGH_LOAD.md的准确草图，独立完成以下证明；未读S2作者稿。**独立statement PASS。** 本结论只针对新选择的ν=5τ/16 profile/capture family，不自动作用于初始μ-profile数据。

每seed Jh有rate>5τ/16，故可取真实0≤t_i,a≤qi、总rateν的profile。ν≥μ，source半径≥β、commonpoint za与真实portions保证R673 short-sample theorem适用；同80%capture/Fubini给va≤3e^(−3k/2)Ma。新family仍partition同一个真实Yrem，λa=va/Ma、bi、exact objective恒等式都保持。选择ν只是合法auxiliary design，不更改原q/Ih/Poisson，也不宣称ν是旧free-rate certificate的最优rate。

固定x与actual subinterval B，ma(x)=Σti,a1Ai(x)，令H_B(x)为ma(x)≥9ν/10的anchors。定义

L_H,B(x)=Σ_{a∈H_B(x)} va ma(x)/Ma，

以及整个空间的L_H=Σ_B L_H,B。high分类依赖x，不能把这组terms当作一个与x无关的receiver branch或original-parent子packing。

为使用原qload≤τ，先排除原finite Ai全部faces上的null集合。finite step field在其余full-dimensional cells上满足load cap；以下对每个这样的x成立，最终a.e.足够。

## 9. 累计质量cutoff下的一次共同点联合付款

固定m>0，取所有high anchors且Ma≤m的**实际assigned groups**，令其接收累计体积

F_x,B(m)=Σ_{a∈H_B(x),Ma≤m}va。

空集合时F=0。否则令D=10m/ν，以及原source子族

S_x(D)={i∈G_B:x∈Ai，di≤D}。

任一所选anchor的rate在di>D上至多Ma/D≤ν/10。故S_x上保留的该anchor rate至少9ν/10−ν/10=4ν/5=τ/4=μ，原qi≥ti给T_S≥μ。另一方面T_S≤Σqi1Ai(x)≤τ。所有parents共点x、半径≥β，满足R673 local theorem的全部条件。di=D的labels保留，strict >D作为删除端点，无tie遗漏。

对任一assigned target h，其anchor在x处rate≥.9ν，在实际zh处rate≥.8ν。同一profile总rateν，所以同时含x、zh的rate≥.7ν；删di>D至多.1ν后仍≥.6ν=3τ/16。由固定G的Jh={i:zh∈Ai}及qi≥ti，原S_x source与Jh的overlap≥3τ/16。

因此对固定x,m后的一个iid S_x-law qi/T_S共同tuple，每个相关zh的检测概率≥(3/16)^k。source半径≥β且target sh<β，所以on检测事件整块真实Xh在sample halo内。第6节同一receiver-union Fubini论证适用，不需跨anchors或targets独立，得到

F_x,B(m)≤3exp[−(2−log(16/3))k]U_S。

e>8/3推出e⁷>(16/3)⁴，因为(8/3)⁷/((16/3)⁴)=32/27>1。因此log(16/3)<7/4，上式≤3e^(−k/4)U_S。

对原S_x，commonpoint x与di≤D保证所有真实Fi都在Q(x,c₀D^(1/n)/2)；它们不交，故U_S≤cD。最终对所有m>0都有

F_x,B(m)≤(30c/ν)e^(−k/4)m。

这是一次联合draw直接支付整个cutoff receiver collection，并未先将各anchor的ηMa求和，也没有额外乘旧η。x,m可分别固定后使用analytic proof；不需要一个draw同时对所有x,m有效。它们和target collection都不依赖当前proof tuple。

## 10. mass range、CDF原子与每B high-load上界

所有profile来源si≥β，故

Ma≥M₀:=ν(2β)ⁿ。

每profile的真实portions在seed共同点za附近Q(za,c₀nα)内，source si<nα且portions across labels不交，所以

Ma≤M₁:=c(2nα)ⁿ。

若有profiles，则M₁≥M₀。ν≥c且α<β给log(M₁/M₀)≤nlogn。这个upper mass bound不需要min-mass choice；canonical或其他eligible profiles均可。

对right-continuous有限CDF F(m)=Σ_{high,Ma≤m}va，精确layer identity为

Σ_high va/Ma=F(M₁)/M₁+∫_{M₀}^{M₁}F(m)m^(−2)dm。

可直接由1/Ma=1/M₁+∫_{Ma}^{M₁}m^(−2)dm求和证明。M₀处的atom已在整个积分中，M₁处的atom由终点项保留；ties、zero-va与M₀=M₁均合法。此积分是dm积分，不是漏掉边界项的Stieltjes微分。

插入第9节F(m)≤Cm，得到Σva/Ma≤(30c/ν)e^(−k/4)[1+log(M₁/M₀)]。由于ma(x)≤ν，

L_H,B(x)≤30c e^(−k/4)(1+nlogn)。

这里始终使用actual payments va/Ma，未抹成uniform η；每个CDF权重是真实互不交receiver volume。

## 11. 全部subintervals求和与absolute C_H

若B有high anchor，Q_B(x)=Σ_{G_B}qi1Ai(x)≥9ν/10=9τ/32。每source的ground-membership次数≤nL_n≤3n²，故

Σ_B Q_B(x)≤3n²Σqi1Ai(x)≤3n²τ。

因此active B数量≤32n²/3。乘第10节的单B界得到

L_H(x)≤320c n²(1+nlogn)e^(−k/4)
       ≤640c n⁴e^(−32√n)
       ≤640(32/31)8!/32⁸=:C_H。

中间用1+nlogn≤2n²、k≥128√n；末步用e^s≥s⁸/8!、s=32√n。所有n、subinterval和CDF的常数均保留；不把high-rim旧branch或旧η再重复支付。该C_H为绝对常数（等于1575/65011712），无需以小数大小作为证明。

## 12. 该部分界能和不能给什么

这是真正全空间a.e.部分load估计，但high集合依赖test point x。它不是一支已付的实际receiver partition，也不是一套独立的constant-per-parent packing coefficients。对同一个新payment向量仍有L=L_H+L_low，L_low由ma(x)<.9ν的terms组成，全部未付。

若以后对同一family证明L_low≤Aτ，则L≤Aτ+C_H，b/(Aτ+C_H)是original-family packing，完整回代仅条件地给

V₀/P₀≤Cadm[(1+A)τ+Kfar+Kup(n)+C_H]。

当前没有该low-part estimate，故没有一般AU/√n闭合。不能把L_H bound积分后当成V_up式source预算，也不能从单独high控制得出全b可行。

所有以上结论在独立statement阶段完成。主代理负责实际constant/strategy数值；本代理未启动或重复数值job。待S2完整proof与最终主稿形成，只核对scope、各阈值/端点和最终hash，不扩low-part研究。

## 13. 追加scope诊断：high只承载少量transport总质量

对同一ν-profile family，0≤ma(x)≤ν。iid ti,a/ν的original sampled intersection满足

∫(ma(x)/ν)^k dx=E|∩sample Ai|
≤E|∩sample Ai+c₀βQ|≤3Ma e^(−2k)。

这里使用ν≥μ、source≥β和seed commonpoint，所有原空间都被积分；没有换回旧μ-profile数据。令ρ=9/10。在ma/ν=u≥ρ上，u=u^k u^(1−k)≤ρ^(1−k)u^k，power方向正确。因此

∫_{ma≥ρν} ma(x)/Ma dx
≤3νρ^(1−k)e^(−2k)=:δₙ。

actual payment λ=va/Ma及非负Tonelli给

∫L_H≤δₙΣva=δₙVrem，

∫L_low=Vrem−∫L_H≥(1−δₙ)Vrem。

后一个等式使用本文件第2节∫L=Vrem，而不是对receiver branch的分类。

可用纯解析全n粗界认证δ<1/2：log(10/9)<1/2，故δ≤3νe^(−3k/2)≤15360√n e^(−192√n)。再用exp²项给δ≤5/(6√n)≤5/96<1/16，因而∫L_low≥15Vrem/16。另用log(10/9)≤1/9<1/8可得更强但非必需的δ≤8/(15√n)≤1/30；两条都不需要有限点外推。

这仅说明low部分可能承载几乎全部actual transport L1质量，不能由high L∞界宣称主要receiver mass已付；它也不证明low L∞必定无界或否定未来统一packing。积分在test-parent空间x中，high/low依赖x，不是实际Ya的分支partition。

## 14. S2完整作者proof与已有实际计算后置比对

完成第8–13节独立审查后，实际读取S2_JOINT_PAYMENT.md，SHA-256：

`3bec170b200c8cb024911f989c5c46d563028c53ec0ea55d44daad37ce7aa242`。

作者proof PASS：ν的可用性、Sx cutoff保留di=D、μ≤Ts≤τ、joint overlap3τ/16、common-x真实owner容量、CDF endpoints、Ma范围、active subintervals全尺度求和以及C_H均与独立推导一致。没有以每anchor ηMa上包络替代F的actual volume，没有把high字段当receiver branch或独立packing。无必须修改数学点。

已读取HIGH_LOAD_CHECK.py及HIGH_LOAD_RESULT.json metadata，未运行/重复该job。记录为Python3.12.14/python-flint0.9.0/Arb256bit，7个scalar identities/inequalities、8个dimension probes（3 stages）和4个exact CDF endpoint fixtures。CH实际exact值为1575/65011712。代码CDF层积分涵盖lower atom、upper atom、ties、degenerate M0=M1与expanded mass span；这些是任意finite atomic measures的identity检查，不是actualsource/receiver geometry实例。

δ代表点只检查明示scalar公式；所有n的一般粗界来自第13节解析推导。主代理拥有实际运行与最终archive，本代理不把读取记录说成自己重跑，也不以hash或finite probes替代数学证明。待最终作者A1/主REPORT形成，仅核具体新claims和最终版本绑定，不研究low项新方向。

## 15. 最终A1/主报告对照与五文件绑定

实际读取A1_ACTUAL_LOAD.md及REPORT全部数学正文，最终结论PASS，无剩余必改项。A1对sameν candidate、moment诊断、m≤ν/5时无保证common-source rate、intermediate低域可能达不到truncation后μ门槛的说明准确；均是本proof缺失的条件，不是low bound不可能的结论。其δ≤120k e^(−15k/8)由ν≤40k及log(10/9)<1/8成立。旧μ-prefix扩充试验被明确隔离，没有混进当前ν的L_low或声称tail满足旧capture。

REPORT完整账、payment非coverweight、原family定义、ν=5τ/16合法性、C_H所有阈值/CDF端点、跨B求和、low≥15Vrem/16及条件回代均与独立审核一致。S2标题已从payment改为bound，避免把x-dependent high part误称为已付receiver branch；主数学证明保持第14节PASS。

最终实际读取并绑定SHA-256：

- REPORT.tex：`95ed7ab6b165ee08a35b93f0158a1e4f26b8e7be88c18cc024c6dd18d94532a5`
- A1_ACTUAL_LOAD.md：`6a62a11047488b7499a15132350f2a2923666afe6bc41c82fa82e9274d11774c`
- S2_JOINT_PAYMENT.md：`857065494e885eb1c26aeab75d22ec522467feaada04655d0661e954f5efef62`
- HIGH_LOAD_CHECK.py：`571021de904d1c432e365023e6f20ae0971ff616417c5e32b2e867b2f47bbc90`
- HIGH_LOAD_RESULT.json：`62b9868fdfc8a1cdfe65ca8a11674b500d36bae0b9e8aa9a0218cdd6d2f7a23d`

实际metadata核对：7 scalar checks、8 probes（2 initial/3 boundary/3 expanded）、4 CDF fixtures全部记录pass，CH=1575/65011712，result中的script digest与实际文件相同。CDF fixtures不是真实source几何；数值不替代第8–13节全域证明。本代理没有重复主代理计算。

**最终独审PASS。** 新high-coincidence全空间部分界成立，仍不是完整packing或paid receiver分支；low承载至少15/16 transport质量且其全空间上界未证。没有一般Cn阶改善或AU闭合主张。只写本S1，无spawn/Git/PDF/MATLAB、无反例扫描，所有授权审核完成，交付停止。
