"""R726 independent recurrence audit; frozen tube files are never touched.

Only recurrence.json is generated. Exact rational sample-box tests and local
Arb256/384 bounds; independent MacBook Fraction/Decimal110 crosschecks.
"""
from fractions import Fraction as F
from itertools import product
from pathlib import Path
import hashlib,json,platform,socket,subprocess,sys

BS=[12,16,20,24,32,40,48,56,64]
GAMMAS=[1,8,256]


def sample_boxes():
    rows=[];one_axis=[-2,-1,0,1,2] # actual coordinates in units1/2
    for label,n,m in [('initial',1,2),('pressure',2,3),('expanded_factorized',4,4)]:
        # Core side1/4, anchor0. The thickened coordinate hull has side
        # (1+2*range_of_integer_samples_and0)/4 on each axis.
        width_sum=0
        for sequence in product(one_axis,repeat=m):
            width_sum+=1+2*(max((0,)+sequence)-min((0,)+sequence))
        expected_independent=F(width_sum,4*5**m)**n
        expected_repeated=F(17,20)**n
        p=F(3,5)**n;independent=p**m;repeated=p
        if n*m<=6:
            points=list(product(one_axis,repeat=n));capture=0;volume_numerator=0
            for sequence in product(points,repeat=m):
                capture+=all(abs(v)<=1 for point in sequence for v in point)
                widths=[1+2*(max([0]+[point[j] for point in sequence])-min([0]+[point[j] for point in sequence])) for j in range(n)]
                volume_numerator+=__import__('math').prod(widths)
            assert F(capture,5**(n*m))==independent
            assert F(volume_numerator,4**n*5**(n*m))==expected_independent
        assert repeated>independent and expected_independent>=expected_repeated
        shock=F(1,4);mixture=shock*repeated+(1-shock)*independent
        rows.append({'stage':label,'dimension':n,'independent_draws':m,'sample_grid':'{-1,-1/2,0,1/2,1}^n',
                     'thickened_core_side_exact':'1/4','capture_source_cube_side_exact':'5/4',
                     'one_sample_capture_probability_exact':str(p),
                     'independent_all_capture_probability_exact':str(independent),
                     'independent_equals_p_to_m':True,'same_sample_reused_probability_exact':str(repeated),
                     'common_shock_one_quarter_probability_exact':str(mixture),
                     'correlated_over_p_to_m_exact':str(repeated/independent),
                     'expected_independent_box_volume_exact':str(expected_independent),
                     'expected_reused_sample_box_volume_exact':str(expected_repeated),
                     'full_joint_enumeration':n*m<=6,
                     'expanded_calculation':'exact coordinate-factorization,5^m one-axis sequences; no full5^(nm) enumeration'})
    return rows


def ceilq(x):return -((-x.numerator)//x.denominator)


def bin_count_decimal(n,u):
    from decimal import Decimal as D
    q=F(4*n,u)
    if q.numerator&(q.numerator-1)==0 and q.denominator&(q.denominator-1)==0:
        return 2+n*(q.numerator.bit_length()-q.denominator.bit_length())
    v=D(n)*(D(q.numerator)/q.denominator).ln()/D(2).ln()
    return 2+int(v.to_integral_value(rounding='ROUND_CEILING'))


def decimal_checks():
    from decimal import Decimal as D,localcontext
    with localcontext() as c:
        c.prec=110;rows=[]
        for b in BS:
            n=1<<b;root=1<<(b//2);lh=(1+D(1)/(32*n)).ln();kappa=(D(n)*lh).exp()
            for gamma in GAMMAS:
                lo=gamma*root;hi=n//4
                if lo>hi:continue
                for u in sorted({lo,min(hi,2*lo),min(hi,4*lo),hi}):
                    m=2+ceilq(F(256*n,u));bins=bin_count_decimal(n,u);x=D(u)/n
                    failure=-D(u)+(D(u)/4)*x.exp()+2*(D(2*n)*D(u*u)/(1024*n)*x.exp()).sqrt()+D(u)/8
                    success=(2*kappa/root).ln()+D(bins).ln()-D(u)/(4*(lh+D(2).ln()/n).exp())
                    peak=max(failure,success)
                    gain=D(m)*u*u/(32768*n)
                    literal=peak+(D(m)*(failure-peak).exp()+(success-peak).exp()).ln()+gain
                    stronger=D(m).ln()+peak+((failure-peak).exp()+(success-peak).exp()).ln()+gain
                    rows.append({'b':b,'gamma':gamma,'u':str(u),'m':str(m),'bins':str(bins),
                                 'values':[str(failure),str(success),str(literal),str(stronger)]})
        return {'host':socket.gethostname(),'python':sys.version,'rows':rows}


if '--remote' in sys.argv:
    print(json.dumps({'exact_boxes':sample_boxes(),'decimal':decimal_checks()}));raise SystemExit(0)


from flint import arb,ctx
BASE=Path(__file__).resolve().parent
def st(x):return x.str(38)
def floor_unique(x):
    value=x.floor().unique_fmpz();assert value is not None
    return int(value)


def bin_count(n,u):
    q=F(4*n,u)
    if q.numerator&(q.numerator-1)==0 and q.denominator&(q.denominator-1)==0:
        return 2+n*(q.numerator.bit_length()-q.denominator.bit_length())
    return 2-floor_unique(-arb(n)*(arb(q.numerator)/q.denominator).log()/arb(2).log())


def point(b,u,bits=384,r_multiplier=1,gain_denominator=32768):
    ctx.prec=bits;A=arb;n=1<<b;root=1<<(b//2);m=2+ceilq(F(256*n,u));bins=bin_count(n,u)
    lh=(A(1)/(32*n)).log1p();kappa=(n*lh).exp();bscale=(-A(u)/n).exp()
    S=A(u)/4;r=A(u*u)/(1024*n)*r_multiplier
    failure=-u+S/bscale+2*(2*n*r/bscale).sqrt()+A(u)/8
    success=(2*kappa/root).log()+A(bins).log()-A(u)/(4*(lh+A(2).log()/n).exp())
    gain=A(m)*u*u/(gain_denominator*n)
    literal=(m*failure.exp()+success.exp()).log()+gain
    stronger=A(m).log()+(failure.exp()+success.exp()).log()+gain
    target=-A(u)/7
    assert literal<target or literal>target
    assert stronger<target or stronger>target
    return {'b':b,'n':f'2^{b}','u':str(u),'m_exact':str(m),'bin_count_exact':str(bins),
            't_definition':'sqrt(n), the worst case among all t>=sqrt(n)',
            'scale_constraint_model':'log(di/dj)=n log h+u, so u<=log(di/dj)-n log h exactly',
            'failure_log_bound':st(failure),'success_log_bound':st(success),'iteration_gain_log':st(gain),
            'literal_log_bound_m_failure_plus_success':st(literal),
            'stronger_log_bound_m_times_both':st(stronger),'target_minus_u_over_7':st(target),
            'literal_pass':bool(literal<=target),'stronger_pass':bool(stronger<=target),
            'literal_log_slack':st(target-literal),'stronger_log_slack':st(target-stronger),
            '_values':(failure,success,literal,stronger)}


def derivative_certificate():
    ctx.prec=384;A=arb
    gain=A(1027)/65536 # (256+3/4)/16384
    fail=-A(7)/8+(A(1)/4)*A('.25').exp()*(1+A('.25'))+(A('.125').exp()/(8*A(2).sqrt()))*(1+A('.125'))
    nmin=4096;lh=(A(1)/(32*nmin)).log1p();success=-1/(4*(lh+A(2).log()/nmin).exp())
    fail_total=fail+gain+A(1)/7;success_total=success+gain+A(1)/7
    assert fail_total<0 and success_total<0
    return {'minimum_n':nmin,'max_gain_derivative':st(gain),
            'failure_plus_gain_plus_target_derivative_upper':st(fail_total),
            'success_plus_gain_plus_target_derivative_upper':st(success_total),
            'consequence':'For either combined bound, log_bound+u/7 strictly decreases between ceiling jumps. Both ceilings only jump downward as u grows, so the entire admissible interval is hardest at its smallest u.'}


def first_passing(b,lo,hi,field):
    if point(b,lo)[field]:return lo
    if not point(b,hi)[field]:return None
    bad=lo;good=hi
    while good-bad>1:
        mid=(bad+good)//2
        if point(b,mid)[field]:good=mid
        else:bad=mid
    assert not point(b,good-1)[field] and point(b,good)[field]
    return good


def main():
    exact=sample_boxes();derivative=derivative_certificate();ranges=[];samples=[]
    for b in BS:
        n=1<<b;root=1<<(b//2)
        for gamma in GAMMAS:
            lo=gamma*root;hi=n//4
            if lo>hi:
                ranges.append({'b':b,'gamma':gamma,'range_empty':True,'u_min':str(lo),'u_max':str(hi)});continue
            for u in sorted({lo,min(hi,2*lo),min(hi,4*lo),hi}):
                low=point(b,u,256);high=point(b,u,384)
                for x,y in zip(low['_values'],high['_values']):assert x.overlaps(y)
                high['gamma']=gamma;high['_check']=[float(x) for x in high['_values']];del high['_values'];samples.append(high)
            start=point(b,lo)
            ranges.append({'b':b,'gamma':gamma,'range_empty':False,'u_min':str(lo),'u_max':str(hi),
                           'literal_entire_range_passes':start['literal_pass'],
                           'stronger_entire_range_passes':start['stronger_pass'],
                           'literal_first_passing_integer_u':first_passing(b,lo,hi,'literal_pass'),
                           'stronger_first_passing_integer_u':first_passing(b,lo,hi,'stronger_pass')})
    negatives=[]
    for label,kwargs in [('failure_radius_multiplier64',{'r_multiplier':64}),('inflation_denominator512',{'gain_denominator':512})]:
        row=point(20,8*(1<<10),384,**kwargs)
        assert not row['literal_pass'] and not row['stronger_pass']
        del row['_values'];row['deliberate_violation']=label;negatives.append(row)
    command=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=5','macbook-math','/Users/zhengzhihao/.venv/bin/python -B - --remote']
    run=subprocess.run(command,input=Path(__file__).read_text(),text=True,capture_output=True,timeout=45)
    remote={'command':command,'exit_code':run.returncode,'stderr':run.stderr}
    if run.returncode==0:check=json.loads(run.stdout);remote['result']=check
    else:check={'exact_boxes':sample_boxes(),'decimal':decimal_checks()};remote['local_fallback']=check
    assert exact==check['exact_boxes']
    for local,other in zip(samples,check['decimal']['rows']):
        assert (local['b'],local['gamma'],local['u'])==(other['b'],other['gamma'],other['u'])
        assert local['m_exact']==other['m'] and local['bin_count_exact']==other['bins']
        for x,y in zip(local['_check'],other['values']):assert abs(x-float(y))<=max(1e-12,abs(x)*1e-12)
        del local['_check']
    remote['independent_crosscheck_passed']=True
    result={'host':socket.gethostname(),'python':sys.executable,'python_version':platform.python_version(),
            'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'derivative_certificate':derivative,'depth_ranges':ranges,'sampled_depths':samples,
            'independent_and_correlated_box_tests':exact,'negative_controls':negatives,'remote':remote,
            'bound_interpretation':['Both readings are reported: literal[m*failure+success]*exp(gain), and the strictly stronger[m*(failure+success)]*exp(gain). Small-n failures are retained, not hidden by clipping probabilities.',
                                    't=sqrt(n) maximizes the positive success bound over t>=sqrt(n). u lies between gamma sqrt(n) and n/4, with gamma1,8,256; empty ranges are explicitly listed.',
                                    'All exact power-of-two logarithms and rational ceilings are evaluated analytically. No interval touching an integer is silently rounded to the wrong bin count.',
                                    'For n>=4096 the derivative certificate proves monotonicity of log_bound+u/7 over the entire u interval, including downward ceiling jumps. Thus the minimum-depth pass/fail decides the whole interval, and binary search records the exact first passing integer when needed.'],
            'sample_box_scope':['All sample-box tests are bounded physical geometric probability models, not actual greedy histories.',
                                'Independent fresh samples have exact fixed-source capture probability p^m. Reusing one sample has the same marginals but all-capture probabilityp, notp^m. A one-quarter common-shock mixture interpolates exactly and demonstrates the danger of association.',
                                'The thickened axis hull uses one core of side1/4 and a fixed source cube of side5/4. Capture is equivalent to all sample coordinates in[-1/2,1/2]. Expectations are computed by actual full enumeration or exact coordinate factorization.',
                                'The scalar recurrence assumes the supplied geometric one-step bounds; it does not verify the user separately assigned genuine positive-high history.'],
            'freeze_scope':['The original frozen tube.py/json are never opened or modified by this script. Only recurrence.py/json are generated for this independent audit.',
                            'Local Arb384 values agree with256 and remote exact/Decimal110 checks. Final artifact SHA256 hashes are reported externally after the last successful run. No Git, remote files or remaining processes.']}
    output=BASE/'recurrence.json';output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'output':str(output),'remote_exit':run.returncode,'independent_crosscheck':True,
                      'range_count':len(ranges),'sampled_points':len(samples),
                      'nonpassing_ranges':[r for r in ranges if not r['range_empty'] and not r['literal_entire_range_passes']],
                      'stronger_nonpassing_ranges':[r for r in ranges if not r['range_empty'] and not r['stronger_entire_range_passes']]},indent=2))


if __name__=='__main__':main()
