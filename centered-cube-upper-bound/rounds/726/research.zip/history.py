"""Positive original loss for balanced-sign receivers in a compressed true history."""
import json
from math import comb, isqrt
from fractions import Fraction as F
from flint import arb, ctx

def run(n,broad):
    root=isqrt(n)
    a=32*n
    jcount=4096*root*a**n
    qlog=arb(2).log()/jcount
    alpha=-(-qlog).expm1()
    donor=qlog.expm1()/2
    count=comb(n,n//2) if broad else 2
    owner=F(1,a**n)
    vt=count*owner
    mass=donor*arb(vt.numerator)/vt.denominator
    dfirst_log=n*arb(32*n).log()+n*(jcount-2)*arb(4).log()+alpha.log()
    # Other baseline values have a geometric upper bound of twice the first.
    # Total later sources and rows <= 2^n+count, smaller than the first.
    assert dfirst_log>(2**n+arb(count)).log()
    assert donor>0 and donor<arb(1)/4 and mass>0
    assert F(5,4)-F(1,2*a)>1+F(6,n)
    assert F(5,4)+F(1,2*a)-F(a+1,2*a)<1+F(6,n)
    assert n*arb(2).log()>arb(n).log()/2
    # For two independent samples distance in Hamming coordinates has exact mean.
    if broad:
        hist=[(2*r,comb(n//2,r)**2) for r in range(n//2+1)]
        assert sum(w for _,w in hist)==count
        gap=F(sum(d*w for d,w in hist),count)*F(7,8)
    else:
        gap=F(7,8) # two sites differ in two axes, unequal with probability 1/2
    return dict(n=n,broad=broad,receiving_labels=str(count),
                log10_baseline_steps=str(arb(jcount-1).log()/arb(10).log()),
                donor_theta=str(donor),V_bad=str(arb(vt.numerator)/vt.denominator),
                R_high=str(mass),logD_div_J_lower=str(dfirst_log/jcount),
                logD_div_J_upper=str((dfirst_log+arb(3).log())/jcount),
                paid_ratio_at_eta_one_quarter=0,expected_two_site_box_span=str(gap))
ctx.prec=256
def reverse(n, v, L):
    dilation=1+arb(1)/(32*n)
    ratio=4*n*L//v
    assert ratio*v==4*n*L and ratio.bit_count()==1
    bins=2+n*(ratio.bit_length()-1)
    m=2+(256*n+v-1)//v
    mock_t=isqrt(n)
    moment=m*(-3*arb(v)/8).exp()+(2*dilation**n*bins/mock_t)*(-arb(v)/(4*dilation*L)).exp()
    inversion=arb(m)*v*v/(32768*n*L)
    margin=-arb(v)/(7*L)-moment.log()-inversion
    assert margin>0
    return dict(n=str(n),depth=str(v),radius_ratio=L,log_slack=str(margin))

reverse_cases=[]
for exponent in [20,32,48,64]:
    n=2**exponent
    for v in [8*isqrt(n),n//4]:
        L=1
        while 512*L*arb(n+2).log()<=v:
            reverse_cases.append(reverse(n,v,L))
            L*=2
print(json.dumps(dict(positive_histories=[run(n,broad) for n in (64,256,1024)
                                           for broad in (False,True)],
                      reverse_tests=reverse_cases),indent=2))
