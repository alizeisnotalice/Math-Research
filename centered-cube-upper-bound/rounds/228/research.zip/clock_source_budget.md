# R228：静态包络的阶段组织与真实来源覆盖缺口

**有限结论。** 对[R227实际后验与pair引理](/Users/zhengzhihao/Desktop/T/output/centered_cube_round227_20261016_final_checkpoint/proof.tex.txt)，normalizer分段能合法得到每阶段有限包络质量，但不能由逐时归一推出整窗包络质量为1。按dyadic level全计的阶段估计被已有 `min{nL,log(e_l/e_h)}` 行界覆盖；跳过大删除后重启可使实际阶段数较小，却仍未转成Wβ来源预算。本稿没有得到新可付款原子交通；下面明确说明dyadic质量/最大来源阶段组织最早缺的真实receiver覆盖费用，不另建未付量宣称成果。

## CS1 先筛准确命题和允许工具

实际剩余为R227 capture-static付款后的原正支：

\[
 \Delta_{yv}>B_x(v)/T+Q_x(v)/(rp_y),\quad
 \Delta=w_{a/c_j}-w_h,\quad r=16\Lambda/(3K\varepsilon_{st}). \tag{CS1}
\]

原terminal-good v与bad u、captureρ0、high `p_y e_g≥2Kq`、FIRST `∫p_yβ≤q`、`∫Qν≤q`全部保原值。尺度 `a≤L(x),R(x)≤b≤2a`，`l=a/c_j≤h≤g≤bc_j`，故对数时长 `L_clk=log(h/l)≤log2`。这里h是far端点而非物理尺度。所有已付正支和负信用不重领。

允许当前同构造 `ν≤β`、source-born共同cut、低N实际receiver门、仅ν的fine-cell rank及固定j,t的对称未归一核。它们均不把辅助来源赋予原hard z的capture，也不把当前后验变成ν或β下的stationary概率。原两Π已经包含e_t^−2。

对同一完整实际行r（若门依hard z/history也固定它），令A_y(v)是 `1Z_t(v)w_t(y,v)/e_t(y)` 的静态可测上包络。R227已证pair引理给

\[
 R_{rem}(r)\le\sqrt{2nL_clk}\,M_G(r)M_B(r),\qquad
 M_G=\int_G A_y\,d\nu,\quad M_B=\int_B A_y\,d\nu. \tag{CS2}
\]

可用实际低门限制G，或把clock静态ρ0并入target包络；这些只减小相应正项，但全局积分还须保它们的完整history标签。实际原付款目标是把CS2乘原 `2Λ 1high dT_r` 后积分，而不是给每个y复制一份Wβ。若包络不依hard z，可在此后用唯一一次hard帽，得到R227式(6)的系数32Λ/3；若包络仍依z，必须保hard条件平均，不可直接移出。

本次不以任意scalar clock模型反驳FULL，也不从有限样本推断一般维数阶。下面仅筛分层方法本身是否已支付原source费用。

## CS2 normalizer阶段：合法包络与其真实个数

固定同一x,y,j及原合法 `[l,h]`。原e_t非增、右连续；w_t非增，Z_t递减。把每段起点s_j后的时钟截至e_t首次低于e_{s_j}/2；删除跳可直接在真实新e上重启，不为跳过的空levels造阶段。用原一侧值使每个阶段内部

\[
 e_t\ge e_{s_j}/2,\quad
 1Z_t(v)w_t(v)/e_t\le2\,1Z_{s_j}(v)w_{s_j}(v)/e_{s_j}.
 \tag{CS3}
\]

端点按原右连续版本分给下一段；单点不影响dt积分。原过程仅有限删除跳，有限正比e_l/e_h保证这种阶段数有限。若需共同截断，先在其上构造再取非负极限。

阶段包络总质量≤2，绝不是整窗总质量为1。设ℓ_j为该阶段对数长度。由于G、B不交，阶段R227引理更精确给

\[
 R_j(r)\le\sqrt{2n\ell_j}\,4\Pi_{s_j}(G)\Pi_{s_j}(B)
 \le\sqrt{2n\ell_j},\qquad
 R_{rem}(r)\le\sqrt{2nL_clk N_{act}}. \tag{CS4}
\]

若保静态targetρ0，把第一因子换成Π_{s_j}(ρ0 1G)，仍有同方向。此处s_j是同一x,y实际e过程确定的阶段，不是逐source分别挑最大时刻后又套单时概率归一。

一般仅知

\[
 N_{act}\le1+\log_2(e_l/e_h). \tag{CS5}
\]

若按每个dyadic level逐层收费，令A=nL_clk、B=log(e_l/e_h)，CS4只给常数乘 `sqrt(A(1+B))`。已有两条真实行上界是

\[
 R_{rem}(r)\le\min\{nL_clk,\log(e_l/e_h)\}. \tag{CS6}
\]

第一条用δ≤n与两Π归一；第二条用δ≤k_v、删其它正门，再用
`−dlog e_t/dlogt=E_{Π_t}k_t` 于连续段，删除的log跳非负。因此∫E k≤log(e_l/e_h)。这包含原支持；不借任何signed删除信用。

由于 `sqrt(A(1+B))≥min(A,B)`，用CS5完全替代N_act时并未改善CS6。不能据此登记新付款。另一方面，一次大删除可跨过许多level，N_act可以远小于log(e_l/e_h)；此时CS4可能改善纯clock行界，不能笼统断言被CS6逐点覆盖。但仅由少阶段给出的root行价仍是√n量级乘原receiver交通；它没有Wβ来源价、没有额外1/K，并非本任务要求的新原量付款。

## CS3 质量守恒支付什么，以及哪里仍留下倒数

对每个原e阶段，真实带权来源损失由同一ν给出：连续部分是 `∫1Z_t k_t w_t ν dt/t`，删除部分为跳时被删权质量。整窗准确满足

\[
 e_l-e_h=\int_l^h\!\int1Z_t k_t w_t\,d\nu\,dt/t
       +\sum_{l<s\le h}\int_{Z_{s-}\setminus Z_s}w_s\,d\nu. \tag{CS7}
\]

端点依原一侧约定，不重复算删除。CS7控制的是带权loss总量。归一后的每阶段质量或score支付却要除以当前e_{s_j}；这些倒数不能删。即使某个source在多个阶段反复降低权，CS7只将其总权损失算一次，并不把该source自动分成同样多份互不重叠的质量预算。

一个只用于核对该收费方法的标量关系是：e_j=2^−j时，`Σ(e_j−e_{j+1})=1−2^−N`，而 `Σ(e_j−e_{j+1})/e_j=N/2`。它解释“总loss有限”何以不支付归一stage数；不是FULL反例，也不说明原score交通一定这么大。若用最大来源阶段给每个v贴一次标签，该标签仍依同一y；对另一个y或receiver可再次出现，原β积分及真实覆盖倍数仍须支付。

按原空间细格质量作dyadic层同样不能消掉这些费用。rank只给 `ν(C∩V)/||ν||≤θV`，允许同一质量层中有很多格，也不给格内密度帽。ν≤β允许真实共有源分配，但不给所有y上的stage家族互不重叠；common cut/低N只在原receiver立方体及其稀疏坐标管上提供限制，没有已授的stage覆盖Carleson常数。不能从这些资格直接写 `Σsup_tΠ_t=1` 或 `Σstage cost≤||β||`。

## CS4 最早需要的真实receiver输出预算

为把缺项定位到原测度，而非新的自由量，先取不依hard z的包络正上界，并令

\[
 Z(x,y)=M_G(x,y)M_B(x,y),\quad
 E_m(y)=\{x\in E_{\omega,V}:2^m<Z(x,y)\le2^{m+1}\},
\]

\[
 \mu_m=\mathbb E\sum_V\int\beta_V(dy)
             \int_{E_m(y)}1high\,p_{s(x),L(x)}(x-y)\,dx. \tag{CS8}
\]

所有m∈Z；零Z无贡献。静态包络可先截断，非负极限保Tonelli。R227原量插入给需控制的实际项至多

\[
 {32\Lambda\over3}\sqrt{2n\log2}\sum_m2^{m+1}\mu_m. \tag{CS9}
\]

若用一个总包络mass M再估Z≤M²，阈值权变成2^{2m}，不能漏掉平方。FIRST只给 `Σ_m μ_m≤q EΣ|E_{ω,V}|≤X`；它不给大m层的衰减。对每个固定y，`p_actual(x,y)`的L,s仍随x变化，不能用∫p_actual dx=1授 `μ_m≤||β||`；即使另付R225一般核族包络，也只给其明列大价格，且没有m衰减。若保z依capture包络，CS8应直接在原hard条件平均内定义对应层，不能把这些层提前当成仅依x,y。

因此这次source分层/最大stage组织最早缺的正是：原同一x,y的这些receiver层，能否通过实际核、当前强capture及共同cut，建立可求和的加权覆盖输出，使CS9获得 `εX+C√n polylog(n)Wβ`。本稿没有证明该覆盖；不把CS8改称一个已知预算，也不将少阶段或小mass的特殊族作为一般付款替代。原K选择及其它尚未完整追踪的全局槽亦不由本稿注销。

## CS5 实际工具检查与停止

本机Python Fraction实际完成：36组A,B核对 `A(1+B)≥min(A,B)²`；8组N核对CS7型权loss与归一收费的16条精确恒等式；15组概率质量核对 `4Π(G)Π(B)≤1`。共67项精确有理断言通过。有限检查只核分层代数，不认证FULL、receiver覆盖或新根阶付款。

交付范围为CS3–7的合法阶段/损失费用及CS8–9的准确真实覆盖缺项。没有新原量付款；有限任务在此停止，不继续把未知覆盖条件改名或拓展简单特殊支。
