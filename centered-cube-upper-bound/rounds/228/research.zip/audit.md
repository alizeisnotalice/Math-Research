# R228 独立审查

## 作者稿前：hard-window affinity与clock变差的连接资格

已读本轮task_contract、R224冻结threshold_gap的QG15–17及范围、R227冻结proof的(5)–(8)和capture说明；不重审这些已证引理，尚未读R228作者新稿。当前实际强capture补域为Δ>B_x(v)/T+Q_v/(rp_y)，仍保原positive、high、good/bad、recapture/FA等已付补权，负账不重复使用。

### 1. 可以回到哪一个hard核及准确常数

若为使用R224 affinity返回hard帽之前，应从同一原positive母式（外2Λ、q^−1p_y h_R(x−z)、原aω/ρ0/history及两Π）重新上放。它替代原hard16/3路线，不能把旧32Λ/3系数保留后再领一次h_R核积分。hard z始终原全νV来源，不能改成Zg或第三份后验。

原good只授

    p_y ≤sqrt(K/3)Σ_{a=1,2,J} sqrt(p_y K_a,x(v))/sqrt(w_g(y,v))。

因此保hard核的三腿positive上界外因子为2Λsqrt(K/3)，仍有q^−1、β(dy)ν(dz)ΠvΠu和全部实际接收权。若只写两腿，须明示原域上的J吸收或对应正量分配；R224仅付终端带J，不能把深clock的J腿自动删去。已付分配应保精确补权。

固定θ=(L,R,A,s,σ,j)、g²=LR、m=min(L,R)、M=max(L,R)，R224在L,R∈[b/2,b]、A∈[L,b]、独立s,σ∈[0,1]、任意y/v/z下授

    ∫ h_R(x−z) sqrt(P_s,L(x−y)P_σ,A(x−v))/sqrt(w_g(y,v)) dx
       ≤(cj/g)^n exp[−κ/2 Σ_i(1−ω_m,i)]，
    κ=25/2^68，ω_m,i=min(1,bC_i/m)。

原a≤L,R≤b≤2a在此范围内；实际cjg/m=ζ∈[1,γ]，从exact-min比较到原cj无需新增指数损失，但物理因子(cj/g)^n仍在。指数1/2不能丢。独立soft包含J腿σ=1及两移动腿，不授任何selector/sources费用。

已用本机Fraction核30组min归一转换平方比ζ^−2n·w_m/w_ζm∈[ζ^−2n,ζ^−n]及κ/2常数，仅作归一代数核，不当实际source或selector证据。

### 2. 先积分receiver：换序本身合法，但固定参数界还不能套入

固定(ω,V,j,y,t)后，原α_i、k_t、Z_t(y)、w_t、e_t和Π_t不依receiver x；可以在完整原非负母式中用Tonelli先积分x。合法写法是先保唯一j，取共同t承载窗[a/cj,bcj]并把所有actual t≤h(x)、high(p_y e_g(x))、good/bad、capture/history与强低门放在x内的原指示/权中。不能把依x的上下端当作同一个固定θ窗，也不能先对j求和再免费恢复唯一标签。signed式只在原有限截断或已证绝对可积范围换序。

换序后x积分内仍有L(x)、R(x)、s(x)、g(x)、w_g(x)、终端集合与capture系数。QG是对单一θ在真实dx上的积分界，不是对每个x的点态界，亦不是任意θ(x)的界。把μ_θ(dx)=1_{θ(x)=θ}dx分别放到dx之下只能给每个θ一份完整列；再对所有θ求和仍有菜单/重叠费用。连续selector的pushforward也不自动具有有界密度或coarea Jacobian。

所以至少需要一个新的qualified maximal-affinity/联合选择器定理：对实际θ(x)及原接收权，给其receiver积分一个可测、有限且有价的共同参数包络，或给按参数分层后的总重叠预算。它须同时控制h_R、两个半密度、原sqrt(w_g)分母和(cj/g)^n因子；只上放kernel而重算新节点上的high/good/ρ0/强低门不合法。soft公共菜单与尺度BV可作方法，但若付C_sel(n)，该因子须保到最后，不能称无害。

先删high/good等正门以套固定θQG是合法上界；但被删的same-x FIRST、高门或capture资格不能在receiver已经积分掉后无价用回。尤其不能把p_actualβ改成某个节点p_θβ后仍引用原q帽。保原高门的加权receiver定理可能避免这种损失，须作者实际证明。

### 3. 与R227pair引理兼容所需的第二连接

对固定j,y及一个固定clock窗，R227只授

    ∫|kv−ku| wt(y,v)wt(y,u)/et(y)^2·支持mask dlogt
       ≤sqrt(2nL_clock) A_y(v)A_y(u)，

其中A必须是同一原normalizer/mask的真实静态majorant。若receiver积分后的系数仍依t，不能直接将它乘在pair结论外；须将其正上放到静态因子，或另证带该时间权的变差定理并付其费用。QG给的指数在固定θ时静态；若θ还由x/t/来源重选，则不自动静态。

一种合法组织是共同参数包络的测度/权先与t冻结，逐θ用固定QG，再对该θ的原clock和真实A应用pair引理；参数总价、source平均和全部ν(z)必须保留。另一种是先在每个actual x用pair引理，再证明其A_{x,y}(v)A_{x,y}(u)加权hard-affinity的联合receiver预算。后一权通常依x；不能把它从QG积分拿出或给其独立worst-case而漏价。

可选一个与x无关的显式majorant（固定j,y，在共同heavy合法窗取原masked posterior的静态majorant）再换序，但其source L¹质量及两份乘积必须证明有用。逐时∫Π=1并不授∫Aν=1；A=w_l/eg类仍带degree比。任意e/mask的pair工具免去它们的导数，不免去这些包络质量费用。

若成功以静态桥把每腿receiver核控制到固定θ的QG右端，则对应的pure-source项仍具有

    q^−1(cj/g_θ)^n exp[−κ/2Σ(1−ω_m)] A_{θ,y}(v)A_{θ,y}(u)

对原β(dy)ν(dz)ν(dv)ν(du)及参数桥权的积分。仅因QG对任意z一致，就把ν(dz)积成νV(V)是允许的粗上放，但这份质量必须付；不能从uniform-z核界自动得到Wβ一次。若桥价C_sel、source项合计S，则最多有

    P_rem ≤2Λsqrt(K/3) C_sel sqrt(2nlog2)·S。

这是一个明确检验尺度：S还须有相应K/receiver/source预算，或另做保权Cauchy，才能给εX+Cε√n polylogWβ。若最终只得C√(XWβ)前因子，Young会平方C；在固定QG核里没有任何常数机制自动抵消sqrt K或C_sel。不能仅见pair的sqrt n就登记一般原付款。

### 4. source交换和接收历史的允许范围

已验证当前β=ν+ρ_exc，只有ν⊗ν shared部分允许未归一W对称交换。stationary是etν；原p_y/et、另一份Π、score与所有high/history都随anchor一起转置。β−ν部分另在，不能由ν≤β反向删去。hard z虽也以ν积分，角色是h_R、实际接收capture/RN，不继承辅助source的good/bad或Z资格；交换它需把所有角色/门真正转置并支付差异。

QG数学半密度乘积对两因子可交换，不意味着实际input/future角色可交换：A≥L、σ及same-x FIRST的输入p均是指定原值，L↔A后不能直接当原输入重新归一。ν-only rank/cut不传给β或posterior。强capture补域保原T、B_x、α0与eligible；不能在新的参数节点/换source后重算capture再称同一原子域。

### 5. 精确成功条件及停止点

可接受的新结论是：在未领hard帽的同一强capture原positive上，给完整selector-affinity/clock-source联合界，且代入2Λsqrt(K/3)、q^−1、三腿/准确分配、原参数菜单价及Young后，确有εX+Cε√n polylog(n)Wβ（或明确子域与精确补域）。来源总价要保持同构造Wν≤Wβ≤相应父输入，不能复用已领的16/3、recapture额度或R226/R227静态门ε槽。所有负信用只在原signed母账一次处理。

目前Tonelli可以交换原nonnegative receiver/clock顺序；不能交换的是“固定θ积分界”与“θ(x)选择”或将已积分掉的same-x权重新当预算。最早需要的新几何是对actual自适应参数及实际source权的联合affinity包络/平均，以及随后静态posterior envelope的source乘积预算。初检完成，尚未读本轮作者稿，等待准确界后审；不作重复全面否证。

## 新Hhat几何命题：作者稿前独立核验通过（分支范围明确）

收到父级准确命题后，先独立推导，再窄核R128冻结proof.md:650–670的RT5/6和RT2固定行说明。原定义确为χ_s=1−s+sφ(1/2)、H0=g cj^−1/2 χ_s ell^(1/(2n))、Hhat=max(a,min(b,H0))、K0=P_s,Hhat、T=cj^(n/2)/(g^n√ell)；并非新选核。原far端点h=g exp(−u/n)、τ=a/cj，u为原预定非负near参数。故令θ=Hhat cj^(1/2)/(g ell^(1/(2n)))，有准确量纲身份

    K0(x−v)/T=∏_i[f_s((x_i−v_i)/Hhat)/θ]。

H0≥a时Hhat≤H0，故θ≤χ_s；closed Hhat-core内逐因子f_s≥χ_s，得到K0/T≥1。强capture余支满足Δ>B/T+Q/(rp)且B≥Dcal K0、Dcal≥1、Δ≤1，与之矛盾。因此该分支排除整个闭Q_Hhat(x)，进而排闭Q_a(x)。H0=a和H0=b的等号均在此域，core面不能用边界原子绕过。

若H0<a，则严格推出

    log(h/τ)<(3/2)logcj−logχ_s−[u+(1/2)logell]/n
             ≤cφ s−[u+(1/2)logell]/n，cφ=−logφ(1/2)<2。

这里−log[(1−s)+sφ(1/2)]≤s cφ是log凹性，cj≤1给第一项非正。cφ<2有解析证：对z≥0限制r∈[1/2,1]得w(z)≥(1/2)e^−2z，故φ(1/2)=∫_0^1w(z)dz≥(1−e^−2)/4>e^−2，后一不等式只需e²>5。因此s≤[u+(1/2)logell]/(2n)时，lower-clamp域的far严格为空，含该soft阈值等号。单点h=τ也不例外，因为此处已推出log(h/τ)<0。

准确全soft分割是：H0≥a域一律排Q_a；H0<a域在上述低s窗far空，剩下H0<a且s高于阈值的域未由这两个结论排除Q_a。不能将“统一排a-core”外推成全s无条件结论。该几何筛查既不证明后验envelope小，也不授根阶source预算；尚待作者准确命题/数值与最终整合审核。

## clock_source_budget.md作者稿后有限审核：通过

已完整读111行稿。CS3的阶段从实际非增右连续e过程起点重启，在半degree前保e_t≥e_start/2，w/Z非增给masked posterior≤2Π_start。端点分配下一阶段、跨多level删除只在实际新e上重启，均不漏dt质量。阶段pair引理给4Π_start(G)Π_start(B)≤1（G/B不交），故CS4为sqrt(2nLclk Nact)。保静态ρ0在target包络中同向，未另造source概率。

每次新阶段degree至少减半，所以Nact≤1+log2(e_l/e_h)正确；一次大删除可少于逐level阶段数，作者未将所有Nact版本都说成被旧行界覆盖。只有用CS5完全替代阶段数后，sqrt(A(1+B))≥min(A,B)证明其没有改善已有min{nL,logratio}（常数意义），范围准确。

CS7分连续weighted-source损失和真实删除质量的守恒式正确，归一stage仍要除当前degree。有限总loss不支付stage数或所有y/receiver复用；rank只属ν、共同cut/低N也没有自动Carleson覆盖常数。CS8的真实p_actualβ层用静态包络乘积Z分层，CS9外常数32Λ/3·sqrt(2nlog2)及2^(m+1)权正确；FIRST只给Σμ_m≤X，不给高m衰减。若capture包络依hardz，必须保原条件平均，不能预先当仅x/y层。

该稿只给合法阶段工具与真实receiver覆盖缺口，没有新原付款。67项Fraction是作者运行报告，未见归档独立脚本，本审核不称已独立重跑其断言；解析阶段论证不依这些有限样本。

## receiver_geometry.md作者稿后审核：主链通过

已全文读RG1–15及数值说明。RG3/4原K0/T量纲、clipping和θ范围正确；RG6排闭Hhat-core再排a-core、RG7–9 lower-clamp短far及严格空支与先行独立筛查一致。全soft覆盖是二分，不把高s的lower-clamp余支删去。RG6保固定Qa指示不需额外selector费用，但其所属H0≥a分支仍须保留。

RG10的正superlevel半径：f_s偶、径向非增且按闭hard core取上半连续版本，t_cap>0时正superlevel为闭区间；跳跃阈值和s=0均有相应零/核心分支。在非空capture盒内逐因子≥t_cap，产品达到Δ/Dcal，严格capture排除该盒合法。RG11两同心非空盒取max、RG12 hard cube包含判零均正确。已提醒作者：空capture盒记A_cap=0应明确不施加pointwise排除，不能把空盒强当闭Q0单点；RG12因R>0及RG13真实dx积分不受该零体积约定影响。

RG13准确为(∏I_i−∏I_i^exc)/R^n，不能换成∏(I_i−I_i^exc)。所有I_i>0时它等于full affinity乘(1−∏ζ_i)，故可将R224固定θ QG full上界乘同一非负因子，得到RG14；I_i=0先零。固定θ下Δ/Hhat/Aexc均静态，框架合法。实际θ(x)仍需qualified maximal-affinity/weighted covering桥；先Tonelli不等于该桥，没有给已消hard核上界再领QG。

RG15在lower-clamp有clock长度<2s，pair引理给sqrt(2nL)<2sqrt(ns)，保静态ρ_v及两份实际source-envelope质量；即使质量为常数，same-x FIRST也只给sqrt(n)X，未成为εX+rootWβ来源价。主稿/作者对其范围均未越界。

主proof几何/选择器范围已通读，提出给common-window的Hhat包含判零显式补“H0≥a branch”限定，避免其孤立充分条件被用于lower-clamp；一般RG12用Aexc无此问题。待最后修订/空间脚本后再绑定。

## geometry_checks源码及独立完整实际复跑：通过

已完整静审自足geometry_checks.py：真实E3 φ与E4 C、实际比例j、H0/Hhat/T/Δ、superlevel含hard跳的半径计算和两个共窗积分分片正确；40dps四例只核24项代数/窗口/旧D≤1检查，未给good/high/FULL资格。另50dps n512三例核10项clamp/clock边界诊断，正负far长度两侧与必要soft下界没有误作充分非空条件。原文明确R≤L同心hardB可使部分示例本来零，不登记新付款。

独立实际执行 geometry_checks.py --output /tmp/r228_audit_geometry_checks.json，exit0；原JSON全部4169字节完全一致，SHA256 `5ba989bb1215b88560fe858cc7e615c9f1c3653722f9579f7cfab0edfc820c77`。4个common-window+3个boundary、总34断言已核。普通mpmath求积和120步半径二分并非有向区间证书，全部一般几何结论仍由解析证明支持。

当前空间spatial脚本正在由父级补实际H_R检查，按其要求未提前终审该部分；本audit尚未冻结。

## 最终空间代码、真实hard补核与量词审核：通过

已完整静审spatial_probe.py最终算法和全部原始JSON。固定模型为b=L=R=g=cj=1、s=.05、K=256，ν=mgδv+muδu、β=ν+β0δ0；同一receiver的p、K1=K2、J、Q、两FIRST cap、high和good/bad均从真实φ/C产品计算，没有自由核值表。ν≤β在该点源模型中确实成立，但点源不构成原正L1/FULL历史。

采样每坐标先uniform，按概率s再加R密度2r的Laplace扰动，恰为固定fs；shift proposal用平移产品fs，log p0−logproposal给未归一重要性权，未作截断。pilot q存在诊断仅用于选三个固定q，validation使用新seed；确定点/fallback与sample-based冻结来源有明确标签，未把逐x变化q当固定q积分。普通20/40dps核检查只比较同一浮点坐标，不是区间资格。必要mass上界的Qcap/high代数方向、positive分母条件、beta cap和截断pair峰正确；它是逐点可变m/q的必要上界，不是同一来源或充分实现。tiny mg和β0导致的小proxy没有被称统一几何收益。

新增hard核确由同一ν计算：R=1时H_R=mg 1_Q1(v)+mu 1_Q1(u)，每个固定q联合门再核H_R>0以及H_R≤16q/3。含hard固定y代理乘β0 H_R/q，未遗漏hard质量或另选来源。它仍未含原history/capture/allocation/forest，亦非整个β所有中心的原交通。父级已将脚本/JSON总scope修为：原无hard proxy与单列hard proxy区分，含hard者只含模型H_R及可选cap，不冒充完整原量。

已解析最终JSON三模型×两proposal×三个固定q的18个验证记录，全部N=2048，joint且H_R>0及再加H_R≤16q/3的命中皆零；所有对应hard代理为零。原非hard联合概率约.091–.263并不表明真实hard交通被采到。零MC-SE只反映未命中，不是误差保证。direct p0单项95%零命中上界1−.05^(1/2048)可作普通有限binomial陈述，不能当同时置信或事件不存在；shift proposal严重退化，不能套p0的binomial界，也不以其较小SE作为可靠改进。numeric_notes对此均准确。

本独审未重复长空间运行。作者和父级报告曾对补hard算法版本完整重跑/包外重跑并整份JSON一致；本审核只把它记作他们的执行，不冒称亲自执行。最后一次scope文字更正同步脚本及预期JSON/script_sha256，数值字段未改；这份最终metadata版本的完整外移重放留给父级冻结后driver，不提前宣称完成。最终原JSON/代码/合同指纹已实核匹配。

## 最终文字修订、依赖与driver

receiver_geometry.md空盒记号已于RG11正文澄清：空capture盒A_cap=0只作尺寸记号，不施加点态排除，不把∅当Q0单点。真实dx积分中的单点不改变RG13。主proof common-window判零已显式限于H0≥a分支，lower-clamp剩余没有被误删；最终147行proof与报告也已加入hard零命中的有限证据范围。两处早前提出的修订均已落实，无遗留阻断。

最终geometry_checks.py保--output，数学算法与已独立实际复跑的4+3例/34断言一致，JSON仍为5ba989...c77；其最终源hash另绑定如下。source/selector预算仍未证明，不从geometry诊断或空间点源模型提升一般结论。三个Python AST和LaTeX环境静检通过，不编译PDF。

reproduce.py已完整静审：包外新目录复制geometry_checks/spatial_probe两个自足脚本、完整JSON比较、manifest前后核验、独立receipt。它继承运行环境，不安装新依赖。本机普通python3导入mpmath实测失败；父级已确认最终使用既有vendor的PYTHONPATH运行python3，并在README明确mpmath1.3依赖与已成功环境。此条件应随归档保留，不能把无mpmath的plain python3当现成完整复现命令。最终迁移执行及其receipt外置于README/归档，不需为该回执再改本audit。

## 最终受审文件SHA256与冻结

|文件|SHA256|
|---|---|
|task_contract.md|7ebdb587e1b3d566cf51aa22b72996d035e1779d36a897c0439a7ce448b17fde|
|proof.tex.txt|3cb937586700633f2ef72cdfae9be74b12d2f9939f705f83d076d9f860aede1c|
|report.md|605b7472706758e9e2c336b32e672b4e7fdae6e03e7263756952a5f05af02b85|
|receiver_geometry.md|917dc6467e46b976bd31180212a8aee332f9dcde5d024edf6111b74421e4950e|
|clock_source_budget.md|63495395ceb8ea43d8aac0de1355613a59412622f4f9b983dd47b228de95e473|
|geometry_checks.py|eed019928fd9e343626e7c0b3a5606401ae3ac9ec4246973187063d631e67b24|
|geometry_checks.json|5ba989bb1215b88560fe858cc7e615c9f1c3653722f9579f7cfab0edfc820c77|
|spatial_probe.py|2823532e600bcc8f34fb792a5c837e19428a1b816050c27f987e4e5cdb2e372a|
|spatial_probe.json|fa5602bca9f97838f11b8b8c24eb58b2bfd885496d74eb7f0cbbffe97df7692f|
|numeric_notes.md|80361e5dc48b8a4cce68c7c3bdc819c2446d1a8146abcaf9fb62f6f27935f4da|
|reproduce.py|9c1fcb698110279d0da2d1b08c0640bd50e1ed1fd98669327b603ab2efe73949|

**最终结论：上述受审范围通过，无剩余修复阻断。** 新pointwise clamp二分与共同窗口几何成立；固定θ QG到actual θ(x)的联合桥、实际posterior包络source价及整个强capture余支一般root付款仍未证。geometry独立实际复跑JSON一致；空间代码/原JSON量词已审核，未冒称亲自重复长运行。无活跃session。本audit冻结，停止写入，父级继续manifest、包外最终重放及归档。
