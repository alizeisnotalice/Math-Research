# R228：强捕获余支的统一接收几何与可计算共同窗口

本稿给出对全部实际参数成立的二分结构：未触发下截断时，原正余支统一排除目标来源的固定 `a` 核；触发下截断时，实际 far 时钟长度受软度控制，并有一个严格的充分空支。另给保真实 C、p、K0及hard来源的更精确排除盒和共同窗口积分模型。没有证明这些条件足以支付全部接收/来源积分；固定参数的QG积分没有被代入自适应参数而冒称全域预算。

## RG1 输入与不改变的原量

使用R227 LG8–17原余量：固定完整实际行及其未付正权，有

\[
 \Delta_{yv}=w_{\tau_j}(y,v)-w_h(y,v)
 >{\mathsf D K_{0,x}(v)+\alpha_0J_x(v)\over T}
   +{Q_x(v)\over r p_y(x)},\qquad
 \rho_0(v)\Delta_{yv}=
 \left(\Delta_{yv}-{\mathsf D K_0(v)+\alpha_0J(v)\over T}\right)_+.
 \tag{RG1}
\]

这里 `𝔇≥1` 是原capture参数，区别权差；`α0=𝔇q/∫Jdν≥0`。同时保原 high、good/bad、FIRST、原ρ及全部history：`p_y e_g≥2Kq`，`p_y w_g(v)≤KQ_v`，`KQ_u<p_yw_g(u)`，`∫pβ≤q`，`∫Qν≤q`。原positive含真实 `dx β(dy)ν(dz)Π(dv)Π(du)`，hard z不等于辅助v/u。

物理参数为

\[
 a\le L,R\le b\le2a,\quad g=\sqrt{LR},\quad
 \gamma=1+1/n,\quad c_j=\gamma^{-j}\le1,\quad
 c_{j+1}g\le m:=\min(L,R)\le c_jg,
\]
\[
 \tau_j=a/c_j,\qquad h=g e^{-u/n},\quad u>0,\qquad
 J_{far}=I_{j,V,y}\cap[\tau_j,h]. \tag{RG2}
\]

非空far须h>τ_j；端点相等的dt/t积分为零。u是原预先固定的窗口参数，不是辅助bad来源。以下不改变j、h或其选择资格。

记 `f_s=(1−s)1_[−1/2,1/2]+sφ`，`φ=h_1*w`，`w(z)=∫_0^1 exp(−|z|/r)dr`。置

\[
 \chi_s=1-s+s\phi(1/2),\quad \ell=1+\log n,\quad
 H_0=g c_j^{-1/2}\chi_s\ell^{1/(2n)},\quad
 \widehat H=\max\{a,\min(b,H_0)\},\quad
 T={c_j^{n/2}\over g^n\sqrt\ell},\quad
 K_0(v)=\widehat H^{-n}\prod_i f_s((x_i-v_i)/\widehat H).
 \tag{RG3}
\]

所有这些是原实际对象，不能由数值模型独立选取。

## RG2 精确capture坐标障碍

定义

\[
 \vartheta={\widehat H\over H_0}\chi_s
 ={\widehat H c_j^{1/2}\over g\ell^{1/(2n)}}.
\]

直接代入给无尺度损失的身份

\[
 \boxed{{K_0(v)\over T}
 =\prod_{i=1}^n{f_s((x_i-v_i)/\widehat H)\over\vartheta}.} \tag{RG4}
\]

有 `0<ϑ≤1`：若H0≥a，则Ĥ≤H0，故ϑ≤χ_s≤1（实际正soft时严格）；若H0<a，则Ĥ=a且 `ϑ=a√c_j/(g ell^{1/(2n)})<1`。在边界s=0且n>1，原H0≥g≥a，仍由具体参数判定；下文只需ϑ≤1。原n≥512没有ell=1退化。

RG1必有

\[
 {K_0(v)\over T}< {\Delta_{yv}\over\mathsf D}\le1. \tag{RG5}
\]

它是同一source displacement产生的Δ与实际receiver产品核之间的必要条件，不是任意独立阈值。完整RG1比RG5强，后面的盒只使用这个必要条件。

## RG3 全部实际参数的二分定理

### 第一支：H0≥a时，统一排除固定a核

此时Ĥ≤H0且Ĥ≥a。若 `|x_i−v_i|≤Ĥ/2` 对所有坐标成立，则f_s≥χ_s，RG4给

\[
 K_0(v)/T\ge(\chi_s/\vartheta)^n=(H_0/\widehat H)^n\ge1,
\]

与RG5矛盾。因此

\[
 \boxed{H_0\ge a\quad\Longrightarrow\quad
 x\notin Q_{\widehat H}(v)\quad\Longrightarrow\quad x\notin Q_a(v).} \tag{RG6}
\]

这不是固定θ积分结论：它逐原非零行成立，最后的 `1_{x∉Q_a(v)}` 不依实际L/R/s，可保在真实dx积分和所有选择器之外。包含H0=a及上截断H0>b；闭核心边界也被严格RG5排除。它不要求R≤L，故也作用于原hard-B没有核心排除的R>L支。

### 第二支：H0<a时，短far时钟及严格空支

由RG3及cj≤1，

\[
 \log{g\over\tau_j}
 <{3\over2}\log c_j-\log\chi_s-{\log\ell\over2n}
 \le-\log\chi_s-{\log\ell\over2n}.
\]

再保真实上端h=gexp(−u/n)，非空far必须满足

\[
 \boxed{0<\mathcal L:=\log{h\over\tau_j}
 <{3\over2}\log c_j-\log\chi_s
       -{u+\frac12\log\ell\over n}
 \le c_\phi s-{u+\frac12\log\ell\over n},\quad
 c_\phi=-\log\phi(1/2).} \tag{RG7}
\]

最后一步是凸函数 `−log(1−(1−φ(1/2))s)` 在[0,1]上不超过端点弦。故

\[
 \boxed{H_0<a,\ J_{far}\ne\varnothing\text{（正时长）}
 \quad\Longrightarrow\quad
 s>{u+\frac12\log\ell\over n c_\phi},\qquad
 \mathcal L<c_\phi s<2s.} \tag{RG8}
\]

`cφ<2`不依数值：r∈[1/2,1]给 `w(z)≥e^{-2z}/2`（z≥0），所以
`φ(1/2)=∫_0^1w(z)dz≥(1−e^{-2})/4>e^{-2}`，其中e²>5可由指数级数前三项加正余项得出。因此有保守、完全精确的充分空支

\[
 \boxed{H_0<a,\quad s\le {u+\frac12\log\ell\over2n}
 \quad\Longrightarrow\quad J_{far}\text{无正时长}.} \tag{RG9}
\]

它是充分空支，不能把其补集称为充分非空条件。一般仍须检查h>τ_j及原I_{j,V,y}。RG6与RG7–9穷尽原全部clipping分支；没有遗漏H0=a等号或将辅助t当成物理L。

## RG4 更精确的排除盒与零共同窗口

固定一个实际行的物理参数及y,v，使Δ>0。令

\[
 t_{cap}=\vartheta(\Delta_{yv}/\mathsf D)^{1/n}.
\]

若t_cap>f_s(0)，以下capture盒为空，不授任何核心排除。否则定义非增偶函数f_s的闭superlevel半径

\[
 r_s(t)=\sup\{r\ge0:f_s(r)\ge t\},\qquad
 A_{cap}=2\widehat H r_s(t_{cap}). \tag{RG10}
\]

f_s在1/2的hard跳跃按原闭核心处理；若 `sφ(1/2)<t≤χ_s`，半径恰为1/2。t>χ_s时可能小于1/2，t≤sφ(1/2)时可超过1/2。零半径盒至多一个点，不提供正体积排除。

在Q_Acap(v)内各坐标f_s≥t_cap，所以RG4给K0/T≥Δ/𝔇，与RG5矛盾。因而RG10给逐行真实排除 `x∉Q_Acap(v)`。RG6是H0≥a时不依Δ的统一较弱版本；不能将它跨到H0<a。

原硬capture还给 `B_hard(v)=1_{R≤L}1_{Q_R(x)}(v)=0`。两个被排除盒同心且各向同性，故可统一为边长

\[
 A_{exc}=\max\{A_{cap},\ R1_{\{R\le L\}}\}, \tag{RG11}
\]

其中空capture盒取A_cap=0仅作尺寸记号；此时不施加任何点态排除，不能把空集认作Q_0(v)单点。积分中的单点零测不改变积分公式。实际hard来源还有 `x∈Q_R(z)`。因此若

\[
 \boxed{A_{exc}\ge R,\qquad
 \|z-v\|_\infty\le(A_{exc}-R)/2,} \tag{RG12}
\]

则Q_R(z)⊂Q_Aexc(v)，这一组实际参数和来源的正交通为零。条件在每个实际x计算时是合法必要几何，不将所有x的参数冻结为同一个值。

## RG5 保hard来源的固定参数模型与QG的准确用法

现在仅为可计算共同窗口模型，固定全部物理参数及y,v,z；不再把它写成θ(x)。给一条实际测试腿 `K_A=P_{σ,A}(x−v)`，其中A∈[L,b]，主两腿σ=s，J腿σ=1。令

\[
 I_i=\int_{z_i-R/2}^{z_i+R/2}
 \sqrt{L^{-1}f_s((x_i-y_i)/L)A^{-1}f_\sigma((x_i-v_i)/A)}\,dx_i,
\]
\[
 I_i^{exc}=\int_{[z_i-R/2,z_i+R/2]\cap[v_i-A_{exc}/2,v_i+A_{exc}/2]}
 \sqrt{L^{-1}f_s((x_i-y_i)/L)A^{-1}f_\sigma((x_i-v_i)/A)}\,dx_i.
\]

同一个hard cube内，准确有

\[
 \int h_R(x-z)\sqrt{p_y(x)K_A(x-v)}1_{x\notin Q_{Aexc}(v)}dx
 ={\prod_i I_i-\prod_i I_i^{exc}\over R^n}. \tag{RG13}
\]

不是各坐标差的乘积。若某I_i=0，整项为零；否则记ζ_i=I_i^exc/I_i∈[0,1]。R224 QG、m=min(L,R)、M=max(L,R)给

\[
 \text{RG13}\le M^{-n}\sqrt{\bar w_m(y,v)}
 \exp\left[-{\kappa\over2}\sum_i(1-\omega_{m,i})\right]
 \left(1-\prod_i\zeta_i\right),\quad
 \omega_{m,i}=\min\{1,bC(|y_i-v_i|/b)/m\},\quad
 \kappa=25/2^{68}. \tag{RG14}
\]

这同时保真实threshold overlap及capture共同窗口损失。RG12恰对应所有ζ_i=1。它适用于从原positive、hard z仍在时开展receiver-first Tonelli的路线；不能对R222/226已经用16/3消去hard来源的上界，再乘一次这个QG收益。

固定(j,y,t)时，原ν、Π/e/k不依x，故先积分receiver合法。但RG14只在L/R/s/g及排除盒固定时成立。实际这些参数依x；即使按选择器fiber分解，每个fiber的固定参数上界直接相加仍要付所有fiber共同占用。RG6的固定Qa排除和RG7的时长约束可以无此费用逐点保留，RG14本身不能免费升级成qualified maximal-affinity估计。

## RG6 与原预算的准确接口和仍缺的共同费用

在下截断支，R227 weighted pair-envelope定理和RG8给每个实际行、静态capture权ρ_v及实际包络A_y(v)≥sup_t1Z_t(v)w_t(v)/e_t(y)，

\[
 \int_{J_{far}}\rho_v\delta_t
 {1Z_t(v)1Z_t(u)w_t(v)w_t(u)\over e_t(y)^2}{dt\over t}
 \le2\sqrt{ns}\,\rho_v A_y(v)A_y(u). \tag{RG15}
\]

这精确保留了smallsoft与短clock的联系。对来源积分后仍有 `(∫_GρA dν)(∫_B A dν)`；不能由逐时Π归一把这两个static envelope质量设为1。原外权 `p_yβ(dy)h_R(x−z)a_ω/q` 和实际dx依旧存在。即使这两个质量有常数界，直接用FIRST也只是√nX，不是εX加√nWβ；还须一个真实receiver/source付款。

在非下截断支，RG6允许在原原式中保固定 `1_{|x−v|∞>a/2}`，RG12–14还能精确删除部分共窗来源。现有工具未证明这个受约束的自适应共同窗口占用有根阶来源价。第一处未获授权的步骤正是：将RG14的固定参数x积分改为原θ(x)的共同source/receiver积分，或者以同一已消hard核再次支付。

因此本稿的正向一般结构是RG6–9及其实际共同窗口后果，不是全局闭合。所需下一预算必须在同一个真实ν/β、原pβ/q、高pe和capture支持下控制这两支的receiver占用；不能用任意两源scalar阈值模型替代共同空间核。

## RG7 可直接交数值的实际空间模型

固定b并用它归一，令 `a_i=(x_i−y_i)/b`、`d_i=(v_i−y_i)/b`、`z_i'=(z_i−y_i)/b`，另保bad点u的真实坐标。所有C阈值必须由同一d_i计算，不独立选择：

\[
 w_t(y,v)=\prod_i\min\{1,bC(|d_i|)/(c_jt)\},\quad
 p_y=L^{-n}\prod_i f_s(ba_i/L),
\]

K1、K2、J和K0分别将同一 `b(a_i−d_i)` 代入L、L^+、b、Ĥ。Q必须取三个真实产品的平均；T、H0、α0及Δ按RG2–3/原共享ν重算。候选source权须共同满足ν≤β，FIRST/high/good/bad/强余支和hardband逐个检验；给定Z必须来自已认证原共同partition及history，不能任选对称mask后声称FULL。

对固定候选θ，RG13是低成本可复现接收模型；对实际自适应θ，必须在同一个x网格上重新计算全部共同测试、Δ、capture和hard源窗口，再对同一个来源集合积分。有限候选参数只能给该有限模型的诊断，不认证全部selector费用。点源/小盒近似必须标为必要空间模型，除非原cut、rank、heavy、历史和真实dx误差也全部认证。

实际执行结果：40位mpmath对4组真实φ/C参数完成24项断言，核对RG4、superlevel窗口差及R220 D≤1；其中s=1、H0<a时capture盒长度.357344小于Ĥ=.5，证实不可误用完整Ĥ核心。另在n=512以50位运行3组边界诊断、10项断言，包含同一lowerclamp的非空/空far两侧。结果和可复现代码如下；均非FULL例、不拟合维数阶。

| n,L,R,s | H0 | Ĥ | A_cap | 同心hard窗口剩余比例 |
|---|---:|---:|---:|---:|
| 16,1,.6,.3 | .7447742659 | .7447742659 | .7447742659 | 0 |
| 16,1,1,1 | .4068435851 | .5 | .3573443951 | .9999998582 |
| 32,.8,.55,.05 | .7219839020 | .7219839020 | .7219839020 | 0 |
| 8,.5,.8,.6 | .4564062646 | .5 | .5 | .9315024436 |

表中使用𝔇=1、所有坐标相同位移、z=v，只检查capture盒窗口；不能把这些行说成通过了good/high或原B全部资格。前两组被原hardB排除的同心行也不登记为新增付款。

n=512的L=R=.75、s=.6给H0=.4765589123495579<a；取 `u=512log(1.5)∓.001`，实际 `log(h/τ)=±.000001953125`，正负两侧均正确处理。L=1,R=.6,s=.2,u=.1给j=130、H0=.7736087482549433≥a、far对数长度.1838804391129225。这里 `φ(.5)=.390308032802239863`、`cφ=.940819023910148719` 是实际数值，RG7–9的证明不依赖它们的浮点近似。

可复现脚本（只依赖mpmath；本次使用用户现有vendor和bundled Python）。第一段40位、第二段50位；所有断言已经实际运行：

```python
import mpmath as m
m.mp.dps = 40

def E(k, x):
    return m.mpf(1)/(k-1) if x == 0 else m.expint(k, x)

def phi(x):
    x = abs(x)
    if x <= m.mpf('.5'):
        return 1-E(3, m.mpf('.5')-x)-E(3, m.mpf('.5')+x)
    return E(3, x-m.mpf('.5'))-E(3, x+m.mpf('.5'))

def C(d):
    d = abs(d)
    if d <= 1:
        return 1-d+E(4, 0)-E(4, d)-E(4, 1)+E(4, d+1)
    return E(4, d-1)-2*E(4, d)+E(4, d+1)

def f(s, x):
    return (1-s)*(abs(x) <= m.mpf('.5'))+s*phi(x)

def radius(s, t):
    if t > f(s, 0): return None
    if s == 0: return m.mpf('.5')
    if s*phi(m.mpf('.5')) < t <= f(s, m.mpf('.5')):
        return m.mpf('.5')
    lo, hi = m.mpf(0), m.mpf(1)
    while f(s, hi) >= t: hi *= 2
    for _ in range(120):
        mid = (lo+hi)/2
        if f(s, mid) >= t: lo = mid
        else: hi = mid
    return (lo+hi)/2

def integ(fn, lo, hi, breaks):
    if lo >= hi: return m.mpf(0)
    cuts = [lo]+sorted({q for q in breaks if lo < q < hi})+[hi]
    return sum(m.quad(fn, [a, b]) for a, b in zip(cuts, cuts[1:]))

checks = 0
cases = [(16,'1','.6','.3','.9'), (16,'1','1','1','.6'),
         (32,'.8','.55','.05','.8'), (8,'.5','.8','.6','.9')]
for n, ls, rs, ss, ds in cases:
    L,R,s,d = map(m.mpf, (ls,rs,ss,ds))
    a,g,gam = m.mpf('.5'),m.sqrt(L*R),1+m.mpf(1)/n
    j = int(m.floor(m.log(g/min(L,R))/m.log(gam)))
    cj,tau = gam**(-j),a*gam**j
    h = g*m.exp(-m.mpf('.1')/n)
    if h <= tau: continue
    chi,ell = 1-s+s*phi(m.mpf('.5')),1+m.log(n)
    H0 = g/cj**m.mpf('.5')*chi*ell**(m.mpf(1)/(2*n))
    H = max(a,min(1,H0))
    T = cj**(m.mpf(n)/2)/(g**n*m.sqrt(ell))
    theta = H*cj**m.mpf('.5')/(g*ell**(m.mpf(1)/(2*n)))
    w = lambda t: min(1,C(d)/(cj*t))**n
    Delta = w(tau)-w(h)
    if Delta <= 0: continue
    assert 0 < theta < 1
    checks += 1
    for x in (m.mpf(0),m.mpf('.3'),m.mpf('1.1')):
        assert m.almosteq((f(s,(x-d)/H)/H)**n/T,
                         (f(s,(x-d)/H)/theta)**n,
                         rel_eps=m.mpf('1e-35'))
        checks += 1
    rc = radius(s,theta*Delta**(m.mpf(1)/n))
    Acap = 0 if rc is None else 2*H*rc
    z,A = d,min(1,gam*L)
    fn = lambda x: m.sqrt(f(s,x/L)*f(s,(x-d)/A)/(L*A))
    br = [-L/2,L/2,d-A/2,d+A/2]
    lo,hi = z-R/2,z+R/2
    I = integ(fn,lo,hi,br)
    cl,ch = max(lo,d-Acap/2),min(hi,d+Acap/2)
    Ic = integ(fn,cl,ch,br)
    outside = (integ(fn,lo,min(hi,cl),br)+integ(fn,max(lo,ch),hi,br)
               if cl < ch else I)
    assert m.almosteq(I-Ic,outside,abs_eps=m.mpf('1e-32'))
    omega = min(1,C(d)/min(L,R))
    assert max(L,R)*I/(R*m.sqrt(omega)) <= 1+m.mpf('1e-25')
    checks += 2
    print(n,ls,rs,ss,'H0/H/Delta/Acap/remain:',
          *[m.nstr(q,12) for q in (H0,H,Delta,Acap,1-(Ic/I)**n)])
print('common-window checks:',checks)  # 24

m.mp.dps = 50
n,a,ell = 512,m.mpf('.5'),1+m.log(512)
gam,cphi = 1+m.mpf(1)/n,-m.log(phi(m.mpf('.5')))
checks = 0
cases = [('lower_nonempty','.75','.75','.6',-m.mpf('.001')),
         ('lower_empty','.75','.75','.6',m.mpf('.001')),
         ('upper_nonempty','1','.6','.2',None)]
for label,ls,rs,ss,du in cases:
    L,R,s = map(m.mpf,(ls,rs,ss))
    g = m.sqrt(L*R)
    j = int(m.floor(m.log(g/min(L,R))/m.log(gam)))
    cj,tau = gam**(-j),a*gam**j
    u = n*m.log(g/tau)+du if du is not None else m.mpf('.1')
    h,chi = g*m.exp(-u/n),1-s+s*phi(m.mpf('.5'))
    H0 = g/cj**m.mpf('.5')*chi*ell**(m.mpf(1)/(2*n))
    H,logfar = max(a,min(1,H0)),m.log(h/tau)
    bound = m.mpf('1.5')*m.log(cj)-m.log(chi)-m.log(ell)/(2*n)-u/n
    assert 0 < cj <= 1
    assert -m.log(chi) <= s*cphi
    checks += 2
    if H0 < a:
        assert logfar < bound
        checks += 1
        if logfar > 0:
            assert s > (u+m.log(ell)/2)/(n*cphi)
            checks += 1
    else:
        assert a <= H <= H0
        checks += 1
    print(label,j,*[m.nstr(q,18) for q in (H0,H,u,logfar,bound)])
print('n=512 boundary checks:',checks)  # 10
```

代码中的E_k是广义指数积分。使用 `φ(x)=1−E3(1/2−|x|)−E3(1/2+|x|)`（核心内）及尾部差，C由对F=max(h,φ)的真实积分得到；没有把C替成任意标量重叠。有限浮点检查不代替RG3–14的解析证明。

正式可复现文件为同目录 `geometry_checks.py`，实际输出为 `geometry_checks.json`；脚本保每组真实参数、clipping、clock和窗口结果。已运行4组共同窗口及3组n=512边界诊断，共34项所列断言通过；这是实际例数，不作抽样覆盖或维数阶推断。
