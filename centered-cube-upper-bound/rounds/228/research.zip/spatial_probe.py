#!/usr/bin/env python3
"""Finite true-spatial-kernel gate diagnostics with frozen-q independent validation."""
import argparse,hashlib,json,math,random
from pathlib import Path
import mpmath as mp
HERE=Path(__file__).resolve().parent
SOURCE_FINGERPRINTS={'task_contract.md': '7ebdb587e1b3d566cf51aa22b72996d035e1779d36a897c0439a7ce448b17fde', 'R225_frozen_numeric_probe.py': '7d3183037ab8911058a4bbc7e70c252d20a6a9ec04f0ca03a7e4bd2dbbf5105f'}
S=.05;K=256.;MG=1e-6;MU=1.;BETA0=1e-10;SHIFT=.125

def phi(x):
    x=abs(mp.mpf(x));h=mp.mpf('.5')
    def E3(t):return h if t==0 else ((1-t)*mp.exp(-t)+t*t*mp.e1(t))/2
    return 1-E3(h-x)-E3(h+x) if x<=h else E3(x-h)-E3(x+h)
def primitiveF(x):
    x=mp.mpf(x);sg=mp.sign(x);t=abs(x);h=mp.mpf('.5')
    return x if t<=h else sg*(h-mp.expint(4,t-h)+mp.expint(4,t+h)+mp.mpf(1)/3-mp.expint(4,1))
def C(d):return primitiveF(mp.mpf('.5')-abs(d))-primitiveF(-mp.mpf('.5')-abs(d))
def logsum(xs):
    z=max(xs);return z+math.log(sum(math.exp(x-z) for x in xs))
def logkernels(x):
    p=phi(x);lp=float(mp.log(p));lf=math.log((1-S)+S*float(p)) if abs(x)<=.5 else math.log(S)+lp
    return lf,lp

def setup(n,mode):
    vs=[.9]*n if mode=='homogeneous' else [.65 if i%2==0 else 1.15 for i in range(n)];us=[-.25]*n if mode=='homogeneous' else [-.1 if i%2==0 else -.4 for i in range(n)]
    with mp.workdps(50):
      cv=[C(mp.mpf(str(x))) for x in vs];cu=[C(mp.mpf(str(abs(x)))) for x in us];logwg_v=float(sum(mp.log(x) for x in cv));logwg_u=float(sum(mp.log(x) for x in cu));logeg=logsum([math.log(MG)+logwg_v,math.log(MU)+logwg_u]);clocks=[]
      for t in (.5,.75):
        tm=mp.mpf(str(t));lv=float(sum(mp.log(min(1,x/tm)) for x in cv));lu=float(sum(mp.log(min(1,x/tm)) for x in cu));kv=sum(x<tm for x in cv);ku=sum(x<tm for x in cu);et=logsum([math.log(MG)+lv,math.log(MU)+lu]);pv=math.exp(math.log(MG)+lv-et);pu=math.exp(math.log(MU)+lu-et)
        clocks.append({'t':t,'k_v':kv,'k_u':ku,'delta_positive':max(kv-ku,0),'log_wt_v':lv,'log_wt_u':lu,'log_et':et,'Pi_v':pv,'Pi_u':pu,'clock_proxy_factor_delta_Piv_Piu':max(kv-ku,0)*pv*pu})
      chi=1-mp.mpf(str(S))+mp.mpf(str(S))*phi(mp.mpf('.5'));Hhat=max(mp.mpf('.5'),min(mp.mpf(1),chi));theta=chi*Hhat/chi
      meta={'n':n,'mode':mode,'v':vs,'u':us,'s':S,'K':K,'nu_masses':{'v':MG,'u':MU},'beta_extra_y0_mass':BETA0,'beta_equals_nu_plus_positive_y0':True,'alpha_v_C': [mp.nstr(x,40) for x in cv],'alpha_u_C':[mp.nstr(x,40) for x in cu],'log_wg_v':logwg_v,'log_wg_u':logwg_u,'log_eg':logeg,'clocks':clocks,'capture_ell1_parameters':{'ell':'1','chi':mp.nstr(chi,40),'H0':mp.nstr(chi,40),'Hhat':mp.nstr(Hhat,40),'theta':mp.nstr(theta,40),'K0_over_T_formula':'product f_s((x_i-v_i)/Hhat)/theta per coordinate; T=1 here'}}
    return meta

def features(x,meta,proposal_shift=0.):
    lp0=lpv=lpu=ljv=lju=lprop=0.
    for xx,v,u in zip(x,meta['v'],meta['u']):
      f0,_=logkernels(xx);fv,jv=logkernels(xx-v);fu,ju=logkernels(xx-u);lp0+=f0;lpv+=fv;lpu+=fu;ljv+=jv;lju+=ju
      if proposal_shift:lprop+=logkernels(xx-proposal_shift)[0]
    lQv=logsum([math.log(2)+lpv,ljv])-math.log(3);lQu=logsum([math.log(2)+lpu,lju])-math.log(3);lfb=logsum([math.log(MG)+lpv,math.log(MU)+lpu,math.log(BETA0)+lp0]);lqnu=logsum([math.log(MG)+lQv,math.log(MU)+lQu]);lqmin=max(lfb,lqnu);lqmax=lp0+meta['log_eg']-math.log(2*K);good=lp0+meta['log_wg_v']<=math.log(K)+lQv;bad=math.log(K)+lQu<lp0+meta['log_wg_u']
    hard_v=all(abs(xx-v)<=.5 for xx,v in zip(x,meta['v']));hard_u=all(abs(xx-u)<=.5 for xx,u in zip(x,meta['u']));hard=MG*hard_v+MU*hard_u
    return {'hard_H_R':hard,'hard_v_support':hard_v,'hard_u_support':hard_u,'lp0':lp0,'log_Pv':lpv,'log_Pu':lpu,'log_Qv':lQv,'log_Qu':lQu,'lp_proposal':lprop if proposal_shift else lp0,'log_cap_beta':lfb,'log_cap_Qnu':lqnu,'log_qmin':lqmin,'log_qmax':lqmax,'good':good,'bad':bad,'necessary_joint_exists_q':good and bad and lqmin<=lqmax,'good_log_margin':math.log(K)+lQv-lp0-meta['log_wg_v'],'bad_log_margin':lp0+meta['log_wg_u']-math.log(K)-lQu}

def draw(n,rng,shift):
    out=[]
    for _ in range(n):
      x=rng.random()-.5
      if rng.random()<S:
        r=math.sqrt(rng.random());x+=(-1 if rng.random()<.5 else 1)*(-r*math.log(1-rng.random()))
      out.append(x+shift)
    return out

def necessary_mass_diagnostic(f,meta):
    """Pointwise necessary upper bound only; mass and admissible q may vary with x."""
    p0,Pv,Pu,Qv,Qu=[math.exp(f[k]) for k in ('lp0','log_Pv','log_Pu','log_Qv','log_Qu')]
    gv,gu=math.exp(meta['log_wg_v']),math.exp(meta['log_wg_u'])
    dq=Qv-p0*gv/(2*K);rq=p0*gu/(2*K)-Qu
    dp=Pv-p0*gv/(2*K);rp=p0*gu/(2*K)-Pu-BETA0*p0
    applicable=f['good'] and dq>0
    upper=max(0.,rq/dq) if applicable else None
    beta_upper=max(0.,rp/dp) if dp>0 else None
    if applicable and beta_upper is not None:upper=min(upper,beta_upper)
    clocks=[]
    if upper is not None:
      for c in meta['clocks']:
        balance=math.exp(c['log_wt_u']-c['log_wt_v']);mstar=min(upper,balance)
        ratio=mstar/balance;pair=ratio/(1+ratio)**2
        clocks.append({'t':c['t'],'balance_mass':balance,'mass_maximizing_pair_within_necessary_upper':mstar,'posterior_pair_upper':pair,'positive_score_proxy_upper':c['delta_positive']*pair,'fixed_mass_positive_score_proxy':c['clock_proxy_factor_delta_Piv_Piu']})
    return {'scope':'Pointwise-adaptive mass/q necessary envelope only; not sufficient, not a fixed source or fixed-q integral. mu=1 and beta0 unchanged.', 'Qcap_denominator':dq,'Qcap_rhs':rq,'Qcap_denominator_ge_Qv_over_2_numerically':dq>=Qv/2-1e-14*Qv if f['good'] else None,'beta_cap_denominator':dp,'beta_cap_rhs':rp,'beta_upper_applied_only_if_denominator_positive':beta_upper,'applicable_on_good':applicable,'mass_upper_both_applicable_caps':upper,'fixed_mass_below_necessary_upper':MG<=upper if upper is not None else None,'clock_pair_envelopes':clocks}

def diagonal_witnesses(meta):
    rows=[]
    with mp.workdps(40):
      H=mp.mpf(meta['capture_ell1_parameters']['Hhat']);theta=mp.mpf(meta['capture_ell1_parameters']['theta'])
      for xx in (-.45,-.25,0.,.1,.2,.3,.4,.49,.6):
        x=[xx]*meta['n'];f=features(x,meta);lk=mp.mpf(0)
        for v in meta['v']:
          z=(mp.mpf(str(xx))-mp.mpf(str(v)))/H;ff=(1-mp.mpf(str(S)) if abs(z)<=mp.mpf('.5') else 0)+mp.mpf(str(S))*phi(z);lk+=mp.log(ff)-mp.log(theta)
        row={'all_coordinates_x':xx,**f,'pointwise_mass_diagnostic':necessary_mass_diagnostic(f,meta),'log_K0_over_T_ell1':float(lk),'capture_scope':'Necessary kernel ratio only; actual history, alphaJ and clock-D capture not certified.'};rows.append(row)
    return rows

def pilot(meta,N,seed,shift=0.):
    rng=random.Random(seed);hits=0;midqs=[];good=bad=high_possible=0
    with mp.workdps(20):
      for _ in range(N):
        f=features(draw(meta['n'],rng,shift),meta,shift);good+=f['good'];bad+=f['bad'];high_possible+=f['log_qmin']<=f['log_qmax']
        if f['necessary_joint_exists_q']:hits+=1;midqs.append((f['log_qmin']+f['log_qmax'])/2)
    return {'N':N,'seed':seed,'proposal_shift':shift,'good_hits':good,'bad_hits':bad,'exists_q_high_hits':high_possible,'necessary_joint_hits':hits,'mid_log_qs_for_freeze':midqs,'scope':'Pilot selection only; pointwise qmin/qmax is not a fixed-q traffic result.'}

def freeze(pilots,diags):
    values=sorted(v for p in pilots for v in p['mid_log_qs_for_freeze'])
    if len(values)>=3:
      qlogs=[values[int((len(values)-1)*f)] for f in (.25,.5,.75)];origin='pilot admissible interval midpoint log-q quantiles'
    else:
      witnesses=[r for r in diags if r['necessary_joint_exists_q']]
      if witnesses:
        row=max(witnesses,key=lambda r:r['log_qmax']-r['log_qmin']);qlogs=[row['log_qmin']+f*(row['log_qmax']-row['log_qmin']) for f in (.25,.5,.75)];origin='deterministic feasible witness interval quartiles'
      else:
        row=min(diags,key=lambda r:r['log_qmin']-r['log_qmax']);qlogs=[(row['log_qmin']+row['log_qmax'])/2+x for x in (-.1,0,.1)];origin='fallback nearest diagnostic, no admissibility assertion'
    return {'origin':origin,'pilot_feasible_count':len(values),'fixed_log_q':qlogs,'fixed_q':[math.exp(x) for x in qlogs],'frozen_before_validation':True,'independent_new_seeds':True}

def validate(meta,frozen,N,seed,shift):
    rng=random.Random(seed);Nq=len(frozen['fixed_log_q']);sums=[0.]*Nq;sums2=[0.]*Nq;hits=[0]*Nq;gatecounts=[{'FIRST_beta':0,'FIRST_Qnu':0,'high':0,'good':0,'bad':0} for _ in range(Nq)];sumw=sumw2=0.;maxx=0.;minlp=0.;ambiguous=0
    hardhits=[0]*Nq;eligiblehits=[0]*Nq;hardprob=[0.]*Nq;hardprob2=[0.]*Nq;hardsum=[0.]*Nq;hardsum2=[0.]*Nq;eligiblesum=[0.]*Nq;eligiblesum2=[0.]*Nq
    with mp.workdps(20):
      for _ in range(N):
        x=draw(meta['n'],rng,shift);f=features(x,meta,shift);lw=f['lp0']-f['lp_proposal'];w=math.exp(lw);sumw+=w;sumw2+=w*w;maxx=max(maxx,max(abs(v) for v in x));minlp=min(minlp,f['lp0'],f['lp_proposal'])
        for j,lq in enumerate(frozen['fixed_log_q']):
          fb=f['log_cap_beta']<=lq;fq=f['log_cap_Qnu']<=lq;hi=lq<=f['log_qmax'];joint=fb and fq and hi and f['good'] and f['bad'];gatecounts[j]['FIRST_beta']+=fb;gatecounts[j]['FIRST_Qnu']+=fq;gatecounts[j]['high']+=hi;gatecounts[j]['good']+=f['good'];gatecounts[j]['bad']+=f['bad']
          margins=[lq-f['log_cap_beta'],lq-f['log_cap_Qnu'],f['log_qmax']-lq,f['good_log_margin'],f['bad_log_margin']];ambiguous+=any(abs(a)<1e-10 for a in margins)
          if joint:
            hits[j]+=1;sums[j]+=w;sums2[j]+=w*w
            if f['hard_H_R']>0:
              hardhits[j]+=1;hardprob[j]+=w;hardprob2[j]+=w*w
              hw=w*f['hard_H_R'];hardsum[j]+=hw;hardsum2[j]+=hw*hw
              if f['hard_H_R']<=16*math.exp(lq)/3:
                eligiblehits[j]+=1;eligiblesum[j]+=hw;eligiblesum2[j]+=hw*hw
    rows=[]
    for j,lq in enumerate(frozen['fixed_log_q']):
      mean=sums[j]/N;var=max(0.,(sums2[j]-sums[j]**2/N)/(N-1));se=math.sqrt(var/N);proxies=[]
      for c in meta['clocks']:
        factor=c['clock_proxy_factor_delta_Piv_Piu'];positive=c['delta_positive']>0;fact=factor if positive else 0.;firstfactor=BETA0/math.exp(lq)
        hm=hardsum[j]/N;hse=math.sqrt(max(0.,(hardsum2[j]-hardsum[j]**2/N)/(N-1))/N);em=eligiblesum[j]/N;ese=math.sqrt(max(0.,(eligiblesum2[j]-eligiblesum[j]**2/N)/(N-1))/N)
        proxies.append({'t':c['t'],'positive_score':positive,'receiver_probability_all_gates':mean if positive else 0.,'receiver_probability_SE':se if positive else 0.,'raw_clock_proxy_E_p0_delta_Piv_Piu':fact*mean,'raw_clock_proxy_SE':fact*se,'fixed_y_FIRST_proxy_integral_p0_beta0_over_q_delta_Piv_Piu':firstfactor*fact*mean,'fixed_y_FIRST_proxy_SE':firstfactor*fact*se,'hard_fixed_y_proxy_integral_p0_beta0_HR_over_q_delta_Piv_Piu':firstfactor*fact*hm,'hard_fixed_y_proxy_MC_SE':firstfactor*fact*hse,'hard_qualified_proxy_HR_le_16q_over_3':firstfactor*fact*em,'hard_qualified_proxy_MC_SE':firstfactor*fact*ese})
      rows.append({'fixed_log_q':lq,'fixed_q':math.exp(lq),'raw_joint_hits':hits[j],'joint_hard_positive_raw_hits':hardhits[j],'joint_hard_positive_probability_estimate':hardprob[j]/N,'joint_hard_positive_probability_MC_SE':math.sqrt(max(0.,(hardprob2[j]-hardprob[j]**2/N)/(N-1))/N),'joint_hard_positive_and_HR_le_16q_over_3_raw_hits':eligiblehits[j],'hard_scope':'Same nu hard kernel HR=mg 1_Q1(v)+mu 1_Q1(u); proxy includes beta0 HR/q, without history/capture/allocation.','gate_raw_counts':gatecounts[j],'p0_probability_estimate':mean,'probability_MC_SE':se,'event_ESS':sums[j]**2/sums2[j] if sums2[j] else 0.,'zero_hits_not_evidence_of_absence':hits[j]==0,'zero_hit_binomial_95_upper_ordinary_eval_if_p0':1-.05**(1/N) if hits[j]==0 and shift==0 else None,'clock_traffic_proxies':proxies})
    return {'N':N,'seed':seed,'proposal_shift_all_coordinates':shift,'sampling_law':'p0' if shift==0 else 'product p_s(x_i-shift)','likelihood_weight':'1' if shift==0 else 'exp(log p0 - log proposal), unnormalized importance estimator','global_weight_mean':sumw/N,'global_ESS':sumw*sumw/sumw2,'importance_degeneracy_warning':('Low ESS: unseen likelihood-weight tails can invalidate apparent MC-SE reliability; do not prefer this over direct p0 sampling.' if shift!=0 and sumw*sumw/sumw2<N/10 else None),'max_abs_sample_coordinate':maxx,'minimum_log_product_density':minlp,'near_gate_boundary_comparisons_under_1e_minus10':ambiguous,'results':rows,'error_scope':'p0 samples use binomial sampling error; shifted samples use weighted iid sample variance and ESS, not binomial. No certified confidence interval or rare-event absence claim.'}

def precision_audit(meta,frozen,seed):
    rng=random.Random(seed);maxdiff=0.;mismatches=0
    for _ in range(16):
      x=draw(meta['n'],rng,0.)
      with mp.workdps(20):low=features(x,meta)
      with mp.workdps(40):high=features(x,meta)
      for key in ('lp0','log_cap_beta','log_cap_Qnu','log_qmax','good_log_margin','bad_log_margin'):maxdiff=max(maxdiff,abs(low[key]-high[key]))
      for q in frozen['fixed_log_q']:
        def selected(f):return f['good'] and f['bad'] and f['log_cap_beta']<=q and f['log_cap_Qnu']<=q<=f['log_qmax']
        mismatches+=selected(low)!=selected(high)
    return {'points':16,'seed':seed,'kernel_dps_compared':[20,40],'maximum_log_feature_difference':maxdiff,'frozen_q_joint_classification_mismatches':mismatches,'scope':'Ordinary precision cross-check only, not interval gate certification.'}

def main(output):
    stages=[]
    for index,(name,n,mode,Npilot) in enumerate([('basic',8,'homogeneous',2048),('pressure',16,'homogeneous',2048),('expanded_heterogeneous',32,'heterogeneous',1024)]):
      meta=setup(n,mode);diags=diagonal_witnesses(meta);print(name,'diagonal feasible',sum(r['necessary_joint_exists_q'] for r in diags),flush=True);pilots=[pilot(meta,Npilot,228010+index)]
      if pilots[0]['necessary_joint_hits']<20:pilots.append(pilot(meta,1024,228110+index,SHIFT))
      frozen=freeze(pilots,diags);print(name,'pilot hits',[p['necessary_joint_hits'] for p in pilots],'fixed q',frozen['fixed_q'],flush=True)
      validation=[validate(meta,frozen,2048,228210+index,0.),validate(meta,frozen,2048,228310+index,SHIFT)]
      for p in pilots:p['mid_log_qs_for_freeze_count']=len(p.pop('mid_log_qs_for_freeze'))
      stages.append({'stage':name,'model':meta,'deterministic_diagonal_witnesses':diags,'pilots':pilots,'frozen_q_selection':frozen,'independent_validation':validation,'precision_audit':precision_audit(meta,frozen,228210+index)});print(name,'validation hits',[[r['raw_joint_hits'] for r in v['results']] for v in validation],flush=True)
    result={'schema':'R228_true_spatial_kernel_probe_v1','complete':True,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'mpmath_version':mp.__version__,'source_fingerprints':SOURCE_FINGERPRINTS,'primary_estimator':'Independent direct p0 sampling; shifted proposal is an auxiliary coverage diagnostic and can be severely degenerate.','fixed_parameters':{'b':1,'L':1,'R':1,'g':1,'cj':1,'a':.5,'s':S,'K':K,'K2_equals_K1':True,'Q':'(2P_s+P_1)/3','nu':'mg delta_v + mu delta_u','beta':'nu + beta0 delta_y0','nu_le_beta':True},'stages':stages,'scope':['Actual common spatial phi/C/f kernels and same x are used throughout, with product probability receiver sampling.','qmin(x)=max caps is only a pilot existence diagnostic; validation q is frozen independently and both FIRST caps plus high checked at that fixed q.','Point sources and assigned clock/geometry parameters are not a positive L1 input or FULL history/source realization.','Capture ell1 ratios on diagonal points do not certify original capture, alphaJ terms, surviving low gate or histories.','Unweighted proxy omits HR; separately reported hard proxies include the model HR and optional cap, still omit capture/history/allocation and FULL qualifications.','Ordinary log-domain numerical arithmetic and Monte Carlo/importance errors, not interval or probability certificates.','No general dimension-order fit, adaptive-selector/source budget or global closure.','No spatial truncation: true full-support fs and shifted fs are sampled.']}
    output.write_text(json.dumps(result,indent=2)+'\n')
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=HERE/'spatial_probe.json');args=ap.parse_args();main(args.output)
