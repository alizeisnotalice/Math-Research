import argparse,json
from pathlib import Path
import mpmath as m

results = {"scope": "Actual phi/C and common-window or clock diagnostics only; not FULL, no dimension-order fit", "common_window": {"precision_digits": 40, "cases": []}, "boundary": {"precision_digits": 50, "n": 512, "cases": []}}
m.mp.dps = 40

def E(k, x):
    return m.mpf(1)/(k-1) if x == 0 else m.expint(k, x)

def phi(x):
    x = abs(x)
    if x <= m.mpf('.5'):
        return 1-E(3, m.mpf('.5')-x)-E(3, m.mpf('.5')+x)
    return E(3, x-m.mpf('.5'))-E(3, x+m.mpf('.5'))

def C(d):
    d = abs(d)
    if d <= 1:
        return 1-d+E(4, 0)-E(4, d)-E(4, 1)+E(4, d+1)
    return E(4, d-1)-2*E(4, d)+E(4, d+1)

def f(s, x):
    return (1-s)*(abs(x) <= m.mpf('.5'))+s*phi(x)

def radius(s, t):
    if t > f(s, 0): return None
    if s == 0: return m.mpf('.5')
    if s*phi(m.mpf('.5')) < t <= f(s, m.mpf('.5')):
        return m.mpf('.5')
    lo, hi = m.mpf(0), m.mpf(1)
    while f(s, hi) >= t: hi *= 2
    for _ in range(120):
        mid = (lo+hi)/2
        if f(s, mid) >= t: lo = mid
        else: hi = mid
    return (lo+hi)/2

def integ(fn, lo, hi, breaks):
    if lo >= hi: return m.mpf(0)
    cuts = [lo]+sorted({q for q in breaks if lo < q < hi})+[hi]
    return sum(m.quad(fn, [a, b]) for a, b in zip(cuts, cuts[1:]))

checks = 0
cases = [(16,'1','.6','.3','.9'), (16,'1','1','1','.6'),
         (32,'.8','.55','.05','.8'), (8,'.5','.8','.6','.9')]
for n, ls, rs, ss, ds in cases:
    L,R,s,d = map(m.mpf, (ls,rs,ss,ds))
    a,g,gam = m.mpf('.5'),m.sqrt(L*R),1+m.mpf(1)/n
    j = int(m.floor(m.log(g/min(L,R))/m.log(gam)))
    cj,tau = gam**(-j),a*gam**j
    h = g*m.exp(-m.mpf('.1')/n)
    if h <= tau: continue
    chi,ell = 1-s+s*phi(m.mpf('.5')),1+m.log(n)
    H0 = g/cj**m.mpf('.5')*chi*ell**(m.mpf(1)/(2*n))
    H = max(a,min(1,H0))
    T = cj**(m.mpf(n)/2)/(g**n*m.sqrt(ell))
    theta = H*cj**m.mpf('.5')/(g*ell**(m.mpf(1)/(2*n)))
    w = lambda t: min(1,C(d)/(cj*t))**n
    Delta = w(tau)-w(h)
    if Delta <= 0: continue
    assert 0 < theta < 1
    checks += 1
    for x in (m.mpf(0),m.mpf('.3'),m.mpf('1.1')):
        assert m.almosteq((f(s,(x-d)/H)/H)**n/T,
                         (f(s,(x-d)/H)/theta)**n,
                         rel_eps=m.mpf('1e-35'))
        checks += 1
    rc = radius(s,theta*Delta**(m.mpf(1)/n))
    Acap = 0 if rc is None else 2*H*rc
    z,A = d,min(1,gam*L)
    fn = lambda x: m.sqrt(f(s,x/L)*f(s,(x-d)/A)/(L*A))
    br = [-L/2,L/2,d-A/2,d+A/2]
    lo,hi = z-R/2,z+R/2
    I = integ(fn,lo,hi,br)
    cl,ch = max(lo,d-Acap/2),min(hi,d+Acap/2)
    Ic = integ(fn,cl,ch,br)
    outside = (integ(fn,lo,min(hi,cl),br)+integ(fn,max(lo,ch),hi,br)
               if cl < ch else I)
    assert m.almosteq(I-Ic,outside,abs_eps=m.mpf('1e-32'))
    omega = min(1,C(d)/min(L,R))
    assert max(L,R)*I/(R*m.sqrt(omega)) <= 1+m.mpf('1e-25')
    checks += 2
    results['common_window']['cases'].append({'n': n, 'L': ls, 'R': rs, 's': ss, 'coordinate_displacement': ds, 'j': j, 'H0': m.nstr(H0,25), 'Hhat': m.nstr(H,25), 'Delta': m.nstr(Delta,25), 'theta': m.nstr(theta,25), 'A_capture': m.nstr(Acap,25), 'window_fraction_remaining': m.nstr(1-(Ic/I)**n,25), 'D_scalar': m.nstr(max(L,R)*I/(R*m.sqrt(omega)),25), 'source_z_equals_v': True, 'capture_parameter': 1})
results['common_window']['assertions_passed'] = checks

m.mp.dps = 50
n,a,ell = 512,m.mpf('.5'),1+m.log(512)
gam,cphi = 1+m.mpf(1)/n,-m.log(phi(m.mpf('.5')))
checks = 0
cases = [('lower_nonempty','.75','.75','.6',-m.mpf('.001')),
         ('lower_empty','.75','.75','.6',m.mpf('.001')),
         ('upper_nonempty','1','.6','.2',None)]
for label,ls,rs,ss,du in cases:
    L,R,s = map(m.mpf,(ls,rs,ss))
    g = m.sqrt(L*R)
    j = int(m.floor(m.log(g/min(L,R))/m.log(gam)))
    cj,tau = gam**(-j),a*gam**j
    u = n*m.log(g/tau)+du if du is not None else m.mpf('.1')
    h,chi = g*m.exp(-u/n),1-s+s*phi(m.mpf('.5'))
    H0 = g/cj**m.mpf('.5')*chi*ell**(m.mpf(1)/(2*n))
    H,logfar = max(a,min(1,H0)),m.log(h/tau)
    bound = m.mpf('1.5')*m.log(cj)-m.log(chi)-m.log(ell)/(2*n)-u/n
    assert 0 < cj <= 1
    assert -m.log(chi) <= s*cphi
    checks += 2
    if H0 < a:
        assert logfar < bound
        checks += 1
        if logfar > 0:
            assert s > (u+m.log(ell)/2)/(n*cphi)
            checks += 1
    else:
        assert a <= H <= H0
        checks += 1
    results['boundary']['cases'].append({'label': label, 'L': ls, 'R': rs, 's': ss, 'j': j, 'H0': m.nstr(H0,30), 'Hhat': m.nstr(H,30), 'u': m.nstr(u,30), 'log_far_length': m.nstr(logfar,30), 'lowerclamp_bound_only_if_H0_lt_a': m.nstr(bound,30), 'lowerclamp': bool(H0<a), 'far_positive_length': bool(logfar>0), 'necessary_s_lower': m.nstr((u+m.log(ell)/2)/(n*cphi),30)})
results['boundary']['assertions_passed'] = checks
results['boundary']['phi_half'] = m.nstr(phi(m.mpf('.5')),35)
results['boundary']['c_phi'] = m.nstr(cphi,35)
results['total_assertions_passed'] = results['common_window']['assertions_passed'] + checks
parser = argparse.ArgumentParser()
parser.add_argument('--output', type=Path, default=Path(__file__).with_suffix('.json'))
out = parser.parse_args().output
out.write_text(json.dumps(results, ensure_ascii=False, indent=2, sort_keys=True)+'\n')
print(json.dumps({'output': str(out), 'common_window_cases': len(results['common_window']['cases']), 'boundary_cases': len(results['boundary']['cases']), 'assertions_passed': results['total_assertions_passed']}))
