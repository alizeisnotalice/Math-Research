# R228 同点空间核：运行前有限方案

窄读R225 numeric_probe.py的真实E1/E3 phi实现；本脚本自足，C用相应E4原函数，一次计算固定位移。b=L=R=g=cj=1,a=.5,K=256,s=.05，K2=K1=P_s，J=P_1，Q=(2P_s+J)/3。y=0，nu=1e−6 delta_v+delta_u，beta=nu+1e−10 delta_0，明确nu≤beta。每个接收点真实计算cap_beta=sum p_source beta、cap_Q=sum Q_source nu，不替换逐x来源核。

三阶段有限模型：basic n8、homogeneous v_i=.9,u_i=−.25；pressure n16、同模式；expanded n32、交替v_i=.65/1.15,u_i=−.1/−.4。每个模型t=.5,.75，alpha_i=C(|source_i−y_i|)，score与完整wt/wg、et/eg、两posterior均保原product min定义。先用所有坐标相同的x_i∈{−.45,−.25,0,.1,.2,.3,.4,.49,.6}及模式对应真实核查门；已有本机初查表明x=.3等点可同时good、bad、存在某q的high，所以零采样命中不能当几何不相容。

独立pilot：n8/16各2048个真实p0样本，n32为1024；若存在q诊断的联合命中少于20，额外1024个移位product proposal样本，xi_i=.125。只用pilot/确定点选择3个log q中间值分位（必要时可行确定点内的1/4,1/2,3/4位置），冻结为常数q后，以全新seed分别2048个p0样本与2048个p_s(x−xi)样本验证。proposal是真正严格soft移位product核，似然权重p0/proposal由全部坐标log核差计算；报告加权均值、MC标准误、全局/事件ESS，不把加权样本当binomial。

固定q验证同一x下的两FIRST cap≤q、high p0 eg≥2Kq、good p0 wg(v)≤KQv、bad KQu<p0 wg(u)、正score kv>ku。输出p0接收概率；两个明确proxy：E_p0[delta Pi_v Pi_u 1gates]，以及乘beta({0})/q的固定y项∫p0 beta0/q delta Pi_v Pi_u 1gates dx。只为静态点源真实核诊断，不是含hard-source/allocation/history/capture的完整原交通。

capture只在确定点记录ell=1的必要核比：chi=1−s+s phi(.5),H0=chi,Hhat=clamp[.5,1]H0，theta=chi Hhat/H0；K0/T=product_i[f_s((x_i−v_i)/Hhat)/theta]。这是由K0=Hhat^−n product f和T=1推得的真核比，不单独认证capture历史、J/alpha项或实际D参数。

空间核直接20dps求值后在log域累加，确定点40dps复核；无密度插值。全部概率/误差仅普通Monte Carlo，所有样本来自真实全支撑fs，没有空间截断。无一般阶拟合/无FULL声称。脚本--output、自足、源码/合同/参考代码指纹，JSON无runtime/路径，最终完整字节复跑。

最后必要精度/覆盖审查（最终复跑前）：每模型独立test的前16个同一浮点坐标用20/40dps重新算真实核，比较固定q联合判定；不增样本或新参数。移位proposal已观察到低ESS和似然权均值明显偏离1，因此只作覆盖失败诊断，不将其较小加权SE当可靠误差界，不额外加样修饰结果。主要概率证据采用直接p0样本。

## 实际结果与界限

三阶段pilot必要联合门命中371/2048、828/2048、320/1024；均足以直接冻结三个独立pilot的log q分位，不触发额外proposal pilot。随后每模型使用全新seed的2048个p0样本。basic三固定q联合概率依次0.091309、0.122559、0.153809（MC SE 0.006367、0.007248、0.007974）；pressure为0.194336、0.238281、0.239746（SE 0.008746、0.009416、0.009436）；expanded异质为0.262695、0.253418、0.225098（SE 0.009727、0.009614、0.009231）。实际同点good/bad/high/两FIRST/正score可共同发生。这是有限点源、固定尺度、固定模型的接收概率；没有构造原历史资格或完整交通。

预选mg=1e−6、mu=1本身使posterior对因子很小。t=.5时每模型固定因子delta Pi_vPi_u分别约7.24e−8、1.31e−9、4.65e−14；相应raw proxy小不能归为真实空间几何的付款机制。另固定y FIRST proxy还人为含beta0=1e−10/q。未测试广泛质量配方，不能由此推质量统一结论。

为单独揭示此限制，仅复用确定点核：令m=nu({v})可变且mu=1。由Qcap与high必要推出
m[Qv−p0 wgv/(2K)] <= p0 wgu/(2K)−Qu。
good保证左系数>=Qv/2>0。另若Pv−p0 wgv/(2K)>0，则beta FIRST给第二上界；取两者可用上界的较小值，负右端截为零只表示无正质量可行。在每时刻t，posterior乘积随质量m在wt_u/wt_v处达1/4，故对[0,m_upper]直接取截断峰值。此为逐x自适应质量/q的必要上界，不充分，不代表同一固定来源的实现，也不是固定q积分。

结果：basic的x_i=.3允许必要m_upper约7.355，t=.5的delta Pi_vPi_u上界约0.468197；pressure同x允许约15353.2，截断峰值达到4；异质n32的x_i=.2允许约3.08e12，也达到4。这些宽上界直接说明，当前固定微小mg数值并未展示质量统一的空间抑制。未因此新增质量采样或扩大搜索。

辅助移位proposal xi=.125的全局ESS约52.43、19.08、3.51，似然权样本均值约.796、.262、.0747，明显退化。其较小概率估计与直接p0结果不一致，普通加权样本SE可漏掉罕见巨大权尾，不能当可靠覆盖保证，更不能取其较小结果支持结论。保留完整加权结果作为覆盖失败记录；主要概率结果为上面的直接p0估计。没有无限增样。

最终精度复查每模型直接validation首16点，以相同已生成浮点坐标在20/40dps重算phi；输出float log特征最大差为0，三个冻结q的联合判定0翻转。所有test的临界log比较距离<1e−10次数为0。这只是普通精度交叉检查，不是区间证书。全部样本来自真实全支撑混合采样，无截断尾。没有一般维数阶拟合、没有FULL或完整source/allocation/capture预算认证。

最终完整脚本复跑与保留的完整预期JSON逐字节一致（不是只比较摘要）。JSON SHA256：e8f9657e2d8c0903155b5a7fe91307a27217ef0f57fafa9203fa14663e0d8b16；源码SHA256：b90b893fdc11ebfd4d49f8df459cc799b8865f61e427863136518ef68c1686eb。JSON无运行时间或输出路径字段，--output可迁移。已完成有限范围，停止。

## 同样本真实hard接收核补核（运行前）

保持全部模型、固定q、seed和样本数，新增H_R(x)=mg 1_{Q_1(v)}(x)+mu 1_{Q_1(u)}(x)，使用原nu而非另选hard来源。逐点记录联合门且H_R>0命中、接收概率及加权SE，并在同一联合门内再检查H_R≤16q/3。固定y代理精确定义为∫p0(x) beta0 H_R(x)/q delta Pi_v Pi_u 1_joint dx；资格版另乘1_{H_R≤16q/3}。这些仍不含历史、capture、allocation。此前不含H_R的proxy保留作对照，不能将其指向有真实hard来源的原交通。复跑仅重建原seed的同样本，不增加采样。

实际补核结果：三模型、每模型三个冻结q、direct p0与移位proposal两套既有2048样本的联合门且H_R>0命中全部为0，故此次含hard的固定y正代理及其H_R≤16q/3资格版均估计为0。与此前0.091–0.263的非hard联合概率形成关键对照：当前参数没有采到hard来源参与的联合事件，不应将先前代理当作原交通发生证据。每个direct p0、固定q的零命中可作普通binomial有限样本的单项95%上界1−.05^(1/2048)≈0.001462；这不是同时置信陈述，更不是不存在的证明。移位proposal仍严重退化，其零命中不能套binomial的p0概率上界，也不能提供更强排除。含hard代理的样本方差/SE为0只反映未命中，不是误差保证。未新增模型、样本或mass优化。

补hard后的最终完整JSON再复跑逐字节一致。当前JSON SHA256：c2bcb3877bb1e3d24e449361b0c6285bb7feaed22a56342d22e5fe0cd72fd061；当前源码SHA256：6a2c845ce7fad400883d0902e99f68b30b472aad7e474cba058463fd862be523。前节旧hash为补hard前历史，当前两hash取代它们作为最终交付绑定。完成后停止。

最终审查后仅修正总scope说明：无hard代理省略H_R，单列hard代理已保留模型H_R及可选帽，仍缺capture/history/allocation与FULL资格。相应脚本自hash及预期JSON元数据同步，数值字段未改；最终包外完整复跑须逐字节验证这一版本。
