# 第228轮：真实捕获几何与独立固定阈值空间探路

前轮分类progress：第227轮已独审并推送6113770。本轮目标仍是一般正L1的一致n^(1/2+o(1))弱型上界，没有闭合。

新的全参数pointwise结构：令H0=g cj^(−1/2)χ_s ell^(1/(2n))，Hhat=clamp[a,b]H0。强capture余支在H0≥a时严格排除Hhat硬核，因而排除统一a核；H0<a时原远clock长度满足Lfar<cφs−(u+.5logell)/n，cφ=−logφ(.5)<2。因此s≤(u+.5logell)/(2n)的lower-clamp far支严格为空。包含等号、clipping、空窗和所有s分支，不将高s的lower-clamp剩余域删掉。

详细共同窗口模型见receiver_geometry.md。hard核保留时可用来源位置的包含判据直接判零；固定参数排除cube后积分是两乘积差。实际参数随x选择时仍缺qualified maximal-affinity或真实weighted covering桥，没有把fixedθ积分套在θ(x)上。第227轮pair-envelope本身也不提供小包络质量。

阶段预算检查没有新增付款：每段mass≤2合法，但按logdegree层粗加可被旧clock估计覆盖；少大删除阶段可以改善纯clock，不提供Wβ预算。详细费用与未证覆盖见clock_source_budget.md，失败路径保留避免重复。

本机数学工具：spatial_probe.py实际φ/C，独立pilot冻q、新seed测试，严格区分逐x存在q诊断与固定q概率。直接p0采样是主要有限证据；shiftproposal出现低ESS/权均值偏离1，完整记录而不声称可靠重要性采样。tiny good-source质量是模型限制，不能把小proxy当uniform几何收益。离散点源、fixed scales及未认证FULL历史均明示。数学工具技能H04用于概率解释边界，未借用未经匹配的LDP。

所有脚本/JSON与核验范围见numeric_notes.md及几何作者稿。普通求积与MC不是区间证明，未拟合维数阶；独立审查先核命题后读作者。保详细LaTeX，不编译PDF。每轮紧凑归档、单独提交并推送；最终复现以包外驱动完整JSON比较与manifest前后核验为准。

剩余缺口仍是原强capture几何上的真实receiver/source统一预算，而非已经证明的空支或固定参数积分。一般目标保持active。

补核原hard因子H_R=ν*h_R：三模型、各三个冻结q的原有direct/shifted样本中，联合门且H_R>0均零命中；含H_R/q交通代理亦零。仅有限零命中，SE=0不代表误差为零，不能证明一般支为空。旧不含hard代理保留作诊断，不能代表原交通。
