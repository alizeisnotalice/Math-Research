# Round 69: full conditional weak return and a single indicator threshold

2026-10-11. **The uniform bound sqrt(n)n^{o(1)} remains unproved.**
The retained unconditional general benchmark is O(n log n).

## Proved progress and the exact remaining estimate

The complete conditional return is now proved: a global atomic cap-energy
estimate E_{M mu<=H}(mu)<=K_n H W implies

    C_n <= C [1+sqrt(n log(n+2) K_n)].

It retains the high-global exception and absorbs it only after the actual
Naor--Tao localization on a physical ratio-max(n,2) window. Constants are
finite before absorption, and only weak inequalities are transferred to
L1 inputs. No general capped-energy convergence is assumed.

A separate collared local return is proved. Its upper collar is paid by
one endpoint average, and its same-window weak constant is absorbed.
The new rooted binary forest replacement works on the actual local good
set. Tiny cells without a local shield and coarse root mass are treated
explicitly. The complete signed error is at most 2(1+e)HW with canonical
parameters, uniformly in window length, source count and depth.

Because target heights vary by only a factor of two, a SINGLE indicator
threshold delta_n=(4n^2)^(-n) suffices, with one extra factor two. The
required indicator test is not proved. Global atomic capped energy also
implies the finite-rectangle-union indicator test at every rho<1, by a
positive-distance transport comparison and product-space Fatou. This
reverse passage does not cover arbitrary L1 capped energy or unchanged
local scale endpoints.

One exact calibration rejects a tempting excessive strengthening. For
n=1, mu=(delta_{-a}+delta_a)/2, H=1, a>=1/2, the actual good-set energy is

    1-e^{-1}+(e+2e^{-1}-3)/(64a^2-1)>1-e^{-1}.

Thus one atom is not an energy extremizer. This does not disprove a larger
dimension-independent or subpower bound, nor the target weak bound.

| Claim | Status |
| --- | --- |
| Global atomic cap energy implies unrestricted L1 weak return | Proved conditional implication |
| Collared local energy implies unrestricted weak return | Proved conditional implication |
| Rooted local replacement and full signed O(HW) error | Proved |
| Reduction to delta_n=(4n^2)^(-n) indicator testing | Proved conditional implication |
| Reverse finite-union indicator passage for rho<1 | Proved conditional implication |
| Two-atom sharp-constant obstruction | Proved counterexample |
| Subpower general cap-energy or single-threshold indicator estimate | Unproved |
| General sqrt(n)n^{o(1)} weak upper bound | Unproved |

For the single-threshold global test with constant J_n, the forward
budget is K_n<=[sqrt(2(1+e))+sqrt(2e(1+log2)J_n)]^2. Therefore
C_n is bounded conditionally by C sqrt(n log(n+2)(1+J_n)). A proved
J_n=O(log^A(n+2)) would give the requested exponent with logarithmic loss
(A+1)/2. No such estimate is inferred from the numerical observations.

## Validation and reproduction

The final standalone probe has 158 rows and 254976 full-space receiver
draws: pilot, heldout, single-atom and two-atom calibrations are separated.
It computes actual complete arrival batches and integrates signed energy
over the entire logvolume line, including the infinity tail. Independent
parent replay is byte-identical. Four supplemental Python guards are
embedded in this report. The main probe additionally has 280 retained
point energy enclosures using outward rational arithmetic, 280 exact
gate checks, and seven controlled cases. These certify only their finite
point computations, not the Monte Carlo receiver integrals.

The auxiliary window statistic uses an UNCOLLARED cap and is not a test
of the collar-matched local theorem. Standard errors are exploratory;
formal ideal Hoeffding radii and floating sampler limitations are stated.
No growth exponent is fitted or deduced.

The archive has exactly five members: proof.md, proof.tex.txt,
cap_energy_probe.py, cap_energy_results.json, inventory.json. Extract to
a temporary directory, preserve the supplied JSON, and run
`python3 -B cap_energy_probe.py` using Python 3.12.14 / NumPy 2.3.5.
Do not pass --pilot for full replay. Run each embedded Python block
separately with standard-library Python. The LaTeX source is saved as
.tex.txt; static checks were run, with no compilation or PDF generation.

The global binary construction retained from Round68 is archived at
`centered-cube-upper-bound/rounds/068/research.zip` in the same repository.
This round contains the newly completed return and new local construction.
The updated 64-skill entrances and evidence paths were reloaded. Skill
availability and byte checks are not theorem verification.



# Round 69: a complete conditional return from capped energy to weak type

The general square-root dimensional upper bound is still unproved. This note closes the **conditional return**: a source-uniform global cap-energy estimate on finite positive atomic sources with constant K_n implies

    C_n <= C [1+sqrt(n log(n+2) K_n)],                         (R1)

with an absolute C. In particular K_n=n^{o(1)} is sufficient. A collar-matched local cap test also suffices, with a separate explicit collar cost. The energy test itself remains unpaid. No convergence of capped energy under atomic approximation is asserted.

## 1. Definitions and the precise finite-window crossing

Let mu be a finite positive atomic source of mass W. Receiver measure is Lebesgue dx. Use full side length L, logvolume time u=n log L, and

    A_u(x)=e^{-u} mu(x+[-e^{u/n}/2,e^{u/n}/2]^n),
    B_u(x)=integral_0^1 A_{u+s}(x) ds,
    D_u(x)=A_{u+1}(x)-A_u(x).

Put c=1-e^{-1}. The nested positive cube averages give A_{u+s}>=e^{-s}A_u, hence B_u>=c A_u. B is locally absolutely continuous in u and B'=D almost everywhere. Also integral B_u dx=W at each time. These facts retain the physical tied arrivals; neither A nor B is assumed to be a martingale.

For I=[u_0,u_1], T=u_1-u_0>0, let M_I=sup_{u in I} A_u. Its B comparison requires the actual source averages up to time u_1+1. For atoms, M_I is a finite maximum of its left endpoint and its physical arrivals inside I; it is Borel. For densities the cube averages are continuous in positive side length, so the supremum over a countable dense set, including endpoints, is measurable.

For a measurable receiver set S, write E_S(I)=integral_S integral_I |D_u|^2 du dx. Then the following unconditional crossing inequality holds:

    lambda |{M_I>lambda} intersect S|
       <= A_0 W + A_1 sqrt(T W E_S(I)/lambda),                (R2)

where

    A_0=2/c,       A_1=(2/c)sqrt(2/c).

Proof. Let a=c lambda/2, and clip B between a and 2a using psi(z)=min(1,max(0,(z-a)/a)). If M_I>lambda then sup_I B>2a. Either B_{u_0}>a, or the continuous clipped path grows from zero to one somewhere in I. The initial receiver set has volume at most W/a by Markov. On the second set its positive variation is at least one, bounded by a^{-1} integral_I 1_{a<B<2a}|D| du. Level sets at the two boundaries do not add derivative terms: for an absolutely continuous path, its derivative is zero almost everywhere on a fixed level set, and the clipped chain rule holds almost everywhere.

The active occupation is at most T W/a, since integral B_u dx=W. Cauchy--Schwarz on S times I gives

    lambda |event intersect S|
      <= (lambda/a)W+(lambda/a)sqrt(E_S(I) T W/a),

which is (R2). The full energy can be replaced by its active-band restriction; using the full energy is sufficient here. Forward smoothing has a one-unit collar, but the occupation time being integrated is T, not an unrecorded full-scale interval.

## 2. The global cap exception must be retained

Assume the following general atomic source hypothesis, uniformly in W,H and all positions and weights:

    integral_{M mu<=H} integral_R |D_u|^2 du dx
       <= K_n H W.                                         (GCE)

On S={M mu<=R lambda}, (R2) gives a capped window fee at most

    [A_0+A_1 sqrt(R K_n T)] W.

It controls only the intersection with that actual global good set. The remaining points are contained in {M mu>R lambda}. They cannot be discarded or paid by the capped estimate.

For example, take one atom of mass one at the origin, a window beginning at volume one, and lambda=1/2. On the receiver region v=(2||x||_infinity)^n<1, the unrestricted window maximum is exactly one, while the global maximum is 1/v>1=2lambda. This entire region, of volume one, is missing from the global-cap-2lambda crossing estimate. This is an endpoint/cap mismatch, not a weak-type counterexample.

Let C_n^{at} be the full weak constant on all finite positive atomic sources and C_n be the full L1 constant. Let C_n^{at}(T) and C_n^{L1}(T) be the suprema of unrestricted window weak constants over all window locations of length T. Then (GCE) yields

    C_n^{at}(T)
       <= A_0+A_1 sqrt(R K_n T)+C_n^{at}/R.                  (R3)

No high-global bands have been summed. R is a fixed norm-level absorption parameter, independent of the source and threshold.

## 3. Only weak inequalities are transferred between atoms and L1

All these constants are finite. One elementary bound is C_n^{at},C_n<=3^n. To see this, take a compact subset of a full strict superlevel set and choose open witness cubes of average greater than lambda whose interiors cover it. For atomic witnesses, slightly increasing the radius places captured atoms in the interior and preserves the strict average. Choose a finite subcover and greedily retain cubes in decreasing radius order, deleting every cube intersecting a retained one. Retained open cubes are disjoint; every deleted cube lies in a triple dilation of a retained cube. Their mass sum is at most W, so the compact receiver volume is at most 3^n W/lambda. Inner regularity passes to the whole measurable set. The same argument covers densities. This crude bound is used only to justify algebraic absorption of finite constants.

For every T,

    C_n^{L1}(T) <= C_n^{at}(T),       C_n^{at} <= C_n.       (R4)

First inequality. For f>=0 in L1, truncate to expanding boxes and transfer the exact mass of each cell of a shrinking finite grid to its center. This produces finite positive atomic measures mu_j of mass at most ||f||_1. For every fixed receiver x and positive cube side L, the captured masses converge to integral_{Q(x,L)} f. Indeed transport displacement tends to zero and the two enclosing cube boundaries have zero f dx mass; the source truncation eventually contains that fixed cube. Thus every strict window witness for f is eventually a witness for mu_j **at the same scale**, including either window endpoint. Fatou transfers the atomic window inequality to f. No cap set or energy is passed through this approximation.

Second inequality. Convolve a finite atomic mu with a positive normalized cube density of shrinking width. Each has mass W. Given any strict full-scale witness cube for mu, enlarge it slightly; for all sufficiently narrow mollifiers it contains the entire smeared mass of every originally captured atom, and its average remains greater than lambda. Therefore every original strict receiver event is eventually a density event. Fatou gives C_n^{at}<=C_n. The first grid argument also transfers the full weak inequality directly, since each full strict event has a fixed finite cube witness. Thus C_n<=C_n^{at} and the full-scale constants agree, although equality of the fixed-window constants is not needed or claimed.

## 4. Actual Naor--Tao localization and global absorption

The external input is Naor--Tao, *Random martingales and localization of maximal inequalities*, Theorem 1.1 and its explicit p=1 specialization (11). The author-hosted primary [PDF](https://web.math.princeton.edu/~naor/homepage%20files/HLM.pdf) was read at the metric hypotheses and theorem on printed pages 2, 4--6, and at the proof in Section 3, printed pages 16--19. The displayed implicit factor is absolute once its microdoubling constant is fixed. No exact numerical value is assigned to that implicit universal constant.

For the cube space take (X,d,base measure)=(R^n,||.||_infinity,dx) and m=max(n,2). It is separable, Lebesgue measure is Radon, every closed metric ball has positive finite measure, and

    |B(x,(1+1/m)r)|/|B(x,r)|=(1+1/m)^n<=e<6.

Thus the theorem can use the fixed admissible microdoubling constant 6, avoiding any endpoint ambiguity at its stated lower bound. Its radius window [r,mr] is exactly the full-side window [a,ma]. There is an absolute L>=1 such that

    C_n <= L [1+C_n^{L1}(T_n)],      T_n=n log m.             (NT)

The additive one absorbs the fixed microdoubling term. This is a **ratio-m window**, not a factor-two window. In particular we do not substitute T=n log 2 into (NT) or assume that a full-scale norm equals a simple sum of two-scale bands.

Combining (R3), (R4) and (NT) gives

    C_n <= L [1+A_0+A_1 sqrt(R K_n T_n)]+(L/R) C_n.

Choose R=2L and absorb the finite C_n term. The exact conditional consequence is

    C_n <= 2L [1+A_0+A_1 sqrt(2L K_n T_n)].                  (R5)

Since T_n<=n log(n+2), this proves (R1). If K_n=n^{o(1)}, then sqrt(log(n+2)K_n)=n^{o(1)}, giving the desired weak upper form. The gain is conditional on the general source estimate (GCE); it is not obtained from a special family, source entropy, or per-source diagonal energy.

This repairs the unverified localization link retained in R53--R55. R68's intrinsic balanced-binary indicator test implies its stated general atomic (GCE) with

    K_n <= [sqrt(2(1+e))+sqrt(e(1+log 2) I_n)]^2.

Consequently a subpower I_n is sufficient all the way to the general weak bound, without transferring capped energy to densities. The indicator test remains unproved.

## 5. A collar-matched local cap test gives a separate clean return

The following hypothesis is also sufficient and is stronger on its receiver set than a global-cap test. Fix sigma_n>=1. For every finite positive atomic source, threshold H and window I=[u_0,u_1] of length T_n, put J=[u_0,u_1+sigma_n], and assume

    E_{{M_J<=H}}(I) <= K_n^{loc} H W.                       (LCE)

An analogous statement at another fixed length T gives the corresponding local window conclusion. No global maximal cap is substituted for M_J.

The top collar is paid directly: for u in [u_1,u_1+sigma_n], positivity gives

    A_u <= e^{sigma_n} A_{u_1+sigma_n},

so the collar maximum has L1 norm at most e^{sigma_n} W. The bottom of J is the same as the bottom of I; no unpaid lower collar appears. Write C_I=C_n^{at}(T_n). Apply (R2) at H=Rlambda on the actual local good set. Its complement is contained in the union of a high **same-window** maximum and a high top-collar average. Hence

    C_I <= A_0+A_1 sqrt(R K_n^{loc} T_n)
               +(C_I+e^{sigma_n})/R.

For R=2, legitimate absorption of this same finite constant yields

    C_I <= 2A_0+2A_1 sqrt(2 K_n^{loc} T_n)+e^{sigma_n}.       (R6)

Transfer the weak window bound by (R4), then use (NT). Thus

    C_n <= L [1+2A_0+2A_1 sqrt(2 K_n^{loc} T_n)
                       +e^{sigma_n}].                       (R7)

In particular subpower K_n^{loc} and bounded sigma_n suffice. This avoids both free high-global summation and a cyclic demand to control a newly enlarged window by the same unverified cap estimate. The top enlargement is one paid averaging operator; the norm absorbed is the original inner-window norm.

For the local binary replacement audited independently in this round, write q=e^{1/n}, alpha=2n^2+1 and R_g=(alpha+1)/(alpha-1)=1+1/n^2. The compatible physical windows are

    inner D-time sides [a,b/q],      original cap sides [a,R_g b].

Set b=q m a. Then the inner ratio is m, T=T_n, and

    sigma_n=n log(q R_g)=1+n log R_g<=1+1/n<=2,
    e^{sigma_n}=e R_g^n<=e^2.

Forward B on the inner window uses source averages only up to side b. Thus (LCE), **if obtained from the actual local indicator test and the paid replacement error**, fits (R7) without a missing collar. The separate replacement proof supplies its own signed error and source budget; this note supplies only the return. Its local indicator test remains unpaid.

## 6. Audit boundary and current skills

R53's all-scale smoothed variation counterexample and R54's rapid atomic crossing energy remain valid. Neither contradicts the conditional results: R54 excludes an uncapped band-energy bound, whereas (GCE)/(LCE) retain actual maximal caps. R55's entropy estimate is not a source-uniform K_n. R68 supplies a conditional indicator-to-energy reduction, not an indicator test.

Per the user's current reload request, M04, N04 and L03 SKILL.md, method.md and cube-interface.md were reread from disk. All nine hashes match the Round64 manifest. The current entrance hashes are:

    M04 94d345413090478f55cf675d0db8127ae997d44aba919888f958306dfff5e293
    N04 0ec449afa32e815eae515b391f2c613e2c2f084496d3e8b3ce1d682da5e9a107
    L03 0e2d41f62f831a87047487abb1bbcd7c74243cfa8e16cd6d702fe829124f5a9c

M04 is used only for directly proved Borel finite maxima; no general selection theorem is imported. N04 prevents an unbudgeted infinite scale sum: the proof uses one source mass through norm localization and explicit absorption. L03 separates exact rational finite geometry from nearest-rounded Decimal analytic evaluations; no unverified interval library is used. Provenance status was inspected, not treated as automatic theorem applicability. The external localization theorem is read and explicitly cited independently of these skills.

The missing research estimate is now precise: prove the general source-uniform energy hypothesis, or the compatible local indicator hypothesis yielding (LCE). The return to the original unrestricted L1 weak problem is conditional but complete.

## 7. Reproducible multistage guard

The first, second and fourth stages below use exact rational arithmetic.
The third evaluates actual finite-atomic event integrals at Decimal
precisions 80 and 140; agreement is not an outward-rounded interval
certificate. No sampled receiver integral is used to prove (GCE) or
(LCE). The code is standalone Python 3.

```python
from fractions import Fraction as F
from decimal import Decimal, localcontext
from itertools import product

counts=dict(global_cap_gap=0, endpoints=0, collar=0,
            absorption=0, atomic_grid=0, decimal_paths=0, crossings=0)

def D(q):
    return Decimal(q.numerator)/Decimal(q.denominator)

def volumes(src,x):
    n=len(x)
    return [(2*max(abs(a-b) for a,b in zip(x,y)))**n for y,p in src]

def capture(src,vs,v):
    return sum((p for (_,p),s in zip(src,vs) if s<=v),F(0))

def maximum(src,vs,left=None,right=None):
    if right is None:
        return max(capture(src,vs,v)/v for v in sorted(set(vs)) if v>0)
    events={left,right}|{v for v in vs if left<=v<=right}
    return max(capture(src,vs,v)/v for v in events)

# Stage 1: the true global-cap hole and finite-window endpoint arrivals.
for n in (1,2,4,8,16):
    src=[((F(0),)*n,F(1))]
    for radius in (F(1,8),F(1,4),F(3,8)):
        x=(radius,)+(F(0),)*(n-1)
        vs=volumes(src,x)
        assert maximum(src,vs,F(1),F(2)**n)==1
        assert maximum(src,vs)>1  # global cap 2lambda=1 removes this point
        counts['global_cap_gap']+=1
    for radius in (F(1,2),F(1),F(3,2)):
        x=(radius,)+(F(0),)*(n-1)
        v=volumes(src,x)[0]
        # Source is first captured exactly at the upper endpoint.
        assert maximum(src,[v],v/2,v)==1/v
        assert maximum(src,[v],v/2,F(3,4)*v)==0
        # A lower endpoint captures the boundary atom and starts at height 1/v.
        assert maximum(src,[v],v,2*v)==1/v
        counts['endpoints']+=1

sources=[]
for n in (1,2,4):
    origin=(F(0),)*n
    pole=lambda t:(F(t),)+(F(0),)*(n-1)
    sources.extend([(n,[(origin,F(1))]),
                    (n,[(pole(-1),F(1,4)),(pole(0),F(1,2)),(pole(1),F(1,4))])])
sources.extend([(1,[((F(i,8),),F(1,8)) for i in range(8)]),
                (2,[(tuple(F(s) for s in y),F(1,4))
                    for y in product((-1,1),repeat=2)])])
paths=[]
for n,src in sources:
    stored=0
    receivers=[tuple(F(t,4) for t in row)
               for row in product((-7,-3,1,5,9),repeat=n)]
    for x in receivers:
        vs=volumes(src,x)
        if not all(v>0 for v in vs): continue
        for left in (F(1,16),F(1),F(4)):
            right=left*F(2)**n
            inner=maximum(src,vs,left,right)
            for gamma in (F(3),F(4),F(8)):
                collar=maximum(src,vs,right,gamma*right)
                endpoint=capture(src,vs,gamma*right)/(gamma*right)
                assert collar<=gamma*endpoint
                outer=maximum(src,vs,left,gamma*right)
                for lam in (F(1,8),F(1,2),F(2)):
                    assert outer<=2*lam or inner>2*lam or gamma*endpoint>2*lam
                    counts['collar']+=1
            if inner>0 and stored<45:
                paths.append((src,vs,left,right,inner*F(2,3)))
                stored+=1

# Stage 2: finite norm-level absorption, including the R=1 boundary.
for A in (F(1,8),F(1),F(3),F(20)):
    for L in (F(1),F(3,2),F(7),F(100)):
        for R in (2*L,4*L,16*L):
            q=L/R
            bound=L*A/(1-q)
            for fraction in (F(0),F(1,4),F(1,2),F(1)):
                C=fraction*bound
                assert C<=L*A+q*C
                assert C<=bound
                if R==2*L: assert bound==2*L*A
                counts['absorption']+=1
    for R in (F(3,2),F(2),F(4),F(16)):
        for collar in (F(1),F(3),F(8)):
            bound=(R*A+collar)/(R-1)
            assert bound==A+(bound+collar)/R
            if R==2: assert bound==2*A+collar
            counts['absorption']+=1
    # At R=1 the term C cannot be absorbed; the denominator would vanish.
    assert all(C<=A+C for C in (F(1),F(10),F(10**9)))

# Stage 3: real finite-atomic smoothed paths, exact event formulas.
def evaluate_path(record,precision):
    src,vs,left0,right0,lambda0=record
    with localcontext() as ctx:
        ctx.prec=precision
        q=(-Decimal(1)).exp(); c=1-q
        ps=[D(p) for _,p in src]; vv=[D(v) for v in vs]
        left,right,lam=map(D,(left0,right0,lambda0))
        a=c*lam/2
        def B(v):
            answer=Decimal(0)
            for p,s in zip(ps,vv):
                if v>=s: answer+=c*p/v
                elif v>=q*s: answer+=p/s-q*p/v
            return answer
        def clipped(z):
            return min(Decimal(1),max(Decimal(0),(z-a)/a))
        events=sorted({left,right}|{v for s in vv for v in (q*s,s)
                                    if left<v<right})
        tv=Decimal(0); energy=Decimal(0); occupation=Decimal(0)
        for lo,hi in zip(events,events[1:]):
            tv+=abs(clipped(B(hi))-clipped(B(lo)))
            mid=(lo+hi)/2
            A=sum((p/s for p,s in zip(ps,vv) if q*s<mid<s),Decimal(0))
            C=sum((c*p if mid>s else -q*p if mid>q*s else Decimal(0)
                   for p,s in zip(ps,vv)),Decimal(0))
            assert abs(B(mid)-(A+C/mid))<Decimal(10)**(-precision+10)
            cuts=[lo,hi]
            if C:
                for level in (a,2*a):
                    if level!=A:
                        root=C/(level-A)
                        if lo<root<hi: cuts.append(root)
            cuts.sort()
            for l,r in zip(cuts,cuts[1:]):
                value=B((l+r)/2)
                if a<value<2*a:
                    occupation+=(r/l).ln()
                    energy+=C*C*(1/(l*l)-1/(r*r))/2
        tolerance=Decimal(10)**(-precision+15)
        assert tv*tv*a*a<=energy*occupation+tolerance
        crossing=int(B(left)<=a and max(B(v) for v in events)>2*a)
        if crossing: assert tv>=1-tolerance
        for v in events:
            original=sum((p for p,s in zip(ps,vv) if s<=v),Decimal(0))/v
            assert B(v)+tolerance>=c*original
        return tuple(+z for z in (tv,energy,occupation)),crossing

max_difference=Decimal(0)
for record in paths:
    coarse,crossing=evaluate_path(record,80)
    fine,_=evaluate_path(record,140)
    with localcontext() as ctx:
        ctx.prec=160
        discrepancy=max(abs(a-b)/(1+abs(b)) for a,b in zip(coarse,fine))
        assert discrepancy<Decimal('1e-65')
        max_difference=max(max_difference,discrepancy)
    counts['decimal_paths']+=1
    counts['crossings']+=crossing

# Stage 4: fixed-scale density-to-atom capture at both window endpoints.
for N in (8,16,32,64,128):
    h=F(2,N)
    src=[((F(-1)+(F(i)+F(1,2))*h,),h) for i in range(N)]
    for x in (F(-3,2),F(-1),F(-1,3),F(0),F(2,3),F(1),F(3,2)):
        for L in (F(1,4),F(1,2),F(1),F(2),F(3)):
            continuous=max(F(0),min(F(1),x+L/2)-max(F(-1),x-L/2))
            atomic=sum((p for (y,),p in src if abs(x-y)<=L/2),F(0))
            assert abs(atomic-continuous)<=2*h
            counts['atomic_grid']+=1

print('PASS multistage guard',counts)
print('nearest-rounded 80/140 maximum relative difference',max_difference)
```

The final embedded guard passed on a fresh local rerun: 15 global-cap-gap
checks, 15 endpoint checks, 36,153 exact collar checks, 240 absorption
checks, 175 atomic-grid capture checks, and 209 actual Decimal event
paths, including 106 clipped crossings. The maximum normalized
80/140-precision discrepancy was 2.023e-79 (rounded upward for this
reported decimal bound). This is a comparison of nearest-rounded
computations, not a certified interval error bound. Runtime was below
one second. These checks validate the finite algebra and event formulas,
not the unproved uniform energy hypotheses.


# Round 69: a local-window replacement with explicit collars

The intrinsic indicator estimate remains unproved. This note proves a local replacement reduction on the ORIGINAL collared local cap, including both small cells that have no local shield and large source cells whose coarse shielding must be settled separately. The signed error budget is independent of window length. The global-cap test from Round68 cannot be substituted for the new local test.

## 1. Normalization and exact window scope

Let H>0, alpha>1, q>1, 0<a<=b/q, and define

\[
 R={\alpha+1\over\alpha-1},\qquad c=Rb,\qquad
 J=[a,b/q],\qquad
 G_c=\{\sup_{a\le L\le c}A_L\mu\le H\}.
\]

The local energy is

\[
 E_{G_c}^{J}(\nu)=
 \int_{G_c}\int_{n\log a}^{n\log(b/q)}
       |A_{qL}\nu-A_L\nu|^2\,du\,dx,\quad u=n\log L.
\]

Thus both averages used by D lie in [a,b]. The original cap has the explicit upper collar [b,Rb]. No information at L<a or L>Rb is used. For the intended cube problem q=exp(1/n). The construction and error lemma below hold for every q>1.

## 2. A coarse rooted forest and settlement of large source cells

Use a translated/rescaled balanced binary grid with ROOT CUBES of side

\[
 s_0=b/(\alpha-1),\qquad
 \lambda=[2(\alpha+1)]^nH.
\]

Below each root, split one coordinate at a time cyclically. A child has half the parent volume; every cell has aspect at most two and largest side s<=2|cell|^(1/n). All fine cells also have s<=s_0.

Call a root P bad if mu(P)>lambda s_0^n, and let tau be the original source restricted to the union of bad roots. Let eta=mu-tau. The following conclusions are precise:

* Every bad root's closed alpha-dilation lies outside G_c. For x inside that dilation, a centered cube of side (alpha+1)s_0=Rb=c captures all mass in the root, and mu(P)>lambda s_0^n=H(2c)^n>Hc^n. This is a local cap argument at the AVAILABLE upper endpoint.
* Consequently A_L tau(x)=0 for x in G_c and L<=b. Indeed outside a closed alpha-dilated root, every source point in it is farther than (alpha-1)s_0/2=b/2 from x in at least one coordinate.
* If a receiver argument begins without the collar, these alpha-root dilations can be charged explicitly. With X their union,

\[
 H|X|\le \left[{\alpha\over2(\alpha+1)}\right]^n W.       \tag{1}
\]

This follows from the sum of dilation volumes and the strict bad-root mass inequality. Overlap only improves the upper bound. In the collared local-energy proof X is already disjoint from G_c, so this fee is not additionally spent.

The removed mass is retained as tau, not silently discarded: eta is redistributed with its full mass conserved, while tau's two window averages vanish exactly on G_c.

Each remaining root has eta-mass at most lambda s_0^n. Select the maximal bad binary descendants R with m_R=eta(R)>lambda|R|. Their parents are good (possibly roots), hence

\[
 \lambda<h_R:=m_R/|R|\le2\lambda.                       \tag{2}
\]

The selected descendants are disjoint and countable. As in Round68, the residual eta outside them is a density f_0<=lambda, proved by contained-cell covers of open sets. Define F=f_0+sum_R h_R1_R; mass(F)=mass(eta)<=W. For finite atomic sources f_0=0 and the selected family is finite. Every target block lies below a good root and has s_R<=s_0.

## 3. The two cell classes: local shield versus direct small-scale payment

For a selected cell R let Q_R^* be its concentric containing cube of side s=s_R, and set S_R=(alpha+1)s. The density threshold implies

\[
 m_R>H S_R^n.
\]

There are two exhaustive cases.

**Medium cells:** S_R>=a. Since s<=s_0, S_R<=c. If x lies in alpha Q_R^*, the centered cube of side S_R captures all original mass in R and has average >H. Therefore G_c avoids alpha Q_R^*. This shield is proved using a scale inside [a,c], not borrowed from the global cap.

**Tiny cells:** S_R<a. The local cap need not exclude alpha Q_R^*. It can contain a source atom or points inside a high-density uniform block. We do not assert a shield. Instead s<a/(alpha+1), so all receiver scales in [a,b] are already large relative to the displacement, and the translation defect is directly affordable.

For x in G_c and a receiver cube of side L in [a,b], every block contributing to the target average is captured in full by the original cube of side RL:

* For a medium block, positive-volume intersection forces L>=(alpha-1)s, so 2s/L<=2/(alpha-1)=R-1.
* For a tiny block, 2s/L<2/(alpha+1)<R-1.

The unchanged residual is part of the original source. Since RL is in [a,c], disjointness gives

\[
 A_LF(x)\le R^nH\qquad(x\in G_c,\ a\le L\le b).          \tag{3}
\]

Both window averages of mu are <=H, and both target averages are <=R^nH. Therefore

\[
 |D(\mu-F)|\le(1+R^n)H
\]

on G_c x the fundamental time window; here Dtau=0 is used.

## 4. Full signed window error, independent of b/a

Couple eta restricted to each selected cell to its uniform target by normalized product coupling. Its mass is m_R, and every coupled displacement is at most s_R. For the full-side cube kernel,

\[
 \|k_L(\cdot-y)-k_L(\cdot-z)\|_1
 \le2n\|y-z\|_\infty/L.
\]

For a medium cell, on G_c the kernel defect vanishes for L<(alpha-1)s. Integrating this bound over ANY subwindow of L>0 with du=n dL/L gives at most 2n^2/(alpha-1). The same applies to the qL term after changing scale.

For a tiny cell, no vanishing assertion is available. But each kernel term is integrated only over L>=a (or L>=qa for the outer term), so its integral is at most 2n^2 s/a<2n^2/(alpha+1)<=2n^2/(alpha-1).

Thus in BOTH cases the complete D coupling defect has integral at most 4n^2/(alpha-1). Summing the mass couplings by Tonelli yields

\[
 \int_{G_c}\int_J|D(\mu-F)|\,du\,dx
 \le {4n^2\over\alpha-1}W.
\]

This bound includes all mixed terms after multiplication by the aggregate pointwise cap (3):

\[
 E_{G_c}^{J}(\mu-F)
 \le \Xi_n HW,\qquad
 \Xi_n={4n^2(1+R^n)\over\alpha-1}.                      \tag{4}
\]

No b/a, atom count, minimum mass, stopping depth, or block-overlap factor occurs. Countably many cells are justified by the finite sum of integrated absolute coupling defects. This is a TRUNCATED error statement; no all-time error bound for the retained coarse mass tau is asserted.

At alpha=2n^2+1, R=1+1/n^2 and Xi_n<=2(1+e).

## 5. The correct local indicator input: a thin band, or one threshold

For a selected-block level t in [lambda,2lambda], define U_t={F>t}. By (3), t1_Ut<=F implies

\[
 G_c\subset
 \{\sup_{a\le L\le b}A_L1_{U_t}\le\rho(t)\},\qquad
 \rho(t)={R^nH\over t}.
\]

These rho lie only in the band

\[
 {\delta_n\over2}\le\rho(t)\le\delta_n,\qquad
 \delta_n={R^n\over[2(\alpha+1)]^n}
          =[2(\alpha-1)]^{-n}.
\]

At the canonical alpha=2n^2+1 this threshold is EXACTLY

\[
 \delta_n=(4n^2)^{-n}.                                  \tag{D}
\]

The minimal needed LOCAL indicator hypothesis is

\[
 E_{\{\sup_{a\le L\le b}A_L1_{U_t}\le\rho(t)\}}^{[a,b/q]}(1_{U_t})
 \le {\cal I}_{n,\mathrm{loc}}\,\rho(t)|U_t|              \tag{LI}
\]

only for the nested unions generated by the actual rooted binary replacement, at their associated rho(t). A stronger sufficient version tests every finite union V of translated/rescaled balanced binary cells and every rho in [delta_n/2,delta_n]. There is no need to require all rho>0. For the prospective weak localization return it suffices to require the physical fundamental ratio b/(qa)=m_n=max(n,2), uniformly in the starting scale a; the construction/error lemma itself holds for every window ratio.

The receiver cap in (LI) is LOCAL to [a,b], while its D-time window is [a,b/q]. The R68 GLOBAL-cap test has a different, generally smaller receiver set and cannot be substituted for (LI).

A further sufficient weakening uses a SINGLE threshold. Assume, for each required generated union V (or more strongly every finite union),

\[
 E_{\{\sup_{a\le L\le b}A_L1_V\le\delta_n\}}^{[a,b/q]}(1_V)
 \le {\cal J}_{n,\mathrm{loc}}\,\delta_n|V|.              \tag{SI}
\]

For rho in [delta_n/2,delta_n], cap-set monotonicity gives

\[
 E_{\{M_{[a,b]}1_V\le\rho\}}^{[a,b/q]}(1_V)
 \le E_{\{M_{[a,b]}1_V\le\delta_n\}}^{[a,b/q]}(1_V)
 \le 2{\cal J}_{n,\mathrm{loc}}\,\rho|V|.
\]

Thus (SI) supplies (LI) with calI_loc=2calJ_loc. Thin-band testing directly has no factor-two loss. Both hypotheses remain unproved.

For finite atomic mu, F is entirely the selected uniform target and has heights in (lambda,2lambda]. Multiplying (LI) by t^2 gives nested testing

\[
 E_{G_c}^J(t1_{U_t})\le R^n{\cal I}_{n,\mathrm{loc}}H\,t|U_t|.
\]

The Round68 layer identity in the TRUNCATED Hilbert space L2(G_c x J) retains all signed receiver and scale cancellations, and gives

\[
 E_{G_c}^J(F)\le(1+\log2)R^n{\cal I}_{n,\mathrm{loc}}\,HW.
\]

The exponential absolute target height cancels. Combining with (4),

\[
 E_{G_c}^{J}(\mu)\le K_n^{\mathrm{loc}}HW,\qquad
 K_n^{\mathrm{loc}}
 =\left[\sqrt{\Xi_n}
       +\sqrt{(1+\log2)R^n{\cal I}_{n,\mathrm{loc}}}\right]^2.
                                                               \tag{5}
\]

For the single-threshold sufficient version replace calI_loc by 2calJ_loc. At canonical alpha, Xi_n<=2(1+e) and R^n<=e, so subpower single-threshold local indicator testing would yield subpower collared local cap energy for EVERY finite atomic source.

The same single-threshold monotonicity applies to the GLOBAL indicator cap in the R68 construction: a test at delta_n on its required level unions gives the global thin-band input with factor two. The global and local gates must still be kept distinct.

For a general Borel source the local replacement and error proof are valid, but F includes the unchanged residual f_0. Its local target energy and mixed term require an additional estimate; no density-to-atom good-set energy convergence is assumed.

## 6. Paid upper collar and two complete conditional return chains

The finite upper collar is settled by one fixed average. Put Z={A_{Rb}mu>H/R^n}. Then H|Z|<=R^nW by Markov. Outside Z, every L in [b,Rb] satisfies

\[
 A_L\mu\le(Rb/L)^nA_{Rb}\mu\le H.
\]

Thus the uncollared cap on [a,b] extends to [a,Rb] outside this explicitly paid Z. This does not extend to all larger scales.

The companion energy-to-weak audit above now proves TWO conditional returns, rather than making an unpaid change of cap set. Its finite-window crossing constants are c_0=1-e^{-1}, A_0=2/c_0 and A_1=(2/c_0)sqrt(2/c_0). It uses the separately checked Naor--Tao localization with an absolute constant L_0>=1 and T_n=n log m_n, m_n=max(n,2).

**Global return.** A source-uniform global atomic cap-energy bound E_{Mmu<=H}^{alltime}(mu)<=K_n HW implies

\[
 C_n\le2L_0[1+A_0+A_1\sqrt{2L_0K_nT_n}].
\]

The high GLOBAL cap exception is retained once and absorbed with threshold multiplier 2L_0. It is not discarded or summed freely across high bands. R68's global indicator reduction, including its new single-threshold sufficient version, feeds this global energy hypothesis. This repairs the previously unclosed conditional return; the indicator energy estimate itself remains unpaid.

**Local return.** The collared local energy hypothesis from (5), at b=q m_n a, implies

\[
 C_n\le L_0[1+2A_0+2A_1\sqrt{2K_n^{\mathrm{loc}}T_n}
                    +eR^n].
\]

Here the inner D-time sides are [a,b/q], the outer original cap sides are [a,Rb], and q=exp(1/n). The collar parameter is sigma_n=n log(qR)=1+n log R; at canonical alpha it is at most two. The same finite INNER-window weak constant is absorbed, while the upper collar is paid by one endpoint averaging operator. No global cap is silently promoted to a local cap.

The companion proves weak-window atomic-to-L1 approximation at the SAME scale and full weak absorption; it does not transfer capped energy to densities. Consequently either source-uniform global cap energy or the matching local cap energy with subpower constant is sufficient for the desired weak upper form C_n<=sqrt(n)n^{o(1)}. The current research still has neither energy estimate: (LI), (SI), and their global analogues are unproved. No unconditional weak bound is claimed here.

## 7. Current skill reload and hypotheses

A02 and N04 were re-read from their current disk entries, method files and cube interfaces for this round. Entry SHA256 values are unchanged from the previously recorded versions:
A02 5718759f09c75af3353a9e041f2f20ebcbca429d49eeb85ccea3bef998f141e5;
N04 0ec449afa32e815eae515b391f2c613e2c2f084496d3e8b3ce1d682da5e9a107.
A02 is used as an audit requirement that the actual LOCAL objective error be dominated; a set map alone is insufficient. N04 requires a genuine finite cumulative budget before countable limits; the coupling Tonelli estimate supplies that budget here. No entropy descent, spectral positivity, Carleson embedding, or external theorem from these skills is imported.

## 8. Exact finite guard

The standalone standard-library guard below uses Fraction throughout. It tests several window ratios, small atoms lying inside the LOCAL good set, medium-cell shielding at allowed scales, strict/tied root densities, removed coarse source invisibility, original local caps, actual uniform rectangular averages, upper-collar comparisons, and the integrated translation majorant. The guard uses rational q>1; the proof covers these q and the actual q=exp(1/n). It does not numerically certify (LI), which remains unproved.

```python
from fractions import Fraction as F
import json

def lengths(k,n,s0):
    q,r=divmod(k,n)
    return tuple(s0*F(2)**(-q-(j<r)) for j in range(n))
def cell(y,k,s0):
    ell=lengths(k,len(y),s0)
    return k,tuple(int(y[j]//ell[j]) for j in range(len(y)))
def bounds(Q,n,s0):
    k,idx=Q
    ell=lengths(k,n,s0)
    return tuple(idx[j]*ell[j] for j in range(n)),ell
def inside(y,Q,s0):
    left,ell=bounds(Q,len(y),s0)
    return all(left[j]<=y[j]<left[j]+ell[j] for j in range(len(y)))
def mass(Q,src,s0):
    return sum((p for y,p in src if inside(y,Q,s0)),F(0))
def source_capture(x,L,src):
    return sum((p for y,p in src if
                max(abs(x[j]-y[j]) for j in range(len(x)))<=L/2),F(0))
def local_good(x,src,H,a,c):
    radii={a,c}
    radii.update(2*max(abs(x[j]-y[j]) for j in range(len(x)))
                 for y,p in src)
    return all(source_capture(x,L,src)<=H*L**len(x)
               for L in radii if a<=L<=c)
def global_good(x,src,H):
    for y,p in src:
        L=2*max(abs(x[j]-y[j]) for j in range(len(x)))
        if L==0 or source_capture(x,L,src)>H*L**len(x): return False
    return True
def build(src,n,lam,s0):
    roots={cell(y,0,s0) for y,p in src}
    bad={Q for Q in roots if mass(Q,src,s0)>lam*s0**n}
    tau=[(y,p) for y,p in src if cell(y,0,s0) in bad]
    eta=[(y,p) for y,p in src if cell(y,0,s0) not in bad]
    selected=set()
    for y,p in eta:
        assert p>lam*s0**n*F(2)**(-60*n)
        candidates=[cell(y,k,s0) for k in range(1,60*n+1)
                    if mass(cell(y,k,s0),eta,s0)>
                       lam*s0**n*F(2)**(-k)]
        selected.add(min(candidates,key=lambda Q:Q[0]))
    assert sum(mass(Q,eta,s0) for Q in selected)==sum(p for y,p in eta)
    return sorted(bad),tau,eta,sorted(selected)
def uniform_capture(x,L,rects,eta,s0,t=None):
    ans=F(0)
    n=len(x)
    for Q in rects:
        left,ell=bounds(Q,n,s0)
        vol=s0**n*F(2)**(-Q[0])
        h=mass(Q,eta,s0)/vol
        if t is not None: h=t if h>t else F(0)
        ov=F(1)
        for j in range(n):
            ov*=max(F(0),min(x[j]+L/2,left[j]+ell[j])
                           -max(x[j]-L/2,left[j]))
        ans+=h*ov
    return ans
def proxy(s,alpha,a,b,q,tiny,n):
    cutoff=F(0) if tiny else (alpha-1)*s
    def integ(lo,hi):
        lo=max(lo,cutoff)
        return max(F(0),1/lo-1/hi)
    return 2*n*n*s*(integ(a,b/q)+integ(q*a,b))

def run():
    threshold_checks=0
    for dim in range(1,129):
        alpha0=F(2*dim*dim+1)
        R0=(alpha0+1)/(alpha0-1)
        delta=R0**dim/(2*(alpha0+1))**dim
        assert delta==F(1,(4*dim*dim)**dim)
        for ratio in (F(1),F(5,4),F(3,2),F(7,4),F(2)):
            rho=delta/ratio
            assert delta/2<=rho<=delta<=2*rho
            threshold_checks+=1
    counts={"source_configurations":0,"root_fee_checks":0,
            "selected_cells":0,"parent_ties":0,
            "window_receiver_scales":0,"threshold_averages":0,
            "nonglobal_local_good_receivers":0,
            "tiny_cells_without_global_shield":0,
            "translation_integral_majorants":0,
            "endpoint_collar_comparisons":0,"single_threshold_budget_pairs":threshold_checks}
    for n in range(1,7):
        a=F(1,8)
        q=1+F(1,n)
        zero=(F(0),)*n
        def pole(t):
            return (F(t),)+(F(0),)*(n-1)
        for m in (2,16,256):
            b=q*m*a
            for alpha in (F(3,2),F(2*n*n+1)):
                H=F(1)
                R=(alpha+1)/(alpha-1)
                c=R*b
                s0=b/(alpha-1)
                lam=(2*(alpha+1))**n
                root_threshold=lam*s0**n
                psmall=a**n/4
                cases=[
                    [(zero,psmall),(pole(a/1024),psmall/4)],
                    [(zero,root_threshold/2),(pole(s0/4),root_threshold/8)],
                    [(zero,root_threshold)],
                    [(zero,2*root_threshold),(pole(3*s0),psmall)]
                ]
                for src in cases:
                    bad,tau,eta,rects=build(src,n,lam,s0)
                    W=sum(p for y,p in src)
                    counts["source_configurations"]+=1
                    assert H*len(bad)*(alpha*s0)**n <= \
                           (alpha/(2*(alpha+1)))**n*W
                    counts["root_fee_checks"]+=1
                    for Q in rects:
                        left,ell=bounds(Q,n,s0)
                        s=max(ell)
                        vol=s0**n*F(2)**(-Q[0])
                        h=mass(Q,eta,s0)/vol
                        assert lam<h<=2*lam
                        assert s<=s0 and s**n<=2**n*vol
                        parent=cell(tuple(left[j]+ell[j]/2 for j in range(n)),
                                    Q[0]-1,s0)
                        pm=mass(parent,eta,s0)
                        assert pm<=2*lam*vol
                        if pm==2*lam*vol: counts["parent_ties"]+=1
                        S=(alpha+1)*s
                        tiny=S<a
                        assert S<=c
                        assert proxy(s,alpha,a,b,q,tiny,n)<=4*n*n/(alpha-1)
                        counts["translation_integral_majorants"]+=1
                        counts["selected_cells"]+=1
                    candidates=[zero]
                    for d in (a/4,a,b/2,b,c/2,c,2*c):
                        for signs in ((1,)*n,(-1,)*n,
                                      tuple((-1)**j for j in range(n))):
                            candidates.append(tuple(signs[j]*d for j in range(n)))
                    for x in candidates:
                        # Fixed endpoint settles every finite upper-collar scale.
                        if source_capture(x,c,src)<=H*c**n/R**n:
                            for L in (b,(b+c)/2,c):
                                assert source_capture(x,L,src)<=H*L**n
                                counts["endpoint_collar_comparisons"]+=1
                        if not local_good(x,src,H,a,c): continue
                        if not global_good(x,src,H):
                            counts["nonglobal_local_good_receivers"]+=1
                        for P in bad:
                            left,ell=bounds(P,n,s0)
                            center=tuple(left[j]+s0/2 for j in range(n))
                            assert max(abs(x[j]-center[j]) for j in range(n))>alpha*s0/2
                        scales={a,(a+b)/2,b,q*a,b/q}
                        for Q in rects:
                            left,ell=bounds(Q,n,s0)
                            s=max(ell)
                            S=(alpha+1)*s
                            center=tuple(left[j]+ell[j]/2 for j in range(n))
                            in_shield=max(abs(x[j]-center[j]) for j in range(n))<=alpha*s/2
                            if S>=a: assert not in_shield
                            elif in_shield: counts["tiny_cells_without_global_shield"]+=1
                            for L in ((alpha-1)*s,S):
                                if a<=L<=b: scales.add(L)
                        for L in scales:
                            if not a<=L<=b: continue
                            assert source_capture(x,L,tau)==0
                            fm=uniform_capture(x,L,rects,eta,s0)
                            assert fm<=source_capture(x,R*L,src)<=H*(R*L)**n
                            ts={lam,F(3,2)*lam,2*lam}
                            ts.update(mass(Q,eta,s0)/(s0**n*F(2)**(-Q[0]))
                                      for Q in rects)
                            for t in ts:
                                assert uniform_capture(x,L,rects,eta,s0,t)<=fm
                                counts["threshold_averages"]+=1
                            if L<=b/q:
                                muD=source_capture(x,q*L,src)/(q*L)**n \
                                    -source_capture(x,L,src)/L**n
                                fD=uniform_capture(x,q*L,rects,eta,s0)/(q*L)**n \
                                    -fm/L**n
                                assert abs(muD-fD)<=(1+R**n)*H
                            counts["window_receiver_scales"]+=1
    assert counts["nonglobal_local_good_receivers"]>0
    assert counts["tiny_cells_without_global_shield"]>0
    return {"exact":counts,
            "scope":"Fraction finite local geometry/error-majorant checks; rational q>1; local indicator test unproved"}
if __name__=="__main__":
    print(json.dumps(run(),sort_keys=True,separators=(",",":")))
```

Final actual replay completed in about 2.62 seconds and passed 144 source configurations, 144 selected cells, 42 parent ties, 7748 receiver scales, 29322 threshold averages, 4725 endpoint-collar comparisons, 144 translation majorants and 640 exact single-threshold budget pairs in dimensions 1 through 128. It explicitly found 345 locally good receivers that were globally bad, and 57 tiny-cell/receiver instances without a shield. All returned data are deterministic; runtime is not a field in the guard JSON. These are finite geometry and majorant checks, not a numerical proof of the indicator energy test.


# Round 69: a guarded reverse passage for finite indicator unions

This is an implication between two unproved uniform estimates, not a proof of either estimate. It explains exactly when atomic cap-energy tests also test the finite-union indicator interface. It does NOT assert continuity of capped energy under arbitrary weak convergence.

## Statement

Put q=exp(1/n), u=n log L, D_u=A_{qL}-A_L, and let

    E_G(nu)=integral_G integral_R |D_u nu(x)|^2 du dx.

Assume the GLOBAL atomic cap-energy hypothesis

    E_{M mu<=H}(mu) <= K_n H mass(mu)                      (A)

for every finite positive atomic source mu and every H>0. Then for every finite union V of bounded axis-parallel rectangles and every 0<rho<1,

    E_{M 1_V<=rho}(1_V) <= K_n rho |V|.                   (I)

No cell aspect ratio or common grid is needed for this reverse implication. The forward reduction in R68/R69 still uses its own balanced binary geometry and source budget. In particular (I) applies at the single threshold delta_n=(4n^2)^(-n) required by R69's forward reduction.

## Proof with the actual good sets

The zero-volume case is trivial, so take |V|>0. Boundaries of the finitely many rectangles have Lebesgue measure zero. Almost every point of V is an interior point, where M 1_V=1. Because rho<1, almost every x in G={M 1_V<=rho} lies outside the compact closure of V. Consequently

    d(x)=dist_infinity(x,V)>0.

Partition a bounded box containing V into finitely many cells whose infinity diameters tend to zero. Push the EXACT measure 1_V dx in each nonzero cell to one point of that cell. Denote the resulting finite positive atomic measure by mu_j. It has mass exactly |V|, and there is a transport coupling with displacement at most epsilon_j -> 0. Its support is within epsilon_j of V. All this is one source approximation, independent of the receiver x and threshold.

Fix x outside the closure and epsilon_j<d(x). If A_L mu_j(x)>0, the receiver cube captures a target atom lying within epsilon_j of V, so L>=2(d(x)-epsilon_j). Enlargement of that cube by full side 2epsilon_j captures every original source cell whose target atom was captured. Therefore, at every L>0,

    A_L mu_j(x)
      <= (1+2epsilon_j/L)^n A_{L+2epsilon_j}(1_V)(x)
      <= (1+epsilon_j/(d(x)-epsilon_j))^n M 1_V(x),

where the second inequality is needed only for nonzero capture. Taking the supremum over ALL L gives

    M mu_j(x) <= (d(x)/(d(x)-epsilon_j))^n M 1_V(x).       (1)

For each fixed eta>0 and almost every x in G, (1) implies M mu_j(x)<=(1+eta)rho for every sufficiently large j. The required index may depend on x; Fatou does not require uniformity in x.

For every fixed x and L>0 the atomic capture converges to the integral of 1_V over the original cube. Indeed the coupling sandwiches its capture between those of cubes of full side L-2epsilon_j and L+2epsilon_j (with zero lower capture if needed), and cube boundaries have zero absolutely continuous source mass. Hence D_u mu_j(x) -> D_u 1_V(x) at every finite u.

On product Lebesgue measure dx du, the nonnegative integrands consequently satisfy

    1_G(x)|D_u 1_V(x)|^2
      <= liminf_j 1_{M mu_j<=(1+eta)rho}(x)|D_u mu_j(x)|^2

almost everywhere. Fatou and (A) give

    E_G(1_V) <= K_n(1+eta)rho |V|.

Let eta decrease to zero. This proves (I), including all time scales and all receiver space. No dominated convergence, unproved energy convergence, or positive source minimum-distance uniform in x was used.

## Exact scope and implications

1. The cap margin (1+eta)rho is essential in the approximation argument. It is removed only after applying the uniform estimate and Fatou.
2. The exclusion of the support uses BOTH finite rectangular geometry and rho<1. We do not infer this argument for arbitrary L1 densities, arbitrary sets with dense support, or rho>=1.
3. For a local cap, enlargement can exceed the cap's upper endpoint. The displayed all-scale comparison therefore does not prove an endpoint-preserving local analogue.
4. A finite atomic numerical example with large cap-energy ratio tests hypothesis (A). This reverse implication alone does not convert an arbitrary such example into a finite-union counterexample at exactly delta_n. The forward reduction gives the logical obstruction only when its whole uniform indicator hypothesis is assumed.
5. Combined with the R69 single-threshold forward reduction, the GLOBAL finite-union test at delta_n and the atomic cap-energy hypothesis are sufficient for one another up to the explicitly paid constant replacement error and the factor 2 from the layer-height band. Neither has been established with a subpower dimensional constant.

## Reproducible finite transport guards

`indicator_transfer_guard.py` uses exact rational arithmetic to compare actual atomic capture with the continuous volume of two disjoint rectangular source blocks. It includes receivers outside, inside, and on support boundaries; only outside receivers enter the positive-distance guard. It checks exact arrival batches and additional endpoint scales, the transport enlargement, the all-scale distance factor at those scales, and source mass conservation. This guards the geometric implementation; the analytic implication is proved above and is not inferred from finite checks.

The current A02 and M04 skill entries and cube interfaces were re-read. A02's objective domination requirement is supplied by (1), not just by a transport map; M04's measurability requirement follows directly from finite atomic maxima and countable dense scales for the continuous density. No general selection theorem is imported.


```python
from fractions import Fraction as F
from itertools import product
import json


def volume_overlap(x, L, lo, hi):
    ans = F(1)
    for a, b, z in zip(lo, hi, x):
        ans *= max(F(0), min(b, z + L / 2) - max(a, z - L / 2))
    return ans


def distance(x, blocks):
    return min(max(max(a-z, z-b, F(0)) for a, b, z in zip(lo, hi, x))
               for lo, hi in blocks)


def run():
    counts = dict(configurations=0, receivers=0, boundary_or_inside=0,
                  positive_distance=0, arrival_and_endpoint_scales=0,
                  distance_factor_checks=0, mass_conservation=0)
    for n in range(1, 7):
        blocks = [((F(0),)*n, (F(1),)*n),
                  ((F(3),)+(F(0),)*(n-1),
                   (F(4),)+(F(1),)*(n-1))]
        for divisions in (1, 2):
            atoms = []
            eps = F(1, 2*divisions)
            for lo, hi in blocks:
                for ids in product(range(divisions), repeat=n):
                    y = tuple(lo[k]+F(2*ids[k]+1, 2*divisions) for k in range(n))
                    atoms.append((y, F(1, divisions**n)))
            assert sum(p for y, p in atoms) == 2
            counts['mass_conservation'] += 1
            counts['configurations'] += 1
            receivers = [(F(1,2),)*n, (F(0),)*n]
            for d in (F(1,8), F(3,4), F(2), F(8)):
                receivers.extend([(-d,)+(F(1,2),)*(n-1),
                                  (F(4)+d,)+(F(1,2),)*(n-1),
                                  (-d,)*n, (F(2),)+(-d,)*(n-1)])
            for x in receivers:
                counts['receivers'] += 1
                d = distance(x, blocks)
                if d == 0:
                    counts['boundary_or_inside'] += 1
                else:
                    counts['positive_distance'] += 1
                scales = {F(1,8), F(1,2), F(1), F(2), F(8), F(32)}
                scales.update(2*max(abs(x[k]-y[k]) for k in range(n)) for y,p in atoms)
                for L in sorted(scales):
                    if L <= 0:
                        continue
                    atom = sum((p for y,p in atoms
                                if max(abs(x[k]-y[k]) for k in range(n)) <= L/2), F(0))
                    upper = sum(volume_overlap(x, L+2*eps, lo, hi) for lo,hi in blocks)
                    lower = (sum(volume_overlap(x, L-2*eps, lo, hi) for lo,hi in blocks)
                             if L > 2*eps else F(0))
                    assert lower <= atom <= upper
                    counts['arrival_and_endpoint_scales'] += 1
                    if d > eps and atom > 0:
                        assert L >= 2*(d-eps)
                        assert atom/L**n <= (d/(d-eps))**n * upper/(L+2*eps)**n
                        counts['distance_factor_checks'] += 1
    assert counts['distance_factor_checks'] > 0
    return {'exact': counts, 'scope': 'finite Fraction transport geometry, not a numerical proof of capped-energy convergence'}


if __name__ == '__main__':
    print(json.dumps(run(), sort_keys=True, separators=(',', ':')))
```


# An exact pressure test: a single atom is not an energy extremizer

This counterexample rejects only the proposed sharp cap-energy constant `1-exp(-1)`. It does not reject a dimension-independent constant, a subpower cap-energy estimate, or the target weak bound. It is a falsification/calibration input, not a substitute for the general proof.

In dimension one take mu=(delta_{-a}+delta_a)/2, H=1, a>=1/2. With the actual global good set G={M mu<=1} and the full time difference D_u=A_{u+1}-A_u, the exact normalized energy is

    E_G(mu)/(H W)
       = 1-e^{-1} + (e+2e^{-1}-3)/(64a^2-1).             (P)

It is strictly greater than the single-atom value 1-e^{-1}, since e>2 and e+2/e-3=(e-1)(e-2)/e>0. Thus an argument asserting that one atom maximizes the capped energy has a concrete counterexample.

## Exact time kernel

Let beta=exp(-1). A unit atom arriving at cube volume s>0 contributes the time profile

    d_s(v) = [beta 1_{v>=beta s}-1_{v>=s}]/v,
    du=dv/v.

For s<=t its temporal Gram kernel is

    g(s,t)=integral_0^infinity d_s(v)d_t(v) dv/v
      = 1/2 [(2-beta)/t^2-beta/max(s,beta t)^2].           (K)

This follows by integrating the four indicator products separately from their positive lower endpoints. It gives g(s,s)=(1-beta)/s^2. If s/t<=beta, it gives g(s,t)=(2-beta-beta^{-1})/(2t^2), which is negative.

## Spatial cancellation of the off-diagonal term

For the two atom sites, set z=|x|/a. The larger arrival volume is t=2a(1+z), and the smaller is s=2a|1-z|. Put r=(1-beta)/(1+beta). By (K), after taking out the common factor 1/(8a^2), the integrand is

    (2-beta)/(1+z)^2-beta/(1-z)^2       for 0<=z<=r,
    (2-beta-beta^{-1})/(1+z)^2         for r<=z<=1/r,

and the corresponding first expression for z>=1/r. The change z -> 1/z makes the integral over [1,infinity) equal the one over [0,1]. On that latter interval the two integrals are respectively

    (1-beta)^2/2,    -(1-beta)^2/2.

They cancel exactly. Hence integral_R g(s(x),t(x)) dx=0. This is an absolutely integrable off-diagonal term: it is bounded near either atom and decays as |x|^{-2} at infinity. We do not subtract divergent diagonal energies.

## The actual maximal cap and its fee

Any cube containing both sites has volume at least 2a>=1, so its average is at most one. A cube containing only one atom can exceed one exactly within distance 1/4 of that atom. Apart from endpoints, which do not affect the integral,

    R minus G = (a-1/4,a+1/4) union (-a-1/4,-a+1/4).

For each diagonal term, integrating outside its OWN bad interval gives `(1-beta)pH`, with p=1/2. The sum is 1-beta. Passing to G additionally removes each diagonal term on the OTHER atom's bad interval.

On either bad interval the near arrival is at most 1/2 and the far arrival is at least 4a-1/2>=3/2. Thus the ratio is at most 1/3<beta, using 2<e<3. Formula (K) applies with its negative branch. Write

    J = integral_{a-1/4}^{a+1/4} [2(x+a)]^{-2} dx
      = 2/(64a^2-1).

The sum of the additionally removed diagonal term and the off-diagonal term on the two bad intervals is

    2 p^2 J [(1-beta)+(2-beta-beta^{-1})]
      = (3-2beta-beta^{-1})/(64a^2-1).

The full off-diagonal integral is zero, so subtracting this finite quantity from 1-beta proves (P). No uncapped total diagonal energy is formed.

## Exact algebraic guards

The same derivation works for any beta in (1/3,1/2), with the corresponding time shift -log(beta). The following Fraction checks validate its finite rational algebra, separated from the analytic proof and from the actual beta=exp(-1) numerical calibration.

```python
from fractions import Fraction as F
import json
count=0
for beta in (F(7,20),F(4,11),F(3,8),F(2,5),F(5,11),F(49,100)):
    r=(1-beta)/(1+beta)
    first=(2-beta)*(1-1/(1+r))-beta*(1/(1-r)-1)
    second=(2-beta-1/beta)*(1/(1+r)-F(1,2))
    assert first==(1-beta)**2/2 and second==-first
    for a in (F(1,2),F(3,4),F(1),F(2),F(8)):
        J=(1/(2*a-F(1,4))-1/(2*a+F(1,4)))/4
        assert J==2/(64*a*a-1)
        assert F(1,2)/(4*a-F(1,2))<=F(1,3)<beta
        removal=2*F(1,4)*J*((1-beta)+(2-beta-1/beta))
        energy=1-beta-removal
        assert energy==1-beta+(1/beta+2*beta-3)/(64*a*a-1)
        assert energy>1-beta
        count+=1
print(json.dumps({'exact_beta_separation_pairs':count,'scope':'rational algebra of the two-atom formula; actual exp(-1) evaluated separately'},sort_keys=True))
```


# Round 69: full-space signed cap-energy pressure

This computation evaluates the actual signed, all-scale centered-cube step energy for finite positive atomic sources on the true global cap. It preserves physical arrival batches, interference between all sources, the full receiver proposal density, and the infinite time tail. The registered heldout estimates do not falsify a finite cap-energy budget, but they provide no uniform bound over arbitrary sources or any fitted dimension dependence. The global-cap-to-weak return remains conditional on the missing general estimate.

The frozen standalone files are `cap_energy_probe.py` and its adjacent `cap_energy_results.json`. The final run has 158 rows / 254,976 receiver draws: 18 pilot rows / 9,216 draws, 132 heldout rows / 212,992 draws, six one-atom calibrations / 24,576 draws, and two independent two-atom calibrations / 8,192 draws. The output stores actual source coordinates and rational weights, thresholds, seeds, full-space proposal branches, tail and diagonal diagnostics, retained extreme receivers, gate checks, and finite rational energy enclosures.

## True cap and full-time energy

Write \(\mu=\sum_i p_i\delta_{y_i}\), \(W=\sum_i p_i\), and \(v_i=(2\|x-y_i\|_\infty)^n\). At each receiver, physical equal-distance arrivals form complete batches. The actual maximum is \(M\mu(x)=\max_j F(v_j)/v_j\), since the average decreases between arrivals. The gate is \(G_H=\{M\mu\le H\}\), including equality.

For volume \(v=L^n\), logarithmic volume time \(u=\log v\), and captured mass \(F(v)\),

\[
D\mu(x,v)=\frac{e^{-1}F(ev)-F(v)}v.
\]

Its coefficient changes by \(+p_i/e\) at \(v_i/e\) and \(-p_i\) at \(v_i\). On an event interval \([a,b]\), the exact integral is
\(C_{a,b}^2(a^{-2}-b^{-2})/2\). Before the first event it is zero; the last interval ends at infinity. This gives the whole signed energy, including all cross terms, with no time mesh or positive-arrival replacement.

Normalize \(V=W/H\), \(a_i=p_i/W\), and \(\tau_i=v_i/V\). The program uses log volumes and `expm1` for short interval lengths. Coefficients are obtained from integer cumulative incoming and current source masses as \(F_{\rm adv}/e-F_{\rm cur}\), avoiding a cumulative sum of cancellation-prone signed floating changes. Physical grouping near log-distance ties is reconstructed from exact binary machine-coordinate distances. Near incoming/outgoing event comparisons would use a 120-digit event-order fallback; none were triggered in this registered run.

The recorded infinity-tail contribution is the exact part after the last physical arrival, when the coefficient is \(-(1-e^{-1})W\). It is included in the main total rather than used as a truncation correction. The source-diagonal diagnostic is \((1-e^{-1})\sum_i p_i^2/v_i^2\), evaluated on the same cap. It is explicitly separate from the actual energy.

## Full-space proposal and ideal envelopes

For a source center and cube-cone radial volume \(v\), use the normalized density

\[
q_b(v)=\begin{cases}1/(2b),&v\le b,\\b/(2v^2),&v>b.\end{cases}
\]

Uniform cube-cone directions give \(dx=dv\,d\sigma\). Sampling chooses the inner branch \(v=bU\) or outer branch \(v=b/U\), each with probability one half; faces, signs, and free cone coordinates are uniform. Machine zero \(U\) is replaced by the next positive float. Centers are selected with probabilities \(a_i\). Half the proposal uses global scale \(V\), and half individual scales \(a_iV=p_i/H\).

The complete density at each receiver, including rejected receivers, is

\[
q(x)=V^{-1}q_{\rm core}(x),\qquad
q_{\rm core}=\tfrac14\sum_i a_i\min(1,\tau_i^{-2})+
\tfrac14\sum_i\min(1,(a_i/\tau_i)^2).
\]

The program divides by this full mixture, never only the sampled component. There is no spatial cutoff. The second component gives an envelope independent of weight imbalance. On \(G_H\), \(\tau_i\ge a_i\); Cauchy in the time Hilbert space gives
\(E_{\rm point}/H^2\le cN\sum_i a_i^2/\tau_i^2\), \(c=1-e^{-1}\). Therefore the normalized importance score is at most \(4cN\). This range bound is a finite-source sampling tool, not a useful dimension-only cap estimate.

Each nonnegative summary records the mean, sample SE, observed maximum, ideal score envelope, formal per-summary 95% Hoeffding radius \(B\sqrt{\log40/(2S)}\), score ESS, and the largest one-percent contribution. Heldout total-energy SEs range from 0.010107 to 0.034226. Formal total-energy Hoeffding radii range from 0.60704 to 109.88594 and generally do not resolve the means. These ideal independent-sampling radii omit machine-transform error and are not simultaneous confidence guarantees. Score ESS and concentration fractions diagnose sampling, not mathematical coverage of all receiver space.

## Staged source pressure

The pilot comprised 18 fixed configurations, 512 draws each: equal/unequal nested and common-face sources in dimensions 1, 4 and 16; one-dimensional midpoint grids at two caps; one atoms; actual vertices in dimensions 4 and 8; unequal clouds; and a near-coincident cluster. Pilot results are labeled and not pooled into heldout estimates.

Heldout configurations use two independent seeds each:

| Family | Configurations | Draws |
|---|---:|---:|
| Correlated coordinates and unequal clouds, \(n=1,2,4,8,16\), requested \(N=8,32,64\), 2,048 per seed | 30 | 122,880 |
| Equal/unequal nested sources, \(n=1,4,16\), \(N=16,64\), 1,024 per seed | 12 | 24,576 |
| One-dimensional midpoint grids, \(N=16,64,256,1024\), \(H=2,4\), 1,024 per seed | 8 | 16,384 |
| Uniform vertices, \(n=4,8\), two caps, 2,048 per seed | 4 | 16,384 |
| Near-coincident clusters, \(n=1,4,16,32\), \(N=16,64\), 1,024 per seed | 8 | 16,384 |
| Four frozen Round 65 sources, 2,048 per seed | 4 | 16,384 |

Dimension and requested source count vary independently in the main matrix. Exact duplicate sites are merged before sampling; the one-dimensional clouds requested at 32 and 64 sites have 30 and 63 actual distinct sites. The JSON records requested, pre-merge, and actual counts, and its score bound uses the actual count. Vertex tests have \(N=2^n\) and are explicitly a special geometry rather than independent dimension/count pressure. Nested depth and weight imbalance are separate changes. Retained Round 65 sources preserve their historical selection bias, while this round's receiver seeds are independent. There is no active new optimization or fitted exponent.

## Heldout observations and calibrations

The following are two-seed means of \(E_{G_H}/(HW)\), with SE \(\sqrt{\mathrm{SE}_1^2+\mathrm{SE}_2^2}/2\):

| Source | Estimate ± sample SE |
|---|---:|
| Correlated \(n=1,N=8,H=4\) | 0.63157 ± 0.00905 |
| Correlated \(n=1,N=64,H=4\) | 0.61426 ± 0.00945 |
| Correlated \(n=16,N=64,H=4\) | 0.32014 ± 0.01032 |
| Unequal cloud \(n=16,N=64,H=3^{-16}\) | 0.59627 ± 0.01347 |
| Equal nested \(n=1,N=64,H=4\) | 0.63336 ± 0.02226 |
| Equal nested \(n=16,N=64,H=4\) | 0.57028 ± 0.02105 |
| Grid \(n=1,N=16,H=2\) | 0.68291 ± 0.01523 |
| Grid \(n=1,N=1024,H=2\) | 0.66045 ± 0.01495 |
| Near cluster \(n=32,N=64,H=1\) | 0.66332 ± 0.02381 |
| Vertices \(n=4,H=8^{-4}\) | 0.48404 ± 0.01140 |
| Vertices \(n=8,H=8^{-8}\) | 0.49945 ± 0.01707 |
| Vertices \(n=8,H=2^{-13}\) | 0.79141 ± 0.01584 |
| Retained perturbed \(n=4,N=16\) | 0.71913 ± 0.01191 |

These cases do not show growth under the registered changes, but they are not a uniform upper test over arbitrary sources. A favorable grid profile does not rule out a multiscale or geometrically different obstruction. The changed vertex cap produces a substantially different value at the same source, illustrating the importance of testing thresholds independently.

Cross terms remain material. In the near cluster \(n=32,N=64\), the actual energy estimate is 0.66332 while its source-diagonal estimate is only 0.01070. Conversely, the eight-dimensional vertex case at \(H=2^{-13}\) has diagonal estimate 0.64879 and total 0.79141. No diagonal-only proxy replaces the main signed integral.

The tail is also retained materially: it represents about 31% of near-cluster energy, about 11–12% of the one-dimensional \(H=2\) grid energy, and about 14% of four-dimensional \(H=8^{-4}\) vertex energy. Dropping it changes the tested quantity.

For a single atom of mass \(p\), all dimensions and caps have exact ratio \(c=1-e^{-1}=0.63212056\). Cube-cone radial integration gives \(dx=dv\,d\sigma\), cap \(v\ge p/H\), and point energy \(cp^2/v^2\). Six calibrations use mass 3, cap \(7/3\), dimensions 1, 2, 4, 8, 16 and 32, and 4,096 draws each. Their means range from 0.62101 to 0.65187, with SE about 0.00988. The exact normalized infinity-tail integral is \(c^2/2\); the calibration tail estimates range from 0.19628 to 0.20603, consistent with that separate reference.

The analytic companion independently proves, for \(\mu=\tfrac12\delta_{-a}+\tfrac12\delta_a\), \(H=1\), \(a\ge1/2\),

\[
E_{G_1}=c+\frac{e+2/e-3}{64a^2-1}.
\]

At \(a=1/2\) the exact reference is 0.66238994, strictly larger than the one-atom value. Two fresh seeds of 4,096 draws give 0.662786 ± 0.009592 and 0.650530 ± 0.009490; their average is 0.656658 ± 0.006747. The strict inequality is established by the analytic formula, not by a Monte Carlo significance claim. This calibration rejects the proposed one-atom extremizer while leaving the general cap-energy budget unresolved.

## Separate uncollared window proxy

The optional diagnostic window is normalized volume \(\tau\in[1/4,4]\). Its local maximal gate tests actual averages at both endpoints and at every physical arrival within that window. The window energy uses the same signed event profile, cut at the endpoints. Results include window energy on the global cap, on this local cap, and the local-only difference. The global cap is contained in the local cap.

This local gate is **uncollared**: \(D(\tau)\) uses averages at \(e\tau\), reaching \(4e\), while the gate only tests through 4. It is not the matching-window LCE hypothesis or a test of its return theorem. An all-receiver window-score bound is still available: each one-source kernel has window norm at most \(8a_i^2\), and full-time norm \(ca_i^2/\tau_i^2\). Splitting at \(\tau_i=a_i\), Cauchy and the individual proposal component give envelope \(32N\), independently of gate membership.

The proxy differs numerically from the global-gated window: the local-only mean is about 0.0533 in the \(N=1024,H=2\) grid, 0.0627 in the eight-dimensional \(H=8^{-8}\) vertex source, and reaches 0.0913 in one correlated row. These observations diagnose gate mismatch and do not support the actual collared LCE claim.

## Finite rational and high-precision audit

All 280 retained extreme points are independently audited using actual binary machine-coordinate distances and rational source masses. Their energy enclosures use integer endpoints on a \(10^{-100}\) grid; each multiplication, reciprocal and square is rounded outwards by integer floor and ceiling. The exponential enclosure is derived from
\(e_- =\sum_{k=0}^{100}1/k!\) and
\(e_+=e_-+[1/101!]/(1-1/102)\).
Actual grouped \(\tau_i/e\) and \(\tau_i\) event intervals are proved ordered at every audited point; coefficients and inverse-square interval integrals are then enclosed, including the infinite tail. This supplies a finite pointwise enclosure of the true energy, rather than merely agreement of two nearest-rounded calculations. It supplies no interval enclosure for the receiver integral or sampler.

The 280 closest gate points are checked against exact rational all-scale maxima. Seven additional controlled points cover positive-volume common-face ties with unequal masses, and small random sources in dimensions 1, 4, 16 and 32. Decimal event sums at precisions 80 and 120 provide independent numerical refinement. A separate pair-Gram expansion is checked for 120 retained extremes with at most 16 sites and all seven controlled cases; expensive quadratic Gram evaluation is not repeated for the large grids.

Maximum finite discrepancies are \(5.92\times10^{-15}\) for floating total energy, \(6.07\times10^{-15}\) for nonzero floating window energy, and \(4.76\times10^{-15}\) for full proposal density. The largest relative rational enclosure width at actual extremes is \(1.10\times10^{-89}\); the far-away 32-dimensional controlled point has tiny energy and a larger relative width \(1.44\times10^{-41}\), still an enclosure. The largest nearest-rounded 80/120-digit energy difference is \(3.20\times10^{-78}\), and the largest event/Gram difference is \(7.45\times10^{-79}\). Every retained classification agrees with the exact gate checks.

Across all draws, 56,023 rows used exact binary physical grouping, correcting 125,389 false log-equality boundaries. The smallest sampled cap-gate log-margin is \(2.93\times10^{-6}\); no row triggered the near-gate main fallback. Exact retained-point checks remain independent of that fallback.

Current L01/L02/H05/L03 entries and relevant method/interface restrictions were reread. This program's explicit integer outward arithmetic is a finite certificate whose rounding rules are stated; it does not validate a general floating interval-library API. Nearest-rounded Decimal comparisons are separately labeled. Machine-coordinate point certificates do not certify classifications at every receiver, ideal continuum sampling, Monte Carlo means, arbitrary positive-source bounds, or transfer from atomic samples to an unrestricted source class. No indicator or uncollared-window proxy is substituted for the true global cap energy.

## Reproduction and freeze

Run without `--pilot`:

```sh
/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 -B /Users/zhengzhihao/Desktop/T/output/centered_cube_round069_20261011/cap_energy_probe.py
```

The program is standalone, reads no prior-round runtime files, and writes adjacent `cap_energy_results.json`. `--pilot` intentionally overwrites the output with pilot-only data and is not the replay command. Python 3.12.14 / NumPy 2.3.5 were used, with BLAS thread counts set to one. The final run exited 0 in 14.1034 seconds. The parent independently replayed it in a temporary directory: exit 0, 14.0763 seconds, byte-identical JSON. There is no live session. Runtime is excluded from the serialized output.

Frozen SHA-256:

- `cap_energy_probe.py`: `4a48b31dd0dc8b05a7241f8891b2ad0e70d51ad0ebc9cd403170ec28d46313fd`
- `cap_energy_results.json`: `955f17ddf3fd3c5b99be7e84a4b7095315674ab48c00eef74ed0d88ed115a269`

The script and data are frozen; no further sampling or edits are planned.


## Independent verification receipt

```json
{
  "main": {
    "exit_code": 0,
    "seconds": 14.076284542003123,
    "byte_identical": true,
    "expected_sha256": "955f17ddf3fd3c5b99be7e84a4b7095315674ab48c00eef74ed0d88ed115a269",
    "actual_sha256": "955f17ddf3fd3c5b99be7e84a4b7095315674ab48c00eef74ed0d88ed115a269",
    "script_sha256": "4a48b31dd0dc8b05a7241f8891b2ad0e70d51ad0ebc9cd403170ec28d46313fd",
    "directory": "/var/folders/lq/2c4qbz2n0354_tnttkv_qsz00000gn/T/round069-main-replay-zubf7ets",
    "stdout_tail": "1927208594 0.02112871257202627\nheldout 49 grid 1 1024 0.6542231931680338 0.018502659703042913\nheldout 50 vertices 4 16 0.4936952987911922 0.016244768486569056\nheldout 51 vertices 4 16 0.7679142835784531 0.018239497117669774\nheldout 52 vertices 8 256 0.500485351937331 0.02491999668346069\nheldout 53 vertices 8 256 0.7985824102307613 0.02323200940891496\nheldout 54 near_cluster 1 16 0.6294740303017441 0.032805968843463366\nheldout 55 near_cluster 1 64 0.573462324671888 0.03276228674987443\nheldout 56 near_cluster 4 16 0.5697883090050176 0.03168094126290887\nheldout 57 near_cluster 4 64 0.6567121129397564 0.03422553103946794\nheldout 58 near_cluster 16 16 0.6866855652074632 0.03335265485092976\nheldout 59 near_cluster 16 64 0.6512156433625295 0.033854246101320117\nheldout 60 near_cluster 32 16 0.6555027758867373 0.032527684125475784\nheldout 61 near_cluster 32 64 0.6883145114577967 0.03407419052255772\nheldout 62 diagonal 1 64 0.7327255556065675 0.020840039121791165\nheldout 63 adversarial 4 16 0.7227948275919551 0.01690711459384284\nheldout 64 binary_subset 4 16 0.7435132256298386 0.01628641182026956\nheldout 65 adversarial 16 64 0.6291796283991087 0.021044358848916308\nruntime 14.026927665996482\n",
    "stderr": ""
  },
  "embedded": {
    "energy_to_weak.md:0": {
      "sha256": "3a0c4d61df9dde539529e99a9ca479f06e9fab465075ae3ade7696b8f6fbe1f1",
      "exit_code": 0,
      "seconds": 0.2701930000039283,
      "stdout": "PASS multistage guard {'global_cap_gap': 15, 'endpoints': 15, 'collar': 36153, 'absorption': 240, 'atomic_grid': 175, 'decimal_paths': 209, 'crossings': 106}\nnearest-rounded 80/140 maximum relative difference 2.022069625342259030660099521276809467055691762837981629880504000324990642547160280386515688896341763571991148184141462754650931945415533687780732830161544970603E-79\n",
      "stderr": ""
    },
    "indicator_window_test.md:0": {
      "sha256": "73056d24496d2a97983dce2d5df7bb4608a22bfec596c3eb1e228c2cdf700b7d",
      "exit_code": 0,
      "seconds": 2.6825266250016284,
      "stdout": "{\"exact\":{\"endpoint_collar_comparisons\":4725,\"nonglobal_local_good_receivers\":345,\"parent_ties\":42,\"root_fee_checks\":144,\"selected_cells\":144,\"single_threshold_budget_pairs\":640,\"source_configurations\":144,\"threshold_averages\":29322,\"tiny_cells_without_global_shield\":57,\"translation_integral_majorants\":144,\"window_receiver_scales\":7748},\"scope\":\"Fraction finite local geometry/error-majorant checks; rational q>1; local indicator test unproved\"}\n",
      "stderr": ""
    },
    "two_atom_cap_calibration.md:0": {
      "sha256": "71f52fc30218276cf6e08923d5c4666eea168bb5cb438c887e82eccd42bf5e3a",
      "exit_code": 0,
      "seconds": 0.01872604100208264,
      "stdout": "{\"exact_beta_separation_pairs\": 30, \"scope\": \"rational algebra of the two-atom formula; actual exp(-1) evaluated separately\"}\n",
      "stderr": ""
    },
    "indicator_transfer_guard.py": {
      "sha256": "2d2632ba977119aeade4e7152d02c8d4032ba71b8c5e8771a3f1936515605716",
      "exit_code": 0,
      "seconds": 0.2463513749971753,
      "stdout": "{\"exact\":{\"arrival_and_endpoint_scales\":1811,\"boundary_or_inside\":24,\"configurations\":12,\"distance_factor_checks\":649,\"mass_conservation\":12,\"positive_distance\":192,\"receivers\":216},\"scope\":\"finite Fraction transport geometry, not a numerical proof of capped-energy convergence\"}\n",
      "stderr": ""
    }
  },
  "frozen_hashes": {
    "energy_to_weak.md": "0d57ce07f8b286b066c5bc40029be880a585ac43038d3eebf4ea2516aaaaeed5",
    "energy_to_weak.tex.txt": "3043d4e43ad6085508dea4c41ec5366f0eebbc50987e54e7842cfa3b53164d76",
    "indicator_window_test.md": "82b46cf21406ef866857681947dd852afdaafc01b97e78e102dabf8648bdb88d",
    "indicator_window_test.tex.txt": "dd1096f839a834eeeff42a7e267b878b74a7ee7e65d771592c936f9c160495c9",
    "indicator_atomic_transfer.md": "4b31175c1c111c769c227afb91ebf181313d6d85205cc1a8b6c20b77d694d300",
    "indicator_atomic_transfer.tex.txt": "c375b0e351c5f3f2d6b72d9e8c47de0b8fee7ea03976ebb72ef69a61b3006120",
    "two_atom_cap_calibration.md": "984bd3a0c0d7696a20b61a7dfdc05f92423d6ed655101815219a8b0659672253",
    "two_atom_cap_calibration.tex.txt": "7bc7ce9092bb59ccda80925847d24c21c2bfcfd55cfbcf6798196c7c186f9fc4",
    "cap_energy_numeric.md": "5563e7216be7e05a59e1641d726f08ddf30f31597f2d82bf76f66fc0dcd8746f",
    "indicator_transfer_guard.py": "2d2632ba977119aeade4e7152d02c8d4032ba71b8c5e8771a3f1936515605716"
  },
  "peer_review": {
    "finite_indicator_reverse": "two independent read-only audits found no substantive defect",
    "two_atom_formula": "independent analytic audit found no substantive defect"
  },
  "scope": "Finite checks and peer audits support the recorded proofs; no numerical claim proves the missing cap-energy estimate."
}
```
