# R667 A1：endpoint 接收几何与来源容量分配检查点

**结论：未得到新的完整 P_box≤A U 估计。** 本轮检查了将正 endpoint 接收点运回已付父盒密度的两种具体几何映射；二者均缺少本题需要的联合质量控制。以下只保留精确支撑、映射核算与决定性停点，不把它们算作主预算进展。沿用 R666 A2 §§2–4 的全部真实对象；C_box≤16U/31 不受影响。

## 1. 先保留准确的非负接收密度

固定 i、ℓ 的条件 slice。记 h_i=s_i/a，w_i=2h_i，c_i=c_0s_i，r=r_iℓ(x,v)。R666 的二值恒等式直接给出

\[
 b_+(x,v)=\frac r{w_i}\,M(1-C)O(1-DI).                 \tag{1}
\]

这里 r 是按**完整实际 first-k key**、全部其他源约束、原 L_h 及该源所有横向约束取的最大合格半径；M,C,D,O,I 的定义保持不变。特别是 (1) 仍保留其他 key 隐藏当前面的条件 C、其他 marked-parent 与 repeat mask 的条件 M。

正 integrand 必须满足 r>0 且

\[
 s_i+vr<|x_\ell-y_{i\ell}|<(1+2/a)s_i+vr.              \tag{2}
\]

这是 O 的准确开带；边界零测。因为实现 r 的整个 key 在近端 pinned 配置覆盖 x，对其每个标签 j 都有

\[
 \max_m (|x_m-u^{\rm near}_{jm}|-c_0s_j)_+\le vr,
 \qquad x\notin A_j^{\prime,\rm near}.                 \tag{3}
\]

这里 u_j^near 只有 j=i、m=ℓ 的坐标被 pin，其余坐标不变。第二项来自真实 S 的 marked-parent 排除，而不是另加假设。因此整个 key 的每个源都可接近这个 receiver，但没有任何一个源已经接收该点。

(2) 的宽度是 w_i，但其位置含 r_iℓ(x,v)。r 本身随 receiver 变；不能把整个正支撑当成一个事先固定位置、宽度 w_i 的 slab。若在有限面安排中分成 r 恒定的 cell，必须保留这些 cell 的并集和映射后重叠。这是本轮几何分配中一个实际需要核算的量。

## 2. 法向内移只接收 D=1 的部分

取 e=sign(x_ℓ−y_iℓ)，在 r 恒定的 cell 上考虑

\[
 T_{i\ell}(x)=x-vr\,e e_\ell.                           \tag{4}
\]

按 (2)，接收点的法向坐标落在

\[
 s_i<|T_{i\ell}(x)_\ell-y_{i\ell}|<(1+2/a)s_i.
\]

在近端 pinned 配置中，这一整个法向带属于 i 的父盒法向区间：正向近端父盒的上端恰为 y_iℓ+(1+2/a)s_i，负向同理。横向坐标没有改变，所以

\[
 T_{i\ell}(x)\in A_i^{\prime,\rm near}
 \quad\Longleftrightarrow\quad D=1.                    \tag{5}
\]

因此 (4) 在 D=0 的正压力上不提供任何父盒接收。正压力并不强制 D=1；(1) 在 D=0 时正好是 M(1−C)Or/w_i。这部分不能并入已付的 C_box，后者恰含 D I。

即使限制在 D=1，(4) 在每个 r-cell 上的 Jacobian 是 1，也仍未证明不同 r-cell、不同 ℓ、不同源的推送重数有绝对界。近端 pin 的父盒截面也不是原 Unif(B_i) 平均接收密度。故“法向带很薄、内移 Jacobian 为 1”尚不能将整个压力付到 ∫L1。

横向越界不只是端点惯例。取 s_i=1、c=1+1/a、vr=c/2，两个坐标为

\[
 x_\ell=3c/2,\qquad x_m=5c/4\ (m\ne\ell),
\]

并把冻结横向中心取为 y_i。此时 O=1、I=0、D=0，(2) 严格成立；(4) 后坐标为 (c,5c/4)，仍在父盒之外。这个例子只验证允许的局部 slice 几何，不声称构造了实际高 T near 输入。

## 3. 多坐标收缩确实接收，但带回指数 Jacobian

若选择实现 r 的整个 key 的任一标签 j，则 (3) 保证 x 位于 Q(u_j^near,c_0s_j+vr)。自然的全坐标收缩

\[
 \widehat T_j(x)
 =u_j^{\rm near}+
       \frac{c_0s_j}{c_0s_j+vr}(x-u_j^{\rm near})          \tag{6}
\]

确实落入 A_j^prime,near。在冻结 r 的 cell 上其逆 Jacobian 恰为

\[
 J_j^{-1}=(1+vr/(c_0s_j))^n.                            \tag{7}
\]

例如 vr/(c_0s_j)=1/2 时就是 (3/2)^n。正常源、法向和时间的系数 r/w_i 没有在这一变化变量中消失。把 j 改为另一个 key 标签，还要核对 i 的 endpoint 压力如何由 j 的实际事件/来源预算承担；不能凭“key 有 k 个源”免费除以 k。

也可以保证推送点属于**所有** j 的 jitter 实现下的父盒，避免 pin-law 问题。由 u_j∈B_j 及 (3)，令

\[
 \beta_j=1+2/a+vr/s_j,\qquad
 T_j^0(x)=y_j+(x-y_j)/\beta_j .                          \tag{8}
\]

则 T_j^0(x)∈A_j⊂A_j′。但此时逆 Jacobian 是 β_j^n，仍有相同指数代价。实际 r 的不同 cell 的 image overlap 还需另算；(7)、(8) 不是包含该重叠后的充分估计。

将超出父盒的坐标直接 clipping 到父盒边界可避开显式指数伸缩，却把正体积压到低维面，因而不产生相对于普通 Lebesgue 父盒密度的有界密度推送。用一层厚度再平滑时必须重新支付该层的体积比；不能将降维映射当作质量免费进入父盒。

这些计算只否定了上面几种**未经额外几何控制的具体收费方式**，没有证明更好的全 key、跨源接收分配不存在，也没有给 P_box 的下界。

## 4. 可用的真正接收预算与本轮欠缺的东西

父代理提供的接收量

\[
 L_1(z)=\sum_jq_j\Pr_{u_j\sim\mathrm{Unif}(B_j)}(z\in A_j'),
 \qquad \int L_1(z)\,dz=c_0^nU                         \tag{9}
\]

是完整、一次支付的真实预算；乘以 all-source void 概率 Z(z) 仍可付。要使用它，实际传输必须同时处理：跨所有源与全部 n 法向的接收重数、r-cell 选择与其 image overlap、以及被接收源的实际 q_j 权重。上述法向映射在 D=0 处没有接收，径向映射的现成估计保留 (7)，边界 clipping 又不受 (9) 的 Lebesgue 密度支配。因此本轮没有获得一个能直接喂入 (9) 的质量上界。

没有假设 endpoint 密度在原 receiver x 上逐点受 Z(x)L1(x) 控制，也没有将正部移出条件 slice。没有用一个来源的整个 shell 作为本轮的新付款结论，没有把未付的接收重数改名为预算。

A2 的首次进入证书提供另一种保留 full key 的组织方式；本文件没有证明其 selected-entry 的几何接收容量，也没有用固定 key 的进入概率替代实际 selected key。两条路线目前都需要一个新的联合估计，不能互相循环引用来补齐。

## 5. 实际轻量核验与终点

运行了 Python 3.15.0 标准库 Fraction，核对 (2)、(5) 的局部几何与 (7) 的精确量级；未运行模拟或重计算。以下是实际代码，未另建文件：

```python
from fractions import Fraction as F
import sys
print('Python',sys.version.split()[0])
for n in (2,16,256):
    a=32*n; h=F(1,a); c=1+h; vr=c/2
    x1=c+vr; x2=c+vr/2
    O=abs(x1-(c+vr))<h
    I=abs(x1-c)<h
    D=x2<=c
    assert O and not I and not D
    assert 1+vr < x1 < 1+F(2,a)+vr
    inward=(x1-vr,x2)
    assert inward[0]==c and inward[1]>c
    print('n=',n,' outer-band=True positive-binary-factor=',int(O and not(D and I)),
          ' normal-transport-outside-parent=True',sep='')
for n in (16,256,4096):
    lower_exponent=(3**n).bit_length()-1-n
    print('inverse radial Jacobian at vr/c=1/2, n=',n,' >= 2^',lower_exponent,sep='')
```

实际输出：

```text
Python 3.15.0
n=2 outer-band=True positive-binary-factor=1 normal-transport-outside-parent=True
n=16 outer-band=True positive-binary-factor=1 normal-transport-outside-parent=True
n=256 outer-band=True positive-binary-factor=1 normal-transport-outside-parent=True
inverse radial Jacobian at vr/c=1/2, n=16 >= 2^9
inverse radial Jacobian at vr/c=1/2, n=256 >= 2^149
inverse radial Jacobian at vr/c=1/2, n=4096 >= 2^2396
```

这些有限点只核对一般公式的代数，不是实际 near 状态的样本，也不是原目标的反例。**最终状态仍是 P_box 的全局绝对预算未付。** 已保存这一检查点，停止本任务；未改其他文件、未 Git/PDF、未启动其他代理。
