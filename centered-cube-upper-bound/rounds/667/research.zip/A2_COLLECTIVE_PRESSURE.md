# R667 A2 — a common-entry logarithmic bound for the endpoint pressure

## Status and frozen scope

A common-entry ratio bound is proved below for the complete positive endpoint pressure. It integrates all actual inverse jitter widths and all n directions in v through **one first-success full key per receiver and realized configuration**, without replacing the common entry cost by nk independent fees. No new absolute source-budget payment or strict contraction has been obtained. A selection-entropy calculation is retained only as a diagnostic: its final envelope is already larger than E|S(1)| and therefore does not improve the global budget.

Thus this does not close the pure sqrt(n) problem. The next valid target remains the original P_box or the sharper actual entry ratio, and the analysis identifies why generic monotone-product influence or entropy replacements do not pay it. All original q_i, I_h, L_h, full shared first-k lists, actual event order and future-repeat pruning remain unchanged. The only product law is the independent auxiliary Unif(B_i) center law from R666.

Use the definitions of R666 A2_BOX_JITTER and REPORT. Write S(v)=S′_k(v), w_i=2s_i/a, c_i=c0s_i, and retain only completed keys whose every label has N_i=1. Every other key is already covered by Q′_rep for the entire interval v∈[0,1]. R666 proves

    E|S(1)| = P_box + C_box,       0≤C_box≤(16/31)U.          (0.1)

The task here is exactly the same P_box.

## 1. Positive endpoint fibers have a one-sided success fraction

Fix a receiver x, the entire history, a coordinate (i,ℓ) with N_i=1, and all center coordinates except t=u_iℓ. Use the R666 slice definitions M,C,D,r, where r=r_iℓ(x,v) is the maximum radius of eligible full keys containing i and every eligibility test except the iℓ constraint is imposed. Empty eligibility gives r=0. Let

    e_iℓ=sign(xℓ−y_iℓ),
    p_iℓ=(e_iℓ(u_iℓ−y_iℓ)+w_i/2)/w_i ∈[0,1].              (1.1)

Choose either e at zero. For fixed x, these p variables are independent uniforms before any success conditioning. They move the corresponding center coordinate from its far endpoint toward its near endpoint.

Let f_iℓ(t)=1{x∈S(v)} under this single-coordinate variation and define the exact positive endpoint indicator

    A_iℓ(v)=[f_iℓ(t_near)−f_iℓ(t_far)]_+ ∈{0,1}.           (1.2)

It is measurable with respect to the frozen variables, excluding u_iℓ. If A_iℓ=1, then M=1, C=0, and the i-parent exclusion holds throughout this whole fiber: it holds at the near endpoint and is decreasing as the center moves toward x. Therefore the actual pruned indicator f_iℓ is a single increasing interval on this fiber, not a general masked Boolean function.

Define α_iℓ(v) as the fraction of this coordinate interval satisfying the containing-i maximum-radius constraint; define it to be zero when eligibility is empty. More explicitly, when r>0,

    α_iℓ(v) = clip_[0,1]((c_i+v r−|xℓ−y_iℓ|+w_i/2)/w_i).  (1.3)

The formula is also valid when xℓ lies inside its jitter interval because c_i>w_i then makes the whole interval admissible. When A_iℓ=1, one has 0<α_iℓ<1 outside null boundary cases, and

    f_iℓ(u_iℓ)=1{p_iℓ≥1−α_iℓ}.

Consequently, with 0/0 interpreted as zero on A=0,

    E_{u_iℓ}[1{x∈S(v)} A_iℓ / α_iℓ] = A_iℓ.               (1.4)

This is where the inverse success-side length appears. Replacing endpoint influence by success probability without this factor is invalid.

For fixed x, history and frozen center coordinates, eligibility only grows with v. Thus r(v) is a nondecreasing finite step function, and α(v) is nondecreasing, with nonnegative jumps. On each open interval where the eligible maximum is fixed and 0<α<1,

    d(log α)/dv = r/(w_i α).                               (1.5)

No derivative of a maximizer in x is asserted.

## 2. All live pivotal coordinates share the same maximal covering radius

Now fix the entire center configuration as well. Suppose x∈S(v) and A_iℓ(v)=1. Since C=0, every currently covering retained full key contains source i. The key realizing r_iℓ is itself covering at the current coordinate: any covering containing-i key has radius at most r_iℓ, and its iℓ interval is contained in that of the maximum eligible key. All other constraints of the maximum eligible key have already been imposed.

It follows that

    r_iℓ(x,v) = R_*(x,v),                                  (2.1)

where R_* is the largest radius among all currently covering full keys. Thus the different endpoint coordinates can be allocated to one common maximal-radius actual key; they are not assigned independent selected targets.

Using (1.4) in the definition of P_box, then applying (2.1), gives the exact collective formula

    P_box = E ∫_{R^n} ∫_0^1 1{x∈S(v)} R_*(x,v)
                     Σ_{i,ℓ:A_iℓ(v)=1} 1/(w_i α_iℓ(v)) dv dx.       (2.2)

Each participating source necessarily has N_i=1. The summation in (2.2) retains every normal coordinate, and every term includes the actual radius and inverse jitter width. There is no external positive-part operation: A_iℓ is formed within the original conditional slice.

## 3. Integrating v retains the common entry value

For x∈S(1), let v0 be its first entry time into S(v). The marked and repeat masks are independent of v, while every retained clipped key grows with v. A finite actual key h0 attains this first entry, and continues to cover x for every v≥v0. Choose one such key measurably, for example by the original target order among ties, and denote its full k-label set by J0(x,u,history).

For precision, each eligible clipped target has entry time

    V_h = max_{j∈J_h,ℓ} (|xℓ−u_jℓ|−c_j)_+ / R_h,

with V_h=+∞ if x∉L_h or the key is not retained. For x outside the masks, v0=min_h V_h; choose a minimizing target. Boundary conventions at v0 do not affect the integrals. Since each retained source has N_i=1, the k labels in J0 are distinct.

At every v≥v0, A_iℓ(v)=1 implies i∈J0. Otherwise the persistent h0 key would be a covering key excluding i, forcing C=1 and A_iℓ=0. This uses one key for the entire v interval even if the current largest covering radius R_* changes repeatedly.

At v0, every coordinate of J0 satisfies its expanded-parent constraint. Its conditional success fraction is at least 1−p_iℓ>0, almost surely; all original uniform coordinates are strictly interior almost surely even though J0 was selected. The larger eligible-radius fraction α_iℓ(v0+) is at least that amount. Thus the following logarithms are well defined. Applying (1.5), keeping the actual entry value, and discarding only nonnegative jump increases gives

    ∫_0^1 1{x∈S(v)} A_iℓ(v) r_iℓ(v)/(w_iα_iℓ(v)) dv
        ≤ log[α_iℓ(1)/α_iℓ(v0+)]                          (3.1)

for each coordinate of J0. An active-time set with several components causes no problem because α never decreases. A jump exactly at entry is not charged; the integration starts on the right of v0. If v0=1 the left side vanishes, and the endpoint ratio is taken as one. One may equivalently use the value at v0 rather than its right limit to obtain a weakly larger upper bound.

Consequently the complete pressure satisfies

    P_box ≤ L_entry,
    L_entry := E ∫_{S(1)} Σ_{i∈J0}Σ_ℓ
                         log[α_iℓ(1)/α_iℓ(v0+)] dx.       (3.2)

This retains every inverse-width/radius factor through the actual logarithmic integration; none was declared dimension-free individually.

For a fixed, unselected actual retained key h and fixed x in its original L_h, define its one-coordinate success probabilities

    F^h_iℓ(v)=Pr_{u_iℓ}(|xℓ−u_iℓ|≤c_i+vR_h),
    H_h(v)=∏_{i∈J_h}∏_ℓ F^h_iℓ(v).                        (3.3)

The history is fixed, labels are distinct, and the original center coordinates are independent, so H_h is precisely the CDF of this key's raw entry V_h for v≥0. It includes no parent-void conditioning and no selection of h. Under the actual selected realization, every other coordinate of J0 is eligible at v0, so

    α_iℓ(v0+) ≥ F^{h0}_iℓ(v0).

Since α_iℓ(1)≤1, (3.2) gives the sharper collective certificate bound

    P_box ≤ L_entry ≤ L_selected,
    L_selected := E ∫_{S(1)} [−log H_{h0}(V_{h0})] dx.      (3.4)

The H appearing here is the unconditioned fixed-key CDF, evaluated under the actual selected-key and fully masked receiver law. This distinction is essential.

For comparison only, replacing each entry fraction by 1−p gives the coarser but valid bound

    P_box ≤ E ∫_{S(1)} Σ_{i∈J0}Σ_ℓ log[1/(1−p_iℓ)] dx.

It is not the proposed main budget: it loses the common entry maximum and can pay nk times a typical coordinate logarithm.

## 4. Fixed-key quantiles, and an explicit actual selection-entropy fee

For any fixed key with finite raw entry V and CDF H, the random variable H(V) stochastically dominates Unif[0,1]. This also holds with atoms: represent V by the generalized inverse H^{-1}(U); then H(V)≥U pointwise. In particular, writing Z=−log H(V),

    Pr(Z>t)≤e^(−t),     E Z≤1.                             (4.1)

The more precise truncated form is

    E[1{V≤1} Z]≤H(1)[1−log H(1)],                         (4.2)

with the value zero at H(1)=0. Indeed {V≤1} corresponds to U≤H(1) under the inverse transform, and −log H(V)≤−log U. Integrating −log U proves (4.2). Atoms can only reduce the right-tail integral.

Neither (4.1) nor (4.2) can be applied to h0 after selecting it. The selection cost can instead be isolated exactly as follows. Fix the actual history and x. For every candidate retained target in its clip, let

    p_h=Pr_centers(x∈S(1) and h0=h),
    p=Σ_h p_h=Pr_centers(x∈S(1)).                           (4.3)

These probabilities include the actual parent and repeat masks, all competing keys and the original clips. No key-independence assumption is made. For any h, the fixed-key exponential tail (4.1) and the event probability p_h give

    E_centers[1{x∈S(1),h0=h} Z_h]
      =∫_0^∞ Pr(x∈S(1),h0=h,Z_h>t)dt
      ≤∫_0^∞ min(p_h,e^(−t))dt
      =p_h[1−log p_h].                                    (4.4)

The p_h=0 term is defined to be zero. Therefore

    P_box ≤ L_selected
      ≤ E_history ∫_{R^n} Σ_h p_h(x)[1−log p_h(x)] dx.      (4.5)

For p>0 let π_h=p_h/p. The integrand is exactly

    Σ_h p_h(1−log p_h)=p[1−log p+H(π)],
    H(π)=−Σ_h π_h log π_h.                                 (4.6)

This is a valid but non-improving upper envelope for the same P_box. It isolates receiver success probability times its negative logarithm and actual first-key selection entropy; it does not pay either quantity. The formula keeps actual probabilities rather than replacing H(π) by log(number of targets).

The primary remaining target is the original P_box≤AU, or an effective AU bound or genuine summable contraction using the actual L_entry ratio in (3.2). No such bound is obtained here. The fixed-key unit quantile fee has not been promoted to a selected-key unit fee. In fact (4.6) is pointwise at least p, so its integral is at least E|S(1)|=P_box+C_box≥P_box. Therefore (4.5), taken as a final budget, is weaker than the already known P_box≤E|S(1)|. It is not a new global improvement and must not become a renamed main target. Its only use here is diagnosing where deleting actual key selection would be invalid.

The first-failing-coordinate product-cell decomposition under global void, communicated by the parent and independently checked by S1, does not change this conclusion. Its exact mixture weights must be retained. Cells can have short coordinate widths; original pinned endpoints can cross cells; and receiver success and first-key selection remain functions of the same full history and centers. This proof operates under the original box law and never replaces the original endpoints by those of a void-conditioned cell.

### Fixed-receiver diagnostic: product law, void and a single full key

This is a fixed-receiver structural diagnostic for a pointwise-in-receiver contraction with coefficient θ<1. It does not test a Lebesgue-integrated global contraction and is not an actual near-input counterexample. In one spatial dimension let every one of k key sources have independent u_i∼Unif[−h,h], h=1/32, c=33/32; take the single key radius R=c and the receiver x=c+2h. The marked parents all exclude x for every possible center, since x−u_i≥c+h>c. Thus the parent void is deterministic, and no mask penalty or incomplete-key selection is involved. The individual raw entries are

    V_i=(2h−u_i)/c ∈[h/c,3h/c]⊂(0,1),
    V=max_i V_i,     H(v)=F(v)^k,

where F is the uniform CDF on this interval. Once the last source enters, all containing-i fibers are eligible, α_i(V+)=F(V), and α_i(1)=1. Therefore the actual ratio in (3.2) for this single key is

    Σ_i log[α_i(1)/α_i(V+)]=−log H(V).

Because H is continuous, its expectation is exactly 1, while the receiver-success probability at v=1 is also exactly 1. The inverse-width integral likewise gives unit positive pressure and zero parent correction at this receiver. Hence this fixed-receiver expectation admits no strict subunit coefficient based on product/void/common-key structure alone, even with k distinct labels. This single-receiver calculation does not disprove a Lebesgue-integrated global contraction.

These coincident source boxes cannot supply the actual high-T near-family configuration under the inherited admission and owner conditions. No claim about an actual-input lower bound follows. The diagnostic only prevents inferring a strict fixed-receiver contraction from these reduced assumptions; actual geometry or integration may provide additional gains. They have not been incorporated into such a contraction in this bounded task.

## 5. Why bare product monotonicity is quantitatively insufficient

This is a diagnostic about the proposed general influence shortcut, **not an actual near-family counterexample**. Let p_1,…,p_D be independent uniforms and let

    G(p)=∏_{j=1}^D 1{p_j≥ε},     ε=1/D, D≥2.

Even this unmasked increasing observable has

    Pr(G=1)=(1−ε)^D,
    Σ_j E[G(p_j=1)−G(p_j=0)]=D(1−ε)^(D−1),
    (total endpoint influence)/Pr(G=1)=D²/(D−1).            (5.1)

So a dimension-free, or generic square-root-D, bound on these uniform-coordinate endpoint influences cannot be imported from unbiased Boolean-cube intuition. A common positive weight merely multiplies both influence formulas; variable r/w weights require still more justification.

For the coarser coordinate-log bound only, its successful-key logarithmic cost is

    E[1{G=1} Σ_j log(1/(1−p_j))]
        = D Pr(G=1)[1−log(1−ε)].                            (5.2)

This explains why the actual common entry in (3.2) must be retained. A single fixed-key entry score has the unit bound (4.1), despite this coarse coordinate-log cost. Selection among keys is a separate issue: even for M abstract independent uniform entry variables, choosing their smallest makes the selected score −log(min V_h) have expectation Σ_{j=1}^M 1/j. This follows by integrating its tail 1−(1−e^(−t))^M. That abstract example is not an actual near-family input. It only prevents deleting selection cost on the basis of the marginal unit bound. The actual high-T first-k sampling, admission geometry, and common receiver/source budget must supply the additional estimate for (3.2)–(4.5).

## 6. Actual bounded calculations and their decision scope

The calculation decision was fixed before running: (i) check the exact algebraic size of the generic monotone endpoint shortcut; (ii) check the monotone-radius logarithmic integration with jumps, especially that ignored jumps can only strengthen (3.1). The code below was actually executed with local python3. It created no experiment files and did not start MATLAB. Fractions in the first part are exact; logarithms in the second part use floating-point arithmetic. Neither finite check proves an absolute AU budget for the selected entry or the selection-entropy integral.

```python
from fractions import Fraction
from math import log
print('Monotone endpoint example (not an actual near-family input):')
for D in [2,4,16,64]:
    eps=Fraction(1,D)
    prob=(1-eps)**D
    influence=D*(1-eps)**(D-1)
    assert influence/prob == Fraction(D*D,D-1)
    print('D=%d success=%.12g total_influence=%.12g influence/success=%s' % (D,float(prob),float(influence),influence/prob))
knots=[0,.25,.6,1]
profiles=[(1,1,1),(.25,1,2),(.5,.5,4)]
checks=0
failures=0
max_ratio=0.
for rr in profiles:
    for w in [.25,1,2]:
        for d in [-.25,.2,.8]:
            for p in [.1,.25,.5,.9]:
                integral=0.
                for j,r in enumerate(rr):
                    left=max(knots[j],(d+w*(1-p))/r)
                    right=min(knots[j+1],(d+w)/r)
                    if right>left:
                        integral += log((right*r-d)/(left*r-d))
                bound=-log(1-p)
                failures += integral>bound+1e-12
                max_ratio=max(max_ratio,integral/bound)
                checks+=1
print('Monotone-radius log-integral checks=%d failures=%d max_ratio=%.15g' % (checks,failures,max_ratio))
```

Actual output:

```text
Monotone endpoint example (not an actual near-family input):
D=2 success=0.25 total_influence=1 influence/success=4
D=4 success=0.31640625 total_influence=1.6875 influence/success=16/3
D=16 success=0.356074130452 total_influence=6.07699849304 influence/success=256/15
D=64 success=0.364986524244 total_influence=23.7299175127 influence/success=4096/63
Monotone-radius log-integral checks=108 failures=0 max_ratio=1
```

The proofs of (3.2)–(4.5) are analytic, above. The common-entry refinement was supplied by the parent in MAIN_ENTRY_COST.md and integrated here with its selected-key quantifiers retained. The independent agent r665_final_account checked the ratio mechanism (1.4), the common-radius identity, persistence of J0, nonnegative α jumps and the actual entry ratio in (3.1)–(3.2), reporting PASS before final text binding. It explicitly did not certify AU or a new source budget. The deliverable stops with the original P_box or the actual L_entry ratio still unpaid; the dominated entropy envelope is not proposed as a new main objective.
