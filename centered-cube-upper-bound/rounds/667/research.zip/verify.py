"""R667 record/hash verification, not a certificate for the open AU estimate."""
from pathlib import Path
import ast,hashlib,json,re,sys
p=Path(__file__).resolve().parent
for name in ('verify.py','REPRO_CHECK.py'):ast.parse((p/name).read_text())
author=(p/'A2_COLLECTIVE_PRESSURE.md').read_text()
blocks=re.findall(r'```python\n(.*?)```',author,re.S);assert len(blocks)==1
assert (p/'REPRO_CHECK.py').read_text().startswith(blocks[0])
r=json.loads((p/'REPRO_RESULT.json').read_text());assert r['exit_code']==0 and not r['stderr']
assert 'checks=108 failures=0 max_ratio=1' in r['stdout']
for expected in ('influence/success=4','influence/success=16/3','influence/success=256/15','influence/success=4096/63'):assert expected in r['stdout']
tex=(p/'REPORT.tex').read_text();assert all(ord(c)>=32 or c in '\r\n\t' for c in tex)
stack=[]
for m in re.finditer(r'\\(begin|end)\{([^}]+)\}',tex):
 kind,env=m.groups()
 if kind=='begin':stack.append(env)
 else:assert stack and stack.pop()==env
assert not stack
audit=(p/'S1_VOID_LAW.md').read_text()
for name in ('REPORT.tex','A2_COLLECTIVE_PRESSURE.md'):assert hashlib.sha256((p/name).read_bytes()).hexdigest() in audit,'Final binding absent: '+name
status='not yet present; final package must check separately'
if (p/'MANIFEST.json').exists():
 for name,e in json.loads((p/'MANIFEST.json').read_text())['members'].items():
  f=p/name;assert f.stat().st_size==e['bytes'] and hashlib.sha256(f.read_bytes()).hexdigest()==e['sha256']
 status='PASS'
print(json.dumps({'status':'PASS','python':sys.version,'audit_bindings':'PASS','python_ast_files':2,'tex_structure':'PASS; no PDF','frozen_replay_record':'108 float checks and four exact Fraction outputs agree; no replay in this invocation','manifest':status,'general_AU_bound':'UNPROVED','entropy_envelope':'dominated by existing trivial upper bound; not progress in global budget'},indent=2))
