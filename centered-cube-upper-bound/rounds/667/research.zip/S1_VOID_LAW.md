# R667 void 条件律与首失败坐标乘积混合独立审查

**结论：精确条件律及 MAIN_VOID_MIXTURE 的首失败坐标表示 PASS。** 固定接收点后跨 label 独立性保留；中心条件律通常失去坐标独立性，但可用显式归一化权重分解为矩形 product laws。该合法表示不支付 P_box、AU 或任何新一般 source 预算。

本审查按父代理给出的实际有限输入合同独立推导，再读取本轮 `MAIN_VOID_MIXTURE.md`。没有重读 R664 历史、没有读取或审核 A2 的 weighted-influence 作者推导，不重做作者目标。只写本文件，不 Git/PDF/MATLAB。本文不把标准 void 后的计数倾斜当作新计数定理；本轮新增核对是 uniform-jitter 辅助中心的联合条件律、其显式 product-mixture，以及使用范围。

## 1. 固定合同及局部 void 事件

固定任意 n≥1、有限实际原输入、b=8，以及普通 Lebesgue receiver x。原 qᵢ、Iₕ、Lₕ、完整 first-k history 规则和真实不交 Fᵢ 均不改变。每个来源原本独立具有

- uᵢ∼Unif(Bᵢ)，Bᵢ=Q(yᵢ,sᵢ/a)，a=32n，sᵢ>0；
- Nᵢ=Nᵢ(8)∼Pois(λᵢ)，λᵢ=8qᵢ，与 uᵢ 独立；
- 给定 Nᵢ=m，其 [0,8] event times 是 m 个 iid Unif[0,8] 的 order statistics。

不同 label 的上述整个数据块跨 label 独立。令 cᵢ=c₀sᵢ，c₀=1+1/a，Aᵢ′=Q(uᵢ,cᵢ)，P′=⋃_{Nᵢ≥1}Aᵢ′，Q′=⋃_{Nᵢ≥2}Q(uᵢ,2cᵢ)。

定义中心允许域及其体积分数

Dᵢ,1(x)=Bᵢ\Q(x,cᵢ)，   αᵢ=|Dᵢ,1|/|Bᵢ|，
Dᵢ,2(x)=Bᵢ\Q(x,2cᵢ)，  βᵢ=|Dᵢ,2|/|Bᵢ|。

有 0≤βᵢ≤αᵢ≤1。由于外扩盒含原 parent，局部允许事件恰为

Eᵢ(x) = {Nᵢ=0}
       ∪ {Nᵢ=1, uᵢ∈Dᵢ,1}
       ∪ {Nᵢ≥2, uᵢ∈Dᵢ,2}。

三个部分互斥，且

E(x):={x∉P′∪Q′}=⋂ᵢ Eᵢ(x)。

此事件只取决于各 label 的 count 与 center，不取决于具体 event times。重复类不能只排除 parent 半径 cᵢ，必须排除 2cᵢ；零次类则完全不限制 center。

## 2. 精确三类概率和中心律

写 pᵢ,tail=1−(1+λᵢ)e^(−λᵢ)。局部归一化为

Zᵢ(x)=P(Eᵢ(x))
     = e^(−λᵢ)+λᵢe^(−λᵢ)αᵢ+pᵢ,tail βᵢ
     = e^(−λᵢ)[1+λᵢαᵢ+(e^(λᵢ)−1−λᵢ)βᵢ]。

给定 E(x)，下列局部三类联合描述精确成立：

| count class | 条件概率 | 该类内中心律 |
|---|---:|---|
| Nᵢ=0 | e^(−λᵢ)/Zᵢ | Unif(Bᵢ) |
| Nᵢ=1 | λᵢe^(−λᵢ)αᵢ/Zᵢ | Unif(Dᵢ,1) |
| Nᵢ≥2 | pᵢ,tail βᵢ/Zᵢ | Unif(Dᵢ,2) |

最后两类只在其概率为正时定义相应 uniform law。更细地，对 m≥2，

P(Nᵢ=m | E(x)) = e^(−λᵢ) λᵢ^m βᵢ/(m! Zᵢ)。

在 Nᵢ≥2 的正概率分支内，计数仍服从原 Pois(λᵢ) 条件于 ≥2 的分布，且与 center∼Unif(Dᵢ,2) 独立。这是因为所有 m≥2 共享同一个 βᵢ，而不是对每个 m 再引入不同的空间倾斜。

不先给定 count class 时，center 的完整条件密度为

pᵢ(u | E(x))
 = 1_Bᵢ(u)/(|Bᵢ| Zᵢ)
   ·[e^(−λᵢ)+λᵢe^(−λᵢ)1_Dᵢ,1(u)+pᵢ,tail 1_Dᵢ,2(u)]。

因此 center 与 count 在 void 后一般相关；不能只把原 Poisson rate 改为一个新 rate 后保留原 independent-center law。

局部 count 的条件 PGF 为

Gᵢ(z|E) = [1+λᵢαᵢ z+βᵢ(e^(λᵢz)−1−λᵢz)]
           /[1+λᵢαᵢ+βᵢ(e^(λᵢ)−1−λᵢ)]。

其条件平均计数是

E[Nᵢ|E]
 = λᵢ[αᵢ+βᵢ(e^(λᵢ)−1)]
   /[1+λᵢαᵢ+βᵢ(e^(λᵢ)−1−λᵢ)]。

该分布一般不是 Poisson；仅知道平均计数不能将其当作 homogeneous Poisson process。

## 3. 跨 label 独立性及精确时间律

因为原联合律是 label product 且 E(x)=⋂Eᵢ(x) 也是 label product 事件，对任意 label-local 可测 Hᵢ，

E[∏ᵢ Hᵢ | E(x)] = ∏ᵢ E[Hᵢ | Eᵢ(x)]。

所以整个局部块 `(center, count, ordered times)` 在该固定 x 的 void 条件下仍跨 label 独立。这个结论不延伸为 target/key 独立：不同 targets 的 Iₕ 重叠，使用同一来源的事件，first-k 选择和完整 keys 仍共享同一历史。

给定具体 Nᵢ=m、center 与 E(x)，事件时间的条件律完全不变：对 0<t₁<⋯<tₘ<8，联合密度为 m!/8^m；它与 center 独立。Nᵢ=0 时没有时间点，Nᵢ=1 时唯一时间均匀于[0,8]；Nᵢ≥2 时先抽上节截断 Poisson count，再抽其 uniform ordered times。空 count 与尾类的不同倾斜不改变 count-conditioned time law，但混合后的过程一般不再有 Poisson independent increments。

等价的完整局部 Janossy 表达是：令 η₀(u)=1，η₁(u)=1_Dᵢ,1(u)，ηₘ(u)=1_Dᵢ,2(u)（m≥2），则在有序时间 simplex 上

P(uᵢ∈du, Nᵢ=m, Tᵢ∈dt | E(x))
 = [e^(−λᵢ) qᵢ^m/(|Bᵢ|Zᵢ)] 1_Bᵢ(u)ηₘ(u) du dt₁⋯dtₘ。

对 simplex 积分给 8^m/m!，正好恢复上节各 count 概率；m=0 使用空时间 measure。跨 labels 的条件联合律就是这些局部块的乘积。此公式保留具体事件时间，不将 conditional selected-key labels 冒充 iid。

## 4. 退化、空条件与边界

在当前有限输入、有限 λᵢ、正半径合同下，每个 Zᵢ≥e^(−λᵢ)>0。因此

P(E(x))=∏ᵢ Zᵢ ≥ exp(−Σᵢλᵢ)>0。

即使接收点位于每个来源 parent 的可能范围内部，所有 counts 同时为0仍使 void 成立，所以整个 void 条件不会成为空条件。空来源族时 E 是必然事件。若改成无限 labels，不能未经核对把这一正概率结论移植过去。

αᵢ=0 时 Dᵢ,1 是零体积域，单次分支条件概率为0，必须删去而非定义零体积 uniform；此时 βᵢ=0，重复分支也消失。βᵢ=0 时只删重复分支。λᵢ=0 时 Nᵢ=0 必然、Zᵢ=1、center 仍 Unif(Bᵢ)，尾类 Pois|≥2 不应在此零概率分支上定义。若额外强行给定某个不存在的正次 count/零体积域，则该附加条件本身为零概率，不存在本文声称的条件 uniform law。

若允许 sᵢ=0，则 Unif(Bᵢ) 的 Lebesgue 形式无定义；本轮正半径合同已排除此问题，不擅自改作 Dirac law。所有 cube 边界在中心的绝对连续律下可任意选闭开约定；积分/Janossy 公式均不变。

## 5. 首失败坐标的显式 disjoint product-mixture

固定某个来源与正次 class，半径 r 取 cᵢ 或 2cᵢ。写 Bᵢ=∏_{ℓ=1}ⁿJℓ，各 Jℓ 宽 wᵢ=2sᵢ/a。令

Cℓ(r)=Jℓ∩[xℓ−r,xℓ+r]，
Tℓ(r)=Jℓ\[xℓ−r,xℓ+r]，
aℓ(r)=|Cℓ(r)|/wᵢ。

则内立方体交集相对体积是 ∏ℓaℓ，外部允许域 D(r)=Bᵢ\Q(x,r) 的比例为 p(r)=1−∏ℓaℓ。按第一个失败坐标分解：

Rℓ(r) = (∏_{j<ℓ} Cj(r)) × Tℓ(r) × (∏_{j>ℓ} Jj)。

这些集合除边界外两两不交，union恰为D(r)，相对 Bᵢ 体积是

vℓ(r) = (∏_{j<ℓ}aj(r))(1−aℓ(r))。

望远镜求和给 Σℓvℓ=p(r)。若 p(r)>0，则

Unif(D(r)) = Σ_{ℓ:vℓ>0} ωℓ(r) Unif(Rℓ(r))，
ωℓ(r)=vℓ(r)/p(r)，  Σℓωℓ=1。

这里每个非空 Rℓ 实际上是一个矩形 interval product，而不是还需两个尾部的并：r≥cᵢ=(a+1)(sᵢ/a)>sᵢ/a=wᵢ/2，若 Jℓ 的左右两段 outside 都有正长度，则被排除区间的长2r必须严格小于|Jℓ|=wᵢ，矛盾。因此 Tℓ 至多一个正长度区间（包括整个 Jℓ 的情形）。不需要再引入±标签；通用“两尾再拆”公式虽也正确，但本题每坐标最多一侧非零。

固定 first-failing tag ℓ 后，各坐标独立：j<ℓ 时 uniform Cj，j=ℓ 时 uniform Tℓ，j>ℓ 时 uniform Jj。空组件/零体积组件权重为0且略去。p=0 时整个对应 count class 已有概率0，不定义 ωℓ。

所以局部条件数据可合法按以下顺序采样：先以第2节显式概率抽0/1/≥2类；0类抽原 Unif(Bᵢ)，1/≥2类分别按r=cᵢ/2cᵢ的 ωℓ抽tag并抽该矩形product center；尾类独立抽原截断Poisson计数；再按具体count抽uniform times。所有这些局部块跨 labels 独立。若同时固定全体 class/tag/count，则全体中心也成为product of rectangular laws。

混合前通常不具坐标独立。例如 n=2、每个inside coordinate fraction均1/2时，D排除一个角矩形；给定D后“两个坐标都inside”概率为0，而两个inside边际都可正，故不可能是其乘积。

## 6. MAIN_VOID_MIXTURE 定点审核与适用限制

已读主代理 `MAIN_VOID_MIXTURE.md`，其Zᵢ、三类、时间保留、首失败权重与本独立推导一致。其“outside coordinate 是单区间”依赖本题 r>halfwidth 的特殊几何，上节已给严格验证。固定tag后product、混合前不product的界线准确。

在固定count/history、固定其余中心，并将所有中心限制在各自的允许cell内时，void exclusion自动保持；原 clips 和 keys 不变，raw full-key coverage 随某个有效坐标朝x移动具有相应单调性。若x在整个该坐标中心区间内部，则cᵢ>wᵢ使该parent约束通常已经恒成立；否则朝x的方向在整个区间固定。这只支持cell内部的合法单调比较，不支付cell边界比较。

每个混合的权重总和是1，故合法平均不凭空乘n；但也不能因此删除某个原推导中真实存在的Σℓ方向求和。条件law/混合weights依赖receiver x、来源尺度和class。原P_box用near/far pinned centers比较，其两个位置可能属于不同的允许cell，乃至一个位置不满足void。固定cell内部的product/influence论证不能自动等同于原endpoint pressure，跨cell/条件归一化/边界差必须另证。

不使用下列无根据替换：

- 不把Nᵢ=1的center当作Unif(Bᵢ)，或把Nᵢ≥2的倾斜当作与单次相同。
- 不在混合前假设单个center的坐标独立；不按同一小cell对所有x使用固定权重。
- 不把跨label独立升级为selected-key iid或target completion独立。
- 不将真实不交Fᵢ的owner容量赋予辅助条件中心；qᵢdᵢ=|Fᵢ|只是原预算身份。
- 不将合法条件law、cell内部单调性或归一化权重当作全局AU/新一般source付款。

## 7. 本机实际轻量精确核对

为核对新倾斜系数而实际使用已有Python数学环境的SymPy，未运行扫描。以L=λ、A=α、B=β，记 H=1+LA+(e^L−1−L)B，程序核对

`1/H + LA/H + (e^L−1−L)B/H = 1`，

`G(1)=1`，

`G'(1)=L[A+B(e^L−1)]/H`。

实际输出归一化和G(1)均为1；条件均值输出与上式代数相同。另以三个符号坐标检查首失败望远镜残差为0；该有限符号实现不是全n证明，全n证明来自逐项 `(∏pre a)−(∏through a)` 的望远镜求和。没有产生新AU预算，也没有对历史计数扫描重跑。

## 8. 交付范围

正确条件law、三类完整倾斜、中心/计数/时间联合结构、零分支处理、first-failing-coordinate显式product mixture及其关键适用限制均已独立审清，并已把公式发送A2 collective-pressure作者。新增仅uniform-jitter中心条件结构与合法表示，不把标准旧void计数倾斜包装成新一般预算。本任务授权范围内没有剩余缺口；原P_box/weighted influence全局支付不在本次审核结论内。交付后停止。

## 9. 追加授权：先独立审核 common-entry ratio statement

父代理随后明确授权本代理审核A2的新log-key/entry-ratio命题；授权范围为精确statement和utility，不尝试支付完整全局目标。以下先独立推导，再读A2正文。**entry-ratio命题PASS；仍无新AU source预算。**

这里必须回到未施加void条件的原辅助Unif(Bᵢ) product law；第1–6节的void后中心混合不能被偷换成坐标uniform。先固定整个Poisson history，因此globally single sources、实际完成keys和次序均固定。auxiliary centers仍是独立uniform-B，所有Fubini条件都合法。

固定x与除uᵢ,ℓ外的其他中心坐标，按朝x的方向将该坐标写成pᵢ,ℓ∈[0,1]（far为0、near为1）。cᵢ>wᵢ使轴向约束在这个方向是非减的；若x位于中心区间内部，该parent约束事实上已恒成立。令Aᵢ,ℓ(v)=[f(near)−f(far)]₊，这是与当前pᵢ,ℓ无关的binary函数。若A=1，则其他mask的M=1、不含i的key覆盖C=0，且near处未被i-parent遮住。该parent的遮挡沿far→near非减，所以整个fiber都未被它遮住。因此实际S-indicator恰为含i raw keys的一个成功suffix。

令αᵢ,ℓ(v)为raw含i eligible maximum-radius约束在该fiber上的成功比例，空eligible时α=0。在A=1时，除endpoint零集外0<α<1、S=1{p≥1−α}，故精确有

E_p[1_S A/α]=A。

在A=0或空fiber处把该带权表达定义为0。使用R666局部正部在其余积分之前取出的定义，得到

P_box=E∫dx∫₀¹1_S(v)Σ_{i:Nᵢ=1,ℓ} Aᵢ,ℓ(v) rᵢ,ℓ(v)/(wᵢαᵢ,ℓ(v)) dv。

这是逐fiber精确重写，没有给selected key假设iid，也没有修改source rate。若某实际成功配置中Aᵢ,ℓ=1，则C=0使全部当前覆盖key含i；任何当前覆盖key的i轴区间都被maximum eligible半径的区间包含，因此该maximum key也真实覆盖当前配置。故rᵢ,ℓ等于当前所有覆盖keys的最大R*。此共半径观察正确，但ratio上界本身可逐项证明，不需把不同targets独立化。

## 10. 持久entry key、α跳跃与精确ratio

对固定完整配置和x∈S(1)，每个保留key的entry threshold可显式写为

Vₕ=max_{j∈Jₕ,ℓ} (|xℓ−uⱼ,ℓ|−cⱼ)₊/Rₕ，

若x不在其原clip则Vₕ=∞。全体有限，mask固定于v，所以v₀=minₕVₕ由实际完整key取得；按原target次序破同分定义J₀。这是可测选择。该同一个key在全部v≥v₀持续覆盖x。于是其后只要Aᵢ,ℓ(v)=1，必有i∈J₀，否则这个持续key就会给C=1，与正endpoint gap矛盾。J₀全部labels全局Nᵢ=1且互异。

固定其他fiber参数，eligibility随v增加，r(v)是非负有限非减step函数。α(v)因而非减、分段affine，跳跃均非负。在open continuity intervals上且0<α<1时，

(d/dv)logα(v)=r(v)/(wα(v))。

当A=1时上述条件成立；A=0时带A的integrand为0，故不大于logα的非负连续增长密度。不能把跳跃遗漏成等式，但为取得上界，丢去这些非负跳跃只会使连续积分≤总log增长，方向正确。

对i∈J₀，在entry时当前实际pᵢ,ℓ已经满足该key的轴向约束，其余坐标也已经eligible。故αᵢ,ℓ(v₀+)≥1−pᵢ,ℓ。原uniform坐标几乎必然严格位于端点内部，故分母正。对有限sources可一次排除其中心在Bi边界的全局零集，无须对所有receiver作不可数零集并集。

因此每个J₀坐标有

∫₀¹1_S(v) Aᵢ,ℓ(v)rᵢ,ℓ(v)/(wᵢαᵢ,ℓ(v))dv
≤ log[αᵢ,ℓ(1)/αᵢ,ℓ(v₀+)]
≤ −log(1−pᵢ,ℓ)。

v₀处的正跳跃未被积分，使用右极限恰当；v₀=1时左侧为0且ratio定义为1。p=1为原product law下的零集；p=0时entry成功使整条fiber成功，αentry=1且后续增长为0。entry之后α保持正，log积分不存在未经处理的α=0奇点。各被积量均非负，Tonelli可先重写/交换积分；有限几何包络和端点trace约定覆盖零集。

由此精确获得

P_box ≤ L_entry
:=E∫_{S(1)}Σ_{i∈J₀,ℓ} log[αᵢ,ℓ(1)/αᵢ,ℓ(v₀+)]dx
≤E∫_{S(1)}Σ_{i∈J₀,ℓ}−log(1−pᵢ,ℓ)dx。

原inverse jitter width确实经v积分变为entry log ratio，而非被称作维数独立或免费。右端仍依赖实际selected key与receiver Lebesgue积分，未获得U预算。

## 11. 固定key quantile与熵包络的utility审核

对固定、未选择的actual retained key h和固定history，其独立source-coordinate约束给entry CDF Hₕ(v)=∏Fᵢ,ℓ,h(v)。任意CDF都有H(V) stochastically dominating Unif[0,1]（用generalized inverse可见H(H⁻¹(U))≥U），包括atoms。因此Zₕ=−logHₕ(Vₕ)有P(Zₕ>t)≤e^(−t)，固定key均值≤1。该结论不能原封不动用于由当前centers选择出的h₀。

在实际entry配置中，αᵢ,ℓ(v₀+)≥Fᵢ,ℓ,h₀(v₀)，且α(1)≤1，所以L_entry≤E∫_{S(1)}−logHₕ₀(Vₕ₀)dx。对选中事件概率pₕ，不需key独立即可用layer cake得到E[1_selected h Zₕ]≤pₕ(1−logpₕ)。该包络合法，但并未支付任何selection cost。

令p=Σpₕ=P_centers(x∈S(1))、πₕ=pₕ/p，则

Σₕpₕ(1−logpₕ)=p[1−logp+H(π)]≥p。

零概率项按0处理。因此整个history/Lebesgue积分后的熵包络≥E|S(1)|，而已有P_box≤E|S(1)|。**该最终粗包络比已有上界更松，不是新全局预算进展，不得作为换名后的主估计目标。**真正仍待支付的是P_box或保留分子、实际entry分母的L_entry；任何统一AU/严格收缩/可求和递推尚未证明。

## 12. A2正文及单key诊断定点比对

独立完成第9–11节后，实际读取作者 `A2_COLLECTIVE_PRESSURE.md`，SHA-256：

`38814608b66418046637ccdeb31632c41a8852189c27f222b8eb236ad604f582`。

作者(1.4)、共max-radius、entry key持久性、(3.1)–(3.2)的actual entry ratio、(3.4)固定key CDF比较、(4.4)选择layer cake以及(4.6)包络非改进处分均与本独立审核一致。未发现必须修正的主公式。作者明确使用原box law、local positive part、globally single retained labels和真实shared key history，未混用第1–6节void后的非product边际law。

作者单key诊断在指定固定receiver的代数计算正确：给定所有key labels全局single，独立uᵢ∼Unif[−h,h]，x=c+2h，parent void对所有中心确定成立；单source entry在[h/c,3h/c]，最大entry的连续CDF H满足H(V)∼Unif，因此actual entry ratio期望恰为1，success概率1，parent correction0。其coincident owners无法满足真实high-T near合同，作者已明确排除此误读。

这个诊断直接排除的只是“固定receiver、仅依product/void/common-key结构”的subunit局部断言。单个receiver计算本身不反驳Lebesgue积分后的完整全局contraction；要作后者断言还需相应空间模型/积分论证。本代理已向主代理指出这一区别，建议作者将诊断首句/结论限定为fixed-receiver structural diagnostic。主报告未把它写成实际输入反例或全局否定。

作者报告的四个Fraction identities及108浮点log-integral检查仅是有限诊断，本代理没有重跑，也不以它们认证entry theorem或AU。通用证明是第9–11节的解析论证。

## 13. 主报告整合定点审核及实读哈希

`MAIN_VOID_MIXTURE.md` 实读SHA-256：

`e4a4fef0608b9efc5b963248c288efe065a3f967ceadc7c6a65846f7a1c75f74`。

主 `REPORT.tex` 本次实读SHA-256：

`84eebdf076f2240dc81be5933df6cc6a61c0b522f56cf7b765c63434cd3c7ded`。

定点审核其式(2)–(6)及继承费用，结论PASS：

- (2)与(3)是原Unif(Bᵢ) law下的inverse-α精确重写；非void后law。空/saturated fiber带权贡献按0处理，局部正部没有改成全局正部。
- (4)保留真实α(1)/α(v₀+)比值、一个持久完整J₀、α非负跳跃方向和p端点零集；没有把coarse coordinate logs当新主预算。
- (5)明确熵包络≥success probability，最终积分≥E|S(1)|≥P_box，因此不是量化改进；固定key unit fee未冒充selected-key unit fee。
- (6)的完整0/1/≥2倾斜、center laws、count-conditioned times、零分支与首失败product-mixture均正确；未声明key iid。
- R666全部费用沿用准确：E|S(1)|=P_box+C_box、C_box≤16U/31；complete union coefficient<11，所以(1)只有(11+16/31)U+P_box。无第二次Δ或parent correction费用。
- 条件恢复仍为(1+e^(1/16))[16384(23+32/31+2A)+2e^(33/32)]√n，前提是P_box≤AU对全部实际输入/维数统一成立。原-parent packing与finite recovery均未被primed packing替换。
- 主报告明确一般sqrt(n)与旧n^(1/2+o(1))目标未证，无新AU付款，失败的独立geometric allocation及有限诊断均未被作为counterexample。

本实读稿末尾尚写“Final audit bindings ... to be recorded before committing”；主代理已预告只将收尾改为finalrecord已绑定。数学正文无需修复；若文件发生该收尾更新，应另记录最终新哈希，不能把本节实读哈希冒充修改后版本。至此授权命题和整合审核已完成，不延伸完整全局目标。

## 14. 最终最小范围修订与最终哈希绑定

按父代理最终通知，实际读取A2的fixed-receiver诊断修订以及REPORT更新的复现/收尾段，未再延伸数学或重跑检查。A2标题、首段和结论现明确该诊断只涉及pointwise-in-receiver subunit断言，不测试或否定Lebesgue-integrated global contraction，且保留非actual-high-T输入限制。该范围修订准确，解决第12节指出的唯一解释风险；全部主公式保持先前PASS。

最终实际读取 A2_COLLECTIVE_PRESSURE.md SHA-256：

`8393d28c825ae464b9b3689ddd89403e00810b0b5b1d6eb14e677daec1685e4e`。

最终实际读取 REPORT.tex SHA-256：

`ac85d8585b872defc0e748d84b26afcc48fdf10c0ed9377b60083dd4f23ba97f`。

REPORT最后复现段现在记录主代理按prescribed Python 3.12.14独立replay四个Fraction identities与108有限log-integral checks，并保留REPRO_CHECK.py/REPRO_RESULT.json；文本正确限定有限诊断不认证实际high-load输入或AU。该收尾不改变式(2)–(6)、entry-ratio或R666费用，最终整合仍PASS。

至此正确void-law、product-mixture、common-entry inverse-α机制、ratio上界、粗熵包络非改进处分及最终作者/主报告范围均已完成授权独审。无剩余必改点；P_box及actual L_entry的全局U预算仍OPEN。已把law发送A2，仅写本S1文件，无Git/PDF/MATLAB。交付停止。
