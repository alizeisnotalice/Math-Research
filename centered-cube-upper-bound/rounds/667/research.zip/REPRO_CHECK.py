from fractions import Fraction
from math import log
print('Monotone endpoint example (not an actual near-family input):')
for D in [2,4,16,64]:
    eps=Fraction(1,D)
    prob=(1-eps)**D
    influence=D*(1-eps)**(D-1)
    assert influence/prob == Fraction(D*D,D-1)
    print('D=%d success=%.12g total_influence=%.12g influence/success=%s' % (D,float(prob),float(influence),influence/prob))
knots=[0,.25,.6,1]
profiles=[(1,1,1),(.25,1,2),(.5,.5,4)]
checks=0
failures=0
max_ratio=0.
for rr in profiles:
    for w in [.25,1,2]:
        for d in [-.25,.2,.8]:
            for p in [.1,.25,.5,.9]:
                integral=0.
                for j,r in enumerate(rr):
                    left=max(knots[j],(d+w*(1-p))/r)
                    right=min(knots[j+1],(d+w)/r)
                    if right>left:
                        integral += log((right*r-d)/(left*r-d))
                bound=-log(1-p)
                failures += integral>bound+1e-12
                max_ratio=max(max_ratio,integral/bound)
                checks+=1
print('Monotone-radius log-integral checks=%d failures=%d max_ratio=%.15g' % (checks,failures,max_ratio))

assert checks == 108 and failures == 0
