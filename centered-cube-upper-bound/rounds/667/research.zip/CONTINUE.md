# R667 checkpoint: preserve actual entry ratios, no new AU payment

Original pure C_n<=K sqrt(n), arbitrary L1/all scales/fixed Lebesgue, remains OPEN. R666 b715aba702828290eb86a53dede0b2cdfc483340 was actually pushed and ls-remote confirmed. R667 has no new general dimensional improvement.

Already paid: E|S1|=P_box+C_box with C_box<=16U/31; (1-e^-tau/4)Vnear<=(11+16/31)U+P_box. No second Delta fee. Unproved P_box<=AU would imply root bound with coefficient Cadm[16384(23+32/31+2A)+Kfar].

New legitimate collective constraint: under original independent uniform-B auxiliary centers, conditional positive endpoint fibers have success fraction alpha and inverse factor1/alpha. At realized success all positive pivotal source coordinates lie in one persistent first-success full key J0. Integrating the actual v derivative of log alpha yields P_box<=E integral_S1 sum_{i in J0,ell} log(alpha_iell(1)/alpha_iell(v0+)). Nonnegative jumps are dropped in the upper-bound direction. Keep this RATIO and actual first-entry selection, masks and Lebesgue receiver measure; no independent selected-key law.

No absolute budget or strict contraction for this ratio was proved. The crude selected-key entropy envelope sum p_h(1-logp_h) is >=p=Pr(S1), hence after integration >=E|S1|>=P_box. It is strictly a dominated diagnostic, not an improved global bound. Do not reopen this route by renaming the entropy as the remaining objective or dropping the numerator in the ratio. Fixed-key quantile mean<=1 cannot be transferred to an adaptively chosen first key.

The exact all-source void law is product across source blocks, not across coordinates within each positive-count center. Count classes0/1/>=2 have distinct center exclusions. First-failure coordinate mixtures are genuine rectangular product components with total weight1, but original pressure pins cross components; no automatic direction-count saving or disjoint-owner capacity follows.

Geometric allocation attempt: normal transport only lands inside source parent on D=1; D=0 transverse escape remains. Radial contraction keeps a dimension-dependent Jacobian and cell/source overlap fees. No actual-input counterexample to the root theorem was found; these are method checkpoints only.

Verification: author four exact Fraction monotone-product checks and108 finite floating log-integral cases; parent independently replayed in prescribed Python3.12.14 with same output. They are not actual high-T near families and do not prove ratio budget. Parent SymPy1.14.0 exactly integrated truncated quantile logarithm. No MATLAB or PDF run this round. All code/results and precise scope retained; do not repeat unless formula changes.

Next round user configuration: at most1Astra and3Sol total. Existing two Astra R667 tasks finish and stop; only one may be reactivated next round. Main agent and local tools retain unrestricted useful computation, no dummy load. MATLAB closes after saved results. Need target a genuine improvement to original P_box or a strict contraction with summable costs, using actual admission and full-key joint geometry; not more conditional identities.
