#!/usr/bin/env python3
"""R774 volume and weak shared-price collision certificates."""

from collections import defaultdict
from fractions import Fraction as F
from itertools import product
import json
from math import comb, factorial
import sys

from flint import __version__ as flint_version, arb, ctx

from verify import density_integral, make_model, meet, size, summation


def geometric_volumes():
    small = []
    for q,u in product(map(F,("1/2","2/3","7/8")),map(F,("0","1/7","2/5"))):
        # In one orthant, integrate coordinate 0..q at fixed budget u,
        # then integrate the remaining budget from u to zero outside q.
        coeffs = [F(1)]
        for n in (1,2,3):
            integral = [F(0)] + [a/(k+1) for k,a in enumerate(coeffs)]
            for k,a in enumerate(coeffs):
                integral[k] += q*a
            coeffs = integral
            by_sections = sum(a*u**k for k,a in enumerate(coeffs))
            by_formula = sum(F(comb(n,k),factorial(k))*q**(n-k)*u**k for k in range(n+1))
            assert by_sections==by_formula
            small.append({"n":n,"q":q,"u":u,"volume_divided_by_2^n":by_sections})

    ctx.prec = 256
    c = arb(1)/256
    ln2 = arb(2).log()
    worst_normalized_log_ratio = -arb(1)/2 + arb(3).sqrt()/4
    assert worst_normalized_log_ratio<0
    large = []
    for exponent in (27,40,80,256):
        n = 2**exponent
        L = arb(n).sqrt()*arb(n+2).log()**3
        limit = (n+1)*ln2
        assert L < n*ln2
        j_max = ((limit/L).log()/ln2).floor().unique_fmpz()
        assert j_max is not None
        j_max = int(j_max)
        assert 2**j_max*L < limit < 2**(j_max+1)*L
        endpoints = []
        for j in sorted({0,j_max}):
            G = 2**j*L
            q0 = (-G/n).exp()
            u = 4*c*G**2/n
            excess = 2*(n*u/q0).sqrt()
            margin = arb(1)/2 - excess/G
            log_ratio = -G/2 + excess
            assert q0>arb(1)/3 and margin>0 and log_ratio<0
            # The normalized log ratio increases with G because q0 decreases.
            endpoints.append({"j":j,"G":G.str(23),"q0":q0.str(23),
                              "u":u.str(23),"margin_per_G":margin.str(23),
                              "log_of_upper_bound_over_exp_minus_G_over_2":log_ratio.str(23)})
        large.append({"n":n,"n_as_power_of_two":exponent,"L":L.str(23),
                      "L_over_n_log_2":(L/(n*ln2)).str(23),
                      "j_max":j_max,"tested_endpoints":endpoints})
    return {"volume_law":"volume(q B_inf + u B_1)/2^n", "small_exact_section_checks":small,
            "large_precision_bits":ctx.prec,"c":"1/256",
            "worst_normalized_log_ratio_when_q0_at_least_one_third":worst_normalized_log_ratio.str(23),
            "large_scope":"only the analytic majorant exp(-G + 2 sqrt(n u / q0)); g in [G,2G), g <= (n+1) log(2); middle dyadic walls follow by monotonicity",
            "large_certified_majorants":large}


def weak_joint():
    (m,centers,octaves,A,E,v,histories,labels,I,C,keys,overlap,K,
     volume,degree,down,p,breaks,prices,Y,int_H,Q_direct,common_rows,deleted) = make_model()
    j = [summation(I[e] for e in keys if labels[e]==i) for i in range(len(A))]
    W = summation(v)
    assert all(0<z<=w for z,w in zip(j,v))

    roots = defaultdict(set)
    hard = set()
    for e,e2 in product(keys,repeat=2):
        i,i2 = labels[e],labels[e2]
        if K[e,e2]>0:
            hard.add((i,i2))
        if octaves[i]!=octaves[i2]:
            continue
        for f in keys:
            if volume(f)<min(volume(e),volume(e2)) and K[e,f]>0 and K[e2,f]>0:
                roots[i,i2].add(labels[f])
    pairs = sorted(roots)
    intersection = {pair:meet(A[pair[0]],A[pair[1]]) for pair in pairs}
    U = {pair:summation(v[k]*density_integral(meet(A[k],intersection[pair]))/m[k]
                        for k in roots[pair]) for pair in pairs}
    root_volumes = {pair:summation(v[k] for k in roots[pair]) for pair in pairs}
    assert all(0<U[pair]<=root_volumes[pair]<=W for pair in pairs)

    price_rows = []
    for a,b in prices:
        x = (a+b)/2
        mu_x = density_integral((a,b))
        for octave in sorted(set(octaves)):
            H_e = {e:I[e]/volume(e) for e in keys if octaves[labels[e]]==octave and C[e][0]<x<C[e][1]}
            H = summation(H_e.values())
            density = defaultdict(F)
            for f,H_f in H_e.items():
                eta = defaultdict(F)
                for e,w in H_e.items():
                    if volume(e)>volume(f) and K[e,f]>0:
                        eta[labels[e]] += p[e]*w
                for (i,a_i),(i2,a_i2) in product(eta.items(),repeat=2):
                    assert labels[f] in roots[i,i2]
                    density[i,i2] += mu_x*a_i*a_i2*H_f/H
            if density:
                price_rows.append((H,density))

    breaks_A = sorted({a for box in A for a in box})
    energy_cells = F(0)
    for a,b in zip(breaks_A,breaks_A[1:]):
        x = (a+b)/2
        load = summation(j[i]/m[i] for i,box in enumerate(A) if box[0]<x<box[1])
        energy_cells += (b-a)*load**2
    energy_pairs = sum(j[i]*j[i2]*size(meet(A[i],A[i2]))/(m[i]*m[i2])
                       for i,i2 in product(range(len(A)),repeat=2))
    assert energy_cells==energy_pairs

    out = []
    for ell in map(F,("5/32","11/64","3/16")):
        low,high = defaultdict(F),defaultdict(F)
        for H,density in price_rows:
            split = high if H>ell else low
            for pair,w in density.items():
                split[pair] += w
        assert sum(low.values())>0 and sum(high.values())>0
        for i,i2 in pairs:
            assert high[i,i2]<=j[i]*j[i2]*U[i,i2]/(ell*m[i]*m[i2])
        for restrict in (False,True):
            relevant = [pair for pair in pairs if not restrict or pair in hard]
            accepted = [pair for pair in relevant if U[pair]<=ell**2*size(intersection[pair])]
            mass_in = summation(high[pair] for pair in accepted)
            mass_out = summation(high[pair] for pair in relevant if pair not in accepted)
            pair_envelope = summation(j[i]*j[i2]*U[i,i2]/(ell*m[i]*m[i2])
                                      for i,i2 in accepted)
            accepted_energy = summation(j[i]*j[i2]*size(intersection[i,i2])/(m[i]*m[i2])
                                        for i,i2 in accepted)
            assert 0<mass_in<=pair_envelope<=ell*accepted_energy<=ell*energy_cells
            assert mass_out>0
            upper_ratio = max(high[i,i2]*ell*m[i]*m[i2]/(j[i]*j[i2]*U[i,i2])
                              for i,i2 in relevant)
            assert upper_ratio<=1
            out.append({"ell":ell,"outer_middle_pair": "hard only" if restrict else "all same-octave ordered pairs",
                        "pairs_with_common_true_root":len(relevant),
                        "pairs_passing_U_gate":len(accepted),
                        "mass_H_at_most_ell":summation(low[pair] for pair in relevant),
                        "mass_H_above_ell":mass_in+mass_out,
                        "accepted_high_H_mass":mass_in,"rejected_high_H_mass":mass_out,
                        "max_pair_ratio_to_bound":upper_ratio,"accepted_pairwise_envelope":pair_envelope,
                        "accepted_restricted_energy_bound":ell*accepted_energy,
                        "accepted_global_energy_bound":ell*energy_cells})
    physical_overlap_equals_lebesgue = all(density_integral(meet(a,b))==size(meet(a,b)) for a,b in product(A,repeat=2))
    marked_contrast = next((i,i2,r,density_integral(r),size(r)) for (i,i2),r in overlap.items()
                           if K[i,i2]>0 and density_integral(r)!=size(r))
    return {"X":"all prices", "M":"same-octave pair collision at the same x, summed over true shared lower roots",
            "U":"aggregate each eligible physical lower parent once, use whole parent triple intersection with true mu",
            "W_total_owner_volume":W,"Lebesgue_energy":energy_cells,
            "physical_parent_pair_mass_equals_lebesgue_in_this_periodic_model":physical_overlap_equals_lebesgue,
            "contrasting_true_mark_pair_intersection_as_i_i2_interval_mu_dx":marked_contrast,
            "scope":"same finite true one-dimensional hard graph as verify.py; no upstream extreme gates",
            "partitions":out}


if __name__ == "__main__":
    print(json.dumps({"python":sys.version.split()[0],"flint":flint_version,"command":"python -B geometry.py",
                      "sections_and_majorants":geometric_volumes(),"weak_joint":weak_joint()},
                     sort_keys=True,indent=2,default=str))
