#!/usr/bin/env python3
"""True two-peak collision, conditional redraw, and hard clique checks for R774."""

from collections import defaultdict
from fractions import Fraction as F
from itertools import combinations, product
from math import factorial
import json
import sys

from verify import density_integral, make_model, meet, size, summation


def certify():
    (d_parent,centers,octaves,A,E,v,histories,labels,I,C,keys,overlap,K,
     volume,degree,down,p,breaks,prices,Y,int_H,Q_direct,common_rows,deleted) = make_model()

    def down_edge(e,f):
        return volume(e)>volume(f) and K[e,f]>0

    def bin_number(e, octave, J):
        # A geometric halving of the volume octave, tested without a square root.
        return int(J == 2 and volume(e)**2 >= 2*octave**2)

    def marked_candidates(e,g):
        return density_integral(overlap[e,g])*I[g]/(volume(e)*volume(g)*degree[e])

    arms = {e: [(g,marked_candidates(e,g)) for g in keys if down_edge(e,g)] for e in keys}
    assert all(summation(w for _,w in arms[e]) == p[e] for e in keys)
    threshold = F(1,8)
    witness = None
    reports = []

    for J in (1,2):
        totals = defaultdict(F)
        clique_root = defaultdict(F)
        clique_collision = defaultdict(F)
        per_group = defaultdict(F)
        checked = 0
        marginal_checks = 0
        for cell in prices:
            x = sum(cell)/2
            mu_x = density_integral(cell)
            for octave in sorted(set(octaves)):
                H_e = {e:I[e]/volume(e) for e in keys
                       if octaves[labels[e]]==octave and C[e][0]<x<C[e][1]}
                H = summation(H_e.values())
                for f,H_f in H_e.items():
                    lam = mu_x*H_f
                    totals["Z"] += lam*H
                    for b in range(J):
                        mids = [e for e in H_e if down_edge(e,f) and bin_number(e,octave,J)==b]
                        eta = {e:p[e]*H_e[e] for e in mids}
                        T = summation(eta.values())
                        if not T:
                            continue
                        checked += 1
                        per_group[f"{octave}:{b}"] += lam*T
                        delta = T/H
                        assert 0<delta<=1
                        level = "low" if delta<=threshold else "high"
                        totals[level+"_root"] += lam*T
                        totals[level+"_collision"] += lam*T*delta

                        # Path-first: both true right arms, with their real price masses and original d.
                        path = {(e,g):H_e[e]*w for e in mids for g,w in arms[e]}
                        first,second,hard_first = defaultdict(F),defaultdict(F),defaultdict(F)
                        bad = hard = repeated = F(0)
                        for (a,wa),(c,wc) in product(path.items(),repeat=2):
                            word = wa*wc
                            raw_redraw = word/T
                            first[a] += raw_redraw
                            second[c] += raw_redraw
                            if K[a[0],c[0]]>0:
                                hard += word/H
                                hard_first[a] += raw_redraw
                            else:
                                bad += word/H
                                if labels[a[0]]==labels[c[0]]:
                                    repeated += word/H
                        assert first == second == path
                        marginal_checks += len(path)
                        # A clique filter can change the original label marginal.
                        if any(hard_first[a]!=path[a] for a in path):
                            totals["peak_mass_with_changed_hard_marginal"] += lam*T

                        # Group-first: sum the private arms, then use the pricewise T_b.
                        hard_pairs = sum(eta[e]*eta[u] for e,u in product(mids,repeat=2) if K[e,u]>0)
                        assert summation(path.values()) == T
                        assert hard==hard_pairs/H and bad+hard==T*delta
                        totals["Q"] += lam*T
                        totals["m"] += lam*T*delta
                        totals["m_bad"] += lam*bad
                        totals["m_bad_repeated_parent"] += lam*repeated
                        totals["m_bad_removed_parent_pair"] += lam*(bad-repeated)
                        totals["m_hard"] += lam*hard

                        # Unordered cliques multiplied by (k+1)! agree with ordered iid draws.
                        for k in (1,2,4):
                            ne = k+1
                            mass = F(0)
                            for group in combinations(mids,ne):
                                if any(K[e,u]<=0 for e,u in combinations(group,2)):
                                    continue
                                term = F(1)
                                for e in group:
                                    term *= eta[e]
                                mass += term
                            probability = factorial(ne)*mass/T**ne
                            assert 0<=probability<=1
                            if k==1:
                                assert probability==hard_pairs/T**2
                            clique_root[k] += lam*T*probability
                            clique_collision[k] += lam*T*delta*probability

                        if witness is None:
                            for e,u in combinations(mids,2):
                                if K[e,u]<=0:
                                    continue
                                for (g,_),(h,_) in product(arms[e],arms[u]):
                                    if len({labels[f],labels[e],labels[u],labels[g],labels[h]})!=5:
                                        continue
                                    for z,w in product(prices,repeat=2):
                                        if z==w or z==cell or w==cell:
                                            continue
                                        muz = density_integral(meet(z,overlap[e,g]))
                                        muw = density_integral(meet(w,overlap[u,h]))
                                        if not muz or not muw:
                                            continue
                                        Z = meet(z,overlap[e,g])
                                        W = meet(w,overlap[u,h])
                                        assert size(meet(cell,Z))==size(meet(cell,W))==size(meet(Z,W))==0
                                        step_e = I[g]*muz/(volume(e)*volume(g)*degree[e])
                                        step_u = I[h]*muw/(volume(u)*volume(h)*degree[u])
                                        candidate = lam*H_e[e]*H_e[u]*step_e*step_u/H
                                        # Original marked path g -> e -> u -> h, with exactly one common x.
                                        path_mass = I[g]*I[e]*K[g,e] * I[u]*K[e,u]/degree[e]
                                        path_mass *= I[h]*K[u,h]/degree[u]
                                        marked = path_mass*muz/density_integral(overlap[g,e])
                                        marked *= mu_x/density_integral(overlap[e,u])
                                        marked *= muw/density_integral(overlap[u,h])
                                        assert 0<candidate==marked*H_f/H<=marked
                                        shared_anchor = summation(H_e[j] for j in H_e
                                                                  if down_edge(e,j) and down_edge(u,j))/H
                                        assert 0<H_f/H<=shared_anchor<=1
                                        witness = {"J":J,"bin":b,"absolute_octave_left":octave,
                                                   "history_f_e_u_g_h":[f,e,u,g,h],
                                                   "parent_volumes_f_e_u_g_h":[volume(j) for j in (f,e,u,g,h)],
                                                   "x_z_w_price_cells":[cell,Z,W],
                                                   "x_z_w_exact_prices":[sum(i)/2 for i in (cell,Z,W)],
                                                   "physical_receiving_owners_g_h":[E[labels[g]],E[labels[h]]],
                                                   "candidate_triangle_mass":candidate,
                                                   "original_three_jump_marked_mass":marked,
                                                   "ratio":H_f/H,
                                                   "sum_of_all_eligible_shared_anchor_ratios":shared_anchor}
                                        break
                                    if witness is not None:
                                        break
                                if witness is not None:
                                    break

        assert totals["Q"]==Q_direct
        assert totals["Z"]>0 and totals["m"]>=totals["Q"]**2/(J*totals["Z"])
        assert 0<totals["m_bad"]<totals["m"] and 0<totals["m_hard"]<totals["m"]
        assert 0<totals["low_root"]<totals["Q"]
        assert totals["low_root"]+totals["high_root"]==totals["Q"]
        assert totals["low_collision"]+totals["high_collision"]==totals["m"]
        assert clique_collision[1]==totals["m_hard"]
        assert Q_direct>=clique_root[1]>=clique_root[2]>=clique_root[4]>=0
        assert summation(per_group.values())==Q_direct
        assert 0<totals["m_bad_removed_parent_pair"]<totals["m_bad"]
        reports.append({"J":J,"totals":totals,"Cauchy_lower_bound":totals["Q"]**2/(J*totals["Z"]),
                        "collision_to_bad_ratio":totals["m"]/totals["m_bad"],
                        "conditional_iid_clique_success_mass_by_k":clique_root,
                        "collision_weighted_clique_success_mass_by_k":clique_collision,
                        "conditional_iid_clique_success_probability_by_k":
                            {k:w/Q_direct for k,w in clique_root.items()},
                        "root_peak_mass_by_octave_and_group":per_group,
                        "positive_fixed_price_root_groups":checked,
                        "path_marginal_entries_checked":marginal_checks})
    assert witness is not None
    assert reports[0]["totals"]["Z"]==reports[1]["totals"]["Z"]
    return {"precision":"exact Fraction","python":sys.version.split()[0],
            "command":"python -B triangles.py",
            "model":"verify.make_model; only true same-octave hard graph and strict descent; no upstream high-dimensional masks",
            "root_measure":"lambda = H_f(x) times true mu, summed over f and octaves; Z = integral H d(lambda)",
            "collision":"m weighted by T_b^2/H; bad means K(e,u)=0, including repeated physical parents",
            "redraw":"marginals are those of true root peaks under T_b; collision tilted by delta=T_b/H",
            "delta_low_threshold_inclusive":threshold,"reports":reports,
            "hard_triangle_with_true_three_jump_comparison":witness}


if __name__ == "__main__":
    print(json.dumps(certify(), sort_keys=True, indent=2, default=str))
