#!/usr/bin/env python3
"""Exact finite certificate for a pricewise cumulative source-rank translation."""

import argparse
from collections import defaultdict
from fractions import Fraction as F
from itertools import combinations
import json
from pathlib import Path
import platform
import sys


def size(interval):
    return max(F(0), interval[1] - interval[0])


def meet(*intervals):
    return max(i[0] for i in intervals), min(i[1] for i in intervals)


def summation(items):
    return sum(items, F(0))


def density_integral(interval):
    """Density 1/2 then 3/2 in each period 1/4, supported on [-12,12]."""
    lo, hi = meet(interval, (F(-12), F(12)))
    if lo >= hi:
        return F(0)

    def primitive(x):
        q = x // F(1, 4)
        rem = x - F(q, 4)
        return F(q, 4) + rem/2 + max(F(0), rem - F(1, 8))

    return primitive(hi) - primitive(lo)


def make_model():
    d_parent = tuple(F(i, 2) for i in range(8, 16)) + tuple(map(F, (8, 9, 10, 11)))
    centers = tuple(F(i, 4) for i in range(-7, 8, 2)) + tuple(F(i, 4) for i in (-13,-11,11,13))
    octaves = (4,) * 8 + (8,) * 4
    A = tuple((y-d/2, y+d/2) for y,d in zip(centers,d_parent))
    E = tuple((y-d/64, y+d/64) for y,d in zip(centers,d_parent))
    v = tuple(map(size, E))
    assert all(m == density_integral(a) for m,a in zip(d_parent,A))
    assert all(not size(meet(E[i],E[j])) for i,j in combinations(range(len(A)),2))
    assert all(D <= m < 2*D for D,m in zip(octaves,d_parent))

    shares = [F(i) for i in ("1","3/4","7/8","2/3","1","5/6","3/4","1",
                              "7/8","2/3","1","3/4")]
    histories = []
    for i,(lo,hi) in enumerate(A):
        C = lo+F(1+i%4,8), hi-F(1+(2*i)%3,8)
        I = v[i]*shares[i]
        if i in (3,9):
            histories.extend([(i, 2*I/3, C),
                              (i, I/3, meet(C,(F(-5,8),F(11,16))))])
        else:
            histories.append((i,I,C))
    labels,I,C = map(tuple,zip(*histories))
    keys = range(len(I))
    assert all(size(c)>0 and c==meet(c,A[i]) for i,_,c in histories)
    assert all(v[i]>=summation(I[e] for e in keys if labels[e]==i) for i in range(len(A)))
    deleted = {(0,2),(0,5),(4,6),(8,9)}
    assert all(density_integral(meet(A[i],A[j]))>0 for i,j in deleted)

    def hard(e,f):
        i,j = labels[e],labels[f]
        return i!=j and octaves[i]==octaves[j] and tuple(sorted((i,j))) not in deleted

    overlap = {(e,f):meet(C[e],C[f]) for e in keys for f in keys}
    K = {(e,f):density_integral(overlap[e,f])/(d_parent[labels[e]]*d_parent[labels[f]])
         if hard(e,f) else F(0) for e in keys for f in keys}
    assert all(K[e,f]==K[f,e] for e,f in K)

    def volume(e):
        return d_parent[labels[e]]

    degree = tuple(summation(I[f]*K[e,f] for f in keys) for e in keys)
    down = tuple(summation(I[f]*K[e,f] for f in keys if volume(f)<volume(e)) for e in keys)
    assert all(degree)
    p = tuple(a/b for a,b in zip(down,degree))
    assert all(0<=a<=1 for a in p)

    breaks = sorted(set(x for c in C for x in c) | {F(-1,8),F(1,4)})
    prices = [(a,b) for a,b in zip(breaks,breaks[1:]) if density_integral((a,b))>0]
    Y = summation(I)
    unweighted_price_integral = summation(I[e]*density_integral(C[e])/volume(e)
                                          for e in keys)
    true_peak_total = summation(I[e]*down[e]*p[e] for e in keys)
    active_twice = sum(1 for a,b in prices if {
        octaves[labels[e]] for e in keys if C[e][0]<(a+b)/2<C[e][1]
    } == {4,8})
    assert active_twice
    return (d_parent,centers,octaves,A,E,v,histories,labels,I,C,keys,overlap,K,
            volume,degree,down,p,breaks,prices,Y,unweighted_price_integral,
            true_peak_total,active_twice,deleted)


def verify():
    (d_parent,centers,octaves,A,E,v,histories,labels,I,C,keys,overlap,K,
     volume,degree,down,p,breaks,prices,Y,unweighted_price_integral,
     true_peak_total,active_twice,deleted) = make_model()
    log_window_ratio = F(17,16)

    def weights_at(x, octave):
        return {e:I[e]/volume(e) for e in keys
                if octaves[labels[e]]==octave and C[e][0]<=x<=C[e][1]}

    def make_bands(H, weighted):
        """Tie by physical parent, then use uniform rank and independent history mark."""
        groups = defaultdict(dict)
        for e,w in H.items():
            groups[labels[e]][e] = w*(p[e] if weighted else 1)
        start = F(0)
        bands, end = {}, {}
        for i in sorted(groups,key=lambda i:(d_parent[i],i)):
            mass = summation(groups[i].values())
            if mass:
                marks = {e:w/mass for e,w in groups[i].items() if w}
                assert sum(marks.values())==1
                bands[i] = ((start,start+mass),marks)
            start += mass
            end[i] = start
        return bands,end

    def window(weigh_p,octave):
        total = F(0)
        for x in breaks+[(a+b)/2 for a,b in prices]:
            H = weights_at(x,octave)
            for m in {volume(e) for e in H}:
                val = summation(w*(p[e] if weigh_p else 1) for e,w in H.items()
                                if m<=volume(e)<=log_window_ratio*m)
                total = max(total,val)
        return total

    def original_hard(e,f):
        return K[e,f]>0 and volume(e)>volume(f)

    def pipe(H, weighted, delta):
        bands, end = make_bands(H,weighted)
        direct = defaultdict(F)
        near = F(0)
        for f,wf in H.items():
            cutoff = end[labels[f]]
            far_floor = cutoff+2*delta
            for region,mix in bands.values():
                for e,qe in mix.items():
                    if not original_hard(e,f):
                        continue
                    assert region[0]>=cutoff
                    coeff = wf*qe*(1 if weighted else p[e])
                    near += coeff*size((region[0],min(region[1],far_floor)))
                    for target,target_mix in bands.values():
                        pullback = (target[0]+delta,target[1]+delta)
                        moved = size(meet(region,pullback,(far_floor,region[1])))
                        if not moved:
                            continue
                        for v_mark,qv in target_mix.items():
                            direct[e,f,v_mark] += coeff*moved*qv

        # Independent sweep at the output coordinate, with flat conditional mark densities.
        inverse = defaultdict(F)
        cap_ratio = F(0)
        plain_over_weighted = F(0)
        over_witness = None
        over_mass = F(0)
        for f,wf in H.items():
            floor = end[labels[f]]+delta
            for target,target_mix in bands.values():
                left = max(floor,target[0])
                right = target[1]
                if left>=right:
                    continue
                cuts = {left,right}
                cuts.update(t-delta for source,_ in bands.values() for t in source
                            if left<t-delta<right)
                cuts = sorted(cuts)
                for a,b in zip(cuts,cuts[1:]):
                    look = (a+b)/2+delta
                    source_mix = next((mix for (l,r),mix in bands.values() if l<look<r),{})
                    coeffs = {e:qe*(1 if weighted else p[e]) for e,qe in source_mix.items()
                              if original_hard(e,f)}
                    ratio = summation(coeffs.values())
                    assert 0<=ratio<=1
                    cap_ratio = max(cap_ratio,ratio)
                    for v_mark,qv in target_mix.items():
                        base = (b-a)*wf*qv
                        for e,coeff in coeffs.items():
                            inverse[e,f,v_mark] += base*coeff
                        if not weighted and ratio and original_hard(v_mark,f):
                            assert p[v_mark]>0
                            excess_ratio = ratio/p[v_mark]
                            if excess_ratio>1:
                                over_mass += base*ratio
                            if excess_ratio>plain_over_weighted:
                                plain_over_weighted = excess_ratio
                                over_witness = {"f":f,"v":v_mark,"old_e":sorted(coeffs),
                                                "output_rank_interval":[a,b],
                                                "H_output_density_to_weighted_cap": excess_ratio}
        assert direct==inverse
        base_by_pair = defaultdict(F)
        for (e,f,v_mark),value in direct.items():
            base_by_pair[f,v_mark] += value
        for (f,v_mark),value in base_by_pair.items():
            base_mass = H[f]*H[v_mark]*(p[v_mark] if weighted else 1)
            assert 0 < value <= base_mass
        assert near<=2*delta*summation(H.values())
        return direct,near,cap_ratio,plain_over_weighted,over_witness,over_mass

    # Independent true geometric probe to check the reattached price and receiver laws.
    owner_probe = tuple((a,a+(1+i%3)*size((a,b))/4) for i,(a,b) in enumerate(E))
    owner_prob = tuple(size(meet(e,z))/size(e) for e,z in zip(E,owner_probe))
    price_probe = F(-1,8),F(1,4)

    def rebuild(hard_output,weighted):
        direct = F(0)
        atomized = F(0)
        exact_probe = F(0)
        check_probe = F(0)
        by_before,by_after = defaultdict(F),defaultdict(F)
        for (v_mark,f),w in hard_output.items():
            if not w:
                continue
            normalizer = down[v_mark] if weighted else degree[v_mark]
            assert normalizer>0 and original_hard(v_mark,f)
            by_before[v_mark] += w
            direct += w*down[v_mark]/normalizer
            for g in keys:
                if not original_hard(v_mark,g):
                    continue
                K_vg = K[v_mark,g]
                price_span = overlap[v_mark,g]
                mv,mg = volume(v_mark),volume(g)
                if weighted:
                    assert p[v_mark]*I[g]*K_vg/normalizer == I[g]*K_vg/degree[v_mark]
                arm_weight = I[g]*K_vg/normalizer
                step = w*arm_weight
                atomized += step
                geom = owner_prob[labels[f]]*owner_prob[labels[g]]
                exact_probe += step*geom*density_integral(meet(price_span,price_probe))/density_integral(price_span)
                for true_cell in prices:
                    mid = sum(true_cell)/2
                    if price_span[0]<mid<price_span[1] and price_probe[0]<mid<price_probe[1]:
                        check_probe += w*I[g]*geom*density_integral(true_cell)/(normalizer*mv*mg)
                by_after[v_mark] += step
        assert direct==atomized
        assert exact_probe==check_probe
        before = summation(by_before.values())
        if before:
            assert 0<exact_probe<direct<=before
        if weighted:
            assert before==direct and by_before==by_after
        tv = summation(abs(w/before-by_after[v_mark]/direct)
                       for v_mark,w in by_before.items())/2 if before else F(0)
        return direct,exact_probe,tv,by_before,by_after

    out = []
    octave_values = sorted(set(octaves))
    windows = {weighted:{octave:window(weighted,octave) for octave in octave_values}
               for weighted in (True,False)}
    for weighted,delta in [(True,F(1,64)),(True,F(1,30)),(False,F(1,64)),(False,F(1,30))]:
        near = F(0)
        direct = defaultdict(F)
        per_octave = {o:defaultdict(F) for o in octave_values}
        local_cap = F(0)
        max_excess = F(0)
        over_witness = None
        over_mass = F(0)
        both_active_count = 0
        int_H = F(0)
        for cell in prices:
            x = sum(cell)/2
            cell_mu = density_integral(cell)
            for octave in octave_values:
                H = weights_at(x,octave)
                int_H += cell_mu*summation(H.values())
                if not H:
                    continue
                moved,local_near,cap,excess,witness,local_over = pipe(H,weighted,delta)
                local_cap = max(local_cap,cap)
                if excess>max_excess:
                    max_excess = excess
                    over_witness = dict(witness,price_cell=cell,octave=octave)
                over_mass += local_over*cell_mu
                both_active_count += bool(moved)
                near += local_near*cell_mu
                per_octave[octave]["near"] += local_near*cell_mu
                for k,val in moved.items():
                    direct[k] += val*cell_mu
        assert int_H==unweighted_price_integral<=Y
        assert 0<near<=2*delta*int_H<=2*delta*Y
        output = summation(direct.values())
        assert 0<output and near+output==true_peak_total

        hard_output = defaultdict(F)
        gap_output = F(0)
        for (e,f,v_mark),w in direct.items():
            octave = octaves[labels[e]]
            assert octave==octaves[labels[f]]==octaves[labels[v_mark]]
            per_octave[octave]["moved"] += w
            double_gap = volume(e)>log_window_ratio*volume(v_mark) and volume(v_mark)>log_window_ratio*volume(f)
            if delta>windows[weighted][octave]:
                assert double_gap
            if double_gap:
                gap_output += w
                per_octave[octave]["double_gap"] += w
            if original_hard(v_mark,f):
                hard_output[v_mark,f] += w
                per_octave[octave]["new_hard"] += w
        hard_mass = summation(hard_output.values())
        assert 0<hard_mass<output
        post,probe,tv,by_before,by_after = rebuild(hard_output,weighted)
        if not weighted:
            assert max_excess>1 and over_mass>0 and 0<post<hard_mass and tv>0
        out.append({"rank":"p(e) H(e)" if weighted else "H(e)",
                    "delta":delta,"near_mass":near,"near_bound_using_actual_price":2*delta*int_H,
                    "near_bound_using_Y":2*delta*Y,"moved_mass":output,
                    "new_hard_mass":hard_mass,"new_nonhard_mass":output-hard_mass,
                    "strict_double_gap_mass":gap_output,"reconstructed_peak_mass":post,
                    "true_price_and_owner_probe_mass":probe,"target_reweighting_TV":tv,
                    "conditional_new_arm":"d_-" if weighted else "d",
                    "far_rule":"r_e > cumulative rank mass through the original f parent + 2*delta",
                    "occupied_output_price_octave_cells":both_active_count,
                    "max_output_density_to_rank_measure":local_cap,
                    "ordinary_rank_output_over_weighted_cap":{"max_ratio":max_excess,
                                                               "witness":over_witness,"mass":over_mass},
                    "by_octave":per_octave,
                    "reattachment_max_min_factor":[min(by_after[v]/w for v,w in by_before.items()),
                                                   max(by_after[v]/w for v,w in by_before.items())]})
    assert out[1]["delta"]>max(windows[True].values())
    assert out[1]["strict_double_gap_mass"]==out[1]["moved_mass"]
    assert out[0]["delta"]<max(windows[True].values())
    return {"dimension":1,"a":32,"log_window_span":"log(17/16)",
            "scope":"same-octave hard graph of actual price intersections, excluding same parents and four stated parent pairs; no original halo, entropy or long-path screens",
            "octave_lower_end":octaves,"parents":A,"centers":centers,"owners":E,"owner_probes":owner_probe,
            "physical_parent_m_equals_d":d_parent,"histories_as_parent_I_C":histories,
            "hard_graph_deleted_parent_pairs":sorted(deleted),"original_d":degree,
            "strictly_down_d":down,"strictly_down_probability":p,
            "price_density":"on [-12,12], period 1/4, value 1/2 then 3/2 in the two halves",
            "price_probe":price_probe,"price_cells_active_in_both_octaves":active_twice,
            "Y_U":Y,"actual_integrated_price_mass":unweighted_price_integral,
            "old_peak_mass":true_peak_total,
            "same_price_window_suprema":{"weighted":windows[True],"ordinary":windows[False]},
            "algorithms":"direct pullback of translated rank intersections and inverse target-coordinate sweep; compare every (old e,f,new v) mass on each actual price cell",
            "transport":out}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--output",type=Path)
    mode.add_argument("--check",type=Path)
    args = parser.parse_args()
    result = verify()
    result["runtime"] = {"python":sys.version.split()[0],"interpreter":sys.executable,
                         "machine":platform.machine(),"arithmetic":"Python Fraction",
                         "commands":["python -B verify.py --output verify.json",
                                     "python -B verify.py --check verify.json"]}
    data = json.dumps(result,default=str,indent=2,sort_keys=True)+"\n"
    if args.output:
        args.output.write_text(data)
    else:
        assert args.check.read_text()==data, "saved certificate differs from fresh calculation"
    print(f"R774 verified {len(result['transport'])} translates across 2 absolute octaves")
    for row in result["transport"]:
        relative = row["moved_mass"]/result["old_peak_mass"]
        print(f"{row['rank']} delta={row['delta']} moved/peak={float(relative):.6f}; "
              f"retained after reattachment={float(row['reconstructed_peak_mass']/row['new_hard_mass']):.6f}")


if __name__ == "__main__":
    main()
