from fractions import Fraction as F
from math import factorial
import json

def phi(r): return (1+r/3)**-3
def bfun(r): return phi(r)+F(3,2)*(1+r/3)**-2
def btail(r): return F(3,2)*(1+r/3)**-2+F(9,2)*(1+r/3)**-1

def eneg(x):
    # Exact outward rational enclosure, x in [0,16].
    if not x:return F(1),F(1)
    N=96
    t=F(1); s=t
    for k in range(1,N+1):
        t=t*x/k;s+=t
    nxt=t*x/(N+1)
    rem=nxt/(1-x/F(N+2))
    return 1/(s+rem),1/s
counts={}
for label,ells in [('initial',[3,4,5]),('pressure',[8,16,32]),('expanded',[64,100,1000])]:
    c=0
    for ell in ells:
        # Full infinite-j price bounded by exact integral tail, not a fit.
        for N in [1,7,31,100]:
            partial=sum((bfun(F(j*ell)) for j in range(N+1)),F(0))
            upper=partial+btail(F(N*ell))/ell
            assert upper<=F(5,2)+F(6,ell)
            c+=1
        for r in [F(0),F(1,10),F(1),F(ell),F(3*ell),F(ell*ell)]:
            # e^r >= its cubic Taylor polynomial >= (1+r/3)^3.
            t3=1+r+r*r/2+r*r*r/6
            assert phi(r)>=1/t3
            c+=1
        # Exact interval checks for deep, unequal, and multi-node records.
        for xs in [[F(0)],[F(1,4),F(5,4)],[F(2),F(4),F(7)],
                   [F(8),F(9),F(12)],[F(16)], [F(1,10),F(11,10),F(21,10)]]:
            rs=[ell*x for x in xs]
            U=sum(map(phi,rs),F(0))
            intervals=[eneg(x-1) if x>=1 else (1/eneg(1-x)[1],1/eneg(1-x)[0]) for x in xs]
            lo=sum((v[0] for v in intervals),F(0))
            hi=sum((v[1] for v in intervals),F(0))
            # Representative within the certified interval; this only tests
            # positive-split bookkeeping, not native path/history realization.
            V=(lo+hi)/2
            a=min(F(1),U);bb=min(F(1),V)
            residual=(1-a)*(1-bb)
            assert a+(1-a)*bb+residual==1
            assert 0<=residual<=1-a
            if residual>0: assert all(x>1 for x in xs)
            # Generic full ledger substitution: R423 = Pa + Pb + R.
            mass=F(13,7); X=F(19,5); W=F(23,11)
            pa=mass*a;pb=mass*(1-a)*bb;R=mass*residual
            C=F(3,97);base=F(5,3);hat=F(100,93);lam=F(128,119)
            omega=pa/W;delta=pb/X
            old=64*lam*hat*(mass+C*X+base*W)
            new=64*lam*hat*(R+(C+delta)*X+(base+omega)*W)
            assert old==new
            c+=1
    counts[label]=c
# Soft union produces exact support restrictions U<1,e*sum(exp(-r/ell))<1;
# it need not remove any fixed fraction uniformly as all r tend to infinity.
print('PASS exact rational checks',json.dumps(counts,sort_keys=True))
print('Infinite path-level sum certified by analytic monotone integral tail; exponential intervals use Taylor remainder.')
print('Finite label bookkeeping only; no native original history, full-parameter absorption, or general closure certificate.')
