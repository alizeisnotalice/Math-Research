# R425：全部保源路径节点的可求和对数质量窗预算

2026-10-20。本文只在 R424 的同一实际测度上改变付款权，不改变接收场、路径核、来源、阶段或历史。得到一个严格加强的根阶 \(W\) 正分量预算；一般未加权余项仍未闭合。正式总账用本轮价格替换 R424 的质量软付款价格，两者不相加。

## 1. 准确合同与候选

沿用 R424：完整 \(f\ge0\)，\(W=\int f<\infty\)，真实 Lebesgue 接收中心 \(A\in E\)，轴平行立方体边长 \(R_A\in[a,b]\)，\(b\le2a\)，
\[
 m_A=f(Q_A)=q_AR_A^n,\quad q_-\le q_A\le\lambda,\quad
 \mu(dA)=dA/m_A,\quad \sigma(dA)=q_A\,dA,\quad
 \pi_A(dx)=f(x)c_A(x)dx/m_A .
\]
记 \(A_n=1+n\log(b/a)\)、\(X_q=\int\sigma\)、
\[
 K=e^{\sqrt n},\quad \ell=\log K=\sqrt n,\quad
 s=1+\sqrt n,\quad h=s/(\varepsilon_0q_-),\quad S=\beta+C_{\rm col}.
\]
应用维数为 \(n\ge9\)。\(\Pi_{423}\) 是 R424 原文的实际正费用测度，含全部原阶段、旧新来源、首次删除、early、时钟、当前占用、空间和双路径 Gram 软权。以下仅在正上界中删除这些限制，不重定义该测度。

两条完整保源路径分别记 \((w_j)_{j\ge0}\)、\((t_j)_{j\ge0}\)，含初始节点与终止节点，停止后不再复制节点。给定原父及双来源，每条第 \(j\) 代位置子概率核满足已有的
\[
 \mathsf P_j^x(dv)\le\frac{\rho_x(dv)}h,\qquad
 \rho_x(dv)=c_v(x)\mu(dv),\qquad
 m_v<m_A/K^{j+1}.                                      \tag{1}
\]
初始核的 exclusive 分母大于 \(h\)；后继核的估计使用真正前代子概率总量不超过一，不把 \(\rho_x/h\) 再迭代积分。未来限制只作正限制，不能条件化后重新归一。

R424 取
\[
 a=K F_{\rm mass}
   =\sum_{\text{两链全部节点 }v}\frac{Km_v}{m_A}.
\]
本轮提出同一节点上的对数质量权
\[
 r_v=\log\frac{m_A}{Km_v}>0,\qquad
 \Phi(r)=(1+r/3)^{-3},\qquad
 F_\Phi=\sum_{\text{两链全部节点 }v}\Phi(r_v).             \tag{2}
\]
它不是先选一个质量带再逐带独立收费。下面对全部对数质量窗、全部代数一次求和，证明
\[
 \boxed{\displaystyle
 \int F_\Phi\,d\Pi_{423}
 \le \Omega_\Phi W,\qquad
 \Omega_\Phi=
 \frac{S\lambda A_n}{h q_-^2}
       \left(5+\frac{12}{\sqrt n}\right).}               \tag{3}
\]
由于 \(3\log(1+r/3)\le r\)，有 \(\Phi(r)\ge e^{-r}\)，且 \(r>0\) 时严格。因此 \(F_\Phi\ge a\)，新支付权确实逐标签支配旧支付权。

## 2. 真实父中心的单调质量窗引理

令 \(\phi:[0,\infty)\to[0,\infty)\) 为有限值可测非增函数，\(\int_0^\infty\phi<\infty\)。固定 \(m>0\)、来源点 \(x\) 与整数 \(j\ge0\)，则
\[
 \boxed{\displaystyle
 \int_{m_A>K^{j+1}m}
 \frac{q_Ac_A(x)}{m_A}
 \phi\!\left(\log\frac{m_A}{Km}\right)dA
 \le\frac{\lambda}{q_-}
 \left[\phi(j\ell)+\int_{j\ell}^{\infty}\phi(r)dr\right].} \tag{4}
\]

证明。置 \(H=K^{j+1}m\) 及
\[
 g(u)=u^{-1}\phi(\log(u/(Km))),\qquad u\ge H .
\]
两因子非负非增，所以 \(g\) 非增。捕获 \(x\) 的实际中心满足
\[
 m_A=q_AR_A^n\ge q_-(2\|A-x\|_\infty)^n .
\]
因此原被积函数受
\(\lambda g(\max\{H,q_-(2\|A-x\|_\infty)^n\})\) 支配；在未捕获或未过严格质量门处，原函数为零。对整个中心空间积分，并用
\(\big|\{A:(2\|A-x\|_\infty)^n\le u\}\big|=u\)，得
\[
 \begin{aligned}
 \text{左端}
 &\le\lambda\int_0^\infty g(\max(H,q_-u))\,du\\
 &=\frac{\lambda}{q_-}
       \left[H g(H)+\int_H^\infty g(v)\,dv\right]\\
 &=\frac{\lambda}{q_-}
       \left[\phi(j\ell)+\int_{j\ell}^\infty\phi(r)\,dr\right].
 \end{aligned}
 \tag{5}
\]
第一个项是中心底部区域的完整费用，不能遗漏。这里积分的是实际中心下界的径向包络，不是把任意选择器边长当独立积分变量。\(m_A=H\) 的整片原子已被原严格门排除；右侧闭包络只扩大上界。允许 \(\phi\) 有跳跃，其端点值按所声明的非增函数取值即可。来源点位于立方体边界也不影响该中心体积计算。

## 3. 同一原费用上的全路径、全质量窗结算

先处理一条链的第 \(j\) 代。R423 的原阶段合同允许在上界中先用 (1)，随后对共同 stage/首次删除求和，用 \(\sum_i b_i(z)\le1\) 和逐来源 \(\beta,C_{\rm col}\)。两种父端合为 \(S\)，而不是额外阶段数。路径统计量依赖冻结的场、父和被保留来源，不通过新历史重选核。得到
\[
 \begin{aligned}
 &\int \phi\!\left(\log\frac{m_A}{Km_{w_j}}\right)d\Pi_{423}\\
 &\quad\le \frac S h
 \int\mu(dv)\!
 \int_{m_A>K^{j+1}m_v}
       \frac{q_AI_{Av}}{m_A}
       \phi\!\left(\log\frac{m_A}{Km_v}\right)dA ,
 \qquad I_{Av}=f(Q_A\cap Q_v).                           \tag{6}
 \end{aligned}
\]
此处分母恰为 \(m_A\)：来自原 \(\pi_A\) 的一次归一化。没有删除 R424 固定测试定理中的 \(1/m_A\)；这是另一个直接作用于原费用的正积分推导。其余旧来源/另一端/路径标签始终保留在左侧，右侧才删除正限制。

将 \(I_{Av}=\int f(x)c_v(x)c_A(x)dx\) 用 Tonelli 展开，在每个 \(v,x\) 上使用 (4)，令
\[
 F_\phi(r)=\phi(r)+\int_r^\infty\phi(t)dt.
\]
则 (6) 不超过
\[
 \frac{S\lambda}{h q_-}F_\phi(j\ell)
 \int\mu(dv)\int f(x)c_v(x)dx
 =\frac{S\lambda}{h q_-}F_\phi(j\ell)\,|E|.              \tag{7}
\]
这里以同一完整 \(f\) 的精确 \(m_v=f(Q_v)\) 取消 \(\mu(dv)\) 的分母；既非来源密度帽，也未将两份 \(W\) 相乘。原生累计量满足
\[
 |E|=\int f(x)J(x)dx\le\frac{A_n}{q_-}W.               \tag{8}
\]
两条链分别使用 (7)，故一般的全质量窗结论为
\[
 \boxed{\displaystyle
 \int\sum_{\text{两链节点 }v}\phi(r_v)d\Pi_{423}
 \le \frac{2S\lambda A_n}{h q_-^2}
       \sum_{j\ge0}F_\phi(j\ell)\,W .}                 \tag{9}
\]
全部求和非负，可以先截断路径代数和阶段再用单调收敛。源零集、空行和不存在的代数贡献均为零。严格质量下降只给 (1) 的代数质量门；本文没有以有限深度本身付款。

若另有 \(\int_0^\infty r\phi(r)dr<\infty\)，由于 \(F_\phi\) 非增，
\[
 \sum_{j\ge0}F_\phi(j\ell)
 \le \phi(0)+\int_0^\infty\phi
   +\ell^{-1}\int_0^\infty(1+r)\phi(r)dr.              \tag{10}
\]
这是一次求和所有窗的价格，不带质量带总数或最大路径长度。

对 \(\Phi=(1+r/3)^{-3}\)，精确有
\[
 \int_r^\infty\Phi=\frac32(1+r/3)^{-2},\quad
 \int_0^\infty\Phi=\frac32,\quad
 \int_0^\infty r\Phi=\frac92 .
\]
所以格点和不超过 \(5/2+6/\ell\)，(9) 即为 (3)。记 \(r_q=\lambda/q_-\)，则
\[
 \Omega_\Phi
 =S r_q\varepsilon_0\frac{A_n}{s}
       (5+12/\sqrt n)
 \le 9 S r_q\varepsilon_0 s,\qquad n\ge9,              \tag{11}
\]
其中 \(A_n\le1+n\le s^2\)。所有常数解析给出，未以数值拟合维数。

## 4. 对 R424 的严格加强、完整补集与唯一计价

在同一个 \(\Pi_{423}\) 上定义
\[
 P_\Phi=\int\min(1,F_\Phi)d\Pi_{423},\qquad
 R_\Phi=\int(1-F_\Phi)_+d\Pi_{423}.
\]
则
\[
 R423=P_\Phi+R_\Phi,\qquad P_\Phi\le\Omega_\Phi W.       \tag{12}
\]
确实可在当前 \(R424=(1-a)_+\Pi_{423}\) 内识别新增正份额：
\[
 \chi_{\rm inc}=
 \begin{cases}
 [\min(1,F_\Phi)-a]/(1-a),&a<1,\\
 0,&a\ge1 .
 \end{cases}
\]
它在 \([0,1]\) 内，且逐标签有
\[
 \min(1,a)+(1-a)_+\chi_{\rm inc}=\min(1,F_\Phi),\qquad
 (1-a)_+(1-\chi_{\rm inc})=(1-F_\Phi)_+.              \tag{13}
\]
因此旧付款和本轮新增部分合起来恰是 (12)，没有重复扣费。本文不声称新增部分单独有价格 \(\Omega_\Phi-\Omega424\)。

正式总账应从同一 \(R423\) 槽替换：
\[
 V_\Phi=V413+\Omega_\Phi,\qquad C423\ \text{不变},
\]
而非 \(V424+\Omega_\Phi\)。于是原反馈不变，
\[
 G_0\le16\widehat F[R_\Phi+C423X_q+V_\Phi W],
\]
\[
 B_H\le32\widehat F R_\Phi+
 (E387+32\widehat F C423)X_q+
 (S390+8s+32\widehat F V_\Phi)W ,
 \tag{14}
\]
\[
 \mathrm{入口}\le\Lambda\{
 8\lambda HW+2d_{\rm eff}A_{{\rm entrance},n}W_\nu/H
 +64\widehat F R_\Phi+(2E387+64\widehat F C423)X_q
 +(2S390+16s+64\widehat F V_\Phi)W\}.
 \tag{15}
\]
这里 \(A_{{\rm entrance},n}\) 是未改的旧入口常数，
\(\widehat F=(1-32\delta-16\eta)^{-1}\)、\(\Lambda=128/119\) 亦未改。相对于 R423 槽，本轮来源价为 \(64\Lambda\widehat F\Omega_\Phi W\)；相对于 R424，只替换其原有 \(\Omega424\) 槽，不另加一次该价格。没有新增 \(X_q\) 费，没有认证其他旧吸收余额。

新补集仍保留全部 R423 标签，另有
\[
 \sum_{\text{两链节点 }v}
  \left(1+\frac13\log\frac{m_A}{Km_v}\right)^{-3}<1
 \quad\text{及精确权 }(1-F_\Phi)_+.                  \tag{16}
\]
它比原总节点质量约束强，但既不保证固定比例消除，也未支付极小节点产生的全部未加权费用。量词上的改进是：在所有父、完整来源、全部代数上，可以给全部对数质量窗一个同一的可求和根阶价格，而非仅以指数质量权定价。一般 \(R_\Phi\le tX_q+C_t sW\) 仍未证明。

## 5. 本机验证范围

配套 `/tmp/r425_geometry_check.py` 使用标准库 Fraction 实际执行三个阶段：

1. 原生连续中心径向模型。\(n=d^2,K=e^d,q_A=1\)，选择真实边长
   \(R_A=\max(R_0,2\|A\|_\infty)\)，中心截于边长 \(R_1\) 的立方体；
   完整 \(f=1\) 于边长 \(2R_1\) 的立方体。故所有实际 cube 匹配
   \(m_A=R_A^n\)，源 \(x=0\) 被捕获。令
   \(\log m_0=d(j+1)+e_0,\ \log(m_1/m_0)=e_1\)，
   则真实中心积分精确等于
   \(\Phi(jd+e_0)+\int_{jd+e_0}^{jd+e_0+e_1}\Phi\)。
   所有这些对数参数是有理数，积分有理精确计算；限制
   \(e_1\le n/2<n\log2\)，故实际边长仍在一个 octave 内。
   这些模型检验原生 parent base+tail，不声称实现原全部历史。
2. 一次求和的精确离散积分证书，检查各区间
   \(F_\Phi(j\ell)\le\ell^{-1}\int_{(j-1)\ell}^{j\ell}F_\Phi\)，
   以及有限前缀价格、两链系数和 (13) 的精确软分拆。
3. 一个完整非均匀有限来源模型的两条实际质量下降链，使用有理对数上下包围严格认证新付款大于旧付款且补集为正。该阶段是有限 incidence/匹配与软分证据，不是 Lebesgue 中心或原生历史实例。

实际运行 `python3 /tmp/r425_geometry_check.py` 已通过，输出为：

```text
PASS stage 1: 24 native continuous-center exact integrals
Full matching and octave hold; this is not a full historical flow model.
PASS stage 2: 80 exact window intervals, 24 replacement splits, 5 two-chain/root constants
PASS stage 3: one exact matched two-chain positive new-payment model
old soft weight = 16/25
certified new soft weight lies strictly in (94/100,95/100): True
Finite incidence and diagnostic K,h only; no native full-history claim.
ALL R425 CHECKS PASS
```

首次执行在一个测试参考数的手录错误处停止：\(\int_0^3F_\Phi\) 误写为 \(69/16\)，应为 \(27/8\)。按脚本中已给出的解析原函数修正该参考数后重跑通过；一般证明与价格未修改。上述计数表示列明的有限配置，不表示独立的一般定理。一般结论由 §§2–4 的证明给出，有限计算不替代它。
