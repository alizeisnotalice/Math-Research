from fractions import Fraction as F
from itertools import product
from pathlib import Path
import json

def native(n,d,rootq,cut):
    assert n%d==0
    a=F(1);b=F(2);q=rootq**d;p=F(1,d)
    assert F(3,4)<=q<=1
    M=q*cut**n
    # Native f=q on Q_4, centers Q_2, R(v)=max(1,2||v||inf), x=0.
    # Entire plateau m=q is excluded at cut<=1, by the strict mass cutoff.
    if cut<=1:
        exact=F(0)
    else:
        upper=min(cut,b)
        exact=rootq**(1-d)*(1+d*(upper**(n//d)-1))
    cap=d*rootq**(1-d)*cut**(n//d)
    assert 0<=exact<=cap
    if cut>1:
        truncated_cap=d*rootq**(1-d)*min(cut,b)**(n//d)
        assert truncated_cap-exact==(d-1)*rootq**(1-d)
    return {'n':n,'p':str(p),'q':str(q),'cut':str(cut),'positive':exact>0,'ratio':str(exact/cap)}

stage1=[native(n,d,r,c) for n,d,r,c in product([12,24],[1,2,3],[F(1),F(15,16)],[F(1,2),F(1),F(5,4),F(3,2),F(2),F(3)])]
stage2=[]
for k,c,eps,S in product([3,6,12],[F(2),F(3)],[F(1,16),F(1,64)],[F(1),F(5,2)]):
    # Exact algebra with K=c^k and p=1/k; c is explicitly a surrogate for e.
    p=F(1,k);s=1+k;K=c**k
    coefficient=2*S*eps/(s*p)*c/(c-1)
    assert coefficient<=2*S*eps*c/(c-1)
    # Same positive fee space, no resampling: two finite chains of node log-depths.
    # exp(-p r_j)=v_j; ratio m_node/m_parent=v_j^k/K.
    vs=[F(1,4),F(1,16),F(1,64)]
    vt=[F(1,5),F(1,25)]
    nodes=vs+vt
    newscore=sum(nodes);oldscore=sum(v**k for v in nodes)
    assert newscore>=oldscore
    chi=min(F(1),newscore);R=F(7,5)
    assert R==chi*R+(1-chi)*R
    # For threshold exp(c0)=2, any node with v>=1/2 is fully paid by min(1,2 sum v).
    extra=[F(1,2)]+nodes
    assert min(F(1),2*sum(extra))==1
    # Fractional moment -> soft receipt, kept as separate algebraic interface.
    paid=min(R,R*newscore)
    assert paid<=R*newscore
    stage2.append({'k':k,'base_c':str(c),'epsilon':str(eps),'S':str(S),'coefficient':str(coefficient),'strict_soft_gain':newscore>oldscore})
stage3=[native(k*k,k,F(1)-F(1,8*k),c) for k,c in product([3,6,12,30,100],[F(1),F(9,8),F(3,2),F(2),F(5,2)])]
summary={'counts':{'native_initial':len(stage1),'soft_parameter':len(stage2),'native_expanded':len(stage3)},'total':len(stage1)+len(stage2)+len(stage3),'positive_native':sum(x['positive'] for x in stage1+stage3),'strict_soft_gains':sum(x['strict_soft_gain'] for x in stage2),'max_dimension':10000}
Path(__file__).with_name('r425_aux_result.json').write_text(json.dumps({'summary':summary,'initial':stage1,'soft':stage2,'expanded':stage3},indent=2)+'\n')
print('PASS',summary)
print('Native radial center integrals at one fixed source, exact strict mass plateau handling; soft algebra uses explicit rational surrogate c for e. No full original history fixture.')
print('r425_aux_result.json')
