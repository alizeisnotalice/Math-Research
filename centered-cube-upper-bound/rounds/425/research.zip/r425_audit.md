# R425 independent final audit

FINAL PASS — for the original-measure logarithmic-window source receipt A, the subsequent fractional-mass X receipt B, their exact soft remainder and full account. General unweighted R425/root weak-type closure, a uniform deleted fraction, complete native-history numerical realization and the old absorption balance are NOT certified. Independent screening preceded author reading. This record supersedes PRE and binds the frozen final files. Only this reviewer audit file was edited during this assignment.

## A. Actual parent-center tail, all-window sum and replacement

Independently derived and then read the complete geometry/main proof. With M=Km_v, D=K^(j+1)m_v and a=jℓ, F(t)=Φ(log(t/M))/t is decreasing for t≥M; for Φ=(1+r/3)^(-3) its logarithmic derivative is −1−3/(3+r). Capture gives m_A≥q_-(2||A−x||∞)^n. Therefore the true center envelope is
∫_{m_A>D}q_Ac_A(x)F(m_A)dA≤(λ/q_-)[Φ(a)+∫_a^∞Φ].
The first term is the complete radial inner BASE. It cannot be discarded as though the strict cutoff eliminated all constant-mass center blocks. Strict atoms may be positively enlarged; no zero-measure mass-level assumption is made. The general finite nonincreasing φ lemma likewise passes; a finite first moment is additionally required for its stated finite all-window bound, as the author explicitly provides.

After the original per-generation ρ_x/h subprobability bound, the father source normalization supplies exactly q_AI_Av/m_A. Full-f Tonelli and the parent tail then give Sλ/(hq_-) times the window factor against |E|=∫fJ≤A_nW/q_-. This is not a deletion of R424's 1/m_A theorem weight: it is a separate direct positive integration. Main's §3 dx scope was corrected to contain the parent integral and now agrees with that proof.

For Φ, tailΦ(a)=(3/2)(1+a/3)^(-2), Φ(0)+tailΦ(0)=5/2 and ∫(Φ+tailΦ)=6. Thus the sum over every j≥0 is at most 5/2+6/ℓ. Both paths give exactly
Ω_A=SλA_n(5+12/ℓ)/(hq_-²)≤9S(λ/q_-)ε_0s.
S already contains endpoint types; there is no added stage, layer, length, τ or endpoint-union factor. Original terminal nodes count once, absent later generations are zero, and all infinite upper sums use nonnegative limits.

Since Φ(r)≥e^(-r), χ_A=min(1,ΣΦ) contains the R424 mass-soft fraction on the SAME Π423. The incremental-fraction identities in geometry (13) are correct, including a≥1 and zero denominators. The formal account rebuilds from Π423 with Ω_A replacing Ω424; it does not add both W prices or assume the incremental price equals their difference. The new remainder is smaller as a positive measure, but this alone does not claim the total numerical RHS decreased.

## B. Fractional native moment and the selected e² receipt

For fixed 0<p≤1, the actual selected-center bound
J_p,<M(x)≤q_-^(p−1)[a^(np)+(U^p−a^(np))/p]≤M^p/(pq_-)
passes, with U=min(b^n,M/q_-). M≤q_-a^n is strictly empty; U=a^n need not be empty when M>q_-a^n (including b=a). The p=1 endpoint is valid. These facts and the plateau are correctly retained. No p=0 estimate or source-density bound is inferred.

The same original probability/stage contract gives, for every positive submeasure Ξ≤Π423,
∫ΞΣ(m_v/m_A)^p≤2S/[h q_-p(K^p−1)]X_q.
One path is integrated and the other contributes probability at most 1; a second h denominator is not introduced. Future restrictions are removed only for an upper bound, not normalized into a new process.

The final main chooses p=1/ℓ and, on A's remainder Π425a, χ_B=min(1,eΣexp(−r_v/ℓ)). Because exp(−r_v/ℓ)=e(m_v/m_A)^p, this is the e² multiplier of the raw power moment. The correct selected price is
Δ_B=2Se²ε_0ℓ/[s(e−1)].
It is not the smaller 2Se version for a different mark. The exact residual is Π423(1−ΣΦ)_+(1−eΣexp(−r/ℓ))_+. On its positive support every term has r>ℓ, hence m_v<m_A/K², including initial and terminal nodes. The original generator still descends by K with its original h/Z; no kernel or history is retrospectively changed. The original R423 joint Gram and all older labels survive positive restriction. Π425≤Π424 is consequently correct.

## Full account, constants and remaining scope

Read main, README, geometry and aux in full. C425=C423+Δ_B and V425=V413+Ω_A, with Fhat unchanged, give exactly the displayed 16/32/64 Fhat G0/BH/entrance slots. From Π423 the source/X additions are 64ΛFhatΩ_AW and 64ΛFhatΔ_BX_q; relative to R424 the W price is replaced. Old entrance, external terms, time atoms and low-dimensional/full-scale qualifications remain once. No new feedback factor or negative-square credit appears. Parameters must be selected consistently at the original initialization if X absorption is desired; making ε_0 small in isolation is not certified to satisfy the complete old budget. The stated root order retains S, λ/q_- and ε_0 dependencies.

A and B are genuine positive ordered marks of the original complete ticket, not new independent posteriors. Neither fixed-fraction elimination nor all-complement payment follows. General R425≤tX_q+C_t sW remains open. The auxiliary's standalone no-W-increment statement applies only to B; the integrated main correctly has A's replacement W invoice plus B's new X invoice.

## Actual independent replay and evidence boundaries

Read all three scripts and ran isolated temporary copies. Every stdout matched the final supplied .result.txt bytes exactly; the regenerated auxiliary JSON was byte-identical. No author output was overwritten. Parent: 144 rational checks (48/48/48), including analytic infinite-tail bounds, exact Taylor exponential enclosures and rational representative-label split/ledger checks. The latter verify bookkeeping/support implications; they do not compute an irrational native-history flow. Aux: 121 records (72 native-initial, 24 explicit rational-base surrogate soft tests, 25 native-expanded), with 68 positive pointwise radial integrals. The native q1_Q4, center Q2, R=max(1,2||v||∞) model has exact matching at x=0 and the strict minimal-mass plateau; it is not an original active-history fixture. Surrogate c=2 or 3 is not silently identified with e.

Geometry: 24 native continuous-parent radial integrals evaluated by exact rational log-parameter formulas; 80 right-sum window intervals; 24 replacement identities; five constants; one finite nonuniform matched-incidence two-chain model. In that finite model the old mark is 16/25, the new mark is rigorously enclosed between 0.94 and 0.95, and both added payment and residual are positive. It uses diagnostic K,h and is not a full native-history certificate. The initially hand-entered reference integral was transparently corrected to 27/8; only the successful final output is bound. General claims are analytic, not inferred from these counts. Reviewer's earlier temporary scalar tests are not added to parent/author totals.

No final ZIP extraction, PDF compilation or Git operation was performed by this auditor. README distinguishes isolated review evidence from archive reproduction. No remaining mathematical revision is required for this bounded scope.

## Final byte bindings (SHA-256)

- `r425_main.md`: `c0c06b0ddb758275c90e0cd4a3202d35d8ff287d8a89596adc2683c01f76b564`
- `r425_readme.md`: `636ad957090dd970ac561c8e0fbd0252f6ae7118873761f83486f30e4311c64d`
- `r425_geometry.md`: `82656a1b1902cce3347b1039de8e760ac0e875963473f093dd4e756f17ca2a78`
- `r425_aux.md`: `9dd6d2a456a751d235b0ce760769d405005dd01f075a23b2c22c67f7727dcf7b`
- `r425_parent_check.py`: `70789054d316ddff57f00086a6212e2819b852aa53b04e9b0ef88b845b952f0b`
- `r425_geometry_check.py`: `19dfdb86d41bd95d7ae36c3e940835149caa3b13ad7561b7ae0cca77d31056a6`
- `r425_aux_check.py`: `d9eb0c5d4f8e8855818e7d02f42f456c68c57db78aeee897b1839b198ba3b1ac`
- `r425_parent.result.txt`: `e29f200ff433bf22bdd705613e06f82d00bdea5fff8e7d9f24f9aaa3bb8694a2`
- `r425_geometry.result.txt`: `0d37895078eac8e39cc9f5db9934ae04bf4f25f98337168c09b05141605bfd0f`
- `r425_aux.result.txt`: `5f438d5b147425cda3f0e4adb9fd58fd95b0aa0d6765d5918d670237abf79891`
- `r425_aux_result.json`: `29a5a46ac4ab7d24f1645ed001112d192b029d5c0387e33b74a3e1b593c44447`
- `r424_main.md`: `64094d03f54e658d43fe05128f3ac6a323c962f1f8a672a46a5f94eb66851093`
- `r423_main.md`: `e52bfc72017e1531968661bf6319760a665c9fa2046c0d306b803786dd8b4caf`
- `r413_main.md`: `ed03c99fbea15e831c6250832a9fc1f48f04d92cba3475fa60266542badf593f`
- `r411_aux.md`: `08877dd6346771a4711a454fbf7704db27d0fd3a05f2dfbab45d69e0ac2c3823`
