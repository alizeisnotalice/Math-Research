"""R425 exact checks. Run with Python 3; no third-party dependencies.

Native checks concern a continuous-center envelope model only.
The last finite matched model does NOT certify native original history.
"""
from fractions import Fraction as Q


def phi(r):
    return (1 + r / 3) ** -3


def tail(r):
    return Q(3, 2) * (1 + r / 3) ** -2


def lattice_f(r):
    return phi(r) + tail(r)


def integral_lattice_f(a, b):
    # Integral of Phi + its tail: primitive tailPhi + (9/2)/(1+r/3).
    return tail(a) - tail(b) + Q(9, 2) * (
        (1 + a / 3) ** -1 - (1 + b / 3) ** -1
    )


# Stage 1: actual continuous native centers, full uniform f, true matching.
# n=d^2, K=exp(d), mchild=1, H=exp(d(j+1)).
# m0=exp(d(j+1)+e0)>H, m1=m0 exp(e1).
# R(A)=max(m0^(1/n),2||A||infty) on Q_{m1^(1/n)}(0).
# f=1 on Q_{2*m1^(1/n)}(0); hence every chosen cube has m=R^n.
# The change u=(2||A||infty)^n has exactly Lebesgue volume du.
native = 0
for d in [3, 4, 8, 16]:
    n = d * d
    for j in [0, 1, 3]:
        for e0 in [Q(1, 4), Q(2)]:
            e1 = Q(n, 3)
            assert 0 < e1 <= Q(n, 2)
            r0, r1 = j * d + e0, j * d + e0 + e1
            actual = phi(r0) + tail(r0) - tail(r1)
            envelope = lattice_f(Q(j * d))
            assert 0 < actual <= envelope
            # Phi'(r)=- (1+r/3)^-4 and Tail'(r)=-Phi(r);
            # antiderivative is analytic, not floating-point quadrature.
            native += 1
print(f"PASS stage 1: {native} native continuous-center exact integrals")
print("Full matching and octave hold; this is not a full historical flow model.")


# Stage 2: exact all-window integral comparison and exact replacement split.
window_cases = 0
for ell in [Q(1, 2), Q(1), Q(3), Q(7), Q(100)]:
    partial = lattice_f(Q(0))
    for j in range(1, 17):
        interval = integral_lattice_f((j - 1) * ell, j * ell)
        assert ell * lattice_f(j * ell) <= interval
        partial += lattice_f(j * ell)
        assert partial <= Q(5, 2) + 6 / ell
        window_cases += 1
assert integral_lattice_f(Q(0), Q(3)) == Q(27, 8)
# Total integral is 6, and F(0)=5/2, by the explicit primitive.
for d in [3, 4, 8, 16, 100]:
    assert 2 * (Q(5, 2) + Q(6, d)) == 5 + Q(12, d)
    assert 5 + Q(12, d) <= 9
split_cases = 0
for a in [Q(0), Q(1, 8), Q(1, 2), Q(7, 8), Q(1), Q(3, 2)]:
    for increment in [Q(0), Q(1, 16), Q(1, 2), Q(2)]:
        b = a + increment
        chi_inc = (min(Q(1), b) - a) / (1 - a) if a < 1 else Q(0)
        rem_old = max(Q(0), 1 - a)
        assert 0 <= chi_inc <= 1
        assert min(Q(1), a) + rem_old * chi_inc == min(Q(1), b)
        assert rem_old * (1 - chi_inc) == max(Q(0), 1 - b)
        split_cases += 1
print(
    f"PASS stage 2: {window_cases} exact window intervals, "
    f"{split_cases} replacement splits, 5 two-chain/root constants"
)


def log_interval(x, terms=160):
    """Exact atanh-series log interval for rational x>=1."""
    assert x >= 1
    v = (x - 1) / (x + 1)
    lower = 2 * sum((v ** (2 * k + 1) / (2 * k + 1)
                     for k in range(terms)), Q(0))
    error = 2 * v ** (2 * terms + 1) / (
        (2 * terms + 1) * (1 - v * v)
    )
    return lower, lower + error


# Stage 3: a single nonuniform full source, actual incidence masses,
# fixed-source exclusive initial laws and their deterministic descendants.
# Diagnostic K=2,h=1/2, finite center weights; not original high-dimensional K.
f = list(map(Q, [1, 2, 3, 1, 2, 3, 13]))
parent = set(range(7))
left, left_terminal = {0, 1}, {0}
right, right_terminal = {3, 4}, {3}
nodes = [left, left_terminal, right, right_terminal]
mass = lambda support: sum((f[x] for x in support), Q(0))
ma = mass(parent)
mv = [mass(v) for v in nodes]
assert ma == 25 and mv == [3, 1, 3, 1]
K, h = Q(2), Q(1, 2)
assert all(ma > K * m for m in mv)
assert mv[0] > K * mv[1] and mv[2] > K * mv[3]
# For each fixed source 0 or 3, rho(triple)=1/4, rho(singleton)=1.
# Initial exclusive normalizer=5/4>h. Event: initial triple, then singleton.
initial_probability = Q(1, 4) / Q(5, 4)
assert initial_probability == Q(1, 5)
assert Q(1) > h
joint_event_probability = initial_probability ** 2
actual_parent_source_weight = f[0] * f[3] / ma ** 2
gamma = joint_event_probability * actual_parent_source_weight
old_weight = K * sum(mv) / ma
new_lower = new_upper = Q(0)
for m in mv:
    lo, hi = log_interval(ma / (K * m))
    new_lower += phi(hi)
    new_upper += phi(lo)
assert 0 < old_weight < new_lower <= new_upper < 1
assert gamma > 0
assert gamma * (new_lower - old_weight) > 0
assert gamma * (1 - new_upper) > 0
print("PASS stage 3: one exact matched two-chain positive new-payment model")
print("old soft weight =", old_weight)
print("certified new soft weight lies strictly in (94/100,95/100):",
      Q(94, 100) < new_lower <= new_upper < Q(95, 100))
assert Q(94, 100) < new_lower <= new_upper < Q(95, 100)
print("Finite incidence and diagnostic K,h only; no native full-history claim.")
print("ALL R425 CHECKS PASS")
