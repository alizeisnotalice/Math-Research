from fractions import Fraction as F
from itertools import combinations
from math import factorial
from pathlib import Path
from decimal import Decimal as D,localcontext
import random,heapq,json

def family(iv,k,b):
 return [tuple(v[2] for v in es) for es in combinations(iv,k) if max(v[0] for v in es)<=b and max(v[0] for v in es)<min(v[1] for v in es)]

def price_sweep(iv,k,b,prices):
 # Cost-only oracle: heap deaths and Fenwick count/sum trees.
 vals=sorted(set(prices));rank={v:i+1 for i,v in enumerate(vals)};sz=len(vals)
 cnt=[0]*(sz+1);sums=[F(0)]*(sz+1)
 def add(v,d):
  i=rank[v]
  while i<=sz:cnt[i]+=d;sums[i]+=d*v;i+=i&-i
 def small(k):
  at=0;have=0;total=F(0);step=1<<(sz.bit_length()-1)
  while step:
   j=at+step
   if j<=sz and have+cnt[j]<k:at=j;have+=cnt[j];total+=sums[j]
   step//=2
  return total+(k-have)*vals[at]
 groups={}
 for s,c,i in iv:
  if s<=b and s<c:groups.setdefault(s,[]).append((c,i))
 heap=[];n=0;best=None
 for s,new in sorted(groups.items()):
  while heap and heap[0][0]<=s:
   c,i=heapq.heappop(heap);add(prices[i],-1);n-=1
  for c,i in new:add(prices[i],1);n+=1;heapq.heappush(heap,(c,i))
  if n>=k:
   cost=small(k)/k
   if best is None or cost<best:best=cost
 return best

def cut_cost(es,k,A):return min(F(sum(i in A for i in e),k) for e in es)
def layer(es,k,p):
 levels=sorted(set([F(0)]+p));out=F(0)
 for lo,hi in zip(levels,levels[1:]):out+=(hi-lo)*cut_cost(es,k,{i for i,v in enumerate(p) if v>lo})
 return out

def random_geometry():
 rng=random.Random(20261008);rows=[]
 for stage,N in enumerate((7,9,12),1):
  for n in (1,2,4,8,16):
   d=N//2+1;points=[tuple(F(rng.randrange(-8,9),8) for _ in range(n)) for _ in range(d)]
   x=tuple(F(rng.randrange(-2,3),8) for _ in range(n));source_prices=[F(rng.randrange(0,17),4) for _ in range(d)]
   p=[source_prices[j%d] for j in range(N)];iv=[]
   for j in range(N):
    entry=max(F(1),2*max(abs(u-v) for u,v in zip(x,points[j%d])));cap=F(rng.randrange(5,33),8)
    if entry<=3 and entry<cap:iv.append((entry,cap,j))
   for k in (2,3,4):
    es=family(iv,k,F(3));oracle=price_sweep(iv,k,F(3),p)
    brute=min((sum(p[i] for i in e)/k for e in es),default=None)
    assert oracle==brute
    L=layer(es,k,p) if es else F(0)
    if es:assert L<=oracle<=k*L
    rows.append(dict(stage=stage,n=n,N=N,sources=d,k=k,witnesses=len(es),price=str(oracle),layer_price=str(L)))
 # Entry at terminal is legitimate, death before entry is not.
 iv=[(F(1),F(2),0),(F(2),F(3),1),(F(2),F(4),2)]
 assert price_sweep(iv,2,F(2),[F(0),F(2),F(4)])==3
 return rows

def allocation_certificates():
 iv=[(F(1),F(2),0),(F(11,10),F(21,10),1),(F(6,5),F(11,5),2),(F(1),F(4),3),(F(3),F(19,5),4)]
 es=family(iv,2,F(4));expected=list(combinations(range(4),2))+[(3,4)]
 assert set(es)==set(expected)
 p=[F(1),F(1),F(1),F(2),F(0)];assert price_sweep(iv,2,F(4),p)==1
 rows=[]
 for c,b in ((F(1,5),F(1,10)),(F(11,50),F(1,10)),(F(9,50),F(4,25)),(F(1,5),F(3,25)),(F(21,100),F(1,10)),(F(19,100),F(7,50)),(F(23,100),F(1,20)),(F(4,25),F(1,5)),(F(1,6),F(1,6))):
  ell=1-3*c-b;mu=[c,c,c,b,ell];assert ell>=b>0
  gaps=[]
  for mask in range(32):
   A={i for i in range(5) if mask>>i&1};g=sum(mu[i] for i in A)-cut_cost(es,2,A);assert g>=0;gaps.append(g)
  B=1/(3*c+2*b);weights={(0,1):c*B,(0,2):c*B,(1,2):c*B,(3,4):2*b*B}
  assert sum(weights.values())==1
  loads=[sum(w/2 for e,w in weights.items() if i in e) for i in range(5)]
  assert all(loads[i]<=B*mu[i] for i in range(5))
  dual=1/sum(mu[i]*p[i] for i in range(5));assert B==dual
  assert sum(mu)==1 and layer(es,2,p)==F(1,2)
  rows.append(dict(capacities=[str(v) for v in mu],all_indicator_tests=32,optimal_B=str(B),primal_edges={str(e):str(w) for e,w in weights.items()},loads=[str(v) for v in loads],dual_price=[str(v) for v in p],dual_value=str(dual)))
 assert rows[0]['optimal_B']=='5/4'
 return rows

def layer_losses():
 rows=[]
 for k in (2,3,4,8,16,32,64):
  iv=[(F(1),F(2),i) for i in range(k)]+[(F(3),F(4),k+i) for i in range(k)]
  p=[F(0)]*(k-1)+[F(k)]+[F(1)]*k
  es=[tuple(range(k)),tuple(range(k,2*k))]
  c=price_sweep(iv,k,F(4),p);L=layer(es,k,p)
  assert c==1 and L==F(1,k) and c/L==k
  rows.append(dict(k=k,complete_price=str(c),layer_price=str(L),ratio=str(c/L)))
 return rows

def delete_guards():
 rows=[]
 for k in (2,3,4):
  iv=[(F(1),F(2+i%3,1),i) for i in range(k+2)]+[(F(4),F(5),k+2+i) for i in range(k)]
  es=family(iv,k,F(5));N=2*k+2
  for mask in range(1<<N):
   A={i for i in range(N) if mask>>i&1};cost=cut_cost(es,k,A)
   loss=F(not any(all(i not in A for i in e) for e in es))
   assert loss/k<=cost<=loss
  rows.append(dict(k=k,N=N,subset_checks=1<<N))
 return rows

def tail_certificates():
 rows=[]
 for q in (F(1,2),F(2),F(8)):
  for gap in (8,16,32):
   M=int(q)+gap;poly=sum((q**j/factorial(j) for j in range(M)),F(0));prev=None;stages=[]
   for order in (64,96,160):
    ehi=sum(((-q)**j/factorial(j) for j in range(order+1)),F(0));elo=ehi-q**(order+1)/factorial(order+1)
    lo=max(F(0),1-ehi*poly);hi=min(F(1),1-elo*poly)
    assert 0<=lo<=hi<=1
    if prev:assert lo>=prev[0] and hi<=prev[1]
    prev=(lo,hi)
    with localcontext() as ctx:
     ctx.prec=70
     dec=lambda z:D(z.numerator)/D(z.denominator)
     stages.append(dict(order=order,tail_lower=format(dec(lo),'.16g'),tail_upper=format(dec(hi),'.16g'),width=format(dec(hi-lo),'.16g')))
   assert lo>0 and (hi-lo)/lo<F(1,10**30)
   # lambda*b^n=1, k=3, mu_min=1/20; illustrative tail coefficient only.
   error=hi*q*F(20,3)
   with localcontext() as ctx:
    ctx.prec=70;err=format(D(error.numerator)/D(error.denominator),'.16g')
   rows.append(dict(Lambda=str(q),cutoff=M,refinements=stages,B_error_upper=err))
 return rows

if __name__=='__main__':
 g=random_geometry();c=allocation_certificates();l=layer_losses();d=delete_guards();t=tail_certificates()
 out=dict(status='PASS; general square-root bound unproved',geometry_oracles=g,primal_dual_certificates=c,sharp_pointwise_layer_losses=l,deletion_checks=d,poisson_tail_intervals=t,notes=['Fractions certify finite geometry, all subset tests, and matching primal-dual certificates. No floating LP solver is used.','Poisson tail intervals use exact rational Taylor remainder signs at three orders.','Seed 20261008 generates finite configurations only; no annealed Poisson demands are estimated.','The local allocation counterexample is not a weak-type lower-bound counterexample.','Tail error depends on Lambda and mu_min and is not a dimension-uniform estimate.'])
 Path(__file__).with_name('results.json').write_text(json.dumps(out,indent=2)+'\n')
 print('PASS',len(g),'price oracles;',len(c),'exact primal-dual certificates;',len(l),'layer gaps;',sum(v['subset_checks'] for v in d),'deletion subset checks;',len(t),'Poisson tails x3')
