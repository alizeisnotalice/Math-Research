from fractions import Fraction as F
from math import isqrt
import json
rows=[]
for n in (4,8,16,32,64,128,256,512,1024):
    a=32*n;t=isqrt(n-1)+1;M=t*a**n
    V=(1-F(4,a))**n
    upper=(1+V/t)/2**n
    assert upper<1/F(t)
    # The largest source owner volume is (2*4**M/a)**n. Prove >=3 by
    # checking only a smaller integer power; avoid materializing 4**M.
    k=a.bit_length()+2
    assert M>=k and (F(2*4**k,a))**n>3
    assert 1-F(1,4**n)>=F(3,4)
    rows.append(dict(n=n,source_count_bits=M.bit_length(),V=float(V),cold_bound=float(upper),one_step_payment_lower='1/8'))
print(json.dumps(rows))
