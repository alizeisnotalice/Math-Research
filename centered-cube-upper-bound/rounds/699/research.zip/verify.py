import json
from pathlib import Path
def load(h,s):return json.loads(Path(h+s+'.json').read_text())
for suff in ('','-sqrt','-cells'):
    rows=[]
    for h in ('mini','laptop'):
        d=load(h,suff)
        assert len({r['pid'] for r in d['rows']})==d['workers']
        print(h,suff,len(d['rows']),sum(r['cpu'] for r in d['rows']),d['elapsed'])
        rows+=d['rows']
    assert len({r['seed'] for r in rows})==len(rows)
    bad=sum(r['bad'] for r in rows);Q=rows[0]['Q'];v=[sum(r['totals'][k] for r in rows)/(Q*Q*bad) for k in range(6)]
    if suff=='-cells':
        strict=[sum(r['strict'][i] for r in rows) for i in range(2)]
        assert all(r['totals'][0]<=r['totals'][1] and r['totals'][3]<=r['totals'][4] for r in rows)
    else:
        strict=sum(r['strict'] for r in rows)
        assert all(r['totals'][0]<=r['totals'][2]<=r['totals'][3] and r['rho_bounds'][0]<=r['rho_bounds'][1] for r in rows)
    print('bad owner count',bad,'fractions',v,'strict',strict)
from fractions import Fraction as F
from zipfile import ZipFile
import sys
zip_path=Path(sys.argv[1]) if len(sys.argv)>1 else Path('/Volumes/data/CodexProjects/T/Math-Research-cube-sqrt-20261114/centered-cube-upper-bound/rounds/698/research.zip')
v=[];w=[]
with ZipFile(zip_path) as z:
    for h in ('mini','laptop'):
        opt={r['seed']:F(r['ratio']) for r in json.loads(z.read(h+'.json'))['rows']}
        d=load(h,'-tree')
        assert len(d['rows'])==len(opt)
        print('tree',h,len(opt),sum(r['cpu'] for r in d['rows']),d['elapsed'])
        for r in d['rows']:
            root=F(r['root']);best=min(F(r[k]) for k in ('core','median','uniform'));o=opt[r['seed']]
            assert o<=best<=root
            v.append((o,best,root));w.append(best/o)
print('tree exact',sum(o==c for o,c,r in v),'improved',sum(c<r for o,c,r in v),'worst cost',float(max(c for o,c,r in v)),'worst versus optimal',float(max(w)))
