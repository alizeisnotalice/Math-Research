from collections import deque
import sys, os, time, socket, json, random
from multiprocessing import get_context
from fractions import Fraction

def case(seed):
    start=time.process_time()
    rng=random.Random(seed)
    n=72+seed%41
    # Units 1/32; equal parents radius 32, disjoint owners radius 1.
    y=[0]
    for _ in range(n-1):
        y.append(y[-1]+rng.choices([2,3,4],[19,2,1])[0])
    ends=sorted({v+d for v in y for d in (-32,32)})
    cells=list(zip(ends,ends[1:]))
    rows=[[h for h,(lo,hi) in enumerate(cells) if lo>=v-32 and hi<=v+32] for v in y]
    inc=list(map(set,rows))
    denom=32**n
    q=denom//2
    load=[0]*len(cells)
    order=list(range(n))
    rng.shuffle(order)
    active=order[:]
    sel=[]
    theta={}
    pools={}
    z={}
    while active:
        i=max(active,key=lambda j:denom-max(load[k] for k in rows[j]))
        w=(denom-max(load[k] for k in rows[i]))//32
        theta[i]=w
        active.remove(i)
        sel.append(i)
        for k in rows[i]:load[k]+=w
        for j in active:
            if j in pools:continue
            h=max(rows[j],key=load.__getitem__)
            if load[h]>=q:
                pools[j]=[k for k in sel if h in inc[k]]
                z[j]=sum(cells[h])

    # Coordinates doubled, to keep actual witness midpoints integral.
    target=list(pools)
    span=max(max(z.values()),2*y[-1])-min(min(z.values()),0)+1
    startpos=min(min(z.values()),0)
    root=(span-1).bit_length()
    from math import gcd
    mult={}
    for j in target:
        for i in pools[j]:mult.setdefault(i,[]).append(z[j])
    # Normalize supply and demand by the true physical ratio denom/32.
    def bound(method):
        positions={}
        for i,vals in mult.items():
            vals=sorted(vals)
            if method=='core':positions[i]=[2*y[i]]
            elif method=='median':positions[i]=[vals[(len(vals)-1)//2]]
            else:positions[i]=vals
        scale=1
        for arr in positions.values():scale=scale*len(arr)//gcd(scale,len(arr))
        costs=[]
        for shift in (0,span//3,2*span//3):
            # One hierarchy per shift; evaluate full-family guarantee first.
            best={j:0 for j in target};root_ratio=None
            for k in range(root+2):
                cell=lambda x:(x-startpos+shift)>>k
                count={}
                for x in z.values():count[cell(x)]=count.get(cell(x),0)+1
                mass={}
                for i,arr in positions.items():
                    val=theta[i]*(scale//len(arr));pieces={}
                    for x in arr:pieces[cell(x)]=pieces.get(cell(x),0)+val
                    mass[i]=pieces
                for j,P in pools.items():
                    c=cell(z[j])
                    ratio=Fraction(sum(mass[i].get(c,0) for i in P),count[c])
                    best[j]=max(best[j],ratio)
                if k==root+1:
                    assert len(count)==1
                    root_ratio=min(Fraction(sum(theta[i] for i in P)*scale,len(target)) for P in pools.values())
            costs.append(Fraction(denom*scale,32)/min(best.values()))
        return min(costs),Fraction(denom*scale,32)/root_ratio
    c,rootcost=bound('core');m,_=bound('median');u,_=bound('uniform')
    assert max(c,m,u)<=rootcost
    return dict(seed=seed,root=str(rootcost),core=str(c),median=str(m),uniform=str(u),cpu=time.process_time()-start,pid=os.getpid())
if __name__=='__main__':
    lo,hi,workers=map(int,sys.argv[1:]);start=time.monotonic()
    with get_context('fork').Pool(workers) as p:rr=p.map(case,range(lo,hi),1)
    print(json.dumps(dict(host=socket.gethostname(),python=sys.version,workers=workers,elapsed=time.monotonic()-start,rows=rr)))
