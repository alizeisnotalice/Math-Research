from collections import deque
from math import isqrt
import sys, os, time, socket, json, random
from multiprocessing import get_context
from fractions import Fraction

def case(seed):
    start=time.process_time()
    rng=random.Random(seed)
    n=72+seed%41
    # Units 1/32; equal parents radius 32, disjoint owners radius 1.
    y=[0]
    for _ in range(n-1):
        y.append(y[-1]+rng.choices([2,3,4],[19,2,1])[0])
    ends=sorted({v+d for v in y for d in (-32,32)})
    cells=list(zip(ends,ends[1:]))
    rows=[[h for h,(lo,hi) in enumerate(cells) if lo>=v-32 and hi<=v+32] for v in y]
    inc=list(map(set,rows))
    denom=32**n
    q=denom//2
    load=[0]*len(cells)
    order=list(range(n))
    rng.shuffle(order)
    active=order[:]
    sel=[]
    theta={}
    pools={}
    hit={}
    position={}
    while active:
        i=max(active,key=lambda j:denom-max(load[k] for k in rows[j]))
        w=(denom-max(load[k] for k in rows[i]))//32
        theta[i]=w
        active.remove(i)
        position[i]=len(sel)
        sel.append(i)
        for k in rows[i]:
            load[k]+=w
            if k not in hit and load[k]>=q and w*32>=q:
                hit[k]=(position[i],{l for l in sel if k in inc[l]})
        for j in active:
            if j in pools:continue
            h=max(rows[j],key=load.__getitem__)
            if load[h]>=q:pools[j]=[k for k in sel if h in inc[k]]

    # Uniform physical parent law on cells, or half placed on original
    # selected first-hit witness cell. Integer transition rows sum to 128.
    Q=1<<36
    first={j:max((k for k in rows[j] if k in hit and hit[k][0]<position[j] and set(pools[j])==hit[k][1]),key=lambda k:-k) for j in pools}
    l=[r[0] for r in rows]; r=[rr[-1]+1 for rr in rows]
    lens=[v-u for u,v in cells]
    def transition(g,biased):
        delta=[0]*(len(cells)+1);atoms=[0]*len(cells)
        for i,value in enumerate(g):
            a=1 if biased and i in first else 2
            delta[l[i]]+=a*value;delta[r[i]]-=a*value
            if a==1:atoms[first[i]]+=64*value
        total=0;out=[]
        for k,z in enumerate(lens):
            total+=delta[k];out.append(z*total+atoms[k])
        return out
    def operator(biased):
        weights=transition([1]*n,biased)
        def mul(g,upper=False):
            vals=transition(g,biased)
            # Conservative conditional means at cell, then return to label.
            mid=[((v+w-1)//w if upper else v//w) if w else 0 for v,w in zip(vals,weights)]
            cum=[0]
            for v,z in zip(mid,lens):cum.append(cum[-1]+v*z)
            out=[]
            for i in range(n):
                mass=cum[r[i]]-cum[l[i]]
                v=mass+64*mid[first[i]] if biased and i in first else 2*mass
                out.append((v+127)//128 if upper else v//128)
            return out
        assert mul([Q]*n)==[Q]*n
        return mul
    ops=[operator(False),operator(True)]
    stats=[0]*6;strict=[0,0]
    for j,pool in pools.items():
        B=set().union(*(hit[k][1] for k in rows[j] if k in hit and hit[k][0]<position[j]))
        G=[isqrt(31*theta[i]*Q**2//denom) if i in B else 0 for i in range(n)]
        for k,op in enumerate(ops):
            up=op([g+int(i in B) for i,g in enumerate(G)],True)[j]
            vec=op(G);one=vec[j];best=one
            for m in range(2,25):
                vec=op(vec);best=max(best,vec[j])
            strict[k]+=best>up
            for idx,val in enumerate((one,best,up)):stats[3*k+idx]+=val**2
    return dict(seed=seed,bad=len(pools),Q=Q,totals=stats,strict=strict,cpu=time.process_time()-start,pid=os.getpid())
if __name__=='__main__':
    lo,hi,workers=map(int,sys.argv[1:4]);use_sqrt=len(sys.argv)>4
    start=time.monotonic()
    with get_context('fork').Pool(workers) as p:rr=p.map(case,range(lo,hi),1)
    print(json.dumps(dict(host=socket.gethostname(),python=sys.version,workers=workers,elapsed=time.monotonic()-start,rows=rr)))
