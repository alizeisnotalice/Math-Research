from collections import deque
from math import isqrt
import sys, os, time, socket, json, random
from multiprocessing import get_context
from fractions import Fraction

def case(seed):
    start=time.process_time()
    rng=random.Random(seed)
    n=72+seed%41
    # Units 1/32; equal parents radius 32, disjoint owners radius 1.
    y=[0]
    for _ in range(n-1):
        y.append(y[-1]+rng.choices([2,3,4],[19,2,1])[0])
    ends=sorted({v+d for v in y for d in (-32,32)})
    cells=list(zip(ends,ends[1:]))
    rows=[[h for h,(lo,hi) in enumerate(cells) if lo>=v-32 and hi<=v+32] for v in y]
    inc=list(map(set,rows))
    denom=32**n
    q=denom//2
    load=[0]*len(cells)
    order=list(range(n))
    rng.shuffle(order)
    active=order[:]
    sel=[]
    theta={}
    pools={}
    hit={}
    position={}
    while active:
        i=max(active,key=lambda j:denom-max(load[k] for k in rows[j]))
        w=(denom-max(load[k] for k in rows[i]))//32
        theta[i]=w
        active.remove(i)
        position[i]=len(sel)
        sel.append(i)
        for k in rows[i]:
            load[k]+=w
            if k not in hit and load[k]>=q and w*32>=q:
                hit[k]=(position[i],{l for l in sel if k in inc[l]})
        for j in active:
            if j in pools:continue
            h=max(rows[j],key=load.__getitem__)
            if load[h]>=q:pools[j]=[k for k in sel if h in inc[k]]

    # Integer tent matrix A. K=A/2048, so normalized K is A/rho(A).
    from bisect import bisect_left,bisect_right
    neighbors=[(bisect_left(y,v-64),bisect_right(y,v+64)) for v in y]
    def mul(g):
        S=[0];T=[0]
        for v,w in zip(y,g):
            S.append(S[-1]+w);T.append(T[-1]+v*w)
        return [(64-v)*(S[i]-S[l])+T[i]-T[l]+(64+v)*(S[r]-S[i])-T[r]+T[i]
                for i,(v,(l,r)) in enumerate(zip(y,neighbors))]
    Q=1<<42
    h=[Q]*n
    for k in range(80):
        v=mul(h);mx=max(v)
        h=[max(1,x*Q//mx) for x in v]
    ah=mul(h)
    # Enclose spectral radius by the Collatz bounds, rounded OUT at 2^-20.
    S=1<<20
    lo=min(v*S//w for v,w in zip(ah,h));hi=max((v*S+w-1)//w for v,w in zip(ah,h))
    assert 0<lo<=hi
    stats=[0]*6
    strict=0
    for j,pool in pools.items():
        wide=set().union(*(hit[k][1] for k in rows[j] if k in hit and hit[k][0]<position[j]))
        assert set(pool)<=wide
        def track(labels):
            # Surrogate 31 theta <= 32t theta since t>=31/32.
            if use_sqrt:
                vec=[isqrt(31*theta[i]*Q**2//denom) if i in labels else 0 for i in range(n)]
            else:
                vec=[31*theta[i]*Q//denom if i in labels else 0 for i in range(n)]
            first=mul(vec)
            uvec=([vec[i]+int(i in labels) for i in range(n)] if use_sqrt else [(31*theta[i]*Q+denom-1)//denom if i in labels else 0 for i in range(n)])
            upper1=(mul(uvec)[j]*S+lo-1)//lo
            ans=0
            for m in range(1,25):
                tmp=first if m==1 else mul(vec)
                vec=[v*S//hi for v in tmp]
                ans=max(ans,vec[j])
                if m==1:one=vec[j]
            return one,ans,upper1
        one,many,upper=track(pool);ow,mw,upw=track(wide)
        assert one<=ow and many<=mw
        strict+=mw>upw
        for hidx,val in enumerate((one,many,ow,mw,upper,upw)):
            stats[hidx]+=min(Q,val)**2
    return dict(seed=seed,bad=len(pools),Q=Q,totals=stats,strict=strict,rho_bounds=[lo,hi],cpu=time.process_time()-start,pid=os.getpid())
if __name__=='__main__':
    lo,hi,workers=map(int,sys.argv[1:4]);use_sqrt=len(sys.argv)>4
    start=time.monotonic()
    with get_context('fork').Pool(workers) as p:rr=p.map(case,range(lo,hi),1)
    print(json.dumps(dict(host=socket.gethostname(),python=sys.version,workers=workers,elapsed=time.monotonic()-start,rows=rr)))
