"""Exact rational dual certificates for eight native matched LPs; stdlib only.
MATLAB floating solution supplies candidate duals, never proof of optimality.
"""
from pathlib import Path
from fractions import Fraction as F
from itertools import product
import json
ROOT=Path(__file__).resolve().parent
cases=json.loads((ROOT/'r436_cutlp_matlab.json').read_text())
reports=[]
for num,case in enumerate(cases,1):
    n,c=case['n'],case['c'];centers=case['centers'];sources=case['sources']
    # MATLAB squeezes single-column n=1 arrays; restore coordinate rows.
    if n==1: centers=[[i] for i in centers];sources=[[j] for j in sources]
    assert all(all(a==int(a) for a in x) for x in centers+sources)
    centers=[tuple(map(int,x)) for x in centers];sources=[tuple(map(int,x)) for x in sources]
    N=len(sources);M=len(centers);high=[bool(x) for x in case['high_group']]
    assert N==(2*c+19)**n and M==(2*c+1)**n
    assert len(set(sources))==N and len(set(centers))==M
    # Validate full integer grids before mixed-radix indexing: no aliases.
    assert all(len(x)==n and all(isinstance(a,int) and -c<=a<=c for a in x) for x in centers)
    assert all(len(x)==n and all(isinstance(a,int) and -c-9<=a<=c+9 for a in x) for x in sources)
    assert set(centers)==set(product(range(-c,c+1),repeat=n))
    assert set(sources)==set(product(range(-c-9,c+10),repeat=n))
    assert len(high)==M
    if case['pattern']=='stripe': expected=[(x[0]//3)%2!=0 for x in centers]
    elif case['pattern']=='checker': expected=[sum(x)%2!=0 for x in centers]
    elif case['pattern']=='radial': expected=[max(map(abs,x))>(c+1)//2 for x in centers]
    else: raise AssertionError('unknown pattern')
    assert high==expected
    base=2*c+19;offset=c+9
    def index(coords):return sum((coords[d]+offset)*base**d for d in range(n))
    assert all(index(s)==j for j,s in enumerate(sources))
    rnum=[(19 if hi else 11)**n for hi in high] # R^n=rnum/10^n
    lam=[int(round(x*10**6)) for x in case['dual_eqlin'][:M]]
    dotnum=sum(a*b for a,b in zip(lam,rnum));den=sum(rnum)
    shift=max(0,-(-dotnum//den))
    lam=[x-shift for x in lam]
    dot=F(sum(a*b for a,b in zip(lam,rnum)),10**(6+n))
    assert dot<=0
    slo=[0]*N;shi=[0]*N;lsum=[0]*N
    for i,center in enumerate(centers):
        radius=9 if high[i] else 5
        count=0
        for delta in product(range(-radius,radius+1),repeat=n):
            idx=index(tuple(center[d]+delta[d] for d in range(n)))
            (shi if high[i] else slo)[idx]+=1
            lsum[idx]+=lam[i];count+=1
        assert count==(19 if high[i] else 11)**n
    assert slo==list(map(int,case['klo'])) and shi==list(map(int,case['khi']))
    coeff=[F(49**n*a*b,a*950**n+b*550**n) if a+b else F(0)
           for a,b in zip(slo,shi)]
    # Exact full-source upper constraints after lambda adjustment.
    values=[cc-F(ll,10**6) for cc,ll in zip(coeff,lsum)]
    beta=max(values);assert all(beta+F(ll,10**6)>=cc for cc,ll in zip(coeff,lsum))
    uniform=sum(coeff,F(0))/N
    # Geometric margins; center halfwidth .049 and source halfwidth .0005.
    for radius,side in [(5,F(11,10)),(9,F(19,10))]:
        assert F(radius,10)+F(49,1000)+F(5,10000)==side/2-F(5,10000)
        assert F(radius+1,10)-F(49,1000)-F(5,10000)==side/2+F(5,10000)
    row={'case':num,'n':n,'c':c,'pattern':case['pattern'],
         'matlab_objective_exploratory':case['objective'],
         'matlab_residual_inf':case['residual_inf'],
         'certified_uniform_feasible_lower':str(uniform),
         'certified_dual_upper_beta':str(beta),'dual_upper_display':float(beta),
         'dual_rounding_denominator':10**6,'dual_integer_lambda':lam,
         'common_integer_shift':shift,'sum_lambda_Rn':str(dot),
         'max_constraint_violation_exact':'0','geometry_capture_verified':True,
         'cut_over_W_scaling':'mu=w/t, W_mu=1/t, m_i=R_i^n; cut/W_mu=sum c_j w_j',
         'scope':'Fixed finite native LP only, no original history or general bound.'}
    reports.append(row)
    print(num,n,c,case['pattern'],'float optimum=',case['objective'],
          'certified upper=',float(beta),'uniform lower=',float(uniform),
          'dual r dot=',float(dot),'upper minus float opt=',float(beta)-case['objective'])
(ROOT/'r436_cutlp_certificate.json').write_text(json.dumps(reports,indent=2)+'\n')
print('PASS: all rational dual inequalities and geometric margins verified.')
