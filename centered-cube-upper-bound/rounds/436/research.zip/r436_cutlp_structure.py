"""Summarize already certified duals; no LP solves."""
from pathlib import Path
from fractions import Fraction as F
import json
ROOT=Path(__file__).resolve().parent
raw=json.loads((ROOT/'r436_cutlp_matlab.json').read_text())
cert=json.loads((ROOT/'r436_cutlp_certificate.json').read_text())
reports=[]
for a,b in zip(raw,cert):
 n=a['n'];c=a['c'];cent=a['centers']
 if n==1:cent=[[x] for x in cent]
 rows=[]
 for hi in [False,True]:
  inds=[i for i,x in enumerate(a['high_group']) if bool(x)==hi]
  ints=[b['dual_integer_lambda'][i] for i in inds]
  group={'group':'large' if hi else 'small','count':len(inds),
   'negative':sum(x<0 for x in ints),'zero':sum(x==0 for x in ints),
   'positive':sum(x>0 for x in ints),'distinct':len(set(ints)),'by_boundary_grid_distance':[]}
  for d in sorted({c-max(map(abs,cent[i])) for i in inds}):
   vals=[b['dual_integer_lambda'][i] for i in inds if c-max(map(abs,cent[i]))==d]
   group['by_boundary_grid_distance'].append({'distance':int(d), 'count':len(vals),
    'mean_exact':str(F(sum(vals),10**6*len(vals))),
    'min':str(F(min(vals),10**6)),'max':str(F(max(vals),10**6)),
    'constant_on_layer':len(set(vals))==1})
  rows.append(group)
 E=F(98,1000)**n*a['ncenters']
 uniform_t=F(10**n,a['nsources'])
 out={'case':b['case'],'n':n,'c':c,'pattern':a['pattern'],
  'E_exact':str(E),'E_over_W_at_float_solution':float(E)*a['t'],
  'W_mu_at_float_solution':1/a['t'],'E_over_W_uniform_exact':str(E*uniform_t),
  'center_domain_coordinate_span':[-c/10-.049,c/10+.049],
  'source_domain_coordinate_span':[-(c+9)/10-.0005,(c+9)/10+.0005],
  'dual_groups':rows}
 reports.append(out)
 print('case',b['case'],'n',n,'c',c,a['pattern'],'E/W(float)=',out['E_over_W_at_float_solution'])
 for g in rows:
  print(' ',g['group'],'signs(-,0,+)=',(g['negative'],g['zero'],g['positive']),
        'distinct=',g['distinct'],'layer means=',[(d['distance'],float(F(d['mean_exact'])),d['constant_on_layer']) for d in g['by_boundary_grid_distance']])
(ROOT/'r436_cutlp_structure.json').write_text(json.dumps(reports,indent=2)+'\n')
