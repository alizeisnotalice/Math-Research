FINAL PASS（限定于本报告列举的测度、容量及有限证书结果；不认证 INFO、CUT 或原 R433 整体预算）。

已在独立 PRE 后阅读全文及32项输入。原 R433、所有历史标签和完整母账不变：无新付款、退款、整体收缩或余项改名。唯一要求的文字一致性修订已完成：cutlp_model_audit §5 的范围/全集/pattern缺项属初审版，冻结说明明确两个证书脚本已加固并重跑。

严格核验范围：

- 完整 P 对实际 dA 可逆，零 J 行由 Tonelli 在实际联合测度下排除，行列 dA-a.e.归一。σ=q_A dA 下只有列帽 rσ；accepted 上放必须再保留 1/θ_y。θ_y为原固定门参数。主稿用 γ_q=θ_y×实际 accepted 流，故其 F_q 与 geometry 的 𝔉 相差 θ_y，两个转移系数一致。严格 loggap 与 S/c_* 共同给主稿式(1)，不丢旧源门或 q 权。
- 原接受流的有向 cut/coarea 和边缘差恒等式成立，质量原子使用左开右闭约定，dt/t 不产生遗漏。反向参考流并不是原接受费用的负信用。bridge 的原记录提升保持 t=(Z−C)/J≥c_*θ_y，F_J+G_J=R 仅是恒等式；尚无 Flog_Π 的目标预算，不能称收缩。
- 近端质量窗的真实边长范围及 native layer-cake（含 base）给 J_slab≤(1+log r+2d)/q_-；完整匹配再给 C_near≤|slab|≤(1+log r+2d)W/q_-。远端 cut 的统一 W/q_- 界仍未证，不能把远跳送到不存在的原质量窗。几何附件的同中心缩质量 t 未保 q 带、也未保旧源 capture；只核实该映射的缺口，不否定一般 CUT。
- 条纹场是完整匹配的真实连续场，其 bulk 的两质量组 ρ 各为1/2。得到裸 Dlog 的 n²W 下界，排除指定 n·polylog(n)W 二次矩目标；一次正通量仅有 nW 下界，未否定所需一次预算，且其原高秩门不合格。不得把该场当原 R433 反例。
- LP 的父盒、来源包与整数 Chebyshev 捕获有严格正余量；完整 Cw=τR^n、Σw=1、τ>0 对应 μ=w/τ 和 q_A=1，一向 cut/W 系数正确。τ=0 仅能支持零捕获列，目标为0。全部来源整数全集、pattern和实际捕获计数已在两个独立证书脚本中重建。
- 对偶条件 λ·R^n≤0、β+C^Tλ≥c 的方向正确；公共有理舍入和整数 shift 后逐列弱对偶给严格 β 上界，uniform 给精确物理可行下界。浮点 primal 最优值并非精确下界，也未被证明等于 β。两个结构汇总只是当前一个退化对偶的描述，不能排除更简单统一权。

实际复现与边界：

在独立目录 /var/folders/lq/2c4qbz2n0354_tnttkv_qsz00000gn/T/r436_audit_repro__x1rznh1 运行四核心脚本、两个 certify.py 及两个 structure.py，均退出0。四核心 stdout 与冻结输出逐字节一致；两个证书重建 JSON 与冻结证书逐字节一致，stdout 亦与两个 run.txt 逐字节一致。重建结构的符号数、层差异及 E/W 与稿件对应。另核原始JSON的 dual/weights长度、正 τ、求解返回状态；这些浮点状态仍只是候选记录。

核心证据分型：mainproof 为6个完整来源区间匹配、有限接收求积模型（形式 log 系数的 Fraction 恒等式）；geometry 为3个正体积中心块场的99项混合断言及追加4项有理虚拟质量检查，对数为 Decimal75 诊断；complement 为10个有理条纹平移积分及5个产品维数行；bridge 为4个有限 matching-incidence 代数模型。它们未认证原完整 stage/early/soft/path历史，不合并成一项原生实验统计。

十个LP的8+2有限模型有理证书全部通过。独立用 Fraction 正项Taylor界核 log(19/11)<11/20，且 n(11/20)^2<1（n≤3），所以十场原 strict-K 过去都为空，不能测试原接受预算或任何渐近阶。压力例较大的有限 cut 上界不构成普遍维数结论。

本审查未重新运行 MATLAB 求解；读取其冻结候选JSON与生成代码，实际运行的是 Python 精确认证。资源文件仅为已有运行记录，数组规模估算不是 MATLAB 进程RSS，未用于数学证明。未安装软件、编译PDF、修改作者代码或仓库。一般 INFO、远端 CUT、原完整 R433 预算及全部既有吸收/全尺度/终端要求仍未解决。

最终字节绑定（32输入；审计自身不自绑定）：

- `r436_main.md`: `5ee5347dcb1a4a7fe6edfbd77756a7d2bb9ac3a23d985d7c595124ec51a4551b`
- `r436_mainproof.md`: `a4587670881d8f14fbf1c31d3d03b4b282eebfb6b1958ddd2d6a9de833218f3e`
- `r436_geometry.md`: `377ca089b758b23c3598a43a106cff4f8726814fcb3efb2206c2e922db633ce7`
- `r436_complement.md`: `ac1e058ccde67af6168b9818ee2853ecacbde5d9ea63685a28899a96f4260003`
- `r436_bridge.md`: `6567de1c60334c9f226b00617686ccb7d462de72498045a29cb77f842269854c`
- `r436_cutlp.md`: `608ab617f6257e9d0ddab0697dca71b37998cd1a0eb6d593309ded2070d27ad4`
- `r436_cutlp_model_audit.md`: `59da8e6cb436a52e499f988c9561ce4f62e0c90019ce1b1eb984690099e79aab`
- `r436_readme.md`: `b0268fa42b24f7506c57c93a74020347f8949a42ffa9e59487f4ab15a930d972`
- `r436_mainproof_check.py`: `31b6a58e74da6c47b72b3b0a3ee4f8e18542544d9161083e14fb994527a42992`
- `r436_mainproof.result.txt`: `66b1911387663f08805cedb6198d0622fd50ec8ab4d94b7b7fd567b360b15c1d`
- `r436_geometry_check.py`: `c676991cbae784b9156cf550f08421fa8bc8a2452253c111146263a5a31e2a14`
- `r436_geometry.result.txt`: `5b7594e88ecc6087ee86297b88ecc9f3a7773907f6c45118afb8e8a276a92731`
- `r436_complement_check.py`: `9156151cb94ff0583b455c06a8c6b54fdd9a4c139479da8f678cdf9a0cf3e24f`
- `r436_complement_check.result.json`: `3a3739bc9e8666ecb3afee3e8a8ac745e09cab3d465e8c096560a18233b2ecfc`
- `r436_bridge_check.py`: `605c553884311db42b93850e3721aae1f48ec34fabea1a911a375ca8f9ea75fb`
- `r436_bridge_check.stdout`: `c1c659fe0b371d5b790e3765a3272794d3e9fc3f835b2ad085e6c6c10d2ed073`
- `r436_cutlp.m`: `00ec9d0cd4c441d0179612c81bebacf0abddf3ed627749420b3c54601b0f793b`
- `r436_cutlp_certify.py`: `caa360cd78fcde2a48b6b5a928d7a305656c3f6afb4d55aeeed1611059881555`
- `r436_cutlp_matlab.json`: `92e9307225d2d37dd40425813b787150365c7a02f01cedd477cdf956eeba5a5b`
- `r436_cutlp_certificate.json`: `7efda9cc1f97d8c56fc2cfae55b9ccd42be00997cea318e81ee55c8139599601`
- `r436_cutlp_run.txt`: `f4e98eed6f776e03bffd9a357ea8a0da02733043523bbe8d60f9c4a7607c3d55`
- `r436_cutlp_resources.txt`: `61affedc30110beed90dd0a6b1c3d493b184f22e4fdcb32068878a1baeb76d09`
- `r436_cutlp_structure.py`: `f3a27e304e559ca24a3b2e01ec09b61409b8065f26453a32f733a5bfc83b013a`
- `r436_cutlp_pressure.m`: `5a7a56efca47a577c43bdf8d24ab2ffe084c96a496e1a0e824eaa5454ec3c388`
- `r436_cutlp_pressure_certify.py`: `ee2b0982c795425e57389632d9166b5c9f608bfb1b7976654d9c76b45f32fbc1`
- `r436_cutlp_pressure_matlab.json`: `ddee4bad6d212a2ba5f79f015dc4e20c5ff32f07ba07693bf1b92b82d02f1759`
- `r436_cutlp_pressure_certificate.json`: `7ba0564bcf510ce03416c781f9fe1662b2db5ccaf09216e1c523992e871b1447`
- `r436_cutlp_pressure_run.txt`: `fb9a4634c0558338b126fc05e16d1555bccbfdcd978585fd73291856db519062`
- `r436_cutlp_pressure_resources.txt`: `ebc8269758867247b9747695dd3f9ffadbf30ae07d9deab2a591a79e00457cbd`
- `r436_cutlp_pressure_structure.py`: `41718f72d80fbaa0a3be0e5085ee57d0242b2f6a2db1efbb898e45ce8c0a1177`
- `r436_contract.md`: `2db5be8f60c96065f8949d122c08298ad26632f627b63a3a9aef6f6c0c86041f`
- `r435_contract.md`: `02906c27e31bd24a95264197f0dc18946434b790dd70868e3670354fbb3203f3`
