% Native continuous two-side matched cut LP. No original history claim.
cutcases={1,100,'stripe';2,20,'stripe'};
results=cell(size(cutcases,1),1);
opts=optimoptions('linprog','Display','none','Algorithm','dual-simplex-highs');
for caseidx=1:size(cutcases,1)
 n=cutcases{caseidx,1}; c=cutcases{caseidx,2}; pattern=cutcases{caseidx,3};
 cv=cell(1,n); sv=cell(1,n);
 [cv{:}]=ndgrid(-c:c); [sv{:}]=ndgrid(-c-9:c+9);
 Ic=zeros(numel(cv{1}),n); Js=zeros(numel(sv{1}),n);
 for d=1:n; Ic(:,d)=cv{d}(:); Js(:,d)=sv{d}(:); end
 M=size(Ic,1); N=size(Js,1);
 switch pattern
  case 'stripe'; ishi=mod(floor(Ic(:,1)/3),2)~=0;
  case 'checker'; ishi=mod(sum(Ic,2),2)~=0;
  case 'radial'; ishi=max(abs(Ic),[],2)>ceil(c/2);
 end
 dist=zeros(M,N);
 for d=1:n; dist=max(dist,abs(Ic(:,d)-Js(:,d)')); end
 C=sparse((~ishi & dist<=5) | (ishi & dist<=9)); clear dist
 R=1.1+0.8*ishi; rn=R.^n;
 klo=full(sum(C(~ishi,:),1))'; khi=full(sum(C(ishi,:),1))';
 hlo=(.098/1.1)^n*klo; hhi=(.098/1.9)^n*khi;
 coeff=zeros(N,1); good=hlo+hhi>0;
 coeff(good)=hlo(good).*hhi(good)./(hlo(good)+hhi(good));
 Aeq=[C,sparse(-rn);sparse(ones(1,N)),sparse(1,1)]; beq=[zeros(M,1);1];
 uniform=[ones(N,1)/N;10^n/N];
 assert(norm(Aeq*uniform-beq,inf)<1e-12);
 tic; [xx,fval,exitflag,out,lambda]=linprog([-coeff;0],[],[],Aeq,beq,zeros(N+1,1),[],opts); elapsed=toc;
 assert(exitflag==1);
 dual=lambda.eqlin;
 result=struct('n',n,'c',c,'pattern',pattern,'centers',Ic,'sources',Js,...
 'high_group',ishi,'klo',klo,'khi',khi,'objective',-fval,...
 'uniform_objective',coeff'*uniform(1:N),'t',xx(end),'weights',xx(1:N),...
 'dual_eqlin',dual,'residual_inf',norm(Aeq*xx-beq,inf),...
 'dual_stationarity_min',min(C'*dual(1:M)+dual(end)-coeff),...
 'dual_t_dot',rn'*dual(1:M),'elapsed_seconds',elapsed,...
 'exitflag',exitflag,'ncenters',M,'nsources',N,'nnz_capture',nnz(C));
 results{caseidx}=result;
 fprintf('case %d n%d c%d %s: optimum %.12g uniform %.12g residual %.3g seconds %.3g\n',...
 caseidx,n,c,pattern,-fval,result.uniform_objective,result.residual_inf,elapsed);
end
outputdir=fileparts(mfilename('fullpath'));
fid=fopen(fullfile(outputdir,'r436_cutlp_pressure_matlab.json'),'w');fwrite(fid,jsonencode(results),'char');fclose(fid);
fprintf('Saved r436_cutlp_pressure_matlab.json; original history not certified.\n');
