from fractions import Fraction as F

def add(d,k,v):
    d[k]=d.get(k,F(0))+v
    if d[k]==0:del d[k]

def run(centers,sides,weights,bump,K):
    boxes=[(c-r/2,c+r/2) for c,r in zip(centers,sides)]
    cuts=sorted({F(0),F(8),F(2),F(4),*(x for box in boxes for x in box)})
    src=[]
    for a,b in zip(cuts,cuts[1:]):
        x=(a+b)/2
        if not 0<=x<=8:continue
        density=1+bump if 2<x<4 else F(1)
        inc=[l<x<r for l,r in boxes]
        src.append(((b-a)*density,inc))
    mass=[sum(v for v,inc in src if inc[i]) for i in range(len(boxes))]
    q=[m/r for m,r in zip(mass,sides)];lam=max(q)
    assert min(q)>=3*lam/4
    nu=[[F(0) for _ in boxes] for _ in boxes]
    for v,inc in src:
        J=sum(weights[i]/mass[i] for i in range(len(boxes)) if inc[i])
        if not J:continue
        for i in range(len(boxes)):
            for j in range(len(boxes)):
                if inc[i] and inc[j]:nu[i][j]+=v*weights[i]*weights[j]/(mass[i]*mass[j]*J)
    for i in range(len(boxes)):
        assert sum(nu[i])==weights[i]
        assert all(nu[i][j]==nu[j][i] for j in range(len(boxes)))
    accepted=[[q[i]*nu[i][j]*F(1+(i+j)%3,3) if mass[i]>K*mass[j] else F(0)
               for j in range(len(boxes))] for i in range(len(boxes))]
    div=[sum(accepted[i])-sum(accepted[j][i] for j in range(len(boxes))) for i in range(len(boxes))]
    assert sum(div)==0
    edgepoly={};divpoly={};cutpoly={}
    for i in range(len(boxes)):
        add(divpoly,mass[i],div[i])
        for j in range(len(boxes)):
            assert accepted[i][j]<=lam*nu[i][j]
            add(edgepoly,mass[i],accepted[i][j]);add(edgepoly,mass[j],-accepted[i][j])
    levels=sorted(set(mass))
    for lo,hi in zip(levels,levels[1:]):
        cut=sum(accepted[i][j] for i in range(len(boxes)) for j in range(len(boxes)) if mass[j]<=lo<mass[i])
        assert cut==sum(div[i] for i in range(len(boxes)) if mass[i]>=hi)
        assert cut>=0
        add(cutpoly,hi,cut);add(cutpoly,lo,-cut)
    assert edgepoly==divpoly==cutpoly
    return bool(edgepoly),len(src)

ct=0;positive=0
for bump in [F(0),F(1,8),F(1,3)]:
 for K in [F(3,2),F(5,2)]:
    pos,n=run([F(1),F(2),F(3),F(5)],[F(1),F(2),F(4),F(2)],
              [F(1,3),F(1,2),F(2,3),F(1,4)],bump,K)
    ct+=1;positive+=pos
print(f'PASS {ct} exact weighted-interval incidence fixtures, {positive} positive oriented log polynomials.')
print('Detailed balance, matched full-source masses/q-band, accepted domination, cut/divergence/log-polynomial identity verified.')
print('Receiver weights are finite quadrature, not a positive-Lebesgue single-valued selector or the original high-dimensional history.')
