# R436 bridge：保留 Z/J 差额的原流自比较

只读本轮 `/tmp/r436_contract.md`，并沿用其中指定的 R435 原合同。没有整体预算结论。唯一保留候选是“原 exclusive 提升中保留 rank/J 的互补质量，再支付其同源有向 log 通量”。它给出对接几何预算的准确接口；未证通量预算不计为新付款。

## 1. 可逆核与原 high-rank 门必须是同一来源和同一质量过去

固定原旧来源 y，用同一实际接收场的 `ρ_y(du)=c_u(y)du/m_u`、`J(y)=∫ρ_y`、`Z_A(y)=∫_{m_u<m_A/K}ρ_y`。原相对秩给 `Z_A(y)≥θ_y J(y)`，θ_y>0 为原冻结常数。不能换成新 z 的门、当前 D_i、g_t 的质量或另造父场的 J；也不能把 θ_y 移到一次后验刷新后的来源。

完整匹配 `m_A=∫f c_A` 使

`dA P(A,du)=dA du ∫ f(y)c_A(y)c_u(y)/(m_A m_u J(y))dy`

对称，两边缘恰为 dA。J=0 行在原来源测度下无贡献；正来源行的 J 有原 A_n/q 上界。σ=q_A dA 时列密度是

`d(σP)/dσ(u)=q_u^−1 ∫q_A P(u,dA)≤λ/q_u≤r`。

这是 column≤rσ，不是 σ 可逆；q_A 不能直接移出核积分。加原 L、exclusive、early/history 后，只保留为 full 核的正支配，不再有实际通量的对称等式。

## 2. 唯一候选：把 prefix 互补差额留在同一个 R 上

令 Π=Π433，R=|Π|。对每个原完整记录 `(A,y,z,history)`，原正支有

`Z=Z_A(y)>(4−ε0)h`，`C=C_A(y,z)<h`。

新增辅助 exclusive **概率**核

`Qex(du)=1_{m_u<m_A/K}ρ_y(du)(1−c_u(z))/(Z−C)`。

它只是一份概率提升；u 不获得旧历史，不用于免费刷新 Π。令

`t=(Z−C)/J`，`c*=1−1/(4−ε0)`，`d*=c*θ_y>0`。

则 `d*≤t≤1`。在同一原记录上，严格有

`R=F_J+G_J`，`F_J=∫t dΠ`，`G_J=∫(1−t)dΠ≤(1−d*)R`。  (1)

因此如果能付 F_J，就能把余差吸收到原 R，而无需把这项差额上放成 X 大常数。区别于先用 `1/Z≤1/(θ_y J)`，(1)保留了互补权的身份。它本身只是恒等式：尚未证明 F_J 的目标价，不能称已获收缩。

为接 strict mass drop，定义同一原带历史费用的通量

`Flog_Π=∫Π(drecord) ∫_{m_u<m_A/K} ρ_y(du)(1−c_u(z)) log(m_A/m_u)/J(y)`。

非负性及 strict K=e^√n 给

`Flog_Π ≥ √n F_J ≥ d*√n R`。  (2)

故一项足够且量词明确的待证桥是：对每 β>0，

`Flog_Π≤β√n X + Cβ n log^A(n+2)W`，  (3)

Cβ 对 n、阶段、尺度一致，并显示对冻结参数的受控依赖。取 β=d*ε 即完成原整体目标。允许 (3) 直接保原历史/soft/低指标；无需先证更强的无标记全场 Dlog。单独重复 (2)不算证明 (3)。

## 3. 与完整可逆 Flog 的 S、r 系数

若几何侧只得 full 无标记

`Flog=∫dA P(A,du)1_{m_A>K m_u}log(m_A/m_u)`，

原静态 sourcewise 帽仍只用一次 S：保固定源 y 与 z，应用非负静态推前，再把 `∫π_A(dz)(1−c_u(z))≤1`，得到

`Flog_Π≤S∫σ(dA)P(A,du)1_down log≤Sλ Flog=S r(q Flog)`。  (4)

因此若 full 侧证明 `qFlog≤γ√n X+Cγ n log^A W`，应取 `γ=d*ε/(Sr)`；最终 W 价乘 `Sr/d*`。没有额外 stage/两来源因子；S 已含两个父方向。若几何作者保 B 或 L，其实际加权通量可直接接 (2)，但必须逐项核同一原字段和 π 来源权，不能再把接受权无损换成原历史核。

## 4. 唯一缺桥与候选筛选标准

当前缺的是 (3)，或足够强的 full 版本；可逆性未证明它。完整对称 flux 只给 down/up 正费用相等，signed log 总积分为零；没有给正 down 费用消失。原 B、L、历史门随方向改变，反向流也未必是任何原原始费用。

任何势差论证若需要在 A→u 后继续，必须给原记录的合法输送、边界和 occupation defect；u 捕获 y 不授予 u 原 first-deletion、early 或两路径历史。任何 entropy/KL 候选须另证与 (3)同一原通量的方向正确比较；预算有限不能替代比较。任何只给 r 或1/d*的列帽都仍是 X 级粗支配，不是 W 根阶预算。仅 Dlog 的二阶上界还须核从其到 (3)是否引入√X或额外 n 损失。

(1)是真正把 rank/J 互补差额留在原 R 的最小自比较；它消除了“剩余改名为另一父测度”的形式问题，未消除几何预算难点。所有旧已付分支无退款；本轮无新增正式费用或余项。

## 5. 实际本机证据

已运行 `/tmp/r436_bridge_check.py`，stdout `/tmp/r436_bridge_check.stdout`。4 个 Fraction 配置使用完整 source matching 的三父三源有限 incidence 核，核 row=1、dA-flux 对称、q-column≤r、`F_J+G_J=R`。这是代数核验；既非连续单值 cube 选择器，也不满足全部原 early/history/path 合同，不是原目标反例或 (3)的证据。未运行或声称宽反例扫描。
