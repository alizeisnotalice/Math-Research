from fractions import Fraction as F
from decimal import Decimal as D, localcontext
n=16; side=[F(1),F(3,2),F(2)]; eta=F(1,1000)
volume=[eta**n,(eta/2)**n,(eta/3)**n]
qcases=[(F(1),F(1),F(1)),(F(1),F(5,4),F(3,2)),(F(3,2),F(5,4),F(1))]
x=[F(0),F(5,8),F(7,8)]
checks=0
with localcontext() as ctx:
 ctx.prec=75
 def dec(x): return D(x.numerator)/D(x.denominator)
 for phase,q in enumerate(qcases,1):
  m=[q[a]*side[a]**n for a in range(3)]
  weight=[m[0],m[1]-m[0],m[2]-m[1]]
  assert min(weight)>0; checks+=1
  for a,R in enumerate(side):
   for y in range(3):
    inside=abs(x[y])+eta<R/2 and F(a+1,100)+eta<R/2
    outside=abs(x[y])-eta>R/2
    assert inside if y<=a else outside; checks+=1
   for u in range(a):
    assert m[a]/m[u]>64; checks+=1  # e^sqrt(16)=e^4<64.
  pi=[[weight[y]/m[a] if y<=a else F(0) for y in range(3)] for a in range(3)]
  J=[sum((volume[a]/m[a] for a in range(y,3)),F(0)) for y in range(3)]
  P=[[sum((pi[a][y]*volume[u]/(m[u]*J[y]) for y in range(min(a,u)+1)),F(0)) for u in range(3)] for a in range(3)]
  sigma=[q[a]*volume[a] for a in range(3)]
  r=max(q)/min(q)
  for a in range(3):
   assert sum(P[a])==1; checks+=1
   for u in range(3):
    assert volume[a]*P[a][u]==volume[u]*P[u][a]; checks+=1
  for u in range(3):
   assert sum((sigma[a]*P[a][u] for a in range(3)),F(0))<=r*sigma[u]; checks+=1
  sigma_reversible=all(sigma[a]*P[a][u]==sigma[u]*P[u][a] for a in range(3) for u in range(3))
  assert sigma_reversible==(phase==1); checks+=1
  down=sum((dec(volume[a]*P[a][u])*dec(m[a]/m[u]).ln() for a in range(3) for u in range(a)),D(0))
  up=sum((dec(volume[u]*P[u][a])*dec(m[a]/m[u]).ln() for a in range(3) for u in range(a)),D(0))
  assert down==up and down>0; checks+=1
  E=F(0); Flog=D(0); radial=D(0); qpart=D(0)
  for a in range(3):
   for y in range(a+1):
    Z=sum((volume[u]/m[u] for u in range(y,a)),F(0))
    if not Z: continue
    for u in range(y,a):
     # L=1 is diagnostic only; exclusivity is integrated against full pi_A.
     B=1-m[u]/m[a]
     flux=sigma[a]*pi[a][y]*(volume[u]/m[u])/Z*B
     E+=flux
     Flog+=dec(flux)*dec(m[a]/m[u]).ln()
     radial+=dec(flux)*dec(side[a]/side[u]).ln()
     qpart+=dec(flux)*dec(q[a]/q[u]).ln()
  tol=D('1e-65')*dec(sum(sigma))
  assert abs(Flog-n*radial-qpart)<=tol; checks+=1
  assert abs(qpart)<=dec(E)*dec(r).ln()+tol; checks+=1
  assert Flog+tol>=D(4)*dec(E); checks+=1
  print('phase',phase,'sigma reversible',sigma_reversible,'positive reversible one-way flux',down)
  print('accepted E, Flog, radius cut, q term:',dec(E),Flog,radial,qpart)
print('PASS',checks,'assertions; 3 native complete-matching block fields')
print('Exact Fraction geometry/probabilities; 75-digit Decimal log diagnostics, not interval proof.')
print('L=1: no original high-rank, low-common, stage or path certification; no global budget test.')
# One bounded check of the attempted intermediate-mass receiver construction.
# Use the constant-q native field from phase 1; t is outside a factor-2 slab
# around both the side-3/2 and side-2 actual parent masses.
m_small=F(3,2)**16; m_large=F(2)**16; t=8*m_small
assert 2*m_small<t and 2*t<m_large
fraction=(t-m_small)/(m_large-m_small)
R_virtual=F(7,4)-eta+2*eta*fraction
q_virtual=t/R_virtual**16
# Whole original big-center block: first center coordinate in [-eta/6,eta/6].
R_virtual_min=F(7,4)-F(4,3)*eta
assert 0<fraction<1
assert q_virtual<1
assert t/R_virtual_min**16<1
print('Intermediate-mass check: 4 exact assertions; actual q=1, virtual q<1 on the full positive big-center block.')
print('t=',t,'virtual q at central first coordinate=',q_virtual)
print('This tests failure of the proposed selector-preserving map, not the far-cut bound or original history.')
