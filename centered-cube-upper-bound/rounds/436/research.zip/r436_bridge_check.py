from fractions import Fraction as F
f=[F(2),F(5),F(3)]
c=[[1,1,0],[1,0,0],[0,1,1]]
m=[sum(f[k]*row[k] for k in range(3)) for row in c]
q=[F(1),F(2),F(3,2)]
checks=0
for vb in [F(1,6),F(1,3),F(1,2),F(1)]:
 v=[F(1),vb,F(1,2)]
 J=[sum(v[i]*c[i][k]/m[i] for i in range(3)) for k in range(3)]
 P=[[sum(f[k]*c[i][k]/m[i]*v[j]*c[j][k]/m[j]/J[k] for k in range(3)) for j in range(3)] for i in range(3)]
 for i in range(3):
  assert sum(P[i])==1
  for j in range(3): assert v[i]*P[i][j]==v[j]*P[j][i]
 for j in range(3):
  col=sum(q[i]*v[i]*P[i][j] for i in range(3))/(q[j]*v[j])
  assert col<=max(q)/min(q)
 # y=source0,z=source1,A=parent0,K=3: only parent1 is in strict mass-past.
 Z=v[1]/m[1]; C=F(0); tex=(Z-C)/J[0]
 assert F(0)<tex<1
 R=F(17,9)
 base=R*tex; complement=R*(1-tex)
 assert base+complement==R
 checks+=1
print(f'PASS: {checks} exact matched-incidence reversibility/q-column/complement models')
print('Scope: finite algebra only, not continuous single-valued cubes or full early/history/path admissibility; no Flog budget proved.')
