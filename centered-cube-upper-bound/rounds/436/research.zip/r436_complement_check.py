from fractions import Fraction as F
from math import isqrt
import json

# Period-1 set S=union [k,k+1/2). Exact antiderivative for arbitrary rational x.
def stripe_F(x):
 k=x.numerator//x.denominator
 r=x-k
 return F(k,2)+min(r,F(1,2))
def stripe_measure(lo,hi):return stripe_F(hi)-stripe_F(lo)
ys=[F(-7,3),F(-1,10),F(0),F(11,7),F(9,2)]
assert 2*(F(1,3)+F(1,81)+F(1,1215))>F(69,100)
checks=[]
for y in ys:
 for side in [F(1),F(2)]:
  got=stripe_measure(y-side/2,y+side/2)
  assert got==side/2
  checks.append({'y':str(y),'side':str(side),'stripe_length':str(got)})
rows=[]
for n in [9,16,64,256,1024]:
 ell=isqrt(n);assert ell*ell==n
 L=4*n
 bulk_ratio=(F(L-2,L))**n
 assert bulk_ratio>=F(1,2)
 # n log2 > sqrt n is certified here by log2>69/100.
 assert F(69*n,100)>ell
 # Dlog/W >= bulk_ratio*n^2*(log2)^2/2.
 d_coeff=bulk_ratio*n*n/2
 f_coeff=bulk_ratio*n/4
 assert d_coeff>=F(n*n,4)
 assert f_coeff>=F(n,8)
 # With threshold log(t)=n log2/2 and unit-width mass slab,
 # both actual levels lie outside the slab for n>=9.
 assert F(69*n,200)>1
 rows.append({'n':n,'bulk_fraction':str(bulk_ratio),
   'Dlog_over_W_coefficient_of_log2_squared':str(d_coeff),
   'Flog_over_W_coefficient_of_log2':str(f_coeff),
   'Ccut_over_W_lower':str(bulk_ratio/4),
   'unit_mass_slab_is_empty':True})
print(json.dumps({'stripe_checks':checks,'geometric_product_rows':rows,
 'scope':'Exact Fraction computations for a real continuous periodic-side cube field; log2 remains symbolic with rational lower bound 69/100. Does not satisfy original high-rank/soft/path gates and is not an original-flow counterexample.'},indent=2))
