#!/usr/bin/env python3
"""Whole paired endpoints: actual common-middle kernel versus two one-point upper bounds."""
import argparse
from collections import defaultdict
from fractions import Fraction as F
from itertools import product
import json
from pathlib import Path

from flint import arb
import joint810 as base
from menus810 import GATES, as_ball, ball, membership_cells


def verify(case, saved, gate):
    n, amp, mid, old = case
    mu = lambda b, **kw: base.mass(b, amp, **kw)
    T = base.parents(n, mid, base.MIDDLE_SHARES, mu)
    U = base.parents(n, old, base.SMALL_SHARES, mu)
    Y = sum(p["j"] for p in U)
    t_bins = [p["bin"] for p in T]
    a = {}
    present = {}
    for u, parent in enumerate(U):
        for mask, mass in membership_cells(parent["physical_A"], T, mu).items():
            active = frozenset(t for t in range(len(T)) if mask & (1 << t)
                               and parent["radius"] < T[t]["radius"])
            # The undeleted source cells and both halves account for the complete alpha.
            for half in (0, 1):
                x = (u, mask, half)
                a[x] = parent["j"] * mass / (2 * parent["true_m"])
                present[x] = active
    assert sum(a.values()) == Y
    d = [F(row["full_original_degree"]) for row in saved["tests"]]
    base_t = [t["j"] / t["true_m"]**2 for t in T]
    by_bin = {k: frozenset(t for t, lab in enumerate(t_bins) if lab == k) for k in set(t_bins)}
    rows, posts = defaultdict(F), defaultdict(F)
    weight = {}
    totals = defaultdict(F)
    # Each endpoint is its full label, actual first-coordinate receiver half and true middle-membership cell.
    # The relation and the common-middle density are constant on this product of real sets.
    for x, y in product(a, repeat=2):
        u, g = x[0], y[0]
        if gate != GATES[0] and U[u]["bin"] == U[g]["bin"]:
            continue
        if gate == GATES[2] and x[2] != y[2]:
            continue
        for k, group in by_bin.items():
            common = present[x] & present[y] & group
            if not common:
                continue
            kernel = sum(base_t[t] for t in common)
            one_point = min(sum(base_t[t] for t in present[x] & group),
                            sum(base_t[t] for t in present[y] & group))
            assert 0 < kernel <= one_point
            raw = F(0)
            for t in common:
                piece = a[x] * a[y] * base_t[t] / d[t]
                raw += piece
                totals[t, g, u] += piece
            weight[k, x, y] = kernel, one_point, raw
            rows[k, x] += a[y]
            posts[k, x] += raw
    expected = {(row["t"], e["q_g"], e["z_u"]): F(e["actual_mass"])
                for row in saved["tests"] for law in row["actual_joint_laws"] if law["law"] == gate
                for e in law["original_label_edge_masses"]}
    assert dict(totals) == expected
    assert all(weight[k, y, x] == item for (k, x, y), item in weight.items())
    marginal = {x: sum(posts[k, x] for k in by_bin) for x in a}
    num_bins = {x: sum(posts[k, x] > 0 for k in by_bin) for x in a}
    out = []
    for choice in ("support_uniform", "actual_bin_posterior"):
        material = arb(0)
        coarse = arb(0)
        alternate = arb(0)
        strict = F(0)
        total_raw = sum(totals.values())
        hits = {level: [F(0), F(0)] for level in (F(1,4), F(1,2), F(1))}
        for (k, x, y), (K, cap, raw) in weight.items():
            if choice == "support_uniform":
                cprod2 = F(1, num_bins[x]*num_bins[y])
            else:
                cprod2 = posts[k, x]*posts[k, y]/(marginal[x]*marginal[y])
            J2 = cprod2/(rows[k,x]*rows[k,y])
            ar_j = ball(J2).sqrt()
            alpha_pair = a[x]*a[y]
            material += ball(alpha_pair) * ar_j
            coarse += ball(alpha_pair*K/cap) * ar_j
            for t in present[x] & present[y] & by_bin[k]:
                true_mass = alpha_pair * base_t[t] / d[t]
                alternate += ball(true_mass*d[t]/K) * ar_j
                true_scaled = (total_raw*d[t]/(Y*K))**2 * J2
                coarse_scaled = true_scaled*(K/cap)**2
                for lev, counts in hits.items():
                    counts[0] += true_mass if true_scaled >= lev**2 else 0
                    counts[1] += true_mass if coarse_scaled >= lev**2 else 0
            if K < cap:
                strict += raw
        mat_ratio, coarse_ratio = material/ball(Y), coarse/ball(Y)
        assert material.overlaps(alternate)
        assert mat_ratio > 0 and mat_ratio <= 1 and coarse_ratio > 0
        if strict:
            assert mat_ratio > coarse_ratio
        else:
            assert mat_ratio.overlaps(coarse_ratio)
        out.append(dict(choice=choice,full_common_over_owner=as_ball(mat_ratio),
                        two_one_point_over_owner=as_ball(coarse_ratio),strict_pair_fraction=str(strict/total_raw),
                        exact_hit_fractions={str(k): list(map(str,(a/total_raw,b/total_raw)))
                                             for k,(a,b) in hits.items()}))
    return dict(gate=gate,positive_records=len(weight),mother=str(sum(totals.values())),results=out)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", type=Path, required=True)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--check", type=Path)
    args = parser.parse_args()
    previous = json.loads(args.data.read_text())["stages"]
    stages = []
    for (name,n,amp,t,u), saved in zip(base.FIXTURES,previous,strict=True):
        comparisons = [verify((n,amp,t,u),saved,gate) for gate in GATES]
        stages.append(dict(stage=name,n=n,comparisons=comparisons))
    # The first three fixtures have comparable sets of compatible middles whenever
    # they have a common middle in the same bin. A fourth physical input tests
    # the strict distinction, before doing any further parameter search.
    assert all(F(x["results"][0]["strict_pair_fraction"]) == 0
               for stage in stages for x in stage["comparisons"])
    fourth = ("three_simultaneous_middles", 3, F(1,2),
              [(("-3/4",0,0),"3/2"),((0,0,0),"3/2"),(("3/4",0,0),"3/2"),
               ((0,"1/2",0),"7/4")],
              [(("-7/4",0,0),1),(("7/4",0,0),"11/8"),
               (("-9/4",0,0),"17/16"),(("9/4",0,0),"23/16")])
    additional = base.example(*fourth)
    name, n, amp, t, u = fourth
    comparisons = [verify((n,amp,t,u),additional,gate) for gate in GATES]
    assert all(F(x["results"][0]["strict_pair_fraction"])>0 for x in comparisons)
    stages.append(dict(stage=name,n=n,comparisons=comparisons))
    result=dict(stages=stages,arithmetic="Fraction, flint Arb 384 bits via menus810",measures="alpha(X)=b_u mu(true cell) times Lebesgue owner half fraction. Degrees include all original neighboring parents. Middle T sums only common physically allowed middles.",
                scope="Four finite diagnostic models, all small-middle volume bins. Both true labels and physical receiver halves are retained. The asymptotic high-dimensional hard-event hypotheses are outside these fixtures.")
    text=json.dumps(result,indent=2,sort_keys=True)+"\n"
    if args.output:
        args.output.write_text(text)
    if args.check:
        assert args.check.read_text()==text
    for s in stages:
        print(s["n"],[(g["gate"],g["results"][1]["full_common_over_owner"]["midpoint_12"],
                        g["results"][1]["two_one_point_over_owner"]["midpoint_12"],
                        round(float(F(g["results"][1]["strict_pair_fraction"])),7))
                       for g in s["comparisons"]])


if __name__ == "__main__":
    main()
