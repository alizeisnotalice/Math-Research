#!/usr/bin/env python3
"""Exact true-source atoms, lifted Schur normalization, entropy and forward KL."""
import argparse
from collections import defaultdict
from fractions import Fraction as F
from hashlib import sha256
from itertools import product
import json
from pathlib import Path
import platform

import flint
from flint import arb, ctx

import joint810 as model


DEPENDENCIES={
    'joint810.py':'a682813430d04acba31640cb04a386369f98c0742a918db66562c847f353d250',
    'joint810.json':'2dc3b67f4f92daad1e8c5c4c3f45990c498aeab122d208809c3edb44e3efff01',
}


def total(x):
    return sum(x,F(0))


def ar(x):
    return arb(x.numerator)/x.denominator


def arsum(x):
    return sum(x,arb(0))


def enclosure(x):
    return dict(ball=x.str(45),internal_radius=x.rad().str(8))


def atom_box(B):
    return tuple(tuple(map(F,axis)) for axis in B)


def in_mask(mask,i):
    return bool((mask>>i)&1)


def true_atoms(physical,amp,n):
    parents=[atom_box(x['physical_A']) for x in physical]
    mu=lambda B:model.mass(B,amp)
    N=len(parents)
    supports=[((-model.SUPPORT,model.SUPPORT),)*n]
    for m in range(1,1<<N):
        b=m&-m
        supports.append(model.clip(supports[m-b],parents[b.bit_length()-1]))
    intersections=[]
    for Q in supports:
        v=mu(Q)
        assert v==model.mass(Q,amp,by_quarters=True)
        intersections.append(v)
    inverse=intersections.copy()
    for k in range(N):
        for m in range(1<<N):
            if not in_mask(m,k):
                inverse[m]-=inverse[m|(1<<k)]
    assert all(v>=0 for v in inverse)
    # Independent physical atom sweep. Merge coordinate signatures between axes.
    direct={(1<<N)-1:F(1)}
    witnesses={(1<<N)-1:()}
    for d in range(n):
        boundaries=sorted({-model.SUPPORT,model.SUPPORT,*(p for B in parents for p in B[d])})
        along=defaultdict(F)
        exemplars={}
        for l,r in zip(boundaries,boundaries[1:]):
            i=sum(1<<k for k,B in enumerate(parents) if B[d][0]<=l<r<=B[d][1])
            along[i]+=model.mass(((l,r),),amp,by_quarters=True) if d==0 else r-l
            exemplars.setdefault(i,(l,r))
        updated=defaultdict(F)
        new_W={}
        for m,i in product(direct,along):
            updated[m&i]+=direct[m]*along[i]
            new_W.setdefault(m&i,witnesses[m]+(exemplars[i],))
        direct,witnesses=updated,new_W
    result={m:v for m,v in enumerate(inverse) if v}
    assert direct==result and total(result.values())==intersections[0]
    for m,Q in witnesses.items():
        q=mu(Q)
        assert q>0 and q<=result[m]
        assert all(mu(model.clip(Q,B))==(q if in_mask(m,i) else 0) for i,B in enumerate(parents))
    for i,p in enumerate(physical):
        assert total(v for m,v in result.items() if in_mask(m,i))==F(p['true_m'])
    return result,witnesses


def true_arms_and_pairs(s,law,atoms):
    Ts,Us=s['middles'],s['olds']
    nt=len(Ts)
    output={}
    geometry={}
    rates={}
    for t in s['tests']:
        i=t['t']
        for a in t['true_arms']:
            u=a['g']
            cells={c:w for c,w in atoms.items() if in_mask(c,i) and in_mask(c,nt+u)}
            j=F(a['j_mu'])
            assert total(cells.values())==j>0
            rate=F(Us[u]['j'])/F(Us[u]['true_m'])/F(Ts[i]['true_m'])
            raw=total(rate*w for w in cells.values())
            assert raw==F(a['raw'])
            geometry[i,u]={c:v/j for c,v in cells.items()}
            assert total(geometry[i,u].values())==1
            rates[i,u]=raw
        actual=next((x for x in t['actual_joint_laws'] if x['law']==law),None)
        e={} if actual is None else {(i,x['z_u'],x['q_g']):F(x['actual_mass']) for x in actual['original_label_edge_masses']}
        via_arms={}
        for a,b in product([u for j,u in rates if j==i],repeat=2):
            if law=='different_size_bins' and Us[a]['bin']==Us[b]['bin']:
                continue
            via_arms[i,a,b]=F(Ts[i]['j'])/F(t['full_original_degree'])*rates[i,a]*rates[i,b]
        assert via_arms==e
        if actual:
            assert total(via_arms.values())==F(actual['original_joint_mother'])
        output.update(via_arms)
    S=total(output.values())
    assert S>0
    return output,geometry,rates,S


def marginal_side(pair,loc,ind):
    raw=defaultdict(F)
    for tag,w in pair.items():
        t,u=tag[0],tag[ind]
        for z,k in loc[t,u].items():
            raw[t,u,z]+=w*k
    return raw


def project_two(M,axis):
    out=defaultdict(F)
    for k,v in M.items():
        kk=tuple(k[i] for i in axis)
        out[kk]+=v
    return out


def weighted_logs(items):
    grouped=defaultdict(F)
    for prob,ratio in items:
        assert prob>=0 and ratio>0
        if ratio!=1 and prob:
            grouped[ratio]+=prob
    result=arsum(ar(w)*ar(r).log() for r,w in sorted(grouped.items()))
    return result,len(grouped)


def schur_kernel(marg,atoms,Ts,Us):
    nt=len(Ts)
    BT=[F(x['bin']) for x in Ts]
    BU=[F(x['bin']) for x in Us]
    jT=[F(x['j'])/F(x['true_m']) for x in Ts]
    jU=[F(x['j'])/F(x['true_m']) for x in Us]
    p=defaultdict(F)
    for (t,u,z),w in marg.items():
        p[z,BT[t],BU[u]]+=w
    mk=project_two(p,(0,1)); ml=project_two(p,(0,2)); mz=project_two(p,(0,))
    FP={}
    for z in atoms:
        FT=defaultdict(F)
        FU=defaultdict(F)
        for i,b in enumerate(jT):
            if in_mask(z,i): FT[BT[i]]+=b
        for i,b in enumerate(jU):
            if in_mask(z,nt+i): FU[BU[i]]+=b
        FP[z]=FT,FU
    weights={}
    bin_atom=defaultdict(list)
    for (z,k,l),v in p.items():
        a,b=mk[z,k],ml[z,l]
        FT,FU=FP[z]
        prob_z=mz[z,]
        sc=v*v/(a*b)
        assert 0<sc<=1 and FT[k]*FU[l]>0
        weights[z,k,l]=ar(sc/(FT[k]*FU[l])).sqrt()
        bin_atom[z].append(dict(middle_bin=k,small_bin=l,p_kl=v/prob_z,p_k=a/prob_z,p_l=b/prob_z,
                                F_middle=FT[k],F_small=FU[l],S_squared=sc))
    for z,values in bin_atom.items():
        FT,FU=FP[z]
        for k in {v['middle_bin'] for v in values}:
            left=arsum(ar(v['F_small'])*weights[z,k,v['small_bin']]*ar(v['p_l']/v['F_small']).sqrt()
                       for v in values if v['middle_bin']==k)
            want=ar(mk[z,k]/(mz[z,]*FT[k])).sqrt()
            assert (left-want).contains(0)
        for l in {v['small_bin'] for v in values}:
            left=arsum(ar(v['F_middle'])*weights[z,v['middle_bin'],l]*ar(v['p_k']/v['F_middle']).sqrt()
                       for v in values if v['small_bin']==l)
            want=ar(ml[z,l]/(mz[z,]*FU[l])).sqrt()
            assert (left-want).contains(0)
    mother=total(marg.values())
    H1,_=weighted_logs((v/mother,ml[z,l]/v) for (z,k,l),v in p.items())
    H2,_=weighted_logs((v/mother,mk[z,k]/v) for (z,k,l),v in p.items())
    return weights,bin_atom,(H1,H2),FP


def schur_value(stage,raw,geo,rates,atoms,first,second):
    T,U=stage['middles'],stage['olds']
    idsT=[F(x['bin']) for x in T]
    idsU=[F(x['bin']) for x in U]
    fminus,fpminus,_,FtFu=first
    fplus,fpplus,_,_=second
    mean_minus={}
    mean_plus={}
    for (t,u),z in geo.items():
        mm,ml=idsT[t],idsU[u]
        mean_minus[t,u]=arsum(ar(p)*fminus.get((c,mm,ml),arb(0)) for c,p in z.items())
        mean_plus[t,u]=arsum(ar(p)*fplus.get((c,mm,ml),arb(0)) for c,p in z.items())
    full_degree={t['t']:F(t['full_original_degree']) for t in stage['tests']}
    numerical=arsum(ar(mass*full_degree[t])*mean_minus[t,u]*mean_plus[t,g] for (t,u,g),mass in raw.items())
    # Cancel the true d_t in the original Gamma in an independently weighted order.
    factorized=arsum(ar(F(T[t]['j'])*rates[t,u]*rates[t,g])*v*mean_plus[t,g]
                    for (t,u),v in mean_minus.items() for g in range(len(U)) if (t,u,g) in raw)
    assert (numerical-factorized).contains(0)
    S=total(F(x['j']) for x in U)
    ratio=numerical/ar(S)
    assert 0<ratio<1
    # Independently apply lifted Schur at each true source atom, after dropping pair gates.
    Jt=[F(x['j'])/F(x['true_m']) for x in T]
    Ju=[F(x['j'])/F(x['true_m']) for x in U]
    sq=arsum(ar(w)*arsum(ar(Jt[t])*arsum(ar(Ju[u])*fminus.get((z,idsT[t],idsU[u]),arb(0))
             for u in range(len(U)) if in_mask(z,len(T)+u))**2 for t in range(len(T)) if in_mask(z,t))
             for z,w in atoms.items())
    assert sq<ar(S) or (sq-ar(S)).contains(0)
    assert numerical<sq or (numerical-sq).contains(0)
    return dict(integral_dv_Wminus_Wplus=enclosure(numerical),denominator_sum_actual_old_j=S,ratio=enclosure(ratio),
        after_degree_cancellation_integral=enclosure(factorized),
        direct_schur_lifted_quadratic_integral=enclosure(sq),direct_schur_integral_ratio=enclosure(sq/ar(S)),
        weighted_site_row_and_column_schur_equalities_checked=True,
        proven_positive_strictly_below_one=True)


def information(raw,geometry,mz,mq,S):
    # Every quantity used before evaluating log is a true absolute rational mass.
    T=project_two(raw,(0,)); TU=project_two(raw,(0,1)); TG=project_two(raw,(0,2))
    TZ=project_two(mz,(0,2)); UZ=project_two(mz,(1,2)); Z=project_two(mz,(2,))
    TQ=project_two(mq,(0,2)); GQ=project_two(mq,(1,2)); Q=project_two(mq,(2,))
    assert total(T.values())==S and total(TZ.values())==S==total(TQ.values())
    cmi,ng=weighted_logs((w/S,w*T[t,]/(TU[t,u]*TG[t,g])) for (t,u,g),w in raw.items())
    ui,nu=weighted_logs((w/S,w*Z[z,]/(TZ[t,z]*UZ[u,z])) for (t,u,z),w in mz.items())
    gi,nv=weighted_logs((w/S,w*Q[z,]/(TQ[t,z]*GQ[g,z])) for (t,g,z),w in mq.items())
    # True five-variable likelihood ratios can reuse exactly identical price-bin factors,
    # separately for each physical t/u. This does not fuse different original points.
    def factorize_atoms(t,u,TP,UP,P):
        classes=defaultdict(F)
        for z,p in geometry[t,u].items():
            ratio=p*T[t,]*P[z,]/(TP[t,z]*UP[u,z])
            classes[ratio]+=p
        assert total(classes.values())==1
        return classes
    fc={key:factorize_atoms(*key,TZ,UZ,Z) for key in TU}
    fd={key:factorize_atoms(*key,TQ,GQ,Q) for key in TG}
    direct_counts=defaultdict(F)
    positive_records=0
    compressed_cross_records=0
    for (t,u,g),m in raw.items():
        positive_records+=len(geometry[t,u])*len(geometry[t,g])
        for (a,w),(b,v) in product(fc[t,u].items(),fd[t,g].items()):
            R=m/T[t,]*a*b
            direct_counts[R]+=m/S*w*v
            compressed_cross_records+=1
    assert total(direct_counts.values())==1
    direct,n0=weighted_logs((w,r) for r,w in direct_counts.items())
    split=cmi+ui+gi
    assert (direct-split).contains(0)
    assert all(x>=arb(0) or x.contains(0) for x in (direct,cmi,ui,gi))
    expected_reference_has_mass_one=total(T[t,]/S*total(v/T[t,] for (k,_),v in TZ.items() if k==t)*
                 total(v/T[t,] for (k,_),v in TQ.items() if k==t) for t, in T)
    assert expected_reference_has_mass_one==1
    assert all(total(v for (u,d),v in UZ.items() if d==z)==w for (z,),w in Z.items())
    assert all(total(v for (u,d),v in GQ.items() if d==z)==w for (z,),w in Q.items())
    cmi_ratios={m*T[t,]/(TU[t,u]*TG[t,g]) for (t,u,g),m in raw.items()}
    return dict(direct_true_five_variable_KL=enclosure(direct),three_conditional_information_sum=enclosure(split),
         arms_conditional_information_given_t=enclosure(cmi),I_u_t_given_z=enclosure(ui),I_g_t_given_q=enclosure(gi),
         exact_arm_CMI_likelihood_ratios=sorted(cmi_ratios),reference_probability_mass=expected_reference_has_mass_one,
         count_of_complete_positive_five_variable_atom_tuples=positive_records,
         aggregated_direct_likelihood_classes_before_final_merge=compressed_cross_records,
         nontrivial_log_ratio_class_counts=[n0,ng,nu,nv],observed_difference_enclosure=enclosure(direct-split))


def example(stage):
    T,U=stage['middles'],stage['olds']
    atoms,witnesses=true_atoms(T+U,F(stage['source_density_amplitude']),stage['n'])
    records=[]
    for law in ('all_two_old_arms','different_size_bins'):
        raw,geo,rates,S=true_arms_and_pairs(stage,law,atoms)
        mz=marginal_side(raw,geo,1)
        mq=marginal_side(raw,geo,2)
        assert total(mz.values())==S==total(mq.values()) and mz==mq
        minus=schur_kernel(mz,atoms,T,U)
        plus=schur_kernel(mq,atoms,T,U)
        entropy=[*minus[2],*plus[2]]
        check=schur_value(stage,raw,geo,rates,atoms,minus,plus)
        kl=information(raw,geo,mz,mq,S)
        if law=='all_two_old_arms': assert kl['exact_arm_CMI_likelihood_ratios']==[1]
        else: assert kl['exact_arm_CMI_likelihood_ratios']==[2]
        records.append(dict(law=law,true_Gamma_mass=S,number_physical_pair_terms=len(raw),
                 true_arm_source_cell_count=len(mz), number_of_old_source_atoms=len(minus[1]),
                 true_one_site_conditional_bin_posteriors=minus[1],weighted_Schur=check,
                 entropies_natural_log=dict(H_K_given_L_and_Z=enclosure(entropy[0]),H_L_given_K_and_Z=enclosure(entropy[1]),
                    H_K_given_J_and_Q=enclosure(entropy[2]),H_J_given_K_and_Q=enclosure(entropy[3]),
                    total_four=enclosure(arsum(entropy))),forward_KL_natural_log=kl))
    return dict(stage=stage['stage'],dimension=stage['n'],positive_mu_membership_atom_count=len(atoms),
         atoms=[dict(mask=i,mu=w,actual_positive_representative_box=witnesses[i]) for i,w in atoms.items()],results=records)


def main():
    here=Path(__file__).resolve().parent
    p=argparse.ArgumentParser(description=__doc__)
    group=p.add_mutually_exclusive_group()
    group.add_argument('--output',type=Path)
    group.add_argument('--check',type=Path)
    args=p.parse_args()
    for name,d in DEPENDENCIES.items():
        assert sha256((here/name).read_bytes()).hexdigest()==d
    ctx.prec=384
    old=json.loads((here/'joint810.json').read_text())['stages']
    rows=[example(s) for s in old]
    out=dict(runtime=dict(python=platform.python_version(),architecture=platform.machine(),flint=flint.__version__,
         Arb_bits=ctx.prec,arithmetic='Fraction exact geometry and Arb outward logarithms/square-roots'),
         reproduction='python -B schur810.py --check schur810.json',dependencies=DEPENDENCIES,stages=rows,
         scope=dict(source='G=A finite model. Every positive source-membership cell is a true measurable portion of mu. Mobius inversion of true cube intersections agrees with an independent full-membership coordinate sweep. Gamma relative to mu is constant on each usable cell.',
             weights='Reconstruct the exact actual atom law as (j_t/d_t)*(b_u*mu(z)/m_t)*(b_g*mu(q)/m_t) on the chosen true old label gate. Condition on actual labels first to integrate the true paired source boxes, keeping the whole original degree. We implement all arms and strictly distinct physical small bins; no redundant owner-half gate.',
             Schur='S_kl uses the true source conditional p(k,l|z). Divide by square root of F^T_k F^U_l, with F sums over all physical parents of the corresponding volume bin. The direct integral cancels d_t exactly, and an independent lifted Schur comparison uses the square of the weighted row sum on each actual cell.',
             entropy='Four exact conditional probability tables and 384-bit logarithms, in nats. The five-variable independent conditional factor is P_t P(z|t) P(q|t) P(u|z) P(g|q). Direct grouped likelihood-ratio KL is checked against I((Z,U);(Q,G)|T)+I(U;T|Z)+I(G;T|Q). The first term reduces to the physical label pair because the two continuous prices are independent given t,u,g on these gates.',
             limit='Three frozen genuinely multibin finite fixtures and stated diagnostic gates. No high-dimensional terminal estimate is inferred.'))
    text=json.dumps(out,sort_keys=True,indent=2,default=str)+'\n'
    if args.output: args.output.write_text(text)
    if args.check: assert args.check.read_text()==text
    if args.output or args.check:
        for s in rows:
            for e in s['results']:
                print(s['stage'],e['law'],s['positive_mu_membership_atom_count'],'Schur',e['weighted_Schur']['ratio']['ball'],
                   'entropy',e['entropies_natural_log']['total_four']['ball'],
                   'KL',e['forward_KL_natural_log']['direct_true_five_variable_KL']['ball'])
        if args.check: print('byte-identical')
    else:
        print(text,end='')


if __name__=='__main__':
    main()
