#!/usr/bin/env python3
"""Replay the four centered-cube round 810 calculations and verify their SHA-256s."""
import argparse
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys


def checked(data, expected, name):
    actual = sha256(data).hexdigest()
    if actual != expected:
        raise ValueError(f"{name}: expected {expected}, got {actual}")
    return data


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--work", type=Path, required=True, help="fresh output directory")
    args = parser.parse_args()
    here = Path(__file__).resolve().parent
    manifest = json.loads((here / "MANIFEST.json").read_text())
    members = {name:checked((here/name).read_bytes(), expected, name)
               for name, expected in manifest["members"].items()}
    work = args.work.resolve()
    work.mkdir(parents=True, exist_ok=False)
    for name, blob in members.items():
        if name.endswith(".py") and name != "replay810.py":
            (work/name).write_bytes(blob)
    scripts = [
        ("joint810", []),
        ("schur810", []),
        ("menus810", ["--data", "joint810.json"]),
        ("common810", ["--data", "joint810.json"]),
    ]
    for stem, extra in scripts:
        filename = stem + ".json"
        subprocess.run([sys.executable, "-B", stem+".py", *extra, "--output", filename],
                       cwd=work, check=True)
        expected = manifest["results"][filename]
        checked((work / filename).read_bytes(), expected, filename)
        print("SHA256", expected, filename, flush=True)
    print("Verified four outputs against the recorded computing environment.")


if __name__ == "__main__":
    main()
