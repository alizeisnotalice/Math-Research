#!/usr/bin/env python3
"""Exact marked-arm masses and conditional section tests on the joint810 fixtures."""
import argparse
from fractions import Fraction as F
from itertools import product
import json
from pathlib import Path
import platform

from flint import arb, ctx
import flint
import joint810 as base

ctx.prec = 384
RANGES = tuple(map(F, ("1/16", "1/8", "1/4", "1/2", "1")))
GATES = ("all_two_old_arms", "different_size_bins", "different_size_bins_and_same_owner_half")


def ball(value):
    q = F(value)
    return arb(q.numerator) / arb(q.denominator)


def as_ball(value):
    return {"interval": str(value), "midpoint_12": format(float(value.mid()), ".12g")}


def membership_cells(box, middles, mu):
    """Measure of each exact middle-membership pattern inside one actual small parent."""
    count = len(middles)
    intersections = []
    for mask in range(1 << count):
        pocket = box
        for index, parent in enumerate(middles):
            if mask & (1 << index):
                pocket = base.clip(pocket, parent["physical_A"])
        intersections.append(mu(pocket))
    atoms = intersections.copy()
    for index in range(count):
        for mask in range(1 << count):
            if not mask & (1 << index):
                atoms[mask] -= atoms[mask | (1 << index)]
    assert min(atoms) >= 0
    for mask, measured in enumerate(intersections):
        assert sum(v for s, v in enumerate(atoms) if s & mask == mask) == measured
    return {s: v for s, v in enumerate(atoms) if v}


def run_gate(case, certificates, cells, gate):
    T, U = case["middles"], case["olds"]
    Y = sum(i["j"] for i in U)
    full = {}
    legs = {}
    accept = {}
    used_by = {i: set() for i in range(len(U))}
    cross = gate != GATES[0]
    fraction = F(1, 2) if gate == GATES[2] else F(1)
    for row in certificates:
        t = row["t"]
        full[t] = F(row["full_original_degree"])
        legs[t] = {e["g"]: F(e["raw"]) for e in row["true_arms"]}
        legal = [(u, g) for u, g in product(legs[t], repeat=2)
                 if not cross or U[u]["bin"] != U[g]["bin"]]
        accept[t] = legal
        for u, g in legal:
            used_by[u].add(t)
            used_by[g].add(t)

    B = [t["j"] / t["true_m"] for t in T]
    outer = {}
    for u, masks in enumerate(cells):
        for mask in masks:
            outer[u, mask] = sum(B[t] for t in used_by[u] if mask & (1 << t))

    mother = F(0)
    atoms = []
    from_rows = arb(0)
    separate_rows = arb(0)
    for t, t0 in enumerate(T):
        triples = accept[t]
        if not triples:
            continue
        degree = full[t]
        m = t0["true_m"]
        available = sum(legs[t].values())
        sections = {u: fraction * sum(legs[t][g] for i, g in triples if i == u)
                    for u in legs[t]}
        arm_masses, arm_means = {}, {}
        for u in {i for pair in triples for i in pair}:
            density = (U[u]["j"] / U[u]["true_m"]) / m
            arm_masses[u] = [(mask, density * mass) for mask, mass in cells[u].items()
                             if mask & (1 << t)]
            assert sum(v for mask, v in arm_masses[u]) == legs[t][u]
            arm_means[u] = sum((ball(v) / ball(outer[u, mask]).sqrt()
                                for mask, v in arm_masses[u]), arb(0))
        actual_edges = {}
        for u, g in triples:
            total = F(0)
            for (z, down), (q, up) in product(arm_masses[u], arm_masses[g]):
                weight = t0["j"] * fraction * down * up / degree
                total += weight
                projection = outer[u, z] * outer[g, q]
                # The compared scores are d_t times all three normalized tests.
                joint_score_sq = degree**2 / (projection * sections[u] * sections[g])
                product_score_sq = degree**2 / (projection * available**2)
                assert joint_score_sq >= product_score_sq
                atoms.append((weight, joint_score_sq, product_score_sq))
            actual_edges[g, u] = total
            mother += total
            coefficient = ball(t0["j"] * fraction) * arm_means[u] * arm_means[g]
            from_rows += coefficient / ball(sections[u] * sections[g]).sqrt()
            separate_rows += coefficient / ball(available)
        saved = next(law for law in certificates[t]["actual_joint_laws"] if law["law"] == gate)
        assert actual_edges == {(e["q_g"], e["z_u"]): F(e["actual_mass"])
                                for e in saved["original_label_edge_masses"]}
        assert sum(actual_edges.values()) == F(saved["original_joint_mother"])

    assert mother == sum(a for a, _, _ in atoms) > 0
    point_mean = sum((ball(w) * ball(v).sqrt() for w, v, _ in atoms), arb(0))
    sep_mean = sum((ball(w) * ball(a).sqrt() for w, _, a in atoms), arb(0))
    assert from_rows.overlaps(point_mean) and separate_rows.overlaps(sep_mean)
    joint_ratio, product_ratio = point_mean / ball(Y), sep_mean / ball(Y)
    assert joint_ratio > 0 and joint_ratio <= 1 and product_ratio > 0
    if cross:
        assert joint_ratio > product_ratio
    else:
        assert joint_ratio.overlaps(product_ratio)
    levels = []
    for threshold in RANGES:
        cutoff = (threshold * Y / mother)**2
        joint_hit = sum(w for w, a, _ in atoms if a >= cutoff) / mother
        separate_hit = sum(w for w, _, a in atoms if a >= cutoff) / mother
        assert F(0) <= separate_hit <= joint_hit <= 1
        levels.append(dict(threshold=str(threshold),joint=str(joint_hit),separate=str(separate_hit)))
    return dict(gate=gate,mother=str(mother),small_receiver_mass=str(Y),positive_summands=len(atoms),
                positive_small_parent_cells=[len(c) for c in cells],joint_over_owner=as_ball(joint_ratio),
                separate_over_owner=as_ball(product_ratio),joint_to_separate=as_ball(joint_ratio/product_ratio),
                diagnostic_hit_fractions=levels)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", type=Path, required=True)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--check", type=Path)
    args = parser.parse_args()
    original = json.loads(args.data.read_text())["stages"]
    stages = []
    for fixture, passed in zip(base.FIXTURES, original, strict=True):
        name, n, amplitude, mids, olds = fixture
        mu = lambda b, **kw: base.mass(b, amplitude, **kw)
        middle = base.parents(n, mids, base.MIDDLE_SHARES, mu)
        old = base.parents(n, olds, base.SMALL_SHARES, mu)
        cells = [membership_cells(p["physical_A"], middle, mu) for p in old]
        case = dict(middles=middle, olds=old)
        calculations = [run_gate(case, passed["tests"], cells, gate) for gate in GATES]
        a, b = calculations[1:]
        assert F(a["mother"]) == 2 * F(b["mother"])
        assert a["joint_over_owner"]["midpoint_12"] == b["joint_over_owner"]["midpoint_12"]
        stages.append(dict(name=name,n=n,calculations=calculations))
    result=dict(python=platform.python_version(),arch=platform.machine(),flint=flint.__version__,
                arb_bits=ctx.prec,score="R/Y_old times d_t/sqrt(C_old C_other a_other a_old)",
                gate_reference="The unconditional comparison preserves both outer tests and uses all actual smaller arms at t for the two remaining row sizes.",
                exact="True atom weights, section sizes, label projections and level hits are fractions. All square roots and score sums use 384-bit Arb; disjoint certified comparisons are required.",
                limits="Diagnostic finite gates, actual cubical receivers, absolutely continuous striped source; high-dimensional stopping, hard intersection, long jumps and L<d_v are not imposed.",
                stages=stages)
    out=json.dumps(result,sort_keys=True,indent=2)+"\n"
    if args.output:
        args.output.write_text(out)
    if args.check:
        assert args.check.read_text()==out
    for s in stages:
        print(s["n"],[(g["gate"],g["joint_over_owner"]["midpoint_12"],g["separate_over_owner"]["midpoint_12"]) for g in s["calculations"]])
    print("all nine two-order Arb and rational marginal checks passed")


if __name__ == "__main__":
    main()
