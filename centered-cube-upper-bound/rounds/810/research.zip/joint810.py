#!/usr/bin/env python3
"""Exact multibin two-source capacity on actual weighted cube branches."""
import argparse
from collections import defaultdict
from fractions import Fraction as F
from itertools import combinations, product
import json
from pathlib import Path
import platform


SUPPORT=F(8)
PERIOD=F(1,2)
QUARTER=F(1,4)
MIDDLE_SHARES=tuple(map(F,(1,'3/4','5/8','7/8')))
SMALL_SHARES=tuple(map(F,(1,'7/8','3/4','5/8','1/2','3/8')))

# First two fixtures are given by first coordinates. The last shifts other coordinates.
FIXTURES=(
    ('sanity',2,F(1,4),[(('0',0),'13/8'),(('-3/2',0),'5/4')],
       [((-2,0),1),((2,0),'3/2')]),
    ('wide_reuse',3,F(1,2),[((0,0,0),'3/2'),(('3/4',0,0),'7/4'),(('-3/4',0,0),'27/16')],
       [(('-7/4',0,0),1),(('7/4',0,0),'11/8'),(('-9/4',0,0),'17/16'),(('9/4',0,0),'23/16')]),
    ('off_axis',4,F(3,4),[((0,0,0,0),'3/2'),(('1/2','1/4',0,0),'7/4'),
          (('-1/2','-1/4',0,'1/4'),'27/16'),(('1/4','-1/2','1/4',0),'13/8')],
       [(('-7/4','1/4',0,0),1),(('7/4','-1/4',0,0),'5/4'),(('-9/4','-1/4','1/4',0),'17/16'),
        (('9/4','1/4','-1/4',0),'11/8'),((-2,'1/2',0,'-1/4'),'33/32'),((2,'-1/2',0,'1/4'),'21/16')]),
)


def total(x):
    return sum(x,F(0))


def cube(center,s):
    return tuple((v-s,v+s) for v in center)


def clip(x,y):
    return tuple((max(a,c),min(b,d)) for (a,b),(c,d) in zip(x,y))


def volume(B):
    out=F(1)
    for a,b in B:
        out*=max(F(0),b-a)
    return out


def phase_primitive(x):
    z=x%PERIOD
    return min(z,PERIOD-z)


def mass(B,amp,by_quarters=False):
    C=clip(B,((-SUPPORT,SUPPORT),)*len(B))
    if not volume(C):
        return F(0)
    a,b=C[0]
    if by_quarters:
        lo=a//QUARTER
        hi=-(-b//QUARTER)
        x=total((1+amp*(-1)**(k%2))*(min(b,QUARTER*(k+1))-max(a,QUARTER*k)) for k in range(lo,hi))
    else:
        x=b-a+amp*(phase_primitive(b)-phase_primitive(a))
    return x*volume(C[1:])


def split_first(B):
    a,b=B[0]
    c=(a+b)/2
    return (((a,c),)+B[1:],((c,b),)+B[1:])


def lower_bin(m):
    D=F(1)
    while D>m: D/=2
    while 2*D<=m: D*=2
    return D


def parents(n,specs,shares,mu):
    out=[]
    for (cc,rad),share in zip(specs,shares):
        y=tuple(map(F,cc))
        s=F(rad)
        A=cube(y,s)
        E=cube(y,s/(32*n))
        assert (4*y[0]).denominator==1 and 1<=s<2
        m=volume(A)
        assert m==mu(A)==mu(A,by_quarters=True)
        v=volume(E)
        out.append(dict(center=y,radius=s,physical_A=A,true_m=m,bin=lower_bin(m),
             physical_E=E,true_receiver_volume=v,j=share*v,share=share))
    return out


def one_source(H,B,demand,mu):
    groups=defaultdict(list)
    for g in sorted(demand):
        assert demand[g]>0
        groups[B[g]].append(g)
    chosen=[]
    for bin_id,labels in sorted(groups.items()):
        g=max(labels,key=lambda g:(demand[g],-g))
        depot=H[labels[0]]
        for u in labels[1:]: depot=clip(depot,H[u])
        assert mu(depot)>0
        chosen.append(dict(bin=bin_id,labels=labels,common_source_box=depot,mu_common=mu(depot),
                           deposit=demand[g],unit_dual_label=g))
    for a,b in combinations(sorted(demand),2):
        if B[a]!=B[b]: assert mu(clip(H[a],H[b]))==0
    primal={g:total(x['deposit'] for x in chosen if mu(clip(H[g],x['common_source_box']))==x['mu_common'])
            for g in demand}
    assert all(primal[g]>=w for g,w in demand.items())
    c=total(x['deposit'] for x in chosen)
    assert c==total(demand[x['unit_dual_label']] for x in chosen)
    return dict(capacity=c,exact_primal_and_dual=chosen,delivered_by_optimal_cover=primal)


def two_source(H,B,demand,mu):
    groups=defaultdict(list)
    for (g,u),w in sorted(demand.items()):
        assert w>0
        groups[B[g],B[u]].append((g,u))
    chosen=[]
    for bins,labels in sorted(groups.items()):
        e=max(labels,key=lambda e:(demand[e],-e[0],-e[1]))
        q,z=map(lambda i:H[i],labels[0])
        for g,u in labels[1:]:
            q,z=clip(q,H[g]),clip(z,H[u])
        assert mu(q)*mu(z)>0
        assert all(mu(clip(q,H[g]))*mu(clip(z,H[u]))==mu(q)*mu(z) for g,u in labels)
        chosen.append(dict(bins=bins,labels=labels,q_source_box=q,z_source_box=z,mu_joint=mu(q)*mu(z),
                           deposit=demand[e],unit_dual_label=e))
    for a,b in combinations(chosen,2):
        g,u=a['unit_dual_label']; h,v=b['unit_dual_label']
        assert mu(clip(H[g],H[h]))*mu(clip(H[u],H[v]))==0
    c=total(x['deposit'] for x in chosen)
    assert c==total(demand[tuple(x['unit_dual_label'])] for x in chosen)
    return dict(capacity=c,exact_primal_and_dual=chosen)


def at_middle(t,T,U,mu):
    t0=T[t]
    A=t0['physical_A']
    m=t0['true_m']
    self_w=t0['j']
    K={}
    d=F(0)
    all_terms=[]
    for role,fam in [('middle',T),('small',U)]:
        for i,v in enumerate(fam):
            if role=='middle' and i==t: continue
            form=clip(A,v['physical_A'])
            overlap=mu(form)
            assert overlap==mu(form,by_quarters=True)
            if not overlap: continue
            k=overlap/(m*v['true_m'])
            term=v['j']*k
            active=role=='small' and v['radius']<t0['radius']
            d+=term
            all_terms.append(dict(role=role,index=i,true_intersection=overlap,K=k,degree_contribution=term,
                                  included_as_downward_old_arm=active))
            if active:
                K[i]=(form,overlap,term)
    d_down=total(r for _,_,r in K.values())
    assert 0<d_down<=d
    ids=sorted(K)
    J={g:K[g][1] for g in ids}
    r={g:K[g][2] for g in ids}
    H={g:K[g][0] for g in ids}
    B={g:U[g]['bin'] for g in ids}
    price_side={g:-1 if H[g][0][1]<0 else 1 for g in ids}
    assert all(H[g][0][1]<0 or H[g][0][0]>0 for g in ids)
    assert all((B[g]!=B[u])==(price_side[g]!=price_side[u]) for g,u in product(ids,repeat=2))
    C0=one_source(H,B,J,mu)
    C1=one_source(H,B,r,mu)
    raw_scale=self_w/d
    true_arms={}
    for g in ids:
        sectors=[]
        for (q,Q),(w,W) in product(enumerate(split_first(H[g])),enumerate(split_first(U[g]['physical_E']))):
            price_mu=mu(Q)
            owner_vol=volume(W)
            raw=r[g]*price_mu/J[g]*owner_vol/U[g]['true_receiver_volume']
            assert raw==U[g]['j']/U[g]['true_receiver_volume']*price_mu*owner_vol/(m*U[g]['true_m'])>0
            sectors.append(dict(q_half=q,W_half=w,actual_price=Q,actual_owner=W,price_mu=price_mu,owner_volume=owner_vol,
                                raw_leg_mass=raw))
        assert total(s['raw_leg_mass'] for s in sectors)==r[g]
        true_arms[g]=sectors
    laws=[]
    for name in ('all_two_old_arms','different_size_bins','different_size_bins_and_same_owner_half'):
        if name!='all_two_old_arms' and len(set(B.values()))<2:
            continue
        edge_mass=defaultdict(F)
        W_marg=defaultdict(F)
        signatures=0
        for g,u in product(ids,repeat=2):
            cross=B[g]!=B[u]
            if name!='all_two_old_arms' and not cross:
                continue
            for Q,Z in product(true_arms[g],true_arms[u]):
                q_side=-1 if Q['actual_price'][0][1]<0 else 1
                z_side=-1 if Z['actual_price'][0][1]<0 else 1
                assert (q_side!=z_side)==cross
                w,k=Q['W_half'],Z['W_half']
                if name.endswith('same_owner_half') and w!=k: continue
                e=raw_scale*Q['raw_leg_mass']*Z['raw_leg_mass']
                signatures+=1
                edge_mass[g,u]+=e
                W_marg[g,w]+=e
            fraction=F(1,2) if name.endswith('same_owner_half') else F(1)
            assert edge_mass[g,u]==raw_scale*fraction*r[g]*r[u]
        upper_geom=C0['capacity']**2
        G=two_source(H,B,{(g,u):J[g]*J[u] for g,u in edge_mass},mu)
        W=two_source(H,B,edge_mass,mu)
        envelope=raw_scale*fraction*C1['capacity']**2
        assert G['capacity']<=upper_geom and W['capacity']<=envelope
        S=total(edge_mass.values())
        left,right=defaultdict(F),defaultdict(F)
        for (g,u),w in edge_mass.items():
            left[g]+=w
            right[u]+=w
        assert left==right and total(left.values())==total(W_marg.values())==S>0
        if name=='all_two_old_arms':
            assert S==self_w*d_down**2/d
            assert G['capacity']==upper_geom and W['capacity']==envelope
        else:
            assert G['capacity']<upper_geom and W['capacity']<envelope
        qcov=one_source(H,B,left,mu)
        zcov=one_source(H,B,right,mu)
        product_reference=qcov['capacity']*zcov['capacity']/S
        ratios=[]
        for (g,u),request in sorted(edge_mass.items()):
            product_transported=qcov['delivered_by_optimal_cover'][g]*zcov['delivered_by_optimal_cover'][u]/S
            ratio=request/product_transported
            ratios.append((ratio,g,u,request,product_transported))
            if name=='all_two_old_arms': assert ratio<=1
        worst=max(ratios)
        if name!='all_two_old_arms':
            # In an active cross block, both maximum-marginal arms must be saturated by every optimal one-source cover.
            assert worst[0]==2
        selected_q={p['unit_dual_label'] for p in qcov['exact_primal_and_dual']}
        selected_z={p['unit_dual_label'] for p in zcov['exact_primal_and_dual']}
        true_both=total(w for (g,u),w in edge_mass.items() if g in selected_q and u in selected_z)/S
        independently=total(left[g] for g in selected_q)*total(right[u] for u in selected_z)/S**2
        low=min(B.values()); high=max(B.values())
        low_then_high=None
        if low!=high:
            joint=total(w for (g,u),w in edge_mass.items() if B[g]==low and B[u]==high)/S
            alone=total(w for g,w in left.items() if B[g]==low)*total(w for u,w in right.items() if B[u]==high)/S**2
            low_then_high=dict(low=low,high=high,actual_joint_probability=joint,independent_marginal_product=alone)
            if name!='all_two_old_arms': assert joint==F(1,2) and alone==F(1,4)
        invalid=[(g['unit_dual_label'],u['unit_dual_label']) for g,u in product(C0['exact_primal_and_dual'],repeat=2)
                 if (g['unit_dual_label'],u['unit_dual_label']) not in edge_mass]
        laws.append(dict(law=name,actual_continuous_record_atom_count=signatures,original_joint_mother=S,
             original_label_edge_masses=[dict(q_g=g,z_u=u,actual_mass=w) for (g,u),w in sorted(edge_mass.items())],
             actual_q_owner_half_projection=[dict(g=g,half=w,mass=v) for (g,w),v in sorted(W_marg.items())],
             geometric_joint=G,geometric_separate_product=upper_geom,original_weight_joint=W,
             original_weight_separate_raw_product=envelope,
             actual_one_arm_marginal_cover=qcov,product_of_actual_marginal_capacities_divided_by_mother=product_reference,
             worst_product_of_optimal_marginal_covers=dict(true_over_product=worst[0],q_g=worst[1],z_u=worst[2],demand=worst[3],delivery=worst[4]),
             independent_product_of_separate_unit_dual_uses_absent_labels=invalid,
             selected_optimal_marginal_dual_labels_both_actual_probability=true_both,
             selected_optimal_marginal_dual_labels_both_independent_probability=independently,
             actual_cross_bin_direction_vs_independence=low_then_high))
    return dict(t=t,middle_bin=t0['bin'],full_original_degree=d,original_old_degree=d_down,
                full_degree_candidate_terms=all_terms,smaller_old_bins=sorted(set(B.values())),
                true_arms=[dict(g=g,source_box=H[g],j_mu=J[g],small_bin=B[g],physical_price_side=price_side[g],raw=r[g],sectors=true_arms[g]) for g in ids],
                geometric_single_source=C0,original_raw_leg_single_source=C1,actual_joint_laws=laws)


def example(name,n,amp,ts,gs):
    mu=lambda B,**kw:mass(B,amp,**kw)
    T=parents(n,ts,MIDDLE_SHARES,mu)
    U=parents(n,gs,SMALL_SHARES,mu)
    P=T+U
    assert all(volume(clip(a['physical_E'],b['physical_E']))==0 for a,b in combinations(P,2))
    assert len({u['bin'] for u in U})>=2 and len({t['bin'] for t in T})>=2
    tests=[at_middle(t,T,U,mu) for t in range(len(T))]
    assert any(len(d['smaller_old_bins'])>=2 for d in tests)
    linked=defaultdict(lambda:defaultdict(F))
    for t in tests:
        for law in t['actual_joint_laws']:
            for w in law['actual_q_owner_half_projection']:
                linked[w['g'],w['half'],law['law']][t['middle_bin']]+=w['mass']
    return dict(stage=name,n=n,source_density_amplitude=amp,old_bins=sorted({g['bin'] for g in U}),
         middle_bins=sorted({t['bin'] for t in T}),middles=T,olds=U,tests=tests,
         actual_same_receiver_half_reused_by_middle_bins=[dict(g=g,half=s,law=law,by_middle_bin=sorted(b.items()))
                        for (g,s,law),b in sorted(linked.items()) if len(b)>1])


def main():
    p=argparse.ArgumentParser(description=__doc__)
    out=p.add_mutually_exclusive_group()
    out.add_argument('--output',type=Path)
    out.add_argument('--check',type=Path)
    args=p.parse_args()
    results=[example(*f) for f in FIXTURES]
    assert any(t['actual_same_receiver_half_reused_by_middle_bins'] for t in results)
    payload=dict(runtime=dict(python=platform.python_version(),architecture=platform.machine(),arithmetic='Fraction exact'),
       reproduction='python -B joint810.py --check joint810.json',stages=results,
       scope=dict(physical='All radii in [1,2), true physical cubes, calibrated positive piecewise source density on [-8,8]^n, uniform in later coordinates. Actual disjoint receiver cubes within s/(32n). Small D and middle M are true dyadic left-volume endpoints.',
          original='The central full degree contains every other positively intersecting true candidate parent, including other middles. True designated q and z separately have mu on the respective full intersection, preserving both receiving half-cubes. All record-atom weights reproduce independent geometric integration.',
          covers='Each middle is fixed. H_tg is the real physical intersection. Within an actual small volume bin the source pockets share a positive anchor box. Different bins have disjoint true pockets. Each single or joint block cover deposits its largest demand on a genuine common atom. A disjoint maximal-demand row gives the exact dual. Two-source demands are given on real ordered rectangles in mu tensor mu.',
          gates='All old arms, a declared gate that the old physical volume bins differ, and that same gate plus equal first-coordinate owner halves. In each actual fixture the different-bin gate is exactly the geometric requirement that q and z lie on opposite sides of x_1=0. The last two are diagnostic conditions on true records. No artificial source or owner atoms.',
          decision='Product of raw one-source covers is a valid upper for the restricted rectangle demand. The product dual can require missing labels. Product of own conditional marginal covers need not satisfy the actual gated joint demands, even with an exact one-source optimum for both arms. The supported original pair distribution determines mass. Each optimal single-marginal source measure saturates the largest request in every disjoint bin, so the sharp cross-bin shortfall at the two maximal arms applies to any tensor product of such optimal covers.',
          limit='These are true numerical finite models, not a test of the original asymptotic high-dimensional gate. The recent shared R809 fixtures have distinct radii but only one old volume bin in each dimension; they are not transferred.'))
    text=json.dumps(payload,sort_keys=True,indent=2,default=str)+'\n'
    if args.output: args.output.write_text(text)
    if args.check: assert args.check.read_text()==text
    if args.output or args.check:
        for s in results:
            e=next(t for t in s['tests'] if len(t['smaller_old_bins'])>1)
            print(s['stage'],'D/M',s['old_bins'],s['middle_bins'],'t',e['t'],'full vs cross geometric capacities',
               *(r['geometric_joint']['capacity'] for r in e['actual_joint_laws'][:2]),'true/raw ratio',
               e['actual_joint_laws'][1]['worst_product_of_optimal_marginal_covers']['true_over_product'])
        if args.check: print('byte-identical')
    else:
        print(text,end='')


if __name__=='__main__':
    main()
