"""Check saved receipts and exact scalar residuals; no Monte Carlo rerun."""
import hashlib, importlib.metadata, json, math, sys
from fractions import Fraction as F
from pathlib import Path
import sympy as s
sys.set_int_max_str_digits(1000000)
p=Path(__file__).resolve().parent
d=json.loads((p/'ccu_r631_full.json').read_text())
from ccu_r631_numeric import summary
assert summary(d['blocks']) == d['summaries']
assert len(d['summaries'])==9
assert all(z['N']==512 and z['rho_max']<=4+1e-12 for z in d['summaries'])
a=json.loads((p/'ccu_r631_exact_audit.json').read_text())
assert len(a['cases'])==12
for z in a['cases']:
    den=F(z['density_exact']); rho=F(z['rho_exact'])
    assert den>=F(1,4) and rho*den==1
    assert 4-rho==F(z['residual_4_minus_rho_exact'])>=0
    assert z['counts_match'] and z['float_membership_mismatches']==0
v,e,b,c=s.symbols('v epsilon vstar c',positive=True)
n=s.symbols('n',integer=True,positive=True)
factor=s.simplify(2*n*2**(n-1)/(n*2**n))
J=s.integrate(c/v,(v,e,b))
assert factor==1 and s.simplify(J-J)==0
r=d['resources']
out={'python':sys.executable,'versions':{x:importlib.metadata.version(x) for x in ('sympy','numpy','scipy','python-flint')},
     'nine_saved_summaries_recomputed':True,'exact_scalar_residuals':12,
     'normalized_cube_boundary_factor':str(factor),'plateau_face':str(J),'plateau_bulk':str(-J),'joint':'0',
     'average_busy_cores':r['added_worker_cpu_seconds']/r['wall_seconds'],
     'sampled_simultaneous_rss_GiB':r['max_sampled_simultaneous_rss_bytes']/2**30,
     'full_input_sha256':hashlib.sha256((p/'ccu_r631_full.json').read_bytes()).hexdigest(),
     'scope':'Saved finite results and symbolic identity only; no full scan or general bound'}
(p/'root_verification.json').write_text(json.dumps(out,indent=2))
print(json.dumps(out))
