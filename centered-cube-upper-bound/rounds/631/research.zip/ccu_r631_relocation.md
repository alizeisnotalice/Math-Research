# R631：共同 future parent 的真实 charge relocation 与未付 incoming

## 1. 准确合同与本轮判断

沿用 `/tmp/ccu_r630_radius_geometry.md` 的已证联合trace。先在其smooth compact输入、K⊂E1、I=[b0,b1]⊂(τ,1)、τ=3/4的范围工作。固定source y、interior u，v=(2r)^n，A(v)=μQ(y−ru,r)，G={A>τv}，B=|G|≤M/τ。T(y,u)是已证的真实outer-level selected集合，contact上A(v)=βv、β∈I、0<β−a0≤b1。写

  H_I=∫_I βdβ，
  T^h(y,u)={v∈T(y,u):B/v>L}，
  q(y,u)=∫_{T^h}(β−a0)dv/v，
  H_L=H_I^(-1)∫dμ(y) E_u q(y,u)。                       (1)

已证 |K|≤(b1/H_I)L M+H_L。本轮构造一次共同future parent及新真实来源，可同时承接每条(y,u)上全部heavy contacts；但未证明跨(y,u)的incoming列容量或receiver收缩。故没有一般根阶付款，不把质量时钟或B/v分割本身当进展。

## 2. 一条ray的全部heavy contacts共用新质量

设T^h非空，定义v_c=sup T^h。A连续，contact的β≤b1，故

  v_c≤B/L， A(v_c)≤b1v_c≤b1B/L。                        (2)

空集合的q=0，不必分配。令P_v=Q(y−r(v)u,r(v))，P_c=P_{v_c}；所有旧contact cubes包含于P_c。

一次共同取W均匀于

  J(y,u)=G∩[B/2,∞)， h_J=|J|≥B/2。                      (3)

L>2时W>v_c。J严格bad，所以A(W)>τW≥τB/2。若L>2b1/τ，真实fresh质量

  F_new(y,u,W)=μ(P_W\P_c)=A(W)−A(v_c)
              >(τ/2−b1/L)B>0。                        (4)

因此可一次取新来源Z，条件分布为μ|_{P_W\P_c}/F_new；同一个future parent及fresh区域服务该(y,u)的全部旧contacts。没有按component、level或旧v重新领取M。与先在完整P_W中按μ取Z相比，旧质量概率≤δ_L=2b1/(τL)，fresh条件化的代价至多

  γ_L=(1−δ_L)^(-1)。                                    (5)

所有选择依赖同一完整μ。A、B、J可测；v_c可在completed source×direction测度下取其普遍可测版本（T的Borel纤维上确界），再改为a.e.可测版本即可积分。端点v_c不必本身是contact；(2)由逼近序列及连续性成立。W∈strict G、P_W\P_c的开边界对L1来源零质量，故(4)没有平台端点遗漏。

## 3. 固定新center和scale的真实incoming

令R=(W)^(1/n)/2、X=y−Ru。以同一W固定y时，准确Jacobian为

  du/2^n=dX/W。

所以重定位到(X,W)的contact收费密度是

  I_L(X,W)=1/(H_I W) ∫_{Q(X,R)}
      f(y) 1_{W∈J(y,u)} q(y,u)/h_J(y,u) dy，
  u=(y−X)/R。                                           (6)

它支持于X∈Eτ={M_cube μ>τ}；∫I_L dX dW=H_L。进一步落到fresh来源z的准确密度（相对dX dW dμ(z)）为

  J_L(X,W,z)=1/(H_I W)∫_{Q(X,R)}
    [f(y)1_{W∈J}q(y,u)/(h_J F_new)]
        1_{z∈Q(X,R)\P_c(y,u)}dy。                       (7)

这是真正需要跨旧receiver重叠一起估计的incoming，不是每ray另作source预算。它对z积分恢复(6)。新source列为C_new(z)=∫J_L(X,W,z)dX dW；只有row归一，没有证明C_new≤常数，也没有证明μ是这个重新分配的平稳测度。不能将该核迭代时每次再领取M。

### 完整方体收缩与fresh条件不能拆开

固定旧v与新(X,W)，置t=(v/W)^(1/n)、a=(y−X)/R。旧receiver和cube准确为

  x=X+(1−t)(y−X)， Q(x,tR)⊂Q(X,R)。                     (8)

固定t时，dy=(1−t)^(-n)dx；原source必须保留为
f(X+(x−X)/(1−t))。不能凭旧receiver位置的(1−t)^n收缩领取均匀体积gain。并且只知t≤t_c=(v_c/W)^(1/n)、t_c^n≤2/L，并不知道全部旧t都贴近t_c；较早contacts仍可能有t很小。

令b=(z−X)/R。共同fresh条件完整地是：至少一个坐标满足

  |b_i−(1−t_c)a_i|≥t_c。                                (9)

若t_c>1/2，它推出某个|b_i|≥2t_c−1，但这只是新来源在真实boundary区域的集中，不授权用该区域体积上界其μ质量。对(6)–(9)的source/receiver投影，目前没有统一多重性估计。以原source当uniform、丢掉(9)，或只取每个face的绝对值，会分别丢掉实际source偏置或receiver交叉结构。

## 4. 弱level递推的完整系数

即使得到某个全局几何估计H_L≤q_*|Eτ|+A_nM，也不能漏掉level降级。设D_n为原cube弱型常数，齐次性给|Eτ|≤D_nM/τ；对全部输入及compact exhaustion取上确界，完整递推为

  D_n≤(b1/H_I)L+A_n+(q_*/τ)D_n。                        (10)

必须q_*<τ，才有严格吸收。若估计是通过以未fresh条件化source核支配(7)而取得系数q_geom，则(5)额外付至多γ_L；取q_*=γ_L q_geom时所需是

  q_geom<τ/γ_L=τ−2b1/L。                               (11)

若直接估计(6)的receiver incoming，fresh归一不会额外改变其总量，可不付γ_L，但仍须q_*<τ。通过上述source domination且q_geom=1时，系数γ_L/τ>4/3；即使不付γ_L，1/τ=4/3也不是收缩。只说“几乎全是新质量”不能改变这一结论；逐级降至E_{τ^k}时重复因子为(q_*/τ)^k，非<1就无可求和terminal。本文没有证明q_geom带有1/L或根阶的几何gain。

## 5. 准确停点

(2)–(4)确实把同一ray全部旧contacts统一转向一份真实fresh区域，避免逐contact独立付新质量；(6)–(9)把跨(y,u)应保留的真实incoming、Jacobian和完整坐标约束写明。尚未付的是该incoming在Eτ及新source列上的共同重叠。质量比例v/W≤2/L本身不等于receiver体积比例；source位置、不同旧v、fresh边界和选中outer trace的相关不能删掉。

本轮未得到H_L≤θ|K|+A_nM或费用根阶的严格递推。一般L1恢复只能在未来uniform完整估计成立后使用，不能把本次转移当新一般定理。没有计算、重扫、agent或repo修改；到此停止。
