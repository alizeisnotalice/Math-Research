"""Frozen R631 proposal, relative density wrt uniform periodic-cell probability.
No source scan runs here. Phase is x/a mod 1, center=(l mod 2)/2 + coset/2.
"""
import os
for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS','NUMEXPR_NUM_THREADS'): os.environ[key]='1'
import json,math,sys,argparse
from pathlib import Path
import numpy as np
from scipy.special import logsumexp
sys.path.insert(0,str(Path(__file__).resolve().parent))
from ccu_r630_importance import halos
from ccu_r630_periodic import params

def distphase(phase,center):return np.abs((phase-center+.5)%1-.5)
def logdensity(x,a,hh,tilts):
 n=len(x);phase=(x/a)%1;logs=[math.log(.25)]
 for j,h in enumerate(hh):
  if np.all(distphase(phase,j/2)<h['h']/a): logs.append(math.log(.125)+n*math.log(a/(2*h['h'])))
 m=len(tilts)
 for t in tilts:
  theta=float(t['theta']);q=float(t['q']); assert 0<theta<1 and 0<q<1
  s=int(np.sum(distphase(phase,((t['l']%2)/2+t['coset']/2)%1)<theta/2))
  logs.append(math.log(.5/m)+s*math.log(q/theta)+(n-s)*math.log((1-q)/(1-theta)))
 return float(logsumexp(logs))

def sample(n,k,tilts,rng):
 _,a,_=params(n,k);hh=halos(n,k,a);z=rng.random()
 if z<.25: x=(rng.random(n)-.5)*a;component='uniform'
 elif z<.5:
  j=0 if z<.375 else 1;h=hh[j]['h'];x=((j*a/2+(2*rng.random(n)-1)*h+a/2)%a)-a/2;component='halo'+str(j)
 else:
  j=min(int((z-.5)*2*len(tilts)),len(tilts)-1);t=tilts[j];theta=float(t['theta']);q=float(t['q']);center=((t['l']%2)/2+t['coset']/2)%1
  high=rng.random(n)<q;u=rng.random(n);offset=np.where(high,(u-.5)*theta,theta/2+u*(1-theta));phase=(center+offset)%1;x=((phase+.5)%1-.5)*a;component='tilt'+str(j)
 logq=logdensity(x,a,hh,tilts);rho=math.exp(-logq); assert rho<=4*(1+1e-12)
 return x,rho,component

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--parameters',type=Path,default=Path(__file__).with_name('ccu_r631_parameters.json'));args=ap.parse_args();data=json.loads(args.parameters.read_text());rng=np.random.default_rng(631333)
 for case in data['cases']:
  n,k=case['n'],case['k']; assert 1<=len(case['tilts'])<=4
  for t in case['tilts']:
   theta=float(t['theta']);q=float(t['q']);assert abs(theta*(q/theta)+(1-theta)*((1-q)/(1-theta))-1)<1e-12
  ws=[sample(n,k,case['tilts'],rng)[1] for _ in range(4)];print(n,k,'m',len(case['tilts']),'rho_max',max(ws),'delta_actual',case['delta_actual_binary64'])
if __name__=='__main__':main()
