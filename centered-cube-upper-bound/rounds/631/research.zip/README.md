# R631 compact reproducibility package

Run `python parity.py` for the single four-point parity check. `ccu_r631_full.py` is the portable continuation entry point; it defaults to the sibling pilot and parameters files and outputs `ccu_r631_full_replay.json`. Re-running it executes the whole continuation, so it was not invoked in verification. The sibling numeric and R630 modules provide the scanner and initial pilot implementation. NumPy and SciPy are required; resource collection uses macOS libproc.

`ccu_r631_full.json` is the original completed computation receipt and compressed sample-level data; its stored original script hashes refer to the actual run, not these modified portable copies. `parity_receipt.json` records both the original data hash and modified code hashes. Original full and pilot data are retained without alteration. Four points in n32, k64, block8 reproduced every saved mathematical field.

The original continuation added 4,320 points in 12.863 seconds, consuming 170.889 worker CPU seconds. Parent plus workers RSS sampled approximately once a second peaked at 872,890,368 bytes; a sampled maximum is not a certified instantaneous peak. The CPU and RSS apply only to the computation phase, not subsequent reporting. Pilot and continuation are independent of R630; R630 had 1,024 samples per case and R631 512. All floating estimates are descriptive and are not a proof.

## Main proof and audit materials

REPORT.tex is the detailed Chinese report; it is not compiled. The two proof notes retain the full transport and signed cancellation ledger. The general root upper bound remains unproved. Independent proof audit is included separately.

Run `python check_results.py` to recompute nine summaries, verify the saved exact scalar residuals and check the symbolic plateau cancellation. It does not rerun Monte Carlo.

For an independent rational point check from the package directory:

```
python ccu_r631_exact_audit.py --parameters ccu_r631_parameters.json --pilot ccu_r631_pilot.json --full ccu_r631_full.json --halo-input halo_input.json --output exact_replay.json
```

`halo_input.json` contains only the required halo contracts from the prior historical input; the original audit receipt identifies the original full input hash. Commands stored in original receipts refer to the original local paths; use the explicit portable arguments above. Prior R630 estimates used for comparison are archived in round 630 and were not recomputed by rerunning the scanner.

Exact certificates apply to the saved binary64 inputs and ideal density values at those points, not to a continuous law for finite pseudorandom arithmetic. CPU utilization refers to the 12.863-second continuation batch, not the full proof/review cycle. No MATLAB or PDF compilation was performed in this round.
