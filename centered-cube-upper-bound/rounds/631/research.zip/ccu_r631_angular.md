# R631：signed angular-flux尝试及小v取消障碍

**结论。** finite-cutoff积分分部成立，但它没有产生可独立付款的root估计。尤其不能丢掉负bulk后只估face−normalizer flux：两者在小v分别对数发散，必须共同重整化。下面仅冻结正确公式、mask恢复范围及首次未付的完整取消问题。

取τ=3/4，I=[13/16,15/16]，`ell=1/8`、`H_I=7/64`。f≥0、C_c∞，φ∈C_c∞(E1)、0≤φ≤1，`Fφ=∫φ dx`。

## 1. receiver与全部future条件保持在同一导数中

令`p(x,r)=μQ(x,r)/V(r)`，`P(x,r)=sup_{s>=r}p(x,s)`。在r远离0的compact区域，p有共同局部Lipschitz界；sup future保留该界，P在r上AC。其r导数在non-record处为0，在下降record处等于p_r，ties/flat点不需假设finite perimeter。

令`Phi(s)=min(ell,max(0,s−13/16))`。固定source y，写`v=(2r)^n`、`x=y−ru`，

`Z=(u/n,−v)`，`dOmega=2^(−n)du dv/v`。

准确有

`Zx=0`，`div_dOmega Z=1`，
`ZPhi(P)=1_{真实outer selected,p∈I}(p−a0)` a.e.       (1)

故原heavy numerator为

`D_L(φ)=∫dμ ∫φ(x)1_{Bτ(y,u)/v>L}ZPhi(P)dOmega`
`       =H_I H_L(φ)`。                              (2)

φ/K沿Z不动，不能分开只对u积分后再忽略receiver边界。β-window与future已经包含在Phi(P)中，未将selected mask改为全U。

## 2. 正则化B下的完整finite-cutoff恒等式

Bτ只有联合可测与0≤Bτ≤M/τ，不预设angular BV。将其在u立方体外延零、作非负angular mollification得B_m。保持0≤B_m≤M/τ，并在L1(μ×du)趋B。令h_ε非减光滑，s≤L时0、s≥L+ε时1，q_m=B_m/v。

取共同cutoff V0,V1：V0足够小时φ支撑上的Phi(P)=ell，故ZPhi=0；V1>M/(τL)使h=0。保持所有项使用**同一个**cutoff，不先删除各自发散部分。

置`D_{m,ε}=∫dμ∫_{U×[V0,V1]}φ h_ε(q_m)ZPhi(P)dOmega`。积分分部准确给

`D_{m,ε}=B0+A_{m,ε}−W_{m,ε}−R_{m,ε}−N_{m,ε}`，    (3)

其中

`0<=B0<=ell M`，
`W=∫φ Phi(P)h_ε(q_m)dμ dOmega>=0`，
`R=∫φ Phi(P)q_m h_ε'(q_m)dμ dOmega>=0`，

`A=(1/n)Σ_{i,σ}∫dμ∫_{u_i=σ}φ Phi(P)h_ε(q_m)`
`                                   ·2^(−n)dS_u dv/v`，

`N=(1/n)∫dμ∫φ Phi(P)h_ε'(q_m)`
`                              ·(u·∇_uB_m)/v dOmega`。

A是cube角向face的正外向flux；N是heavy-normalizer cutoff的angular导数，符号未知。B0是小v边界，大v边界0。式(3)保留了所有mask的费用，无source面密度帽。

## 3. 小v取消：不能把A−N当有限未付项

取真正smooth compact plateau：0≤f≤c，c>1，并在大盒内恒为c；φ在其内部紧盒恒为1。对该紧盒内的source y和足够小r，所有方向的x仍在plateau且

`P(x,r)=c`，`Phi(P)=ell`，`h=1`，`h'=0`。

因此在同一小v区间[V0,v*]，逐y恰有

`A=ell log(v*/V0)`，`W=ell log(v*/V0)`，
`N=R=0`，`selected-window trace=0`。                (4)

在正μ质量的y上积分仍如此。两项分别随V0→0发散，真实trace却为0；必要取消发生在A−W，不在h'项。故虽然固定cutoff下“丢负W”是形式上界，所得face−N上界可成为∞，不能提供维数/输入一致的可付款估计。

必须保留共同cutoff下的`A−W−R−N`（及B0）再取极限。只把A−N称作首个有限angular边界、或宣称常数与V1/V0无关，均不成立。此例只核验IBP拆分，不反驳原heavy目标。

## 4. 原trace恢复与尚未完成的统一估计

固定ε，B_m→B及h_ε连续使D_{m,ε}→D_ε：在finite v窗，selected trace绝对连续于μ×du×dv、密度≤(15/16)/V0。再ε↓0，h_ε(B/v)趋严格heavy指标（等号仍0），DCT恢复D_L。这里恢复的是**完整D**，不声称A、W、R、N分别有极限、finite trace或uniform bound。

小v也须在(3)整体中取极限：D在足够小v为0，B0有≤ell M的界，剩余取消由完整恒等式保留；其单项不允许先估再去cutoff。B_m的derivatives可随m增长，L1误差小不能推出N小。原B也尚未获angular BV或normalizer-boundary符号。

因此未完成的是共同cutoff的boundary/bulk取消能否按同一μ统一估成所需`theta H_I Fφ+H_I A_nM`，而非仅重新表示原heavy trace。若没有这种实际新估计，(3)不降低原H_L的难度。仍未证明`H_L<=theta|K|+A_nM`。

对φ→1_K，R630完整trace给receiver mask误差≤`H_I||φ−1_K||_1`；这不涉及将source image体积当μ质量。已付light费用仍为`(60/7)L M`，小v边界上界仍为`8M/7`，但它们不能替代尚未控制的完整取消。

本机SymPy核验Z、weighted divergence、Z(B/v)及7/64、60/7、8/7系数；没有扫描或重算。此稿只记录正确诊断，不声称root改善。完成待审。
