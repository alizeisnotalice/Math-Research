# R631 冻结tilt proposal独立合同审计

2026-10-28。未读实现/作者结论，未运行MC或新扫描；仅本机SymPy核轴密度积分及混合权和。**合同成立，条件如下。**

1. **高count区间。** 写2R/a=l+θ，0<θ<1。周期相位中轴count为l或l+1；高区间B确以(l mod2)/2为中心、长度θ。偶l在格点附近、奇l在半格点附近；open端点归低count，均为零测。θ=0退化情形须跳过或另定义，不能除θ。冻结实际binary半径/区间作为proposal几何完全合法，不要求它等于旧真实outer root。

2. **密度及抽样。** 每坐标以概率q取uniform B，否则uniform Bᶜ，故相对cell uniform的密度为

   D_b(x)=(q/θ)^s((1−q)/(1−θ))^(n−s)，

   s为该新点落B的坐标数；无binomial系数。轴积分为1，n维积亦为1。s_old∈[0,n]时(s_old+.5)/(n+1)已严格位于(0,1)；若clip仍须保持严格内点。密度必须使用与生成点完全相同的冻结区间、长度、shift及q。

3. **一次混合。** 令A=a_actual^n、V_j为实际halo体积，则完整relative density为

   D(x)=.25+.125 A1_H₀/V₀+.125 A1_H₁/V₁
        +(.5/m_b)Σ_b D_b(x)，ρ=1/D≤4。

   所有重叠分量相加，不能只用实际抽中component的密度。m_b须是实际component数且≥1；空tilt清单须重分配其.5概率。于是P(E)=E_q[ρ1_E]，S_j=AτE_q[ρ1_E N_j/m]，m=N₀+kN₁。proposal坐标独立不使两coset target变成product；halo外multiatom witnesses由uniform正密度保留。使用actual A，名义化另标。

4. **冻结及统计。** 全部尺度、q及component选择只用旧数据并在新run前冻结；旧高影响点无需无偏，因为只用于proposal。条件于该清单，新独立iid mixture样本给无偏importance估计；旧点不能冒充新iid样本。若固定分层配额，SE须按其设计计算。权变量一般非Bernoulli，ρ≤4不认证浮点事件或严格tail。

5. **k=1对称化。** target有S₀=S₁，但未配对的tilts可能使proposal不对称。安全做法是配对target integrand、两视图共用base点同一ρ(x)，于是两列均为Aτ·mean(ρ1_E)/2，无需q对称。不应直接平均含ρ(x)与ρ(x+d)的两个完整importance项，除非q本身在d=(a/2)1平移下不变；或先对proposal随机平移并用其对称混合密度。

新点仍须完整扫描真实E1及outerτ的全部尺度；冻结proposal尺度不截断target菜单。该合同只支持同一周期模型的有效提样，不认证一般receiver下界、重列吸收或维数定理。完成停止。
