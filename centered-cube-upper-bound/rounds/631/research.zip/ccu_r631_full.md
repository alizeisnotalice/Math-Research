# R631 expanded comparison

Old R630: 1024 points; frozen R631: 512 points per case. ESS fractions and top shares are descriptive, not a significance test. Same-point source symmetry applies for k=1; high-dimensional finite estimates have sampling and floating error.

| n | k | S1 ESS old / 1024 | S1 ESS new / 512 | new top 1 / top 4 | new S1 ± SE | ms per point old / new |
|---:|---:|---:|---:|---:|---:|---:|
| 32 | 1 | 61.33 | 73.25 | 0.077 / 0.170 | 1.142 ± 0.124 | 0.51 / 0.56 |
| 32 | 64 | 65.15 | 111.82 | 0.027 / 0.091 | 1.417 ± 0.119 | 0.42 / 0.54 |
| 32 | 4096 | 60.70 | 68.82 | 0.042 / 0.151 | 1.321 ± 0.148 | 0.41 / 0.55 |
| 128 | 1 | 15.98 | 13.59 | 0.241 / 0.422 | 2.62 ± 0.702 | 5.17 / 5.61 |
| 128 | 64 | 18.88 | 20.59 | 0.138 / 0.356 | 4.25 ± 0.918 | 5.20 / 5.56 |
| 128 | 4096 | 22.01 | 17.11 | 0.152 / 0.420 | 4.346 ± 1.03 | 5.17 / 5.55 |
| 512 | 1 | 4.30 | 86.00 | 0.036 / 0.146 | 1.424 ± 0.14 | 109.13 / 112.37 |
| 512 | 64 | 7.17 | 8.21 | 0.267 / 0.602 | 5.383 ± 1.87 | 109.53 / 112.29 |
| 512 | 4096 | 11.04 | 7.98 | 0.193 / 0.641 | 10.92 ± 3.84 | 111.57 / 112.75 |

Top four receiver records and their winner (l, theta), mixture component and high-counts for all four frozen tilt regions are recorded in ccu_r631_full_comparison.json. The new sample still has a uniform component and does not rule out contributions in unsampled areas.

Resources: {'wall_seconds': 12.863238791993354, 'added_worker_cpu_seconds': 170.889081, 'parent_peak_rss_bytes': 65830912, 'max_worker_peak_rss_bytes': 58195968, 'max_sampled_simultaneous_rss_bytes': 872890368, 'workers': 14, 'pending_limit': 56}. Simultaneous RSS sampled once per second is not a rigorous absolute peak; worker cumulative CPU is measured directly. Pending futures at most 56.
