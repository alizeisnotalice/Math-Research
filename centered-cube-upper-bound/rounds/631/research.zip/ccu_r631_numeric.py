import os
for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[key]='1'
import argparse, concurrent.futures, hashlib, json, math, platform, resource, shlex, sys, time
from pathlib import Path
import numpy as np
import ccu_r631_proposal as prop
sys.path.insert(0,str(Path(__file__).resolve().parent))
import ccu_r630_periodic as base

def block(q):
 n,k,b,tilts=q;t=time.monotonic();cpu=time.process_time();_,a,cut=base.params(n,k);seed=631100000+n*100000+k*300+b;rng=np.random.default_rng(seed);rows=[]
 for j in range(4):
  x,rho,component=prop.sample(n,k,tilts,rng);r=base.scan(x,k,a,cut); e=r['status']=='E1';row={'index':4*b+j,'rho':rho,'component':component,'status':r['status'],'events':r['events'],'pi0':r.get('pi0',0.),'pi1':r.get('pi1',0.),'near_equal_events':r.get('near_equal_events',0)}
  if e:row.update({'winner':r['winner'],'x':x.tolist()})
  rows.append(row)
 return {'n':n,'k':k,'block':b,'seed':seed,'records':rows,'cpu_seconds':time.process_time()-cpu,'elapsed_seconds':time.monotonic()-t,'worker_peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}

def summary(blocks):
 out=[]
 for n,k in sorted({(b['n'],b['k']) for b in blocks}):
  bs=[b for b in blocks if (b['n'],b['k'])==(n,k)]; rows=[r for b in bs for r in b['records']];N=len(rows); _,a,_=base.params(n,k); an=a**n;rho=np.array([r['rho'] for r in rows]);E=np.array([r['status']=='E1' for r in rows],float);p0=np.array([r['pi0'] for r in rows]);p1=np.array([r['pi1'] for r in rows]);fac=.75*an
  vals=[rho*E*.5,rho*E*.5] if k==1 else [rho*p0,rho*p1/k]
  def diag(v):
   z=float(v.sum());return {'S':float(fac*v.mean()),'SE':float(fac*v.std(ddof=1)/math.sqrt(N)),'ESS':z*z/float(v@v) if v@v else 0,'top1_share':float(v.max()/z) if z else None,'top4_share':float(np.sort(v)[-4:].sum()/z) if z else None}
  a0,a1=map(diag,vals);W=an/(1+k)*float((rho*E).mean());res=(a0['S']+k*a1['S'])/(1+k)-.75*W
  assert abs(res)<1e-9*max(1,W);out.append({'n':n,'k':k,'N':N,'E_hits':int(E.sum()),'actual_delta':(1+k)/an,'nominal_delta':1/n,'S0':a0,'S1':a1,'W':W,'identity_residual':res,'rho_max':float(rho.max()),'weighted_E_ESS':float((rho*E).sum()**2/((rho*E)@(rho*E))) if np.any(E) else 0.,'cpu_per_point':sum(b['cpu_seconds'] for b in bs)/N,'components':{c:sum(r['component']==c for r in rows) for c in sorted({r['component'] for r in rows})}})
 return out

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--workers',type=int,default=14);ap.add_argument('--parameters',type=Path,default=Path(__file__).with_name('ccu_r631_parameters.json'));ap.add_argument('--output',type=Path,default=Path(__file__).with_name('ccu_r631_pilot.json'));a=ap.parse_args();assert 1<=a.workers<=14;param=json.loads(a.parameters.read_text());tasks=iter((c['n'],c['k'],b,c['tilts']) for c in param['cases'] for b in range(8));pending={};blocks=[];start=time.monotonic()
 with concurrent.futures.ProcessPoolExecutor(max_workers=a.workers) as pool:
  def fill():
   while len(pending)<4*a.workers:
    try:q=next(tasks)
    except StopIteration:break
    pending[pool.submit(block,q)]=1
  fill()
  while pending:
   done,_=concurrent.futures.wait(pending,return_when=concurrent.futures.FIRST_COMPLETED)
   for f in done:pending.pop(f);blocks.append(f.result())
   fill()
 blocks.sort(key=lambda z:(z['n'],z['k'],z['block']));out={'input_sha256':hashlib.sha256(a.parameters.read_bytes()).hexdigest(),'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'proposal_sha256':hashlib.sha256(Path(prop.__file__).read_bytes()).hexdigest(),'base_sha256':hashlib.sha256(Path(base.__file__).read_bytes()).hexdigest(),'command':shlex.join([sys.executable]+sys.argv),'python':sys.version,'numpy':np.__version__,'platform':platform.platform(),'blocks':blocks,'summaries':summary(blocks),'resources':{'wall_seconds':time.monotonic()-start,'worker_cpu_seconds':sum(b['cpu_seconds'] for b in blocks),'max_worker_rss_bytes':max(b['worker_peak_rss_bytes'] for b in blocks),'parent_peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'workers':a.workers,'pending_limit':4*a.workers},'note':'Binary64 finite diagnostics. k1 symmetry uses the same base weight rho(x) times E(x), not a translated density. Independent of R630 sample law.'}
 with a.output.open('w') as f:json.dump(out,f)
 print(json.dumps(out['resources']))
if __name__=='__main__':main()
