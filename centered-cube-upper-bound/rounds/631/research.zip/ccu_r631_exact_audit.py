#!/usr/bin/env python3
"""Exact rational bounded audit of frozen R631 saved binary64 sample points."""
import argparse,json,hashlib,math,sys,time
from fractions import Fraction as F
from pathlib import Path
import numpy as np
sys.set_int_max_str_digits(1000000)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def ceil(q):return -((-q.numerator)//q.denominator)
def audit(case,row,halos,origin,block):
 n,k=case['n'],case['k'];a=F.from_float(case['spacing_binary64']);xx=list(map(F.from_float,row['x']));w=row['winner'];lo=F.from_float(w['left']);hi=F.from_float(w['right']);assert lo<hi;r=(lo+hi)/2
 counts=[]
 for shift in (F(0),a/2):
  c=[ceil((z+r-shift)/a)-((z-r-shift)//a)-1 for z in xx];assert all(v>=0 for v in c);counts.append(math.prod(c))
 N0,N1=counts;m=N0+k*N1;count_ok=all(str(z)==w[t] for t,z in [('N0',N0),('N1',N1),('m',m)])
 phase=[(z/a)%1 for z in xx];h=[F(x['h_exact']) for x in halos];halo=[all(abs((z-shift+a/2)%a-a/2)<h[j] for z in xx) for j,shift in enumerate((F(0),a/2))]
 den=F(1,4)+sum((F(1,8)*(a/(2*h[j]))**n if halo[j] else 0) for j in (0,1)); details=[];mismatch=0
 pf=(np.array(row['x'])/float(a))%1
 for t in case['tilts']:
  theta=F.from_float(t['theta']);q=F.from_float(t['q']);assert 0<theta<1 and 0<q<1
  center=F((t['l']%2+t['coset'])%2,2);bits=[abs((z-center+F(1,2))%1-F(1,2))<theta/2 for z in phase];s=sum(bits)
  floatbits=np.abs((pf-float(center)+.5)%1-.5)<float(theta)/2;mm=sum(bool(b)!=bool(c) for b,c in zip(bits,floatbits));mismatch+=mm
  D=(q/theta)**s*((1-q)/(1-theta))**(n-s);den+=F(1,2*len(case['tilts']))*D
  details.append({'theta_binary64':str(theta),'q_binary64':str(q),'center':str(center),'exact_high_count':s,'float_high_count':int(np.sum(floatbits)),'membership_mismatch_count':mm,'high_indices':[i for i,v in enumerate(bits) if v]})
 rho=1/den;residual=4-rho;assert den>=F(1,4) and residual>=0
 saved_tilts=row.get('tilt_high_counts');return {'origin':origin,'n':n,'k':k,'block':block,'index':row['index'],'component':row['component'],'radius_inside_exact':str(r),'counts_exact':[str(N0),str(N1)],'weighted_count_exact':str(m),'counts_match':count_ok,'halo_memberships':halo,'tilts':details,'saved_tilt_counts_match':None if saved_tilts is None else saved_tilts==[x['exact_high_count'] for x in details], 'float_membership_mismatches':mismatch,'density_exact':str(den),'rho_exact':str(rho),'residual_4_minus_rho_exact':str(residual),'rho_le_4_certified':residual>=0,'saved_rho':row['rho'],'exact_rho_display':float(rho),'rho_abs_difference':abs(float(rho)-row['rho']),'saved_winner':w}

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--parameters',type=Path,default=Path('/tmp/ccu_r631_parameters.json'));ap.add_argument('--pilot',type=Path,default=Path('/tmp/ccu_r631_pilot.json'));ap.add_argument('--full',type=Path,default=Path('/tmp/ccu_r631_full.json'));ap.add_argument('--halo-input',type=Path,default=Path('/tmp/ccu_r630_portable/historical_compact.json'));ap.add_argument('--output',type=Path,default=Path('/tmp/ccu_r631_exact_audit.json'));args=ap.parse_args();start=time.monotonic();params=json.loads(args.parameters.read_text());pilot=json.loads(args.pilot.read_text());full=json.loads(args.full.read_text());halo=json.loads(args.halo_input.read_text());ha={(z['n'],z['k']):z['halos'] for z in halo['halo_contracts']};results=[]
 for case in params['cases']:
  n,k=case['n'],case['k'];pick=next((b,r) for b in pilot['blocks'] if (b['n'],b['k'])==(n,k) for r in b['records'] if r['status']=='E1' and 'x' in r)
  results.append(audit(case,pick[1],ha[n,k],'pilot',pick[0]['block']))
 for k in (1,64,4096):
  case=next(x for x in params['cases'] if x['n']==512 and x['k']==k)
  candidates=[(r['rho'] if k==1 else r['rho']*r['pi1'],b,r) for b in full['blocks'] if b['n']==512 and b['k']==k for r in b['records'] if r['status']=='E1']
  score,b,row=max(candidates,key=lambda x:x[0]); assert 'x' in row, 'maximum impact point not retained'
  res=audit(case,row,ha[512,k],'full_max',b['block']);res['selection_impact_score']=score;results.append(res)
 out={'script_sha256':sha(Path(__file__)),'input_hashes':{str(p):sha(p) for p in (args.parameters,args.pilot,args.full,args.halo_input)},'cases':results,'count_mismatches':sum(not z['counts_match'] for z in results),'tilt_float_membership_mismatches':sum(z['float_membership_mismatches'] for z in results),'saved_tilt_count_mismatches':sum(z['saved_tilt_counts_match'] is False for z in results),'rho_max_exact_le_4':all(z['rho_le_4_certified'] for z in results),'max_rho_abs_diff':max(z['rho_abs_difference'] for z in results),'elapsed_seconds':time.monotonic()-start,'scope':'exact rational audit of twelve saved binary64 points, not ideal irrational geometry or finite PRNG continuous law'}
 args.output.write_text(json.dumps(out,indent=2));
 with args.output.with_suffix('.md').open('w') as f:
  f.write('# R631 精确输入的有限密度证书\n\n每个 pilot case 一点，共9点；另对完整 run 的 n512 各 k 选一个 S1 最大影响点（k=1 按对称归一使用 rho），共3点。所有坐标、格距、theta、q 视保存的 binary64 为精确有理数，winner 处取左右端点的有理中点并直接逐轴计两类格点。\n\n')
  f.write('| 来源 | n | k | block / index | 两类/加权计数匹配 | 浮点与精确 B 成员分歧 | rho≤4 | rho误差（显示） |\n|---|---:|---:|---|---|---:|---|---:|\n')
  for z in results:f.write(f"| {z['origin']} | {z['n']} | {z['k']} | {z['block']} / {z['index']} | {z['counts_match']} | {z['float_membership_mismatches']} | {z['rho_le_4_certified']} | {z['rho_abs_difference']:.3g} |\n")
  f.write('\n每个密度完全用有理数计算：D=1/4+Σhalo项+(1/2m)Σtilt乘积，记录精确 D、rho=1/D 和 4−rho≥0 残差。输入使用实际冻结 theta/q 的 binary64 数；B 以精确相位计算，比较了逐坐标浮点 B 成员。halo 可重叠，密度项累加。\n\n浮点伪随机数只有有限个值，且取模、线性映射等存在舍入；即使冻结参数视为精确有理数，实际离散生成点的概率质量也不等于理想连续混合密度。精确 rho 证书只评价所保存点上的理想密度，不认证生成器的连续分布、理想无理格距或一般维数命题；不重跑 MC。\n')
 print('n=',len(results),'counts mismatches',out['count_mismatches'],'B mismatches',out['tilt_float_membership_mismatches'],'saved B mismatches',out['saved_tilt_count_mismatches'],'rho max diff',out['max_rho_abs_diff'],'wall',out['elapsed_seconds'])
if __name__=='__main__':main()
