import os
for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[key]='1'
import argparse,concurrent.futures,ctypes,hashlib,json,math,resource,shlex,sys,time
from pathlib import Path
import numpy as np
import ccu_r631_proposal as prop
import ccu_r631_numeric as pilot
base=pilot.base

def region(x,a,ts):
 phase=(x/a)%1
 return [int(np.sum(prop.distphase(phase,((t['l']%2)/2+t['coset']/2)%1)<float(t['theta'])/2)) for t in ts]
def block(q):
 n,k,b,ts=q;w=time.monotonic();cpu=time.process_time();_,a,cut=base.params(n,k);seed=631100000+n*100000+k*300+b;rng=np.random.default_rng(seed);rows=[]
 for j in range(4):
  x,rho,c=prop.sample(n,k,ts,rng);r=base.scan(x,k,a,cut);rec={'index':4*b+j,'rho':rho,'component':c,'status':r['status'],'events':r['events'],'pi0':r.get('pi0',0.),'pi1':r.get('pi1',0.),'near_equal_events':r.get('near_equal_events',0),'tilt_high_counts':region(x,a,ts)}
  if r['status']=='E1':rec.update({'winner':r['winner'],'x':x.tolist()})
  rows.append(rec)
 return {'n':n,'k':k,'block':b,'seed':seed,'records':rows,'cpu_seconds':time.process_time()-cpu,'elapsed_seconds':time.monotonic()-w,'worker_peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}

def rsrc(pid):
 lib=ctypes.CDLL('/usr/lib/libproc.dylib'); buf=(ctypes.c_uint64*12)();num=lib.proc_pidinfo(pid,4,0,ctypes.byref(buf),96)
 if num!=96:return None
 return {'pid':pid,'rss_bytes':buf[1],'cpu_time_ns':buf[2]+buf[3]}

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--workers',type=int,default=14);ap.add_argument('--pilot',type=Path,default=Path(__file__).with_name('ccu_r631_pilot.json'));ap.add_argument('--parameters',type=Path,default=Path(__file__).with_name('ccu_r631_parameters.json'));ap.add_argument('--output',type=Path,default=Path(__file__).with_name('ccu_r631_full_replay.json'));a=ap.parse_args();assert 1<=a.workers<=14; param=json.loads(a.parameters.read_text());pd=json.loads(a.pilot.read_text());cases={(c['n'],c['k']):c for c in param['cases']};blocks=pd['blocks'];retained={}
 def reduce(b):
  key=(b['n'],b['k']);keep=retained.setdefault(key,[])
  for r in b['records']:
   if 'x' not in r:continue
   # Ranking both columns (scaled by their respective source masses).
   score=r['rho']*max(r['pi0'],r['pi1']);keep.append((score,r['index'],r));keep.sort(key=lambda v:(-v[0],v[1]))
   if len(keep)>8:keep.pop()[2].pop('x',None)
 # Recreate pilot coordinates from frozen seeds, not the source scan.
 for b in blocks:
  n,k=b['n'],b['k'];ts=cases[(n,k)]['tilts'];rng=np.random.default_rng(b['seed']);_,spacing,_=base.params(n,k)
  for r in b['records']:
   x,rho,c=prop.sample(n,k,ts,rng);assert rho==r['rho'] and c==r['component'];r['tilt_high_counts']=region(x,spacing,ts)
  reduce(b)
 todo=iter((c['n'],c['k'],b,c['tilts']) for c in param['cases'] for b in range(8,128));pending={};samples=[];start=time.monotonic();last=start-1
 with concurrent.futures.ProcessPoolExecutor(max_workers=a.workers) as pool:
  def fill():
   while len(pending)<4*a.workers:
    try:q=next(todo)
    except StopIteration:break
    pending[pool.submit(block,q)]=1
  fill()
  while pending:
   done,_=concurrent.futures.wait(pending,timeout=.2,return_when=concurrent.futures.FIRST_COMPLETED)
   for f in done:
    pending.pop(f);b=f.result();reduce(b);blocks.append(b)
   fill();now=time.monotonic()
   if now-last>=1:
    parent=rsrc(os.getpid());workers=[z for z in (rsrc(p.pid) for p in pool._processes.values()) if z is not None]; samples.append({'elapsed_seconds':now-start,'parent':parent,'workers':workers,'total_rss_bytes':(parent['rss_bytes'] if parent else 0)+sum(z['rss_bytes'] for z in workers),'process_cpu_ns':(parent['cpu_time_ns'] if parent else 0)+sum(z['cpu_time_ns'] for z in workers),'pending_futures':len(pending),'note':'live workers may be idle; taskinfo cpu times are cumulative'});last=now
 blocks.sort(key=lambda z:(z['n'],z['k'],z['block'])); out={'input_pilot_sha256':hashlib.sha256(a.pilot.read_bytes()).hexdigest(),'input_parameters_sha256':hashlib.sha256(a.parameters.read_bytes()).hexdigest(),'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'proposal_sha256':hashlib.sha256(Path(prop.__file__).read_bytes()).hexdigest(),'base_sha256':hashlib.sha256(Path(base.__file__).read_bytes()).hexdigest(),'command':shlex.join([sys.executable]+sys.argv),'blocks':blocks,'summaries':pilot.summary(blocks),'resource_samples':samples,'resources':{'wall_seconds':time.monotonic()-start,'added_worker_cpu_seconds':sum(b['cpu_seconds'] for b in blocks if b['block']>=8),'parent_peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'max_worker_peak_rss_bytes':max(b['worker_peak_rss_bytes'] for b in blocks if b['block']>=8),'max_sampled_simultaneous_rss_bytes':max(s['total_rss_bytes'] for s in samples),'workers':a.workers,'pending_limit':4*a.workers},'note':'Pilot source scan not rerun; pilot proposal coordinates regenerated for tilt regions, verified weight/component. binary64 geometry; k=1 symmetric same-point estimator; 8 highest per-case records retained with x; 1024 vs 512 comparisons are exploratory.'}
 with a.output.open('w') as f:json.dump(out,f)
 print(json.dumps(out['resources']))
if __name__=='__main__':main()
