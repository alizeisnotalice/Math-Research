# R631 signed flux与relocation独立终审

2026-10-28。先独立核目标与向量场，再读最终修订`/tmp/ccu_r631_angular.md`、`/tmp/ccu_r631_relocation.md`；定点核对`/tmp/ccu_r631_bundle/REPORT.tex`证明第1–3节。不审其数值/12条证书，不运行样本或新扫描，不改作者文件。仅本机Fraction/SymPy核H_I及费用代数。

## 1. Future envelope与selected trace：接受范围

在f≥0、C_c∞、φ∈C_c∞(E1)及远离r=0的compact窗口，P(x,r)=sup_(s≥r)m(x,s)/V(s)局部Lipschitz、沿r绝对连续；正level窗口可用有限source质量截断future参数。running-future最大值在non-record处导数为0，在下降contact处等于p_r，flat/tie部分不能另生正trace。clamp Φ的chain rule保留全部future与β窗口，故作者ZΦ(P)的a.e. selected-density身份正确；不需要finite perimeter或每level正则。

对Z=(u/n,−v)、x=y−r(v)u，Zx=0、Zp=p−a0；**相对du dv/v**的div Z=1（Euclidean div是0）。因此receiver mask沿Z不动。此为继承R630 smooth contact合同的等价表达，未自动推广一般L1 contact。

## 2. 完整finite-cutoff Green式与必要修复

固定共同V0,V1、angular mollification及平滑heavy mask时，符号正确：

D_(m,ε)=B0+A−W−R−N，0≤B0≤ell M，W,R≥0。

A是正外向angular-face flux，N符号未知。B仅可测/有界，没有angular BV或经典trace；mollification的L1小误差不控制∇B_m。固定finite窗口恢复**完整D**可用volume DCT，随后ε↓0恢复strict heavy；这不认证A、W、R、N各自的极限，也不能无条件交换边界与volume极限。

原先删W后只估A−N的有限性主张不成立。smooth plateau f=c>1、φ在内部为1时，小v的P=c、Φ=ell、heavy mask为1；采用标准正居中mollifier可使这些小v陈述对closed U有效。每个内部source点有

A_[V0,v*]=W_[V0,v*]=ell log(v*/V0)，N=R=0，

selected-window trace却为0。归一化|∂U|/(n2^n)=1。必要取消是A−W，非h'项；固定cutoff删负bulk虽为形式上界，却可在去cutoff后变∞。**最终作者稿及REPORT已经修复，保留B0和共同A−W−R−N，不再声称A−N有独立finite/root预算。** 小v cut可使原trace为0，不使分拆项各自可付。对φ→1_K的mask恢复可用完整contact measure的H_I倍Lebesgue边际，不能用source像体积替代。

## 3. Relocation(2)–(11)：有限转移身份通过

同一(y,u)上v_c≤B/L及A(v_c)≤b1B/L由contact逼近与连续性得到。J=G∩[B/2,∞)的dV长度≥B/2；L>2b1/τ时共同future parent的fresh质量>(τ/2−b1/L)B，全部旧contact cubes均在同一P_c内。它不是逐contact领M；fresh条件化相对完整parent law的支配因子γ_L=(1−2b1/(τL))^(−1)正确。

fixed y,W下du/2^n=dX/W，故incoming(6)–(7)及其总量H_L正确；integrate新source z恢复receiver incoming，但没有全局新source列容量。sup纤维可按completed measure取可测版本。固定t的x=X+(1−t)(y−X)、dy=(1−t)^(−n)dx正确；fresh条件必须保留至少一个|b_i−(1−t_c)a_i|≥t_c。不能按薄层体积支付任意μ，也不能从t_c^n≤2/L推出全部旧t接近t_c。

新receiver只保证在Eτ。若H_L≤q_*|Eτ|+A_nM，弱型递推系数为q_*/τ，必须q_*<τ；若借fresh source domination取得系数，则需q_geom<τ/γ_L=τ−2b1/L。source domination中的其它费用也须随其实际因子保留。没有incoming容量/strict contraction时，不可迭代重新领取M。

## 4. 最终整合及未付位置

REPORT证明第1–3节与上述修订稿一致，无新增未证主张。常数H_I=7/64、light费用60L M/7及小v边界上界8M/7代数正确，但不支付剩余signed取消或heavy trace。修订消除了早稿的有限边界误读，没有产生一般改进。

**接受：** smooth有限cutoff的完整signed身份、原heavy volume trace恢复的所述顺序、单ray共同fresh relocation及真实Jacobian/level费用。**仍未证：** signed组合的统一root预算、跨source/direction incoming列界，或H_L≤θ|K|+A_nM的θ<1吸收。一般L1 contact恢复、完整root目标与R559母账均未闭合；数值证据不补此缺口。独立终审完成，停止。
