import json,hashlib
from pathlib import Path
from ccu_r631_full import block
p=Path(__file__).resolve().parent
param=json.loads((p/'ccu_r631_parameters.json').read_text()); data=json.loads((p/'ccu_r631_full.json').read_text())
c=next(c for c in param['cases'] if c['n']==32 and c['k']==64); old=next(b for b in data['blocks'] if b['n']==32 and b['k']==64 and b['block']==8); new=block((32,64,8,c['tilts']))
for key in ('n','k','block','seed'):assert old[key]==new[key]
for o,n in zip(old['records'],new['records']):
 for key,v in o.items():assert n[key]==v,(key,n[key],v)
receipt={'case':[32,64],'block':8,'records':4,'math_match':True,'original_full_sha256':hashlib.sha256((p/'ccu_r631_full.json').read_bytes()).hexdigest(),'portable_full_sha256':hashlib.sha256((p/'ccu_r631_full.py').read_bytes()).hexdigest(),'portable_proposal_sha256':hashlib.sha256((p/'ccu_r631_proposal.py').read_bytes()).hexdigest(),'portable_numeric_sha256':hashlib.sha256((p/'ccu_r631_numeric.py').read_bytes()).hexdigest(),'cpu_seconds':new['cpu_seconds'],'wall_seconds':new['elapsed_seconds'],'worker_rss_bytes':new['worker_peak_rss_bytes'],'note':'Replays four points only; validates all saved math fields. Original full output was produced by original scripts, not these path-modified files.'}
(p/'parity_receipt.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt))
