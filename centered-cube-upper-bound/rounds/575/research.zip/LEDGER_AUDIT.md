# R575 最后窄审：恢复常数与 quantile 加权费

## 已定位文件与对应式

本审先定位，再仅阅读以下相关段落，未读整个历史。

| R575 被审位置 | R574 归档对应位置 | 内容 |
|---|---|---|
| `REPORT.tex:159–160` | `REPORT.tex:149–164`；`BAND_BRIDGE.md:171–189` | 全尺度完整 residual 到一般 L1 的同常数恢复 |
| `REPORT.tex:161–165` | `REPORT.tex:166–200`；`BAND_BRIDGE.md:153–169` | 单质量带恢复、4/3、N_n、各输入自己的 H2 |
| `REPORT.tex:166–169` | `REPORT.tex:202–213` | 旧 Φ/Ψ 母式、严格吸收与原一般常数 |
| `REPORT.tex:113–123`、`eq:special` | 本轮 `REPORT.tex:108–111` 的实际 carrier 付款 | quantile 加权总量的准确系数 |

绝对文件：`/tmp/ccu_r575_release/REPORT.tex`、`/tmp/ccu_r574_release/REPORT.tex`、`/tmp/ccu_r574_release/BAND_BRIDGE.md`。未修改这些文件，只写本审稿；无 repo、新代理、PDF 或数值实验。指定本机 Python/SymPy 实跑核了下述系数展开与吸收恒等式，严格论证不依赖数值证据。

## 通过清单

**1. 完整全尺度常数：通过。** R575 的 \(R_\lambda\) 已在 `:41–42` 定义为 \(\lambda|E_\lambda\setminus H_2|\)，不是未乘 λ 的体积。因此假设 \(R_\lambda\le D_nW\) 与已付 \(\lambda|H_2|\le2\sqrt nW\) 相加，原子完整弱型常数恰为
\[
K_n^{\rm full}=2\sqrt n+D_n^{\rm full}.
\]
固定盒网格质量收敛、严格见证与 Fatou，继而非负截断单调恢复 L1，保留同一常数。不需16e、N_n、4/3或源格保留因子，也不需 H2_j 收敛。必须是所有 finite atomic 输入、全部尺度和阈值统一的**完整** residual 估计；归档与本轮都保留了该条件，没有用单独好区付款代替它。

**2. 单质量带一般常数：通过。** 归档实际输入为 R571 同一来源 f_k、ΣW_k≤N_nW、真实边长 R∈[2^k,2^{k+1}]、q_k∈[3λ/4,λ]，以及原异常集16eW。阈值 τ=αλ、α<3/4 的严格 slack 和原子化保证 r_S(τ)>R；α↑3/4 产生且只产生4/3。因此
\[
K_n^{\rm band}=16e+\frac43N_n(2\sqrt n+D_n^{\rm band}),
\quad N_n=2+\lceil\log_2(32n^2)\rceil.
\]
展开为 \(16e+(8/3)N_n\sqrt n+(4/3)N_nD_n^{\rm band}\)，与归档附件完全一致。H2 随各实际 ν_{k,j}≈f_k 变化，其费用当前必须跟随 ΣW_k 计算；本轮 `:165` 正确保留了这一限制。没有漏掉密度/来源因子，也没有额外要求 source grids。

这里仅为清晰将 D_n 标上 full/band；本轮同符号在两个分别引入的条件命题内使用，不代表二者已证明或数值相同。无需数学修正。

**3. 旧 Φ/Ψ 吸收常数：通过，仍是未付条件账。** 对归档同一完整对象，
\[
\Phi\le(1+G)W+G\sqrt J\,\Psi,
\quad\Psi\le a\Phi+LW,
\quad G\sqrt J\,a<1
\]
直接给
\[
\Phi\le F_\Phi W,\qquad
F_\Phi=\frac{1+G+G\sqrt J\,L}{1-G\sqrt J\,a}.
\]
再用归档 \(X'\le\sqrt D\Phi\)、原密度4/3、源格保留 \((1-\eta)^{-1}\)、来源累计 N_n，准确得到
\[
16e+\frac{4N_n\sqrt D\,F_\Phi}{3(1-\eta)}.
\]
没有应额外补的 C0、G²或旧平方能量 d=1−3h 因子：本轮照录的是归档完整混合范数母账，不能与另一母式混用。其使用必须保留归档同一 G,J,D,η、同一冻结场/共同动作和完整 Ψ；不能把本轮 quantile carrier 的体积或分量和自动当作 Ψ。R575 `:169` 明确说新载体未支付此账，表述正确。此审没有证明所需 \(\Psi\le a\Phi+LW\)。

## Quantile 总量到根阶的准确系数

在本轮明确的 special 设置 M_g=m_{0g}、ε_g=1/(4n)、b=n^−1/2，实际 carrier 本身满足
\(\lambda|B(K_g,m_{0g})|\le(n^{-1/2}+n^{-1})m_{0g}\)。所以对同一个 ν、λ 共同选择的 w_g≥0，若真正有 a.e. receiver 覆盖
\[
1_{E_\lambda\setminus H_2}\le\sum_gw_g1_{B(K_g,m_{0g})},
\quad T:=\sum_gw_gm_{0g}\le Cn\log^A(n+2)W,
\]
Tonelli/体积求和给准确 residual 常数
\[
\boxed{R_\lambda\le C(\sqrt n+1)\log^A(n+2)W.}
\]
因此若该覆盖与总量对完整全尺度 residual 统一成立，完整一般 L1 常数为
\[
\boxed{2\sqrt n+C(\sqrt n+1)\log^A(n+2).}
\]
可放宽为 \([2+2C\log^A(n+2)]\sqrt n\)，但前式是准确系数。若只对实际完整单质量带成立，则一般常数是
\[
16e+\frac43N_n\left[2\sqrt n+C(\sqrt n+1)\log^A(n+2)\right].
\]
没有额外覆盖概率逆因子，因为报告的假设已经是共同权重下点态覆盖≥1；若换成覆盖概率≥p，权重总量须先包含1/p。也没有额外阈值比，因为该段所有组使用同一实际 λ；若以后改变组阈值，必须重算。

本轮 `:118–123` 将此结论明确限制在 special 设置，并明确没有证明覆盖选择或 T 的总量，故其“足以给根阶多对数费用”正确。一般 M_g>m_{0g} 的组不能仍只按 special 系数结账，必须保留质量增量与 ε 项；报告没有这样误用。

## 最终判定与修正清单

三条继承常数及 quantile 放大均通过，未发现需修正的遗漏因子或额外未声明假设。唯一符号提示是可以区分 \(D_n^{\rm full}\)、\(D_n^{\rm band}\)，但现有分条件表述没有数学错误。

所有旧吸收界、完整 residual 界和 quantile 总量界均仍为**尚未付款的条件账**。本审只核对应公式与合法回代，不声称新增一般上界。定位/通过清单完成，停止待审。
