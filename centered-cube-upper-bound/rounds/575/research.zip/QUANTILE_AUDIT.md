# R575：分位几何核的独立审查与全局放大边界

**判定：通过，以下明确假设不可删除。** 先按 root 给出的准确命题独立核对 weighted atoms、ties、包含关系及费用，再读 `/tmp/ccu_r575_astra.md` 的定版对照。定版采用的“missing≤εm0 / 分位累计>εm0”版本正确。没有取得跨所有群组的一般根阶累计预算。

只写本文件，无 repo/他人修改，无子代理，无 PDF。指定本机 Python/SymPy 实际核查了费用差的恒等式及 M=m0、ε=1/(4n) 的特例；无数值扫描。输出费用差为 \(2(2n\varepsilon m_0-m_0+m_K)/n\)，特例为 \((b+1/n)m_0\)。严格证明如下。

## 1. 正确的原子分位点与质量

固定真实残余 reference S0：\(C_{S_0}\setminus H_2\ne\varnothing\)，记 \(m_0=m_{S_0}>0\)，\(0<\varepsilon\le1/(4n)\)。定义每坐标有限支持上的
\[
\ell_j=\min\{t:\nu_{S_0}(z_j\le t)>\varepsilon m_0\},\quad
u_j=\max\{t:\nu_{S_0}(z_j\ge t)>\varepsilon m_0\}.
\tag{1}
\]
两侧分位点存在，并且严格外尾质量分别≤εm0。所有同坐标 ties 作为实际 Lebesgue-source labels 的总质量共同计入；不分割原子。\(\ell_j\le u_j\)：否则两个各≤εm0的严格外尾会覆盖全部质量，而2ε<1，矛盾。

令 \(R=\prod_j[\ell_j,u_j]\)、\(K=\{i\in S_0:z_i\in R\}\)。删除的只是2n个严格坐标外尾的并，因此
\[
m_K\ge(1-2n\varepsilon)m_0\ge m_0/2>0.
\tag{2}
\]
这允许 K 的坐标 bounding box 退化，不要求连续来源或原子位置一般。

若要用 closed missing 条件 \(m(S_0\setminus S)\le\varepsilon m_0\)，(1) 的累计必须严格>。仅累计≥时，S可以恰删除全部阈值质量，左右支点结论失败。另一正确但不同的版本是累计≥与missing<；不能交叉混用。

## 2. 没有实际共同标签仍有正确整族包含

考虑任意有限族 \(\mathcal G\)，对每个 S 假设
\[
m(S_0\setminus S)\le\varepsilon m_0,\quad m_S\le M,
\qquad m_0\le M\le2m_K.
\tag{3}
\]
由 (1)，reference 中坐标≤ℓ_j的来源质量严格>εm0，不可能被 S 全部删去；坐标≥u_j同理。所以 S 中仍有真实原子满足两侧坐标条件，得到
\[
\min_{i\in S}z_{ij}\le\ell_j\le\min_{i\in K}z_{ij},\quad
\max_{i\in S}z_{ij}\ge u_j\ge\max_{i\in K}z_{ij}.
\tag{4}
\]
新增到 S 的来源只可能加大其 ranges，不破坏 (4)。注意该证明不声称 K⊂S。

记 \(r_M=(M/\lambda)^{1/n}\)，并定义真实 receiver boxes
\[
B_R(M)=\prod_j(u_j-r_M/2,\ell_j+r_M/2),\quad
B(K,M)=\prod_j(\max_Kz_j-r_M/2,\min_Kz_j+r_M/2).
\]
因 \(r_S\le r_M\)，逐坐标有
\[
\boxed{\bigcup_{S\in\mathcal G}C_S\subset B_R(M)\subset B(K,M).}\tag{5}
\]
如果右盒某坐标宽度非正，它为空，(5) 仍成立。C_S 是严格开盒；(4) 的非严格极值不等式与 r_S≤r_M 足够，不需要删除 receiver 边界。

这是几何共同核：全族真实交集可以为空。K仍是 S0 的真实来源半质量核，但不是族内每个 S 的共同 source allocation。不能将 (5) 当成 source-nonduplicating forest 中的 parent–child 标签关系。

## 3. 低 β 与准确费用

reference 必须确有 H2 外 receiver。因为 (2) 且 K⊂S0，R574 的大高核消去结论给 \(\beta_K<b\)。仅有 \(\beta_{S_0}<b\) 不足以推出这一点。

在 (3) 的 \(M\le2m_K\) 条件下，使用已证共同核 carrier 付款：
\[
\begin{aligned}
\lambda|\cup_{S\in\mathcal G}C_S|
&\le\lambda|B(K,M)|\\
&\le\beta_Km_K+(\beta_K+2/n)(M-m_K)\\
&=\beta_KM+(2/n)(M-m_K)\\
&\le bM+2(M-m_0)/n+4\varepsilon m_0.
\end{aligned}\tag{6}
\]
这里没有领取旧 receiver C_K 的另一份费用，也不假设旧 cover 已包含它。βK=0允许；估计中的线性增量正是要保留的费用。

特别 M=m0、ε=1/(4n) 时，\(M\le2m_K\) 自动由 (2) 成立，整族一次付款
\[
\boxed{\lambda|\cup C_S|\le(b+1/n)m_0.}\tag{7}
\]
一般 M>m0 时，\(M\le2m_K\) 不能仅由 ε≤1/(4n) 自动删除。例如 (2) 在端点只保证 mK≥m0/2，未保证可取任何 M>m0。

## 4. 实际 source-metric 选择能接什么总账

该邻域是实际质量的一侧 metric 条件 \(d_-(S_0,S)=m(S_0\setminus S)\)，不是坐标距离，也不是跨群组自动不复制的容量。对多个共同固定的 references/group carriers，真实覆盖及共同权重若给
\[
1_{\mathrm{residual}}\le\sum_g w_g1_{B(K_g,M_g)},\quad w_g\ge0,
\]
则 (6) 只允许相应的实际总费
\[
\sum_gw_g\left[bM_g+\frac2n(M_g-m_{0g})+4\varepsilon_gm_{0g}\right].
\tag{8}
\]
source sharing 必须在这里结算，不能把群组数或 metric-packing 数量免费删掉。

有一个对后续选择有用的尺度区别：若均用 (7)、b=n^−1/2，则 references 总质量若能真正控制到
\(\sum_gw_gm_{0g}\le Cn\log^A(n+2)W\)，就已经得到根阶乘对数付款；不必误要求 polylog·W。后者是14√n森林 payer所需的强预算，(7) 的逐群组费只有约 m0/√n。更准确的 (8) 允许大量 βK 极小的群组，故也不应强制用未加权 reference 数量替代真实费用。

目前没有由源 metric 直接证明这一选择预算：按 m0 递减选最大近包含邻域，只保证后来 reference 删除了前者超过ε比例的质量；这不蕴含 source-disjoint，也不控制同一个原子被多少 references 使用。把这些 references 全改归共享原子的 stars，又需要结算 stars 之间的实际 source/receiver overlap；不能把先前 union 冒充一颗新 star。量化分位点本身没有给出这种累计结算。

因此已确认的是 (5)–(7) 的整族几何付款；未证明的是在全部实际残余上共同选择这些群组（以及必要的共同星组）并控制 (8)。未将一般 Hall/LP 可行性或与弱型等价的容量条件称作新结果。

## 5. 被停止的共同随机候选，仅留准确费用

此前独立尝试共同 Poisson source-sharing stars：对每个真实原子在 u∈[L,2U] 放强度 \(m_i\,du/u^2\) 的 marks，mark生成中心 zi、体积 u/λ 的辅助 receiver cube。同位置质量拆分不改变该随机律。任一 band witness S 的整个 C_S，在 S 内存在 u≥mS 的 mark 时被覆盖，均值≥1/2，故同一共同选择给每个真实 receiver 覆盖概率≥\(1-e^{-1/2}\)。但准确期望总 receiver fee 是 \(W\log(2U/L)\)，per-source 同倍，单带只到 O(n)W；没有得到根阶结算。辅助 mark 的 u 不是原输入 atom 的真实质量，不能假装是免费保持容量的 source leaf。依 root 指示已停止其未剪枝 union 分析，不另写下界或将其重述为新 payer。

审查完成；没有一般残余改善，按边界停止待审。
