# R575 证明与复现导航

REPORT.tex 为本轮完整论证；NUMERICS.tex 区分一般解析证明、有限LP有理证书、Arb区间结果和浮点候选。均不编译PDF。

## 复现

在解压目录使用装有 NumPy、SciPy、python-flint 的 Python：

```sh
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 /Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python repro/reproduce.py
```

三个原脚本串行执行，输出至临时目录，核对冻结数学字段。回执写入 repro/reproduction_receipt.json。不要对归档只读目录直接运行；复制至可写工作目录。回执变化只反映新的复现元数据。

本轮版本：Python3.12.14、NumPy2.5.4、SciPy1.18.1、python-flint0.9.0，Arb192位。初次原始命令和结果由数值附录说明，最终可携带运行元数据见回执。库版本变化可能使优化器选中不同最优支持或Arb显示不同；不得因显示不同而删除实际证书核验。

LP最小输入从已发布R574 research.zip的numeric.json逐字段抽取。主代理另从该Git工作树归档读取并匹配原输入SHA及全部抽取字段，实际全部通过。原完整输入不重复归档。

## 继承证明与总账来源

- R574 REPORT.tex：全部尺度实际标签盒表示、任意交叠高半质量核覆盖H2、全尺度及单质量带条件恢复。
- R574 BAND_BRIDGE.md：单带局部化的真实N_n来源费用。
- R573研究包：给定合法森林的付款；本轮精确限定为什么不能免费把任意交叠族转成该森林。
- R571研究包：原一般输入局部化与常数16e、(4/3)N_n。

继承结论不是由本轮有限测试重新认证。全部剩余仍是E_lambda\H2；没有关闭该对象的一般根阶预算。

## 证据保留与范围

QUANTILE_AUDIT.md和GRID_AUDIT.md分别保留先独立审命题后的核验。REPORT_AUDIT.md及LEDGER_AUDIT.md核最终报告和费用桥。MANIFEST.json记录归档成员哈希；哈希只能确认字节，不能替代数学独审。

仅归档必要最终代码、一个合并数学结果、一个最小输入及最终审核。其余草稿、重复JSON及运行缓存留在仓库外。没有PDF、无新大扫描。本轮维护1个Astra与3个GPT-6.1 Sol的团队，完成者不计正在运行。
