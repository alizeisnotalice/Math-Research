"""Run the three frozen scripts and compare exact/certified mathematical outputs."""
from pathlib import Path
import tempfile,subprocess,sys,json,os,time,hashlib,platform
ROOT=Path(__file__).resolve().parent
IGNORE={'runtime_seconds','peak_rss_bytes','interpreter','python_version','numpy_version','scipy_version','sympy_version','python_flint_version','command','source_input','source_sha256','solver'}
def project(v):
 if isinstance(v,dict):return {k:project(x) for k,x in v.items() if k not in IGNORE}
 if isinstance(v,list):return [project(x) for x in v]
 return v
def canonical(v):return json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
expected=json.loads((ROOT/'expected_math.json').read_text())
manifest=json.loads((ROOT/'input_manifest.json').read_text())
assert digest(ROOT/'lp_input.json')==manifest['extracted_input_sha256']
start=time.perf_counter();runs=[]
env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
with tempfile.TemporaryDirectory(prefix='r575-repro-') as td:
 for name in ['ccu_r575_numeric','ccu_r575_grid_certificate','ccu_r575_quantile_check']:
  output=Path(td)/(name+'.json')
  cmd=[sys.executable,str(ROOT/(name+'.py'))]
  if name=='ccu_r575_numeric':cmd+=['--input',str(ROOT/'lp_input.json')]
  cmd+=['--output',str(output)]
  t=time.perf_counter()
  completed=subprocess.run(cmd,env=env,capture_output=True,text=True,timeout=60)
  assert completed.returncode==0,(name,completed.stderr)
  actual=json.loads(output.read_text());math_result=project(actual)
  assert math_result==expected[name],name+' mathematical output changed'
  runs.append({'script':name+'.py','script_sha256':digest(ROOT/(name+'.py')),'returncode':completed.returncode,'status':actual['status'],'mathematical_output_sha256':hashlib.sha256(canonical(math_result)).hexdigest(),'matches_reference':True,'elapsed_seconds':time.perf_counter()-t,'stderr':completed.stderr.strip(),'runtime_metadata':{'runtime_seconds':actual.get('runtime_seconds'),'peak_rss_bytes':actual.get('peak_rss_bytes')}})
receipt={'status':'PASS_ALL_THREE_PORTABLE_REPRODUCTIONS','runs':runs,'input_manifest':manifest,'comparison':'Recursive equality of mathematical projection; ignores timing/RSS/paths/versions and exploratory float solver metadata. Exact rational values, all feasibility/zero-gap certificates, rank/bbox outcomes, and Arb192 interval strings retained.','certificate_classes':{'tree_LP':'float HiGHS proposes support; exact Fraction primal/dual feasibility and zero gap certify result','grid':'Fraction arithmetic and n2 all-subset enumeration; general classification is analytic input','quantile':'Fraction rank/mass/bbox; python-flint Arb192 n2 beta/carrier balls; n3/n8 no beta/root claim'},'extraction_scope':'Input extraction is faithful reduction of previous R574 record, not independent geometric validation.','interpreter':sys.executable,'python_version':platform.python_version(),'command':'OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 '+sys.executable+' '+str(ROOT/'reproduce.py'),'total_elapsed_seconds':time.perf_counter()-start}
(ROOT/'reproduction_receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'status':receipt['status'],'scripts':[{'name':r['script'],'match':r['matches_reference']} for r in runs],'interpreter':sys.executable,'total_elapsed_seconds':receipt['total_elapsed_seconds']},indent=2))
