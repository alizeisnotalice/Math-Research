"""Four fixed weighted quantile families; exact rank/bbox/mass, Arb192 n2 fees."""
from fractions import Fraction as Q
from pathlib import Path
from itertools import product
import argparse,json,sys,platform,time,resource,shlex
from flint import arb,ctx
import flint
ctx.prec=192
parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,default=Path(__file__).resolve().parent/'quantile_results.json');args=parser.parse_args();start=time.perf_counter()
def aq(q):
 q=Q(q);return arb(q.numerator)/arb(q.denominator)
def prodq(vals):
 p=Q(1)
 for x in vals:p*=x
 return p
def box(points,ids):return [(min(points[i][j] for i in ids),max(points[i][j] for i in ids)) for j in range(len(points[0]))]
def omissions(weights,budget):
 out=[]
 def rec(i,chosen,total):
  if i==len(weights):out.append(tuple(chosen));return
  rec(i+1,chosen,total)
  if total+weights[i]<=budget:rec(i+1,chosen+[i],total+weights[i])
 rec(0,[],Q(0));return out
models=[]
p=[(cx+dx,cy) for cx in [Q(-5,4),Q(5,4)] for cy in [Q(-5,4),Q(5,4)] for dx in [Q(-1,100),Q(1,100)]]
models.append(('n2_eight_corner_pairs',2,p,[Q(1)]*8,Q(1,8)))
p=[(cx+dx,cy) for cx in [Q(-4),Q(4)] for cy in [Q(-4),Q(4)] for dx in [Q(-1,100),Q(1,100)]]+[(Q(-41,10),Q(0)),(Q(41,10),Q(0)),(Q(0),Q(-41,10)),(Q(0),Q(41,10))]
models.append(('n2_weighted_trim_outliers',2,p,[Q(10)]*8+[Q(5)]*4,Q(1,8)))
for n in [3,8]:
 p=[tuple(Q(-1 if i%2==0 else 1,10) for j in range(n)) for i in range(4*n)]
 models.append((f'n{n}_duplicate_coordinate_clusters',n,p,[Q(1)]*(4*n),Q(1,4*n)))
rows=[]
for name,n,points,weights,eps in models:
 N=len(points);m0=sum(weights,Q(0));budget=eps*m0
 assert 0<eps<=Q(1,4*n)
 ranks=[];R=[]
 for j in range(n):
  coordinate_mass={}
  for p,w in zip(points,weights):coordinate_mass[p[j]]=coordinate_mass.get(p[j],Q(0))+w
  ordered=sorted(coordinate_mass);cum=Q(0);lo=None
  for v in ordered:
   cum+=coordinate_mass[v]
   if cum>budget:lo=v;break
  cum=Q(0);hi=None
  for v in reversed(ordered):
   cum+=coordinate_mass[v]
   if cum>budget:hi=v;break
  assert lo<=hi
  lower_tail=sum((w for p,w in zip(points,weights) if p[j]<lo),Q(0))
  upper_tail=sum((w for p,w in zip(points,weights) if p[j]>hi),Q(0))
  assert lower_tail<=budget and upper_tail<=budget
  assert sum((w for p,w in zip(points,weights) if p[j]<=lo),Q(0))>budget
  assert sum((w for p,w in zip(points,weights) if p[j]>=hi),Q(0))>budget
  ranks.append({'coordinate':j,'coordinate_mass':[[str(v),str(coordinate_mass[v])] for v in ordered],'lower_quantile':str(lo),'upper_quantile':str(hi),'strict_lower_tail_mass':str(lower_tail),'strict_upper_tail_mass':str(upper_tail)})
  R.append((lo,hi))
 K=[i for i,p in enumerate(points) if all(lo<=p[j]<=hi for j,(lo,hi) in enumerate(R))]
 mK=sum((weights[i] for i in K),Q(0));kb=box(points,K);M=m0
 assert mK>0 and mK>=(1-2*n*eps)*m0 and mK>=m0/2 and m0<=M<=2*mK
 omits=omissions(weights,budget)
 families=[];intersection=set(range(N));bad_subsets=0
 for omit in omits:
  ids=[i for i in range(N) if i not in omit];intersection.intersection_update(ids)
  bb=box(points,ids);ms=sum((weights[i] for i in ids),Q(0))
  assert m0-ms<=budget and ms<=M
  assert all(bb[j][0]<=kb[j][0]<=kb[j][1]<=bb[j][1] for j in range(n))
  contained=set(K)<=set(ids)
  bad_subsets+=not contained
  families.append({'omitted_labels':list(omit),'omitted_mass':str(m0-ms),'mass':str(ms),'bbox':[[str(a),str(b)] for a,b in bb],'K_is_source_subset':contained,'bbox_K_contained':True})
 assert not intersection
 # One deterministic allowed deletion plus remote replacement, preserving mS=m0.
 omit=(0,);oldids=list(range(1,N));remote=tuple(Q(100) for j in range(n));extra_points=points+[remote];extra_ids=oldids+[N];extra_mass=m0-weights[0]+weights[0]
 bb=box(extra_points,extra_ids)
 assert weights[0]<=budget and extra_mass<=M
 assert all(bb[j][0]<=kb[j][0]<=kb[j][1]<=bb[j][1] for j in range(n))
 assert max(v-u for u,v in bb)**n>=extra_mass
 added={'C_empty_certified_by_range_power':True,'deleted_old_labels':[0],'deleted_mass':str(weights[0]),'added_remote_point':list(map(str,remote)),'added_mass':str(weights[0]),'total_mass':str(extra_mass),'bbox':[[str(a),str(b)] for a,b in bb],'bbox_K_contained':True}
 fee={'checked':False,'reason':'n3/n8 intentionally certify quantile, mass and bbox only; no root or beta claim'}
 if n==2:
  rK=aq(mK).sqrt();rM=aq(M).sqrt();ranges=[b-a for a,b in kb]
  beta=arb(1);carrier=arb(1)
  for d in ranges:
   wK=rK-aq(d);wM=rM-aq(d)
   assert wK>0 and wM>0
   beta*=wK/rK;carrier*=wM
  b=arb(1)/arb(n).sqrt();assert beta<b
  rhs=beta*aq(M)+2*aq(M-mK)/n
  final=b*aq(M)+2*aq(M-m0)/n+4*aq(eps*m0)
  # Exact equality when K=S0 and M=mK, otherwise strict Arb sign.
  if M==mK:assert (carrier-rhs).contains(0)
  else:assert carrier<rhs
  assert carrier<final
  fee={'checked':True,'precision_bits':192,'core_ranges':list(map(str,ranges)),'beta_K_Arb':beta.str(50),'b_Arb':b.str(50),'beta_K_lt_b_certified':True,'carrier_volume_Arb':carrier.str(50),'beta_M_plus_2_delta_over_n_Arb':rhs.str(50),'low_beta_final_bound_Arb':final.str(50),'fee_equality_exact_from_same_M_and_mK':M==mK,'fee_inequality_certified':True,'S0_actual_H2_residual_qualification':'NOT CHECKED; no residual payer conclusion'}
 rows.append({'model':name,'n':n,'N':N,'positions':[[str(x) for x in p] for p in points],'weights':list(map(str,weights)),'epsilon':str(eps),'m0':str(m0),'budget_omitted_mass':str(budget),'quantile_coordinate_certificates':ranks,'R':[[str(a),str(b)] for a,b in R],'K_labels':K,'trimmed_labels':[i for i in range(N) if i not in K],'mK':str(mK),'M':str(M),'mass_lower_bound':str((1-2*n*eps)*m0),'mass_lower_bound_slack':str(mK-(1-2*n*eps)*m0),'family_count':len(families),'families':families,'common_source_intersection_labels':sorted(intersection),'family_members_not_containing_K':bad_subsets,'remote_added_case':added,'carrier_cover_certificate':'For every S, bbox(K) subset bbox(S) and mS<=M; hence C_S subset B(K,M) using actual radius, even if K not subset S.','fee':fee,'all_exact_rank_mass_bbox_checks':True})
result={'status':'PASS_FOUR_FIXED_QUANTILE_WHOLE_FAMILY_GEOMETRIES','rows':rows,'fixed_cases':4,'noaddedatoms_family_count':sum(r['family_count'] for r in rows),'remote_added_cases':4,'rank_bbox_mass_arithmetic_error':'0 (Fraction only)','Arb_precision_bits':192,'interpreter':sys.executable,'python_version':platform.python_version(),'python_flint_version':flint.__version__,'command':'OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 '+shlex.join([sys.executable]+sys.argv),'runtime_seconds':time.perf_counter()-start,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'processes':1,'scope':'Fixed finite quantile geometry and n2 carrier-fee certificates. S0 residual qualification and general joint reference-family payment NOT proved.'}
args.output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='rows'},indent=2))
print(json.dumps([{'model':r['model'],'m0':r['m0'],'mK':r['mK'],'trimmed':r['trimmed_labels'],'family_count':r['family_count'],'intersection':r['common_source_intersection_labels'],'family_K_not_subset_count':r['family_members_not_containing_K'],'fee':r['fee']} for r in rows],indent=2))
