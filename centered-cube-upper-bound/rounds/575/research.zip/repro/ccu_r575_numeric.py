"""Two approved A2 residual full-source tree LPs; exact rational certificates."""
import argparse,json,sys,platform,time,resource,hashlib,shlex,signal
from pathlib import Path
from fractions import Fraction as Q
from functools import lru_cache
import numpy as np
import scipy
from scipy.optimize import linprog
parser=argparse.ArgumentParser()
parser.add_argument('--input',type=Path,default=Path(__file__).resolve().parent/'ccu_r574_numeric.json')
parser.add_argument('--output',type=Path,default=Path(__file__).resolve().parent/'numeric.json')
args=parser.parse_args();start=time.perf_counter()
raw=args.input.read_bytes();data=json.loads(raw)
assert data['status']=='PASS_10_COMPLETE_SUBSET_GREEDY_INFLATION_CASES'

def alarm(sig,frame):raise TimeoutError('120 second input cap')
signal.signal(signal.SIGALRM,alarm)
@lru_cache(None)
def trees(mask):
    if mask.bit_count()==1:return ((mask,None,None),)
    first=mask&-mask;res=[];a=(mask-1)&mask
    while a:
        b=mask^a
        if b and a&first:
            for ta in trees(a):
                for tb in trees(b):res.append((mask,ta,tb))
        a=(a-1)&mask
    return tuple(res)
def masks(t):
    m,a,b=t
    if a is None:return [m]
    assert a[0]&b[0]==0 and a[0]|b[0]==m
    return [m]+masks(a)+masks(b)
def rationalize(x):return [Q(float(v)).limit_denominator(1000000) for v in x]
rows=[]
for model,expected in [('n2_four_3_4',15),('n2_six_grid',945)]:
    signal.alarm(120);ts=time.perf_counter()
    case=next(r for r in data['rows'] if r['model']==model and r['A']==2)
    N=case['N'];W=Q(N);full=(1<<N)-1
    alltrees=trees(full);assert len(alltrees)==expected
    nodemasks=[masks(t) for t in alltrees]
    for ms in nodemasks:
        assert len(ms)==2*N-1 and ms[0]==full
        assert sorted(m for m in ms if m.bit_count()==1)==[1<<i for i in range(N)]
        assert all(1<=m.bit_count()<=N for m in ms) and N<=8
    cells=case['residual_cells'];assert cells
    patterns=[];unique={};mapping=[]
    for c in cells:
        witness=set(c['witness_masks'])
        pattern=tuple(int(bool(witness.intersection(ms))) for ms in nodemasks)
        assert any(pattern)
        if pattern not in unique:unique[pattern]=len(patterns);patterns.append(pattern)
        mapping.append(unique[pattern])
    M=np.array(patterns,dtype=float)
    sol=linprog(np.ones(expected),A_ub=-M,b_ub=-np.ones(len(patterns)),bounds=(0,None),method='highs',options={'presolve':True,'threads':1})
    assert sol.success,sol.message
    wp=rationalize(sol.x);yd=rationalize(-sol.ineqlin.marginals)
    assert all(w>=0 for w in wp) and all(y>=0 for y in yd)
    covers=[sum((wp[j] for j,v in enumerate(p) if v),Q(0)) for p in patterns]
    loads=[sum((yd[i] for i,p in enumerate(patterns) if p[j]),Q(0)) for j in range(expected)]
    assert all(v>=1 for v in covers) and all(v<=1 for v in loads)
    primal=sum(wp,Q(0));dual=sum(yd,Q(0));assert primal==dual
    # Verify every original real receiver cell and every tree after row compression.
    assert all(covers[r]>=1 for r in mapping)
    single=[j for j in range(expected) if all(p[j] for p in patterns)]
    support=[]
    for j,w in enumerate(wp):
        if w:
            support.append({'tree_index':j,'weight':str(w),'nested_tree':alltrees[j],'node_masks':nodemasks[j],'node_masses':[m.bit_count() for m in nodemasks[j]],'covered_original_cell_indices':[i for i,r in enumerate(mapping) if patterns[r][j]],'root_mass':str(W),'source_labels':list(range(N))})
    dualsupport=[]
    for r,y in enumerate(yd):
        if y:
            representative=mapping.index(r)
            dualsupport.append({'unique_row_index':r,'weight':str(y),'original_cell_index':representative,'cell_certificate':cells[representative],'all_equivalent_original_cell_indices':[i for i,v in enumerate(mapping) if v==r]})
    rows.append({'model':model,'A':2,'n':2,'N':N,'W':str(W),'mass_band':[1,N],'source_positions':case['unit_source_positions'],'residual_volume':case['exact_volume_E_minus_H_A'],'all_tree_count':len(alltrees),'original_positive_cell_count':len(cells),'unique_incidence_row_count':len(patterns),'original_cell_to_unique_row':mapping,'optimal_common_weight_exact':str(primal),'dual_objective_exact':str(dual),'gap_exact':str(primal-dual),'minimum_original_cell_coverage':str(min(covers)),'maximum_tree_dual_load':str(max(loads)),'single_tree_cover_count':len(single),'single_tree_cover_indices':single,'primal_support':support,'dual_support':dualsupport,'all_tree_dual_loads':[str(v) for v in loads],'all_unique_row_primal_coverage':[str(v) for v in covers],'every_source_multiplicity':[str(primal)]*N,'actual_weighted_root_mass':str(primal*W),'R573_diagnostic_fee':'14*sqrt(2)*'+str(primal*W),'solver':{'name':'scipy.optimize.linprog/HiGHS','float_objective_exploratory':float(sol.fun),'message':sol.message,'certificate_recovery':'Fraction.limit_denominator(1000000), then all original cell and all tree exact feasibility and zero-gap assertions'},'all_checks_exact':True,'runtime_seconds':time.perf_counter()-ts})
    signal.alarm(0)
result={'status':'PASS_TWO_COMPLETE_TREE_POOLS_EXACT_PRIMAL_DUAL','rows':rows,'source_input':str(args.input),'source_sha256':hashlib.sha256(raw).hexdigest(),'tree_enumeration':'unordered disjoint binary splits; least label forced into left child, each full-source root once','arithmetic_error':'0 in certificates; LP floats exploratory only','interpreter':sys.executable,'python_version':platform.python_version(),'numpy_version':np.__version__,'scipy_version':scipy.__version__,'command':'OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 '+shlex.join([sys.executable]+sys.argv),'runtime_seconds':time.perf_counter()-start,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'processes':1,'scope':'Two approved finite A2 residual incidences only, no high-core rerun, full-E expansion, N8 enumeration, or general forest multiplicity theorem.'}
args.output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps([{k:r[k] for k in ['model','all_tree_count','original_positive_cell_count','unique_incidence_row_count','optimal_common_weight_exact','dual_objective_exact','gap_exact','single_tree_cover_count','actual_weighted_root_mass','runtime_seconds']} for r in rows],indent=2))
print(json.dumps({k:v for k,v in result.items() if k!='rows'},indent=2))
