"""Fixed high-dimensional grid formulas plus complete n=2 subset classification.
Classification and forest/threshold implications for general n are analytic inputs,
not established for all n by these finite numerical checks.
"""
from fractions import Fraction as Q
from pathlib import Path
from itertools import product
import argparse,json,sys,platform,time,resource,shlex
sys.set_int_max_str_digits(0)
parser=argparse.ArgumentParser()
parser.add_argument('--output',type=Path,default=Path(__file__).resolve().parent/'grid_certificate.json')
args=parser.parse_args();start=time.perf_counter()
ns=[2,3,4,8,16,32,64,128]
rows=[]
# Rational certificate sqrt(2)/2<3/4: both positive and square difference>0.
sqrt_gap_square=Q(3,4)**2-Q(1,2);assert sqrt_gap_square>0
for n in ns:
    eps=Q(1,n*2**n);a=2-eps
    gap=a**n-(2**n-1)
    assert gap>0 and 2*a>3 and a-1>Q(3,4)
    beta=(eps/2)**n
    assert beta==Q(1,n*2**(n+1))**n
    assert n*beta**2<1
    W=3**n;blocks=2**n;blockmass=2**n
    cellvol=eps**n
    residual=blocks*cellvol
    residual_formula=Q(2)**(n-n*n)/n**n
    assert residual==residual_formula
    assert cellvol==blockmass*beta
    same_threshold_cost=blocks*blockmass
    assert same_threshold_cost==4**n
    ratio=Q(same_threshold_cost,W)
    assert ratio==Q(4,3)**n
    starcost=2**n
    assert starcost<=W and Q(starcost,W)==Q(2,3)**n
    # Positive corner-cell coordinate interval, for sign +, is (a-1,1).
    assert 1-(a-1)==eps
    assert a-1>0 # disjoint sign choices, all lie in central side-2 star cube
    rows.append({'n':n,'a':str(a),'epsilon_side_of_corner_cell':str(eps),'W':str(W),'corner_block_count':str(blocks),'corner_block_mass':str(blockmass),'exact_a_power_minus_2n_minus1':str(gap),'exact_2a_minus3':str(2*a-3),'exact_a_minus1_minus_three_quarters':str(a-1-Q(3,4)),'sqrt2_over2_less_three_quarters_squared_gap':str(sqrt_gap_square),'beta':str(beta),'n_beta_squared':str(n*beta**2),'one_minus_n_beta_squared':str(1-n*beta**2),'single_corner_cell_volume':str(cellvol),'total_residual_volume':str(residual),'residual_formula':'2^(n-n^2)/n^n','same_threshold_original_node_forest_min_total_rootcost_conditional_on_classification':str(same_threshold_cost),'forest_cost_over_W':str(ratio),'central_star_or_lower_threshold_singleton_cost':str(starcost),'star_cost_over_W':str(Q(starcost,W)),'lower_threshold':'2^(-n)','positive_corner_coordinate_interval':['a-1','1'],'exact_formula_residuals':{'volume':'0','beta_mass_volume':'0','forest_ratio':'0','star_ratio':'0'},'all_fixed_n_checks':True})
# Only n=2: all 511 nonempty subsets of the nine actual grid atoms.
n=2;a=Q(15,8);positions=list(product([-a,Q(0),a],repeat=2));N=len(positions)
positive=[];expected=set()
for i in range(N):expected.add(1<<i)
for signs in product([-1,1],repeat=2):
    mask=sum(1<<i for i,p in enumerate(positions) if all(p[j] in [0,signs[j]*a] for j in range(2)))
    assert mask.bit_count()==4;expected.add(mask)
for mask in range(1,1<<N):
    ids=[i for i in range(N) if mask>>i&1];m=len(ids)
    ranges=[max(positions[i][j] for i in ids)-min(positions[i][j] for i in ids) for j in range(2)]
    # width_j<sqrt(m) for every j, certified by exact positive squaring.
    ispositive=all(d*d<m for d in ranges)
    if ispositive:
        assert m in [1,4]
        radius=Q(1 if m==1 else 2) # SIDE length, exact for surviving masses
        lo=[max(positions[i][j] for i in ids)-radius/2 for j in range(2)]
        hi=[min(positions[i][j] for i in ids)+radius/2 for j in range(2)]
        vol=(hi[0]-lo[0])*(hi[1]-lo[1])
        positive.append({'mask':mask,'mass':m,'source_indices':ids,'ranges':list(map(str,ranges)),'C_lower':list(map(str,lo)),'C_upper':list(map(str,hi)),'C_area':str(vol)})
assert {v['mask'] for v in positive}==expected
assert sum(v['mass']==1 for v in positive)==9 and sum(v['mass']==4 for v in positive)==4
blocks2=[v for v in positive if v['mass']==4]
for i,v in enumerate(blocks2):
    for w in blocks2[i+1:]:
        assert any(Q(v['C_upper'][j])<=Q(w['C_lower'][j]) or Q(w['C_upper'][j])<=Q(v['C_lower'][j]) for j in range(2))
        assert v['mask']&w['mask'] and not (v['mask']&w['mask']==v['mask'] or v['mask']&w['mask']==w['mask'])
assert sum(Q(v['C_area']) for v in blocks2)==Q(1,16)
result={'status':'PASS_FIXED_GRID_DIMENSION_FORMULAS_AND_N2_ALL_SUBSETS','dimensions':ns,'rows':rows,'n2_complete_classification':{'positions':[[str(x) for x in p] for p in positions],'subsets_checked':511,'positive_count':len(positive),'singleton_count':9,'corner_block_count':4,'positive_subsets':positive,'exact_residual_area':'1/16','pairwise_corner_cells_disjoint':True,'corner_source_labels_pairwise_crossing':True,'empty_subset_decision':'nonempty iff all coordinate range squared < mass, exact Fraction comparisons'},'analytic_input_boundary':'General classification, shared-center/crossing forest lower-bound implication, and H2 coverage implications are supplied analytically by root/audit. Fixed dimensions numerically verify their stated rational premises; only n2 classification is independently enumerated.','central_star_scope':'A different threshold singleton at origin: threshold 2^-n gives side 2, weighted source cost 2^n. This is not an obstruction to arbitrary-threshold forests.','interpreter':sys.executable,'python_version':platform.python_version(),'command':'OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 '+shlex.join([sys.executable]+sys.argv),'runtime_seconds':time.perf_counter()-start,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'processes':1,'arithmetic_and_comparison_error':'0 (Fraction only)','no_exponential_atom_enumeration':'Only fixed n2 nine atoms / 511 subsets enumerated; all other n use closed rational formulas.'}
args.output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'status':result['status'],'dimensions':ns,'n2_positive_counts':[9,4],'runtime_seconds':result['runtime_seconds'],'peak_rss_bytes':result['peak_rss_bytes'],'forest_ratio_exact':[{ 'n':r['n'],'cost_over_W':r['forest_cost_over_W']} for r in rows]},indent=2))
