# R575 可携带最小复现支撑

实际运行一次 `reproduce.py`，三脚本数学输出均与冻结参考完全一致：`PASS_ALL_THREE_PORTABLE_REPRODUCTIONS`。运行记录见 `reproduction_receipt.json`。

本机实际命令：

`OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 /Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/ccu_r575_repro_support/reproduce.py`

迁移目录后，用安装有NumPy、SciPy、python-flint的Python运行同目录`reproduce.py`；它使用自身目录寻找全部文件，通过当前`sys.executable`运行三个原脚本，输出写临时目录，成功或退出后清理。它只写自身目录的`reproduction_receipt.json`，不覆写原实验输出。

## 目录内容

- 三个原脚本的原样副本：`ccu_r575_numeric.py`、`ccu_r575_grid_certificate.py`、`ccu_r575_quantile_check.py`。
- `lp_input.json`：tree LP实际所需的两个R574 A2 cases，共10,639 bytes；原R574完整输入666,576 bytes未复制。
- `input_manifest.json`：原完整输入SHA256、抽取输入SHA256、逐字段抽取规则。仅保留top-level status及两case的model/A/N/residual_cells/unit_source_positions/exact_volume_E_minus_H_A。status沿用原producer状态以兼容冻结脚本，并不宣称精简包含全部10个case。
- `expected_math.json`：三个冻结输出的数学字段参考，排除时间、RSS、路径、版本与探索性float solver metadata。
- `reproduce.py`与本说明；`reproduction_receipt.json`保存实际解释器、脚本哈希、数学投影哈希、每项返回码、警告、实际资源与时间。

输入抽取只复用已核R574的真实cell-witness incidence，不是几何独立审查。原完整R574 SHA256为`abaa98d2b4eaa3efef251d75b0df97af8ae08129c106b193dee95f54e0b59f20`；精简输入SHA256为`f02a277439431387e798fd2632ba5646d9b224108894ea123df858939f8779b3`。

## 比较与证据类别

复现对数学投影逐字段比较，而不比较运行时间/RSS/路径。LP的float objective、solver message不作证书；其全部Fraction原/对偶feasibility与零gap、完整tree/cell数学结果保留比较。grid的Fraction公式与n2完整枚举结果保留比较；一般classification仍是解析输入。quantile的Fraction rank/mass/bbox、Arb192费用包络字符串保留比较；n3/n8没有β或根计算主张。

Arb显示包络在当前python-flint0.9.0/192-bit设定下复现完全一致；这不是对任意库版本输出格式一致性的保证。即使以后ball格式改变，也不能为了“通过”而忽略其包含性，须重新明确比较方法。

本次运行：Python3.12.14，既定本机venv；三个子程序依次、单进程运行，OPENBLAS/OMP线程均1，单脚本timeout60秒；总实际约0.291秒，全部returncode0，数学结果逐项相同。没有新模型、参数扫描或原几何重算。完成即停。
