# R575 有理格点族：同阈值原节点森林桥的独立审查

**判定：root的有理版本成立。** 它排除“同一原阈值、原source节点receiver覆盖、以R573统一root-mass payer收费”下的polylog-overhead森林桥；不排除一般weak目标、receiver/β加权新payer、真正source refinement或改变阈值的森林路线。后者在本例中有明确廉价覆盖，必须保留此边界。

本次先由给定格点定义独立推导，没有读作者新证明，没有添加其他输入、反例扫描或全subset/tree枚举。只写本文件，不改他人文件/repo，不spawn，无PDF。

## 1. 模型与全部正receiver的穷尽分类

固定整数n≥2、λ=1，令

`a=2−1/(n2^n)`，`ν=Σ_{z∈{−a,0,a}^n}δ_z`，`W=3^n`。

所有原子质量均为1。记δ=2−a=1/(n2^n)>0。Bernoulli给

`a^n=2^n(1−1/(n2^(n+1)))^n≥2^n−1/2>2^n−1`。

因此对质量m<2^n的非singleton S，其某坐标跨度≥a，而r_S=m^(1/n)≤(2^n−1)^(1/n)<a，C_S为空。

若任一坐标同时出现−a与+a，跨度为2a。n≥2时a≥15/8，所以2a>3≥m_S^(1/n)（m_S≤3^n），C_S也为空。反之，不含这种跨度的S，每个坐标至多取两个相邻格点值，故|S|≤2^n。

质量m>2^n于是必有2a跨度，receiver为空。质量m=2^n且C_S非空时，每个坐标必须取两个相邻值，且全部组合都必须存在，否则点数小于2^n。因此它恰为以下2^n个完整corner blocks之一：

`K_σ=Π_j{0,σ_j a}`，`σ∈{−1,+1}^n`。

每个K_σ质量2^n、边长r=2，各坐标跨度a<2，所以确有正receiver。综上，**全部非空C_S恰为3^n个singleton盒与2^n个corner盒**，没有遗漏更大质量/更远尺度的实际见证。此分类依实际tensor格点输入，不是对任意source假定坐标独立。

## 2. 高族、H₂分离与唯一witness

corner因子

`β_K=(1−a/2)^n=(1/(n2^(n+1)))^n<n^-1/2=b`。

空receiver的β为0，singleton β=1。因此R574全高β族只有singletons，greedy选中全部原子；H₂是这些点处半边长h=2^(1/n)/2的闭cube之并。

corner receiver在σ_j=+1坐标是(a−1,1)，在σ_j=−1坐标是(−1,1−a)。不同σ的盒互不相交，边长均δ。对其中任意x及任意grid原子z，每个坐标到格点值的距离都严格大于a−1。而

`a−1≥7/8>√2/2≥2^(1/n)/2=h`。

所以整个C_{K_σ}与H₂不交，且有正开体积δ^n。可直接取P_σ=C_{K_σ}，不用另挑一个中心小片。它也不落入任何singleton C，或其他corner C；结合第1节穷尽分类，K_σ是每个x∈P_σ的**唯一实际source-subset witness**。

严格开C、闭H₂及质量相等的边界无问题：上述距离有统一正间隙。其余C不是仅“零体积”，而是至少一个坐标区间非正、按定义为空。

## 3. 同λ、原节点森林的精确成本障碍

冻结一条合法band，例如L=U=2^n。它包含全部corner节点，ratio=1；全部P_σ都属于完整band残余。考虑任意有限/可求和共同非负weights w_F的原source不复制binary forests：每个node是原label子集，m/r/C使用原unit masses和同一λ=1，根互不交，W_F为真实根总质量。

任意两不同K_σ共享中心原子0，质量同为2^n且互不包含。森林源集laminar，因此每棵forest最多含一个K_σ节点。若没有这个节点，就没有任何原node C能覆盖P_σ；若含它，则其所属根质量至少2^n，故W_F≥2^n。

若共同weights覆盖每个P_σ几乎处处，唯一witness使

`Σ_{F: K_σ为node} w_F≥1`。

2^n个σ分别求和，而每棵forest至多进入一项，得到

`Σ_contributing F w_F≥2^n`，

`Σ_F w_F W_F≥2^n·2^n=4^n`。

这允许任意多棵forest，不是只否定一棵树。相对原W=3^n，必要overhead至少(4/3)^n，故不能在此结构合同下对所有输入取得polylog(n)或n^o(1)的weighted root总费。乘上R573的14√n payer只会保留这一指数overhead；它不表示receiver的真实体积或weak常数有此下界。

该成本下界可达：对每个σ取以K_σ为唯一根的森林（需要时在其内部二叉细分），weight=1，即根总费4^n。

若限制为全原子full-root trees，每棵根质量均W，覆盖所需

`Σ_T w_T≥2^n`。

同样可达：每个σ各取一棵包含K_σ的full tree，weight=1。故该有限族的exact full-tree LP optimum为2^n；每棵只能cover一个P-group，给每个group取一个cell的dual weight1即是直接下界证书。无须枚举巨量树才知道这个值。

## 4. 已有高D carriers为何不改变此下界

在同一λ=1、b=n^-1/2下，高β nodes只有singletons。其R573 D_node是unit cube，已经包含于R574的H₂，故不能覆盖任何P_σ。给forest列加入这些已合法支付的高D盒，不会改变第3节结论。

不能因低β K的某个更大carrier能cover其他P就把它按同一个14√n payer免费加入；它不满足该high pruning条件，须另证真实费用。改变payer、β权、source分配或阈值后，已不属于本次反证合同。

## 5. 实际receiver预算反而很小

所有corner C都在Q(0,2)=(-1,1)^n内，所以一个共同star carrier直接覆盖全部非singleton receivers，体积/λ费为2^n≤W。这里不要求把所有corner labels放入同一laminar节点。

精确非singleton union也已知：2^n盒互不交，每个体积δ^n，因此

`|E₁\H₂|=2^nδ^n=2^(n−n²)/n^n`。

singleton unit cubes也两两不交，并与这些corner盒分离，所以完整level体积为3^n加上述小量。此处没有一般weak常数的指数下界。若允许按实际receiver体积或βm给节点收费，此族同样没有第3节那种root-mass费用障碍。

## 6. 改阈值森林是明确的逃逸，不可遗漏

取只含中心原子δ₀的单source forest，真实根质量W_l=1，但使用较低阈值

`λ_l=2^-n`。

其singleton阈值边长为2，receiver正是Q(0,2)，覆盖全部P_σ。取weight1，按正确阈值比记账，weighted root费用为

`(λ/λ_l)W_l=2^n≤3^n=W`。

若仍调用R573粗14√n payer，所得费用至多14√n·2^n，也没有相对W的指数overhead。实际star体积则直接只费2^n。故本族**不能**排除允许λ_l改变且支付阈值比的forest路线；它直接展示为什么验收合同必须允许/准确计价这种适配。

同样不应扩大到任意fractional source splitting或copy输入：本证明的唯一witness分类、laminar交叉及m_K=2^n均针对原unit masses的原节点。纯label重命名不改变它；若把同一原子复制到不同分支仍宣称原source不复制，则违反前提。真正质量细分、改变节点质量/位置或非同阈值，需要独立验证coverage及source/阈值费用，本次既不否定也不免费授权。

## 7. 量词、实际核验及最终范围

反例对每个n≥2给一个有限正原子输入、一个λ=1和一条合法mass band；这足以否定对所有输入/带均有polylog source-overhead的同阈值原节点森林桥。weights对整个receiver集合共同固定；不能按每个P另选weights而省掉它们的总费用。结论对a.e.覆盖也成立，因为每个P有正开体积。

一般证明是上述全n解析推导。只实际运行了本机Python Fraction的标量控制：`(7/8)^2−1/2=17/64>0`；n=2时a=15/8、β=1/256、残余体积1/16、source-sensitive下界16、full-root weight下界4、lower-threshold source费4≤W=9。没有枚举source subsets、trees或新模型，也未从这些控制外推维数。

最终：同λ原node forest/旧high-D、uniform root-mass payer桥的polylog overhead被本族解析否定；R573给定森林定理本身仍真。一般weak目标、receiver/β加权新payer、signed或变阈值新机制均未被否定。变阈值central-source覆盖是已核的具体class boundary，不是新的统一一般定理。按任务完成停止。
