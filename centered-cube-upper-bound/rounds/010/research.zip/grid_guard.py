from fractions import Fraction as F
from itertools import product
from math import prod,log,sqrt
import json
# Exact periodic containment by integration over one shift period.
def count_period(x,L,H):
 lo=x-L/2;hi=x+L/2
 # shift U in [0,H); boundaries at U+kH. Changes only at lo,hi mod H.
 cuts=sorted({F(0),H,lo%H,hi%H});good=F(0)
 for a,b in zip(cuts,cuts[1:]):
  u=(a+b)/2
  kl=(lo-u)//H;kh=(hi-u)//H
  good+=(b-a)*int(kl==kh)
 return good/H
contain=[]
for H in map(F,['3','4','8']):
 for L,x in product(map(F,['1','3/2','2']),map(F,['-7/3','0','5/7'])):
  actual=count_period(x,L,H);assert actual==1-L/H
  contain.append({'H':str(H),'L':str(L),'x':str(x),'exact_retention':str(actual)})
anisotropic=[]
# Same volume, unequal side lengths: parameterization makes geometric mean rational.
for n in [2,4,8]:
 for t in [F(4),F(8),F(16)]:
  for ratio in [F(1),F(3,2),F(2)]:
   sides=[t*ratio,t/ratio]+[t]*(n-2)
   assert prod(sides)==t**n
   actual=prod(1-1/h for h in sides);optimal=(1-1/t)**n
   assert actual<=optimal
   anisotropic.append({'n':n,'geometric_mean_side_over_b':str(t),'ratio':str(ratio),'retention':str(actual),'isotropic_retention':str(optimal)})
# Full fixed-query loss vs partial-source splitting is intentionally distinguished.
# These are display-only searches for the explicit analytic certificate, not a proof.
tradeoff=[]
for n in [4,16,64,256]:
 ts=sorted(set([1.01+j*(16*n-1.01)/4000 for j in range(4001)]+[2.0*n,sqrt(n)]))
 logvalues=[log(n)+log(log(2*t))-n*__import__('math').log1p(-1/t) for t in ts]
 j=min(range(len(ts)),key=lambda j:logvalues[j]);best=__import__('math').exp(logvalues[j])
 at2n=F(2*n-1,2*n)**n
 assert at2n>=F(1,2)
 tradeoff.append({'n':n,'sampled_min_t':ts[j],'sampled_min_certificate':best,'min_over_n_log_n_display':best/(n*log(n)),'comparison_domain':'logarithmic to avoid overflow','exact_retention_at_2n':str(at2n),'scope':'finite floating parameter exploration; analytic lower bound proved separately'})
# Single-scale complete-source localization with high/low cells.
# Integrate both receiver x and shifts u by exact partitions, n=1.
local=[]
for points,weights in [([F(-1),F(0),F(3,2)],[F(1),F(2),F(1)]),([F(-1,4),F(1,4)],[F(1,2),F(1,2)]),([F(-2),F(-1),F(0),F(1),F(2)],[F(1)]*5)]:
 for lam in [F(1,4),F(1),F(2)]:
  H=F(3);L=F(1);cuts=sorted({y+sgn*L/2 for y in points for sgn in [-1,1]});original=retained=F(0);checks=0
  for l,r in zip(cuts,cuts[1:]):
   x=(l+r)/2;mass=sum((w for y,w in zip(points,weights) if abs(x-y)<L/2),F(0))
   if mass>lam:original+=lam*(r-l)
   # Containment is exact at every x; its constant probability can be integrated.
   cp=count_period(x,L,H);assert cp==1-L/H
   if mass>lam:retained+=lam*(r-l)*cp
   checks+=1
  assert retained==(1-L/H)*original
  local.append({'points':[str(x) for x in points],'weights':[str(w) for w in weights],'lambda':str(lam),'original':str(original),'retained':str(retained),'cells':checks,'scope':'exact single-query containment and Lebesgue integration; not a general maximal estimate'})
multi=[]
for n in [1,2,3]:
 pts=list(product([F(-1,4),F(1,4)],repeat=n));Ls=[F(1),F(3,2),F(2)];H=F(4)
 cuts=sorted({y[0]+sign*L/2 for y in pts for L in Ls for sign in [-1,1]})
 for lam in [F(1,8),F(1,2)]:
  original=retained=F(0);cells=0
  for ids in product(range(len(cuts)-1),repeat=n):
   x=[(cuts[j]+cuts[j+1])/2 for j in ids];vol=prod(cuts[j+1]-cuts[j] for j in ids)
   vals=[sum((F(1,len(pts)) for y in pts if all(abs(xx-yy)<L/2 for xx,yy in zip(x,y))),F(0))/L**n for L in Ls]
   if max(vals)>lam:
    L=Ls[vals.index(max(vals))];cp=prod(count_period(xx,L,H) for xx in x)
    assert cp==(1-L/H)**n
    original+=lam*vol;retained+=lam*vol*cp
   cells+=1
  assert retained>=(1-F(2)/H)**n*original
  multi.append({'n':n,'lambda':str(lam),'cells':cells,'original':str(original),'retained_true_winner':str(retained),'uniform_min_retention':str((1-F(2)/H)**n)})
# Optimize both available cell-mass prices before optimizing the grid.
from math import exp,log1p
C=8/3
def softplus(x):return x+log1p(exp(-x)) if x>0 else log1p(exp(x))
def log_kstar(logv):
 if logv<=log(C*(1+log(17))):return logv
 lo=0.;hi=logv
 for _ in range(90):
  x=(lo+hi)/2
  # v/z = C*(1+log(1+16z)); the sides are strictly monotone.
  if logv-x>log(C)+log1p(softplus(log(16)+x)):lo=x
  else:hi=x
 return logv-(lo+hi)/2
optimized=[]
for n in [4,16,64,256]:
 ts=[1.01+j*(16*n-1.01)/1000 for j in range(1001)]+[2.*n]
 logs=[log_kstar(n*log(2*t))-n*log1p(-1/t) for t in ts];j=min(range(len(ts)),key=lambda i:logs[i]);value=exp(logs[j])
 optimized.append({'n':n,'sampled_best_t':ts[j],'mass_optimized_certificate':value,'ratio_to_n_log_n':value/(n*log(n)),'scope':'floating bisection/finite t exploration in log domain; rigorous order from proof'})
print(json.dumps({'status':'PASS','one_coordinate_containment':contain,'anisotropy':anisotropic,'tradeoff_exploration':tradeoff,'complete_source_checks':local,'true_winner_full_space':multi,'mass_price_optimization':optimized},indent=2))
