# R503 独立预审：实际共同质量分母

本预审先于阅读任何 R503 作者证明。设 \(d\mu=f\,dx\)、\(W=\mu(\mathbb R^n)<\infty\)，\(C,D\) 两两不交（\(\mu\)-a.e.），\(M=\mu C,N=\mu D\)。固定边长 \(R\)，记
\[
q=f*h_R,\quad a=(f1_C)*h_R,\quad b=(f1_D)*h_R,
\quad h_R=R^{-n}1_{Q(0,R)}.
\]
把实际中心集合与接受密度合成 \(w=t1_E\in[0,S]\)，则 \(d\nu=wq\,dB\)。所有零分母项置零：\(q=0\) 时 \(a=b=0\)。

**可直接使用的共同分母恒等式。** 实际部分捕获被完整保留：
\[
T_{CD}:=\int p_Cp_D\,d\nu=\int w\frac{ab}{q}\,dB.
\tag{1}
\]
令 \(\tilde a=wa,\tilde b=wb,\tilde q=wq\)，\(r=\tilde q-\tilde a-\tilde b\ge0\)，以及 \(A=\int\tilde a,B_0=\int\tilde b\)。当 \(A+B_0>0\) 时有精确正缺陷分解
\[
T_{CD}=\frac{AB_0}{A+B_0}
-\int(\tilde a+\tilde b)
 \left(\frac{\tilde a}{\tilde a+\tilde b}-\frac{A}{A+B_0}\right)^2dB
-\int\frac{\tilde a\tilde b r}{(\tilde a+\tilde b)\tilde q}\,dB.
\tag{2}
\]
\(A+B_0=0\) 时全式为零。这同时保留后验分离的方差信用与其他来源稀释的信用。固定尺度由 Tonelli 得
\[
A=\int_C\!\mu(dx)\int w(B)h_R(B-x)dB\le SM,
\quad B_0\le SN,
\quad T_{CD}\le S\frac{MN}{M+N}.
\tag{3}
\]
此处没有包围盒或密度上帽。对全中心 \(w=1\) 且 \(C\cup D\) 为全来源，式 (2) 仅余真实后验方差。不能反向套用卷积 Jensen：\(ab/(a+b)\) 的凹性给点态卷积下界，所需上界来自积分后的 Cauchy。

另一个合法固定尺度工具是条件 Cauchy：对来源函数 \(F\in L^2(\mu)\)，
\[
\int w(B)\frac{|(fF*h_R)(B)|^2}{q(B)}dB
\le S\int |F|^2d\mu.
\tag{4}
\]
它使用同一个实际 \(q\)，并非将两来源分别归一。若 \(F\) 依赖父中心、mark 或原历史，点态条件 Cauchy 仍可用，但右侧必须保留该依赖及真实来源列。

**冻结可变 selector 的代价。** 当实际 \(R_B\in[a,b]\) 可测时，(1)–(2) 仍逐点精确；但 \(\int a\) 不再等于 \(M\)。准确负载为
\[
A=\int_C L_w(x)\,d\mu(x),\qquad
L_w(x)=\int_E t(B)R_B^{-n}1_{Q_B}(x)dB.
\]
中心 Lebesgue 的尺度层蛋糕（包括底部项）仅直接给
\(L_w\le S[1+n\log(b/a)]=SA_n\)。故 (3)、(4) 的通用可变尺度版本须付 \(A_n\)，例如 \(T_{CD}\le SA_n MN/(M+N)\)。不能先逐尺度证明 (4)，再免费把积分内换成全尺度 supremum；也不能为不同来源或来源对重新选择半径。

**对原同权积分的适用范围。** 若原项另带 head、rank、void、\(G\) 或接受历史权，必须在 (1) 的双来源积分内保留它，或明确以非负上界删除并记录放松。特别是 \(u,G\) 与父质量不能从该式自动交换。式 (2) 的两个负信用可能是可用的共同质量机制，但将它们跨来源格、父或尺度相加后取得根阶费用，仍需单独证明；上述固定尺度收据本身没有支付全体原余项。

本机指定 Python 实跑 `/tmp/r503_audit_math_check.py`：13 项 SymPy/Fraction 检查通过，核共同分母分解、零负载、有限归一平均核的负载与 L² 不等式。它只是有限平均模型的代数辅助，不认证真实连续 selector 或原历史，也不是一般证明的替代。预审交付后等待作者稿。
