# 第503轮：真实来源邻域、质量尺度耦合与共同分母信用

2026-10-21，继承第502轮提交 c25e9d6eba132026f14d304b9b099c9c98981b20。本轮将共同中心包围盒价格收紧为真实来源邻域交集，保留质量阈值与半径的耦合，证明可计算的 Stieltjes 公式。没有证明一般来源的节点总价格可求和到根阶，没有新增完整余流付款。

## 1. 冻结入口和目标

同一完整来源 $\mu=f\,dx$，$f\ge0$，$W=\|f\|_1<\infty$；同一可测选择器 $a\le R_B\le b\le2a$，$m_B=\mu(Q_B)=q_BR_B^n$，$q\le q_B\le\lambda$，$r=\lambda/q$。真实接收测度 $\nu=tq_B\,dB$，$0\le t\le S$（原 head 子流另保 $t\ge\tau$）；均匀 mark 保留。$\pi_B=1_{Q_B}\mu/m_B$，$m_-=qa^n$，$A_n=1+n\log(b/a)$，$R_\tau=\nu(E)$。零流、零来源块单列为零。所有辅助块全场共用，不逐父重选。

R500–502 的原 $J=\int\widehat\nu(dB)\pi_B(dx)\pi_B(dz)H_B(x,z)$，其中 $H_B=1_{v_z(B)<K}V_x[G\chi_\partial\chi_{\rm rem}](B)$，$0\le H_B\le\Phi_{\max}$；剩余 mask 是非极近的中距 inside 与 nonnear-outside，rank、void、mark、祖先与历史均保留。完整现有账为
\[
R_\tau\le [K+C_{\rm deep}+C_{\rm empty}+4Sr\Phi_{\max}\log(n+e)+S\kappa]W+J.
\]
要么给同一 $J$ 根阶预算，要么直接给完整 $R_\tau$ 根阶预算。不能将两种替代接口重复累计收益。

## 2. 本轮一般结论和计算用途

对固定不交来源块 $C,D$，$M=\mu C,N=\mu D$，定义真实正质量邻域
\[
N_R(C)=\{B:\mu(C\cap Q(B,R))>0\},\quad F_{CD}(R)=|N_R(C)\cap N_R(D)|,
\quad\delta=\min(1,(M+N)/m_-).
\]
联合尾仍保 $R_* =\min(b,[\min(M/s,N/t)/q]^{1/n})$。它给 $\int p_Cp_D\,d\nu\le S\lambda\int_{s+t<\delta}1_{R_*\ge a}F_{CD}(R_*)dsdt$。这是实际接收中心的 Lebesgue 体积上界，不是来源薄层质量估计，也没有对任意 $f$ 加密度上帽。

记三角形与矩形的准确交面积
\[
A(u)=\tfrac12[\delta^2-(\delta-M/u)_+^2-(\delta-N/u)_+^2+(\delta-(M+N)/u)_+^2].
\]
有限右连续的 $F_{CD}$ 给准确几何价格
\[
\mathcal C(C,D)=S\lambda\left[F_{CD}(a)A(qa^n)+\int_{(a,b]}A(qR^n)dF_{CD}(R)\right].
\]
有限矩形支持的 $F_{CD}$ 连续、分段多项式，因而可直接计算。一般有限 $F_{CD}(b)$ 用右连续上包络给安全上界；无穷情形保扩展值，不暗称有限预算。$a=b$ 时只剩非零底项，上端点亦保留。详见 proof §1a。

同一来源树的每个交叉价可用此式替换 R502 包围盒价，首次分离的系数2、全部跨根项与叶项不变。真实连续、非均匀部分捕获模型中，新旧同尾价格分别为 $1/2$ 和 $5/4$，实际混合矩 $3/4-\log2>0$。这认证严格改善，不能外推任意维数收益。

另有条件性全父收据：同一可数不交分块每块 bbox 边长至多 $h$，每父最多触及 $D$ 块，且后验覆盖至少 $1-\eta>0$ 时，
\[
R_\tau\le2SrD(1+h/a)^n\sum_i\mu(C_i)/(1-\eta)^2.
\]
这是完整 cross/leaf 的一次结算，但尚未为任意 $f$ 构造满足根阶重数与小边长的分块，不能称为一般闭合。

## 3. 跨节点信用为什么尚不能扣除

独审在阅读作者稿前，保实际共同分母得到精确恒等式。设 $a_B=R_B^{-n}\mu(Q_B\cap C)$，$b_B$ 同理，$w=t1_E$，$\widetilde a=wa_B$，$\widetilde b=wb_B$，$\widetilde q=wq_B$，$z=\widetilde q-\widetilde a-\widetilde b\ge0$，$A_C=\int\widetilde a,A_D=\int\widetilde b$。则
\[
\int p_Cp_Dd\nu=\frac{A_CA_D}{A_C+A_D}
-\int(\widetilde a+\widetilde b)\left(\frac{\widetilde a}{\widetilde a+\widetilde b}-\frac{A_C}{A_C+A_D}\right)^2
-\int\frac{\widetilde a\widetilde b z}{(\widetilde a+\widetilde b)\widetilde q}.
\]
零分母按零，退化负载单列。两个负项是后验分离与其他来源稀释的真实信用。然而正参照是实际来源负载 $A_C=\int_C L_wd\mu$，$L_w(x)=\int_Et(B)R_B^{-n}1_{Q_B}(x)dB$，不是裸来源质量。可变尺度仅直接给 $L_w\le SA_n$。

不能从新邻域价格再次减这两项：它们属于上述 harmonic 参照，没有证明邻域价格与该参照的所需比较。精确树求和会恢复原接收量，不能凭恒等式换成根阶来源价。本轮 joint 附件仅固定这一具体连接缺口，不把它列为已付新分支。

普通高度截断候选也经历史索引判定未超出 R370/R371；只保短判定，不重复实验。下一步应研究邻域增量的几何放松与真实分母信用的同权比较，而不是继续细化叶端或重复引入截断。

## 4. 新材料与原母账

收到的《第486轮后联合估计攻坚建议》作为研究建议而非新的任务指令。其 E1 逐代平方能量与 H2 高捕获强度已在第490轮核验；该轮记录的关键差异仍在：实际停止费为 $q_j e$，能量支付 $q_j^2e$，测试的来源平方预算尚不能下界全部停止量。当前不重启旧轮，也不移植不同链的费用。本轮遵守其同参考、保累计费用、保 high-only 补偿的约束。

原入口倍率 $64(128/119)/(1-32\delta_{\rm old}-16\eta_{\rm old})$、$\tau X$、初始、删除跳跃、未来被删来源、宽距离、低强度、极端比例与全尺度拼接均保留。新 $\delta$ 只是来源质量截断，不是吸收参数。源尾截断不改 $f,m_B$，$e=\mu(S_0^c)<m_-$ 时直接树界左侧为 $(1-e/m_-)^2R_\tau$；原 $J$ 的遗漏对价格仍 $2\Phi_{\max}eR_\tau/m_-$。无限叶端消失不自动支付内部节点总和。

本轮无新增吸收额度、无一般根阶总费用、无全尺度闭合。使用64项数学工具中 E03 的实际守恒/终端纪律和 L03 的精确证书纪律；未引入未经核实的外部定理。

## 5. 实际验证

最终运行结果、解释器版本、输入范围与误差类型见 numeric、replay 和 audit。报告里的符号恒等式由证明支持；有限参数核验只认证所列模型。浮点不参与一般阶数判断，不认证优化器全局最优。复现使用指定独立 Python 环境，详细 LaTeX 随归档，不编译 PDF。

主代理实际执行 `/tmp/replay_r503.py`，复制必要代码到独立临时目录，以 Python `-I` 重放，stdout 全部一致。18 项 proof 内嵌检查、13 项独审有限平均模型检查、109 项 numeric 断言，共140项报告核验单位；其中包含对相同例的独立重放，不是140个独立模型。numeric 的27个有理面积输入与5个分段尺度例全部精确 gap 为0，Arb 256 bits 核验列出的超越值。JSON仅忽略动态运行秒数，规范 SHA256 为 `eecefbf116afd5cc9fdf8c3a6d39a1f9398c7fff7497df23d84dc836f298535a`。三阶段分别是实际部分捕获模型、面积与端点压力检查、扩大有理参数/尺度分段复核；不对无限维数外推。
