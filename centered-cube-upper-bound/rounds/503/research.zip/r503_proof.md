# R503：真实来源邻域交集及一次分块费用

保留 R502 的同一真实场：\(\mu=f\,dx\)、\(W<\infty\)，立方体边长 \(a\le R_A\le b\le2a\)，\(m_A=\mu(Q_A)=q_AR_A^n\)，\(q\le q_A\le\lambda\)，\(r=\lambda/q\)，\(\nu(dA)=t(A)q_A,dA\)、\(0\le t\le S\)。概率 mark 同时积分。记 \(m_-=qa^n\)、\(R_\tau=\nu(E)\)。本稿保完整来源和选择器，证明 bbox 联合尾的严格加强及一个可检验的整体分块价；没有构造适用于所有来源的根阶分块。

## 1. 不依赖来源代表元的真实邻域

对可测来源块 \(C\)，定义
\[
N_R(C)=\{A:\mu(C\cap Q(A,R))>0\}.
\]
这是 \((f1_C)*1_{Q(0,R)}\) 的正集，联合可测，对 \(\mu\)-零集修改不变；固定 \(R>0\) 时卷积连续。它单调随 \(R\) 增大。这里不是把原来源块的 Lebesgue 体积当作质量。

取固定不交块 \(C,D\)，\(M=\mu C,N=\mu D>0\)，并令
\[
\delta=\min\{1,(M+N)/m_-\},\quad
R_*(s,t)=\min\{b,[\min(M/s,N/t)/q]^{1/n}\}.
\]
若 \(p_C(A)>s,p_D(A)>t\)，则 \(m_A<\min(M/s,N/t)\)、\(R_A\le R_*\)，所以
\[
\nu\{p_C>s,p_D>t\}
\le S\lambda\,|N_{R_*}(C)\cap N_{R_*}(D)|.\tag{1}
\]
当 \(R_*<a\) 时右侧应置零；\(R_*=a\) 仍允许非空，不能删掉固定边长场。完整分母还给 \(p_C+p_D\le\delta\)。因此
\[
\int p_Cp_D\,d\nu\le S\lambda\,\mathcal A(C,D),\qquad
\mathcal A(C,D)=\int_{s,t>0,\ s+t<\delta}
1_{R_*\ge a}|N_{R_*}(C)\cap N_{R_*}(D)|\,dsdt.\tag{2}
\]
证明只是同一场的质量约束、集合包含与 Tonelli，不重选半径或来源树。无界来源可使该几何上界无穷，不能隐去这一情形。

若存在 R502 的本质 bbox，则真实邻域包含于相应扩大盒；故
\[
S\lambda\mathcal A(C,D)
\le Sr\,V_{CD}\delta\mathcal E(M,N).\tag{3}
\]
对有限个有正密度的来源矩形，\(N_R\) 是这些矩形分别扩大 \(R/2\) 后的并，边界不影响中心体积。交集体积可通过坐标端点分割精确求和；它不先将整个并集填成 bbox。第 4 节给出非零、真实匹配的严格改善。

对同一个固定有限来源树，R502 精确首次分离式不变：
\[
J(S_0^2)=2\Phi\sum_{C,D}\int p_Cp_D\theta_{CD}\,d\nu
+\sum_{L\text{ 叶}}J(L^2).
\]
其中 \(\theta_{CD}\) 仍是原两方向接受权的真实条件平均。仅在上界时使用 \(\theta\le1\)，于是交叉项可付 \(2S\lambda\Phi\sum\mathcal A(C,D)\)；叶项保持原样或用 R502 的真实叶价。对 \(H\equiv1\) 则去掉 \(\Phi\)，直接估计 \(R_\tau\)。这两入口择一，不重复计价。不允许只保同一森林根内 pair、遗漏跨根 pair。

## 1a. 联合尾的单变量 Stieltjes 公式（保基项）

固定同一对来源块，令 \(F(R)=|N_R(C)\cap N_R(D)|\)，并定义
\[
A(u)=\frac12\left[\delta^2-(\delta-M/u)_+^2
-(\delta-N/u)_+^2+(\delta-(M+N)/u)_+^2\right],\qquad u>0.
\tag{3a}
\]
它恰为 \(\{s,t>0:s+t<\delta,\ s<M/u,\ t<N/u\}\) 的面积。证明是在面积 \(\delta^2/2\) 的三角形中，分别平移去掉 \(s\ge M/u\)、\(t\ge N/u\) 两角，再加回其交集；边界为零面积。

**精确版本。** 若 \(F\) 在 \([a,b]\) 有限、非减且右连续（在 \(b\) 向右常值延拓），则式 (2) 的几何价格准确为
\[
\boxed{S\lambda\mathcal A(C,D)=S\lambda\left[
F(a)A(qa^n)+\int_{(a,b]}A(qR^n)\,dF(R)\right].}\tag{3b}
\]
这里 \(dF\) 是 Lebesgue–Stieltjes 测度，积分在 \((a,b]\) 而非 \([a,b]\)；\(F(a)\) 已单独支付。对每个 \(R_*\ge a\)，
\[
F(R_*)=F(a)+\int_{(a,b]}1_{R\le R_*}\,dF(R).
\]
乘 \(1_{R_*\ge a}\) 并在三角形上 Tonelli 积分即可：对任意 \(a\le R\le b\)，事件 \(R_*\ge R\) 的面积正是 \(A(qR^n)\)。严格/非严格质量门只改变此二维 Lebesgue 积分的零集。\(R_*=b\) 通常具有正面积，故不得删除 \(b\) 端点；若 \(dF\) 在 \(b\) 有原子，它必须保留。若 \(a=b\)，积分为空，价格为 \(S\lambda F(a)A(qa^n)\)，不是零。

若 \(f1_C,f1_D\) 的本质支持各为有限个有正密度的非退化矩形的并，则扩大矩形的交并体积 \(F\) 连续、分段多项式。坐标端点排序只有有限次改变；在每个区间作有限矩形的包含排除或网格体积求和即可。因此 (3b) 是可计算的一维加权积分，而非仅在符号上重命名二维尾。

**任意来源的安全版本。** 一般 \(F\) 由集合包含非减、可测，但本稿不额外断言其右连续。若 \(F(b)<\infty\) 且 \(a<b\)，取
\[
\overline F(R)=\lim_{s\downarrow R,\,s\le b}F(s)\quad(a\le R<b),
\qquad \overline F(b)=F(b).
\]
它是有限非减右连续包络，\(\overline F\ge F\)，于 \(b\) 向右常值延拓。故严格成立
\[
S\lambda\mathcal A(C,D)\le S\lambda\left[
\overline F(a)A(qa^n)+\int_{(a,b]}A(qR^n)\,d\overline F(R)\right].\tag{3c}
\]
若 \(a=b\)，直接使用实际 \(F(a)\) 的基项，无需包络。若 \(F(b)=\infty\)，不从 (3c) 宣称有限价格；可先把中心限制在固定有界窗口，应用同一证明后单调扩张窗口，所得上界仍可能无穷。这里不改来源测度或 matching。有限盒情形用 (3b) 等式；一般情形只需 (3c) 上界，不为连续性引入未经证明的假设。

该公式保留全部半径尺度及质量阈值，但本身没有证明树节点费用可求和，也不改变原接受权的范围。以下本机符号检验是具体端点/尺度例，而非一般证明：取 \(M=N=q=1,n=1,\delta=1,a=1,b=2\)，来源区间 \(C=[-1,0],D=[1/2,3/2]\) 上各密度 1，则 \(F(R)=R-1/2\)。直接二维尾积分与 (3b) 都为 \(\log4-3/4\)；固定边长 \(a=b=1\) 时两者都为 \(1/4\)。

```python
import sympy as s
u,x=s.symbols('u x',positive=True)
area=(1-2*(1-1/u)**2)/2  # 1 <= u <= 2
rhs=s.Rational(1,2)*s.Rational(1,2)+s.integrate(area,(u,1,2))
# Symmetry s>=t: triangle section length min(s,1-s).
lhs=2*(s.integrate(s.Rational(3,2)*x,(x,0,s.Rational(1,2)))
       +s.integrate((1/x-s.Rational(1,2))*(1-x),
                    (x,s.Rational(1,2),1)))
assert s.simplify(lhs-rhs)==0
assert s.Rational(1,2)*area.subs(u,1)==s.Rational(1,4)
print('2 Stieltjes/base assertions PASS; price =',s.simplify(rhs))
```

实际 stdout：`2 Stieltjes/base assertions PASS; price = -3/4 + log(4)`。

## 2. 可一次结算完整 cross/leaf 的明确范围

设 \(\{C_i\}\) 是固定、至多可数的不交来源块，每块本质 bbox 各边长至多 \(h\)。假设对 \(\nu\)-几乎所有真实父：
\[
\#\{i:A\in N_{R_A}(C_i)\}\le D<\infty,\qquad
\pi_A\Big(\bigcup_iC_i\Big)\ge1-\eta>0.
\tag{4}
\]
则有整体上界
\[
\boxed{R_\tau\le
\frac{2SrD(1+h/a)^n}{(1-\eta)^2}\sum_i\mu(C_i).}\tag{5}
\]
证明：逐父 Cauchy 给 \(\sum_i p_i^2\ge(1-\eta)^2/D\)。R502 单块尾与真实质量截断给
\[
\int p_i^2\,d\nu\le2Sr(1+h/a)^n
\min\{1,\mu(C_i)/m_-\}\mu(C_i).
\]
求和并舍去最后的截断即得 (5)。原始证明也保留该截断，可使小质量块更便宜。该论证对完整父后验先求平方和，再恢复全部质量，故没有遗漏跨块来源对，也没有逐块重复付一份 \(W\)。它与第 1 节的树价是替代结算方式。

条件 (4) 可由真实邻域的重数检验；充分条件是在 \(E\) 上 \(\sum_i1_{N_b(C_i)}\le D\)。若尾质量 \(e=\mu((\cup_iC_i)^c)<m_-\)，则无需改 \(f,m_A,q_A\)，直接取 \(\eta=e/m_-\)。若 \(h\le ca/n\)、\(\eta\le\eta_0<1\)、\(D\le D_0\sqrt n\log^A(n+2)\)，(5) 确给相应根阶来源价。

这不是一般来源构造：对 diffuse 来源的很细网格，一个父可能触及大量块；对合并后的稀疏块，bbox 又可能很大。当前未证明能够同时控制重数与块尺度，亦未证明所有真实邻域树交叉价的总和具有根阶。这里只记录可验证的整体适用条件和真实局部严格改善，不以重新定义 \(\mathcal A\) 或取树 inf 当成一般付款。

## 3. 无限细化与原 mask 的纪律

邻域替换仅改变非负交叉项的上界，故有限树到无限树仍以 R502 的首次分离单调收敛处理。若叶最大质量 \(\epsilon_k\to0\)，实际叶残项至多 \(\Phi\epsilon_kR_\tau/m_-\)，不需先控制叶 bbox。这里 \(R_\tau\le S[1+n\log(b/a)]W<\infty\)。无界来源先取有界 \(S_0\)，尾质量 \(e\) 不改原 matching；直接接口为 \((1-e/m_-)^2R_\tau\)，原 \(J\) 的遗漏 pair 至多 \(2\Phi eR_\tau/m_-\)。这些终端结论不支付无限内部几何价。原 rank、void、history 和剩余 mask 只留在 \(\theta\) 内，未向新来源块或辅助中心迁移。

## 4. 本机精确核验（静态真实中心，不认证原 history）

取 \(n=1,a=b=1,S=1\)。来源为三个宽 \(1/4\) 的区间，中心分别为 \(-1,0,1\)，密度分别为 \(4,4,8\)。令 \(C\) 为左右两块、\(D\) 为中块。真实中心 \(A\in[3/8,5/8]\) 使用同一边长 1，故
\[
\mu(Q_A\cap C)=8(A-3/8),\quad
\mu(Q_A\cap D)=4(5/8-A),\quad
m_A=4A-1/2\in[1,2].
\]
因此实际 qband 是 \(q=1,\lambda=2\)，全来源质量 \(W=4\)，\(R_\tau=3/8\)。真实扩大邻域交集体积为 \(1/2\)，bbox 扩大交集为 \(5/4\)。在同一 \(R_*\) 与同一 triangle 上，(2) 价格分别为 \(1/2\) 与 \(5/4\)，严格改善。实际积分为 \(3/4-\log2>0\)，不只是空域例。另将外侧来源移至 \(\pm3\)，取三个完全捕获的正中心区间，仍有完整 qband 匹配，此时真实交叉积分为零而 bbox 价格仍正。

以下脚本完整内嵌，实际以本机数学 Python 运行。三阶段分别检查分离来源、非零 partial capture、四个真实集合间距的扩张交集；后者是几何量核验，不新增原 history 认证。

```python
from fractions import Fraction as F
import sympy as s

def length(intervals):
    intervals=sorted((l,r) for l,r in intervals if l<r)
    out=[]
    for l,r in intervals:
        if out and l<=out[-1][1]:
            out[-1]=(out[-1][0],max(out[-1][1],r))
        else: out.append((l,r))
    return sum((r-l for l,r in out),F(0))

def common(d):
    rad=F(5,8)
    return length([(max(c-rad,-rad),min(c+rad,rad))
                   for c in [-d,d]])

checks=0
# Stage 1: packets at -3,0,3; widths 1/4, masses 1,3/2,2.
assert common(F(3))==0; checks+=1
masses=[F(1),F(3,2),F(2)]
assert all(F(1)<=m<=2 for m in masses); checks+=1
R=sum(F(3,4)*m for m in masses)
assert R==F(27,8) and sum(masses)==F(9,2); checks+=1
# Each center interval has length 3/4 and captures its own full packet only.
assert 2*F(3,8)+F(1,4)==1; checks+=1

# Stage 2: actual selector R_A=1, A in [3/8,5/8].
x=s.symbols('x',real=True)
lo,hi=s.Rational(3,8),s.Rational(5,8)
c=8*(x-lo); d=4*(hi-x); m=4*x-s.Rational(1,2)
assert s.expand(c+d-m)==0; checks+=1
assert m.subs(x,lo)==1 and m.subs(x,hi)==2; checks+=1
pair=s.simplify(s.integrate(c*d/m,(x,lo,hi)))
assert pair==s.Rational(3,4)-s.log(2); checks+=1
# Exact positivity and upper bound: log2=integral_1^2 dt/t lies in (1/2,3/4).
assert s.integrate(m,(x,lo,hi))==s.Rational(3,8); checks+=1
leaf=s.integrate((c*c+d*d)/m,(x,lo,hi))
assert s.simplify(2*pair+leaf-s.Rational(3,8))==0; checks+=1
assert common(F(1))==F(1,2); checks+=1
bbox=F(5,4); triangle=F(1,2); lam=F(2)
assert lam*triangle*common(F(1))==F(1,2); checks+=1
assert lam*triangle*bbox==F(5,4); checks+=1

# Stage 3: exact union geometry, same source component width and R=1.
for gap,want in [(F(3,4),F(1)),(F(1),F(1,2)),
                 (F(5,4),F(0)),(F(3),F(0))]:
    assert common(gap)==want<=bbox; checks+=1
print('separated native: R=27/8, W=9/2, cross=0')
print('partial native: R=3/8, W=4, cross=3/4-log(2)')
print('cross decimal diagnostic:',s.N(pair,18))
print('same-tail prices: actual neighborhoods=1/2; bbox=5/4')
print(f'{checks} exact assertions PASS; no original history claim.')
```

实际 stdout：

```text
separated native: R=27/8, W=9/2, cross=0
partial native: R=3/8, W=4, cross=3/4-log(2)
cross decimal diagnostic: 0.0568528194400546906
same-tail prices: actual neighborhoods=1/2; bbox=5/4
16 exact assertions PASS; no original history claim.
```

结论：真实邻域交集严格保留了 bbox 丢失的稀疏结构，且 (5) 给出一次来源结算的可验证适用条件。尚未证明一般输入存在低重数、合适尺度的同一全局分块，或其真实邻域树价可和；因此没有取得原完整剩余的一般根阶预算。
