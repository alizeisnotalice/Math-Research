#!/usr/bin/env python3
"""Bounded exact R503 checks; no original-history certificate."""
from fractions import Fraction as Q
from pathlib import Path
import sys,json,time,platform
import sympy as sp
import flint
from flint import arb,ctx
ROOT=Path(__file__).resolve().parent
ctx.prec=256
checks=0

def check(b):
 global checks
 assert bool(b)
 checks+=1

def rat(x):
 x=Q(x);return sp.Rational(x.numerator,x.denominator)
def ar(x):
 x=Q(x);return arb(x.numerator)/x.denominator

def length(xs):
 out=[]
 for l,r in sorted((l,r) for l,r in xs if l<r):
  if out and l<=out[-1][1]:out[-1]=(out[-1][0],max(r,out[-1][1]))
  else:out.append((l,r))
 return sum((r-l for l,r in out),Q(0))
def common(d,R=Q(1)):
 r=Q(1,8)+R/2
 return length([(max(c-r,-r),min(c+r,r)) for c in [-d,d]])
def area(M,N,delta,u):
 pp=lambda x:max(Q(0),x)
 return (delta**2-pp(delta-M/u)**2-pp(delta-N/u)**2+pp(delta-(M+N)/u)**2)/2

def slice_area(M,N,delta,u):
 # Independent vertical slice: 0<s<min(M/u,delta), 0<t<min(N/u,delta-s).
 end=min(M/u,delta)
 pts=sorted({Q(0),end,*[x for x in [delta-N/u] if 0<x<end]})
 f=lambda x:max(Q(0),min(N/u,delta-x))
 return sum(((b-a)*(f(a)+f(b))/2 for a,b in zip(pts,pts[1:])),Q(0))

def exact_zero(x):
 check(sp.simplify(x)==0)

def eval_arb(expr):
 expr=sp.sympify(expr)
 if expr.is_Rational:return arb(int(expr.p))/int(expr.q)
 if expr.func==sp.log:return eval_arb(expr.args[0]).log()
 if expr.is_Add:return sum((eval_arb(x) for x in expr.args),arb(0))
 if expr.is_Mul:
  z=arb(1)
  for x in expr.args:z*=eval_arb(x)
  return z
 raise ValueError(expr)

def native16():
 start=checks
 check(common(Q(3))==0)
 masses=[Q(1),Q(3,2),Q(2)]
 check(all(1<=m<=2 for m in masses))
 check(sum(Q(3,4)*m for m in masses)==Q(27,8) and sum(masses)==Q(9,2))
 check(2*Q(3,8)+Q(1,4)==1)
 x=sp.symbols('x',real=True);lo,hi=sp.Rational(3,8),sp.Rational(5,8)
 c=8*(x-lo);d=4*(hi-x);m=4*x-sp.Rational(1,2)
 exact_zero(c+d-m)
 check(m.subs(x,lo)==1 and m.subs(x,hi)==2)
 pair=sp.simplify(sp.integrate(c*d/m,(x,lo,hi)))
 check(pair==sp.Rational(3,4)-sp.log(2))
 check(sp.integrate(m,(x,lo,hi))==sp.Rational(3,8))
 leaf=sp.integrate((c*c+d*d)/m,(x,lo,hi))
 exact_zero(2*pair+leaf-sp.Rational(3,8))
 check(common(Q(1))==Q(1,2))
 check(2*Q(1,2)*common(Q(1))==Q(1,2))
 check(2*Q(1,2)*Q(5,4)==Q(5,4))
 for gap,want in [(Q(3,4),Q(1)),(Q(1),Q(1,2)),(Q(5,4),Q(0)),(Q(3),Q(0))]:check(common(gap)==want<=Q(5,4))
 check(checks-start==16)
 # Independent full-L1 and center-volume guards beyond the original 16.
 source=[(Q(-9,8),Q(-7,8),Q(4)),(Q(-1,8),Q(1,8),Q(4)),(Q(7,8),Q(9,8),Q(8))]
 check(sum((r-l)*rho for l,r,rho in source)==4)
 # On receiver [3/8,5/8], only right and middle packets intersect; no missing source.
 for A in [Q(3,8),Q(1,2),Q(5,8)]:
  mass=sum(max(Q(0),min(r,A+Q(1,2))-max(l,A-Q(1,2)))*rho for l,r,rho in source)
  check(mass==4*A-Q(1,2))
 p=arb(3)/4-arb(2).log()
 check(p.is_finite() and p>0 and p<arb(1)/2)
 return {'original_assertions':16,'W':'4','receiver_interval':['3/8','5/8'],'R_tau':'3/8','cross_exact':'3/4-log(2)','cross_arb':str(p),'true_neighborhood_price':'1/2','bbox_price':'5/4'}

R=sp.symbols('R',positive=True)
def area_expr(M,N,delta,n,mid):
 u=mid**n
 # first term delta^2, others active selected at exact rational midpoint.
 ans=rat(delta)**2
 for coeff,value,cap in [(-1,delta-M/u,M),(-1,delta-N/u,N),(1,delta-(M+N)/u,M+N)]:
  if value>0:ans+=coeff*(rat(delta)-rat(cap)/R**n)**2
 return sp.expand(ans/2)

def stieltjes_case(name,a,b,d,M,N,delta):
 # Actual union-neighborhood volume F(R), source packet width1/4.
 def fexpr(mid):
  radius=Q(1,8)+mid/2
  if d>=2*radius:return sp.Integer(0)
  if d<=radius:return R+sp.Rational(1,4)
  return 2*R+sp.Rational(1,2)-2*rat(d)
 # n=1 exact rational mass and geometry breakpoints.
 points=sorted({a,b,*[x for x in [d-Q(1,4),2*d-Q(1,4),M/delta,N/delta,(M+N)/delta] if a<x<b]})
 direct=rat(common(d,b)*area(M,N,delta,b))
 base=rat(common(d,a)*area(M,N,delta,a))
 increment=sp.Integer(0)
 for l,r in zip(points,points[1:]):
  mid=(l+r)/2;F=fexpr(mid);A=area_expr(M,N,delta,1,mid)
  # Validate exact branch formula against independent interval union at midpoint.
  check(F.subs(R,rat(mid))==rat(common(d,mid)))
  check(A.subs(R,rat(mid))==rat(area(M,N,delta,mid)))
  direct+=sp.integrate(F*(-sp.diff(A,R)),(R,rat(l),rat(r)))
  increment+=sp.integrate(A*sp.diff(F,R),(R,rat(l),rat(r)))
 rhs=base+increment
 exact_zero(direct-rhs)
 check(rhs.is_finite)
 if a==b:exact_zero(rhs-base)
 interval=eval_arb(sp.simplify(rhs))
 check(interval.is_finite() and (interval>=0 or (rhs==0 and interval.contains(0))))
 return {'name':name,'a':str(a),'b':str(b),'d':str(d),'M':str(M),'N':str(N),'delta':str(delta),'breakpoints':[str(x) for x in points], 'base':str(base),'increment':str(sp.simplify(increment)),'direct':str(sp.simplify(direct)),'gap':'0','value_arb':str(interval),'scope':'actual interval-neighborhood F; abstract mass-tail parameters, not matching receiver/history'}

def main():
 t0=time.perf_counter();native=native16()
 # Symbolic active-branch derivation by rectangle subtraction from triangle.
 D,A,B=sp.symbols('delta A B',positive=True)
 exact_zero(D**2/2-(D-A)**2/2-(D-B)**2/2+(D-A-B)**2/2-A*B)
 area_rows=[]
 # 27 fixed rational combinations; includes empty cap zero, small/large rectangles and ties.
 for M,N in [(Q(1,4),Q(1,2)),(Q(1),Q(1)),(Q(3),Q(1,3))]:
  for delta in [Q(1,3),Q(1,2),Q(1)]:
   for u in [Q(1,2),Q(1),Q(3)]:
    got=area(M,N,delta,u);ind=slice_area(M,N,delta,u)
    check(got==ind);check(0<=got<=min(delta**2/2,M*N/u**2))
    area_rows.append({'M':str(M),'N':str(N),'delta':str(delta),'u':str(u),'area':str(got),'gap':'0'})
 # Explicit zero cap pressure.
 check(area(Q(0),Q(1),Q(1),Q(1))==slice_area(Q(0),Q(1),Q(1),Q(1))==0)
 cases=[('nonzero_base',Q(1),Q(2),Q(1,4),Q(3),Q(1),Q(1)),('fixed_side_a_eq_b',Q(1),Q(1),Q(1),Q(3),Q(1),Q(1)),('mass_truncation',Q(1),Q(2),Q(1),Q(1,4),Q(1,2),Q(1)),('negative_gap_empty',Q(1),Q(2),Q(3),Q(1),Q(1),Q(1)),('negative_gap_opens',Q(1),Q(2),Q(5,4),Q(1),Q(1,2),Q(1))]
 st=[stieltjes_case(*case) for case in cases]
 # Independent nonzero-base necessity: omission has exactly this positive gap.
 check(sp.Rational(st[0]['base'])>0)
 check(sp.Rational(st[1]['base'])>0 and st[1]['increment']=='0')
 # Scale Stieltjes area maps u=q R^n; arbitrary n is symbolic chain rule on an active branch.
 q,n=sp.symbols('q n',positive=True);m=sp.symbols('M',positive=True)
 exact_zero(sp.diff((D-m/(q*R**n))**2/2,R)-n*m*(D-m/(q*R**n))/(q*R**(n+1)))
 result={'scope':'finite static native continuous example + exact abstract area/Stieltjes checks; no general closure or original history','environment':{'executable':sys.executable,'python':platform.python_version(),'sympy':sp.__version__,'python_flint':flint.__version__,'arb_precision_bits':ctx.prec},'command':f'{sys.executable} r503_numeric.py','checks':checks,'native':native,'area_cases':area_rows,'stieltjes_cases':st,'compute_index':{'seconds':time.perf_counter()-t0}}
 (ROOT/'r503_numeric.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
 print(f'PASS {checks} assertions; independent native16,27 area cases,5 Stieltjes cases; static-only/no history')
if __name__=='__main__':main()
