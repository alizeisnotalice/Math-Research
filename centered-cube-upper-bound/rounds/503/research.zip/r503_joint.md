# R503 联合检查：真实邻域价格与共同分母负信用

本附件只检查一种跨节点机制：能否用后验方差及其他来源稀释的负信用，抵消真实邻域价格的粗节点费用。结论是：负信用确有准确跨节点结算，但当前参照测度不同，未得到一般根阶来源预算；不能从邻域上界再次直接扣掉这些信用。

## 1. 固定同一原场的两种量

沿本轮实际 \(\mu=f\,dx\)、\(m_B=\mu(Q_B)=q_BR_B^n\)、\(a\le R_B\le b\)、\(q\le q_B\le\lambda\)、\(d\nu=t(B)q_B\,dB\)、\(t\le S\)。所有来源集合和分割树对全部父共同固定。记 \(p_C=\pi_B(C)\)。原 mark 可并入 \(\nu\) 的概率扩展。

对不交来源块 \(C,D\)，本轮真实邻域尾工具产生上界 \(\mathcal C_{CD}\)；其候选表达为
\[
\mathcal C_{CD}=S\lambda\left[
F_{CD}(a)\mathcal A(qa^n)+
\int_{(a,b]}\mathcal A(qR^n)\,dF_{CD}(R)\right],
\]
其中 \(F_{CD}(R)=|N_R(C)\cap N_R(D)|\)，\(\mathcal A(u)\) 是共同三角形 \(s+t<\delta_{C\cup D}\) 内再截 \(s<\mu C/u,t<\mu D/u\) 的面积。邻域及 Stieltjes 端点的严格定义、一般证明归本轮主证明负责；本附件只使用它提供的 \(T_{CD}:=\int p_Cp_Dd\nu\le\mathcal C_{CD}\)，不重复证明或提高其量词。

另一方面，定义实际来源负载
\[
L_w(x)=\int t(B)R_B^{-n}1_{Q_B}(x)\,dB,
\qquad A_C=\int_C L_w\,d\mu=\int p_C\,d\nu.
\]
这是 \(\mu\) 的实际加权测度，并非 \(\mu(C)\)。只有 \(L_w\le SA_n\) 的既有通用帽，不能在变量选择器下使用固定尺度的 \(A_C\le S\mu(C)\)。

## 2. 同一完整分母下的准确信用及求和

令 \(F=C\sqcup D\)、\(p_F=p_C+p_D\)、\(A_F=A_C+A_D\)。在零分母处全部项取零。定义
\[
\mathcal H_F=\frac{A_CA_D}{A_F},\qquad
\mathcal V_F=\int p_F
 \left(\frac{p_C}{p_F}-\frac{A_C}{A_F}\right)^2d\nu,
\qquad
\mathcal D_F=\int\frac{p_Cp_D(1-p_F)}{p_F}\,d\nu.
\]
直接展开平方并用 \(\int p_Cd\nu=A_C\)，得到
\[
\mathcal H_F-\mathcal V_F
=\int\frac{p_Cp_D}{p_F}\,d\nu,
\qquad
T_{CD}=\mathcal H_F-\mathcal V_F-\mathcal D_F.
\tag{1}
\]
故对任意有限完整来源树，准确跨节点式为
\[
\sum_{F\text{ 内节点}}
(\mathcal H_F-\mathcal V_F-\mathcal D_F)
=\frac12\left[R_\tau-
\int\sum_{L\text{ 叶}}p_L^2\,d\nu\right].
\tag{2}
\]
这一求和保留了全部实际部分捕获；两个负项可消去 \(\mathcal H_F\) 的细分增长。但右端恰是待付父量及真实叶项，正参照仍由 \(L_w\mu\) 定义。式 (2) 不能单独把费用降为 \(\mu\) 的根阶价格。

## 3. 不可跳过的比较

合法的逐节点联合使用仅为
\[
T_{CD}\le
\min\{\mathcal C_{CD},\,
\mathcal H_F-\mathcal V_F-\mathcal D_F\}.
\tag{3}
\]
不能写 \(T_{CD}\le\mathcal C_{CD}-\mathcal V_F-\mathcal D_F\)。后者需要额外比较 \(\mathcal H_F\le\mathcal C_{CD}\)，目前没有这种关系；当两块各自有正父负载却没有任何共同可捕获中心时，\(\mathcal C_{CD}=T_{CD}=0\) 而 \(\mathcal H_F>0\)，已有负信用正是用来抵消 \(\mathcal H_F\)。不能再从零邻域价扣第二次。

因此，所尝试机制还缺一项具体几何结算：保同一个真实选择器和全部捕获分母，证明邻域尾外放产生的粗节点放大量与式 (1) 的信用有一个**同权、跨节点、以 \(\mu\) 计价的比较**。式 (1)–(3) 没有给出该比较；直接保全部信用只返回式 (2)，删信用再用 \(L_w\le SA_n\) 则回到既有维数级负载。没有得到新的原积分付款。

以上讨论直接针对 \(R_\tau\)。若用于原 \(J\)，仍须保 \(H_B(x,z)\) 的 rank、void、祖先和 mark 标签；以 \(H\le\Phi_{\max}\) 删除这些权会额外损失 \(\Phi_{\max}\)，不能声称式 (1) 已使用原历史。没有刷新来源、改变父选择器或另造树流。

本轮按有界任务停止；没有新增数值实验。本附件展开的是预审已核的共同分母公式，未把代数求和或新的容量定义计作几何进展。
