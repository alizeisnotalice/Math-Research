from fractions import Fraction as F
import sympy as s
a,b,r=s.symbols('a b r',positive=True)
assert s.simplify(a*b/(a+b+r)-(a*b/(a+b)-a*b*r/((a+b)*(a+b+r))))==0
mu=[F(1),F(2),F(3)]
H=[[F(1,2),F(1,3),F(0)],[F(1,2),F(1,3),F(1,2)],[F(0),F(1,3),F(1,2)]]
checks=1
for w in [[F(1)]*3,[F(1),F(1,2),F(0)],[F(0),F(0),F(0)]]:
 q=[sum(H[j][i]*mu[i] for i in range(3)) for j in range(3)]
 aa=[w[j]*H[j][0]*mu[0] for j in range(3)];bb=[w[j]*H[j][1]*mu[1] for j in range(3)];rr=[w[j]*H[j][2]*mu[2] for j in range(3)]
 A=sum(aa);B=sum(bb)
 T=sum(aa[j]*bb[j]/(aa[j]+bb[j]+rr[j]) if aa[j]+bb[j]+rr[j] else F(0) for j in range(3))
 var=sum((aa[j]+bb[j])*(aa[j]/(aa[j]+bb[j])-A/(A+B))**2 for j in range(3) if aa[j]+bb[j]) if A+B else F(0)
 dil=sum(aa[j]*bb[j]*rr[j]/((aa[j]+bb[j])*(aa[j]+bb[j]+rr[j])) for j in range(3) if aa[j]+bb[j])
 assert T==(A*B/(A+B) if A+B else F(0))-var-dil;checks+=1
 assert A<=mu[0] and B<=mu[1];checks+=1
 assert T<=(mu[0]*mu[1]/(mu[0]+mu[1]));checks+=1
 f=[F(-1),F(2),F(0)]
 lhs=sum(w[j]*sum(H[j][i]*mu[i]*f[i] for i in range(3))**2/q[j] for j in range(3))
 assert lhs<=sum(mu[i]*f[i]**2 for i in range(3));checks+=1
print('PASS',checks,'symbolic/Fraction shared-denominator and Jensen checks; finite averaging model only')
