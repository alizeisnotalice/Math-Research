# R503 独立终审

FINAL PASS（限定工具范围）。真实来源邻域联合尾、质量尺度耦合的 Stieltjes 价格、条件性低重数分块收据及共同分母恒等式通过审查。**没有证明一般来源存在低成本全局分块、内部节点总价可和，也没有新增完整原余流的一般根阶付款或全尺度闭合。**

独立 PRE 先于作者阅读形成；其 `quad` 排版现已修正，数学与13项检查脚本未变。已读本白名单全部10件最终字节，未修改作者稿或仓库。

- 尾界保同一真实 selector、完整质量、部分捕获及概率 mark。三角域面积 A(u) 正确；Stieltjes 必须保 F(a) 底项、(a,b] 增量和 b 原子。a=b 仅剩底项。有限右连续 F 给等式，一般有限 F 用右连续上包络给上界，无穷体积不冒称有限价格。真实非均匀连续例的 1/2 对 5/4 严格改善及正混合矩 3/4−log2 均正确。
- 条件性完整分块界须同时有全父后验覆盖、同一可数分块的触及重数 D、块尺度 h；它支付全部 cross/leaf，而这些一般构造条件尚未证明。源尾截断、无限叶端与跨根 pair 均保留，两个替代入口不叠加收益。
- 共同分母的 harmonic 参照减后验方差、再减其他来源稀释项是精确等式；固定尺度的实际负载有 Sμ 帽，可变尺度只直接有 SA_nμ 帽。joint 完整树求和恢复原接收量；未证明 harmonic 参照小于邻域价，故不能从邻域价再次扣两项信用。高度截断附件只作已有机制的范围判定，无新付款。
- 原 J 的 rank、void、祖先、mark、history 权仍在真实条件平均中；删除它们只得显式 Φ_max 上放。原母账及未付余项未被新辅助块或中心继承、消除。

实际独立隔离重放已有源码：proof 两块18项、PRE13项、numeric109项，共140个报告断言单位（含重复核验，非140个模型）。四份 stdout 与 replay 逐字一致；numeric JSON 只剔除 compute_index.seconds 后完全一致，规范 SHA256 为 `eecefbf116afd5cc9fdf8c3a6d39a1f9398c7fff7497df23d84dc836f298535a`。Fraction/SymPy 精确运算及 Arb256区间仅认证所列静态连续例、面积与尺度接口，不认证一般树预算或原 history。独审临时6项面积检查不计归档140项。

最终输入 SHA256（仅绑定下列10件；审计文件自身另报）：

- `r503_main.md`: `1b5e59de6794014ad8c3916533f37fb0a44150427d67769b3dfa5c1b258549ea`
- `r503_proof.md`: `58d230afdfa7fae51022b6822acdef79ab9c84b622f57642e45de871956e2b67`
- `r503_joint.md`: `5b80f20d43a576a08fadefdd7362b1d19eec55a275cf994839f39d955b5bb3c9`
- `r503_geometry.md`: `a50a9f7eb6a1d334640b87d3091dfb99463959d429babd0d67afae61854e3f74`
- `r503_audit_pre.md`: `0fe5b78c3b06040b8a81948e523b3b401b16ae35f089d015f2918ab227fb0726`
- `r503_audit_math_check.py`: `c43803588892a5dd3a7f89c2fe73768416dad1df32e353cd610c6f5f15e888c2`
- `r503_numeric.md`: `7e6f7f254bf95adc5e2b24e0d40e692966e4c82a2eff7cefa7305775fbfe40eb`
- `r503_numeric.py`: `4ae1fac9da2595dd0cc34749a342f6cd57ddc6c532ca65d55d7384a81bdf0054`
- `r503_numeric.json`: `ae335ce0bdcb5f1dd43560f657a076f96f1a5b50bb50d069af3017b547a09b12`
- `r503_replay.json`: `1aaf8b0665949a7f536bcd9f7c6927fb28a6484ece2623959894c79a9fc7b976`
