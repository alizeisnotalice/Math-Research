"""Exact rational guards for fixed-pair flux; no finite-grid maximal surrogate.

Run python3 flux_guard.py. Standard library only; results.json is overwritten.
The dimension-free general pair bound is analytic in proof.md, not inferred here.
"""
from fractions import Fraction as F
import json
from pathlib import Path


def maximal(atoms, x, a=F(1), b=F(2)):
    n = len(x)
    arrivals = [2 * max(abs(t - s) for t, s in zip(x, y)) for y, w in atoms]
    candidates = sorted({a, b} | {r for r in arrivals if a <= r <= b})
    rows = [(sum((w for r, (y, w) in zip(arrivals, atoms) if r <= R), F(0)) / R**n, R)
            for R in candidates]
    H = max(v for v, R in rows)
    return H, [R for v, R in rows if v == H]


def atoms2(n, alpha, d):
    return [(tuple(F(0) for _ in range(n)), alpha**n),
            ((d,) + (F(0),) * (n - 1), 1 - alpha**n)]


def run():
    report = {"arithmetic": "fractions.Fraction; deterministic; no random sampling",
              "stages": [], "opposite": [], "orthogonal": [], "bottom": [], "endpoint": []}
    stages = [("exploration", [1, 2, 3, 4]),
              ("stress", [8, 16, 32]), ("expanded", [64, 128, 256])]
    alphas = [F(3, 4), F(7, 8), F(15, 16)]
    r0, r1 = F(3, 2), F(2)
    for name, dimensions in stages:
        report["stages"].append({"name": name, "dimensions": dimensions})
        for n in dimensions:
            eps = F(1, 4096 * (n + 1))
            for alpha in alphas:
                d = r0 * (1 + alpha) / 2
                atoms = atoms2(n, alpha, d)
                delta = 1 - alpha**n
                x = [F(0)] * n
                x[0] = alpha * r0 / 2
                H, winners = maximal(atoms, x)
                assert H == 1 / r0**n and winners == [alpha * r0, r0]
                xm, xp = x.copy(), x.copy()
                xm[0] -= eps
                xp[0] += eps
                assert maximal(atoms, xm)[1] == [2 * xm[0]]
                assert maximal(atoms, xp)[1] == [2 * (d - xp[0])]
                # Entire opposite-face seam: transverse cube of side alpha*r0.
                area = (alpha * r0)**(n - 1)
                fee = delta * d / r0**n * area
                exact = delta * (1 + alpha) * alpha**(n - 1) / 2
                assert fee == exact and fee <= delta
                report["opposite"].append({"n": n, "alpha": str(alpha), "fee_over_delta": str(fee / delta)})
                # Fixed bottom-scale plateau vs a larger interior arrival.
                rb = 1 / alpha
                db = rb / 2
                bottom_atoms = atoms2(n, alpha, db)
                xb = [F(0)] * n
                Hb, wb = maximal(bottom_atoms, xb)
                assert Hb == alpha**n and wb == [F(1), rb]
                xb[0] = -eps
                assert maximal(bottom_atoms, xb)[1] == [F(1)]
                xb[0] = eps
                assert maximal(bottom_atoms, xb)[1] == [2 * (db - eps)]
                # This centered patch has transverse side a=1, regular a.e.
                bottom_fee = delta * db / rb**n
                assert bottom_fee / delta == alpha**(n - 1) / 2
                assert bottom_fee <= delta * (1 + alpha) / 2
                report["bottom"].append({"n": n, "alpha": str(alpha), "fee_over_delta": str(bottom_fee / delta)})
                if n >= 2:
                    for r in [F(13, 8), F(7, 4), F(15, 8)]:
                        x = [F(0)] * n
                        x[0], x[1] = d - r / 2, alpha * r / 2
                        H, winners = maximal(atoms, x)
                        assert H == 1 / r**n and winners == [alpha * r, r]
                        xm, xp = x.copy(), x.copy()
                        xm[1] -= eps
                        xp[1] += eps
                        assert maximal(atoms, xm)[1] == [2 * xm[1]]
                        assert maximal(atoms, xp)[1] == [r]
                    # Integrate one orthogonal-face seam over r in (r0,2).
                    # normal & surface Jacobian cancel, leaving rational density.
                    fee = delta * d * alpha**(n - 1) / 2 * (1 / r0 - 1 / r1)
                    cap = delta * alpha**(n - 2) * (1 + alpha)**2 / 4 * (1 - r0 / r1)
                    assert fee <= cap <= delta
                    report["orthogonal"].append({"n": n, "alpha": str(alpha),
                                                 "fee_over_delta": str(fee / delta), "bound_over_delta": str(cap / delta)})
            # The b-endpoint jump is not a continuous winner-pair seam.
            w = F(3, 2) * F(2)**n
            atoms = [((F(0),) * n, w)]
            x = [F(0)] * n
            x[0] = 1 - F(1, 100 * (n + 1))
            Hin, _ = maximal(atoms, x)
            x[0] = 1 + F(1, 100 * (n + 1))
            Hout, _ = maximal(atoms, x)
            assert 1 < Hin <= 2 and Hout == 0
            face_fee = w / F(2)**n * F(1) * F(2)**(n - 1)
            assert face_fee == w / 2 and 2 * n * face_fee == n * w
            report["endpoint"].append({"n": n, "negative_endpoint_fee_over_W": str(F(n))})
    report["counts"] = {k: len(report[k]) for k in ["opposite", "orthogonal", "bottom", "endpoint"]}
    report["status"] = "all exact finite guards passed; general upper bound remains open"
    return report


if __name__ == "__main__":
    result = run()
    Path(__file__).with_name("results.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({"counts": result["counts"], "status": result["status"]}, ensure_ascii=False))
