"""Exact signed-block sampling for physical moving small cubes and fixed large cubes."""

from fractions import Fraction as F
from itertools import product
from math import prod
from sys import version

SMALL = F(1, 2)
BIG = F(3, 4)
A = F(3, 4)
RADIUS = F(1, 16)
SHIFT = 2 * RADIUS
Q = (1 - A) / 2
QMAX = Q + (SHIFT + RADIUS) / 2


def mode(groups, signs):
    return tuple(tuple((i, signs[i]) for i in group) for group in groups)


def father(signs):
    return tuple(sign * (BIG + A * SMALL) for sign in signs)


def physical_bounds(owner, large, blocks):
    """Pull all cube-coordinate conditions back to one interval per parameter."""
    result = []
    for block in blocks:
        lo, hi = F(-1), F(1)
        for i, sign in block:
            ends = [sign * (large[i] + shift - owner[i]) / SMALL
                    for shift in (-BIG, BIG)]
            lo, hi = max(lo, min(ends)), min(hi, max(ends))
        result.append((lo, hi))
    return result


def point_probability(owner, large, blocks):
    return prod(max(F(0), hi - lo) / 2
                for lo, hi in physical_bounds(owner, large, blocks))


def arrangement_probability(owner, large, blocks):
    """Independent small-case audit, integrate cartesian cells by physical membership."""
    cells = []
    for block in blocks:
        edges = {F(-1), F(1)}
        for i, sign in block:
            for shift in (-BIG, BIG):
                edge = sign * (large[i] + shift - owner[i]) / SMALL
                if -1 < edge < 1:
                    edges.add(edge)
        edges = sorted(edges)
        cells.append(tuple(zip(edges, edges[1:])))
    total = F(0)
    for cell in product(*cells):
        point = list(owner)
        for block, (lo, hi) in zip(blocks, cell):
            for i, sign in block:
                point[i] += SMALL * sign * (lo + hi) / 2
        assert all(abs(x - u) <= SMALL for x, u in zip(point, owner))
        if all(abs(x - t) <= BIG for x, t in zip(point, large)):
            total += prod((hi - lo) / 2 for lo, hi in cell)
    return total


def affine_product_integral(factors):
    """Integral on [0,1] of a product of polynomials a+b x."""
    coefficients = [F(1)]
    for intercept, slope in factors:
        next_coefficients = [F(0)] * (len(coefficients) + 1)
        for degree, value in enumerate(coefficients):
            next_coefficients[degree] += intercept * value
            next_coefficients[degree + 1] += slope * value
        coefficients = next_coefficients
    return sum(value / (degree + 1)
               for degree, value in enumerate(coefficients))


def mean_block(intervals):
    """Fubini over tau and signed owner coordinates on a genuine positive-width core."""
    edges = sorted({F(-1), F(1), *(A - x for pair in intervals for x in pair)})
    assert edges[0] == -1 and edges[-1] == 1
    total = F(0)
    for lo, hi in zip(edges, edges[1:]):
        factors = []
        mid = (lo + hi) / 2
        for left, right in intervals:
            if mid < A - right:
                break
            if mid < A - left:
                factors.append(((lo + right - A) / (right - left),
                                (hi - lo) / (right - left)))
        else:
            total += (hi - lo) / 2 * affine_product_integral(factors)
    return total


def mean_probability(core, target, blocks):
    total = F(1)
    for block in blocks:
        orientation = {sign * target[i] for i, sign in block}
        if len(orientation) > 1:
            # Every signed target displacement is strictly positive on both cores.
            return F(0)
        intervals = [tuple(sorted(target[i] * endpoint / SMALL for endpoint in core[i]))
                     for i, _ in block]
        total *= mean_block(intervals)
    return total


def uniform_minimum(count):
    return -RADIUS * (count - 1) / (count + 1)


def closed_mean(groups, shift):
    # The shifted coordinate and the others have interiors of disjoint rank ranges.
    result = F(1)
    for group in groups:
        count = len(group)
        if 0 not in group:
            expected_min = uniform_minimum(count)
        elif shift < 0 or count == 1:
            expected_min = shift
        else:
            expected_min = uniform_minimum(count - 1)
        result *= Q + expected_min / 2
    return result


def binary_floor(value):
    guess = value.numerator.bit_length() - value.denominator.bit_length()
    return guess - (value < F(2)**guess)


def exercise(label, n):
    third = n // 3
    first = tuple(range(third))
    second = tuple(range(third, 2 * third))
    third = tuple(range(2 * third, n))
    axis = tuple(range(n))
    plus = (1,) * n
    mixed = tuple(-1 if i in second else 1 for i in axis)
    both = (first + third, second)
    three = (first, second, third)
    separate = tuple((i,) for i in axis)
    patterns = ((axis,), (axis,), both, three, separate)
    modes = tuple(mode(groups, signs) for groups, signs in
                  zip(patterns, (plus, mixed, plus, plus, plus)))
    targets = (plus, mixed)
    origin = (F(0),) * n

    frozen = tuple(tuple(point_probability(origin, father(target), blocks)
                         for blocks in modes) for target in targets)
    assert frozen == ((Q, 0, Q**2, Q**3, Q**n),
                      (0, Q, Q**2, Q**3, Q**n))
    assert QMAX == F(7, 32)
    print(f"{label} n={n}  A_t/A_u side ratio={BIG / SMALL}  blocks={tuple(map(len, three))}")
    print(f"  owner 0, matching or wrong one-block / common two / three / independent = "
          f"{Q} or 0 / {Q**2} / {Q**3} / 8^-{n}; one-block gain=8^{n-1}")

    all_averages = []
    for name, shift in (("U", SHIFT), ("W", -SHIFT)):
        centers = (SMALL * shift,) + (F(0),) * (n - 1)
        core = tuple((c - SMALL * RADIUS, c + SMALL * RADIUS) for c in centers)
        volume = prod(hi - lo for lo, hi in core)
        assert volume == F(1, 16)**n
        assert all(abs(lo) + SMALL < 3 and abs(hi) + SMALL < 3 for lo, hi in core)
        assert all(0 < A - target[i] * point / SMALL < 1
                   for target in targets for i, interval in enumerate(core)
                   for point in interval)
        averages = tuple(tuple(mean_probability(core, target, blocks) for blocks in modes)
                         for target in targets)
        best, two, thr, ind = (closed_mean(groups, shift)
                              for groups in (patterns[0], both, three, separate))
        assert averages == ((best, 0, two, thr, ind), (0, best, two, thr, ind))
        assert ind == Q ** (n - 1) * (Q + shift / 2)
        assert 0 < two / best <= QMAX < F(1, 2)
        assert 0 < thr <= two
        all_averages.append((best, two, thr, ind))
        if n == 3:
            for target in targets:
                large = father(target)
                assert all(abs(c) + BIG < 3 for c in large)
                for owner in (origin, centers, *(product(*core))):
                    for blocks in modes:
                        assert point_probability(owner, large, blocks) == arrangement_probability(
                            owner, large, blocks)

        print(f"  {name}, true Lebesgue core volume=16^-{n}, moving small cube side=1")
        print(f"    mean best / common two / common three = {best} / {two} / {thr}")
        print(f"    independent mean=(1/8)^{n-1}*({Q + shift / 2}); "
              f"floor log2(best / independent)={binary_floor(best / ind)}")
        print(f"    common two/best={two / best}; each raw integral=16^-{n} times its mean")

    assert SMALL * (SHIFT - RADIUS) > 0
    (bu, tu, _, _), (bw, tw, _, _) = all_averages
    assert F(1, 2) * (bu + bw) > F(1, 2) * (tu + tw)
    print("  fixed menu vs parent-aware, equal two-parent prior on each core: exactly 1/2.")
    print(f"  two parents and two cores, same public mode but independent draws: "
          f"best simultaneous/parent-aware simultaneous={tu*tw/(bu*bw)}.")
    print("  sharing the same displacement vector gives simultaneous mass 0 on U x W.")


if __name__ == "__main__":
    print(f"Python {version.split()[0]}; all geometry and integrals use exact Fraction.")
    print("Physical model: both parents and moving owners have centered maximal value 3/2 "
          "for the window [1,2] in f=(3/2)1_{[-3,3]^n}.")
    print("Parent signs are all positive and +,-,+ by groups; E_U and E_W are disjoint "
          "cores and each parent is tested on both. No full historical Gamma is modelled.")
    print("For a single parent, merge all compatible axes to dominate. A mode compatible "
          "with both can merge to just two signature groups; its row score is at most "
          "7/32 of the one-parent best. Exclusive modes contribute to at most one row.")
    print("The two rows have equal core-integrated best scores. An equal mix of their "
          "exclusive one-block modes attains the fixed-menu maximin and mean bound.")
    exercise("INITIAL", 3)
    exercise("OPPOSED BLOCK PRESSURE", 12)
    exercise("EXPANDED", 96)
