"""R859: union-source repricing on the complete pinned real R814 cross flow."""

from argparse import ArgumentParser
from collections import defaultdict
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
from zipfile import ZipFile
import json
import sys


PIN858="7224b3ca13f4f5293676e5fa520e4230369c10e0453bfee6f348b0b20edb20da"
REPRICE_PIN="edcf755e059cd0080e2ab8cb8af563381098fa7c20982f985c5901c7f754b622"
RULES=("central","central+left","central+left+right")
PRICE_MULTIPLIERS=(F(1,4),F(1),F(2))


def helper(rounds):
    path=rounds/"858"/"research.zip"
    assert sha256(path.read_bytes()).hexdigest()==PIN858
    with ZipFile(path) as archive:
        manifest=json.loads(archive.read("MANIFEST.json"))["sha256"]
        name="reprice858.py"
        script=archive.read(name)
        assert sha256(script).hexdigest()==manifest[name]==REPRICE_PIN
    env={"__name__":"pools859_fixed_helpers","__file__":name}
    exec(compile(script,name,"exec"),env)
    return env


def build(raw,parents,src,rule,independent):
    buckets=defaultdict(lambda:defaultdict(F))
    lookup={}
    for record,value in sorted(raw.items()):
        t,left,right=record
        allowed=parents[t]["bit"]
        if rule>=1:
            allowed|=parents[left[0]]["bit"]
        if rule>=2:
            allowed|=parents[right[0]]["bit"]
        pool=tuple(w for w in sorted(src) if w&allowed)
        assert pool and len(pool)==len(set(pool))
        market=right[1] if independent else "shared"
        lookup[record]=(market,pool)
        buckets[market][pool]+=value
    assert sum(sum(parts.values()) for parts in buckets.values())==sum(raw.values())
    return buckets,lookup


def recipient_loads(amounts):
    typed=defaultdict(F)
    physical=defaultdict(F)
    father=defaultdict(F)
    for (mid,left,right),v in amounts.items():
        assert v>=0
        father[mid]+=v
        for role,leg in enumerate((left,right)):
            half=leg[0],leg[2]
            typed[(role,*half)]+=v
            physical[half]+=v
    assert sum(physical.values())==sum(typed.values())==2*sum(amounts.values())
    return typed,physical,father


def at_price(raw,parents,src,network,buckets,lookup,price):
    mass=sum(raw.values())
    results={}
    mincut=F(0)
    worst=(F(-1),None,None)
    for market,demand in sorted(buckets.items()):
        value,rr,cc,cut=network(demand,src,price)
        cut_demand,cut_mu,cells=cut
        assert cut_mu==sum(src[w] for w in cells)
        assert value==sum(rr.values())==sum(cc.values())
        assert all(v<=price*src[w] for w,v in cc.items())
        # Exact dual certificate on the original fixed market:
        # uncut demands plus one true source-capacity price.
        assert value==sum(demand.values())-cut_demand+price*cut_mu
        deficit=cut_demand-price*cut_mu
        if deficit>worst[0] and deficit>0:
            worst=(deficit,market,cut)
        results[market]=rr
        mincut+=value
    paid={}
    for key,val in raw.items():
        market,pool=lookup[key]
        frac=F(results[market].get(pool,0))/buckets[market][pool]
        assert 0<=frac<=1
        paid[key]=val*frac
    primal=sum(paid.values())
    assert 0<primal<=mass and primal==mincut
    before_t,before_p,before_f=recipient_loads(raw)
    after_t,after_p,after_f=recipient_loads(paid)
    assert all(after_t[k]<=v for k,v in before_t.items())
    assert all(after_p[k]<=v<=parents[k[0]]["owner_volume"]/2 for k,v in before_p.items())
    # This solution realizes the source-only dual even with one
    # physical receiver cap on combined U and W usage, never a copied
    # cap for each side. The dual remains valid with nonnegative added
    # constraints by ignoring those constraints.
    rem={t:1-after_f[t]/v for t,v in before_f.items()}
    difficult=max(rem,key=lambda t:(rem[t],t))
    density=max(2*v/parents[k[0]]["owner_volume"] for k,v in after_p.items())
    return primal,worst,difficult,rem,density,sum(x>0 for x in paid.values())


def all_source_models(raw,parents,src,env,C0,fmt,label):
    mass=sum(raw.values())
    dispensary={}
    print(label,"original records",len(raw),"; original mass",fmt(mass))
    before_t,before_p,before_f=recipient_loads(raw)
    assert all(before_p[k]<=parents[k[0]]["owner_volume"]/2 for k in before_p)
    physical_max=max(2*v/parents[k[0]]["owner_volume"] for k,v in before_p.items())
    print("  Full-flow combined U+W physical-cap density maximum",fmt(physical_max))

    for i,rule in enumerate(RULES):
        independent,index_i=build(raw,parents,src,i,True)
        shared,index_s=build(raw,parents,src,i,False)
        assert shared["shared"].keys()=={pool for market,pool in index_i.values()}
        req,cap=env["peak"](shared["shared"],src)
        assert cap[0]==req*cap[1] and cap[1]==sum(src[w] for w in cap[2])
        print(" ",rule,"; critical common peak/C0",fmt(req/C0),
              "; critical cut demand/original",fmt(cap[0]/mass),
              "; exact critical true mu",cap[1],"; cells",cap[2])
        for mul in PRICE_MULTIPLIERS:
            price=C0*mul
            a=at_price(raw,parents,src,env["network"],independent,index_i,price)
            b=at_price(raw,parents,src,env["network"],shared,index_s,price)
            assert 0<b[0]<=a[0]<=mass
            if i:
                assert all(x<=y for x,y in zip(dispensary[i-1,mul],(a[0],b[0])))
            dispensary[i,mul]=(a[0],b[0])
            print("    price/C0",mul,"; paid/orig independent q, shared, shared+real U+W:",
                  *(fmt(x/mass) for x in (a[0],b[0],b[0])),
                  "; shared residual",fmt(1-b[0]/mass),
                  "; positive original rows paid",b[5],"; worst selected middle",b[2],fmt(b[3][b[2]]))
            if b[1][1] is not None:
                d,s,cells=b[1][2]
                assert b[1][1]=="shared" and d-price*s==mass-b[0]
                print("      exact shared mincut: true mu",s,
                      "; permitted central-plus-old cap/orig",fmt(price*s/mass),
                      "; remaining cut demand/orig",fmt(d/mass),"; cells",cells)
            if mul==1:
                solo={}
                for t in sorted(before_f):
                    sub={key:x for key,x in raw.items() if key[0]==t}
                    only,lk=build(sub,parents,src,i,False)
                    maximum,_,_,_,_,_=at_price(sub,parents,src,env["network"],only,lk,price)
                    solo[t]=1-maximum/before_f[t]
                print("      at C0 residual by actual common primal:",
                      tuple((t,fmt(v)) for t,v in sorted(b[3].items())),
                      "; unavoidable with each father alone:",
                      tuple((t,fmt(v)) for t,v in solo.items()))
    return dispensary


if __name__=="__main__":
    parser=ArgumentParser()
    parser.add_argument("--rounds",type=Path,required=True)
    args=parser.parse_args()
    env=helper(args.rounds)
    parents,src,raw,fmt,pin814=env["load"](args.rounds)
    assert len(raw)==920 and all(v>0 for v in raw.values())
    independent,_=build(raw,parents,src,0,True)
    C0=max(env["peak"](individual,src)[0] for individual in independent.values())
    assert C0>0
    assert env["network"](build(raw,parents,src,0,False)[0]["shared"],src,C0)[0]<sum(raw.values())
    print("Python",sys.version.split()[0],"| exact Fraction primal/dual and original subflow reconstruction")
    print("R858",PIN858,"; certified reprice helper",REPRICE_PIN)
    print("R814",pin814,"; original positive rows",len(raw),"; C0",fmt(C0))
    print("Frozen source cells: union eligibility includes actual parents once per record.")
    print("Extended auxiliary source cells leave the two real endpoints on each original accepted record untouched.")
    print("Actual receiver (father,half) cap used once for the sum over both physical arms.")
    base=all_source_models(raw,parents,src,env,C0,fmt,"Both original central-volume bins")
    assert base[0,F(1)][0]==sum(raw.values())
    assert all(base[1,m][1]==base[2,m][1] for m in PRICE_MULTIPLIERS)
    by_bin=defaultdict(dict)
    for key,val in raw.items():
        by_bin[parents[key[0]]["volume_bin"]][key]=val
    assert set(by_bin)=={F(64),F(128)}
    for d,subset in sorted(by_bin.items()):
        all_source_models(subset,parents,src,env,C0,fmt,"Only absolute middle volume bin "+str(d))
    print("All assertions passed. R814 finite calibration, with original U,W and complete degree weights.")
