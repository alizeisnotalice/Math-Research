"""Exact cyclic dyadic cut and refill for real cube gates and receiver cores."""

from fractions import Fraction as F
from math import prod
from sys import version

SU, ST = F(1, 2), F(3, 4)
TAU = F(1)
OUTSIDE = "outside"
LARGE_LOCAL = F(1, 64)


def cube(center, half_side):
    return tuple((x - half_side, x + half_side) for x in center)


def intersection(first, second):
    result = []
    for (a, b), (c, d) in zip(first, second):
        lo, hi = max(a, c), min(b, d)
        if lo >= hi:
            return None
        result.append((lo, hi))
    return tuple(result)


def volume(box):
    return prod(hi - lo for lo, hi in box) if box is not None else F(0)


def expand(box, pad):
    return tuple((lo - pad, hi + pad) for lo, hi in box)


def crop_from_middle(box, fraction):
    lo, hi = box[0]
    shift = (hi - lo) * (1 - fraction) / 2
    return ((lo + shift, hi - shift), *box[1:])


def dyadic_cell(point, depth, root_side):
    rounds, extra = divmod(depth, len(point))
    sides = [root_side / 2**(rounds + (i < extra)) for i in range(len(point))]
    left = [(x // h) * h for x, h in zip(point, sides)]
    return tuple((x, x + h) for x, h in zip(left, sides))


def restrict_mass(pieces, gate):
    return sum((mass * volume(intersection(box, gate)) / volume(box)
                for _, box, mass in pieces), F(0))


def split_pieces(pieces, axis, cut, lower):
    """Clip one coordinate, preserving each piece's density exactly."""
    result = []
    for name, box, mass in pieces:
        a, b = box[axis]
        lo, hi = (a, min(b, cut)) if lower else (max(a, cut), b)
        if lo < hi:
            result.append((name, (*box[:axis], (lo, hi), *box[axis+1:]),
                           mass * (hi - lo) / (b - a)))
    return result


def stopping_tree(root, pieces, max_depth):
    found = {}
    deepest = 0
    stack = [(root, volume(root), pieces, 0)]
    while stack:
        box, size, support, depth = stack.pop()
        mass = sum(value for _, _, value in support)
        if mass > TAU * size:
            found[box] = mass
            deepest = max(depth, deepest)
            assert 0 < depth <= max_depth and mass <= 2 * TAU * size
            continue
        # Every part remaining after removal of the spike pieces has density <= tau.
        if not any(name != OUTSIDE for name, _, _ in support):
            continue
        assert depth < max_depth
        axis = depth % len(root)
        a, b = box[axis]
        cut = (a + b) / 2
        for lower in (True, False):
            child = (*box[:axis], (a, cut) if lower else (cut, b), *box[axis+1:])
            stack.append((child, size / 2, split_pieces(support, axis, cut, lower), depth + 1))
    return found, deepest


def binary_floor(value):
    guess = value.numerator.bit_length() - value.denominator.bit_length()
    return guess - (value < F(2)**guess)


def exercise(label, n, peak_bits):
    base = F(n)
    root_side = 4 * base
    center = (base + F(1, 10),) * n
    old_centers = tuple((center[0] + shift, *center[1:]) for shift in (-1, 1))
    small_parent = cube(center, SU)
    old_parents = tuple(cube(c, ST) for c in old_centers)
    true_gates = tuple(intersection(small_parent, parent) for parent in old_parents)
    light_gates = tuple(intersection(expand(small_parent, SU / n), expand(parent, ST / n))
                        for parent in old_parents)
    assert intersection(*light_gates) is None
    assert all(volume(gate) == F(1, 4) for gate in true_gates)
    assert all(volume(gate) == (F(1, 4) + (SU + ST) / n) * (1 + F(1, n))**(n-1)
               for gate in light_gates)

    h = F(1, 16 * n)
    scale_steps = (int(root_side / h)).bit_length() - 1
    assert root_side / h == 2**scale_steps
    fine_depth = n * scale_steps + 1
    fine_anchor = (base + F(1, 3),) * (n - 1)
    left = dyadic_cell((true_gates[0][0][0], *fine_anchor), fine_depth, root_side)
    right = dyadic_cell((true_gates[1][0][1], *fine_anchor), fine_depth, root_side)
    coarse_steps = (int(4 * root_side)).bit_length() - 1
    middle = dyadic_cell((base + F(3, 8), *((base + F(1, 8),) * (n - 1))),
                         n * coarse_steps, root_side)
    large = ((F(0), base),) * n
    true_stops = (left, right, middle, large)
    angles = [tuple(hi - lo for lo, hi in box) for box in true_stops]
    assert max(angles[0]) == max(angles[1]) == h < SU / (2 * n)
    assert max(angles[2]) == F(1, 4) > SU / (2 * n)
    assert max(angles[2]) < 2 * n * SU == max(angles[3])
    assert all(max(sides) / min(sides) <= 2 for sides in angles)
    assert all(intersection(a, b) is None for i, a in enumerate(true_stops)
               for b in true_stops[i+1:])

    epsilon = F(1, 2**peak_bits)
    constant_fill = F(3, 2)
    fine_mass = constant_fill * volume(left)
    middle_mass = constant_fill * volume(middle)
    coarse_mass = constant_fill * volume(large)
    assert fine_mass == F(3, 4) * h**n
    outside_box = ((base + F(9, 16), base + F(19, 32)), *
                   (((base + F(3, 8), base + F(7, 16)),) * (n - 1)))
    outside_mass = volume(outside_box) / 2
    assert all(intersection(outside_box, box) is None for box in true_stops)
    assert intersection(outside_box, true_gates[1]) == outside_box
    local = (
        ("left small", crop_from_middle(intersection(left, true_gates[0]), epsilon), fine_mass),
        ("right small", crop_from_middle(intersection(right, true_gates[1]), epsilon), fine_mass),
        ("middle", crop_from_middle(intersection(middle, true_gates[1]), epsilon), middle_mass),
        ("large local", crop_from_middle(intersection(large, true_gates[0]), epsilon), LARGE_LOCAL),
        (OUTSIDE, outside_box, outside_mass),
    )
    bulk = ((F(0), base * epsilon), *large[1:])
    pieces = (*local, ("large bulk", bulk, coarse_mass - LARGE_LOCAL))
    root = ((F(0), root_side),) * n
    assert all(mass > 0 and intersection(box, root) == box for _, box, mass in pieces)
    assert all(intersection(a, b) is None for i, (_, a, _) in enumerate(pieces)
               for _, b, _ in pieces[i+1:])
    stops, depth = stopping_tree(root, pieces, fine_depth)
    assert stops == dict(zip(true_stops, (fine_mass, fine_mass, middle_mass, coarse_mass)))
    refill = (*(('refilled', box, mass) for box, mass in stops.items()), local[-1])
    assert sum(mass for _, _, mass in pieces) == sum(mass for _, _, mass in refill)
    assert max(mass / volume(box) for _, box, mass in refill) == constant_fill
    peak_density = max(mass / volume(box) for _, box, mass in pieces)
    assert peak_density >= constant_fill / epsilon

    receiver_half = SU / (32 * n)
    cores = tuple(cube(c, receiver_half) for c in (center, *old_centers))
    original_background = ((F(-1), root_side + 1),) * n
    all_sides = tuple(expand(core, F(1)) for core in cores)
    assert all(intersection(bulk, shell) is None for shell in all_sides)
    assert all(intersection(shell, original_background) == shell for shell in all_sides)
    local_sum = sum(mass for _, _, mass in local)
    # f=3/2 outside B. On B, f is the actual ledger density. Only the low packet
    # can decrease the original background, and all test cubes have volume >=1.
    height_lo = constant_fill - volume(outside_box)
    height_hi = constant_fill + local_sum
    assert 1 < height_lo and height_hi < 2
    assert volume(cores[0]) == (2 * receiver_half)**n

    prices = tuple(restrict_mass(pieces, gate) for gate in true_gates)
    assert prices == (LARGE_LOCAL + fine_mass, fine_mass + middle_mass + outside_mass)
    # The full ambient prices are separately defined if the Hall gate is omitted.
    source_support = tuple((name, box, volume(box)) for name, box, _ in pieces)
    ambient_prices = tuple(constant_fill * volume(gate) + price
                           - constant_fill * restrict_mass(source_support, gate)
                           for gate, price in zip(true_gates, prices))
    assert all(ambient > selected for ambient, selected in zip(ambient_prices, prices))

    small_keep = tuple(volume(intersection(q, a)) / volume(q)
                       for q, a in zip((left, right), true_gates))
    assert all(0 < share < 1 for share in small_keep)
    for block, gate in zip((left, right), light_gates):
        assert intersection(block, gate) == block
    middle_true = volume(intersection(middle, true_gates[1])) / volume(middle)
    middle_keep = volume(intersection(middle, light_gates[1])) / volume(middle)
    assert middle_true == F(3, 5)
    assert middle_keep == middle_true + F(3, n) < 1
    large_lite = constant_fill * volume(intersection(large, light_gates[0]))
    assert 0 < large_lite < LARGE_LOCAL
    assert restrict_mass(refill, light_gates[0]) == fine_mass + large_lite
    assert restrict_mass(refill, light_gates[1]) == fine_mass + outside_mass + middle_mass * middle_keep
    assert (restrict_mass(refill, light_gates[1]) - fine_mass - outside_mass) < middle_mass

    # This envelope is specified by public Q and n, independent of a source draw.
    outer_pad = F(3, 4) * max(angles[3]) / n
    assert outer_pad >= SU + receiver_half
    common_outer = expand(large, outer_pad)
    assert intersection(cores[0], common_outer) == cores[0]
    assert volume(common_outer) / volume(large) == (1 + F(3, 2*n))**n < 5
    assert volume(cores[0]) / coarse_mass == F(2, 3) * F(1, 32*n*n)**n

    # Same-point and same-cell real channels; here both original source groups
    # are disjoint, and each channel acts on its own actual input population.
    theta = F(1, 3)
    keep_left, keep_right = small_keep
    mixed_true = theta * (1-theta) * (keep_left + keep_right)
    both_true = ((1-theta) + theta * keep_left) * ((1-theta) + theta * keep_right)
    assert F(0) < mixed_true < 2 * theta * (1-theta)
    assert both_true == (1-theta)**2 + mixed_true + theta**2 * keep_left * keep_right < 1

    print(f"{label} n={n}, depth={depth}, peak cut=2^-{peak_bits}, floor log2(max f_B)={binary_floor(peak_density)}")
    print(f"  max g={constant_fill}, 4 disjoint stops with averages 3/2, side ratios 1 or 2")
    print(f"  small diam={h}, middle diam=1/4, large diam={n}; true local large source=1/64")
    print(f"  stop masses small (each)=(3/4)*({h})^{n}, middle=(3/2)*4^-{n}, large=(3/2)*{n}^{n}")
    print(f"  outside mass=(1/64)*16^-{n-1}; original Hall prices left=1/64+small, right=small+middle+outside")
    assert outside_mass == F(1, 64) * F(1, 16)**(n-1)
    assert all(F(3, 8) < price < F(13, 32) for price in ambient_prices)
    print("  true intersection Lebesgue volume=1/4 each; ambient prices in (3/8,13/32) "
          "by exact 3/8 + Hall price - (3/2)|B intersection gate|")
    print(f"  original/light refill fractions small L,R={small_keep[0]},{small_keep[1]} -> 1,1; "
          f"middle R={middle_true} -> {middle_keep}, unpaid={1-middle_keep}")
    print(f"  enlarged large-block mass / true local large mass has floor log2 {binary_floor(large_lite/LARGE_LOCAL)}")
    print(f"  real E_u volume=(1/{32*n})^{n}; one public large-Q envelope volume / |Q|="
          f"(1+3/{2*n})^{n}<5")
    print(f"  lambda |E_u| / true large stop mass=(2/3)*(1/{32*n*n})^{n}")
    print(f"  same-point/same-cell mixture cross terms, share of m_Lsmall*m_Rsmall "
          f"original={mixed_true}, light=4/9; total original={both_true}, light=1")


if __name__ == "__main__":
    print(f"Python {version.split()[0]}; exact Fraction with piecewise constant absolutely continuous measures.")
    print("Cyclic coordinates start at axis 1, tau=1, fixed A_u side=1 and two edge parents side=3/2.")
    print("All three genuine positive receiver cores have centered maximal height in (1,2) on side window [1,2].")
    print("Hall price is mu_B(A_t intersection A_u) on true source support B. Ambient f=3/2 off B, f_B on B.")
    print("Small threshold is s_u/(2n), large is 2 n s_u. The middle loss stays in the ledger.")
    print("The remote bulk and edge packet are separate. Each spike may narrow further with its exact mass fixed.")
    print("For theta=1/3 the full source output of the two-channel kernel equals (1-theta) mu_B+theta g dx.")
    exercise("INITIAL", 8, 4)
    exercise("PRESSURE", 16, 12)
    exercise("EXPANDED", 64, 24)
