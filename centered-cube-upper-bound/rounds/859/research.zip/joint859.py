"""R859 exact alternative payment: a shared source or one of U,W,T0."""

from argparse import ArgumentParser
from collections import defaultdict
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
from zipfile import ZipFile
import json
import sys


PIN858="7224b3ca13f4f5293676e5fa520e4230369c10e0453bfee6f348b0b20edb20da"
PIN_HELPER="edcf755e059cd0080e2ab8cb8af563381098fa7c20982f985c5901c7f754b622"


def helpers(rounds):
    path=rounds/"858"/"research.zip"
    assert sha256(path.read_bytes()).hexdigest()==PIN858
    with ZipFile(path) as z:
        code=z.read("reprice858.py")
        manifest=json.loads(z.read("MANIFEST.json"))
    assert sha256(code).hexdigest()==manifest["sha256"]["reprice858.py"]==PIN_HELPER
    main={"__name__":"joint859_reprice","__file__":"reprice858.py"}
    exec(compile(code,"reprice858.py","exec"),main)
    # The pinned original code already constructs and verifies all
    # transfers. Expose that local witness in a separate in-memory
    # namespace, leaving all input files and peak() semantics untouched.
    text=code.decode()
    old="return carried, rows, cols, (demand, capacity, cut_cells)"
    assert text.count(old)==1
    instrumented={"__name__":"joint859_witness","__file__":"reprice858.py"}
    exec(compile(text.replace(old,old+", solution"),"reprice858.py","exec"),instrumented)
    return main,instrumented["network"]


def volume(box):
    value=F(1)
    for a,b in box:
        assert a<b
        value*=b-a
    return value


def configuration(raw,parents,src):
    data={}
    source_units={("source",w):m for w,m in src.items()}
    receiver_units={}
    for key,amount in sorted(raw.items()):
        t,left,right=key
        u,g=left[0],right[0]
        bits=parents[t]["bit"]|parents[u]["bit"]|parents[g]["bit"]
        sources=tuple(("source",w) for w in sorted(src) if w&bits)
        assert sources
        for h in (0,1):
            recs=frozenset((("receiver",u,left[2]),("receiver",g,right[2]),("receiver",t,h)))
            assert len(recs)==3
            for a,i,k in recs:
                parent=parents[i]
                assert volume(parent["owner_halves"][k])==parent["owner_volume"]/2
                assert 0<parent["j"]/2<=parent["owner_volume"]/2
                receiver_units[(a,i,k)]=parent["j"]/2
            data[key,h]=(amount/2,sources,tuple(sorted(recs)))
    assert len(data)==2*len(raw)==1840
    assert all(data[key,0][0]+data[key,1][0]==amount for key,amount in raw.items())
    assert sum(x[0] for x in data.values())==sum(raw.values())
    return data,source_units,receiver_units


def build(data,mode):
    demands=defaultdict(F)
    lookup={}
    for row,(weight,S,R) in data.items():
        pool=S if mode=="source" else R if mode=="receiver" else tuple(sorted(S+R))
        assert len(pool)==len(set(pool))
        lookup[row]=pool
        demands[pool]+=weight
    return demands,lookup


def solve(data,original,db,capacities,certified_net):
    demands,lookup=db
    value,rows,columns,cut,solution=certified_net(demands,capacities,F(1))
    mass=sum(original.values())
    assert mass==sum(demands.values())
    assert value==sum(rows.values())==sum(columns.values())==sum(solution.values())
    flows=defaultdict(dict)
    for (pool,res),amt in solution.items():
        flows[pool][res]=amt
    realized=defaultdict(F)
    totals=defaultdict(F)
    actual_receivers=defaultdict(F)
    actual_sources=defaultdict(F)
    examples={}
    physical_hits=set()
    for pair,(weight,source,receiver) in data.items():
        key,t_half=pair
        pool=lookup[pair]
        fraction=weight/demands[pool]
        local=F(0)
        for res,v in flows[pool].items():
            amt=v*fraction
            assert amt>0 and (res in source or res in receiver)
            if res[0]=="receiver":
                assert res in receiver
                actual_receivers[res]+=amt
            else:
                assert res in source
                actual_sources[res]+=amt
            local+=amt
            totals[res[0]]+=amt
            examples.setdefault(res[0],(pair,res,amt))
        assert local<=weight and local==rows.get(pool,0)*fraction
        if local>0:
            physical_hits.add(pair)
        realized[key]+=local
    assert all(realized[key]<=x for key,x in original.items())
    assert sum(realized.values())==sum(totals.values())==value
    for used in (actual_sources,actual_receivers):
        assert all(v==columns[k]<=capacities[k] for k,v in used.items())
    demand,cap,res=cut
    source_cut=sum(capacities[k] for k in res if k[0]=="source")
    recv_cut=sum(capacities[k] for k in res if k[0]=="receiver")
    assert cap==source_cut+recv_cut and value==mass-demand+cap
    return value,totals,(demand,source_cut,recv_cut,res),examples,len(physical_hits)


def replay(rounds):
    helper,net=helpers(rounds)
    parents,src,raw,fmt,pin814=helper["load"](rounds)
    data,sources,receivers=configuration(raw,parents,src)
    independent,_,_=helper["strata"](raw,src,parents,"central",True)
    K=max(helper["peak"](d,src)[0] for d in independent.values())
    demand_sets={kind:build(data,kind) for kind in ("source","receiver","joint")}
    Pstar,Pcut=helper["peak"](demand_sets["receiver"][0],receivers)
    mass=sum(raw.values())
    assert Pstar>0 and Pcut[0]==Pstar*Pcut[1]

    print("R858",PIN858,"; reprice",PIN_HELPER)
    print("R814",pin814,"; positive originals",len(raw),"with two exact T0 halves each.")
    print(" K=C0",fmt(K),"; P_rec* (one of the three true positions)",fmt(Pstar))
    print("  Receiver critical cut: demand/original",fmt(Pcut[0]/mass),
          "; actual sum j_i/2",Pcut[1],"; physical half-cores",Pcut[2])
    print("  Original two sources and U,W stay attached; a payment chooses one permitted resource.")
    print("  Each physical (father,half) capacity is P*j_i/2. The same index across roles uses it once.")
    source_cap={k:v*K for k,v in sources.items()}

    def nice(v):
        return fmt(v) if v else "0"

    independent_src=solve(data,raw,demand_sets["source"],source_cap,net)
    productive=0
    for theta in (F(0),F(1,8),F(1,4),F(1,2),F(1)):
        P=theta*Pstar
        rec_cap={k:v*P for k,v in receivers.items()}
        receiver=solve(data,raw,demand_sets["receiver"],rec_cap,net)
        joint=solve(data,raw,demand_sets["joint"],source_cap|rec_cap,net)
        assert joint[0]>=max(independent_src[0],receiver[0])
        if theta==0:
            assert receiver[0]==0 and joint[0]==independent_src[0]
        if theta==1:
            assert joint[0]==receiver[0]==mass
        if joint[0]>max(independent_src[0],receiver[0]):
            productive+=1
            assert joint[1]["source"]>0 and joint[1]["receiver"]>0
        print(" P/P_rec*",theta,"; paid/original source only, receiver only, joint:",
              *(nice(v[0]/mass) for v in (independent_src,receiver,joint)))
        print("   joint source/receiver decomposition:",
              *(nice(joint[1].get(k,0)/mass) for k in ("source","receiver")),
              "; positive expanded originals",joint[4])
        for name,res in (("source",independent_src),("receive",receiver),("joint",joint)):
            d,a,b,_=res[2]
            print("   ",name,"dual (cut demand, source cap, receiver cap)/original:",
                  *(nice(v/mass) for v in (d,a,b)))
        if theta in (F(1,8),F(1,4),F(1,2)):
            cut=joint[2][3]
            sm=sum(sources[k] for k in cut if k[0]=="source")
            rm=sum(receivers[k] for k in cut if k[0]=="receiver")
            assert K*sm==joint[2][1] and P*rm==joint[2][2]
            print("    exact joint cut: true mu",sm,"; actual sum j_i/2",rm)
            print("    source masks",tuple(k[1] for k in cut if k[0]=="source"),
                  "; receiver halves",tuple(k[1:] for k in cut if k[0]=="receiver"))
        if theta==F(1,4):
            for kind,(pair,key,amt) in sorted(joint[3].items()):
                print("    witnessed positive original subrow",pair,
                      "spends one",kind,key,"; amount",nice(amt))
    assert productive>0
    print("Strict joint gain over either single resource in",productive,"tested positive-price settings.")


if __name__=="__main__":
    parser=ArgumentParser()
    parser.add_argument("--rounds",type=Path,required=True)
    args=parser.parse_args()
    print("Python",sys.version.split()[0],"| exact Fraction primal, dual, and physical witness")
    replay(args.rounds)
    print("All assertions passed. Finite real R814 calibration of alternative resources.")
