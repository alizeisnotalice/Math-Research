"""Exact cut-monotonicity and degree tests for the two-channel allocation.
Only the cube geometry and transfer are tested in dimension one.
"""
from bisect import bisect_right
from fractions import Fraction as F
from functools import lru_cache
from itertools import pairwise
from math import isqrt
import sys

BITS = 22
M = F(2)
def integer_root(value, order):
    if order == 2:
        return isqrt(value)
    lo, hi = 0, 1 << ((value.bit_length() + order - 1)//order + 1)
    while hi-lo > 1:
        mid = (lo+hi)//2
        if mid**order <= value:
            lo = mid
        else:
            hi = mid
    return lo

@lru_cache(maxsize=None)
def clipped_power(value, num, den):
    if value >= 1:
        return F(1)
    assert value >= 0
    scaled = value**num * (2**BITS)**den
    result = integer_root(scaled.numerator//scaled.denominator, den)
    assert result**den <= scaled < (result+1)**den
    return F(result, 2**BITS)

@lru_cache(maxsize=None)
def source_share(b, p, q):
    if b == 0:
        return F(1)
    # r=p/q, value under the p-th root is (1+M/b)^q/b^p.
    return clipped_power((1+M/b)**q/b**p, 1, p)

def attenuation(raw, p, q):
    if raw <= 1:
        return F(1)
    return clipped_power(1/raw, p-q, p)

def parents(depth):
    result = []
    for level in range(depth):
        size = F(2**level)
        for sign in (-1, 1):
            for j in range(16):
                center = sign * size*F(33+2*j,64)
                owner_lo,owner_hi = center-size/64,center+size/64
                result.append((center-size,center+size,size,owner_lo,owner_hi))
    owners = sorted((a,b) for _,_,_,a,b in result)
    assert all(hi <= lo for (_,hi),(lo,_) in pairwise(owners))
    return result

def weights(geometry,cut):
    answer = []
    for x,y,s,lo,hi in geometry:
        if cut == "full":
            r = F(1)
        elif cut == "half":
            # A contains exactly the left half of every disjoint true owner.
            r = F(1,2)
        else:
            # Source cut B=[-24,24] as a union of measurable cells plus the
            # receptor cut A of the previous line. Labels not fully in B are removed.
            r = F(1,2) if x >= -24 and y <= 24 else F(0)
        answer.append(r*(hi-lo)/(2*s))
    return answer

def profile(geometry,bs,p,q):
    # Work on cells with exact endpoints. Uniform source has density one.
    sites = set()
    for x,y,s,_,_ in geometry:
        sites.update((x,y))
        for j in range(x//s,y//s+2):
            sites.add(j*s)
    sites = sorted(sites)
    slices = list(pairwise(sites))
    centers = [(x+y)/2 for x,y in slices]
    b_values = [sum((b for b,(l,h,_,_,_) in zip(bs,geometry) if l<=x<h),F())
                for x in centers]
    shares = [source_share(b,p,q) for b in b_values]
    residual_cdf = {sites[0]: F(0)}
    for (x,y),a in zip(slices,shares):
        residual_cdf[y] = residual_cdf[x]+(y-x)*(1-a)
    events = {x:F(0) for x in sites}
    for (lo,hi,s,_,_),b in zip(geometry,bs):
        if not b:
            continue
        for j in range(lo//s,hi//s+1):
            edge=j*s
            a,c = max(lo,edge),min(hi,edge+s)
            if c>a:
                density = b*(residual_cdf[c]-residual_cdf[a])/s
                events[edge]+=density
                events[edge+s]-=density
    raw=[]; current=F(0)
    for x,_ in slices:
        current+=events[x]
        raw.append(current)
    assert current+events[sites[-1]]==0 and min(raw)>=0
    attenuation_values = [attenuation(v,p,q) for v in raw]
    # F^r<=F0 and b(bp_r)^r<=b+M as integer-power inequalities.
    for b,a,v,theta in zip(b_values,shares,raw,attenuation_values):
        assert (v*theta)**p<=v**q
        assert b**q*(b*a)**p <= (b+M)**q
    raw_total=sum(((hi-lo)*v for (lo,hi),v in zip(slices,raw)),F())
    genuine_total=sum((b*(hi-lo) for (lo,hi,_,_,_),b in zip(geometry,bs)),F())
    assert raw_total==sum(((hi-lo)*b*(1-a) for (lo,hi),b,a in zip(slices,b_values,shares)),F())
    assert raw_total<=genuine_total
    def at(z):
        return bisect_right(sites,z)-1
    paper_probe=F(1,1024) # all quantities at the probe remain constant on (0,1/1024].
    i=at(paper_probe)
    assert all(lo < paper_probe < hi for lo,hi,_,_,_ in geometry)
    def retained(s):
        return shares[i]+(1-shares[i])*sum(
            ((min(s,y)-max(F(),x))*t for (x,y),t in zip(slices,attenuation_values)
               if max(F(),x)<min(s,y)),F())/s
    s_values=sorted({s for _,_,s,_,_ in geometry})
    return b_values,shares,raw,attenuation_values,[retained(s) for s in s_values],(
        b_values[i],max(raw),raw_total/genuine_total,retained(s_values[0]),retained(s_values[-1]))

def summarise(v):
    return ",".join(format(float(q),".7f") for q in v)

def arithmetic():
    # Explicit legal exponents for the public transport theorem for 20 cases.
    for a in (F(1,10),F(1),F(10),F(100),F(1000)):
        for b in (F(0),F(1,4),F(49,100),F(4999,10000)):
            margin=F(1,2)-b
            r=1+margin/(4*(1+a+b))
            p=8*(1+a+b)/margin
            exponent=F(1,2)+b+(a+b)*(r-1)+2*(1+a+b)/p
            assert exponent<=1-margin/2 < 1
    print("20 exact exponent checks; remaining power is at least half of 1/2-b.")

if __name__=="__main__":
    print("Python",sys.version.split()[0],"Fraction, downward dyadic roots at",BITS,"bits")
    for depth in (3,5,8,16):
        geometry=parents(depth)
        print("physical levels",depth,"disjoint owners",len(geometry))
        for p,q in ((3,2),(2,1),(3,1)):
            rows=[profile(geometry,weights(geometry,cut),p,q) for cut in ("full","half","both")]
            for a,b in pairwise(rows):
                assert all(x>=y for x,y in zip(a[0],b[0]))
                assert all(x<=y for x,y in zip(a[1],b[1]))
                assert all(x>=y for x,y in zip(a[2],b[2]))
                assert all(x<=y for x,y in zip(a[3],b[3]))
                assert all(x<=y for x,y in zip(a[4],b[4]))
            print(" r",F(p,q),"full/half/both (source crowding, max raw fill, raw fraction, first- and last-scale retained):")
            for row in rows:
                print("  "+summarise(row[5]))
            if depth==16:
                assert rows[0][5][1]>1 and rows[0][4][0]<rows[1][4][0]
    arithmetic()
    print("Continuous interval transport algebra only; no R813 high-dimensional sample.")
