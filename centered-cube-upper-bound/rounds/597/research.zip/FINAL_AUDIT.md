# R597 最终独审

**PASS，无剩余必须修复项。** 通过范围为已证局部公式、完整事件筛查和两个冻结九点模型的有限几何证书；完整全局下界及一般根阶改善仍未证明。

最终 REPORT SHA256：
`0533d4b98a0ff92b8ae9fd015f72444c3c7b20424fbe8b91de8458436f1699c0`

最终 `/tmp/ccu_r597_probe.py` SHA256：
`297cb7f4ecb41093127ea2a8bdf73d1ee34941df89d9e5ad62e3dc7738a1ee3a`

已全文审核原整合版；最终只改计时范围，修订句及上述最终哈希已实际核对。前置独立意见、两次尝试、尺度证书及独立手证分别见本地 `ccu_r597_pre_audit.md`、`ccu_r597_attempt_audit.md`、`ccu_r597_scale_audit.md`、`ccu_r597_geometry_audit.md`；不将其余未审历史自动纳入 PASS。

## 完成的核验

- 全部有限来源、正体积 carrier 的完整 E、固定负背景和 strict 阈值保持一致；R596 条件 q>=max(1,C_n/2)、显示指数因子、固定 n 后 nearmax 极限及全部反馈商未丢失。有限例仅认证 q>=1，未认证 nearmax。
- 共同 dyadic 顶尺度、细尺度相位、边界与一次来源容量合法。避边概率只在 r<=s 使用；局部密度包含测试没有被写成实际接收的必要条件或统一收缩。原作者模糊渐近在报告中已删，仅保留精确门槛。
- Signed flux 的 Fubini 及 critical cutoff 方向正确；指定例 B=5/84>0、ell-W/r=13/168>0 确实说明该尺度正 flux 不等于接收。没有对 signed 总质量套正弱型。
- 新增一次事件正部下界系数正确；进入面 Jacobian 没有被当作累计来源费用。Tonelli/singleton 排除所得熵式为上界，报告明确它不提供正下界，也未称熵为一般问题必要损失。
- 每个模型全部511子集被实际生成。精确不交分解与真实 singleton/pair 双向覆盖认证完整 E：正 carrier 数305/17，分解片9/25，体积均21-8sqrt(2)。未用单父体积和冒充并集。
- 手工核对匹配点的三项交面积与 qF 公式；P 正、D 首两事件负，D 后续全部尺度由质量9上界排除。更正后的风险点没有被继续用作负例。比较仅说明相同 q、同一测试尺度/质量不足以决定接收，不声称两输入全部事件历史相同。
- 两个半边长1e-5闭盒的 E 分离、r变化至多2h、query cube 内外嵌套r0±4h、covered-area界方向及首两事件质量稳定均正确。P给严格正下界；D给严格负上界及全部晚事件排除。不是由点采样外推邻域。
- Fraction squarefree radical 表达的规范乘法、精确零、Arb512严格符号和失败抛错逻辑通过；无浮点几何或符号回退。独立geometry稿未读数值实现，其更大1e-4开邻域未被冒充代码已认证的闭盒。

## 实际证据与运行范围

已实际用本机 Python 比较 full结果与root复跑，去掉execution后全部字段一致。full结果SHA为 `37ad3d25c0845dfb956a245b5cc5b263fa703d2b75b926abc18397d7774103d2`。同码复跑不等于独立算法。

精简结果SHA为 `22246fa1c55f1adf1596b0dfd13e063c9ceb83ed19d350b3d083884e84c9077b`。全部共同保留字段无差异，matched/risk完整events与full probes逐项相同；删去的全subset/矩形及一般probe明细可由脚本再生。19 probes、两小盒与执行摘要均与报告一致，不代表A_theta总体积估计。

额外 independent_algebra.py SHA为 `edb856a661e354280dfaa6b01a78dc3774831dc91b4260aaba2c982e8116c2c8`。其integer-sqrt生成包围、精确平方和符号传播正确；已用Fraction实际核对JSON包围宽度1e-60及各符号。它只检查手推点公式，不独立枚举halo或认证moving-box交面积；初次手抄端点失败及更正范围准确记录。

本次实际运行小型SymPy检查了flux/临界余量、三项qF化简和Tonelli原函数，残差为零；另运行哈希及JSON比对。没有重跑probe枚举/扫描或额外符号脚本，也没有把其他代理的运行写成审核者重跑。

**计时修正已读回：** timer/alarm不含imports、argparse及JSON输出；约0.12秒是main computation计时，不是端到端进程时间或全流程硬timeout。512MiB是计算后的budget检查，非OS内存cap。报告准确。

仍缺完整deficit、whole-E mask及跨尺度/来源去重的联合正预算。有限证书不给uniform eta_n、L_n或一般维数收益。无新增扫描、repo/git、spawn或PDF；至此结束本轮审核。
