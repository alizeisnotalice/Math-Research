from fractions import Fraction as F
from pathlib import Path
import json,sys,hashlib,platform,math
den=10**60
lo=F(math.isqrt(2*den*den),den)
hi=lo+F(1,den)
assert lo*lo<2<hi*hi
expressions={'product_pair':(F(-7,12),F(17,36),1),'diagonal_pair':(F(-1607,2400),F(17,36),-1),'diagonal_single':(F(-8043,10000),F(3571,7500),-1),'q_minus_one':(F(4,3),F(-8,9),1),'pair_source_gate':(F(-1,48),F(2,9),1),'single_source_gate':(F(-7,25),F(424,1875),1)}
results={}
for name,(c,d,sgn) in expressions.items():
 lower=c+d*(lo if d>=0 else hi);upper=c+d*(hi if d>=0 else lo)
 assert lower>0 if sgn>0 else upper<0
 results[name]={'lower':str(lower),'upper':str(upper),'certified_sign':sgn}
far=F(9)-F(3,4)*(F(7,2)-F(2,100000))**2
assert far<0
out={'scope':'Independent exact-rational sign check of hand-derived matched point formulas, NOT independent full-halo enumeration or neighborhood overlap verification. Square-root endpoints certified by exact squaring.','sqrt2_lower':str(lo),'sqrt2_upper':str(hi),'results':results,'far_event_neighborhood_bound':str(far),'rounding_error':'zero for all rational arithmetic; sqrt2 enclosed in stated interval','execution':{'python':platform.python_version(),'interpreter':sys.executable,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}}
Path(sys.argv[1]).write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'all_exact_rational_checks_pass':True,'sqrt2_interval_width':str(hi-lo),'far_upper':str(far)}))
