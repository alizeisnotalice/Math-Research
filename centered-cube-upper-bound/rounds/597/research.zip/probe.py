#!/usr/bin/env python3
"""Two frozen nine-source models: exact full E, finite all-scale event tests."""
import argparse,hashlib,itertools,json,math,platform,resource,shlex,signal,sys,time
from fractions import Fraction as F
from functools import lru_cache
from pathlib import Path
import flint
from flint import arb,ctx

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=Path(__file__).with_name('ccu_r597_results.json'));args=ap.parse_args();start=time.perf_counter();ctx.prec=512;LIMIT=512*1024**2
 def timeout(*_):raise TimeoutError('120s guard; no omitted source family')
 signal.signal(signal.SIGALRM,timeout);signal.alarm(120)
 Z=();ONE=((1,F(1)),);theta=F(1,4)
 def pack(d):return tuple(sorted((r,c) for r,c in d.items() if c))
 def rat(q):q=F(q);return ((1,q),) if q else Z
 def add(a,b):
  d=dict(a)
  for r,c in b:d[r]=d.get(r,F(0))+c
  return pack(d)
 def scale(a,q):return tuple((r,c*q) for r,c in a if c*q)
 def sub(a,b):return add(a,scale(b,-1))
 @lru_cache(maxsize=30000)
 def mul(a,b):
  d={}
  for r,c in a:
   for s,e in b:
    g=math.gcd(r,s);k=r*s//g**2;d[k]=d.get(k,F(0))+c*e*g
  return pack(d)
 @lru_cache(None)
 def av(a):return sum((arb(c.numerator)/c.denominator*arb(r).sqrt() for r,c in a),arb(0))
 @lru_cache(maxsize=40000)
 def sign(a):
  if not a:return 0
  x=av(a)
  if x>0:return 1
  if x<0:return -1
  raise ArithmeticError('Arb512 sign unresolved; no float fallback')
 def out(a):return {'exact_squarefree_radical_terms':[[r,str(c)] for r,c in a],'Arb512':av(a).str(65)}
 @lru_cache(None)
 def root(n):
  c=1;r=1;p=2
  while p*p<=n:
   e=0
   while n%p==0:e+=1;n//=p
   c*=p**(e//2)
   if e%2:r*=p
   p+=1 if p==2 else 2
  if n>1:r*=n
  return ((r,F(c)),)
 def mini(a,b):return a if sign(sub(a,b))<=0 else b
 def maxi(a,b):return a if sign(sub(a,b))>=0 else b
 def volume(B):return mul(sub(B[0][1],B[0][0]),sub(B[1][1],B[1][0]))
 def intersection(B,C):
  D=tuple((maxi(a,c),mini(b,d)) for (a,b),(c,d) in zip(B,C))
  return D if all(sign(sub(b,a))>0 for a,b in D) else None
 def inside_box(B,C):return all(sign(sub(B[j][0],C[j][0]))>=0 and sign(sub(C[j][1],B[j][1]))>=0 for j in range(2))
 def query_box(x,r):return tuple((rat(v-r/2),rat(v+r/2)) for v in x)
 def covered(Q,rects):
  v=Z
  for B in rects:
   I=intersection(Q,B)
   if I:v=add(v,volume(I))
  return v
 def point_inside(x,rects):return any(all(sign(sub(rat(x[j]),B[j][0]))>=0 and sign(sub(B[j][1],rat(x[j])))>=0 for j in range(2)) for B in rects)
 def full_boxes(z):
  boxes={};records=[]
  for S in range(1,512):
   ids=[i for i in range(9) if S>>i&1];m=len(ids);h=scale(root(m),F(1,2));bb=[(min(z[i][j] for i in ids),max(z[i][j] for i in ids)) for j in range(2)]
   B=tuple((sub(rat(hi),h),add(rat(lo),h)) for lo,hi in bb);sg=[sign(sub(b,a)) for a,b in B]
   boxes[S]=B if min(sg)>0 else None;records.append({'mask':S,'mass':m,'bbox':[[str(a),str(b)] for a,b in bb],'width_signs':sg,'positive_carrier':min(sg)>0})
  return boxes,records
 models=[];private={};expected=sub(rat(21),scale(root(2),8))
 for name in ('product','diagonal'):
  z=[(F(i),F(j)) for i in range(3) for j in range(3)] if name=='product' else [(F(i),F(i)) for i in range(9)]
  boxes,records=full_boxes(z);rects=[];pieceparents=[]
  if name=='product':
   base=((rat(F(-1,2)),rat(F(5,2))),(rat(F(-1,2)),rat(F(5,2))))
   # The nine actual singleton unit squares tile base exactly on its 3x3 grid.
   assert [F(-1,2)+i for i in range(4)]==[F(-1,2),F(1,2),F(3,2),F(5,2)]
   for i in range(9):assert inside_box(boxes[1<<i],base)
   singles=[boxes[1<<i] for i in range(9)]
   for B,C in itertools.combinations(singles,2):assert intersection(B,C) is None
   single_area=Z
   for B in singles:single_area=add(single_area,volume(B))
   assert single_area==volume(base)
   rects.append(base);pieceparents.append('exact 3x3 tiling by all nine singleton squares')
   for axis in range(2):
    for fixed in (0,2):
     for k in range(2):
      p=(k,fixed) if axis==0 else (fixed,k);q=(k+1,fixed) if axis==0 else (fixed,k+1);i=z.index(p);j=z.index(q);S=(1<<i)|(1<<j);B=boxes[S];assert B
      transverse=1-axis;D=list(B)
      D[transverse]=(B[transverse][0],rat(F(-1,2))) if fixed==0 else (rat(F(5,2)),B[transverse][1])
      D=tuple(D);assert volume(D) and inside_box(D,B);rects.append(D);pieceparents.append(S)
  else:
   for i in range(9):rects.append(boxes[1<<i]);pieceparents.append(1<<i)
   for i in range(8):
    S=(1<<i)|(1<<(i+1));B=boxes[S];assert B;mid=rat(F(2*i+1,2))
    extra1=((B[0][0],mid),(mid,B[1][1]));extra2=((mid,B[0][1]),(B[1][0],mid))
    for D in (extra1,extra2):assert inside_box(D,B);rects.append(D);pieceparents.append(S)
  for a,b in itertools.combinations(rects,2):assert intersection(a,b) is None
  # Independent complete-subset containment check, not merely trusting a structural formula.
  for S,B in boxes.items():
   if B:assert covered(B,rects)==volume(B),'Incomplete proposed E decomposition'
  v=Z
  for B in rects:v=add(v,volume(B))
  assert v==expected;q=scale(v,F(1,9));assert sign(sub(q,ONE))>0
  offsets=[F(51,100),F(21,40),F(11,20),F(3,5)];anchor=z[-1];probes=[]
  for delta in offsets:
   for direction in ((1,0),(1,1)):
    probes.append(('frozen_anchor_'+str(delta)+'_'+str(direction),(anchor[0]+delta,anchor[1]+delta*direction[1])))
  probes.append(('final_matched_probe',(F(275,100),F(149,100)) if name=='product' else (F(775,100),F(744,100))))
  if name=='diagonal':probes.append(('superseded_risk_probe_not_final_match',(F(775,100),F(749,100))))
  results=[]
  for tag,x in probes:
   if point_inside(x,rects):
    results.append({'tag':tag,'x':list(map(str,x)),'inside_E':True,'A_theta_eligible':False});continue
   radii=sorted(set(2*max(abs(x[j]-p[j]) for j in range(2)) for p in z));assert radii[0]>0
   events=[];maxJ=Z;maxSource=Z
   for r in radii:
    ids=[i for i,p in enumerate(z) if all(2*abs(x[j]-p[j])<=r for j in range(2))];m=len(ids);I=covered(query_box(x,r),rects)
    source=sub(scale(q,m),scale(sub(q,rat(theta)),r*r));J=sub(source,scale(I,theta))
    if sign(sub(J,maxJ))>0:maxJ=J
    if sign(sub(source,maxSource))>0:maxSource=source
    events.append({'r_exact':str(r),'captured_labels':ids,'captured_mass':m,'source_deficit_exact':str(r*r-m),'covered_area':out(I),'exterior_area':out(sub(rat(r*r),I)),'source_only_qF':out(source),'source_only_sign':sign(source),'actual_qF':out(J),'actual_sign':sign(J),'actual_F_Arb512':(av(J)/av(q)).str(65)})
   member=sign(maxJ)>0;gate=sign(maxSource)>0
   cls='joint_witness' if member else 'complete_E_masked' if gate else 'source_limited'
   results.append({'tag':tag,'x':list(map(str,x)),'inside_E':False,'all_unique_positive_source_entry_events':events,'maximum_positive_part_qF':out(maxJ),'source_gate_maximum_positive_part':out(maxSource),'A_theta_member':member,'source_only_gate':gate,'classification':cls,'scale_completeness':'Strict decrease between source entries; r->0 contributes0 to positive-part supremum; all tied labels captured together at each closed event.'})
  models.append({'name':name,'sources_rational':[list(map(str,p)) for p in z],'masses':['1']*9,'all_511_actual_source_subsets':records,'exact_disjoint_E_rectangles':[{'bounds':[[out(a),out(b)] for a,b in B],'actual_subset_witness':S} for B,S in zip(rects,pieceparents)],'E_volume':out(v),'q':out(q),'decomposition_certificate':{'all_511_subsets_generated':True,'all_positive_carriers_covered_exactly_by_disjoint_E':True,'every_piece_received_by_actual_singleton_or_pair':True,'pieces_pairwise_disjoint_up_to_null_boundaries':True,'exact_area_minus_21_plus_8sqrt2':[],'positive_subset_count':sum(B is not None for B in boxes.values()),'disjoint_piece_count':len(rects)},'probes':results})
  private[name]=(z,rects,q,results)
 # Small matched neighborhoods, h fixed by root. Conservative nesting bounds
 # avoid pretending the moving query cube has fixed source/face geometry.
 h=F(1,100000);neighborhoods={}
 for name,center in [('product',(F(275,100),F(149,100))),('diagonal',(F(775,100),F(744,100)))]:
  z,rects,q,probes=private[name];chosen=next(p for p in probes if p['tag']=='final_matched_probe');assert not chosen['inside_E']
  separations=[]
  for B in rects:
   gaps=[sub(B[j][0],rat(center[j]+h)) for j in range(2)]+[sub(rat(center[j]-h),B[j][1]) for j in range(2)]
   positives=[g for g in gaps if sign(g)>0];assert positives;separations.append(out(positives[0]))
  if name=='product':
   chosen_sources=[i for i,p in enumerate(z) if p in [(F(2),F(1)),(F(2),F(2))]];assert len(chosen_sources)==2
   for i in chosen_sources:assert center[0]-z[i][0]-h>abs(center[1]-z[i][1])+h
   r0=F(3,2);upperI=covered(query_box(center,r0+4*h),rects)
   lowerJ=sub(sub(scale(q,2),scale(sub(q,rat(theta)),(r0+2*h)**2)),scale(upperI,theta));assert sign(lowerJ)>0
   neighborhoods[name]={'center':list(map(str,center)),'halfside':str(h),'area_exact':str((2*h)**2),'outside_E_for_every_center':True,'conclusion':'every center belongs to A_theta','positive_lower_qF':out(lowerJ),'witness_radius':'2(x_coordinate-2)','captured_fixed_labels':chosen_sources,'outer_comparison_cube_r':str(r0+4*h),'upper_covered_area':out(upperI),'per_E_piece_positive_separation_guards':separations}
  else:
   events=chosen['all_unique_positive_source_entry_events'];assert F(events[0]['r_exact'])==F(28,25) and F(events[1]['r_exact'])==F(3,2)
   radii=[F(e['r_exact']) for e in events]
   assert all(b-a>4*h for a,b in zip(radii,radii[1:]))
   # No max-coordinate switch occurs in this receiver box for any diagonal source.
   for p in z:assert abs(abs(center[0]-p[0])-abs(center[1]-p[1]))>2*h
   bounds=[]
   for r0,m in ((F(28,25),1),(F(3,2),2)):
    lowerI=covered(query_box(center,r0-4*h),rects)
    upperJ=sub(sub(scale(q,m),scale(sub(q,rat(theta)),(r0-2*h)**2)),scale(lowerI,theta));assert sign(upperJ)<0
    bounds.append({'r_at_center':str(r0),'captured_mass_stable':m,'inner_comparison_cube_r':str(r0-4*h),'lower_covered_area':out(lowerI),'strict_negative_upper_qF':out(upperJ)})
   assert radii[2]==F(7,2)
   far=F(9)-F(3,4)*(F(7,2)-2*h)**2;assert far<0
   neighborhoods[name]={'center':list(map(str,center)),'halfside':str(h),'area_exact':str((2*h)**2),'outside_E_for_every_center':True,'conclusion':'no center belongs to A_theta','first_two_event_upper_bounds':bounds,'all_later_event_source_only_F_upper_exact':str(far),'per_E_piece_positive_separation_guards':separations}
 pair_events={}
 for model in models:
  probe=next(p for p in model['probes'] if p['tag']=='final_matched_probe');event=next(e for e in probe['all_unique_positive_source_entry_events'] if F(e['r_exact'])==F(3,2));assert event['captured_mass']==2;pair_events[model['name']]=event
 assert pair_events['product']['actual_sign']>0 and pair_events['diagonal']['actual_sign']<0
 assert next(p for p in models[0]['probes'] if p['tag']=='final_matched_probe')['A_theta_member']
 assert not next(p for p in models[1]['probes'] if p['tag']=='final_matched_probe')['A_theta_member']
 assert next(p for p in models[1]['probes'] if p['tag']=='superseded_risk_probe_not_final_match')['A_theta_member']
 if resource.getrusage(resource.RUSAGE_SELF).ru_maxrss>LIMIT:raise MemoryError('512MiB guard')
 signal.alarm(0)
 result={'scope':'Two frozen nine-unit-source n2 models, exact full E and19 fixed exterior probes including the explicitly superseded risk point, plus two fixed tiny receiver-box certificates. No grid area estimate or dimensional lower bound.',
 'theta_exact':str(theta),'lambda':1,'W':9,'r_convention':'cube SIDE length; ri=2 dist_infinity','models':models,'matched_r_3_over2_comparison':pair_events,'matched_neighborhoods':neighborhoods,
 'neighborhood_nesting_proof':'For centers within h in infinity norm, each source-entry side changes by at most2h. Its query cube contains Q(center0,r0-4h) and is contained in Q(center0,r0+4h). Fixed E gives rigorous covered-area bounds. Product uses a fixed dominant x-coordinate witness capturing both stated labels. Diagonal entry order and dominant coordinate are stable; first two events have negative upper margins, all later events have mass<=9 and r>=3.5-2h, giving a negative source-only upper bound.',
 'decision':'Same exact q, same mass2/radius1.5 but different COMPLETE E coverage flips fixed-radius margin; all-scale finite-event checks and tiny neighborhoods also flip full A_theta membership. Source-only gate remains true in the diagonal masked case.',
 'scale_certificate':'For fixed E and q>=1, between source-entry sides mass is constant while (1-theta/q)r^2 and (theta/q)|Q intersect E| increase; strict positivity needs only closed source events. The positive-part supremum additionally retains the r->0 value0.',
 'qualification_limit':'q>=1 is certified. Near-maximizer condition q>=C_n/2 is not certified and no application of the near-maximizer shell theorem or global lower bound follows.',
 'spatial_grid':'Not run: the fixed matched positive-area boxes already resolve the intended geometric decision; no unbounded-error grid area was substituted.',
 'superseded_probe_risk':'The earlier diagonal(775/100,749/100) really is received at an earlier event; its positive event certificate is retained, not used as the final match.',
 'arithmetic':'Canonical exact Fraction squarefree radicals; all nonzero order/area/margin signs Arb512, exact zero by coefficient cancellation; no floating geometry or sign comparisons.',
 'execution':{'interpreter':sys.executable,'python':platform.python_version(),'python_flint':flint.__version__,'precision_bits':ctx.prec,'processes':1,'guard_seconds':120,'guard_bytes':LIMIT,'runtime_seconds':time.perf_counter()-start,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'command':shlex.join([sys.executable,str(Path(__file__).resolve()),*sys.argv[1:]])},'all_assertions_passed':True}
 args.output.write_text(json.dumps(result,ensure_ascii=False,sort_keys=True,indent=2)+'\n')
 print(json.dumps({'models':[(m['name'],m['E_volume']['Arb512'],m['decomposition_certificate']['positive_subset_count'],m['decomposition_certificate']['disjoint_piece_count'],[(p['tag'],p.get('classification')) for p in m['probes']]) for m in models],'matched_coverages':{k:v['covered_area']['Arb512'] for k,v in pair_events.items()},'neighborhood_decisions':{k:v['conclusion'] for k,v in neighborhoods.items()},'execution':result['execution']}))
if __name__=='__main__':main()
