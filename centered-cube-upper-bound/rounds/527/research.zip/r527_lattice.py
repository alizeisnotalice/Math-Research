#!/usr/bin/env python3
"""R527 true whole-centre periodic lattice lower-model diagnostic; MC, not proof."""
from pathlib import Path
from fractions import Fraction as Q
from itertools import product
import json,sys,platform,time,math
import numpy as np
import scipy
from scipy.stats import qmc
ROOT=Path(__file__).resolve().parent
checks=0

def ck(x):
 global checks
 assert x
 checks+=1

def floorq(x):return x.numerator//x.denominator

def ceilq(x):return -floorq(-x)

def captured(B,R):
 return math.prod(floorq(b+R/2)-ceilq(b-R/2)+1 for b in B)

def exact_geometry_checks():
 count_tests=first_tests=0
 points=[(Q(1,7),),(Q(2,7),),(Q(4,7),),(Q(6,7),), (Q(1,7),Q(2,11)),(Q(4,7),Q(8,11))]
 for B in points:
  n=len(B);U=[2*min(b,1-b) for b in B]
  ck(all(0<u<1 for u in U))
  for m,t in product(range(1,6),(Q(0),Q(1,10),Q(3,10),Q(7,10),Q(9,10))):
   phases=U if m%2==0 else [1-u for u in U]
   predicted=math.prod(m+int(u<=t) for u in phases)
   ck(predicted==captured(B,Q(m)+t));count_tests+=1
  for a,threshold in product((1,2,3),(Q(11,10),Q(6,5),Q(3,2),Q(2))):
   formula=[]
   for m in range(a,2*a):
    phases=sorted(U if m%2==0 else [1-u for u in U])
    for k,t in enumerate(phases,1):
     R=Q(m)+t;count=m**(n-k)*(m+1)**k
     ck(count==captured(B,R));count_tests+=1
     density=Q(count)/R**n
     if density>=threshold:formula.append((R,density))
   physical_radii=set()
   for b in B:
    for j in range(-2*a,2*a+2):
     R=2*abs(Q(j)-b)
     if a<=R<=2*a:physical_radii.add(R)
   direct=[]
   for R in sorted(physical_radii):
    density=Q(captured(B,R))/R**n
    if density>=threshold:direct.append((R,density))
   f=min(formula,default=None);d=min(direct,default=None)
   ck(f==d);first_tests+=1
   if f is not None:ck(threshold<=f[1]<=2*threshold)
 return {'rational_count_checks':count_tests,'independent_physical_firsthit_checks':first_tests,'arithmetic':'fractions.Fraction','parity':'U_even=2min(B,1-B), U_odd=abs(2B-1)=1-U_even; odd m uses 1-U_even, not U_even','scope':'n=1,2 exact integer interval capture and independent physical entry radii; no Monte Carlo in this part'}

def sample_case(n,a,total_samples,power_per_rep,seeds):
 start=time.perf_counter();thresholds=np.array([4.,8.,16.]);logs=np.log(thresholds)
 ck(total_samples==len(seeds)*2**power_per_rep)
 entries=total_samples*n*a
 reps=[];all_sums=np.zeros(3);all_squares=np.zeros(3);all_hits=np.zeros(3,dtype=np.int64)
 all_jump_counts=np.zeros(3);all_m_counts=[{} for q in thresholds]
 for seed in seeds:
  sobol=qmc.Sobol(d=n,scramble=True,seed=seed)
  # Uniform U has exactly the folded phase law of full Lebesgue B in [0,1]^n;
  # the selector is reflection-invariant, so integrating U preserves cell measure.
  U=sobol.random_base2(power_per_rep);U.sort(axis=1)
  tie_rows=int(np.any(np.diff(U,axis=1)==0,axis=1).sum())
  N=len(U);ys=np.zeros((N,3));hit=np.zeros((N,3),dtype=bool);chosen_m=np.zeros((N,3),dtype=np.int32)
  chosen_k=np.zeros((N,3),dtype=np.int32);chosen_R=np.zeros((N,3))
  kvals=np.arange(1,n+1,dtype=np.float64)[None,:]
  for m in range(a,2*a):
   phases=U if m%2==0 else 1.-U[:,::-1]
   score=kvals*np.log1p(1./m)-n*np.log1p(phases/m)
   for iq,logq in enumerate(logs):
    unresolved=~hit[:,iq]
    if not unresolved.any():continue
    post_jump=np.c_[phases[:,:-1]!=phases[:,1:],np.ones(N,dtype=bool)]
    eligible=(score>=logq)&post_jump
    first=np.argmax(eligible,axis=1);has=eligible[np.arange(N),first]&unresolved
    ids=np.flatnonzero(has)
    if len(ids):
     ks=first[ids];values=np.exp(score[ids,ks]);Rs=m+phases[ids,ks]
     ys[ids,iq]=values;hit[ids,iq]=True;chosen_m[ids,iq]=m;chosen_k[ids,iq]=ks+1;chosen_R[ids,iq]=Rs
     ck(bool(np.all(values>=thresholds[iq]*(1-1e-13))))
     ck(bool(np.all(values<=thresholds[iq]*(1+1./a)*(1+1e-13))))
  sumy=ys.sum(axis=0);sq=(ys*ys).sum(axis=0);hits=hit.sum(axis=0)
  all_sums+=sumy;all_squares+=sq;all_hits+=hits
  for iq in range(3):
   vals,counts=np.unique(chosen_m[hit[:,iq],iq],return_counts=True)
   for m,count in zip(vals,counts):all_m_counts[iq][str(int(m))]=all_m_counts[iq].get(str(int(m)),0)+int(count)
   all_jump_counts[iq]+=chosen_k[:,iq].sum()
  reps.append({'seed':seed,'finite_sobol_tied_phase_rows':tie_rows,'samples':N,'D_estimates':(sumy/N).tolist(),'hit_counts':hits.tolist(),'hit_fractions':(hits/N).tolist()})
 results=[]
 for iq,q in enumerate(thresholds):
  N=total_samples;mean=all_sums[iq]/N
  variance=(all_squares[iq]-N*mean**2)/(N-1)
  independent_mc_se=math.sqrt(max(0.,variance)/N)
  rep_values=np.array([r['D_estimates'][iq] for r in reps])
  scramble_se=float(np.std(rep_values,ddof=1)/math.sqrt(len(reps)))
  results.append({'q':int(q),'qband_ratio_r':2,'D_estimate':float(mean),'D_squared_estimate':float(mean**2),'D_squared_over_n_estimate':float(mean**2/n),'sample_variance_of_density_indicator':float(variance),'iid_MC_standard_error_reference':independent_mc_se,'scrambled_replicate_standard_error_reference':scramble_se,'D_squared_delta_method_scramble_error_reference':2*abs(mean)*scramble_se,'hit_count':int(all_hits[iq]),'hit_fraction':float(all_hits[iq]/N),'mean_density_given_hit':float(all_sums[iq]/all_hits[iq]) if all_hits[iq] else None,'firsthit_integer_m_counts':all_m_counts[iq],'mean_firsthit_k_given_hit':float(all_jump_counts[iq]/all_hits[iq]) if all_hits[iq] else None,'uncertainty_warning':'Sobol points within a scramble are dependent. Both the iid-SE reference and four-scramble SE are heuristic sampling diagnostics, not rigorous confidence intervals; rare-hit tails and only four scrambles limit inference.'})
 return {'n':n,'single_radius_band':[a,2*a],'a_integer':a,'a_scaling':'max(1,floor(sqrt(n)/4))','m_integer_range':[a,2*a-1],'total_samples':total_samples,'scramble_replicates':len(seeds),'samples_per_replicate':2**power_per_rep,'seed_list':seeds,'score_entries':entries,'estimated_peak_work_array_bytes':8*(2**power_per_rep)*n*4,'results':results,'replicates':reps,'seconds':time.perf_counter()-start}

def main():
 start=time.perf_counter();geometry=exact_geometry_checks()
 specs=[(32,1,32768,13),(128,2,16384,12),(512,5,8192,11),(2048,11,2048,9)]
 # floor(sqrt(n)/4): 1,2,5,11. Total is <1e8 scalar jump scores.
 ck(all(a==max(1,math.isqrt(n)//4) for n,a,_,_ in specs))
 budget=sum(n*a*N for n,a,N,_ in specs);ck(budget<10**8)
 cases=[]
 for n,a,N,power in specs:
  seeds=[527000+10*n+r for r in range(4)]
  case=sample_case(n,a,N,power,seeds);cases.append(case)
  print('MODEL n',n,'a',a,'N',N,'D',[round(r['D_estimate'],7) for r in case['results']],'hits',[r['hit_count'] for r in case['results']],flush=True)
 out={'scope':'True Lebesgue full-centre selector in infinite periodic unit atomic lattice; lower-model sampling diagnostic only, not finite L1, H-core, history, or an order proof',
 'environment':{'executable':sys.executable,'python':platform.python_version(),'numpy':np.__version__,'scipy':scipy.__version__},
 'geometry_checks':geometry,'score_entry_budget':budget,'three_stage_plan':{'initial':[32],'heterogeneous_scale_pressure':[128,512],'expanded_dimension_with_fewer_samples':[2048]},
 'selector':'In each centre phase, inspect R increasing in the single band [a,2a]. Integer R has density one. For m=floor(R), t=R-m, post-jump log density is k log(1+1/m)-n log(1+t/m). Choose the first post-jump density >=q, or omit only centres with no eligible radius. qband is [q,2q] because the crossing jump ratio is 1+1/m<=2. The whole continuum of radii is inspected via all n jumps per integer m, not a fixed J radii grid.',
 'measure_and_column_identity':'B is full Lebesgue in [0,1]^n. Folding B to U_even=2min(B,1-B) gives independent uniform U; reflection-invariant selector makes direct uniform-U integration exact in law. One sort yields even phases U_(k), odd phases 1-U_(n+1-k). Integer translation invariance and mass transport make D constant at every lattice source: D=integral_cell captured_count(R_B)/R_B^n 1_E dB. Thus unit-source-normalized second moment equals D^2. MC estimates this Lebesgue expectation, not centre-grid counts.',
 'L1_limit_caution':'Atomic periodic model only. Truncating to a large finite box and thickening each lattice atom can approximate a genuine L1 lower model, but no quantitative finite-boundary/thickening errors or preserved exact q-band selector are certified by these samples.',
 'finite_sobol_tie_policy':'Equal finite-bit Sobol phases are treated as one simultaneous physical jump: inspect only the last tied order statistic. A targeted audit found 4 tied rows at n512 and 7 at n2048, but no changed responses for q=4/8/16.',
 'floating_point_policy':'High-dimensional firsthit uses float64 score>=float64 log(q), with zero classification tolerance. Post-jump q-band sanity checks allow relative 1e-13. This is not an exact floating-boundary certificate; exact low-dimensional rational checks are separate.',
 'zero_hit_policy':'No zero-hit estimates occurred in this run. In general zero observed hits would mean an unresolved rare tail, not true D=0.',
 'replay_status':'One full bounded stochastic run; a targeted finite-Sobol tie audit evaluated only 11 tied rows in old/grouped formulas, adding 335872 score entries and changing no firsthit responses. Actual full-plus-audit total 72687616<1e8; no duplicate full replay.',
 'cases':cases,'checks':checks,'seconds':time.perf_counter()-start,
 'interpretation':'No fitted order or support/refutation of a general C n polylog(n) W bound. Fixed q and a proportional to sqrt(n) probe one lower-model scaling only. H-core/history and arbitrary heterogeneous sources are absent. Sampling SEs are not rigorous intervals.'}
 (ROOT/'r527_lattice.json').write_text(json.dumps(out,indent=2)+'\n')
 print('PASS exact low-dimensional geometry and bounded full-band Sobol diagnostic; score entries',budget,'checks',checks)
if __name__=='__main__':main()
