from fractions import Fraction as F
import json,sys,platform
from pathlib import Path
# Algebra certificate only: no assertion that these masks realize a cube selector.
mu=[F(1),F(2),F(3),F(4),F(5),F(6)]
sets=[{0,1},{1,2},{0,3},{2,4}]
VB=[F(3),F(5),F(5),F(8)]; VC=F(21); m=sum(mu)
I=[sum(mu[x] for x in B) for B in sets];J=[m-i for i in I]
assert all(VC>2*v and i==v for v,i in zip(VB,I))
h=[sum(F(int(x in B))/(v*j) for B,v,j in zip(sets,VB,J)) for x in range(len(mu))]
out=[sum(F(int(x in B))/(v*VC) for B,v in zip(sets,VB)) for x in range(len(mu))]
inc=[sum(F(int(x not in B))*i/(v*VC*j) for B,v,i,j in zip(sets,VB,I,J)) for x in range(len(mu))]
mean=sum(w*v for w,v in zip(mu,h))/m
assert all(o-k==m/VC*(v-mean) for o,k,v in zip(out,inc,h))
assert sum(w*(o-k) for w,o,k in zip(mu,out,inc))==0
loss=sum(w*v*(o-k) for w,v,o,k in zip(mu,h,out,inc))
var=m/VC*sum(w*(v-mean)**2 for w,v in zip(mu,h))
assert loss==var>=0
value={'scope':'fixed-parent full-small-parent algebra only, not cube geometry, q-band, history, or global budget','python':platform.python_version(),'executable':sys.executable,'mu':list(map(str,mu)),'small_parent_masks':[sorted(B) for B in sets],'small_volumes':list(map(str,VB)),'large_volume':str(VC),'large_mass':str(m),'intersection_masses':list(map(str,I)),'difference_masses':list(map(str,J)),'h':list(map(str,h)),'outflow_source_density':list(map(str,out)),'arrival_source_density':list(map(str,inc)),'potential_loss':str(loss),'variance_identity':str(var),'checks':'exact flow divergence, mass conservation, full variance identity'}
# Prescribed actual 2D cube configuration: exact bounds, no search.
eta=F(1,10000);delta=F(1,100);small_center=F(-2,5);right_center=F(6,5)
small_area=(2*eta)**2;large_area=(2*delta)**2
assert small_center-eta-F(1,2)>-1+delta
assert small_center+eta+F(1,2)<1-delta
assert eta+F(1,2)<1-delta
assert small_center+eta+F(1,2)<right_center-delta-1
assert right_center+delta+1<4
O0=(2-2*delta)**2;O1=(2-right_center-2*delta)*(2-2*delta)
assert O1>0
cov_bound=3*small_area**2/16+small_area*large_area*(F(1,16)-(O0+O1)/64)
global_bound=large_area*cov_bound
assert global_bound==F(-3659,25000000000000000000)<0
value['actual_cube_global_D_potential_sign']={'scope':'one prescribed true L1, actual positive-Lebesgue-center geometry; sign of proposed D potential only, not a counterexample to any target bound','n':2,'source':'indicator of [-4,4]^2','q_band':'q=1, r=1','side_lengths':['1','2'],'eta':str(eta),'delta':str(delta),'small_center_x':str(small_center),'right_center_x':str(right_center),'small_center_area':str(small_area),'large_center_area':str(large_area),'central_pair_intersection_lower_bound':str(O0),'central_right_intersection_lower_bound':str(O1),'central_covariance_upper_bound':str(cov_bound),'integrated_covariance_upper_bound':str(global_bound),'true_J_weight_factor':'4/3; all nonzero small/large far pairs have I=1,J=3'}
Path(__file__).with_suffix('.json').write_text(json.dumps(value,indent=2)+'\n')
print('PASS exact fixed-parent full-flow divergence and variance; no general bound')
