# R217 主代理：捕获权与核差的中间层几何

本稿使用 peak_good_geometry.md 经独审的时间带预算，保留R211实际baseline捕获余权，不重选alpha或来源。这里给出的精确二次约束是下一轮攻击剩余中间层的必要几何；其存在条件本身不是付款。

## CG1 原余权及真实对比
固定完整实际行，令 Delta=w_tau(v)-w_h(v)。只在T Delta>0及原eligible集合上写商。原 baseline
\[
 rho_0(v)=\left(1-\frac{D K_0(v)+alpha_0 J(v)}{T Delta(v)}\right)_+,
 \quad alpha_0=Dq/Q_J\ge0.
\]
其余零/非eligible行按原合同处理。已付实际rho到rho0的差项不重付。D为原recapture参数，不是曲率变量。

令 B=(K1+K2)/J，z=K0/J，zeta=p/(kappa T L0)，H=B-zeta z。
PG主定理直接支付 mixed 内 d_t=(3L0/K)w_g/w_t>=1 且 rho0 H_+<=1 的原正子支，价格16 Lambda L0/(3K) W_A；L0=K sqrt(n)时为根阶。此结论对所有原尺度成立，不需下述比较条件。

只为刻画剩余，取实际 Hhat>=Lplus，则已有点态比较
\[
 B\le C_H z,\quad C_H=(Hhat/L)^n+(Hhat/Lplus)^n.
\]
不能把C_H当无维数常数。置
\[
 A=1-alpha_0 J/(T Delta),\quad a=D J/(T Delta)>0,
 \quad C=C_H-zeta.
\]
那么 rho0=(A-a z)_+，并有
\[
 rho0 H_+\le (A-a z)_+(Cz)_+.
\tag{CG1}
\]
如果A<=0或C<=0，右侧为零，该行在d>=1部分由PG支付。若A,C>0，精确完成平方：在0<z<A/a上
\[
 C z(A-a z)=\frac{CA^2}{4a}-Ca\left(z-\frac{A}{2a}\right)^2.
\tag{CG2}
\]
区间外正部乘积为零，故全域上界CA^2/(4a)。因而 CA^2<=4a 也是同一已付PG支的充分条件，不另领取一份预算。

## CG2 未付行的必要双侧夹逼
若实际 rho0 H_+>1，则必A>0,C>0, CA^2>4a，且
\[
 \frac{A-\sqrt{A^2-4a/C}}{2a}<z<
 \frac{A+\sqrt{A^2-4a/C}}{2a}.
\tag{CG3}
\]
等价地，偏离A/(2a)超过相应半宽的来源不属于该未付支。严格端点不能写成免费的闭覆盖；等号属于已付rho0H<=1。

证明只是CG1与二次函数精确解集；这里没有把K1,K2替换成可自由选择的核。zeta含同一当前p，alpha0含同一QJ，Delta与w_g来自同一来源历史，因此不能分别取它们的最坏值后声称已保联合几何。CG3可用于组织后续共同来源容量估计，但目前没有证明这段区间的原交通总量满足根阶。

## CG3 完整覆盖与下轮瓶颈
在先前已剥离低域之后，当前mixed正余项按顺序严格分成：
1. d_t<1；
2. d_t>=1且rho0 H_+<=1：本轮实际根阶支付；
3. d_t>=1且rho0 H_+>1：保留。
第二支也含H<=0，但mixed与good使此交集为空（零权行另零）。第三支在Hhat>=Lplus时满足CG3，在Hhat<Lplus时仍保实际原核差，不擅自使用C_H比较。负信用保留原位一次。本轮没有重用R215已耗w的吸收预算；使用的是同一原正积分的一条独立上界。

后续主问题是第三支的真实共同来源/接收容量与第一支的大终端时钟比，而非再证明uniform方差。CG3把capture与mixed核差联合保留，支持针对中间层的估计。未取得该预算前，一般n^(1/2+o(1))结论仍未证明。

## CG4 有理代数检查
capture_polynomial_check.py用Fraction核对三阶段参数中的完成平方和根阶付款充分判据。此为有限精确代数证据，不认证FULL几何，也不替代上述逐点解析证明；实际结果见同名JSON。
