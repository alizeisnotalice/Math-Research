# R217：小逆指数下的真实倾斜比较与核外矩

状态：以下是可用于下一步的有限弱估计，不给一般 root 付款。主要结果是 **SC3 的连续逆腿比较、SC5 的带严格 gap 核外矩、SC6 的逐坐标低频转移和 SC7 的真实 core 振荡判据**。它们均对任意来源平移一致，但不声称 $Y=\log j-\log p-\log k$ 有统一正方差。小 $\Theta\log(1/s)$ 只控制逆 $K$ 腿替换的费用，不能删除 $Y$ 自身的 $\log(1/s)$ 或其退化方向。

## SC1　准确对象与结论范围

设 $0<s\le1$，$\lambda,\eta_v,\eta_u\in[1/2,1]$，$d_v,d_u\in\mathbb R$ 任意，
\[
h(t)=\int_0^1e^{-t/a}\,da\quad(t\ge0),\qquad
\phi(x)=\int_{-1/2}^{1/2}h(|x-y|)\,dy,
\]
\[
f_s=(1-s)\mathbf1_{[-1/2,1/2]}+s\phi,\quad
p_\lambda(x)=\lambda^{-1}f_s(x/\lambda),
\]
\[
j_z(x)=\phi(x-d_z),\quad
q_z(x)=\eta_z^{-1}\phi((x-d_z)/\eta_z),\quad
k_z(x)=\eta_z^{-1}f_s((x-d_z)/\eta_z).
\]
这些都是归一密度：Tonelli 给 $\int h(|x|)dx=\int_0^1 2a\,da=1$，卷积及缩放保留积分。点边界不影响以下密度或积分。

固定 $r=\tau=1/4$，$\theta,\chi\ge0$，$\Theta=\theta+\chi<1/2$，定义
\[
g=p_\lambda^{3/2}j_v^{-1/4}j_u^{-1/4}k_v^{-\theta}k_u^{-\chi},
\quad Z=\int_{\mathbb R}g,
\quad P(dx)=g(x)dx/Z.
\tag{SC1}
\]
零指数因子按 $1$ 处理。为展示 tailgap，记
\[
\beta=\tfrac12+\Theta<1,\qquad
a_*=\tfrac12+\theta/\eta_v+\chi/\eta_u<\tfrac32,
\]
\[
\delta=\frac{3}{2\lambda}-a_*
\ge 1-2\Theta>0,
\qquad I=[-\lambda/2,\lambda/2].
\tag{SC2}
\]
下文不把 $\delta^{-1}$ 当统一常数；$\Theta\uparrow1/2$ 时仍须保留它。两腿同尺度是 $\eta_v=\eta_u$ 的特例。

## SC2　显式核常数与平移比

全篇使用以下明确的保守常数：
\[
A=\frac{e^{-3/2}}3,\quad B=3e^{1/2},\quad
R=B/A=9e^2,\quad m=\frac{e^{-2}}2,\quad C=m^{-1}=2e^2.
\tag{SC3}
\]
对所有 $x$，
\[
A\frac{e^{-|x|}}{1+|x|}\le\phi(x)
\le B\frac{e^{-|x|}}{1+|x|},
\qquad 0<\phi\le1,
\tag{SC4}
\]
且 $|x|\le1/2$ 时 $\phi(x)\ge m$。

证明：置 $u=1/a-1$，有
\[
h(t)=e^{-t}\int_0^\infty\frac{e^{-tu}}{(1+u)^2}du
\le e^{-t}\min(1,t^{-1})\le\frac{2e^{-t}}{1+t},
\]
$t=0$ 按第一项解释。另一方面，只积 $a\in[1-1/(2(1+t)),1]$，此处 $t/a\le t+1$，故
\[
h(t)\ge\frac{e^{-t}}{2e(1+t)}.
\]
卷积中 $||x-y|-|x||\le1/2$，两方向的 $1+|x-y|$ 比至多 $3/2$，即给 SC4 的 $A,B$。$h\le1$ 给 $\phi\le1$；core 内 $|x-y|\le1$，只积 $a\in[1/2,1]$ 给 $h(|x-y|)\ge e^{-2}/2$，从而给 $m$。全部为初等点态证明。

由 SC4、三角不等式及 $(1+|t|)/(1+|t-z|)\in[(1+|z|)^{-1},1+|z|]$，得任意 $t,z$ 的平移一致比
\[
R^{-1}\frac{e^{-|z|}}{1+|z|}
\le\frac{\phi(t-z)}{\phi(t)}
\le R e^{|z|}(1+|z|).
\tag{SC5}
\]
这里的 $R$ 不随 $t$ 即来源位移增长。

还由 core 下界及 core 外定义，处处有
\[
s\phi\le f_s\le C\phi,
\quad\text{而在 }[-1/2,1/2]\text{ 内 }m\le f_s\le1.
\tag{SC6}
\]
$C$ 与 $s$ 无关；但左端的 $s$ 不得删除。

## SC3　连续逆腿参考与归一化密度双向比较

定义保留真实 $p_\lambda$ 的连续逆腿参考
\[
G=p_\lambda^{3/2}j_v^{-1/4}j_u^{-1/4}q_v^{-\theta}q_u^{-\chi},
\quad Z_0=\int G,\quad Q(dx)=G(x)dx/Z_0.
\tag{SC7}
\]
则 $0<Z,Z_0<\infty$，且
\[
C^{-\Theta}G\le g\le s^{-\Theta}G,
\quad C^{-\Theta}Z_0\le Z\le s^{-\Theta}Z_0,
\tag{SC8}
\]
\[
\boxed{U^{-1}\le\frac{dP}{dQ}\le U,
\qquad U=(C/s)^\Theta.}
\tag{SC9}
\]
因此若 $\Theta\log(1/s)\le C_0$，则 $U\le C^\Theta e^{C_0}\le C^{1/2}e^{C_0}$。这是对任意平移、尺度一致的归一化比较；既不支付 $s^{-1/4}$ 之类多余费用，也没有省略真实 $s^{-\Theta}$。

证明：SC6 缩放后给 $sq_z\le k_z\le Cq_z$；负幂直接给 SC8，归一化给 SC9。有限性由下一节的严格 $\delta$ 尾估计给出，正性由 core 下界给出。对任意非负可测 $F$（允许无穷），SC9 还给 $U^{-1}E_QF\le E_PF\le UE_QF$。

此参考只替换逆 $K$ 腿，仍包含真实 receiver 的 soft 跳变、来源平移和同坐标两腿，不能当作原来源后验或原 $\Pi$。

## SC4　来源平移从显式常数中消去

记
\[
H=j_v^{-1/4}j_u^{-1/4}q_v^{-\theta}q_u^{-\chi},\qquad H_0=H(0)>0.
\]
各因子使用 SC5，$\eta_z^{-1}$ 的归一化常数在比值中消去，得到
\[
R^{-\beta}e^{-a_*|x|}(1+2|x|)^{-\beta}
\le H(x)/H_0
\le R^\beta e^{a_*|x|}(1+2|x|)^\beta.
\tag{SC10}
\]
于是
\[
Z_0\ge H_0 D_0,\qquad
D_0=m^{3/2}\lambda^{-1/2}R^{-\beta}
 e^{-a_*\lambda/2}(1+\lambda)^{-\beta}.
\tag{SC11}
\]
确实，在长度为 $\lambda$ 的 $I$ 上，$p_\lambda\ge m/\lambda$，且 SC10 的下界至少其 $|x|=\lambda/2$ 处值。

$H_0$ 可以随来源增长；它准确出现在分子、分母，以下归一化结果中完全消去。不能将 SC11 单独外提为原来源已付上界。

## SC5　真实 tilt 的核外质量与矩：保留 $s^{3/2-\Theta}$ 和 gap

置 $\gamma=3/2-\Theta>1$，并定义完全显式的
\[
K=\frac{C^\Theta B^{3/2}R^{2\beta}2^\beta
 e^{a_*\lambda/2}(1+\lambda)^\beta}{m^{3/2}\lambda}.
\tag{SC12}
\]
则真实归一化密度 $\rho=dP/dx$ 满足
\[
\boxed{\rho(x)\le K s^\gamma e^{-\delta|x|}
\quad (x\notin I).}
\tag{SC13}
\]
更精细的同一证明在右端保留乘子
$2^{-\beta}(1+2|x|)^\beta/(1+|x|/\lambda)^{3/2}\le1$；SC13 是便于使用的弱形式。

证明：$x\notin I$ 时 $p_\lambda=(s/\lambda)\phi(x/\lambda)$。用 SC4、SC8、SC10，
\[
g(x)\le H_0s^\gamma\lambda^{-3/2}B^{3/2}R^\beta
 e^{-\delta|x|}\frac{(1+2|x|)^\beta}{(1+|x|/\lambda)^{3/2}}.
\]
因 $\lambda\le1$、$\beta<1<3/2$，该分式至多 $2^\beta$。再除以 $Z\ge C^{-\Theta}H_0D_0$ 即得 SC12–13。相同论证去掉 $s^{-\Theta}$ 可证 $Z_0$ 有限；core 内所有核严格正且有界，故没有其余奇点。

对任意整数 $q\ge0$，令
\[
M_q^{\rm out}=E_P[|X|^q\mathbf1_{X\notin I}].
\]
两侧积分与分部积分给
\[
\boxed{M_q^{\rm out}\le 2Ks^\gamma e^{-\delta\lambda/2}
\sum_{j=0}^q\frac{q!}{(q-j)!}
 \frac{(\lambda/2)^{q-j}}{\delta^{j+1}}
\le\frac{2Ks^\gamma q!}{\delta^{q+1}}.}
\tag{SC14}
\]
最后一个弱界直接把积分下端降至 $0$。尤其
\[
P(I^c)\le T:=\frac{2Ks^\gamma}{\delta}e^{-\delta\lambda/2},\quad
E_P|X|^q\le(\lambda/2)^q+\frac{2Ks^\gamma q!}{\delta^{q+1}}\ (q\ge1).
\tag{SC15}
\]
$P(I)\ge(1-T)_+$；当保守 $T>1$ 时不强求此下界有效。若 $s\downarrow0$ 且 $\Theta\log(1/s)\le C_0$，则 $\Theta\to0$、$\delta\ge1-2\Theta$ 最终离零，$K$ 对所有允许尺度一致有界，且 $s^\gamma\le e^{C_0}s^{3/2}$。因此真实 tilt 核外的固定阶矩为 $O_{C_0}(s^{3/2})$。这是一条可用的集中结论，仍不是 $Y$ 的反集中。

## SC6　可直接用于 R216 CB6 的逐坐标转移

对同一可测实函数 $F$，有限二阶矩时利用 $\operatorname{Var}F=\inf_cE(F-c)^2$，SC9 给
\[
U^{-1}\operatorname{Var}_QF\le\operatorname{Var}_PF
\le U\operatorname{Var}_QF.
\tag{SC16}
\]
令 $F'$ 是同一法的独立复制，并令
$B_P(F)=E_{P\otimes P}(F(X)-F(X'))^4$，则
\[
B_P(F)\le U^2B_Q(F).
\tag{SC17}
\]
这两条对真实 $F=Y_z=\log j_z-\log p_\lambda-\log k_z$ 同样成立；参考比较并不把 $Y_z$ 中的 $k_z$ 换掉。

在实际 product receiver tilt 的各坐标，对每个坐标构造 $Q_i,U_i$。若某子集 $\mathcal J$ 中已在 **同一实际函数** $Y_i$ 下核验
$\sigma_{Q,i}^2=\operatorname{Var}_{Q_i}Y_i>0$ 及 $B_{Q,i}<\infty$，取共同窗满足
\[
\omega_0^2 U_i^3 B_{Q,i}\le12\sigma_{Q,i}^2
\quad(i\in\mathcal J).
\tag{SC18}
\]
则 SC16–17 保证 $\omega_0^2B_{P,i}\le12\sigma_{P,i}^2$。初等余弦四阶界给
\[
|\varphi_{P,i}(t)|^2\le1-t^2\sigma_{P,i}^2+t^4B_{P,i}/24
\le1-t^2\sigma_{P,i}^2/2,
\]
故
\[
\boxed{|\Phi(t,0)|\le\exp\left(-\frac{t^2}{4}
\sum_{i\in\mathcal J}U_i^{-1}\sigma_{Q,i}^2\right),
\quad |t|\le\omega_0.}
\tag{SC19}
\]
于是 R216 CB5 可以用
$V=\frac12\sum_{i\in\mathcal J}U_i^{-1}\sigma_{Q,i}^2$ 和 SC18 的真实 $\omega_0$。证明中只乘各坐标真实特征函数；没有先付 $\prod_iU_i$，因此不产生无必要的 $U^n$。退化坐标仍仅使用模不超过 $1$，不贡献虚构方差。若参考方差为零或没有共同窗，这一接口不给 root。

## SC7　core 上的空间振荡给真实方差，允许真实退化

将 $P$ 条件化到 $I$，记 $P_I$，记 $\mathsf U_I$ 为 $I$ 上均匀概率。定义
\[
U_I=(C/s)^\Theta m^{-3/2}R^{2\beta}
 e^{a_*\lambda}(1+\lambda)^{2\beta}.
\tag{SC20}
\]
则
\[
U_I^{-1}\le dP_I/d\mathsf U_I\le U_I.
\tag{SC21}
\]
证明：$I$ 内 $p_\lambda^{3/2}$ 在 $m^{3/2}\lambda^{-3/2}$ 与 $\lambda^{-3/2}$ 之间，SC8、SC10 给 $g$ 在该区间的上、下界，其比恰为 SC20；除以区间平均仍在同一比值之间。

全方差分解和 SC21 因而给可核验的下界
\[
\boxed{\operatorname{Var}_PF\ge(1-T)_+U_I^{-1}
\operatorname{Var}_{\mathsf U_I}F.}
\tag{SC22}
\]
特别地，若找到 $A_1,A_2\subset I$，各长至少 $\alpha\lambda$，且 $|F(x)-F(y)|\ge d$ 对几乎所有 $(x,y)\in A_1\times A_2$ 成立，则独立复制的方差恒等式给
\[
\operatorname{Var}_{\mathsf U_I}F\ge\alpha^2d^2,
\quad \operatorname{Var}_PF\ge(1-T)_+U_I^{-1}\alpha^2d^2.
\tag{SC23}
\]
此判据要求实际空间振荡，可以与实际 good/capture 几何合用；没有单凭来源距离宣布非退化。它是一个明确的后续证明任务，而非新增未经核验的假设。

反之，若 $\eta_v=1$ 且 $|d_v|>(1+\lambda)/2$，则来源 $K_v$ 的 core 与 $I$ 分离；$I$ 上准确有 $k_v=sj_v$，因而
\[
Y_v(x)=-\log p_\lambda(x)-\log s\quad(x\in I).
\tag{SC24}
\]
当 $s<1$，此函数在 $I$ 上的振幅至多 $\log(1/(1-s))$。因此 SC23 的 $d$ 在这类真实配置中不能取固定正数；小逆指数的密度比较不改变这一事实。下一节还给其全空间方差趋零的有控结论。

## SC8　shift-uniform 对数矩上界及一条完整退化估计

对任一腿 $z$，记 $Y_{z,0}=Y_z(0)$。SC5–6 给
\[
|Y_z(x)-Y_{z,0}|\le b_s+11|x|,
\qquad b_s=3\log R+2\log(C/s).
\tag{SC25}
\]
证明：$\log j_z$ 的差至多 $\log R+|x|+\log(1+|x|)$；$\log p_\lambda$ 与 $\log k_z$ 的差各至多
$\log(C/s)+\log R+|x|/a+\log(1+|x|/a)$，其中 $a=\lambda$ 或 $\eta_z$。用 $a\ge1/2$、$\log(1+t)\le t$ 后，全部线性系数至多 $2(1+1/\lambda+1/\eta_z)\le10$，故所写的 $11|x|$ 保守成立。

于是全部所需矩有限，且
\[
E_P|Y_z-Y_{z,0}|^4\le8\left[b_s^4+11^4
\left((\lambda/2)^4+48Ks^\gamma/\delta^5\right)\right],
\]
\[
\boxed{B_P(Y_z)\le128\left[b_s^4+11^4
\left((\lambda/2)^4+48Ks^\gamma/\delta^5\right)\right].}
\tag{SC26}
\]
这里先用 $(a+b)^4\le8(a^4+b^4)$，再对复制差用同一不等式。该界保留 $\log(1/s)^4$；条件 $\Theta\log(1/s)\le C_0$ 不使这一项自动有界。若几何能另给精确更小差矩，应以实际差矩替换此保守界，而非把它当免费共同频率窗。

对 SC24 的严格分离配置，$0\in I$ 且没有来源边界歧义。以 $Y_{v,0}$ 为中心，core 用准确振幅，核外用 SC25，得到
\[
\boxed{\operatorname{Var}_PY_v\le
\log^2\frac1{1-s}+2b_s^2 T+242 M_2^{\rm out}.}
\tag{SC27}
\]
$T,M_2^{\rm out}$ 均由 SC14–15 显式支付。若 $s\downarrow0$ 且 $\Theta\log(1/s)\le C_0$，SC27 为
$O_{C_0}(s^2+s^{3/2}(1+\log^2(1/s)))\to0$，对另一腿任意平移及所有允许尺度一致。此处不是只列反例：它准确指出 SC22 的可用振荡在哪里消失，并量化剩余尾部的费用。

## SC9　计算核对与下一步接口

本稿证明不依赖数值。实际调用已连接 MATLAB，对 $x=0,0.25,\ldots,12$ 共 49 点用单层 $a$ 积分核对 $\phi(x)(1+x)e^x$；网格最小约 $0.5568$、最大约 $0.9829$，处于解析区间 $[A,B]\approx[0.0744,4.9462]$。MATLAB 同时核算 $R\approx66.5015,m\approx0.0677,C\approx14.7781$。积分采用 AbsTol $10^{-13}$、RelTol $10^{-11}$；这是浮点 sanity check，不是区间证书或点态证明。未运行新增模拟、CF 或拟合 $n$ 阶数。

下面为该次实际调用的完整短代码（仅计算，不写文件）：

```matlab
r217_A=exp(-1.5)/3;
r217_B=3*exp(.5);
r217_R=r217_B/r217_A;
r217_m=exp(-2)/2;
r217_C=1/r217_m;
disp(struct('A',r217_A,'B',r217_B,'R',r217_R, ...
    'm',r217_m,'C',r217_C));
r217_x=linspace(0,12,49);
r217_phi=zeros(size(r217_x));
for r217_i=1:numel(r217_x)
    r217_z=r217_x(r217_i);
    if r217_z<=.5
        r217_fun=@(a) a.*(2-exp(-(.5+r217_z)./a) ...
            -exp(-(.5-r217_z)./a));
    else
        r217_fun=@(a) a.*(exp(-(r217_z-.5)./a) ...
            -exp(-(r217_z+.5)./a));
    end
    r217_phi(r217_i)=integral(r217_fun,0,1, ...
        'AbsTol',1e-13,'RelTol',1e-11);
end
r217_ratio=r217_phi.*(1+r217_x).*exp(r217_x);
disp(struct('grid_ratio_min',min(r217_ratio), ...
    'grid_ratio_max',max(r217_ratio),'analytic_lower',r217_A, ...
    'analytic_upper',r217_B,'phi_zero',r217_phi(1)));
```

工具实际返回（沿用 MATLAB 当时显示精度，未补造更多位数）：

```text
A: 0.0744
B: 4.9462
R: 66.5015
m: 0.0677
C: 14.7781
grid_ratio_min: 0.5568
grid_ratio_max: 0.9829
analytic_lower: 0.0744
analytic_upper: 4.9462
phi_zero: 0.5568
```

实际下一步可以二选一并保留原域：一是利用 SC9/SC18–19，在连续逆腿参考下核验实际 $Y_i$ 的方差和差四矩；二是直接在真实 receiver core 上，用 SC22–23 将实际 good/capture 保证的空间振荡变成方差，并以 SC14 支付互补尾。两者都允许 SC24–27 的近常量方向，因而必须由峰位置及原门的几何判断哪些坐标可付款。SC13 不删原 mixed/good/capture/来源/selector/window 费用；$U,K,U_I,\delta$ 和原标量总质量仍须一起回代。本稿提供严格的新弱接口，不声称一般来源 root 已闭合。
