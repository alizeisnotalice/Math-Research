#!/usr/bin/env python3
"""Exact rational checks of CG2, not a full geometric input certificate."""
from fractions import Fraction as F
from pathlib import Path
import argparse, hashlib, json

def run():
    stages=[]
    for name, denoms in [('initial',[2,3]),('stress',[5,7,11]),('expanded',[17,31,64])]:
        total=0; paid=0; middle=0
        for d in denoms:
            for A in [F(1,d),F(d-1,d),F(1)]:
                for a in [F(1,d),F(1),F(d)]:
                    for C in [F(1,d),F(1),F(4*d),F(8*d)]:
                        for j in range(0,2*d+1):
                            z=A*j/(a*d)
                            val=max(F(0),A-a*z)*C*z
                            top=C*A*A/(4*a)
                            if z<=A/a:
                                assert val==top-C*a*(z-A/(2*a))**2
                            else:
                                assert val==0
                            assert val<=top
                            if top<=1:
                                assert val<=1
                                paid+=1
                            if val>1:
                                assert top>1
                                assert (2*a*z-A)**2<A*A-4*a/C
                                middle+=1
                            total+=1
        stages.append(dict(stage=name,denominators=denoms,exact_checks=total,paid_tests=paid,middle_tests=middle))
    return {'scope':'finite exact rational CG2 checks, not FULL source geometry','script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'stages':stages,'all_passed':True}
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=Path(__file__).with_suffix('.json'));a=p.parse_args()
    a.output.write_text(json.dumps(run(),ensure_ascii=False,indent=2)+'\n')
