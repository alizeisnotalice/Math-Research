# R217 本机小软度数值方案（运行前冻结）

仅研究单坐标真实物理 tilt。lambda=eta=1，r=tau=1/4，theta=chi=1/[8 max(1,log(1/s))]；s=0.25,0.05,0.01。分离配置 d_v=d_u=1.25，重叠对照 d_v=0.25,d_u=-0.25。L0=kappa=T=b=w_v=w_u=1 仅用于代数诊断，不声称满足原交通门。

三阶段预定：初探用 s=.25 的两种位移、18dps/24阶 Gauss-Legendre、Z=24；压力阶段全部六配置、24dps/48阶、Z=64；扩大精度全部六配置、36dps/96阶、Z=160。每个有限区间在 hard 端点、位移中心、零点及外尾几何分片上作确定性积分；所有原始矩、mixed分子及direct inverse-sum同时求积。比较压力与扩大精度结果，不能将比较当有向舍入证书。

计算 M、单坐标 Y_v 和 Y_u 的均值方差四阶中心矩、D_v/D_u均值及 D=0 的曲率峰位置、实际 tilt 质量落在原receiver核心且位移核外的比例，以及 Rmix、M Rmix、C_v C_u M Rmix 和直接 Zmix。曲率峰另记录在分段连续域内的数值根与 hard 跳跃越峰，不能将空间峰存在与原 good/capture 等同。绝不拟合一般维数阶。

尾部方案：本次 theta<=1/8 且所有 p,j,k<=1，因此新 g=p^(3/2)(j_v j_u)^(-1/4)(k_v k_u)^(-theta) 被 R216 theta=chi=1/8 的 g 支配。复用其 epsilon=.25,c_epsilon=.2 的指数-多项式包络计算有限窗之外原始 |Y|^j (j=0..4) 上界；R<=1，所以 mixed分子和 direct Zmix 的尾也由该质量上界控制。此为解析包络的浮点数求值，求积自身仍非严格区间验证。完成后追加真实结果。

## 实际运行结果

已用指定 bundled Python 与 vendor mpmath 运行，三阶段共14次配置求积；完整结果、分片、精度和脚本SHA256见JSON。最终运行耗时 12.067 秒。

|s|位移(v,u)|M|Rmix|M Rmix|Zmix|Var(Yv)|核心条件Var(Yv)|E Dv|
|---|---|---|---|---|---|---|---|---|
|.25|(1.25,1.25)|4.99709758|0.969263228|4.84350293|3.26808392|0.544746072|0.000190481349|0.644737712|
|.25|(.25,-.25)|1.51855603|0.871476549|1.32338597|0.892935643|2.46428248|nan|-0.513815208|
|.05|(1.25,1.25)|4.51729999|0.959486792|4.33428968|3.41129601|0.0776896934|6.14115039e-06|1.24534313|
|.05|(.25,-.25)|1.58570651|0.788720131|1.25067864|0.984344698|2.96095462|nan|-1.33044552|
|.01|(1.25,1.25)|4.34599822|0.924812543|4.01923366|3.36498715|0.011069294|2.35772848e-07|2.39144891|
|.01|(.25,-.25)|1.60928007|0.747469704|1.2028881|1.00708327|5.64612438|nan|-1.37879864|

表中nan表示核心条件事件质量为零，条件方差未定义。这里 Zmix=C_v C_u M Rmix。分离配置的 Rmix 只有有限收缩，完整 M Rmix 仍约4–5，Zmix仍约3.3；不能因R下降就宣称原费用被支付。重叠对照的Zmix分别约.893,.984,1.007，也不能从单坐标诊断推断一般n。

压力阶段与扩大精度阶段对M、R、M R、Zmix、方差、四阶中心矩的相对差最大为 4.71e-12。最终同节点代数身份误差最大 1.13e-35。这是求积复核与逐点代数检验；后者不是独立误差证书。

最终Z160的原始绝对矩尾包络：raw0最大 3.36e-37，raw4最大 5.16e-26。所有尾包络由已述旧g支配；没有使用无穷区间求积或悄悄忽略尾。mpmath/GL非有向舍入，故不能把尾小于求积差改称严格数值证书。

## 位置与实际下一步

分离配置在receiver核心|x|<.5严格有K_v=K_u=sJ_v=sJ_u，所以Y_v=Y_u=-log p-log s。这是解析恒等式；数值核心条件方差随s下降，正符合局部空间变化消去，而不是统一非退化。下表记录该核心D值；中心与内侧端点均为正，因此曲率峰D=0并不在这段高质量核心上。

|s|D(0)|D(.5−)|D(−.5+)|tilt核心质量|
|---|---|---|---|---|
|.25|0.483948472|0.531886499|0.531886499|0.956416079|
|.05|1.22780606|1.23635531|1.23635531|0.996916532|
|.01|2.38928532|2.39095896|2.39095896|0.999739811|

分片内符号变号根扫描未检出连续D=0根（不是完备无根证明）；重叠对照在v腿x=-.25,.5和u腿x=-.5,.25存在hard跳跃越过D=0，峰不能靠连续性自动补成空间根。完整左右值见JSON。

因此下一步应保留D的中心位置、核心K=sJ退化及原good/capture支持，联合估计真实完整费用；不能只追统一Var(Y)下界或只估Rmix。该计算没有实施原good/capture门，不认证实际交通可行性，不支付原source/selector、双Pi或时间费用。无一般维数拟合。

复现命令：

```sh
PYTHONPATH=/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor /Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 /Users/zhengzhihao/Math-Research-centered-cube-work/centered-cube-upper-bound/rounds/217/work/small_soft_checks.py
```

## 有限源clock与min-product证书（追加实际运行）

新增三阶段n=(2,4)/(8,16)/(32,64)，每配置Fraction精确算术及mpmath 40/70dps积分。target、bad、future-deleted extra源质量均为1；extra权同target，在(lo+hi)/2删除，始终不作terminal bad。删除前e_t=2(a/t)^n+(a/t)^(n−1)，删除后e_t=(a/t)^n+(a/t)^(n−1)；e_g=a^n+a^(n−1)。保留完整Pi²分母，并在删除点分片。原min-product实现为target/extra的n个alpha均1/8，bad的n−1个alpha为1/8、另一个为1；在所用时域及g=1恰给上述幂。帽min(w_t,cw_g)与这个原乘积定义分开。

取a=1/8、g=1、c=2^n、lo=1/2、hi=(1/2)(1+1/(8n))、U=(2hi)^n、B=2U−1、ζq=1、H=B−1。K=3,J=1,L0=c,p=(1+B)/w_g,κT=p/c,q=1。所有Fraction断言通过：0<H<1、good饱和、d(lo)=1,d(hi)=U；mixed为2d/(1+B)<1，恰t<hi。

在collar中min(w_v(t),cw_g)=w_v(t)，所以精确FTC drop=wlo−whi=cw_g(1−1/U)=cw_g H/(1+B)，没有额外1/2；p乘回恰p drop=cH=(K/3)L0 J H。真正pair积分为∫w_vw_u/e_t² dt/t（δ=1）。各段化简成a/(ma+t)^2，其中删除前m=2、删除后m=1，因此存在独立有理原函数−a/(ma+t)，可与直接未消去权重的高精积分核对。六个精确有理比较均满足pair≤drop/e_g。

|n|pair integral (70dps摘录)|pair / (drop/e_g)|
|---|---|---|
|2|0.00804712128754|0.158564867189|
|4|0.00412712603644|0.0200453278816|
|8|0.002090457636|0.000630028391785|
|16|0.00105208349824|1.23410227162e-06|
|32|0.000527772165175|9.42920097616e-12|
|64|0.000264320803383|1.09850659097e-21|

40/70dps结果最大绝对差为 3.27e-43；70dps与精确有理积分最大差为 0。两项不替代有理恒等式证书；有理结果直接证明这些有限配置的标量不等式。完整巨有理数保存在clock_certificate.json。

此处B/p/q为指定代数量，没有证明来自真实空间核，extra删除也是给定clock模型。因此只作有限源clock/min-product代数证书，不称FULL，不认证原capture、高面、来源预算或一般维数付款。

两个脚本现在均支持--output PATH；JSON不含运行时或输出路径，默认写各自责任JSON。small_soft历史耗时保留在上文；重跑耗时仅stdout显示。

clock复现：

```sh
PYTHONPATH=/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor /Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 /Users/zhengzhihao/Math-Research-centered-cube-work/centered-cube-upper-bound/rounds/217/work/clock_certificate.py
```

最终确定性复核：两个脚本各用显式--output指向原JSON再次运行，运行前后完整字节相等，断言通过；没有在JSON保留耗时或输出路径。

原min-product权实现补充：target/extra各n个alpha_i=1/8；bad为n−1个alpha_i=1/8及一个alpha_i=1。因此原权w_t=∏_i min(1,alpha_i/t)（再乘指定alive/deleted mask）在本collar及g=1实现上述幂。min(w_v,cw_g)仅为FTC辅助帽，不能与原min-product定义混同；JSON现分列两者。
