#!/usr/bin/env python3
"""R217 deterministic finite-window physical tilt probes; not interval certificates."""
import argparse, json, math, time, hashlib
from pathlib import Path
import mpmath as mp
HERE=Path(__file__).resolve().parent

def phi(x):
    x=abs(x); h=mp.mpf('.5')
    def e3(t):
        if not t: return mp.mpf('.5')
        return ((1-t)*mp.exp(-t)+t*t*mp.e1(t))/2
    return 1-e3(h-x)-e3(h+x) if x<=h else e3(x-h)-e3(x+h)
def fs(x,s): return (1-s if abs(x)<=mp.mpf('.5') else 0)+s*phi(x)
def evaluate(s0,dv0,du0,dps,degree,Z):
  with mp.workdps(dps):
    s,dv,du=map(mp.mpf,(s0,dv0,du0)); r=mp.mpf('.25'); th=1/(8*max(1,mp.log(1/s))); beta=r+th; q=r/beta; C=q**r*(1-q)**th; peak=mp.log(r/th)
    nodes,weights=mp.gauss_quadrature(degree,'legendre')
    base=[-mp.mpf(Z),mp.mpf(Z),mp.mpf(0),-mp.mpf('.5'),mp.mpf('.5'),dv,du,dv-mp.mpf('.5'),dv+mp.mpf('.5'),du-mp.mpf('.5'),du+mp.mpf('.5')]
    for t in (1,2,4,8,16,32,64,128):
      if t<Z: base.extend((mp.mpf(t),mp.mpf(-t)))
    cuts=sorted(set(base)); rows=[]
    def point(x):
      p=fs(x,s); jv=phi(x-dv); ju=phi(x-du); kv=fs(x-dv,s); ku=fs(x-du,s)
      yv=mp.log(jv)-mp.log(p)-mp.log(kv); yu=mp.log(ju)-mp.log(p)-mp.log(ku)
      g=p**mp.mpf('1.5')/(jv*ju)**r/(kv*ku)**th
      Dv=yv-peak; Du=yu-peak
      def f(D): return mp.exp(-beta*(mp.log(1-q+q*mp.exp(D))-q*D))
      prod=f(Dv)*f(Du)
      direct=p*(jv/p+kv)**(-beta)*(ju/p+ku)**(-beta)
      return g,yv,yu,Dv,Du,prod,direct
    sums=[mp.mpf(0) for _ in range(15)]
    for a,b in zip(cuts,cuts[1:]):
      mid=(a+b)/2; half=(b-a)/2
      for z,w in zip(nodes,weights):
        x=mid+half*z; wt=half*w; g,yv,yu,Dv,Du,prod,direct=point(x)
        vals=[g,g*yv,g*yv*yv,g*yv**3,g*yv**4,g*yu,g*yu*yu,g*yu**3,g*yu**4,g*prod,direct,g*int(abs(x)<mp.mpf('.5') and abs(x-dv)>mp.mpf('.5') and abs(x-du)>mp.mpf('.5')),g*yv*yu]
        core=int(abs(x)<mp.mpf('.5') and abs(x-dv)>mp.mpf('.5') and abs(x-du)>mp.mpf('.5'))
        vals.extend([g*yv*core,g*yv*yv*core])
        for k,v in enumerate(vals): sums[k]+=wt*v
    M=sums[0]; mv=sums[1]/M; mu=sums[5]/M
    vv=sums[2]/M-mv**2; vu=sums[6]/M-mu**2
    fourthv=sums[4]/M-4*mv*sums[3]/M+6*mv**2*sums[2]/M-3*mv**4
    fourthu=sums[8]/M-4*mu*sums[7]/M+6*mu**2*sums[6]/M-3*mu**4
    # R216 absolute envelope at fixed theta=chi=1/8 dominates this g.
    eps=mp.mpf('.25'); ce=mp.mpf('.2'); delta=mp.mpf('1.5')-(1+eps)*mp.mpf('.75')
    logB=-mp.mpf('.75')*mp.log(ce)-mp.mpf('.25')*mp.log(s)+mp.mpf('.75')+(1+eps)*mp.mpf('.75')/2+(1+eps)*mp.mpf('.375')*(abs(dv)+abs(du))
    cy=-3*mp.log(ce)-2*mp.log(s)+(1+eps)*(2*max(abs(dv),abs(du))+mp.mpf('1.5')); dy=(1+eps)*3
    def tail(j):
      total=mp.mpf(0)
      for k in range(j+1):
        prim=sum(mp.factorial(k)/mp.factorial(k-l)*mp.mpf(Z)**(k-l)/delta**(l+1) for l in range(k+1))
        total+=math.comb(j,k)*cy**(j-k)*dy**k*prim
      return 2*mp.exp(logB-delta*Z)*total
    # Find D=0 on each continuous interval; hard jumps are reported separately.
    roots={}; jumps={}
    for leg,ix in [('v',3),('u',4)]:
      rr=[]; jj=[]
      for a,b in zip(cuts,cuts[1:]):
        aa=a+(b-a)*mp.mpf('1e-10'); bb=b-(b-a)*mp.mpf('1e-10'); fa=point(aa)[ix]; fb=point(bb)[ix]
        if fa*fb<0:
          lo,hi=aa,bb
          for _ in range(80):
            mid=(lo+hi)/2; fm=point(mid)[ix]
            if fa*fm<=0: hi=mid
            else: lo=mid; fa=fm
          rr.append((lo+hi)/2)
      for x in cuts[1:-1]:
        e=mp.mpf('1e-10'); a=point(x-e)[ix]; b=point(x+e)[ix]
        if a*b<0: jj.append({'x':str(x),'D_left':mp.nstr(a,16),'D_right':mp.nstr(b,16)})
      roots[leg]=[mp.nstr(x,24) for x in rr]; jumps[leg]=jj
    val={'M':M,'theta':th,'Theta_log_inverse_s':2*th*mp.log(1/s),'C_v_C_u':C*C,'Rmix':sums[9]/M,'M_Rmix':sums[9],'Zmix_factorized':C*C*sums[9],'Zmix_direct':sums[10],'identity_abs_error':abs(C*C*sums[9]-sums[10]),'mean_Y_v':mv,'mean_Y_u':mu,'variance_Y_v':vv,'variance_Y_u':vu,'central_fourth_Y_v':fourthv,'central_fourth_Y_u':fourthu,'covariance_Yv_Yu':sums[12]/M-mv*mu,'mean_D_v':mv-peak,'mean_D_u':mu-peak,'target_Y_at_peak':peak,'tilt_mass_receiver_core_both_shifted_cores_outside':sums[11]/M,'raw_abs_Y_tail_bound_0_to_4':[tail(j) for j in range(5)],'delta_envelope':delta,'B_envelope':mp.exp(logB)}
    def convert(v):
      if isinstance(v,list): return [convert(t) for t in v]
      return mp.nstr(v,dps)
    val['conditional_core_variance_Y_v']=sums[14]/sums[11]-(sums[13]/sums[11])**2 if sums[11] else mp.nan
    val['D_v_at_receiver_core_center']=point(mp.mpf(0))[3]
    val['D_v_at_receiver_core_right_inside']=point(mp.mpf('.5')-mp.mpf('1e-12'))[3]
    val['D_v_at_receiver_core_left_inside']=point(-mp.mpf('.5')+mp.mpf('1e-12'))[3]
    out={k:convert(v) for k,v in val.items()}; out.update({'s':s0,'d_v':dv0,'d_u':du0,'dps':dps,'degree':degree,'Z':Z,'cuts':[str(t) for t in cuts],'curvature_peak_roots_D_equals_zero':roots,'hard_jump_crossings_D_equals_zero':jumps})
    return out

def main(output):
  start=time.monotonic(); cases=[(s,dv,du) for s in ('.25','.05','.01') for dv,du in [('1.25','1.25'),('.25','-.25')]]; stages=[]
  for name,dps,degree,Z,configs in [('initial',18,24,24,cases[:2]),('stress',24,48,64,cases),('expanded_precision',36,96,160,cases)]:
    results=[]
    for config in configs:
      results.append(evaluate(*config,dps,degree,Z)); print(name,config,'M=',results[-1]['M'],'R=',results[-1]['Rmix'],flush=True)
    stages.append({'stage':name,'results':results})
    output.write_text(json.dumps({'schema':'R217_small_soft_physical_tilt_v1','stages':stages,'complete':False},indent=2)+'\n')
  comparisons=[]
  with mp.workdps(45):
    for a,b in zip(stages[1]['results'],stages[2]['results']):
      comparisons.append({'s':b['s'],'d_v':b['d_v'],'relative_differences':{k:mp.nstr(abs(mp.mpf(a[k])-mp.mpf(b[k]))/max(mp.mpf('1e-40'),abs(mp.mpf(b[k]))),16) for k in ['M','Rmix','M_Rmix','Zmix_direct','variance_Y_v','central_fourth_Y_v']}})
  result={'schema':'R217_small_soft_physical_tilt_v1','complete':True,'mpmath_version':mp.__version__,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'stages':stages,'stress_expanded_comparisons':comparisons,'limitations':['Finite Gauss-Legendre quadrature without interval rounding; analytic infinite-tail envelopes are evaluated in ordinary arbitrary precision.','Only n=1 algebraic diagnostic, parameters L0=kappa=T=b=w=1 do not certify original traffic feasibility.','Root scan detects sign changes inside the explicit partition, not all possible tangent roots.','No general-n order fit or original good/capture payment claim.']}
  output.write_text(json.dumps(result,indent=2)+'\n'); print('complete',time.monotonic()-start,flush=True)
if __name__=='__main__':
  ap=argparse.ArgumentParser(); ap.add_argument('--output',type=Path,default=HERE/'small_soft_checks.json'); args=ap.parse_args(); main(args.output)
