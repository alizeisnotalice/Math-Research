# R217：小软度下的真实曲率几何与费用

R216已推送a1dc87922c6f11f902c5db008dcbf3d56aa3c217；冻结包/Users/zhengzhihao/Desktop/T/output/centered_cube_round216_20261016_final_checkpoint。一般任意正L1中心立方体根阶弱型目标不变。原mixed两端、capture/goodbad、high/FIRST、Π²/e²、dx、窗口、时间与负信用全部保留。

本轮先核小指数Θ log(1/s)有界能控制哪些真实倾斜费用，不预设所有来源/soft下Y=logJ-logp-logK有统一正方差。低软度且K=sJ的局部几何可近似消去空间变化；应保曲率峰的位置D、原good/capture门与其互补，不将统一非退化当已证。若只给有限条件或旧包络，明确不算新一般付款。

可用R215精确joint尾/源权吸收，R216 exactmixed曲率、共同Phi与CB5低频浓度桥接、CR5–7实际good支持及全部互补域。不能重复使用已耗w，也不能把旧R134逆good、R197反集中、R123/124/198软度工具重新登记。K04仅用于适用性核验，本对象不是Gaussian最大值，不直接援引其外部Gaussian定理。

任务分工：Astra r166_raw_budget负责peak_good_geometry.md：唯一核心为将曲率峰位置与真实good/capture联合估计，削减原空间/来源预算；先准确命题后证明。Sol r166_exact_certificate负责small_exponent_comparison.md：独立核小Θ下真实tilted density比较、退化方向与可用矩常数，提供能实际使用的弱形式，不追泛反例。Sol r164_audit负责audit.md：先独筛准确对象及条件后读作者稿。Sol medium r171_numeric_design负责small_soft_checks.py/json与numeric_notes.md：预定少量物理tilt配置，三阶段多精度，探路小soft/指数/位移/峰位置，不拟合n阶；先方案再运行。主代理负责共同支持/权重推导、选择下一步、最终实际复跑及整合。

各人只写责任文件，不Git/PDF/自增Agent/无界扩任务；完成停等。成果须改变实际下一步或提供经独审的新估计，不以篇幅、余项改名或恢复旧粗界计成果。最终每轮精简归档独立commit/push；未闭合明确保留一般缺口。

## 恢复后的实际分工与路线调整

2026-10-16恢复时live agent仅root，已确认work只有本任务书。未重复旧存活任务；新启r217_peak（Astra high）、r217_compare（Sol high）、r217_audit（Sol high）、r217_numeric（Sol medium）。四者分别负责peak_good_geometry.md、small_exponent_comparison.md、audit.md、两组数值脚本/JSON与numeric_notes.md；主代理负责capture_geometry.md、capture_polynomial_check.py/json、详细LaTeX、报告和最终归档。没有启动无独立职责的额外Agent。

主线从uniform tilted方差转向完整mixed+good限制原w_t值域的几何。最终准确命题为d>=1且实际固定捕获余权R乘H正部<=epsilon的原正子支具有16Lambda L0 epsilon/(3K) WA预算；全尺度成立。H=(K1+K2)/J−p K0/(kappa T L0 J)。H先由真实核定义，不重选。主代理再将原rho0与H联合，给尺度可比较剩余支的二次中间区间。成功判据是实际原测度价格独审通过；其余分支仍须明确保留，不把这一子支冒作一般上界。

只调用实际本机Python/mpmath/Fraction和辅助MATLAB检查，无PDF编译。不存在可分离的本轮模型扣额记录，不猜成本比例。
