# R217：mixed 曲率峰、真实 good 与可支付的时钟窄区间

状态：证明一个新的原正子支上界，而不是只估计归一化后的曲率因子。完整 mixed 与 good 将原时钟权的下降限制为一个显式差值，并完整保留原捕获余权；该加权差值与同一 good 门相乘后，恰好留下固定尺度 J 的来源积分。由原 high/FIRST 支付全部 receiver、时间和来源费用，不使用任何负余额，也不再次使用 R215 已耗的 w。一般互补域仍未支付。

本稿只写责任文件。先读 R217 task_contract、R216 mixed_entropy_geometry 与 constrained_receiver_geometry；窄核 R128 RT1–6 及 R170 research.zip 中 source_pair_tool_contract.md §SP3、bridge_energy_audit.md §8.3–8.4，以及 R211 research.zip::joint_capacity.md JC19–23、JC28–30 和 audit.md §10–11。R170 的终端比值结算属于有条件 signed 边界工具，本稿控制的是 mixed 补域内实际正 delta 的积分。以下不把旧 R134 逆 good 或恢复 HH 包络计作新付款。

## PG1　准确命题先行

保持原固定 block 的 b、J_v=P_{1,b}(x-v)，实际选择器 p_y=P_{s,L}(x-y)、K_{1v}=P_{s,L}(x-v)、K_{2v}=P_{s,L^+}(x-v)、K_{0v}=P_{s,Hhat}(x-v)，以及原 T、g、Z_t、e_t、w_t 和 Π_t。这里 g、核、T 可依 x，但在固定实际 receiver 行后不随辅助时钟 t 变化。

只在正交通行写商；严格实际 s>0 保证各核正，e_g=0 等零行先按原合同处理。令

\[
 c=3L_0/K,\quad d_t(v)=c\,w_g(v)/w_t(v),\quad
 q_v=K_{0v}/J_v,\quad \zeta_y=p_y/(\kappa T L_0),
\]
\[
 B_v=(K_{1v}+K_{2v})/J_v,\qquad
 H_y(v)=B_v-\zeta_yq_v.
 \tag{PG1}
\]
K 为原 good 常数，不是核 K0。q_v 也不是原 FIRST 水平，后者以下记 Q。

设 R(v)∈[0,1] 是该原正泛函中实际保留的 target 权；固定完整 (ω,V,j,x,y,g,history) 行后，它不依辅助 t。上层取原 ρ_r(v)，或已按 R211 剥离并支付 recapture 后的基线 ρ0(v)，不重新计算任何依赖原 ρ 的门。R=0 的交通先零。

这一冻结资格来自原定义而非新假设：R128 RT2/RT6 的 Δ=w_τ−w_h、a=TΔ、E、U、α 取自实际终端/历史行，辅助 t 只在 Π_t、δ_t 及其实际门中运行；R211 JC19–22 准确写 ρ=(1−DK0/a−αJ/a)_+、ρ0=(1−DK0/a−α0J/a)_+，α0=DQ_FIRST/∫Jdν，所有右端也在同一实际行固定。零 a、零 Q_J、空 target 按原合同先零。JC23、JC28–30 明确保持原实际门，不用 ρ0 重算 history 或资格。故两权均合法带出下面的单来源时钟积分；这里没有给 ρ 添加任何新点态不等式。

对任意共同预定 ε>0，从含此实际 R 权的尚未支付 mixed 正余项中截取

\[
 \mathcal A_\varepsilon=
 \{d_t(v)\ge1,\quad 0<R(v)H_y(v)_+\le\varepsilon\}.
 \tag{PG2}
\]
该子支仍交原两腿 mixed、target good、bad、capture、high/FIRST、FA、rho0、唯一 j、窗口和全部历史门。不同已支付正子支先作不交化。设 W_ν=EΣ_V||ν_V||，保原来源总账 W_ν≤W_A；**不假设 ν≤β 或 W_ν≤W_β**。

H≤ε 是这一加权条件的充分子支；允许 R 很小而 H 很大，故加权命题更强。R=1 给未加捕获权的特例，不把实际 R 替换为一个未经授权的人造权。

**命题。** 对任意合法有限正交通截断，恢复一次硬来源 16/3 和外系数 2Λ 后，

\[
 \boxed{R^+_{\mathrm{mixed}\cap\mathcal A_\varepsilon}
 \le {16\Lambda L_0\over3K}\,\varepsilon W_\nu
 \le {16\Lambda L_0\over3K}\,\varepsilon W_A.}
 \tag{PG3}
\]
其余原负余额完全不动。ε=1 给显式 O(L0) 正来源价；若原 L0 为根阶，该子支的来源价就是根阶。没有另外的 n、时窗长度、j 菜单、soft 菜单或当前尺度 selector 费用；这些消失的理由是下面完整的实际行证明，而非冻结 selector 后冒用概率归一。

本命题不要求 Hhat≥L+、Hhat≤H0 或 p/T≤2κL0。原全部尺度均可使用 PG1–3；这些条件仅在后面的“小 s 充分几何”说明中按需出现。

## PG2　mixed/good 给出的准确时钟区间

记原 mixed 两腿中的 target 量

\[
 a_v=L_0J_v/(p_yw_t(v)),\qquad
 b_v=K_{0v}/(\kappa T w_t(v))=a_v\zeta_yq_v.
\]
由同一 target 的 good，

\[
 3p_yw_g(v)/K\le K_{1v}+K_{2v}+J_v
 \quad\Longleftrightarrow\quad d_t(v)\le a_v(1+B_v).
 \tag{PG4}
\]
完整 mixed 给 a_v(1+ζ_yq_v)<1。二者合用，精确推出

\[
 d_t(v)<U_y(v):={1+B_v\over1+\zeta_yq_v}.
 \tag{PG5}
\]
故 d_t≥1 时必 H_y(v)>0；H≤0 的该支严格为空。不能把混合门分别拆开后仍声称有下面的减项 ζq。

固定 x,y,v 后 B、ζ、q、U、wg 都不随 t 变。原 w_t 连续非增，a.e.

\[
 -\partial_{\log t}w_t(v)=k_t(v)w_t(v),\qquad k_t(v)\ge0.
\]
因此 d_t≥1、d_t<U 对应

\[
 c w_g(v)/U<w_t(v)\le c w_g(v).
\]
对任何原合法时钟子域 I⊂{t≤g}，无需其连通，也无需冻结 Z_t，有

\[
 \int_I k_t(v)w_t(v)
 1_{\{1\le d_t(v)<U\}}\,{dt\over t}
 \le c w_g(v)\left(1-{1\over U}\right)_+
 =c w_g(v){H_y(v)_+\over1+B_v}.
 \tag{PG6}
\]
证明：w_t 的下降测度穿过给定值域的总量至多该值域长度；单调性保证不会多次穿越。k_t=0 的平台贡献为零，有限阈值时 w_t 连续，严格 k 的端点约定不产生额外跳质量。真实删除只改变 Z_t/e_t，不改变这个单来源 w_t 身份。若 c<1，t≤g 给 d_t≤c<1，PG2 本身为空；c=1 时只有可能的零下降平台，不造成例外。

## PG3　保两个原来源因子的时钟积分

固定实际 receiver 行，target v 属于原 terminal good 集 G⊂Z_g。原冻结单调合同给 Z_g⊂Z_t、e_t≥e_g>0（t≤g）；并不声称 Π_t 按测度序单调。用原 δ_t=(k_t(v)-k_t(u))_+≤k_t(v)，先在 u 上对完整 Π_t 归一化，再上放其余非负门，得到

\[
 \begin{aligned}
 &\int_I\iint \delta_t\,R(v)1_{G}(v)
 1_{\{1\le d_t(v)<U_y(v)\}}
 1_{\{0<R(v)H_y(v)_+\le\varepsilon\}}
 \,\Pi_t(dv)\Pi_t(du)\,{dt\over t}\\
 &\le {1\over e_g}\int_G R(v)1_{\{0<R(v)H_y(v)_+\le\varepsilon\}}
 \left[\int_I k_t(v)w_t(v)
 1_{\{1\le d_t(v)<U_y(v)\}}{dt\over t}\right]\nu(dv)\\
 &\le {c\over e_g}\int_Gw_g(v)
 {R(v)H_y(v)_+\over1+B_v}
 1_{\{R(v)H_y(v)_+\le\varepsilon\}}\,\nu(dv).
 \end{aligned}\tag{PG7}
\]
第一步实际上是 ∫1_Zt wt(u)ν(du)/e_t²=1/e_t≤1/e_g；v 的 terminal 支持保证它不会在区间内被删。未对 Π_t 微分，故无需删除跳或后验漂移费。实际捕获权 R 全程保留，利用它对辅助 t 固定而带出内层积分；u 腿 mixed、bad、其它 capture/FA/suffix 等门仅作非负上放，不把其资格转给其它来源。

**w 账。** 此处从原未消费的两份 wt 出发：u 的一份在原 Π_t 归一化中使用，v 的一份在 PG6 单调下降中使用。没有使用 R215 的位移吸收；本界与 R215 对同一正量的界是备选上界，不能将后者已经吸收了 w 的余式代入 PG7 再领一遍概率归一。

## PG4　good 消分母、high/FIRST 与真实 dx 的闭合

同一个 good 门给

\[
 p_y w_g(v)\le {K\over3}J_v(1+B_v).
\]
因此将原外 p_y 乘回 PG7，得到更精确的实际正核价

\[
 p_y\,\mathrm{clock}_\varepsilon(x,y)
 \le {cK\over3e_g(y)}
 \int_G J_v R(v)H_y(v)_+1_{\{R(v)H_y(v)_+\le\varepsilon\}}\,\nu(dv).
 \tag{PG8}
\]
这里实际联合权中的 H_y(v) 正部满足

\[
 J_vH_y(v)_+
 =\left(K_{1v}+K_{2v}-{p_y\over\kappa TL_0}K_{0v}\right)_+.
 \tag{PG9}
\]
PG8 实际保留 R(v) 乘上述正部。这是 full mixed 与原 capture 在实际来源权中的改进，不能只把它改名为未付余项；PG2 的加权截断正好使 R(v) 乘该正部≤εJ_v，从而有可归一化的固定 b 核。

原 high 和共同 FIRST 逐 receiver 给

\[
 {1_{\mathrm{high}}\over e_g(y)}\le {p_y\over2KQ},\qquad
 \int p_y\,\beta_V(dy)\le Q.
\]
于是对每个固定 x,V,j，

\[
 \int\beta_V(dy)\,1_{\mathrm{high}}
 p_y\,\mathrm{clock}_\varepsilon(x,y)
 \le {c\varepsilon\over6}J\nu_V(x).
 \tag{PG10}
\]
该论证使用相同 x 的真实 p_y、Q 和实际 selector，不依赖 ν≤β，不把 β 或 ν 概率化。更精确地可保留次概率 M_x(dy)=p_yβ_V(dy)/Q 及其 high/good/RH 权：PG10 的 ε 可替换为同一 M_x 下的加权 R H_+ 积分；只有 PG2 才给统一 ε。

至此右边不依 j、y、g、s、L、Hhat 或 T。原唯一 1_{j(x)=j} 一直保留，现在才合并 j；不同独立窗口仍各按自身来源账，不复制一份 W_A。J=P1,b 的 b 是原固定 block 参数，故

\[
 \int J\nu_V(x)\,dx=\|\nu_V\|.
\]
硬来源只用一次 16/3，外 signed 系数只乘一次 2Λ，得到

\[
 (2\Lambda)(16/3)(c\varepsilon/6)
 ={16\Lambda c\varepsilon\over9}
 ={16\Lambda L_0\varepsilon\over3K},
\]
即 PG3。时间已经由 PG6 完整积分，不再乘 T_* 或 log2；current selector 已由 PG8–10 转成固定 J，不再付 CR11 的尺度 n。每一步是正上界，所以不需改变或消费任何负项；任意截断先作，随后非负单调极限合法。

## PG5　与真实曲率峰 D 和小软度几何的连接

R216 target 曲率位置为

\[
 D_v=\log(a_v/b_v)-\log(r/\theta)
 =-\log(\zeta_yq_v)-\log(r/\theta).
 \tag{PG11}
\]
在 PG2 的 clock 域，由 PG4–5 有 ζq<B，因此

\[
 D_v>-\log B_v-\log(r/\theta).
 \tag{PG12}
\]
若 Hhat≥L+，CR3 给 B_v≤C_Hq_v，其中 C_H=(Hhat/L)^n+(Hhat/L+)^n，故

\[
 D_v>-\log C_H-\log q_v-\log(r/\theta).
 \tag{PG13}
\]
真正同尺度 L=L+=Hhat=b 时 C_H=2，得到题设的 −log2−log(K0/J)−log(r/θ)。这不是将一般 CR7 除 T 后忽略 (H0/L)^n：一般尺度始终保 C_H，PG3 本身不需要该除法。

在同尺度源 core 外，每坐标 K0/J 恰为 s。若所有 n 个坐标都在源 core 外，q_v=s^n、B_v=2s^n。于是对任何 ζ≥0，PG2 的 R H_+≤ε 在 ε≥2s^n 时自动满足（更强地可保 2R(v)s^n≤ε），而真实 good/mixed 强迫 clock 处于 1≤d<(1+2s^n)/(1+ζs^n)。所得小系数已在 PG6–10 联合权中支付，不是仅报告 R_mix 小。

可用的全维数、一般当前尺度版本如下。令 a_φ=φ(1/2)>0、B_s=s+(1-s)/a_φ。定义

\[
 m_v=\#\{i:|x_i-v_i|>L^+/2\}.
\]
对任一 A∈{L,L+}，A≤b。若该坐标在 A 的 core 外，由 φ 径向非增，

\[
 {(b/A)f_s((x_i-v_i)/A)\over\phi((x_i-v_i)/b)}
 \le (b/A)s.
\]
若在 A 的闭 core 内，φ((x_i-v_i)/A)≥a_φ 且 φ((x_i-v_i)/b)≥φ((x_i-v_i)/A)，故同一比值≤(b/A)B_s。实际外坐标多于 m_v 只改善此界，因为 s≤B_s。因此

\[
 \boxed{B_v\le
 [(b/L)^n+(b/L^+)^n]\,s^{m_v}B_s^{n-m_v}
 \le 2(b/L)^n s^{m_v}B_s^{n-m_v}.}
 \tag{PG14}
\]
这给不依赖 Hhat 的明确充分几何：只要右端≤ε，或更强地只要求 R(v) 乘右端≤ε，则整个 d≥1 的实际 mixed/good 子支都由 PG3 支付。若用 λ=L/b，可写

\[
 m_v\log(1/s)-(n-m_v)\log B_s
 \ge n\log(1/\lambda)+\log(2/\varepsilon).
 \tag{PG15}
\]
闭 core 面必须计入内坐标，不能靠 Lebesgue 零面删除实际选择器所选硬面。PG14–15 完整保留 n、尺度和 core 内增强费用，不声称单个外坐标就足以付全维数预算。实际原 soft 下门 s>1−2^(−1/n) 仍保留，s=0 不被授予 FULL 身份。

## PG6　为什么没有遗漏 monomial 总质量 M

本证明从原事件的 p_yΠ_t²δ 正积分开始，到 PG3 在原 dx、β、ν、clock 测度下结束；没有将 P* 归一化后的前因子当总质量。与 R216 身份的代数联系为

\[
 C_v a_v^{-r}b_v^{-\theta} f_{r+\theta,r/(r+\theta)}(D_v)
 =(a_v+b_v)^{-(r+\theta)}
 =a_v^{-(r+\theta)}(1+\zeta_yq_v)^{-(r+\theta)}.
\]
仅用 D 大给 f 的指数尾，会抵消 inverse-K 中的 q^{-θ} 并退回旧单项包络；这不算付款。PG6 的新信息来自同一个 good 对 a_v 的下界，把上述 1+ζq 与 1+B 的差变成原 wt 可支付的下降量。故结论不要求额外控制 M、tilted 方差或 Fourier 窗，也不宣称已有一个统一的 Rmix 根阶界。

## PG7　全分支账与历史边界

在当前尚未支付 mixed 正余项内，按以下顺序不交分割：

1. d_t(v)<1：本稿未支付；这是原 terminal/current 时钟比偏低域，不能给它继承 PG6。
2. d_t(v)≥1 且 H_y(v)≤0：由完整 mixed/good 严格为空。
3. d_t(v)≥1 且 0<R(v)H_y(v)_+≤ε：PG3 已给完整正预算；R=0 的行此前已零。
4. d_t(v)≥1 且 R(v)H_y(v)_+>ε：保留全部原 raw 权与负余额，仍未支付。

在第三支之外没有把旧粗包络重新称为新付款。若用 PG14 作为充分筛选，则其失败域也保留在第三支的潜在可付部分与第四支中；不能把 PG14 失败等同于 R H_+>ε。Hhat<L+、Hhat>H0 及 lower clamp 均未被删除，它们可直接按 PG1–3 分类，只有依赖 CR3 的峰位置说明要交 Hhat≥L+。bad u 不继承 v 的 good/capture 资格；它的门只在 PG7 的正上放中删除。

R170 已有 bounded-terminal-ratio 的 signed 边界价 16Λe^M/9 Wν，需要其完整时间独立分支与排序/suffix/删除资格。本稿不调用该身份或负项，而由原正 δ≤kv 和 mixed/good 的短值域直接积分，故不借其未授予的 positive-traffic 结论。与已付 R214 additive-cap 或其它历史正支须先不交化；对相同正量只选一个上界，不叠加信用。PG3 不认证第三支含旧工具未覆盖的 FULL 实例，亦不宣称一般原目标闭合；认证的是可直接用于原剩余正泛函的新联合权重估计和明确补域。

## PG8 本机验证范围

核心有限验证统一使用 clock_certificate.py/json 及 numeric_notes.md：实际min-product权、terminal target/bad、future-deleted来源、完整Pi_t两份权和高精分段积分；不以无物理上界的形式单调曲线作为原时钟证据。解析证明仍为PG2–4的单调下降、非负积分与真实high/FIRST推导，有限数值不认证FULL来源几何或一般阶数。实际运行和最终复现状态以数值笔记及父级driver回执为准。
