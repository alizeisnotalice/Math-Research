#!/usr/bin/env python3
"""Exact finite-source clock algebra, plus deterministic high precision pair integration."""
import argparse, hashlib, json
from fractions import Fraction as F
from pathlib import Path
import mpmath as mp
HERE=Path(__file__).resolve().parent

def fraction(x): return str(x.numerator)+'/'+str(x.denominator)
def calc(n):
    a=F(1,8); lo=F(1,2); hi=lo*(1+F(1,8*n)); deletion=(lo+hi)/2
    c=F(2)**n; wg=a**n; eg=wg+a**(n-1); U=(2*hi)**n; B=2*U-1; zetaq=F(1); H=B-zetaq
    p=(1+B)/wg; L0=c; K=F(3); J=F(1); kappaT=p/c; q=F(1)
    w=lambda t:(a/t)**n
    drop=w(lo)-w(hi); upper=drop/eg
    # Before deletion the two n-rate sources contribute 2*a^n; afterward only target does.
    primitive=lambda t,m:-a/(m*a+t)
    exact_pair=(primitive(deletion,2)-primitive(lo,2))+(primitive(hi,1)-primitive(deletion,1))
    assertions={'H_between_zero_and_one':0<H<1,'good_saturated':p*wg==1+B,'zeta_q_one':p/(kappaT*L0)*q==1,'d_lo_one':c*lo**n==1,'d_hi_U':c*hi**n==U,'mixed_hi_equality':2*U/(1+B)==1,'w_lo_c_wg':w(lo)==c*wg,'w_hi_cwg_over_U':w(hi)==c*wg/U,'FTC_drop':drop==c*wg*H/(1+B),'p_times_drop':p*drop==K*L0*J*H/3,'pair_le_drop_over_eg':exact_pair<=upper,'eg_terminal_target_plus_bad':eg==a**n+a**(n-1)}
    assert all(assertions.values())
    integrations=[]
    for dps in (40,70):
      with mp.workdps(dps):
        m=lambda f:mp.mpf(f.numerator)/f.denominator
        aa,ll,dd,hh=map(m,(a,lo,deletion,hi))
        # Actual weights and full e_t, rather than canceled integrand, are used in quadrature.
        def integrand(t,multiplicity):
          wv=(aa/t)**n; wu=(aa/t)**(n-1); et=multiplicity*wv+wu
          return wv*wu/(et*et*t)
        value=mp.quad(lambda t:integrand(t,2),[ll,dd])+mp.quad(lambda t:integrand(t,1),[dd,hh])
        integrations.append({'dps':dps,'pair_integral':mp.nstr(value,dps),'abs_error_vs_exact_fraction':mp.nstr(abs(value-m(exact_pair)),dps),'upper':mp.nstr(m(upper),dps),'pair_over_upper':mp.nstr(value/m(upper),dps)})
    with mp.workdps(80):
      difference=mp.nstr(abs(mp.mpf(integrations[0]['pair_integral'])-mp.mpf(integrations[1]['pair_integral'])),40)
    vals={'a':a,'g':F(1),'lo':lo,'hi':hi,'deletion_clock':deletion,'c':c,'w_target_g':wg,'w_bad_g':a**(n-1),'eg':eg,'Dupper_U':U,'B':B,'zeta_q':zetaq,'H':H,'K':K,'J':J,'L0':L0,'p':p,'kappa_T':kappaT,'q_K0_over_J':q,'w_target_lo':w(lo),'w_target_hi':w(hi),'FTC_drop':drop,'drop_over_eg_upper':upper,'p_times_FTC_drop':p*drop,'exact_pair_integral':exact_pair,'pair_slack_upper_minus_pair':upper-exact_pair}
    return {'n':n,'rational_values':{k:fraction(v) for k,v in vals.items()},'rational_assertions':assertions,'sources':[{'name':'target','mass':'1/1','clock_exponent':n,'alpha_coordinates':['1/8']*n,'deleted_at':None,'terminal_bad':False},{'name':'bad','mass':'1/1','clock_exponent':n-1,'alpha_coordinates':['1/8']*(n-1)+['1/1'],'deleted_at':None,'terminal_bad':True},{'name':'future_deleted_extra','mass':'1/1','clock_exponent':n,'alpha_coordinates':['1/8']*n,'deleted_at':fraction(deletion),'terminal_bad':False}],'pair_delta_target_minus_bad':'1/1','full_et_before_deletion':'2*(a/t)^n+(a/t)^(n-1)','full_et_after_deletion':'(a/t)^n+(a/t)^(n-1)','mixed_support':'lo <= t < hi; mixed endpoint hi is excluded; endpoints have zero dt/t mass','original_min_product_weights':'w_t(z)=product_i min(1,alpha_i/t) independently of deletion; the source measure separately multiplies 1_Zt by w_t. Alpha coordinates realize all displayed powers on [lo,hi] and at g=1', 'auxiliary_FTC_cap':'min(w_v(t), c*w_v(g)); on [lo,hi] it is w_v(t); this cap is distinct from the original min-product weight','integrations':integrations,'precision_40_70_abs_difference':difference}

def main(output):
    stages=[{'stage':name,'cases':[calc(n) for n in ns]} for name,ns in [('initial',[2,4]),('stress',[8,16]),('expanded',[32,64])]]
    result={'schema':'R217_finite_source_clock_certificate_v1','complete':True,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'mpmath_version':mp.__version__,'stages':stages,'scope':['Exact rational finite-clock certificate; no FULL or genuine spatial-kernel realization claim.','Other source mass is retained in e_t until its deletion; extra source is never terminal bad.','Rational exact pair integral independently checks 40/70dps quadrature; floating quadrature alone is not a directed interval certificate.','B, p, q are algebraic inputs; no original good/capture geometry or general-source bound is certified.']}
    output.write_text(json.dumps(result,indent=2)+'\n')
    for stage in stages:
      for row in stage['cases']: print(row['n'],row['integrations'][-1]['pair_integral'],row['integrations'][-1]['pair_over_upper'],flush=True)
if __name__=='__main__':
    ap=argparse.ArgumentParser(); ap.add_argument('--output',type=Path,default=HERE/'clock_certificate.json'); args=ap.parse_args(); main(args.output)
