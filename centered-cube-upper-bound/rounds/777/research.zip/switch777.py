#!/usr/bin/env python3
"""R777 exact two-price pruning, hard marginal-preserving switches and peak stitching."""

from collections import defaultdict
from fractions import Fraction as F
from itertools import product
import json
import sys


def ss(items):
    return sum(items,F(0))


def size(q):
    return max(F(0),q[1]-q[0])


def inter(*q):
    return max(z[0] for z in q),min(z[1] for z in q)


def contains(q,r):
    return q[0]<=r[0]<=r[1]<=q[1]


def mu(q):
    a,b=inter(q,(F(-4),F(4)))
    if a>=b:
        return F(0)

    def primitive(x):
        rounds=x//F(1,4)
        t=x-rounds*F(1,4)
        return rounds*F(1,4)+t/2+max(F(0),t-F(1,8))

    return primitive(b)-primitive(a)


def core_geometry():
    middle=16
    A=[(F(-3),F(3))]*middle+[(F(-9,4),F(7,4)),(F(-7,4),F(9,4))]
    C=[parent if i<2 or i>=middle else (parent[0],F(7,8)) for i,parent in enumerate(A)]
    a=32
    shrink=[((lo+hi)/2-(hi-lo)/(2*a),(lo+hi)/2+(hi-lo)/(2*a)) for lo,hi in A]
    step=size(shrink[0])/middle
    E=[(shrink[0][0]+(i+F(1,8))*step,shrink[0][0]+(i+F(7,8))*step)
       for i in range(middle)]+shrink[middle:]
    assert all(contains(s,e) and size(e)>0 for s,e in zip(shrink,E))
    assert all(not size(inter(e,f)) for i,e in enumerate(E) for f in E[:i])
    m=[mu(a) for a in A]
    assert m==list(map(size,A)) and all(4<=x<8 for x in m)
    I=list(map(size,E))
    I[-2]*=F(1,8)
    I[-1]*=F(1,10)
    edges={(0,1),(2,3),(4,5)}
    keys=range(len(A))
    s={(e,v):mu(inter(C[e],C[v])) for e,v in product(keys,repeat=2)}
    K={(e,v):s[e,v]/(m[e]*m[v]) if e!=v and tuple(sorted((e,v))) not in edges else F(0)
       for e,v in product(keys,repeat=2)}
    down={e:[u for u in keys if m[u]<m[e] and K[e,u]>0] for e in keys}
    d={e:ss(I[u]*K[e,u] for u in keys) for e in keys}
    dminus={e:ss(I[u]*K[e,u] for u in down[e]) for e in keys}
    assert all(d.values()) and all(len(down[e])==2 for e in range(middle))
    peaks={(u,e,g):I[u]*I[e]*I[g]*K[e,u]*K[e,g]/d[e]
           for e in keys for u,g in product(down[e],repeat=2)}
    Q=ss(peaks.values())
    assert Q==ss(I[e]*dminus[e]**2/d[e] for e in keys)>0
    return keys,A,C,E,m,I,s,K,d,down,peaks,Q


def stats(q):
    """Readable decimal enclosure after exact Fraction assertions."""
    scale=10**12
    k,r=divmod(q.numerator*scale,q.denominator)

    def dec(v):
        return f"{v//scale}.{v%scale:012d}"

    return [dec(k),dec(k+bool(r))]


def switch(nu,K):
    edges=list(product(nu,repeat=2))
    bad={e:ss(nu[v] for v in nu if not K[e,v]) for e in nu}
    epsilon=max(bad.values())
    assert 0<min(bad.values())<epsilon<F(1,4)
    total_bad=ss(nu[e]*bad[e] for e in nu)
    reference={pair:nu[pair[0]]*nu[pair[1]] for pair in edges}
    good={pair for pair in edges if K[pair]}
    if not good:
        raise AssertionError("no good edge")
    final={pair:reference[pair] for pair in good}
    donors_used=defaultdict(F)
    normalizers=[]
    for e,v in edges:
        if K[e,v]:
            continue
        choices=[(a,b) for a,b in sorted(good) if K[a,v] and K[e,b]]
        normalizer=ss(reference[a,b] for a,b in choices)
        assert normalizer>=1-3*epsilon>0
        normalizers.append(normalizer)
        for a,b in choices:
            weight=reference[e,v]*reference[a,b]/normalizer
            final[a,b]-=weight
            donors_used[a,b]+=weight
            final[e,b]+=weight
            final[a,v]+=weight
    used=max(w/reference[k] for k,w in donors_used.items())
    assert used<=total_bad/(1-3*epsilon)<1
    assert all(w>0 for w in final.values())
    naive=defaultdict(F)
    for e in nu:
        for v in nu:
            if K[e,v]:
                naive[v]+=reference[e,v]/(1-bad[e])
    tv=ss(abs(naive[v]-nu[v]) for v in nu)/2
    for v in nu:
        assert ss(final.get((e,v),0) for e in nu)==nu[v]
        assert ss(final.get((v,e),0) for e in nu)==nu[v]
    assert all(final[e,v]==final[v,e] for e,v in final)
    return final,{"epsilon":epsilon,"minimum_bad_row":min(bad.values()),"total_bad":total_bad,
                  "minimum_switch_normalizer":min(normalizers),
                  "maximum_withdrawal_fraction":stats(used),
                  "naive_column_TV":stats(tv),"naive_column_drift_nonzero":tv>0}


def certify():
    keys,A,C,E,m,I,s,K,d,down,peaks,Q=core_geometry()
    prices=[(F(-3,4),F(-1,2)),(F(-1,4),F(0)),(F(1,4),F(1,2)),(F(1),F(5,4))]
    price_mass=list(map(mu,prices))
    assert price_mass==[F(1,4)]*len(prices)
    assert mu((F(-3,4),F(-5,8)))==F(1,16)
    guard={
        (0,0):F(1),(0,1):F(3,4),(1,0):F(3,4),(1,1):F(1),
        (2,0):F(3,10),(2,2):F(9,20),(0,3):F(1,2),(3,1):F(1,2)
    }
    H=[ss(I[e]/m[e] for e in keys if contains(C[e],P)) for P in prices]
    beta=[ss(I[e]*I[v]/(m[e]*m[v]) for e,v in product(keys,repeat=2)
             if contains(C[e],P) and contains(C[v],P) and not K[e,v])/H[r]**2
          for r,P in enumerate(prices)]
    b=F(1,8)
    assert max(beta[:3])<b<beta[3]
    untrimmed={}
    for (u,e,g),mass in peaks.items():
        for (r,t),w in guard.items():
            P,Qprice=prices[r],prices[t]
            first=mu(inter(C[u],C[e],P))
            second=mu(inter(C[e],C[g],Qprice))
            if not first or not second:
                continue
            factor=w*F(8+((e+2*r+t)%4),12)
            assert 0<factor<=1
            amount=mass*first*second*factor/(s[e,u]*s[e,g])
            assert amount==I[u]*I[e]*I[g]*first*second*factor/(d[e]*m[e]**2*m[u]*m[g])
            untrimmed[u,e,g,r,t]=amount
    assert 0<ss(untrimmed.values())<Q

    def side(record,j):
        return record[3+j]

    def reduced(data,removed):
        return {rec:w for rec,w in data.items() if all((j,side(rec,j)) not in removed for j in (0,1))}

    def vertex_masses(data):
        masses=defaultdict(F)
        for rec,w in data.items():
            for j in (0,1):
                masses[j,side(rec,j)]+=w
        return masses

    dead_bad={(j,r) for (j,r) in vertex_masses(untrimmed) if beta[r]>b}
    active=reduced(untrimmed,dead_bad)
    assert dead_bad=={(0,3),(1,3)}
    lost_bad=ss(untrimmed.values())-ss(active.values())
    pure_density=ss(I[u]*I[e]*I[g]/(d[e]*m[e]**2*m[u]*m[g]) for u,e,g in peaks)
    c=pure_density*price_mass[0]/(2*H[0]**2)
    rounds=[]
    while True:
        degrees=vertex_masses(active)
        dead={v for v,w in degrees.items() if w/price_mass[v[1]]<c*H[v[1]]**2}
        if not dead:
            break
        next_active=reduced(active,dead)
        old=ss(active.values())
        new=ss(next_active.values())
        budget=ss(c*H[v[1]]**2*price_mass[v[1]] for v in dead)
        assert 0<old-new<=ss(degrees[v] for v in dead)<budget
        rounds.append({"vertices":sorted(dead),"lost":old-new,"threshold_charge":budget,
                       "density_over_H2_before":{str(v):degrees[v]/price_mass[v[1]]/H[v[1]]**2 for v in sorted(dead)}})
        active=next_active
    assert [r["vertices"] for r in rounds]==[[(1,2)],[(0,2)]]
    core=ss(active.values())
    assert core and core+lost_bad+ss(z["lost"] for z in rounds)==ss(untrimmed.values())

    by_vertex=vertex_masses(active)
    conditional=defaultdict(lambda:defaultdict(F))
    for rec,w in active.items():
        for j in (0,1):
            conditional[j,side(rec,j)][rec[1]]+=w
    nu={a:{e:w/by_vertex[a] for e,w in sorted(hist.items())} for a,hist in conditional.items()}
    assert len(nu)==4 and all(sum(law.values())==1 for law in nu.values())
    different=ss(abs(nu[0,0][e]-nu[1,0][e]) for e in nu[0,0])/2
    assert different>0
    couples={}
    switch_stats=[]
    for key in sorted(nu):
        coup,test=switch(nu[key],K)
        couples[key]=coup
        switch_stats.append({"vertex":key,**test})
    assert all(s["naive_column_drift_nonzero"] for s in switch_stats)

    # Tracking subcells uses the true within-cell price law. The shared coordinate is
    # carried exactly; the other coordinate and marks are drawn from the new record.
    portions={}
    for i,box in enumerate(prices):
        a0,b0=box
        z=(a0+b0)/2
        portions[i]=mu((a0,z))/mu(box),mu((z,b0))/mu(box)
        assert portions[i]==(F(1,4),F(3,4))
    refined={(*rec,i,j):w*portions[rec[3]][i]*portions[rec[4]][j]
             for rec,w in active.items() for i,j in product(range(2),repeat=2)}
    assert ss(refined.values())==core

    def fibre(rec,j):
        return side(rec,j),rec[5+j],rec[1]

    def totals_by_group(data,j):
        groups=defaultdict(F)
        for rec,w in data.items():
            groups[fibre(rec,j)]+=w
        return groups

    original_groups={j:totals_by_group(refined,j) for j in (0,1)}

    def step(incoming,j):
        by_source=totals_by_group(incoming,j)
        moved=defaultdict(F)
        for (cell,subcell,e),w in by_source.items():
            group=nu[j,cell]
            for v in group:
                replacement=couples[j,cell].get((e,v),F(0))
                if replacement:
                    assert K[e,v]>0
                    moved[cell,subcell,v]+=w*replacement/group[e]
        return {rec:w*moved[fibre(rec,j)]/original_groups[j][fibre(rec,j)] for rec,w in refined.items()}

    comparisons=[]
    for length in (2,3,6):
        incoming=refined
        for ell in range(length):
            j=1-ell%2
            incoming=step(incoming,j)
            assert incoming==refined
        # Independently aggregate the original unrefined record after the restored price split.
        old=defaultdict(F)
        for rec,w in incoming.items():
            old[rec[:5]]+=w
        assert old==active
        comparisons.append({"switches":length,"whole_original_records":len(old),
                            "same_true_price_subcell_records":len(incoming),"mass":ss(incoming.values())})

    # A genuine right merge and its projection onto u -> e -> v -> u'.
    vertex=(1,0)
    u,e,g,i,j=next(iter(active))
    assert j==0
    v=next(v for v in nu[vertex] if K[e,v])
    u2,_,g2,i2,_=next(rec for rec in active if rec[1]==v and rec[4]==j and rec[3]!=i)
    left=ss(w for rec,w in active.items() if rec[0]==u and rec[1]==e and rec[3:]==(i,j))
    right=ss(w for rec,w in active.items() if rec[0]==u2 and rec[1]==v and rec[3:]==(i2,j))
    M=by_vertex[vertex]
    three_jump_synthetic=M*couples[vertex][e,v]*left/(M*nu[vertex][e])*right/(M*nu[vertex][v])
    true_word = (I[u]*I[e]*K[u,e])*(I[v]*K[e,v]/d[e])*(I[u2]*K[v,u2]/d[v])
    three_jump_original=true_word*price_mass[i]*price_mass[j]*price_mass[i2]/(s[e,u]*s[e,v]*s[v,u2])
    density_direct=I[u]*I[e]*I[v]*I[u2]/(m[u]*m[e]**2*m[v]**2*m[u2]*d[e]*d[v])
    three_jump_by_density=density_direct*price_mass[i]*price_mass[j]*price_mass[i2]
    assert three_jump_original==three_jump_by_density>0 and three_jump_synthetic>0
    expanded_three_jump=ss(a*couples[vertex][e,v]/nu[vertex][e]*b/(M*nu[vertex][v])
                           for r,a in active.items() if r[0]==u and r[1]==e and r[3:]==(i,j)
                           for t,b in active.items() if t[0]==u2 and t[1]==v and t[3:]==(i2,j))
    three_jump_ratio=three_jump_synthetic/three_jump_original
    assert expanded_three_jump/three_jump_by_density==three_jump_ratio
    three_jump_report={"projected_histories":[u,e,v,u2],"private_indices_and_shared":[i,j,i2],
                       "true_K_degree_three_jump_mass":three_jump_original,
                       "switched_marked_projection_mass":stats(three_jump_synthetic),
                       "switched_over_original_three_jump":stats(three_jump_ratio)}
    # Project three or more links without replacing the genuine degree normalizers.
    longer=[]
    for length in (2,3,6):
        marks=tuple(0 if k%2==0 else 2 for k in range(length+1))
        sides=tuple(1-k%2 for k in range(length))
        e0,last=marks[0],marks[-1]
        ends=(16,17)
        options=[]
        for j,e_j in enumerate(marks):
            row=[w for rec,w in active.items() if rec[1]==e_j and rec[3:]==(0,1)
                 and (j!=0 or rec[0]==ends[0])
                 and (j!=length or rec[(0,2)[1-sides[-1]]]==ends[1])]
            assert row and all(row)
            options.append(row)
        factors=[]
        for a,v,j in zip(marks,marks[1:],sides):
            vertex=(j,j)
            factors.append(couples[vertex][a,v]/(nu[vertex][a]*by_vertex[vertex]*nu[vertex][v]))
        factor=F(1)
        for w in factors:
            factor*=w
        grouped=factor
        for row in options:
            grouped*=ss(row)
        if length<=3:
            expanded=F(0)
            for word in product(*options):
                term=factor
                for w in word:
                    term*=w
                expanded+=term
            assert grouped==expanded
        old_marked=I[ends[0]]*I[e0]*K[ends[0],e0]*price_mass[0]/s[ends[0],e0]
        for a,v,j in zip(marks,marks[1:],sides):
            old_marked*=I[v]*K[a,v]*price_mass[j]/(d[a]*s[a,v])
        old_marked*=I[ends[1]]*K[last,ends[1]]*price_mass[1-sides[-1]]/(d[last]*s[last,ends[1]])
        assert min(grouped,old_marked)>0
        longer.append({"switches":length,"old_marked_chain":old_marked,"projected_over_old":stats(grouped/old_marked),
                       "record_expansion_checked":length<=3})
    # A genuine subflow of the core with the theoretical pruning-gap ratio.
    one_square = {rec:w for rec,w in active.items() if rec[3:]==(0,0)}
    middle_totals = {e:ss(w for rec,w in one_square.items() if rec[1]==e) for e in nu[0,0]}
    equal_mass = min(middle_totals.values())
    keep = {e:equal_mass/w for e,w in middle_totals.items()}
    aux = {rec:w*keep[rec[1]] for rec,w in one_square.items()}
    assert all(0<aux[rec]<=active[rec] for rec in aux)
    aux_masses = {e:ss(w for rec,w in aux.items() if rec[1]==e) for e in middle_totals}
    assert set(aux_masses.values())=={equal_mass}
    denom = price_mass[0]
    density = {e:w/denom for e,w in aux_masses.items()}
    total_density = ss(density.values())
    bad_density = {e:ss(density[v] for v in density if not K[e,v]) for e in density}
    aux_b = max(bad_density.values())/H[0]**2
    aux_c = total_density/H[0]**2
    assert aux_b/aux_c == F(1,8)
    assert all(bad_density[e]<=aux_b*H[0]**2 for e in density)
    assert total_density>=aux_c*H[0]**2
    common_nu = {e:r/total_density for e,r in density.items()}
    aux_coupling,aux_switch = switch(common_nu,K)
    aux_gamma = max(w/(common_nu[e]*common_nu[v]) for (e,v),w in aux_coupling.items())
    assert aux_gamma<=2

    # The point is chosen from the known current center and known input price half.
    # The other private price and the next center are marginalized afterwards.
    prediction_points = (F(-3,8),F(0),F(3,8))
    permitted = ((F(-5,4),F(-1,4)),(F(-1,2),F(1,2)),(F(1,4),F(5,4)))
    D_regions = {v:permitted[v%len(permitted)] for v in keys}
    assert all(contains(A[v],D_regions[v]) for v in keys)

    def contains_point(box,z):
        return box[0]<=z<=box[1]

    alpha_test = max(ss(K[e,v]*I[v] for v in keys if contains_point(D_regions[v],z))
                     for e,z in product(keys,prediction_points))
    Y = ss(I)
    hit_mass = weight_budget = F(0)
    row_count = 0
    real_example = None
    for e,x_half in product(density,range(2)):
        group_size = aux_masses[e]
        z = prediction_points[(e+x_half)%len(prediction_points)]
        others = {v for v in density if contains_point(D_regions[v],z)}
        moves = {v:aux_coupling.get((e,v),F(0))/common_nu[e] for v in density}
        row_hit = ss(moves[v] for v in others)

        # Expand both original endpoint marks and the independently unknown half of the new price.
        observed = ss(w/group_size*portion*moves[next_rec[1]]*w2/aux_masses[next_rec[1]]
                      for rec,w in aux.items() if rec[1]==e
                      for portion in portions[0]
                      for next_rec,w2 in aux.items() if next_rec[1] in others)
        assert observed==row_hit
        t = ss(I[u]/m[u] for u in down[e] if contains(C[u],prices[0]))
        b0 = density[e]/(I[e]/m[e])
        factor = t/(b0*d[e])
        local_alpha = ss(K[e,v]*I[v] for v in others)
        assert row_hit<=(aux_gamma/aux_c)*local_alpha*factor<=(aux_gamma/aux_c)*alpha_test*factor
        event_mass = group_size*portions[0][x_half]
        hit_mass += event_mass*row_hit
        weight_budget += event_mass*factor
        row_count+=1
        if real_example is None and 0<row_hit<1:
            real_example = {"current_history":e,"known_input_price_half":x_half,
                            "predicted_point":z,"t":t,"b0":b0,"actual_d":d[e],
                            "local_alpha":local_alpha,"true_conditional_hit":stats(row_hit),
                            "row_cap":stats((aux_gamma/aux_c)*alpha_test*factor)}
    assert real_example and weight_budget<=Y
    assert 0<hit_mass<ss(aux.values())
    assert hit_mass<=(aux_gamma/aux_c)*alpha_test*weight_budget<=(aux_gamma/aux_c)*alpha_test*Y
    safe_aux = {"original_core_cell_pair":[0,0],"no_increased_record_weight":True,
                "mass":ss(aux.values()),"scale_range":[min(keep.values()),max(keep.values())],
                "b":aux_b,"c":aux_c,"b_over_c":aux_b/aux_c,
                "initial_actual_record_pruning_mass":F(0),"low_degree_pruning_mass":F(0),
                "transition_gamma_exact_upper_factor":stats(aux_gamma),"hard_switch":aux_switch,
                "predictable_exact_check":{"row_count":row_count,"alpha_test":alpha_test,"Y":Y,
                                           "integrated_raw_payment":stats(hit_mass),
                                           "integrated_row_weight":weight_budget,
                                           "total_bound_using_Y":stats((aux_gamma/aux_c)*alpha_test*Y),
                                           "positive_example":real_example,
                                           "D_v_regions_by_residue":permitted,"candidate_points":prediction_points}}
    # Real source pools. Selection b(e) is made before the unobserved transition.
    pools = ((F(-1,2),F(1,2)),(F(23,8),F(29,8)),(F(-13,4),F(-21,8)))
    pool_mass = tuple(mu(q) for q in pools)
    assert all(pool_mass)
    choices = {e:e%len(pools) for e in density}
    coverage = {(b,v):mu(inter(B,A[v]))/pool_mass[b]
                for b,B in enumerate(pools) for v in keys}
    M = F(2)
    high_group = {v for v in choices if coverage[choices[v],v]>=1/M}
    assert 0<len(high_group)<len(choices)
    original_total = ss(aux.values())
    group_flow = defaultdict(F)
    pool_hit = entering = low_to_high = own_incoming = F(0)
    for (e,v),w in aux_coupling.items():
        edge_flow = original_total*w
        b_source,b_target = choices[e],choices[v]
        group_flow[b_source,b_target] += edge_flow
        pool_hit += edge_flow*coverage[b_source,v]
        if v not in high_group:
            continue
        if b_source==b_target:
            assert coverage[b_source,v]>=1/M
            own_incoming += edge_flow
        else:
            entering+=edge_flow
            if e not in high_group:
                low_to_high+=edge_flow
    high_mass=ss(aux_masses[e] for e in high_group)
    assert 0<low_to_high<=entering<high_mass==entering+own_incoming
    assert own_incoming<=M*pool_hit

    pool_breakpoints=sorted({z for box in [*pools,*A] for z in box})
    test_points=set(pool_breakpoints)|{(lo+hi)/2 for lo,hi in zip(pool_breakpoints,pool_breakpoints[1:])}
    pool_alpha=max(ss(K[e,v]*I[v] for v in keys if contains_point(A[v],z))
                   for e,z in product(keys,sorted(test_points))
                   if any(contains_point(B,z) for B in pools))
    own_row_hit = {
        e:ss(w*coverage[choices[e],v]/common_nu[e] for (f,v),w in aux_coupling.items() if f==e)
        for e in choices
    }
    assert pool_hit==ss(aux_masses[e]*w for e,w in own_row_hit.items())
    for e,w in own_row_hit.items():
        t=ss(I[u]/m[u] for u in down[e] if contains(C[u],prices[0]))
        b0=density[e]/(I[e]/m[e])
        assert w<=(aux_gamma/aux_c)*pool_alpha*t/(b0*d[e])
    scaled_pool_bound=M*(aux_gamma/aux_c)*pool_alpha*Y
    assert high_mass<=M*pool_hit+entering<=scaled_pool_bound+entering
    pools_report={"pool_intervals":pools,"true_mu_pool_masses":pool_mass,
                  "M":M,"representative_central_fraction_by_pool":[coverage[b,0] for b in range(len(pools))],
                  "high_own_pool_histories":sorted(high_group),"b_by_history":choices,
                  "classification_transition_flows":{str(key):w for key,w in sorted(group_flow.items())},
                  "stationary_high_own_mass":high_mass,"same_class_incoming":own_incoming,
                  "cross_class_incoming_to_high":entering,"low_to_high_subset":low_to_high,
                  "true_pool_hit_mass":pool_hit,"pool_alpha_test":pool_alpha,
                  "M_C_alpha_Y_over_c_bound":stats(scaled_pool_bound),
                  "scope":"common central A_v; true pool fraction depends on selected source pool, and is constant across possible central successors within that pool"}

    return {"geometry":{"A":A,"C":C,"E":E,"m":m,"I":I,"nonuniform_price":"period 1/4, density 1/2 and then 3/2",
                        "only_one_physical_volume_octave":[4,8],"prices":prices,"K_example":K[0,16],"d_example":d[0],
                        "Q_true_old_full":Q},
            "subflow":{"mass_before_filters":ss(untrimmed.values()),"H_by_price":H,"bad_beta_by_price":beta,
                       "b":b,"c":c,"b_over_c":b/c,"initial_bad_fibres":sorted(dead_bad),"removed_initial_mass":lost_bad,
                       "initial_diagnostic_bad_gate":"whole original h_z tensor h_z fraction; formal per-record gate is checked on the auxiliary true subflow",
                       "low_degree_rounds":rounds,"core_mass":core,"left_right_same_price_TV":different},
            "auxiliary_true_subflow_with_b_over_c_below_one_quarter":safe_aux,
            "actual_source_pools":pools_report,
            "switching":switch_stats,"continuously_shared_price_chain":comparisons,
            "marked_three_jump_check":three_jump_report,
            "longer_marked_chain_checks":longer,
            "scope":"finite true 1D hard graph with continuous within-cell laws; diagnostic cascade and separate exact auxiliary local pruning gap; no upstream high-dimensional masks"}


if __name__=="__main__":
    print(json.dumps({"python":sys.version.split()[0],"arithmetic":"Fraction","command":"python -B switch777.py",
                      "certificate":certify()},sort_keys=True,indent=2,default=str))
