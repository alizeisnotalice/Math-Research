#!/usr/bin/env python3
"""Real source pools and separated receiving intervals in a finite preserved peak flow."""

from fractions import Fraction as F
from itertools import combinations
import hashlib
import json
from pathlib import Path

from switch777 import contains, inter, size, ss, switch


def mu(box):
    lo,hi=inter(box,(F(-6),F(6)))
    if lo>=hi:
        return F(0)

    def primitive(x):
        whole=x//F(1,16)
        rest=x-F(whole,16)
        return F(whole,16)+rest/2+max(F(0),rest-F(1,32))

    return primitive(hi)-primitive(lo)


def calc():
    centers=[F(2*i-15,8) for i in range(16)]+[F(0),F(3,4)]
    mass=[5+F(i,16) for i in range(16)]+[F(4),F(9,2)]
    A=[(c-m/2,c+m/2) for c,m in zip(centers,mass)]
    E=[(c-F(1,256),c+F(1,256)) for c in centers]
    I=[size(b)*(1-F(i%3,12)) for i,b in enumerate(E)]
    assert all(mu(b)==m for b,m in zip(A,mass))
    assert all(contains((c-m/64,c+m/64),j) for c,m,j in zip(centers,mass,E))
    assert all(size(inter(E[i],E[j]))==0 for i,j in combinations(range(18),2))
    assert len(set(A[:16]))==16
    left,right=(F(-1,2),F(-1,4)),(F(1,4),F(1,2))
    assert all(contains(b,left) and contains(b,right) for b in A)
    small1,small2=16,17
    middle=range(16)
    forbidden={(0,1),(2,3),(4,5)}
    K={(i,j):mu(inter(A[i],A[j]))/(mass[i]*mass[j])
       if i!=j and tuple(sorted((i,j))) not in forbidden else F(0)
       for i in range(18) for j in range(18)}
    d=[ss(K[i,j]*I[j] for j in range(18)) for i in range(18)]
    dminus=[ss(K[i,j]*I[j] for j in range(18) if mass[j]<mass[i]) for i in range(18)]
    H=ss(w/m for w,m in zip(I,mass))
    before=[]
    for e in middle:
        peak=I[small1]*I[e]*I[small2]*K[e,small1]*K[e,small2]/d[e]
        raw=peak*mu(left)/mu(inter(A[e],A[small1]))*mu(right)/mu(inter(A[e],A[small2]))
        assert raw==I[small1]*I[e]*I[small2]*mu(left)*mu(right)/(mass[small1]*mass[e]**2*mass[small2]*d[e])
        before.append(raw)
    atom=min(before)
    q=16*atom
    nu={i:F(1,16) for i in middle}
    G,sw=switch(nu,K)
    maxden=max(G[i,j]/(nu[i]*nu[j]) for i,j in G)
    T={(i,j):G.get((i,j),F(0))/nu[i] for i in middle for j in middle}
    c=q/(mu(left)*H**2)
    gamma=max(ss(nu[j] for j in middle if not K[i,j]) for i in middle)
    assert mu(left)==mu(right) and gamma==F(1,8)
    b=c*gamma
    Y=ss(I)
    endpoints=sorted({k for box in A for k in box})
    pts=endpoints+[(x+y)/2 for x,y in zip(endpoints,endpoints[1:])]
    alpha=max(ss(K[i,j]*I[j] for j in range(18) if A[j][0]<=p<=A[j][1])
              for i in range(18) for p in pts)
    assert alpha==max(d)
    global_cap=maxden/c*alpha*Y

    pools=[(F(-4),F(0)),(F(-1),F(3)),(F(1),F(5))]
    colors=[i//6 for i in middle]
    hits={(k,j):mu(inter(pool,A[j]))/mu(pool) for k,pool in enumerate(pools) for j in middle}
    assert all(len(set(hits[k,j] for j in middle))>=4 for k in range(len(pools)))
    pooled=[]
    for M in (F(10,9),F(4,3),F(2)):
        target={j for j in middle if hits[colors[j],j]>=1/M}
        threshold_mass=q*ss(nu[j] for j in target)
        incoming=q*ss(w for (i,j),w in G.items() if j in target and colors[i]!=colors[j])
        same=q*ss(w for (i,j),w in G.items() if j in target and colors[i]==colors[j])
        predictive=q*ss(w*hits[colors[i],j] for (i,j),w in G.items())
        same_predicted=q*ss(w*hits[colors[i],j] for (i,j),w in G.items()
                            if j in target and colors[i]==colors[j])
        assert threshold_mass==same+incoming and same<=M*same_predicted
        assert same_predicted<=predictive<=global_cap
        own=q*ss(nu[i]*hits[colors[i],i] for i in middle)
        penalty=q*ss(w*(1-mu(inter(pools[colors[i]],pools[colors[j]]))/
                         max(mu(pools[colors[i]]),mu(pools[colors[j]]))) for (i,j),w in G.items())
        assert own<=predictive+penalty
        pooled.append({"M":M,"qualifying_middle_parents":len(target),"own_covered":threshold_mass,
                       "cross_group_into_covered":incoming,"same_group_into_covered":same,
                       "predictable_actual_source_mass":predictive,"within_group_predictable_mass":same_predicted,
                       "soft_loss_total_variation":penalty,"own_normalized_pool_incidence":own})
    assert any(0<z["qualifying_middle_parents"]<16 for z in pooled)

    flows={(i,j):F(i==j) for i in middle for j in middle}
    coarse=[(F(k),F(k+1)) for k in range(-3,3)]
    probes={(j,k):size(inter(E[j],B))/size(E[j]) for j in middle for k,B in enumerate(coarse)}
    assert all(ss(probes[j,k] for k in range(len(coarse)))==1 for j in middle)
    lags=[]
    for k in range(1,13):
        flows={(i,j):ss(flows[i,f]*T[f,j] for f in middle) for i in middle for j in middle}
        assert all(ss(nu[i]*flows[i,j] for i in middle)==nu[j] for j in middle)
        if k not in (1,2,5,12):
            continue
        law={(i,g):ss(flows[i,j]*probes[j,g] for j in middle) for i in middle for g in range(len(coarse))}
        pair=q*ss(nu[i]*law[i,g]**2 for i in middle for g in range(len(coarse)))
        pair_by_end=q*ss(nu[i]*flows[i,j]*flows[i,v]*size(inter(E[j],B))/size(E[j])*
                         size(inter(E[v],B))/size(E[v])
                         for i in middle for j in middle for v in middle for B in coarse
                         if size(inter(E[j],B)) and size(inter(E[v],B)))
        top=q*ss(nu[i]*max(law[i,g] for g in range(len(coarse))) for i in middle)
        assert 0<pair==pair_by_end<=top<q and top<=global_cap
        lags.append({"lag":k,"common_start_receiver_collision":pair,"best_one_cell":top,
                     "fraction_collision":round(float(pair/q),10),"comparison_cap":global_cap})

    # Two far copies of the original peak. The extra source stays outside every parent.
    # The true left price is in left. In copy two a near exterior mass is seen by both pools.
    # Another exterior mass is seen by the local price window only for some central radii.
    added=[((F(31,4),F(8)),F(80)),((F(33,2),F(67,4)),F(160))]
    def local_source(box, copy):
        return mu(box)+(ss(w*size(inter(box,pos))/size(pos) for pos,w in added) if copy else F(0))
    assert all(local_source(box,1)==m for box,m in zip(A,mass))
    csmall=centers[small1]
    Bpredict=(csmall-5*mass[small1]/2,csmall+5*mass[small1]/2)
    output=[]
    for copy in (0,1):
        pred=local_source(Bpredict,copy)
        bounds=[]
        for e in middle:
            s=mass[e]/2
            minimum=(left[1]-6*s,left[0]+6*s)
            maximum=(left[0]-6*s,left[1]+6*s)
            assert contains(minimum,Bpredict) and contains(Bpredict,A[e])
            lower=mass[e]/local_source(maximum,copy)
            upper=mass[e]/local_source(minimum,copy)
            assert 0<lower<=upper<=mass[e]/pred
            bounds.append((lower,upper))
        output.append({"copy":copy,"center_source_pool_mass":pred,
                       "lower_weighted_local_score":ss(atom*z[0] for z in bounds),
                       "upper_weighted_local_score":ss(atom*z[1] for z in bounds),
                       "predictive_source_integral":ss(atom*mass[e]/pred for e in middle),
                       "certain_at_least_one_tenth":sum(lo>=F(1,10) for lo,hi in bounds),
                       "certain_below_one_tenth":sum(hi<F(1,10) for lo,hi in bounds)})
    assert output[0]["certain_at_least_one_tenth"]==16
    assert output[1]["certain_below_one_tenth"]==16
    return {"middle_parents":16,"original_parent_volumes":mass,"actual_disjoint_owner_labels":len(E),
            "price_cells":[left,right],"mu_left":mu(left),"mu_right":mu(right),"H":H,
            "unthinned_marked_mass":ss(before),"preserved_mass":q,"thinning_range":[min(atom/x for x in before),F(1)],
            "b":b,"c":c,"b_over_c":b/c,"alpha_test_for_actual_parents":alpha,"Y":Y,
            "geometric_pool_checks":pooled,"truly_disjoint_owner_samples":lags,"local_mass_checks":output,
            "scope":"One physical octave, actual source, actual disjoint owners, synthetic eligible graph; translated local copies may be placed at 0 and 100."}


if __name__=="__main__":
    res=calc()
    print(json.dumps({"arithmetic":"Fraction; rounded collision fractions for reading only",
                      "model_script_sha256":hashlib.sha256(Path(__file__).with_name("switch777.py").read_bytes()).hexdigest(),
                      "results":res},indent=2,sort_keys=True,default=str))
