"""Artifact and fixed-evidence checks, not a proof of the global operator bound."""
from pathlib import Path
from fractions import Fraction as Q
import hashlib,json,math,argparse
D=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--selection',type=Path,default=D/'selection.json');a=p.parse_args()
read=lambda n:json.loads((D/n).read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest=read('MANIFEST.json')
assert set(manifest)=={p.name for p in D.iterdir() if p.is_file() and p.name not in ('MANIFEST.json','selection.json')}
for name,v in manifest.items():assert sha(D/name)==v['sha256'] and (D/name).stat().st_size==v['bytes'],name
assert sha(a.selection)==read('INPUTS.json')['selection']['sha256']
src=json.loads(a.selection.read_text());m=read('masks.json');assert m['input_sha256']==sha(a.selection)
for result,script in [('masks.json','masks.py'),('gain_probe.json','gain_probe.py'),('cert.json','subset_cert.py'),('symbolic.json','symbolic.py')]:assert read(result)['script_sha256']==sha(D/script)
assert len(m['results'])==12 and all(r['status']=='complete' for r in m['results'])
records={(r['n'],r['seed'],tuple(r['tau'])):r for r in m['results']}
for r in m['results']:
 old=next(x for x in src['results'] if x['N']==4096 and (x['n'],x['seed'],tuple(x['tau']))==(r['n'],r['seed'],tuple(r['tau'])))
 pos=[x for x in old['selected_records'] if x[-1]>0];V=pos[-16:][::-1];assert V==r['witnesses_last_first']
 hist={};den=r['prefix_common_denominator'];n=r['n']
 for x in pos[:-16]:
  mask=sum(1<<k for k,y in enumerate(V) if all(3*abs(x[d]-y[d])<32*x[0] for d in range(1,n+1)))
  hist[mask]=hist.get(mask,0)+x[-1]*(den//((16*x[0])**n))
 assert sorted(hist.items())==[tuple(z) for z in r['prefix_capturemask_histogram']]
 assert r['stages']['16']['best_mask']==r['stages']['20']['best_mask']
 for exp,st in r['stages'].items():
  assert int(exp) in (16,20) and st['best_mask']&1
  code=st['best_mask']; op=sum(v*max((mask&code).bit_count()-1,0) for mask,v in hist.items())
  assert Q(op,den)==Q(*st['O_prefix_exact'])
  assert st['per_scramble_best_masks']==[code,code]
  for snap in st['scrambles']:
   for key in ('inner_mask_counts','shell_mask_counts'):
    assert sum(v for _,v in snap[key])==1<<int(exp)
    assert all(0<=mask<65536 and v>0 for mask,v in snap[key])
g=read('gain_probe.json');assert g['status']=='complete' and len(g['cases'])==48
assert g['input_sha256']==sha(D/'masks.json')
for r in g['cases']:
 w=r['optional_weights'];tau=float(Q(*r['tau']))
 DD=sum(v*(b+c-tau) for v,b,c in zip(w,r['b_k'],r['B_k']))
 CC=sum(w[i-1]*w[j-1]*b for i,j,b in r['b_kl_upper'])
 assert math.isclose(DD,r['D'],rel_tol=1e-11,abs_tol=1e-12)
 assert math.isclose(CC,r['C'],rel_tol=1e-11,abs_tol=1e-12)
 assert 0<r['J_quadratic']<=r['gain_with_Q']+1e-10<=r['actual_subset_gain']+2e-10
cert=read('cert.json');assert cert['input_sha256']==sha(a.selection) and cert['masks_sha256']==sha(D/'masks.json')
q=lambda k:Q(*map(int,cert[k]))
assert cert['mask']==1537 and cert['indices_last_first']==[0,9,10] and cert['s']=='1'
assert q('U1_lower')>Q(236,100) and q('U3_upper')<Q(2109,1000)
assert q('U3_minus_U1_upper')<Q(-254,1000)
assert q('U3_upper')-q('U1_lower')==q('U3_minus_U1_upper')
s=read('symbolic.json');assert s['enumerated_states']==16 and s['union_residual']=='0' and s['repeat_credit_residual']=='0'
print('PASS: static manifest, reused R616 input, actual capture histograms, sampled gain arithmetic, and fixed strict certificate. General root-order payment remains unproved.')
