import os
for name in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[name]='1'
import argparse,concurrent.futures,hashlib,json,math,platform,resource,shlex,sys,time
from fractions import Fraction as Q
from math import lcm
from pathlib import Path
import numpy as np,scipy
from scipy.stats import qmc

BITS=16; SIZE=1<<BITS; FULL=SIZE-1; BATCH=1<<14; A=8; T=3.; C=29/27; STAGES=(16,20)
def sparse(a):
 ids=np.flatnonzero(a); return [[int(i),int(a[i])] for i in ids]
def zeta(h):
 a=h.copy()
 for k in range(BITS):
  a=a.reshape(-1,2,1<<k); a[:,1,:]+=a[:,0,:]; a=a.reshape(-1)
 return a
def capture(y,z,R): return all(3*abs(int(a)-int(b)) < 32*R for a,b in zip(y,z))
def rat(z):return Q(z[0],z[1])
def jr(q):return [q.numerator,q.denominator]
def worker(rec):
 started=time.monotonic(); cpu=time.process_time(); n=rec['n']; tau=rat(rec['tau'])
 pos=[x for x in rec['selected_records'] if x[-1]>0]; assert len(pos)>=16
 prefix=pos[:-16]; V=pos[-16:][::-1]; r0=V[0][0]; assert all(x[0]>=r0 for x in V)
 s=max(z[0] for z in V)/r0; u=np.array([np.array(z[1:-1],dtype=float)/(9*r0) for z in V]); den=lcm(*[(16*R)**n for R in (8,6,4)])
 hist=np.zeros(SIZE,dtype=np.int64)
 for z in prefix:
  mask=sum(1<<k for k,w in enumerate(V) if capture(w[1:-1],z[1:-1],z[0])); hist[mask]+=z[-1]*(den//(16*z[0])**n)
 wp=int(hist.sum()); prior=[]; load=[]
 for k,w in enumerate(V):
  L=sum(int(hist[i]) for i in np.flatnonzero(hist) if int(i)&(1<<k));load.append(L)
  j=len(pos)-1-k
  prior.append(sum(z[-1]*(den//(16*z[0])**n) for z in pos[:j] if capture(w[1:-1],z[1:-1],z[0])))
  assert Q(prior[-1],den)<=tau
 tail=sum((Q(z[-1],(16*z[0])**n) for z in pos[-16:]),Q(0)); wlast=Q(V[0][-1],(16*V[0][0])**n)
 zpref=zeta(hist); masks=np.arange(SIZE,dtype=np.int64); valid=masks[1::2]; complement=FULL^masks
 uncovered=zpref[complement]; union=wp-uncovered
 loadsum=np.zeros(SIZE,dtype=np.int64); count=np.zeros(SIZE,dtype=np.int8)
 for k in range(BITS):
  ind=(masks&(1<<k))!=0; loadsum[ind]+=load[k]; count[ind]+=1
 op=loadsum-union; assert np.all(op>=0)
 exactbase=np.asarray([float(int(count[i])*tau+tail-Q(int(op[i]),den)) for i in valid]); pf=(9/8)**n
 # Each scramble accumulates 16-bit failure masks in the two positive-measure pieces.
 stages={str(e):[] for e in STAGES}
 for scramble in range(2):
  sob=qmc.Sobol(d=n+2,scramble=True,seed=100000+100*rec['seed']+10*n+scramble)
  hi=np.zeros(SIZE,dtype=np.int64); hs=np.zeros(SIZE,dtype=np.int64); single=np.zeros(2,dtype=np.int64)
  for step in range((1<<20)//BATCH):
   if time.monotonic()-started>150:return {'status':'partial_timeout','n':n,'seed':rec['seed'],'tau':rec['tau'],'scramble':scramble,'blocks':step,'cpu_seconds':time.process_time()-cpu}
   x=sob.random(BATCH); face=np.minimum((x[:,0]*2*n).astype(int),2*n-1); dim=face//2; sign=np.where(face%2,1.,-1.); q=2*x[:,2:2+n]-1
   if s<T:
    zi=s*q; rr=s*np.exp(math.log(T/s)*x[:,1]); zo=rr[:,None]*q; zo[np.arange(BATCH),dim]=sign*rr
    mi=np.zeros(BATCH,dtype=np.uint16); mo=np.zeros(BATCH,dtype=np.uint16)
    for k in range(BITS):
     mi |= (np.max(np.abs(zi-u[k]),axis=1)<C*s).astype(np.uint16)<<k
     mo |= (np.max(np.abs(zo-u[k]),axis=1)<C*rr).astype(np.uint16)<<k
    hi += np.bincount(mi,minlength=SIZE); hs += np.bincount(mo,minlength=SIZE)
   # Original last witness bound uses its own s=1, not the fixed-s model.
   zi1=q; rr1=np.exp(math.log(T)*x[:,1]); zo1=rr1[:,None]*q; zo1[np.arange(BATCH),dim]=sign*rr1
   single += [np.count_nonzero(np.max(np.abs(zi1-u[0]),axis=1)>=C),np.count_nonzero(np.max(np.abs(zo1-u[0]),axis=1)>=C*rr1)]
   npts=(step+1)*BATCH
   if npts in (1<<16,1<<20):
    # Snapshots stored as independent sparse histograms; no signed geometric measure.
    stages[str(int(math.log2(npts)))].append({'inner_mask_counts':sparse(hi),'shell_mask_counts':sparse(hs),'last_single_counts':list(map(int,single))})
 outstage={}
 for exp in STAGES:
  sz=1<<exp; snaps=stages[str(exp)]; arrays=[]; singles=[]
  for snap in snaps:
   a=np.zeros(SIZE,dtype=np.int64);b=np.zeros(SIZE,dtype=np.int64)
   for idx,v in snap['inner_mask_counts']:a[idx]=v
   for idx,v in snap['shell_mask_counts']:b[idx]=v
   H=(zeta(a)[complement[valid]]+n*math.log(T/s)*zeta(b)[complement[valid]])/sz if s<T else np.zeros(len(valid))
   arrays.append(exactbase+pf*H)
   singles.append(float(tau+wlast)+pf*(snap['last_single_counts'][0]+n*math.log(T)*snap['last_single_counts'][1])/sz)
  mean=(arrays[0]+arrays[1])/2; best=int(np.argmin(mean)); code=int(valid[best]); m=int(count[code]); Hs=[]
  for snap in snaps:
   # Recover H from corresponding U and exact constant.
   pass
  Hs=[(float(x[best])-exactbase[best])/pf for x in arrays]
  singleidx=0 # valid masks begin at mandatory-only mask 1
  fixedsingle=[float(x[singleidx]) for x in arrays]
  dif1=[float(arrays[i][best])-fixedsingle[i] for i in range(2)]; diforig=[float(arrays[i][best])-singles[i] for i in range(2)]
  hpre=Q(int(uncovered[code]),den); credit=Q(int(op[code]),den)
  outstage[str(exp)]={'samples_per_scramble':sz,'scrambles':snaps,'best_mask':code,'best_indices_last_first':[k for k in range(BITS) if code&(1<<k)],'m':m,'best_U_replicates':[float(x[best]) for x in arrays],'best_H_replicates':Hs,'R_prefix_exact':jr(hpre),'O_prefix_exact':jr(credit),'m_tau_exact':jr(m*tau),'tail_exact':jr(tail),'fixed_prefix_single_U_replicates':fixedsingle,'original_last_single_U_replicates':singles,'delta_fixed_prefix_replicates':dif1,'delta_original_single_replicates':diforig,'delta_fixed_mean':sum(dif1)/2,'delta_fixed_se_two_scrambles':abs(dif1[0]-dif1[1])/2,'delta_original_mean':sum(diforig)/2,'per_scramble_best_masks':[int(valid[np.argmin(x)]) for x in arrays]}
 return {'status':'complete','n':n,'N':rec['N'],'seed':rec['seed'],'tau':rec['tau'],'selected_sha256':rec['selected_sha256'],'s':s,'r0_quarter_units':r0,'witnesses_last_first':V,'prefix_positive_count':len(prefix),'prefix_common_denominator':den,'prefix_weight_numerator':wp,'prefix_capturemask_histogram':sparse(hist),'prefix_load_numerators':load,'prior_load_numerators':prior,'delta_prefix_exact':[jr(tau-Q(x,den)) for x in load],'tail_exact':jr(tail),'last_weight_exact':jr(wlast),'stages':outstage,'elapsed_seconds':time.monotonic()-started,'cpu_seconds':time.process_time()-cpu,'peak_rss_bytes_macos':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}

def main():
 parser=argparse.ArgumentParser();parser.add_argument('--input',type=Path,default=Path(__file__).resolve().parent/'selection.json');parser.add_argument('--output-dir',type=Path,default=Path(__file__).resolve().parent);parser.add_argument('--workers',type=int,default=12); args=parser.parse_args(); assert 1<=args.workers<=12
 args.output_dir.mkdir(parents=True,exist_ok=True); outpath=args.output_dir/'ccu_r617_masks.json'; mdpath=args.output_dir/'ccu_r617_masks.md'
 inp=json.loads(args.input.read_text()); profiles=[r for r in inp['results'] if r['N']==4096 and r['status']=='complete'];assert len(profiles)==12
 out={'input':str(args.input),'input_sha256':hashlib.sha256(args.input.read_bytes()).hexdigest(),'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'command':shlex.join([sys.executable]+sys.argv),'python':sys.version,'numpy':np.__version__,'scipy':scipy.__version__,'platform':platform.platform(),'workers':args.workers,'BLAS_threads':1,'qmc':'2 scrambled Sobol replicates, nested 2^16 and 2^20, batch=2^14','geometry':'fixed r0 and s for all masks; histograms are violations of intersection; inner weight 1, shell weight n log(t/s)','scope':'finite sampled optimization; not certified; optimizer and evaluation use same samples','results':[]}
 start=time.monotonic()
 def save():
  out['elapsed_seconds']=time.monotonic()-start;out['cpu_sum_seconds']=sum(r.get('cpu_seconds',0) for r in out['results']);outpath.write_text(json.dumps(out,separators=(',',':')))
  lines=['# R617: actual witness-mask optimization','',f"Input SHA256 `{out['input_sha256']}`; script SHA256 `{out['script_sha256']}`.",f"Command `{out['command']}`; workers {args.workers}, BLAS1; elapsed {out['elapsed_seconds']:.3f} s; summed worker CPU {out['cpu_sum_seconds']:.3f} s.",'','Fixed prefix and tail are taken before the earliest of the last 16 witnesses; last witness is mandatory. All subsets use the same r0 and s=max r/r0. The fixed-prefix single baseline uses that same s and tail; the original single baseline uses only the last witness, its own s=1, and last weight as tail. Numerical estimates use two nested scrambled Sobol sequences and reuse samples to optimize; no certification or out-of-sample claim.','','| n | tau | seed | s | m | selected mask | U_opt − fixed single | paired SE | U_opt − original single |','|---:|---:|---:|---:|---:|---:|---:|---:|---:|']
  for r in sorted(out['results'],key=lambda r:(r['n'],r['seed'],r['tau'])):
   if r['status']!='complete': lines.append(f"\nPartial {r}");continue
   d=r['stages']['20'];lines.append('| %d | %d/%d | %d | %.4g | %d | %d | %.8g | %.3g | %.8g |'%(r['n'],*r['tau'],r['seed'],r['s'],d['m'],d['best_mask'],d['delta_fixed_mean'],d['delta_fixed_se_two_scrambles'],d['delta_original_mean']))
  lines+=['','Actual prefix and geometry histograms are retained independently in JSON; the data do not define a positive difference measure. Floating-point minima are estimates, not a proof of optimality for the continuous integrals or an operator bound.']
  mdpath.write_text('\n'.join(lines)+'\n')
 with concurrent.futures.ProcessPoolExecutor(max_workers=args.workers) as pool:
  futures=[pool.submit(worker,r) for r in profiles]
  try:
   for f in concurrent.futures.as_completed(futures,timeout=175):
    try:out['results'].append(f.result())
    except Exception as e:out['results'].append({'status':'error','error':repr(e)})
    save();print('completed',len(out['results']),out['results'][-1]['status'],flush=True)
  except concurrent.futures.TimeoutError:
   out['timeout']=True;save()
 save()
if __name__=='__main__':main()
