import argparse,json,hashlib,sys,time,platform,resource
from fractions import Fraction as Q
from pathlib import Path
from itertools import product
start=time.perf_counter(); cpu=time.process_time()
p=argparse.ArgumentParser(); base=Path(__file__).resolve().parent
p.add_argument('--input',type=Path,default=base/'selection.json');p.add_argument('--masks',type=Path,default=base/'masks.json');p.add_argument('--output',type=Path,default=base/'cert.json');a=p.parse_args()
hashfile=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
d=json.loads(a.input.read_text()); maskdata=json.loads(a.masks.read_text()); assert hashfile(a.input)==maskdata['input_sha256']
r=[x for x in d['results'] if x['n']==2 and x['N']==4096 and x['seed']==1002 and x['tau']==[1,1]];assert len(r)==1
pos=[(i,x) for i,x in enumerate(r[0]['selected_records']) if x[-1]>0]; prefix=pos[:-16]; tail=pos[-16:];w=tail[::-1]; mask=1537; assert mask & 1; chosen=[w[j] for j in range(16) if mask&(1<<j)];assert len(chosen)==3
rr=[x for x in maskdata['results'] if x['n']==2 and x['N']==4096 and x['seed']==1002 and x['tau']==[1,1]];assert len(rr)==1; ref=rr[0]; assert ref['stages']['20']['best_mask']==mask and [x for _,x in w]==ref['witnesses_last_first']
r0=w[0][1][0];assert r0==8 and min(x[0] for _,x in chosen)==r0 and max(x[0] for _,x in chosen)==r0
assert min(x[0] for _,x in w)==r0 and max(x[0] for _,x in w)==r0 and ref['s']==1
assert all(max(abs(v) for v in x[1:3])<8*x[0] for _,x in pos)
def wt(x):return Q(x[-1],(16*x[0])**2)
def capt(x,y):return all(3*abs(x[j]-y[j])<32*x[0] for j in (1,2))
tailfee=sum((wt(x) for _,x in tail),Q()); single_tail=wt(w[0][1]); O=sum((wt(x)*max(sum(capt(x,y) for _,y in chosen)-1,0) for _,x in prefix),Q()); R=sum((wt(x)*max(1-sum(capt(x,y) for _,y in chosen),0) for _,x in prefix),Q())
assert tailfee==Q(*ref['tail_exact']) and single_tail==Q(*ref['last_weight_exact']) and O==Q(*ref['stages']['20']['O_prefix_exact']) and R==Q(*ref['stages']['20']['R_prefix_exact'])
P=Q(9,8)**2
# u=y/72; grid denominator 72*subdiv supports exact integers
pts=[[x[1],x[2]] for _,x in chosen]
def bounds(points,subdiv):
 lower=Q();upper=Q();den=72*subdiv
 for ij in product(range(-3*subdiv,3*subdiv),repeat=2):
  lo=[72*i for i in ij];hi=[v+72 for v in lo];pp=[[v*subdiv for v in p] for p in points]
  amin=[0 if l<=0<=h else min(abs(l),abs(h)) for l,h in zip(lo,hi)];amax=[max(abs(l),abs(h)) for l,h in zip(lo,hi)]; mn=max(den,*amin);mx=max(den,*amax)
  good=all(any(27*(0 if l<=u<=h else min(abs(u-l),abs(u-h)))>=29*mx for l,h,u in zip(lo,hi,p)) for p in pp)
  cap=any(all(27*max(abs(u-l),abs(u-h))<29*mn for l,h,u in zip(lo,hi,p)) for p in pp)
  if good:lower+=Q(den**2,4*subdiv**2*mx**2)
  if not cap:upper+=Q(den**2,4*subdiv**2*mn**2)
 return lower,upper
attempts=[]
for subdiv in (4,8,16):
 L1,V1=bounds([pts[0]],subdiv); L3,V3=bounds(pts,subdiv)
 delta=2+tailfee-single_tail-O+P*(V3-L1)
 attempts.append({'grid_denominator':subdiv,'H1_lower':[str(L1.numerator),str(L1.denominator)],'H3_upper':[str(V3.numerator),str(V3.denominator)],'delta_upper':[str(delta.numerator),str(delta.denominator)]})
 if delta<0:break
assert delta<0
fmt=lambda q:[str(q.numerator),str(q.denominator)]
out={'n':2,'N':4096,'seed':1002,'tau':'1','a':8,'t':3,'c':'29/27','P':'81/64','mask':mask,'indices_last_first':[j for j in range(16) if mask&(1<<j)],'prefix_count':len(prefix),'tail_count':len(tail),'witnesses':[x for _,x in chosen],'r0':r0,'s':'1','grid_denominator':subdiv,'attempts':attempts,'H1_lower':fmt(L1),'H1_upper':fmt(V1),'H3_lower':fmt(L3),'H3_upper':fmt(V3),'tail_fixed':fmt(tailfee),'tail_single':fmt(single_tail),'overlap_prefix':fmt(O),'residual_prefix':fmt(R),'U1_lower':fmt(1+single_tail+P*L1),'U3_upper':fmt(3+tailfee-O+P*V3),'U3_minus_U1_upper':fmt(delta),'input_sha256':hashfile(a.input),'masks_sha256':hashfile(a.masks),'script_sha256':hashfile(Path(__file__)),'command_argv':[sys.executable]+sys.argv,'python':sys.version,'platform':platform.platform(),'wall_seconds':time.perf_counter()-start,'cpu_seconds':time.process_time()-cpu,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'scope':'single fixed postselected subset; selection records assumed; no global optimum or dimension-general claim'}
a.output.write_text(json.dumps(out,indent=2)+'\n')
for k in ['H1_lower','H3_upper','U1_lower','U3_upper','U3_minus_U1_upper']:print(k,float(Q(*map(int,out[k]))))
print('subdiv',subdiv,'O',O,'R',R,'time',out['wall_seconds'],'sha',out['script_sha256'])
