from pathlib import Path
import argparse,json,hashlib,zipfile
D=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--previous',type=Path,required=True);p.add_argument('--output',type=Path,default=D/'selection.json');a=p.parse_args()
i=json.loads((D/'INPUTS.json').read_text())['selection']; sha=lambda b:hashlib.sha256(b).hexdigest()
assert sha(a.previous.read_bytes())==i['archive_sha256'],'Unexpected R616 archive'
with zipfile.ZipFile(a.previous) as z:
 assert z.testzip() is None
 b=z.read(i['member'])
assert sha(b)==i['sha256']
if a.output.exists():assert a.output.read_bytes()==b,'Refusing to replace different input'
else:a.output.write_bytes(b)
print('PASS: materialized exact R616 input without changing its contents')
