import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[k]='1'
import argparse,hashlib,json,math,platform,shlex,sys,time
from fractions import Fraction as F
from pathlib import Path
import numpy as np,scipy
from scipy.optimize import minimize_scalar

def zeta(v):
 a=v.copy()
 for k in range(16): a=a.reshape(-1,2,1<<k); a[:,1,:]+=a[:,0,:]; a=a.reshape(-1)
 return a
def calc(r,stage,rep):
 n=r['n']; s=r['s']; tau=float(F(*r['tau'])); den=r['prefix_common_denominator']; V=r['witnesses_last_first']; w=np.array([v[-1]/(16*v[0])**n for v in V[1:]],float); wm=float(max(w)); assert wm>0
 ph=np.zeros(65536); 
 for m,v in r['prefix_capturemask_histogram']:ph[m]=v/den
 pm=np.flatnonzero(ph); bits=((pm[:,None]>>np.arange(1,16))&1).astype(float); mand=(pm&1)!=0
 B=bits[mand].T@ph[pm[mand]]
 stageinfo=r['stages'][str(stage)]; snap=stageinfo['scrambles'][rep]; gi=np.zeros(65536);gs=np.zeros(65536)
 for m,v in snap['inner_mask_counts']:gi[m]=v
 for m,v in snap['shell_mask_counts']:gs[m]=v
 geom=(9/8)**n*(gi+(n*math.log(3/s)*gs if s<3 else 0))/(1<<stage) if s<3 else gi*0
 gm=np.flatnonzero(geom); gm=gm[(gm&1)==0]; gvec=geom[gm]; incidence=((gm[:,None]>>np.arange(1,16))&1).astype(float)
 bk=incidence.T@gvec; bkl=incidence.T@(incidence*gvec[:,None]); D=float(np.dot(w,bk+B-tau)); C=float((np.dot(w,bkl@w)-np.dot(w*w,np.diag(bkl)))/2); C=max(0.,C)
 limit=1/wm
 theta=0. if D<=0 else min(limit,D/(2*C)) if C>0 else limit
 J=theta*D-theta**2*C
 nbits=bits[~mand]; pweights=ph[pm[~mand]]; d=nbits@w
 def Qextra(z):
  t=z/wm; p=t*w; prod=np.prod(1-nbits*p,axis=1); return float(np.dot(pweights,t*d-1+prod))
 def objective(z):return (z/wm)*D-(z/wm)**2*C+Qextra(z)
 grid=np.linspace(0.,1.,129); values=np.array([objective(z) for z in grid]); cand=[(values[0],0.),(values[-1],1.)]
 for i in range(1,128):
  if values[i]>=values[i-1] and values[i]>=values[i+1]:
   opt=minimize_scalar(lambda z:-objective(z),bounds=(float(grid[i-1]),float(grid[i+1])),method='bounded',options={'xatol':1e-14});cand.append((-float(opt.fun),float(opt.x)))
 gain,z=max(cand)
 # Independently recompute the full subset optimum for this single scramble.
 allm=np.arange(65536,dtype=np.int64); val=allm[1::2]; comp=65535^allm
 uncovered=zeta(ph)[comp]; union=ph.sum()-uncovered
 load=np.array([float(ph[pm[mand]].sum())]+list(bits.T@ph[pm])); weightsum=np.zeros(65536); cnt=np.zeros(65536)
 for k in range(16):
  ind=(allm&(1<<k))!=0;weightsum[ind]+=load[k];cnt[ind]+=1
 overlap=weightsum-union; H=zeta(geom)[comp[val]]; tail=float(F(*r['tail_exact'])); U=cnt[val]*tau+tail+H-overlap[val]
 best=int(np.argmin(U)); single=float(U[0]); actual=single-float(U[best])
 return {'n':n,'tau':r['tau'],'seed':r['seed'],'stage':stage,'replicate':rep,'optional_weights':w.tolist(),'b_k':bk.tolist(),'B_k':B.tolist(),'b_kl_upper':[[i+1,j+1,float(bkl[i,j])] for i in range(15) for j in range(i+1,15)],'D':D,'C':C,'theta_limit':limit,'theta_opt_quadratic':theta,'J_quadratic':J,'z_opt_credit':z,'theta_opt_credit':z/wm,'Q_at_opt':Qextra(z),'gain_with_Q':gain,'grid_points':129,'actual_subset_best_mask':int(val[best]),'actual_subset_gain':actual,'actual_single_U':single,'actual_best_U':float(U[best]),'quadratic_fraction_of_actual':J/actual if actual>0 else None,'credit_fraction_of_actual':gain/actual if actual>0 else None}
def main():
 p=argparse.ArgumentParser();p.add_argument('--input',type=Path,default=Path(__file__).parent/'ccu_r617_masks.json');p.add_argument('--output-dir',type=Path,default=Path(__file__).parent);a=p.parse_args();a.output_dir.mkdir(parents=True,exist_ok=True)
 obj=json.loads(a.input.read_text()); records=[]; start=time.monotonic()
 for r in obj['results']:
  assert r['status']=='complete'
  for st in (16,20):
   for rep in (0,1):
    if time.monotonic()-start>27:break
    records.append(calc(r,st,rep))
 out={'input_sha256':hashlib.sha256(a.input.read_bytes()).hexdigest(),'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'command':shlex.join([sys.executable]+sys.argv),'python':sys.version,'numpy':np.__version__,'scipy':scipy.__version__,'elapsed_seconds':time.monotonic()-start,'cases':records,'status':'complete' if len(records)==48 else 'partial_timeout','scope':'numeric probe, two scrambled histograms per stage; no new sampling; not a certificate'}
 (a.output_dir/'ccu_r617_gain_probe.json').write_text(json.dumps(out,separators=(',',':')))
 lines=['# R617 second-order gain diagnostic','',f"Command `{out['command']}`; input SHA256 `{out['input_sha256']}`; source SHA256 `{out['script_sha256']}`; elapsed {out['elapsed_seconds']:.3f}s.",'','No new samples: the separate positive geometry and exact prefix histograms are used directly. All values are floating-point evidence; two scrambles do not constitute certification. Actual subset gain is recomputed against the same fixed-prefix single baseline, separately for each retained sample.','','| n | tau | seed | replicate | D | C | J | J+Q max | actual subset gain |','|---:|---:|---:|---:|---:|---:|---:|---:|---:|']
 for r in sorted(records,key=lambda t:(t['n'],t['seed'],t['tau'],t['stage'],t['replicate'])):
  if r['stage']==20:lines.append('| %d | %d/%d | %d | %d | %.8g | %.8g | %.8g | %.8g | %.8g |'%(r['n'],*r['tau'],r['seed'],r['replicate'],r['D'],r['C'],r['J_quadratic'],r['gain_with_Q'],r['actual_subset_gain']))
 lines+=['','Q is separately preserved additional prefix overlap credit. Its displayed maximum uses a 129-point grid and bounded refinement of detected local maxima; it is not a rigorous global optimization certificate. The JSON also records both stages, all b_k, B_k and b_kl values and maximizing parameters.']
 (a.output_dir/'ccu_r617_gain_probe.md').write_text('\n'.join(lines)+'\n');print(out['status'],len(records),'elapsed',out['elapsed_seconds'])
if __name__=='__main__':main()
