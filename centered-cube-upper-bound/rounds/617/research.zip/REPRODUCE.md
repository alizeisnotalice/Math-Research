# 第617轮复现与范围

REPORT.tex 是详细LaTeX报告，不编译PDF。AUDIT.md包括先独立合同审查、再核计算与最终理论/证书的记录。一般根阶目标仍未闭合；新一般结果是有明确费用的充分减量引理，不是所有输入均有足够减量的结论。

## 先取上一轮的必要输入

本轮不重复打包已在第616轮保存的selection.json。必须同时取得仓库中的 `rounds/616/research.zip`；INPUTS.json绑定该包和其中输入的SHA-256。解压本轮到仓库外目录，例如 `/tmp/r617` 后运行：

```sh
python materialize_input.py --previous /绝对路径/centered-cube-upper-bound/rounds/616/research.zip
python verify.py
```

materialize_input只读取前包；若输出已存在且内容不同会拒绝覆盖。不修改前轮档案。当前目录会多出一个生成的selection.json，verify将其视为明确外部依赖，不加入本轮MANIFEST或ZIP。

实际数学解释器是 `/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python`。Python3.12.14、NumPy2.5.4、SciPy1.18.1、SymPy1.14.0的具体运行记录见各JSON。

## 重放入口

```sh
python masks.py --input selection.json --output-dir /tmp/r617-mask-replay --workers 12
python gain_probe.py --input masks.json --output-dir /tmp/r617-gain-replay
python subset_cert.py --input selection.json --masks masks.json --output /tmp/r617-cert-replay.json
python symbolic.py --output /tmp/r617-symbolic-replay.json
```

masks输出名为ccu_r617_masks.json/md，最多12进程，每个BLAS1线程；这次实际12case均完成。单任务150秒保护/收集175秒超时不等于进程强杀截止，必须检查complete。输入几何、尾项、共同r0/s在所有子集相同，所有奇数mask恰为2^15个含末见证的子集。保存的稀疏capture histograms足以重算全部 sampled objective。只用正几何和实际体积权分别记账，不把它们的逐mask差当正测度。

gain_probe读取旧hist而不重新抽样。48组是12实际profile×2个嵌套stage×2个scramble，不是48个独立新输入。含P的几何积分、实际B_k信用与全部费用分别组合。Q信用优化采用129点网格并细化检测到的局部极大值，只有浮点探索意义。探针所显示J/Gain比例不是严格积分比。

subset_cert是唯一固定实例 n2、τ1、seed1002、mask1537(bits0,9,10)的纯Fraction证书。它重算固定16项尾费和真实prefix信用，并用原last-only方案的自己的tail作基线；不是把二者混成同一prefix。全部16半径/r0/s断言保留。1/4格未认证、1/8格认证，两次准确端点保存于attempts。参考masks仅给后选择的子集及费用核对，证书不依赖其抽样积分值；选择偏差不影响随后独立的全盒有理包络。它未证所选子集全局最优，也未严格认证旧连续菜单每个方案都不改善。

symbolic枚举4个形式独立Bernoulli变量的16个状态，两个代数恒等式残差为0。一般有限族证明由报告提供，有限符号检查不替代一般几何论证。

## 本轮实际验证

- 独审认可固定候选池、强制末见证、共同s和tail下的完整预算；向下累计支配只限未捕获强制见证的子格，分数权需保留截断条件或外域费用。
- 独立重算12实际prefix hist、prior loads、2stage所有32768个允许subset的保存浮点账；原single计数与上一轮同点记录一致。没有无故重复Sobol采样。
- 独审通过Bernoulli/Bonferroni减量引理和从真实不交增量导出的空间容量，未获得统一n改进；γ重分配只作为条件证书。
- 严格固定实例：U1>2.36、U3<2.109、U3−U1<−0.254；精确分数和两级网格收据齐全。
- 工具推理与本机计算并发分别管理。此次12进程墙时1.827秒、累计worker CPU12.746秒、峰值RSS和1.383GiB；结束后进程释放，不冒称持续满载。MATLAB未产生本轮证据。

未支付：如何为一般输入构造candidate pool/witness选择，使新增几何覆盖与真实重复信用在同一来源积分下足以抵消全局主量，且tail、尺度、覆盖、终端和旧母账全部受控。浮点正收益、一个严格实例或条件性γ均不能替代这一步。
