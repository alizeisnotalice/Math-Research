# R617 固定候选池合同与 mask 支配：独立预审

日期：2026-10-28。本稿仅从父任务给定候选合同和已核 R616 finite-selection 条件独立推导；没有阅读作者新证明，没有反例扫描，没有参数实验。关键结论是：两个完整 histogram 确实足够计算该固定合同的所有允许 U(T)，但截断几何域只直接支配一个明确的下闭 mask 子格，不能把累计支配说成逐 mask 正性。

## 1. 固定合同及合法性

固定 x、同一次实际 selection。令 S_x 为 w_j>0 且 x∈aB_j 的贡献 index，V 为最后 K 个正贡献，k*=max V 为最后项。固定

P_x={j∈S_x:j<min V}，Tail_x=S_x\P_x，
r0=r_(k*)，q_k=r_k/r0，s=max_(k∈V)q_k，
u_k=(y_k−x)/[(a+1)r0]，c=(b−1)/(a+1)>1，P=((a+1)/a)^n。

以下 T⊂V 必须含 k*。即使 T 没有取得 V 的最大半径，r0、s、prefix、tail 仍不变。按最后 K 个正贡献的定义，Tail_x=V（零权或非贡献的选出项仍保留其原 index 供 selection 条件使用）。

所有 prefix 项早于每个 V 项，故 r_j/r0≥s；每个 witness 的此前捕获预算只能引用原 selection。若 prefix j 没有捕获 k*，由共同星包含 x 的三角不等式得 r_j<t r0。其整个实际增量的归一化像

E_j=(I_j−x)/[(a+1)r0]

满足 ||z||∞<r_j/r0<t。由未捕获 k 与 y∈I_j 的严格开边界，

||u_k−z||∞>c(r_j/r0)≥c max(s,||z||∞)。                    (1)

因此 R616 的多 cap 包络仍合法：固定 tail 与 s 只可能令某些 T 的账比重新切 prefix 更粗，不能令它失效。不能在计算时偷偷把 s 换成 max_T q_k、tail 换成 T 的重量，却仍使用旧 prefix histogram。

若 s≥t，所有 prefix 项必捕获 k*，所以强制 T∋k* 的实际 prefix residual 为0；按合同 H_T=0。这一分支可直接处理。以下主要写 1≤s<t。

## 2. 两个 mask histogram：精确计量

几何域 D={||z||∞<t}，m_s(z)=max(s,||z||∞)。定义完整几何捕获 mask

G(z)={k∈V:||u_k−z||∞<c m_s(z)}。

取有限几何测度

ν(dz)=P 2^(−n) m_s(z)^(−n) 1_D(z) dz，
g(B)=ν{z:G(z)=B}，B⊂V。

这样把 P 直接包含进 g；若作者 histogram 不含 P，以下所有 g 都应乘 P。其总质量严格为

Σ_B g(B)=P[1+n log(t/s)]。                               (2)

实际 prefix 的中心捕获 mask 是

A_j={k∈V:y_k∈bB_j}，
a(A)=Σ_(j∈P_x,A_j=A) w_j。

因为 j<min V，所有 bit 都确实对应“此前项 j 被后来 witness k 捕获”，不是取消时间条件后的对称关系。半径次序也已用于 r_j/r0≥s。固定此合同并记录完整 bit mask 后，计算其他 T 时不再需要逐项展开 index；这不是证明可以忘掉这些条件。

对 T∋k*，令 D_T={A⊂V:A∩T=∅}。则

PH_T=Σ_(B∈D_T)g(B)，
R_P(T)=Σ_(A∈D_T)a(A)，
O_P(T)=Σ_A a(A)(|A∩T|−1)_+，
U(T)=|T|τ+W_tail+Σ_(B∈D_T)g(B)−O_P(T)。                  (3)

故同一完整几何 histogram 与实际 histogram 确实能读出所有允许 T 的准确既定包络，无需逐 T 重积分。m_s、坐标与两种 measure 必须相同，实际 histogram 不能改用无权个数。

## 3. 真正可证的 down-set 支配

设 E0={A⊂V:k*∉A}。它本身是下闭集。若 a(A)>0 且 A∈E0，则该项 j 未捕获 k*，从第1节知整个 E_j⊂D。

更强的逐点关系是

G(z)⊂A_j，z∈E_j。                                      (4)

证明：k∉A_j 时由 (1) 得 k∉G(z)，取逆否命题即可。注意方向是“几何捕获⇒实际中心捕获”；不是反过来。

变换后的实际 weight-density 为

μ_j(dz)=P 2^(−n)(r_j/r0)^(−n)1_(E_j)(z)dz。

各 E_j 两两不交，且 r_j/r0≥m_s(z)，故 Σ_j μ_j≤ν（在 D 中）。每个 μ_j(E_j)=w_j。这里使用的是实际 increments 的 Lebesgue 体积权，不是原 L1 来源质量被假定有 density cap。

于是对任何下闭集 E⊂E0，都有严格可用的必要约束

Σ_(A∈E)a(A)≤Σ_(B∈E)g(B)。                              (DS)

理由：A_j∈E 则由 G(z)⊂A_j 与下闭性知 G(z)∈E；整项 E_j 又在 D 中，然后应用实际密度支配。等价地，对任意全格下闭集 F，先取 E=F∩E0 再应用 (DS)。特别 D_T⊂E0，所以 (3) 的每个允许 T 都满足 R_P(T)≤PH_T。

**不能省略的限制。** 对包含 k* 的实际 mask，prefix 可能有 r_j≥t r0，整 I_j 不再保证进入截断域 D。因而不能直接把 (DS) 宣称为完整 a 在整个 2^V 上对所有 down-set 的支配；需要额外的域外实际质量付款，或另定义未截断/扩大域的几何 measure。仅“uncaptured actual⇒uncaptured geometric”不足以把这些已捕获 k* 的整项质量放进 D。

**绝不是逐 mask 正性。** (DS) 不推出 g(A)−a(A)≥0。关系 (4) 允许实际质量从较小几何 mask B 运输到较大中心 mask A；到达 mask A 的实际质量可以大于该格自己的几何容量，而仍完全满足所有下闭累计不等式。对累计差做 Möbius 反演也不会保留非负性。

## 4. 等价的 order-subcoupling：可给作者的完整线性约束

记 a^- 为 a 在 E0 上的限制。实际 increments 构造出非负数 π(B,A)，B,A∈E0，满足

π(B,A)=0 unless B⊂A，
Σ_B π(B,A)=a(A)，
Σ_A π(B,A)≤g(B)。                                       (Flow)

具体 π 是 mask A 的实际 increments 中、几何点 mask B 的 μ_j 质量。这保留了量纲与 density，不是假定逐 mask 容量可以原地容纳实际质量。

在有限 mask 格上，(DS) 与存在这样的 subcoupling 等价。必要性由支持 B⊂A 立即得到。充分性可写有限二部容量网络：几何 mask B 的供给≤g(B)，实际 mask A 的需求=a(A)，仅连 B⊂A。任意需求族 F 的可用供应为 ↓F；由

a(F)≤a(↓F)≤g(↓F)

满足容量 cut 条件，故存在非负可行流。这个等价仅是 histogram 层面的 order 可行性，不证明给定 a,g 能由真实 cube selection 实现。

若 h(T)=g(D_T)−a(D_T)，则由 Flow 有精确表示

h(T)=Σ_(B∈D_T)[g(B)−Σ_Aπ(B,A)]
     +Σ_(B∈D_T,A∉D_T)π(B,A)≥0。                         (5)

所以对所有允许 T 确有非负 cumulative gap；不能因此声称 h 的逐 mask 系数非负，也不能据此免费假定 h 关于 T 单调、次模或超模。g(D_T)、a(D_T) 分别来自非负 histogram，但其差需要保留运输结构。

## 5. 必须同时保留的 selection / index / tail 约束

定义 prefix witness 负载

L_k^P=Σ_A a(A)1_(k∈A)，
L_k^tail=Σ_(j∈Tail_x,j<k)w_j1_(y_k∈bB_j)。

同一次实际 selection 的条件给出

0≤L_k^P≤τ−L_k^tail≤τ。                                 (6)

未在 S_x 内的其他已选项也可能付负载；忽略它们只使 (6) 更松，不许可增加预算。任何非负 λ_k 都给

Σ_A a(A)Σ_kλ_k1_(k∈A)≤τΣ_kλ_k−Σ_kλ_k L_k^tail。          (7)

另有每个 w_j≤a^(−n)，W_tail≤K a^(−n)，以及实际 radii 非增、原 index、原严格开中心捕获条件。给定实际 prefix radii 时还有逐项强制 bit：

r_j≥t r_k ⇒ k∈A_j。                                    (8)

特别 s≥t 时所有 prefix 的 A_j 都含 k*。若研究者保留 radius-bin mask histogram，则 (8) 可直接加入；若只保存无尺度 a(A)，不应再声称已保存了所有 radius/joint-realizability 约束。

单位权的 exact algebra 为

Σ_(k∈T)L_k^P=W_prefix+O_P(T)−a(D_T)。

从而固定合同下有非常有用的准确恒等式

U(T)−W(x)=Σ_(k∈T)(τ−L_k^P)+h(T)。                       (9)

两类项均非负，且第一类还≥Σ_(k∈T)L_k^tail。故任何两个 histogram 的松弛模型至少应满足 (2)、非负质量、(DS)/(Flow)、(6)及其加权形式；不能只保留每个 T 的 h(T)≥0 而忘记各 T 共享同一对 histogram、同一 prefix 和同一 witness 预算。

(9) 不排除 U(T)<U({k*})：可以用新增 witness 费用/剩余 eligibility slack 换取较小 h(T)。它只说明精确账加合法外放松不可能把 U 降到实际 W 以下。R616 的有限包络改进与此完全相容。

## 6. 非单位 λ：何时可用同一截断几何 measure

非负 λ 是必要条件：c_λ(A)=Σ_k λ_k1_(k∈A) 随 mask 包含而非减，f_λ(A)=(1−c_λ(A))_+ 随包含而非增。O_λ(A)=(c_λ(A)−1)_+。

如果 λ_(k*)≥1，则 f_λ 在所有含 k* 的 mask 上为0，其正水平集均是 E0 中的下闭集。由 (DS) 或 layer-cake 得

Σ_A a(A) f_λ(A)≤Σ_B g(B) f_λ(B)。                       (10)

于是完整合法加权包络是

W(x)+Σ_A a(A)O_λ(A)
 ≤τΣ_kλ_k+W_tail+Σ_Bg(B)f_λ(B)，                        (11)

还可用 (7) 扣除 Σ_kλ_k L_k^tail。单位 T∋k* 是 λ=1_T 的特例。若要保留 probability-mixture 形式 Σλ=1 并用这个充分条件，则只能把全部权放在 k*，不能凭概率混合免费得到多 cap 交集。

更一般，若 V 有多个 r_k=r0 的最小半径 witnesses，λ 在所有这些最小半径项上的总权≥1也足够：大半径 prefix 必捕获所有这些项，f_λ 正值要求至少漏掉一个最小半径 witness；可把 E0 扩成“没有包含全部最小半径 witnesses”的下闭集，再重做同样证明。也可依据实际 radius/mask 明确验证每个 r_j≥t r0 的项都有 c_λ(A_j)≥1；这必须实际写出，不能由任意 λ≥0 自动推出。

若 λ_(k*)<1 且无上述额外覆盖条件，则不能无偿使用 (10)。一个始终安全、但更粗的补付款是

Σ_A a(A)f_λ(A)
 ≤Σ_(B∈E0)g(B)f_λ(B)+(1−λ_(k*))_+ L_(k*)^P。             (12)

证明是把实际 mask 分成 k* 未捕获/已捕获两类，前者用 E0 下闭支配，后者 f_λ≤(1−λ_(k*))_+，其总质量为 L_(k*)^P。这个缺失项不能藏进原 τ 同时又保留原全部信用。

## 7. 供作者使用的结论及边界

可直接使用的确切必要条件是：固定 prefix/r0/s 的共同 histogram 表达式 (3)；E0 上所有下闭累计支配 (DS)，或等价的包含序 subcoupling (Flow)；原 selection 与实际 tail 内部负载约束 (6)–(8)；及完整 gap 恒等式 (9)。若允许非单位 λ，须保留非负性及让 residual 真正局限于截断域的条件，或支付 (12) 这类额外项。

这些约束允许有符号逐 mask 差，并不授权逐 mask 非负、任意重排半径或 index、独立重选 tail，亦不说明 histogram 松弛的可行解均可实现为 cubes。只有单独的 principal down-set D_T 约束弱于所有允许 down-set 的完整支配。

本稿所有几何 measure 均来自实际 increment 的 Lebesgue 体积换元；不能用它替代任意 L1 来源测度的质量帽。随 x 选择 V/T/λ并最终积分，仍需可测规则、同一次 selection 和完整 |f(x)| 加权账；没有一般维源积分目标在此自动闭合。

按用户数学工具偏好，实际使用指定数学 venv 的 SymPy 验证 (9) 的展开恒等式及正部恒等式的 c≥1、c≤1 两支。SymPy 未能直接自动化简 Max 表达式，未把该自动化失败当数学否定；分支代数检查通过。没有数值扫描，严格支配由第3–4节的测度/流证明给出。

## 8. 独立合同完成后对 mask 计算的定向核验

独立完成第1–7节后，才读取 `/tmp/ccu_r617_masks.py/json/md`。未重跑大规模 Sobol，未做新反例或 family 扫描。当前12案例与脚本/输入/selected SHA256匹配，全部 complete。

**算法与归一化通过。** bit0对应最后正贡献 k*；valid=全部奇数mask，恰为2^15个强制bit0的候选T。V=最后16个正贡献、prefix=其之前全部正贡献、tail=这16项重量；r0和s在所有T中固定。实际histogram保存的是严格中心捕获bit，权为cell增量除以(16R)^n，通过共同LCM化为整数。几何histogram保存每点被inner caps捕获的完整bitmask，故对FULL^T做subset-zeta，准确得到T中所有caps均未捕获的质量。内cube权1、shell权n log(t/s)与R616相同，几何histogram并非有符号差measure。

实际前缀的 `uncovered=zeta(a)[FULL^T]`、`union=Wprefix−uncovered`、`loadsum=Σ_(k∈T)L_k^P`，因此 `op=loadsum−union` 恰等于Σ_A a(A)(|A∩T|−1)_+。U的常数项准确为|T|τ+固定tail−op，并未错把capture次数直接当重复信用。

**稀疏保存可复算，并已独立重算。** 从输入selected_records重新生成所有12个实际prefix mask histogram、每个prefix位负载、全部16个witness此前正贡献负载、tail及last weight，与JSON完全一致。对geometry sparse counts检查mask范围/唯一性、正整数计数、每片总数恰等于2^16或2^20、两阶段逐mask嵌套。另以不同写法的subset-zeta从保存histogram重算每案例、两阶段、每个32768允许T的浮点目标，最优mask、两个单独scramble最优mask、所选mask的U/H、精确residual/op/mτ/tail、两种单witness基线及所有差/配对SE均与保存值一致。

原last-single基线确实另外使用s=1与last weight，而fixed-prefix-single基线使用固定s与16项tail；两者不能混称同一基线。原single的accepted counts还与R616同seed同点记录逐项匹配，完整16见证的共同s积分也与R616对应记录一致。这是对采样实现的额外交叉核对，不是重新采样。

所有12案例在2^16与2^20阶段的mean-optimal mask相同。特别n=2、τ=1、seed=1002的mask1537为bits{0,9,10}，是合法的非连续3-witness子集；它区别于R616只试连续末p项的菜单。当前相对original-last-single约−0.6529仍是用同批样本选点并评价的探索数值。它不认证真实连续积分的全局最优、未试family或一般维收益；新的固定实例严格证书须另审。

**支配与样本不可混用。** 第3–4节的DS/Flow针对真实几何测度g；这里保存的Sobol histogram是其近似。不能因为真实下闭支配成立，就把有限样本的几何−实际逐mask差改写成正measure，也不能把未经严格误差处理的经验DS当精确可行约束。两scramble配对SE和两阶段稳定性均不消除sample-in选择偏差。

## 9. mask1537 固定实例严格证书：必要核验通过

已审 `/tmp/ccu_r617_subset_cert.py/json/md`。按授权，用指定数学venv做了一次约0.04秒的精确证书重放，独立输出 `/tmp/ccu_r617_audit_subset_cert.json`；没有重跑Sobol。

输入为已核合法selection的 n=2、τ=1、N=4096、seed=1002记录。mask1537=bits{0,9,10}，强制最后项正确；固定prefix有276个正贡献，固定tail为最后16项。所选3项及完整16候选的半径均为r0=8，所以固定s=1，不是只根据所选子集偷偷降低s。几何归一化u=y/72、c=29/27、P=81/64正确。

证书比较的是两个合法但不同prefix/tail的包络：原last-single的tail为13/16384；三witness候选仍使用完整16项tail=131/16384，prefix重复信用11415/8192、实际未捕获负载361/8192。上述费用与已审mask记录准确一致。不能把这两个tail当成同一费用，也不能将三项自身重量取代固定16项tail。

矩形代码以den=72·subdiv作整数缩放；每格边长1/subdiv、面积1/subdiv²。m_s的盒内最小/最大值、所有witness的坐标距离阈值和严格/非严格边界方向与R616证书相同。单格归一化密度权准确为den²/(4 subdiv² m_integer²)。上下端点全部用Fraction求和；delta<0和停止加密也都是Fraction比较，float只在末尾打印。

独立重放确认1/4网格的差值上界

31302217/485703680>0，

故该粗网格没有认证改善；它不表示真实改善不存在。1/8网格则得到

U3−U1≤−10018963877236605/39393174053961728<−0.254。

相应端点精确比较还给

U1≥10704434645119637899/4530215016205598720>2.36，
U3≤2388063449809357081/1132553754051399680<2.109。

作者随后仅增加完整16项s/r0、mandatory bit断言及两次attempts保存。最终脚本SHA256为 `20c16600ea7fb24c7d03c2fcdee465d9946edf3706302697df503f679d5aaa56`，与最终JSON匹配；两次attempts的端点及最终全部费用/端点，与独立重放及对1/4网格的额外准确复算一致。未对更改前的审计运行收据伪造新版脚本归属。

此证书是后选定的一个有限、真实selection上的严格包络改善；确定性有理包络本身不受选择时复用Sobol样本的统计偏差影响。但它不证明原连续后缀菜单在该case均无法改善（R616对此只有数值菜单结果），不证明全部子集的连续几何最优，也不提供一般source预算或维数指数。当前代码/JSON/MD在这一范围内一致，没有决定性错误。主文尚待另审。

## 10. 新一般收费引理与条件性 source 接口：独立必要审查

只审 `/tmp/ccu_r617_main_sol.md` 第3–4节新增一般结论及第5节条件接口，未扩展到新证明、family或反例扫描。该文件本身给出的定义足够核验，无需把其他作者未见结论当作前提。以下通过范围是一般 finite-selection 收费/容量引理，绝不是新的统一维数上界。

**Bernoulli 与 Bonferroni 通过。** E非空时wmax>0且0≤θ≤1/wmax准确保证p_k=θw_k∈[0,1]；E空时减量按0处理。原selection、V、prefix、tail、r0、s及几何测度全被冻结，只有有限witness子集作独立Bernoulli选择。新增费用期望准确为τθΣw_k。对每个固定z，union指标的二阶Bonferroni下界是单项和减去成对交项；积分和独立选择后，几何新覆盖期望≥θΣw_k b_k−θ²Σ_(k<l)w_kw_l b_kl，符号与成对系数正确。下界即使为负仍合法。

对于原mandatory已经捕获的prefix j，原重捕获信用为0，新增信用恰为w_j乘被选optional捕获数，故其期望正是θΣ_k w_kB_k；没有把原credit重复免费扣除。对于原mandatory未捕获的j，额外信用为w_j(N_j−1)_+，其期望准确是w_j[θd_j−1+Π_(k:A_jk=1)(1−θw_k)]，且非负。舍去这部分给式(3)，保留它可加强保证。取有限随机结果的期望再推出存在一个T合法；随机性没有改变原input/selection，也没有引入坐标或来源独立性。J_gain的分情况闭式与闭区间端点正确。

**实际candidate增量密度(5)通过。** 归一化后每个candidate的ρ_k=r_k/r0∈[1,s]，其实际增量位于[-s,s]^n，且各点到u_k距离严格小于ρ_k/(a+1)≤ε。测度

σ=P2^(−n)Σρ_k^(−n)1_(Itilde_k)dv

在第k块上的质量准确为|I_k|/(2ar_k)^n=w_k，所以总量确为q。实际increments不交、ρ_k≥1给σ的Lebesgue密度≤P2^(−n)。这一步是有限实际体积权的容量，不是对f增添density cap；不能换成任意原source测度后沿用。

**cap-incidence夹逼(6)通过。** R=c m_s≥cs>ε。中心被cap捕获时，整个对应增量落在z的R+ε立方体中，其质量总和恰为g(z)，故由密度容量给g≤min(q,PV_(R+ε))。中心未捕获时，该增量全部在R−ε开立方体外，故q−g≤P[s^n−V_(R−ε)]，取正部得到g_-≤g。strict中心条件与体积边界零测的用途没有混淆。交体积的各坐标截断边长公式正确。

**D/C替换通过。** D=∫_(D0)g dν+Σw_kB_k−τq≥d。点态展开g²后，去掉单项平方得到

C=(1/2)∫_(D0)[g²−Σw_k²1_(G_k)]dν≤(1/2)∫g_+²dν=c2。

因此对θ≥0，原保证减量减去粗保证减量恰为θ(D−d)+θ²(c2−C)≥0。式(7)最大化的是较小的保证减量，转回U上界时方向正确，不会因C≤c2而错误放大收益。d≤0时以θ=0给0保证；s≥t时ν=0、所有prefix被mandatory捕获，新增credit≤原τ，因此该固定预算不会因加witness下降，最优τ+Q。这些退化分支与一般式一致。

**第5节仅作为条件性接口通过。** 对固定实际bad-stars，∫fW=Σv_jh_j，故ηVtot=∫fW−D_f准确。Ubound≥W与实际cover系数给式(8)方向正确。若存在整次selection固定、与接收点x无关的γ_j≥0、Σγ_j=Vtot满足式(9)，乘f积分可用Σγ_jh_j≥ηVtot，于是

∫fUbound−D_f=ηVtot+∫f(Ubound−W)≤B||f||_1。

γ_j=v_j时其核正是W，确实退回Ubound≤B；允许固定star间重新分配γ给出条件性自由度，但本稿没有证明存在具有根阶B的γ，也没有从candidate局部容量(5)–(6)推出它。γ不能依x改变，否则上述固定bad-star平均付款不再成立。式(8)/(9)不是已取得的一般source估计，也不豁免旧合同全费用。

独立实际调用指定数学venv的SymPy，枚举三个形式Bernoulli参数的8个状态，核验union期望与新增credit恒等式；二阶Bonferroni的三阶余项为p1p2p3，并核验D/C替换差的展开，均精确通过。没有使用浮点比较支撑上述一般证明。

**最终判断：** 第3–4节是合法、无新增source假设的明确一般收费/容量上界；第5节是方向正确的条件性几何充分证书。未发现决定性错误。仍缺由真实selection普遍推出足够大的减量，或具有根阶B的统一γ证书，以及其完整来源积分付款；不能将本轮这些条件式改称新的维数估计。

## 11. 主报告最终整合与无新采样 gain probe：一致性核验

已读 `/tmp/ccu_r617_final/REPORT.tex`，并核对 `/tmp/ccu_r617_gain_probe.py/json/md` 与归档目录的 `symbolic.py/json`。本步只作文稿/证据范围一致性检查，未重复Sobol或已审一般收费/容量证明。

新增gain probe确实只从已保存的两个正histogram读取b_k、b_kl与实际B_k；没有新抽样入口。其输入/代码SHA256匹配。保存状态complete，共48个不同record/stage/scramble组合，恰为12案例×2阶段×2scramble。全部48组D及二阶J是正浮点值。大阶段24组的比例实际为：

* 二阶J/该scramble完整菜单采样最优gain：4.5644537599743895%至58.429872314165046%；
* 加入额外credit后的探索gain/同基线gain：6.00711080025852%至64.86510367720581%。

报告的4.56–58.43%和6.01–64.87%准确；两种比例都使用同一固定prefix-single基线，没有将original-last-single偷偷混入。129点参数网格加局部有界refinement只产生浮点探索，不认证真实积分、连续参数全局最大或统计覆盖；报告和probe.md均已明确。有限探针中的正D/J不能升级为一般均匀正减量，报告未作此升级。

另直接核对原masks.json：全部12案例的两阶段及每个单独scramble最优mask确实相同；大阶段所选m范围2至8；固定prefix与original-single的两种差均负。报告约1.83秒wall、12.75秒worker CPU及1.38GiB worker峰值和与原收据一致（精确峰值和1.383148193359375GiB）。这些是一次已完成运行记录，不是持续占满CPU声明。

归档symbolic.py的SHA256与JSON匹配，记录4个形式Bernoulli参数、16个枚举状态、union及重复信用残差均为字符串0。代码也确实计算这两个多项式恒等式；报告准确将其定位为补充代数核验，未以四变量枚举替代一般有限族或几何证明。

**主报告范围通过。** R616长证明仅作为已核前提，未伪装为本轮全新重证；固定candidate/prefix/tail/r0/s、mandatory-last、downset仅在E0有效、有符号逐mask差、实际increment密度与任意f区别、λ截断条件、两种baseline、1/4失败与1/8严格证书、sample-in优化限制等声明与既有审查一致。原输入仍是一般L1、真实Lebesgue接收测度与全部尺度，没有引入product source、density cap或有利scale筛选。原R559共同source/phase/window/clock账未自动支付，也有明确声明。γ接口准确限制为未构造根阶B的条件性充分证书。

报告明确未证明：所有高预算态均能下降、统一收缩、终端根阶成本、整个来源积分付款或最终n^(1/2+o(1))目标。有限证书没有宣称旧连续菜单全部严格失败或mask1537连续几何全局最优。没有决定性文稿/证据范围错误。

一个非阻断文字建议是将式(global)前“a complete operator proof must control”改为“one sufficient full-source target is”：固定polylog预算是n^(1/2+o(1))的较强充分目标，不必宣称为唯一必要账式。主报告本已保留更精细source-sensitive alternative，故这不影响已证明结果。

按父任务归档方案，selection原始输入复用R616包、以已核SHA256 `2315b812165bc617d6a4fa343c769ca2ca918577f5f6030d1d6430ea70d383db` 绑定，不重复装入新ZIP。该来源设计不改变上述数学证据；复现说明需准确将其列为外部前包依赖，不能把它描述为新包自含输入。本节未擅自认证尚未生成的最终ZIP或manifest。
