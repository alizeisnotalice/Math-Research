from pathlib import Path
import sympy as s
import itertools,json,sys,hashlib,time,argparse
p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=Path(__file__).with_suffix('.json'));a=p.parse_args();start=time.perf_counter()
x=s.symbols('p0:4');one=s.Integer(1)
union=0;repeat=0
for state in itertools.product((0,1),repeat=4):
 probability=s.prod(x[k] if state[k] else 1-x[k] for k in range(4))
 union+=int(any(state))*probability
 repeat+=max(sum(state)-1,0)*probability
u=s.expand(union-(1-s.prod(1-v for v in x)))
r=s.expand(repeat-(sum(x)-1+s.prod(1-v for v in x)))
assert u==0 and r==0
out={'command_argv':[sys.executable,*sys.argv],'python':sys.version,'sympy':s.__version__,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'bernoulli_formal_variables':4,'enumerated_states':16,'union_residual':str(u),'repeat_credit_residual':str(r),'elapsed_seconds':time.perf_counter()-start,'scope':'Exact polynomial identities for four formal Bernoulli parameters; the general finite-family argument and geometry are proved separately.'}
a.output.write_text(json.dumps(out,indent=2)+'\n');print('PASS: both exact polynomial residuals are zero')
