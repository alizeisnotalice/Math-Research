# 第116轮：FIRST 重尾集中与真实体积的三点核审查

一般中心立方体 n^(1/2+o(1)) 一致弱型上界仍未证明。本轮没有增加实际根阶付款；第115轮的已证估计和原位预算保持有效。

本轮唯一瓶颈是小父节点的实际重尾联合交通。先尝试借 FIRST 未来核约束重尾来源，再筛查逐点三点核比较。筛查给出指数损失的严格核算例；其正体积邻域的当前加权积分同时至多8^(-n)，说明不能把逐点失败直接解释为真实接收积分失败。不是原 FULL 实例，也不否定整体几何路线。

可继续使用的正向结论是：固定合法未来核 P_(1,b)，FIRST 迫使高 pe 分支的归一化重尾来源至少一半集中在三点比较失效区域。通过保留第三来源概率核及其1/e分母，将高分支写成真实原交通上的积分；低 pe 分支仍显式保留。此项是准确几何表示，不是新付款。

下一步需要同时估计低 pe 分支与三来源坏区域的整体积分，保留原软端、原硬捕获端、新附加来源、种子平均、真实 dx 及全部分层费用。不再要求全空间逐点支配成立。

使用更新的 L03 技能限定范围：精确有理端点与初等级数余项；未依赖未经核验的浮点区间 API。基本未来混合后验界及旧 Bernstein 倾斜没有被登记为新成果。没有调用新外部文献定理；所有本轮新计算从核定义及非负积分推出。

数值为本机 Python 3.14.6/Fraction；三阶段12行、6个基础指数证书、29项程序检查，0失败。压力阶段2项因低阶截断跨阈值而保持 UNDECIDED，不算失败或被认证。正式记录一次及隔离重放一次字节一致；不拟合维度阶数、不认证 FULL 实现性，不编译 PDF。详细执行时间与哈希见 execution_receipt.json。

额度：本环境没有每个 Agent 的实际扣额数据，故不估计模型成本比例。本轮复用 Astra high 一名、Sol high 审查一名、Sol medium 数值一名；辅助 Sol high 曾发生两次服务流断，没有其完成稿，未把该任务计入数学成果。

本稿终止一个明确的逐点候选，并记录其不能终止积分路线的原因。完整未来上限还给出一条严格的重尾来源几何：在另行限定的高当前核区域，重尾的相当部分必须落入三点比较失效区。该结论没有新增根阶付款；R115 AR18 仍未闭合。

## 1. 待检逐点命题及允许的未来参数

沿用原一维核
\[
 h=\mathbf1_{[-1/2,1/2]},\quad
 w(v)=\int_0^1e^{-|v|/t}dt,\quad \phi=h*w,
 \quad P_{s,L}(v)=L^{-n}\prod_{i=1}^n[(1-s)h(v_i/L)+s\phi(v_i/L)].
 \tag{F1}
\]
\(\phi\le1\)，因为 \(w\) 是概率密度且 \(h\le1\)。置原 RC 的
\[
 F(v)=\max\{h(v),\phi(v)\},\qquad
 C(d)=\int_{-1/2}^{1/2}F(v-d)dv.
 \tag{F2}
\]
因此 \(0<C(d)\le1\)，且 \(C(d)\ge(1-|d|)_+\)。

候选是：对任意维度、\(0<a\le b\le2a\)、当前 \(s\in[0,1]\)、\(L,R\in[a,b]\)、\(g=\sqrt{LR}\) 和来源点 \(y,z'\)，能否有至多多项式增长的 \(K_n\) 使
\[
 P_{s,L}(x-y)\widetilde w_{j,g}(y,z')
 \le K_n\sup_{\substack{s\le s'\le1\\a\le L'\le b}}
                        P_{s',L'}(x-z')?
 \tag{F3}
\]
\(\widetilde w_{j,g}\) 是 S5 的原比例权重；当前 \(s\) 是原选择器的值，而不是重新为单坐标选择的软度。右侧甚至允许逐 \(z'\) 取最有利的未来参数，因而比任何不依 \(z'\) 的合法共同 future 混合更大。这个较强右侧的逐点比较若失败，任何该类混合都不能修复其统一多项式常数。

(F3) 只是待检核命题。其右侧的逐来源上确界不能放入 \(f\) 积分后冒称受到 FIRST 的 \(q\) 上限控制。

## 2. 正体积矩形上的解析证书

固定 \(b=2a\)、\(s=1/4\)、\(L=R=g=b\)、比例带 \(j=0\)，以及
\[
 y=0,\quad z'=-(b/8)(1,\ldots,1),\quad
 B_b=(3b/8,b/2)^n,
 \qquad |B_b|=b^n8^{-n}.
 \tag{F4}
\]
对任意 \(x\in B_b\)，所有 \(x_i/b\) 都在当前硬盒内部，故
\[
 P_{1/4,b}(x)\ge b^{-n}(3/4)^n,
 \qquad \widetilde w_{0,b}(0,z')=C(1/8)^n\ge(7/8)^n.
 \tag{F5}
\]
另一方面，\(r_i=x_i-z'_i>b/2\)。任意 \(L'\le b\) 都使全部未来硬因子为零。对 \(u\ge1/2\)，原核有准确表示
\[
 \phi(u)=\int_0^1t\big[e^{-(u-1/2)/t}-e^{-(u+1/2)/t}\big]dt
 \le\tfrac12e^{-(u-1/2)}.
 \tag{F6}
\]
于是 \(2u\phi(u)\le u e^{-(u-1/2)}\le e^{-1/2}\)。令 \(u=r_i/L'>1/2\)，因 \(r_i>b/2\) 而有 \(b/L'<2u\)，从而
\[
 {b\over L'}\phi(r_i/L')\le e^{-1/2}.
\]
共同未来软度满足 \(s'\in[s,1]\)，所以 \((s')^n\le1\)。对整个允许未来集一致成立
\[
 \sup_{s\le s'\le1,\ a\le L'\le b}P_{s',L'}(x-z')
 \le b^{-n}e^{-n/2}.
 \tag{F7}
\]
特别地，(F3) 在整个正体积矩形上都要求
\[
 \boxed{K_n\ge B_*^n,\qquad B_*={21e^{1/2}\over32}>1.}
 \tag{F8}
\]
严格大于一也可直接用 \(e^{1/2}>1+1/2+1/8\) 验证，无需数值估计。单一共同软度、共同物理尺度及所有允许未来参数已包含在 (F7) 中，故这不是因漏掉某个 future 参数造成的损失。

本构造只否定统一核比较 (F3)，未构造完整 \(f\) 的实际 FIRST、FULL、失败币或 strict CP/GP 实例，不能称为原目标的反例。

## 3. 真实体积抵消了这个局部算例的绝对费用

在相同矩形上，\(P_{1/4,b}\le b^{-n}\)、\(C(1/8)^n\le1\)，因此
\[
 \boxed{
 (21/256)^n
 \le\int_{B_b}P_{1/4,b}(x)\widetilde w_{0,b}(0,z')dx
 \le8^{-n}.}
 \tag{F9}
\]
所以该区域上的逐点相对损失虽然指数增长，其当前核加权绝对空间质量仍指数衰减。不能把 \((B_*/8)^n\) 当作任何实际积分比；(F8) 和 (F9) 分别记录相对核比较和绝对空间费用。

这也可以直接放回真实行作局部核验。仅考虑当前选择器满足 \(L=b,s=1/4\)、并在原实际软端乘 \(\mathbf1_{\{x-y\in B_b\}}\) 的子交通。当前联合软核由 \(q^{-1}P_{1/4,b}(x-y)d\beta(y)\) 支配，而原硬行上限是 \(h_R\nu\le4\lambda\le C_hq\)，\(C_h=16/3\)。逐固定种子放回这些母核、保留真实 \(dx\)，再对 \(y\) 用 Tonelli，得到
\[
 T_{B_b}\le C_h\,8^{-n}W_\beta\le C_h\,8^{-n}W_{\rm hi}.
 \tag{F10}
\]
这是对该明确局部限制的正确绝对收费，不声称当前 FULL 中它必非空，也不登记一项独立的全局改进。原门只在取上界时删除，没有重新生成它们。单个平移矩形的 (F10) 不允许对随 \(z'\)、\(y\)、尺度和种子变化的一族矩形免费求和；未证明的来源复用/几何重叠正发生在这一步。

## 4. 完整 FIRST 确实迫使重尾落入哪一种几何

以下回到 R115 AR18 的同一实际 \(T_{\rm small}\)。固定当前种子，\(\nu\le\beta\le f\,dz\)，\(a\le g(x)\le b\)。记
\[
 p(x,y)=P_{s(x),L(x)}(x-y),\quad
 Z=Z_{j,V}(y,g(x)),\quad
 W(x,y,z')=\widetilde w_{j,g(x)}(y,z'),\quad
 e(x,y)=\int_Z W(x,y,z')d\nu_V(z').
 \tag{F11}
\]
\(W\) 是核权重，不是来源总质量。\(Z\)、\(e\) 及 \(j\) 均沿用当前原对象，没有更换 heavy 门。

只用一个共同合法未来参数 \((1,b)\)，置 \(Q_b(x,z')=P_{1,b}(x-z')\)。原完整 FIRST 给
\[
 \int Q_b(x,z')d\nu_V(z')\le P_{1,b}f(x)\le q.
 \tag{F12}
\]
该不等式逐当前种子成立；不要求 \(\nu\) 独立于种子。这里没有逐来源上确界，也没有 \(\int\sup\) 的交换。

给定 \(K>0\)，定义严格失效集与其加权质量
\[
 D_K(x,y)=\{z'\in Z:p(x,y)W(x,y,z')>KQ_b(x,z')\},
 \qquad b_K(x,y)=\int_{D_K(x,y)}W(x,y,z')d\nu_V(z').
 \tag{F13}
\]
等号归补集；若 \(e=0\)，取随后归一化量为零；若 \(p=0\)，则 \(D_K\) 为空。对补集积分并用 (F12)，准确得到
\[
 \boxed{p(x,y)[e(x,y)-b_K(x,y)]\le Kq.}
 \tag{F14}
\]
在 \(pe>0\) 上，等价地 \(b_K/e\ge1-Kq/(pe)\)。

在真正高分支 \(pe\ge2Kq\) 上，(F14) 给 \(b_K/e\ge1/2\)。主代理 `integration.md` I1–I3 已将这一关系准确乘回原实际交通测度：以
\(\Pi_{x,y}=\mathbf1_ZW\,d\nu/e\) 为归一化辅助来源核，保留原硬端 \(z\)，另加入测试来源 \(z'\)，得到 I2 的三来源表示。这里引用该已写明的真实 \(dx\)、\(d\beta(y)\)、种子和原门接口，不另引入一个 \(\tau\) 核心门或任何新费用。

低分支仍须保留。原重尾门只给该支当前核密度
\[
 p<{2Kq\over e}<{2Kc_j^{n/2}\over\ell_n g^n},
 \qquad \ell_n=1+\log n;
 \tag{F15}
\]
它不是来源后验质量或接收体积上限，也不意味着 LC19 的整个核加权核心已小。

## 5. 当前结论与明确的积分缺口

本轮没有新增一般根阶付款，没有新增全局费用或减少旧费用。新增解析事实为：(F3) 的多项式逐点比较在正体积矩形上失败；同一矩形的当前核绝对空间质量却至多 \(8^{-n}\)，因此该失败不否定实际积分抵消；完整 FIRST 还给出 (F14) 的严格加权失效区约束。

下一项需要证明的准确整体积分对象是 `integration.md` I2 中
\[
 \int_{\{pe\ge2Kq\}}d\mathcal T(\omega,x,y,z)
 {1\over e(x,y)}\int_{D_K(x,y)}W(x,y,z')d\nu_V(z'),
 \tag{F16}
\]
其中 \(d\mathcal T\) 是同一原实际交通；逐种子其规范 RN 表示为 \(q^{-1}p(x,y)h_{R(x)}(x-z)a_\omega(x,y,z)dx\,d\beta_V(y)d\nu_V(z)\)，\(0\le a_\omega\le1\)，完整联合门均保留在 \(a_\omega\) 内，不活跃行取零。其新几何是明确不等式
\(p(x,y)W(x,y,z')>K P_{1,b}(x-z')\)，不是一个未知占有率符号。必须利用这类失效区域的核加权体积，并支付它们随来源、尺度和种子变化的复用；单个矩形的 (F9) 没有给出此整体估计。归一化 \(1/e\) 不可丢掉，\(z'\) 也不能被当成独立原后验或另一份免费来源。

(F16) 尚无根阶或可吸收预算，I2 的低 \(pe\) 补项也未支付。一般目标仍未闭合。本任务在此结束，不继续展开三来源估计或重试已被 (F8) 排除的逐点候选。

# R116 原位三来源表示（主代理稿，I1–I3 已通过独立审查）

固定 R115 实际余项的非负交通测度 \(d\mathcal T(\omega,x,y,z)\)，总质量为 \(T_{\rm small}\)。它保持原种子、真实接收 \(dx\)、来源以及 FULL/FIRST/CP/GP/deep 等全部门；这里只对同一测度增加指示函数。固定 \(K>0\)。记
\[
p=P_{s(x),L(x)}(x-y),\quad e=e_j(y,g)>\ell q c_j^{-n/2}g^n>0,
\quad Q_x(z')=P_{1,b}(x-z').
\]
当前种子下 \(\nu\le f\,dz'\)，且 \((1,b)\) 是合法的共同 future test。因此 \(\int Q_x\,d\nu\le q\)。假定全输入质量有限，\(0\le\widetilde w\le1\)，故 \(e<\infty\)。定义
\[
D_K(x,y)=\{z'\in Z_j(y,g):p\widetilde w_j(y,z';g)>KQ_x(z')\},\quad
\Pi_{x,y}(dz')=\frac{1_{Z_j(y,g)}\widetilde w_j(y,z';g)}e\,d\nu(z').
\]
这是逐点概率核，不是另一个可自由选择的来源；分母 \(e\) 不可删除。由坏集补集的定义，
\[
p e\,[1-\Pi_{x,y}(D_K)]\le K\int Q_x\,d\nu\le Kq.
\tag{I1}
\]
在 \(p=0\) 情况左端为零；以下高分支自动排除它。令 \(A=\{pe\ge2Kq\}\)，则在 \(A\) 上 \(\Pi(D_K)\ge1/2\)。将它乘原交通测度（不替换原硬端 \(z\)），得到
\[
T_{\rm small}\le T_{A^c}+2\int 1_A\,d\mathcal T(\omega,x,y,z)
\int 1_{D_K(x,y)}(z')\,\Pi_{x,y}(dz').
\tag{I2}
\]
所有积分非负，可用 Tonelli；原可测核、选择器及门沿用此前定义。这一表示把同一原行交通附加一个归一化的第三来源 \(z'\)，并未假定 \(z'\) 满足原捕获 \(z\in Q_R(x)\) 的门，也没有对 \(z'\) 重选未来参数。原门仍全部作用在原变量上。

在低分支，由实际重尾门还可读出
\[
p<\frac{2Kq}{e}<\frac{2K c_j^{n/2}}{\ell g^n}.
\tag{I3}
\]
I3 是核密度的上界，不能当作后验来源总质量或接收体积上界。没有证明 \(T_{A^c}\) 可按小接收费用支付，也没有证明 I2 的三来源积分为根阶。

本轮没有新增已付款项。R115 的大父费用、全部旧来源费、外层 \(\Lambda=128/119\) 和一般余项预算均保持原样。I2 只有在两项都得到真实整体估计后才能用于闭合，不能只估高分支。不同来源费用不可无条件取 max，原 \(1/e\)、真实 \(dx\)、种子平均以及尺寸/尺度/分层费用均须保留。

# 数值协议（保留执行前状态文字；实际执行见后文）

# R116 冻结有理证书协议（实现已写，暂不执行）

本任务依L03精确残差工作流，纯标准Python/Fraction。只认证exp(1/2)及给定候选因子B=21exp(1/2)/32的有理包围、固定矩形几何和12行幂证书；不认证真实积分比、付款、FULL或一般闭合。无浮点指数、渐近拟合、积分、随机、外部依赖或旧轮执行。

## 解析依据与界

令a_k=(1/2)^k/k!，S_M=Σ_(k=0)^M a_k。M≥1时next=a_(M+1)，r=1/[2(M+2)]。所有更后项相邻比≤r，因此准确有理区间

`S_M ≤ exp(1/2) ≤ S_M + next/(1−r)`。

程序一条路径按term/(2k)递推计算S；另按Fraction(1,2)^k/factorial(k)作独立有限和核对。尾上界来自上述无限级数解析比较，不声称有限self-check验证了无限所有项。保存基础两端完整Fraction、next/r/tail及正残差；核tail*(1−r)=next、嵌套上下界方向。

给定s=1/4，current因子下界3/4，C下界7/8，(3/4)(7/8)=21/32；B乘exp(1/2)。对严格阈值27/25，用lower>27/25为CERTIFIED_GT、upper≤阈值为CERTIFIED_NOT_GT，其余UNDECIDED。跨阈值是证书精度不足，不是数学失败。并核B/8的upper<1。

## 给定矩形几何与scope

归一b=1,a=1/2。矩形各轴x_i∈(3/8,1/2)，体积(1/8)^n；一般b下体积(b/8)^n。future中心各轴z'=-b/8，future L'∈[b/2,b]，其hard右端z'+L'/2≤3b/8。因此整个开矩形所有坐标严格outside future hard；上端包络与矩形下端相等不误判为inside，边界零测。不引入错误b/4作为全部future半边，不证明soft future核为0。

给定current P≤b^(−n)、wtilde≤1，则current矩形加权积分的准确上界为(1/8)^n。它与代理量(B/8)^n不同：B^n是候选逐坐标比值因子，(B/8)^n仅该因子乘归一化矩形体积，不是实际积分比或付款。当前两因子下界及P/wtilde上界是任务提供的解析前提，不用有限字段伪造实际原门。

## 三阶段菜单及self-check

- 初步：n={1,2,4,8},M=8，4行，须能CERTIFIED_GT且B/8<1。
- 压力：固定n=1，M={1,2,3,4}，4行。M1/M2预期UNDECIDED并正常保存；M3/M4预期CERTIFIED_GT。M3的B下端=553/512，与27/25准确残差1/12800>0，独立端点self-check；M1 exp上端33/20，M2 exp上端277/168亦精确核。
- 扩大：n={32,128,512,1024},M=24，4行。仅正有理端点幂计算，不拟合指数或扩大参数。须CERTIFIED_GT且代理上端<1。

总12唯一(stage,n,M)行；基础证书M={1,2,3,4,8,24}共6。每行实际算B_lower^n/B_upper^n与(B_lower/8)^n/(B_upper/8)^n，核顺序、非负及代理上端<1。初/扩大行实际核lower比阈值幂严格大，压力保留真实分类。

n≤8完整保存幂端点。n≥32保存每端点的完整基础Fraction引用、指数、分子/分母bit数及可复现SHA256；hash编码明确为约分Fraction的ASCII `numerator/denominator`（包括分母1）。指数标签不是数值检查，producer内部仍实际Fraction求幂、比较和hash。基础exp/B/Bover8端点全部完整保存，可据来源重建所有幂界。current_weighted_rectangle_upper=(1/8)^n另单独保存准确Fraction与不等式来源，不等同代理。

## 完成与失败

expected/actual从保存stage rows核唯一键、12/6菜单完整性。基础界方向/self-check、几何包络、幂顺序、初/扩大阈值失败为UNKNOWN非零，保存精确样本和已完成rows；压力按预定UNDECIDED不记失败。顶层FINITE_PROTOCOL_PASS仅指该有限证书程序通过；压力undecided计数单列。

一个自含numeric.py，默认stdout确定性JSON，无时间/模式/RNG字段；--record以xb排他创建numeric_output.json，不覆写旧证据。协议hash仅构建provenance，运行不读协议或旧资产。当前只写源码并作AST/文本静查，不导入/执行producer；父静态审PASS后才由父正式record/replay。actual_integral_ratio=NOT_COMPUTED、actual_payment=NOT_CERTIFIED、original_FULL_realizability=UNKNOWN、general_closure=NOT_CLAIMED必须保留。完成停工。

# R116 保存证据审查 — PASS

仅读取保存的numeric_output.json、execution_receipt.json、冻结协议及源码必要字段；未导入/执行producer、求积或重跑实验。源码由本代理编写，执行前完整静审由父代理完成；本稿是保存结果一致性审核，不冒称第二份独立源码审查。

输出实读32,338B，SHA256 `60d0489cb1ed1da8658438caad573f4102d9efeae0ac8680b760966e483029c3`；实际源码SHA256 `8393a21092d68d0389d4bc030a784c985125372bade7fdad6a57be998a8ea1c4` 与回执一致。协议实hash `09be438784cc6560c88fd3e84092d330dbe723391d1ce0ac41d2192b9c787b87` 与源码/输出provenance相同。回执记Python3.14.6、record1与isolated replay1，两exit0、stderr空、字节一致，合计0.17507825秒。

三阶段各4行、总12唯一行，6基础证书齐全；actual=expected=receipt counts。29项程序checks全部true，failures为空。顶层FINITE_PROTOCOL_PASS是有限证书程序通过，**不把两项压力UNDECIDED改称失败或已证负例**。

压力n=1、M1的B−27/25区间为[-153/1600,9/3200]，M2为[-87/6400,13/6400]，均跨0，保存UNDECIDED。M3下端553/512，严格残差1/12800>0；M4、初步M8及扩大M24亦CERTIFIED_GT。S_M与geometric tail基础端点、next/r/tail完整保存；tail上界的无限级数依据是解析相邻比控制，29有限checks不替代该解析论证。

每行B^n及(B/8)^n端点由实际Fraction幂计算。保存数据中的base interval引用、指数、基础端点全部一致；对n≤8打印的完整端点独立核其约分ASCII numerator/denominator哈希及分子/分母bit数，无差异。n≥32的大幂不重新计算，保存完整基础端点+指数+bit数+实际值哈希足以按冻结源码复现；父单文件回放字节一致提供该producer执行证据。

几何字段正确采用future中心−b/8、L'∈[b/2,b]，归一b=1的右端上帽3/8，与开矩形下端相同；x_i>3/8使future hard全部outside，边界零测。不误用最小半边b/4控制全部future，不声称future soft为0。

候选B因子来自给定(3/4)(7/8)exp(1/2)。B^n是比值因子证书，(B/8)^n只乘归一化矩形体积，所有行都标明不是实际积分比/付款。current加权矩形上界另存(1/8)^n，来源P≤b^(-n)、wtilde≤1，与代理量分列。保存状态actual_integral_ratio=NOT_COMPUTED、actual_payment=NOT_CERTIFIED、FULL_UNKNOWN/general NOT_CLAIMED正确保留；没有浮点指数拟合或将有限证书推广为一般闭合。

未发现保存结果/协议/回执不一致；完成停工，不覆盖任何现有证据。

# R116 三点核比较的独立命题筛查

**结论：按原合法软度域 \(s'\in[s,1]\)，候选必要下界严格成立。** 尚未读取本轮作者新稿或正体积邻域证明，只使用定义和初等非负积分。本稿只审核此逐点核命题，不认证原 FULL 实例，不否定一般研究路线。未执行数值、Git、PDF 或新代理；只写本文件。

准确参数为整数 \(n\ge1\)、\(a>0\)、\(b=2a\)，\(s=1/4\)，每坐标 \(y_i=0\)、\(z'_i=-b/8\)、\(x_i=7b/16\)。未来上确界必须为 \(s'\in[1/4,1]\)、\(L'\in[a,b]\)。如果只写 \(s'\ge s\) 而不限制原 soft 参数域，允许无上界实数，则本例未来核上确界为无穷，不能得到所声称的必要下界；正式稿须明确合法域。

## 当前核与重叠权重

非负 Tonelli 给 \(\int_{\mathbb R}w(v)dv=\int_0^12t\,dt=1\)，故 \(0\le\phi=h*w\le1\)，\(F=\max(h,\phi)\le1\)，因此 \(C(d)\le1\) 及权重不再需额外 min 的定义正确。

\(x_i/b=7/16<1/2\) 严格处于当前硬核心内，所以
\[
P_{1/4,b}(x-y)\ge\left({3\over4b}\right)^n.
\tag{Q1}
\]
\(F\ge h\) 给两个长度一的区间重叠下界，\(d=1/8\) 时重叠长度 \(7/8\)，故
\[
\widetilde w=C(1/8)^n\ge(7/8)^n,
\qquad P_{1/4,b}(x-y)\widetilde w
\ge\left({21\over32b}\right)^n.
\tag{Q2}
\]

## 未来尺度上确界

未来各坐标距离准确为 \(x_i-z'_i=9b/16\)。记 \(v=(9b/16)/L'\)，则 \(v\in[9/16,9/8]\)，对全部未来尺度严格 \(v>1/2\)，没有硬核闭端面的等号支路。故未来每坐标因子为 \(s'\phi(v)\)，其 soft 上确界在合法端点 \(s'=1\) 取得；共同尺度和共同 soft 度没有被坐标独立化。

对任何 \(v\ge1/2\)，直接卷积换元给
\[
\phi(v)=\int_0^1t(1-e^{-1/t})e^{-(v-1/2)/t}dt
\le\frac12e^{-(v-1/2)},
\qquad
2v\phi(v)\le v e^{-(v-1/2)}\le e^{-1/2}.
\tag{Q3}
\]
最后一项的导数符号由 \(1-v\) 决定，最大值在 \(v=1\)；这个点也在实际未来尺度区间内。有限端点与一般 \(v\ge1/2\) 上界均合法。

归一化需用准确距离：\(1/L'=v/(9b/16)\le2v/b\)，**不应写成等式**。这给安全的松上界
\[
\sup_{\substack{1/4\le s'\le1\\ a\le L'\le b}}
P_{s',L'}(x-z')
\le\left({e^{-1/2}\over b}\right)^n.
\tag{Q4}
\]
每个尺度的同一坐标表达均有这一上界，故合法控制整个共同尺度上确界，没有遗漏未来的小尺度。

## 必要常数及范围

若所给逐点比较在这些参数上成立，Q2/Q4 必须给
\[
K_n\ge\left({21e^{1/2}\over32}\right)^n
>\left({27\over25}\right)^n=1.08^n.
\tag{Q5}
\]
严格常数无需数值求值：正指数级数至四次给
\(e^{1/2}>1+1/2+1/8+1/48+1/384=211/128\)，而
\(21\cdot211/4096=4431/4096>27/25\)（交叉乘差为 \(183>0\)）。\(n=1\) 与全部正整数均覆盖。

这证明该特定三点逐点核比较不能有次指数 \(K_n\)。单个点的核算术不自动认证正体积邻域，也不认证完整原 FULL 交通或否定其它整体付款方式。后续正体积稿需另审邻域、统一未来尺度界及其准确量词；本次不展开。

筛查已交接父代理，等待作者冻结邻域正文与授权。

## `integration.md` I1–I3 全文独审

**结论：I1–I3 PASS。** 已按授权阅读全文；没有阅读尚未到达的 Astra 正体积稿，不把以上单点比较变成原 FULL 反例。此模块是原交通的表示与必要分支条件，没有新增付款。

**概率核及 I1。** \(e=e_j(y,g)\) 是原 S14 支持上同一 \(\widetilde w_j\) 和 \(Z_j\) 的加权 \(\nu\) 质量。原严格重门给 \(e>\ell q c_j^{-n/2}g^n>0\)，而 \(0\le\widetilde w_j\le1\)、\(\nu\le f\) 和完整输入有限质量给 \(e\le\|\nu\|<\infty\)。故 \(\Pi\) 的分母合法、总质量准确为一。它只需定义在实际原交通支持上；若要求全域核，可在 \(e=0\) 的原交通零支持部分任意延拓，不影响本稿积分。不得删去 \(1/e\) 或改成无归一化的独立 \(\nu\) 来源。

\((1,b)\) 固定且属于原 FIRST 的合法共同 future 族，故 \(\int Q_x\,d\nu\le P_{1,b}f(x)\le q\)。当前 \(\nu\) 与来源分解可依原种子，此不等式逐种子由正支配成立，不需要独立性。坏集使用严格 \(p\widetilde w_j>KQ_x\)，因此 \(Z_j\) 内补集恰满足非严格反向不等式；积分给
\(pe(1-\Pi(D_K))\le K\int Q_xd\nu\le Kq\)。在 \(pe=0\) 时，由 \(e>0\) 可知 \(p=0\)，左端零；\(K,q>0\) 使高分支自动排除这种情形，没有除以零。

**I2。** 高集 \(A=\{pe\ge2Kq\}\) 含等号，I1 给 \(\Pi(D_K)\ge1/2\)。原质量精确分成 \(T_A+T_{A^c}\)，故仅对高集乘二就得到 I2，没有遗漏低集。新三来源测度准确为
\(\mathbf1_A\mathbf1_{D_K}(z')\,d\mathcal T(\omega,x,y,z)\Pi_{\omega,x,y}(dz')\)。所有原变量和历史门继续保留，真实 \(dx\)、种子平均及 \(1/e\) 均在此测度中；不是用新 \(z'\) 替换原捕获 \(z\)。新点只继承概率核明确的承载条件，不能获得原 \(z\in Q_R(x)\)、原接受 LCA 或完整 FULL/CP/GP 资格。正文准确说明这一限制；未来测试仍是固定 \((1,b)\)，不是依 \(z'\) 重选。

**I3 与预算边界。** \(A^c\) 是严格 \(pe<2Kq\)，除以有限正 \(e\)，再用其原严格重门，准确给两个严格号
\(p<2Kq/e<2Kc_j^{n/2}/(\ell g^n)\)。这只限制点态核密度，不是来源总质量或 receiver 面积估计；没有支付低分支。I2 的三来源高分支也没有根阶费用结论。本次无新增 \(X\) 或来源费用，R115 已登记大父费、所有旧费及原 \(\Lambda\) 位置保持。只有两项都获真实整体估计后才可回代，不以来源支持相交为由无条件取 max。

审核完成，等待作者正体积统一矩形稿。未执行数值、Git、PDF 或新代理，未修改作者文件。

## 冻结 `astra_first.md` F1–F16 全文独审

按父授权读取冻结全文，实读 SHA256 与通知一致：`6ae881d0192397992bb019399a8a8e0454f0c4d929959c4dc0e81cb78bd48f7e`。

**最终结论：F1–F16 全文 PASS，与已审 I1–I3 一致；无需作者修订。** 只核原定义、正体积统一比较及真实交通接口，不运行数值、producer、积分程序、Git、PDF 或新代理。

**F1–F8：PASS。** 合法未来域明确为 \(s\le s'\le1\)，消除了先前筛查指出的无上界 soft 参数歧义。取 \(L=R=g=b\)、\(j=0\) 准确给 \(\widetilde w=C(1/8)^n\)。整个开矩形 \(B_b=(3b/8,b/2)^n\) 内，当前每坐标严格处于硬核心，未来距离 \(x_i-z'_i=x_i+b/8>b/2\) 则在全部 \(L'\le b\) 下严格处于硬核心外。因 \(b/L'<2(x_i-z'_i)/L'\)，原尾表示与 \(2u\phi(u)\le e^{-1/2}\) 对全部共同未来尺度和 soft 度提供统一 F7，而非只控制一个参数。矩形体积准确为 \(b^n8^{-n}\)。F8 的指数必要常数正确，初等指数级数已足够严格证明 \(B_*>1\)，本审先前还核出 \(B_*>1.08\)。正文正确限定：这排除特定统一逐点核比较，未构造实际 FIRST/FULL 输入，不否定积分路线。

**F9：PASS。** 下界是当前核 \((3/(4b))^n\)、权重 \((7/8)^n\) 和真实矩形体积 \(b^n8^{-n}\) 的乘积，准确为 \((21/256)^n\)。上界由当前核不超过 \(b^{-n}\) 与权重不超过一得到 \(8^{-n}\)。没有把相对常数 \(B_*^n\) 与这份绝对核积分拼成未证明的实际积分比。

**F10：PASS，只有这份局部限制的价。** 先固定 seed，对原软端只乘 \(\mathbf1_{\{x-y\in B_b\}}\)，并保留 \(s(x)=1/4,L(x)=b\) 的实际选择器限制。使用逐原软集合的 \(q^{-1}P_{1/4,b}\beta_V\) 支配及 \(h_R\nu_V\le4\lambda\le C_hq\)，得到 \(C_h\) 乘 \(\int\beta_V(dy)\int\mathbf1_{B_b}(x-y)P_{1/4,b}(x-y)dx\)。扩至全空间后，每个 \(y\) 的内积分至多 \(8^{-n}\)；不交原叶的 \(\beta_V\) 质量准确相加成为 \(W_\beta\)。因此没有额外叶数或 source 重复费，也无需后验独立。当前矩形随软点的唯一平移已由这一 Tonelli 正确计算；若另对不同参数或第三来源索引产生的一族矩形求和，则必须另证复用预算，不能重复领取 F10。本式没有证明该 FULL 子交通非零，没有被插入主账作为新全局付款，也没有删除旧费用。

**F11–F15：PASS。** 使用当前同一 \(V,j,g,\widetilde w,\nu_V\) 定义 \(e\)，保留其原 heavy 门和全部 seed 依赖。固定 future 测试 \((1,b)\) 的积分逐 seed 受完整 \(f\) 的 FIRST 上限 \(q\) 控制；没有对来源点取 future 上确界后再积分。严格坏集的等号归补集，F14 正向不等式及高分支 \(b_K/e\ge1/2\) 正确。\(p=0\) 时坏集空；\(e=0\) 的归一化取零只用于原实际交通零支持或非高分支，实际 S14 重尾支持上 \(e\) 有限且严格正。低分支 F15 的两个严格号与 I3 一致，不被转换为后验质量或接收体积帽。

**F16：PASS。** 原逐软集合正支配使逐 seed、逐原叶的交通相对于
\(q^{-1}p(x,y)h_R(x-z)dx\,d\beta_V(y)d\nu_V(z)\)
有可测 RN 密度 \(0\le a_\omega\le1\)。这是原相关联合核的支配表示，不是假设两后验独立；原 FULL/FIRST/CP/GP/deep、receiver 门及历史资格仍在 \(a_\omega\) 中，不活动行置零。全局式按同一原叶求和并保留 seed 平均；内层第三来源必须取这一 \(V\) 的 \(\nu_V\)，其归一化分母正是同一加权量 \(e=\int_ZW\,d\nu_V\)。没有改用 \(\beta_V\) 总质量、删除 \(1/e\)、重选 future 或将 \(z'\) 赋予原 \(z\) 的硬捕获/接受 LCA 资格。高三来源整体积分与低 \(pe\) 补项均明确尚未付款。

本轮准确成果是正体积上的特定逐点比较障碍，以及 FIRST 对加权坏集的必要约束；局部绝对核费与整体三来源预算保持区分。F16/I2 没有一般根阶估计，一般目标继续 **UNPROVED**。审计完成，停止本任务。

# 复现方法与范围

将下列 REPRO-FILE-BEGIN 标记对应代码块按标记字节数提取为同名文件，
核对 SHA256 后运行 `python3 numeric.py`，stdout 应与保存 numeric_output.json 逐字节一致。
不需第三方依赖。默认命令不写文件；`--record` 采用排他创建，已有结果时不会覆盖。
运行只复现冻结的有限有理证书，不认证 FIRST/FULL 交通实现性或一般根阶上界。
只保留 LaTeX 文本，未编译 PDF。证明引用的 R114/R115 原交通定义及已付账见相邻轮次归档；
本轮没有删除或替换任何旧来源费用、真实测度或原门。

<!-- REPRO-FILE-BEGIN name="numeric.py" bytes="10900" sha256="8393a21092d68d0389d4bc030a784c985125372bade7fdad6a57be998a8ea1c4" -->
````python
"""R116 exact finite certificates. No construction occurs on import."""
from fractions import Fraction as F
from pathlib import Path
import argparse
import hashlib
import json
import math
import sys

PROTOCOL_SHA256 = "09be438784cc6560c88fd3e84092d330dbe723391d1ce0ac41d2192b9c787b87"
THRESHOLD = F(27, 25)
FACTOR = F(21, 32)
MENU = (("initial", (1, 2, 4, 8), (8,)),
        ("pressure", (1,), (1, 2, 3, 4)),
        ("expanded", (32, 128, 512, 1024), (24,)))


def text(x):
    return str(x)


def check(state, name, passed, details):
    item = {"name": name, "pass": bool(passed), "details": details}
    state["checks"].append(item)
    if not passed:
        state["failures"].append(item)


def classify(lo, hi):
    if lo > THRESHOLD:
        return "CERTIFIED_GT"
    if hi <= THRESHOLD:
        return "CERTIFIED_NOT_GT"
    return "UNDECIDED"


def exponential_certificate(M, state):
    if M < 1:
        raise ValueError("M must be at least one")
    term = F(1)
    partial = term
    for k in range(1, M + 1):
        term /= 2 * k
        partial += term
    direct = sum((F(1, 2)**k / math.factorial(k)
                  for k in range(M + 1)), F(0))
    next_term = term / (2 * (M + 1))
    ratio_cap = F(1, 2 * (M + 2))
    tail = next_term / (1 - ratio_cap)
    upper = partial + tail
    blo, bhi = FACTOR * partial, FACTOR * upper
    check(state, "finite sum and geometric tail arithmetic",
          partial == direct and 0 < ratio_cap < 1 and next_term > 0
          and tail > next_term and tail * (1 - ratio_cap) == next_term,
          {"M": M, "finite_sum": text(partial), "independent_sum": text(direct),
           "next_term": text(next_term), "ratio_cap": text(ratio_cap),
           "tail_upper": text(tail), "tail_minus_next": text(tail-next_term)})
    check(state, "B base ordered and volume proxy below one",
          0 < blo <= bhi and bhi / 8 < 1,
          {"M": M, "B_lower": text(blo), "B_upper": text(bhi),
           "one_minus_proxy_upper": text(1-bhi/8)})
    return {"M": M, "exp_half": [text(partial), text(upper)],
            "next_term": text(next_term), "ratio_cap": text(ratio_cap),
            "tail_upper": text(tail), "B": [text(blo), text(bhi)],
            "B_over_8": [text(blo/8), text(bhi/8)],
            "B_minus_threshold": [text(blo-THRESHOLD), text(bhi-THRESHOLD)],
            "threshold_class": classify(blo, bhi),
            "analytic_tail_reason": "All ratios after a_(M+1) are <= 1/[2(M+2)]; sum the geometric majorant."}


def endpoint_certificate(value, base, exponent, full):
    # Hash the actual computed reduced Fraction, not the expression label.
    canonical = f"{value.numerator}/{value.denominator}"
    result = {"base": text(base), "exponent": exponent,
              "numerator_bits": value.numerator.bit_length(),
              "denominator_bits": value.denominator.bit_length(),
              "fraction_ascii_sha256": hashlib.sha256(canonical.encode("ascii")).hexdigest()}
    if full:
        result["fraction"] = text(value)
    return result


def power_interval(base_pair, n, ref):
    lo, hi = base_pair
    actual_lo, actual_hi = lo**n, hi**n
    result = {"base_interval_ref": ref, "power": n,
              "lower": endpoint_certificate(actual_lo, lo, n, n <= 8),
              "upper": endpoint_certificate(actual_hi, hi, n, n <= 8)}
    return result, actual_lo, actual_hi


def geometry(state):
    b, a, center = F(1), F(1, 2), F(-1, 8)
    rect_lo, rect_hi = F(3, 8), F(1, 2)
    future_right_min = center + a/2
    future_right_max = center + b/2
    check(state, "open rectangle outside every future hard cube",
          0 < a <= b and future_right_min <= future_right_max == rect_lo
          and rect_lo < rect_hi and rect_hi-rect_lo == F(1, 8),
          {"future_L_range": [text(a), text(b)], "future_center": text(center),
           "right_endpoint_range": [text(future_right_min), text(future_right_max)],
           "rectangle_open_interval": [text(rect_lo), text(rect_hi)],
           "reason": "L'<=b implies z'+L'/2<=3b/8; every open-rectangle coordinate is strictly larger."})
    check(state, "given current and C lower factors multiply exactly",
          (1-F(1, 4))*F(7, 8) == FACTOR,
          {"s": "1/4", "delta_z_magnitude": "1/8", "current_lower": "3/4",
           "C_lower": "7/8", "product": text(FACTOR),
           "role": "Given analytic kernel lower-factor premises; not a reconstructed original gate."})
    return {"b": text(b), "a": text(a), "rectangle_axis_open": [text(rect_lo), text(rect_hi)],
            "rectangle_volume_formula": "(b/8)^n", "boundary_measure": "ZERO",
            "future_center": text(center), "future_L_range": [text(a), text(b)],
            "future_hard_right_endpoint_upper": text(future_right_max),
            "future_hard_all_outside": True, "future_soft_zero": "NOT_CLAIMED"}


def build():
    if hasattr(sys, "set_int_max_str_digits"):
        sys.set_int_max_str_digits(0)
    state = {"checks": [], "failures": []}
    stages = {name: [] for name, _, _ in MENU}
    certs = {}
    current = {"stage": "startup"}
    geometry_record = None
    try:
        geometry_record = geometry(state)
        for M in (1, 2, 3, 4, 8, 24):
            current = {"stage": "base_certificate", "M": M}
            certs[str(M)] = exponential_certificate(M, state)
        check(state, "independent tail endpoint self checks",
              F(certs["1"]["exp_half"][1]) == F(33, 20)
              and F(certs["2"]["exp_half"][1]) == F(277, 168)
              and F(certs["3"]["B"][0]) == F(553, 512)
              and F(certs["3"]["B_minus_threshold"][0]) == F(1, 12800),
              {"M1_upper_expected": "33/20", "M2_upper_expected": "277/168",
               "M3_B_lower_expected": "553/512", "M3_positive_residual_expected": "1/12800"})
        ordered = [certs[str(M)] for M in (1, 2, 3, 4, 8, 24)]
        check(state, "nested rational exponential intervals",
              all(F(x["exp_half"][0]) <= F(y["exp_half"][0])
                  and F(y["exp_half"][1]) <= F(x["exp_half"][1])
                  for x, y in zip(ordered, ordered[1:])), {"M_order": [1, 2, 3, 4, 8, 24]})
        for stage, dimensions, degrees in MENU:
            for n in dimensions:
                for M in degrees:
                    current = {"stage": stage, "n": n, "M": M}
                    cert = certs[str(M)]
                    blo, bhi = map(F, cert["B"])
                    expected_class = "UNDECIDED" if stage == "pressure" and M in (1, 2) else "CERTIFIED_GT"
                    Bpower, pl, ph = power_interval((blo, bhi), n, f"{M}.B")
                    proxy, vl, vh = power_interval((blo/8, bhi/8), n, f"{M}.B_over_8")
                    upper = F(1, 8)**n
                    row = {"key": [stage, n, M], "base_certificate_ref": str(M),
                           "threshold_class": cert["threshold_class"], "B_power_interval": Bpower,
                           "factor_times_rectangle_volume_interval": proxy,
                           "normalized_rectangle_volume": text(upper),
                           "current_weighted_rectangle_upper": text(upper),
                           "weighted_upper_premises": ["P<=b^(-n)", "wtilde<=1", "rectangle volume=(b/8)^n"],
                           "proxy_is_actual_integral_ratio": False, "proxy_is_actual_payment": False}
                    stages[stage].append(row)
                    check(state, "row actual powers, threshold and damping certificate",
                          0 < pl <= ph and 0 < vl <= vh < 1
                          and cert["threshold_class"] == expected_class
                          and (expected_class != "CERTIFIED_GT" or pl > THRESHOLD**n)
                          and upper == F(1, 8**n),
                          {"key": row["key"], "threshold_class": cert["threshold_class"],
                           "expected_class": expected_class, "B_power_ordered": pl <= ph,
                           "proxy_upper_below_one": vh < 1,
                           "current_upper_is_volume_only": text(upper)})
    except Exception as exc:
        check(state, "construction exception with partial records", False,
              {"sample": current, "error_type": type(exc).__name__, "error": str(exc)})
    actual_keys = [tuple(row["key"]) for rows in stages.values() for row in rows]
    expected_keys = {(stage, n, M) for stage, ns, ms in MENU for n in ns for M in ms}
    check(state, "fixed menu and all base certificates complete",
          set(actual_keys) == expected_keys and len(actual_keys) == 12
          and set(certs) == {"1", "2", "3", "4", "8", "24"},
          {"actual_rows": len(actual_keys), "expected_rows": 12,
           "actual_base_degrees": sorted(map(int, certs)), "expected_base_degrees": [1, 2, 3, 4, 8, 24]})
    undecided = [row["key"] for row in stages["pressure"] if row["threshold_class"] == "UNDECIDED"]
    return {"status": "UNKNOWN" if state["failures"] else "FINITE_PROTOCOL_PASS",
            "scope": "Finite exact exponential-factor and given rectangle certificates only.",
            "original_FULL_realizability": "UNKNOWN", "general_closure": "NOT_CLAIMED",
            "actual_integral_ratio": "NOT_COMPUTED", "actual_payment": "NOT_CERTIFIED",
            "provenance": {"protocol_sha256": PROTOCOL_SHA256, "role": "Static construction provenance; no runtime file authentication."},
            "analytic_inputs": {"exp_argument": "1/2", "B_multiplier": text(FACTOR), "threshold": text(THRESHOLD)},
            "geometry": geometry_record, "base_certificates": certs, "stages": stages,
            "hash_encoding": "Reduced Fraction ASCII numerator/denominator, including denominator 1.",
            "counts": {"expected": {"initial": 4, "pressure": 4, "expanded": 4, "base_certificates": 6},
                       "actual_completed": {**{k: len(v) for k, v in stages.items()}, "base_certificates": len(certs)},
                       "integrity_checks": len(state["checks"]), "failed_checks": len(state["failures"]),
                       "pressure_undecided": len(undecided)},
            "pressure_undecided_keys": undecided, "integrity_checks": state["checks"], "failures": state["failures"]}


def main(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument("--record", action="store_true")
    args = parser.parse_args(argv)
    payload = build()
    data = (json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=True)+"\n").encode("utf-8")
    if args.record:
        try:
            with Path(__file__).resolve().with_name("numeric_output.json").open("xb") as stream:
                stream.write(data)
        except FileExistsError:
            sys.stdout.buffer.write(data)
            return 2
    sys.stdout.buffer.write(data)
    return 0 if payload["status"] == "FINITE_PROTOCOL_PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
````
<!-- REPRO-FILE-END -->

<!-- REPRO-FILE-BEGIN name="numeric_output.json" bytes="32338" sha256="60d0489cb1ed1da8658438caad573f4102d9efeae0ac8680b760966e483029c3" -->
````json
{"actual_integral_ratio":"NOT_COMPUTED","actual_payment":"NOT_CERTIFIED","analytic_inputs":{"B_multiplier":"21/32","exp_argument":"1/2","threshold":"27/25"},"base_certificates":{"1":{"B":["63/64","693/640"],"B_minus_threshold":["-153/1600","9/3200"],"B_over_8":["63/512","693/5120"],"M":1,"analytic_tail_reason":"All ratios after a_(M+1) are <= 1/[2(M+2)]; sum the geometric majorant.","exp_half":["3/2","33/20"],"next_term":"1/8","ratio_cap":"1/6","tail_upper":"3/20","threshold_class":"UNDECIDED"},"2":{"B":["273/256","277/256"],"B_minus_threshold":["-87/6400","13/6400"],"B_over_8":["273/2048","277/2048"],"M":2,"analytic_tail_reason":"All ratios after a_(M+1) are <= 1/[2(M+2)]; sum the geometric majorant.","exp_half":["13/8","277/168"],"next_term":"1/48","ratio_cap":"1/8","tail_upper":"1/42","threshold_class":"UNDECIDED"},"24":{"B":["17162194006260414582979315355473/15861938061307935167789137920000","3125971051140289799042661011175443/2889138718309659619847307264000000"],"B_minus_threshold":["31300900047844601767046401873/15861938061307935167789137920000","5701235365857409607569166055443/2889138718309659619847307264000000"],"B_over_8":["17162194006260414582979315355473/126895504490463481342313103360000","3125971051140289799042661011175443/23113109746477276958778458112000000"],"M":24,"analytic_tail_reason":"All ratios after a_(M+1) are <= 1/[2(M+2)]; sum the geometric majorant.","exp_half":["17162194006260414582979315355473/10409396852733332453861621760000","3125971051140289799042661011175443/1895997283890714125524795392000000"],"next_term":"1/520469842636666622693081088000000","ratio_cap":"1/52","tail_upper":"1/510460807201346110718214144000000","threshold_class":"CERTIFIED_GT"},"3":{"B":["553/512","19943/18432"],"B_minus_threshold":["1/12800","911/460800"],"B_over_8":["553/4096","19943/147456"],"M":3,"analytic_tail_reason":"All ratios after a_(M+1) are <= 1/[2(M+2)]; sum the geometric majorant.","exp_half":["79/48","2849/1728"],"next_term":"1/384","ratio_cap":"1/10","tail_upper":"5/1728","threshold_class":"CERTIFIED_GT"},"4":{"B":["4431/4096","243747/225280"],"B_minus_threshold":["183/102400","2223/1126400"],"B_over_8":["4431/32768","243747/1802240"],"M":4,"analytic_tail_reason":"All ratios after a_(M+1) are <= 1/[2(M+2)]; sum the geometric majorant.","exp_half":["211/128","11607/7040"],"next_term":"1/3840","ratio_cap":"1/12","tail_upper":"1/3520","threshold_class":"CERTIFIED_GT"},"8":{"B":["17017969/15728640","2910072709/2689597440"],"B_minus_threshold":["155189/78643200","26537369/13447987200"],"B_over_8":["17017969/125829120","2910072709/21516779520"],"M":8,"analytic_tail_reason":"All ratios after a_(M+1) are <= 1/[2(M+2)]; sum the geometric majorant.","exp_half":["17017969/10321920","2910072709/1765048320"],"next_term":"1/185794560","ratio_cap":"1/20","tail_upper":"1/176504832","threshold_class":"CERTIFIED_GT"}},"counts":{"actual_completed":{"base_certificates":6,"expanded":4,"initial":4,"pressure":4},"expected":{"base_certificates":6,"expanded":4,"initial":4,"pressure":4},"failed_checks":0,"integrity_checks":29,"pressure_undecided":2},"failures":[],"general_closure":"NOT_CLAIMED","geometry":{"a":"1/2","b":"1","boundary_measure":"ZERO","future_L_range":["1/2","1"],"future_center":"-1/8","future_hard_all_outside":true,"future_hard_right_endpoint_upper":"3/8","future_soft_zero":"NOT_CLAIMED","rectangle_axis_open":["3/8","1/2"],"rectangle_volume_formula":"(b/8)^n"},"hash_encoding":"Reduced Fraction ASCII numerator/denominator, including denominator 1.","integrity_checks":[{"details":{"future_L_range":["1/2","1"],"future_center":"-1/8","reason":"L'<=b implies z'+L'/2<=3b/8; every open-rectangle coordinate is strictly larger.","rectangle_open_interval":["3/8","1/2"],"right_endpoint_range":["1/8","3/8"]},"name":"open rectangle outside every future hard cube","pass":true},{"details":{"C_lower":"7/8","current_lower":"3/4","delta_z_magnitude":"1/8","product":"21/32","role":"Given analytic kernel lower-factor premises; not a reconstructed original gate.","s":"1/4"},"name":"given current and C lower factors multiply exactly","pass":true},{"details":{"M":1,"finite_sum":"3/2","independent_sum":"3/2","next_term":"1/8","ratio_cap":"1/6","tail_minus_next":"1/40","tail_upper":"3/20"},"name":"finite sum and geometric tail arithmetic","pass":true},{"details":{"B_lower":"63/64","B_upper":"693/640","M":1,"one_minus_proxy_upper":"4427/5120"},"name":"B base ordered and volume proxy below one","pass":true},{"details":{"M":2,"finite_sum":"13/8","independent_sum":"13/8","next_term":"1/48","ratio_cap":"1/8","tail_minus_next":"1/336","tail_upper":"1/42"},"name":"finite sum and geometric tail arithmetic","pass":true},{"details":{"B_lower":"273/256","B_upper":"277/256","M":2,"one_minus_proxy_upper":"1771/2048"},"name":"B base ordered and volume proxy below one","pass":true},{"details":{"M":3,"finite_sum":"79/48","independent_sum":"79/48","next_term":"1/384","ratio_cap":"1/10","tail_minus_next":"1/3456","tail_upper":"5/1728"},"name":"finite sum and geometric tail arithmetic","pass":true},{"details":{"B_lower":"553/512","B_upper":"19943/18432","M":3,"one_minus_proxy_upper":"127513/147456"},"name":"B base ordered and volume proxy below one","pass":true},{"details":{"M":4,"finite_sum":"211/128","independent_sum":"211/128","next_term":"1/3840","ratio_cap":"1/12","tail_minus_next":"1/42240","tail_upper":"1/3520"},"name":"finite sum and geometric tail arithmetic","pass":true},{"details":{"B_lower":"4431/4096","B_upper":"243747/225280","M":4,"one_minus_proxy_upper":"1558493/1802240"},"name":"B base ordered and volume proxy below one","pass":true},{"details":{"M":8,"finite_sum":"17017969/10321920","independent_sum":"17017969/10321920","next_term":"1/185794560","ratio_cap":"1/20","tail_minus_next":"1/3530096640","tail_upper":"1/176504832"},"name":"finite sum and geometric tail arithmetic","pass":true},{"details":{"B_lower":"17017969/15728640","B_upper":"2910072709/2689597440","M":8,"one_minus_proxy_upper":"18606706811/21516779520"},"name":"B base ordered and volume proxy below one","pass":true},{"details":{"M":24,"finite_sum":"17162194006260414582979315355473/10409396852733332453861621760000","independent_sum":"17162194006260414582979315355473/10409396852733332453861621760000","next_term":"1/520469842636666622693081088000000","ratio_cap":"1/52","tail_minus_next":"1/26543961974469997757347135488000000","tail_upper":"1/510460807201346110718214144000000"},"name":"finite sum and geometric tail arithmetic","pass":true},{"details":{"B_lower":"17162194006260414582979315355473/15861938061307935167789137920000","B_upper":"3125971051140289799042661011175443/2889138718309659619847307264000000","M":24,"one_minus_proxy_upper":"19987138695336987159735797100824557/23113109746477276958778458112000000"},"name":"B base ordered and volume proxy below one","pass":true},{"details":{"M1_upper_expected":"33/20","M2_upper_expected":"277/168","M3_B_lower_expected":"553/512","M3_positive_residual_expected":"1/12800"},"name":"independent tail endpoint self checks","pass":true},{"details":{"M_order":[1,2,3,4,8,24]},"name":"nested rational exponential intervals","pass":true},{"details":{"B_power_ordered":true,"current_upper_is_volume_only":"1/8","expected_class":"CERTIFIED_GT","key":["initial",1,8],"proxy_upper_below_one":true,"threshold_class":"CERTIFIED_GT"},"name":"row actual powers, threshold and damping certificate","pass":true},{"details":{"B_power_ordered":true,"current_upper_is_volume_only":"1/64","expected_class":"CERTIFIED_GT","key":["initial",2,8],"proxy_upper_below_one":true,"threshold_class":"CERTIFIED_GT"},"name":"row actual powers, threshold and damping certificate","pass":true},{"details":{"B_power_ordered":true,"current_upper_is_volume_only":"1/4096","expected_class":"CERTIFIED_GT","key":["initial",4,8],"proxy_upper_below_one":true,"threshold_class":"CERTIFIED_GT"},"name":"row actual powers, threshold and damping certificate","pass":true},{"details":{"B_power_ordered":true,"current_upper_is_volume_only":"1/16777216","expected_class":"CERTIFIED_GT","key":["initial",8,8],"proxy_upper_below_one":true,"threshold_class":"CERTIFIED_GT"},"name":"row actual powers, threshold and damping certificate","pass":true},{"details":{"B_power_ordered":true,"current_upper_is_volume_only":"1/8","expected_class":"UNDECIDED","key":["pressure",1,1],"proxy_upper_below_one":true,"threshold_class":"UNDECIDED"},"name":"row actual powers, threshold and damping certificate","pass":true},{"details":{"B_power_ordered":true,"current_upper_is_volume_only":"1/8","expected_class":"UNDECIDED","key":["pressure",1,2],"proxy_upper_below_one":true,"threshold_class":"UNDECIDED"},"name":"row actual powers, threshold and damping certificate","pass":true},{"details":{"B_power_ordered":true,"current_upper_is_volume_only":"1/8","expected_class":"CERTIFIED_GT","key":["pressure",1,3],"proxy_upper_below_one":true,"threshold_class":"CERTIFIED_GT"},"name":"row actual powers, threshold and damping certificate","pass":true},{"details":{"B_power_ordered":true,"current_upper_is_volume_only":"1/8","expected_class":"CERTIFIED_GT","key":["pressure",1,4],"proxy_upper_below_one":true,"threshold_class":"CERTIFIED_GT"},"name":"row actual powers, threshold and damping certificate","pass":true},{"details":{"B_power_ordered":true,"current_upper_is_volume_only":"1/79228162514264337593543950336","expected_class":"CERTIFIED_GT","key":["expanded",32,24],"proxy_upper_below_one":true,"threshold_class":"CERTIFIED_GT"},"name":"row actual powers, threshold and damping certificate","pass":true},{"details":{"B_power_ordered":true,"current_upper_is_volume_only":"1/39402006196394479212279040100143613805079739270465446667948293404245721771497210611414266254884915640806627990306816","expected_class":"CERTIFIED_GT","key":["expanded",128,24],"proxy_upper_below_one":true,"threshold_class":"CERTIFIED_GT"},"name":"row actual powers, threshold and damping certificate","pass":true},{"details":{"B_power_ordered":true,"current_upper_is_volume_only":"1/2410312426921032588580116606028314112912093247945688951359675039065257391591803200669085024107346049663448766280888004787862416978794958324969612987890774651455213339381625224770782077917681499676845543137387820057597345857904599109461387122099507964997815641342300677629473355281617428411794163967785870370368969109221591943054232011562758450080579587850900993714892283476646631181515063804873375182260506246992837898705971012525843324401232986857004760339316736","expected_class":"CERTIFIED_GT","key":["expanded",512,24],"proxy_upper_below_one":true,"threshold_class":"CERTIFIED_GT"},"name":"row actual powers, threshold and damping certificate","pass":true},{"details":{"B_power_ordered":true,"current_upper_is_volume_only":"1/5809605995369958062859502533304574370686975176362895236661486152287203730997110225737336044533118407251326157754980517443990529594540047121662885672187032401032111639706440498844049850989051627200244765807041812394729680540024104827976584369381522292361208779044769892743225751738076979568811309579125511333093243519553784816306381580161860200247492568448150242515304449577187604136428738580990172551573934146255830366405915000869643732053218566832545291107903722831634138599586406690325959725187447169059540805012310209639011750748760017095360734234945757416272994856013308616958529958304677637019181594088528345061285863898271763457294883546638879554311615446446330199254382340016292057090751175533888161918987295591531536698701292267685465517437915790823154844634780260102891718032495396075041899485513811126977307478969074857043710716150121315922024556759241239013152919710956468406379442914941614357107914462567329693696","expected_class":"CERTIFIED_GT","key":["expanded",1024,24],"proxy_upper_below_one":true,"threshold_class":"CERTIFIED_GT"},"name":"row actual powers, threshold and damping certificate","pass":true},{"details":{"actual_base_degrees":[1,2,3,4,8,24],"actual_rows":12,"expected_base_degrees":[1,2,3,4,8,24],"expected_rows":12},"name":"fixed menu and all base certificates complete","pass":true}],"original_FULL_realizability":"UNKNOWN","pressure_undecided_keys":[["pressure",1,1],["pressure",1,2]],"provenance":{"protocol_sha256":"09be438784cc6560c88fd3e84092d330dbe723391d1ce0ac41d2192b9c787b87","role":"Static construction provenance; no runtime file authentication."},"scope":"Finite exact exponential-factor and given rectangle certificates only.","stages":{"expanded":[{"B_power_interval":{"base_interval_ref":"24.B","lower":{"base":"17162194006260414582979315355473/15861938061307935167789137920000","denominator_bits":3317,"exponent":32,"fraction_ascii_sha256":"8467e6e3d8d2499d7f3a3c73334a2892acf465e3e57519a3ed4122563bfcae7c","numerator_bits":3321},"power":32,"upper":{"base":"3125971051140289799042661011175443/2889138718309659619847307264000000","denominator_bits":3557,"exponent":32,"fraction_ascii_sha256":"76fe25f6bd569988a83ee3809ed0deba8bb11a14022ac5d88d0afa2b718a22e6","numerator_bits":3561}},"base_certificate_ref":"24","current_weighted_rectangle_upper":"1/79228162514264337593543950336","factor_times_rectangle_volume_interval":{"base_interval_ref":"24.B_over_8","lower":{"base":"17162194006260414582979315355473/126895504490463481342313103360000","denominator_bits":3413,"exponent":32,"fraction_ascii_sha256":"43103f25d39d639d28c1a757d5138fc58117ed498e00d1b9b7b015ba5bb50c80","numerator_bits":3321},"power":32,"upper":{"base":"3125971051140289799042661011175443/23113109746477276958778458112000000","denominator_bits":3653,"exponent":32,"fraction_ascii_sha256":"e92b0735172812856ae1d547c7fa23451f06f1a5de66277f3e218398ba42544f","numerator_bits":3561}},"key":["expanded",32,24],"normalized_rectangle_volume":"1/79228162514264337593543950336","proxy_is_actual_integral_ratio":false,"proxy_is_actual_payment":false,"threshold_class":"CERTIFIED_GT","weighted_upper_premises":["P<=b^(-n)","wtilde<=1","rectangle volume=(b/8)^n"]},{"B_power_interval":{"base_interval_ref":"24.B","lower":{"base":"17162194006260414582979315355473/15861938061307935167789137920000","denominator_bits":13267,"exponent":128,"fraction_ascii_sha256":"489965bbedda3d34954aa1c19e2afd09adf112b0ebc089424390808345a53fc5","numerator_bits":13282},"power":128,"upper":{"base":"3125971051140289799042661011175443/2889138718309659619847307264000000","denominator_bits":14228,"exponent":128,"fraction_ascii_sha256":"fa1c3edc15770ccc3803896ac57d42e1c94a355fcda40b6dba3bc01dd98012c4","numerator_bits":14243}},"base_certificate_ref":"24","current_weighted_rectangle_upper":"1/39402006196394479212279040100143613805079739270465446667948293404245721771497210611414266254884915640806627990306816","factor_times_rectangle_volume_interval":{"base_interval_ref":"24.B_over_8","lower":{"base":"17162194006260414582979315355473/126895504490463481342313103360000","denominator_bits":13651,"exponent":128,"fraction_ascii_sha256":"f54da5c7235d481281b396eb5ac9f3ffacf1dc246267cce601051fc09298f98a","numerator_bits":13282},"power":128,"upper":{"base":"3125971051140289799042661011175443/23113109746477276958778458112000000","denominator_bits":14612,"exponent":128,"fraction_ascii_sha256":"8af321f34f68ce427a9cc994823df94120d76c8c7f7a4076302a18a1ab24c24b","numerator_bits":14243}},"key":["expanded",128,24],"normalized_rectangle_volume":"1/39402006196394479212279040100143613805079739270465446667948293404245721771497210611414266254884915640806627990306816","proxy_is_actual_integral_ratio":false,"proxy_is_actual_payment":false,"threshold_class":"CERTIFIED_GT","weighted_upper_premises":["P<=b^(-n)","wtilde<=1","rectangle volume=(b/8)^n"]},{"B_power_interval":{"base_interval_ref":"24.B","lower":{"base":"17162194006260414582979315355473/15861938061307935167789137920000","denominator_bits":53067,"exponent":512,"fraction_ascii_sha256":"e4cea6412b817ca27c80d192ec429146ac391de20f1358b2b1494c5d14c5b0a9","numerator_bits":53125},"power":512,"upper":{"base":"3125971051140289799042661011175443/2889138718309659619847307264000000","denominator_bits":56911,"exponent":512,"fraction_ascii_sha256":"c040fe33522293a0a130f637060d7d65e0d85fc56f10b36d2a90b1a9e0e53cf9","numerator_bits":56970}},"base_certificate_ref":"24","current_weighted_rectangle_upper":"1/2410312426921032588580116606028314112912093247945688951359675039065257391591803200669085024107346049663448766280888004787862416978794958324969612987890774651455213339381625224770782077917681499676845543137387820057597345857904599109461387122099507964997815641342300677629473355281617428411794163967785870370368969109221591943054232011562758450080579587850900993714892283476646631181515063804873375182260506246992837898705971012525843324401232986857004760339316736","factor_times_rectangle_volume_interval":{"base_interval_ref":"24.B_over_8","lower":{"base":"17162194006260414582979315355473/126895504490463481342313103360000","denominator_bits":54603,"exponent":512,"fraction_ascii_sha256":"93707d82776648d2abd91e5a814c9bc63b9bb5679b2cedb9142e926b25853c6f","numerator_bits":53125},"power":512,"upper":{"base":"3125971051140289799042661011175443/23113109746477276958778458112000000","denominator_bits":58447,"exponent":512,"fraction_ascii_sha256":"6b1512d854520a609a12e873378cf4206b85b8d6f1586a10f84c84baf1dc0a2b","numerator_bits":56970}},"key":["expanded",512,24],"normalized_rectangle_volume":"1/2410312426921032588580116606028314112912093247945688951359675039065257391591803200669085024107346049663448766280888004787862416978794958324969612987890774651455213339381625224770782077917681499676845543137387820057597345857904599109461387122099507964997815641342300677629473355281617428411794163967785870370368969109221591943054232011562758450080579587850900993714892283476646631181515063804873375182260506246992837898705971012525843324401232986857004760339316736","proxy_is_actual_integral_ratio":false,"proxy_is_actual_payment":false,"threshold_class":"CERTIFIED_GT","weighted_upper_premises":["P<=b^(-n)","wtilde<=1","rectangle volume=(b/8)^n"]},{"B_power_interval":{"base_interval_ref":"24.B","lower":{"base":"17162194006260414582979315355473/15861938061307935167789137920000","denominator_bits":106133,"exponent":1024,"fraction_ascii_sha256":"7f445987b87448f91a5fe6dbaa7311293feef89f387af60ff928483de73e7eb4","numerator_bits":106250},"power":1024,"upper":{"base":"3125971051140289799042661011175443/2889138718309659619847307264000000","denominator_bits":113822,"exponent":1024,"fraction_ascii_sha256":"82ff96e194e631dbd2428b3657b60c63910fffa30cb6b49d7b55a84789786d63","numerator_bits":113939}},"base_certificate_ref":"24","current_weighted_rectangle_upper":"1/5809605995369958062859502533304574370686975176362895236661486152287203730997110225737336044533118407251326157754980517443990529594540047121662885672187032401032111639706440498844049850989051627200244765807041812394729680540024104827976584369381522292361208779044769892743225751738076979568811309579125511333093243519553784816306381580161860200247492568448150242515304449577187604136428738580990172551573934146255830366405915000869643732053218566832545291107903722831634138599586406690325959725187447169059540805012310209639011750748760017095360734234945757416272994856013308616958529958304677637019181594088528345061285863898271763457294883546638879554311615446446330199254382340016292057090751175533888161918987295591531536698701292267685465517437915790823154844634780260102891718032495396075041899485513811126977307478969074857043710716150121315922024556759241239013152919710956468406379442914941614357107914462567329693696","factor_times_rectangle_volume_interval":{"base_interval_ref":"24.B_over_8","lower":{"base":"17162194006260414582979315355473/126895504490463481342313103360000","denominator_bits":109205,"exponent":1024,"fraction_ascii_sha256":"f890057b368f6b5c02f21b1086278147e71a37ce3f19fa039642c85e2ea658b4","numerator_bits":106250},"power":1024,"upper":{"base":"3125971051140289799042661011175443/23113109746477276958778458112000000","denominator_bits":116894,"exponent":1024,"fraction_ascii_sha256":"bdfa092ca815777531a1e7934888887dcadb4fb4c362792dd2bc3b5779a8e7de","numerator_bits":113939}},"key":["expanded",1024,24],"normalized_rectangle_volume":"1/5809605995369958062859502533304574370686975176362895236661486152287203730997110225737336044533118407251326157754980517443990529594540047121662885672187032401032111639706440498844049850989051627200244765807041812394729680540024104827976584369381522292361208779044769892743225751738076979568811309579125511333093243519553784816306381580161860200247492568448150242515304449577187604136428738580990172551573934146255830366405915000869643732053218566832545291107903722831634138599586406690325959725187447169059540805012310209639011750748760017095360734234945757416272994856013308616958529958304677637019181594088528345061285863898271763457294883546638879554311615446446330199254382340016292057090751175533888161918987295591531536698701292267685465517437915790823154844634780260102891718032495396075041899485513811126977307478969074857043710716150121315922024556759241239013152919710956468406379442914941614357107914462567329693696","proxy_is_actual_integral_ratio":false,"proxy_is_actual_payment":false,"threshold_class":"CERTIFIED_GT","weighted_upper_premises":["P<=b^(-n)","wtilde<=1","rectangle volume=(b/8)^n"]}],"initial":[{"B_power_interval":{"base_interval_ref":"8.B","lower":{"base":"17017969/15728640","denominator_bits":24,"exponent":1,"fraction":"17017969/15728640","fraction_ascii_sha256":"57c153d4a75477295c2534cd81fb5b7e87cc0f2ade6e5cf23d59bf3892f1d623","numerator_bits":25},"power":1,"upper":{"base":"2910072709/2689597440","denominator_bits":32,"exponent":1,"fraction":"2910072709/2689597440","fraction_ascii_sha256":"940c48af341a5b9df30ff727ef9bb220980ff9e91ab31dfa495f4e79092206dc","numerator_bits":32}},"base_certificate_ref":"8","current_weighted_rectangle_upper":"1/8","factor_times_rectangle_volume_interval":{"base_interval_ref":"8.B_over_8","lower":{"base":"17017969/125829120","denominator_bits":27,"exponent":1,"fraction":"17017969/125829120","fraction_ascii_sha256":"d94f32b0d8768a2f39decedcdd5024cecc63ce14eadd75670e236400ff9a48f3","numerator_bits":25},"power":1,"upper":{"base":"2910072709/21516779520","denominator_bits":35,"exponent":1,"fraction":"2910072709/21516779520","fraction_ascii_sha256":"230199a6eeb31d4e4f74cd36cd329b1782308fb33a6ed5cc8db6af79e8fdfdcf","numerator_bits":32}},"key":["initial",1,8],"normalized_rectangle_volume":"1/8","proxy_is_actual_integral_ratio":false,"proxy_is_actual_payment":false,"threshold_class":"CERTIFIED_GT","weighted_upper_premises":["P<=b^(-n)","wtilde<=1","rectangle volume=(b/8)^n"]},{"B_power_interval":{"base_interval_ref":"8.B","lower":{"base":"17017969/15728640","denominator_bits":48,"exponent":2,"fraction":"289611268884961/247390116249600","fraction_ascii_sha256":"f53fdd4e530f8a038e67b385e6f9b4c4fc84039270039876e873139856a3d445","numerator_bits":49},"power":2,"upper":{"base":"2910072709/2689597440","denominator_bits":63,"exponent":2,"fraction":"8468523171666598681/7233934389254553600","fraction_ascii_sha256":"7bd32cc948509d2f48cb706920e267f1211a4455a2edc57d997dd8e125b06b9d","numerator_bits":63}},"base_certificate_ref":"8","current_weighted_rectangle_upper":"1/64","factor_times_rectangle_volume_interval":{"base_interval_ref":"8.B_over_8","lower":{"base":"17017969/125829120","denominator_bits":54,"exponent":2,"fraction":"289611268884961/15832967439974400","fraction_ascii_sha256":"6a57c772d9cd7f9dd1156683bdd24cd656a97f366c5aab8c69e47c8a0e6a5cc5","numerator_bits":49},"power":2,"upper":{"base":"2910072709/21516779520","denominator_bits":69,"exponent":2,"fraction":"8468523171666598681/462971800912291430400","fraction_ascii_sha256":"4bdc882544d06f694298cb7c548a6bd52d1663646472a2052bbb0effbbc85252","numerator_bits":63}},"key":["initial",2,8],"normalized_rectangle_volume":"1/64","proxy_is_actual_integral_ratio":false,"proxy_is_actual_payment":false,"threshold_class":"CERTIFIED_GT","weighted_upper_premises":["P<=b^(-n)","wtilde<=1","rectangle volume=(b/8)^n"]},{"B_power_interval":{"base_interval_ref":"8.B","lower":{"base":"17017969/15728640","denominator_bits":96,"exponent":4,"fraction":"83874687065157179464251971521/61201869617990601969500160000","fraction_ascii_sha256":"5380dc0a0c9f027cb6ef3f9b60285c903ebb8ccdd6284d4978cbe79966229e75","numerator_bits":97},"power":4,"upper":{"base":"2910072709/2689597440","denominator_bits":126,"exponent":4,"fraction":"71715884709054107993057428703510939761/52329806748039651402832298335272960000","fraction_ascii_sha256":"3d72a2dd73112adfbab30aa77406a69a041c6f96e5211b84411b3e9ca82778ee","numerator_bits":126}},"base_certificate_ref":"8","current_weighted_rectangle_upper":"1/4096","factor_times_rectangle_volume_interval":{"base_interval_ref":"8.B_over_8","lower":{"base":"17017969/125829120","denominator_bits":108,"exponent":4,"fraction":"83874687065157179464251971521/250682857955289505667072655360000","fraction_ascii_sha256":"6cdc602438a0ae3623ce062702821fc8ab749a946678309f20763b064d2e88ad","numerator_bits":97},"power":4,"upper":{"base":"2910072709/21516779520","denominator_bits":138,"exponent":4,"fraction":"71715884709054107993057428703510939761/214342888439970412146001093981278044160000","fraction_ascii_sha256":"98aa02743a5ec6436db99e42bd0019f0ebcb13d3fbe508ef00d6945509a6f0fe","numerator_bits":126}},"key":["initial",4,8],"normalized_rectangle_volume":"1/4096","proxy_is_actual_integral_ratio":false,"proxy_is_actual_payment":false,"threshold_class":"CERTIFIED_GT","weighted_upper_premises":["P<=b^(-n)","wtilde<=1","rectangle volume=(b/8)^n"]},{"B_power_interval":{"base_interval_ref":"8.B","lower":{"base":"17017969/15728640","denominator_bits":192,"exponent":8,"fraction":"7034963130278045070979381636650316688523291579135395053441/3745668844737521111849365698223255035922880240025600000000","fraction_ascii_sha256":"fc91bfe641a328ffb2860514a8a0946ad872b501ef0f72d5827f6c54e8e0c5b1","numerator_bits":193},"power":8,"upper":{"base":"2910072709/2689597440","denominator_bits":251,"exponent":8,"fraction":"5143168119602340819864886786308868501593018465162010166770831779405370737121/2738408674287176235999004115708778786456312558352277980532117707161600000000","fraction_ascii_sha256":"8ca8ecf2dc6e71764ab1e9e74482a3eb37d94990cab57beae67a8ebb0dd22964","numerator_bits":252}},"base_certificate_ref":"8","current_weighted_rectangle_upper":"1/16777216","factor_times_rectangle_volume_interval":{"base_interval_ref":"8.B_over_8","lower":{"base":"17017969/125829120","denominator_bits":216,"exponent":8,"fraction":"7034963130278045070979381636650316688523291579135395053441/62841895272631854998056967782082365960765921129041336729600000000","fraction_ascii_sha256":"17b937cbb423ec952578969770e5c23256039d25afa6db30d2992f88ad8d708e","numerator_bits":193},"power":8,"upper":{"base":"2910072709/21516779520","denominator_bits":275,"exponent":8,"fraction":"5143168119602340819864886786308868501593018465162010166770831779405370737121/45942873824789601741422267834135174796595430354988771771431133710474910105600000000","fraction_ascii_sha256":"6684c58b6afacaf663c2394559aedf01d02d17e709815e799810588482f396e7","numerator_bits":252}},"key":["initial",8,8],"normalized_rectangle_volume":"1/16777216","proxy_is_actual_integral_ratio":false,"proxy_is_actual_payment":false,"threshold_class":"CERTIFIED_GT","weighted_upper_premises":["P<=b^(-n)","wtilde<=1","rectangle volume=(b/8)^n"]}],"pressure":[{"B_power_interval":{"base_interval_ref":"1.B","lower":{"base":"63/64","denominator_bits":7,"exponent":1,"fraction":"63/64","fraction_ascii_sha256":"4aa7ee7c24d1ffd6295ae4a48d654ed3b2b44935683cff66ab29a225de4a45d9","numerator_bits":6},"power":1,"upper":{"base":"693/640","denominator_bits":10,"exponent":1,"fraction":"693/640","fraction_ascii_sha256":"6ed435a04c147fbf518d13fc2b107c3466247d328370e1a9c41e9d195248db71","numerator_bits":10}},"base_certificate_ref":"1","current_weighted_rectangle_upper":"1/8","factor_times_rectangle_volume_interval":{"base_interval_ref":"1.B_over_8","lower":{"base":"63/512","denominator_bits":10,"exponent":1,"fraction":"63/512","fraction_ascii_sha256":"cb01b7a839bf17eee045f36c59125682be019159e48c8ba36a4da0d19a18b5a7","numerator_bits":6},"power":1,"upper":{"base":"693/5120","denominator_bits":13,"exponent":1,"fraction":"693/5120","fraction_ascii_sha256":"8679529871118e550031691d09962d472cd56930d6a256bc5caccc4426a1f10a","numerator_bits":10}},"key":["pressure",1,1],"normalized_rectangle_volume":"1/8","proxy_is_actual_integral_ratio":false,"proxy_is_actual_payment":false,"threshold_class":"UNDECIDED","weighted_upper_premises":["P<=b^(-n)","wtilde<=1","rectangle volume=(b/8)^n"]},{"B_power_interval":{"base_interval_ref":"2.B","lower":{"base":"273/256","denominator_bits":9,"exponent":1,"fraction":"273/256","fraction_ascii_sha256":"751b4c0abd9d5867abd19ade4081fe8828ec362fdc6bcf1a5bd2a7e3e78af821","numerator_bits":9},"power":1,"upper":{"base":"277/256","denominator_bits":9,"exponent":1,"fraction":"277/256","fraction_ascii_sha256":"1b238cdb40a3b5bc0eb4f56562c7179799fc832cffa73047cebc45482b9d4bb8","numerator_bits":9}},"base_certificate_ref":"2","current_weighted_rectangle_upper":"1/8","factor_times_rectangle_volume_interval":{"base_interval_ref":"2.B_over_8","lower":{"base":"273/2048","denominator_bits":12,"exponent":1,"fraction":"273/2048","fraction_ascii_sha256":"4c3558c2798785a24d051f79dc93cbdfc3a716cf82ddb8b720bb9714c3381fc3","numerator_bits":9},"power":1,"upper":{"base":"277/2048","denominator_bits":12,"exponent":1,"fraction":"277/2048","fraction_ascii_sha256":"e1292f642f3882d0b8a0c25e782dccb828b429541e5684fb877c1100985b5bcf","numerator_bits":9}},"key":["pressure",1,2],"normalized_rectangle_volume":"1/8","proxy_is_actual_integral_ratio":false,"proxy_is_actual_payment":false,"threshold_class":"UNDECIDED","weighted_upper_premises":["P<=b^(-n)","wtilde<=1","rectangle volume=(b/8)^n"]},{"B_power_interval":{"base_interval_ref":"3.B","lower":{"base":"553/512","denominator_bits":10,"exponent":1,"fraction":"553/512","fraction_ascii_sha256":"b8932c87a487a391ddff40a4d34f90a6d21334d93b3115bef0993b3044d3448f","numerator_bits":10},"power":1,"upper":{"base":"19943/18432","denominator_bits":15,"exponent":1,"fraction":"19943/18432","fraction_ascii_sha256":"b91b36cc5e923e3c54e37df86a2296fce5ea9ec2674627d495d323fdd6f4cc59","numerator_bits":15}},"base_certificate_ref":"3","current_weighted_rectangle_upper":"1/8","factor_times_rectangle_volume_interval":{"base_interval_ref":"3.B_over_8","lower":{"base":"553/4096","denominator_bits":13,"exponent":1,"fraction":"553/4096","fraction_ascii_sha256":"ee8136e680e65933521f68122433767996e8a049362761dc6dde4fb097511231","numerator_bits":10},"power":1,"upper":{"base":"19943/147456","denominator_bits":18,"exponent":1,"fraction":"19943/147456","fraction_ascii_sha256":"3df97251b01f9d3e379bf17a4c824f65ea48f813c2b2c16b181e5831b1e7bbbd","numerator_bits":15}},"key":["pressure",1,3],"normalized_rectangle_volume":"1/8","proxy_is_actual_integral_ratio":false,"proxy_is_actual_payment":false,"threshold_class":"CERTIFIED_GT","weighted_upper_premises":["P<=b^(-n)","wtilde<=1","rectangle volume=(b/8)^n"]},{"B_power_interval":{"base_interval_ref":"4.B","lower":{"base":"4431/4096","denominator_bits":13,"exponent":1,"fraction":"4431/4096","fraction_ascii_sha256":"21f3f3bce37ed819564768f75855ba82ebefde60a8a511b6473f472b43dc4ff4","numerator_bits":13},"power":1,"upper":{"base":"243747/225280","denominator_bits":18,"exponent":1,"fraction":"243747/225280","fraction_ascii_sha256":"0b211e739227511e3c7bb1a8cdf82924a0ca62153b06fedd610f8bde9801cf41","numerator_bits":18}},"base_certificate_ref":"4","current_weighted_rectangle_upper":"1/8","factor_times_rectangle_volume_interval":{"base_interval_ref":"4.B_over_8","lower":{"base":"4431/32768","denominator_bits":16,"exponent":1,"fraction":"4431/32768","fraction_ascii_sha256":"e875d12bf089f356ee34d399347427794362851341e06fbdeb51e45cb8d8792e","numerator_bits":13},"power":1,"upper":{"base":"243747/1802240","denominator_bits":21,"exponent":1,"fraction":"243747/1802240","fraction_ascii_sha256":"90ebf24aa67e8e1c248fd62054c5aeffb26f9913e49bb84473d7ff042a58b102","numerator_bits":18}},"key":["pressure",1,4],"normalized_rectangle_volume":"1/8","proxy_is_actual_integral_ratio":false,"proxy_is_actual_payment":false,"threshold_class":"CERTIFIED_GT","weighted_upper_premises":["P<=b^(-n)","wtilde<=1","rectangle volume=(b/8)^n"]}]},"status":"FINITE_PROTOCOL_PASS"}
````
<!-- REPRO-FILE-END -->

<!-- REPRO-FILE-BEGIN name="execution_receipt.json" bytes="898" sha256="70a2ab8711e9ea4a73009a6199b98b2bd8c332b6a3cfc495df8d816814ca7992" -->
````json
{
  "python": "3.14.6 (main, Jun 10 2026, 10:03:53) [Clang 21.0.0 (clang-2100.0.123.102)]",
  "record_runs": 1,
  "isolated_replay_runs": 1,
  "total_wall_seconds": 0.17507825000211596,
  "exit_codes": [
    0,
    0
  ],
  "stderr_empty": true,
  "byte_identical": true,
  "output_bytes": 32338,
  "output_sha256": "60d0489cb1ed1da8658438caad573f4102d9efeae0ac8680b760966e483029c3",
  "producer_sha256": "8393a21092d68d0389d4bc030a784c985125372bade7fdad6a57be998a8ea1c4",
  "counts": {
    "actual_completed": {
      "base_certificates": 6,
      "expanded": 4,
      "initial": 4,
      "pressure": 4
    },
    "expected": {
      "base_certificates": 6,
      "expanded": 4,
      "initial": 4,
      "pressure": 4
    },
    "failed_checks": 0,
    "integrity_checks": 29,
    "pressure_undecided": 2
  },
  "scope": "Finite exact exponential-factor and given rectangle certificates only."
}
````
<!-- REPRO-FILE-END -->
