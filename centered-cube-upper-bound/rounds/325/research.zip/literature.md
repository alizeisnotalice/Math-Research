# R325 — Gaussian-quantile transport to a uniform cube; adaptive-selector scope

## Fixed-cube theorem and constant

Let (Q=x_0+[0,L]^n) with Euclidean metric, and let (U_Q) be normalized Lebesgue measure. For every probability (P) with finite (D_{KL}(P\Vert U_Q)),
\[
W_2^2(P,U_Q)\le {L^2\over\pi}D_{KL}(P\Vert U_Q).
\]
Thus if (D_{KL}(P\Vert U_Q)\le\log D), there is a coupling ((X,Y)) with (X\sim P,Y\sim U_Q) and (L^{-2}\mathbb E|X-Y|^2\le(\log D)/\pi). The constant is dimension-free and explicit; it is a safe consequence of the sharp Gaussian inequality, not claimed optimal for the cube.

A direct proof avoids any transport theorem on a cube with boundary. Let (Phi_n) act coordinatewise by the standard Gaussian CDF. It pushes standard Gaussian (gamma_n) to (U_{[0,1]^n}), and is globally (1/\sqrt{2\pi})-Lipschitz in Euclidean distance. For (P\ll U_Q), pull it back by the coordinatewise inverse affine-Gaussian-CDF map (S:Q\to\mathbb R^n), and call the result (\nu=S_\#P). The map is a bimeasurable bijection off null boundary sets, so (D_{KL}(\nu\Vert\gamma_n)=D_{KL}(P\Vert U_Q)). Finite KL implies (\nu) has finite second moment: for any (0<t<1/2), the entropy variational inequality gives
\[
t\int |z|^2d\nu\le D_{KL}(\nu\Vert\gamma_n)+\log\int e^{t|z|^2}d\gamma_n<\infty.
\]
Talagrand's Gaussian transport theorem gives (W_2^2(\nu,\gamma_n)\le2D_{KL}(\nu\Vert\gamma_n)). Push any coupling through the affine coordinatewise Φ map; its Lipschitz constant is (L/\sqrt{2\pi}), so the squared cost is at most (L^2/(2\pi)) times the Gaussian coupling cost, yielding (L^2D_{KL}/\pi). The result includes the closed cube: finite KL makes P absolutely continuous with respect to its uniform law, so boundary-only mass is impossible; the pushforward coupling is supported in the closed cube.

## Adaptive selector limitation

For each fixed receiver (x), the fixed-cube theorem applies to a probability (P_x) relative to that receiver's fixed cube (Q_{R(x)}(x)), provided the corresponding KL is finite. A common measurable family of couplings may require a measurable-kernel selection argument.

The theorem does not itself furnish a single coupling compatible with an arbitrary adaptive (x\mapsto R(x)), nor preserve incidence masks (c_x(v)), the accepted set E, FIRST constraints, or shared-source normalization. It supplies no entropy bound for a receiver-conditioned/adaptively selected source law. It therefore does not by itself prove a payment estimate for the adaptive hard-capture baseline.

## Primary theorem text actually checked

M. Talagrand, “Transportation cost for Gaussian and other product measures,” *Geometric and Functional Analysis* 6 (1996), 587–600, DOI 10.1007/BF02249265. I accessed the author's own preprint page, followed its link 4 to `transportationcost.dvi`, and converted/read the theorem text. The original author's page identifies the linked preprint and warns it may differ from print: [Talagrand preprints](https://michel.talagrand.net/preprints/). In §1, Theorem 1.1 (preprint p. 2; corresponding journal page 588) says: for \(\nu\ll\gamma\), where \(\gamma\) is canonical Gaussian measure on \(\mathbb R^N\), and \(f=d\nu/d\gamma\), transport cost with \(w(x,y)=\|x-y\|_2^2\) is at most \(2\int f\log f\,d\gamma\). This is exactly \(W_2^2(\nu,\gamma)\le2D_{KL}(\nu\Vert\gamma)\), including the absolute-continuity hypothesis needed here. The displayed formula and cost occur immediately at Theorem 1.1; its proof begins in §3 and decomposes entropy coordinatewise (preprint pp. 13–14).

The local retrieval artifacts used for the text check are `/tmp/transportationcost.dvi` (SHA256 `2e9dfe7c395e934b311800b9b31965ad13a9cb5683fedecd7b6cb6b282631e97`) and `/tmp/transportationcost.txt` (SHA256 `22333519f09ecd12c26bcf5979f72905c9050a038e667fdded851eb0981395b3`). The CDF pushforward, KL invariance, entropy moment check, and scaling above are deductions from the checked theorem.
