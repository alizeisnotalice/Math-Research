# R325 — exact same-tag overlap fee and the remaining signed bottleneck

## Result and scope

Fix precisely the R324 first-G tag law and the original R323 residual. All receiver fields, the original alpha, full inclusive J, old source measures, all recent/middle/source-capacity/CZ/high-J/high-K gates, and the entire original negative square are fixed. No alpha restart is made here. Put

    A_n=1+n log(b/a),   zeta=1-a/(4b),
    delta_n=A_n^2 zeta^n/(q_- G),  q_-=3lambda/4.

The SAME accepted term N_acc already defined in R324 satisfies the new global geometric estimate

    0 <= N_acc <= delta_n nu(S_G) <= delta_n W_nu.       (1)

In particular, for b<=2a, zeta<=7/8. This removes the eta X_rho fee from this particular R324 payment. It does not introduce a new acceptance gate, a new tag law, a receiver translation, or a source concentration condition.

Since the exact existing identities are

    Phi_res=N_res-E_full,
    Phi_next=N_rej-E_full,
    N_res=N_acc+N_rej,

we obtain the two-sided comparison of the ACTUAL signed residuals

    Phi_next <= Phi_res <= Phi_next+delta_n W_nu.        (2)

Thus the fixed same-tag step changes the signed residual by at most this small source fee. This is a quantitative limitation on this step as well as an improved payment. It is NOT a general root bound for Phi_next.

For the consistent original threshold G=c sqrt(n)/lambda, c>0,

    delta_n <= [4/(3c)] (1+n log 2)^2 (7/8)^n/sqrt(n)
            < 56/c,                                    (3)

uniformly for integer n>=1. The displayed dimension-dependent coefficient, not its crude constant bound, is the primary estimate. If instead the fixed original threshold is G=H=sqrt(d A_n/(4lambda)), retain

    delta_n = [8 A_n^2/(3 sqrt(lambda d A_n))] zeta^n.   (4)

No assumption on lambda d or aspect dependence has been inserted.

## 1. Exact fields used

For each source z with K_z(b)>=G let T_z be the unchanged first-G probability law of R324:

    V_z(v)=1_E(v)c_v(z)/(q(v)R(v)^n),
    T_z(dv)=b_z(v)V_z(v)dv/G.

Here b_z takes all radius groups before the first crossing, the exact proportional fraction of the crossing group, and no later group. This includes the cases where the crossing is an atom, a continuous crossing, or the endpoint b. None of these old clocks or atoms is modified in this note.

Set a_z(u)=T_z(Q_(R(u))(u)). Write the old residual pair mask as M_res in [0,1], including all its old gates. For J_y(r)>=H let

    t_yzr(u)=J_y(r)^(-1)
             integral_(R(w)<=r) U_y(w)M_res(y,z,r,u,w)dw.

Then 0<=t<=1, using the ORIGINAL full J. The accepted positive term is exactly

    N_acc = integral_(S_G) nu(dz) integral T_z(dv) D_z(v),

    D_z(v)=integral beta(dy)ell_n(dr)1_(J_y(r)>=H)
             integral_(R(u)<=r) U_y(u)c_u(z)c_u(v)t_yzr(u)du.  (5)

The old w endpoint remains in t and is not equated with the new tag v. Sources outside S_G have zero positive residual because its original current high-K gate fails. The full E_full, including its parts outside that high-K domain, is left untouched.

## 2. Actual selector geometry gives a fixed-layer envelope

For z,v fixed, positivity, t<=1, and FIRST give

    D_z(v) <= integral ell_n(dr)
                   integral_(R(u)<=r) rho(u)c_u(z)c_u(v)du
             <= integral ell_n(dr)|Q_r(z) intersection Q_r(v)|
             =: B_n(v-z).                               (6)

The second inequality is the specific selector-safe geometry: if the ACTUAL cube of side R(u)<=r captures both z and v, its center u lies in BOTH cubes Q_r(z) and Q_r(v). This uses no regularity of the adaptive R, no translation modulus under a supremum, and no cap at a fictitious receiver. FIRST is used only as 0<=rho<=1_E<=1. All old masks are retained in (5) and dropped only in the positive upper bound (6).

For d=v-z the exact envelope is

    B_n(d)= product_i(1-|d_i|/b)_+
            + n integral_a^b product_i(1-|d_i|/r)_+ dr/r. (7)

Indeed ell_n=b^(-n)delta_b+n r^(-n-1)1_(a,b)dr, and the intersection of two cubes of side r has volume product_i(r-|d_i|)_+. In particular 0<=B_n<=A_n. The endpoint atom contributes the first term of (7); it has not been discarded.

## 3. Integrating the SAME entropy envelope

Use the precise reference measure that gave the R324 entropy bound:

    S_z(v)=sup_(a<=t<=b) h_t(v-z),
    sigma_z(dv)=S_z(v)dv/A_n,
    S_z=h_b + integral_a^b (n/t)h_t dt,
    T_z <= D sigma_z,  D=A_n/(q_-G).                    (8)

The last inequality follows from the actual tag density bound T_z<=V_z/G and q>=q_-. It is stronger than its entropy consequence KL(T_z||sigma_z)<=log D. This proof uses this SAME pointwise domination, not an implication from the scalar KL bound alone. The latent mixture side t is not identified with actual R(v).

For independent coordinates X_i uniform on [-t/2,t/2], a<=t,r<=b<=2a implies t<=2r. Hence the exact one-dimensional integral is

    E(1-|X_i|/r)_+ = 1-t/(4r).

Therefore

    E_(v~h_t(. - z)) [|Q_r(z) intersection Q_r(v)|/r^n]
       = (1-t/(4r))^n <= (1-a/(4b))^n = zeta^n.         (9)

This is only a reference product-cube computation. Neither the actual tag law nor actual receiver positions are asserted independent.

Integrating (9) first against the probability mixture

    pi(dt)=[delta_b(dt)+n1_(a,b)(t)dt/t]/A_n

and then against r^n ell_n(dr), whose total mass is A_n, gives

    integral B_n(v-z)sigma_z(dv) <= A_n zeta^n.          (10)

Finally (5), (6), and the pointwise bound (8) yield

    N_acc <= integral_(S_G) nu(dz) integral T_z(dv)B_n(v-z)
           <= D A_n zeta^n nu(S_G).

This proves (1). No matched beta<=f or q=P*f identity is needed. No source density cap was used. The one source measure is charged once.

The coarse rational certificate in (3) is elementary: log2<1, 1+n<=2n, and (7/8)^n<=exp(-n/8). The maximum of x^(3/2)exp(-x/8) for x>0 is attained at x=12. Since sqrt(12)<7/2 and exp(3/2)>4 (the positive Taylor sum through degree three is 67/16>4), this maximum is <42/4=21/2. Multiplication by 16/(3c) gives 56/c. This analytic bound is independent of the numerical checks below.

## 4. Complete ledger and the precise unpaid correlation

Replace ONLY the R324 accepted-piece receipt by (1). All payments before it, including near/far, old layers, shape success, low-K prefix, and CZ pieces, remain unchanged. The new receipt consumes zero additional X_rho absorption reserve. At the original target factor 2 and recovery factor Lambda=128/119, the replaced slot is

    2Lambda L_out[Phi_res]
      <= 2Lambda L_out[delta_n W_nu]
         + 2Lambda L_out[Phi_next].                     (11)

For genuinely common parameters one may extract delta_n. With varying native outer data, keep the exact source-weighted outer sum. Original source conservation, all aspect/leaf/time multipliers, and the original lambda d dependence are still required. There is no free sum of |E| or source masses across slots.

The exact unpaid quantity continues to be

    Phi_next = integral beta nu ell_n 1_(J>=H)
          integral_(R(u)<=r) U_y(u)c_u(z)
                 [t_yzr(u)(1-a_z(u))-p_yz(r)]du,
    p_yz(r)=A_yz(r)/J_y(r).                              (12)

On the complement of current high K the first term is zero, while the negative square is still present. No part of E_full has been spent in (1), (6), or (10). All rejection geometry and old w gates remain in (12).

The missing quantitative step is a lower comparison of the shared-source posterior capture p_yz against the actual positive rejected traffic, after its original weighted aggregation. The available entropy bound describes T_z relative to the reference centered at z. It gives no proved comparison to the actual probability P_(y,r)(dw)=U_y(w)1_(R(w)<=r)dw/J_y(r). Their shared-prefix support yields only the already proved upper affinity relation

    [integral sqrt(dP_(y,r)dT_z)]^2 <= p_yz(r).

Neither (8)-(10) nor a two-sided Schur upper estimate reverses this inequality. In particular (2) shows that an attempted solution which only discards the SAME N_acc has reduced the original signed challenge by at most delta_n W_nu. At root G this reduction is exponentially small in n up to a polynomial. A general payment of the remaining (12) still needs a new aggregate posterior/source-correlation argument; no such argument is proved here, even when explicitly matched nu<=beta<=f and q=P*f are allowed. Those matched conditions must be used in the same original slot if pursued later.

This is the bounded delivery: a new global selector-safe overlap payment for the already existing term, plus a quantitative equivalence of the before/after signed residuals up to its exact fee. It does not establish the requested general epsilon X_rho+C_epsilon sqrt(n)polylog(n+2)W bound for Phi_next.

## 5. Executed local diagnostics, not proof

The following standard-library Python code was actually run locally. It checks the exact one-coordinate overlap formula for 1,056 rational pairs, and evaluates the root coefficient for dimensions 1 through 10,000. The maximum in that finite numerical scan was 7.001096632976679 at n=9 for c=1. This float is diagnostic only; the uniform bound 56 in (3) has the separate analytic certificate above. The rational calculation checks the displayed antiderivative, not a quadrature or a realization of all original fields.

```python
from fractions import Fraction as F
import math
count=0
for ri in range(1,33):
    r=F(ri,16)
    for ti in range(1,2*ri+1):
        t=F(ti,16)
        actual=2*(t/2-(t/2)**2/(2*r))/t
        expected=1-t/(4*r)
        assert actual==expected
        count+=1
vals=[(4*(1+n*math.log(2))**2/(3*math.sqrt(n))*(7/8)**n,n)
      for n in range(1,10001)]
assert count==1056
assert all(v<56 for v,n in vals)
print(count,max(vals))
```
