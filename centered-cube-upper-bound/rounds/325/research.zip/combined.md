# R325：同标记全局交叠估计与真实来源容量极值证书

2026-10-18。一般 n^(1/2+o(1)) 一致弱型上界尚未闭合。本轮有一项新的同原积分几何上界、一项真实来源容量的精确极值理论及有限连续模型证书。它们不支付全部拒绝项，不以有限检验推断维度阶数。

## 1. 原始入口与完整未付账

完整历史账继承 rounds/322/research.zip::ledger.md，后续完整替换见 R323、R324 的 combined.md。仍不将 R_out 认作 X_band，不将独立原生硬带 H_rootleft 认作 B_H。历史 H0 入口及全物理尺度桥仍缺；原宽来源/low-pe分类、极端比例补集、初始原子 I_rem、真删除跳跃 J_rem、未来被删来源 D_rem、后缀 P_suffix 和其原负项独立保留。

本轮主线固定 R324 所有 U,J,A,E,R,q、alpha、来源、源块、H/G 和原正掩码；不重启alpha、不改门、不换平方。Phi_res=N_res−E_full，Phi_next=N_rej−E_full，N_res=N_acc+N_rej。

## 2. 新的几何付款及其准确含义

令 A_n=1+nlog(b/a)，zeta=1−a/(4b)，delta_n=A_n² zeta^n/(q_-G)。R324同一个首G标记 T_z 的接受项满足

0<=N_acc<=delta_n nu(S_G)<=delta_n W_nu,
Phi_next<=Phi_res<=Phi_next+delta_n W_nu.

证明不依赖固定实际R或来源密度。原实际 R(u)<=r 同时捕获 z,v 时，u必在 Q_r(z)∩Q_r(v)；FIRST据此产生合法固定层交叠势 B_n(v−z)=∫ell_n(dr)|Q_r(z)∩Q_r(v)|。同一个tag的密度由 D sigma_z 控制，D=A_n/(q_-G)。sigma_z是先前精确均匀Qt混合。因为a<=t,r<=b<=2a，参考平均交叠精确为(1−t/(4r))^n，至多zeta^n。两次原有归一化给出上述delta_n。没有把实际标签当作独立坐标，也没有在adaptive R下使用未经证明的平移模量。

若原门确取G=c sqrt(n)/lambda，则delta_n<56/c，且显式维度上界为(4/(3c))(1+nlog2)²(7/8)^n/sqrt(n)。这一维度项指数衰减。若原门取G=H，则必须保留其实际d/H比例依赖，不可擅改成根阶G。选择不同G需连同旧lowK费用lambdaG和原余项一起重组。

本结果直接替换上一轮接受项的eta X_rho+C2²/(eta q_-G)源费，不把二者相加。它也证明：只去掉这个同一接受项，改变原有符号难题的幅度至多delta_n W_nu。不能把该标记反复接受当作已知大比例覆盖；本轮下一步不继续堆叠同类接受门。

## 3. 总账中的唯一替换与吸收费用

保持 R323/R324 的全部先前分支付款，只将

2Lambda eta L_out[X_rho]+2Lambda L_out[C2²/(eta q_-G)||nu||+Phi_next]

替换为

2Lambda L_out[delta_n||nu||+Phi_next],  Lambda=128/119.

新几何付款新增X系数为零。若保持R324统一选定epsilon=eta=119/65536，现在删除eta槽，剩下CZ来源分解的2Lambda epsilon=1/256。总旧接收系数为E_original+1/256，而非宣称已经全局可吸收。其中

E_original=19/768+Lambda(epsilon_tree+delta_tail+k0 kappa_n+epsilon_LP)
 +epsilon_near+epsilon_FA+epsilon_IJ+epsilon_D+epsilon_G.

仅原M3允许L_out[X_rho]<=X_old；任意新外层不得无证复制源质量或X。R302固定H入口源费、raw近/中源费、R320近/远、旧层源费、B_rect、lowK、CZ及tiny-soft尾都仍按R323各付一次。极端比例补集与I/J/D/suffix原2Lambda系数、未用负项保持原域，完整负平方E_full也只扣一次。未知入口系数和全epsilon约束依然未闭合。

## 4. 保留全平方的来源极值理论（替代接口）

从完整B_H的R324有符号输运接口重新开始，冻结实际beta,f,q,U,J及CZ源块质量m_D。这个接口不再另加主线的全部B_H分支付款。

在实际nu<=beta的匹配槽内，定义原全平方列费用

b(z)=∫beta(dy)ell_n(dr)1_(J>=H)[A_yz−A_yz²/J],  0<=b(z)<=A_n.

令p_D为同一uniform-packet Jensen reference的单位来源费用。则完整剩余R=Σ_D[∫D b dnu−m_Dp_D]。真正的来源容量极值为

Psi_D(m)=sup_{0<=sigma<=beta|D,sigma(D)=m}∫D b dsigma
 =min_{0<=t<=A_n}[mt+∫D(b−t)_+dbeta]
 =∫_0^An min(m,beta(D∩{b>t}))dt.

最优解先填满高b列，门限水平集允许比例填充。β源质量而非Lebesgue体积是容量。本文直接证明原可行解、共同阈值对偶及零间隙；使用B01技能守卫，不援引未经核验的无限维强对偶，也不假称优化源实现原历史选择器。

若有限分格有原列成本界l_j<=b<=u_j及真实容量c_j=beta(S_j)，两端LP有同一约束0<=x_j<=c_j，Σx=m_D。其值满足L_D<=Psi_D<=U_D，U_D−L_D<=Delta m_D。原列值分格宽Delta给至多ceil(A_n/Delta)格；几何容量仍需实际核验。对未保留的源包尾质量m_tail，上证书比全极值的误差至多DeltaΣ_Fm_D+2A_nm_tail，负reference尾不能漏掉。

取Delta=epsilon_num sqrt(n)、m_tail<=epsilon_num sqrt(n)W_nu/(2A_n)，误差不超过2epsilon_num sqrt(n)W_nu。这个可验证的根阶加法误差不等于目标本身根阶；未知的是高费用列的实际beta容量。只有证明所得极值/对偶证书的根阶上界，才能通过原reference付款回代完整B_H。

## 5. 实际连续模型：精确极值包络而非抽象矩阵

本机计算冻结R324的真实一维f、beta、两实际尺度、q=h_R*f=1与dx，只取新的nu=.5beta|D使来源容量有自由度；D=[−1/2,−1/4]，m=1/4。三个来源形状在16/64/256格上分别解上下界LP。实际b的Lipschitz常数为.5，由该模型的解析A斜率证明；这不推广到一般adaptive选择器。

全部18个LP都具有Fraction原/对偶零间隙证书；有理log余项与向外2^-80价格舍入控制连续列误差。256格时，连续最优值的认证区间展示如下（以下小数仅供展示；认证上下界为脚本输出的 Fraction，不以展示小数作为严格端点）

- initial：[.008000718117077,.008122788429578]；原nu费用约.005950138805。
- reverse/narrow：[.006888507789524,.007010578102024]；原nu费用约.006069280329。
- twin：[.009481430889345,.009603501201845]；原nu费用约.007525537288。

三个严格下界也超过对应的uniform-square reference。因此“来源容量自动使剩余漂移非正”不成立于这些冻结列模型；真实最坏源的分配与证书已保留。这不是一般根阶界的反例：这些一维模型不满足原hard>2lambda历史带，也没有产生新的合法历史选择器。它们定位下一步必须估计高费用列容量的量级，而不是猜测有符号漂移自动抵消。

## 6. 本轮文献/熵接口核验

独审初筛给出准确但仍条件性的关系：binaryKL(实际接受率||参考交叠率)<=实际条件熵；以及KL(T_z||P_y,r)有限时，原capture概率至少exp(−KL)。后一个KL的q抵消后仍含真实soft likelihood和alpha，FIRST只给上界，不能据此宣布低KL或共同捕获下界。

literature.md从Talagrand作者托管原文Theorem1.1核回Gaussian T2，利用GaussianCDF的Lipschitz推前证明固定uniform cube的W2²<=L² KL/π。这一已核工具不自动保留adaptive接收掩码；本轮几何付款不依赖它，未把固定cube输运界用作未证的Phi_next预算。

## 7. 实际运行与状态

主代理fresh运行10479项精确检查：core1056、来源极值165、实际容量LP9258。另外执行n=1..10000的浮点维度诊断，最大所见系数约7.0011(n9)，不是全维证明；56的统一界有独立解析证明。数值脚本用mpmath仅显示小数，证书判断均为精确Fraction。原代码不编译PDF。

当前还未得到一般Phi_next根阶预算，完整弱型上界继续开放。没有实际模型扣额数据，不猜测成本比例。本轮新估计删掉一个真实吸收项，有限证书改变了下一步极值几何策略；没有把它们冒称全局闭合。
