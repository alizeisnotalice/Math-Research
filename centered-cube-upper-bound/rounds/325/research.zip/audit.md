# R325 independent preauthor screen — useful entropy/capture and affinity contracts

Ownership: only /tmp/r325_audit.md. No Git or other-author edits. New R325 author proofs have not been read. Original full U,J,A,E,q,R,s,L,nu,beta and every current Phi_next mask are frozen; no R324 proofs or tests are repeated.

## 1. Exact acceptance from conditional entropy, with the missing reference overlap retained

Use R324's SAME actual first-G tag tau_z and its explicit canonical latent-scale lift. Write P_z^T for the ACTUAL lifted scale marginal, P_z(dx|t) for its conditional law, kappa_z(t)=KL(P_z(dx|t)||uniform Q_t(z)), and kappa_cond(z)=integral kappa_z(t)P_z^T(dt)<=logD. None of these t labels is original chosen R or original layer r.

For a fixed actual capturing receiver u of side R=R(u), let

 v_z,t(u)=|Q_t(z) intersect Q_R(u)|/t^n,
 a_z,t(u)=P_z(Q_R(u)|t),
 vbar_z(u)=integral v_z,t(u)P_z^T(dt),
 a_z(u)=integral a_z,t(u)P_z^T(dt)=tau_z(Q_R(u)).

Data processing to this binary event gives binaryKL(a_z,t||v_z,t)<=kappa_z(t). The log-sum inequality across t then gives

 binaryKL(a_z(u)||vbar_z(u))<=kappa_cond(z)<=logD.

Equivalently use the reference joint law P_z^T(dt)*uniform Q_t(z); this keeps the ACTUAL scale marginal and has exactly the conditional entropy as its KL. It is not the canonical joint law with the old reference pi. Empty/zero-scale fibers contribute zero; binary endpoint cases use the usual absolute-continuity conventions.

A valid elementary consequence is

 a_z(u)>=max(0,vbar_z(u)-sqrt(kappa_cond(z)/2)).

For binaryKL, the second derivative in its first argument is1/[a(1-a)]>=4, with value/first derivative0 at a=v, proving the quadratic bound without an external concentration theorem. A sharper lower bound is the lower endpoint of the binaryKL sublevel interval; equivalently

 a>=sup_{t>0}[-kappa_cond-log(1-vbar+vbar exp(-t))]/t,

clipped below at0. To FORCE any positive lower acceptance from entropy alone requires kappa_cond< -log(1-vbar); a=0 has exactly that binary entropy. This is the decisive missing overlap-versus-entropy parameter, not merely the magnitude of logD.

The geometric reference overlap is explicit, not unknown independence: each coordinate overlap length is

 [min(z_i+t/2,u_i+R/2)-max(z_i-t/2,u_i-R/2)]_+,

and their product divided by t^n is v_z,t. On an actual capture z in Q_R(u), for a<=R,t<=b<=2a, each fraction is at least1/2, hence v_z,t>=2^(-n), but that exponential lower bound does not combine with O(log n) entropy into a positive dimension-uniform acceptance. This observation quantifies a gap; it is not an original-history counterexample or proof that no other shared-source estimate can work.

A directly payable geometric event needs no entropy: if t<=R-2||u-z||_infinity, the whole Q_t(z) lies in Q_R(u), so a_z(u)>=P_z^T{t<=R-2||u-z||_infinity}. Its actual scale probability is another explicit parameter; the original same-prefix support does not bound it automatically because this latent t is not original R(v).

## 2. Mean-bias control needs an additional covariance or margin estimate

R324 gives an averaged normalized squared conditional mean displacement, not an overlap theorem. A valid no-independence supplement is: let m_i(t) be the conditional mean, Sigma_ii(t) its coordinate variances, and d_i=R/2-|m_i(t)-u_i|. If all d_i>0, Chebyshev and a coordinate union bound give

 a_z,t(u)>=max(0,1-sum_i Sigma_ii(t)/d_i²).

All moments exist because conditional support is Q_t(z). This uses no diagonal covariance/coordinate independence. The unavailable quantity is the actual variance-to-face-margin sum (and the mass of fibers with a positive margin). Merely knowing mean close to z supplies neither this sum nor closeness to all faces around u. The generic support variance t²/4 per coordinate is finite but can make the bound useless. Any proposed application must pay/control these explicit missing quantities, rather than calling conditional mean bias a lower overlap bound.

## 3. The useful shared-source affinity parameter and exact q cancellation

At an actual high-K/high-J prefix, let P_y,r(dw)=U_y(w)1{R(w)<=r}dw/J and tau_z=T_z^G. Its support is on captures c_w(z)=1 within this same prefix. The affinity L=integral sqrt(dP_y,r d tau_z) obeys L²<=p_yz=A_yz/J (Cauchy-Schwarz on capture support).

If the ACTUAL relative entropy ell_yz=KL(tau_z||P_y,r) is finite, Jensen in the reverse direction gives

 L=E_tau sqrt(dP/dtau)>=exp(-ell_yz/2),
 p_yz>=L²>=exp(-ell_yz).

This is a usable quantitative lower correlation certificate. It requires the tag law to be absolutely continuous relative to the SAME original row posterior and pays its actual relative entropy. R324's KL(tau||canonical sigma) is not that entropy and does not control it without another likelihood comparison.

On tag support, with b_z(w) the first-G fraction, the exact original densities give

 d tau_z/dP_y,r = J b_z(w)/[G alpha(w,y) P_s(w),L(w)(w-y) R(w)^n].

The original q(w) cancels EXACTLY. Zeros of alpha or of the actual soft response may make ell_yz infinite and affinity uninformative; one cannot remove them inside the already fixed Phi_next by declaring alpha=1. When finite,

 ell_yz=log(J/G)+E_tau log b_z-E_tau log[alpha P_s,L(w-y)R^n].

Thus a sufficient explicit certificate is a lower likelihood alpha P_s,L(w-y)R^n>=zeta>0 tau-a.e.; it gives ell_yz<=log[J/(G zeta)] and p_yz>=G zeta/J. Other integrable lower-log-likelihood estimates can replace it. These are parameters of the actual original source/receiver row, not new source kernels or recomputed q.

The matched q=P_s,L*f and beta<=f imply FIRST as an UPPER response constraint, and may permit further joint-source work. They do not by themselves provide the stated pointwise alpha/soft likelihood lower bound on the actual tag support. Source domination must not be replaced by a density cap or beta+nu<=f. This screen does not prove that no integrated shared-source estimate exists; it identifies the exact missing relative-likelihood/correlation quantity.

## 4. How these certificates enter the actual signed core

Keep the exact R324 anchored integrand

 U_y(u)c_u(z)[t_yz(u)(1-a_z(u))-p_yz],

where0<=t<=1 retains all original pair/core gates and original w/J; the complete square also remains outside the high-K positive domain. If a_z(u)>=a0 and ell_yz<=ell0 on a declared original subset, that subset is nonpositive whenever a0+exp(-ell0)>=1. More sharply retain the actual t in t(1-a0)<=exp(-ell0). These are sufficient signed criteria, not automatically satisfied gates.

One may instead quantify the remaining positive gap t(1-a0)-exp(-ell0) with all original anchor weights. A uniform gap<=delta gives only delta times the original anchor first moment<=delta A_n Wnu, unless a stronger actual-source budget is proved. No raw-target identity, epsilon X absorption or root source price follows merely from naming this gap. Outside the declared favorable subset, retain the complete signed/positive complement exactly; do not subtract a second square or recompute old labels under the canonical law.

## 5. Actual local tool evidence and screen verdict

Actually executed installed local mpmath at60digits on81 pairs of binary probabilities.81 Pinsker comparisons and81 squared-affinity-versus-exp(-KL) comparisons PASS, total162 ordinary high-precision diagnostics. They are NOT outward interval certificates and do not replace the analytic second-derivative/Jensen proofs. No R324 numerical run was repeated and no new counterexample campaign was conducted.

Independent initial verdict: PASS for the quantitative binary-entropy acceptance contract, explicit reference-overlap parameter, covariance/margin supplement, and actual tag-to-row affinity/likelihood contract. Neither conditional mean bias nor canonical KL alone has yet been converted into the missing general Phi_next payment. Await author proofs for bounded comparison; original source/mask/outer obligations remain intact.

## 6. Independent new same-tag zero-output geometry screen

Before reading the new R325 core proof, independently verified the proposed accepted-term estimate. Cancel only the original w numerator/fullJ in a positive bound, retain the same tag tau_z, and use FIRST. For fixed z,v the remaining potential is at most

 B_n(v-z)=integral ell_n(dr)|Q_r(z) intersect Q_r(v)|.

An actual receiver capturing both z,v at R(u)<=r lies in those two r-cubes; no selector translation, virtual cap or smoothness of R is required. For v uniform on Q_t(z), a<=r,t<=b<=2a implies t<=2r and each coordinate integral is exactly1-t/(4r). Thus

 E_sigma B_n<=A_n[1-a/(4b)]^n.

The SAME actual tag is pointwise dominated by D sigma, D=A_n/(q_-G), so the already existing N_acc satisfies

 0<=N_acc<=delta_n nu(S_G), delta_n=A_n²[1-a/(4b)]^n/(q_-G).

This is a zero-X alternative receipt, not an additional tag gate or a bigger accepted fraction. For G=c sqrt(n)/lambda, it is bounded by(16/(3c))n^(3/2)e^(-n/8); the maximum occurs at n=12. A safe64/c follows e³>12; author's sharper56/c certificate is also valid (see next section). Original q/G/aspect and source weights must be retained when not using this threshold. This statement uses pointwise domination, stronger information than a scalar KL bound alone.

## 7. Full author core comparison

Read /tmp/r325_core.md in full after §6. SHA256 c1866ba3a0500565e7a7de2dff139c93e92cf18bce3070965c2da8643770b7af. PASS for formulas(1)–(12), inclusive terminal b atom, exact canonical scale mixture and source-once payment. The author's safe56/c proof is rigorous: sqrt12<7/2, e^(3/2)>67/16>4, so12^(3/2)e^(-3/2)<21/2; multiplying16/(3c) gives56/c. The dimensions1..10000 scan is diagnostic, not its uniform proof.

The accepted term is literally R324's N_acc with old masks, fullJ, original old w and complete original square unchanged. Therefore

 Phi_next<=Phi_res<=Phi_next+delta_n Wnu.

The remaining challenge is quantitatively unchanged up to this source fee; the accepted piece can be very small and no coverage fraction is claimed. It is correct to replace the old eta X_rho+L2 accepted-piece bound with this zero-X bound, but not to retain both fees as simultaneous payments or to subtract another square. The original same-prefix affinity upper relation is not reversed. This is a genuine selector-safe overlap payment and an exact limitation on the fixed lift step, not a general Phi_next upper bound.

## 8. Independent capacity-relaxation screen, then author comparison

Before reading /tmp/r325_transport.md, independently derived: for the frozen complete-square column b(z)=integral beta ell 1{J>=H}(A_z-A_z²/J), FIRST gives0<=b<=A_n. On one frozen packet with actual m<=beta(D), the exact dominated-source maximum of integral b d sigma over0<=sigma<=beta|D and sigma(D)=m is

 Psi_D(m)=integral_0^An min(m,beta(D intersect {b>t}))dt
 =min_{t in[0,An]}[mt+integral_D(b-t)_+d beta].

A threshold fill with a fractional whole tie level attains it. The SAME row/source prior beta and cost b are fixed before optimizing; optimizing separately for each row/scale would be a different relaxation. All source packets are disjoint and their masses fixed, so the upper relaxation is common-source and mass-conserving. Source-dependent original selectors need not be realized by its optimizer.

Read /tmp/r325_transport.md fully: SHA256 df6cacaab563c4dc7bc82b7c602c68b2864c2cba962877ca5d4363401d927d77. PASS for its bounded cost, exact bathtub/tie formula, per-packet reference p_D<=An and signed surplus upper bound. The reference remains the R324 Jensen reference, not actual B_H(g). The finite knapsack bounds use actual beta capacities; uniform cost width Delta gives gap<=Delta*m without packet-count fee. L1(beta) coefficient errors dominate every feasible allocation error. For a discarded countable tail, the conservative signed-reference gap really needs2An*m_tail; keeping its negative reference improves that factor as stated. Delta=eta sqrt(n) and the stated tail threshold give<=2eta sqrt(n)Wnu, not a bound for the unknown optimum itself.

It is a precise computable upper relaxation, not the general source-root estimate. Optimizers are not asserted to retain original nu-dependent low-pe/history qualification; hard caps only inherit when genuine same-f domination/all-radius cap is available. If beta has not been identified with the authentic dominating source, this source-order theorem remains conditional. No general strong-duality theorem or arbitrary transport dual is invoked.

## 9. Read numeric report and necessary script scope

Read /tmp/r325_notes.md and inspected relevant /tmp/r325_numeric.py code. The fixture preserves R324's actual1D positive-L1 source, selected radii1/1.5, q=1 and frozen beta/U/J/full square, with nu=beta/2 and real allocation slack. It does not satisfy the original hard lower2lambda band or complete R323 history/core. The twin source is explicitly changed to half of beta over whole D; it is not mislabeled as half of old two-packet nu.

For these actual columns, A(y,z) has piecewise slopes of absolute value<=1; |1-2A/J|<=1 and total ell mass1 give the analytical Lip(b)<=beta(D)=1/2. Certified midpoint log enclosures plus Lip*h/2 and outward dyadic rounding bound the ENTIRE spatial bins. Actual beta mass, not bin length, is the capacity. The lower LP realizes a genuine dominated L1 source; finite primal/dual zero gaps and continuous objective enclosure are correctly separated. Positive optimum-minus-reference debt in these fixed examples disproves only a universal nonpositive-debt inference for this frozen class; it does not show a general root bound false.

The report's9258 exact counted checks=492+1788+6972+6 nesting observations is arithmetically consistent. Descriptive mpmath decimals are not used for decisions. Neither this reviewer nor finite numerical optimization has certified general high-column scarcity or full historical eligibility. Primary fresh execution/log evidence remains to be bound after final integration. No reviewer repeat of the entire numeric run is claimed.

## 10. Final integration review and actual coefficient calibration

Read the complete R325 checkpoint combined.md and compared it to both audited new mathematics reports and the prior R324 single-Phi replacement. PASS for the primary budget structure: replace the old R324 accepted-piece eta X_rho AND its L2 source bill by delta_n Wnu; keep exactly the SAME Phi_next and original whole E_full once. No new acceptance mask or repeated acceptance probability is introduced. All older R323 source/occupancy payments remain once. The complete-B_H bathtub/source-transport relaxation is an alternative entrance/decision interface, not another source price added to the primary Phi ledger.

A fresh local exact Fraction run checked4 assertions:2*(128/119)*(119/65536)=1/256;12<(7/2)²; the positive exp(3/2) Taylor sum through degree3 equals67/16>4; and(16/3)*(21/2)=56. Thus keeping the old R324 epsilon=119/65536 after deleting eta leaves E_original+1/256, conditional on the same authentic M3. This is not a global absorption proof. G is retained with its original dependence and earlier low-K fee; changing it requires its actual split/remaining integral to change consistently.

The root-threshold expression with log2 and7/8 is an explicit upper bound for delta_n when b/a<=2, not an equality for every current band. The precise delta_n is A_n²(1-a/(4b))^n/(q_-G). Display decimals for continuous LP intervals must be distinguished from exact Fraction certificate endpoints. Primary has been notified of these minor wording corrections; final hashes below are bound only after those clarifications are saved.

Primary's10479 exact counted checks are1056 core overlap identities+165 extremal allocation checks+9258 actual continuous-column/LP certificate checks. The10000-dimensional floating scan is separate, not proof of the56 constant. The reviewer independently ran162 ordinary mpmath60-digit entropy/affinity diagnostics plus4 exact arithmetic assertions; these are not added to primary's count. Scope of actual1D fixture and unattained historical/general-root implications remain explicit. No reviewer repeat of primary's full scripts is claimed.

Literature's fixed uniform-cube transport inequality is not an assumption in the new payment, and no adaptive-mask transfer from it is certified here. Its supplied provenance may be bound as reference metadata without redoing the independent literature agent's full source search.

## 11. Exact remaining gap and final scope

The primary open object remains original Phi_next=N_rej-E_full with the actual rejected triple, shared beta/nu posterior and complete original masks. The zero-X estimate additionally proves that the before/after signed residuals differ by at most delta_n Wnu; it does not establish a root bound for either residual. Conditional-entropy event bounds require an actual reference-overlap/entropy balance; affinity lower certificates require actual tag-to-row relative likelihood or KL. Neither missing parameter is proved small from matched FIRST alone.

The full-B_H alternative still requires an actual high-column-capacity estimate or certified root-sized extremal/dual budget. A root-size approximation error for the finite relaxation is not the root size of its unknown value. The actual positive optimized debt is not a general centered-cube or original-history counterexample.

Complete extreme-aspect complement, initial/history deletion/future-deleted/suffix obligations, genuine H0 historical entrance, separate native H_rootleft, all-scale and small-dimension/outer-error linkage remain independent and unproved. No claim that only constants/logarithms remain is certified. This receipt covers the declared proofs/integration, not any later unread TeX/PDF.

## 12. Final corrected-byte receipt

Re-read the two changed passages of final combined.md: the log2/7/8 expression is now correctly called an explicit dimension UPPER bound; all printed LP decimals are explicitly display-only, while rigorous endpoints are the script's Fraction outputs. Both requested clarifications are resolved. No further mathematical correction is required.

Inspected actual primary logs: core_checks.log reports1056 exact overlap identities plus the separately labeled n1..10000 floating coefficient scan; extremal_checks.log reports165 exact assertions. Read numeric_summary.json scope/counts for9258 exact checks. The primary's fresh execution is attributed to primary, not this reviewer. No duplicate history/literature/source search or full diagnostic replay was performed by this reviewer.

Final SHA256 bindings:

- /Users/zhengzhihao/Desktop/T/output/centered_cube_round325_20261018_final_checkpoint/combined.md: f8038fb5e470dd27b527e5ee04305a6b6c9295ff9d6d8507449bf60f28b8c48b

- /Users/zhengzhihao/Desktop/T/output/centered_cube_round325_20261018_final_checkpoint/core.md: c1866ba3a0500565e7a7de2dff139c93e92cf18bce3070965c2da8643770b7af

- /Users/zhengzhihao/Desktop/T/output/centered_cube_round325_20261018_final_checkpoint/core_checks.log: 5b1ec895d48a328879d697d73f1b59446120e489ad0f1df3d12e6f30c35ac820

- /Users/zhengzhihao/Desktop/T/output/centered_cube_round325_20261018_final_checkpoint/core_checks.py: 8c5b09a6021e3a31be7da91e4e3271a1718e95a1c0968952028a0a66c3c693aa

- /Users/zhengzhihao/Desktop/T/output/centered_cube_round325_20261018_final_checkpoint/extremal.md: df6cacaab563c4dc7bc82b7c602c68b2864c2cba962877ca5d4363401d927d77

- /Users/zhengzhihao/Desktop/T/output/centered_cube_round325_20261018_final_checkpoint/extremal_checks.log: 18a2522b1d1f090109fd783261a40a4f2034a4a417aca58dc86852862956cdaa

- /Users/zhengzhihao/Desktop/T/output/centered_cube_round325_20261018_final_checkpoint/extremal_checks.py: 898bb6d0176dcd9cc9d6d53c68f056f5c9e26e6c31c56d9487916c025229da41

- /Users/zhengzhihao/Desktop/T/output/centered_cube_round325_20261018_final_checkpoint/literature.md: 27e2d57e2fec1d57119cdfe7680b7ab8340fa61cc9ebe12f818da27718776123

- /Users/zhengzhihao/Desktop/T/output/centered_cube_round325_20261018_final_checkpoint/numeric.py: a2b44784c68d7d5a0e9670701596d9ac78ebd02f5a4c8cebb51231ccff379b28

- /Users/zhengzhihao/Desktop/T/output/centered_cube_round325_20261018_final_checkpoint/numeric_notes.md: e781bbfc524795b3ccb350bc0d338321cbac31729e2b85a8b1b9c5d4a58e29cc

- /Users/zhengzhihao/Desktop/T/output/centered_cube_round325_20261018_final_checkpoint/numeric_summary.json: 36a4c6e57354ec90236386994e83675a640795d0f77aba41d0707c0b6c8e66b9

- /Users/zhengzhihao/Desktop/T/output/centered_cube_round325_20261018_final_checkpoint/requirements.txt: a699f46ed76bd216f1081b6b2330e4fb45d7c8c5a5354b208694d6590a5a8645

Primary-authored TeX metadata ONLY: /Users/zhengzhihao/Desktop/T/output/centered_cube_round325_20261018_final_checkpoint/research.tex: 49026bc11c7f607105f8efc7c2faaf7dde9bb7b44b2f15ede7253afeca9b102a. This later TeX was NOT read line-by-line or compiled by the reviewer; no TeX/PDF correctness claim is included.


The supplied literature.md is reference metadata, not a dependency of the new zero-X payment; its entire source search was not re-audited. All substantive new payment, exact extremal and integration claims are covered at the bounded scopes above.

FINAL VERDICT: PASS for the fixed original accepted-term zero-X overlap receipt, unchanged signed-core relation, dominated-source full-square extremal reduction and certified finite objective brackets, and the corrected combined ledger. The remaining rejected-triple/shared-source posterior correlation and complete historical/global obligations are not paid. No general centered-cube root closure is certified. Freeze this audit at these bytes; changed proof/integration bytes require a new explicit binding.
