# R325 — exact dominated-source extremal reduction for the full-square transport surplus

**Proved scope.** Under the actual additional source order `ν≤β≤f`, the R324 integrated packet surplus has an exact sharp upper relaxation with the SAME `β,f,q,U,J` frozen. Its value is determined by actual `β`-mass capacities of high-cost source columns. It admits explicit finite linear-program brackets with certified source-linear error, including a countable-packet tail. This is an extremal reduction, not a root payment: no general bound on those high-column capacities is proved. The optimizer is not asserted to satisfy the original history or any source-dependent eligibility condition.

No new source density cap, component FIRST, shared-source symmetry, source/receiver selector, or input-dependent softness gate is inserted. Only this file is authored; other agents' files and Git are unchanged.

## 1. Freeze the real original row and its full capture square

Use the original R324 transport interface. The `y` row source is the actual `β`; the hard source is the actual `ν≤β≤f`; the complete input `f`, actual common `q`, shared softness and scales, row mask `α`, and receiver set are fixed. In particular keep

\[
 \rho(u)=\int U_y(u)\beta(dy)\le1_E(u),\quad
 X_\rho=\lambda\int\rho<\infty,
\]
\[
 J_y(r)=\int_{R(u)\le r}U_y(u)du,\qquad
 A_{yz}(r)=\int_{R(u)\le r}U_y(u)1_{Q_{R(u)}(u)}(z)du,
\]
\[
 \ell_n=b^{-n}\delta_b+nr^{-n-1}1_{[a,b]}dr,
 \quad A_n=1+n\log(b/a),\quad\ell_n([R,b])=R^{-n}.       \tag{1}
\]

Rows are the original finite rows; all endpoint restrictions remain in original numerators and do not rebuild `J`. The scalar full-square cost is

\[
 B_\nu=\int b(z)\nu(dz),\qquad
 b(z)=\int\beta(dy)\ell_n(dr)1_{J_y(r)\ge H}
             \left[A_{yz}(r)-\frac{A_{yz}(r)^2}{J_y(r)}\right].
                                                               \tag{2}
\]

The actual shared `q` and complete `f` are present inside every original `U`. The source order is used on the SAME `β` that occurs in (2), rather than a newly substituted prior. If an old abstract `β` has not been identified with the matched dominating source, the theorem is conditional on that missing map.

There is a useful pointwise cap requiring no source-density estimate:

\[
 \boxed{\quad 0\le b(z)\le A_n\quad}\quad\text{for almost every }z.
                                                               \tag{3}
\]

Indeed discard the negative square and the high-row gate, and apply original FIRST at each scale:

\[
 \int\beta(dy)A_{yz}(r)
 =\int_{R(u)\le r}\rho(u)1_{Q_{R(u)}(u)}(z)du\le r^n.
\]

Integrating `r^n` against `ell_n` gives (3), including the terminal atom. Thus `b` is a measurable bounded cost formed from the original full square; it is not the unpaid drift renamed as a new function. No continuity or spatial Lipschitz bound for `b` is assumed for arbitrary measurable scale selectors.

## 2. Relate the exact source-cell surplus to this cost

Freeze the R323 binary-CZ source boxes `𝒟` for the ACTUAL `ν` at threshold `K>0`. Write `m_D=ν(D)`, `Ω=⋃𝒟`, and let `g` be the original source-preserving spread. Thus `g≤2K`, `∫g=Wν`. At each original row/scale, let

\[
 a_D(y,r)=|D|^{-1}\int_D A_{yz}(r)dz,
 \quad \mu_D=m_D^{-1}\int_D A_{yz}(r)\nu(dz),
 \quad V_D=m_D^{-1}\int_D(A_{yz}(r)-\mu_D)^2\nu(dz).
\]

Define the **per-unit-source** Jensen reference

\[
 p_D=\int\beta(dy)\ell_n(dr)1_{J_y(r)\ge H}
                    [a_D-a_D^2/J_y(r)],\qquad 0\le p_D\le A_n.
                                                               \tag{4}
\]

The exact R324 identity is

\[
 B_\nu=\mathcal P+\mathcal R,\qquad
 \mathcal P=\int_{\Omega^c}b\,d\nu+\sum_Dm_Dp_D,
\]
\[
 \mathcal R=\sum_D\left[\int_Db(z)\nu(dz)-m_Dp_D\right]
 =\int\beta(dy)\ell_n(dr)1_{J\ge H}\sum_Dm_D
 \left[(\mu_D-a_D)(1-2a_D/J)
              -\frac{(\mu_D-a_D)^2+V_D}{J}\right].        \tag{5}
\]

Both negative quadratic credits remain inside (2)/(5). The reference `𝒫` is larger than actual `B_g` by the uniform-tag source variance, and must not be identified with `B_g`. Its already-proved one-input FIRST/L² fee is

\[
 \mathcal P\le\varepsilon X_\rho+
                    \frac{C_2^2K}{2\varepsilon\lambda}W_\nu.
                                                               \tag{6}
\]

Here `C₂` is the authorized dimension-independent all-radius centered-cube strong-L² constant, as checked in R323. Formula (5), not a recomputed posterior or a modified `J`, is the surplus to be estimated.

## 3. Exact extremum from actual shared-source capacities

For each `D` put `B_D=β(D)≥m_D` and define

\[
 C_D(t)=\beta(D\cap\{b>t\}),\qquad 0\le t\le A_n.
\]

Consider the fixed-cost source-domination relaxation

\[
 \Psi_D(m)=\sup\left\{\int_Db\,d\sigma:
        0\le\sigma\le\beta|_D,\ \sigma(D)=m\right\},
 \qquad 0\le m\le B_D.                                  \tag{7}
\]

Then

\[
 \boxed{\ \Psi_D(m)=\int_0^{A_n}\min\{m,C_D(t)\}dt
 =\min_{0\le t\le A_n}
       \left[mt+\int_D(b-t)_+\,d\beta\right].\ }         \tag{8}
\]

**Proof and optimizer.** Write `σ=θβ`, `0≤θ≤1`. For every `t`, the elementary feasible upper bound

\[
 b\theta\le t\theta+(b-t)_+
\]

gives the dual expression in (8). Choose a level `t_*` satisfying

\[
 \beta(D\cap\{b>t_*\})\le m
               \le\beta(D\cap\{b\ge t_*\}).             \tag{9}
\]

For `0<m<B_D` such a level exists from the distribution function. Put

\[
 \theta_*=1_{\{b>t_*\}}+\gamma1_{\{b=t_*\}},\qquad
 \gamma=\frac{m-\beta(D\cap\{b>t_*\})}
                    {\beta(D\cap\{b=t_*\})},            \tag{10}
\]

with any value on a zero-mass tie set. It is feasible and attains equality in the dual bound. Thus the optimizer fills all highest-cost source columns first and uses a fractional threshold level only if necessary. `m=0` is the zero measure; `m=B_D` is `β|D`. The L¹ prior is nonatomic, but the level distribution of `b` may have atoms; (10) treats them exactly without assuming ties have zero mass. Layer cake for this optimizer gives the first expression in (8). ∎

In particular the actual `ν|D` is feasible, so

\[
 \boxed{\quad\mathcal R\le
        \sum_D[\Psi_D(m_D)-m_Dp_D].\quad}                 \tag{11}
\]

This is sharp over **dominated source allocations with the frozen packet masses**, keeping `ν` outside `Ω` fixed. Independently select (10) on disjoint `D`; their sum is one source measure `σ≤β`, with each required packet mass and total hard-source mass unchanged. The reference `g` and `p_D` are unchanged. There are no source copies, pair-mass products, or separate row/scale priors. The series converges absolutely because each summand is between `−A_nm_D` and `A_nm_D`.

This sharpness is for the stated relaxation, not the full historical construction. The optimized hard source does NOT replace actual `ν` in any traffic being estimated. In particular if `α`, an eligibility mask, or other construction originally depended on `ν`, it remains frozen; the optimizer need not realize that construction. Same-radius hard caps for trial sources are not implicitly granted: if they follow from a matched full-`f` cap they are inherited by `σ≤β≤f`; otherwise omitting them only enlarges the upper relaxation. A large optimum is not an original operator counterexample.

## 4. Finite LP brackets with source-linear error

For one packet, take any finite measurable partition `D=⊔_jS_j` and certified cost bounds

\[
 l_j\le b(z)\le u_j\quad\beta\text{-a.e. on }S_j,
 \qquad c_j=\beta(S_j).
\]

Define two finite fractional-knapsack programs with the SAME feasible polytope

\[
 L_D=\max\{\sum_jl_jx_j:0\le x_j\le c_j,\ \sum_jx_j=m_D\},
\]
\[
 U_D=\max\{\sum_ju_jx_j:0\le x_j\le c_j,\ \sum_jx_j=m_D\}.
\]

Then

\[
 \boxed{\quad L_D\le\Psi_D(m_D)\le U_D,\qquad
 U_D-L_D\le\Delta m_D\quad\text{if }u_j-l_j\le\Delta.\quad} \tag{12}
\]

For the upper bound allocate the actual source-bin masses. For the lower bound, realize a maximizing vector by `σ|S_j=(x_j/c_j)β|S_j` when `c_j>0`; zero-capacity bins carry no mass. Its actual cost is at least the lower objective. The gap follows by comparing objectives at a common feasible vector: their difference is at most `ΔΣx=Δm_D`. The optimal programs can be solved by decreasing-cost filling, with fractional final bins, exactly as in (10).

An unconditional finite choice is **value bins** of the actual `b`, each of width `Δ`: half-open intervals covering `[0,A_n]`, with the last endpoint included. There are `N=ceil(A_n/Δ)` bins (at least one); their actual `β` capacities are the coefficients. This construction needs no spatial regularity. If spatial bins have a separately proved local Lipschitz bound `L` and maximum diameter `h`, then one may instead use certified spatial bounds of width `Lh`. An arbitrary measurable original radius selector does not automatically supply such a Lipschitz estimate.

Numerical cost approximation also has a rigorous source-domination error rule. If a computed `b_hat` satisfies

\[
 \eta_D=\int_D|b-b_{\rm hat}|\,d\beta<\infty,
\]

then every feasible `σ` obeys `|∫b dσ−∫b_hat dσ|≤η_D`; hence the exact extrema differ by at most `η_D`. A certified interval for `p_D` of width `ζ_D` contributes at most `m_Dζ_D` to the surplus interval. Those errors are charged, not inferred from an uncertified receiver quadrature. In particular a finite LP is only a certified numerical receipt when its capacities and cost bounds are themselves certified for the original fields.

## 5. Countably many source packets and the actual dimension cost

Choose finitely many original packets `F⊂𝒟` and let

\[
 m_{\rm tail}=\sum_{D\notin F}m_D.
\]

Their total tail signed surplus is at most `A_nm_tail` by (3), (4). Therefore a directly usable finite certificate is

\[
 \mathcal R\le
 C_F:=\sum_{D\in F}[U_D-m_Dp_D]+A_nm_{\rm tail}.          \tag{13}
\]

It has no packet-count fee. The conservative upper bracket's gap from the exact relaxation (11) is at most

\[
 0\le C_F-\sum_D[\Psi_D(m_D)-m_Dp_D]
           \le\Delta\sum_{D\in F}m_D+2A_nm_{\rm tail}.   \tag{14}
\]

The factor two matters: the omitted tail surplus can be negative. If its reference `Σ_tail m_Dp_D` is retained explicitly in (13), the gap improves to `ΔΣ_Fm_D+A_nm_tail`; (13) instead needs only the coarse tail mass and drops that negative reference. Separately certified `b,p_D` errors add as described after (12).

For any `η>0`, `Wν>0`, choose

\[
 \Delta=\eta\sqrt n,\qquad
 m_{\rm tail}\le\frac{\eta\sqrt n}{2A_n}W_\nu.           \tag{15}
\]

Such a finite `F` exists because the source masses sum to at most `Wν`. Formula (14) then gives error at most `2η√nWν`. The value-bin count per retained packet is

\[
 N=\max\{1,\lceil A_n/(\eta\sqrt n)\rceil\}.            \tag{16}
\]

Only when `b/a≤2` is this `O(1+√n/η)`, since `A_n=1+n log(b/a)`. The number of retained packets has no all-input dimension-only bound here, and the actual geometric capacities remain unknown. Thus this is a finite extremal reduction at root-size additive accuracy, not a root estimate, a polynomial-time theorem, or a claim that one may sum source budgets over independently selected partitions. If `Wν=0`, all quantities vanish.

## 6. How an actual certificate would pay; what is still missing

For example, valid scalar thresholds `t_D∈[0,A_n]` give the explicit upper certificate

\[
 \mathcal R\le\sum_D\left[
      m_D(t_D-p_D)+\int_D(b-t_D)_+\,d\beta\right].         \tag{17}
\]

The integral uses actual SOURCE `β` mass, not Lebesgue level volume applied to an arbitrary source. Since the boxes are disjoint, both mass terms are source-once. This upper bound follows from a checked feasible scalar inequality, not from assuming an arbitrary transport dual is an upper estimate.

If a geometric argument or certified LP establishes the right side of (11), (13), or (17) to be at most `L√n(Wβ+Wν)`, then (5), (6), with `K=λ√n`, give the actual conditional payment

\[
 B_\nu\le\varepsilon X_\rho+
     \sqrt n\left[\frac{C_2^2}{2\varepsilon}W_\nu
                         +L(W_\beta+W_\nu)\right],       \tag{18}
\]

plus whatever certified approximation error was used. Every source and outer multiplier must retain its original ledger. Receiver losses aggregate through actual `Xρ`/M3, and an absorption requires the independently established original entrance.

No bound of the required size for these actual high-`b` capacities is established here. The trivial cap only gives order `A_nWν`. Source order alone controls how much hard mass can be placed in a high-cost region, while it does not show that such regions are scarce under the SAME row prior `β`. Shared `q` is kept exactly in `b`; a new proof must estimate its actual high-column capacities or a concrete dual certificate. The exact relaxation can guide that question without discarding the original square, but does not answer it by renaming the surplus.

## 7. Executed finite certificates and minimal reproduction

The local standard-library Fraction run below passed **165 exact assertions**: 15 primal/dual equalities, 15 feasible source allocations, 60 finite-bin enclosure checks, 60 `Δm` gaps, and 15 weighted-cost approximation bounds. It tests ties, zero capacities, and masses `0`/full prior. The costs are abstract bounded allocation data; they are not claimed to realize an original cube kernel or history. The separate numeric author is testing actual one-dimensional fixed-row/source examples with certified spatial cost brackets.

```python
from fractions import Fraction as F
ct=dict(primal_dual=0,capacity=0,bin_bracket=0,bin_gap=0,coefficient_error=0)
cap=F(7,3)
profiles=[([F(0),cap/4,2*cap/3,cap],[F(1,7),F(2,5),F(0),F(4,9)]),
          ([cap/2]*4,[F(1,3),F(1,5),F(2,7),F(3,8)]),
          ([cap,cap/3,cap/3,F(0)],[F(1,4)]*4)]
def greedy(v,B,m):
    x=[F(0)]*len(v); rem=m
    for i in sorted(range(len(v)),key=lambda i:v[i],reverse=True):
        x[i]=min(rem,B[i]); rem-=x[i]
    assert rem==0
    return sum(v[i]*x[i] for i in range(len(v))),x
for vals,B in profiles:
    total=sum(B)
    for m in (F(0),total/5,total/2,total,sum(B[:2])):
        exact,x=greedy(vals,B,m)
        dual=min(m*t+sum(B[i]*max(F(0),vals[i]-t) for i in range(4))
                 for t in set([F(0),cap]+vals))
        assert exact==dual; ct['primal_dual']+=1
        assert sum(x)==m and all(0<=x[i]<=B[i] for i in range(4))
        ct['capacity']+=1
        for N in (1,3,8,17):
            step=cap/N
            lo=[min(N-1,int(v/step))*step for v in vals]
            hi=[min(cap,v+step) for v in lo]
            lower,_=greedy(lo,B,m); upper,_=greedy(hi,B,m)
            assert lower<=exact<=upper; ct['bin_bracket']+=1
            assert upper-lower<=step*m; ct['bin_gap']+=1
        pert=[min(cap,max(F(0),v+F((-1)**i,13)))
              for i,v in enumerate(vals)]
        pe,_=greedy(pert,B,m)
        eta=sum(B[i]*abs(vals[i]-pert[i]) for i in range(4))
        assert abs(pe-exact)<=eta; ct['coefficient_error']+=1
print('PASS',ct,'total',sum(ct.values()))
```
