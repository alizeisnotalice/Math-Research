# R325 actual-column source-capacity optimization

The standalone script passes 9,258 exact certificate checks in three meshes:16 (492 checks),64 (1,788),256 (6,972), plus6 observed refinement-nesting checks. Three fixed actual R324 columns are used: initial, reverse/narrow and twin. Helpers and source profiles are copied self-contained from frozen R324 (`/tmp/r324_numeric.py`, SHA256 e2a09ff6f82b4151b17bb7d3d9f0bcbb9f2d3e905780cf0f137bda3526fc03ab); no old temporary file is imported at runtime.

## Frozen actual geometry and nontrivial source capacity

Keep the R324 finite positive-L1 f, beta=f|D, actual receiver dx, s0,L=R in{1,3/2}, q=h_R*f=1, U,J and H=3/4 unchanged. D=[-1/2,-1/4], beta(D)=1/2. The new original hard source is nu=(1/2)beta|D, mass m=1/4, so nu<=beta<=f and there is genuine allocation freedom. Set K_CZ=3/4: D has nu-average1, while its dyadic parent has average1/2. Thus D is a legitimate maximal bad packet in all three profiles. Its average and parent mass remain fixed under the capacity relaxation.

The actual full-square column is

    b(z)=integral beta(dy) ell(dr) 1_(J_y>=H)
                    [A_yz-A_yz²/J_y].

The two physical prefix weights are1/3 and2/3, including b=2's terminal atom. Exact A and J are those realized in R324, not new row variables. The script integrates b(z) analytically in y at every rational bin midpoint by splitting at y=z and the actual source knots. It retains the SAME beta and J when changing the second source. No smoothed density is used to reconstruct f or q.

Optimize the source-dominance relaxation

    Psi(m)=sup{integral_D b sigma:0<=sigma<=beta|D, sigma(D)=m}.

This is compared with the ACTUAL original source nu and with the SAME whole-packet uniform-reference cost m P_D from R324, where P_D=integral beta ell[a_D-a_D²/J]. In twin the new nu is half of the frozen beta on the whole D; it is not half of the previous R324 two-packet nu. All profile changes are explicit in the script.

## Continuous-column enclosures and exact LP certificates

On D, actual A(y,z) is piecewise affine in z with absolute slope<=1, and0<=A<=J. Therefore absolute slope of A-A²/J is<=1. Since ell's total mass is1, b is Lipschitz with L=beta(D)=1/2. This analytical fact is derived from the actual capture formulas. The finite factor checks corroborate it; they are not offered as a sampled proof of a global derivative bound.

For each spatial bin of width h, exact rational log-series bounds enclose its midpoint value. Adding/subtracting Lh/2 encloses b on the entire bin. Prices are rounded OUTWARD to a common denominator2^80; every rounding is checked exactly. This avoids massive unrelated rational denominators while preserving the certificate.

Bin capacities are the exact beta masses, not lengths. Two fractional-knapsack LPs maximize lower or upper bin prices with total allocated mass m. Every LP has a feasible Fraction primal, exact bathtub dual

    m t + sum_bins capacity*(price-t)_+,

zero primal-dual gap, and the contact rule: fill above t, leave below t, fraction only at ties. There are18 complete LP certificates. The lower primal is a real feasible L1 source: on each bin set sigma=(allocated_mass/beta_bin_mass)beta. Its true objective is at least the lower LP price. The upper LP bounds every continuous feasible source. Thus these are certificates for the actual continuous-column optimum, not just an abstract discretized objective.

If delta is the maximum upper-minus-lower bin price, then upper_opt-lower_opt<=delta*m. Exact checks also give delta<=Lh+2^-78, including log-enclosure and outward-rounding errors. The observed objective intervals shrink by a factor4 at each mesh; refinement nesting is checked for these fixtures, not claimed for arbitrary midpoint schemes.

## Results and source placement

At mesh256 the certified intervals are:

|frozen column|original nu objective|capacity optimum interval|uniform square reference mP_D|
|---|---:|---:|---:|
|initial|.005950138804666|[.008000718117077,.008122788429578]|.007970181500629|
|reverse/narrow|.006069280328941|[.006888507789524,.007010578102024]|.006167977423263|
|twin|.007525537288097|[.009481430889345,.009603501201845]|.007823561648417|

Every finest-mesh optimum lower bound exceeds both the original nu objective and mP_D. Consequently the supremal signed debt Psi-mP_D is rigorously positive in ALL three actual columns. Source capacity alone therefore does not force the R324 reference debt to be nonpositive. This is a finite actual-source conclusion, not a general asymptotic or history counterexample.

The lower-price LP provides these feasible near-optimal source supports at mesh256 (partial boundary bins use the recorded fractions):

* Initial: [-1/2,-503/1024] with mass13/512, and[-209/512,-1/4] with mass115/512.
* Reverse/narrow: [-1/2,-215/512] with mass41/512, and[-291/1024,-1/4] with mass87/512.
* Twin: [-3/8,-1/4] with total mass1/4.

These are certified feasible bin allocations. They are not asserted to be the exact continuous optimizer's contact set. The printed JSON includes both price thresholds, source-mass runs, exact objective bounds, original analytic expressions, optimization gaps and supremal-debt intervals. At mesh16 the reverse-column gain and some debt signs are unresolved; the script reports this rather than replacing the bounds by midpoint guesses.

## Scope and reproduction

The exact same input/kernel/FIRST/cap/receiver geometry from R324 is retained. Optimized sigma is an actual positive-L1 source dominated by beta in the frozen capacity class; it is not asserted to satisfy unverified nu-dependent historical selectors. As in R324, this matched s0,q=1 fixture does not realize the original hard lower band2lambda<h_R*f or the complete R323 residual/core. The bathtub theorem is the supplied analytical relaxation; no general root budget or dimension exponent is inferred.

```
/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 /tmp/r325_numeric.py
```

The script prints deterministic exact JSON and creates no result file. Standard-library Fractions provide all certificate decisions. Existing vendored mpmath is loaded explicitly by fallback only for descriptive decimals; the loaded path is recorded. Exact log-series enclosures, rather than floating-point optimization or rounding, determine every bound and sign.
