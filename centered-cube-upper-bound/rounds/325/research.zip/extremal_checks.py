from fractions import Fraction as F
ct=dict(primal_dual=0,capacity=0,bin_bracket=0,bin_gap=0,coefficient_error=0)
cap=F(7,3)
profiles=[([F(0),cap/4,2*cap/3,cap],[F(1,7),F(2,5),F(0),F(4,9)]),
          ([cap/2]*4,[F(1,3),F(1,5),F(2,7),F(3,8)]),
          ([cap,cap/3,cap/3,F(0)],[F(1,4)]*4)]
def greedy(v,B,m):
    x=[F(0)]*len(v); rem=m
    for i in sorted(range(len(v)),key=lambda i:v[i],reverse=True):
        x[i]=min(rem,B[i]); rem-=x[i]
    assert rem==0
    return sum(v[i]*x[i] for i in range(len(v))),x
for vals,B in profiles:
    total=sum(B)
    for m in (F(0),total/5,total/2,total,sum(B[:2])):
        exact,x=greedy(vals,B,m)
        dual=min(m*t+sum(B[i]*max(F(0),vals[i]-t) for i in range(4))
                 for t in set([F(0),cap]+vals))
        assert exact==dual; ct['primal_dual']+=1
        assert sum(x)==m and all(0<=x[i]<=B[i] for i in range(4))
        ct['capacity']+=1
        for N in (1,3,8,17):
            step=cap/N
            lo=[min(N-1,int(v/step))*step for v in vals]
            hi=[min(cap,v+step) for v in lo]
            lower,_=greedy(lo,B,m); upper,_=greedy(hi,B,m)
            assert lower<=exact<=upper; ct['bin_bracket']+=1
            assert upper-lower<=step*m; ct['bin_gap']+=1
        pert=[min(cap,max(F(0),v+F((-1)**i,13)))
              for i,v in enumerate(vals)]
        pe,_=greedy(pert,B,m)
        eta=sum(B[i]*abs(vals[i]-pert[i]) for i in range(4))
        assert abs(pe-exact)<=eta; ct['coefficient_error']+=1
print('PASS',ct,'total',sum(ct.values()))
