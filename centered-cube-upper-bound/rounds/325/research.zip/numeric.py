#!/usr/bin/env python3
"""R325 actual source-capacitated column optimization. Helpers copied from frozen R324; no runtime dependency on it."""
from fractions import Fraction as F
from math import comb
from collections import Counter
from pathlib import Path
import json,sys
try:import mpmath as mp
except ImportError:
 sys.path.insert(0,'/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor');import mpmath as mp
counts=Counter()
def ck(k,b):
 counts[k]+=1
 assert b,k

def trim(p):
 p=list(p)
 while len(p)>1 and p[-1]==0:p.pop()
 return p

def add(a,b):return trim([(a[i] if i<len(a) else 0)+(b[i] if i<len(b) else 0) for i in range(max(len(a),len(b)))])
def scale(p,c):return trim([x*c for x in p])
def sub(a,b):return add(a,scale(b,-1))
def mul(a,b):
 out=[F(0)]*(len(a)+len(b)-1)
 for i,x in enumerate(a):
  for j,y in enumerate(b):out[i+j]+=x*y
 return trim(out)
def val(p,x):return sum((v*x**i for i,v in enumerate(p)),F(0))
def integ(p,l,h):return sum((v*(h**(i+1)-l**(i+1))/(i+1) for i,v in enumerate(p)),F(0))
def mass(profile):return sum(((h-l)*d for l,h,d in profile),F(0))
def imass(profile,l,h):return sum((max(F(0),min(h,b)-max(l,a))*d for a,b,d in profile),F(0))
def fprofile(local):return [(a+j*F(1,2),b+j*F(1,2),d) for j in range(-3,5) for a,b,d in local]
def overlap(*intervals):return max(F(0),min(i[1] for i in intervals)-max(i[0] for i in intervals))
def Aactual(y,z,full):
 out=overlap((F(-1),F(0)),(y-F(1,2),y+F(1,2)),(z-F(1,2),z+F(1,2)))
 if full:out+=F(2,3)*overlap((F(0),F(1)),(y-F(3,4),y+F(3,4)),(z-F(3,4),z+F(3,4)))
 return out

def fixture(name):
 D=(F(-1,2),F(-1,4))
 if name=='twin':
  d1=(F(-1,2),F(-7,16));d2=(F(-5,16),F(-1,4))
  knots=sorted({*D,*d1,*d2,(d1[0]+d1[1])/2,(d2[0]+d2[1])/2});beta=[];nu=[]
  for a,b in zip(knots,knots[1:]):
   mid=(a+b)/2;inpacket=any(l<mid<h for l,h in [d1,d2]);peak=any(l<mid<(l+h)/2 for l,h in [d1,d2]);density=F(5) if peak else F(1)
   beta.append((a,b,density))
   if inpacket:nu.append((a,b,density))
  packets=[d1,d2]
 else:
  width={'initial':F(1,8),'reverse_narrow':F(1,16),'wide':F(3,16)}[name];height=1+F(1,4)/width
  peak=(D[1]-width,D[1]) if name=='reverse_narrow' else (D[0],D[0]+width)
  knots=sorted({*D,*peak});beta=[(a,b,height if peak[0]<(a+b)/2<peak[1] else F(1)) for a,b in zip(knots,knots[1:])];nu=list(beta);packets=[D]
 return dict(name=name,beta=beta,nu=nu,f=fprofile(beta),packets=packets)
# Bivariate polynomial integration of A and A² over z, yielding y-polynomials.
def moments(profile,full,ymid):
 out=[]
 for power in [1,2]:
  poly=[F(0)]
  for lo,hi,density in profile:
   pieces=[(lo,hi,hi<=ymid)] if not lo<ymid<hi else [(lo,None,True),(None,hi,False)]
   for lower,upper,zless in pieces:
    # A=ay(y)+az*z on the relevant side of z=y.
    ay=([F(1),F(-1)] if zless else [F(1),F(2,3)]) if full else ([F(1,2),F(-1)] if zless else [F(1,2)])
    az=(F(2,3) if zless else F(-1)) if full else (F(0) if zless else F(-1))
    for j in range(power+1):
     yp=[F(1)]
     for _ in range(power-j):yp=mul(yp,ay)
     coeff=comb(power,j)*az**j*density/F(j+1)
     for bound,sign in [(upper,1),(lower,-1)]:
      term=([F(0)]*(j+1)+yp) if bound is None else scale(yp,bound**(j+1))
      poly=add(poly,scale(term,coeff*sign))
  out.append(poly)
 return out

def integrate_ratio(numer,J,lo,hi):
 q=[F(0)]*max(1,len(numer)-1);r=trim(numer)
 while len(r)>=len(J) and any(r):
  degree=len(r)-len(J);c=r[-1]/J[-1];q[degree]+=c;r=sub(r,[F(0)]*degree+scale(J,c))
 constant=integ(q,lo,hi);coef=r[0]/J[1] if r else F(0);arg=val(J,hi)/val(J,lo)
 return constant,{arg:coef} if coef else {}
def expr_add(a,b):
 c=a[0]+b[0];logs=dict(a[1])
 for arg,v in b[1].items():logs[arg]=logs.get(arg,F(0))+v
 return c,{a:c for a,c in logs.items() if c}
def expression(P,S,J,lo,hi):
 c,l=integrate_ratio(S,J,lo,hi);return integ(P,lo,hi)-c,{a:-v for a,v in l.items()}
def evaluate(e,dps):
 with mp.workdps(dps):
  cv=lambda x:mp.mpf(x.numerator)/x.denominator
  return cv(e[0])+sum((cv(c)*mp.log(cv(a)) for a,c in e[1].items()),mp.mpf(0))
def log_interval(x,terms=32):
 if x==1:return F(0),F(0)
 if x<1:
  lo,hi=log_interval(1/x,terms);return -hi,-lo
 t=(x-1)/(x+1);lo=2*sum((t**(2*j+1)/F(2*j+1) for j in range(terms)),F(0));rem=2*t**(2*terms+1)/((2*terms+1)*(1-t*t))
 return lo,lo+rem
def expression_interval(e):
 lo=hi=e[0]
 for arg,c in e[1].items():
  a,b=log_interval(arg)
  if c>=0:lo+=c*a;hi+=c*b
  else:lo+=c*b;hi+=c*a
 return lo,hi
def encoded(e):return dict(rational=str(e[0]),logs=[dict(argument=str(a),coefficient=str(c)) for a,c in sorted(e[1].items())])
def bernstein_coefficients(poly,lo,hi):
 degree=len(poly)-1;shift=[F(0)]*(degree+1)
 for i,v in enumerate(poly):
  for j in range(i+1):shift[j]+=v*comb(i,j)*lo**(i-j)*(hi-lo)**j
 b=[sum((shift[i]*F(comb(j,i),comb(degree,i)) for i in range(j+1)),F(0)) for j in range(degree+1)]
 return b
def bernstein_sign(poly,lo,hi):
 b=bernstein_coefficients(poly,lo,hi)
 return 'nonpositive' if max(b)<=0 else 'nonnegative' if min(b)>=0 else 'mixed'

def column(z,beta):
 out=(F(0),{})
 for full,weight in [(False,F(1,3)),(True,F(2,3))]:
  J=[F(1),F(-1,3)] if full else [F(1,2),F(-1)]
  for a,b,density in beta:
   cuts=sorted({a,b}|({z} if a<z<b else set()))
   for lo,hi in zip(cuts,cuts[1:]):
    yless=(lo+hi)/2<z
    A=([1-z,F(2,3)] if yless else [1+F(2,3)*z,F(-1)]) if full else ([F(1,2)-z] if yless else [F(1,2),F(-1)])
    out=expr_add(out,expression(scale(A,density*weight),scale(mul(A,A),density*weight),J,lo,hi))
 return out

def whole_integrals(beta):
 whole=(F(-1,2),F(-1,4));original=(F(0),{});reference=(F(0),{})
 for full,weight in [(False,F(1,3)),(True,F(2,3))]:
  J=[F(1),F(-1,3)] if full else [F(1,2),F(-1)]
  knots=sorted({x for a,b,d in beta for x in [a,b]})
  for lo,hi in zip(knots,knots[1:]):
   mid=(lo+hi)/2;density=sum(d for a,b,d in beta if a<mid<b)
   P,S=moments(beta,full,mid);a,a2=moments([(whole[0],whole[1],F(4))],full,mid)
   original=expr_add(original,expression(scale(P,density*weight/2),scale(S,density*weight/2),J,lo,hi))
   reference=expr_add(reference,expression(scale(a,density*weight/4),scale(mul(a,a),density*weight/4),J,lo,hi))
 return original,reference

def greedy(capacity,prices,m):
 order=sorted(range(len(capacity)),key=lambda i:(-prices[i],i));left=m;allocation=[F(0)]*len(capacity)
 for i in order:
  take=min(left,capacity[i]);allocation[i]=take;left-=take
  if not left:break
 ck('LP_exact_mass',left==0 and sum(allocation)==m)
 ck('LP_capacity_feasible',all(0<=x<=c for x,c in zip(allocation,capacity)))
 objective=sum((x*p for x,p in zip(allocation,prices)),F(0))
 last=next(i for i in reversed(order) if allocation[i]>0)
 threshold=prices[last]
 dual=m*threshold+sum((c*max(F(0),p-threshold) for c,p in zip(capacity,prices)),F(0))
 ck('LP_bathtub_dual_zero_gap',dual==objective)
 ck('LP_contact_fill',all((x==c if p>threshold else x==0 if p<threshold else True) for x,c,p in zip(allocation,capacity,prices)))
 return objective,allocation,threshold

def runs(allocation,caps,edges):
 out=[];start=None;end=None;massrun=F(0)
 for i,x in enumerate(allocation):
  if x:
   if start is None:start=edges[i]
   end=edges[i+1];massrun+=x
  elif start is not None:
   out.append(dict(interval=[str(start),str(end)],mass=str(massrun)));start=end=None;massrun=F(0)
 if start is not None:out.append(dict(interval=[str(start),str(end)],mass=str(massrun)))
 return out

def pretty_fraction(x):
 with mp.workdps(40):return mp.nstr(mp.mpf(x.numerator)/x.denominator,22)
def optimize(model,mesh):
 beta=model['beta'];D=(F(-1,2),F(-1,4));B=mass(beta);m=B/2;KCZ=F(3,4);Lip=B;h=(D[1]-D[0])/mesh
 ck('source_capacity_nontrivial',0<m<B)
 ck('frozen_CZ_actual',m/(D[1]-D[0])>KCZ and m/F(1,2)<=KCZ)
 ck('original_source_order',all(d/2<=d for a,b,d in beta))
 ck('frozen_source_mass',B==F(1,2))
 edges=[D[0]+h*i for i in range(mesh+1)];caps=[];lower=[];upper=[]
 for lo,hi in zip(edges,edges[1:]):
  center=(lo+hi)/2;exact=column(center,beta);a,b=expression_interval(exact)
  ck('column_log_interval_order',a<=b)
  cap=imass(beta,lo,hi);caps.append(cap)
  # Outward dyadic repair keeps exact certificates compact.
  denominator=2**80;pl=max(F(0),a-Lip*h/2);pu=b+Lip*h/2
  lower.append(F((pl*denominator).numerator//(pl*denominator).denominator,denominator))
  scaled=pu*denominator;upper.append(F(-((-scaled.numerator)//scaled.denominator),denominator))
  ck('outward_dyadic_price_certificate',lower[-1]<=pl and pu<=upper[-1])
  ck('point_column_nonnegative',a>=0)
  # Actual affine-in-z derivative coefficients are bounded by1 on each side;
  # |1-2A/J|<=1 since actual0<=A<=J, yielding Lip integralβ=B.
  for y in [D[0],(D[0]+D[1])/2,D[1]]:
   for full in [False,True]:
    J=1-y/3 if full else F(1,2)-y;A=Aactual(y,center,full)
    ck('actual_column_Lipschitz_factors',0<=A<=J and abs(1-2*A/J)<=1)
 ck('all_bin_source_mass_once',sum(caps)==B)
 low,xlow,tlow=greedy(caps,lower,m);high,xhigh,thigh=greedy(caps,upper,m)
 width=max(u-l for l,u in zip(lower,upper))
 ck('capacity_optimum_enclosure_order',low<=high)
 ck('delta_error_mass_budget',high-low<=width*m)
 ck('nominal_spatial_error_plus_roundoff',width<=Lip*h+F(1,2**78))
 # Canonical original source theta=1/2 is feasible in the SAME capacity set.
 original,reference=whole_integrals(beta);origlo,orighi=expression_interval(original);reflo,refhi=expression_interval(reference)
 ck('original_fractional_source_feasible',sum(c/2 for c in caps)==m)
 ck('original_below_optimum_upper',orighi<=high)
 gaplo=low-orighi;gaphi=high-origlo;debtlo=low-refhi;debthi=high-reflo
 ck('optimization_gap_enclosure',gaplo<=gaphi)
 ck('supremal_debt_enclosure',debtlo<=debthi)
 return dict(fixture=model['name'],mesh=mesh,source_capacity=str(B),allocated_mass=str(m),CZ_threshold=str(KCZ),Lip=str(Lip),binwidth=str(h),objective_lower=str(low),objective_upper=str(high),certificate_width=str(high-low),width_budget=str(width*m),original_objective=encoded(original),original_value=mp.nstr(evaluate(original,65),22),reference_value=mp.nstr(evaluate(reference,65),22),lower_value=pretty_fraction(low),upper_value=pretty_fraction(high),gap_lower=str(gaplo),gap_upper=str(gaphi),gap_certified_positive=gaplo>0,supremal_debt_lower=str(debtlo),supremal_debt_upper=str(debthi),supremal_debt_sign='positive' if debtlo>0 else 'negative' if debthi<0 else 'unresolved',lower_allocation_runs=runs(xlow,caps,edges),upper_allocation_runs=runs(xhigh,caps,edges),lower_dual_threshold=str(tlow),upper_dual_threshold=str(thigh))
def main():
 reports=[];stages=[]
 for mesh in [16,64,256]:
  before=sum(counts.values())
  for name in ['initial','reverse_narrow','twin']:reports.append(optimize(fixture(name),mesh))
  stages.append(dict(mesh=mesh,fixtures=3,checks=sum(counts.values())-before))
 before=sum(counts.values())
 for name in ['initial','reverse_narrow','twin']:
  rows=[r for r in reports if r['fixture']==name]
  for a,b in zip(rows,rows[1:]):ck('observed_refinement_nested_certificates',F(b['objective_lower'])>=F(a['objective_lower']) and F(b['objective_upper'])<=F(a['objective_upper']))
 stages.append(dict(mesh='refinement_check',fixtures=3,checks=sum(counts.values())-before))
 print(json.dumps(dict(status='PASS',check_counts=dict(counts),total_checks=sum(counts.values()),stages=stages,results=reports,mpmath_loaded_from=mp.__file__,scope='Source-dominance bathtub relaxation for the fixed actual R3241D column. Spatial-bin LP bounds are certified by exact capacity/primal-dual arithmetic, rational logarithm enclosures and the analytical actual-column Lipschitz bound. Optimizer is not asserted to realize new history-dependent selectors.'),sort_keys=True))
if __name__=='__main__':main()
