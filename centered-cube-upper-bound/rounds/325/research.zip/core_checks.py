from fractions import Fraction as F
import math
count=0
for ri in range(1,33):
    r=F(ri,16)
    for ti in range(1,2*ri+1):
        t=F(ti,16)
        actual=2*(t/2-(t/2)**2/(2*r))/t
        expected=1-t/(4*r)
        assert actual==expected
        count+=1
vals=[(4*(1+n*math.log(2))**2/(3*math.sqrt(n))*(7/8)**n,n)
      for n in range(1,10001)]
assert count==1056
assert all(v<56 for v,n in vals)
print(count,max(vals))
