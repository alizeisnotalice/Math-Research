"""R845. Replay the shared real right-hand source on the four R844 cores."""
from fractions import Fraction as F
from itertools import product


WIDTH = F(1, 256)
RADIUS = F(5, 64)
SIGNS = tuple(product((-1, 1), repeat=2))


def norm(a, folded):
    def size(t):
        if folded:
            t %= 1
            return min(t, 1 - t)
        return abs(t)
    return max(size(t) for t in a)


def law_for_group(sign_y):
    large = sign_y == 1
    length, center, offset, mass = ((F(2), F(31, 32), F(31, 16), F(4))
                                     if large else
                                     (F(17, 16), F(15, 32), F(7, 8), F(1, 4)))
    signs = tuple(s for s in SIGNS if s[1] == sign_y)
    # The original four source and four receiver squares have half-width WIDTH.
    sources = [((F(0), F(0)), F(1))]
    for s in SIGNS:
        private = F(31, 16) if s[1] == 1 else F(7, 8)
        sources.append((tuple(sign * private for sign in s), F(4) if s[1] == 1 else F(1, 4)))
    for s in signs:
        x = tuple(sign * center for sign in s)
        seen = []
        for a, value in sources:
            dist = max(abs(u-v) for u, v in zip(a, x))
            if dist + 2*WIDTH < length/2:
                seen.append(value)
                if large:
                    assert dist - 2*WIDTH > F(61, 64)
            else:
                assert dist - 2*WIDTH > 1
        assert sum(seen) == 1 + mass
    assert 1 < (1+mass)/length**2 < 2
    cap = (1+mass)/(2*F(61, 64))**2 if large else 1+mass
    assert cap < 2
    occup = (2*WIDTH)**2
    real = 2*occup*(1+mass)/length**4
    points = [(F(0), F(0))] + [tuple(F(sign)*offset/length for sign in s) for s in signs]
    probs = (1/(1+mass), mass/(2*(1+mass)), mass/(2*(1+mass)))
    assert sum(probs) == 1
    output = []
    for folded in (False, True):
        hits = []
        for a in points:
            line = []
            for b in points:
                d = norm(tuple(x-y for x,y in zip(a,b)), folded)
                # Same original z and same true witness side in this group:
                # uncertainty is just the difference of two source-square offsets.
                slack = 2*WIDTH/length
                assert d+slack <= RADIUS or d-slack > RADIUS
                line.append(d+slack <= RADIUS)
            hits.append(line)
        p = tuple(sum(w for w,ok in zip(probs, row) if ok) for row in hits)
        output.append(sum(w*v for w,v in zip(probs,p)))
        print("  ", "mod 1" if folded else "physical", "conditional probabilities", *(str(x) for x in p),
              "mean", output[-1], "original mass in the double draw", real*output[-1])
    return real, tuple(output)


def cutoff():
    # Prices are normalized before averaging. Test the low-mass exclusion,
    # including the n+1 endpoint and the case all bins are paid at the top.
    cases = 0
    max_ratio = F(0)
    for n in (1, 2, 4, 8, 16, 32, 64):
        for h in (0, 1, n//2, n, n+1, 2*n):
            for a in (-7, -1, 0, 2, n//2, n, n+12):
                for b in (-8, -1, 0, 1, 5, n//2+4, n+12):
                    m, W = F(2)**a, F(2)**b
                    s = sum((min(F(1), W/F(2)**i)
                             for i in range(n+1) if i>n-h or m <= 2*F(2)**(i+h)), F(0))
                    basis = 1+h+max(b-a,0)
                    assert s <= 4*basis
                    cases += 1
                    max_ratio = max(max_ratio,s/basis)
    print("Dyadic row stress cases", cases, "largest ratio to 1+h+log2_plus(W/m)", max_ratio)


if __name__ == "__main__":
    print("Right source is the actual common positive-width R844 square. Real receivers have disjoint areas.")
    small = law_for_group(-1)
    large = law_for_group(1)
    assert small[1] == (F(33,50), F(33,50))
    assert large[1] == (F(9,25), F(1))
    print("Actual ordered masses with common right source: small", small[0], "large", large[0])
    cutoff()
