"""Float64 Monte Carlo for the periodic lattice window in round 845."""
from decimal import Decimal, localcontext
from math import isqrt, log, log1p
from os import environ
from random import Random

for name in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "VECLIB_MAXIMUM_THREADS",
             "MKL_NUM_THREADS", "BLIS_NUM_THREADS", "NUMEXPR_NUM_THREADS"):
    environ[name] = "1"

import numpy as np
import scipy
from scipy import stats

BATCH = 128
SEED = 84520261126
LN2 = log(2)
TOL = 1e-10


def grid_info(n):
    m = 1 + isqrt(n - 1)
    side = m * np.exp2(np.arange(n + 1) / n)
    inside = np.floor(side).astype(int)
    assert side[0] == m and side[-1] == 2 * m
    return m, side, inside


def inverted_order(u):
    return 1 - u[..., ::-1]


def maxima(u, m):
    n = u.shape[-1]
    rank = np.arange(1, n + 1)
    best = np.full(len(u), -np.inf)
    where = np.full(len(u), float(m))
    for k in range(m, 2 * m):
        frac = u if k % 2 == 0 else inverted_order(u)
        scores = rank * log1p(1 / k) - n * np.log1p(frac / k)
        winner = n - 1 - np.argmax(scores[:, ::-1], axis=1)
        rows = np.arange(len(u))
        score = scores[rows, winner]
        update = score >= best
        best[update] = score[update]
        where[update] = k + frac[rows[update], winner[update]]
    return best, np.where(best > 0, where, m)


def grid_counts(u, side, inside):
    frac = side - inside
    odd = inside % 2 == 1
    count = np.empty((len(u), len(side)), dtype=int)
    for row, sorted_u in enumerate(u):
        count[row, ~odd] = np.searchsorted(sorted_u, frac[~odd], side="right")
        count[row, odd] = np.searchsorted(inverted_order(sorted_u), frac[odd], side="right")
    return count


def measure(u, m, side, inside):
    n = u.shape[-1]
    peak, where = maxima(u, m)
    frac = side - inside
    count = grid_counts(u, side, inside)
    exponent = count * np.log1p(1 / inside) - n * np.log1p(frac / inside)
    grid_peak = exponent.max(axis=1)
    assert np.all(grid_peak <= np.maximum(0, peak) + TOL)
    band = (peak > 0) & (peak <= LN2)
    assert not np.any((np.minimum(abs(peak), abs(peak - LN2))) < TOL)

    # Clipping at 2 is inactive on the true band. Cap before exp on other rows.
    rho = np.exp(np.minimum(LN2, exponent))
    energy = np.diff(rho, axis=1) ** 2
    prefix = np.concatenate((np.zeros((len(u), 1)), energy.cumsum(axis=1)), axis=1)
    upward = np.searchsorted(side, where, side="left")
    downward = np.searchsorted(side, where, side="right") - 1
    rows = np.arange(len(u))

    def centered(indices):
        start = np.clip(indices - m // 2, 0, n - m)
        return prefix[rows, start + m] - prefix[rows, start]

    full = prefix[:, -1]
    upper = centered(upward)
    lower = centered(downward)
    best = (prefix[:, m:] - prefix[:, :-m]).max(axis=1)
    mass = np.exp(2 * np.minimum(peak, LN2)) * band
    result = np.column_stack((band, full * band, upper * band, lower * band,
                              best * band, mass))
    diagnostics = (int(np.sum((grid_peak <= 0) & band)),
                   int(np.sum((grid_peak <= LN2) & (peak > LN2))),
                   float(np.minimum(abs(peak), abs(peak - LN2)).min()))
    return result, diagnostics


def independent_check(x):
    """Enumerate actual lattice points and process physical entry radii."""
    n = len(x)
    m, side, inside = grid_info(n)
    scale = 2 ** 52
    coords = [int(float(v) * (2 * scale)) for v in x]
    events = sorted((abs(2 * scale * z - v), j)
                    for j, v in enumerate(coords) for z in range(-m, m + 2)
                    if m * scale < abs(2 * scale * z - v) < 2 * m * scale)
    assert len(events) == n * m
    logs = [0.0] + [log1p(1 / k) for k in range(1, 2 * m)]
    counts = [m] * n
    weight = 0.0
    drift = 0.0
    best, at = 0.0, m * scale
    top_count = None
    for index, (threshold, j) in enumerate(events):
        increment = logs[counts[j]] - drift
        updated = weight + increment
        drift = (updated - weight) - increment
        weight = updated
        counts[j] += 1
        if index + 1 < len(events) and events[index + 1][0] == threshold:
            continue
        score = weight - n * log1p((threshold - m * scale) / (m * scale))
        if score >= best:
            best, at, top_count = score, threshold, counts.copy()
    u = np.sort(2 * np.minimum(x, 1 - x))[None, :]
    rank_max, rank_at = maxima(u, m)
    rank_max = max(0, rank_max[0])
    assert abs(best - rank_max) < TOL
    actual_counts = (np.floor(x[None, :] + side[:, None] / 2)
                     - np.ceil(x[None, :] - side[:, None] / 2) + 1)
    assert np.array_equal((actual_counts - inside[:, None]).sum(axis=1),
                          grid_counts(u, side, inside)[0])
    decimal_error = 0.0
    if top_count is not None:
        with localcontext() as context:
            context.prec = 60
            tally = sum((Decimal(v).ln() * top_count.count(v) for v in set(top_count)), Decimal(0))
            true_score = tally - n * (Decimal(at) / scale).ln()
            decimal_error = abs(float(true_score) - rank_max)
            assert decimal_error < TOL
    return abs(best - rank_max), abs(at / scale - rank_at[0]), decimal_error


def matched_precheck():
    print("MATCHED PRECHECK / stdlib seed=845314, shared sorted U, 96 per n")
    rng = Random(845314)
    expected_hits = (56, 50, 45)
    expected_full = (1.885144, 3.690275, 6.472742)
    expected_down = (0.416517, 0.394010, 0.366925)
    for n, hits, baseline, reference in zip((64, 256, 1024), expected_hits,
                                           expected_full, expected_down):
        m, grid, k = grid_info(n)
        u = np.sort(np.array([[rng.random() for _ in range(n)] for _ in range(96)]), axis=1)
        data, _ = measure(u, m, grid, k)
        avg = data.mean(axis=0)
        assert int(data[:, 0].sum()) == hits and abs(avg[1] - baseline) < 1e-6
        assert abs(avg[3] - reference) < 1e-6
        print(f"n={n:4d} accepted={hits:2d} full={avg[1]:.6f} "
              f"local_up={avg[2]:.6f} local_down={avg[3]:.6f} best_local={avg[4]:.6f}")


def sample(n, size):
    m, side, inside = grid_info(n)
    rng = np.random.Generator(np.random.PCG64(np.random.SeedSequence([SEED, n])))
    records, diagnostics, validated = [], [], []
    for start in range(0, size, BATCH):
        x = rng.random((min(BATCH, size - start), n))
        u = 2 * np.minimum(x, 1 - x)
        assert np.all((0 < u) & (u < 1))
        if start == 0:
            for centers in (x[0], x[1], np.full(n, 3 / 8),
                            (np.arange(n) + 0.5) / (2 * n)):
                validated.append(independent_check(centers))
        data, diagnostic = measure(np.sort(u, axis=1), m, side, inside)
        records.append(data)
        diagnostics.append(diagnostic)
    rows = np.concatenate(records)
    hit, full, local, down, best, root = rows.mean(axis=0)
    ratio = local / full
    ratio_se = stats.sem(rows[:, 2] - ratio * rows[:, 1]) / full
    counts = int(rows[:, 0].sum())
    misses = sum(d[0] for d in diagnostics)
    extras = sum(d[1] for d in diagnostics)
    margin = min(d[2] for d in diagnostics)
    sweep, witness, decimal = np.max(validated, axis=0)
    print(f"n={n} m={m} centers={size} accepted={counts} p={hit:.6f} "
          f"full={full:.6f} ± {stats.sem(rows[:, 1]):.6f} "
          f"local_up={local:.6f} ± {stats.sem(rows[:, 2]):.6f}")
    print(f"  paired local/full={ratio:.6f} ± {ratio_se:.6f} "
          f"local_down={down:.6f} best_local={best:.6f} "
          f"true_witness_square={root:.6f} grid_band_misses/extras={misses}/{extras}")
    print(f"  min log-margin={margin:.3e}; independent physical sweep on 4 centers "
          f"max log-value discrepancy={sweep:.3e}, side discrepancy={witness:.3e}, "
          f"60-digit witness discrepancy={decimal:.3e}")


if __name__ == "__main__":
    print(f"NumPy {np.__version__}, SciPy {scipy.__version__}; λ=1; true band 1<M_[1,2]<=2; "
          "normalization by all sampled centers; ± denotes one Monte Carlo SE.")
    matched_precheck()
    for n, size in ((64, 4096), (256, 8192), (1024, 8192)):
        print(f"{'INITIAL SCREEN' if n == 64 else 'EXPANDED RANGE'} / PCG64 SeedSequence([{SEED}, {n}])")
        sample(n, size)
