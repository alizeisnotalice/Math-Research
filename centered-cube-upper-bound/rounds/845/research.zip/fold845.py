"""Exact replay: cubical overlap periodization and actual folded receipts (R845)."""

from decimal import Decimal, localcontext
from fractions import Fraction as F
from itertools import combinations, product
from math import ceil, floor, prod
import sys


def tent(displacement, side, delta=F(0)):
    return max(F(0), 1 - max(F(0), abs(displacement) - delta) / side)


def folds(theta, side, delta=F(0), period=None):
    period = side if period is None else period
    lower = floor((-side - delta - theta) / period)
    upper = ceil((side + delta - theta) / period)
    return tuple(w for k in range(lower, upper + 1)
                 if (w := tent(theta + k * period, side, delta)) > 0)


def one_dim_checks():
    delta_values = (F(0), F(1, 128), F(1, 3), F(1), F(7, 3))
    side_values = (F(1), F(17, 16), F(7, 4), F(2))
    phases = (F(0), F(1, 2), F(1, 3), F(-7, 5), F(5, 7))
    for side, delta, u in product(side_values, delta_values, phases):
        theta = side * u
        assert sum(folds(theta, side, delta)) == 1 + 2 * delta / side
    for delta, u in product(delta_values[:3], phases):
        effective_side = 2 - 2 * delta
        assert effective_side + 2 * delta == 2
        assert sum(folds(2 * u, effective_side, delta, 2)) == 1
    fixed_s = F(2)
    assert all(sum(folds(fixed_s * u, fixed_s, period=1)) == 2 for u in phases)
    assert sum(folds(F(0), fixed_s, period=3)) == 1
    assert sum(folds(F(3, 2), fixed_s, period=3)) == F(1, 2)
    print("1D exact: 100 matched-period checks, 15 bottom-band checks.")
    print("Period 1 at s=2 sums to 2; period 3 has sums 1 and 1/2.")


def short_list_checks():
    sides = (F(17, 16), F(7, 4), F(2))
    deltas = (F(1, 128), F(1, 64), F(1, 32))
    phases = ((F(0), F(0), F(0)), (F(1, 2),) * 3,
              (F(1, 3), F(5, 7), F(-7, 5)))
    totals = []
    for u in phases:
        weights = [folds(s * q, s, d) for s, d, q in zip(sides, deltas, u)]
        envelope = sum(prod(entry) for entry in product(*weights))
        assert envelope == prod(1 + 2 * d / s for s, d in zip(sides, deltas))
        bare = prod(sum(folds(s * q, s)) for s, q in zip(sides, u))
        assert bare == 1
        totals.append(envelope)
    assert sum(totals) == len(phases) * totals[0]
    print("3D local list, variable physical periods", sides, "absolute errors", deltas)
    print("  three phases zero, boundary, generic; bare per phase = 1,")
    print("  thick per phase =", totals[0], "; sum of three envelopes =", sum(totals))


def sup_dist(a, b):
    return max(abs(x - y) for x, y in zip(a, b, strict=True))


def show(value):
    with localcontext() as ctx:
        ctx.prec = 15
        return str(Decimal(value.numerator) / Decimal(value.denominator))


def positive_receivers_2d():
    eps = F(1, 256)
    q_mass = F(1, 4)
    delta = 2 * eps
    q_origin = (F(0), F(0))
    signs = tuple(product((-1, 1), repeat=2))
    private_masses = {s: F(1) if s[-1] == -1 else F(3) for s in signs}
    total_source = q_mass + sum(private_masses.values())
    area = (2 * eps)**2
    rows = []
    for s in signs:
        small = s[-1] == -1
        center = tuple(t * (F(1, 2) if small else F(3, 16)) for t in s)
        side = F(17, 16) if small else F(7, 4)
        private = private_masses[s]
        v = side**2
        assert max(sup_dist(center, s), sup_dist(center, q_origin)) + 2 * eps < side / 2
        other_min = 2 * min(sup_dist(center, other) - 2 * eps
                            for other in signs if other != s)
        assert other_min > 2
        assert q_mass + private > v
        assert (1 if small else 2) <= v < (2 if small else 4)
        # On smaller scales the q-only density is bounded at first q entry.
        q_min = 2 * (sup_dist(center, q_origin) - 2 * eps)
        # If a private source is hit, charge the full two-packet mass.
        a_min = 2 * (sup_dist(center, s) - 2 * eps)
        assert q_mass / q_min**2 < 2
        assert (q_mass + private) / a_min**2 < 2
        assert total_source / other_min**2 < 2
        receipt_coeff = area * private / v**2
        rows.append((s, center, v, private, receipt_coeff))
    assert all(sup_dist(c, d) > 2 * eps for (_, c, *_), (_, d, *_) in combinations(rows, 2))
    assert total_source == F(33, 4)
    assert all(sum(folds(F(sj), F(2))) == 1 for s in signs for sj in s)
    assert sum(prod(tent(F(sj), F(2)) for sj in s) for s in signs) == 1
    thick_envelopes = [prod(tent(F(sj), F(2), delta) for sj in s) for s in signs]
    assert sum(thick_envelopes) == (1 + delta)**2
    z_receipt = sum(coeff for *_, coeff in rows)
    ordered_mass = q_mass * z_receipt
    both_orders = 2 * ordered_mass
    all_tau = area * sum((q_mass + private)**2 / v**2 for _, _, v, private, _ in rows)
    zero_phase = area * sum((q_mass**2 + private**2) / v**2 for _, _, v, private, _ in rows)
    assert all_tau == both_orders + zero_phase
    # Conditional on the same z in the real q packet, each coordinate of
    # a-z differs from its nominal sign by a triangular difference on [-2eps,2eps].
    clipped_tail = (2 * eps - eps)**2 / (2 * (2 * eps)**2)
    generic_mass = both_orders * (1 - clipped_tail)
    assert generic_mass == F(7, 8)*both_orders
    local_union_mass = all_tau
    assert max(zero_phase, both_orders, generic_mass) <= local_union_mass
    # For z in half of the actual q packet, the adaptive phase subtracts
    # z exactly and leaves all private packets within eps of the coset.
    assert eps < delta < 1 - 2 * eps and all((sj - 1) % 2 == 0 for s in signs for sj in s)
    adaptive_mass = ordered_mass / 2
    # Shared real endpoint resampling, with two actual Lebesgue receiver factors.
    coeff = tuple(row[-1] for row in rows)
    gamma = [[q_mass * ri * rj / z_receipt for rj in coeff] for ri in coeff]
    assert [sum(entries) for entries in gamma] == [q_mass * ri for ri in coeff]
    assert list(map(sum, zip(*gamma))) == [q_mass * ri for ri in coeff]
    assert sum(map(sum, gamma)) == ordered_mass
    print("2D actual dyadic volume bins: lambda=1, 1<M<=2 over all positive lengths.")
    print("  four disjoint receivers area each", area, "; source packet half-width", eps,
          "; total source", total_source)
    for s, ctr, v, private, r in rows:
        print("  sign", s, "center", ctr, "v", v, "left mass", private,
              "int dx/v", area/v, "raw per-unit-right mass", r,
              "one-direction ordered raw", q_mass*r)
    print("  common real q mass", q_mass, "; common receipt per unit eta(q)", z_receipt)
    print("  ordered q->private original mass", ordered_mass,
          "; both orders", both_orders, "; full raw tau on tested E", all_tau)
    print("  fixed zero/generic phases", zero_phase, generic_mass,
          "; local list union", local_union_mass)
    print("  z-dependent phase: theta=(1,1)-z on the negative half of q, zero")
    print("  otherwise; ordered q->private accepted mass", adaptive_mass)
    print("  16 shared-z two-receiver entries, both Lebesgue marginals checked.")


def high_dim_checks():
    print("High-dimensional positive width pressure, l=2, lambda=1, actual [1,2] window.")
    for n in (16, 128, 1024, 4096):
        eps = F(1, 128*n)
        beta = F(1, 5*n)
        delta = 2*eps
        assert 0 < eps < beta < F(1, 2)
        witness_v = 2**n
        packet_mass = F(3, 4)*witness_v
        # The useable part of each orthant is eps<signed x_i<1-eps,
        # with at least one signed coordinate <=beta and one >=1-beta.
        # Their Lebesgue volume is computed by exact inclusion and exclusion.
        area = (1 - 2*eps)**n - 2*(1 - beta - eps)**n + (1 - 2*beta)**n
        assert area > 0
        assert (1 - beta - eps)**n >= 1 - n*(beta + eps) > F(3, 4)
        assert 1 < 2*packet_mass/witness_v < 2
        assert 2*packet_mass/(2*(1-beta-eps))**n < 2
        # No opposite-direction packet can enter a witness at any l<=2,
        # as signed receiver coordinates are >eps. Each of the two
        # eligible sources has l/2 >= 1-beta-eps when it first enters.
        h = tent(F(1), F(2))
        assert h == F(1, 2)
        directions = 2**n
        assert directions * h**n == 1
        assert directions * tent(F(1), F(2), delta)**n == (1+delta)**n
        assert len(folds(F(0), F(2), delta)) == 3
        assert len(folds(F(1), F(2), delta)) == 2
        assert len(folds(F(2, 3), F(2), delta)) == 2
        shared_z_receipt = directions * area * packet_mass / witness_v**2
        mass = packet_mass * shared_z_receipt
        total_source = (1+directions)*packet_mass
        assert shared_z_receipt == F(3, 4)*area
        assert mass / 2**n == F(9, 16)*area
        assert mass / total_source == F(3, 4)*area/(1+directions)
        print(" n", n, "eps", eps, "delta", delta,
              "nominal positive lifts 2^n, thick zero phase 3^n")
        print("   directional actual int dx/v =", show(area), "*2^(-n); sum =", show(area))
        print("   q-receipt per unit eta(q) =", show(shared_z_receipt),
              "; ordered raw mass =", show(mass/2**n), "*2^n")
        print("   total eta =", show(total_source / 2**(2*n)), "*2^(2n); original share =",
              show(2**n*mass / total_source), "*2^(-n)")
        print("   thick envelope sum", show((1+delta)**n),
              "; bare envelope sum 1; single direction bare envelope 2^(-n)")


if __name__ == "__main__":
    print(sys.version)
    one_dim_checks()
    short_list_checks()
    positive_receivers_2d()
    high_dim_checks()
    print("All exact assertions passed. Decimal fields are display only.")
