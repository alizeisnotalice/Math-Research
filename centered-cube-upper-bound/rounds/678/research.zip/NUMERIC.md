# R678 exact finite halo-product decomposition

Executed with `/Users/zzh/.local/share/math-research-tools/venv/bin/python`, Python 3.12.14. Input SHA256 `51133281e98e46889690d01d1a3a47a114c6dad79ec123cb9d3929f95e16d642`; script SHA256 `72123da4e4a22aff73c601f6182a1ea7940b9792808ffb87eed3e4eeb5ac7d8b`.

All 120 fixture/policy/degree records and 930 deduplicated key product identities passed using Fraction arithmetic. The existing 10 R677 fixtures were read without rerunning geometry. Both policies and k=1,...,6 are included. Full source labels, multiplicities, earliest eligible group, original anchor radius, intersection lengths and each codimension term are saved.

For each key, write t=2*c0*rho and intersection side lengths ell. The exact weighted j-term is (q^m/m!)*t^j*e_(n-j)(ell). Its sum over j agrees exactly with direct weighted product volume. Aggregate shares are formed after summing over distinct multi-index keys within one fixture/policy/k; no independent tuple double counting.

| Quantity | Minimum | Maximum |
|---|---:|---:|
| unexpanded_full_ratio | 0.0131264727288 | 0.492307692308 |
| top_codimension_share | 0.0158700931912 | 0.507692307692 |
| upper_half_codimension_share | 0.503885975588 | 0.785699065115 |

High codimension terms cannot be discarded in these finite examples: the table reports their actual aggregate shares. This is finite structural evidence, not an asymptotic estimate. Unexpanded/full means the j=0 contribution divided by all j contributions. “Upper half” means j>=ceil(n/2), including j=n.

PRODUCT_SUMMARY.json contains all 120 aggregate records and three-stage statistics without per-key details; it binds the full local result by SHA256 `bb4053701e5644ae3541d14b6a26cde93cf2ba7ba574ffb5cfb59e08586b4ed7`. Input is not duplicated: retrieve WITNESS_RESULT.json from the R677 research archive, verify the input hash above, and place it adjacent to this script or pass --input /path/to/WITNESS_RESULT.json.

Requested stage views are explicitly marked in JSON: initial n=1,2 and k=1,2; multiscale stress k=3,4; expanded n=3,4,6 and k=5,6. All combinations were cheap and were retained for comparison. Centers in dimensions n>=3 reuse trailing zero coordinates; this does not test independent motion in all coordinates. Tau remains kappa*(32n)^(-n), kappa in {1/2,3/2,5/2}. No high-tau/hardcore/K-prime, root-order, or exponential-budget inference is made.
