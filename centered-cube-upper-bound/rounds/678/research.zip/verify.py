from pathlib import Path
from fractions import Fraction as F
import ast,hashlib,json,re,math
p=Path(__file__).resolve().parent
for n in ['PRODUCT_CHECK.py','CAUSAL_CHECK.py','verify.py']:ast.parse((p/n).read_text())
P=json.loads((p/'PRODUCT_SUMMARY.json').read_text());C=json.loads((p/'CAUSAL_SUMMARY.json').read_text())
for stem,r in [('PRODUCT',P),('CAUSAL',C)]:
 assert r['all_checks_passed']
 assert r['script_sha256']==hashlib.sha256((p/(stem+'_CHECK.py')).read_bytes()).hexdigest()
 assert r['input_sha256']=='51133281e98e46889690d01d1a3a47a114c6dad79ec123cb9d3929f95e16d642'
assert len(P['records'])==120 and P['key_checks']==930
for r in P['records']:
 cs=list(map(F,r['weighted_codimension_contributions']));ss=list(map(F,r['codimension_shares']));v=F(r['full_weighted_volume'])
 assert len(cs)==r['n']+1 and sum(cs)==v==F(r['direct_weighted_volume'])
 assert sum(ss)==1 and all(x/v==y for x,y in zip(cs,ss))
 assert cs[0]/v==F(r['unexpanded_full_ratio'])
 assert sum(ss[(r['n']+1)//2:])==F(r['upper_half_codimension_share'])
assert len(C['records'])==60 and C['totals']['keys']==171 and C['totals']['causal_receiver_pairs']==1070
for r in C['records']:
 lhs=sum(F(t)**r['k']*F(v) for t,v in zip(r['strict_source_rates'],r['group_receiver_volumes']))/math.factorial(r['k'])
 assert lhs==F(r['lhs'])<=F(r['S_causal'])
 assert F(r['S0_causal'])<=F(r['V'])/math.factorial(r['k'])==F(r['V_over_k_factorial'])
 assert F(r['D'])==F(r['S_causal'])-F(r['S0_causal'])>=0
assert sum(F(r['D'])>0 for r in C['records'])==36
s=(p/'REPORT.tex').read_text();stack=[]
for m in re.finditer(re.escape(chr(92))+r'(begin|end)\{([^}]+)\}',s):
 if m[1]=='begin':stack.append(m[2])
 else:assert stack and stack.pop()==m[2]
assert not stack
review=(p/'S3_REVIEW.md').read_text()
for n in ['REPORT.tex','A1_PRODUCT_BUDGET.md','S2_FIBER_BUDGET.md','PRODUCT_CHECK.py','PRODUCT_SUMMARY.json','CAUSAL_CHECK.py','CAUSAL_SUMMARY.json']:
 assert hashlib.sha256((p/n).read_bytes()).hexdigest() in review,n
if (p/'MANIFEST.json').exists():
 for n,v in json.loads((p/'MANIFEST.json').read_text())['members'].items():
  b=(p/n).read_bytes();assert len(b)==v['bytes'] and hashlib.sha256(b).hexdigest()==v['sha256']
print(json.dumps(dict(passed=True,exact_aggregate_records=180,manifest_checked=(p/'MANIFEST.json').exists(),scope='exact recorded arithmetic and integrity; not general proof checker')))
