# R678 A1 — causal actual-receiver absorption and the full product boundary budget

## Result

The full global halo-key budget remains unproved. There is, however, a useful exact change of the payment object: restrict each core-first key to actual receivers in its own or later groups. The complete weighted cover survives, while strict source history and center admission give an unexpanded contribution at most V_rem/k!. This term is absorbable against the cover's T_min^k V_rem/k! lower bound. Thus this version no longer needs a separate exponentially improved unexpanded high-moment estimate.

The whole causal boundary contribution is still unpaid. Coordinate-product coarea is valid with the actual receiver indicator retained. Higher-order endpoint-tag elimination has not supplied a common physical point at which the original q-load can be applied jointly. The note below distinguishes these proved facts from that remaining global estimate.

## 1. Frozen R677 data and exact product volume

Use the audited R677 ordered groups and their strictly earlier common cores K'_a. The original anchor radii s_{r_a} are nonincreasing. Actual remaining receivers Y_a are disjoint unions of X_h, with all h in group a containing z_a in A_h. Put

    V=V_rem=sum_a |Y_a|,
    T_a=sum_{i in K'_a}q_i>T_min:=3tau/8-a_geom^(-n),
    a_geom=32n, c0=1+1/a_geom, c=c0^n,
    tau=16384 sqrt(n), k=ceil(128 sqrt(n)).

Every i in K'_a strictly precedes r_a and every target assigned to that group. All sources of a core contain z_a and have radius at least s_{r_a}. The complete original-family packing optimum P0 remains available; no q-support restriction is imposed on that optimum.

An eligible multiindex m has |m|=k and support contained in at least one K'_a. Retain repetitions, with

    w_m=q^m/m!,
    a(m)=min{a:support(m) subset K'_a},
    rho_m=s_{r_{a(m)}},
    I_m=intersection_{i in support(m)}A_i.

The intersection contains a positive-volume prefix-saturation cell, so it is a genuine box with positive widths ell_m,j. With Q the unit infinity-norm ball,

    |I_m+c0 rho_m Q|=product_{j=1}^n(ell_m,j+2c0 rho_m).       (1)

The radius is the original anchor radius, not the maximum radius left in the group after paid classifications. Core-first eligibility is not automatically spatial first hit. This note uses the strict-core history directly and does not import a spatial-first-hit claim.

For the full-space unexpanded sum one only has the inherited rough certificate

    sum_m w_m |I_m| <= integral g(x)^k dx/k!
                    <=tau^(k-1)U/k!,                       (2)

where g=sum_i q_i1_Ai. Relative to the desired U T_min^k/k!, (2) still has the exponential-in-k factor (tau/T_min)^k/tau. Paying only the full-space halo remainder would therefore not, by itself, finish that full-space route.

## 2. A causal actual-Y restriction absorbs the unexpanded term

Define the actual future receiver mask for each key by

    E_m=union_{b>=a(m)}Y_b,
    S_caus=sum_m w_m |(I_m+c0 rho_m Q) intersect E_m|,
    S_caus,0=sum_m w_m |I_m intersect E_m|.                  (3)

No receiver is replaced by a full halo or a rough envelope here. Since every key supported on K'_b has a(m)<=b, rho_m>=s_{r_b}, and z_b in I_m, each y in Y_b lies in the relevant key halo and in E_m. The multinomial identity proves

    S_caus >=sum_b |Y_b|T_b^k/k!
           >=T_min^k V/k!.                                 (4)

Now fix x in an actual X_h belonging to Y_b. Every key counted by S_caus,0 at x has a(m)<=b, and every source in that key satisfies

    i<r_{a(m)}<=r_b<=h.                                    (5)

The original source-center admission condition implies, throughout B_h,

    sum_{i<h}q_i1_Ai(x)<=1.                                (6)

Indeed s_i>=s_h in the original radius order, and x in B_h intersect A_i implies that y_h lies in the c0-expanded parent of i; the original expanded-center admission test bounds the sum. Strictly earlier cores are essential for the clean constant 1 in (6).

The eligible causal keys at x are a subset of all multiindices on this earlier prefix. Therefore

    sum_{m:a(m)<=b} w_m 1_{I_m}(x)
       <=(sum_{i<h}q_i1_Ai(x))^k/k! <=1/k!.

Integration over the disjoint actual X_h gives

    S_caus,0<=V/k!.                                        (7)

Set

    B_caus=sum_m w_m |[(I_m+c0 rho_m Q)\I_m] intersect E_m|.

Equations (3), (4), and (7) yield the proved complete-receiver account

    (T_min^k-1)V/k! <= B_caus.                              (8)

This is not an upper bound on B_caus. It does mean that an estimate

    B_caus <=C U T_min^k/k!                                 (9)

would pay V<=C U/(1-T_min^(-k)), with a uniformly harmless denominator in the actual regime. The analogous bound with tau P0 in place of U would also suffice for the unchanged global objective. Neither version of (9) is proved here.

The full-P-first spatial variant need not have the strict inequality i<h when its earliest anchor is the receiving target itself. It cannot inherit (7) with constant 1 without a self-source check. The present proof deliberately uses K' core-first keys and their strict history.

## 3. Whole-product coarea with the real receiver mask

For one key let

    Q_m(t)=|(I_m+c0 tQ) intersect E_m|,  0<=t<=rho_m.

This is absolutely continuous. The box parallel-volume coarea formula, retaining the actual measurable mask, gives

    Q_m(rho_m)-Q_m(0)
      =c0 integral_0^rho_m sum_{j=1}^n sum_{sigma=+,-}
           integral_{F_m,j,sigma(t)}1_{E_m}(x)
                   dH^(n-1)(x) dt,                        (10)

where F_m,j,sigma(t) is the corresponding face of I_m+c0tQ. Tangential edges have zero face measure; changes to receiver sets on null sets do not affect the integrated identity. Roughness of the owner or receiver pieces is permitted. Tonelli is legitimate because all summands are nonnegative and the eligible key family is finite.

Without the mask, (10) reduces to the exact non-enumerative product derivative

    |I_m+c0 rho_m Q|-|I_m|
      =2c0 integral_0^rho_m sum_j
             product_{l!=j}(ell_m,l+2c0t) dt.                (11)

Equations (10)–(11) avoid writing 2^n face terms, but they do not pay them. At an expanded face, the common original point is obtained by projection back to I_m and depends on the whole key. The original q-load at the displayed expanded point cannot count the other labels; replacing it by expanded-parent load would introduce an unproved spatial enlargement budget. The mask in (10) must also remain at its actual displaced point, rather than being moved to the projected point without justification.

The new task after (8) is precisely a joint upper bound for the masked whole-product trace integral in (10). It is not a separate high moment of the unexpanded full-space field.

## 4. Why at most k distinct endpoint tags has not yet paid all orders

The separately developed and independently reviewed first- and second-codimension trace estimates are valid global partial budgets. They are not reproved here and do not control the complete product. The obstruction to simply continuing their fixed-corner argument appears with three distinct endpoint tags.

For a mixed upper-face term, assign each normal coordinate to a source attaining the minimum upper endpoint. There are at most k distinct tags, even if many coordinates are present. Fix a smallest-radius tag j. When eliminating just one larger-radius tag i, one can choose a common point as follows: on normals owned by i, use the lower endpoint of j; on the other normals, use the upper endpoint of that coordinate's owner; retain the actual transverse coordinates. Positive intersection and radius order put this point in every candidate i. One-sided traces take care of endpoint ties. Thus a single fiber can be bounded by the original q-load tau while all the other tags are frozen.

The point depends on the other tags' endpoints. After summing out i, its own normal endpoints are no longer fixed. A subsequent tag need not contain either prescribed endpoint of j on those eliminated normal coordinates. Individual fiber bounds at moving points do not supply a joint bound tau^(number of tags-1). Thus replacing a 2^n face list by at most k tag blocks is not, on its own, an exp(O(k)) global budget.

A small exact cube fixture isolates this geometric issue. Let the smallest tag be

    J=[-1,1]^3,

and let the two larger cubes, both of side 4, be

    I=[-18/5,2/5] x [1/5,21/5] x [-2,2],
    K=[1/5,21/5] x [-18/5,2/5] x [-2,2].

Their positive intersection is

    [1/5,2/5] x [1/5,2/5] x [-1,1].

The upper endpoint owners in the three directions are I, K, and J respectively. No corner of J belongs to both I and K. The fiber point (-1,2/5,1) belongs to I, and (2/5,-1,1) belongs to K; each uses the other large tag's varying upper endpoint. This verifies the loss of a common fixed corner. It is only a test of this elimination argument, not an actual high-tau admitted-owner input or a counterexample to (9). The fixture does not rule out a different joint trace method.

## Verification and final checkpoint

A local Python standard-library Fraction calculation checked that the two large boxes above are cubes of side 4, computed their exact positive intersection with J, enumerated all eight corners of J and found none in both large tags, and verified the two moving fiber points. Its output was:

    exact three-tag cube intersection:
      [('1/5','2/5'),('1/5','2/5'),('-1','1')]
    common corners of smallest cube contained in both other tags: []
    two moving fiber points verified

This finite check supports only the stated fixed-corner diagnostic. The all-input statements (4)–(8) and the coarea formula are analytic proofs, not numerical extrapolations. No scalar optimization, historical scan, MATLAB session, child agent, Git operation, PDF, or modification of another agent's file was performed.

The actual new reduction is (8): the complete causal receiver kernel has an absorbable unexpanded contribution. The missing estimate is still the full masked offset trace budget (9), including all coordinates and all endpoint tags. It has not been proved, and no full V_rem or original P0 conclusion is claimed. Work stops here for integration and the next bounded global step.

## Closing addendum — full-first absorption with the self cost retained

The full-population spatial-first-hit version also admits the causal absorption, with an explicit self-source cost. Keep exactly the same core-eligible multiindex set. Define

    a_full(m)=min{a:support(m) subset P_a},
    rho_m^full=s_{r_{a_full(m)}},
    E_m^full=union_{b>=a_full(m)}Y_b,
    L=1+a_geom^(-n).

Because a_full(m)<=a(m), the full halo and future mask retain the complete weighted cover from (4). For x in an actual X_h belonging to group b, any full-causal key counted at x has

    i<=r_{a_full(m)}<=r_b<=h

for every label in its support. The earlier-prefix admission bound remains at most 1 throughout B_h. The only additional possible label is h itself, whose contribution is at most q_h<=a_geom^(-n). Consequently

    sum_{i<=h}q_i1_Ai(x)<=1+q_h<=L,
    S_full,caus,0<=L^k V/k!,
    S_full,caus>=T_min^k V/k!.

With the full-first boundary cost defined using its own halo and mask,

    D_full,caus=sum_m w_m
       |[(I_m+c0 rho_m^full Q)\I_m] intersect E_m^full|,

one obtains the proved inequality

    (T_min^k-L^k)V/k! <=D_full,caus.                        (12)

In the actual regime T_min>L, so this is a valid absorption. It simultaneously preserves spatial first hit and the actual future receivers; it does not require discarding the anchor self source from the full population.

The two boundary objects must not be identified. For the unchanged eligible key set, rho_m^full>=rho_m and E_m^full contains E_m, so B_caus<=D_full,caus termwise. A bound for the smaller core-first cost is not automatically an upper bound for the full-first cost. Equation (12) supplies no new upper bound for either one; their complete masked trace budgets remain unpaid. This addendum only closes the self-source check identified in Section 2, and does not restart the geometric exploration.
