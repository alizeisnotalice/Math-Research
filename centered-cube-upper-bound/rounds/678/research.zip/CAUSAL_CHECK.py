#!/usr/bin/env python3
"""Exact causal halo/receiver intersections on existing finite R677 geometry."""
from fractions import Fraction as F
from pathlib import Path
from itertools import combinations_with_replacement
from collections import Counter
from math import factorial,prod
import argparse,json,hashlib,sys,platform,time
BASE=Path(__file__).resolve().parent

def enc(x):
    if isinstance(x,F):return str(x)
    if isinstance(x,dict):return {str(k):enc(v) for k,v in x.items()}
    if isinstance(x,(tuple,list)):return [enc(v) for v in x]
    return x

def volume(box):return prod(max(F(0),hi-lo) for lo,hi in box)
def intersect(b1,b2):return [(max(lo1,lo2),min(hi1,hi2)) for (lo1,hi1),(lo2,hi2) in zip(b1,b2)]

def run(path):
    started=time.time();raw=path.read_bytes();src=json.loads(raw);records=[]
    for fixture in src['fixtures']:
        assert fixture['all_checks_passed'];n=fixture['n'];a=fixture['a'];c0=F(fixture['c0']);q=list(map(F,fixture['q']))
        A=[dict(y=list(map(F,C['y'])),s=F(C['s'])) for C in fixture['cubes']]
        X=[]
        for h,C in enumerate(A):
            box=[(y-C['s']/a,y+C['s']/a) for y in C['y']]
            box[0]=(F(fixture['receiver_strips'][h]['cut']),box[0][1])
            assert volume(box)==F(fixture['receiver_strips'][h]['X_volume'])
            X.append(box)
        for policy,R in fixture['policies'].items():
            groups=R['groups'];P=[set(G['positive_sources'])-{G['anchor']} for G in groups]
            Ts=[sum((q[i] for i in p),F(0)) for p in P]
            Yvol=[sum((volume(X[h]) for h in G['members']),F(0)) for G in groups]
            V=sum(Yvol,F(0))
            assert all(i<groups[b]['anchor'] for b,p in enumerate(P) for i in p)
            for k in (1,2,3):
                keys=set()
                for b,p in enumerate(P):
                    local=[]
                    for tup in combinations_with_replacement(sorted(p),k):
                        key=tuple(sorted(Counter(tup).items()));keys.add(key)
                        local.append(prod(q[i]**m for i,m in key)/prod(factorial(m) for i,m in key))
                    assert sum(local,F(0))==Ts[b]**k/factorial(k)
                lhs=sum((Ts[b]**k*Yvol[b]/factorial(k) for b in range(len(groups))),F(0))
                Scausal=F(0);Szero=F(0)
                count=dict(keys=len(keys),keys_with_nonzero_halo=0,keys_with_nonzero_unexpanded=0,causal_receiver_pairs=0,positive_halo_receiver_pairs=0,positive_unexpanded_receiver_pairs=0,nonempty_strict_P_groups=sum(bool(p) for p in P),empty_strict_P_groups=sum(not p for p in P))
                for key in sorted(keys):
                    supp={i for i,m in key};first=next(b for b,p in enumerate(P) if supp<=p)
                    rho=A[groups[first]['anchor']]['s'];coef=prod(q[i]**m for i,m in key)/prod(factorial(m) for i,m in key)
                    I=[(max(A[i]['y'][d]-A[i]['s'] for i in supp),min(A[i]['y'][d]+A[i]['s'] for i in supp)) for d in range(n)]
                    assert volume(I)>0
                    H=[(lo-c0*rho,hi+c0*rho) for lo,hi in I]
                    vH=F(0);vI=F(0)
                    for b in range(first,len(groups)):
                        for h in groups[b]['members']:
                            # All causal labels precede this receiver, so the original
                            # center-admission condition applies to the unexpanded term.
                            assert all(i<groups[b]['anchor']<=h for i in supp)
                            hvol=volume(intersect(H,X[h]));ivol=volume(intersect(I,X[h]));assert hvol>=ivol
                            vH+=hvol;vI+=ivol
                            count['causal_receiver_pairs']+=1
                            count['positive_halo_receiver_pairs']+=bool(hvol)
                            count['positive_unexpanded_receiver_pairs']+=bool(ivol)
                            if supp<=P[b]:assert hvol==volume(X[h])
                    count['keys_with_nonzero_halo']+=bool(vH);count['keys_with_nonzero_unexpanded']+=bool(vI)
                    Scausal+=coef*vH;Szero+=coef*vI
                count['keys_with_zero_halo']=count['keys']-count['keys_with_nonzero_halo']
                count['keys_with_zero_unexpanded']=count['keys']-count['keys_with_nonzero_unexpanded']
                count['zero_halo_receiver_pairs']=count['causal_receiver_pairs']-count['positive_halo_receiver_pairs']
                count['zero_unexpanded_receiver_pairs']=count['causal_receiver_pairs']-count['positive_unexpanded_receiver_pairs']
                bound=V/factorial(k);D=Scausal-Szero
                assert lhs<=Scausal and Szero<=bound and D>=0
                records.append(dict(fixture=fixture['name'],n=n,N=fixture['N'],policy=policy,k=k,original_tau=F(fixture['tau']),strict_source_sets=[sorted(p) for p in P],strict_source_rates=Ts,original_anchors=[G['anchor'] for G in groups],group_receiver_volumes=Yvol,V=V,lhs=sum((Ts[b]**k*Yvol[b]/factorial(k) for b in range(len(groups))),F(0)),S_causal=Scausal,S0_causal=Szero,V_over_k_factorial=bound,D=D,coverage_slack=Scausal-lhs,unexpanded_slack=bound-Szero,counts=count,all_checks_passed=True))
    totals=dict(records=len(records),nonzero_S_causal=sum(bool(r['S_causal']) for r in records),zero_S_causal=sum(not r['S_causal'] for r in records),nonzero_S0_causal=sum(bool(r['S0_causal']) for r in records),zero_S0_causal=sum(not r['S0_causal'] for r in records),nonzero_D=sum(bool(r['D']) for r in records),zero_D=sum(not r['D'] for r in records),max_strict_source_rate=max(t for r in records for t in r['strict_source_rates']),keys=sum(r['counts']['keys'] for r in records),causal_receiver_pairs=sum(r['counts']['causal_receiver_pairs'] for r in records))
    result=dict(title='R678 exact finite strict-source causal halo absorption ingredients',input_path=str(path.resolve()),input_sha256=hashlib.sha256(raw).hexdigest(),script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),python=sys.executable,python_version=sys.version,platform=platform.platform(),elapsed_seconds=time.time()-started,original_experiment_rerun=False,definitions=dict(strict_P='P_b minus {original anchor_b}; finite test only, not a hard K-prime',T_b='sum of qi on strict_P_b',Y_b='disjoint union of actual receiver strips X_h in original group b',V='sum of |Y_b| over all original loss groups',first_eligible='earliest original group with support(m) subset strict_P_b',Z_m='union actual X_h in all groups b >= first_eligible, without requiring their eligibility',I_m='intersection of source cubes in support(m)',H_m='I_m expanded in each coordinate by c0*original anchor radius of first eligible group',coefficient='product qi**mi / product mi!',S_causal='sum over deduplicated eligible multi-indices coefficient*|H_m intersect Z_m|',S0_causal='sum coefficient*|I_m intersect Z_m|'),checks=['sum_b T_b**k*|Y_b|/k! <= S_causal','S0_causal <= V/k!','D=S_causal-S0_causal >= 0','local multi-index sum = T_b**k/k!','each eligible group receiver box is fully contained in its first-eligible halo'],scope='All original R677 low-tau fixtures and both policies, degrees 1,2,3. Empty strict P gives zero. Actual rational strip intersections; no experiment rerun. No Tmin absorption test: all T<1. The analytic hard-core T>1 move-to-left argument is not empirically certified here. Trailing center coordinates remain reused at zero in dimensions >=3.',totals=totals,records=records,all_checks_passed=True)
    (BASE/'CAUSAL_SUMMARY.json').write_text(json.dumps(enc(result),indent=2)+'\n')
    print(json.dumps(enc(dict(all_checks_passed=True,totals=totals,script_sha256=result['script_sha256'],input_sha256=result['input_sha256']))))
if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input',type=Path,default=BASE/'WITNESS_RESULT.json')
    run(parser.parse_args().input)
