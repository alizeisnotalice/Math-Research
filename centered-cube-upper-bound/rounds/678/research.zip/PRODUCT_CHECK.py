#!/usr/bin/env python3
"""Exact finite low-tau halo product decomposition from existing R677 JSON only."""
from fractions import Fraction as F
from pathlib import Path
from itertools import combinations_with_replacement
from collections import Counter
from math import factorial,prod
import hashlib,json,sys,platform,time,argparse
BASE=Path(__file__).resolve().parent
DEFAULT_INPUT=BASE/'WITNESS_RESULT.json'
def enc(v):
    if isinstance(v,F):return str(v)
    if isinstance(v,dict):return {str(k):enc(x) for k,x in v.items()}
    if isinstance(v,(tuple,list)):return [enc(x) for x in v]
    return v

def elementary(lengths):
    e=[F(1)]+[F(0)]*len(lengths)
    for t,l in enumerate(lengths):
        for d in range(t+1,0,-1):e[d]+=l*e[d-1]
    return e

def run(input_path):
    INPUT=input_path.resolve()
    start=time.time();raw=INPUT.read_bytes();source=json.loads(raw);records=[];totalkeys=0
    for fixture in source['fixtures']:
        assert fixture['all_checks_passed']
        n=fixture['n'];c0=F(fixture['c0']);q=list(map(F,fixture['q']));tau=F(fixture['tau'])
        A=[dict(y=list(map(F,C['y'])),s=F(C['s'])) for C in fixture['cubes']]
        for policy,pr in fixture['policies'].items():
            groups=pr['groups'];Ps=[set(g['positive_sources']) for g in groups]
            for k in range(1,7):
                keys=set()
                for p in Ps:
                    assert sum((q[i] for i in p),F(0))==tau
                    for labels in combinations_with_replacement(sorted(p),k):keys.add(tuple(sorted(Counter(labels).items())))
                contributions=[F(0)]*(n+1);directsum=F(0);details=[]
                for key in sorted(keys):
                    support={i for i,m in key};first=next(b for b,p in enumerate(Ps) if support<=p)
                    r=groups[first]['anchor'];rho=A[r]['s'];t=2*c0*rho
                    lo=[max(A[i]['y'][d]-A[i]['s'] for i in support) for d in range(n)]
                    hi=[min(A[i]['y'][d]+A[i]['s'] for i in support) for d in range(n)]
                    lengths=[h-l for h,l in zip(hi,lo)];assert min(lengths)>0
                    e=elementary(lengths)
                    coeff=prod(q[i]**m for i,m in key)/prod(factorial(m) for i,m in key)
                    terms=[coeff*t**j*e[n-j] for j in range(n+1)]
                    direct=coeff*prod(l+t for l in lengths)
                    assert sum(terms,F(0))==direct
                    for j,v in enumerate(terms):contributions[j]+=v
                    directsum+=direct
                    details.append(dict(multi_index=key,support=sorted(support),first_eligible_group=first,original_anchor=r,rho=rho,coefficient=coeff,intersection_lengths=lengths,elementary_symmetric=e,expansion_width=t,weighted_codimension_contributions=terms,weighted_direct_volume=direct,identity_passed=True))
                full=sum(contributions,F(0));assert full==directsum and full>0
                shares=[v/full for v in contributions]
                # Stages mark requested views, not extra experiments.
                stages=[]
                if n in (1,2) and k in (1,2):stages.append('initial_n1_n2_k1_k2')
                if 'multiscale' in fixture['name'] and k in (3,4):stages.append('stress_multiscale_k3_k4')
                if n in (3,4,6) and k in (5,6):stages.append('expanded_n3_n4_n6_k5_k6')
                records.append(dict(fixture=fixture['name'],n=n,N=fixture['N'],k=k,policy=policy,stages=stages,original_tau=tau,key_count=len(keys),weighted_codimension_contributions=contributions,codimension_shares=shares,full_weighted_volume=full,direct_weighted_volume=directsum,unexpanded_weighted_volume=contributions[0],unexpanded_full_ratio=shares[0],top_codimension_share=shares[n],upper_half_codimension_share=sum(shares[(n+1)//2:],F(0)),details=details,all_checks_passed=True))
                totalkeys+=len(keys)
    def extremes(field):
        low=min(records,key=lambda r:r[field]);high=max(records,key=lambda r:r[field])
        def brief(r):return dict(fixture=r['fixture'],n=r['n'],k=r['k'],policy=r['policy'],value=r[field],decimal=float(r[field]))
        return dict(min=brief(low),max=brief(high))
    summaries={field:extremes(field) for field in ('unexpanded_full_ratio','top_codimension_share','upper_half_codimension_share')}
    obj=dict(title='R678 exact codimension product contributions for finite first-eligible full-P keys',input=str(INPUT),input_sha256=hashlib.sha256(raw).hexdigest(),script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),python=sys.executable,python_version=sys.version,platform=platform.platform(),elapsed_seconds=time.time()-start,original_experiment_rerun=False,all_checks_passed=True,record_count=len(records),key_checks=totalkeys,formula='For each deduplicated multi-index m: coeff=product(q_i**m_i)/product(m_i!); earliest full-P eligible original group selects rho. Sum_j coeff*(2*c0*rho)**j*e_(n-j)(intersection side lengths) equals coeff*product(length+2*c0*rho).',unexpanded_definition='j=0 weighted intersection volume divided by full weighted expanded intersection volume.',summaries=summaries,records=records,scope='Existing true geometric low-tau fixtures only, k=1..6, n=1,2,3,4,6. Last coordinates reused at zero in n>=3. Full P from original loss groups; no K-prime/hardcore claim. No high-tau or root-order conclusion, no exponential-budget test.')
    (BASE/'PRODUCT_RESULT.json').write_text(json.dumps(enc(obj),indent=2)+'\n')
    full_hash=hashlib.sha256((BASE/'PRODUCT_RESULT.json').read_bytes()).hexdigest()
    stage_stats={}
    for stage in ('initial_n1_n2_k1_k2','stress_multiscale_k3_k4','expanded_n3_n4_n6_k5_k6'):
        subset=[R for R in records if stage in R['stages']]
        stage_stats[stage]=dict(record_count=len(subset),key_checks=sum(R['key_count'] for R in subset),dimensions=sorted({R['n'] for R in subset}),degrees=sorted({R['k'] for R in subset}),unexpanded_full_ratio_range=[min(R['unexpanded_full_ratio'] for R in subset),max(R['unexpanded_full_ratio'] for R in subset)],upper_half_codimension_share_range=[min(R['upper_half_codimension_share'] for R in subset),max(R['upper_half_codimension_share'] for R in subset)])
    summary={key:value for key,value in obj.items() if key!='records'}
    summary.update(full_result_sha256=full_hash,full_result_filename='PRODUCT_RESULT.json',detail_policy='Each record retains exact contribution vectors, shares, volumes and keys count; per-key details omitted. Full result remains local.',stage_statistics=stage_stats,records=[{key:value for key,value in R.items() if key!='details'} for R in records])
    (BASE/'PRODUCT_SUMMARY.json').write_text(json.dumps(enc(summary),indent=2)+'\n')
    lines=['# R678 exact finite halo-product decomposition','',f"Executed with `{sys.executable}`, Python {platform.python_version()}. Input SHA256 `{obj['input_sha256']}`; script SHA256 `{obj['script_sha256']}`.",'',f"All {len(records)} fixture/policy/degree records and {totalkeys} deduplicated key product identities passed using Fraction arithmetic. The existing 10 R677 fixtures were read without rerunning geometry. Both policies and k=1,...,6 are included. Full source labels, multiplicities, earliest eligible group, original anchor radius, intersection lengths and each codimension term are saved.",'','For each key, write t=2*c0*rho and intersection side lengths ell. The exact weighted j-term is (q^m/m!)*t^j*e_(n-j)(ell). Its sum over j agrees exactly with direct weighted product volume. Aggregate shares are formed after summing over distinct multi-index keys within one fixture/policy/k; no independent tuple double counting.','', '| Quantity | Minimum | Maximum |','|---|---:|---:|']
    for field,S in summaries.items():lines.append(f"| {field} | {S['min']['decimal']:.12g} | {S['max']['decimal']:.12g} |")
    lines+=['','High codimension terms cannot be discarded in these finite examples: the table reports their actual aggregate shares. This is finite structural evidence, not an asymptotic estimate. Unexpanded/full means the j=0 contribution divided by all j contributions. “Upper half” means j>=ceil(n/2), including j=n.','', f'PRODUCT_SUMMARY.json contains all 120 aggregate records and three-stage statistics without per-key details; it binds the full local result by SHA256 `{full_hash}`. Input is not duplicated: retrieve WITNESS_RESULT.json from the R677 research archive, verify the input hash above, and place it adjacent to this script or pass --input /path/to/WITNESS_RESULT.json.','', 'Requested stage views are explicitly marked in JSON: initial n=1,2 and k=1,2; multiscale stress k=3,4; expanded n=3,4,6 and k=5,6. All combinations were cheap and were retained for comparison. Centers in dimensions n>=3 reuse trailing zero coordinates; this does not test independent motion in all coordinates. Tau remains kappa*(32n)^(-n), kappa in {1/2,3/2,5/2}. No high-tau/hardcore/K-prime, root-order, or exponential-budget inference is made.','']
    (BASE/'NUMERIC.md').write_text('\n'.join(lines))
    print(json.dumps(enc(dict(all_checks_passed=True,records=len(records),key_checks=totalkeys,summaries=summaries,script_sha256=obj['script_sha256'],input_sha256=obj['input_sha256']))))
if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input',type=Path,default=DEFAULT_INPUT,help='Existing R677 WITNESS_RESULT.json; default adjacent to this script.')
    run(parser.parse_args().input)
