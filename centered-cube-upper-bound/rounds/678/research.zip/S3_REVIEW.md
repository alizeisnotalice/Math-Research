# R678 S3 independent pre-review

Status: FINAL PASS within the bounded scope recorded below; no mandatory mathematical correction found in the finalized REPORT and two author notes. The initial geometric/Fubini checks preceded reading R678 author drafts, and later trace/causal proposals were independently checked before their author treatments. No complete weak global budget or root-order bound is certified.

## 1. Current target and retained finite quantifiers

Retain the entire R677 original finite input, static radius-order q recursion, genuine disjoint owners, actual receivers, freshly reclassified residual groups, original anchors, cores and key definitions. The target under review is now only

    S_core <= C U T_min^k/k!,

or the broader sufficient inequality

    S_core <= C tau P0 T_min^k/k!.

Either would pay the actual new residual by the exact R677 weighted cover. The old stronger tau^k exp(-2k) scale is NOT required. If the residual is empty its volume is already zero; T_min is only needed for the nonempty residual/core family.

Every selected group index and halo parameter must keep its dependence on the ENTIRE multi-index. The original anchor radius is nonincreasing; the maximum remaining target radius need not be. Core-first and full-P spatial-first kernels are different costs. The larger full-P-first halo cost may be used as a sufficient upper bound for the core cost, but its first-hit geometry cannot be attached to the smaller core kernel for free.

## 2. Exact box identity and legal Tonelli decomposition

For an eligible key m, write I_m=product_j [L_j,U_j] with side lengths ell_j=U_j-L_j and t_m=c0 s_{r_a(m)}. Eligibility gives a nonempty intersection; in the R677 positive-cell construction it even has positive side lengths. The identity remains valid for degenerate nonempty boxes:

    |I_m+t_m Q|=product_j(ell_j+2t_m)
       =sum_{J subset [n]} (2t_m)^|J| product_{j notin J}ell_j.

There is no approximation or sparsity assertion in this formula. J empty is the unexpanded volume. J=[n] is the full-codimension term (2t_m)^n; it must not disappear in a Fubini argument. The zero-dimensional projection has measure one by the usual convention.

With pi_{Jc} denoting the retained coordinates, each term is exactly

    integral_{pi_{Jc} I_m} (2t_m)^|J| dz.

The sum over all keys and all J is finite and nonnegative. It can be interchanged with the corresponding Lebesgue integrals by Tonelli. Since the parents are axis-parallel boxes and the eligible intersection is nonempty,

    pi_{Jc} I_m = intersection_{i in support(m)} pi_{Jc} A_i.

This is a valid geometric identity; it does not transfer the full-dimensional capacity to those projections. A proposed proof must control the combined contribution of all coordinate subsets, including its dimension dependence, not silently count a uniform per-subset price 2^n times.

## 3. What a real fixed fiber inherits

Fix retained coordinates z and write u for the other coordinates. Fubini legitimately gives, for almost every z,

    g_z(u)=sum_i q_i 1_Ai(z,u) <= tau for almost every u.

The actual owner fibers F_i(z) are likewise disjoint for almost every z, and their measures integrate back to |F_i|. Any already proved whole-B_h low-load inequality restricts to its true fibers. The original radius-order center-admission argument also gives earlier-source low load throughout the actual small owner box, hence throughout its genuine slices.

These are statements about actual slices with the ORIGINAL q_i. They do not say that q_i equals the slice-owner measure divided by a lower-dimensional parent volume. Generally the conditional owner measures vary with z and may vanish on a fiber where the parent is present. Replacing them by fictitious full-parent fractions would change the true source mass account. Applying a lower-dimensional admission/saturation theorem or R673 would require its full sliced hypotheses, normalization, genuine owner rates and history to be proved separately.

The a.e. qualifier must be retained. Restricting an a.e. full-dimensional load bound to an arbitrary exceptional trace is not valid. A prescribed face-free fiber can sometimes be justified by the finite-arrangement structure, but that requires the actual face-free condition in its retained coordinates; Fubini alone does not supply it.

## 4. Projection and first-hit bridges which are not inherited

The projected field

    g_proj(z)=sum_i q_i 1_{pi A_i}(z)

is a sum of per-parent fiber suprema. The original bound controls the supremum of their sum at a common fiber point. Exchanging those operations is invalid. Many parents can have the same projection while occupying separated dropped-coordinate positions. Thus g<=tau does not imply g_proj<=tau. The center-admission test does not automatically repair this operator mismatch. Such an observation is not an actual hard-near counterexample to the global target.

For a single fixed core, its total rate is bounded by tau; that special pool cap cannot be replaced by an unrestricted union of projected pools without paying source reuse. All-family sum_i q_i is not bounded by tau.

Even genuine full-P spatial first hit asserts only that each earlier selected witness is outside I_m. Its projection can lie inside pi I_m, with the failed containment occurring solely in a dropped coordinate. Projected first-hit exclusion therefore requires a new statement. Earlier selected witnesses also need not lie in a common fixed fiber, so the original ordered list does not directly become an admissible sliced stopping process. Core-first has the additional cutoff/self-exclusion issue already identified in R677.

## 5. Thin intersections and selected halo costs

A small ell_j says that an intersection is thin in that coordinate. It neither bounds the source q-rate at its genuine common witness nor certifies few parents, low projected q-load or sparse source ownership. In particular the factor (ell_j+2t_m)/ell_j can diverge as ell_j tends to zero while t_m stays positive. Positive-volume arrangement cells have no uniform minimum width in the supplied contract.

The exact box expansion can also be viewed as a per-key collar decomposition or clamping transport. Those operations depend on I_m and t_m, hence on the entire selected key. They do not give one source-independent map with controlled global multiplicity/Jacobian. A source-owner integral still needs an actual kernel bound; thin volume is not a replacement for it.

The side lengths, eligible-group selection, anchor radius and every source mark are correlated functions of the full key. A proof cannot pull their selection weight out of a multinomial sum, treat the remaining labels as iid from one fixed core, or sum independent local source prices without proving the corresponding conditional/geometric estimate.

## 6. The elementary unexpanded price and the new weaker goal

The original load gives exactly the inherited upper certificate

    S_unexpanded <= integral g^k/k! <= tau^(k-1)U/k!.

This is valid but alone does not establish the present C U T_min^k/k! scale with C absolute. The available lower bound T_min approximately (3/8)tau does not make the quotient tau^(k-1)/T_min^k uniform in dimension. This is a limitation of that certificate, not a lower bound on the actual selected sum.

The exact source-marking identity remains

    S_core=(1/k)sum_i |F_i| Gamma_i.

Accordingly an owner-weighted mean bound of order T_min^k/(k-1)! would suffice for the U target; a uniform sourcewise Gamma_i bound is stronger than necessary. The broader tau P0 target may use a jointly feasible original-family packing. Neither formulation is supplied merely by a projection identity or a generic fixed-fiber cap.

## Preliminary disposition

Legal bridges: exact product/coordinate expansion; finite nonnegative Tonelli; actual a.e. sliced load and owner integrals; restrictions of already proved whole-box admission bounds; and the unchanged exact weighted-cover/source-marking identities.

Missing bridges: controlled projected or trace capacity; a genuine sliced owner normalization/history; preservation of first-hit geometry after projection; and a simultaneous selected-halo/source budget with all subset/multiplicity factors retained. These are proof obligations, not impossibility assertions. No R678 author text has been read at this stage. Only this S3 file is written; no subagent, Git/PDF action or numerical rerun is performed.

## 7. Saved product-check algorithm and finite metadata

After the independent mathematical pre-review, read PRODUCT_CHECK.py's complete algorithm, NUMERIC.md, and the PRODUCT_SUMMARY.json header, extrema and stage metadata. The large aggregate JSON output was not manually checked record by record. No script was executed or numerical experiment rerun.

The algorithm reads the saved R677 geometric fixtures, enumerates unordered source multisets with repetitions, deduplicates complete multi-indices within each fixture/policy/degree, selects earliest eligibility in the ORIGINAL full-P groups, and uses the original anchor radius. It retains the exact q^m/m! coefficient. Its elementary-symmetric recursion updates in reverse order and therefore includes all coordinate subsets of each codimension.

There is a notation distinction: the script's t=2c0 rho is the added SIDE WIDTH; the mathematical pre-review above uses t=c0 rho as the halo RADIUS. The script correctly checks

    sum_j coeff*(2c0rho)^j*e_(n-j)(ell)
       = coeff*product_j(ell_j+2c0rho).

The j=0 term is unexpanded volume, j=n is the full-codimension term, and upper-half share uses j>=ceil(n/2). Aggregate shares are formed after summing the exact weighted contributions in a single fixture/policy/degree record. Float conversions occur only in displayed decimal summaries; the stored contributions and ratios are rational.

Metadata records 120 combinations from ten fixtures, two policies and six degrees, and 930 product identities after deduplication WITHIN each record. This does not mean 930 globally unique physical keys across all policies. The three stage labels are requested subset views of the saved computation, not independent additional experiments.

The declared input is the already saved R677 WITNESS_RESULT.json, with hash 51133281e98e46889690d01d1a3a47a114c6dad79ec123cb9d3929f95e16d642. The recorded script hash is 72123da4e4a22aff73c601f6182a1ea7940b9792808ffb87eed3e4eeb5ac7d8b. The actual final artifact hashes are bound below.

These are full-P, low-threshold, degrees 1 through 6 checks in dimensions 1,2,3,4,6, with reused trailing coordinates. The finite high-codimension shares show those terms are substantial in the tested weighted sums; they are not asymptotic lower bounds or actual hard-near examples. The experiment does not verify the n>=256 hard-core construction, a projected-capacity theorem, the new weak global owner budget, or a root-order estimate. Its scope and the NUMERIC explanation are consistent with the inspected algorithm.

## 8. Independently checked one- and two-normal true trace fees

The following proposed estimates were checked before reading their author proof. Write C_l for the total weighted product term with normal coordinate l, and C_lh for a fixed distinct coordinate pair. Assume k>=1 for the first, k>=2 for the second. Each eligible key is tagged in a normal by a deterministic unique source attaining the minimum upper endpoint of its intersection in that normal. Ties must be resolved once. A positive eligible intersection supplies the corresponding strict lower-endpoint inequalities.

The correct capacity at such a face is the COMMON INSIDE one-sided trace, not an unrestricted closed-boundary q field. For example, sources counted at an upper face satisfy lower<p<=upper, so all remain present just below that face. Finiteness and the original a.e. cap imply this one-sided trace is <=tau for almost every retained coordinate. The same argument applies to any fixed common sign cone at a corner.

Single normal: extract one occurrence of the endpoint tag i, using q^m/m! <=q_i q^(m-e_i)/(m-e_i)!. Drop eligibility/selection restrictions only in the resulting nonnegative upper bound. The remaining k-1 labels are counted by the genuine inward trace polynomial at the FIXED tagged endpoint. Using rho_m<=s_i and integrating the other coordinates over the tag face gives

    C_l <= c0 tau^(k-1) U/(k-1)!.

The factor 2s_i times its (n-1)-face volume is exactly d_i. No first-hit or admission hypothesis beyond the true global cap is needed for this fee.

Two normals, same tag: the fixed upper-upper corner and the same inward trace give c0^2 tau^(k-1)U/(k-1)!.

Two normals, distinct tags: order their ORIGINAL indices i<j, so s_i>=s_j. There are two choices of which normal is supplied by i. At the original joint upper endpoint, the remaining k-2 labels have true inward trace <=tau. For the orientation where i supplies l and j supplies h, intersection positivity and s_i>=s_j imply that A_i contains the FIXED mixed corner of A_j with coordinate lower_j in l and upper_j in h. It contains that corner from the same (+l,-h) inward cone. The remaining-coordinate projection indicator of A_i can therefore be charged to an actual mixed-corner trace at A_j, whose summed i-rate is <=tau a.e. Using rho_m<=s_j gives, per orientation,

    c0^2 tau^(k-1) U/(k-2)!.

Thus the proposed total bound is valid:

    C_lh <= c0^2 tau^(k-1)U
                    [1/(k-1)!+2/(k-2)!].

These arguments use true full-coordinate face/corner traces with a common inward side; they do not assume projected q-load <=tau. The coefficient extraction is an upper bound with possible overcounting, which is harmless in this direction.

Neither fee controls all codimensions or has yet been shown to fit the total weak target after summation. A naive extension to three or more normals lacks a geometric step: for a third normal supplied by another tag, a larger parent is known to contain the original joint endpoint, but need not contain the same fixed corner of the smallest tag. Which end of that smaller interval is contained can depend on the parent. The two-normal argument does not prove a common corner for all these tags. Additional orientation/normal costs and their total cannot be omitted.

## 9. Causal actual-receiver restriction and genuine absorption

Independently checked the new proposal before reading its author treatment. Keep CORE-first selection a(m), its original-anchor halo H_m, and the actual NEW residual partition Y_b. Set

    Z_m=union_{b>=a(m)}Y_b,
    S_causal=sum_m w_m |H_m intersect Z_m|,
    S0_causal=sum_m w_m |I_m intersect Z_m|,
    D_causal=sum_m w_m |(H_m minus I_m) intersect Z_m|.

For x in Y_b, every key supported in K'_b still has a(m)<=b, so x belongs to H_m intersect Z_m. The exact weighted-cover lower bound therefore survives:

    T_*^k V/k! <= S_causal.

For a key counted at x in X_h subset Y_b, each source label satisfies i<r_a(m)<=r_b<=h. Original radius order and center admission give the genuine earlier-source field <=1 throughout B_h. Dropping the remaining nonnegative eligibility/causality restrictions in the UNEXPANDED kernel yields

    sum_{m:a(m)<=b}w_m 1_I_m(x)
       <=(sum_{i<h}q_i 1_Ai(x))^k/k! <=1/k!.

All Z_m lie in the SAME actual residual receiver Y. Integration therefore gives S0_causal<=V/k!, not a bound on a full-space sum. Since H_m contains I_m, the measurable partition S_causal=S0_causal+D_causal is exact. Consequently

    (T_*^k-1)V/k! <= D_causal.

The stipulated hard-regime T_*>1 permits true absorption. This retains the complete same Y objective and does not reclassify or discard demand. The strict source priority relies on K' with its self deletion; it should not be replaced by full-P-first while silently keeping the same earlier-field bound.

This is a valid new causal reduction, not a paid bound for D_causal. The product formula gives the full-space |H_m| exactly; after intersection with the arbitrary actual union Z_m, it is only an upper certificate unless a real collar/fiber partition retains 1_Z_m. No full-P spatial-first property or old Poisson law is used. The shell's actual-receiver/owner transport cost remains to be proved.

## 10. Full-P spatial-first causal absorption with the self allowance

Independently checked the later full-first repair before reading its author treatment. Keep the SAME core-eligible key set, choose a_full(m) as the earliest original group with support(m) subset P_a (including paid groups), use its original anchor radius in H_full,m, and let Z_full,m be the actual residual union over b>=a_full(m).

For a counted receiver x in X_h subset Y_b, every source label satisfies

    i <= r_a_full(m) <= r_b <= h.

There can be at most the single original self label h outside the strict earlier-source field; its multiplicity in a key is handled by the multinomial formula. Original admission and q_h<=a^(-n) give, throughout B_h,

    g_<=h(x) <=1+q_h <=L=1+a^(-n).

Therefore the exact same nonnegative-sum enlargement yields

    S0_full,causal <= L^k V/k!.

All keys supported in K'_b still have a_full(m)<=b, and their full-first original anchor radii dominate the actual target radii. Thus the full weighted-cover lower bound survives on the SAME actual Y. With the genuine full-first shell cost D_full,causal,

    (T_*^k-L^k)V/k! <= D_full,causal.

In the stipulated hard regime T_*>2L, hence T_*^k-L^k >=(1-2^(-k))T_*^k >=T_*^k/2. The absorption is uniform. The larger full-first kernel CAN be absorbed while retaining the actual spatial-first-hit property; only the core proof's constant-one earlier-field bound fails to transfer unchanged. This is the precise self correction.

The full-first halo and causal union are at least as large as their core-first counterparts. Accordingly this is a larger unpaid shell budget with better first-hit geometry, not a proof that the shell is paid. No global owner estimate for D_full,causal follows from this repair alone.


## 11. Final author/report comparison

Read A1_PRODUCT_BUDGET.md and S2_FIBER_BUDGET.md in full, including A1's completed full-first self addendum. Read REPORT.tex's full chain and its final A-full update. Their product identities, coarea/fiber quantifiers, first two true trace estimates, causal same-Y absorption, full-first self allowance and stated unproved shell budget agree with the independent deductions above. No mandatory mathematical correction was found.

A1's masked parallel-volume coarea identity is valid for arbitrary measurable actual receiver masks: the expanding-box volume is absolutely continuous, the boundary faces move with speed c0, and the mask remains at the actual face location. Its integrated value is insensitive to null-set representative changes. This is also consistent with the direct coordinate collar parametrization in S2. No projection of the mask to an original face is made for free.

The three-tag cube diagnostic in A1 has the stated positive intersection [1/5,2/5] times [1/5,2/5] times [-1,1]. Its two larger boxes have side four, none of the smallest cube's eight corners belongs to both, and the two listed moving fiber points belong to their respective larger cubes. These facts follow directly from the listed rational endpoints. This is a diagnostic for the fixed-corner elimination argument, not an admitted hard-near owner/receiver example or a counterexample to the global budget. No diagnostic computation was rerun by this reviewer.

S2 retains all coefficient costs: dimension-summing its first two orders gives the k and k(2k-1) factorial factors displayed in REPORT. Its all-normals/same-tag subseries bound also retains the exponential marking envelope (1+c0)^n-1. It correctly calls these upper certificates rather than realized lower bounds or impossibility arguments. The full multi-tag/offset bridge remains open.

The exact actual-receiver collar parameterization is valid with unit Jacobian, nonempty outside-coordinate sets and all sign patterns. Boundary overlaps are null. The stronger load-one constraint holds at the actual receiving point; the tau face trace may be at a different point. The papers do not silently identify those constraints. The larger full-first halo, future mask and collar cannot be interchanged with the smaller core-first cost for free.

## 12. Final causal-script and metadata boundary

Read the complete CAUSAL_CHECK.py algorithm and compact CAUSAL_SUMMARY.json metadata without executing the experiment. It reconstructs actual rational receiver strips from the saved R677 input; uses strict P_b minus the original anchor, rather than claiming a hard K'; deduplicates full multi-indices for degrees 1,2,3; computes real I/H intersections with every actual receiver in the causal future; and checks weighted coverage, S0_causal<=V/k!, and nonnegative collar difference. Empty strict populations contribute zero.

The metadata records 60 records, 171 keys, 1070 causal receiver pairs, 36 positive collars, 24 zero collars, and maximum strict population rate 1/64. This matches REPORT's declared interpretation. These low rates do NOT empirically demonstrate a positive absorption coefficient. The hard-regime T_*>1 proof and the full-first L correction are ANALYTIC audits; the finite causal experiment uses strict populations and does not cover the full-first self variant.

The PRODUCT and CAUSAL source hashes below match their summary metadata; both summaries reference the same saved R677 input hash. The large JSON records and reproducible per-key outputs were not checked item by item by this reviewer. Scope/metadata and source-algorithm inspection is certified, not a numerical rerun or a complete manual data audit. Historical R677 tools and admission assumptions remain accepted as supplied.

## Final disposition and artifact binding

FINAL PASS covers the exact full box/coarea/fiber representations; limits on projection and conditional owner normalization; one- and two-normal true trace budgets with factorial/dimension factors; core-first actual-Y absorption; full-first spatial-hit absorption with its self allowance; higher-order gap identification; and bounded author/report/source/metadata consistency.

The unpaid object is still the COMPLETE actual-receiver offset collar, core-first or its larger full-first variant. No complete S_core bound, source-reuse settlement, all-order mixed trace estimate, general root bound, hard-near counterexample or impossibility theorem is certified.

Final SHA-256 values under /Volumes/data/CodexTemp/centered-cube-r678-20261115:

- REPORT.tex: 4824553fb75353180f92c712f50dd93d089868a3cb245f33d8bdd59e0412b5f8
- A1_PRODUCT_BUDGET.md: b807515119b08152a89b13c1bed037cee3a12a4ca74fbff906cf4f3aad3c83b4
- S2_FIBER_BUDGET.md: 3cddf2848a39b895e91510289d763e406bc03bfa61ebc16cb7366f2ba8950144
- PRODUCT_CHECK.py: 72123da4e4a22aff73c601f6182a1ea7940b9792808ffb87eed3e4eeb5ac7d8b
- PRODUCT_SUMMARY.json: 6f2c21316ce16365b66e56e397c6888dc5a2c30b412874f7051d93989443e4fe
- CAUSAL_CHECK.py: e32b482c27a2ad05875586c4098c0363bc9f743ca38558cf1bcb4681148c37a5
- CAUSAL_SUMMARY.json: 91a2483ee382ee8a21226544460e857820d3ee2dc69aa5109e09effd65dad944

The prior input remains in the R677 archive, referenced by SHA-256 51133281e98e46889690d01d1a3a47a114c6dad79ec123cb9d3929f95e16d642; it is not duplicated here. Hashes bind artifacts, not mathematical truth. Only this S3 review file was written by this reviewer; no subagent, Git/PDF action or numerical rerun was performed. Bounded task complete; stop.
