# R678 S2 — exact fiber decomposition and globally paid first two mixed orders

**Proved source budgets.** For the R677 first-eligible-core key sum, let C_J be its unclipped mixed-face term on coordinate set J. The original all-space q capacity gives

    sum_{|J|=1}C_J <=n c0 tau^(k-1)U/(k-1)!,

    sum_{|J|=2}C_J
      <=binom(n,2)c0^2 tau^(k-1)U
           [1/(k-1)!+2/(k-2)!].                             (1)

The second formula is for k>=2, as in the intended k=ceil(128sqrt(n)) regime. The distinct-tag part is paid by a TRUE fixed corner trace of the smaller-radius source. It does not drop normal-coordinate constraints into a projected q-load.

These are complete GLOBAL budgets for these two orders, not a proof of the entire key sum or of a complete packing. The constants, binomial coordinate factors and factorial marking costs are retained. Higher simultaneous endpoint traces and the gain needed to reach T_min^k remain unpaid.

The parent/Astra causal-mask improvement directs the relevant next task to the offset actual-receiver boundary integral below. The full-space bounds (1) remain valid upper bounds for its positive clipped terms, but cannot substitute for a payment of the whole causal boundary.

No current-round Astra manuscript was read. Only this assigned file is written; no child, Git, PDF or new numerical scan is introduced. The independent reviewer and main agent report that they have checked the codimension-one and codimension-two claims.

## 1. Exact key and product geometry

Use precisely the original R677 parents, owners and first-core eligibility. For an eligible multiplicity vector m, |m|=k, write

    w_m=product_i q_i^(m_i)/m_i!,
    a(m)=earliest core K'_a containing support(m),
    rho_m=s_{r_{a(m)}}.

The radius is the ORIGINAL anchor radius. It is at most every source radius in this key. It is not the possibly nonmonotone maximum remaining target radius.

Put

    I_m=intersection_{i:m_i>0}A_i
       =product_{l=1}^n[L_l(m),U_l(m)],
    ell_l(m)=U_l(m)-L_l(m)>0.

Positivity follows because the key contains an eligible core's shared witness, chosen off every original parent face. Therefore

    |I_m+c0rho_m Q|
      =product_l(ell_l+2c0rho_m)
      =sum_{J subset [n]}(2c0rho_m)^|J|
                       |projection_{J complement}I_m|.      (2)

No dimension or multiplicity factor is suppressed. Define C_J to be the sum of the corresponding nonnegative term in (2), weighted by w_m. Then S_core=sum_J C_J.

The empty-coordinate term obeys the standard direct capacity bound

    C_empty<=tau^(k-1)U/k!,

because it is bounded by integral g^k/k!, with g=sum_iq_i1_{A_i}<=tau. This is only context, not the new joint estimate.

## 2. One-normal trace: proof of the first bound

Fix coordinate l. Assign the upper endpoint U_l(m) to one source i in the key attaining it; ties use a fixed label rule. Since m_i>=1,

    w_m<=q_i q^(m-e_i)/(m-e_i)!.

For transverse y in projection I_m, every remaining key label contains the point (U_l(m),y) in its inward one-sided trace. There is a genuine positive-length intersection below that endpoint. The original q-load in this trace is at most tau for almost every transverse y.

This use of a face trace is legitimate despite null faces: for the finite parent family the inward normal limit is constant for sufficiently small displacement away from finitely many transverse faces. Its value is a limit of full-dimensional q-loads bounded by tau. We do not sum the potentially larger two-sided closed-boundary values.

Fixing i pins the endpoint to y_i,l+s_i. Dropping the eligibility/first-group restrictions only enlarges the remaining-label sum, which is bounded by tau^(k-1)/(k-1)!. Also rho_m<=s_i and projection I_m is contained in projection A_i. Thus

    C_{ {l} }
      <=sum_i q_i(2c0s_i)(2s_i)^(n-1)
                      tau^(k-1)/(k-1)!
      =c0 tau^(k-1)U/(k-1)!.                               (3)

The scalar factor 2c0rho in (2) already includes both exterior normal slabs. Charging this unclipped scalar term through an upper endpoint does not discard the lower slab. For a clipped geometric interpretation the two signs can instead be handled separately and give the same total.

Summing all n coordinates proves the first line of (1).

## 3. Two-normal trace: same supporting source

Fix coordinates l1,l2. If the two upper endpoints are assigned to the SAME source i, mark that source once. The other k-1 labels contain the true full corner

    (y_i,l1+s_i, y_i,l2+s_i, transverse y)

in its inward trace. Their total factorial sum is at most tau^(k-1)/(k-1)!. The normal-area weight satisfies (2c0rho_m)^2<=(2c0s_i)^2. Integration over the remaining projection of A_i therefore gives

    C_same
      <=c0^2 tau^(k-1)U/(k-1)!.                            (4)

One mark is used here, not q_i^2. This includes keys with only one distinct source and correctly retains repeated labels.

## 4. Two-normal trace: different supporting sources

Consider the direction in which source i supplies the l1 upper endpoint and source j supplies the l2 upper endpoint, with i<j in the original order and therefore s_i>=s_j. The reversed assignment will be paid separately.

At a true mixed key corner, normal cross-containment gives

    lower_j,l1 < upper_i,l1 <= upper_j,l1,
    lower_i,l2 < upper_j,l2 <= upper_i,l2.                   (5)

The positive key interior excludes the zero-intersection endpoint cases. Because the i interval has length at least the j interval, (5) implies

    lower_i,l1<=lower_j,l1<upper_i,l1.

Hence EVERY candidate i for fixed j and transverse y contains the SAME source-j corner

    x_j^*=(lower_j,l1, upper_j,l2, transverse y)             (6)

in the trace directed inward to A_j: positive in l1 and negative in l2. It contains the transverse coordinates because those lie in projection(A_i intersect A_j).

It follows from the ORIGINAL full-space q bound that the total rate of all these candidate i is at most tau at this fixed corner. This is the decisive genuine trace payment; it is not a projected or existential-fiber load bound.

For each fixed tag pair, the remaining k-2 labels are bounded by tau^(k-2)/(k-2)! at the ORIGINAL mixed corner (upper_i,l1,upper_j,l2,y). Marking the two distinct sources is valid since

    w_m<=q_iq_j q^(m-e_i-e_j)/(m-e_i-e_j)!.

Use rho_m<=s_j. After the remaining-label bound, sum q_i through (6) and integrate transverse y in projection A_j. This pays the chosen direction by

    tau^(k-2)/(k-2)!
       sum_j q_j (2c0s_j)^2 (2s_j)^(n-2) tau
      =c0^2 tau^(k-1)U/(k-2)!.                             (7)

The other direction, in which the larger-radius tag supplies l2 instead, gives the same bound. Combining (4) and twice (7) proves the second line of (1) for each coordinate pair, then summing binom(n,2) pairs proves (1).

No center-admission claim at a projected point is used. All invoked capacity tests are at actual full-space one-sided corners. The source-owner volumes enter once through q_jd_j=|F_j|.

## 5. Full numerical size of these bounds

Including the empty term, (1) gives only

    C_empty+sum_{|J|=1}C_J+sum_{|J|=2}C_J
      <=tau^(k-1)U/k!
         [1+n c0 k+binom(n,2)c0^2 k(2k-1)].                 (8)

To compare with the present weaker target U T_min^k/k!, use T_min>kappa tau, kappa=119/320. This certificate still costs

    [1+n c0 k+binom(n,2)c0^2 k(2k-1)]/(tau kappa^k).

Thus even the paid low orders have not acquired the needed rate-ratio gain. Their proof is a real global trace estimate, but is not a constant bound for S_core at the requested normalization. A large upper certificate is not a lower bound on actual S_core.

There is a further full-product warning. The same single-tag argument works for the subseries in which all normals in a fixed J have the SAME upper supporting source, giving c0^|J|tau^(k-1)U/(k-1)!. Summing that marking envelope over ALL nonempty J costs

    [(1+c0)^n-1]tau^(k-1)U/(k-1)!.                          (9)

Hence merely grouping normals by at most k source tags does not by itself produce exp(O(k)): even one tag can own many normals, and this available envelope is exponential in n. Retaining rho_m/s_i and actual receiver geometry rather than bounding it by one may be essential. Equation (9) again describes the marking upper bound, not a realized lower bound or a no-go theorem.

## 6. Exact offset fibers retain the causal ACTUAL receivers

For arbitrary measurable sets Z_m, partition the exterior of I_m by its nonempty set J of outside coordinates and signs sigma in {-,+}^J. Let f_m,J,sigma(y,t) have transverse coordinates y in projection_{J complement}I_m, and normal coordinates

    L_l(m)-t_l if sigma_l=-,
    U_l(m)+t_l if sigma_l=+,

with 0<t_l<=c0rho_m. Unit Jacobian and disjoint coordinate classification give the EXACT identity

    |((I_m+c0rho_mQ) minus I_m) intersect Z_m|
      =sum_{J nonempty}sum_sigma
          integral_{projection I_m}
          integral_{(0,c0rho_m]^J}
              1_{Z_m}(f_m,J,sigma(y,t)) dt dy.              (10)

No BV boundary or trace regularity of Z_m is assumed; this is a nonnegative measurable change of variables. With Z_m=whole space, (10) recovers all nonempty terms of (2). With the causal Z_m equal to the union of the groups at or after a(m), it keeps the true receiver locations and all mixed-face dimensions.

The parent/Astra causal step gives, after its separate audit,

    (T_min^k-1)V_rem/k!
      <=sum_m w_m |(H_m minus I_m) intersect Z_m|.           (11)

Its mechanism is compatible with (10): on an actual X_h in a later causal group all key labels strictly precede h, so the unexpanded original load on B_h is at most one by center admission. The unexpanded causal term is at most V_rem/k!, and is absorbed into the weighted-key cover. This is a separate global causal improvement; it is not claimed as a consequence of (1).

All bounds (1) apply to the corresponding positive clipped terms by dropping 1_{Z_m}, but doing so loses the extra structure in (11). The next real target is therefore the OFFSET joint trace in (10), not another estimate of the old unexpanded full-space moment.

## 7. Exact remaining multi-tag/offset obstruction and stop

For three or more distinct endpoint tags, the two-tag fixed-corner reduction does not immediately iterate. With smallest-radius pivot j, a tag i contains the pivot's lower endpoint in i's own normal block and the pivot's upper endpoint in j's block. In a THIRD tag's block, i need only contain that third tag's mixed endpoint; it need not contain either fixed pivot endpoint vector chosen for the whole block.

Eliminating one tag changes its block to a pivot endpoint. The remaining tags have not been shown to contain those newly substituted coordinates. Paying this by independent corner patterns charges the coordinates in that block, not merely the number of supporting tags, and does not give the required exp(O(k)) all-product estimate. No unproved simultaneous endpoint condition is inserted.

For the actual causal fibers, there is a second exact issue: the original q trace constraints are tested at the FACE point, while the real receiving point is f_m,J,sigma(y,t), offset by as much as c0rho_m in each outside coordinate. Only the latter is known to lie in B_h and enjoy the strict-priority load-one bound. Replacing the face's tau by one without paying that displacement would be invalid.

A proved joint estimate transporting this true receiving constraint through the mixed endpoint/offset integral would be new progress. It is not supplied by (1), (9), projection alone, or one more local face order. No generic L2/adjoint route or local iid sum is reopened.

This bounded task establishes the independently checked first two global mixed orders and the exact all-order causal fiber kernel, but not a complete S_core or original-family packing bound. Work stops here; the next task must attack the actual-Y offset joint trace rather than increment local orders or run new scans.
