# R678 continuation / reproduction

Input comes from the previous R677 research.zip: extract WITNESS_RESULT.json. Its required SHA256 is `51133281e98e46889690d01d1a3a47a114c6dad79ec123cb9d3929f95e16d642`. R678 does not duplicate this input.

Run `python PRODUCT_CHECK.py --input /path/to/WITNESS_RESULT.json`. Without --input, the script reads WITNESS_RESULT.json adjacent to itself. Use exact Fraction arithmetic; no additional packages are required. The existing local interpreter was Python 3.12.14.

Archive PRODUCT_CHECK.py, PRODUCT_SUMMARY.json, NUMERIC.md and this note. Keep the full PRODUCT_RESULT.json local. PRODUCT_SUMMARY.json retains all 120 aggregate records and three-stage statistics, omits all per-key detail, and cryptographically binds the full local result. Rerunning produces updated elapsed-time metadata and therefore a new full-result hash; the exact contributions are unchanged.

The finite low-tau findings do not provide a high-tau, hard-core, or root-order estimate. The next proof decision must retain the substantial higher-codimension terms rather than discard them from these examples.

## Actual current mathematical checkpoint

Read REPORT.tex and the independent review. General square-root upper bound remains unproved. New proved global absorption keeps the SAME true receiver union and original history: core-first causal unexpanded cost <=V/k!, so (T_*^k-1)V/k! <= D_causal. The spatial full-P-first version is also legal with explicit self cost L=1+(32n)^(-n): (T_*^k-L^k)V/k! <= D_full,causal. Its halo/mask and boundary expense are larger; do not use its spatial property with the smaller core cost for free.

Next attack the ENTIRE actual-receiver offset trace, using all cube coordinates and complete source history. First/second global face estimates are proved but insufficient after normalization. Do not spend the next round increasing local face order, renaming the remaining term, or optimizing factorial scalars. In the exact collar representation the load-one receiver is offset from the face point with load tau; an actual joint transport/capacity estimate is missing. Three-tag corner failure diagnoses only a proposed elimination, not the mathematical goal.

Additional reproduction: CAUSAL_CHECK.py --input /path/to/R677/WITNESS_RESULT.json writes CAUSAL_SUMMARY.json. All recorded causal tests use low-threshold strict P minus anchor, not hard K'; maximum tested T=1/64, so they verify coverage and unexpanded inequality, not positive absorption. The full-first self correction is analytically reviewed, not covered by that strict-core finite test.

Use verify.py for exact arithmetic in all 180 saved aggregate records, script/input hash bindings, review bindings and manifest. It is not a general proof checker. No PDF or MATLAB run. Keep at most one Astra and three GPT-6.1 Sol active. The next goal turn must inspect actual Git state; do not infer push from local commit alone.
