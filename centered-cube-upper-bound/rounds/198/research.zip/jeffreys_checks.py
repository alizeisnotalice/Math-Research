#!/usr/bin/env python3
"""Finite Jeffreys beta-factor and clipped-product checks; no interval claims."""
import argparse
from fractions import Fraction as F
import hashlib,json,math,time
from pathlib import Path
import mpmath as mp
HERE=Path(__file__).resolve().parent


def rational_checks():
    selected=set(range(1,513))|{1024,4096}
    c=F(1);rows=[]
    for m in range(1,4097):
        c*=F(2*m-1,2*m)
        if m in selected:
            # Independent exact binomial definition, avoiding enormous JSON ints.
            independent=F(math.comb(2*m,m),4**m)
            assert c==independent and c*c>=F(1,4*m)
            if m in (1,2,8,32,128,512,1024,4096):
                rows.append({'m':m,'numerator_bits':c.numerator.bit_length(),'denominator_bits':c.denominator.bit_length(),
                    'recurrence_equals_binomial':True,'squared_lower_bound':True,'equality':c*c==F(1,4*m)})
    return {'arithmetic':'Fraction','checked_count':len(selected),'m_range':'1..512 plus 1024,4096',
        'assertions':['c_m=binom(2m,m)/4^m equals recurrence','c_m^2>=1/(4m)'],
        'selected_summaries':rows,'status':'PASS'}


def runtime(dps):
    mp.mp.dps=dps
    def val(x):return mp.mpf(x.numerator)/x.denominator
    def out(x):return mp.nstr(x,dps+5)
    def logc(m):return mp.loggamma(mp.mpf(m)+mp.mpf('.5'))-mp.loggamma(m+1)-mp.log(mp.pi)/2
    def zvalue(Nq,uq):
        N,u=val(Nq),val(uq)
        def xlogx(x):return x*mp.log(x) if x else mp.mpf(0)
        logz=mp.loggamma(N*u+mp.mpf('.5'))+mp.loggamma(N*(1-u)+mp.mpf('.5'))-mp.loggamma(N+1)-mp.log(mp.pi)-N*(xlogx(u)+xlogx(1-u))
        m=(Nq.numerator+Nq.denominator-1)//Nq.denominator
        lc=logc(m);margin=logz-lc
        # Integer endpoint is exact equality, but loggamma subtraction can round.
        exact_endpoint=Nq.denominator==1 and uq in (0,1)
        if exact_endpoint:
            exact_c=F(math.comb(2*m,m),4**m)
            assert abs(margin)<mp.mpf(10)**(-dps+5)
            assert abs(mp.exp(logz)-val(exact_c))<mp.mpf(10)**(-dps+4)
        else:assert margin>=0
        return {'dps':dps,'ceil_N':m,'log_Z':out(logz),'Z':out(mp.exp(logz)),
            'log_c_ceilN':out(lc),'log_margin':out(margin),
            'lower_c':out(mp.exp(lc)),'coarse_lower':out(1/(2*mp.sqrt(m))),
            'integer_endpoint_exact_equality':exact_endpoint,'status':'PASS'}
    def clipped(n,family,capq):
        cap=val(capq)
        if family=='symmetric':
            assert n%2==0
            k=n//2;Pmax=F(4)**k
            ai=[F(1)]*k+[F(3)]*k;bi=[F(3)]*k+[F(1)]*k
            def normalized(t):return (1-(t-mp.mpf('.5'))**2)**k
            roots=[]
            if cap<1:
                radius=mp.sqrt(1-cap**(mp.mpf(1)/k))
                roots=[mp.mpf('.5')-radius,mp.mpf('.5')+radius] if radius<mp.mpf('.5') else []
        else:
            Pmax=F(1);ai=[F(1)]*n;bi=[F(0)]*n
            def normalized(t):return (1-t)**n
            roots=[1-cap**(mp.mpf(1)/n)] if cap<1 else []
        # The actual polynomial is checked independently at rational nodes.
        for tq in (F(0),F(1,4),F(1,2),F(3,4),F(1)):
            exact=math.prod((1-tq)*a+tq*b for a,b in zip(ai,bi))/Pmax
            assert abs(normalized(val(tq))-val(exact))<mp.mpf(10)**(-dps+4)
        for root in roots:assert abs(normalized(root)-cap)<mp.mpf(10)**(-dps+3)
        theta_roots=[mp.asin(mp.sqrt(t)) for t in roots]
        cuts=[mp.mpf(0)]+theta_roots+[mp.pi/2]
        den=min(mp.mpf(1),cap**2)
        ratio=2/mp.pi*mp.quad(lambda theta:min(normalized(mp.sin(theta)**2)**2,cap**2)/den,cuts)
        lower=mp.exp(logc(2*n));margin=ratio-lower
        endpoint_equality=(family=='endpoint' and capq>=1)
        if endpoint_equality:assert abs(margin)<mp.mpf(10)**(-dps+4)
        else:assert margin>=0
        return {'dps':dps,'Pmax_exact':str(Pmax),'cap_exact':str(Pmax*capq),
            'normalized_cap':str(capq),'t_clipping_roots':[out(t) for t in roots],
            'theta_clipping_roots':[out(t) for t in theta_roots],
            'ratio':out(ratio),'lower_c_2n':out(lower),'margin':out(margin),
            'endpoint_unclipped_exact_equality':endpoint_equality,'status':'PASS'}
    return zvalue,clipped


def run():
    ns=[('initial',F(1,100)),('initial',F(1,4)),('initial',F(1)),
        ('stress',F(2)),('stress',F(8)),('stress',F(32)),
        ('expanded',F(128)),('expanded',F(1024)),('expanded',F(4096))]
    zrows=[{'stage':stage,'N':str(N),'u':str(u),'runs':[]} for stage,N in ns for u in (F(0),F(1),1/(N+2),F(1,4),F(1,2))]
    crows=[{'stage':stage,'n':n,'family':family,'cap_over_Pmax':str(cap),'runs':[]}
        for stage,n,family in [('initial',2,'symmetric'),('stress',8,'endpoint'),('expanded',32,'symmetric')] for cap in (F(1,10),F(1),F(2))]
    for dps in (25,40):
        zv,cl=runtime(dps)
        for row in zrows:row['runs'].append(zv(F(row['N']),F(row['u'])))
        for row in crows:row['runs'].append(cl(row['n'],row['family'],F(row['cap_over_Pmax'])))
    for rows,key in ((zrows,'log_Z'),(crows,'ratio')):
        for row in rows:
            diff=abs(mp.mpf(row['runs'][0][key])-mp.mpf(row['runs'][1][key]))
            assert diff<mp.mpf('1e-16')
            row['absolute_precision_difference']=mp.nstr(diff,12)
    return {'schema':'r198_jeffreys_v1','inputs':{'task_contract.md':hashlib.sha256((HERE/'task_contract.md').read_bytes()).hexdigest()},
        'dependencies':{'mpmath_version':mp.__version__,'mpmath_entry_sha256':hashlib.sha256(Path(mp.__file__).read_bytes()).hexdigest()},
        'formula_Z':'B(Nu+1/2,N(1-u)+1/2)/(pi u^(Nu)(1-u)^(N(1-u))); 0log0=0',
        'formula_clipped':'integral min(P(t)^2,cap^2) 2dtheta/pi / min(Pmax^2,cap^2); t=sin(theta)^2',
        'clipped_product_families':{'symmetric':'P(t)=(1+2t)^(n/2)(3-2t)^(n/2), Pmax=4^(n/2) at 1/2',
            'endpoint':'P(t)=(1-t)^n, Pmax=1 at 0'},
        'precision_dps':[25,40],'Z_case_count':len(zrows),'clipped_case_count':len(crows),
        'rational_checks':rational_checks(),'Z_cases':zrows,'clipped_cases':crows,'status':'PASS',
        'limitations':['Finite rational and scalar high-precision evidence, not a general beta-factor or clipped-mixture proof.',
            'mpmath loggamma and finite quadrature with explicit clipping points are not directed intervals.',
            'Endpoint equalities are checked with a rounding tolerance rather than a false strict floating sign.',
            'No physical kernel, original source/history, selector, or FULL instance is constructed.']}

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=HERE/'jeffreys_checks.json');args=ap.parse_args()
    t=time.monotonic();r=run();args.output.write_text(json.dumps(r,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'status':r['status'],'Z_cases':r['Z_case_count'],'clipped_cases':r['clipped_case_count'],'exact_m_count':r['rational_checks']['checked_count'],'seconds':round(time.monotonic()-t,3)},sort_keys=True))
