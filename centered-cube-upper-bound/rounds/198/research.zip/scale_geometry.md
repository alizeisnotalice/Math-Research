# R198：mixed 物理核的尺度上包络与真实硬面费

本稿证明固定共同软度 s 的一般物理尺度工具。对 b/a≤2，中心固定，P_{s,L}=L^{-n}∏f_s(x_i/L)，有显式界

\[
 \int\sup_{a\le L\le b}P_{s,L}(x)\,dx
 \le1+{\log(b/a)\over2}
 \left[n(1-s)+\sqrt{n^2(1-s)^2+nV_s}\right],
\]

其中 V_s≤9/4。硬面正跳、连续部分的负平均和 scale Jacobian 全部保留。它给出所求 O(1+n(1−s)+√n)，但近硬的线性费确实不能统一删去；Jeffreys 软度平均和原 inverse-J/cap 权重的接缝另列全部费用。不宣称一般 root 弱型结论闭合。

## SG1. 物理定义、归一化与准确尺度分解

令

\[
 h(r)=1_{[-1/2,1/2]}(r),\quad
 w(r)=\int_0^1e^{-|r|/t}\,dt,\quad \phi=h*w,
\]
\[
 f_s=(1-s)h+s\phi,\quad
 P_{s,L}(x)=L^{-n}\prod_{i=1}^nf_s(x_i/L),
 \quad s\in[0,1],\quad0<a\le L\le b.
\]

h、φ、fs 是概率密度；F、C 没有被概率化。所有来源可任意相关，下面 tensor 计算只针对物理 receiver 核的确切乘积。

对 f_s>0 处定义

\[
 \kappa_s(r)=-1-{rs\phi'(r)\over f_s(r)},\quad
 \psi_s(r)=\kappa_s(r)+(1-s).
\]

s=0 的零密度区域不作除法，ψ0取0。指数尾使 ∫rφ'=−1，故

\[
 \int\kappa_s f_s=-(1-s),\qquad
 \int\psi_s f_s=0.
 \tag{SG1}
\]

第一项 −1 来自 L^{-1} Jacobian，不能遗漏。对 logL 的一维 signed 测度导数为

\[
 \partial_{\log L}[L^{-1}f_s(x/L)dx]
 =\kappa_s(x/L)L^{-1}f_s(x/L)dx
   +{1-s\over2}(\delta_{L/2}+\delta_{-L/2}).
 \tag{SG2}
\]

由换元后对 C1 紧支撑测试函数积分分部即可核验两面各 (1−s)/2。张量连续部分为 P_{s,L}Σκ_s；n 个坐标的面正质量合为 n(1−s)。完整 signed derivative 的总质量仍为零，面测度没有被视为合法 FIRST future 核。

## SG2. 原 φ 的 scale-score 二阶矩：自足常数

这是冻结 R176 SF5–8 的物理计算，本节完整给出。令

\[
 g_t=h*\ell_t,\quad \ell_t(r)={e^{-|r|/t}\over2t},
 \qquad\phi(r)=\int_0^12t\,g_t(r)\,dt.
\]

权 2t 的积分为1。在 |r|≤1/2，

\[
 g_t(r)=1-e^{-1/(2t)}\cosh(r/t)
 \ge c_0={1-e^{-1}\over2},\quad
 |g_t'(r)|\le{e^{-(1/2-|r|)/t}\over2t}.
\]

用 r²≤1/4 和对称积分得

\[
 \int_{|r|\le1/2}{r^2g_t'(r)^2\over g_t(r)}dr
 \le{1\over16c_0t}.
 \tag{SG3}
\]

在 r=1/2+u、u≥0，有 g_t=(1−e^{-1/t})e^{-u/t}/2，导数模为 g_t/t；两侧精确积分给

\[
 \int_{|r|>1/2}{r^2g_t'^2\over g_t}dr
 =(1-e^{-1/t})\left({1\over4t}+1+2t\right).
 \tag{SG4}
\]

对任一此类概率密度 g，scale-score 矩为

\[
 I(g)=\int\left(-1-{rg'\over g}\right)^2g
     =\int{r^2g'^2\over g}-1.
\]

因此设 A0=1/4+1/[8(1−e^{-1})]，则 I(g_t)≤A0/t+2t。对 scale-score 的 numerator −g−rg' 使用混合 Cauchy，

\[
 I_\phi\le\int_0^12t\,I(g_t)dt
 \le2A_0+{4\over3}
 =:B_\phi={11\over6}+{1\over4(1-e^{-1})}<{9\over4}.
 \tag{SG5}
\]

Tonelli 与显示的可积上界处理 t↓0，不需要正则化后删费用。最后严格界仅用 e>5/2，可由指数级数初项核验。

此处 Iφ 是 scale-score Fisher，Bφ 是它的明确数值上界；另一个矩 ∫r²φ′²/φ=Iφ+1 的上界为 Bφ+1。本文不声称 Bφ+1≤3，主包络常数只使用下面的 V_s≤Bφ<9/4。

对 mixed 物理 score，令 V_s=∫ψ_s²fs。s>0 时展开并用 ∫rφ'=−1、fs≥sφ，得到

\[
 V_s=s^2\left(\int{r^2\phi'^2\over f_s}-1\right)
 \le s(I_\phi+1)-s^2
 \le s(B_\phi+1)-s^2\le B_\phi<{9\over4}.
 \tag{SG6}
\]

s=0 时 V0=0。最后一步因 Bφ>1，Bφ−[s(Bφ+1)−s²]=(1−s)(Bφ−s)≥0。这同时证明 task 中真实 φ 的有限 scale-score 二阶矩，未假设一般 log-concavity 或来源坐标独立。

## SG3. 正变差得到全尺度包络

对几乎每个固定 x，L↦P_{s,L}(x) 在 [a,b] 上分段 C1，只在有限个 L=2|x_i| 有硬核进入的非负跳。不同坐标同时进入的 x 集为有限个超平面、Lebesgue 零测；不影响下面积分。闭硬面给右连续 entry 值。初始 Pa 已计入，只将 (a,b] 的 entry 跳计入后续变化。

故点态有

\[
 \sup_{a\le L\le b}P_{s,L}(x)
 \le P_{s,a}(x)
 +\int_a^b[\partial_{\log L}^{\rm ac}P_{s,L}(x)]_+{dL\over L}
 +\sum_{L\in(a,b]}\Delta_LP_{s,L}(x).
 \tag{SG7}
\]

积分所有 entry 跳时，一个坐标的 jump 为 (1−s)L^{-n}∏_{j≠i}fs(x_j/L)，两侧 x_i=±L/2 的换元各给 dL/2，其余坐标积分 L^{n−1}。因此跳项准确积分为

\[
 n(1-s)\log(b/a).
 \tag{SG8}
\]

对连续项，令 X_i 按物理 fs 分布，Y=Σψ_s(X_i)、A_h=n(1−s)。Y 均值0、方差 nV_s，且 Σκ=Y−A_h。用 z_+=(|z|+z)/2 与 Cauchy，

\[
 \int[\partial_{\log L}^{\rm ac}P_{s,L}]_+dx
 =\mathbb E(Y-A_h)_+
 \le{\sqrt{A_h^2+nV_s}-A_h\over2}.
 \tag{SG9}
\]

这一步保留连续部分平均 −A_h；没有在面项之外再丢一次同样的负体积信用。物理 product 下交叉项为零，并非原 Pi/source 独立性。

令

\[
 \mathfrak S_{n,s}={A_h+\sqrt{A_h^2+nV_s}\over2}.
\]

合并 SG7–9 和 ∫Pa=1，得

\[
 \boxed{\int\sup_{a\le L\le b}P_{s,L}(x)dx
       \le1+\mathfrak S_{n,s}\log(b/a).}
 \tag{SG10}
\]

又有 sqrt(A_h²+nV_s)≤A_h+sqrt(nV_s)，故

\[
 \mathfrak S_{n,s}\le n(1-s)+\tfrac12\sqrt{nV_s}
 \le n(1-s)+\tfrac34\sqrt n.
 \tag{SG11}
\]

b/a≤2 时，SG10–11 给所求绝对常数界；特别可用 1+n(1−s)+√n。若 1−s≤C/√n，固定 s 的尺度包络费为 O((1+C)√n)。a=b 时包络积分恰1，所有路径费为零。

## SG4. 硬尺度费不能在原允许软度下统一去掉

纯硬 s=0 有 V0=0，SG10 为 1+nlog(b/a)，而且是等号。直接看 r=||x||∞，r≤a/2 时最大 a^{-n}，a/2<r≤b/2 时最大 (2r)^{-n}，积分即

\[
 \int\sup_L h_L^{\otimes n}=1+n\log(b/a).
 \tag{SG12}
\]

一般 s∈[0,1] 的实际核含正 hard component：P_s,L≥(1−s)^n h_L^{⊗n}，因此

\[
 \int\sup_L P_{s,L}\ge(1-s)^n[1+n\log(b/a)].
 \tag{SG13}
\]

原严格软下门为 s>1−2^{-1/n}。取任一固定 c>log2、s_n=1−e^{-c/n}，便严格处于该门之上，而 (1−s_n)^n=e^{-c}。ratio2 的包络仍为 Ω(n)。这只是本 kernel 工具的线性下界，不是一般弱型问题的反例；说明不能无额外原几何把 SG10 统一改成 O(√n)。也不声称对每个固定中间 s，SG11 的 n(1−s) 都是 sharp。

## SG5. 一般正 L1/来源积分及尺度 selector 的合法预算

定义 E_s(x)=sup_{a≤L≤b}P_s,L(x)。其可测性可由上述分段连续、右 entry 值得到，或用稠密尺度序列及端点取上确界。

对任意有限正来源测度 η，

\[
 \sup_L(P_{s,L}*\eta)(x)\le(E_s*\eta)(x),\quad
 \int\sup_L(P_{s,L}*\eta)\,dx
 \le[1+\mathfrak S_{n,s}\log(b/a)]\|\eta\|.
 \tag{SG14}
\]

Tonelli 直接证明，故适用于任意正 L1 输入。任意可测 L(x)∈[a,b]、甚至 L(x,z) 的来源依赖尺度选择都可由该正包络支配，只要正在被积分的固定正来源 η 及其他费用保持；不需固定 receiver 尺度或来源密度。

若原共同来源预算为 ΣV||νV||≤W_A，且窗口 ratio≤2，固定同一 s 的逐 V 正包络可按真实 ΣV 源账汇总。不同 s_V 用各自常数；多窗独立重用必须保留原账，不额外复制 WA。实际 outer β、ν/e、wt/Wg、原 capture 三点系数若依 receiver，SG14 不把它们变成固定 η，也不自动支付其权重。

## SG6. Jeffreys 平均及与父软度工具的准确接缝

令 dJ(s)=ds/[πsqrt(s(1−s))]，质量1且 ∫(1−s)dJ=1/2。SG11 和 Tonelli 给真实平均

\[
 \int dJ(s)\int E_s(x)dx
 \le1+\log(b/a)[n/2+\tfrac34\sqrt n].
 \tag{SG15}
\]

这是共同 prior 平均而非 receiver 自适应 s(x) 的 bound。若另有父本轮已独审的软度 pointwise 工具（r=1）

\[
 \sup_s P_{s,L}(x)\le C_J\sqrt{n+1}\int P_{s,L}(x)dJ(s),
\]

则正上放可得到

\[
 \int\sup_{s,L}P_{s,L}(x)dx
 \le C_J\sqrt{n+1}
 [1+\log(b/a)(n/2+\tfrac34\sqrt n)].
 \tag{SG16}
\]

软度先界、尺度再放入 prior 积分的顺序是合法的，但该直接组合保留 O(n^{3/2}) 费，不能将两个 root 作用相乘后只报一个 root。SG13 已说明 near-hard 区需要原额外资格才可能进一步节约。

父/同轮 Astra 的实际截帽核 min(P_s,L²,(BJ)²)/J 有 inverse-J 权重，不是本节的物理概率密度。它的连续 score 积分不再具有 SG9 使用的 fs product 均值/方差；不能把本稿固定 s 的 root 连续费直接代入该核。本稿不替其既有 1+2nlog2 正径向尺度账省费。若对实际 capture 或 signed mask 做尺度积分分部，还须保其导数、硬面 traces、selector 和 source-normalizer 费用；SG10 没有消费这些原信用。

## SG7. 有限结论与停止

本轮新增的实际工具是 SG10 的全尺度包络，常数细化为 [n(1−s)+sqrt(n²(1−s)²+nV_s)]/2，物理 score 二阶矩和所有正硬面费用均已自证。它给近全 soft 的固定 s 根阶尺度费，同时原允许 near-hard 软度仍有 SG13 的线性尺度下界。

SG14 给一般正 L1/固定来源与任意尺度 selector 的实际路径；SG15–16 诚实保留 Jeffreys/source 合并费用。没有将该未加权 kernel 工具称为原 inverse-J 截帽或 occupation 付款，不宣称一般任意输入根阶弱型闭合。不再扩展新路线。
