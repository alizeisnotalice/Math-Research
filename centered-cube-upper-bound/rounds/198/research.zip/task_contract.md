# R198: 软度选择的平方根混合费与硬尺度账

权威基线R197提交15ca7efb5d16ea6805d4b2e86148796d942be5af，外部冻结目录/Users/zhengzhihao/Desktop/T/output/centered_cube_round197_20261016_final_checkpoint。一般任意正L1根阶目标不变。

主准确候选：任意非负a_i,b_i，P(s)=∏[(1-s)a_i+s b_i]，任何r>0，是否有sup_s P(s)^r ≤C sqrt(rn+1)∫_0^1P(t)^r dt/[πsqrt(t(1-t))]，端点和零值先处理，C绝对。欲替代R197 TK6的exp(r)(n+1)软度费。需要完整证明与数值三阶段验证，不凭Bayes/Jeffreys名称引用。

进一步：能否在原cap不变、真实Lebesgue接收测度下与R197反集中结合；不得将fixedparameter反集中免费应用于sup。尺度硬面费另外研究，允许诚实保留n因子而不猜√n。

父主证明与整合；Astra负责混合包络与反集中的合法接缝；Sol high负责硬尺度一般几何费；Sol high先独筛再审；Sol medium精确/高精度数值复现。各自只写分配文件，不git、不spawn、不覆盖他人。来源nu/e、wt/Wg、j/time、共同alpha与window账全部保留。

每轮独审后精简归档，详细LaTeX，不编译PDF，单独提交推送。没有完整一般证明不宣称闭合。
