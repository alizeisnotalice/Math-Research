# R198: a monotone cap preserves the square-root softness mixture and anti-concentration

This proves an adaptive capped receiver-kernel estimate. The original hard likelihood cut is enlarged to a monotone cap before applying the softness mixture. Its extra above-cap part has a decaying likelihood weight and is paid by the same finite-displacement anti-concentration. The scale, original source normalization and time costs remain explicit. No general source-budget closure is claimed.

## MA1. Original fixed-source cap

Fix an original window and sources y,v. Normalize b to one in receiver coordinates and write `d=(v-y)/b`, `lambda=L/b in [1/2,1]`. Let

    p_(s,lambda)(z)=product_i lambda^(-1) f_s(z_i/lambda),
    j(z)=product_i phi(z_i-d_i),
    W_g(y,v)=product_i C(d_i),
    B0=K/[3(1-eta)], B=B0/W_g, 0<eta<1.

Here W_g is the fixed-source lower bound for the original terminal weight, not a newly selected terminal clock. The original `w_g(y,v)>=W_g` holds even when g depends on receiver x. On the original good, high-A gate `A>=1-eta`, R196 TD11 gives

    p_(s,L)(x-y)/J_b(x-v) <= B.                    (MA1)

This safely enlarges the actual cap, which also retains rho. The target-current smallness gate, high, reciprocal, capture, history and receiver membership may subsequently be positively dropped in the kernel upper bound; they are not asserted to hold after enlargement. The sources, original posterior and alpha are not recomputed.

Let

    m=m(y,v)=#{i: |y_i-v_i|>=3b/4},
    h0=1/16,
    q_m=min(1,sqrt(128/(m+1))),
    a_m=min(1,2 q_m/(1-exp(-h0))).                 (MA2)

The integer m is fixed by the source pair before receiver or softness integration. All square kernels here are physical densities; the common b powers cancel in `integral p^2/J dx`.

## MA2. The needed form of the independently proved softness lemma

For a product of n nonnegative affine factors P(s), choose a maximizer s_* of P. If the maximum is positive, `jeffreys_envelope.md` sections 2--3 give

    P(t)>=P(s_*) exp[-n KL(s_* || t)],
    integral_0^1 exp[-N KL(s_* || t)] pi(dt)
           >=1/(2 sqrt(N)), N=2n,
    pi(dt)=dt/[pi sqrt(t(1-t))].                  (MA3)

Endpoint parameters use the usual continuous conventions for Bernoulli KL. If P vanishes identically the following inequalities are zero. MA3 is the independently proved near-maximizer form, not just an estimate of the untruncated integral of P^2. That distinction is needed to retain the cap.

For every c>=0 fixed with respect to the softness variable,

    sup_s min(P(s)^2,c^2)
       <=2 sqrt(2n) integral_0^1 min(P(t)^2,c^2) pi(dt).        (MA4)

Proof: the cap function is monotone, so its supremum is attained at the same s_* as P. If `a=exp[-n KL]<=1`, then

    min(P(t)^2,c^2)>=min(a^2 P(s_*)^2,c^2)
                   >=a^2 min(P(s_*)^2,c^2).

Integrate and apply MA3. The case c=0 is zero. No upper comparison between P(t) and P(s_*) is required, and the proof does not claim that a truncated likelihood event persists under a change of softness.

In the application c(z)=B j(z). It depends on receiver and the fixed source pair, but **not** on the softness being mixed. It also does not depend on the variable current scale in the scale step below. This is why MA4 applies.

## MA3. Fixed-parameter cost of the enlarged cap

For fixed `(s,lambda)`, put `r(z)=p_(s,lambda)(z)/j(z)`. The actual likelihood-truncated kernel is positively bounded by

    p^2/j 1_{r<=B} <= min(p^2,(Bj)^2)/j.           (MA5)

The extra above-cap part is controlled through the exact identity

    integral min(p^2,(Bj)^2)/j dz
       = B E_p exp[-|log(r/B)|].                  (MA6)

At p=0 the original integrand is zero; the probability identity is taken on its positive support. It therefore also covers pure hard receiver densities. J is strictly positive.

The R197 finite-displacement theorem applies uniformly to every s in [0,1] and lambda in [1/2,1]. It proves

    sup_a Prob_p(log r in [a,a+h0]) <= q_m.         (MA7)

For completeness, its geometric input is actual: on each coordinate with |d_i|>=3/4, two current-core intervals of mass at least 1/128 have log-likelihood ranges separated by at least 1/8. Extracting these two masses gives a fair Bernoulli pair with activation probability 1/64. Conditional antichains and the binomial activation count give MA7. Only the receiver product density is independent; the source coordinates have no independence assumption.

Partition the two half-lines around log B into half-open intervals of length h0. The exponential in MA6 is at most exp(-k h0) on the kth interval on each side. Thus

    E_p exp[-|log(r/B)|]
       <=min(1,2 q_m sum_(k>=0) exp(-k h0))=a_m,
    integral min(p^2,(Bj)^2)/j dz <= B a_m.        (MA8)

This pays both sides of the monotone cap. Merely applying the one-sided truncated estimate at the mixed parameters would not have justified MA4--8.

## MA4. Actual full-softness capped kernel estimate

Apply MA4 pointwise with P(s)=p_(s,lambda)(z), divide by the fixed positive j, and then integrate z and pi. MA8 is uniform in the mixed parameter. Consequently

    integral sup_(0<=s<=1)
        [p_(s,lambda)^2/j 1_{p_(s,lambda)/j<=B}] dz
       <= integral sup_s min(p_(s,lambda)^2,(Bj)^2)/j dz
       <= 2 sqrt(2n) B a_m.                       (MA9)

This is a genuine softness-selector estimate in Lebesgue receiver measure. It retains the finite-displacement anti-concentration factor rather than multiplying an untruncated envelope and an unrelated cut estimate.

For m proportional to n and sufficiently large to enter the nontrivial range of MA2, the factor sqrt(n) in the mixture and the factor 1/sqrt(m) in a_m compensate each other up to explicit constants. For small m, a_m=1 may be the only available estimate. No nonempty geometric coverage is inferred from a threshold that exceeds n.

Multiplication by the original fixed-time source weight gives the physical bound `2 sqrt(2n) B0 (w_t/W_g) a_m`. The original ratio w_t/W_g has not been deleted.

## MA5. All current scales: the hard-face cost is retained

Define

    F_lambda(z)=sup_s min(p_(s,lambda)(z)^2,(B j(z))^2)/j(z).

For each s, lambda^n p_(s,lambda)(z) is nondecreasing in lambda. The hard kernel's closed-face convention makes its jumps upward. Since j and B are fixed in this step,

    lambda^(2n) F_lambda(z)
       =sup_s min((lambda^n p_(s,lambda)(z))^2,
                  lambda^(2n)(Bj(z))^2)/j(z)

is also nondecreasing. The radial Stieltjes envelope, including all its hard jumps, therefore gives

    sup_(a/b<=lambda<=1) F_lambda
       <= F_1+2n integral_(a/b)^1 F_lambda dlambda/lambda.

Integrating and using MA9 at each lambda proves

    integral sup_(s,L in original window)
        [P_(s,L)(x-y)^2/J_b(x-v)
              1_{P_(s,L)(x-y)/J_b(x-v)<=B}] dx
       <= D_n B a_m,
    D_n=2 sqrt(2n)[1+2n log(b/a)]
       <=2 sqrt(2n)(1+2n log 2).                  (MA10)

For the kernel including the actual fixed-time target weight,

    w_t integral sup_(s,L) [same truncated expression] dx
       <=D_n B0 (w_t/W_g) a_m.                    (MA11)

The remaining factor of order n in MA10 is explicit. The unweighted physical-density scale estimate from the parallel scale manuscript does not apply to this inverse-J cap without a further argument. MA10 also does not mix receiver-dependent terminal clocks: they were already enlarged using the fixed W_g in MA1.

## MA6. Return to the original companion and source ledger

In the global formulas MA12--13 below, D_n denotes the uniform bound 2 sqrt(2n)(1+2n log 2), not a single window-dependent value from MA10. This applies when the original windows vary with omega,V.

Consider the actual high-A companion, or its R196 large-current-difference part. Its integrand `p_y^2 A^2/J_v` is bounded by `p_y^2/J_v` only on the original masks. At those points MA1 holds. First make this positive enlargement, and only then apply MA10--11. The original target posterior is

    Pi_(y,j,t)(dv)=1_{Z_(y,j,t)}(v) w_t(y,v) nu_V(dv)/e_t(y).

It is independent of receiver x at fixed `(omega,V,j,y,t)`. After dropping the remaining bad-source posterior probability by its mass bound one, MA11 gives the rigorous original upper estimate

    C_actual
       <=D_n B0 E sum_V sum_j integral_(I_j) dt/t
             integral beta_V(dy) integral Pi_(y,j,t)(dv)
                    a_(m(y,v))/W_g(y,v).          (MA12)

I_j is the original x-independent auxiliary interval `[a/c_j,b c_j]` intersected with its defining domain. Empty intervals and e_t=0 rows contribute zero. Every actual receiver and history restriction has only been positively enlarged; no original posterior, alpha, bad source, forest or source law is reselected. Keeping more of these restrictions can improve MA12, but such an improvement is not asserted here.

Formula MA12 is an upper estimate with a fully explicit physical source weight. It is **not** a paid W_A bound: `a_m/W_g` can be large on the tiny-good-weight core. The probability mass bound for Pi does not control it. Nor can an upper bound for the kernel including w_t be integrated against nu/e_t as though that were a probability.

If a retained region has a separately established bound `a_m/W_g<=R_*`, then the elementary consequence is

    C_actual <= D_n B0 R_* Tstar W_beta,
    Tstar=sup_windows sum_j log_+(b c_j^2/a)
         <=log 2+(n+1)(log 2)^2/4.                 (MA13)

This implication records all costs; it does not claim the original remainder satisfies that condition. It would combine with the repaired energy `E_J<=n W_nu/(2K)` to give the corresponding raw bound `(32 Lambda/3) sqrt[n D_n B0 R_* Tstar/(2K)] W_A`. Additional original windows retain their own source ledger. The unique-j restriction cannot cancel Tstar after the different frozen posterior measures have been positively summed.

Thus the new result is the legitimate all-softness anti-concentration estimate MA9 and its all-scale form MA10, including both sides of the cap and the real source/time return MA12. It improves the selector fee without asserting that the tiny-overlap source column or the general root bound is now paid.
