# R198 独立审计

仅维护本文件；其他作者同时工作，无Git/spawn/他人编辑。先读task_contract.md，未读本轮作者证明即作§§1–3独立命题筛查。当前是预审检查点，不是最终冻结。

## 1. 非负仿射产品的Jeffreys平方根费：独筛通过

设n>=1、r>0、P(s)=product_i[(1-s)a_i+s b_i]，a_i,b_i>=0。P恒零先取零。否则在极大点u所有因子为正。0<u<1时，令pi_i=u b_i/[(1-u)a_i+u b_i]，一阶条件给sum pi_i=nu；对各因子的两个正项用log凹性，得到

P(t)>=P(u) exp[-n KL(u||t)]，0<t<1。

u=0或1不需要一阶等号，逐因子分别用f_i(t)>= (1-t)a_i或t b_i给相同结论。零端点的KL按连续极限解释。正幂r合法。

记N=rn、m=ceil N>=1。由于KL>=0，Z_N(u)=integral exp[-N KL(u||t)]dt/[pi sqrt(t(1-t))]>=Z_m(u)。精确Beta式为

Z_m(u)=B(mu+1/2,m(1-u)+1/2)/[pi u^(mu)(1-u)^(m(1-u))]。

令h(x)=psi(x+1/2)-log x。对x>0，h'(x)=sum_(k>=0)(k+x+1/2)^(-2)-1/x<0；严格不等号来自严格凸函数(x+t)^(-2)在每个[k,k+1]的midpoint积分。于是d log Z_m/du=m[h(mu)-h(m(1-u))]>=0于u<=1/2。对称性及端点连续性给全局最小在端点。

此处Gamma串无需未核外部定理：M^z B(z,M+1)=integral_0^M t^(z-1)(1-t/M)^M dt趋Gamma(z)，且前两z导数在正compact上由t^(z-1)|log t|^j exp(-t)支配；Beta反复分部积分给Euler乘积极限。对log二阶求导即得上述绝对收敛串。

端点Z_m(0)=binom(2m,m)/4^m=:c_m。c_1=1/2且(c_(m+1)/c_m)^2=((2m+1)/(2m+2))²>=m/(m+1)，故c_m>=1/(2sqrt m)。因此严格得到

sup_s P(s)^r <=2sqrt(ceil(rn)) integral P(t)^r dt/[pi sqrt(t(1-t))]
<=2sqrt(rn+1) integral P(t)^r dt/[pi sqrt(t(1-t))]。

n=0的空产品另直接成立。该结果只收soft选择费，不包含原cap、scale、source列或clock费用。

## 2. 固定软度的一般尺度包络：必须保硬面

对原产品核P_(s,H)，ac尺度score kappa=-1-r s phi'/f_s 的均值为-(1-s)；中心化psi=kappa+(1-s)的已审一致方差<=9/4。因此ac product导数的L1范数<=1.5sqrt n+n(1-s)。每个坐标两面各权(1-s)/2，正面measure总量n(1-s)，不能从ac导数中遗漏。

保全部BV变差即可安全给

integral sup_(a<=H<=b) P_(s,H)(x)dx
<=1+log(b/a)[1.5sqrt n+2n(1-s)]。

这是固定s、闭面按尺度右连续代表元的正Stieltjes/BV结论；固定s可经Tonelli给一般L1输入及实际H(x)正包络。不能仅从每个s的积分界免费替成s(x)。s=0的真实hard包络恰有1+nlog(b/a)费用，因此一般尺度账含n项有实际必要；没有宣称统一root尺度界。

## 3. 新capped反集中接缝：准确候选独筛通过

收到Astra准确候选后先独推，尚未读其证明。固定receiver处c=BJ>0，且c对被优化soft参数s固定。F_c(P)=min(P²,c²)单调，故sup_s F_c(P_s)=F_c(max_s P_s)。由§1的KL下界，F_c(P_t)>=exp[-2n KL]F_c(P_max)，可用r=2的积分下界得到显式2sqrt(2n)的softsup因子。c可依receiver/source，但不能随正在优化的s另选。

固定s、lambda，r=p/j时准确有

integral j min(r²,B²)dx = B E_p exp[-|log(r/B)|]。

对长度h0=1/16的双侧分箱，以R197真实产品receiver反集中q_m<=min(1,sqrt(128/(m+1)))控制，右侧<=B min(1,2q_m/(1-exp(-h0)))。purehard先删p零集。原截断integrand<=此capped integrand，但两者不相等；above-cap部分确由对称指数帽处理，不能直接把原truncated单参数界平均成sup。

该构件可把soft选择费与固定参数反集中合法连接；m约n时只是抵消显式sqrt n soft费。尺度、wt/Wg、原nu/e、完整j/time及窗口重用尚需各自原账。等待父及两作者完整稿后审核，不把新界面登记为一般原余域已付。


## 4. 作者后读：三份完整数学稿

完成前述独筛后全文核验 jeffreys_envelope.md。KL内点和端点、Euler/Beta前两导数支配、H严格递减、Z端点最小、非整数N向ceilN放宽及c_m递推均通过。固定c的正幂截帽扩展与可测sup/Tonelli准确。该稿没有把原非单调cut直接带入混合不等式。

全文核验 mixed_anticoncentration.md 的MA1–13通过。原good/highA先给source-fixed B=B0/Wg；单调帽以上的积分确由B E_p exp[-|log(r/B)|]及双侧分箱支付。soft积分后仍保a_m=min(1,2q_m/(1-exp(-1/16)))，不把固定参数截断估计直接平均为sup。lambda^(2n)F_lambda单调，尺度正Stieltjes界包含闭硬面，给D_n=2sqrt(2n)[1+2nlog(b/a)]；不能用未加权物理密度的scale方差替其逆J平方帽省费。MA12返回原beta Pi列时保a_m/Wg；MA13只在另已证该source weight上界时给D_n B0 Rstar Tstar Wbeta。实际source/time付款仍未闭合。

全文核验 scale_geometry.md 的SG1–16通过。内外Laplace混合积分、Iphi上界Bphi<9/4、V_s和score均值正确。正变差可比§2的安全界更锐：A_h=n(1-s)时

integral sup_L P_s,L <=1+log(b/a)[A_h+sqrt(A_h²+nV_s)]/2
<=1+log(b/a)[n(1-s)+.75sqrt n]。

ac正变差用(E|Y-A_h|-A_h)/2，另加真实entry正跳A_h；没有重复消费负体积项。初始Pa先计，只有(a,b]跳后计。purehard等号和nearhard正分量下界通过；它们限制的是该正包络工具，不是原弱型问题反例。固定正来源的Tonelli尺度包络、Jeffreys平均和全soft组合费用准确。

最终SG5后的符号范围句亦核对：Iphi是scale Fisher量，Bphi仅其上界；Bphi+1不被声称<=3。主证明只使用V_s<=Bphi<9/4，未依赖未落盘的新锐化。

## 5. 数值静态核验

逐行静核 jeffreys_checks.py 及最终 numerical_review.md，不重复运行。45项Z_N(u)的Beta-loggamma式含0log0约定、ceil整数和端点相等容差；514项Fraction递推与独立binomial及c_m²下界；9项平方帽积分的原有理product核对、Pmax、固定cap、clipping roots和sin²theta后的2/pi Jacobian均正确。低cap整段截帽、cap>=peak及纯endpoint相等分支正确。

这些有限整数断言不替代所有m的归纳；25/40位特殊函数/quad与显式roots不构成interval认证。JSON依赖/contract哈希及notes计数、非physical/FIRST/FULL标签准确。父/数值作者报告已有完整JSON隔离重放；本审计仅静态检查，最终driver尚待父整合。


## 6. 最终整合核验与冻结

proof.tex.txt全文核验JE/KL/Beta、截帽两侧、MA12/13原来源回代及SG连续/面正变差与三份数学稿一致。发现并已实读修复两项转录/量词问题：(i) repaired能量/Cauchy显示公式的结束符补为\]；(ii) 跨窗口全局MA12–14统一取D_n=2sqrt(2n)(1+2nlog2)，不得提出某个窗口的D_n。Tstar同样取原窗族sup；B0/Rstar若变须原逐窗费用或统一上界。没有编译PDF。

report.md范围/常数和数值计数正确。reproduce.py静态通过：先核manifest，再要求新输出JSON路径、运行单脚本并传递非零退出，完整字节比较；不冒充一般proof checker。父已报告实际重跑45/514/9完整JSON一致；本审计未重复运行，最终manifest总driver留待父归档阶段执行，不提前声明通过。

最终通过范围：非负仿射乘积及单调帽的sqrt软度费；合法全soft反集中接缝和显式尺度/来源费用；固定s物理尺度包络及nearhard线性下界。原a_m/Wg、source归一、完整j/time/window和少分离坐标补集仍未支付，未认证一般root弱型结论或all-mother付款。没有必须修项未处理。

以下绑定当前10个其他work文件；不绑定本文件自身或未来manifest。到此冻结停止。

| 文件 | SHA256 |
|---|---|
| jeffreys_checks.json | `11daebcb60f8e61369893c165fe1e6d97624d40c0c719902280703427a8de0d3` |
| jeffreys_checks.py | `7a16323323b34662f22723122c24116d464ad4dac23292038f78456f8b357543` |
| jeffreys_envelope.md | `e05f273cc3ff0c79d791d7ef17021d972ebe7e7c8d60ef3aa9f22de013b51564` |
| mixed_anticoncentration.md | `3e3cbc5b4780215fd7d8342d33483533ac9f0b676020b7ce4bdcd87d4ec055b3` |
| numerical_review.md | `9edb01eed836ab161e5766a33230d085c3a62ebd44374745da60b6e4a950321e` |
| proof.tex.txt | `59ed4927e2ff4a22d1aa9b24d116d8eb50f6c64d5cb2efe4eed5bef27045b845` |
| report.md | `cf972f4cf7376fc4c5b78467fac13214ed72d3558f8dcb0474ca350db361e3f6` |
| reproduce.py | `d6a32e41afd37c538f916b122fabc81bc548aede67d8e7770f19fbd59fc6bed9` |
| scale_geometry.md | `6531512a6a7651674620dfb6802255987bcaff0d525a98a4d149c762b2aa40c9` |
| task_contract.md | `0a334c138925296ecf16e9f99fd96bf418f7d24940473b6e321c0dfecfcdf637` |
