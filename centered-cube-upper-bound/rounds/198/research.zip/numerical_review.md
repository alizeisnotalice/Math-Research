# R198 Jeffreys mixture diagnostics

The script passed three finite categories: 45 beta-factor parameter cases at 25/40 decimal digits; 514 exact integer checks; and nine clipped-product cases at both precisions. These are finite algebraic/high-precision diagnostics, not a general mixture theorem, physical original source/selector instance or FULL certificate.

For Z_N(u), stages use N=(.01,.25,1), (2,8,32), (128,1024,4096), with u=0,1,1/(N+2),1/4,1/2. The loggamma formula uses 0log0=0 explicitly and checks Z_N(u)>=c_ceil(N). Integer endpoints are true equality branches: their numerical log difference is allowed a rounding tolerance and exp(log Z) is also compared to an independently computed Fraction binomial coefficient. No negative floating equality residue is misreported as a counterexample. The largest observed 25/40 log-Z difference is below 1.30e-22 (script threshold 1e-16), including the largest N=4096.

For every m=1..512 and m=1024,4096, Fraction arithmetic independently compares the recurrence product (2j-1)/(2j) to binom(2m,m)/4^m and verifies c_m^2>=1/(4m). The output retains counts, exact pass flags and selected numerator/denominator bit lengths rather than huge integer strings. Equality in this coarse squared bound occurs at m=1 among the selected summaries. This is exact evidence for these finite integers, not all m by induction.

The clipped cases keep r=2, the actual peak Pmax and a fixed cap throughout each mixture. Initial n=2 and expanded n=32 use P(t)=(1+2t)^(n/2)(3-2t)^(n/2), whose maximum is 4^(n/2) at t=1/2. Stress n=8 uses P(t)=(1-t)^n with maximum 1 at t=0. Each stage tests cap/Pmax=1/10,1,2. The simplified normalized polynomial is independently compared with the original rational factor product at five rational t nodes. Integration uses t=sin^2(theta), Jeffreys measure 2dtheta/pi, with explicit clipping roots. Roots are checked by substitution before integration; a low cap below the whole symmetric polynomial is correctly classified as entirely clipped, with no internal root.

All ratios pass the lower c_(2n). For n=8 endpoint and cap>=Pmax the ratio equals c16 numerically, about 0.1399499340914. For n=2 symmetric, the ratios are 1,0.7734375,0.7734375. For n=32 symmetric, they are about 0.5950429748,0.2041294858,0.2041294858, all above c64 about 0.07038609217. The cap=2 values correctly duplicate the untruncated ratio: the denominator remains min(Pmax^2,cap^2), not cap^2. These checks do not optimize arbitrary products or change a cap during integration.

All high-precision calculations use standard-import mpmath 1.3.0. No interval arithmetic is used; explicit clipping points do not certify quadrature or loggamma rounding. There is no asymptotic fit. Reproduce with the already available vendor path, without installing dependencies:

```sh
PYTHONPATH=/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor python3 jeffreys_checks.py --output jeffreys_checks.json
```

Copy the script and its local task_contract.md together to relocate it. JSON records the local contract filename hash plus mpmath version and entry-file SHA, not absolute mathematical input paths or timing. Runtime was about 0.1 seconds locally. An independent temporary-directory copy was executed once and its complete JSON compared byte-for-byte equal to the work output. Only the three assigned numerical files were written.
