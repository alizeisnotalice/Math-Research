# 第486轮：自然Poisson配置提升与低捕获信息的几何谱收缩

日期2026-10-21。一般n^(1/2+o(1))一致弱型上界未闭合。本轮构造保配置而不改成独立产品参考的分析链，证明其中来源刷新对确定低捕获部分有维数无关谱收缩。未将一次随机低Gram成功族等同于整个Poisson候选场。

## 原合同与全局目标

μ=f dx、W=∥f∥₁，f任意非负L¹；m_A=μ(Q_A)=q_A R_A^n，a≤R_A≤b≤2a，q≤q_A≤λ，r=λ/q，σ=q_A dA，ν=tσ，0≤t≤S。R=ν(E)，X=σ(E)，m_-=qa^n>0，m_+=λb^n<∞。原不可跨质量带、接受记录、历史门及全部来源质量不变。零流单列。

当前目标仍为原完整剩余积分的εX+Cε√n log^A(n+2)W，并支付所有母账。宽距离、低pe、初始、跳跃、删除、未来被删及极小尺度比费用不因新分析链自动付款。第485轮指出配置来源相关在父投影时丢失，本轮不把该相关直接加到旧核能量里。

## 自然参考、最大父列与新分析链

给每个父保uniform mark，按质量再按mark全序。状态为(A,s,x,F)，其中x∼π_A，F是原质量带内增广序严格低于(A,s)、捕获x的全部raw PPP。记自然参考为
\[
 \mathsf M(dA,ds,dx,dF)=\nu(dA)ds\,\pi_A(dx)
 \operatorname{PPP}_{\Lambda_{A,s,x}}(dF),\qquad
 \mathsf M_\omega=m_A^{-1}\mathsf M.
\]
F为全部raw族而不是筛后子族。有限强度由ν(E)<∞及m_->0保证。记录按原条件律独立附加，成功时取原最大父B并留下其下方全部raw点，失败则停止，得到次Markov算子J。

几何附件通过最大点Palm分解和原中心CDF证明
\[
 \mathsf M J\le\mathsf M,\qquad
 \mathsf M_\omega J\le b_0\mathsf M_\omega,
 \quad b_0=2rS/T<1.
\]
保同质量marks及闭尾原子，不假来源密度帽。随后使用下文H，在新父保持mark，来源重采、交集留点、差集补点。H同时保持两种自然参考。定义新分析链\(\mathcal P=JH\)。它保原成功判据，但后续条件配置通常不是原K每步独立重抽的配置，所以不声称与原K父轨迹同律。

该新链的初始测度质量仍恰为原R。正支配给
\[
 \mathsf M\mathcal P^j\le\mathsf M,
 \qquad |\mathsf M\mathcal P^j|
 \le\frac{m_+}{m_-}b_0^j R\longrightarrow0.
\]
第一式和第二式分别来自普通与质量加权列，不能把质量比前因子删掉。因此所有停止完整相加为
\[
 R=\sum_{j\ge0}\mathsf M\mathcal P^j e^\sharp,
 \quad e^\sharp=1-\mathcal P1=1-J1.
\]
初始一次价\(\mathsf M e^\sharp\)等于原核一次失败价；累计价仍按真实新链到达量计，不能重复当成一次εX。旧K的窗内行界及第485轮永久pair路径费也不能直接转授新链。

下面给固定父、mark纤维上的完整谱证明，由主代理提出并与Sol独立推导整合。

## 1. 固定父与自然参考

固定父 \(B\)，令 \(\pi=\pi_B\) 为概率。候选空间 \(\mathcal E\) 为标准 Borel，\(\Lambda\) 为有限强度，捕获关系 \((x,C)\mapsto1_C(x)\) 可测，\(S_x=\{C:x\in C\}\)。允许 \(\Lambda\) 有原子及 \(\pi(C)=0\)。令潜在完整配置 \(\Xi\sim\operatorname{PPP}(\Lambda)\) 与 \(X\sim\pi\) 独立，实际观察状态为
\[
(X,F)=(X,\Xi|_{S_X}),
\quad M(dx,dF)=\pi(dx)\operatorname{PPP}(1_{S_x}\Lambda)(dF).
\]
给定 \((x,F)\)，补全独立 \(\operatorname{PPP}(1_{S_x^c}\Lambda)\)，再独立抽 \(Z\sim\pi\)，输出 \((Z,\Xi|_{S_Z})\)。即保留交集点，补上 \(S_Z\setminus S_x\) 的独立点。定义其 Markov 算子为 \(H\)。

在 ambient \(L^2(\pi\otimes\operatorname{PPP}\Lambda)\) 中，令 \(Q\) 为给定 \((X,\Xi|_{S_X})\) 的条件期望投影，\(A\) 为给定完整 \(\Xi\) 的条件期望投影（对来源平均）。状态空间嵌入为 \(\operatorname{Ran}Q\)。则
\[
H=QAQ\big|_{\operatorname{Ran}Q}=U^*U,
\qquad (Ug)(\Xi)=\int g(x,\Xi|_{S_x})\pi(dx). \tag{1}
\]
所以 \(H\) 自伴、非负、保持常数且 \(M\) 不变。这是自然相关参考，不是 \(\pi(dx)\lambda(dF)\) 产品参考。

## 2. 混沌公式及原子说明

采用补偿 Poisson 多重积分规范
\[
g(x,F)=\sum_{k\ge0} I_k(h_k(x;\cdot)),
\quad
\|g\|_M^2=\sum_{k\ge0}k!\int\pi(dx)\int|h_k(x;\mathbf C)|^2d\Lambda^k,
\]
其中对称核满足
\(h_k(x;\mathbf C)=0\) 除非 \(x\in C_1\cap\cdots\cap C_k\)。\(k=0\) 为来源函数 \(h_0(x)\)。公式(1)依次平均来源、再作观察条件期望，故
\[
\boxed{h'_k(z;\mathbf C)
=1_{z\in C_1\cap\cdots\cap C_k}
 \int_{C_1\cap\cdots\cap C_k}h_k(x;\mathbf C)\pi(dx).} \tag{2}
\]
对 \(k=0\)，这就是 \(h'_0=\int h_0d\pi\)。

固定元组，记 \(p_{\mathbf C}=\pi(\cap_i C_i)\)。其来源纤维上的算子为秩一，非零特征值恰为 \(p_{\mathbf C}\)：常数方向乘 \(p_{\mathbf C}\)，源积分为零的方向被消去。\(p=0\) 纤维无质量。原子强度下 \(\Lambda^k\) 的对角不能删除；同一个候选重复 \(k\) 次时，特征值仍是 \(\pi(C)\)，**不是** \(\pi(C)^k\)。多重积分须使用 factorial/Charlier 规范，而非把普通点计数乘积当成补偿混沌。

### 自含的完备性说明

有限强度下，对有界简单 \(f>-1\)，Poisson 指数向量
\[
\mathcal E_f(\Xi)=e^{-\int f d\Lambda}\prod_{C\in\Xi}(1+f(C))
\]
满足 \(\mathbb E\mathcal E_f\mathcal E_g=e^{\int fg d\Lambda}\)。对参数求导及极化定义 \(I_k\)，比较幂级数得到 \(k!\) 等距与不同阶正交。指数向量的线性包稠密：在任一有限可测分割上，独立 Poisson 计数的概率生成函数解析，若一个 \(L^2\) 函数与所有邻近零参数的指数向量正交，其各计数系数均为零；再以生成配置 σ-代数的有限分割条件期望逼近即可。乘来源简单函数给 ambient 稠密性。

独立增量直接给
\(\mathbb E[\mathcal E_f(\Xi)\mid x,\Xi|_{S_x}]=\mathcal E_{f1_{S_x}}(\Xi)\)。由稠密性及投影连续性，\(Q\) 在第 \(k\) 阶核上乘 \(\prod_i1_{C_i}(x)\)。这证明上述状态子空间、(2)及其一般有限强度延拓；不需要把 diffuse 公式未经检查地套到原子上。

## 3. 谱帽与必须保留的 high-only 部分

若对 \(\Lambda\)-几乎处处候选有 \(\pi(C)\le\theta\)，则对所有 \(k\ge1\)，\(p_{\mathbf C}\le\theta\)。由(2)，
\[
\|Hg\|_M\le\theta\|g\|_M
\quad\text{当 }\int g\,dM=0. \tag{3}
\]
事实上，零均值空间上的算子范数正是
\(\operatorname*{ess\,sup}_{C\sim\Lambda}\pi(C)\)，全空候选取0。上界如前；下界在一阶取 \(h_1(x;C)=1_C(x)f(C)\)，集中于捕获概率接近本质上确界的候选即可。这里本质上确界也可相对于 \(\pi(C)\Lambda(dC)\) 取，零捕获候选不影响结论。

一般前缀可能有高捕获候选。固定可测分类
\[
\mathcal L=\{C:\pi(C)\le\theta\},\quad
\mathcal H=\mathcal L^c.
\]
第 \(k\ge1\) 阶只要元组至少一个成员属于 \(\mathcal L\)，该纤维谱帽就是 \(\theta\)；全属 \(\mathcal H\) 的 high-only 部分只能保原上界1。两类子空间正交且被 \(H\) 保持。

还有一个可直接用于实际函数的表达。令 \(F_{\rm hi}=F|_{\mathcal H}\)。给定 \(X\)，high/low PPP 独立，故
\(g-\mathbb E[g\mid X,F_{\rm hi}]\) 正好是所有 low-touch 混沌的和。于是
\[
\boxed{\langle g,(I-H)g\rangle_M
\ge(1-\theta)\,\mathbb E_M\operatorname{Var}(g\mid X,F_{\rm hi})
 +\operatorname{Var}_\pi\bigl(\mathbb E[g\mid X]\bigr).} \tag{4}
\]
\(k=0\) 的非常数来源部分被 \(H\) 消去，故第二项的系数为1。其余 high-only 信用仍非负，但不提供统一谱隙。

对一次实际低 Gram 保留族及最大父 \(B\)，每个其他保留成员确有
\(\pi_B(C)=I_{BC}/m_B=\gamma_{BC}\sqrt{m_C/m_B}\le1/2\)。这只说明这些已实现点落在确定 low 类。随机选择、最大父条件与成功事件一般混合各阶及 high-only 分量；“实现中有很多 low 成员”不是(3)对全前缀成立的条件，也不直接下界(4)的条件方差。

本稿只核固定父自然核的谱结构，不移动原接受权、不刷新原历史，不把 \(H\) 的不变性视作完整停止收缩。一般费用还需对真实输入函数的 high-only 部分及原参考变化分别结算。一般谱论证独立于下述有限Charlier/PGF检查。


## 回到同一自然参考的累计能量

在整状态自然测度M上取伴随。J的行与列均≤1，因此J*为L²(M)收缩；H自伴。对非负v∈L²(M)令h=J*v，则
\[
 \|v\|_M^2-\|\mathcal P^*v\|_M^2
 =\|v\|_M^2-\|J^*v\|_M^2+\|h\|_M^2-\|Hh\|_M^2
 \ge\frac34\|h-\Pi_{\rm hi}h\|_M^2. \tag{8}
\]
这里Πhi是在每个固定父、mark下给定来源及高捕获配置的条件期望，低捕获阈值为1/2。它保全部high-only部分及父/来源零阶部分；不是删去这些状态。谱估计按父、mark非负积分，维数常数3/4不变。

由上述正列界，\((\mathcal P^*)^j1\le\min\{1,(m_+/m_-)b_0^j\}\)，故实际新链occupation密度
\(V^\sharp=\sum_{j\ge0}(\mathcal P^*)^j1\)
有界、属于L²，满足\(\mathcal P^*V^\sharp=V^\sharp-1\)。代入(8)给
\[
 \frac34\|J^*V^\sharp-\Pi_{\rm hi}J^*V^\sharp\|_M^2
 \le2\int V^\sharp dM-R. \tag{9}
\]
这是在同一合法参考中的实际低捕获信息耗散，避免第485轮把产品χ²误作免费信用的问题。然而(9)仍没有给出R或停止费的根阶上界：其右边是累计占用，high-only投影及一次费用的累计权尚需支付。不能只因成功族含许多低捕获点就断言左边控制固定比例的R或占用。

下一步须用实际成功门证明J*V^sharp的低捕获条件方差足以控制未付部分，同时给high-only部分及全部停止原因统一源价，或给带可求和余项的真实递推。此处保留原目标，没有以一个新的投影余项定义替代付款。

## 文献、技能与计算边界

使用64项工具D04的条件参考及绝对连续性核查、L03有理/区间证据分级。独立核查了Last–Penrose《Lectures on the Poisson Process》公开作者版第18章Theorem18.10（印刷页195、PDF页207）及其L²混沌展开说明：
https://stoch.math.kit.edu/img/Last/lastpenrose2017.pdf
该文献只支持Poisson展开背景，不证明本项目H谱界或一般上界；上文以指数向量及投影自行推导本轮接口，保原子及重复候选。未全文宣称读完该书，未复制或重新编译其PDF。

本机独立Python运行几何附件29项、参考费用附件54项、自然耦合991项、独立谱1350项，共2424项检查。750项是signature-pair系数核验，1350项也含矩阵元素，不是同数量独立模型。谱实验保重复候选：特征值是实际交集概率，不是单点概率的次数幂。Poisson PGF/Charlier恒等式与矩阵实现分别核验；Arb零残差含0仅相容，严格不等式须整球满足方向。

有限parent模型只用真实连续来源与cube几何，不认证Lebesgue接收场或原历史；一般谱证明与有限计算分开。最终独审与隔离/解压重放绑定文件。新增轮次说明及紧凑归档，详细LaTeX源随包，不编译PDF。实际额度扣费数据不可获得，不猜测成本比例。完整根阶目标保持未完成。
