# R486限定谱补充：真实source交集与Poisson chaos系数

原r486_numeric.py/json/md均保持冻结。本补充仅新增r486_spectral_numeric.py和本报告。实际运行1350项Fraction/SymPy检查，8个固定tuple，次数1/2/3；大量检查为source矩阵元素的加权对称性，不是1350个独立样本。不枚举Poisson计数、不作MC，也不从这些例子声称无限chaos的一般谱定理。

## 固定自然参考和实际几何

复用原R486的6个实际子区间及固定父B：f=1_{[−4,4]}，π_B均匀于[−2,2]。子中心(−6/5,−4/5,−1/5,1/5,4/5,6/5)，完整m=R=(1,3/2,2,1,3/2,2)。源signature按所有实际端点严格分割，candidate捕获概率依次

(1/4,3/8,1/2,1/4,3/8,9/20)。

只取T=1，ν_j=(j+1)/21，λ=(1/21,4/63,1/14,4/21,10/63,1/7)。这是自然参考的谱核验，不是原K/history，也不把选择后的law称为fresh。

## source rank-one部分

对tuple(C_j1,…,C_jk)，D为这些实际区间与B的共同source交集；重复candidate不重复缩小D。在source signature cells上以π_B(cell)为精确有理权，构造

H_D(i,j)=1_D(i)1_D(j)π_B(cell_j)。

代码独立核H_D²=p_D H_D、H_D1_D=p_D1_D、trace H_D=p_D，以及π_i H_ij=π_j H_ji。另用非恒定交错有理h核

〈h,H_Dh〉_π=(∫_D h dπ_B)²≥0。

这是显式outer-product算子，因此D非空时rank1，唯一非零特征p_D=π_B(D)；空交集为零算子。逐tuple核p_D≤每个参与candidate的p_C≤1/2。没有把不同coordinates捕获当独立。

| tuple（0起始编号） | chaos次数 | p_D / 唯一非零特征 |
|---|---:|---|
| (0) | 1 | 1/4 |
| (2) | 1 | 1/2 |
| (0,0) | 2 | 1/4 |
| (0,1) | 2 | 17/80 |
| (0,5) | 2 | 0（rank0） |
| (2,2,2) | 3 | 1/2 |
| (1,2,3) | 3 | 1/16 |
| (2,2,3) | 3 | 1/4 |

重复tuple(0,0)的特征是1/4，不是(1/4)²；(2,2,2)特征是1/2，不是1/8。它们检验atomic Poisson多阶部分，而非把同计数重复相乘后误称同阶chaos。

## 独立的共享计数/Charlier核验

为避免只镜像rank-one代码，另用两个独立的Poisson计算路径核计数系数。

第一条：对N~Pois(λ)，使用精确factorial moments E(N)_j=λ^j，或等价Touchard多项式，展开

C1=N−λ；
C2=N(N−1)−2λN+λ²；
C3=N(N−1)(N−2)−3λN(N−1)+3λ²N−λ³。

SymPy核它们均值0、不同阶正交、E C_k²=k!λ^k，k=1,2,3。

第二条：在自然保点耦合下，令a=1_C(X)、b=1_C(Z)。共享计数及两侧独立计数的联合PGF给

E[e^{-λas}(1+s)^F e^{-λbt}(1+t)^G |X,Z]=exp(λab st)。

代码从shared/old-only/new-only三个Poisson强度相加，逐4种a,b核指数恒等；再对s、t取1/2/3阶导数。所得交叉系数为同阶k!λ^k·ab，不同阶0，与第一条直接Poisson矩计算相同。

对多candidate tuple，独立坐标系数相乘。若candidate j重复n_j次，正确系数是∏ n_j!λ_j^{n_j}。于是取source系数h=1_D时，联合输入norm为p_D乘该系数，耦合inner product为p_D²乘该系数，其比恰p_D；8个tuple均精确Fraction核验，空D不作0/0除法。

例如(0,0)系数为2/441，输入norm1/882、耦合内积1/3528，比1/4；(2,2,2)系数3/1372，输入norm3/2744、耦合内积3/5488，比1/2。这些系数来自实际共享计数PGF，而非事先把谱值写进代码。

## 复现与范围

命令：

`/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python r486_spectral_numeric.py`

实际Python3.12.14、SymPy1.14.0。全部源概率、算子和chaos系数为有理/符号精确，不需区间求积或额外Arb计算。脚本自含，stdout输出固定摘要及8个tuple的精确证书，不写或依赖旧numeric文件。

主代理的一般H谱证明与chaos完备性不由8个tuple建立。本补充只核自然参考上的source operator与实际保点耦合的计数系数吻合；selected输入、原max-success核及history仍按原报告的范围限制。新增计数1350与主numeric的991分开，由主代理整合。归档新增仅这两个spectral文件，计算已停止。
