# R486：自然PPP参考下的保点source-refresh耦合

实际输入与范围在运行前已冻结。本次9配置（2/4/6个真实子cube×T=1/4,1,4）通过991项检查，其中750项是有限来源signature对的精确PGF系数检查，不是750个独立模型。没有Monte Carlo或计数尾截断。

结论范围：自然输入下给定Z的输出确为正确capture PPP，且条件于Z与X独立；对非自然选择输入，输出submeasure仍被自然参考支配，但归一条件law一般不是fresh。本证书不是原K构造，也不认证实际history/success。

## 1. 实际区间与完整质量

完整L1来源f=1_{[−4,4]}，W=8。固定父B中心0、R_B=m_B=4，π_B为[−2,2]上的均匀law。

子cube中心为−6/5,−4/5,−1/5,1/5,4/5,6/5，选择R=(1,3/2,2,1,3/2,2)，取前2/4/6。每个子cube完整位于f支撑内，完整m_j=R_j；不是仅算其与B重叠的质量。有限子type权ν_j=(j+1)/(N(N+1)/2)，λ_j=ν_j/(T m_j)>0。

所有π_B来源按父端点和实际子cube端点分成有理区间，signature在每个开段恒定，端点零测。p_j=π_B(C_j)、p_ij=π_B(C_i∩C_j)均由实际长度精确计算。例如第6子cube为[1/5,11/5]，p_5=9/20，不能误用m_5/m_B=1/2，因为它部分位于B外。

这里是有限子types与真实连续来源，未宣称ν_j为实际Lebesgue中心强度或父B与子cube满足原全部路径合同。

## 2. 自然参考law与保留/补点

自然输入为X~π_B，给定X后F_j独立Pois(λ_j 1_{C_j}(X))，Z~π_B独立。逐j令G_j：

- X、Z都在C_j时保留原F_j；
- Z在C_j但X不在时补独立Pois(λ_j)；
- Z不在时输出0。

给定X、Z，保留和补点的独立Poisson强度相加为

λ_j 1_{C_j}(X)1_{C_j}(Z)+λ_j[1−1_{C_j}(X)]1_{C_j}(Z)=λ_j1_{C_j}(Z)。

SymPy核4种0/1捕获组合的PGF，代码对全部source-signature对逐坐标核强度向量恒等。因此完整联合PGF为

E[∏s_j^{G_j}|X,Z]=exp{Σ_j λ_j1_{C_j}(Z)(s_j−1)}。

它不依X，且对j因子化。故G|Z是正确capture PPP，并与X在给定Z后独立。没有错误宣称未条件化G坐标独立：Z混合会引入covariance，实际核了坐标0、1的正混合covariance。

保留、补点、删除次数期望为

Eret=Σλ_jp_j²，Eadd=Edelete=Σλ_jp_j(1−p_j)，
Ein=Eout=Σλ_jp_j=Eret+Eadd。

一、二阶总计数矩由signature积分和p_ij矩阵两种精确Fraction表达式独立核；零输出概率为Σ_signature π_B(signature) exp(−Σ_capture λ_j)，用Arb严格计算。

| T=1 | Eout | Eret | Eadd |
|---|---|---|---|
| 2子cube | 1/4 | 1/12 | 1/6 |
| 4子cube | 1/4 | 7/80 | 13/80 |
| 6子cube | 17/70 | 223/2400 | 2519/16800 |

## 3. 一个实际选择输入：支配保留，conditional fresh丢失

使用同一自然输入上的选择d=1_{F_0≥1}≤1，未归一。设p0=π_B(C0)=1/4，q0=1−exp(−λ0)。选择总质量为p0 q0。

该实际选择经过同一耦合后的输出，在自然(Z,G)参考下RN精确为

Z∈C0时：p0·1_{G0≥1}；
Z不在C0时：p0 q0。

理由是：若旧X不在C0则F0必0，选择不发生；若X在C0且Z也在，原F0被保留，选择就是G0≥1；若Z不在，F0被丢弃，选择只留下旧输入概率q0。其他坐标在条件X、选择后仍按自然独立Poisson生成，故这不是只核某个计数的偶然不等式，而是完整输出subdensity表达式。

两支RN均≤p0≤1，因此未归一输出submeasure≤自然参考。代码核每个Z signature的selected总质量均为p0 q0；这说明Z本身在选择归一后仍为π_B，但**G|Z不fresh**。

Z∈C0时，归一selected的G0为零截断Poisson：其零概率0，而自然零概率exp(−λ0)>0；其均值为λ0/(1−exp(−λ0))>λ0。T1、N2时，该均值约1.17590882，而自然均值仅1/3。其他T、N同样严格核。

| T=1 | 自然全零输出概率近似 | 归一selected全零输出概率近似 |
|---|---:|---:|
| 2子cube | .816189725 | .691691813 |
| 4子cube | .800000796 | .611580847 |
| 6子cube | .794155779 | .575957255 |

selected全零subprobability也逐signature精确表达并核≤自然全零概率。一般“density≤1则Markov推前被参考推前支配”由主证明处理；此处只核一个完整具体选择，不把归一conditional law称为fresh。

## 4. 复现与误差

命令：

`/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python r486_numeric.py`

实际Python3.12.14、SymPy1.14.0、Arb256-bit，解释器和实际用时在JSON compute_index。完整源质量、signature概率、强度、矩和期望计数为Fraction精确值；PGF恒等为符号/有理检查；零点概率及选择normalizer为严格Arb球。无浮点网格、MC、solver或Poisson尾截断。

自然law、选后submeasure、选后归一law明确区分。没有把本耦合替换为原K，也没有几何high门/history成功主张。脚本自含并输出自身目录，stdout固定摘要。归档仅r486_numeric.py、r486_numeric.json、r486_numeric.md。计算已停止。
