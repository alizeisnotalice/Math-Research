# R486：保实际配置的收缩提升与产品参考改动费

保持 R483–485 的同一个实际成功父核 \(K\)、\(\nu=t\sigma\)、\(R=\nu(E)\)。本稿构造合法的配置提升，证明它在**实际相关参考**下收缩；若换成独立来源产品参考，则给出准确补偿项和正裁剪成本。没有证明完整根阶停止预算，也不把配置支持分离直接计为能量信用。

## 1. 实际输出分解及绝对连续的范围

记
\[
\Gamma(dA,dB,dF,dx)=\nu(dA)\mathcal Q(A;dB,dF,dx)
\]
为原成功 joint，保原接受条件。\(F\) 只记录实际中心、marks、raw/保留族及必要离散标签，不记录 \(x\) 本身或由 \(x\) 确定的精确连续统计；这些统计对应的门仍保留在 \(\Gamma\) 的权内。R482 的 Janossy 表示使此粗化输出对某个配置测度乘 \(\mu(dx)\) 绝对连续，且 \(x\in Q_B\)。故在正输出配置上，其条件来源律 \(q_{BF}\ll\pi_B\)。若保留任意额外连续历史作为条件标签，不能自动沿用这一产品 AC 结论。

令 \(a(B)=d(\nu K)/d\nu\in[0,1]\)。正规条件分解为
\[
\Gamma_{m out}(dB,dF,dx)
=a(B)\nu(dB)\lambda_B(dF)q_{BF}(dx).
\]
\(a=0\) 处条件核任取。定义两个不同参考
\[
N=\nu\lambda_Bq_{BF},\qquad
P=\nu\lambda_B\pi_B,
\quad r(B,F,x)=\frac{dq_{BF}}{d\pi_B}(x),\quad N=rP. \tag{1}
\]
两者总质量均为 \(R\)、父边缘均为 \(\nu\)，但只有 \(\Gamma_{m out}=aN\le N\) 自动成立。相对 \(P\) 的实际列密度是 \(ar\)，不是 \(a\)。

## 2. 自然参考下的真实算子及完整能量

对 \(v\in L^2(\nu)\)，以 \(Z=(B,F,x)\) 记输出，设
\[
q_v(Z)=\mathbb E_\Gamma[v(A)\mid Z],
\qquad (Tv)(Z)=a(B)q_v(Z).
\]
于是 \(Tv=d(\Gamma_v)_{\rm out}/dN\)，而
\[
\mathbb E_N[Tv\mid B]=K^*v(B). \tag{2}
\]
输入行质量是 \(K1\le1\)，输出列质量是 \(a\le1\)。条件 Jensen 给 \(\|Tv\|_{2,N}\le\|v\|_{2,\nu}\)。更精确地，令 \(e=1-K1\)，有
\[
\begin{aligned}
\mathcal D_N(v)&:=\|v\|_{2,\nu}^2-\|Tv\|_{2,N}^2\\
&=\int e v^2d\nu
 +\int\operatorname{Var}_\Gamma(v(A)\mid Z)d\Gamma_{\rm out}
 +\int(1-a)q_v^2d\Gamma_{\rm out}\ge0,\\
\|v\|_{2,\nu}^2-\|K^*v\|_{2,\nu}^2
&=\mathcal D_N(v)
 +\int|Tv-K^*v(B)|^2dN. \tag{3}
\end{aligned}
\]
这保留了实际配置，但 \(N\) 的来源条件本来就是 \(q_{BF}\)，已经携带共同核心相关；低 Gram 给出的 \(q_{BF}\) 相对 \(\pi_B\) 分离，不是(3)中关于 \(N\) 的方差下界。

一个真正保原父过程的提升如下：在状态 \((A,F_{\rm old},x_{\rm old})\) 上，下一步忽略附加的旧 \(F,x\)，按当前 \(A\) 重新抽原记录、\(\pi_A\) 来源及mark，并运行同一 \(\mathcal Q\)。这样
\(N\widehat K=aN\le N\)，父投影始终为原 \(K\)。若改为直接使用到达来源 \(q_{AF}\) 运行下一步，就改变了原 \(K\)，本稿不作此替换。

初始可在原父 \(\nu\) 上附加 \(\lambda_Aq_{AF}\) 作为分析标签；这不是给原初始记录新增历史。若 \(V=(I-K^*)^{-1}1\)，提升的 occupation 密度为
\[
\widehat V=1+TV,\qquad
\mathbb E_N[\widehat V\mid B]=V,
\qquad\int e(B)\widehat VdN=R. \tag{4}
\]
终端和初始质量完全保留。相应总能量仍为
\(2\int Vd\nu-R\)，没有因附加配置多出一份可支付预算。

## 3. 换为独立来源参考时，信用必须减去改参考费用

产品参考下同一实际输出密度是
\[
H_v=rTv,\qquad \mathbb E_P[H_v\mid B]=K^*v(B)=:h_v(B).
\]
\(T_P:v\mapsto H_v\) 的行仍是原 \(K1\)，列却为 \(ar\)，一般不受1支配。始终合法的加权方差是
\[
\|v\|_\nu^2-\|h_v\|_\nu^2
=\mathcal D_N(v)+
 \int_{r>0}\frac{|H_v-rh_v|^2}{r}\,dP. \tag{5}
\]
\(r=0\) 处 \(H_v=0\)，该项取0；(5)各项有限，不作 \(\infty-\infty\)。

如果另有 \(H_v\in L^2(P)\)，才可写成普通产品方差减补偿费：
\[
\boxed{\|v\|_\nu^2-\|h_v\|_\nu^2
=\mathcal D_N(v)+\int|H_v-h_v|^2dP-\mathcal C_{\rm ref}(v),}
\]
\[
\mathcal C_{\rm ref}(v)=\int(r-1)|Tv|^2dN. \tag{6}
\]
该费用对一般 \(v\) 不必非负，不能按有利符号删除。其绝对可积性由上述两平方范数保证；没有该假设时只用(5)。

一个决定性的核验是 \(v=1\)：此时 \(T1=a\)、\(h_1=a\)，因此在有限情形
\[
\int|H_1-h_1|^2dP
=\int a(B)^2\chi^2(q_{BF}\Vert\pi_B)\,\nu(dB)\lambda_B(dF)
=\mathcal C_{\rm ref}(1). \tag{7}
\]
几何联合 \(\chi^2\) 无论多大，都被这次改参考费用**精确抵消**。这不是反例搜索，而是同一实际核对常数输入的必要一致性检查；它不排除对真正 \(V\) 另有可付的联合比较。

## 4. 如强制产品列帽，删除费用是多少

对给定非负输入 \(v\)，要在同一 \(P\) 上取得列帽 \(C>0\)，可在原完整 \(v\Gamma\) 记录上乘
\(\min\{1,C/H_v(Z)\}\)，零密度处任取1。最大保留输出为 \(\min(H_v,C)P\)，精确损失
\[
\Delta_C(v)=\int(H_v-C)_+dP. \tag{8}
\]
这是保历史的正限制，不是来源刷新；任何由原流正删除得到的列帽计划都至少损失(8)。

若配置来源支持共同核心 \(E_F\subset Q_B\)，记 \(p_F=\pi_B(E_F)\)，并令
\(\bar v_{BF}=\mathbb E_\Gamma[v(A)\mid B,F]\)。固定 \((B,F)\) 先积分来源，即得
\[
\Delta_C(v)\ge
 \int\bigl(a(B)\bar v_{BF}-Cp_F\bigr)_+
 \,\nu(dB)\lambda_B(dF). \tag{9}
\]
对于 \(v=1\)，这是 \(\int(a-Cp_F)_+\nu\lambda\)。低 Gram 可给 \(p_F\le[2(l-1)]^{-1}\)，但它在(9)中说明产品参考可容纳的质量小，不会自动使损失小。用于累计预算时必须取 \(v=V\)，不能用一次 \(\Delta_C(1)\) 代替 \(\Delta_C(V)\)。本稿没有给这些损失或(6)的实际 occupation 补偿费一个根阶来源价。

## 5. 与本轮自然 Palm 参考的接口

Astra 独立研究的更自然候选为
\(N_{\rm Palm}=\nu(dB)\pi_B(dx)\operatorname{PPP}_{<B,x}(dF)\)：它保来源与下方配置的相关，而不使用 \(\lambda_B\pi_B\)。本稿不重复其最大点分解证明。若其实际列支配成立，可以用该相关参考替代本稿 \(N\) 构造收缩提升；仍须按该参考的密度计算几何信用，不能把相对 \(\pi_B\) 的配置条件 \(\chi^2\) 免费移入。

本稿的可核结论是(3)—(9)这一带费提升及准确停止账。当前最窄未证桥是：在同一实际累计输入 \(V\) 下，保留配置的相关参考能否产生足够耗散，同时以一次来源预算控制改参考或重置来源的费用。只保配置标签、总方差或核心支持大小尚未做到这一点。到此停止，不改变原母账。

## 6. 实际有理核验

指定本机 Python 实跑下列脚本，输出：

```text
PASS 54 exact Fraction assertions: natural lift, reference-change compensation, unit-density cancellation and clipped-column cost; finite measure model only.
```

三种来源相关程度、两种输出强度、常数与非恒定输入，含零来源密度。它核参考转换的符号、自然缺陷分解、常数输入取消及裁剪成本，不模拟原立方体完整历史。

```python
from fractions import Fraction as F
checks=0
for q in [F(1,2),F(3,4),F(1)]:
    for a in [F(1,4),F(3,4)]:
        cells=[]
        for j in range(2):
            for x in range(2):
                qx=q if j==x else 1-q
                N=qx/2; P=F(1,4); r=2*qx
                p=F(1,4) if j==x else F(3,4)
                cells.append((N,P,r,p))
        for vals in [[F(1),F(1)],[F(1),F(3)]]:
            Ts=[a*(p*vals[0]+(1-p)*vals[1]) for N,P,r,p in cells]
            h=sum(N*T for (N,P,r,p),T in zip(cells,Ts))
            norm=sum(v*v for v in vals)
            nn=sum(N*T*T for (N,P,r,p),T in zip(cells,Ts))
            ref=sum(N*(r-1)*T*T for (N,P,r,p),T in zip(cells,Ts))
            pv=sum(P*(r*T-h)**2 for (N,P,r,p),T in zip(cells,Ts))
            assert norm-h*h==norm-nn+pv-ref; checks+=1
            rows=[sum(a*N*(p if j==0 else 1-p)
                      for N,P,r,p in cells) for j in range(2)]
            kill=sum((1-rows[j])*vals[j]**2 for j in range(2))
            rev=sum(a*N*p*(1-p)*(vals[0]-vals[1])**2
                    for N,P,r,p in cells)
            slack=sum(a*N*(1-a)*(T/a)**2
                      for (N,P,r,p),T in zip(cells,Ts))
            assert norm-nn==kill+rev+slack; checks+=1
            assert norm-nn>=0; checks+=1
            if vals==[F(1),F(1)]:
                assert pv==ref; checks+=1
        loss=sum(P*max(F(0),a*r-1) for N,P,r,p in cells)
        keep=sum(P*min(a*r,F(1)) for N,P,r,p in cells)
        assert keep+loss==a; checks+=1
        core=F(1,2) if q==1 else F(1)
        assert loss>=max(F(0),a-core); checks+=1
print(f'PASS {checks} exact Fraction assertions: natural lift, reference-change compensation, unit-density cancellation and clipped-column cost; finite measure model only.')
```
