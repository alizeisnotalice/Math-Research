# R486：实际最大父输出的自然 Palm 配置参考

本附件证明整份低秩 raw 配置的输出列支配，以及一次保自然参考的来源耦合。它不把成功条件下的配置重新称为独立 Poisson，也不把下述分析耦合认作 R483 原父刷新核的同律实现。一般无权停止量的根阶来源预算仍未证明。

## 1. 原输入、标记与参考测度

沿原合同，\(\mu=f\,dx\)，\(m_A=\mu(Q_A)=q_AR_A^n\)，\(q\le q_A\le\lambda\)，\(r=\lambda/q\)，\(\sigma=q_A\,dA\)。原接受父边缘为
\[
\nu(dA)=t(A)\sigma(dA),\qquad 0\le t\le S,
\qquad \pi_A(dx)=c_A(x)\mu(dx)/m_A.
\]
在每个原质量带内给父附独立均匀标记，按质量再按标记排序，记增广父为 \(\widehat A=(A,s_A)\)。所有公式都保留同带限制。设
\[
\rho_x(d\widehat A)=c_A(x)\nu(dA)ds_A/m_A,
\quad v_x(\widehat A)=\rho_x\{\widehat C\prec\widehat A\},
\quad U(x)=\rho_x(\text{该带}).
\tag{1}
\]
质量原子由均匀标记展开，因此 \(v_x\) 将 \(\rho_x\) 推为 \([0,U(x)]\) 上 Lebesgue 测度。零行无贡献。

原输入先抽原条件记录，再抽 \(x\sim\pi_A\) 与标记；raw 父过程强度是 \(T^{-1}1_{\widehat C\prec\widehat A}\rho_x(d\widehat C)\)。成功判据、旧两来源、长边、全 raw no-hit、低 Gram 等均按原定义。它们只在下面正上界中删除。

对输出最大父 \(\widehat B\)，记 \(F\) 为其下方的**全部 raw 点**，不是筛选后的 \(F_0\)。定义
\[
\mathsf M(d\widehat B,dx,dF)
=\nu(dB)ds_B\,\pi_B(dx)\,
 \operatorname{PPP}_{\Lambda_{B,x}}(dF),
\quad
\Lambda_{B,x}(d\widehat C)
=T^{-1}1_{\widehat C\prec\widehat B}\rho_x(d\widehat C).
\tag{2}
\]
这是相关配置参考：其 \((B,x)\) 边缘为 \(\nu\pi_B\)，但给定配置后的来源通常集中在共同核心，不是 \(\pi_B\)。

## 2. 整配置 Palm 输出列：普通与质量加权版本

固定 \(A,x\)，最大点 \(B\) 的增广秩为 \(w<v=v_x(\widehat A)\)。有限 Poisson 展开按最大点分解：区间 \((w,v)\) 无点，\([0,w)\) 上独立保留全部 Poisson 点。因此 raw 联合测度为
\[
\mu(dx)\rho_x(d\widehat A)
 \frac{\rho_x(d\widehat B)}T
 e^{-(v-w)/T}\,
 \operatorname{PPP}_{\Lambda_{B,x}}(dF).
\tag{3}
\]
这也可直接由 Janossy 的 \(j!\) 置换对称性指定最大点后求和得到；有限强度下全是非负级数，交换积分无需成功条件下的独立性假设。

对原父积分，\(T^{-1}\int_w^{U(x)}e^{-(v-w)/T}dv=1-e^{-(U(x)-w)/T}\)。故 raw 输出对 (2) 的密度精确为该因子，实际成功输出 \(\Gamma\) 满足
\[
\boxed{\Gamma\le\mathsf M.}\tag{4}
\]
旧父、旧记录与所有成功标签可按实际正规条件分布附回；(4) 本身是投影列界，不宣称这些标签在参考中独立，也不给输出父旧历史资格。

再令输入父测度为 \(\omega=\nu/m\)，但每父仍运行同一原实验。令 \(\mathsf M_\omega\) 为 (2) 将 \(\nu(dB)\) 改成 \(\omega(dB)\) 的参考。相对该参考，raw 列密度精确为
\[
d_\omega(\widehat B,x)
=\frac{m_B}{T}\int_{\widehat A\succ\widehat B}
 \frac{e^{-(v_x(\widehat A)-w)/T}}{m_A}\rho_x(d\widehat A).
\tag{5}
\]
真实中心质量 CDF 满足
\[
G_x(M):=\int_{m_A\le M}t(A)c_A(x)\sigma(dA)\le rSM.
\]
于是闭尾（包含 \(m_A=m_B\)）为
\[
\int_{[m_B,\infty)}u^{-2}dG_x(u)
=-\frac{G_x(m_B-)}{m_B^2}
 +2\int_{m_B}^{\infty}\frac{G_x(u)}{u^3}du
\le\frac{2rS}{m_B}.
\]
删掉 (5) 的 void 因子、同带及标记限制只增加积分，得到
\[
\boxed{\Gamma_\omega\le\frac{2rS}{T}\mathsf M_\omega.}\tag{6}
\]
该证明没有将同质量的增广次序改为严格质量下降，没有漏掉质量原子；也没有用来源密度上帽。

## 3. 一次交集留点、差集补点的合法性

固定 \(\widehat B\)，写
\[
\Lambda_B(d\widehat C)=1_{\widehat C\prec\widehat B}
 \nu(dC)ds_C/(Tm_C),\qquad \Lambda_{B,x}=c_C(x)\Lambda_B.
\]
该强度有限。定义 Markov 更新 \(\mathcal H_B\)：保当前 \((x,F)\)，抽 \(z\sim\pi_B\)，保留 \(F\) 中捕获 \(z\) 的点，另独立补强度
\[
1_{c_C(z)=1,\ c_C(x)=0}\Lambda_B(d\widehat C)
\]
的 Poisson 点，输出 \((z,F')\)。

若输入恰为 \(\pi_B(dx)\operatorname{PPP}_{\Lambda_{B,x}}(dF)\)，给定预先抽定的 \(x,z\)，旧过程的交集部分与旧独占部分独立；交集部分和新补点之和恰为 \(\operatorname{PPP}_{\Lambda_{B,z}}\)。所以
\[
\mathsf M\mathcal H=\mathsf M,
\qquad \mathsf M_\omega\mathcal H=\mathsf M_\omega.
\tag{7}
\]
等价构造是先条件补全一个强度 \(\Lambda_B\) 的 master Poisson，再按新来源限制；这里的 master 只解释参考的一次更新。

对实际成功输入只能推出
\[
\Gamma\mathcal H\le\mathsf M,
\qquad \Gamma_\omega\mathcal H\le(2rS/T)\mathsf M_\omega.
\tag{8}
\]
给定完整旧配置或成功历史，留下的共同点已确定，通常不再是新独立 PPP。故 (7)—(8) 允许一个保配置的**替代分析过程**，但没有证明它与原 \(K\) 的父轨迹同律。旧标签可以保存为辅助状态；新来源、新配置不继承其历史门。

对于实际成功的 \(F_0\) 与最大质量父 \(B\)，原低 Gram 行界仍逐配置给出
\[
\mathbb E_{z\sim\pi_B}
\#\{C\in F_0\setminus\{B\}:z\in Q_C\}
=\sum_C\gamma_{BC}\sqrt{m_C/m_B}\le\tfrac12.
\tag{9}
\]
这控制一次刷新后留存的原已筛父数，**没有**控制新补点数、重新成功概率或累计停止费。自然参考本身包含核心相关性，因此不能再把相对独立 \(\pi_B\) 的配置 \(\chi^2\) 全额视为 (8) 的耗散。仍缺的是保自然参考的分析过程与原无权停止费用之间的有价比较；原质量共轭 Green 的 \(m\) 与 \(e/m\) 配对也没有因此消失。

## 4. 实际本机有限核验与范围

下列代码在指定本机 Python 实际运行：输出为
`PGF identities: 2 PASS; atom-inclusive CDF/Palm cap checks: 27 PASS`。
前两项是交集/差集 Poisson 的联合生成函数代数；其余是四个有限质量 CDF（含阈值原子）在三个 \(T\) 下的闭尾与加权列帽算术。它们不是完整原生成功历史实例，一般结论由上面证明给出。

```python
from fractions import Fraction as F
import sympy as s
c,d,e,u,v=s.symbols('c d e u v', nonnegative=True)
old_joint=s.exp(c*(u*v-1)+d*(u-1)+e*(v-1))
assert s.simplify(old_joint.subs(u,1)-s.exp((c+e)*(v-1)))==0
assert s.simplify(old_joint-old_joint.xreplace({d:e,e:d,u:v,v:u}))==0
profiles=[[(1,F(1))],[(1,F(1,2)),(2,F(3,2))],
          [(1,F(1)),(2,F(1)),(4,F(2))],
          [(1,F(1,3)),(3,F(2)),(7,F(4))]]
checks=0
for ps in profiles:
    cumulative=F(0)
    for m,a in ps:
        cumulative+=a
        assert cumulative<=m
    for m,_ in ps:
        tail=sum((a/F(t*t) for t,a in ps if t>=m),F(0))
        assert tail<=F(2,m)
        for T in [F(1,2),F(1),F(7)]:
            assert F(m,1)*tail/T<=2/T
            checks+=1
print('PGF identities: 2 PASS; atom-inclusive CDF/Palm cap checks:',checks,'PASS')
```
