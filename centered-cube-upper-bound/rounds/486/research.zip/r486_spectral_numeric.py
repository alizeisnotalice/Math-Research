from fractions import Fraction as F
from pathlib import Path
from math import factorial
from collections import Counter
import sys,platform,json
import sympy as sp
from sympy.functions.combinatorial.numbers import stirling
checks=0

def ck(v):
 global checks
 assert v
 checks+=1

def matmul(A,B):return [[sum(A[i][k]*B[k][j] for k in range(len(B))) for j in range(len(B[0]))] for i in range(len(A))]
# Independent Poisson moment and shared-count PGF calculations.
n,lam,s,t=sp.symbols('n lam s t',positive=True)
def EP(poly):
 p=sp.Poly(sp.expand(poly),n)
 return sp.expand(sum(coef*sum(stirling(power[0],j,kind=2)*lam**j for j in range(power[0]+1)) for power,coef in p.terms()))
char={k:sp.expand(sum(sp.binomial(k,j)*(-lam)**(k-j)*sp.ff(n,j) for j in range(k+1))) for k in (1,2,3)}
for k in (1,2,3):
 ck(EP(char[k])==0);ck(sp.simplify(EP(char[k]**2)-sp.factorial(k)*lam**k)==0)
 for j in (1,2,3):
  expected=sp.factorial(k)*lam**k if j==k else 0
  ck(sp.simplify(EP(char[k]*char[j])-expected)==0)
  pgfcoef=sp.diff(sp.exp(lam*s*t),s,k,t,j).subs({s:0,t:0})
  ck(pgfcoef==expected)
for a in (0,1):
 for b in (0,1):
  exponent=lam*a*b*((1+s)*(1+t)-1)+lam*a*(1-b)*s+lam*(1-a)*b*t-lam*a*s-lam*b*t
  ck(sp.expand(exponent-lam*a*b*s*t)==0)

cent=list(map(F,[F(-6,5),F(-4,5),F(-1,5),F(1,5),F(4,5),F(6,5)]));mass=list(map(F,[1,F(3,2),2,1,F(3,2),2]))
intervals=[(cent[i]-mass[i]/2,cent[i]+mass[i]/2) for i in range(6)]
for lo,hi in intervals:ck(-4<=lo<hi<=4)
endpoints=sorted(set([F(-2),F(2)]+[max(F(-2),min(F(2),z)) for pair in intervals for z in pair]))
cells=[]
for lo,hi in zip(endpoints,endpoints[1:]):
 mid=(lo+hi)/2;cells.append(dict(interval=[lo,hi],prob=(hi-lo)/4,sig=[int(a<mid<b) for a,b in intervals]))
probs=[c['prob'] for c in cells];N=len(cells);ck(sum(probs)==1)
pchild=[sum(c['prob']*c['sig'][j] for c in cells) for j in range(6)]
for p in pchild:ck(0<p<=F(1,2))
rate=[F(j+1,21)/mass[j] for j in range(6)] # T=1
rows=[]
for tup in [(0,),(2,),(0,0),(0,1),(0,5),(2,2,2),(1,2,3),(2,2,3)]:
 d=[int(all(c['sig'][j] for j in tup)) for c in cells];pD=sum(probs[i]*d[i] for i in range(N))
 H=[[F(d[i]*d[j])*probs[j] for j in range(N)] for i in range(N)]
 HH=matmul(H,H);ck(HH==[[pD*z for z in row] for row in H])
 for i in range(N):
  ck(sum(H[i][j]*d[j] for j in range(N))==pD*d[i])
  for j in range(N):ck(probs[i]*H[i][j]==probs[j]*H[j][i])
 ck(sum(H[i][i] for i in range(N))==pD)
 ck(pD<=min(pchild[j] for j in tup));ck(pD<=F(1,2))
 h=[F((-1)**i*(i+1)) for i in range(N)]
 quad=sum(probs[i]*h[i]*sum(H[i][j]*h[j] for j in range(N)) for i in range(N));scalar=sum(probs[i]*d[i]*h[i] for i in range(N))
 ck(quad==scalar**2)
 counts=Counter(tup);norm=F(1)
 for j,order in counts.items():
  factor=F(factorial(order))*rate[j]**order
  direct=EP(char[order]**2).subs(lam,sp.Rational(rate[j].numerator,rate[j].denominator))
  ck(direct==sp.Rational(factor.numerator,factor.denominator));norm*=factor
 input_norm=pD*norm;shared_cov=pD*pD*norm
 if pD:ck(shared_cov/input_norm==pD)
 else:ck(input_norm==shared_cov==0)
 rows.append(dict(tuple=list(tup),chaos_orders={str(j):order for j,order in counts.items()},p_D=str(pD),source_operator_rank=0 if pD==0 else 1,nonzero_eigenvalue=None if pD==0 else str(pD),counts_chaos_norm_factor=str(norm),joint_input_norm_for_h1D=str(input_norm),coupled_chaos_inner_product_for_h1D=str(shared_cov),ratio=None if pD==0 else str(shared_cov/input_norm),D_source_intervals=[[str(z) for z in cells[i]['interval']] for i in range(N) if d[i]],scope='Natural-reference conditional Poisson chaos, not selected-input or original K/history'))
print('PASS',checks,'exact Fraction/SymPy checks;8 tuples of orders1/2/3 on frozen R486 six-cube geometry; no infinite-chaos/history claim')
print(json.dumps(dict(executable=sys.executable,python=platform.python_version(),sympy=sp.__version__,candidate_capture_probabilities=list(map(str,pchild)),T='1',lambda_rates=list(map(str,rate)),tuples=rows),indent=2))
