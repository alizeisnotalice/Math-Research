from fractions import Fraction as F
from pathlib import Path
import sys,platform,json,time
import sympy as sp
from flint import arb,ctx
ROOT=Path(__file__).resolve().parent;ctx.prec=256
start=time.perf_counter();checks=0

def ck(v):
 global checks
 assert v
 checks+=1

def ar(v):
 v=F(v);return arb(v.numerator)/v.denominator
# Exact conditional PGF, including degenerate capture indicators.
q,lam=sp.symbols('q lam',positive=True)
for a in (0,1):
 for b in (0,1):
  ck(sp.simplify(sp.exp(lam*a*b*(q-1))*sp.exp(lam*(1-a)*b*(q-1))-sp.exp(lam*b*(q-1)))==0)
  ck(sp.diff(sp.exp(lam*b*(q-1)),q).subs(q,1)==lam*b)
# Selected F0>=1: weighted Poisson PGF subtracts the zero atom.
ck(sp.diff(sp.exp(lam*(q-1))-sp.exp(-lam),q).subs(q,1)==lam)
ck((sp.exp(lam*(q-1))-sp.exp(-lam)).subs(q,1)==1-sp.exp(-lam))
cent=list(map(F,[F(-6,5),F(-4,5),F(-1,5),F(1,5),F(4,5),F(6,5)]));mass=list(map(F,[1,F(3,2),2,1,F(3,2),2]))
intervals=[(cent[j]-mass[j]/2,cent[j]+mass[j]/2) for j in range(6)]
for lo,hi in intervals:ck(-4<=lo<hi<=4)
models=[];cases=[]
for N in (2,4,6):
 nu=[F(j+1,N*(N+1)//2) for j in range(N)]
 endpoints=sorted(set([F(-2),F(2)]+[max(F(-2),min(F(2),x)) for pair in intervals[:N] for x in pair]))
 cells=[]
 for lo,hi in zip(endpoints,endpoints[1:]):
  mid=(lo+hi)/2;sig=[int(intervals[j][0]<mid<intervals[j][1]) for j in range(N)]
  cells.append(dict(lo=lo,hi=hi,prob=(hi-lo)/4,sig=sig))
 ck(sum(c['prob'] for c in cells)==1)
 p=[sum(c['prob']*c['sig'][j] for c in cells) for j in range(N)]
 pij=[[sum(c['prob']*c['sig'][i]*c['sig'][j] for c in cells) for j in range(N)] for i in range(N)]
 for j in range(N):
  overlap=max(F(0),min(F(2),intervals[j][1])-max(F(-2),intervals[j][0]));ck(p[j]==overlap/4)
  ck(pij[j][j]==p[j]);ck(0<p[j]<1)
 models.append(dict(N=N,nu=list(map(str,nu)),children=[dict(center=str(cent[j]),R_and_complete_mass=str(mass[j]),source_interval=list(map(str,intervals[j])),parent_capture_probability=str(p[j])) for j in range(N)],source_signature_cells=[dict(interval=[str(c['lo']),str(c['hi'])],probability=str(c['prob']),signature=c['sig']) for c in cells]))
 for tt in (F(1,4),F(1),F(4)):
  rate=[nu[j]/(tt*mass[j]) for j in range(N)]
  # Conditional independent-Poisson rates: exact vector identity for every
  # source pair, stronger than checking finitely many count outcomes.
  pairchecks=0
  for cx in cells:
   for cz in cells:
    retain=[rate[j]*cx['sig'][j]*cz['sig'][j] for j in range(N)]
    births=[rate[j]*(1-cx['sig'][j])*cz['sig'][j] for j in range(N)]
    ck([retain[j]+births[j] for j in range(N)]==[rate[j]*cz['sig'][j] for j in range(N)]);pairchecks+=1
  expectedin=sum(rate[j]*p[j] for j in range(N))
  kept=sum(rate[j]*p[j]**2 for j in range(N))
  new=sum(rate[j]*p[j]*(1-p[j]) for j in range(N));deleted=new
  ck(kept+new==expectedin);ck(kept+deleted==expectedin)
  second=expectedin+sum(rate[i]*rate[j]*pij[i][j] for i in range(N) for j in range(N))
  secondsig=sum(c['prob']*(sum(rate[j]*c['sig'][j] for j in range(N))**2+sum(rate[j]*c['sig'][j] for j in range(N))) for c in cells)
  ck(second==secondsig)
  zero=sum((ar(c['prob'])*(-ar(sum(rate[j]*c['sig'][j] for j in range(N)))).exp() for c in cells),arb(0));ck(0<zero<1)
  # The joint law is independent of X given Z, not an unconditional
  # independent Poisson vector: source signatures produce mixture covariance.
  covariance=rate[0]*rate[1]*(pij[0][1]-p[0]*p[1]);ck(covariance>0)
  # Actual selection event S={old F0>=1} of density1_S <=1.
  p0=p[0];q0=1-(-ar(rate[0])).exp();eventmass=ar(p0)*q0;ck(0<eventmass<1)
  density_inside=ar(p0);density_outside=ar(p0)*q0
  ck(density_inside<1);ck(density_outside<1)
  selzero=eventmass*sum((ar(c['prob'])*(-ar(sum(rate[j]*c['sig'][j] for j in range(N)))).exp() for c in cells if not c['sig'][0]),arb(0))
  ck(selzero<zero);ck(selzero/eventmass<zero)
  truncated_mean=ar(rate[0])/q0;ck(truncated_mean>ar(rate[0]))
  output_selected_mean0=ar(p0*p0*rate[0]);ck(output_selected_mean0<ar(p0*rate[0]))
  # Every Z cell has selected mass equal to Pr(S); this verifies Z itself
  # remains fresh despite the retained G0 becoming truncated inside C0.
  for c in cells:
   massatZ=ar(p0)*q0 if c['sig'][0] else density_outside
   ck((massatZ-eventmass).is_finite() and (massatZ-eventmass).contains(0))
  cases.append(dict(N=N,T=str(tt),phase='initial' if N==2 else ('four_cube_selection_pressure' if N==4 else 'six_cube_expanded'),lambda_rates=list(map(str,rate)),source_signature_pair_PGF_checks=pairchecks,input_expected_count=str(expectedin),output_expected_count=str(expectedin),expected_retained_count=str(kept),expected_added_count=str(new),expected_deleted_count=str(deleted),output_count_second_moment=str(second),coordinate01_unconditional_covariance=str(covariance),unconditional_zero_output_probability=str(zero),selection_event='old F0>=1',selection_submass=str(eventmass),selected_output_RN_inside_C0='p0*1_(G0>=1)',selected_output_RN_outside_C0='p0*(1-exp(-lambda0))',p0=str(p0),subdensity_max=str(density_inside),selected_zero_output_subprobability=str(selzero),selected_conditional_zero_output_probability=str(selzero/eventmass),natural_zero_G0_given_Z_inside_C0=str((-ar(rate[0])).exp()),selected_zero_G0_given_Z_inside_C0='0',selected_conditional_mean_G0_given_Z_inside_C0=str(truncated_mean),natural_mean_G0_given_Z_inside_C0=str(rate[0]),selected_submeasure_mean_G0=str(output_selected_mean0),Z_marginal_after_conditioning_selection='pi_B unchanged',scope='Natural-reference preserve/add coupling and density<=1 selection only; not original K/history'))
result=dict(scope='Actual interval source geometry with a finite list of child types and natural conditional PPP counts. No claim about original K or success/history.',compute_index=dict(executable=sys.executable,python=platform.python_version(),sympy=sp.__version__,arb_precision_bits=ctx.prec,command='"'+sys.executable+'" r486_numeric.py',seconds=time.perf_counter()-start),checks=checks,geometry=dict(f='1_[-4,4]',W='8',B_center='0',B_side_and_complete_mass='4',pi_B='uniform[-2,2]',models=models),formula=dict(natural_conditional_PGF='E[prod s_j^G_j|X,Z]=exp(sum lambda_j*1_Cj(Z)*(s_j-1)), independent of X',selected_pushforward_RN='p0*1_G0>=1 if Z in C0; p0*(1-exp(-lambda0)) otherwise',selection_mass='p0*(1-exp(-lambda0))',retained_count='sum lambda_j*p_j^2',added_count='sum lambda_j*p_j*(1-p_j)',target_domination='selected output submeasure <= natural output reference; no normalization by selection probability',nonfresh_after_selection='Z in C0 => G0 is zero-truncated Poisson(lambda0)'),cases=cases,exactness='Full child mass from actual continuous L1 f, exact source signature probabilities and Poisson moments Fraction; conditional joint PGF identities symbolic; zero probabilities/selected normalizers256-bit Arb. No count truncation or Monte Carlo.')
(ROOT/'r486_numeric.json').write_text(json.dumps(result,indent=2)+'\n')
print('PASS',checks,'checks;9 actual interval PPP couplings and selected-submeasure certificates; no original K/history claim')
