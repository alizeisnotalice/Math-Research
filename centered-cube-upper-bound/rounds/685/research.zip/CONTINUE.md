# R685 continuation — no new uniform upper bound in this bounded attempt

Original arbitrary-L1/all-scales/Lebesgue C_n<=K sqrt(n) remains unproved. Current correct actual-receiver normalization and full fees remain exactly R684. Old fixed high-moment G_rich is false; never resume that target. H_rich<=CU or direct originalV/packing payment still open.

## What this round decided

Source-restricted transport on O(x)=actualcore_b intersect outsideparents is SUFFICIENT for V<=CU but stronger than the scalar bound, and stronger still than allowing all original P0 variables. Exact Hall cuts are E_A={x:O(x)subsetA}; need |E_A|<=Cmu(A) for everyA, not onlyA=all. Do not call this an equivalent replacement for the original problem without a hereditary theorem.

Thinning sources toA and receivers toE_A DOES preserve the original disjoint owner geometry, common witnesses, scale windows, admission upper bounds and actual outside rate. It need NOT regenerate the original greedy q/history. R684normalizedJ and R683low/cone are hereditary on these cuts without regeneratingq: (1-alpha)|E_A|<=H_rich(E_A,A)+e_nmu(A). The missing term is still the actual joint rich cost, not a new paid fee.

Same-receiver iid2 proposals p_i=qi/W: exact forced-cut mass Q2(A)=integral p_A(x)^2. C2=max_A Q2(A)/mu(A), with source prices E min(lambda_i,lambda_j). Relative tooneproposal the gain is exactly half E|lambda_i-lambda_j|. Repeats included, sameb/x/W, noPSD or undefinedtwo-winner theorem. C*restricted<=C2<=C1natural; onp_A≈1 there is almostnogain. Need geometry of the whole near-forced-source receiver union. More proposal algebra is not a payment.

## Do not continue optimizing this radial certificate

D=c0^n, D<u<Theta, lambda=exp[(u/D-1)/n]. Removing smallradiuspool (rate<=u) leaves >Theta-u rate, so proportional routing has a valid global coefficient
C(u)=[(1+c0/lambda)^n-1]/(Theta-u).
But infC(u)>=max(0,2^n exp(-Theta/D)-1)/Theta, and for n>=2^30 >=(2^(n/2)-1)/(6144sqrt n) diverges exponentially. This rules out THIS full single-source-shadow certificate attaining a uniform bound bythresholdtuning; it does not prove actualallocationcongestion large or rule out all radialmethods. S2 also records a volume-power certificate; no newgeneralupperbound claimed.

## Actual computation, not geometric evidence

One frozen abstract4row/3source matrix only: mu=(1,1,8),q=(1,8,1)/16,d=(16,2,128), rowmasses(2,1,1,6),N=({0,1},{1,2},{1},{2}). V=U10 butrestrictedopt3/2. qsingle11/3, musingle19/9, qpair91/27, mupair245/162. ExactHall lower cuts andFraction flows match; HiGHSfloatingcrosscheck separate. Independentverify525receivercuts,14pairsourcecuts,3primalsPASS. Noactualhardcube realization claimed, no scan or newphysicaldimension model, noMATLAB/PDF.

## Next substantive task

Keep focus on original joint geometry, especially receiver regions almost entirely dependent on one overlapping source population, with all actualhistory and sourceprices/capacities. The actual restriction may be enlarged if justified; originalP0 includes everyinputparent and has nooldqcap. Do not force a stronger transport theorem merely because its LP is clean. Do not count the present Hall reformulation or exponentialcertificate as an improvement towardrootorder. This was an audited bounded unsuccessful route check, archived to prevent repeatwork.

User cap oneAstra/threeSol, reusecurrentagents. Next completedround686. Temporarywork remainsdata-volume only; noPDF; MATLABpromptlyexit ifused.
