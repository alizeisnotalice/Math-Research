#!/usr/bin/env python3
"""Independent exact finite certificates; no geometric realization is inferred."""
from pathlib import Path
from fractions import Fraction as F
from itertools import combinations
import hashlib,json
P=Path(__file__).resolve().parent
j=json.loads((P/'RESULT.json').read_text())
def check_flow(r):
 ids=r['source_ids'];mu=list(map(F,r['mu']));v=list(map(F,r['receiver_masses']))
 N=[{ids.index(i) for i in row} for row in r['allowed_source_ids']]
 flow=[[F(x) for x in row] for row in r['optimal_exact_flow']]
 C=F(r['C_opt_exact'])
 assert all(sum(row)==vr for row,vr in zip(flow,v))
 assert all(x>=0 and (x==0 or i in N[b]) for b,row in enumerate(flow) for i,x in enumerate(row))
 assert all(sum(row[i] for row in flow)<=C*mu[i] for i in range(len(ids)))
 vals=[]
 for mask in range(1,1<<len(v)):
  rows=[b for b in range(len(v)) if mask>>b&1]
  ns=set().union(*(N[b] for b in rows));cap=sum(mu[i] for i in ns)
  assert cap>0
  vals.append(sum(v[b] for b in rows)/cap)
 assert max(vals)==C
 return len(vals)
checks=check_flow(j['result']);assert F(j['result']['C_opt_exact'])==F(3,2)
assert F(j['result']['C_equal_exact'])==F(11,3)
assert F(j['heuristic_and_pair_audit']['C_mu_proportional_exact'])==F(19,9)
mu=list(map(F,j['result']['mu']));q=list(map(F,j['result']['q']));v=list(map(F,j['result']['receiver_masses']))
ids=j['result']['source_ids'];N=[{ids.index(i) for i in row} for row in j['result']['allowed_source_ids']]
for name,weights,expected in [('q',q,F(91,27)),('mu',mu,F(245,162))]:
 cert=j['heuristic_and_pair_audit']['two_choice'][name]
 probs=[[weights[i]/sum(weights[h] for h in N[b]) if i in N[b] else F(0) for i in range(3)] for b in range(4)]
 vals=[]
 for mask in range(1,8):
  A={i for i in range(3) if mask>>i&1}
  vals.append(sum(v[b]*sum(probs[b][i] for i in A)**2 for b in range(4))/sum(mu[i] for i in A))
 assert max(vals)==expected==F(cert['C2_exact'])
 events=cert['pair_event_rows']
 for ev in events:
  b=int(ev['receiver_row'][1:]);i,h=[ids.index(t) for t in ev['pair']]
  prob=probs[b][i]*probs[b][h]*(1 if i==h else 2)
  assert prob==F(ev['probability']) and prob*v[b]==F(ev['mass'])
 assert sum(F(e['mass']) for e in events)==sum(v)
 checks+=check_flow(cert['pair_event_exact_primal_and_Hall_audit'])
# Uniform-threshold certificate: sufficient exact constants in the proof.
assert F(6144,2**15)==F(3,16)<F(1,3)
# log2>2/3 follows from its positive atanh(1/3) series.
if (P/'MANIFEST.json').exists():
 for name,h in json.loads((P/'MANIFEST.json').read_text()).items():
  assert hashlib.sha256((P/name).read_bytes()).hexdigest()==h,name
print(json.dumps({'status':'PASS','independent_receiver_subsets':checks,'independent_pair_source_subsets':14,'primal_flows':3,'scope':'exact frozen abstract allocation model and scalar proof constants; no uniform cube bound'}))
