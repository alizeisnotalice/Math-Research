# R685 exact frozen receiver-source allocation audit

## Outcome and scope

The frozen S2 matrix confirms

| allocation rule | exact worst normalized source load |
|---|---:|
| unrestricted optimal balancing | 3/2 |
| proportional to q on each allowed row | 11/3 |
| proportional to mu on each allowed row | 19/9 |
| optimal choice from two same-row iid q-proposals | 91/27 |
| optimal choice from two same-row iid mu-proposals | 245/162 |

Both two-candidate models are with replacement, including singleton rows and repeated-candidate events. The mu-proposal pair optimum exceeds unrestricted balancing by exactly 1/81. The q-proposal pair rule improves its one-candidate rule but retains a substantial forced singleton-source bottleneck.

This is an **abstract capacity matrix**, not an actual cube, strict core, hard high-threshold recursion, or general global-budget example. All receiver masses and allowed edges are frozen algebraic inputs supplied by S2. No geometric realization is inferred.

## Frozen input

Sources have

`mu=(1,1,8)`, `q=(1,8,1)/16`, `d=(16,2,128)`,

so mu_i=q_i*d_i exactly. Rows are

| receiver | mass | allowed sources |
|---|---:|---|
| r0 | 2 | s0,s1 |
| r1 | 1 | s1,s2 |
| r2 | 1 | s1 |
| r3 | 6 | s2 |

Total receiver mass and total source capacity are both 10. The complete input is embedded in RESULT.json and is reproduced by the built-in `--frozen-s2` flag. No fourth input file is created.

## Unrestricted optimum: matching exact lower and upper certificates

All 15 nonempty receiver subsets are enumerated using fractions.Fraction. Weighted Hall gives

`C*=max_S mass(S)/mu(N(S))`.

The unique tight subset is `{r0,r2}`, with receiver mass 3 and neighbor capacity `mu0+mu1=2`, so C*≥3/2. Exact rational max-flow supplies the primal

```text
          s0    s1    s2
r0       3/2   1/2    0
r1         0     0    1
r2         0     1    0
r3         0     0    6
```

Every row sum is exact, every flow uses an allowed edge, and normalized column loads are `(3/2,3/2,7/8)`. Thus C*=3/2. The same lower certificate can be written as source prices `(1/2,1/2,0)`, with mu-weighted price sum one and total receiver minimum-price cost 3/2.

For the q/W rule the normalized column loads are `(2/9,11/3,55/72)`. For the mu-proportional rule they are `(1,19/9,31/36)`. Both follow from exact row fractions, not floating LP values.

## Same-row iid pair allocation

For a fixed proposal p_r on the allowed sources of row r, draw both candidates independently from that **same row**, with replacement. For each nonempty source subset A, events with both candidates in A are forced to allocate to A. Their total mass is

`forced(A)=sum_r mass_r [sum_(i in A) p_ri]^2`.

The exact two-choice optimum is therefore

`C2=max_(nonempty A) forced(A)/mu(A)`.

The code enumerates all seven source subsets and separately constructs all eight nonzero unordered pair-event rows. A mixed pair has mass `2 mass_r p_ri p_rj`; a repeated pair has mass `mass_r p_ri^2`. Exact max-flow and all 255 nonempty event-row Hall subsets verify that the event primal reaches the source-subset lower bound. This supplies matching exact lower and upper certificates rather than relying on a floating objective.

For q-proposals the tight set is `{s1}`:

`forced({s1})=2(8/9)^2+(8/9)^2+1=91/27`.

For mu-proposals the same set is tight:

`forced({s1})=2(1/2)^2+(1/9)^2+1=245/162`.

The following exact event allocation attains both optima. Each event's entire mass is assigned to the displayed chosen source.

| receiver and candidate pair | q-proposal event mass | mu-proposal event mass | chosen source |
|---|---:|---:|---|
| r0:(s0,s0) | 2/81 | 1/2 | s0 |
| r0:(s0,s1) | 32/81 | 1 | s0 |
| r0:(s1,s1) | 128/81 | 1/2 | s1 |
| r1:(s1,s1) | 64/81 | 1/81 | s1 |
| r1:(s1,s2) | 16/81 | 16/81 | s2 |
| r1:(s2,s2) | 1/81 | 64/81 | s2 |
| r2:(s1,s1) | 1 | 1 | s1 |
| r3:(s2,s2) | 6 | 6 | s2 |

The resulting normalized loads are `(34/81,91/27,503/648)` for q-proposals and `(3/2,245/162,283/324)` for mu-proposals. The source price concentrated on s1 matches each lower certificate; generally pair-event prices use `E[min(lambda_I,lambda_J)]`, with the shared row and iid proposal retained.

These results concern optimal selection within a specified proposal pair. They do not grant access to every neighbor after the pair is drawn, condition on distinct candidates, or replace two candidates by samples from different receiver rows.

## Arithmetic, solver cross-checks and reproduction

All capacities, probabilities, Hall ratios, flows and primal checks use exact rational arithmetic. SciPy linprog(method='highs') is only a secondary normalized floating check. All three LPs succeeded: unrestricted and the two pair-event models. Their objectives agree with the exact certificates to at most 2.23e-16. No floating result supplies the proof.

Local versions: NumPy2.5.4, SciPy1.18.1 with bundled HiGHS1.12.0; standalone highspy1.15.1; CVXPY1.9.3. Only SciPy/HiGHS is used for optimization here; no packages were installed.

Executed command:

```text
/Users/zzh/.local/share/math-research-tools/venv/bin/python /Volumes/data/CodexTemp/centered-cube-r685-20261116/NUMERIC.py --frozen-s2
```

The run completed in about 0.36 seconds, all exact assertions passed, and the Python process exited with code zero. RESULT.json includes the frozen input, all seven source-subset pair certificates, exact event flows, Hall enumeration hashes, solver outcomes, command and source hash.

Source SHA-256: `5d65c0bf24f6827c6040dac8d0966bd7b17241cec85ddcc7ec4ce5cf21971ef4`. Result SHA-256: `bacf033735d5e2a23e0509840b82022d431f43216c10986bb43884d39e98eafc`.

No additional matrix, parameter scan, actual cube construction, subagent, Git operation or PDF was used. Computation stopped after this frozen audit.
