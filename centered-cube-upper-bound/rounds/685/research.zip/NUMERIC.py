#!/usr/bin/env python3
"""R685 exact finite allocation interface. No allocations run without frozen --input JSON."""
from fractions import Fraction as F
from pathlib import Path
from collections import deque
import argparse,hashlib,json,sys,time,math
ROOT=Path(__file__).resolve().parent

def rational(x):
    if not isinstance(x,(str,int)) or isinstance(x,bool):raise ValueError('Exact rational inputs must be strings or integers; floats are forbidden')
    return F(x)
def serial(v):
    if isinstance(v,F):return str(v)
    if isinstance(v,list):return [serial(x) for x in v]
    if isinstance(v,dict):return {k:serial(x) for k,x in v.items()}
    return v

def solve(data):
    # Geometry is provenance supplied by the frozen input, not inferred by this LP.
    sources=data['sources'];rows=data['receivers']
    if len(rows)>12:raise ValueError('This bounded certificate accepts at most12 receiver rows')
    ids=[s['id'] for s in sources];rids=[r['id'] for r in rows]
    if len(set(ids))!=len(ids) or len(set(rids))!=len(rids):raise ValueError('IDs must be unique')
    q=[rational(s['q']) for s in sources];d=[rational(s['d']) for s in sources];mu=[q0*d0 for q0,d0 in zip(q,d)]
    if not all(v>0 for v in q+d):raise ValueError('Every active source must have q,d>0')
    v=[rational(r['mass']) for r in rows]
    if any(x<0 for x in v):raise ValueError('Receiver masses must be nonnegative')
    allowed=[]
    for row in rows:
        aa=row['allowed_source_ids']
        if len(set(aa))!=len(aa) or any(i not in ids for i in aa):raise ValueError('Allowed source IDs invalid')
        allowed.append([ids.index(i) for i in aa])
    V=sum(v,F(0));Mu=sum(mu,F(0));totalrows=len(v);ncols=len(mu)
    # All receiver-subset weighted Hall obstructions, exact.
    C=F(0);tight=None;ties=0;hall=[]
    for mask in range(1,1<<totalrows):
        selected=[r for r in range(totalrows) if mask>>r&1]
        mass=sum((v[r] for r in selected),F(0));N=sorted(set(i for r in selected for i in allowed[r]));capacity=sum((mu[i] for i in N),F(0))
        if mass and not capacity:return {'feasible':False,'reason':'positive receiver subset has no allowed capacity','Hall_obstruction_rows':[rids[r] for r in selected]}
        ratio=mass/capacity if capacity else F(0)
        hall.append({'mask':mask,'mass':str(mass),'neighbor_capacity':str(capacity),'ratio':str(ratio)})
        if ratio>C:C=ratio;tight={'receiver_ids':[rids[r] for r in selected],'neighbor_source_ids':[ids[i] for i in N],'mass':mass,'capacity':capacity};ties=1
        elif ratio==C:ties+=1
    assert all(F(r['ratio'])<=C for r in hall)
    # Exact rational max-flow at the Hall optimum supplies the primal witness.
    S=0;R0=1;I0=1+totalrows;T=I0+ncols;size=T+1
    residual=[[F(0)]*size for _ in range(size)];initial=[[F(0)]*size for _ in range(size)]
    def edge(a,b,c):initial[a][b]+=c;residual[a][b]+=c
    for r in range(totalrows):edge(S,R0+r,v[r])
    for r in range(totalrows):
        for i in allowed[r]:edge(R0+r,I0+i,V)
    for i in range(ncols):edge(I0+i,T,C*mu[i])
    augmentations=0;flow=F(0)
    while True:
        parent=[-1]*size;parent[S]=S;queue=deque([S])
        while queue and parent[T]<0:
            a=queue.popleft()
            for b in range(size):
                if parent[b]<0 and residual[a][b]>0:parent[b]=a;queue.append(b)
        if parent[T]<0:break
        b=T;path=[]
        while b!=S:path.append((parent[b],b));b=parent[b]
        amount=min(residual[a][b] for a,b in path)
        for a,b in path:residual[a][b]-=amount;residual[b][a]+=amount
        flow+=amount;augmentations+=1
    assert flow==V
    X=[[initial[R0+r][I0+i]-residual[R0+r][I0+i] for i in range(ncols)] for r in range(totalrows)]
    assert all(sum(row,F(0))==v[r] for r,row in enumerate(X))
    loads=[sum((X[r][i] for r in range(totalrows)),F(0))/mu[i] for i in range(ncols)]
    assert all(z<=C for z in loads)
    # Equal q/W assignment preserves exactly the same allowed relation.
    equal=[]
    for r in range(totalrows):
        W=sum((q[i] for i in allowed[r]),F(0))
        equal.append([v[r]*q[i]/W if i in allowed[r] and W else F(0) for i in range(ncols)])
    equal_loads=[sum((equal[r][i] for r in range(totalrows)),F(0))/mu[i] for i in range(ncols)]
    Ce=max(equal_loads,default=F(0));assert Ce>=C
    # Double-precision LP is an explicitly secondary check, normalized for scale.
    lp={'status':'not run: zero total receiver mass'}
    if V:
        import numpy as np
        import scipy
        from scipy.optimize import linprog
        vn=[float(z/V) for z in v];mn=[float(z/Mu) for z in mu]
        if any((v[i]>0 and vn[i]==0) for i in range(totalrows)) or any(z==0 for z in mn):
            lp={'status':'skipped: normalized positive rational underflows float; exact Hall and flow certificates remain valid'}
        else:
            pairs=[(r,i) for r in range(totalrows) for i in allowed[r]];nv=len(pairs)+1
            objective=np.zeros(nv);objective[-1]=1;eq=np.zeros((totalrows,nv));ub=np.zeros((ncols,nv))
            for z,(r,i) in enumerate(pairs):eq[r,z]=1;ub[i,z]=1
            ub[:,-1]=-np.array(mn)
            res=linprog(objective,A_ub=ub,b_ub=np.zeros(ncols),A_eq=eq,b_eq=np.array(vn),bounds=(0,None),method='highs')
            lp={'status':'success' if res.success else 'solver did not certify success','scipy_version':scipy.__version__,'message':res.message,'normalized_objective':float(res.fun) if res.success else None,'exact_normalized_optimum':str(C*Mu/V),'absolute_objective_discrepancy':abs(float(res.fun)-float(C*Mu/V)) if res.success else None,'scope':'Floating cross-check only; exact proof is Hall lower bound plus rational primal flow'}
    return serial({'feasible':True,'source_ids':ids,'receiver_ids':rids,'q':q,'d':d,'mu':mu,'receiver_masses':v,'allowed_source_ids':[r['allowed_source_ids'] for r in rows],'C_opt_exact':C,'Hall_tight_subset':tight,'Hall_tight_subset_count':ties,'Hall_subsets_enumerated':len(hall),'Hall_all_subsets_sha256':hashlib.sha256(json.dumps(hall,sort_keys=True).encode()).hexdigest(),'optimal_exact_flow':X,'optimal_normalized_source_loads':loads,'maxflow_augmentations':augmentations,'equal_q_over_W_flow':equal,'equal_normalized_source_loads':equal_loads,'C_equal_exact':Ce,'C_equal_over_C_opt':Ce/C if C else F(1),'scipy_HiGHS_crosscheck':lp,'all_exact_primal_checks_passed':True})

def frozen_s2_input():
    return {'name':'S2 frozen4rows3sources exact abstract allocation matrix','scope':'ABSTRACT CAPACITY MATRIX ONLY. Not an actual cube, strict core, hard high-threshold recursion, or general global-budget certificate.','sources':[{'id':'s0','q':'1/16','d':'16'},{'id':'s1','q':'1/2','d':'2'},{'id':'s2','q':'1/16','d':'128'}],'receivers':[{'id':'r0','mass':'2','allowed_source_ids':['s0','s1']},{'id':'r1','mass':'1','allowed_source_ids':['s1','s2']},{'id':'r2','mass':'1','allowed_source_ids':['s1']},{'id':'r3','mass':'6','allowed_source_ids':['s2']}]}

def audit_heuristics_and_pairs(data,base):
    sources=data['sources'];rows=data['receivers'];ids=[s['id'] for s in sources]
    q=[rational(s['q']) for s in sources];mu=[q[i]*rational(sources[i]['d']) for i in range(len(sources))]
    v=[rational(r['mass']) for r in rows];N=[[ids.index(sid) for sid in r['allowed_source_ids']] for r in rows]
    prop=[[v[r]*mu[i]/sum((mu[j] for j in N[r]),F(0)) if i in N[r] else F(0) for i in range(len(ids))] for r in range(len(rows))]
    loads=[sum((prop[r][i] for r in range(len(rows))),F(0))/mu[i] for i in range(len(ids))]
    Cmu=max(loads);assert Cmu==F(19,9)
    assert F(base['C_opt_exact'])==F(3,2) and F(base['C_equal_exact'])==F(11,3)
    expected=[[F(3,2),F(1,2),F(0)],[F(0),F(0),F(1)],[F(0),F(1),F(0)],[F(0),F(0),F(6)]]
    assert all(sum(row,F(0))==v[r] for r,row in enumerate(expected))
    assert all(sum((expected[r][i] for r in range(len(rows))),F(0))<=F(3,2)*mu[i] for i in range(len(ids)))
    pairsout={}
    for proposal,weights in (('q',q),('mu',mu)):
        probs=[[weights[i]/sum((weights[j] for j in N[r]),F(0)) if i in N[r] else F(0) for i in range(len(ids))] for r in range(len(rows))]
        subset=[];C2=F(0);tight=[]
        for mask in range(1,1<<len(ids)):
            Aset=[i for i in range(len(ids)) if mask>>i&1];capacity=sum((mu[i] for i in Aset),F(0))
            forced=sum((v[r]*sum((probs[r][i] for i in Aset),F(0))**2 for r in range(len(rows))),F(0))
            ratio=forced/capacity
            subset.append({'source_ids':[ids[i] for i in Aset],'forced_pair_event_mass':forced,'capacity':capacity,'C2_lower':ratio})
            if ratio>C2:C2=ratio;tight=[ids[i] for i in Aset]
        events=[]
        for r in range(len(rows)):
            for z,i in enumerate(N[r]):
                for j in N[r][z:]:
                    mass=v[r]*probs[r][i]*probs[r][j]*(1 if i==j else 2)
                    events.append({'id':rows[r]['id']+'__'+ids[i]+'_'+ids[j],'mass':str(mass),'allowed_source_ids':[ids[i]] if i==j else [ids[i],ids[j]],'receiver_row':rows[r]['id'],'pair':[ids[i],ids[j]],'probability':str(mass/v[r])})
        assert sum((F(r['mass']) for r in events),F(0))==sum(v,F(0))
        event_data={'sources':sources,'receivers':events}
        primal=solve(event_data)
        assert F(primal['C_opt_exact'])==C2
        for key in ('equal_q_over_W_flow','equal_normalized_source_loads','C_equal_exact','C_equal_over_C_opt'):primal.pop(key,None)
        expectedC=F(91,27) if proposal=='q' else F(245,162)
        assert C2==expectedC
        pairsout[proposal]={'C2_exact':C2,'tight_source_subset':tight,'all7_source_subset_certificates':subset,'iid_probabilities_by_receiver':probs,'pair_event_rows':events,'pair_event_exact_primal_and_Hall_audit':primal,'iid_rule':'Two independent candidates from the SAME receiver row, WITH replacement; mixed unordered pair gets mass2p_i p_j. Singletons force their only source. Event allocation may split mass between its candidates.','scope':'Optimal choice within the given iid pair proposal, not unrestricted access to all row neighbors.'}
    return serial({'mu_proportional_flow':prop,'mu_proportional_normalized_source_loads':loads,'C_mu_proportional_exact':Cmu,'provided_primal_exact_verified':expected,'two_choice':pairsout})

def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--input',type=Path,help='Frozen JSON supplied by S2');parser.add_argument('--frozen-s2',action='store_true',help='Use the single explicitly frozen S2 four-row matrix')
    args=parser.parse_args();tick=time.time()
    if args.frozen_s2:
        if args.input:parser.error('Choose either --input or --frozen-s2')
        data=frozen_s2_input();raw=json.dumps(data,sort_keys=True).encode();input_path='built-in explicitly frozen S2 matrix'
    else:
        if not args.input:parser.error('A frozen --input or --frozen-s2 is required')
        raw=args.input.read_bytes();data=json.loads(raw);input_path=str(args.input.resolve())
    answer=solve(data)
    extra=audit_heuristics_and_pairs(data,answer) if args.frozen_s2 else None
    out={'status':'computed frozen finite allocation model','scope':data.get('scope','UNSPECIFIED INPUT PROVENANCE: capacity matrix only'),'name':data.get('name'),'input_path':input_path,'input_sha256':hashlib.sha256(raw).hexdigest(),'input':data,'arithmetic':'Exact Fraction Hall enumeration and exact rational max-flow; optional floating SciPy HiGHS cross-check','command':[sys.executable,str(Path(__file__).resolve())]+(['--frozen-s2'] if args.frozen_s2 else ['--input',str(args.input.resolve())]),'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'result':answer,'elapsed_seconds':time.time()-tick,'geometry_note':'This program does not verify actual cube geometry, original high-threshold recursion or global source budget.'}
    out['heuristic_and_pair_audit']=extra
    out['local_solver_versions']={'scipy':'1.18.1','scipy_bundled_HiGHS':'1.12.0','standalone_highspy':'1.15.1','cvxpy':'1.9.3'}
    (ROOT/'RESULT.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({'status':out['status'],'result':answer,'elapsed_seconds':out['elapsed_seconds'],'heuristic_and_pair_audit':extra,'RESULT_sha256':hashlib.sha256((ROOT/'RESULT.json').read_bytes()).hexdigest(),'source_sha256':out['script_sha256']},indent=2))
if __name__=='__main__':main()
