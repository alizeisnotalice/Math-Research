from fractions import Fraction as F
from itertools import product
from math import isqrt
from pathlib import Path
import json,platform,sys,subprocess

def cases(remote):
    data=[]
    for q,code,B in [(5,(1,-1),2),(7,(-1,1,0),3),(11,(1,1),4)]:
        # Exact finite torus. Independent rows of the shear matrix.
        if remote:
            freq=[int(sum(1 for row in product(range(q),repeat=len(code)) if sum(a*b for a,b in zip(code,row))%q==v)) for v in range(q)]
        else:
            freq=[1]+[0]*(q-1)
            for c in code:
                freq=[sum(freq[(v-c*z)%q] for z in range(q)) for v in range(q)]
        assert len(set(freq))==1
        # Several labelled targets have overlapping projected sections; bill the union.
        sections=[{x for x in product(range(q),repeat=B) if all((v+i)%q<q//2+1 for v in x)} for i in range(3)]
        union=set.union(*sections);den=q**(len(code)*B)
        if remote:
            mass=F(len(union),q**B)
        else:
            from math import prod
            mass=F(sum(prod(freq[v] for v in x) for x in union),den)
        assert mass==F(len(union),q**B)<=sum(F(len(s),q**B) for s in sections)
        data.append([q,list(code),B,len(union),str(mass),sum(map(len,sections))])
    return data
def transport(remote):
    # Exact directed bipartite maximum; transpose averaging yields a symmetric optimum.
    out=[]
    for dim,m,ncost in [(1,5,2),(2,7,3),(3,10,5)]:
        pts=[tuple(((i*(2*l+3))%11) for l in range(dim)) for i in range(m)]
        weight=[F(1+i%4,7) for i in range(m)]
        for radius in (3,6,9):
            edges={(i,j):weight[i]*weight[j]*ncost for i in range(m) for j in range(m) if max(abs(a-b) for a,b in zip(pts[i],pts[j]))>=radius}
            if remote:
                vals=[]
                for mask in range(1<<m):
                    cut=sum((weight[i] for i in range(m) if not(mask>>i&1)),F(0))
                    for j in range(m):
                        cut+=min(weight[j],sum((edges.get((i,j),F(0)) for i in range(m) if mask>>i&1),F(0)))
                    vals.append(cut)
                opt=min(vals)
            else:
                s=2*m;t=s+1;cap={(s,i):weight[i] for i in range(m)}
                cap.update({(m+i,t):weight[i] for i in range(m)})
                cap.update({(i,m+j):v for (i,j),v in edges.items()})
                opt=F(0)
                while True:
                    par={s:None};front=[s]
                    for v in front:
                        for w in range(t+1):
                            if w not in par and cap.get((v,w),0)>0:par[w]=v;front.append(w)
                        if t in par:break
                    if t not in par:break
                    v=t;path=[]
                    while v!=s:
                        w=par[v];path.append((w,v));v=w
                    aug=min(cap[e] for e in path);opt+=aug
                    for v,w in path:cap[v,w]-=aug;cap[w,v]=cap.get((w,v),0)+aug
            out.append([dim,m,radius,str(opt)])
    return out
if '--mac' in sys.argv:
 print(json.dumps([platform.python_version(),[cases(True),transport(True)]]));sys.exit()
ls=[cases(False),transport(False)]
cmd=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=8','macbook-math','/Users/zhengzhihao/.venv/bin/python -B - --mac']
proc=subprocess.run(cmd,input=Path(__file__).read_text(),text=True,capture_output=True,check=True,timeout=100);rv,rs=json.loads(proc.stdout);assert rs==ls
from flint import arb,ctx
ctx.prec=256;hist=[]
for n in (256,1024,4096):
    a=32*n;k=(n.bit_length()-1)//2;h=1+arb(1)/a;b=arb(2)**(arb(1)/n);P=2*h*b
    K=4096*isqrt(n)*a**n;ell=arb(2).log()/K
    for m in (1,2):
        r=arb(m)/isqrt(n);w=2*r/a
        V=4*w**n;R=V*ell.expm1()/2
        G=n*arb(a).log()+(K-5)*n*arb(4).log()+(-(-ell).expm1()).log()
        candidates=3*(w/P)**k
        assert 0<R and R<V/4 and G>(4*arb(8)**n+4).log() and 0<candidates and candidates<1
        hist.append(dict(n=n,k=k,m=m,V=str(V),R=str(R),logD_div_K=[str(G/K),str((G+arb(3).log())/K)],expected_other_candidates=str(candidates),ac_matched_fraction=str(7*V*isqrt(n)/(16*arb(2)**n))))
print(json.dumps(dict(python=sys.executable,version=platform.python_version(),remote_version=rv,cmd=cmd,torus=ls,histories=hist),indent=2))
