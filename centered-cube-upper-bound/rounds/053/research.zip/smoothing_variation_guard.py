#!/usr/bin/env python3
"""Exact majority-prefix guards and actual 1D positive-source convolution probes.

K is frequency depth, not dimension. Exact Fraction certificates check the
analytically proved error budget; they do not derive it from finite sampling.
Actual small-K sources are positive, finite, piecewise constant densities on
[-1,2]. Their cube integrals use integer digit counting, with no fine-cell
enumeration. Receiver averages are stratified finite sampling. B_j uses a
deterministic midpoint v quadrature and 80-digit rational approximations to
exp(v); it is an auxiliary approximation, not a certified Lebesgue integral.
"""
from fractions import Fraction as F
from decimal import Decimal, localcontext
from math import comb
from pathlib import Path
import json
import random
import time


def fs(x):
    x = F(x)
    return str(x.numerator) if x.denominator == 1 else f'{x.numerator}/{x.denominator}'


def dec(x):
    x = F(x)
    return Decimal(x.numerator) / Decimal(x.denominator)


def ds(x):
    return format(x, '.24E')


class Majority:
    def __init__(self, K):
        assert K >= 1 and K % 2 == 1
        self.K = K
        self.cumulative = []
        for r in range(K + 1):
            row, running = [], 0
            for plus in range(r + 1):
                running += comb(r, plus)
                row.append(running)
            assert running == 2 ** r
            self.cumulative.append(row)

    def numerator(self, fixed_sum, remaining):
        # Every invocation fixes some of an odd total K, hence no zero tie.
        assert (fixed_sum + remaining) % 2 == 1
        cutoff = (remaining - fixed_sum - 1) // 2
        if cutoff < 0:
            negative = 0
        elif cutoff >= remaining:
            negative = 2 ** remaining
        else:
            negative = self.cumulative[remaining][cutoff]
        return 2 ** remaining - 2 * negative

    def expectation(self, fixed_sum, remaining):
        return F(self.numerator(fixed_sum, remaining), 2 ** remaining)


def prefix_dynamic_guards(K):
    model = Majority(K)
    c = F(comb(K - 1, (K - 1) // 2), 2 ** (K - 1))
    delta = F(1, 4)
    layer_values = []
    for j in range(1, K + 1):
        remaining = K - j
        absolute_sum = 0
        signed_sum = 0
        for plus in range(j):
            s = 2 * plus - (j - 1)
            weight = comb(j - 1, plus)
            before = model.numerator(s, remaining + 1)
            for bit in (-1, 1):
                difference = 2 * model.numerator(s + bit, remaining) - before
                absolute_sum += weight * abs(difference)
                signed_sum += weight * difference
        expectation = delta * F(absolute_sum, 2 ** (K + 1))
        assert expectation == delta * c and signed_sum == 0
        layer_values.append(expectation)
    total = sum(layer_values, F(0))
    assert total == delta * K * c
    return {'K': K, 'dimension': 1, 'delta': fs(delta), 'central_binomial_probability': fs(c),
            'layers_checked': K, 'every_layer_absolute_increment': fs(delta * c),
            'total_conditional_variation': fs(total),
            'expected_positive_conditional_variation': fs(total / 2),
            'status': 'exact binomial prefix-distribution enumeration; not a sampled source integral'}


def budget_guards(K):
    delta = F(1, 4)
    c = F(comb(K - 1, (K - 1) // 2), 2 ** (K - 1))
    s = 1
    while s < 100 * (K + 1):
        s *= 2
    q = s.bit_length() - 1
    R = s * s
    assert R == 2 ** (2 * q) and s >= 100 * (K + 1)
    target = delta * K * c
    error_per_profile = 26 * delta / s  # e<3 =>8e+2<26.
    loss = 2 * (K + 1) * error_per_profile
    variation_lower = target - loss
    positive_lower = max(F(0), (variation_lower - 2 * delta) / 2)
    assert positive_lower >= 0 and loss <= F(13, 100)
    return {'K': K, 'dimension': 1, 'q': q, 'sqrt_R': s, 'R_exact': R,
            'source_mass': '9/2', 'density_range': ['5/4', '7/4'],
            'central_binomial_probability': fs(c),
            'conditional_total_variation': fs(target),
            'single_profile_L1_error_upper': fs(error_per_profile),
            'sampled_scale_total_error_upper': fs(loss),
            'smoothed_total_variation_lower': fs(variation_lower),
            'smoothed_positive_variation_lower': fs(positive_lower),
            'positive_variation_lower_per_source_mass': fs(positive_lower / F(9, 2)),
            'positive_variation_lower_decimal': ds(dec(positive_lower)),
            'log_scale_span_definition': 'K log(R), dimension fixed at one',
            'status': 'exact parameter guard for analytically proved whole-Lebesgue error bound; no fine-source enumeration'}


class ActualSource:
    """Exact integral of (3/2+sign-majority/4)1[-1,2]."""
    def __init__(self, K, q):
        self.K, self.q = K, q
        self.B = 2 * q * K + 1
        self.cells = 2 ** self.B
        self.positions = tuple(2 * q * i + 1 for i in range(1, K + 1))
        self.selected = set(self.positions)
        self.model = Majority(K)
        assert self.sign_count_below(self.cells) == 0
        assert self.integral(F(-1), F(2)) == F(9, 2)

    def sign_for_cell(self, m):
        total = sum(1 if ((m >> (self.B - pos)) & 1) == 0 else -1
                    for pos in self.positions)
        return 1 if total > 0 else -1

    def sign_count_below(self, m):
        if m == self.cells:
            return 0
        assert 0 <= m < self.cells
        total, fixed_sum, remaining = 0, 0, self.K
        for pos in range(1, self.B + 1):
            bit = (m >> (self.B - pos)) & 1
            selected = pos in self.selected
            if bit:
                # Branch bit=0 lies below m; suffix coordinates are uniform.
                branch_sum = fixed_sum + int(selected)
                branch_remaining = remaining - int(selected)
                numerator = self.model.numerator(branch_sum, branch_remaining)
                total += numerator * 2 ** (self.B - pos - branch_remaining)
            if selected:
                fixed_sum += 1 if bit == 0 else -1
                remaining -= 1
        return total

    def periodic_primitive(self, x):
        integer = x.numerator // x.denominator
        fraction = x - integer
        scaled = fraction * self.cells
        m = scaled.numerator // scaled.denominator
        remainder = fraction - F(m, self.cells)
        complete = F(3 * m, 2 * self.cells) + F(self.sign_count_below(m), 4 * self.cells)
        density = F(3, 2) + F(self.sign_for_cell(m), 4)
        return integer * F(3, 2) + complete + remainder * density

    def integral(self, low, high):
        low, high = max(F(-1), low), min(F(2), high)
        if high <= low:
            return F(0)
        return self.periodic_primitive(high) - self.periodic_primitive(low)

    def average(self, x, L):
        return self.integral(x - L / 2, x + L / 2) / L

    def conditional(self, x, j):
        m = (x * self.cells).numerator // (x * self.cells).denominator
        fixed = sum(1 if ((m >> (self.B - pos)) & 1) == 0 else -1
                    for pos in self.positions[:j])
        return F(3, 2) + self.model.expectation(fixed, self.K - j) / 4


def actual_probe(K, repetitions, quadrature):
    b = budget_guards(K)
    source = ActualSource(K, b['q'])
    seed = 530000 + 1000 * K + 10 * repetitions + quadrature
    rng = random.Random(seed)
    exp_midpoints = [F((dec(F(2 * i + 1, 2 * quadrature))).exp()) for i in range(quadrature)]
    assert all(1 < e < 3 for e in exp_midpoints)
    errors = [F(0) for _ in range(K + 1)]
    total_variation, positive_variation, model_variation = F(0), F(0), F(0)
    sample_count = repetitions * 2 ** K
    minimum, maximum = F(7, 4), F(5, 4)
    for pattern in range(2 ** K):
        for _ in range(repetitions):
            m = rng.getrandbits(source.B)
            for index, pos in enumerate(source.positions):
                mask = 1 << (source.B - pos)
                if (pattern >> index) & 1:
                    m |= mask
                else:
                    m &= ~mask
            x = F(256 * m + rng.randrange(1, 256), 256 * source.cells)
            assert 0 < x < 1
            # Independent floor-formula source value and one-cell integral.
            rsum = sum(1 if ((2 * x * (b['R_exact'] ** i)).numerator //
                             (2 * x * (b['R_exact'] ** i)).denominator) % 2 == 0 else -1
                       for i in range(1, K + 1))
            density = F(3, 2) + F(1 if rsum > 0 else -1, 4)
            assert source.integral(F(m, source.cells), F(m + 1, source.cells)) * source.cells == density
            smooth, conditional = [], []
            for j in range(K + 1):
                L = F(1, b['sqrt_R'] * b['R_exact'] ** j)
                averages = [source.average(x, e * L) for e in exp_midpoints]
                assert all(F(5, 4) <= a <= F(7, 4) for a in averages)
                value = sum(averages, F(0)) / quadrature
                expected = source.conditional(x, j)
                smooth.append(value)
                conditional.append(expected)
                errors[j] += abs(value - expected)
                minimum, maximum = min(minimum, value), max(maximum, value)
            for j in range(1, K + 1):
                change = smooth[j] - smooth[j - 1]
                total_variation += abs(change)
                positive_variation += max(F(0), change)
                model_variation += abs(conditional[j] - conditional[j - 1])
    assert model_variation / sample_count == F(b['conditional_total_variation'])
    total_variation /= sample_count
    positive_variation /= sample_count
    mean_errors = [e / sample_count for e in errors]
    return {'K': K, 'dimension': 1, 'R_exact': b['R_exact'], 'finest_cell_binary_depth': source.B,
            'source_mass_exact': '9/2', 'source_density_range_exact': ['5/4', '7/4'],
            'source_support': '[-1,2]', 'receiver_interval': '[0,1]',
            'receiver_samples': sample_count, 'samples_per_selected_bit_pattern': repetitions,
            'seed': seed,
            'receiver_sampling': 'all selected-bit patterns equally weighted; random other bits, then discrete offset 1..255 on a 256-grid inside the finest cell',
            'quadrature_midpoints': quadrature, 'exp_precision_decimal_digits': 80,
            'conditional_total_variation_exact': b['conditional_total_variation'],
            'sampled_smoothed_total_variation_decimal': ds(dec(total_variation)),
            'sampled_smoothed_positive_variation_decimal': ds(dec(positive_variation)),
            'sampled_positive_variation_per_source_mass_decimal': ds(dec(positive_variation / F(9, 2))),
            'sampled_profile_L1_errors_decimal': [ds(dec(e)) for e in mean_errors],
            'sampled_B_range_decimal': [ds(dec(minimum)), ds(dec(maximum))],
            'whole_Lebesgue_profile_error_bound_exact': b['single_profile_L1_error_upper'],
            'status': 'actual finite positive source exact interval integrals; receiver sampling and v quadrature are auxiliary approximations',
            'scope_limit': 'Sampled errors are not certified full-Lebesgue L1 errors; no numerical order fit or single-octave obstruction claimed.'}


def toy_integral_guard(K):
    """Independent exhaustive floor-formula oracle for every finest prefix."""
    q, R = 1, 4
    source = ActualSource(K, q)
    running = 0
    for m in range(source.cells + 1):
        assert source.sign_count_below(m) == running
        expected = F(3 * m, 2 * source.cells) + F(running, 4 * source.cells)
        assert source.periodic_primitive(F(m, source.cells)) == expected
        # Also cross the whole-period boundary using an exact primitive.
        assert source.periodic_primitive(1 + F(m, source.cells)) == F(3, 2) + expected
        if m < source.cells:
            # At cell midpoint x=(2m+1)/(2*cells), direct original r_i floor
            # formulas are independent of the digit-DP implementation.
            rsum = sum(1 if (((2 * m + 1) * R ** i) // source.cells) % 2 == 0 else -1
                       for i in range(1, K + 1))
            sign = 1 if rsum > 0 else -1
            direct_density = F(3, 2) + F(sign, 4)
            assert source.integral(F(m, source.cells), F(m + 1, source.cells)) == direct_density / source.cells
            running += sign
    assert running == 0
    return {'K': K, 'q': q, 'R': R, 'finest_cells_enumerated': source.cells,
            'prefixes_checked': source.cells + 1,
            'source_mass_exact': '9/2',
            'status': 'every prefix and one-cell integral independently checked against direct floor-symbol enumeration; toy geometry only'}


def main():
    start = time.monotonic()
    with localcontext() as ctx:
        ctx.prec = 80
        K_values = (1, 3, 5, 9, 17, 33, 65, 129, 257)
        dynamic = [prefix_dynamic_guards(K) for K in K_values]
        budgets = [budget_guards(K) for K in (*K_values, 513, 1025)]
        actual = [actual_probe(K, repetitions, quadrature)
                  for repetitions, quadrature in ((4, 8), (16, 16)) for K in (1, 3, 5)]
        toy = [toy_integral_guard(K) for K in (1, 3, 5)]
        counts = {'exact_prefix_distribution_cases': len(dynamic),
                  'exact_analytic_error_budget_cases': len(budgets),
                  'actual_positive_source_convolution_probes': len(actual),
                  'independent_toy_source_prefix_enumerations': len(toy)}
        results = {'round': 53, 'status': 'PASS', 'standard_library_only': True,
                   'counts': counts, 'total_parameter_cases': sum(counts.values()),
                   'exact_layers_checked': sum(K_values),
                   'actual_receiver_samples': sum(a['receiver_samples'] for a in actual),
                   'independent_toy_prefixes_checked': sum(a['prefixes_checked'] for a in toy),
                   'scope': {'dimension': 1, 'depth_K_is_not_dimension': True,
                             'positive_source': '(3/2+sign(sum_i r_i)/4) indicator[-1,2], odd K, r_i=(-1)^floor(2x R^i)',
                             'time_smoothed_average': 'B_j=integral_0^1 A_(exp(v)L_j) f dv, L_j=R^(-j)/sqrt(R)',
                             'analytic_error': 'Whole-Lebesgue error theorem is separately proved; script checks its exact parameters with e<3.',
                             'fixed_threshold_band': 'All actual averages lie between 5/4 and 7/4, inside the true band (1,2).',
                             'upper_event': '{sup_u B(u)>2} is empty by the analytic source range, not merely absent on sampled receivers.',
                             'band_clipped_potential_range': ['1/4', '3/4'],
                             'weak_counterexample_disclaimer': 'Large band variation is not a counterexample to a maximal weak bound; the upper-threshold event is empty here.',
                             'all_scale_limit': 'Scale span is K log(R). This does not refute a single fixed scale-ratio window budget.',
                             'phase_groups': [[1, 3, 5], [9, 17, 33], [65, 129, 257]],
                             'phase_note': 'Parameter groups in one execution, not independently claimed runs.',
                             'sampling_limit': 'Actual receivers use stratified selected bits and discrete 256-grid jitter inside the finest cell, not continuous uniform draws. Receiver sampling and midpoint time quadrature have no claimed rigorous error bound or confidence interval; the exact general conclusion relies on the separately audited analytic bound.'},
                   'prefix_distribution': dynamic, 'analytic_error_budgets': budgets,
                   'actual_convolution_probes': actual, 'independent_toy_prefix_enumerations': toy}
        out = Path(__file__).with_name('results.json')
        out.write_text(json.dumps(results, sort_keys=True, indent=2) + '\n')
        print('PASS', sum(counts.values()), counts)
        print('Exact prefix layers:', sum(K_values), 'actual receivers:', results['actual_receiver_samples'])
        print('Runtime seconds:', round(time.monotonic() - start, 3))


if __name__ == '__main__':
    main()
