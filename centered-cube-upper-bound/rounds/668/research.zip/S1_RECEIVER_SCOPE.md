# R668 true-receiver restriction 与任意可测权重通量独立审查

**结论：恢复式、all-L1范围及可测Y的加权通量/正压分解继承均PASS。** 不需Y为BV或有光滑边界，但必须把恒等式写为原S′的regular moving exposed faces上的1_Y权重；不把粗糙T本身称为polyhedral/BV region。全族parent correction仍≤16U/31，真正P_Y或T的U预算未证。

本审查先读本轮TASK，再独立核对继承量词。只沿用已证R665–R667合同，不重读历史，不运行几何/概率扫描，不读主Astra预算作者稿。仅写本文件；无Git/PDF/MATLAB。

## 1. 固定数据、真实receiver与恢复

固定任意n≥1及实际有限原输入。保留a=32n、c₀=1+1/a、原qᵢ、Iₕ、common witnesses、原Lₕ、真实disjoint near losses Xₕ、radius order、shared rate-qᵢ Poisson history、真实first-k keys、全局未来repeat pruning。辅助uᵢ独立Unif(Bᵢ)，Aᵢ′=Q(uᵢ,c₀sᵢ)。令

Y=⋃_{near h}Xₕ，   |Y|=Vnear，
M′=P′∪Qrep′，
S(v)=Ωₖ′(v)\M′，
T(v)=(Ωₖ′(v)∩Y)\M′=S(v)∩Y。

Y由原实际input/owner construction确定，独立于Poisson history和auxiliary centers；不要求任何边界正则性。Ωₖ′仍取所有实际完成keys的union，不只取receiver自己owner对应的target。

旧marginal completion论证的局部事实是：若near target h完成k事件，其整个真实Xₕ位于原对应halo∩Lₕ，因Aᵢ⊂Aᵢ′也位于primed halo。故

E|Ωₖ′(1)∩Y| ≥ Σₕ|Xₕ|P(h完成k)
               ≥(1−ετ)Vnear， ετ=e^(−τ/4)<1/2。

第一步使用Xₕ真实不交和各target自己的可用cover；不假设target completion独立。实际union仍保留所有cross-key rescue。于是

(1−ετ)Vnear ≤ E|Ωₖ′(1)∩Y|
             ≤ E|P′|+E|Qrep′|+E|T(1)|
             ≤ Bₙ′U+E|T(1)|，

Bₙ′=8c₀ⁿ+32(2c₀/a)ⁿ≤5119/496<11。

P′、Qrep′的两项费用可仍按全空间支付，故限制receiver没有制造遗漏或新fee。这里没有第二次Δ：旧差集费用和完整new-union费用仍是同一账目的不同拆法。本式对每个实际有限input成立，Y虽依赖该input但没有限制原f类、尺度或维数。因此由其建立统一T预算仍可经原parent packing与finite recovery得到原all-L1目标；它是更弱的充分receiver目标，不是special-input定理。

## 2. 任意固定measurable Y：正确的加权flux statement

以下结论对任意固定Lebesgue-measurable Y⊂Rⁿ成立，可无界、无BV、无perimeter条件；S(v)来自有限bounded boxes，相关体积仍有限。先固定一条实际有限history和一组generic辅助中心，使R665 regular moving-face allocation有效。设Γᵢ,ℓ,σ(v)为原S(v)的正则moving exposed faces，标记其actual halo velocity Rₕ>0。则对0≤s<t≤1，

|S(t)∩Y|−|S(s)∩Y|
 =Σ_{i:Nᵢ=1,ℓ,σ}∫_s^t∫_{Γᵢ,ℓ,σ(v)} 1_Y(x)Rₕ dH^(n−1)(x)dv。

特别是S(0)=∅，所以

|T(1)|=Σ_{i:Nᵢ=1,ℓ,σ}∫₀¹∫_{Γᵢ,ℓ,σ(v)}1_Y(x)Rₕ dH^(n−1)(x)dv。

这是原finite-box flux measure对固定可测weight的积分，不是对∂(S∩Y)应用经典光滑boundary公式。T可能没有有限周长或polyhedral boundary；本结论不赋予它这些性质。

## 3. coarea证明：固定clips/masks分cell，再用entry map

对固定history/centers，原Lₕ以及P′、Qrep′的固定坐标面形成有限orthogonal arrangement。取其open full-dimensional cells；边界之并是Lebesgue-null。每个cell上哪些targets允许其original clip恒定，mask是否允许也恒定。只考虑mask允许的cells。

对cell中clip允许的每个实际completed key定义

θₕ(x)=max_{j∈Jₕ,ℓ} (|xℓ−uⱼ,ℓ|−cⱼ)₊/Rₕ， cⱼ=c₀sⱼ。

这来自非空box intersection的真实坐标约束，不改变key选择。令θ(x)=minₕθₕ(x)；没有可用key的cell不贡献。θ在每个此类cell上是有限Lipschitz、piecewise affine。其positive affine pieces的梯度为某一±eℓ/Rₕ，故在θ>0且可微的一般点有

|∇θ|=1/Rₕ>0。

没有positive flat piece：唯一可能的常数piece是θ=0；它属于原key core，而原core含于marked parent，已由M′排除。即使不使用此排除，初始θ=0部分也只需从volume difference中单列；本合同S(0)=∅所以没有初始项。

在mask允许cell内，S(v)正是{θ≤v}（差boundary null sets）。对非负Borel weight1_Y，coarea给

∫_{cell∩{s<θ≤t}}1_Y(x)dx
 =∫_s^t∫_{cell∩{θ=v}}1_Y(x)/|∇θ(x)| dH^(n−1)(x)dv。

再求所有有限cells。除R665已排除的有限collision参数和低维交线外，{θ=v}恰为S(v)的moving exposed faces；generic support/velocity归属使1/|∇θ|=Rₕ。固定clip/mask面只产生零速度界面，且与moving faces的一般交集H^(n−1)-null，不需给它们或Y边界添加fee。这证明第2节。

亦可先对bounded continuous weights使用有限face calculation，再用上述coarea occupation measure扩展到任意measurable weight；不能只声称“Y固定所以边界光滑/不贡献”。合法性来自entry/coarea或等价ACL/Fubini，不来自Y的boundary theorem。

## 4. a.e.代表元与trace的准确范围

对任意measurable Y，不应声称每个固定v在每个moving face上都有classical Y-trace。可选任意Borel代表元1_Y；若改动Lebesgue-null集合N，coarea保证

∫₀¹ΣΓ∫1_N(x)Rₕ dH^(n−1)dv=0。

故加权flux的integrated值与Y的Lebesgue代表无关。因有限keys的Rₕ正，a.e.v时在各正则moving faces上H^(n−1)-a.e.点也避开这些bad representatives；只有这种a.e.-in-v的面上statement可免费使用。

若要写trace，可先在每条coordinate line上取1_Y的一维Lebesgue precise representative；Fubini和一维Lebesgue differentiation排除一个ambient-null集合。在每个regular face patch，沿moving normal的坐标是affine且速度Rₕ>0，(v,transverse coordinate)→x的Jacobian为Rₕ。因此对a.e.v和H^(n−1)-a.e.面点，两侧沿该normal的平均trace存在并等于所选1_Y代表值。有限coordinate directions可同时排除null sets。无须Y∈BV，也无须它有点态topological trace。

F_Y(v)=|S(v)∩Y|是绝对连续，且在a.e.v的导数等于第2节加权face flux。事实上有限expanded boxes使|S(t)\S(s)|≤C(t−s)，所以F_Y甚至Lipschitz；任意可测权重0≤1_Y≤1保持此界。整个证明未对粗糙∂Y求surface measure或smoothness。

这些论证可先逐history/centers执行，再以nonnegative Tonelli对Poisson/auxiliary law取期望。Poisson有限horizon的总event count几乎必然有限，generic jitter条件亦几乎必然，故不存在额外概率例外预算。

## 5. R666 exact positive pressure/correction逐slice继承

固定history、globally single i、coordinateℓ、receiver x、v以及其他center coordinates，沿用R666准确记号。f(t)=1_{x∈S(v)}，b=(r/w)[f(near)−f(far)]，φ为actual i/ℓ positive axial flux，j=M(1−C)D(r/w)OI。已证

φ=b₊+j，

j≥0， OI⇒vr≤w， r(v)非减。

Y固定且不依赖center变化，所以其indicator在每个fiber中是常数。令f_Y(t)=1_Y(x)f(t)，则精确有

b_Y=1_Y b， (b_Y)₊=1_Y b₊， φ_Y=1_Y φ， j_Y=1_Y j。

正部仍在固定slice内先取，再作其他积分/期望；没有把local pressure换成global signed pressure的正部。empty eligible、parent subtraction、其他marked/repeat masks、全部covering keys及两法向均沿用不变。第2节加权flux把这项pointwise分解合法整合为

E|T(1)|=P_Y+C_Y，

P_Y=Σ_{i,ℓ}∫dx∫₀¹ E_{−(iℓ)}[1{Nᵢ=1}1_Y(x)b₊]dv，
C_Y=Σ_{i,ℓ}∫dx∫₀¹ E_{−(iℓ)}[1{Nᵢ=1}1_Y(x)j]dv。

所有x保持普通Lebesgue receiver measure；Y没有改作source law、conditioned center law或density cap。

因为0≤1_Y≤1，

0≤C_Y≤C_box≤(16/31)U， 0≤P_Y≤P_box。

所以R666薄层/双inner-threshold bands所付的16/31U全族修正无损转给T；不需Y坐标截面长度上界、perimeter或rough-boundary fee。也可直接在原付款证明的receiver空间积分中插入1_Y≤1，所有Tonelli与r(v)monotonicity步骤仍成立。

禁止把Y依赖输入误当作依赖本轮center/history：若另定义random Y(u,history)，上述fiber常数步骤一般不成立，必须另证。本任务真实near Y在原input冻结时已确定，故不受这个问题影响。

## 6. 完整费用和条件常数，不声称AU

真实near Y下的加强partial account是

(1−ετ)Vnear ≤ (Bₙ′+16/31)U+P_Y
             ≤ (11+16/31)U+P_Y。

这是所有已知费用一次支付后的精确范围；Δ不再另付，CY不再重复加入。一般all-L1恢复仍只用原Aᵢ上的q/τ packing。

若以后直接证明E|T(1)|≤A_TU（统一于全部真实inputs和n），可取

Cₙ≤C_adm[16384(23+2A_T)+K_far]√n。

若以后证明P_Y≤A_PU，则由已付correction取A_T=A_P+16/31，得到

Cₙ≤C_adm[16384(23+32/31+2A_P)+K_far]√n，

C_adm=1+e^(1/16)，K_far=2e^(33/32)。两种A的含义不可混用。若采用E|T(1)|≤ηVnear+CU，则需统一η+ετ<1才能吸收；“η<1”本身若没有总余量仍不足。

本审查未证明任何这样的A_T、A_P或strict-gain inequality。T⊂S只是更弱的充分目标，不自动形成新估计。只保留owner自己的completed target union会退化为marginal completion，不可用来替换本报告所需的所有cross-key coverage。

## 7. 新的轻量本机检查及其范围

按用户数学工具偏好，实际调用已有Python数学环境/SymPy作一个非BV receiver的exact sanity check，不运行scans。取一维Y=⋃_{m≥1}(4^(−m),2·4^(−m))，其indicator在0附近有无穷次跳跃，并非全区间BV。对单moving endpoint S(v)=(0,v)，加权terminal volume及加权endpoint flux均为

Σ_{m≥1}4^(−m)=1/3。

实际SymPy summation输出两者为1/3，断言通过。此toy仅核对“不需BV”的解释，不是实际near-input、未证明一般coarea结论，更不是U预算证据；任意Y的严格证明见第3–4节。

## 8. 有界交付

恢复式、所有fees、all-L1继承、任意固定measurable Y的加权face identity、准确a.e./trace范围以及R666正压/16U/31修正继承均已独立审清。无必须修复的数学缺口；真正P_Y或E|T|的全局U预算仍OPEN。已发送关键公式给主代理，本代理不扩展Astra攻坚目标。交付停止。

## 9. 追加有界独审：S2全mask条件计数律与式(7)–(14)

按父代理追加授权，实际读取 `S2_SHARED_GAIN.md`；SHA-256为

`117f006412e60643c51d64f184906a5aa2fa90b999ad09d3166fbcd315e18fe5`。

**结论PASS，未发现必须修正的计数律、方向或fee。** 这次S2先固定全部auxiliary centers，再仅对原Poisson law条件化；与R667先不固定centers的joint void law是两个相容的disintegrations，不可把条件后的center law错误换回原uniform再省掉W_x权重。S2所有receiver积分确实使用原center law下的W_x因子，未犯此错。

对固定x，C_x={x∈Aᵢ′}、D_x={x∈Q(uᵢ,2c₀sᵢ)}是全族sets，C_x⊂D_x。完整mask允许事件恰为C_x上Nᵢ=0、D_x\C_x上Nᵢ≤1、D_x外不限，故

W_x=e^(−8G_x)∏_{D_x\C_x}e^(−8qᵢ)(1+8qᵢ)， G_x=Σ_{C_x}qᵢ。

条件后counts仍跨label独立；C_x为0、D_x\C_x为独立Bernoulli(8qᵢ/(1+8qᵢ))、其余仍原Poisson。这里保留整个[0,8]的count，包含完成后的未来events；不存在predictable pruning替代。

Iₕ⊂D_x成立，但其依据须保留真实witness合同：zₕ∈Aₕ、x∈Xₕ⊂Bₕ，因此||x−zₕ||∞≤c₀sₕ；每个i∈Iₕ有zₕ∈Aᵢ⊂Aᵢ′及sᵢ≥sₕ。于是x∈Aᵢ′+c₀sₕQ⊂Q(uᵢ,2c₀sᵢ)。这不是对任意pool的断言，且不使用Xₕ的boundary regularity。由同一witness和原clip，owner target只要实际完成，其真正first-k key就覆盖x，不受chronological label顺序影响。

式(7)独立核对：在G_x≤τ/16时，Σ_{Iₕ\C_x}qᵢ>7τ/16；原cap给8qᵢ≤8a^(−n)≤1/4，所以μ>(8/(5/4))(7τ/16)=14τ/5。k≤2τ+1≤9τ/4，μ>k。

式(8)独立核对：Bernoulli Chernoff下界指数为

((14/5−9/4)²/(2·14/5))τ=(121/2240)τ，

且121/2240−1/20=9/2240>0。使用Z<k而由Z≤k的Chernoff界上放松合法；ceil(k)没有漏项。指数方向正确。

式(9)因此是低marked-load区域的高completion概率下界，不是所需T的upper payment。式(10)以Markov及∫G_x≤Σqᵢ|Aᵢ′|=c₀ⁿU给16c₀ⁿU/τ，合法使用原qᵢdᵢ=|Fᵢ|，没有新auxiliary owner-capacity假设。

式(11)的左右方向正确：T⊂Y\M′，而owner成功给T的lower coverage；低load缺口≤e^(−τ/20)Vnear，高load缺口至多式(10)。原unconditional owner completion还直接给更小缺口ετVnear，因为{void且owner未完成}⊂{owner未完成}，不需它们独立。所以S2正确说明(11)不是新的receiver预算改进。

式(12)–(13)正确使用δ(z)=z−log(1+z)∈[0,z²/2]和1−e^(−Σδ)≤Σδ：

0≤e^(−8G_x)−W_x≤32Σ_{D_x}qᵢ²。

积分Y并上放到全部expanded parents得32Σqᵢ²(4c₀sᵢ)ⁿ≤32(2c₀/a)ⁿU。这正是已付repeat-union fee，不能再次加入Bₙ′。它不认证剩余marked-load空间积分的U界。

式(14)也正确：T_own与T使用同一个global mask，前者pathwise包含于后者；其差只能落在实际owner未完成的receiver上，故0≤E|T|−E|T_own|≤ετVnear。cross-key rescue不能作为独立负terminal contribution。S2对mechanism的失败处分准确，没有将它解释成AU、不可能性定理或大Vnear/U构造。

## 10. R662历史范围定位：完整I候选已被更强结论包含

只按R662路径定位并读取相关命题，没有重读全历史。来源为：

- `/Volumes/data/CodexTemp/centered-cube-r662-20261115/REPORT.tex`，结论式(1)、near应用式(7)、`Common-point cumulative volume and sample minimum` 小节式(8)。实读SHA-256：`0a5e929166066e4c9e1c0cf3b0fad93fbc64b464522caf14e705631e159f2770`。
- 同目录 `AUDIT_INTERSECTION.md`，及其末尾“范围补充：取消预设尺度上界”。实读SHA-256：`895588117e230868780d45a0ef591613252adc4c15d1f5c93f6ff098c864d62e`。

R662的已证准确范围是：n≥256，有限原共点parents Aᵢ=Q(yᵢ,sᵢ)，sᵢ≥r>0，真实不交Fᵢ⊂Q(yᵢ,sᵢ/a)，qᵢ=|Fᵢ|/(2sᵢ)ⁿ，T=Σqᵢ≥8192√n，c=c₀ⁿ。对任意integer m≥2T/c，以原真实label law qᵢ/T iid有放回抽m次，有

E| (∩_{ℓ≤m}Aᵢℓ)+c₀rQ |
≤U_I exp(100n/m−T/8)。

主报告最终statement已不要求sᵢ≤nr，独审末节也明确原证明的sample-minimum、lens、tail及全L拼接不使用这个上界。近尺度窗口只对其feasibility bound T≤c(1+nlogn)及小维空域说明必要；不能把空域说明移植到无尺度上界的一般族。

现在令K_I=∩_{i∈I}Aᵢ，W=|K_I+c₀rQ|。完整K_I包含于每次sampled intersection的反向关系必须写准：

K_I ⊂ ∩_{ℓ≤m}Aᵢℓ，

所以对每个m直接有固定实数

W≤U_I exp(100n/m−T/8)。

对这些数值upper bounds取inf、令m→∞，立即得到

W≤U_I e^(−T/8)<U_I。

无需交换任何随机变量极限或积分；即使部分qᵢ=0使其从sample law中省去，完整K_I只会更小，包含关系仍成立。这个推论比Astra候选“高T强迫W≤U_I”更强，且所需几何、scale累计容量与真实Fi条件已在R662同一证明中覆盖。

对本轮实际near池，r=sₕ、T>τ/2=8192√n，n≥256时直接满足R662范围；其报告式(7)甚至已对实际k给E(sampled halo)≤U_Ie^(−τ/32)，同样立即上界完整W。n<256的实际near branch在原sᵢ<nsₕ窗口及chosen threshold下已被该报告证明为空。因此本轮实际near合同中的候选没有新增范围或新局部预算。

必须保留两项区别：

1. 上述W是**完整原I交集**，不能替换成某次first-k prefix或选中key。完整交集比prefix交集小，故W是后者的lower quantity；给完整W上界不会自动给实际sampled/pinned/primed union上界。
2. 即使每个I分别有此强界，也没有Σ_I U_I≤CU。跨pools可重复使用同一source mass，局部discount不能无证拼成全族U预算。该缺口在R662报告的历史scope表中已明确。

因此不值得继续重证本实际near范围下的较弱W≤U_I；除非提出并核对明确超出旧定理的新范围或joint-payment结论，当前候选应作历史去重而非本轮新进展。本审查不扩展该局部证明。

## 11. 本轮主报告完整账目与scope定点审核

按追加授权实际读取R668 `REPORT.tex`，本次实读SHA-256：

`edd716bb778adb1e4532d91e7e5608f01d17fb187f52af7e94fe400623f1ddca`。

**主公式、总账、常数与证据scope PASS；无必须修正的数学公式。**

恢复bracket `(1−ε)V−Bₙ′U≤E|T1|≤V`方向正确；ηV+CU只有η+ε<1时才可吸收。measurable-Y部分使用原S′faces×1_Y及coarea，未声称T有smooth/BV边界。E|T|=P_Y+C_Y、C_Y≤16U/31与complete `(11+16/31)U+P_Y`只付一次；没有二次Δ或repeat fee。

直接T预算A_T对应23+2A_T；P_Y预算A_P须用A_T=A_P+16/31，条件常数与既有恢复一致。全mask race、14/5、121/2240及repeat fee方向与第9节相同。其有限Fraction/tiny non-BV sanity check均限定为诊断，未替代全维capacity或actual high-load geometry；本代理没有重复S2已执行计算。

主报告当前末节明确暂为draft，等待Astra bounded checkpoint与独审整合。最终提交前需要把draft状态改为实际完成状态，并在新增历史去重段准确保留R662的n/T阈值、原parent/完整I范围，以及不能跨I相加的缺口；这属于最终整合所需scope更新，不是现有公式错误。若仅声称完整W≤U_I，应明示其为R662更强定理的直接推论，不列作R668新付款。

本次只追加本S1文件，未改S2或主稿。所有授权的条件律/费用审查及历史范围定位已完成；无新AU、无跨I付款、无一般结论闭合。交付后停止。

## 12. 最后有界A1独审：Hall、triangular load与exterior allocation

实际读取A1_RECEIVER_BUDGET.md，SHA-256：

`2e9ecdb422ada7775bef80035fe891171bb47307d79a658e2afc2c0dc343ad3a`。

**§2–5数学结论PASS；没有新AU。**

§2的finite-network statement准确：对C≥0、真实demands |Xₕ|与source capacities |Fᵢ|，存在supported-on-Iₕ的非负transfers、每target需求全付且每source最多C|Fᵢ|，等价于对每个target subset H的distinct-neighbor cut inequality。必要性由求和；充分性由finite max-flow/min-cut，adjacency edges取total demand容量即可使任何违反adjacency的cut不成为小于total demand的obstruction。零demand/零capacity先略去，空cut无问题。这里的“equivalent”只针对所定义网络，不是说Hall-cut是原maximal theorem的必要研究目标；A1明确这是possibly stronger的充分路线，范围正确。

§3的N_r时间顺序正确。实际saturation pool满足每个i∈Iₕ都早于h。若H={h₁<⋯<h_m}，则N_r=⋃_{j≤r}Iₕⱼ的每个distinct source都早于h_r，故在真实Xₕᵣ⊂Lₕᵣ上，Σ_{i∈N_r}qᵢ1_Aᵢ≤Σ_{i<h_r}qᵢ1_Aᵢ≤1（a.e.）。不能把N_r任意换成包含未来populations的union；作者未这样做。式(3.4) Tₕ^out=Tₕ−Σ_{Iₕ}qᵢ1_Aᵢ≥Tₕ−1>τ/2−1也正确，分母严格正。

§4的canonical exterior transfer对i∈Iₕ定义、否则0；它是确定性的actual receiver积分，且Σ_{i∈Iₕ}zₕᵢ=|Xₕ|。对positive-capacity source qᵢ>0，source ratio准确等于(1/dᵢ)Σ_{h:i∈Iₕ}∫_{Xₕ∩Aᵢ^c}1/Tₕ^out。真实Xₕ不交，所以可把这些receiver积分组成Yᵢ而没有multiplicity；actual witness几何给Yᵢ⊂Q(yᵢ,(1+c₀)sᵢ)。whole-annulus上界因而为

[((1+c₀)ⁿ−1)/(τ/2−1)]。

n和scale因子没有漏项；这个capacity本身仍exponential，不是绝对C。非exterior transfer的2(1+c₀)ⁿ/τ粗界也准确。没有使用auxiliary center density或primed packing。

§5完整原K_I的cover范围也准确：zₕ∈∩_{i∈Iₕ}Aᵢ=K_I，且x∈Xₕ⊂Bₕ、zₕ∈Aₕ，所以||x−zₕ||∞≤c₀sₕ=Rₕ；于是Xₕ⊂zₕ+RₕQ⊂K_I+RₕQ。结合第10节已定位R662范围可给实际near cover的δτ=e^(−τ/32)U_I，甚至可用更强e^(−T_I/8)U_I。这里是原parents的完整intersection，不是primed intersection或任意prefix。

对H求和只得到δτΣ_i m_i(H)|Fᵢ|，不能把multiplicity省成distinct-neighbor sum；A1正确保留此缺口。其抽象distinct-neighborhood rational诊断明确缺少actual geometry/admission，不被当作实际counterexample或证明方法不可能；本代理未重复该有限计算。

## 13. 最终主报告初读与两个需显式补回的定义域

完整实际读取整合后REPORT.tex，SHA-256：

`bb30b0124fe825f20988c8cdd54c4a9ffc7f512ae9bc239e7b7c311ee144f09a`。

全部主数学结论、总账、R662实数upper-bound取inf、全子集Hall量词、N_r、exponential annulus cost及未闭合scope均PASS。末节已移除draft，未把任何局部/diagnostic包装为新AU。

压缩A1到主报告时有两个定义域需要明确补回，已通知主代理：

1. canonical zₕᵢ积分只对i∈Iₕ定义，其他i的zₕᵢ=0；否则书面公式看似给非邻居也转账，不能支持“每demand恰好分配”的断言。
2. per-source ratio (Σₕzₕᵢ)/(qᵢdᵢ)只对qᵢ>0使用；qᵢ=0来源transfer为0，不作0/0。

A1原文的supported定义与discard-zero上下文已有这些限定；这是主报告需要保留的精确定义，不改变任何估计或常数。等待最小范围修复后仅绑定最终哈希，不延伸任务。

## 14. 最终定义域修复核对与签署

已实际读取主报告最后两项最小修复：zₕᵢ仅在i∈Iₕ时按积分定义、否则0；zero-capacity来源不转账，ratio仅对qᵢ>0使用。修复准确，无公式/费用更改。

最终实际读取REPORT.tex SHA-256：

`a265919cdbe682ef7cf2b36040cc47f42ff6aed8c99c8595be00f88d39bf8841`。

A1实际读取版本保持第12节哈希：

`2e9ecdb422ada7775bef80035fe891171bb47307d79a658e2afc2c0dc343ad3a`。

**最终审查PASS，无剩余必须修改项。** Receiver restriction/coarea、S2条件race、R662历史去重、Hall充分路线、ordered N_r及exterior allocation均保留准确量词与未付费用。没有新增全局AU或closure。只追加本S1；不spawn/Git/PDF/MATLAB，不重复已过计算。授权审核完成，交付停止。
