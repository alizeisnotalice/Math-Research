from pathlib import Path
import ast, hashlib, json, re
p=Path(__file__).resolve().parent
ast.parse((p/'REPRO_CHECK.py').read_text())
ast.parse((p/'verify.py').read_text())
r=json.loads((p/'REPRO_RESULT.json').read_text())
assert r['pass'] and r['count_configurations']==8
assert r['script_sha256']==hashlib.sha256((p/'REPRO_CHECK.py').read_bytes()).hexdigest()
s=(p/'REPORT.tex').read_text()
assert s.count(r'\begin{document}')==s.count(r'\end{document}')==1
assert sorted(re.findall(r'\\begin\{([^}]+)\}',s))==sorted(re.findall(r'\\end\{([^}]+)\}',s))
assert 'remains a draft' not in s
for name in ('REPORT.tex','A1_RECEIVER_BUDGET.md'):
    digest=hashlib.sha256((p/name).read_bytes()).hexdigest()
    assert digest in (p/'S1_RECEIVER_SCOPE.md').read_text(), (name,'missing final audit binding')
manifest=p/'MANIFEST.json'
if manifest.exists():
    for name, record in json.loads(manifest.read_text())['members'].items():
        b=(p/name).read_bytes()
        assert len(b)==record['bytes']
        assert hashlib.sha256(b).hexdigest()==record['sha256']
print(json.dumps({'pass':True,'scope':'artifact integrity, syntax, saved exact-check record and audit bindings only; not a proof verifier','manifest_checked':manifest.exists()}))
