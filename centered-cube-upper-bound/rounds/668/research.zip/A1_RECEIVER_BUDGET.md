# R668 A1 — actual receiver allocation: the precise unpaid joint capacity

## Bounded checkpoint

No new absolute AU payment or uniformly absorbable epsilon V_near+CU estimate has been proved in this task. The actual-receiver formulation is weaker than the whole-halo target and is legitimate, but it does not make the terminal receiver mass small by itself. The useful outcome of this checkpoint is an explicit, finite, jointly quantified source-allocation criterion, together with the exact triangular admission constraints available to attack it. The existing single-population geometric fee remains stronger than the local estimate independently considered here; that local proof was stopped after the inherited result was identified.

All original q_i, I_h, s_h, saturation witnesses, original L_h, true disjoint X_h, full shared first-k lists and global future-repeat pruning are retained. The only receiver is Y=union of actual near X_h. No own-key-only replacement of the union, independent-key selection, new source law, or regularity assumption on X_h is used.

## 1. Terminal accounting fixes what a strict gain must mean

Let M′=P′ union Q′_rep and

    T(v)=(Omega′_k(v) intersect Y) minus M′.

The inherited completion bound and the paid whole marked/repeated unions give

    (1−eps_tau)V_near − B′_n U ≤ E|T(1)| ≤ V_near,
    eps_tau=e^(−tau/4),     B′_n<11.                       (1.1)

Consequently, an estimate E|T(1)|≤epsilon V_near+CU with epsilon+eps_tau<1 must exclude a large V_near/U state through the actual geometry or source capacity. More alternative covering keys do not directly shrink T(1): adding keys increases the union, and the completed own targets already cover nearly all true receivers. Cross-key rescue can redistribute the time/face account and help a source allocation, but a reduction in an intermediate pivotal count is not itself a terminal epsilon gain.

In particular, a direct deterministic V_near≤C U estimate would suffice and would retain the general original scope. The remainder of this note specifies one stronger source-local route to such an estimate; it does not assert that this route is necessary for the original theorem.

## 2. A finite joint allocation criterion, with every target-subfamily quantifier

Write d_h^rec=|X_h| and b_i=|F_i|=q_i d_i. Discard zero-demand targets and zero-capacity sources where appropriate. Construct a finite bipartite graph with target h connected to source i exactly when i∈I_h. For a proposed constant C, consider nonnegative transfers z_hi satisfying

    Σ_{i∈I_h} z_hi = d_h^rec                 for each near h,
    Σ_{h:i∈I_h} z_hi ≤ C b_i                for each source i.       (2.1)

These are deterministic transfers of the actual receiver mass to the actual disjoint owner volumes. If (2.1) holds, summing it immediately yields V_near≤CU, without any further Poisson, scale or dimensional fee.

For this graph, (2.1) is equivalent to the following finite family of inequalities:

    For EVERY subset H of the actual near targets,
    Σ_{h∈H}|X_h| ≤ C Σ_{i∈N(H)}|F_i|,
    N(H)=union_{h∈H} I_h.                                 (2.2)

Each source label is counted once on the right, even when it lies in many I_h. The equality of the left side with the receiver-union measure uses the actual disjointness of X_h.

Necessity follows by summing (2.1) over H. Sufficiency is the finite max-flow/min-cut theorem: give each source vertex capacity Cb_i from the network source, connect it to its adjacent target vertices with capacity at least total demand, and give each target its demand edge to the sink. Every finite obstructing cut is exactly a target subset H whose total demand exceeds its distinct-neighbor source capacity. Thus no target-subset quantifier may be omitted.

An absolute C satisfying (2.2) for all actual inputs is **unproved here**. It is a checkable sufficient allocation proposition. It can be stronger than the original total-budget claim, because it requires using only each target's own population I_h and requires every subset cut to be payable by its neighbor sources. Arbitrary extra source capacity elsewhere in the family is unavailable to this particular network. Failure of this proposed network criterion in an actual input would not by itself disprove the original theorem or the full shared-key approach.

## 3. What the actual admission gives jointly

The source-owner and source-center facts available beyond a fixed-target random-intersection estimate are

    F_i⊂B_i,  the F_i are disjoint,  |F_i|=q_i d_i,
    Σ_{j<i} q_j 1_{Q(y_j,c0s_j)}(y_i)≤1,                   (3.1)

and, on each true receiver,

    x∈X_h⊂L_h  ⇒  Σ_{i<h}q_i1_{A_i}(x)≤1.                 (3.2)

These are original-parent/source statements. No enlarged primed-parent packing is inferred.

For an ordered target subfamily H={h_1<…<h_m}, put

    N_r=union_{j≤r}I_{h_j}.

All labels in N_r precede h_r, so the genuinely joint triangular constraint is

    for a.e. x∈X_{h_r},    Σ_{i∈N_r}q_i1_{A_i}(x)≤1.       (3.3)

This sums distinct labels across all earlier populations at once. It is not merely a separate load bound for each I_h. The original source-center admission (3.1) similarly relates source locations across those populations in their actual order. A proposed geometric or finite model must keep these constraints; matching only individual T_h and common witnesses is insufficient.

For the own population, (3.2) gives a useful exact exterior-incidence statement:

    T_h^out(x):=Σ_{i∈I_h}q_i1_{A_i^c}(x)
      ≥T_h−1>tau/2−1,         a.e. x∈X_h.                  (3.4)

Almost all of the large source rate at a receiver therefore comes from parents which do not contain that receiver. This is where admission acts in the simplest actual allocation; it prevents paying the high source rate by pretending those receivers lie inside their source parents.

What is still missing is an inequality converting the triangular constraints (3.1)–(3.3), exterior incidences (3.4), common witnesses and comparable actual scales into the distinct-neighbor capacity cuts (2.2), or into a weaker global allocation that pays the full receiver mass. No such conversion has been proved in this task.

## 4. The canonical exterior allocation exposes the unpaid spatial ratio

The actual inequalities do provide a concrete feasible allocation before source capacities are imposed:

    z_hi := ∫_{X_h} q_i1_{A_i^c}(x)/T_h^out(x) dx
            if i∈I_h, and zero otherwise.                 (4.1)

Equation (3.4) makes the denominator positive, and summing over i gives exactly |X_h|. No random key or auxiliary center is involved. Define the disjoint receiver union incident to source i by

    Y_i=union_{h:i∈I_h}X_h.

The inherited actual own-target geometry gives X_h⊂A_i+R_h Q for i∈I_h, with R_h=c0s_h≤c0s_i. Therefore

    Y_i⊂Q(y_i,(1+c0)s_i).

The exact source-capacity ratio of (4.1) is

    (Σ_h z_hi)/(q_i d_i)
      = (1/d_i) Σ_{h:i∈I_h}∫_{X_h∩A_i^c} 1/T_h^out(x) dx.       (4.2)

Its immediate whole-annulus bound is only

    (Σ_h z_hi)/(q_i d_i)
      ≤ [(1+c0)^n−1]/(tau/2−1).                           (4.3)

Thus this allocation is valid but does not close the desired absolute capacity. Every n and scale factor is visible: (4.3) is exponential in dimension before division by tau≈sqrt(n). There is no hidden owner-density replacement. A successful modification must improve the collective charges in (4.2), or use a different allocation, by exploiting actual overlap and (3.3); simply inserting the exterior condition into a per-source whole-parent envelope does not pay the missing fee.

The weaker non-exterior allocation z_hi=|X_h|q_i/T_h likewise gives at best 2(1+c0)^n/tau. The exterior allocation shows exactly what (3.2) contributes beyond that bound and why it still falls short.

## 5. The inherited strong single-population result does not sum over different populations

The parent and the assigned historical-audit Sol identified that R662 already controls a completed-population outer body more strongly than the tentative local argument considered in this task. Its all-samples intersection inequality permits an arbitrarily large sample size; the full population intersection is contained in every sampled intersection. Taking that limit gives an exponential-in-T local fee. The reported actual-near consequence is an outer-cover fee at most

    delta_tau Σ_{i∈I_h}|F_i|,    delta_tau=e^(−tau/32),      (5.1)

for the relevant complete-population cover of X_h. The local AMGM/cumulative-scale proof under consideration here was stopped because even its intended fee |cover|≤Σ_{i∈I_h}|F_i| is weaker than (5.1).

Neither statement pays repeated use of the same source across different I_h. Summing any bound of the form (5.1) over a target subfamily H produces

    Σ_{h∈H}|X_h|
      ≤delta_tau Σ_i m_i(H)|F_i|,
    m_i(H)=#{h∈H:i∈I_h},                                  (5.2)

whereas the required network cut is CΣ_{i∈N(H)}|F_i|. Identical-population target groups can sometimes be collapsed geometrically and paid once; that does not control m_i across distinct overlapping populations. A uniform bound on this multiplicity or a summable replacement using the actual geometry is not supplied by the single-population estimate.

The full shared first-k process does not itself turn m_i uses into independent source fees. Different target populations can share most of their early events, and distinct prefixes can still share the same pivotal labels. Conversely, adding genuinely alternative keys increases the terminal receiver union. An admissible rescue argument must therefore establish a real source-capacity consequence, not merely show that many target keys differ.

## 6. Frozen finite check: local exponential fees do not imply the joint cut abstractly

The sole numerical decision here was whether arbitrarily strong per-population fees, even for distinct source neighborhoods and disjoint receiver demand atoms, logically suffice to remove source reuse without another geometric input. The following exact rational check confirms that they do not. It is an abstract incidence diagnostic, **not an actual near-family counterexample**: it does not claim the original geometric admission, real q/scale relation or witness conditions.

Take one common source of capacity 1 and N private sources of capacity eps=1/N². Target h is adjacent to the common source and its own private source, so all neighborhoods are distinct. Give each target demand delta=1/16. Every local fee demand≤delta times its incident source capacity holds. But all-target demand is N/16 and distinct-neighbor capacity is 1+1/N, which forces a Hall constant N²/[16(N+1)]. By increasing N this ratio is unbounded. The same construction works with any fixed positive local factor delta by increasing N.

The following code was actually executed using local python3; it uses exact Fraction arithmetic and creates no experiment files:

```python
from fractions import Fraction
print('Distinct-neighborhood abstract capacity check; not an actual near input')
delta=Fraction(1,16)
for N in [16,64,256]:
    eps=Fraction(1,N*N)
    demand=N*delta
    capacity=1+N*eps
    local_ok=delta<=delta*(1+eps)
    ratios=[Fraction(m,16)/(1+m*eps) for m in range(1,N+1)]
    assert max(ratios)==ratios[-1]
    assert local_ok
    print('N=%d local_fee_pass=%s global_demand=%s distinct_source_capacity=%s necessary_Hall_C=%s' % (N,local_ok,demand,capacity,demand/capacity))
```

Actual output:

```text
Distinct-neighborhood abstract capacity check; not an actual near input
N=16 local_fee_pass=True global_demand=1 distinct_source_capacity=17/16 necessary_Hall_C=16/17
N=64 local_fee_pass=True global_demand=4 distinct_source_capacity=65/64 necessary_Hall_C=256/65
N=256 local_fee_pass=True global_demand=16 distinct_source_capacity=257/256 necessary_Hall_C=4096/257
```

This does not show that (2.2) fails for the actual construction, nor that the allocation method is impossible. It isolates the exact extra implication that remains unproved: the actual geometry and triangular admission must prevent such unpaid distinct-population reuse, or a different global mechanism must pay it. No MATLAB session was started. No new global budget is claimed, and this bounded task ends here.
