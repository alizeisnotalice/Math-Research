# R668 S2 — the actual conditional source race: exact law and a failed gain mechanism

**Conclusion.** No new `AU` payment or strict `epsilon Vnear + CU` upper bound is proved. The attempted conditional-source-race mechanism has a definite stopping point: after conditioning on *all* actual marked/repeat exclusions, the actual owner's high-load pool still completes with probability at least `1-exp(-tau/20)` at every receiver whose primed marked-source load is at most `tau/16`. Thus this race produces almost all of the surviving receiver volume; it does not produce the missing strict loss. Cross-key rescue cannot reverse that direction. The exact conditional law below retains every source and the real future-repeat mask. This is an actual-input statement, not an abstract incidence or coincident-box diagnostic.

The applicable `math-research` and `python-math` workflows were read. Scope: frozen R665 REPORT §§2–4, R666 REPORT/A2 and R667 REPORT/A2; one shared history, actual `q_i,I_h,X_h,L_h`, and independent `u_i~Unif(B_i)`. I made no file changes except this assigned note, did not spawn an agent, and did not use Git/PDF/MATLAB.

## 1. Fix the real receiver and expose the full mask before the race

Write `b=8`, `lambda_i=8q_i`, `a=32n`, `c0=1+1/a`, `tau=16384 sqrt(n)` and `k=ceil(2tau)`. Fix every auxiliary center and a receiver `x∈X_h`; the true owners are disjoint, so `h` is fixed by `x` independently of the history. Define the *global*, all-source sets

```
C_x = {i : x∈A'_i},
D_x = {i : x∈A'_i + c0 s_i [-1,1]^n}.
```

In particular `C_x⊂D_x`. These are not restricted to the owner's `I_h`, a chosen full key, earlier sources, or covering sources. The event `V_x={x∉M'}` is exactly

```
N_i=0 for i∈C_x;
N_i≤1 for i∈D_x\C_x;
no restriction for i∉D_x.                                    (1)
```

Consequently its probability over the *original* shared Poisson process is

```
W_x = exp(-8 G_x) ∏_{i∈D_x\C_x} [exp(-8q_i)(1+8q_i)],
G_x = Σ_{i∈C_x}q_i.                                         (2)
```

This calculation includes events after first-key completion. It never treats their exclusion as a predictable stopping rule. All products are finite, so `W_x>0`.

The actual common witness gives `I_h⊂D_x`. Indeed `z_h∈A_h`, `x∈X_h⊂B_h`, and hence `||x-z_h||∞≤c0 s_h=R_h`. For every `i∈I_h`, `z_h∈A_i⊂A'_i` and `s_h≤s_i`, so

```
x∈A'_i+R_h[-1,1]^n ⊂ A'_i+c0s_i[-1,1]^n.
```

More strongly, for **any** completed full first-k key of owner `h`, the same witness belongs to its full core and therefore `x` belongs to its `v=1` halo. Its original clip is satisfied because `x∈X_h⊂L_h`. No coordinate regularity or boundary property of `X_h` is used.

## 2. Exact completion law after the global future exclusions

Conditioning the independent Poisson counts on (1) preserves their independence. On `C_x` the counts vanish; on `D_x\C_x` they are Bernoulli, with

```
p_i = Pr(N_i=1 | N_i≤1) = 8q_i/(1+8q_i).                   (3)
```

For `i∉D_x` they retain their original Poisson laws. Since the owner's *entire* pool lies in `D_x`, the number of its available actual events under this conditioning is exactly

```
Z_h(x) = Σ_{i∈I_h\C_x} Bernoulli(p_i),                     (4)
```

with independent summands. The chronological first-k selection has not been replaced: the owner is completed if and only if the total number of its actual events by time 8 is at least k. Once completed, its first k events give a halo containing x by §1, whatever their times and order. Each source can occur at most once on `V_x`; this is a consequence of the real mask, not an independent-key assumption.

Writing `T_own` for owner-key coverage followed by the **same global mask**, we therefore have the exact identity

```
Pr(x∈T_own | u) = W_x Pr(Z_h(x)≥k | V_x,u),               (5)
```

and the full shared union satisfies

```
W_x Pr(Z_h(x)≥k | V_x,u)
    ≤ Pr(x∈T(1) | u) ≤ W_x.                               (6)
```

Arbitrarily many cross-owner keys and all shared dependencies are retained in the middle quantity. Formula (6) requires no independence between keys. Their rescue adds coverage to the left side.

## 3. High actual load makes the surviving race almost surely succeed

Suppose `G_x≤tau/16`. Then the actual pool load and actual cap on each source imply

```
Σ_{i∈I_h\C_x}q_i > tau/2 - G_x ≥ 7tau/16,
8q_i≤8a^(-n)≤1/4,
mu_h := E[Z_h | V_x,u]
      = Σ_{i∈I_h\C_x} 8q_i/(1+8q_i)
      > (8/(5/4))(7tau/16) = 14tau/5.                     (7)
```

Also `k≤2tau+1≤9tau/4`, since `tau≥16384`. For completeness the elementary Bernoulli Chernoff inequality used here follows from

```
E exp(-t Z_h) = ∏_i [1+p_i(e^(-t)-1)]
             ≤ exp(mu_h(e^(-t)-1))
```

and optimization, giving `Pr(Z_h≤(1-delta)mu_h)≤exp(-mu_h delta²/2)` for `0<delta<1`. Since `(mu-k)²/(2mu)` increases in `mu>k`, (7) yields

```
Pr(Z_h<k | V_x,u)
 ≤ exp[-(14/5-9/4)² tau /(2·14/5)]
 = exp(-121tau/2240)
 ≤ exp(-tau/20).                                          (8)
```

Thus at every such actual receiver, uniformly in its admitted geometry and in every auxiliary center configuration,

```
(1-exp(-tau/20)) W_x ≤ Pr(x∈T(1)|u) ≤ W_x.                (9)
```

This is a quantitative obstruction to this proposed *mechanism*, not to the desired geometric theorem. High T and the exact future-repeat conditioning do not give a strict completion deficit on the low marked-load region; they give the opposite estimate. The full radius-descending admission remains in force, but is deterministic under this conditioning and supplies no extra stochastic suppression in (3)–(8). Turning admission into a useful spatial statement is the unproved step; it cannot be supplied by changing the race law.

The high-load exceptional set is itself charged using the actual source capacity:

```
|{x∈Y:G_x>tau/16}|
 ≤ (16/tau)∫_Y G_x dx
 ≤ (16 c0^n/tau) U.                                       (10)
```

Hence the conditional-race estimate gives

```
0 ≤ E_u∫_Y W_x dx - E|T(1)|
  ≤ exp(-tau/20)Vnear + (16 c0^n/tau)U.                    (11)
```

I do not propose (11) as an improved global bound: ordinary unconditional completion already gives the smaller missing-coverage estimate `eps_tau Vnear`. Its value here is to identify the direction and size of the conditional-race effect without dropping future pruning. There is no newly paid receiver-volume upper bound.

## 4. All future-repeat effects have an already paid additive fee

For each `z≥0`, `0≤z-log(1+z)≤z²/2`, by integrating `t/(1+t)≤t` from 0 to z. Therefore (2) yields

```
0 ≤ exp(-8G_x)-W_x
  ≤ Σ_{i∈D_x\C_x} [8q_i-log(1+8q_i)]
  ≤ 32 Σ_{i∈D_x}q_i².                                    (12)
```

After receiver integration and auxiliary expectation,

```
0 ≤ E_u∫_Y exp(-8G_x)dx - E_u∫_Y W_x dx
 ≤ 32 Σ_i q_i² (4c0s_i)^n
 ≤ 32(2c0/a)^n U.                                         (13)
```

This is the existing paid repeat-union fee, recovered from the exact future-conditioned law; it is not another fee to add to `B'_n`. Thus a hoped-for substantial gain from repeat capture alone cannot be extracted without additional spatial structure. The retained full future mask has already spent only this `O(U)` amount.

Cross-key rescue also cannot make an independent negative terminal contribution: `T_own⊂T(1)` pathwise. Its possible increase is bounded by owner incompletion, so

```
0 ≤ E|T(1)|-E|T_own| ≤ eps_tau Vnear.                      (14)
```

This is consistent with the parent's terminal-direction warning. Any slice pressure saved by a rescuing key is redistributed among the other positive faces or the same final coverage; it does not produce a terminal loss for free.

## 5. Exact failure point, with no renamed objective

The attempted proof was: expose the full mask, exploit high T to obtain many potential disqualifying future sources, and then exploit shared-key replacement. Equations (3)–(9) show exactly why this route fails as a net-gain argument. The future-conditioned surviving source process still has more than enough distinct events to complete the owner's actual full key. Cross-key replacement can only increase the resulting terminal set. The only demonstrated removal due to repetitions is the already paid fee (13).

No estimate here proves that a large `Vnear/U` admitted configuration is impossible. In particular, (9) does **not** construct such a configuration, and it does not refute a spatially integrated contraction. It does show that the missing estimate must use the spatial content of admission and original owner capacity beyond the conditional source race. No integral in this note is offered as a renamed research target or as a new `AU` bound. This bounded attempt stops at that missing geometric payment.

## 6. Actual local verification and its limited scope

The calculation was fixed before execution: verify the exact independent Bernoulli-odds conditioning algebra on all eight count configurations for three test rates, then verify every rational constant in (7)–(8). These three test rates are a finite algebra diagnostic, **not** a claimed actual near family or a high-T simulation. The all-source law and inequalities have their proofs above.

Executed `/Users/zzh/.local/share/math-research-tools/venv/bin/python`; no installations or MATLAB session. Exact `Fraction` output:

```
python exact conditional-law configurations: 8
conditional completion probability: 19/1683
mean/tau lower bound: 14/5
Chernoff exponent/tau lower bound: 121/2240
chosen exponent/tau: 1/20
checks: PASS
```

Reproducer (embedded here because only this assigned file may be written):

```python
from fractions import Fraction as F
from itertools import product
from math import prod
lam=[F(1,8), F(1,16), F(1,32)]
weights={b:prod(lam[j] if b[j] else F(1) for j in range(3))
         for b in product([0,1], repeat=3)}
z=sum(weights.values())
assert z==prod(1+t for t in lam)
p=[t/(1+t) for t in lam]
for b,w in weights.items():
    assert w/z==prod(p[j] if b[j] else 1-p[j] for j in range(3))
assert sum(w for b,w in weights.items() if sum(b)>=2)/z==F(19,1683)
m=F(8)/(1+F(1,4))*(F(1,2)-F(1,16))
assert m==F(14,5)
assert (m-F(9,4))**2/(2*m)==F(121,2240)>F(1,20)
```

The Python process exited normally. The normal executor was blocked by the existing symlinked-writable-root configuration; explicitly escalated reads and this authorized research write succeeded. No configuration was changed.
