import json, sys, platform, hashlib
from pathlib import Path
from fractions import Fraction as F
from itertools import product
from math import prod
lam=[F(1,8), F(1,16), F(1,32)]
weights={b:prod(lam[j] if b[j] else F(1) for j in range(3))
         for b in product([0,1], repeat=3)}
z=sum(weights.values())
assert z==prod(1+t for t in lam)
p=[t/(1+t) for t in lam]
for b,w in weights.items():
    assert w/z==prod(p[j] if b[j] else 1-p[j] for j in range(3))
assert sum(w for b,w in weights.items() if sum(b)>=2)/z==F(19,1683)
m=F(8)/(1+F(1,4))*(F(1,2)-F(1,16))
assert m==F(14,5)
assert (m-F(9,4))**2/(2*m)==F(121,2240)>F(1,20)

import sympy as sp
j=sp.symbols('j',integer=True,positive=True)
assert sp.summation(sp.Rational(1,4)**j,(j,1,sp.oo))==sp.Rational(1,3)
capacity=[]
for N in (16,64,256):
    delta=F(1,16); tiny=F(1,N*N)
    ratios=[F(h,16)/(1+h*tiny) for h in range(1,N+1)]
    assert max(ratios)==ratios[-1]
    assert delta<=delta*(1+tiny)
    capacity.append({"N":N,"ratio":str(ratios[-1])})
result={"pass":True,"interpreter":sys.executable,"python":platform.python_version(),"count_configurations":len(weights),"conditional_completion":str(sum(w for b,w in weights.items() if sum(b)>=2)/z),"mean_factor":str(m),"chernoff_factor":str((m-F(9,4))**2/(2*m)),"arithmetic":"exact Fraction and symbolic geometric sum; no numerical tolerance","sympy":sp.__version__,"non_BV_toy_volume":"1/3","abstract_capacity_diagnostic":capacity,"scope":"finite conditioning algebra, rational constants, non-BV toy and abstract incidence diagnostic only; not an actual high-load input or general capacity proof"}
result["script_sha256"]=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
Path(__file__).with_name("REPRO_RESULT.json").write_text(json.dumps(result,indent=2)+"\n")
print(json.dumps(result,indent=2))
