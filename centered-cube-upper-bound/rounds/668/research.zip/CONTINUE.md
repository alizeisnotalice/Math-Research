# R668 continuation

General pure sqrt(n) and former n^(1/2+o(1)) upper bounds remain OPEN. No new AU budget in R668.

Retain R666 full fee and actual owner construction. R668 establishes legal restriction to fixed genuine receiver Y, not new payment: (1-eps)V <= (11+16/31)U+P_Y and ET=P_Y+C_Y, C_Y<=16U/31. Terminal bracket (1-eps)V-BU<=ET<=V means adding rescue keys cannot itself shrink final mass. Exact global-mask conditional race remains almost surely complete on the paid low-load region; stop expanding this as a loss mechanism.

R662 already implies complete-population |intersection Ai+c0rQ|<=U_I exp(-T_I/8), for n>=256,T_I>=8192sqrt(n), simply by containment and taking infimum over sample size. No random-limit interchange. Do not reprove a weaker local AMGM bound; do not substitute complete intersection for sampled/pinned union.

Unique geometric gap: distinct source capacity across overlapping actual I_h. A1 records a sufficient all-target-subset flow criterion, not a necessary equivalent to the general theorem. Actual time-order admission implies union-of-earlier-populations load<=1 on later actual receivers. Canonical exterior allocation has exact demand but still exponential annulus fee. Work on a quantitative geometric improvement of total charges, not more conditional identities, generic Hall renaming, or abstract counterexamples.

Configuration cap: 1 Astra, 3 GPT-6.1 Sol. No requirement to fill idle slots. Local tools for proof decisions only; close MATLAB after actual use. Next true research round separately audited/archived/committed/pushed. R668 compact archive contains full proof/audit/checkpoint; no PDF.
