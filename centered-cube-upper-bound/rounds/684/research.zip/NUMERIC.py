#!/usr/bin/env python3
"""R684 common-receiver continuous-envelope decision, not realizable source construction."""
def append_candidate_separation():
 from pathlib import Path
 import json,hashlib,sys,time
 from flint import arb,ctx
 ctx.prec=256;tick=time.time();root=Path(__file__).resolve().parent;dst=root/'RESULT.json';old=json.loads(dst.read_text())
 saved=hashlib.sha256(json.dumps(old['results'],sort_keys=True).encode()).hexdigest()
 checks=[]
 for L in (32,40,48,64):
  n=2**L;rootn=2**(L//2);tau=16384*rootn;M=4*tau;k=8*n
  logR=M*(1+arb(1)/n).log();RR=logR.exp()
  logerr=arb(256).log()+2*arb(n).log()-arb(n)/64
  moment_per_n=8*(arb(8)/3).log();gap_per_n=moment_per_n-logR
  assert gap_per_n>0 and logerr < -100*arb(2).log()
  if L==32:assert RR>2
  else:assert RR<2
  checks.append({'n':'2^'+str(L),'n_exact':str(n),'tau_exact':str(tau),'M_exact_ceil_4tau':str(M),'log_R':str(logR),'R':str(RR),'R_less_than_2':bool(RR<2),'log_k_squared_delta_over_tau':str(logerr),'k_squared_delta_over_tau_less_than_2_to_minus100':True,'candidate_log_lower_ratio_per_n':str(gap_per_n),'candidate_log_lower_ratio_positive':True,'source_cost_log_per_sqrt_n':str(n*logR/rootn),'candidate_high_moment_log_per_n':str(moment_per_n)})
 safe=[]
 for L in (40,48,64):
  n=2**L;a0=128*n*n;tau=16384*2**(L//2);M=4*tau
  small=arb(2)/a0;prob=(-arb(n)/18).exp()
  first=(n*(1-small).log()).exp()
  second=(n*(arb(n)/(n+1)+small).log()).exp()
  owner=first-second-prob
  target=(n*(1-arb(1)/n-small).log()).exp()-prob
  qtarget=(n*(1-arb(1)/n).log()).exp()
  log_error=arb(640).log()+2*arb(n).log()-arb(n)/64
  growth=8*(arb(8)/3).log()-arb(M)/n-arb(8).log()/n
  assert owner>arb(1)/2 and target>arb(1)/4 and qtarget<arb(1)/2
  assert log_error<-(arb(2).log()) and growth>3 and M<=5*tau
  safe.append({'n':'2^'+str(L),'a0':'128*n^2','layer_owner_fraction_lower':str(owner),'layer_owner_greater_than_half':True,'target_volume_fraction_lower':str(target),'target_volume_greater_than_quarter':True,'qtarget_upper':str(qtarget),'qtarget_less_than_half':True,'log_safe_error_upper':str(log_error),'safe_error_less_than_half':True,'growth_minus_log8_per_n':str(growth),'growth_greater_than_3n':True,'M_le_5tau':True})
 old['candidate_high_moment_separation']={'scope':'PROVISIONAL GEOMETRIC CONSTANTS. Certified scalar evaluations only; no geometric contract, actual cube construction, probabilistic error bound, or lower inequality is verified. The expression called candidate_log_lower_ratio is not a theorem.','inputs':{'tau':'16384 sqrt(n)','M':'ceil(4tau), exact4tau at these square n','R':'(1+1/n)^M','delta_candidate':'M exp(-n/64)','k':'8n','candidate_log_lower_ratio':'8n log(8/3)-n log R'},'exact_error_simplification':'k^2 delta/tau = 256 n^2 exp(-n/64) for M=4tau','checks':checks,'decision':'R<2 fails at n=2^32 and passes at 2^40,2^48,2^64. Candidate exponent is positive and candidate error ratio below2^-100 at all4. This confirms scalar exp(n) vs exp(sqrt n) separation conditional on unverified geometric inputs.','safe_constant_preparation':{'scope':'Finite certified scalar preparation at n>=2^40 only; no geometric model is independently certified. M<=5tau and W>=tau/2 are candidate construction inputs.','safe_error_formula':'640*n^2*exp(-n/64)','a0':'128*n^2, actual a assumed no smaller','checks':safe},'fixed_I_results_preserved_sha256':saved,'precision_bits':ctx.prec,'command':[sys.executable,str(Path(__file__).resolve()),'--separation-only'],'elapsed_seconds':time.time()-tick}
 old['script_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
 assert hashlib.sha256(json.dumps(old['results'],sort_keys=True).encode()).hexdigest()==saved
 dst.write_text(json.dumps(old,indent=2)+'\n')
 print(json.dumps({'candidate_checks':checks,'elapsed_seconds':time.time()-tick,'source_sha256':old['script_sha256'],'RESULT_sha256':hashlib.sha256(dst.read_bytes()).hexdigest()},indent=2))

if __name__=='__main__':
 import sys as _sys
 if '--separation-only' in _sys.argv:
  append_candidate_separation()
  raise SystemExit(0)

from pathlib import Path
from fractions import Fraction as F
from math import comb,ceil
import json,hashlib,sys,platform,time
import sympy as sp
import flint
from flint import arb,acb,ctx
ROOT=Path(__file__).resolve().parent;start=time.time();ctx.prec=128
cache={};records=[];cross=[]
def A(q):
 q=F(q);return arb(q.numerator)/q.denominator
def evaluate(n,p,h,d,bits=128):
 ctx.prec=bits;h=F(h);d=F(d);r0=1-h;rr=F(n,2)-h
 assert 0<=h<=F(1,2) and 0<d<=1 and r0>=d/2
 ar0=A(r0);ah=A(h);ad=A(d);R=A(rr);length=(R/ar0).log()
 core=ar0**n*(1-(1-ad/(2*ar0))**p)
 def fun(t,analytic):
  r=acb(ar0)*t.exp();v=1-acb(ad)/(2*r)
  bracket=1-acb(arb(p)/(2*n))*v**(p-1)-acb(arb(n-p)/n)*v**p
  radial=acb(1) if h==0 else (1+acb(ah)/r)**(-n)
  return n*radial*bracket
 parts=1 if n<1024 else 96
 shell=sum((acb.integral(fun,acb(length)*j/parts,acb(length)*(j+1)/parts,rel_tol=arb(2)**-70,abs_tol=arb(2)**-70/parts,eval_limit=20000,depth_limit=25) for j in range(parts)),acb(0))
 assert shell.is_finite() and shell.imag.contains(0)
 total=core+shell.real
 assert total>0,(n,p,str(h),str(d),str(total),str(shell))
 return total,core,shell.real
# Symbolic surface derivative at fixed ell, then substitute ell=h+r.
r,l,h,d=sp.symbols('r l h d',positive=True)
n,p=sp.symbols('n p',positive=True,integer=True)
Vinside=(r-(h+d-l))**p*(2*r)**(n-p)
surface=sp.diff((2*r)**n-Vinside,r).subs(l,h+r)/(2*(h+r))**n
expected=n*r**(n-1)/(h+r)**n*(1-sp.Rational(1,2)*p/n*(1-d/(2*r))**(p-1)-(n-p)/n*(1-d/(2*r))**p)
for nv,pv in ((2,1),(3,2),(4,4),(16,8)):
 assert sp.factor((surface-expected).subs({n:nv,p:pv}))==0
# Three bounded stages: initial small inputs; exact representative cross-checks; expanded dimensions.
stage1=[(n,p,h,d) for n in (16,64) for p in (1,n) for h in (F(0),F(1,4)) for d in (F(1,2),F(1))]
stage2=[(256,p,h,F(1)) for p in (1,128,256) for h in (F(0),F(1,4),F(1,2))]
stage3=[(n,p,h,d) for n in (1024,65536) for p in (1,n//2,n) for h in (F(0),F(1,4),F(1,2)) for d in (F(1,4),F(1))]
for stage,inputs in enumerate((stage1,stage2,stage3),1):
 tick=time.time()
 for nn,pp,hh,dd in inputs:
  key=(nn,pp,hh,dd)
  if key in cache:continue
  total,core,shell=evaluate(*key)
  row={'stage':stage,'n':nn,'p':pp,'h':str(hh),'d':str(dd),'pool':str(total),'core':str(core),'shell':str(shell),'pool_over_sqrt_n':str(total/arb(nn).sqrt()),'pool_over_n_log_n':str(total/(nn*arb(nn).log())),'precision_bits':128,'integral_method':'Arb certified complex analytic quadrature, real-axis log-radius integral','finite_certified_ball':True}
  records.append(row);cache[key]=(total,core,shell)
 print('stage',stage,'completed','new inputs',len(inputs),'elapsed',time.time()-tick,flush=True)
 # Exact analytic representative checks after the initial stage, before dimension expansion.
 if stage==1:
  for nn,pp,dd in ((16,1,F(1)),(16,8,F(1,2)),(64,1,F(1))):
   # h=0: polynomial in d/(2r) gives rational + (p/2)log(n/2).
   core=1-(1-dd/2)**pp;rat=core
   for j in range(1,pp+1):
    cj=(-1)**j*(-F(pp,2*nn)*(comb(pp-1,j) if j<=pp-1 else 0)-F(nn-pp,nn)*comb(pp,j))
    rat+=nn*cj*(dd/2)**j*(1-F(2,nn)**j)/j
   exact=A(rat)+A(F(pp,2))*arb(F(nn,2).numerator).log()-A(F(pp,2))*arb(F(nn,2).denominator).log()
   val=evaluate(nn,pp,F(0),dd,bits=192)[0]
   assert val.overlaps(exact)
   cross.append({'kind':'exact h0 polynomial antiderivative','n':nn,'p':pp,'d':str(dd),'rational_part':str(rat),'log_n_over_2_coefficient':str(F(pp,2)),'exact_evaluation':str(exact),'independent_192bit_quadrature':str(val),'overlap_passed':True})
  # h>0,p=1: z=r/(h+r) gives an exact finite-sum antiderivative.
  nn=16;hh=F(1,4);dd=F(1);z=sp.symbols('z',positive=True)
  anti=(-sp.log(1-z)-sum(z**j/sp.Integer(j) for j in range(1,nn)))/2+sp.Rational(dd.numerator,dd.denominator)/(2*sp.Rational(hh.numerator,hh.denominator))*z**(nn-1)
  assert sp.simplify(sp.diff(anti,z)-(z**(nn-1)/(2*(1-z))+sp.Rational(nn-1)*sp.Rational(dd.numerator,dd.denominator)/(2*sp.Rational(hh.numerator,hh.denominator))*z**(nn-2)))==0
  def antival(zz):return (-(1-zz).log()-sum((zz**j/j for j in range(1,nn)),arb(0)))/2+A(dd/(2*hh))*zz**(nn-1)
  ctx.prec=192;z0=A(1-hh);z1=A((F(nn,2)-hh)/F(nn,2));core=A(1-hh)**nn*(A(dd)/(2*A(1-hh)))
  exact=core+antival(z1)-antival(z0);val=evaluate(nn,1,hh,dd,bits=192)[0]
  assert val.overlaps(exact)
  cross.append({'kind':'exact hpositive p1 z-antiderivative','n':nn,'p':1,'h':str(hh),'d':str(dd),'exact_evaluation':str(exact),'independent_192bit_quadrature':str(val),'overlap_passed':True})
  ctx.prec=128
  print('exact representative checks completed',len(cross),flush=True)
out={'scope':'c0=1,a=infinity limiting continuous owner envelope at fixed I and receiver x. Not a realizable disjoint finite source construction, not an original high-threshold recursion, and not a general lower bound.','python':sys.version,'sympy_version':sp.__version__,'python_flint_version':flint.__version__,'platform':platform.platform(),'command':[sys.executable,str(Path(__file__).resolve())],'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'formula':{'I':'[-h,h]^n','receiver':'p coordinates h+d, n-p coordinates 0','ell':'max(1,h+||u||infinity)','range':'ell<n/2','density':'1{||u-x||infinity>ell}/(2ell)^n','core':'(1-h)^n*[1-(1-d/(2(1-h)))^p]','shell':'integral_(1-h)^(n/2-h) n*r^(n-1)/(h+r)^n *[1-p/(2n)*(1-d/(2r))^(p-1)-(n-p)/n*(1-d/(2r))^p] dr','surface_note':'Differentiate cube receiver-inside volume at fixed ell FIRST, then substitute ell=h+r. Differentiating a moving-threshold volume gives the wrong shell density.','piecewise_extension':'If r<d/2, the inside receiver region is empty and bracket=1. In tested h<=1/2,d<=1 this branch is absent except a boundary point.','h0_p1_exact':'d/2 + (1/2)log(n/2) + ((n-1)d/2)*(1-2/n)'},'results':records,'exact_crosschecks':cross,'summary':{'input_count':len(records),'exact_crosscheck_count':len(cross),'all_certified_balls_finite':True,'all_crosschecks_passed':True},'elapsed_seconds':time.time()-start,'errors':[],'prior_execution_note':'Initial launch stopped before integration because SymPy did not reduce the general symbolic integer-power identity to literal zero; exact rational-function checks at (n,p)=(2,1),(3,2),(4,4),(16,8) replace that simplifier-dependent assertion. A second launch caught a missing outer complement in the independent hpositive p1 core expression; the primary quadrature core formula was correct and the cross-check expression was repaired. A large-n unsplit ball was uninformatively wide because r/r was evaluated with interval dependency; h0 radial factor is now exactly1 and large-n log-radius integration is split into96 short pieces.'}
(ROOT/'RESULT.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'script_sha256':out['script_sha256'],'summary':out['summary'],'elapsed_seconds':out['elapsed_seconds'],'RESULT_sha256':hashlib.sha256((ROOT/'RESULT.json').read_bytes()).hexdigest()},indent=2),flush=True)

append_candidate_separation()
