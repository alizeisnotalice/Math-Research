# R684 continuous receiver envelope and provisional scalar separation

## Decision and scope

The common receiver boundary alone does not reduce the specified limiting continuous owner envelope to order sqrt(n). There is an exact linear-n example already with one active receiver coordinate when h=0. With a positive fixed intersection, all n active coordinates still give a linear-n envelope. These statements concern the density relaxation at c0=1; they are not realizable-source lower bounds.

The later scalar checks confirm the proposed exp(n) high-moment versus exp(sqrt(n)) source-cost separation numerically, conditional on geometric constants still under audit. The restriction R<2 fails at n=2^32, so the prepared range starts at n≥2^40. No actual construction or general lower theorem is certified here.

## Fixed-I envelope formula

Set `N=n/2`, `I=[−h,h]^n`, and x with p coordinates equal to h+d and the other coordinates zero. For an owner point u let `r=||u||infinity`, `ell=max(1,h+r)`. The density being integrated is

`1{ell<N, ||u−x||infinity>ell}/(2ell)^n`.

The tested ranges are `h=0,1/4,1/2`, `d=1/4,1/2,1` as specified in the bounded stages, so `r0=1−h≥d/2`. In the core r≤r0, ell=1 and the exact contribution is

`core=r0^n[1−(1−d/(2r0))^p]`.

On a shell with ell fixed, the receiver-inside part of the cube [−r,r]^n has volume

`[r−(h+d−ell)]^p(2r)^(n−p)`

when its active-coordinate threshold lies between the faces. Differentiate this volume with respect to r **while holding ell fixed**, then substitute ell=h+r. This gives the shell integral

`∫_(r0)^(N−h) [n r^(n−1)/(h+r)^n]`

`  ·[1−p/(2n)(1−d/(2r))^(p−1)−(n−p)/n(1−d/(2r))^p] dr`.

If r<d/2, the receiver-inside part is empty and the bracket is one. That branch is absent in the tested range except for a boundary point. Differentiating the outside volume after inserting the moving ell=h+r threshold would give an incorrect surface term.

With t=log(r/r0), certified quadrature uses the analytic integrand

`n [r/(h+r)]^n [same bracket]`.

For h=0 its radial factor is set to the exact value one, avoiding interval dependency. For n≥1024 the log-radius interval is split into 96 short pieces. These are one-dimensional analytic integrals, not grids of owner points.

## Exact representative checks and envelope size

For h=0,p=1 the result simplifies exactly to

`pool=d/2+(1/2)log(n/2)+((n−1)d/2)(1−2/n)`.

At d=1 this grows as n/2. Three h=0 examples are independently checked by exact polynomial antiderivatives, consisting of one rational number plus `(p/2)log(n/2)`. A positive-h,p=1 example is checked by the substitution z=r/(h+r), whose primitive is

`(1/2)[−log(1−z)−Σ_(j=1)^(n−1) z^j/j]+[d/(2h)]z^(n−1)`.

SymPy verifies the finite-sum derivative. All four exact expressions overlap independent 192-bit certified quadrature balls.

There is also a simple analytical decision for positive h and p=n. The shell bracket is at least 1/2. On `[n/4,n/2−h]`, `(r/(h+r))^n≥exp(−4h)`. For the tested n≥16 and h≤1/2, this interval is inside the shell range and the ratio of its endpoints is at least 3/2. Therefore this limiting envelope satisfies

`pool≥(n/2)exp(−4h)log(3/2)`.

This is a lower bound for the **specified continuous relaxation only**. It proves that this relaxation cannot itself furnish a uniform sqrt(n) pool upper bound. It does not establish a compatible collection of original source cubes or disjoint finite owners at the envelope density.

Selected computed ratios follow; displayed centers are approximate and full certified balls are retained in RESULT.json.

| n | p | h | pool/sqrt(n) | pool/[n log(n)] |
|---|---:|---:|---:|---:|
| 16 | 1 | 0 | 2.025555 | 0.182641 |
| 64 | 1 | 0 | 4.093562 | 0.123037 |
| 256 | 1 | 0 | 8.089370 | 0.091176 |
| 1024 | 1 | 0 | 16.066254 | 0.072433 |
| 65536 | 1 | 0 | 128.016401 | 0.045090 |
| 65536 | 65536 | 0 | 2633.607936 | 0.927611 |
| 65536 | 65536 | 1/4 | 130.500235 | 0.045965 |
| 65536 | 65536 | 1/2 | 49.903154 | 0.017577 |

The staged run contains 61 bounded inputs across n=16,64,256,1024,65536 and four exact cross-checks. All final balls are finite and positive. Total successful run time was about 1.04 seconds; the expanded integration stage itself took about 0.16 seconds. It had already finished before the instruction to stop fixed-I expansion arrived; no further integrations were run afterward.

The limiting assumption c0=1 corresponds to a→infinity. These numerical envelope values do not directly transfer to a finite-a construction. The original parent/source containment, positive owner volume, center admission, historical cores and high-threshold recursion would all need their own verification. In particular the h=0 example is a degenerate common intersection benchmark, not a positive strict-core realization.

## Provisional high-moment/source-cost scalar checks

The subsequently requested scalars are

`tau=16384sqrt(n)`, `M=ceil(4tau)`, `R=(1+1/n)^M`,

`delta_candidate=M exp(−n/64)`, `k=8n`.

At the four tested square dimensions M=4tau exactly. The candidate logarithmic ratio is

`8n log(8/3)−n log R`.

This is a scalar expression, not an established lower bound from geometry. Its certified values divided by n are:

| n | R | R<2 | candidate log ratio/n |
|---|---:|---|---:|
| 2^32 | 2.718282 | **no** | 6.846634 |
| 2^40 | 1.064494 | yes | 7.784134 |
| 2^48 | 1.003914 | yes | 7.842728 |
| 2^64 | 1.000015 | yes | 7.846619 |

The early n=2^32 range fails R<2 and is explicitly retained as a range correction. At all four dimensions the candidate error simplifies exactly to

`k² delta_candidate/tau=256n²exp(−n/64)`

and is certified below 2^−100. Meanwhile `n log R/sqrt(n)` is approximately 65536, whereas `8log(8/3)≈7.846634` is a positive constant. Thus the candidate high-moment exponent is of order n and source cost exponent of order sqrt(n). This separation is conditional on the still-unverified geometric interpretation.

## Safer scalar constant preparation for n≥2^40

The subsequent conservative error envelope is

`640n²exp(−n/64)`

using the candidate inputs M≤5tau and W≥tau/2. At n=2^40,2^48,2^64, 256-bit Arb checks use `a0=128n²` (with actual a assumed no smaller) and certify

`(1−2/a0)^n−(1/(1+1/n)+2/a0)^n−exp(−n/18)>1/2`,

`(1−1/n−2/a0)^n−exp(−n/18)>1/4`,

`(1−1/n)^n<1/2`,

`640n²exp(−n/64)<1/2`,

`8nlog(8/3)−M−log8>3n`.

| n | layer owner lower | target volume lower | qtarget upper | last growth expression/n |
|---|---:|---:|---:|---:|
| 2^40 | 0.632121 | 0.367879 | 0.367879 | 7.784134 |
| 2^48 | 0.632121 | 0.367879 | 0.367879 | 7.842728 |
| 2^64 | 0.632121 | 0.367879 | 0.367879 | 7.846619 |

All scalar comparisons pass. These are finite preparations for analytic constants, not independent certification of the proposed model, error probability, realized lower bound, or all-dimensions inequalities. No enormous source family or geometric grid was generated.

## Reproducibility

The original integral command is the saved NUMERIC.py with the specified Python interpreter. Later scalar checks use an append-only mode:

```text
/Users/zzh/.local/share/math-research-tools/venv/bin/python /Volumes/data/CodexTemp/centered-cube-r684-20261116/NUMERIC.py --separation-only
```

The append mode preserves all 61 integral records and four exact cross-checks. A canonical hash of the integral records is saved. Python/SymPy/python-flint versions, precise inputs, certified balls, code hash and commands are in RESULT.json. Quadrature uses 128-bit working precision with tolerance 2^−70; independent antiderivative checks use 192 bits and the scalar append uses 256 bits.

Source SHA-256: `df41cbe1c29c399561ddc9f2d98b47eb91c97dc4b2dc5eba4e02bd2411206907`. Result SHA-256: `01884d5f9f1b4fc6ea14e4329f944e2f016a872c716bf94baa1adc68970b4547`. The final scalar append completed normally in under 0.01 seconds. Earlier failed launches were retained in the execution note: a symbolic simplifier limitation, a corrected complement in the independent positive-h check, and an uninformatively wide unsplit interval evaluation. None is counted as numerical evidence. Final checks all passed and the Python process exited.

No MATLAB, PDF, Git, child agent, package installation, Monte Carlo sample, or exponential geometric grid was used.
