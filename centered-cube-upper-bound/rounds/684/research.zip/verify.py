#!/usr/bin/env python3
"""Independent scalar and delivery checks, not a numerical construction of the huge family."""
from pathlib import Path
from fractions import Fraction as F
from math import isqrt
import json,hashlib
from flint import arb,ctx
ctx.prec=320
P=Path(__file__).resolve().parent
j=json.loads((P/'RESULT.json').read_text())
assert len(j['results'])==61 and len(j['exact_crosschecks'])==4 and not j['errors']
assert j['summary']['all_certified_balls_finite'] and j['summary']['all_crosschecks_passed']
# Rational constants used in the uniform analytic estimates.
assert F(15,16)-F(4,7)-F(1,48)==F(29,84)>F(1,4)
assert F(256,257)-F(1,16)>F(7,8)
assert 1+F(7,8)>F(7,4)
assert 3*7**8>8**8
assert F(1,3)-F(64,3*256)==F(1,4)
assert F(16,15)<F(4,3)
assert F(8,3)**4>27  # together with e<3 gives log(8/3)>3/4
assert F(256*24*64**4,2**80)<F(1,2) # e^x>=x^4/24
rows=[]
for power in (40,48,64):
 n=2**power;root=isqrt(n);assert root*root==n
 tau=16384*root;J=4*tau;k=8*n
 assert F(J,n)<=F(1,16)
 a0=128*n*n
 logR=J*(arb(1)+arb(1)/n).log()
 source=(arb(1)-arb(2)/a0)**n-(arb(n)/(n+1)+arb(2)/a0)**n-arb(16)/(3*n)
 target=(arb(1)-arb(1)/n)**n-arb(64)/(3*n)
 epslog=(arb(256)+arb(0)).log()+2*arb(n).log()-arb(n)/64
 exponent=8*arb(n)*(arb(8)/3).log()-logR*n
 assert source>arb(1)/4 and target>arb(1)/4
 assert (arb(1)-arb(1)/n)**n < arb(1)/2
 assert logR<arb(4).log()-arb(3).log()
 assert epslog<-(arb(2).log()) and exponent>5*n
 rows.append({'n':str(n),'source_layer_lower':str(source),'target_fraction_lower':str(target),'moment_exponent_per_n':str(exponent/n)})
# Replay the explicitly reviewed exact algebra block; no theorem is inferred from it.
import re
blocks=re.findall(r'```python\n(.*?)```',(P/'S2.md').read_text(),re.S)
assert len(blocks)==1
namespace={}
exec(compile(blocks[0],'S2 exact replay','exec'),namespace)
assert namespace['checks']==840
if (P/'MANIFEST.json').exists():
 for name,sha in json.loads((P/'MANIFEST.json').read_text()).items():
  assert hashlib.sha256((P/name).read_bytes()).hexdigest()==sha,name
print(json.dumps({'status':'PASS','independent_Arb_bits':ctx.prec,'scalar_cases':rows,'stored_integral_cases':61,'stored_exact_crosschecks':4,'exact_normalization_replay_endpoint_checks':840,'scope':'independent scalar bounds and stored-result integrity; huge finite geometry is analytic, not enumerated'}))
