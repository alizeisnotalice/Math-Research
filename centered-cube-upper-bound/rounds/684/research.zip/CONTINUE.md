# R684 continuation — stop pursuing the false fixed high-moment budget

General arbitrary-L1, all-scales, fixed-Lebesgue C_n<=K sqrt(n) remains UNPROVED. This round corrects an overstrong sufficient estimate, not the original target. Read final REPORT.tex, A1 actual construction, S2 exact recovery, S3 independent audit.

## Superseded target and retained valid results

R683's low-retained-degree and half-coordinate-same-sign high-degree estimates remain valid. Its fixed k=8n target G_rich=k!C_rich/Theta^k<=CU is FALSE, not merely unproved. Do not keep attempting to prove it or import it as a lemma. The exact same reconstructed a is used in the counterconstruction; no source/receiver assumptions were relaxed.

Take square n>=2^40,tau=16384sqrt(n),J=4tau,s_l=(1+1/n)^l,R=s_J. Real disjoint small owners fill J shells, discard outermost grid cells and l1-small centers. Each shell contributes >=29/84 raw q-rate, while at any accepted good center the total RAW w-admission load is <=J exp(-n/64). Append unit-radius target parents on a disjoint good-center interior grid. All rows are accepted using w. Every source has w=a^-n; tau integer means exactly tau a^n source rows saturate, then all later q=0. Guard cells in the entirely positive outermost layer force any legal saturation witness into ALL target parents. First-group strict core has rate tau; targets remain real residual receivers. All scales/far/up conditions hold.

Actual source U<=(2R)^n, target receiver volume>=2^n/4, sampled independent/all-outside support probability>=1/2 at degree8n. Thus Gclean/U>=e^(5n)/8 and G_rich/U>=e^(5n)/8-1. Yet this very input satisfies V0<=84U/29: the failure is moment inflation, not a lower bound against the desired maximal theorem.

## Exact repaired normalization (valid, not the only possible route)

Keep original disjoint Y_b and actual strict core K'_b. Let W_b(x)=sum_core qi 1Ai^c(x)>Theta, x inY_b. For degree j:
J_{j,m}(x)=sum_b 1Yb(x)1suppm_subset_coreb product_i1Ai^c(x)/W_b(x)^j.
Each summand is defined as zero off its Y_b; W_b inverse is evaluated only on Y_b where strictly positive.
Then j!sum_|m|j q^m/m! integral J_{j,m}=V EXACT.
Do not replace the actual core mask by the enlarged earliest-core Z_m, or W_b by Theta: either can lose the normalization protection. Nonnegative Tonelli is legitimate even with key-dependent data; false independent-pool factorization is not.

Keep original graph-derived omega(m), full-I sign classification and r=retained OCCURRENCE count. At k=8n define H_rich=k!sum_rich q^m omega/m! integral J_k,m. It is <=V, unlike old G_rich. Need a genuine H_rich<=CU budget or direct V<=CU; neither is proved.

New leak<=alpha V, alpha=sqrt(delta Lambda)k(k-1)/Theta<=1/(4Theta 3^n B^k)<1/2. Both double-marked Schur endpoints at samex have SAME actual b and W_b; deleting labels does not change W_b. Keep radius-ratio mask before enlarging sums. The low/cone bounds transfer since J_k,m<=K_m/Theta^k in the valid direction.

Full account:
(1-alpha)V<=H_rich+e_n U,
e_n=2^-43n+2^[-n(77/4+6log2n)],
V0<=Cadm{[1+(Kfar+Kup)/tau+e_n/(1-alpha)]U+H_rich/(1-alpha)},P0>=U/tau.
Constants and dimension-only a are unchanged from R683. Small-dimensional empty-core exclusion remains. Changing to a shorter or receiver-dependent degree is allowed by the exact multinomial identity but does NOT automatically preserve k8n paid-sector estimates.

## Computation and next proof decision

The fixed-I continuous receiver envelope is not small enough alone (linear n persists); it is a relaxation, not an actual-source lower model. 61 Arb integrations and4 exactcrosschecks completed; later huge-n scalar checks only evaluate logs/closed formulas. Trialn2^32 failedR<2 and was excluded, not silently passed. Final analytic construction restricts to square n>=2^40. No enormous geometric grid was materialized. Mainverify320bit and exactrational checks supply finite scalar crosschecks; all-dimensional construction and identities are analytic.

Next focus is the joint original-source budget of the accurately normalized receiver configurations, including history and reuse. The high moment may be replaced, but no fixed-pool or fresh-cut independence may be invented. Do not count this normalization identity as a new payment or closed upper bound. User cap remains oneAstra/threeSol; reuse existing agents. Local computation only for explicit decisions. Next genuine completed round is685; no second684commit.
