import sys,time,platform,json
from pathlib import Path
from fractions import Fraction
import numpy as np,sympy as sp
START=time.monotonic();BUDGET=30.;UNION_EVALS=0

def area(lo,hi):
 global UNION_EVALS
 UNION_EVALS+=1
 if len(lo)==0:return 0.
 # Removing a contained receiving rectangle preserves the complete union.
 contains=(lo[:,None,:]<=lo[None,:,:]).all(2)&(hi[:,None,:]>=hi[None,:,:]).all(2)
 np.fill_diagonal(contains,False)
 for i in range(len(lo)):
  for j in range(i):
   if np.all(lo[i]==lo[j]) and np.all(hi[i]==hi[j]):contains[i,j]=False
 keep=~contains.any(0);lo=lo[keep];hi=hi[keep]
 edges=np.unique(np.r_[lo[:,0],hi[:,0]]);ans=0.
 for a,b in zip(edges[:-1],edges[1:]):
  ix=np.flatnonzero((lo[:,0]<(a+b)/2)&(hi[:,0]>(a+b)/2))
  if not len(ix):continue
  ix=ix[np.argsort(lo[ix,1])];low,high=lo[ix[0],1],hi[ix[0],1];length=0.
  for i in ix[1:]:
   if lo[i,1]>high:length+=high-low;low,high=lo[i,1],hi[i,1]
   else:high=max(high,hi[i,1])
  ans+=(b-a)*(length+high-low)
 return float(ans)

def receiver(x,w):
 N=len(w);bits=np.array([[bool(mask>>i&1) for i in range(N)] for mask in range(1,1<<N)])
 r=np.sqrt(bits@w);low=np.max(np.where(bits[:,:,None],x[None,:,:],-np.inf),axis=1)-r[:,None]/2;high=np.min(np.where(bits[:,:,None],x[None,:,:],np.inf),axis=1)+r[:,None]/2;ok=(high>low).all(1)
 return low[ok],high[ok]
class Experiment:
 def __init__(self,name,x,w):
  self.name=name;self.x=np.array(x,float);self.w=np.array(w,float);self.ax=self.x/np.sqrt(2);self.aw=self.w/2;self.lo,self.hi=receiver(self.ax,self.aw);self.u=area(self.lo,self.hi);lm,hm=receiver(self.x,self.w);self.U=area(lm,hm);self.L=np.ptp(self.ax,axis=0)+1;self.cache={};self.levels=[];self.N=len(w)
 def value(self,key):
  if key not in self.cache:
   z=np.array([float(key[0]),float(key[1])])*self.L
   old=area(np.r_[self.lo,self.lo+z],np.r_[self.hi,self.hi+z]);lo,hi=receiver(np.r_[self.ax,self.ax+z],np.r_[self.aw,self.aw]);new=area(lo,hi);O=2*self.u-old;G=new-old
   if O<0 and O>-1e-13:O=0.
   if G<0 and G>-1e-13:G=0.
   self.cache[key]=(G,O,G-O,z)
  return self.cache[key]
 def level(self,n):
  before=len(self.cache);st=time.monotonic();sums=np.zeros(7);best=(-float('inf'),None);Omin=Gmin=1e100
  for i in range(n):
   for j in range(n):
    key=(Fraction(2*i+1-n,n),Fraction(2*j+1-n,n));G,O,g,z=self.value(key);sums+=np.array([g,G,O,G*G-O*O,G+O,O*g,O*O]);Gmin=min(Gmin,G);Omin=min(Omin,O)
    if g>best[0]:best=(g,z.tolist())
  weight=4*np.prod(self.L)/(n*n);v=sums*weight
  row=dict(midpoint_grid_n=n,point_count=n*n,new_cached_points=len(self.cache)-before,elapsed_seconds=time.monotonic()-st,integral_Gamma=v[0],integral_G=v[1],integral_O=v[2],O_convolution_exact=self.u**2,O_convolution_error=v[2]-self.u**2,integral_G2_minus_O2=v[3],integral_G_plus_O=v[4],G_plus_O_weighted_Gamma=v[3]/v[4],integral_O_Gamma=v[5],O_weighted_Gamma=v[5]/v[2],grid_sup_Gamma=best[0],sup_sample_z=best[1],min_sample_G=Gmin,min_sample_O=Omin)
  if self.levels:row['change_from_previous_level']={k:row[k]-self.levels[-1][k] for k in ['integral_Gamma','G_plus_O_weighted_Gamma','O_weighted_Gamma','grid_sup_Gamma','integral_O']}
  self.levels.append(row)
 def output(self):return dict(name=self.name,N=self.N,mu_positions=self.x.tolist(),mu_masses=self.w.tolist(),U_mu=self.U,U_alpha=self.u,scaling_error=self.u-self.U/2,interaction_support_box=[[-float(l),float(l)] for l in self.L],cached_shift_count=len(self.cache),levels=self.levels)
b=(1+np.sqrt(.5))/2
experiments=[Experiment('one_source',[[0,0]],[1]),Experiment('R540_two_source_contact',[[0,0],[b,0]],[.5,.5]),Experiment('asymmetric_three_source',[[0,0],[.4,.02],[.45,.07]],[.4,.3,.3])]
for e in experiments:e.level(17);print(e.name,17,e.levels[-1]['elapsed_seconds'],flush=True)
benchmark_time=time.monotonic()-START;estimate_remaining=sum(e.levels[-1]['elapsed_seconds'] for e in experiments)*(33**2+65**2)/17**2
planned=[33,65] if benchmark_time+estimate_remaining<28 else ([33] if benchmark_time+sum(e.levels[-1]['elapsed_seconds'] for e in experiments)*33**2/17**2<28 else [])
for n in planned:
 for e in experiments:
  if time.monotonic()-START>28:break
  e.level(n);print(e.name,n,e.levels[-1]['integral_Gamma'],e.levels[-1]['G_plus_O_weighted_Gamma'],flush=True)
# Symbolic N1 calibration from full three-box inclusion/exclusion.
t=sp.symbols('t',nonnegative=True);a=sp.sqrt(2)/2;p=(1-a)/2;q=(1+a)/2;A=1-t;C=a-t
AL=2*(sp.integrate(a*A,(t,0,p))+sp.integrate((q-t)*A,(t,p,q)));L2=2*(a*a*p+sp.integrate((q-t)**2,(t,p,q)));AC=2*sp.integrate(A*C,(t,0,a));LC=2*(sp.integrate(a*C,(t,0,p))+sp.integrate((q-t)*C,(t,p,a)));OG=sp.simplify(AC**2-2*LC**2);Gamma2=sp.simplify(sp.Rational(2,3)**2-4*AL**2+4*L2**2);num=sp.simplify(Gamma2+2*OG)
exact=dict(ell='a for 0<=t<=(1-a)/2; (1+a)/2-t for (1-a)/2<=t<=(1+a)/2; 0 otherwise',a=str(a),Gamma_formula='(1-|zx|)_+*(1-|zy|)_+-2*ell(|zx|)*ell(|zy|)',integral_Gamma=str(sp.simplify(1-2*a*a)),integral_O='1/4',integral_G='1/4',integral_G_plus_O='1/2',integral_O_Gamma=str(OG),O_weighted_Gamma=str(sp.simplify(4*OG)),integral_G2_minus_O2=str(num),G_plus_O_weighted_Gamma=str(sp.simplify(2*num)),G_plus_O_weighted_Gamma_float=float(2*num))
out=dict(command=sys.executable+' '+str(Path(__file__).resolve()),versions=dict(python=platform.python_version(),numpy=np.__version__,sympy=sp.__version__),seed=None,scope='Three fixed complete-union configurations, finite deterministic midpoint quadrature. Supremum fields are sampled maxima only. No special-family constant optimization or dimension/order conclusions. N1 symbolic integrals separately exact.',normalization='mu mass1; alpha masses mu/2 and positions mu/sqrt(2); u=U_mu/2. Gamma=G-O=Ucombined-2u.',support_proof='Every mixed receiving box has a cross-package pair with coordinate difference at most sqrt(total combined mass)=1. Thus if any |z_j|>span_j(alpha)+1 every mixed positive-volume box is empty. Old receiver overlap is also absent there since its radius cap is sqrt(1/2)<1.',quadrature='Midpoint grid n per axis over full declared support rectangle; cache key reduced rational normalized displacement per axis, shared across levels. Every shift evaluates complete old union and complete combined union. Contained-box removal preserves full union.',budget=dict(target_seconds=BUDGET,initial_benchmark_seconds=benchmark_time,predicted_remaining_for_33_65=estimate_remaining,planned_later_levels=planned,note='Stage timings guide grid reduction; actual complete elapsed includes symbolic calculation and is reported.'),union_evaluations=UNION_EVALS,elapsed_seconds=time.monotonic()-START,N1_exact=exact,results=[e.output() for e in experiments])
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2));print(json.dumps(exact),flush=True)
