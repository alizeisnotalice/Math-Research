R351 frozen exact peeling diagnostic

Two fresh local Python processes each returned PASS: 30,991 exact Fraction assertions. Initial stage: 167; boundary stress: 512; expanded: 30,293; separate scalar infinite-boundary algebra: 19. These are finite model checks, not a numerical proof of the general peeling lemma.

Reproduce with the standard library only:

```
/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 r351_numeric.py
```

The script writes r351_numeric_result.json beside itself and imports no historical temporary files. The three deliverables are r351_numeric.py, r351_numeric_result.json, and this note.

Actual continuous fixture. For j=0,...,N, source packet [j-h,j+h] has mass 1 and density 1/(2h). Receiver interval E_i=[i+h,i+1-h], i=0,...,N-1, has positive length v=1-2h and actual hard side R=2. All source-by-receiver rectangles are checked by exact endpoint inequalities: every receiver captures its two adjacent packets completely, and all other packets are outside up to null contacts. Consequently full-source m=2, q=m/R=1, lambda=1 throughout. This is true positive-L1 source and positive Lebesgue receiver measure, not a point-weight incidence substitute. Peeling never resets original f, q, R, or the posterior pi_w=f c_w/2.

For a retained set, D has values v times half the number of incident retained receivers. The source gate is strictly D>s. Delete whole receiver blocks when pi_w e <= 1-theta, including equality. The exact integrated potential is

Phi(D)=sum_packets [min(D,s)+min(1,2hT)(D-s)_+].

Every layer verifies theta X_deleted <= sum_z (1-e_z) DeltaD_z = sum_deleted v(1-pi_w e) <= Phi_before-Phi_after. Each receiver is charged once. The global test telescopes only Phi_initial-Phi_terminal, without multiplying by the number of peeling rounds.

Useful results:

| Fixture | Deleted layers | theta X_deleted | Initial potential | Remaining X |
|---|---:|---:|---:|---:|
| N=8, h=1/10, s=3/5, theta=1/2, T=1/2 | 4 | 16/5 | 257/50 | 0 |
| N=32, h=1/8, s=9/16, theta=1/2, T=1/2 | 16 | 12 | 2421/128 | 0 |
| N=128, base parameters | 64 | 256/5 | 3977/50 | 0 |
| N=32, h=3/16, s=15/32, theta=1/2, T=1/4 | 16 | 10 | 15985/1024 | 0 |
| N=8, base parameters except theta=3/4 | 0 | 0 | 257/50 | 32/5 |

Thus long cascades occur in the actual continuous fixture, while a nonempty stable remainder also occurs. Boundary fixtures include D=s (strict gate correctly zero), exact posterior deletion equality (6 and 30 rows in two fixtures), and T comparable to source density. All nine fixtures retain real source densities and physical capture endpoints.

Infinite-limit caution is tested separately, not claimed as a realized infinite receiver cascade. With f=5, T=1/2, s=3/5 and D_j=s+1/(j+1), every finite gate equals 9/10, while evaluating the strict gate at D_infinity=s gives zero. The potential remains continuous, with tail Psi(D_j)-Psi(s)=T/(j+1). This supports the distinction in r351_geometry.md between the decreasing gate limit e_* and substitution of a strict indicator at the limiting D; it does not establish an infinite-model fixed point.

Scope. The finite chain tests the common-source posterior and source-potential accounting under actual q=1 capture geometry. It does not implement original high-dimensional eta/Omega or highpast qualifications, certify the universal maximal-operator constant C, or prove a root-order bound. The scalar limit guard is algebraic evidence about threshold handling. The elementary tested Phi_initial <= s W + T X_initial is particular to these finite fixtures; it is not a substitute for the analytic L4 input in the general proof.
