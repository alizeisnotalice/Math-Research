from fractions import Fraction as F
from itertools import product
count=0
for f,T,s,x,y in product(
    [F(1,2),F(1),F(3)], [F(1,10),F(1),F(4)],
    [F(1,2),F(1),F(2)],
    [F(0),F(1,4),F(1),F(3)], [F(0),F(1,4),F(1),F(3)]):
 if y>x: continue
 def phi(d): return f*min(d,s)+min(f,T)*max(d-s,0)
 e=(max(1-T/f,0) if x>s else 0)
 assert f*(x-y)*(1-e)<=phi(x)-phi(y)
 count+=1
N=7; supports=[{j,j+1} for j in range(N-1)]
f=[F(1)]*N; mass=[F(2)]*(N-1)
receiverweight=[F(3,2)]*(N-1)
s=F(1); T=F(1,10); theta=F(1,4)
active=set(range(N-1)); removed=[]; defect=F(0)
def occ(A):
 return [sum(receiverweight[j]/mass[j] for j in A if i in supports[j])
         for i in range(N)]
def potential(D):
 return sum(f[i]*min(D[i],s)+min(f[i],T)*max(D[i]-s,0)
            for i in range(N))
D0=occ(active)
while active:
 D=occ(active)
 e=[max(1-T/f[i],0) if D[i]>s else F(0) for i in range(N)]
 p={j:sum(f[i]*e[i] for i in supports[j])/mass[j] for j in active}
 dead={j for j in active if p[j]<=1-theta}
 if not dead: break
 new=active-dead; Dnew=occ(new)
 d=sum(f[i]*(D[i]-Dnew[i])*(1-e[i]) for i in range(N))
 assert theta*sum(receiverweight[j] for j in dead)<=d
 assert d<=potential(D)-potential(Dnew)
 defect+=d; removed.append(len(dead)); active=new
assert removed==[2,2,2] and not active
assert defect<=potential(D0)
print('PASS',count,'exact potential inequalities; cascade',removed,
      'removed qmass',sum(receiverweight),'defect',defect,
      'initial potential',potential(D0))
