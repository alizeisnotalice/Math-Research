#!/usr/bin/env python3
"""Exact true-L1 chain peeling and a separate infinite-threshold boundary algebra."""
from fractions import Fraction as F
from collections import Counter
from pathlib import Path
import json
BASE=Path(__file__).resolve().parent
C=Counter()
def ck(k,v):C[k]+=1;assert v,k

def fixtures():
 return [('initial','chain8',8,F(1,10),F(3,5),F(1,2),F(1,2)),('boundary_stress','deletion_equality',8,F(1,10),F(3,5),F(1,10),F(1,2)),('boundary_stress','D_equals_s_at_edges',8,F(1,10),F(2,5),F(1,2),F(1,2)),('boundary_stress','D_equals_s_everywhere',8,F(1,10),F(4,5),F(1,2),F(1,2)),('boundary_stress','stable_nonempty',8,F(1,10),F(3,5),F(3,4),F(1,2)),('expanded','chain32_h1over8',32,F(1,8),F(9,16),F(1,2),F(1,2)),('expanded','chain128',128,F(1,10),F(3,5),F(1,2),F(1,2)),('expanded','chain32_h3over16',32,F(3,16),F(15,32),F(1,2),F(1,4)),('expanded','largeT_deletion_equality',32,F(1,10),F(3,5),F(1,2),F(5,2))]

def model(stage,name,N,h,s,theta,T):
 before=sum(C.values());R=F(2);v=1-2*h;f=1/(2*h);W=F(N+1);clip_fraction=min(F(1),2*h*T);alpha=max(F(0),1-2*h*T);E=[(F(i)+h,F(i+1)-h) for i in range(N)];Z=[(F(j)-h,F(j)+h) for j in range(N+1)]
 ck('real_positive_source_receiver_blocks',0<h<F(1,4) and 0<theta<1 and T>0 and all(b>a for a,b in E) and all(b>a for a,b in Z))
 # Every source x receiver rectangle is full capture or null overlap, never partial.
 capture={}
 for i,(a,b) in enumerate(E):
  for j,(lo,hi) in enumerate(Z):
   inside=(lo>=b-R/2 and hi<=a+R/2);outside=(hi<=a-R/2 or lo>=b+R/2);expected=j in [i,i+1]
   ck('actual_full_block_capture_geometry',inside==expected and (inside or outside))
   capture[i,j]=int(inside)
  m=sum(capture[i,j] for j in range(N+1));ck('actual_full_source_q_band',m==2 and F(3,4)<=m/R<=1)
 ck('actual_disjoint_receiver_intervals',all(E[i][1]<=E[i+1][0] for i in range(N-1)))
 ck('fixed_full_source_mass',sum((hi-lo)*f for lo,hi in Z)==W)
 def D(active):
  return [v/R*sum(i in active for i in [j-1,j] if 0<=i<N) for j in range(N+1)]
 def Phi(values):return sum((min(d,s)+clip_fraction*max(F(0),d-s) for d in values),F(0))
 active=set(range(N));initialD=D(active);initialPhi=Phi(initialD);Xinitial=N*v
 ck('exact_initial_D_endpoint_internal',initialD[0]==initialD[-1]==v/2 and all(d==v for d in initialD[1:-1]))
 layers=[];paid=drop_sum=F(0);all_deleted=set();atD=atPi=0
 while True:
  current=D(active);ej=[alpha if d>s else F(0) for d in current];p={i:(ej[i]+ej[i+1])/2 for i in active};deleted={i for i in active if p[i]<=1-theta};atD+=sum(d==s for d in current);atPi+=sum(x==1-theta for x in p.values())
  for j,d in enumerate(current):
   ck('exact_source_e_with_strict_D_gate',ej[j]==(alpha if d>s else 0))
   if d==s:ck('D_equals_s_has_zero_excess_gate',ej[j]==0)
  ck('exact_full_source_D_first_moment',sum(current)==len(active)*v)
  if not deleted:break
  after=active-deleted;nxt=D(after);Xdeleted=len(deleted)*v;P=Phi(current);Pn=Phi(nxt);deltaD=[a-b for a,b in zip(current,nxt)];linear=sum((1-e)*dd for e,dd in zip(ej,deltaD));receiver_loss=sum((v*(1-p[i]) for i in deleted),F(0))
  ck('deletion_is_complete_receiver_block',all(p[i]<=1-theta for i in deleted) and all(p[i]>1-theta for i in active-deleted))
  ck('D_decreases_using_original_radius',all(dd>=0 for dd in deltaD))
  ck('potential_concave_one_step',P-Pn>=linear)
  ck('source_receiver_loss_exchange_exact',linear==receiver_loss)
  ck('layer_payment_by_potential_drop',theta*Xdeleted<=linear<=P-Pn)
  ck('no_receiver_charged_twice',all_deleted.isdisjoint(deleted));all_deleted|=deleted;paid+=theta*Xdeleted;drop_sum+=P-Pn
  layers.append(dict(iteration=len(layers),active_before=len(active),deleted_receivers=sorted(deleted),Xq_deleted=str(Xdeleted),theta_Xq_deleted=str(theta*Xdeleted),potential_before=str(P),potential_after=str(Pn),potential_drop=str(P-Pn),linear_lower_drop=str(linear),D_before=list(map(str,current)),D_after=list(map(str,nxt)),posterior_e_on_deleted={str(i):str(p[i]) for i in sorted(deleted)}));active=after
  ck('finite_peeling_progress_bound',len(layers)<=N)
 finalD=D(active);finalPhi=Phi(finalD);Xremaining=len(active)*v
 ck('global_potential_telescope_once',drop_sum==initialPhi-finalPhi)
 ck('global_receiver_payment_no_layer_factor',paid==theta*(Xinitial-Xremaining)<=initialPhi-finalPhi)
 ck('global_receiver_measure_account',len(all_deleted)+len(active)==N)
 ck('initial_potential_global_source_bound',initialPhi<=s*W+T*Xinitial)
 if not active:ck('all_deleted_terminal_potential_zero',finalPhi==0)
 return dict(stage=stage,name=name,N_receivers=N,h=str(h),source_f_density=str(f),source_blocks_mass_each='1',source_W=str(W),receiver_intervals=[[str(a),str(b)] for a,b in E],source_intervals=[[str(a),str(b)] for a,b in Z],actual_R='2',actual_m='2',actual_q='1',lambda_='1',source_clip_T=str(T),theta=str(theta),s=str(s),source_excess_factor=str(alpha),layers_count=len(layers),initial_Xq=str(Xinitial),remaining_Xq=str(Xremaining),total_theta_Xq_deleted=str(paid),initial_potential=str(initialPhi),terminal_potential=str(finalPhi),summed_potential_drop=str(drop_sum),D_equals_s_instances=atD,posterior_deletion_equality_instances=atPi,remaining_receiver_ids=sorted(active),layers=layers,exact_checks=sum(C.values())-before,scope='True positive-L1 packet source and positive receiver Lebesgue intervals, full block capture verified. Shared original f/q/R never reset. Fixed-scale diagnostic peeling, not original high-dimensional eta/Omega or highpast traffic.')

def infinite_boundary_algebra():
 before=sum(C.values());f=F(5);T=F(1,2);s=F(3,5);alpha=1-T/f
 def Psi(d):return f*min(d,s)+min(f,T)*max(F(0),d-s)
 rows=[]
 for j in [0,1,3,15,63,1023]:
  d=s+F(1,j+1);dn=s+F(1,j+2);e=alpha if d>s else F(0)
  ck('infinite_sequence_finite_stage_gate',d>s and e==alpha)
  ck('infinite_sequence_potential_step',Psi(d)-Psi(dn)==T*(d-dn))
  ck('infinite_sequence_potential_tail',Psi(d)-Psi(s)==T/F(j+1))
  rows.append(dict(j=j,Dj=str(d),Dnext=str(dn),e_finite=str(e),potential_tail_to_limit=str(Psi(d)-Psi(s))))
 limit_D=s;e_limit_formula=alpha if limit_D>s else F(0);ck('strict_threshold_limit_discontinuity',alpha>e_limit_formula and e_limit_formula==0)
 return dict(exact_checks=sum(C.values())-before,f=str(f),T=str(T),s=str(s),sequence='D_j=s+1/(j+1) decreases to s',finite_gate_value=str(alpha),gate_evaluated_at_D_limit='0',finite_gate_limit=str(alpha),potential_at_limit=str(Psi(s)),rows=rows,scope='Scalar boundary algebra only, not a realized infinite receiver peeling example. Shows why strict-gate indicators cannot be passed to the limit by substituting D_limit=s; potential itself has the correct continuous limit. No undefined infinity-minus-infinity is used.')

def main():
 models=[];stages=[]
 for stage in ['initial','boundary_stress','expanded']:
  before=sum(C.values())
  for args in fixtures():
   if args[0]==stage:models.append(model(*args))
  stages.append(dict(name=stage,exact_checks=sum(C.values())-before))
 boundary=infinite_boundary_algebra();out=dict(status='PASS',total_exact_checks=sum(C.values()),check_counts=dict(C),stages=stages,models=models,infinite_boundary_algebra=boundary,scope='Exact true positive-volume chain peeling and separately marked scalar infinite-threshold boundary. No general core-lemma certification, full original highpast simulation or root-order claim. Standard-library Fraction only.')
 (BASE/'r351_numeric_result.json').write_text(json.dumps(out,sort_keys=True,indent=2)+'\n');print(json.dumps(dict(status='PASS',total_exact_checks=sum(C.values()),stages=stages,boundary_checks=boundary['exact_checks'],layer_counts={m['name']:m['layers_count'] for m in models}),sort_keys=True))
if __name__=='__main__':main()
