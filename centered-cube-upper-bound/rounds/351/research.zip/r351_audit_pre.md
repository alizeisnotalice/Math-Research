# R351 independent preliminary audit

Scope: only the propositions supplied by the parent were used for this preliminary screen; no R351 author proof was read before this record. Original full-f receiver field, actual Lebesgue receiver measure, q/R/m, all original marked traffic and its incoming density kappa<=q remain frozen. No global root conclusion is asserted.

## Actual-source deletion potential — PASS

Let E_0=E and E_{j+1}=E_j\B_j, D_j(z)=int_{E_j} c_u(z)/R_u^n du. With fixed s,T>0 and theta in (0,1), set e_j=1_{D_j>s}(1-T/f)_+ (zero on f=0), and B_j={u in E_j: int e_j d pi_u <=1-theta}. Every field is measurable by Tonelli; q>0 gives the posterior probability pi_u=f c_u/m_u. B_j are disjoint measurable subsets of the original receivers.

The genuine receiver fee, stronger than merely paying the original incoming flow, obeys
 theta X_q(B_j) <= int f(z)(1-e_j(z))[D_j(z)-D_{j+1}(z)] dz.
Indeed integrate q_u(1-int e_j d pi_u) over B_j. This uses the original m=qR^n exactly, without replacing the input or masks.

For each source, define Psi_z(d)=f(z)min(d,s)+min(f(z),T)(d-s)_+. Its slope decreases at s, so it is concave. At the old value D_j the defect multiplier is f below/equal s and min(f,T) above s. Hence even across the threshold
 f(1-e_j)(D_j-D_{j+1}) <= Psi_z(D_j)-Psi_z(D_{j+1}).
The crossing contribution is charged at the old value, and no source or radius atom is omitted. Summing finitely then using Tonelli gives
 theta X_q(E\E_infty) <= int [Psi(D_0)-Psi(D_infty)] <= s W + T int D_0 1_{D_0>s}.
With the inherited selector-adjoint bound int D_0^4 <= C^4 |E| <= C^4 X_q/q_- and T=beta theta q_- s^3/C^4, the deleted union costs at most sW/theta+beta X_q. The same estimate pays its original kappa-marked subtraffic, since kappa<=q. No layer count or repeated source fee occurs.

Parameters and initialization matter: E_0=E makes the first step exactly R350's single-step split. Therefore the entire cascade REPLACES that one-step fee at the same price; it is not added to it. Starting from the already-concentrated set is also valid, but using the same old price requires explicitly prepending the original E step into this same telescoping argument. Different thresholds at different stages need a separate potential account.

D_j decreases to D_infty by monotone convergence of the actual receiver integrals. Let A_infty=intersection_j{D_j>s}; then {D_infty>s} subset A_infty subset {D_infty>=s}. The exact limit e_infty=1_{A_infty}(1-T/f)_+ need not equal the strict-threshold expression. Survivors have int e_infty d pi_u >=1-theta, not necessarily strict >. Consequently their posterior mass on {D_infty>=s, f>T/eta} is >=1-theta/eta for theta<eta<1. This is only a necessary closed limit condition; do not replace the actual survivor set by a strict fixed-point formula or claim a convergence rate.

## Independent multistep Markov proposal — conditional interface only

For the eligible fixed-source rank kernel, source reset plus rank shift defines a killed receiver kernel Q with q du subinvariant, and strict mass growth makes Q^N=0 for a finite mass-range-dependent N. For original input I, occupation O=sum_{k<N} I Q^k satisfies O=I+OQ, and the exact total terminal tagged measure is O(du) pi_u(dy) times the noneligible indicator. Its total mass equals I(E). A one-step terminal source cap does not bound this total unless one controls O; O may accumulate an N factor.

A sufficient Green domination I<=sigma-sigma Q, sigma=q du, implies O<=sigma. However its slack already has directly source-paid mass: (sigma-sigma Q)(E)=int sigma(1-Q1). Paying min(I,slack) is therefore not itself a new deep flow theorem. Full input occupation control remains unproved. Do not mix this alternative with the cascade fee.

## Shared high-density source interface

Individual posterior concentration in one common source set preserves original labels under conditional resampling, with the explicit inverse acceptance factor. It does not imply large pairwise source intersections or an independent source-isolated partition. A new source h=f1_S cannot be installed as the original input with inherited q/J/clock/history.

## Local computational evidence

Executed one fresh Python Fraction process: 771 assertions (scalar concave-potential comparisons and a one-round finite incidence cascade). These check the algebra and threshold direction only, not a continuous cube or historical qualification. This is auditor evidence, separate from all parent/author totals.

Status: independent screen PASS for the actual-source cascade, including its receiver X_q payment and same-price replacement. No general bound for the infinite survivor core is supplied. Await frozen R351 author/main/ledger files for final file-level audit.
