from fractions import Fraction as F
source=[(-F(1,10),F(1,10),F(5)),
        (F(59,100),F(61,100),F(10)),
        (F(79,100),F(81,100),F(12)),
        (F(104,100),F(106,100),F(72,5))]
R=[F(1),F(6,5),F(36,25),F(216,125)]
centers=[F(0),F(1,10),F(11,50),F(9,25)]
vol=[r/20 for r in R]
receivers=[(c-v/2,c+v/2) for c,v in zip(centers,vol)]
mass=[(b-a)*d for a,b,d in source]
capture=[[int(z<=u) for z in range(4)] for u in range(4)]
for u,(left,right) in enumerate(receivers):
 for z,(lo,hi,dens) in enumerate(source):
  if capture[u][z]:
   assert right-R[u]/2<=lo and hi<=left+R[u]/2
  else:
   assert hi<=left-R[u]/2 or lo>=right+R[u]/2
m=[sum(mass[z]*capture[u][z] for z in range(4)) for u in range(4)]
assert m==R
K=F(11,10);Delta=F(3,50)
xi=[[F(capture[u][z],20) for u in range(4)] for z in range(4)]
Q=[[[F(0) for w in range(4)] for u in range(4)] for z in range(4)]
stop=[[F(0) for u in range(4)] for z in range(4)]
for z in range(4):
 ends=[F(0)]
 for weight in xi[z]: ends.append(ends[-1]+weight)
 for u in range(4):
  if not xi[z][u]: continue
  for w in range(4):
   length=max(F(0),min(ends[u+1]+Delta,ends[w+1])
                         -max(ends[u]+Delta,ends[w]))
   Q[z][u][w]=length/xi[z][u]
   if length: assert m[w]>K*m[u]
  stop[z][u]=1-sum(Q[z][u])
  assert 0<=stop[z][u]<=1
 for w in range(4):
  assert sum(xi[z][u]*Q[z][u][w] for u in range(4))<=xi[z][w]
 assert sum(xi[z][u]*stop[z][u] for u in range(4))==min(Delta,sum(xi[z]))
P=[[sum(mass[z]*capture[u][z]*Q[z][u][w]/m[u] for z in range(4))
    for w in range(4)] for u in range(4)]
for w in range(4):
 assert sum(vol[u]*P[u][w] for u in range(4))<=vol[w]
receiver_mass=vol[:]
initial=sum(receiver_mass); W=sum(mass); terminal=[]
N=1
while K**N < m[-1]/m[0]: N+=1
for j in range(N):
 T=sum(receiver_mass[u]*(1-sum(P[u])) for u in range(4))
 nxt=[sum(receiver_mass[u]*P[u][w] for u in range(4)) for w in range(4)]
 assert sum(receiver_mass)==T+sum(nxt)
 assert all(0<=nxt[w]<=vol[w] for w in range(4))
 assert T<=sum(mass[z]*min(Delta,sum(xi[z])) for z in range(4))
 terminal.append(T);receiver_mass=nxt
assert sum(receiver_mass)==0
assert sum(terminal)==initial and initial<=N*Delta*W
print("PASS: 16 real capture checks; four source-rank kernels;",
      N,"exact generations; initial =",initial,"terminal masses =",terminal)
