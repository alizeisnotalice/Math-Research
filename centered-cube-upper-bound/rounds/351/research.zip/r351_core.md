# R351 — Legal iterated rank routing and its exact terminal occupation bill

**Proved finite result.** The actual R350 rank kernel can be iterated
after each genuine full-f source resampling. Every generation retains
receiver density at most \(q\), and every surviving edge increases the
original mass by a strict factor \(K\). No old \(\eta\Omega\) qualification
is reused. Using the full subprobability kernel, rather than killing
every row whose upper mass is at most \(\Delta\), gives the sharp per-round
terminal price
\[
 \int f(y)\min\{\Delta,D(y)\}dy\le\Delta W.
\]
For any \(L\), paths stopping in the first \(L\) generations therefore
cost at most \(L\Delta W\), with an exact remaining marked \(L\)-jump flow.
All paths stop after \(N=O(\sqrt n)\) generations, giving only
\(N\Delta W=O(nW)\) in general. A nonduplicating root bound for the total
terminal occupation is not proved.

## 1. Start from an actual marked incoming measure

Freeze the original full-f field
\[
 m_u=\int f c_u=q_uR_u^n,\quad q_-\le q_u\le\lambda,\quad
 a\le R_u\le b\le2a,\quad
 \xi_y(du)=q_uc_u(y)du/m_u,\quad D(y)=\xi_y(E).
\]
Use the original \(q_-=3\lambda/4\) and integer \(n\ge1\).
Set \(K=e^{\sqrt n}\), \(\Delta=2(1+\sqrt n)\),
\(m_0=q_-a^n\), and \(m_1=\lambda b^n\).
The input is any already constructed nonnegative marked measure whose
current actual receiver marginal is \(\kappa_0(u)du\), with
\(0\le\kappa_0\le q\). In particular this includes the R350 incoming
late flow, or its genuine concentrated-witness restriction.

All earlier marks, including original source, old small receiver, old
physical time, original \(J_y(r)\), \(\eta\Omega\), and late condition, are
carried unchanged throughout what follows. The construction does not
declare a later receiver/source pair to be a newly qualified original
row.

Use the full R350 noncyclic rank kernel \(Q_y(u,dw)\), **on all capturing
rows**, not merely the old soft-active ones. It is a subprobability:
\[
 Q_y(u,E)\le1,\qquad
 \int\xi_y(du)Q_y(u,dw)\le\xi_y(dw).                       \tag{1}
\]
Every surviving edge has \(m_w>Km_u\). This last fact holds on the whole
subkernel because the shift \(\Delta\) exceeds the real closed-window
capacity \(D_0=1+\log K+\log(\lambda/q_-)\); old soft qualification was
needed only to guarantee row mass one, not to prove the strict gap.

Define its exact stopping probability
\[
 b_y(u)=1-Q_y(u,E),\qquad 0\le b_y(u)\le1.
\]
By the actual randomized-rank identity, the lost ranks are precisely
the terminal interval of length \(\min\{\Delta,D(y)\}\), so
\[
 \int \xi_y(du)b_y(u)=\min\{\Delta,D(y)\}.                  \tag{2}
\]
This includes all mass atoms. The stopping rule need not kill an entire
mass atom or an entire receiver row. On rows with strict upper
\(\xi_y\)-mass exceeding \(\Delta\), \(b_y(u)=0\); on the remaining
rows the surviving fraction is still routed legitimately.

## 2. Genuine source resampling and sub-Markov evolution

At an actual current receiver \(u\), resample from
\[
 \pi_u(dy)=f(y)c_u(y)dy/m_u .
\]
Then use \(Q_y\), stopping with its missing probability \(b_y(u)\).
The current receiver transition is the fixed sub-Markov kernel
\[
 P(u,dw)=\int\pi_u(dy)Q_y(u,dw).
\]
The actual identity
\[
 q_u\,du\,\pi_u(dy)=f(y)dy\,\xi_y(du)
\]
and (1) imply the measure domination
\[
 (q\,du)P(dw)\le q_wdw.                                  \tag{3}
\]
Consequently the iterates
\[
 \kappa_{j+1}(w)dw=(\kappa_j(u)du)P(dw)
\]
are absolutely continuous and satisfy \(0\le\kappa_j\le q\) for every
generation. This is a new capacity proof for the iterates, rather than
a reuse of \(a=q\omega\le\lambda\) on arrived traffic.

The terminal measure at generation \(j\), with all previous path marks
retained, has its last two-coordinate marginal
\[
 dZ_j(u,y)=\kappa_j(u)du\,\pi_u(dy)b_y(u).
\]
Write \(M_j=\int_E\kappa_j(u)du\) and \(T_j=|Z_j|\). Probability
conservation at this actual generation gives exactly
\[
 M_j=T_j+M_{j+1},\qquad
 M_0=\sum_{j=0}^{L-1}T_j+M_L.                             \tag{4}
\]
These equalities hold on the full marked path measure, not only after
forgetting the original clock. No new clock migration occurs.

From \(\kappa_j/q\le1\) and (2),
\[
 \begin{split}
 T_j&=\int f(y)\int \xi_y(du)
                  \frac{\kappa_j(u)}{q_u}b_y(u)dy\\
    &\le\int f(y)\min\{\Delta,D(y)\}dy
     \le\Delta W.                                        \tag{5}
 \end{split}
\]
Thus the low-upper rows have a real source price. Killing those whole
rows instead would permit the looser \((\Delta+D_0)W\) per round;
(2) pays only the actual fractional stopping probability.

## 3. Finite horizon, actual paid branches and all costs

Every surviving \(j\)-step path satisfies
\[
 m_{u_j}>K^j m_{u_0}\ge K^j m_0 \quad (j\ge1).
\]
Set
\[
 N=\max\left\{1,\left\lceil
          \frac{\log(m_1/m_0)}{\log K}\right\rceil\right\}.
\]
There can be no surviving \(N\)-step path, including when the ratio is
an exact power of \(K\), because the edge inequalities are strict.
Hence \(M_N=0\). Applying (4),(5) gives the honest full bound
\[
 M_0=\sum_{j=0}^{N-1}T_j
 \le N\int f(y)\min\{\Delta,D(y)\}dy
 \le N\Delta W.                                         \tag{6}
\]
For the original octave,
\[
 N\le 1+\sqrt n\log2+\frac{\log(4/3)}{\sqrt n},
\]
so (6) is \(O(nW)\), not a root-order conclusion.

There is also a precise partial payment with no receiver charge:
\[
 M_0\le M_L+L\Delta W,\qquad 0\le L\le N.                 \tag{7}
\]
The paid portion consists of all genuine marked paths stopped before
generation \(L\). The residual \(M_L\) consists of paths with \(L\)
actual strict mass-gap transitions, carrying their original initial
marks and every resampled source. It is not a restart of original \(G\).
For
\[
 L=\min\{N,\lceil\log(n+2)\rceil\},
\]
(7) pays that portion at most
\(2(1+\sqrt n)\lceil\log(n+2)\rceil W\).
If \(L=N\), no residual remains; otherwise there is no estimate here
that the surviving mass is small. This is a real finite stopping branch,
not an assertion that it covers a fixed fraction.

All prices in (5)–(7) use full \(W\), because each new \(\pi_u\) uses
full \(f\). Any original outer multiplier acts on the terminal prices.
When starting from an already restricted R350 residual, the prior fees
remain as previously paid; none is charged again. Conversely (6) can
be applied directly to the original incoming late measure if its
weaker \(O(nW)\) conclusion is wanted.

## 4. Exact missing cumulative source capacity

There is an exact expression for the total terminal bill:
\[
 M_0=\int f(y)\int \xi_y(du)b_y(u)\,
            H(u)\,dy,\qquad
 H(u)=\sum_{j=0}^{N-1}\frac{\kappa_j(u)}{q_u}.              \tag{8}
\]
The current proof bounds every summand by one. It does **not** bound
their sum by one. Strict mass increase limits the possible generations
at a receiver, but gives up to \(N\) of them. Formula (8), not a
reapplication of the old high-past or soft gate, is the exact cumulative
source-capacity quantity needing improvement.

Equivalently, with the forward action on receiver measures,
\[
 \kappa_0=\sum_{j=0}^{N-1}\kappa_j(I-P)
\]
as a signed receiver-measure identity, while the actual nonnegative
terminal measures are the \(Z_j\) in (4). The signed receiver difference
must not be mistaken for sourcewise disjoint terminal capacity.

No estimate of (8) by \(C\sqrt n\,\mathrm{polylog}(n)W\) independent of
the number of generations has been obtained. A proof would need actual
joint control of the occupation \(H\) on the source-dependent lost-rank
sets, or a valid disjoint allocation of their repeated source charges.
The single-generation column domination (3) alone does not furnish
that allocation. This identifies the unpaid cost without assuming a
private source tree, a source-density cap, or free cross-round reuse.

## 5. Exact local diagnostic

The embedded standard-library script was actually executed. It checks
a positive-volume one-dimensional full-f cube field, exact randomized
rank intervals, strict mass gaps, every generation's actual receiver
capacity, conservation, the stopping identity (2), and the cumulative
terminal total.

The fixture uses diagnostic \(K=11/10\) and \(\Delta=3/50\), larger than
its actual closed mass-window capacity \(1/20\). These are not the
original root parameters; no original high-past or late flow is claimed
for this fixture. The starting density is \(q\), a legal generic input
for the iteration theorem. It tests the new capacity evolution, not
qualification of a new original row.

~~~python
from fractions import Fraction as F
source=[(-F(1,10),F(1,10),F(5)),
        (F(59,100),F(61,100),F(10)),
        (F(79,100),F(81,100),F(12)),
        (F(104,100),F(106,100),F(72,5))]
R=[F(1),F(6,5),F(36,25),F(216,125)]
centers=[F(0),F(1,10),F(11,50),F(9,25)]
vol=[r/20 for r in R]
receivers=[(c-v/2,c+v/2) for c,v in zip(centers,vol)]
mass=[(b-a)*d for a,b,d in source]
capture=[[int(z<=u) for z in range(4)] for u in range(4)]
for u,(left,right) in enumerate(receivers):
 for z,(lo,hi,dens) in enumerate(source):
  if capture[u][z]:
   assert right-R[u]/2<=lo and hi<=left+R[u]/2
  else:
   assert hi<=left-R[u]/2 or lo>=right+R[u]/2
m=[sum(mass[z]*capture[u][z] for z in range(4)) for u in range(4)]
assert m==R
K=F(11,10);Delta=F(3,50)
xi=[[F(capture[u][z],20) for u in range(4)] for z in range(4)]
Q=[[[F(0) for w in range(4)] for u in range(4)] for z in range(4)]
stop=[[F(0) for u in range(4)] for z in range(4)]
for z in range(4):
 ends=[F(0)]
 for weight in xi[z]: ends.append(ends[-1]+weight)
 for u in range(4):
  if not xi[z][u]: continue
  for w in range(4):
   length=max(F(0),min(ends[u+1]+Delta,ends[w+1])
                         -max(ends[u]+Delta,ends[w]))
   Q[z][u][w]=length/xi[z][u]
   if length: assert m[w]>K*m[u]
  stop[z][u]=1-sum(Q[z][u])
  assert 0<=stop[z][u]<=1
 for w in range(4):
  assert sum(xi[z][u]*Q[z][u][w] for u in range(4))<=xi[z][w]
 assert sum(xi[z][u]*stop[z][u] for u in range(4))==min(Delta,sum(xi[z]))
P=[[sum(mass[z]*capture[u][z]*Q[z][u][w]/m[u] for z in range(4))
    for w in range(4)] for u in range(4)]
for w in range(4):
 assert sum(vol[u]*P[u][w] for u in range(4))<=vol[w]
receiver_mass=vol[:]
initial=sum(receiver_mass); W=sum(mass); terminal=[]
N=1
while K**N < m[-1]/m[0]: N+=1
for j in range(N):
 T=sum(receiver_mass[u]*(1-sum(P[u])) for u in range(4))
 nxt=[sum(receiver_mass[u]*P[u][w] for u in range(4)) for w in range(4)]
 assert sum(receiver_mass)==T+sum(nxt)
 assert all(0<=nxt[w]<=vol[w] for w in range(4))
 assert T<=sum(mass[z]*min(Delta,sum(xi[z])) for z in range(4))
 terminal.append(T);receiver_mass=nxt
assert sum(receiver_mass)==0
assert sum(terminal)==initial and initial<=N*Delta*W
print("PASS: 16 real capture checks; four source-rank kernels;",
      N,"exact generations; initial =",initial,"terminal masses =",terminal)
~~~

Only this note was authored. The deliverables are the legal marked
iteration, its fractional terminal price, and the exact cumulative bill;
a general root-order total terminal budget remains open.
