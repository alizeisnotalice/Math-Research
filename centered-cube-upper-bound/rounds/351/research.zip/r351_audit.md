# R351 final independent audit — PASS within the stated contract

This is a file-level review of the frozen R351 main proof, geometry, auxiliary iteration, numeric code/results/notes, and replacement ledger. Only this audit and the earlier owned preliminary audit were written. No author files or Git state were changed. The original historical reduction was not re-audited in full, and no general dimension-root weak-type closure is certified.

## 1. Main actual-source potential: PASS

The proof uses the same full f, actual receiver Lebesgue measure, cubes, m=qR^n, and incoming original marked density 0<=kappa<=q as R350. Restricting the existing witness label does not recompute J, physical clock, masks, or ancestral source qualifications.

For the complete simultaneous deletion scheme E_{j+1}={w in E_j: pi_w e_j>1-theta}, the identity Delta D_j=int_{R_j} c_w/R_w^n dw is exact. Integrating the actual posterior defect gives theta X_q(R_j)<=int f(1-e_j) Delta D_j. Thus this is a receiver X_q payment, stronger than merely an incoming-kappa mass estimate.

Psi_z(d)=f min(d,s)+min(f,T)(d-s)_+ is continuous, increasing and concave. The slope at the old occupancy is f for D_j<=s and min(f,T) for D_j>s. This proves f(1-e_j)Delta D_j<=Psi(D_j)-Psi(D_{j+1}), including a crossing of s and equality D_j=s. No threshold crossing or source atom is silently discarded. Finite sums telescope; nonnegative monotone convergence proves the countable deletion bound with the terminal potential retained. Integrability also follows directly from Psi(D_E)<=fD_E and int fD_E=X_q.

The inherited fixed-exponent adjoint estimate int D_E^4<=C^4|E|<=C^4 X_q/q_- gives int Psi(D_E)<=sW+TC^4 X_q/(q_-s^3). No Lp assumption on f or numerical value of C is introduced. With T=beta theta q_-s^3/C^4 this pays all removed original marked traffic by beta X_q+(s/theta)W, once, independently of the number of layers.

Taking E_0=E and exactly the R350 parameters makes the first deletion the R350 one-step deletion. Therefore the whole cascade replaces that single fee; it is not appended to the old fee. This is a genuine proved enlarged paid union, although the enlargement may be empty for some inputs. The arbitrary measurable-subset deletion extension applies to the budget; concentration of every eventual survivor requires the complete tests used by the main scheme, rather than an arbitrary unfair deletion schedule.

## 2. Infinite limit and residual: PASS with the stated weak guards

D_j decreases to the actual D_{E_infty}. The limit of the strict indicator can retain a source with D_{E_infty}=s. The frozen proof correctly uses e_*<=1_{D_core>=s}(1-T/f)_+, and bounded convergence only supplies posterior >=1-theta. It does not claim a strict fixed point. For theta=1/4, the necessary actual posterior mass on {D_core>=s,f>2T} is >=1/2, not necessarily >1/2. These guards are correctly preserved in main and ledger. The residual is the actual surviving marked traffic, not a newly installed source field, and no root estimate of that core is proved.

## 3. Auxiliary iteration: PASS, separate allocation only

The full noncyclic rank subkernel has strict mass growth on every surviving edge, sourcewise column domination by xi, and lost rank exactly min(Delta,D). Resampling by the genuine full-f posterior yields (q du)P<=q du, hence each generation separately has kappa_j<=q. Probability conservation M_j=T_j+M_{j+1} and finite strict-mass horizon, including exact powers of K, are valid. The displayed N bound and the resulting O(nW) total bound are honest.

The cumulative occupation sum_j kappa_j/q is not bounded by one. Formula (8) records the correct repeated terminal source bill. The root-log price for a limited number of generations is only for that exact stopped marked subbranch, with its surviving path measure retained. It is not added to the main cascade ledger and does not prove general control of all generations. No old original eta/Omega qualification is transferred to a resampled row.

## 4. Main replacement ledger: PASS, inherited aggregation conditional

The B_H price remains [(13/3)epsilon+gamma_eff+epsilon/16]X_q+[C_epsilon,n+4(1+sqrt(n))]W+(D_top+C_hit)W_ex. Source peeling uses full W; the old clipping and relative-future terms retain W_ex. The source low-D and clip estimates inside the whole-branch proof are not billed again. Entrance multiplication by 2 and external Lambda are retained; the per-slot source contribution is 8(1+sqrt(n))W after the entrance factor.

With epsilon=119/3072 and Lambda=128/119, the external receiver charge is 13/36+2Lambda gamma_eff+1/192. Adding the historical CZ 1/256 only under its stated same-certified-X aggregation hypothesis gives 853/2304+2Lambda gamma_eff<865/2304, leaving >1439/2304 unallocated. This is absorption headroom, not a proof that the remaining terms fit it. The new round adds no X or source charge relative to R350.

The final ledger preserves the core, general soft/crossing terms, contract-exterior mass/scale/threshold complements, chronological initial/deletion/future-deleted-source atoms, and H/scale/layer/outer-limit fees. Physical ell's terminal atom does not replace historical time atoms. No overall closure or 'only constants/logarithms remain' claim is made.

## 5. Code/results and evidence scope: PASS

Read both proof-embedded scripts, the standalone copies, numeric.py, numeric_result.json, and numeric.md. The two standalone proof scripts are byte-for-byte their unique embedded code blocks. The finite chain numeric fixture is a true positive-L1 source with positive receiver intervals: each actual R=2 cube captures exactly its two adjacent source packets, all other packets are excluded up to null contacts, and full m=2,q=1 are verified. The integrated potential uses the correct source-density factor min(1,2hT). Entire receiver blocks are deleted at posterior <=1-theta, D=s is treated by the strict gate, and terminal potentials are not discarded from telescope checks.

The JSON and notes agree: 30,991 Fraction assertions =167 initial+512 boundary+30,293 expanded+19 separate scalar boundary assertions. The N=128 fixture genuinely has 64 deleting layers; another fixture has a nonempty stable remainder. These are fixed-scale diagnostics, not original high-dimensional high-past/eta-Omega traffic. The infinite-threshold example is explicitly scalar algebra, not a realized infinite cube cascade. The finite fixture's looser initial-potential bound does not replace the analytic L4 input.

The parent reports fresh execution of numeric 30,991 PASS, geometry 270 potential cases plus a three-round cascade, and core 16 capture checks/four source-rank kernels/six exact generations. These structured checks are not falsely summed as a raw universal assertion count. I did not repeat those pipelines. My separate fresh preliminary Fraction process executed 771 scalar/finite-incidence assertions, recorded only as auditor algebra evidence and not included in the parent totals.

## 6. Final conclusion

PASS for the enlarged actual cascade deletion payment, same-price R350 replacement, weak infinite-core guards, the separate honest finite Markov iteration, and the stated numeric/ledger scope. General consistent root-order control of the self-supported concentration core remains unproved; the entire historical/global task is not certified complete.

## Frozen SHA256 bindings

The following are the bytes reviewed. The inherited R350 files establish the required rank/adjoint/full-field interface; this binding does not constitute a new exhaustive historical audit.

```
0253a14b9104f1b469d0e1d721fcb6ea6ea6256a8f8f43efabe278564619790e  /tmp/r351_main.md
b07aa6f09f20a06d09fb2dfc79459dc6e6f74aedd6f3e882e4876c615b16f253  /tmp/r351_ledger.md
c8d688467593892e84608eb40774d62d61112284b40c18c261dee54f8effe4a3  /tmp/r351_geometry.md
27421b0a4fcacfbd10f89f0707be35514f3c349af8097c77753a98b0d6d6c48b  /tmp/r351_core.md
0ce2d009e5cad3ab93d2f98596ef0c9af5d827232e4550d090c9e5241a115bfa  /tmp/r351_numeric.md
11d9576bf70e701833dee223a1eaa16356926d65e48acdd1f70adcf57ff9e238  /tmp/r351_geometry_checks.py
333f0f45adfae3add7c81384a3bd061e641690ecbe3631cd43857cfb04e92601  /tmp/r351_core_checks.py
81550385ecbc49479295cbe986510fa920ca2096efa9786e36b446332b66ee06  /tmp/r351_numeric.py
9cca0f55853cdc3ff5ff9417af464590bb30468f1d7a7098112f735e349ca9bf  /tmp/r351_numeric_result.json
d9b438348e1bc67ab676ff72b7949507c0a8af78a4326a2114e3fae8759feb8f  /tmp/r351_audit_pre.md
10145c9409bbdfefd1efeccc9180123ff2c48ceb350eb42a291412bc4224bc85  /tmp/r350_main.md
5d7634654dae1fef93db81e5bd9d354b3a917cf54467e65f9ad597ee50a1bf97  /tmp/r350_ledger.md
eef2a5ba2e20828387aab0ac8a8d3b58a55196229a44ae63f8870804b5b74b20  /tmp/r350_geometry.md
133d639819177b06cf4c5078cd6471bfbb9c37a27f9669fdd235e4b353804064  /tmp/r350_core.md
677b514720de2f1f35e6e0635972d88cd87c74ae786127312f36a16c6e2e4118  /tmp/r350_audit.md
```
