#!/usr/bin/env python3
"""PUBLIC generic canonical hardmax sampler and conditional moment guards.
No private source recipe; no exact full-gated high-load physical certificate.
Stdlib Fraction/log enclosures, independent proposal Jacobian checks, and
interval directions. Statistical guarantees require exact iid variables/gates.
"""
from fractions import Fraction as F
from functools import lru_cache
from pathlib import Path
import json,math
SEED=870611

def clean(x):
    if isinstance(x,F):return str(x)
    if isinstance(x,dict):return {str(k):clean(v) for k,v in x.items()}
    if isinstance(x,(tuple,list)):return [clean(v) for v in x]
    return x

@lru_cache(None)
def log_interval(x):
    x=F(x);assert x>0;k=0
    while x>=2:x/=2;k+=1
    while x<1:x*=2;k-=1
    def unit(v):
        z=(v-1)/(v+1);q=z*z;term=z;total=F(0)
        for j in range(48):total+=2*term/(2*j+1);term*=q
        rem=2*term/(97*(1-q))
        return total,total+rem
    lo,hi=unit(x);l2,u2=unit(F(2))
    if k>=0:return lo+k*l2,hi+k*u2
    return lo+k*u2,hi+k*l2


def ceil_sqrt(x,bits=48):
    x=F(x);assert x>=0;D=1<<bits
    root=math.isqrt((x.numerator*D*D)//x.denominator)
    if root*root*x.denominator<x.numerator*D*D:root+=1
    val=F(root,D);assert val*val>=x
    if root:assert (val-F(1,D))**2<x
    return val

def normalization(n):
    lo,hi=log_interval(F(2));Hl=1+n*lo;Hu=1+n*hi
    for ell in (lo,hi):assert 1/(1+n*ell)+n*ell/(1+n*ell)==1
    return dict(n=n,H_interval=[Hl,Hu],inner_probability_interval=[1/Hu,1/Hl],
      shell_probability_interval=[n*lo/Hl,n*hi/Hu],
      joint_normalization_identity='(1+n*ell)/(1+n*ell)=1, same ell in both branch probabilities',
      ideal_sampling_law='Inner unit cube probability1/H; shell probabilitynlog2/H, loguniform full-side r in[1,2], uniform face/sign and uniform other coordinates.',
      clamped_radius='r=max(1,2||x-y||infinity)',
      density='h_y/H: inner1/H, shell r^-n/H; shell Jacobian of each face chart=r^(n-1)/2')

def face_guard(n,r):
    # Direct face chart x_n= +/-r/2, other coords r*v_i. Jacobian r^(n-1)/2.
    r=F(r);assert 1<=r<=2
    jac=r**(n-1)/2
    density_H=(F(n)/r)*F(1,2*n)/jac
    assert density_H==r**(-n)
    return dict(n=n,r=r,face_chart_jacobian=jac,density_times_H=density_H,
      expected_density_times_H=r**(-n),residual=density_H-r**(-n))

def weight_guard(n,dist,L):
    dist,L=F(dist),F(L);r=max(F(1),2*dist);assert 1<=L<=2
    captured=r<=L
    ratio=(r/L)**n if captured else F(0)
    assert 0<=ratio<=1
    lo,hi=log_interval(F(2));Hlo=1+n*lo;Hhi=1+n*hi
    return dict(n=n,distance_inf=dist,r_clamped=r,L_selected=L,captured=captured,
      canonical_weight_divided_by_H=ratio,weight_interval=[Hlo*ratio,Hhi*ratio],
      proved_weight_upper=Hhi,inner_radius_convention_checked=dist<F(1,2))

def old_proposal_guard(m):
    # Algebraic selector L=2 only; NONphysical, no first-contact/source/gates.
    r=2-F(1,2**m);lo,hi=log_interval(F(2));Hhi=1+hi
    a=F(4,5)*(r**-2-F(1,4));b=F(1,5)*(1/r-F(1,2))
    old_low=a+b/hi;old_up=a+b/lo
    old_wlo=F(1,2)/old_up;old_whi=F(1,2)/old_low
    assert old_wlo>Hhi
    bounded_ratio=r/2;assert bounded_ratio<=1
    return dict(m=m,n=1,r=r,L=F(2),scope='NONphysical fixed selector2 algebra; does not assert any actual first-hit retained event.',
      old_density_interval=[old_low,old_up],old_weight_interval=[old_wlo,old_whi],
      H_upper=Hhi,new_weight_divided_by_H=bounded_ratio,
      result='Old outer-vanishing cube-mixture proposal has weight exceedingH and diverging as r→2; direct hardmax weight never exceedsH.')

def moment_radius(N,delta):
    delta=F(delta);assert 0<delta<1 and N>0
    lo,hi=log_interval(6/delta);v=hi/(2*N);rad=ceil_sqrt(v)
    return dict(N=N,delta=delta,log_six_over_delta_interval=[lo,hi],
      normalized_simultaneous_radius_upper=rad,square_residual=rad*rad-v,
      statement='For3 iid exactly evaluated normalized variables in[0,1], Hoeffding plus union bound gives simultaneous mean errors<=sqrt(log(6/delta)/(2N)), probability>=1-delta.',
      prerequisites='Exact fixed predicate/selector/kernel and iid exact proposal; no quadrature, finite-input tail, gate or source-integration error is included.')

def lift_variance(est,rad):
    b,a,c=map(F,est);rad=F(rad)
    blo=max(F(0),b-rad);bhi=min(F(1),b+rad)
    alo=max(F(0),a-rad);ahi=min(bhi,a+rad)
    clo=max(F(0),c-rad);chi=min(ahi,c+rad)
    if blo==0:vl,vh=F(0),F(1,4)
    else:
        vl=max(F(0),clo/bhi-(ahi/blo)**2)
        vh=min(F(1,4),chi/blo-(alo/bhi)**2)
        assert 0<=vl<=vh
    return dict(normalized_b_interval=[blo,bhi],normalized_m1_interval=[alo,ahi],normalized_m2_interval=[clo,chi],
      normalized_conditional_variance_interval=[vl,vh],denominator_strictly_positive=blo>0,
      scope='Direction check conditional on simultaneous normalized moment intervals; when b lower=0 return full[0,1/4].')

def moment_guard(N,delta):
    # Synthetic exact observations, not physical samples, and iid not asserted.
    template=[(F(1,4),F(0)),(F(1,2),F(1,3)),(F(3,4),F(2,3)),(F(1),F(1))]
    est=[sum(w*u**j for w,u in template)/4 for j in range(3)]
    info=moment_radius(N,delta);lift=lift_variance(est,info['normalized_simultaneous_radius_upper'])
    ev=est[2]/est[0]-(est[1]/est[0])**2
    vl,vh=lift['normalized_conditional_variance_interval'];assert vl<=ev<=vh
    return dict(radius_certificate=info,synthetic_normalized_estimates=est,interval_lift=lift,
      synthetic_weighted_variance=ev,
      actual_data_status='NONphysical synthetic mechanics check; no iid claim or confidence-labelled actual residual data.')


def density_diffuse_guard(n,p):
    # Neutral sufficient bound only, no actual source or retained receivers.
    # Assume ||f||infinity<=n^n,lambda=1,L>=1,grid side1/(16n^2).
    eps=F(1,16*n*n);a=F(1,n**p);bound=(F(n)*eps)**n
    assert bound<a
    return dict(n=n,p=p,grid_side=eps,density_upper=n**n,lambda_value=F(1),L_lower=F(1),
      packet_share_upper=bound,share_threshold=a,strict_residual=a-bound,
      eta_zero_conditional=True,grid_translation_independent=True,
      scope='Elementary sufficient density hypothesis; no actual source, original/coarse gates or high-load event existence is asserted.')

def prefix_guard(n):
    # Generic implication: a supplied strict earlier hard witness bounds L*.
    r=F(3,2);witness=F(4,3);A=F(5,4);lam=F(1)
    assert 1<=witness<r<=2 and A>lam
    return dict(n=n,clamped_source_radius=r,witness_scale=witness,witness_average_hypothesis=A,threshold=lam,
      canonical_contribution_zero_if_hypotheses_verified=True,
      scope='Conditional selector implication only; no physical witness is claimed for this algebra record. Float private signs do not become exact certificates.')

def main():
    dims=[1,2,4,8,16,32,128,512,1024,4096,16384,2**20]
    normalization_records=[normalization(n) for n in dims]
    face_records=[face_guard(n,r) for n in (1,2,4,8,16) for r in (F(5,4),F(3,2),F(2))]
    weights=[weight_guard(n,d,L) for n in (1,2,4,8,16,128,1024) for d,L in [(F(1,8),F(3,2)),(F(1,2),F(1)),(F(3,4),F(7,4)),(F(1),F(2)),(F(3,4),F(5,4))]]
    old=[old_proposal_guard(m) for m in (2,4,8,16,32,64)]
    moments=[moment_guard(N,d) for N in (32,512,6400) for d in (F(1,10),F(1,100))]
    density=[density_diffuse_guard(n,p) for n in (1,2,4,8,16,128) for p in (1,2,4)]
    prefix=[prefix_guard(n) for n in (1,4,128)]
    obj=dict(schema='R87-public-bounded-canonical-proposal-v1',publication='PUBLIC generic exact algebra only; private pressure recipes excluded.',seed=SEED,
      scope='No new actual fully qualified high-load residual,I_T/Hall bound or general square-root estimate. Confidence formulas are conditional and not applied to uncertified private gates.',
      stages=dict(pilot='Proposal normalization/face Jacobian/inner clamped-radius tests',pressure='Old vanishing-outer-proposal algebraic weight countercomparison, NONphysical selector',expanded='Large-n normalization and conditional3-moment/variance interval directions'),
      normalization_records=normalization_records,face_jacobian_records=face_records,canonical_weight_records=weights,
      old_proposal_algebra_records=old,conditional_moment_records=moments,
      conditional_density_diffuse_records=density,conditional_prefix_witness_records=prefix,
      counts=dict(normalization_dimensions=len(dims),face_records=len(face_records),weight_records=len(weights),old_proposal_records=len(old),conditional_moment_records=len(moments),density_diffuse_records=len(density),prefix_records=len(prefix)))
    Path(__file__).with_name('hall_results.json').write_text(json.dumps(clean(obj),indent=2,sort_keys=True)+'\n')
    print('PASS',obj['counts'])
if __name__=='__main__':main()
