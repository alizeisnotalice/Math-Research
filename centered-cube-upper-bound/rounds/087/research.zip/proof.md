# 中心立方体第87轮：直接来源预算与连续容量分配

2026-10-12。本轮证明随机分块的直接共同来源预算、物理碰撞和低熵已付分支、连续最优负载主割及一般Borel Hall耦合接口，并给出实际坏来源递推的有限不加权熵势。一般正L1输入的 $n^{1/2+o(1)}$ 一致弱型上界仍未证明，保留一般基准 $O(n\log n)$。

按用户配置保留八个研究角色：三位Astra high作者、Astra high和Sol high独审、两位Sol high数值代理、一位Sol high文献与技能代理。优先复用既有上下文；两位作者因运行流连续中断而以相同模型替换对应角色，未因此增加重复研究任务。审核员先检查命题与潜在反例，再阅读全文；主代理核对统一主账并独立隔离重放。

原输入门槛、真实勒贝格接收测度、全部尺度和分层费用均保留。低碰撞、高熵完整余集的共同来源预算以及阈值补偿占用仍开放。条件性结论和有限检验不登记为一般闭合。

公开归档不含未发表下界配方或新私人压力输入。实际执行结果见inventory.json及独审摘要；LaTeX只静态检查，不编译PDF。


# 第87轮主账：直接来源预算、物理聚合与连续容量

日期：2026-10-12（本轮于10月11日开始）。一般 n^(1/2+o(1)) 一致弱型上界仍未证明；保留一般基准 O(n log n)。第86轮已独立提交并推送 99cb70e53870e88fc64af45f5a723635e24d419a。本轮证明和实际检验的范围以下文及独立审核回执为准。

## 原接口和费用

沿用第82/86轮原输入 mu=fdy、真实 lambda dx、完整窗口[1,2]、原最早硬接触L*、锚点、全窗口E2、严格后见证及原中间下截断 e^{-s_n}/2。原粗平滑低事件F按当前输入计算。每次实际删源重新选择全部门槛。B0、Bext、Tsoft/alpha定义和全尺度C_loc log(n+2)均保留；只逐背景层证明则另付O(log n)层数。

R86已付固定网格分支Fdom={eta_(n^-p)>=n^-1/2}，固定网格边长h0=1/(16n²)，Fdiff=F\Fdom，其中p>0固定。

## 新直接来源预算及完整余集

给定0<h<=1/4、来源分块及可测随机分块族，E=exp(nh)，B_h=1+E[1+(2n²+n)h]。平均标记份额eta_bar_a使用同一实际来源、同一接触。对每个可测接收子集A，已证明

`lambda int_A eta_bar_a dx <= [E+B_h+(1+E)log(1/a)] mu(N_A)`，

N_A为正截面本质来源邻域。边缘秩Z的均值恰为1，直接积分几何点态界即可支付，不需要指数尾异常集删除或额外logH。R86的小h圆整分支费因此改善为

`Pdom_improved=(5+3log(1/a))/rho`。

对每个q>1，非负积分另给出

`lambda int_A E_shift sum_j p_j^q dx <= [E+B_h+(1+E)/(q-1)] mu(N_A)`。

随机平移网格给实际后验nu_x和C_h=int nu_x(dy)nu_x(dz) product_i(1-|y_i-z_i|/h)_+。平均Shannon网格熵记Hbar_h。于是

`lambda int_A C_h dx <= (B_h+1+2E) mu(N_A)`。

在h0处右侧系数<=163/31，C_h0>=3/4分支的全部割费用<=652/93。所有公式保留真实接收勒贝格测度和共同来源；不假设物理坐标独立。

取h*=1/(16n^(3/2)), a*=exp(-2sqrt n), rho=1/2。{C_h*>=3/4} OR {Hbar_h*<=sqrt n}均包含于eta_bar_a*>=1/2，联合分支只收费一次

`Pphys=2[E+B_h+2(1+E)sqrt n]=O(sqrt n)`。

新的完整余集定义为

`Fnew=Fdiff intersect {C_h*<3/4, Hbar_h*>sqrt n}`。

若Dnew一致支付这个完整事件，则原返回式为

`C_n^square <= C_loc log(n+2)[B0+Bext+Tsoft/alpha+Pdom_improved+Pphys+Dnew]`。

Dnew仍未证明为根号阶。还可单独改用F\{eta_bar_a*>=1/2}并省去旧Fdom费用，但本轮保持上述明确分解；两种余集不能混用。若改变已付分支，必须同步修改整个递推和主账。

对每行实际后验可由N个边长delta的小立方体覆盖的可测接收集，另证明优化h后的费用<=14[1+logN+n^(3/2)sqrt(delta)]，条件0<delta<=1/(16n)。部分覆盖的遗漏质量有显式二元熵和网格计数费用。这是一个带覆盖条件的通用分支，未断言所有输入满足该条件。

## 连续容量与来源限制

已证明：对Borel侧长选择器，通过提升(x,L(x))得到闭捕获关系，全部可测Hall割不等式等价于相应有限正耦合可行性；无需选择器连续或紧支撑。原最早硬接触本身具有Borel性。立方体和mu≪dy的密度点引理把删零行后的普通邻域与本质邻域联系起来。最小非法输送量恰等于Hall亏损的上确界，并有耦合达值。耦合可能对接收×来源乘积测度奇异，未声称密度核或对偶势达值，也未改进K。

对正规紧致接收集、连续原选择器，连续二次最优来源负载b_*存在且列密度唯一；其正高负载层给紧致接收主割A_s和来源S_s，满足

`N(A_s)=S_s mod mu, lambda|A_s|=int_(S_s) b_* dmu`。

b_*在所有可行列中按凸序最小；其本质上确界等于真实Hall比值的上确界，未断言某个最终割达值。原规范列的凸矩估计可转给b_*，但其右侧方差仍为原规范联合律的方差，不能换成可能奇异的优化律。

主割删源保存全部原硬前缀、接触及整个捕获后验，因而在旧选择器处保存固定网格份额、C_h与Hbar_h。它不自动保存原中间平滑下界或严格后见证。一般删源后的重选必须重算全部门与物理统计。I_T不对子集单调；不能继承旧完整事件预算。

## 熵势的已证部分与未付部分

对实际坏来源递推，固定0<K<H_n，令当前需求D_i、来源后验相对物理来源的熵e_i、G_i=n lambda_i int_(B_i) log L_i。已证明非负势

`Phi_i=D_i e_i+(1+log(H_n/K))(D_i+G_i)`

满足有限、零误差、不加权递减

`Phi_(i+1)<=Phi_i-D_i d_bin(p_i||rho_i)`。

严格旧半径见证给p_iD_i>D_(i+1)，该事实是误差结算的必要一步。空子代与零质量约定均单独处理。将t_i=lambda_0/lambda_i乘回后，右端再产生

`Ecomp=sum_(i=1)^(m-1)(t_i-t_(i-1))Phi_i`。

此正项至少包含(1+log(H_n/K))乘此前阈值放大费用之和，尚无统一来源质量预算。不加权递减不支付原阈值费用、重复已付分支或终端H_n t_m W_m。真正有限共同律的终端KL及正鞅漂移也保持这项缺口；不能通过翻转KL或改变滤过消去。变量阈值好行费用至少K/(1-beta_i)，不存在免费的可和阈值损失方案。

若在每个当前完整Fnew另证I_T<=R_nW/n，可使用第86轮准确条件返回；该假设仍开放。本轮连续主割提供了另一组需逐割重新估计的目标，未以子集单调性将完整事件预算迁移过去。

## 检验范围与私人边界

重要策略按初步探索、已知反例压力和扩大范围记录。证明、精确有理/区间检验和浮点诊断分别标记。公开95项通用记录与独立守卫为可移植复现材料；不认证任何完整实际高负载事件。

私人原点压力案例严格验证：指定固定网格的低单块质量可与物理集中并存，新分支能支付该情形。案例负载很低，不是高容量或一般上界反例。私人高维搜索采用有界重要性权重；硬根和全部门槛仍有未认证环节，无I_T积分证书。主代理已隔离重放公开记录及两项私人程序，结果一致；公开包只保存匿名验证范围。

主代理尝试以变化横向切片的条件秩代替固定来源块秩；内生选择会改变参考律。九项精确、明确非物理的标量检查揭示未付选择费用，故该路线不进入主费用式。

更新后的64项技能入口做内容哈希快照；实际读过的技能、方法和文献列在对应报告中。入口清单不等于64项定理逐一认证。公开包只含审核报告、详细LaTeX文本及必要独立复现材料；私人配方和PDF不入包，未编译PDF。


## 1. Contact data and the physical statistic

Let \(n\ge2\), \(d\mu=f\,dy\), \(0\le f\in L^1(\mathbb R^n)\), \(0<W=\mu(\mathbb R^n)<\infty\), and \(\lambda>0\). Let \(B\) be measurable and \(L:B\to[1,2]\) measurable, with
\[
 Q_x=x+[-L(x)/2,L(x)/2]^n,\qquad
 \mu(Q_x)=\lambda L(x)^n. \tag{1}
\]
Set \(H_n=1+n\log2\). The source-centered window envelope gives \(b_B\le H_n\) and \(\lambda|B|\le H_nW\), so all subsequent receiver demand is finite. The new estimates require contact only; they apply in particular to the whole fixed-grid \(F_{\rm diff}\) from R86, with its existing selector, and to every measurable subset of it. No smooth gate is transferred under source restriction.

The actual captured probability is
\[
 \nu_x(dy)=\frac{\mathbf1_{Q_x}(y)d\mu(y)}{\lambda L(x)^n}.
\]
For a FIXED physical side \(h>0\), define
\[
 k_h(y,z)=\prod_{i=1}^n(1-|y_i-z_i|/h)_+,
 \qquad C_h(x)=\iint k_h(y,z)d\nu_x(y)d\nu_x(z). \tag{2}
\]
This statistic is invariant under translating the physical input and under changing labels used to represent the same source measure. It is not invariant under changing \(h\). For every atomless \(\nu_x\), \(C_h(x)\downarrow0\) as \(h\downarrow0\), by dominated convergence off the diagonal. Thus no arbitrary refinement is being treated as genuine geometric dispersion.

## 2. A general-width packet bound

For \(0<h\le1/4\), partition the source into countably many measurable packets \(S_j\), each contained in an axis-parallel cube of full side \(h\). Discard zero-mass packets and write \(W_j=\mu(S_j)\). Define
\[
 p_j(x)=\frac{\mu(S_j\cap Q_x)}{\lambda L(x)^n},\quad
 \eta_a(x)=\sum_jp_j(x)\mathbf1_{\{p_j(x)\ge a\}},\quad 0<a\le1.
\]
For \(y\in S_j\), let
\[
 g(y)=\int_B L(x)^{-n}\mathbf1_{Q_x}(y)
                  \mathbf1_{\{p_j(x)\ge a\}}dx.
\]
Put
\[
 E_h=e^{nh},\quad B_h=1+E_h[1+(2n^2+n)h],\quad
 A_{h,a}=B_h+(1+E_h)\log(1/a). \tag{3}
\]
Then
\[
 \mu\{g>K\}\le2\exp\!\left[-\frac{K-A_{h,a}}{2E_h}\right]W. \tag{4}
\]

Here is the geometric proof, including the width cost rather than hiding it in a universal constant. Translate one packet's containing-cube center to zero. Its one-coordinate upper and lower marginal tails are \(G_{i,\pm}\). Define
\[
 Z_j(y)=\frac1{2n}\sum_{i,\pm}\log\frac{W_j}{G_{i,\pm}(y_i)}.
\]
Each marginal is atomless because \(\mu\) is \(L^1\). Every normalized tail rank is uniform. In particular \(\mathbb E_{\mu_j/W_j}Z_j=1\) exactly, and Jensen also gives \(\mathbb E_{\mu_j/W_j}e^{Z_j/2}\le2\). Neither assertion requires independence. The exact first moment, rather than the auxiliary exponential tail, is the primary payment tool below.

Rows capturing the whole packet have \(W_j\le\lambda L^n\le W_j/a\). The exact side-interval envelope \(1+n\log(v/\ell)\) pays at most \(1+\log(1/a)\). For partial capture and captured \(y\), put \(r=2\|x\|_\infty\), measured from the PACKET CENTER. Then \(|L-r|\le h\). The region \(r\le1+h\) costs at most \(e^{nh}=E_h\).

On a unique-face cone with \(x_i=r/2\), \(r>1+h\), and \(2|x_k|<r-2h\) for every \(k\ne i\), all transverse packet coordinates are captured. The captured packet is exactly a marginal half-space. Hence, for the appropriate tail \(G=G_{i,\pm}(y_i)\),
\[
 G\le\mu(S_j\cap Q_x)\le\lambda L^n\le W_j/a.
\]
Set \(\ell=\max(1,(G/\lambda)^{1/n})\), \(v=\min(2,(W_j/(a\lambda))^{1/n})\). The cone is empty if \(\ell>v\); otherwise \(r\in[\ell-h,v+h]\). This is a containment statement, with no assumed derivative or monotonicity of the selected side. Its radial volume element is bounded by \(r^{n-1}dr/2\), while
\[
 r^{n-1}(r-h)^{-n}\le E_h/r,\qquad
 \log\frac{v+h}{\ell-h}\le n^{-1}\log\frac{W_j}{aG}+3h.
\]
The latter follows from \(\ell\ge1\) and \(h\le1/4\). Summing the \(2n\) cones costs at most
\(E_h[Z_j+\log(1/a)+3nh]\).
The near-tie angular fraction is at most \(2(n-1)h/r\). Its full radial contribution is bounded by
\[
 2n(n-1)hE_h\int_{1+h}^{2+h}r^{-2}dr
 \le2n(n-1)hE_h.
\]
Combining the four pieces proves
\[
                    g(y)\le E_hZ_j(y)+A_{h,a}. \tag{5}
\]
Apply the marginal-rank exponential bound and sum the actual packet masses once to obtain (4). For \(h\le1/(16n^2)\), R86 also supplies the sharper rounded form \(g\le2Z_j+3+3\log(1/a)\).

## 3. The weighted all-cut budget and averaging without an extra fee

Let \((\Omega,\pi)\) be a probability space and let \(\{S_{s,j}\}_{j\in\mathbb N}\), \(s\in\Omega\), be a jointly measurable family of source partitions satisfying the same side bound \(h\). All packet indicators and centers used in the preceding proof are assumed jointly measurable; translated half-open grids below satisfy this explicitly. Write \(p_{s,j}\), \(\eta_{a,s}\), and \(g(y,s)\) for their actual quantities, and define
\[
 \bar\eta_a(x)=\int\eta_{a,s}(x)d\pi(s),\qquad
 M_{h,a}=E_h+B_h+(1+E_h)\log(1/a). \tag{6}
\]
For EVERY measurable \(A\subset B\), without any lower bound on \(\bar\eta_a\),
\[
 \boxed{\quad\lambda\int_A\bar\eta_a(x)dx
       \le M_{h,a}\mu(N_A),\qquad N_A=\{y:b_A(y)>0\}.\quad} \tag{7}
\]
Consequently EVERY measurable cut of \(\{\bar\eta_a\ge\rho\}\), \(0<\rho\le1\), has Hall fee \(M_{h,a}/\rho\). There is no number-of-partitions factor, no extra averaging loss, and no window-envelope logarithm in this payment.

To prove the weighted estimate first with \(W\), integrate (5) on the explicitly chosen auxiliary source space \(d\mu(y)d\pi(s)\). Its total mass is \(W\). The exact marginal-rank identity \(\int Z_j\,d\mu_j=W_j\) and countable summation imply
\[
 \iint g(y,s)d\mu(y)d\pi(s)\le M_{h,a}W.
\]
On the other hand, Tonelli and actual contact give the exact identity
\[
 \iint g(y,s)d\mu(y)d\pi(s)
 =\int_B L(x)^{-n}\mathbb E_s\sum_j
      \mathbf1_{\{p_{s,j}(x)\ge a\}}\mu(S_{s,j}\cap Q_x)dx
 =\lambda\int_B\bar\eta_a(x)dx.
\]
Thus the branch is paid directly from actual common-source mass. The auxiliary shift law does not impose any independence on physical source coordinates. The exponential tail (4) is a retained auxiliary tool; no deletion of exceptional sources is needed for this stronger mean budget.

For arbitrary \(A\), Tonelli gives \(\mu(Q_x\setminus N_A)=0\) for almost every \(x\in A\). Consequently source restriction to \(N_A\) preserves contact and every packet capture simultaneously for almost every \((x,s)\), and hence preserves \(\bar\eta_a\) for almost every \(x\). Apply the just-proved weighted estimate to this restricted physical input and receiver set \(A\), using its new marginal ranks. If its mass is zero, contact gives \(|A|=0\). No old gate is inherited or needed. Ordinary measurable cube-union neighborhoods contain \(N_A\) and give the weaker corresponding bound. No attained continuum allocation is inferred merely from these inequalities.

### 3.1. All positive packet moments from the same source budget

For \(q>1\), define \(R_{q,h}(x)=\mathbb E_s\sum_jp_{s,j}(x)^q\). Nonnegative Tonelli gives
\[
 (q-1)\int_0^1 a^{q-2}\bar\eta_a(x)da=R_{q,h}(x).
\]
Integrating (7), including its essential-neighborhood version for the SAME cut \(A\), yields the unconditional estimate
\[
 \lambda\int_A R_{q,h}(x)dx
 \le\left[E_h+B_h+\frac{1+E_h}{q-1}\right]\mu(N_A).
 \tag{19}
\]
The integral of the logarithmic term is \((q-1)\int_0^1a^{q-2}\log(1/a)da=1/(q-1)\). No small-share, entropy, collision, or gate condition is required beyond actual contact. The bound is not asserted at \(q=1\).

## 4. An intrinsic paid branch inside the fixed-grid diffuse event

Take \(s\) uniformly in \([0,h)^n\) and \(S_{s,j}=s+hj+[0,h)^n\), \(j\in\mathbb Z^n\), intersected with the source. For any two fixed points, the probability of sharing a cell is exactly \(k_h(y,z)\): the one-coordinate probability is \((1-|y_i-z_i|/h)_+\), and the auxiliary coordinate shifts are independent by construction. Thus
\[
 C_h(x)=\mathbb E_s\sum_jp_{s,j}(x)^2,\qquad
 \bar\eta_a(x)\ge C_h(x)-a. \tag{8}
\]
For the inequality, the contribution of shares below \(a\) to the sum of squares is at most \(a\), and the remaining squares are at most their corresponding shares. No independence of the physical source is used.

Taking \(q=2\) in (19) now gives a direct, unconditional common-source physical-pair budget for EVERY measurable cut:
\[
 \boxed{\quad\lambda\int_A C_h(x)dx
          \le [B_h+1+2E_h]\mu(N_A).\quad} \tag{20}
\]
Consequently the all-cut Hall fee for \(\{C_h\ge c\}\), \(0<c\le1\), is \([B_h+1+2E_h]/c\). At \(h\le h_0=1/(16n^2)\), the geometric bounds \(E_h\le32/31\), \(B_h\le68/31\) give a dimension-independent collision budget \(163/31\), and a fee \(652/93\) at \(c=3/4\). This is a genuine weighted estimate on arbitrary common-source contact data; it is not an assumption that collision is large on the remaining event.

It follows that EVERY measurable cut of
\[
                         R_{h,a,\rho}=\{x\in B:C_h(x)\ge a+\rho\}
\]
has Hall fee \(M_{h,a}/\rho\). At the fixed original maximal grid side \(h_0=1/(16n^2)\), the sharper R86 constants give
\[
 P=\frac{5+3\log(1/a)}\rho. \tag{9}
\]
This can remove rows from the old fixed-grid \(F_{\rm diff}\) even when every original-grid packet share is tiny. It uses an actual physical pair statistic, not a global entropy bound derived from those shares.

There is also a larger-scale root-order branch. Fix
\[
 h_*=\frac1{16n^{3/2}},\qquad a=\frac14,\qquad\rho=\frac12.
\]
Then \(E_{h_*}\le e^{1/(16\sqrt2)}\),
\((2n^2+n)h_*=(2\sqrt n+1/\sqrt n)/16\), and
\[
 P_* =\frac43[B_{h_*}+1+2E_{h_*}]
       =O(\sqrt n). \tag{10}
\]
Thus \(\{C_{h_*}\ge3/4\}\) has this unconditional all-cut Hall bound. All constants are independent of the source, of its coordinate correlations, and of the fixed microgrid's origin.

A direct geometric sufficient condition is
\[
 \mathbb E_{\nu_x\otimes\nu_x}\|Y-Z\|_1
                  \le h(1-a-\rho), \tag{11}
\]
when \(a+\rho\le1\): the product in (2) is at least \(1-\|Y-Z\|_1/h\). This offers a certificate of physical concentration without counting labels. It is only sufficient.

### 4.1. A larger entropy branch, with a single combined fee

Define the physical averaged packet entropy
\[
 \mathcal H_h(x)=\mathbb E_s\sum_jp_{s,j}(x)\log\frac1{p_{s,j}(x)},
 \qquad 0\log(1/0):=0. \tag{14}
\]
Every selected cube meets at most \((2/h+2)^n\) positive-mass grid cells, so \(0\le\mathcal H_h\le n\log(2/h+2)\). This bound gives finiteness, not a root-order bound. The statistic is defined by the fixed physical grid scale and averaged origin; it does not change when an auxiliary representation of \(\mu\) is refined.

For \(s_0>0\), pointwise entropy bounds the subthreshold mass by
\[
 1-\eta_{e^{-2s_0},s}(x)
 \le\frac1{2s_0}\sum_jp_{s,j}(x)\log\frac1{p_{s,j}(x)}.
\]
Thus \(\mathcal H_h\le s_0\) implies \(\bar\eta_{e^{-2s_0}}\ge1/2\), and every measurable cut of this entropy branch has fee
\[
 2[E_h+B_h+2(1+E_h)s_0]. \tag{15}
\]
This is a proved payment for an explicit entropy sublevel set, not an entropy estimate inferred from small shares.

For one combined root-order branch, use \(h=h_*\), \(s_0=\sqrt n\), \(a_n=e^{-2\sqrt n}\le1/4\), and \(\rho=1/2\). Both \(C_{h_*}\ge3/4\) and \(\mathcal H_{h_*}\le\sqrt n\) imply \(\bar\eta_{a_n}\ge1/2\). Therefore their UNION has the single fee
\[
 P_{\rm phys}=2[E_{h_*}+B_{h_*}+2(1+E_{h_*})\sqrt n]
                 =O(\sqrt n). \tag{16}
\]
There is no sum of two branch fees.

### 4.2. Row-dependent geometric covers, without a common source partition

Suppose for one row that \(\nu_x\) is supported almost surely in a union of at most \(N\ge1\) cubes of full side \(\delta\le h\), with arbitrary centers and overlap. These cubes may depend on the row, but are fixed before the auxiliary shift is drawn. Then
\[
                 \mathcal H_h(x)\le\log N+\frac{n\delta}{h}\log2. \tag{17}
\]
Assign each point in overlapping cubes to the first cube containing it and let \(K\) be this finite cover label. For each shift let \(J\) be the grid label. The elementary finite entropy chain inequality gives
\(H(J)\le H(K)+H(J\mid K)\), with \(H(K)\le\log N\). Conditional on a cover label, each coordinate lies in an interval of length at most \(\delta\). Its coordinate grid label is constant unless the auxiliary grid cuts that interval, an event of probability at most \(\delta/h\); on that event there are at most two labels, so its entropy is at most \(\log2\). Conditional entropy subadditivity and averaging yield (17). Physical coordinate independence is not required.

In particular, at \(h=h_*\), every measurable set of rows admitting such covers with
\(\delta\le h_*/(2\sqrt n)=1/(32n^2)\) and \(\log N\le\sqrt n/2\)
lies in the paid entropy branch, since \((1+\log2)\sqrt n/2<\sqrt n\). This permits exponentially many cubes in \(\sqrt n\), with different centers for every row; it does not require a single global packet partition. No measurable selection of covers is needed for this pointwise implication. We do not assert measurability of the entire cover-admission class; the Hall estimate applies to every measurable receiver subset satisfying the condition.

The same argument gives an optimized geometric estimate independent of a preset aggregation scale. If \(0<\delta\le1/(16n)\) and each row under consideration has such an \(N\)-cube cover, choose \(h=\sqrt{\delta/n}\) and write \(S=n^{3/2}\sqrt\delta\). Then \(\delta\le h\le1/(4n)\), \(E_h\le4/3\), and (17) gives \(s_0=\log N+S\log2\) as an entropy upper bound. Applying (15), every measurable cut of these rows has Hall fee at most
\[
             14\,[1+\log N+n^{3/2}\sqrt\delta]. \tag{21}
\]
Indeed \(B_h\le7/3+(10/3)S\), \(\log2\le3/4\), and the exact fee in (15) is at most \(22/3+(28/3)\log N+(41/3)S\). This proves (21) with a universal numerical constant. It permits arbitrary common-source correlations and different covering centers for every row. The estimate interpolates with physical diameter; it does not assert that every captured source has a small such cover. It is a separate usable corollary, not an additional fee silently added to the default combined branch (16).

There is a robust version for positive tails. If the actual mass outside the union of the \(N\) cubes is \(\tau\in[0,1]\), then
\[
 \mathcal H_h(x)\le h_{\rm bin}(\tau)
 +(1-\tau)\left[\log N+\frac{n\delta}{h}\log2\right]
 +\tau n\log(2/h+2). \tag{18}
\]
Here \(h_{\rm bin}(\tau)=-\tau\log\tau-(1-\tau)\log(1-\tau)\), with zero endpoint terms. Use the covered/outside binary label, the preceding cover labels on the covered part, and the finite selected-cube grid count on the outside part. All terms are finite. Whenever the right side is at most \(\sqrt n\), the same combined fee applies. Formula (18) uses the actual \(\tau\); replacing it by a larger number requires checking the resulting bound rather than silently assuming monotonicity.

The exact remaining whole event, retaining the SAME current first-contact selector, is now
\[
 F_{\rm rem}=F_{\rm diff}\cap
       \{C_{h_*}<3/4,\ \mathcal H_{h_*}>\sqrt n\}. \tag{12}
\]
The union of original background layers in the removed branch is paid once; there is no layer factor unless the estimate is separately summed layerwise. The existing all-scale return has its additional logarithm. A reselected-source recursion may add \(P_{\rm phys}\) to its paid constant and run on the full newly defined \(F_{\rm rem}\); all canonical columns and source-conditional variances must be recomputed on that event. No subset-monotonicity of normalized variance is used.

## 5. What this does and does not settle

Arbitrary fine label refinement can make all packet shares tiny while preserving \(\nu_x\), contact, and every physical kernel. The statistic (2) ignores this relabeling, but a change of physical scale still changes it and eventually drives it to zero. A fixed grid can additionally split physically close mass across coordinate boundaries. Averaging fixes the origin artifact; it does not prove that most rows have large \(C_h\).

A tempting complementary calculation uses the actual pair-contact identity
\[
 \lambda^2|A|=\iint\!\int_A L(x)^{-2n}
           \mathbf1_{Q_x}(y)\mathbf1_{Q_x}(z)\,dx\,d\mu(y)d\mu(z). \tag{13}
\]
It retains common-source geometry, but its natural source budget is quadratic in \(\mu\), while Hall needs linear \(\mu(N_A)\). Low \(C_h\) alone supplies no normalization converting (13) to a linear budget; replacing one factor by an independently chosen conditional reference would change the actual joint law. Thus (13) is not counted as a gain or as a closure proof.

The statistic in (2) couples two captured sources within one row. The remaining Hall difficulty concerns source mass shared across many different rows; no inter-row overlap estimate follows just from a small value of (2). The remaining open task is a uniform general capacity estimate on (12), or a genuinely paid additional decomposition of that event. Neither a universal entropy upper bound nor a source-variance bound follows from its small local collision probability. The positive results here are the unconditional weighted all-cut budgets (7), (19), (20) and their single combined physically defined branch (16). General \(\sqrt n\,n^{o(1)}\) closure is not claimed.

### 5.1. Qualified obstruction to interpreting fixed-grid shares

A private exact three-stage test establishes that the fixed maximal-grid diffuse event can contain physically concentrated, positive-Lebesgue-measure receiver sets satisfying all retained original gates and the new coarse-low gate. In those qualified cases every fixed-grid share lies below the prescribed old cutoff, yet the physical collision exceeds the new paid threshold. The averaged physical branch therefore removes actual rows from the old diffuse event; the issue is not an arbitrary refinement of a formal label model.

The seven-case certificate has six qualified coarse-low records and one original-gate record that is correctly rejected by the new coarse gate. It uses exact rational enclosures for continuous whole-window kernel bounds and proves the hard selector and strict later witness analytically on whole receiver boxes. No single background-layer claim is needed. An independent nonwriting replay and proof review passed. All recipes and parameters remain private.

The obstruction is precisely to the inference “small fixed-grid shares imply physical dispersion.” Its demand and canonical load are small, so it does not refute the filtered high-load target, the optimized Hall bound, or the remaining event (12). This is a qualified failure of an inference together with a proved repair, not a general upper-bound closure.

## 6. Audit and numerical scope

Both independent auditors received the exact statements before reading author proofs and passed blind checks of the mean budget, moment integration, collision identity, general-width constants and geometric-cover estimates. Independent full Markdown and TeX proof reads returned PASS, including the constants 163/31, 652/93 and 14. No compilation was performed. Three-stage scalar checks are coordinated with the independent guard owner; their exact counts and arithmetic receipts belong to the separate audit ledger, and they do not certify actual receiver gates. The private actual-gate pressure has pilot, origin-artifact pressure and expanded-parameter stages; all seven exact records were independently replayed, with the six successes and one correctly excluded control described above. Actual pressure constructions are not reproduced here. Inconclusive high-load searches with floating gate predicates supply no universal variance or Hall conclusion. General proofs, exact certificates and numerical diagnostics remain separate.

## 1. Actual recursion and common laws

All logarithms are natural. Fix n≥2, H=1+n log 2, and 0<K<H. If K≥H, q≤b≤H makes the source tail empty, so that case needs no entropy argument. Fix a finite horizon m. At stage i use the current source μ_i=f_i dy, W_i=μ_i(R^n), threshold λ_i, the original complete R82 gates and earliest hard contact L_i(x)∈[1,2]. The anchor is below λ_i/2; the smooth gate is the original whole-window P_{1,L}≤λ_i/2; the original middle floor and any retained layer gates are recomputed. Delete the paid coarse-high and packet branches without changing L_i on retained rows. The grid is fixed, but its current source masses and packet shares are recomputed after each restriction. Let F_i^diff be this whole current fixed-grid diffuse residual. Apply the R87 physical branch, with h_*=1/(16n^{3/2}), to the same current captured law μ_i|Q_i/(λ_iL_i^n). Write C_{h_*} for its pair expectation of the collision kernel ∏_j(1−|y_j−z_j|/h_*)_+, and Hbar_{h_*} for the entropy of its grid-cell shares averaged over a uniform origin shift in [0,h_*)^n. The whole remaining event is

F_i^rem=F_i^diff∩{C_{h_*}<3/4, Hbar_{h_*}>sqrt n}.

The collision-high/entropy-low UNION has the once-paid fee P_phys=2[E_*+B_*+2(1+E_*)sqrt n], where E_*=exp(nh_*) and B_*=1+E_*[1+(2n²+n)h_*]. This follows from coverage's actual common-source weighted packet estimate; both branches imply averaged significant-packet mass at least 1/2 at cutoff exp(−2sqrt n). This branch changes neither current input nor current selector. All physical statistics are recomputed after the next source restriction. Let B_i⊂F_i^rem be the current receivers. The B_i are nested; the F_i^rem need not be.

The captured stopping kernel satisfies 0≤k_i(x,y)≤L_i(x)^{-n}1_{Q_i(x)}(y), with d_i(x)=∫k_i dμ_i>c_iλ_i. Here c_i=1−α_i−ε_i>0. Set

q_i(y)=∫_{B_i}k_i(x,y)dx, S_i={q_i>K}, μ_{i+1}=μ_i|S_i,
λ_{i+1}=β_iλ_i, β_i=δ_i c_i∈(0,1).

Only rows with ∫_{S_i}k_i/d_i>δ_i proceed. Such a row has the STRICT old-radius witness A_{L_i}f_{i+1}>λ_{i+1}. After every fresh gate, B_{i+1}⊂B_i. Its new anchor and the strict old witness imply L_{i+1}<L_i and Q_{i+1}⊂Q_i. Every statement below uses this specific recursion, not arbitrary source removal. Measurability is as in the original first-contact and captured-stop constructions; all sets can be completed without changing any integral.

Write Z_i=∩_{j<i}S_j, E_i(x)=Z_i∩Q_i(x), and μ_0(E_i(x))=λ_i L_i(x)^n. Define

b_i(y)=∫_{B_i}L_i(x)^{-n}1_{Q_i(x)}(y)dx,
D_i=λ_i|B_i|=∫b_i dμ_i, R_i=D_i/W_i.

The retained full-window envelope gives b_i≤H and D_i≤H W_i. If D_i=0, terminate the current receiver chain and put all subsequent receiver quantities equal to zero. All ratios below concern positive D_i and a positive child. On the standard Borel product B_0×R^n, define the current probability, extended by zero outside B_i,

P_i(dx,dy)=D_i^{-1}1_{B_i}(x)L_i(x)^{-n}1_{Q_i(x)}(y) dx μ_i(dy).

Its receiver marginal is uniform on B_i; its source marginal and source reference are ν_i=b_i μ_i/D_i and π_i=μ_i/W_i. No coordinate independence is assumed. Put e_i=KL(ν_i||π_i). Then

0≤e_i≤log(H/R_i).                                                   (1)

Indeed dν_i/dπ_i=b_i/R_i≤H/R_i; its relative entropy is finite. Throughout TV(P,Q)=sup_A|P(A)−Q(A)|=one half of the L1 distance.

## 2. A genuine unweighted source entropy descent

At a positive step write p_i=ν_i(S_i), ρ_i=π_i(S_i), C_i=p_iD_i. These are different fractions: p_i is a captured posterior fraction, ρ_i is a physical source fraction. Both are positive when the child is positive. Let e_i^S=KL(ν_i(·|S_i)||π_i(·|S_i)). Since π_i(·|S_i)=π_{i+1}, the binary entropy chain rule gives

e_i=d_bin(p_i||ρ_i)+p_i e_i^S+(1−p_i)e_i^{S^c}.                       (2)

At endpoints use the zero-weight complementary term convention. This is a finite identity, not a difference of infinite entropies. On S_i, K<b_i≤H because q_i≤b_i.

The actual old bad-row witness yields the additional inequality

C_i=∫_{B_i}L_i^{-n}μ_i(S_i∩Q_i)dx>D_{i+1}.                           (3)

Indeed the integrand is >β_iλ_i on B_{i+1}; integrate there and then enlarge to B_i. This strict inequality is not derived merely from source or cube nesting.

Put θ_i(x)=(L_{i+1}(x)/L_i(x))^n on B_{i+1}. Relative to P_i conditioned on Y∈S_i, the child joint law has density

(dP_{i+1}/d(P_i|S_i))(x,y)=(C_i/D_{i+1})θ_i(x)^{-1}

on its support. It is at least one by (3). Thus its joint reselection entropy is exactly

J_i^ent=log(C_i/D_{i+1})+
 n |B_{i+1}|^{-1}∫_{B_{i+1}}log(L_i/L_{i+1})dx.                       (4)

Data processing gives KL(ν_{i+1}||ν_i|S_i)≤J_i^ent. Expanding relative entropy against π_{i+1} gives the finite three-point identity. The log density of ν_i|S_i against π_{i+1} is log[b_iW_{i+1}/C_i], whose oscillation on S_i is at most ℓ_K=log(H/K). Consequently

e_{i+1}≤e_i^S+J_i^ent+ℓ_K TV(ν_{i+1},ν_i|S_i).                       (5)

Here and below an integral over the child support is interpreted under its probability law, not the old receiver marginal.

The new useful estimate is a paid total-variation error. Since the joint density is at least one on the child support,

TV(P_{i+1},P_i|S_i)=1−(D_{i+1}/C_i) avg_{B_{i+1}}θ_i.

Define the UNWEIGHTED geometric kernel increment

J_i^geom=λ_{i+1}∫_{B_{i+1}}(1−θ_i)dx.

Contraction of TV under source projection and D_{i+1}≤C_i imply

D_{i+1} TV(ν_{i+1},ν_i|S_i)≤(C_i−D_{i+1})+J_i^geom.                 (6)

To verify (6), multiply the exact joint TV by D'=D_{i+1}, split it as D'(1−D'/C)+(D'^2/C)(1−avg θ), and bound the two terms by C−D' and D'(1−avg θ), respectively.

Let

G_i=nλ_i∫_{B_i}log L_i dx≥0,
Φ_i=D_i e_i+(1+ℓ_K)(D_i+G_i)≥0.

Nested receivers, nested radii and λ_{i+1}≤λ_i give

G_i−G_{i+1}≥nλ_{i+1}∫_{B_{i+1}}log(L_i/L_{i+1})dx≥J_i^geom.

Multiply (5) by D'=D_{i+1}. Use D'e_i^S≤C_i e_i^S≤D_i e_i−D_i d_bin from (2), D'log(C_i/D')≤C_i−D', and (6). Since C_i≤D_i, these yield the unconditional, zero-error descent

Φ_{i+1}≤Φ_i−D_i d_bin(p_i||ρ_i).                                    (7)

In particular for every finite actual chain,

Φ_m+Σ_{i<m}D_i d_bin(p_i||ρ_i)≤Φ_0
≤D_0[log(H/R_0)+(1+ℓ_K)(1+n log 2)].                                (8)

If S_i has zero mass, set p_i=ρ_i=0 and d_bin(0||0)=0. If a child is empty, its Φ is zero and the final step still follows from (2), since Φ_i≥D_i e_i≥D_i d_bin. Thus the theorem includes termination. This is a finite lower-bounded potential with all its errors paid. It is a new unweighted source-conditioning budget, not a dimension-improved weak fee: its initial scale contains D_0 and n, and the original-demand compensation is still necessary.

## 3. Threshold compensation: the exact remaining positive term

Let t_i=λ_0/λ_i=∏_{j<i}β_j^{-1}. Multiplying (7) by t_i and summing, with all endpoint terms retained, gives for m≥1

t_{m−1}Φ_m+Σ_{i<m}t_iD_i d_bin(p_i||ρ_i)
≤Φ_0+Σ_{i=1}^{m−1}(t_i−t_{i−1})Φ_i.                                (9)

For constant β the last summand is (1−β)t_iΦ_i. Equivalently β(t_{i+1}Φ_{i+1})≤t_iΦ_i−λ_0|B_i|d_bin. The positive occupation on the right of (9) is NOT bounded by (8). In fact, if E_comp denotes this right-hand sum,

E_comp≥(1+ℓ_K)Σ_{j=0}^{m−2}U_j.                                     (9a)

Indeed Φ_i≥(1+ℓ_K)D_i and (t_i−t_{i−1})D_i=(1−β_{i−1})λ_0|B_i|≥U_{i−1}. For m=1 the sum is empty. Thus this potential's compensation error includes the previous unpaid amplification; this does not exclude a new binary-gain or geometric bound paying it. The potential's receiver and geometric terms carry exactly the original threshold amplification after compensation. Neither an infinite limit nor a bound on the terminal weak expense H t_mW_m follows.

The original receiver accounting remains, at finite depth,

λ_0|R_0^recv|≤Σ_{i<m}t_i[A_iW_i+G_i^fee(W_i−W_{i+1})]+H t_mW_m,
G_i^fee=K/[c_i(1−δ_i)].                                             (10)

Here R_0^recv denotes the initial receiver event, distinct from the load ratio R_0. A_i includes every newly recomputed original-gate, coarse and packet branch. For the retained choices α=ε=1/[10log(n+2)], θ=log^{-2}(n+2), δ=1/2, c=1−2/[10log(n+2)], its prescribed components are B_base+B_ext+T_soft/α+P_packet+P_phys, with B_base=4+2log2 sqrt(7n/3), B_ext=2H/sqrt(n+2), and
P_packet=(5+3log(1/a))/ρ_packet, using the improved actual weighted packet payment.
The fixed choices a=n^{-p}, ρ_packet=n^{-1/2} give P_packet=O_p(sqrt(n)log(n+2)). An additionally invoked R83 deletion, layer fee, and all-scale logarithm must be included separately. Formula (8) pays none of these repeated weighted charges automatically.

## 4. Finite stopped joint entropy identifies the threshold cost

Now fix β_i=β and D_0>0. Set τ(x)=max{0≤i≤m:x∈B_i}. Define a second stopped law P^τ on B_0×R^n with the SAME uniform B_0 receiver marginal as P_0 and source conditional law μ_0|E_{τ(x)}(x)/μ_0(E_{τ(x)}(x)). This differs from the current P_i in §1. Its density against P_0 is β^{-τ}(L_0/L_τ)^n on its support. Thus, with h=log(1/β),

KL(P^τ||P_0)=h E_Xτ+n E_Xlog(L_0/L_τ)≤mh+nlog2.                    (11)

Define j_i=t_{i+1}J_i^geom=λ_0∫_{B_{i+1}}(1−θ_i)dx and
U_i=(1−β)λ_0∫_{B_{i+1}}θ_i dx.
The geometric potential nλ_0∫_{B_i}logL_i proves Σj_i≤nlog2 D_0. Direct summation gives

Σ_{i<m}U_i=(1−β)D_0 Eτ−(1−β)Σ_{i<m}j_i.

Therefore

0≤[(1−β)/h]D_0 KL(P^τ||P_0)−Σ_{i<m}U_i
≤(1−β)nlog2(1+1/h)D_0.                                             (12)

This is an exact identification of the missing cost, not a bound independent of m. No arbitrarily long qualified chain is asserted. If |B_1|>0 and m≥1, then KL(P_0||P^τ)=∞: on each persistent row E_τ⊂E_1 has μ_0-mass at most β times μ_0(E_0), so the removed capture set has positive P_0 mass and zero P^τ mass. Reversing KL cannot turn (12) into a finite decreasing potential.

## 5. An actual common-law martingale has positive entropy drift

Work under P_0 and reveal X at time zero. Freeze E_i and its mass at τ(X). Write s_i(X)=μ_0(E_{i∧τ}(X))/μ_0(E_0(X)),
F_i=σ(X,1_{E_{j∧τ}(X)}(Y):j≤i), M_i=1_{E_{i∧τ}(X)}(Y)/s_i(X).
This is a discrete finite filtration (completed if desired). M_0=1 and M_i≤β^{-m}2^n. Conditional on a live row and Y∈E_i, survival to E_{i+1} has probability s_{i+1}/s_i; outside E_i all later values vanish. This directly proves that M_i is a true finite martingale and

E[M_{i+1}logM_{i+1}−M_i logM_i|F_i]
=M_i1_{τ>i}log(s_i/s_{i+1})≥0.                                      (13)

Use 0log0=0. Its unconditional drift is
|B_0|^{-1}∫_{B_{i+1}}[h+nlog(L_i/L_{i+1})]dx.
Thus the correctly defined likelihood martingale produces the positive terminal entropy in (11). It does not produce a negative compensator for U. The source coordinate Y is generally not F_i-measurable. Including Y in F_0 makes the whole pair (X,Y) known initially and destroys the nonconstant martingale property. The projections E[M_i|Y] do not inherit a useful stage filtration or the same drift merely by calling them source projections. No infinite-horizon uniform integrability is used.

## 6. Variable thresholds and the remaining correction

For β_i=δ_ic_i, changing δ alone with c_i=c<1 leaves 1−β_i≥1−c. Allowing c_i→1 gives

G_i^fee=K/[c_i(1−δ_i)]≥K/(1−β_i),
T_soft/α_i≥T_soft/(1−β_i).

Hence Σ_{i<m}G_i^fee≥K m²/Σ_{i<m}(1−β_i). A summable threshold-loss schedule cannot have uniformly bounded fee coefficients. This does not rule out a scheme whose increasing coefficients are paid by separately proved weighted source decay. With variable β_i define U_i=(1−β_i)λ_0∫_{B_{i+1}}θ_i dx. Then

ΣU_i=λ_0∫_{B_0}Σ_{i<τ(x)}(1−β_i)dx−Σ(1−β_i)j_i,
0≤Σ(1−β_i)j_i≤nlog2D_0.                                           (14)

The next correction must control the positive occupation in (9), or establish receiver/source progress strong enough to pay (10), on the actual current-input diffuse class. A sufficient-looking entropy contraction without its weighted terminal is not a correction. The present (7) is useful because its errors have genuinely been paid; its compensated version displays precisely the new term that requires geometric information.

All radial forcing used in a closure remains defined on WHOLE F_i^rem. The inequality q_{B_i}≤q_{F_i^rem} permits a whole-event load-tail bound to pay the actual subset source filter; normalized radial variance is not subset monotone. The B_i potential above therefore cannot silently replace a whole-event I_T hypothesis. Rechecking packet masses and every gate after source restriction remains mandatory.

The general square-root-order bound remains **unproved**. This component removes a previously explicit finite-representation restriction: on every original compact regular receiver set there exists a continuum allocation whose source load is minimal in convex order. Its high-load levels give actual compact receiver cuts with exact common-source balance. The proof treats singular conditional allocations and boundary capture, rather than substituting a finite graph or a product-density assumption. It produces no improved dimension bound for those cuts. The geometric task left over is stated in Section 7.

## 1. Original data and the allocation problem

Let $n\ge1$, $\mu=fdy$ with nonnegative $f\in L^1(\mathbb R^n)$, and $\lambda>0$. Let $B$ be a compact regular subset of the original retained receiver event, with continuous original selector $L:B\to[1,2]$. Every original gate is retained. In particular,
\[
 \mu(Q(x,L(x)))=\lambda L(x)^n,\qquad
 \mu(Q(x,r))\le\lambda r^n\quad(1\le r<L(x)).          \tag{1}
\]
Demand is $\nu=\lambda1_Bdx$, with $D=\nu(B)<\infty$. If $D=0$, all demand conclusions are trivial; hence assume $D>0$. Put
\[
 N=\bigcup_{x\in B}Q(x,L(x)),\qquad
 E=\{(x,y)\in B\times N:y\in Q(x,L(x))\}.
\]
Both are compact because $B$ is compact and $L$ continuous. Restrict the source space to $N$; sources outside it have no legal edge and receive zero load.

An admissible allocation is a positive measure $\pi$ on $E$ with first marginal $\nu$ and second marginal $b\mu$. It may have singular conditional measures in the source variable. We do not claim that it has a joint density relative to $dx\,d\mu$. The source load $b$ is a density of its **marginal**, and source capacity $K$ means $b\le K$ almost everywhere with respect to the one common $\mu$.

The original canonical allocation
\[
 d\pi_0=1_B(x)L(x)^{-n}1_{Q(x,L(x))}(y)dx\,d\mu(y)
\]
is feasible. Its column satisfies $0\le b_0\le H_n:=1+n\log2$ by the retained full-window hard envelope. Thus the capped feasible class
\[
 \mathcal C_H=\{\pi:\pi_X=\nu,\ \pi_Y=b\mu,\ 0\le b\le H_n,
                              \operatorname{supp}\pi\subset E\}
\]
is nonempty. No source is copied or assigned a receiver-private capacity.

## 2. A universal density-point lemma for source sets

**Lemma.** For every measurable source set $A$, there is a $\mu$-null set $Z_A$ such that for every $y\in A\setminus Z_A$ and **every** positive-side axis-aligned cube $Q$ containing $y$,
\[
                         \mu(A\cap Q)>0.              \tag{2}
\]
The same exceptional set works for all these cubes, including cubes with $y$ on a face or corner.

To prove it, choose a Borel version of $f$ and of $A$. Almost every point of $A$ with respect to $\mu$ has $0<f(y)<\infty$ and is a Lebesgue density point of one of the sets
\[
 A_j=A\cap\{1/j\le f\le j\},\qquad j=1,2,\ldots .
\]
Indeed these sets cover $A$ up to a $\mu$-null set, and Lebesgue differentiation applies to each. Any cube containing $y$ contains, near $y$, one complete coordinate orthant of a sufficiently small ball. That orthant occupies the fixed fraction $2^{-n}$ of the ball. Density one of $A_j$ therefore forces its intersection with that orthant to have positive Lebesgue measure; $f\ge1/j$ there gives (2). This is the only coordinate geometry used in this lemma. It makes no independence assertion.

For a Borel representative of a bounded source load $b$, apply (2) simultaneously to the countably many sets $\{b<q\}$, $q\in\mathbb Q$. Outside one $\mu$-null set,
\[
 b(y)\ge \operatorname*{ess\,inf}_{z\in Q}^{\mu} b(z)
       \quad\hbox{for every positive-side cube }Q\ni y. \tag{3}
\]
For if $b(y)$ were smaller than that essential infimum, a rational value strictly between them would contradict (2).

A second consequence will be needed for singular allocations. For a measurable receiver set $A\subset B$, define its essential source neighborhood
\[
 N_A^{\rm ess}=\left\{y:\int_A1_{Q(x,L(x))}(y)dx>0\right\}. \tag{4}
\]
Every admissible allocation sends the demand on $A$ into this set, up to null sets. To see this, put $M=N\setminus N_A^{\rm ess}$. Tonelli gives $\mu(Q(x,L(x))\cap M)=0$ for $\nu$-almost every $x\in A$. By (2), outside one source-null set every point of $M$ belongs only to cubes whose intersection with $M$ has positive source mass. Such a point cannot be captured by any of those good receiver rows. An allocation has row marginal $\nu$ and source marginal absolutely continuous with respect to $\mu$, so neither exceptional set can carry allocated mass. This proves the claim without requiring $\pi\ll dx\,d\mu$.

## 3. Attainment and the row-minimum certificate

Minimize
\[
             \mathcal J(\pi)=\frac12\int_N b(y)^2d\mu(y)
                         \quad\hbox{over }\mathcal C_H. \tag{5}
\]
An optimizer exists. All candidate plans have the same finite mass on the compact space $B\times N$, hence a minimizing sequence has a weakly convergent subsequence of measures. Their columns are bounded in $L^2(\mu)$ by $H_n$ and have a weakly convergent subsequence there. Testing against continuous functions of $y$ identifies the limit marginal with the weak $L^2$ column limit. The constraints $0\le b\le H_n$ are weakly closed; the first marginal remains $\nu$; the closed legal relation $E$ retains all the mass. Weak lower semicontinuity of the $L^2$ norm proves attainment. Mixing two minimizing plans and using strict convexity shows that the minimizing column $b_*$ is unique up to $\mu$-null sets. The plan itself need not be unique.

Choose a Borel representative and define
\[
             m(x)=\operatorname*{ess\,inf}_{Q(x,L(x))}^{\mu}b_*.
                                                                  \tag{6}
\]
Each contact cube has positive source mass, so this infimum is well-defined in $[0,H_n]$. It is measurable. In fact it is upper semicontinuous on $B$: for every real $q$,
\[
 \{x:m(x)<q\}
 =\left\{x:\int_{Q(x,L(x))}1_{\{b_*<q\}}d\mu>0\right\}
\]
a relatively open set. The integral is continuous in $x$ by dominated convergence, because $L$ is continuous and an $L^1$ source gives every cube boundary zero mass.

**Row-minimum theorem.** Every optimizer in (5) satisfies
\[
                         b_*(y)=m(x)\quad\pi_*\text{-a.e.}       \tag{7}
\]
The inequality $b_*(y)\ge m(x)$ on all legal edges outside one source-null set follows from (3), so it also holds for a singular optimizer.

For the reverse inequality, suppose a positive amount is allocated where $b_*(y)>m(x)$. Choose rational $q<q'$ so that a positive donor part has $b_*>q'$ on rows with $m<q$. Let
\[
 c_q(x)=\mu(Q(x,L(x))\cap\{b_*<q\})>0.
\]
Disintegrate $\pi_*$ over $\nu$ and retain a positive donor part on rows where $c_q(x)\ge1/M$ for some finite $M$. This is possible by a countable exhaustion. On each such row, move a small common fraction of its donor mass to the probability measure
\[
        c_q(x)^{-1}1_{Q(x,L(x))\cap\{b_*<q\}}d\mu.
\]
The row marginal and legal support are unchanged. The new recipient column has density at most $MD$, so it belongs to $L^2(\mu)$. Recipients have $b_*<q<H_n$; choose the moved fraction at most $(H_n-q)/(MD)$ and at most one. This explicitly preserves the cap, while donors only lose mass. The directional derivative of (5) is at most minus $(q'-q)$ times the positive moved donor mass, because every recipient has cost below $q$ and every donor above $q'$. The finite quadratic remainder is of second order, so a sufficiently small move strictly lowers (5), a contradiction. This proves (7).

Equations (3) and (7) also give an explicit dual certificate. For every other admissible plan with column $c$ for which the integral is defined,
\[
 \int b_*c\,d\mu\ge\int_Bm(x)d\nu(x)=\int b_*^2d\mu.       \tag{8}
\]
This is directly proved weak duality with equality at $\pi_*$, not an invocation of an infinite-dimensional strong-duality theorem.

## 4. Compact saturated cuts and continuum convex order

For every $s>0$ put
\[
 A_s=\{x\in B:m(x)\ge s\},\qquad S_s=\{y:b_*(y)\ge s\}.
\]
The receiver set $A_s$ is compact. Its actual geometric neighborhood is compact as well. We have
\[
 N_{A_s}^{\rm ess}=\bigcup_{x\in A_s}Q(x,L(x))=S_s
                   \quad\text{modulo }\mu\text{-null sets},       \tag{9}
\]
\[
                  \nu(A_s)=\int_{S_s}b_*d\mu.                   \tag{10}
\]
Here and below equality of a geometric set with $S_s$ is an equality in source measure; no equality of the underlying point sets is asserted.

For the upper inclusion in (9), every $x\in A_s$ satisfies $\mu(Q_x\cap\{b_*<s\})=0$. Apply (2) to the single source set $\{b_*<s\}$: outside its one exceptional source-null set, none of these cubes can contain such a point. This handles the union over uncountably many rows. For the reverse inclusion, (7) shows that the part of $\pi_*$ with source in $S_s$ is exactly its part with receiver in $A_s$. The essential-neighborhood result following (4) puts that part into $N_{A_s}^{\rm ess}$. Its source marginal is $b_*1_{S_s}\mu$, and $b_*\ge s>0$, so $S_s$ is contained in the essential neighborhood modulo $\mu$. The mass identity gives (10).

Strict levels $\{m>s\},\{b_*>s\}$ obey the same identities by increasing unions of levels with thresholds tending down to $s$. This also applies at $s=0$. Every competing admissible column $c$, with no cap or $L^2$ assumption required, must supply all the demand of the strict receiver level from the corresponding strict source level. Consequently, for every $s\ge0$,
\[
                 \int(c-s)_+d\mu\ge\int(b_*-s)_+d\mu.          \tag{11}
\]
Indeed the left side is at least its integral over $\{b_*>s\}$; the integral of $c$ there is at least the demand of $\{m>s\}$, which equals $\int_{b_*>s}b_*d\mu$. Both columns have total mass $D$. The hinge representation of a convex function therefore gives the continuum convex-order conclusion, with the usual extended-value interpretation whenever the comparator integral is infinite. In particular every convex moment available for the canonical column transfers to $b_*$ without assuming a finite principal partition.

The optimal capacity is exactly
\[
 \|b_*\|_{L^\infty(\mu)}
 =\sup_{A\subset B}\frac{\nu(A)}{\mu(N_A^{\rm ess})}
 =\sup_{\substack{A\subset B\text{ compact}\\\nu(A)>0}}
                  \frac{\nu(A)}{\mu(\bigcup_{x\in A}Q_x)}.
                                                                  \tag{12}
\]
The ratios only use positive-demand sets; their denominators are positive because the canonical plan is feasible. Any admissible plan of capacity $K$ bounds every such ratio by $K$, using (4) for essential neighborhoods and ordinary legal support for geometric neighborhoods. Conversely, for every $0<s<\|b_*\|_\infty$, the compact cut $A_s$ has positive demand and, by (9)--(10), ratio at least $s$. Let $s$ increase to the essential supremum. This proves (12), but does not assert that the final supremum itself is attained by a positive-demand cut.

## 5. Exact geometric inheritance of principal source cuts

Set $f_s=f1_{S_s}$. For every $x\in A_s$, not just for the allocated part of its source law,
\[
 \mu(Q_x\setminus S_s)=0.
\]
Thus for every physical prefix $1\le r\le L(x)$,
\[
 \int_{Q(x,r)}f_sdy=\int_{Q(x,r)}fdy.                    \tag{13}
\]
The original anchor, earliest hard contact and the entire captured source posterior are unchanged on this cut. For any specified fixed packet grid, every captured packet fraction
\[
        p_j(x)=\mu_j(Q_x)/(\lambda L(x)^n)
\]
is also unchanged. In particular the R86 fixed-grid diffuse condition is preserved at the old selector. This assertion concerns a specified grid and gives no extra uniformity under arbitrary refinement.

More generally, let $\nu_x=1_{Q_x}\mu/(\lambda L(x)^n)$ be the actual captured probability and $\nu_x^{(s)}=1_{Q_x}(f_sdy)/(\lambda L(x)^n)$. Equation (13) gives $\nu_x^{(s)}=\nu_x$ for every $x\in A_s$. Consequently, at the same old selector and every fixed physical scale $h>0$, the R87 statistics
\[
 C_h(x)=\iint\prod_{i=1}^n(1-|y_i-z_i|/h)_+\,d\nu_x(y)d\nu_x(z),
 \qquad
 \overline H_h(x)=\mathbb E_\theta\sum_jp_{\theta,j}(x)
                                     \log\frac1{p_{\theta,j}(x)}
                                                            \tag{13a}
\]
are exactly preserved. Here $\theta$ is uniform on $[0,h)^n$, $p_{\theta,j}$ are the posterior masses of the translated half-open side-$h$ grid cells, and $0\log(1/0)=0$; $\overline H_h$ is the coverage report's $\mathcal H_h$. Each individual grid-cell mass is unchanged for every shift, so the averaged Shannon entropy and $\bar\eta_a$ are unchanged as well. The selected cube meets only finitely many such cells, so this entropy is finite. In particular, the new whole-residual labels $C_{h_*}<3/4$ and $\overline H_{h_*}>\sqrt n$ are inherited on $A_s$ whenever they held there originally. This preservation statement keeps the old contact and threshold; it does not assert preservation after reselection at a different threshold.

All nonnegative original or coarse smooth upper bounds can only improve under $f_s\le f$. Two properties do **not** automatically survive: a strict later hard witness may use a source outside the old cube, and the original middle lower bound may use smooth mass outside it. We do not apply a theorem requiring either lost property to $f_s$ with the old labels. At every lower threshold $\lambda'<\lambda$, however, the old contact cube is a strict hard witness for $f_s$. From (10),
\[
 \frac{\lambda'|A_s|}{\|f_s\|_1}
       =\frac{\lambda'}\lambda\frac{\int_{S_s}b_*d\mu}{\mu(S_s)}
       \ge\frac{\lambda'}\lambda s.                    \tag{14}
\]
If a proof uses this new input, it must reselect and reclassify all required gates and pay their existing fees. Equation (14) has no extra dimension factor, but is not itself an upper bound.

## 6. What this adds to the retained estimates

The continuum optimizer and its compact source-closed cuts are new infrastructure beyond the retained finite principal statement. Applying (11) to the actual original canonical column $b_0$ now rigorously gives, for every $T\ge2$,
\[
 \int(b_*-T)_+^2d\mu\le\int(b_0-T)_+^2d\mu
       \le24n^2 I_T(B)+48D/T,                            \tag{15}
\]
and the R86 near-center pair estimate gives alternatively
\[
 \int(b_*-T)_+^2d\mu
       \le12n^2\mathcal E_{T,a}(B)+96D/[T(1-a)^2].       \tag{16}
\]
The right sides use the **original canonical** source laws on the same $B$. They are not conditional variances under $\pi_*$, and are not silently recomputed on $A_s$. Neither sourcewise radial density bounds nor row-age laws transfer automatically to a possibly singular optimized conditional allocation. Equations (15)--(16) remove a continuum existence qualification, not the missing geometric estimate for their right sides.

There is no new dimension, mesh, packet-count, scale-depth, or limiting fee in (2)--(16). The only initial cap is the retained $H_n$ used to obtain a compact feasible class. The theorem applies directly to every regular compact cut authorized by the R82 reduction. It does not claim a new optimizer for arbitrary noncompact or discontinuous-selector data; the separately owned lifted Hall interface addresses that broader scope. Layerwise use retains the original layer count, and the all-scale return retains its logarithm.

## 7. Remaining high-load geometry and proof discipline

The exact remaining task can now be stated on actual compact cuts: bound the ratios in (10) for principal levels whose original receiver rows also lie in the whole diffuse coarse-low residual. Those cuts have a genuine common-source closure and exact original prefix equations. No argument here bounds their size by $\sqrt n\,n^{o(1)}$, nor bounds their far-pair energy by $W/n$. The original smooth gate and diffuse condition remain available on the original rows, but a restriction-based argument must respect the two lost gates listed above.

The two-row prefix obstruction from R86 still applies to any attempt to infer a far-pair discount from just two chains. Generic balancing or energy descent adds no such discount. The additional content here is continuum attainment, a dual certificate, convex-order minimality, and compact spatial source-closed levels. A new multirow inequality using these levels, the retained smooth conditions, or a justified reselection ledger is still required for a dimensional gain.

The precise theorem was sent to both independent auditors before author proof. Their blind checks validated the density-point mechanism, capped first-variation route, and essential-neighborhood repair; full proof receipts and three-stage tests are recorded only after actual completion. A03 and D01 were read with their interfaces: the compactness and positive-coupling assumptions are proved here, rather than borrowed from a copula, vector transport, or path-law model. B01 is used only in the direct weak-duality sense of (8). No infinite strong-duality theorem, unproved coordinate independence, or finite-mesh limit is substituted for the argument.

The general cube weak bound remains **UNPROVED**. This note proves a measurable-selector Hall/deficiency interface, with no numerical improvement in capacity. Its entropy tool remains conditional on quantified overlap or joint-law comparison. R82 gates, the R86 paid packet branch, whole-residual restrictions, and the separate scale/layer fees remain unchanged.

## 1. Two primary sources and reading boundaries

**Entropy.** Raginsky, *Strong Data Processing Inequalities and Φ-Sobolev Inequalities for Discrete Channels*, arXiv:1411.3575v4 (30 March 2016), [primary PDF](https://arxiv.org/pdf/1411.3575). For finite alphabets write η(p,K)=sup_{q≠p}D(qK‖pK)/D(q‖p). Admissibility requires positive p and pK. Theorem 3.1 bounds η by max-row total variation; Remark 3.2 gives the finite common-minorization bound 1−ε. Theorem 3.9 gives η(⊗p_i,⊗K_i)=max_iη(p_i,K_i). Theorem 3.11 gives
\[
 \eta(p,K)\le1-\frac aA[1-\eta(\bar p,\bar K)],\quad
 a=\min_x\frac{\bar p(x)}{p(x)},\quad
 A=\max_{x,y}\frac{\bar p(x)\bar K(y|x)}{p(x)K(y|x)}.
\tag{S1}
\]
Both-zero ratio cells are set to zero; a positive numerator over zero denominator makes A infinite. Read the theorem statements and proofs on printed pp.12–13,28–30,33–34, and Lemma A.4 on pp.67–68. Theorem 3.1's external Markov-contraction antecedent was not independently reread. No full-paper audit is claimed.

**Printed-proof qualification and our repair of the KL comparison.** In Theorem 3.11's proof, rewriting the actual joint expectation through the reference joint RN density is not an equality when the actual law has extra support. Finite A only supplies reference joint ≤A times actual joint. For positive f and B(u,v)=u log(u/v)−u+v≥0, the finite variational sums instead give
\[
 \operatorname{gap}_{p,K}(f)
 =\inf_\xi\sum_{x,y}p(x)K(y|x)B(f(x),\xi(y))
 \ge A^{-1}\operatorname{gap}_{\bar p,\bar K}(f),
 \qquad \operatorname{Ent}_{\bar p}(f)\ge a\operatorname{Ent}_p(f).
\]
Here gap is the mean conditional entropy. The reference SDPI bounds its gap below by (1−ηbar)Entbar, which proves (S1). KL entropy is homogeneous, so positive nonconstant f is normalized under each reference without changing the ratio. Nonnegative nonconstant f follows by positive approximation and finite-alphabet continuity with a positive denominator. This repair is our coordinatewise nonnegative-Bregman derivation; it preserves the theorem's conclusion without reverse joint absolute continuity and does not certify the printed equality in the extra-support case.

**Transport.** Beiglböck–Schachermayer, *Duality for Borel measurable cost functions*, arXiv:0807.1468v1 (9 July 2008), [primary PDF](https://arxiv.org/pdf/0807.1468). Theorem 1: Polish spaces, Borel probability marginals, nonnegative Borel cost finite product-almost-everywhere, and one finite-cost plan imply equality of the primal infimum and the integrable-potential dual supremum. Read Theorem 1, Lemma 1.1, and the proof assembly through Theorem 2 and the subsidy/sandwich argument; not every auxiliary source was independently checked. Here the bounded cost 1 outside a closed relation satisfies every finiteness hypothesis. Primal attainment below follows from tightness and lower semicontinuity, not Borel duality alone.

The exact cube transfers below are proved here; they are not statements attributed to either paper.

## 2. Closed lifting removes selector continuity from coupling Hall

Let B⊂R^n be Borel, ν=λ1_B dx have finite mass D, λ>0, and let L:B→[1,2] be Borel. Let μ=f dy be finite with f≥0, W=μ(R^n), and κ=Kμ, M=KW. Assume D≤M and M>0. Define
\[
 T(x)=(x,L(x)),\quad \widehat\nu=T_\#\nu,\qquad
 R=\{((x,l),y):2\|x-y\|_\infty\le l\}.
\tag{S2}
\]
R is closed in (R^n×[1,2])×R^n although the selected graph need not be closed. A finite Borel measure on this Polish space is Radon. No compact receiver support or bounded source support is assumed.

For a Borel row cut A⊂B put
\[
 N(A)=\bigcup_{x\in A}Q(x,L(x)),\qquad
 S_A=\{y:\int_A1_{Q(x,L(x))}(y)\,d\nu(x)>0\}.
\tag{S3}
\]
N(A) is analytic, hence measurable in the completed finite source measure; S_A is Borel. The following are equivalent:

* a positive coupling γ has receiver marginal ν, source marginal ≤κ, and γ-almost every pair (x,y) satisfies y∈Q(x,L(x));
* ν(A)≤κ(N(A)) for every Borel A⊂B;
* ν(A)≤κ(S_A) for every Borel A⊂B.

The statements also hold for ν-completed measurable cuts via a Borel version. They assert coupling feasibility, not that γ has a density relative to ν×μ or that every disintegrated row kernel is absolutely continuous.

### 2.0 The actual earliest-contact selector is Borel

For the retained earliest ≥λ convention, g(x,l)=l^{-n}μ(Q(x,l)) is jointly continuous on R^n×[1,2]: cube indicators converge off the limiting boundary, which has zero source measure because μ≪dy, and f is an integrable dominator. Set L*(x)=inf{l∈[1,2]:g(x,l)≥λ}, with +∞ for an empty set. For each fixed a∈[1,2],
\[
 \{x:L^*(x)\le a\}
 =\{x:\max_{1\le l\le a}g(x,l)\ge\lambda\}
\]
is closed, since a continuous function maximized over a fixed compact interval depends continuously on x. Thus L* is Borel on its finite-hit domain. The original anchor g(x,1)<λ and strict later witness make the minimum finite, greater than one, and an exact equality contact by continuity. This proves measurability for that actual convention; it does not prove selector continuity or replace a different selector definition.

### 2.1 Direct closed-relation Hall proof

Adjoin an isolated receiver ∂ of mass M−D, legal to all sources. The receiver measure ρ=νhat+(M−D)δ_∂ and source κ have equal mass M. The augmented legal relation R' is closed. Dummy-containing cuts have all source neighbors and satisfy Hall automatically.

Physical cut inequalities imply Hall for every compact lifted cut C: A=T^{-1}(C) is Borel, νhat(C)=ν(A), and N(A)⊂R(C). Off-graph points only enlarge the lifted neighborhood. For any Borel lifted cut, inner regularity gives its demand as the supremum of compact-cut demands; their neighborhoods lie inside the original neighborhood. Thus all augmented Borel cut inequalities hold.

Choose finite partitions on bounded boxes of both spaces with bounded-cell diameters tending to zero, one exterior cell on each side, and a separate dummy cell. Enlarge boxes until both marginal tail masses tend to zero. Join two cells when their product meets R'. For any union of receiver cells, its actual legal neighborhood is contained in the union of adjacent source cells. The finite weighted Hall inequalities therefore hold. Finite max-flow produces cell flows with the prescribed marginal cell masses. Spread each positive flow over the normalized product of its two marginal restrictions; zero-mass cells carry no flow.

For pairs in bounded cells, their distance to R' is at most the sum of the two cell diameters. Pairs involving an exterior cell have mass at most the sum of the two marginal tails. All these approximate couplings have the same marginals, hence are uniformly tight by the marginal union bound. A weakly convergent subsequence preserves both marginals. For any ε>0 the open set {distance to R'>ε} has asymptotically zero mass; Portmanteau gives zero mass to it in the limit. The limit is supported on closed R'. Remove the dummy row and project (x,l) to x. Since the lifted receiver marginal is T#ν, this yields the required actual-selector coupling. Necessity follows by restricting any legal coupling to the cut and its analytic neighborhood. This proof uses neither a regular-selector approximation nor an assumption of density-flow attainment. The finite-flow/tight-limit proof itself only needs finite Radon marginals and a closed relation; source absolute continuity is first used in §2.2. It therefore also permits the isolated dummy source used below.

If D=0 the zero coupling works. If K=0 or W=0 and D>0 no coupling is possible. If D>M the total-mass cut already fails.

### 2.2 Cube/L1 identification of the essential neighborhood

Fix A and set S=S_A, taking a Borel version of f. Tonelli gives
\[
 \int_A\mu(Q(x,L(x))\cap S^c)\,d\nu(x)=0.
\]
Delete the Borel ν-null set of rows for which this nonnegative integrand is positive; call the remaining full-measure set A'.

For μ-almost every y∈S^c there is an integer k with f(y)≥1/k and y a Lebesgue density point of S^c∩{f≥1/k}. This follows by applying the density theorem to those countably many measurable sets. Every axis-aligned cube of positive side containing such a y contains a fixed orthant portion of all sufficiently small balls centered at y, including when y lies on a face or corner. The density-one property therefore gives μ(Q∩S^c)>0 for every such cube. Consequently no good y outside S belongs to any Q(x,L(x)) with x∈A'. Thus μ(N(A')\S)=0. Deleting ν-null rows leaves every section integral unchanged, so S⊂N(A') pointwise. Hence
\[
 \mu(N(A'))=\mu(S_A),\qquad
 \inf_{A''\subset A,\ \nu(A\setminus A'')=0}\mu(N(A''))=\mu(S_A),
\tag{S4}
\]
where the infimum runs over Borel full-measure subsets. This proves the essential-cut equivalence and invariance under ν-null modifications. The density argument is the same cube-specific interface used in the parent's and alternative author's essential-minimum checks; it requires μ≪dy. For a general closed relation, a positive-section neighborhood need not describe singular couplings.

## 3. Exact capacity deficiency, without a maximizing cut

Keep D≤M. Let
\[
 \Delta_K=\sup_{A\subset B\ {\rm Borel}}[\nu(A)-\kappa(N(A))]_+
 =\sup_A[\nu(A)-\kappa(S_A)]_+.
\tag{S5}
\]
The equality uses (S4) and ν(A')=ν(A). The minimum mass outside R' among couplings of ρ and κ is exactly Δ_K. It is attained.

For every cut, its demand can reach only κ(N(A)) through legal edges; hence illegal mass is at least that cut's positive deficit. For the converse, adjoin an isolated dummy source z of mass Δ_K, legal to all receiver points, and increase the receiver dummy mass to M+Δ_K−D. Every real-row cut now has enough capacity by the definition of Δ_K; any dummy-containing cut is automatic. The closed Hall proof produces a wholly legal augmented coupling. After discarding z, its real-row part has demand deficit d≤Δ_K. Its unused physical source mass is M−D+d. Split this remaining source measure into masses M−D and d; send the first part to the original receiver dummy, and fill the unmatched real-row measure of mass d using a product coupling with the second part. At most d mass is illegal. Together with the cut lower bound this proves exact equality, with no assumption that a maximizing cut exists.

The original fixed-marginal coupling class is tight and weakly closed. Its cost c=1_(R')^c is bounded and lower semicontinuous, so a minimizing plan exists. Normalizing both marginals by M, the primary transport theorem also gives
\[
 \Delta_K=M\sup_{\phi+\psi\le c}
 \left[\int\phi\,d(\rho/M)+\int\psi\,d(\kappa/M)\right],
\tag{S6}
\]
with integrable potentials and an everywhere constraint. We assert a supremum, not an integrable dual maximizer. The new result is a measurable/noncompact coupling interface; it contributes no improvement to the required K or general weak constant.

## 4. Actual common-source entropy prerequisites

A directly proved arbitrary-correlation option is common refreshment. If a stochastic kernel has K_x≥εR_0 for a common probability R_0 and 0<ε<1, write K_x=εR_0+(1−ε)K'_x. Joint convexity and data processing give
\[
 D(PK\|QK)\le(1-\varepsilon)D(P\|Q)
\tag{S7}
\]
for probability inputs P,Q, with extended nonnegative entropy conventions. At ε=1 the output is constant and its entropy is zero, treated separately. This works on standard Borel spaces and introduces no dimensional constant; the missing hypothesis is the actual ε. An explicit actual patch bridge is: if a Borel source E lies in every capture cube Q_x of a receiver patch A and μ(E)≥ε sup_{x∈A}m_x>0, then K_x≥ε μ|E/μ(E). Thus (S7) applies on that patch with the original input and gates. The retained gates do not supply this common-mass condition, and entropy contraction alone is not a settlement of U.

For the actual captured posterior K_x=μ|Q_x/m_x, m_x=λL(x)^n, a direct integration of the two densities gives
\[
 \|K_x-K_z\|_{\rm TV}
 =1-\frac{\mu(Q_x\cap Q_z)}{\max(m_x,m_z)}.
\tag{S8}
\]
This maps the primary row-overlap coefficient to an exact same-source geometric quantity. Small fixed-grid packet shares and low translated-grid pair concentration do not bound it. A coordinate noise kernel at a fixed scale is not automatically this adaptive posterior kernel.

For a persistent row in the actual nested bad-row recursion, E_i⊂E_0 and m_i=μ_0(E_i)=β^iλ_0 L_i^n. Therefore
\[
 \|\mu_0|E_i/m_i-\mu_0|E_0/m_0\|_{\rm TV}=1-\beta^i(L_i/L_0)^n,
\quad D(\mu_0|E_i/m_i\|\mu_0|E_0/m_0)
 =i\log(1/\beta)+n\log(L_0/L_i).
\tag{S9}
\]
The overlap can shrink with depth. This checks the direction of that finite-horizon common-law entropy identity: it is terminal conditioning cost. A separate finite unweighted source-entropy descent can coexist with this identity; its threshold weighting requires its own ledger. The identity (S9) does not pay the threshold-amplified U_i or the weighted whole-residual variance forcing.

A separate usable option from (S1) is to exhibit a finite-alphabet reference pair (pbar,Kbar) with known gap and prove 0<a/A uniformly. Actual input correlations are then allowed. If the reference is product, tensorization requires BOTH reference input and reference channel to factor. Actual support holes can make A infinite; mere positivity permits arbitrarily large A/a. Source-label refinement and tiny shares supply no such comparison. Passing finite partitions to the actual continuous law would additionally require a stable comparison and an explicit entropy-limit argument. No such bridge has been established.

## 5. Boundary checks and retained gaps

| Stage | Exact scope checked | Outcome |
|---|---|---|
| Pilot | Finite weighted Hall, all-cut defect versus max-flow; overlap identity and nested finite conditioning | Algebra agrees, including zero-defect/zero-mass conventions. |
| Known-pressure check | Previously retained singular-plan warning, null row changes, depth conditioning and support holes | Lifted coupling theorem handles the first two; entropy does not acquire a uniform refreshment/comparison constant. No actual new lower bound is inferred. |
| Expanded | Noncompact/unbounded marginal tails, measurable selector, all measurable cuts; finite overlap checks across 2,3,8,32 source states and depths 1,2,8,32 | Hall follows from the proved tight limit and cube density interface, independent of n. The entropy identities remain exact while the needed uniform constant is absent. |

Executed replay: 96 rational weighted-Hall cases (1,2,4,8 row states; 2,3,8,32 source states) matched exhaustive cut deficiency to exact Fraction max-flow. Across depths 1,2,8,32, 172 rational nested-overlap cases passed; floating KL replay had maximum absolute discrepancy 0 in those cases. The KL replay is a floating diagnostic; the displayed KL identity is proved algebraically. No physical-gate claim is inferred.

Exact finite replay: use nonnegative rational source masses, nonempty nested subsets, and m_i their sums; then sum min(1_E/m_E,1_F/m_F)μ=μ(E∩F)/max(m_E,m_F). All entropy expressions use finite positive captured masses. The dimension-free Hall proof is a theorem for all n, not a fit to a dimension sweep. Finite checks do not certify a complete-gate physical counterexample or a density allocation.

Read updated A03, D01, D04 and M04 skill contracts and the relevant cube interfaces. A03's specialized copula theorem is not used as a general existence theorem. D01's vector KR neutral plans are not the positive coupling theorem here. D04 permits correlated laws only with their actual conditional kernels and correctly oriented entropy weights. M04's finite selector case does not establish general measurable selection; L being Borel is an explicit input, and no new argmax selector is manufactured.

The next concrete missing inputs are a common-source geometric bound for low-local-pair rows, an actual paid overlap/reference-comparison mechanism, or a threshold-weighted forcing estimate. None follows from the two source theorems. The measurable Hall extension may be used for optimizing reassignment after such a capacity estimate is proved; it does not provide that estimate.

本轮改进了原后验列的采样接口，但没有得到新的、完整合格的高负载剩余事件，也没有证明过滤方差预算、Hall 容量界或一般的平方根维数界。实际输入压力探索保留在私有记录中；公开程序只包含通用有理恒等式、条件区间计算和非物理代数对照。

令 \(H_n=1+n\log2\)，\(r(x,y)=\max(1,2\|x-y\|_\infty)\)。源中心的硬极大包络为
\[
 h_y(x)=r(x,y)^{-n}\mathbf1_{Q(y,2)}(x),\qquad \int h_y\,dx=H_n.
\]
提议分布以概率 \(1/H_n\) 在单位立方体内均匀采样；以概率 \(n\log2/H_n\) 在壳层采样：全边长 \(r\) 在 \([1,2]\) 上对数均匀，面和符号均匀，其余坐标在该面内均匀。每个面参数化的 Jacobian 是 \(r^{n-1}/2\)，故壳层密度为 \(r^{-n}/H_n\)，内立方体密度为 \(1/H_n\)。

当所选边长 \(L_*\in[1,2]\) 捕获源点时，原后验列的单样本权重为
\[
 w=H_n(r/L_*)^n\mathbf1_{\{y\in Q(x,L_*)\}}\le H_n.
\]
内立方体必须使用截断半径 \(r=1\)：此处权重是 \(H_nL_*^{-n}\)，不能用未截断的 \(2\|x-y\|_\infty\)。取 \(u=\log r\)，三项矩变量分别被 \(H_n,H_n\log2,H_n(\log2)^2\) 控制。此密度和权重计算依赖真实 \(dx\)，不把面采样理解成接收测度本身集中在低维面上。

第一阶段验证同一对数值下的内外概率和、面 Jacobian 与截断半径权重。第二阶段对旧的外缘密度趋零提议分布做代数对照：在非物理固定选择器 \(L=2\) 下，其权重可超过 \(H_n\) 并随外缘逼近发散，而新权重仍有上界。这个对照没有声称任何原门槛下的实际最早接触事件。第三阶段扩大维数，并检查三矩的条件误差半径、分母区间和方差区间方向。

对三个**准确求值、独立同分布**的归一化变量，Hoeffding 不等式与联合界给出同时误差半径
\[
 \varepsilon_N=\sqrt{\log(6/\delta)/(2N)}.
\]
代码以对数的有理包络及二进制向上平方根给出其严格上界。若归一化矩同时落在 \([b_-,b_+]\)、\([m_{1,-},m_{1,+}]\)、\([m_{2,-},m_{2,+}]\)，且 \(b_->0\)，则条件方差的外包络可取
\[
 \max\{0,m_{2,-}/b_+-(m_{1,+}/b_-)^2\}
 \le V\le
 \min\{1/4,m_{2,+}/b_--(m_{1,-}/b_+)^2\}.
\]
若 \(b_-=0\)，返回完整区间 \([0,1/4]\)。这只是条件区间传递；高负载阈值判定和源测度积分还需要各自的不确定性处理。公开合成样例验证算术方向，不宣称该样例是独立物理样本。

另有两组初等接口检查。第一，若一个准确验证的严格硬见证位于被查询源点的截断半径之前，则真正最早接触也在该半径之前，该源点的列贡献为零。它为预筛提供条件充分依据；私有扫描中的浮点符号不是这个前提的精确证书。第二，若 \(\|f\|_\infty\le M\)，微网格全边长为 \(\epsilon_g\)，则每个包份额至多 \(M\epsilon_g^n/(\lambda L_*^n)\)。该上界严格小于指定份额阈值时，\(\eta_a=0\)，对网格平移同样成立。这是密度假设下的初等充分条件，既不证明门槛合格，也不产生维数增益。

私有实际探索完成了三个阶段：重复不稳定的旧采样区域、改变共同源几何、扩大维数。新权重的有界性消除了此前外缘大权重问题；预筛与不预筛在固定样本上的列捕获判定一致。过滤后估计没有显示目标高负载列。少量有效捕获样本导致条件矩及方差仍不稳定，不能把这一结果解释为排除高负载。硬根、全窗口软门槛和软核截断误差尚未严格包络，故所有实际矩、经验标准误和有效样本量均为诊断，没有置信证书。当前仅查询有限源点，没有估计整个源测度的高负载质量，也没有估计 \(I_T\)。

公开程序共保存 95 条记录：12 个归一化维数、15 个面 Jacobian、35 个权重、6 个旧提议代数对照、6 个条件矩区间、18 个密度充分条件以及 3 个条件前缀见证。程序自包含，只用 Python 标准库；本机公开重放约 0.02 秒。精确分数见 `hall_results.json`。一般目标仍未证明。

## R87 independent Astra proof audit

The author proofs were read after independent statement and countermechanism prechecks. The mathematical results below PASS, with the stated scopes. The general uniform bound C_n <= sqrt(n) n^(o(1)) remains unproved.

**Direct common-source budgets.** For contact data with the actual source mu = f dy, the geometric packet envelope and the exact marginal-rank mean give, for every measurable receiver cut A:

lambda integral_A eta_bar_a dx <= [E_h + B_h + (1 + E_h) log(1/a)] mu(N_A).

The source restriction to the essential neighborhood preserves contact and all captured packet masses; it needs no inherited smooth gate. Jointly measurable averaging does not assume independence of physical coordinates. Integrating the cutoff gives the q > 1 packet-moment fee E_h + B_h + (1 + E_h)/(q - 1). In particular:

lambda integral_A C_h dx <= (B_h + 1 + 2 E_h) mu(N_A).

The fixed-scale collision/entropy union has the single proved fee P_phys = 2[E_* + B_* + 2(1 + E_*) sqrt(n)]. The geometric-cover corollary has fee at most 14[1 + log(N) + n^(3/2) sqrt(delta)] when 0 < delta <= 1/(16n). The robust cover bound uses actual outside mass. These are unconditional payments for explicit branches, not assertions that those branches exhaust the input.

**Continuous capacity interfaces.** The compact, continuous-selector problem has an attained positive coupling with unique source column minimizing every convex load functional. A universal source-density-point argument handles cube boundaries and singular conditional allocations. Its upper level rows are compact saturated Hall cuts, and the optimal capacity equals the supremum of their ratios; a maximizing positive-demand cut is not asserted. A separate closed lift proves coupling Hall and exact capacity deficiency for Borel selectors and finite unbounded marginals. The actual earliest-contact selector is Borel by joint continuity of the hard average. These theorems concern couplings and source marginal densities; product-density allocation is not inferred.

Principal source restriction preserves the actual captured posterior, all original hard prefixes and the fixed-scale collision/entropy statistics at the unchanged selector. It need not preserve the strict later hard witness or the original middle smooth lower gate. Canonical radial/pair estimates transfer to the optimized column through convex order, not through an assumed transfer of canonical conditional laws.

**Actual entropy descent and its remaining expense.** The finite bad-source recursion has a nonnegative unweighted potential Phi_i = D_i e_i + (1 + ell_K)(D_i + G_i), satisfying Phi_(i+1) <= Phi_i - D_i d_bin(p_i || rho_i), including termination. The child joint-law likelihood, source-projection total variation, and geometric error payments were checked directly. Threshold compensation retains:

 t_(m-1) Phi_m + sum_(i<m) t_i D_i d_bin(p_i || rho_i)
 <= Phi_0 + sum_(1<=i<m) (t_i - t_(i-1)) Phi_i.

The positive term dominates the preceding U_i costs, except the final stage. It is not paid by unweighted descent. Repeated branch charges and the weak terminal H_n t_m W_m therefore remain. The stopped-KL and finite martingale identities have the correct common law, orientation and filtration; no infinite-horizon conclusion is taken.

**Exact remaining scope.** The new whole event is F_rem = F_diff intersect {C_(h_*) < 3/4, Hbar_(h_*) > sqrt(n)}. Every source restriction recomputes gates, selectors, packet masses and physical statistics. Current nested receiver sets do not replace this whole event in a radial forcing hypothesis. Unweighted conditional variance is not receiver-subset monotone. The single combined branch is paid once; repeated-input fees, background-layer counts when used, and the all-scale logarithm remain explicit.

**Evidence and failed inferences.** The qualified private certificate was independently replayed exactly without rewriting author files: six positive-volume records pass the retained original and new coarse-low gates, and one control is correctly rejected by the new coarse gate. It proves only that small fixed-grid shares can coexist with physical concentration and that the new averaged branch removes that origin artifact. It has small burden and is not a high-load, Hall-capacity or weak-type counterexample. No private recipe appears here. Public hard-envelope sampling formulas have the correct clamped radius and Jacobian; confidence formulas require exact predicates and independent samples. The actual exploratory searches remain diagnostics, without a certified whole-source I_T or retained high-load conclusion. Program guards owned by other auditors are not represented as this auditor's replays.

All four author MD/TeX proof pairs were checked for consistency. External primary-source reading provenance remains attributed to its source reader; this audit independently verifies the newly proved transfers. No supplied lower-bound construction is part of this public audit.

## Independent public conclusion

The R87 general bound **C_n <= sqrt(n) n^{o(1)} remains UNPROVED**. Independent blind proposition checks preceded proof reads. The final public Markdown and TeX proofs in coverage, adaptive, alternative and sources were read in full and pass within their explicit hypotheses. These findings certify the stated lemmas and finite checks; they do not certify the remaining complete receiver event.

The substantive unconditional payment is the physical, translation-averaged packet budget. At fixed side h, set E_h=exp(nh), B_h=1+E_h[1+(2n²+n)h]. Exact marginal tail ranks have mean one even with arbitrary source-coordinate dependence. They give, for EVERY measurable receiver cut A,

lambda integral_A eta_bar_a dx <= [E_h+B_h+(1+E_h)log(1/a)] mu(N_A).

Here N_A is the positive-section essential neighborhood in the SAME original source measure. Integrating the packet threshold yields the q-moment budget and, at q=2, the physical collision budget lambda integral_A C_h dx <= [B_h+1+2E_h] mu(N_A). These are weighted all-cut statements, not unconditional demand bounds for low collision. At h_*=1/(16n^{3/2}), the UNION of collision >=3/4 and averaged grid entropy <=sqrt(n) has the single proved fee 2[E_*+B_*+2(1+E_*)sqrt(n)]=O(sqrt(n)) per window. Averaging shifts introduces no copy count or independent capacity. The remaining whole current residual has both C_h*<3/4 and entropy>sqrt(n). Refinement h->0 does not pay that residual. Row-dependent physical covers and the explicit bound 14[1+log N+n^{3/2}sqrt(delta)] are sufficient inclusion criteria for the same entropy branch, with the actual outside probability required when a cover has a remainder.

The new unweighted source-entropy potential Phi_i=D_i e_i+(1+log(H_n/K))(D_i+G_i) obeys Phi_child<=Phi_i-D_i d_bin. Its proof uses the actual strict bad-row witness C_i>D_child, a shared source law, a bounded old log-density oscillation, and the exact joint total-variation identity. Empty-child and endpoint cases are included. Threshold compensation is positive: the error in the finite weighted inequality contains at least (1+log(H_n/K)) times the preceding U_j sum. Thus unweighted descent does not settle threshold amplification, the repeated branch fees, the weighted terminal H_n t_m W_m, or whole-residual radial forcing. The current B_i and the whole current residual cannot be interchanged for normalized variance. Source restriction requires every gate and statistic to be recomputed.

On compact original B with continuous L, the alternative proves continuum quadratic attainment, a unique source column minimal in convex order, and compact saturated source-closed receiver levels. The density-point lemma applies outside ONE source-null set to EVERY positive-side axis cube, including boundary cubes; this resolves singular conditional allocations. The bounded rerouting construction explicitly preserves the H_n cap. Optimal capacity is the supremum of all-cut Hall ratios, with no claim that its final supremum is attained. On a principal cut the original captured posterior, all prefixes, packet shares, physical C_h and averaged entropy are exactly preserved at the old selector. Strict later witnesses and the original middle lower gate are not automatically preserved. Neither existence nor convex order supplies a root-order capacity estimate.

The sources proof independently constructs the Hall coupling for a Borel selector by closed lifting, finite flows and tight weak limits; selector continuity and bounded support are not assumed. For positive L1 source, universal cube density points identify essential neighborhoods even for singular couplings. Balanced dummy augmentation proves that minimum illegal mass equals the all-cut deficiency, and bounded lower-semicontinuous cost supplies attainment. The actual earliest >=lambda contact is Borel by joint cube-average continuity; this does not make that selector continuous. Common refreshment and posterior-overlap entropy tools require their stated actual shared-source overlap, and do not pay U by themselves.

For source provenance this audit reopened [Beiglböck–Schachermayer, Theorem 1](https://arxiv.org/pdf/0807.1468) and [Raginsky, Theorem 3.11 and its comparison proof](https://arxiv.org/pdf/1411.3575). The bounded 0/1 cost meets the former's finiteness requirements; it is not a hard infinite-cost duality substitution. In the latter, an RN equality can fail when the actual joint law has extra support. The source author's nonnegative KL-Bregman comparison repairs the inequality without reverse absolute continuity. This audit does not claim to reread every external proof in the source bibliography.

## Actual independent execution

The public producer stores **95 generic or conditional algebra records**, not a fully gated high-load physical certificate. Its proposal normalization is a Lebesgue-density identity, and its confidence bounds require exact independent samples, selectors, predicates and kernel evaluations; they are not applied to uncertified private numerical gates. The public guard imports no producer functions.

| Independent check | Executed scope and outcome |
|---|---|
| Shift/collision lift | Three stages, 6 dependent finite posterior laws; complete rational shift arrangements independently equal the triangular product, with eta_bar>=C_h-a and one labeled-source Tonelli projection. NONPHYSICAL arrays. |
| Packet moments/cover | 72 width/mean comparisons, 72 threshold-moment models, 48 marginal-rank/cover models across n=2,3,4 / 8,32,128 / 512,4096. Exact threshold breakpoint integration and directed exponential/log enclosures; arbitrary physical-input qualification is not asserted. |
| Stopped joint and proposal | 6 finite common-source stopped-law models and 9 normalization/Jacobian models in three stages. Reverse absolute continuity, lifetime/U identity and fee-versus-loss tradeoff checked. These do not construct an actual retained recursion. |
| Principal/Hall | 12 finite graphs with 2/3, 4/5 and 6/8 row/source states, 14 saturated blocks. Exhaustive receiver cuts, exact Fraction Edmonds–Karp capacity/conservation/mincut, descending block densities, all hinge breakpoints, optimal Hall capacity and 36 legal-flow deficiency comparisons passed. These are finite NONPHYSICAL analogues of the proved continuum theorem. |
| New source potential | 9 shared-source arrays in three stages n=2,4,8. Exact contact-mass algebra and joint/source TV, plus rational outward log enclosures proving the zero-error descent and compensation direction. NONPHYSICAL; no qualified high-q chain existence inferred. |
| Frozen public JSON | All 95 records independently reconstructed: normalization 12, face Jacobian 15, captured weights 35, explicitly NONPHYSICAL old-proposal comparison 6, conditional moments 6, conditional density 18, prefix implication 3. |

Independent isolated main replay: **exit 0**, empty stderr, **0.021639208 s**, output JSON byte-identical to the frozen data. Independent portable guard replay: **exit 0**, empty stderr, **3.737058958 s** (guard internal elapsed 3.716284 s), with 3,868 successful checks. The isolated directory contained only the public Hall pair, the extracted guard, and placeholder proof/inventory files; no component manuscripts, skills, private files or outside-path dependencies were available. This verifies package-shape portability. The parent's later assembled-archive replay is a separate receipt, not claimed here before execution.

The guard requires only Python standard library and the frozen Hall pair beside it. After extracting the single Python fence from the public proof, run `python3 -B audit_guard.py`. It hashes the code/data, verifies records, and executes the independently written finite checks. It does not rerun the producer; the separate main replay above does. No PDF compilation, Git operation or other author's file edit was performed by this auditor.

Frozen public pair:

- hall_probe.py: `eff94464e582ac459e35569bdec77b7348caeac47efff7cb4391a9e08e72893e`
- hall_results.json: `050bec6775e598db4ac47f995879a5b66c05f8fd14fb382327e79e84abac873f`
- audit_guard.py: `d2115599047422e5c57d22472b34a1f1e7f99e56bc6dca0ede26bcc4984b36ef`

The original R82 gates remain the master interface. Additional old deletions, background-layer charges and all-scale logarithmic return stay separate in the ledger. Public audit conclusions include only upper lemmas, their hypotheses and anonymous method limitations; private recipes and their file dependencies remain outside this extraction. No general residual capacity, high-load source contraction or dimensional asymptotic conclusion follows from these finite executions.

## 独立公开证书审核程序

```python
#!/usr/bin/env python3
"""R87 independent PUBLIC guard. Finite arrays are NONPHYSICAL.
Only the frozen public pair is required beside this file.
No private recipes, author imports, external paths or external modules.
"""
from fractions import Fraction as F
from itertools import product
from pathlib import Path
import hashlib,json,math,time
ROOT=Path(__file__).resolve().parent
COUNT={}
def check(x,tag):
    if not x:raise AssertionError(tag)
    k=tag.split(':')[0];COUNT[k]=COUNT.get(k,0)+1

def log_bounds(x,terms=64):
    x=F(x);assert x>0
    if x==1:return F(0),F(0)
    if x<1:
        a,b=log_bounds(1/x,terms);return -b,-a
    k=0
    while x>2:x/=2;k+=1
    def unit(v):
        z=(v-1)/(v+1);lo=2*sum(z**(2*j+1)/(2*j+1) for j in range(terms))
        hi=lo+2*z**(2*terms+1)/((2*terms+1)*(1-z*z))
        return lo,hi
    a,b=unit(x);c,d=unit(F(2));return a+k*c,b+k*d

def collision_stages():
    # Dependent finite posterior laws, not positive-L1 physical fixtures.
    stages=[(1,[(1,3),(2,3)]),(2,[(2,5),(3,4)]),(3,[(3,5),(4,5)])]
    records=0
    for stage,models in stages:
        for n,N in models:
            h=F(1,4*stage);a=F(1,N+2)
            ys=[tuple(h*F((i*(j+2)+j)%7,5) for j in range(n)) for i in range(N)]
            weights=[F(i+1,N*(N+1)//2) for i in range(N)]
            cuts=[]
            for j in range(n):
                cuts.append(sorted(set([F(0),h]+[y[j]-(y[j]//h)*h for y in ys])))
            avg_eta=avg_sq=F(0);mass=F(0)
            for inds in product(*[range(len(c)-1) for c in cuts]):
                shift=tuple((cuts[j][i]+cuts[j][i+1])/2 for j,i in enumerate(inds))
                vol=math.prod(cuts[j][i+1]-cuts[j][i] for j,i in enumerate(inds))/h**n
                packet={}
                for y,w in zip(ys,weights):
                    key=tuple((y[j]-shift[j])//h for j in range(n));packet[key]=packet.get(key,F(0))+w
                eta=sum(p for p in packet.values() if p>=a);sq=sum(p*p for p in packet.values())
                check(sq<=eta+a,'collision:small and large share inequality')
                avg_eta+=vol*eta;avg_sq+=vol*sq;mass+=vol
            tri=sum(w*v*math.prod(max(F(0),1-abs(y[j]-z[j])/h) for j in range(n))
                    for y,w in zip(ys,weights) for z,v in zip(ys,weights))
            check(mass==1,'collision:complete shift arrangement')
            check(avg_sq==tri,'collision:independent exact triangular product identity')
            check(avg_eta>=tri-a,'collision:averaged dominant capture bound')
            # Labeled source costs integrate once; projection removes label.
            gains=[[F((i+j)%5+1,7) for i in range(N)] for j in range(stage+2)]
            shiftw=[F(j+1,(stage+2)*(stage+3)//2) for j in range(stage+2)]
            source=[sum(v*g[i] for v,g in zip(shiftw,gains)) for i in range(N)]
            joint=sum(v*sum(w*t for w,t in zip(weights,g)) for v,g in zip(shiftw,gains))
            check(joint==sum(w*t for w,t in zip(weights,source)),'lift:shared-source label projection Tonelli')
            check(all(0<=t<=1 for t in source),'lift:fractional source restriction')
            records+=1
    print('COLLISION THREE STAGES',records,'dependent finite posterior laws NONPHYSICAL')

def entropy_stages():
    records=0
    for stage,ns,m in [(1,[2,4],3),(2,[8,32],8),(3,[128,4096],16)]:
        for n in ns:
            beta=F(2,5);length=[F(2)-F(i,2*m) for i in range(m+1)]
            survive=[beta**i*(length[i]/length[0])**n for i in range(m+1)]
            bins=sorted(set([F(0),F(1)]+survive));widths=[b-a for a,b in zip(bins,bins[1:])]
            lifetime_weights=[F(i+1,(m+1)*(m+2)//2) for i in range(m+1)]
            initial=widths;kl_lo=kl_hi=F(0);chain_lo=chain_hi=F(0);reverse_lost=F(0)
            lb_lo,lb_hi=log_bounds(1/beta)
            for tau,p in enumerate(lifetime_weights):
                stopped=[w/survive[tau] if b<=survive[tau] else F(0) for b,w in zip(bins[1:],widths)]
                check(sum(initial)==1 and sum(stopped)==1,'entropy:shared row marginal normalized')
                check(survive[tau]==beta**tau*(length[tau]/length[0])**n,'entropy:exact survival ratio')
                check(all(q==0 or q/w==1/survive[tau] for q,w in zip(stopped,widths)),'entropy:joint RN density')
                c,d=log_bounds(length[0]/length[tau]);chain_lo+=p*(tau*lb_lo+n*c);chain_hi+=p*(tau*lb_hi+n*d)
                # Exact multiplicative RN identity supplies the logarithm
                # decomposition, without constructing enormous Taylor ratios.
                check(1/survive[tau]==beta**(-tau)*(length[0]/length[tau])**n,
                      "entropy:exact RN factorization for KL")
                kl_lo+=p*(tau*lb_lo+n*c);kl_hi+=p*(tau*lb_hi+n*d)
                reverse_lost+=p*sum(w for q,w in zip(stopped,widths) if q==0)
            check(max(kl_lo,chain_lo)<=min(kl_hi,chain_hi),'entropy:log identity interval consistency')
            check(reverse_lost>0,'entropy:reverse absolute continuity fails')
            etau=sum(F(i)*w for i,w in enumerate(lifetime_weights))
            U=J=F(0)
            for i in range(m):
                rows=sum(lifetime_weights[i+1:]);ratio=(length[i+1]/length[i])**n
                U+=(1-beta)*rows*ratio;J+=rows*(1-ratio)
            check(U==(1-beta)*(etau-J),'entropy:threshold error lifetime identity')
            # Exact depth-dependent entropy coefficient tradeoff.
            losses=[F(i+1,4*m) for i in range(m)]
            check(sum(1/x for x in losses)*sum(losses)>=m*m,'entropy:fee versus summable loss Cauchy')
            check(all(0<x<1 for x in losses),'entropy:admissible coefficients')
            records+=1
    print('STOPPED JOINT THREE STAGES',records,'finite common-source arrays NONPHYSICAL; no actual retained-chain existence')

def proposal_stages():
    records=0
    for stage,ns in [(1,[1,2,4]),(2,[8,32,128]),(3,[512,4096,65536])]:
        for n in ns:
            # log width is a formal positive rational H0; density/Jacobian
            # identity and mixture normalization are algebraically exact.
            H0=F(1,2);H=1+n*H0
            check(F(1,H)+n*H0/H==1,'proposal:unit and face probabilities')
            for r in [F(1),F(5,4),F(3,2),F(7,4),F(2)]:
                density=r**(-n)/H
                check(n*r**(n-1)*density==n/(H*r),'proposal:radial face Jacobian')
                for L in [r,(r+2)/2,F(2)]:
                    w=H*(r/L)**n
                    check(0<=w<=H,'proposal:actual capture importance bound')
                    for j in range(4):check(w*H0**j<=H*H0**j,'proposal:bounded moment integrand')
            records+=1
    print('PROPOSAL THREE STAGES',records,'exact normalization/Jacobian; no numerical selector/gate certification')

def exp_upper(x):
    # Positive Taylor tail, dyadic range reduction and integer outward rounding.
    x=F(x);Q=1<<120;k=0
    while x>F(1,2):x/=2;k+=1
    term=total=F(1)
    for j in range(1,33):term*=x/j;total+=term
    upper=total+2*term*x/33
    u=-((-upper.numerator*Q)//upper.denominator)
    for _ in range(k):u=-((-u*u)//Q)
    return F(u,Q)

def fraction_flow(demand,capacity,neighbors):
    # Independent exact Edmonds-Karp, not a producer import.
    nr,ns=len(demand),len(capacity);sink=nr+ns+1;N=sink+1
    original={};adj=[set() for _ in range(N)]
    def edge(a,b,c):
        original[a,b]=F(c);adj[a].add(b);adj[b].add(a)
    for i,d in enumerate(demand):edge(0,1+i,d)
    for i,mask in enumerate(neighbors):
        for j in range(ns):
            if mask>>j&1:edge(1+i,1+nr+j,sum(demand))
    for j,c in enumerate(capacity):edge(1+nr+j,sink,c)
    residual={}
    for (a,b),c in original.items():residual[a,b]=c;residual[b,a]=F(0)
    value=F(0)
    while True:
        pred={0:None};queue=[0]
        for a in queue:
            for b in sorted(adj[a]):
                if b not in pred and residual.get((a,b),0)>0:pred[b]=a;queue.append(b)
            if sink in pred:break
        if sink not in pred:break
        b=sink;path=[]
        while b: a=pred[b];path.append((a,b));b=a
        amount=min(residual[e] for e in path)
        for a,b in path:residual[a,b]-=amount;residual[b,a]+=amount
        value+=amount
    flows={e:c-residual[e] for e,c in original.items()};balance=[F(0)]*N
    for (a,b),v in flows.items():
        check(0<=v<=original[a,b],'flow:capacity enclosure');balance[a]-=v;balance[b]+=v
    check(balance[0]==-value and balance[sink]==value and all(v==0 for v in balance[1:sink]),
          'flow:independent exact conservation')
    cut=sum(c for (a,b),c in original.items() if a in pred and b not in pred)
    check(cut==value,'flow:residual mincut equals exact flow')
    return value,flows

def principal_stages():
    records=blocks=0
    for stage,(nr,ns) in enumerate([(2,3),(4,5),(6,8)],1):
        for seed in range(4):
            p=[F(j+1,ns*(ns+1)//2) for j in range(ns)]
            demand=[F((i+seed)%5+1,11) for i in range(nr)]
            neighbors=[]
            for i in range(nr):
                mask=sum(1<<j for j in range(ns) if (i*3+j*2+seed)%(stage+3)<=stage)
                neighbors.append(mask or 1<<(i%ns))
            def cuts(rows,masks):
                answer=[]
                for bits in range(1,1<<len(rows)):
                    union=0;d=F(0)
                    for k,i in enumerate(rows):
                        if bits>>k&1:union|=masks[i];d+=demand[i]
                    mass=sum(p[j] for j in range(ns) if union>>j&1)
                    answer.append((d/mass,union,[i for k,i in enumerate(rows) if bits>>k&1]))
                return answer
            rows=list(range(nr));masks=neighbors[:];load=[F(0)]*ns;previous=None
            while rows:
                candidates=cuts(rows,masks);K=max(v[0] for v in candidates)
                source=0
                for k,u,_ in candidates:
                    if k==K:source|=u
                forced=[i for i in rows if masks[i]&~source==0]
                check(sum(demand[i] for i in forced)==K*sum(p[j] for j in range(ns) if source>>j&1),
                      'principal:union maximizing cut exact saturation')
                if previous is not None:check(K<previous,'principal:maximal tight union gives strictly descending densities')
                value,flow=fraction_flow([demand[i] for i in forced],
                         [K*p[j] if source>>j&1 else F(0) for j in range(ns)],
                         [masks[i] for i in forced])
                check(value==sum(demand[i] for i in forced),'principal:block demand saturated')
                for j in range(ns):
                    if source>>j&1:load[j]=K
                rows=[i for i in rows if i not in forced]
                for i in rows:
                    masks[i]&=~source
                    check(masks[i]!=0,'principal:nonempty residual legal neighbors')
                previous=K;blocks+=1
            canonical=[F(0)]*ns
            for i,mask in enumerate(neighbors):
                mass=sum(p[j] for j in range(ns) if mask>>j&1)
                for j in range(ns):
                    if mask>>j&1:canonical[j]+=demand[i]/mass
            check(sum(p[j]*load[j] for j in range(ns))==sum(demand),'principal:one source total mass')
            for T in sorted(set([F(0)]+load+canonical)):
                check(sum(p[j]*max(F(0),load[j]-T) for j in range(ns))<=
                      sum(p[j]*max(F(0),canonical[j]-T) for j in range(ns)),
                      'principal:all hinge breakpoints convex order')
            check(max(load)==max(c[0] for c in cuts(list(range(nr)),neighbors)),
                  'principal:optimal capacity equals allcut Hall')
            # Maximum legal flow deficit: all-cut defect = D-maxlegal.
            # Balanced completion additionally requires total source capacity>=D.
            for factor in [F(1,2),F(1),F(3,2)]:
                cap=[factor*max(load)*v for v in p]
                defect=max([F(0)]+[sum(demand[i] for i in rr)-sum(cap[j] for j in range(ns) if u>>j&1)
                            for _,u,rr in cuts(list(range(nr)),neighbors)])
                value,_=fraction_flow(demand,cap,neighbors)
                check(sum(demand)-value==defect,'hall:exact defect no maximizing-cut shortcut')
            records+=1
    print('PRINCIPAL THREE STAGES',records,'finite graphs',blocks,
          'saturated blocks; NONPHYSICAL exact flow/allcut/convex-order analogues')

def kl_interval(p,q):
    lo=hi=F(0)
    for a,b in zip(p,q):
        if a:
            check(b>0,'potential:finite absolute continuity');u,v=log_bounds(a/b);lo+=a*u;hi+=a*v
    return lo,hi

def source_potential_stages():
    records=0
    for stage,(n,N) in enumerate([(2,2),(4,3),(8,4)],1):
        for variant in range(3):
            beta=F(2,5);lam=F(1,4*2**n);H=F(4)
            L=[F(3,2)+F(i,N*3) for i in range(N)];Lp=[v-F(1,2)+F(variant,100) for v in L]
            keep=N-1;caps=[lam*v**n for v in L];S=F(3,4)*min(caps)
            child=[beta*lam*v**n for v in Lp[:keep]]
            check(all(1<=u<v<=2 for u,v in zip(Lp,L)),
                  'potential:admissible nested radius proxies')
            cuts=sorted(set([F(0),F(1),S]+caps+child));mass=[b-a for a,b in zip(cuts,cuts[1:])]
            P=[[w/F(N)/v**n if b<=c else F(0) for b,w in zip(cuts[1:],mass)] for v,c in zip(L,caps)]
            Crows=[[w/F(N)/v**n if b<=c else F(0) for b,w in zip(cuts[1:],mass)]
                   for v,c in zip(Lp[:keep],child)]
            D=sum(map(sum,P));Dp=sum(map(sum,Crows));b=[sum(r[j] for r in P)/mass[j] for j in range(len(mass))]
            old=[sum(r[j] for r in P)/D for j in range(len(mass))]
            new=[sum(r[j] for r in Crows)/Dp for j in range(len(mass))]
            inS=[t<=S for t in cuts[1:]];p=sum(v for v,g in zip(old,inS) if g);C=p*D
            cond=[v/p if g else F(0) for v,g in zip(old,inS)]
            ref=[w/S if g else F(0) for w,g in zip(mass,inS)]
            K=min(v for v,g in zip(b,inS) if g)/2
            check(D==lam and Dp==beta*lam*F(keep,N) and C>Dp,
                  'potential:contact mass and strict old restricted witness algebra')
            check(all(K<v<=H for v,g in zip(b,inS) if g),'potential:one source log oscillation range')
            tv=sum(abs(a-c) for a,c in zip(new,cond))/2
            oldjoint=[v/C if g else F(0) for r in P for v,g in zip(r,inS)]
            newjoint=[v/Dp for r in Crows for v in r]+[F(0)]*((N-keep)*len(mass))
            jointtv=sum(abs(a-c) for a,c in zip(newjoint,oldjoint))/2
            theta=sum((Lp[i]/L[i])**n for i in range(keep))/keep
            Jg=Dp*(1-theta)
            check(jointtv==1-Dp/C*theta and tv<=jointtv,
                  'potential:exact joint TV and contraction')
            check(Dp*tv<=C-Dp+Jg,'potential:unnormalized TV payment')
            eo=kl_interval(old,mass);en=kl_interval(new,ref);binary=kl_interval([p,1-p],[S,1-S])
            ell=log_bounds(H/K)
            Gold=[F(0),F(0)];Gnew=[F(0),F(0)]
            for i in range(N):
                u,v=log_bounds(L[i]);Gold[0]+=n*lam*u/N;Gold[1]+=n*lam*v/N
                if i<keep:
                    u,v=log_bounds(Lp[i]);Gnew[0]+=n*beta*lam*u/N;Gnew[1]+=n*beta*lam*v/N
            oldPhi=D*eo[0]+(1+ell[0])*(D+Gold[0])
            newPhi=Dp*en[1]+(1+ell[1])*(Dp+Gnew[1])
            check(newPhi+D*binary[1]<=oldPhi,'potential:outward-log zero-error source entropy descent')
            check((1/beta-1)*Dp>=(1-beta)*Dp/beta*theta,
                  'potential:threshold compensation contains previous U')
            records+=1
    print('SOURCE POTENTIAL THREE STAGES',records,
          'finite common-source arrays; exact masses/TV and outward rational log descent, NONPHYSICAL')

def coverage_checks():
    models=moments=covers=0
    for stage,ns in [(1,[2,3,4]),(2,[8,32,128]),(3,[512,4096])]:
        for n in ns:
            # Rational side choices; hstar below its integer-sqrt conservative
            # upper. No finite physical posterior/gates are asserted.
            hs=[F(1,16*n*n),F(1,16*n*math.isqrt(n)),F(1,4)]
            for h in hs:
                E=exp_upper(n*h);B=1+E*(1+(2*n*n+n)*h)
                for a in [F(1,4),F(1,n*n),F(1,n**3)]:
                    l,u=log_bounds(1/a);rho=F(1,2)
                    mean=(E+B+(1+E)*u)/rho
                    H=1+n*log_bounds(2)[1];qlog=log_bounds(4*H/rho)[1]
                    old=1+2*(B+(1+E)*u+2*E*qlog)/rho
                    check(mean<=old,'mean:direct mean improves source-tail price')
                    check(B>=1+E,'mean:geometric cost signs')
                    models+=1
                # Exact integral of a^(q-2)eta(a) on its complete breakpoint
                # arrangement, independently compared with sum of q-powers.
                ps=[F(1,2),F(1,3),F(1,6)];cuts=sorted(set([F(0),F(1)]+ps))
                for q in [2,3,5]:
                    result=F(0)
                    for lo,hi in zip(cuts,cuts[1:]):
                        mid=(lo+hi)/2;eta=sum(p for p in ps if p>=mid)
                        result+=eta*(hi**(q-1)-lo**(q-1))
                    check(result==sum(p**q for p in ps),'moment:complete threshold integral identity')
                    price=E+B+(1+E)/F(q-1)
                    if q==2:check(price==B+1+2*E,'moment:physical collision price constant')
                    moments+=1
            # Marginal rank -log integrals telescope for arbitrarily dependent
            # shifted/reflected U coordinates; no physical independence.
            for M in [3,5,9]:
                coeff={};constant=F(0)
                for j in range(M):
                    lo,hi=F(j,M),F(j+1,M);constant+=hi-lo
                    if lo not in (0,1):coeff[lo]=coeff.get(lo,F(0))+lo
                    if hi not in (0,1):coeff[hi]=coeff.get(hi,F(0))-hi
                check(constant==1 and all(v==0 for v in coeff.values()),
                      'rank:exact marginal minus-log mean telescope')
                covers+=1
            # Optimized cover width with rational square roots: delta=n h^2.
            # nh<=1/4 guarantees all analytic conditions; S=n^2 h.
            for h in [F(1,8*n),F(1,16*n),F(1,32*n*n)]:
                delta=n*h*h;S=n*n*h;E=F(4,3)
                check(delta<=h and delta<=F(1,16*n) and n*h<=F(1,4),
                      'cover:optimized width conditions')
                B=1+E*(1+(2*n*n+n)*h)
                check(B<=F(7,3)+F(10,3)*S,'cover:source geometry width bound')
                for logN in [F(0),F(1),F(3)]:
                    bound=2*(E+B+2*(1+E)*(logN+F(3,4)*S))
                    check(bound<=14*(1+logN+S),'cover:universal fourteen coefficient')
                covers+=1
    print('COVERAGE THREE STAGES',models,'width/mean comparisons',moments,
          'threshold moments',covers,'rank/cover models; NONPHYSICAL algebra')

EXPECTED={
 'hall_probe.py':'eff94464e582ac459e35569bdec77b7348caeac47efff7cb4391a9e08e72893e',
 'hall_results.json':'050bec6775e598db4ac47f995879a5b66c05f8fd14fb382327e79e84abac873f'}

def actual_checks():
    for name,digest in EXPECTED.items():
        check(hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest,
              'bytes:frozen public object')
    z=json.loads((ROOT/'hall_results.json').read_text())
    check(z['schema']=='R87-public-bounded-canonical-proposal-v1','schema:current scope')
    l2,u2=log_bounds(2)
    for r in z['normalization_records']:
        n=r['n'];lo,hi=map(F,r['H_interval'])
        check(lo<=1+n*l2<=1+n*u2<=hi,'json:independent H enclosure')
        ip=list(map(F,r['inner_probability_interval']));sp=list(map(F,r['shell_probability_interval']))
        check(ip==[1/hi,1/lo] and sp==[1-1/lo,1-1/hi],
              'json:matched probability directions')
    for r in z['face_jacobian_records']:
        n=r['n'];rad=F(r['r']);jac=rad**(n-1)/2
        check(F(r['face_chart_jacobian'])==jac,'json:independent face chart Jacobian')
        check(F(n)/rad/F(2*n)/jac==F(r['density_times_H'])==rad**(-n),
              'json:Lebesgue density and Jacobian')
        check(F(r['residual'])==0,'json:zero face residual')
    for r in z['canonical_weight_records']:
        n=r['n'];dist,L=F(r['distance_inf']),F(r['L_selected']);rad=max(F(1),2*dist)
        captured=rad<=L;ratio=(rad/L)**n if captured else F(0)
        check(r['captured']==captured and F(r['r_clamped'])==rad,'json:clamped capture')
        check(F(r['canonical_weight_divided_by_H'])==ratio and 0<=ratio<=1,
              'json:captured normalized weight bound')
        lo,hi=map(F,r['weight_interval'])
        check(lo<=(1+n*l2)*ratio<=(1+n*u2)*ratio<=hi,
              'json:independent weight enclosure')
    for r in z['old_proposal_algebra_records']:
        m=r['m'];rad=2-F(1,2**m);a=F(4,5)*(rad**-2-F(1,4));b=F(1,5)*(1/rad-F(1,2))
        dlo,dhi=map(F,r['old_density_interval']);wlo,whi=map(F,r['old_weight_interval'])
        check(dlo<=a+b/u2<=a+b/l2<=dhi,'json:old density interval direction')
        check(wlo==F(1,2)/dhi and whi==F(1,2)/dlo,
              'json:old importance interval direction')
        check(wlo>F(r['H_upper']) and F(r['new_weight_divided_by_H'])==rad/2,
              'json:NONphysical old comparison')
    for r in z['conditional_moment_records']:
        cert=r['radius_certificate'];N=cert['N'];delta=F(cert['delta'])
        lo,hi=map(F,cert['log_six_over_delta_interval']);l,u=log_bounds(6/delta)
        check(lo<=l<=u<=hi,'json:independent conditional logarithm')
        rad=F(cert['normalized_simultaneous_radius_upper']);x=hi/F(2*N)
        check(rad*rad>=x and (rad-F(1,1<<48))**2<x,
              'json:integer directed radius minimality')
        check(F(cert['square_residual'])==rad*rad-x,'json:radius residual')
        est=list(map(F,r['synthetic_normalized_estimates']));b,a,c=est
        exact=c/b-(a/b)**2
        check(F(r['synthetic_weighted_variance'])==exact,
              'json:synthetic weighted variance')
        I=r['interval_lift'];bl,bh=max(F(0),b-rad),min(F(1),b+rad)
        al,ah=max(F(0),a-rad),min(bh,a+rad)
        cl,ch=max(F(0),c-rad),min(ah,c+rad)
        expected=[F(0),F(1,4)] if bl==0 else [max(F(0),cl/bh-(ah/bl)**2),min(F(1,4),ch/bl-(al/bh)**2)]
        check(list(map(F,I['normalized_conditional_variance_interval']))==expected,
              'json:conditional variance outward arithmetic')
        check(expected[0]<=exact<=expected[1],'json:synthetic variance enclosed')
    for r in z['conditional_density_diffuse_records']:
        n,p=r['n'],r['p'];eps=F(r['grid_side']);bound=F(r['density_upper'])*eps**n/F(r['lambda_value'])/F(r['L_lower'])**n
        a=F(1,n**p)
        check(F(r['packet_share_upper'])==bound<a==F(r['share_threshold']),
              'json:conditional density sufficient inequality')
        check(F(r['strict_residual'])==a-bound,'json:density residual')
    for r in z['conditional_prefix_witness_records']:
        check(1<=F(r['witness_scale'])<F(r['clamped_source_radius'])<=2 and
              F(r['witness_average_hypothesis'])>F(r['threshold']),
              'json:conditional prefix implication only')
    sizes=[len(z[k]) for k in ['normalization_records','face_jacobian_records','canonical_weight_records',
           'old_proposal_algebra_records','conditional_moment_records','conditional_density_diffuse_records',
           'conditional_prefix_witness_records']]
    check(sizes==[12,15,35,6,6,18,3] and sum(sizes)==95,'schema:95 public generic records')
    print('PUBLIC FROZEN JSON:95 independent generic/conditional algebra records; no fully gated high-load certificate')

def main():
    start=time.monotonic();collision_stages();entropy_stages();proposal_stages();coverage_checks()
    principal_stages();source_potential_stages();actual_checks()
    print('PASS',json.dumps(COUNT,sort_keys=True),'elapsed_seconds',round(time.monotonic()-start,6))
if __name__=='__main__':main()
```
