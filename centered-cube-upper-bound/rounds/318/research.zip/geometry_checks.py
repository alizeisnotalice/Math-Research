from fractions import Fraction as F
from itertools import product
ct={'physical_geometry':0,'edge_credit':0,'covariance_identity':0,'local_fixture':0}
centers=[-F(19,20),-F(7,10),F(7,10),F(19,20)]
cells=[(x-F(1,100),x+F(1,100)) for x in centers]
yboxes=[(-F(1,200)-F(1,2000),-F(1,200)+F(1,2000)),
        (F(1,200)-F(1,2000),F(1,200)+F(1,2000))]
zbox=(-F(1,1000),F(1,1000));R=F(9,5);eta=F(3,5);h=F(1,100)
for cell,ybox in product(cells,yboxes):
 assert max(abs(x-y) for x,y in product(cell,ybox))<1;ct['physical_geometry']+=1
for i,j in product(range(4),repeat=2):
 if i!=j:
  assert min(abs(x-w) for x,w in product(cells[i],cells[j]))>h
  ct['physical_geometry']+=1
cap=[0,1,1,0]
for cell,c in zip(cells,cap):
 dd=[abs(x-z) for x,z in product(cell,zbox)]
 if c:assert max(dd)<R/2 and min(dd)>eta*R/2
 else:assert min(dd)>R/2
 ct['physical_geometry']+=1

def edge(U,vol,v,i,j,cap):
 J=[sum(u*m for u,m in zip(row,vol)) for row in U]
 aa=[row[i]*vol[i]*cap[i] for row in U]
 bb=[row[j]*vol[j]*cap[j] for row in U]
 tt=[row[j]*vol[j] for row in U]
 f=[a/q if q else F(0) for a,q in zip(aa,J)]
 g=[b/q if q else F(0) for b,q in zip(bb,J)]
 E=sum(w*a*b/q for w,a,b,q in zip(v,aa,bb,J) if q)
 N=sum(w*a*t/q for w,a,t,q in zip(v,aa,tt,J) if q)
 P=D=cov=F(0)
 for k,m in enumerate(vol):
  weights=[v[y]*U[y][k] for y in range(2)];rho=sum(weights)
  if not rho:continue
  ff=sum(w*x for w,x in zip(weights,f));gg=sum(w*x for w,x in zip(weights,g))
  P+=m*ff*gg/rho
  signed=m*weights[0]*weights[1]/rho*(f[0]-f[1])*(g[0]-g[1])
  cov+=signed;D+=abs(signed)
 assert E==P+cov;ct['covariance_identity']+=1
 credit=max(F(0),P-D)
 assert 0<=credit<=E<=N;ct['edge_credit']+=1
 return N,E,P,D,credit
U=[[F(1,2)]*4,[F(1,2),F(1,2),F(0),F(1,2)]]
vol=[F(1,50)]*4;J=[sum(row)*vol[0] for row in U]
A=[sum(u*c for u,c in zip(row,cap))*vol[0] for row in U]
H=F(1,40);d=F(3,200)
v=[(min(d,a)-d*a/H)/(a*(1-a/j)) for a,j in zip(A,J)]
assert edge(U,vol,v,1,2,cap)==(F(3,4000),F(3,4000),F(7,8000),F(1,8000),F(3,4000))
assert edge(U,vol,v,2,1,cap)==(F(3,4000),F(3,4000),F(7,8000),F(1,8000),F(3,4000))
ct['local_fixture']+=2
base=credit=loss=F(0)
for i,j in product((1,2),range(4)):
 if i==j:continue
 N,E,P,D,C=edge(U,vol,v,i,j,cap)
 base+=N;credit+=C;loss+=N-E
self_far=sum(v[y]*U[y][i]**2/J[y]*(vol[i]-h)**2 for y,i in product(range(2),(1,2)))
base+=self_far
assert (base,credit,base-credit,loss)==(F(3,320),F(3,2000),F(63,8000),F(7,1000))
layer=1/R-1/(F(2)-2*h)
assert (layer*base,layer*(base-credit),layer*loss)==(F(1,2112),F(7,17600),F(7,19800))
ct['local_fixture']+=2
for cols in (3,5,8):
 for seed in range(8):
  V=[[F((seed+3*y+2*x)%7,14) for x in range(cols)] for y in range(2)]
  vv=[F(2,5),F(3,5)];mm=[F(x+1,cols) for x in range(cols)]
  cc=[(seed+x)%2 for x in range(cols)]
  for i,j in product(range(cols),repeat=2):edge(V,mm,vv,i,j,cc)
print('PASS',ct)
