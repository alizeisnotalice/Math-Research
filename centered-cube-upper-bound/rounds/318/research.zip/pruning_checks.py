#!/usr/bin/env python3
"""Optional source-adaptive integer-cell pruning: bounded exact array tests."""
from fractions import Fraction as F
from itertools import product
from pathlib import Path
from collections import Counter
import json
counts=Counter()
def ck(key,b):
 counts[key]+=1
 assert b,key

def cells(B):return tuple(product(*(range(lo,hi) for lo,hi in B)))
def children(B):
 axes=[]
 for lo,hi in B:
  if hi-lo==1:axes.append([(lo,hi)])
  else:
   mid=lo+(hi-lo)//2;axes.append([(lo,mid),(mid,hi)])
 return list(product(*axes))
def build(n,k,pattern):
 root=((0,k),)*n;indices=cells(root)
 def f(i):
  if pattern=='zero':return F(0)
  if pattern=='uniform':return F(1)
  if pattern=='one_cell':return F(int(all(x==0 for x in i)))
  if pattern=='strip':return F(int(i[0]==0))
  return F(1+sum((j+1)*v for j,v in enumerate(i)),1+n*k)
 full={i:f(i) for i in indices};res={i:full[i]/2 if sum(i)%2==0 else F(0) for i in indices}
 mass=lambda B:sum((full[i] for i in cells(B)),F(0))
 leaves=[];visited=0
 def walk(B,depth):
  nonlocal visited
  visited+=1;ids=cells(B);parent=mass(B)
  if len(ids)==1:
   leaves.append((B,depth,'single'));return
  ch=children(B);childsets=[set(cells(c)) for c in ch]
  ck('children_exact_partition',set.union(*childsets)==set(ids) and sum(map(len,childsets))==len(ids))
  ck('child_mass_conservation',sum((mass(c) for c in ch),F(0))==parent)
  balanced=all(2*mass(c)<=parent for c in ch)
  if balanced:leaves.append((B,depth,'balanced'))
  else:
   # Every child is retained, including zero-source children.
   for child in ch:walk(child,depth+1)
 walk(root,0)
 leafsets=[set(cells(B)) for B,_,_ in leaves]
 ck('leaves_complete_cover',set.union(*leafsets)==set(indices))
 ck('leaves_disjoint',sum(map(len,leafsets))==len(indices))
 ck('full_mass_once',sum((mass(B) for B,_,_ in leaves),F(0))==sum(full.values()))
 ck('residual_mass_once',sum((sum((res[i] for i in cells(B)),F(0)) for B,_,_ in leaves),F(0))==sum(res.values()))
 ck('residual_domination',all(0<=res[i]<=full[i] for i in indices))
 depth_bound=(k-1).bit_length()
 ck('depth_bound',max(d for _,d,_ in leaves)<=depth_bound)
 for B,d,why in leaves:
  ck('leaf_linf_diameter',max(hi-lo for lo,hi in B)<=k)
  if why!='single':ck('nonsingle_child_balance',all(2*mass(c)<=mass(B) for c in children(B)))
  else:ck('single_cell_stop',len(cells(B))==1)
 return dict(n=n,k=k,source_pattern=pattern,fine_cells=k**n,full_mass=str(sum(full.values())),residual_mass=str(sum(res.values())),visited_nodes=visited,leaf_count=len(leaves),max_depth=max(d for _,d,_ in leaves),depth_bound=depth_bound,zero_full_mass_leaves=sum(mass(B)==0 for B,_,_ in leaves),leaves=[dict(box=B,depth=d,stop=why,full_mass=str(mass(B)),residual_mass=str(sum((res[i] for i in cells(B)),F(0)))) for B,d,why in leaves])
def main():
 rows=[];stages=[]
 for name,n,ks in [('initial',1,[1,2]),('boundary',2,[3,4]),('expanded',3,[5,8])]:
  before=sum(counts.values())
  for k in ks:
   for pattern in ['zero','uniform','one_cell','strip','skew']:rows.append(build(n,k,pattern))
  stages.append(dict(stage=name,n=n,k=ks,models=10,checks=sum(counts.values())-before))
 result=dict(status='PASS',arithmetic='Fraction',scope='Bounded integer fine-cell array algorithm only; one_cell denotes mass on a positive-volume fine cell, not an atomic L1 source. No high-dimensional root/source-budget theorem certified.',algorithm='Split each nonunit axis into floor/ceil halves. Freeze parent iff every child mass <=half parent mass; otherwise recurse into ALL children. Single cells stop. Zero parent therefore freezes.',check_counts=dict(counts),total_checks=sum(counts.values()),stages=stages,models=rows)
 Path(__file__).with_suffix('.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
 print(json.dumps({k:result[k] for k in ['status','check_counts','total_checks','stages']},sort_keys=True))
if __name__=='__main__':main()
