# R318 — source-cell averaging: exact boundary packets and the scale cost

## 1. Contract and bounded conclusion

Use the COMPLETE-f native remainder in `/tmp/r317_entry.md`: fixed fine source cells F_i of side d0=a/n, masses m_i=f(F_i), s_i^n=m_i sqrt(n)/(e^2 lambda), frozen residual nu=(f-sqrt(n)lambda)_+ dz, and actual positive traffic

    dT=A(x,z)h_(R(x))(x-z)dx nu(dz),  0<=A<=1/2.

All native owner/component/capture/history masks remain in A. Deep birth means R>s_i exp(L/n), with L=sqrt(n) in that entrance. These complete-f s_i are not the historical mu_hi birth radii t_i. On the original receiver event, R is a full-f hard winner and G0=sup_[a,b]h_r*f<=4lambda.

The verified result is an exact source-conserving boundary-packet comparison and positive inflated-radius comparison. Smoothing creates no free input density bound. The full selectable-radius boundary envelope below still has scale cost of order A_n=1+n log(b/a); it does not tend to zero with the smoothing width. No general root payment of deep birth follows.

## 2. Exact cell identity and positive transport

First take ANY fixed half-open grid of side delta>0 and full cell packets f_i=f|F_i, m_i=f(F_i). Set f_bar=sum_i(m_i/delta^n)1_(F_i). This is a mass-preserving positive L1 averaging operator. For any actual cube Q=Q_R(x), write theta_i=|F_i intersect Q|/delta^n. Then EXACTLY

    f_bar(Q)-f(Q)=sum_i integral_(F_i)[theta_i-1_Q(z)]f(dz),
    |f_bar(Q)-f(Q)|<=B_delta^f(x,R),
    B_delta^f(x,R)=sum_(0<theta_i<1)m_i.              (1)

Whole inside/outside cells contribute zero. This bound uses their actual source masses, not boundary volume times an assumed density. Partial cells lie in

    Q_(R+2delta)(x)\Q_(R-2delta)_+(x),

where the inner cube is empty for R<=2delta. Endpoint contacts of cells/cubes cause no L1 mass ambiguity. The bounds remain valid at a,b.

The common coupling f_i(dz) times uniform(dz'|F_i) preserves each original packet and has |z-z'|_infinity<=delta. Thus, for all R>0,

    f_bar(Q_R(x))<=f(Q_(R+2delta)(x)),
    f(Q_R(x))<=f_bar(Q_(R+2delta)(x)).               (2)

Equivalently h_R(x-z)<=(1+2delta/R)^n h_(R+2delta)(x-z') on that coupling when z was captured. This is a positive all-selector comparison, not substitution of a fixed convolution for a selected receiver integral. Every use of R+2delta inside [a,b] requires R<=b-2delta. The excluded top traffic has the ordinary one-source envelope fee at most

    (1/2)[1+n log(b/max(a,b-2delta))]W_nu
       <=(1/2)(1+2n delta/a)W_nu.                  (3)

For delta=eta*a/n, the transport factor is <=e^(2eta) and the top coefficient is <=(1+2eta)/2, including narrow bands and a=b. These are known inflation/envelope tools applied to immutable cell packets, not an independently new root mechanism.

At an actual winner R<=b-2delta, (2) gives

    h_(R+2delta)*f_bar(x)>=(1+2delta/R)^(-n)G0(x).

Also sup_(a<=r<=b-2delta)h_r*f_bar(x)<=(1+2delta/a)^n G0(x), when that range is nonempty. The scale ranges differ; these facts do NOT say R or R+2delta is a winner for f_bar on the old full band. The inward boundary mass has no small upper bound from winner maximality: its smaller-cube ceiling has the wrong direction for that inference.

## 3. Frozen masks and a real boundary-source branch

For the original fine cells, transport the LOCATION z to z' uniformly inside its own F_i, but keep original z and ALL its masks as an ancestral mark. Integrate A(x,z) against nu|F_i(dz) times uniform(dz'|F_i). Then the difference between the original traffic and this marked averaged traffic is at most

    (1/2) integral_E R(x)^(-n)B_delta^nu(x,R(x))dx.   (4)

It is zero on cells wholly inside/outside the cube. Here delta=d0, or an aligned refinement delta<=d0 that keeps the original fine-cell label. Recomputing A(x,z') instead would incur a separate mask-oscillation term and is not authorized. Averaging nu also does not identify it with (f_bar-sqrt(n)lambda)_+.

There is an executable actual subbranch: retain deep birth and take source packets whose cells are partial at the actual cube. On receivers satisfying

    B_delta^nu(x,R(x))<=2epsilon lambda R(x)^n,     (5)

that actual boundary-packet traffic is <=epsilon X, X=lambda|E|. The same fee bounds its smoothing comparison error. The complement of (5), the deep traffic from whole captured cells, and the marked smoothed traffic are NOT paid by this statement. An epsilon-X absorption requires the separately established same finite-X entry. Condition (5) is a true source-mass test, not a consequence of hard caps or deep birth. One may keep its exact integral (4) instead of imposing the test.

## 4. Entire radial-envelope cost and the deep-cell limitation

For u=2|x-z|_infinity, a positive upper envelope for the boundary-packet kernel is

    sup_(a<=R<=b)R^(-n)1{|u-R|<=2delta}.

Its EXACT Lebesgue integral, for delta>0, is

    E_n(delta)=((a+2delta)^n-(a-2delta)_+^n)/a^n
          +n integral_a^b (1+2delta/R)^(n-1)dR/R.    (6)

Indeed the maximizing radius is a on u between (a-2delta)_+ and a+2delta, and u-2delta on the remaining interval through b+2delta. Positive Tonelli therefore pays (4) by at most E_n(delta)W_nu/2, one source fee over the entire family. It is only a majorant; it is not claimed to be the actual error.

For delta=eta*a/n,

    E_n(delta)<=e^(2eta)[1+n log(b/a)],
    E_n(delta)>=n log(b/a),
    lim_(delta downarrow 0)E_n(delta)=n log(b/a).    (7)

The second/limit assertions concern this selectable-radius envelope. They do not assert a nonzero smoothing error for a fixed f. In fact the independent L1 estimate is

    integral sup_[a,b]|h_R*(f_bar-f)| dx
                                      <=A_n ||f_bar-f||_1,

and ||f_bar-f||_1 tends to zero along refining grids for each fixed L1 f. There is no quantitative rate in delta uniform over arbitrary f supplied by the current contract.

For delta=d0, the ACTUAL averaged density on an active deep cell is

    m_i/d0^n=(e^2 lambda/sqrt(n))(s_i/d0)^n
       <(e^2 lambda/sqrt(n))(R/d0)^n exp(-L).        (8)

At d0=a/n and L=sqrt(n), the factor (nR/a)^n exp(-sqrt(n)) is not a root bound. Finer averaging only worsens this mass-based density estimate. Coarser averaging needs the true sum of all fine-cell packets it mixes; it cannot use one m_i without its cell-count/local-mass cost. Thus (8) is not a density ceiling for the original f and does not settle whole-cell deep traffic. The precise remaining information is an actual boundary-source integral such as (4) and an independent price for the retained whole-cell/marked traffic, or a justified quantitative L1 approximation modulus. None is proved from deep birth alone here.

## 5. Executed bounded checks

The exact Fraction code below returned `PASS {'mass_conservation': 9, 'boundary_error': 189, 'inflate_original': 189, 'inflate_average': 189}`. It tests positive-volume L1 interval sources, grid phases and boundary/endpoints. The n-dimensional statements and family cost are proved above; no finite test certifies a source-root deep-birth price.

```python
from fractions import Fraction as F
from itertools import product
from math import floor
src=[(F(-1,3),F(2,5),F(2)),(F(3,4),F(5,4),F(3,2))]
def length(I,J):return max(F(0),min(I[1],J[1])-max(I[0],J[0]))
def mass(Q):return sum(w*length(Q,(l,r)) for l,r,w in src)
ct={'mass_conservation':0,'boundary_error':0,'inflate_original':0,'inflate_average':0}
for delta,phase in product((F(1,2),F(1,5),F(1,20)),(F(0),F(1,3),F(2,3))):
 offset=phase*delta
 lo=floor((min(l for l,r,w in src)-offset)/delta)
 hi=floor((max(r for l,r,w in src)-offset)/delta)
 cells=[((offset+i*delta,offset+(i+1)*delta),mass((offset+i*delta,offset+(i+1)*delta))) for i in range(lo,hi+1)]
 assert sum(m for C,m in cells)==sum(w*(r-l) for l,r,w in src);ct['mass_conservation']+=1
 def avg(Q):return sum(m*length(Q,C)/delta for C,m in cells)
 for x,R in product((F(-1),F(-1,2),F(0),F(1,4),F(1,2),F(1),F(3,2)),(F(1),F(5,4),F(2))):
  Q=(x-R/2,x+R/2);E=(x-R/2-delta,x+R/2+delta)
  B=sum(m for C,m in cells if 0<length(Q,C)<delta)
  assert abs(avg(Q)-mass(Q))<=B;ct['boundary_error']+=1
  assert avg(Q)<=mass(E);ct['inflate_original']+=1
  assert mass(Q)<=avg(E);ct['inflate_average']+=1
print('PASS',ct)
```

Only `/tmp/r318_smoothing.md` is authored here. Other authors' files and Git are unchanged.
