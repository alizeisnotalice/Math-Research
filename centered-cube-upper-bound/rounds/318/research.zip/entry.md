# R318 — compact source packets pay a genuinely larger native branch

**Proved main result:** apply a source-frozen compact-packet split DIRECTLY to the COMPLETE full-f native remainder from R316. This pays all traffic whose entire packet has mass at least `lambda R^n exp(-sqrt(n))/sqrt(n)`, with an explicit root-order source budget. Its remaining positive traffic has that aggregate packet mass strictly smaller. For packets made from whole original fine cells, the new remainder is a subtraffic of R317's old fine-cell-deep remainder. The R317 fine-cell fee is NOT added again.

A countable mass-adaptive partition with finite recursion in each coarse root is constructed below. A tensor-blob input verifies that the new paid branch contains positive actual native traffic that was individually fine-cell-deep. Thus the gain is a real merged-mass qualification, rather than a change of notation. No root estimate of the remaining aggregate-deep traffic, historical FULL qualification, or all-scale conclusion is asserted. Only `/tmp/r318_entry.md` was written.

## 1. Exact starting traffic and source fields

Use the COMPLETE full-source entrance of `/tmp/r316_entry.md`, sections2–4, also restated as the main version of `/tmp/r317_entry.md`:

`X_band <= (768/767)[P104(f,lambda)+H_native]`. (1)

Here `E_band={2lambda<M<=4lambda}`, `M=sup_[a,b]h_r*f`, `0<a<=b<=2a`, and R=R*(x) is the fresh actual maximizing hard selector. The complete input f is unchanged and `nu=(f-sqrt(n)lambda)_+ dz`, `W_res=||nu||` is frozen. The original native positive measure is

`dT=A(x,z)h_R(x-z)dx nu(dz)`, `||T||=H_native`,

`0<=A<=1_E lambda/M<=1/2`. (2)

All the actual R104 ownership, harmonic deficiency, finite K0, non-small captured mass and fixed unique heavy-component factors remain inside A. The source residual is not reconstructed after a split. The full-band input gives

`h_r*f(x)<=4lambda for ALL r in[a,b], x in E_band`. (3)

The relevant original archive is `/Users/zhengzhihao/Math-Research-centered-cube-work/centered-cube-upper-bound/rounds/104/research.zip`, member `proof.md`:99–117 (uniform positive input),135–150 (exact hard-window envelope),855–921 (native residual),923–927 (the already absorbed1/768). P104 is the ENTIRE explicit source price in R316(3), not a new symbol for unpriced branches.

## 2. Frozen compact-packet theorem, including the top strip

Let `{P}` be any countable source-frozen measurable partition. Each positive-mass packet has infinity-diameter at most `d_P<infinity`; the only geometric assertion used is that, if `z in P intersect Q_R(x)`, then

`P subset Q_(R+2d_P)(x)` up to source-null sets. (4)

Define the complete source mass and immutable residual packet

`m_P=integral_P f`, `nu_P=nu|P`, `K_P=(1+2d_P/a)^n`,

`N=n log(b/a)`, `T0(R)=lambda R^n exp(-sqrt(n))/sqrt(n)`. (5)

The mass in (5) is full f mass, not captured mass and not nu mass. Packets with m_P=0 carry no traffic. On the actual original measure (2) split exactly

`dT_paid,P=1_P(z)1_{m_P>=T0(R)}dT`,

`dT_deep,P=1_P(z)1_{m_P<T0(R)}dT`. (6)

Equality is in the paid branch. We prove the explicit packet receipt

`||T_paid,P|| <= c_P ||nu_P||`,

`c_P=(1/2){2+min[N,sqrt(n)+log(4sqrt(n))+log K_P]`

`                    +min[N,log K_P]}`. (7)

**Interior.** Keep the paid condition and restrict to `R<=b-2d_P`. The radius `R+2d_P` is in[a,b]. Capture, (3) and(4) imply

`m_P<=4lambda(R+2d_P)^n<=4lambda K_P R^n`.

The paid condition also implies `R^n<=m_P sqrt(n)exp(sqrt(n))/lambda`. Thus all actual radii of THIS packet on this interior subbranch lie in the fixed window

`[a,b] intersect [(m_P/(4lambda K_P))^(1/n),`

`                        (m_P sqrt(n)exp(sqrt(n))/lambda)^(1/n)]`. (8)

Its nth-logarithmic width is at most

`min[N,sqrt(n)+log(4sqrt(n))+log K_P]`.

For any fixed z and positive closed interval[u,v], the exact hard column mass is `integral sup_(u<=r<=v)h_r(x-z)dx=1+nlog(v/u)`. Use A<=1/2 only for the positive upper estimate, then integrate against nu_P. This proves the first window term in(7). Empty windows carry no traffic; nonempty singleton windows have mass1.

**Top.** The actual second subbranch is still `m_P>=T0(R)` AND `R>b-2d_P`. Its upper estimate may discard the paid condition, but the exact partition does not. The fixed containing radius interval is `[ell_P,b]`, where `ell_P=max(a,b-2d_P)`. Its log width satisfies

`nlog(b/ell_P)<=min[N,log K_P]`. (9)

If ell_P=a then `b/a<=1+2d_P/a`; otherwise `b/ell_P=1+2d_P/ell_P<=1+2d_P/a`. This proves(9), including b=a, n=1, a narrow band and the case b-2d_P<a, when the interior is empty. The second hard-window column price gives the other term of(7).

The two actual subbranches are disjoint (interior includes equality at b-2d_P), so their prices add. No receiver-volume union, overlap bound on receivers, or change of dx is involved.

Sum over the SOURCE partition. Positive Tonelli and `sum_P||nu_P||=W_res` give the exact, source-weighted connector

`H_native <= sum_P c_P||nu_P|| + H_packetdeep`,

`dT_packetdeep=sum_P1_P(z)1_{m_P<T0(R)}dT`. (10)

There is no packet-count multiplier. If useful, each c_P may be replaced by the smaller of(7) and the always-valid whole-window price `(1+N)/2` for that same paid subtraffic. Formula(7), rather than a supremum over packet diameters, is the principal receipt.

## 3. Explicit mass-adaptive construction with no hidden scale copies

Keep the ORIGINAL fine grid of R317, full cell side `a/n`. Let

`k=floor(sqrt(n))>=1`, `d_max=k a/n<=a/sqrt(n)`.

Group exactly k adjacent original fine cells in each coordinate into coarse root cubes of side d_max, with grid boundaries inherited from the fine grid. Every root merges exactly `k^n` fine cells, between `(sqrt(n)/2)^n` and `n^(n/2)`; for n=k^2 it merges exactly `n^(n/2)` cells.

Here is one concrete source-adaptive partition (other frozen partitions also obey(7)). For each root, compute its complete f mass. If it has only one original fine cell, stop. Otherwise bisect each nontrivial integer fine-cell index interval into its floor/ceiling halves. This gives at most2^n rectangular child blocks, each a UNION OF WHOLE original fine cells. If every child has mass at most half the parent mass, freeze the parent as a terminal packet. If some child has more than half the parent mass, split the parent and apply the same rule to ALL its children. Empty packets can be kept as zero terms or ignored.

The maximum index side halves at each split, so the recursion stops in at most `ceil(log2 k)` layers. Only the terminal packets are used in(6); ancestors are never billed. Terminal packets partition the source space, are frozen from f before receivers are selected, and have `d_P<=d_max`. Their size depends on the actual source-mass concentration. Odd k causes rectangular child blocks, which does not affect the infinity-diameter proof. The n=1,2,3 case has k=1 and simply stops at the original fine cells.

For these packets the remaining traffic in(10) satisfies BOTH

`m_P < lambda R^n exp(-sqrt(n))/sqrt(n)` (the new aggregate qualification),

`m_i<=m_P<lambda R^n exp(-sqrt(n))/sqrt(n)` for every original fine cell F_i containing the captured source z. (11)

Consequently it satisfies R317's old fine-cell-deep inequality `m_i<e^2 lambda R^n exp(-sqrt(n))/sqrt(n)`. It also retains ALL original native masks. This proves actual subtraffic inclusion, not an assertion that old masks survive a receiver/source replacement.

The nesting by WHOLE fine cells is essential for(11). The packet receipt(7) remains true for arbitrary measurable bounded packets, but arbitrary fragments do not imply `m_i<=m_P`.

Since `log K_P<=2nd_P/a<=2k<=2sqrt(n)`, a coarse optional bound on the new price is

`sum_P c_P||nu_P|| <= [1+sqrt(n)/2+2k+(1/2)log(4sqrt(n))]W_res`.

The sharper actual source-weighted sum in(10) is retained when packet sizes differ. A small-diameter packet therefore pays its own smaller log K_P, rather than the maximum diameter of its neighbors.

## 4. Overlap and adaptive-cover settlement

Our construction uses a partition, so there is no geometric covering multiplicity fee. A countable source-frozen cover can also use frozen weights `psi_P(z)>=0`, supported in its packets, with `sum_P psi_P(z)=1` source-a.e. Keep the full-support mass `m_P=integral_P f` and allocate only the actual traffic as `psi_P(z)dT`, with hard source `psi_P nu`. For each captured allocated pair, z is still in P, so the entire P lies in the enlarged cube and the SAME full-mass inequality `m_P<=4lambda K_P R^n` holds. Its paid condition `m_P>=T0(R)` supplies the other window endpoint. The column receipt therefore integrates against `psi_P nu`, and `sum_P||psi_P nu||=W_res` gives a source-once budget even though the full-support masses themselves may overlap. No bound on `sum_P m_P` is needed in this argument. As a second, more conservative choice one may instead use allocated packet mass `m_P^alloc=integral psi_P f`; the same proof works since that mass is also bounded by the enlarged full-f response. These two choices have different paid/deep predicates; allocation does not force recomputing the mass field.

Without traffic allocation, a cover of source multiplicity M has total billed hard-source mass at most M W_res, not W_res. Using S complete ancestor/scale covers independently likewise bills at most S times that budget (or their explicit mass sum), unless a common source partition of unity settles them. Selecting only the terminal disjoint packets above avoids that cost by an actual partition identity. For an overlapping packet that contains the entire old fine cell of its allocated captured source, the full-support-mass choice still implies `m_i<=m_P`, so its deep predicate gives(11). Arbitrary fragments or allocated-mass fields require separate verification of that inclusion; partition-of-unity algebra alone does not provide it. An uncovered part when `sum psi<1` remains an explicit positive residual.

## 5. New paid branch is nonempty on actual native traffic

The following is a diagnostic of the NEW receipt, not a counterexample or a weak-bound completion. It verifies the native gates, and shows that merged packet mass is strictly stronger than the previous fine-cell qualification.

Take an integer k>=2, n=k^2, a=lambda=1, b=2. At each center `c in{-2,0,2}^n`, put a constant-density blob of side1/k and total full-f mass3. Thus its density is `3k^n`; blobs are disjoint. Choose the coarse-root grid explicitly with phase `-1/(2k)` in each coordinate and full side1/k. Thus the blob centered at0 is exactly one coarse root, and every other blob center differs by an integer multiple of1/k. Take the original fine grid as its subdivision into k fine cells per axis (fine side1/n). Each blob therefore contains exactly `k^n` whole fine cells, including even k; no default zero-index grouping is used. This grid also subdivides the integer-centered side1 ownership cells: the boundary offset is `k(k-1)/2` fine steps. Choose K0 to contain the entire finite support (its source tail is zero).

For each blob center c, take receivers x in the centered box of full side `1-1/k`. For EVERY radius r in[1,2], Q_r(x) contains that entire blob and captures no other blob: in each coordinate, receiver half-width plus blob half-width equals1/2, whereas a different center is2 away, leaving a source distance at least3/2 in a differing coordinate, larger than r/2. Therefore

`h_r*f(x)=3/r^n`, `M(x)=3`, `R*=1`, `G_N=1/3`. (12)

The actual residual source mass of each blob is

`c_res=3-k^(1-n)>0`.

Each original fine cell has full mass `3/k^n`, and

`3/k^n < exp(2-k)/k`. (13)

So every captured pair in these receiver boxes is R317-fine-deep. For k=2, (13) follows from `3/16<1/2`; for k>=3, `k^(k^2-1)>3 exp(k-2)` follows, for example, by k>=3 and comparison with powers of3>e.

We now check the actual R104 gates, rather than declaring an abstract possible branch. Every nonzero side1 ownership cell is centered at c in the stated tensor grid and contains exactly its one blob. A side5 macro-package centered at such c contains at least `2^n` COMPLETE blobs. It captures at most the one local blob at x, so its capture fraction is at most `2^-n<1/(2k)=1/D104`. Hence EVERY contributing macro capture gate (v_i>0) is zero: Theta=0 and the exact residual G1 remains1/3. The harmonic quantity is at most2^-n<1/k. The captured residual mass is c_res, larger than the small-capture threshold beta104. The ownership-cell graph is connected (the center0 cell is within index-infinity-distance2 of every source cell). Its unique component has residual mass `3^n c_res>exp(k)`, satisfying the actual heavy threshold. Thus on these receiver boxes the native measure is exactly positive with the stated G1, cap source, capture and heavy gates. No historical FULL structure is used.

The coarse roots of section3 have d_max=1/k; each blob is one such root. Its child masses are spread uniformly, so the mass-adaptive rule freezes the entire blob as a terminal packet. It has full packet mass3 and merges `k^n` individually deep fine cells. Set

`K=(1+2/k)^n`, `t_P^n=3k/K`, `L_P=k+log K`.

Then

`t_P^n<=1`, `t_P^n exp(L_P)=3k exp(k)>1`. (14)

For the first inequality, `log K>=2k^2/(k+2)>=k` and `exp(k)>3k` for k>=2. Thus R*=1 is in the packet's near-birth window, while it is individually fine-cell-deep. Equivalently the NEW paid condition holds with strict slack:

`m_P/T0(1)=3k exp(k)>1`.

This is genuine aggregation: for k=2,4,8 the packet merges respectively16,4294967296, and `8^64` fine cells. The positive actual mass of this newly paid subtraffic over these disjoint receiver boxes is

`(1/3)(1-1/k)^n W_res >0`. (15)

This checks actual nonemptiness within H_native, including all its masks, rather than just comparing two arbitrary mass parameters.

## 6. Complete entrance and remaining unpaid traffic

The MAIN global-band receipt is (1)+(10):

`X_band <= (768/767){P104(f,lambda)`

`                          +sum_P c_P||nu_P||+H_packetdeep}.` (16)

There is no B_pre, soft deletion fee, or additional R317 source receipt in(16). It starts again at the complete R316 normalized input. Only the previously established R104 output loss1/768 is absorbed. The coefficient of the packet source sum and of its remaining traffic is exactly768/767; the half in c_P comes from the actual native gate bound, not a further absorption.

The remaining positive integral is exactly

`H_packetdeep=integral_E dx integral A(x,z) h_R(x-z)`

`            1_{m_(P(z))<lambda R^n exp(-sqrt(n))/sqrt(n)}nu(dz)`. (17)

It retains complete original dx, the frozen complete input f, the SAME nu, selector and native factors, and the actual mass-adaptive terminal partition. Formula(11) confirms it is a stronger remainder than R317's original fine-cell-deep slot. Its root-order payment is NOT proved here. Mass adaptivity alone gives no lower bound on the fraction of traffic in the paid branch for every input; claiming such a bound would be an additional geometric theorem. Nor does small full-f packet mass give a pointwise density cap or automatically reconstruct FULL/history.

The new usable progress is therefore a paid, nonempty merged-packet branch with a strictly stronger exact aggregate remainder. Any further cover/smoothing/forest argument must address(17), using the true aggregate masses and explicit additional costs. The independent smoothing author `/root/r286_joint_mass` confirmed this is complementary to that route: this proof supplies a legitimate aggregate-mass source budget and does not replace it by one fine-cell mass.

## 7. Executed checks and independent audit

Local Python/Fraction execution checked k=2,4,8: exact fine-deep sufficient inequalities using e<3, macro capture failure `2^n>2k`, heavy threshold via powers3>e, and packet near-birth `3k<=K`. The displayed positive mass fractions from(15) were approximately0.0208333,0.00334087,0.0000647730. Exact complete-f fine-cell masses were3/16,3/4^16 and3/8^64. Numerical evaluations only illustrate size; the analytic and exact rational inequalities above are the proof.

The numeric author independently froze `/tmp/r318_packet_checks.py` and `/tmp/r318_packet_checks.json` after630 integer/Fraction checks, reported fresh double execution PASS. Their hashes were read locally:

- Python: `ead9572aa3755fab39b20b0353e0a599dce81f9d15c575e9aa4c6a0658aa2a0c`.
- JSON: `20e5a2687665bf980cc5eb20968a7a4955a7ef3ea72de46f250bda689b78f794`.

Those files were not modified here. `/root/r285_final_audit` independently checked the main merged-packet receipt, especially threshold equality, the top subbranch, complete-f package masses, source-once terminal summation, and the whole-fine-cell nesting required for residual inclusion. Screen PASS was reported. No README closure claim is used.
