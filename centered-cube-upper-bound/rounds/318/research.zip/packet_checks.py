#!/usr/bin/env python3
"""R318 physical tensor-packet input: exact algebra and interval geometry."""
from fractions import Fraction as F
from pathlib import Path
from collections import Counter
import json
counts=Counter()
def ck(key,b):
 counts[key]+=1
 assert b,key

def contains(I,J):return I[0]<=J[0] and J[1]<=I[1]
def disjoint(I,J):return I[1]<=J[0] or J[1]<=I[0]
def run(k):
 n=k*k;a=F(1);b=F(2);side=F(1,k);half=side/2;recvhalf=(1-side)/2;origin=-half
 cells=k**n;blobs=3**n;density=3*cells;fine_mass=F(3,cells);res=F(3)-F(k,k**n)
 # All-r proof: actual receiver coordinate displacement is STRICTLY less
 # than recvhalf. Its distance to its blob is <=recvhalf+half=1/2,
 # and to any other-center blob along a separated axis >=3/2> b/2.
 ck('continuous_own_capture_distance',recvhalf+half==a/2)
 ck('continuous_other_exclusion_distance',2-recvhalf-half>b/2)
 ck('positive_receiver_box',recvhalf>0)
 for c in [-2,0,2]:
  blob=(F(c)-half,F(c)+half);owner=(F(c)-F(1,2),F(c)+F(1,2))
  ck('blob_inside_ownership',contains(owner,blob))
  ck('fine_grid_alignment',(F(c)-half-origin)*n==int((F(c)-half-origin)*n))
  ck('coarse_grid_alignment',(F(c)-half-origin)*k==int((F(c)-half-origin)*k))
  ck('fine_coordinate_count',side/F(1,n)==k)
  macro=(F(c)-F(5,2),F(c)+F(5,2));inside=[]
  for z in [-2,0,2]:
   target=(F(z)-half,F(z)+half)
   full=contains(macro,target)
   ck('macro_no_partial_blobs',full or disjoint(macro,target))
   if full:inside.append(z)
  ck('macro_coordinate_count',len(inside)>=2)
  # Explicit samples are diagnostics; the preceding distance inequalities
  # certify all x in the open receiver cube and all r in [1,2].
  for offset in [-recvhalf,F(0),recvhalf]:
   for r in [F(1),F(3,2),F(2)]:
    receiver=(F(c)+offset-r/2,F(c)+offset+r/2)
    ck('sample_own_capture',contains(receiver,blob))
    for z in [-2,0,2]:
     if z!=c:ck('sample_other_exclusion',disjoint(receiver,(F(z)-half,F(z)+half)))
 ck('fine_tensor_mass',cells*fine_mass==3)
 ck('coarse_full_mass',density*side**n==3)
 ck('residual_mass',res==(density-k)*side**n and 0<res<3)
 # Full-f hard response is M/r^n, M=3; transport gate G_N=1/M.
 for r in [F(1),F(3,2),F(2)]:ck('hard_winner_endpoint',F(3)/r**n<=3)
 ck('native_hardband',2<3<=4)
 ck('normalized_transport_gate',F(1,3)*3==1)
 ck('ownership_ratio_failure',F(1,2**n)<F(1,2*k))
 # For any macro, captured mass is either 0 or one full residual blob;
 # macro mass >=2^n residual blobs. Thus every two-proportion H_i fails,
 # independent of its contribution threshold, and Gamma=0.
 ck('all_macro_capture_ratio',res/(2**n*res)<F(1,2*k))
 # The side-1 positive ownership indices are {-2,0,2}^n; consecutive
 # coordinate indices have gap2<=3. Coordinate paths make graph connected.
 ck('graph_coordinate_edge',max([2,2])<=3)
 ck('finite_K0_tail_zero',blobs*F(3)==3*blobs)
 # e<3 gives e^k<3^k; strict lower bound proves a heavy component.
 ck('total_residual_heavy_integer_certificate',blobs*res>3**k)
 # e^(k-2)<=3^(k-2), inverted for the old strict deep threshold.
 old_cert=k**n>3*k*3**(k-2)
 ck('old_fine_deep_integer_certificate',old_cert)
 K=(1+F(2,k))**n;t_power=F(3*k)/K
 ck('new_coarse_not_deep',3>=F(1,k)) # 3>e^-k/k follows e^k>1.
 ck('coarse_birth_lower_gate',3*k<=K)
 ck('coarse_birth_not_failure',t_power<=1)
 # t^n exp(L)=3k exp(k)>1, using only exp(k)>1.
 ck('coarse_near_upper_gate',3*k>1)
 return dict(k=k,n=n,blob_count=blobs,blob_side=side,full_density=density,full_mass=3*blobs,receiver_halfwidth=recvhalf,total_receiver_volume=blobs*(1-side)**n,fine_cells_per_blob=cells,fine_cell_mass=fine_mass,coarse_packet_mass=F(3),residual_per_blob=res,total_residual=blobs*res,macro_min_blob_count=2**n,macro_max_blob_count=3**n,maximum_macro_capture_ratio=F(1,2**n),hard_response_at_winner=F(3),normalised_transport_gate=F(1,3),winner_radius=F(1),old_deep_integer_left=k**n,old_deep_integer_right=3*k*3**(k-2),coarse_K=K,coarse_t_n=t_power,coarse_near_upper_certificate='t^n exp(L)=3 k exp(k)>3 k>1',ownership_Gamma=0,scope='Actual positive-volume L1 input and receiver open boxes; full tensor interval geometry certified by coordinate inequalities. No FULL/history reconstruction claimed.')
def serial(x):
 if isinstance(x,F):return str(x)
 if isinstance(x,dict):return {k:serial(v) for k,v in x.items()}
 if isinstance(x,(list,tuple)):return [serial(v) for v in x]
 return x

def main():
 rows=[];stages=[]
 for name,ks in [('initial',[2,3]),('boundary',[4,8]),('expanded',[16])]:
  before=sum(counts.values());rows.extend(run(k) for k in ks)
  stages.append(dict(stage=name,k=ks,checks=sum(counts.values())-before))
 result=dict(status='PASS',arithmetic='Fraction/integer',check_counts=dict(counts),total_checks=sum(counts.values()),stages=stages,models=rows,analytic_bridges=['Coordinate extreme-distance inequalities prove all radii in [1,2], not merely sampled radii.','Tensor containment counts prove at least 2^n complete blobs per positive ownership macro.','Coordinate gap2 paths prove connectedness of finite tensor ownership graph.','Elementary e<3 and exp(k)>1 convert the displayed rational/integer certificates to exponential deep/near conditions.'],scope='Specified R104 transport/ownership and proposed packet branch diagnostic, not certification of omitted FULL/CP/GP/history masks or a general dimensional theorem.')
 Path(__file__).with_suffix('.json').write_text(json.dumps(serial(result),sort_keys=True,indent=2)+'\n')
 print(json.dumps({k:result[k] for k in ['status','check_counts','total_checks','stages']},sort_keys=True))
if __name__=='__main__':main()
