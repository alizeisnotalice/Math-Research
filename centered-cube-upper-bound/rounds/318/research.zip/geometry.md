# R318 — covariance-corrected overlap credits on the original collar-far mask

## 1. Exact local target and the new inequality

Keep the original R302/R315/R316 fields U_y(x), full J_y(r), A_yz(r), actual selected R(x), and the ORIGINAL minimum-tent weight

    v_y=v_H,d(A_yz(r),J_y(r)), 0<=v_y<=1,

which vanishes off {J>=H,0<A<H}, with H>=d>0. All original low-pe,m, full e_g, alpha, aspect, source and outer/clock qualifications remain. In particular neither J nor v is recomputed after any receiver grouping. Write E_r=E intersect {R<=r}, c_x(z)=1{z in Q_(R(x))(x)}, and use side lengths a<=R<=b. Fix the R315 eta,h for this original outer instance and set

    k_z(u)=1{R(u)>a/eta, z in Q_(R(u))(u)\Q_(eta R(u))(u)},
    delta(u,w)=||u-w||_infinity+|R(u)-R(w)|/2,
    t_h=max(a,b-2h).

For each z,r, r<t_h, the ACTUAL weighted local loss is

    L(z,r)=integral beta(dy) v_y/J_y(r)
       integral_(E_r x E_r) U_y(u)U_y(w)
                     k_z(u)(1-c_w(z))1{delta(u,w)>h}du dw. (1)

Zero-J rows contribute zero. If a/eta>=b, t_h=a, or H=d, the relevant local loss vanishes. The target collar-far fee is integral nu(dz)ell_n(dr)1{r<t_h}L(z,r). This is the original local double-endpoint mask, not a whole-tent surrogate.

Define its exact un-subtracted baseline by omitting only (1-c_w):

    N_far(z,r)=integral beta(dy) v_y/J_y(r)
       integral_(E_r x E_r) U_y(u)U_y(w)
                            k_z(u)1{delta>h}du dw.    (2)

The difference N_far-L is the actual far capture-overlap integral. Both are finite and 0<=L<=N_far<=integral v_y A_yz(r)beta(dy). The common-source first moment therefore bounds their integrated size by A_n W_nu, A_n=1+n log(b/a), without proving root order.

The NEW local result is a constructive lower certificate for portions of this actual overlap. For any disjoint family of certified far receiver rectangles, the nonnegative covariance-corrected credits C_e defined in section 2 satisfy

    L(z,r)<=N_far(z,r)-sum_e C_e(z,r).                (3)

The right side is nonnegative. There is no subtraction of the R317 whole-tent square. Every credit in (3) comes from a rectangle wholly contained in the original far mask and retains the original collar factor on its capturing endpoint. All constants in (3) are exactly 1; no dimension or scale fee is suppressed. It gives a directly local improvement, but the size of the credit can be zero. A universal source-root price is NOT proved by (3) alone.

## 2. A single certified rectangle and its exact covariance correction

Use a common measurable partition of the TAGGED actual receivers (x,R(x)), pulled back to E. The tag is needed because R(x) can be discontinuous. For a rectangle e=Omega_i x Omega_j assume

    delta(u,w)>h for every u in Omega_i, w in Omega_j. (4)

The prefix E_r is imposed on both endpoints below. Define, as functions of the original soft source y,

    a_i(y)=integral_(Omega_i intersect E_r)U_y(u)k_z(u)du,
    t_j(y)=integral_(Omega_j intersect E_r)U_y(w)dw,
    b_j(y)=integral_(Omega_j intersect E_r)U_y(w)c_w(z)dw.

All three are bounded by the same FULL J_y(r). The exact local rectangle baseline and overlap are

    N_e=integral beta(dy)v_y a_i(y)t_j(y)/J_y(r),
    E_e=integral beta(dy)v_y a_i(y)b_j(y)/J_y(r).      (5)

Thus its actual local loss is N_e-E_e, and 0<=E_e<=N_e. The collar, far relation and prefix have not been enlarged in this identity.

Put f_y=a_i(y)/J_y(r), g_y=b_j(y)/J_y(r) on positive-J rows and zero otherwise. These symbols are bounded test fractions, not the original full source f from the hard-cap contract. On the SAME full original prefix E_r define

    rho_v(x)=integral beta(dy)v_y U_y(x),
    F_e(x)=integral beta(dy)v_y U_y(x) f_y,
    G_e(x)=integral beta(dy)v_y U_y(x) g_y,
    S_f(x)=integral beta(dy)v_y U_y(x) f_y^2,
    S_g(x)=integral beta(dy)v_y U_y(x) g_y^2,
    V_f(x)=S_f(x)-F_e(x)^2/rho_v(x),
    V_g(x)=S_g(x)-G_e(x)^2/rho_v(x).                 (6)

All fields are zero off E_r. Set every ratio to zero at rho_v=0; positivity then makes its numerator zero. Since v<=1, original FIRST gives rho_v<=rho<=1. No new FIRST at a source or virtual center is invoked.

Define the edge prediction and defect, each finite for a single edge,

    Pi_e=integral_(E_r)F_e(x)G_e(x)/rho_v(x)dx,
    D_e=integral_(E_r)sqrt(V_f(x)V_g(x))dx,
    C_e=(Pi_e-D_e)_+.                               (7)

Then

    0<=C_e<=E_e.                                   (8)

Proof: conditional on an actual receiver with rho_v>0, the probability measure v_y U_y(x)beta(dy)/rho_v(x) gives

    Cov(f_y,g_y)>=-sqrt(Var(f_y)Var(g_y)).

Multiplying by rho_v and integrating yields

    integral_(E_r)dx integral beta(dy)v_y U_y(x)f_y g_y
          >=Pi_e-D_e.

Integrating U_y over the UNCHANGED full prefix gives J_y(r), so the left side is exactly E_e. The same covariance calculation shows V_f,V_g>=0. Finally E_e>=0 permits the positive part in (7). This proves (8).

The correction D_e is essential. Cross capture is bilinear; receiver projection need not underestimate a bilinear inner product. Its conditional covariance can be negative even though all kernels and weights are nonnegative. A whole-tent square lower bound cannot replace (7). The example below has Pi_e>E_e and its explicit D_e repairs that over-subtraction exactly.

A coarser computable correction is sqrt((integral V_f)(integral V_g)), by Cauchy-Schwarz. It is valid but at least as large as D_e, hence gives no larger credit. Formula (7) is the sharper common-receiver version.

## 3. Disjoint far rectangles, measurability, and source-once summation

Let {Omega_i x Omega_j}_e be a finite or countable family with pairwise disjoint actual ordered receiver-pair sets, each satisfying (4). The endpoints can occur in more than one rectangle, but no ordered PAIR is charged twice. Because all terms are positive,

    sum_e E_e <= actual far capture-overlap =N_far-L.

Together with (8) this proves (3). No bound of the form one W_nu or one W_beta per edge is used. This source conservation would be lost if one separately applied a full hard cap to every edge and then summed those prices.

For a countable family take the positive part PER EDGE as in (7), and only then sum. The series sum_e C_e is nonnegative and bounded by sum_e E_e<=N_far. In general sum_e Pi_e and sum_e D_e are not separately justified as finite; (3) must not be rewritten as their difference. This also ensures that the final subtraction in (3) is finite and nonnegative.

A fully explicit common family is available. Partition the ambient tag space R^n x [a,b] into nested half-open dyadic spatial cubes and radius intervals of mesh 2^(-m)a. Use the metric

    d_tag((x,R),(w,S))=||x-w||_infinity+|R-S|/2.

Each ambient cell has metric diameter at most 3a2^(-m)/2. A pair of ambient cells is certified if the infimum of d_tag over the two cells is strictly greater than h. Its pullback under x -> (x,R(x)) is measurable, even for discontinuous actual R. The infimum is explicitly the infinity-distance of the spatial boxes plus half the distance of the radius intervals.

At level m retain only certified cell pairs not already contained in a certified pair at a coarser level. These first-certified rectangles are disjoint as ordered pair sets. Their union is exactly the open far set {delta>h}: for a fixed far pair, the two containing cell diameters eventually become smaller than its positive gap delta-h. A pair with delta=h is never included and is not part of the original strict far mask. Pullback cells with empty actual receiver measure contribute zero. A finite enumeration gives an executable partial credit; its uncredited far baseline remains in (3). There is no claim that a finite enumeration already covers all far traffic.

The family may be fixed for the original eta,h and shared across every row y, source z and layer r. The actual z-dependence remains only in k_z,c_w,v and the integrals; no separate source copy or free actual scale selector is introduced. Finite partial credit sums increase monotonically, so their upper certificates decrease. This statement concerns one fixed first-certified family; changing a partition does not automatically compare individual credit values.

## 4. Original ledger and the precise unproved price

Define

    K_local=integral nu(dz)ell_n(dr)1{r<t_h}
                         [N_far(z,r)-sum_e C_e(z,r)]. (9)

It is nonnegative and finite, with actual weighted collar-far <=K_local<=A_n W_nu. This replaces only the collar-far remainder in the inherited R315/R316 continuation. For a<b and the R315 root-source choice eta^n=1/A_n, kappa_h=epsilon/4 and H=sqrt(d A_n/(4lambda))>=d, it gives

    T_target <=4sqrt(lambda d A_n)(W_beta+W_nu)
       +(32/3)Csoft_n W_beta
       +2[2+log A_n+log(1+epsilon/4)]W_nu
       +2epsilon X+2D_eff+2K_local.                 (10)

Here Csoft_n<=1+(pi/2)sqrt(n), X=lambda|E|, and D_eff is the actual winner defect. The separate R315 receiver version is likewise valid with its own eta,h and source coefficient. The original lambda d=(4/3)kappa0 psi_inf/v0, all aspect complements, and every original positive outer/clock multiplier remain. Neither an unverified winner identity nor native future-softness FIRST is imported.

The missing quantitative statement is now directly localized:

    K_local <=epsilon' X+C_(epsilon')sqrt(A_n)log^p(n+2)
                                   (W_beta+W_nu),   (11)

with all lambda d/H/aspect dependence explicit if it enters. We have not proved (11). The new inequality (3) makes a corrected quadratic overlap credit legal under the original two-endpoint mask; it does not guarantee that this credit removes most of N_far. The covariance errors D_e can prevent such removal, and a fine spatial grid alone does not control them. They measure variation of original row capture fractions at shared actual receivers, including all original alpha/history effects.

Thus the exact further task is to bound the baseline left after the summed corrected credits using actual full-soft row geometry and original hard-source caps. Dropping D_e, replacing J by local packet mass, or summing a full source price per rectangle would not solve that task. No assumption such as nu<=beta, source density control, or posterior agreement has been inserted.

## 5. Exact physical fixture: a valid localized credit and a necessary defect

Use the broad prescribed-kernel fixture from R317: n=1, a=1, b=L=2, R=9/5, s=0, q=1, lambda=4/3. The two beta sources each have mass 1 on intervals of length 1/1000 centered at +/-1/200. Nu has mass 1 on [-1/1000,1/1000]. The full source beta+nu has mass 3, hence all legal hard averages are <=3<4lambda. The four actual receiver cells have length 1/50 and centers -19/20,-7/10,7/10,19/20. All relevant soft kernel values are P_(0,2)=1/2. The first beta row uses alpha=1 on all cells; the second uses alpha=1 except on the third cell. The prescribed beta row-upper-cap holds. Full-f canonical soft FIRST, a positive native softness margin, and the original low-pe,m/history qualifications are NOT certified for this fixture.

Choose H=1/40,d=3/200,eta=3/5,h=1/100. The row J,A,v values are exactly those in R317. Both inner receiver cells capture in the collar; both outer cells miss. All different-cell pairs are certified far. On each low layer [9/5,99/50), consider the ordered edge from the left inner cell to the right inner cell. Exact calculation gives

    N_e=E_e=3/4000,
    Pi_e=7/8000,
    D_e=1/8000,
    C_e=3/4000.                                    (12)

Thus subtracting Pi_e without its defect would exceed the true overlap. The corrected credit exactly cancels this rectangle's baseline, as it must because the destination cell also captures. The reverse ordered edge has the same values. Edges to the outer cells have zero overlap and zero credit, so their genuine missed-source traffic is retained.

For the full far baseline one must also account for far pairs within a single inner receiver interval. For an interval of length ell=1/50 and h=1/100, the ordered pair area satisfying |u-w|>h is (ell-h)^2=1/10000. These within-cell far pairs have zero true loss because both endpoints capture, but they are NOT included in the selected different-cell certified family. Their baseline is therefore conservatively retained.

At each low layer the exact values are

    N_far=3/320,
    selected total corrected credit=3/2000,
    N_far-sum C_e=63/8000,
    actual collar-far loss=7/1000.                  (13)

The layer mass is 5/99. Hence the new localized certificate is 7/17600, strictly below the un-subtracted local baseline 1/2112 and above the exact local loss 7/19800. This is a strict improvement of an upper certificate on the original local mask, with no use of the whole-tent energy as a subtraction. The saving removes verified capture-overlap from the baseline; it is not claimed to pay an additional positive missed-source component by itself. It is a prescribed-kernel finite geometric diagnostic, not a root theorem or historical-input qualification.

## 6. Reproducible exact checks

The code below uses the actual positive-volume interval fixture for (12),(13), verifies both endpoints and all geometry, and checks covariance-corrected bilinear credits in additional finite two-row matrices. For two rows the conditional covariance magnitude is exactly a rational weight times the product of the two row-fraction differences, so all checks use Fraction arithmetic with no floating square root. A fresh isolated Python process passed 24 physical-geometry checks, 792 edge-credit checks, 792 covariance-identity checks and 4 exact local-fixture comparisons. These counters count the displayed check groups. The additional matrices are algebra diagnostics, not claimed physical historical inputs.

```python
from fractions import Fraction as F
from itertools import product
ct={'physical_geometry':0,'edge_credit':0,'covariance_identity':0,'local_fixture':0}
centers=[-F(19,20),-F(7,10),F(7,10),F(19,20)]
cells=[(x-F(1,100),x+F(1,100)) for x in centers]
yboxes=[(-F(1,200)-F(1,2000),-F(1,200)+F(1,2000)),
        (F(1,200)-F(1,2000),F(1,200)+F(1,2000))]
zbox=(-F(1,1000),F(1,1000));R=F(9,5);eta=F(3,5);h=F(1,100)
for cell,ybox in product(cells,yboxes):
 assert max(abs(x-y) for x,y in product(cell,ybox))<1;ct['physical_geometry']+=1
for i,j in product(range(4),repeat=2):
 if i!=j:
  assert min(abs(x-w) for x,w in product(cells[i],cells[j]))>h
  ct['physical_geometry']+=1
cap=[0,1,1,0]
for cell,c in zip(cells,cap):
 dd=[abs(x-z) for x,z in product(cell,zbox)]
 if c:assert max(dd)<R/2 and min(dd)>eta*R/2
 else:assert min(dd)>R/2
 ct['physical_geometry']+=1

def edge(U,vol,v,i,j,cap):
 J=[sum(u*m for u,m in zip(row,vol)) for row in U]
 aa=[row[i]*vol[i]*cap[i] for row in U]
 bb=[row[j]*vol[j]*cap[j] for row in U]
 tt=[row[j]*vol[j] for row in U]
 f=[a/q if q else F(0) for a,q in zip(aa,J)]
 g=[b/q if q else F(0) for b,q in zip(bb,J)]
 E=sum(w*a*b/q for w,a,b,q in zip(v,aa,bb,J) if q)
 N=sum(w*a*t/q for w,a,t,q in zip(v,aa,tt,J) if q)
 P=D=cov=F(0)
 for k,m in enumerate(vol):
  weights=[v[y]*U[y][k] for y in range(2)];rho=sum(weights)
  if not rho:continue
  ff=sum(w*x for w,x in zip(weights,f));gg=sum(w*x for w,x in zip(weights,g))
  P+=m*ff*gg/rho
  signed=m*weights[0]*weights[1]/rho*(f[0]-f[1])*(g[0]-g[1])
  cov+=signed;D+=abs(signed)
 assert E==P+cov;ct['covariance_identity']+=1
 credit=max(F(0),P-D)
 assert 0<=credit<=E<=N;ct['edge_credit']+=1
 return N,E,P,D,credit
U=[[F(1,2)]*4,[F(1,2),F(1,2),F(0),F(1,2)]]
vol=[F(1,50)]*4;J=[sum(row)*vol[0] for row in U]
A=[sum(u*c for u,c in zip(row,cap))*vol[0] for row in U]
H=F(1,40);d=F(3,200)
v=[(min(d,a)-d*a/H)/(a*(1-a/j)) for a,j in zip(A,J)]
assert edge(U,vol,v,1,2,cap)==(F(3,4000),F(3,4000),F(7,8000),F(1,8000),F(3,4000))
assert edge(U,vol,v,2,1,cap)==(F(3,4000),F(3,4000),F(7,8000),F(1,8000),F(3,4000))
ct['local_fixture']+=2
base=credit=loss=F(0)
for i,j in product((1,2),range(4)):
 if i==j:continue
 N,E,P,D,C=edge(U,vol,v,i,j,cap)
 base+=N;credit+=C;loss+=N-E
self_far=sum(v[y]*U[y][i]**2/J[y]*(vol[i]-h)**2 for y,i in product(range(2),(1,2)))
base+=self_far
assert (base,credit,base-credit,loss)==(F(3,320),F(3,2000),F(63,8000),F(7,1000))
layer=1/R-1/(F(2)-2*h)
assert (layer*base,layer*(base-credit),layer*loss)==(F(1,2112),F(7,17600),F(7,19800))
ct['local_fixture']+=2
for cols in (3,5,8):
 for seed in range(8):
  V=[[F((seed+3*y+2*x)%7,14) for x in range(cols)] for y in range(2)]
  vv=[F(2,5),F(3,5)];mm=[F(x+1,cols) for x in range(cols)]
  cc=[(seed+x)%2 for x in range(cols)]
  for i,j in product(range(cols),repeat=2):edge(V,mm,vv,i,j,cc)
print('PASS',ct)
```

Only /tmp/r318_geometry.md is written. Other author files and Git are unchanged. The result stops at the localized inequality (3) with its explicit covariance correction and the unproved integrated root-price step (11).
