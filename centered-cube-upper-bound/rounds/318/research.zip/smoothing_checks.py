from fractions import Fraction as F
from itertools import product
from math import floor
src=[(F(-1,3),F(2,5),F(2)),(F(3,4),F(5,4),F(3,2))]
def length(I,J):return max(F(0),min(I[1],J[1])-max(I[0],J[0]))
def mass(Q):return sum(w*length(Q,(l,r)) for l,r,w in src)
ct={'mass_conservation':0,'boundary_error':0,'inflate_original':0,'inflate_average':0}
for delta,phase in product((F(1,2),F(1,5),F(1,20)),(F(0),F(1,3),F(2,3))):
 offset=phase*delta
 lo=floor((min(l for l,r,w in src)-offset)/delta)
 hi=floor((max(r for l,r,w in src)-offset)/delta)
 cells=[((offset+i*delta,offset+(i+1)*delta),mass((offset+i*delta,offset+(i+1)*delta))) for i in range(lo,hi+1)]
 assert sum(m for C,m in cells)==sum(w*(r-l) for l,r,w in src);ct['mass_conservation']+=1
 def avg(Q):return sum(m*length(Q,C)/delta for C,m in cells)
 for x,R in product((F(-1),F(-1,2),F(0),F(1,4),F(1,2),F(1),F(3,2)),(F(1),F(5,4),F(2))):
  Q=(x-R/2,x+R/2);E=(x-R/2-delta,x+R/2+delta)
  B=sum(m for C,m in cells if 0<length(Q,C)<delta)
  assert abs(avg(Q)-mass(Q))<=B;ct['boundary_error']+=1
  assert avg(Q)<=mass(E);ct['inflate_original']+=1
  assert mass(Q)<=avg(E);ct['inflate_average']+=1
print('PASS',ct)
