from multiprocessing import get_context
from flint import arb,ctx
import flint,sys,json,platform
def run(b):
    ctx.prec=192
    n=2**b
    L=arb(n).log()
    p=L/n
    # Use log1p even when 1+p rounds to a ball containing 1.
    signed=n*(p*(1+arb(1)/(32*n))**2/2).log1p()-L/2
    half=-arb(n)/2*(-p).log1p()-L/2
    k=int((L/8).floor().unique_fmpz())
    term=arb(1)
    total=arb(1)
    for j in range(1,k+1):
        term*=((arb(n-j+1)/n)*L)/(j*(1-p))
        total+=term
    logpi=n*(-p).log1p()+total.log()
    assert signed < arb(1)/10 and half < 1 and logpi < -L/2
    return b
if __name__=='__main__':
    with get_context('fork').Pool(12) as pool:
        bits=pool.map(run,range(6,1001))
    print(json.dumps(dict(count=len(bits),first=min(bits),last=max(bits),precision=192,python=sys.version,flint=flint.__version__,host=platform.node())))
