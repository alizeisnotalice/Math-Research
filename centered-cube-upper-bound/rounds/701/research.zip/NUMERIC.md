# 第701轮双机验证

scan.py 按 n=2^b 检查 b=6 至 1000 的 995 个维度。每个维度测试 6 个缺陷参数、41 个尺度候选，程序对不适用的尺度显式跳过。结果为浮点对数，不是严格证书。命令分别为 python scan.py 6 1001 2 12 和 python3 - 7 1001 2 15 < scan.py。mini.json 与 laptop.json 保存每个维度的候选比较和实际解释器版本。MacBook 首次连接超时，重试成功；重叠重试输出未计入统计。

certify.py 在 Mac mini 上用 12 个进程、python-flint 0.9.0、Arb 192 位验证同一组维度的三个严格界：单侧正交方向的费用除以根号 n 后对数小于 1/10，半数指定轴的枚举费用除以根号 n 后对数小于 1，以及缺陷数不超过 floor(log(n)/8) 的概率小于 1/sqrt(n)。运行 /Users/zzh/.local/share/math-research-tools/venv/bin/python certify.py。保存输出 cert.json。

exact.py 枚举五维全部 7581 个布尔向下封闭族。按编码排序后，两机分别用 python exact.py 0 12 和 python3 - 1 15 < exact.py，奇偶分片同时发出。若 π 是该族的 Bernoulli 乘积概率，对于 p=k/256，1≤k≤255，m=2,3,4，整数交叉相乘检验 π(1−(1−p)^m)≤π(p)^m。独立样本取并说明一般形式成立：并集属于该族则各样本均属于该族。该检验用于检查乘积概率衰减的方向和等号情形，不认证报告中的连续微分估计。共 5,799,465 次，25,245 次取等。两个 exact 输出记录进程数、CPU 时间和墙钟时间。核数使用率随调度变化。所有计算进程在返回结果时已退出。
