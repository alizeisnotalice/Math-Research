import sys,json,os,math,socket,time
from multiprocessing import get_context
def ideals():
    fam=[0,1]
    for d in range(5):
        fam=[a|(b<<(1<<d)) for a in fam for b in fam if (a&b)==b]
    return fam
def profile(mask):
    c=[0]*6
    for x in range(32):
        if (mask>>x)&1:c[bin(x).count('1')]+=1
    return tuple(c)
def check(mask):
    cpu=time.process_time()
    c=profile(mask)
    eq=0
    for k in range(1,256):
        for m in (2,3,4):
            den=256**m
            keep=(256-k)**m
            left=sum(v*(den-keep)**i*keep**(5-i) for i,v in enumerate(c))
            right=sum(v*k**i*(256-k)**(5-i) for i,v in enumerate(c))**m
            assert left<=right
            eq+=left==right
    return eq,time.process_time()-cpu,os.getpid()
if __name__=='__main__':
    parity,w=map(int,sys.argv[1:])
    jobs=sorted(ideals())[parity::2];start=time.monotonic()
    with get_context('fork').Pool(w) as pool: out=pool.map(check,jobs,8)
    print(json.dumps(dict(host=socket.gethostname(),python=sys.version,workers=len({z[2] for z in out}),cases=len(out)*765,equalities=sum(z[0] for z in out),cpu=sum(z[1] for z in out),elapsed=time.monotonic()-start,parity=parity)))
