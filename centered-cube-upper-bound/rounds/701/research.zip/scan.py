"""Diagnostic Pareto search at true integer dimensions n=2**b.
Scale x = n*p; logs and recurrences avoid 1-p rounding to 1.
"""
import math, time, json, socket, sys, os
from multiprocessing import get_context

def values(n,k,x):
    ln=math.log(n);p=x/n;h=1+1/(32*n)
    f=1.;fwd=1.;prob=1.;poly=1.
    for m in range(1,k+1):
        falling=(1-(m-1)/n)/m
        f*=falling*h*h*x
        fwd+=f
        prob*=falling*x/(1-p)
        poly+=prob
    logtail=n*math.log1p(-p)+math.log(poly)
    # derivative upper for nested integral; require x>k.
    logcap=n*math.log1p(1/(32*n))+logtail+math.log1p(n/(x-k))-.5*ln
    return math.log(fwd)-.5*ln, logcap

def case(b):
    start=time.process_time()
    n=1<<b;ln=math.log(n)
    rows=[]
    # Pilot, threshold pressure, and higher-defect follow-up all on same data.
    for d in (.1,.125,.18,.19,.25,.375):
        k=max(1,int(d*ln))
        options=[]
        for z in range(65,146,2):
            x=z*ln/100
            if x>=n or x<=k:continue
            f,c=values(n,k,x)
            options.append((max(f,c+math.log(8)),z,f,c))
        obj,z,f,c=min(options)
        f1,c1=values(n,k,ln)
        rows.append([d,k,z,f,c,f1,c1])
    return dict(bits=b,rows=rows,cpu=time.process_time()-start,pid=os.getpid())
if __name__=='__main__':
    lo,hi,step,w=map(int,sys.argv[1:]);start=time.monotonic()
    with get_context('fork').Pool(w) as pool:rows=pool.map(case,range(lo,hi,step),1)
    print(json.dumps(dict(host=socket.gethostname(),python=sys.version,workers=w,elapsed=time.monotonic()-start,rows=rows)))
