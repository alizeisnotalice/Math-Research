# R469：有限多来源跨度、条件化成本与下一样本增量

本稿给出改变样本数选择的精确公式；没有证明原 \(P\) 的分散来源补集已获得根阶来源预算。旧来源、实际父、阶段及历史均冻结，新增抽样仅是原测度的概率扩充。cube 参数是边长。

## 1. \(k\) 来源父核及全部质量成本

固定 \(k\ge2\) 个 required 来源 \(Y\)、终端中心 \(u,v\)，记
\(d_i=\operatorname{span}_iY\)、\(d_\infty=\max_i d_i\)、
\(P_Y(t)=\prod_i(1-d_i/t)_+\)，以及
\[
 L=\max\{a,(K^2\max(m_u,m_v)/\lambda)^{1/n}\}.
\]
实际质量门空当 \(K^2\max(m_u,m_v)\ge\lambda b^n\)。其余
\[
 \frac{q_A}{m_A^k}=q_A^{1-k}R_A^{-kn},\qquad
 \int_{\rm actual} \frac{q_Ac_A(Y)}{m_A^k}
       1_{\{u,v\notin Q_A\}}\,dA
 \le q^{1-k}E_{kn}(Y,\{u,v\};L,b).                 \tag{1}
\]
令 \(\chi=1_{\{u,v\notin\operatorname{boxhull}(Y)\}}\)。
若 \(d_\infty>b\) 包络为零；否则 \(t_0=\max(L,d_\infty)\)，R468 的积分证明给
\[
\begin{split}
 E_{kn}
 &\le\chi\left[b^{-(k-1)n}P_Y(b)
       +kn\int_{t_0}^b t^{-(k-1)n-1}P_Y(t)\,dt\right]\\
 &\le\chi P_Y(b)\left[
       \frac{k}{k-1}t_0^{-(k-1)n}
       -\frac1{k-1}b^{-(k-1)n}\right].              \tag{2}
\end{split}
\]
\(P_Y(b)\le e^{-\sum_i d_i/b}\)。固定边长 \(L=b\) 的基项保留。
\(k=1\) 另用
\(E_n\le\chi[P_Y(b)+n\int_{t_0}^bP_Y(t)dt/t]\le1+n\log(b/L)\)，
不使用奇异的 \(k/(k-1)\)。

若旧记录只有 \(y,z\)，再独立附加 \(r=k-2\) 个背景样本
\[
 X_j\sim Q^{\rm bg}_{A,u,v}
  =\frac{1_{Q_A\setminus(Q_u\cup Q_v)}\,d\mu}{B_A},
 \qquad B_A=\mu(Q_A\setminus(Q_u\cup Q_v)),
\]
则扩充不改原 \(P\) 总量。严格 \(m_A>K^2\max(m_u,m_v)\) 给
\(B_A\ge d_*m_A\)，\(d_*=1-2/K^2>0\)，故密度上放成本准确为
\[
 \frac{q_A}{m_A^2B_A^r}
 \le d_*^{-r}\frac{q_A}{m_A^{r+2}}.                \tag{3}
\]
只有在确实取出 (3) 时才付该成本；它不等于免费获得 \(r\) 个独立历史来源。对 \(2/K^2\le1/2\)，
\[
 d_*^{-r}\le\exp(4r/K^2).
\]
所以 \(r\lesssim\sqrt n\) 的背景条件化成本小；真正困难是 (1) 之后额外 \(r\) 份真实 \(\mu\) 积分的共同结算，不能把它们各自替成 \(W\)。

## 2. 不需坐标独立的精确跨度与增量

固定一个原记录，令 \(F_i\) 为 \(Q^{\rm bg}_{A,u,v}\) 的第 \(i\) 坐标 CDF。
该边缘由 \(L^1\) 来源产生，故无坐标原子；以下积分恒等式也适用于有原子的概率律。
写 \(Q_A=\prod_i[\ell_i,r_i]\)，以及原两来源的
\(a_i=\min(y_i,z_i)\)、\(b_i=\max(y_i,z_i)\)。
附加 \(r\ge1\) 个样本后，第 \(i\) 坐标总跨度 \(D_{r,i}\) 满足
\[
 \mathbb E D_{r,i}=b_i-a_i
 +\int_{b_i}^{r_i}(1-F_i(t)^r)\,dt
 +\int_{\ell_i}^{a_i}(1-(1-F_i(t))^r)\,dt.          \tag{4}
\]
因此下一样本的真实非负增量为
\[
 \mathbb E(D_{r+1,i}-D_{r,i})
 =\int_{b_i}^{r_i}F_i^r(1-F_i)\,dt
  +\int_{\ell_i}^{a_i}(1-F_i)^rF_i\,dt.            \tag{5}
\]
两积分区间不交。令
\(c_r=r^r/(r+1)^{r+1}\le1/(r+1)\)，由
\(\max_{p\in[0,1]}p^r(1-p)=c_r\) 得
\[
\boxed{\quad
 \mathbb E\sum_i(D_{r+1,i}-D_{r,i})
 \le c_r\left(nR_A-\|y-z\|_1\right)
 \le \frac{nR_A}{r+1}.
 \quad}                                                        \tag{6}
\]
若没有固定的 \(y,z\)，而是 \(r\) 个全新 iid 来源，则
\[
 \mathbb E\operatorname{range}_{r,i}
 =\int_{\ell_i}^{r_i}[1-F_i^r-(1-F_i)^r]dt,
\]
相应增量上界是 \(2R_Ac_r\)。这些结论仅用“不同样本在固定原记录下独立”，不假设同一样本的坐标独立。

这使 \(r\simeq\sqrt n\) 成为**边际跨度增长**降到 \(O(\sqrt n)R_A\) 的可核样本尺度，但不是累计跨度下界或原费用上界。几何乘积还有逐样本的
\[
 0\le P_{Y_r}(t)-P_{Y_{r+1}}(t)
 \le t^{-1}\sum_i(D_{r+1,i}-D_{r,i}),              \tag{7}
\]
由各因子在 \([0,1]\) 及单坐标 Lipschitz 性证明。将 (6) 直接积分于原记录，仅得
\[
 \int \mathbb E[(\sum_i\Delta D_i)/R_A]\,dP
 \le \frac{n}{r+1}|P|,                            \tag{8}
\]
价格仍是原流质量，而不是 \(W\)。要形成原目标预算，缺的是把同一原记录加权的父中心面损失或跨度增量，结算到一次共享 \(f\)-质量的比较；(7) 本身没有改变来源边缘，不能完成这一转换。

## 3. 分位证书仅作条件性选样判据

若第 \(i\) 坐标 \(\epsilon,1-\epsilon\) 分位间距为 \(d_i(\epsilon)\)，则
\[
 \Pr\{\text{所有坐标新增样本跨度}\ge d_i(\epsilon)\}
 \ge1-2n(1-\epsilon)^r.
\]
因此条件平均指数因子不超过
\(e^{-\sum_i d_i(\epsilon)/b}+2n(1-\epsilon)^r\)。
对固定 \(\epsilon,r\)，该辅助失败事件在概率扩充中的质量至多
\(2n(1-\epsilon)^r|P|\le2Sn(1-\epsilon)^rX\)；
这不证明剩余事件的来源价格。稀有坐标尾可使所选分位宽度为零，而真实样本跨度非零，故不将该证书作为唯一机制，也不从 \(q\)-band 推出分位宽度下界。

## 4. 实际有限精确检查

已用指定本机 Python 及 Fraction 实际运行：三阶段 24、48、72 项，共 144 项断言通过。以下三组条件样本律（1维、完全相关2维、3维稀有轴方向）检查 (4)–(6) 和无固定来源的增量式。它们验证条件概率代数，不是实际匹配父场或原历史认证。一般证明不依赖有限检查。

~~~python
from fractions import Fraction as F
from collections import defaultdict
checks=0
models=[
 ([(F(0),),(F(1),)],[F(1,2),F(1,2)]),
 ([(F(0),F(0)),(F(1,2),F(1)),(F(1),F(1,2))],
  [F(1,4),F(1,2),F(1,4)]),
 ([(F(0),F(0),F(0)),(F(1),F(0),F(0)),
   (F(0),F(1),F(0)),(F(0),F(0),F(1))],[F(1,4)]*4)
]
def means(points,weights,r,anchored):
    n=len(points[0])
    if anchored:
        states={(tuple([F(1,4)]*n),tuple([F(3,4)]*n)):F(1)}
    else:
        states={(x,x):w for x,w in zip(points,weights)}
    for _ in range(r if anchored else r-1):
        nxt=defaultdict(F)
        for (lo,hi),p in states.items():
            for x,w in zip(points,weights):
                key=(tuple(min(lo[i],x[i]) for i in range(n)),
                     tuple(max(hi[i],x[i]) for i in range(n)))
                nxt[key]+=p*w
        states=nxt
    return [sum(p*(hi[i]-lo[i]) for (lo,hi),p in states.items()) for i in range(n)]
for phase,(points,weights) in enumerate(models,1):
    local=0;n=len(points[0])
    for r in [1,2,4,6]:
        anchored=means(points,weights,r,True)
        anchored_next=means(points,weights,r+1,True)
        free=means(points,weights,r,False)
        free_next=means(points,weights,r+1,False)
        cr=F(r**r,(r+1)**(r+1))
        for i in range(n):
            cuts=sorted(set([F(0),F(1),F(1,4),F(3,4)]+[x[i] for x in points]))
            ea=F(1,2);da=F(0);ef=F(0);df=F(0)
            for l,u in zip(cuts,cuts[1:]):
                mid=(l+u)/2
                p=sum(w for x,w in zip(points,weights) if x[i]<=mid)
                width=u-l
                ef+=width*(1-p**r-(1-p)**r)
                df+=width*(p**r*(1-p)+(1-p)**r*p)
                if mid>F(3,4):
                    ea+=width*(1-p**r);da+=width*p**r*(1-p)
                elif mid<F(1,4):
                    ea+=width*(1-(1-p)**r);da+=width*(1-p)**r*p
            assert anchored[i]==ea
            assert anchored_next[i]-anchored[i]==da
            assert F(0)<=da<=cr/2
            assert free[i]==ef
            assert free_next[i]-free[i]==df
            assert F(0)<=df<=2*cr
            checks+=6;local+=6
    print("phase",phase,"PASS",local)
print("total PASS",checks,"Fraction conditional-range assertions; no native-history claim")
~~~
