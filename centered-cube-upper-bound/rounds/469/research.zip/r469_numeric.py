from fractions import Fraction as F
from pathlib import Path
from itertools import product
from math import isqrt
import json,sys,platform,time
import sympy as s
from flint import arb,ctx
ROOT=Path(__file__).resolve().parent
start=time.perf_counter();checks=0;ctx.prec=192

def ck(z):
 global checks
 assert z
 checks+=1

def frac(x):return F(int(s.numer(x)),int(s.denom(x)))
def intervalpoly(poly,lo,hi):
 a=b=F(0)
 for coef in s.Poly(poly,u).all_coeffs():
  vals=[a*lo,a*hi,b*lo,b*hi];c=frac(coef);a=min(vals)+c;b=max(vals)+c
 return a,b
u=s.Symbol('u',real=True)
def scalar(r):
 if r==1:S=s.Integer(2)
 else:
  old,cur=s.Integer(2),s.Integer(1)
  for m in range(2,r):old,cur=cur,s.expand(cur-u*old)
  S=cur
 g=s.Poly(s.expand(u*S),u)
 derivative=g.diff();candidates=[(F(0),F(0)),(F(1,4),F(1,4))]
 roots=derivative.intervals(eps=s.Rational(1,10**35)) if derivative.degree()>0 else []
 for (a,b),multiplicity in roots:
  a=frac(a);b=frac(b)
  if b<0 or a>F(1,4):continue
  candidates.append((max(a,F(0)),min(b,F(1,4))))
 bounds=[]
 for a,b in candidates:
  lo,hi=intervalpoly(g.as_expr(),a,b);mid=(a+b)/2;val=frac(g.eval(s.Rational(mid.numerator,mid.denominator)))
  ck(lo<=val<=hi);bounds.append((a,b,lo,hi,val))
 lower=max(z[4] for z in bounds);upper=max(z[3] for z in bounds)
 coarse=2*F(r**r,(r+1)**(r+1));simple=F(2,r+1)
 ck(lower<=upper<=coarse<=simple);ck(upper-lower<F(1,10**34))
 winners=[z for z in bounds if z[3]>=lower]
 for a,b,_,_,_ in winners:ck(0<=a<=b<=F(1,4))
 return dict(r=r,h_u=str(g.as_expr()),derivative=str(derivative.as_expr()),real_stationary_intervals_in_domain=[dict(lo=a,hi=b) for a,b in candidates[2:]],
  optimal_h_lower=lower,optimal_h_upper=upper,optimal_h_display=str(s.N(s.Rational(lower.numerator,lower.denominator),20)),
  maximizing_u_enclosures=[dict(lo=z[0],hi=z[1]) for z in winners],coarse_termwise_bound=coarse,simple_bound=simple,
  coarse_over_best_display=str(s.N(s.Rational(coarse.numerator,coarse.denominator)/s.Rational(lower.numerator,lower.denominator),15)))
scalars=[scalar(r) for r in (1,2,3,4,8,16,32,64)]
for row,expected in zip(scalars[:4],(F(1,2),F(1,4),F(1,8),F(1,12))):ck(row['optimal_h_lower']==row['optimal_h_upper']==expected)
# Independent polynomial symmetry identity checks for p representation.
p=s.Symbol('p',real=True)
for row in scalars:
 r=row['r'];ck(s.expand(s.sympify(row['h_u'],locals={'u':u}).subs(u,p*(1-p))-(p**r*(1-p)+(1-p)**r*p))==0)
# Range identities for finite CDFs: direct joint enumeration vs exact CDF integration.
distributions=[('fair_two_point',[F(0),F(1)],[F(1,2),F(1,2)]),('rare_two_point',[F(0),F(1)],[F(1,5),F(4,5)]),('three_levels',[F(0),F(1,3),F(1)],[F(1,4),F(1,2),F(1,4)])]
def enum_range(points,probs,r):
 out=F(0)
 for idx in product(range(len(points)),repeat=r):
  prob=F(1)
  for i in idx:prob*=probs[i]
  out+=prob*(max(points[i] for i in idx)-min(points[i] for i in idx))
 return out
cdf=[]
for name,points,probs in distributions:
 ck(sum(probs)==1)
 for r in (1,2,4):
  rng=F(0);delta=F(0);cum=F(0)
  for i in range(len(points)-1):
   cum+=probs[i];length=points[i+1]-points[i]
   rng+=length*(1-cum**r-(1-cum)**r)
   delta+=length*(cum**r*(1-cum)+(1-cum)**r*cum)
  direct=enum_range(points,probs,r);directnext=enum_range(points,probs,r+1)
  ck(rng==direct);ck(delta==directnext-direct)
  ck(delta<=2*(points[-1]-points[0])*F(r**r,(r+1)**(r+1)))
  cdf.append(dict(name=name,r=r,points=points,probabilities=probs,expected_range=rng,increment=delta))
# Fixed old endpoints: exterior intervals are disjoint, hence no factor two.
fixed=[]
for name,points,probs in distributions:
 oldpairs=[(points[0],points[0]),(points[-1],points[-1]),(points[0],points[-1])] if len(points)==2 else [(points[0],points[1]),(points[1],points[1]),(points[0],points[-1])]
 for y,z in oldpairs:
  lo=min(y,z);hi=max(y,z)
  for r in (1,2,4):
   endpoints=sorted(set(points+[lo,hi]));delta=F(0)
   for a,b in zip(endpoints,endpoints[1:]):
    mid=(a+b)/2;CDF=sum(prob for x,prob in zip(points,probs) if x<=mid)
    if mid<lo:delta+=(b-a)*(1-CDF)**r*CDF
    elif mid>hi:delta+=(b-a)*CDF**r*(1-CDF)
   def direct(k):
    ans=F(0)
    for idx in product(range(len(points)),repeat=k):
     prob=F(1)
     for i in idx:prob*=probs[i]
     vals=[y,z]+[points[i] for i in idx]
     ans+=prob*(max(vals)-min(vals))
    return ans
   old_r=direct(r);old_next=direct(r+1);ck(delta==old_next-old_r)
   cr=F(r**r,(r+1)**(r+1));bound=(points[-1]-points[0]-(hi-lo))*cr
   ck(0<=delta<=bound)
   fixed.append(dict(name=name,old_y=y,old_z=z,r_background=r,expected_range=old_r,increment=delta,exterior_bound=bound))
# Center-volume loss needs a fixed source law, independent of testing center B.
center_scalar=[]
for r in (1,2,4,8,16,32,64):
 if r==1:
  maximum=F(1);at=F(0)
 else:
  ck(s.expand(s.diff(p**(r-1)*(1-p),p)-p**(r-2)*((r-1)-r*p))==0)
  at=F(r-1,r);maximum=at**(r-1)*(1-at)
  ck(maximum==F((r-1)**(r-1),r**r))
 center_scalar.append(dict(r=r,pointwise_quotient_max=maximum,argmax_p=at,formula='p^r(1-p)<=c_(r-1)*p'))

# Joint vectors: coordinates are deliberately dependent; only samples are iid.
models=[]
for n in (4,16,64,256,1024):
 k=isqrt(n)
 for r in (k,k+2):
  # Uniform axis vector e_J; each coordinate is Bernoulli(1/n), not independent.
  arange=n*(1-(1-F(1,n))**r-F(1,n)**r)
  adelta=(1-F(1,n))**r+F(n-1,n**r)
  # Independent check by exact count of distinct labels, subtract all-identical correction.
  distinct=n*(1-(1-F(1,n))**r)
  ck(arange==distinct-n*F(1,n)**r)
  ck(n*(1-(1-F(1,n))**(r+1)-F(1,n)**(r+1))-arange==adelta)
  for typ,prob in (('all_coordinates_fair',F(1,2)),('all_coordinates_rare',F(1,r+1))):
   erange=n*(1-prob**r-(1-prob)**r)
   inc=n*(prob**r*(1-prob)+(1-prob)**r*prob)
   ck(n*(1-prob**(r+1)-(1-prob)**(r+1))-erange==inc)
   scalarbound=next((z['optimal_h_upper'] for z in scalars if z['r']==r),2*F(r**r,(r+1)**(r+1)))
   ck(inc<=n*scalarbound)
   models.append(dict(n=n,k=k,r=r,model=typ,probability_of_diagonal_one=prob,sumrange=erange,increment=inc,
    sumrange_over_n=erange/n,increment_over_sqrt_n=inc/k,
    sumrange_display=str(s.N(s.Rational(erange.numerator,erange.denominator),14)),increment_display=str(s.N(s.Rational(inc.numerator,inc.denominator),14)),
    dependence='one Bernoulli chooses either 0 vector or 1 vector; coordinates fully correlated'))
  models.append(dict(n=n,k=k,r=r,model='uniform_axis',sumrange=arange,increment=adelta,sumrange_over_n=arange/n,increment_over_sqrt_n=adelta/k,
   sumrange_display=str(s.N(s.Rational(arange.numerator,arange.denominator),14)),increment_display=str(s.N(s.Rational(adelta.numerator,adelta.denominator),14)),
   dependence='one uniform label chooses e_J; coordinates mutually exclusive, not independent'))
# Exact analytic limits for the fully correlated rare-direction family n=r^2.
rr=s.Symbol('rr',positive=True)
rare_range=1-(1/(rr+1))**rr-(rr/(rr+1))**rr
rare_increment_over_root=rr*((1/(rr+1))**rr*(rr/(rr+1))+(rr/(rr+1))**rr/(rr+1))
range_limit=s.limit(rare_range,rr,s.oo);increment_limit=s.limit(rare_increment_over_root,rr,s.oo)
ck(s.simplify(range_limit-(1-s.exp(-1)))==0);ck(s.simplify(increment_limit-s.exp(-1))==0)

# Arb independently encloses concrete limiting constants; no asymptotic assertion inferred from samples.
inv_e=(-arb(1)).exp();ck(inv_e>arb(36)/100);ck(inv_e<arb(37)/100)
ck(1-inv_e>arb(63)/100);ck(1-inv_e<arb(64)/100)
out=dict(scope='Finite same-joint probability range/increment and optimal scalar certificates; no native cube/highrank/history or parent payment bridge',
 executable=sys.executable,python=platform.python_version(),sympy=s.__version__,arb_precision_bits=ctx.prec,checks=checks,scalar_certificates=scalars,cdf_cases=cdf,fixed_old_endpoint_cases=fixed,center_volume_scalar=center_scalar,joint_models=models,
 formulas=dict(range='E range_r=int[1-F^r-(1-F)^r]dt',increment='Delta_r=int[F^r(1-F)+(1-F)^r F]dt',
 optimal_scalar='h_r(p)=u S_(r-1)(u), u=p(1-p) in [0,1/4], S0=2,S1=1,S_m=S_(m-1)-u S_(m-2); maximize at endpoints and derivative roots',
 axes='E sumrange=n[1-(1-1/n)^r-(1/n)^r]; Delta=(1-1/n)^r+(n-1)/n^r',
 caveat='For r=k+2 all r points iid from the same law, not two conditioned old sources plus k iid backgrounds'),
 analytic_rare_family_limits=dict(n='r^2',sumrange_over_n=str(range_limit),increment_over_sqrt_n=str(increment_limit)),
 limiting_constants_arb=dict(inv_e=str(inv_e),one_minus_inv_e=str(1-inv_e)),
 compute_index=dict(status='complete',command='/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python r469_numeric.py',
 arithmetic='Fraction exact CDF/model moments, SymPy exact Sturm root intervals and rational interval Horner for global scalar max, Arb192 constants',seconds=time.perf_counter()-start))
(ROOT/'r469_numeric.json').write_text(json.dumps(out,default=str,indent=2)+'\n')
print(sys.executable,'Python',platform.python_version(),'SymPy',s.__version__)
for z in scalars:print('r',z['r'],'optimal h',z['optimal_h_display'],'coarse/best',z['coarse_over_best_display'])
for z in models:
 if z['n'] in (16,1024) and z['r']==z['k']:print('n',z['n'],z['model'],'sumrange',z['sumrange_display'],'increment',z['increment_display'])
print('PASS',checks,'exact/interval assertions;',len(scalars),'scalar r;',len(cdf),'CDF cases;',len(fixed),'fixed-old cases;',len(models),'joint model evaluations')
