# R469：共享 packet 字典的真实收费与独立验证

本稿作用于同一原记录测度 \(P\)，父边缘 \(\nu\le S\sigma\)，\(\sigma(dA)=q_A\,dA\)。记 \(\mu=f\,dx\)、\(W=\mu(\mathbb R^n)\)、\(m_A=\mu(Q_A)=q_AR_A^n\)、\(q\le q_A\le\lambda\)、\(r=\lambda/q\)、\(a\le R_A\le b\le2a\)、\(X=\sigma(E)\)。cube 参数均为边长。新增样本只用于正分数筛选；原接受、来源、阶段、两条路径及历史不变。以下是可付筛选收据，**没有证明它恢复原流的固定比例或支付完整分散补集**。

## 1. 一个共同字典的原生中心收费

固定至多可数轴平行盒字典 \(\mathcal C=(C_i)\)，满足
\[
 \sum_{j=1}^n\ell_{ij}/a\le L,\qquad
 \sum_i1_{C_i}(x)\le J\quad\mu\text{-a.e.}
\]
盒不必构成分割。对 \(0<\theta\le1\)，令 \(E_i=\{A:\pi_A(C_i)\ge\theta\}\)。若 \(\mu(C_i)<q\theta a^n\)，则 \(E_i=\varnothing\)；等号不能删去。否则令
\(R_i=[\mu(C_i)/(q\theta)]^{1/n}\ge a\)。真实完整匹配给
\[
 m_A\le\mu(C_i)/\theta,\quad R_A\le R_i,\quad
 E_i\subset C_i+[-R_i/2,R_i/2]^n.
\]
最后一条只需 \(Q_A\cap C_i\) 有正来源质量，不要求完整捕获盒。因此
\[
 \sigma(E_i)\le\lambda R_i^n\prod_j(1+\ell_{ij}/R_i)
 \le r e^L\mu(C_i)/\theta,
\]
以及
\[
 P\{\exists i:\pi_A(C_i)\ge\theta\}
 \le \frac{Sr e^LJ}{\theta}W.\tag{1}
\]
这是真实 Lebesgue 中心与匹配质量的收费，不是体积控制来源密度。

允许随机字典，但须由**一个全局随机种子**生成，其分布独立于被积原记录（可以依赖固定的完整 \(f\)）；对几乎每个种子，以上边长与来源重数界必须同时适用于全部父。逐实现用 (1) 后取期望即可。若字典的条件分布随父 \(A\) 改变，即使每个字典各自满足 \(J=1\)，也不能使用此论证。训练可以依赖父、原记录和其辅助样本，从同一个字典中可测地选盒或弃权；不能因此免费生成新的父私有字典。

## 2. Sample splitting：置信失败与背景归一化全部保留

固定原记录 \(\xi\)，其两个终端满足 \(m_u,m_v<m_A/K^2\)。令
\[
 O_\xi=Q_A\setminus(Q_u\cup Q_v),\quad
 d_\xi=\pi_A(O_\xi)\ge d_*:=1-2/K^2>0,
 \quad\rho_\xi=1_{O_\xi}\pi_A/d_\xi.
\]
训练阶段从共同字典选 \(C=C(\xi,\text{seed},\text{training})\)。在训练结束后，另附 \(k\) 个条件独立的验证样本 \(Z_j\sim\rho_\xi\)，并与训练条件独立。弃权时验证永不接受。令
\[
 \tau=\theta/d_*\le1/4,\quad
 N_C=\sum_{j=1}^k1_C(Z_j),\quad
 \mathsf{Acc}=\{N_C\ge\lceil2k\tau\rceil\}.
\]
若原父不是任何字典盒的 \(\theta\)-重父，则选中盒的背景率
\(p=\rho_\xi(C)\le\theta/d_*=\tau\)。由 \(2^{N_C}\) 的 Markov 界，含整数端点，
\[
 \Pr(\mathsf{Acc}\mid\xi,\text{seed},\text{training})
 \le 2^{-\lceil2k\tau\rceil}(1+p)^k
 \le e^{-c_0k\tau},\quad c_0=2\log2-1>0.
\]
结合 (1)、\(|P|\le SX\)，得到实际原流的正分数收据
\[
 \boxed{\ P^{\rm val}(\mathsf{Acc})
 \le \frac{Sr e^LJ}{\theta}W+S e^{-c_0k\theta/d_*}X.\ }\tag{2}
\]
它在原记录上拉回为接受概率乘 \(P\)，不赋验证样本任何历史。例如取 \(\theta=\min(d_*/4,1/(1+\sqrt n))\)、固定 \(L,J\)，第一项是根阶；通过选 \(k\) 可将第二项系数降至任给正数。所有参数均显式，未隐藏字典大小或每父重复收费。

若训练选中的背景率 \(p\ge4\tau\)，则拒绝事件 \(N_C<\lceil2k\tau\rceil\) 蕴含 \(N_C<2k\tau\)。用 \(2^{-N_C}\) 得
\[
 \Pr(\mathsf{Acc}^c\mid\cdot)
 \le e^{-2(1-\log2)k\tau}\le e^{-k\tau/2}.\tag{3}
\]
所以 (2) 能可靠识别训练已经找到的重盒；**尚未证明训练能在原流多数记录上找到它**。完整未付量精确保留为 \(P^{\rm val}(\mathsf{Acc}^c)\)，或在拉回后保留相同拒绝概率乘 \(P\)。未覆盖来源、选盒失败、小背景率均在其中。

在 (2) 的直接概率论证中没有取出 \(\rho_\xi\) 的密度，所以无需另付 \(d_*^{-k}\)。若把验证样本展开到原生多来源中心核，则真实密度是
\[
 \rho_\xi^{\otimes k}
 =d_\xi^{-k}1_{O_\xi^k}\pi_A^{\otimes k}
 \le d_*^{-k}\pi_A^{\otimes k}.
\]
此时必须保留 \(d_*^{-k}\)，不能同时将背景率帽误写成 \(\theta\)。依次排除先前样本的抽样也不是本稿的固定背景 law。

## 3. 恢复率校准：为何固定分割的样本损失权本身不够

对任意来源分割，记 \(p_i=\mu(C_i\cap Q_A)/\mu(C_i)\)、\(\pi_i=\pi_A(C_i)\)。父稿的可付权
\[
 w_k(A)=\sum_i\pi_i p_i^{k-1}(1-p_i),\quad
 \int w_k\,d\nu\le S c_{k-1}A_nW,
 \quad c_j=\frac{j^j}{(j+1)^{j+1}},\ c_0=1
\]
同时具有点态幅度上限
\[
 0\le w_k(A)\le c_{k-1},\qquad A_n=1+n\log(b/a).\tag{4}
\]
因为 \(\sum_i\pi_i\le1\)，且单项在 \(p=(k-1)/k\) 达到最大值。随机选分割不改变 (4)。当 \(k\asymp\sqrt n\)，未归一加权量虽有根阶价格，其最大恢复比例也仅 \(O(n^{-1/2})\)。归一化为 \(w_k/c_{k-1}\) 后继承的价格回到 \(SA_nW\)。因此不把该加权根价列为完整原流的新付款。

本次尚缺的具体构造是：在统一 \(L,J\) 的共享字典下，利用原匹配和完整来源证明训练失败/分散部分有可付总质量，或者构造真正共同的有符号结算使许多样本损失不逐次收费。小经验 hull 本身不保证这点；独立验证只证明条件置信度，不解决训练所选字典的跨父来源重数。固定三个样本也不能替代随维度增长的取样：其经验 hull 最多记录三个稀有方向，而不必暴露完整来源的分散性。此处没有新增反例扫描，也没有宣称固定样本失败否定可变样本路线。

## 4. 实际本机精确检查

使用指定 Python 环境运行下列自含代码。前半为已实际运行的 180 项 Fraction 幅度核验；后半为三个 \(\tau\) 阶段的二项验证整数端点、Markov 上界检查。它们只验证有限概率代数，不认证原生全匹配场或原历史非空。一般中心证明与概率证明独立于这些有限检查。

```python
from fractions import Fraction as F
from math import comb, ceil
checks=0
for k in (1,2,4,8):
    r=k+1;c=F(k)**k/F(k+1)**(k+1)
    for j in range(41):
        p=F(j,40)
        assert p**k*(1-p)<=c;checks+=1
    assert F(k,k+1)**k*(1-F(k,k+1))==c;checks+=1
    assert c<=F(1,k+1);checks+=1
for r in (2,3,5,9):
    p=[F(1),F(1,2),F(r-1,r)];pi=[F(1,4),F(1,4),F(1,2)]
    c=F(r-1)**(r-1)/F(r)**r
    w=sum(a*b**(r-1)*(1-b) for a,b in zip(pi,p))
    assert w<=c;checks+=1
    assert w/c<=1;checks+=1
print('amplitude PASS',checks)
validation=0
for tau in (F(1,16),F(1,8),F(1,4)):
    local=0
    for k in (4,8,16):
        threshold=ceil(2*k*tau)
        for p in (F(0),tau/2,tau):
            acc=sum(F(comb(k,j))*p**j*(1-p)**(k-j)
                    for j in range(threshold,k+1))
            assert acc<=F(1,2)**threshold*(1+p)**k
            assert acc<=F(1,2)**threshold*(1+tau)**k
            local+=2
        for p in (4*tau,(1+4*tau)/2,F(1)):
            reject=sum(F(comb(k,j))*p**j*(1-p)**(k-j)
                       for j in range(threshold))
            assert reject<=F(2)**(threshold-1)*(1-p/2)**k
            local+=1
    validation+=local
    print('validation tau',tau,'PASS',local)
print('total PASS',checks+validation,
      'Fraction assertions; probability algebra, no native-history claim')
```

实际 stdout：

```text
amplitude PASS 180
validation tau 1/16 PASS 27
validation tau 1/8 PASS 27
validation tau 1/4 PASS 27
total PASS 261 Fraction assertions; probability algebra, no native-history claim
```
