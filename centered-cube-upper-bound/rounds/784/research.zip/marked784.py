#!/usr/bin/env python3
"""R784 exact right-mark law, independent true samples and one common pool law."""

from collections import defaultdict
from fractions import Fraction as F
from itertools import product
import json
import sys


def ss(xs):
    return sum(xs,F(0))


def length(q):
    return max(F(0),q[1]-q[0])


def section(*intervals):
    return max(q[0] for q in intervals),min(q[1] for q in intervals)


def mu1(I):
    lo,hi=section(I,(F(-8),F(8)))
    period=F(1,8)

    def primitive(x):
        k=x//period
        r=x-k*period
        return k*period+r/2+max(F(0),r-period/2)

    return primitive(hi)-primitive(lo) if hi>lo else F(0)


def left_bucket(m):
    b=m.numerator.bit_length()-m.denominator.bit_length()
    return b-1 if F(2)**b>m else b


def nodes_in_tree(keys):
    nodes=[]
    def split(values):
        if len(values)<2:
            return
        t=len(values)//2
        L,U=values[:t],values[t:]
        nodes.append((L,U))
        split(L)
        split(U)

    split(tuple(keys))
    return nodes


def certify(n,eta,pieces):
    if n==6:
        r=[F(i,16) for i in (16,22,22,23,30)]
        c=[F(i,32) for i in (0,-42,44,-44,60)]
        probe_v=4
        known_pool=(0,0)
    else:
        r=[F(i,8) for i in (8,9,10,11,12,13,14,15,15)]
        c=[F(i,8) for i in (-12,9,-7,11,-10,7,-14,10,4)]
        probe_v=7
        known_pool=(0,pieces//2-1)
    ids=range(len(r))
    a=32*n
    h=1+F(1,a)
    m=[(2*s)**n for s in r]
    I=[x/a**n for x in m]
    weights=[I[j]/m[j] for j in ids]
    ends=[(z-s,z+s) for z,s in zip(c,r)]
    assert [mu1(q)*mu1((-s,s))**(n-1) for q,s in zip(ends,r)]==m
    assert all(abs(c[i]-c[j])>(r[i]+r[j])/a for i in ids for j in ids if i<j)
    assert all(1<=s<2 for s in r)
    if n==6:
        assert all((16*x).denominator==1 for x in c)
    owners=[(x-s/a,x+s/a) for x,s in zip(c,r)]

    def price_mass(indices,slab):
        first=section(slab,*(ends[j] for j in indices))
        s=min(r[j] for j in indices)
        return mu1(first)*mu1((-s,s))**(n-1)

    full=(F(-4),F(4))
    assert all(-4<=lo<=hi<=4 for lo,hi in ends)
    bins=[left_bucket(v) for v in m]
    tree=nodes_in_tree(range(min(bins),max(bins)+1))
    overlap={(i,j):price_mass((i,j),full) for i,j in product(ids,repeat=2)}
    good={(i,j) for (i,j),w in overlap.items() if i!=j and bins[i]!=bins[j] and 0<w<=eta*min(m[i],m[j])}
    K={(i,j):overlap[i,j]/(m[i]*m[j]) if (i,j) in good else F(0) for i,j in overlap}
    d={v:ss(I[j]*K[v,j] for j in ids) for v in ids}
    down={v:ss(I[j]*K[v,j] for j in ids if m[j]<m[v]) for v in ids}
    peak=ss(I[v]*down[v]**2/d[v] for v in ids if d[v])
    assert peak>0

    limits=[F(-4)+F(8*i,pieces) for i in range(pieces+1)]
    pools=list(zip(limits,limits[1:]))
    cuts=sorted({*limits,F(0),F(-1,8),F(1,8),*(point for J in ends for point in J)})
    atoms=list(zip(cuts,cuts[1:]))
    atoms_in_P={j:tuple(k for k,(a0,b0) in enumerate(atoms) if lo<=a0<b0<=hi)
                for j,(lo,hi) in enumerate(pools)}
    classes={v:{} for v in ids}
    for v in ids:
        for node,(B,U) in enumerate(tree):
            if bins[v] not in U:
                continue
            feasible=[u for u in ids if bins[u] in B and (u,v) in good]
            for P,region in enumerate(pools):
                active=[(u,k,weights[u]*price_mass((u,v),atoms[k]))
                        for u,k in product(feasible,atoms_in_P[P])]
                valid=[row for row in active if row[-1]]
                direct=ss(weights[u]*price_mass((u,v),region) for u in feasible)
                if direct:
                    assert direct==ss(w for _,_,w in valid)>0
                    classes[v][node,P]=(direct,valid)
    for v in ids:
        assert ss(total/m[v] for total,_ in classes[v].values())==down[v]
    assert known_pool in classes[probe_v] and len(classes[probe_v])>=2

    def marker_sample(v,label,records):
        M=ss(w for _,_,w in records)
        if label=="whole_true_down_arm":
            assert M/m[v]==down[v]
        full=[(k,w/M) for _,k,w in records]
        grouped=defaultdict(F)
        for k,w in full:
            grouped[k]+=w
        first={(-1,-1):F(1)}
        second=first

        def push(current,choices):
            result=defaultdict(F)
            for (lo,hi),w in current.items():
                for k,p in choices:
                    key=(k,k) if lo<0 else (min(lo,k),max(hi,k))
                    result[key]+=w*p
            assert ss(result.values())==1
            return result

        rows={}
        for k in range(1,5):
            first=push(first,full)
            second=push(second,grouped.items())
            assert first==second
            if k==1:
                continue
            same=mixed=range_ge=F(0)
            possible_min_length=None
            range_witness=None
            allowed_owner_centres=[]
            for (left,right),w in first.items():
                lo,hi=atoms[left],atoms[right]
                if lo[0]<0<=hi[0]:
                    mixed+=w
                else:
                    same+=w
                if hi[0]-lo[1]>=F(1,8):
                    range_ge+=w
                    if range_witness is None:
                        range_witness={"lowest_and_highest_true_cells":[lo,hi],
                                       "positive_exact_probability_of_this_extrema_state":w,
                                       "minimum_range_within_the_state":hi[0]-lo[1]}
                allowed=hi[1]-h*r[v],lo[0]+h*r[v]
                assert allowed[0]<=owners[v][0]<=owners[v][1]<=allowed[1]
                x=length(allowed)
                possible_min_length=x if possible_min_length is None else min(possible_min_length,x)
                allowed_owner_centres.append(allowed)
            neg=ss(w for x,w in grouped.items() if atoms[x][0]<0)
            assert same==neg**k+(1-neg)**k and mixed==1-same
            original_two_arm_budget=I[v]*(M/m[v])**2/d[v]
            rows[k]={"same_half_probability":same,"both_halves_probability":mixed,
                     "certified_minimum_range_at_least_1_over_8_probability":range_ge,
                     "minimum_first_axis_owner_envelope_length":possible_min_length,
                     "positive_range_witness":range_witness,
                     "peak_weighted_same_half":original_two_arm_budget*same,
                     "peak_weighted_both_halves":original_two_arm_budget*mixed,
                     "peak_weighted_certified_range":original_two_arm_budget*range_ge,
                     "axis_common_envelope_over_all_states":
                         (max(z[0] for z in allowed_owner_centres),min(z[1] for z in allowed_owner_centres))}
        transverse_radius=h*r[v]-max(r[u] for u,_,_ in records)
        assert transverse_radius>=r[v]/a
        return {"guaranteed_transverse_owner_envelope":(-transverse_radius,transverse_radius),
                "normalization_M":M,"x_equals_M_over_mv":M/m[v],"positive_true_label_cells":len(full),
                "positive_first_axis_cells_after_merging":len(grouped),"multi_mark_checks":rows}

    all_records=[r0 for _,records in classes[probe_v].values() for r0 in records]
    full_sample=marker_sample(probe_v,"whole_true_down_arm",all_records)
    M,local=classes[probe_v][known_pool]
    local_sample=marker_sample(probe_v,"known_source_class_only",local)
    if n==6:
        assert all(not p["both_halves_probability"] and not p["certified_minimum_range_at_least_1_over_8_probability"]
                   for p in full_sample["multi_mark_checks"].values())
    else:
        assert all(0<p["both_halves_probability"]<1 and p["certified_minimum_range_at_least_1_over_8_probability"]>0
                   for p in full_sample["multi_mark_checks"].values())
    v=probe_v
    b=known_pool
    other=next(j for j in sorted(classes[v]) if j!=b)
    a1,ar=classes[v][b]
    a2,br=classes[v][other]
    by_fix=I[v]*(a1/m[v])*(a2/m[v])/d[v]
    exact_paths=F(0)
    for (u,k,_),(g,l,_) in product(ar,br):
        old=I[u]*I[v]*K[u,v]*I[g]*K[v,g]/d[v]
        pair=price_mass((u,v),atoms[k])*price_mass((v,g),atoms[l])/(overlap[u,v]*overlap[v,g])
        exact_paths+=old*pair
    assert by_fix==exact_paths>0

    # Fix B,P once. The price (and, when retained, its mixture label) is drawn
    # from the same pool before looking at any of the feasible central labels.
    anchor_node,anchor_P=b
    B=tree[anchor_node][0]
    P=pools[anchor_P]
    support=[u for u in ids if bins[u] in B]
    pool_mass=ss(weights[u]*price_mass((u,),P) for u in support)
    eligible=[v for v in ids if b in classes[v]]
    assert len(eligible)>=2 and pool_mass>0
    original_class_total=ss(I[v]*(classes[v][b][0]/m[v])**2/d[v] for v in eligible)
    physical=ss(weights[u]*price_mass((u,*eligible),P) for u in support)/pool_mass
    common_label=ss(weights[u]*price_mass((u,*eligible),P)
                    for u in support if all((u,v) in good for v in eligible))/pool_mass
    by_label={v:classes[v][b][0]/pool_mass for v in eligible}
    first_axis=ss(weights[u]*mu1(section(P,ends[u],*(ends[v] for v in eligible)))*
                   mu1((-r[u],r[u]))**(n-1) for u in support)/pool_mass
    assert 0<=common_label<=physical<=first_axis<=1
    assert 0<physical<1 and all(0<p<1 for p in by_label.values())
    assert 0<=original_class_total*common_label<original_class_total
    assert 0<original_class_total*physical<original_class_total
    if n==6:
        assert common_label==0 and eligible==[3,4]
    return {"n":n,"eta":eta,"P_count":pieces,
            "real_parent_radii":r,"centres_first_axis":c,"physical_radius_octave":"[1,2)",
            "actual_mass_equals_Lebesgue":m,"actual_I_equals_disjoint_E_volume":I,
            "true_original_hard_degree":d,"real_old_peak":peak,
            "diagnostics":{"sampled_true_central":probe_v,"all_marked_arms":full_sample,
                           "one_known_source_class":local_sample},
            "two_real_source_classes_ordered_arms":{"central":probe_v,"b_c":[b,other],"x_b_x_c":[a1/m[probe_v],a2/m[probe_v]],
                                                     "exact_old_two_arm_budget_by_both_methods":by_fix},
            "one_shared_source_law":{"B_bins":B,"P":P,"N_true_source_pool":pool_mass,"same_price_for_central_labels":eligible,
                "actual_mu_pool_price_hits_all_central_A":physical,
                "real_peak_weighted_all_hit_with_same_reference_price":original_class_total*physical,
                "real_peak_weighted_all_hit_with_same_reference_label":original_class_total*common_label,
                "real_peak_weighted_all_hit_if_resampled_per_central":original_class_total,
                "first_axis_envelope_hits_all_central_owners":first_axis,
                "one_shared_small_label_is_legal_for_all_and_price_hits_all":common_label,
                "true_eligibility_for_each_central_before_rejection":by_label,
                "separately_resampling_from_each_true_conditional_gives_all_hit":F(1)},
            "scope":"physical source on all coordinates, diagnostic half/range and marked envelope on the first axis; already known B and P, genuine selected 783 intersections only"}


if __name__=="__main__":
    print(json.dumps({"python":sys.version.split()[0],"arithmetic":"Fraction",
                      "command":"python -B marked784.py",
                      "source_mu":"period 1/8, density 1/2 then 3/2 in each coordinate on [-8,8]^n",
                      "examples":[certify(n,eta,p) for n,eta,p in [(6,F(1,48),1),(8,F(3,4),2),(8,F(1,2),8)]]},
                     sort_keys=True,indent=2,default=str))
