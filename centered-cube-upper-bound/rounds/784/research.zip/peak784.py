"""Exact physical source cells, accepted peak posteriors, and Arb-Schur checks."""
from fractions import Fraction as F
from itertools import product
import json
import sys
from flint import arb, ctx, __version__ as flint_version
from marked784 import mu1, ss, left_bucket, nodes_in_tree
ctx.prec = 256

def ar(t):
    t=F(t)
    return arb(t.numerator)/arb(t.denominator)
def s_ar(xs):
    return sum(xs,arb(0))
enclosure_checks={"separated_or_exact":0,"overlapping_enclosures":0,
                  "undecided_positive_part":0}
def bounded(left,right):
    delta=right-left
    if delta>=0:
        enclosure_checks["separated_or_exact"]+=1
    else:
        assert delta.contains(0)
        enclosure_checks["overlapping_enclosures"]+=1
def mark_boundary(value):
    if not (value<0 or value>0 or value==0):
        assert value.contains(0)
        enclosure_checks["undecided_positive_part"]+=1
def ratio(a,b):
    return str(a/b) if b else None
def marked_scores(cids, B, G, local, H, mu, hb, fv, W, a, m, x, d, eta, window, variable, bins, legal):
    rows=[]
    marginal={v:[F(0) for z in mu] for v in cids}
    by_price=F(0)
    for i,(_,labels,z) in enumerate(local):
        base_masses=[W[v]*fv[v][i]*z for v in cids]
        by_price+=max(base_masses)
        for u in labels:
            if bins[u] not in B:
                continue
            tau=H[i]*a*z
            parts={v:(a*x[v]/(d[v]*H[i]) if v in labels and (u,v) in legal else F(0)) for v in cids}
            assert ss(parts.values())<=1
            for v in cids:
                marginal[v][i]+=tau*parts[v]
            rows.append((i,u,tau,parts))
    assert all(marginal[v][i]==W[v]*fv[v][i]*mu[i] for v in cids for i in range(len(mu)))
    q=ss(W.values())
    by_mark=ss(tau*max(parts.values()) for i,u,tau,parts in rows)
    by_two=ss(tau*ss(sorted(parts.values(),reverse=True)[:2]) for i,u,tau,parts in rows)
    assert by_price<=by_mark<=by_two<=q
    singleton_energy=ss(tau*ss(t*t for t in parts.values()) for i,u,tau,parts in rows)
    assert by_mark**2<=ss(tau for i,u,tau,parts in rows)*singleton_energy
    positive=arb(0)
    eall=F(0)
    hard_energy=F(0)
    nselected=0
    for g in sorted(set(G.values())):
        mids=[v for v in cids if G[v]==g]
        qg=ss(W[v] for v in mids)
        clusterF=[ss(parts[v] for v in mids) for _,_,_,parts in rows]
        assert ss(tau*clusterF[j] for j,(_,_,tau,_) in enumerate(rows))==qg
        selected=[]
        cuts={}
        powers={}
        score_by_v={}
        for v in mids:
            level=0
            if variable:
                for hh in sorted(set(H)):
                    if ss(mu[i]*fv[v][i] for i in range(len(mu)) if H[i]<=hh)>=F(1,2):
                        level=int(hh/a)
                        break
            cuts[v]=a*level
            powers[v]=window+level
            score=s_ar(ar(tau*parts[v]/W[v])*ar(clusterF[j]).sqrt()
                       for j,(i,_,tau,parts) in enumerate(rows) if H[i]>=cuts[v])
            score_by_v[v]=score
            fee=ar(eta*qg/(m[v]*x[v]**2)).sqrt()/(2**powers[v])
            mark_boundary(score-fee)
            if score>fee:
                selected.append(v)
                positive+=ar(W[v])*(score-fee)
            else:
                assert score<fee or (fee-score).contains(0)
        nselected+=len(selected)
        es=[F(0),F(0)]
        for v,w in product(selected,repeat=2):
            far=max(m[v],m[w])>2**(4*max(powers[v],powers[w]))*min(m[v],m[w])
            # In these fixtures good excludes same bin. A far pair has different bins.
            physically_small=(v,w) in legal or not any(a0[v]*a0[w] for _,_,_,a0 in rows)
            ev=ss(tau*parts[v]*parts[w] for i,u,tau,parts in rows if H[i]>=max(cuts[v],cuts[w]))
            es[int(far and physically_small)]+=ev
        cap=ar(eta)*s_ar(ar(m[v]).sqrt()*ar(x[v]*a/d[v]/(2**powers[v])) for v in selected)**2
        bounded(ar(es[1]),cap)
        bounded(s_ar(ar(W[v])*score_by_v[v] for v in selected)**2,ar(qg*ss(es)))
        eall+=es[0]
        hard_energy+=es[1]
    bounded(positive,ar(q*eall).sqrt())
    # Full one-group square at log-volume window log(4), before the positive-row cut.
    # This checks the common-u sum independently of the marginal price sum.
    far_marked=F(0)
    far_price=F(0)
    for v,w in product(cids,repeat=2):
        if (v,w) not in legal or max(m[v],m[w])<=4*min(m[v],m[w]):
            continue
        far_marked+=ss(tau*parts[v]*parts[w] for _,_,tau,parts in rows)
        far_price+=ss(W[v]*W[w]*mu[i]*fv[v][i]*fv[w][i]/(H[i]*hb[i])
                      for i in range(len(mu)) if H[i]*hb[i])
    cap=ar(eta)*s_ar(ar(a*x[v]/d[v])*ar(m[v]).sqrt() for v in cids)**2/2
    bounded(ar(far_marked),cap)
    bounded(ar(far_price),cap)
    return {"fixed_log4_all_rows_far_marked":str(far_marked),
            "fixed_log4_all_rows_far_price":str(far_price),
            "best_single_middle_from_price":str(by_price/q),
            "best_single_middle_from_mark":str(by_mark/q),"two_middle_list_from_mark":str(by_two/q),
            "true_mark_density_positive_over_group":str(positive/ar(q)),
            "true_mark_selected":nselected,"selected_far_hard_energy":str(hard_energy)}

def model(n,eta,parts,window,variable):
    if n==6:
        r=[F(i,16) for i in (16,22,22,23,30)]
        centers=[F(i,32) for i in (0,-42,44,-44,60)]
    else:
        r=[F(i,8) for i in (8,9,10,11,12,13,14,15,15)]
        centers=[F(i,8) for i in (-12,9,-7,11,-10,7,-14,10,4)]
    ids=range(len(r))
    m=[(2*s)**n for s in r]
    a=F(1,(32*n)**n)
    I=[a*x for x in m]
    bins=list(map(left_bucket,m))
    tree=nodes_in_tree(range(min(bins),max(bins)+1))
    intervals=[(x-s,x+s) for x,s in zip(centers,r)]
    edges=[F(-4)+F(8*j,parts) for j in range(parts+1)]
    xs=sorted({F(0),*edges,*(t for pair in intervals for t in pair)})
    ts=sorted({F(0),*r})
    cells=[]
    for lo,hi in zip(xs,xs[1:]):
        p=sum(t<=(lo+hi)/2 for t in edges)-1
        for t0,t1 in zip(ts,ts[1:]):
            lab={v for v in ids if intervals[v][0]<=lo<hi<=intervals[v][1] and t1<=r[v]}
            if lab:
                mass=mu1((lo,hi))*(mu1((-t1,t1))**(n-1)-mu1((-t0,t0))**(n-1))
                cells.append((p,lo,tuple(sorted(lab)),mass))
    overlaps={(v,w):ss(z for _,_,loc,z in cells if v in loc and w in loc) for v,w in product(ids,repeat=2)}
    assert all(overlaps[v,v]==m[v] for v in ids)
    legal={(v,w) for (v,w),z in overlaps.items() if v!=w and bins[v]!=bins[w] and 0<z<=eta*min(m[v],m[w])}
    d=[ss(a*overlaps[v,w]/m[v] for w in ids if (v,w) in legal) for v in ids]
    down=[ss(a*overlaps[v,w]/m[v] for w in ids if (v,w) in legal and m[w]<m[v]) for v in ids]
    whole=ss(I[v]*down[v]**2/d[v] for v in ids if d[v])
    groups=[]
    total_z=F(0)
    q0=F(0)
    energies=[F(0),F(0)]
    positive=s_ar([])
    z_positive=s_ar([])
    biggest_F2=F(0)
    all_selected=0
    for B,up in tree:
        for P in range(parts):
            local=[(lo,loc,z) for pp,lo,loc,z in cells if pp==P]
            if not local:
                continue
            H=[a*len(loc) for _,loc,_ in local]
            hb=[a*sum(bins[v] in B for v in loc) for _,loc,_ in local]
            mu=[z for _,_,z in local]
            tau=[h*k*z for h,k,z in zip(H,hb,mu)]
            Z=ss(tau)
            total_z+=Z
            fv={}
            x={}
            W={}
            for v in ids:
                if bins[v] not in up or not d[v]:
                    continue
                raw=[a*sum((v,u) in legal and bins[u] in B for u in loc) if v in loc else F(0)
                     for _,loc,_ in local]
                M=ss(b*z for b,z in zip(raw,mu))
                if M:
                    x[v]=M/m[v]
                    fv[v]=[b/M for b in raw]
                    assert ss(f*z for f,z in zip(fv[v],mu))==1
                    W[v]=I[v]*x[v]**2/d[v]
            if not W:
                continue
            q=ss(W.values())
            assert q<=Z
            q0+=q
            cids=list(W)
            G={v: (0 if variable<2 else (1 if centers[v]>=0 else -1)) for v in cids}
            mask=range(len(mu))
            sg={}
            cluster_mass={}
            for g in sorted(set(G.values())):
                Lg=[v for v in cids if G[v]==g]
                cluster_mass[g]=ss(W[v] for v in Lg)
                Fg=[ss(W[v]*fv[v][i] for v in Lg)/(H[i]*hb[i]) if H[i]*hb[i] else F(0) for i in mask]
                assert ss(z*f for z,f in zip(tau,Fg))==cluster_mass[g]
                assert all(0<=f<=1 for f in Fg)
                sg[g]=Fg
            Ftot=[ss(sg[g][i] for g in sg) for i in mask]
            assert max(Ftot)<=1
            biggest_F2=max(biggest_F2,max(Ftot))
            for g,Fg in sg.items():
                qg=cluster_mass[g]
                Lg=[v for v in cids if G[v]==g]
                levels={}
                ks={}
                scores={}
                chosen=[]
                for v in Lg:
                    hmin=0
                    if variable:
                        for z in sorted(set(H)):
                            if ss(mu[i]*fv[v][i] for i in mask if H[i]<=z)>=F(1,2):
                                hmin=int(z/a)
                                break
                    levels[v]=hmin
                    ks[v]=window+hmin
                    scores[v]=s_ar(ar(mu[i]*fv[v][i])*ar(Fg[i]).sqrt() for i in mask if H[i]>=hmin*a)
                    term=(ar(eta*qg/(m[v]*x[v]**2))).sqrt()/(2**ks[v])
                    delta=scores[v]-term
                    mark_boundary(delta)
                    if delta>0:
                        chosen.append(v)
                        positive+=ar(W[v])*delta
                    else:
                        assert delta<0 or delta.contains(0)
                    old=ar(eta*Z/(m[v]*x[v]**2)).sqrt()/(2**ks[v])
                    mark_boundary(scores[v]-old)
                    if scores[v]>old:
                        z_positive+=ar(W[v])*(scores[v]-old)
                all_selected+=len(chosen)
                lhs=s_ar(ar(W[v])*scores[v] for v in chosen)
                e=[F(0),F(0)]
                for v,w in product(chosen,repeat=2):
                    near=max(m[v],m[w])<=F(2)**(4*max(ks[v],ks[w]))*min(m[v],m[w])
                    high=overlaps[v,w]>eta*min(m[v],m[w])
                    epair=ss(W[v]*W[w]*fv[v][i]*fv[w][i]*mu[i]/(H[i]*hb[i])
                             for i in mask if hb[i] and H[i]>=max(levels[v],levels[w])*a)
                    e[int(not near and not high)]+=epair
                hard_cap=eta*ss(I[v]*x[v]/d[v]/((2*r[v])**(n//2))/F(2)**ks[v] for v in chosen)**2
                assert e[1]<=hard_cap
                bounded(lhs**2, ar(qg*ss(e)))
                energies=[left+right for left,right in zip(energies,e)]
            # The three-copy Schur kernel is formed from the genuine one-price laws in this same class.
            affinity={(v,w):s_ar(ar(mu[i])*ar(fv[v][i]*fv[w][i]).sqrt() for i in mask)
                       for v,w in product(cids,repeat=2)}
            for v in cids:
                assert affinity[v,v].contains(1)
            rows=[s_ar(ar(a)*affinity[v,w]**3 for w in cids) for v in cids]
            row_upper=max(t.upper() for t in rows)
            projections=[]
            for kind in ("one","halves","all"):
                parts2={}
                for i in mask:
                    name=0 if kind=="one" else (local[i][0]>=0 if kind=="halves" else i)
                    parts2.setdefault(name,[]).append(i)
                proj={}
                for v in cids:
                    mass1=s_ar(s_ar(ar(mu[i])*ar(fv[v][i]).sqrt() for i in subgroup)**2/
                               ar(ss(mu[i] for i in subgroup)) for subgroup in parts2.values())
                    proj[v]=mass1**3
                    bounded(proj[v],arb(1))
                    if kind=="all":
                        assert proj[v].contains(1)
                trace=s_ar(ar(a)*p for p in proj.values())
                bounded(trace,row_upper*(len(parts2)**3))
                projections.append({"partition":kind,"rank":len(parts2)**3,
                                    "genuine_weighted_projection_fraction":str(s_ar(ar(W[v])*proj[v] for v in cids)/ar(q))})
            ref=cids[0]
            self_rank=s_ar(ar(W[v])*affinity[ref,v]**6 for v in cids)/ar(q)
            bounded(self_rank,arb(1))
            if n==6 and list(B)==[6,7,8] and parts==1:
                assert set(cids)=={3,4} and fv[3]==fv[4] and self_rank.contains(1)
            observed=marked_scores(cids,B,G,local,H,mu,hb,fv,W,a,m,x,d,eta,window,variable,bins,legal)
            groups.append({"given_small_history_and_price":observed,"single_true_reference_projection_fraction":str(self_rank),"B":list(B),"P":P,"middle_ids":cids,"q":str(q),"Z":str(Z),"q_over_Z":str(q/Z),
                           "affinity_offdiagonal":{str((v,w)):str(affinity[v,w]) for v in cids for w in cids if v<w},
                           "rank_tests":projections,"schur_row_bound_divided_by_owner_density":str(row_upper/ar(a))})
    assert q0>0 and q0<=whole
    bounded(positive,ar(q0*energies[0]).sqrt())
    return {"n":n,"eta":str(eta),"P_count":parts,"s0_over_log2":4*window,
            "window_kind":["constant","true_H_median","true_H_median_and_middle_split"][variable],
            "q0":str(q0),"q0_over_true_peak":str(q0/whole),"q0_over_sum_Z":str(q0/total_z),
            "selected":all_selected,"true_q_deduction_over_q0":str(positive/ar(q0)),
            "substituting_old_Z_in_same_test_over_q0":str(z_positive/ar(q0)),
            "bad_and_near_square":str(energies[0]),"hard_far_square":str(energies[1]),
            "highest_true_F":str(biggest_F2),"groups":groups}
def biaxial(n):
    """Different active faces of the same small cube give a positive common-u cost."""
    r=(F(1),F(3,2),F(15,8))
    c=((F(0),F(0)),(F(9,4),F(0)),(F(0),F(11,4)))
    eta=F(1,8)
    a=F(1,(32*n)**n)
    m=[(2*t)**n for t in r]
    def mass(ids):
        factors=[]
        for j in range(2):
            lo=max(c[i][j]-r[i] for i in ids)
            hi=min(c[i][j]+r[i] for i in ids)
            factors.append(mu1((lo,hi)))
        mr=min(r[i] for i in ids)
        return factors[0]*factors[1]*mu1((-mr,mr))**(n-2)
    assert [mass([i]) for i in range(3)]==m
    assert all(any(abs(c[i][j]-c[k][j])>(r[i]+r[k])/(32*n) for j in range(2))
               for i in range(3) for k in range(i+1,3))
    bins=list(map(left_bucket,m))
    left,right=nodes_in_tree(range(bins[0],bins[2]+1))[0]
    assert bins[0] in left and all(b in right for b in bins[1:])
    I=[a*M for M in m]
    overlaps={(i,j):mass([i,j]) for i in range(3) for j in range(3) if i!=j}
    assert all(0<z<=eta*min(m[i],m[j]) for (i,j),z in overlaps.items())
    ratios=[overlaps[i,j]/min(m[i],m[j]) for i,j in ((0,1),(0,2),(1,2))]
    assert ratios==[F(1,8),F(1,16),F(5,64)]
    assert m[2]>4*m[1] and mass([0,1,2])==F(2**(n-2),32)
    d=[ss(I[j]*overlaps[i,j]/(m[i]*m[j]) for j in range(3) if j!=i) for i in range(3)]
    x={i:a*overlaps[0,i]/m[i] for i in (1,2)}
    p={i:x[i]/d[i] for i in (1,2)}
    W={i:I[i]*x[i]**2/d[i] for i in (1,2)}
    triple=mass([0,1,2])
    cost=2*triple*a**2*p[1]*p[2]/3
    tau=3*a*a*triple
    density={i:W[i]/(overlaps[0,i]*3*a*a) for i in (1,2)}
    assert all(density[i]==p[i]/3 for i in (1,2))
    assert 0<cost==2*tau*density[1]*density[2]
    upper=ar(eta)/2*s_ar(ar(a*p[i])*ar(m[i]).sqrt() for i in (1,2))**2
    assert ar(cost)<upper
    bounded(ar(cost),upper)
    return {"n":n,"eta":str(eta),"overlap_fractions":list(map(str,ratios)),
            "middle_volume_ratio":str(m[2]/m[1]),"common_true_triple_source_mass":str(triple),
            "q_common":str(ss(W.values())),"two_orderings_true_mark_far_square":str(cost),
            "fraction_of_far_square_cap":str(ar(cost)/upper)}

def lower_window():
    rows=[]
    for n in (256,1024,4096,2**16,2**24,2**40,2**80):
        an=arb(n)
        kval=((3*an/(74*an.log())).sqrt()-20+arb(1)/2).floor().unique_fmpz()
        assert kval is not None
        K=max(48,int(kval))
        h=1+F(1,32*n)
        for p in (2,4,8):
            distortion=F(2,K)+1-F(K,K+20)**p
            r0=F(p-1,p+1)
            low=1-min(1,r0+distortion)/h
            high=1-max(0,r0-distortion)/h
            reference=2+h/2
            rows.append({"n":n,"p":p,"K":K,"per_axis_envelope_lower":str(low),
                         "per_axis_envelope_upper":str(high),
                         "strict_lower_times_reference_above_one":(low*reference**(p-1)>1)})
    return rows
if __name__=="__main__":
    tests=[(6,F(1,48),1,0,0),(6,F(1,48),1,1,0),(6,F(1,48),1,2,0),
           (6,F(1,48),2,1,0),(6,F(1,48),1,1,1),(6,F(1,48),1,1,2),
           (8,F(3,4),2,1,0),(8,F(3,4),2,1,1),(8,F(1,2),8,1,0),(8,F(1,2),8,1,2)]
    print(json.dumps({"python":sys.version.split()[0],"python_flint":flint_version,"arb_bits":ctx.prec,
                      "models":[model(*t) for t in tests],"biaxial":[biaxial(n) for n in (8,12,24)],"original_wide_window":lower_window(),"enclosure_checks":enclosure_checks},indent=2,sort_keys=True))
