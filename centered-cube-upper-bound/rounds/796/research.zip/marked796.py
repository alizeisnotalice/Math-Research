#!/usr/bin/env python3
"""Exact far-mark calculation and an Arb check of the scalar contraction range."""
import argparse
from fractions import Fraction as F
from itertools import product
import json
from pathlib import Path
import platform

from flint import arb, ctx, __version__ as flint_version


def add(xs):
    return sum(xs, F(0))


def width(box):
    return max(F(0), box[1] - box[0])


def intersection(x, y):
    return max(x[0], y[0]), min(x[1], y[1])


def mid(box):
    return add(box) / 2


def positive(s):
    return max(F(0), s)


def split(box, knots):
    lo, hi = box
    endpoints = sorted({lo, hi, *(x for x in knots if lo < x < hi)})
    return list(zip(endpoints, endpoints[1:]))


def simpson(f, box, knots):
    return add((v - u) * (f(u) + 4*f((u + v)/2) + f(v)) / 6
               for u, v in split(box, knots))


def pieces(box, period, amplitude):
    if not amplitude:
        return [(*box, F(1))]
    half = period / 2
    lo, hi = box
    out = []
    while lo < hi:
        n = lo // half
        right = min(hi, (n + 1) * half)
        out.append((lo, right, 1 + amplitude if n % 2 == 0 else 1 - amplitude))
        lo = right
    return out


def mass(box, period, amplitude):
    return add((hi - lo) * r for lo, hi, r in pieces(box, period, amplitude))


def cubic_volume(x, p, fresh):
    """Use the eight-term truncated cubic difference for x+p <= 2*y."""
    a, b = x
    c, d = p
    e, f = fresh

    def Q(q):
        return (positive(q-a-c)**3 - positive(q-b-c)**3
                - positive(q-a-d)**3 + positive(q-b-d)**3) / 12

    return Q(2*f) - Q(2*e)


def convolution_volume(x, p, fresh):
    """Independent sum-density trapezoid and exact quadratic y integration."""
    a, b = x
    c, d = p
    bends = [a+c, a+d, b+c, b+d]

    def cdf(t):
        if t <= a+c:
            return F(0)
        t = min(t, b+d)

        def g(s):
            return width(intersection(x, (s-d, s-c)))

        return add((v-u)*(g(u)+g(v))/2 for u, v in split((a+c, t), bends))

    return simpson(lambda y: cdf(2*y), fresh, [z/2 for z in bends])


def strip(x, p, gap):
    """Area of points with p-x >= gap."""
    a, b = x
    c, d = p

    def ramp(t):
        return (positive(t-a)**2 - positive(t-b)**2) / 2

    return ramp(d-gap) - ramp(c-gap)


def chosen_far_left(x, p, fresh, R):
    a, b = x
    c, d = p

    def slice_area(y):
        limit = min(b, y-R)
        if limit <= a:
            return F(0)

        def ramp(t):
            return (positive(t-a)**2 - positive(t-limit)**2) / 2

        return ramp(2*y-c) - ramp(2*y-d)

    knots = [(v+w)/2 for v, w in product(x, p)] + [a+R, b+R, c-R, d-R]
    return simpson(slice_area, fresh, knots)


def reflect(iv):
    return -iv[1], -iv[0]


def joint_near(x, p, y, R):
    return simpson(lambda z: positive(x[1] - max(x[0], z-R))
                   * positive(min(p[1], z+R) - p[0]), y,
                   [x[0]+R, x[1]+R, p[0]-R, p[1]-R])


def block(left, right, ybox, R):
    lx, rx, ly = left[:2], right[:2], ybox[:2]
    w = left[2] * right[2] * ybox[2]
    v = width(lx)*width(rx)*width(ly)
    v_left = cubic_volume(lx, rx, ly)
    assert v_left == convolution_volume(lx, rx, ly)
    assert 0 <= v_left <= v
    lf = chosen_far_left(lx, rx, ly, R)
    rf = chosen_far_left(reflect(rx), reflect(lx), reflect(ly), R)
    near = joint_near(lx, rx, ly, R)
    assert 0 <= lf <= v_left and 0 <= rf <= v-v_left
    assert lf + rf + near == v
    return [w * q for q in (v_left, v-v_left, lf, rf, near, v)]


def owner(box):
    center = mid(box)
    half = width(box) / 64
    return center-half, center+half


def survivor_balance(table, probe_owners, old_raw, y_prior, threshold):
    # The pointwise U-density is constant on each original owner's interval.
    columns = [add(row[j] for row in table) for j in range(2)]
    density = [old_raw * columns[j] / width(probe_owners[j]) for j in range(2)]
    surviving = [j for j in range(2) if density[j] >= threshold]
    assert surviving
    removed = add(old_raw * columns[j] for j in range(2) if j not in surviving)
    bound = threshold * add(width(probe_owners[j]) for j in range(2) if j not in surviving)
    assert removed <= bound
    # Exact nondegenerate U tests within the actual surviving E intervals.
    U = [(j, box) for j in surviving
         for box in split(probe_owners[j], [probe_owners[j][0] + width(probe_owners[j])/3])]
    u_m = [columns[j] * width(box) / width(probe_owners[j]) for j, box in U]
    y_m = [add(row[j] for j in surviving) for row in table]
    whole = add(y_m)
    assert whole == add(u_m) > 0
    from_y, from_u, witness = [], [], None
    for i, ym in enumerate(y_m):
        forward = [table[i][j] * width(box) / (width(probe_owners[j]) * ym) if ym else F(0)
                   for j, box in U]
        assert add(forward) == int(ym > 0)
        from_y.append(forward)
    for k, (j, box) in enumerate(U):
        reverse = [row[j] / columns[j] for row in table]
        assert add(reverse) == 1
        for i, q in enumerate(reverse):
            assert (y_m[i] / whole) * from_y[i][k] == (u_m[k] / whole) * q
            if q != y_prior[i] and witness is None:
                witness = dict(y_cell=i, u_cell=k, conditional=q, original_prior=y_prior[i])
        from_u.append(reverse)
    assert witness is not None
    return dict(threshold=threshold, physical_u_density=density, live_owners=surviving,
                lost_raw_mass=removed, threshold_cap=bound,
                mass_of_surviving_far_records=old_raw * whole, u_cells=U,
                y_marginal=[z/whole for z in y_m], u_marginal=[z/whole for z in u_m],
                y_to_u=from_y, u_to_y=from_u, true_conditioning_witness=witness)


def geometry(name, terminal, parents, period, amplitude, R):
    A_l, A_r = parents
    L, R_old = intersection(A_l, terminal), intersection(A_r, terminal)
    assert width(L) > 0 and width(R_old) > 0 and L[1] < R_old[0]
    boxes = (terminal, A_l, A_r)
    masses = [mass(iv, period, amplitude) for iv in boxes]
    assert masses == list(map(width, boxes))
    E_t, E_l, E_r = map(owner, boxes)
    assert all(width(intersection(u, v)) == 0
               for index, u in enumerate((E_t, E_l, E_r))
               for v in (E_t, E_l, E_r)[index+1:])
    yl = split(terminal, [terminal[0] + width(terminal) * F(k, 3) for k in (1, 2)])
    left = pieces(L, period, amplitude)
    right = pieces(R_old, period, amplitude)
    old_m = [mass(iv, period, amplitude) for iv in (L, R_old)]
    y_prior = [mass(iv, period, amplitude)/masses[0] for iv in yl]
    denominator = masses[0] * old_m[0] * old_m[1]
    records = []
    for cell in yl:
        subtotal = [F(0)] * 6
        for cx, cp, cy in product(left, right, pieces(cell, period, amplitude)):
            subtotal = [a+b for a,b in zip(subtotal, block(cx, cp, cy, R))]
        records.append([n/denominator for n in subtotal])
    pl, pr, fl, fr, pn, unity = map(add, zip(*records))
    assert unity == 1 and pl+pr == fl+fr+pn == 1
    far = fl+fr
    assert min(fl, fr, pn) > 0
    span = add(p[2]*q[2]*strip(p[:2], q[:2], 2*R) for p,q in product(left,right)) / (old_m[0]*old_m[1])
    # Both near inequalities require p-x<2R, so near and wide old span are disjoint.
    assert 0 < span < 1 and far >= span
    assert [r[5] for r in records] == y_prior
    ordered_k = [old_m[i] / (masses[0]*masses[i+1]) for i in range(2)]
    true_degree = ordered_k[0]*width(E_l) + ordered_k[1]*width(E_r)
    old_raw = width(E_t) * width(E_l) * width(E_r) * ordered_k[0] * ordered_k[1] / true_degree
    assert old_raw > 0
    receive_probe = (E_l[0] + width(E_l)/4, mid(E_r))
    probe_rates = [width(intersection(receive_probe, e))/width(e) for e in (E_l,E_r)]
    terminal_probe_rates = [width(intersection(terminal, e))/width(e) for e in (E_l,E_r)]
    assert probe_rates == [F(3,4), F(1,2)]
    actual_probe_joint = fl*probe_rates[0] + fr*probe_rates[1]
    independent_probe_joint = far*(pl*probe_rates[0] + pr*probe_rates[1])
    physical_probe_densities = [old_raw * v/width(e) for v,e in zip((fl,fr),(E_l,E_r))]
    threshold = mid(physical_probe_densities)
    balance = survivor_balance([(s[2],s[3]) for s in records], (E_l,E_r), old_raw, y_prior, threshold)

    if name == "initial":
        assert pl == pr == F(1,2) and actual_probe_joint == independent_probe_joint
        assert balance["live_owners"] == [0,1]
    else:
        assert pl != pr and actual_probe_joint != independent_probe_joint
        assert len(balance["live_owners"]) == 1
    if name == "pressure":
        assert terminal_probe_rates == [F(1), F(1,2)]
        assert old_m[0] != width(L)
    return dict(stage=name, parents=boxes, true_parent_m=masses, owners=(E_t,E_l,E_r),
                true_old_price_intervals=(L,R_old), true_old_price_m=old_m, period=period,
                amplitude=amplitude, distance_threshold=R, raw_ordered_peak_mass=old_raw,
                central_degree=true_degree, left_right=[pl,pr], far_joint_left_right=[fl,fr],
                raw_far_left_right=[old_raw*fl,old_raw*fr], near=pn, probability_span_at_least_2R=span,
                far_given_old_span_at_least_2R=F(1), y_grid=yl, fresh_y_true_prior=y_prior,
                exact_block_ledger=records, actual_probe_box=receive_probe, owner_probe_rates=probe_rates,
                owner_rates_in_terminal=terminal_probe_rates,
                actual_joint_far_and_probe=actual_probe_joint,
                incorrect_independent_probe_joint=independent_probe_joint, terminal_owner_balance=balance)



def shared_terminal_mark():
    """Two actual terminals share the same once-read old owner coordinate."""
    t = [(F(0), F(4)), (F(3, 2), F(11, 2))]
    left, right = (F(-3, 4), F(9, 4)), (F(5, 2), F(11, 2))
    small = [left, right]
    E = [owner(box) for box in [*t, *small]]
    Eu, Eg = E[2:]
    assert all(width(intersection(p, q)) == 0
               for i, p in enumerate(E) for q in E[i+1:])
    period, amplitude, R = F(1, 2), F(1, 2), F(5, 4)
    y_test, z_test = (F(3), F(7, 2)), (F(11, 4), F(3))
    assert all(mass(box, period, amplitude) == width(box) for box in [*t, *small])

    def one(A):
        il, ir = [intersection(A, box) for box in small]
        assert il[1] < ir[0]
        m = mass(A, period, amplitude)
        ml, mr = [mass(box, period, amplitude) for box in (il, ir)]
        old_k = [u/(m*width(box)) for u, box in zip((ml, mr), small)]
        d = old_k[0]*width(Eu) + old_k[1]*width(Eg)
        old_mass = width(owner(A))*width(Eu)*width(Eg)*old_k[0]*old_k[1]/d
        start = max(A[0], il[0]+R, (il[0]+ir[0])/2)
        assert start < A[1]

        def accepted(y_box, z_box=ir):
            data = product(pieces(il, period, amplitude),
                           pieces(intersection(ir, z_box), period, amplitude),
                           pieces(intersection(A, y_box), period, amplitude))
            return add(u[2]*v[2]*y[2]*chosen_far_left(u[:2], v[:2], y[:2], R)
                       for u, v, y in data) * old_mass / (m*ml*mr)
        return accepted, (start, A[1]), dict(terminal=A, old_intersection=[il,ir],
                                             old_intersection_m=[ml,mr], original_d=d,
                                             old_peak_mass=old_mass)

    models = [one(A) for A in t]
    accepted = [f(A) for A,(f, _, _) in zip(t, models)]
    density = [v/width(Eu) for v in accepted]
    posterior = [v/add(density) for v in density]
    strongest = max(range(2), key=lambda i: density[i])
    residual = add(density)-density[strongest]
    assert 0 < residual == density[1-strongest] and add(posterior) == 1
    # Use a genuine positive interior interval of the same physical old E.
    U_piece = (Eu[0], Eu[0]+width(Eu)/3)
    assert width(U_piece) > 0
    joint_by_t, rows, differences = [], [], []
    for i, (f, supported, geometry_data) in enumerate(models):
        both, only_y, only_z = [f(a,b) for a,b in
                               [(y_test,z_test),(y_test,models[i][2]["old_intersection"][1]),(t[i],z_test)]]
        assert 0 < both <= min(only_y,only_z) < accepted[i]
        joint_by_t.append(both/width(Eu)*width(U_piece))
        cond_both = both/accepted[i]
        independent = only_y*only_z/accepted[i]**2
        differences.append(cond_both-independent)
        j = 1-i
        old_parent_free = split(t[i], t[j])
        old_active_free = split(t[i], models[j][1])
        unused_parent = add(f(b) for b in old_parent_free if width(intersection(b,t[j])) == 0)
        unused_mark = add(f(b) for b in old_active_free if width(intersection(b,models[j][1])) == 0)
        assert 0 < unused_parent <= unused_mark < accepted[i]
        assert f(supported) == accepted[i]
        rows.append(dict(**geometry_data, accepted_at_shared_U=accepted[i],
                         U_density=density[i], t_given_same_U=posterior[i],
                         marked_y_essential_support=supported, conditional_event_y_z=cond_both,
                         incorrectly_independent_y_z=independent,
                         fresh_after_other_parent=unused_parent/accepted[i],
                         fresh_after_other_marked_support=unused_mark/accepted[i],
                         positive_two_terminal_order_and_unoccupied_source=
                         posterior[j]*posterior[i]*unused_parent/accepted[i]))
    assert any(d for d in differences)
    joint_given_U = add(joint_by_t)/(add(density)*width(U_piece))
    assert joint_given_U == add(posterior[i]*rows[i]["conditional_event_y_z"] for i in range(2))
    return dict(terminal_rows=rows, source_law="true periodic 1±1/2 density restricted to [-8,8]",
                radius_gate=R, physical_owners=E, old_physical_parents=small, shared_Eu=Eu,
                chosen_U_subinterval=U_piece, joint_probe_y=y_test, joint_probe_old_z=z_test,
                strongest_only_terminal=strongest, total_shared_U_density=add(density),
                positive_unpaid_density_at_same_U=residual,
                remaining_mass_on_whole_Eu=accepted[1-strongest],
                at_same_U_t_y_z_joint=joint_given_U,
                interpretation="the same U has both marked roots; after spending a whole old parent, either order retains a strictly positive true marked source")


def A(x):
    x = F(x)
    return arb(x.numerator) / arb(x.denominator)


def scalar_range(n):
    a = F(1,32*n)

    def f(u):
        t = A(u)
        return (t/2).exp() - 1 - t*t.exp()/8 - A(a)

    def brackets(lo, hi, increasing):
        if increasing:
            assert f(lo) < 0 < f(hi)
        else:
            assert f(lo) > 0 > f(hi)
        for _ in range(38):
            u = (lo + hi)/2
            positive = f(u) > 0
            assert positive or f(u) < 0
            if positive == increasing:
                hi = u
            else:
                lo = u
        assert (f(lo) < 0 < f(hi)) if increasing else (f(lo) > 0 > f(hi))
        return [lo, hi]

    assert 4*(-A(1)/2).exp()-2 > 0 and 4*(-A(F(3,2))/2).exp()-A(F(5,2)) < 0
    assert f(F(1,4*n)) > 0 and f(F(7,4)) > 0
    lo = brackets(F(0),F(1,4*n),True)
    hi = brackets(F(7,4),F(2),False)
    assert f(F(1,n)) > 0 and f(F(2)) < 0
    scaled = [[n*z for z in edge] for edge in (lo,hi)]
    return dict(n=n, small_root_u_bracket=lo, large_root_u_bracket=hi,
                J_root_brackets=scaled, approximate_J_brackets=[[float(q) for q in edge] for edge in scaled],
                certified_safe_J=[F(1,4), F(7*n,4)], fails_at_J=[0,2*n])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    cli = parser.add_mutually_exclusive_group()
    cli.add_argument("--output", type=Path)
    cli.add_argument("--check", type=Path)
    args = parser.parse_args()
    ctx.prec = 256
    cases = [
        geometry("initial", (F(-2),F(2)), ((F(-3,2),F(-1)),(F(1),F(3,2))), F(1,4),F(0),F(5,4)),
        geometry("pressure", (F(0),F(4)), ((F(-7,16),F(13,16)),(F(3),F(5))), F(1,4),F(1,2),F(3,2)),
        geometry("expanded", (F(-2),F(4)), ((F(-3),F(-3,4)),(F(3,8),F(15,8))), F(3,4),F(3,4),F(7,4)),
    ]
    result = dict(
        runtime=dict(python=platform.python_version(), architecture=platform.machine(), flint=flint_version,
                     arb_bits=ctx.prec), command="python -B marked796.py --check marked796.json",
        range_proof=("For u=J/n>=0, H(u)=exp(u/2)-1-u exp(u)/8 must be at least 1/(32n). "
                     "H'(u) has the sign of 4 exp(-u/2)-(1+u), which strictly decreases. "
                     "Arb brackets both roots for each listed n. "
                     "The safe range [1/4,7n/4] is uniform: 1/4<=J<=n follows from "
                     "H(u)>=u/8 for u<=1, and the rest follows from unimodality and "
                     "the Arb-verified H(7/4)>1/32. J=0 and J=2n fail, the latter by "
                     "H(2)=-(exp(1)-2)^2/4."),
        scalar=[scalar_range(n) for n in (1,16,64,256)],
        precision="Fraction for continuous one-dimensional geometry; Arb sign tests for exponentials only",
        scope="true terminal and old-intersection prices, independent conditional arms, original disjoint owner probes; the Far and U gates are diagnostic",
        cases=cases, shared_terminal_mark=shared_terminal_mark(),
    )
    text = json.dumps(result, default=str, sort_keys=True, indent=2) + "\n"
    if args.output:
        args.output.write_text(text)
    if args.check:
        assert args.check.read_text() == text
    if args.output or args.check:
        for line in cases:
            print(line["stage"], "left",line["left_right"][0],"far",line["far_joint_left_right"],
                  "live_U",line["terminal_owner_balance"]["live_owners"])
        shared=result["shared_terminal_mark"]
        print("shared two terminals",f"strongest={shared['strongest_only_terminal']}",
              f"positive residual={shared['remaining_mass_on_whole_Eu']}",
              f"fresh in both orders={[str(x['fresh_after_other_parent']) for x in shared['terminal_rows']]}")
        if args.check:
            print("byte-identical")
    else:
        print(text, end="")


if __name__ == "__main__":
    main()
