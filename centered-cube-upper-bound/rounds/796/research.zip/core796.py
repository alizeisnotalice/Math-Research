#!/usr/bin/env python3
"""Exact physical-source peeling and reversible-kernel diagnostic (one dimension)."""
import argparse
from fractions import Fraction as F
from itertools import product
import json
from pathlib import Path
import platform


SUPPORT = (F(-72), F(72))
PERIOD = F(1, 16)
HALF = PERIOD / 2
TRANSLATION = 10
START_RADIUS = F(64)
SHRINK = 32
DELTA = F(13, 32)
D = F(1)


def total(values):
    return sum(values, F(0))


def length(interval):
    return max(F(0), interval[1] - interval[0])


def intersect(a, b):
    return max(a[0], b[0]), min(a[1], b[1])


def contained(inner, outer):
    return outer[0] <= inner[0] <= inner[1] <= outer[1]


def translate(lo, hi):
    return F(TRANSLATION) + lo / F(32), F(TRANSLATION) + hi / F(32)


def center_radius(c, r):
    return c - r, c + r


def parent_and_owner(parent):
    center, radius = total(parent) / 2, length(parent) / 2
    return parent, center, radius, center_radius(center, radius / SHRINK)


def density_pieces(box, amplitude):
    lo, hi = intersect(box, SUPPORT)
    while lo < hi:
        slab = lo // HALF
        right = min(hi, (slab + 1) * HALF)
        density = 1 + amplitude if slab % 2 == 0 else 1 - amplitude
        yield lo, right, density
        lo = right


def mass(box, amplitude):
    lo, hi = intersect(box, SUPPORT)
    if hi <= lo:
        return F(0)

    def primitive(x):
        offset = x % PERIOD
        return x + amplitude * min(offset, PERIOD - offset)

    result = primitive(hi) - primitive(lo)
    assert result == total((b - a) * c for a, b, c in density_pieces(box, amplitude))
    return result


def real_separated_weight(first, second, amplitude):
    """Integrate both orientations of |y-z|>DELTA under the real product measure."""
    def ramp(left, right, cutoff):
        return (max(F(0), cutoff - left)**2 - max(F(0), cutoff - right)**2) / 2

    def forward(x0, x1, y0, y1):
        return ramp(x0, x1, y1 - DELTA) - ramp(x0, x1, y0 - DELTA)

    value = F(0)
    for (a, b, rho), (c, d, sigma) in product(density_pieces(first, amplitude),
                                            density_pieces(second, amplitude)):
        piece = forward(a, b, c, d) + forward(c, d, a, b)
        assert 0 <= piece <= (b - a) * (d - c)
        value += rho * sigma * piece
    return value


def original_route(starts, terms, preaccepted, amplitude):
    """One starting owner coordinate can physically reach every listed terminal."""
    starting = [parent_and_owner(center_radius(c, START_RADIUS)) for c in starts]
    all_owners = sorted(t[3] for t in starting + terms)
    assert all(x[1] < y[0] for x, y in zip(all_owners, all_owners[1:]))
    assert all(mass(t[0], amplitude) == length(t[0]) for t in starting + terms)
    owner_union_size = total(length(t[3]) for t in starting)
    weights = [q / owner_union_size for q in preaccepted]
    assert 0 < total(weights) <= 1 and all(w > 0 for w in weights)
    slots = []
    for parent, start, _, owner in starting:
        anchors = []
        for terminal, center, radius, new_owner in terms:
            eta = radius / START_RADIUS
            half_strip = F(1, 4)
            band = ((center - eta * (start + half_strip)) / (1 - eta),
                    (center - eta * (start - half_strip)) / (1 - eta))
            assert contained(band, intersect(parent, terminal))
            assert max(abs(y - T) for y, T in product(band, owner)) <= START_RADIUS
            assert mass(band, amplitude) > 0

            # At both endpoints of the starting owner there is still positive
            # anchor mass reaching the terminal owner. The clipped anchor
            # width is concave in T, so this suffices on the whole interval.
            anchor_end_masses = []
            for T in owner:
                preimage = tuple((x - eta * T) / (1 - eta) for x in new_owner)
                allowed = intersect(band, preimage)
                size = mass(allowed, amplitude)
                assert size > 0
                anchor_end_masses.append(size)
            anchors.append(dict(band=band, endpoint_anchor_masses=anchor_end_masses))
        slots.append(dict(center=start, parent=parent, owner=owner, anchor_choices=anchors))
    integrated = [total(length(t[3]) * w for t in starting) for w in weights]
    assert integrated == preaccepted
    return dict(starting_slots=slots, T_measure=owner_union_size,
                routes_at_each_T=weights, pointwise_reserved_probability=total(weights))


def peel(kernel, masses, threshold):
    active = list(range(len(masses)))

    def activity(vertices):
        return {i: total(kernel[i][j] * masses[j] for j in vertices) for i in vertices}

    def edge_mass(vertices, removed):
        return total(masses[i] * masses[j] * kernel[i][j] for i, j in product(vertices, repeat=2)
                     if i in removed or j in removed)

    starting_mass = edge_mass(active, set(active))
    stages = []
    removed_all = set()
    while active:
        row = activity(active)
        discard = {i for i in active if row[i] < threshold}
        if not discard:
            break
        removed = edge_mass(active, discard)
        overlap = edge_mass(sorted(discard), discard)
        dropped_source = total(masses[i] for i in discard)
        assert removed == 2 * total(row[i] * masses[i] for i in sorted(discard)) - overlap
        assert removed <= 2 * threshold * dropped_source
        stages.append(dict(rows=[[i, row[i]] for i in active], discard=sorted(discard),
                           loss=removed, drop_source=dropped_source, cap=2 * threshold * dropped_source))
        active = [i for i in active if i not in discard]
        removed_all |= discard
    remaining = edge_mass(active, set(active))
    loss = total(s["loss"] for s in stages)
    assert loss == starting_mass - remaining
    personal_cap = 2 * threshold * total(masses[i] for i in sorted(removed_all))
    full_cap = 2 * threshold * total(masses)
    assert loss <= personal_cap <= full_cap
    return dict(threshold=threshold, rounds=stages, active=active, final_rows=activity(active),
                original_mass=starting_mass, loss=loss, final_mass=remaining,
                spent_source_cap=personal_cap, full_good_source_cap=full_cap)


def transitions(k, terms, masses, rows, probabilities, terminal_m, Z):
    active = rows["active"]
    h = rows["final_rows"]
    threshold, nu = rows["threshold"], rows["final_mass"]
    zmin = min(Z)
    assert active and all(h[i] >= threshold > 0 for i in active)
    marginal = {i: masses[i] * h[i] / nu for i in active}
    P = {(i, j): k[i][j] * masses[j] / h[i] for i, j in product(active, repeat=2)}
    P_label = {(t, i, j): term[i][j] * masses[j] / h[i]
               for t, term in enumerate(terms) for i, j in product(active, repeat=2)}
    assert total(marginal.values()) == 1
    for i in active:
        assert total(P[i, j] for j in active) == 1
        assert total(marginal[j] * P[j, i] for j in active) == marginal[i]
    measured_bound = F(0)
    for i, j in P:
        pointwise_cap = total(a / D**2 for t, a in enumerate(probabilities) if terms[t][i][j] > 0)
        bin_cap = pointwise_cap * masses[j] / (threshold * zmin)
        assert 0 <= P[i, j] <= k[i][j] * masses[j] / threshold <= bin_cap
        assert marginal[i] * P[i, j] == marginal[j] * P[j, i]
        assert P[i, j] == total(P_label[t, i, j] for t in range(len(terms)))
        for t, m in enumerate(terminal_m):
            if (c := P_label[t, i, j]):
                assert c <= probabilities[t] * masses[j] / (Z[t] * m**2 * threshold)
        if bin_cap:
            measured_bound = max(measured_bound, P[i, j] / bin_cap)
    P2 = {}
    for i, j in P:
        direct = total(P[i, o] * P[o, j] for o in active)
        reverse = masses[i] * masses[j] / nu * total(
            masses[o] * k[i][o] * k[j][o] / h[o] for o in active
        )
        assert marginal[i] * direct == reverse
        P2[i, j] = direct
    for i in active:
        assert total(P2[i, j] for j in active) == 1
        assert total(marginal[j] * P2[j, i] for j in active) == marginal[i]

    repetition, sample = F(0), None
    for t in range(len(terms)):
        for i, o, j in product(active, repeat=3):
            term = marginal[i] * P_label[t, i, o] * P_label[t, o, j]
            repetition += term
            if term and i != j and sample is None:
                sample = dict(start=i, shared=o, end=j, terminal=t, probability=term)
    repeated_by_middle = total(marginal[o] * total(P_label[t, o, i] for i in active)**2
                               for t in range(len(terms)) for o in active)
    assert 0 < repetition == repeated_by_middle <= 1
    assert sample is not None
    return dict(marginal=marginal, one=[[P[i, j] for j in active] for i in active],
                two=[[P2[i, j] for j in active] for i in active],
                max_fraction_of_bin_cap=measured_bound,
                same_terminal_two_step_probability=repetition,
                distinct_endpoints_same_terminal_witness=sample)



def layered_peel(term_k, masses, membership, terminal_m, Z, paid, threshold, kappa):
    """Peel physical sources, terminal/source incidences, and physical terminals."""
    cells = set(range(len(masses)))
    terminals = set(range(len(paid)))
    incidence = [set(i for i in cells if member[i]) for member in membership]
    source_losses = [F(0)] * len(paid)
    incidence_losses = [F(0)] * len(paid)
    dropped_terminals, history, positive_incidence = {}, [], []
    initial_domain = total(masses)

    def energy(t, keep):
        return total(term_k[t][i][j] * masses[i] * masses[j]
                     for i, j in product(sorted(keep), repeat=2))

    def companion(t, i):
        return total(masses[j] for j in incidence[t] if term_k[t][i][j]) / terminal_m[t]

    while cells and terminals:
        current_h = {i: total(term_k[t][i][j] * masses[j]
                              for t in terminals if i in incidence[t] for j in incidence[t])
                     for i in cells}
        source_drop = {i for i in cells if current_h[i] < threshold}
        drop_source_charge = F(0)
        for t in sorted(terminals):
            old = energy(t, incidence[t])
            incidence[t] -= source_drop
            charge = old - energy(t, incidence[t])
            source_losses[t] += charge
            drop_source_charge += charge
        assert drop_source_charge <= 2 * threshold * total(masses[i] for i in source_drop)
        cells -= source_drop

        incidence_drop = []
        incidence_charge = F(0)
        for t in sorted(terminals):
            strengths = [(i, companion(t, i)) for i in sorted(incidence[t])]
            drops = [(i, amount) for i, amount in strengths if amount < kappa * Z[t]]
            drop_ti = {i for i, _ in drops}
            if not drop_ti:
                continue
            old = energy(t, incidence[t])
            incidence[t] -= drop_ti
            charge = old - energy(t, incidence[t])
            assert charge <= 2 * kappa * paid[t] * total(masses[i] for i in drop_ti) / terminal_m[t]
            incidence_losses[t] += charge
            assert incidence_losses[t] <= 2 * kappa * paid[t]
            incidence_charge += charge
            incidence_drop += [(t, i, amount) for i, amount in drops]
            positive_incidence += [(t, i, amount, kappa * Z[t]) for i, amount in drops if amount]

        terminal_drop = []
        for t in sorted(terminals):
            left = energy(t, incidence[t])
            q = left / paid[t]
            if q < F(1, 2):
                assert (1 - q) * paid[t] == source_losses[t] + incidence_losses[t]
                dropped_terminals[t] = dict(q=q, retained_before_whole_drop=left,
                                            original_mass=paid[t], original_source_loss=source_losses[t],
                                            incidence_loss=incidence_losses[t])
                terminal_drop.append(t)
        terminals -= set(terminal_drop)
        if not (source_drop or incidence_drop or terminal_drop):
            break
        history.append(dict(source_drop=sorted(source_drop), source_edge_loss=drop_source_charge,
                            incidence_drop=incidence_drop, incidence_edge_loss=incidence_charge,
                            terminal_drop=terminal_drop))

    dropped_original = total(paid[t] for t in dropped_terminals)
    possible_source_charge = 2 * threshold * initial_domain
    source_charge_for_dropped = total(source_losses[t] for t in dropped_terminals)
    assert (F(1, 2) - 2 * kappa) * dropped_original <= source_charge_for_dropped
    assert source_charge_for_dropped <= total(source_losses) <= possible_source_charge
    whole_terminal_cap = possible_source_charge / (F(1, 2) - 2 * kappa)
    assert dropped_original <= whole_terminal_cap

    q = {t: energy(t, incidence[t]) / paid[t] for t in sorted(terminals)}
    assert all(F(1, 2) <= keep <= 1 for keep in q.values())
    assert all(companion(t, i) >= kappa * Z[t] for t in terminals for i in incidence[t])
    h = {i: total(term_k[t][i][j] * masses[j]
                  for t in terminals if i in incidence[t] for j in incidence[t]) for i in sorted(cells)}
    h_scaled = {i: total(term_k[t][i][j] * masses[j] / q[t]
                         for t in terminals if i in incidence[t] for j in incidence[t])
                for i in sorted(cells)}
    assert all(threshold <= h[i] <= h_scaled[i] <= 2 * h[i] for i in cells)
    restored = {t: energy(t, incidence[t]) / q[t] for t in sorted(terminals)}
    assert restored == {t: paid[t] for t in sorted(terminals)}
    assert total(h_scaled[i] * masses[i] for i in cells) == total(restored.values())
    whole_terminal_remaining_loss = total(x["retained_before_whole_drop"]
                                          for x in dropped_terminals.values())
    assert total(paid) == (total(source_losses) + total(incidence_losses)
                          + whole_terminal_remaining_loss + total(energy(t, incidence[t]) for t in terminals))
    live_terms = sorted(terminals)
    reweighted_terms = [[[term_k[t][i][j] / q[t] if i in incidence[t] and j in incidence[t]
                           else F(0) for j in range(len(masses))] for i in range(len(masses))]
                        for t in live_terms]
    full_kernel = [[total(term[i][j] for term in reweighted_terms) for j in range(len(masses))]
                   for i in range(len(masses))]
    reweighted = transitions(full_kernel, reweighted_terms, masses,
                             dict(active=sorted(cells), final_rows=h_scaled,
                                  threshold=threshold, final_mass=total(restored.values())),
                             [paid[t] for t in live_terms], [terminal_m[t] for t in live_terms],
                             [q[t] * Z[t] for t in live_terms])
    old_cap_fraction = F(0)
    for i, j in product(sorted(cells), repeat=2):
        if full_kernel[i][j]:
            old_kernel = total(term[i][j] for term in term_k)
            relative_to_old_cap = full_kernel[i][j] / h_scaled[i] / (2 * old_kernel / threshold)
            assert relative_to_old_cap <= 1
            old_cap_fraction = max(old_cap_fraction, relative_to_old_cap)
    return dict(kappa=kappa, good_support=initial_domain, rounds=history,
                strict_positive_incidence_examples=positive_incidence, whole_dropped=dropped_terminals,
                whole_dropped_original_mass=dropped_original, whole_terminal_cap=whole_terminal_cap,
                global_source_charge=total(source_losses), incidence_charge=total(incidence_losses),
                live_source=sorted(cells), live_incidence={t: sorted(incidence[t]) for t in sorted(terminals)},
                live_terminal_fraction=q, min_final_h=min(h.values(), default=None),
                min_reweighted_h=min(h_scaled.values(), default=None), recovered_original_mass=restored,
                reweighted_max_fraction_of_old_2k_cap=old_cap_fraction,
                reweighted_same_terminal_two_step_probability=reweighted["same_terminal_two_step_probability"])


def experiment(name, amplitude, starts, parent_units, coefficients, good_units, threshold):
    good = [translate(lo, hi) for lo, hi in good_units]
    terms = [parent_and_owner(translate(lo, hi)) for lo, hi in parent_units]
    m = [length(a[0]) for a in terms]
    assert all(D <= x < 2 * D for x in m)
    aperture = [mass(cell, amplitude) for cell in good]
    assert all(x > 0 for x in aperture)
    assert all(left[1] <= right[0] for left, right in zip(good, good[1:]))
    labels = list(range(len(good)))
    membership = [[contained(cell, parent) for cell in good] for parent, *_ in terms]
    for t, (parent, *_) in enumerate(terms):
        assert mass(parent, amplitude) == m[t]
        for i, cell in enumerate(good):
            assert mass(intersect(cell, parent), amplitude) == (aperture[i] if membership[t][i] else 0)
    # Integer ordering is material: cells are disjoint except for null endpoints.
    is_far, true_area = {}, {}
    for i, j in product(labels, repeat=2):
        low, high = sorted((i, j))
        is_far[i, j] = good[high][0] - good[low][1] > DELTA
        true_area[i, j] = real_separated_weight(good[i], good[j], amplitude)
        assert true_area[i, j] == is_far[i, j] * aperture[i] * aperture[j]

    before = [c * d**2 for c, d in zip(coefficients, m)]
    route = original_route(starts, terms, before, amplitude)
    k = [[F(0) for _ in good] for _ in good]
    term_k, acceptance, paid = [], [], []
    for t, m_t in enumerate(m):
        pair = {(i, j) for i, j in is_far if is_far[i, j] and membership[t][i] and membership[t][j]}
        discrete = total(aperture[i] * aperture[j] for i, j in sorted(pair))
        continuous = total(true_area[i, j] for i, j in true_area if membership[t][i] and membership[t][j])
        assert discrete == continuous > 0
        Z = discrete / m_t**2
        assert 0 < Z < 1
        acceptance.append(Z)
        a_t = before[t] * Z
        paid.append(a_t)
        density = a_t / (Z * m_t**2)
        assert density == coefficients[t]
        term = [[density if (i, j) in pair else F(0) for j in labels] for i in labels]
        root_projection = route["T_measure"] * route["routes_at_each_T"][t] * continuous / m_t**2
        assert a_t == root_projection == total(term[i][j] * aperture[i] * aperture[j] for i, j in pair)
        term_k.append(term)
        for i, j in pair:
            k[i][j] += density
    assert all(k[i][j] == k[j][i] for i, j in is_far)
    h = [total(c * mu for c, mu in zip(row, aperture)) for row in k]
    source_projection = [total(coefficients[t] * true_area[i, j] / aperture[i]
                               for t in range(len(terms)) for j in labels
                               if membership[t][i] and membership[t][j]) for i in labels]
    assert h == source_projection and total(x * mu for x, mu in zip(h, aperture)) == total(paid)
    wrong_no_Z = total(a * z for a, z in zip(paid, acceptance))
    assert 0 < wrong_no_Z < total(paid)

    rows = peel(k, aperture, threshold)
    assert rows["original_mass"] == total(paid)
    core = rows["active"]
    degree = [sum(k[i][j] > 0 for j in core) for i in core]
    assert len(core) >= 4 and min(degree) >= 2
    probes = transitions(k, term_k, aperture, rows, paid, m, acceptance)
    cleanup = layered_peel(term_k, aperture, membership, m, acceptance, paid, threshold, F(1, 8))
    assert cleanup["live_terminal_fraction"]
    data = dict(stage=name, amplitude=amplitude, boxes=good, source_masses=aperture,
                good_source_mass=total(aperture), terminal_parent=[a[0] for a in terms],
                terminal_owners=[a[3] for a in terms], binary_bin=[D, 2 * D],
                terminal_m=m, density_coefficients=coefficients, preaccepted_mass=before,
                real_route=route, Z=acceptance, accepted_projection=paid,
                wrong_dropping_Z_total=wrong_no_Z, k=k, original_h=h, peeling=rows,
                core_graph_degrees=degree, transition=probes, layered_cleanup=cleanup)
    if name == "pressure":
        assert [w["discard"] for w in rows["rounds"]] == [[5], [2]]
        assert rows["loss"] == F(39, 4096) and rows["final_mass"] == F(9, 256)
        equality_example = peel(k, aperture, F(7, 128))
        assert [w["discard"] for w in equality_example["rounds"]] == [[5]]
        assert equality_example["final_rows"][2] == equality_example["threshold"]
        data["threshold_equality_retained"] = equality_example
        assert list(cleanup["whole_dropped"]) == [2]
    if name == "expanded":
        assert len(set(m)) == 2 and len(rows["rounds"]) == 2
    return data


def suite():
    base = [(4, 6), (10, 12), (16, 17), (28, 29), (31, 32), (40, 41)]
    expanded = [(F(4), F(9, 2)), (F(9, 2), 6), *base[1:3],
                (28, F(57, 2)), (F(57, 2), 29), *base[4:]]
    parents = [(0, 32), (8, 40), (16, 48), (8, 44)]
    rates = [F(2), F(1, 2), F(1), F(1, 32)]
    threshold = F(1, 16)
    stages = [
        experiment("initial", F(1, 4), [F(0)], parents[:2], rates[:2], base, threshold),
        experiment("pressure", F(1, 2), [F(0)], parents[:3], rates[:3], base, threshold),
        experiment("expanded", F(3, 4), [F(-5), F(0), F(5)], parents, rates, expanded, threshold),
    ]
    # A narrow final cell remains a genuine positive source. Two terminal
    # incidences lose it as a partner before the global source itself is cut.
    incidence_stress = [*base[:3], (20, 22), *base[3:5], (40, F(40) + F(1, 512))]
    control = experiment("positive_incidence_control", F(1, 2), [F(0)], parents, rates,
                         incidence_stress, threshold)
    cleanup = control["layered_cleanup"]
    assert cleanup["strict_positive_incidence_examples"] and cleanup["whole_dropped"]
    assert cleanup["live_terminal_fraction"]
    return stages, control


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    outputs = parser.add_mutually_exclusive_group()
    outputs.add_argument("--output", type=Path)
    outputs.add_argument("--check", type=Path)
    args = parser.parse_args()
    stages, control = suite()
    certificate = dict(
        runtime=dict(python=platform.python_version(), architecture=platform.machine()),
        precision="standard-library Fraction, no approximation", command="python -B core796.py --check core796.json",
        input=dict(support=SUPPORT, period=PERIOD, density="1±amplitude on alternating half periods",
                   parent_reference="all original parents have true mu(A)=length(A)",
                   rho="source pair initially independently drawn from actual mu restricted to terminal / m_t",
                   normalization="retained mass a_t = actual pre-filter route mass times exact acceptance Z_t",
                   delta=DELTA, gate="both prices in common good cells and distance strictly above delta",
                   scope="true one-dimensional parent, owner, source, route and accepted pair; diagnostic finite model of the geometric gates"),
        stages=stages, additional_positive_incidence_control=control,
    )
    data = json.dumps(certificate, indent=2, sort_keys=True, default=str) + "\n"
    if args.output:
        args.output.write_text(data)
    if args.check:
        assert args.check.read_text() == data
    if not (args.output or args.check):
        print(data, end="")
    else:
        for stage in stages:
            row = stage["peeling"]
            discarded = [x["discard"] for x in row["rounds"]]
            print(stage["stage"], f"Z={list(map(str, stage['Z']))}", f"before={row['original_mass']}",
                  f"rounds={discarded}", f"loss={row['loss']}", f"core={row['final_mass']}",
                  f"repeat={stage['transition']['same_terminal_two_step_probability']}")
        cleanup = control["layered_cleanup"]
        print("positive incidence control", f"positive={len(cleanup['strict_positive_incidence_examples'])}",
              f"dropped={list(cleanup['whole_dropped'])}", f"live={list(cleanup['live_terminal_fraction'])}")
        if args.check:
            print("byte-identical")


if __name__ == "__main__":
    main()
