#!/usr/bin/env python3
"""Exact finite diagnostic for one source self-coupling across reachable terminals."""
import argparse
from fractions import Fraction as F
from hashlib import sha256
import importlib.util
from itertools import product
import json
from pathlib import Path
import platform
import sys


SOLVER_SHA = "72847cc23d843b5025ff3bc6a4b8b09350f6f76f1b63a52c152fc2d9a93a27fd"
SUPPORT = (F(-72), F(72))
LOCAL = (F(8), F(12))
PERIOD = F(1, 4)
A = 32
START_RADIUS = F(64)


def length(interval):
    return max(F(0), interval[1] - interval[0])


def intersect(first, second):
    return max(first[0], second[0]), min(first[1], second[1])


def center_radius(center, radius):
    return center - radius, center + radius


def midpoint(interval):
    return sum(interval) / 2


def inside(x, interval):
    return interval[0] <= x <= interval[1]


def assert_disjoint(intervals):
    for left, right in zip(sorted(intervals), sorted(intervals)[1:]):
        assert left[1] < right[0]


def area(interval, amplitude):
    """Mass for alternating 1±amplitude half-periods on SUPPORT."""
    interval = intersect(interval, SUPPORT)
    if not length(interval):
        return F(0)

    def primitive(x):
        remainder = x % PERIOD
        return x + amplitude * min(remainder, PERIOD - remainder)

    return primitive(interval[1]) - primitive(interval[0])


def union_length(intervals):
    """Independent interval union by merging components, rather than cell enumeration."""
    components = []
    for left, right in sorted(intervals):
        if right <= left:
            continue
        if components and left <= components[-1][1]:
            components[-1][1] = max(components[-1][1], right)
        else:
            components.append([left, right])
    return sum(map(length, components), F(0))


def adjacent(breaks):
    ordered = sorted(set(breaks))
    return list(zip(ordered, ordered[1:]))


def shadows(start, terminals, offsets, amplitude):
    start_owner = center_radius(start, START_RADIUS / A)
    start_parent = center_radius(start, START_RADIUS)
    bands, projected = [], []
    for (center, radius), (offset_lo, offset_hi) in zip(terminals, offsets):
        rho = radius / START_RADIUS
        left, right = start + offset_lo, start + offset_hi
        band = ((center - rho * right) / (1 - rho),
                (center - rho * left) / (1 - rho))
        owner = center_radius(center, radius / A)
        shadow = intersect(start_owner, (left - START_RADIUS / A, right + START_RADIUS / A))
        parent_pair = intersect(start_parent, center_radius(center, radius))
        assert intersect(band, parent_pair) == band
        assert max(abs(y - T) for y, T in product(band, start_owner)) <= START_RADIUS
        assert area(band, amplitude) > 0
        assert length(shadow) > 0
        assert intersect(shadow, center_radius(center, START_RADIUS - radius + radius / A)) == shadow
        bands.append((band, rho, owner))
        projected.append(shadow)
    return bands, projected


def real_receiving(starts, terminals, offsets, amplitude, rule):
    receiving, root_info = [], []
    for start, bands_for_start in zip(starts, offsets):
        start_owner = center_radius(start, START_RADIUS / A)
        bands, projected = shadows(start, terminals, bands_for_start, amplitude)
        breaks = [*start_owner, *(e for interval in projected for e in interval)]
        root_id = len(root_info)
        for cell in adjacent(breaks):
            probe = midpoint(cell)
            active = tuple(i for i, interval in enumerate(projected) if inside(probe, interval))
            physical = []
            for i, (band, rho, owner) in enumerate(bands):
                feasible = tuple((e - rho * probe) / (1 - rho) for e in owner)
                feasible = intersect(feasible, band)
                if length(feasible):
                    y = midpoint(feasible)
                    assert inside(y + rho * (probe - y), owner)
                    assert area(feasible, amplitude) > 0
                    physical.append(i)
            assert tuple(physical) == active
            if rule == "priority-first":
                weight = {i: F(1, 16) for i in active}
                if 0 in weight:
                    weight[0] = 1 - F(len(active) - 1, 16)
            else:
                weight = {i: F(1, len(active)) for i in active}
            receiving.append((root_id, cell, active, weight))
        root_info.append(dict(center=start, radius=START_RADIUS, owner=start_owner,
                              anchor_bands=[band for band, _, _ in bands], shadows=projected))
    return receiving, root_info


def inspect_case(name, amplitude, starts, terminals, offsets, rule, solve):
    parent_boxes = [center_radius(c, s) for c, s in terminals]
    terminal_owner = [center_radius(c, s / A) for c, s in terminals]
    start_parents = [center_radius(c, START_RADIUS) for c in starts]
    start_owners = [center_radius(c, START_RADIUS / A) for c in starts]
    all_parents = start_parents + parent_boxes
    assert_disjoint(start_owners + terminal_owner)
    assert all(area(p, amplitude) == length(p) for p in all_parents)
    m = list(map(length, parent_boxes))
    boxes = adjacent([*SUPPORT, *LOCAL, *(e for interval in parent_boxes for e in interval)])
    masses = [area(b, amplitude) for b in boxes]
    memberships = [frozenset(i for i, p in enumerate(parent_boxes) if inside(midpoint(b), p))
                   for b in boxes]
    assert all(x > 0 for x in masses)
    assert [sum(x for b, x in zip(memberships, masses) if i in b) for i in range(len(m))] == m
    S = sum(masses)
    S_active = sum(x for b, x in zip(memberships, masses) if b)
    assert S == area(SUPPORT, amplitude)

    receiving, roots = real_receiving(starts, terminals, offsets, amplitude, rule)
    C_real = max(sum(weights.values(), F(0)) for _, _, _, weights in receiving)
    root_fee = [sum(length(cell) * weight.get(t, 0) for _, cell, _, weight in receiving)
                for t in range(len(m))]
    cover_one = [
        sum(length(cell) for _, cell, active, _ in receiving if t in active) / m[t]
        for t in range(len(m))
    ]
    overlap_old_receiving = sum(length(cell) for _, cell, active, _ in receiving if len(active) > 1)
    assert overlap_old_receiving > 0 and all(w > 0 for w in root_fee)
    assert C_real <= 1

    indices = list(range(len(boxes)))
    pair = {}
    for i, j in product(indices, repeat=2):
        common = memberships[i] & memberships[j]
        D, raw = F(0), F(0)
        for _, cell, active, weight in receiving:
            D += length(cell) * max((1 / m[t] for t in common.intersection(active)), default=F(0))
            raw += length(cell) * sum((weight.get(t, 0) / m[t] for t in common), F(0))

        independent = F(0)
        for root in roots:
            covered = []
            for t in sorted(common, key=lambda u: (m[u], u)):
                larger = covered + [root["shadows"][t]]
                independent += (union_length(larger) - union_length(covered)) / m[t]
                covered = larger
        assert D == independent
        alpha = min(F(1), 1 / D) if D else F(1)
        assert raw <= C_real * D and alpha * raw <= C_real
        naive_sum = sum((cover_one[t] for t in common), F(0))
        assert D <= naive_sum
        pair[i, j] = dict(D=D, alpha=alpha, reward=alpha * raw, naive_sum=naive_sum)
    assert any(w["naive_sum"] > w["D"] > 0 for w in pair.values())

    reward = [[pair[i, j]["reward"] for j in indices] for i in indices]
    opt, best_plan, dual_x, dual_y, augmentations = solve(masses, masses, reward)
    diagonal = {(i, i): x for i, x in enumerate(masses)}
    product_plan = {(i, j): masses[i] * masses[j] / S for i, j in pair}
    local = [i for i in indices if inside(midpoint(boxes[i]), LOCAL)]
    local_mass = sum(masses[i] for i in local)
    local_mix = {(i, i): masses[i] for i in indices if i not in local}
    local_mix.update({(i, j): masses[i] * masses[j] / local_mass for i, j in product(local, repeat=2)})

    def pair_payment(plan):
        return sum(w * reward[i][j] for (i, j), w in plan.items())

    simple_switch, selected_pair = diagonal, None
    for i, j in pair:
        if i >= j:
            continue
        flow = min(masses[i], masses[j])
        switched = diagonal.copy()
        switched[i, i] -= flow
        switched[j, j] -= flow
        switched[i, j] = switched[j, i] = flow
        if pair_payment(switched) > pair_payment(simple_switch):
            simple_switch, selected_pair = switched, (i, j)

    def analyze(plan):
        assert all(w >= 0 for w in plan.values())
        assert all(sum(plan.get((i, j), 0) for j in indices) == masses[i] for i in indices)
        assert all(sum(plan.get((i, j), 0) for i in indices) == masses[j] for j in indices)
        uncut = [F(0)] * len(m)
        clipped = [F(0)] * len(m)
        for (i, j), w in plan.items():
            for t in memberships[i] & memberships[j]:
                uncut[t] += w / m[t]
                clipped[t] += w * pair[i, j]["alpha"] / m[t]
        assert all(0 <= q <= p <= 1 for p, q in zip(uncut, clipped))
        through_terminals = sum(r * c for r, c in zip(root_fee, clipped))
        through_receiving = sum(length(cell) * w * clipped[t]
                                for _, cell, _, weights in receiving for t, w in weights.items())
        through_sources = pair_payment(plan)
        assert through_terminals == through_receiving == through_sources
        assert through_sources <= C_real * S_active <= C_real * S
        independent_by_terminal = sum(r * p * min(F(1), 1 / d)
                                      for r, p, d in zip(root_fee, uncut, cover_one))
        assert independent_by_terminal >= through_terminals
        return dict(fee=through_sources, p=clipped, raw_terminal_probability=uncut,
                    off_diagonal_mass=sum(w for (i, j), w in plan.items() if i != j),
                    paid_if_reusing_shadow_budget_independently_per_terminal=independent_by_terminal,
                    plan=[(i, j, w) for (i, j), w in sorted(plan.items()) if w])

    plans = {tag: analyze(plan) for tag, plan in
             (("diagonal", diagonal), ("product", product_plan),
              ("product_within_local_window", local_mix), ("best_single_swap", simple_switch),
              ("optimal_common", best_plan))}
    assert plans["optimal_common"]["fee"] == opt
    assert opt == sum(x * y for x, y in zip(masses, dual_x)) + sum(x * y for x, y in zip(masses, dual_y))
    assert all(dual_x[i] + dual_y[j] >= reward[i][j] for i, j in pair)
    assert all(dual_x[i] + dual_y[j] == reward[i][j] for i, j in best_plan)
    assert opt >= max(v["fee"] for v in plans.values())

    if name == "initial":
        diag, switch = plans["diagonal"], plans["best_single_swap"]
        assert root_fee == [F(53, 16), F(7, 32)]
        assert diag["p"] == [F(15, 56), F(15, 56)]
        assert switch["p"] == [F(2, 7), F(1, 7)]
        assert switch["fee"] - diag["fee"] == F(57, 1792)
        assert switch["raw_terminal_probability"] == [F(1), F(1, 2)]

    return dict(name=name, amplitude=amplitude, term_parents=parent_boxes,
                term_owners=terminal_owner, terminal_m=m, true_route_rule=rule,
                source_intersections=[dict(terminal_pair=(i, j), Lebesgue=length(inter),
                                           mu=area(inter, amplitude))
                                      for i, first in enumerate(parent_boxes)
                                      for j, second in enumerate(parent_boxes) if i < j
                                      for inter in [intersect(first, second)]],
                roots=roots, start_parents=start_parents, source_mass=S, active_source_mass=S_active,
                source_cells=[dict(interval=b, mass=x, terminals=sorted(member))
                              for b, x, member in zip(boxes, masses, memberships)],
                receiving_cells=[dict(root=k, interval=c, act=act, weights=w, normalized_y_densities=
                                      "mu restricted to each feasible anchor interval, then normalized")
                                 for k, c, act, w in receiving],
                actual_start_overlap=overlap_old_receiving, actual_wire_mass=root_fee,
                real_route_cap=C_real, combined_payment_cap=C_real * S,
                active_payment_cap=C_real * S_active, terminal_private_shadow_strength=cover_one,
                source_pair_test=[dict(cell_pair=(i, j), **w) for (i, j), w in pair.items()
                                  if i <= j and w["D"]],
                positive_single_swap_cells=selected_pair, objective=plans,
                optimal_dual=dict(first=dual_x, second=dual_y, augmentations=augmentations),
                gain_opt_minus_diagonal=opt - plans["diagonal"]["fee"])


def run(solve):
    v0, v1, v2 = (F(39, 4), F(1, 2)), (F(41, 4), F(1, 2)), (F(43, 4), F(1, 2))
    v1b = F(163, 16), F(3, 4)
    b0, b1, b2 = (F(1, 2), F(3, 4)), (F(-3, 4), F(-1, 2)), (F(-1, 8), F(1, 8))
    c0, c1, c2 = (F(1, 4), F(1, 2)), (F(-1), F(-3, 4)), (F(1, 2), F(1))
    return [
        inspect_case("initial", F(1, 2), [F(0)], [v0, v1], [(b0, b1)], "priority-first", solve),
        inspect_case("reuse_stress", F(1, 4), [F(0), F(5)], [v0, v1b],
                     [(b0, b1), (c0, c1)], "priority-first", solve),
        inspect_case("expanded", F(3, 4), [F(-5), F(0), F(5)], [v0, v1b, v2],
                     [(b0, b1, b2), (c0, c1, c2), (b1, b2, b0)], "balanced", solve),
    ]


def import_solver(directory):
    code = directory / "common791.py"
    assert sha256(code.read_bytes()).hexdigest() == SOLVER_SHA
    spec = importlib.util.spec_from_file_location("common791", code)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module.max_transport


def replay_certificates(path):
    """Recompute the experiment using only the recorded primal/dual solutions."""
    stages = iter(json.loads(path.read_text())["stages"])

    def solve(rows, cols, reward):
        stage = next(stages)
        result = stage["objective"]["optimal_common"]
        dual = stage["optimal_dual"]
        plan = {(i, j): F(value) for i, j, value in result["plan"]}
        left, right = [F(x) for x in dual["first"]], [F(x) for x in dual["second"]]
        assert len(left) == len(rows) and len(right) == len(cols)
        value = sum(flow * reward[i][j] for (i, j), flow in plan.items())
        assert value == F(result["fee"])
        return value, plan, left, right, dual["augmentations"]

    return solve


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--transport-dir", type=Path,
                        help="reoptimize using the archived exact common791.py solver")
    action = parser.add_mutually_exclusive_group()
    action.add_argument("--output", type=Path)
    action.add_argument("--check", type=Path)
    args = parser.parse_args()
    if args.check and args.transport_dir is None:
        solve = replay_certificates(args.check)
    else:
        solve = import_solver(args.transport_dir or Path(__file__).resolve().parent)
    records = run(solve)
    data = dict(
        precision="exact Fraction, including primal/dual equality; no simulation",
        runtime=dict(python=platform.python_version(), implementation=platform.python_implementation(),
                     architecture=platform.machine()),
        command="python -B coupling796.py --check coupling796.json",
        reoptimization="python -B coupling796.py --transport-dir path-containing-common791.py --output coupling796.json",
        unchanged_dependency_sha256={"common791.py": SOLVER_SHA},
        inputs=dict(source_support=SUPPORT, local_window=LOCAL, half_period=PERIOD / 2,
                    first_half_density="1+amplitude", second_half_density="1-amplitude",
                    source_measure="actual original mu, unchanged across start and terminal parents",
                    owners="all Q(center, radius/32) pairwise disjoint",
                    receiving_measure="Lebesgue on the union of starting owners",
                    route="actual affine contraction conditional on a positive anchor interval",
                    enforced="finite physical parent/owner, measure, affine reachability and shared budget",
                    scope="one-dimensional finite diagnostic routing with fixed positive weights; full peak mask and near-extreme conditions not modeled"),
        stages=records,
    )
    text = json.dumps(data, indent=2, sort_keys=True, default=str) + "\n"
    if args.check:
        assert args.check.read_text() == text
    if args.output:
        args.output.write_text(text)
    if args.check or args.output:
        for row in records:
            values = {k: v["fee"] for k, v in row["objective"].items()}
            print(row["name"], *(f"{k}={v}" for k, v in values.items()),
                  f"gain={row['gain_opt_minus_diagonal']}")
        if args.check:
            print("byte-identical")
    else:
        print(text, end="")


if __name__ == "__main__":
    main()
