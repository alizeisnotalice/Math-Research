# 第118轮：因果连续项的终端薄尺度预算

日期：2026-10-14。一般中心立方体极大算子的 `n^(1/2+o(1))` 一致弱型上界仍未闭合。

本轮沿第117轮归一化来源的连续变化公式，保留原硬来源、全部历史门和接收点的唯一比例带。得到一个适用于全部实际输入的局部预算：只累计接收尺度 g 之前对数长度不超过 u/n 的连续正变化，其费用不超过 `u T_small/4≤uX`。计入 R116 的系数2与外层 `Λ=128/119` 后，该项的全局费用至多 `2ΛuX`；选择 `u≤119ε/256` 可支付新增 εX。这不抵销任何旧误差费。

这是一段真实连续项的部分付款，不是一般根阶来源预算，也没有证明这段尺度占总交通的固定比例。远时连续项、每个比例带的初始项、跳跃接收费用和低 pe 支全部保留。作者稿的准确回代式 CJ11 展示这些缺口；CJ12 的乘法吸收是另一种记账方式，不能与 CJ11 同时获益。

为继续处理远时，本轮保留了带符号的协方差及坏/非坏来源对积分。非坏来源必须再分为最终存活的 good 来源和未来被删除的来源；只有前者有 good 核门。它们的双来源密度保留 e_t 的平方分母，并与原硬来源和真实勒贝格接收测度共同积分。该表示和加权 future 容量目前都没有取得新付款，不能以余项改名代替估计。

独立审查先检查命题，再审作者稿，并修正了非坏来源分类及标量例必须取 t=g 的范围。标量压力例只说明标量 FIRST 预算不足以直接推断点态根阶协方差；不是原 FULL 输入反例，也不否定真实几何积分路线。

数值核验只使用固定的两原子抽象过程、精确有理运算和解析对数包围，分基础、压力、扩大参数三个阶段。代理接收费不构成真实 FULL 实现证书。实际执行与重放状态以后文执行记录为准；一般解析命题与有限数值证据分开记录。只保留必要文本与复现材料，不编译 PDF。

# R118：因果连续项的终端薄尺度付款与远时容量接口

**状态：终端薄尺度预算命题已通过独立筛查（`near_statement_audit.md`）；本作者全文待独审，远时连续项未闭合。** 本稿未修改 R117，也没有把因果表示、signed covariance 恒等式或固定参数数值当作新增付款。低 pe、所有比例带初始项及跳跃项仍需另行支付。

## 1. 准确交通和因果分解

沿 R117 JG1–JG18，固定原种子 ω、不交叶 V、来源 y 及比例带 j。记
\[
 \mu_t=1_{Z_t}w_t\nu_V,\quad e_t=\mu_t(\mathbb R^n),
 \quad\Pi_t=\mu_t/e_t,
 \quad k_t(z')=\#\{i:bC(|y_i-z'_i|/b)<c_jt\},
 \quad m_t=\int k_t\,d\Pi_t.
 \tag{CJ1}
\]
所有定义限于原 heavy 尺度区间 I_{j,V,y}。实际接收尺度为 g(x)，其比例带 j(x) 唯一；原 R114 heavy 门保证 g(x)∈I_{j(x),V,y}。原实际 FIRST、原 hard 捕获、CP/GP/deep、失败币、种子、原小父上限及 R117 已核 CS/softtop 删除门全部继承。第三来源 z′ 仍不继承原 z 的 hard 捕获和历史门。

令 d𝒯_V(ω,x,y,z) 为 R115–R116 的原实际非负交通，RN 为
\[
 q^{-1}P_{s(x),L(x)}(x-y)h_{R(x)}(x-z)a_\omega(x,y,z)
 \,dx\,d\beta_V(y)d\nu_V(z).
 \tag{CJ2}
\]
这里 a_ω 携带所有原门，不是可自由生成 FULL 的任意新掩码。定义
\[
 d\mathcal T_{j,V}=1_{\{j(x)=j\}}d\mathcal T_V,
 \quad T_{\rm small}=\mathbb E\sum_{V,j}\int d\mathcal T_{j,V}
 \le4X,\quad X=\lambda|E_0|.
 \tag{CJ3}
\]
最後一式来自原行帽 4λ 和同一真实接收集 E_0。**草案中 Σ_j 的因果式必须由 CJ3 的唯一比例带指示承载。** 若先去掉硬端而另写边缘化表达，仍须显式保留 `1_{j(x)=j}`；否则每个接收点会被重复计入多个 j。

写 p=P_{s,L}(x−y)，并保留 R117 的三个 n 维核共同混合
\[
 Q_x^*(z')={P_{s,L}(x-z')+P_{s,L^+}(x-z')+P_{1,b}(x-z')\over3},
 \quad L^+=\min(b,(1+1/n)L).
\]
对于本节固定的实际 (x,y,g)，定义一次
\[
 D_g=\{z'\in Z_g:p w_g(z')>KQ_x^*(z')\},
 \qquad A=\{p e_g\ge2Kq\}.
 \tag{CJ4}
\]
后续 t≤g 的积分不重选 D_g、当前参数或 Q_x^*。因 Z_g⊂Z_t，D_g 在整个因果段都属于存活来源。

R116 给
\[
 T_{\rm small}\le T_{A^c}+2H_K,
 \quad H_K=\mathbb E\sum_{V,j}\int1_A\Pi_g(D_g)\,d\mathcal T_{j,V}.
 \tag{CJ5}
\]
将 R117 JG13 的正变差只积到 g，得到准确的非负上界
\[
 H_K\le H_{\rm init}+H_{\rm jump}+\mathcal C,
 \tag{CJ6}
\]
其中初始项用 Π_{τ_j}(D_g)，跳跃项用 τ_j<u≤g 的 `(Π_u−Π_{u-})_+(D_g)`，各自与同一 `1_A d𝒯_{j,V}` 积分。连续项为
\[
 \boxed{
 \mathcal C=\mathbb E\sum_{V,j}\int1_A d\mathcal T_{j,V}
 \int_{I_{j,V,y}\cap[\tau_j,g]}{dt\over t}
 \int (m_t-k_t(z'))_+1_{D_g}(z')\,d\Pi_t(z').}
 \tag{CJ7}
\]
这是保留原硬端 z 的版本。积分端点在 dt 下无影响；禁块跳跃只在 H_jump 计，不混入连续项。R117 的可测核构造确保所有非负积分合法。CJ6 本身没有费用收益。

## 2. 可独审新命题：终端厚度 u/n 的真实连续项

固定一个在来源、接收点和种子之前选择的 u>0，把 CJ7 中满足
\[
 \max\{\tau_j,g e^{-u/n}\}<t\le g
 \tag{CJ8}
\]
的部分记为 𝒞_near(u)，其余记为 𝒞_far(u)。若实际因果区间更短，取与它的交；若 heavy 区间为单例，连续项为零。

**命题 CJ-A。** 对当前全部一般实际输入，
\[
 \boxed{\mathcal C_{\rm near}(u)
 \le{u\over4}T_{\rm small}\le uX.}
 \tag{CJ9}
\]
它保留全部原门、归一化 1/e_t、真实 dx、硬端 z 和自适应尺度，不假定任何源独立性、固定参数或几何稀疏。

**证明。** 对每个 t，0≤k_t≤n，且 m_t=E_{Π_t}k_t。因此
\[
 \int(m_t-k_t)_+\,d\Pi_t
 ={1\over2}\mathbb E_{\Pi_t}|k_t-m_t|
 \le{n\over4}.
 \tag{CJ10}
\]
乘 `1_{D_g}` 只会减小左侧。对每个固定原 (ω,V,j,x,y,z)，CJ8 的对数长度至多 u/n，所以
\[
 \int_{\max\{\tau_j,g e^{-u/n}\}}^g{dt\over t}
 \int(m_t-k_t)_+1_{D_g}\,d\Pi_t\le u/4.
\]
把这个确定的上界乘 `1_A d𝒯_{j,V}`，再按 CJ3 的唯一比例带归属相加，得到 CJ9。没有将每个 j 的 u/4 再乘比例带个数；也未把 e_t 从概率测度 Π_t 中删除。证毕。

对任意 u>0，𝒞_near 是 RN 权重不超过 u/4 的真实加权子预算；只有 u≤4 时，该权重必不超过 1，才可进一步称为原 d𝒯 的子测度。下述通常的 0<ε≤1、u≤119ε/256 自动满足这一条件。X 使用原有限接收集的预算单位；不借 X=∞ 的形式不等式宣称有限误差价。

准确回代为
\[
 \boxed{
 T_{\rm small}
 \le T_{A^c}+2H_{\rm init}+2H_{\rm jump}
       +2\mathcal C_{\rm far}(u)+2uX.}
 \tag{CJ11}
\]
或者在 0<u<2 时保留 CJ9 的第一项作一次吸收，得到
\[
 (1-u/2)T_{\rm small}
 \le T_{A^c}+2H_{\rm init}+2H_{\rm jump}
       +2\mathcal C_{\rm far}(u).
 \tag{CJ12}
\]
CJ11 与 CJ12 是同一项的两种记账方式，只选其一，不能同时获得接收费与乘法收益。

若外层原账为 `P_old+ΛT_small`，Λ=128/119，那么 CJ11 新增的是 `2ΛuX`。要求新增的**全局**费用至多 εX 时取
\[
 u\le\varepsilon/(2\Lambda).
 \tag{CJ13}
\]
这只支付新连续终端薄尺度项，不抵销或覆盖既有 R115 大父费和任何旧吸收费用。未付初始/跳跃/低 pe 与远时项在 CJ11 中全部保留。本命题未声称宽度 u/n 的切片占全部连续交通的固定比例。

## 3. 远时改用 signed covariance 的准确接口

固定实际 (ω,V,j,x,y,g)，只在原禁块恒定的开区间内微分。R117 JG11 给
\[
 {d\over dt}\Pi_t(D_g)
 ={m_t\Pi_t(D_g)-\int_{D_g}k_t\,d\Pi_t\over t}
 =-{\operatorname{Cov}_{\Pi_t}(k_t,1_{D_g})\over t}.
 \tag{CJ14}
\]
令 G_t=Z_t\D_g，表示非 D_g 补集，不能全部称为 good 来源。在 Π_t 支持上 `1_G=1−1_D`，所以
\[
 {d\over dt}\Pi_t(D_g)
 ={\operatorname{Cov}_{\Pi_t}(k_t,1_{G_t})\over t},
 \quad
 [\operatorname{Cov}_{\Pi_t}(k_t,1_{G_t})]_+
 \le(n-m_t)\Pi_t(G_t).
 \tag{CJ15}
\]
这里 D_g 固定，G_t 在各禁块恒定区间也固定；没有对随 t 重选的坏集套用导数。全部因果跳跃仍需单列。在跳点 u≤g，D_g⊂Z_g⊂Z_u，故删除不触及 D_g，`Π_u(D_g)−Π_{u-}(D_g)≥0`，并与 CJ6 的跳跃正部完全一致。

因此可以把 CJ6 的连续正密度积分替换为 signed covariance 的实际积分，得到等式版本。该带符号积分绝对收敛：逐 t 的协方差绝对值至多 n/4，因果对数长度至多 log(b/a)，与原交通积分后至多 `(n/4)log(b/a)T_small<∞`，所以可以合法交换积分。它可能保留更多抵消，但**还不是一个接收费或来源费上界**。若把 covariance 再取正部，它不超过 CJ7；下面说明 FIRST 能直接提供什么。

对 t≤g，因每个权重因子的比在 [1,g/t] 内，
\[
 1\le R_{t,g}(z'):=w_t(z')/w_g(z')\le(g/t)^n.
\]
定义精确的加权 future 容量
\[
 \mathcal F_{t,g}(x,y)
 :=\int_{Z_g}R_{t,g}(z')Q_x^*(z')d\nu_V(z'),
\]
以及将在 t 与 g 之间被禁块删去的质量
\[
 \Delta_{t,g}(y)=\int_{Z_t\setminus Z_g}w_t(z')d\nu_V(z').
 \tag{CJ16}
\]
高支上 p>0。对存活的 good 来源 `Z_g\D_g`，定义直接给 `p w_g≤KQ_x^*`，故
\[
 \Pi_t(Z_g\setminus D_g)
 \le {K\over p e_t}\mathcal F_{t,g}(x,y),
\]
\[
 \boxed{
 [\operatorname{Cov}_{\Pi_t}(k_t,1_{G_t})]_+
 \le(n-m_t)\min\left\{1,
 {\Delta_{t,g}\over e_t}
 +{K\mathcal F_{t,g}(x,y)\over p e_t}\right\}.}
 \tag{CJ17}
\]
这是待进一步利用的明确接口，所有源、核、分母和尺度都已固定。

原 FIRST 只给未加权的 `∫Q_x^*dν_V≤q`，由它和逐点比值目前能直接读出的上界为
\[
 \mathcal F_{t,g}(x,y)\le(g/t)^n q,
 \quad
 \Pi_t(Z_g\setminus D_g)
 \le {Kq\over p e_t}(g/t)^n.
 \tag{CJ18}
\]
当 `t≤g e^{-u/n}`，该系数可以随 log(g/t) 放大；不能以当前 g 的 good 概率帽替代早期 t 的 good 概率帽。FIRST 允许共同 future 测试，不允许按 z′ 更换参数来消去 R_{t,g}。

对于 Δ，若 t 与 g 之间没有禁块扩张则 Δ=0；若发生扩张，A_{j,g} 是真正 light 块而非未变 light 的 heavy fallback。由 ν_V≤h 及 e_t≥e_g，
\[
 {\Delta_{t,g}\over e_t}
 \le{H_j(g)\over e_g}\le\rho_j(g)
 ={c_j^{n/2}\over\ell}
 \max\{1,\sqrt n c_{j+1}^n,\sqrt n(g/b)^n\}.
 \tag{CJ19}
\]
**CJ19 尚未付款。** 它处在连续协方差率 `(n−m_t)dt/t` 内；直接积分仍可能留下 `n log(g/τ_j)`。R117 JG15 的可求和 jump 质量不能直接代替此连续项的实际积分费用，也不能忽略之后与原 `p h_R a_ω` 的相乘。

还可在点态上精确保留坏来源与非 D_g 补集来源的 score 次序，避免先把补集只估成总质量。对固定实际 (x,y,g,t)，令 D=D_g，则
\[
 -\operatorname{Cov}_{\Pi_t}(k_t,1_D)
 ={1\over2}\iint
 [k_t(z'')-k_t(z')][1_D(z')-1_D(z'')]
 \,d\Pi_t(z')d\Pi_t(z'')
\]
\[
 =\int_{D_g}\int_{Z_t\setminus D_g}
 [k_t(z'')-k_t(z')]\,d\Pi_t(z'')d\Pi_t(z').
 \tag{CJ19a}
\]
因此
\[
 [-\operatorname{Cov}_{\Pi_t}(k_t,1_D)]_+
 \le\int_{D_g}\int_{Z_t\setminus D_g}
 [k_t(z'')-k_t(z')]_+
 \,d\Pi_t(z'')d\Pi_t(z').
 \tag{CJ19b}
\]
这里必须按不交并分开补集来源：
\[
 Z_t\setminus D_g
 =(Z_g\setminus D_g)\,\dot\cup\,(Z_t\setminus Z_g).
 \tag{CJ19c}
\]
第一类是存活 good 来源，具有 `p w_g≤KQ_x^*` 门，可以接 CJ16–CJ18 的 future 容量；第二类是未来删去来源，不具有该 good 门，只能另用 Δ_{t,g} 接口。CJ19a/b 的内层积分依 CJ19c 分成这两项，不能把第一类的核比较用于第二类。

正贡献只来自“坏来源 z′ 的 k_t 反而小于补集来源 z″”的配对；其余配对给零或有利的负项。Π_t⊗Π_t 的准确密度仍含 `w_t(z′)w_t(z″)/e_t²`、两个 Z_t 门，D_g 还含实际 Q_x^* 坏门。将 CJ19a 或 CJ19b 乘原 `1_A d𝒯_{j,V}` 并在 t≤g 下积分，会完整保留原 hard 来源 z 与这两个辅助来源的几何。下一项几何估计可分别针对“坏—存活 good”及“坏—未来删去”两类逆序来源对的真实 x 体积；仅使用 CJ18 会丢掉这个次序信息且不覆盖第二类。目前没有为该来源对积分给出新付款。

## 4. 哪种过强的点态筛查可以排除

仅从原 FIRST 的标量测试预算、高 pe 及 0≤k≤n，无法推出点态 covariance 为 O(√n)。一个两类概率计算即可核对，不需要长数值扫描：本例明确取 t=g，所以 e_t=e_g、w_t=w_g；令 Π_g 在分割 Z_g 的 B、G 上的质量分别为 3/4、1/4，令 k=k_g=0 于 B、k=k_g=n 于 G，并令 `p e_g=3Kq`。于是
\[
 m_t=n/4,\qquad
 \operatorname{Cov}_{\Pi_t}(k,1_G)=3n/16.
 \tag{CJ20}
\]
若标量测试比 `KQ/(p w_g)` 在 B 上为 1/18、在 G 上为 1，则 terminal 坏集 D_g 正是 B，G=Z_g\D_g 为存活 good 集，且
\[
 \int Q\,d\nu={p e_t\over K}
 \left({3\over4}\,{1\over18}+{1\over4}\right)
 ={7\over8}q\le q.
\]
因此高 pe 与标量 FIRST 容量同时成立，仍可有线性点态协方差。本计算**不是**实际 Q_x^* 的空间实现，也不是 FULL 输入反例，更没有证明远时积分本身线性；它只排除将这些标量信息直接升级为点态根阶 score 界的推理。任何改善必须确实使用 Q_x^* 的几何、原硬端捕获、来源关系或积分抵消。

## 5. 本轮结论与唯一远时缺口

本轮的新增实价只有 CJ9–CJ13：终端对数尺度厚度 u/n 的因果连续项，无条件付给至多 2ΛuX 的全局接收预算。该证明适用于整个一般实际余项，没有将小维数、固定来源或特殊族替代一般输入。

远时仍缺一条把 CJ16 的加权 future 容量与实际 `p h_R a_ω`、归一化 e_t、t≤g 共同积分的估计，或者直接控制 CJ19a 的 signed 来源对积分，分别利用 CJ19c 的“坏—存活 good”和“坏—未来删去”两类逆序来源对与真实 x 体积的关系。CJ18 的逐点 `(g/t)^n` 替代和 CJ19 的单独质量帽均不能完成这一任务；CJ20 说明只继续操作现有标量容量与 score 帽不会给所需的点态根阶改善。原两中心列可以保留 g≥t，但把原硬端积分后只看到一次 e_t 因子并不足以消去第三来源和其连续 score；没有在本稿声称这种符号配对已经产生付款。

低 pe、所有 j 的初始和跳跃接收费用仍是其他独立缺口，CJ11 完整展示其位置。一般根阶目标仍 UNPROVED。本稿不扩大数值协议，不改他人文件，不开展 Git、PDF 或子代理工作；交付后停待命。

> 审查过程按时间保留；最终冻结版本的结论见该节末尾。静态审查不代表已执行数值。

# R118 近尺度连续正变差预算：独立命题筛查

状态：**所给命题 PASS。** 仅使用已审 R117 JG-A/JG11 的可测概率核及原接口 `T_small≤4X`，独立推导，不读取 R118 作者未冻结稿或 CL3。未数值、Git、PDF，未改其他文件。该命题只支付指定的近尺度连续项，不是一般余项闭合。

## 1. 准确对象与范围

固定原实际交通测度

\[
d\mathcal T=q^{-1}p\,h_R\,a\,dx\,d\beta_V(y)\,d\nu_V(z),
\qquad \mathcal T(\mathrm{all})=T_{small}\le4X,
\quad X=\lambda|E_0|.
\]

所有原种子平均、V 求和、原 FIRST/FULL/CP/GP/deep 等 gate 均在同一测度内；本稿的积分记号包含它们。每个实际接收 x 只有一个 `j=j(x)`。固定该行原 `g=g(x)`，假设 g 属于比例带 j 的原 heavy 区间 I，令

\[
\ell_u(x)=\max\{\tau_j,g e^{-u/n}\},\qquad u>0.
\]

原 heavy 区间是从 τ_j 开始的初始区间，故 `[ell_u,g]` 的内部位于 I，所用 e_t 有限正，Π_t 是同一原来源上的概率核。`D_g=D_g(x,y)` 固定于该行的 x、y、g；积分 t 时不改成 D_t，不重选 test、实际尺度或来源。由 Z 嵌套，t≤g 时 `D_g⊂Z_g⊂Z_t`，但下述标量上界甚至不需要这一包含。

在禁块恒定的区间，R117 JG11 给连续正变差测度

\[
v_t(dz')=\frac{(m_t-k_t(z'))_+}{t}\,\Pi_t(dz'),
\qquad 0\le k_t\le n,
\quad m_t=\int k_t\,d\Pi_t.
\]

定义所审准确项

\[
C_{near}=\int d\mathcal T
\int_{\ell_u}^{g}v_t(D_g)\,dt.
\tag{N1}
\]

若遇禁块跳，只在相邻恒定区间积分连续 dt 密度，不加入任何跳正测度。有限跳点与坐标折点的 dt 零集可任意置零。

## 2. 核级 n/4 界：不引入 j 或来源倍数

对任一概率空间上的 `K∈[0,n]`，写 `m=E K`。逐点有

\[
(m-K)_+\le m(1-K/n).
\tag{N2}
\]

证明：K≥m 时左端为零，右端非负；K≤m 时两边之差为 `K(1−m/n)≥0`。取期望即得

\[
E(m-K)_+\le m(1-m/n)\le n/4.
\tag{N3}
\]

该式包含 m=0,n 的退化情况；两端此时正变差为零。应用于 K=k_t，再限制到固定 D_g，

\[
0\le v_t(D_g)\le v_t(\mathrm{all})
=\frac{E_{\Pi_t}(m_t-k_t)_+}{t}
\le\frac{n}{4t}
\quad\text{a.e. }t.
\tag{N4}
\]

这里没有假设来源后验独立，也没有把 `[0,n]` 中的 K 当成二项变量。常数 n/4 来自概率与范围界，未使用输入质量、森林深度或比例带数。

由于 `τ_j≤g`，

\[
0\le\log(g/\ell_u)\le u/n.
\]

故逐原交通行

\[
\boxed{0\le A_{near}(x,y):=
\int_{\ell_u}^{g}v_t(D_g)dt
\le\frac n4\log(g/\ell_u)\le\frac u4.}
\tag{N5}
\]

原 lower 截端只有缩短区间的作用。g=τ_j 或 lower=g 时积分为零；无需从区间外引入 Π，也不计初始 τ_j 的删除。原 heavy 右端是否开放不影响结果：实际 g∈I 已保证取用的核合法；端点单点不改变连续积分。

## 3. 真实交通与唯一 j 回代

将 N5 乘同一原非负交通，得到更强的源无关形式

\[
\boxed{C_{near}\le\frac u4 T_{small}\le uX.}
\tag{N6}
\]

若将积分写为 j 求和，必须保留原 `1_{j(x)=j}`：

\[
C_{near}=\sum_j\int 1_{\{j(x)=j\}}A_{near}\,d\mathcal T
\le\frac u4\sum_j\int1_{\{j(x)=j\}}d\mathcal T
=\frac u4T_{small}.
\tag{N7}
\]

不出现 `J`、`Σ_j 1` 或复制 `W_β`。τ_j 虽随 j 变化，N5 对每个实际 j 用同一 u/4 常数，因此不需额外付尺度菜单费。种子和来源求和也只是同一 d𝒯 的非负积分；不能把每个 seed/来源的界单独重复领取为 X。

## 4. 可测性和“真实子预算”的准确含义

R117 JG-A 已给 `(ω,V,y,t)` 上的显式可测 Π、m 与连续正密度；原 g、j 和 τ_j 为原可测选择器。原 D_g 的图可测。于是

\[
1_{\{\ell_u<t<g\}}
\frac{(m_t-k_t(z'))_+}{t}1_{D_g}(z')\Pi_t(dz')
\]

给非负可测核，可用 Tonelli 定义 N1。每行 t≥τ_j>0，且 heavy 子区间内分母 e_t>0；空 heavy 区间没有实际 g 或对应贡献，不在其上作除法。若 X 有限，N6 同时保证所审积分有限；X=0 时原交通及本项均为零。X 无限时仍是扩展非负数不等式，但不能据其宣称有限误差预算。

C_near 是从完整原实际输入的交通及其第三来源连续正变化中提取的真实项，不是固定参数样本或重造的抽象 FULL 输入。对任意 u>0，它是一项 RN 权重不超过 u/4 的真实加权子预算；**只有 u≤4 时还可直接称作原 d𝒯 的子测度**（因为 N5 给权重≤1）。不能对任意大 u 声称必有 `C_near≤T_small`。用于小误差预算时取下节的小 u，自然满足这一子测度口径。

## 5. R116 系数与外 Λ

R116 的 `T_small≤T_{A^c}+2H_K` 中高项系数 2 必须保留。若 H_K 的后续真实分解中，N1 正是被分出的近尺度连续项，则其树前账单为

\[
\boxed{2\Lambda C_{near}\le2\Lambda uX,
\qquad\Lambda=128/119.}
\tag{N8}
\]

因此，为将**这一项**放入全局 `εX`，充分条件准确为

\[
\boxed{0<u\le\frac{\epsilon}{2\Lambda}
=\frac{119}{256}\epsilon.}
\tag{N9}
\]

常用 `0<ε≤1` 下这也给 u<1，从而 N1 确实为原交通的子测度预算。N8 不再加第二个 R116 的 2，也不再乘第二个 Λ；它不抵扣 R115 大父费或任何旧接收/来源费。选择 N9 只给此项一个误差槽，最终总 X 吸收还须保留其他历史槽。

N8 是条件记账：本稿证明的是 N1 本身的预算，不替作者证明 H_K 的实际分解恰包含且只包含这一项。若作者另用正包络、改 D_g 或把多份近项重复加入，须核其与 N1 的准确关系，不能只因名称“近连续”便领取本预算。

## 6. 本命题没有付款的部分

近区间长度的上界不控制 `τ_j≤t<g e^{-u/n}` 的远时连续变差，不控制 JG13 的初始 Π_{τ_j}，也不控制禁块跳跃正测度。低 pe 项 `T_{A^c}` 仍需自己的真实付款。JG-B 的已审跳系数并非本命题新增交通费；各来源、尺度和种子的其余联合包络费用也未因此消失。

独立筛查结论：N6/N8/N9 正确，截端、零区间、可测核与唯一 j 求和均合法；“任意 u 时是原交通子测度”需改为上面的权重口径。近尺度连续项可以按指定误差槽付款，其余一般预算仍未闭合。完成后停止待命。

> 审查过程按时间保留；最终冻结版本的结论见该节末尾。静态审查不代表已执行数值。

# R118 因果连续项作者全文独立审查

对象：完整读取 `causal_joint.md`，已核 SHA-256 为 `e13bc3de16f8bd042d82f71bfeb01244284756aebce5ad265343eb73f23c3a66`，与冻结值一致。使用已审 R117 JG-A/JG-B 与本轮独立 `near_statement_audit.md`；不以作者的自称认证替代核验。只写本稿，未数值、Git、PDF，未修改作者文件。

**结论：CJ1–CJ19b 的解析与 CJ9–CJ13 的真实近时预算 PASS；接入前需完成 §4 的两处最小范围修订。** 它们不改变正确公式，但避免把未来删除来源误赋终端好门，以及把 t 点标量数据误当 g 点坏门。远时、初始、跳跃与低 pe 仍未付款，一般目标未闭合。

## 1. 同一原交通、因果分解与近时回代

CJ1 的 k 定义等价于 R117 `A_i<t`。CJ2 使用同一实际 RN `q^{-1}p h_R a`；CJ3 的 `1_{j(x)=j}` 保证每个实际接收点只进入一个比例带，原种子与 V 求和也仍在原交通账中。逐行原帽给 `T_small≤4X`，不从后验平均反推输入行帽。原 heavy 区间是初始区间，g∈I 保证 τ_j 至 g 的核有有限正 e_t；空或单例区间不产生连续贡献。

CJ4 保留固定 D_g 与共同 Q_x^*，不随积分 t 重选。Z 递减给 `D_g⊂Z_g⊂Z_t`，故已审 JG13 的正变化积分可以只截到实际 g，CJ6/CJ7 成立。初始 Π_{τ_j} 只计一次；跳点计正测度，连续 dt 积分不额外计跳，不移除 `1/e_t` 或原硬端 z。

CJ9/CJ10 与独立 `near_statement_audit.md` 的 N3–N7 一致，不重复证明。对原 `1_A d𝒯` 的近项有

\[
\mathcal C_{near}\le(u/4)T_{small}\le uX.
\]

CJ11 先保留 R116 的 2，再用 `C_near≤uX`，因此新增树后项为 `2uX`。CJ12 改用第一上界得到 `(1−u/2)T_small`，仅在 0<u<2 时可作吸收。两种方式只能选其一，不同时领取费用与收缩收益。

原外账若按作者指定为 `P_old+ΛT_small`，则树前新增为 `2ΛuX`，`Λ=128/119`，CJ13 条件准确为

\[
u\le\epsilon/(2\Lambda)=119\epsilon/256.
\]

没有漏掉 2，也没有把 Λ 乘两次或自动抵扣 R115/历史 X 槽。u 任意时权重≤u/4 的表述正确；u≤4 才必为原交通子测度，常用 ε≤1 自动满足。未证明近片段占总连续项的固定比例。

## 2. Signed covariance 与双来源展开

在每个禁块恒定段，D_g 固定，逐概率核微分给

\[
\partial_t\Pi_t(D_g)
=[m_t\Pi_t(D_g)-E_{\Pi_t}(k_t1_{D_g})]/t
=-\operatorname{Cov}_{\Pi_t}(k_t,1_{D_g})/t.
\]

令 `G_t=Z_t\D_g`，在 Π_t 支持上 `1_G=1−1_D`，故 CJ14/CJ15 的符号正确。并有

\[
[\operatorname{Cov}(k_t,1_G)]_+
\le(n-m_t)\Pi_t(G_t),
\]

因为 `Cov(k,1_G)=E[(k−m)1_G]≤(n−m)Π(G)`。在跳点 u≤g，删除集合不交 D_g，D_g 的未归一化质量不变而 e 减少，故其概率跳非负，等于该有符号跳测度的正部在 D_g 上的取值。

作者所称“等式版本”可严格写为：若定义

\[
\mathcal C_{sig}:=\mathbb E\sum_{V,j}\int1_A d\mathcal T_{j,V}
\int_{\tau_j}^{g}\operatorname{Cov}_{\Pi_t}(k_t,1_{G_t})\frac{dt}{t},
\]

则

\[
H_K=H_{init}+H_{jump}+\mathcal C_{sig}.
\tag{A1}
\]

这里 C_sig 可以为负；它与 CJ7 的非负 C 不是同一对象。C_sig 逐行绝对积分≤`(n/4)log(g/τ_j)`；实际 `g≤bc_j`、`τ_j=a/c_j` 给 `log(g/τ_j)≤log(b/a)`，与有限 `T_small` 相乘保证绝对可积。作者据此交换有符号积分合法。协方差正部≤CJ7 的连续正变化，也正确。不可将 A1 的 signed far 与 CJ11 的非负 C_far 不加定义就混作同一费用。

独立核对 CJ19a：

\[
-\operatorname{Cov}_{\Pi_t}(k,1_D)
=\int_D\int_{Z_t\setminus D}
[k(z'')-k(z')]d\Pi_t(z'')d\Pi_t(z').
\tag{A2}
\]

对称式中的 1/2 恰被两种交叉方向抵消，最终没有遗漏 1/2，也不再乘 2。正贡献的顺序是 D 中 z′ 的 k 较小、补集 z″ 的 k 较大；反向配对给负贡献。`[∫f]_+≤∫f_+` 给 CJ19b，界方向正确。

双辅助来源的密度准确为

\[
d\Pi_t(z')d\Pi_t(z'')
=\frac{1_{Z_t}(z')1_{Z_t}(z'')w_t(z')w_t(z'')}{e_t^2}
d\nu_V(z')d\nu_V(z'').
\tag{A3}
\]

它还要乘原 `1_A q^{-1}p h_R a dx dβ_V(y)dν_V(z)`。原硬来源 z 与两个辅助来源 z′、z″ 不同，不能把辅助来源继承硬捕获门。作者保留 `e_t^{-2}`、两个 Z 门与终端坏门，未把双来源归一化误当单来源。单独 A2/A3 并未产生新空间费。

## 3. Future 容量与未来删除质量

单坐标的 min 比值在 `[1,g/t]`，相乘给 CJ16 的 `1≤R_{t,g}≤(g/t)^n`。终端幸存好来源 `Z_g\D_g` 满足 `p w_g≤KQ_x^*`，因此

\[
\Pi_t(Z_g\setminus D_g)
\le K\mathcal F_{t,g}/(p e_t).
\]

FIRST 仅给原未加权 Q 混合的整体容量 q；不依 z′ 重选参数时，直接推出的仍是 `F_{t,g}≤(g/t)^n q`。CJ17/CJ18 方向正确，且保留了原 e_t 与 terminal 的坏/好门。

`G_t` 的准确不交分割是

\[
G_t=(Z_g\setminus D_g)\ \dot\cup\ (Z_t\setminus Z_g).
\tag{A4}
\]

第二部分在 t 时存活、之后被原禁块删除，其 Π_t 质量正是 `Δ_{t,g}/e_t`。故 CJ17 的质量帽包含 Δ 必要且正确；没有将全部补集错误地仅用 future 容量估计。

若无扩张，Δ=0；若有扩张，终端 A_{j,g} 是真正 light 块。由 w_t≤1、真实 ν≤h、删集位于该块及 `e_t≥e_g` 得

\[
\Delta_{t,g}/e_t\le H_j(g)/e_g\le\rho_j(g).
\]

CJ19 使用同一原 born 资格，不免费赋 β hard rank。其后仍需积分 `(n−m_t)dt/t` 并乘原交通，可能留下线性 n 的费用；作者明确说尚未付款，未将 JG-B 的 jump 标量预算冒充连续项交通付款，这一范围正确。

## 4. 接入前必须做的两处最小范围修订

### 4.1 CJ19a 后的“good 来源”须分两类

公式 A2 的内域是 `Z_t\D_g`，包含 A4 的未来删除来源。作者句子“坏来源 z′ 的 k_t 反而小于 good 来源 z″”及末节“逆序坏/好来源”若把 good 理解为满足 terminal `p w_g≤KQ` 的来源，则错误：未来删除来源甚至不在 Z_g，没有这个终端好门。

请将该句改为：

> 正贡献只来自终端坏来源 z′ 的 k_t 小于补集来源 z″ 的配对。补集分为终端幸存好来源 `Z_g\D_g` 与未来删除来源 `Z_t\Z_g`；只有前者满足 `p w_g≤KQ_x^*`。后者须保留 Δ 或其真实来源对项，不能借用该好门。

末节对应称作“逆序坏/补集来源对”，或显式同时写两类。需要的真实 signed 分解为

\[
-\operatorname{Cov}(k,1_{D_g})
=\int_{D_g}\int_{Z_g\setminus D_g}(k''-k')d\Pi_t''d\Pi_t'
+\int_{D_g}\int_{Z_t\setminus Z_g}(k''-k')d\Pi_t''d\Pi_t'.
\tag{A5}
\]

这是现有正确公式的范围澄清，不要求新增付款。对 A5 取正部也须保留两部分，不能只估第一部分便称控制了全部 far covariance。

### 4.2 CJ20 标量单元须明确 t=g

原坏集 D_g 按 `p w_g>KQ` 定义，高支按 `p e_g≥2Kq` 定义。CJ20 当前却给 `p e_t=3Kq` 与 `KQ/(p w_t)`，随后直接说坏集为 B。若 t<g，这两个 t 点条件并不确定终端 D_g，也不保证 terminal 高 pe。

请在标量例开头明确：

> 本独立标量单元取 t=g，故 w_t=w_g、e_t=e_g；不作为原 Q_x^* 的空间实现。

此时坏集 B、好集 G、高 pe 与容量计算完全一致：比值 B=`1/18<1`、G=`1`，G 的等号属于好补集，`Π_g(B)=3/4`；`p e_g=3Kq` 属高支。

\[
m=n/4,\qquad\operatorname{Cov}(k,1_G)=3n/16,
\]

\[
\int Qd\nu=(p e_g/K)(3/72+1/4)=7q/8\le q.
\]

算术正确，证明标量条件允许线性协方差，不能凭这些信息推出统一点态 O(√n)。它没有证明实际 geometric Q、真实 FULL、远时空间积分或一般目标的反例；作者已有这些范围限制，补 t=g 后保持即可。

## 5. 有界结论

本稿认可作者的新近时预算及签名接口的公式，不认可远时已付款或一般闭合。§4 两处最小修订完成后可将全文作为部分预算与条件接口接入；冻结未修版的相关范围文字不应直接照录到主稿。旧来源费、R115 大父误差、R116 的低项/系数 2 与原外 Λ 各保持原账。完成本次全文审查后停止待命。

## 6. 两处 scope 修订的定点增量复审：最终 PASS

已核修订冻结版本 SHA-256：`130aa72752953260a7cb77ef92e70159e2bb7b71031848840368bb42c4390484`。仅阅读并核对 CJ19c、相邻来源分类文字、CJ20 的 t=g 以及末节对应范围，不重审上述已通过公式。

- CJ19c 已明确不交分开 `Z_g\D_g` 与 `Z_t\Z_g`；只有第一类具有终端 good 核比较，第二类保留未来删除 Δ 接口。来源对文字与远时缺口均改为分别处理这两类，未把第一类的 good 门套给第二类。
- CJ20 已明确取 t=g、e_t=e_g、w_t=w_g，B/G 分割 Z_g，坏集按 terminal `pw_g>KQ` 定义；与高 pe 和容量算术完全一致，仍限定为标量条件排错，不宣称空间/FULL 实现。

**最终 verdict：修订冻结全文 PASS，可作为本轮部分预算与未付款条件接口接入。** 此结论替代初版两处范围修订待完成的状态；认可的新增费用仍仅为近连续项 `2ΛuX`，远时、初始、跳跃、低 pe 与一般根阶目标仍未闭合。未运行数值、Git、PDF，停止待命。

# 数值协议（保留执行前状态文字；实际执行见后文）

# R118 近尺度连续项：最小精确协议（待审，未运行）

只核 `near_statement_audit.md` 的局部连续预算与外层记账。真实全部输入的覆盖来自已证 CJ-A/JG-A 接口，绝不来自以下两原子样本；不认证 FULL 几何、远时根预算、初始项或跳费。不造真实交通。仅本协议，暂不代码。

## 定义与精确路径

固定 n、k，`r=1+1/(kn)`，t∈[1,r]，`μ=(a t^-n,b)`。基础 a=b=1；e=Σμ，dμ=(-na t^(-n-1),0)，de=Σdμ。独立商法则 `dpi_i=(dμ_i e−μ_i de)/e²`；实际正部 P=Σmax(dpi_i,0)，另比中心化母式及 `Σ|dpi|/2`。取 `p=a/(a+b t^n)`，精确原函数给 `V=p(1)−p(r)`；基础 `V=1/2−1/(1+r^n)`。检查 Σdpi=0、P=n p(1−p)/t、`n/4−tP=n(p−1/2)²≥0`。e=0 输入不得归一化。

全部 Fraction/整数幂，不用浮点积分。log 包围用 `z=(r−1)/(r+1)`：
`L_M=2Σ_{m=0}^{M−1}z^(2m+1)/(2m+1)`，
`U_M=L_M+2z^(2M+1)/[(2M+1)(1−z²)]`。
z>0 时 L_M<log r<U_M；z=0 精确为零。逐项实际计算 V、dpi，不将闭式预期写回 observed。比较 V≤n log(r)/4 时：`nL_M/4−V≥0` 为严格方向证书；`V−nU_M/4>0` 为失败证书；其余未判定，不冒称已证。零长度单独核 V=0。

## 三阶段固定菜单

1. 基础：n=4,k=16,a=b=1,M=2；导数点 `{1,(1+r)/2,r}`。保存商法则/中心化残差、V 与 log 上下证书、平方残差。先从 μ 两端计算概率差，再比基础闭式。
2. 压力：仍 n=4,k=16,M=2。open/closed 端点连续积分 V 相同；另固定 r=1 的零长度单元。极端权重 `(a,b)={(0,1),(1,0),(1/1024,1),(1024,1)}`，按同一原函数独立核 V 与范围界；(0,0) 仅预期拒绝。基础 t=1 检查全变差=2P；错误省略 1/2 后全变差超过 n/(4t)，必须被精确残差识别。以上均抽象单元，无禁块删除。
3. 扩大：n={4,16,256,1024}、k={16,128}，基础 a=b=1，共8固定配置；M={1,2,4,8} 只缩窄 log 证书，r、μ、V 不随 M 改变。导数点仍三点。不扩扫、不依据 observed 调参。

## 外层 2Λ 与成功标准

取 `Λ=128/119`、`u=1/k`。用 log(1+x)≤x 的解析界及有理残差 `1/(kn)−U_M≥0` 核 `V≤u/4`。记账单元只取标量代理 X=1、T_small=4：`C_proxy=4V`，账单 `2Λ C_proxy=8ΛV`，固定 `ε=2Λ/k`，实际核 `ε−8ΛV≥0`。这只是检验 N6/N8/N9 的系数，不能把代理当原真实交通；唯一实际 j 与全部原 gate 由已证接口保留。2 与 Λ 各乘一次；不复制每个 n/k 样本的 X，不把8份相加为一次付款。

每阶段输出必要配置、精确残差符号与小型完整有理证书；巨大分数用 bit_length/SHA 加确定公式重建，不输出海量重复副本。成功：全部直接身份成立，正确局部/log/外层方向有证书，预期拒绝被识别；包围跨界只标未判定，实际身份错误立即 FAIL。每阶段须主代理授权运行；本协议无执行结果。

# 数值协议（保留执行前状态文字；实际执行见后文）

> 审查过程按时间保留；最终冻结版本的结论见该节末尾。静态审查不代表已执行数值。

# R118 最小近尺度协议独立审查

对象：完整读取 `numeric_protocol.md`，已核 SHA-256 为 `7d4346533c53b76d82320ad593df3fd4134119bd8153498d2bd28ed88b548fd1`，与冻结值一致。仅静态审查，不代码、不运行，不重读已审 CJ-A。

**Verdict：PASS，最小协议可实施。** 它检验两原子解析身份、近时间窗和收费系数，不认证真实 FULL 交通或一般远时付款；无必须修改项。

## 1. 商法则、原函数与错误系数压力

非负 a、b 不同时为零时，`e=a t^{-n}+b>0`，第一概率

\[
p(t)=a/(a+b t^n)
\]

满足

\[
p'(t)=-n p(t)(1-p(t))/t,
\qquad\pi_2'= -p'(t)\ge0.
\]

故直接商法则向量的正部 P、中心化式与半个全变差均为

\[
P=n p(1-p)/t=\tfrac12\sum_i|\pi_i'|,
\qquad n/4-tP=n(p-1/2)^2\ge0.
\]

原函数正确给 `V=p(1)−p(r)`；基础 a=b=1 时为 `1/2−1/(1+r^n)`。a=0 或 b=0 的退化概率恒定，P=V=0；(0,0) 无可归一化核，预期拒绝正确。协议先从实际 μ 两端归一化后算 V、再与闭式比较，未把闭式预测直接写成 observed。

基础 t=1、p=1/2 时 `P=n/4`、`Σ|dpi|=n/2`，错误把全变差当正变化会严格超过 `n/(4t)`。因此阶段二要求这一错误系数被识别，是有效精确压力，不依赖数值近似。连续轨迹在端点无原子，open/closed 的积分 V 相同；r=1 的零长度单元 V=0。

## 2. log 包围方向及证书可构造性

对 `z=(r−1)/(r+1)∈(0,1)`，atanh 级数部分和 L_M 严格低于 log r；用首个省略分母及几何尾得到的 U_M 严格高于 log r。z=0 时二者精确为零，另作零长度身份，不硬套严格不等号。

协议的判据方向正确：

- `nL_M/4−V≥0` 给 `V≤nL_M/4<n log r/4`；
- `V−nU_M/4>0` 给实际违背范围界的证书；
- 其余区间比较未判定，不能因缺少通过证书就声称数学失败。

固定基础八配置的 M=1 已有可构造的正确下证书，而不是依精度碰运气。令

\[
q_n=(r^n-1)/(r^n+1),\qquad z=(r-1)/(r+1).
\]

通过有理加法身份 `q_{m+1}=(q_m+z)/(1+q_m z)≤q_m+z`，归纳得 `q_n≤nz`；基础 `V=q_n/2≤nz/2=nL_1/4`。更大 M 的 L_M 增加，不破坏证书。极端权重仍由同一商法则/原函数核验；协议遇不足证书明确标未判定，不允许调输入扩扫。

外层使用的 `U_M≤1/(kn)` 残差也可构造。置 `x=1/(kn)`，r=1+x，故 `x=2z/(1−z)`。对 M=1，

\[
x-U_1
=\frac{2z^2}{1-z}
\left(1-\frac{z}{3(1+z)}\right)>0.
\]

U_M 随 M 增大而下降，故固定菜单 M=1,2,4,8 均不需修改输入来通过这一有理上证书。标准库 Fraction/整数幂足够；唯一的 log 误差由明确的有理包围承担，未调用浮点积分认证。

## 3. u、实际时间窗与代理账

该抽象轨迹可精确按近窗取 `τ=1,g=r,u=1/k`。因

\[
n\log r\le n(r-1)=1/k=u,
\]

有 `g e^{-u/n}≤1=τ`，故 CJ-A 的真实截端窗口

\[
[\max(\tau,g e^{-u/n}),g]=[1,r].
\]

不是把 u 误取为 log r，也未遗漏 n 因子。由导数范围及 log 上包围，`V≤n log r/4≤u/4`，协议的有理残差链与此一致。r=1 零窗单元另作覆盖，不生成初始或跳跃费用。

代理 `X=1,T_small=4,C_proxy=4V` 代入原系数的正确账为

\[
2\Lambda C_{proxy}=8\Lambda V
\le2\Lambda/k=\epsilon,
\qquad\Lambda=128/119.
\]

R116 的 2 和外 Λ 各一次，4 来自明确代理交通质量而非另一个推导倍数。`ε=2Λ/k` 正好与 `u=ε/(2Λ)` 一致。此项只测试 N6/N8/N9 的系数；协议明确代理不是真实交通、不将八份 X 相加，范围正确。

## 4. 冻结输入与执行范围

M 只改变 log 证书，r、a/b、μ、导数三点和实际 V 不变；跨精度不重建来源或观察窗。四个 n、两个 k、三点导数与极端/零质量单元均为冻结小菜单，没有按 observed 调参。巨大分数以确定公式重建配合 bit_length/SHA 的安排仍须保持可追溯的精确残差，不得将 SHA 本身当不等式证明。

本 PASS 只允许按该协议进入实现准备，执行仍遵守主代理逐阶段授权。已证 CJ-A 的一般覆盖不来自这些样本；FULL 几何、远时、初始和跳跃费用仍未认证。未运行任何程序，完成后待命。

# R118 producer 实现说明（未运行）

对应协议 SHA256：`7d4346533c53b76d82320ad593df3fd4134119bd8153498d2bd28ed88b548fd1`。只新增本轮 `numeric.py` 与本说明；未改协议、R117 或他人文件。未导入、编译或运行 producer，交代码 SHA 静审后停待命。

程序仅标准库。`--stage 1/2/3/all` 的标准格式为 `--stage 1` 等；默认 all。按协议固定三阶段，默认 JSONL stdout；`--record PATH` 排他 `open(...,"x")` 记录相同输出，不覆盖已有文件。实现失败立即非零退出，预期零质量拒绝与包围未判定单独报告。

原始 μ=(a t^-n,b) 与 dμ=(-na t^(-n-1),0) 独立求值；实际 dpi 由 e/de 商法则生成，再取实际正部和，与母公式、半全变差及平方残差比较。V 先由实际 μ 两端归一化概率差得到，再比有理原函数闭式。open/closed 无原子连续积分用同一原函数，零窗、极端概率与错误省略 1/2 压力均保持原菜单。

每配置只计算一次原始输入、三点导数与 V，M 循环仅重算 atanh log 包围和证书。input SHA 与 observed SHA 在各 M 完全复用；M 不在 input SHA 内。全部运算使用 Fraction/整数幂，不计算浮点 log 或积分。下包围通过、上包围失败、跨界未判定方向与协议一致。

代理账固定 X=1、T_small=4、Λ=128/119、u=1/k、ε=2Λ/k，直接核 8ΛV≤ε；从 log 上包围另外核 n log r≤u。2、Λ 和代理质量 4 各使用一次，不把各样本 X 相加。真实交通全部覆盖来自已证 CJ-A 接口；本代码只核抽象局部公式与代理系数，不认证 FULL 来源、远时根预算、初始项或跳费。

输出只保留必要配置与核心残差；最大分子/分母位长≤512 的有理数完整输出，其余保存符号、两端 bit_length 与 exact binary SHA。hash 的有理数使用约分分子/分母，大端整数字节带符号/长度；字典键排序。确定性固定菜单、输入与代码 SHA 可完整重建巨大分数并复核摘要；hash 本身不充当不等式证明。代码不需要解除全局整数转字符串限制，因为巨大整数只以二进制取 hash，不作十进制转换。

未宣称运行通过；静审重点为商法则独立性、V 的 observed/expected 分离、log 包围方向、跨 M 固定输入与 2Λ 代理记账。

> 审查过程按时间保留；最终冻结版本的结论见该节末尾。静态审查不代表已执行数值。

# R118 producer 独立静态审核

代码 SHA-256：`1d877b24cb8ea49ba37de12cd12b3430b739c1877f82b2486a70b59fcd311e18`；协议 SHA-256：`7d4346533c53b76d82320ad593df3fd4134119bd8153498d2bd28ed88b548fd1`。已核文件字节，与冻结值及协议审计 PASS 对应。仅读取本轮协议、协议审计、代码、实现说明；未运行、导入或编译 producer，未修改作者文件。

**verdict：PASS。无必要修订。** 本结论允许主代理对该冻结版本按原三阶段授权执行，不是已运行 PASS、FULL 来源证书或一般远时付款。

1. **原始商法则与实际正部独立（80–116）。** raw_mu 先生成 `(a t^−n,b)`，独立 dμ 为 `(−na t^(−n−1),0)`，实际 e/de 再产生逐坐标 dpi。P 从实际 dpi 正部和求出、全变差从实际 dpi 绝对值和求出；中心化式和闭式仅作为比较目标。总质量、逐坐标中心化残差、半全变差及平方残差均精确核对，符号方向 `dpi₀≤0≤dpi₁` 正确。没有从母公式反填 observed 导数。

2. **V 的 observed/expected 分离（126–152）。** 两端 μ 分别独立归一化，再取实际第一概率差为 V，随后比较原函数 `a/(a+b)−a/(a+b r^n)` 和基础闭式。点导数菜单与 V 都在 M 循环前计算一次。正部积分的原函数方向由上述原始 μ 的解析导数恒等式给出；不将三个有限导数点本身称为一般积分证明。

3. **log 包围与判断方向（119–123、153–163）。** z=(r−1)/(r+1) 在固定菜单属 [0,1)；部分和与首省略项/几何尾完全匹配已审解析包围。`nL_M/4−V≥0` 为通过；`V−nU_M/4>0` 为实际失败；其余 UNDETERMINED，不误当反例。r=1 时 z=L=U=0、V=0，专门输出 PASS_ZERO_LENGTH。程序没有浮点 log、积分或近似门判断。

4. **跨 M 原始输入冻结及八菜单（130–146、153–179、209–212）。** raw 输入、三点实际导数、V、input/observed SHA 都先生成一次。M=(1,2,4,8) 只改变 log 包围与对应残差，不改变 r/a/b/μ/观察窗。阶段三恰为四 n 乘两 k 的八配置，没有按 observed 增加样本或调参。摘要复用表示共享固定输入和结果，不是把预测常数写回 observed。

5. **外层代理系数精确（164–178）。** Λ=128/119，实际 charge=8ΛV，即固定 T_small=4 给 2Λ·4V；epsilon=2Λ/k，核 ledger=epsilon−charge≥0。另核 `1/(kn)−U_M≥0`、`1/(4k)−V≥0` 与 `epsilon/(2Λ)=1/k`，未漏 n，2 和 Λ 各使用一次。X=1、T_small=4 只是输出中明确固定的标量代理，未在八配置间汇总为一次实际付款；scope 明确排除真实交通与远时根认证。

6. **极端/零输入和错误系数压力（186–206）。** 四组 a/b 使用同一独立归一化/导数/原函数路径；a=0 或 b=0 会实际得到常概率与零 V/P。a=b=0 时只从 raw_mu 求实际零 e 并报告 normalization_undefined，不进行归一化；通用 evaluate/normalized 也分别拒绝无有效质量和 e≤0。t=1 的全变差与 2P 都来自实际 dpi，错误省略 1/2 的违界残差为全变差−n/(4t)>0，当前 n=4、t=1 的写法 F(4,4) 正确。

7. **open/closed 单元的证据口径（188–197）。** 两种积分口径都使用已生成 V，等号断言自身只是同一连续原函数值的口径记录。原始轨迹无端点原子，故两积分相等由解析连续性支持；这里不把该同值赋值说成独立数值检出、不制造禁块跳跃，也不要求新测试框架。

8. **精确压缩、失败与不可覆写（18–77、215–251）。** 小分数完整保存；大分数保存约分 Fraction 的符号、位长与带类型/符号/长度的大端 binary SHA。hash 不可逆，但保存的固定菜单、完整小参数与冻结源码可以重算各巨大有理量，再核摘要；hash 本身不充当不等式。`--record` 排他创建，默认 JSONL stdout；断言/异常非零停止，包围未判定单独计数并输出 PASS_WITH_UNDETERMINED。main 守卫不在导入时运行菜单。独立 execution receipt 与记录重放仍由主代理负责。

所有记录保留 ABSTRACT_TWO_ATOM_NON_FULL/SCALAR_PROXY_ONLY 标签；真实一般覆盖来自已证接口而非这些样本。代码未认证 FULL 几何、远时根预算、初始项或跳费，无新增一般付款主张。

状态：`code_static_audit=PASS_FROZEN_SHA`、`producer_executed=NO`、`record_replay=NOT_RUN`、`FULL_certification=NOT_CLAIMED`。交付后待命。

# 第118轮实际数值检验记录

主代理按阶段1、2、3顺序执行；每阶段通过后才开启下一阶段，随后在隔离临时目录仅复制冻结源码并依次重放。六次退出码均为0、stderr为空，每阶段stdout逐字节相同。合并输出126条JSONL记录、104488字节，记录行数不代表数学定理数或全部程序断言数。

源码SHA256：`1d877b24cb8ea49ba37de12cd12b3430b739c1877f82b2486a70b59fcd311e18`。
协议SHA256：`7d4346533c53b76d82320ad593df3fd4134119bd8153498d2bd28ed88b548fd1`。
输出SHA256：`48226578218569ba9c0ad147e5cfb2e112ce0cc940e8443ac9aa6a782e6d7fb2`。
Python版本：`3.14.6 (main, Jun 10 2026, 10:03:53) [Clang 21.0.0 (clang-2100.0.123.102)]`。

阶段1实际核n=4,k=16的原始两原子质量、商法则和原函数；阶段2核端点/零长、极端权重、零总质量的预期拒绝及遗漏半系数的身份错误。阶段3核8个固定配置n=4,16,256,1024与k=16,128，并以M=1,2,4,8缩紧同一输入的log包围。输入质量、r及原函数观测值均不随M改变；没有依据结果扩扫或拟合阶数。

合计保存43条实际导数记录、15条原函数变差记录、39条log与代理账证书。证书分类为`{'PASS': 38, 'PASS_ZERO_LENGTH': 1}`，实现失败0条。零总质量的拒绝是预期不适用输入，不是CJ-A反例。open/closed连续原函数同值的记录不冒充独立检出实验。

全部计算使用Fraction及整数，log误差由atanh级数的解析有理包围控制。大整数压缩为精确二进制哈希和位数，可由冻结代码与固定菜单重建。未调用浮点区间API、未编译PDF。

数值中的X=1、T_small=4和8ΛV只是核验费用系数的代理账；没有把两原子配置实现为原FULL输入，也未认证远时、初始、跳跃或低pe的全局付款。CJ-A的一般性来自解析证明和独立审查；有限数值只检验列明的局部机制。

从Markdown的REPRO-FILE-BEGIN标记提取numeric.py、numeric_output.jsonl、execution_receipt.json并核哈希，依次运行`python3 numeric.py --stage 1`、`python3 numeric.py --stage 2`、`python3 numeric.py --stage 3`；三个stdout按此顺序拼接即应与保存输出逐字节一致。默认不写文件，--record PATH采用排他创建；每次实际耗时、退出码和输出哈希见收据。

# 复现方法与范围

将下列 REPRO-FILE-BEGIN 标记对应代码块按标记字节数提取为同名文件，
核对 SHA256 后依次运行 `python3 numeric.py --stage 1`、`--stage 2`、`--stage 3`，三个 stdout 按此顺序拼接，应与保存 numeric_output.jsonl 逐字节一致。
不需第三方依赖。默认命令不写文件；记录命令采用排他创建，已有结果时不会覆盖。
运行只复现冻结的有限有理证书，不认证 FIRST/FULL 交通实现性或一般根阶上界。
只保留 LaTeX 文本，未编译 PDF。证明引用的 R114/R115 原交通定义及已付账见相邻轮次归档；
本轮没有删除或替换任何旧来源费用、真实测度或原门。

<!-- REPRO-FILE-BEGIN name="numeric.py" bytes="10657" sha256="1d877b24cb8ea49ba37de12cd12b3430b739c1877f82b2486a70b59fcd311e18" -->
````python
#!/usr/bin/env python3
"""R118 fixed two-atom exact menu; default JSONL stdout, no result writes."""
import argparse
from fractions import Fraction as F
import hashlib
import json
from pathlib import Path
import sys

PROTOCOL_SHA = "7d4346533c53b76d82320ad593df3fd4134119bd8153498d2bd28ed88b548fd1"
LAMBDA = F(128, 119)


class Failure(Exception):
    pass


def exact_hash(value):
    h = hashlib.sha256()

    def feed(v):
        if isinstance(v, F):
            h.update(b"F")
            feed(v.numerator)
            feed(v.denominator)
        elif isinstance(v, int):
            raw = abs(v).to_bytes((abs(v).bit_length() + 7) // 8, "big")
            h.update(b"I" + (b"-" if v < 0 else b"+") + len(raw).to_bytes(8, "big") + raw)
        elif isinstance(v, str):
            raw = v.encode()
            h.update(b"S" + len(raw).to_bytes(8, "big") + raw)
        elif isinstance(v, dict):
            h.update(b"D" + len(v).to_bytes(8, "big"))
            for key in sorted(v):
                feed(key)
                feed(v[key])
        elif isinstance(v, (tuple, list)):
            h.update(b"L" + len(v).to_bytes(8, "big"))
            for item in v:
                feed(item)
        else:
            raise TypeError(type(v).__name__)

    feed(value)
    return h.hexdigest()


def compact(v):
    if isinstance(v, F):
        nb, db = abs(v.numerator).bit_length(), v.denominator.bit_length()
        if max(nb, db) <= 512:
            return {"numerator": str(v.numerator), "denominator": str(v.denominator)}
        return {"sign": (v > 0) - (v < 0), "numerator_bits": nb,
                "denominator_bits": db, "exact_sha256": exact_hash(v)}
    if isinstance(v, dict):
        return {key: compact(item) for key, item in v.items()}
    if isinstance(v, (tuple, list)):
        return [compact(item) for item in v]
    return v


class Output:
    def __init__(self, record):
        self.record = record
        self.undetermined = 0

    def emit(self, kind, **data):
        line = json.dumps(compact({"kind": kind, **data}), sort_keys=True, separators=(",", ":"))
        print(line, flush=True)
        if self.record is not None:
            self.record.write(line + "\n")
            self.record.flush()

    def require(self, condition, check, **data):
        if not condition:
            self.emit("FAIL", check=check, **data)
            raise Failure(check)


def raw_mu(n, a, b, t):
    return (a * t ** (-n), b)


def normalized(n, a, b, t, out):
    mu = raw_mu(n, a, b, t)
    e = sum(mu, F(0))
    out.require(e > 0, "positive_mass", e=e)
    pi = tuple(x / e for x in mu)
    out.require(sum(pi, F(0)) == 1, "probability_mass")
    return mu, e, pi


def derivative(n, a, b, t, out):
    mu, e, pi = normalized(n, a, b, t, out)
    dmu = (-n * a * t ** (-n - 1), F(0))
    de = sum(dmu, F(0))
    dpi = tuple((dmu[i] * e - mu[i] * de) / e ** 2 for i in range(2))
    mean = n * pi[0]
    centered = ((mean - n) * pi[0] / t, mean * pi[1] / t)
    centered_residual = tuple(dpi[i] - centered[i] for i in range(2))
    positive = sum((max(F(0), x) for x in dpi), F(0))
    full_variation = sum((abs(x) for x in dpi), F(0))
    formula = n * pi[0] * (1 - pi[0]) / t
    square_residual = F(n, 4) - t * positive - n * (pi[0] - F(1, 2)) ** 2
    out.require(sum(dpi, F(0)) == 0 and all(x == 0 for x in centered_residual),
                "quotient_centered_derivative", residual=centered_residual)
    out.require(positive == full_variation / 2 == formula and square_residual == 0,
                "positive_rate_range_identity", square_residual=square_residual)
    out.require(dpi[0] <= 0 <= dpi[1], "continuous_primitive_orientation")
    return {"t": t, "dpi": dpi, "P": positive, "full_variation": full_variation,
            "quotient_centered_residual": centered_residual,
            "quotient_mass_residual": sum(dpi, F(0)),
            "half_full_residual": positive - full_variation / 2,
            "closed_rate_residual": positive - formula,
            "square_identity_residual": square_residual,
            "range_margin": F(n, 4) - t * positive}


def log_bounds(r, terms):
    z = (r - 1) / (r + 1)
    lower = 2 * sum((z ** (2 * m + 1) / (2 * m + 1) for m in range(terms)), F(0))
    upper = lower + 2 * z ** (2 * terms + 1) / ((2 * terms + 1) * (1 - z ** 2))
    return lower, upper


def evaluate(out, name, n, k, a=F(1), b=F(1), terms=(2,), r=None):
    r = 1 + F(1, k * n) if r is None else r
    out.require(n > 0 and k > 0 and r >= 1 and a >= 0 and b >= 0 and a + b > 0,
                "valid_abstract_input")
    points = tuple(sorted({F(1), (1 + r) / 2, r}))
    raw = {"name": name, "n": n, "k": k, "a": a, "b": b, "r": r, "points": points}
    input_sha = exact_hash(raw)
    # All observed quantities are computed once, outside the log-precision loop.
    pi0 = normalized(n, a, b, F(1), out)[2]
    pi1 = normalized(n, a, b, r, out)[2]
    variation = pi0[0] - pi1[0]
    predicted = a / (a + b) - a / (a + b * r ** n)
    out.require(variation >= 0 and variation == predicted, "primitive_endpoint_identity",
                residual=variation - predicted)
    if a == b == 1:
        out.require(variation == F(1, 2) - 1 / (1 + r ** n), "basic_closed_variation")
    if r == 1:
        out.require(variation == 0, "zero_length_variation")
    observed_derivatives = tuple(derivative(n, a, b, t, out) for t in points)
    observed_sha = exact_hash({"V": variation, "pi_endpoints": (pi0, pi1),
                               "derivatives": observed_derivatives})
    out.emit("configuration", **raw, input_sha256=input_sha,
             scope="ABSTRACT_TWO_ATOM_NON_FULL", reconstruct="evaluate fixed menu in this code SHA")
    for result in observed_derivatives:
        out.emit("actual_derivative", case=name, **result)
    out.emit("actual_variation", case=name, V=variation, primitive_residual=variation - predicted,
             observed_sha256=observed_sha, method="exact_continuous_primitive_no_quadrature")
    for M in terms:
        lower, upper = log_bounds(r, M)
        pass_margin = F(n, 4) * lower - variation
        fail_margin = variation - F(n, 4) * upper
        if pass_margin >= 0:
            status = "PASS" if r > 1 else "PASS_ZERO_LENGTH"
        elif fail_margin > 0:
            out.require(False, "log_budget_violation", M=M, failure_margin=fail_margin)
        else:
            status = "UNDETERMINED"
            out.undetermined += 1
        log_to_u = F(1, k * n) - upper
        near_margin = F(1, 4 * k) - variation
        epsilon = 2 * LAMBDA / k
        charge = 8 * LAMBDA * variation  # 2Λ times proxy mass 4V, exactly once.
        ledger_margin = epsilon - charge
        out.require(log_to_u >= 0 and near_margin >= 0 and ledger_margin >= 0,
                    "local_proxy_budget", log_to_u=log_to_u, near=near_margin, ledger=ledger_margin)
        out.require(epsilon / (2 * LAMBDA) == F(1, k), "outer_coefficient_identity")
        out.emit("log_and_proxy_certificate", case=name, M=M, status=status,
                 input_sha256=input_sha, observed_sha256=observed_sha,
                 log_lower=lower, log_upper=upper, log_pass_margin=pass_margin,
                 log_failure_margin=fail_margin, log_to_u_residual=log_to_u,
                 near_residual=near_margin, proxy_charge=charge, epsilon=epsilon,
                 ledger_residual=ledger_margin, X=1, T_small=4,
                 scope="SCALAR_PROXY_ONLY_NO_TRAFFIC_OR_FAR_ROOT_CERTIFICATION")
    return variation, observed_derivatives


def stage1(out):
    evaluate(out, "baseline_n4_k16", 4, 16)


def stage2(out):
    V, rates = evaluate(out, "endpoint_and_half_factor", 4, 16)
    # Continuous primitives have no endpoint atoms: both endpoint conventions use V.
    open_integral = V
    closed_integral = V
    out.require(open_integral == closed_integral, "continuous_endpoint_conventions")
    rate_at_one = rates[0]
    wrong_margin = rate_at_one["full_variation"] - F(4, 4)
    out.require(wrong_margin > 0 and rate_at_one["full_variation"] == 2 * rate_at_one["P"],
                "missing_half_factor_detected")
    out.emit("endpoint_and_wrong_half_pressure", open_closed_residual=open_integral - closed_integral,
             wrong_full_as_positive_violation=wrong_margin)
    evaluate(out, "zero_length", 4, 16, r=F(1))
    for label, a, b in (("p0", F(0), F(1)), ("p1", F(1), F(0)),
                        ("small_p", F(1, 1024), F(1)), ("large_p", F(1024), F(1))):
        evaluate(out, label, 4, 16, a, b)
    a = b = F(0)
    e = sum(raw_mu(4, a, b, F(1)), F(0))
    out.require(e == 0, "expected_zero_mass_input")
    out.emit("expected_rejection", case="zero_mass", e=e, reason="normalization_undefined",
             input_sha256=exact_hash({"n": 4, "k": 16, "a": a, "b": b}))


def stage3(out):
    for n in (4, 16, 256, 1024):
        for k in (16, 128):
            evaluate(out, f"expanded_n{n}_k{k}", n, k, terms=(1, 2, 4, 8))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--stage", choices=("1", "2", "3", "all"), default="all")
    parser.add_argument("--record", help="Exclusive-create JSONL copy; never overwrite")
    args = parser.parse_args()
    record = None
    try:
        if args.record:
            record = open(args.record, "x", encoding="utf-8")
        out = Output(record)
        out.emit("run_header", stage=args.stage, protocol_sha256=PROTOCOL_SHA,
                 code_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                 arithmetic="Fraction_only", input_policy="FIXED_INPUT_OBSERVED_ACROSS_M",
                 scope="LOCAL_ABSTRACT_AND_PROXY_ONLY_NON_FULL")
        for stage, function in (("1", stage1), ("2", stage2), ("3", stage3)):
            if args.stage in (stage, "all"):
                before = out.undetermined
                out.emit("stage_start", stage=stage)
                function(out)
                out.emit("stage_complete", stage=stage,
                         result="PASS_FIXED_MENU" if out.undetermined == before else "PASS_WITH_UNDETERMINED")
        out.emit("complete", result="PASS_FIXED_MENU_NO_FULL_PAYMENT_CLAIM" if not out.undetermined
                 else "PASS_WITH_UNDETERMINED", undetermined=out.undetermined)
        return 0
    except Failure:
        return 1
    except Exception as exc:
        print(json.dumps({"kind": "FAIL", "error_type": type(exc).__name__, "message": str(exc)},
                         sort_keys=True), file=sys.stderr)
        return 1
    finally:
        if record is not None:
            record.close()


if __name__ == "__main__":
    raise SystemExit(main())
````
<!-- REPRO-FILE-END -->

<!-- REPRO-FILE-BEGIN name="numeric_output.jsonl" bytes="104488" sha256="48226578218569ba9c0ad147e5cfb2e112ce0cc940e8443ac9aa6a782e6d7fb2" -->
````json
{"arithmetic":"Fraction_only","code_sha256":"1d877b24cb8ea49ba37de12cd12b3430b739c1877f82b2486a70b59fcd311e18","input_policy":"FIXED_INPUT_OBSERVED_ACROSS_M","kind":"run_header","protocol_sha256":"7d4346533c53b76d82320ad593df3fd4134119bd8153498d2bd28ed88b548fd1","scope":"LOCAL_ABSTRACT_AND_PROXY_ONLY_NON_FULL","stage":"1"}
{"kind":"stage_start","stage":"1"}
{"a":{"denominator":"1","numerator":"1"},"b":{"denominator":"1","numerator":"1"},"input_sha256":"f759d54d26ad1d3e925ba4de249748f9d61093fa44bd3f7d96c5a4fa55532b38","k":16,"kind":"configuration","n":4,"name":"baseline_n4_k16","points":[{"denominator":"1","numerator":"1"},{"denominator":"128","numerator":"129"},{"denominator":"64","numerator":"65"}],"r":{"denominator":"64","numerator":"65"},"reconstruct":"evaluate fixed menu in this code SHA","scope":"ABSTRACT_TWO_ATOM_NON_FULL"}
{"P":{"denominator":"1","numerator":"1"},"case":"baseline_n4_k16","closed_rate_residual":{"denominator":"1","numerator":"0"},"dpi":[{"denominator":"1","numerator":"-1"},{"denominator":"1","numerator":"1"}],"full_variation":{"denominator":"1","numerator":"2"},"half_full_residual":{"denominator":"1","numerator":"0"},"kind":"actual_derivative","quotient_centered_residual":[{"denominator":"1","numerator":"0"},{"denominator":"1","numerator":"0"}],"quotient_mass_residual":{"denominator":"1","numerator":"0"},"range_margin":{"denominator":"1","numerator":"0"},"square_identity_residual":{"denominator":"1","numerator":"0"},"t":{"denominator":"1","numerator":"1"}}
{"P":{"denominator":"297415715735405569","numerator":"295038689589854208"},"case":"baseline_n4_k16","closed_rate_residual":{"denominator":"1","numerator":"0"},"dpi":[{"denominator":"297415715735405569","numerator":"-295038689589854208"},{"denominator":"297415715735405569","numerator":"295038689589854208"}],"full_variation":{"denominator":"297415715735405569","numerator":"590077379179708416"},"half_full_residual":{"denominator":"1","numerator":"0"},"kind":"actual_derivative","quotient_centered_residual":[{"denominator":"1","numerator":"0"},{"denominator":"1","numerator":"0"}],"quotient_mass_residual":{"denominator":"1","numerator":"0"},"range_margin":{"denominator":"297415715735405569","numerator":"72036383130625"},"square_identity_residual":{"denominator":"1","numerator":"0"},"t":{"denominator":"128","numerator":"129"}}
{"P":{"denominator":"1199087372321281","numerator":"1179505393664000"},"case":"baseline_n4_k16","closed_rate_residual":{"denominator":"1","numerator":"0"},"dpi":[{"denominator":"1199087372321281","numerator":"-1179505393664000"},{"denominator":"1199087372321281","numerator":"1179505393664000"}],"full_variation":{"denominator":"1199087372321281","numerator":"2359010787328000"},"half_full_residual":{"denominator":"1","numerator":"0"},"kind":"actual_derivative","quotient_centered_residual":[{"denominator":"1","numerator":"0"},{"denominator":"1","numerator":"0"}],"quotient_mass_residual":{"denominator":"1","numerator":"0"},"range_margin":{"denominator":"1199087372321281","numerator":"1152206881281"},"square_identity_residual":{"denominator":"1","numerator":"0"},"t":{"denominator":"64","numerator":"65"}}
{"V":{"denominator":"69255682","numerator":"1073409"},"case":"baseline_n4_k16","kind":"actual_variation","method":"exact_continuous_primitive_no_quadrature","observed_sha256":"12f64dd427b62f5d9fc6edd39c6043fa79f80a3e36dc863b4efdcdf83d29ac0c","primitive_residual":{"denominator":"1","numerator":"0"}}
{"M":2,"T_small":4,"X":1,"case":"baseline_n4_k16","epsilon":{"denominator":"119","numerator":"16"},"input_sha256":"f759d54d26ad1d3e925ba4de249748f9d61093fa44bd3f7d96c5a4fa55532b38","kind":"log_and_proxy_certificate","ledger_residual":{"denominator":"4120713079","numerator":"4460048"},"log_failure_margin":{"denominator":"9277033629982435200","numerator":"-46081628889923"},"log_lower":{"denominator":"6440067","numerator":"99848"},"log_pass_margin":{"denominator":"446011232210694","numerator":"2215457933"},"log_to_u_residual":{"denominator":"267906787200","numerator":"32366747"},"log_upper":{"denominator":"267906787200","numerator":"4153676803"},"near_residual":{"denominator":"2216181824","numerator":"278753"},"observed_sha256":"12f64dd427b62f5d9fc6edd39c6043fa79f80a3e36dc863b4efdcdf83d29ac0c","proxy_charge":{"denominator":"4120713079","numerator":"549585408"},"scope":"SCALAR_PROXY_ONLY_NO_TRAFFIC_OR_FAR_ROOT_CERTIFICATION","status":"PASS"}
{"kind":"stage_complete","result":"PASS_FIXED_MENU","stage":"1"}
{"kind":"complete","result":"PASS_FIXED_MENU_NO_FULL_PAYMENT_CLAIM","undetermined":0}
{"arithmetic":"Fraction_only","code_sha256":"1d877b24cb8ea49ba37de12cd12b3430b739c1877f82b2486a70b59fcd311e18","input_policy":"FIXED_INPUT_OBSERVED_ACROSS_M","kind":"run_header","protocol_sha256":"7d4346533c53b76d82320ad593df3fd4134119bd8153498d2bd28ed88b548fd1","scope":"LOCAL_ABSTRACT_AND_PROXY_ONLY_NON_FULL","stage":"2"}
{"kind":"stage_start","stage":"2"}
{"a":{"denominator":"1","numerator":"1"},"b":{"denominator":"1","numerator":"1"},"input_sha256":"649c16a7bfbe8b6c507c3e50b2e6e45e553e327cef865d9f0bec1fb1aa2d4c16","k":16,"kind":"configuration","n":4,"name":"endpoint_and_half_factor","points":[{"denominator":"1","numerator":"1"},{"denominator":"128","numerator":"129"},{"denominator":"64","numerator":"65"}],"r":{"denominator":"64","numerator":"65"},"reconstruct":"evaluate fixed menu in this code SHA","scope":"ABSTRACT_TWO_ATOM_NON_FULL"}
{"P":{"denominator":"1","numerator":"1"},"case":"endpoint_and_half_factor","closed_rate_residual":{"denominator":"1","numerator":"0"},"dpi":[{"denominator":"1","numerator":"-1"},{"denominator":"1","numerator":"1"}],"full_variation":{"denominator":"1","numerator":"2"},"half_full_residual":{"denominator":"1","numerator":"0"},"kind":"actual_derivative","quotient_centered_residual":[{"denominator":"1","numerator":"0"},{"denominator":"1","numerator":"0"}],"quotient_mass_residual":{"denominator":"1","numerator":"0"},"range_margin":{"denominator":"1","numerator":"0"},"square_identity_residual":{"denominator":"1","numerator":"0"},"t":{"denominator":"1","numerator":"1"}}
{"P":{"denominator":"297415715735405569","numerator":"295038689589854208"},"case":"endpoint_and_half_factor","closed_rate_residual":{"denominator":"1","numerator":"0"},"dpi":[{"denominator":"297415715735405569","numerator":"-295038689589854208"},{"denominator":"297415715735405569","numerator":"295038689589854208"}],"full_variation":{"denominator":"297415715735405569","numerator":"590077379179708416"},"half_full_residual":{"denominator":"1","numerator":"0"},"kind":"actual_derivative","quotient_centered_residual":[{"denominator":"1","numerator":"0"},{"denominator":"1","numerator":"0"}],"quotient_mass_residual":{"denominator":"1","numerator":"0"},"range_margin":{"denominator":"297415715735405569","numerator":"72036383130625"},"square_identity_residual":{"denominator":"1","numerator":"0"},"t":{"denominator":"128","numerator":"129"}}
{"P":{"denominator":"1199087372321281","numerator":"1179505393664000"},"case":"endpoint_and_half_factor","closed_rate_residual":{"denominator":"1","numerator":"0"},"dpi":[{"denominator":"1199087372321281","numerator":"-1179505393664000"},{"denominator":"1199087372321281","numerator":"1179505393664000"}],"full_variation":{"denominator":"1199087372321281","numerator":"2359010787328000"},"half_full_residual":{"denominator":"1","numerator":"0"},"kind":"actual_derivative","quotient_centered_residual":[{"denominator":"1","numerator":"0"},{"denominator":"1","numerator":"0"}],"quotient_mass_residual":{"denominator":"1","numerator":"0"},"range_margin":{"denominator":"1199087372321281","numerator":"1152206881281"},"square_identity_residual":{"denominator":"1","numerator":"0"},"t":{"denominator":"64","numerator":"65"}}
{"V":{"denominator":"69255682","numerator":"1073409"},"case":"endpoint_and_half_factor","kind":"actual_variation","method":"exact_continuous_primitive_no_quadrature","observed_sha256":"12f64dd427b62f5d9fc6edd39c6043fa79f80a3e36dc863b4efdcdf83d29ac0c","primitive_residual":{"denominator":"1","numerator":"0"}}
{"M":2,"T_small":4,"X":1,"case":"endpoint_and_half_factor","epsilon":{"denominator":"119","numerator":"16"},"input_sha256":"649c16a7bfbe8b6c507c3e50b2e6e45e553e327cef865d9f0bec1fb1aa2d4c16","kind":"log_and_proxy_certificate","ledger_residual":{"denominator":"4120713079","numerator":"4460048"},"log_failure_margin":{"denominator":"9277033629982435200","numerator":"-46081628889923"},"log_lower":{"denominator":"6440067","numerator":"99848"},"log_pass_margin":{"denominator":"446011232210694","numerator":"2215457933"},"log_to_u_residual":{"denominator":"267906787200","numerator":"32366747"},"log_upper":{"denominator":"267906787200","numerator":"4153676803"},"near_residual":{"denominator":"2216181824","numerator":"278753"},"observed_sha256":"12f64dd427b62f5d9fc6edd39c6043fa79f80a3e36dc863b4efdcdf83d29ac0c","proxy_charge":{"denominator":"4120713079","numerator":"549585408"},"scope":"SCALAR_PROXY_ONLY_NO_TRAFFIC_OR_FAR_ROOT_CERTIFICATION","status":"PASS"}
{"kind":"endpoint_and_wrong_half_pressure","open_closed_residual":{"denominator":"1","numerator":"0"},"wrong_full_as_positive_violation":{"denominator":"1","numerator":"1"}}
{"a":{"denominator":"1","numerator":"1"},"b":{"denominator":"1","numerator":"1"},"input_sha256":"53de12ae1b887920e2c224062ea71610ffb44738f4a97a94036005d926c07796","k":16,"kind":"configuration","n":4,"name":"zero_length","points":[{"denominator":"1","numerator":"1"}],"r":{"denominator":"1","numerator":"1"},"reconstruct":"evaluate fixed menu in this code SHA","scope":"ABSTRACT_TWO_ATOM_NON_FULL"}
{"P":{"denominator":"1","numerator":"1"},"case":"zero_length","closed_rate_residual":{"denominator":"1","numerator":"0"},"dpi":[{"denominator":"1","numerator":"-1"},{"denominator":"1","numerator":"1"}],"full_variation":{"denominator":"1","numerator":"2"},"half_full_residual":{"denominator":"1","numerator":"0"},"kind":"actual_derivative","quotient_centered_residual":[{"denominator":"1","numerator":"0"},{"denominator":"1","numerator":"0"}],"quotient_mass_residual":{"denominator":"1","numerator":"0"},"range_margin":{"denominator":"1","numerator":"0"},"square_identity_residual":{"denominator":"1","numerator":"0"},"t":{"denominator":"1","numerator":"1"}}
{"V":{"denominator":"1","numerator":"0"},"case":"zero_length","kind":"actual_variation","method":"exact_continuous_primitive_no_quadrature","observed_sha256":"794ad839fcda82d21f8ad16d3366d1268cc489c9d81f8b8cfb10067f1d0a87a6","primitive_residual":{"denominator":"1","numerator":"0"}}
{"M":2,"T_small":4,"X":1,"case":"zero_length","epsilon":{"denominator":"119","numerator":"16"},"input_sha256":"53de12ae1b887920e2c224062ea71610ffb44738f4a97a94036005d926c07796","kind":"log_and_proxy_certificate","ledger_residual":{"denominator":"119","numerator":"16"},"log_failure_margin":{"denominator":"1","numerator":"0"},"log_lower":{"denominator":"1","numerator":"0"},"log_pass_margin":{"denominator":"1","numerator":"0"},"log_to_u_residual":{"denominator":"64","numerator":"1"},"log_upper":{"denominator":"1","numerator":"0"},"near_residual":{"denominator":"64","numerator":"1"},"observed_sha256":"794ad839fcda82d21f8ad16d3366d1268cc489c9d81f8b8cfb10067f1d0a87a6","proxy_charge":{"denominator":"1","numerator":"0"},"scope":"SCALAR_PROXY_ONLY_NO_TRAFFIC_OR_FAR_ROOT_CERTIFICATION","status":"PASS_ZERO_LENGTH"}
{"a":{"denominator":"1","numerator":"0"},"b":{"denominator":"1","numerator":"1"},"input_sha256":"ee68d7a0971f28cdf6fe64111686bd4b12ed0288abb91f4e3b9b83cd028cf238","k":16,"kind":"configuration","n":4,"name":"p0","points":[{"denominator":"1","numerator":"1"},{"denominator":"128","numerator":"129"},{"denominator":"64","numerator":"65"}],"r":{"denominator":"64","numerator":"65"},"reconstruct":"evaluate fixed menu in this code SHA","scope":"ABSTRACT_TWO_ATOM_NON_FULL"}
{"P":{"denominator":"1","numerator":"0"},"case":"p0","closed_rate_residual":{"denominator":"1","numerator":"0"},"dpi":[{"denominator":"1","numerator":"0"},{"denominator":"1","numerator":"0"}],"full_variation":{"denominator":"1","numerator":"0"},"half_full_residual":{"denominator":"1","numerator":"0"},"kind":"actual_derivative","quotient_centered_residual":[{"denominator":"1","numerator":"0"},{"denominator":"1","numerator":"0"}],"quotient_mass_residual":{"denominator":"1","numerator":"0"},"range_margin":{"denominator":"1","numerator":"1"},"square_identity_residual":{"denominator":"1","numerator":"0"},"t":{"denominator":"1","numerator":"1"}}
{"P":{"denominator":"1","numerator":"0"},"case":"p0","closed_rate_residual":{"denominator":"1","numerator":"0"},"dpi":[{"denominator":"1","numerator":"0"},{"denominator":"1","numerator":"0"}],"full_variation":{"denominator":"1","numerator":"0"},"half_full_residual":{"denominator":"1","numerator":"0"},"kind":"actual_derivative","quotient_centered_residual":[{"denominator":"1","numerator":"0"},{"denominator":"1","numerator":"0"}],"quotient_mass_residual":{"denominator":"1","numerator":"0"},"range_margin":{"denominator":"1","numerator":"1"},"square_identity_residual":{"denominator":"1","numerator":"0"},"t":{"denominator":"128","numerator":"129"}}
{"P":{"denominator":"1","numerator":"0"},"case":"p0","closed_rate_residual":{"denominator":"1","numerator":"0"},"dpi":[{"denominator":"1","numerator":"0"},{"denominator":"1","numerator":"0"}],"full_variation":{"denominator":"1","numerator":"0"},"half_full_residual":{"denominator":"1","numerator":"0"},"kind":"actual_derivative","quotient_centered_residual":[{"denominator":"1","numerator":"0"},{"denominator":"1","numerator":"0"}],"quotient_mass_residual":{"denominator":"1","numerator":"0"},"range_margin":{"denominator":"1","numerator":"1"},"square_identity_residual":{"denominator":"1","numerator":"0"},"t":{"denominator":"64","numerator":"65"}}
{"V":{"denominator":"1","numerator":"0"},"case":"p0","kind":"actual_variation","method":"exact_continuous_primitive_no_quadrature","observed_sha256":"704fef990a975ff30f1a2f079983b1ec11a14a48e8cc8c480283aac09a22c08c","primitive_residual":{"denominator":"1","numerator":"0"}}
{"M":2,"T_small":4,"X":1,"case":"p0","epsilon":{"denominator":"119","numerator":"16"},"input_sha256":"ee68d7a0971f28cdf6fe64111686bd4b12ed0288abb91f4e3b9b83cd028cf238","kind":"log_and_proxy_certificate","ledger_residual":{"denominator":"119","numerator":"16"},"log_failure_margin":{"denominator":"267906787200","numerator":"-4153676803"},"log_lower":{"denominator":"6440067","numerator":"99848"},"log_pass_margin":{"denominator":"6440067","numerator":"99848"},"log_to_u_residual":{"denominator":"267906787200","numerator":"32366747"},"log_upper":{"denominator":"267906787200","numerator":"4153676803"},"near_residual":{"denominator":"64","numerator":"1"},"observed_sha256":"704fef990a975ff30f1a2f079983b1ec11a14a48e8cc8c480283aac09a22c08c","proxy_charge":{"denominator":"1","numerator":"0"},"scope":"SCALAR_PROXY_ONLY_NO_TRAFFIC_OR_FAR_ROOT_CERTIFICATION","status":"PASS"}
{"a":{"denominator":"1","numerator":"1"},"b":{"denominator":"1","numerator":"0"},"input_sha256":"e9f78eee0ff88159eec945c0b99e65ebbd5f18b8d13f3be87e031de01f78fc94","k":16,"kind":"configuration","n":4,"name":"p1","points":[{"denominator":"1","numerator":"1"},{"denominator":"128","numerator":"129"},{"denominator":"64","numerator":"65"}],"r":{"denominator":"64","numerator":"65"},"reconstruct":"evaluate fixed menu in this code SHA","scope":"ABSTRACT_TWO_ATOM_NON_FULL"}
{"P":{"denominator":"1","numerator":"0"},"case":"p1","closed_rate_residual":{"denominator":"1","numerator":"0"},"dpi":[{"denominator":"1","numerator":"0"},{"denominator":"1","numerator":"0"}],"full_variation":{"denominator":"1","numerator":"0"},"half_full_residual":{"denominator":"1","numerator":"0"},"kind":"actual_derivative","quotient_centered_residual":[{"denominator":"1","numerator":"0"},{"denominator":"1","numerator":"0"}],"quotient_mass_residual":{"denominator":"1","numerator":"0"},"range_margin":{"denominator":"1","numerator":"1"},"square_identity_residual":{"denominator":"1","numerator":"0"},"t":{"denominator":"1","numerator":"1"}}
{"P":{"denominator":"1","numerator":"0"},"case":"p1","closed_rate_residual":{"denominator":"1","numerator":"0"},"dpi":[{"denominator":"1","numerator":"0"},{"denominator":"1","numerator":"0"}],"full_variation":{"denominator":"1","numerator":"0"},"half_full_residual":{"denominator":"1","numerator":"0"},"kind":"actual_derivative","quotient_centered_residual":[{"denominator":"1","numerator":"0"},{"denominator":"1","numerator":"0"}],"quotient_mass_residual":{"denominator":"1","numerator":"0"},"range_margin":{"denominator":"1","numerator":"1"},"square_identity_residual":{"denominator":"1","numerator":"0"},"t":{"denominator":"128","numerator":"129"}}
{"P":{"denominator":"1","numerator":"0"},"case":"p1","closed_rate_residual":{"denominator":"1","numerator":"0"},"dpi":[{"denominator":"1","numerator":"0"},{"denominator":"1","numerator":"0"}],"full_variation":{"denominator":"1","numerator":"0"},"half_full_residual":{"denominator":"1","numerator":"0"},"kind":"actual_derivative","quotient_centered_residual":[{"denominator":"1","numerator":"0"},{"denominator":"1","numerator":"0"}],"quotient_mass_residual":{"denominator":"1","numerator":"0"},"range_margin":{"denominator":"1","numerator":"1"},"square_identity_residual":{"denominator":"1","numerator":"0"},"t":{"denominator":"64","numerator":"65"}}
{"V":{"denominator":"1","numerator":"0"},"case":"p1","kind":"actual_variation","method":"exact_continuous_primitive_no_quadrature","observed_sha256":"673c84aaabbedca2d8cf7fca137bcb8ad52cb4ac73e7fdbf34b09f58a9b2c487","primitive_residual":{"denominator":"1","numerator":"0"}}
{"M":2,"T_small":4,"X":1,"case":"p1","epsilon":{"denominator":"119","numerator":"16"},"input_sha256":"e9f78eee0ff88159eec945c0b99e65ebbd5f18b8d13f3be87e031de01f78fc94","kind":"log_and_proxy_certificate","ledger_residual":{"denominator":"119","numerator":"16"},"log_failure_margin":{"denominator":"267906787200","numerator":"-4153676803"},"log_lower":{"denominator":"6440067","numerator":"99848"},"log_pass_margin":{"denominator":"6440067","numerator":"99848"},"log_to_u_residual":{"denominator":"267906787200","numerator":"32366747"},"log_upper":{"denominator":"267906787200","numerator":"4153676803"},"near_residual":{"denominator":"64","numerator":"1"},"observed_sha256":"673c84aaabbedca2d8cf7fca137bcb8ad52cb4ac73e7fdbf34b09f58a9b2c487","proxy_charge":{"denominator":"1","numerator":"0"},"scope":"SCALAR_PROXY_ONLY_NO_TRAFFIC_OR_FAR_ROOT_CERTIFICATION","status":"PASS"}
{"a":{"denominator":"1024","numerator":"1"},"b":{"denominator":"1","numerator":"1"},"input_sha256":"8b90b798295d205968ccd571f424b1a50d0377ade070ade2c451dd7318d58614","k":16,"kind":"configuration","n":4,"name":"small_p","points":[{"denominator":"1","numerator":"1"},{"denominator":"128","numerator":"129"},{"denominator":"64","numerator":"65"}],"r":{"denominator":"64","numerator":"65"},"reconstruct":"evaluate fixed menu in this code SHA","scope":"ABSTRACT_TWO_ATOM_NON_FULL"}
{"P":{"denominator":"1050625","numerator":"4096"},"case":"small_p","closed_rate_residual":{"denominator":"1","numerator":"0"},"dpi":[{"denominator":"1050625","numerator":"-4096"},{"denominator":"1050625","numerator":"4096"}],"full_variation":{"denominator":"1050625","numerator":"8192"},"half_full_residual":{"denominator":"1","numerator":"0"},"kind":"actual_derivative","quotient_centered_residual":[{"denominator":"1","numerator":"0"},{"denominator":"1","numerator":"0"}],"quotient_mass_residual":{"denominator":"1","numerator":"0"},"range_margin":{"denominator":"1050625","numerator":"1046529"},"square_identity_residual":{"denominator":"1","numerator":"0"},"t":{"denominator":"1","numerator":"1"}}
{"P":{"denominator":"76831538084250625","numerator":"288123720302592"},"case":"small_p","closed_rate_residual":{"denominator":"1","numerator":"0"},"dpi":[{"denominator":"76831538084250625","numerator":"-288123720302592"},{"denominator":"76831538084250625","numerator":"288123720302592"}],"full_variation":{"denominator":"76831538084250625","numerator":"576247440605184"},"half_full_residual":{"denominator":"1","numerator":"0"},"kind":"actual_derivative","quotient_centered_residual":[{"denominator":"1","numerator":"0"},{"denominator":"1","numerator":"0"}],"quotient_mass_residual":{"denominator":"1","numerator":"0"},"range_margin":{"denominator":"76831538084250625","numerator":"76541163397383169"},"square_identity_residual":{"denominator":"1","numerator":"0"},"t":{"denominator":"128","numerator":"129"}}
{"P":{"denominator":"319230010606081","numerator":"1151860736000"},"case":"small_p","closed_rate_residual":{"denominator":"1","numerator":"0"},"dpi":[{"denominator":"319230010606081","numerator":"-1151860736000"},{"denominator":"319230010606081","numerator":"1151860736000"}],"full_variation":{"denominator":"319230010606081","numerator":"2303721472000"},"half_full_residual":{"denominator":"1","numerator":"0"},"kind":"actual_derivative","quotient_centered_residual":[{"denominator":"1","numerator":"0"},{"denominator":"1","numerator":"0"}],"quotient_mass_residual":{"denominator":"1","numerator":"0"},"range_margin":{"denominator":"319230010606081","numerator":"318060152046081"},"square_identity_residual":{"denominator":"1","numerator":"0"},"t":{"denominator":"64","numerator":"65"}}
{"V":{"denominator":"18313684225","numerator":"1073409"},"case":"small_p","kind":"actual_variation","method":"exact_continuous_primitive_no_quadrature","observed_sha256":"eb2769b6ce7040e4e850119824ca2b324cc44ec27106c74c39e9c0d38bbc6242","primitive_residual":{"denominator":"1","numerator":"0"}}
{"M":2,"T_small":4,"X":1,"case":"small_p","epsilon":{"denominator":"119","numerator":"16"},"input_sha256":"8b90b798295d205968ccd571f424b1a50d0377ade070ade2c451dd7318d58614","kind":"log_and_proxy_certificate","ledger_residual":{"denominator":"2179328422775","numerator":"291919776784"},"log_failure_margin":{"denominator":"39250882420120575360","numerator":"-606252414290463743"},"log_lower":{"denominator":"6440067","numerator":"99848"},"log_pass_margin":{"denominator":"117941353425843075","numerator":"1821671916619397"},"log_to_u_residual":{"denominator":"267906787200","numerator":"32366747"},"log_upper":{"denominator":"267906787200","numerator":"4153676803"},"near_residual":{"denominator":"1172075790400","numerator":"18244986049"},"observed_sha256":"eb2769b6ce7040e4e850119824ca2b324cc44ec27106c74c39e9c0d38bbc6242","proxy_charge":{"denominator":"2179328422775","numerator":"1099170816"},"scope":"SCALAR_PROXY_ONLY_NO_TRAFFIC_OR_FAR_ROOT_CERTIFICATION","status":"PASS"}
{"a":{"denominator":"1","numerator":"1024"},"b":{"denominator":"1","numerator":"1"},"input_sha256":"71bdf537e11ed0bfc0bb54e64a48ac278bad588317c3fed87327ea8b79430c57","k":16,"kind":"configuration","n":4,"name":"large_p","points":[{"denominator":"1","numerator":"1"},{"denominator":"128","numerator":"129"},{"denominator":"64","numerator":"65"}],"r":{"denominator":"64","numerator":"65"},"reconstruct":"evaluate fixed menu in this code SHA","scope":"ABSTRACT_TWO_ATOM_NON_FULL"}
{"P":{"denominator":"1050625","numerator":"4096"},"case":"large_p","closed_rate_residual":{"denominator":"1","numerator":"0"},"dpi":[{"denominator":"1050625","numerator":"-4096"},{"denominator":"1050625","numerator":"4096"}],"full_variation":{"denominator":"1050625","numerator":"8192"},"half_full_residual":{"denominator":"1","numerator":"0"},"kind":"actual_derivative","quotient_centered_residual":[{"denominator":"1","numerator":"0"},{"denominator":"1","numerator":"0"}],"quotient_mass_residual":{"denominator":"1","numerator":"0"},"range_margin":{"denominator":"1050625","numerator":"1046529"},"square_identity_residual":{"denominator":"1","numerator":"0"},"t":{"denominator":"1","numerator":"1"}}
{"P":{"denominator":"75710180376024709530625","numerator":"302119618140010708992"},"case":"large_p","closed_rate_residual":{"denominator":"1","numerator":"0"},"dpi":[{"denominator":"75710180376024709530625","numerator":"-302119618140010708992"},{"denominator":"75710180376024709530625","numerator":"302119618140010708992"}],"full_variation":{"denominator":"75710180376024709530625","numerator":"604239236280021417984"},"half_full_residual":{"denominator":"1","numerator":"0"},"kind":"actual_derivative","quotient_centered_residual":[{"denominator":"1","numerator":"0"},{"denominator":"1","numerator":"0"}],"quotient_mass_residual":{"denominator":"1","numerator":"0"},"range_margin":{"denominator":"75710180376024709530625","numerator":"75405700448367979987969"},"square_identity_residual":{"denominator":"1","numerator":"0"},"t":{"denominator":"128","numerator":"129"}}
{"P":{"denominator":"295761566628870996481","numerator":"1207813523111936000"},"case":"large_p","closed_rate_residual":{"denominator":"1","numerator":"0"},"dpi":[{"denominator":"295761566628870996481","numerator":"-1207813523111936000"},{"denominator":"295761566628870996481","numerator":"1207813523111936000"}],"full_variation":{"denominator":"295761566628870996481","numerator":"2415627046223872000"},"half_full_residual":{"denominator":"1","numerator":"0"},"kind":"actual_derivative","quotient_centered_residual":[{"denominator":"1","numerator":"0"},{"denominator":"1","numerator":"0"}],"quotient_mass_residual":{"denominator":"1","numerator":"0"},"range_margin":{"denominator":"295761566628870996481","numerator":"294534881019460436481"},"square_identity_residual":{"denominator":"1","numerator":"0"},"t":{"denominator":"64","numerator":"65"}}
{"V":{"denominator":"17627662804225","numerator":"1099170816"},"case":"large_p","kind":"actual_variation","method":"exact_continuous_primitive_no_quadrature","observed_sha256":"d6c9143ef4e4a073b59468d94544f318cf7c16d94db348cc88afe29d93dfab13","primitive_residual":{"denominator":"1","numerator":"0"}}
{"M":2,"T_small":4,"X":1,"case":"large_p","epsilon":{"denominator":"119","numerator":"16"},"input_sha256":"71bdf537e11ed0bfc0bb54e64a48ac278bad588317c3fed87327ea8b79430c57","kind":"log_and_proxy_certificate","ledger_residual":{"denominator":"2097691873702775","numerator":"280917053952016"},"log_failure_margin":{"denominator":"188902820308994493436800","numerator":"-2917005550364670021499"},"log_lower":{"denominator":"6440067","numerator":"99848"},"log_pass_margin":{"denominator":"113523329512616883075","numerator":"1753008141976773128"},"log_to_u_residual":{"denominator":"267906787200","numerator":"32366747"},"log_upper":{"denominator":"267906787200","numerator":"4153676803"},"near_residual":{"denominator":"1128170419470400","numerator":"17557315872001"},"observed_sha256":"d6c9143ef4e4a073b59468d94544f318cf7c16d94db348cc88afe29d93dfab13","proxy_charge":{"denominator":"2097691873702775","numerator":"1125550915584"},"scope":"SCALAR_PROXY_ONLY_NO_TRAFFIC_OR_FAR_ROOT_CERTIFICATION","status":"PASS"}
{"case":"zero_mass","e":{"denominator":"1","numerator":"0"},"input_sha256":"11fe4d3ce244ae5e6ce3fc219e171afcb686968ac7805b72b1b58cae8bad5f5e","kind":"expected_rejection","reason":"normalization_undefined"}
{"kind":"stage_complete","result":"PASS_FIXED_MENU","stage":"2"}
{"kind":"complete","result":"PASS_FIXED_MENU_NO_FULL_PAYMENT_CLAIM","undetermined":0}
{"arithmetic":"Fraction_only","code_sha256":"1d877b24cb8ea49ba37de12cd12b3430b739c1877f82b2486a70b59fcd311e18","input_policy":"FIXED_INPUT_OBSERVED_ACROSS_M","kind":"run_header","protocol_sha256":"7d4346533c53b76d82320ad593df3fd4134119bd8153498d2bd28ed88b548fd1","scope":"LOCAL_ABSTRACT_AND_PROXY_ONLY_NON_FULL","stage":"3"}
{"kind":"stage_start","stage":"3"}
{"a":{"denominator":"1","numerator":"1"},"b":{"denominator":"1","numerator":"1"},"input_sha256":"894af604583a80fea0c838384083881e8e0596066fee7c8035f51a0910d6286d","k":16,"kind":"configuration","n":4,"name":"expanded_n4_k16","points":[{"denominator":"1","numerator":"1"},{"denominator":"128","numerator":"129"},{"denominator":"64","numerator":"65"}],"r":{"denominator":"64","numerator":"65"},"reconstruct":"evaluate fixed menu in this code SHA","scope":"ABSTRACT_TWO_ATOM_NON_FULL"}
{"P":{"denominator":"1","numerator":"1"},"case":"expanded_n4_k16","closed_rate_residual":{"denominator":"1","numerator":"0"},"dpi":[{"denominator":"1","numerator":"-1"},{"denominator":"1","numerator":"1"}],"full_variation":{"denominator":"1","numerator":"2"},"half_full_residual":{"denominator":"1","numerator":"0"},"kind":"actual_derivative","quotient_centered_residual":[{"denominator":"1","numerator":"0"},{"denominator":"1","numerator":"0"}],"quotient_mass_residual":{"denominator":"1","numerator":"0"},"range_margin":{"denominator":"1","numerator":"0"},"square_identity_residual":{"denominator":"1","numerator":"0"},"t":{"denominator":"1","numerator":"1"}}
{"P":{"denominator":"297415715735405569","numerator":"295038689589854208"},"case":"expanded_n4_k16","closed_rate_residual":{"denominator":"1","numerator":"0"},"dpi":[{"denominator":"297415715735405569","numerator":"-295038689589854208"},{"denominator":"297415715735405569","numerator":"295038689589854208"}],"full_variation":{"denominator":"297415715735405569","numerator":"590077379179708416"},"half_full_residual":{"denominator":"1","numerator":"0"},"kind":"actual_derivative","quotient_centered_residual":[{"denominator":"1","numerator":"0"},{"denominator":"1","numerator":"0"}],"quotient_mass_residual":{"denominator":"1","numerator":"0"},"range_margin":{"denominator":"297415715735405569","numerator":"72036383130625"},"square_identity_residual":{"denominator":"1","numerator":"0"},"t":{"denominator":"128","numerator":"129"}}
{"P":{"denominator":"1199087372321281","numerator":"1179505393664000"},"case":"expanded_n4_k16","closed_rate_residual":{"denominator":"1","numerator":"0"},"dpi":[{"denominator":"1199087372321281","numerator":"-1179505393664000"},{"denominator":"1199087372321281","numerator":"1179505393664000"}],"full_variation":{"denominator":"1199087372321281","numerator":"2359010787328000"},"half_full_residual":{"denominator":"1","numerator":"0"},"kind":"actual_derivative","quotient_centered_residual":[{"denominator":"1","numerator":"0"},{"denominator":"1","numerator":"0"}],"quotient_mass_residual":{"denominator":"1","numerator":"0"},"range_margin":{"denominator":"1199087372321281","numerator":"1152206881281"},"square_identity_residual":{"denominator":"1","numerator":"0"},"t":{"denominator":"64","numerator":"65"}}
{"V":{"denominator":"69255682","numerator":"1073409"},"case":"expanded_n4_k16","kind":"actual_variation","method":"exact_continuous_primitive_no_quadrature","observed_sha256":"12f64dd427b62f5d9fc6edd39c6043fa79f80a3e36dc863b4efdcdf83d29ac0c","primitive_residual":{"denominator":"1","numerator":"0"}}
{"M":1,"T_small":4,"X":1,"case":"expanded_n4_k16","epsilon":{"denominator":"119","numerator":"16"},"input_sha256":"894af604583a80fea0c838384083881e8e0596066fee7c8035f51a0910d6286d","kind":"log_and_proxy_certificate","ledger_residual":{"denominator":"4120713079","numerator":"4460048"},"log_failure_margin":{"denominator":"111496107565440","numerator":"-553833281"},"log_lower":{"denominator":"129","numerator":"2"},"log_pass_margin":{"denominator":"8933982978","numerator":"41603"},"log_to_u_residual":{"denominator":"3219840","numerator":"389"},"log_upper":{"denominator":"3219840","numerator":"49921"},"near_residual":{"denominator":"2216181824","numerator":"278753"},"observed_sha256":"12f64dd427b62f5d9fc6edd39c6043fa79f80a3e36dc863b4efdcdf83d29ac0c","proxy_charge":{"denominator":"4120713079","numerator":"549585408"},"scope":"SCALAR_PROXY_ONLY_NO_TRAFFIC_OR_FAR_ROOT_CERTIFICATION","status":"PASS"}
{"M":2,"T_small":4,"X":1,"case":"expanded_n4_k16","epsilon":{"denominator":"119","numerator":"16"},"input_sha256":"894af604583a80fea0c838384083881e8e0596066fee7c8035f51a0910d6286d","kind":"log_and_proxy_certificate","ledger_residual":{"denominator":"4120713079","numerator":"4460048"},"log_failure_margin":{"denominator":"9277033629982435200","numerator":"-46081628889923"},"log_lower":{"denominator":"6440067","numerator":"99848"},"log_pass_margin":{"denominator":"446011232210694","numerator":"2215457933"},"log_to_u_residual":{"denominator":"267906787200","numerator":"32366747"},"log_upper":{"denominator":"267906787200","numerator":"4153676803"},"near_residual":{"denominator":"2216181824","numerator":"278753"},"observed_sha256":"12f64dd427b62f5d9fc6edd39c6043fa79f80a3e36dc863b4efdcdf83d29ac0c","proxy_charge":{"denominator":"4120713079","numerator":"549585408"},"scope":"SCALAR_PROXY_ONLY_NO_TRAFFIC_OR_FAR_ROOT_CERTIFICATION","status":"PASS"}
{"M":4,"T_small":4,"X":1,"case":"expanded_n4_k16","epsilon":{"denominator":"119","numerator":"16"},"input_sha256":"894af604583a80fea0c838384083881e8e0596066fee7c8035f51a0910d6286d","kind":"log_and_proxy_certificate","ledger_residual":{"denominator":"4120713079","numerator":"4460048"},"log_failure_margin":{"denominator":"10789896095784220526915207040","numerator":"-53596441218080757815111"},"log_lower":{"denominator":"20806355587185315","numerator":"322585618157344"},"log_pass_margin":{"denominator":"1440958346125029450709830","numerator":"7157644393440239773"},"log_to_u_residual":{"denominator":"311595981273687277440","numerator":"37644989876979959"},"log_upper":{"denominator":"311595981273687277440","numerator":"4831042217524383751"},"near_residual":{"denominator":"2216181824","numerator":"278753"},"observed_sha256":"12f64dd427b62f5d9fc6edd39c6043fa79f80a3e36dc863b4efdcdf83d29ac0c","proxy_charge":{"denominator":"4120713079","numerator":"549585408"},"scope":"SCALAR_PROXY_ONLY_NO_TRAFFIC_OR_FAR_ROOT_CERTIFICATION","status":"PASS"}
{"M":8,"T_small":4,"X":1,"case":"expanded_n4_k16","epsilon":{"denominator":"119","numerator":"16"},"input_sha256":"894af604583a80fea0c838384083881e8e0596066fee7c8035f51a0910d6286d","kind":"log_and_proxy_certificate","ledger_residual":{"denominator":"4120713079","numerator":"4460048"},"log_failure_margin":{"denominator":"51576907267227905668184758638112672701940517760","numerator":"-256196969277438420033067453151976179540519"},"log_lower":{"denominator":"684496120477532061442721474183421735","numerator":"10612555535028203078585463960619648"},"log_pass_margin":{"denominator":"47405245650025648592081579630618265351048270","numerator":"235475155585880900765686997382323695321"},"log_to_u_residual":{"denominator":"1489463558159109765699361927823125695360","numerator":"179947252014720190050560543927984711"},"log_upper":{"denominator":"1489463558159109765699361927823125695360","numerator":"23092920844221369899001969578308354279"},"near_residual":{"denominator":"2216181824","numerator":"278753"},"observed_sha256":"12f64dd427b62f5d9fc6edd39c6043fa79f80a3e36dc863b4efdcdf83d29ac0c","proxy_charge":{"denominator":"4120713079","numerator":"549585408"},"scope":"SCALAR_PROXY_ONLY_NO_TRAFFIC_OR_FAR_ROOT_CERTIFICATION","status":"PASS"}
{"a":{"denominator":"1","numerator":"1"},"b":{"denominator":"1","numerator":"1"},"input_sha256":"f358fcf9bca10991a2fbb8cfe7d7fb4ca3aa0d0a9969186774485f312d0ab490","k":128,"kind":"configuration","n":4,"name":"expanded_n4_k128","points":[{"denominator":"1","numerator":"1"},{"denominator":"1024","numerator":"1025"},{"denominator":"512","numerator":"513"}],"r":{"denominator":"512","numerator":"513"},"reconstruct":"evaluate fixed menu in this code SHA","scope":"ABSTRACT_TWO_ATOM_NON_FULL"}
{"P":{"denominator":"1","numerator":"1"},"case":"expanded_n4_k128","closed_rate_residual":{"denominator":"1","numerator":"0"},"dpi":[{"denominator":"1","numerator":"-1"},{"denominator":"1","numerator":"1"}],"full_variation":{"denominator":"1","numerator":"2"},"half_full_residual":{"denominator":"1","numerator":"0"},"kind":"actual_derivative","quotient_centered_residual":[{"denominator":"1","numerator":"0"},{"denominator":"1","numerator":"0"}],"quotient_mass_residual":{"denominator":"1","numerator":"0"},"range_margin":{"denominator":"1","numerator":"0"},"square_identity_residual":{"denominator":"1","numerator":"0"},"t":{"denominator":"1","numerator":"1"}}
{"P":{"denominator":"4854638933386998587596801","numerator":"4849884217468780544000000"},"case":"expanded_n4_k128","closed_rate_residual":{"denominator":"1","numerator":"0"},"dpi":[{"denominator":"4854638933386998587596801","numerator":"-4849884217468780544000000"},{"denominator":"4854638933386998587596801","numerator":"4849884217468780544000000"}],"full_variation":{"denominator":"4854638933386998587596801","numerator":"9699768434937561088000000"},"half_full_residual":{"denominator":"1","numerator":"0"},"kind":"actual_derivative","quotient_centered_residual":[{"denominator":"1","numerator":"0"},{"denominator":"1","numerator":"0"}],"quotient_mass_residual":{"denominator":"1","numerator":"0"},"range_margin":{"denominator":"4854638933386998587596801","numerator":"18500862096187596801"},"square_identity_residual":{"denominator":"1","numerator":"0"},"t":{"denominator":"1024","numerator":"1025"}}
{"P":{"denominator":"19037762716763776094209","numerator":"19000362709440440303616"},"case":"expanded_n4_k128","closed_rate_residual":{"denominator":"1","numerator":"0"},"dpi":[{"denominator":"19037762716763776094209","numerator":"-19000362709440440303616"},{"denominator":"19037762716763776094209","numerator":"19000362709440440303616"}],"full_variation":{"denominator":"19037762716763776094209","numerator":"38000725418880880607232"},"half_full_residual":{"denominator":"1","numerator":"0"},"kind":"actual_derivative","quotient_centered_residual":[{"denominator":"1","numerator":"0"},{"denominator":"1","numerator":"0"}],"quotient_mass_residual":{"denominator":"1","numerator":"0"},"range_margin":{"denominator":"19037762716763776094209","numerator":"289923906459930625"},"square_identity_residual":{"denominator":"1","numerator":"0"},"t":{"denominator":"512","numerator":"513"}}
{"V":{"denominator":"275954798594","numerator":"538445825"},"case":"expanded_n4_k128","kind":"actual_variation","method":"exact_continuous_primitive_no_quadrature","observed_sha256":"eb967611ce3eef9deabe8ea90b6b6e8734f094a8caf2a5d0d8fce04b25c3a281","primitive_residual":{"denominator":"1","numerator":"0"}}
{"M":1,"T_small":4,"X":1,"case":"expanded_n4_k128","epsilon":{"denominator":"119","numerator":"2"},"input_sha256":"f358fcf9bca10991a2fbb8cfe7d7fb4ca3aa0d0a9969186774485f312d0ab490","kind":"log_and_proxy_certificate","ledger_residual":{"denominator":"16419310516343","numerator":"270536194"},"log_failure_margin":{"denominator":"222879639506979916800","numerator":"-2207624993281"},"log_lower":{"denominator":"1025","numerator":"2"},"log_pass_margin":{"denominator":"282853668558850","numerator":"2626563"},"log_to_u_residual":{"denominator":"1615334400","numerator":"3077"},"log_upper":{"denominator":"1615334400","numerator":"3151873"},"near_residual":{"denominator":"70644428440064","numerator":"135268097"},"observed_sha256":"eb967611ce3eef9deabe8ea90b6b6e8734f094a8caf2a5d0d8fce04b25c3a281","proxy_charge":{"denominator":"16419310516343","numerator":"275684262400"},"scope":"SCALAR_PROXY_ONLY_NO_TRAFFIC_OR_FAR_ROOT_CERTIFICATION","status":"PASS"}
{"M":2,"T_small":4,"X":1,"case":"expanded_n4_k128","epsilon":{"denominator":"119","numerator":"2"},"input_sha256":"f358fcf9bca10991a2fbb8cfe7d7fb4ca3aa0d0a9969186774485f312d0ab490","kind":"log_and_proxy_certificate","ledger_residual":{"denominator":"16419310516343","numerator":"270536194"},"log_failure_margin":{"denominator":"390271535428367958480000000","numerator":"-3865643255624818177"},"log_lower":{"denominator":"3230671875","numerator":"6303752"},"log_pass_margin":{"denominator":"891519406588925343750","numerator":"8830507852813"},"log_to_u_residual":{"denominator":"2828517840000000","numerator":"5387955209"},"log_upper":{"denominator":"2828517840000000","numerator":"5519060951041"},"near_residual":{"denominator":"70644428440064","numerator":"135268097"},"observed_sha256":"eb967611ce3eef9deabe8ea90b6b6e8734f094a8caf2a5d0d8fce04b25c3a281","proxy_charge":{"denominator":"16419310516343","numerator":"275684262400"},"scope":"SCALAR_PROXY_ONLY_NO_TRAFFIC_OR_FAR_ROOT_CERTIFICATION","status":"PASS"}
{"M":4,"T_small":4,"X":1,"case":"expanded_n4_k128","epsilon":{"denominator":"119","numerator":"2"},"input_sha256":"f358fcf9bca10991a2fbb8cfe7d7fb4ca3aa0d0a9969186774485f312d0ab490","kind":"log_and_proxy_certificate","ledger_residual":{"denominator":"16419310516343","numerator":"270536194"},"log_failure_margin":{"denominator":"5427913070788033566836828643750000000000","numerator":"-53763530387064434049505156545031"},"log_lower":{"denominator":"24962400827032470703125","numerator":"48707139018330700256"},"log_pass_margin":{"denominator":"6888494292646444483579064941406250","numerator":"68230601226273698993536939"},"log_to_u_residual":{"denominator":"39339146109750243750000000000","numerator":"74935909613934385579127"},"log_upper":{"denominator":"39339146109750243750000000000","numerator":"76759333835992010438639623"},"near_residual":{"denominator":"70644428440064","numerator":"135268097"},"observed_sha256":"eb967611ce3eef9deabe8ea90b6b6e8734f094a8caf2a5d0d8fce04b25c3a281","proxy_charge":{"denominator":"16419310516343","numerator":"275684262400"},"scope":"SCALAR_PROXY_ONLY_NO_TRAFFIC_OR_FAR_ROOT_CERTIFICATION","status":"PASS"}
{"M":8,"T_small":4,"X":1,"case":"expanded_n4_k128","epsilon":{"denominator":"119","numerator":"2"},"input_sha256":"f358fcf9bca10991a2fbb8cfe7d7fb4ca3aa0d0a9969186774485f312d0ab490","kind":"log_and_proxy_certificate","ledger_residual":{"denominator":"16419310516343","numerator":"270536194"},"log_failure_margin":{"denominator":"8931743870173065557515524501256940516206440925598144531250000000000","numerator":"-88469007648239575403806199895877354723421630375744410337677"},"log_lower":{"denominator":"65238590909907431524225540501065552234649658203125","numerator":"127294851918561152352365700214256636038077712256"},"log_pass_margin":{"denominator":"18002902215099864465451505460802334309304133057594299316406250","numerator":"178318916989646976997480891817993249168403375107164939"},"log_to_u_residual":{"denominator":"64733383261901108374501937915425300598144531250000000000","numerator":"123308598096787505400117259267607582152199145361709"},"log_upper":{"denominator":"64733383261901108374501937915425300598144531250000000000","numerator":"126309080585303814788548980231797432648598838452294541"},"near_residual":{"denominator":"70644428440064","numerator":"135268097"},"observed_sha256":"eb967611ce3eef9deabe8ea90b6b6e8734f094a8caf2a5d0d8fce04b25c3a281","proxy_charge":{"denominator":"16419310516343","numerator":"275684262400"},"scope":"SCALAR_PROXY_ONLY_NO_TRAFFIC_OR_FAR_ROOT_CERTIFICATION","status":"PASS"}
{"a":{"denominator":"1","numerator":"1"},"b":{"denominator":"1","numerator":"1"},"input_sha256":"bc5c08b56fb5f8c0c55c4b6bb342ea45227bad91c5d0cdc320d461ea6226e060","k":16,"kind":"configuration","n":16,"name":"expanded_n16_k16","points":[{"denominator":"1","numerator":"1"},{"denominator":"512","numerator":"513"},{"denominator":"256","numerator":"257"}],"r":{"denominator":"256","numerator":"257"},"reconstruct":"evaluate fixed menu in this code SHA","scope":"ABSTRACT_TWO_ATOM_NON_FULL"}
{"P":{"denominator":"1","numerator":"4"},"case":"expanded_n16_k16","closed_rate_residual":{"denominator":"1","numerator":"0"},"dpi":[{"denominator":"1","numerator":"-4"},{"denominator":"1","numerator":"4"}],"full_variation":{"denominator":"1","numerator":"8"},"half_full_residual":{"denominator":"1","numerator":"0"},"kind":"actual_derivative","quotient_centered_residual":[{"denominator":"1","numerator":"0"},{"denominator":"1","numerator":"0"}],"quotient_mass_residual":{"denominator":"1","numerator":"0"},"range_margin":{"denominator":"1","numerator":"0"},"square_identity_residual":{"denominator":"1","numerator":"0"},"t":{"denominator":"1","numerator":"1"}}
{"P":{"denominator":"2052877461546489399335600097165740058105436739516602627659181838946565283848118457090049","numerator":"8193506374437656205860161775325454241197883500093869475562823454404766172719352175919104"},"case":"expanded_n16_k16","closed_rate_residual":{"denominator":"1","numerator":"0"},"dpi":[{"denominator":"2052877461546489399335600097165740058105436739516602627659181838946565283848118457090049","numerator":"-8193506374437656205860161775325454241197883500093869475562823454404766172719352175919104"},{"denominator":"2052877461546489399335600097165740058105436739516602627659181838946565283848118457090049","numerator":"8193506374437656205860161775325454241197883500093869475562823454404766172719352175919104"}],"full_variation":{"denominator":"2052877461546489399335600097165740058105436739516602627659181838946565283848118457090049","numerator":"16387012748875312411720323550650908482395767000187738951125646908809532345438704351838208"},"half_full_residual":{"denominator":"1","numerator":"0"},"kind":"actual_derivative","quotient_centered_residual":[{"denominator":"1","numerator":"0"},{"denominator":"1","numerator":"0"}],"quotient_mass_residual":{"denominator":"1","numerator":"0"},"range_margin":{"denominator":"2052877461546489399335600097165740058105436739516602627659181838946565283848118457090049","numerator":"2000529610727844205167984870073463409023841761420196254445261822110653742029167722500"},"square_identity_residual":{"denominator":"1","numerator":"0"},"t":{"denominator":"512","numerator":"513"}}
{"P":{"denominator":"493459831442210190330230675895252172500241066410681978074956544586800149045249","numerator":"1964247653137664681462783124086424642842166149041488303842554274029459648544768"},"case":"expanded_n16_k16","closed_rate_residual":{"denominator":"1","numerator":"0"},"dpi":[{"denominator":"493459831442210190330230675895252172500241066410681978074956544586800149045249","numerator":"-1964247653137664681462783124086424642842166149041488303842554274029459648544768"},{"denominator":"493459831442210190330230675895252172500241066410681978074956544586800149045249","numerator":"1964247653137664681462783124086424642842166149041488303842554274029459648544768"}],"full_variation":{"denominator":"493459831442210190330230675895252172500241066410681978074956544586800149045249","numerator":"3928495306275329362925566248172849285684332298082976607685108548058919297089536"},"half_full_residual":{"denominator":"1","numerator":"0"},"kind":"actual_derivative","quotient_centered_residual":[{"denominator":"1","numerator":"0"},{"denominator":"1","numerator":"0"}],"quotient_mass_residual":{"denominator":"1","numerator":"0"},"range_margin":{"denominator":"493459831442210190330230675895252172500241066410681978074956544586800149045249","numerator":"1918830236107077196175582916121450897695905081546294770386926684813370884100"},"square_identity_residual":{"denominator":"1","numerator":"0"},"t":{"denominator":"256","numerator":"257"}}
{"V":{"denominator":"1404933922207318888154065648005462106114","numerator":"21902227261782517150283609139194630145"},"case":"expanded_n16_k16","kind":"actual_variation","method":"exact_continuous_primitive_no_quadrature","observed_sha256":"f82f3f2919d84dacce57e4b1e0dfa13fd65f82d3cc2dc71108b0278843394ff9","primitive_residual":{"denominator":"1","numerator":"0"}}
{"M":1,"T_small":4,"X":1,"case":"expanded_n16_k16","epsilon":{"denominator":"119","numerator":"16"},"input_sha256":"bc5c08b56fb5f8c0c55c4b6bb342ea45227bad91c5d0cdc320d461ea6226e060","kind":"log_and_proxy_certificate","ledger_residual":{"denominator":"11941938338762210549309558008046427901969","numerator":"3647288517986046326759614968006602096"},"log_failure_margin":{"denominator":"35563755501645144870359072466948120870177767808","numerator":"-179761597376231422813867710328807317953345"},"log_lower":{"denominator":"513","numerator":"2"},"log_pass_margin":{"denominator":"720731102092354589623035677426802060436482","numerator":"3628792364119807137033695636851584527"},"log_to_u_residual":{"denominator":"202507776","numerator":"1541"},"log_upper":{"denominator":"202507776","numerator":"789505"},"near_residual":{"denominator":"44957885510634204420930100736174787395648","numerator":"1595688726618895267957331548502888417"},"observed_sha256":"f82f3f2919d84dacce57e4b1e0dfa13fd65f82d3cc2dc71108b0278843394ff9","proxy_charge":{"denominator":"4917268727725616108539229768019117371399","numerator":"659643550472508751820306345839273566720"},"scope":"SCALAR_PROXY_ONLY_NO_TRAFFIC_OR_FAR_ROOT_CERTIFICATION","status":"PASS"}
{"M":2,"T_small":4,"X":1,"case":"expanded_n16_k16","epsilon":{"denominator":"119","numerator":"16"},"input_sha256":"bc5c08b56fb5f8c0c55c4b6bb342ea45227bad91c5d0cdc320d461ea6226e060","kind":"log_and_proxy_certificate","ledger_residual":{"denominator":"11941938338762210549309558008046427901969","numerator":"3647288517986046326759614968006602096"},"log_failure_margin":{"denominator":"46796389858062255651937633710271350106419064881317760","numerator":"-236538397694593314345194869143543817286857145411"},"log_lower":{"denominator":"405017091","numerator":"1579016"},"log_pass_margin":{"denominator":"569022250219628594989514028578202214329025594374","numerator":"2876196444396795124443294466347827642007101"},"log_to_u_residual":{"denominator":"266468844510720","numerator":"2027717147"},"log_upper":{"denominator":"266468844510720","numerator":"1038866206723"},"near_residual":{"denominator":"44957885510634204420930100736174787395648","numerator":"1595688726618895267957331548502888417"},"observed_sha256":"f82f3f2919d84dacce57e4b1e0dfa13fd65f82d3cc2dc71108b0278843394ff9","proxy_charge":{"denominator":"4917268727725616108539229768019117371399","numerator":"659643550472508751820306345839273566720"},"scope":"SCALAR_PROXY_ONLY_NO_TRAFFIC_OR_FAR_ROOT_CERTIFICATION","status":"PASS"}
{"M":4,"T_small":4,"X":1,"case":"expanded_n16_k16","epsilon":{"denominator":"119","numerator":"16"},"input_sha256":"bc5c08b56fb5f8c0c55c4b6bb342ea45227bad91c5d0cdc320d461ea6226e060","kind":"log_and_proxy_certificate","ledger_residual":{"denominator":"11941938338762210549309558008046427901969","numerator":"3647288517986046326759614968006602096"},"log_failure_margin":{"denominator":"68061435643404871152636505307258681795313104795851141631993650560","numerator":"-344025318634935130936941540049382923909540183513695299101027"},"log_lower":{"denominator":"327257493784194050595","numerator":"1275859291593784096"},"log_pass_margin":{"denominator":"459775154313965028862924943980076482080314423880317374837830","numerator":"2323992911228215054260938151283201222484625180188065501"},"log_to_u_residual":{"denominator":"387556650558894509581432320","numerator":"2949145019993299659859"},"log_upper":{"denominator":"387556650558894509581432320","numerator":"1510944021225688378392611"},"near_residual":{"denominator":"44957885510634204420930100736174787395648","numerator":"1595688726618895267957331548502888417"},"observed_sha256":"f82f3f2919d84dacce57e4b1e0dfa13fd65f82d3cc2dc71108b0278843394ff9","proxy_charge":{"denominator":"4917268727725616108539229768019117371399","numerator":"659643550472508751820306345839273566720"},"scope":"SCALAR_PROXY_ONLY_NO_TRAFFIC_OR_FAR_ROOT_CERTIFICATION","status":"PASS"}
{"M":8,"T_small":4,"X":1,"case":"expanded_n16_k16","epsilon":{"denominator":"119","numerator":"16"},"input_sha256":"bc5c08b56fb5f8c0c55c4b6bb342ea45227bad91c5d0cdc320d461ea6226e060","kind":"log_and_proxy_certificate","ledger_residual":{"denominator":"11941938338762210549309558008046427901969","numerator":"3647288517986046326759614968006602096"},"log_failure_margin":{"denominator":"264547541931355515569526185138820314012421654842908070367424453119886702039222914999323520","numerator":"-1337189724939961387949962163731895007450968763450872163509585124719246900552211113191"},"log_lower":{"denominator":"673419694209083339848701021624750401748978855","numerator":"2625421236543128031879604402047017936511616"},"log_pass_margin":{"denominator":"946110172276820766942972452001388740316797518178173174523004596016990093697152219470","numerator":"4782236084272578779290034060039107230812822642157284247192693937655193191896921"},"log_to_u_residual":{"denominator":"1506391369727736377241075078901009666683539772157440","numerator":"11463012181023921501569811094837271797521064327"},"log_upper":{"denominator":"1506391369727736377241075078901009666683539772157440","numerator":"5872878275817946302096379715862231738685056170663"},"near_residual":{"denominator":"44957885510634204420930100736174787395648","numerator":"1595688726618895267957331548502888417"},"observed_sha256":"f82f3f2919d84dacce57e4b1e0dfa13fd65f82d3cc2dc71108b0278843394ff9","proxy_charge":{"denominator":"4917268727725616108539229768019117371399","numerator":"659643550472508751820306345839273566720"},"scope":"SCALAR_PROXY_ONLY_NO_TRAFFIC_OR_FAR_ROOT_CERTIFICATION","status":"PASS"}
{"a":{"denominator":"1","numerator":"1"},"b":{"denominator":"1","numerator":"1"},"input_sha256":"16e21665005e3cd1bcc3edb30d3ef32fa6ea840ad7679863330313b9959250a0","k":128,"kind":"configuration","n":16,"name":"expanded_n16_k128","points":[{"denominator":"1","numerator":"1"},{"denominator":"4096","numerator":"4097"},{"denominator":"2048","numerator":"2049"}],"r":{"denominator":"2048","numerator":"2049"},"reconstruct":"evaluate fixed menu in this code SHA","scope":"ABSTRACT_TWO_ATOM_NON_FULL"}
{"P":{"denominator":"1","numerator":"4"},"case":"expanded_n16_k128","closed_rate_residual":{"denominator":"1","numerator":"0"},"dpi":[{"denominator":"1","numerator":"-4"},{"denominator":"1","numerator":"4"}],"full_variation":{"denominator":"1","numerator":"8"},"half_full_residual":{"denominator":"1","numerator":"0"},"kind":"actual_derivative","quotient_centered_residual":[{"denominator":"1","numerator":"0"},{"denominator":"1","numerator":"0"}],"quotient_mass_residual":{"denominator":"1","numerator":"0"},"range_margin":{"denominator":"1","numerator":"0"},"square_identity_residual":{"denominator":"1","numerator":"0"},"t":{"denominator":"1","numerator":"1"}}
{"P":{"denominator":"158225413151405955115526495635856943732147124301901727317800406487664718365442156887092153639438213461810123234213889","numerator":"632744760171647091874489684773133364485666560507809948547732141608609878142801540772554665503018903217514110735351808"},"case":"expanded_n16_k128","closed_rate_residual":{"denominator":"1","numerator":"0"},"dpi":[{"denominator":"158225413151405955115526495635856943732147124301901727317800406487664718365442156887092153639438213461810123234213889","numerator":"-632744760171647091874489684773133364485666560507809948547732141608609878142801540772554665503018903217514110735351808"},{"denominator":"158225413151405955115526495635856943732147124301901727317800406487664718365442156887092153639438213461810123234213889","numerator":"632744760171647091874489684773133364485666560507809948547732141608609878142801540772554665503018903217514110735351808"}],"full_variation":{"denominator":"158225413151405955115526495635856943732147124301901727317800406487664718365442156887092153639438213461810123234213889","numerator":"1265489520343294183748979369546266728971333121015619897095464283217219756285603081545109331006037806435028221470703616"},"half_full_residual":{"denominator":"1","numerator":"0"},"kind":"actual_derivative","quotient_centered_residual":[{"denominator":"1","numerator":"0"},{"denominator":"1","numerator":"0"}],"quotient_mass_residual":{"denominator":"1","numerator":"0"},"range_margin":{"denominator":"158225413151405955115526495635856943732147124301901727317800406487664718365442156887092153639438213461810123234213889","numerator":"2413732762947559326627437097844680108053262172983685249823174664080797936129368398774575851377655308043795562500"},"square_identity_residual":{"denominator":"1","numerator":"0"},"t":{"denominator":"4096","numerator":"4097"}}
{"P":{"denominator":"36984281513478204112542923138001641950836216432464784107088115804081589945870468659081450438445636394221569","numerator":"147862671267221763002169568591012781907777328627429680088824262375327822041585631971893555504163545312919552"},"case":"expanded_n16_k128","closed_rate_residual":{"denominator":"1","numerator":"0"},"dpi":[{"denominator":"36984281513478204112542923138001641950836216432464784107088115804081589945870468659081450438445636394221569","numerator":"-147862671267221763002169568591012781907777328627429680088824262375327822041585631971893555504163545312919552"},{"denominator":"36984281513478204112542923138001641950836216432464784107088115804081589945870468659081450438445636394221569","numerator":"147862671267221763002169568591012781907777328627429680088824262375327822041585631971893555504163545312919552"}],"full_variation":{"denominator":"36984281513478204112542923138001641950836216432464784107088115804081589945870468659081450438445636394221569","numerator":"295725342534443526004339137182025563815554657254859360177648524750655644083171263943787111008327090625839104"},"half_full_residual":{"denominator":"1","numerator":"0"},"kind":"actual_derivative","quotient_centered_residual":[{"denominator":"1","numerator":"0"},{"denominator":"1","numerator":"0"}],"quotient_mass_residual":{"denominator":"1","numerator":"0"},"range_margin":{"denominator":"36984281513478204112542923138001641950836216432464784107088115804081589945870468659081450438445636394221569","numerator":"2256216736355321536220851330205435651630203685594191047329619135584703789999680070970099470482907856900"},"square_identity_residual":{"denominator":"1","numerator":"0"},"t":{"denominator":"2048","numerator":"2049"}}
{"V":{"denominator":"384625956032497651366403877339565502448094075091484674","numerator":"751035408012718388408560275994103271704647272792065"},"case":"expanded_n16_k128","kind":"actual_variation","method":"exact_continuous_primitive_no_quadrature","observed_sha256":"f729a0d14af7141091696ac3151fc9ea2c3a5e18a65ca06bfa19ef41fcb481ec","primitive_residual":{"denominator":"1","numerator":"0"}}
{"M":1,"T_small":4,"X":1,"case":"expanded_n16_k128","epsilon":{"denominator":"119","numerator":"2"},"input_sha256":"16e21665005e3cd1bcc3edb30d3ef32fa6ea840ad7679863330313b9959250a0","kind":"log_and_proxy_certificate","ledger_residual":{"denominator":"3269320626276230036614432957386306770808799638277619729","numerator":"13689589997976643031573718654946762187810203135342"},"log_failure_margin":{"denominator":"4959498083760657033678448202508210463292382844656332146967841792","numerator":"-49231822036225964280282525327536870247321357671644322305"},"log_lower":{"denominator":"4097","numerator":"2"},"log_pass_margin":{"denominator":"1575812541865142877648156685460199863529841425649812709378","numerator":"15581631873973621359567968682915410812724102787087"},"log_to_u_residual":{"denominator":"103154724864","numerator":"12293"},"log_upper":{"denominator":"103154724864","numerator":"50356225"},"near_residual":{"denominator":"98464244744319398749799392598928768626712083223420076544","numerator":"47913564992918250610508015292313667657335710973697"},"observed_sha256":"f729a0d14af7141091696ac3151fc9ea2c3a5e18a65ca06bfa19ef41fcb481ec","proxy_charge":{"denominator":"1346190846113741779782413570688479258568329262820196359","numerator":"22619419347206577345010756547587110300751729627619840"},"scope":"SCALAR_PROXY_ONLY_NO_TRAFFIC_OR_FAR_ROOT_CERTIFICATION","status":"PASS"}
{"M":2,"T_small":4,"X":1,"case":"expanded_n16_k128","epsilon":{"denominator":"119","numerator":"2"},"input_sha256":"16e21665005e3cd1bcc3edb30d3ef32fa6ea840ad7679863330313b9959250a0","kind":"log_and_proxy_certificate","ledger_residual":{"denominator":"3269320626276230036614432957386306770808799638277619729","numerator":"13689589997976643031573718654946762187810203135342"},"log_failure_margin":{"denominator":"46248446539243825788344181980230632491356740351188888625946296847784960","numerator":"-459097927009078019809685162723491419007392801369010465221639339"},"log_lower":{"denominator":"206309462019","numerator":"100712456"},"log_pass_margin":{"denominator":"79351974067608138134283804184601423793277716104025591300923596806","numerator":"787709199324511050405384483944495972703374160918617518141"},"log_to_u_residual":{"denominator":"961941248402616320","numerator":"114635018243"},"log_upper":{"denominator":"961941248402616320","numerator":"469583240178347"},"near_residual":{"denominator":"98464244744319398749799392598928768626712083223420076544","numerator":"47913564992918250610508015292313667657335710973697"},"observed_sha256":"f729a0d14af7141091696ac3151fc9ea2c3a5e18a65ca06bfa19ef41fcb481ec","proxy_charge":{"denominator":"1346190846113741779782413570688479258568329262820196359","numerator":"22619419347206577345010756547587110300751729627619840"},"scope":"SCALAR_PROXY_ONLY_NO_TRAFFIC_OR_FAR_ROOT_CERTIFICATION","status":"PASS"}
{"M":4,"T_small":4,"X":1,"case":"expanded_n16_k128","epsilon":{"denominator":"119","numerator":"2"},"input_sha256":"16e21665005e3cd1bcc3edb30d3ef32fa6ea840ad7679863330313b9959250a0","kind":"log_and_proxy_certificate","ledger_residual":{"denominator":"3269320626276230036614432957386306770808799638277619729","numerator":"13689589997976643031573718654946762187810203135342"},"log_failure_margin":{"denominator":"2462764073805120598164556992037415749534659764565306395393209179120209131144917371120640","numerator":"-24447305057845718261673197528733588035869490993545765865238420413839489374423587"},"log_lower":{"denominator":"2034468859544076981321461865","numerator":"993150549155778992111968"},"log_pass_margin":{"denominator":"782509530120485792791630124462840025347304758852548243615155633312047902922957010","numerator":"7767796110477455422129567394975241183186600196703521669247361381883812503"},"log_to_u_residual":{"denominator":"51224084806113039172333674840698880","numerator":"6104399729173497723805323859"},"log_upper":{"denominator":"51224084806113039172333674840698880","numerator":"25005655759505708910642246844451"},"near_residual":{"denominator":"98464244744319398749799392598928768626712083223420076544","numerator":"47913564992918250610508015292313667657335710973697"},"observed_sha256":"f729a0d14af7141091696ac3151fc9ea2c3a5e18a65ca06bfa19ef41fcb481ec","proxy_charge":{"denominator":"1346190846113741779782413570688479258568329262820196359","numerator":"22619419347206577345010756547587110300751729627619840"},"scope":"SCALAR_PROXY_ONLY_NO_TRAFFIC_OR_FAR_ROOT_CERTIFICATION","status":"PASS"}
{"M":8,"T_small":4,"X":1,"case":"expanded_n16_k128","epsilon":{"denominator":"119","numerator":"2"},"input_sha256":"16e21665005e3cd1bcc3edb30d3ef32fa6ea840ad7679863330313b9959250a0","kind":"log_and_proxy_certificate","ledger_residual":{"denominator":"3269320626276230036614432957386306770808799638277619729","numerator":"13689589997976643031573718654946762187810203135342"},"log_failure_margin":{"denominator":"158421538039670711221420567896945322611012538307111261209170223886170347477697707479061334560949398244368849014577454080","numerator":"-1572614977367665587819353483335605742553374921616831702257668881792717478349078343187005833519027003325014969511"},"log_lower":{"denominator":"69284494157418960501202623372985770086263821307012950941685","numerator":"33822062745084856525296225779348283875096479891845400448"},"log_pass_margin":{"denominator":"26648614803525265511526745902482243839861671163644533808385203128729348024922774517271696586371052747053045235690","numerator":"264534805587048647938134077352498059247658289017558729896839728503470133506851200178611914329952593206283"},"log_to_u_residual":{"denominator":"3295077423766698190354283151293389932427711402785699321380472975360","numerator":"392676019676718463008820029118615937158004404262141679116167"},"log_upper":{"denominator":"3295077423766698190354283151293389932427711402785699321380472975360","numerator":"1608531847303906382295918499938356937006060453987192605088692903"},"near_residual":{"denominator":"98464244744319398749799392598928768626712083223420076544","numerator":"47913564992918250610508015292313667657335710973697"},"observed_sha256":"f729a0d14af7141091696ac3151fc9ea2c3a5e18a65ca06bfa19ef41fcb481ec","proxy_charge":{"denominator":"1346190846113741779782413570688479258568329262820196359","numerator":"22619419347206577345010756547587110300751729627619840"},"scope":"SCALAR_PROXY_ONLY_NO_TRAFFIC_OR_FAR_ROOT_CERTIFICATION","status":"PASS"}
{"a":{"denominator":"1","numerator":"1"},"b":{"denominator":"1","numerator":"1"},"input_sha256":"8b4b826c478d6e8f97a35e7b21da502ec530492b5897b2ec145b6443a62d8766","k":16,"kind":"configuration","n":256,"name":"expanded_n256_k16","points":[{"denominator":"1","numerator":"1"},{"denominator":"8192","numerator":"8193"},{"denominator":"4096","numerator":"4097"}],"r":{"denominator":"4096","numerator":"4097"},"reconstruct":"evaluate fixed menu in this code SHA","scope":"ABSTRACT_TWO_ATOM_NON_FULL"}
{"P":{"denominator":"1","numerator":"64"},"case":"expanded_n256_k16","closed_rate_residual":{"denominator":"1","numerator":"0"},"dpi":[{"denominator":"1","numerator":"-64"},{"denominator":"1","numerator":"64"}],"full_variation":{"denominator":"1","numerator":"128"},"half_full_residual":{"denominator":"1","numerator":"0"},"kind":"actual_derivative","quotient_centered_residual":[{"denominator":"1","numerator":"0"},{"denominator":"1","numerator":"0"}],"quotient_mass_residual":{"denominator":"1","numerator":"0"},"range_margin":{"denominator":"1","numerator":"0"},"square_identity_residual":{"denominator":"1","numerator":"0"},"t":{"denominator":"1","numerator":"1"}}
{"P":{"denominator_bits":6659,"exact_sha256":"85777abd6e32a556c744616f3282927f3e00f2faadda29b2dcb923c6d9d595a1","numerator_bits":6665,"sign":1},"case":"expanded_n256_k16","closed_rate_residual":{"denominator":"1","numerator":"0"},"dpi":[{"denominator_bits":6659,"exact_sha256":"dca7d6c95a9abdf2867dabf70979441c4500784941eda7eb1216e7206a6e000b","numerator_bits":6665,"sign":-1},{"denominator_bits":6659,"exact_sha256":"85777abd6e32a556c744616f3282927f3e00f2faadda29b2dcb923c6d9d595a1","numerator_bits":6665,"sign":1}],"full_variation":{"denominator_bits":6659,"exact_sha256":"c06b1b56a3d72cd731144602928d983280ca9cfa2f80ec37e8cfea5fb4fc0881","numerator_bits":6666,"sign":1},"half_full_residual":{"denominator":"1","numerator":"0"},"kind":"actual_derivative","quotient_centered_residual":[{"denominator":"1","numerator":"0"},{"denominator":"1","numerator":"0"}],"quotient_mass_residual":{"denominator":"1","numerator":"0"},"range_margin":{"denominator_bits":6659,"exact_sha256":"67288703ecbbcfec8d170bacf08feb5401d6ec6a78199d58dd0ac20e212c01a4","numerator_bits":6653,"sign":1},"square_identity_residual":{"denominator":"1","numerator":"0"},"t":{"denominator":"8192","numerator":"8193"}}
{"P":{"denominator_bits":6147,"exact_sha256":"bd19488c3d5694456d908e817e86d20f8406c7043c68d9439a23c937b16415aa","numerator_bits":6153,"sign":1},"case":"expanded_n256_k16","closed_rate_residual":{"denominator":"1","numerator":"0"},"dpi":[{"denominator_bits":6147,"exact_sha256":"d6af2182f320287773c8a006d816cc9da1c6b308111537b787d5bb14d8ced1ac","numerator_bits":6153,"sign":-1},{"denominator_bits":6147,"exact_sha256":"bd19488c3d5694456d908e817e86d20f8406c7043c68d9439a23c937b16415aa","numerator_bits":6153,"sign":1}],"full_variation":{"denominator_bits":6147,"exact_sha256":"ce7f58f22d97dcd7a0de274550b205c537382e05ff3d7aa1d4fb17b7bcccdc78","numerator_bits":6154,"sign":1},"half_full_residual":{"denominator":"1","numerator":"0"},"kind":"actual_derivative","quotient_centered_residual":[{"denominator":"1","numerator":"0"},{"denominator":"1","numerator":"0"}],"quotient_mass_residual":{"denominator":"1","numerator":"0"},"range_margin":{"denominator_bits":6147,"exact_sha256":"658cafb57af5ae7c81e0ea2ba49b59e1e991c11f052124501d5f0a06d8f10f9a","numerator_bits":6143,"sign":1},"square_identity_residual":{"denominator":"1","numerator":"0"},"t":{"denominator":"4096","numerator":"4097"}}
{"V":{"denominator_bits":3075,"exact_sha256":"f8a68744a2fda0e6cb58eed2b29d6681a02df8d59c2048274dad1ea9237ac19c","numerator_bits":3069,"sign":1},"case":"expanded_n256_k16","kind":"actual_variation","method":"exact_continuous_primitive_no_quadrature","observed_sha256":"cfc707e7751418531d4c9d86b6470cd3323f0a710d144b1edf8819d611771422","primitive_residual":{"denominator":"1","numerator":"0"}}
{"M":1,"T_small":4,"X":1,"case":"expanded_n256_k16","epsilon":{"denominator":"119","numerator":"16"},"input_sha256":"8b4b826c478d6e8f97a35e7b21da502ec530492b5897b2ec145b6443a62d8766","kind":"log_and_proxy_certificate","ledger_residual":{"denominator_bits":3080,"exact_sha256":"2176e709fe9517feb24a84225f65556f0d455811eba74f2bdd76b75485ebd80e","numerator_bits":3066,"sign":1},"log_failure_margin":{"denominator_bits":3107,"exact_sha256":"88dd6044cde1ba773f1d26b4e9108be6f0e2fb946fd7a1627212889cc60cc7f9","numerator_bits":3090,"sign":-1},"log_lower":{"denominator":"8193","numerator":"2"},"log_pass_margin":{"denominator_bits":3088,"exact_sha256":"e6540bd4bb4a956d02ff1fd5301e393e13ea5cb94b501b8dc82fd746569464e4","numerator_bits":3070,"sign":1},"log_to_u_residual":{"denominator":"824935735296","numerator":"24581"},"log_upper":{"denominator":"824935735296","numerator":"201375745"},"near_residual":{"denominator_bits":3080,"exact_sha256":"62b3a50e2eb907b12aa0ffd3b99d7285976bb89d49b6665398d54eadbb75bf9e","numerator_bits":3062,"sign":1},"observed_sha256":"cfc707e7751418531d4c9d86b6470cd3323f0a710d144b1edf8819d611771422","proxy_charge":{"denominator_bits":3080,"exact_sha256":"c62f0920dae289577d476b8513270d09e79dc1d4e86e23bc7a95c43e2ca368c7","numerator_bits":3078,"sign":1},"scope":"SCALAR_PROXY_ONLY_NO_TRAFFIC_OR_FAR_ROOT_CERTIFICATION","status":"PASS"}
{"M":2,"T_small":4,"X":1,"case":"expanded_n256_k16","epsilon":{"denominator":"119","numerator":"16"},"input_sha256":"8b4b826c478d6e8f97a35e7b21da502ec530492b5897b2ec145b6443a62d8766","kind":"log_and_proxy_certificate","ledger_residual":{"denominator_bits":3080,"exact_sha256":"2176e709fe9517feb24a84225f65556f0d455811eba74f2bdd76b75485ebd80e","numerator_bits":3066,"sign":1},"log_failure_margin":{"denominator_bits":3135,"exact_sha256":"57258846b81eb9e7131c1dab7f1840f37deacc85680003a26e2e4854df14139e","numerator_bits":3118,"sign":-1},"log_lower":{"denominator":"1649871495171","numerator":"402751496"},"log_pass_margin":{"denominator_bits":3115,"exact_sha256":"aa26b4e5afe61b40f8b0a6615219a8d1cb673ac7ab1ee46e04146c1759199aa8","numerator_bits":3098,"sign":1},"log_to_u_residual":{"denominator":"276870083203710443520","numerator":"8250028728347"},"log_upper":{"denominator":"276870083203710443520","numerator":"67586985128427523"},"near_residual":{"denominator_bits":3080,"exact_sha256":"62b3a50e2eb907b12aa0ffd3b99d7285976bb89d49b6665398d54eadbb75bf9e","numerator_bits":3062,"sign":1},"observed_sha256":"cfc707e7751418531d4c9d86b6470cd3323f0a710d144b1edf8819d611771422","proxy_charge":{"denominator_bits":3080,"exact_sha256":"c62f0920dae289577d476b8513270d09e79dc1d4e86e23bc7a95c43e2ca368c7","numerator_bits":3078,"sign":1},"scope":"SCALAR_PROXY_ONLY_NO_TRAFFIC_OR_FAR_ROOT_CERTIFICATION","status":"PASS"}
{"M":4,"T_small":4,"X":1,"case":"expanded_n256_k16","epsilon":{"denominator":"119","numerator":"16"},"input_sha256":"8b4b826c478d6e8f97a35e7b21da502ec530492b5897b2ec145b6443a62d8766","kind":"log_and_proxy_certificate","ledger_residual":{"denominator_bits":3080,"exact_sha256":"2176e709fe9517feb24a84225f65556f0d455811eba74f2bdd76b75485ebd80e","numerator_bits":3066,"sign":1},"log_failure_margin":{"denominator_bits":3192,"exact_sha256":"c95ed0c885d2b451dfaa1ebbe10af5e2557bbfe2bbd382e440fba0cd27b42895","numerator_bits":3174,"sign":-1},"log_lower":{"denominator":"86729876578659386676658216995","numerator":"21171701942962576110627616"},"log_pass_margin":{"denominator_bits":3171,"exact_sha256":"1384ef828686784fcf8ed9a645cfba92c3ee386edaf12b891bccb4ef67c679d1","numerator_bits":3153,"sign":1},"log_to_u_residual":{"denominator":"26197940134583562771893603821622353920","numerator":"780632404313637205443152093779"},"log_upper":{"denominator":"26197940134583562771893603821622353920","numerator":"6395200845765501492651393718419491"},"near_residual":{"denominator_bits":3080,"exact_sha256":"62b3a50e2eb907b12aa0ffd3b99d7285976bb89d49b6665398d54eadbb75bf9e","numerator_bits":3062,"sign":1},"observed_sha256":"cfc707e7751418531d4c9d86b6470cd3323f0a710d144b1edf8819d611771422","proxy_charge":{"denominator_bits":3080,"exact_sha256":"c62f0920dae289577d476b8513270d09e79dc1d4e86e23bc7a95c43e2ca368c7","numerator_bits":3078,"sign":1},"scope":"SCALAR_PROXY_ONLY_NO_TRAFFIC_OR_FAR_ROOT_CERTIFICATION","status":"PASS"}
{"M":8,"T_small":4,"X":1,"case":"expanded_n256_k16","epsilon":{"denominator":"119","numerator":"16"},"input_sha256":"8b4b826c478d6e8f97a35e7b21da502ec530492b5897b2ec145b6443a62d8766","kind":"log_and_proxy_certificate","ledger_residual":{"denominator_bits":3080,"exact_sha256":"2176e709fe9517feb24a84225f65556f0d455811eba74f2bdd76b75485ebd80e","numerator_bits":3066,"sign":1},"log_failure_margin":{"denominator_bits":3306,"exact_sha256":"2786d06656c376b684da3cbfaf38466e68a4a287a67510100ddd6ced8d79d3e1","numerator_bits":3288,"sign":-1},"log_lower":{"denominator":"755387266045163244143066936167353265014562435231854012818610855","numerator":"184398210617916893964671838780290783795855887622296336614016"},"log_pass_margin":{"denominator_bits":3283,"exact_sha256":"a677661d64d9906fc2ce4862ebaf5c3b1144366518f4691426000a214264f939","numerator_bits":3266,"sign":1},"log_to_u_residual":{"denominator":"430997239339250276690497282352086938050553930149588173937077677587619840","numerator":"12842628445959201110384531924165927503251557219238917594768519047"},"log_upper":{"denominator":"430997239339250276690497282352086938050553930149588173937077677587619840","numerator":"105211092757113190381530553542315809182495266545707561360012086360743"},"near_residual":{"denominator_bits":3080,"exact_sha256":"62b3a50e2eb907b12aa0ffd3b99d7285976bb89d49b6665398d54eadbb75bf9e","numerator_bits":3062,"sign":1},"observed_sha256":"cfc707e7751418531d4c9d86b6470cd3323f0a710d144b1edf8819d611771422","proxy_charge":{"denominator_bits":3080,"exact_sha256":"c62f0920dae289577d476b8513270d09e79dc1d4e86e23bc7a95c43e2ca368c7","numerator_bits":3078,"sign":1},"scope":"SCALAR_PROXY_ONLY_NO_TRAFFIC_OR_FAR_ROOT_CERTIFICATION","status":"PASS"}
{"a":{"denominator":"1","numerator":"1"},"b":{"denominator":"1","numerator":"1"},"input_sha256":"a37d5a753de3a3a53155b851b953ec8e5d85c1bed723efb17a532b76c35d1443","k":128,"kind":"configuration","n":256,"name":"expanded_n256_k128","points":[{"denominator":"1","numerator":"1"},{"denominator":"65536","numerator":"65537"},{"denominator":"32768","numerator":"32769"}],"r":{"denominator":"32768","numerator":"32769"},"reconstruct":"evaluate fixed menu in this code SHA","scope":"ABSTRACT_TWO_ATOM_NON_FULL"}
{"P":{"denominator":"1","numerator":"64"},"case":"expanded_n256_k128","closed_rate_residual":{"denominator":"1","numerator":"0"},"dpi":[{"denominator":"1","numerator":"-64"},{"denominator":"1","numerator":"64"}],"full_variation":{"denominator":"1","numerator":"128"},"half_full_residual":{"denominator":"1","numerator":"0"},"kind":"actual_derivative","quotient_centered_residual":[{"denominator":"1","numerator":"0"},{"denominator":"1","numerator":"0"}],"quotient_mass_residual":{"denominator":"1","numerator":"0"},"range_margin":{"denominator":"1","numerator":"0"},"square_identity_residual":{"denominator":"1","numerator":"0"},"t":{"denominator":"1","numerator":"1"}}
{"P":{"denominator_bits":8195,"exact_sha256":"e7fec1784571d239833b277e87e807ba987710418e9ff68cf8eab2ee2cabf2ef","numerator_bits":8201,"sign":1},"case":"expanded_n256_k128","closed_rate_residual":{"denominator":"1","numerator":"0"},"dpi":[{"denominator_bits":8195,"exact_sha256":"f0896874ba42f7c5bf601b67be9ab92adbc7eae50cd8970fc02153d1cccb0b6f","numerator_bits":8201,"sign":-1},{"denominator_bits":8195,"exact_sha256":"e7fec1784571d239833b277e87e807ba987710418e9ff68cf8eab2ee2cabf2ef","numerator_bits":8201,"sign":1}],"full_variation":{"denominator_bits":8195,"exact_sha256":"9cadfebd136b4220a041c55aebaf5587ac6ca0081d770c0df3939edbf0bb1c9b","numerator_bits":8202,"sign":1},"half_full_residual":{"denominator":"1","numerator":"0"},"kind":"actual_derivative","quotient_centered_residual":[{"denominator":"1","numerator":"0"},{"denominator":"1","numerator":"0"}],"quotient_mass_residual":{"denominator":"1","numerator":"0"},"range_margin":{"denominator_bits":8195,"exact_sha256":"d9542d956e99d9c6c4ca13a69af67fb1de8b4fd5114e2151fa0a234cdec6234a","numerator_bits":8183,"sign":1},"square_identity_residual":{"denominator":"1","numerator":"0"},"t":{"denominator":"65536","numerator":"65537"}}
{"P":{"denominator_bits":7683,"exact_sha256":"7e34612eeb99461b9ea28ed8e8be0bf86438a1d9eb3c6c831f2f43fa756d1f85","numerator_bits":7689,"sign":1},"case":"expanded_n256_k128","closed_rate_residual":{"denominator":"1","numerator":"0"},"dpi":[{"denominator_bits":7683,"exact_sha256":"b76842dbb482ad1228d9bf1a2c2356c7ebb9b2323313242925b2ff321bac9fc2","numerator_bits":7689,"sign":-1},{"denominator_bits":7683,"exact_sha256":"7e34612eeb99461b9ea28ed8e8be0bf86438a1d9eb3c6c831f2f43fa756d1f85","numerator_bits":7689,"sign":1}],"full_variation":{"denominator_bits":7683,"exact_sha256":"09b0233cbd7643999fbc2bc39deb221e72db9b94fff9839168c2eba71ea94f51","numerator_bits":7690,"sign":1},"half_full_residual":{"denominator":"1","numerator":"0"},"kind":"actual_derivative","quotient_centered_residual":[{"denominator":"1","numerator":"0"},{"denominator":"1","numerator":"0"}],"quotient_mass_residual":{"denominator":"1","numerator":"0"},"range_margin":{"denominator_bits":7683,"exact_sha256":"32b709ac5d2689f6b46aa74f4a534e6bc0110e2be4064122d67ffeade57f626a","numerator_bits":7673,"sign":1},"square_identity_residual":{"denominator":"1","numerator":"0"},"t":{"denominator":"32768","numerator":"32769"}}
{"V":{"denominator_bits":3843,"exact_sha256":"97734b31c333a462d5b635846fa4532a262c22aeb5d4ce656615f1a0a4c871ac","numerator_bits":3834,"sign":1},"case":"expanded_n256_k128","kind":"actual_variation","method":"exact_continuous_primitive_no_quadrature","observed_sha256":"2917742d1635ccc8567aef175c7f896ee84249d8c1f4500aa60fc7dda0f52cd5","primitive_residual":{"denominator":"1","numerator":"0"}}
{"M":1,"T_small":4,"X":1,"case":"expanded_n256_k128","epsilon":{"denominator":"119","numerator":"2"},"input_sha256":"a37d5a753de3a3a53155b851b953ec8e5d85c1bed723efb17a532b76c35d1443","kind":"log_and_proxy_certificate","ledger_residual":{"denominator_bits":3848,"exact_sha256":"cad9d558213babfed122f1d92cd0ac122d01521f7f0dbefb79f3cb83880957db","numerator_bits":3827,"sign":1},"log_failure_margin":{"denominator_bits":3884,"exact_sha256":"d856e565d665049b32b8927231a2e1bf12ae6ac46921ce39ff817084d12f6e04","numerator_bits":3858,"sign":-1},"log_lower":{"denominator":"65537","numerator":"2"},"log_pass_margin":{"denominator_bits":3859,"exact_sha256":"80d16d7f5056dad6639327e85bb2329a2743961b6ad9ca2c985fc31dd82bf571","numerator_bits":3832,"sign":1},"log_to_u_residual":{"denominator":"422231792615424","numerator":"196613"},"log_upper":{"denominator":"422231792615424","numerator":"12885295105"},"near_residual":{"denominator_bits":3851,"exact_sha256":"aa9c733f96df99d28357040b8878afb94efbccd05b97f7297bedcbfa19b0b8f6","numerator_bits":3826,"sign":1},"observed_sha256":"2917742d1635ccc8567aef175c7f896ee84249d8c1f4500aa60fc7dda0f52cd5","proxy_charge":{"denominator_bits":3844,"exact_sha256":"01e13620967763316705b3ffdfe3bce426f4b63fd13a2baca46f27bc80840bd7","numerator_bits":3838,"sign":1},"scope":"SCALAR_PROXY_ONLY_NO_TRAFFIC_OR_FAR_ROOT_CERTIFICATION","status":"PASS"}
{"M":2,"T_small":4,"X":1,"case":"expanded_n256_k128","epsilon":{"denominator":"119","numerator":"2"},"input_sha256":"a37d5a753de3a3a53155b851b953ec8e5d85c1bed723efb17a532b76c35d1443","kind":"log_and_proxy_certificate","ledger_residual":{"denominator_bits":3848,"exact_sha256":"cad9d558213babfed122f1d92cd0ac122d01521f7f0dbefb79f3cb83880957db","numerator_bits":3827,"sign":1},"log_failure_margin":{"denominator_bits":3917,"exact_sha256":"5b8f2fc8533b09e20d14f2626506ee51fcf0b356567b156c74022bf99ffb7996","numerator_bits":3890,"sign":-1},"log_lower":{"denominator":"844463585427459","numerator":"25770590216"},"log_pass_margin":{"denominator_bits":3892,"exact_sha256":"0a84fcec869d875ca863203c25a589dadfc9605e99c8d025d203e073a289edff","numerator_bits":3866,"sign":1},"log_to_u_residual":{"denominator":"3022545139670756444405760","numerator":"1407453626040329"},"log_upper":{"denominator":"3022545139670756444405760","numerator":"92239349982615306241"},"near_residual":{"denominator_bits":3851,"exact_sha256":"aa9c733f96df99d28357040b8878afb94efbccd05b97f7297bedcbfa19b0b8f6","numerator_bits":3826,"sign":1},"observed_sha256":"2917742d1635ccc8567aef175c7f896ee84249d8c1f4500aa60fc7dda0f52cd5","proxy_charge":{"denominator_bits":3844,"exact_sha256":"01e13620967763316705b3ffdfe3bce426f4b63fd13a2baca46f27bc80840bd7","numerator_bits":3838,"sign":1},"scope":"SCALAR_PROXY_ONLY_NO_TRAFFIC_OR_FAR_ROOT_CERTIFICATION","status":"PASS"}
{"M":4,"T_small":4,"X":1,"case":"expanded_n256_k128","epsilon":{"denominator":"119","numerator":"2"},"input_sha256":"a37d5a753de3a3a53155b851b953ec8e5d85c1bed723efb17a532b76c35d1443","kind":"log_and_proxy_certificate","ledger_residual":{"denominator_bits":3848,"exact_sha256":"cad9d558213babfed122f1d92cd0ac122d01521f7f0dbefb79f3cb83880957db","numerator_bits":3827,"sign":1},"log_failure_margin":{"denominator_bits":3987,"exact_sha256":"abe26b913f1cc0a7a7d63e0cc85b69cd3f8adfe85aa454c1cb0e558997d6052b","numerator_bits":3960,"sign":-1},"log_lower":{"denominator":"545249405511354110352991592063631465","numerator":"16639437433928002268158307598688"},"log_pass_margin":{"denominator_bits":3961,"exact_sha256":"739fc3aa0c0d5547cac45279a3931f7fb18079103236268af88f6a47e645b897","numerator_bits":3935,"sign":1},"log_to_u_residual":{"denominator":"3512849747647180867270839136485337886212423680","numerator":"1635764855971495742520882848595247699"},"log_upper":{"denominator":"3512849747647180867270839136485337886212423680","numerator":"107202030850353405557200567999150241611811"},"near_residual":{"denominator_bits":3851,"exact_sha256":"aa9c733f96df99d28357040b8878afb94efbccd05b97f7297bedcbfa19b0b8f6","numerator_bits":3826,"sign":1},"observed_sha256":"2917742d1635ccc8567aef175c7f896ee84249d8c1f4500aa60fc7dda0f52cd5","proxy_charge":{"denominator_bits":3844,"exact_sha256":"01e13620967763316705b3ffdfe3bce426f4b63fd13a2baca46f27bc80840bd7","numerator_bits":3838,"sign":1},"scope":"SCALAR_PROXY_ONLY_NO_TRAFFIC_OR_FAR_ROOT_CERTIFICATION","status":"PASS"}
{"M":8,"T_small":4,"X":1,"case":"expanded_n256_k128","epsilon":{"denominator":"119","numerator":"2"},"input_sha256":"a37d5a753de3a3a53155b851b953ec8e5d85c1bed723efb17a532b76c35d1443","kind":"log_and_proxy_certificate","ledger_residual":{"denominator_bits":3848,"exact_sha256":"cad9d558213babfed122f1d92cd0ac122d01521f7f0dbefb79f3cb83880957db","numerator_bits":3827,"sign":1},"log_failure_margin":{"denominator_bits":4118,"exact_sha256":"889054d817a6a33c7f0977387cfd02b7481fa40187e1f771bf8bef765459df04","numerator_bits":4091,"sign":-1},"log_lower":{"denominator":"79605844140731317799750494889562797102596448191377485592692054514794044829685","numerator":"2429340499165642489089013015609764371243304907823363728731515855337342848"},"log_pass_margin":{"denominator_bits":4098,"exact_sha256":"7faaf524384b378816c1ca44f389078e9728aff82c621eea73bfd518bd913d96","numerator_bits":4071,"sign":1},"log_to_u_residual":{"denominator":"9785444160414135642995557110984864766280995394308912172893868103101013257019664957440","numerator":"4556609820388082762812099591392580606968088293064656639359783914445608260493"},"log_upper":{"denominator":"9785444160414135642995557110984864766280995394308912172893868103101013257019664957440","numerator":"298623500043443028756701211062788513616933174560294342963412767385916281229497837"},"near_residual":{"denominator_bits":3851,"exact_sha256":"aa9c733f96df99d28357040b8878afb94efbccd05b97f7297bedcbfa19b0b8f6","numerator_bits":3826,"sign":1},"observed_sha256":"2917742d1635ccc8567aef175c7f896ee84249d8c1f4500aa60fc7dda0f52cd5","proxy_charge":{"denominator_bits":3844,"exact_sha256":"01e13620967763316705b3ffdfe3bce426f4b63fd13a2baca46f27bc80840bd7","numerator_bits":3838,"sign":1},"scope":"SCALAR_PROXY_ONLY_NO_TRAFFIC_OR_FAR_ROOT_CERTIFICATION","status":"PASS"}
{"a":{"denominator":"1","numerator":"1"},"b":{"denominator":"1","numerator":"1"},"input_sha256":"beacaa0c4d76c199fb8b126d95412882d3fc6279e23e45475e6920af1086ecda","k":16,"kind":"configuration","n":1024,"name":"expanded_n1024_k16","points":[{"denominator":"1","numerator":"1"},{"denominator":"32768","numerator":"32769"},{"denominator":"16384","numerator":"16385"}],"r":{"denominator":"16384","numerator":"16385"},"reconstruct":"evaluate fixed menu in this code SHA","scope":"ABSTRACT_TWO_ATOM_NON_FULL"}
{"P":{"denominator":"1","numerator":"256"},"case":"expanded_n1024_k16","closed_rate_residual":{"denominator":"1","numerator":"0"},"dpi":[{"denominator":"1","numerator":"-256"},{"denominator":"1","numerator":"256"}],"full_variation":{"denominator":"1","numerator":"512"},"half_full_residual":{"denominator":"1","numerator":"0"},"kind":"actual_derivative","quotient_centered_residual":[{"denominator":"1","numerator":"0"},{"denominator":"1","numerator":"0"}],"quotient_mass_residual":{"denominator":"1","numerator":"0"},"range_margin":{"denominator":"1","numerator":"0"},"square_identity_residual":{"denominator":"1","numerator":"0"},"t":{"denominator":"1","numerator":"1"}}
{"P":{"denominator_bits":30723,"exact_sha256":"1e14bb21fb73e034e573fa7b7cc29117463575203a7ea21edebf9053edfc851b","numerator_bits":30731,"sign":1},"case":"expanded_n1024_k16","closed_rate_residual":{"denominator":"1","numerator":"0"},"dpi":[{"denominator_bits":30723,"exact_sha256":"6f22fef10d375b51a5925606fe6b1497a1a6e49c844f14f2a662d810c3562fd4","numerator_bits":30731,"sign":-1},{"denominator_bits":30723,"exact_sha256":"1e14bb21fb73e034e573fa7b7cc29117463575203a7ea21edebf9053edfc851b","numerator_bits":30731,"sign":1}],"full_variation":{"denominator_bits":30723,"exact_sha256":"705adaae205d1507b0e59db084483e6993f9cf8cb36cfb974e9af8cef05a0f8e","numerator_bits":30732,"sign":1},"half_full_residual":{"denominator":"1","numerator":"0"},"kind":"actual_derivative","quotient_centered_residual":[{"denominator":"1","numerator":"0"},{"denominator":"1","numerator":"0"}],"quotient_mass_residual":{"denominator":"1","numerator":"0"},"range_margin":{"denominator_bits":30723,"exact_sha256":"f27e0dc4e9ccd526f6264f677d58395b7c6182c4166dced8e20ae885a964e29d","numerator_bits":30719,"sign":1},"square_identity_residual":{"denominator":"1","numerator":"0"},"t":{"denominator":"32768","numerator":"32769"}}
{"P":{"denominator_bits":28675,"exact_sha256":"53d57c9735e1ad8e4617b720e1757b0d59c6aa3c6bfa04d434596cf0a09a0355","numerator_bits":28683,"sign":1},"case":"expanded_n1024_k16","closed_rate_residual":{"denominator":"1","numerator":"0"},"dpi":[{"denominator_bits":28675,"exact_sha256":"59d916d54d3504f71e001e22b4987d4b7c841946028110f9d96b12c2b9ca1887","numerator_bits":28683,"sign":-1},{"denominator_bits":28675,"exact_sha256":"53d57c9735e1ad8e4617b720e1757b0d59c6aa3c6bfa04d434596cf0a09a0355","numerator_bits":28683,"sign":1}],"full_variation":{"denominator_bits":28675,"exact_sha256":"83315bebc98579fb2ed69fa7679f952f21d0f6d99c0e28525d02fe5dc89ad7d4","numerator_bits":28684,"sign":1},"half_full_residual":{"denominator":"1","numerator":"0"},"kind":"actual_derivative","quotient_centered_residual":[{"denominator":"1","numerator":"0"},{"denominator":"1","numerator":"0"}],"quotient_mass_residual":{"denominator":"1","numerator":"0"},"range_margin":{"denominator_bits":28675,"exact_sha256":"7db1d2248a2fdabb9b182c2e1bc4133369237a369799f6962de62ca188ea9c84","numerator_bits":28673,"sign":1},"square_identity_residual":{"denominator":"1","numerator":"0"},"t":{"denominator":"16384","numerator":"16385"}}
{"V":{"denominator_bits":14339,"exact_sha256":"ff2074055b41bbea9f3684af304b4bf428314dae897f77733248f948c796730e","numerator_bits":14333,"sign":1},"case":"expanded_n1024_k16","kind":"actual_variation","method":"exact_continuous_primitive_no_quadrature","observed_sha256":"2f41560fa1bf0176aaeee6c583b9fbefcd5992b0ea18151a37d397577235470d","primitive_residual":{"denominator":"1","numerator":"0"}}
{"M":1,"T_small":4,"X":1,"case":"expanded_n1024_k16","epsilon":{"denominator":"119","numerator":"16"},"input_sha256":"beacaa0c4d76c199fb8b126d95412882d3fc6279e23e45475e6920af1086ecda","kind":"log_and_proxy_certificate","ledger_residual":{"denominator_bits":14342,"exact_sha256":"05e88281263801bcbaa529100730a986f6a699f4098901401ff7ff0cc045f632","numerator_bits":14327,"sign":1},"log_failure_margin":{"denominator_bits":14375,"exact_sha256":"2b1da065d8c0f860012977c6383693bc49c66af7889e4ba6ae69d71de194be6c","numerator_bits":14358,"sign":-1},"log_lower":{"denominator":"32769","numerator":"2"},"log_pass_margin":{"denominator_bits":14354,"exact_sha256":"8a57f7903b3e1619f7d5a4322d4bc0272a330a10a371b569a54b5429575df676","numerator_bits":14336,"sign":1},"log_to_u_residual":{"denominator":"52781390069760","numerator":"98309"},"log_upper":{"denominator":"52781390069760","numerator":"3221422081"},"near_residual":{"denominator_bits":14344,"exact_sha256":"fa0c53664ea967917b9c2467e65ed8f8ded2d869aec25866c68d351a4cc85475","numerator_bits":14326,"sign":1},"observed_sha256":"2f41560fa1bf0176aaeee6c583b9fbefcd5992b0ea18151a37d397577235470d","proxy_charge":{"denominator_bits":14340,"exact_sha256":"de1c19a3edd19e39a4e9dbcbd811aa51f1b0a86e22a0784c056917fd78057eb1","numerator_bits":14337,"sign":1},"scope":"SCALAR_PROXY_ONLY_NO_TRAFFIC_OR_FAR_ROOT_CERTIFICATION","status":"PASS"}
{"M":2,"T_small":4,"X":1,"case":"expanded_n1024_k16","epsilon":{"denominator":"119","numerator":"16"},"input_sha256":"beacaa0c4d76c199fb8b126d95412882d3fc6279e23e45475e6920af1086ecda","kind":"log_and_proxy_certificate","ledger_residual":{"denominator_bits":14342,"exact_sha256":"05e88281263801bcbaa529100730a986f6a699f4098901401ff7ff0cc045f632","numerator_bits":14327,"sign":1},"log_failure_margin":{"denominator_bits":14407,"exact_sha256":"aaad075fb3eb7d7e813d73e7936e193577a3e30929ed2b4e20a2b0ebceaae8c8","numerator_bits":14390,"sign":-1},"log_lower":{"denominator":"105562780237827","numerator":"6442844168"},"log_pass_margin":{"denominator_bits":14385,"exact_sha256":"9fe81d69a5acc8b59070bf0319f1f56848ccc8cdad37e50f6439d614bedc9ec3","numerator_bits":14368,"sign":1},"log_to_u_residual":{"denominator":"283385225903602957516800","numerator":"527824639262747"},"log_upper":{"denominator":"283385225903602957516800","numerator":"17295933717328691203"},"near_residual":{"denominator_bits":14344,"exact_sha256":"fa0c53664ea967917b9c2467e65ed8f8ded2d869aec25866c68d351a4cc85475","numerator_bits":14326,"sign":1},"observed_sha256":"2f41560fa1bf0176aaeee6c583b9fbefcd5992b0ea18151a37d397577235470d","proxy_charge":{"denominator_bits":14340,"exact_sha256":"de1c19a3edd19e39a4e9dbcbd811aa51f1b0a86e22a0784c056917fd78057eb1","numerator_bits":14337,"sign":1},"scope":"SCALAR_PROXY_ONLY_NO_TRAFFIC_OR_FAR_ROOT_CERTIFICATION","status":"PASS"}
{"M":4,"T_small":4,"X":1,"case":"expanded_n1024_k16","epsilon":{"denominator":"119","numerator":"16"},"input_sha256":"beacaa0c4d76c199fb8b126d95412882d3fc6279e23e45475e6920af1086ecda","kind":"log_and_proxy_certificate","ledger_residual":{"denominator_bits":14342,"exact_sha256":"05e88281263801bcbaa529100730a986f6a699f4098901401ff7ff0cc045f632","numerator_bits":14327,"sign":1},"log_failure_margin":{"denominator_bits":14470,"exact_sha256":"e88f2c00f523be455342f1ebf1fcbaed72969a33ee7edceb2eb5b14ea70d09fb","numerator_bits":14452,"sign":-1},"log_lower":{"denominator":"1420071995334169139061960136622115","numerator":"86671671138880686150661352224"},"log_pass_margin":{"denominator_bits":14449,"exact_sha256":"3861f44fed7bc91ce6ce556bfef9669a9eaef29a14ab147c0f6f146c0f0396c5","numerator_bits":14431,"sign":1},"log_to_u_residual":{"denominator":"1372395384287744832908636661658289363189760","numerator":"2556181594604181321574621676863607"},"log_upper":{"denominator":"1372395384287744832908636661658289363189760","numerator":"83761810535186696655387205997115211783"},"near_residual":{"denominator_bits":14344,"exact_sha256":"fa0c53664ea967917b9c2467e65ed8f8ded2d869aec25866c68d351a4cc85475","numerator_bits":14326,"sign":1},"observed_sha256":"2f41560fa1bf0176aaeee6c583b9fbefcd5992b0ea18151a37d397577235470d","proxy_charge":{"denominator_bits":14340,"exact_sha256":"de1c19a3edd19e39a4e9dbcbd811aa51f1b0a86e22a0784c056917fd78057eb1","numerator_bits":14337,"sign":1},"scope":"SCALAR_PROXY_ONLY_NO_TRAFFIC_OR_FAR_ROOT_CERTIFICATION","status":"PASS"}
{"M":8,"T_small":4,"X":1,"case":"expanded_n1024_k16","epsilon":{"denominator":"119","numerator":"16"},"input_sha256":"beacaa0c4d76c199fb8b126d95412882d3fc6279e23e45475e6920af1086ecda","kind":"log_and_proxy_certificate","ledger_residual":{"denominator_bits":14342,"exact_sha256":"05e88281263801bcbaa529100730a986f6a699f4098901401ff7ff0cc045f632","numerator_bits":14327,"sign":1},"log_failure_margin":{"denominator_bits":14596,"exact_sha256":"3c21533e00aa1676a618f7e068e3f62b0d41d5f35caca403769798f95ae23c2d","numerator_bits":14578,"sign":-1},"log_lower":{"denominator":"73634353305409129940820664286843339614356299413536912687764023394796885","numerator":"4494147110272931529281228623869522029001735373063697797795215824768"},"log_pass_margin":{"denominator_bits":14574,"exact_sha256":"90ad0113548bf099ba1dd34cf6bef4d430e64f249fc76ad2ccc3ad2f1a7b2178","numerator_bits":14556,"sign":1},"log_to_u_residual":{"denominator":"134417487897920707620804309377212599716288105153453354808857263449726637390725120","numerator":"250361894605115385350803050111674631215444231610182895191265380086555441"},"log_upper":{"denominator":"134417487897920707620804309377212599716288105153453354808857263449726637390725120","numerator":"8203942014687469324361005970461399538521134723825845554950100693221392777489"},"near_residual":{"denominator_bits":14344,"exact_sha256":"fa0c53664ea967917b9c2467e65ed8f8ded2d869aec25866c68d351a4cc85475","numerator_bits":14326,"sign":1},"observed_sha256":"2f41560fa1bf0176aaeee6c583b9fbefcd5992b0ea18151a37d397577235470d","proxy_charge":{"denominator_bits":14340,"exact_sha256":"de1c19a3edd19e39a4e9dbcbd811aa51f1b0a86e22a0784c056917fd78057eb1","numerator_bits":14337,"sign":1},"scope":"SCALAR_PROXY_ONLY_NO_TRAFFIC_OR_FAR_ROOT_CERTIFICATION","status":"PASS"}
{"a":{"denominator":"1","numerator":"1"},"b":{"denominator":"1","numerator":"1"},"input_sha256":"20c21e194e32314e1f17f7d0b3c0fba968a22063f3380fcb0bc972990dc3c05c","k":128,"kind":"configuration","n":1024,"name":"expanded_n1024_k128","points":[{"denominator":"1","numerator":"1"},{"denominator":"262144","numerator":"262145"},{"denominator":"131072","numerator":"131073"}],"r":{"denominator":"131072","numerator":"131073"},"reconstruct":"evaluate fixed menu in this code SHA","scope":"ABSTRACT_TWO_ATOM_NON_FULL"}
{"P":{"denominator":"1","numerator":"256"},"case":"expanded_n1024_k128","closed_rate_residual":{"denominator":"1","numerator":"0"},"dpi":[{"denominator":"1","numerator":"-256"},{"denominator":"1","numerator":"256"}],"full_variation":{"denominator":"1","numerator":"512"},"half_full_residual":{"denominator":"1","numerator":"0"},"kind":"actual_derivative","quotient_centered_residual":[{"denominator":"1","numerator":"0"},{"denominator":"1","numerator":"0"}],"quotient_mass_residual":{"denominator":"1","numerator":"0"},"range_margin":{"denominator":"1","numerator":"0"},"square_identity_residual":{"denominator":"1","numerator":"0"},"t":{"denominator":"1","numerator":"1"}}
{"P":{"denominator_bits":36867,"exact_sha256":"6689463e1d9cadf87caae178c760f85dca2ab0c16e4ac8133dcb9113e13cff98","numerator_bits":36875,"sign":1},"case":"expanded_n1024_k128","closed_rate_residual":{"denominator":"1","numerator":"0"},"dpi":[{"denominator_bits":36867,"exact_sha256":"383c42e1a299d508cc6a32e0ed7d11bd040eec890a5881a4b8da7dcd19255d55","numerator_bits":36875,"sign":-1},{"denominator_bits":36867,"exact_sha256":"6689463e1d9cadf87caae178c760f85dca2ab0c16e4ac8133dcb9113e13cff98","numerator_bits":36875,"sign":1}],"full_variation":{"denominator_bits":36867,"exact_sha256":"75a8f45e34ab3973ae9a0d4db538b6bcb28fc40a7cfb4e09355d736dc6bee75f","numerator_bits":36876,"sign":1},"half_full_residual":{"denominator":"1","numerator":"0"},"kind":"actual_derivative","quotient_centered_residual":[{"denominator":"1","numerator":"0"},{"denominator":"1","numerator":"0"}],"quotient_mass_residual":{"denominator":"1","numerator":"0"},"range_margin":{"denominator_bits":36867,"exact_sha256":"2ce45a81d676ea967e55c6f82dafa1188ff915251be7519116b258860b305558","numerator_bits":36857,"sign":1},"square_identity_residual":{"denominator":"1","numerator":"0"},"t":{"denominator":"262144","numerator":"262145"}}
{"P":{"denominator_bits":34819,"exact_sha256":"5cac23ddc21ecc9874777cba17a55c1d6031bc21ecc3a3923bc85425195e29eb","numerator_bits":34827,"sign":1},"case":"expanded_n1024_k128","closed_rate_residual":{"denominator":"1","numerator":"0"},"dpi":[{"denominator_bits":34819,"exact_sha256":"d79faae4a7faf606e379c14533d7658323aa91e853bbc5cb9aeaf44c6ab20bb5","numerator_bits":34827,"sign":-1},{"denominator_bits":34819,"exact_sha256":"5cac23ddc21ecc9874777cba17a55c1d6031bc21ecc3a3923bc85425195e29eb","numerator_bits":34827,"sign":1}],"full_variation":{"denominator_bits":34819,"exact_sha256":"760cdd3251f535573e5fe602de6da49c33b9b5974a1d8df3a15af804fe5bf459","numerator_bits":34828,"sign":1},"half_full_residual":{"denominator":"1","numerator":"0"},"kind":"actual_derivative","quotient_centered_residual":[{"denominator":"1","numerator":"0"},{"denominator":"1","numerator":"0"}],"quotient_mass_residual":{"denominator":"1","numerator":"0"},"range_margin":{"denominator_bits":34819,"exact_sha256":"b5f167e7731b3711d024966a7a65d260f850eb7426cdc5cbb643f1bda0ab8458","numerator_bits":34811,"sign":1},"square_identity_residual":{"denominator":"1","numerator":"0"},"t":{"denominator":"131072","numerator":"131073"}}
{"V":{"denominator_bits":17411,"exact_sha256":"c257edb9cecb8117f919b0c58e753894af1cf6bcf7f37bdc5b9314aba8a57ea8","numerator_bits":17402,"sign":1},"case":"expanded_n1024_k128","kind":"actual_variation","method":"exact_continuous_primitive_no_quadrature","observed_sha256":"43d7e4f39fdd2be5ed3f82dae331d20a1428cde7df73d5d08c96e7d5bb7972b6","primitive_residual":{"denominator":"1","numerator":"0"}}
{"M":1,"T_small":4,"X":1,"case":"expanded_n1024_k128","epsilon":{"denominator":"119","numerator":"2"},"input_sha256":"20c21e194e32314e1f17f7d0b3c0fba968a22063f3380fcb0bc972990dc3c05c","kind":"log_and_proxy_certificate","ledger_residual":{"denominator_bits":17414,"exact_sha256":"505bc0dea11b04a145d2723a4788076eefca2bf8ff04775cf324c173047a6c0d","numerator_bits":17391,"sign":1},"log_failure_margin":{"denominator_bits":17456,"exact_sha256":"78bbd8f672c741f24f1cb48ad1453b74a2cf5cf0b3233f4a1595abcc65c775d0","numerator_bits":17430,"sign":-1},"log_lower":{"denominator":"262145","numerator":"2"},"log_pass_margin":{"denominator_bits":17429,"exact_sha256":"78e7c7d48f2baa2e70bf6cdbacb8fa081dd0275fa4b98308977e11032da7465a","numerator_bits":17402,"sign":1},"log_to_u_residual":{"denominator":"27021907002654720","numerator":"786437"},"log_upper":{"denominator":"27021907002654720","numerator":"206160003073"},"near_residual":{"denominator_bits":17419,"exact_sha256":"546763c3d210491baf64d7c2567c59ce2fd9e09166b351f41762b8c369554d27","numerator_bits":17393,"sign":1},"observed_sha256":"43d7e4f39fdd2be5ed3f82dae331d20a1428cde7df73d5d08c96e7d5bb7972b6","proxy_charge":{"denominator_bits":17412,"exact_sha256":"bcc7bec2cfb44a7239db668cab8e5b99c4078b6a7d0dfebfe41171e006c61ad6","numerator_bits":17406,"sign":1},"scope":"SCALAR_PROXY_ONLY_NO_TRAFFIC_OR_FAR_ROOT_CERTIFICATION","status":"PASS"}
{"M":2,"T_small":4,"X":1,"case":"expanded_n1024_k128","epsilon":{"denominator":"119","numerator":"2"},"input_sha256":"20c21e194e32314e1f17f7d0b3c0fba968a22063f3380fcb0bc972990dc3c05c","kind":"log_and_proxy_certificate","ledger_residual":{"denominator_bits":17414,"exact_sha256":"505bc0dea11b04a145d2723a4788076eefca2bf8ff04775cf324c173047a6c0d","numerator_bits":17391,"sign":1},"log_failure_margin":{"denominator_bits":17491,"exact_sha256":"1ce0799f73bdb68ffbbd51d486bf51c56ea5c567b553af85dbb37f49ec3527f5","numerator_bits":17465,"sign":-1},"log_lower":{"denominator":"54043814006095875","numerator":"412320006152"},"log_pass_margin":{"denominator_bits":17466,"exact_sha256":"26eabe42aa25f2bb7cb8096c9b213c4aa30d41536eee9ef318245c66d6ae3188","numerator_bits":17440,"sign":1},"log_to_u_residual":{"denominator":"1031636376066603908956160000","numerator":"30024417470054403"},"log_upper":{"denominator":"1031636376066603908956160000","numerator":"7870730901383646194347"},"near_residual":{"denominator_bits":17419,"exact_sha256":"546763c3d210491baf64d7c2567c59ce2fd9e09166b351f41762b8c369554d27","numerator_bits":17393,"sign":1},"observed_sha256":"43d7e4f39fdd2be5ed3f82dae331d20a1428cde7df73d5d08c96e7d5bb7972b6","proxy_charge":{"denominator_bits":17412,"exact_sha256":"bcc7bec2cfb44a7239db668cab8e5b99c4078b6a7d0dfebfe41171e006c61ad6","numerator_bits":17406,"sign":1},"scope":"SCALAR_PROXY_ONLY_NO_TRAFFIC_OR_FAR_ROOT_CERTIFICATION","status":"PASS"}
{"M":4,"T_small":4,"X":1,"case":"expanded_n1024_k128","epsilon":{"denominator":"119","numerator":"2"},"input_sha256":"20c21e194e32314e1f17f7d0b3c0fba968a22063f3380fcb0bc972990dc3c05c","kind":"log_and_proxy_certificate","ledger_residual":{"denominator_bits":17414,"exact_sha256":"505bc0dea11b04a145d2723a4788076eefca2bf8ff04775cf324c173047a6c0d","numerator_bits":17391,"sign":1},"log_failure_margin":{"denominator_bits":17568,"exact_sha256":"e183dad1409ad5d34ae20a50dbce72202217898b379624b7afd1ae06b47e04e9","numerator_bits":17542,"sign":-1},"log_lower":{"denominator":"1786530131108249750189012036581350703125","numerator":"13630091217585042596640586492123616"},"log_pass_margin":{"denominator_bits":17541,"exact_sha256":"8d4de56250bfa1bae1e33a300a2182c28bcb4b202456735e3a8ed4fa38d22aa3","numerator_bits":17514,"sign":1},"log_to_u_residual":{"denominator":"184155528658748665631754977021128118667079680000000","numerator":"5359604023415966809163976921095082344567"},"log_upper":{"denominator":"184155528658748665631754977021128118667079680000000","numerator":"1404989823644486301072337084048043189181874183"},"near_residual":{"denominator_bits":17419,"exact_sha256":"546763c3d210491baf64d7c2567c59ce2fd9e09166b351f41762b8c369554d27","numerator_bits":17393,"sign":1},"observed_sha256":"43d7e4f39fdd2be5ed3f82dae331d20a1428cde7df73d5d08c96e7d5bb7972b6","proxy_charge":{"denominator_bits":17412,"exact_sha256":"bcc7bec2cfb44a7239db668cab8e5b99c4078b6a7d0dfebfe41171e006c61ad6","numerator_bits":17406,"sign":1},"scope":"SCALAR_PROXY_ONLY_NO_TRAFFIC_OR_FAR_ROOT_CERTIFICATION","status":"PASS"}
{"M":8,"T_small":4,"X":1,"case":"expanded_n1024_k128","epsilon":{"denominator":"119","numerator":"2"},"input_sha256":"20c21e194e32314e1f17f7d0b3c0fba968a22063f3380fcb0bc972990dc3c05c","kind":"log_and_proxy_certificate","ledger_residual":{"denominator_bits":17414,"exact_sha256":"505bc0dea11b04a145d2723a4788076eefca2bf8ff04775cf324c173047a6c0d","numerator_bits":17391,"sign":1},"log_failure_margin":{"denominator_bits":17721,"exact_sha256":"c254a771fe3089d4a161bbfd114fafbe2dc0b9c5cbb9c41522dd3e398ce15c78","numerator_bits":17694,"sign":-1},"log_lower":{"denominator":"6573957902981572648704787817135385516411220321368300674333484325644060616607666015625","numerator":"50155127147292226043811560832775772087971928581221034561988310864230187851875712"},"log_pass_margin":{"denominator_bits":17692,"exact_sha256":"5af9f9da542b013cf976a5fa49b4d374d1056cbe32107c51e72ede46caa93780","numerator_bits":17666,"sign":1},"log_to_u_residual":{"denominator":"1279993449169775267704349664690531516064172516320304489027121311231285419259591160000000000000000","numerator":"37252522854357967488607302109212146941594547183415486179308318166484841256234826110179"},"log_upper":{"denominator":"1279993449169775267704349664690531516064172516320304489027121311231285419259591160000000000000000","numerator":"9765537768608853922247581466325603160168827725523499026432165656520131696765731985388733571"},"near_residual":{"denominator_bits":17419,"exact_sha256":"546763c3d210491baf64d7c2567c59ce2fd9e09166b351f41762b8c369554d27","numerator_bits":17393,"sign":1},"observed_sha256":"43d7e4f39fdd2be5ed3f82dae331d20a1428cde7df73d5d08c96e7d5bb7972b6","proxy_charge":{"denominator_bits":17412,"exact_sha256":"bcc7bec2cfb44a7239db668cab8e5b99c4078b6a7d0dfebfe41171e006c61ad6","numerator_bits":17406,"sign":1},"scope":"SCALAR_PROXY_ONLY_NO_TRAFFIC_OR_FAR_ROOT_CERTIFICATION","status":"PASS"}
{"kind":"stage_complete","result":"PASS_FIXED_MENU","stage":"3"}
{"kind":"complete","result":"PASS_FIXED_MENU_NO_FULL_PAYMENT_CLAIM","undetermined":0}
````
<!-- REPRO-FILE-END -->

<!-- REPRO-FILE-BEGIN name="execution_receipt.json" bytes="3428" sha256="b6f2cbd87fb336647112195b5599a4b2741c676d5ce9d41a805ab4eff058cff3" -->
````json
{
  "producer_sha256": "1d877b24cb8ea49ba37de12cd12b3430b739c1877f82b2486a70b59fcd311e18",
  "output_sha256": "48226578218569ba9c0ad147e5cfb2e112ce0cc940e8443ac9aa6a782e6d7fb2",
  "protocol_sha256": "7d4346533c53b76d82320ad593df3fd4134119bd8153498d2bd28ed88b548fd1",
  "python": "3.14.6 (main, Jun 10 2026, 10:03:53) [Clang 21.0.0 (clang-2100.0.123.102)]",
  "arithmetic": "fractions.Fraction; analytic rational enclosure of log r",
  "record_runs": [
    {
      "stage": "1",
      "command": [
        "/opt/homebrew/opt/python@3.14/bin/python3.14",
        "/Users/zhengzhihao/Desktop/T/output/centered_cube_round118_20261014/numeric.py",
        "--stage",
        "1",
        "--record",
        "/Users/zhengzhihao/Desktop/T/output/centered_cube_round118_20261014/stage1_record_private.jsonl"
      ],
      "exit_code": 0,
      "seconds": 0.034089792001395836,
      "producer_sha256": "1d877b24cb8ea49ba37de12cd12b3430b739c1877f82b2486a70b59fcd311e18",
      "stdout_sha256": "afdd2808eeb89f22d814552dd1cc3e5b9c52a69fbda4129ef44b6d56b1c18403",
      "stdout_bytes": 4550,
      "stderr_bytes": 0
    },
    {
      "stage": "2",
      "command": [
        "/opt/homebrew/opt/python@3.14/bin/python3.14",
        "/Users/zhengzhihao/Desktop/T/output/centered_cube_round118_20261014/numeric.py",
        "--stage",
        "2",
        "--record",
        "/Users/zhengzhihao/Desktop/T/output/centered_cube_round118_20261014/stage2_record_private.jsonl"
      ],
      "exit_code": 0,
      "seconds": 0.03560966700024437,
      "producer_sha256": "1d877b24cb8ea49ba37de12cd12b3430b739c1877f82b2486a70b59fcd311e18",
      "stdout_sha256": "c13adacabfae2798a189043c01e86942d399175bf23bbf8951f326c170256d98",
      "stdout_bytes": 22529,
      "stderr_bytes": 0
    },
    {
      "stage": "3",
      "command": [
        "/opt/homebrew/opt/python@3.14/bin/python3.14",
        "/Users/zhengzhihao/Desktop/T/output/centered_cube_round118_20261014/numeric.py",
        "--stage",
        "3",
        "--record",
        "/Users/zhengzhihao/Desktop/T/output/centered_cube_round118_20261014/stage3_record_private.jsonl"
      ],
      "exit_code": 0,
      "seconds": 0.06721400000060385,
      "producer_sha256": "1d877b24cb8ea49ba37de12cd12b3430b739c1877f82b2486a70b59fcd311e18",
      "stdout_sha256": "d265ad83609d618a81d859f4e2a14f1b6c9c5c68d4aef5b481d9de7eb0435cc9",
      "stdout_bytes": 77409,
      "stderr_bytes": 0
    }
  ],
  "isolated_replay_runs": [
    {
      "stage": "1",
      "exit_code": 0,
      "seconds": 0.03433966700140445,
      "stdout_sha256": "afdd2808eeb89f22d814552dd1cc3e5b9c52a69fbda4129ef44b6d56b1c18403",
      "stderr_bytes": 0,
      "byte_identical": true
    },
    {
      "stage": "2",
      "exit_code": 0,
      "seconds": 0.03470591700170189,
      "stdout_sha256": "c13adacabfae2798a189043c01e86942d399175bf23bbf8951f326c170256d98",
      "stderr_bytes": 0,
      "byte_identical": true
    },
    {
      "stage": "3",
      "exit_code": 0,
      "seconds": 0.06703987499895447,
      "stdout_sha256": "d265ad83609d618a81d859f4e2a14f1b6c9c5c68d4aef5b481d9de7eb0435cc9",
      "stderr_bytes": 0,
      "byte_identical": true
    }
  ],
  "byte_identical": true,
  "exit_codes": [
    0,
    0,
    0,
    0,
    0,
    0
  ],
  "stdout_bytes": 104488,
  "actual_full_certificate": false,
  "general_goal": "UNPROVED",
  "actual_traffic_payment_certified_by_numerics": false
}
````
<!-- REPRO-FILE-END -->
