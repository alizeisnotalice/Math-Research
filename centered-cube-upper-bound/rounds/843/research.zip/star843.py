"""R843 finite true-position star telescoping and shifted thin intersections."""
from dataclasses import dataclass
from fractions import Fraction as F
from itertools import combinations, pairwise, product
from math import prod
import sys

TAG = ("a", "b", "w")
MASS = (F(3, 5), F(7, 10), F(7, 5))
AT = (F(-17, 20), F(0), F(9, 10))
PACKET_WIDTH = F(1, 2048)
PROFILES = ((F(1), F(3, 4), F(1, 2), F(1, 4), F(0)),
            (F(1), F(1), F(1, 2), F(1, 2), F(1, 4)),
            (F(1), F(1, 2), F(1, 2), F(0), F(0)),
            (F(3, 4), F(3, 4), F(1, 4), F(1, 4), F(1, 8)))


def support(center, width):
    return center-width/2, center+width/2


def inc(lo, hi):
    return max(F(0), hi-lo)


@dataclass(frozen=True)
class Core:
    x: tuple
    L: F
    mask: tuple

    @property
    def width(self):
        return self.x[1]-self.x[0]


def real_cores():
    cores = (Core(support(F(-17, 40), F(1, 32)), F(1), (0, 1)),
             Core(support(F(4, 5), F(1, 32)), F(2), (1, 2)),
             Core(support(F(0), F(1, 4096)), F(2), (0, 1, 2)))
    sources = tuple(support(p, PACKET_WIDTH) for p in AT)
    assert all(x[1]<y[0] or y[1]<x[0] for x,y in combinations(sources,2))
    assert all(x.x[1]<y.x[0] or y.x[1]<x.x[0] for x,y in combinations(cores,2))
    for i,c in enumerate(cores):
        x,y = c.x
        dist = tuple(max(a-y,x-b) for a,b in sources)
        for j,(a,b) in enumerate(sources):
            if j in c.mask:
                assert max(b-x,y-a)<c.L/2
            else:
                assert dist[j]>1
        mass = sum(MASS[j] for j in c.mask)
        if i == 0:
            cap = mass
        elif i == 1:
            assert dist[1]>F(3,4)
            cap = max(MASS[2],mass/F(3,2))
        else:
            assert min(dist[0],dist[2])>F(3,4)
            cap = max(MASS[1],mass/F(3,2))
        assert 1<mass/c.L<=cap<=2
    print("Actual overlap geometry: positive packet width", PACKET_WIDTH,
          "source (location,mass)", tuple(zip(AT,MASS,strict=True)))
    print("  real disjoint (core, L, tag mask)", cores, "lambda=1, all cores in 1<M_I<=2")
    return cores


def g(cores, x, a, z):
    assert z in cores[x].mask
    if a not in cores[x].mask:
        return (F(0),)*5
    p = PROFILES[(x+2*a+z)%len(PROFILES)]
    assert all(0<=v<=u<=1 for u,v in pairwise(p))
    return p


def star_tuple(cores, marks):
    picked = tuple(cores[x] for x,_ in marks)
    # Each x_i is an independent Lebesgue variable on its actual core.
    lo = inc(max(c.x[1]-c.L/2 for c in picked),min(c.x[0]+c.L/2 for c in picked))
    hi = inc(max(c.x[0]-c.L/2 for c in picked),min(c.x[1]+c.L/2 for c in picked))
    true_mass = sum(MASS[a] for a in range(3) if all(a in c.mask for c in picked))
    assert true_mass>0 and 0<lo<=hi
    stage = [F(0)]*5
    first = [F(0)]*4
    first_future = [F(0)]*4
    for a,m in enumerate(MASS):
        weights = [g(cores,x,a,z) for x,z in marks]
        for j in range(5):
            stage[j] += m*prod(s[j] for s in weights)
        for j in range(4):
            loss = weights[0][j]-weights[0][j+1]
            first[j] += m*loss*prod(s[j] for s in weights[1:])
            first_future[j] += m*loss*prod(s[j+1] for s in weights[1:])
    deltas = tuple(u-v for u,v in pairwise(stage))
    assert all(0<=a<=b<=c for a,b,c in zip(first_future,first,deltas,strict=True))
    assert sum(deltas)==stage[0]-stage[-1] and stage[0]<=true_mass
    # Strict crossing of the frozen lower geometric cap K lambda |I|.
    K, lam = F(1), F(1)
    entry = next(j for j,l in enumerate(stage) if l<K*lam*lo)
    post = sum(first[entry:])
    assert post<=stage[entry]-stage[-1]<K*lam*lo<=K*lam*hi
    # Distinct (x_i,z_i) variables retain their true x widths and source mass.
    product_measure = prod(cores[x].width*MASS[z] for x,z in marks)
    return (lo,hi,true_mass,stage,first,first_future,deltas,entry,post,product_measure)


def scan_stars(cores):
    options = [(i,z) for i,c in enumerate(cores) for z in c.mask]
    for m,cases in ((2,product(options,repeat=2)),(3,product(options,repeat=3)),
                    (7,(((0,0),(1,2),(2,2))*2+(tip,) for tip in options))):
        counts = [0,0,0]
        strict = 0
        weighted_paid = F(0)
        weighted_cap = F(0)
        for marks in cases:
            lo,hi,eta,stage,first,_,deltas,entry,post,mu = star_tuple(cores,marks)
            counts[0] += 1
            counts[1] += stage[0]<eta
            counts[2] += entry>0
            strict += sum(u<v for u,v in zip(first,deltas,strict=True))
            weighted_paid += mu*post
            weighted_cap += mu*lo
        assert counts[0]==(7**m if m<7 else 7)
        assert counts[1]>0 and strict>0 and weighted_paid<=weighted_cap
        print("  m",m,"tuples",counts[0],"initial joint g below eta(I)",counts[1],
              "safe gate entered after stage 0",counts[2],"strict first-coordinate increments",strict,
              "integrated later charge",weighted_paid,"valid integrated frozen cap",weighted_cap)
    marks = ((0,0),(1,2),(2,2))
    lo,hi,eta,st,only,future,delta,entry,post,mu = star_tuple(cores,marks)
    assert (lo,hi,eta)==(F(39,160),F(49,160),F(7,10))
    assert st==[F(7,10),F(7,40),F(7,80),0,0] and entry==1 and post==F(7,80)
    print("  fixed true tuple (left,a),(right,w),(tiny,w): I length bounds", (lo,hi),"eta(I)",eta)
    print("   L_j",st,"loss", delta,"only-first with old companions", only,
          "with future companions",future,"entry",entry,"later charge",post,"dx d eta(z) product",mu)
    # The actual relation g_j * dx d eta(a)d eta(z)/L^(2) is a nested positive subflow.
    original = []
    for j in range(5):
        value = sum(c.width*MASS[a]*MASS[z]*g(cores,x,a,z)[j]/c.L**2
                    for x,c in enumerate(cores) for a,z in product(c.mask,repeat=2))
        original.append(value)
    assert all(0<v<u for u,v in pairwise(original))
    print("  actual retained original two-point masses through the same five stages", original)


def thin_comparison():
    eps, W, S = F(1,128), F(1,512), F(1,4)
    x0,x1 = support(F(0),W),support(1-eps,W)
    positions = (F(0),F(1,2)-eps/2,1-eps)
    sources = tuple(support(x,PACKET_WIDTH) for x in positions)
    assert x0[1]<x1[0]
    assert all(a[1]<b[0] for a,b in pairwise(sources))
    # Original witness at each actual receiver sees one unit private mass
    # and the 1/4 shared packet. All lengths <=3/2 miss the remote private
    # packet; larger lengths see at most 9/4, so the true height is <=3/2.
    assert sources[2][0]-x0[1]>F(3,4) and x1[0]-sources[0][1]>F(3,4)
    for core, accepted in ((x0,(0,1)),(x1,(1,2))):
        for i in accepted:
            a,b = sources[i]
            assert max(b-core[0],core[1]-a)<F(1,2)
    assert 1<F(5,4)<F(3,2)
    true, expected = [], []
    for x,y in product(x0,x1):
        a = support(x,F(1))
        receivers = [support(y+d,F(1)) for d in (F(0),-S)]
        sizes = []
        for b in receivers:
            I = max(a[0],b[0]),min(a[1],b[1])
            assert sources[0][1]<I[0]<sources[1][0]<sources[1][1]<I[1]<sources[2][0]
            assert I[0]==b[0] and I[1]==a[1]
            # Right comparison box still sees the shared and right packet.
            assert b[0]<sources[1][0]<sources[2][1]<b[1]
            sizes.append(I[1]-I[0])
        assert sizes[1]==sizes[0]+S
        true.append(sizes[0])
        expected.append(sum(sizes)/2)
    uniform_true, uniform_compare = (min(true),max(true)),(min(expected),max(expected))
    assert uniform_true==(F(3,512),F(5,512)) and uniform_compare==(F(67,512),F(69,512))
    m_common = F(1,4)
    assert 2*uniform_true[1]<m_common<2*uniform_compare[0]
    # The affine endpoint assignment is unchanged over the product.
    # Averaging two independent true receiver positions gives gap eps.
    raw, averaged = W**2*eps,W**2*(eps+S/2)
    assert averaged/raw==17
    print("Independent positive thin witness rows, boxes L=1, cores", (x0,x1),
          "source widths",PACKET_WIDTH,"common positive eta",m_common)
    print("  fixed comparison translations (0,-1/4) with probabilities (1/2,1/2), one row fixed")
    print("  true intersection interval",uniform_true,"expected comparison interval",uniform_compare,
          "two true dx integral",raw,"comparison integral",averaged,"ratio", averaged/raw)
    print("  K=2: eta(I)>K*true |I| everywhere but eta(I)<K*expected comparison |I| everywhere.")


def main():
    print("Replay:",sys.executable,"-B star843.py > star843.txt")
    print("Python",sys.version.split()[0],"exact Fraction; no external dependencies.")
    print("Monotone row profiles:",PROFILES)
    scan_stars(real_cores())
    thin_comparison()
    print("Finite physical-position and deletion certificates only.")
    print("PASS")


if __name__=="__main__":
    main()
