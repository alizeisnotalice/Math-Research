"""Exact positive-width R843 witness and weighted Gram certificate."""
from dataclasses import dataclass
from decimal import Decimal, ROUND_CEILING, ROUND_FLOOR, localcontext
from fractions import Fraction as F
from itertools import combinations, product
from math import prod
import sys

WIDE = F(1, 32)
WIDTHS = tuple(F(1, 2**p) for p in (7, 12, 20, 28))
MASSES = (F(3, 5), F(7, 10), F(7, 5))
POSITIONS = (F(-17, 20), F(0), F(9, 10))
PACKET_WIDTH = F(1, 2048)


def show(x):
    with localcontext() as ctx:
        ctx.prec = 15
        ctx.rounding = ROUND_FLOOR
        lo = Decimal(x.numerator)/Decimal(x.denominator)
        ctx.rounding = ROUND_CEILING
        hi = Decimal(x.numerator)/Decimal(x.denominator)
    return f"[{lo}, {hi}]"


def interval(c, width):
    return c-width/2, c+width/2


@dataclass(frozen=True)
class Core:
    c: F
    width: F
    v: F
    d: int
    tags: frozenset

    @property
    def mass(self):
        return sum(MASSES[i] for i in self.tags)

    @property
    def integral(self):
        return self.width*self.d/self.v**2


def family(width, bridge):
    left = Core(F(-17, 40), WIDE, F(1), 1, frozenset((0, 1)))
    right = (Core(F(4, 5), WIDE, F(2), 2, frozenset((1, 2))) if bridge else
             Core(F(13, 10), WIDE, F(1), 1, frozenset((2,))))
    return left, right, Core(F(0), width, F(2), 2, frozenset((0, 1, 2)))


def validate(cores):
    packets = [interval(x, PACKET_WIDTH) for x in POSITIONS]
    assert all(b<c or d<a for (a,b),(c,d) in combinations(packets, 2))
    ranges = [interval(core.c, core.width) for core in cores]
    assert all(b<c or d<a for (a,b),(c,d) in combinations(ranges, 2))
    caps = []
    for i, (core, (x, y)) in enumerate(zip(cores, ranges, strict=True)):
        assert core.width > 0 and 1 <= core.v <= 2 and core.d <= core.v < 2*core.d
        near = [max(u-y, x-v) for u,v in packets]
        for j, (u,v) in enumerate(packets):
            if j in core.tags:
                assert max(v-x, y-u) < core.v/2
            else:
                assert near[j] > 1
        if i == 0 or core.tags == frozenset((2,)):
            cap = core.mass
        elif i == 1:
            assert near[1] > F(3, 4)
            cap = max(MASSES[2], core.mass/F(3, 2))
        else:
            assert min(near[0], near[2]) > F(3, 4)
            cap = max(MASSES[1], core.mass/F(3, 2))
        assert 1 < core.mass/core.v <= cap <= 2
        caps.append(cap)
    return caps


def gram(cores, D):
    return tuple(tuple(sum((c.integral for c in cores if c.d<=D and {i,j}<=c.tags), F(0))
                       for j in range(3)) for i in range(3))


def weighted(a, b):
    return tuple(tuple(sum(a[i][j]*MASSES[j]*b[j][k] for j in range(3))
                       for k in range(3)) for i in range(3))


def scores(T):
    T2, T3 = weighted(T,T), weighted(weighted(T,T),T)
    assert T2 == tuple(zip(*T2, strict=True)) and T3 == tuple(zip(*T3, strict=True))
    c2 = T[0][2]**2/(T[0][0]*T[2][2])
    f = T2[0][2]**2/(T3[0][0]*T[2][2])
    rev = T2[0][2]**2/(T3[2][2]*T[0][0])
    assert all(0<=x<=1 for x in (c2,f,rev))
    return T2,T3,c2,f,rev


def bessel(cores):
    for name, picked in (("d=1",[c for c in cores if c.d==1]), ("d=2",[c for c in cores if c.d==2]),
                         ("D<=2",list(cores))):
        loads = tuple(sum((c.integral*c.mass for c in picked if i in c.tags), F(0)) for i in range(3))
        for f in ((F(1),F(-2),F(3,2)), (F(0),F(1),F(0)), (F(1),F(0),F(1))):
            exact = sum(c.integral*sum(MASSES[i]*f[i] for i in c.tags)**2 for c in picked)
            cs = sum(MASSES[i]*loads[i]*f[i]**2 for i in range(3))
            assert exact<=cs<=max(loads)*sum(MASSES[i]*f[i]**2 for i in range(3))
        print("  orthogonal receiver projection and source-mass Cauchy",name,"loads",loads,"cap",max(loads))


def replay(bridge):
    print("Geometry:", "actual wide bridge b" if bridge else "same f, right wide core has w alone")
    limits = scores(gram(family(F(0),bridge),2))
    old = F(1)
    for width in WIDTHS:
        cores = family(width,bridge)
        caps = validate(cores)
        T = gram(cores,2)
        T2,T3,c2,f,rev = scores(T)
        true = sum(c.width*MASSES[0]*MASSES[2]/c.v**2 for c in cores if {0,2}<=c.tags)
        assert true==F(21,100)*width>0 and T[0][2]==width/2 and c2<old
        old = c2
        if bridge:
            assert min(f,rev)>F(1,10)
        print("  Xtiny width",width,"true J_X(a,w)",true,"T(a,w)",T[0][2],
              "C2^2,C4^2(a,w),C4^2(w,a)",tuple(show(x) for x in (c2,f,rev)))
        if width==WIDTHS[1]:
            print("  cores (center,width,v,d,true mass,height upper,H² integral)",
                  [(c.c,c.width,c.v,c.d,c.mass,cap,c.integral) for c,cap in zip(cores,caps,strict=True)])
            print("  exact T, T², T³ at this width:",T,T2,T3)
            if bridge:
                assert gram(cores,1)[2][2]==0
                floor = limits[0][0][2]**2/(T3[0][0]*T[2][2])
                assert floor>F(1,10)
                print("  C4^2 uniform forward lower for 0<width<=1/4096 by entrywise monotonicity",show(floor))
                print("  D=1 has zero w norm; two-end normalized score undefined.")
                bessel(cores)
    assert limits[2:]==((F(0),F(49,387),F(2,11)) if bridge else (0,0,0))
    if not bridge:
        assert max(f,rev)<F(1,10**10)
    print("  exact zero-width limits C2^2, forward C4^2, reverse C4^2",limits[2:])


def paid_intersection():
    cores = family(F(1, 4096), True)
    packet_boxes = tuple(interval(x, PACKET_WIDTH) for x in POSITIONS)
    for k in (2, 3):
        lengths = []
        selected = cores[:k]
        for receivers in product(*(interval(x.c, x.width) for x in selected)):
            left = max(x-core.v/2 for x, core in zip(receivers, selected, strict=True))
            right = min(x+core.v/2 for x, core in zip(receivers, selected, strict=True))
            # The same two active affine endpoints at all vertices; hence
            # they are active everywhere on the actual receiver product.
            assert left == receivers[1]-1 and right == receivers[0]+F(1, 2)
            assert left < packet_boxes[1][0] < packet_boxes[1][1] < right
            assert packet_boxes[0][1] < left and right < packet_boxes[2][0]
            lengths.append(right-left)
        limits = min(lengths), max(lengths)
        bounds = MASSES[1]/limits[1], MASSES[1]/limits[0]
        assert limits == (F(39, 160), F(49, 160))
        assert bounds == (F(16, 7), F(112, 39))
        actual_dx = prod(x.width for x in selected)
        assert actual_dx == (F(1, 1024) if k == 2 else F(1, 4194304))
        print("paid witness intersection with", k, "independent true dx slots: |I|", limits,
              "eta(I)", MASSES[1], "eta(I)/|I|", bounds, "receiver product volume", actual_dx)
    without = family(F(1, 4096), False)
    for xl, xr in product(*(interval(c.c, c.width) for c in without[:2])):
        assert xl+F(1, 2) < xr-F(1, 2)
    print("  no-wide-bridge control: intersection of the two wide witnesses empty uniformly.")


def main():
    print("Replay:",sys.executable,"-B geometry843.py > geometry843.txt")
    print("Python",sys.version.split()[0],"Fraction and outward decimal display.")
    print("n=1, lambda=1, centers",POSITIONS,"packet width",PACKET_WIDTH,"masses",MASSES,
          "densities",tuple(x/PACKET_WIDTH for x in MASSES))
    print("v_x=witness volume, d=volume band, shared height window 1<M_[1,2]<=2.")
    replay(True)
    replay(False)
    paid_intersection()
    print("Finite exact geometry and moment matrices. No high-dimensional terminal qualification.")
    print("PASS")


if __name__=="__main__":
    main()
