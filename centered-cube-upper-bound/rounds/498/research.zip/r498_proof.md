# R498：局部实际质量 ceiling 与可支付的 signed 来源混合修正

同 R497 的固定真实场及同一个 max-only 父核 \(K_0\)。记 \(\widehat\nu=\nu_\tau ds\)、\(c=rS\)、\(\beta=c/T\)、\(L=\log(m_+/m_-)\)、\(K=\kappa T\)。目标仍是完整
\(I=\int b_RG\,d\widehat\nu\)，其中 \(G=(I-K_0^*)^{-1}1\)。

本稿证明：可把 R497 全局 \(m_+\) 换成每个来源实际可捕获父的最高质量，**全部来源重置修正另付一个明确的维数无关 \(W\) 价**。没有假设源协方差有利，也没有解决新的局部头部谱的根阶费用；故完整目标仍未闭合。

## 1. 可测局部候选

对 \(\rho_x(d\widehat A)=c_A(x)\widehat\nu(d\widehat A)/m_A\)，定义
\[
 M(x)=\operatorname*{ess\,sup}_{\widehat A\sim\rho_x}m_A.
\]
零行取 \(M(x)=m_-\)。用有理质量阈值 \(\rho_x\{m_A>u\}>0\) 表示，\(M\) 可测且 \(m_-\le M(x)\le m_+\)。对原 joint \(\widehat\nu(d\widehat A)\pi_A(dx)\) 几乎处处有 \(m_A\le M(x)\)。这是真实 source-dependent ceiling，不是逐来源重选接收半径。

置
\[
 \ell(x)=\log M(x),\qquad h(A)=\int\ell(x)\pi_A(dx),
\]
\[
 \psi_x(\widehat A)=e^\beta[1+\beta\log(M(x)/m_A)],\qquad
 \Phi_{\rm loc}(\widehat A)=\pi_A\psi_x
 =e^\beta[1+\beta(h(A)-\log m_A)]. \tag{1}
\]
这些函数在有效 joint 上有界且至少1；不是先假定 \(\Phi_{\rm loc}\) 已为父上解。

固定 \(x\)，令实际祖先算子
\[
 (V_x f)(\widehat B)=\frac1T\int_{\widehat A\succ\widehat B}
 1_{\{v_x(\widehat A)\ge K\}}
 e^{-[v_x(\widehat A)-v_x(\widehat B)]/T}
 f(\widehat A)\rho_x(d\widehat A).
\]
R497 闭原子窗 \(\rho_x[m,M]\le c(1+\log(M/m))\) 对这个局部 ceiling 同样成立。其分段积分证明逐来源
\[
 d_x(\widehat B):=\psi_x(\widehat B)-1-(V_x\psi_x)(\widehat B)\ge0.
\tag{2}
\]
质量原子仍以 mark 保留；输入 rank 门只减少正核。

## 2. 来源重置的精确残差，不能免费删去

定义 \(d(\widehat B)=\pi_B d_x\ge0\) 及
\[
 C(\widehat B)=\int\pi_B(dx)
 V_x\bigl[h(A)-\ell(x)\bigr](\widehat B).
\tag{3}
\]
\(\Phi_{\rm loc}(A)-\psi_x(A)=e^\beta\beta[h(A)-\ell(x)]\)，故父核准确满足
\[
 K_0^*\Phi_{\rm loc}=\Phi_{\rm loc}-1-d+e^\beta\beta C.
\tag{4}
\]
没有 \(C\le0\) 的假设。由 \(|h(A)-\ell(x)|\le L\) 与 \(K_0^*1\le1\)，
\[
 |C|\le L. \tag{5}
\]
设 \(u=(I-K_0)^{-1}b_R\)。它是此 raw 父链最终 rank 停止的概率，故 \(0\le u\le1\)；\(1-u\) 是最终 raw 空样本概率，且
\[
 \int(1-u)\,d\widehat\nu=E_{\rm empty}
 \le A_*Te^{-\kappa}W,\qquad
 A_*\le3+8cL/T. \tag{6}
\]
所有终端由 R495 分数列帽趋零。将(4)迭代并与 \(b_R\) 配对，保真实负项得到
\[
 I=\int b_R\Phi_{\rm loc}d\widehat\nu
       +e^\beta\beta\int uC\,d\widehat\nu
       -\int ud\,d\widehat\nu. \tag{7}
\]
有界势与几何终端帽使该式没有 \(\infty-\infty\)。这里只使用同一个 raw 核；不为原成功链刷新历史。

## 3. signed 混合项与头部联合结算

写 \(E_x(\widehat A)=1_{\{v_x(\widehat A)<K\}}\)，
\(n_x(\widehat A)=1_{\{v_x(\widehat A)\ge K\}}e^{-v_x(\widehat A)/T}\)。按父先积所有输出最大点，核行质量为
\(a_x=1-E_x-n_x\)。有界 signed Fubini 给
\[
 \int C\,d\widehat\nu
 =\int\widehat\nu(d\widehat A)\pi_A(dx)[h(A)-\ell(x)]a_x
 =-C_{\rm head}-C_{\rm emp}, \tag{8}
\]
其中
\[
 C_{\rm head}=\int\widehat\nu\pi_A E_x(h(A)-\ell(x)),\qquad
 C_{\rm emp}=\int\widehat\nu\pi_A n_x(h(A)-\ell(x)).
\]
第二个等号准确使用每父 \(\pi_A(h-\ell)=0\)，不是丢掉实际 rank 门。

父均值头部与真正来源头部之差恰为
\[
 \int b_R\Phi_{\rm loc}d\widehat\nu
 -\int\widehat\nu\pi_A E_x\psi_x
 =e^\beta\beta C_{\rm head}.
\]
因此(7)–(8)合并为整目标的精确 signed 账
\[
 \boxed{I=
 \int\widehat\nu\pi_A E_x\psi_x
 -e^\beta\beta C_{\rm emp}
 -e^\beta\beta\int(1-u)C\,d\widehat\nu
 -\int ud\,d\widehat\nu.} \tag{9}
\]
这一步不能先取 \(C_+\)；取正部会毁掉头部抵消。已证自然空样本一次价为 \(Te^{-\kappa}W\)，所以
\[
 |C_{\rm emp}|\le LTe^{-\kappa}W,
 \qquad
 \left|\int(1-u)C\,d\widehat\nu\right|
 \le LA_*Te^{-\kappa}W. \tag{10}
\]
从而全部来源混合误差至多
\[
 C_{\rm mix}W,\qquad
 C_{\rm mix}=e^\beta cL(1+A_*)e^{-\kappa}. \tag{11}
\]
\(-\int ud\) 仍保非正；上界可丢，但未再作为另一账的独立信用。

沿 R495 原参数，记 \(H_0=S/\tau\)、\(C_g=512cH_0+4c+S\)、\(T_{\min}=4096cH_0\)。由
\[
 T^2\ge16cC_g(L+1)/\varepsilon_g,\quad
 A_*\le3+\varepsilon_gT/(2C_g),\quad
 e^{-\kappa}=(256cH_0/T)^8,
\]
得到显式维数无关上界
\[
 C_{\rm mix}\le
 e^{c/T_{\min}}(256cH_0)^8\frac{\varepsilon_g}{16C_g}
 \left[\frac4{T_{\min}^6}
       +\frac{\varepsilon_g}{2C_gT_{\min}^5}\right]
 =:\overline C_{\rm mix}. \tag{12}
\]
固定 \(r,S,\tau,\varepsilon_g\) 时此常数不随维数或质量窗增大。\(L=0\) 时混合误差直接为零。这是已支付的修正，不是假设 \(\Phi_{\rm loc}\) 自动上解。

## 4. 整体改进与本接口尚未支付的谱费用

令
\[
 H_{\rm loc}=\int\mu(dx)\int_{v_x(\widehat A)<K}
 \log\frac{M(x)}{m_A}\,\rho_x(d\widehat A),\quad
 H_0^{\rm head}=\int\min\{U(x),K\}\,d\mu\le KW.
\]
由(9)–(12)，不另开局部门而控制完整目标：
\[
 \boxed{I\le e^\beta[H_0^{\rm head}+\beta H_{\rm loc}]
                   +\overline C_{\rm mix}W.} \tag{13}
\]
再加已付 \(C_{\rm empty}W\) 可控制 \(R_\tau\)，最初 \(\tau X\) 及原母账仍保留。相对 R497，全局与局部谱有准确非负差
\[
 H_{\log}-H_{\rm loc}
 =\int\min\{U(x),K\}\log\frac{m_+}{M(x)}\,d\mu(x)\ge0. \tag{14}
\]
因此(13)是一个有价的整体局部化，能在实际局部最高质量远小于全局 ceiling 的来源处省掉明确费用；不宣称对每个场都有严格节省或固定比例改善。

但目前仍只有 \(0\le H_{\rm loc}\le KLW\)。其精确可计算形式是
\[
 H_{\rm loc}=\int\mu(dx)\int_{m_-}^{M(x)}
 \min\{K,\rho_x(m_A\le t)\}\,\frac{dt}{t}. \tag{15}
\]
完整根阶结论还需在原场上对(15)作全局几何压缩或联合吸收；本稿没有证明它窄谱。源混合修正已付，剩下的正局部头部谱不能再借协方差或 empty 价消去。这是本候选的明确停止点，不把局部化本身称为完整 root 付款。

式(9)中的真实负项 \(-\int ud\,d\widehat\nu\) 仍可供未来联合几何使用，并未被本轮另处扣款。特别是 \(u=b_R+K_0u\ge b_R\)，所以
\[
 \int ud\,d\widehat\nu\ge\int b_Rd\,d\widehat\nu.
\]
右边由原同父 head 与来源 CDF slack 直接计算。当前不主张它已控制正局部谱；后续也可保该信用联合结算，不限于单独压缩(15)。

## 5. 实际符号与有理核验

脚本检查 source-centered 消去的符号，以及正核停止概率配对的有限代数。有限核不认证真实中心几何或原成功历史；一般结论由上面共同参考证明。

```python
import sympy as s
from fractions import Fraction as F
p,l1,l2,E1,E2,n1,n2=s.symbols('p l1 l2 E1 E2 n1 n2')
h=p*l1+(1-p)*l2
C=p*(h-l1)*(1-E1-n1)+(1-p)*(h-l2)*(1-E2-n2)
head=p*(h-l1)*E1+(1-p)*(h-l2)*E2
emp=p*(h-l1)*n1+(1-p)*(h-l2)*n2
assert s.expand(C+head+emp)==0
checks=1
for a in [F(0),F(1,4),F(1,3),F(1,2)]:
    # K has its sole edge 0 -> 1; row failure splits into rank and empty.
    empty=[F(1,4),F(1,5)]
    b=[1-a-empty[0],1-empty[1]]
    u=[b[0]+a*b[1],b[1]]
    G=[F(1),1+a]
    phi=[F(2),F(3)]
    residual=[1-phi[0],1+a*phi[0]-phi[1]]
    I=sum(G[i]*b[i] for i in range(2))
    rhs=sum(b[i]*phi[i]+u[i]*residual[i] for i in range(2))
    assert I==rhs
    assert sum(1-v for v in u)==sum(G[i]*empty[i] for i in range(2))
    checks+=2
T,c,Cg,eps,A=s.symbols('T c Cg eps A',positive=True)
left=c*(eps*T*T/(16*c*Cg))*(4+eps*T/(2*Cg))*(A/T)**8
right=A**8*eps/(16*Cg)*(4/T**6+eps/(2*Cg*T**5))
assert s.simplify(left-right)==0
checks+=1
print(f'{checks} symbolic/Fraction assertions PASS; signed mixing and stopping algebra only.')
```

实际本机 stdout：`10 symbolic/Fraction assertions PASS; signed mixing and stopping algebra only.`。一般来源混合迁移由同参考解析证明成立，有限检查不认证完整几何/history。
