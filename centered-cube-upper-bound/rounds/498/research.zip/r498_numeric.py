from pathlib import Path
from fractions import Fraction as F
import sys,platform,json,time
import sympy as sp
import flint
from flint import arb,ctx
ROOT=Path(__file__).resolve().parent;ctx.prec=384;start=time.perf_counter();checks=0
E=sp.Symbol('E',positive=True);l3,l4,l9=sp.symbols('l3 l4 l9',real=True)

def ck(x):
 global checks
 assert x
 checks+=1

def clean(x):return sp.expand(x)
def eq(x):ck(clean(x)==0)
def ar(x):
 x=F(x);return arb(x.numerator)/x.denominator

def er(x):
 x=F(x)*72;assert x.denominator==1;return E**x.numerator

def add(*polys):
 out={}
 for p in polys:
  for k,v in p.items():out[k]=clean(out.get(k,0)+v)
 return {k:v for k,v in out.items() if v!=0}
def scale(p,a):return {k:clean(a*v) for k,v in p.items() if a*v!=0}
def mul(p,q):
 out={}
 for k,v in p.items():
  for kk,vv in q.items():out[k+kk]=clean(out.get(k+kk,0)+v*vv)
 return out

def at(p,x):return clean(sum(v*er(k*x) for k,v in p.items()))
def integ(p,a,b):return clean(sum(v*((er(k*b)-er(k*a))/sp.Rational(k.numerator,k.denominator) if k else sp.Rational((b-a).numerator,(b-a).denominator)) for k,v in p.items()))
Earb=ar(F(1,72)).exp();subarb={E:Earb,l3:arb(3).log(),l4:arb(4).log(),l9:arb(9).log()}
def ev(x):
 x=sp.sympify(x)
 if x.is_Rational:return ar(F(int(x.p),int(x.q)))
 if x in subarb:return subarb[x]
 if x.is_Add:return sum((ev(z) for z in x.args),arb(0))
 if x.is_Mul:
  y=arb(1)
  for z in x.args:y*=ev(z)
  return y
 if x.is_Pow and x.exp.is_Integer:return ev(x.base)**int(x.exp)
 raise ValueError(x)
def val(p,xx):return sum((ev(v)*(ar(k)*xx).exp() for k,v in p.items()),arb(0))
def interval(a,b):return ar((a+b)/2)+arb(0,str(ar((b-a)/2)))
def meanpoly(ps,weights):return add(*(scale(p,sp.Rational(w.numerator,w.denominator)) for p,w in zip(ps,weights)))
# Centering and explicit cost-algebra identities, independent of finite models.
p,x,y,EX,EY,nX,nY=sp.symbols('p x y EX EY nX nY')
h=p*x+(1-p)*y
C=p*(h-x)*(1-EX-nX)+(1-p)*(h-y)*(1-EY-nY)
eq(C+p*(h-x)*EX+(1-p)*(h-y)*EY+p*(h-x)*nX+(1-p)*(h-y)*nY)
T,c,Cg,eps,aa=sp.symbols('T c Cg eps aa',positive=True)
eq(c*(eps*T*T/(16*c*Cg))*(4+eps*T/(2*Cg))*(aa/T)**8-aa**8*eps/(16*Cg)*(4/T**6+eps/(2*Cg*T**5)))
mu=[F(3),F(1),F(8)];capture=[[1,0,0],[1,1,0],[0,1,1]];mass=[F(3),F(4),F(9)];logs=[l3,l4,l9];ell=[l4,l9,l9];nu=mass;W=sum(mu)
pi=[[mu[x]*capture[a][x]/mass[a] for x in range(3)] for a in range(3)]
hh=[sum(sp.Rational(w.numerator,w.denominator)*ell[x] for x,w in enumerate(pi[a])) for a in range(3)]
prefix=[[sum(capture[b][x] for b in range(a)) for x in range(3)] for a in range(3)]
for x in range(3):
 for a in range(3):ck(sum(nu[b]*capture[b][x] for b in range(a+1))<=2*mass[a])
models=[]
for label,tt,kk in [('initial',F(1),F(1,2)),('atom_boundary',F(1),F(1)),('expanded_threshold',F(1,2),F(3,2))]:
 beta=F(2)/tt;eb=er(beta)
 psi=[[eb*(1+sp.Rational(beta.numerator,beta.denominator)*(ell[x]-logs[a])) for x in range(3)] for a in range(3)]
 breaks=[];pieces=[];yend=[]
 for a in range(3):
  bp=sorted({F(0),F(1)}|{kk-prefix[a][x] for x in range(3) if capture[a][x] and 0<kk-prefix[a][x]<1});breaks.append(bp)
  yn=sp.Integer(0);out=[]
  for lo,hi in zip(bp,bp[1:]):
   mid=(lo+hi)/2;active=[capture[a][x] and prefix[a][x]+mid>=kk for x in range(3)]
   b=1-sum(pi[a][x] for x in range(3) if active[x]);D=sp.Integer(0)
   for x in range(3):
    if active[x]:D+=sp.Rational(pi[a][x].numerator,pi[a][x].denominator)*sum(er(-F(prefix[a][x]-prefix[j][x]-1)/tt)*yend[j] for j in range(a) if capture[j][x])
   D=clean(D)
   if b==1:yp={F(0):sp.Integer(1),-1/tt:clean((yn-1)*er(lo/tt))}
   else:
    bb=sp.Rational(b.numerator,b.denominator)
    yp=add({F(0):sp.Integer(1)},{-b/tt:clean((yn-1-D/(bb-1)*er(-lo/tt))*er(b*lo/tt))},{-1/tt:clean(D/(bb-1))})
   up=add({F(0):sp.Rational(b.numerator,b.denominator)},scale(yp,1-sp.Rational(b.numerator,b.denominator)),{-1/tt:D})
   # Exact ODE and Volterra absorption equation on the whole interval.
   deriv={k:sp.Rational(k.numerator,k.denominator)*v for k,v in yp.items()}
   eq(at(yp,lo)-yn)
   for v in add(scale(deriv,sp.Rational(tt.numerator,tt.denominator)),yp,scale(up,-1)).values():eq(v)
   out.append((lo,hi,yp,up));yn=at(yp,hi)
  pieces.append(out);yend.append(yn)
 # Ancestor V for parent-constant source functions; exact exponential polynomials.
 def ancestor(a,x,field,sample):
  out={}
  threshold=kk-prefix[a][x]
  if threshold<1:
   if sample<threshold:
    out=add(out,{1/tt:clean(field[a][x]*(er(-threshold/tt)-er(-1/tt)))})
   else:out=add(out,{F(0):field[a][x],1/tt:-field[a][x]*er(-1/tt)})
  for j in range(a+1,3):
   if not capture[j][x]:continue
   low=max(F(0),kk-prefix[j][x])
   if low<1:out=add(out,{1/tt:clean(field[j][x]*er(F(prefix[a][x]-prefix[j][x])/tt)*(er(-low/tt)-er(-1/tt)))})
  return out
 field=[[hh[a]-ell[x] for x in range(3)] for a in range(3)]
 Ctotal=Chead=Cemp=Cweighted=Cemptyweighted=Ud=I=sourcehead=parenthead=empty=sp.Integer(0)
 for a in range(3):
  eq(sum(sp.Rational(pi[a][x].numerator,pi[a][x].denominator)*(hh[a]-ell[x]) for x in range(3)))
  for lo,hi,yp,up in pieces[a]:
   mid=(lo+hi)/2;active=[capture[a][x] and prefix[a][x]+mid>=kk for x in range(3)]
   Cpoly=meanpoly([ancestor(a,x,field,mid) for x in range(3)],pi[a])
   dpoly=meanpoly([add({F(0):psi[a][x]-1},scale(ancestor(a,x,psi,mid),-1)) for x in range(3)],pi[a])
   bR=1-sum(pi[a][x] for x in range(3) if active[x])
   nnpoly={}
   for x in range(3):
    w=sp.Rational(pi[a][x].numerator,pi[a][x].denominator)
    if not w:continue
    if not active[x]:
     Chead+=mass[a]*w*(hh[a]-ell[x])*sp.Rational((hi-lo).numerator,(hi-lo).denominator)
     sourcehead+=mass[a]*w*psi[a][x]*sp.Rational((hi-lo).numerator,(hi-lo).denominator)
    else:
     npoly={-1/tt:er(-F(prefix[a][x])/tt)}
     Cemp+=mass[a]*w*(hh[a]-ell[x])*integ(npoly,lo,hi)
     nnpoly=add(nnpoly,scale(npoly,w))
   Ctotal+=mass[a]*integ(Cpoly,lo,hi)
   Cweighted+=mass[a]*integ(mul(up,Cpoly),lo,hi)
   Cemptyweighted+=mass[a]*integ(mul(add({F(0):sp.Integer(1)},scale(up,-1)),Cpoly),lo,hi)
   Ud+=mass[a]*integ(mul(up,dpoly),lo,hi)
   I+=mass[a]*integ(up,lo,hi)
   empty+=mass[a]*integ(add({F(0):sp.Integer(1)},scale(up,-1)),lo,hi)
   parenthead+=mass[a]*bR*sum(sp.Rational(pi[a][x].numerator,pi[a][x].denominator)*psi[a][x] for x in range(3))*sp.Rational((hi-lo).numerator,(hi-lo).denominator)
   # Interval certificate of d>=0 (the identified u is the unique Volterra absorption solution).
   for k in range(4):
    left=lo+(hi-lo)*F(k,4);right=lo+(hi-lo)*F(k+1,4)
    vv=val(dpoly,interval(left,right));ck(vv.is_finite());ck(vv>0)
 eq(Ctotal+Chead+Cemp);eq(Cweighted+Cemptyweighted-Ctotal)
 eq(parenthead-sourcehead-eb*sp.Rational(beta.numerator,beta.denominator)*Chead)
 eq(I-sourcehead+eb*sp.Rational(beta.numerator,beta.denominator)*(Cemp+Cemptyweighted)+Ud)
 # Source-centering remains zero with u(A,s) at that SAME parent, not u(B).
 for a in range(3):eq(hh[a]-sum(sp.Rational(pi[a][x].numerator,pi[a][x].denominator)*ell[x] for x in range(3)))
 quantities=dict(I=I,empty=empty,source_head=sourcehead,parent_head=parenthead,C_total=Ctotal,C_head=Chead,C_emp=Cemp,uC=Cweighted,one_minus_u_C=Cemptyweighted,u_d=Ud)
 values={name:str(ev(clean(value))) for name,value in quantities.items()}
 for name,value in quantities.items():ck(ev(clean(value)).is_finite())
 ck(ev(I)>0);ck(ev(empty)>0);ck(ev(Ud)>0)
 ck(abs(ev(Cemp))<arb(3).log()*ar(tt)*ar(-kk/tt).exp()*ar(W))
 ck(abs(ev(Cemptyweighted))<arb(3).log()*ev(empty))
 models.append(dict(label=label,T=str(tt),K=str(kk),c='2',beta=str(beta),continuous_mark='s in[0,1],rho_parent=1; exact piecewise exponential Volterra solution',mark_breakpoints=[[str(z) for z in v] for v in breaks],convolution_y_endpoint_values=[str(ev(z)) for z in yend],quantities=values,signed_residual='exact0 in Laurent polynomial E=exp(1/72) and symbolic log3/log4/log9',centered_same_parent_u_term='exact0; this does not set u(B)*C(B) to zero'))
# R495 actual parameter choices, independent of the small scalar models above.
params=[]
for profile,(r,S,tau,ep) in enumerate([(1,1,F(1),F(1,4)),(3,1,F(1,4),F(1,16)),(1,2,F(2),F(1,16)),(3,2,F(1,2),F(1,4))]):
 cc=F(r*S);HH=F(S)/tau;cg=512*cc*HH+4*cc+S;tmin=4096*cc*HH
 bar=ar(cc/tmin).exp()*ar((256*cc*HH)**8*ep/(16*cg)*(4/tmin**6+ep/(2*cg*tmin**5)))
 for dim in (0,2,256,10**12):
  LL=arb(0) if dim==0 else ar(r).log()+dim*arb(2).log()
  root=(ar(16*cc*cg/ep)*(LL+1)).sqrt().ceil().unique_fmpz();ck(root is not None)
  tv=max(int(tmin),(6*cg/ep).__ceil__(),int(root))
  ck(ar(tv*tv)>=ar(16*cc*cg/ep)*(LL+1));ck(tv>=tmin)
  kap=8*ar(F(tv)/(256*cc*HH)).log();beta=ar(cc/tv);Astar=3+8*ar(cc)*LL/tv
  mix=beta.exp()*ar(cc)*LL*(1+Astar)*(-kap).exp()
  ck(mix.is_finite());ck(bar.is_finite());ck(mix<=bar)
  if dim==0:ck(mix==0)
  params.append(dict(profile=profile,L='0' if dim==0 else str(LL),n=None if dim==0 else dim,P=str(cc),H0=str(HH),eps=str(ep),T=tv,kappa=str(kap),Astar=str(Astar),Cmix=str(mix),Cbar=str(bar)))
result=dict(scope='Finite atomic-source/finite-parent incidence with continuous uniform mark plus separate actual R495 parameter arithmetic. Not native receiver/history geometry.',compute_index=dict(executable=sys.executable,python=platform.python_version(),sympy=sp.__version__,python_flint=flint.__version__,arb_precision_bits=ctx.prec,command='"'+sys.executable+'" r498_numeric.py',seconds=time.perf_counter()-start),checks=checks,continuous_mark_models=3,parameter_cases=16,source_input=dict(positions=['0','2/5','1'],weights=['3','1','8'],parent_intervals=[['-1/5','1/5'],['-1/5','3/5'],['1/5','6/5']],capture=capture,mass=list(map(str,mass)),nu='nu_parent=mass, finite atomic parent measure',ell=['log4','log9','log9'],h=list(map(str,hh))),formulas=dict(signed='I=source_head-exp(beta)*beta*Cemp-exp(beta)*beta*integral(1-u)C-integral u*d',unweighted='integral C=-Chead-Cemp=integral (ell-h)(1-a)',weighted='u is true forward raw rank absorption probability; only the same-parent source-centered term is zero. u(B) cannot be moved to ancestorA.',constant='Cmix=exp(beta)cL(1+Astar)exp(-kappa)<=Cbar; Cbar formula from r498_proof eq12'),models=models,parameters=params,decision='Full signed formula and its small empty-weighted correction pass exact continuous-mark tests. The parent/source-centered zero term does not erase weighted uC. Actual R495 parameter arithmetic pays the dimension-independent mixing correction, leaving local head spectrum unpriced.',errors='Identities exact in Laurent polynomial exp(1/72) and symbolic logs; values384-bit Arb. d>=0 certified by interval subdivisions; u identified by exact Volterra ODE/boundary solution and strict row-contraction. No discrete mark approximation, truncation or random scan.')
(ROOT/'r498_numeric.json').write_text(json.dumps(result,indent=2)+'\n')
print('PASS',checks,'exact/Arb assertions;3 continuous-mark signed models,16 R495 parameter cases;no original geometry claim')
