# 第498轮：完整父势的来源局部化与有符号混合费用结算

## 研究目标与本轮变化

沿已推送第497轮873e7b639f69f411eb86928ec96559db51802848，继续一般中心立方体极大算子根阶一致弱型上界；任意非负L1来源、真实勒贝格接收测度和全部原入口费用均保留。此次不再优化deep常数，也不扩大无目的反例扫描。新结果是在同一个完整raw停止积分上支付来源局部化引起的全部混合修正，尚未证明完整根阶预算。

采用64项数学工具中E03的有限层望远镜、到达测度和终端纪律；没有引用其外部树Bellman定理或常数。实际本机数学验证只作为代数与数值证据。

## 冻结原积分与完整费用

令μ=f dx，W=||f||1，q≤q_A≤λ，r=λ/q，a≤R_A≤b≤2a，m_A=μ(Q_A)=q_AR_A^n。原截断ντ=t q_A dA|t≥τ，0<τ≤S、t≤S，只截断一次，不归一化。连续mark与质量共同给出全序。沿R495–497，ρ_x(dÂ)=1_QA(x)ντ(dA)ds/m_A，v_x为其前缀rank，U(x)=ρ_x(全域)，K=κT、c=rS、β=c/T、L=log(m+/m−)。

K0是同一max-only正支配父核，G=Σ(K0*)^j1；b_R(B)=π_B{v_x(B)<K}。完整量I=∫b_RG dνhat满足Rτ=I+Eempty，Eempty≤Cempty W。原成功链只由raw支配，不声称两链同律。所有真实父标记、尺度、完整质量与来源分母保留。

本轮关键是定义M(x)=ρ_x意义下捕获父质量的ess sup，零行取m−，而不是将原selector按来源重选。定义ell(x)=log M(x)、h(A)=π_A ell，以及
\[
\psi_x(A)=e^\beta[1+\beta\log(M(x)/m_A)],\qquad
\Phi_{\rm loc}(A)=\pi_A\psi_x(A).
\]
每来源的闭质量窗保证source上解缺陷d_x=ψ_x−1−V_xψ_x≥0；父平均却有实际signed修正C，不能直接称Φloc为父上解。

## 有符号费用为何可以支付

令u=ΣK0^j b_R，是raw最终rank停止概率，0≤u≤1。其补集1−u是raw最终empty概率，积分已付为Eempty。完整精确账为
\[
I=H_{\rm source}-e^\beta\beta C_{\rm emp}
-e^\beta\beta\int(1-u)C\,d\widehat\nu-\int u d\,d\widehat\nu.
\]
其中Hsource=∫νhat π_A 1_{v<K} ψ_x。Cemp只带同源高rank空样本权1_{v≥K}exp(−v/T)，d=π_B d_x≥0；所有定义和推导在proof中完整列出。这个抵消使用每父π_A(h−ell)=0及真实核行质量。若先取C正部，头部抵消将丢失；本轮不采用该放缩。

由|C|≤L、一次empty≤Texp(−κ)W、累计empty≤DTexp(−κ)W，D=3+8cL/T，全部混合误差≤exp(β)cL(1+D)exp(−κ)W。原选参T²≥16cCg(L+1)/εg、T≥Tmin=4096cH0、κ=8log[T/(256cH0)]、H0=S/τ给出维数无关参数常数
\[
\overline C_{\rm mix}=e^{c/T_{\min}}(256cH_0)^8
\frac{\varepsilon_g}{16C_g}
\left(4/T_{\min}^{6}+\varepsilon_g/(2C_gT_{\min}^{5})\right),
\quad C_g=512cH_0+4c+S.
\]
这里不从u≤1直接删掉signed权，也不把empty乘expκ后仍说小。有限层终端及所有signed积分由有限总参考、 bounded势与已证几何终端帽控制。

## 对完整目标的实际改进及剩余缺口

定义真实局部谱
\[
H_{\rm loc}=\int\mu(dx)\int_{v_x(A)<K}\log\frac{M(x)}{m_A}\rho_x(d\widehat A).
\]
于是整个原截断量有界于
\[
R_\tau\le e^\beta(KW+\beta H_{\rm loc})
 +(\overline C_{\rm mix}+C_{\rm empty})W.
\]
相对旧全局谱，节省准确为
\[
H_{\log}-H_{\rm loc}
=\int\min(U(x),K)\log\frac{m_+}{M(x)}\,d\mu(x)\ge0.
\]
这不保证每个场都严格节省，亦未证明Hloc根阶价。来源重置补偿已经支付；此接口中正的局部头部谱仍可能只有KLW粗价。下一步必须利用真实中心几何压缩同一Hloc，或保留精确账中的负信用−∫u d与头部联合结算。u≥b_R可给出一个同父双来源的可计算信用下界，但本轮未证明其足够付款；不能把局部化当作全局闭合。

原母账仍保τX、所有原非rank累计费、初始、删除跳跃、未来被删来源、宽距离、低强度、极端比例及全尺度拼接。入口倍率64(128/119)/(1−32δ_old−16η_old)照旧，所有ε按完整总账分配。其他备选几何分解不能与本谱接口重复抵扣。

## 验证与归档约定

本轮主证明、独立命题预审、实际数值证书和几何探索分别附后。有限核仅验证signed恒等式与停止代数；不能认证真实连续中心困难流。解析参数界与浮点或区间检查分开标记，以最终独审绑定与实际重放记录为准。只归档必要文本、详细LaTeX与复现，不编译PDF；每轮单独提交推送，不将未完成的根阶结论写成已证。

实际隔离重放通过：proof 10项符号/有理断言，geometry 1项符号恒等式与6个有理接口例，numeric 312项exact/Arb断言，共329项报告核验单位，非329个独立模型。numeric保3个连续mark有限模型及16个R495参数例（4组参数，L=0与n=2,256,10^12），精确恒等式在Laurent指数/对数形式环为零，区间核Arb384bits。Python3.12.14、SymPy1.14.0、python-flint0.9.0，实际解释器及重放stdout见r498_replay.json。只有compute_index.seconds作为动态字段排除；规范JSON SHA256为79fd47b7553c84186585aff07950866feebe1832e7ec4f69b9f95a2341dfae75。有限模型不是L1/Lebesgue真实困难流，R495参数检查与该模型分开，未把模型的标量T当原选参。
