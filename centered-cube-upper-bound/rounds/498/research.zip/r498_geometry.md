# R498 几何附件：同一祖先对的外部来源匹配

本附件只证明一个同对来源子测度的精确输运。它消除直接换来源时表面的质量比损失，但没有跨祖先累计的根阶费用；不得与主稿的 source-local ceiling 收据叠加抵扣。原完整目标仍未由本附件闭合。

## 1. 唯一候选与实际测度

沿 R497：
\(\mu=f\,dx\)、\(m_A=\mu(Q_A)>0\)、\(\pi_A=\mu|_{Q_A}/m_A\)，
\(\widehat\nu=\nu_\tau\otimes ds\)。连续 mark 定义全序
\(\widehat B\prec\widehat A\)，因此 \(m_B\le m_A\)，相等质量也允许。
\(\rho_x(d\widehat B)=c_B(x)\widehat\nu(d\widehat B)/m_B\)，
\(v_x\) 是该同一真实来源测度的严格前缀秩，\(K=\kappa T\)，
\(G=\sum_j(K_0^*)^j1\)。

令 \(h_B(z)=1_{\{v_z(\widehat B)<K\}}\)，并令
\(\chi_\partial(A,x)=1_{\{2\|A-x\|_\infty>\zeta R_A\}}\)。定义实际正测度
\[
 d\mathcal W=
 \widehat\nu(d\widehat A)G(A)\pi_A(dx)
 \chi_\partial(A,x)1_{\{v_x(\widehat A)\ge K\}}
 \frac{1_{\{\widehat B\prec\widehat A\}}}{T}
 e^{-[v_x(\widehat A)-v_x(\widehat B)]/T}
 \rho_x(d\widehat B).
 \tag{1}
\]
这里保留真实中心、原截断权 \(t\)、mark、void、边界条件及累计权 \(G\)。没有重新选择半径或来源后验。R497 的完整 boundary 祖先量准确为
\[
 I_{\rm anc,\partial}=\int d\mathcal W\int\pi_B(dz)h_B(z).
 \tag{2}
\]
其核换序仅使用
\(m_A^{-1}\pi_B(dx)c_A(x)=m_B^{-1}\pi_A(dx)c_B(x)\)。
原成功历史已在既有 \(K_0\) 正支配步骤中处理；本附件不声称 \(K_0\) 与原成功链同 law。

## 2. 外部来源的精确常数 1 输运

固定同一 \((\widehat A,\widehat B)\)，记
\[
 I=\mu(Q_A\cap Q_B),\qquad
 H=\mu((Q_B\setminus Q_A)\cap\{h_B=1\}).
\]
于是 \(0\le H\le m_B-I\le m_A-I\)。若 \(m_A-I>0\)，置
\[
 d_{AB}=\frac{m_AH}{m_B(m_A-I)}.
\]
则同质量的两个子测度为
\[
 \pi_B(dz)h_B(z)1_{Q_A^c}(z)
 \quad\longrightarrow\quad
 d_{AB}\pi_A(dw)1_{Q_B^c}(w),
 \qquad 0\le d_{AB}\le1.
 \tag{3}
\]
证明：两侧总质量均为 \(H/m_B\)，且完整缺陷准确是
\[
 1-d_{AB}
 =\frac{m_A(m_B-I-H)}{m_B(m_A-I)}
  +\frac{I(m_A-m_B)}{m_B(m_A-I)}\ge0.
 \tag{4}
\]
若 \(m_A-I=0\)，质量次序迫使 \(m_A=m_B=I\)、\(H=0\)，两侧均取零；若仅 \(H=0\)，也取零。故没有除零端点问题。

式 (3) 可实现为联合测度：在 \(H>0\) 时，将原左侧 \(z\) 子测度与概率
\(\mu|_{Q_A\setminus Q_B}/(m_A-I)\) 相乘。这样保留原 \(z\) 及全部已有条件标签；新 \(w\) 只是人工分析来源，不获低秩、旧来源历史或成功资格。它不是把原记录的 \(z\) 擅自换成 \(w\)。

因而 (2) 中 \(z\notin Q_A\) 的真实正部分有精确式
\[
 I_{\rm out}=\int d\mathcal W
       \int\pi_A(dw)d_{AB}1_{Q_B^c}(w).
 \tag{5}
\]
这比直接以 \(m_A/m_B\) 外放强：质量比与真实外部来源质量共同抵消。证明只用完整 \(\mu(Q)\) 匹配；没有来源密度帽、薄层来源估计或新父历史。

## 3. 尚缺的联合结算，不能把 (5) 当付款

把 (4) 的非负缺陷删掉，并将 \(1_{Q_B^c}(w)\) 删掉后，原 raw maximum 行质量不超过 1。因此本路线目前仅给
\[
 I_{\rm out}\le\int G(A)\,\widehat\nu(d\widehat A).
 \tag{6}
\]
右侧是累计父占用，尚无所需根阶来源价；不能用一次 \(\int\nu\) 替代它。式 (4) 的缺陷亦不能单独扣原费用：还要与 (2) 中
\(z\in Q_A\cap Q_B\) 的正部分在同一累计测度下共同结算。

具体地，删去 inside 的 head、boundary、rank 和 void 仅能得到
\[
 I_{\rm in}\le\frac1T\int_{\widehat B\prec\widehat A}
 G(A)\frac{I_{AB}^{2}}{m_A m_B^2}
 \,\widehat\nu(d\widehat A)\widehat\nu(d\widehat B).
 \tag{7}
\]
这不是可直接调用对称 overlap-Schur 的分母；与
\(I_{AB}^2/(m_A m_B)^{3/2}\) 相比多出
\(\sqrt{m_A/m_B}\)，且 \(G\) 仍在。故本轮唯一未证步骤是：在保 (1) 的真实 void/rank 权时，用 (4) 的 overlap 缺陷与 inside 低秩来源项共同控制累计费用，而非分别正外放成 (6)、(7)。目前没有这样的有价比较。

主稿的 source-local ceiling 为
\(M(x)=\operatorname*{ess\,sup}_{A:c_A(x)=1}m_A\)。本输运的新 \(w\in Q_A\) 只保证 \(M(w)\ge m_A\)，没有保 \(z\) 的 head 秩或比较 \(M(w)\) 与 \(M(z)\)。因此不能声称式 (3) 已控制主稿剩余的 local logarithmic head spectrum，也不能将其非负缺陷与主稿 signed mixing 收据重复使用。这个明确的限制决定：下一步必须证明同权的 signed overlap/head 比较，而不是继续优化外部输运常数。

## 4. 实际本机核验及范围

以下代码已在指定 Python 环境实际运行；输出为一项符号恒等式 PASS、六个精确质量接口例 PASS。它核 (3)–(4) 的归一、符号及零外部端点，不是 native cube/history 实例，不证明全局费用。

```python
import sympy as s
from fractions import Fraction as F
A,B,I,H=s.symbols('A B I H', positive=True)
d=A*H/(B*(A-I))
rhs=A*(B-I-H)/(B*(A-I))+I*(A-B)/(B*(A-I))
assert s.simplify(1-d-rhs)==0
print('symbolic density deficit: PASS')
n=0
for a,b,i,h in [(5,3,1,2),(3,3,1,2),(5,3,0,3),
                (5,3,3,0),(5,3,1,1),(3,3,3,0)]:
    a,b,i,h=map(F,(a,b,i,h))
    if a==i:
        assert h==0
        d=F(0)
    else:
        d=a*h/(b*(a-i))
        assert F(0)<=d<=1
        assert d*(a-i)/a==h/b
    n+=1
print(f'exact mass-interface cases (including zero exterior): {n} PASS')
```

结论：同对外部来源匹配有严格常数 1，并保原标签的联合表示；未取得新的跨父整体付款。本附件到此停止，不另立新余项。
