# R498：连续 mark 的 signed mixing 完整账

完成 312 项 exact/Arb 断言：3 个固定连续 uniform-mark 模型、16 个 R495 参数检查。未重复 deep 实验。结论是完整 signed 恒等式与来源混合误差的参数付款相容；剩余局部 head 谱未付，原几何/history 不认证。

## 有限模型与连续 mark

来源点为 0、2/5、1，质量 (3,1,8)。有限父区间依次 [−1/5,1/5]、[−1/5,3/5]、[1/5,6/5]，完整捕获集合为 {0}、{0,1}、{1,2}，质量 (3,4,9)。ν_parent=m_parent，来源律为完整 π，故各父的 rank 质量为 1，使用连续 mark s∈[0,1]，没有离散 mark 近似。

来源实际 ceiling 为 (4,9,9)，ell=(log4,log9,log9)。h=(log4,(3log4+log9)/4,log9)。中间父同时具有不同 ceiling 和不同来源 rank prefix，使 C 真正非零。对各来源全部质量阈值，脚本核有限中心质量 CDF≤2m，因此取 c=2。

三个阶段只取 (T,K)=(1,1/2)、(1,1)、(1/2,3/2)。第二例恰落完整 rank 原子段端点；第三例的阈值穿过更高 prefix。它们的 T 是 scalar probe，不满足 R495 的巨大 T 选择；R495 参数另行检查。有限原子来源、有限父测度不是 L1/Lebesgue receiver，也没有原 octave、success/history 资格。

## 真正的 rank 吸收概率 u

按实际质量 3<4<9 排序。设 v_x(A,s)=prefix_x(A)+s，prefix 为捕获该来源的低质量父数。u_A(s) 由前向 raw rank 停止方程 u=b_R+K0u 定义；不是任取的权，也不把 u(B) 移到祖先 A。

引入 y_A(s)=∫_0^s exp(−(s−t)/T)u_A(t)dt/T。rank 阈值将 mark 分成有限有理区间，每段有

u_A=b+(1−b)y_A+D exp(−s/T)，Ty_A'=u_A−y_A，y_A(0)=0，

其中 b 是该段实际 π_A 下 inactive-source 概率，D 由低质量父 y_B(1) 及真实捕获 prefix 算出。脚本用精确 exponential polynomial 解，逐段核 ODE 与连续初值。这与 Volterra 方程等价；raw 行质量≤1−exp(−2/T)<1，故该唯一解就是最终 rank 吸收概率，1−u 是 empty 吸收概率。

指数常数以形式 E=exp(1/72) 的 Laurent polynomial 表示；三个 log 先作独立符号。所有恒等式在该形式环中精确为零，而不是浮点残差含零。数值显示用 384-bit Arb。

## 两个积分方向、中心化与完整 signed 式

定义 ψ_x(A)=expβ[1+β(ell_x−log m_A)]、β=c/T，Φ_loc=π_Aψ_x。按作者定义计算 C(B)=π_BV_x[h(A)−ell_x]，d=π_B[ψ_x−1−V_xψ_x]。

代码直接按接收父 B 积祖先 V，计算 C、uC、(1−u)C；另一方向按输入父 A 计算 head 与 empty。精确核

∫Cν=−C_head−C_emp=∫ν_Aπ_A(ell−h)(1−a)，

a=1_(v≥K)(1−exp(−v/T))。

中心化只给同父 π_A(h−ell)=0；乘同一个 u(A,s) 后仍为零。它不意味着 ∫u(B)C(B)ν_B=0，也不允许跨父搬 u。

再核父头部与真正来源头部之差 expβ β C_head，最后完整相消为

I=head_source−expβ β C_emp−expβ β∫(1−u)Cν−∫udν。

d 的每段用四个覆盖区间 Arb 包围，严格证 d>0；∫ud>0，负项按原式保留，没有另当独立信用。

便读结果如下，严格值见 JSON：

| 阶段 | I=∫uν | C_emp | ∫uCν | ∫(1−u)Cν | ∫udν |
|---|---:|---:|---:|---:|---:|
| 初探 | 10.01199121 | −.00371430 | .18782665 | .11998648 | 44.97316783 |
| 原子端点 | 14.67963502 | .14143281 | .41023019 | .05653466 | 95.80166418 |
| 扩大阈值 | 15.91493783 | .00957042 | .29070284 | .00382557 | 1111.11764299 |

各例自然总 R=16，empty=16−I。C_emp 确实换符号；若先取 C_+ 或把来源均值误当逐点值，会丢掉已核的 head 抵消。三个例还严格区间核 |C_emp|<L T exp(−K/T)W 和 |∫(1−u)C|<L E_empty，其中 L=log3。

## 新 signed 误差的 R495 实际选参

另取 R497 的四个代表 (r,S,τ,eps) profile；每个仅测 L=0 以及 L=log r+nlog2、n=2,256,10^12，共16例。L=0 是零窗边界参数检查，不称由对应几何构造。此部分没有重算 deep 几何。

c=rS、H0=S/τ、Cg=512cH0+4c+S，T 按原 max 选择上取整；κ=8log[T/(256cH0)]，A*=3+8cL/T。逐项核

Cmix=exp(c/T)cL(1+A*)exp(−κ)≤Cbar，

其中 Tmin=4096cH0，

Cbar=exp(c/Tmin)(256cH0)^8 eps/(16Cg)
×[4/Tmin^6+eps/(2Cg Tmin^5)]。

SymPy 实际核将 L≤eps T²/(16cCg)、1+A*≤4+eps T/(2Cg) 代入后的幂次拆分。对实际选参，Arb 核 Cmix≤Cbar，包括大 n；L=0 时 Cmix 精确为零。

四 profile 的 Cbar 约为 5.89284×10^(−7)、1.51661×10^(−6)、2.50788×10^(−7)、1.42698×10^(−5)，均保参数依赖，不把它们称作所有参数的绝对常数。维数无关上界来自显式解析式，不从16点猜得。

因此此 signed 来源修正有明确维数无关 W 价；真正局部 head_source（含局部头部 log-mass 谱）仍是另一个未付目标。有限模型不证明原成功流或最终 root 预算。

## 复现与可重放口径

`/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/r498_numeric.py`

实际 Python3.12.14、SymPy1.14.0、python-flint0.9.0、Arb384 bits。输入自含，输出写脚本目录。固定 stdout：

`PASS 312 exact/Arb assertions;3 continuous-mark signed models,16 R495 parameter cases;no original geometry claim`

JSON 唯一动态字段为 `compute_index.seconds`；隔离重放比较时只删除该字段，其余字典字段应一致。断言数含区间/有限性/符号身份，不是独立模型数。无随机扫描、Monte Carlo、指数积分截断或浮点容差证明。

白名单仅 `/tmp/r498_numeric.py`、`/tmp/r498_numeric.json`、`/tmp/r498_numeric.md`。完成限定任务后停止。
