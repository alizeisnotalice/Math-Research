# R498 独立终审

FINAL PASS（限定范围）。整个 max-only rank 积分的 source-local ceiling 迁移成立，全部 signed 来源混合补偿已付明确、维数无关的参数依赖 W 价。这超出只列条件修正项的接口；但局部 head 质量谱及其与负 slack 的联合根阶预算仍未证，完整一般目标与原母账未闭合。

独立 PRE 先核局部拆分、实际核修正和 signed resolvent；作者随后提供的新头部抵消及 empty 加权付款已另行独立审查。最终已审白名单七件，未发现必要修补项。

1. **局部量与真实参考。** M(x) 由同一 ρ_x 的有理阈值尾定义，可测、有界；零行取 m_-，joint 几乎处处 M(x)≥m_A。原 f、质量、候选中心和 mark 未重选。逐来源 R497 闭窗证明给 d_x=ψ_x−1−V_xψ_x≥0；父平均 Φ_loc 本身不被误称为上解。C 仍保实际祖先 rank 门、void、mark 次序和全部分母，signed 项没有随正主项删门。
2. **有价 signed 迁移。** 核验精确残差 K₀*Φ_loc=Φ_loc−1−d+exp(β)βC，以及 0≤u=ΣK₀^j b_R≤1。终端消失使 1−u 真为 raw empty 吸收概率；有界势、有限参考和 |C|≤L 保证所有 signed 交换绝对可积。按真实输出最大点先积分得 ∫C=−C_head−C_emp，父 head 与来源 head 的差为 exp(β)βC_head。因此整个 I 精确等于 source_head−exp(β)βC_emp−exp(β)β∫(1−u)C−∫ud。该符号与费用正确；不是先取 C_+、删负权或把 u(B) 移到祖先 A。
3. **混合误差常数。** |C_emp|≤LTexp(−κ)W、|∫(1−u)C|≤LA_*Texp(−κ)W。用原 T² 下界、T_min、κ 与 A_* 的关系，严格得到 proof(12) 的 T_min^(−6)、T_min^(−5) 两项及系数。固定 r,S,τ,ε_g 时 Cbar_mix 与维数、L 无关；L=0 的实际误差为零。此处不需要额外 T 上界。负项 −∫ud 保留，未在别账重复收费。
4. **整个目标与未付谱。** R_τ≤exp(β)(KW+βH_loc)+(Cbar_mix+C_empty)W 保整个原截断量；H_log−H_loc 的非负差公式及局部质量 prefix layer-cake 成立。并不保证每个场严格省量；当前 H_loc≤KLW 仍粗。若未来使用 u≥b_R 的 slack 下界，须与同一谱联合结算，不能把本轮混合价再用来删除正谱。
5. **几何附件。** 同对外部来源的 d_AB≤1、退化端点、质量缺陷与保原 z 的 product coupling 准确。W 换序保 π_A、ρ_x 和实际 G；inside 粗核 I_AB²/(m_A m_B²) 的额外质量比未抹去。新人工 w 不获原 rank/history，未认证跨祖先累计付款，亦不与主收据叠加抵扣。

**独立实际复现。** 指定 Python `-I`：proof 10项符号/Fraction 已在其最终未改版本隔离通过；最后仅新增重放 geometry 1项符号+6接口及 numeric 312项 exact/Arb。共329项报告核验单位，stdout 与冻结 replay 一致。numeric JSON 只去 compute_index.seconds 后逐字段一致，规范 SHA256 为 `79fd47b7553c84186585aff07950866feebe1832e7ec4f69b9f95a2341dfae75`。连续 mark 的3个有限原子来源/有限父模型以精确指数多项式验证账，16个 R495 参数例另核常数；Arb384位严格包围。它们不认证 L¹/Lebesgue 真实困难流、原成功历史或一般阶数。

原一次 τX、R495非 rank 收据、R496 empty、入口倍率及全尺度等未付槽仍保留。一般根阶结论未闭合；本报告仅认证此次完整局部化及其已付混合修正。

## 最终输入绑定

- `r498_main.md`: `fbcdb52e56b79b6109108ef9b4dfea1b635feb162a6103ba95e021a817633d24`
- `r498_geometry.md`: `28b3bda8f75e1edc6cd63728248e621527ca8878969ec59cdb7de9c739082db4`
- `r498_proof.md`: `50b5bef1701f37565ca3c6d56db7627124479e001e379aeec1f03e038f4fdfe1`
- `r498_numeric.md`: `e956e3329e542a5d82c7e7418410a707d41dd3fb539168c608cd14a2ce7bcc1a`
- `r498_numeric.py`: `4cc9353064697e4eb97c0825c552c293e4794a4eb5c9d0ebf53f88c7a5dd9421`
- `r498_numeric.json`: `da73b5f6fca4014cdc6f1b57962ae4ca9847fd3de6d482fb55243ccd2c5ad03e`
- `r498_replay.json`: `d0bfbbf7d7407b9045f68bc091f232e3650696bc35a216424e91cb64098bb1f4`
