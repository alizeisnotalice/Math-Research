#!/usr/bin/env python3
"""R683 simultaneous normalized-root projection and true sign-count experiment."""
def append_degree_certificate():
    from pathlib import Path
    from fractions import Fraction
    import hashlib,json,sys,time
    import sympy as sym
    import flint
    from flint import arb,ctx
    tick=time.time();ctx.prec=256
    root=Path(__file__).resolve().parent
    dst=root/'RESULT.json';old=json.loads(dst.read_text())
    assert old['summary']['fixture_count']==14 and old['summary']['projection_pattern_count']==1644
    fixture_hash=hashlib.sha256(json.dumps(old['fixtures'],sort_keys=True).encode()).hexdigest()
    def lg2(x):return arb(x).log()/arb(2).log()
    ns=sorted(set([65536,65537,10**6,10**8]+[2**L for L in (16,17,20,24,32,64,128,256,512,1024)]))
    checks=[]
    for n in ns:
        k=8*n
        R=(n**64-1).bit_length()+256
        # Exact upper and lower checks for the ceiling, using integers only.
        assert 2**(R-256)>=n**64 and 2**(R-257)<n**64
        L=lg2(n);lr=lg2(R)
        low=lg2(6)+2*L+(lr+R*(lg2(24)+3*L))/n+8*(lr-lg2(6142)-L/2)
        cone=lg2(18)+2*L+arb(33)/4-arb(R)/8
        target=-arb(77)/4-6*L
        assert low < -43 and cone<=target
        checks.append({'n':str(n),'k':str(k),'R_exact':R,'L_log2_n':str(L),'low_log2_certificate_per_n':str(low),'low_margin_below_minus43':str(-43-low),'low_passed':True,'cone_log2_certificate_per_n':str(cone),'cone_target_per_n':str(target),'cone_margin_below_target':str(target-cone),'cone_passed':True})
    nn,kk,BB,Theta,UU=sym.symbols('n k B Theta U',positive=True)
    aa=64*nn**(nn+1)*kk**4*9**nn*BB**(2*kk)
    dl=sym.powsimp(4*nn*nn**nn/aa,force=True)
    assert sym.simplify(dl-1/(16*kk**4*9**nn*BB**(2*kk)))==0
    sq=1/(4*kk**2*3**nn*BB**kk)
    assert sym.simplify(sym.powsimp(sq**2,force=True)-dl)==0
    alpha=sq*kk*(kk-1)/Theta
    expected=(kk-1)/(4*kk*Theta)*3**(-nn)*BB**(-kk)
    assert sym.simplify(sym.powsimp(alpha-expected,force=True))==0
    direct=sym.powsimp(alpha*(3**nn*UU/Theta*BB**(kk-2)),force=True)
    assert sym.simplify(direct-(kk-1)*UU/(4*kk*Theta**2*BB**2))==0
    assert Fraction(16384,6142)<3
    cert={'scope':'Independent finite scalar verification of A1.md final (9)-(13), not an all-dimensions numerical proof or payment of the sign-rich clean sector. Analytic proof remains in A1.md.','source':'A1.md final degree-change addendum (9)-(13)','degree':'k=8n','R':'ceil(64 log2 n+256)','Theta_lower':'6142 sqrt(n)','Q0_upper':'3n^2','exact_R_method':'R=(n^64-1).bit_length()+256; both bounding integer powers verified','precision_bits':ctx.prec,'python_flint_version':flint.__version__,'checks':checks,'all_finite_checks_passed':True,'logarithmic_extension':'n=2^L, L in {16,17,20,24,32,64,128,256,512,1024}, plus n65537,10^6,10^8','new_leak_parameter':{'a':'64*n^(n+1)*k^4*9^n*B^(2k)','Lambda':'n^n','delta_bound':'delta<=4n/a, since a>=4n','symbolic_delta_Lambda_upper':str(dl),'symbolic_square_root_upper':str(sq),'symbolic_alpha_upper':str(expected),'conditional_direct_leak_bound':str(direct),'conditional_direct_leak_less_than':'U/(4*Theta^2*B^2) for k>=2','exact_tau_Theta_ratio_upper':str(Fraction(16384,6142)),'scope':'The direct expression assumes the separately established same-normalization whole-key envelope and complete masked leakage inequality; symbolic cancellation is not their proof.'},'old_fixture_count':14,'old_projection_pattern_count':1644,'preserved_fixture_sha256':fixture_hash,'command':[sys.executable,str(Path(__file__).resolve()),'--degree-change-only'],'elapsed_seconds':time.time()-tick,'errors':[]}
    old['degree_change_certificate']=cert
    old['script_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    assert hashlib.sha256(json.dumps(old['fixtures'],sort_keys=True).encode()).hexdigest()==fixture_hash
    dst.write_text(json.dumps(old,indent=2)+'\n')
    print(json.dumps({'degree_checks':len(checks),'all_finite_checks_passed':True,'old_geometry_preserved':True,'elapsed_seconds':cert['elapsed_seconds'],'script_sha256':old['script_sha256'],'RESULT_sha256':hashlib.sha256(dst.read_bytes()).hexdigest()},indent=2))

if __name__=='__main__':
    import sys as _sys
    if '--degree-change-only' in _sys.argv:
        append_degree_certificate()
        raise SystemExit(0)

from fractions import Fraction as F
from itertools import product
from math import prod
from pathlib import Path
import hashlib,json,platform,sys,time
import sympy as sp
ROOT=Path(__file__).resolve().parent;start=time.time()
def box(y,s):return [(v-s,v+s) for v in y]
def whole_intersection(boxes,n):return [(max(B[t][0] for B in boxes),min(B[t][1] for B in boxes)) for t in range(n)]
def serial(v):
 if isinstance(v,F):return str(v)
 if isinstance(v,list):return [serial(x) for x in v]
 if isinstance(v,tuple):return [serial(x) for x in v]
 if isinstance(v,dict):return {k:serial(x) for k,x in v.items()}
 return v
fixtures=[]
def roots(n,d,near=False):
 rr=[];signs=list(product((-1,1),repeat=d));r=len(signs)
 for idx,sg in enumerate(signs):
  s=F(1) if near else F(2)-F(idx,r)
  if near:y=[F(v)*(F(1,2)+F(1,32*n)) for v in sg]+[F(0)]*(n-d)
  else:
   y=[F(sg[t] if t<d else 1)*(s-F(1,10)-F((idx*3+t*5)%11,1000)) for t in range(n)]
  rr.append((y,s))
 return sorted(rr,key=lambda x:-x[1])
def add(n,d,stage,near=False,cut=False,rho_factor=F(1)):
 rr=roots(n,d,near);extra=[]
 if cut:
  base=whole_intersection([box(y,s) for y,s in rr],n);ell=[hi-lo for lo,hi in base]
  mid=[(lo+hi)/2 for lo,hi in base];radius=min(ell)/3
  mid[0]+=min(ell)/12
  extra=[box(mid,radius)]
 fixtures.append((f'{stage}_n{n}_d{d}'+('_cut' if cut else '')+('_nearsharp' if near else ''),n,d,stage,rr,extra,rho_factor))
for n in (2,3,4):add(n,n,'stage1_full_signs')
for d in (1,2,3):add(4,d,'stage2_low_active')
for d in (1,2):add(4,d,'stage2_extra_cut',cut=True)
for d in (1,2,3):
 add(8,d,'stage3_product_unequal')
 add(8,d,'stage3_product_nearsharp',near=True)
records=[];allfail=[]
for name,n,d,stage,rr,extra,rho_factor in fixtures:
 a=32*n;c0=1+F(1,a);rootboxes=[box(y,s) for y,s in rr];r=len(rr)
 independent=all(any(abs(rr[j][0][t]-rr[i][0][t])>c0*rr[i][1] for t in range(n)) for i in range(r) for j in range(i+1,r))
 assert independent
 I=whole_intersection(rootboxes+extra,n);ell=[hi-lo for lo,hi in I];assert all(v>0 for v in ell)
 center=[(lo+hi)/2 for lo,hi in I];rho=min(s for y,s in rr)*rho_factor
 signs=[[1 if y[t]>=center[t] else -1 for t in range(n)] for y,s in rr]
 patterns=[];Btrue=Bcap=Bbinary=F(0);mixed_exact=F(0);fail=[]
 for mask in range(1<<n):
  J=[t for t in range(n) if mask>>t&1];j=len(J);remain=[t for t in range(n) if not mask>>t&1]
  p=len({tuple(v[t] for t in J) for v in signs})
  projection=prod((ell[t] for t in remain),start=F(1))
  S=sum(((2*s)**(-(n-j)) for y,s in rr),F(0))
  lhs=projection*S
  if not lhs<=p<=min(2**j,r):fail.append(mask)
  weight=(2*c0*rho)**j
  Btrue+=weight*p/S;Bcap+=weight*min(2**j,r)/S;Bbinary+=weight*2**j/S;mixed_exact+=weight*projection
  patterns.append({'mask':mask,'J':J,'p_J':p,'binary_classes':2**j,'root_capped_binary_classes':min(2**j,r),'projection_volume':projection,'inverse_radius_sum_dimension_n_minus_j':S,'lhs_projection_times_sum':lhs,'p_minus_lhs':p-lhs,'certificate_passed':lhs<=p<=min(2**j,r)})
 H=prod((v+2*c0*rho for v in ell),start=F(1));assert H==mixed_exact
 assert H<=Btrue<=Bcap<=Bbinary
 if 'nearsharp' in name:
  beta=F(1,2)+F(1,a)
  expected=(1+c0-beta)**d*(1+c0)**(n-d)
  assert H/(2**n)==expected
  # Product factorization of every true sign count and all halo terms.
  assert all(v['p_J']==2**len([t for t in v['J'] if t<d]) for v in patterns)
  assert Btrue/(2**n)==(F(1,2)+c0)**d*(1+c0)**(n-d)
  assert Bbinary/(2**n)==(F(1,2)+c0)**n/F(2**d)*2**n # product binary p=2^j, S=r2^-(n-j)
 row={'name':name,'stage':stage,'n':n,'active_coordinates_in_construction':d,'a':a,'c0':c0,'rho':rho,'roots':[{'center':y,'radius':s} for y,s in rr],'extra_cut_boxes':extra,'root_count':r,'all_full_center_independence_tests_passed':independent,'whole_intersection':I,'intersection_widths':ell,'intersection_center':center,'root_sign_vectors_at_whole_intersection_center':signs,'all_projection_certificates_passed':not fail,'failed_masks':fail,'projection_patterns':patterns,'exact_halo_volume':H,'true_sign_halo_certificate':Btrue,'root_capped_binary_halo_certificate':Bcap,'binary_halo_certificate':Bbinary,'binary_over_true':Bbinary/Btrue,'capped_binary_over_true':Bcap/Btrue,'true_over_exact':Btrue/H,'exact_halo_over_smallest_parent_volume':H/(2*min(s for y,s in rr))**n,'exact_halo_times_root_inverse_volume_sum':H*sum(((2*s)**(-n) for y,s in rr),F(0))}
 records.append(serial(row));allfail.extend((name,x) for x in fail)
# Independent symbolic product identity for the nearsharp equal-radius family.
nn,dd,cc=sp.symbols('n d c',positive=True,integer=True)
bb=sp.symbols('beta',positive=True)
# Active factor of true-p certificate: undilated bound1/2, dilated c.
# Inactive factor: undilated1, dilated c. Exact active factor1-beta+c.
symbolic={'true_sign_bound_over_parent_volume':'(1/2+c0)^d*(1+c0)^(n-d)','exact_halo_over_parent_volume':'(1-beta+c0)^d*(1+c0)^(n-d)','beta':'1/2+1/a','exact_specialization':'(3/2)^d*(2+1/a)^(n-d)','true_over_exact':'[(3/2+1/a)/(3/2)]^d','pure_binary_over_parent_volume':'2^(n-d)*(1/2+c0)^n'}
assert sp.expand((1-bb+cc).subs({bb:sp.Rational(1,2)+1/sp.Symbol('a'),cc:1+1/sp.Symbol('a')}))==sp.Rational(3,2)
out={'scope':'Geometry-only independent-root and whole-intersection tests. No q/highT, original strict-core construction, sharpness, or complete clean-branch payment is asserted. Extra cutting cubes are geometry only, not asserted valid assigned clean parents.','python':sys.version,'sympy_version':sp.__version__,'platform':platform.platform(),'command':[sys.executable,str(Path(__file__).resolve())],'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'arithmetic':'Exact Fraction for every geometry volume, pattern count and comparison; SymPy symbolic factor check. No random search or floating tolerance.','fixtures':records,'symbolic_nearsharp_product':symbolic,'summary':{'fixture_count':len(records),'projection_pattern_count':sum(len(v['projection_patterns']) for v in records),'all_full_center_independence_passed':True,'all_projection_certificates_passed':not allfail,'failures':allfail},'elapsed_seconds':time.time()-start,'errors':[]}
(ROOT/'RESULT.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:out[k] for k in ('script_sha256','summary','elapsed_seconds')},indent=2))
for r in out['fixtures']:
 print(r['name'],'binary/true',r['binary_over_true'],'true/exact',r['true_over_exact'],'halo/parent',r['exact_halo_over_smallest_parent_volume'])
print('RESULT.json sha256',hashlib.sha256((ROOT/'RESULT.json').read_bytes()).hexdigest())

append_degree_certificate()
