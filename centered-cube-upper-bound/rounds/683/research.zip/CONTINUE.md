# R683 continuation — the sign-rich complete clean integral is still unpaid

General arbitrary-L1, all-scales, Lebesgue C_n<=K sqrt(n) remains UNPROVED; goal active. Read REPORT.tex then S3/S2. A1 preserves development details; its earlier k~sqrt(n) regime is superseded by its final addendum and REPORT, not mixed with the new regime.

## Final parameter contract

For each dimension reconstruct original finite owners/q/recursion/cores/receivers at
k=8n, N=(n+1)^n, B=3N,
a=64 n^(n+1) k^4 9^n B^(2k), tau=16384 sqrt(n), T=3tau/8-a^-n, Theta=T-1>=6142 sqrt(n).
Finite packing entrance has no a^n loss, valid for every a. Never relabel old owners to fit new a.

Complete degree cover is D_k>=Theta^k V/k! for EVERY degree: actual outside source rate in each strict core exceeds Theta. Earliest-core halo and causal mask contain each such original receiver. No old pair cover or factor100/97 is used.

Same complete kernels, original clean weights omega, and exact full graph peeling as R682. Retained degree r counts OCCURRENCES, not distinct roots. Exact root mark1/r and deleted incoming-union rate<=r are indispensable.

R682 all-degree leakage bridge plus coarse all-core envelope gives k!L_k/Theta^k< U/(4Theta²B²) with the new a. No lower-degree clean terminal remains.

## New paid clean sectors

R=ceil(64log2 n+256).
- r<R, ALL signs: normalized cost<=2^-43n U for n>=65536.
- r>=R, signs constant on >=ceil(n/2) coordinates relative to center of FULL I_m: normalized cost<=2^[-n(77/4+6log2 n)]U.

Proof charges one original source grid globally. Other coeligible root radii lie in (2si/n,nsi/2). Disjoint actual owner cumulative volume gives Q0<=3n², or Q<=2^-n/4 for half-coordinate same-sign pools. Grid, halo, sign choices give (6n²)^n or (18n²)^n costs, kept explicitly before coefficient sums. New degree k8n absorbs low r despite the grid; cone decay absorbs high r. No per-core U, no boundary density cap on arbitrary f.

No strict core exists for 256<=n<=65536 by old common-witness owner capacity <=c0^n[1+nlog(n/2)]<6143sqrt(n); earlier n<256 hard branch stays disposed.

## Exact remaining target

C_rich is the ORIGINAL clean key cost with r>=R and root signs varying in >floor(n/2) coordinates, not an altered kernel or independent owner product. Need G_rich=k!C_rich/Theta^k<=C U uniformly in n and input. Preserve all original deleted parents, actual Y, earliest-core seed radius, causal masks, omega and history.

Full account: V<=G_rich+eta_n U,
eta_n=2^-43n+2^[-n(77/4+6log2n)]+1/(4Theta²B²),
V0<=Cadm{[1+(Kfar+Kup)/tau+eta_n]U+G_rich}, P0>=U/tau.
Cadm=1+e^(1/16),Kfar=2e^(33/32),Kup<=8e^(33/16).
No final pure-sqrt upper bound follows until the remaining full weighted geometry is controlled.

Projection estimate |proj_(Jc)I| sum_roots(2si)^[-(n-|J|)]<=actual sign classes M_J is valid but has an unshrunk highest mixed-volume halo term. Do not count it alone as global payment. Separate single-orthant pool smallness loses its gain when all2^n patterns are summed. Focus on joint receiver/root geometry rather than graph-only rewrites or accumulating easier branches.

## Actual verification and scheduling

14 rational geometry fixtures,1644 projection checks,13 finite scalar dimensions through2^1024; tests do NOT realize the high-threshold recursion. 256-bit Arb original calculations,320-bit independent verify.py; analytic proofs supply uniform n statements. Python3.12 environment; no MATLAB or PDF. Manifest binds delivery files; regenerating RESULT changes runtime metadata.

User cap: one Astra, three GPT-6.1 Sol, reuse agents; local computation unrestricted when useful. Next genuine round is684. Do not make another683 commit. Continue respecting clean dedicated clone and independently verify remote acceptance on each round.

## Next candidate from Astra after this round's final theorem (not independently audited)

For full intersection I=c+product[-h_t,h_t] and an actual x in its halo outside all source parents, centers of any radius-s parent containing I but excluding x lie in C_s(I) minus Q(x,s), where C_s(I)=c+product[-(s-h_t),s-h_t]. Proposed exact volume is product 2(s-h_t) minus product [2(s-h_t)-delta_t]_+, delta_t=(|x_t-c_t|-h_t)_+. These differences are NOT nested in s; do not insert their volumes into a cumulative-owner formula.

A proposed owner-wise envelope sets ell(u)=max{rho,max_t(h_t+|u_t-c_t|)/c0}, cminus=1-1/a. For eligible owners at rho<=s_i<n rho/2, I subset Ai and x outside Ai imply ell(u)<=s_i and ||u-x||infty>cminus ell(u). Disjoint owners then give a pointwise envelope with denominator (2ell(u))^n. This retains actual receiver information, but I and rho vary with the complete key. It is not an independent fixed pool, and no product/integral interchange paying G_rich has been proved. Check the formula and joint dependence before using it. This is a precise next candidate, not an additional R683 theorem or claimed fee payment.
