# R683 true sign classes in simultaneous normalized-root halo bounds

## Decision

Keeping the actual sign-class counts materially reduces the full halo certificate in low-active-coordinate families. It does not make that certificate dimension-free: a family where the true-count certificate is nearly exact already has a large halo contribution from inactive coordinates. Thus there are two separate expenses: avoidable binary sign counting and actual geometric halo growth.

This is a geometry-only consistency experiment. It does not assign q, construct a hard high-T residual core, or pay the original complete clean-key integral. Extra cutting cubes are geometric constraints, not asserted valid assigned clean parents.

## Precise quantities

The root parents are `Ai=Q(yi,si)`, in nonincreasing radius order. Every pair satisfies full expanded-center independence: for i<j, `yj∉Q(yi,c0 si)`, with `a=32n`, `c0=1+1/a`. Compute the **whole** positive intersection I, including any auxiliary cutting cubes, before calculating its widths ell and center m. Let J be a subset of deleted coordinate indices, j=|J|. Define

`p_J=#{(sign(yi,t−m_t))_(t∈J): i a root}`,

with zero assigned the positive sign. Ties at center coordinates use this deterministic rule; there is no random sign assignment. For every J the script computes exactly

`S_(n−j)=Σi(2si)^−(n−j)`,

`|π_(J^c) I| S_(n−j)≤p_J≤min(2^j,r)`.

All r root parents remain in this sum even when some other parent controls an intersection face. For j=n the projection is zero-dimensional with volume one and S0=r, so the full sign count must equal r. For j=0 the bound is the simultaneous normalized-root volume inequality.

For `rho≤min si`, the exact halo is

`H=∏t(ell_t+2c0 rho)=Σ_J(2c0 rho)^j |π_(J^c)I|`.

The three upper certificates replace the projection volume respectively by

- `p_J/S_(n−j)` (true sign classes);
- `min(2^j,r)/S_(n−j)` (root-capped binary classes);
- `2^j/S_(n−j)` (binary classes).

Every individual projection comparison and the complete inequalities `H≤B_true≤B_capped≤B_binary` are checked by exact rational arithmetic. The expanded product for H is independently checked against its direct product formula.

## Bounded fixtures actually executed

Stage 1 uses full sign families in dimensions 2,3,4, with 2^n roots, unequal rational radii in [1,2], and small rational coordinate offsets around 1/10. Different sign coordinates force the required expanded-center independence, which is also tested pair by pair. Full sign families have p_J=2^j, so actual sign counting gives no saving there.

Stage 2 uses n=4 and d=1,2,3 active coordinate families, again with unequal radii. Two additional d=1,2 fixtures include a rational cutting cube strictly reducing the root-only intersection. The code uses the actual new whole intersection and its center; no root-only width or original center is silently reused. All certificates still hold. Extra cuts increase the gap between the projection certificate and the true halo, as expected, without changing the algebraic root-normalization denominator.

Stage 3 uses n=8,d=1,2,3, with product-structured unequal-radius roots and a separate nearsharp equal-radius sign-code family. Each n=8 fixture has only 256 projection patterns; no high-dimensional lattice, geometric grid search, or word enumeration is used. Across all three stages there are **14 fixtures and 1644 projection patterns**, all passing the stated certificates.

## Nearsharp product stress and the real remaining expense

The equal-radius family has `si=1`, root labels indexed by all signs on d active coordinates,

`yi,t=±beta` on active coordinates and zero on inactive coordinates,

`beta=1/2+1/a`, `rho=1`, `r=2^d`.

For distinct roots a differing active coordinate has center separation `2beta=1+2/a>c0`. Thus these are actual independent root parents. I has active widths `2(1−beta)` and inactive widths 2. Its center is zero, and

`p_J=2^|J∩active|`.

All projection identities factor by coordinate. Exact formulas, checked against every mixed term and the direct halo product, are

`H/2^n=(1−beta+c0)^d(1+c0)^(n−d)`

`          =(3/2)^d(2+1/a)^(n−d)`,

`B_true/2^n=(1/2+c0)^d(1+c0)^(n−d)`,

`B_true/H=(1+2/(3a))^d`,

`B_binary/2^n=2^(n−d)(1/2+c0)^n`.

Thus the true-count projection estimate becomes arbitrarily close to exact as a increases, yet the actual halo retains a factor near 2 per inactive coordinate. Relative to the simultaneous normalized-root sum,

`H Σi(2si)^−n = 3^d(2+1/a)^(n−d)`.

This rules out a dimension-free pointwise halo coefficient from root independence alone in this geometric model. A valid global clean-budget proof would need additional geometry or an integral/source budget; improving the sign count alone does not supply that payment.

For n=8,a=256, the following entries are truncated to six decimal places from exact fractions:

| active d | binary/true | capped/true | true/exact | H/parent volume | H times root inverse-volume sum |
|---|---:|---:|---:|---:|---:|
| 1 | 17.163802 | 1.329905 | 1.002604 | 194.640431 | 389.280862 |
| 2 | 11.435105 | 1.742929 | 1.005215 | 145.695761 | 582.783044 |
| 3 | 7.618453 | 2.174622 | 1.007832 | 109.058815 | 872.470523 |

Here `true/exact=(385/384)^d`. The saving from keeping actual sign classes is substantial, while the true coefficient remains large even when its upper bound is within one percent of exact. This distinguishes a loose binary-count bound from actual geometric cost. No sharpness or hard-core realizability assertion is made.

## Appended independent degree-change scalar certificate

This bounded check reads A1.md final formulas (9)–(13), changes the degree to `k=8n`, and uses

`R=ceil(64 log2 n+256)`, `Theta≥6142√n`, `Q0≤3n²`.

It verifies the displayed low-degree scalar certificate

`log2[(6n²)^n R(kQ0)^R(R/Theta)^k]/n≤−43`

and the cone comparison

`log2[(18n²)^n 2^(8n)2^(−nR/8+n/4)]≤−n(19.25+6log2n)`.

All evaluations use 256-bit Arb ball arithmetic and strict interval comparisons. R has a fully exact integer ceiling: `R=(n^64−1).bit_length()+256`, with both bounding integer powers checked. Thus interval rounding of log2 n cannot accidentally lower R.

There are 13 distinct tested dimensions: n=65536,65537,10^6,10^8 and n=2^L for `L=16,17,20,24,32,64,128,256,512,1024` (65536 appears in both lists). All tests pass. The following displayed centers are approximate; the full certified balls and margins are in RESULT.json.

| n | exact R | low log2 bound per n | cone log2 bound per n | cone target per n |
|---|---:|---:|---:|---:|
| 65536 | 1280 | -46.488348 | -115.580075 | -115.250000 |
| 65537 | 1281 | -46.478590 | -115.705031 | -115.250132 |
| 1000000 | 1532 | -53.205872 | -139.216938 | -138.839411 |
| 100000000 | 1957 | -63.764755 | -179.054225 | -178.702549 |

These are finite sanity checks, **not an all-dimensions numerical proof**. The uniform derivation remains the analytic argument in A1.md. The sign-rich high-retained-degree clean sector is not paid by this certificate.

### Rechecked leakage parameter at the changed degree

The new leakage parameter is distinct from the former k≈sqrt(n) parameter:

`a=64 n^(n+1) k^4 9^n B^(2k)`, `Lambda=n^n`, `k=8n`.

SymPy verifies the exact cancellation

`4nLambda/a=1/(16k^4 9^n B^(2k))`.

The general bound `delta≤4n/a` follows from a≥4n. Its square-root upper bound is

`√(delta Lambda)≤1/(4k²3^nB^k)`.

Consequently the rechecked leakage coefficient obeys

`alpha≤[(k−1)/(4kTheta)]3^−nB^−k`.

The same-normalization whole-key envelope, when separately established, gives

`F_(k−1)≤3^n U/Theta B^(k−2)`.

Their symbolic product cancels exactly to

`[(k−1)/(4k)]U/(Theta²B²) < U/(4Theta²B²)` for k≥2.

The exact comparison `16384/6142<3` is checked as the rate-ratio input for B. These are algebraic identities for the new degree; they do not import the obsolete bound k≤129√n. No astronomical a, delta subtraction, giant grid, or giant source family is constructed. The masked leakage inequality and whole-key envelope remain analytic inputs rather than conclusions of the symbolic computation.

The append mode loads the existing RESULT.json and preserves all 14 fixtures and 1644 geometry checks; a canonical SHA-256 of the fixture array is recorded to certify preservation. Reproduce just this append without rerunning geometry using:

```text
/Users/zzh/.local/share/math-research-tools/venv/bin/python /Volumes/data/CodexTemp/centered-cube-r683-20261116/NUMERIC.py --degree-change-only
```

## Reproducibility

Executed command:

```text
/Users/zzh/.local/share/math-research-tools/venv/bin/python /Volumes/data/CodexTemp/centered-cube-r683-20261116/NUMERIC.py
```

All geometry, volumes, inverse-radius sums, sign counts and comparisons use Python `fractions.Fraction`. SymPy checks the nearsharp specialization. RESULT.json retains every root, cutting cube, whole intersection, sign vector, projection pattern, exact gap and full certificate, together with Python/SymPy/platform versions and the source hash. Source SHA-256: `7b105d356fe83540f4a51b1ce7ec0953921d83c5d8ef83738082f0052b483ced`. Result SHA-256: `be47ba4636c4c1079f2de0ee854d72cbe075a22b1bd6f2c7e82700141efa69a2`. The original geometry run took about 0.12 seconds. The appended degree-only certificate took about 0.03 seconds and did not rerun geometry. Both completed with exit code zero and recorded no errors or certificate failures. No MATLAB, PDF, Git, package installation, or child agent was used.
