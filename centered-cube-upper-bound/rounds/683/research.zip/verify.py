#!/usr/bin/env python3
"""Independent delivery checks: finite geometry/scalars, never the open theorem."""
from pathlib import Path
from fractions import Fraction as F
from itertools import combinations
from math import prod
import json, hashlib
from flint import arb, ctx
P=Path(__file__).resolve().parent
j=json.loads((P/'RESULT.json').read_text());ctx.prec=320
assert not j['errors']
count=0
for row in j['fixtures']:
 roots=[([F(t) for t in r['center']],F(r['radius'])) for r in row['roots']]
 n=row['n'];c0=F(row['c0']);rho=F(row['rho'])
 for (y,s),(z,t) in combinations(roots,2):
  assert s>=t and any(abs(y[h]-z[h])>c0*s for h in range(n))
 boxes=[[(v-s,v+s) for v in y] for y,s in roots]
 boxes += [[(F(lo),F(hi)) for lo,hi in b] for b in row['extra_cut_boxes']]
 I=[(max(b[h][0] for b in boxes),min(b[h][1] for b in boxes)) for h in range(n)]
 widths=[hi-lo for lo,hi in I];center=[(hi+lo)/2 for lo,hi in I]
 assert min(widths)>0
 full=prod(w+2*c0*rho for w in widths);mixed=F(0)
 for rec in row['projection_patterns']:
  J=rec['J'];d=n-len(J)
  pats=len({tuple(int(y[h]>=center[h]) for h in J) for y,s in roots})
  v=prod((widths[h] for h in range(n) if h not in J),start=F(1))
  inv=sum(((2*s)**(-d) for y,s in roots),F(0))
  assert v*inv<=pats<=min(2**len(J),len(roots))
  assert pats==rec['p_J'] and v*inv==F(rec['lhs_projection_times_sum'])
  mixed+=(2*c0*rho)**len(J)*v;count+=1
 assert full==mixed==F(row['exact_halo_volume'])
assert len(j['fixtures'])==14 and count==1644
cert=j['degree_change_certificate']
assert cert['preserved_fixture_sha256']==hashlib.sha256(json.dumps(j['fixtures'],sort_keys=True).encode()).hexdigest()
def log2(t):return arb(t).log()/arb(2).log()
for row in cert['checks']:
 n=int(row['n']);k=8*n;R=(n**64-1).bit_length()+256
 assert R==row['R_exact'] and (1<<(R-257))<n**64<=(1<<(R-256))
 L=log2(n)
 low=n*(log2(6)+2*L)+log2(R)+R*(log2(k)+log2(3)+2*L)+k*(log2(R)-log2(6142)-L/2)
 cone=n*(log2(18)+2*L)+k-n*arb(R)/8+arb(n)/4
 assert low < -43*n and cone <= -arb(n)*(arb(77)/4+6*L)
assert F(16384,6142)<3
assert F(32,31)*(F(1,256)+3840)<6143
assert 81*64<6142 and 81*16*(6+3*16)<2*65536
if (P/'MANIFEST.json').exists():
 for name,sha in json.loads((P/'MANIFEST.json').read_text()).items():
  assert hashlib.sha256((P/name).read_bytes()).hexdigest()==sha,name
print(json.dumps({'status':'PASS','independent_exact_geometry_fixtures':14,'independent_projection_checks':count,'independent_Arb_bits':ctx.prec,'scalar_dimensions':len(cert['checks']),'scope':'finite checks and delivery integrity; general sign-rich estimate unproved'}))
