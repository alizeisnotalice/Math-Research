#!/usr/bin/env python3
"""Exact public co-parent ranks and an actual five-point rectangle reference."""
import argparse
from collections import defaultdict
from fractions import Fraction as F
from hashlib import sha256
from itertools import combinations, product
import json
from math import prod
from pathlib import Path
import platform
import subprocess
import sys


DEPENDENCIES={
    'rectangle806.py':'04714603e8dfbc8b7fe6f1f9e431c4fd8cf9c3b671e567e34bd5315244c576be',
    'profile806.json':'176f897ca3fc7fd4ffd00770d39100437c4394fdd51044a108563bc76a0ff0f1',
    'triples806.py':'203a1f2ff8c6e13b66f77ad81055e71471f87b59ae805a3037c69d4ed0e3ae98',
    'reverse805.py':'c9a810c2807fa592e0fc76c514738522d8414d2e01c548579856e64d8b7fb17e',
    'reverse805.json':'955de184b852e78a2913ca9e1865404afa746c0425a920c3aa80bf9896dad886',
    'shared805.py':'d35faf62af4a6498cfaff0bd8ce1b59ebdd870143847660c67f02aa0aa10ceab',
}


def total(x):
    return sum(x,F(0))


def pow2(j):
    return F(2)**j


def dyadic_rank(R):
    assert R>0
    j=R.numerator.bit_length()-R.denominator.bit_length()
    if R>pow2(j):
        j+=1
    assert pow2(j-1)<R<=pow2(j)
    return j


def rank_shape(j,shift):
    return F(1)/(8*pow2(j)*(shift+abs(j))**2)


def physical_atoms(stage,model,old):
    T,U=stage['middle_cubes'],stage['small_cubes']
    parents=T+U
    boxes=[old.box(p['A']) for p in parents]
    amp=F(stage['true_source_amplitude'])
    mu=lambda B:model.source_mass(B,amp)
    axes=[]
    for d in range(stage['n']):
        cuts=sorted({-model.SUPPORT,model.SUPPORT,*(z for B in boxes for z in B[d])})
        axes.append([(sum(1<<k for k,B in enumerate(boxes) if B[d][0]<=a<b<=B[d][1]),
                      mu(((a,b),)) if d==0 else b-a) for a,b in zip(cuts,cuts[1:])])
    masses=defaultdict(F)
    for coordinates in product(*axes):
        mask=(1<<len(boxes))-1
        w=F(1)
        for bits,m in coordinates:
            mask &= bits
            w *= m
        masses[mask]+=w
    for i,p in enumerate(parents):
        assert total(w for s,w in masses.items() if (s>>i)&1)==F(p['m'])
    label_b=[F(p['j'])/F(p['m']) for p in parents]
    chi_density={s:total(label_b[i] for i in range(len(T),len(parents)) if (s>>i)&1) for s in masses}
    chi={s:m*chi_density[s] for s,m in masses.items()}
    assert total(chi.values())==total(F(p['j']) for p in U)
    assert total(masses.values())==mu(((-model.SUPPORT,model.SUPPORT),)*stage['n'])
    return parents,boxes,mu,{'mu':dict(masses),'chi':chi},chi_density


def one_rank_row(x, scores, dest, D):
    groups=defaultdict(list)
    for w,K in scores.items():
        if K>0:
            groups[K].append(w)
    mass=F(0)
    tickets={}
    layer_masses=defaultdict(F)
    row_weights={1:F(0),3:F(0)}
    ties=0
    for K,target in sorted(groups.items(),reverse=True):
        live=[w for w in target if dest[w]>0]
        add=total(dest[w] for w in live)/D
        if not add:
            continue
        before=mass
        mass+=add
        j=dyadic_rank(mass)
        assert mass==total(dest[w] for w,score in scores.items() if score>=K)/D
        layer_masses[j]+=add
        ties+=len(live)>1
        for w in live:
            density=rank_shape(j,3)/D
            tickets[w]=dict(K=K,rank=mass,strict_before_tie_rank=before,dyadic_j=j,
                true_destination_atom_mass=dest[w],density_against_destination=density,
                mass=density*dest[w],equal_K_positive_atom_count=len(live))
        for offset in row_weights:
            row_weights[offset]+=rank_shape(j,offset)*add
    assert all(m<=pow2(j) for j,m in layer_masses.items())
    for offset,w in row_weights.items():
        bound=(F(1,offset**2)+F(2,offset))/8
        assert 0<=w<=bound<1
    assert total(q['mass'] for q in tickets.values())==row_weights[3]
    cemetery=1-row_weights[3]
    assert row_weights[3]+cemetery==1
    return dict(x=x,tickets=tickets,mass=row_weights[3],raw_shift_one_mass=row_weights[1],cemetery=cemetery,
        ties=ties,positive_rank_max=mass)


def all_rank_rows(stage,physical,rect):
    T,U=stage['middle_cubes'],stage['small_cubes']
    parents,_,_,dest,_=physical
    families=defaultdict(list)
    for k,p in enumerate(parents):
        role='middle' if k<len(T) else 'small'
        d=rect.dyadic_lower(F(p['m']))
        families[role,d].append(k)
    rows={}
    checks=[]
    for family,indices in sorted(families.items()):
        role,D=family
        coefficient={i:D*F(parents[i]['j'])/F(parents[i]['m'])**2 for i in indices}
        for sigma,weights in dest.items():
            tested={}
            for x in sorted(weights):
                active=[i for i in indices if (x>>i)&1]
                score={w:total(coefficient[i] for i in active if (w>>i)&1) for w in weights}
                tested[x]=one_rank_row(x,score,weights,D)
            rows[family,sigma]=tested
            vals=[r['mass'] for r in tested.values() if r['mass']]
            checks.append(dict(role=role,D=D,all_family_physical_ids=indices,sigma=sigma,
                tested_full_parent_membership_atoms=len(tested),positive_rows=len(vals),zero_rows=len(tested)-len(vals),
                positive_mass_range=[min(vals),max(vals)] if vals else None,
                maximum_mass_shift_one=max(r['raw_shift_one_mass'] for r in tested.values()),
                positive_tie_blocks=sum(r['ties'] for r in tested.values())))
    return rows,checks


def strict_contains(x,B):
    return all(a<r<b for r,(a,b) in zip(x,B))


def point_and_subbox(B,checked,model,avoid=(),fixed=None):
    candidates=(fixed,) if fixed is not None else (tuple(a+(b-a)/order for a,b in B) for order in range(3,100))
    for x in candidates:
        assert strict_contains(x,B)
        if x in avoid or (4*x[0]).denominator==1:
            continue
        if any(x[d] in C[d] for C in checked for d in range(len(x))):
            continue
        span=[]
        for d,(a,b) in enumerate(B):
            cuts={a,b,*[v for C in checked for v in C[d]]}
            e=min(abs(x[d]-c) for c in cuts)/4
            span.append((x[d]-e,x[d]+e))
        Q=tuple(span)
        assert model.inside(Q,B) and model.volume(Q)>0
        return x,Q
    raise AssertionError('no physical interior point selected')


def true_square(stage,profile,config,physical,model,old,triples):
    _,marks,T,U,mu,middle_bin,small_bin,_,owners,_=config
    frozen=profile['selected_anchor']
    u=frozen['u']
    r=owners[u].index(old.box(frozen['U_subbox']))
    root=(u,r,tuple(frozen['full_y_middle_mask']))
    M,D=F(frozen['central_bin']),small_bin[u]
    best=None
    for row in profile['actual_price_rows']:
        Z=old.box(row['z_actual_box'])
        H,Ht,_,_=triples.same_z_edges(stage,config,M,D,Z,model,old)
        xs=sorted(x for x in Ht[root] if x[0]==0)
        for x,xx in combinations(xs,2):
            for a1 in sorted(H[x].keys()&H[xx].keys()):
                if a1==root:
                    continue
                key=(int(x[1]!=xx[1])+int(u!=a1[0]),int(x[2]!=xx[2]),int(x[1]!=xx[1]))
                if best is None or key>best[0]:
                    best=(key,Z,x,xx,root,a1,[H[x][root],H[x][a1],H[xx][root],H[xx][a1]])
        if best and best[0][0]==2:
            break
    assert best is not None
    _,Z,x,xx,a,aa,h=best
    assert min(h)>0
    Q1,Q2=marks[x[1]][x[2:]]['price'],marks[xx[1]][xx[2:]]['price']
    W1,W2=marks[x[1]][x[2:]]['owner'],marks[xx[1]][xx[2:]]['owner']
    Y1=old.box(frozen['y_subbox'])
    index_to_pair=[(row['t'],row['u']) for row in stage['by_t_u']]
    Y2=None
    for Y in stage['alternation']['source_atoms']:
        active=tuple(sorted(t for k in Y['active_types'] for t,v in [index_to_pair[k]] if v==aa[0]))
        if active==aa[2]:
            Y2=old.box(Y['representative_cell'])
            break
    assert Y2 is not None
    source_boxes={'z':Z,'q1':Q1,'q2':Q2,'y1':Y1,'y2':Y2}
    checked=physical[1]+[old.box(t['hat']) for t in T]+[old.box(v['G']) for v in U]
    selected={}
    for name,B in source_boxes.items():
        fixed=tuple(map(F,frozen['actual_y_point'])) if name=='y1' else None
        point,box=point_and_subbox(B,checked,model,tuple(q['price_point'] for q in selected.values()),fixed=fixed)
        mask=sum(1<<i for i,P in enumerate(physical[1]) if strict_contains(point,P))
        assert mask in physical[3]['mu']
        selected[name]=dict(price_point=point,positive_subbox=box,actual_parent_membership_mask=mask)
    for x0,a0,qn,yn in [(x,a,'q1','y1'),(x,aa,'q1','y2'),(xx,a,'q2','y1'),(xx,aa,'q2','y2')]:
        _,t,g,*_=x0
        u0,r0,_=a0
        t_box=old.box(T[t]['A'])
        assert model.inside(selected['z']['positive_subbox'],t_box)
        assert model.inside(selected['z']['positive_subbox'],old.box(U[u0]['A']))
        assert model.inside(selected[qn]['positive_subbox'],t_box)
        assert model.inside(selected[qn]['positive_subbox'],old.box(U[g]['A']))
        assert model.inside(selected[yn]['positive_subbox'],old.box(U[u0]['G']))
        assert model.volume(model.clip(selected[yn]['positive_subbox'],old.box(T[t]['hat'])))==0
    assert model.center(owners[a[0]][a[1]])==tuple(map(F,frozen['actual_U_point']))
    assert selected['y1']['price_point']==tuple(map(F,frozen['actual_y_point']))
    return M,D,selected,dict(encoded_lefts=[x,xx],encoded_rights=[a,aa],true_corner_h=h,
                            actual_owner_points=[model.center(Q) for Q in (owners[a[0]][a[1]],owners[aa[0]][aa[1]],W1,W2)])


def tree_tests(M,D,points,R,physical):
    _,_,mu,base,chi_density=physical
    refs={'z':'mu','q1':'chi','q2':'chi','y1':'mu','y2':'mu'}
    for name,p in points.items():
        w=mu(p['positive_subbox'])
        mask=p['actual_parent_membership_mask']
        p['actual_mu_subbox_mass']=w
        p['actual_chi_subbox_mass']=w*chi_density[mask]

    def step(x,w,family,sigma):
        a,b=(points[k]['actual_parent_membership_mask'] for k in (x,w))
        row=R[family,sigma][a]
        ticket=row['tickets'][b]
        wp=points[w]['actual_'+sigma+'_subbox_mass']
        assert wp>0 and ticket['K']>0
        original=ticket['density_against_destination']*wp
        assert original<=ticket['mass']<=row['mass']
        conditional=original/row['mass']
        shape=rank_shape(ticket['dyadic_j'],3)
        Omega=ticket['K']/shape
        assert original==conditional*row['mass'] and original*Omega==ticket['K']*wp/family[1]
        return dict(source=x,destination=w,sigma=sigma,family=family,Omega=Omega,J0=shape,**ticket,
             row_mass=row['mass'],row_cemetery_probability=row['cemetery'],raw_hit_subbox=original,
             hit_subbox_conditioned_on_row_survival=conditional)

    mid=('middle',M)
    small=('small',D)
    common=[step('z','q2',mid,'chi'),step('z','y1',small,'mu'),step('z','y2',small,'mu')]
    z_first=step('z','q1',mid,'chi')
    q_first=step('q1','z',mid,'mu')
    assert z_first['K']==q_first['K']
    assert all(a['sigma']==refs[a['destination']] for a in common+[z_first,q_first])
    wrong1=step('z','q1',mid,'mu')
    wrong2=step('q1','z',mid,'chi')

    def at_witness(root,edges):
        root_sigma=refs[root]
        root_mass=points[root]['actual_'+root_sigma+'_subbox_mass']
        product_raw=prod(e['raw_hit_subbox'] for e in edges)
        correction=prod(e['row_mass'] for e in edges)
        row_conditional=prod(e['hit_subbox_conditioned_on_row_survival'] for e in edges)
        omega=prod(e['Omega'] for e in edges)
        assert product_raw==row_conditional*correction
        return dict(root=root,root_measure=root_sigma,original_root_subbox_mass=root_mass,
             Omega_four_edge_product=omega,raw_product_after_reweighting_with_Omega=root_mass*product_raw*omega,
             separately_row_normalized_product_after_Omega_and_restoring_rows=root_mass*row_conditional*omega*correction,
             raw_five_point_product=root_mass*product_raw,
             probability_reference_product_after_normalizing_only_root=root_mass*product_raw/total(base[root_sigma].values()),
             separately_row_normalized_product_with_unchanged_root=root_mass*row_conditional,
             restoring_multiplier_product_of_row_survival=correction,edges=edges)

    actionZ=R[mid,'chi']
    actionQ=R[mid,'mu']
    actionY=R[small,'mu']
    zraw=total(w*actionZ[a]['mass']**2*actionY[a]['mass']**2 for a,w in base['mu'].items())
    qraw=total(w*total(j['mass']*actionZ[z]['mass']*actionY[z]['mass']**2 for z,j in actionQ[a]['tickets'].items())
               for a,w in base['chi'].items())
    q_alt=total(actionZ[z]['mass']*actionY[z]['mass']**2*total(base['chi'][a]*actionQ[a]['tickets'].get(z,{}).get('mass',0)
                    for a in base['chi']) for z in base['mu'])
    assert qraw==q_alt and 0<zraw<=total(base['mu'].values()) and 0<qraw<=total(base['chi'].values())
    z_out=at_witness('z',[z_first]+common)
    q_out=at_witness('q1',[q_first]+common)
    assert z_out['raw_five_point_product']<=zraw and q_out['raw_five_point_product']<=qraw
    all_sources_once=prod(points[p]['actual_'+sigma+'_subbox_mass'] for p,sigma in refs.items())
    direct=all_sources_once*prod(edge['K']/edge['family'][1] for edge in [z_first]+common)
    assert direct==all_sources_once*prod(edge['K']/edge['family'][1] for edge in [q_first]+common)
    for t in (z_out,q_out):
        assert direct==t['raw_product_after_reweighting_with_Omega']
        assert direct==t['separately_row_normalized_product_after_Omega_and_restoring_rows']
    ratio=z_out['raw_five_point_product']/q_out['raw_five_point_product']
    assert ratio==z_first['density_against_destination']/q_first['density_against_destination']
    return dict(z_root=z_out,q1_root=q_out,z_root_global_raw_survival=zraw,q1_root_global_raw_survival=qraw,
             reference_five_subboxes_product_with_each_source_once=all_sources_once,
             direct_original_K_over_bin_four_edge_mass=direct,exact_wealth_identity_both_roots=True,
             z_root_global_acceptance_under_mu_probability=zraw/total(base['mu'].values()),
             q1_root_global_acceptance_under_chi_probability=qraw/total(base['chi'].values()),
             z_root_rerooted_q1_raw_local_ratio=ratio,
             wrong_sigma_mu_at_z_to_q1_hit_relative_to_true=wrong1['raw_hit_subbox']/z_first['raw_hit_subbox'],
             wrong_sigma_chi_at_q1_to_z_hit_relative_to_true=wrong2['raw_hit_subbox']/q_first['raw_hit_subbox'])


def main():
    here=Path(__file__).resolve().parent
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--r805-dir',type=Path,default=here)
    p.add_argument('--r806-dir',type=Path,default=here)
    g=p.add_mutually_exclusive_group()
    g.add_argument('--output',type=Path)
    g.add_argument('--check',type=Path)
    args=p.parse_args()
    r5,r6=args.r805_dir.resolve(),args.r806_dir.resolve()
    for f,h in DEPENDENCIES.items():
        if f!='reverse805.json':
            assert sha256(((r5 if '805' in f else r6)/f).read_bytes()).hexdigest()==h
    sys.path[:0]=[str(r6),str(r5)]
    import reverse805 as model
    import shared805 as old
    import triples806 as triples
    import rectangle806 as rect
    fixture=r5/'reverse805.json'
    data=fixture.read_bytes() if fixture.is_file() else subprocess.check_output([sys.executable,'-B',str(r5/'reverse805.py')])
    assert sha256(data).hexdigest()==DEPENDENCIES['reverse805.json']
    config=json.loads(data)['stages']
    anchors=json.loads((r6/'profile806.json').read_text())['stages']
    assert rank_shape(-1,1)<rank_shape(0,1) and rank_shape(-1,2)<rank_shape(0,2)
    assert all(rank_shape(j,3)>=rank_shape(j+1,3) for j in range(-64,65))
    result=[]
    for s,a in zip(config,anchors,strict=True):
        assert s['stage']==a['stage']
        physical=physical_atoms(s,model,old)
        ranks,checks=all_rank_rows(s,physical,rect)
        M,D,points,quad=true_square(s,a['right_fixed_middle_posterior'],triples.genuine_config(s,model,old),physical,model,old,triples)
        tests=tree_tests(M,D,points,ranks,physical)
        result.append(dict(stage=s['stage'],dimension=s['n'],full_membership_mu_masses=physical[3]['mu'],
                   actual_chi_masses=physical[3]['chi'],total_true_mu=total(physical[3]['mu'].values()),
                   total_true_chi=total(physical[3]['chi'].values()),all_full_same_bin_rank_rows=checks,
                   fixed_original_anchor_witness=dict(central_bin=M,small_bin=D,points=points,**quad),
                   five_point_reference_trees=tests))
    out=dict(runtime=dict(python=platform.python_version(),architecture=platform.machine(),arithmetic='Fraction exact'),
        reproduction='python -B ranks807.py --check ranks807.json',dependencies=DEPENDENCIES,stages=result,
        monotonicity=dict(J_at_minus_one_and_zero_shift_one=[rank_shape(-1,1),rank_shape(0,1)],
             J_at_minus_one_and_zero_shift_two=[rank_shape(-1,2),rank_shape(0,2)],
             J_at_minus_one_and_zero_shift_three=[rank_shape(-1,3),rank_shape(0,3)],
             row_bound_shift_one=F(3,8),row_bound_shift_three=F(7,72)),
        scope=dict(kernel='D is the bin lower endpoint. All physical parents of the appropriate role and bin enter K_D=D*sum j_i/m_i^2. Full real membership atoms are integrated against mu and chi. L=1 and chi uses every actual old small parent.',
           rank='Group ties in exact positive K before taking cumulative right-endpoint sigma mass divided by D. Each dyadic rank layer has normalized mass at most 2^j. J=rank_shape(j,3)*sigma/D with cemetery supplement. The offset-one alternative has a mass bound only. Offset 3 is monotone globally, since for j<0 the consecutive denominator ratio is at least 2*(3/4)^2 and for j>=0 exceeds 1.',
           true_points='Use one positive actual four-edge witness in each frozen right anchor, keeping full original q and receiver marks, legal external y, z in the true common price cell, and physical bins. Every selected price point has a positive actual subbox. No alternative anchors are scanned.',
           reroot='The z-root tree sends q1 and q2 against chi in the middle bin and y1 and y2 against mu in the small bin. The q1-root tree sends to z against mu with the other three slots unchanged. Root measures are accounted once. No row acceptance division is applied to raw successful original-point products. Row-normalized products require restoring all row acceptances. In each positive subbox product the four edge factors Omega=K/J0 restore exactly the direct product of K_D/D with each source reference used once, for both roots.',
           model='Frozen real finite cube source geometry and actual diagnostic path gates. High-dimensional hypotheses or geometric gains are not inferred.'))
    text=json.dumps(out,sort_keys=True,indent=2,default=str)+'\n'
    if args.output:
        args.output.write_text(text)
    if args.check:
        assert args.check.read_text()==text
    if args.check or args.output:
        for s in result:
            t=s['five_point_reference_trees']
            print(s['stage'],'positive square t/u labels',s['fixed_original_anchor_witness']['encoded_lefts'],s['fixed_original_anchor_witness']['encoded_rights'],
                'maximum rank row',max(c['positive_mass_range'][1] for c in s['all_full_same_bin_rank_rows'] if c['positive_mass_range']),
                'correct roots local ratio display',format(float(t['z_root_rerooted_q1_raw_local_ratio']),'.8g'))
        if args.check:
            print('byte-identical')
    else:
        print(text,end='')


if __name__=='__main__':
    main()
