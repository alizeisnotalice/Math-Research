#!/usr/bin/env python3
"""True same-label price resampling and four-cube geometric comparison."""
import argparse
from collections import defaultdict
from fractions import Fraction as F
from hashlib import sha256
from itertools import product
import json
from pathlib import Path
import platform
import subprocess
import sys


DEPENDENCIES = {
    'rectangle806.py': '04714603e8dfbc8b7fe6f1f9e431c4fd8cf9c3b671e567e34bd5315244c576be',
    'profile806.json': '176f897ca3fc7fd4ffd00770d39100437c4394fdd51044a108563bc76a0ff0f1',
    'triples806.py': '203a1f2ff8c6e13b66f77ad81055e71471f87b59ae805a3037c69d4ed0e3ae98',
    'reverse805.py': 'c9a810c2807fa592e0fc76c514738522d8414d2e01c548579856e64d8b7fb17e',
    'reverse805.json': '955de184b852e78a2913ca9e1865404afa746c0425a920c3aa80bf9896dad886',
    'shared805.py': 'd35faf62af4a6498cfaff0bd8ce1b59ebdd870143847660c67f02aa0aa10ceab',
}


def total(x):
    return sum(x,F(0))


def physical_price_partition(stage,config,model,old):
    """Join global true z cells with physical parent membership once, without an anchor scan."""
    fibres,marks,T,U,mu,*_ = config
    price={}
    for t,frame in enumerate(fibres):
        for edges in frame.values():
            for u,zflag,owner_half in edges:
                price[t,u,zflag]=marks[t][u,zflag,owner_half]['price']
    price_boxes=[price[key] for key in sorted(price)]
    parents=[old.box(v['A']) for v in T+U]
    starts=[]
    for d in range(stage['n']):
        cuts=sorted({-model.SUPPORT,model.SUPPORT,*(edge for B in price_boxes+parents for edge in B[d])})
        axis=[]
        for a,b in zip(cuts,cuts[1:]):
            zmask=sum(1<<k for k,B in enumerate(price_boxes) if B[d][0]<=a<b<=B[d][1])
            pmask=sum(1<<j for j,B in enumerate(parents) if B[d][0]<=a<b<=B[d][1])
            mass=mu(((a,b),)) if d==0 else b-a
            assert mass>0
            axis.append((zmask,pmask,mass))
        starts.append(axis)
    buckets=defaultdict(F)
    for axes in product(*starts):
        zmask=(1<<len(price_boxes))-1
        parmask=(1<<len(parents))-1
        mass=F(1)
        for zm,pm,weight in axes:
            zmask &= zm
            parmask &= pm
            mass *= weight
        buckets[zmask,parmask] += mass
    ordered_z=sorted({zmask for zmask,_ in buckets},key=lambda mask:tuple(i for i in range(len(price_boxes)) if (mask>>i)&1))
    id_of={mask:i for i,mask in enumerate(ordered_z)}
    joint={(id_of[zmask],pmask):w for (zmask,pmask),w in buckets.items()}
    z_mu=defaultdict(F)
    for (i,_),w in joint.items():
        z_mu[i] += w
    assert total(z_mu.values())==mu(((-model.SUPPORT,model.SUPPORT),)*stage['n'])
    return parents,joint,z_mu


def full_intersection(I,direction,known,T,U,partition,model,mu):
    parents,joint,_=partition
    first,second,third=I
    N=len(T)
    codes={N+known,first,second,N+third} if direction=='right' else {known,N+first,N+second,third}
    indices=sorted(codes)
    mask=sum(1<<i for i in indices)
    S=parents[indices[0]]
    for i in indices[1:]:
        S=model.clip(S,parents[i])
    split=defaultdict(F)
    for (z,M),w in joint.items():
        if M & mask == mask:
            split[z] += w
    mu_S=mu(S)
    assert mu_S>0 and total(split.values())==mu_S
    return S,mu_S,dict(split),indices


def fixed_anchor(stage,frozen,direction,config,partition,triples,model,old):
    _,_,T,U,mu,middle_bin,small_bin,right_ref,owners,_=config
    parents,joint,z_mu=partition
    a=frozen['selected_anchor']
    if direction=='right':
        known=a['u']
        r=owners[known].index(old.box(a['U_subbox']))
        anchor=known,r,tuple(a['full_y_middle_mask'])
        assert right_ref[anchor]==F(a['right_reference_mass'])
        M,D=F(a['central_bin']),small_bin[known]
        m_known=F(U[known]['m'])
    else:
        anchor=tuple(a['x'])
        known=anchor[1]
        M,D=middle_bin[known],F(a['small_bin'])
        m_known=F(T[known]['m'])
    rows={}
    for f in frozen['actual_price_rows']:
        z=f['z_id']
        Z=old.box(f['z_actual_box'])
        assert F(f['z_pattern_true_mu'])==z_mu[z] and z not in rows
        H,Ht,ref_left,ref_right=triples.same_z_edges(stage,config,M,D,Z,model,old)
        if direction=='left':
            assert ref_left[anchor]==F(a['left_reference_mass'])
        parent,density,p_z,_,lost,gap,closures=triples.genuine_completion(direction,anchor,H,Ht,ref_left,ref_right)
        assert density==F(f['true_z_density']) and parent=={int(k):F(v) for k,v in f['posterior'].items()}
        assert density*z_mu[z]==F(f['unscaled_weight'])
        assert total(p_z.values())+lost==1 and lost==0
        rho=F(f['true_z_probability'])
        assert rho==density*z_mu[z]/F(a['unscaled_true_price_mass'])
        rows[z]=dict(z_id=z,representative_Z=Z,mu_Z=z_mu[z],rho=rho,p_z=p_z,
                     original_fraction_without_completion=lost,original_fraction_without_distinct_encoded_marks=gap)
    assert total(r['rho'] for r in rows.values())==1
    pbar=defaultdict(F)
    for r in rows.values():
        for I,p in r['p_z'].items():
            pbar[I]+=r['rho']*p
    assert total(pbar.values())==1
    b=triples.square_budget(pbar,direction,T,U)
    infos=[]
    true_geom_joint=defaultdict(F)
    true_two_by_labels, geom_inverse_by_labels=defaultdict(F),defaultdict(F)
    correct_same=geom_same=F(0)
    K_reverse, K_conditional=F(0),F(0)
    for I,pI in sorted(pbar.items()):
        S,mu_S,physical,indices=full_intersection(I,direction,known,T,U,partition,model,mu)
        q=mu_S/m_known
        B=b[I]*q
        assert 0<q<=1 and B>0
        present={z:r['rho']*r['p_z'][I] for z,r in rows.items() if I in r['p_z']}
        true_law={z:w/pI for z,w in present.items()}
        geometry={z:w/mu_S for z,w in physical.items()}
        assert total(true_law.values())==1 and total(geometry.values())==1
        for z,w in present.items():
            assert physical[z]==z_mu[z] and true_law[z]==geometry[z]*(rows[z]['rho']/z_mu[z])*rows[z]['p_z'][I]*mu_S/pI
            true_geom_joint[z]+=w
        leakage=total(w for z,w in geometry.items() if z not in true_law)
        tv=total(abs(true_law.get(z,0)-geometry.get(z,0)) for z in true_law.keys()|geometry.keys())/2
        assert 0<=leakage<=tv<=1
        geom_tight=max(true_law[z]/geometry[z] for z in true_law)
        inverse_ratio=q/pI
        K_reverse=max(K_reverse,inverse_ratio)
        K_conditional=max(K_conditional,geom_tight)
        for z,w in present.items():
            for zz,v in present.items():
                true_two_by_labels[z,zz]+=w*v/pI
                geom_inverse_by_labels[z,zz]+=w*v/q
        same_I=total(w*w for w in true_law.values())
        correct_same+=pI*same_I
        geom_same+=pI*total(w*w for w in geometry.values())
        infos.append(dict(I=I,physical_parent_ids=indices,true_S=S,mu_S=mu_S,q_I=q,b_I=b[I],B_I=B,p_bar=pI,
            inverse_p_bar_relative_to_inverse_q=inverse_ratio,actual_p_bar_over_B=pI/B,
            true_z_given_I=true_law,geometric_mu_given_S_by_price_atom=geometry,
            true_price_given_I_vs_geometry_TV=tv,geometric_probability_outside_true_given_I_price_support=leakage,
            smallest_per_I_true_price_density_multiple_of_geometric=geom_tight,true_same_atom_given_I=same_I))
    assert true_geom_joint=={z:r['rho'] for z,r in rows.items()}
    true_two_by_prices,geom_inverse_by_prices={},{}
    q_by_I={x['I']:x['q_I'] for x in infos}
    K_price_only=F(0)
    for z,zz in product(rows,repeat=2):
        Z,ZZ=rows[z],rows[zz]
        common=Z['p_z'].keys()&ZZ['p_z'].keys()
        scale=Z['rho']*ZZ['rho']
        D0=scale*total(Z['p_z'][I]*ZZ['p_z'][I]/pbar[I] for I in common)
        D1=scale*total(Z['p_z'][I]*ZZ['p_z'][I]/q_by_I[I] for I in common)
        assert true_two_by_labels[z,zz]==D0 and geom_inverse_by_labels[z,zz]==D1
        assert 0<=D0<=K_reverse*D1
        if D1:
            K_price_only=max(K_price_only,D0/D1)
        true_two_by_prices[z,zz]=D0
        geom_inverse_by_prices[z,zz]=D1
    assert total(true_two_by_prices.values())==1
    for z,r in rows.items():
        assert total(true_two_by_prices[z,zz] for zz in rows)==r['rho']
        assert total(true_two_by_prices[zz,z] for zz in rows)==r['rho']
    assert correct_same==total(true_two_by_prices[z,z] for z in rows)
    same_geom_denominator=total(geom_inverse_by_prices[z,z] for z in rows)
    exact_diag_ratio=correct_same/same_geom_denominator
    assert exact_diag_ratio<=K_price_only<=K_reverse
    assert geom_same<=1 and geom_same>0
    assert total(geom_inverse_by_prices.values())==total(info['p_bar']**2/info['q_I'] for info in infos)

    coeff_B=max(info['actual_p_bar_over_B'] for info in infos)
    total_b=total(x['b_I'] for x in infos)
    total_B=total(x['B_I'] for x in infos)
    measured_square=total(info['p_bar']**2/info['b_I'] for info in infos)
    cutoff=[]
    for threshold in (F(1,16),F(1,8),F(1,4),F(1,2),F(3,4)):
        thin=[x for x in infos if x['q_I']<=threshold]
        n_thin=len(thin)
        p_thin=total(x['p_bar'] for x in thin)
        B_thin=total(x['B_I'] for x in thin)
        b_thin=total(x['b_I'] for x in thin)
        assert B_thin<=threshold*b_thin and p_thin<=coeff_B*B_thin
        assert p_thin**2<=measured_square*b_thin
        cutoff.append(dict(diagnostic_q_threshold=threshold,thin_triples=n_thin,retained_triples=len(infos)-n_thin,
            retained_triple_fraction=F(len(infos)-n_thin,len(infos)),thin_probability=p_thin,retained_probability=1-p_thin,
            thin_B_sum=B_thin,thin_b_sum=b_thin,thin_probability_bound_from_B=coeff_B*B_thin,
            thin_probability_squared_bound_from_b=measured_square*b_thin))
    normalized_B_cutoffs=[]
    for eps in (F(1,16),F(1,4),F(1)):
        coefficient=eps/total_B
        thin=[x for x in infos if x['p_bar']<coefficient*x['B_I']]
        predicted=coefficient*total(x['B_I'] for x in thin)
        actual=total(x['p_bar'] for x in thin)
        assert actual<=predicted<=eps
        normalized_B_cutoffs.append(dict(epsilon=eps,thin=len(thin),retained=len(infos)-len(thin),
            true_probability=actual,geometric_comparison_mass=predicted))
    for r in rows.values():
        r['p_z']=[dict(I=I,p=prob) for I,prob in sorted(r['p_z'].items())]
    return dict(direction=direction,known_physical_parent=known,known_parent_mu=m_known,central_bin=M,small_bin=D,
        fixed_anchor=a,all_positive_true_price_atoms=list(rows.values()),by_I=infos,
        probability_sum=total(pbar.values()),total_b_over_actual_positive_I=total_b,total_B_over_actual_positive_I=total_B,
        full_intersection_diagnostic_cutoffs=cutoff,
        low_p_bar_vs_normalized_B_diagnostic_cutoffs=normalized_B_cutoffs,
        smallest_global_p_bar_multiple_of_B=coeff_B,tight_inverse_frequency_replacement_with_shared_I=K_reverse,
        tight_inverse_frequency_replacement_ignoring_I=K_price_only,
        actual_same_price_atom_probability=correct_same,actual_different_price_atom_probability=1-correct_same,
        geometric_redraw_same_price_atom_probability=geom_same,
        same_price_atom_inverse_using_q_unnormalized=same_geom_denominator,
        exact_same_atom_aggregate_inverse_comparison_factor=exact_diag_ratio,
        all_price_pair_inverse_using_q_unnormalized=total(geom_inverse_by_prices.values()),
        tight_global_true_z_given_I_density_multiple_of_geometry=K_conditional,
        p_bar_weighted_geometry_leakage_outside_true_given_I_support=total(info['p_bar']*info['geometric_probability_outside_true_given_I_price_support'] for info in infos),
        p_bar_weighted_true_vs_geometric_price_TV=total(info['p_bar']*info['true_price_given_I_vs_geometry_TV'] for info in infos))


def main():
    # Derived exact fractions may exceed the default decimal conversion limit.
    sys.set_int_max_str_digits(0)
    here=Path(__file__).resolve().parent
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--r805-dir',type=Path,default=here)
    p.add_argument('--r806-dir',type=Path,default=here)
    group=p.add_mutually_exclusive_group()
    group.add_argument('--output',type=Path)
    group.add_argument('--check',type=Path)
    args=p.parse_args()
    r5,r6=args.r805_dir.resolve(),args.r806_dir.resolve()
    for name,digest in DEPENDENCIES.items():
        if name=='reverse805.json':
            continue
        assert sha256(((r5 if '805' in name else r6)/name).read_bytes()).hexdigest()==digest
    sys.path[:0]=[str(r6),str(r5)]
    import triples806 as triples
    import reverse805 as model
    import shared805 as old
    rp=r5/'reverse805.json'
    rp_bytes=rp.read_bytes() if rp.is_file() else subprocess.check_output([sys.executable,'-B',str(r5/'reverse805.py')])
    assert sha256(rp_bytes).hexdigest()==DEPENDENCIES['reverse805.json']
    raw=json.loads(rp_bytes)
    frozen=json.loads((r6/'profile806.json').read_text())
    reports=[]
    for s,proof in zip(raw['stages'],frozen['stages'],strict=True):
        assert s['stage']==proof['stage']
        config=triples.genuine_config(s,model,old)
        partition=physical_price_partition(s,config,model,old)
        applications=[fixed_anchor(s,proof[tag],side,config,partition,triples,model,old) for tag,side in
                (('right_fixed_middle_posterior','right'),('left_fixed_small_posterior','left'))]
        reports.append(dict(stage=s['stage'],dimension=s['n'],physical_parent_price_joint_atoms=len(partition[1]),
                            entire_fixture_price_atom_count=len(partition[2]),applications=applications))
    assert sum(len(a['all_positive_true_price_atoms']) for s in reports for a in s['applications'])==69
    assert any(a['p_bar_weighted_true_vs_geometric_price_TV']>0 for s in reports for a in s['applications'])
    data=dict(runtime=dict(python=platform.python_version(),architecture=platform.machine(),arithmetic='exact Fraction'),
              dependencies=DEPENDENCIES,reproduction='python -B overlap807.py --check overlap807.json',stages=reports,
              scope=dict(anchors='Frozen six R806 anchors. All their 69 positive price atoms, not just their representative boxes, and no new anchor optimization. Original 1/2/3-dimensional masks, full degrees and true completions.',
                  physical='Known small u for a fixed true right mark, known middle t for a fixed true left mark. S_I is the four-fold intersection of physical cubes. q_I=mu(S_I)/mu(A_known), B_I=b_I q_I with all three ordered b_i=j_i/m_i factors.',
                  redraw='Two true prices use the shared I and independent given-I conditional laws. At each z compare to a separate true geometric source draw mu restricted to S_I, using the full disjoint price partition and the physical membership refinement.',
                  inverse='Keep the same numerator rho(z)rho(z_prime)p_z(I)p_z_prime(I) and replace p_bar(I) by q_I only in the denominator. The label-aware tight multiple is max_I q_I/p_bar(I), and label-blind/event-specific sharp ratios are independently evaluated.',
                  thresholds='Finite diagnostic q cutoffs. Actual selected probability, b and B masses, Cauchy bound and retained combination fraction are reported. Separately test p_bar below epsilon times B divided by total B. No high-dimensional threshold or bound is inferred.'))
    text=json.dumps(data,sort_keys=True,indent=2,default=str)+'\n'
    if args.output:
        args.output.write_text(text)
    if args.check:
        assert args.check.read_text()==text
    if args.output or args.check:
        for s in reports:
            for a in s['applications']:
                print(s['stage'],a['direction'],len(a['all_positive_true_price_atoms']),len(a['by_I']),
                    'TV',format(float(a['p_bar_weighted_true_vs_geometric_price_TV']),'.9g'),
                    'inverse K',format(float(a['tight_inverse_frequency_replacement_with_shared_I']),'.9g'),
                    'same atom',format(float(a['actual_same_price_atom_probability']),'.9g'))
        if args.check:
            print('byte-identical')
    else:
        print(text,end='')


if __name__=='__main__':
    main()
