#!/usr/bin/env python3
"""Integrate the four receiver tent factors against the true continuous striped source."""
import argparse
from fractions import Fraction as F
from functools import lru_cache
from itertools import product
import json
from math import ceil, floor, prod
from pathlib import Path
import sys


def tent(x, c, b):
    return max(F(0), 1-abs(x-c)/b)


@lru_cache(maxsize=None)
def factor(points, widths, amp, support, half):
    lo=max([-support]+[p-b for p,b in zip(points,widths)])
    hi=min([support]+[p+b for p,b in zip(points,widths)])
    if lo>=hi:
        return F(0)
    cuts={lo,hi}
    cuts.update(x for x in points if lo<x<hi)
    if amp:
        cuts.update(k*half for k in range(floor(lo/half)+1,ceil(hi/half)))
    cuts=sorted(cuts)
    val=F(0)
    for a,b in zip(cuts,cuts[1:]):
        mid=(a+b)/2
        density=1+amp*(1 if floor(mid/half)%2==0 else -1)
        coeff=[F(1)]
        for p,w in zip(points,widths):
            slope=F(1 if mid<p else -1)/w
            const=tent(a,p,w)
            new=[F(0)]*(len(coeff)+1)
            for j,t in enumerate(coeff):
                new[j]+=const*t
                new[j+1]+=slope*t
            coeff=new
        by_coeff=sum(c*(b-a)**(j+1)/(j+1) for j,c in enumerate(coeff))
        by_boole=(b-a)*sum(zz*prod(tent(a+i*(b-a)/4,p,w) for p,w in zip(points,widths))
                            for i,zz in enumerate((7,32,12,32,7)))/90
        assert by_coeff==by_boole>=0
        val+=density*by_coeff
    return val


def solve(stage,anchor,model,old):
    dim=stage['n']
    parents=stage['middle_cubes']+stage['small_cubes']
    boxes=[old.box(p['A']) for p in parents]
    nt=len(stage['middle_cubes'])
    M,D=F(anchor['central_bin']),F(anchor['small_bin'])
    h0=1+F(1,32*dim)
    bins=(M,M,D,D)
    rows=[]
    for row in anchor['by_I']:
        i,j,k=row['I']
        known=anchor['known_physical_parent']
        I=(i,j,nt+known,nt+k) if anchor['direction']=='right' else (known,k,nt+i,nt+j)
        e=sum(F(a['mu_Z']) for a in anchor['all_positive_true_price_atoms']
              if str(a['z_id']) in row['true_z_given_I'])
        rows.append((I,e,F(row['mu_S']),prod(F(parents[t]['j'])/F(parents[t]['m']) for t in I)))
    widths=tuple(2*h0*max(F(parents[I[j]]['s']) for I,*_ in rows) for j in range(4))
    geom_const=prod(w**dim/bin_size for w,bin_size in zip(widths,bins))
    etaD=max(m for _,m,_,_ in rows)
    cases=set()
    for I,*_ in rows:
        for pattern in (0,1,2):
            def probe(i,j):
                box=boxes[i]
                if pattern==0:
                    return tuple((a+b)/2 for a,b in box)
                return tuple(a+(b-a)*(F(1,8) if (j+d+pattern)%2 else F(7,8))
                             for d,(a,b) in enumerate(box))
            cases.add(tuple(probe(i,j) for j,i in enumerate(I)))
    raw,weighted=[],[]
    cutoff_counts=[0,0,0]
    for H in sorted(cases):
        P=tuple(tuple(p[d] for p in H) for d in range(dim))
        K=prod(factor(v,widths,F(stage['true_source_amplitude']) if d==0 else F(0),
                      model.SUPPORT,model.HALF_PERIOD) for d,v in enumerate(P))
        eligible=[(I,e,m,b) for I,e,m,b in rows if
                  all(all(a<=p[d]<=bb for d,(a,bb) in enumerate(boxes[i])) for i,p in zip(I,H))]
        lhs=sum(b*e for _,e,_,b in eligible)
        lhs4=sum(b*m for _,_,m,b in eligible)
        assert 0 < lhs <= lhs4 <= geom_const*K and lhs<=geom_const*etaD
        ratios=K/etaD
        raw.append(ratios)
        weighted.append(lhs4/(geom_const*K))
        for i,x in enumerate((F(1),F(1,2),F(1,4))):
            cutoff_counts[i]+=ratios<x
    return dict(stage=stage['stage'],side=anchor['direction'],dimension=dim,
                distinct_true_probes=len(cases),kernel_relative_to_largest_observed_e_range=[min(raw),max(raw)],
                fractions_below_1_half_quarter=cutoff_counts,largest_actual_sum_over_cube_bound=max(weighted))


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--data',required=True,type=Path)
    ap.add_argument('--overlap',required=True,type=Path)
    g=ap.add_mutually_exclusive_group(required=True)
    g.add_argument('--output',type=Path)
    g.add_argument('--check',type=Path)
    args=ap.parse_args()
    sys.path.insert(0,str(args.data.resolve()))
    import reverse805 as model
    import shared805 as old
    raw=json.loads((args.data/'reverse805.json').read_text())
    src=json.loads(args.overlap.read_text())
    records=[]
    for stage, ref in zip(raw['stages'],src['stages'],strict=True):
        assert stage['stage']==ref['stage']
        for a in ref['applications']:
            records.append(solve(stage,a,model,old))
    ret=json.dumps(dict(scope='Exact full parent cube tent capacity at three prescribed four-point choices per positive ordered tuple (duplicates merged). Fractions and closed Boole quadrature for quartics. Window cutoff eta D in these diagnostics is the largest observed exact positive price support e in the frozen anchor.',records=records),sort_keys=True,indent=2,default=str)+'\n'
    if args.output:
        args.output.write_text(ret)
    if args.check:
        assert args.check.read_text()==ret
    for x in records:
        print(x['stage'],x['side'],x['distinct_true_probes'],x['fractions_below_1_half_quarter'],
              'kernel range',*[format(float(v),'.5g') for v in x['kernel_relative_to_largest_observed_e_range']])


if __name__=='__main__':
    main()
