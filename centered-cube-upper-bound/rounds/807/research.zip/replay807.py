#!/usr/bin/env python3
"""Recreate R807 exact outputs from its six scripts and the immutable R806 input archive."""
import argparse
from hashlib import sha256
import json
from pathlib import Path
import shutil
import subprocess
import sys
from zipfile import ZipFile


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--base',required=True,type=Path,help='R806 research.zip, see MANIFEST')
    ap.add_argument('--work',required=True,type=Path,help='a new directory for derived files')
    args=ap.parse_args()
    here=Path(__file__).resolve().parent
    base=args.base.resolve()
    work=args.work.resolve()
    manifest=json.loads((here/'MANIFEST.json').read_text())
    if digest(base)!=manifest['base_archive_sha256']:
        raise ValueError('unexpected R806 archive')
    for name,sha in manifest['archived_sha256'].items():
        if digest(here/name)!=sha:
            raise ValueError('archive member mismatch: '+name)
    work.mkdir(parents=True,exist_ok=False)
    with ZipFile(base) as z:
        parent=json.loads(z.read('MANIFEST.json'))
        for name in ('rectangle806.py','profile806.json','triples806.py','reverse805.py','shared805.py'):
            data=z.read(name)
            if sha256(data).hexdigest()!=parent['files'][name]['sha256']:
                raise ValueError('upstream payload mismatch: '+name)
            (work/name).write_bytes(data)
    for name in manifest['archived_sha256']:
        if name.endswith('.py') and name!='replay807.py':
            shutil.copyfile(here/name,work/name)
    interp=[sys.executable,'-B']
    reverse=subprocess.check_output(interp+['reverse805.py'],cwd=work)
    if sha256(reverse).hexdigest()!='955de184b852e78a2913ca9e1865404afa746c0425a920c3aa80bf9896dad886':
        raise ValueError('reverse805 fixture mismatch')
    (work/'reverse805.json').write_bytes(reverse)
    for command in manifest['runs']:
        subprocess.run(interp+command,cwd=work,check=True)
    for name,sha in manifest['generated_sha256'].items():
        if digest(work/name)!=sha:
            raise ValueError('recomputed result differs: '+name)
        print('SHA256',sha,name)
    print('All source, upstream and six output digests verified.')


if __name__=='__main__':
    main()
