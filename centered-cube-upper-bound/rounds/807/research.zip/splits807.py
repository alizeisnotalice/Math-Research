#!/usr/bin/env python3
"""Six exact physical-base splits and the observed same-price support."""
import argparse
from fractions import Fraction as F
from hashlib import sha256
from itertools import combinations
import json
from pathlib import Path
import platform
import subprocess
import sys


DEPENDENCIES = {
    'overlap807.json': '640fdb9b1ef00eb9372d6caaedea5b13ae20d1930508ba0312c039c5ffacbc6b',
    'reverse805.py': 'c9a810c2807fa592e0fc76c514738522d8414d2e01c548579856e64d8b7fb17e',
    'reverse805.json': '955de184b852e78a2913ca9e1865404afa746c0425a920c3aa80bf9896dad886',
}
BASE_PAIRS = tuple(combinations(range(4),2))


def total(x):
    return sum(x,F(0))


def as_box(B):
    return tuple(tuple(map(F,axis)) for axis in B)


def pair_sources(application,stage,model):
    T,U=stage['middle_cubes'],stage['small_cubes']
    amp=F(stage['true_source_amplitude'])
    physical={('t',i):as_box(x['A']) for i,x in enumerate(T)}
    physical.update({('u',i):as_box(x['A']) for i,x in enumerate(U)})
    price_mu={str(r['z_id']):F(r['mu_Z']) for r in application['all_positive_true_price_atoms']}
    observed={}
    for z in application['all_positive_true_price_atoms']:
        name=str(z['z_id'])
        rho=F(z['rho'])
        assert rho>0
        for row in z['p_z']:
            I=tuple(row['I'])
            p=F(row['p'])
            assert p>0 and name not in observed.setdefault(I,{})
            observed[I][name]=rho*p
    known=application['known_physical_parent']
    forward=application['direction']=='right'
    entries=[]
    for f in application['by_I']:
        I=tuple(f['I'])
        i,j,k=I
        slots=(('u',known),('t',i),('t',j),('u',k)) if forward else (('t',known),('u',i),('u',j),('t',k))
        boxes=[physical[mark] for mark in slots]

        def mass(indices):
            Q=boxes[indices[0]]
            for p in indices[1:]:
                Q=model.clip(Q,boxes[p])
            direct=model.source_mass(Q,amp)
            assert direct==model.source_mass(Q,amp,decompose=True)
            return direct

        m4=mass(tuple(range(4)))
        pbar=F(f['p_bar'])
        true_label_prices=observed[I]
        assert total(true_label_prices.values())==pbar
        assert {z:w/pbar for z,w in true_label_prices.items()}=={z:F(w) for z,w in f['true_z_given_I'].items()}
        e=total(price_mu[z] for z in true_label_prices)
        geometry={z:F(w) for z,w in f['geometric_mu_given_S_by_price_atom'].items()}
        assert m4==F(f['mu_S']) and 0<e<=m4
        assert e/m4==total(geometry[z] for z in true_label_prices)
        splits=[]
        for a,b in BASE_PAIRS:
            c,d=(v for v in range(4) if v not in (a,b))
            m2,m3c,m3d=mass((a,b)),mass((a,b,c)),mass((a,b,d))
            assert 0<m4<=min(m3c,m3d)<=max(m3c,m3d)<=m2
            independent_product=m3c*m3d/m2
            splits.append(dict(base=(a,b),remaining=(c,d),m_ij=m2,m_ijk=m3c,m_ijl=m3d,
                               c_ij=independent_product,c_ij_over_e=independent_product/e,c_ij_over_m4=independent_product/m4))
        largest=max(s['c_ij'] for s in splits)
        assert largest/e==(largest/m4)*(m4/e)
        entries.append(dict(I=I,ordered_physical_slots=slots,distinct_physical_count=len(set(slots)),
            p_bar=pbar,true_price_support_ids=sorted(map(int,true_label_prices)),e=e,m4=m4,e_over_m4=e/m4,
            six=splits,max_c=largest,max_c_over_e=largest/e,max_c_over_m4=largest/m4))
    assert total(x['p_bar'] for x in entries)==1
    anchor=application['fixed_anchor']
    ref_weight=F(anchor['right_reference_mass'] if forward else anchor['left_reference_mass'])
    mass=ref_weight*F(anchor['unscaled_true_price_mass'])
    return entries,mass


def cutoffs(entries):
    total_mass=total(x['p_bar'] for x in entries)
    results=[]
    for H in (F(1),F(11,10),F(2)):
        above=[x for x in entries if x['max_c_over_e']>H]
        equal=[x for x in entries if x['max_c_over_e']==H]
        geom=[x for x in above if x['max_c_over_m4']>H]
        only_support=[x for x in above if x['max_c_over_m4']<=H]
        p,p_equal=total(x['p_bar'] for x in above),total(x['p_bar'] for x in equal)
        from_geometry=total(x['p_bar'] for x in geom)
        from_support=total(x['p_bar'] for x in only_support)
        assert p==from_geometry+from_support and 0<=p+p_equal<=total_mass
        results.append(dict(H=H,number_strict=len(above),number_equal=len(equal),number_at_least=len(above)+len(equal),
            strict_weight=p,equality_weight=p_equal,at_least_weight=p+p_equal,
            strict_weight_with_pure_geometry_over_H=from_geometry,
            strict_weight_requiring_loss_of_actual_price_support=from_support))
    return results


def develop(stage,case,model):
    entries,actual_anchor_flow=pair_sources(case,stage,model)
    all_distinct=[x for x in entries if x['distinct_physical_count']==4]
    best=max(entries,key=lambda x:x['max_c_over_e'])
    witness={k:best[k] for k in ('I','e','m4','p_bar','max_c','max_c_over_e','max_c_over_m4')}
    return dict(direction=case['direction'],known_physical_parent=case['known_physical_parent'],
        central_bin=case['central_bin'],small_bin=case['small_bin'],anchor_original_flow=actual_anchor_flow,
        actual_triple_count=len(entries),with_four_distinct_physical_slots=len(all_distinct),
        weight_with_four_distinct_physical_slots=total(x['p_bar'] for x in all_distinct),
        range_all_splits_c_over_e=[min(s['c_ij_over_e'] for x in entries for s in x['six']),
                                   max(s['c_ij_over_e'] for x in entries for s in x['six'])],
        range_max_c_over_e=[min(x['max_c_over_e'] for x in entries),best['max_c_over_e']],
        range_max_c_over_m4=[min(x['max_c_over_m4'] for x in entries),max(x['max_c_over_m4'] for x in entries)],
        max_gain_witness=witness,all_actual_cutoffs=cutoffs(entries),
        four_distinct_cutoffs_as_mass_of_unchanged_anchor=cutoffs(all_distinct),
        entries=[{k:v for k,v in x.items() if k!='p_bar'} for x in entries])


def main():
    # These are derived exact fractions, whose decimal strings may be long.
    sys.set_int_max_str_digits(0)
    here=Path(__file__).resolve().parent
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--r805-dir',type=Path,default=here)
    group=p.add_mutually_exclusive_group()
    group.add_argument('--output',type=Path)
    group.add_argument('--check',type=Path)
    args=p.parse_args()
    r5=args.r805_dir.resolve()
    old=(here/'overlap807.json').read_bytes()
    assert sha256(old).hexdigest()==DEPENDENCIES['overlap807.json']
    script=r5/'reverse805.py'
    assert sha256(script.read_bytes()).hexdigest()==DEPENDENCIES['reverse805.py']
    sys.path.insert(0,str(r5))
    import reverse805 as model
    fixture=script.with_suffix('.json')
    raw=fixture.read_bytes() if fixture.is_file() else subprocess.check_output([sys.executable,'-B',str(script)])
    assert sha256(raw).hexdigest()==DEPENDENCIES['reverse805.json']
    stages=[]
    for stage,observed in zip(json.loads(raw)['stages'],json.loads(old)['stages'],strict=True):
        assert stage['stage']==observed['stage']
        applications=[develop(stage,x,model) for x in observed['applications']]
        stages.append(dict(stage=stage['stage'],dimension=stage['n'],applications=applications))
    assert len(stages)==3 and all(len(s['applications'])==2 for s in stages)
    assert all(a['range_max_c_over_m4'][1]<2 for s in stages for a in s['applications'])
    assert any(a['all_actual_cutoffs'][-1]['strict_weight_requiring_loss_of_actual_price_support']>0
               for s in stages for a in s['applications'])
    out=dict(runtime=dict(python=platform.python_version(),architecture=platform.machine(),arithmetic='Fraction exact'),
        dependencies=DEPENDENCIES,reproduction='python -B splits807.py --check splits807.json',stages=stages,
        scope=dict(witness='Six frozen original anchors with the actual shared-I completed path table saved by overlap807. No further selection of anchors.',
             sets='All m_ij, m_ijk, m_ijl and m4 use actual physical A cubes with the same given absolutely continuous nonuniform mu. This is the finite G_i=A_i choice for the split calculation. It retains the original external y pockets and path gates in the true path weights.',
             observed='e is the mu-mass of all disjoint true price atoms on which p_z(I)>0, after the original and rectangle gates. It is computed from actual stored positive paths and cross-checked by the four-cube geometric price law. Four slot labels may repeat.',
             weights='Thresholds are exact. Each normalized weight uses the original conditional p_bar on its anchor. The actual anchor flow is recorded once. Multiplying it by a cutoff weight gives the corresponding unnormalized original flow. Full per-label weights are indexed by I in the frozen overlap table. Anchor weights are never added across fixtures or directions.',
             limits='True source and owner geometry in finite dimensions, with diagnostic masks. Neither the split mass observed here nor its empirical ratios are asserted for the full high-dimensional theorem.'))
    text=json.dumps(out,sort_keys=True,indent=2,default=str)+'\n'
    if args.output:
        args.output.write_text(text)
    if args.check:
        assert args.check.read_text()==text
    if args.output or args.check:
        for s in stages:
            for a in s['applications']:
                print(s['stage'],a['direction'],'range max c/e',*[str(x) for x in a['range_max_c_over_e']],
                     'at thresholds strict weight displays',*[format(float(x['strict_weight']),'.10g') for x in a['all_actual_cutoffs']])
        if args.check:
            print('byte-identical')
    else:
        print(text,end='')


if __name__=='__main__':
    main()
