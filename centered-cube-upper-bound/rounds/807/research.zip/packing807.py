#!/usr/bin/env python3
"""Exact source occupation, three fresh probes and two-root capture in six frozen anchors."""
import argparse
from collections import defaultdict
from fractions import Fraction as F
from functools import reduce
from itertools import product
import json
from math import prod
from operator import and_
from pathlib import Path
import platform
import sys


def source_partition(boxes, mass):
    axes = []
    for d in range(len(boxes[0])):
        cuts = sorted({v for box in boxes for v in box[d]})
        axis = []
        for a, b in zip(cuts, cuts[1:]):
            mask = sum(1 << i for i, box in enumerate(boxes) if box[d][0] <= a < b <= box[d][1])
            if mask:
                axis.append((mask, mass(((a, b),)) if d == 0 else b - a))
        axes.append(axis)
    cells = defaultdict(F)
    for cell in product(*axes):
        mask = reduce(and_, (item[0] for item in cell))
        if mask:
            cells[mask] += prod(item[1] for item in cell)
    return cells


def normalized_root(stage, anchor, kind, inside_mass, old):
    parents = stage['middle_cubes'] + stage['small_cubes']
    nt = len(stage['middle_cubes'])
    boxes = [old.box(i[kind]) for i in parents]
    cells = source_partition(boxes, inside_mass)
    m = [inside_mass(box) for box in boxes]
    for i, v in enumerate(m):
        assert sum(w for mask, w in cells.items() if mask >> i & 1) == v > 0
    ids, weights = [], []
    for row in anchor['by_I']:
        i, j, k = row['I']
        a = anchor['known_physical_parent']
        if anchor['direction'] == 'right':
            ids.append((i, j, nt+a, nt+k))
        else:
            ids.append((a, k, nt+i, nt+j))
        weights.append(F(row['p_bar']))
    assert sum(weights) == 1 and len(set(ids)) == len(ids)
    b = [F(p['j']) / F(p['m']) for p in parents]
    cap_mix = max(w/prod(b[i] for i in I) for I, w in zip(ids, weights))
    slots = []
    for j in range(4):
        rows = defaultdict(F)
        for pmask, weight in cells.items():
            bits = sum(1 << k for k, I in enumerate(ids) if pmask >> I[j] & 1)
            if bits:
                rows[bits] += weight
        slots.append(rows)
    scales = [min(m[I[j]] for I in ids) for j in range(4)]
    slot_bessel = []
    for j in range(4):
        labels = set(I[j] for I in ids)
        slot_bessel.append(max(sum(b[i] for i in labels if mask >> i & 1) for mask in cells))
    tuple_b = [prod(b[i] for i in I) for I in ids]
    assert all(w <= cap_mix * z for w, z in zip(weights, tuple_b))
    index = range(len(ids))
    volumes = [prod(m[i] for i in I[1:]) for I in ids]
    def joint_volume(I, J):
        out = F(1)
        for i, j in zip(I[1:], J[1:]):
            out *= sum(w for mask, w in cells.items() if mask >> i & 1 and mask >> j & 1)
        return out
    ij = [[joint_volume(I, J) for J in ids] for I in ids]
    occupancy, pair_mass = F(0), F(0)
    diagnostics = []
    for active, base_volume in slots[0].items():
        rates = [weights[k] / m[I[0]] if active >> k & 1 else F(0) for k, I in enumerate(ids)]
        row = sum(rates)
        q = [a/row for a in rates]
        occupancy += row * base_volume
        tuple_density = [q[k]/volumes[k] for k in index]
        union, mass, capture = F(0), F(0), F(0)
        max_density, max_hit = F(0), F(0)
        terms = defaultdict(F)
        for bcells in product(slots[1].items(), slots[2].items(), slots[3].items()):
            bits = reduce(and_, (part[0] for part in bcells), active)
            if bits:
                terms[bits] += prod(part[1] for part in bcells)
        for bits, cell_vol in terms.items():
            labels = [k for k in index if bits >> k & 1]
            dens = sum(tuple_density[k] for k in labels)
            hit = sum(q[k] for k in labels)
            max_density, max_hit = max(max_density, dens), max(max_hit, hit)
            union += cell_vol
            mass += cell_vol*dens
            capture += cell_vol*dens*hit
        direct = sum(q[i]*q[j]*ij[i][j]/volumes[i] for i in index for j in index if q[i] and q[j])
        upper_density = cap_mix * prod(slot_bessel) / (row * prod(scales))
        upper_hit = cap_mix * prod(slot_bessel) / (row * scales[0])
        assert mass == 1 and direct == capture and capture <= max_hit <= min(F(1), upper_hit)
        assert 1 <= max_density * union and max_density <= upper_density
        pair_mass += row * base_volume * capture
        diagnostics.append(dict(reachable_triple_mass=union, occupation_density=row,
                                true_peak_density=max_density, sup_times_reachable_volume=max_density*union,
                                per_point_capture=max_hit, two_root_capture=capture,
                                common_base_mass=base_volume))
    assert occupancy == 1 and 0 < pair_mass <= 1
    return dict(stage=stage['stage'], dimension=stage['n'], direction=anchor['direction'], auxiliary_source=kind,
                support_rows=len(diagnostics), ordered_quads=len(ids), true_original_total=occupancy,
                integrated_pair_capture=pair_mass, rows=diagnostics)


def main():
    sys.set_int_max_str_digits(0)
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--data',type=Path,required=True,help='Folder containing reverse805.py, shared805.py and reverse805.json')
    ap.add_argument('--overlap',type=Path,required=True)
    group=ap.add_mutually_exclusive_group(required=True)
    group.add_argument('--output',type=Path)
    group.add_argument('--check',type=Path)
    args=ap.parse_args()
    sys.path.insert(0,str(args.data.resolve()))
    import reverse805 as model
    import shared805 as old
    fixtures=json.loads((args.data/'reverse805.json').read_text())
    frozen=json.loads(args.overlap.read_text())
    reports=[]
    for stage, both in zip(fixtures['stages'],frozen['stages'],strict=True):
        assert stage['stage']==both['stage']
        def mass(box):
            return model.source_mass(box,F(stage['true_source_amplitude']))
        for anchor in both['applications']:
            for kind in ('A','G'):
                reports.append(normalized_root(stage,anchor,kind,mass,old))
    result=dict(python=platform.python_version(),architecture=platform.machine(),arithmetic='exact Fraction',
                scope='Original six finite marked-anchor weights and primitive atomless source. All three additional source probes are fresh. Both full cubes A and stored source pockets G are tested. Finite pocket sizes and gates differ from the asymptotic hypotheses.',reports=reports)
    payload=json.dumps(result,indent=2,sort_keys=True,default=str)+'\n'
    if args.output:
        args.output.write_text(payload)
    else:
        assert args.check.read_text()==payload
    for rec in reports:
        print(rec['stage'],rec['direction'],rec['auxiliary_source'],rec['support_rows'],
              'pair capture',format(float(rec['integrated_pair_capture']),'.10g'))
    if args.check:
        print('byte-identical')


if __name__=='__main__':
    main()
