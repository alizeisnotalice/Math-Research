#!/usr/bin/env python3
"""Symbolic homogeneities and directed finite log-budget checks."""
import argparse
import json
from pathlib import Path
import platform
import sympy as sp
import flint
from flint import arb, ctx


def symbolic():
    k = sp.symbols('k', positive=True, integer=True)
    p = k/(k-1)
    identities = [k*(1-1/p)-1, 1-k+k/p, (p-1)*k/p-1]
    assert all(sp.cancel(v)==0 for v in identities)
    M,D=sp.symbols('M D', positive=True)
    assert sp.cancel((D/M)/(M*D**2)-1/(M**2*D))==0
    return ['k(1-1/p)=1','1-k+k/p=0','(p-1)k/p=1','(D/M)/(MD^2)=1/(M^2D)']


def bounds():
    ctx.prec=512
    result=[]
    for j in (16,32,64,128,256,512,2048,8192):
        n=arb(2)**j
        N=n+2
        ell=N.log()
        L=n.sqrt()*ell**3
        P=N*ell**6
        H=4*(1+n.sqrt()/ell**2)
        tau=min(arb(1)/4,L/(H*N))
        kap=min(arb(1)/16,(L/(16*H*N))**3)
        B=1/(kap*tau**2)
        d0=P/(N**2*ell)
        rlo=n.sqrt()*ell**2
        slo=n.sqrt()*ell**8-arb(2).log()
        shi=(n+1)*arb(2).log()
        # Upper log of the two paper charges and tolerances. Enlarge the true
        # deletion-union and K^2 constants by a deliberate finite factor N^2.
        receiver=(B*H*N/(N**8*L)).log()
        source=(B*H*N**2*ell/(N**8*P)).log()
        lowrow=(B*H*ell*N**4).log()-rlo/512
        row=dict(j=j,receiver_fee_log_ratio=str(receiver),source_fee_log_ratio=str(source),
                 low_volume_superpolynomial_probe_log=str(lowrow),nonempty=bool(slo<shi),
                 receiver_and_source_negative=bool(receiver<0 and source<0))
        if slo<shi:
            interval=[]
            for s in (slo,(slo*shi).sqrt(),shi):
                Hpair=(N**2*B*H/d0).log()-(s+rlo/256)/2
                extra=Hpair+(s+rlo/256)/4
                assert extra<0
                interval.append(dict(log_upper_including_pair_union=str(Hpair),
                                     remaining_log_after_quarter_margin=str(extra)))
            row['pair_tests']=interval
        assert (slo<shi) or (shi<slo)
        result.append(row)
    return result


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    g=ap.add_mutually_exclusive_group(required=True)
    g.add_argument('--output',type=Path)
    g.add_argument('--check',type=Path)
    args=ap.parse_args()
    data=dict(python=platform.python_version(),sympy=sp.__version__,flint=flint.__version__,
              identities=symbolic(),arbitrary_constants_in_finite_test='C_0=4,C=C_2=1; further finite slack N^2 in pack bound',
              dimensions=bounds(),precision_bits=ctx.prec)
    out=json.dumps(data,sort_keys=True,indent=2)+'\n'
    if args.output:
        args.output.write_text(out)
    if args.check:
        assert args.check.read_text()==out
    print('sympy identities',len(data['identities']))
    for row in data['dimensions']:
        print(row['j'],'admissible nonempty',row['nonempty'],'two costs negative',row['receiver_and_source_negative'],
              'three pair checks',len(row.get('pair_tests',[])))


if __name__=='__main__':
    main()
