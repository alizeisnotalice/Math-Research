from fractions import Fraction as F
from decimal import Decimal as D, localcontext
from pathlib import Path
from bisect import bisect_right
import json

def density(K,u,pattern):
    width=F(1,K*u**4); events={F(0):F(0),F(1):F(0)}
    for j in range(K):
      jitter=(F(1,1000) if pattern==0 else (F(999 if j%2 else 1,1000) if pattern==1 else F((17*j+3)%37,37)))
      a=(F(j)+jitter)/K-width/2;b=a+width
      for shift in (-1,0,1):
       lo=max(F(0),a+shift);hi=min(F(1),b+shift)
       if lo<hi:
        events[lo]=events.get(lo,F(0))+1/(K*width);events[hi]=events.get(hi,F(0))-1/(K*width)
    nodes=sorted(events);vals=[];pr=[F(0)];cur=F(0)
    for i,x in enumerate(nodes[:-1]):
      cur+=events[x];vals.append(cur);pr.append(pr[-1]+cur*(nodes[i+1]-x))
    assert pr[-1]==1
    def primitive(x):
      z=x.numerator//x.denominator;r=x-z;i=bisect_right(nodes,r)-1
      return z+pr[i]+vals[i]*(r-nodes[i])
    return nodes,primitive

def bv_tests():
 out=[]
 for K in (64,128):
  for u in (2,4,8):
   for pat in (0,1,2):
    nodes,P=density(K,u,pat)
    for sign in (-1,1):
     L=F(35,32);gap=F(sign,K*u*u*16);J=L+gap
     cuts=sorted(set([F(0),F(1)]+[(x+s*r/2)%1 for x in nodes for s in (-1,1) for r in (L,J)]))
     def d(x,r):return ( (P(x+r/2)-P(x-r/2))/r-1)/4
     squares=F(0);absint=F(0);meanL=F(0);meanJ=F(0);sup=F(0)
     for lo,hi in zip(cuts,cuts[1:]):
      a=d(lo,J)-d(lo,L);b=d(hi,J)-d(hi,L);w=hi-lo
      squares+=w*(a*a+a*b+b*b)/3
      absint+=w*(abs(a)+abs(b))/2 if a*b>=0 else w*(a*a+b*b)/(2*(abs(a)+abs(b)))
      meanL+=w*(d(lo,L)+d(hi,L))/2;meanJ+=w*(d(lo,J)+d(hi,J))/2;sup=max(sup,abs(a),abs(b))
     assert meanL==meanJ==0 and squares<=4*abs(gap)/K and absint<=abs(gap) and sup<=F(7,2*K)
     out.append(dict(K=K,u=u,pattern=pat,sign=sign,segments=len(cuts)-1,L2_squared=str(squares),bound=str(4*abs(gap)/K)))
 return out

def tail(q,k):
 term=(-q).exp()
 for j in range(1,k+1):term*=q/j
 total=term;j=k
 while term>total*D(10)**(-__import__('decimal').getcontext().prec+8):
  j+=1;term*=q/j;total+=term
 return total

def dc(f):return D(f.numerator)/D(f.denominator)
def canon(d):return str(D(format(d,'.18g')).normalize())
def numeric(prec):
 with localcontext() as ctx:
  ctx.prec=prec;tilts=[];formal=[];repairs=[]
  for size in (4,8,16):
   for epsilon in (F(1,4),F(1,16),F(1,256)):
    for shift in (0,1,2):
     va=[F(2*i-size+1,size) for i in range(size)];vb=[va[(i+shift)%size] for i in range(size)]
     aa=[1+epsilon*x for x in va];bb=[1+epsilon*x for x in vb]
     assert sum(aa)==sum(bb)==size and min(aa+bb)>=F(1,2) and max(aa+bb)<=F(3,2)
     chi=dc(sum((x-y)**2 for x,y in zip(aa,bb))/size)
     vv=[(dc(y)/dc(x)).ln() for x,y in zip(aa,bb)];weights=[dc(x)/size for x in aa]
     mean=sum(p*v for p,v in zip(weights,vv));second=sum(p*v*v for p,v in zip(weights,vv))
     tol=D(10)**(-prec+5)
     assert -2*chi-tol<=mean<=tol and second<=6*chi+tol
     assert max(abs(v-mean) for v in vv)<=dc(8*epsilon)
     tilts.append(dict(size=size,epsilon=str(epsilon),shift=shift,mean=canon(mean),second=canon(second),chi=canon(chi)))
  cstar=D(2).sqrt()/10
  for expn in (8,12,16,24,32,48,64,80):
   n=D(10)**expn;K=int(cstar*n.sqrt()/(64*(8*n.ln()).sqrt())+D('0.5'))*64
   u=cstar*n.sqrt()/K;logu=u.ln();ell=D('0.00001')/(D(K)*u*u*logu);duration=n*ell/4
   M=int((48*u)**(D(1)/3))+1
   guard=D(K)>=7000*logu and 10*(1+D(M).ln())<=K and u>=14
   formal.append(dict(n_exponent=expn,K=K,u=canon(u),duration=canon(duration),sqrt_duration=canon(duration.sqrt()),explicit_local_guards=guard,duration_at_least_one=duration>=1,log_normalized_candidate=canon((K*u*duration.sqrt()).ln()),note='No numerical certification of the accepted Cramer n0 or a good environment.'))
  for T in (D(0),D('0.1'),D(1),D(10),D(100),D(10000),D(10)**8,D(10)**16):
   m=int((64*(2+T).ln()).to_integral_value(rounding='ROUND_CEILING'));q=D(m)/2
   p=tail(q,m);chernoff=(-D(m)/8).exp();actual_budget=(D(m)/(m+1)+m*T)*p;bound=(1+m*T)*chernoff
   assert p<=chernoff and actual_budget<=bound<=1
   transfer=tail(D(m),m+1);moment=D(1)/(12+D(4)/m)
   assert transfer>=moment>=D(1)/16
   repairs.append(dict(T=str(T),m=m,low_tail=canon(p),false_positive_bound=canon(bound),actual_death_budget=canon(actual_budget),transfer_probability=canon(transfer),moment_lower=canon(moment)))
  return dict(tilts=tilts,formal=formal,repair=repairs)

def main():
 bv=bv_tests();a=numeric(70);b=numeric(110);assert a==b
 coefficient=F(1,4)/(2*(F(12,1000)+F(2,1000)/6));assert coefficient==F(375,37)>10
 result=dict(status='PASS finite guards; asymptotic counterexample uses accepted analytic lower tools',bv=bv,**a,bernstein_exponent_coefficient=str(coefficient),notes=['BV tests are actual positive-width periodic sources with background, testing the high-frequency part only. The retained low-spectrum derivative bound is analytic.','All BV integrations and input normalizations are Fraction-exact.','Decimal70/110 repetition is not interval certification; no rare-event or high-dimensional source simulation.','No random seeds: deterministic inputs.'])
 Path(__file__).with_name('results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps(dict(status='PASS',bv_cases=len(bv),bv_segments=sum(x['segments'] for x in bv),tilt_cases=len(a['tilts']),formal_cases=len(a['formal']),repair_cases=len(a['repair']))))
if __name__=='__main__':main()
