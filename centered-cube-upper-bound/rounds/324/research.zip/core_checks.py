from fractions import Fraction as F
from random import Random
rng=Random(324)
ct=dict(mass=0,prefix=0,density=0,tag_compare=0,square=0)
for case in range(48):
 n=1+case%3; nx=5; nz=4; ny=3
 pos=[tuple([F(i-2,3)]+[F((i+k)%3-1,4) for k in range(1,n)]) for i in range(nx)]
 zs=[tuple([F(i-2,4)]+[F((i+2*k)%3-1,5) for k in range(1,n)]) for i in range(nz)]
 R=[F(1),F(1),F(3,2),F(2),F(2)]
 vol=[F(rng.randrange(1,5),8) for _ in range(nx)]
 q=[F(rng.randrange(3,5),4) for _ in range(nx)]
 cap=[[int(max(abs(pos[x][k]-zs[z][k]) for k in range(n))<=R[x]/2) for z in range(nz)] for x in range(nx)]
 tagcap=[[int(max(abs(pos[u][k]-pos[v][k]) for k in range(n))<=R[u]/2) for v in range(nx)] for u in range(nx)]
 nu=[F(rng.randrange(1,5),4) for _ in range(nz)]
 capscale=max([F(1)]+[sum(nu[z]*cap[x][z] for z in range(nz))/(4*R[x]**n) for x in range(nx)])
 nu=[m/capscale for m in nu]
 beta=[F(1,3)]*ny
 U=[[F(rng.randrange(1,7),5) for x in range(nx)] for y in range(ny)]
 uscale=max(F(1),max(sum(beta[y]*U[y][x] for y in range(ny)) for x in range(nx)))
 U=[[a/uscale for a in row] for row in U]
 rho=[sum(beta[y]*U[y][x] for y in range(ny)) for x in range(nx)]
 V=[[F(cap[x][z])/(q[x]*R[x]**n) for x in range(nx)] for z in range(nz)]
 cuts=sorted(set(R))
 K=[[sum(V[z][x]*vol[x] for x in range(nx) if R[x]<=r) for z in range(nz)] for r in cuts]
 thresholds=[F(1,8),F(1,2)]+[k/2 for k in K[-1] if k]+[k for row in K for k in row if k]
 for G in thresholds:
  T=[[F(0)]*nx for z in range(nz)]
  for z in range(nz):
   if K[-1][z]<G:continue
   rem=G
   for r in cuts:
    ids=[x for x in range(nx) if R[x]==r]
    batch=sum(V[z][x]*vol[x] for x in ids)
    frac=min(F(1),rem/batch) if batch else F(0)
    for x in ids:T[z][x]=frac*V[z][x]*vol[x]/G
    rem-=frac*batch
   assert rem==0 and sum(T[z])==1;ct['mass']+=1
  mu=[sum(nu[z]*T[z][v] for z in range(nz))/vol[v] for v in range(nx)]
  assert sum(mu[v]*vol[v] for v in range(nx))==sum(nu[z] for z in range(nz) if K[-1][z]>=G)
  for v in range(nx):
   assert mu[v]<=F(4)/(F(3,4)*G);ct['density']+=1
  acc=[[sum(T[z][v]*tagcap[u][v] for v in range(nx)) for u in range(nx)] for z in range(nz)]
  for u in range(nx):
   lhs=sum(nu[z]*cap[u][z]*acc[z][u] for z in range(nz))
   rhs=sum(mu[v]*vol[v]*tagcap[u][v] for v in range(nx))
   assert lhs<=rhs;ct['tag_compare']+=1
  N=Na=Nr=En=F(0)
  for i,r in enumerate(cuts):
   ell=r**(-n)-(cuts[i+1]**(-n) if i+1<len(cuts) else 0)
   ids=[x for x in range(nx) if R[x]<=r]
   for z in range(nz):
    if K[i][z]>=G:
     assert all(T[z][v]==0 for v in range(nx) if R[v]>r);ct['prefix']+=1
   for y in range(ny):
    J=sum(U[y][u]*vol[u] for u in ids)
    if J<F(1,4):continue
    for z in range(nz):
     A=sum(U[y][u]*vol[u]*cap[u][z] for u in ids)
     En+=ell*beta[y]*nu[z]*A*A/J
     if K[i][z]<G:continue
     for u in ids:
      mask=F(1+(u+y+z+case)%3,3)
      term=ell*beta[y]*nu[z]*U[y][u]*vol[u]*cap[u][z]*mask
      N+=term;Na+=term*acc[z][u];Nr+=term*(1-acc[z][u])
  assert N-En==Na+(Nr-En);ct['square']+=1
  positive=sum(rho[u]*vol[u]/R[u]**n*sum(mu[v]*vol[v]*tagcap[u][v] for v in range(nx)) for u in range(nx))
  assert Na<=positive
print('PASS',ct,'total',sum(ct.values()))
