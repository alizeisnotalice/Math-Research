from fractions import Fraction as F
from itertools import product
ct=dict(coupling=0,mean_variance=0,jensen=0,debt=0,reference_bound=0,away=0)
pos=neg=zero=0
weights=((1,1,1),(1,5,1),(1,1,5),(5,1,1))
for J,sw,tw in product((F(1),F(2),F(7,3)),weights,weights):
    a=(F(0),J/3,J)
    p=tuple(F(v,sum(sw)) for v in sw)
    q=tuple(F(v,sum(tw)) for v in tw)
    phi=lambda x:x-x*x/J
    mu=sum(x*w for x,w in zip(a,p)); c=sum(x*w for x,w in zip(a,q))
    V=sum(w*(x-mu)**2 for x,w in zip(a,p))
    Vg=sum(w*(x-c)**2 for x,w in zip(a,q))
    Cv=sum(w*phi(x) for x,w in zip(a,p))
    Cg=sum(w*phi(x) for x,w in zip(a,q))
    trans=sum(p[i]*q[j]*(a[i]-a[j])*(1-(a[i]+a[j])/J)
              for i in range(3) for j in range(3))
    assert trans==Cv-Cg; ct['coupling']+=1
    assert Cv-Cg==(mu-c)*(1-(mu+c)/J)+(Vg-V)/J
    ct['mean_variance']+=1
    assert phi(c)-Cg==Vg/J>=0; ct['jensen']+=1
    debt=(mu-c)*(1-2*c/J)-((mu-c)**2+V)/J
    assert Cv==phi(c)+debt; ct['debt']+=1
    assert 0<=phi(c)<=c; ct['reference_bound']+=1
    if (mu-c)*(c-J/2)>=0:
        assert debt<=0; ct['away']+=1
    pos+=debt>0; neg+=debt<0; zero+=debt==0
print('PASS',ct,'total',sum(ct.values()),
      'debt_signs',dict(positive=pos,negative=neg,zero=zero))
