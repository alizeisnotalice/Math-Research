# R324 bounded history check: actual-incidence normalized lift

## Finding

The proposed high-prefix lift/density certificate is **not located** in the bounded R318–R323 check. R323 already proves a different, direct **low-prefix receipt** for the actual hard-incidence cumulative (K_z(r)): the baseline portion on (K_z(r)<G) costs at most λG W_ν. It retains the complementary high-K branch and explicitly leaves its double-high geometry unresolved. Thus R323 is not the proposed source-to-actual-receiver normalized lift on (S=\{K_z(b)\ge G\}\), nor does it prove the proposed tag-marginal density bound or high-K accepted-baseline Young payment.

## Exact references

- `rounds/323/research.zip::core_geometry.md`, lines 5–14 defines the actual row (V_z(x)=1_E(x)c_x(z)/(q(x)R(x)^n)), its cumulative (K_z(r)=\int_{R(x)\le r}V_z(x)dx), and claims only the fixed-G low portion (K_z(r)<G) costs λG W_ν. Lines 46–51 split the original baseline exactly into lowK and highK, leaving `Phi_double=N_core,highK-E_full` with the original whole square.
- Same member, lines 53–81 proves this low-prefix receipt by integrating the original missed endpoint to full (J), applying FIRST and the inclusive-CDF prefix-mass estimate. Lines 76–81 says finiteness needs no density cap and describes the row as an actual integral on actual E,R,q.
- Same member, lines 133–169 identifies a cross-Gram representation and Schur **upper** bounds; lines 152 and 168–169 explicitly say double-high K/J does not lower-bound the square and no bound for the highK residual is proved.
- `rounds/323/research.zip::audit.md`, lines 66–76 independently records precisely the same (K_z(s)) low-prefix payment and its hypotheses; lines 98–102 confirms that only `N_core,highK-E_full` remains and no boundary-density cap or high-K closure is established.
- The generic frozen source-tag construction in `rounds/319/research.zip::entry.md`, lines 57–75, lifts source z to a uniform auxiliary tag U in its fixed packet and accepts U in the actual original cube. Lines 77–97 proves an upper bound for that accepted low-average subtraffic via the spread density g. It is a receiver-independent source-label/tag lift, not the proposed (T_z(dv)\propto c_v(z)dv/[q(v)R(v)^nK_z(b)]) normalized by actual incidence. Lines 101–109 explicitly keep the rejected component as an obstruction and give a packetwise domination criterion; they do not establish the requested K-normalized tag marginal.

## Bounded-search conclusion

Among the targeted R318, R319, R322 and R323 archive markdown members, no exact definition of the proposed (T_z), no μ marginal estimate (\mu\le4\lambda/(q_-G)) on (S), and no payment of the accepted original baseline by (\varepsilon X_\rho+C_2^2/(\varepsilon q_-G)W_\nu) was found. This is a bounded local search, not a claim about every archive. In particular, do not conflate the R323 low-K direct receipt with the proposed high-K normalized lift; the former is already proved, the latter remains a distinct candidate.
