# R324 — actual first-prefix tags have a logarithmic conditional geometric-bias budget

Primary authored, 2026-10-18. This is a geometric property of the SAME source-conditioned first-G tag law in core.md, not a replacement law, new source budget, acceptance theorem, or a completed root bound. It uses the D04 classical finite-KL chain rule on standard Borel spaces; the conditional reference is retained rather than replacing the radial mixture by independent coordinate marginals.

## 1. Exact canonical cube mixture

Write Q_t(z) for the cube of side t, h_t=t^(-n)1_Qt, a<=t<=b. Put A_n=1+n log(b/a) and

S_z(x)=sup_{a<=t<=b} h_t(x-z).

Let d=2||x-z||infinity. Except null boundaries, S_z=0 for d>b, and S_z=max(a,d)^(-n) for d<=b. It has the exact positive mixture

S_z(x)=h_b(x-z)+∫_a^b (n/t) h_t(x-z)dt.

Indeed the right side is b^(-n)+∫_{max(a,d)}^b n t^(-n-1)dt=max(a,d)^(-n) on its support. Its total mass is A_n. The canonical probability is sigma_z(dx)=S_z(x)dx/A_n, with explicit joint version

Q_z(dt,dx)=pi(dt) h_t(x-z)dx,
pi=[delta_b+n 1_(a,b)dt/t]/A_n.

The t=b atom is essential; a=b gives pi=delta_b and exactly one uniform cube. This auxiliary latent scale t is NOT the original chosen R(x), original layer r, or a free new outer clock.

## 2. Domination of the actual high-K tag

The original hard incidence is V_z(x)=1_E(x)c_x(z)/[q(x)R(x)^n]. For a source with K_z(b)>=G, retain a measurable fraction a_z(x) in [0,1] selecting its earliest G incidence mass in actual R order, fractionally splitting only the crossing same-R atom. The tag tau_z(dx)=a_z(x)V_z(x)dx/G is a probability and retains all original fields. See core.md for its construction and prefix property.

Since q>=q_- and a<=R<=b, tau_z has density at most S_z/(q_-G). Therefore

0<=w_z=d tau_z/d sigma_z<=D=A_n/(q_-G).

The existence of a high-K source implies D>=1; no law is claimed on absent sources if G>A_n/q_-. This domination holds with arbitrary original selector E,R,q; no actual-source density cap or geometric symmetry is assumed. It yields

0<=KL(tau_z||sigma_z)=∫w_z log(w_z)d sigma_z<=log D.

We use 0 log0=0. The negative part is integrable since x log x>=-1/e; the positive part is bounded by w logD. Thus no infinity-minus-infinity manipulation is used.

## 3. Preserve the law while exposing the latent scale

Define the joint probability P_z(dt,dx)=w_z(x)Q_z(dt,dx). Its x marginal is the EXACT tau_z, and KL(P_z||Q_z)=KL(tau_z||sigma_z)<=logD. Set

M_z(t)=∫w_z(x)h_t(x-z)dx,
P_z^T(dt)=M_z(t)pi(dt),
P_z(dx|t)=w_z(x)h_t(x-z)dx/M_z(t) for M_z(t)>0.

The zero-M fibers have zero P_z^T mass and are assigned any probability without affecting formulas. All spaces are standard Borel. Finite KL and the direct disintegration give the legal chain

KL(P_z^T||pi)+∫ KL(P_z(dx|t)||h_t(x-z)dx) P_z^T(dt)<=logD.

In particular the conditional entropy is averaged under P_z^T, NOT pi. There is no claim that P_z's coordinates are independent or that its scale is the original R.

## 4. Dimension-free quadratic cost of conditional mean displacement

Let m_z(t)=∫x P_z(dx|t). This is finite because x is in Q_t(z). For any s in R^n, the centered uniform cube satisfies

log∫exp(s·(x-z))h_t(x-z)dx <= t²||s||_2²/8.

Elementary proof: convexity bounds each one-coordinate exponential expectation by cosh(s_i t/2), and log cosh v<=v²/2 follows by integrating tanh v<=v for v>=0 and evenness. Product structure is used ONLY for the reference uniform cube, not the actual conditional law. Jensen applied to the tilted density gives

s·(m_z(t)-z)<=KL(P_z(dx|t)||h_t dx)+t²||s||²/8.

Take s=4(m_z(t)-z)/t². Consequently

2||m_z(t)-z||_2²/t² <= KL(P_z(dx|t)||h_t dx),
∫ ||m_z(t)-z||_2²/t² P_z^T(dt) <= (1/2)log D.  (GEO)

For a measurable threshold L>0, the actual P_z^T mass of fibers with ||m_z(t)-z||²/t²>L is at most logD/(2L). This is only a conditional mean-bias statement; it does not imply overlap/capture probability or control actual source boundary mass.

Since all source laws are obtained by measurable kernels, (GEO) may be integrated over the original high-source restriction nu_S without copying its mass:

∫nu_S(dz)∫ ||m_z(t)-z||²/t² P_z^T(dt) <= .5 logD ||nu_S||.

For b/a<=2, q_-=3lambda/4, G=sqrt(n)/lambda, the exact value D=4 A_n/(3sqrt(n)) is at most 8sqrt(n)/3 for n>=1, because A_n<=n+1<=2n. Hence its entropy fee is at most log(8/3)+.5log n. This is a logarithmic geometric budget, NOT a claimed root estimate on Phi_res. Variable outer parameters retain their actual source-weighted logD costs; no extra clock copies.

## 5. Scope and numerical exploration

The result rules out arbitrary large aggregate conditional mean bias for the true high-incidence tags, while allowing substantial conditional covariance and boundary contact. It does not show the tag accepts a uniform fraction of the original captures. In an auxiliary reference example of two independent uniform centers in the same cube, the probability that their coordinate differences are at most half the side length is (3/4)^n. Primary actually ran MATLAB for n=1,2,4,8,16,32,64,128: values include 0.10011 (n8), 0.010023 (n16), 1.0091e-8 (n64), 1.0182e-16 (n128). This is an exact product-reference calculation evaluated in floating point, not an original full-history counterexample; it changes the next decision: combine shared-source capture-square correlations with this geometric budget, rather than inferring acceptance from density domination alone.

Reproducible finite tests in entropy_checks.py check the mixture antiderivative using Fractions, conditional entropy chain on explicit finite-scale positive-volume cube mixtures, and the mean-bias bound at two Decimal precisions. The finite mixtures are implementation diagnostics, not asserted to equal the continuous canonical law or the actual first-G tags. The analytic argument above proves (GEO) for the original tags.

Open: turn conditional entropy/bias plus original common beta/nu and the full cross-capture square into an upper bound for the remaining rejected triples. Neither KL upper bounds nor favorable source drift alone currently supplies that inequality.
