# R324 — high-incidence source transport with a bounded-density tag and the original square

## Result and exact scope

Keep the fixed original R323 residual

    Phi_res=N_res-E_full.

Its positive baseline retains J_y(r)>=H, K_z(r)>=G, the original recent and middle receiver gates, original source-shape failure, and the actual middle-CZ-packet rejected weight. Its U,J,A,q,E,R, sources and full negative square are unchanged.

High K supplies a concrete new source-transport payment. There is ONE frozen source-to-actual-receiver probability kernel T_z^G, for sources

    S_G={z:K_z(b)>=G},

whose tag marginal mu has

    ||mu||_1=nu(S_G)<=W_nu,
    0<=mu(v)<=4lambda/(q_-G).                             (1)

Moreover, whenever the ORIGINAL current layer has K_z(r)>=G, the whole tag law is supported on actual receivers v satisfying R(v)<=r and c_v(z)=1. This is an exact compatibility with the original receiver clock, including radius atoms.

Define the actual new acceptance fraction

    a_z(u)=T_z^G(Q_(R(u))(u)).                            (2)

Insert a_z(u) into the existing N_res, giving N_acc; insert 1-a_z(u), giving N_rej. Then, for every eta>0,

    N_acc<=eta X_rho+C2^2/(eta q_-G) W_nu,               (3)
    Phi_res<=eta X_rho+C2^2/(eta q_-G) W_nu+Phi_next,
    Phi_next=N_rej-E_full.                              (4)

The original whole E_full is still subtracted once. All original gates stay in both positive pieces and the original full J is used throughout. No source density assumption, source-order assumption, softness gate, enlarged-radius cap, or change of q is used in (1)-(4). C2 is exactly the previously authorized dimension-independent strong L2 constant for the centered cube maximal operator.

For G=c sqrt(n)/lambda, the source coefficient in (3) is 4C2^2/(3eta c sqrt(n)). This is a genuine paid sub-integral of the GENERAL current residual, produced by high incidence rather than concentration of source packets. There is no uniform positive accepted fraction; the accepted sub-integral may be very small or zero on a particular further restriction. No general root bound for Phi_next is proved.

## 1. Actual first-G transport and exact atoms

Use the original hard incidence field and inclusive CDF

    V_z(v)=1_E(v)c_v(z)/(q(v)R(v)^n),
    K_z(r)=integral_(R(v)<=r) V_z(v)dv.

It is finite, with K_z(b)<=A_n/q_-, A_n=1+nlog(b/a). For z in S_G let

    tau_z=inf{r in [a,b]:K_z(r)>=G},
    k_z^-=K_z(tau_z-), d_z=K_z(tau_z)-K_z(tau_z-).

Here K_z(a-)=0. If d_z>0 put gamma_z=(G-k_z^-)/d_z; it lies in [0,1]. If d_z=0 set gamma_z=0; in that case k_z^-=G. Define

    b_z(v)=1_(R(v)<tau_z)+gamma_z 1_(R(v)=tau_z),
    T_z^G(dv)=G^(-1)b_z(v)V_z(v)dv.                       (5)

The scalar b_z is not the original source mask alpha and does not change any original receiver field. It only defines a NEW source-tag probability law. In particular a fractional crossing atom in (5) is NOT a fractional interpretation of the old gate K<G, and no atom of original J,K or ell_n is removed or split in the traffic being estimated.

By the inclusive CDF definition,

    integral b_z(v)V_z(v)dv=G,
    0<=dT_z^G/dv<=V_z(v)/G.                              (6)

Thus T_z^G is a probability kernel. If K_z(r)>=G then tau_z<=r, so it is supported in R(v)<=r; V_z also gives c_v(z)=1. All endpoint equalities are retained, including tau_z=b. Zero-mass sources or sources outside S_G do not participate in this lift.

The definitions are measurable: K_z(r) is a jointly measurable increasing right-continuous CDF; its first crossing and left limit are measurable, and R(v)=tau_z is a measurable set. Equivalently, (5) is the canonical first-G truncation of the measurable radius pushforward measure, with proportional selection of the crossing atom. It uses no spatial choice function or new receiver partition.

The source-tag joint measure is

    pi(dz,dv)=1_(S_G)(z)nu(dz)T_z^G(dv).

It has original source marginal 1_(S_G)nu. Its tag marginal has the actual Lebesgue density

    mu(v)=1_E(v)/(Gq(v)R(v)^n)
                   integral_(S_G) b_z(v)c_v(z)nu(dz).

Mass conservation and the SAME ACTUAL receiver/radius cap imply

    integral mu=nu(S_G),
    mu(v)<=nu(Q_(R(v))(v))/(Gq(v)R(v)^n)
          <=4lambda/(q_-G).

This proves (1). No source cap is evaluated at a source center, a translated E, or a larger radius. The high-K sources are frozen using K_z(b); the same mu is used at every y,r,u,w. Current K_z(r)>=G only ensures that all their already-frozen tags lie in the current prefix.

## 2. Paying the accepted part without altering any original gate

Write the original N_res using its actual pair mask M_res in [0,1]:

    N_res=integral beta(dy)nu(dz)ell_n(dr)1_(J>=H)/J
                integral U_y(u)U_y(w)c_u(z)M_res du dw.

M_res includes K_z(r)>=G and all current residual conditions. Insert a_z(u) or 1-a_z(u), which gives the exact positive identity

    N_res=N_acc+N_rej.                                   (7)

For N_acc only, integrate the original noncapturing endpoint w against its original numerator and bound its mass by the SAME full J. Drop the other positive masks, but retain that every contributing source belongs to S_G. The original inclusive layer tail and FIRST yield

    N_acc<=integral_E rho(u) R(u)^(-n)
                  integral_(S_G)c_u(z)a_z(u)nu(dz)du.

By (2), c_u(z)<=1 and Tonelli,

    integral_(S_G)c_u(z)a_z(u)nu(dz)
      <=integral_(S_G)T_z^G(Q_(R(u))(u))nu(dz)
      =integral_(Q_(R(u))(u))mu(v)dv.                     (8)

This is a positive tag comparison. It does NOT substitute mu for nu in the original K gate, source masks, A, J or E_full. Its test cube is exactly the original selected cube Q_(R(u))(u); no enlargement factor occurs.

Consequently, with X_rho=lambda integral rho and 0<=rho<=1,

    N_acc<=integral rho M_square mu
      <=C2 sqrt(X_rho/lambda)||mu||_2
      <=C2 sqrt(4X_rho W_nu/(q_-G)).                      (9)

Young's inequality gives (3). If X_rho is infinite this is only an extended-real statement; as in R323 the useful application uses the original finite occupancy/truncation. Both positive pieces are finite, being bounded by N_res<=A_nW_nu; therefore the signed identity in (4) subtracts finite quantities.

## 3. What the rejected triple and the whole square actually say

Unfolding the NEW tag law, the remaining positive piece contains the exact geometric factors

    c_u(z)c_v(z)[1-c_u(v)] b_z(v)/(Gq(v)R(v)^n),          (10)

in addition to the original U_y(u)U_y(w), M_res, beta nu ell_n/J and dv. On every such contribution, R(v)<=r and R(u),R(w)<=r. The old w endpoint remains completely original and is not identified with v.

The new rejected triple is genuinely nonreciprocal: u captures z, v captures z, but u does not capture the receiver center v. Its elementary necessary distance condition is

    R(u)/2<||u-v||_infinity<=(R(u)+R(v))/2.               (11)

This condition does not make the actual source mass in a thin boundary small, and R(v)/R(u) can be of order one. The cap that produced the tag density is already paid in (1); it does not turn (10) into a small original source-boundary mass.

For a precise comparison with the unchanged square, fix y,z,r on the high-K/high-J domain and put

    P_(y,r)(dw)=U_y(w)1_(R(w)<=r)dw/J_y(r),
    p_yz=P_(y,r)(c_w(z))=A_yz(r)/J_y(r),
    t_yz(u)=integral M_res(y,z,r,u,w) P_(y,r)(dw).

Thus 0<=t<=1 and t=0 wherever the original residual gates fail. The exact residual cost is

    Phi_next=integral beta nu ell_n 1_(J>=H)
                   integral_(R(u)<=r) U_y(u)c_u(z)
                     [t_yz(u)(1-a_z(u))-p_yz]du.          (12)

Outside K_z(r)>=G, the first term is zero and the negative square remains; define the tag quantities there only when needed. Formula (12) does not redistribute E_full onto a different source or receiver field. It shows precisely which square gain would be needed: the actual shared-source posterior capture p_yz must offset the tag rejection seen by the original capturing endpoint.

There is a legitimate, but not uniformly quantified, shared-prefix affinity certificate. Since T_z^G is a probability law supported on c_w(z)=1 inside this same prefix,

    L_yz(r)=integral sqrt((dP_(y,r)/dw)(dT_z^G/dw))dw,
    0<=L_yz(r)^2<=p_yz.                                 (13)

This is just Cauchy-Schwarz on the actual capture support. In original fields its integrand is

    sqrt[ U_y(v)b_z(v)c_v(z)/(J_y(r)Gq(v)R(v)^n) ].

Therefore a region where L_yz(r)^2>=t_yz(u)(1-a_z(u)) contributes nonpositively to (12). This is a proved cost criterion, NOT a theorem that it covers the general residual. High J and high K alone do not lower-bound this affinity, and a Schur upper bound is not such a lower bound. The tag transport does remove the future-prefix incompatibility from this comparison; it does not prove the remaining correlation estimate.

The packet identity suggested in the task remains exact, with its necessary J factor: for p_z=A_yz/J and a packet of mass m,

    J integral_(D) p_z(1-p_z)nu(dz)
       =Jm[ pbar_D(1-pbar_D)-Var_(nu_D/m)(p_z) ].          (14)

The negative variance in (14) is part of E_full already retained in (12); it cannot be added as a second independent credit. Neither (14) nor (13) has yet yielded a paid bound for all rejected triples (10).

## 4. Optional exact radial domination and entropy certificate

Let H_z(v)=sup_(a<=R<=b) h_R(v-z), whose exact integral is A_n, and let sigma_z(dv)=H_z(v)dv/A_n. Equation (6) gives the actual domination

    T_z^G<= [A_n/(q_-G)] sigma_z.                        (15)

On S_G the bracket is at least one, since G<=K_z(b)<=A_n/q_-. Thus its relative entropy satisfies

    D(T_z^G || sigma_z)<=log[A_n/(q_-G)].                 (16)

At a current high-K layer r the same statement holds with the envelope over a<=R<=r and A_n(r)=1+nlog(r/a), because all tags are already in the prefix. This is an elementary density-ratio certificate, not a product-coordinate concentration theorem: sigma_z is a radial mixture, not a coordinate product. No lower acceptance bound or general square gain is inferred from (15)-(16).

## 5. Complete insertion and unpaid complement

Apply (4) after the already fixed R323 low-K and CZ priorities. This REPLACES the one Phi_res slot. The R323 payments and their exact selectors/partitions remain as they were. The new tag input is formed once per original outer instance; its source mass is charged once explicitly by the new coefficient in (3). It is not a free copy of an earlier test input.

At the original target factor 2 and old recovery Lambda=128/119, the new terms are

    2Lambda eta L_out[X_rho]
      +2Lambda C2^2/(eta q_-G) W_nu
      +2Lambda L_out[Phi_next],                           (17)

when the parameters are common. With varying authentic outer data retain the exact weighted source sum. Only the certified M3 bound allows L_out[X_rho]<=X_old. Thus the additional receiver coefficient is exactly 2Lambda eta. It must fit a separately maintained absorption reserve; no missing original H0 entry is supplied here.

If G=H=sqrt(dA_n/(4lambda)), then q_-G=(3/8)sqrt(lambda d A_n), and the fixed-instance new source coefficient is

    8C2^2/[3eta sqrt(lambda d A_n)].                      (18)

This dependence cannot be called O(1/sqrt(n)) unless the original lambda d is controlled as required. For the independent root choice G=c sqrt(n)/lambda, retain the already paid low-K source fee lambda G=c sqrt(n) and the coefficient stated after (4). Changing G changes the original residual and requires its consistent reassembly.

Every aspect dependence, old source-shape inflation, original time/leaf factors and source-conservation rule remains. No matched beta<=f or q=P*f equality is needed for the new transport; if those are used later to estimate (13), they must be the same original slot. This note does not restart alpha or replace the current E_full.

History check: a targeted read of R318/R319/R322/R323 found the generic frozen-tag comparison in R319 and the distinct low-K prefix payment in R323, but not this high-K normalized actual-incidence lift or its bounded-density Young receipt. The check is recorded separately by the history agent in `/tmp/r324_lift_history.md`. The present proof is self-contained for the new lift; it reuses the already authorized maximal-L2 theorem exactly as R323 did.

## 7. Reproducible finite diagnostic

The code below checks the NEW transport only: exact first-G mass, complete same-radius crossing groups, current-prefix support, the tag-density cap, actual-cube acceptance comparison, and preservation of the original whole-square identity. It is a finite atomic/quadrature diagnostic, not a claim of native L1/history/low-pe realization or a numerical proof of the maximal theorem. It uses only Python's standard library.

```python
from fractions import Fraction as F
from random import Random
rng=Random(324)
ct=dict(mass=0,prefix=0,density=0,tag_compare=0,square=0)
for case in range(48):
 n=1+case%3; nx=5; nz=4; ny=3
 pos=[tuple([F(i-2,3)]+[F((i+k)%3-1,4) for k in range(1,n)]) for i in range(nx)]
 zs=[tuple([F(i-2,4)]+[F((i+2*k)%3-1,5) for k in range(1,n)]) for i in range(nz)]
 R=[F(1),F(1),F(3,2),F(2),F(2)]
 vol=[F(rng.randrange(1,5),8) for _ in range(nx)]
 q=[F(rng.randrange(3,5),4) for _ in range(nx)]
 cap=[[int(max(abs(pos[x][k]-zs[z][k]) for k in range(n))<=R[x]/2) for z in range(nz)] for x in range(nx)]
 tagcap=[[int(max(abs(pos[u][k]-pos[v][k]) for k in range(n))<=R[u]/2) for v in range(nx)] for u in range(nx)]
 nu=[F(rng.randrange(1,5),4) for _ in range(nz)]
 capscale=max([F(1)]+[sum(nu[z]*cap[x][z] for z in range(nz))/(4*R[x]**n) for x in range(nx)])
 nu=[m/capscale for m in nu]
 beta=[F(1,3)]*ny
 U=[[F(rng.randrange(1,7),5) for x in range(nx)] for y in range(ny)]
 uscale=max(F(1),max(sum(beta[y]*U[y][x] for y in range(ny)) for x in range(nx)))
 U=[[a/uscale for a in row] for row in U]
 rho=[sum(beta[y]*U[y][x] for y in range(ny)) for x in range(nx)]
 V=[[F(cap[x][z])/(q[x]*R[x]**n) for x in range(nx)] for z in range(nz)]
 cuts=sorted(set(R))
 K=[[sum(V[z][x]*vol[x] for x in range(nx) if R[x]<=r) for z in range(nz)] for r in cuts]
 thresholds=[F(1,8),F(1,2)]+[k/2 for k in K[-1] if k]+[k for row in K for k in row if k]
 for G in thresholds:
  T=[[F(0)]*nx for z in range(nz)]
  for z in range(nz):
   if K[-1][z]<G:continue
   rem=G
   for r in cuts:
    ids=[x for x in range(nx) if R[x]==r]
    batch=sum(V[z][x]*vol[x] for x in ids)
    frac=min(F(1),rem/batch) if batch else F(0)
    for x in ids:T[z][x]=frac*V[z][x]*vol[x]/G
    rem-=frac*batch
   assert rem==0 and sum(T[z])==1;ct['mass']+=1
  mu=[sum(nu[z]*T[z][v] for z in range(nz))/vol[v] for v in range(nx)]
  assert sum(mu[v]*vol[v] for v in range(nx))==sum(nu[z] for z in range(nz) if K[-1][z]>=G)
  for v in range(nx):
   assert mu[v]<=F(4)/(F(3,4)*G);ct['density']+=1
  acc=[[sum(T[z][v]*tagcap[u][v] for v in range(nx)) for u in range(nx)] for z in range(nz)]
  for u in range(nx):
   lhs=sum(nu[z]*cap[u][z]*acc[z][u] for z in range(nz))
   rhs=sum(mu[v]*vol[v]*tagcap[u][v] for v in range(nx))
   assert lhs<=rhs;ct['tag_compare']+=1
  N=Na=Nr=En=F(0)
  for i,r in enumerate(cuts):
   ell=r**(-n)-(cuts[i+1]**(-n) if i+1<len(cuts) else 0)
   ids=[x for x in range(nx) if R[x]<=r]
   for z in range(nz):
    if K[i][z]>=G:
     assert all(T[z][v]==0 for v in range(nx) if R[v]>r);ct['prefix']+=1
   for y in range(ny):
    J=sum(U[y][u]*vol[u] for u in ids)
    if J<F(1,4):continue
    for z in range(nz):
     A=sum(U[y][u]*vol[u]*cap[u][z] for u in ids)
     En+=ell*beta[y]*nu[z]*A*A/J
     if K[i][z]<G:continue
     for u in ids:
      mask=F(1+(u+y+z+case)%3,3)
      term=ell*beta[y]*nu[z]*U[y][u]*vol[u]*cap[u][z]*mask
      N+=term;Na+=term*acc[z][u];Nr+=term*(1-acc[z][u])
  assert N-En==Na+(Nr-En);ct['square']+=1
  positive=sum(rho[u]*vol[u]/R[u]**n*sum(mu[v]*vol[v]*tagcap[u][v] for v in range(nx)) for u in range(nx))
  assert Na<=positive
print('PASS',ct,'total',sum(ct.values()))
```

The embedded script was actually executed locally and returned `PASS {'mass': 2451, 'prefix': 5806, 'density': 4080, 'tag_compare': 4080, 'square': 816} total 17233`. Source-mass conservation and the final positive baseline comparison are additional exact assertions in each threshold case; the displayed counter reports its five named categories.

Only `/tmp/r324_core.md` is authored. The new paid accepted sub-integral and all remaining costs are explicit. The rejected triple/cross-Gram term remains genuinely unproved; this is not a claim that only constants or logarithms remain.
