# R324 independent preauthor screen — exact signed source transport

Ownership: only /tmp/r324_audit.md. No Git or author-file changes. This screen was completed before reading new R324 author proofs. Original U,J,A,E,R,q,beta,all eligibility/history fields and thresholds are frozen throughout.

## 1. Complete physical boundary loss is linear in the hard source, with frozen fields

For J>0 let f_J(A)=A-A²/J, where A_z=integral_{R(u)<=r} U_y(u)c_u(z)du and0<=A_z<=J_y(r). For J=0 set f=0. The original physical B_H(nu)=integral beta(dy)ell(dr)1{J>=H} integral f_J(A_z)nu(dz) is linear in nu ONLY when its row fields and high-J qualification are held fixed. If they were originally chosen from nu, they remain the actual chosen fields; this linearity does not re-run that choice on a new source.

Let Pi be ANY mass-conserving positive coupling with first marginal nu and second marginal g(z')dz', for instance the identity on good source and the conditional uniform tag in each frozen disjoint binary-CZ packet. Exactly,

 B_H(nu)-B_H(g)=integral beta ell 1{J>=H} integral Pi(dz,dz')
 (A_z-A_z')[1-(A_z+A_z')/J].

The coefficient belongs to[-1,1], hence the absolute difference is bounded by the same coupling's integral|A_z-A_z'|. FIRST and the inclusive hard-scale envelope give integral beta ell integral nu A_z<=A_n Wnu for every finite hard source, without requiring its original same-R cap. The same holds for g. Thus both losses and the absolute transport integrand are integrable (bounded by2A_n Wnu). Countably many disjoint packets can be summed by positive Tonelli before the finite signed subtraction; no convergence of normalized quotients under row truncation is assumed. Zero-mass packets and empty rows contribute zero.

This is an exact signed identity, not itself a new source payment. It preserves the original receiver measure dx and original beta marginal. The all-radius L2 estimate may bound the new g first moment, but it does not pay the transport difference automatically.

## 2. Packet mean and variance: necessary J normalization

For a packet D of mass m>0 and p_z=A_z/J, define its mean and variance using ACTUAL normalized nu|D/m, not uniform volume. Then exactly

 integral_D f_J(A_z)nu(dz)=m J[barp_nu(1-barp_nu)-Var_nu(p)].

The factor J is necessary. The formula without J applies only after normalizing the loss by J. For the uniform averaged source g_D the corresponding mean and variance use dz/|D|. Therefore the exact packet difference is

 mJ[(barp_nu-barp_g)(1-barp_nu-barp_g)-Var_nu(p)+Var_g(p)].

The original actual-nu variance is favorable negative credit, but the uniform-source variance enters with the opposite sign in this difference. Neither a source ordering nor Jensen lets one discard that latter term or identify the two means. A shared packet law controls simultaneous capture indicators but does not imply their means coincide.

## 3. Precise scope of source and endpoint masks

A constant-in-z weight v(y,r) multiplies the complete identity directly. A source-dependent weight v(y,z,r) requires transporting the WHOLE product v(z)f_J(A_z). For example its difference is

 v(z)[f_J(A_z)-f_J(A_z')]+[v(z)-v(z')]f_J(A_z').

If instead the original v(z) is kept as an ancestral tag when z' is used for capture geometry, the averaged second marginal is a MARKED response, not the unweighted B_H(g). It may have receiver/prefix-dependent weighted marginals. It cannot be granted the one-g CZ budget without the appropriate domination proof.

The scalar variance formula requires the complete double-endpoint capture/miss product with common full J, or another explicitly verified scalar reduction. An arbitrary endpoint mask M(y,z,r,u,w), nonsymmetric distance priority, capacity-failure label, high-K source gate, or middle-packet rejection generally prevents that reduction. Their exact transported difference must keep each mask and capture factor, or pay the resulting mask-disagreement term. A threshold recomputed at z' is not the old threshold at z. In particular K_z and original e/m/history labels must be frozen and carried as ancestral marks unless an actual comparison is proved.

## 4. The signed core square cannot be replaced

For the original Phi_res(nu)=integral[N_res(z)-A_z²/J]nu(dz), exact transport requires

 integral Pi{N_res(z)-N_res(z')-[A_z²-A_z'²]/J}.

Here N_res(z') must either evaluate every actual predicate at z' (with its mask difference retained), or explicitly carry the original z predicates as tags. These are different, clearly declared objects. A bound on full physical B_H(nu) does not authorize replacing only E_full(nu) by E_full(g) in the existing core. No inequality E_full(nu)>=E_full(g) has been established.

Equivalently, if N_res=A-O_omit under the same original physical contract, then Phi_res=B_H(nu)-O_omit(nu). A transport comparison for B_H must retain the original omitted-baseline credit or its exact transported difference; it cannot silently change it. The whole square remains subtracted once, and the old posterior negative credits remain independent.

## 5. A safe boundary discrepancy upper bound and the missing saving

A universally valid geometric bound is

 |A_z-A_z'|<=integral_{R(u)<=r} U_y(u)|c_u(z)-c_u(z')|du.

After FIRST and the inclusive layer tail, its integral is bounded by

 integral_E R(u)^(-n) integral Pi(dz,dz')|c_u(z)-c_u(z')|du.

This is the actual source-coupling capture-boundary discrepancy. It makes no density assumption on nu. Thin packet diameter/receiver shell volume alone does not estimate its arbitrary concentrated original-source part. This positive boundary discrepancy, a cancellation in the SIGNED coefficient, or an actual comparison controlling all marked masks must be paid to obtain epsilon X_rho plus a root source fee. The exact transport and favorable source variance are useful contracts, but do not yet prove that missing estimate for the high-J/high-K, middle-rejected Phi_res.

## 6. Executed bounded local arithmetic and screen verdict

Actual standard-library Python Fraction run checked243 exact scalar transport/Lipschitz identities and12 packet mean/variance identities, total255 assertions PASS. The tests are finite algebra, not native/history or source-geometry realizations. Universal conclusions above are analytic.

Initial verdict: PASS for the frozen-field complete physical transport identity, countable-source summation, and packet actual-source mean/variance formula WITH its J factor. Masks and signed core require the stated additional terms. No general root transport or complete Phi_res payment is proved. Await author proof for bounded comparison; do not expand old history or repeat prior tests.

## 7. Independent first-G tag entropy screen, then author comparison

Before reading the new entropy proof, independently verified: on nonempty high-K sources the actual first-G tag probability tau_z has density<=S_z/(q_-G), S_z=sup_[a,b]h_t(x-z). With sigma_z=S_z dx/A_n, D=A_n/(q_-G)>=1 and0<=d tau/d sigma<=D. Therefore finite KL<=logD. Lift by the SAME density w(x) to canonical joint Q_z(dt,dx)=[delta_b+n dt/t]h_t(x-z)dx/A_n. The x marginal is exactly tau, joint KL is unchanged, and the entropy chain leaves an average conditional KL<=logD after dropping only a nonnegative scale-marginal KL.

The cube reference has log mgf<=t²||s||²/8 by one-coordinate endpoint convexity/cosh and product structure. Entropy/Jensen then gives2||mean(t)-z||²/t²<=conditionalKL. The resulting mean-bias budget is averaged under the ACTUAL lifted scale marginal, not the reference pi, and is<=.5logD. Zero scale fibers have zero actual mass and may be assigned arbitrary conditional laws. Measurability follows from the explicit original incidence kernel and first-crossing selection. This is a genuine conditional geometric budget on the SAME actual tag, not a capture/acceptance theorem or negative-square lower bound.

Read /tmp/r324_entropy.md in full after this screen: PASS for its exact S_z mixture, essential b atom, a=b endpoint, actual first-G law, finite entropy chain and uniform-cube constant. The auxiliary latent t is neither original selected R nor original r/clock. Source integration is once over the original high-source restriction. Its logarithmic D example is explicitly qualified; no general overlap or covariance estimate follows.

At primary's explicit request, actually executed python3 /tmp/r324_entropy_checks.py: exit0,264 checks PASS (168 mixture identities,12 probability masses,24 chain identities,24 bias inequalities,24 domination inequalities,12 precision comparisons). Exact fractions support mixture/mass; entropy arithmetic uses Decimal50/80 and is NOT an interval certificate. The finite positive-volume two-scale mixtures do not stand in for continuous original first-G tags. Their analytic proof is the preceding argument.

## 8. Full author transport comparison

Read /tmp/r324_transport.md in full only after the initial screen. PASS. Author uses moments of A (rather than p=A/J), so its variance factors1/J and packet formulas(9),(14) exactly agree with the J-corrected independent screen. The Jensen reference P is explicitly different from B_H(g): P-B_H(g)=sum m V_g/J. It is independently dominated by the ONE common g first moment, whose weighted FIRST/L2 bound is epsilon X_rho+C2²K Wnu/(2epsilon lambda), without radius-inflation factor or component FIRST.

The exact signed correction retains the two genuine negative terms -m(delta²+Vnu)/J. Away-from-half criterion(delta)(a-J/2)>=0 gives a true positive whole-scale original packet branch, paid by the simultaneous reference. Its failure retains the actual packet loss. Positive part of the signed debt is a correction integral, not original adverse subtraffic. No universal sign/capture coverage is inferred.

Ancestral source multiplier v(y,z,r)<=1 is kept at the original label; weighted actual source moments change, uniform tag mean stays a_D, reference mass m_v<=m, and the SAME g first-moment envelope still dominates. This is a valid domination proof for such marked weights. Arbitrary endpoint M remains excluded absent separate mask transport. It cannot replace the existing core's whole negative square or be added to R323's already-complete allocation as though disjoint.

## 9. Actual high-incidence tag payment on the original core

Read /tmp/r324_core.md fully. PASS. On S_G={K_z(b)>=G}, the measurable first crossing tau_z and proportional whole-radius crossing fraction select exactly G incidence mass. Cases k^-=G, zero crossing atom, tau=a and tau=b are legitimate; tag mass selection does NOT split or alter original high/low gates, original J/K atoms or ell. Every original current high-K prefix contains all the already-frozen tags.

Actual same-E, SAME-selected-R nu cap yields the tag marginal density mu<=4lambda/(q_-G), with mass nu(S_G) once. Insert exact tag acceptance a_z(u) into N_res, retaining all original gates/fullJ; cancel the old second endpoint only in a positive majorant. Then c_u(z)a_z(u) averaged in nu<=mu(Q_R(u)(u)). Weighted FIRST/L2/Young gives

 N_acc<=eta X_rho+C2² Wnu/(eta q_-G).

The exact positive complement N_rej retains original high-J/high-K, all previous core conditions and the old w endpoint; the signed replacement is Phi_next=N_rej-E_full with the ORIGINAL WHOLE square once. Its unfolded rejected triple is u captures z, tag v captures z, u misses center v; same-prefix compatibility is useful but supplies no uniform accepted fraction. The new v is never identified with old w. Outside high-K the positive term vanishes while the original square remains.

The same-prefix affinity L²<=p is a correct Cauchy-Schwarz lower criterion for a favorable signed contribution, not an established correlation bound for all actual rows. Packet actual-source variance is part of the retained square and cannot be added twice. The tag entropy density certificate and the main entropy lift preserve exactly this law.

Outer recovery adds2Lambda eta L_out[X_rho] and the genuine weighted new source fee once. M3 can bound it by2Lambda eta X_old only on its authenticated original slots; no H0/global absorption is created. G=H dependence is8C2²/(3eta sqrt(lambda d A_n)); it is not automatically1/sqrt(n). Choosing another G reassembles its prior low-K split consistently.

## 10. Numeric report scope (read, not reviewer rerun)

Read /tmp/r324_notes.md completely and inspected the entropy script. The source/receiver fixture is actual one-dimensional positive-volume L1 with a finite periodic full source, actual q=1 at both selected R=1,3/2, matched beta/nu ordering and FIRST/caps. Polynomial/log formulas and rigorous rational log-sign enclosures are distinguished from44 ordinary mpmath45/65-digit quadrature comparisons. Those comparisons are not interval quadrature. The fixture deliberately fails original hard lower band2lambda<h_R*f and does not implement complete low-pe/history/R323 core eligibility; nonempty high/high/middle must not be relabeled as complete core success. The numeric author's2157 assertions are reported evidence, not reviewer execution. The transport author's261 scalar checks and core author's17233 named diagnostic checks likewise do not replace the analytic all-input proofs.

Status before integration: PASS at the exact branch/identity scope. Remaining tasks are genuine rejected-triple/cross-capture-square and toward-half signed-drift estimates; no general root payment or full global entry is certified.

## 11. Final combined-ledger audit

Read the complete final checkpoint combined.md, SHA2569e4cb869ef6b4930c9c7364b455c4faf2a6ea7b8b23bacc531dc21402bd88192. PASS for this bounded integration. The primary line replaces exactly the old single2Lambda L_out[Phi_res] slot by the accepted tag source/occupancy fees plus2Lambda L_out[Phi_next]. All R323 low-K,CZ,source-shape and fixed-H aspect priority/fees remain once. The original complete E_full stays once in Phi_next. Neither the same-prefix tag law nor the entropy lift recomputes original e/m,K,J,source gates or actual receiver scales.

The full-B_H signed transport/reference formula is an ALTERNATIVE complete-entrance estimate. It is not inserted into the existing endpoint-masked core, nor charged in addition to the complete R323/R324 primary decomposition. Its favorable away-from-half branch and its unbounded toward-half debt have their proper distinct meanings.

Executed an additional exact Fraction assertion: with Lambda=128/119 and epsilon=eta=119/65536,2Lambda(epsilon+eta)=1/128. R323 allows arbitrary epsilon, and changing it changes the displayed CZ source coefficient but no source predicate. Under the authenticated M3 weighted occupancy bound, the total new old-output loss is1/128; without that matching keep actual L_out[X_rho]. This arithmetic does not solve unspecified older epsilon slots, the unknown historical entry coefficient, native H_rootleft or all-scale/small-dimension budgets.

The new entropy/bias theorem is a genuine measured property of the SAME true tag and may be integrated once over the high-source restriction. It does not make a lower bound for posterior cross-capture, source boundary mass, covariance or accepted fraction. No Schur upper bound or KL upper bound is converted into that missing lower-correlation estimate.

Primary's evidence count19915 is consistent:17233core+261transport+2157numeric+264entropy. Of these128 are ordinary high-precision comparisons (44 mpmath quadratures and84 Decimal entropy/precision comparisons), NOT exact interval certificates. Numeric's rational integrated/sign certificates are separately identified. The named core counter omits some additional assertions, and this is disclosed. Reviewer inspected actual core/transport PASS logs and summaries, and separately ran entropy264, initial scalar255, and one final calibration assertion; reviewer checks are not added to primary's19915. No MATLAB execution by this reviewer is claimed. The text's MATLAB product-reference table is clearly an auxiliary reference, not original-history realization or a proof of acceptance failure for every actual tag.

## 12. Final frozen hashes

- /Users/zhengzhihao/Desktop/T/output/centered_cube_round324_20261018_final_checkpoint/combined.md: 9e4cb869ef6b4930c9c7364b455c4faf2a6ea7b8b23bacc531dc21402bd88192

- /Users/zhengzhihao/Desktop/T/output/centered_cube_round324_20261018_final_checkpoint/core.md: 4275e6964f4cb4a622b4c1d56b94430d21c3d26aff7a22dafd80a7f7d34b95a2

- /Users/zhengzhihao/Desktop/T/output/centered_cube_round324_20261018_final_checkpoint/core_checks.log: 536a5194ddca337edb8c20b28c15bbb3ef20558440346e7168d7f39da78ad8b5

- /Users/zhengzhihao/Desktop/T/output/centered_cube_round324_20261018_final_checkpoint/core_checks.py: 84109b159df4e2886877c35fbc66e516810bd9566b73f10cac769697b366e091

- /Users/zhengzhihao/Desktop/T/output/centered_cube_round324_20261018_final_checkpoint/entropy.md: 67f8d0e78ba273dac3d276534fc26154b1d104a235bbf79ab915a0c786bc81a2

- /Users/zhengzhihao/Desktop/T/output/centered_cube_round324_20261018_final_checkpoint/entropy_checks.py: 356a78bd8ff09cb156c53f0bf5b226d1f79b45f00ebf3a8e4b9b795b77b9cb9b

- /Users/zhengzhihao/Desktop/T/output/centered_cube_round324_20261018_final_checkpoint/entropy_summary.json: 685f8c41e09d2e032e25494c2b92b84080241b283c62aa4d42af07fa59bc5340

- /Users/zhengzhihao/Desktop/T/output/centered_cube_round324_20261018_final_checkpoint/history.md: 66b8a727b93923f45495fe8f00de44c4449705fb0c94ba9322af6c99ae97de6b

- /Users/zhengzhihao/Desktop/T/output/centered_cube_round324_20261018_final_checkpoint/numeric.py: e2a09ff6f82b4151b17bb7d3d9f0bcbb9f2d3e905780cf0f137bda3526fc03ab

- /Users/zhengzhihao/Desktop/T/output/centered_cube_round324_20261018_final_checkpoint/numeric_notes.md: d578fe29b7665c69ae7ca1d9189796d7a8734fddd2ffb1ec5160fed7c2c15de0

- /Users/zhengzhihao/Desktop/T/output/centered_cube_round324_20261018_final_checkpoint/numeric_summary.json: 3435007b169b12db9d22cfcc6e20ab47fbb799d91fc321069ce68357393ba4b4

- /Users/zhengzhihao/Desktop/T/output/centered_cube_round324_20261018_final_checkpoint/requirements.txt: a699f46ed76bd216f1081b6b2330e4fb45d7c8c5a5354b208694d6590a5a8645

- /Users/zhengzhihao/Desktop/T/output/centered_cube_round324_20261018_final_checkpoint/transport.md: 78f85deb4eea4ba09c960ab4b74dc17cb265f28d95b02846ab6088038ecf1e2d

- /Users/zhengzhihao/Desktop/T/output/centered_cube_round324_20261018_final_checkpoint/transport_checks.log: 1ceb59129781a8a6fe87ab9f548a45ab26aac2d26facee9ef348673ecf23289e

- /Users/zhengzhihao/Desktop/T/output/centered_cube_round324_20261018_final_checkpoint/transport_checks.py: b6b0966c84231fdfed76c81ef10883241a165738a7e21fc1200b03cbaeb38a42


These bindings cover the three mathematics reports, combined.md, retained scripts/logs and diagnostic scope. history.md is bound as supplied reference metadata; its entire historical novelty search was not repeated. requirements.txt is metadata; no environment installation was performed. No later research.tex/PDF is covered by this receipt unless separately read and bound.

Final verdict: PASS for the proved exact signed identities, whole-scale favorable packet branch, actual high-incidence accepted-subintegral source payment, and same-law logarithmic conditional mean-bias budget. The GENERAL rejected-triple/cross-Gram Phi_next estimate, unfavorable packet drift, extreme-aspect complement, initial/deletion/future-deleted/suffix obligations, historical H0 entry and separate native/all-scale/small-dimension/outer-error linkage remain unproved. No claim of general centered-cube root closure or merely constant/logarithmic remainder is certified. Freeze this audit at these bytes; subsequent mathematics/integration changes require an explicit updated binding.
