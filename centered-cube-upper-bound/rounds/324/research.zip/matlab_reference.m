r324n=[1 2 4 8 16 32 64 128];
r324acc=(3/4).^r324n;
disp(table(r324n',r324acc',(sqrt(r324n).*r324acc)','VariableNames',{'n','uniform_cube_pair_acceptance','root_scaled_acceptance'}));
