"""Finite diagnostics only; analytic continuous-tag proof is entropy.md."""
from fractions import Fraction as F
from decimal import Decimal, localcontext
from itertools import product
import json

count={'envelope':0,'mass':0,'chain':0,'bias':0,'domination':0,'precision':0}
for n in (1,2,4,16,64,128):
    for a,b,d in product((F(1),F(3,2)),(F(2),F(3)),(F(0),F(1),F(3,2),F(2),F(5,2),F(3),F(4))):
        lo=max(a,d)
        mixture=F(0) if d>b else b**(-n)+(lo**(-n)-b**(-n))
        envelope=F(0) if d>b else lo**(-n)
        assert mixture==envelope
        count['envelope']+=1

def dec(q):return Decimal(q.numerator)/Decimal(q.denominator)
rows=[]
for n,mode in product((1,2,3,4),('halfspace','corner','asymmetric')):
    cells=[]
    for ii in product(range(4),repeat=n):
        # Positive-volume cells side 1/2 within Q_2; Q_1 is its central subgrid.
        center=tuple(F(2*i-3,4) for i in ii)
        in_small=all(i in (1,2) for i in ii)
        a0=F(1,2)*F(1,2)**n if in_small else F(0)
        a1=F(1,2)*F(1,4)**n
        if mode=='halfspace':w=F(5) if sum(center)>0 else F(1)
        elif mode=='corner':w=F(17) if all(v>0 for v in center) else F(1)
        else:w=F(1)+sum(F(j+1)*(v+1) for j,v in enumerate(center))
        cells.append((center,(a0,a1),w))
    norm=sum(sum(q)*w for _,q,w in cells)
    joint=[(x,q,tuple(w*v/norm for v in q)) for x,q,w in cells]
    marg=[sum(p[k] for _,_,p in joint) for k in (0,1)]
    assert sum(marg)==1;count['mass']+=1
    D=max(w/norm for _,_,w in cells)
    means=[tuple(sum(x[j]*p[k] for x,_,p in joint)/marg[k] for j in range(n)) for k in (0,1)]
    bias=2*sum(marg[k]*sum(v*v for v in means[k])/F(1+k)**2 for k in (0,1))
    outputs=[]
    for prec in (50,80):
        with localcontext() as ctx:
            ctx.prec=prec
            def kl(p,q):return dec(p)*dec(p/q).ln() if p else Decimal(0)
            total=sum(kl(p[k],q[k]) for _,q,p in joint for k in (0,1) if p[k])
            scale=sum(kl(m,F(1,2)) for m in marg)
            cond=sum(dec(marg[k])*sum(kl(p[k]/marg[k],q[k]/F(1,2)) for _,q,p in joint if p[k]) for k in (0,1))
            tol=Decimal(10)**(-prec+5)
            assert abs(total-scale-cond)<tol;count['chain']+=1
            assert dec(bias)<=cond+tol;count['bias']+=1
            assert total<=dec(D).ln()+tol;count['domination']+=1
            outputs.append((total,cond))
    assert all(abs(x-y)<Decimal('1e-43') for x,y in zip(*outputs));count['precision']+=1
    rows.append({'n':n,'mode':mode,'D':str(D),'twice_bias':str(bias),'KL_80':str(outputs[-1][0]),'conditional_KL_80':str(outputs[-1][1])})
print(json.dumps({'status':'PASS','counts':count,'total':sum(count.values()),'rows':rows,'scope':'finite positive-volume scale mixtures; Decimal consistency not interval certificate; continuous original-tag proof analytic'},indent=2))
