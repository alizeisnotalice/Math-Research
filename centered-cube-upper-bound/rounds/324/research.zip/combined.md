# 第324轮：真实前缀标记、条件几何偏移与完整平方

2026-10-18。一般 n^(1/2+o(1)) 一致弱型上界仍未闭合。本轮主线是 R323 的同一 Phi_res=N_res−E_full；另有完整 B_H 的有符号输运替代接口。两条接口不混加。

## 一、原入口及完整账本的继承

完整原积分与所有费用继承 rounds/322/research.zip::ledger.md，当前更新继承 rounds/323/research.zip::combined.md。历史 R_out 与 X_band 的 H0 入口仍缺，原生硬带 H_rootleft 也未与 B_H 建立同一性。以下只替换历史路线中已有的辅助边界槽，不宣称原事件已获上界。

R323 固定 H、同一 U,J,A,q,E,R、同一来源、同一正基线优先序均保留。当前 N_res 中有 J_y(r)>=H、K_z(r)>=G、旧近期/中间接收距离/形状失败门及中间 CZ 包的真实边界拒绝权。整个 E_full 在所有正分支之外扣一次。

## 二、高累计量产生合法的共同标记输入

原硬列 V_z(v)=1_E(v)c_v(z)/(q(v)R(v)^n)，K_z(r)=∫_{R<=r}V_z。
对 S_G={K_z(b)>=G}，按原 R 顺序取最先 G 质量，跨越门限的同半径原子按统一比例选取，得到冻结概率 T_z^G。只新标记律作比例选择，不分割原 J/K/ell 或其门。

新联合测度为1_S nu(dz) T_z^G(dv)，标记边缘 mu 满足

||mu||1=nu(S_G),  mu(v)<=4lambda/(q_-G).

当前 K_z(r)>=G 时全部标记仍在当前原前缀 R(v)<=r，并满足 c_v(z)=1。接受权 a_z(u)=T_z^G(Q_R(u)(u))。在原 N_res 内精确拆分 a 和1−a，得到

N_acc<=eta X_rho+C2²/(eta q_-G) W_nu,
Phi_res<=eta X_rho+C2²/(eta q_-G) W_nu+Phi_next,
Phi_next=N_rej−E_full.

X_rho=lambda∫rho，原强L2定理只用于新有界密度输入mu。没有修改原来源、原q或负平方。source gate G不同选择对应不同原剩余积分；不能只优化系数而不改门。

这个新付款来自高累计量本身，不是来源集中情形。没有统一接受比例，也没有把接受部分称为全部边界费用。剩余项含实际三点因子 c_u(z)c_v(z)(1−c_u(v))，并保留原w、全J及全部旧门。

## 三、同一标记律的对数几何预算

设 A_n=1+nlog(b/a)，canonical sigma_z=(sup_{a<=t<=b}h_t(x−z))dx/A_n。该密度精确等于 uniform Q_t(z) 的正混合，尺度分布 [delta_b+n dt/t]/A_n。注意这是辅助潜在尺度t，不是原实际R或层r。

T_z^G<=D sigma_z，D=A_n/(q_-G)>=1。把同一密度比提升到上述联合尺度/位置律，不改T_z^G的边缘。D04的真实条件熵链给出，按提升后实际尺度分布P_z^T平均，

E KL(P_z(dx|t)||unif Q_t(z))<=logD,
E ||m_z(t)−z||2²/t²<=.5logD.

第二式由乘积均匀参考的指数矩及熵Jensen直接证明，不假定实际坐标独立。取G=sqrt(n)/lambda，q_-=3lambda/4时 D<=8sqrt(n)/3，费用为O(log(n+2))，可按nu(S_G)来源一次积分。它是已证的条件均值偏移预算，不是实际边界质量、重叠下界或Phi_next预算。

## 四、有符号来源输运：作为完整B_H的替代接口

另从原完整B_H重新出发，用R323守恒CZ平均g。每个包固定同一A,J，记mu_D=E_nuD A、a_D=E_uniformD A、V_D=Var_nuD A、delta_D=mu_D−a_D。精确剩余为

R_D=m_D[delta_D(1−2a_D/J)−(delta_D²+V_D)/J].

整个B_H=P+R，其中P包括m_D[a_D−a_D²/J]和good来源原费用；P不等于B_H(g)，差值为均匀来源方差。一个共同g即给

P<=epsilon_tr X_rho+C2² K_CZ/(2epsilon_tr lambda)W_nu.

实际包均值远离J/2的正分支被此参考支付；有符号余项保留两个负二次项。该接口不能直接塞入含endpoint掩码的Phi_res；若选择此路线，整个B_H从入口重新估计，R323近/远/旧层/形状/CZ付款一并替换，不能重复收款。实际一维数值表明B_H(nu)−B_H(g)可变号，正负R_D均在正长度行区间出现，故不能省略剩余项。

## 五、主线总账更新与吸收校准

在R323完整combined总账仅作以下替换：

2Lambda L_out[Phi_res]
  <=2Lambda eta L_out[X_rho]
    +2Lambda L_out[C2²/(eta q_-G)||nu||+Phi_next],
Lambda=128/119.

R323原epsilon槽仍在；在M3认证后新旧接收项总系数为2Lambda(epsilon+eta)。取epsilon=eta=119/65536，合计恰为1/128。R323 theorem允许任意epsilon，此重选只改变已明确的源费，不改变其来源门/几何分割。全总系数依然是

E_original+1/128,
E_original=19/768+Lambda(epsilon_tree+delta_tail+k0 kappa_n+epsilon_LP)
 +epsilon_near+epsilon_FA+epsilon_IJ+epsilon_D+epsilon_G.

所有epsilon与未知H0入口尚未统一结清，故不能称全局吸收已证。参数若随外层变动，保留实际加权源费和L_out[X_rho]；没有免费逐时钟复制。

原固定H的显式尺度入口(8lambda H W_beta+2d_eff A_n/H W_nu)、近/远源费、旧层源费、B_rect形状费、lowK费lambdaG、CZ费及optional tiny-soft尾均按R323保留一次。宽源low-pe和extreme补集不被本轮三点变化替换。I_rem初始、J_rem真删除跳跃、D_rem未来被删来源连续项、P_suffix和其原负项系数仍为原2Lambda；终端good连续定理不支付这些独立义务。原全尺度桥、小维度及原生H_rootleft也不改变。

## 六、证据、实际工具与未解决决策

主代理实际fresh运行：core_checks.py 17233个计数的Fraction检查（另有不计数的质量等断言），transport_checks.py 261个Fraction检查，numeric.py 2157个检查，entropy_checks.py 264个检查，共19915个计数检查。其中numeric的44项为45/65位数值积分一致性，entropy的84项为Decimal50/80位熵一致性/比较；不能把它们称为精确区间证书。numeric的积分符号及正长度符号区间另有精确有理证书。各脚本范围与一般证明分列。

真实一维fixture保留同一f、nu<=beta<=f、真实q=h_R*f=1、两实际R和dx，但不满足原hard>2lambda带，不能称完整R323核心实现。高维tag脚本是有限原子几何诊断，不替代原L1证明。entropy有限混合检查不是原continuous tag实现。

本机MATLAB另运行均匀立方体两中心接受概率(3/4)^n表(n1至128)，显示密度分散本身不保证统一接受比例；它是参考几何而非原模型反例。Python数值使用现有mpmath，requirements.txt给版本；其余脚本仅标准库。没有模型实际扣额数据，不估算成本比例。

下一步集中于Phi_next的实际三点拒绝与原共享来源捕获平方的关系，使用已证的同前缀标记和对数几何偏移，不能把条件均值控制偷换成所需相关性。完整一般根阶预算仍未证明。本轮只保留必要归档，不编译PDF。
