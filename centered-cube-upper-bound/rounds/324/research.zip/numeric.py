#!/usr/bin/env python3
"""R324 actual 1D endpoint kernel: exact polynomial/log source transport."""
from fractions import Fraction as F
from math import comb
from collections import Counter
from pathlib import Path
import json,sys
try:import mpmath as mp
except ImportError:
 sys.path.insert(0,'/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor');import mpmath as mp
counts=Counter()
def ck(k,b):
 counts[k]+=1
 assert b,k

def trim(p):
 p=list(p)
 while len(p)>1 and p[-1]==0:p.pop()
 return p

def add(a,b):return trim([(a[i] if i<len(a) else 0)+(b[i] if i<len(b) else 0) for i in range(max(len(a),len(b)))])
def scale(p,c):return trim([x*c for x in p])
def sub(a,b):return add(a,scale(b,-1))
def mul(a,b):
 out=[F(0)]*(len(a)+len(b)-1)
 for i,x in enumerate(a):
  for j,y in enumerate(b):out[i+j]+=x*y
 return trim(out)
def val(p,x):return sum((v*x**i for i,v in enumerate(p)),F(0))
def integ(p,l,h):return sum((v*(h**(i+1)-l**(i+1))/(i+1) for i,v in enumerate(p)),F(0))
def mass(profile):return sum(((h-l)*d for l,h,d in profile),F(0))
def imass(profile,l,h):return sum((max(F(0),min(h,b)-max(l,a))*d for a,b,d in profile),F(0))
def fprofile(local):return [(a+j*F(1,2),b+j*F(1,2),d) for j in range(-3,5) for a,b,d in local]
def overlap(*intervals):return max(F(0),min(i[1] for i in intervals)-max(i[0] for i in intervals))
def Aactual(y,z,full):
 out=overlap((F(-1),F(0)),(y-F(1,2),y+F(1,2)),(z-F(1,2),z+F(1,2)))
 if full:out+=F(2,3)*overlap((F(0),F(1)),(y-F(3,4),y+F(3,4)),(z-F(3,4),z+F(3,4)))
 return out

def fixture(name):
 D=(F(-1,2),F(-1,4))
 if name=='twin':
  d1=(F(-1,2),F(-7,16));d2=(F(-5,16),F(-1,4))
  knots=sorted({*D,*d1,*d2,(d1[0]+d1[1])/2,(d2[0]+d2[1])/2});beta=[];nu=[]
  for a,b in zip(knots,knots[1:]):
   mid=(a+b)/2;inpacket=any(l<mid<h for l,h in [d1,d2]);peak=any(l<mid<(l+h)/2 for l,h in [d1,d2]);density=F(5) if peak else F(1)
   beta.append((a,b,density))
   if inpacket:nu.append((a,b,density))
  packets=[d1,d2]
 else:
  width={'initial':F(1,8),'reverse_narrow':F(1,16),'wide':F(3,16)}[name];height=1+F(1,4)/width
  peak=(D[1]-width,D[1]) if name=='reverse_narrow' else (D[0],D[0]+width)
  knots=sorted({*D,*peak});beta=[(a,b,height if peak[0]<(a+b)/2<peak[1] else F(1)) for a,b in zip(knots,knots[1:])];nu=list(beta);packets=[D]
 return dict(name=name,beta=beta,nu=nu,f=fprofile(beta),packets=packets)
# Bivariate polynomial integration of A and A² over z, yielding y-polynomials.
def moments(profile,full,ymid):
 out=[]
 for power in [1,2]:
  poly=[F(0)]
  for lo,hi,density in profile:
   pieces=[(lo,hi,hi<=ymid)] if not lo<ymid<hi else [(lo,None,True),(None,hi,False)]
   for lower,upper,zless in pieces:
    # A=ay(y)+az*z on the relevant side of z=y.
    ay=([F(1),F(-1)] if zless else [F(1),F(2,3)]) if full else ([F(1,2),F(-1)] if zless else [F(1,2)])
    az=(F(2,3) if zless else F(-1)) if full else (F(0) if zless else F(-1))
    for j in range(power+1):
     yp=[F(1)]
     for _ in range(power-j):yp=mul(yp,ay)
     coeff=comb(power,j)*az**j*density/F(j+1)
     for bound,sign in [(upper,1),(lower,-1)]:
      term=([F(0)]*(j+1)+yp) if bound is None else scale(yp,bound**(j+1))
      poly=add(poly,scale(term,coeff*sign))
  out.append(poly)
 return out

def integrate_ratio(numer,J,lo,hi):
 q=[F(0)]*max(1,len(numer)-1);r=trim(numer)
 while len(r)>=len(J) and any(r):
  degree=len(r)-len(J);c=r[-1]/J[-1];q[degree]+=c;r=sub(r,[F(0)]*degree+scale(J,c))
 constant=integ(q,lo,hi);coef=r[0]/J[1] if r else F(0);arg=val(J,hi)/val(J,lo)
 return constant,{arg:coef} if coef else {}
def expr_add(a,b):
 c=a[0]+b[0];logs=dict(a[1])
 for arg,v in b[1].items():logs[arg]=logs.get(arg,F(0))+v
 return c,{a:c for a,c in logs.items() if c}
def expression(P,S,J,lo,hi):
 c,l=integrate_ratio(S,J,lo,hi);return integ(P,lo,hi)-c,{a:-v for a,v in l.items()}
def evaluate(e,dps):
 with mp.workdps(dps):
  cv=lambda x:mp.mpf(x.numerator)/x.denominator
  return cv(e[0])+sum((cv(c)*mp.log(cv(a)) for a,c in e[1].items()),mp.mpf(0))
def log_interval(x,terms=32):
 if x==1:return F(0),F(0)
 if x<1:
  lo,hi=log_interval(1/x,terms);return -hi,-lo
 t=(x-1)/(x+1);lo=2*sum((t**(2*j+1)/F(2*j+1) for j in range(terms)),F(0));rem=2*t**(2*terms+1)/((2*terms+1)*(1-t*t))
 return lo,lo+rem
def expression_interval(e):
 lo=hi=e[0]
 for arg,c in e[1].items():
  a,b=log_interval(arg)
  if c>=0:lo+=c*a;hi+=c*b
  else:lo+=c*b;hi+=c*a
 return lo,hi
def encoded(e):return dict(rational=str(e[0]),logs=[dict(argument=str(a),coefficient=str(c)) for a,c in sorted(e[1].items())])
def bernstein_coefficients(poly,lo,hi):
 degree=len(poly)-1;shift=[F(0)]*(degree+1)
 for i,v in enumerate(poly):
  for j in range(i+1):shift[j]+=v*comb(i,j)*lo**(i-j)*(hi-lo)**j
 b=[sum((shift[i]*F(comb(j,i),comb(degree,i)) for i in range(j+1)),F(0)) for j in range(degree+1)]
 return b
def bernstein_sign(poly,lo,hi):
 b=bernstein_coefficients(poly,lo,hi)
 return 'nonpositive' if max(b)<=0 else 'nonnegative' if min(b)>=0 else 'mixed'

def run(model):
 beta,nu,fullf,packets=[model[k] for k in ['beta','nu','f','packets']];g=[(l,h,imass(nu,l,h)/(h-l)) for l,h in packets];CZ=F(3,2)
 ck('same_source_orders',all(imass(nu,a,b)<=imass(beta,a,b)<=imass(fullf,a,b) for a,b,_ in beta))
 for a,b,d in beta:
  mid=(a+b)/2;density=lambda profile:sum(dd for aa,bb,dd in profile if aa<mid<bb)
  ck('pointwise_source_orders',density(nu)<=density(beta)<=density(fullf))
 ck('CZ_mass_conservation',mass(g)==mass(nu))
 gL2=sum(((b-a)*d*d for a,b,d in g),F(0))
 ck('same_good_source_L2',gL2<=2*CZ*mass(g) and max(d for a,b,d in g)<=2*CZ)
 for l,h in packets:
  ck('CZ_bad_average',imass(nu,l,h)/(h-l)>CZ)
  length=h-l;parentlo=(l//(2*length))*(2*length)
  ck('CZ_parent_not_bad',imass(nu,parentlo,parentlo+2*length)/(2*length)<=CZ)
 for R,elo,ehi in [(F(1),F(-1),F(0)),(F(3,2),F(0),F(1))]:
  knots=sorted({elo,ehi}|{z+sign*R/2 for a,b,d in fullf for z in [a,b] for sign in [-1,1] if elo<z+sign*R/2<ehi})
  for lo,hi in zip(knots,knots[1:]):
   for x in [lo,(lo+hi)/2,hi]:
    q=imass(fullf,x-R/2,x+R/2)/R;rho=imass(beta,x-R/2,x+R/2)/R
    ck('actual_q_exact',q==1);ck('actual_FIRST',rho<=1);ck('actual_sameR_cap',imass(nu,x-R/2,x+R/2)<=4*R)
 samples=sorted({a for a,b,d in beta}|{b for a,b,d in beta}|{(a+b)/2 for a,b,d in beta})
 totals={key:(F(0),{}) for key in ['Bnu','Bg','reference','debt','firstg']};signs=Counter();sampledebt=[];numeric_error=mp.mpf(0);precision_errors={45:mp.mpf(0),65:mp.mpf(0)};quadchecks=0;sign_intervals={}
 for full,weight in [(False,F(1,3)),(True,F(2,3))]:
  J=[F(1),F(-1,3)] if full else [F(1,2),F(-1)]
  for y,z in [(F(-49,100),F(-27,100)),(F(-49,100),F(-26,100)),(F(-48,100),F(-27,100)),(F(-48,100),F(-26,100))]:
   aa=Aactual(y,z,full);ck('positive_volume_middle_vertices',F(1,8)*val(J,y)<aa<F(7,8)*val(J,y))
  ck('positive_volume_middle_sources',imass(beta,F(-49,100),F(-48,100))>0 and imass(nu,F(-27,100),F(-26,100))>0)
  for y in samples:
   ck('double_high_J_K',val(J,y)>=F(3,4))
   for z in samples:
    A=Aactual(y,z,full);formula=(1-max(y,z)+F(2,3)*min(y,z)) if full else F(1,2)-max(y,z)
    ck('actual_capture_integral',A==formula)
    zp=samples[-1-samples.index(z)];Ap=Aactual(y,zp,full);jy=val(J,y)
    ck('pointwise_signed_transport',A-A*A/jy-(Ap-Ap*Ap/jy)==(A-Ap)*(1-(A+Ap)/jy))
  for l,h,bd in beta:
   knots=sorted({l,h}|{v for a,b,d in nu+g for v in [a,b] if l<v<h})
   for lo,hi in zip(knots,knots[1:]):
    mid=(lo+hi)/2;Pn,Sn=moments(nu,full,mid);Pg,Sg=moments(g,full,mid)
    for key,P,S in [('Bnu',Pn,Sn),('Bg',Pg,Sg),('firstg',Pg,[F(0)])]:
     e=expression(scale(P,bd*weight),scale(S,bd*weight),J,lo,hi);totals[key]=expr_add(totals[key],e)
    for pl,ph in packets:
     prof=[(max(pl,a),min(ph,b),d) for a,b,d in nu if max(pl,a)<min(ph,b)];m=mass(prof)
     pn,sn=moments(prof,full,mid);ag,sg=moments([(pl,ph,F(1,ph-pl))],full,mid)
     mu=scale(pn,1/m);second=scale(sn,1/m);debtP=sub(mu,ag);debtS=sub(second,mul(ag,ag));N=sub(mul(J,debtP),debtS)
     refP=scale(ag,m);refS=scale(mul(ag,ag),m)
     ck('packet_reference_identity_P',add(refP,scale(debtP,m))==pn)
     ck('packet_reference_identity_S',add(refS,scale(debtS,m))==sn)
     for key,P,S in [('reference',refP,refS),('debt',scale(debtP,m),scale(debtS,m))]:totals[key]=expr_add(totals[key],expression(scale(P,bd*weight),scale(S,bd*weight),J,lo,hi))
     signs[bernstein_sign(N,lo,hi)]+=1
     for y in [lo+(hi-lo)/4,mid,lo+3*(hi-lo)/4]:
      jy=val(J,y);mn=val(mu,y);aa=val(ag,y);vn=val(second,y)-mn**2;vg=val(sg,y)-aa**2;debt=val(N,y)/jy
      ck('packet_variances_nonnegative',vn>=0 and vg>=0)
      ck('packet_signed_delta',val(pn,y)-val(sn,y)/jy-m*(aa-val(sg,y)/jy)==m*((mn-aa)*(1-(mn+aa)/jy)+(vg-vn)/jy))
      ck('reference_good_source_variance',m*(aa-aa*aa/jy)-m*(aa-val(sg,y)/jy)==m*vg/jy)
      ck('reference_below_firstmoment',0<=m*(aa-aa*aa/jy)<=m*aa)
      ck('packet_debt_formula',debt==(mn-aa)*(1-2*aa/jy)-((mn-aa)**2+vn)/jy)
      ck('away_from_half_paid',not ((mn-aa)*(aa-jy/2)>=0) or debt<=0)
      sampledebt.append(debt)
      if debt and ('positive' if debt>0 else 'negative') not in sign_intervals:
       label='positive' if debt>0 else 'negative';radius=(hi-lo)/16
       for _ in range(40):
        left=max(lo,y-radius);right=min(hi,y+radius);coeffs=bernstein_coefficients(N,left,right)
        if (min(coeffs)>0 if debt>0 else max(coeffs)<0):break
        radius/=2
       ck('debt_positive_volume_sign_certificate',left<right and (min(coeffs)>0 if debt>0 else max(coeffs)<0))
       sign_intervals[label]=dict(row_interval=[str(left),str(right)],packet=[str(pl),str(ph)],prefix='full' if full else 'R1',point_debt=str(debt))
    # Independent ordinary high precision quadrature of exact inner moments.
    e=expression(scale(Pn,bd*weight),scale(Sn,bd*weight),J,lo,hi)
    for dps in [45,65]:
     with mp.workdps(dps):
      cv=lambda x:mp.mpf(x.numerator)/x.denominator
      pv=lambda p,y:sum(cv(c)*y**i for i,c in enumerate(p))
      q=mp.quad(lambda y:cv(bd*weight)*(pv(Pn,y)-pv(Sn,y)/pv(J,y)),[cv(lo),cv(hi)])
      err=abs(q-evaluate(e,dps));ck('analytic_vs_quad',err<mp.mpf(10)**(-(dps-8)));numeric_error=max(numeric_error,err);precision_errors[dps]=max(precision_errors[dps],err);quadchecks+=1
 ck('integrated_reference_plus_debt',expr_add(totals['reference'],totals['debt'])==totals['Bnu'])
 difference=expr_add(totals['Bnu'],(-totals['Bg'][0],{a:-c for a,c in totals['Bg'][1].items()}))
 intervals={key:expression_interval(expr) for key,expr in [('Bnu_minus_Bg',difference),('debt',totals['debt']),('reference_minus_Bg',expr_add(totals['reference'],(-totals['Bg'][0],{a:-c for a,c in totals['Bg'][1].items()})))]}
 ck('integrated_transport_sign_rational_certificate',intervals['Bnu_minus_Bg'][0]>0 or intervals['Bnu_minus_Bg'][1]<0)
 ck('integrated_debt_negative_rational_certificate',intervals['debt'][1]<0)
 ck('reference_good_Jensen_gap_rational_certificate',intervals['reference_minus_Bg'][0]>0)
 return dict(name=model['name'],H='3/4',G='3/4',lambda_value='1',K_CZ='3/2',same_good_source_L2_squared=str(gL2),beta_mass=str(mass(beta)),nu_mass=str(mass(nu)),beta=[list(map(str,p)) for p in beta],nu=[list(map(str,p)) for p in nu],CZ_packets=[list(map(str,p)) for p in packets],expressions={k:encoded(e) for k,e in totals.items()},values={k:mp.nstr(evaluate(e,65),25) for k,e in totals.items()},Bnu_minus_Bg=mp.nstr(evaluate(expr_add(totals['Bnu'],(-totals['Bg'][0],{a:-c for a,c in totals['Bg'][1].items()})),65),25),integrated_sign_certificates={key:dict(sign='positive' if lo>0 else 'negative' if hi<0 else 'unresolved',lower=str(lo),upper=str(hi)) for key,(lo,hi) in intervals.items()},debt_sign_intervals=sign_intervals,debt_Bernstein_segments=dict(signs),sample_debt_min=str(min(sampledebt)),sample_debt_max=str(max(sampledebt)),sample_debt_positive=sum(d>0 for d in sampledebt),sample_debt_negative=sum(d<0 for d in sampledebt),quad_checks=quadchecks,max_quad_error=mp.nstr(numeric_error,8),quad_error_by_precision={str(p):mp.nstr(e,8) for p,e in precision_errors.items()})
def main():
 reports=[];stages=[]
 for stage,names in [('initial',['initial']),('boundary_reverse_width',['reverse_narrow','wide']),('twin_source',['twin'])]:
  before=sum(counts.values());reports.extend(run(fixture(name)) for name in names);stages.append(dict(stage=stage,fixtures=names,checks=sum(counts.values())-before))
 print(json.dumps(dict(mpmath_loaded_from=mp.__file__,status='PASS',check_counts=dict(counts),total_checks=sum(counts.values()),stages=stages,fixtures=reports,scope='Actual 1D positive-L1 same-input endpoint-kernel geometry with exact piecewise polynomial/log integration and ordinary45/65digit quadrature checks; not root/history or nonemptyR323core certification.'),sort_keys=True))
if __name__=='__main__':main()
