# R324 — exact signed source transport and a whole-scale packet-mean receipt

**Scope.** Keep the original receiver weights `U`, full prefix `J`, actual capture functions `A`, and `J≥H` gate. The R323 binary stopping average supplies a real feasible source coupling. Its signed variance transport has an exact decomposition into one already-priceable averaged-source reference and a signed packet-mean drift with two negative quadratic terms. This pays a whole-scale positive branch where the source packet mean moves away from capture probability `1/2`. No assertion that this branch covers arbitrary inputs, or that the remaining signed drift has a universal root price, is made.

The reference uses R319/R323's authorized maximal-L² machinery. The new content is the exact signed drift/credit interface and its natural nonpositive branch, not a new general maximal theorem or a claim that transport alone pays the full loss. No arbitrary Kantorovich dual is used: all transport statements below are direct calculations for the explicit positive coupling.

## 1. Original fields and one source-preserving coupling

Use the R323 original contract: `ν,β` are finite positive L¹ sources, `a≤R(u)≤b`,

\[
 \rho(u)=\int U_y(u)\beta(dy)\le1_E(u),\qquad
 X_\rho=\lambda\int\rho(u)du<\infty,
\]
\[
 J=J_y(r)=\int_{R(u)\le r}U_y(u)du,\quad
 A_z=A_{yz}(r)=\int_{R(u)\le r}U_y(u)1_{Q_{R(u)}(u)}(z)du,
\]
\[
 \ell_n=b^{-n}\delta_b+nr^{-n-1}1_{[a,b]}dr,
 \quad \ell_n([R,b])=R^{-n},\quad A_n=1+n\log(b/a).       \tag{1}
\]

All rows are the original finite rows. In particular `0≤A_z≤J`; every expression below is only evaluated at `J≥H>0`. Any endpoint restriction remains in its original numerator/mask, not in a rebuilt denominator. For this scalar variance theorem the target is the original full capture square

\[
 B_\nu=\int\beta(dy)\ell_n(dr)1_{J\ge H}
          \int \phi_J(A_z)\nu(dz),
 \qquad \phi_J(a)=a-a^2/J.                              \tag{2}
\]

This is the original oriented capture/miss loss after integrating both receivers, with no component FIRST. General endpoint-dependent pair qualifications require an additional comparison; they cannot silently be inserted into (2). An original ancestral weight `v(y,z,r)∈[0,1]` is treated separately in §5.

Fix `K>0` and the R323 cyclic binary grid. Its maximal high-average source boxes form a disjoint family `𝒟`, with

\[
 K|D|<m_D:=\nu(D)\le2K|D|,\qquad
 \nu|_{\Omega^c}\le K\,dz,\quad \Omega=\bigcup_DD.
\]

Define the same source average and the SAME frozen coupling for all rows:

\[
 g=1_{\Omega^c}\frac{d\nu}{dz}
             +\sum_D\frac{m_D}{|D|}1_D,
 \quad 0\le g\le2K,\quad\int g=W_\nu,\quad
 \|g\|_2^2\le2KW_\nu,                                  \tag{3}
\]
\[
 \mathcal C(dz,dz')=\nu|_{\Omega^c}(dz)\delta_z(dz')
        +\sum_D\nu|_D(dz)\frac{1_D(z')}{|D|}dz'.          \tag{4}
\]

Its marginals are exactly `ν` and `g dz'`. Tags are uniform only conditionally on the frozen source packet, independent of receivers. The original ancestor `z` and every original gate remain available. Neither `ν` nor the full input is given a density cap; only the legitimate new test input `g` has (3).

## 2. Exact signed transport; absolute boundary mass is not substituted

For every actual row/scale and coupled pair,

\[
 \phi_J(A_z)-\phi_J(A_{z'})
 =(A_z-A_{z'})\left[1-\frac{A_z+A_{z'}}J\right].          \tag{5}
\]

Thus, writing `B_g` for (2) with source density `g`,

\[
 B_\nu-B_g=\int\beta(dy)\ell_n(dr)1_{J\ge H}
     \int (A_z-A_{z'})\left[1-\frac{A_z+A_{z'}}J\right]
                   \mathcal C(dz,dz').                  \tag{6}
\]

The actual capture difference is

\[
 A_z-A_{z'}=\int_{R(u)\le r}U_y(u)
       [1_{Q_{R(u)}(u)}(z)-1_{Q_{R(u)}(u)}(z')]du.        \tag{7}
\]

The bracket is signed true source-boundary crossing. It is not boundary volume times an assumed source density. Finite signed interchange in (6) is valid: `|φ_J(A_z)−φ_J(A_z')|≤A_z+A_z'`, whose full integral is at most `2A_nWν` by original FIRST and the two source marginals. The positive and negative transport terms therefore both exist. Physical radius atoms and the terminal `b` atom in `ell_n` are included without a differentiability assumption.

At a fixed row/scale and packet define

\[
 \mu_D=\frac1{m_D}\int_D A_z\nu(dz),\quad
 a_D=\frac1{|D|}\int_D A_{z'}dz',
\]
\[
 V_{\nu,D}=\frac1{m_D}\int_D(A_z-\mu_D)^2\nu(dz),
 \qquad V_{g,D}=\frac1{|D|}\int_D(A_{z'}-a_D)^2dz'.       \tag{8}
\]

These are source moments of the SAME original capture function, not new receiver posteriors or replacement kernels. Taking the product coupling inside `D` gives the exact formula

\[
 \int_{D\times D}[\phi_J(A_z)-\phi_J(A_{z'})]d\mathcal C
 =m_D\left[(\mu_D-a_D)\left(1-\frac{\mu_D+a_D}J\right)
                 +\frac{V_{g,D}-V_{\nu,D}}J\right].      \tag{9}
\]

In particular neither source variance has a generally favorable sign relative to the other. Uniform averaging is not automatically an upper comparison for the concave capture cost.

## 3. The Jensen reference is larger than `B_g`, but pays once

Define the source-averaged reference at each row/scale by

\[
 P_{y,r}=\int_{\Omega^c}\phi_J(A_z)\nu(dz)
                 +\sum_Dm_D\phi_J(a_D),
 \quad \mathcal P=\int\beta(dy)\ell_n(dr)1_{J\ge H}P_{y,r}.
                                                               \tag{10}
\]

It is NOT `B_g`. Precisely,

\[
 \mathcal P=B_g+\int\beta(dy)\ell_n(dr)1_{J\ge H}
                       \sum_D\frac{m_DV_{g,D}}J\ge B_g.  \tag{11}
\]

This difference is uniform-source variance, not a new source fee. Since `0≤φ_J(a)≤a`, the whole reference simultaneously satisfies

\[
 \mathcal P\le\int\beta(dy)\ell_n(dr)1_{J\ge H}
                     \int g(z)A_z\,dz
 \le\int\rho(u)h_{R(u)}*g(u)du
 \le C_2\sqrt{\int\rho}\,\|g\|_2.                      \tag{12}
\]

The middle inequality keeps the original full prefix and then uses the exact tail in (1) and original FIRST. The last uses `ρ²≤ρ` and the dimension-uniform all-radius centered-cube L² bound verified in R323 §1. It applies to the valid `g`; no component FIRST or original-source L² assumption is made. Thus for every `ε>0`,

\[
 \boxed{\ \mathcal P\le\varepsilon X_\rho
          +\frac{C_2^2\|g\|_2^2}{4\varepsilon\lambda}
 \le\varepsilon X_\rho
          +\frac{C_2^2K}{2\varepsilon\lambda}W_\nu.\ }    \tag{13}
\]

No R323 inflation factor or small/large relative-scale split appears in this reference payment. For `K=λ√n` it has root source cost at every original scale. It does not pay the still-unbounded transport drift in the next formula.

## 4. Exact drift minus genuine source credits; a paid positive branch

Put `δ_D=μ_D−a_D`. The original packet cost has the exact identity

\[
 \int_D\phi_J(A_z)\nu(dz)
 =m_D\phi_J(a_D)+\mathcal R_D,
\]
\[
 \boxed{\ \mathcal R_D=m_D\left[
    \delta_D\left(1-\frac{2a_D}J\right)
             -\frac{\delta_D^2+V_{\nu,D}}J\right].\ }     \tag{14}
\]

Consequently, with

\[
 \mathcal R=\int\beta(dy)\ell_n(dr)1_{J\ge H}\sum_D\mathcal R_D,
\]

\[
 \boxed{\ B_\nu=\mathcal P+\mathcal R
 \le\varepsilon X_\rho+
        \frac{C_2^2K}{2\varepsilon\lambda}W_\nu
       +\mathcal R.\ }                                  \tag{15}
\]

The terms `−m_Dδ_D²/J` and `−m_DVν,D/J` are both retained. All terms are integrable: the source/average first moments dominate the needed quadratic moments because `0≤A≤J`. Equation (15) may be used as a signed ledger; an upper positive error is `∫βell1_{J≥H}Σ_D(ℛ_D)_+`. That positive error is a correction integral, not the original positive adverse subtraffic.

A directly checkable sufficient nonpositive condition is

\[
 (\mu_D-a_D)(a_D-J/2)\ge0.                              \tag{16}
\]

It says the actual source mean lies at least as far in the same direction from `J/2` as its uniform tag mean: the shift is away from capture probability `1/2`. Under (16), the drift term in (14) is nonpositive, so `ℛ_D≤−m_D(δ_D²+Vν,D)/J≤0`. More generally the exact sufficient-and-necessary packet comparison with this particular reference is

\[
 J\delta_D(1-2a_D/J)\le\delta_D^2+V_{\nu,D}.              \tag{17}
\]

This permits an inward mean shift when its actual source variance pays the drift.

For an **actual positive branch**, insert the packet/row/scale indicator of (16) into the original packet loss, and include the original good source `Ωᶜ`. This branch, denoted `B_away`, obeys

\[
 B_{\rm away}\le\mathcal P
       \le\varepsilon X_\rho+
                 \frac{C_2^2K}{2\varepsilon\lambda}W_\nu. \tag{18}
\]

Its exact positive complement is the original packet loss on the failure of (16), with the same `U,J,A`, not a transported input. One may instead choose the larger favorable gate (17), still with one reference payment. No separate `Wν` charge is needed for every favorable packet, row, sign, or scale: their references are dominated simultaneously by (12). If the aggregate signed `ℛ≤0`, (15) pays the ENTIRE original `Bν` at the same price. The current contract does not prove either this aggregate inequality or any uniform favorable coverage.

These are whole-scale statements: no favorable small physical window, `ns≤D`, or source-density hypothesis is added. They are an alternative to R323's relative-scale/tag allocation; the full payments from the two routes must not be added as though they were disjoint. Applying this scalar identity directly to R323's endpoint-dependent boundary mask would require transporting that mask as well, so it is not claimed here.

## 5. Original ancestral weights and the precise unpaid flux

For a fixed original `v(y,z,r)∈[0,1]`, define `B_v` by inserting `v` into (2). In the coupling retain `v(y,z,r)` at the ORIGINAL ancestor in both terms of (5); do not recompute it at `z'`. At a fixed row/scale set

\[
 m_{v,D}=\int_Dv\,d\nu,\quad
 \mu_{v,D}=m_{v,D}^{-1}\int_DvA\,d\nu,\quad
 V_{v,D}=m_{v,D}^{-1}\int_Dv(A-\mu_{v,D})^2d\nu.
\]

Zero-weight packets contribute zero. Because the uniform tag is independent conditionally on `D`, its mean stays `a_D`, while the reference mass is `m_v,D≤m_D`. Replace `m_D,μ_D,Vν,D` by `m_v,D,μ_v,D,Vv,D` in (14). The good-source reference likewise keeps its original `v`. Its total is still dominated by the SAME `g` first-moment bound (12), since `v≤1`. Hence (13)–(18) hold with these replacements and the same source fee. These weighted source moments are only exact accounting for the original mark; they do not alter a kernel, `J`, or source response.

This covers the original source-dependent tent weight when the target has the full capture-square form. For an endpoint-dependent `M(y,z,r,u,w)`, or another gate not reducible to an ancestral multiplier of (2), a separate mask-transport term is required. The scalar result cannot be imported by changing notation.

The remaining signed term has an explicit actual geometric meaning. Let

\[
 \eta_D(u)=\nu(D\cap Q_{R(u)}(u))/m_D,
 \quad \theta_D(u)=|D\cap Q_{R(u)}(u)|/|D|.
\]

Then, in the unweighted version,

\[
 \delta_D=\int_{R(u)\le r}U_y(u)[\eta_D(u)-\theta_D(u)]du. \tag{19}
\]

Only partial packets can contribute. The unpaid flux in (14) is the signed actual capture imbalance in (19), multiplied by `1−2a_D/J`, AFTER subtracting its squared mean displacement and source variance. FIRST gives a column bound after summing the actual `U`, but does not by itself control this row-dependent signed multiplier or compare `η_D` with `θ_D`. Same-radius hard caps constrain captured mass, not its sign relative to the uniform tag. Domination `ν≤βᶜ≤f` on a matched lineage similarly supplies no such correlation automatically. Thus no source-root bound for the remaining toward-half surplus is asserted.

This states a precise missing geometric estimate: an integrated upper bound on `Σℛ_D` (or its positive part) with the stated original weights, retaining both negative terms of (14). Replacing (19) by its absolute boundary first moment returns the old R318/R323 boundary budget, potentially of order `A_nWν`; it is not new payment. The exact formula permits genuine favorable cancellation, but the theorem does not assume that cancellation for arbitrary sources.

For outer aggregation the new loss is `εXρ`, so the certified FIRST/M3 budget is the weighted sum of `λ∫ρ`, not an unproved sum of receiver-set volumes. All source fees carry their actual outer weights and original source-conservation ledger. A global absorption still requires the original finite entrance and its available loss reserve.

## 6. Executed exact scalar diagnostics

The following local Python/Fraction run passed **261 exact assertions on 48 source/tag moment configurations**. It verifies both transport formulas, the distinction between actual `B_g` and the Jensen reference, and the away-from-half sign. Signed debts were positive in 3 cases and negative in 45, so these formulas alone do not certify universal cancellation. This is scalar evidence, not an original cube-kernel/history realization. Actual L¹ receiver/source diagnostics belong to the separate numeric author's packet.

```python
from fractions import Fraction as F
from itertools import product
ct=dict(coupling=0,mean_variance=0,jensen=0,debt=0,reference_bound=0,away=0)
pos=neg=zero=0
weights=((1,1,1),(1,5,1),(1,1,5),(5,1,1))
for J,sw,tw in product((F(1),F(2),F(7,3)),weights,weights):
    a=(F(0),J/3,J)
    p=tuple(F(v,sum(sw)) for v in sw)
    q=tuple(F(v,sum(tw)) for v in tw)
    phi=lambda x:x-x*x/J
    mu=sum(x*w for x,w in zip(a,p)); c=sum(x*w for x,w in zip(a,q))
    V=sum(w*(x-mu)**2 for x,w in zip(a,p))
    Vg=sum(w*(x-c)**2 for x,w in zip(a,q))
    Cv=sum(w*phi(x) for x,w in zip(a,p))
    Cg=sum(w*phi(x) for x,w in zip(a,q))
    trans=sum(p[i]*q[j]*(a[i]-a[j])*(1-(a[i]+a[j])/J)
              for i in range(3) for j in range(3))
    assert trans==Cv-Cg; ct['coupling']+=1
    assert Cv-Cg==(mu-c)*(1-(mu+c)/J)+(Vg-V)/J
    ct['mean_variance']+=1
    assert phi(c)-Cg==Vg/J>=0; ct['jensen']+=1
    debt=(mu-c)*(1-2*c/J)-((mu-c)**2+V)/J
    assert Cv==phi(c)+debt; ct['debt']+=1
    assert 0<=phi(c)<=c; ct['reference_bound']+=1
    if (mu-c)*(c-J/2)>=0:
        assert debt<=0; ct['away']+=1
    pos+=debt>0; neg+=debt<0; zero+=debt==0
print('PASS',ct,'total',sum(ct.values()),
      'debt_signs',dict(positive=pos,negative=neg,zero=zero))
```

Only `/tmp/r324_transport.md` is authored here. No other author's files or Git were changed.
