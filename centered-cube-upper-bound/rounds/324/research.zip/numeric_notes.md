# R324 actual shared-source 1D diagnostic

The standalone script passes 2,157 assertions in three stages: initial329; reversed/narrow and wide peaks658; twin source packets1,170. It uses actual positive-volume L1 sources and exact receiver dx. Polynomial identities, packet moments and source/geometry gates use Fractions. Integrated answers are exact rational-plus-log expressions. Their signs are certified by rational log-series enclosures; ordinary 45/65-digit quadrature independently checks the analytic antiderivatives. The script prints deterministic JSON and writes no result file.

## Actual input and thresholds

Set a=lambda=1,b=2,E=[-1,1]. On x<0 take s=0,L=R=1; on x>=0 take s=0,L=R=3/2; alpha=1. The complete finite source f repeats a half-unit-period profile on[-2,2], with mass1/2 per period. Its central supported half-period is D=[-1/2,-1/4]. Every actual receiver window lies in this finite source region and has an integer number of periods, so the actual q=h_R*f=1 everywhere on E. The script independently verifies this on every affine convolution segment, including endpoints. With beta<=f, the actual rho=integral U_y beta<=1; actual nu caps also hold. No input is replaced to achieve q.

For the first three fixtures beta=nu=f restricted to D, of mass1/2. On D the baseline density is1 and a peak of width w has height1+1/(4w), preserving mass1/2. Initial w=1/8 is at the left end; reverse/narrow w=1/16 is at the right end; wide w=3/16 is at the left end. The rest of each half-unit period is zero. Binary-CZ threshold is K_CZ=3/2. The maximal bad dyadic interval is D, average2; its dyadic parent[-1/2,0] has average1. Its good-source replacement is density2 on D, preserving nu mass.

The twin fixture has bad packets D1=[-1/2,-7/16] and D2=[-5/16,-1/4], each of width1/16. Nu has density5 on the first half and1 on the second half of each packet, and zero outside them. Beta=f|D has those same peaks but density1 also on the intervening part of D. Thus nu<=beta<=f pointwise, W_beta=1/2, W_nu=3/8. Each packet has average3; its length1/8 parent has average3/2, exactly NOT bad. The good source g is density3 on those packets. The same-g L2 squares are1 in the first three fixtures and9/8 in twin, all <=2K_CZ W_nu.

## Exact physical J, K and A

For y,z in D, the original fields are computed by interval intersections on E. For prefix1:

    J_y=K_y=1/2-y,
    A_yz=1/2-max(y,z).

For prefix3/2 and every later layer:

    J_y=K_y=1-y/3,
    A_yz=1-max(y,z)+(2/3)min(y,z).

The script compares these formulas with actual capture integrals. Fix H=G=3/4, strictly rational diagnostic thresholds rather than final root-optimized values. Both source sides are high in both prefixes. The source rectangle y in[-.49,-.48], z in[-.27,-.26] has positive beta-times-nu measure in ALL fixtures and 1/8<A/J<7/8. Affine numerator inequalities checked at its four vertices certify the whole rectangle. Thus high/high and middle rejection are nonempty for the actual fields.

The ell weights are1/3 for [1,3/2) and2/3 for [3/2,2], including terminal atom1/2 at b=2. Every BH integral retains the SAME original beta,U,J,q; only the second hard source nu is compared with g. This is the full BH transport comparison, not a replacement of a square inside an unrelated residual.

## Exact source transport and reference debt

For every packet and fixed actual row, define mu=E_nu A, a=E_uniform A, Vnu and Vg. The script checks

    deltaB = m[(mu-a)(1-(mu+a)/J)+(Vg-Vnu)/J],
    BH_nu,packet = m[a-a²/J] + m debt,
    debt=(mu-a)(1-2a/J)-[(mu-a)²+Vnu]/J.

It also checks the ORIGINAL pointwise signed transport identity (A-A')[1-(A+A')/J] on actual A fields, the away-from-half implication, and the distinction

    reference - BH_g,packet = m Vg/J >=0.

The reference is bounded by the SAME good-source first moment, not a redefined kernel or q. No root L2 theorem constant is asserted by this experiment.

|fixture|BH_nu|BH_g|BH_nu-BH_g|integrated reference debt|
|---|---:|---:|---:|---:|
|initial|.01190027761|.01528124070|-.003380963090|-.004040085392|
|reverse/narrow|.01213856066|.01192662016|+.000211940498|-.000197394189|
|wide|.01234464816|.01400154824|-.001656900081|-.002221263126|
|twin|.01161470333|.01224389988|-.000629196549|-.000665029577|

All displayed integrated signs are certified with exact rational enclosures for the log expressions. Reversing/narrowing the source peak changes the transport sign. Integrated reference debt is negative in these four fixtures, while pointwise debt has BOTH signs on positive-length beta-row intervals in each. For example initial prefix1 is negative on[-61/128,-59/128], while its full prefix is positive on[-45/128,-43/128]. Reverse/narrow prefix1 has positive debt on[-119/256,-113/256]. The JSON gives all sign intervals and exact point debts. Bernstein coefficient bounds certify the sign throughout each interval, so this is not a point-sampling inference or a search for a general counterexample.

## Integration and reproducibility

Integration first splits z at source knots and z=y, producing exact polynomial moments in y. Dividing by the original affine J yields polynomial plus a rational coefficient times log(J_hi/J_lo). Formal reference-plus-debt expressions agree exactly. For rigorous sign enclosures, log x uses the 32-term atanh series with exact rational remainder 2t^65/[65(1-t²)], t=(x-1)/(x+1), inverting x<1. This is separate from ordinary high-precision quadrature.

Actual mpmath was loaded from the existing vendor path `/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor/mpmath/__init__.py`, after bundled import fallback. Forty-four independent antiderivative/quadrature comparisons pass. The maximum observed errors across fixtures are about1.37e-44 at45 digits and1.79e-64 at65 digits; these are numerical agreement figures, not interval quadrature certificates.

Run:

```
/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 /tmp/r324_numeric.py
```

Scope is deliberately one-dimensional. The source order, actual q, endpoint kernel, FIRST, selected-radius cap, shared sources, receiver dx and two physical radii are realized. This matched s0,q=1 fixture does NOT realize the original hard lower band2lambda<h_R*f, nor full low-pe/m/history qualifiers. The R323 recent/root-failure/core masks are not all implemented; nonempty high/high/middle here must not be relabeled as nonempty complete R323 core. No dimension exponent or complete target/root closure is inferred.
