#!/usr/bin/env python3
"""R175 bounded constructive four-atom common-input search and two interval checks."""
from pathlib import Path
from fractions import Fraction as F
from functools import lru_cache
from itertools import product
import sys,math,json,time,hashlib,importlib.util,collections
HERE=Path(__file__).resolve().parent
VENDOR=Path('/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor')
sys.path.insert(0,str(VENDOR));import mpmath as mp
mp.mp.dps=22
TOOL=Path('/Users/zhengzhihao/Desktop/T/output/centered_cube_round168_20261016_final_checkpoint/lp_candidate_certificate.py')
sp=importlib.util.spec_from_file_location('r175_interval',TOOL);ct=importlib.util.module_from_spec(sp);sp.loader.exec_module(ct);I=ct.I
S=F(1,4);L=F(9,10);R=F(1);K=F(1);EPS=F(1,2**32);ETA=F(1,2);CP=F(2,5)
US=(S,F(5,8),F(1));SCALES=(F(1,2),F(5,8),F(3,4),L,F(1))

def rat(x):return str(x)
def M(x):x=F(x);return mp.mpf(x.numerator)/x.denominator
@lru_cache(None)
def phi(z):
 z=abs(M(z));e=lambda t:mp.mpf('.5') if t==0 else mp.expint(3,t)
 return float(1-e(mp.mpf('.5')-z)-e(mp.mpf('.5')+z) if z<=mp.mpf('.5') else e(z-mp.mpf('.5'))-e(z+mp.mpf('.5')))
@lru_cache(None)
def cfast(d):
 d=abs(M(d));e=lambda z:mp.mpf(1)/3 if z==0 else mp.expint(4,z)
 return float(1-d+mp.mpf(1)/3-e(1)-e(d)+e(d+1) if d<=1 else e(d-1)-2*e(d)+e(d+1))
@lru_cache(None)
def kfast(n,s,scale,z):
 s,scale,z=F(s),F(scale),F(z)
 return (((1-float(s))*(abs(z)<=scale/2)+float(s)*phi(z/scale))/float(scale))**n

def prefilter(n,y,v,u,eta,cp=CP):
 g=math.sqrt(float(L));ell=1+math.log(n);H0=g*(1-float(S)+float(S)*phi(F(1,2)))*ell**(1/(2*n));H=max(.5,min(1.,H0));h=g*math.exp(-.01/n);T=g**(-n)/math.sqrt(ell)
 assert n/(n+1)*g<=float(L)<=g and .5<g<=1 and float(S)>1-2**(-1/n)
 assert math.sqrt(ell)/(8*(128/119))-16/(3*math.sqrt(ell))<1
 eta=float(eta);nu=[eta,1-eta];z=[v,u];Cs=[cfast(y-v),cfast(y-u)]
 W=lambda t:[min(1,c/t)**n for c in Cs]
 wg=W(g);w0=W(.5);wh=W(h);TD=[T*(a-b) for a,b in zip(w0,wh)]
 py=kfast(n,S,L,y);pv=[kfast(n,S,L,t) for t in z];J=[kfast(n,F(1),F(1),t) for t in z];K0=[kfast(n,S,F(str(H)),t) for t in z]
 Lplus=min(F(1),(F(1)+F(1,n))*L)
 Q=[(kfast(n,S,L,t)+kfast(n,S,Lplus,t)+j)/3 for t,j in zip(z,J)];good=[py*w<=float(K)*q for w,q in zip(wg,Q)]
 if not good[0]:return dict(status='reject',reason='target_good_fails')
 U=[min(td,k0) if gg else 0 for td,k0,gg in zip(TD,K0,good)];Unu=sum(a*b for a,b in zip(nu,U));QJ=sum(a*b for a,b in zip(nu,J));eg=sum(a*b for a,b in zip(nu,wg))
 qbase=sum(a*b for a,b in zip(nu,pv))+float(EPS)*py;pr=kfast(n,S,L,cp)
 qhigh=py*eg/(2*float(K));qrho=Unu+QJ*(TD[0]-K0[0])/J[0];qcap=.98*min(qhigh,qrho)
 if qcap<=qbase:return dict(status='reject',reason='high_or_rho_qcap_below_current_floor')
 low=0.;high=(qcap-qbase)/pr;constraints=[]
 def impose(a,b,name):
  nonlocal low,high
  if a>0:low=max(low,b/a)
  elif a<0:high=min(high,b/a)
  elif b>1e-12*max(abs(qbase),abs(b),1e-300):return False
  constraints.append((name,a,b));return low<high
 # Actual same-alpha nonnegativity, finite future, and inherited hard cap are simultaneous linear m constraints.
 if not impose(pr,Unu-qbase,'alpha_nonnegative'):return dict(status='reject',reason='alpha_constraint')
 future=[(ss,ll,'future_'+str(ss)+'_'+str(ll)) for ss in US for ll in SCALES]
 if (S,Lplus) not in [(ss,ll) for ss,ll,_ in future]:future.append((S,Lplus,'future_K2_scale'))
 future.append((S,F(str(H)),'future_K0_scale'))
 for ss,ll,name in future:
  fn=sum(a*kfast(n,ss,ll,t) for a,t in zip(nu,z))+float(EPS)*kfast(n,ss,ll,y)
  if not impose(pr-kfast(n,ss,ll,cp),fn-qbase,name):return dict(status='reject',reason='finite_future_linear_infeasible',failed_constraint=name,coefficient=pr-kfast(n,ss,ll,cp),rhs=fn-qbase,completion_interval=[low,high],qcap=qcap,qbase=qbase,Hhat=H,H0=H0,target_TDelta=TD[0],target_K0=K0[0])
 if not impose((16/3)*pr-1,float(EPS)-(16/3)*qbase,'hard_16_over_3'):return dict(status='reject',reason='hard_linear_infeasible')
 low=max(low,0.)
 if not low<high or high<=0:return dict(status='reject',reason='completion_interval_empty')
 mass=F(str((low+high)/2)).limit_denominator(10**14)
 if not low<float(mass)<high:return dict(status='reject',reason='rational_midpoint_not_in_interval')
 q=qbase+float(mass)*pr;alpha=(q-Unu)/QJ;rho=[max(0,1-(k+alpha*j)/td) if td>0 else 0 for k,j,td in zip(K0,J,TD)]
 A=[r*j/(3*qq) if gg else 0 for r,j,qq,gg in zip(rho,J,Q,good)];highratio=py*eg/(2*q)
 core=[j for j,qq in enumerate(Q) if qq<py/(2*float(K)*float(ETA))]
 positive_interval=(Cs[0]<.5<Cs[1]<h and A[0]>0 and highratio>1)
 Gamma=None;cg=None;Theta=None;Sfuture=n*math.log(float(S));reta=False
 if core==[0,1] and Cs[0]<.5<Cs[1]<g:
  Gamma=n*math.log(Cs[1]/.5);cg=(Cs[1]/g)**n;Theta=Gamma-math.log(.5+.5*cg);reta=Theta>.5*math.log(n) and Sfuture-Theta<0
 if positive_interval:
  a0=nu[0]*w0[0]/sum(m*w for m,w in zip(nu,w0));we=(Cs[0]/Cs[1])**n;ae=nu[0]*we/(nu[0]*we+nu[1]);positive=py*A[0]*(a0-ae)
 else:positive=0.
 margins=[]
 for name,a,b in constraints:
  if name=='future_'+str(S)+'_'+str(L):continue
  margins.append((a*float(mass)-b)/max(q,abs(b),1e-300))
 score=min([highratio-1,rho[0],(float(K)*Q[0]-py*wg[0])/max(float(K)*Q[0],1e-300)]+margins)
 return dict(status='feasible',reason=('active_Reta' if positive_interval and reta else 'feasible_but_no_active_Reta'),
  n=n,y=str(y),v=str(v),u=str(u),eta=str(F(str(eta))),epsilon=str(EPS),completion_position=str(cp),Lplus=str(Lplus),completion_mass=str(mass),completion_feasible_interval=[low,high],q=q,
  good=good,high_ratio=highratio,alpha=alpha,rho=rho,A=A,Cscalar=Cs,canonical_core=core,Gamma_target=Gamma,cg=cg,Theta_target=Theta,Sfuture_target=Sfuture,
  original_positive=positive,outer_beta_weighted_positive=float(EPS)*positive,positive_pair_active=positive_interval,Reta=reta,actual_Gamma_above_root=Gamma is not None and Gamma>.5*math.log(n),
  joint_margin=score,future_constraint_count=len(future),hard_mass_over_q=(float(EPS)+float(mass))/q)

# Interval certification uses the same exact physical positions/masses, not fitted C/A arrays.
def clip(z):return I(max(I(0).lo,min(I(1).lo,z.lo)),max(I(0).hi,min(I(1).hi,z.hi)))
def minimum(a,b):return I(min(a.lo,b.lo),min(a.hi,b.hi))
def sign(z):return 'pass' if z.lo>0 else ('fail' if z.hi<=0 else 'ambiguous')
def convert(z):return I(z.lo,z.hi)
def cert_kernel(n,s,scale,z,Nq):return ct.kern(s,scale,[z]*n,Nq)
def cert(case,Nq):
 n=case['n'];y,v,u=map(F,(case['y'],case['v'],case['u']));eta=F(case['eta']);mass=F(case['completion_mass']);cp=F(case['completion_position']);nu=[eta,1-eta];z=[v,u]
 g=I(L).sqrt();ell=I(1)+ct.log_rational(F(n));root=ct.log_interval(ell)/I(2*n)
 # exp endpoint inversion preserves directed enclosure.
 eroot=I((1/ct.iv.exp_neg(F(root.lo))).lo,(1/ct.iv.exp_neg(F(root.hi))).hi)
 H0=g*(I(1-S)+I(S)*ct.phi_range(I(F(1,2)),Nq))*eroot;H=I(max(I(F(1,2)).lo,min(I(1).lo,H0.lo)),max(I(F(1,2)).hi,min(I(1).hi,H0.hi)))
 T=1/(g**n*ell.sqrt());h=g*ct.iv.exp_neg(F(1,100*n));Cs=[ct.iv.C(abs(y-t),Nq) for t in z]
 W=lambda t:[(c/t).capped_one()**n for c in Cs]
 wg=W(g);w0=W(I(F(1,2)));wh=W(h);TD=[T*(a-b).nonnegative() for a,b in zip(w0,wh)]
 kern=lambda ss,ll,zz:cert_kernel(n,ss,ll,zz,Nq)
 py=kern(S,I(L),y);pv=[kern(S,I(L),t) for t in z];J=[kern(F(1),I(1),t) for t in z];K0=[kern(S,H,t) for t in z];Lplus=min(F(1),(F(1)+F(1,n))*L);K2=[kern(S,I(Lplus),t) for t in z];Q=[(kern(S,I(L),t)+k2+j)/3 for t,k2,j in zip(z,K2,J)]
 goodmargin=[I(K)*qq-py*w for qq,w in zip(Q,wg)];good=[sign(a) for a in goodmargin]
 U=[minimum(td,k0) if gg=='pass' else I(0) if gg=='fail' else I(0,minimum(td,k0).hi) for td,k0,gg in zip(TD,K0,good)]
 Fpos=[v,u,y,cp];Fmass=[eta,1-eta,EPS,mass];q=sum((I(a)*kern(S,I(L),p) for a,p in zip(Fmass,Fpos)),I(0))
 QJ=sum((I(a)*b for a,b in zip(nu,J)),I(0));eg=sum((I(a)*b for a,b in zip(nu,wg)),I(0));alpha=(q-sum((I(a)*b for a,b in zip(nu,U)),I(0)))/QJ
 rho=[clip(1-(k+alpha*j)/td) if td.lo>0 else I(0,1) for k,j,td in zip(K0,J,TD)];A=[r*j/(3*qq) if gg=='pass' else I(0) if gg=='fail' else I(0,(r*j/(3*qq)).hi) for r,j,qq,gg in zip(rho,J,Q,good)]
 high=py*eg/(I(2)*q);future=[]
 future_menu=[(ss,I(ll)) for ss in US for ll in SCALES]
 if (S,Lplus) not in [(ss,ll) for ss in US for ll in SCALES]:future_menu.append((S,I(Lplus)))
 future_menu.append((S,H))
 for ss,ll in future_menu:
  value=sum((I(a)*kern(ss,ll,p) for a,p in zip(Fmass,Fpos)),I(0));margin=q-value
  equality=ss==S and ll.lo==I(L).lo and ll.hi==I(L).hi
  future.append(dict(s=str(ss),scale=ll.out(),value=value.out(),margin=margin.out(),status='symbolic current equality' if equality else sign(margin)))
 hardmass=I(EPS+mass);hardmargin=I(F(16,3))*q-hardmass
 canonical=[sign(py/I(2*K*ETA)-qq) for qq in Q]
 Mroot=ct.log_rational(F(n))/I(2);Gamma=I(n)*ct.log_interval(Cs[1]/I(F(1,2)));cg=(Cs[1]/g)**n
 Theta=Gamma-ct.log_interval(I(F(1,2))+I(F(1,2))*cg);Sf=I(n)*ct.log_rational(S)
 profile_margins=[I(F(1,2))-Cs[0],Cs[1]-I(F(1,2)),h-Cs[1],Cs[1]-Cs[0]]
 # Exact two-source FTC for the positive orientation before the bad-source threshold.
 pi0=I(nu[0])*w0[0]/(I(nu[0])*w0[0]+I(nu[1]))
 wend=(Cs[0]/Cs[1])**n;pie=I(nu[0])*wend/(I(nu[0])*wend+I(nu[1]));drop=(pi0-pie).nonnegative()
 positive=py*A[0]*drop;EJ=I(n)*J[0]*drop;Cb=py**2*A[0]**2/J[0]*drop/I(n)
 Lcap=I(K)/I(3);Dactual=I(1)
 d=(1-Dactual*K0[0]/TD[0]).nonnegative()
 sigma=I(9)*Lcap**2*Q[0]**2/(py**2*d**2)
 Mcubic=I(2)*py**3*TD[0]*d**3/(I(243)*I(K)*Dactual*Lcap**2*Q[0]**2*J[0])
 kappa_terminal=K0[1]/wg[1]
 reserve_fraction=Dactual*I(nu[1])*K0[1]/(alpha*QJ)
 K0y=kern(S,H,y);outer_tau_mass=Dactual*K0y*I(EPS)/(alpha*QJ)
 physical_cut=dict(Lcap=Lcap.out(),d=d.out(),sigma=sigma.out(),sigma_below_4over9=sign(I(F(4,9))-sigma),
   M_sharp_equals_cubic=Mcubic.out(),K0_bad_over_wg_bad=kappa_terminal.out(),lowcapture_margin=(Mcubic-kappa_terminal).out(),
   whole_clock_lowcapture=sign(Mcubic-kappa_terminal),
   proof='wt_bad>=wg_bad on the full original clock; K0_bad/wt_bad<=K0_bad/wg_bad<M. Only positive pair has this bad u.',
   actual_same_alpha_bad_reserve_fraction=reserve_fraction.out(),actual_outer_y_tau_atom_mass=outer_tau_mass.out(),K0_y=K0y.out(),Jnu=QJ.out(),
   scope='finite same-alpha row quantities; not global source payment')
 Dupper=ell.sqrt()/(I(8)*I(F(128,119)))-I(16)/(I(3)*ell.sqrt())
 scale_margins=dict(j0_lower=I(L)-I(F(n,n+1))*g,j0_upper=g-I(L),tau_to_g=g-I(F(1,2)),g_to_b=I(1)-g)
 soft=I(S)-1+I(ct.iv.exp_neg(F(ct.log_rational(F(2)).hi)/n).lo,ct.iv.exp_neg(F(ct.log_rational(F(2)).lo)/n).hi)
 checks=dict(actual_high=sign(high-I(1)),target_good=good[0],alpha_nonnegative=sign(alpha),target_rho_positive=sign(rho[0]),target_A_positive=sign(A[0]),
  all_finite_future=all(a['status'] in ('pass','symbolic current equality') for a in future),hard_16_over_3=sign(hardmargin),
  canonical_core_both=canonical==['pass','pass'],profile_sorted_and_crossing=all(sign(a)=='pass' for a in profile_margins),
  actual_Gamma_above_root=sign(Gamma-Mroot),Theta_above_root=sign(Theta-Mroot),S_minus_Theta_negative=sign(Theta-Sf),original_positive=sign(positive),
  D_equals_1= Dupper.hi<1,j0_legal=all(a.lo>=0 for a in scale_margins.values()),strict_soft=sign(soft))
 return dict(N=Nq,checks=checks,q=q.out(),high_ratio=high.out(),good=good,good_margins=[a.out() for a in goodmargin],U=[a.out() for a in U],alpha=alpha.out(),rho=[a.out() for a in rho],A=[a.out() for a in A],
  C_scalar=[a.out() for a in Cs],wg=[a.out() for a in wg],Delta=[(a-b).nonnegative().out() for a,b in zip(w0,wh)],TDelta=[a.out() for a in TD],K0=[a.out() for a in K0],J=[a.out() for a in J],Lplus=str(Lplus),K2=[a.out() for a in K2],Q=[a.out() for a in Q],eg=eg.out(),
  H0=H0.out(),Hhat=H.out(),g=g.out(),h=h.out(),T=T.out(),D_upper_branch=Dupper.out(),scale_margins={k:a.out() for k,a in scale_margins.items()},strict_soft_margin=soft.out(),
  finite_future=future,hard_mass=hardmass.out(),hard_margin=hardmargin.out(),canonical_core_margins=[(py/I(2*K*ETA)-a).out() for a in Q],Gamma_target=Gamma.out(),cg=cg.out(),Theta_target=Theta.out(),Sfuture_target=Sf.out(),root_threshold=Mroot.out(),
  physical_cut=physical_cut,positive_pA=positive.out(),outer_beta_weighted_positive=(I(EPS)*positive).out(),EJ=EJ.out(),Cb=Cb.out(),posterior_drop=drop.out(),
  Cauchy_identity_structural=True,integral_method='exact two-profile FTC on [.5,C_bad], all later scores equal; interval physical coefficients; Cauchy factorization exact structurally',
  scope='atomic common f=beta>=nu, q=current by definition; finite future menu only; diagnostic K; conditional Zall; no L1/history/FULL')

def main():
 start=time.monotonic();rows=[]
 for n,y,v,u,eta in product((4,8,16),(F(-3,10),F(-7,20),F(-2,5)),(F(21,40),F(11,20),F(23,40)),(F(-9,10),F(-1)),(F(1,20),F(3,25))):
  if time.monotonic()-start>120:rows.append(dict(status='not_evaluated_budget',n=n,y=str(y),v=str(v),u=str(u),eta=str(eta)));continue
  result=prefilter(n,y,v,u,eta);result.update(n=n,y=str(y),v=str(v),u=str(u),eta=str(eta))
  result['stage']='stage1' if n==4 and y in (F(-3,10),F(-7,20)) and v in (F(21,40),F(11,20)) and u==F(-9,10) else 'stage2' if n==4 else 'stage3'
  rows.append(result)
 initial_rows=rows
 revised=[]
 for old in initial_rows:
  if old.get('reason')!='finite_future_linear_infeasible':continue
  result=prefilter(old['n'],F(old['y']),F(old['v']),F(old['u']),F(old['eta']),cp=L/2)
  result.update(n=old['n'],y=old['y'],v=old['v'],u=old['u'],eta=old['eta'],stage=old['stage'],construction_revision='completion moved to closed current hard face L/2')
  revised.append(result)
 rows=revised
 active=[r for r in rows if r.get('positive_pair_active') and r.get('Reta') and r.get('actual_Gamma_above_root')]
 selected=[]
 for target_n in (4,16):
  pool=[r for r in active if r['n']==target_n]
  if pool:selected.append(max(pool,key=lambda a:a['joint_margin']))
 if not selected and active:selected=[max(active,key=lambda a:a['joint_margin'])]
 certificates=[dict(input=r,refinements=[cert(r,Nq) for Nq in (128,256)]) for r in selected[:2]]
 out=dict(scope='Constructive common four-atom physical-form diagnostics only; not L1/FIRST/history/FULL or a general bound.',
  plan=dict(candidate_budget=200,initial_candidates=108,face_revision_candidates=64,prescreen_seconds_budget_per_phase=120,interval_certificate_budget=2,s=str(S),L=str(L),R=str(R),a='1/2',b='1',K=str(K),canonical_eta=str(ETA),outer_mass=str(EPS),initial_completion_position=str(CP),approved_face_completion_position=str(L/2),q='actual current convolution for each f; never an independent fitted q',
  construction='f=beta=eta delta_(v^n)+(1-eta)delta_(u^n)+epsilon delta_(y^n)+m delta_(completion^n), nu=first two atoms; completion=.4 initially and .45 in the approved face revision',mass_choice='one rational interior point of the linear finite-future/hard/high/rho feasible m interval'),
  inputs={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in (TOOL,Path(ct.DEP))},local_inputs={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (HERE/'task_contract.md',HERE/'inherited_contract.md')},
  initial_prescreen=initial_rows,initial_summary=dict(candidate_count=len(initial_rows),reasons=dict(collections.Counter(r.get('reason',r['status']) for r in initial_rows)),failed_future_constraints=dict(collections.Counter(r['failed_constraint'] for r in initial_rows if 'failed_constraint'in r))),prescreen=rows,summary=dict(candidate_count=len(initial_rows)+len(rows),face_revision_candidates=len(rows),reasons=dict(collections.Counter(r.get('reason',r['status']) for r in rows)),failed_future_constraints=dict(collections.Counter(r['failed_constraint'] for r in rows if 'failed_constraint'in r)),active_Reta_Gamma_above_root=len(active),certificates=len(certificates)),certificates=certificates,
  limitations=['K1 is diagnostic; theorem-level K is unknown.','Finite future menu plus K0, not continuum all-future.','Atomic f/beta is not an original L1/source family.','Conditional Zall and fixed receiver, no original history/positive-dx realization.','Outer beta mass and beta-weighted positive are retained; positive row is not an integrated lower bound.','No exponent fit or extension beyond the fixed budget.'],
  runtime=dict(seconds=round(time.monotonic()-start,3),python=sys.version,mpmath=mp.__version__))
 (HERE/'active_geometry_probe.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(dict(summary=out['summary'],seconds=out['runtime']['seconds'],selected=[{k:r[k] for k in ('n','y','v','u','eta','completion_mass','original_positive','joint_margin')} for r in selected]),indent=2))
if __name__=='__main__':main()
