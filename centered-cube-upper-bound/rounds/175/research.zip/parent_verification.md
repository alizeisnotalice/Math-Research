# R175 parent verification

Read the full final residual_capacity.md, reserve_envelope.md, and core_joint_geometry.md. Parent main derivation is the sharp scalar envelope; independent audit separately checks it and all costs. The joint source-density transformations do not establish their receiver column estimate or eliminate the retained j costs.

Parent read active_geometry_probe.py and caught K2 wrongly set to scale1 in the draft n16 path. Sol corrected both prefilter and interval kernels to Lplus=min(1,(1+1/n)L), added actual K2 to the finite future menu and reran the unchanged172 configurations. Final n16 uses153/160. Parent re-read the corrected formula and verified the final certificate fields.

Actual independent replay directory: /Users/zhengzhihao/Desktop/T/output/r175_parent_driver_replay_20261016. Both frozen scripts and local input contracts were copied there and executed with bundled Python3.12. Active probe completed in8.247s,172 prescreen inputs,2 selected interval certificates; scalar script14 rational extrema times1001 grid checks plus7 inverse checks passed.

Parent loaded original and replay JSON, removed only runtime metadata, and asserted every other field identical: both passed. Parent additionally asserted all listed checks in bothN128/256 certificates passed, actualLplus fields correct, sigma<4/9 and whole-clock low-capture status passed. All Python sources parsed. Sol independently read and replayed the scalar script with exact full-JSON equality.

The final physical samples are finite common atomic inputs with actual same-alpha and positive traffic. They certify only the displayed finite future menu, not continuumFIRST, L1 stability, original history or receiver integral. The low-capture remainder stays unpaid. Scalar grid tests are not the proof of the analytic envelope. No PDF compiled.

Reproduction retains absolute frozen kernel/interval and vendor dependencies, whose hashes are recorded in the JSON. The bundle is not independently portable. The driver verifies archived bytes and repeats the two scripts into an empty output directory.
