# R175：same-α储备支付一个明确的原bad-source pair切片

## 1. 准确命题与原范围

本稿读R175合同、inherited_contract及冻结R174 `global_core_geometry.md` GC1–14。固定原共同window与完整行，不改ν、β、q、当前/全部future、actualdx、history、原Zt、et、Πt、same-α或唯一j。R174规范Q-sublevel core及其时钟完全不改，也不另选core。

准确新结论：对原剩余core正J-share Rη，按一个显式的物理bad-source比值作无条件pair分割，其中上部的真实raw费用为

\[
\boxed{\operatorname{Raw}_J^+[\mathcal R_\eta\cap H_{cap}]
\le\frac{16\Lambda}{3K}L_{cap}\sqrt{n\log2}\,W_\beta.}
\tag{RC1}
\]

Lcap>0是全局预先固定的数，不是R174被移除来源集合B，也不是receiver尺度L。Hcap在下文给出，不要求某个未知posterior矩普遍有界。补集是明确的原bad源低K0/wt区域，完整保留；本文不支付它，不宣称一般根阶闭合或新的FULL/L1正覆盖。

这里必须保留原正项的**bad内源u**。原R170冻结 `task_contract.md` 第9行规定U=1good,Δ>0 min(TΔ,DK0)，第11行原raw明确含1bad(u)，第15行明确bad上U=0。R128冻结 `proof.md` RT5 第652–658行给good/bad绝对门与K0ν≤q、Jν≤q，RT6第662–667行给共同合法K0及原same-α。若GC14先已把内源扩大为全部u，该扩大式是上界接口，不能对其中非bad u套U=0；本定理回到含原bad门的真实正交通再作Cauchy。

## 2. 原捕获恒等式给的bad储备

记QJ=∫J(x-u)ν(du)>0。所有积分都用本行同一个原ν；q>0、高行eg>0已排除零来源行。原

\[
U(u)=1_{good,\Delta>0}\min(T\Delta_u,DK_{0,u}),\quad
\alpha Q_J=Dq-\int U\,d\nu,\quad D\ge1.
\]

原K0是共同合法future测试，故K0ν≤q；U≤DK0。于是准确恒等式为

\[
\boxed{\alpha Q_J=D(q-K_0\nu)+\int(DK_0-U)d\nu
\ge D\int_{\mathsf B_y}K_0\,d\nu.}
\tag{RC2}
\]

\(\mathsf B_y\) 是本行原terminal bad来源集合，包含原bad门且不扩大为all-u，其上U=0；它与GC1的被移除Q-superlevel集合没有混淆。式中两项都非负，不是自由设定的新source预算，更没有重选α。

(RC2)只控制bad的K0加权质量，不控制其无权或wt质量。不能据它宣称全部blocker小，也不能直接把α的总质量从active槽另扣一次。新构造正是先按真实K0/wt分割，再在可比部分作这个转移。

对任意M>0及固定target v，定义原current posterior中的cut blocker

\[
b_t^M(v)=\int_{\mathsf B_y}1_{\{k_t(u)<k_t(v)\}}
1_{\{K_{0,u}/w_t(y,u)\ge M\}}d\Pi_t(u).
\]

物理wt>0。逐点wt≤K0/M、原Πt=1Ztwtν/et与(RC2)给

\[
\boxed{b_t^M(v)\le\frac1{e_tM}\int_{\mathsf B_y}K_0d\nu
\le\frac{\alpha Q_J}{D e_t M}.}
\tag{RC3}
\]

原bad、lower-score、Zt以及其他原pair门只使左端更小。即使M依固定target v与原外参数，积分u时M仍共同固定。没有交换v/u的角色，没有把外β当ν，也没有引入独立来源。

## 3. 正active槽中的低α消去

在原target正槽A_v>0上，Δv>0且

\[
d_v=\left[1-\frac{DK_{0,v}}{T\Delta_v}\right]_+>0,
\qquad\rho_v=\left[d_v-\frac{\alpha J_v}{T\Delta_v}\right]_+,
\quad A_v=1_{good}\rho_v\frac{J_v}{3Q_v}.
\tag{RC4}
\]

沿用已独审R173的标量平方截断（本稿不把它另报为新结果）：对α>0，

\[
J_v\rho_v^2\le\frac{4T\Delta_v}{27\alpha}d_v^3.
\tag{RC5}
\]

它来自max b(d−b)+²=4d³/27。新内容是把(RC3)与它相乘，**同一个实际α恰好消掉**：

\[
\boxed{\frac{p_y^2A_v^2}{J_v}b_t^M(v)
\le\frac{4p_y^2T\Delta_v d_v^3Q_J}
{243D Q_v^2e_t M}.}
\tag{RC6}
\]

没有假设α有统一正下界，没有遗留1/α费用。

α=0须单独解释而非除零：由(RC2)，bad上的K0ν为0；任何M>0 cut中K0≥Mwt>0，故该bad cut的wtν质量为0，btM=0。于是(RC6)仍成立。特别K0=0的坏源不会落入任何正M的上部；它们全部留在低核补集。最新实际严格s>0时K0处处正，若原terminal good/bad分割与high给bad终端质量非零，还可推出α>0，但这不提供统一下界，本稿付款不依赖该额外推论。

## 4. 显式物理pair切片与companion点态预算

同一共同输入的J测试与high给

\[
Q_J\le q,\qquad e_t\ge e_g,\qquad
\frac{Q_J}{e_t}\le\frac q{e_g}\le\frac{p_y}{2K}.
\tag{RC7}
\]

对预先固定Lcap>0，在A_v>0的target槽定义

\[
\boxed{M_{cap}(v)=
\frac{2p_y^3T\Delta_v d_v^3}
{243KD L_{cap}^2 Q_v^2J_v}>0.}
\tag{RC8}
\]

p,Qv,Jv在原非零高行均正；Δv,dv仅在原active槽使用。其他target槽本来没有正交通，可任意定义cut，不构造0/0。

保留v的原terminal、good、ρ和GC9剩余Rη门，保留u的原bad及全部原pair/history门。新上部与低部为

\[
H_{cap}(t,v,u)=1_{\{K_{0,u}/w_t(y,u)\ge M_{cap}(v)\}},
\qquad H_{low}=1-H_{cap}.
\tag{RC9}
\]

对同一完整行，Mcap由实际物理核、TΔ与D构成，不含新source moment，不依α的选择，也不依辅助t；时间变化只在原wt中。边界等号归Hcap。cut可测，且这是原非负pair integrand的切片，不要求新support或固定terminal导数公式。

将M=Mcap代入(RC6)/(RC7)，立刻得到

\[
\boxed{\frac{p_y^2A_v^2}{J_v}\,b_t^{cap}(v)
\le L_{cap}^2J_v.}
\tag{RC10}
\]

这是一条在**每个原高行、每个actualt、每个原active v**成立的实际系数预算，而非待假设的posterior gate。用QJ/et的准确值可把Mcap改成

\[
M_{cap}^{exact}(t,v)=
\frac{4p_y^2T\Delta_v d_v^3Q_J}
{243D L_{cap}^2Q_v^2 e_tJ_v},
\tag{RC11}
\]

其不大于(RC8)，可扩大上部。本稿采用更保守但无需row质量比值的(RC8)。两个选择不可混报为同一个集合。

(RC2)在各v的上界中使用同一个reserve不是额外消费账：这里没有从signed ledger扣任何负项，而是给同一实际正coefficient作可同时成立的上界。随后仍以原Πt(dv)和固定Jv积分，不把每个v当成独立的一份q来分别收价。

## 5. actual EJ/ZJ结算及全部费用

去原hard-source因子一次之后，原正J-share的共同测度为actualdx、βV(dy)、dt/t、Πt(dv)Πt(du)及原seed/history/unique-j/eligible/high门，integrand p_yA_vδ+。在Rη∩Hcap上作Cauchy，保留1bad(u)、1δ+>0与cut，得

\[
P_{cap}\le\sqrt{E_{cap}C_{cap}},\quad
E_{cap}\le E_J,
\]
\[
C_{cap}\le
\mathbb E\sum_{V,j}\int_{original}\int_{\mathcal R_\eta}
\frac{p_y^2A_v^2}{J_v}b_t^{cap}(v)d\Pi_t(v)
\frac{dt}t\,d\beta_V(y)dx
\le L_{cap}^2 Z_J.
\tag{RC12}
\]

若原额外pair门ηpair∈[0,1]为分数权，Cauchy两边各放其平方根；丢掉它只增加上述正上界。所有source仍是原ν/Π，不因cut被重定义。

使用已独审的实际全局帽

\[
E_J\le\frac n{2K}W_\beta,\qquad
Z_J\le\frac{\log2}{2K}W_\beta
\]

给Pcap≤Lcap√(nlog2)Wβ/(2K)。恢复原hard帽16/3及outer2Λ**各一次**，得到(RC1)。没有新增time log费；显示的log2恰来自已审ZJ。没有新future菜单或source层数费用；只使用原共同合法K0与固定b的J。保留原唯一j直到一致上界，因此没有新n+2因子；window/history费用完全继承原合同，没有把adaptive Q作空间概率核积分。原∑VνV≤∑VβV、固定J的actualdx积分在EJ/ZJ中已正确计入。

EJ/ZJ用于这个新的正切片，只产生(RC1)明确列出的新增source价格，不能在总账中宣称其他已付分支因此免费。所有signed负项（包括已消费suffix与未消费反向/删除项）在原整行留账，本稿一份也未再次领取。

## 6. 无条件残余分解与准确未付区域

原非负remainder准确分为

\[
\operatorname{Raw}_J^+[\mathcal R_\eta]
=\operatorname{Raw}_J^+[\mathcal R_\eta H_{cap}]
+\operatorname{Raw}_J^+[\mathcal R_\eta H_{low}].
\]

故本稿无条件给

\[
\boxed{\operatorname{Raw}_J^+[\mathcal R_\eta]
\le\frac{16\Lambda}{3K}L_{cap}\sqrt{n\log2}\,W_\beta
+\operatorname{Raw}_J^+[\mathcal R_\eta H_{low}].}
\tag{RC13}
\]

结合既有GC11，全部原正J-share有完整不重叠总账

\[
\begin{split}
\operatorname{Raw}_J^+[all]\le{}&
\left\{\frac{16\Lambda}{9}[2\eta\sqrt{n\log2}+e^M-1]
+\frac{16\Lambda}{3K}L_{cap}\sqrt{n\log2}\right\}W_\beta\\
&+\frac{16\Lambda}{9}e^{-h}\,\mathbb E\int_Dq\,dx
+\operatorname{Raw}_J^+[\mathcal R_\eta H_{low}].
\end{split}
\tag{RC14}
\]

R174的被移除来源、smallΘ与future-dominant分支只各领原价格一次；新cut仅作用于其Rη补集。默认η=1/2、M=(logn)/2及原ε对应h可照旧。原其他mother shares不由本稿支付。

最终未付bad-source几何已经具体缩小为

\[
u\in\mathsf B_y,\quad k_t(u)<k_t(v),\quad
\frac{K_0(x-u)}{w_t(y,u)}<
\frac{2p_y^3T\Delta_v d_v^3}
{243KD L_{cap}^2Q_v^2J_v},
\tag{RC15}
\]

同时v保持原good、positiveρ、terminal core与大Θ/非future-dominant Rη，其他actual gates不变。低α没有被假设远离0：其可造成的困难被保留在这个低K0/wt补集，尤其包括所有K0=0的bad源及soft尾部。本文没有证明该补集的receiver吸收、统一companion预算或原测度质量小；下一步联合receiver估计由父级/Astra负责，不在此扩展。

如果要写其剩余Cauchy系数，必须保留原bad门和cut：

\[
\mathbb E\sum_{V,j}\int_{original}\frac{dt}t\,d\beta(y)dx
\int_{\mathcal R_\eta}\frac{p_y^2A_v^2}{J_v}d\Pi_t(v)
\int_{\mathsf B_y}1_{\{k_u<k_v\}}H_{low}(t,v,u)d\Pi_t(u).
\tag{RC16}
\]

它在本稿中**未付款**，不因起了名字或有有限实例而得到polylog界。

## 7. 检查点与停止

先筛查原bad⇒U=0及same-input K0ν≤q，再构造(RC2)/(RC3)的实际储备转移；原cubic仅作已证标量工具，新步骤是α消去和(RC8)–(RC10)的物理pair预算，随后恢复全部EJ/ZJ/raw费用。α=0、Δ=0、d=0、K0=0、cut闭面及原all-u扩大式不适用的边界均单列。未做新posterior假设、alpha优化或反例扫描。

精确候选在长证明前已发独审，初步代数与常数已核通过；最终全文绑定由父级记录。仅写责任文件residual_capacity.md，无Git、spawn、PDF、不改他人文件，交付本有界证明后停止。
