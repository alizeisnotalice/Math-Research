# R175 constructive active physical-form core rows

Two common four-atom inputs now have interval-certified high rows with positive original-form A and positive J-share traffic in the canonical Reta source region. These are diagnostic K1, finite-future, atomic fixed-point examples. They do not certify L1 stability, continuum FIRST, original history, positive receiver measure or FULL realizability.

## Bounded construction and its correction

The approved initial family had108 candidates, with x=0,n4/8/16,s=1/4,a=1/2,b=R=1,L=.9. Each source uses an actual repeated-coordinate position. The common measure is

    f=beta=eta delta_(v^n)+(1-eta)delta_(u^n)
           +epsilon delta_(y^n)+m delta_(r^n),
    nu=eta delta_(v^n)+(1-eta)delta_(u^n), epsilon=2^-32.

q is the actual current convolution of this f. It is not an independent target. The completion mass m is one rational interior point of simultaneous linear inequalities for the finite future menu (including K0), hard16/3, high and positive target rho. No mass grid was scanned.

With initial completion r=.4,44 candidates fail target good and64 fail the K0 future constraint after other requirements. The full initial records are retained in JSON. In these remaining64 cases Hhat is between .8381 and .8965, so r=.4 lies inside its hard core. The required completion mass conflicts with the K0 upper constraint. This is an observed finite family obstruction, not a general impossibility theorem.

The parent then approved one targeted correction: place completion on the closed current hard face r=L/2=.45, retaining all constraints and reusing only those64 good candidates. Total prescreen work is172 candidates, below the200 budget. All64 corrected candidates are numerically feasible;50 show the prescribed active Reta diagnostic, and30 additionally have Gamma itself above .5log n, so their apparent deficit is not solely the eta-envelope surcharge. Only the two instances below receive interval certification.

## Two certified inputs

In both instances eta=3/25,1-eta=22/25,epsilon=1/4294967296,r=9/20,K=1 and canonical eta_cap=1/2. Scalars in the table are repeated across all n coordinates.

| n | outer y | good source v | bad source u | completion mass m |
|---:|---:|---:|---:|---|
| 4 | -2/5 | 21/40 | -9/10 | 589533716533/73598208837274 |
| 16 | -7/20 | 21/40 | -9/10 | 1553944690/29396674824873 |

At N256, the main intervals are:

| Quantity | n4 | n16 |
|---|---|---|
| q | [.00631308185,.00631309289] | [2.02359992e-5,2.02361333e-5] |
| high ratio p eg/(2Kq) | [11.089323,11.089846] | [5.269143,5.270174] |
| same alpha | [1.81561060,1.81569433] | [1343.22310,1343.42311] |
| target rho | [.31236190,.31248623] | [.50966040,.50994738] |
| target Gamma | [.91192675,.91196808] | [2.53848225,2.53865560] |
| canonical Theta | [1.42938332,1.42943130] | [3.23118067,3.23135410] |
| original row positive | [.00139246454,.00139344309] | [9.93650881e-6,9.94866476e-6] |

Both nu sources lie strictly in the canonical Q-sublevel core. The target v is good and has positive rho,A; u is bad. Gamma and Theta both exceed .5log n. Since v lies outside the b hard cube in all coordinates, S=log(P_s,b/J)=nlog(1/4), exactly negative. Thus S-Theta<0, placing this target in the stated receiver-price complement for every nonnegative receiver threshold h.

Every finite future test, including the legal K0 scale, the hard16/3 condition, strict softness and actual ratio-bin constraints pass at both N128 and N256. D_n=1 is freshly checked from its inherited formula for all epsilon_G<=1 in these dimensions. K1 remains diagnostic because theorem-level K is unresolved.

## Positive traffic and mass bookkeeping

The physical profiles satisfy C_good<.5<C_bad<h. Before xi=C_bad, target score is n and bad-source score0; afterwards both scores are n. Hence the exact finite-row identity is

    I_original=p_y A_v [Pi_v(.5)-Pi_v(C_bad)].

The endpoint posteriors are evaluated using physical C intervals and actual nu masses. No free score array, A=1 replacement or numerical quadrature supplies this positive value. The JSON also records EJ,Cb through the corresponding exact two-source factorization.

The outer beta atom has mass2^-32 and is included in f,q and every future test. Its beta-weighted positive intervals are approximately[3.24208e-13,3.24437e-13] for n4 and[2.31352e-15,2.31636e-15] for n16. These small original weights are retained. A positive fixed row is not an integrated lower bound, an extremal global example, or evidence for an n exponent.

## Reproduction and limits

Run `python3 centered-cube-upper-bound/rounds/175/work/active_geometry_probe.py`. It reproduces both the failed initial phase and the approved hard-face phase, stores every decision reason and the exact selected source inputs, then performs only two N128/256 interval certificates. Runtime on this host is about ten seconds. Frozen dependency hashes and local filename keys are included for migration.

Finite future means the15 prescribed u/scale pairs plus K0 and actual K2 when not already in that menu:16 tests for n4 and17 for n16. The actual Lplus=min(1,(1+1/n)L) equals1 for n4 and153/160 for n16; the K2 kernel uses this scale in both prescreen and certificates. It is not a continuum all-future certificate. The completion is an atom exactly on a closed hard face. No symmetric smoothing or L1 stability is inferred. Zall remains conditional, and original history/source-lineage and real dx are unconstructed. This round establishes a concrete physical-form active intersection to study, without claiming the general bound or a counterexample.


## Whole-clock physical cutoff and actual reserve quantities

On the same two inputs, set Lcap=K/3=1/3 and d=[1-D K0_v/(TDelta_v)]_+. Both interval certificates have sigma=9 Lcap^2 Q_v^2/(p^2 d^2)<4/9, so the sharp and cubic cutoffs agree. The stored cutoff is

    M=2 p^3 TDelta_v d^3 /(243 K D Lcap^2 Q_v^2 J_v).

At N256, n4 has sigma approximately5.884e-5, M in[2745.26,2745.87], and K0_u/wg_u in[2.27038e-5,2.27065e-5]. For n16, sigma is approximately6.002e-15, M in[1.82545e16,1.82687e16], and K0_u/wg_u in[4.31338e-19,4.31549e-19]. The latter is strictly below M in both cases. Since wt_u>=wg_u on the full clock, the only positive pair stays in the unpaid low-capture complement throughout; this is a whole-clock inequality, not a sampled-time observation.

The actual same-alpha reserve fraction D nu_u K0_u/(alpha Jnu) is approximately6.087e-4 for n4 and8.421e-18 for n16. The actual outer-atom tau mass D K0_y epsilon/(alpha Jnu) is approximately3.093e-8 and1.803e-5, respectively. Their raw intervals are stored. These are same-input point-row quantities, not global source payments or bounds on a sum over outer sources.
