# R175: sharp simultaneous reserve–residual envelope

Parent derivation. Pending independent audit. This is a scalar extremum applied to actual physical pair cuts. It is not an extremizer theorem for the original maximal operator or a general root-order bound.

## 1. Actual inputs; preserve the common alpha

Work on an original nonzero high row with p>0, et>=eg, nu fixed, Jnu=int J dnu, and D>=1. For a target v with TDelta_v>0 define d=[1-D K0v/(TDelta_v)]_+ and a=Jv/(TDelta_v)>0. If d=0 the target residual is zero. Otherwise original rho=(d-alpha a)_+.

For a positive measurable target/time threshold M, cut the ORIGINAL bad inner sources by ku<kv and K0u/wt(u)>=M. The same-alpha reserve identity implies

    alpha Jnu >= D int_bad K0u dnu,
    b_cut <= min(1, alpha S),   S=Jnu/(D et M).

All quantities belong to the same row. The cut does not change alpha, q, original posterior, source mass or support. The threshold may depend on t and v because this is a positive-pair Cauchy estimate; it is not a time-varying terminal gate in a clock FTC. For alpha=0 the cut has posterior mass zero. No original negative signed credit is consumed by using the capture equality as a constraint.

## 2. Exact scalar extremum

For d,a,S>0, set h=dS/a. Then

    sup_{alpha>=0} (d-alpha a)_+^2 min(1,alpha S) = d^2 F(h),
    F(h) = 4h/27                  for 0<=h<=3,
           (1-1/h)^2              for h>=3.                  (RE1)

Proof: z=alpha a/d. Only 0<=z<=1 matters. For hz<=1 the objective divided by d² is h z(1-z)²; its derivative is h(1-z)(1-3z). For hz>=1 it is (1-z)², decreasing. If h<=3, z=1/3 is feasible in the first branch and globally maximizes. If h>=3, both branch maxima meet at z=1/h. Boundary h=3 agrees, F(0)=0 by continuity. F is nondecreasing, continuous and <=1. These optima are sharp for the scalar relaxation; they do not assert that the same alpha can be freely chosen or realized in the original full geometry.

Compared with separately maximizing the two factors, F(h)<=min(1,4h/27), strictly stronger for h>3 except limiting/boundary equalities. This preserves the coupling of the reserve and the residual rather than inserting an independent 1/alpha bound.

## 3. Explicit geometric quantities, no unknown posterior moment

Using Jnu<=q and et>=eg>=2Kq/p,

    h <= H_M = d (TDelta_v) p /(2KD M Jv).

Consequently the actual cut companion integrand satisfies

    (p² rho² Jv/(9Qv²)) b_cut
       <= [p² d²/(9Qv²)] Jv F(H_M).                       (RE2)

Every dimension and scale dependence remains in the actual kernels, TDelta and d. No independent source choice, moment assumption or inverse-alpha factor appears. This estimate only concerns original bad inner sources; it cannot be applied to the enlarged all-u posterior tail without separately paying good-u sources.

## 4. A larger explicitly paid physical branch

Fix Lcap>0. Put sigma=9 Lcap² Qv²/(p² d²). If sigma>=1, the original bound rho<=d and b<=1 already give companion<=Lcap²Jv for all original bad inner sources of this target; no cutoff is needed.

For 0<sigma<1 define

    Hmax(sigma)=27sigma/4                 if sigma<=4/9,
                1/(1-sqrt(sigma))        if sigma>=4/9,
    M_sharp = d (TDelta_v) p /(2KD Jv Hmax(sigma)).          (RE3)

The two definitions agree at sigma=4/9. Cutting bad u by K0u/wt(u)>=M_sharp ensures H_M<=Hmax and F(H_M)<=sigma. Thus (RE2)<=Lcap²Jv. All definitions are measurable; targets with d=0 or TDelta=0 contribute zero and require no division. K0 may vanish at irrelevant places; the positive-cut argument never divides by a zero K0.

Cauchy with the original globally paid EJ<=nW/(2K), ZJ<=log2 W/(2K), then hard16/3 and outer2Lambda once, gives

    RawPositive_J[this pair branch]
       <= (16Lambda/(3K)) Lcap sqrt(n log2) W.             (RE4)

The gates can be restricted to the previously unpaid R_eta without changing the estimate. Pair branches must be assigned disjointly when combined with R174; retaining the original source-slot partition and then cutting only its unpaid pairs does so.

For sigma<=4/9 this is exactly the cubic threshold in residual_capacity.md. For sigma>4/9 it is weaker (smaller threshold), hence pays a larger concrete pair set. As sigma tends to1, M_sharp tends to0 consistently with the all-bad branch above. This is an algebraic improvement of the actual geometric cutoff, not a proof that its complement is small.

## 5. Remaining geometric obligation

After the already paid R174 slots and (RE3), the unpaid original bad pairs have both the specified Q-sublevel target, large effective threshold loss and low K0u/wt(u) relative to M_sharp. Any remaining original good-u pairs or other mother shares stay in the original ledger. The true receiver measure, all source labels, scales and windows are unchanged. One still needs a joint receiver/source geometric budget for this low-capture region; no entropy or independence bound is asserted for it.
