# R175：canonical core 的实际三点联合容量检查点

状态：本稿未证明 R174 未付 R_eta 的一般根阶预算。完成的是一个固定 j、保持同一输入和实际密度的联合容量比较：外来源 beta−nu 与内 bad 来源可同时按原同-alpha 储备归一，产生四次残余界。它是准确的结构引理，不是已经支付的正交通分支。本轮已支付的新物理 pair-cut 见同目录 residual_capacity.md / reserve_envelope.md；这里不重新登记其费用。

## 1. 原量词与实际目标

固定原 seed/window、x、V、j，仍用原 p_y=P_(s,L)(x−y)、J_v=P_(1,b)(x−v)、Q_v=(K1_v+K2_v+J_v)/3。nu=nu_V、beta=beta_V 在整个 y 积分前冻结，nu≤beta，sum_V beta_V≤f。严格实际 soft 范围 s>1−2^(−1/n)>0 下，K0、J、p 在有限点严格正。零来源、e_g=0、TDelta_v≤0、rho_v=0 的行/槽不进入以下正目标。

本稿关键地使用 K0_j=P_(s,Hhat_j) 在固定 x,j 下对整个 y 积分共同。原文依据是冻结 R128 proof.md RT1（606–608行：s,L,R 为接收点参数）、RT4 前尺度定义（637行：g=sqrt(LR)）、RT6（662–664行：Hhat 只由这些参数及 j 决定）；冻结 R170 task_contract.md Definitions 已明确记录并经 R169 审核该结论。定位文件：

- /Users/zhengzhihao/Desktop/T/output/centered_cube_round128_20261014/proof.md
- /Users/zhengzhihao/Desktop/T/output/centered_cube_round170_20261016_final_checkpoint/task_contract.md

不因 K0 对 y 共同而把它视为对 x、j 固定的空间概率核。以下保留 D_y 记号，兼容原 D 为共同常数的特例，绝不重选 D。

R174 取 eta=1/2，规范 core C_eta、有效损失 Theta_eta 不变。保留其实际未付 target R_eta，并保留原 bad_y(u)、k_t(u)<k_t(v)、Z_t(u)、terminal good/positive-rho/存活 v。可再限制到 residual_capacity.md RC15 的 H_low，或者 reserve_envelope.md 更大已付支的补集；下述比较对任意这样的实际正子集成立。

令 H=H(x,y,t,v,u)∈[0,1] 保存这些指示、原 pair/history/eligible/high/唯一 j 门及所选正子集。它不吸收 rho、J/(3Q) 或任何来源密度。原 hard 源先按已审 16/3 上界一次；若该上界需放松某个 [0,1] 门，则 H 指放松后所得合法上界的剩余门。以下只是这个固定 companion 的精确换密度，不把放松称为原 raw 等式。

记 w_v=w_t(y,v)、e=e_t(y)。实际 bad companion 为

\[
\mathcal C_{\rm rem}
=\mathbb E\sum_{V,j}\int dx\,\beta(dy)\frac{dt}{t}\,\nu(dv)\nu(du)\,
H\,1_{\mathsf B_y}(u)
\frac{p_y^2\rho_v^2J_v}{9Q_v^2}
\frac{w_vw_u}{e^2}.
\tag{CJ1}
\]

时间是原窗口，Π=1_Z w nu/e 完全不改。H 包含两槽原支持；特别不能把 bad 扩成全部低 score 来源后继续使用下文储备。R173 已审能量给

\[
\operatorname{Raw}^{J,+}_{\rm rem}
\le {32\Lambda\over3}
\sqrt{{nW_\beta\over2K}\,\mathcal C_{\rm rem}},
\qquad\Lambda=128/119.
\tag{CJ2}
\]

这里 hard16/3 与 outer2Lambda 各一次，未消费任何 signed 负项。

## 2. 同一 K0 的双重储备

令 zeta=beta−nu≥0，Q_J=∫J nu，G0=q−∫K0 nu。共同 FIRST 与 zeta≤f−nu 给

\[
0\le\int K0(x-y)\zeta(dy)\le G0.
\tag{CJ3}
\]

原 U_y=1_good,Delta>0 min(TDelta,D_y K0)，same-alpha 定义精确给

\[
\gamma_y:={\alpha_yQ_J\over D_y}
=G0+\int(K0-U_y/D_y)d\nu
\ge G0,\qquad
\gamma_y\ge\int_{\mathsf B_y}K0\,d\nu.
\tag{CJ4}
\]

这两个下界控制的是同一个实际 gamma_y，而非两个可独立分配的储备。

当 G0>0 时定义下式 tau；对所有 gamma_y>0 的行（无须 G0>0）均按下式定义 mu_y，gamma_y=0 时取 mu_y=0。这些测度保持实际密度：

\[
\tau_{x,V,j}(dy)={K0(x-y)\over\gamma_y}\zeta(dy),
\qquad
\mu_{x,V,j,y}(du)={K0(x-u)1_{\mathsf B_y}(u)\over\gamma_y}\nu(du).
\tag{CJ5}
\]

于是 ∥tau∥≤K0 zeta/G0≤1，逐 y 有 ∥mu_y∥≤1。gamma_y 可以依 y；tau 的结论使用其共同下界 G0，不假定 gamma 恒定。mu_y 是实际依 y 的条件测度，不能视作与 tau 无关的另一个概率来源。nu(dv) 从未归一化。

边界必须分开：G0=0 时 CJ3 与严格 K0>0 强制 zeta=0，故外 zeta 部分为零，可取 tau=0。即使 G0=0，gamma_y 仍可能为正；不能推出 alpha=0。对任意 gamma_y=0 的行，CJ4 强制 bad_y 的 nu 质量为零，原 bad-pair 为零，mu_y 可取零。若扩展到 s=0 或其他可使 K0=0 的端点，以上只重构正 K0 部分；K0=0 上的外 zeta 或 bad 来源必须另留，不能除零或宣布消失。本稿不使用该端点扩展。

## 3. 实际 alpha 的 cubic / quartic 比较

在正 target 上定义

\[
d_v=\left[1-{D_yK0_v\over T\Delta_v}\right]_+,
\quad a_v={\alpha_yJ_v\over T\Delta_v},
\quad\rho_v=(d_v-a_v)_+.
\tag{CJ6}
\]

初等最大值 max a(d−a)_+²=4d³/27 与 max a²(d−a)_+²=d⁴/16 分别给

\[
\alpha_yJ_v\rho_v^2\le
F_1:=\min\{\alpha_yJ_vd_v^2,\,4T\Delta_vd_v^3/27\},
\tag{CJ7}
\]
\[
\alpha_y^2J_v\rho_v^2\le
F_2:=\min\{\alpha_y^2J_vd_v^2,\,(T\Delta_v)^2d_v^4/(16J_v)\}.
\tag{CJ8}
\]

证明：只需 0≤a≤d；对 a(d−a)² 微分最大在 d/3，对 a²(d−a)² 最大在 d/2；a≥d 时 rho=0。两个 min 的第一项来自 rho≤d，第二项来自同一个实际 alpha 的标量上界，没有将 alpha 自由重选。CJ7 是本轮辅助稿已用的 cubic；CJ8 是供双储备精确换密度使用的 quartic。

按 beta=nu+zeta 将 CJ1 精确分为 C_nu+C_zeta。nu 外槽仅替换内 bad 密度，得到

\[
\mathcal C_\nu\le\mathbb E\sum_{V,j}
\int dx\,\nu(dy)\frac{dt}{t}\nu(dv)\mu_y(du)\ H\,
{p_y^2Q_JF_1\,w_vw_u\over9D_yQ_v^2e^2K0_u}.
\tag{CJ9}
\]

外 zeta 槽同时使用 zeta(dy)=gamma_y tau(dy)/K0_y 和 1_bad nu(du)=gamma_y mu_y(du)/K0_u，得到

\[
\mathcal C_\zeta\le\mathbb E\sum_{V,j}
\int dx\,\tau(dy)\frac{dt}{t}\nu(dv)\mu_y(du)\ H\,
{p_y^2Q_J^2F_2\,w_vw_u\over9D_y^2Q_v^2e^2K0_yK0_u}.
\tag{CJ10}
\]

特别，使用 CJ8 的 quartic 项，CJ10 的物理上界核为

\[
\boxed{
{p_y^2Q_J^2(T\Delta_v)^2d_v^4\,w_vw_u
\over144D_y^2Q_v^2J_ve_t(y)^2K0(x-y)K0(x-u)}}.
\tag{CJ11}
\]

144=9·16，两个 K0 分母、e_t²、J_v 分母和 d_v⁴ 都不可省。换密度前的系数是 gamma_y² rho_v² J_v；gamma_y²=alpha_y²Q_J²/D_y²，故 CJ8 恰消去两次储备归一中的 alpha。对 C_nu 只有一次 bad 换密度，不能假装也有第二个外储备并套 CJ11。

这完成了固定 j 的比较证明。所有核来自同一 x,y,v,u 和同一原输入，删除仅出现在原 Z_t 门及实际 e_t；没有对称性、独立性或删源后重新归一的假设。

## 4. 尚缺的实际列积分与费用

CJ9–11 没有证明一个统一积分常数。准确缺口是：在 R_eta 与已付 pair-cut 补集上，能否对 CJ9、CJ10 的实际联合密度和三点物理核共同积分，得到

\[
\mathcal C_\nu+\mathcal C_\zeta\le C_n W_\beta,
\qquad C_n=\operatorname{polylog}(n),
\tag{CJ12?}
\]

或者直接把对应原正交通的一部分以 epsilon E∫q dx 吸收，并对剩余部分证明该式。CJ12? 是未证目标，不是新增假设、条件定理或已付分支。若它成立，CJ2 给明确价格 (32Lambda/3)sqrt(n C_n/(2K))W_beta；目前不能领取此价。

具体不能省掉的步骤如下：

1. tau 随 x,V,j 变化，mu 还依 y。∥tau∥、∥mu_y∥≤1 不给 actual dx 的列预算；先对 y,u 取上确界会丢掉 CJ3–5 的实际容量衰减。必须保留其密度与物理核一起积分。
2. K0 是原自适应接收尺度核；不能将 1/K0_y 或 1/K0_u 与 p、Q、J、Delta、d 分离后用某个固定卷积核的 L1 归一。原 rho/Delta 的活跃条件和两槽 same-alpha 都仍在 H/CJ6 中。
3. CJ5 的 subprobability 是固定 j 结论。tau_j 各自质量≤1 不意味着 sum_j tau_j 质量≤1。即使保留原唯一 j 指示，各 j 的 K0_j/gamma_(y,j) 归一不同，不能免费消去求和；若仅逐 j 收同一常数，可能支付原至多 n+2 的菜单费。CJ9–12? 因而明确保留 sum_j 和原门。window/history 同样不因新记号免费合并。
4. C_nu 与 C_zeta 都须支付，sum_V 的同源质量、实际 dx、时间以及全部原来源/接收选择均在 CJ12? 内。不能只控制 zeta 部分后称 beta 全部完成；也不能把每个 V 的储备差 G0 当成可免费相加的 receiver 预算。

本次有界尝试没有完成这些联合列积分，故没有新增独立 raw 付款。下一步准确对象是 CJ9 与 CJ10 保留实际密度的接收点积分，而非再给一个未知矩设小量门。

## 5. 本轮有限模型证据的边界

同目录 active_geometry_probe 的新同源 completion 报告了实际 good/rho/high 与 R_eta 同时非零的候选；父级随后指出 n=16 的 Lplus 需更正，故这里不认证这些候选，最终有效性以修正证书及独审为准。模型外 y 原 beta 质量仅 2^(−32)，任何正行量必须乘此质量，不能据单行大比值推全球压力。即使修正后通过，该诊断仍只核有限 future 与物理标量区间，不认证 continuum FIRST、正 L1、history 或 FULL。它不证明 CJ12?，也不是其反例；这里未另跑样本或扩大搜索。

最终结论：CJ3–11 是可审核、同输入、固定 j 的双储备 quartic 结构；R_eta 的一般联合几何付款仍未闭合。已付 pair-cut 与未付低核补集严格分开，所有原负信用保留。
