# R175 独立几何审查：一般共同clock先行检查点

状态：作者前独立推导完成，等待指定成稿后审。仅编辑本文件；不运行数值、不改作者、不Git/spawn/PDF。R174的余项没有因此闭合。

## 1. 输入与检查范围

父级指定的task_contract.md初次读取时尚未落盘；已实读本轮inherited_contract.md及R173最终冻结mass_sensitive_geometry.md中原量词、真实terminal槽和FTC。继承文档标题/末段仍写R174，因此这里只以其原核/共同输入定义为继承依据，任务范围以父级R175准确指令为准。未读本轮作者稿。

固定完整实际行x,y,V,j、原current/future选择、同alpha/rho、共同窗口及原history。S=Z_(ell+)是完整初始来源，nu有限，Z_g包含于Z_t包含于S；e_g>0。terminal A=1_good rho J/(3Q)支持于Z_g，0≤A≤1。Pi_t仍为原1_Zt wt nu/e_t。时间变量tau=log(t/ell)，T=log(g/ell)≤log2，wt严格正且绝对连续，−dlogwt/dtau=k_t∈{0,...,n} a.e.。

任意共同clock斜率r(t)须是在此行预先固定的可测函数，0≤r≤n。它可依整行/原nu，但在内层u,v积分中共同，不能对每个对手来源另选一个r后共享同一费用。令

    c_t=exp(−integral_ell^t r_s ds/s),
    v_t(u)=w_t(u)/c_t,
    E_t=e_t/c_t,
    E_g=e_g/c_g.

有v'_t=(r_t−k_t)v_t。所有以下源积分使用原nu，删除不改变clock或full-initial来源定义。

## 2. 一般clock的准确分母及删除费用

令

    G_t=integral_fullS (r_t−k_t(u))_+ v_t(u)nu(du),
    L_t=integral_t^g G_s ds/s,
    D_t=E_g−L_t,
    lambda_t=L_t/E_g.

直接用Z_g包含于Z_t，逐源积分正导数得到

    E_g−E_t
    ≤integral_Zg[v_g(u)−v_t(u)]nu(du)
    ≤integral_fullS integral_t^g(r_s−k_s(u))_+ v_s(u) ds/s nu(du)
    =L_t.

故E_t≥D_t。该式对任意原nested删除有效；G_t必须包括full initial S及其后来删除部分。只有在某固定core上k≥r a.e.时，才可把S缩成其补集B。这也是R173 essinf构造的关键，而非符号简化。

D'_t=G_t、D_g=E_g。使用1/D需要D_t>0；充分且统一的条件为lambda_ell<1，不能从任意r自动推出。一般r即使按原Pi均值选择，也没有由FIRST直接给lambda<1或小lambda。e_g归一、c_g因子和time内1/c_t均须保留。r=0给G=lambda=0，是一个始终合法但可能具有大Gamma的参照。

## 3. 原正pair的逐源比较：低score项不能省

定义原阻塞平均

    bpair_t(v)=integral(k_t(v)−k_t(u))_+ Pi_t(du),
    a_t(v)=k_t(v)−r_t,
    Gamma_t(v)=integral_t^g a_s(v) ds/s.

所有v都有

    bpair_t(v)≤(a_t(v))_+ + G_t/E_t.                 (A1)

当a_t(v)≥0时可把正部换为a_t(v)，但这只是在该时刻的比较。若固定terminal来源在全窗a_t(v)≥0 a.e.，则R173整窗FTC原样成立，即

    I[A H]≤(1/e_g)integral AH wg
                    [expGamma_ell/(1−lambda_ell)−1]dnu. (A2)

这里H是时间固定terminal来源门，且必须保证其来源全窗a≥0。不能只在被积分的每一时刻取1_{a_t≥0}，然后把没有取到的时段从FTC边界里抹去。

对一般来源，F_t(v)=expGamma_t(v)/D_t满足

    −F'_t=expGamma_t[a_t/D_t+G_t/D_t²].

由E≥D>0、A1及原terminal冻结分子得完整上界

    I[A]≤(1/e_g)integral_Zg A wg
        {expGamma_ell/(1−lambda_ell)−1
         +integral_ell^g expGamma_t (r_t−k_t(v))_+
                             /(1−lambda_t) dt/t}dnu.    (A3)

该式的括号整体给非负上界；其中首项独自可能为负，不能将其命名为非负付款因子后丢掉校正。A3只用正支配，没有使用signed负信用。

即使只付款a_t≥0的交通，整窗FTC仍需补低score时段F的回升正变差。其精确回升密度为

    (F'_t)_+=expGamma_t[(r_t−k_t(v))/D_t−G_t/D_t²]_+,

被A3所列低score校正控制。截取任意连续/不连续时段或每个score层均不能重复领取同一个初末边界。

## 4. 低score校正的完整可用费用

A3的校正按未归一来源写为

    L_A=integral_ell^g integral_Zg
             A(v)(r_t−k_t(v))_+ w_t(v)/(c_t D_t)nu(dv) dt/t.

它是实际terminal活跃低score来源所贡献的量；fullG还须包含inactive及后来删除来源，二者不能互换。由0≤A≤1、Z_g包含于S，严格得到

    L_A≤integral_ell^g G_t/D_t dt/t
        =log(D_g/D_ell)=−log(1−lambda_ell).              (A4)

这是单次整体对数费用，未乘score层数、删除次数或n。它不是自动小量。若有实际可验证的统一lambda_ell≤lambda_*<1，按原唯一j、共同current核p与sum beta≤f，原外因子32Lambda/3至多给

    RawCorrection≤(32Lambda/3)[−log(1−lambda_*)]
                                      E integral_D q dx. (A5)

更精确可保留E integral dx sum_V integral beta(dy) p_y
[−log(1−lambda_row)]，不能由逐行有限性推出统一epsilon价。A5用的是原current FIRST和A≤1，无需把Q或自适应future核作空间归一；不同独立窗口仍按原合同收费。

因此要以此校正取得epsilon接收价，必须真正证明其原current加权积分小，或给lambda_*≤1−exp(−3epsilon/(32Lambda))之类足够小的显式条件。将lambda<1作为新未控制gate，只是一个条件分支，不是R174余项付款。

另一条来源价比较由原good给出

    L_A≤K/(3p_y e_g) integral_Zg J_v
       integral_ell^g expGamma_t(v)(r_t−k_t(v))_+
                               /(1−lambda_t)dt/t nu(dv).

这里的时间积分仍是新的真实未付系数；没有从已付delta²能量或FIRST直接得到统一界。若使用Cauchy，它必须保留原低score质量、samealpha rho及原J空间槽，不能把(r−k)_+当成delta_+已付能量。

## 5. R174 canonical核心下的必要限制

对R174已构造的S=C_eta不交B_eta，任意新r的增长精确分解为G_B+G_C。B_eta已由nu(B_eta)≤eta e_g控制，故其贡献满足

    lambda_B≤eta(1−c_g).

但新r高于原essinf后，core中的(r−k)_+不再为零；lambda_C必须完整保留，包括core中非good/零rho以及后来删除来源。只按活跃terminal来源的质量加权选择r，不能忽略这些对E_t下界的影响。反过来，实际低score活跃校正L_A不能以已付B槽费用替代：两者来源集合/系数不同，B已付款也没有把B移出原Pi。

新clock若使大Gamma降低，其降低量正由a的负部及其正变差体现；不能只保留新的小端点Gamma，删掉这笔返还费用。逐层/逐时间切换r若不保持单一共同AC c，会额外产生clock跳；如确需拼接，所有人工边界与重复端点必须按变差一次计全。以上A1–A4用单一任意可测r，已避免人为每层计费，但未使该费用消失。

## 6. 后审计划与当前结论

等待Astra核心联合几何及Sol实际alpha精确命题。后审只检：(i)所用r/G/D和支持是否满足上述量词；(ii)低score活跃槽及fullinitial增长是否真实付清；(iii)原samealpha/共同future/nu与receiver物理条件是否足以给所声称的积分界；(iv)是否把单次对数变差、原hard16/3、outer2Lambda、uniquej、time/window费用计全。数值不代替一般证明。

先行结论：任意共同clock的分母下界成立；全窗高score来源可沿用R173 FTC；一般来源须保留A3精确低score校正。校正有A4一次对数费用，但目前没有一般小量保证。没有证明R174未付R_eta闭合，没有引入新gate充当新全局定理。检查点交付后停止等待作者成稿。


## 7. same-alpha bad-pair阈值切分：作者稿前独立筛查

已读后落盘的本轮task_contract.md，范围与上述继承一致。对本次准确候选，先独立代数，再等待作者稿。原定义由R172冻结task_contract及residual_support_geometry的G1–G4核实：D为原统一捕获倍数D_n≥1，K0=P_(s,Hhat)为共同合法future，故K0nu≤q。U=1_(good,Delta>0)min(TDelta,DK0)满足0≤U≤DK0，原samealpha满足

    alpha QJ=Dq−integral U dnu,
    QJ=integral J dnu>0.

原bad是原good补集，因而其上U=0。精确推出

    alpha QJ=D(q−K0nu)+integral(DK0−U)dnu
             ≥D integral_bad K0 dnu.                    (B1)

这保留同一实际alpha、nu、q和D；不把U或rho换成独立最优变量。D>0及K0nu≤q不可省。K0非负而非处处严格正；尤其s=0时K0在硬窗外为0，不可假设bad所有来源均正K0。原J严格正、e_g>0保证QJ>0，故原alpha合法。

目标v保留原terminal/good/rho及R174 R_eta或任何其他原正门。对TDelta_v>0令

    d_v=[1−DK0_v/(TDelta_v)]_+,
    rho_v=[d_v−alpha J_v/(TDelta_v)]_+.

当alpha>0，标量b(d−b)_+²≤4d³/27（极值b=d/3）严格给

    J_v rho_v²≤4 TDelta_v d_v³/(27alpha).               (B2)

任意正阈值M=M(row,t,v)，定义实际内源cut同时满足原bad、原严格低score ku<kv，以及K0_u/w_t(u)≥M；其后验质量为b_cut(t,v)。可保留原全部pair mask，其值在[0,1]，不放大原bad身份。由w>0及非负性，

    b_cut≤(1/(e_t M))integral_bad K0nu
          ≤alpha QJ/(D e_t M).                         (B3)

这里M可依targetv和t，因为仅在同次u积分中共同；不属于固定terminal来源FTC，不需要时间不变sourcegate，也没有对u自选future核。原Pi和删除支持均保持；可将Zt中的bad质量放大到完整nu的bad质量，但不能删掉完整reserve中已删除来源。

由e_t≥e_g及high、共同FIRST，

    QJ/e_t≤q/e_g≤p_y/(2K).

将B2/B3乘原companion系数，得到

    (p_y² A_v²/J_v)b_cut
    ≤2 p_y³ TDelta_v d_v³/(243 K D Q_v² M).             (B4)

因此任取统一Lcap>0，并在正目标槽定义

    M=2 p_y³ TDelta_v d_v³/
                       (243 K D Q_v² Lcap² J_v)>0,      (B5)

便有原真实cut companion点态≤Lcap² J_v。常数243=9·27及高行带入的1/(2K)均保留，没有漏J或多付alpha。

边界：p_y=0时原带p交通为0；TDelta≤0按原非空far/残余资格不入正目标，不能计算其残余比；d_v=0使rho=0，直接零槽。Q_v≥J_v/3>0，J_v>0。在其余槽B5正且有限，等号K0/w=M可入cut，原ku<kv的严格面保留。alpha=0时不应用B2除法；B1使integral_bad K0nu=0，而cut有K0_u≥M wt(u)>0，故其nu/Pi质量为0。K0=0内源自动不在任何正M cut。alpha趋0不需要极限交换，逐alpha分支已覆盖。

实际正pair Cauchy限制在此cut上，delta²能量直接由原EJ控制；companion由Lcap²ZJ控制。因此

    sqrt(EJ·Lcap² ZJ)
       ≤Lcap sqrt(nlog2)W_beta/(2K),
    RawPositive_J[cut]
       ≤16Lambda/(3K) Lcap sqrt(nlog2)W_beta.            (B6)

原hard16/3及outer2Lambda恰一次。target/t/row依赖cut只缩原非负积分，不增加菜单、层数或删除费用；uniform Lcap保证原uniquej在全局上界后合并。固定J真实dx、全部beta/nu和原time/history/window范围继承EJ/ZJ；Q没有空间归一。该支不消费任何原signed负信用。

这是明确物理pair阈值子支，非新未知posterior小量gate。它支付bad内源中高K0/w部分；原bad低K0/w补集仍保留，不能据此声称全部R_eta已付。若某上界接口已把原bad扩大成all-u，B1/B3只能用在其中bad部分；非bad内源不能借U=0获得同价。原始pair究竟带bad的依据仍以冻结原合同为准，后审须在成稿中确认。

先行判断：B1–B6准确候选成立，边界按上述零槽约定；等待residual_capacity.md逐式后审及最终绑定，不运行数值。


## 8. 父级饱和reserve标量包络：作者前独立筛查

对第7节相同实际bad-pair，固定正目标槽d=d_v>0、t=J_v/(TDelta_v)>0。后验质量同时满足b_cut≤1与b_cut≤alpha S，其中S=Jnu/(D e_t M)≥0。由rho=(d−alpha t)_+，令h=dS/t。若S=0，cut质量0且下式按F(0)=0成立。否则在alpha t≥d时rho=0，在0≤alpha t<d时令z=alpha t/d，优化

    rho² b_cut≤d²(1−z)² min(1,hz),  0≤z≤1.

未饱和段z≤1/h的导数为h(1−z)(1−3z)，饱和段z≥1/h的导数为−2(1−z)。若h≤3，未饱和极大点1/3合法且全域最大4h/27；若h≥3，最大在接点1/h，为(1−1/h)²。因此严格得到

    F(h)=4h/27              (0≤h≤3),
         (1−1/h)²          (h≥3),
    rho²b_cut≤d² F(h).                                  (C1)

F连续单调递增，F(3)=4/9，趋无穷时趋1。h=3两支及导数相容。该优化使用同一实际alpha，虽对所有alpha取上确界，却不修改原alpha；其余原samealpha资格仍保留。C1也不声称物理输入一定能实现极值z。

源容量给

    h=d TDelta_v Jnu/(D e_t M J_v)
       ≤hbar=d TDelta_v p_y/(2K D M J_v).                (C2)

由于F单调，h用hbar上放方向正确。原companion满足

    (p_y² A_v²/J_v)b_cut
       ≤p_y² J_v d_v² F(hbar)/(9Q_v²).                  (C3)

令sigma=9Lcap²Q_v²/(p_y²d_v²)。对0<sigma<1，要求F(hbar)≤sigma的准确反解是

    hbar≤27sigma/4                  (0<sigma≤4/9),
    hbar≤1/(1−sqrt(sigma))          (4/9<sigma<1).        (C4)

sigma=4/9时两式同为3；sigma趋1的阈值发散。若sigma≥1，由rho≤d、b≤1可直接支付该目标的全部原bad低score pair，不需要K0/w阈值。不能把这个“全部bad”误作包括good内源的全来源pair。

C4按C2可选明确M=d TDelta p/(2KD J hmax)。这不含未知posterior矩；只使用原物理target量、共同容量和选择的统一Lcap。低预算sigma≤4/9时该M恰等第7节旧cubic门：因27sigma/4代入化简给2p³TDelta d³/(243KD Q²Lcap²J)。高预算4/9<sigma<1才严格放宽旧门。整支由同一个点态companion≤Lcap²J控制，union后只使用一次EJ/ZJ及外因子，费用仍为16Lambda/(3K)Lcap sqrt(nlog2)W_beta；不得给各sigma层分别领取同一费用。

d=0、p=0、TDelta≤0的原零槽沿第7节处理，不定义sigma或t的0/0。alpha=0依原reserve论证cut质量0；S=0按h=0处理；K0=0内源不入任何正M cut，除非目标属于sigma≥1的整bad自动支。M=0不在C2除法范围，整bad支须单独由b≤1证明而非声称令M=0后仍直接套公式。

先行判断：标量包络、容量上放及预算反解准确；它给更大的明确物理paid pair支，无一般覆盖结论。等待reserve_envelope.md成稿后审，不扩研究。


## 9. reserve_envelope.md完整后审

已在第8节独立优化之后实读完整成稿§1–§5。绑定SHA256：

    14db72c247af88908cbe56c61c71c7bedfca1090c3728a92d5048c5f0b9f9da3

判断：RE1–RE4及明确scope通过，无实质修订。RE1是对同一alpha的联合优化，不是分别对reserve/rho取互不相容极值；饱和点、h=3及F(0)约定正确。RE2的容量上放h≤H_M方向及p、J、D、et系数与第8节相同。RE3在sigma=4/9接合、sigma≥1的全bad单列、sigma趋1阈值趋0均合法；没有实际除零或把M=0代入S。

成稿明确原非零高行p>0、D≥1、TDelta>0，d0/Delta0零槽单列，K0可为零且不作其倒数。alpha0按reserve得cut后验质量0，不使用1/alpha。阈值依t/v只在原正pair Cauchy中用；未当作可变terminal FTC门。原bad身份、samealpha及fullactualsource保留，all-u扩大后的good内源没有借U=0。

RE4恰由单个union pair支的companion≤Lcap²J与EJ/ZJ继承，外价16Lambda/(3K)Lcap sqrt(nlog2)W与独立核算一致。sigma分段只是一个物理门定义，不产生额外层数或可重复领取的energy预算；先保留R174完整来源槽分割，仅在其未付R_eta内切pair即可互斥组合。

原delta严格低score面、source/receiver measure、uniquej、hard一次、原窗口及history费用没有改变。该稿的“更大支”只表示相对旧cubic门的集合包含，未声称新支覆盖R_eta或补集便宜；结尾完整保留低K0/w残余、可能的其他原内源份额和其他mother核槽。有限scalar检验不作为RE1证明，本独审未运行脚本。


## 10. residual_capacity.md完整后审

已在第7节独立证明之后，实读RC1–RC16及全稿说明，并亲读R170最终冻结task_contract.md原good/U/alpha及raw行；原raw确含1_bad(u)，其定义可用于B1而无需借all-u扩大式。绑定SHA256：

    e69b278f1c631f25d5407dcf80447c099c742756e1caa32e97a78b78187bc848

判断：指定命题和完整费用通过，无实质修订。

RC2是原alpha捕获等式的非负分解，K0共同合法、K0nu≤q、D≥1及bad上U=0均准确；bad是原terminal绝对门而非canonical Q-superlevel B。RC3只把实际Zt/低score/pair门丢向完整bad的K0质量，没有将nu归一或假定bad无权质量小。

RC4–RC7的samealpha cubic消去、243系数及QJ/et≤p/(2K)与独立证明完全一致。alpha0分支不除alpha，d0/Delta0非活跃target不定义残余门，K0zero内源留低部。稿中严格s>0可进一步推出alpha>0的观察明确为额外条件性陈述，不用于新付款；没有冒称alpha统一下界。

RC8的Mcap不依辅助t，RC11 exact门则保留actual QJ/et。RC7保证exact≤physical门，二者给不同集合并明确没有混报。RC9的等号归高部，保留原bad、严格低score及全部原门。原Mcap和sharp门均可依实际x,y,v行，且只缩原正pair，没有改变source Pi对receiver的原非前视量词。

RC10/RC12的同reserve被用于不同target只是逐点同时成立的不等式；真正结算仍按一个原target后验和固定J积分，不重复领取q。分数pair门按Cauchy两槽共同测度处理，丢原非负门仅放大EJ和companion。RC1的16Lambda/(3K)Lcap sqrt(nlog2)W已逐常数核验；log2来自ZJ，hard16/3与outer2Lambda各一次，uniquej保留至一致界后，没有新n+2、future菜单、source分层或删除次数。

RC13是原非负pair互斥切分，RC14仅在GC11原未付R_eta加此新source价，因而没有把已付B/P/Q槽又计成新cut；把同一个EJ/ZJ用于证明不同upper bounds并不使其他已付支免费，稿件准确留了新增费用。RC15及RC16保留全部lowK0/w、R_eta目标、bad及严格score门，未声称其receiver质量、alpha或companion便宜。

父级sharp reserve门可替换本稿保守Mcap扩大paid支；若在总账中采用sharp支，则以其唯一相应补集替换Hlow，不能将cubic和sharp同域费用重复计入。两稿在低sigma支的阈值恰相同，高sigma改进与第8–9节一致。本独审未运行或重复数值。

目前等待Astra core_joint_geometry.md准确成稿；未以本次pair支或clock条件声称完整R_eta已付。


## 11. Astra共同来源quartic结构：作者前独立筛查

父级给出准确命题后，尚未读Astra稿，先独立核同一共同输入结构。固定实际x,V及j（以及同一原窗口/seed），nu、beta不依积分y，beta=nu+zeta，zeta≥0。K0=P_(s,Hhat)按原R170合同在此固定x,j下对整个y积分共同，J=P_(1,b)共同，故QJ=Jnu不依y。D_y记号可沿原D，但不允许为优化而重选。由共同合法FIRST，

    deltaq=q−K0nu≥K0zeta≥0,
    gamma_y=alpha_y QJ/D_y
           =deltaq+integral(K0−U_y/D_y)nu
           ≥deltaq,
    gamma_y≥integral_(bad_y) K0nu.                     (D1)

若deltaq>0且gamma_y>0，定义

    tau(dy)=K0(x−y) zeta(dy)/gamma_y,
    mu_y(du)=K0(x−u)1_(bad_y)(u)nu(du)/gamma_y.

则tau总量≤K0zeta/deltaq≤1，且逐y有mu_y总量≤1。这里mu_y保留对y的实际条件依赖，绝不能当成与tau独立的同一来源概率。也没有将nu(v)归一。

在严格soft K0处处正时，deltaq=0强制zeta=0，故tau可直接取零；gamma_y=0强制bad_y的nu质量为0，原bad-pair在该y为零，mu_y取零不会丢原正交通。若允许s=0的硬核，则K0=0上可能有非零zeta或bad来源；这些zero-K部分不能由上述tau/mu重构，必须独立留账。原R175实际strictsoft范围需由成稿准确声明，不能仅从kernel符号推全域正性。

对非零正target令b=alpha_y J_v/(TDelta_v)。则

    alpha_y² J_v rho_v²
      =(TDelta_v)²/J_v · b²(d_v−b)_+²
      ≤(TDelta_v)²d_v⁴/(16J_v),                         (D2)

最大点b=d_v/2。正标量优化不重选actualalpha；d0/Delta0原target零槽不作除法。

在zeta外源且bad内源部分，原companion密度是

    p_y² rho_v² J_v/(9Q_v²) · wt(v)wt(u)/e_t²

对zeta(dy)nu(dv)1_bad nu(du)，保留原strictscore、good/terminal/R_eta以及任何原pair/history/cut。用两次精确密度替换zeta=gamma_y tau/K0_y、1_bad nu=gamma_y mu_y/K0_u，再用gamma_y²=alpha_y² QJ²/D_y²及D2，得到对nu(dv)tau(dy)mu_y(du)的上界kernel

    p_y² (QJ)² (TDelta_v)² d_v⁴ wt(v)wt(u)
       /[144 D_y² Q_v² J_v e_t² K0_y K0_u].             (D3)

144=9·16，J在分母而非分子，et²及两K0分母均不可省。所有依赖y/v/u/t的系数仍真实存在。归一只改变这个恒等积分的写法，不改变原Pi/nu/alpha，也没有为kernel建立统一列界。

特别的尺度费用：本subprob陈述目前固定j。原K0可依j；tau_j分别质量≤1不能推出sum_j tau_j质量≤1，即便原uniquej(y)门互斥。因为归一分母gamma_(y,j)及K0j各自不同，逐j使用subprob后直接去掉j求和可损失原互斥性。成稿只能保留原sum_j/uniquej或另证共同列界；若只以每j总量1收费，可能有原n+2层费，不能免价。共同窗口及history同理不因新概率记号免费合并。

独立结论：固定共同K0的zeta外源quartic变换D1–D3正确；严格正性边界按上述处理。nu外源部分未处理，D3的共同kernel无已证全局预算，不能登记为新付款或一般闭合。等待成稿后审。


## 12. 主LaTeX及互斥总账对读

已实读当前proof.tex.txt所有主要公式。原bad储备、同alpha联合优化、H_M容量上放、sigma反解、全bad自动支及sharp/cubic集合包含均与第7–9节一致。eta来源槽与本轮Lcap pair槽不同，原Q核也不因新概率记号被空间归一。主稿的新增source价16Lambda/(3K)Lcap sqrt(nlog2)W和GC11旧source/receiver价逐常数一致。

完整账先切R174来源槽，只在原未付R_eta切sharp pair。因此两轮付款集合不交；本轮cubic和sharp是同一门的保守/精确版本，不累计重收。末项R_eta∩Hsharp补集保留原bad、实际rho及严格低score。原signed负账没有借用，其他mother核仍未付。主稿未使用general-clock新未知gate，也没有把quartic subprob结构登记新费用。

当前绑定proof.tex.txt SHA256：

    31f83524cfcf00f5fef3a4a7250c9b158366d8c6768bf8c08d379442c11e0013

本独审不读新numerics作为一般证明，不重复脚本；有限future/interval标量通过不能升级continuum FIRST、正L1/history/FULL。主稿明确保留这个边界。

## 13. core_joint_geometry首次成稿后审及必要定义澄清

已先完成第11节独立推导，再实读CJ1–CJ12?全部成稿。首稿SHA256：

    55b3ad691ac6ae07529ee8a89983b87375dc26a91b98d8fbf7c35879998594b0

公式与费用范围通过；唯一发现的形式定义缺口已直接反馈作者：CJ5以“当G0>0，定义tau与mu”引入两测度，但G0=0只强制zeta=0，gamma_y仍可正且nu外槽仍可非零，CJ9仍须mu。故mu公式必须明确对所有gamma_y>0成立，无须G0>0；gamma_y0时取0。tau在G0=0时取0。此澄清不改任何公式/证明/常数，但完成后须另绑定最终hash。

其余新增后审结果：CJ1完整保留原真实密度wt(v)wt(u)/et²与bad门，H不吸收rho、J/(3Q)或来源密度；hard放松仅作合法非负上界，并未冒称原raw等式。CJ2是原EJ加本companion的Cauchy接口，不预先假定companion已付。

CJ3使用同一共同K0及nu≤beta≤f，准确给K0zeta≤q−K0nu；CJ4的同gamma同时下界两储备，并非两份可任意分配budget。原K0在固定x,j对y共同，但对x/j仍自适应，稿件没有冒称固定空间核。CJ5用共同G0控制tau质量，保留mu_y条件依赖，nu(v)未归一。strictsoft正核处理G0/gamma0正确；hardzero部分明确不在本结构范围、不能免费除去。

CJ7的F1是alpha J rho²的两条并行上界之min，CJ8的F2是alpha²Jrho²的两条并行上界之min；边界a≥d时rho0，min仍有效。CJ9只一次bad换密度，得到QJ F1/(D K0u)，没有伪造nu外槽第二份储备。CJ10两次换密度得到QJ²F2/(D² K0y K0u)，CJ11 quartic项144、Jv分母、et²、d⁴全部与第11节独立推导相同。

CJ12?准确标为未证列积分目标。正文显式保留sum_j/原uniquej门及潜在n+2价、nu与zeta两槽、actualdx和窗口/history，未把逐j子概率质量误当共同总质量。只有证明该真实列预算后才可领取CJ2的source价，本轮没有登记。故本结构不改变R174余项及本轮low捕获补集未付的结论。


## 14. 唯一定义修订验收、最终绑定及冻结

已实读CJ5修订句：tau在G0>0时定义；mu_y在所有gamma_y>0时按式定义，无须G0>0；gamma_y=0时取零。G0=0的nu外槽因此有完整定义，zeta外槽仍按严格正核结论为零。第13节指出的定义缺口已修复，其余数学未变，完整指定范围通过。

最终实算并绑定理论稿SHA256：

| 文件 | SHA256 |
| --- | --- |
| residual_capacity.md | e69b278f1c631f25d5407dcf80447c099c742756e1caa32e97a78b78187bc848 |
| reserve_envelope.md | 14db72c247af88908cbe56c61c71c7bedfca1090c3728a92d5048c5f0b9f9da3 |
| core_joint_geometry.md | a0b7d5a919d04ca63d39ca43f07fb8e9fdbf07993443d835f30645dbecaa5349 |
| proof.tex.txt | 31f83524cfcf00f5fef3a4a7250c9b158366d8c6768bf8c08d379442c11e0013 |

最终结论：原samealpha reserve支付明确physical bad-pair上部，sharp联合包络严格改进部分cubic门；完整raw价为16Lambda/(3K)Lcap sqrt(nlog2)W，与GC11按互斥来源/pair顺序合并。一般共同clock身份成立但低score校正仍必须计费。quartic双储备只认证固定j、保留密度的结构，未付CJ12列积分、nu外槽及j费用不得省略。本轮没有支付全部低捕获余项、其他mother核份额或一般弱型上界。

数值由父级与专责数值审查另行核验，本独审未运行脚本，也未把finitefuture/区间检查认作continuum FIRST、L1/history/FULL认证。以上一般公式均来自独立推导和后审，而非作者结论或数值输出。

本次有界独审完成；仅修改责任geometry_audit.md，无Git、spawn、PDF及作者文件修改。现冻结停止，不再扩展研究。
