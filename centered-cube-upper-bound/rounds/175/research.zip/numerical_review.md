# R175 numerical review

## Constructive physical probe

The first108 candidates and all their rejection reasons are preserved separately from the approved64-candidate hard-face correction. The modification is geometrically specific: r=.4 puts the completion inside Hhat, while r=.45 is on the closed current L face and outside the selected Hhat faces. No other geometry, K, source mass ratio or future check was relaxed. The final172 candidates stay within the original200/2min budget; no further expansion follows success or failure.

The selected f,beta,nu use the same physical source positions, with nu<=beta=f as atomic measures and positive outer beta mass. q is evaluated from that same f. U,alpha,rho,A,good and high are recomputed together. The K0 future check and hard-source mass use the completion atom as well as the outer atom; neither is a free probe.

The interval certificates at N128 and256 use exact rational positions/masses, g and the original Hhat/T formulas, directed physical C and receiver kernels, and certified exp/log/sqrt. All displayed gates have separated signs. The current equality is symbolic because q is defined as that current convolution; it is not tested by subtracting independent interval copies. Other displayed future values have positive interval margins. j0,D=1 and strict softness are verified from their actual formulas. K remains diagnostic.

For each selected row, physical interval signs certify C_good<.5<C_bad<h and both canonical core memberships. Thus the target has score n, the other source score0 until C_bad, and equal scores thereafter. The positive integral is exactly p A times the drop of its posterior. Same terminal alpha/rho/A remain fixed through this clock. EJ=nJ_v times that posterior drop and Cb=p^2 A_v^2/J_v times the drop/n, so the corresponding Cauchy equality is structural rather than a comparison of interval upper endpoints.

Both cases satisfy Gamma>.5log n already before the eta correction. S=nlog s is exact because the target source lies outside the b hard cube in every coordinate. Theta>S and Theta>.5log n therefore certify the named finite Reta source region. The actual beta-weighted positive is retained and is much smaller than the conditional row value. No source-budget or positive-dx inference is made.

These are two interval-certified finite physical-form input rows with only finite future checks and conditional Zall. In particular an atom on the current hard face is not an L1-stable construction; no continuum FIRST, original history or FULL statement is inferred. The parent retains independent code/replay and theorem review responsibility.

## Parent reserve_envelope_check.py

Independent code review and replay pass. For h>0 the unsaturated objective is h z(1-z)^2 on z<=1/h, with derivative h(1-z)(1-3z). It is maximized at z=1/3 when h<=3. When h>3, the unsaturated objective increases to z=1/h and the saturated objective (1-z)^2 decreases from that point, giving (1-1/h)^2. The transition value is4/9 at h=3. The stated linear upper envelope follows from (h-3)^2(4h-3)>=0 for h>=3. The listed inverses are consistent on their respective branches.

I reran the parent script with `--output /tmp/r175_reserve_review.json`; all14 rational h values,1001 grid points each and7 inverse checks are identical to its JSON. Neither parent file was modified. These finite exact checks support the independently proved scalar envelope, and do not establish physical realizability or any global maximal-operator conclusion.


## Final Q definition and new cutoff audit

Parent review caught a draft definition error: K2 had been evaluated at scale1 for every dimension. Before freezing, both prescreen and certificate paths were corrected to actual Lplus=min(1,(1+1/n)L), and the K2 finite-future test was added when absent from the base menu. All172 prescribed constructions were rerun without expansion and the same two selected inputs recertified. The final n16 certificate uses Lplus=153/160, not1; its17 finite-future tests all pass. Earlier n16 draft Q/cut values are not final evidence.

The added physical cutoff uses the residual d before alpha, not rho. At Lcap=K/3, both sigma intervals are strictly below4/9, so the sharp/cubic equality is applicable. The upper interval endpoint of K0_u/wg_u lies far below the lower endpoint of M. Monotonicity wt_u>=wg_u then proves whole-clock low-capture membership without time quadrature or a posterior independence assumption. The same-alpha bad reserve fraction uses the actual bad source mass nu_u; the outer tau atom uses epsilon in beta and the physical receiver K0_y. Alpha Jnu is kept as the common original denominator. No summation/source-budget conclusion is attached to these finite quantities.
