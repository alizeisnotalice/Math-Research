from fractions import Fraction as Q
from pathlib import Path
import json,argparse

def F(h):return Q(4,27)*h if h<=3 else (1-1/h)**2

def main():
 rows=[]
 stages={'initial':[Q(1,100),Q(1,2),Q(1),Q(2),Q(3)],'pressure':[Q(2999,1000),Q(3001,1000),Q(4),Q(27,4),Q(9)],'expanded':[Q(1,10**9),Q(100),Q(10000),Q(10**9)]}
 for stage,hs in stages.items():
  for h in hs:
   opt=Q(1,3) if h<=3 else 1/h
   exact=(1-opt)**2*min(Q(1),h*opt)
   assert exact==F(h)
   for k in range(1001):
    z=Q(k,1000);assert (1-z)**2*min(Q(1),h*z)<=exact
   assert F(h)<=min(Q(1),Q(4,27)*h)
   rows.append({'stage':stage,'h':str(h),'optimizer':str(opt),'value':str(exact),'grid_points':1001,'status':'exact_pass'})
 inv=[]
 for sigma in [Q(1,100),Q(1,4),Q(4,9)]:
  H=Q(27,4)*sigma;assert F(H)==sigma;inv.append({'sigma':str(sigma),'Hmax':str(H)})
 for root in [Q(2,3),Q(3,4),Q(9,10),Q(999,1000)]:
  sigma=root**2;H=1/(1-root);assert F(H)==sigma;inv.append({'sigma':str(sigma),'Hmax':str(H)})
 out={'scope':'Exact finite scalar checks only. General scalar proof is analytic in reserve_envelope.md; no general maximal-operator or physical realizability inference.','rows':rows,'inverse_checks':inv,'all_exact_pass':True}
 p=argparse.ArgumentParser();p.add_argument('--output',default=str(Path(__file__).with_suffix('.json')));a=p.parse_args();Path(a.output).write_text(json.dumps(out,indent=2)+'\n');print(f'{len(rows)} extrema x1001 grid checks and {len(inv)} inverse checks passed')
if __name__=='__main__':main()
