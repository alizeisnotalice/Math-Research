# R315 — sequential source-interior and receiver-contact payment

## 1. Exact contract and statement

Fix one ORIGINAL outer-data/clock instance. Let n>=1, 0<a<=b<=2a, lambda>0, q_-=3lambda/4<=q(x)<=lambda, and finite positive L1 sources beta,nu. Keep the actual accepted receiver set E, selected s(x) in [0,1], L(x),R(x) in [a,b], and

    U_y(x)=1_E(x)alpha(x,y)P_(s(x),L(x))(x-y)/q(x),
    0<=alpha<=1,  rho(x)=integral U_y(x)beta(dy)<=1,
    J_y(r)=integral_{R(x)<=r}U_y(x)dx,
    I_y=J_y(b),   X=lambda|E|,
    ell_n(dr)=b^(-n)delta_b(dr)+n r^(-n-1)1_(a,b)(r)dr.

All original low-pe,m, full e_g, history and aspect qualifications already in alpha remain evaluated from the original sources. No virtual receiver FIRST, component FIRST, future-softness FIRST, or relation nu<=beta is used. We use the physical-cube B_H of `/tmp/r313_input_302.md`, for any H>0:

    B_H=integral beta(dy)nu(dz)ell_n(dr) 1{J_y(r)>=H}/J_y(r)
        integral_{R(u),R(w)<=r}U_y(u)U_y(w)c_u(z)(1-c_w(z))du dw, (1)
    c_x(z)=1{z in Q_(R(x))(x)}.

Here Q_R has side length R. Formula (1) is exactly the usual half-symmetric-difference formula, by swapping u,w. Denominators on J=0 are set to zero; H>0 excludes them. Extra z-dependent qualification disagreement in a different functional is NOT covered by identifying it with physical cube disagreement.

Assume the matched ORIGINAL full source f dominates nu as a measure and has the same-center all-radius cap on E:

    nu<=f dx,  G0(x)=sup_(a<=t<=b)h_t*f(x)<=4lambda.

Define the nonnegative actual winner defect

    D_eff=integral_E rho(x)[G0(x)-h_(R(x))*f(x)]dx.     (2)

This is zero for original full-source hard winners. It must be retained for general selected R. The provenance audit `/tmp/r314_contact_provenance.md` verifies source domination and the all-radius cap for the identified old R237/R112 restrictions via R237 and R244; it does not identify their old selected R as a winner. Native hard-winner fields have zero defect, but a complete entry linking any native target to (1) is a separate requirement.

Write A_n=1+n log(b/a). Let 0<eta<1 and h>0 be FIXED for this outer instance, not selected freely per source pair. Put

    r0=a/eta,  t_h=max(a,b-2h),
    kappa_h=(1+2h/a)^n-1,
    b0(eta)=1+n log(min(b/a,1/eta)).

Define the exact residual B_c,far(eta,h) to be (1) restricted by ALL of

    R(u)>r0,
    z in Q_(R(u))(u) \ Q_(eta R(u))(u),
    r<t_h,
    delta(u,w):=||u-w||_infinity+|R(u)-R(w)|/2>h.     (3)

The actual missed endpoint 1-c_w, full U at both endpoints, full J, high-J condition and all original masks remain in this integral. Empty intervals give zero. In particular if r0>=b it is empty. Equality R(u)=r0 belongs to the bottom branch.

The following general estimate is the new sequential payment:

    B_H <= [b0(eta)+1+log(1+kappa_h)]W_nu
       + min{4eta^n X, (16/3)eta^n A_n Csoft_n W_beta}
       +4kappa_h X +D_eff+B_c,far(eta,h),             (4)

where Csoft_n=sum_(k=0)^n max_(0<=s<=1) binom(n,k)s^k(1-s)^(n-k)
obeys Csoft_n<=1+(pi/2)sqrt(n). The beta source version in the minimum is independent of the receiver volume. If X is infinite, receiver terms are extended-value bounds; their exact replacements use lambda integral I_y beta(dy). No absorption is claimed without the original finite entry.

For a<b, the ROOT-SOURCE choice

    eta^n=1/A_n,   kappa_h=epsilon/4,
    h=(a/2)[(1+epsilon/4)^(1/n)-1], epsilon>0,

gives

    B_H <= [2+log A_n+log(1+epsilon/4)]W_nu
       +(16/3)Csoft_n W_beta+epsilon X
       +D_eff+B_c,far(eta,h).                         (5)

For a=b the stronger fixed-scale bound B_H<=W_nu holds directly.

The separate RECEIVER choice, for 0<epsilon<8,

    eta^n=epsilon/8,   kappa_h=epsilon/8,
    h=(a/2)[(1+epsilon/8)^(1/n)-1],

gives

    B_H <= [2+log(8/epsilon)+log(1+epsilon/8)]W_nu
       +epsilon X+D_eff+B_c,far(eta,h).               (6)

The residuals in (5),(6) have different fixed eta,h and must not be interchanged. These results pay actual positive pieces of the original auxiliary B_H. They do not prove a source-root estimate for the remaining collar-far piece.

## 2. Sequential allocation: bottom and deep interior

Partition the integrand of (1), in this order, by its capturing endpoint u:

1. B_bottom: R(u)<=r0.
2. B_deep: R(u)>r0 and z in Q_(eta R(u))(u).
3. B_collar: R(u)>r0 and z in Q_(R(u))(u)\Q_(eta R(u))(u).

These are disjoint and exhaustive because (1) already includes c_u. Thus B_H=B_bottom+B_deep+B_collar EXACTLY, including scale atoms. The collar restriction is oriented and need not be symmetric in u,w.

For either first piece integrate the bad endpoint only AFTER preserving its original factor. Its restricted mass is at most full J_y(r), cancelling the existing denominator in an upper bound. Drop the high-J restriction only after this positive domination. The inclusive layer identity

    ell_n([R(u),b])=R(u)^(-n)                         (7)

then proves

    B_bottom<=integral_E rho(u)1{R(u)<=r0}
                         h_(R(u))*nu(u)du
       <=[1+n log(min(b,r0)/a)]W_nu.                 (8)

For the last step apply shared FIRST rho<=1 at the original receiver, then extend u and integrate the single hard-scale envelope on [a,min(b,r0)]. Its mass is exactly the bracket. This pays each hard source once, not once per row or per selected radius. When r0>=b the bottom piece is the whole B_H.

On B_deep, the smaller scale eta R(u) belongs to (a,b]. Crucially the all-radius cap is at this SAME accepted center u. It gives

    nu(Q_(eta R(u))(u))<=4lambda eta^n R(u)^n.

Together with (7) and the same full-J cancellation,

    B_deep<=4lambda eta^n integral I_y beta(dy).      (9)

This yields 4eta^n X by shared FIRST. Alternatively the full-soft row envelope proved below gives I_y<=A_n Csoft_n/q_-, so (9) is at most

    (16/3)eta^n A_n Csoft_n W_beta.                  (10)

Neither estimate needs winner equality or a density bound on nu. When eta R<a no smaller-radius cap is asserted: that endpoint was allocated to (8).

## 3. Exact common-softness envelope and root coefficient

For the original product soft kernel write its positive degree expansion

    P_(s,L)=sum_(k=0)^n b_nk(s)Q_(k,L),
    b_nk(s)=binom(n,k)s^k(1-s)^(n-k).

Each Q_(k,L)=L^(-n)Q_k(./L) is the normalized average of the products with exactly k soft coordinates. Q_k is a probability density and is ray-nonincreasing; the original one-dimensional hard and soft factors both have these properties. No coordinate is allowed to choose its own softness. For c_nk=max_s b_nk(s),

    sup_(s,L)P_(s,L)(x)<=sum_k c_nk sup_(a<=L<=b)Q_(k,L)(x).

For any ray-nonincreasing probability profile Q, the dilation inequality is

    sup_(a<=L<=b)L^(-n)Q(x/L)
       <=b^(-n)Q(x/b)+n integral_a^b L^(-n)Q(x/L)dL/L.

One proof uses finite increasing scale partitions: the increase from the next scale backwards is bounded by the normalization decrease, since Q(x/L) is nondecreasing with L. Sum and pass to the supremum by monotone refinement (or use the equivalent Stieltjes inequality). This applies to discontinuous hard factors too. Integrating in x yields A_n, and hence

    integral sup_(s,L)P_(s,L)(x)dx<=A_n Csoft_n.      (11)

The actual alpha<=1 and q>=q_- then give the I_y bound used above. Csoft_n is a coefficient sum, NOT an asserted equality for integral sup_s P_s. The archived shape and scale inequalities are independently traced in `/tmp/r315_soft_envelope_provenance.md` to R293 and R302.

For completeness, b_nk(s) is unimodal. Its maximum equals its value at s=0 plus the integral of its positive derivative. Therefore

    Csoft_n=1+integral_0^1 sum_k (b'_nk(s))_+ ds.

Since sum_k b'_nk=0, with V distributed Binomial(n,s),

    sum_k (b'_nk(s))_+
      =E|V-ns|/[2s(1-s)]<=sqrt(n)/[2sqrt(s(1-s))].

The integrable endpoint singularities and integral_0^1[s(1-s)]^(-1/2)ds=pi prove the asserted root bound. This is an exact common-softness argument and incurs no independent coordinate maxima.

## 4. Contact payment applies after the oriented collar restriction

Split B_collar in the order r>=t_h; then r<t_h,delta<=h; then r<t_h,delta>h. The last term is exactly (3). The first two terms are bounded by the WHOLE symmetric top and contact pieces of B_H. This positive superset step is important: no symmetry is asserted for the oriented collar piece itself.

The R314 top estimate gives

    B_collar,top<=B_top<=[1+n log(b/t_h)]W_nu
                                  <=[1+log(1+kappa_h)]W_nu. (12)

In brief, Q_y(r)/J_y(r)<=integral nu(dz)A_yz(r). Tonelli over r>=t_h gives the actual kernel

    rho(x) nu(Q_(R(x))(x))/max(R(x),t_h)^n.

After original FIRST it is bounded by the hard envelope on [t_h,b]. No source fee is repeated for the collar and the bottom: the two original allocations are disjoint, while their upper prices are allowed to use the same full W_nu a stated finite number of times.

For contact, if r<t_h and delta<=h, both enlarged scales R(x)+2delta are <=b. Same-center source domination and the full hard maximum give

    nu(Q_(R+2delta)(x)\Q_R(x))
       <=G0(x)[(R+2delta)^n-R^n]
                       +R^n[G0(x)-h_R*f(x)].

Each side of the two-cube symmetric difference is in the other cube's outward shell. On the full symmetric contact piece, integrate the resulting two endpoint bounds with U_y(u)U_y(w)/(2J_y(r)). The other endpoint integrates to the unchanged J; then (7) removes R^n. Consequently

    B_collar,contact<=B_contact<=4kappa_h X+D_eff.    (13)

This argument is precisely the R314 contact theorem. It uses full-source maximality through the explicit defect, not an invented nu density. If R is a verified actual full hard winner, D_eff=0. Original selected-radius caps alone cannot set it to zero. Combining (8)--(13) proves (4).

For (5), r0<=b follows from 1+log t<=t with t=(b/a)^n: A_n<=(b/a)^n. Thus b0=1+log A_n and (10) loses its scale factor. For (6), (8) is bounded by 1+log(8/epsilon), including the case eta<a/b where the bottom branch already includes all captures. Equations (9),(13) each cost at most epsilon X/2. If a=b, applying shared FIRST to the single-scale first moment immediately gives B_H<=W_nu. This treats all endpoint and empty-branch cases.

## 5. Original target, fees and the exact remaining obstacle

At the original R302 equal-coefficient H=sqrt(d A_n/(4lambda)), its previously proved entry is

    T_target<=4sqrt(lambda d A_n)(W_beta+W_nu)+2B_H.

Substitution of (5) gives the valid continuation

    T_target<=4sqrt(lambda d A_n)(W_beta+W_nu)
      +(32/3)Csoft_n W_beta
      +2[2+log A_n+log(1+epsilon/4)]W_nu
      +2epsilon X+2D_eff+2B_c,far(eta,h).             (14)

Alternatively (6) replaces the two new source lines by

    2[2+log(8/epsilon)+log(1+epsilon/8)]W_nu,

with its own eta,h. The aspect/height parameters are unchanged:

    d=kappa0 psi_inf/(q_-v0),
    lambda d=(4/3)kappa0 psi_inf/v0,
    kappa0=2K/(ell M), psi_inf=3-2/(3gamma^n), gamma=1+1/n.

The original positive outer multiplier and clock integrate EVERY term of (14). No extra free time, source restriction, or unique-band summation is introduced. The source-optimized H or original receiver entry can be retained instead; the new theorem holds for every H>0. Absorbing epsilon X requires the separately verified complete entry for this SAME X. Selecting actual winners afresh requires a valid rerun of the original uniform construction, not replacing the old R after its masks or J were built.

The source-root part of (14) is explicit, but (3) still lacks a source-root price. The following exact calculation explains why ignoring its missed endpoint is insufficient. Suppose r0=a/eta<b and consider the collar-only source kernel

    sup_(r0<=R<=b)R^(-n)1{eta R/2<||x-z||_infinity<=R/2}.

Writing rho=2||x-z||_infinity, its value almost everywhere is zero for rho<=a; r0^(-n) for a<rho<=r0; rho^(-n) for r0<rho<=b; and zero beyond b. Thus its integral is EXACTLY

    1-eta^n+n log(b/r0).                             (15)

At eta^n=1/A_n, this is A_n-1/A_n-log A_n, still of scale A_n. Under the stated strict hypothesis r0<b, the strict lower cutoff R>r0 in (3) has the same supremum almost everywhere. If r0=b, the actual strict residual (3) is empty; its envelope is zero, whereas the closed single-scale family at R=b has mass 1-eta^n, so no strict/closed equality is asserted at that endpoint. For the root-source choice with a<b, r0<b follows from the strict inequality 1+log t<t for t=(b/a)^n>1. Hence a fresh application of shared FIRST after discarding the missed endpoint recovers a linear scale cost. This is a kernel-envelope computation, not a counterexample to the original target.

For clarity the needed overlap has not vanished: for fixed y,r,u define

    J_far=integral_{R(w)<=r,delta(u,w)>h}U_y(w)dw,
    A_far(z)=integral_{R(w)<=r,delta(u,w)>h}U_y(w)c_w(z)dw.

The exact remaining inner factor in (3) is

    U_y(u)1_{collar_u}(z)[J_far-A_far(z)]/J_y(r),

with the original r<t_h and high-J factors. A usable source-root estimate must exploit this true overlap, or a more economical original target entry, rather than paying (15). No bound making A_far a fixed fraction of J_far is proved here.

Finally, collar mass itself is NOT rare at true hard winners. If nu=f and eta R>=a, winner maximality implies

    f(Q_(eta R)(x))<=eta^n f(Q_R(x)),
    f(Q_R(x)\Q_(eta R)(x))>=(1-eta^n)f(Q_R(x)).      (16)

For a restricted nu<=f only, this lower bound need not hold for nu. Even for nu=f, (16) is a statement about captured source mass, NOT the proportion of B_H or its far residue. It shows why the remaining same-source overlap problem is substantive. Root payment of (3), any nonzero winner defect, extreme-aspect costs and the complete outer ledger remain separate obligations.

## 6. Reproducible bounded checks and their scope

The embedded exact-Fraction check below uses real positive-volume box sources and actual receiver cubes. Its three stages use n=1,2; n=4,8; n=16,32. It checks the oriented bottom/deep/collar partition and its per-row deep payment, including all radius atoms, empty inner-scale branches, equality at r0 and H endpoints. The full source is 1_(Q_4), so the all-radius average cap is 1, and lambda=1/4. A fresh isolated Python process passed 192 partition checks, 192 deep-budget checks, 636 legal inner-cap checks and 48 empty-branch checks (1068 exact checks total). The receiver masses here are finite quadrature weights; this diagnostic does NOT claim they are an original FIRST-compatible full-soft input. The continuum FIRST and row-envelope payments are proved above.

```python
from fractions import Fraction as F
from itertools import product
from math import prod
ct={'partition':0,'deep_budget':0,'legal_inner_cap':0,'empty_branch':0}
def box(c,r):return [(x-r/2,x+r/2) for x in c]
def mass(*bs):
 return prod(max(F(0),min(B[i][1] for B in bs)-max(B[i][0] for B in bs)) for i in range(len(bs[0])))
for stage in ((1,2),(4,8),(16,32)):
 for n in stage:
  src=[(F(-2),F(2))]*n
  centers=[(F(0),)*n,(F(1,4),)*n,(F(3,4),)*n]
  rs=[F(1),F(3,2),F(2)]
  cubes=[box(c,r) for c,r in zip(centers,rs)]
  for eta,us,H in product((F(1,2),F(2,3),F(3,4),F(7,8)),
    ((F(1,4),F(1,2),F(1,4)),(F(1),F(2),F(3))),(F(1,4),F(1),F(3),F(6))):
   total=bottom=deep=collar=F(0);r0=1/eta
   for j,r in enumerate(rs):
    wt=r**(-n)-(rs[j+1]**(-n) if j+1<len(rs) else F(0))
    act=list(range(j+1));J=sum(us[i] for i in act)
    if J<H:continue
    for i,k in product(act,act):
     fee=wt*us[i]*us[k]/J
     cm=mass(src,cubes[i])-mass(src,cubes[i],cubes[k])
     total+=fee*cm
     if rs[i]<=r0:bottom+=fee*cm
     else:
      inner=box(centers[i],eta*rs[i])
      dm=mass(src,inner)-mass(src,inner,cubes[k])
      assert 0<=dm<=cm
      assert mass(src,inner)<=(eta*rs[i])**n
      ct['legal_inner_cap']+=1
      deep+=fee*dm;collar+=fee*(cm-dm)
   assert total==bottom+deep+collar;ct['partition']+=1
   assert deep<=eta**n*sum(us);ct['deep_budget']+=1
   if r0>=2:
    assert deep==collar==0 and total==bottom;ct['empty_branch']+=1
print('PASS',ct)
```

The separate frozen numeric author files `/tmp/r315_numeric.py`, `.json`, `.md` contain 14506 exact Fraction checks, including cluster variance, actual cube overlap and true-winner stress fixtures. Parent reports a fresh successful rerun. Those receiver quadratures are not claimed as full FIRST certificates, and the winner collar stress is not a proof that the entire B_H residue is large. Only `/tmp/r315_geometry.md` is written by this author; no other file or Git state is changed.
