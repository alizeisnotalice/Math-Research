from fractions import Fraction as F
from random import Random
rng=Random(315);ct={'anova':0,'common_capture':0,'relaxed_threshold':0,'shrink_same_threshold':0}
radii=(F(1),F(3,2),F(2));xs=(F(-1,2),F(0),F(3,4));zs=(F(-3,4),F(-1,4),F(1,4),F(3,4),F(5,4))
for trial in range(120):
 n=(1,2,4)[trial%3];mu=[F(rng.randrange(4),3) for _ in xs];nu=[F(rng.randrange(4),5) for _ in zs];N=sum(nu)
 R=[rng.choice(radii) for _ in xs];S=[rng.choice(radii) for _ in xs]
 cr=[[int(abs(x-z)<=r/2) for z in zs] for x,r in zip(xs,R)]
 cs=[[int(abs(x-z)<=s/2) for z in zs] for x,s in zip(xs,S)]
 def state(ids,lab):
  j=sum((mu[i] for i in ids),F(0));A=[sum((mu[i]*lab[i][z] for i in ids),F(0)) for z in range(len(zs))]
  val=sum((w*(a-a*a/j) for w,a in zip(nu,A)),F(0)) if j else F(0)
  return j,A,val
 def innovation(common,added,lab):
  j,A,fi=state(common,lab);h,V,fa=state(added,lab)
  cross=F(0) if not j or not h else j*h/(j+h)*sum(w*(v/h-a/j)**2 for w,v,a in zip(nu,V,A))
  return fa+cross
 vals=[]
 for r in radii:
  ir=[i for i in range(3) if R[i]<=r];is_=[i for i in range(3) if S[i]<=r];co=sorted(set(ir)&set(is_));old=sorted(set(ir)-set(is_));new=sorted(set(is_)-set(ir))
  jr,ar,fr=state(ir,cr);js,ass,fs=state(is_,cs);_,_,ficr=state(co,cr);_,_,fics=state(co,cs)
  kr=innovation(co,old,cr);ks=innovation(co,new,cs)
  assert fr-fs==ficr-fics+kr-ks and 0<=kr<=N*sum((mu[i] for i in old),F(0));ct['anova']+=1
  e=sum(mu[i]*sum(w*abs(cr[i][z]-cs[i][z]) for z,w in enumerate(nu)) for i in co)
  assert abs(ficr-fics)<=e;ct['common_capture']+=1
  vals.append((jr,fr,js,fs))
 ec=sum(mu[i]*sum(w*abs(cr[i][z]-cs[i][z]) for z,w in enumerate(nu))/max(R[i],S[i])**n for i in range(3))
 pu=sum((mu[i]*(R[i]**(-n)-S[i]**(-n)) for i in range(3) if S[i]>R[i]),F(0))
 layers=[r**(-n)-(radii[k+1]**(-n) if k+1<len(radii) else 0) for k,r in enumerate(radii)]
 for H in (F(1,4),F(1),F(2)):
  br=sum(w*fr for w,(jr,fr,js,fs) in zip(layers,vals) if jr>=H)
  for c in (F(1,4),F(1,2),F(3,4)):
   bs=sum(w*fs for w,(jr,fr,js,fs) in zip(layers,vals) if js>=c*H)
   assert br<=bs+ec+N*pu;ct['relaxed_threshold']+=1
  if all(s<=r for r,s in zip(R,S)):
   bs=sum(w*fs for w,(jr,fr,js,fs) in zip(layers,vals) if js>=H)
   assert br<=bs+ec;ct['shrink_same_threshold']+=1
print('PASS',ct)
