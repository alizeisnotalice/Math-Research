# 第315轮：中间硬层的定向薄壳交通与根阶来源预算

## 结论与范围

一般中心立方体极大算子的 n^(1/2+o(1)) 一致弱型上界仍未证明。本轮得到实际来源的完整正分割：较小捕获尺度、深内部、顶端积分层与接触接收点依次支付，剩余严格保留中间尺度、远接收点和捕获端内侧薄壳三者的联合交通。分割使用原接收权、同一完整 J 和真实来源质量；不以薄层体积推断来源质量小。

这是 R302 的原几何费用 B_H 的新估计，不是完整弱型定理，也不是原时间原子的预算。它具有两种可用收费方式：不先吸收接收项的根阶来源方式，以及显式 epsilon X 方式。两种方式是替代方案，不叠加；R313 初始化分解同样不与本轮重复相加。

## 1. 完整合同

固定一个原外层实例。f>=0 为完整L1输入，nu<=f dx；beta 为原软来源。原实际接收集 E、完整软核、共同 q∈[3lambda/4,lambda]、原 z 无关门 alpha∈[0,1] 定义

U_y(x)=alpha(x,y)1_E(x)P_(s(x),L(x))(x-y)/q(x),

rho(x)=∫U_y(x)beta(dy)<=1_E(x)。保留全部原 low-pe、m、aspect、历史及来源资格，不为本轮重新计算 FIRST。a<=L,R<=b<=2a，G0(x)=sup_[a,b]h_t*f(x)<=4lambda。定义 X=lambda|E|，I_y=∫U_y dx，J_y(r)=∫_(R<=r)U_y dx，A_yz(r)=∫_(R<=r)U_y(x)1_(Q_R(x))(z)dx。

原层测度 ell_n=b^(-n)delta_b+n r^(-n-1)1_(a,b)dr，满足 ell_n([R,b])=R^(-n)，端点原子不可删除。B_H 是 R302 高J费用 ∫beta ell 1_(J>=H)∫(A-A²/J)dnu，H>0。

采用定向写法，捕获端为 u、遗漏端为 w：

B_H=∫beta(dy)ell_n(dr)1_(J>=H)/J ∫_(R(u),R(w)<=r)U_y(u)U_y(w)nu(Q_R(u)(u)\Q_R(w)(w))du dw。

没有额外1/2；与对称差写法的1/(2J)精确相等。所有新分支都限制此同一正积分，分母始终是完整J。

全共同软度的既有包络给 ∫U_y<=A_n Csoft_n/q_-，A_n=1+n log(b/a)，Csoft_n=Σ_k max_s Bin(n,k)s^k(1-s)^(n-k)<=1+π√n/2。Csoft_n是包络系数质量，不是∫sup_s的相等式。R293/R302原件与独审定位另附，未将双选择器卷积的A_n²费用偷换为单端A_n。

## 2. 不需硬最大化的新来源分割

固定0<eta<1，不得令eta随接收点或来源任意变化。按捕获端u先分：

- bottom：R(u)<=a/eta；
- deep：R(u)>a/eta 且 z∈Q_(eta R(u))(u)；
- collar：R(u)>a/eta 且 z∈Q_R(u)(u)\Q_(eta R(u))(u)。

等号归bottom，三个分支精确覆盖。遗漏端、原高J门、原ell及全部原资格仍在。

先把遗漏权 ∫Uw 1_(z不在Qw)/J 正性控制为1，再用ell恒等式。bottom经真实FIRST后用硬尺度包络，只收一份nu质量：

B_bottom <= [1+n log min(b/a,1/eta)] W_nu。

在deep分支，eta R>=a保证同一接收点内尺度合法；nu(Q_(eta R))<=4lambda(eta R)^n，不需要密度帽、分量FIRST或赢家等式。因此

B_deep <=4lambda eta^n ∫rho(x)dx
       <=min{4eta^n X, (16/3)eta^n A_n Csoft_n W_beta}。

当a/eta>=b时全部属于bottom，deep/collar为空；R=b端点仍在bottom中保留。a=b时直接 B_H<=W_nu，以下根阶参数分支仅用于a<b。

取eta^n=1/A_n，即得

B_H <=(1+log A_n)W_nu+(16/3)Csoft_n W_beta+B_collar。

这已支付两个真实来源分支，且来源费为O(√n)；它没有证明剩余薄壳交通小。

## 3. 与接触几何顺序组合

在上一步剩余collar上，再按r>=t_h=max(a,b-2h)、低r且delta(u,w)<=h、低r且delta>h分，其中delta=||u-w||inf+|R(u)-R(w)|/2。先将前两项分别扩大到R314完整top/contact正集合，之后才使用对称性；不能对非对称collar门直接取消另一端J。

令kappa=(1+2h/a)^n-1，D_eff=∫rho(x)[G0(x)-h_R*f(x)]dx。R314支付top<= [1+log(1+kappa)]W_nu，contact<=4kappa X+D_eff。

剩余 C_(eta,h) 是上述定向原积分额外保留

R(u)>a/eta, z∈Q_R(u)(u)\Q_(eta R(u))(u),
r<t_h, delta(u,w)>h, z不在Q_R(w)(w)

的部分。它仍是实际来源、真实dx、原fullJ与原外层权下的联合交通，不是边界体积或重新定义的源后验。

根阶来源方案：eta^n=1/A_n，h=a[(1+epsilon/4)^(1/n)-1]/2，得到

B_H <= [2+log A_n+log(1+epsilon/4)]W_nu
       +(16/3)Csoft_n W_beta+epsilon X+D_eff+C_(eta,h)。

接收吸收方案：0<epsilon<1，eta^n=epsilon/8，h=a[(1+epsilon/8)^(1/n)-1]/2，则

B_H <= [2+log(8/epsilon)+log(1+epsilon/8)]W_nu
       +epsilon X+D_eff+C_(eta,h)。

后式deep/contact各用epsilon X/2，总和才是epsilon X。两式残项的eta不同，不把残项混同。真实完整硬赢家时D_eff=0；旧冻结选择器未认证赢家时必须保留D_eff，其粗界4X不可吸收。

## 4. 极值几何与完整总账

若nu=f且R为真实最大化半径、eta R>=a，同中心最大化反而给

f(Q_(eta R))<=eta^n f(Q_R)，
f(Q_R\Q_(eta R))>=(1-eta^n)f(Q_R)。

当a/eta<b时，单独丢弃遗漏接收权后，collar源列包络的精确质量为1-eta^n+n log(b eta/a)；根阶参数eta^n=1/A_n下等于A_n-1/A_n-log A_n，仍是线性尺度费用。这是包络恒等式，不是原目标的反例。因此必须保留原(J_far-A_far(z))/J，不能将共同来源捕获收益抹掉。

因此thin collar可能含绝大部分完整捕获质量。这只是来源质量结论，不是C_(eta,h)/B_H的下界。下一主瓶颈是该真实薄壳捕获与遗漏接收点之间的共同来源/重叠预算，不能用边界稀少推断代替。

R302原入口仍是 T<=4sqrt(lambda d A_n)(W_beta+W_nu)+2B_H，其中lambda d=(4/3)kappa0 psi_inf/v0；全部m、aspect及正外层Lambda照乘，不能省略极端比例补集。本轮任何epsilon X经此入口成为2epsilon X，经旧共享树恢复Lambda=128/119后为2Lambda epsilon X。唯一leaf接收集和概率seed使其至多同一原X；若再有完整入口系数C_ent，最终须乘C_ent，尚不能自行令它为1。epsilon=119/32768时仅该局部旧账收费为X/128，并非总吸收已经完成。

本轮核查澄清：可以从一开始在完整硬带选择可测argmax R*，据它生成全部资格，此时新构造D_eff=0。R104的统一输入条件允许这种初始选择；无需证明旧冻结门在事后替换R下不变。尚未认证的是完整原始硬带到真实FULL/Gamma/R_out的入口与重建假设链。共同FIRST只在已删除基线/端点等输出后的E_ret上使用，接收费用可正性扩大到X_band。原native R_HP、R_corr不能仅凭名称认作旧T或B_H。

总账仍保留：宽距离/低pe大m及极端aspect、初始I、删除跳跃J、未来被删来源连续D、未付suffix及原负项各一次，以及完整入口/最终吸收系数。R314/R315只处理特定几何费用，不能替代这些独立项。

辅助比较稿另证明事后换半径的有向前缀误差：B_H(R)<=B_(3H/4)(S)+E_capture+W_nu P_up。它保留改变J门与半径原子的费用；不是本轮首选fresh构造的额外收费，也不是免费换选择器证书。

## 5. 实际检验、技能与交付

本机Python标准库Fraction fresh复跑14,506项检查，输出JSON与作者冻结结果逐字节相同。三阶段维度2/4、8/16、32/64，真实正体积来源与四接收点有限求积，验证定向bottom/deep/collar、层端点、完整J和接收分组方差分解。它们没有实现原连续FIRST或真实Lebesgue接收场，故不认证全局空间费用。

追加真实连续硬赢家长盒模型：R*=3/2，来源[0,3]×[-1/8,1/8]^(n-1)，接收点(-3(n-1)/(4n),0,...)。连续最大化来自R314解析推导；本轮精确交体积显示eta=1-1/(2n)时collar占一半，eta=1-1/n的合法n>=4时占全部。n2的后一内尺度<a，明确排除其内帽比较。此结果改变路线判断：剩余collar不能视作稀少。

另fresh复跑作者来源分割/内帽脚本1,068项精确检查（采用bottom闭端点约定；主数值脚本采用同样合法的另一端点约定，均单独验证其正分割），以及辅助选择器比较脚本1,902项精确检查；该有限原子来源测试只认证代数/几何诊断。独审自己的高精度诊断与精确检查分开记录，不混入上述主代理精确计数。

本轮阅读64项工具的E03树Bellman技能、课题接口与来源状态：未建立当前非嵌套几何的真实树流与终端预算，因此未调用外部Bellman定理，只把其假设检查用于筛选累计势路线。既有R293/R302包络直接由归档证明继承。本轮未编译PDF。实际模型扣额数据不可得，不估算成本比例。

复现：解压后运行 python3 numeric.py、python3 geometry_checks.py 与 python3 joint_checks.py。保存详细LaTeX、主证明、独审、来源定位及三份脚本；生成JSON不重复入库。每轮单独提交，仅增加README和research.zip并更新项目总览。
