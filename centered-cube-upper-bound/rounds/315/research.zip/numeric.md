# R315 finite spatial-cluster and source-location diagnostic

The standalone standard-library script passes 14,506 exact Fraction assertions. The registered 18 models comprise n=2,4 (4,290 checks), n=8,16 (5,094), n=32,64 (5,094), with three fixed geometry mechanisms at each n. Each model has four actual cubes in two spatial-sign clusters, side lengths 1 and 3/2, and positive-volume uniform box sources. There are 108 H/near-split budgets: H=1,2,3 and h=1/16,1/4. The later preregistered source-location extension uses eta in {1/2,3/4,1-1/(2n)}, deduplicated, for 306 budgets. No model is optimized after seeing results.

Actual geometry and exact compression

* Lobes: two sources of mass 1/2 each, side 1/4, centered at first coordinate +/-3/4 and zero otherwise. Two receivers at each source center, radii 1 and 3/2, all weights 1. Transverse coordinates are fully captured: this is explicitly a one-axis separation embedded in n dimensions.
* Overlap: one unit-mass unit-side source cube at zero; receiver centers at first coordinate +/-1/4, zero otherwise, radii 1 and 3/2, all weights 1. Its transverse capture is also complete.
* Dense boundary: one unit-mass source cube of side 1/4 at zero. Receiver centers are (-1/2,...,-1/2), (-1,...,-1), (1/2,...,1/2), (1,...,1), with corresponding weights 1,16,1,16 and radii 1,3/2,1,3/2. The light receivers capture opposite source orthants of mass 2^-n; heavy receivers miss the source. This uses all n coordinates.

For each geometry, tensor interval intersections compute the mass captured by every receiver subset. Exact Mobius inversion recovers all capture-pattern masses (at most 16), with nonnegativity and every intersection independently reconstructed. This retains genuine positive-volume L1 mass; it neither samples source points nor assumes a density cap uniform across dimensions.

For each radius prefix, J=sum h and A=sum h capture. The script verifies F=integral A(1-A/J), its pair-disagreement expression, and the law of total variance

    F = sum_c J_c integral p_c(1-p_c)
        + sum_c J_c integral (p_c-p)^2.

The second term is conditional-mean between-cluster energy. It is separately recorded from the sum of receiver-pair energies whose endpoints lie in different clusters; these are different quantities. Low-capture-ratio energy is the part of F on source cells with p=A/J<1/8.

All quantities retain exact layer weights r^(-n)-r_next^(-n), terminal atom 2^(-n), and inclusive J>=H. Top means r>=t=max(1,2-2h). Below t, pairs are near iff their actual delta=||x_i-x_j||inf+|R_i-R_j|/2 is <=h. All 108 budgets satisfy BH=top+near+far and integrated within+between identities. The recorded first moment is sum ell M; it is not replaced by an unsupported FIRST source bound.

Candidate-driven source split

At each capturing endpoint i, bottom means R_i<1/eta. Otherwise the actual captured source is divided between Q_(eta R_i)(x_i) and its collar Q_Ri\Q_(eta Ri). For an ordered pair, its contribution is h_i h_j/J times nu(Q_Ri\Q_Rj). Deep contribution uses the exact intersection with Q_(eta Ri); collar is the exact difference. This gives both a full-BH split and the same split restricted to low-layer far pairs. The script verifies all 306 full and 306 far identities and 13,056 nonnegative deep-within-capture comparisons. It does not certify either source-price coefficient without actual FIRST and the required cap interfaces.

Decisive finite results

At H=3, the light-radius J=2 prefix is excluded and the full prefix remains. For the lobes, all BH is ANOVA between-cluster energy. With h=1/16 and eta=1-1/(2n), its far energy splits exactly half bottom, half deep, zero collar. Thus this finite far mechanism is genuinely source separation, and it is not automatically a collar mechanism.

For overlap at H=3, between/BH=1/3 while cross-cluster receiver-pair energy/BH=2/3. At n=64, eta=127/128, the far split is bottom 1/3, deep 253/384, collar 1/128. The bottom/deep interfaces therefore materially affect what remains to estimate; calling all far energy collar would be false in this fixture.

For dense boundary at H=3, source cells with nonzero A have p=1/34. All BH lies in the low-p part. ANOVA between/BH=1/33, whereas cross-cluster receiver-pair energy/BH=17/33. Its far energy is entirely bottom; no eligible deep or collar capturing endpoint contributes. Cluster means alone thus miss substantial within-cluster low-capture energy in this registered model. At n=2, BH=11/51; at n=64 it equals 11/19457541648324237413061144839259. The tiny latter value is reported as actual finite data, not fitted to a dimension order.

Changing h to 1/4 makes t=3/2, so the H=3 prefix is entirely top. This is a change in the exact auxiliary split, not an additional disjoint payment. All top/near/far identities use the same original BH.

True-winner collar pressure (additional preregistered section)

To prevent extrapolating arbitrary receiver quadratures to winner geometry, a final 28-check section uses the R314 full unit-mass long box [0,3] x [-1/8,1/8]^(n-1), not an arbitrary binary capture fixture. At all six n it fixes R*=3/2 and g=3(n-1)/(4n). Continuous hard maximization at this R* is established analytically in R314; this section verifies physical source intersections, not that continuous theorem. The complete-source capture is exactly R*/(6n)>0.

For eta=1-1/(2n), all six inner radii eta R*>=1 are legal, and the actual inner fraction is exactly 1/2, hence collar fraction exactly 1/2. Its inner fraction is <=eta^n. For eta=1-1/n, the five legal n>=4 cases have inner fraction zero and collar fraction one, again satisfying inner<=eta^n. At n=2, this latter inner radius is 3/4<a: it is recorded as excluded from the deep-cap comparison, even though its physical intersection can be computed. The 11 legal cases verify collar>=1-eta^n by exact fractions.

Thus the low collar fractions of some earlier arbitrary-quadrature models cannot be used to call the remaining collar rare at actual winners: a positive-L1 true-winner fixture retains half or all captured source in it. No spatial fee or FIRST realization is asserted by this final section.

Limitations and reproduction

These are actual cube/source intersections and finite nonnegative receiver quadratures. They do not realize original FIRST, a selected receiver field with Lebesgue measure, full low/e/m history, or all-input/root closure. The deep and bottom *decompositions* are certified; their analytic source fees are not supplied by these quadratures. There is no asymptotic fit or adversarial geometry search.

Run in a fresh process:

```
/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 /tmp/r315_numeric.py
```

Output JSON is deterministic and written beside the script. It stores all geometry, source boxes, capture-pattern masses, prefix moments, pair energies, gates, and source splits. No external packages, randomness, prior temporary script imports, or floating-point certificate decisions are used.
