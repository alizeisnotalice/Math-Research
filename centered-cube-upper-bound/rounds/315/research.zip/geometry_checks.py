from fractions import Fraction as F
from itertools import product
from math import prod
ct={'partition':0,'deep_budget':0,'legal_inner_cap':0,'empty_branch':0}
def box(c,r):return [(x-r/2,x+r/2) for x in c]
def mass(*bs):
 return prod(max(F(0),min(B[i][1] for B in bs)-max(B[i][0] for B in bs)) for i in range(len(bs[0])))
for stage in ((1,2),(4,8),(16,32)):
 for n in stage:
  src=[(F(-2),F(2))]*n
  centers=[(F(0),)*n,(F(1,4),)*n,(F(3,4),)*n]
  rs=[F(1),F(3,2),F(2)]
  cubes=[box(c,r) for c,r in zip(centers,rs)]
  for eta,us,H in product((F(1,2),F(2,3),F(3,4),F(7,8)),
    ((F(1,4),F(1,2),F(1,4)),(F(1),F(2),F(3))),(F(1,4),F(1),F(3),F(6))):
   total=bottom=deep=collar=F(0);r0=1/eta
   for j,r in enumerate(rs):
    wt=r**(-n)-(rs[j+1]**(-n) if j+1<len(rs) else F(0))
    act=list(range(j+1));J=sum(us[i] for i in act)
    if J<H:continue
    for i,k in product(act,act):
     fee=wt*us[i]*us[k]/J
     cm=mass(src,cubes[i])-mass(src,cubes[i],cubes[k])
     total+=fee*cm
     if rs[i]<=r0:bottom+=fee*cm
     else:
      inner=box(centers[i],eta*rs[i])
      dm=mass(src,inner)-mass(src,inner,cubes[k])
      assert 0<=dm<=cm
      assert mass(src,inner)<=(eta*rs[i])**n
      ct['legal_inner_cap']+=1
      deep+=fee*dm;collar+=fee*(cm-dm)
   assert total==bottom+deep+collar;ct['partition']+=1
   assert deep<=eta**n*sum(us);ct['deep_budget']+=1
   if r0>=2:
    assert deep==collar==0 and total==bottom;ct['empty_branch']+=1
print('PASS',ct)
