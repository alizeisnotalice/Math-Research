#!/usr/bin/env python3
"""R315 exact real-cube cluster diagnostic, standard library only."""
from fractions import Fraction as F
from collections import Counter
from pathlib import Path
import json
counts=Counter()
def ck(key,b):
 counts[key]+=1
 assert b,key

def box(c,R):return tuple((v-R/2,v+R/2) for v in c)
def volume(b):
 v=F(1)
 for l,r in b:v*=max(F(0),r-l)
 return v

def intersect(*bs):return tuple((max(x[0] for x in xs),min(x[1] for x in xs)) for xs in zip(*bs))
def mass(src,*bs):return sum((w*volume(intersect(s,*bs))/volume(s) for s,w in src),F(0))
def make(n,kind):
 zero=(F(0),)*n
 if kind=='lobes':
  cs=[(v,)+(F(0),)*(n-1) for v in [F(-3,4),F(-3,4),F(3,4),F(3,4)]]
  src=[(box(c,F(1,4)),F(1,2)) for c in [cs[0],cs[2]]]; weights=list(map(F,[1,1,1,1]))
 elif kind=='overlap':
  cs=[(v,)+(F(0),)*(n-1) for v in [F(-1,4),F(-1,4),F(1,4),F(1,4)]]
  src=[(box(zero,F(1)),F(1))]; weights=list(map(F,[1,1,1,1]))
 else:
  cs=[(v,)*n for v in [F(-1,2),F(-1),F(1,2),F(1)]]
  src=[(box(zero,F(1,4)),F(1))];weights=list(map(F,[1,16,1,16]))
 return dict(n=n,kind=kind,centers=cs,radii=[F(1),F(3,2),F(1),F(3,2)],weights=weights,sources=src,clusters=[[0,1],[2,3]])
def patterns(src,cubes):
 m=len(cubes); both={mask:mass(src,*[cubes[i] for i in range(m) if mask>>i&1]) for mask in range(1<<m)}
 exact={mask:sum(((-1)**((sup^mask).bit_count())*both[sup] for sup in both if sup&mask==mask),F(0)) for mask in both}
 ck('mobius_mass',sum(exact.values())==both[0]);ck('mobius_nonnegative',all(v>=0 for v in exact.values()))
 for mask in both:ck('intersection_reconstruction',sum(v for p,v in exact.items() if p&mask==mask)==both[mask])
 return {p:w for p,w in exact.items() if w}
def run(model):
 n=model['n']; rs=model['radii']; hs=model['weights']; cubes=[box(c,r) for c,r in zip(model['centers'],rs)]; ledger=patterns(model['sources'],cubes)
 def integral(fn):return sum((w*fn(p) for p,w in ledger.items()),F(0))
 prefixes=[]
 for r in [F(1),F(3,2),F(2)]:
  ids=[i for i,R in enumerate(rs) if R<=r];J=sum(hs[i] for i in ids);A=lambda p:sum((hs[i] for i in ids if p>>i&1),F(0))
  M=integral(A); fee=integral(lambda p:A(p)*(1-A(p)/J)); within=F(0);between=F(0)
  for cluster in model['clusters']:
   group=[i for i in cluster if i in ids]; j=sum((hs[i] for i in group),F(0))
   if not j:continue
   a=lambda p:sum((hs[i] for i in group if p>>i&1),F(0))
   within+=integral(lambda p:a(p)*(1-a(p)/j));between+=j*integral(lambda p:(a(p)/j-A(p)/J)**2)
  ck('total_variance',fee==within+between);ck('cluster_nonnegative',within>=0 and between>=0)
  pairs=[]
  for i in ids:
   for k in ids:
    if i>=k:continue
    diff=integral(lambda p:abs(int(bool(p>>i&1))-int(bool(p>>k&1))))
    delta=max(abs(x-y) for x,y in zip(model['centers'][i],model['centers'][k]))+abs(rs[i]-rs[k])/2
    energy=hs[i]*hs[k]*diff/J
    pairs.append(dict(i=i,k=k,delta=delta,energy=energy,cross_cluster=(i<2)!=(k<2)))
  ck('pair_energy',sum((p['energy'] for p in pairs),F(0))==fee)
  low=integral(lambda p:A(p)*(1-A(p)/J) if A(p)/J<F(1,8) else F(0))
  prefixes.append(dict(r=r,J=J,M=M,F=fee,within=within,between=between,low_ratio_F=low,pairs=pairs,cross_cluster_pair_F=sum((p['energy'] for p in pairs if p['cross_cluster']),F(0))))
 budgets=[]
 for H in map(F,[1,2,3]):
  for h in [F(1,16),F(1,4)]:
   t=max(F(1),F(2)-2*h); levels=sorted({F(1),F(3,2),F(2),t}); result={k:F(0) for k in ['BH','first_moment','within','between','low_ratio_F','cross_cluster_pair_F','top','near','far']}
   for j,r in enumerate(levels):
    row=max((p for p in prefixes if p['r']<=r),key=lambda p:p['r']);w=r**(-n)-(levels[j+1]**(-n) if j+1<len(levels) else 0)
    if row['J']<H:continue
    for key,src in [('BH','F'),('first_moment','M'),('within','within'),('between','between'),('low_ratio_F','low_ratio_F'),('cross_cluster_pair_F','cross_cluster_pair_F')]:result[key]+=w*row[src]
    if r>=t:result['top']+=w*row['F']
    else:
     result['near']+=w*sum((p['energy'] for p in row['pairs'] if p['delta']<=h),F(0))
     result['far']+=w*sum((p['energy'] for p in row['pairs'] if p['delta']>h),F(0))
   ck('integrated_total_variance',result['BH']==result['within']+result['between'])
   ck('top_near_far',result['BH']==result['top']+result['near']+result['far'])
   ck('first_moment_bound',0<=result['BH']<=result['first_moment'])
   for key in ['between','low_ratio_F','cross_cluster_pair_F','far','top']:
    result[key+'_fraction']=result[key]/result['BH'] if result['BH'] else None
   splits=[]
   for eta in sorted({F(1,2),F(3,4),1-F(1,2*n)}):
    split={k:F(0) for k in ['bottom','deep','collar','far_bottom','far_deep','far_collar']}
    for j,r in enumerate(levels):
     row=max((p for p in prefixes if p['r']<=r),key=lambda p:p['r']);w=r**(-n)-(levels[j+1]**(-n) if j+1<len(levels) else 0)
     if row['J']<H:continue
     ids=[i for i,R in enumerate(rs) if R<=r]
     for i in ids:
      small=box(model['centers'][i],eta*rs[i])
      for k in ids:
       raw=hs[i]*hs[k]/row['J']*(mass(model['sources'],cubes[i])-mass(model['sources'],cubes[i],cubes[k]))
       deep=hs[i]*hs[k]/row['J']*(mass(model['sources'],small)-mass(model['sources'],small,cubes[k])) if rs[i]>=1/eta else F(0)
       ck('deep_oriented_range',0<=deep<=raw)
       terms={'bottom':raw,'deep':F(0),'collar':F(0)} if rs[i]<1/eta else {'bottom':F(0),'deep':deep,'collar':raw-deep}
       delta=max(abs(x-y) for x,y in zip(model['centers'][i],model['centers'][k]))+abs(rs[i]-rs[k])/2
       for key,v in terms.items():
        split[key]+=w*v
        if r<t and delta>h:split['far_'+key]+=w*v
    ck('source_split_total',sum(split[k] for k in ['bottom','deep','collar'])==result['BH'])
    ck('source_split_far',sum(split[k] for k in ['far_bottom','far_deep','far_collar'])==result['far'])
    splits.append(dict(eta=eta,**split))
   budgets.append(dict(H=H,h=h,t=t,source_splits=splits,**result))
 return dict(**model,capture_pattern_mass=[dict(mask=p,mass=w) for p,w in ledger.items()],prefixes=prefixes,budgets=budgets)
def serial(x):
 if isinstance(x,F):return str(x)
 if isinstance(x,dict):return {k:serial(v) for k,v in x.items()}
 if isinstance(x,(tuple,list)):return [serial(v) for v in x]
 return x

def main():
 reports=[]; stages=[]
 for name,ns in [('initial',[2,4]),('stress',[8,16]),('expanded',[32,64])]:
  before=sum(counts.values())
  for n in ns:
   for kind in ['lobes','overlap','dense_boundary']:reports.append(run(make(n,kind)))
  stages.append(dict(name=name,dimensions=ns,models=6,checks=sum(counts.values())-before))
 winner_pressure=[]
 for n in [2,4,8,16,32,64]:
  R=F(3,2);g=3*F(n-1,4*n);center=(-g,)+(F(0),)*(n-1)
  full_source=[(((F(0),F(3)),)+((F(-1,8),F(1,8)),)*(n-1),F(1))]
  capture=mass(full_source,box(center,R))
  ck('winner_pressure_full_capture',capture==R/(6*n)>0)
  for eta in [1-F(1,2*n),1-F(1,n)]:
   legal=eta*R>=1
   inner=mass(full_source,box(center,eta*R))/capture
   if legal:
    ck('winner_inner_contact',0<=inner<=eta**n)
    ck('winner_collar_lower',1-inner>=1-eta**n)
   winner_pressure.append(dict(n=n,R=R,g=g,eta=eta,inner_radius=eta*R,eligible=legal,capture=capture,inner_fraction=inner,collar_fraction=1-inner,eta_power=eta**n))
 result=dict(winner_pressure=winner_pressure,status='PASS',arithmetic='Fraction',scope='Actual positive-volume box source/cube geometry; finite receiver quadrature, not FIRST or original history.',check_counts=dict(counts),total_checks=sum(counts.values()),stages=stages,models=reports)
 Path(__file__).with_suffix('.json').write_text(json.dumps(serial(result),indent=2,sort_keys=True)+'\n')
 print(json.dumps({k:result[k] for k in ['status','check_counts','total_checks','stages']},sort_keys=True))
if __name__=='__main__':main()
