# R315 independent preauthor screen

Independent screen PASS, saved BEFORE reading new R315 author proof files. Own audit only; no Git or other-author edits. This is an actual positive capturing-endpoint allocation under explicit same-E full-cap/source-domination hypotheses, not a general root closure.

## Original orientation and exact source allocation

For physical-cube R302 variance, Q/J=integral A(r,z)[1-A(r,z)/J(r)]nu(dz). Expanding A as the actual capture integral gives the stated oriented captured-x/missed-other representation. Zero J contributes zero. All original full U, J,H, source/history gates, ell endpoints and actual receiver dx remain. A further oriented pair gate may be retained provided0<=M<=1; nonnegativity alone without an upper bound is insufficient. Dropping its bad-prefix factor uses integral_prefix U(1-c)M<=J, preserving the original denominator.

Fix eta in(0,1) for the whole original outer instance, independently of x,y,z. Set r0=a/eta. Either coherent endpoint convention is valid: bottom R<r0/deep R>=r0, or bottom R<=r0/deep R>r0; use exactly ONE in each residual identity. Inner boundaries belong to deep and the remaining outer collar is its exact complement. Eta may not silently be chosen separately per source row when using the one shared hard-source envelope.

## Bottom and deep payments

Bottom oriented fee is at most integral_E rho(x)h_(R(x))*nu(x)1_bottom dx. ORIGINAL FIRST rho<=1 precedes receiver extension; the single hard envelope on[a,min(b,r0)] has mass

1+n ln min(b/a,1/eta).

The closed envelope legitimately dominates a strict-scale endpoint and includes the terminal physical atom. If r0>=b, bottom is all original traffic apart from the consistently assigned equality endpoint; no illegal inner scale is queried.

On the deep branch eta R>=a and eta R<=b, so nu<=f and the SAME-original-receiver full all-radius ceiling G0<=4lambda give nu(Q_(eta R)(x))<=4lambda eta^n R^n. No winner equality is required. The remaining miss/prefix gate is<=1 and layers have ell([R,b])=R^(-n), hence

BH_deep<=4lambda eta^n integral_beta I_y
 <=4eta^n X, X=lambda|E|,
 <=(16/3)eta^n A_n Csoft_n Wbeta.

The last alternative uses only actual alpha<=1, q>=q_-=3lambda/4 and the original full-soft scale row envelope I_y<=A_n Csoft_n/q_-. It does NOT apply FIRST to individual degrees or assume a density bound. Source beta and nu need not be ordered; only the stated nu<=original full f plus all-radius cap is used.

For eta^n=epsilon/4,0<epsilon<4, bottom<=1+ln(4/epsilon) times Wnu and deep<=epsilon X. The exact remaining collar still carries all original factors. Absorption requires the SAME finite original X entry and outer coefficients, not an invented target.

## Root-source choice and the remaining collar

For a<b, A_n=1+n ln(b/a)>1. Taking eta^n=1/A_n is legal and r0^n=a^n A_n<b^n, since1+ln t<t for t=(b/a)^n>1. Then the bottom fee is exactly bounded by(1+ln A_n)Wnu and deep by(16/3)Csoft_n Wbeta. At a=b treat separately: the fixed-scale hard envelope already gives BH<=Wnu; eta=1 is not substituted into an eta in(0,1) theorem.

The common-soft coefficient-envelope bound is analytic:

Csoft_n=sum_k max_s b_nk(s)
 =1+integral_0^1 sum_k(b'_nk)_+ ds
 =1+(1/2)integral_0^1 E|K-ns|/[s(1-s)]ds
 <=1+(sqrt(n)/2)integral_0^1 ds/sqrt(s(1-s))
 =1+pi sqrt(n)/2.

Only the binomial coefficient distribution is used here; no source/actual posterior independence is asserted. Endpoint singularities are integrable and b_k(0) sums to1. Thus the displayed deep price is a true root source payment for that positive component.

A true full-f hard winner with nu=f and deep legal inner scale has f(Q_R\Q_etaR)>=(1-eta^n)f(Q_R). This is a SOURCE MASS lower bound, not a lower bound for the actual BH/collar-far fee after its missed-capture and prefix gates. It shows collar mass need not be rare. A direct annular hard-envelope bound for R in[r0,b] has mass1-eta^n+n ln(b/r0), when r0<=b; it remains linear-scale at eta^n=1/A_n. No root payment for the collar follows from these facts.

## Sequential contact combination screened independently

Partition the ORIGINAL oriented fee into bottom, deep and collar first. Apply R314 top/low-contact/far split ONLY to the collar remainder. Collar-top and collar-low-contact are nonnegative subfees of the full R314 top/contact pieces; first dominate by those full positive supersets, THEN use their symmetric estimates. A direct symmetry cancellation on the nonsymmetric capturing-collar restriction would be invalid. With kappa=epsilon/4 this gives

BH<=(16/3)Csoft_n Wbeta
 +[2+ln A_n+ln(1+epsilon/4)]Wnu
 +epsilon X+D_eff+B_collar,far.

The exact residual has capturing R>r0 (for the<=/> convention), captured z in Q_R\Q_etaR, missed other endpoint, low layer r<t_h and delta>h, and full original J/H/masks. It is a subset of the original oriented variance, not a recomputed source or denominator. Source prices bound disjoint target pieces by possibly overlapping positive supersets; this does not double-subtract target traffic. R313's auxiliary rank initialization is not silently added as another disjoint credit. No native/legacy winner identity is supplied by this theorem; D_eff remains until certified, while bottom/deep themselves need no winner.

## Actual bounded diagnostics

{'orientation_partition_Fraction': 6, 'inner_legal_cap_Fraction': 10, 'parameter_root_mp60': 21, 'Csoft_bound_mp60': 7}

Executed exact Fraction orientation/partition and real uniform-box inner-cap geometry checks, plus ordinary60-digit parameter/coefficient-envelope comparisons. All PASS. Finite receiver weights are occupation diagnostics, not realizations of the full original soft kernel/FIRST/history. The analytic argument proves the source prices; the exact collar far remainder and independent global/outer/entry gaps remain. Author comparisons and final bindings are recorded below.

## Auxiliary selector-transport proposition: independent screen before its proof

Screened the separately supplied comparator statement without reading r315_joint.md. For fixed ORIGINAL U/source fields, let R,S be measurable in[a,b] and0<c<1. PutT=max(R,S) and compare the common prefix{T<=r}. At a fixed common prefix J, variance F=integral(A-A^2/J)nu is1-Lipschitz in its capture mass A; changing actual c_R to c_S there costs at most integral_prefix U nu(Q_R Delta Q_S). Integrating layers gives exactly E_capture=integral_E rho nu(Q_R Delta Q_S)/max(R,S)^n.

The R-prefix excess over the common prefix has row mass h(r)=integral U1{R<=r<S}. If common J>=cH and original J_R>=H, monotonicity plus a receiver-block variance increment bound<=h Wnu compares to the S-prefix at thresholdcH. If common J<cH, thenh>(1-c)J_R and F_R<=J_R Wnu/4<=h Wnu/[4(1-c)]. Thus

BH(R)<=B_(cH)(S)+E_capture+max(1,[4(1-c)]^(-1))Wnu P_up,
P_up=integral_E rho1{S>R}(R^(-n)-S^(-n))dx.

The inclusive ell integral of1{R<=r<S} is exactlyR^(-n)-S^(-n), including terminal cases. WhenS<=R there is no excess/common-prefix loss, and same-H comparison holds without P_up. This is a valid comparison of auxiliary functionals with frozen U; it does not transport original history/low/e/m gates or give a general root price for P_up. Full-source winner contact may bound capture error with scale gap and old selected defect, but does not remove the positive prefix transport expense.


## Final author comparison and endpoint correction — PASS

Read both frozen mathematical proofs after saving the independent screens. The main source theorem, full-soft envelope proof, sequential positive allocation, general minimum-price estimate, root-source specialization and receiver specialization agree with the screen. The all-radius cap is used only at the SAME accepted receiver and a legal smaller scale. The source-only alternative follows from the one-ended full-common-soft dilation envelope, not a component FIRST or the two-ended convolution mass. The original R302 continuation correctly doubles EVERY newly substituted fee and retains lambda*d=(4/3)kappa0*psi_inf/v0. Different eta,h choices have different residuals.

One endpoint sentence required correction: the strict R>r0 collar envelope agrees with its closed counterpart only if r0<b. At r0=b the strict branch is empty, whereas the closed single-scale envelope has mass 1-eta^n. This has been fixed in final main hash 78299677...; its theorem and code are unchanged. The root-source specialization has r0<b strictly when a<b, so its main formula and annular obstruction calculation are unaffected. At a=b the fixed-scale estimate is used separately.

The auxiliary selector comparator is valid with its relaxed cH threshold and explicit upward-prefix expense. Its exact ANOVA/Lipschitz argument retains all old-only/new-only blocks. Original U, sources and history remain frozen. With c=3/4 the coefficient k_c is1. Same-H shrink-only comparison is valid; this does not authorize free changing of a frozen target radius, nor pay E_capture or Wnu*P_up generally.

## Provenance, original source ledger and fresh entry — bounded PASS

Read entry.md, selector_provenance.md and soft_envelope_provenance.md. Directly spot-checked the cited original ZIP clauses: R104 proof.md97–112, R237 source_ledger.md79–99, R244 receiver_ledger.md9–29, R293 proof.tex.txt177–193, and R302 r302_pair_kernel.md41–66. They support the selected-band uniform hypothesis, once-only leaf/probability-seed source budget, same-E all-radius ceiling, common-soft coefficient constant, and physical scale envelope as quoted. The R104 clause is a uniform theorem for a given measurable E,R; it is not a coverage theorem from the weak event to the FULL/history process.

A measurable complete-source hard argmax can be chosen at the BEGINNING on the native hard band, meeting the inspected R104 selected-band hypothesis, and every later selector-dependent gate can be constructed from it. Then the newly constructed matched defect is zero. This is not an invariance assertion for previously frozen masks/J/target. The full authentic native-band-to-FULL/Gamma/R_out entry, regenerated uniform hypotheses, and complete fee/adoption arithmetic remain uncertified. In particular retained FIRST is on E_ret, not reassigned to already-paid outputs in the full band.

For the matched old leaf/probability-seed aggregation, the contact receiver charge after the R302 factor2 is exactly2*Lambda*epsilon with Lambda=128/119; epsilon=119/32768 gives1/128. If a complete entry has coefficient C_ent multiplying R_out, the eventual charge is C_ent/128. No C_ent=1 or global absorption is inferred. A historical nonwinner retains2*Lambda*D_eff,total; the coarse bound8*Lambda*X_old is not absorbable. Native X_band, old X_old and native R_HP/R_corr are not identified merely by notation. Initial I, deletion-time J, future-deleted continuous D, suffix, wide/aspect complements and original negative terms remain each once. Physical radius atoms do not become history time atoms.

## Final combined, README, TeX and evidence review — PASS

Read final checkpoint combined.md, research.tex and README.md as text; no compilation or edits to those files. Their formulas agree with the frozen author statements. In particular the oriented formula has NO extra1/2; bottom uses closed endpoint and deep/collar strict endpoint; J is never recomputed; collar contact is enlarged to the full positive symmetric contact fee before using symmetry. Root-source and epsilon receiver alternatives are not added, and R313 initialization is not claimed disjoint from this payment. The strict annular formula in the integration is explicitly restricted to a/eta<b. The true-winner collar lower bound is complete-source MASS only, not a lower bound for BH or its residual.

Read standalone numeric.py/md and the final JSON scope, and inspected the primary fresh-run logs. They report14506 exact Fraction assertions, geometry1068=192 partition+192 deep-budget+636 legal-inner-cap+48 empty-branch, and auxiliary1902=360 ANOVA+360 Lipschitz+1080 relaxed-threshold+102 shrink. The checkpoint numeric.py and numeric.json are byte-identical to their author originals. Those scripts/logs are attributed to the primary fresh execution, not a second execution by this reviewer. This reviewer independently executed the bounded diagnostics listed above. Both bottom endpoint conventions are coherent, but the numeric script's strict-bottom/deep-equality partition is separately validated and is not silently substituted into the author residual. Finite receiver quadratures and atomic algebraic tests do not realize full continuum FIRST/history; the documented true-winner long-box source is normalized to unit mass. Its analytic continuous maximizer is inherited from R314, while current exact intersections verify the stated collar fractions only. No finite test substitutes for the analytic source fees or establishes general root growth.

## Frozen hash bindings

All hashes below were computed directly from the reviewed bytes. Main proof and integration have final endpoint wording.

| File | SHA-256 |
|---|---|
| /tmp/r315_geometry.md | 78299677d76d925f74c841dd607b6418d986152ac003b99ee702b06fddcb053c |
| /tmp/r315_joint.md | 996db185a881348c5f1d8ffafeb9bb05404f8090193eaf049661a94348336337 |
| /tmp/r315_entry.md | 6a3bbd0b2ff0dfd0dc5fbadd766e6e2b067166f7066fd52bf7fce1f68bf6cf1c |
| /tmp/r315_selector_provenance.md | 257f7ea92b8f532189097babc3515c92e4b9ea01353340602126d144b45903e8 |
| /tmp/r315_soft_envelope_provenance.md | b050fc30c2a1b2a2da9184e060beeab398b057da00925edb07edf965cd75b1fc |
| checkpoint/combined.md | 8b37b395a6060d220e386231f5339dcaf51f3f649c9af869d12c6f631ef75f34 |
| checkpoint/research.tex | 32d63cefa4bf9c75a2d70e6453c5db2fc42f40634a75fda95a10ed66be4b6d59 |
| checkpoint/README.md | e85b5ba66f2f33cc68ca958c68684534464c10ec02187134de3b49d7b5c98a5b |
| numeric.py (author and checkpoint) | 5e3f0cedac1bffa18d9e9f389e77721d6abb901872df05d071b9e2b44230deb8 |
| numeric.json (author and checkpoint) | 5a1598fd7a5e72ee2c1fe6afe3d126aa32863d7edd8b964821a378ced2c494ed |
| /tmp/r315_numeric.md | 75fec5caf16dbae8b59e8697cd783e1308b1b3d03a94fd696ecaaae66731ad1b |
| checkpoint/numeric_checks.log | 22b8dd21937a788a022e083b2beb64338e403ba5aeb3c03cec83ff1aa57bb4e4 |
| checkpoint/geometry_checks.py | 5e69381ca1d7651c08fb2f318af440c8141643a7e671a7356460c42188d459e3 |
| checkpoint/geometry_checks.log | ac29c6d1ff9b15b2f769bce1c3eec632ba04bad29b300ee638d4d0ddba3e330c |
| checkpoint/joint_checks.py | 5221279a620012d58e1deb161683ecd6a4b944c0d079a4a8e9365af60e695b51 |
| checkpoint/joint_checks.log | ec0c398626679fbfe786c9e5a7548484bd4f4d70773647d6a9c03d3575abb8fe |

Checkpoint root is /Users/zhengzhihao/Desktop/T/output/centered_cube_round315_20261018_final_checkpoint.

## Final verdict and exact remaining gap

PASS for these bounded mathematical statements and their final integration. Newly paid positive components are bottom capturing scales, deep source interior, then collar top/contact subfees with the stated source and receiver charges. The remaining fee is EXACTLY the original full-J oriented captured-collar / missed-other / low-layer / far-receiver joint traffic C_(eta,h), not merely a thin volume set. No source-root bound for it is proved; dropping its missed endpoint only returns the linear annular-envelope mass. The frozen historical winner defect, or a correctly rebuilt zero-defect fresh entry, the authentic coverage connector and all separate original ledger complements remain obligations. This receipt does not certify general weak-type closure or completed global absorption. Audit frozen; no further task expansion.
