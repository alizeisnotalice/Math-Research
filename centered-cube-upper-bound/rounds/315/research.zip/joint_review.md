# R315 — transporting actual capture variance to a hard winner

## 1. Candidate screen and theorem

Changing the selected radius changes BOTH the physical capture label and the prefix of receivers contributing to J. A capture-discrepancy estimate alone omits a genuine term. The comparison below keeps both changes and the high-J cutoff, including radius atoms. It is an actual comparator inequality, but the permitted hypotheses do not make all its errors small; no general legacy-to-native root bridge is claimed.

Use the original R302 U_y(x) and its masks unchanged, with mu_y(dx)=U_y(x)dx, arbitrary finite positive L1 beta,nu, and FIRST

    v(x)=integral U_y(x)beta(dy)<=1.

Let R(x),S(x) be any two measurable radii in [a,b]. In application R is the OLD selector and S is a full-source hard winner. Only the geometric comparator uses S: it is never substituted into the old low-pe/m/aspect gates, q, p_y, alpha, or the target. For T=R,S define

    c_T(x,z)=1{z in Q_(T(x))(x)},
    J_T(y,r)=integral_{T(x)<=r}mu_y(dx),
    A_T(y,r,z)=integral_{T(x)<=r}c_T(x,z)mu_y(dx),
    F_T(y,r)=integral [A_T-A_T^2/J_T]nu(dz),
    B_H(T)=integral beta(dy)ell_n(dr)1{J_T>=H}F_T(y,r).

At J_T=0 set F_T=0. Use the original inclusive ell_n=b^(-n)delta_b+n r^(-n-1)1_(a,b)dr. Put N=W_nu and

    e(x)=nu(Q_(R(x))(x) symmetric_difference Q_(S(x))(x)),
    E_capture=integral v(x)e(x)/max(R(x),S(x))^n dx,
    P_up=integral v(x)1{S(x)>R(x)}[R(x)^(-n)-S(x)^(-n)]dx.

For every H>0 and 0<c<1,

    B_H(R)<=B_(cH)(S)+E_capture+k_c N P_up,
    k_c=max(1,1/[4(1-c)]).                            (1)

In particular c=3/4 gives k_c=1. If S<=R at every retained receiver, the sharper SAME-threshold statement holds:

    B_H(R)<=B_H(S)+E_capture,   P_up=0.               (2)

This explains why a smaller maximizing radius can be compared without paying a prefix error; a larger maximizing radius cannot simply be inserted for free. Equations (1)-(2) are inequalities for the full actual rows, not assertions of component FIRST.

## 2. Exact ANOVA accounting at a prefix

Fix y,r. Let I={R<=r,S<=r}, O={R<=r<S}, P={S<=r<R}. For a label family c and a receiver set D write j_D=mu_y(D), A_D(z)=integral_D c(x,z)mu_y(dx), p_D=A_D/j_D, and

    F_c(D)=integral [A_D-A_D^2/j_D]nu(dz).

Use zero for empty-mass blocks. The EXACT disjoint-block identity is

    F_c(I union D)=F_c(I)+K_c(D|I),
    K_c(D|I)=F_c(D)
          +j_I*j_D/(j_I+j_D) integral (p_D-p_I)^2 nu. (3)

The cross term is zero if either block has zero mass. Consequently

    F_R-F_S=[F_(c_R)(I)-F_(c_S)(I)]
                  +K_(c_R)(O|I)-K_(c_S)(P|I).       (4)

This is the full signed prefix-change formula; discarding the old-only block O would omit real variance. For the common block, with j=mu_y(I)>0,

    F_(c_R)(I)-F_(c_S)(I)
      =integral (A_R,I-A_S,I)[1-(A_R,I+A_S,I)/j]nu,

so its absolute value is at most integral_I e(x)mu_y(dx). The coefficient one is the sharp scalar Lipschitz constant of A-A^2/j on [0,j]. Furthermore

    0<=K_c(D|I)<=N j_D.                              (5)

Indeed F_c(D)=j_D integral p_D(1-p_D)nu, and the cross coefficient is <=j_D. Pointwise p_D(1-p_D)+(p_D-p_I)^2<=1. The coefficient one in (5) can be approached when j_I/j_D is large and the two block labels are opposite. These sharpness statements concern the variance functional; no original-cube counterexample is asserted.

Equations (4)-(5) give the directional bound

    F_R<=F_S+integral_I e dmu_y+N mu_y(O).            (6)

All the posterior errors in (3) are genuine source integrals. The N mu_y(O) bound is a safe relaxation of them, not a claim that the resulting fee has already been paid by a source budget.

## 3. Threshold changes, physical scale integration, and atoms

On J_R>=H and J_S>=cH use (6). On J_R>=H>J_S/c, one instead has

    mu_y(O)>=J_R-J_S>(1-c)J_R,
    F_R<=N J_R/4<=N mu_y(O)/[4(1-c)].               (7)

Thus both cases are bounded by the new active term plus the common-capture error and k_c N mu_y(O). Integrate positively. For a fixed actual receiver x,

    integral ell_n(dr)1{R(x)<=r,S(x)<=r}
       =max(R(x),S(x))^(-n),
    integral ell_n(dr)1{R(x)<=r<S(x)}
       =1{R(x)<S(x)}[R(x)^(-n)-S(x)^(-n)].          (8)

Tonelli and original FIRST give exactly (1). In particular, a radius atom moved across a prefix, including the b endpoint, is charged by (8); no continuous interpolation of a selector is used. If S<=R, then O is empty and J_S>=J_R, so the same-H conclusion (2) follows directly. This proof also covers ties, zero receiver blocks and N=0.

A same-H comparison for arbitrary R,S would require keeping threshold-switch contributions. The relaxed threshold in (1) is what avoids silently dropping them.

## 4. What full hard maximality controls, and what it does not

Now assume nu<=f and, on the same original E,

    G0(x)=sup_(a<=t<=b) f(Q_t(x))/t^n<=4lambda,
    f(Q_(S(x))(x))=G0(x)S(x)^n.

The old winner defect is Delta_R=G0 R^n-f(Q_R)>=0. The cubes at a single center are nested, so full maximality gives

    E_capture <=integral v(x)G0(x)
                  [1-(min(R,S)/max(R,S))^n]dx
          +integral v(x)1{S>R}Delta_R(x)/S(x)^n dx.   (9)

For S<=R there is actually the additional NONPOSITIVE correction -v Delta_R/R^n, which was dropped in (9). For S>R, equality of the full-f shell mass is G0(S^n-R^n)+Delta_R. Thus maximizing an average does not by itself make the shell or its normalized scale factor small. A universally valid coarse bound is E_capture<=4lambda integral v<=4X when X=lambda|E| is finite. That is not an absorbable epsilon X estimate.

Full maximality also supplies no bound for P_up in (1): increasing the selected radius delays that receiver in every intervening prefix, even if its capture label on part of nu does not change. FIRST permits the explicit domination

    P_up<=integral_E 1{S>R}[R^(-n)-S^(-n)]dx,

but this need not yield a root source price for N P_up. Replacing it by a product of total source masses would not settle the requested budget. The exact ANOVA expression (3) may be smaller, but no source estimate for it is proved here. The old coarse fallback B_H(R)<=A_n N remains available; (1) is not claimed always cheaper.

The R314 contact theorem legitimately applies to B_(cH)(S), with the SAME old U: its proof only needs FIRST and the actual hard-winner cubes, not a recomputation of alpha. Accordingly the original R302 root entry, whenever its independently established hypotheses apply, has the valid continuation

    T_old<=4sqrt(lambda*d*A_n)(W_beta+W_nu)
        +2[1+log(1+epsilon/4)]W_nu+2epsilon X
        +2B_far(S)+2E_capture+2k_c N P_up.           (10)

Here H in the old entry is its original chosen value, the native comparator uses threshold cH, and B_far(S) is R314's exact low-layer far-pair part formed using that same U and S. Original d, all qualifications and outer Lambda remain; Lambda multiplies EVERY term. Finite-X absorption and the original target entry are not newly certified by this note.

Thus this comparison can move an old geometric field to a true winner without pretending prefixes are unchanged. It changes the next decision to an explicit receiver-weighted upward-scale transport budget, in addition to capture mismatch. The stated assumptions do not yet pay those errors generally. Directly retaining the old R314 contact defect may be cheaper than making this replacement; no improvement of the global exponent is claimed.

## 5. Executed finite checks

The following exact Fraction diagnostic returned `PASS {'anova': 360, 'common_capture': 360, 'relaxed_threshold': 1080, 'shrink_same_threshold': 102}`. It uses finite actual cube incidences and occupation weights. Atomic nu and occupation weights here are algebraic diagnostics, not a claimed realization of the original L1 full-soft/FIRST history. The continuum theorem is proved above.

```python
from fractions import Fraction as F
from random import Random
rng=Random(315);ct={'anova':0,'common_capture':0,'relaxed_threshold':0,'shrink_same_threshold':0}
radii=(F(1),F(3,2),F(2));xs=(F(-1,2),F(0),F(3,4));zs=(F(-3,4),F(-1,4),F(1,4),F(3,4),F(5,4))
for trial in range(120):
 n=(1,2,4)[trial%3];mu=[F(rng.randrange(4),3) for _ in xs];nu=[F(rng.randrange(4),5) for _ in zs];N=sum(nu)
 R=[rng.choice(radii) for _ in xs];S=[rng.choice(radii) for _ in xs]
 cr=[[int(abs(x-z)<=r/2) for z in zs] for x,r in zip(xs,R)]
 cs=[[int(abs(x-z)<=s/2) for z in zs] for x,s in zip(xs,S)]
 def state(ids,lab):
  j=sum((mu[i] for i in ids),F(0));A=[sum((mu[i]*lab[i][z] for i in ids),F(0)) for z in range(len(zs))]
  val=sum((w*(a-a*a/j) for w,a in zip(nu,A)),F(0)) if j else F(0)
  return j,A,val
 def innovation(common,added,lab):
  j,A,fi=state(common,lab);h,V,fa=state(added,lab)
  cross=F(0) if not j or not h else j*h/(j+h)*sum(w*(v/h-a/j)**2 for w,v,a in zip(nu,V,A))
  return fa+cross
 vals=[]
 for r in radii:
  ir=[i for i in range(3) if R[i]<=r];is_=[i for i in range(3) if S[i]<=r];co=sorted(set(ir)&set(is_));old=sorted(set(ir)-set(is_));new=sorted(set(is_)-set(ir))
  jr,ar,fr=state(ir,cr);js,ass,fs=state(is_,cs);_,_,ficr=state(co,cr);_,_,fics=state(co,cs)
  kr=innovation(co,old,cr);ks=innovation(co,new,cs)
  assert fr-fs==ficr-fics+kr-ks and 0<=kr<=N*sum((mu[i] for i in old),F(0));ct['anova']+=1
  e=sum(mu[i]*sum(w*abs(cr[i][z]-cs[i][z]) for z,w in enumerate(nu)) for i in co)
  assert abs(ficr-fics)<=e;ct['common_capture']+=1
  vals.append((jr,fr,js,fs))
 ec=sum(mu[i]*sum(w*abs(cr[i][z]-cs[i][z]) for z,w in enumerate(nu))/max(R[i],S[i])**n for i in range(3))
 pu=sum((mu[i]*(R[i]**(-n)-S[i]**(-n)) for i in range(3) if S[i]>R[i]),F(0))
 layers=[r**(-n)-(radii[k+1]**(-n) if k+1<len(radii) else 0) for k,r in enumerate(radii)]
 for H in (F(1,4),F(1),F(2)):
  br=sum(w*fr for w,(jr,fr,js,fs) in zip(layers,vals) if jr>=H)
  for c in (F(1,4),F(1,2),F(3,4)):
   bs=sum(w*fs for w,(jr,fr,js,fs) in zip(layers,vals) if js>=c*H)
   assert br<=bs+ec+N*pu;ct['relaxed_threshold']+=1
  if all(s<=r for r,s in zip(R,S)):
   bs=sum(w*fs for w,(jr,fr,js,fs) in zip(layers,vals) if js>=H)
   assert br<=bs+ec;ct['shrink_same_threshold']+=1
print('PASS',ct)
```

For n>1 the listed scalar coordinates embed diagonally as (x,...,x), so the same incidence rule is exactly that of n-dimensional centered cubes; physical layer weights use the displayed n. Only `/tmp/r315_joint.md` is written. Other authors' files and Git are unchanged.
