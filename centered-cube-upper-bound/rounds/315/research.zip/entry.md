# R315 — bounded independent entry/contact absorption audit

**Historical-slot accounting only — the 1/128 charge is NOT completed global absorption (fresh-route update immediately below):** R314’s contact receiver charge can be aggregated once over the identified OLD leaf/seed collection: its exact coefficient in the old `R_out` ledger is `2 Lambda epsilon`, `Lambda=128/119`. For example `epsilon=119/32768` charges exactly `X_old/128`. This is a usable receiver-charge accounting, **not** a completed global absorption: the old selected radius has no certified hard-winner identity, so the additional `2 Lambda D_eff,total` must remain. Its coarse bound contributes `1024/119 X_old`, which cannot be absorbed. The separate R312 native entry has genuine hard winners and an already audited whole-event absorption, but no verified bridge from its `R_corr`/`R_HP` to R302’s low-pe target/B_H was found.

Only `/tmp/r315_entry.md` was written. No Git, new local kernel proof, or counterexample campaign. This audit intentionally does not redo the entire R304 ledger.

## Priority update: a FRESH maximizing-selector construction is legitimate

The parent’s steering distinguishes a new construction from changing a frozen historical selector. I read `/tmp/r315_selector_provenance.md` and checked its central original clauses directly in `104::proof.md:97–112`, `107::proof.md:905–930`, and `112::proof.md:401–421`.

**Yes:** one may begin on the native hard band with a measurable `R*(x) in argmax_(a<=R<=b) h_R*f(x)`, and generate all R-dependent objects from that R*. It meets the uniform R104 selected-band hypotheses. None of the inspected uniform payment theorems prohibits this initial maximizer choice. Their use in a fresh construction does not require comparing old and new capture gates or proving frozen-selector invariance. If the original complete construction is rerun with this selector, `D_eff=0` by definition; the historical inability to identify the OLD R does not obstruct the NEW construction.

There is an important event convention: the complete hard band includes outputs deleted by the baseline/endpoints/low-source payments. The common interior soft FIRST is furnished on the retained event `E_ret subset E_band`. Do not claim that all of E_band has that retained FIRST. Build the old-style traffic only on E_ret and use the global budget `X_band=lambda|E_band|`; the contact calculation below then gives `2Lambda epsilon lambda|E_ret|<=2Lambda epsilon X_band`. Equivalently keep `X_ret` internally, then enlarge its positive receiver charges to X_band at the complete-event entry. This yields the desired SAME global budget without reassigning FIRST to already-paid outputs.

### Minimal fresh-rerun certification packet

1. **Choose fields before geometry/history.** Start with the complete f, native hard band, initial R*, original soft FIRST sigma,L_s and the fixed common-q high source. The native baseline, physical endpoint, angular and whole-soft low-source deletions must retain their original prices. This much is supplied by `312::native_entry.md:7–52` and its archived GENERAL source. Keep the same R* thereafter; all new gates may be regenerated from it.
2. **Supply the authentic entry to history/R_out. THIS is the earliest missing connector.** Construct the original FULL positive process/accepted histories, actual `S_core`, source-once/hard source restriction and `Gamma` using these initial native fields, and state the actual complete-band inequality reaching R_out with exact paid fees and receiver coefficient. R104’s hypotheses accept a given G<=1/source/selector; they do not prove that a newly invented G or Gamma covers the original weak event. Native R_HP is a different complete positive residual and does not itself provide this history-to-R_out construction. This packet must cite the genuine upstream FULL/CP/GP/history coverage theorem, rather than trying to prove coverage from a cap or a shared kernel name.
3. **R104–R115 uniform transport/deletion packet.** Given the authenticated joint input, the inspected R104 ownership/cap-first price (`104::proof.md:817–842`) is uniform in the original measurable selector; R105’s birth gate and near-birth payment require its original whole-cell/endpoint qualifications and must be regenerated/paid for R*. The R107 joint-tree input `Gamma<=q^-1 P mu_hi`, original caps and actual shared histories are explicit at `107::proof.md:905–938`; unique leaf/receiver/source support is at998–1016. R109/R112/R113 network refinements, coupled source residual and R114/R115 forbidden/root/parent cuts must be rebuilt on the resulting sources. Their applicable original hypotheses and all old prices remain; a finite audit must affirm them, especially the original birth/FULL gates, not infer them from arbitrary beta,nu<=f. Inspected equations do not require a nonmaximizing R, so the maximizing choice itself supplies no obstruction.
4. **R116–R123 exact low/high/history split.** Rebuild g,j,Z_t,e_t,Pi_t and all test gates from R*. R116’s low/high decomposition and R117’s original posterior are uniform algebraic statements once the regenerated hypotheses hold. The original time atom/continuous split and complete ledger at `123::proof.md:1098–1109` then retain lowpe/I/J/D/suffix and their exact coefficients. R223’s signed contract is compatible with those rebuilt original fields. No all-history closure is claimed by this compatibility check.
5. **Direct R302 use on the regenerated low-pe,m>M,v>=v0 target.** Apply the universal R302 theorem with actual beta_V,nu_V, actual R*, same retained receivers and their caps/height conditions. This can be done directly on that original slot; it does not require replaying every optional R126–R301 local route or charging their alternative prices. If using previously paid low-near/moderate-m allocations instead, retain their exact complementary masks and receipts. On this regenerated R302 object R314 has zero defect; the exact global receiver charge is at most `2Lambda epsilon X_band`. For example epsilon119/32768 gives X_band/128 once. This is a REAL calibrated charge for the proposed fresh construction, conditional only on completing packets2–4, not a claim that old gates were invariant.
6. **Finish entry/adoption arithmetic.** The coefficient multiplying R_out in packet2 must multiply this charge as well. A connector `X_band<=A_ent W+alpha_ent X_band+C_ent R_out*` would make it `C_ent/128`, so tune epsilon to `eta/(2Lambda C_ent)` after C_ent is actually verified. Account the complete old E_original plus exactly the selected later receipts. Initial/jump/deleted/suffix/aspect/far complements remain unless separately paid. Native R312 is an alternative path and is not added to this newly rebuilt old-style entry.

**Certification boundary:** the fresh maximizer choice, uniform compatibility of the inspected contracts, once-only leaf/seed aggregation, and epsilon calibration are certified here. The authentic native-band-to-FULL/R_out generation/coverage and the complete regenerated-hypothesis/adoption packet are not yet certified. It would be incorrect to repeat “winner identity missing” as a permanent obstacle to this authorized fresh route; the actual missing work is the bounded entry/rerun packet above. Conversely, starting R104 afresh with arbitrary G<=1 does not fill that packet.

## 1. Exact primary locators

Let `R=/Users/zhengzhihao/Math-Research-centered-cube-work/centered-cube-upper-bound/rounds`. Below `314::geometry.md:34` means the line of that member inside `R/314/research.zip`. Every locator below was read directly in the archive during this audit.

- **Old receiver/source support:** `107::proof.md:998–1016`; `112::proof.md:401–421`; `237::source_ledger.md:79–99`.
- **R302 target and factor:** `302::r302_geometry.md:5–22,42–69`.
- **R314 contact and its integrated FIRST proof:** `314::geometry.md:5–56,87–112`; top-source price at114–135.
- **R314 selector/source provenance:** `314::contact_provenance.md:25–33`.
- **Native full original event and actual absorption:** `312::native_entry.md:7–52,136–154`; its explicit separation from the old route is `312::combined.md:25–44`.

## 2. Two different original X’s must remain different

### Old auxiliary/history route

`112::proof.md:401–407` fixes complete f, common q, original finite receiver set E_0, original selectors s,L,R, and

`X_old=lambda|E_0|`, `P_(s(x),L(x))*f(x)=q`, `h_(R(x))*f(x)<=4lambda`.

After a full probability seed omega is fixed, each original positive receiver belongs to at most one terminal leaf, and its whole hard cube and original soft source lie in that leaf (`107::proof.md:1005–1016`, `112::proof.md:417–421`). Therefore choose and retain the actual sets

`E_(omega,V)={x in E_0: Q_(R(x))(x) lies in V and its original terminal row is eligible}`.

These are disjoint in x at fixed omega, since V are disjoint. Enlarging a specific target’s receiver set to E_(omega,V) while retaining its original caps is a legitimate positive upper estimate. The original seed is averaged as a probability, not summed over its possible values.

`237::source_ledger.md:81–99` gives

`E sum_V ||beta_V||<=W`, `E sum_V ||nu_V||<=W`,

and the common-tree recovery `Lambda=128/119` ONCE. No source W is copied per clock or ratio band. The original low-pe slot carries `Lambda T_low`; it does not carry the high continuous factor2 or a new `dt/t`.

### Native complete-event route

`312::native_entry.md:24–50` uses the WHOLE original hard band `2lambda<G0<=4lambda`, fixed original `mu_hi=f1_{f>q sqrt(n)}dy`, actual soft FIRST and full future cap, and the full-source HARD WINNER R_h. Here

`X_band=lambda|E_band|`,

`X_band<=A_paid+(64/63)R_HP`.

The high-potential residual R_HP is the original single-receiver mixed integral with full-H high-correlation, far-distance and high-potential masks, not B_H. The native degree partition gives, for m>=7,

`[1-(256/63)2^(-m)]X_band`

` <= A_paid+(64/63)e^(-m/6)A_n W_hi+(64/63)R_corr`.

The bracket is at least61/63; `X_band<=A_n W/2<infinity` justifies the actual absorption. At m=7 the already charged receiver coefficient is exactly2/63. References: `312::native_entry.md:136–154`.

`312::combined.md:27–34` explicitly refuses to identify X_old with X_band. This native route bypasses the old-entry ambiguity for ITS own residual; it does not settle the old residuals or automatically place B_H in the native inequality.

## 3. Actual old-slot reentry and outer coefficient

R302 applies to the actual raw `low-pe,m>M,v>=v0` branch, with `v=min(1,(L/R)^(n/2))`. Keep full original e_g,m and all source/history masks. Its inequality is

`T_target<=4sqrt(lambda d A_n)(W_beta+W_nu)+2B_H`,

`d=[2K/(ell_n M)]psi_inf/(q_-v0)`.

This is at fixed original outer data. To apply it to the OLD slot, instantiate beta=beta_V, nu=nu_V, the actual same selectors and q, receiver set E_(omega,V), and a z-independent original row mask alpha<=1 dominating the target mask. Choose alpha only from genuinely row-only qualifications; alpha may retain original low pe,m and aspect, but cannot absorb a z-dependent forbidden/source gate into a supposedly z-independent field. Then

`U_(omega,V,y)(x)=alpha(x,y)1_(E_(omega,V))(x)p_y(x)/q`,

`f_(omega,V)(x)=integral U_(omega,V,y)(x)beta_V(dy)<=1_(E_(omega,V))(x)`

by ORIGINAL FIRST. Thus the relevant receiver integral obeys the actual bound

`E sum_V integral f_(omega,V)(x)dx <= |E_0|`.

The unique original j(x) remains inside each target/row; there is no independent j sum and no newly introduced clock in this RAW low-pe application. This identifies a lawful OLD-slot instantiation of the universal R302 inequality. It does **not** certify any different outer xi/clock construction merely from the words “outer instance”: if such a construction is used instead, its entire weight and integrated mass/cap bridge must be supplied separately.

R314’s proof keeps the stronger actual contact bound

`B_contact <=4lambda kappa_h integral f_(omega,V)(x)dx +D_eff,(omega,V)`.

The same full J_y cancels, and `ell_n([R,b])=R^(-n)` eliminates the physical layer measure before FIRST (`314::geometry.md:89–106`). Therefore after R302’s factor2 and the OLD outer Lambda,

`2Lambda E sum_V B_contact`

` <=8Lambda kappa_h X_old +2Lambda D_eff,total`.

The top-source part separately costs `2Lambda[1+log(1+kappa_h)]W_nu` and is NOT another receiver charge. Here

`D_eff,total=E sum_V integral f_(omega,V)(x)`

`                   [G0(x)-h_(R(x))*f(x)]dx`.

For R314’s physical width `h=(a/2)[(1+epsilon/4)^(1/n)-1]`, `kappa_h=epsilon/4`, so the exact receiver coefficient is

`8Lambda kappa_h=2Lambda epsilon=(256/119)epsilon`.

For any desired old-ledger charge eta, take `epsilon=119 eta/256`. In particular eta=1/128 gives

`epsilon=119/32768`, `h=(a/2)[(1+119/131072)^(1/n)-1]`,

and the contribution is exactly `X_old/128`. Actual local Python/Fraction execution verified this arithmetic. It verifies constants, not the missing hard-winner equality or original-entry connector.

For fixed common d,A_n, all R302 source terms sum once to at most `4Lambda sqrt(lambda d A_n)(W_beta,total+W_nu,total)`. If these parameters vary with outer data, retain their weighted source sums until a uniform bound is proved. Source-linear fixed-instance prices are not automatically integrated prices.

## 4. Why this is still not an actual global absorption certificate

### A. Hard-winner defect in the OLD application

`314::contact_provenance.md:29–33` positively verifies source order `nu_V<=sigma_V<=alpha_V<=f` and the R244 same-E all-radius hard ceiling. It does NOT certify old selected `R(x)=R_h(x)` or `h_(R(x))*f(x)=G0(x)`. Soft FIRST equality is not hard maximality.

Consequently old-slot use of R314 must retain D_eff,total. The same disjoint receiver/seed accounting gives only

`D_eff,total<=4X_old`, hence `2Lambda D_eff,total<=8Lambda X_old=(1024/119)X_old`.

This is not a small error. Sending h or epsilon to zero does not reduce this bound. Approximate-winner contact can instead be paid under the ACTUAL new qualification `G0-h_R f<=4lambda zeta` at BOTH receiver endpoints (`314::geometry.md:108–112`); that gives coefficient `8Lambda(kappa_h+zeta)` in the old target ledger, but its complementary receiver pairs must remain explicitly. No such original full coverage has been certified.

### B. Original old-event entrance and adopted errors

The strongest old assembled inequality remains for R_out, with the original low-pe factor Lambda, not directly for X_old. Through the audited R304 ancestor it retains

`E_original=19/768+Lambda(epsilon_tree+delta_tail+k0 kappa_n+epsilon_LP)`

`             +epsilon_neartime+epsilon_FA+epsilon_IJ+epsilon_D+epsilon_G`.

The calibrated R314 contact adds exactly1/128 to this OLD receiver-charge sum if it is adopted once on the stated target. This does not prove the sum is a global alpha: the original coefficient multiplying R_out in a complete `X_old<=A_ent W+alpha_ent X_old+C_ent R_out` connector and the complete later adoption sum remain unverified. If such an entrance uses C_ent, the contact contribution to the final X_old coefficient would be `C_ent/128`, not automatically1/128.

### C. Native entry has contact, but no target-to-B_H connector

Native R_h is a true winner, so D_eff=0 for a B_H legitimately formed from those fields. However, no cited original theorem identifies native R_corr/R_HP with the R302 low-pe,m>M,v>=v0 target or bounds it by the R302 source terms+2B_H with all qualifications and constants. Native R_corr has a degree corridor/full-H/high-potential contract; R302’s actual height and aspect qualifications are different. Changing to the native winner or canonical soft selector can alter the accepted receiver/history/source gates. No free selector substitution is licensed.

This exact missing connector is stated in `314::combined.md:35–47`: native single-receiver R_HP and double-receiver B_H do not correspond by name. Therefore one cannot multiply R314’s epsilon by64/63 (or64/61) and announce a new native absorption without that target bridge. R312 already completed its OWN2/63-or-smaller degree-tail absorption; no R314 contact charge has yet been entered there.

## 5. What remains on the original ledger, unchanged by this audit

Retain the OLD wide-distance/large-m low-pe and its extreme-aspect complement; `2Lambda I_rem` initial low test; `2Lambda J_rem` genuine deletion-time atoms; `2Lambda D_rem` future-deleted-source CONTINUOUS positive traffic; and continuous suffix positive traffic, including its wide-distance part and every complement outside the exact priced near domains. Keep unused `-2Lambda N_Zc-2Lambda N_del` once; consumed N_Z never returns. The R302/R314 geometric fee is an auxiliary upper-bound fee, not one of these original atoms or a receipt paying all of them.

These slots and exact original measures are recorded at `123::proof.md:1098–1109`, `121::proof.md:1516–1532`, `120::proof.md:436–459`, and `223::negative_contract.md:60–75`; see `/tmp/r304_global_ledger.md` for the already restored definitions. The native R312 alternative is not added to that old full ledger.

**Usable next step (preferred fresh route):** choose the native hard maximizer R* at the outset, generate the authentic complete-band-to-FULL/R_out entry, and rebuild/verify the original qualifications and selected payment ledger using that same R*. The inspected uniform contracts allow this initial choice; the resulting matched R302/R314 construction has zero winner defect and the contact receiver charge is calibrated once, while the original-entry multiplier and full error sum still require verification before global absorption. Only if continuing the frozen historical interface must its unverified winner defect D_eff remain, or a separately priced approximate-contact/comparison branch be supplied. Such an auxiliary comparison is not the preferred route and must not obscure the fresh construction. Keep far geometry and all original low-pe, initial, jump, future-deleted, suffix and aspect complements explicit; do not replace the complete ledger by “only B_far remains.”
