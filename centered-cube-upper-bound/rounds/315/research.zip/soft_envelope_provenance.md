# R315 shared-softness envelope provenance

## Audited source chain

1. **Coefficient envelope and root-order constant (R293).** Frozen source: /Users/zhengzhihao/Math-Research-centered-cube-work/centered-cube-upper-bound/rounds/293/research.zip (SHA-256 1f250582da2cc900f3ae22cc5f56e6b843d99800e7a0618a13cd44a41149cf55), member proof.tex.txt. Lines 177–182 expand the actual common-soft product
   Π_i p_s(u_i)=Σ_k b_{n,k}(s)Q_k(u),
   where Q_k is a probability mixture of products with exactly k soft coordinates, and dominate the pointwise softness supremum by Σ_k a_{n,k}Q_k with a_{n,k}=max_s b_{n,k}(s). Thus ∫sup_s Π_i p_s ≤ Csoft_n, where Csoft_n:=Σ_k a_{n,k}. It is an upper-envelope mass; the source does not claim equality of the integral with that coefficient sum. Lines 184–193 prove
   Csoft_n=1+∫_0^1 Σ_k(b'_{n,k}(s))_+ ds
   and Σ_k(b'_k)_+=E|Bin(n,s)−ns|/[2s(1−s)]≤√n/[2√(s(1−s))], hence Csoft_n≤1+(π/2)√n. This proof is all n, preserves one common s across coordinates, and is not a product of independently optimized coordinate softnesses.
2. **Independent review of that constant.** Same ZIP, member audit.md, lines 31–35 gives an independent preauthor derivation of the homogeneous bound and the same binomial-variation estimate; lines 49–51 records final PASS for the author proof and explicitly matches Csoft≤1+(π/2)√n. It also says the conclusion is a fixed-band spatial-majorant result and does not remove source-transfer gaps.
3. **Actual physical-scale envelope (R302).** Frozen source: /Users/zhengzhihao/Math-Research-centered-cube-work/centered-cube-upper-bound/rounds/302/research.zip (SHA-256 92bef60e49994ab4c33869ad3e9cf55c3b445272583d09634abe1362c5099169), member r302_pair_kernel.md. Lines 41–50 define the actual h, φ, p_s=(1−s)h+sφ, Q_k and Q_n=Σ_k c_{n,k}Q_k, with each Q_k probability and mass(Q_n)=Csoft_n; equation (4) gives p_s^{⊗n}≤Q_n pointwise for every common s. Lines 52–66 prove the ray-decreasing physical dilation envelope
   sup_{a≤L≤b} L^(−n)Q_n(x/L) ≤ b^(−n)Q_n(x/b)+n∫_a^b L^(−n)Q_n(x/L)dL/L.
   With μ(dL)=δ_b+n1_(a,b)(L)dL/L, define K(x)=∫L^(−n)Q_n(x/L)μ(dL). Its mass is ∫K=A_n Csoft_n, A_n=1+n log(b/a), and p_{s,L}(x−y)≤K(x−y) at each actual selected common softness/scale. Therefore the complete common-soft, all-physical-scale pointwise supremum also has integral at most A_n Csoft_n. The endpoint atom at b is included.
4. **Independent R302 audit.** Same R302 ZIP, member r302_scale_audit.md lines 89–96, confirms the full-common-soft profile is built from the probability tensor shapes with total coefficient Csoft≤1+(π/2)√n and that the two physical-scale measures have total mass A_n. It verifies the positive envelope for receiver-selected scales. Lines 102–112 caution that the resulting integrable product kernel still has mass A_n² Csoft and does not by itself pay its integral against arbitrary source product measures.

## Scope and formula precision

The verified reusable price is the positive majorant mass A_n Csoft_n≤[1+n log(b/a)][1+(π/2)√n] for the one-ended full common-soft physical-scale envelope. In a two-selector convolution, both selector envelopes are used and the resulting L1 majorant is A_n² Csoft_n, as R302 audit line 112 records; the root-order point-amplitude estimate is separate and must not be substituted for that L1 mass.

The displayed Csoft_n is the coefficient-sum upper envelope for ∫sup_s. The exact assertion is ∫sup_s Π_i p_s(u_i)du≤Csoft_n, not equality to Csoft_n. No “1+√(2n)” alternative was needed: the frozen proof and independent review both establish 1+(π/2)√n.

