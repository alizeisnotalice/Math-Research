# R315 selector provenance: initial choice versus frozen selector

## Finding

The upstream supports two different statements, with different scopes.

1. The R104 geometric theorem is formulated for an input pair consisting of a measurable E and a measurable selector R(x)∈[a,2a] satisfying 2λ<A_{R(x)}f(x)≤4λ. Its displayed hypothesis does not require R to maximize over radii. It also does not say that an arbitrary previously fixed E and its downstream masks are invariant under changing R.
2. On the separate native hardband event E0={2λ<G0≤4λ}, G0=sup_{a≤r≤b}h_r*f, one may define a measurable hard maximizer R*(x)∈argmax h_r*f(x) at the outset. Then h_{R*}*f=G0∈(2λ,4λ] and R104’s selected-radius hypothesis is met for this newly specified pair (E0,R*), assuming the same octave. Every later R-dependent set/gate must be defined using R* from the start. This is a legitimate fresh construction on the native hardband, not proof that an already frozen R from R104/R107/R112/R302 equals R* or that its old E, U, qualifications, and target entry remain unchanged.
3. The R107→R112→R237→R302 lineage does not itself make that fresh choice. Its equations freeze the old R and never give a max identity. R237 does establish ν_V≤f; R244 gives all-radius hard upper caps on the same original E, so this matched source can use the cap at its frozen R. Neither fact supplies max equality. Thus D_eff=0 is not certified for that retained slot. A new route beginning at native E0 may have zero mismatch by construction, but it must rebuild and price the whole actual target with that chosen selector.

## Exact upstream clauses

- R104, rounds/104/research.zip::proof.md, §1, lines 97–105: “原可测赢家 R(x)∈[a,2a] 在 E 满足” followed by exactly 2λ<A_{R(x)}f(x)≤4λ and the definition of Q_x. This is a selected-radius band, not an equation with sup_r. The surrounding theorem takes E and R as data; no separate restriction says they must be the hard argmax. Nothing in these lines authorizes changing a selector after downstream objects have been frozen.
- R104, same member, lines 107–112: ν_ω≤f dz is frozen before receiver selection; the actual traffic then uses R(x). This fixes the receiver/source order but does not impose a max condition on R.
- R105, rounds/105/research.zip::proof.md, lines 40–44, explicitly carries forward the R104 selector and freezes residual ν before receiver selection. Lines 132–145 continue to use the original R and its birth gate. No re-maximization step appears.
- R107, rounds/107/research.zip::proof.md, §R107 lines 899–913: line 901’s prose says “整个硬赢家,” but the actual R1 equations at lines 905–913 say only a≤L_s,R≤b, P_{s,L_s}f=q, and h_R f≤4λ≤C_hq. There is no h_R f=G0 or R∈argmax equation. R107 line 913 then freezes hard source under this selected kernel.
- R112, rounds/112/research.zip::proof.md, J1 lines 401–407, says “沿用 R107 R1–R4” and repeats the same selected-radius upper cap. At lines 411–421 its actual traffic and J3 keep h_{R(x)}.
- R237, rounds/237/research.zip::source_ledger.md, SL1 lines 17–23 and SL3 lines 81–85, proves for its terminal leaves ν_V≤σ_V≤α_V=μ_hi,ω|_V≤f dz, with disjoint leaves. It changes source restrictions, not R(x).
- R244, rounds/244/research.zip::receiver_ledger.md, RL1 lines 9–29, traces GENERAL_CURRENT_REDUCTION’s complete-source event to G_s=sup_{a≤L≤b}P_{s,L}*f and 2λ<G0≤4λ, then uses P_{0,R}=h_R to obtain h_R*f≤4λ≤(16/3)q for every R∈[a,b] on the same E. Combined with R237’s ν_V≤f, this yields an all-radius cap for the matched restricted source. It remains an upper cap; it is not a maximizer identity.
- Native hardband GENERAL_CURRENT_REDUCTION.md §1 lines 5–13 defines G0 as the hard-family supremum and the hard band; §7 line 125 separately calls R_h the original hard winner. This is the right place to start a fresh maximum-selector construction. It does not rewrite historical R in the R104 chain.

## What may be claimed

For a fresh route, if the target receiver set is specifically the native hardband E0 and all downstream definitions are allowed to be generated after choosing R*(x) as a measurable argmax, then the selected-band R104 lemma is applicable at R*. Existing all-radius caps also hold. That is an initial selector choice, not an alteration of an existing frozen target.

For an already retained R104/R107/R112/R302 slot, the proved inheritance is only: keep its original R, retain its existing masks and FIRST, and use ν_V≤f plus the same-E all-radius hard cap when the source slot is exactly matched. The documents give no selector-invariance result for U_y, A_yz, J_y, low-pe/history/aspect gates, or the original entry under R→R*. They therefore do not justify asserting R=R_h or setting D_eff to zero in that slot.

No separate entry estimate for a newly rebuilt target is certified by this provenance note. The selector choice itself is available on the native band; payment/coverage of all rebuilt qualifications remains a distinct obligation.

