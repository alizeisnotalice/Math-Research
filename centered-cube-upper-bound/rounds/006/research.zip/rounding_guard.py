from fractions import Fraction as F
from itertools import product
from functools import lru_cache
import json
BITS=96;UNIT=2**BITS;TERMS=40
@lru_cache(None)
def logiv(x):
 if x==1:return F(0),F(0)
 if x<1:
  a,b=logiv(1/x);return -b,-a
 k=0
 while x>=2:x/=2;k+=1
 def series(v):
  z=(v-1)/(v+1);s=sum((2*z**(2*j+1)/(2*j+1) for j in range(TERMS)),F(0))
  return s,s+2*z**(2*TERMS+1)/((2*TERMS+1)*(1-z*z))
 a,b=series(x);c,d=series(F(2));a+=k*c;b+=k*d
 return F(a.numerator*UNIT//a.denominator,UNIT),F(-((-b.numerator*UNIT)//b.denominator),UNIT)
def lp(v,tau):return (F(0),F(0)) if v<=tau else tuple(tau*z for z in logiv(v/tau))
def jiv(p,v):
 a,b=logiv(1+p*v);c,d=logiv(1+v)
 return a-p*d,b-p*c
rows=[]
for n in [1,2,4]:
 a=F(1);b=F(2);d=F(1,4*n)
 pts=[(F(0),)*n,(d/2,)+(F(0),)*(n-1),(-F(3,4),)+(F(1,8),)*(n-1),(F(7,4),)+(F(0),)*(n-1)]
 grid=[F(-9,8),F(-3,4),F(0),F(3,4),F(9,8)]
 counts={'points':0,'tests':0,'exclusive':0,'inner':0,'outer':0,'negative_gap_certificates':0,'positive_gap_certificates':0,'outer_rejects_inner_only_cap':0}
 for weights in [[F(1),F(1),F(2),F(1)],[F(1),F(7),F(1,3),F(4)],[F(7),F(1),F(4),F(1,3)],[F(1),F(1),F(1,10000),F(1,10000)],[F(1),F(1),F(1000),F(1)]]:
  u,v=weights[:2];m=u+v;p=u/m;q=v/m
  receivers=list(product(grid,repeat=n))+[(base+d/4,)+(F(0),)*(n-1) for base in [F(-1),F(1),F(-1,2)]]
  for x in receivers:
   dist=[2*max(abs(xi-yi) for xi,yi in zip(x,y)) for y in pts]
   cand=sorted({a,b}|{r for r in dist if a<=r<=b})
   def maximum(w):
    vals=[sum((wi for wi,di in zip(w,dist) if di<=r),F(0))/r**n for r in cand]
    H=max(vals);return H,cand[vals.index(H)]
   H,r=maximum(weights)
   if not H:continue
   Hy,_=maximum([m,F(0)]+weights[2:]);Hz,_=maximum([F(0),m]+weights[2:])
   iy=dist[0]<=r;iz=dist[1]<=r
   counts['points']+=1
   for frac in [F(1,8),F(1,2),F(7,8)]:
    tau=H*frac
    l0,h0=lp(H,tau);ly,hy=lp(Hy,tau);lz,hz=lp(Hz,tau)
    glo=l0-p*hy-q*hz;ghi=h0-p*ly-q*lz
    counts['tests']+=1
    counts['negative_gap_certificates']+=ghi<0;counts['positive_gap_certificates']+=glo>0
    if iy==iz:
     # If original winner sees both/neither, both outcomes preserve that response exactly.
     assert Hy>=H and Hz>=H
     continue
    counts['exclusive']+=1
    pp=p if iy else q;qq=1-pp;A=m/r**n
    B=H-pp*A;assert B>=0
    caplo,caphi=jiv(pp,A/tau)
    assert ghi<=tau*caphi
    if r+d<=b:
     counts['inner']+=1
     delta=(1+d/a)**n-1;gamma=qq/delta-pp
     assert qq*A<=delta*H
     if gamma>0:
      assert B>=gamma*A
      cl,ch=jiv(pp,min(A/tau,1/gamma))
      assert ghi<=tau*ch
    else:
     counts['outer']+=1
     delta=(1+d/a)**n-1;gamma=qq/delta-pp
     if gamma>0:
      _,incorrect_hi=jiv(pp,min(A/tau,1/gamma))
      counts['outer_rejects_inner_only_cap']+=glo>tau*incorrect_hi
     assert ghi<=p*q*A
     # Receiver lies in the explicit boundary shell.
     captured=0 if iy else 1;excluded=1-captured
     assert dist[captured]<=b and dist[excluded]>b-d
 # Boundary exponential estimate and small-cell regime used in the theorem.
 assert (b/(b-d))**n-1<=2*n*d/b
 rows.append({'n':n,'distance_twice_linf':str(d),'counts':counts})
quad=[]
for steps in [16,64,256]:
 checks=0
 for p in [F(1,8),F(1,2),F(7,8)]:
  q=1-p
  for gamma in [F(0),F(1,8),F(1),F(8)]:
   end=1/(gamma+p);h=end/steps
   low=h*sum((p*q/(1+q*h*j) for j in range(1,steps+1)),F(0))
   high=h*sum((p*q/(1+q*h*j) for j in range(steps)),F(0))
   l,u=logiv((gamma+1)/(gamma+p));l*=p;u*=p
   assert low<=l<=u<=high;checks+=1
 quad.append({'steps':steps,'certified_integral_checks':checks})
tree_rows=[]
for n,N in [(1,7),(2,13),(4,31)]:
 h=F(1,8*n*n)
 pts=[tuple(h*F((j*(2*k+1))%(N+1)+1,N+2) for k in range(n)) for j in range(N)]
 assert len(set(pts))==N
 weights=[F((j*j+1)%7+1,7) for j in range(N)];W=sum(weights,F(0))
 counters={'merges':0,'maximum_depth':0};sum_md=F(0)
 def tree(ids,low,width,depth):
  global sum_md
  counters['maximum_depth']=max(counters['maximum_depth'],depth)
  mass=sum((weights[j] for j in ids),F(0))
  if len(ids)==1:return {ids[0]:F(1)}
  axis=depth%n;mid=low[axis]+width[axis]/2
  left=[j for j in ids if pts[j][axis]<mid];right=[j for j in ids if pts[j][axis]>=mid]
  nw=list(width);nw[axis]/=2
  parts=[]
  for subset,side in [(left,0),(right,1)]:
   if not subset:continue
   nl=list(low)
   if side:nl[axis]=mid
   law=tree(subset,nl,nw,depth+1)
   childmass=sum((weights[j] for j in subset),F(0))
   parts.append((law,childmass))
  if len(parts)==2:
   counters['merges']+=1;sum_md+=mass*2*max(width)
  result={}
  for law,cm in parts:
   for j,prob in law.items():result[j]=prob*cm/mass
  return result
 law=tree(list(range(N)),[F(0)]*n,[h]*n,0)
 assert law=={j:weights[j]/W for j in range(N)}
 assert counters['merges']==N-1
 assert sum_md<=4*n*h*W
 tree_rows.append({'n':n,'N':N,'h':str(h),'total_mass':str(W),'sum_mass_times_diameter_bound':str(sum_md),'uniform_bound':str(4*n*h*W),'expected_representative_law_exact':True,**counters})
print(json.dumps({'status':'PASS','scope':'True finite-atom continuous-window point tests with exact winner reselection; no spatial integration certificate. Separate rational Darboux checks of scalar radial integral.','rounds':rows,'radial_integral_rounds':quad,'coarsening_tree_rounds':tree_rows,'bits':BITS,'atanh_terms':TERMS},indent=2))
