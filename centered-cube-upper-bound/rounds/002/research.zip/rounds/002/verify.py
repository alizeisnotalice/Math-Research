"""Read-only validation of round 002; no original experiment is rerun."""
import argparse, gzip, hashlib, json, re, subprocess
from collections import Counter
from fractions import Fraction as F
from pathlib import Path

P = Path(__file__).resolve().parents[2]
ROOT = P.parent
parser = argparse.ArgumentParser()
parser.add_argument('--revision', help='Read the committed snapshot rather than current files')
args = parser.parse_args()
def read(name):
    if args.revision:
        return subprocess.check_output(['git', 'show', f'{args.revision}:{P.name}/{name}'], cwd=ROOT)
    return (P / name).read_bytes()
def obj(name): return json.loads(read(name))
inventory = obj('rounds/002/inventory.json')
for entry in inventory['files']:
    data = read(entry['path'])
    assert len(data) == entry['bytes']
    assert hashlib.sha256(data).hexdigest() == entry['sha256'], entry['path']
for prefix in ['sharp_packet_residual_guard_20261007', 'sharp_packet_residual_guard_20261007_supplement', 'packet_graph_merge_guard_20261007']:
    result = obj(prefix + '_results.json')
    assert result['status'] == 'PASS'
    assert hashlib.sha256(read(prefix + '.py')).hexdigest() == result['script_sha256']
    assert hashlib.sha256(read(prefix + '_registration.json')).hexdigest() == result['registration_sha256']
result = obj('grouped_packet_deletion_guard_20261007_results.json')
comparisons = losses = 0
for summary in result['summaries']:
    for row in summary['family_results']:
        assert F(row['scalar_minus_actual_excess']['interval'][0]) > 0
        assert F(row['actual_excess_sum_D_minus_I']['interval'][1]) < 0
        comparisons += 1
for n in [1, 2, 3]:
    data = json.loads(gzip.decompress(read(f'grouped_packet_deletion_guard_20261007_n{n}_cells.json.gz')))
    assert data['coverage']['whole_cartesian_support_certified']
    assert F(data['coverage']['exact_volume_sum']) == 6 ** n
    for row in data['packet_results']:
        assert F(row['actual_deletion_loss']['interval'][0]) >= 0
        losses += 1
receipt = obj('packet_graph_merge_guard_20261007_receipt.json')
pairs = negative = positive = 0
for entry in receipt['new_artifacts']:
    data = read(Path(entry['path']).name)
    assert hashlib.sha256(data).hexdigest() == entry['sha256']
    raw = gzip.decompress(data)
    assert hashlib.sha256(raw).hexdigest() == entry['uncompressed_sha256']
    for row in json.loads(raw)['merges']:
        delta = F(row['J_new']) - F(row['J_old'])
        assert delta == F(row['difference_formula']) == F(row['J_new_minus_J_old'])
        assert (delta <= 0) == row['nonincrease']
        pairs += 1
        negative += delta < 0
        positive += delta > 0
tex = read('阶段研究与数值检验笔记.tex.txt').decode()
assert tex.count(r'\begin{document}') == tex.count(r'\end{document}') == 1
labels = re.findall(r'\\label\{([^}]+)\}', tex)
assert len(labels) == len(set(labels))
for name in ['multi_packet_terminal_geometry_section_20261007.tex.txt', 'grouped_source_clock_section_20261007.tex.txt', 'grouped_source_clock_zero_time_erratum_20261007.tex.txt', 'packet_sharp_group_numerical_section_20261007.tex.txt']:
    text = read(name).decode()
    assert Counter(re.findall(r'\\begin\{([^}]+)\}', text)) == Counter(re.findall(r'\\end\{([^}]+)\}', text))
assert (comparisons, losses, pairs, negative, positive) == (9, 23, 123, 20, 103)
print(json.dumps({'status': 'PASS', 'round': 2, 'inventory_hashes': len(inventory['files']), 'strict_group_comparisons': comparisons, 'nonnegative_deletions': losses, 'exact_graph_pairs': pairs, 'decreasing_merges': negative, 'increasing_merges': positive, 'tex_one_document_no_duplicate_labels': True, 'compiled': False, 'original_experiments_rerun': False}, ensure_ascii=False, indent=2))
