# 完整 packet 删除的实际有限尺度空间费用：三轮精确审计

本批全部完成，固定一次执行正常 exit 0，耗时约 0.470 秒。9 个分组的实际费用上帽均由严格有理对数区间认证；23 个唯一 packet 删除损失均非负，其中 3 个精确为零。9 个真实 excess 全部严格为负，保存原值。当前输入没有产生正 excess 压力，不能据此判断维数阶或一般控制策略的费用。

## 1. 冻结合同与完整积分

使用旧 `log_max_variation_probe_20261007_n{1,2,3}_cell_profiles.json.gz` 中的完整来源、共同有限尺度 J、共同阈值 τ 与全部 cell arrangement。没有运行旧 oracle、旧主程序或旧 Monte Carlo。原 μ 总质量 W=1；删除 packet 后保留全部其余来源，包括原赢家未捕获的标签，不重新归一化。

记 h_R(x−y)=R^(−n)1{2||x−y||∞≤R}，M=M_J μ，原 E={M>τ}，R 为原完整 μ 的实际有限 J 赢家。同值时选择最小 R。对于完整来源的一种分割 {μ_B}，定义

\[
 \Phi(\mu)=\tau\int\log_+(M_J\mu/\tau)\,dx,\quad
 I=\tau|E|,\quad D_B=\Phi(\mu)-\Phi(\mu-\mu_B),
\]
\[
 \mathcal E(\mathcal B)=\sum_B D_B-I,\qquad
 \pi_B(x)=\frac{A_R\mu_B(x)}{M(x)},\quad
 z(x)=\log(M(x)/\tau),\quad
 C(\mathcal B)=\tau\int_E(1+4z)\sum_B\pi_B^2\,dx.
\]

本批核验实际重新最大化的删除损失，以及 **Ecal≤C**。原 posterior 始终使用完整 μ 的分母与原赢家，不使用删除后分母。每个 packet 删除后的所有 J 响应、真正新赢家、同值数、阈值状态均保存。

每个坐标按所有 atom±R/2 面切开，全部 Cartesian open cells 在每个 J 下响应恒定。旧保存的完整 capture 数组和质量由 Fraction 复核；每个删除只从每个 J 的完整质量中减掉该 packet 的捕获质量。删除不新增坐标面。核验全部相邻区间 Cartesian 组合唯一、数量正确、volume 与 midpoint 正确，整支持矩形为 [-1,5]^n，volume=6^n；矩形外原源与全部删除源响应均为零。面边界为 Lebesgue 零集。因此这是该有限 J 模型的完整 Lebesgue 积分，不是 receiver 点样本覆盖率。

## 2. 固定三轮来源与分割

| n | 来源 / 正质量 | J | τ | 完整 cells | 原 E cells | M=τ plateau | 原 M>0 赢家同值 cells | I |
|---|---|---|---|---:|---:|---:|---:|---|
| 1 | 0 标签两份各 1/8；1 质量 1/4；4 质量 1/2 | 1,2 | 1/4 | 10 | 1 | 6 | 2 | 1/4 |
| 2 | 原点两标签各 1/16；其余三个 {0,1}² 顶点各 1/8；(4,4) 质量 1/2 | 1,3/2,2 | 1/8 | 256 | 13 | 48 | 12 | 5/16 |
| 3 | 原点两标签各 1/32；其余七个 {0,1}³ 顶点各 1/16；(4,4,4) 质量 1/2 | 1,5/4,3/2,2 | 1/16 | 10648 | 789 | 378 | 32 | 467/1024 |

每一轮都预固定三种同源完整分割：每个独立物理位置；第一坐标 <2 与 ≥2；全部来源作为一个 packet。同位标签必须同组。跨分割出现同一 packet 时只缓存其删除响应，仍按每种分割分别记账。唯一 packet 数为 5/7/11，物理 atom 组数为 3/5/9；没有按 receiver 调整分组。

严格 E 使用 M>τ，plateau 不入 E；每个 Φ 的 log_+ 在 M≤τ 时精确为零。没有调阈值、调分组或补输入以得到有利结果。

## 3. 实际结果与赢家切换

下表只作可读十进制展示；认证使用 JSON 保存的 Fraction 两端及 signed-log 系数，不把表格舍入值当区间端点。

| n | 分割 | ΣD_B | 真实 Ecal=ΣD_B−I | scalar C | C−Ecal |
|---:|---|---:|---:|---:|---:|
| 1 | physical_atoms | 0.173286795140 | -0.076713204860 | 0.943147180560 | 1.019860385420 |
| 1 | first_coordinate_left_right | 0.173286795140 | -0.076713204860 | 0.943147180560 | 1.019860385420 |
| 1 | all_source | 0.173286795140 | -0.076713204860 | 0.943147180560 | 1.019860385420 |
| 2 | physical_atoms | 0.299147701838 | -0.013352298162 | 1.359792400653 | 1.373144698815 |
| 2 | first_coordinate_left_right | 0.281167572309 | -0.031332427691 | 1.437170289238 | 1.468502716928 |
| 2 | all_source | 0.281167572309 | -0.031332427691 | 1.437170289238 | 1.468502716928 |
| 3 | physical_atoms | 0.377239856876 | -0.078814830624 | 1.507347076207 | 1.586161906831 |
| 3 | first_coordinate_left_right | 0.328482771515 | -0.127571915985 | 1.769985773559 | 1.897557689544 |
| 3 | all_source | 0.328482771515 | -0.127571915985 | 1.769985773559 | 1.897557689544 |

9 个 C−Ecal 区间下端严格为正，最小下端约 1.019860385420；全部 9 个 Ecal 区间上端严格为负。没有 unresolved。n=1 的三个零损失 packet 精确对应两个近端物理位置及它们的合并 packet；当轮 E 只有远端贡献，因此不能把该轮作为丰富 overlap 压力。

第一坐标左右分割与 all-source 的 ΣD_B 都等于原 Φ，是当前远隔两个支持块输入的结果：两块在 J≤2 下不共同进入一个 query。此相等不是一般 packet 恒等式。all-source 删除的 M 为零，约定选择 J 最小尺度并记录全尺度同值；它的选择器变化不能当作正响应赢家切换。

在原 E 上，n=1/2 两轮删除后仍有正响应的赢家切换为零。n=3 的 8 个近端物理 packet 各有 81 个正响应赢家切换 cell，共 648 个 **packet×cell** 对；远端、近端合并及 all-source packet 的变化来自归零分支。所有完整 cell 的删除后质量/响应/新赢家均在 profiles 中，没有用冻结原赢家代替删除后的最大化。

对 5/7/11 个唯一 packet 汇总，原 E 上 π=0 的 packet×cell 对为 3/49/4621，π=1 为 2/26/1578；这是配对计数，不是积分值或互不相交空间计数。π=0/1 的全部逐 packet 记录、归零计数及完整来源分配保留。

## 4. 区间、复现与资格范围

只读抽取已审 `spatial_packet_collision_probe_20261007.py` 的四个 log helper AST 函数，没有执行该旧程序。采用 range reduction、100 项 atanh 正项级数加显式尾上界、192 bit dyadic 有向 outward 端点。先把每个积分合成 signed rational log-coefficient map；同参数系数合并，负系数交换上下端，精确取消识别为零。C−Ecal 也使用自己的合并表达式，而非把两个宽区间相减。质量、体积、posterior、所有候选响应与赢家比较全部 Fraction 精确运算。

注册 hash 为 `197244d7c83550bdcb9b9f9de9bbf736edd45a1157f5cc4b15a30c0dff59bd72`，脚本 hash 为 `20a0f0255d09e788368379cc2148cdf7b2e9b29c2d2a3a6a9cb31fdb6ad68bb4`。结果 hash 为 `c503888eb2d2928fcdb46ccf6726f41c11c62d35d14124ac6bd71821f6b1e00b`。三轮共有 10914 cells、932 原 capture patterns、23 唯一 packet 积分、9942 个新 packet×pattern counterfactual、39230 个新尺度响应。正常终态，无活动 session；未执行额外 batch。

注册时记录 grouped_source_clock 稿的当时 hash `101601328a7b6e72f05b7198eadd3ccdab02efa38725a6a35d16b1380fceb1aa`。终稿阶段只读其更新版（hash `904c87b9a2ef428f72228369a9dc39a91f02a1fbd69ddf2643fe14e7139c5c6b`），不改变本批冻结定义。该稿的 R_a 是带符号余项，不能把 source-clock 积分恒等式误写为另一个全状态 Φ 生成元费用。更新稿的 own-response 锐化帽及 accepted-history 控制未加入本批；属于另一个接口。

本批验证实际有限共同 J 的空间费用组件。它没有认证 continuous [1,2] winner，没有构造未知 nearmax 输入，没有测 all-history/adaptive packet 政策，没有给任意 packet 的小格 16W/22W 费用，也没有证明 √n 预算。负 Ecal 仅说明当前冻结来源的实际删除总损失低于 I；不能推出一般余项必为负。

脚本入口为 `grouped_packet_deletion_guard_20261007.py register`，随后 `grouped_packet_deletion_guard_20261007.py run`，Python 为 `/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3`。原登记/执行文件实行独占创建，原路径不覆盖。需要重现时，应将此脚本、三个旧 cell profile、旧 log_max_variation receipt 以及所用 spatial_packet_collision log helper 脚本复制到新的隔离目录后运行两个入口；数值表达式应相同，目录路径、时间、运行耗时及含路径的 profile hash 不要求相同。本交付没有启动重现。完整路径、所有 input/source/profile hashes 和终态 scope 位于 final receipt。
