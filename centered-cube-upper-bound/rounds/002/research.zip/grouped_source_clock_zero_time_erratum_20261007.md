# 整组时钟的零时刻合并约定

本补充仅澄清 grouped_source_clock_20261007.md §3、§7 式 (11) 与 grouped_source_clock_section_20261007.tex.txt 相应控制段、(GC9) 的初值／求和约定。原 MD 已由 grouped_packet_deletion_guard_20261007_registration.json 的 grouped_clock_notes_present 及其 final_receipt.json 记录 SHA-256，因此保留两份原稿，以独立勘误插入。

**初始分组定义为时刻 \(0\) 预处理合并完成后的分组。** 相应 \(q_0\) 与 \(K_{\rm in}(0)\) 均取此后值；所有过程合并求和只计严格正时刻 \(0<s\le T\) 的合并。因此式 (11)／(GC9) 应读为
\[
\begin{aligned}
 \mathbb E_Q H_{\rm fine}(T)
 &=H_{\rm fine}(0)-\mathbb E_Q\int_0^T\mathcal D_s\,ds,\\
 \mathbb E_Q H(q_T)
 &=H(q_0)-\mathbb E_Q\int_0^T\mathcal D_s\,ds
       -\mathbb E_Q\sum_{\substack{s\text{ 为合并时刻}\\0<s\le T}}\delta_s,\\
 \mathbb E_Q K_{\rm in}(T)
 &=K_{\rm in}(0)
       +\mathbb E_Q\sum_{\substack{s\text{ 为合并时刻}\\0<s\le T}}\delta_s.
\end{aligned}
\]

若允许零时刻预处理，完整来源与原细标签熵不变；其粗熵向块内残余熵的转移已包含在 \(q_0,K_{\rm in}(0)\) 中，不再加入上述合并和。该约定也适用于其后使用合并总量的推论。其余证明、费用与数值结论不变；本补充无需重跑数值。
