# Packet graph merge criterion：三轮精确后处理终态

2026-10-07。独占新增本 prefix；已读 multi_packet_terminal_geometry_20261007.md §6–7，并复用其来源一次图预算与有效 own-fee 证书。注册和 code 先冻结，再运行新脚本一次，exit0；未运行旧 graph 程序或任何 maximal query，未改他人文件、原 profiles 或主账。

## 1. 完整来源与原图

按原 local_clock_graph_guard_20261007 frozen manifest 顺序读取9组完整来源/profile：

- 原round1：N3、n1、clique/path/cluster；
- 原round2：N5、n16、clique/path/cluster；
- 原round3：N8、n256、clique/path/cluster。

保留原全部 atom 坐标、原标签、原权重、总质量1和保存的 neighbor_masks/边表。原图是已保存的 conservative co-capture covering graph；本批不重算 exact actual graph，不删除原额外边。合并 A/B 为完整来源 μ_C=μ_A+μ_B，只合并质量，不按 receiver 截断、不归一化其他来源。每个 pair 都从同一个原完整图出发，不运行多步 greedy。

所有 unordered pairs 全部枚举：每种图分别3、10、28个，合计123。负/正/零增量均保存，不按结果筛选。

## 2. 确实有效的 κ，不把自由参数当费用

原 singleton 为真实 atom packet，其 own-logmax cap κ=1 有效。可直接作为以下闭盒证书的 ell0情形，也有原 atom 精确 profile 的证据；本批未新查 maximal profile。

对合并两个原 atom，ell=max_i |z_Ai−z_Bi|，取完整闭盒 [coordinate min,coordinate max]，每坐标长度≤ell。选该盒最低角点 c，则每个被原 Q(x,R) 捕获的来源点到 c 的 infinity 距离≤ell，因此

2||x−c||∞≤R+2ell≤R(1+2ell/a)。

由此在原 R∈[a,b] 上，完整 packet 响应有正 envelope

M_C(x)≤w_C(1+2ell/a)^n / max(a,2||x−c||∞)^n。

对全 receiver Lebesgue 空间积分这个 envelope 的 log-positive，径向体积变量 s=(2||x−c||∞)^n 的 core 与外围项相消，准确为
[κ_geo w_C−λa^n]_+≤κ_geo w_C，
其中 κ_geo=(1+2ell/a)^n。因此 κ_geo 是全部阈值 own-logmax cap，不需要把原窗口扩大；全空间只是 envelope 积分区域。

另原 b=2a，普适 cap K_C≤Z/e≤1+n，其中 Z=1+n ln2，使用 ln2≤1、e≥1 即可。故

κ_C=min(1+n,(1+2ell/a)^n)

是两个已证明有效证书的最小值，不是拟合参数。全闭盒和原两个 atom 的支撑包含关系逐坐标精确检查，保存 ell、角点、两个 cap 及选用 cap；没有声称 κ_C 是精确 own-fee。

## 3. 独立 quotient 与完整目标恒等式

新图将原每条边的端点 A/B 同时映到 C，去自环及重边，独立计算全部新邻居和度数。令 e=1_{A~B}、common=N(A)∩N(B)，则逐pair核验：

d_C=d_A+d_B−2e−|common|；
每个剩余 common 节点度数−1，其他剩余节点度数不变。

共同邻居原 d_D≥2，恒等 H_(d_D−1)−H_d_D=−1/d_D 用 Fraction 精确核验，无零分母。

使用完整目标
J=sum_B w_B κ_B(1+H_dB)，H_d=sum_{j=1}^d1/j。

直接从整个 quotient 图重新求 J_new，与原 J_old 相减；另独立评价

(w_A+w_B)κ_C(1+H_dC)
−w_Aκ_A(1+H_dA)
−w_Bκ_B(1+H_dB)
−sum_common w_Dκ_D/d_D，

123次全部精确相等。并核验该差≤0与正文合并判据左右不等式完全等价。结果可支付的只是一个已证完整预算的下降，未据它宣称一般输入总能降到平方根，也未认证全局 greedy optimality。

## 4. 全部三轮结果

|原case|pair数|检查数|负增量|零|正增量|closed-box cap|global cap|
|---|---:|---:|---:|---:|---:|---:|---:|
|r1 clique|3|44|2|0|1|3|0|
|r1 path|3|40|0|0|3|0|3|
|r1 cluster|3|44|2|0|1|3|0|
|r2 clique|10|195|2|0|8|10|0|
|r2 path|10|141|0|0|10|0|10|
|r2 cluster|10|141|3|0|7|4|6|
|r3 clique|28|789|6|0|22|28|0|
|r3 path|28|465|0|0|28|0|28|
|r3 cluster|28|465|5|0|23|7|21|

总20个严格下降、0个相等、103个上升；原冻结round1 cluster与clique实例相同，也原样保留，未按重复内容删除预注册实例。每个pair的正负值、全部 source mass、图、degree、common correction、κ及J值都存在9个新确定性gzip artifact中，完整 artifact hashes见 receipt。

**2338 PASS**：9case共2324项，冻结 code/proof/原manifest/results/9profiles共13项，最终注册数量1项。elapsed0.081411791004939秒。一次成功、失败0，旧graph程序0、新 maximal query0，不追加多步或其他压力计划。

## 5. 文件收据与边界

- code SHA256：
  78eaff91477d6a5cfe7e4e3690ce4e3d70d0205021467f249d8c0ca49585a1b5
- registration：
  5599a485a1418556d669f44d4ab46ca91fdd1be2ac55e6138f527dae3df514d2
- results：
  ff0e2233b40f0be5fba96915d89aa876824417a8bc4bd95913ab7d9b51dc1ba1
- receipt：
  59856ed5bae1d68318b3b287689d8e31bc92698ccb649c68b370c77c818c0c9d

这仅是预先固定完整来源的单步图合并恒等式与有效几何cap的有限守卫。图停止政策的合法 law 和图预算由原解析证明承担，本批没有重新模拟实际时钟、FIRST/history，也不认证 nearmax、一般 sqrt(n) 分组存在性或实际 geom 余项闭合。

