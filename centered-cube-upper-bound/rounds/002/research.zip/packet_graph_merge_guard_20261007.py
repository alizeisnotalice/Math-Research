#!/usr/bin/env python3
"""New exact quotient-graph postprocessing, no old graph program or max call."""
from fractions import Fraction as F
import pathlib,json,gzip,hashlib,itertools,time
P=pathlib.Path(__file__).resolve().parent;PRE="packet_graph_merge_guard_20261007"
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p,x):p.write_text(json.dumps(x,ensure_ascii=False,sort_keys=True,indent=2)+"\n")
def harmonic(d):return sum((F(1,j) for j in range(1,d+1)),F(0))
def cost(weights,kappa,adj):return sum((weights[i]*kappa[i]*(1+harmonic(len(adj[i]))) for i in adj),F(0))
checks=0
def ck(x,label):
    global checks
    checks+=1
    if not x:raise AssertionError(label)
def main():
    start=time.monotonic();regp=P/(PRE+"_registration.json");reg=json.loads(regp.read_text())
    for e in reg["frozen_inputs"]:ck(sha(pathlib.Path(e["path"]))==e["sha256"],"frozen input")
    oldreg=json.loads((P/reg["original_registration"]).read_text())
    artifacts=[];summaries=[];paircount=0
    for entry in reg["cases"]:
        before=checks;f=P/entry["profile"];old=json.loads(gzip.decompress(f.read_bytes()))
        case=old["case"];n=case["n"];N=case["N"];a=F(case["a"]);b=F(case["b"])
        ck(case==oldreg["cases"][entry["manifest_index"]],"frozen complete case")
        source=case["source"];atoms=[list(map(F,x)) for x in source["atoms"]]
        weights={i:F(x) for i,x in enumerate(source["weights"])};kap={i:F(1) for i in weights}
        ck(len(atoms)==N and sum(weights.values(),F(0))==F(source["W"])==1,"full source mass")
        ck(b==2*a and a>0,"global own fee constant range")
        adj={i:{j for j in range(N) if old["neighbor_masks"][i]>>j&1} for i in range(N)}
        ck(all(i not in adj[i] and all(i in adj[j] for j in adj[i]) for i in adj),"old simple undirected graph")
        old_edges={tuple(sorted((i,j))) for i in adj for j in adj[i] if i<j}
        ck(old_edges=={(d["i"],d["j"]) for d in old["pair_distance_graph"] if d["edge"]},"use original saved graph")
        Jold=cost(weights,kap,adj);rows=[]
        for A,B in itertools.combinations(range(N),2):
            common=adj[A]&adj[B];e=int(B in adj[A]);dA=len(adj[A]);dB=len(adj[B])
            dC_formula=dA+dB-2*e-len(common)
            C=N;remaining=[i for i in range(N) if i not in (A,B)];labels=remaining+[C]
            def contracted(i):return C if i in (A,B) else i
            quotient_edges=set()
            for i,j in old_edges:
                u,v=contracted(i),contracted(j)
                if u!=v:quotient_edges.add(tuple(sorted((u,v))))
            newadj={i:set() for i in labels}
            for i,j in quotient_edges:newadj[i].add(j);newadj[j].add(i)
            ck(newadj[C]==(adj[A]|adj[B])-{A,B},"quotient neighbors")
            ck(len(newadj[C])==dC_formula,"merged degree formula")
            ck(all(i not in newadj[i] and all(i in newadj[j] for j in newadj[i]) for i in labels),"quotient simple symmetric")
            other=[]
            for i in remaining:
                expected=len(adj[i])-int(i in common)
                ck(len(newadj[i])==expected,"remaining degree update")
                other.append({"label":i,"old_degree":len(adj[i]),"new_degree":len(newadj[i]),"common":i in common})
            ell=max(abs(x-y) for x,y in zip(atoms[A],atoms[B]))
            lows=[min(x,y) for x,y in zip(atoms[A],atoms[B])]
            highs=[max(x,y) for x,y in zip(atoms[A],atoms[B])]
            ck(all(F(0)<=h-l<=ell for l,h in zip(lows,highs)),"pair complete closed box support")
            ck(all(l<=x<=h and l<=y<=h for l,h,x,y in zip(lows,highs,atoms[A],atoms[B])),"both original atoms in merged box")
            globalcap=F(1+n);geocap=(1+2*ell/a)**n;kC=min(globalcap,geocap)
            ck(1<=kC<=globalcap and kC<=geocap,"valid cap minimum")
            newweights={i:weights[i] for i in remaining};newweights[C]=weights[A]+weights[B]
            newkap={i:kap[i] for i in remaining};newkap[C]=kC
            ck(sum(newweights.values(),F(0))==sum(weights.values(),F(0)),"no mass loss or renormalization")
            ck(all(newweights[i]==weights[i] and newkap[i]==kap[i] for i in remaining),"unmerged complete sources unchanged")
            terms=[];correction=F(0)
            for i in sorted(common):
                d=len(adj[i]);ck(d>=2,"common denominator positive")
                ck(harmonic(d-1)-harmonic(d)==-F(1,d),"common harmonic correction")
                t=weights[i]*kap[i]/d;correction+=t
                terms.append({"label":i,"mass":str(weights[i]),"kappa":str(kap[i]),"old_degree":d,"subtracted_term":str(t)})
            formula=(weights[A]+weights[B])*kC*(1+harmonic(dC_formula))-weights[A]*kap[A]*(1+harmonic(dA))-weights[B]*kap[B]*(1+harmonic(dB))-correction
            Jnew=cost(newweights,newkap,newadj);difference=Jnew-Jold
            ck(difference==formula,"full J difference exact")
            left=(weights[A]+weights[B])*kC*(1+harmonic(dC_formula))
            right=weights[A]*kap[A]*(1+harmonic(dA))+weights[B]*kap[B]*(1+harmonic(dB))+correction
            ck((difference<=0)==(left<=right),"merge criterion equivalence")
            sign="negative" if difference<0 else "positive" if difference>0 else "zero"
            rows.append({"A":A,"B":B,"C":C,"edge_AB":e,"dA":dA,"dB":dB,"common":sorted(common),
                         "dC_formula":dC_formula,"dC_direct":len(newadj[C]),"other_degrees":other,
                         "ell":str(ell),"closed_box_lower":[str(x) for x in lows],"closed_box_upper":[str(x) for x in highs],
                         "kappa_A":"1","kappa_B":"1","kappa_C_global":str(globalcap),"kappa_C_geometric":str(geocap),"kappa_C":str(kC),
                         "cap_selected":"global" if globalcap<=geocap else "closed_box",
                         "new_source_packets":{str(i):{"original_labels":[A,B] if i==C else [i],"mass":str(newweights[i]),"kappa":str(newkap[i])} for i in labels},
                         "quotient_edges":[list(x) for x in sorted(quotient_edges)],"quotient_neighbors":{str(i):sorted(newadj[i]) for i in labels},
                         "common_correction_terms":terms,"common_correction_sum":str(correction),
                         "criterion_left":str(left),"criterion_right":str(right),"J_old":str(Jold),"J_new":str(Jnew),
                         "J_new_minus_J_old":str(difference),"difference_formula":str(formula),
                         "sign":sign,"strict_decrease":difference<0,"nonincrease":difference<=0})
            paircount+=1
        out=P/(PRE+"_"+case["case_id"]+".json.gz")
        raw=json.dumps({"complete_case":case,"original_neighbor_masks":old["neighbor_masks"],
                         "original_pair_distance_graph":old["pair_distance_graph"],"original_source_cells":old["source_cell_indices"],
                         "original_graph_status":"Original conservative co-capture covering graph, not replaced by exact atom graph.",
                         "original_singleton_kappa":"1, proved atom own-logmax upper cap","J_old":str(Jold),"merges":rows},
                       ensure_ascii=False,sort_keys=True,separators=(",",":")).encode()
        out.write_bytes(gzip.compress(raw,mtime=0))
        art={"path":str(out),"sha256":sha(out),"uncompressed_sha256":hashlib.sha256(raw).hexdigest()};artifacts.append(art)
        summaries.append({"case_id":case["case_id"],"round":case["round"],"n":n,"N":N,"graph_recipe":case["graph_recipe"],
                          "pairs":len(rows),"checks":checks-before,"J_old":str(Jold),
                          "counts":{s:sum(r["sign"]==s for r in rows) for s in ("negative","zero","positive")},
                          "cap_counts":{s:sum(r["cap_selected"]==s for r in rows) for s in ("global","closed_box")},
                          "min_delta":str(min(F(r["J_new_minus_J_old"]) for r in rows)),
                          "max_delta":str(max(F(r["J_new_minus_J_old"]) for r in rows)),"artifact":art})
    ck(paircount==123 and len(summaries)==9,"registered all-pair count")
    result={"status":"PASS","checks":checks,"pair_records":paircount,"cases":summaries,
            "script_sha256":sha(pathlib.Path(__file__)),"registration_sha256":sha(regp),"elapsed_seconds":time.monotonic()-start,
            "scope":"Single-merge exact quotient graph, complete source mass and proved geometric/global own-fee caps. No new max, actual clock history, global greedy optimality or sqrt theorem.",
            "old_graph_program_invocations":0,"max_queries":0}
    rp=P/(PRE+"_results.json");dump(rp,result)
    dump(P/(PRE+"_receipt.json"),{"status":"PASS","successful_execution_count":1,"failed_execution_count":0,
                                 "checks_successful_terminal_only":checks,"script_sha256":sha(pathlib.Path(__file__)),
                                 "registration_sha256":sha(regp),"results_sha256":sha(rp),
                                 "new_artifacts":artifacts,"elapsed_seconds":result["elapsed_seconds"],
                                 "old_graph_program_invocations":0,"max_queries":0})
    print(json.dumps({"status":"PASS","checks":checks,"cases":len(summaries),"pairs":paircount,
                      "sign_counts":{s:sum(c["counts"][s] for c in summaries) for s in ("negative","zero","positive")},
                      "elapsed_seconds":result["elapsed_seconds"]}))
if __name__=="__main__":main()

