#!/usr/bin/env python3
"""Portable replay of the two saved exact receiver inputs; no new sampling."""
import json,time,hashlib,sys
from pathlib import Path
from ccu_r627_exact import e_scan
P=Path(__file__).resolve().parent
sys.set_int_max_str_digits(100000)
d=json.loads((P/"selected_exact_historical.json").read_text());out=[]
for row in d["selected"]:
 t=time.monotonic()
 z=e_scan([row["a_exact_binary64"]]*row["n"],row["x_exact_binary64"],max_events=1000000,seconds=60)
 assert z["E"]==row["result"]["E"]==False
 assert z==row["result"],"exact event result changed"
 out.append({"n":row["n"],"density_case":row["density_case"],"result":z,"wall_seconds":time.monotonic()-t})
r={"status":"passed","selected":out,"script_sha256":hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),"scope":"two saved binary64 receiver inputs only"}
(P/"selected_exact_replay.json").write_text(json.dumps(r,indent=2)+"\n")
print({"status":r["status"],"cases":[(z["n"],z["density_case"],z["wall_seconds"]) for z in out]})
