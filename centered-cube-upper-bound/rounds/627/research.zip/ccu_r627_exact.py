#!/usr/bin/env python3
"""R627 exact rational two-coset event scans; no floating input coercion.

Input JSON: {"cases":[{"id":"...", "a":["..."], "x":["..."],
 "u":["..."], "sample_r":"..."}]} . x/u/sample_r optional; n=len(a).
The shifted coset is a_i*(k_i+1/2) in every coordinate, not independent
coordinate-wise coset choices. Output JSON to stdout only.
"""
import argparse,heapq,json,math,time,sys
from fractions import Fraction as F

def Q(x):
    if isinstance(x,float):raise TypeError('binary64 values must be supplied as exact rational strings')
    return F(x)
class BudgetExceeded(RuntimeError):pass

def cutoff(a,tau=F(3,4)):
    delta=F(2)/math.prod(a)
    if not delta<tau:raise ValueError('require 2/product(a) < tau')
    v=tau/delta;return sum(a)/(4*(v-1)/(v+1)),delta

def e_scan(a,x,*,max_events=200000,seconds=20):
    a=list(map(Q,a));x=list(map(Q,x));n=len(a)
    if not n or len(x)!=n or any(z<=0 for z in a):raise ValueError('invalid input')
    end,delta=cutoff(a);heap=[];cnt=[[0]*n for _ in range(2)];t0=time.monotonic()
    for group in (0,1):
        for i,(d,z) in enumerate(zip(a,x)):
            shift=F(group,2)*d; k=(z-shift)//d
            for side,idx in ((-1,k),(1,k+1)):
                distance=abs(idx*d+shift-z)
                heapq.heappush(heap,(distance,group,i,side))
    processed=groups=0
    while heap and heap[0][0]<=end:
        r=heap[0][0];groups+=1
        while heap and heap[0][0]==r:
            t,g,i,side=heapq.heappop(heap);cnt[g][i]+=1;processed+=1
            if processed>max_events or time.monotonic()-t0>seconds:raise BudgetExceeded('incomplete forward event scan')
            heapq.heappush(heap,(t+a[i],g,i,side))
        m=math.prod(cnt[0])+math.prod(cnt[1])
        if m>(2*r)**n:
            right=min(end,heap[0][0]);w=(r+right)/2
            while m<=(2*w)**n:w=(w+r)/2
            assert r<w<right and m>(2*w)**n
            return {'E':True,'witness_r':str(w),'strict_count':m,'strict_slack':str(F(m)-(2*w)**n),'events_processed':processed,'event_groups':groups,'safe_cutoff':str(end),'delta':str(delta)}
    return {'E':False,'complete_to_cutoff':True,'events_processed':processed,'event_groups':groups,'safe_cutoff':str(end),'delta':str(delta)}

def exit_scan(a,u,*,tau=F(3,4),sample_r=None,max_events=200000,seconds=20):
    a=list(map(Q,a));u=list(map(Q,u));tau=Q(tau);n=len(a)
    if not n or len(u)!=n or any(z<=0 for z in a) or any(abs(z)>=1 for z in u):raise ValueError('invalid input')
    end,delta=cutoff(a,tau);heap=[];cnt=[[1]*n,[0]*n];t0=time.monotonic()
    for i,(d,v) in enumerate(zip(a,u)):
        for group in (0,1):
            for side in (-1,1):
                # From an anchor y=0 in the unshifted coset, moving cube
                # centre is -u*R. Positive displacement enters at q/(1-u).
                gap=d if group==0 else d/2
                step=d/(1-side*v)
                heapq.heappush(heap,(gap/(1-side*v),group,i,side,step))
    left=F(0);best=F(0);events=groups=0;badplateaus=0;sample_count=None
    sample=Q(sample_r) if sample_r is not None else None
    if sample is not None and not 0<sample<end:raise ValueError('sample_r must be in (0,cutoff)')
    while left<end:
        right=min(end,heap[0][0]);A=math.prod(cnt[0])+math.prod(cnt[1])
        if sample is not None and left<=sample<=right and sample_count is None:
            # At an event the open cube has the pre-event count.
            if sample>left:sample_count=A
        if left<right and A>tau*(2*left)**n:
            badplateaus+=1;best=max(best,min(F(A)/tau,(2*right)**n))
        if right==end:break
        left=right;groups+=1
        while heap and heap[0][0]==right:
            t,g,i,side,step=heapq.heappop(heap);cnt[g][i]+=1;events+=1
            if events>max_events or time.monotonic()-t0>seconds:raise BudgetExceeded('incomplete exit event scan')
            heapq.heappush(heap,(t+step,g,i,side,step))
    out={'Vstar_exact':str(best),'events_processed':events,'event_groups':groups,'bad_plateaus':badplateaus,'safe_cutoff':str(end),'delta':str(delta)}
    if sample is not None:
        assert sample_count is not None
        V=(2*sample)**n
        out['sample']={'r':str(sample),'count':sample_count,'strict_tau_bad':sample_count>tau*V,'tau_slack':str(F(sample_count)-tau*V),'V_le_Vstar':V<=best}
    return out

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--input',required=True);ap.add_argument('--max-events',type=int,default=200000);ap.add_argument('--seconds',type=float,default=20);args=ap.parse_args()
    sys.set_int_max_str_digits(100000);data=json.load(open(args.input));out=[]
    for case in data['cases']:
        row={'id':case['id']}
        if 'x' in case:row['forward']=e_scan(case['a'],case['x'],max_events=args.max_events,seconds=args.seconds)
        if 'u' in case:row['exit']=exit_scan(case['a'],case['u'],sample_r=case.get('sample_r'),max_events=args.max_events,seconds=args.seconds)
        out.append(row)
    print(json.dumps({'cases':out},indent=2))
if __name__=='__main__':main()
