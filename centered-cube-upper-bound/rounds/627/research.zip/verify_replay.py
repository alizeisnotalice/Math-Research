#!/usr/bin/env python3
"""One sparse block replay plus exact structural and final-tail checks."""
import json,hashlib,math,sys,time,resource
from pathlib import Path
from fractions import Fraction as F
import numpy as np
import ccu_r627_numeric as numeric,ccu_r627_expand as expanded
P=Path(__file__).resolve().parent;t=time.perf_counter();cpu=time.process_time()
def count(x,r,a,shift):
 def ceil(q):return -((-q.numerator)//q.denominator)
 vals=[]
 for z in x:
  lo=(z-r-shift)/a;hi=(z+r-shift)/a;vals.append(max(0,ceil(hi)-int(lo//1)-1))
 return math.prod(vals)
a=F(2);r=F(11,10);x=[F(0),F(0)];c0=count(x,r,a,F());c1=count(x,r,a,a/2);assert (c0,c1,c0+c1)==(1,4,5)
assert (c0+c1)!=math.prod([3,3]),'must not expand to product of coset sums'
xs=[v+a/2 for v in x];assert count(xs,r,a,F())==c1 and count(xs,r,a,a/2)==c0
assert numeric.direct_anchor(np.zeros(2),float(r),float(a))==5
assert numeric.receiver_E(np.zeros(2),float(a),10.)[0]==1
old=json.loads((P/'replay_block_original.json').read_text());fresh=expanded.task((128,3,1,64));keys=('n','density_case','block','N','seed','q_hits','q_ambiguous','E_hits','E_ambiguous','guard_ambiguous','delta','a','Rcut','source_records','receiver_records');diff=[k for k in keys if fresh[k]!=old[k]];assert not diff,diff
orig=json.loads((P/'statistics_original.json').read_text());now=json.loads((P/'statistics_replay.json').read_text());assert orig['results']==now['results'],'16 exact tails/Arb results differ'
exact=json.loads((P/'exact_one_result.json').read_text());assert len(exact['cases'])==1;sample=exact['cases'][0]['exit']['sample'];assert sample['strict_tau_bad'] and sample['V_le_Vstar'] and sample['count']==1
out={'status':'passed','two_cosets_sum_products':[c0,c1,c0+c1],'incorrect_product_of_sums':9,'half_shift_swaps_coset_counts':True,'zero_event_receiver_true':True,'one_sparse_64_block':'all stable computational fields and records identical','exact_tail_16_and_arb':'all original result fields identical','exact_checker_one_source':'count=1, strict tau bad, V<=Vstar','script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'wall_seconds':time.perf_counter()-t,'cpu_seconds':time.process_time()-cpu,'peak_rss_bytes_macos':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
(P/'verification_receipt.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
