from fractions import Fraction as F
from pathlib import Path
import json,sys,hashlib
import sympy as s
h,b=s.symbols("h b",positive=True)
expr=h+b*h/(h-1)
assert s.simplify(s.diff(expr,h).subs(h,1+s.sqrt(b)))==0
assert s.simplify(expr.subs(h,1+s.sqrt(b))-(1+s.sqrt(b))**2)==0
assert s.simplify(s.diff(expr,h,2)-2*b/(h-1)**3)==0
checks={"direction_min_gt_1_6":F(93,500)>F(1,6),"direction_gap":F(93,500)-F(1,6)==F(29,1500),"entry_lt_21_40":F(18300003,35000000)<F(21,40),"radius_ratio_gt_5_4":F(80,63)>F(5,4),"total_mass_below_later_volume":F(20001,20000)<F(11999749,10000000)}
assert all(checks.values())
out={"status":"passed","fraction_checks":checks,"symbolic_optimization":"H=1+sqrt(b), value (1+sqrt(b))^2; positive second derivative for H>1,b>0","scope":"algebra and explicit uniform constants only; not a geometric theorem","python":sys.version,"sympy":s.__version__,"interpreter":sys.executable,"script_sha256":hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
Path(__file__).with_name("algebra_certificate.json").write_text(json.dumps(out,indent=2)+"\n")
print(json.dumps(out))
