import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[k]='1'
import argparse,concurrent.futures,hashlib,json,math,platform,resource,shlex,sys,time
from pathlib import Path
import numpy as np,scipy
from scipy.stats import beta
import ccu_r627_numeric as base

def params(n,k):
 if k<3:return base.params(n,k)
 delta=1/128;a=(2/delta)**(1/n);cut=n*a/(2*math.log(.75/delta))*1.00000000001;return delta,a,cut

def task(spec):
 n,k,block,N=spec;t=time.monotonic();cpu=time.process_time();delta,a,cut=params(n,k);seed=62720000+n*10000+k*100+block;rng=np.random.default_rng(seed);sources=[];receivers=[];z=amb=e=eamb=guard=0
 for i in range(N):
  u=2*rng.random(n)-1;parts,_=base.anchored_intervals(u,a,cut);assert parts;R=max(b for _,b in parts);w=[(hi/R)**n if lo==0 else math.exp(n*math.log(hi/R))*(-math.expm1(n*math.log(lo/hi))) for lo,hi in parts];occ=math.fsum(w);assert 0<occ<=1+1e-9;draw=rng.random(2);p=min(int(np.searchsorted(np.cumsum(w),draw[0]*occ,side='right')),len(parts)-1);lo,hi=parts[p];v=max(np.finfo(float).tiny,min(1-np.finfo(float).eps,float(draw[1])));r=hi*math.exp(math.log(v if lo==0 else math.exp(n*math.log(lo/hi))*(1-v)+v)/n);m=base.direct_anchor(u,r,a);margin=math.log(m)-math.log(.75)-n*math.log(2*r)
  if margin<=base.EPS:state=-1;amb+=1;guard+=1
  else:
   x=(-r*u+a/2)%a-a/2;state,_=base.receiver_E(x,a,cut);z+=state==1;amb+=state==-1
  sources.append({'u':u.tolist(),'r':r,'Rstar':R,'E_status':state,'source_count':str(m),'source_margin':margin,'occupation_ratio':min(1.,occ)})
 for i in range(N):
  x=(rng.random(n)-.5)*a;state,_=base.receiver_E(x,a,cut);e+=state==1;eamb+=state==-1;receivers.append({'x':x.tolist(),'E_status':state})
 return {'n':n,'density_case':k,'block':block,'N':N,'seed':seed,'q_hits':int(z),'q_ambiguous':int(amb),'E_hits':int(e),'E_ambiguous':int(eamb),'guard_ambiguous':int(guard),'delta':delta,'a':a,'Rcut':cut,'source_records':sources,'receiver_records':receivers,'elapsed_seconds':time.monotonic()-t,'cpu_seconds':time.process_time()-cpu,'peak_rss_bytes_macos':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}

def preserved(r):
 a=r['a'];n=r['n'];ss=[]
 for row in r['sample_records']:
  u=np.asarray(row['u']);x=(-row['r']*u+a/2)%a-a/2;ss.append(x)
 ss += [np.asarray(z['x']) for z in r['receiver_records']]
 def atom(x):return any(np.all(np.abs((x-sh)/a-np.round((x-sh)/a))<1e-14) for sh in (0.,a/2))
 matches=sum(atom(x) for x in ss);assert matches==0
 return {'n':n,'density_case':r['density_case'],'N':r['trials'],'seed':r['seed'],'q_hits':r['q_hits'],'q_ambiguous':r['q_ambiguous'],'E_hits':r['P_hits'],'E_ambiguous':r['P_ambiguous'],'guard_ambiguous':r['guard_ambiguous'],'reason':'saved source and receiver points do not equal either coset atom; hence no r=0+ positive-count platform can occur; corrected zero-event branch cannot alter these classifications','source_atom_matches':matches}

def main():
 p=argparse.ArgumentParser();p.add_argument('--pilot-input',type=Path);p.add_argument('--phase',choices=('initial','sparse_expand'),required=True);p.add_argument('--workers',type=int,default=14);p.add_argument('--output-dir',type=Path,default=Path(__file__).resolve().parent/'replay');a=p.parse_args();assert 1<=a.workers<=14;a.output_dir.mkdir(parents=True,exist_ok=True);orig=a.pilot_input if a.pilot_input else Path(__file__).resolve().parent/'expanded_counts.json';old=json.loads(orig.read_text());path=a.output_dir/'ccu_r627_expanded.json';md=a.output_dir/'ccu_r627_expanded.md';start=time.monotonic()
 if a.phase=='initial':
  pilots=[next(r for r in old['preserved_pilots'] if (r['n'],r['density_case'])==pair) for pair in ((32,0),(128,0),(32,2))] if 'preserved_pilots' in old else [preserved(next(r for r in old['results'] if (r['n'],r['density_case'])==pair)) for pair in ((32,0),(128,0),(32,2))];out={'pilot_input_sha256':hashlib.sha256(orig.read_bytes()).hexdigest(),'corrected_source_sha256':hashlib.sha256(Path(base.__file__).read_bytes()).hexdigest(),'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'python':sys.version,'numpy':np.__version__,'scipy':scipy.__version__,'platform':platform.platform(),'commands':[],'preserved_pilots':pilots,'results':[]};tasks=[]
  for n,k in ((32,0),(128,0)):
   tasks +=[(n,k,j,64) for j in range(7)]+[(n,k,7,48)]
  tasks +=[(32,2,0,64),(32,2,1,48),(128,3,0,64)]
 else:
  out=json.loads(path.read_text());sparse=[r for r in out['results'] if (r['n'],r['density_case'])==(128,3)];assert sum(r['E_hits'] for r in sparse)>=2,'sparse E gate not met';tasks=[(128,3,j,64) for j in range(1,16)]
 out['commands'].append(shlex.join([sys.executable]+sys.argv))
 def save():
  summaries=[]
  for n,k in ((32,0),(128,0),(32,2),(128,3)):
   rows=[r for r in out['results'] if (r['n'],r['density_case'])==(n,k)];pil=[r for r in out['preserved_pilots'] if (r['n'],r['density_case'])==(n,k)];N=sum(r['N'] for r in rows+pil)
   if not N:continue
   z=sum(r['q_hits'] for r in rows+pil);za=sum(r['q_ambiguous'] for r in rows+pil);e=sum(r['E_hits'] for r in rows+pil);ea=sum(r['E_ambiguous'] for r in rows+pil);delta=params(n,k)[0];q=z/N;P=e/N;W=P/delta
   summaries.append({'n':n,'density_case':k,'N':N,'delta':delta,'q_hits':z,'q_ambiguous':za,'E_hits':e,'E_ambiguous':ea,'q':q,'P':P,'W':W,'absorb_1_16':(q+1/16)/W if W else None,'absorb_1_4':(q+1/4)/W if W else None,'q_sampling_CP':[(float(beta.ppf(.05/16,z,N-z+1)) if z else 0),float(beta.ppf(1-.05/16,z+za+1,N-z-za)) if z+za<N else 1],'P_sampling_CP':[(float(beta.ppf(.05/16,e,N-e+1)) if e else 0),float(beta.ppf(1-.05/16,e+ea+1,N-e-ea)) if e+ea<N else 1]})
  out['summaries']=summaries;path.write_text(json.dumps(out));L=['# R627 decision-relevant expanded pilot','','Original 16-point pilots are retained only after exact-atom check; all additional samples use distinct fixed seeds. q and P are independent per case. Float geometry and RNG are not certified. q≤1 is a mathematical source-budget ceiling, not an estimate of future optimized angular weights.','','| n | δ | N | q hits | E hits | q | W | (q+1/16)/W | (q+1/4)/W |','|---:|---:|---:|---:|---:|---:|---:|---:|---:|']
  for r in summaries:L.append('| %d | %.7g | %d | %d | %d | %.7g | %.7g | %s | %s |'%(r['n'],r['delta'],r['N'],r['q_hits'],r['E_hits'],r['q'],r['W'],str(r['absorb_1_16']),str(r['absorb_1_4'])))
  L+=['','Clopper–Pearson entries in JSON are sampling-only candidates for independent integer-tail verification; they do not certify floating event classifications. No dimension-growth conclusion is implied.'];md.write_text('\n'.join(L)+'\n')
 with concurrent.futures.ProcessPoolExecutor(max_workers=min(a.workers,len(tasks))) as pool:
  for f in concurrent.futures.as_completed([pool.submit(task,t) for t in tasks]):
   r=f.result();out['results'].append(r);save();print('done',r['n'],r['density_case'],r['block'],'N',r['N'],'E',r['E_hits'],flush=True)
 out['last_wall_seconds']=time.monotonic()-start;out['worker_cpu_sum_seconds']=sum(r['cpu_seconds'] for r in out['results']);out['max_worker_rss_bytes']=max(r['peak_rss_bytes_macos'] for r in out['results']);save()
if __name__=='__main__':main()
