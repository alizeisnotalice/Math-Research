# R627 独立scope审计与作者关键步终审

日期：2026-10-28。原独立gate曾写入`/tmp/ccu_r627_audit.md`，文件冲突后按根代理指示迁移至本文件。§§1–4恢复读取作者稿之前已形成的判断；§§5–7独审`/tmp/ccu_r627_main.md`。不改他人文件、不启动Agent、不扩展反例族。只运行一次本机Fraction/SymPy的有界常数及代数核验，无新样本或大计算。

## 1. 原独立gate：阈值优化不是自动的新预算

同一真实finite L1来源μ、M=μ(R^n)、E1={M_μ>1}下，I_τ=∫_(E1)C_τ≤M。若证明I_τ≥κ_n|E1|−εM，得到|E1|≤(1+ε)M/κ_n。反向若已知|E1|≤K_nM，则任意非负C都平凡满足I≥(ε/K_n)|E1|−εM。因此允许固定ε>0的integrated lower在阶数上与所求weaktype同难；将目标改名为kernel优化不是独立进展。ε=0是更强的具体kernel要求。

可对每个输入一次选τ或angular密度w(y,u)≥0，条件2^(−n)∫w(y,u)du≤1保证每source的一份预算。但实际C随之改变；依receiver各取最优τ/角度则没有该共同负载保证。把最多M的source mass尽量发往E1，也没有建立与|E1|的比较。

## 2. 原独立gate：跨τ的准确比较

固定y,u，以v=V(r)写A(v)，G_τ={A(v)>τv}、B_τ=|G_τ|、H={y−v^(1/n)u/2∈E1}。有G1⊂H、G1⊂G_τ，且由A非减得G1/τ⊂G_τ。因此B_τ≥B1/τ，且

I_τ=∫dμ E_u[|G_τ∩H|/B_τ]≥∫dμ E_u[B1/B_τ]，
I_1=∫dμ E_u[1{B1>0}]。

零分母取0。现有通用界只给τB1/M≤B1/B_τ≤τ，没有统一正保留率。新增τ-bad半径可能在H内或外，不能凭嵌套断言I_τ单调。τ=1的active source mass即使保留，也尚未付receiver体积。

τ↑1的集合极限是{A≥v}而非strict G1；正dV测度的等号platform使其不自动趋strict occupation。若active方向另证等号零测，可得该方向保留概率趋1，但没有一般统一速率或volume bound。R626局部annulus与B_τ≤M/τ只给C_τ(x)≥τlog(1/τ)V0/M；优化系数最多1/e，仍未消除V0/M。这不是完整C的上界。

## 3. 原独立gate：真实cube几何接口

uniform u下的准确一、二阶接口为

E_u A_(y,u)(r)=∫∏_i(1−|z_i−y_i|/(2r))_+dμ(z)，
E_u A_(y,u)(r)^2=∫∫∏_i(1−span{y_i,z_i,z'_i}/(2r))_+dμ(z)dμ(z')。

乘积来自我们选择的uniform方向，不来自μ坐标独立。angular重加权后必须重算。只有这些entry/span约束或其它明确cube几何若能控制跨receiver的共同escape/overlap，才提供新信息；仅有每方向source预算或单parent增长尚不足够。

## 4. 原独立gate：一个具体但未证的充分tail合同

沿x的outer 1-level局部cube Q0、质量V0，令Π_x为y∼μ|Q0/V0和annulus上归一化n dr/r的联合分布，L=log(1/τ)。定义T_Λ(x)=Π_x{B_τ(y,(y−x)/r)>ΛV0}。则

C_τ(x)≥(L/Λ)[1−T_Λ(x)]。

若独立几何证明∫_(E1)T_Λ≤ρ|E1|+A_nM、ρ<1，便得κ=(1−ρ)L/Λ及ε=A_nL/Λ。Λ为root polylog、A_n=O(Λ/L)才给所需量级。它是更强且可检验的tail条件，不是已有定理；局部annulus失败也不否定完整C。只将它命名escape lemma、或不带严格收缩调用原weaktype，均未越过gate。

## 5. 作者mean+fresh对数界：公式及可积性通过

现独审作者τ=3/4、完整strict B_τ合同。outer r0可用真实strict 1-bad半径的sup作Borel选择；有限M与L1连续性给0<r0<∞、m(x,r0)=V0。作者entry (2)准确，R≥r∈I时anchored parent包含Q0。

尾部v>Hv0、v0=V0/τ上，bad指标≤F/[τ(v−v0)]。小v段长≤Hv0，按同一fresh μ交换积分后，作者(4)–(5)的log分母max{V(entry),Hv0}−v0及1/τ系数均正确。VM≤Hv0的分支也无负log或零分母。用1/(v−v0)≤H/[(H−1)v]给(6)的nH/[τ(H−1)]正确，且确为有损线性放松，不是共同预算。

e_x点wise可积且有限，无需density cap：

0≤e_x≤[(M−V0)/(nV0)]log(M/V0)<∞。

因为T1>0，fresh总质量M−V0有限，log核至多(1/n)log(M/V0)。B_τ在π_x活跃项上正且≤M/τ，故E B_τ有限且正；Jensen E(1/B_τ)≥1/E B_τ合法，即使左端为∞。由(6)并以T1替T_H给作者(9)，H=1+sqrt(ne_x)的优化值确为(1+sqrt(ne_x))²；e_x=0取H↓1也正确。

(11)由两次Cauchy得出，方向及系数通过；应在0<|F|<∞且∫F e_x<∞时使用，空集平凡。E1的有限体积可使用既有有限维粗weaktype基线，不需要待证root估计。不能先假设全receiver e_x可积且有统一预算；作者下一节正好排除了这种过强使用。

## 6. 固定一维finite-L1筛查：全部关键常数通过

取整数N≥1，Δ=1/[100(N+1)]、ε=Δ/(100N)，所有bumps支撑半径η<ε/1000。N个位置在[.6,.61]内保持间距≥Δ可实现；X_j长度ε/8且两两不交。自身bump在r0=ε/2内全被捕获，质量ε；x∈X_j有严格1-bad较小半径。r0以后到Δ/4只见自身质量；r≥Δ/4而未见原点时，小bumps总量Nε=Δ/100，平均≤1/50。看到原点时r≥.6−ε/4−η。

使用指定本机数学Python实际Fraction核验了全N统一最坏常数：

* ε≤1/20000、η<1/20000000，M≤20001/20000；看到原点时长度≥11999749/10000000>M。因此确无later 1-bad平台，outer r0准确为ε/2。
* y在自身bump、x∈X_j、r<2ε/3时，u>(3/16)−3η/(2ε)>93/500=.186；它比1/6大29/1500。因此作者u≥1/6合法，无须将阈值改成更大的数。
* 原点bump中任意z的entry≤(6/7)(61/100+2η)<18300003/35000000<21/40=.525。T1=2ε/3也小于21/40，R_M≥2/3，所以R_M/max{T1,entry}≥80/63>5/4。

原点unit mass对fresh log积分统一贡献至少log(5/4)，故e_x≥log(5/4)/ε；乘每个X_j长度ε/8并相加给作者(12)。来源M<2而该积分随N线性增长，确实排除了固定n=1下∫_(E1)e_x≤K_nM的复杂度无关一般界。整个构造逐N为有限光滑compact L1输入，不依赖atomic转移。

这个结论仅否定线性fresh log-energy再作全receiver算术平均的共同预算。小receiver总体积很小，完整C还包含原点大来源的直接信用；不能据此声称C低、母weaktype失败，或否定对某个冻结family更有利的共同最优来源。作者稿已保持这些限制。

## 7. 二阶恒等式与最终审查判断

作者(13)及不同半径(14)通过：在每坐标把center为0、(y_i−z_i)/R、(y_i−z'_i)/S的三个长度2区间求交，归一化长度即[1−span/2]_+。R=S时正确化为§3的three-point span。mean乘积及covariance不能删去；(16)的两点局部例A=a+b1{U1<0}、方差b²/4亦准确，只否定无条件1/n saving。它不含真实outer/receiver掩膜，不能直接代入π_x的诱导方向分布。

实际运行的SymPy只另确认H+bH/(H−1)的驻点和优化值；它不认证几何。除上述有界常数核验外无新计算、样本、反例族或Agent。

**终审：作者关键公式(4)–(11)、固定1D有限L1失败步骤及二阶cube恒等式通过，无决定性数学错误。一般积分receiver lower、低信用严格吸收及root维数改进仍未证明。** 新结果正确定位一个过强的fresh-energy共同预算，而未否定完整B_τ核或原母目标。本独立scope审计恢复及追加完成，停止。
