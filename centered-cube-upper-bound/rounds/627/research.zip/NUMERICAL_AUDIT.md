# R627 独立数值与几何核验

这是数值核验记录，与 Sol 的理论审计分开。独立事件扫描代码：`/tmp/ccu_r627_exact.py`，SHA-256 `a7f53db86c12c1c78dcb77156ff28d063604d1ca49e06ce064a32340379595b2`。受检生产代码 `/tmp/ccu_r627_numeric.py`，SHA-256 `2aad5d06a9b568c989393bff0c07ad62fb841da8b533ab3bb9157f65451c1a43`；唯一受检 pilot 文件 `/tmp/ccu_r627_compute/case_n7_d0.json`，SHA-256 `8c9ce598cc39ea5e33754b74c3696589e53d1f359fba63a1c9674c992b2e6430`。独立计算通过指定 venv 的 Python 单进程执行，未运行其他 case 或全批。

检查生产代码：两组全局相关的 coset 分别按轴计数相乘，再把两个乘积相加；anchored 起始计数分别是各轴 1 和各轴 0，第二组首次距离对应半周期。两类格点在全坐标同时平移半周期时互换；这解释同一平移不变 source-view 下两类等分布，不单独证明积分恒等式。

独立脚本以有理数为输入，精确合并相同半径事件。forward 对严格正裕度构造有理见证；否则完整扫描到有理安全截止值。anchored 逐平台精确比较 `min(A/τ,(2Rnext)^n)`，不假设首次穿越即终止；开盒事件点计数取事件前值。超时或事件预算耗尽则抛异常，不输出部分值。一维玩具算例检查了零事件、同时入点、开边界、false 全扫描和 `Vstar=4/3`。

| 来源 | 行号 | 已存与独立结果 | 附加核验 |
|---|---:|---|---|
| receiver | 0 | E=true / true | 有严格见证 |
| receiver | 1 | E=false / false | 有理安全截止前 75 个事件完整扫描 |
| source sample | 0 | E=true / true | count=1；严格 τ-bad，V≤Vstar；exit 显示一致 |
| source sample | 1 | E=true / true | count=1；严格 τ-bad，V≤Vstar；exit 显示一致 |

执行时错误地将同编号 receiver 和独立 source 记录视为一组，实际上共检查了四条独立记录，超过每 case 最多两条的要求；没有检查其他 case。receiver 和 source 分别独立抽样，同编号不代表配对。核验以所存 binary64 数的精确有理表示为输入，不是原无理 spacing 的严格证书，也不将有限周期原子数值视为一般 L1 见证。

边界风险：生产 `receiver_E` 跳过 r=0 事件后的检查，一般参数下若 x 恰好位于源点，初始正半径平台可能已经满足 E，从而可能漏判；应检查该右侧平台。它对应连续抽样的零测边界，未发现上表的已保存结果受其影响，不能据此断言所有试验失败。

此前两行真实数值的核验结果由一次性标准输入脚本打印并记录于本报告；**没有单独生成我的 exact result JSON**。`/tmp/ccu_r627_numeric.json` 属于生产计算结果，并非此独立审计的 JSON。

## Expanded 的两条指定记录及零事件复核

单独运行 `/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/ccu_r627_selected_check.py`。该 wrapper 在运行任何检查之前写出精确选择的输入，随后将结果写入 `/tmp/ccu_r627_selected_exact.json`；输入来源是 `/tmp/ccu_r627_expanded.json`。按 block 顺序选后续 pilot 的首条 false E，两条都是 n=128、block 0、row 0：density_case 0 和 3 各一条。没有读取其他记录用于判定，没有重扫原试算。

独立有理事件扫描分别完整处理 19,980 和 16,725 个事件，抵达保守安全截止，均确认 E=false，与保存分类一致；耗时约 0.81 秒和 0.71 秒，未触发每条 60 秒限制。所有 binary64 a 与 x、半周期 shift 均作为精确有理输入保存在结果 JSON；有理截止值分别约 40.0573 和 34.1203。它们只是保存的二进制近似模型的严格判断，不是原无理 spacing 的证书。

此外用 density_case 0 的 a 对原点这一源点单独检查：修正后的生产 `receiver_E` 在 128 个零事件后返回 true；独立精确实现也返回 true，并给出有理正半径 witness。该单点检查验证了已发现的零事件分支修复，不等于对其他所有边界输入的证明。wrapper SHA-256 `7de410b9f6a10c5429d3ae7151871cb6248d36db9f3d2eba939edeecfd11f387`；原独立 engine 散列和修正后生产脚本散列同时写入结果 JSON。
