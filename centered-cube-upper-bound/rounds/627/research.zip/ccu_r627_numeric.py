import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[k]='1'
import argparse,concurrent.futures,hashlib,heapq,json,math,platform,resource,shlex,sys,time
from pathlib import Path
import numpy as np,scipy
from scipy.stats import beta
TAU=.75;LT=math.log(TAU);EPS=1e-10

def params(n,k):
 delta=1/(4*n**.25) if k==0 else (.5 if k==1 else .625);a=(2/delta)**(1/n);cut=n*a/(2*math.log(TAU/delta))*1.00000000001;return delta,a,cut

def entry_heap(x,a):
 n=len(x);heap=[]
 for c,shift in enumerate((0.,a/2)):
  for i,z in enumerate(x):
   k=math.floor((z-shift)/a); left=(k*a+shift);right=left+a
   heapq.heappush(heap,(z-left,c,i,-1));heapq.heappush(heap,(right-z,c,i,1))
 return heap

def receiver_E(x,a,cut):
 n=len(x);heap=entry_heap(x,a);counts=[[0]*n for _ in range(2)];zero=[n,n];prod=[1,1];amb=False;events=0
 while heap:
  r=heap[0][0]
  if r>cut:break
  while heap and heap[0][0]==r:
   _,c,i,d=heapq.heappop(heap);old=counts[c][i];counts[c][i]+=1
   if old==0:zero[c]-=1
   else:prod[c]=prod[c]//old*(old+1)
   heapq.heappush(heap,(r+a,c,i,d));events+=1
  m=(prod[0] if zero[0]==0 else 0)+(prod[1] if zero[1]==0 else 0)
  if r<=0:
   if m:return 1,events
   continue
  if not m:continue
  v=math.log(m)-n*math.log(2*r)
  if v>EPS:return 1,events
  if v>=-EPS:amb=True
 return (-1 if amb else 0),events

def anchored_intervals(u,a,cut):
 n=len(u);heap=[]
 for c in (0,1):
  for i,z in enumerate(u):
   for side in (-1,1):
    den=1+side*z
    if den>1e-15:
     step=a/den;first=step if c==0 else step/2
     heapq.heappush(heap,(first,c,i,step))
 counts=[[1]*n,[0]*n];zero=[0,n];prod=[1,1];parts=[];last=0.;events=0
 while True:
  nxt=heap[0][0] if heap else cut;m=prod[0]+(prod[1] if zero[1]==0 else 0);root=.5*math.exp((math.log(m)-LT)/n);end=min(nxt,root,cut)
  if end>last:parts.append((last,end))
  if not heap or nxt>=cut:break
  last=nxt
  while heap and heap[0][0]==nxt:
   _,c,i,step=heapq.heappop(heap);old=counts[c][i];counts[c][i]+=1
   if old==0:zero[c]-=1
   else:prod[c]=prod[c]//old*(old+1)
   heapq.heappush(heap,(nxt+step,c,i,step));events+=1
 return parts,events

def direct_anchor(u,r,a):
 x=-r*u;m=0
 for shift in (0.,a/2):
  c=np.floor((x+r-shift)/a).astype(int)-np.ceil((x-r-shift)/a).astype(int)+1
  m+=math.prod(map(int,c))
 return m

def run(pair):
 n,k=pair;t=time.monotonic();cpu=time.process_time();delta,a,cut=params(n,k);rng=np.random.default_rng(627000+n*10+k);samples=[];recv=[];z=amb=e=eamb=guard=0;eventsmax=0
 for h in range(16):
  u=2*rng.random(n)-1;parts,ne=anchored_intervals(u,a,cut);assert parts;R=max(b for _,b in parts);eventsmax=max(eventsmax,ne)
  weights=[(hi/R)**n if lo==0 else math.exp(n*math.log(hi/R))*(-math.expm1(n*math.log(lo/hi))) for lo,hi in parts];occ=math.fsum(weights);assert 0<occ<=1+1e-9;draw=rng.random(2);idx=min(int(np.searchsorted(np.cumsum(weights),draw[0]*occ,side='right')),len(parts)-1);lo,hi=parts[idx];v=max(np.finfo(float).tiny,min(1-np.finfo(float).eps,float(draw[1])));ratio=v if lo==0 else math.exp(n*math.log(lo/hi))*(1-v)+v;r=hi*math.exp(math.log(ratio)/n);m=direct_anchor(u,r,a);margin=math.log(m)-LT-n*math.log(2*r)
  if margin<=EPS:guard+=1;amb+=1;state=-1
  else:
   x=(-r*u+a/2)%a-a/2;state,ne2=receiver_E(x,a,cut);eventsmax=max(eventsmax,ne2)
   if state==1:z+=1
   if state==-1:amb+=1
  samples.append({'u':u.tolist(),'r':r,'Rstar':R,'occupation_ratio':min(1.,occ),'source_count':str(m),'source_margin':margin,'E_status':state,'selected_interval':[lo,hi],'anchor_events':ne})
 for h in range(16):
  x=(rng.random(n)-.5)*a;state,ne=receiver_E(x,a,cut);eventsmax=max(eventsmax,ne);e+=int(state==1);eamb+=int(state==-1);recv.append({'x':x.tolist(),'E_status':state,'events':ne})
 P=e/16;q=z/16;W=P/delta if P else 0.
 return {'n':n,'density_case':k,'delta':delta,'a':a,'Rcut':cut,'seed':627000+n*10+k,'trials':16,'q_hits':z,'q_ambiguous':amb,'P_hits':e,'P_ambiguous':eamb,'q_estimate':q,'P_estimate':P,'W_estimate':W,'credit_plus_1_16':None if not W else (q+1/16)/W,'credit_plus_1_4':None if not W else (q+1/4)/W,'sample_records':samples,'receiver_records':recv,'guard_ambiguous':guard,'max_events':eventsmax,'elapsed_seconds':time.monotonic()-t,'cpu_seconds':time.process_time()-cpu,'peak_rss_bytes_macos':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}

def main():
 p=argparse.ArgumentParser();p.add_argument('--phase',choices=('first','remaining'),required=True);p.add_argument('--workers',type=int,default=1);p.add_argument('--output-dir',type=Path,default=Path(__file__).resolve().parent/'replay');a=p.parse_args();assert 1<=a.workers<=14;a.output_dir.mkdir(parents=True,exist_ok=True);cp=a.output_dir/'ccu_r627_compute';cp.mkdir(exist_ok=True);path=a.output_dir/'ccu_r627_numeric.json';md=a.output_dir/'ccu_r627_numeric.md';start=time.monotonic()
 if a.phase=='first':out={'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'commands':[],'python':sys.version,'numpy':np.__version__,'scipy':scipy.__version__,'platform':platform.platform(),'source':'two globally coupled cosets, total density 2/a^n','results':[]};tasks=[(7,0)]
 else:out=json.loads(path.read_text());tasks=[(n,k) for n in (7,32,128) for k in (0,1,2) if (n,k)!=(7,0)]
 out['commands'].append(shlex.join([sys.executable]+sys.argv))
 def save():
  path.write_text(json.dumps(out));L=['# R627 correlated two-coset occupation pilot','','The source is aZ^n plus its global diagonal half-shift; source counts are sums of two coordinate products, not a product source. Source-view q and independent receiver P(E) use 16 samples each. The source-view identity and all geometric evaluations remain floating periodic diagnostics, not proof or a finite-L1 result.','','| n | δ | hits q | hits P(E) | W=P/δ | (q+1/16)/W | (q+1/4)/W | Rcut |','|---:|---:|---:|---:|---:|---:|---:|---:|']
  for r in sorted(out['results'],key=lambda z:(z['n'],z['density_case'])):L.append('| %d | %.6g | %d/16 | %d/16 | %.6g | %s | %s | %.5g |'%(r['n'],r['delta'],r['q_hits'],r['P_hits'],r['W_estimate'],str(r['credit_plus_1_16']),str(r['credit_plus_1_4']),r['Rcut']))
  L+=['','Each fixed case uses independent source and receiver samples and a single true multi-coset source. Very small sample counts, floating cutoffs and geometry prevent inference of any general dimensional order.'];md.write_text('\n'.join(L)+'\n')
 with concurrent.futures.ProcessPoolExecutor(max_workers=min(a.workers,len(tasks))) as pool:
  for f in concurrent.futures.as_completed([pool.submit(run,q) for q in tasks]):
   r=f.result();out['results'].append(r);(cp/('case_n%d_d%d.json'%(r['n'],r['density_case']))).write_text(json.dumps(r));save();print('done',r['n'],r['density_case'],'q',r['q_hits'],'E',r['P_hits'],'events',r['max_events'],flush=True)
 out['last_wall_seconds']=time.monotonic()-start;out['worker_cpu_sum_seconds']=sum(z['cpu_seconds'] for z in out['results']);out['max_worker_rss_bytes']=max(z['peak_rss_bytes_macos'] for z in out['results']);out['workers_last']=a.workers;save()
if __name__=='__main__':main()
