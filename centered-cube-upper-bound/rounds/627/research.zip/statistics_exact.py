import json,math,sys,time,platform,resource,hashlib,argparse
from pathlib import Path
from fractions import Fraction as Q
from scipy.stats import beta
import scipy,flint
from flint import arb,fmpq,ctx
ROOT=Path(__file__).resolve().parent
parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,default=ROOT/'statistics_replay.json');args=parser.parse_args()
sys.set_int_max_str_digits(30000);ctx.prec=256;start=time.perf_counter();cpu=time.process_time();ex=ROOT/'expanded_counts.json';pilot=ROOT/'pilot_metadata.json';script=ROOT/'ccu_r627_numeric.py';d=json.loads(ex.read_text());old=json.loads(pilot.read_text());h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();assert d['pilot_input_sha256']==old['original_pilot_sha256'] and d['corrected_source_sha256']==old['original_corrected_selector_sha256'] and 'r=0+' in old['audit_correction'];den=10**6

def tail(n,k,p,up):
 lo,hi=(k,n+1) if up else (0,k+1)
 return Q(sum(math.comb(n,j)*p**j*(den-p)**(n-j) for j in range(lo,hi)),den**n)
def interval(n,k):
 L=math.floor(beta.ppf(1/320,k,n-k+1)*den) if k else 0;U=math.ceil(beta.ppf(1-1/320,k+1,n-k)*den) if k<n else den
 while k and tail(n,k,L,True)>Q(1,320):L-=1
 while k<n and tail(n,k,U,False)>Q(1,320):U+=1
 lt=tail(n,k,L,True) if k else Q();ut=tail(n,k,U,False) if k<n else Q();assert 0<=L<=U<=den and lt<=Q(1,320) and ut<=Q(1,320);return Q(L,den),Q(U,den),lt,ut
def ep(pair):return Q(int(pair[0]))*Q(2)**int(pair[1])
def endpoints(x):
 a=x.lower().man_exp();b=x.upper().man_exp();return ep(a),ep(b)
def outward(q,upper):return Q(-((-q.numerator*den)//q.denominator) if upper else q.numerator*den//q.denominator,den)
f=lambda x:[str(x.numerator),str(x.denominator)]
cases=[(32,0),(128,0),(32,2),(128,3)];results=[]
for n,k in cases:
 records=[r for r in d['results'] if r['n']==n and r['density_case']==k];assert records and all(r['q_ambiguous']==r['E_ambiguous']==r['guard_ambiguous']==0 for r in records)
 observed=next(r for r in d['summaries'] if r['n']==n and r['density_case']==k)
 saved=[r for r in d['preserved_pilots'] if r['n']==n and r['density_case']==k]
 if k==3:
  first=next(r for r in records if r['block']==0);assert first['N']==64 and first['E_hits']>=2;fresh=[r for r in records if r['block']!=0];excluded={'N':64,'q_hits':first['q_hits'],'E_hits':first['E_hits'],'reason':'sparse expansion decision'}
 else:
  assert len(saved)==1 and saved[0]['N']==16 and saved[0]['source_atom_matches']==0;fresh=records;excluded={'N':16,'q_hits':saved[0]['q_hits'],'E_hits':saved[0]['E_hits'],'reason':'case-selection pilot'}
 N=sum(r['N'] for r in fresh);q=sum(r['q_hits'] for r in fresh);e=sum(r['E_hits'] for r in fresh);assert (N,q,e)=={(32,0):(496,431,104),(128,0):(496,479,117),(32,2):(112,112,109),(128,3):(960,906,18)}[(n,k)];assert observed['N']==N+excluded['N'] and observed['q_hits']==q+excluded['q_hits'] and observed['E_hits']==e+excluded['E_hits']
 a_floats={r['a'] for r in records};assert len(a_floats)==1;floating_a=Q.from_float(next(iter(a_floats)));delta_bin=2/floating_a**n
 if k==0: ideal=1/(4*(arb(n).log()/4).exp())
 elif k==2:ideal=arb(fmpq(5,8))
 else:ideal=arb(fmpq(1,128))
 dl,du=endpoints(ideal);assert dl>0
 ql,qu,qlt,qut=interval(N,q);el,eu,elt,eut=interval(N,e);assert ql>0 and el>0
 def ratio(dl,du):return {'W':[f(outward(el/du,False)),f(outward(eu/dl,True))],'credit_1_16':[f(outward(dl*(ql+Q(1,16))/eu,False)),f(outward(du*(qu+Q(1,16))/el,True))]}
 results.append({'n':n,'density_case':k,'all_counts':{'N':observed['N'],'q':observed['q_hits'],'E':observed['E_hits']},'excluded':excluded,'fresh_counts':{'N':N,'q':q,'E':e},'q_interval':[f(ql),f(qu)],'E_interval':[f(el),f(eu)],'tail_exact':{'q_lower':f(qlt),'q_upper':f(qut),'E_lower':f(elt),'E_upper':f(eut)},'ideal_delta_interval':[f(dl),f(du)],'binary64_a_exact':f(floating_a),'binary64_model_delta_exact':f(delta_bin),'ideal_density_results':ratio(dl,du),'binary64_density_results':ratio(delta_bin,delta_bin),'angular_1_over_q_interval':[f(outward(1/qu,False)),f(outward(1/ql,True))]})
out={'results':results,'tail_threshold':'1/320','familywise_failure_at_most':'1/20','scope':'conditional ideal iid exact event tests on fresh postdecision samples; excludes PRNG, spacing, r0 and event numerical errors; no general-dimensional claim','expanded_sha256':h(ex),'pilot_sha256':h(pilot),'corrected_selector_sha256':h(script),'script_sha256':h(Path(__file__)),'runtime':{'python':sys.version,'scipy':scipy.__version__,'flint':flint.__version__,'sys_executable':sys.executable,'platform':platform.platform(),'argv':[sys.executable]+sys.argv,'wall_seconds':time.perf_counter()-start,'cpu_seconds':time.process_time()-cpu,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}}
args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_text(json.dumps(out,indent=2)+'\n');print([(r['n'],r['density_case'],r['fresh_counts'],r['q_interval'],r['E_interval'],r['ideal_density_results'],r['angular_1_over_q_interval']) for r in results]);print('sha',out['script_sha256'],'wall',out['runtime']['wall_seconds'])
