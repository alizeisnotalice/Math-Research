# R627 复现与证据范围

使用本机独立环境 `/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python`。实际版本：Python 3.12.14、NumPy 2.5.4、SciPy 1.18.1、SymPy 1.14.0、python-flint 0.9.0；详细解释器、哈希与原始命令见 computational_provenance.json 和统计证书。

在解压目录执行（将 python 替换为上述解释器）：

```sh
python statistics_exact.py --output statistics_replay.json
python ccu_r627_exact.py --input exact_one_input.json > exact_one_result.json
python verify_replay.py
python selected_check.py
python verify_algebra.py
```

这些命令已实际执行。verify_replay.py仅重放一个128维稀疏模型64点分块，检查全部稳定字段，另检查零半径事件、两余类乘积之和及半移交换；没有重跑全部模型。selected_check.py按已保存准确有理输入重放两个128维否定事件，全扫描至安全截断；不依赖未归档的全量临时JSON。每条限制60秒，超时必须报错，不能把部分扫描当否定证书。

## 数据血缘

- expanded_counts.json保存全部分块的计数、种子与间距，以及原先导样本的保留记录。完整9.1MiB临时expanded JSON留在本地，未重复上传全部方向数组。
- replay_block_original.json保留一个分块的完整原记录，供确定性重放对照。exact_sample_input.json为已审七维记录；selected_exact_historical.json包含两个高维有理输入和原结果。
- 先导阶段共九案，每案16个source及16个独立receiver样本。扩展阶段只对四个冻结模型实施，两个阶段请求14个单线程worker，未为填满CPU添加任务。
- 最终置信推断排除用于选择案例的16点pilot，以及稀疏模型触发扩样的64点pilot。只使用新样本496、496、112、960；不要使用原全样本候选区间代替这一修正。
- 精确整数核验16个二项尾，每尾≤1/320；八个概率区间的联合95%保证条件于选择后新试验为理想iid且事件准确。它不涵盖PRNG、平台扫描与几何浮点误差。
- Arb既记录理想格距的密度，也记录实际binary64格距对应的准确有理密度；二者不能混用。准确事件证书只覆盖列出的舍入输入，不证明原连续模型的积分数值。

## 资源与限界

机器15逻辑核心、24GiB。本轮批量任务请求最多14个进程，BLAS/OMP各1线程。最后阶段墙钟2.140秒；整个扩展各worker累计CPU17.998秒，最大单worker峰值RSS98,238,464字节。两个时间范围不同，不可相除当作并行利用率。第一阶段墙钟及系统CPU采样未保存，不声称持续满载。MATLAB本轮未运行。未编译PDF。

报告的通用解析下界通过独审，但其中新的交叉能量没有共同来源预算；归一化角向常数下界也不能作为捷径。四个有限模型的q已高只决定不继续追求增大发往异常集合的总质量，不能排除有用的几何重加权，更不能证明一般维数阶。完整根阶目标与R559母账仍未闭合。
