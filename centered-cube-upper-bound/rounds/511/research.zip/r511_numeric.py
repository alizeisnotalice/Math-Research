#!/usr/bin/env python3
"""Finite shared-selector periodic grid model, with explicit finite-L1 sandwich."""
from pathlib import Path
from itertools import permutations
from math import factorial,comb
import sys,platform,json,time
from fractions import Fraction as Q
import flint
from flint import arb,ctx
ctx.prec=256
ROOT=Path(__file__).resolve().parent
checks=0

def ck(x):
 global checks
 assert bool(x)
 checks+=1

def aa(q):
 q=Q(q);return arb(q.numerator)/q.denominator

def compositions(n,k,prefix=()):
 if k==1:yield prefix+(n,);return
 for c in range(n+1):yield from compositions(n-c,k-1,prefix+(c,))

def solve(n,ks,q0=Q(1,2),stage="baseline"):
 start=time.perf_counter();K=len(ks);delta=Q(1,100*n)
 base=arb(2).root(n);qpower={Q(1,2):-1,Q(2):1,Q(4):2}[q0]
 Rs=[base**(k-qpower) for k in ks]
 for R in Rs:ck(R>1+2*aa(delta));ck(R<2-2*aa(delta))
 A=[R-1-2*aa(delta) for R in Rs];B=[R-1+2*aa(delta) for R in Rs]
 probs=[A[0]]+[A[i]-B[i-1] for i in range(1,K)]+[1-B[-1]]
 ck(all(p>0 for p in probs));survive=(1-4*K*aa(delta))**n
 ck(sum(probs,arb(0)).contains(1-4*K*aa(delta)))
 powers=[[p**j for j in range(n+1)] for p in probs]
 masks=[arb(0) for i in range(1<<K)];counts=0
 for cs in compositions(n,K+1):
  counts+=1
  den=1
  for c in cs:den*=factorial(c)
  multi=factorial(n)//den
  weight=arb(multi)
  for i,c in enumerate(cs):weight*=powers[i][c]
  cumulative=0;mask=0
  for j in range(K):
   cumulative+=cs[j]
   if cumulative==ks[j]:mask|=1<<j
  masks[mask]+=weight
 ck(counts==comb(n+K,K));ck((sum(masks,arb(0))-survive).contains(0))
 policies=[]
 for priority in permutations(range(K)):
  P=[arb(0) for j in range(K)]
  for mask,p in enumerate(masks):
   for j in priority:
    if mask&(1<<j):P[j]+=p;break
  ck((sum(P,arb(0))-survive+masks[0]).contains(0))
  ell=[aa(q0)*p for p in P];objective=sum((x*x for x in ell),arb(0))
  policies.append((priority,P,ell,objective))
 # Certified max hull; all policies whose interval can still attain max remain contenders.
 maxball=policies[0][3]
 for p in policies[1:]:maxball=maxball.max(p[3])
 contenders=[p for p in policies if not any(z[3]>p[3] for z in policies)]
 ck(len(contenders)>=1)
 chosen=contenders[0]
 if len(contenders)==1:
  for p in policies:
   if p is not chosen:ck(chosen[3]>p[3])
 dominated=[p for p in policies if p not in contenders]
 for p in dominated:ck(any(z[3]>p[3] for z in policies))
 rawtotal=aa(q0)*(survive-masks[0]);ck(rawtotal<1)
 L=1000*n;factor=Q(L-2,L)**n
 ck(factor>=Q(998,1000))
 ck(maxball>0);ck(maxball<aa(q0*q0))
 ck((sum(chosen[1],arb(0))-survive+masks[0]).contains(0))
 def st(x):return x.str(35,radius=True)
 result={'stage':stage,'n':n,'candidate_k':ks,'candidate_count':K,'delta':str(delta),'q0':str(q0),'R_j_arb':[st(R) for R in Rs],'allowed_bin_probabilities_arb':[st(p) for p in probs],'composition_count':counts,'priority_count':len(policies),'survival_probability_exact':str((1-4*K*delta)**n),'survival_probability_arb':st(survive),'surviving_but_no_valid_choice_arb':st(masks[0]),'selected_probability_arb':st(survive-masks[0]),'raw_column_sum_arb':st(rawtotal),'trivial_square_bound_raw_sum_squared_arb':st(rawtotal*rawtotal),'mask_probabilities_arb':{str(i):st(p) for i,p in enumerate(masks)},'certified_max_Q_over_W_periodic_arb':st(maxball),'contending_priorities_k':[[ks[i] for i in p[0]] for p in contenders],'chosen_demonstrated_priority_k':[ks[i] for i in chosen[0]],'chosen_P_j_arb':[st(p) for p in chosen[1]],'chosen_ell_j_arb':[st(p) for p in chosen[2]],'chosen_Q_over_W_arb':st(chosen[3]),'finite_embedding_L':L,'finite_W':str(L**n),'finite_sandwich_lower_factor_exact':str(factor),'finite_chosen_lower_bound_arb':st(aa(factor)*chosen[3]),'finite_periodic_upper_bound_arb':st(chosen[3]),'all_priorities':[{'priority_k':[ks[i] for i in p[0]],'Q_over_W_arb':st(p[3])} for p in policies],'seconds':time.perf_counter()-start}
 print('MODEL',stage,'q',q0,'n',n,'K',K,'compositions',counts,'policies',len(policies),'selected',st(survive-masks[0]),'max',st(maxball),'contenders',len(contenders),flush=True)
 return result

def main():
 start=time.perf_counter();models=[]
 for n,ks in [(4,[0,1,2]),(8,[0,2,4,6]),(16,[2,6,10,14])]:models.append(solve(n,ks))
 for n,ks in [(4,[2,3]),(8,[2,3,5,7]),(16,[3,6,10,14])]:models.append(solve(n,ks,Q(2),'main'))
 models.append(solve(16,[3,6,10,14],Q(4),'density_pressure'))
 out={'scope':'seven finite periodic shared-priority selector models; ungated one-source columns, optional Dstar only dominated; finite L1 sandwich explicit','environment':{'executable':sys.executable,'python':platform.python_version(),'python_flint':flint.__version__,'arb_precision_bits':ctx.prec},'checks':checks,'models':models,'seconds':time.perf_counter()-start}
 (ROOT/'r511_numeric.json').write_text(json.dumps(out,indent=2)+'\n')
 print('PASS',checks,'strict Arb/finite combinatorial checks; no general summability theorem')
if __name__=='__main__':main()
