# R511 主代理：保共同半径的增难变分条件

以下是有限候选族的一般解析命题，不是原问题的根阶预算。μ=f dx≥0，W<∞，原中心域E；每个B有有限非空可测候选集，候选c的R_c(B)、q_c(B)=μQ(B,R_c)/R_c^n、t_c(B)预先固定可测，a≤R_c≤b≤2a，q≤q_c≤λ=rq，0≤t_c≤S。候选层号j(c,B)由m_c=μQ(B,R_c)∈[m_j,γm_j)确定，m_j=qa^nγ^j。r、γ固定，有限层数N。所有半径都属于同一中心B，不能由来源对重新选择。

令α_c(B)≥0，Σ_cα_c(B)=1，仅在合法候选上非零，定义
\[
\ell_j^\alpha(y)=\int_E\sum_{c:j(c,B)=j}\alpha_c(B)t_c(B)R_c(B)^{-n}1_{Q(B,R_c(B))}(y)\,dB,
\qquad Q(\alpha)=\sum_j\|\ell_j^\alpha\|_{L^2(\mu)}^2.
\]
这是允许混合的外扩域；确定性选择器是其中顶点型输入，每个B仅选一个c。改变α时不重新生成候选、层号或原历史。

## 1. 有限性与原几何帽

固定层的所有候选半径落在[(m_j/λ)^(1/n),(γm_j/q)^(1/n)]。对于任意0<l≤h，固定y的中心包络满足
\[
\int_{\mathbb R^n}\sup_{l\le R\le h}R^{-n}1_{Q(B,R)}(y)\,dB=1+n\log(h/l).
\]
证明：令d=2||B−y||∞，d≤l部分积分为1；l<d≤h时最大值d^−n，d的球体积为d^n，壳积分为n∫_l^h ds/s。混合系数和不超过1，故C=S[1+log(γr)]给ℓ_j≤C；对所有层同理有Σ_jℓ_j≤SA_n，A_n=1+nlog(b/a)。因此
\[
Q(\alpha)\le C\int\sum_j\ell_j^\alpha d\mu\le CSA_nW.
\]
这里没有逐候选数量费用。取每B第一个合法候选并令辅助t=1，Tonelli给q|E|≤A_nW，所以E有限测度。W=0或S=0单列零目标。

## 2. 精确最佳响应与有限增难

在当前α下定义真实来源score
\[
\psi_c(B)=t_c(B)R_c(B)^{-n}\int_{Q(B,R_c(B))}\ell_{j(c,B)}^\alpha(y)\,d\mu(y).
\]
它可测且0≤ψ_c≤SCλ。选择使ψ_c最大、按候选索引破同的c'(B)，得到确定性α'。由固定线性算子与平方展开，严格有
\[
Q(\alpha')-Q(\alpha)=2\int_E\left[\max_c\psi_c(B)-\sum_c\alpha_c(B)\psi_c(B)\right]dB
+\sum_j\|\ell_j^{\alpha'}-\ell_j^\alpha\|_2^2\ge0.\tag{BR}
\]
所有积分有限，故换序合法。不要求不同候选的层号相同。

给定η>0、W>0，先无条件做一次最佳响应，确保确定性；然后反复计算Δ=Q(α')−Q(α)。若Δ>ηW则更新，否则保当前确定性α并停止。由于Q≤CSA_nW，大增量更新次数不超过CSA_n/η，初始确定化至多另一次；因而有限步停止，输出Q不低于原输入，并满足
\[
\int_E(\max_c\psi_c-\psi_{c(B)})dB\le\eta W/2,
\qquad\sum_j\|\ell_j^{\alpha'}-\ell_j^\alpha\|_2^2\le\eta W.
\]
这是积分变分必要条件，不是逐中心近最优或全局最大，不保证迭代极限的唯一性。它给研究几何极值的一个合法增难过程：要证明有限候选域的统一raw平方预算，足以控制这些可达的近最佳响应配置。不自动推广到所有连续半径；离散逼近、门与质量分层边界费用尚须证明。

## 3. 原流与X费用

Q增大不意味着R_*或原history单调。本命题仅为原raw平方需求提供更大的辅助目标，不能用新选择器重新评价旧gate。X_α=∫Σα_cq_c dB位于[q|E|,λ|E|]，所以X_out≤rX_in。若未来取得Q_out≤BW+δX_out，只能回推Q_in≤BW+rδX_in，随后仍需支付平方预算到R_*的N层Cauchy/Young费用。纯BW上界无此额外X比较。本轮没有取得BW或δX预算。

## 4. 可复现的固定线性算子代数检查

以下Fraction只验证(BR)代数与增难，不声称其有限数组就是连续立方体几何。连续几何模型由numeric附件另核。三阶段：混合输入初步检查；候选依赖层及稀疏支持检查；扩大至24个确定性种子和4/6个中心。η=1/100，质量W为来源点权和。实际次数见重放记录，不以通过数外推阶数。

```python
from fractions import Fraction as F
from itertools import product
count=0; updates=[]
for seed in range(24):
 bcount=4+2*(seed%2);ccount=3;yc=5;jc=3
 mu=[F(y+1,15) for y in range(yc)];W=sum(mu)
 # Each candidate has its own fixed layer and nonnegative kernel.
 layer=[[ (b+c+seed)%jc for c in range(ccount)] for b in range(bcount)]
 kernel=[[[F((b+2*c+3*y+seed)%7,10) for y in range(yc)] for c in range(ccount)] for b in range(bcount)]
 alpha=[[F(1,ccount)]*ccount for b in range(bcount)]
 def field(a):
  return [[sum(a[b][c]*kernel[b][c][y] for b in range(bcount) for c in range(ccount) if layer[b][c]==j) for y in range(yc)] for j in range(jc)]
 def norm(v):return sum(mu[y]*v[j][y]**2 for j in range(jc) for y in range(yc))
 initial=norm(field(alpha)); steps=0
 for iteration in range(10000):
  ell=field(alpha)
  score=[[sum(mu[y]*kernel[b][c][y]*ell[layer[b][c]][y] for y in range(yc)) for c in range(ccount)] for b in range(bcount)]
  chosen=[max(range(ccount),key=lambda c:score[b][c]) for b in range(bcount)]
  new=[[F(c==chosen[b]) for c in range(ccount)] for b in range(bcount)]
  e2=field(new);delta=norm(e2)-norm(ell)
  gap=sum(max(score[b])-sum(alpha[b][c]*score[b][c] for c in range(ccount)) for b in range(bcount))
  distance=norm([[e2[j][y]-ell[j][y] for y in range(yc)] for j in range(jc)])
  assert delta==2*gap+distance and gap>=0 and distance>=0;count+=1
  if iteration>0 and delta<=W/100:
   assert gap<=W/200 and distance<=W/100 and norm(ell)>=initial;count+=1
   updates.append(steps);break
  alpha=new;steps+=1
 else:raise AssertionError('finite fixture did not stop')
print('PASS',count,'exact shared-selector linear-operator identities and finite stopping checks')
print('updates including initial deterministic choice',updates)
```
