# R511：把实际 K 提升回原父中心，并去掉逆阈值损失

版本 v3：第 6 节新增不稀疏的下降质量转移；第 7 节保留主代理提出、经独立核验的真实小列折扣与可求和 Hardy 率上界。终端仍缺独立来源付款，不与前五节的稀疏 q_j 混算。

本轮在原共享父中心上完成了分数壳 lift。实际归一因子可用 θ_j(y)≥(m_j/C)(ℓ_j(y)−u/2) 控制，因而列估计中不必付 1/u。由此得到 K≤L+E，且误差具有准确预算 ∫E dμ≤γuν(E)≤γuSX。但主要项 L 尚无独立 W 预算；其总质量的精确恒等式表明，只依靠分数壳保行和质量带宽，不能获得统一严格收缩。本文不声称完成 H=∫K 的 polylog(n)W 上界。

## 1. 合同、对象与旧流边界

沿 R510 固定 r=λ/q、S，μ=f dx≥0，W<∞，a≤R_B≤b≤2a，m_B=μQ_B=q_BR_B^n，q≤q_B≤λ，dν=tq_BdB，0≤t≤S。原质量层 E_j 满足 m_j≤m_B<γm_j，γ>1 固定，各 E_j 互斥。记

    ℓ_j(y)=∫_{E_j}t(B)R_B^(−n)1_{Q_B}(y)dB,
    A_j(y,z)=∫_{E_j}t(B)R_B^(−n)1_{Q_B}(y)1_{Q_B}(z)dB,
    C=S[1+log(γr)],   p_j=A_j/C.

取 0<u≤C，H_j={ℓ_j≥u}。按 h=ceil(log_γ(1+2γC/u)) 个模类分层；同一模类依质量递增，令 P_{<j}=Σ_{i<j}p_i，

    q_j=(p_j−P_{<j})_+,
    θ_j(y)=∫q_j(y,z)μ(dz).

这里 q_j 是 R510 分数壳核，与密度下界 q 不同。目标高列平方需求及其准确来源列为

    H=Σ_j∫_{H_j}ℓ_j(y)^2 μ(dy)=∫K(z)μ(dz),
    K(z)=Σ_j∫_{H_j}ℓ_j(y)^2 q_j(y,z)/θ_j(y) μ(dy).       (1)

原 D_* 有历史的内来源列 F_j≤2ℓ_j；故这是一个合法的上包络平方问题。A_j 不是原有历史接受流的相对保留量；下面 lift 保留原父中心与来源支持，却不会赋予这个辅助分配新的旧 gate 资格，也不重新运行历史。

## 2. 更强的实际 θ 下界

定义原父质量加权因子及被分数壳删除的行质量：

    b_j(y)= [∫_{E_j}t(B)R_B^(−n)1_{Q_B}(y)(m_B/m_j)dB]/ℓ_j(y),
    d_j(y)=∫min(p_j(y,z),P_{<j}(y,z))μ(dz),
    δ_j(y)=C d_j(y)/m_j.

在 ℓ_j(y)>0 上，1≤b_j(y)≤γ；并且由实际模类间距，

    0≤δ_j(y)≤u/2,
    θ_j(y)=(m_j/C)[b_j(y)ℓ_j(y)−δ_j(y)].                (2)

这比仅记录 θ_j≥um_j/(2C) 多保留了原 ℓ_j。于是 H_j 上

    θ_j(y)≥(m_j/C)[ℓ_j(y)−u/2],
    ℓ_j(y)^2/θ_j(y)
       ≤(C/m_j)·ℓ_j(y)^2/[ℓ_j(y)−u/2]
       ≤(C/m_j)[ℓ_j(y)+u].                             (3)

最后一步等价于 u(ℓ_j−u)/2≥0。它完全去掉原粗列估计中的显式逆阈值 1/u。

## 3. 保原父中心的准确 lift 与小误差预算

令 α_j(y,z)=q_j(y,z)/p_j(y,z)（p_j=0 时取 0），则 0≤α_j≤1、α_j 对称，且

    q_j(y,z)=(1/C)∫_{E_j}t(B)R_B^(−n)
                      1_{Q_B}(y)1_{Q_B}(z)α_j(y,z)dB.  (4)

这是准确 lift，不把不同 pair 的 R_B 重新优化；对给定 j,y,z，α_j 作为同一因子乘在所有原父中心上。也没有以扩大盒代替 Q_B。

由 (3)–(4) 得 K(z)≤L(z)+E(z)，其中

    L(z)=Σ_j (1/m_j)∫_{E_j}t(B)R_B^(−n)1_{Q_B}(z)
                 ·∫_{Q_B∩H_j}ℓ_j(y)α_j(y,z)μ(dy)dB,
    E(z)=Σ_j (u/m_j)∫_{E_j}t(B)R_B^(−n)1_{Q_B}(z)
                 ·∫_{Q_B∩H_j}α_j(y,z)μ(dy)dB.           (5)

小误差可用真实父质量立即结算，而非使用放大盒上帽：

    0≤E(z)≤γuΣ_jℓ_j(z),
    ∫E dμ≤γuν(E)≤γuSX.                                (6)

因此本轮获得的实际分解是

    H≤∫L dμ+γuSX.                                     (7)

式 (6) 是一个可明确进入全账的 X 型误差，不是独立 W 费用；还必须配合 ∫L 的新来源付款，才可能关闭完整目标。若后续得到 ∫L≤B_{r,S}(n)W，则以 N=O_r(n) 和原 F_j≤2ℓ_j，可把低列项及 (6) 合并，经 Cauchy–Schwarz/Young 得

    R_*≤εX+[(1+γ)NuS/ε]W+2√(N B_{r,S}(n))W.

选择 u≈n^(−1/2) 只使已知 X 型误差所对应的 W 项达到根阶；B_{r,S}(n) 的 polylog 预算仍是未证部分。不得从该条件式宣布根阶目标完成。

## 4. 主要项的精确质量与为什么还没有收缩

由 (4)，主要项也可写成

    L(z)=CΣ_j(1/m_j)∫_{H_j}ℓ_j(y)q_j(y,z)μ(dy).

因此结合 (2)，其总质量有准确恒等式

    ∫L dμ
      =Σ_j∫_{H_j}[b_j(y)ℓ_j(y)^2−δ_j(y)ℓ_j(y)]μ(dy)
      =H+Σ_j∫_{H_j}(b_j−1)ℓ_j²dμ
           −Σ_j∫_{H_j}δ_jℓ_jdμ.                       (8)

记 R_H=Σ_j∫_{H_j}ℓ_jdμ≤ν(E)。目前仅可推出

    H−(u/2)R_H≤∫L dμ≤γH.                              (9)

这定位了严格收缩所缺的东西：保行所用稀疏层距只保证删除校正不超过 (u/2)R_H；它没有给出该校正占 H 的正比例下界。质量分层因子 b_j−1 反而非负。把 γ 缩到 1 附近只能减小正误差，不能自动产生负的统一收缩系数。对 ℓ_j远大于u 的行，(9) 显示本次 lift 的主质量几乎完整保留。

主要项仍具有可供后续使用的原父后验公式：

    ∫L dμ=Σ_j∫_{E_j}dν(B)(m_B/m_j)
          ·E_{π_B⊗π_B}[1_{H_j}(Y)ℓ_j(Y)α_j(Y,Z)].       (10)

这里两个分母已准确回到原 π_B⊗π_B；因子 m_B/m_j∈[1,γ] 保留。式 (10) 可接受真正针对原共享父/两来源的几何付款，但仅用 α_j≤1 就回到 (9) 的 γH，仍然循环。它不提供原历史 gate 的相对保留结论。

R510 的前缀几何约束

    Σ_{j≤J}m_jq_j(y,z)≤(Sλ/C)∏_k(ρ_J−|y_k−z_k|)_+

仍合法，但本轮没有找到将它与 (5)/(10) 的原中心质量同时积分为一次 W 的办法。先把前缀右边对 μ 积分会重新产生无上帽的扩大盒质量；本文没有使用这一步。

## 5. 最小实际检查

使用本机 `/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python -I`，SymPy 1.14.0 实跑 81 组有理参数的四项系数关系，以及一个真实连续一维模型的两个精确积分，共 326 个断言。

连续模型为 μ=1_[−1,2]dx，原中心 E=[0,1]，全部 R_B=2，q_B=t=1，单一质量层 m_j=2、m_B=2。其来源列

    ℓ(y)=(y+1)/2  (−1≤y≤0),
    ℓ(y)=1/2      (0≤y≤1),
    ℓ(y)=(2−y)/2  (1≤y≤2).

取 u=1/4，则 H_j=[−1/2,3/2]，高列平方质量 H=19/48，高列线性质量 R_H=7/8。没有前层时 α=1、δ=0、b=1，故主要项准确为 ∫L=H；这核查实际 lift 的恒等式及“系数改善不等于严格收缩”，不是对一般目标的反例。

```python
from fractions import Fraction as F
import sympy as s
count=0
for u in (F(1,16),F(1,4),F(1)):
 for ell in (u,2*u,7*u):
  for b in (F(1),F(9,8),F(3,2)):
   for r in (F(0),u/4,u/2):
    theta=b*ell-r
    assert theta>=ell-u/2>0
    assert ell*ell/theta<=ell+u
    L=ell*theta
    assert ell*ell-u*ell/2<=L<=b*ell*ell
    assert L==ell*ell+(b-1)*ell*ell-r*ell
    count+=4
x=s.symbols('x',real=True)
H=2*s.integrate(((x+1)/2)**2,(x,-s.Rational(1,2),0))+s.Rational(1,4)
R=2*s.integrate((x+1)/2,(x,-s.Rational(1,2),0))+s.Rational(1,2)
assert H==s.Rational(19,48);assert R==s.Rational(7,8);count+=2
print('PASS',count,'exact lift coefficient and continuous one-layer checks; SymPy',s.__version__)
print('continuous model high-square mass=',H,' high linear mass=',R,' lifted main mass=',H)
```

停止界限：本轮实际改善了归一列的系数，并得到 (6) 的小参数 X 型误差；未取得主要项 L 的非循环来源预算，也未证明 H 的 polylog(n)W 上界。后续应针对 (10) 的原父、两来源与 α_j 的联合结构付款，而不是再次用上帽或质量守恒估计它。

## 6. v2：细层重叠向较小原质量层转移的精确递推

这是针对主代理建议额外推演的一条替代机制。重新取固定质量层比 γ>2（例如 γ=4），不作随 u 变化的稀疏化；原真实中心仍互斥，父 R_B 不变。以下以帽号区分新的密集层分数壳与前文稀疏 q_j。

固定原 pair (y,z)，记 P_{<j}=Σ_{i<j}p_i(y,z)，

    b̂_j=min(p_j,P_{<j}),    q̂_j=p_j−b̂_j.

p_j 原行质量 s_j(y)=∫p_j(y,z)μ(dz)≥m_jℓ_j(y)/C。把该层高列平方需求准确注入 p_j，注入率为

    w_j(y)=1_{H_j}(y)ℓ_j(y)^2/s_j(y)≤C²/m_j.

零行取 w_j=0。按质量从大到小定义实际 pair 系数

    r_i(y,z)=w_i(y)+Σ_{j>i} r_j(y,z)b̂_j(y,z)/P_{<j}(y,z),     (11)

P_{<j}=0 的商取 0。一个处于 j 层、密度为 r_jp_j 的记录，其中 r_jq̂_j 终止；其余 r_jb̂_j 按 p_i/P_{<j} 的概率送到 i<j。因此每个记录只选择一个较小层，质量严格下降，没有同一记录被送给所有父层的重复计数。有限层 DAG 的准确守恒式为

    Σ_j w_j(y)p_j(y,z)=Σ_i r_i(y,z)q̂_i(y,z).             (12)

如需携带原中心，p_i 的中心条件分布由原 A_i 的积分核给出；转移时保留原来源 y,z、原高层中心及全部旧标签，再附加一个低层辅助中心。它是 bookkeeping lift，不能在低层中心重新评价旧历史，也不能把它称为原 gate 的真实再生过程。

式 (11) 的多父输入有一个独立层数的实际系数帽。令

    D=C²(γ−1)/(γ−2).

利用 b̂_j/P_{<j}≤1 和几何质量增长，逆向归纳得

    r_i≤C²/m_i+DΣ_{j>i}1/m_j
       ≤[C²+D/(γ−1)]/m_i=D/m_i.                         (13)

因此 γ=4 时 D=3C²/2，所有下降路径及多父输入均已计入，无需再乘层数。γ=2 时这个粗归纳没有严格余量，不能直接使用 (13)；可以采用固定 γ=4 的原质量分层，也可对 γ=2 的层作两个固定模类分别执行，并保留两个类的费用。

新的终端来源列为

    K_term(z)=Σ_i∫r_i(y,z)q̂_i(y,z)μ(dy),
    ∫K_term dμ=H,
    K_term(z)≤DΣ_i(1/m_i)∫q̂_i(y,z)μ(dy).               (14)

这是一条真实质量下降、没有流量放大的递推；但 (14) 右边仍没有独立 W 预算。逐 pair 的 Σq̂_i≤1 不允许丢掉各层 1/m_i，终端不再转移也不等于终端免费。用现有原行帽只能把 (14) 估成原接收量的常数倍，因此没有闭合根阶目标。

在原共享中心结构下，R510 的前缀 (PK) 也适用于 q̂_i；它可作为继续估计 (14) 的几何输入。本轮没有进一步得到其一次来源费用，故不继续展开路径或增加新的未付分支。

本机 Fraction 实跑下面三个有限核列表，12 个断言验证 (12)、逐 pair 壳 packing、(13) 和非负性。这些只核代数机制；一般公式由上述有限递推证明，且不把抽象核测试当作原几何付款。

```python
from fractions import Fraction as F
cases=[list(map(F,['1/8','1/4','1/2','1'])),
       list(map(F,['1','1/2','1/4','1/8'])),
       list(map(F,['0','1/3','0','2/3','1']))]
gamma=F(4);D=(gamma-1)/(gamma-2)
for p in cases:
 n=len(p);m=[gamma**i for i in range(n)];w=[F(1)/x for x in m]
 P=[sum(p[:j],F(0)) for j in range(n)]
 b=[min(p[j],P[j]) for j in range(n)];q=[p[j]-b[j] for j in range(n)]
 rate=[F(0)]*n
 for i in range(n-1,-1,-1):
  rate[i]=w[i]+sum((rate[j]*b[j]/P[j] if P[j] else F(0))
                   for j in range(i+1,n))
 assert sum(w[j]*p[j] for j in range(n))==sum(rate[j]*q[j] for j in range(n))
 assert sum(q)<=1
 assert all(rate[j]<=D/m[j] for j in range(n))
 assert all(x>=0 for x in q)
print('PASS 12 exact dense-transfer conservation, shell-packing and coefficient-cap assertions')
```

v2 最终界限：去逆阈值 lift 的小误差 (6) 已明确；下降质量递推 (11)–(13) 也已守恒并控制多父输入。独立来源费用仍集中在 (14) 的终端归一列，未获 polylog(n)W 付款。完整目标保持未完成。

## 7. v3：保留真实小列折扣的 Hardy 收费结构

第 6 节的统一 C²/m_i 帽可以进一步改进，不能把舍弃所有小 ℓ 的粗终端帽误当作唯一目标。令 e_j(y)=ℓ_j(y)1_{H_j}(y)。原注入率保有

    w_j(y)≤C e_j(y)/m_j.

只用 b̂_j/P_{<j}≤1，(11) 的有限倒推给出

    r_i≤w_i+Σ_{k≥1}2^(k−1)w_{i+k}
       ≤(C/m_i) E_i(y),
    E_i(y)=e_i(y)+(1/γ)Σ_{k≥1}(2/γ)^(k−1)e_{i+k}(y).    (15)

这里 2^(k−1) 是从层 i+k 到 i 的所有严格下降中间层子集数；它已包括多父输入，并非另行增加路径计费。有限层之外 e_j=0。

对 γ>2，卷积系数非负且总和

    κ_γ=1+1/(γ−2)=(γ−1)/(γ−2).

因此在每个固定真实来源 y 上，离散 Young 不等式给出

    [Σ_iE_i(y)²]^(1/2)≤κ_γ[Σ_je_j(y)²]^(1/2).         (16)

这保留了小列平方收益；γ=4 时 κ_γ=3/2。更准确的终端收费结构应保留为

    K_term(z)≤CΣ_i(1/m_i)∫E_i(y)q̂_i(y,z)μ(dy).        (17)

原中心 lift 可继续用于 (17) 的 q̂_i，pair 与全部原父半径仍一致。不能先把 E_i 换成 κ_γ C 后，反过来要求那个更强粗核有独立来源预算。

目前 (16) 不是新 W 收据，因为其右边积分正是未付高列平方量 H。若直接积分 (17)，再仅用 ∫q̂_i(y,z)μ(dz)≤γm_iℓ_i(y)/C，会回到 γΣ∫E_iℓ_i dμ，仍是原列能量的双线性项。它的常数不小于 1，因此没有严格收缩。仍需保 (17) 中的真实 q̂_i 与原共享中心几何，证明独立来源付款；本轮没有完成这一步。

独立使用本机 Fraction，对 γ=3,4,8 及三个有限列序列实跑 18 个精确断言，检查最坏倒推系数与 (16)。一般 (15) 来自有限递推归纳，(16) 来自可求和卷积；有限检查不替代来源预算。

```python
from fractions import Fraction as F
count=0
for gamma in (F(3),F(4),F(8)):
 for ell in ([F(1),F(1,2),F(1,4),F(1,8)],
             [F(0),F(1),F(0),F(1)],[F(1,10)]*7):
  n=len(ell);w=[ell[i]/gamma**i for i in range(n)];rates=[F(0)]*n
  for i in range(n-1,-1,-1):rates[i]=w[i]+sum(rates[i+1:])
  E=[ell[i]+sum(F(2)**(k-1)/gamma**k*ell[i+k]
               for k in range(1,n-i)) for i in range(n)]
  assert all(rates[i]==E[i]/gamma**i for i in range(n));count+=1
  kappa=(gamma-1)/(gamma-2)
  assert sum(x*x for x in E)<=kappa*kappa*sum(x*x for x in ell);count+=1
print('PASS',count,'exact descending-path coefficients and Hardy sequence bounds')
```

v3 最终交付：实际去 1/u 的原父 lift 与可付小误差；守恒、严格下降质量且控制多父输入的层转移；保小列折扣的 Hardy 终端结构 (17)。独立来源预算仍未证，完整根阶目标未完成。
