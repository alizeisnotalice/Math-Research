# Independent rational owner certificate

Scope: actual receiver and packing incidence for the specified finite successor model, under the stated incoming-capture eligibility assumption. It does not construct an old AC KKT source or Euler realization, and does not establish a calibrated, old near-score, or general root bound. The computation does not invoke or depend on a numerical optimization solver.

## Simplex profiles

The independent script rebuilds old-tag image intervals and full receivers from geometry, enumerates every arrangement atom, calculates capture eligibility from all incoming old intervals, retains fill, reserves δ=1/100 baseline, and distributes each free atom equally among the eligible labels with maximum m. It checks exact individual rational p and group p values against every record: all 2+4+16 branches for r=1,2,4 and the four specified r=8 patterns. The r=8 patterns are not a complete Euler expectation. Every actual expanded C shares a positive common interval, so the full packing constraint is ∑α≤1.

For each case the script brackets the unique root of ∑ ε p_j/(ν−m_j)=1 on ν>max_j m_j using 100 exact Fraction bisections; all bounds and corresponding Q′=ν−εW bounds are in JSON. Strict decrease and endpoint signs certify each root. For this common-simplex problem, α_j=εp_j/(ν−m_j); the free marginal price p_j/(m_j α_j)=(ν−m_j)/(εm_j) is strictly decreasing in m_j. The chosen allocation is therefore KKT-feasible, including exact baseline, ties, and fill. This is an exact argument, distinct from prior solver residuals. For the same-sign r=2 event ν=64 exactly, W=3/4, Q′=68/5.

## Non-simplex actual receiver certificate

With C=[[-2,2],[-3/2,3/2],[7/4,47/4]], a=32, the script derives B=[[-1/16,1/16],[-3/64,3/64],[211/32,221/32]] and enumerates all four positive-length B atoms: left tail [−1/16,−3/64] with owner 1 only; shared [−3/64,3/64] with owners 1,2; right tail [3/64,1/16] with owner 1 only; [211/32,221/32] with owner 3 only. Since E=B there is no fill; both shared rows are assumed capture eligible. All receiver atoms are included, total W=7/16. Cube incidence has precisely maximal positive-length cells {1,2} and {1,3}, so packing is α1+α2≤1 and α1+α3≤1; singleton cells are redundant.

For ε=1 and δ=1/100, allocating all free shared atom to row 2 gives p=(203/6400,597/6400,5/16). Set α=(a,1−a,1−a), with a the unique root in (1/10000,1/100) of p1/a−(p2+p3)/(1−a)=9. Its derivative is strictly negative. Exact 100-step rational bisection brackets that root, and this bracket lies within the author's 80-step bracket; both author endpoint signs were checked. Set positive packing multipliers μ12=3+p2/(1−a), μ13=10+p3/(1−a). By the root equation all three stationarity conditions m_j+p_j/α_j=(μ12+μ13,μ12,μ13)_j hold, and both packing constraints bind. The strict rational inequality p1/(4a)>p2/(3(1−a)) throughout the bracket proves the shared free allocation chooses row 2, despite m2=3<m1=4. The convex relative entropy formulation and these KKT conditions certify a global solution. It is a finite specified successor model, not a proof that these intervals arise from an old KKT Euler action.

## Implicit deficit, exact branch

Conditionally on the proposed first-order/dual inequality with P=16, d=P−Q′, and σ_j=ω(C_j)−m_j≥0, the same-sign r=2 case has σ_outer=8, σ_center=0, p_outer=1/4, ε=336/5 and W=3/4. Thus

    d ≥ (672/5)/(292/5−d),  0≤d≤16.

The denominator is at least 212/5>0 on this entire domain. Multiplication gives (d−12/5)(d−56)≤0, whose intersection with [0,16] is [12/5,16]. Hence d≥12/5, and the exact simplex optimum gives d=16−68/5=12/5. The second algebraic root 56 is outside the physical domain. This arithmetic validates this instance conditional on the stated general inequality; it does not independently prove that inequality in every geometry.

## Reproduction and hashes

Ran `/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/ccu_r656/numeric/verify_owner_certificate.py > /tmp/ccu_r656/numeric/verify_owner_certificate.json`, Python 3.12.14, standard-library Fraction, no CVXPY. The verifier reads the sibling author JSON and compares exactly; it reconstructs geometry and KKT itself.

SHA-256:
- `owner_profile.py` 0381e5c56986d241ca2b2c67a2ad164197824707ab02d3016534a559e6953f84
- `owner_profile.json` 33c182441ba284b23d8fdd263989051d02302af894b16c31732fce6dfaf2abdc
- `owner_profile.md` a03ee557a0ded5ec6addfca75aff0f18bdc876291eda7a59bd1050e8a26b7b3f
- `verify_owner_certificate.py` d1614ed2c510144de48a2991fd95bfde30f3836aa30c700ed643c7d86d08370b
- `verify_owner_certificate.json` f8879496d63439fdd8af9f87afbc88144406be27ba2470e1db822596621452f8


## Local and global iterations in separated copies

The actual C union lies in [−2,47/4] and its translate lies in [98,447/4]; they are disjoint, as are the two actual B unions. Thus the owner objective and feasible packing constraints factor by component, giving additive optimal Q′ and deficit; this does not construct or replicate an old source budget. In one component the LP bound 4α1+3α2+10α3≤13−9α1 follows from the two packing inequalities, and (0,1,1) attains P=13. Dual cell prices (3,10) give σ=(9,0,0). The positive-overlap C-neighborhood of row 1 consists of all three rows, so P_N=13 and W_N=|B1∪B2∪B3|=7/16. For two copies P=26 and W=7/8, while each relevant neighborhood has the same P_N,W_N. Its forced baseline and exclusive atoms imply p1≥203/6400, attained at the certified optimizer.

Independently recomputed all k=1,2,4,8 iterates for both global and local formulas in Fraction arithmetic and compared exactly with all author entries. Each iterate is strictly less than the lower endpoint of the independently certified actual deficit bracket [9n·a_lo,9n·a_hi], n=1,2. Thus the result is rigorous without relying on the rounded outputs: for n=2, global k=8 is approximately 0.02498631, neighborhood k=8 approximately 0.06049669, and actual deficit approximately 0.06069184. First iterates are 1827/60400 (one copy), 609/24400 (two, global), and 1827/30200 (two, local). These are conditional numerical instances of the supplied neighborhood inequality, not a proof of that inequality or of a shared original source budget.


## Independent selector comparison

The exact feasible free allocation of the shared atom produces p1∈[203/6400,797/6400], p2=1/8−p1, p3=5/16. All three owners remain strictly positive, including endpoint minimum p2=3/6400. For each p1, g(x)=p1/x−(W−p1)/(1−x)−9 is strictly decreasing from +∞ to −∞ on (0,1), giving a unique x. The two positive packing multipliers and stationarity described above certify α=(x,1−x,1−x) for every feasible p1. Equivalently p1=x[W+9(1−x)]; its relevant small root lies in (0,1), while the other quadratic root lies above 1. Since ∂g/∂p1>0 and ∂g/∂x<0, x strictly increases with p1; Q′=13−9x strictly decreases. Hence min Q′ selects the upper endpoint, whereas joint B selects the lower endpoint by the already certified strict shared free-price inequality.

Independent 110-step Fraction root brackets at both endpoints are inside the author's 100-step brackets, with strict endpoint signs. The resulting exact Q_B−Q_min interval is in the verifier JSON and lies strictly within (899/10000,9/100), proving positivity without floating-point certification. With common W and fixed R>0, D_minQ−D_B=R(Q_B−Q_min)>0. This is a conditional finite successor selector comparison, under the stated capture eligibility, with no old-state realization or claim of a general bound. No CVXPY was run.

Selector artifact SHA-256: script `20465ef28bd36b1dae5133c94c4468a9bcd476c01f4c3d6d75fed45f56dfe94a`; JSON `b74f8436c500792f5283736ed13e033c7701882fab8c01003dc81f018897ea48`; report `18acfbc4694e551caf3a002aeff0b4f18e9b76502a4aa5f4c10274d58b2cd99a`. Final verifier hashes in the reproduction section above supersede earlier versions.


## Global selector-support iteration

Independently iterated F(d)=9p1/(151/16−d), starting at zero, for both endpoint allocations p1=203/6400 and 797/6400. The k=1,2,4,8 exact Fraction values match all entries under `global_support_iterations` in the updated selector JSON; all are strictly below the lower endpoint of the corresponding independently certified 110-step actual-deficit bracket 9x. This is the global bound for the single component; the specified neighborhood MAX instance is separately checked below. The verifier also explicitly asserts the previously reported rational Q-gap bounds 899/10000 and 9/100.


## Neighborhood MAX in the specified finite instance

For each of one and two separated components, independently recomputed the exact iterations with p1,max=797/6400 and denominator min(P+W−4−d, P_N+W_N−4), P_N=13 and W_N=7/16. All k=1,2,4,8 fractions match the author JSON and lie strictly below the corresponding lower 110-step rational bracket for the true fixed-selector deficit 9n·x_high. For two copies all four iterates equal 7173/30200; the true deficit is 18x_high. This replaces the previous scope limitation that neighborhood MAX had not been checked for this specified instance. It is not an independent audit of the general neighborhood theorem, an old-source realization, or a shared source budget. No CVXPY was run.
