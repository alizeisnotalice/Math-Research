# TASK_NUM_PARTITION_DESIGN — atomic partition diagnostic

Use the R655 frozen n=1 atomic source and objective/eligibility definitions, including R=15/272, ε=336/5, entropy mixture δ=1/100, old source labels, λ/r, and unchanged m and u. The source is the same uncalibrated atomic-limit toy used in R655, not a positive-width example. For r clones per row, old I=[y−1/32,y+1/32] is cut into kr equal cells; k=1 gives contiguous pieces, k>1 colors cells cyclically by clone index. Each clone receives exactly k cells and 1/r of the old interval volume. Anchor draws are independent and all 2^r central ±1 tuples are evaluated with equal weights; the outer anchors remain fixed at −1 and +1. Each actual clone image E is the union of the images of its cells. Its receiver B and C do not depend on the partition. Exact Fraction endpoints form the combined E/B arrangement. On each atom incoming clone labels and full eligibility are recomputed, with fill and deleted old rows retained. The common-intersection packing constraint and joint owner/entropy program are re-solved per tuple. No source density, Poisson approximation, or W-only proxy is introduced.

| r | partition cells per row | tuples | E W (exact) | E Q′ numerical | E D numerical |
|---:|---:|---:|---:|---:|---:|
| 2 | contiguous | 4 | 7/8 | 13.881659839 | 0.109467288 |
| 2 | 4 cyclic | 4 | 7/8 | 13.884071661 | 0.109334283 |
| 2 | 8 cyclic | 4 | 7/8 | 13.884071227 | 0.109334307 |
| 2 | 16 cyclic | 4 | 7/8 | 13.884071661 | 0.109334283 |
| 4 | contiguous | 16 | 31/32 | 14.095919420 | 0.191401503 |
| 4 | 8 cyclic | 16 | 31/32 | 14.097124193 | 0.191335063 |
| 4 | 32 cyclic | 16 | 31/32 | 14.097124810 | 0.191335029 |

Exact eligibility allocations change in the r=2 comparisons, justifying r=4 follow-up. As one example, r=2 center tags (−1,+1) give D≈0.186552525 contiguous and D≈0.218668480 with 4 cyclic cells; opposite tags (+1,−1) give D≈0.251316454 contiguous and D≈0.218668480 with 4 cyclic cells. The full expectation changes far less than individual branches: 4-cell cyclic minus contiguous gives ΔE D≈−0.000133005, and for r=4 8-cell cyclic gives ΔE D≈−0.000066440. Their corresponding E Q′ differences are ≈+0.002411822 and +0.001204773. These are solver-dependent numerical observations, not certified strict sign results; they indicate no improvement if the aim is to increase D. Other directions or partitions are not ruled out.

All r=2 solves were `optimal`; r=4 contiguous and 8 cyclic had 15 `optimal` and 1 `optimal_inaccurate`, 32 cyclic had 14 and 2. Across all runs maximum α-stationarity residual is 1.36e−5, owner conservation 8.46e−13, free price residual 3.78e−7, packing positive residual 0, and absolute ledger residual below 9e−17. Residuals are not error bounds on D. Exact eligibility sets and lengths, per-branch p, q, α, Q′, D and solver residuals are recorded in partition_design.json. This does not prove a strict difference or a valid positive-width AC construction, and does not establish general partition effects.

Full replay: from the directory containing the archived scripts, run `python partition_design.py` with NumPy, CVXPY and Clarabel installed. It reads only the definitions from the adjacent `r655_clone_probe.py` and does not rerun the source scan. The original run used `/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python`. After the path-only change, syntax, helper imports and the original helper SHA-256 were verified; the full optimization was not rerun. Python, NumPy, CVXPY and Clarabel versions and elapsed time are recorded in the JSON. One process, OpenBLAS and OMP set to one thread.

SHA-256: partition_design.py `78092cbd182f163c32db127debcddf9b432381dafedd5008a2add53dfb6df2ff`; partition_design.json `119c3b627156c0f95fd158ee4fe1e7ddceb4daa547e1a2710fb99edffd2a6c05`; copied r655_clone_probe.py (identical to original clone_probe.py) `30dff4fadb5abadb8ce197bf348bb1eb1dcdd30b496bbb43c3a10207c1e340f4`.
