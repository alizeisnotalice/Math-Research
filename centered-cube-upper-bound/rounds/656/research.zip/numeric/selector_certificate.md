# R656 owner selector comparison

In the previously specified non-simplex successor fixture, use the genuine a=32 receivers and the same assumed capture eligibility. The atoms have row-1-exclusive volume 1/32, shared eligible volume 3/32, row-3-exclusive volume 5/16, and total W=7/16. With δ=1/100, the shared baseline gives 3/6400 to each of rows 1 and 2. The remaining 99/100 of the shared atom may be assigned freely, so the exact feasible range is

`p1 in [1/32+3/6400, 1/32+3/6400+(99/100)(3/32)] = [203/6400,797/6400]`,

with `p2=1/8−p1` and `p3=5/16`. This derives the end points from the real receiver atoms and retains the exclusive parts.

For every feasible p, the actual entropy optimizer has both packing-cell constraints active, `alpha=(x,1−x,1−x)`, where the unique `x in (0,1)` solves

`p1/x−(W−p1)/(1−x)=9`, and `Q(p)=13−9x`.

The two cell multipliers are `3+p2/(1−x)>0` and `10+p3/(1−x)>0`; stationarity and concavity prove this is the actual fixed-p entropy optimizer. The root function is strictly decreasing in x and strictly increasing in p1, so x increases strictly with p1, and Q strictly decreases. Therefore directly minimizing Q over the actual Pδ selects `p1=797/6400`.

The previously certified joint-B solution has `p1=203/6400`: at that point the actual free price of row 1 strictly exceeds row 2's, so all shared free mass goes to row 2. Fraction bisection with 100 steps yields the exact endpoint brackets recorded in the JSON; rounded decimal values are:

| selector | p1 | x | actual Q′ |
|---|---:|---:|---:|
| joint B | 203/6400 | 0.00337176894649 | 12.96965407948 |
| direct min Q | 797/6400 | 0.01336572540834 | 12.87970847132 |

For the same W and any fixed `R>0`, replacing the joint-B owner by the min-Q owner increases `D=W−RQ′` by the strictly positive amount

`R(Q_B−Q_min)`, with `Q_B−Q_min≈0.08994560816`.

This is a receiver/packing selector decision under the stated eligibility and fixed R; the fixture has not been realized as a genuine old KKT source or a near-score state. The result does not establish the theorem or an improvement on every actual Euler action.

Reproduce without CVXPY: `/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/ccu_r656/numeric/selector_certificate.py > /tmp/ccu_r656/numeric/selector_certificate.json`. The script uses Python 3.12.14 Fraction arithmetic; source SHA-256 `20465ef28bd36b1dae5133c94c4468a9bcd476c01f4c3d6d75fed45f56dfe94a`, JSON SHA-256 `b74f8436c500792f5283736ed13e033c7701882fab8c01003dc81f018897ea48`.

## Global support iteration: MIN versus MAX

Here `P=13`, `W=7/16`, `epsilon=1`, and the only positive row slack is `sigma1=9`. For a fixed owner p, the global deficit bound is

`f_p(t)=9p1/(151/16−t)`.

This increases strictly with p1, so the MIN and MAX over the real owner polytope occur respectively at `203/6400` and `797/6400`. Starting at `d0=0`, Fraction arithmetic gives:

| k | MIN iteration (p1 low) | MAX iteration (p1 high) |
|---:|---:|---:|
| 1 | 0.03024834437086093 | 0.11875827814569537 |
| 2 | 0.030345605757148036 | 0.12027173661992850 |
| 4 | 0.030345920515093563 | 0.12029152537602494 |
| 8 | 0.03034592051836897 | 0.12029152867507122 |

The exact rational iterates are stored in `global_support_iterations` in the JSON. Each is strictly below the lower rational bracket of its corresponding true KKT deficit: approximately 0.03034592051837 for MIN and 0.12029152867507 for MAX. The MAX limit here equals the actual min-Q deficit; rounded displays are not the certificate.

For the stated general global argument, if `d(p)>=f_p(d(p))`, `d(p)<=d*=max_p d(p)<=epsilon W`, each `f_p` is convex, and `f_p(epsilon W)<=epsilon W`, its chord between `d(p)` and `epsilon W` gives `f_p(d*)<=d*`. Therefore the MAX support map also satisfies `F_max(d*)<=d*`, and its increasing iteration from zero gives lower bounds. This calculation does not establish those premises for every setting, and the following separate neighborhood check uses the additionally supplied local-mass premise.

## Neighborhood MAX on separated copies

Under the separately supplied and independently audited premise `nu(C_j)<=P_Nj` for the optimal AC dual, the uncapped local coefficient is at most one. For the same component and its copy translated by 100, `P_N1=13`, `W_N1=7/16`, and the maximum eligible row-1 volume is `p1=797/6400` per component. The actual receiver sets and their unions are fixed as p varies. For n=1,2 separated components the neighborhood MAX map is

`F_N,max(d)=9n(797/6400)/min(13n+7n/16−4−d,151/16)`.

The exact Fraction iterates, starting from zero, are included under `neighbor_MAX_iterations` in the JSON. Their rounded values are:

| components | k=1 | k=2 | k=4 | k=8 | actual maximum deficit |
|---:|---:|---:|---:|---:|---:|
| 1 | 0.11875827814569537 | 0.12027173661992850 | 0.12029152537602494 | 0.12029152867507122 | 0.12029152867507131 |
| 2 | 0.23751655629139073 | 0.23751655629139073 | 0.23751655629139073 | 0.23751655629139073 | 0.24058305735014263 |

The first iterates are respectively the exact fractions `7173/60400` and `7173/30200`. Every iterate is checked strictly below `9n` times the lower rational bracket for the actual high-p1 KKT root. This is a finite witness for the supplied neighborhood theorem, not a separate proof of its AC dual premise or an old near-score construction.
