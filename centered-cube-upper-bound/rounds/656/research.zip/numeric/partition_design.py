import os
os.environ['OPENBLAS_NUM_THREADS']='1'; os.environ['OMP_NUM_THREADS']='1'
from pathlib import Path
import json, hashlib, time
# Import only model definitions, never the baseline scan.
source=(Path(__file__).resolve().parent / 'r655_clone_probe.py').read_text()
pre,rest=source.split('def run(r,tag):',1)
exec(pre)
body=rest.split("out={'task':'TASK_NUM_CLONE_1'",1)[0]
old="""   left=y-F(1,32)+F(i,16*r);right=y-F(1,32)+F(i+1,16*r)
   labels.append(f'{name}{i}');masses.append(m);E.append((t*left-b*(y+X),t*right-b*(y+X)));B.append((c-t/32,c+t/32));C.append((c-t,c+t))"""
new="""   labels.append(f'{name}{i}');masses.append(m)
   # k=1 contiguous; k>=2 cyclic coloring of k*r equal microcells.
   for cell in (range(i*k,(i+1)*k) if k==1 else range(i,k*r,r)):
    left=y-F(1,32)+F(cell,16*k*r); right=y-F(1,32)+F(cell+1,16*k*r)
    E.append((t*left-b*(y+X),t*right-b*(y+X),len(labels)-1))
   B.append((c-t/32,c+t/32));C.append((c-t,c+t))"""
assert old in body
body=body.replace(old,new)
body=body.replace('pts=sorted(set(x for ab in E+B for x in ab)); allocation=', 'pts=sorted(set(x for a,b,j in E for x in (a,b)) | set(x for ab in B for x in ab)); allocation=')
body=body.replace('inc=tuple(j for j,(a,b) in enumerate(E) if a<x<b); rec=', 'inc=tuple(sorted(set(j for a,b,j in E if a<x<b))); rec=')
exec('def run(r,tag,k):'+body)
start=time.monotonic(); data={}
for r,ks in [(2,[1,2,4,8]),(4,[1,2,8])]:
    if r==4 and not data['2']['any_changed']:
        break
    sets={};
    for k in ks:
        records=[run(r,tag,k) for tag in product((-1,1),repeat=r)]
        sets[str(k)]={'branches':records,'mean_D':sum(x['D'] for x in records)/len(records),'mean_Qprime':sum(x['Qprime'] for x in records)/len(records),'mean_W':str(sum((F(x['W']) for x in records),F(0))/len(records))}
    basecases=sets['1']['branches']; changed=False
    for k in ks[1:]:
        for x,y in zip(basecases,sets[str(k)]['branches']):
            # Compare exact eligibility allocation, not floating solver outputs.
            def allocations(z): return {tuple(a['eligible']):F(a['length']) for a in z['eligibility_atoms']}
            if allocations(x)!=allocations(y): changed=True
    data[str(r)]={'designs':sets,'any_changed':changed}
    print('r',r,'eligibility_changed',changed,'means',[(k,v['mean_D']) for k,v in sets.items()],flush=True)
out={'task':'TASK_NUM_PARTITION_DESIGN','scope':'atomic-limit diagnostic; no positive-width inference; full joint owner/entropy recomputed per partition and full tag tuple','source_sha256':hashlib.sha256(source.encode()).hexdigest(),'python':platform.python_version(),'numpy':np.__version__,'cvxpy':cp.__version__,'clarabel':clarabel.__version__,'delta':str(delta),'epsilon':str(eps),'results':data,'elapsed_seconds':time.monotonic()-start}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2))
