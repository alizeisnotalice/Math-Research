# R656 owner mass profile and non-simplex check

For the R655 atomic family, all realized C share a positive interval, so packing is the simplex. For every available j, actual KKT gives `m_j+epsilon p_j/alpha_j=nu`, hence

`alpha_j=epsilon p_j/(nu−m_j)`, `sum_j epsilon p_j/(nu−m_j)=1`, `Q′=nu−epsilon W`.

The derivative of the joint objective for a free atom is `log[p_j/(m_j alpha_j)]+1`; its price is `(nu−m_j)/(epsilon m_j)`, strictly decreasing in m_j for common nu. Therefore **every free portion must choose the largest eligible mass**, with arbitrary ties among equal-m labels. This includes the real δ=1/100 baseline, whose share is reserved before free assignment. It is an exact statement for simplex packing, rather than a conclusion from solver status.

The script reads `r655_clone_probe.json` beside itself, containing all 2+4+16 archived R655 eligibility-atom records, computes exact rational baseline and mass-layer volumes, allocates the free part to the mass maximizers, then solves the scalar root numerically. It does not rerun their CVXPY problems. Maximum absolute difference of Q′ from the earlier joint CVXPY values is 2.22e−6, 2.51e−6, 3.01e−6 for r=1,2,4; the maximal root equation residual is 2.23e−16. The refined means are approximately 13.6, 13.881661021, 14.095919569 respectively. Tied same-m allocation may change individual p/alpha but cannot change the aggregate mass profile or Q′; the script's equal split is a valid optimizer, not a claim about the original solver's canonical secondary selector.

The only enlarged cases are the same actual atomic family at r=8, four prescribed central tags; all 8 left and right clone anchors retain their fixed endpoints. There is no claim that these four selected tags give the r=8 expectation:

| tag pattern | W | aggregate p(m=8), p(m=16) | Q′ |
|---|---:|---|---:|
| all left | 3/4 | 1/4, 1/2 | 13.6 |
| all right | 3/4 | 1/4, 1/2 | 13.6 |
| alternating | 1 | 1/4, 3/4 | 14.16814225 |
| first 4 left, last 4 right | 1 | 11/64, 53/64 | 14.75051581 |

The calculations use zero-width tags and do not prove positive-width or calibrated-hard-state conclusions. The four-pattern mean is not an Euler expectation.

## Non-simplex counterexample: genuine cube receivers

Take actual one-dimensional new cubes `C1=[−2,2]`, `C2=[−3/2,3/2]`, `C3=[7/4,47/4]`, with volumes m=(4,3,10). Their positive-volume packing constraints are `alpha1+alpha2<=1` and `alpha1+alpha3<=1`, with no C2–C3 overlap. With a=32 their actual centered receivers are `B1=[−1/16,1/16]`, `B2=[−3/64,3/64]`, `B3=[211/32,221/32]`. Set E=B. The shared atom B2 has length 3/32 and is eligible for rows 1 and 2; B1's two exclusive tails have total length 1/32, and the B3 exclusive atom has length 5/16. Every real receiver atom is retained. Assume both shared incoming rows satisfy capture eligibility. Set epsilon=1 and δ=1/100. This is a finite actual-interval receiver/packing model; it does not assert an old KKT source, Euler realization, or near-score state.

The true optimum has `p=(203/6400,597/6400,5/16)`, with all shared free mass assigned to row 2 even though m2=3<m1=4; row 1 receives its exclusive part and shared baseline. Both packing constraints bind. Put `alpha1=a`, `alpha2=alpha3=1−a`; the strict monotone equation

`(203/6400)/a − (2597/6400)/(1−a)=9`

has its unique solution in [1/10000,1/100]. The script gives an 80-bisection rational bracket and verifies throughout it

`(203/6400)/(4a) > (597/6400)/(3(1−a))`.

The two positive cell multipliers are `mu12=3+(597/6400)/(1−a)` and `mu13=10+(5/16)/(1−a)`. Their sum is the effective dual price of row 1, while row 2 sees only mu12. They satisfy all entropy stationarity equations, and the strict price comparison verifies the free atom choice; concavity and KKT prove the solution. Rounded solver outputs are alpha1≈0.003372, cell multipliers ≈3.0936 and ≈10.3136, and free prices ≈2.352 and 0.0312. Those rounded values illustrate the exact rational certificate. Thus the max-m rule is specific to common-simplex packing and fails for this actual receiver incidence.

## Reproduction

`/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/ccu_r656/numeric/owner_profile.py > /tmp/ccu_r656/numeric/owner_profile.json`

Python 3.12.14, NumPy 2.5.4, SciPy 1.18.1, CVXPY 1.9.3, Clarabel 0.11.1, single process, OpenBLAS/OMP threads 1. The script emits JSON to stdout; the shell redirection saves it. The archived input `r655_clone_probe.json` has SHA-256 `1f76884f44e6bcb409f191debe9cf876c08896e8caec096f69f4887af453497a`, matching the original `/tmp/ccu_r655/numeric/clone_probe.json`. After changing the input path to be relative to the script, an actual replay produced output byte-for-byte identical to the prior JSON. The JSON contains all 22 old comparisons, all four r=8 tag profiles, exact mass layers, scalar roots and the non-simplex rational bracket. Script SHA-256 `0381e5c56986d241ca2b2c67a2ad164197824707ab02d3016534a559e6953f84`; JSON SHA-256 `33c182441ba284b23d8fdd263989051d02302af894b16c31732fce6dfaf2abdc`.

## Global versus neighborhood deficit certificate

This additional bounded comparison uses the three real C/32 receivers above and a second identical component translated by 100; the two C unions and receiver unions are disjoint. For each component the packing LP optimum is P=13, attained at `(0,1,1)`. Its two cell multipliers are 3 and 10, giving row slacks `sigma=(9,0,0)`. The real free-image eligibility includes zero-slack row 2 on the shared B2 atom; nevertheless the baseline and row-1-exclusive receiver force `p1>=203/6400`. The actual KKT solution attains this bound, and `W=7/16` per component. A single mass/packing account is used: for two components total P=26 and total W=7/8. There is no duplicated source M.

Under the supplied neighborhood inequality, put `d=P−Q′` and use `d_0=0`, `d_(k+1)=F(d_k)`. For one component, row 1's C neighborhood is the entire component, so the two denominator choices give

`F_1(d)=9(203/6400)/(151/16−d)`.

For two components, the purely global denominator gives

`F_global(d)=18(203/6400)/(183/8−d)`,

while the neighborhood certificate gives

`F_neighborhood(d)=18(203/6400)/min(183/8−d,151/16)`.

The code computes k=1,2,4,8 entirely with Fraction. Exact fractions are in `deficit_certificates` in the JSON; the numerical display below is rounded and is not an interval proof by itself.

| components | actual d (KKT rational bracket) | certificate | k=1 | k=2 | k=4 | k=8 |
|---:|---:|---|---:|---:|---:|---:|
| 1 | ≈0.03034592051837 | global and neighborhood | 0.03024834437 | 0.03034560576 | 0.030345920515 | 0.030345920518 |
| 2 | ≈0.06069184103674 | global | 0.02495901639 | 0.02498627904 | 0.02498630888 | 0.02498630888 |
| 2 | ≈0.06069184103674 | neighborhood | 0.06049668874 | 0.06049668874 | 0.06049668874 | 0.06049668874 |

For example the exact first iterates are `1827/60400` for one component, `609/24400` for two-component global, and `1827/30200` for two-component neighborhood. The actual d is bracketed by nine times (or eighteen times) the exact rational KKT bracket for a recorded above. This compares the strength of these two bounds on a single fixed finite packing example; it does not establish the general neighborhood inequality or an old near-score realization.
