import json, platform
from fractions import Fraction as F
p3=F(5,16);W=F(7,16);p_low=F(1,32)+F(1,100)*F(3,64);p_high=p_low+F(99,100)*F(3,32)
assert p_low==F(203,6400) and p_high==F(797,6400)
def g(x,p): return p/x-(W-p)/(1-x)-9
def bounds(p):
 lo=F(1,1000000);hi=F(1,10);assert g(lo,p)>0 and g(hi,p)<0
 for _ in range(100):
  mid=(lo+hi)/2
  if g(mid,p)>0:lo=mid
  else:hi=mid
 return lo,hi
lo,hi=bounds(p_low);LO,HI=bounds(p_high)
assert 0<lo<hi<LO<HI<1
# KKT for the joint-B solution: no shared free mass goes to row 1.
p2=F(3,32)-F(3,6400)
assert p_low/(4*hi)>p2/(3*(1-hi))
# positive duals for both packing cells, for all p in the interval.
assert p3>0 and F(3,6400)>0
qB=(F(13)-9*hi,F(13)-9*lo);qmin=(F(13)-9*HI,F(13)-9*LO); gain=(9*(LO-hi),9*(HI-lo))
# Global MAX/MIN supported deficit iterations; Fraction arithmetic only.
def deficit_iter(p,root_lower):
 d=F(0); out={}
 for k in range(1,9):
  assert F(151,16)-d>0
  d=9*p/(F(151,16)-d)
  assert d<9*root_lower
  if k in (1,2,4,8): out[str(k)]=str(d)
 return out
iterations={'MIN_p1low':deficit_iter(p_low,lo),'MAX_p1high':deficit_iter(p_high,LO),'actual_MIN_deficit_interval':[str(9*lo),str(9*hi)],'actual_MAX_deficit_interval':[str(9*LO),str(9*HI)]}
# Neighbor MAX on one or two separated copies: W_N=7/16 and P_N=13.
def neighbor_max(n):
 d=F(0); out={}
 for k in range(1,9):
  den=min(F(13*n)+F(7*n,16)-4-d,F(151,16))
  assert den>0
  d=n*9*p_high/den
  assert d<n*9*LO
  if k in (1,2,4,8):out[str(k)]=str(d)
 return out
neighbor_iterations={str(n):{'P':str(13*n),'W':str(F(7*n,16)),'p1max_per_component':str(p_high),'iterates':neighbor_max(n),'actual_deficit_interval':[str(n*9*LO),str(n*9*HI)]} for n in (1,2)}
out={'python':platform.python_version(),'receiver_atoms':{'B1_exclusive_total':'1/32','shared_B2':'3/32','B3_exclusive':'5/16','W':str(W),'delta':'1/100'},'p1_feasible_interval':[str(p_low),str(p_high)],'p2':'1/8-p1','p3':str(p3),'actual_joint_B_p1':str(p_low),'min_Q_p1':str(p_high),'KKT_root_equation':'p1/x-(W-p1)/(1-x)=9; alpha=(x,1-x,1-x)','monotonicity':'partial g/partial p1=1/x+1/(1-x)>0; partial g/partial x=-p1/x^2-(W-p1)/(1-x)^2<0, so x increases strictly and Q=13-9x decreases strictly','joint_B_x_interval':list(map(str,(lo,hi))),'min_Q_x_interval':list(map(str,(LO,HI))),'joint_B_Q_interval':list(map(str,qB)),'min_Q_interval':list(map(str,qmin)),'Q_B_minus_Q_min_interval':list(map(str,gain)),'D_gain':'R*(Q_B-Q_min), strictly positive for R>0','global_support_iterations':iterations,'neighbor_MAX_iterations':neighbor_iterations,'scope':'actual C/a receiver atoms and assumed capture eligibility; not a realizable old KKT or near-score construction'}
print(json.dumps(out,indent=2))
