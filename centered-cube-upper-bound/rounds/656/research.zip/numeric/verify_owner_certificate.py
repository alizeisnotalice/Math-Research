from fractions import Fraction as F
from itertools import product
from collections import defaultdict
import json, hashlib, platform
from pathlib import Path
here=Path(__file__).resolve().parent
profile=json.loads((here/'owner_profile.json').read_text())
base=[('L',-F(127,64),F(8),F(4),F(3,2)),('C',F(0),F(16),F(8),F(7,2)),('R',F(127,64),F(8),F(4),F(3,2))]
def arrangement(intervals):
    pts=sorted(set(x for ab in intervals for x in ab)); out=[]
    for l,h in zip(pts,pts[1:]):
        mid=(l+h)/2; covered=tuple(i for i,(a,b) in enumerate(intervals) if a<mid<b)
        if covered: out.append((l,h,covered))
    return out
def atoms(r,tags):
    E=[];B=[];C=[];labels=[];ys=[];m=[]
    for name,y,mass,t,b in base:
        for i in range(r):
            X=F(-1 if name=='L' else 1 if name=='R' else tags[i]);c=(1+b)*y-b*X
            lo=y-F(1,32)+F(i,16*r);hi=y-F(1,32)+F(i+1,16*r)
            E.append((t*lo-b*(y+X),t*hi-b*(y+X)));B.append((c-t/32,c+t/32));C.append((c-t,c+t));labels.append(name+str(i));ys.append(y);m.append(mass)
    assert min(x[1] for x in C)>max(x[0] for x in C)
    points=sorted(set(x for pair in E+B for x in pair)); D=defaultdict(F)
    for lo,hi in zip(points,points[1:]):
        x=(lo+hi)/2; incoming=[i for i,(a,b) in enumerate(E) if a<x<b]; recv=[i for i,(a,b) in enumerate(B) if a<x<b]
        if not recv: continue
        elig=tuple(i for i in incoming if all(C[i][0]<=ys[k]-1 and C[i][1]>=ys[k]+1 for k in incoming)) if incoming else tuple(recv)
        assert elig; D[elig]+=hi-lo
    p=defaultdict(F)
    for elig,length in D.items():
        winners=[j for j in elig if m[j]==max(m[k] for k in elig)]
        for j in elig: p[j]+=F(1,100)*length/len(elig)
        for j in winners:p[j]+=F(99,100)*length/len(winners)
    return D,p,m,labels
Eps=F(336,5)
def root(p,m):
    def g(x):return sum((Eps*v/(x-m[j]) for j,v in p.items()),F())-1
    lo=F(max(m[j] for j in p))+F(1,10**8);hi=F(1000);assert g(lo)>0 and g(hi)<0
    for _ in range(100):
        mid=(lo+hi)/2
        if g(mid)>0:lo=mid
        elif g(mid)<0:hi=mid
        else:return mid,mid
    assert g(lo)>0 and g(hi)<0
    return lo,hi
cases=[]
for r in (1,2,4,8):
  for row in profile['cases'][str(r)]:
    D,p,m,labels=atoms(r,row['tag']); W=sum(D.values(),F()); assert W==F(row['W'])
    assert {labels[k]:str(v) for k,v in p.items()}==row['p']
    lo,hi=root(p,m); assert lo>max(m[j] for j in p)
    Wp=sum(p.values(),F()); assert W==Wp
    groups={str(a):str(sum((v for j,v in p.items() if m[j]==a),F())) for a in sorted(set(m[j] for j in p))}
    assert groups==row['p_by_mass']
    cases.append({'r':r,'tag':row['tag'],'atoms':len(D),'W':str(W),'p_by_mass':groups,'nu_bracket':[str(lo),str(hi)],'Qprime_bracket':[str(lo-Eps*W),str(hi-Eps*W)]})
C=[(-F(2),F(2)),(-F(3,2),F(3,2)),(F(7,4),F(47,4))]
B=[((l+h)/2-(h-l)/64,(l+h)/2+(h-l)/64) for l,h in C]
A=arrangement(B); coverage=[(str(a),str(b),[j+1 for j in js]) for a,b,js in A]
assert coverage==[('-1/16','-3/64',[1]),('-3/64','3/64',[1,2]),('3/64','1/16',[1]),('211/32','221/32',[3])]
cp=arrangement(C); incidence=set(tuple(j+1 for j in js) for _,_,js in cp);assert incidence=={(1,),(1,2),(1,3),(3,)}
p1=F(203,6400);p2=F(597,6400);p3=F(5,16);assert p1+p2+p3==F(7,16)
def eq(x): return p1/x-(p2+p3)/(1-x)-9
lo=F(1,10000);hi=F(1,100);assert eq(lo)>0 and eq(hi)<0
for _ in range(100):
 mid=(lo+hi)/2
 if eq(mid)>0: lo=mid
 else: hi=mid
assert eq(lo)>0 and eq(hi)<0
auth_lo,auth_hi=map(F,profile['non_simplex']['exact_kkt']['alpha1_bracket'])
assert auth_lo<=lo<hi<=auth_hi and eq(auth_lo)>0 and eq(auth_hi)<0
assert p1/(4*hi)>p2/(3*(1-hi))
non={'receiver_atoms':coverage,'packing_incidence':sorted(incidence),'p':[str(p1),str(p2),str(p3)],'root_bracket':[str(lo),str(hi)],'price_difference_lower':str(p1/(4*hi)-p2/(3*(1-hi))),'free_shared_allocation':['0','3/32'],'strict_positive_cell_multipliers':True}
P=F(16); W=F(3,4); eps=F(336,5); sig=F(8); p_outer=F(1,4)
A=P+eps*W-F(8); B=eps*sig*p_outer
assert A==F(292,5) and B==F(672,5)
assert F(12,5)+F(56)==A and F(12,5)*56==B
assert F(0)<=F(12,5)<=P<F(56) and A-P>0
assert eps*(F(1,4)/(F(64)-8)+F(1,2)/(F(64)-16))==1
assert F(64)-eps*W==F(68,5) and P-F(68,5)==F(12,5)
implicit={'P':str(P),'W':str(W),'epsilon':str(eps),'sigma_outer':str(sig),'p_outer':str(p_outer),'denominator_constant':str(A),'numerator':str(B),'root_interval':['12/5','56'],'physical_d_domain':['0','16'],'minimum_denominator':str(A-P),'d_lower':'12/5','actual_d':'12/5','note':'conditional on the proposed first-order inequality and dual measure assumptions'}
# Independent localized bound arithmetic for separated translated copies.
receiver=[((l+h)/2-(h-l)/64,(l+h)/2+(h-l)/64) for l,h in C]
assert max(h for l,h in C)<min(l+100 for l,h in C)
assert max(h for l,h in receiver)<min(l+100 for l,h in receiver)
neighbors=[i for i,(l,h) in enumerate(C) if max(l,C[0][0])<min(h,C[0][1])]
assert neighbors==[0,1,2]
wn=sum((b-a for a,b,_ in arrangement(receiver)),F()); assert wn==F(7,16)
# LP dual multipliers 3,10 prove P<=13; (0,1,1) attains it.
assert F(3)+F(10)==13 and F(3)+F(10)-4==9
localized={}
for n in (1,2):
  expected=profile['deficit_certificates'][str(n)]
  assert F(expected['P'])==13*n and F(expected['W'])==n*wn
  assert F(expected['forced_p1'].split()[0])==p1
  authorlo,authorhi=map(F,expected['actual_deficit_interval'])
  assert authorlo<=9*n*lo<9*n*hi<=authorhi
  fields={}
  for local in (False,True):
    d=F(0); seq={}
    for k in range(1,9):
      glob=13*n+n*wn-4-d; assert glob>0
      den=min(glob,13+wn-4) if local else glob
      assert den>0
      d=n*9*p1/den
      if k in (1,2,4,8):
        assert d<9*n*lo
        seq[str(k)]=str(d)
    name='neighborhood_iterations' if local else 'global_iterations'
    assert seq==expected[name]
    fields[name]=seq
  localized[str(n)]={'P':str(13*n),'W':str(n*wn),'P_neighborhood':'13','W_neighborhood':str(wn),'actual_deficit_bracket':[str(9*n*lo),str(9*n*hi)],**fields}
assert F(localized['1']['global_iterations']['1'])==F(1827,60400)
assert F(localized['2']['global_iterations']['1'])==F(609,24400)
assert F(localized['2']['neighborhood_iterations']['1'])==F(1827,30200)
# Independent selector endpoint and root brackets; all p_j remain positive.
selector_path=here/'selector_certificate.json'
selector=json.loads(selector_path.read_text())
pl=F(1,32)+F(1,100)*F(3,64); ph=pl+F(99,100)*F(3,32)
assert pl==F(203,6400) and ph==F(797,6400)
assert F(1,8)-ph==F(3,6400)>0 and pl>0 and F(5,16)>0
assert list(map(F,selector['p1_feasible_interval']))==[pl,ph]
Wsel=F(7,16)
def gs(x,p):return p/x-(Wsel-p)/(1-x)-9
def selroot(p):
 l=F(1,1000000); h=F(1,10); assert gs(l,p)>0 and gs(h,p)<0
 for _ in range(110):
  mid=(l+h)/2
  if gs(mid,p)>0:l=mid
  else:h=mid
 assert gs(l,p)>0 and gs(h,p)<0
 return l,h
l0,h0=selroot(pl);l1,h1=selroot(ph); assert 0<l0<h0<l1<h1<1
for key,l,h in [('joint_B_x_interval',l0,h0),('min_Q_x_interval',l1,h1)]:
 a,b=map(F,selector[key]); assert a<=l<h<=b and gs(a,pl if key.startswith('joint') else ph)>0 and gs(b,pl if key.startswith('joint') else ph)<0
gap=(9*(l1-h0),9*(h1-l0)); assert gap[0]>F(899,10000) and gap[1]<F(9,100)
agap=list(map(F,selector['Q_B_minus_Q_min_interval'])); assert agap[0]<=gap[0]<gap[1]<=agap[1]
# Global-only support iteration for both selector endpoints.
support={}
for label,p,rootlower in [('MIN_p1low',pl,l0),('MAX_p1high',ph,l1)]:
 d=F(0); seq={}
 for k in range(1,9):
  den=F(151,16)-d; assert den>0
  d=9*p/den
  if k in (1,2,4,8):
   assert d<9*rootlower
   seq[str(k)]=str(d)
 assert seq==selector['global_support_iterations'][label]
 support[label]=seq
for key,l,h in [('actual_MIN_deficit_interval',l0,h0),('actual_MAX_deficit_interval',l1,h1)]:
 a,b=map(F,selector['global_support_iterations'][key]); assert a<=9*l<9*h<=b
neighbor_max={}
for n in (1,2):
 record=selector['neighbor_MAX_iterations'][str(n)]
 assert F(record['P'])==13*n and F(record['W'])==n*F(7,16) and F(record['p1max_per_component'])==ph
 d=F(0); seq={}
 for k in range(1,9):
  den=min(F(13*n)+F(7*n,16)-4-d,F(151,16)); assert den>0
  d=9*n*ph/den
  if k in (1,2,4,8):
   assert d<9*n*l1
   seq[str(k)]=str(d)
 assert seq==record['iterates']
 a,b=map(F,record['actual_deficit_interval']); assert a<=9*n*l1<9*n*h1<=b
 neighbor_max[str(n)]=seq
assert set(neighbor_max['2'].values())=={str(F(7173,30200))}
selector_check={'neighbor_MAX_iterations':neighbor_max,'global_support_iterations':support,'p1_range':[str(pl),str(ph)],'minimum_p2':str(F(1,8)-ph),'joint_B_x_bracket':[str(l0),str(h0)],'min_Q_x_bracket':[str(l1),str(h1)],'Q_gap_bracket':list(map(str,gap)),'D_gain':'R*Q_gap > 0 for fixed R>0','selector_sha256':__import__('hashlib').sha256(selector_path.read_bytes()).hexdigest()}
out={'selector':selector_check,'localized':localized,'implicit_same_sign_r2':implicit,'python':platform.python_version(),'profile_sha256':hashlib.sha256((here/'owner_profile.json').read_bytes()).hexdigest(),'simplex_cases':cases,'non_simplex':non}
print(json.dumps(out,indent=2))
