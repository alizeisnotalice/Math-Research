import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
import math,json,platform,itertools
from fractions import Fraction as F
from pathlib import Path
import numpy as np,cvxpy as cp,scipy,clarabel
from scipy.optimize import brentq
EPS=F(336,5);DEL=F(1,100)
def profile(atoms):
 p0={}; q={}; masses={}
 for atom in atoms:
  length=F(atom['length']); labels=atom['eligible']; ms=[16 if x.startswith('C') else 8 for x in labels]; best=max(ms)
  winners=[x for x,m in zip(labels,ms) if m==best]
  for x,m in zip(labels,ms):
   masses[x]=m;p0[x]=p0.get(x,F(0))+length/len(labels)
   if x in winners:q[x]=q.get(x,F(0))+length/len(winners)
 p={x:DEL*p0[x]+(1-DEL)*q.get(x,F(0)) for x in masses};W=sum(p.values(),F(0)); groups={str(m):sum(v for x,v in p.items() if masses[x]==m) for m in sorted(set(masses.values()))}
 nu=brentq(lambda t:sum(float(EPS*v)/(t-masses[x]) for x,v in p.items())-1,max(masses.values())+1e-9,10000,xtol=1e-13)
 alpha={x:float(EPS*v)/(nu-masses[x]) for x,v in p.items()};Q=sum(masses[x]*a for x,a in alpha.items());res=sum(alpha.values())-1
 return {'W':str(W),'p_by_mass':{k:str(v) for k,v in groups.items()},'p':{x:str(v) for x,v in p.items()},'nu':nu,'Qprime':Q,'nu_minus_eps_W':nu-float(EPS*W),'root_residual':res,'alpha':alpha}
def build_atoms(r,tags):
 d=F(127,64); base=[('L',-d,F(8),F(4),F(3,2)),('C',F(0),F(16),F(8),F(7,2)),('R',d,F(8),F(4),F(3,2))];E=[];B=[];C=[];labels=[]; ys=[]
 for name,y,m,t,b in base:
  for i in range(r):
   X=F(-1) if name=='L' else F(1) if name=='R' else F(tags[i]); c=(1+b)*y-b*X; lo=y-F(1,32)+F(i,16*r);hi=y-F(1,32)+F(i+1,16*r);labels.append(f'{name}{i}');ys.append(y); E.append((t*lo-b*(y+X),t*hi-b*(y+X)));B.append((c-t/32,c+t/32));C.append((c-t,c+t))
 assert min(a[1] for a in C)-max(a[0] for a in C)>0
 pts=sorted(set(x for ab in E+B for x in ab)); groups={}
 for l,h in zip(pts,pts[1:]):
  x=(l+h)/2;inc=[j for j,(a,b) in enumerate(E) if a<x<b]; rec=[j for j,(a,b) in enumerate(B) if a<x<b]
  if not rec:continue
  eligible=tuple(j for j in inc if all(C[j][0]<=ys[k]-1 and C[j][1]>=ys[k]+1 for k in inc)) if inc else tuple(rec)
  assert eligible; elig=tuple(labels[j] for j in eligible);groups[elig]=groups.get(elig,F(0))+h-l
 return [{'eligible':list(k),'length':str(v)} for k,v in groups.items()]
old=json.loads(Path(__file__).with_name('r655_clone_probe.json').read_text()); cases={}
for r in (1,2,4):
 vals=[]
 for row in old['r'][str(r)]['rows']:
  z=profile(row['eligibility_atoms']);z.update(tag=row['tag'],previous_Qprime=row['Qprime'],Q_difference=z['Qprime']-row['Qprime']);vals.append(z)
 cases[str(r)]=vals
patterns={'all_left':[-1]*8,'all_right':[1]*8,'alternating':[-1,1]*4,'block':[-1]*4+[1]*4}; cases['8']=[dict(tag=v,pattern=k,**profile(build_atoms(8,v))) for k,v in patterns.items()]
# C1=[-2,2], C2=[-3/2,3/2], C3=[7/4,47/4], B_j=C_j/32 about their centers.
# B1 has exclusive tails total 1/32, B2 shared length 3/32, B3 exclusive 5/16.
# I=B so E=B: abstract feasible successor only, no old-state realization.
m=np.array([4.,3.,10.]); a=cp.Variable(3,nonneg=True);z=cp.Variable(2,nonneg=True)
p=cp.hstack([1/32+.01*3/64+.99*z[0],.01*3/64+.99*z[1],5/16]); c1=a[0]+a[1]<=1;c2=a[0]+a[2]<=1;pr=cp.Problem(cp.Minimize(cp.sum(cp.rel_entr(p,cp.multiply(m,a)))-m@a),[cp.sum(z)==3/32,c1,c2]);pr.solve(solver='CLARABEL',tol_gap_abs=1e-11,tol_feas=1e-11,tol_gap_rel=1e-11,max_iter=500)
aa=np.asarray(a.value);pp=np.asarray(p.value);zz=np.asarray(z.value);dual=[float(c1.dual_value),float(c2.dual_value)];price=pp/(m*aa);eff=[dual[0]+dual[1],dual[0],dual[1]]
# Candidate q1=0, q2=3/32; strict KKT and rational root interval.
p1=F(1,32)+F(3,6400);p2=F(3,32)-F(3,6400);p3=F(5,16)
def eq(x): return p1/x-(p2+p3)/(1-x)-9
a_lo=F(1,10000);a_hi=F(1,100)
assert eq(a_lo)>0 and eq(a_hi)<0
for _ in range(80):
 mid=(a_lo+a_hi)/2
 if eq(mid)>0:a_lo=mid
 else:a_hi=mid
assert p1/(4*a_hi)>p2/(3*(1-a_hi))
non={'C_intervals':[[-2,2],['-3/2','3/2'],['7/4','47/4']],'B_intervals':[['-1/16','1/16'],['-3/64','3/64'],['211/32','221/32']],'m':m.tolist(),'shared_atom':'B2=[-3/64,3/64], eligible 1 and 2, length 3/32','forced_atoms':'B1 tails total 1/32; B3 length 5/16','packing':['alpha1+alpha2<=1','alpha1+alpha3<=1'],'delta':'1/100','epsilon':'1','status':pr.status,'p':pp.tolist(),'q_shared':zz.tolist(),'alpha':aa.tolist(),'dual_cells':dual,'effective_dual_price':eff,'free_prices':price.tolist(),'stationarity_residual':max(abs(eff[i]-m[i]-pp[i]/aa[i]) for i in range(3)),'exact_kkt':{'alpha1_bracket':[str(a_lo),str(a_hi)],'alpha2_alpha3':'1-alpha1','p1':str(p1),'p2':str(p2),'p3':str(p3),'equation':f'{p1}/a - ({p2}+{p3})/(1-a) = 9','cell_duals':f'mu12=3+({p2})/(1-a)>0; mu13=10+({p3})/(1-a)>0','price_inequality':'p1/(4a)>p2/[3(1-a)] throughout bracket; free q1=0, q2=3/32','certificate':'exact rational bisection and KKT; geometric packing and receiver model only'},'scope':'actual C/32 receiver incidence; no claim of old KKT, Euler action, or near-score realization'}
# F(d) certificate on one component and a translated disjoint second copy.
# P=13/component, W=7/16/component, only sigma1=9; forced p1=203/6400.
def iter_bound(n,local):
 d=F(0); vals={}; P=13*n; W=F(7*n,16); p=F(203,6400)
 for k in range(1,9):
  den=F(P)-d+W-4
  if local: den=min(den,F(13)+F(7,16)-4)
  assert den>0
  d=n*9*p/den
  if k in (1,2,4,8): vals[str(k)]=str(d)
 return vals
certificate={}
for n in (1,2):
 global_b=iter_bound(n,False); local_b=iter_bound(n,True)
 assert all(F(v)<=9*n*a_lo for v in list(global_b.values())+list(local_b.values()))
 certificate[str(n)]={'P':str(13*n),'W':str(F(7*n,16)),'only_positive_sigma':'9 per component on row 1','forced_p1':'203/6400 per component','actual_deficit_interval':[str(9*n*a_lo),str(9*n*a_hi)],'global_iterations':global_b,'neighborhood_iterations':local_b,'copy_separation':'second C,B translated by 100; components pairwise disjoint'}
out={'python':platform.python_version(),'numpy':np.__version__,'scipy':scipy.__version__,'cvxpy':cp.__version__,'clarabel':clarabel.__version__,'scope':'atomic R655 geometry; exactly specified r8 patterns; no positive-width or calibrated inference','formula':'u_j=(nu-m_j)/m_j; free price u_j/epsilon; nu > max available m, so free owner maximizes m','cases':cases,'non_simplex':non,'deficit_certificates':certificate};print(json.dumps(out,indent=2))
