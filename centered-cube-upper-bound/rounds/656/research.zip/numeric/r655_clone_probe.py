import os
os.environ['OPENBLAS_NUM_THREADS']='1'; os.environ['OMP_NUM_THREADS']='1'
from fractions import Fraction as F
from itertools import product
from collections import defaultdict
import json,platform,time,math
import cvxpy as cp,numpy as np,clarabel
R=F(15,272); eps=F(336,5); M=F(16); delta=F(1,100)
base=[('L',-F(127,64),F(8),F(4),F(3,2)),('C',F(0),F(16),F(8),F(7,2)),('R',F(127,64),F(8),F(4),F(3,2))]
def atoms(intervals):
 pts=sorted(set(x for ab in intervals for x in ab)); out=[]
 for a,b in zip(pts,pts[1:]):
  x=(a+b)/2; coverage=tuple(j for j,(lo,hi) in enumerate(intervals) if lo<x<hi)
  if coverage: out.append((a,b,coverage))
 return out
def run(r,tag):
 labels=[]; E=[]; B=[]; C=[]; masses=[]
 for name,y,m,t,b in base:
  for i in range(r):
   X=F(-1) if name=='L' else F(1) if name=='R' else F(tag[i]); c=(1+b)*y-b*X
   left=y-F(1,32)+F(i,16*r);right=y-F(1,32)+F(i+1,16*r)
   labels.append(f'{name}{i}');masses.append(m);E.append((t*left-b*(y+X),t*right-b*(y+X)));B.append((c-t/32,c+t/32));C.append((c-t,c+t))
 common=min(x[1] for x in C)-max(x[0] for x in C); assert common>0
 # same interval arrangement contains both E and B boundaries.
 pts=sorted(set(x for ab in E+B for x in ab)); allocation=defaultdict(F); W=F(0); image=F(0)
 for lo,hi in zip(pts,pts[1:]):
  x=(lo+hi)/2; inc=tuple(j for j,(a,b) in enumerate(E) if a<x<b); rec=tuple(j for j,(a,b) in enumerate(B) if a<x<b)
  if not rec: continue
  area=hi-lo; W+=area
  if inc:
   image+=area
   good=tuple(j for j in inc if all(C[j][0]<=base[k//r][1]-1 and C[j][1]>=base[k//r][1]+1 for k in inc))
  else: good=rec
  assert good
  allocation[good]+=area
 avail=sorted(set(j for a in allocation for j in a)); loc={j:i for i,j in enumerate(avail)}; p0=np.zeros(len(avail)); edges=[]
 for es,length in allocation.items():
  for j in es:p0[loc[j]]+=float(length)/len(es);edges.append((es,j))
 z=cp.Variable(len(edges),nonneg=True); al=cp.Variable(len(avail),nonneg=True); constraints=[]
 for es,length in allocation.items(): constraints.append(sum(z[i] for i,(a,j) in enumerate(edges) if a==es)==float(length))
 q=cp.hstack([sum(z[i] for i,(a,k) in enumerate(edges) if k==j) for j in avail]);p=float(delta)*p0+(1-float(delta))*q
 packing=cp.sum(al)<=1;constraints.append(packing); mm=np.array([float(masses[j]) for j in avail]); pr=cp.Problem(cp.Minimize(cp.sum(cp.rel_entr(p,cp.multiply(mm,al)))-mm@al/float(eps)),constraints)
 pr.solve(solver='CLARABEL',tol_gap_abs=1e-11,tol_feas=1e-11,tol_gap_rel=1e-11,max_iter=500)
 if pr.status not in ['optimal','optimal_inaccurate']: raise RuntimeError(pr.status)
 alpha=np.zeros(len(labels));alpha[avail]=al.value; pv=np.zeros(len(labels));pv[avail]=p.value; qv=np.zeros(len(labels));qv[avail]=q.value
 Qp=sum(float(m)*alpha[j] for j,m in enumerate(masses));S=float(M)-Qp; Ffill=W-image; O=F(1)-image;D=float(W)-float(R)*Qp
 res=float(np.max(abs(-np.array(p.value)/np.array(al.value)-mm/float(eps)+float(packing.dual_value))))
 price=np.asarray(p.value)/(mm*np.asarray(al.value));priceerr=max([max(0,price[loc[j]]-min(price[loc[k]] for k in es)) for i,(es,j) in enumerate(edges) if z.value[i]>1e-7] or [0]); ownererr=max(abs(sum(z.value[i] for i,(a,j) in enumerate(edges) if a==es)-float(length)) for es,length in allocation.items())
 return {'tag':tag,'W':str(W),'image_union':str(image),'F':str(Ffill),'O':str(O),'E_growth':'2/17','common_C_length':str(common),'available':[labels[j] for j in avail],'alpha':dict(zip(labels,alpha.tolist())),'p':dict(zip(labels,pv.tolist())),'q':dict(zip(labels,qv.tolist())),'Qprime':Qp,'S':S,'D':D,'full_ledger_residual':D-(float(F(2,17)-O+Ffill)+float(R)*S),'solver_status':pr.status,'alpha_stationarity_residual':res,'owner_conservation_residual':ownererr,'price_residual':priceerr,'packing_residual':max(0,sum(alpha)-1),'eligibility_atoms':[{'eligible':[labels[j] for j in es],'length':str(length)} for es,length in allocation.items()]}
out={'task':'TASK_NUM_CLONE_1','scope':'atomic limit w=0; only finite r 1,2,4; legitimate clones partition old I and lambda, common mu; positive width not inferred','python':platform.python_version(),'numpy':np.__version__,'cvxpy':cp.__version__,'clarabel':clarabel.__version__,'R':str(R),'epsilon':str(eps),'r':{}}
start=time.monotonic()
for r in (1,2,4):
 records=[run(r,t) for t in product((-1,1),repeat=r)]; n=len(records); meanW=sum((F(z['W']) for z in records),F(0))/n; assert meanW==1-F(1,2**(r+1))
 out['r'][str(r)]={'branches':n,'mean_W':str(meanW),'mean_Qprime':sum(z['Qprime'] for z in records)/n,'mean_S':sum(z['S'] for z in records)/n,'mean_D':sum(z['D'] for z in records)/n,'rows':records}
w=F(1,65536)
for r in (1,2,4):
 mu=F(out['r'][str(r)]['mean_W']); err=13*r*w
 out['r'][str(r)]['positive_width_W_enclosure']=[str(mu-err),str(mu+err)]
out['positive_width']='1/65536';out['positive_width_enclosure_basis']='couple source anchors to signed endpoints; every B moves at most b*w, union symmetric difference <= 2 sum b*w = 13*r*w'
out['r_to_infinity_expected_W']='1, in this atomic limit';out['positive_width_infinite_expected_W']=str(1+7*w)
out['positive_width_infinity_basis']='central clone anchors are dense in both source intervals a.s.; the two receiver swept intervals are disjoint and length 1/2+7w/2 each; outer swept receivers lie inside them'
out['elapsed_seconds']=time.monotonic()-start
print(json.dumps(out,indent=2))
