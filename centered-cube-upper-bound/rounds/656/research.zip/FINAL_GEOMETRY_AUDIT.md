# R656 final independent geometry and policy audit

**Verdict: PASS within the stated partial-result scope.** The reduced-cost/neighbor pressure theorem, MAX endpoint transfer, finite feasible owner witnesses and full-gain certificate are valid in the frozen report's domains. No blocking error remains. The uniform root-order net payment and general centered-cube weak bound remain unproved.

## Frozen bytes

The following SHA-256 values were actually computed from the reviewed files and confirmed as the final freeze:

| File | SHA-256 |
|---|---|
| `/tmp/ccu_r656/REPORT.tex` | `73b82672bc967d996b2561afd623cb428084bc8baf956d6ebfc6514613461568` |
| `/tmp/ccu_r656/NEXT_TARGET.md` | `c69d2968de2572c57aad8d997674dc2670ffa213bf1d60495aec28609f10b237` |

This audit is self-contained for the integrated results below. It reads the actual frozen report and next target; acceptance does not require the archived author drafts or preliminary screens. Passed numerical jobs were not rerun.

## Actual class and new selection objective

The report preserves one global epsilon_* on arbitrary finite labelled full-owner states, actual AC old KKT sources and actual finite normalized successors. Its use of the inherited uniform-Lipschitz calibration squeeze avoids enlarging N at an unrelated old parameter. Source/exploration selection precedes the finite independent clone count and anchors; no limiting optimizer or interchange of exploration/cloning limits is introduced.

For each realized tuple the available owner polytope is the same actual capture/image-priority `P_delta=delta p0+(1-delta)P`, with delta=.01. Baseline positivity makes every available p_j and fixed-p optimizer alpha_j positive. Unavailable rows have no new optimization variable and are never divided by; their old incoming tags remain in the full gain. Each feasible volume vector has a genuine nonatomic partition realization.

Choosing p to minimize its actual fixed-p source mass Q(p) is a **new** objective. The report explicitly relinquishes old joint-B free-minimum-u' and joint-dual properties. It recomputes actual alpha(p), and does not reassign p after freezing a different alpha. Any such full-owner output still satisfies the genuine same-parameter score identity and successor cap. Thus this policy change is legal for the full-gain contradiction route, without claiming that the old joint-B optimizer is unchanged.

## Reduced-cost and local replacement theorem

For the realized available packing polytope let P be its linear volume optimum, q=m.alpha(p), and d(p)=P-q. An optimal nonnegative linear dual nu can be represented on actual positive-volume packing cells, with mass P and reduced costs `sigma_j=nu(C_j)-m_j>=0`. AC representation excludes spurious null-contact loads. The exact identity is

`d(p)=U_nu+sum sigma_j alpha_j`, `U_nu=int(1-load_alpha)dnu>=0`.

At fixed positive p, first order against the unit packing vector e_j is legitimate through a positive segment even if the endpoint log value is minus infinity. It gives

`m_j+epsilon p_j/alpha_j<=q+epsilon W`.

Against a linear maximizer it also gives `0<=d(p)<epsilon W`; q>0 gives d(p)<P. The denominator `q+epsilon W-m_j` is strictly positive.

For `N_j={i:|C_i intersect C_j|>0}`, retaining alpha outside N_j, clearing its other neighbors and putting coefficient one on j is a genuine a.e. packing. Its FO inequality bounds the same row gradient by `P_Nj+epsilon W_Nj`, where W_Nj is the **actual receiver-union volume**, independent of the trial p. The capacity `sum_Nj p_i<=W_Nj` follows from disjoint real owners inside those receivers. The resulting alpha lower bound uses the minimum of the global and local denominators.

The local reduced-cost cap is independently valid: remove nu restricted to C_j and add an optimal AC dual for the restricted N_j family. An outside row loses no mass because its intersection with C_j is Lebesgue-null and nu is AC. Every neighbor demand is covered by the added dual; additional outside mass is harmless. The new global covering dual has mass `P-nu(C_j)+P_Nj>=P`. Hence

`nu(C_j)<=P_Nj`, `0<=sigma_j<=min(P-m_j,P_Nj-m_j)`.

Multiplication of the actual alpha lower bound by nonnegative sigma and the exact dual identity therefore proves the stated fixed-p pressure inequality. It is not an incorrect reversal of the generic fixed-p deficit upper bound. U_nu is retained and only discarded as nonnegative; no fictitious positive credit is created.

## MAX endpoint and finite witnesses

On `[0,epsilon W]` the row pressure is the maximum of the global ratio `sigma_j/(P-m_j+epsilon W-t)` and the constant local ratio `sigma_j/(P_Nj+epsilon W_Nj-m_j)`. When P=m_j, sigma_j=0 and the global term is defined identically zero, including its otherwise ambiguous endpoint. The local denominator is positive. The caps above put both endpoint ratios at most one. Each pressure function is therefore continuous, convex and nondecreasing, with `f_(p,nu)(epsilon W)<=epsilon W`.

The fixed-p inequality gives `f_(p,nu)(d(p))<=d(p)`. Its convex chord to the endpoint proves `f_(p,nu)(t)<=t` for every `t>=d(p)` in that interval. Since Q(p) is continuous on compact P_delta, `d_star=max_p d(p)` is attained and is strictly below epsilon W. Thus d_star is a common supersolution for every feasible p and genuine whole optimal dual. This is the valid reason MAX may replace the older mandatory MIN support function.

The eligible MAX support formula has fixed row weights: W_Nj is a receiver-union bound, not a p-dependent sum. A finite family of verified optimal duals can be maximized. Using all vertices of their compact finite-cell optimal face is also valid: at fixed t the objective is convex piecewise-linear in the whole dual vector, so a maximum is attained at a vertex. No rowwise mixture of incompatible duals is used.

The iteration from zero is nondecreasing and bounded by d_star; every finite iterate is certified. Continuity gives the least fixed point in the limit, without a rate or permission to choose a later algebraic root. More concretely, if an attaining pair (p,nu) gives `F(x)>x`, the chord would be contradicted by d(p)<=x. Hence x<d(p), and monotonicity gives `F(x)<=f_(p,nu)(d(p))<=d(p)`. Every strict finite step therefore has a real owner witness. Keeping the last strict witness through a plateau, or any feasible owner at zero, requires no limiting optimizer.

## Measurable action and corrected fallback scope

For a fixed finite old family, packing/availability/atom-incidence patterns have finitely many Borel strata. Cube incidences, receiver-union volumes and translated measurable-image atom volumes are Borel in anchors (using Borel representatives modulo null sets). Canonical finite LP vertices, deterministic eligible ties, scalar evaluations and strict-step comparisons therefore define a Borel witness. Nonatomic coordinate cuts realize its volumes. Comparing its actual fixed-p Q against the old joint-B Q can only improve D and cannot invalidate the pressure certificate.

The near-minimum fallback is also mathematically legitimate as a Borel selection: rational atom-simplex allocations are countably dense, continuity gives their infimum Q_min, and the first index within positive tau exists. The final report correctly says this proves measurable near-optimal existence, **not** an effective finite computation of that countable infimum or a verifiable stopping rule. This corrected wording removes the only overstatement identified during review. The main finite pressure witness is independent of the fallback. Its optional `R tau` expense is explicitly allocated rather than hidden in the source tolerance.

## Complete gain and remaining gap

For the realized certificate x_k the selected actual entropy response has `Q'<=P-x_k`. Since old R>0,

`D=W-RQ'>=W-R(P-x_k)`.

The expectation relative to reachable Pi correctly retains the favorable `Pi-P_Z`, the static gap K, finite T_r and the `(R-T0)Pi` debit. The report does not replace actual alpha with a maximal linear packing, drop K, double-charge deletion, or infer a uniform positive cV margin from a nonzero scalar certificate. Its source-price warning is accurate: capture of old A_k concerns old mu, whereas a volume dual covers expanded C and need not assign A_k its old mass. A new cube-scale estimate is still required.

The old owner/shape-variation section also stays within its lawful domain: fixed-mu variations require moment/KKT saturation and full-owner feasibility, while fixed-volume shape changes preserve old score and W and affect net gain only through actual Q'. Isolated image collision reduction is not added again after fill.

## Finite evidence boundaries and stop

The simplex max-m free-price conclusion is explicitly limited to the older joint-B simplex selector. The non-simplex receiver example has real cubes/receivers and imposed eligibility, but no constructed old KKT/Euler history or near-score status. Its strict selector separation therefore does not refute or prove the actual near-score theorem. The two-component local test receives no independent old-source allowance. Selected r8 patterns are not a full r8 expectation; partition diagnostics remain floating, selector-dependent evidence. The low-R atomic fixture and its outside-successor-cap limitation remain visible. No already passed certificate or solver campaign was repeated here.

The geometric feasibility, endpoint, witness and full-budget signs above were independently checked from the frozen formulas. Prior bounded exact SymPy checks in this same review round verified the relevant algebra; no numerical scan, author-file edit, Git/API operation, PDF compilation or subdelegation was performed by this reviewer. Audit complete for the two hashes above. No blocking line remains, and no root-order closure is certified.
