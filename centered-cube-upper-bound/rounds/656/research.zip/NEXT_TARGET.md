# Next target: real eligible MAX exposure and unused load must pay the full cube gap

The general centered-cube n^(1/2+o(1)) weak (1,1) bound remains UNPROVED. Keep the R655 all-finite globally calibrated epsilon_*, genuine full owners, actual old entropy/KKT AC source, and finite independent Euler clones. All old/deleted input rows remain. Actual gain is D=E_growth-O+F+RS=W-RQ'. The target is E D>=cV-C L M, L=C0 sqrt(n) polylog(n), with no label/scale/neighborhood count in its constants.

R655 calibration, lawful cloning and full feasible-cell exploration remain available. They make the ENTIRE high empirical correlation arbitrarily small at cost zeta V after fixing a finite near-score state and then choosing finite r. Do not reopen Gamma_good or repeat a bad-alpha expense. Positive exploration is selected before r; its limit cannot be interchanged with r→infinity. The original-input no-a^n restoration remains conditional on completing the real uniform gain.

## The action can select ownership for actual full gain

For each fixed tuple, keep the actual capture/image-priority eligible atoms, available rows and baseline Pdelta=delta p0+(1-delta)P, delta=.01. For every feasible p recompute the unique positive fixed-p entropy optimizer alpha(p); Q(p)=m.alpha(p) is continuous on compact Pdelta, so Qmin=min_p Q(p) is attained. Minimizing Q maximizes W-RQ, pointwise at fixed W,R.

The older joint-B owner selector is a legal backup, not a mandatory restriction. Its free minimum-u' property and its joint-source-dual equality are NOT available for the new selector. Fixed-p entropy KKT, real packing, the score bridge, normalization, all-N kappa_next<=4, old-score preservation and finite-cell Gamma control all survive.

There is no need to solve the nonconvex min-Q problem to realize the certificate below. Every strict finite MAX-pressure step produces an actual feasible owner witness whose fixed-p optimizer has at least that deficit. Keep the last strict witness, compare its actual Q with the old joint-B pair and take the smaller one. This is a genuine finite Borel action, not an infinite optimizer. A measurable rational-dense tau-near-minimum fallback also exists and costs at most R tau; tau=zeta V/R assigns that cost explicitly. The countable-infimum argument proves Borel near-optimal existence, not an effective finite computation of the infimum or a finite-search stopping criterion; the main finite pressure-witness action does not require this fallback. No claim that a small iteration increment bounds error to the limiting root is made.

## Proved finite-tuple quantitative theorem

Freeze a genuine tuple. Let P=P_Z be linear packing on its ACTUAL available expanded cubes, Q'=m.alpha, and d=P-Q'. Let nu be a whole optimal AC linear packing dual on positive-volume cells, mass P, and set

    sigma_j=nu(Cj)-m_j>=0,
    U_nu=int(1-load_alpha)dnu>=0,
    d=U_nu+sum sigma_j alpha_j.

Nu is neither the old source nor the entropy KKT source. For the positive-volume C-intersection neighborhood N_j define its true restricted linear value P_Nj and true receiver-union volume W_Nj. The legal replacement packing sets beta_j=1, retains alpha outside N_j, and clears the other neighbors. Fixed-p first order gives

    g_j=m_j+epsilon p_j/alpha_j
       <=min(Q'+epsilon W, P_Nj+epsilon W_Nj),
    alpha_j>=epsilon p_j / D_j(d),
    D_j(t)=min(P-m_j+epsilon W-t, P_Nj+epsilon W_Nj-m_j).

The exact optimal-dual local replacement proves nu(Cj)<=P_Nj: remove nu|Cj (outside-neighborhood demands are unchanged a.e.) and add a restricted-neighborhood optimal AC dual. Hence

    sigma_j<=min(P-m_j,P_Nj-m_j).

This is what validates uncapped neighborhood MAX; a hypothetical local denominator without this proof would not suffice. All these neighborhood quantities are row pressure bounds in ONE whole dual account, not separate M charges.

Put w_j,nu(t)=sigma_j/D_j(t), with any P-m_j=sigma_j=0 global term defined identically zero at the endpoint. For fixed feasible p,

    f_p,nu(t)=epsilon sum p_j w_j,nu(t)

is convex, continuous and nondecreasing on [0,epsilon W], and f_p,nu(epsilon W)<=epsilon W. Actual d(p)<min(P,epsilon W) and d(p)>=f_p,nu(d(p)). Convex chords imply f_p,nu(t)<=t for every t>=d(p) up to epsilon W. Thus d*=max_p d(p) is a supersolution for the MAX support map

    U_Z(w)=delta p0.w+(1-delta)sum_T |T| max_{j in J(T)} w_j,
    F_Z(t)=max_whole_optimal_duals epsilon U_Z(w_nu(t)).

A finite verified dual family is enough; all vertices give the full compact-face maximum. MAX over duals is convex maximization/finite enumeration, not the old MIN version's single LP. Do not combine rowwise slacks from incompatible duals.

The iteration x0=0, x_(k+1)=F_Z(xk) is nondecreasing and <=d*. Its limit is the LEAST fixed point, not an arbitrary larger algebraic root. Every strict step F_Z(x)>x has an attaining feasible pair (p,nu) with actual d(p)>=F_Z(x): otherwise the chord property contradicts strict increase. This supplies a finite owner witness; after a plateau retain the preceding strict-step witness. No actual alpha is an input to F_Z, although realizing that owner still requires actual fixed-p entropy optimization. The older mandatory-MIN certificate remains valid but is a weaker comparison, not the main candidate objective.

U_nu is retained in the exact theory. A zero conservative certificate does not mean actual deficit is zero. No root-order lower bound for exposure, iterations or U_nu has yet been proved.

## The exact unclosed global payment

Let Pi be reachable TRUE-cube linear volume packing, T0=T_infinity(0), K=T0 Pi-Wreach>=0, and T_r=Wreach-E W_r>=0. Since P_Z<=Pi, the actual net identity is

    E D_r=R(Pi-E Q'_r)-(R-T0)Pi-K-T_r.

The realizable finite witness gives the sufficient lower certificate

    E D_r>=E[W-R(P_Z-xk)]
          =R E[(Pi-P_Z)+xk]-(R-T0)Pi-K-T_r,

with only the stated optional -R E tau expense for a tau-approximate selector. Keep the favorable sampling/availability gap Pi-P_Z, K AND finite T_r. Static max packing cannot replace the actual entropy advantage: Wreach<=T0 Pi, so its pure term is nonpositive for R>T0. That is a conditional strength screen, not a constructed near-score counterexample.

The next actual theorem must show that real cube eligibility/coverage permits enough MAX reduced-cost exposure and/or unused dual load to make this entire expression >=cV-C L M, or produce an equally complete actual trial-owner estimate. Merely knowing a positive finite certificate, counting contacts, proving a Hall identity, or re-expanding a KL formula does not pay K or the leading cV margin. Actual capture A_k subset C_j concerns old mu(Ak)=mk; a minimum volume dual only covers expanded C and need not give nu(Ak)>=mk. This source-price mismatch remains a concrete missing geometric implication. Large neighborhoods cannot be bounded by one row's m without proof.

## Genuine connection limits and evidence scope

Old owner volume changes require their actual old optimizer/source response and receiver-Hall feasibility. On the legal fixed-mu/full-owner slice, m fixed and saturation imply Q_w=M-epsilon V=Q; only the constrained h-cost varies. Volume-preserving piece-shape changes leave old score and coupled W unchanged, with D_new-D_old=-R(Q'_new-Q'_old). Reduced image collisions and fill cancel directly, so a partition must lower actual Q or improve actual deficit; old score stationarity alone supplies no nonzero price on these shape directions.

The exact finite tests support the theorem's direction, not a general dimensional bound. The common-simplex max-m owner rule holds only for the older joint-B selector. The non-simplex model uses real cubes and their C/a receivers but imposed receiver-coverage/capture eligibility; no old KKT/Euler history is constructed. In it min-Q chooses the opposite owner endpoint from joint B, with rigorous 0.0899<Q_B-Qmin<0.09. Global MAX k8 is about .120291528675, compared with old MIN .030345920518, with exact Fraction/KKT brackets. Two separated copies verify the uncapped neighborhood MAX value 7173/30200 below actual deficit; this is not a shared old-source construction. Four r8 patterns are not an r8 expectation. Cyclic partition tests are floating decision evidence only and do not certify strict mean changes or a positive-width/global-epsilon_* result.

The next round should directly attack the actual cube MAX-exposure/unused-load full budget. Do not spend another round merely deriving this certificate, redoing Gamma elimination, or asserting that the old joint-B minimum-price selector must remain fixed. Any recursive alternative still needs actual same-parameter states, all future O/F/S, normalization weights and controlled endpoint/terminal costs.
