"""Verify archive bytes, TeX references, and portable finite certificates; no PDF build."""
import argparse, ast, hashlib, json, re, subprocess, sys, tempfile, shutil
from pathlib import Path
root=Path(__file__).resolve().parent
parser=argparse.ArgumentParser();parser.add_argument('--replay',action='store_true');args=parser.parse_args()
manifest=json.loads((root/'manifest.json').read_text())
for name,expected in manifest['files'].items():
    path=root/name
    assert path.is_file(),name
    assert hashlib.sha256(path.read_bytes()).hexdigest()==expected,name
for path in (root/'numeric').glob('*.py'):
    ast.parse(path.read_text(),filename=str(path))
tex=(root/'REPORT.tex').read_text()
labels=re.findall(r'\\label\{([^}]+)\}',tex)
assert len(labels)==len(set(labels)), 'duplicate labels'
refs=re.findall(r'\\(?:eqref|ref)\{([^}]+)\}',tex)
assert set(refs)<=set(labels), sorted(set(refs)-set(labels))
assert '\\begin{document}' in tex and '\\end{document}' in tex
result={'verified_files':len(manifest['files']),'tex_labels':len(labels),'pdf_compiled':False,'replayed':[]}
if args.replay:
    with tempfile.TemporaryDirectory(prefix='ccu-r656-portable-') as tmp:
        dst=Path(tmp)/'numeric';shutil.copytree(root/'numeric',dst)
        for script,output in [('owner_profile.py','owner_profile.json'),('selector_certificate.py','selector_certificate.json'),('verify_owner_certificate.py','verify_owner_certificate.json')]:
            run=subprocess.run([sys.executable,str(dst/script)],cwd=tmp,capture_output=True,timeout=120,check=True)
            assert run.stdout==(dst/output).read_bytes(), script+' output mismatch'
            result['replayed'].append(script)
result['scope']='Finite rational and recorded numerical certificates only; no CVXPY optimization rerun and no general-dimensional theorem certification.'
print(json.dumps(result,ensure_ascii=False,indent=2))
