# R656 最终独立全账审核

**PASS，限定于有限元组定理、可实现选择器及完整预算的正确整合；无阻塞项。一般 root-order 弱型上界、统一正 cV 增量与受控递推仍未证明。**

## 冻结绑定

已实际读取全文、最终 NEXT、修订 fallback 和归档 NUMERIC_AUDIT，并重算文件 SHA-256：

| 文件 | SHA-256 |
| --- | --- |
| `/tmp/ccu_r656/REPORT.tex` | `73b82672bc967d996b2561afd623cb428084bc8baf956d6ebfc6514613461568` |
| `/tmp/ccu_r656/NEXT_TARGET.md` | `c69d2968de2572c57aad8d997674dc2670ffa213bf1d60495aec28609f10b237` |

本结论从正文定义与下列代数／可行性独立判断，不依赖未归档工作稿；没有扩扫描或重跑历史 CVXPY。

## 有限压力与 MAX 转移 — PASS

线性 dual、旧 mu 和 entropy KKT source 被正确区分。对一份 whole optimal AC linear dual，精确地

`d=P-Q'=U_nu+sum sigma_j alpha_j`，`U_nu>=0`。

fixed-p first order 可由正 alpha 到 boundary vector 的线段合法使用，给 `d<min(P,epsilon W)`。局部比较向量取 j 权重 1、保留 N_j 外 alpha、清空其它邻居，确实 a.e. 可行，给真实 `P_Nj+epsilon W_Nj` 分母。局部 dual cap 也成立：删去 nu|Cj 不损 outside-neighborhood 需求，再加 restricted optimal dual，全局最优性强制 `nu(Cj)<=P_Nj`。因此 sigma 的全局／局部上界及终端压力<=1均有实际依据，没有一份 M 每邻域。

固定 p 的 f_p,nu 连续、凸、非减，满足 `f(d(p))<=d(p)`、`f(epsilon W)<=epsilon W`；凸弦故给所有 `t>=d(p)` 的 `f(t)<=t`。所以 d*=max_p d(p) 是 eligible-owner MAX／whole-dual MAX 的共同 supersolution，迭代从零非减且<=d*。P=m_j 时 sigma_j=0 的终端约定正确。

每个严格步 F(x)>x 的 attaining pair (p,nu) 若 d(p)<=x 将违反凸弦；否则由单调性 `F(x)<=f(d(p))<=d(p)`。这认证真实有限 owner witness，不是把较大代数根强塞给 actual deficit。plateau 保留上一严格 witness；无严格步取任意合法 owner。有限 dual face 非负且总 mass=P，故紧、vertices 有限；没有拼接不兼容 dual 的逐行 slack。

## Selector、baseline 与费用 — PASS

P_delta 的正 baseline、packing 紧性和 log barrier给 alpha(p)、Q(p) 连续，min Q 真达到。所有输出仍为实际 capture/image-priority full owners，固定 p 下重算真实 entropy optimizer。新规则逐 tuple 不劣于旧 joint-B，但不继承 free min-u'／旧 bottleneck 等式／实际 joint-B dual 等值；正文只在明确的 legacy 段使用这些性质。

finite exposure witness 的 atom allocation、whole dual、有限 tie、nonatomic cuts 和实际 reoptimization给 Borel action；与旧 pair 比较选小 Q 同时保留 `d>=x_k`、`D>=D_B`。

最终 fallback 已改为 **measurable**：countable infimum证明 Borel tau-near-optimal existence，不是 effective finite q_* computation 或 finite-search stopping。main finite witness 不依赖 fallback。tau>0 的唯一近优损失是 `R tau`；`tau=zeta V/R` 恰为 zeta V。小迭代增量不被当成 limiting-root gap。以上不假设 Q(p) 凸。

## 完整净账与一次势能回代 — PASS

完整对象保持 `D=E-O+F+RS=W-RQ'`，所有 old/deleted tags、真实 loss/fill 与固定 epsilon_* 均保留。全 N 校准在有限 near-score 状态／复制前固定；后继 kappa'<=4。整项 high Gamma 的有限-cell控制适用于这些新适应选择器，不再另付 bad-alpha，low tags 不误归一。source/exploration 容差分配及先固定正 xi、后选有限 r 的次序保留。

实际 available linear value P_Z<=reachable true-cube Π，故 witness 精确给

`D>=W-R(P_Z-x_k)`，

`E D_r>=C_r:=R E[(Pi-P_Z)+x_k]-(R-T0)Pi-K-T_r`。

Pi-P_Z 有利，K 与 T_r 是负费用；均未丢失。Π／P_Z 不是 actual entropy optimizer。U_nu只被舍作非负，未被称为已付；零压力也不推出零实际 deficit。

若用 tau fallback，再减 `R E tau`。一次 score 回代的可用期望量是

`E[D_sel-4L Q'_sel]>=C_r-R E tau-4LM`。

该量若严格超过总 near-score 容差 eta·M，先选 favorable tuple，再取任意实际 next AC source，即可使用 score bridge；不需要可测 next-source kernel。finite witness 本身无 tau 费。若另从 tagged A_r 而非直接 D 估计，才扣实际使用的整项 Gamma 误差；T_r 若已在 C_r 内不得再收费。theta kappa L、xi kappa L 计入 old near-score 精度，一份最终 4LM不逐 clone/cell/step 重付。

正文没有提供使上式超过所需 margin 的统一几何下界。仍缺 actual eligible MAX exposure／unused load 联合 coverage，支付 `(R-T0)Pi+K+T_r` 并留下 cV。capture 只约束旧 mu，不能推出 linear dual nu(Ak)>=mk；大 neighborhood 也不能无证明由一行 m 支付。fixed-mu/full-owner variation只能保持旧 Q，shape stationarity不提供免费新 deficit。这些边界表述正确。

## 数值绑定与结论范围 — PASS

实际重算的六个 numeric SHA（owner_profile、selector_certificate、verify_owner_certificate 各 py/json）全部匹配正文最终清单。归档 NUMERIC_AUDIT 与正文用途一致；本审核者没有冒称新重放其 numerical campaigns。

已核 atomic r2 entropy separation按原范围保留；legacy common-simplex最大-m规则未推广到新选择器。non-simplex三 interval 模型及两分离 copies均是实际有限 C/receiver 程序，但 capture eligibility是 imposed 条件，没有旧 AC KKT／Euler 实现。selector gap、MIN/MAX iterates和局部 7173/30200 是此 conditional model 的精确证据，不是原 near-score/shared-source 定理。四个 r8 patterns不是完整 expectation；循环 partition 的微小 adverse均值仅浮点决策证据，残差不是 D error bars，无正宽/global 域结论。

另实际运行本机 SymPy核验 dual deficit 展开、凸弦端点、net certificate 和 tau normalization零残差；一般可行性与 MAX transfer由上述解析核验承担。

**最终 PASS：可按有限可实现 certificate 与未闭合几何目标交付；不能按一般弱型改善或完整正增量已证交付。** 最终解释自足，不需未归档工作稿。仅写本审计，未改作者文件，未用 Git/API/PDF/子代理；交付后停止。
