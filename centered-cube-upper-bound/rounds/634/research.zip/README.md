# R634：完整增长与新容量联合预算

一般 n^(1/2+o(1)) 弱型上界尚未证明。REPORT.tex 是本轮统一数学报告；不编译 PDF。未证目标始终为同一个 D=V*−(V/Q)Q* 的统一净下界。R634 是 R634–R636 三轮决策窗口的第一轮，本轮不计完整预算突破。

独审文件区分完整终端、实际交通付款和仍未证明的联合价格。旧来源不是产品分布；新 Tν 的条件目标才是产品均匀。返回真实接收交通时 e_j/ε 和完整增长价格不能省略。

复现：

    /Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python check_ledger.py
    OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1 /Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python numeric/verify.py

可换任意兼容 Python+SymPy 解释器；代码不依赖本机绝对路径。LEDGER_CHECKS.json 与 numeric/ROOT_CHECKS.json 是实际执行结果。前者只认证符号恒等式与有限有理控制，后者只认证所列输入与回归，不外推一般维数或任意程序输入。

数值引擎的两处根隔离漏检已修复；旧 R633 的30个中心重新隔根并由独立检查器复核通过。旧历史包保留，不能继续将旧引擎用于新证书。新引擎无法在给定位数预算内分离根时抛错，不能将计算未决误报为无坏区间。

SOURCE_AND_COMPUTE.md 记录文献适用范围、工具实际使用和计算任务决策。MANIFEST.json 按白名单逐文件列哈希。未收录缓存、重复作者工作稿、可重建完整日志或 PDF。
