# R634 exact numeric regression package

Run from this directory with Python 3 and SymPy (tested Python 3.12.14, SymPy 1.14.0):

    OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1 python verify.py

On this machine use /Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python as the Python executable. The verifier deletes any prior ROOT_CHECKS.json at startup, raises on failure, and writes a fresh summary only after success. It runs the six rational controls (12 centers, canonical radius 2113/2112), the real two-dimensional narrow-root example (radius 1+2^−51), seven named edge regressions, and six R633 inputs (30 centers). The engine recomputes radii; independent.py rebuilds source-box polynomials and verifies strict inner radii and all future outer caps by exact rational root isolation, coefficients, root isolation and radius ratios. A synthetic even-multiplicity regression tests sign handling and is not claimed to arise from a source box. Fail-closed precision exhaustion is checked. These finite tests are not a general proof of the algorithm or a dimension bound.

old_failure_evidence.json records the genuine source and earlier incorrect not-in-E result: two nondegenerate isolators meet at 1, where the excess is 2^−100. The fixed engine refines overlapping or touching adjacent isolators as well as boundary-touching ones; it throws if its finite precision budget cannot resolve the configuration.

Included: radius_engine.py, independent.py, verify.py, regression.py, 13 JSON inputs, old_failure_evidence.json, and ROOT_CHECKS.json. No absolute path is required by the code. The stored summary is the primary agent's actual rerun: 0.732 s wall, 0.521 s parent CPU, maximum parent RSS 74,448,896 bytes. Subprocess CPU is not included in that parent CPU field. Per-run versions, input hashes, engine hash and counts are in ROOT_CHECKS.json.
