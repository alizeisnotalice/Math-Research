#!/usr/bin/env python3
"""Finite exact regressions; failures raise and this is not a general proof."""
import contextlib,io,json,platform,resource,subprocess,sys,time,hashlib
from pathlib import Path
import sympy as sp
import radius_engine as eng
from independent import intervals,check,S,r
if not __debug__: raise RuntimeError('Run without python -O: verification uses assertions')
HERE=Path(__file__).resolve().parent
(HERE/'ROOT_CHECKS.json').unlink(missing_ok=True)
start=time.perf_counter(); cpu=time.process_time()

def source_data(path):
 d=json.loads(path.read_text()); src=[([(eng.Q(a),eng.Q(b)) for a,b in q['box']],eng.Q(q['density'])) for q in d['sources']];return d,src

def verify_input(path,expected=None):
 d,src=source_data(path);count=0
 for center in d['centers']:
  z=eng.solve_center(list(map(eng.Q,center)),src,d['dimension']); assert z['status']=='certified', (path.name,center,z['status'])
  rm,rp=map(S,(z['r_minus'],z['r_plus'])); assert S(z['ratio_power'])==(rp/rm)**d['dimension']
  ps=intervals(d,center); rl,rh=map(S,z['last_root_interval']);assert rm<=rl<=rh<=rp
  q=next(q for a,b,p,q in ps if a<=rl and rh<=b)
  assert q.eval(rl)==0 if rl==rh else q.count_roots(rl,rh)==1
  for seg in z['segments']:
   lo,hi=map(S,(seg['left'],seg['right']));mid=(lo+hi)/2
   a,b,p,q=next(t for t in ps if t[0]<=mid<t[1]);assert lo>=a and hi<=b
   assert sp.Poly.from_list(list(map(S,seg['coefficients'])),r)==q and q.degree()<=d['dimension']
  with contextlib.redirect_stdout(io.StringIO()):check(d,center,str(rm),str(rp))
  if expected is not None:
   R=S(expected);q=next(q for a,b,p,q in ps if a<=R<=b);assert q.eval(R)==0
   with contextlib.redirect_stdout(io.StringIO()):check(d,center,str(rm),str(R))
  count+=1
 return count

cases=['half','near','tangent','apart','half_width','apart_width']
summary={}
summary['six_controls']={name:verify_input(HERE/'inputs'/f'{name}_input.json','2113/2112') for name in cases}
summary['adjacent_root_2d']=verify_input(HERE/'inputs'/'adjacent.json',str(S(1)+S(1)/2**51))
summary['r633_30_centers']={f'n{n}_v{v}':verify_input(HERE/'inputs'/f'input_n{n}_v{v}.json') for n in (2,3,7) for v in (0,1)}
proc=subprocess.run([sys.executable,str(HERE/'regression.py')],capture_output=True,text=True,check=True)
lines=[x for x in proc.stdout.splitlines() if ' PASS' in x];assert len(lines)==7,proc.stdout
summary['seven_regressions']=lines
result={'status':'PASS','scope':'finite exact regression; not a general proof','checks':summary,'python':sys.version,'sympy':sp.__version__,'platform':platform.platform(),'command':'OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python verify.py','wall_seconds':time.perf_counter()-start,'cpu_seconds_parent':time.process_time()-cpu,'max_rss_parent_raw_platform_units':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'input_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((HERE/'inputs').glob('*.json'))},'engine_sha256':hashlib.sha256((HERE/'radius_engine.py').read_bytes()).hexdigest()}
(HERE/'ROOT_CHECKS.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
