#!/usr/bin/env python3
"""Piecewise exact last strict-bad radius for rational box-density mixtures."""
import json,sys,time,resource,hashlib
import sympy as S
r=S.Symbol('r')
def Q(x):
 if isinstance(x,(float,bool)):raise ValueError('floats and booleans forbidden')
 return S.Rational(str(x))
def polynomial(c,sources,n,L,U):
 z=(L+U)/2; total=S.S.Zero
 for box,d in sources:
  prod=S.S.One
  for x,(a,b) in zip(c,box):
   left=max(a,x-z); right=min(b,x+z)
   if right<=left:prod=S.S.Zero;break
   prod*= (b if b<x+z else x+r)-(a if a>x-z else x-r)
  total+=d*prod
 return S.Poly(S.expand(total-(2*r)**n),r,domain=S.QQ)
def solve_center(c,sources,n):
 mass=sum((d*S.prod(b-a for a,b in box) for box,d in sources),S.S.Zero)
 cuts=sorted({S.S.Zero}|{abs(x-t) for box,d in sources for x,(a,b) in zip(c,box) for t in (a,b)})
 H=max(cuts)+mass+2; cuts.append(H); pieces=[(L,U,polynomial(c,sources,n,L,U)) for L,U in zip(cuts,cuts[1:]) if L<U]
 for step in range(3,257):
  eps=S.Rational(1,2**step); records=[]; positive=[]; retry=False
  for L,U,p in pieces:
   if p.is_zero:
    records.append({'left':str(L),'right':str(U),'coefficients':['0'],'zero':True,'roots':[],'bands':[]});continue
   roots=[]
   for (a,b),mult in S.polys.polytools.intervals(p,eps=eps):
    if b<L or a>U:continue
    if a<b and (a<=L<=b or a<=U<=b):retry=True;break
    if a==b and (a==L or a==U):continue
    if a>=L and b<=U:
     if roots and a<=roots[-1][1]:retry=True;break
     roots.append((a,b,mult))
   if retry:break
   bounds=[L]+[v for a,b,k in roots for v in (a,b)]+[U]; bands=[]; cursor=L
   for a,b,k in roots+[(U,U,0)]:
    if cursor<a:
     sample=(cursor+a)/2; v=p.eval(sample); sign=S.sign(v)
     if sign==0:raise RuntimeError('unisolated root in root-free band')
     bands.append([str(cursor),str(a),int(sign)])
     if sign>0:positive.append((L,U,p,cursor,a,b,k))
    cursor=b
   records.append({'left':str(L),'right':str(U),'coefficients':list(map(str,p.all_coeffs())),'zero':False,'roots':[[str(a),str(b),k] for a,b,k in roots],'bands':bands})
  if retry:continue
  if not positive: return {'status':'center_not_in_E','breakpoints':list(map(str,cuts)),'segments':records,'tail_start':str(H),'tail_mass':str(mass)}
  L,U,p,left,edge,root_hi,k=positive[-1]
  if k: # right endpoint is an isolated algebraic zero
   if edge<root_hi and p.eval(edge)>0: minus=edge
   else:minus=edge-eps
   plus=root_hi+eps; kind='isolated_root'; final=[str(edge),str(root_hi)]
  else:
   minus=edge-eps;plus=edge+eps;kind='breakpoint';final=[str(edge),str(edge)]
  if minus<=left or p.eval(minus)<=0 or plus<=minus or (plus/minus)**n>S.Rational(101,100):continue
  return {'status':'certified','r_minus':str(minus),'r_plus':str(plus),'root_kind':kind,'last_root_interval':final,'inner_excess':str(p.eval(minus)),'ratio_power':str((plus/minus)**n),'breakpoints':list(map(str,cuts)),'segments':records,'tail_start':str(H),'tail_mass':str(mass),'tail_formula':f'{mass} - (2*r)**{n}'}
 raise RuntimeError('could not separate roots/cost after refinement')
def main():
 start=time.perf_counter(); cpu=time.process_time(); raw=open(sys.argv[1],'rb').read(); data=json.loads(raw);n=data['dimension']; sources=[]
 for s in data['sources']:
  box=[(Q(a),Q(b)) for a,b in s['box']];d=Q(s['density'])
  if len(box)!=n or d<0 or any(a>=b for a,b in box):raise ValueError('invalid source')
  sources.append((box,d))
 if n<1 or not sources:raise ValueError('invalid dimension/source')
 cs=[[Q(v) for v in c] for c in data['centers']]
 if any(len(c)!=n for c in cs):raise ValueError('bad center')
 result={'input_sha256':hashlib.sha256(raw).hexdigest(),'dimension':n,'centers':[]}
 for c in cs:result['centers'].append({'center':list(map(str,c)),**solve_center(c,sources,n)})
 result['run']={'python':sys.version.replace('\n',' '),'sympy':S.__version__,'cpu_s':time.process_time()-cpu,'wall_s':time.perf_counter()-start,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
 print(json.dumps(result,indent=2))
if __name__=='__main__':main()
