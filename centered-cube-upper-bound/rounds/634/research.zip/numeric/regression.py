#!/usr/bin/env python3
import importlib.util, json, sys, subprocess, tempfile, time, resource
from fractions import Fraction as F
from pathlib import Path
start=time.perf_counter();cpu=time.process_time();here=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('radius_engine',here/'radius_engine.py');eng=importlib.util.module_from_spec(spec);spec.loader.exec_module(eng)
def run(c,s):return eng.solve_center([eng.Q(c)],[( [(eng.Q(a),eng.Q(b))],eng.Q(d)) for a,b,d in s],1)
# Exact root at geometric breakpoint r=2.
z=run(0,[(0,1,3),(1,2,1)]);assert z['status']=='certified' and z['last_root_interval']==['2','2'] and F(z['r_minus'])<2<F(z['r_plus']);print('breakpoint_root PASS',z['last_root_interval'])
# Real 2D box: two extremely close roots in a piece whose isolators meet at 1.
d=json.load(open(here/'inputs'/'adjacent.json'))
src2=[([(eng.Q(a),eng.Q(b)) for a,b in q['box']],eng.Q(q['density'])) for q in d['sources']]
z=eng.solve_center([eng.Q(x) for x in d['centers'][0]],src2,2)
expected=F(1)+F(1,2**51)
assert z['status']=='certified' and list(map(F,z['last_root_interval']))==[expected,expected]
assert F(z['r_minus'])<expected<F(z['r_plus']) and F(z['inner_excess'])>0
print('real_adjacent_isolators PASS',z['last_root_interval'])
# If precision cap cannot separate an even narrower genuine pair, raise; never emit a negative diagnosis.
extreme=[([(eng.S.Rational(1,2)-eng.S.Rational(1,2**603),eng.S.Rational(3,2)),(eng.S.Rational(-1,4),eng.S.Rational(1,4))],eng.S.Integer(16))]
try:
 eng.solve_center([eng.S.Integer(0),eng.S.Integer(0)],extreme,2)
except RuntimeError as e:
 assert 'could not separate' in str(e);print('precision_exhaustion_raises PASS')
else:raise AssertionError('expected bounded refinement failure')
# Positive narrow band and isolating bound coinciding with a source breakpoint: real R634 source.
x=json.load(open(here/'inputs'/'half_input.json'));src=[( [(eng.Q(a),eng.Q(b)) for a,b in q['box']],eng.Q(q['density'])) for q in x['sources']];z=eng.solve_center([eng.Q(0)],src,1);assert z['status']=='certified' and z['last_root_interval']==['2113/2112','2113/2112'];print('narrow_breakpoint_isolator PASS',z['last_root_interval'])
# Equality plateau is not a strict bad region, and all later radii remain nonpositive.
z=run(0,[(-1,0,2)]);assert z['status']=='center_not_in_E' and any(t['zero'] for t in z['segments']);print('zero_platform_no_strict_bad PASS')
# Deliberate synthetic piece polynomial: repeated even root touches 0 but never >0.
# Unit test for the sign/isolator stage, not a claim this polynomial arose from a source box.
orig=eng.polynomial
eng.polynomial=lambda c,sources,n,L,U: eng.S.Poly(-(eng.r-1)**2,eng.r,domain=eng.S.QQ)
z=eng.solve_center([eng.Q(0)],[([(eng.Q(1),eng.Q(2))],eng.Q(1))],1);eng.polynomial=orig
assert z['status']=='center_not_in_E';print('synthetic_even_root_contact PASS')
# Tail formula is exact beyond H: finite source mass and strictly negative excess.
z=run(0,[(0,1,3),(1,2,1)]);H=F(z['tail_start']);M=F(z['tail_mass']);assert H>2 and M-2*H<0 and M-2*(H+1)<0;print('complete_tail PASS')
print('python',sys.version.replace('\n',' '),'sympy',eng.S.__version__,'cpu_s',time.process_time()-cpu,'wall_s',time.perf_counter()-start,'rss_bytes',resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
