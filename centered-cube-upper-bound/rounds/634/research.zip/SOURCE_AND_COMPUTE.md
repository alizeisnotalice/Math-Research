# 来源与计算账目

- R619 正则 packing 的真实 L1 KKT 来源构造为继承工具；本轮没有重新认证其全部历史证明。R633 的 Hall 双接收及 cross 乘积边缘为继承工具。R634 在相同来源与完整族上证明新增命题。
- Bourgain, *On the Hardy–Littlewood maximal function for the cube*, arXiv:1212.2661，primary：https://arxiv.org/pdf/1212.2661 。本轮读取 PDF 开头及定理（第3页），核对每个 p>1 的维数无关强 Lp 范围；未声称通读全部20页。本轮仅把 p=2 用于有界 packing potential Lν，未用于任意 L1 来源端点。
- 使用用户64项数学工具中的 D01（正测度输运模型/边缘不可互换）、L03（有理及区间证书方向）、N04（可求和费用与真实终端）。技能是方法约束，不是新命题认证；未套用向量KR、路径律或未经条件核验的黑箱定理。
- 实际本机解释器：/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python；Python3.12.14，SymPy1.14.0。root重跑 numeric/verify.py 和 check_ledger.py。numeric/ROOT_CHECKS.json 与 LEDGER_CHECKS.json 保存本次实际结果、版本、输入哈希。没有本轮 MATLAB 执行、Arb 区间扫描、SDP 证书或 PDF 编译。
- exact radius 是有理多项式根隔离；不是浮点网格。历史失败 JSON 只保留最小错误输出证据；最终引擎/独立检查器各自重建并检验半径。有限回归不证明任意输入的一般正确性。
- CPU实查为15逻辑核心、24GiB物理内存。此次精确验证总耗时小于一秒，串行运行；没有谎称满载。用户最新偏好允许尽量用满机器，因此后续计算不设固定预留核心或内存比例；按实际输入分块、外存、动态并发。有明确科学判别目标后才展开，无候选桥时不以重复扫描制造负载。
- 额度未取得可归属本轮的扣额数据，因此不猜测模型成本比例。协作复用了3个Astra xhigh（同一D的不同职责）、Sol high独审/回代、Terra精确实现与独立复现；完成者不计为正在计算。
