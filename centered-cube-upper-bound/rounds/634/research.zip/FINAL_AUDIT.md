# R634 整合报告最终全局回代审核

审核对象：`/tmp/ccu_r634_final/REPORT.tex`。先按本支独立推导核查全局链，再对照 `/tmp/ccu_r634/transport_audit.md` 的新通过项；只写本文件，不改报告或仓库。

**审核结论：未发现实质数学回代错误；已证明的结构、部分交通付款与条件性终端链通过。完整 (U) 仍未证明，本审核不认证一般根阶弱型上界。** 唯一文字勘误（首节 n 与 a 的范围写法）已即时告知主代理并已修正为“n≥1 与 a≥32n”；各计算均按这个明确条件审核。主代理确认没有其他数学内容修改。

## 1. 一般 f 的入口与辅助来源权限

一般非负 L1 输入在阈值 1 的严格坏域中，每点可取一个同心严格平均见证 A_x，B_x=A_x/a 仍包含该点；紧集有有限开子覆盖。固定序生成真实 increments 并删去零体积标签，不改变 receiver union 至零测集。任何原族 packing λ 均满足 Q≤∫fLλ≤||f||1。因此**若**所有有限族 R=V/Q>6PH 被排除，则紧集体积≤6PH||f||1；固定半径卷积连续、内正则性、阈值齐次性及 |f| 恢复一般输入、全部正半径与真实 Lebesgue receivers。该论证不引入额外 selected-cover 系数。

报告正确区分原输入 f 与重新构造的真实 L1 辅助 μ。μ 的 canonical 大半径帽由 μ 自己的最后严格坏半径与径向连续性得到，没有转移原 f 的帽。以后 canonical family/packing 更新不要求它仍由最初 f 见证；条件 (U) 必须对全部更新 family 的辅助 KKT 来源统一成立，这一点在报告中保留。

## 2. canonical 全族与 D 完整净账

原 μ 满足 m_j>d_j，故最后严格坏半径非空、正且有限；L1 的径向连续性给 μ(A_j*)=|A_j*|，所有更大半径均有体积帽，并有 g_j=t_j^n≥m_j/d_j。每个 E_j* 是实际 I_j 的同中心 homothety，E_j*⊂B_j*，但并集通常不等于完整新 receiver union。报告保留了

\[
C_{\rm fill}=V^*-|\cup E_j^*|\ge0,
\qquad
D=(\mathcal A-RM)-O+R(M-Q^*)+C_{\rm fill}.
\]

该式准确。新完整线性 packing 的 Q*≤M 由旧 μ 的 canonical 接触积分得到，旧 λ 未被错误地放到新 stars。raw surplus 的分解

\[
\mathcal A-RM
=\epsilon[\sum v_j^2/(\lambda_jd_j)-V^2/Q]
 +\sum v_j(g_j-m_j/d_j)
\]

以及两项非负性均通过。报告没有把 Cfill 删掉后仍宣称等式，没有重复使用 raw surplus、RS 或新容量节省。

## 3. 固定 N 终端、K 与严格端点

KKT、m_j≤M 和 d_j≥a^nv_j 严格给

\[
QM\ge(\epsilon a^n/N)V^2,
\quad
R\le\frac{N}{2a^n}[1+\sqrt{1+4a^n/(\epsilon N)}].
\]

这是固定 a、ε、不增标签数时可沿迭代使用的真正有限终端，不必要求经典弱界满足 εPB_n<1。它不是最后维数界；仅有严格递增不够。报告使用的统一加性增幅足以撞破该终端，逻辑正确。

若未证的 (U) 确有统一 c>0、C≥0，则 H=KL_n、K≥max(32,8C/(3c))（L_n≥1）在 hard 分支给 D≥3cV/4。有限 open boxes 的正体积 clique 在足够接近的内缩中保持、且内缩不新增 clique，所以 packing polytope 最终稳定，Q*,-→Q*；有限 receiver union 体积也连续。取真实 deficit 误差≤cV/4，保持 D^-≥cV/2。旧 μ 对这些严格内近似 stars 可行，故 Qε'≤Q*,-≤M；新正行数不增，a、ε 不变。于是

\[
R'\ge R+D^-/Q^{*,-}\ge R+cV/(2M)
>R+3cPH/4.
\]

全部常数、分母替换的正号条件与 endpoint 误差均正确。报告没有将“可逼近”写成误差为零。故 (U) 的条件性充分性已成立，但这一终端修复本身不证明 (U)。

## 4. Γ′、owner 与不能删除的价格

全标签 Γ′ 的未归一质量、receiver 常数及 third-core noncollision 通过；不要求 J,K 独立。growth 下界使用 ρ 的 Jensen 与 Γ′ 两边缘，不是 growth 重加权后的边缘上界。其 balanced 下界由先控制 ∫√((1−e_J)(1−e_K)) 再 Cauchy 得到，同样成立。报告正确把它称为增长下界而不是 overlap 上界。

最大 canonical R* 的 owner partition 使 D_jk⊂I_k，Σ_jb_jk≤v_k；σ_jk 的总 source measure≤μ，且

\[
O=\epsilon^{-1}\sum_{jk}e_kg_k\sigma_{jk}(\mathbb R^n)
\]

是准确式。价格 e_kg_k/ε 仍在。moderate-parent t_j≤a/3 时 D_jk⊂A_j：由两条膨胀小 cube 的位置与 R_k*≤R_j* 可得 preimage 距 y_j<2R_j*/a−r_k<ar_j。固定 k 的 owner preimages 不交，再用 I_k 真实不交，得到

\[
\sum_{j:t_j\le a/3,k}\lambda_jb_{jk}
\le\int_U L_\lambda\le Q.
\]

但回到 O 的 g_k/λ_j 价格及非 moderate parents 没有被此界支付；报告明确保留。ζ 的 source 边缘为同一 μ，Dcov/Duncov/Cfill 分拆通过；可丢的是非负“未覆盖 source 的净保留增长”，不是用 S/ε 单独结算带 g 的 owner 损失。

## 5. transport、receiver 分支及新 L2 付款

独立展开 F_total=ε^-1∫F_old Lνdμ，得到 V−S/ε≤F_total≤V。固定 k 的真实 receiver 密度≤ν_k 及 small-ratio support 给 Fsmall≤eQ*；没有删掉 1/m_j 后误套体积界。Tν 的 source、target 边缘与总质量正确，接回 receiver 必须乘 e_j/ε，报告已显式保留，未将 target 密度≤1 免费移给 exposed receiver 流。Fleb≤Q/ε<V/3 和 signed Δtrans 的准确式均通过。

新 packing 的 blocker exchange 合法：删除全部正体积冲突，再加入 j 权1；open/正体积约定排除了边界容量问题。small-blocker 情形给真实全部 I_j 上的 centered maximal 阈值至少 (1/2)e^(−3/32)。输入强 L2 的是 0≤Lν≤1、∫Lν=Q* 的 packing potential，**不是任意 L1 来源 μ**。于是 C0=4e^(3/16)C2² 的整 receiver 付款正确。另核 [Bourgain 原文 PDF](https://arxiv.org/pdf/1212.2661) 第3页定理：cube maximal 的强 Lp 常数对 p>1 与维数无关，足以提供这里的 p=2 常数；未据此声称端点弱型维数无关。

在同一 F 中按 union 删掉 J0 行与 small pairs，余量≥V−S/ε−(e+C0)Q*；即使两部分相交，扣两上界只使下界更弱。报告明确警告这些付款不默认互斥，未把它们各自从 V 扣掉后重复算收益。剩余 j 的 large blockers 是一个行冲突条件；blocker 标签不能自动等于交通目标标签，更不是已付列容量。与 transport_audit 新附审结论一致。

## 6. source-clique 所谓“条件均值”的准确含义

本节必须读作**冻结 k 与真实 X 后，对产品均匀 target Y 作显式坐标替换积分**。准确对象为

\[
G_i^k(X)=\sum_j\lambda_je_j1_{A_j}(X)
                    \prod_{\ell>i}p_{jk\ell},
\quad \delta_{ki}(X)=G_i^k(X)-G_{i-1}^k(X).
\]

因为只保留包含 X 的旧标签，固定坐标将相应 p 从 [0,1] 改为1，故 δ≥0、Σδ≤F_old(X)≤1，进而 source 加权平方积分≤Q*。它不是 μ 过滤下的零均值或正交 martingale difference；μ 无坐标产品性。报告上下文和公式限定在 Y|k 的产品均匀上，并没有使用 μ 鞅解释。

准确连接为 I=εΔtrans+Remainder，Remainder≥0；该余项不是零，不能把 δ 和直接称为 signed 交通。回到 receiver 要除 ε，回到 D 仍要保留 g_j(1−h_j) 或 g_jh_j；平方对应 ε^-2 价格。报告没有用无价 Σδ_i²≤1、trace 或错误 source L2 投影证明根阶净收益。

## 7. 实际数值证据与范围

本审只读主代理实际运行收据，未伪称自己重放：`LEDGER_CHECKS.json` 为 PASS（4 项符号恒等式、精确 D/M 控制与必要 N 筛查）；`numeric/ROOT_CHECKS.json` 为 PASS（12+1+30=43 个中心及7项回归，含精度耗尽抛错），记录 Python 3.12.14、SymPy 1.14.0、输入及引擎哈希。报告对约0.73秒主代理实跑、MATLAB 未执行、旧历史未改写的范围表述与收据一致。

一维控制的 a=H=32、ε=1/66、m=2113/1056、相交阈值 δ=1/1056 以及 D=m/32 对照代数一致；它不是 hard 分支。二维窄区间 G(r)=2^-100−4(r−1)^2 的最后根为 1+2^-51，亦准确。有限回归与身份检查不证明根隔离程序对任意输入正确，更不证明 (U) 或一般维数阶。必要标签数 N>(9/2)H(a+1)^n 从终端代入 hard 门槛严格推出，仅限制显式逐标签测试，不是一般算法复杂度下界。

## 最终边界

报告可作为本轮**已证部分、真实未付价格及条件回代**的归档。现在仍缺同一完整 D 的统一估计

\[
D\ge cV-CL_nM.
\]

尤其 retained-growth/new-capacity 比较及完整 owner 价格尚未支付。一般 f 入口、固定 N 终端、强 L2 的局部分支和有限数字 PASS 都不能替代这一步。本审核不认证一般根阶上界已成立，不认证 (U)，也不把结构性新式计作完整预算突破。完成后停止，无新分支、agent 或重数值。
