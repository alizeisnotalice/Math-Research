# R634 transport 与 source-clique product 增量独立审查

输入：本轮 `transport.md` 的 §2、§4、Tν/Fleb 后续式，以及主代理给定的 source-clique product 命题。固定同一完整 D、μ、λ、ν、全部真实 I_j 与全部半径。没有替换原 source 为产品分布，没有启动新代理、求解 LP 或改动他人文件。

**结论：growth-price 下界、Fsmall、Tν 边缘、Fleb 和 signed Δtrans 均通过。product 增量也通过，但只控制 soft 交通。Tν 接回 receiver 必须显式乘 e_j/ε；其 target 密度≤1 不随此乘权免费保留。尚未获得完整 D 的净下界。**

## 1. 全标签 Γ′ 的 growth-price 下界通过

由原边缘 `Γ′(J=j)≤ρ_je_j`，

\[
\int(1-e_J)d\Gamma'
\le\sum_j\rho_je_j(1-e_j)
\le\beta(1-\beta).
\]

第二步是 ρ 概率下的 `E(e²)≥β²`，不假设标签独立。K 端同理。因 `g_j=t_j^n≥1/(1−e_j)`，Cauchy 给

\[
\int g_Jd\Gamma'\ge\frac{\omega^2}{\beta(1-\beta)}.
\]

对 balanced 价格，令 `u=1−e_J,v=1−e_K`。有

\[
\int\sqrt{uv}\,d\Gamma'
\le\sqrt{\int u\,d\Gamma'\int v\,d\Gamma'}
\le\beta(1-\beta),
\]

再用 Cauchy 于 `1/√(uv)`，得到

\[
\int\sqrt{g_Jg_K}\,d\Gamma'
\ge\frac{\omega^2}{\beta(1-\beta)}.
\]

在 β≥3/4、κ≤1/8、H≥32 时，令 `l(b)=15b/8−33/32`，则 `ω≥l(β)≥3/8`。准确因式分解为

\[
\frac{l(b)^2}{b}-\frac3{16}
=\frac{3(4b-3)(300b-121)}{1024b}\ge0,
\]

\[
l(b)-2b(1-b)=\frac{(4b-3)(16b+11)}{32}\ge0.
\]

因 `M/Q=(1−β)^{-1}`，J、K 和 balanced 三种未归一化价格均至少 `(3/16)M/Q`；归一化后的三种期望均至少 2。`β/ω≤2`、`1/ω≤8/3` 的边缘常数也合法。

这是最低总增长价格的固定比例，不是完整 A* 的固定比例；它不控制 growth surplus，也不允许把 g_j 加权后的 Γ′ 边缘仍当作原边缘。

## 2. ζ 的完整 receiver 价格通过

\[
d\zeta(X,Z,j)=\lambda_j1_{A_j}(X)\mu(dX)1_{I_j}(Z)dZ/v_j.
\]

其 source 边缘为 μ。KKT `λ_je_jm_j=εv_j` 给

\[
\epsilon A^*=\int e_jg_jd\zeta,
\qquad
\epsilon O^*=\int e_jg_jh_j(Z)d\zeta.
\]

Γ′ own 边缘至多 `(e_j/M)ζ`；其条件 receiver 核系数为 `ε/(Mm_j)`，原 `1/m_j` 真实价格没有消失。Γ′ 伙伴不碰撞不能消除第三方 owner 事件 h_j；未带价删除概率≤1/H 不能直接支付 g_j 加权删除量。

## 3. Fsmall 与 slack 支付通过

定义

\[
F_{jk}(dZ)=\nu_k\frac{\mu(A_j\cap A_k^*)}{m_j}1_{I_j}(Z)dZ.
\]

设 `F_old=Σλ_je_j1_Aj≤1`。准确有

\[
\epsilon F_{\rm total}=\int F_{\rm old}L_\nu d\mu,
\quad
0\le V-F_{\rm total}\le S/\epsilon.
\]

对固定 k，I_j 不交且 `μ(A_j∩A_k*)/m_j≤1`，所以其 receiver 密度≤ν_k。这一步使用已保留的真实流，合法放宽比例，并未先删掉 1/m_j。

若 `ar_j≤δR_k*` 且该流非零，则源交集保证

\[
\|y_j-y_k\|_\infty<ar_j+R_k^*.
\]

对全部真实 Z∈I_j⊂B_j，

\[
\|Z-y_k\|_\infty
<R_k^*+(a+1)r_j
\le[1+(1+1/a)δ]R_k^*.
\]

固定 k 的密度上界遂可在这一个 cube 内积分，得

\[
F_{\rm small}\le[1+(1+1/a)δ]^nQ^*.
\]

取 `δ=1/[n(1+1/a)]`，准确得到 `Fsmall≤(1+1/n)^nQ*≤eQ*`。它控制实际 receiver 质量，不是中心数。

若 `Vmiss=V−Fsmall−Flarge`，则 `0≤Vmiss≤S/ε`。对 0<c≤1，hard 条件 εR>3 使

\[
RS-cV_{\rm miss}\ge(R-c/\epsilon)S>\tfrac23RS.
\]

因此 transport 的剩余目标

\[
D-cS/\epsilon\ge cF_{\rm large}-C_0PH_0M
\]

确实足以推出

\[
D\ge cV-[C_0PH_0+ce]M.
\]

但这条剩余目标仍未证明；small/miss 支付不包括 growth-priced owner overlap。

## 4. Tν 的边缘正确；接回 receiver 的必要乘权须显式

\[
dT_\nu(X,Y,k)=\nu_k1_{A_k^*}(X)\mu(dX)
\frac{1_{A_k^*}(Y)dY}{\Delta_k},\quad\Delta_k=|A_k^*|=\mu(A_k^*).
\]

准确边缘为

\[
(X)_\#T_\nu=L_\nu\mu,\qquad
(Y)_\#T_\nu=L_\nu dy\le dy,\qquad T_\nu(1)=Q^*.
\]

给定 k，Y 是 A_k* 中的产品均匀点；X 是真实 `μ|A_k*` 条件点。无需且不能把 X 的坐标独立化。该 Y 也不是 Γ′ 的原 source Y。

**必要澄清：** Tν 与 ζ 的普通 old-label/receiver conditional kernel 组合，仅给

\[
\nu_k\lambda_j\mu(A_j\cap A_k^*)1_{I_j}(Z)dZ/v_j.
\]

要准确回到 F_jk，必须再乘 `e_j/ε`：

\[
\frac{\lambda_je_j}{\epsilon v_j}=\frac1{m_j}.
\]

因此 transport 中“组合后准确回到 F_jk”应明确指这份 **曝光并除 ε 的组合**。现有 F_jk 公式本身正确；这是不能省略的 normalization。

在这份实际 exposed 组合下，目标 Y 密度一般只能用

\[
\frac1\epsilon L_\nu(Y)\,dY
\]

作上界，而不能继续沿用 Tν 的 ≤dy。对该流或 owner 价格作 product 分析必须保留完整乘权。

出入差亦正确：

\[
\int[L_\lambda(X)-L_\lambda(Y)]dT_\nu
=Q^*-\int L_\nu L_\lambda dy,
\]

\[
\epsilon V\le S+Q^*-\int L_\nu L_\lambda dy.
\]

它使用 `∫LνLλ≤Q`，尚未把出入差转成完整 D 的 receiver 净收益。

## 5. Fleb 与 signed Δtrans 通过

\[
F_{\rm leb,jk}=\nu_k\frac{v_j}{m_j}|A_j\cap A_k^*|,
\]

\[
F_{\rm leb}=\frac1\epsilon\int L_\nu F_{\rm old}dy
\le Q/\epsilon<V/3.
\]

这里 `v_j/m_j=λ_je_j/ε` 完整保留。若 `A_k*⊂A_j`，canonical 接触给 μ(A_j∩A_k*)=|A_j∩A_k*|，故该 pair 的 source 交通与 Lebesgue 对照交通相等。这一 contained 部分可由同一 Fleb 一次支付。

准确余项是

\[
\Delta_{\rm trans}
=\sum_{jk}\nu_k\frac{v_j}{m_j}
[\mu(A_j\cap A_k^*)-|A_j\cap A_k^*|]
=F_{\rm total}-F_{\rm leb}
\ge V-S/\epsilon-Q/\epsilon.
\]

各项可异号；不能用逐 pair 正部分替代这条式子而不支付新费用。

## 6. source-clique product 增量：命题成立，适用测度准确

固定新标签 k 及 X∈A_k*。设

\[
c_j(X)=\lambda_je_j1_{A_j}(X),\qquad
\theta_{jki}=\frac{|(y_{j,i}-ar_j,y_{j,i}+ar_j)\cap
(y_{k,i}-R_k^*,y_{k,i}+R_k^*)|}{2R_k^*}.
\]

给定 k 的 target Y 是产品均匀，故

\[
g_X(Y)=\sum_jc_j(X)1_{A_j}(Y).
\]

按 i=1,…,n 依次把 target 坐标固定成 X_i，用显式 product integral 定义

\[
G_i^k(X)=\sum_jc_j(X)\prod_{\ell>i}\theta_{jk\ell},
\quad\delta_i^k(X)=G_i^k(X)-G_{i-1}^k(X).
\]

只要 c_j(X)>0，所有 X_i 均在该 old star 的坐标区间内，因此固定坐标将对应 θ 从 [0,1] 换成 1。于是

\[
\delta_i^k(X)=\sum_jc_j(X)(1-\theta_{jki})
\prod_{\ell>i}\theta_{jk\ell}\ge0,
\]

\[
\sum_i\delta_i^k(X)=F_{\rm old}(X)-\mathbb E[g_X(Y)\mid k]
\le F_{\rm old}(X)\le1,
\qquad
\sum_i(\delta_i^k(X))^2\le1.
\]

所以 parent 提出的积分界成立，而且有更精确的

\[
\mathcal E:=\sum_k\nu_k\int_{A_k^*}\sum_i(\delta_i^k)^2d\mu
\le\mathcal I:=\sum_k\nu_k\int_{A_k^*}\sum_i\delta_i^k d\mu
\le\epsilon F_{\rm total}\le\epsilon V,
\]

同时 `mathcal E≤Q*≤M`。这没有假设 μ 是产品。δ_i 是这条确定性坐标固定路径的非负增量，**不是** μ 下零均值或相互正交的 martingale differences。

## 7. product 增量和真实 signed 交通的精确连接及缺口

令 `u_jk=μ(A_j∩A_k*)`、`l_jk=|A_j∩A_k*|`。展开第 6 节积分，得到

\[
\mathcal I=\sum_{jk}\nu_k\lambda_je_j u_{jk}
\left(1-\frac{l_{jk}}{\Delta_k}\right).
\]

与完整 receiver 交通比较，准确有

\[
\boxed{\mathcal I
=\epsilon\Delta_{\rm trans}+\mathcal R,\qquad
\mathcal R=\sum_{jk}\nu_k\lambda_je_j l_{jk}
\left(1-\frac{u_{jk}}{\Delta_k}\right)\ge0.}
\]

非负性由 `u_jk≤μ(A_k*)=Δ_k`。因此 product 增量确实连接了同一 source 交通，不是一个无关模型；但连接的是 **soft λ_je_j=εv_j/m_j 价格**。

决定性缺口仍有三项：

1. 转回实际 receiver 交通要除以 ε。单用积分≤M 只回到 M/ε 的基准量级；用坐标 Cauchy 还可能引入 √n/ε。H 是待吸收参数，不能把其系数隐藏进独立的 H0 常数。
2. 完整 D 中的 O* 带价为 `(1/ε)∫e_jg_jh_j(Z)dζ`。当前 product 增量没有 g_j、第三方 owner h_j(Z) 或它们与 source/new-label 的相关性。把这些乘回 c_j 后，`Σc_j≤1` 的 square-budget 前提不再自动成立。
3. Γ′ 的自适应标签支配不把此 Tν product 增量或其平方自动支配到 owner 流。不存在已证的共同核不等式把第 6 节的 square sum 结算成 `A*−O*−RM+(R−c/ε)S+Cfill` 的净正项。

所以不能把“增量平方积分≤M”直接命名成完整 D 的全局预算。所需净估计仍是第 3 节末列出的完整 large-traffic 式，或另一条保留相同全部费用的等价不等式。

## 8. 实际数学工具

本机 math venv、SymPy 1.14.0 轻量运行，核验第 1 节两项精确因式分解及第 7 节代数差：`c·u(1−l/Δ)−c(u−l)=c·l(Δ−u)/Δ`。没有重复求解、没有数值扫参。

最终审核状态：**通过上述结构/交通/产品增量命题；保留必要 e_j/ε normalization；尚未证明完整 D 的根阶净预算。**

## 9. 附审 selection §6：合法 ν 交换与 small-blocker 强 L² 付款

本节只审 Bourgain dimension-free cube strong L² 定理在当前对象中的应用；primary 定理本身按主代理已核查的合同使用，不重复审原论文。

### 9.1 合法交换通过；使用正体积/open-clique 合同

固定 j，删除所有与 A_j* 有正体积交的 new stars 的 ν 权（包括 j 本身的原权），再把 j 的权设成 1。余下 stars 与 A_j* 内部不交；所以在 open cubes 的点态 packing 合同、或等价的 Lebesgue-a.e./正体积 clique 合同下，所得权仍可行。

若把闭立方体的边界接触当成额外 pointwise clique，则不能直接说这份交换在全部边界点可行；当前使用正体积约定，且 μ 为 L1，故没有此问题。对开轴平行 cubes，非空交就是正体积交。

ν 最优性因此给

\[
\sum_{k:|A_k^*\cap A_j^*|>0}\nu_k\Delta_k\ge\Delta_j.
\]

该式没有按 j 分配独立 Q*，只能作为每个 j 的冲突条件。

### 9.2 整 receiver 的 L² 付款通过，常数正确

取 `η=1/(32n)`。若 j 的小 blockers（`R_k*≤ηR_j*`）贡献至少 Δ_j/2，则每个 blocker 的全部 A_k* 位于

\[
Q(y_j,(1+2\eta)R_j^*).
\]

因为交叠给 `||y_k−y_j||∞<R_j*+R_k*`，再加自身 R_k* 即得此包含。

对所有真实 z∈I_j⊂B_j，`||z−y_j||∞<r_j≤R_j*/a`，所以一个**以 z 为中心**、半径 `(1+2η+1/a)R_j*` 的 cube 包含上述全部 blockers。故对真实函数 `L=Lν`，

\[
M_{\rm cube}L(z)
\ge\frac1{2(1+2\eta+1/a)^n}
\ge\frac12e^{-3/32}=:\alpha.
\]

最后一步使用 `2η+1/a≤3/(32n)` 及 `log(1+x)≤x`。这不是把原 L1 来源 μ 代入强 L²；输入是 `0≤L≤1`、`∫L=Q*` 的有限 packing potential，确有

\[
\|L\|_2^2\le Q^*.
\]

I_j 的实际不交性与 Chebyshev 给

\[
\sum_{j\in J_0}v_j
\le|\{M_{\rm cube}L\ge\alpha\}|
\le\alpha^{-2}C_2^2\|L\|_2^2
\le4e^{3/16}C_2^2Q^*.
\]

所以 `C0=4exp(3/16)C2²` 正确且维数无关。这里支付的是这些 j 的**全部真实 receiver 增量**，没有漏掉 1/m_j，也没有只付中心数量。

### 9.3 剩余流下界与强冲突条件通过

对每个 j，

\[
\sum_kF_{jk}
=\frac{v_j}{m_j}\int_{A_j}L_\nu d\mu\le v_j.
\]

因此删除所有 j∈J0 的交通至多损失 C0Q*；再删除原 small-scale 交通至多损失 eQ*。即使两部分重合，按并集扣款只会更小，故真正余流满足

\[
\boxed{F_{\rm rem}\ge V-S/\epsilon-(e+C_0)Q^*.}
\]

每个余流 pair 保留 `ar_j>R_k*/[n(1+1/a)]` 及完整价格 `ν_kv_j/m_j`。其 j∉J0，所以 small-blocker 总量严格小于 Δ_j/2；与合法交换下界合并，得到

\[
\sum_{\ell:|A_\ell^*\cap A_j^*|>0,\ R_\ell^*>\eta R_j^*}
\nu_\ell\Delta_\ell>\Delta_j/2.
\]

这里 blocker 标签 ℓ 不能擅自认成该 traffic 的目标标签 k；冲突体积压力还不是余流 receiver 的列容量，也不是 owner overlap 的带价预算。

**附审结论：§6 的新 small-blocker 整 receiver 付款与余流筛除均通过。** 尚缺的是这份余流、其 large-blocker 压力与完整 `e_jg_jh_j/ε`、growth surplus、RS 的同积分净估计。它没有改变本报告第 7 节的决定性缺口。

## 10. 收束状态

作者已显式修订 Tν composition 的 e_j/ε，且补写

\[
\Delta_{\rm trans}=\epsilon^{-1}\int[F_{\rm old}(X)-F_{\rm old}(Y)]dT_\nu.
\]

这条等价式通过：source 端给 εFtotal，Lebesgue target 端给 εFleb；不是声称 source-exposed target 仍有密度≤1。

最终通过项包括：growth 三价格下界、完整 receiver 流、Fsmall、Tν/Fleb/signed traffic、source-clique product 增量、合法 ν 交换、Bourgain strong L² 的 small-blocker 整 receiver 付款及余流下界。**仍未证明原目标 `D≥cV−CPH0M`；尤其 product 平方积分不能代替完整 D 的净预算。** 按主代理要求完成后停止，等待整合。
