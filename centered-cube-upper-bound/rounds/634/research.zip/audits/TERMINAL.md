# R634 完整递推终端独审（Sol high）

审核范围：固定 a、ε=(2PH)^{-1} 的同一 finite-family regularized packing，及在合法扩张、重算真实增量、重新构造来源后能否以 R=V/Qε 的增加形成矛盾。只读 R634 CONTRACT 和 R619 原 barrier 定义/KKT；不另开机制、不扫参、不改仓库。

**判定：经典 O(nlog n) 弱型界配合已知 barrier gap，并不自动给当前 fixed-ε 的统一 R 终端；但不能据 εB_n>1 宣称终端不可能。另有一个可用的固定标签数终端，见第3节。无论采用哪种有限终端，只有 R 单调增加仍不足以构成矛盾，必须证明增幅迫使它发散或越过该终端。**

## 1. 由定义/一阶最优性得到的准确 gap

在同一 family 的 packing polytope K 上，令

    Qopt=max_{λ∈K} Σd_jλ_j,
    λε=argmax_{λ∈K,λ_j>0}[Σd_jλ_j+εΣv_j logλ_j],
    Qε=Σd_jλε,j,   V=Σv_j.

删去 v_j=0 的行后全部 v_j>0；K 有严格正可行点且 compact，正则最优点存在并全正。取任一线性最优 λopt，正则目标的一阶最优性给

    Qopt−Qε
      ≤εΣv_j(1−λopt,j/λε,j)
      =εV−εΣv_j λopt,j/λε,j
      ≤εV.

所以 0≤Qopt−Qε≤εV。后面的非负项不可凭空下界为维数一致比例；当前合同没有这样的估计。这比只引用 source duality 的 Qopt≤M=Qε+εV 更明确，但不会自动产生更强终端。

## 2. 经典弱型界能支付什么、不能支付什么

设 B_n 是对一般非负 L1 来源、全部正半径的已知有限弱型常数。继承 finite-cell LP 对偶，Qopt 是满足 μ0(A_j)≥d_j 的同一 finite family 的最小真实 L1 来源质量。

对 z∈B_j，取 R_z=ar_j+||z−y_j||∞<(a+1)r_j，则 Q(z,R_z) 包含 A_j，故其 μ0 平均严格大于 1/P，P=(1+1/a)^n。这一步即使 μ0(A_j)=d_j 也有严格号。因此

    V≤P B_n Qopt.

若题目中的 B_n 已包含这一 finite-family receiver 平移因子，则以下 K_n 直接取该 B_n；否则记 K_n=P B_n。把 gap 代入，准确得到

    V≤K_n(Qε+εV),
    R≤K_n(1+εR).

只有在 εK_n<1 时，这条链直接给

    R≤K_n/(1−εK_n).                                  (Tweak)

当前 ε=1/(2PH) 时，εK_n=B_n/(2H)。一般 nlog n 级已知界相对于 intended sqrt n·polylog 的 H，不能保证该量<1。若它≥1，上述显示式只是不再给 R 的上界；**这不证明实际 cube family 的 R 可以无界，更不反驳另一个几何终端。** 严格 gap 或每个实例 Qε>0 也不提供跨变化 family 的统一量化余量。

一个真正足够的补充是证明 Qε≥c_n Qopt，c_n>0 对迭代中全部 family 统一，允许 c_n 很差但不能随迭代趋零；则 R≤K_n/c_n。现有 gap 只给 c_n≥1−εK_n，非正时不能使用。目前没有从旧合同证明这种更强比较。

把 ε 改为≤1/(2K_n) 可使 (Tweak) 有效，但这会改变 KKT 来源、β 和 hard 分支。原 β>3/4 门槛会变成 R>3/ε，通常回到 nlog n 级；因此不能不付参数改变费用而将它当作当前 root-threshold 递推的免费修复。

## 3. 可用的固定标签数终端：不需要 εK_n<1

令 N 是当前正增量行数。KKT 与 m_j≤M 给

    λε,j m_j=λε,j d_j+εv_j≥εv_j,
    λε,j≥εv_j/M.

又 I_j⊂B_j，所以 d_j=a^n|B_j|≥a^n v_j。因此

    Qε M= MΣλε,jd_j
       ≥εΣv_jd_j
       ≥εa^nΣv_j²
       ≥(εa^n/N)V².

使用 M=Qε+εV，得

    1/R²+ε/R≥εa^n/N,
    R≤G(N,a,ε)
      := N/(2a^n) [1+sqrt(1+4a^n/(εN))].             (TN)

这对每个固定 N,a,ε 是统一有限的，独立于 centers、radii、source-cell 数和最小权；没有使用经典 weak bound，也没有假设 N/a^n 很小。若合法扩张每步只沿原 N0 个标签作 homothety、重算增量并删除零行，则 N_k≤N0，且上式可直接用 N0 统一，给真正的迭代终端 G(N0,a,ε)。

这个终端依赖初始 N0，但**可作为反证迭代的辅助终端**：若从任意 hard finite family 出发，能保持同一 a、ε、不增标签数，并严格证明 R_k→∞，就必与 (TN) 矛盾。它不必成为最终弱型常数；最终若排除全部 R>6PH 的 family，得到的仍是 root-threshold 常数，而不是 G(N0)。

限制也必须明确：若递推新建越来越多标签/子立方体，只有每一步有限 N_k 并不提供统一终端；若 ε_k→0，(TN)也不能无条件沿用。新的来源必须重新满足同一 actual increments 的完整 KKT，不能只保留旧 λ 或 M。

## 4. 有限终端并不把“单调增加”变成矛盾

即使已得到统一有限 G，严格递增也可能趋近 G 或更小的极限。因此以下都还不够：

- 每一步 R_{k+1}≥R_k；
- 每一步 R_{k+1}>R_k，但增幅没有统一量化；
- raw expanded volume 增加，而新 source 成本和 overlap 尚未同时回代。

足够的递推形式例如：在 hard 区域保持 R_{k+1}≥(1+c)R_k（c>0 对步骤统一）；或 R_{k+1}≥R_k+g(R_k)，且 g 在可能的有界 hard 区间有严格正下界；或严格证明全部累计增幅发散。也可使用一个 finite supremum 的近极值反证，但须证明在 supremum 附近仍有不会退化的净改进，不能只称“每个实例均可再改进”。

所有 endpoint strict approximations、overlap、换源质量、标签删选与阈值损失必须包含在净增幅中。若所证实际只是“接近 endpoint 后可使 Rnext 任意接近 R”，则没有正增幅；若是严格但可求和的小增幅，也仍没有矛盾。

## 5. 给主路线的可执行判断

- **目前可以保留：** 固定 ε 的 barrier gap；经典 finite-family bound 的完整 P 因子；在不增标签数时的显式终端 (TN)。
- **目前不可声称：** εB_n>1 意味着任何终端都不可能；或者反过来，经典 finite weak bound 已终止当前 R 递推。
- **可用修复：** 若候选扩张确实不增标签数，采用 (TN) 作终端，接着只需审核其**净增幅是否量化到迫使 R 发散**。这是原同 family 路线的终端补充，不是新付款机制。
- **尚未证明：** 当前提供的合同没有完整 overlap/capacity 付款，也没有这样一个量化增幅；因此尚不能形成 root 上界矛盾。若未来标签数不受控，则还缺独立于迭代的 Qε 比较或其他统一终端。

**实际轻量验证：** 本机 math venv、SymPy 1.14.0 核验 (TN) 的正根代入 εa^nR²/N−εR−1 后残差为0，以及 (Tweak) 的等式端点，运行约0.18秒。一般终端及逻辑判断来自上述不等式证明，不是有限扫参。唯一写入文件为本报告；独审完成停止。
