"""Exact finite algebra checks; not a proof of the unproved joint inequality."""
from fractions import Fraction as F
from pathlib import Path
import json, platform, sys
import sympy as s

if not __debug__:
    raise RuntimeError('Do not disable assertions')
b=s.symbols('b', positive=True)
l=15*b/8-s.Rational(33,32)
assert s.simplify(l*l/b-s.Rational(3,16)-3*(4*b-3)*(300*b-121)/(1024*b))==0
assert s.simplify(l-2*b*(1-b)-(4*b-3)*(16*b+11)/32)==0
N,a,eps=s.symbols('N a eps',positive=True)
x=N/(2*a)*(1+s.sqrt(1+4*a/(eps*N)))
assert s.simplify(eps*a*x*x/N-eps*x-1)==0
c,u,v,d=s.symbols('c u v d',positive=True)
assert s.simplify(c*u*(1-v/d)-c*(u-v)-c*v*(1-u/d))==0
m=F(2113,1056); V=F(1,8); Q=F(4); R=V/Q; M=2*m; ep=F(1,66)
assert M==Q+ep*V and m-2==ep*F(1,16)
controls=[]
for gap in [F(1,2112),F(1,1056)-F(1,100000),F(1,1056),F(1,1056)+F(1,100000)]:
    overlap=max(F(0),m-2-gap)
    qp=m if overlap>0 else 2*m
    vp=2*m/32
    deficit=vp-R*qp
    assert deficit==(m/32 if overlap>0 else 0)
    assert vp-R*M==0
    controls.append(dict(gap=str(gap),intersection=str(overlap),Qstar=str(qp),D=str(deficit)))
screen={str(n):str(F(9,2)*32*(32*n+1)**n) for n in (1,2,3,4,7)}
out=dict(status='PASS',scope='exact symbolic identities and finite rational controls; U remains unproved',
         python=sys.version,executable=sys.executable,sympy=s.__version__,platform=platform.platform(),
         identities=4,controls=controls,necessary_N_strictly_greater_than=screen)
Path(__file__).with_name('LEDGER_CHECKS.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
