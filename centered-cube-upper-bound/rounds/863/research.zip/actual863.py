"""Exact maximal cyclic-dyadic stopping on R814's truncated product comb."""
from argparse import ArgumentParser
from collections import defaultdict
from fractions import Fraction as F
from functools import lru_cache
from hashlib import sha256
from itertools import product
from math import prod
from pathlib import Path
from zipfile import ZipFile
import json
import sys

PINS={
    814:"891d8cbcbd35537e6abc18c938e53b1b4f300327357c24c8d14a51a46ad5e190",
    860:"2b530fd04c0f05f81e7c52cf4c644b07ce25103d96967927820f011c27c9ae39",
}
THEOREM_THRESHOLD=("4^(1/16)",F(4),16)
THRESHOLDS=(("sqrt(2)",F(2),2),("2",F(2),1),("16",F(16),1),("128",F(128),1),
            THEOREM_THRESHOLD)
CUTOFFS=(F(1,8),F(1,32),F(1,128))


def archive_member(rounds,edition,name):
    path=rounds/str(edition)/"research.zip"
    assert sha256(path.read_bytes()).hexdigest()==PINS[edition]
    with ZipFile(path) as z:
        data=z.read(name)
        manifest=json.loads(z.read("MANIFEST.json"))["sha256" if edition==860 else "members"]
        assert sha256(data).hexdigest()==manifest[name]
    env={"__name__":"actual863_archive","__file__":name}
    exec(compile(data,name,"exec"),env)
    return env


def ranges(intervals):
    merged=[]
    for a,b in sorted(intervals):
        assert a<b
        if merged and a<=merged[-1][1]:
            x,y=merged.pop()
            merged.append((x,max(b,y)))
        else:
            merged.append((a,b))
    return merged


class Source:
    def __init__(self,comb,stage):
        self.comb=comb
        self.n=stage["dimension"]
        data=stage["density"]
        self.low,self.high=data["support"]
        self.bump=data["bump_half_width"]
        self.period=data["period"]
        self.phase=data["bump_center_mod_period"]
        self.floor=data["density_floor_one_axis"]
        self.peak=data["density_peak_one_axis"]
        self.widths=[self.high-self.low]
        while self.widths[-1]>self.bump:
            self.widths.append(self.widths[-1]/2)
        assert self.widths[-1]==self.bump
        assert ((self.phase-self.bump-self.low)/self.bump)%1==0
        assert ((self.phase+self.bump-self.low)/self.bump)%1==0
        assert self.period/self.bump%1==0
        self.period_mass=self.mass(self.low,self.low+self.period)
        assert self.period_mass==self.period
        assert all(w%self.period==0 and self.mass(self.low,self.low+w)==w
                   for w in self.widths if w>=self.period)
        assert self.mass(self.low,self.high)==self.high-self.low

    def mass(self,a,b):
        return self.comb["interval_mass"](a,b,self.bump)

    @lru_cache(maxsize=None)
    def average(self,width,offset):
        a=self.low+width*offset
        return self.mass(a,a+width)/width

    def signatures(self,axis,parents,boxes):
        width=self.widths[-1]
        projected=ranges(tuple(b[axis] for b in boxes))
        faces={z for p in parents.values() for z in p["box"][axis]}
        types=defaultdict(F)
        for left,right in projected:
            first=(left-self.low)//width
            last=(right-self.low)//width
            cuts=({left,right} | {x for x in faces if left<x<right}
                  | {self.low+j*width for j in range(first+1,last+1)
                     if left<self.low+j*width<right})
            cut=sorted(cuts)
            for a,b in zip(cut,cut[1:]):
                point=(a+b)/2
                mask=sum(p["bit"] for p in parents.values()
                         if p["box"][axis][0]<point<p["box"][axis][1])
                signature=tuple(self.average(w,0 if w>=self.period else
                                    ((point-self.low)//w) % (self.period//w))
                                for w in self.widths)
                # The leaf lies between comb breakpoints. There is no new
                # averaged density on any descendent.
                assert signature[-1] in (self.floor,self.peak)
                mass=self.mass(a,b)
                assert mass==signature[-1]*(b-a)
                types[mask,signature]+=mass
        return dict(types)

    @lru_cache(maxsize=None)
    def stops(self,paths):
        out=[None]*len(THRESHOLDS)
        levs=[0]*self.n
        for depth in range(self.n*(len(self.widths)-1)+1):
            density=prod(u[lev] for u,lev in zip(paths,levs))
            longest=self.widths[min(levs)]
            for j,(name,threshold,power) in enumerate(THRESHOLDS):
                if out[j] is None and density**power>threshold:
                    out[j]=longest
            if all(a is not None for a in out):
                break
            if depth<self.n*(len(self.widths)-1):
                levs[depth%self.n]+=1
        return tuple(out)


def measure_stops(source,parents,src,raw):
    gates=sorted({(t,arm[0]) for t,l,r in raw for arm in (l,r)})
    active={arm[1] for t,l,r in raw for arm in (l,r)}
    boxes=[]
    for t,i in gates:
        box=tuple((max(a,c),min(b,d)) for (a,b),(c,d) in
                  zip(parents[t]["box"],parents[i]["box"]))
        assert all(a<b for a,b in box)
        boxes.append(box)
    per_axis=[source.signatures(j,parents,boxes) for j in range(source.n)]
    by_mask=defaultdict(F)
    counts={m:[defaultdict(F) for _ in THRESHOLDS] for m in active}
    and_all=sum(p["bit"] for p in parents.values())
    hit_summands=0
    for data in product(*(a.items() for a in per_axis)):
        mask=and_all
        for (m,path),weight in data:
            mask&=m
        if mask not in active:
            continue
        mass=prod(weight for (m,path),weight in data)
        paths=tuple(path for (m,path),weight in data)
        outcomes=source.stops(paths)
        by_mask[mask]+=mass
        for stop_at,local in zip(outcomes,counts[mask]):
            local[stop_at]+=mass
        hit_summands+=1
    # Axis projections prune only evaluation, never the stopping densities.
    # Exact recovery of every used complete source mask checks no lost prices.
    assert dict(by_mask)=={u:src[u] for u in active}
    assert all(sum(v.values())==src[u] for u,count in counts.items() for v in count)
    return counts,tuple(len(a) for a in per_axis),hit_summands


def fractions(counts,src,threshold,keep):
    chances={}
    outside={}
    for price,profile in counts.items():
        statuses=profile[threshold]
        outside[price]=statuses.get(None,F(0))/src[price]
        chances[price]=sum(m for w,m in statuses.items()
                           if w is None or keep(w))/src[price]
        assert 0<=outside[price]<=chances[price]<=1
    return chances,outside


def original(rows,parents,probs):
    weights=[F(0)]*3
    margins=[[defaultdict(F) for _ in (0,1)] for _ in range(3)]
    for (t,l,r),weight in sorted(rows.items()):
        a,b=probs[l[1]],probs[r[1]]
        shares=((1-a)*(1-b),a*(1-b)+(1-a)*b,a*b)
        assert sum(shares)==1
        for k,f in enumerate(shares):
            weighted=weight*f
            weights[k]+=weighted
            for j,(i,y,h) in enumerate((l,r)):
                margins[k][j][i,h]+=weighted
    assert sum(weights)==sum(rows.values())
    for k,v in enumerate(margins):
        for side in v:
            assert sum(side.values())==weights[k]
            assert all(0<=x<=parents[i]["owner_volume"]/2 for (i,h),x in side.items())
    for j in (0,1):
        for (i,h) in margins[0][j]:
            assert sum(margins[k][j][i,h] for k in range(3))<=parents[i]["owner_volume"]/2
    peaks=tuple(max(2*v/parents[i]["owner_volume"] for (i,h),v in side.items())
                for side in margins[2])
    return weights,peaks


def physical_octave(parents,rows):
    radii=sorted({parents[t]["radius"] for t,l,r in rows} |
                 {parents[arm[0]]["radius"] for t,l,r in rows for arm in (l,r)})
    R=F(1)
    while R>radii[0]:
        R/=2
    while 2*R<=radii[0]:
        R*=2
    assert all(R<=s<2*R for s in radii)
    return R,radii


def replay(rounds):
    public=archive_member(rounds,860,"public860.py")
    comb=archive_member(rounds,814,"comb811.py")
    stage=comb["fixture"](*comb["FIXTURES"][-1])
    parents,src,rows,hard,outward,pin,cut=public["load"](rounds)
    assert pin==PINS[814] and len(rows)==920 and len(hard)==848
    assert tuple(parents)==tuple(stage["parent_order"])
    mass=sum(rows.values())
    assert sum(hard.values())==cut[2]
    R,radii=physical_octave(parents,rows)
    source=Source(comb,stage)
    assert sum(src.values())==(source.high-source.low)**source.n
    counts,types,parts=measure_stops(source,parents,src,rows)
    active_mass=sum(src[y] for y in counts)
    assert len(counts)==10

    def fmt(x):
        return "0" if x==0 else outward(x)

    print("Python",sys.version.split()[0],"; Fraction exact stopping and original positive-integral reconstruction.")
    print("Pinned R814 and R860",PINS[814],PINS[860])
    print("Actual truncated root: [",source.low,",",source.high,")^4 ; total mu",sum(src.values()),
          "; exact average 1 and all containing coarser ancestors have average <=1.")
    print("Fixed cyclic split x1,x2,x3,x4, strict threshold crossing; terminal length",source.widths[-1])
    print("Terminal boundaries include all density breaks. Persistence outside all maximal stops is determined exactly.")
    print("Pruned axis signatures and active product terms",types,parts,"; all ten active source masses independently recovered.")
    print("Original full and hard records",len(rows),len(hard),
          "; full F and hard/F",fmt(mass),fmt(sum(hard.values())/mass))
    print("Low = first stopping block's longest side <= cutoff, or permanence outside every stopping block.")
    print("Actual used parent radii",tuple(map(str,radii)),"; common physical radius window [R,2R) with R=",R)
    print("Each cutoff is epsilon*R. Shares are normalized by original total F.")
    print("True original price marginals condition on full membership mask; two arms are integrated using the archived product law.")
    for j,(name,threshold,power) in enumerate(THRESHOLDS):
        print(" tau0",name)
        _,outside=fractions(counts,src,j,lambda w: w<=R*CUTOFFS[-1])
        never_mass=sum(src[y]*p for y,p in outside.items())/active_mass
        out_full,_=original(rows,parents,outside)
        out_hard,_=original(hard,parents,outside)
        print("  true active mu never stopped share:",fmt(never_mass),
              "; both outside original all/F and hard/F:",fmt(out_full[2]/mass),fmt(out_hard[2]/mass))
        distribution=defaultdict(F)
        for profile in counts.values():
            for stop,a in profile[j].items():
                distribution[stop]+=a/active_mass
        assert sum(distribution.values())==1
        print("  masses by actual first longest side:",[(str(w),fmt(distribution[w]))
                                                         for w in sorted(w for w in distribution if w is not None)])
        if (name,threshold,power)==THEOREM_THRESHOLD:
            cutoffs=(("epsilon = 4^(-11/12), exact twelfth-power test",
                      lambda w: (w/R)**12<=F(1,4**11)),
                     ("epsilon = 1/8 (same threshold, smaller control)",
                      lambda w: w<=R/8))
        else:
            cutoffs=tuple((str(R*cutoff),lambda w,v=cutoff: w<=R*v) for cutoff in CUTOFFS)
        for cutoff,keep in cutoffs:
            p,_=fractions(counts,src,j,keep)
            short=sum(src[y]*z for y,z in p.items())/active_mass
            assert never_mass<=short
            g,M=original(rows,parents,p)
            h,H=original(hard,parents,p)
            if (name,threshold,power)==THEOREM_THRESHOLD:
                assert short in (0,1) and g[2]==short*mass and h[2]==short*sum(hard.values())
            print("   cutoff",cutoff,"active mu low fraction",fmt(short),
                  "true short alone",fmt(short-never_mass),"; conditional per-price low range",
                  fmt(min(p.values())),fmt(max(p.values())))
            print("    original low endpoints zero/one/both:",
                  "all",tuple(fmt(x/mass) for x in g),"hard",tuple(fmt(x/mass) for x in h))
            print("    absolute original both-low all/hard",fmt(g[2]),fmt(h[2]))
            print("    two-low real U/W peak over the actual half Lebesgue:",
                  tuple(fmt(x) for x in M),tuple(fmt(x) for x in H))
    current=sorted({t for t,l,r in rows})
    print("Archived full and old completeness on the actual middle parents:",
          [(t,fmt(parents[t]["full_d"]),fmt(parents[t]["old_d"])) for t in current])
    largest_ratio=max(parents[t]["m"]/max(parents[l[0]]["m"],parents[r[0]]["m"])
                      for t,l,r in rows)
    assert largest_ratio<16 and all(parents[t]["full_d"]<2 for t in current)
    print("Actual largest middle/max-small volume ratio",largest_ratio,
          "< 16 < exp(2 ln^8(6)); every archived d_v < 2 < 2 ln^3(6).")
    print("The dimension-four archive certifies the stopping label and does not meet the theorem's full-history gates.")
    print("All assertions passed. Finite geometric stopping classification.")


if __name__=="__main__":
    parser=ArgumentParser()
    parser.add_argument("--rounds",type=Path,required=True)
    replay(parser.parse_args().rounds)

