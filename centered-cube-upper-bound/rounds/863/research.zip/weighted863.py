"""R863: freeze all actual physical-window price labels before grid thinning."""
from argparse import ArgumentParser
from collections import defaultdict
from fractions import Fraction as F
from hashlib import sha256
from itertools import product
from math import prod
from pathlib import Path
import runpy
import sys

PIN_ACTUAL="92db3e9f95357f4671c0f21b7f075a52bb6b2c99b27c386382d845780c1897da"
TAU=F(19,16)
GRIDS=((F(1,4),F(0)),(F(1,8),F(0)),(F(1,32),F(0)),(F(1,32),F(1,2)))


def load(rounds):
    path=Path(__file__).with_name("actual863.py")
    assert sha256(path.read_bytes()).hexdigest()==PIN_ACTUAL
    actual=runpy.run_path(str(path))
    public=actual["archive_member"](rounds,860,"public860.py")
    comb=actual["archive_member"](rounds,814,"comb811.py")
    stage=comb["fixture"](*comb["FIXTURES"][-1])
    parents,src,all_,hard,fmt,_,cut=public["load"](rounds)
    R,radii=actual["physical_octave"](parents,all_)
    assert (len(all_),len(hard))==(920,848) and sum(hard.values())==cut[2] and R==1
    eps=F(1,4)
    assert eps**6<1/F(4**5) and TAU**8<4<F(6,5)**8
    return actual,comb,stage,parents,src,all_,hard,fmt,R


def intersect(a,b):
    return tuple((max(x,u),min(y,v)) for (x,y),(u,v) in zip(a,b))


def touching_indices(lo,hi,w,shift):
    left=(lo-shift)//w
    right=-((shift-hi)//w)
    return range(left,right)


def relevant_grid(w,shift,gates):
    keys=set()
    for g in gates:
        assert all(a<b for a,b in g)
        keys.update(product(*(touching_indices(a,b,w,shift) for a,b in g)))
    for key in sorted(keys):
        yield tuple((shift+x*w,shift+(x+1)*w) for x in key)


def mass_by_mask(box,parents,active,source):
    data={sum(p["bit"] for p in parents.values()):F(1)}
    for d,(lo,hi) in enumerate(box):
        sides={lo,hi} | {x for p in parents.values() for x in p["box"][d] if lo<x<hi}
        sides=sorted(sides)
        row=defaultdict(F)
        for a,b in zip(sides,sides[1:]):
            mid=(a+b)/2
            mask=sum(p["bit"] for p in parents.values()
                     if p["box"][d][0]<mid<p["box"][d][1])
            row[mask]+=source.mass(a,b)
        nxt=defaultdict(F)
        for (m,x),(n,y) in product(data.items(),row.items()):
            nxt[m&n]+=x*y
        data=nxt
    return {m:value for m,value in data.items() if m in active and value>0}


def densities(g,parents,source):
    raw={i:prod(source.mass(a,b) for a,b in intersect(g,p["box"])) for i,p in parents.items()}
    weighted={i:p["j"]*raw[i]/p["m"] for i,p in parents.items()}
    return sum(weighted.values()),sum(x for i,x in weighted.items() if parents[i]["role"]=="old")


def inventory(w,offset,parents,src,raw,source):
    active={arm[1] for _,l,r in raw for arm in (l,r)}
    arms=sorted({(t,arm[0]) for t,l,r in raw for arm in (l,r)})
    gates=[intersect(parents[t]["box"],parents[i]["box"]) for t,i in arms]
    recovered=defaultdict(F)
    table=[]
    for g in relevant_grid(w,offset,gates):
        mask=mass_by_mask(g,parents,active,source)
        if not mask:
            continue
        nu=densities(g,parents,source)
        assert nu[0]>=nu[1]>0
        for i,value in mask.items():
            recovered[i]+=value
        table.append((mask,nu))
    assert dict(recovered)=={i:src[i] for i in active}
    return table,active


def weighted_median_gap(table,volume):
    available=defaultdict(F)
    for v,d in table:
        available[d[0]/volume]+=sum(v.values())
    ordered=sorted(available)
    assert len(ordered)>1
    total=sum(available.values())
    part=F(0)
    for i,x in enumerate(ordered):
        part+=available[x]
        if 2*part>=total:
            left=min(i,len(ordered)-2)
            return (ordered[left]+ordered[left+1])/2
    raise AssertionError("empty positive source")


def summarize_grid(table,active,src,vol,tau,role):
    given=defaultdict(F)
    uncut=defaultdict(F)
    mass=sum(src[i] for i in active)
    all_counts=defaultdict(F)
    maxima=[F(0),F(0)]
    for masks,twin in table:
        v=twin[role]
        a=min(F(1),tau*vol/v)
        assert 0<a<=1 and a*v<=tau*vol
        assert (v>tau*vol)==(a<1)
        carried=sum(masks.values())
        if a<1:
            all_counts["cells_strict"]+=1
            all_counts["active_mu_strict"]+=carried
        if a*v==tau*vol:
            all_counts["cells_saturated"]+=1
        all_counts["window_nu_in_live_cells"]+=v
        all_counts["window_nu_after_live_cells"]+=a*v
        maxima[0]=max(maxima[0],v/vol)
        maxima[1]=max(maxima[1],a*v/vol)
        for m,value in masks.items():
            given[m]+=value*a
            if a==1:
                uncut[m]+=value
    pair={m:(given[m]/src[m],uncut[m]/src[m]) for m in sorted(active)}
    assert all(0<=q<=a<=1 for a,q in pair.values())
    return pair,maxima,all_counts


def original(rows,means,parents):
    value,one,both=F(0),F(0),F(0)
    mark=[defaultdict(F),defaultdict(F)]
    reference=[defaultdict(F),defaultdict(F)]
    for (t,l,r),amount in rows.items():
        a,p=means[l[1]]
        b,q=means[r[1]]
        weight=amount*a*b
        value+=weight
        both+=amount*p*q
        one+=amount*(p*(1-q)+(1-p)*q)
        for s,(i,m,h) in enumerate((l,r)):
            mark[s][i,h]+=weight
            reference[s][i,h]+=amount
    assert all(sum(d.values())==value for d in mark)
    assert 0<=both<=value<=sum(rows.values())
    assert all(v<=reference[s][i,h]<=parents[i]["owner_volume"]/2
               for s in (0,1) for (i,h),v in mark[s].items())
    peak=tuple(max(2*v/parents[i]["owner_volume"] for (i,h),v in r.items()) for r in mark)
    return value,both,one,peak


def main(rounds):
    actual,comb,stage,parents,src,rows,hard,outward,R=load(rounds)
    source=actual["Source"](comb,stage)
    assert sum(src.values())==(source.high-source.low)**source.n
    for i,p in parents.items():
        assert p["m"]==comb["mass"](p["box"],source.bump)
        assert 0<p["j"]<=p["owner_volume"]==comb["volume"](p["owner"])
        assert all(comb["volume"](E)==p["owner_volume"]/2 for E in p["owner_halves"])
    F0=sum(rows.values())
    fmt=lambda x:"0" if x==0 else outward(x)
    coeff=[sum(p["j"]/p["m"] for i,p in parents.items() if role==0 or p["role"]=="old")
           for role in (0,1)]
    print("Python",sys.version.split()[0],"; exact Fraction weighted global-window thinning.")
    print("Pinned actual863.py",PIN_ACTUAL)
    print("Actual R814 finite range contains all eight physical-window labels;",
          "the five old labels are exactly all possible original small arms.")
    print("G_i is the original true A_i under restricted comb mu; m_i=mu(A_i); j_i is the actual calibrated owner share.")
    print("Labels and (j_i, m_i, j_i/|E_i|):",
          [(i,tuple(map(str,(p["j"],p["m"],p["j"]/p["owner_volume"])))) for i,p in parents.items()])
    print("Frozen global total nu_O^0, full/old-only:",
          sum(p["j"] for p in parents.values()),sum(p["j"] for p in parents.values() if p["role"]=="old"))
    print("True physical R=",R,"; epsilon<=1/4<4^(-5/6); tau main",TAU,
          "<4^(1/8)<6/5; full/hard original records",len(rows),len(hard))
    print("Each real input piece is integrated against the actual comb inside its grid cube before averaging theta.")
    print("Original theta(z)theta(q) uses the product source law on true cells and preserves both original U/W marginals.")
    print("Saturation census covers every grid cube with positive active price-source mass.")
    for frac,phase in GRIDS:
        w=frac*R
        vol=w**source.n
        table,active=inventory(w,w*phase,parents,src,rows,source)
        axis_cap=source.floor+(source.peak-source.floor)*min(w,2*source.bump)/w
        assert w+2*source.bump<source.period
        global_upper=[c*axis_cap**source.n for c in coeff]
        assert max(global_upper)<TAU
        cap2=weighted_median_gap(table,vol)
        print(" grid w=",w,"; phase/w=",phase,"; active cubes",len(table),
              "; both role-law global pre-thinning density caps:",
              *(fmt(x) for x in global_upper))
        print("  exact live density spans, full then old-only:",
              tuple(outward(min(q[k]/vol for m,q in table),max(q[k]/vol for m,q in table)) for k in (0,1)))
        tests=[("theorem-scale rational diagnostic",TAU),("straddled actual pressure",cap2)]
        if frac==F(1,32):
            tests.append(("fixed common pressure across phases",F(1,32768)))
        for name,tau in tests:
            print(" ",name,"tau",fmt(tau))
            for role in (0,1):
                means,peaks,census=summarize_grid(table,active,src,vol,tau,role)
                x,y=original(rows,means,parents),original(hard,means,parents)
                strict=census["cells_strict"]
                if tau==TAU:
                    assert strict==0 and x[0]==x[1]==sum(rows.values()) and y[0]==y[1]==sum(hard.values())
                if role==0 and tau==cap2:
                    assert 0<strict<len(table)
                print("   ",("full eight","old-only five")[role],
                      "strict/saturated",strict,census["cells_saturated"],
                      "; strict actual source fraction",
                      fmt(census["active_mu_strict"]/sum(src[i] for i in active)),
                      "; peak nu density before/after",*(fmt(a) for a in peaks),
                      "; retained frozen nu over active grid cubes",
                      fmt(census["window_nu_after_live_cells"]/census["window_nu_in_live_cells"]))
                print("     all/hard theta-product, both untouched, exactly one untouched, per F:",
                      tuple(fmt(q/F0) for q in x[:3]),tuple(fmt(q/F0) for q in y[:3]))
                print("     max marked original weight per actual U/W half Lebesgue, all/hard:",
                      tuple(fmt(a) for a in x[3]),tuple(fmt(a) for a in y[3]))
    print("Every active price cell is fully recovered and every thinned grid capacity is certified.")
    print("The fixture is a four-dimensional exact check; the large-history high-load regime is outside its scope.")


if __name__=="__main__":
    parser=ArgumentParser()
    parser.add_argument("--rounds",type=Path,required=True)
    main(parser.parse_args().rounds)

