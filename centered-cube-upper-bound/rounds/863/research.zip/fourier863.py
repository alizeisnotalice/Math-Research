"""Certified torus tests of a common box-average translation supremum."""

from fractions import Fraction as F
from itertools import product
from math import isqrt, prod
from sys import version

from flint import __version__ as flint_version
from flint import arb, ctx

ctx.prec = 320
PI = arb.pi()
TINY = arb(2)**-180


def to_ball(value):
    return arb(value.numerator)/value.denominator


def sinc(x):
    return arb(1) if x.is_zero() else x.sin()/x


def exponent(x, p):
    return (x.log()*to_ball(p)).exp()


def dilation_energy(n, epsilon, constant):
    return ((4*constant*epsilon**2).log1p()*n).expm1()


def fmt(value):
    return value.str(9)


def audit_one_axis():
    # On x^2 <=3/2, multiply the alternating Taylor majorant of sin^2
    # by x^-2+1/3. The coefficients of x^2,x^4,x^6 are these.
    assert -F(1,3)+F(1,3) == 0
    fourth, sixth = F(2,45)-F(1,9), F(2,135)
    assert fourth+F(3,2)*sixth == -F(2,45)
    assert 1/F(3,2)+F(1,3) == 1
    for x in map(to_ball,(F(1,128), F(1,5), F(1), F(7,6), F(5,4), F(9,2))):
        assert sinc(x)**2+x.sin()**2/3 < 1
    print("One-axis tensor weight is sinc(x)^2+sin(x)^2/3 <= 1.")
    print("The rational Taylor bound for x^2<=3/2 is 1-2*x^4/45. For larger x use x^-2+1/3.")


def spectral_data(s, period, counts, modes):
    amplitudes, tensor_nonempty_check = [], []
    zero_energy = arb(0)
    total_energy = arb(0)
    bare_energy = arb(0)
    for frequencies, amplitude, phase in modes:
        scale = to_ball(amplitude)
        bare_energy += scale**2/2
        xi = [s*k/period for k in frequencies]
        m2 = prod(sinc(x)**(2*b) for x,b in zip(xi,counts))
        full = prod((sinc(x)**2+x.sin()**2/3)**b for x,b in zip(xi,counts))
        independent = m2*prod((1+x**2/3)**b for x,b in zip(xi,counts))
        assert (full-independent).contains(0)
        tensor_nonempty_check.append(full)
        zero_energy += scale**2*m2/2
        total_energy += scale**2*full/2
        amplitudes.append((frequencies,scale*m2.sqrt(),to_ball(phase)*PI))
    assert all(value <= 1 for value in tensor_nonempty_check)
    assert zero_energy < total_energy < bare_energy
    return amplitudes, bare_energy, (total_energy-zero_energy)/bare_energy


def add_cos(terms, v, phase, amplitude):
    a,b = terms.get(v,(arb(0),arb(0)))
    terms[v] = (a+amplitude*phase.cos(),b-amplitude*phase.sin())


def finite_shift_data(amplitudes, shifts, mesh):
    data = []
    for h in shifts:
        contributions = []
        first = {}
        for frequency, scale, phase in amplitudes:
            angle = sum(x*y for x,y in zip(frequency,h))
            shifted_phase = phase+angle/2
            coef = -2*scale*(angle/2).sin()
            contributions.append((frequency,coef,shifted_phase))
            first[frequency] = (coef*shifted_phase.sin(),coef*shifted_phase.cos())
        square = {}
        for u,b,p in contributions:
            for v,d,q in contributions:
                diff = tuple(x-y for x,y in zip(u,v))
                sums = tuple(x+y for x,y in zip(u,v))
                add_cos(square,diff,p-q,b*d/2)
                add_cos(square,sums,p+q,-b*d/2)
        # Integral over the mesh cell divided by its volume, centered at theta.
        for v,(a,b) in square.items():
            correction = prod(sinc(PI*x/mesh) for x in v)
            square[v] = (a*correction,b*correction)
        fixed = sum(coef*coef for _,coef,_ in contributions)/2
        lip = sum(abs(coef)*sum(map(abs,v)) for v,coef,_ in contributions)
        data.append((first,square,fixed,lip))
    return data


def dot_value(terms, phases):
    return sum((a*phases[v][0]+b*phases[v][1] for v,(a,b) in terms.items()),arb(0))


def finite_bounds(data, rank, mesh, norm_squared):
    keys = set().union(*(set(first)|set(square) for first,square,_,_ in data))
    trig = [((PI*j/mesh).cos(),(PI*j/mesh).sin()) for j in range(2*mesh)]
    integrated, midpoint = arb(0),arb(0)
    for point in product(range(1,2*mesh,2),repeat=rank):
        phases = {v:trig[sum(x*y for x,y in zip(point,v))%(2*mesh)] for v in keys}
        tests = [abs(dot_value(first,phases)) for first,_,_,_ in data]
        # Any selected common shift yields a valid lower bound on this entire cell.
        # Selection at an interval midpoint changes only which exact integral is used.
        selected = max(range(len(data)),key=lambda i:tests[i].mid())
        integrated += dot_value(data[selected][1],phases)
        max_ball = tests[0]
        for x in tests[1:]:
            max_ball = max_ball.max(x)
        midpoint += max_ball*max_ball
    norm = norm_squared.sqrt()
    integrated = (integrated/mesh**rank).sqrt()/norm
    sampled = (midpoint/mesh**rank).sqrt()/norm
    fixed = arb(0)
    lip = arb(0)
    for _,_,energy,constant in data:
        fixed = fixed.max(energy)
        lip = lip.max(constant)
    cell_error = PI/mesh*lip/norm
    return fixed.sqrt()/norm, integrated, sampled+cell_error, cell_error


def multifrequency(label, n, period, counts, modes, mesh, side_scales):
    epsilon = exponent(arb(n),F(-11,12))
    print(f"{label} n={n}, physical circle circumference=2*pi*{period}, phase blocks={counts}, mesh={mesh}")
    for s0 in side_scales:
        s = to_ball(s0)
        amplitudes, f2, e_mix = spectral_data(s,period,counts,modes)
        # One physical h determines all its mode phases. All endpoints and zeros
        # of these disjoint-block shift intervals are realized by actual h.
        shifts = [tuple(epsilon*s*b*sign/period for b,sign in zip(counts,choice))
                  for choice in product((-1,0,1),repeat=len(counts)) if any(choice)]
        data = finite_shift_data(amplitudes,shifts,mesh)
        fixed,lower,finite_up,mesh_error = finite_bounds(data,len(counts),mesh,f2)
        continuous_up = (dilation_energy(n,epsilon,3)*e_mix).sqrt()
        universal_up = dilation_energy(n,epsilon,8).sqrt()
        assert 0 < fixed < lower < continuous_up < universal_up
        assert lower < finite_up
        assert all(a.rad()<TINY for a in (fixed,lower,finite_up,mesh_error,e_mix,continuous_up))
        useful_up = finite_up.min(continuous_up)
        print(f"  s={s0}, tested shifts={len(shifts)}, norm ratios")
        print(f"    best fixed h {fmt(fixed)}, certified finite lower {fmt(lower)}")
        print(f"    finite upper {fmt(useful_up)}, midpoint geometric error bound {fmt(mesh_error)}")
        print(f"    nonempty mixed energy {fmt(e_mix)}, continuous upper {fmt(continuous_up)}, original C0=8 upper {fmt(universal_up)}")


def pure_and_cost(n,s0):
    s = to_ball(s0)
    epsilon = exponent(arb(n),F(-11,12))
    tau = exponent(arb(n),F(1,16))
    period = isqrt(n)
    assert period**2 == n
    x = s/period
    one_axis = sinc(x)**2+x.sin()**2/3
    assert one_axis < 1
    m2 = ((sinc(x)**2).log()*n).exp()
    nonempty = m2*((x*x/3).log1p()*n).expm1()
    assert (nonempty+m2-(one_axis.log()*n).exp()).contains(0)
    angle = epsilon*s*n/period
    assert 0 < angle < PI/2
    # Sup over phase offsets [-angle,angle] equals the better endpoint.
    # The normalized Haar average of (cos(theta)-cos(theta+angle))^2
    # follows from the integral on [0,pi/2], then divide by ||cos||_2^2=1/2.
    amplitude = (2*(angle/2).sin()*(1+2*angle.sin()/PI).sqrt()*m2.sqrt())
    full_energy = dilation_energy(n,epsilon,8)
    data_upper = (dilation_energy(n,epsilon,3)*nonempty).sqrt()
    upper = full_energy.sqrt()
    assert 0 < amplitude < data_upper < upper
    volume_log2 = n*epsilon.log1p()/arb(2).log()
    c_model = 1+arb(n).sqrt()*upper
    expense = tau**2*c_model**4/exponent(arb(n),F(11,24))
    equivalence = (1/(arb(n)*epsilon)+(full_energy/(arb(n)*epsilon**2)).sqrt())**4
    assert (expense-equivalence).contains(0)
    assert all(a.rad()<TINY for a in (one_axis,amplitude,upper,data_upper,volume_log2,expense))
    print(f"PURE n={n}, s={s0}, all n frequency coordinates nonzero, physical circle circumference=2*pi*{period}")
    print(f"  exact continuous norm ratio {fmt(amplitude)}, mixed-data upper {fmt(data_upper)}, C0=8 upper {fmt(upper)}")
    print(f"  log2 of individual volume inflation n log2(1+epsilon) = {fmt(volume_log2)}")
    print(f"  exact continuous ratio / (epsilon sqrt(n)) = {fmt(amplitude/(epsilon*arb(n).sqrt()))}")
    print(f"  fee excluding (H/L)j(A), normalized by n^(11/24) with N=n = {fmt(expense)}")


if __name__ == "__main__":
    print(f"Python {version.split()[0]}, python-flint {flint_version}, Arb precision {ctx.prec} bits.")
    print("A_s averages over [-s,s]^n on its physical torus, Haar mass one. epsilon=n^(-11/12).")
    print("Mixed FTOC on one common shift gives the continuous bound after Cauchy-Schwarz and Parseval.")
    print("Piecewise selecting one actual finite h and integrating its square gives the finite lower bound.")
    print("Finite midpoint upper adds the displayed geometric Lipschitz error. Arb internal radii checked <2^-180.")
    audit_one_axis()
    multifrequency("FIRST WINDOW",2,2,(1,1),(
        ((1,0),F(1),F(0)),((0,1),F(3,4),F(1,5)),
        ((1,1),F(1,2),F(-1,7)),((2,-1),F(1,4),F(1,3))),
        24,(F(1,2),F(3,4),F(1)))
    multifrequency("EXPANDED MULTIFREQUENCY",16,4,(5,5,6),(
        ((1,0,1),F(1),F(0)),((0,1,-1),F(4,5),F(1,7)),
        ((1,-1,0),F(3,5),F(1,9)),((1,1,1),F(1,3),F(-1,5))),
        12,(F(1,2),F(1)))
    print("Pure phases allow analytic continuous sup, since the common shift offsets cover the full phase interval.")
    assert 2*F(1,16)+4*(1-F(11,12)) == F(11,24)
    print("Original scalar cost is (H/L)j(A) tau^2 K^4. tau=n^(1/16), K~n*epsilon, exponent 11/24.")
    print("N=n below only fixes the scalar upper-bound prototype. No original multiscale history is simulated.")
    pure_and_cost(16,F(1,2))
    pure_and_cost(2**48,F(3,4))
    pure_and_cost(2**96,F(1))
