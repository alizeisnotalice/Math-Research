"""R863: exact D_C and Arb-enclosed one-end weighted charge on real records."""
from argparse import ArgumentParser
from collections import defaultdict
from fractions import Fraction as F
from functools import reduce
from hashlib import sha256
from itertools import pairwise
from math import prod
from pathlib import Path
import runpy
import sys

from flint import arb,ctx,__version__ as flint_version

PIN_WEIGHTED="4bd95c8a88f9c1edd9fa4338ac91dbb0eb3b1b555985af16fed938882c601430"
GRIDS=((F(1,4),F(0)),(F(1,32),F(0)),(F(1,32),F(1,2)))


def A(x):
    return arb(x.numerator)/x.denominator


def fmt(x):
    return "0" if x==0 else (A(x) if isinstance(x,F) else x).str(10,radius=True)


def read(rounds):
    path=Path(__file__).with_name("weighted863.py")
    assert sha256(path.read_bytes()).hexdigest()==PIN_WEIGHTED
    helper=runpy.run_path(str(path))
    actual,comb,stage,parents,src,rows,hard,_,R=helper["load"](rounds)
    source=actual["Source"](comb,stage)
    assert R==1
    return helper,source,parents,src,rows,hard


def inventory(helper,source,parents,src,rows,w,phase):
    active={arm[1] for t,l,r in rows for arm in (l,r)}
    arms=sorted({(t,arm[0]) for t,l,r in rows for arm in (l,r)})
    gates=[helper["intersect"](parents[t]["box"],parents[i]["box"]) for t,i in arms]
    total=defaultdict(F)
    entries=[]
    for box in helper["relevant_grid"](w,w*phase,gates):
        piece=helper["mass_by_mask"](box,parents,src.keys(),source)
        assert sum(piece.values())==prod(source.mass(a,b) for a,b in box)
        if not active&piece.keys():
            continue
        for c,mu in piece.items():
            if c in active:
                total[c]+=mu
        entries.append(piece)
    assert dict(total)=={c:src[c] for c in active}
    return entries,active


def effective_table(pieces,coeff,lam,volume):
    f={y:b*b/(b+lam) for y,b in coeff.items()}
    table=[(sum(f[y]*mass for y,mass in p.items())/volume,p) for p in pieces]
    assert all(q>0 for q,p in table)
    return table


def split_pressure(table,active):
    by_density=defaultdict(F)
    for d,p in table:
        by_density[d]+=sum(p[y] for y in active&p.keys())
    totals=sum(by_density.values())
    highest=max(by_density)
    walked=F(0)
    for a,b in pairwise(sorted(by_density)):
        walked+=by_density[a]
        if 2*walked>=totals or b==highest:
            q=(a+b)/2
            assert min(by_density)<q<highest
            return q
    raise AssertionError("the chosen empirical grid has a single density")


def distributions(table,active,src,K2,volume):
    support={y:defaultdict(F) for y in sorted(active)}
    density={d for d,p in table}
    exact={d:min(F(1),1/(K2*d)) for d in density}
    saturated=weight_saturated=F(0)
    charged=F(0)
    unthinned=F(0)
    for d,p in table:
        assert exact[d]*K2*d*volume<=volume
        if exact[d]<1:
            assert exact[d]*K2*d*volume==volume
            saturated+=1
            weight_saturated+=sum(p[y] for y in p.keys()&active)
        charged+=exact[d]*K2*d*volume
        unthinned+=K2*d*volume
        for y in p.keys()&active:
            support[y][d]+=p[y]/src[y]
    assert all(sum(row.values())==1 for row in support.values())
    return support,exact,saturated,weight_saturated,charged,unthinned


def continuous_mark(records,support,weight,K2,parents):
    means={y:sum((A(p)*weight[d] for d,p in values.items()),arb(0))
           for y,values in support.items()}
    uncut={y:sum(p for d,p in values.items() if K2*d<=1) for y,values in support.items()}
    pairs={}
    result=[arb(0),arb(0),arb(0)]
    saturated_both=F(0)
    uncut_both=F(0)
    marginals=[defaultdict(arb),defaultdict(arb)]
    raw_marg=[defaultdict(F),defaultdict(F)]
    for (t,l,r),amount in records.items():
        z,q=l[1],r[1]
        key=tuple(sorted((z,q)))
        if key not in pairs:
            # omega decreases with D_C/|C|, so the exact argument of max
            # is the minimum of the two physical grid density classes.
            vals=defaultdict(F)
            for a,p in support[z].items():
                for b,s in support[q].items():
                    vals[min(a,b)]+=p*s
            assert sum(vals.values())==1
            pairs[key]=sum((A(p)*weight[d] for d,p in vals.items()),arb(0))
        for j,x in enumerate((means[z],means[q],pairs[key])):
            result[j]+=A(amount)*x
        saturated_both+=amount*(1-uncut[z])*(1-uncut[q])
        uncut_both+=amount*uncut[z]*uncut[q]
        for s,(i,y,k) in enumerate((l,r)):
            marginals[s][i,k]+=A(amount)*pairs[key]
            raw_marg[s][i,k]+=amount
    original=sum(records.values())
    assert all(x<=parents[i]["owner_volume"]/2 for slot in raw_marg for (i,k),x in slot.items())
    assert all(x.overlaps(result[2]) for x in (sum(slot.values(),arb(0)) for slot in marginals))
    for slot,base in zip(marginals,raw_marg):
        for (i,k),x in slot.items():
            reference=A(base[i,k])
            assert x<reference or x.overlaps(reference)
    peak=tuple(reduce(arb.max,(A(2/parents[i]["owner_volume"])*x
                              for (i,k),x in slot.items())) for slot in marginals)
    return result,saturated_both,uncut_both,peak


def compare(high,low):
    h,fb,ub,peak=high
    l,lb,cut,other=low
    assert fb==lb and ub==cut
    assert all(x.overlaps(y) for x,y in zip(h+list(peak),l+list(other)))


def main(rounds):
    helper,source,parents,src,rows,hard=read(rounds)
    M=sum(rows.values())
    coeff={y:sum(p["j"]/p["m"] for p in parents.values() if p["bit"]&y) for y in src}
    full_k=sum(p["j"]/p["m"] for p in parents.values())
    assert len(parents)==8
    prototype_lam=F(1,2)
    prototype_K2=F(source.n)
    pressure_lam=full_k/4
    data=[]
    for w,phase in GRIDS:
        pieces,active=inventory(helper,source,parents,src,rows,w,phase)
        vol=w**source.n
        p=effective_table(pieces,coeff,prototype_lam,vol)
        q=effective_table(pieces,coeff,pressure_lam,vol)
        data.append((w,phase,vol,p,q,active))
    zero_fine=next((q,active) for w,phase,vol,p,q,active in data if w==F(1,32) and phase==0)
    cutoff=split_pressure(*zero_fine)
    pressure_K2=1/cutoff

    print("Python",sys.version.split()[0],"python-flint",flint_version,"; exact Fraction D_C and 192/384-bit Arb roots.")
    print("Pinned weighted863.py",PIN_WEIGHTED)
    print("All eight physical window labels; G_i is the archived true A_i, b_i=j_i/m_i.")
    print("Every used grid cube is integrated over all true mu, including inactive original price membership.")
    print("Original/hard record counts",len(rows),len(hard),"; all mass shares below normalized by full F.")
    print("Prototype lambda=4^(-1/2), K^2=4; diagnostic pressure lambda=(sum b_i)/4 exactly",
          pressure_lam,"; common pressure K^2 =",pressure_K2,
          "; threshold 1/K^2 =",fmt(cutoff))
    print("For each grid, omega^2 K^2 D_C <= physical volume is exact; omega itself is rounded outward.")
    for w,phase,vol,p,q,active in data:
        cap1=source.floor+(source.peak-source.floor)*min(w,2*source.bump)/w
        assert w+2*source.bump<source.period
        true_global_upper=cap1**source.n*full_k**2/(full_k+prototype_lam)
        assert prototype_K2*true_global_upper<1
        print(" grid w",w,"phase/w",phase,"positive price-source cubes",len(p),
              "; global prototype D_C/|C| upper",fmt(true_global_upper))
        for label,table,K2 in (("prototype",p,prototype_K2),("common pressure",q,pressure_K2)):
            support,omega2,n_sat,mu_sat,used_charge,provisional_charge=distributions(table,active,src,K2,vol)
            results=[]
            for bits in (192,384):
                ctx.prec=bits
                weight={d:A(a).sqrt() for d,a in omega2.items()}
                results.append((continuous_mark(rows,support,weight,K2,parents),
                                continuous_mark(hard,support,weight,K2,parents)))
            for hi,lo in zip(*results):
                compare(hi,lo)
            print("  ",label,"D_C/|C| span",fmt(min(omega2)),fmt(max(omega2)),
                  "; strict saturated cubes",n_sat,
                  "; actual price mass on them",fmt(mu_sat/sum(src[y] for y in active)),
                  "; actual/provisional square charge",
                  fmt(used_charge),fmt(provisional_charge),fmt(used_charge/provisional_charge))
            for key,item,original in zip(("all","hard"),results[-1],(M,sum(hard.values()))):
                vals,both_sat,both_untouched,peak=item
                exact_full=(both_sat==0)
                if exact_full:
                    assert vals[2].overlaps(A(original))
                else:
                    assert vals[2]<A(original)
                if label=="prototype":
                    assert both_untouched==original and all(x.overlaps(A(original)) for x in vals)
                print("    ",key,"original left/right/max shares",tuple(fmt(x/A(M)) for x in vals),
                      "; both branches clipped weight",fmt(both_sat/M),
                      "; full by max",exact_full)
                print("      max-marked U/W weights per actual half Lebesgue:",tuple(fmt(x) for x in peak))
    print("All checks passed. Finite geometric one-end marking and square-charge capacity, without old-contract payment inference.")


if __name__=="__main__":
    parser=ArgumentParser()
    parser.add_argument("--rounds",type=Path,required=True)
    main(parser.parse_args().rounds)

