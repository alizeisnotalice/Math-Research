# R239 independent audit — statement-first checkpoint

The contract was read when it appeared. The first reads preceded its creation; the bounded screening below uses the exact parent/author statements and the frozen R238 interface. No R239 author proof has yet been read. Only this audit file is edited.

## Correction: original receiver hardcap also applies to beta

On the retained original receiver Omega, beta<=f and the original all-R hardband imply beta(Q_R(x))<=C0 q R^n for every R in [a,b]. The same is true for every frozen positive geometry witness mu<=f. A blanket statement that beta cannot receive this receiver hardcap is too strong and is corrected here. What cannot be transferred to beta is nu's source rank, actual birth-piece gate, source density qualification or a new uniform source-centered mass cap. This correction does not change either original source, posterior or frozen historical commit.

Write H_R=C0 q R^n and H_b=C0 q b^n; they have mass units. The fixed-R threshold H_R must not be replaced by q alone. For a common all-node certificate, H_b is a safe threshold, together with the original whole-scale hardband.

## Forbidden cubes and their real union

For a cube C of full side d<=R with beta(C)>H_R (or mu(C)>H_R), no original receiver can have Q_R(x) containing C. Its forbidden-center cube is E_R(C)=Q_(R-d)(center C). For any original hard z, not necessarily in C, the exact excluded receiver volume within Q_R(z) is the product of coordinate intersection lengths

    product_i [min(z_i+R/2,c_i+(R-d)/2)
               -max(z_i-R/2,c_i-(R-d)/2)]_+.

It gives an occupation loss after division by R^n. For d>R there is no containing-center cube and this exclusion argument gives no loss; for d=R its volume is zero. For d<=a and mass>H_b the same source cube is forbidden for every legal node. Several cubes give the volume of the actual union of their forbidden-center sets, not the sum of overlapping volumes. A finite/countable measurable family or another proved measurable union is sufficient; no source-cover multiplicity arises if the hard source is still integrated once.

The proposed homothetic passage is valid even if z is outside C. For x in Q_a(z), let x_R=z+(R/a)(x-z). Then Q_a(x) is contained in Q_R(x_R), by the coordinate triangle inequality. Thus any lowest-scale bad-mass event, and any union of its certified forbidden centers, maps into a real R-scale forbidden set. The map scales volume by (R/a)^n. In particular, for fixed mu<=f let

    U_a={x:mu(Q_a(x))>H_b},
    delta_base(z)=a^(-n) |Q_a(z) minus U_a|.

Then O_R(z)<=delta_base(z) for all R in [a,b]. The convolution of L1 mu with a cube indicator is continuous, so U_a is Borel and delta_base is measurable. This formulation avoids an unsupported uncountable-union measurability claim. It does not normalize an adaptive hard scale or change traffic sources.

## Exact missing-mass inequality

Fix z,R and a finite witness sigma<=f, T=sigma(total), X uniform on Q_R(z), m_X=sigma(Q_R(X)). On the original Omega, m_X<=H_R; everywhere m_X<=T. Therefore

    E m_X <= H_R O_R(z)+T(1-O_R(z)),
    O_R(z) <= min(1,(T-E m_X)/(T-H_R)),  T>H_R.

For T<=H_R there is no gain from this ratio and the unit occupation bound is used. Tonelli gives

    E m_X=integral a_R(y,z)sigma(dy),
    a_R(y,z)=product_i (1-|y_i-z_i|/R)_+.

A local total T may be obtained by restricting the witness to Q_(2R)(z), or to its intersection with D_V(z); this is a source restriction for a geometry witness, not a new traffic posterior. The scale 2R here merely names a local source set and is not granted a hardcap outside [a,b]. For a common fixed witness with T>H_b, a_R>=a_a yields the all-node bound

    O_R(z) <= min(1, integral [1-a_a(y,z)]sigma(dy)/(T-H_b)).

High local beta(D(z)) alone does not make the missing-mass numerator small. Retaining its weighted overlap or an actual concentrated submeasure is the extra geometric content; replacing that numerator by T generally loses any gain.

## Optimized mean witness

Let mu<=f be finite and frozen, c_z(y)=1-a_a(y,z), H=H_b, and

    Phi_z(r)=integral (1-c_z(y)/r)_+ mu(dy),
    delta_W(z)=inf{r in (0,1]:Phi_z(r)>=H}, empty set ->1.

Because c_z=0 only at y=z and mu is atomless, Phi_z(r)->0 as r decreases to zero. Phi is continuous for r>0, nondecreasing, and strictly increases wherever it is positive before saturation. It follows that delta_W is measurable, strictly positive and <=1, including the empty/r=1 endpoint cases. No zero denominator is required.

If Phi_z(r)>=H, take sigma=mu restricted to {c_z<r}. Its mass T is strictly greater than H, and integral c_z sigma<=r(T-H). Conversely, any sigma<=mu with T>H and ratio integral c_z sigma/(T-H)<=r satisfies

    r H <= integral (r-c_z) sigma <= integral (r-c_z)_+ mu.

Hence delta_W equals min(1,inf over these positive-denominator witness ratios). This is the sharp charge within this mean-deficit witness family; it is not asserted to equal the actual receiver occupancy. In fact the exact base allowed fraction delta_base above is <=delta_W for the same mu, because every witness ratio also bounds that base allowed event.

The witness mu or sigma only proves original receiver exclusion. It does not replace nu in either posterior, beta in the actual anchor slot, or the source marginal being charged. A measurable choice may depend on original hard z before x,y,v,u,j,M,t. With any certified common delta, the R238 full-scale estimate and its paid source subset may be reused with their entire constants and source moment. That is not automatically a bound on the general complementary source set.

A useful explicit sufficient condition is T>=(1+eta)H and
mean_sigma ||y-z||_1/a <= eta A/[(1+eta)R_D(z)^3], eta>0.
Indeed c_z<=min(1,||y-z||_1/a), so it implies delta R_D^3<=A. It is a real geometric condition and is not supplied just by the size of beta(D(z)).

## Common-receiver second moments: permitted interface

For two witnesses mu_1,mu_2<=f use the same X uniform on Q_a(z). The exact cross moment is the integral against mu_1(dy)mu_2(dy') of

    |Q_a(z) intersect Q_a(y) intersect Q_a(y')|/a^n.

The witnesses or their masses are not independent draws of receivers. A nonnegative convex combination has witness <=f, threshold H, and its variance includes the actual covariance term. If its mean exceeds H, Cantelli gives the allowed-probability bound variance/[variance+(mean-H)^2]. Zero variance with mean>H means zero allowed probability; mean<=H provides no such gain. Signed or unnormalized coefficients do not keep the same witness cap/threshold for free. Any claimed joint certificate must retain these same-X quantities and actual positivity conditions.

## Bounded local tool evidence and status

Actual local execution passed 36 exact Fraction finite-density interval checks of the mean-deficit and forbidden-box inequalities, 20 finite positive-cost threshold/ratio optimization cases, and 60 homothetic center tests. These are bounded fixed-R/algebra diagnostics, not FULL histories, interval certificates for later numerics or archived formal replay experiments; their temporary standalone code is not archived. The proofs above use Tonelli, positive-measure domination and elementary box geometry.

Statement-first result: the proposed mean/witness and common-base geometry interfaces pass with these qualifications. The old prohibition on beta's original receiver hardcap is explicitly corrected. Quantitative actual-source payment requires retaining a certified delta, the original D(z) local soft mass, all R238 constants and the remaining source moment/complementary branch ledger. No general root closure or nonempty/full coverage claim is inferred. Awaiting the exact author proofs for final audit; no broad counterexample search was undertaken.

## Final author-proof audit

The complete parent proof (1)–(11), source_exclusion_geometry.md WG1–WG10 and distributed_overlap.md DO1–DO6 were read. Their new geometric estimates pass. The inherited all-scale cap is used only on original Omega, while beta/f/mu witnesses are never inserted as new traffic sources. The common base-radius dilation, exact forbidden-union volume and mean-deficit inequality preserve true Lebesgue receiver measure and each fixed hard anchor. The earlier warning about beta's hardcap is expressly corrected; beta's source-rank/birth qualifications remain distinct.

The optimized Phi threshold and fractional witness infimum are equivalent on the actual finite absolutely continuous domain. In particular equality Phi=H still gives the selected mass T>H because c_z=0 is the singleton z and has zero mu mass. The positive threshold and small-r dominated limit imply delta_W>0. Empty/one endpoints, measurable rational thresholds and cap-one conventions are correct. Sharpness is restricted to the mean-deficit witness class: delta_base<=delta_W, and neither is identified with the actual receiver occupation. A selected witness's mass is not substituted for beta(D(z)) in the final source congestion.

The first/cross second moment kernel is the common three-cube intersection, not a product of independent receiver probabilities. Its covariance matrix is positive semidefinite. The one-sided variance inequality, zero-variance positive-gap case, nonnegative convex combination restriction and sign qualification for the inverse-covariance formula are correct. Rational finite-support simplex weights give the same measurable infimum: positive gap is open, the ratio is continuous there, and the common ||f||_1 bound supplies uniform approximation for countable probability weights. An unattained zero infimum still forces every original O_R(z)=0; zero anchors are removed before logarithms. No signed witness combination or free source-scale supremum is used.

Any stated minimum of certified common occupation bounds remains a bound for the same original receiver. R238's already audited actual-I0 interpolation, half-menu price, full-nu Gini and 7/(64theta^3) sum then apply unchanged. All theta_z factors stay inside original nu(dz) until the fixed-anchor sum is settled. The final constant is C*=12 Lambda exp(4)(7e/8), Lambda=128/119, with no new union/source multiplicity. The {delta R_D^3<=A} payment follows with 4A+108/exp(3), retaining beta(D(z)), unchanged full-nu posteriors and all original historical/complementary qualifications. Neither a general input/root budget for the complementary set nor FULL nonemptiness/positive mass fraction of the paid set is certified.

## Independent execution and domain guards

Both the full numeric source and notes were read. Independent complete replay passed and its entire 25802-byte JSON was byte-identical, SHA256 955168bad62c07aa56f27adb700a030d1dd06951a34a01cbd4a9912c90e568c1. Its separately counted objects are three main true L1 receiver models, three true L1 boundary cases, two Phi models (each five rational-r values and four thresholds), eight atomic diagnostics and 24 rational homothety cases. Fraction arithmetic exactly handles affine receiver sublevel lengths, equality plateaus, tent integrals, rational threshold brackets and the expanded-coordinate inclusion. These tools are not FULL original source/history instances.

The atomic cost-zero mass exactly H is deliberately outside the actual L1 theorem: it may have threshold delta=0 while the strict-T>H ratio infimum is positive or has no feasible witness. The script keeps threshold_delta and fraction_delta_cap1 separate and explicitly flags this degeneracy; it does not assert theorem equivalence for that example. Cost-zero mass greater than H and near-threshold stress are also distinguished. The genuine L1 models have no singleton mass and obey the theorem's strict-denominator guard.

The DO6 archived embedded script was independently extracted and run. All three exact Fraction tests matched the recorded means, variances, negative covariances and zero joint Cantelli price (densities 6,8,12). The high-dimensional slab statement correctly separates dimension-independent local moments from dimension-dependent source mass, and the positive-anchor example does not claim a FULL history construction. The WG author's 15 additional L1-tool checks remain author-reported diagnostics, not relabeled as this auditor's executions. The initial temporary 36+20+60 checks likewise are separate bounded diagnostics without archived standalone scripts, not extra formal replay configurations.

The final report and reproduction driver were also read. The report preserves the L1/atomic guard, same-X covariance, witness-only role and unproved complementary-source budget. The driver copies the contract/source outside the frozen package, compares the complete JSON, extracts/runs the three archived moment checks and verifies the manifest before and after. Final manifest-driver execution belongs to the parent's external receipt; it is not claimed by this audit.

**Final conclusion: pass within the stated original-far scope.** The beta receiver-hardcap correction and new witness/common-center certificates are valid, with the stated original R238 costs. General root closure, FULL nonemptiness/positive coverage of the paid subset and the complementary source moment remain unproved. All final source files below are bound by SHA256; this table excludes the audit itself. The auditor releases this file and stops writing after this table.


| File | SHA256 |
| --- | --- |
| task_contract.md | `8afc05d54bc947d904e1c289dd2cd8ca14ff04ffe1e8bc32ef7d44f4b62c3e85` |
| proof.tex.txt | `92c063d0529f5f13b108b7e470f57f94700031fdaae93d2b66cc6f94d1d624cc` |
| source_exclusion_geometry.md | `c7852132fb123b4b19f38ea13f0fdb31a33a0c23280d756dbd07c03ec045d841` |
| distributed_overlap.md | `2989e70df65a5994714c4fcb314a28d2d9fd0571d2cdaf8c5f028c90869bcc50` |
| report.md | `47f61d188870ee9b2bada7c9c17b010a10d86494f59e216fa84b94c36098403d` |
| numeric_checks.py | `c22d51ed352069a1348ce69d70a0d620b7ef05b4dbbe0ab79e1996457e63b00d` |
| numeric_checks.json | `955168bad62c07aa56f27adb700a030d1dd06951a34a01cbd4a9912c90e568c1` |
| numeric_notes.md | `270c6f30877dc0eeaea64983bf2e9db7bb44aaeaa2551158c683fa767e16abdc` |
| reproduce.py | `a5c8fe2c094eb2cacb1446d757a37947f455825b83a58dbf02d1fd3e8cfc1780` |
