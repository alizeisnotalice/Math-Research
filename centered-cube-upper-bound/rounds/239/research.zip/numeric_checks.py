#!/usr/bin/env python3
"""Exact R239 common-source geometry and fraction tools, not FULL."""
import argparse,hashlib,json
from fractions import Fraction as F
from pathlib import Path
ROOT=Path(__file__).resolve().parent

def mass_at(x,slabs,a=F(1)):
 return sum(d*max(F(0),min(x+a/2,hi)-max(x-a/2,lo)) for lo,hi,d in slabs)
def geometry(slabs,H=F(1)):
 knots=sorted(set([F(-1,2),F(1,2)]+[t for lo,hi,_ in slabs for t in (lo-F(1,2),lo+F(1,2),hi-F(1,2),hi+F(1,2)) if -F(1,2)<t<F(1,2)]));mean=F(0);second=F(0);length=F(0);rows=[]
 for lo,hi in zip(knots,knots[1:]):
  u=mass_at(lo,slabs);v=mass_at(hi,slabs);width=hi-lo;mean+=width*(u+v)/2;second+=width*(u*u+u*v+v*v)/3
  if max(u,v)<=H:allowed=width
  elif min(u,v)>=H:allowed=F(0) if u!=v or u>H else width
  else:allowed=width*(H-min(u,v))/abs(v-u)
  length+=allowed;rows.append(dict(lo=str(lo),hi=str(hi),mass_lo=str(u),mass_hi=str(v),allowed_length=str(allowed)))
 return dict(slabs=[[str(v) for v in row] for row in slabs],source_mass=str(sum((b-a)*d for a,b,d in slabs)),receiver_H=str(H),mean=str(mean),second_moment=str(second),variance=str(second-mean**2),receiver_allowed_length=str(length),pieces=rows)
def cross(slabs1,slabs2):
 points={F(-1,2),F(1,2)}
 for lo,hi,_ in slabs1+slabs2:
  points.update(t for t in (lo-F(1,2),lo+F(1,2),hi-F(1,2),hi+F(1,2)) if -F(1,2)<t<F(1,2))
 points=sorted(points);out=F(0)
 for lo,hi in zip(points,points[1:]):
  u,v=mass_at(lo,slabs1),mass_at(hi,slabs1);p,q=mass_at(lo,slabs2),mass_at(hi,slabs2);out+=(hi-lo)*(2*u*p+u*q+v*p+2*v*q)/6
 return out

def Phi(r,slabs):
 assert r>0
 total=F(0)
 for lo,hi,d in slabs:
  points=sorted(set([lo,hi]+[t for t in (-r,F(0),r) if lo<t<hi]))
  for a,b in zip(points,points[1:]):total+=d*(b-a)*(max(F(0),1-abs(a)/r)+max(F(0),1-abs(b)/r))/2
 return total

def phi_threshold(slabs,H):
 if Phi(F(1),slabs)<H:return dict(empty=True,delta='1',Phi1=str(Phi(F(1),slabs)))
 lo=F(0);hi=F(1)
 for _ in range(80):
  mid=(lo+hi)/2
  if Phi(mid,slabs)>=H:hi=mid
  else:lo=mid
 assert (lo==0 or Phi(lo,slabs)<H) and Phi(hi,slabs)>=H
 return dict(empty=False,delta_lower=str(lo),delta_upper=str(hi),Phi_lower=str(Phi(lo,slabs)) if lo else '0',Phi_upper=str(Phi(hi,slabs)),bracket_width=str(hi-lo))
def cost(y):
 p=F(1)
 for t in y:p*=max(F(0),1-abs(t))
 return 1-p

def atomic(masses,H):
 points=[(F(0),F(0)),(F(1,4),F(1,4)),(F(1),F(0))];atoms=sorted((cost(y),m) for y,m in zip(points,masses));T=F(0);K=F(0);candidates=[]
 for c,m in atoms:
  T+=m;K+=c*m
  if T>H:candidates.append((K/(T-H),T,K))
 raw=min(candidates) if candidates else None;delta=min(F(1),raw[0]) if raw else F(1)
 phi=lambda r:sum(m*max(F(0),1-c/r) for c,m in atoms)
 empty=phi(F(1))<H
 zero_mass=sum(m for c,m in atoms if c==0)
 threshold_delta=F(0) if zero_mass>=H else delta
 # Atom equality at cost0 is not allowed by original L1 mu; keep it visible.
 equality_degeneracy=zero_mass==H
 assert threshold_delta==delta or equality_degeneracy
 if delta==0:assert sum(m for c,m in atoms if c==0)>H
 elif delta<1:assert phi(delta)==H
 else:assert empty or phi(F(1))>=H
 return dict(masses=[str(m) for m in masses],H=str(H),geometric_positions=[[str(t) for t in y] for y in points],costs=[str(cost(y)) for y in points],total_mass=str(T),feasible_prefixes=[dict(T=str(t),cost_integral=str(k),positive_denominator=str(t-H),ratio=str(v)) for v,t,k in candidates],fraction_raw=str(raw[0]) if raw else None,fraction_delta_cap1=str(delta),threshold_delta=str(threshold_delta),zero_cost_mass=str(zero_mass),zero_cost_equals_H=equality_degeneracy,threshold_fraction_agree=threshold_delta==delta,Phi1=str(phi(F(1))),threshold_empty=empty,scope='Finite atomic geometric-cost optimization diagnostic only, not L1 receiver input.')

def homothety(n,ratio,mode):
 a=F(1);R=ratio;z=[F(i%3-1,7) for i in range(n)];x=[z[i]+(F(0) if mode=='center' else F(1 if i%2 else -1,2)) for i in range(n)];xr=[z[i]+ratio*(x[i]-z[i]) for i in range(n)];margins=[]
 for i in range(n):
  left=x[i]-a/2-(xr[i]-R/2);right=xr[i]+R/2-(x[i]+a/2);assert left>=0 and right>=0;margins.extend([left,right])
 return dict(n=n,R_over_a=str(ratio),position=mode,minimum_endpoint_margin=str(min(margins)),a='1',z_pattern='(i mod3-1)/7',x_pattern='z or z+alternating±1/2',coordinate_count_checked=n,scope='Exact rational inclusion Qa(x) subset QR(z+(R/a)(x-z)); fixed homothety, not adaptive kernel normalization.')
def main(output,contract):
 left=[(F(-3,4),F(-1,4),F(6))];right=[(F(1,4),F(3,4),F(6))];mix=[(a,b,d/2) for a,b,d in left+right];models=[geometry(left),geometry(right),geometry(mix)];crossmoment=cross(left,right);cov=crossmoment-F(models[0]['mean'])*F(models[1]['mean']);assert [F(r['mean']) for r in models]==[F(3,2)]*3 and [F(r['variance']) for r in models]==[F(3,2),F(3,2),F(0)] and cov==-F(3,2) and F(models[2]['receiver_allowed_length'])==0
 pressure=[geometry(left,F(0)),geometry(mix,F(3,2)),geometry(left,F(3))]
 assert [F(r['receiver_allowed_length']) for r in pressure]==[F(1,4),F(1),F(1)]
 phis=[]
 for name,slabs in [('left',left),('mix',mix)]:
  phis.append(dict(name=name,r_values=[dict(r=str(r),Phi=str(Phi(r,slabs))) for r in [F(1,10),F(1,4),F(1,2),F(3,4),F(1)]],thresholds=[dict(H=str(H),certificate=phi_threshold(slabs,H)) for H in [F(1),F(3,2),F(2),F(3)]]))
 atomrows=[atomic(list(map(F,m)),F(h)) for m,h in [((1,2,3),1),((1,2,3),3),((1,2,3),6),((2,0,0),1),((1,0,0),1),((0,0,0),1),((1,2,3),'999999/1000000'),((1,2,3),'1000001/1000000')]]
 homo=[homothety(n,r,mode) for n in (1,2,16,128) for r in (F(1),F(3,2),F(2)) for mode in ('center','corner')]
 payload=dict(source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),contract_sha256=hashlib.sha256(Path(contract).read_bytes()).hexdigest(),scope='Exact finite implementation checks, true L1 commonreceiver slab geometry separate from atomic fraction diagnostics; not FULL/history/general closure.',L1_receiver_models=models,L1_boundary_receiver_models=pressure,common_receiver_crossmoment=str(crossmoment),common_receiver_covariance=str(cov),incorrect_independent_covariance='0 (not used)',bound_comparisons={'single_fraction_firstmoment':'3/4','single_Cantelli':'6/7','half_mixture_exact_receiver':'0','full_f_firstmoment':'3/5','common_X_required':True},L1_Phi_checks=phis,atomic_fraction_checks=atomrows,homothety_checks=homo,counts=dict(true_L1_models=len(models),true_L1_boundary_models=len(pressure),Phi_models=len(phis),atomic_diagnostics=len(atomrows),homothety_cases=len(homo)))
 Path(output).write_text(json.dumps(payload,indent=2,sort_keys=True)+'\n');print(payload['counts'])
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--output',default=str(ROOT/'numeric_checks.json'));p.add_argument('--contract',default=str(ROOT/'task_contract.md'));a=p.parse_args();main(a.output,a.contract)
