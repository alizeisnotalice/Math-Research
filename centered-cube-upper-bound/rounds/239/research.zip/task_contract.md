# R239 共同来源优化与最低尺度接收几何
日期2026-10-17；上轮9343cc98a98da7c120ee5367d7ad2f0636046359已推送，工作区开始时干净。

## 目标、纠正与准确命题
继续一般中心立方体n^(1/2+o(1))目标，集中处理中间硬层分散的高局部soft质量。R238的“不能给β硬帽”表述过宽：原Ω上h_R*f≤C0q与β≤f给同一个receiver hardcap；不能转移的是ν的rank、出生与来源密度资格。本轮明确纠正，不改写旧提交，不改变原β/ν/Π/history。

允许任意预冻结几何证人μ≤f。H=C0qb^n，c_z(y)=1−∏(1−|yi−zi|/a)_+。对σ≤μ、T=σ(total)>H，候选allR占用界O_R(z)≤∫c_z dσ/(T−H)。σ只用于证明原接收排除，不替换交通来源或posterior。优化δ_W(z)=inf{r∈(0,1]:∫(1−c_z/r)_+dμ≥H}，空集取1。证明它等于cap1后的分式最优价，检查分母、严格mass、等号、可测和δ=0情形；接R238真实列与全部节点求和，给明确付款范围。

共同最低尺度几何：x∈Qa(z)，x_R=z+(R/a)(x−z)时Qa(x)⊂QR(x_R)。因此最低尺度source mass>H_b的禁区按比例映入任R的真实禁区。精确禁区并集与两证人协方差不可重复体积或假设来源独立。

辅助路线只负责：固定X均匀Qa(z)，mμ(X)的tent均值、两个证人的共同X交叉二阶矩、Cantelli/凸组合证书及无额外scale费接入；不重复主证人的分式优化。

## 假设和已证工具
沿R238同一有限共同截断、原f≥0 L1、ν≤β≤f、q,K,a,b、D(z)、真实Ω、原allR hardband与actual FIRST、fullν两后验、合法capture、三目标腿两朝向。允许R238 7/(64θ³)全部节点和及C*=12Λe^4(7e/8)。Λ128/119与ell1+logn分开。不得免费重做source选择，不得给β赋νrank，不得将adaptiveR或s(x)核列归一。

使用64项技能A01审查单比值正分母与固定参数residual方向；不引用其外部CCT/SOS等定理填补一般root预算。新推导须自证。

## 文件责任和交付
peak：source_exclusion_geometry.md，证人优化、可测、union几何和全预算；compare：distributed_overlap.md，精确均值/协方差与共同接收；audit：audit.md，先独审命题后审作者；numeric：numeric_checks.py/json、numeric_notes.md，本机初探—边界压力—扩大范围可复现计算。主代理：contract、proof.tex.txt、report.md、reproduce.py和本轮精简归档。共享树各自限文件，不提交他人，不无限扩题；优先复用既有四Agent。

成功判据是独审通过、来源不变的真正几何估计及可付款分支或全局预算。一般补集未控制则保持明确缺口，不因几何证人可计算就宣称一般闭合；有限低维模型不得称FULL历史实例。每轮完成后独立提交推送，控制文件数、不编译PDF。
