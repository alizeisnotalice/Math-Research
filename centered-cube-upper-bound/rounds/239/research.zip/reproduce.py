#!/usr/bin/env python3
"""Frozen R239 evidence verification and exact local replay."""
import argparse,hashlib,json,shutil,subprocess,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parent
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def verify():
    hashes=json.loads((ROOT/'manifest.json').read_text())
    for name,h in hashes.items():assert digest(ROOT/name)==h,name
    return len(hashes)
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--verify-only',action='store_true');ap.add_argument('--output-dir',type=Path);args=ap.parse_args();count=verify()
    if args.verify_only:print('verified',count,'manifest hashes');return
    if args.output_dir is None:ap.error('--output-dir required')
    out=args.output_dir.resolve()
    if out==ROOT or ROOT in out.parents:ap.error('output must be outside package')
    out.mkdir(parents=True,exist_ok=False)
    for name in ('task_contract.md','numeric_checks.py'):shutil.copyfile(ROOT/name,out/name)
    start=time.monotonic()
    subprocess.run([sys.executable,str(out/'numeric_checks.py'),'--output',str(out/'numeric_checks.json'),'--contract',str(out/'task_contract.md')],check=True)
    assert (out/'numeric_checks.json').read_bytes()==(ROOT/'numeric_checks.json').read_bytes(),'entire JSON differs'
    result=json.loads((out/'numeric_checks.json').read_text())
    runs=[{'driver':'numeric_checks.py','counts':result['counts'],'entire_json_byte_identical':True,'sha256':digest(out/'numeric_checks.json'),'elapsed_seconds':time.monotonic()-start}]
    code=(ROOT/'distributed_overlap.md').read_text().split('```python\n',1)[1].split('```',1)[0]
    path=out/'distributed_moment_checks.py';path.write_text(code)
    r=subprocess.run([sys.executable,str(path)],check=True,capture_output=True,text=True)
    (out/'moment_stdout.txt').write_text(r.stdout)
    runs.append({'driver':'distributed_overlap.md embedded script','exact_density_cases':3,'stdout':r.stdout.strip(),'exit_code':r.returncode})
    assert verify()==count
    receipt={'complete_replay':True,'manifest_hashes_before_and_after':count,'runs':runs,'python':sys.executable,'scope':'Exact finite L1 receivers/moments, rational Phi certificates, atomic out-of-domain guards and finite homotheties; not FULL histories or general root closure.'}
    (out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
if __name__=='__main__':main()
