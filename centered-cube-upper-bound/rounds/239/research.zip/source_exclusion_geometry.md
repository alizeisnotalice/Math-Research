# R239：共同来源证人的精确优化与可付款接收几何

本轮纠正一个资格表述：`β≤f` 在原 receiver 集上确实继承 **原 f 的所有尺度 hardband**；不能继承的是 `ν` 的 top-k/rank、出生行和来源密度资格。利用这同一个原约束，下面允许 `β` 或完整 `f` 提供几何证人，但交通来源仍是原 `β(dy)ν(dz)`，两辅助槽仍是完整原 `ν` 的 posterior。

主结果是可计算的一阶共同来源证人最优价 `δ_W`、全节点费用 WG7 及明确已付款分支 WG8。它不声称等于真实 receiver 占用的最优界；实际最低尺度排除概率可以更强。一般远 soft 质量的剩余预算没有闭合。

## WG1. 原对象及合法几何证人

沿用 R238 冻结 checkpoint 的原有限截断、外资料 `(ω,V)`、`q,K>0`、`0<a≤b≤2a`、`ν≤β≤f dx`、原 all-soft/physical/history/capture/large-n 资格和真实 receiver 集 `Ω`。令 `C0=16/3`、`H=C0 q b^n`。

原 `G0=sup_(a≤R≤b)h_R*f≤4λ`、`q≥3λ/4` 给

\[
 \mu(Q_R(x))\le C_0qR^n\le H
 \quad(x\in\Omega,\ R\in[a,b]) \tag{WG1}
\]

对任何预冻结正测度 `μ≤f dx` 都成立。`h_R=R^−n1_QR` 使用完整边长。出处是 `GENERAL_CURRENT_REDUCTION.md` §1（第 7–13 行）；R238 主证明开头已核此原 hardband。这里必须保留原 `Ω`，不能先正放到全空间再授 WG1。

默认可取 `μ=β_V`，也可取 `μ=f dx` 或其它原预冻结子测度。`μ` 仅是证明某些 receiver 不可能存在的**几何证人上界**，不替换交通中的 `β,ν`，不重建 `Π_t,e_t,Z_t`，不重新做 FIRST。因 `μ≤f∈L1`，它有限且无原子。该帽也绝不授源中心 `z` 或任意空间点上的 `μ` 密度上界。

对固定原 hard 来源 `z`，令

\[
 c_{R,z}(y)=1-\prod_{i=1}^n(1-|y_i-z_i|/R)_+,
 \quad c_z=c_{a,z}.
\]

则 `0≤c_R,z≤c_z≤min(1,||y−z||1/a)` 对 `R≥a` 成立。`c_z=0` 当且仅当 `y=z`。以下任何 witness `σ_z≤μ` 在随机 receiver 或实际 `x` 之前固定，可以依 `z`，不能依那个 receiver 的抽样结果。

## WG2. 最低尺度的共同 receiver 几何

定义

\[
 \delta_{\rm base}(z)=a^{-n}
 |\{x\in Q_a(z):\mu(Q_a(x))\le H\}|. \tag{WG2.1}
\]

这是从原来源一次最低尺度卷积得到的概率，不涉及未知 `Ω`。对于 `x∈Q_a(z)`，令

\[
 x_R=z+(R/a)(x-z),\qquad R\ge a.
\]

每坐标 `|x_R−x|≤(R−a)/2`，所以 `Q_a(x)⊂Q_R(x_R)`。因而 `μ(Q_a(x))>H` 蕴含 `x_R∉Ω`。该映射把 `Q_a(z)` 双射为 `Q_R(z)`，Jacobian 为 `(R/a)^n`，得

\[
 \boxed{O_R(z):=\int_\Omega h_R(x-z)dx
 \le\delta_{\rm base}(z)\quad(R\in[a,b]).} \tag{WG2.2}
\]

这里是固定尺度间的显式仿射映射，不是把某个 `R(x)` 核作全空间归一。`δ_base` 的 measurability 由 `μ(Q_a(x))` 和非负积分的 measurability 得出。

## WG3. 共同来源的任意一阶证人界

取任意 `σ≤μ`，令 `T=σ(R^n)>H`。对于固定 `z,R`，令 `X` 在 `Q_R(z)` 上均匀，定义缺失质量

\[
 V_X=T-\sigma(Q_R(X))\ge0.
\]

在 `X∈Ω` 上，由 WG1，`V_X≥T−H>0`。同一个随机 receiver 对所有来源点共同使用，Tonelli 给精确均值

\[
 \mathbb E V_X=\int c_{R,z}(y)\sigma(dy),
\]

因为 `P(y∈Q_R(X))=|Q_R(z)∩Q_R(y)|/R^n=∏(1−|y_i−z_i|/R)_+`。因此

\[
 \boxed{O_R(z)\le
 \frac{\int c_{R,z}\,d\sigma}{T-H}
 \le\frac{\int c_z\,d\sigma}{T-H}.} \tag{WG3.1}
\]

在最低尺度，这个同样的一阶估计其实还证明

\[
 \delta_{\rm base}(z)\le
 \frac{\int c_z\,d\sigma}{T-H}, \tag{WG3.2}
\]

因为事件 `μ(Q_a(X))≤H` 蕴含 `σ(Q_a(X))≤H`。没有把不同 witness 或来源点当成独立事件；分母必须是严格正的 `T−H`。

## WG4. 精确分式优化和所有边界

定义输入可计算的截断函数

\[
 \Phi_z(r)=\int(1-c_z(y)/r)_+\mu(dy),\qquad r>0,
\]

以及

\[
 \boxed{\delta_W(z)=\inf\{r\in(0,1]:\Phi_z(r)\ge H\},
 \qquad\inf\varnothing:=1.} \tag{WG4.1}
\]

对于 `r>0`，若 `Φ_z(r)≥H`，取预冻结的截断证人
`σ_r=1_{c_z<r} μ`、`T_r=σ_r(R^n)`。则

\[
 \int(r-c_z)\,d\sigma_r=r\Phi_z(r)\ge rH.
\]

**即使等号 Φ=H，也有 T_r>H。** 因 `H>0` 使截断集上有正质量，而 `μ{c_z=0}=μ{z}=0`，其权 `1−c_z/r` 严格小于一几乎处处，所以 `T_r>Φ_z(r)≥H`。于是

\[
 \frac{\int c_z\,d\sigma_r}{T_r-H}\le r. \tag{WG4.2}
\]

反向，若某个 `σ≤μ`、`T>H` 的分式值不超过 `r`，则

\[
 rH\le\int(r-c_z)\,d\sigma
 \le\int(r-c_z)_+\,d\mu=r\Phi_z(r).
\]

因此，规定空 witness 族的 inf 为 `+∞`，得到准确等式

\[
 \boxed{\delta_W(z)=\min\left\{1,
 \inf_{0\le\sigma\le\mu,\ \sigma(\mathbb R^n)>H}
 \frac{\int c_z\,d\sigma}{\sigma(\mathbb R^n)-H}\right\}.} \tag{WG4.3}
\]

若分式 inf 小于一，用任意更大的 `r<1` 及上述两向论证即得等式；若没有这样的 `r`，两边均截为一。空 witness、所有 witness 的价大于一、以及恰为一的情况因此都被覆盖。

`Φ_z(r)` 随 `r` 连续且不减，由有限测度上的 dominated convergence 得到。又
`Φ_z(r)≤μ{c_z<r}→μ{z}=0` 当 `r↓0`。所以 `δ_W(z)>0`，没有非法 `log(1/0)`。若 `δ_W<1`，连续性与 inf 定义给 `Φ_z(δ_W)=H`，相应截断证人达到 WG4.3 的分式 inf；其分母仍严格正。

可测性：对固定正有理 `r`，`Φ_z(r)` 是可测函数；对于 `0<t≤1`，

\[
 \{\delta_W<t\}=\bigcup_{r\in\mathbb Q\cap(0,t)}
 \{\Phi_z(r)\ge H\}.
\]

inf 可用有理网格逼近，不必未经证明选择一个任意测度优化器。结合 WG2–4，

\[
 \boxed{O_R(z)\le\delta_{\rm base}(z)\le\delta_W(z)\le1
 \quad\text{对全部 }R\in[a,b].} \tag{WG4.4}
\]

WG4.3 的“精确”只指这个 **一阶 missing-mass witness 族**；它不声称 `δ_W=δ_base` 或等于真实 `O_R`，更不声称优化了所有接收几何。若增大几何证人上界 `μ`，`Φ` 增大、`δ_W` 不增；特别 `μ=f dx` 至少不弱于 `μ=β_V`。原交通的来源质量 `β(D(z))` 不因此替换成 `μ` 的质量。

## WG5. 显式证书：不要求一整个小 cube 独自拥挤

任意给定 `0<r≤1`，单个静态输入不等式

\[
 \int(1-c_z/r)_+\mu\ge H \tag{WG5.1}
\]

就证明全部节点 `O_R(z)≤r`。它可以由多块来源共同贡献，无需某块质量单独超过 `H`，也不要求原 hard `ν` 在其中集中。

一个更便于检查的充分条件是：存在原预冻结 `σ_z≤μ`，质量 `T_z≥(1+\eta)H`，`\eta>0`，并且

\[
 \frac1{T_z}\int\frac{\|y-z\|_1}{a}\sigma_z(dy)\le m_z.
\]

WG3 给

\[
 \boxed{\delta_W(z)\le\min\{1,(1+\eta)m_z/\eta\}.} \tag{WG5.2}
\]

更精确可用平均 `c_z` 代替平均 `l1/a`；有远尾时后者可能更大或无穷，前者始终可积。这里平均位移直接进入，没有额外乘一个 `n`。但若来源自身平均 `l1` 距离已有 `n` 的量级，不会凭此消去那个真实维数。

`σ_z` 的总量不会在最终账目中按不同 `z` 求和。它只是以已知原 hardband 排除 receiver 的点态逻辑证人；最后仍仅对原 `ν(dz)` 积一次。使用完整 `f` 的已付/已删来源部分作几何证人也没有恢复其旧负信用，因为使用的只是原 full-input 约束 WG1。

## WG6. 接回原实际列，不改变 posterior

保 R237/R238 原 source-pair `D_V(z)`，令

\[
 \rho_D(z)=\beta(D_V(z))/(qa^n),\quad
 B=e\lceil\pi\sqrt n\rceil,\quad
 R_D(z)=1+\log_+\rho_D(z)+\log_+K+\log B.
\]

这些仍来自原 soft 来源 `β`，不是几何 witness `μ`。固定 hard `z` 后，对节点 `(L*,R*,M,j)` 使用原 actual-soft 列和合法 capture：

\[
 I_0(y,z)=\int_\Omega h_{R^*}(x-z)P_{s(x),L^*}(x-y)dx.
\]

原 actual FIRST 给 `∫_{D(z)} I0 dβ≤q O_R*(z)≤q δ_W(z)`。R238 同底测度插值、半阶 QG 已付公共菜单 `B`、同一 full-ν 两槽的 Gini 界及完整节点和给，对于任意 `0<θ≤1/2`，

\[
 \sum_{j,M}(K/3)^\theta\mathcal T_{jM,z}
 \le\frac7{64\theta^3}\delta_W(z)(K/3)^\theta
 \left(\frac{B\rho_D(z)}{\delta_W(z)}\right)^{2\theta}. \tag{WG6}
\]

此处 `𝒯` 已积原 `β|D(z)`，但未乘外 `2Λe^4` 或三腿两朝向。`j` 求和仍要求同一 `a,q,β,ν,D` 跨 `j`。所有 actual scales、softness、history、capture 与合法 far-clock 子集保持 R238 的范围；没有把 hard `z` 当作 posterior 变量，也没有变量尺度的核列归一。

## WG7. 全预算及准确余项

设 `H_D(z)=R_D(z)+log(1/δ_W(z))`，在 `x,y,v,u,j,M,t` 前冻结 `θ_z=1/(2H_D(z))`。WG6 指数因子至多 `e`，故恢复全部外因子后，

\[
 \boxed{P_{\rm far}(U)\le
 C_*\,\mathbb E\sum_V\int_V
 \delta_W(z)[R_D(z)+\log(1/\delta_W(z))]^3\nu_V(dz),
 \qquad C_*={21\over2}\Lambda e^5.} \tag{WG7}
\]

这对所有 `U≥0` 一致，`U=0` 只指该原 far 分支的全部有效 clock；不覆盖先前另分配的分支。`m_D(z)=0` 的原行先置零，`μ=0` 时 `δ_W=1`，无相应几何改善。没有新菜单外因子或额外 source count。

本定理确有输入可检验的衰减，而不是把 `O_R` 改名：`δ_W` 由原来源的显式截断积分及 WG4 的分式最优式给出。另一方面，WG7 的全部右侧尚未被原条件证明为一般根阶质量预算；其未付来源仍是高 `β(D(z))` 且这些接收几何证书不够强的原 `ν` 部分。

## WG8. 完整已付款的分支与充分几何范围

对任意 `A≥1`，定义预冻结原 hard 来源集合

\[
 E_A^W=\{z:\delta_W(z)R_D(z)^3\le A\}.
\]

用 `(u+v)^3≤4(u³+v³)` 和 `sup_(s≥0)e^−s s³=27/e³`，与 R238 相同，得到

\[
 \boxed{P_{\rm far}^{E_A^W}(U)\le
 C_*(4A+108/e^3)\,\mathbb E\sum_V\nu_V(E_A^W).} \tag{WG8.1}
\]

因此 `A=1` 是常数来源价，`A=sqrt n L_n`、`L_n≥1` 是明确的根阶 `O(sqrt n L_n)Wν` 支，无新增 `X` 费。

如果 `R_D³>A`，以下任一原来源证书足以进入此分支：

\[
 \Phi_z(A/R_D^3)\ge H, \tag{WG8.2}
\]

或存在 `σ_z≤μ`、`T_z≥(1+\eta)H` 满足

\[
 \frac1{T_z}\int\frac{\|y-z\|_1}{a}\sigma_z(dy)
 \le\frac{\eta A}{(1+\eta)R_D(z)^3}. \tag{WG8.3}
\]

如果 `R_D³≤A`，本就由 `δ_W≤1` 支付。WG8.2–3 允许多处或 diffuse 来源共同贡献，`μ=β` 可以来自 `β−ν`，不要求 `ν` 本身拥挤。所有证书都在原输入/残差上检验；没有据此宣称原 FULL 流程一定留下正比例满足证书的 hard 来源。

当 `β(D(z))` 很大但主要来自远于 hard 接收尺度的 soft 来源，这些源的 `c_z` 可能等于或接近一，不能在小 `r` 的 WG8.2 中贡献。该情况下 source-FIRST 的 `I0(y,z)` 距离权仍可能重要，而用整个 `m_D(z)` 的 Hölder 会丢掉它。本轮不把这个精确剩余问题伪装成已经付款，也不继续扩展新路线。

## WG9. 任意位置拥挤 cubes 的并集证书

这是独立的必要几何补充，不能把不同 cube 的体积相加。取任何预冻结的有限或可数 cube 族 `C_i=Q_{d_i}(c_i)`，`0<d_i≤a`，满足 `μ(C_i)>H`。对合法 `R`，定义

\[
 E_R=\bigcup_i Q_{R-d_i}(c_i).
\]

WG1 给 `Ω∩E_R=∅`。hard 来源 `z` **不需要属于任何 C_i**。令

\[
 \delta_{\rm cov}(z)=1-a^{-n}|Q_a(z)\cap E_a|.
\]

同一个映射 `x_R=z+(R/a)(x−z)` 把 `Q_a(z)∩Q_{a−d_i}(c_i)` 送入 `Q_R(z)∩Q_{R−d_i}(c_i)`：每坐标增加的位移至多 `(R−a)/2`。整个映射对并集是单射，故

\[
 O_R(z)\le\delta_{\rm cov}(z),\qquad
 \delta_{\rm base}(z)\le\delta_{\rm cov}(z). \tag{WG9}
\]

有限/可数并集可测；体积在同一 receiver 空间计算，无重复覆盖费。若 `δ_cov=0`，该 hard 来源的实际接收交通为零，在任何对数优化前先置零；若 `δ_cov>0`，可按 WG6–8 把它作为另一已证几何上界，或与 `δ_W` 取点态较小者。

一个明确的分散覆盖证书：若所有 `2^n` 个中心 `c_ε=z+hε`、`ε_i=±1` 的边长 `d` cubes 都有质量 `>H`，且 `d≤2h≤a−d`，则它们的最低尺度排除中心并集为 `Q_{a−d+2h}(z)`，包含 `Q_a(z)`，所以所有 `O_R(z)=0`。`h>d/2` 时 `z` 不在任何拥挤 cube 内。这是并集几何的确定性推论，不是一个已认证 FULL 输入构造；其陈述也不产生 `2^n` 的预算因子，因为没有逐 cube 相加来源费。

## WG10. 本机计算证据与范围

作者本机 Python/mpmath 70 位精度实际运行了 15 个真正有限 `L1` 来源的一维固定尺度工具检查。取 `a=b=1`、`z=0`、`H=1`、`μ=(T/L)1_[0,L]dy`，其中
`L∈{.05,.25,.75}`、`T∈{1.25,2,4,16,100}`。这里 `c_z(y)=y` 于来源支撑。

解析优化值在截一前为

\[
 r_*=\begin{cases}2LH/T,&H\le T/2,\\
 LT/[2(T-H)],&H>T/2,\end{cases}\qquad
 \delta_W=\min(1,r_*).
\]

程序用实际 quadrature 核验 `Φ(r_*)=H`（当 `r_*<1`）及截断证人分式等于 `r_*`。原固定尺度接收事件 `μ(Q_1(X))≤H`、`X` 均匀 `Q_1(0)` 的精确概率为 `LH/T`，全部满足 `O≤δ_W`。15 例均通过，报告的最大阈值残差为 `0.0`（70 位运算输出），最大精确占用/上界比为 `0.6`。

这些是原核的一维固定尺度工具模型，不满足原 remainder 的大维 FULL/history 资格，亦不拟合维数阶。它们同时展示 `δ_W` 一般严格大于真实最低尺度占用，避免把一阶最优与真实几何最优混同。本轮独立 numeric/audit 的更多运行以其责任文件为准。

本稿只写 `source_exclusion_geometry.md`，不改原来源/后验，不提交文件。R238 fractional 插值与全节点求和作为已证工具使用；新增的一阶优化、原测度资格与并集几何均在本文完整证明。
