# R239 bounded plan

Initial: exact common-receiver moments for the two true density6 slabs and their half mixture, plus exact Phi(r) at rational r. Stress: strict mass denominators, equality/empty/zero-cost atom branches and near-threshold H, preserving atom diagnostics as distinct from L1 receiver geometry. Expanded: rational homothety coordinate endpoints/corners through n16/128 and R/a=1,3/2,2. Atom fraction optimization uses a single frozen geometric cost and positive denominator; no witness changes the original traffic source/posterior. All computations are finite implementation evidence, not FULL history or a general root estimate.

## Actual computations and common-source covariance

All computations use Python Fraction exact arithmetic; no floating-point approximation or assumed independence enters the geometry. The executed true L1 models are eta1=6 indicator[-3/4,-1/4], eta2=6 indicator[1/4,3/4], and their half mixture. The receiver X is uniform[-1/2,1/2], a=1,z=0,H=1. On every exact receiver segment, source mass m(X) is affine, so its first/second moments and the sublevel length are independently integrated from endpoint values. Each source has mass3, mean3/2, secondmoment15/4 and variance3/2. Their common-X crossmoment is3/4, hence covariance-3/2, not0. The half mixture has mean3/2 and zero variance, and is identically3/2; its receiver{m<=1} has length0. A single slab's actual allowed length is5/12. The single firstmoment fraction bound is3/4 and Cantelli is6/7; for full f=eta1+eta2 the corresponding firstmoment bound is3/5, while the exact receiver remains empty. These are common-source calculations, not a product of independent receiver events.

Boundary pressure separately executes three further true receiver cases: single left slab atH=0 has allowed length1/4 (a zero-mass plateau); half mixture atH=3/2 has allowed length1 (equality everywhere); left slab atH=3 has allowed length1. The piecewise implementation distinguishes equality plateaus from equality endpoints.

Two L1 Phi models (left slab and half mixture) each evaluate five rational r values and four thresholds H=1,3/2,2,3. Phi(r)=integral(1-c/r)+mu is computed by exact tent trapezoids on all breakpoints; no sampled integral is used. Nonempty delta thresholds have80-step exact rational bisection brackets with Phi(lower)<H<=Phi(upper); empty thresholds record Phi(1)<H and delta1. Left and half mixture have the same cost distribution and Phi, although their receiver measures and variances differ. In both H=1 gives delta3/4 and H=3/2 gives delta1; H=2 and H=3 are empty. Thus covariance can improve a firstmoment-only certificate without silently changing its source.

## Fraction optimization and an atomic equality guard

Eight finite atomic configurations use geometric positions(0,0),(1/4,1/4),(1,0), whose exact costs are0,7/16,1. They test positive denominators T-H, H near mass thresholds, totalmass equality, empty measure, zero-cost mass aboveH, and zero-cost mass exactlyH. A cheap-first allocation minimizes cost at fixedT; on each allocation segment its ratio is fractional-linear, so an endpoint or the appropriate strict-boundary limit suffices. The stored finite candidates have T>H and exact Fraction costs/ratios. They are algebraic optimization diagnostics only, not L1 receiver instances.

The equality guard is essential: if an atom at c=0 has mass exactlyH, Phi(r)>=H can hold for every smallr, giving threshold delta0, even though the strict-T>H fractional infimum is positive (7/16 in the mixed example), or there is no feasibleT (the sole massH atom). The script explicitly stores threshold_delta and fraction_delta_cap1 separately, and marks this equality degeneracy instead of asserting false equivalence. Parent confirmed this lies outside the original theorem domain: for original mu absolutely continuous with respect to Lebesgue, mu{c=0}=mu{z}=0<H. If zero-cost atomic mass exceedsH, the ratio is correctly0 with a feasible T>H; that branch agrees. This endpoint stress does not refute the original L1 statement or motivate a new search.

## Expanded exact homothety menu

Twenty-four cases use n=1,2,16,128; R/a=1,3/2,2; X at center or alternating-sign corners of Q_a(z), with rational translated z coordinates(i mod3-1)/7. Each coordinate independently verifies both endpoint margins of Q_a(X) subset Q_R(z+(R/a)(X-z)). Boundary equality margins are retained, not perturbed. This verifies the exact implementation of the geometric coupling; no adaptive-R kernel normalization or full-source posterior replacement is inferred.

Three stages are therefore actual, separately counted: initial true L1 moments/Phi; strict/equality/empty and overlapping-witness pressure; enlarged-dimension rational homothety. No FULL history, rank assumptions, source independence, or general root budget is claimed.

## Reproduction

Actual runtime: bundled Python3.12.14, standard library only; no NumPy/mpmath dependency or installation is required for this all-rational script.

```sh
/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 \
/Users/zhengzhihao/Math-Research-centered-cube-work/centered-cube-upper-bound/rounds/239/work/numeric_checks.py \
--output /tmp/r239_numeric_replay.json \
--contract /Users/zhengzhihao/Math-Research-centered-cube-work/centered-cube-upper-bound/rounds/239/work/task_contract.md
```

Script and contract paths can be relocated together. JSON binds their content hashes, not paths, and excludes runtime fields.

## Frozen replay

Complete separate-output replay was byte-identical, 25802 JSON bytes; wall.03s,user.02s,system.00s. Actual counts:3 main trueL1 receivers,3 trueL1 boundary receiver cases,2 Phi models (five rationalr/fourH each),8 atomic diagnostics,24 rational homotheties. Source SHA256 `c22d51ed352069a1348ce69d70a0d620b7ef05b4dbbe0ab79e1996457e63b00d`; JSON `955168bad62c07aa56f27adb700a030d1dd06951a34a01cbd4a9912c90e568c1`; contract `8afc05d54bc947d904e1c289dd2cd8ca14ff04ffe1e8bc32ef7d44f4b62c3e85`.
