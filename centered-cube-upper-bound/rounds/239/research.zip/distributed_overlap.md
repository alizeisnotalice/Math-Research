# R239: same-center distributed mass and joint second moments

Only this file is owned by this task. The general arbitrary-input root
weak bound remains open. This note supplies an elementary, computable
occupation certificate for the R238 overlap/clock theorem; it does not
alter the original posterior, source measures or histories.

## DO1. Immediate scope correction: beta has the original hardband cap

On the original receiver domain Omega the all-R hardband is

    h_R*f(x)<=C0 q for every R in [a,b],  C0=16/3,
    0<a<=b<=2a.

Its original definition is [GENERAL_CURRENT_REDUCTION.md:7–13]
(/Users/zhengzhihao/Desktop/T/output/cube_general_20261003/GENERAL_CURRENT_REDUCTION.md:7):
G0=sup_{a<=R<=b} P_{0,R}*f, 2lambda<G0<=4lambda, and
q>=3lambda/4. Thus for **any** fixed witness measure eta<=f dx,

    eta(Q_R(x))<=H_R:=C0 q R^n,  x in Omega.             (DO1)

This applies to beta as well as nu. R238's crowded-nu wording was one
sufficient witness choice, not a restriction to nu. What cannot be
transferred from nu to beta is the inherited hard-tail rank. No claim
that beta lacks the original receiver-centered hardband cap is valid.
The distinction with an off-receiver source-centered mass cap remains:
DO1 only holds at x in the retained original Omega. See R222
`weight_contract.md:94` for the prohibition on enlarging x first and
then granting the original hardband to new points.

Witnesses below are finite Borel measures <=f dx. They may be beta,
nu, or other certified submeasures, and may depend measurably on the
frozen original hard anchor z, but not on the random receiver center.
They are geometric certificates, not replacements for beta or nu in
the original traffic. In particular no new witness normalizes Pi_t.

## DO2. Exact first and cross second moments at one radius

Fix R>0 and z. Let X be uniform with respect to genuine Lebesgue
measure on Q_R(z), and m_eta(X)=eta(Q_R(X)). Define

    T_R(z;y)=product_i (1-|y_i-z_i|/R)_+,
    U_R(z;y,y')=product_i
       [1-(max(z_i,y_i,y'_i)-min(z_i,y_i,y'_i))/R]_+.

For any two witnesses eta,sigma,

    mu_eta,R(z):=E m_eta(X)=integral T_R(z;y)eta(dy),
    Gamma_eta,sigma,R(z):=E[m_eta(X)m_sigma(X)]
       =integral integral U_R(z;y,y')eta(dy)sigma(dy'). (DO2)

Proof: in one coordinate, centers which cover y form the interval
[y_i-R/2,y_i+R/2]. Its intersection with the center interval around
z_i has length (R-|y_i-z_i|)_+. For two covered points the common
intersection of the three equal-length intervals has length R minus
the spread of their centers, clipped at zero. Coordinates multiply;
Tonelli gives both formulas. They use the **same center X**. There
is no independence assumption on two source labels or on the local
mass random variables. Finite witness masses imply finite second
moments. Define their exact covariance by

    Sigma_eta,sigma=Gamma_eta,sigma-mu_eta mu_sigma.     (DO3)

It is a positive semidefinite matrix for every finite witness list,
since a^T Sigma a=E[(sum a_l(m_l-mu_l))^2]>=0. Covariances can be
negative. Replacing Gamma by mu_eta mu_sigma would erase precisely
the useful same-receiver geometry.

## DO3. Sharp first-moment price and a second-moment improvement

At fixed R let O_R(z)=|Omega intersect Q_R(z)|/R^n. For a witness of
mass M>H_R, since 0<=m<=M and m<=H_R on Omega,

    O_R(z)<=min{1,(M-mu)/(M-H_R)}.                     (DO4)

Indeed E m<=H_R O_R+M(1-O_R). This is sharp among arbitrary bounded
random variables when only M and mu are supplied; no assertion of
attainability by every cube geometry is needed. One may restrict a
witness to Q_{2R}(z), since no other point contributes to m(X) except
null spatial boundaries. This is a useful finite local mass choice,
not a cap on that local mass.

If mu>H_R, let d=mu-H_R>0 and v=Var(m). Then

    O_R(z)<=v/(v+d^2).                                (DO5)

To prove it, put Y=m-mu and t>=0. On m<=H_R, (Y-t)^2>=(d+t)^2;
hence its probability is <=(v+t^2)/(d+t)^2. Set t=v/d. If v=0
the event is empty. If mu<=H_R this argument supplies only the bound
one. DO4 and DO5 may be minimized, and neither is uniformly better.

For two witnesses, write d_eta=mu_eta-H_R and d_sigma=mu_sigma-H_R.
For any alpha in [0,1] with d_alpha=alpha d_eta+(1-alpha)d_sigma>0,
the convex witness eta_alpha=alpha eta+(1-alpha)sigma is still <=f,
and its variance is

    v_alpha=alpha^2 Sigma_eta,eta+(1-alpha)^2 Sigma_sigma,sigma
                         +2alpha(1-alpha)Sigma_eta,sigma.

Therefore the stronger joint certificate is

    O_R(z)<=inf_{alpha in [0,1], d_alpha>0}
                    v_alpha/(v_alpha+d_alpha^2),       (DO6)

with value one when there is no such alpha. Original Omega satisfies
both hardband constraints simultaneously. This is why positive
combinations are allowed; arbitrary signed combinations would not
follow from the upper hardband constraints.

One may equivalently minimize a^T Sigma a subject to a>=0 and d^T a=1.
If Sigma is positive definite and Sigma^-1 d is nonnegative, this gives
the explicit value 1/(1+d^T Sigma^-1 d). Without that sign condition
one must keep the nonnegative minimization, rather than silently use
an unrestricted inverse. A nonnegative combination of zero variance
and positive deficit instead gives value zero.

## DO4. One base-radius joint law pays every legal hard scale

The preceding formulas can be made uniform in R without taking a
node-count fee or assuming an unproved supremum capacity. Let X_a be
uniform Q_a(z), and for R>=a set

    X_R=z+(R/a)(X_a-z).

Then X_R is uniform Q_R(z), and

    |X_R-X_a|_infty<=(R-a)/2,
    Q_a(X_a) subset Q_R(X_R).                         (DO7)

For any fixed finite witness list eta_l,z<=f, if X_R belongs to the
original Omega, DO1 and DO7 imply

    m_{eta_l,a}(X_a)<=m_{eta_l,R}(X_R)<=H_R<=H_b
       for every l,      H_b=C0 q b^n.

Thus the rigorous uniform occupation certificate is

    O_R(z)<=P{m_{eta_l,a}(X_a)<=H_b for every l},
                  simultaneously for all R in [a,b]. (DO8)

Compute DO2–DO6 only at radius a, with the common threshold H_b.
Any resulting bound delta(z) in [0,1] from the joint event, for example
the infimum of the two-witness Cantelli expressions and first-moment
expressions, therefore bounds **all** O_R(z). No scale supremum of a
new receiver set has been taken. The same source witnesses are used
throughout this coupling; they need not change with R.

For Borel witness kernels in z, the displayed moment integrals are
measurable. The infimum over alpha can be taken over rational alpha
in [0,1] with positive deficit; continuity on that open deficit domain
gives the same infimum, including zero limits. Hence delta is a legal
measurable original-anchor quantity chosen before x,y,v/u,j,M,t.
One may always include the bound one and avoid undefined 0/0 cases.

More generally, fix a finite or countable family of Borel witness
kernels eta_l,z<=f dx before receiver or node selection. Let mu_l(z)
and Sigma_lk(z) be DO2–DO3 at radius a. For finite-support simplex
weights alpha_l>=0, sum alpha_l=1, put

    g_alpha(z)=sum_l alpha_l mu_l(z)-H_b,
    V_alpha(z)=sum_l,k alpha_l alpha_k Sigma_lk(z),
    delta_2(z)=inf_{alpha: g_alpha(z)>0}
                         V_alpha(z)/(V_alpha(z)+g_alpha(z)^2), (DO8a)

with empty infimum assigned one. Then O_R(z)<=delta_2(z) for every
legal R. Every convex witness sum alpha_l eta_l is still <=f; sources
may overlap. The covariance, not the raw second-moment Gamma in DO2,
must appear in V_alpha. Nonnegative variance is guaranteed by DO3.

It suffices to take the infimum over rational finite-support simplex
weights. For a fixed finite support, mu and V are continuous in its
weights, and a strictly positive deficit stays positive under close
approximation. For a countable real simplex, every m_l(X) is bounded
by the common ||f||_1. Approximation of weights in l1 by normalized
rational finite-support weights gives uniform convergence of the local
mass random variables, hence convergence of their first and second
moments. Thus the same infimum covers countable real weights and is
measurable, as a countable infimum of measurable qualified expressions
(assign value one outside g_alpha>0). If V_alpha=0 and g_alpha>0, its
value is exactly zero. If zero is an unattained infimum, applying the
bound along an infimizing sequence still gives O_R=0. Traffic from
that anchor vanishes before logarithms or normalization are considered.

This uniform coupling was suggested by the parent and independently
checked here by its explicit cube inclusion; no new probabilistic
independence, randomized grid, heavy floor or historical receiver
qualification is needed.

## DO5. Exact interface with original sources and clocks

The audited R238 overlap interpolation uses the original actual soft
kernel I0(y,z)=integral_Omega h_R*(x-z)P_{s(x),L*}(x-y)dx and proves

    integral_{D_V(z)} I0(y,z)beta(dy)<=q O_R*(z).

Using the uniform delta of DO8, the full two original posteriors and
the common soft menu B=e ceil(pi sqrt n), its proved node bound is

    T_{jM,z}<=(u/4)(B rho_D(z))^{2theta}
       delta(z)^{1-2theta}c^{4theta n}exp(-2theta xi),
    rho_D(z)=beta(D_V(z))/(q a^n).

The original beta(D_V(z)), not the chosen geometric witness mass,
stays in rho_D. Both Pi_t are still defined from the complete original
nu. All original capture and history gates and real Lebesgue measure
remain as required by that theorem. Witnesses provide only an upper
bound for the receiver occupation already present in the same integral.

For positive delta and rho_D, set

    R_delta(z)=1+log_+rho_D(z)+log_+K+log B+log(1/delta(z)),
    theta_z=1/(2R_delta(z)).

R238's complete j/M sum gives the actual source budget

    P_far(U)<=(21e/2)Lambda e^4
          E sum_V integral delta(z) R_delta(z)^3 nu_V(dz), (DO9)

where Lambda=128/119. On delta=0 anchors all node receiver integrals
vanish; skip logarithms and assign zero cost. On rho_D=0 the original
soft source integral is zero. No zero row is normalized. This pays any
original source subset on which delta R_delta^3 has a proved root-order
bound, and charges its actual hard mass once. The remaining source
integral is explicit. The first/second moments do not prove such a
bound on every input, so DO9 is not a general root weak theorem.

One may use delta=min(delta_W,delta_cov,delta_2), provided each term is
an independently proved uniform occupation bound on this same original
Omega; delta_2 is DO8a. Taking the minimum does not change beta, nu or
Pi and does not treat different receiver events as disjoint. The final
source integration is against the unchanged original nu_V(dz), with
the same outer seed expectation and all its actual ledger factors.

## DO6. Distributed dense geometry: exact examples and limits

The joint improvement is not limited to a single small crowded cube.
Here are exact finite L1 geometric diagnostics, with no FULL claim.
Take a=1, z=0, threshold H_b=1 (choose q=1/(C0 b^n)), and two finite
slab witnesses of density c on

    A=[-3/4,-1/4] times [-2,2]^{n-1},
    B=[1/4,3/4] times [-2,2]^{n-1}.

They are both <=f=c(1_A+1_B), and convex combinations remain <=f.
For X uniform Q_1(0), each slab's local mass depends only on X_1.
On X_1 in [-1/2,-1/4] the left mass is c/2; on [-1/4,1/4] it is
c(1/4-X_1); on [1/4,1/2] it is zero. The right mass is its reflection.
Consequently

    mu_left=mu_right=c/4,
    Var(left)=Var(right)=c^2/24,
    Cov(left,right)=-c^2/24,
    (left+right)/2 == c/4 on the whole center cube.      (DO10)

For c>4 the mixed local mass is constant above H_b, so DO6 gives
delta=0, while either individual first-moment/Cantelli test can be
strictly positive. Means, variances, covariance and the zero joint
bound are the displayed dimension-independent values. Total witness
mass is not dimension-independent: after restriction to Q_2(0), each
slab has mass c*2^{n-2}, without changing its local mass on Q_1(0).
Consequently the first-moment baseline grows weaker with n. The table
below gives the exact n=1 first-moment prices (mass c/2); its mean,
variance, covariance and Cantelli columns remain valid in every n.
At c=6,n=1 even the full sum f=eta_left+eta_right is a legal witness:
its mass is 6, mean is 3, and the first bound is (6-3)/(6-1)=3/5.
Thus the zero variance/joint bound improves both the 3/4 single-witness
first price and this 3/5 full-source first price. For general n the
restricted full-source mass is c*2^{n-1}, while its mean remains c/2.
No sources are treated as independent.

The exclusion is stable on a positive set of anchors: for
z in [-1/4,1/4]^n, all center windows in coordinates 2..n stay inside
[-2,2], and the mixed first-coordinate local mass remains c/4 for
center coordinates in [-3/4,3/4]. Adding any finite small central
density to f and to beta allows a positive hard subsource there without
changing the witness proof. This demonstrates a geometrical payment,
not construction of the full historical process or a nonzero FULL
far traffic. It is a stress example for the general theorem, not a
special-family substitute for a universal budget.

Exact arithmetic was actually executed with Python's Fraction type:

| c | mean | variance | covariance | individual first bound | individual Cantelli | joint Cantelli |
|---:|---:|---:|---:|---:|---:|---:|
| 6 | 3/2 | 3/2 | -3/2 | 3/4 | 6/7 | 0 |
| 8 | 2 | 8/3 | -8/3 | 2/3 | 8/11 | 0 |
| 12 | 3 | 6 | -6 | 3/5 | 3/5 | 0 |

Reproducible embedded code, including the exact same-center product:

```python
from fractions import Fraction as F
cuts=list(map(F,['-1/2','-1/4','1/4','1/2']))
def overlap(x,l,u):return max(F(0),min(x+F(1,2),u)-max(x-F(1,2),l))
def moments(c):
    L=[c*overlap(x,F(-3,4),F(-1,4)) for x in cuts]
    R=[c*overlap(x,F(1,4),F(3,4)) for x in cuts]
    mean=lambda v:sum((b-a)*(u+v)/2 for a,b,u,v in zip(cuts,cuts[1:],v,v[1:]))
    prod=lambda u,v:sum((b-a)*(2*u0*v0+u0*v1+u1*v0+2*u1*v1)/6 for a,b,u0,u1,v0,v1 in zip(cuts,cuts[1:],u,u[1:],v,v[1:]))
    mu=mean(L);vr=prod(L,L)-mu**2;cv=prod(L,R)-mu**2
    assert mu==c/4 and vr==c*c/24 and cv==-vr
    assert (vr+vr+2*cv)/4==0 and mu>1
    M=c/2;first=(M-mu)/(M-1);cant=vr/(vr+(mu-1)**2)
    print('density',c,'mean',mu,'variance',vr,'covariance',cv,'first',first,'singleCantelli',cant,'pairCantelli',0)
for c in map(F,[6,8,12]):moments(c)
```

All three exact tests passed. The elementary probability bounds and
kernel formulas, not these finite tests, establish DO2–DO9. A separate
input/source budget is still needed where the certified delta is not
small; neither beta rank nor a free heavy floor is introduced.
