# R483：刷新原记录与来源后的质量共轭 Green 核

本稿以 R479–482 已证明的实际成功核及两端支配为输入。新增可用结论是：**每步刷新来源及原记录后，质量共轭核仍有无维数的真实行、列界和 Green 算子界**。这里没有保留固定来源秩，也没有让新父继承旧历史。最后恢复无权停止费用时仍出现一对不可省的质量权；本稿没有证明完整根阶预算。

## 1. 输入与合法刷新

固定原场 \(\mu=f\,dx\)、\(W=\mu(\mathbb R^n)\)、\(m_A=q_AR_A^n\)、\(q\le q_A\le\lambda\)、\(r=\lambda/q\)、\(a\le R_A\le b\le2a\)。原完整记录测度为 \(\Pi\)，父投影为
\[
\nu(dA)=t(A)\sigma(dA),\qquad \sigma=q_A\,dA,
\qquad 0\le t\le S,\quad R=\nu(E)\le SX.
\]
沿用原固定质量带划分；以下行列证明亦适用于使用整个质量区间作为单带的另一个核。主结论不通过改带改变首步成功流。给定当前父 \(A\)，独立抽原条件记录 \(\mathcal C_A=\Pi(\cdot\mid A)\)、来源 \(x\sim\pi_A\) 和 uniform 标记，再运行原 PPP 最大父及所指定的成功正限制。输出只保父 \(B\)；下一步重新抽上述三项。零 \(t\) 处条件记录任选。实际记录空间为标准 Borel 时这些条件核可测；也可直接采用原构造的条件核版本。

原成功输出父—来源—标记边缘受 \(t(B)\sigma(dB)\pi_B(dx)ds_B\) 支配，故得到父状态次 Markov 核 \(K\)，满足
\[
K1\le1,\qquad \nu K\le\nu. \tag{1}
\]
旧记录可以保留在联合空间，但新记录的来源、阶段和时钟来自 \(\mathcal C_B\)。刷新只保正质量，不保依赖旧来源的位移功等被积函数。标记也被刷新，所以只声称 \(m_B\le m_A\)，不声称跨步字典序严格下降。

设 \(I_{AB}=\mu(Q_A\cap Q_B)\)。最大点核的密度不超过 PPP 强度。先对原 \(x\sim\pi_A\) 积分，再放掉成功门，给真正的核支配
\[
\boxed{K(A,dB)\le
 \frac{t(B)I_{AB}}{T m_A m_B}\,
 1_{m_B\le m_A}\sigma(dB).} \tag{2}
\]
原质量原子由单步 uniform mark 处理；积分这些 marks 后使用闭质量门只是正放大。所有原门仍在左侧实际 \(K\) 内。

## 2. 闭质量尾的原子安全证明

固定任意来源位置 \(z\)，定义实际中心 CDF
\[
F_z(u)=\int c_A(z)1_{m_A\le u}\sigma(dA).
\]
捕获及匹配意味着这些中心处于边长 \((u/q)^{1/n}\) 的盒内，故
\[
F_z(u)\le ru. \tag{3}
\]
这是中心 Lebesgue 体积界，不是 \(f\) 的密度帽。对每个 \(m>0\)，Tonelli 给包含阈值原子的精确式
\[
\int_{[m,\infty)}u^{-2}\,dF_z(u)
=-\frac{F_z(m-)}{m^2}
 +2\int_m^\infty\frac{F_z(u)}{u^3}\,du
\le\frac{2r}{m}. \tag{4}
\]
写 \(F_z(m)\) 代替左极限会错误删除阈值原子。质量上界有限时亦可把尾积分写至该上界并保端点项；(4) 已自动保留它。

## 3. 真正的质量共轭收缩

定义正算子
\[
(\mathsf L g)(A)=m_A^{-1}K(mg)(A).
\]
由(2)，其核由 \(t(B)I_{AB}\sigma(dB)/(T m_A^2)\) 支配。行界为
\[
\mathsf L1(A)
\le \frac1{T m_A^2}\int_{Q_A}\mu(dz)
       \int_{m_B\le m_A}t(B)c_B(z)\sigma(dB)
\le\frac{rS}{T}. \tag{5}
\]
相对于同一 \(\nu=t\sigma\) 的列界，由(4)得
\[
\frac{d(\nu\mathsf L)}{d\nu}(B)
\le\frac1T\int_{m_A\ge m_B}
       \frac{t(A)I_{AB}}{m_A^2}\sigma(dA)
\le\frac1T\int_{Q_B}\mu(dz)\frac{2rS}{m_B}
=\frac{2rS}{T}. \tag{6}
\]
\(t(B)=0\) 不参与该 RN 密度。行 Cauchy–Schwarz 后对 \(\nu\) 积分，直接给
\[
\|\mathsf Lg\|_{L^2(\nu)}^2
\le\frac{rS}{T}\int\mathsf L(|g|^2)d\nu
\le\frac{2r^2S^2}{T^2}\|g\|_{L^2(\nu)}^2.
\]
因此，当 \(c_2=\sqrt2rS/T<1\) 时，
\[
\boxed{\left\|\sum_{j\ge0}\mathsf L^j\right\|_{2\to2}
\le(1-c_2)^{-1}.} \tag{7}
\]
这是实际刷新成功核的界，非抽象任意矩阵或原固定来源 Green 公式；质量等号原子不妨碍收缩。

## 4. 停止费用恢复：质量权不能删除

令 \(e=1-K1\)、\(\nu_j=\nu K^j\)。由(1)，\(\nu_j\le\nu\)，且
\[
R-|\nu_N|=\sum_{j<N}\int e\,d\nu_j. \tag{8}
\]
\(m_-=qa^n>0\)、\(m_+=\lambda b^n<\infty\)。式(5)使
\(K^j1\le(m/m_-)(rS/T)^j\)，故终端趋零。共轭关系与(7)于是给精确恢复及一个合法上界：
\[
\boxed{R=\left\langle m,(I-\mathsf L)^{-1}(e/m)\right\rangle_{\nu}
\le\frac{\|m\|_{2,\nu}\|e/m\|_{2,\nu}}{1-c_2}.} \tag{9}
\]
两个范数的真实来源表达分别为
\[
\|m\|_{2,\nu}^2
=\int\mu(dx)\int t(A)m_A c_A(x)\sigma(dA),
\quad
\|e/m\|_{2,\nu}^2
=\int\mu(dx)\int\frac{t(A)e(A)^2c_A(x)}{m_A^3}\sigma(dA).
\]
它们不是两份可独立支付的 \(W\) 费用。仅用质量端点及 \(e^2\le e\)，(9)只推出
\[
R\le\frac{(m_+/m_-)^2}{(1-c_2)^2}\int e\,d\nu,
\]
指数范围损失明显。不能把(7)中的测试函数换成 \(1\) 而省掉 \(m,e/m\)。尚缺的是对同一实际停止通量与该 Green 核的**联合加权配对**估计，而非核存在性或终端消失。

有一个更实用但仍仅线性维数的完整备用价。对 \(0<p\le1\)，(3) 的低端层积分给
\[
\int_{m_B\le M}t(B)m_B^{p-1}c_B(x)\sigma(dB)
\le(rS/p)M^p,
\quad Km^p\le\frac{rS}{pT}m^p. \tag{10}
\]
取 \(T\ge2rS\)、\(p=2rS/T\)，令
\[
D_m=\log(m_+/m_-),\qquad
J=\left\lceil\frac{pD_m+\log2}{\log2}\right\rceil.
\]
则 \(|\nu_J|\le R/2\)。完整单带成功账（包括高门失败、短边、中心外部及全 raw 无旧来源命中）为
\[
\int e\,d\nu\le E_T=\epsilon_T X+\kappa TW,
\quad\epsilon_T=\tau+\delta S+4rS^2/T+S^2b_n/T,
\quad\kappa=8\log(4/\delta),\quad b_n\le3^{-n},
\]
其中参数必须满足原成功证明要求，如 \(T\ge1024rS^2/(\tau\delta)\)。这是 R482 的 \(N=1\) 版本，不声称任意小 \(T\) 有同一成功价。由(8)，
\[
R\le2J E_T,
\qquad
2J\kappa TW\le
\kappa\left[\frac{4rS D_m}{\log2}+4T\right]W. \tag{11}
\]
当 \(T\asymp\sqrt n\) 时生存步数可为 \(O(\sqrt n)\)，但本证明的来源总价仍为 \(O(nW)\)，而 \(X\) 误差也必须乘 \(2J\)。选择 \(\tau,\delta\) 时须同步满足其与 \(T\) 的约束；不能只调小误差而保持旧成功核价格。式(11)是已得上界的强度，不是一般不可能性结论。

## 5. 未采用的局部来源分配及本轮范围

对低 Gram 保留族、最大父 \(B_*\)，有
\(\pi_{B_*}(\sum_{B\ne B_*}c_B)\le1/2\)。即使允许 fractional 保留，只要仍保最大父并要求某来源被至少 \(k_0>1\) 个父的总权捕获，其可用来源质量至多 \(1/[2(k_0-1)]\)。加原 slab 和成功门只会减少支持。因此局部重抽来源至少面临线性族大小的恢复费用；它不能代替上述全局刷新核。删除 raw 父还需另付实际配置法则改变，未在此宣布合法免费删除。

本轮保留的新工具为(4)—(7)：实际中心闭尾容量及质量共轭 Green 收缩。原输入正质量可以合法进入刷新过程，但(9)的停止权仍未付；不将辅助历史当原历史，不将新范数界称为完整根阶付款。

## 6. 实际本机核验

在指定本机 Python 实跑以下脚本，stdout 为：

```text
PASS 58 exact Fraction assertions: closed-CDF atoms, finite Schur, conjugate terminal identity; not native-history simulation.
```

第一阶段检查含阈值原子的闭尾积分；第二阶段检查行列 Schur 的有限有理形式；第三阶段检查带质量共轭的完整终端恢复。它们是代数及测度边界核验，不是原生全历史实例。此前局部分配探路曾实跑 93 断言，未用于(4)—(11)的证明，不再扩展或作为本稿必要附件。

```python
from fractions import Fraction as F
checks=0
for r in [F(1),F(3,2)]:
    atoms=[(F(1),r),(F(2),r),(F(4),2*r)]
    for a in [F(1,2),F(1),F(3,2),F(2),F(3),F(4),F(5)]:
        tail=sum(w/t**2 for t,w in atoms if t>=a)
        left=sum(w for t,w in atoms if t<a)
        knots=sorted(set([a]+[t for t,w in atoms if t>a]))
        integ=F(0)
        for j,l in enumerate(knots):
            right=knots[j+1] if j+1<len(knots) else None
            cum=sum(w for t,w in atoms if t<=l)
            integ+=cum*(1/l**2-(0 if right is None else 1/right**2))/2
        assert tail==-left/a**2+2*integ; checks+=1
        assert tail<=2*r/a; checks+=1
        assert sum(w for t,w in atoms if t<=a)<=r*a; checks+=1
for k in [F(0),F(1,8),F(1,4),F(1,3)]:
    m=[F(1),F(2),F(4)]
    K=[[F(0),F(0),F(0)],[k,F(0),F(0)],[k,k,F(0)]]
    L=[[K[i][j]*m[j]/m[i] for j in range(3)] for i in range(3)]
    row=max(map(sum,L))
    col=max(sum(L[i][j] for i in range(3)) for j in range(3))
    for v in [[F(1),F(1),F(1)],[F(-2),F(3),F(1,2)],
              [F(0),F(1),F(0)]]:
        lv=[sum(L[i][j]*v[j] for j in range(3)) for i in range(3)]
        assert sum(x*x for x in lv)<=row*col*sum(x*x for x in v)
        checks+=1
    e=[1-sum(z) for z in K]
    h=[e[i]/m[i] for i in range(3)]
    accum=h[:]
    for stage in range(2):
        h=[sum(L[i][j]*h[j] for j in range(3)) for i in range(3)]
        accum=[accum[i]+h[i] for i in range(3)]
    assert all(m[i]*accum[i]==1 for i in range(3)); checks+=1
print(f'PASS {checks} exact Fraction assertions: closed-CDF atoms, finite Schur, conjugate terminal identity; not native-history simulation.')
```
