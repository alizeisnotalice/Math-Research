# R483：刷新父核的质量共轭 Green 与真实停止费用

## 1. 本轮对象和可证结论

沿 R482，\(\mu=f\,dx\)、\(m_A=\mu(Q_A)=q_AR_A^n\)、\(q\le q_A\le\lambda\)、\(r=\lambda/q\)、\(a\le R_A\le b\le2a\)，\(\sigma=q_A\,dA\)。原完整记录的父边缘为
\[
\nu(dA)=t(A)\sigma(dA),\qquad 0\le t\le S,
\qquad R=\nu(E),\quad X=\sigma(E).
\]
所有原来源、时钟、阶段和成功门仍在原记录中。这里只研究以下合法刷新核 \(K\)：给定父 \(A\)，重新抽原条件记录、人工来源 \(x\sim\pi_A\) 和均匀质量 tie mark，运行原成功抽样，输出父 \(B\)；下一步仅以 \(B\) 为当前父，再作同样刷新。旧记录可以附存，但新记录不是其历史延续。原 \(\Omega_0\) 首步不变。

已证的目标边缘支配在投影后给 \(\nu K\le\nu\)，且 \(K1\le1\)、\(m_B\le m_A\)。每步刷新 mark 后不再声称字典序严格下降。本稿证明质量共轭 Green 有维数无关的算子界，并精确核算其回到原停止账的质量权。**这还没有支付 \(R\) 或 \(w_0\)。**

## 2. 真正的维数无关 Green 界

由实际最大父核的密度不超过 raw 强度，正删除成功门后，有
\[
 K(A,dB)\le {I_{AB}\over Tm_Am_B}
 1_{m_B\le m_A}\nu(dB),\qquad
 I_{AB}=\mu(Q_A\cap Q_B).
\tag{1}
\]
这里只作上界；(1) 右侧不是成功后归一化律。令
\[
 L=m^{-1}Km,\qquad a_0={rS\over T},\qquad
 \rho={\sqrt2rS\over T}.
\]
则 \(L(A,dB)\le I_{AB}1_{m_B\le m_A}\nu(dB)/(Tm_A^2)\)。固定真实来源 \(x\)，实际匹配给
\[
 |\{B:x\in Q_B,m_B\le u\}|\le u/q.
\tag{2}
\]
这是接收中心 Lebesgue 体积界，不是 \(f\) 的密度帽。交换来源与中心积分，得到
\[
 L1(A)\le {S\lambda\over Tm_A^2}
 \int_{Q_A}{m_A\over q}\,d\mu=a_0.
\tag{3}
\]
另一方面，含质量端点原子的 layer cake 给
\[
 \int_{m_A\ge m_B}c_A(x)m_A^{-2}\,dA
 \le 2\int_{m_B}^{\infty}{u/q\over u^3}\,du
 ={2\over qm_B}.
\]
因此相对同一 \(\nu\) 的列满足
\[
 L^*1(B)\le {S\lambda\over T}\int_{Q_B}{2\over qm_B}\,d\mu
 =2a_0.
\tag{4}
\]
Cauchy–Schwarz 后积分，或直接使用 (3)–(4)，给
\[
 \|L\|_{L^2(\nu)\to L^2(\nu)}\le\rho,\qquad
 G_L:=\sum_{j\ge0}L^j,\quad \|G_L\|_{2\to2}\le(1-\rho)^{-1}
\tag{5}
\]
（要求 \(\rho<1\)，原 \(T\) 满足）。这些常数不含质量带数或 \(A_n\)。

## 3. 回原停止账：终端完整，但质量配对未消

记 \(e=1-K1\)。由 (3)，\(Km\le a_0m\)，故
\[
 K^jm\le a_0^jm,\qquad
 \nu K^j1\le {a_0^j\over m_{\min}}\int m\,d\nu\longrightarrow0,
 \quad m_{\min}=qa^n>0.
\tag{6}
\]
于是所有停止原因合计恰为
\[
 R=\sum_{j\ge0}\nu K^je
   =\langle m,G_L(e/m)\rangle_\nu.
\tag{7}
\]
这也可由 \((I-L)(1/m)=e/m\) 直接核对。质量范围有限使所有相关向量属于 \(L^2(\nu)\)。特别地，(5) 合法给
\[
 R\le {1\over1-\rho}
 \left(\int m^2d\nu\int {e^2\over m^2}d\nu\right)^{1/2},
\tag{8}
\]
但两个质量矩未获根阶来源价；不能删除 \(m\) 或 \(m^{-1}\)。

尝试利用共同来源作局部 Cauchy 时，准确展开为
\[
 R=\iint \mathscr C(x,z)\,d\mu(x)d\mu(z),
\quad
 \mathscr C(x,z)=\int c_A(x)
   \left[G_L\left({c_\bullet(z)e(\bullet)\over m_\bullet^2}\right)\right](A)
   d\nu(A).
\tag{9}
\]
证明仅用 \(m_A=\int c_A(x)d\mu(x)\) 和非负 Tonelli。它保留实际 \(K\)，包括全部成功门。刷新后的不同跳可以使用不同来源；(9) 不是 \(x=z\) 的对角积分，也没有把第一来源保留到终端的合同。因此同源局部平方不能替代这个双来源交叉账。

另一个等价、对下一步更直接的记录是
\[
 R=\int {e(B)\over m_B}\,[G_L^*m](B)\,d\nu(B),\qquad
 {G_L^*m\over m}=\sum_{j\ge0}(K^*)^j1.
\tag{10}
\]
待支付的是这个**实际累计入量乘停止率**。维数无关的 \(G_L\) 范数没有给它相对 \(\nu\) 的维数无关帽。

原 raw 空点率的单步成本可以精确计算。沿原质量带，源秩的参考推前是 \(dv\)，故
\[
 \int e_{\emptyset}\,d\nu
 =T\int\sum_j(1-e^{-u_j(x)/T})\,d\mu(x)
 \le T\mathcal M.
\tag{11}
\]
空点只是总停止的一个正原因；其累计成本为
\(\int e_{\emptyset}(G_L^*m)/m\,d\nu\)，不是 (11)。即使另行采用全 octave 单带 \(N=1\)，并取 \(T\asymp\sqrt n\)，(11) 也只给单步 \(O(\sqrt nW)\)。其余低秩、记录、几何失败仍须分别保留；不可每轮重收一次后默认只有一轮。唯一缺桥是利用实际重叠和停止来源结构控制 (10) 的累计源列，或其 (9) 双来源形式，而不付全质量跨度。这里没有得到该控制，也不将 (7)–(10) 称作新的目标付款。

## 4. 前置 Poisson 删补筛查的范围

对抽样前固定的 \(A,x,z\)，共同、仅捕 \(x\)、仅捕 \(z\) 三个强度质量记 \(c,d_x,d_z\)。独立抽三个 PPP、共享共同部分，确给两个正确 raw 边缘；不变配置概率为 \(e^{-d_x-d_z}\)，强度差为 \(d_z-d_x\)。同单位 slab 只控制后者，不能控制前者。若新来源按旧保留族 \(F\) 的 \(h_F(z)\mu(dz)/M_F\) 选取，其中 \(h_F=\sum_Fc_B\)、\(M_F=\sum_Fm_B\)，低 Gram 给
\[
 \mathbb E[h_F(z)]={\int h_F^2d\mu\over M_F}\le3/2.
\]
补点后需重新筛最大父、Gram、旧来源及中心门；来源依旧配置选择时，输出还带该选择密度的条件期望，不能直接称 raw PPP。此筛查仅解释为何转向本稿的合法父刷新；未另收费用、未宣称不可能闭合。

## 5. 实际本机核验与边界

指定 Python `/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python` 实际运行下列自含代码，输出 **24 项 PASS**。三角矩阵仅核共轭、停止与来源展开的代数，不是原生 Lebesgue 接收场或历史实例；一般几何常数由 (2)–(4) 证明。

```python
import sympy as s
checks=0
for p,q,r in [(s.Rational(1,4),s.Rational(1,8),s.Rational(1,3)),
              (s.Rational(1,2),s.Rational(1,8),s.Rational(1,4)),
              (s.Rational(1,3),s.Rational(1,6),s.Rational(1,2))]:
 K=s.Matrix([[0,p,q],[0,0,r],[0,0,0]])
 m=s.Matrix([16,4,1]); D=s.diag(*m); one=s.ones(3,1)
 e=one-K*one; L=D.inv()*K*D; G=(s.eye(3)-L).inv()
 assert L==D.inv()*K*D;checks+=1
 assert (s.eye(3)-L)*D.inv()*one==D.inv()*e;checks+=1
 assert G*D.inv()*e==D.inv()*one;checks+=1
 assert (m.T*G*D.inv()*e)[0]==3;checks+=1
 assert sum((one.T*K**j*e)[0] for j in range(3))==3;checks+=1
 C=s.Matrix([[1]*16,[1]*4+[0]*12,[1]+[0]*15])
 assert C*s.ones(16,1)==m;checks+=1
 total=sum((C[:,x].T*G*D.inv()**2*s.diag(*e)*C[:,y])[0]
           for x in range(16) for y in range(16))
 assert total==3;checks+=1
U,T=s.symbols('U T',positive=True);v=s.symbols('v',nonnegative=True)
assert s.simplify(s.integrate(s.exp(-v/T),(v,0,U))-T*(1-s.exp(-U/T)))==0;checks+=1
c,dx,dz,a,b=s.symbols('c dx dz a b',nonnegative=True)
pgf=s.exp(c*(a*b-1)+dx*(a-1)+dz*(b-1))
assert s.simplify(pgf.subs(b,1)-s.exp((c+dx)*(a-1)))==0;checks+=1
assert s.simplify(pgf.subs(a,1)-s.exp((c+dz)*(b-1)))==0;checks+=1
print(f'PASS {checks} exact symbolic/rational interface assertions; no native receiver-field or history certificate.')
```

结论：本轮得到真实刷新核的质量加权 Green 收敛和完整终端账；一般 \(\epsilon X+O_\epsilon(\sqrt n\,\mathrm{polylog}\,n)W\) 的停止来源预算仍未证明。原 R482 已付费用保留，不由辅助刷新退还或重复收费。
