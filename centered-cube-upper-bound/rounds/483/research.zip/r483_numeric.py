from fractions import Fraction as F
from pathlib import Path
import sys,platform,json,time
import sympy as sp
from flint import arb,ctx
ROOT=Path(__file__).resolve().parent;ctx.prec=256
start=time.perf_counter();checks=0

def ck(v):
 global checks
 assert v
 checks+=1

def ar(v):
 v=F(v);return arb(v.numerator)/v.denominator

def matstr(A):return [[str(z) for z in row] for row in A]
def mult(A,B):return [[sum(A[i][k]*B[k][j] for k in range(len(B))) for j in range(len(B[0]))] for i in range(len(A))]
def transpose(A):return list(map(list,zip(*A)))
def inverse_exact(A):
 n=len(A);B=[A[i][:]+[F(int(i==j)) for j in range(n)] for i in range(n)]
 for j in range(n):
  ck(B[j][j]!=0);piv=B[j][j];B[j]=[z/piv for z in B[j]]
  for i in range(n):
   if i!=j:
    fac=B[i][j];B[i]=[B[i][k]-fac*B[j][k] for k in range(2*n)]
 return [row[n:] for row in B]
def zeros(n):return [[F(0)]*n for _ in range(n)]
def eye(n):return [[F(int(i==j)) for j in range(n)] for i in range(n)]
def ldl(A):
 n=len(A);L=eye(n);d=[]
 for j in range(n):
  dj=A[j][j]-sum(L[j][k]**2*d[k] for k in range(j));ck(dj>0);d.append(dj)
  for i in range(j+1,n):L[i][j]=(A[i][j]-sum(L[i][k]*L[j][k]*d[k] for k in range(j)))/dj
 diag=zeros(n)
 for i in range(n):diag[i][i]=d[i]
 ck(mult(mult(L,diag),transpose(L))==A)
 return d
# Integral of (A-B+c)_+ over a center rectangle, exact hinge primitive.
def hint(a0,a1,b0,b1,c):
 def f(x):return max(F(0),x)**3/6
 return f(a1-b0+c)-f(a0-b0+c)-f(a1-b1+c)+f(a0-b1+c)
def avgI(ca,la,ra,cb,lb,rb):
 a0,a1=ca-la/2,ca+la/2;b0,b1=cb-lb/2,cb+lb/2
 aa,bb=ra/2,rb/2
 return (hint(a0,a1,b0,b1,aa+bb)-hint(a0,a1,b0,b1,aa-bb)-hint(a0,a1,b0,b1,-aa+bb)+hint(a0,a1,b0,b1,-aa-bb))/(la*lb)
z=sp.symbols('z',positive=True)
ck(sp.diff(z**3/6,z,2)==z)
cent=list(map(F,[-1,F(-3,5),F(-1,5),F(1,5),F(3,5),1]));length=[F(1,5)]*6
side=[F(3,2),F(1)]*3;t=list(map(F,[1,F(1,2),F(3,4),1,F(1,4),F(3,4)]))
for i in range(6):
 ck(0<t[i]<=1);ck(cent[i]-length[i]/2-side[i]/2>=-4);ck(cent[i]+length[i]/2+side[i]/2<=4)
 for j in range(i):ck(abs(cent[i]-cent[j])>(length[i]+length[j])/2)
I=[[avgI(cent[i],length[i],side[i],cent[j],length[j],side[j]) for j in range(6)] for i in range(6)]
for i in range(6):
 ck(I[i][i]==side[i]-length[i]/3)
 for j in range(6):ck(I[i][j]==I[j][i]);ck(0<=I[i][j]<=min(side[i],side[j]))
rows=[]
for N in (2,4,6):
 nu=[t[i]*length[i] for i in range(N)];D=zeros(N)
 for i in range(N):D[i][i]=nu[i]
 for T in (F(4),F(16),F(64)):
  K=[[nu[j]*I[i][j]/(T*side[i]*side[j])*(1 if side[i]>side[j] else (F(1,2) if side[i]==side[j] else 0)) for j in range(N)] for i in range(N)]
  L=[[K[i][j]*side[j]/side[i] for j in range(N)] for i in range(N)]
  # Campbell raw-count marked domination kernel: independent uniform
  # marks give factor1/2 for mass ties; this is not a max-success law.
  for i in range(N):
   for j in range(N):ck(L[i][j]==nu[j]*I[i][j]/(T*side[i]**2)*(1 if side[i]>side[j] else (F(1,2) if side[i]==side[j] else 0)))
  row=[sum(L[i]) for i in range(N)]
  col=[sum(nu[i]*L[i][j] for i in range(N))/nu[j] for j in range(N)]
  for v in row:ck(v<=1/T)
  for v in col:ck(v<=2/T)
  gram=mult(mult(transpose(L),D),L)
  psd=[[2*D[i][j]/T**2-gram[i][j] for j in range(N)] for i in range(N)]
  pivots=ldl(psd)
  inv=[[F(int(i==j))-L[i][j] for j in range(N)] for i in range(N)]
  G=inverse_exact(inv)
  ck(mult(inv,G)==eye(N));ck(mult(G,inv)==eye(N))
  # Finite Neumann sum through4, exact resolvent remainder and rational tail.
  power=eye(N);partial=eye(N)
  for step in range(1,5):
   power=mult(power,L)
   partial=[[partial[i][j]+power[i][j] for j in range(N)] for i in range(N)]
  power5=mult(power,L);rem=[[G[i][j]-partial[i][j] for j in range(N)] for i in range(N)]
  ck(rem==mult(power5,G))
  rational_c=F(2)/T;tail=rational_c**5/(1-rational_c)
  rgram=mult(mult(transpose(rem),D),rem)
  tailPSD=[[tail**2*D[i][j]-rgram[i][j] for j in range(N)] for i in range(N)]
  tailpivots=ldl(tailPSD)
  hs2=sum(nu[i]*L[i][j]**2/nu[j] for i in range(N) for j in range(N))
  ck(hs2<2/T**2)
  schur=arb(2).sqrt()/ar(T);generic_green=1/(1-schur);rational_green=1/(1-ar(F(2)/T))
  ck(schur<1);ck(generic_green<rational_green)
  rows.append(dict(N=N,T=str(T),phase='initial' if N==2 else ('four_block_pressure' if N==4 else 'six_block_expanded'),nu=list(map(str,nu)),X_sigma=str(sum(length[:N])),nu_total=str(sum(nu)),block_average_I=matstr([r[:N] for r in I[:N]]),K=matstr(K),L=matstr(L),row_sums=list(map(str,row)),weighted_column_sums=list(map(str,col)),row_bound=str(1/T),column_bound=str(2/T),PSD_matrix_2D_over_T2_minus_LtDL=matstr(psd),exact_LDL_positive_pivots=list(map(str,pivots)),Hilbert_Schmidt_norm_squared=str(hs2),HS_norm_upper=str(ar(hs2).sqrt()),Schur_norm_bound=str(schur),generic_Green_norm_bound=str(generic_green),rational_Green_norm_bound=str(rational_green),Green_exact=matstr(G),Neumann_partial_through4=matstr(partial),Neumann_remainder_exact=matstr(rem),rational_tail_bound=str(tail),tail_PSD_positive_LDL_pivots=list(map(str,tailpivots)),scope='Independent-uniform-mark averaged raw Campbell domination kernel; Galerkin compression, not a max-success law or exact marked-chain lumpability'))
result=dict(scope='Nine exact continuous uniform L1 block-field compressions of the independent-mark averaged raw Campbell domination kernel. No max-success or history claim.',compute_index=dict(executable=sys.executable,python=platform.python_version(),sympy=sp.__version__,arb_precision_bits=ctx.prec,command='"'+sys.executable+'" r483_numeric.py',seconds=time.perf_counter()-start),checks=checks,geometry=dict(f='1_[-4,4]',W='8',q='1',r='1',S='1',centers=list(map(str,cent)),block_lengths=list(map(str,length)),selected_R_and_full_mass=list(map(str,side)),t=list(map(str,t)),capture_mass='exact full interval length R for every actual center',tie_rule='Strict lower mass factor1, equal mass independent uniform mark factor1/2, larger mass factor0'),formula=dict(Kbar='nuB*avgI_AB/(T*mA*mB)*orderfactor; orderfactor1 strict lower,1/2 ties,0 higher',Lbar='mA^-1*Kbar*mB=nuB*avgI_AB*orderfactor/(T*mA^2)',weight='nuA=tA*center_lengthA',PSD='2*diag(nu)/T^2-L^T*diag(nu)*L positive definite',Green='Exact rational inverse(I-L), with finite Neumann sum through4 and certified weighted residual'),cases=rows,exactness='Full interval intersections integrated over continuous center rectangles by positive-part cubic primitives. All matrices, weighted columns, LDL and Green certificates Fraction exact; 256-bit Arb norm displays. Not an arbitrary incidence matrix.')
(ROOT/'r483_numeric.json').write_text(json.dumps(result,indent=2)+'\n')
print('PASS',checks,'checks;2/4/6 actual continuous blocks x3 T values; marked raw-count compression p1, no max-success/history claim')
