# R483：实际连续父场的marked raw-count核、Schur与Green证书

最终交付版本只采用主代理指定的equal-mass独立uniform mark平均：strict lower质量系数1，equal质量系数1/2，higher质量系数0。它是raw Campbell计数支配核的有限压缩，不是“最大成功父”的精确转移核。

指定环境实际运行2/4/6块×T=4,16,64，共9配置、532项检查。前期strict-only nilpotent分支已被替换，不作为交付结果，也不把其两步终止当成本轮Green证据。这里只检静态连续几何实现、块平均矩阵和有限维证书；一般主Schur定理与原history另由作者证明。

## 1. 真实场和交集的连续积分

完整来源f=1_{[−4,4]}，W=8。父中心块长度均1/5，中心依次为−1,−3/5,−1/5,1/5,3/5,1，取前2、4、6块。块之间严格不交，选择边长依次3/2,1,3/2,1,3/2,1。所有实际cube均在来源支撑内，因此完整m_A=R_A、q=r=1，单octave成立。

静态接受边缘t依次为1,1/2,3/4,1,1/4,3/4，S=1；ν_i=t_i·length_i。没有声称这些t是原history构造。实际σ为中心Lebesgue测度，质量变化来自真实边长，不是任意指定源质量。

代码对连续中心矩形积分实际来源交集

I(A,B)=|Q_A∩Q_B|。

令a=R_A/2,b=R_B/2,d=A−B，则

I(d)=(d+a+b)_+−(d+a−b)_+−(d−a+b)_++(d−a−b)_+。

每个hinge的双中心积分用(z_+)³/6在矩形四角的差精确计算，再除以两块长度。SymPy核正半轴原函数的二阶导数，Fraction核对称、质量上界以及同块平均I=R−length/3。未用中心点交集代替整块。

最小2块的实际平均矩阵为

[[43/30,1631/1920],[1631/1920,14/15]]。

例如交叉均值1631/1920不等于中心点的17/20。

## 2. marked核及权

记orderfactor为上述1、1/2、0，ν_j=t_j length_j。独立原mark与raw mark都均匀，equal-mass关系下有s_B<s_A概率1/2。于是所算块平均为

Kbar_ij=ν_j avgI_ij·orderfactor/(T m_i m_j)，
Lbar_ij=m_i^{-1}Kbar_ij m_j=ν_j avgI_ij·orderfactor/(T m_i²)。

内积权D=diag(ν_i)，不把它换成无权Euclidean内积。逐行核Σ_j L_ij≤1/T，逐加权列核Σ_i ν_i L_ij/ν_j≤2/T；从而Schur界为√2/T。

注意：这是对实际连续marked raw-count核的Galerkin块平均。它不是对一般marked动力学的精确lumpability声明；复合块平均矩阵不等于先复合完整连续mark核再平均。主代理的一般定理可覆盖完整核，但不能凭这些有限矩阵建立一般定理。success最大父核只在有已证正支配时才可引用同一上界，本计算没有认证该成功律。

## 3. 有理PSD与非nilpotent Green

9配置均精确构造

B=2D/T²−L^T D L，

并以全有理LDL分解核所有pivot>0且重构矩阵等于B。JSON保存B和正pivot，提供独立于浮点谱的||L||≤√2/T证书。

含tie版本非nilpotent。脚本以有理Gauss-Jordan计算G=(I−L)^{-1}，核左右两个逆乘积都为I。另计算P4=I+L+L²+L³+L⁴，准确核

G−P4=L⁵G。

选保守有理收缩界c=2/T<1，尾范数界为c⁵/(1−c)。脚本进一步对该尾界核

[c⁵/(1−c)]²D−(G−P4)^T D(G−P4)

的有理LDL正定证书；JSON保存实际余项、tail界和positive pivots，所有量可自含重构。一般Neumann范数价格1/(1−√2/T)及更粗1/(1−2/T)以Arb展示，没有以有限相加冒充无限Green。

| T=4 | 最大row | 最大weighted column | 实际HS范数上界近似 |
|---|---|---|---:|
| 2块 | 487/19200 | 2639/86400 | .02383113 |
| 4块 | 2767/57600 | 17177/345600 | .04211534 |
| 6块 | 5881/115200 | 173/3456 | .04809665 |

此时统一Schur上界√2/4≈.353553，rational尾界为1/16。T16、64同样通过，完整表格在JSON。有限场的体积和接受密度都不大，界较松；不以此声称困难高门或高维实例已验证。

## 4. 复现与范围

命令：

`/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python r483_numeric.py`

实际Python3.12.14、SymPy1.14.0、Arb256-bit。几何、矩阵、weighted columns、LDL、逆和余项均为Fraction精确值；norm展示有严格Arb球。无求解器、浮点谱、Monte Carlo或中心网格近似。JSON compute_index记录环境和实际用时。532检查包含支持、矩阵与正性断言，不是532个独立模型。

本轮最终只核p=1；未扩测其它p。块平均原始核、完整连续核、成功最大父核和原history严格区分。归档仅r483_numeric.py、r483_numeric.json、r483_numeric.md。计算已停止。
