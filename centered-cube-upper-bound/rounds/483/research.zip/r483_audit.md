# R483 FINAL PASS（仅限加权收缩与停止结算）

独立预审先于作者稿，终审已核全部七项冻结输入。PASS 认证 parent-only 刷新核、真实质量CDF闭尾、质量共轭 L²/Green 收缩及完整停止恒等式；不认证原双来源配对的根阶付款，一般目标仍未闭合。

K 每步重抽原条件记录、人工来源及mark，νK≤ν；这可定义合法辅助链，但不保留上一跳的旧来源/history。其真实成功核仅由 raw-count 正支配。L=m⁻¹Km 的行≤rS/T，相对同一ν的列≤2rS/T；闭尾必须保 F(m−)，阈值质量原子没有遗漏。因此 ||L||₂≤√2rS/T<1，Green算子范数≤(1−√2rS/T)⁻¹。质量上下界有限使相似关系及终端消失合法。

停止账准确为 R=〈m,G_L(e/m)〉ν，且 G_L(e/m)=1/m；不能删质量权或将此恒等式当新W上界。主稿双来源展开(12)、geometry累计入量式(10)与互补稿0<p≤1及有限步备用价均合法，但没有消掉质量跨度或累计停止费。分带规则、原母账及其他未付项保留，单带只是明确另核的备用方案。

实际隔离复现：指定 Python、新临时目录，运行两正文内嵌脚本及 numeric.py，24、58、532 项全部通过，三段stdout与replay逐字一致。numeric JSON仅剔除 compute_index.seconds 后全字段一致，canonical SHA256为 b08d53e53482f6e9440f1a5e31082a12d279366c7eac31113be8741af3a7dfb0。连续中心交集采用精确矩形积分；数值矩阵是独立uniform tie-mark平均 raw-count 核的Galerkin压缩，未被误作成功最大父律、精确集总或完整原history认证。未编译PDF。

冻结输入 SHA256：

- `r483_main.md`: `0529883483a3d95f032dcfd346b3d87bb051bc7bf7608ebc256b43934a2080e9`
- `r483_geometry.md`: `70d14f20201bff0f9bebffaecad31d1b7c90a4af90b02142feeac6ad25d62dfe`
- `r483_complement.md`: `184304caf1f058f836776e50b68687eabb28b7e294dc72301bfd2cd99322285d`
- `r483_numeric.md`: `fc4de1b4125a1e0a995bdcf419c003351a5b1df0398bb99c5a5e217905e4c159`
- `r483_numeric.py`: `b3d5b54b18cd0db45aa290531808748d4b1f901cb99dafd9ac70d0148858f20d`
- `r483_numeric.json`: `11523e4e45daba9e06cccd686890f0a3751d19c6dd7233e1a4269fc263687c74`
- `r483_replay.json`: `1bd307c31a405139c16dd9546b37a549f680a1a6f0d034d3a27fd48721e59434`
