# R177：continuum FIRST 的正增长预算与原 companion 的精确桥

本稿先证明一个实际原正交通付款：由原单侧 continuum FIRST 选定外来源越出当前硬立方体的坐标上尾，完整 beta 的该分支以 epsilon E∫q dx 支付，无新增 n、j 或 soft-selector 费用。其低越界补集仍未闭合。另证明原选择的正增长预算，并用正 Duhamel 分解把 companion 的一份 p_y 转入同一增长测度；这条桥的剩余三点乘子尚未支付。一般根阶结论保持未证。

## 0. 直接支付原 raw 的外来源越界上尾

本节仅使用原 current s(x),L(x)、共同 q，以及全部 u≥s 的合法 same-L future；不使用替代 global-soft selector。对任意 epsilon>0，置

\[
\delta=\min\{1/2,\,3\epsilon/(32\Lambda n\log2)\},\qquad
k_\delta(n,s)=\min\{k\in\{0,\ldots,n+1\}:
\inf_{\theta\ge0}e^{-\theta k}(1-s+se^\theta)^n\le\delta\}.
\tag{OT1}
\]

k=n+1 总可行且对应空来源支；s=1 时恰取 n+1。阈值是明确的有限整数选择，可用可数稠密 theta 取下确界，故可测。令

\[
m_x(y)=\#\{i:|x_i-y_i|>L(x)/2\},\qquad
E_{tail}=\{m_x(y)\ge k_\delta(n,s(x))\}.
\]

**原交通付款定理。** 在原 R_eta、low-capture 及所有原门内，只切外 y 的上述事件，则

\[
\boxed{\operatorname{Raw}^{J,+}_{low\cap E_{tail}}
\le\epsilon\,\mathbb E\int q(x)dx.}
\tag{OT2}
\]

证明保留同一 f。把物理 current kernel 展开成 hard/soft 子集 E，令其联合来源质量为

\[
{f(y)\over q}L^{-n}s^{|E|}(1-s)^{n-|E|}
\prod_{i\in E}\phi((x_i-y_i)/L)
\prod_{i\notin E}h((x_i-y_i)/L)\,dy.
\]

对 E,y 总和积分为一，只是在证明中归一 current-f 质量，不更换原 nu、beta 或 Pi。令 K=|E|。对 0<s<1、theta≥0，取 u=se^theta/(1−s+se^theta)≥s。原 FIRST 精确给

\[
\mathbb E_{current\ f}e^{\theta K}
=(1-s+se^\theta)^n{P_{u,L}f(x)\over q(x)}
\le(1-s+se^\theta)^n.
\tag{OT3}
\]

联合密度非零时 m_x(y)≤K，因为硬坐标不能承载当前硬立方体外的来源。故 Markov 与 OT1 给

\[
\int_{E_{tail}}p_y f(y)dy\le\delta q(x).
\tag{OT4}
\]

下确界不必达到：先对每个有限 theta 应用，再取下确界。s=0 的 m≥1 源质量为零；s=1 尾支为空，均可直接处理。

原 J 槽 A_v=1_good rho_v J_v/(3Q_v) 满足 0≤A_v≤1，原 score 正差≤n，两份原 Pi 各为概率，原实际时间长≤log2。先保留唯一 j 指示，待这些上界全部与 j 无关后求和，得到

\[
\begin{aligned}
\operatorname{Raw}^{J,+}_{low\cap E_{tail}}
&\le {32\Lambda\over3}n\log2\,
\mathbb E\int dx\sum_V\int_{E_{tail}}p_y\beta_V(dy)\\
&\le {32\Lambda\over3}n\log2\,\delta\,
\mathbb E\int q(x)dx\le\epsilon\mathbb E\int q(x)dx.
\end{aligned}
\tag{OT5}
\]

第一行只用原 hard16/3、outer2Lambda 各一次，原 hard/source/history/pair/low-capture 门作正上界丢弃；第二行在共同 p,s,L 和同一原 seed 下先用 sum_V beta_V≤f。没有逐 V 领取 q，没有新增 n+2 的 j 费，也没有 soft 网格。beta=nu+zeta 两部分同时覆盖。可以只对原有限合法正截断证明，再按非负性取极限；不借任何负信用。

此原正切分应在 R175 已付分支的补集上作，故不重复计价。剩余为 m_x(y)<k_delta 的同一原 low-capture 交通；一般 s 接近一时阈值可等于 n+1，定理不声称这时补集低维。K 只是 current 核的 latent soft-mask 数，绝不等于原 y−v 分离决定的 k_t。

可量化的小均值范围也只作准确范围说明：若原 ns≤c，OT3≤exp(c(e^theta−1))。令 ell_delta=log(1/delta)≥e²c，则取 k=min{n+1,ceil(2ell_delta/log(ell_delta/c))} 已足以使上尾≤delta。证明设 v=log(ell_delta/c)≥2，实数 k0=2ell_delta/v 满足 log(k0/(ec))≥v/2，因为 v/2−log v+log2−1≥0；于是 k0 log(k0/(ec))≥ell_delta，Poisson Chernoff 给结论，向上取整只改强。故在这个有明确小均值的原范围，delta≈epsilon/n 给解析 log n/loglog n 级外越界阈值。不能把此范围免费扩成全部原输入，也不借新 selector 的下端性质替换旧合同。

## 1. 原范围与正增长核

使用 R177 task_contract、冻结 R176 scale_face_geometry.md SF4/SF10/SF11 和 R175 CJ1–11。原当前选择满足 p_y=P_(s(x),L(x))(x−y)、P_(s,L)f(x)=q(x)，且所有合法 H∈[a,b] 有 P_(s,H)f(x)≤q(x)。不更换原 s,L、来源、history、same-alpha、j 或 Pi。新 joint-global selector 的性质不作为旧 CJ 合同。

记 b_s(r)=(1−s)h(r)+s phi(r)。phi 偶且随 |r| 下降：phi'(r)=w(r+1/2)−w(r−1/2)，r>0 时不正。定义非负连续增长核

\[
\mathcal R_{s,H}(z)=H^{-n}\sum_i
[-(z_i/H)s\phi'(z_i/H)]\prod_{k\ne i}b_s(z_k/H)\ge0.
\tag{EF1}
\]

采用乘积写法避免零密度除法。令 Fbar 为 SF4 的平均面概率测度，定义正测度

\[
\mathcal G_{s,H}
=\mathcal R_{s,H}dz+n(1-s)\overline{\mathsf F}_{s,H}.
\]

由原尺度恒等式，准确地有

\[
\partial_{\log H}(P_{s,H}dz)=-nP_{s,H}dz+\mathcal G_{s,H},
\qquad\|\mathcal G_{s,H}\|=n.
\tag{EF2}
\]

其连续增长质量 ns、面增长质量 n(1−s)。这不同于 SF4 中中心化的 signed bulk；这里全部非负，后续没有删掉某个未计费的负项。

对一般正 L1 的合法性沿 SF13 公共代表元：有限 hard/soft 子集展开只用于取得同一个 receiver 满测集，在其上所有 s 与 H 路径身份同时成立。每个固定子集的尺度导数是有限测度、路径 TV 可积，卷积后 Tonelli 给 AC 路径；物理端点由 L1 输入及核连续性一致延拓。因而可代入原 measurable s(x)、L(x)、H(x)，无需在选定极值尺度处求导，也无需使用逐固定 s 的 L1 范数去控制任意 s(x)。本稿只积分路径上的面卷积，不给可能无定义的某个选定单尺度 face trace 赋值。

## 2. 原极值的向上正通量：实际 receiver 价

任取原 measurable H_+(x)∈[L(x),b]。由 EF2 的路径恒等式与 continuum FIRST，

\[
\begin{aligned}
\int_L^{H_+}(f*\mathcal G_{s,H})(x){dH\over H}
&=P_{s,H_+}f(x)-q(x)
  +n\int_L^{H_+}P_{s,H}f(x){dH\over H}\\
&\le n\log(H_+/L)q(x).
\end{aligned}
\tag{EF3}
\]

因此若 log(H_+/L)≤epsilon/n，完整正增长以及其中正 hard-face 通量都满足真实预算

\[
\int dx\int_L^{H_+}(f*\mathcal G_{s,H})(x){dH\over H}
\le\epsilon\int q(x)dx.
\tag{EF4}
\]

可对任意 receiver 子集积分，右端相应限制；可能无穷时先作原有限正截断。所有对同一增长积分取值在 [0,1] 的原门只减小左端。若共同路径内的来源为 sum_V nu_V 或 sum_V beta_V，可先用其≤f，再用 EF3，不能逐 V 分别领取 q。原唯一 j 若仅选择一个 H_+(x)，直接合成该选择，EF3 不增 j 费用；对各 j 独立积分则不适用这个免求和结论。

这是原 extremal receiver 的通量预算，不是声称低 capture companion 本身已落入这条薄尺度路径。

## 3. 向下尺度的衰减正分解：保留原储备

设 H_0(x)≤L(x) 为共同合法尺度，ell=log(L/H0)，c0=exp(−n ell)。将 EF2 乘积分因子得到正测度等式

\[
P_{s,L}dz=c_0P_{s,H_0}dz+
\int_{H_0}^{L}(H/L)^n\mathcal G_{s,H}{dH\over H}.
\tag{EF5}
\]

记第二项为正增长测度 T_(s,H0,L)。卷积原共同 f，准确得

\[
\begin{aligned}
f*T(x)&=q-c_0P_{s,H_0}f(x)\\
&=(1-c_0)q+c_0\{q-P_{s,H_0}f(x)\}\le q.
\end{aligned}
\tag{EF6}
\]

因此全尺度窗的**衰减**增长保持 actual dx 时只收 ∫q，不收 n log(b/a)∫q。不能删掉 (H/L)^n 后仍声称此价。若 ell≤epsilon/n，进一步有

\[
f*T(x)\le\epsilon q(x)+\{q-P_{s,H_0}f(x)\}.
\tag{EF7}
\]

取 H0=Hhat_j≤L，则 P_(s,H0)=K0_j。令原 G0,V=q−K0_j nu_V，因 nu_V≤f，EF7 的后一项≤G0,V。原 same-alpha 有 gamma_y≥G0,V，此处仅记录相同储备的出现，不第二次扣取它、不推断其已经吸收。

sum_V beta_V 的正增长总量可先被 f*T 支配；同理适用于 sum_V zeta_V 和 sum_V nu_V。逐 V 上界 G0,V 不能免费相加。固定 j 的原 K0 可以共同，sum_j 仍保持原唯一指示；有不同归一密度的 j 项不能据 EF6 另行免价。Hhat>L 的实际行不属于 EF5 这一向下桥，保留为未处理部分，不能裁掉。

## 4. 一份 current 核进入原 companion：等式及剩余系数

对 Hhat≤L 的实际行，令 T_j(x−y) 表示 EF5 正增长的密度（作为正测度等式也可用）。原 beta≤f dx 允许与它积分。逐原 y 有

\[
p_y=c_0K0_y+T_j(x-y).
\tag{EF8}
\]

取原 CJ1 的完整正 mask M，保持 R_eta、original bad、严格低 score、high/good/rho、唯一 j、history 与 Z_t；M 不含 rho 或 J/(3Q)。完整原被积式是

\[
M\,{p_y^2\rho_v^2J_v\over9Q_v^2}
{w_t(y,v)w_t(y,u)\over e_t(y)^2}
\,dx\,\beta_V(dy)\nu_V(dv)\nu_V(du){dt\over t}.
\tag{EF9}
\]

把一份 p_y 代 EF8，是一个全正、同输入的精确分拆，不重选 alpha、e 或 Pi：baseline 部分带 c0K0_y，growth 部分带 T_j(x−y)，两部分共有剩余乘子

\[
\boxed{\mathcal M_{x,y,t,v,u}
=M\,{p_y\rho_v^2J_v\over9Q_v^2}
{w_t(y,v)w_t(y,u)\over e_t(y)^2}.}
\tag{EF10}
\]

于是 growth 部分仍必须对 beta(dy)nu(dv)nu(du)dt/t 积分 T_j(x−y)Mcal。EF6 只支付不带这个乘子的 beta 增长质量。原 good 给出的最直接上界仅为

\[
\mathcal M\le
M\,{K\rho_v^2J_v\over9Q_v w_g(y,v)}
{w_t(y,v)w_t(y,u)\over e_t(y)^2}.
\tag{EF11}
\]

它不是 [0,1] 门；还含实际 w_t/w_g、target 核比、e_t 的归一及两份来源。保留 bad 内槽积分可写成 w_t(y,v)b_bad,t(v)/e_t(y)，但尚无从 FIRST 推出该加权量对 EF6 增长测度的有界或根阶积分控制。same-alpha cubic/quartic 与 R176 JR5–7 可继续保留，却没有把 EF10 自动变成有界乘子。

特别不能先将 actual tau、mu 各替为独立质量一，再用 EF6；也不能用联合质量≤1/4 直接宣称 growth 的 q 价可吸收。那需要 EF10 与原同一待付量之间的可迭代支配，而本稿没有此式。baseline 部分及 nu 外槽同样没有被 EF8 自动支付，完整 beta=nu+zeta 两部分均保持。

## 5. 硬面路径的支持说明与非 face 部分

若只使用 EF3 中的 hard-face 通量，则对 z=x−v，其路径积分具有显式非负密度

\[
\mathcal A_{s,L,H_+}(z)
=(1-s)\sum_i1_{\{L<r_i\le H_+\}}
r_i^{-n}\prod_{k\ne i}b_s(z_k/r_i),
\qquad r_i=2|z_i|.
\tag{EF12}
\]

证明：每面系数 (1−s)/2；积分 delta(z_i∓H/2)dH/H 给 2/r_i，与 1/2 抵消，其余 n−1 坐标给 r_i^(−n+1)。端点面改变在 L1 来源下不改变预算。其支持要求某坐标穿过实际尺度层。原低 capture companion 的 target v、bad u 或 outer y 尚没有相应支持包含定理；不能把非 face 部分漏掉，再称 EF4 已支付整体。

新 latent soft-subset 极值定理若适用，可控制 current P_(s,L)f 加权来源越出当前硬立方体的坐标数。但它不是以 y−v 为中心的原 k_t，也不直接控制 EF10 的 J_v/Q_v、rho、w_t/w_g。即使 outer y 在 current hard core，target v 仍可与它在许多坐标分离；target 使用的 Jnu 容量也不同于 current pnu。对替代 global-soft selector，还需先迁移旧来源/history 合同。因此本稿不把 latent K 的界当作原非 face 项的已证预算。

## 6. 完整费用与最早未证环节

已证明的原 raw 结论是 OT2–5，支付完整 beta 的明确外来源上尾；其低越界补集仍保留。另已证明的真实 receiver 中间结论是 EF3–7：自适应原 s(x) 不增离散菜单费；正薄窗增长有 epsilon∫q 价；全向下窗保留衰减后的增长有 ∫q 价及明确储备缺口。它们没有求导选定最大点，也没有假设任意 L1 的 face trace 或 source 坐标独立。

从这些结论到原目标的最早未证环节明确是 EF10：必须控制它与实际正增长测度的联合积分，且同时付 baseline、Hhat>L、nu 与 zeta 外槽和非 face 部分。EF11 尚不足；未证的不是新的抽象矩，而是一次明确正 Duhamel 拆分之后仍在的物理乘子。若仅把该乘子删除，则变成另一个泛函，EF6 的 q 预算不能转给原 CJ1。

原 raw 的外因子仍为 hard16/3 和 outer2Lambda 各一次。若未来真的得到 C_low≤C_n W_beta，则原 EJ 给 (32Lambda/3)sqrt(n C_n/(2K))W_beta；本稿没有该 companion 结论，因此不领取这一 source 价。实际已付的 epsilon raw 吸收仅为 OT2 的外来源上尾，不能扩到全部剩余；所有原负信用保持。完成本次有限桥接尝试后停止，不追加反例搜索或换目标。
