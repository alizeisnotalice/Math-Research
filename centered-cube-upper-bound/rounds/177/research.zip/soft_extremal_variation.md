# R177：极值软度的联合 Euler 身份、真实来源矩与尾质量费用

本稿只写本责任文件。依据 R177 合同及冻结 R176 `scale_face_geometry.md`（SF1–14），使用真实正输入 f∈L1、真实 receiver dx 和原 mixed 核。以下有限混合、微分和尾界均直接证明；不将来源后验坐标假设为独立，不调用有限原子强对偶。新的全局软度选择与旧 CJ/history/source 构造的兼容性尚未证明，本稿不将新选择免费替换进旧账。

## SE1. 核、当前极值及原选择的单边性

记 h=1[-1/2,1/2]，φ=h*w，w(r)=∫₀¹ exp(−|r|/a)da；此积分 a 仅是 dummy。令 b_s=(1−s)h+sφ，P_{s,H}(z)=H^(−n)∏ᵢb_s(zᵢ/H)，F(s,H,x)=(P_{s,H}*f)(x)，物理窗口为 0<a≤H≤b。各核质量为1。

固定 receiver x。原 continuum FIRST 为 q=F(s,L,x)，以及 F(u,H,x)≤q 对所有 u∈[s,1]、H∈[a,b]。当 0<s<1 时，有限多项式性给当前点的右软度导数 F_s(s,L,x)≤0。即使 s 是 (0,1) 内点，也不能据此断言 F_s=0，因为原合法软度域从当前 s 开始。s=1 时没有这条右导数测试。

φ、φ′ 有界，且 φ+rφ′ 有界并衰减；紧 H 窗口内的物理卷积及其软度导数对 (s,H) 连续。对 L1 f 的硬面例外，固定 H 的有限源超平面对 f dz 零测，支配收敛成立。尺度点导数则不因此处处存在：选中 L 可以是硬面累积造成的不可微点。后文对一般 L1 使用 R176 的公共 AC 路径代表元和有限差分，不假设该点可微。

## SE2. 软核连续尺度项与真实软度导数的准确分解

置 ζφ(r)=−1−rφ′(r)/φ(r)，并定义质量零的 soft-only dilation 核

\[
\mathcal L_{s,H}(z)=\sum_{i=1}^n sH^{-1}\zeta_\phi(z_i/H)\phi(z_i/H)
 \prod_{j\ne i}H^{-1}b_s(z_j/H).
\tag{SE2}
\]

这里 ζφφ=−φ−rφ′，故不需除以零的约定。R176 的中心化连续尺度核为 B_{s,H}=P_{s,H}∑ᵢψ_s(zᵢ/H)。逐坐标准确恒等式

\[
\psi_sb_s=s\zeta_\phi\phi+s(1-s)(\phi-h)
\]

给出

\[
\boxed{\mathcal B_{s,H}=\mathcal L_{s,H}+s(1-s)\partial_sP_{s,H}.}
\tag{SE3}
\]

∫ζφφ=0。令 Iφ=∫ζφ²φ<9/4（R176 SF5–7 已完整证明），在 b_s 的物理张量下，单坐标 ℓ_s=sζφφ/b_s 均值0，且 ∫ℓ_s²b_s≤sIφ，因为 b_s≥sφ。交叉积分为0，因此

\[
\|\mathcal L_{s,H}\|_1\le\sqrt{nsI_\phi}\le\tfrac32\sqrt{ns},\qquad
\int_a^b\|f*\mathcal L_{s,H}\|_1\frac{dH}{H}
\le\tfrac32\sqrt{ns}\log(b/a)\|f\|_1.
\tag{SE4}
\]

s>0 时上述最后一个核范数界可取严格小于；s=0 时核为0。此费用仍要求同一个全空间固定 s；对 s=s(x) 不能在 dx 内免费取上确界。它也不是选择 H(x) 后的瞬时核范数。SE3 是实际软度和尺度的耦合，SE4 本身未解决原自适应软度预算。

## SE3. 新全局选择的真正 O(q) 软度费用

固定 c>log2，s₀=1−exp(−c/n)。考虑

\[
q_*(x)=\max_{s_0\le u\le1,\ a\le H\le b}F(u,H,x),
\quad F(s_*,L_*,x)=q_*(x).
\tag{SE5}
\]

f=0 时所有预算均为0，下文只处理非零正 f，此时 s₀>0 保证 q_*>0。紧参数域的连续性给最大值。可测选择和 hard-window supremum≤e^c q_* 的完整 elementary 构造由父稿 `measurable_extremal_reduction.md` 处理；本稿条件于其同一个选择，不另换来源。点态支配也直接来自 P_{s₀,H}≥(1−s₀)^n h_H^⊗n=e^(−c)h_H^⊗n。

定义仅在选中点的软下降费用

\[
D_*(x)=-s_*(1-s_*)F_s(s_*,L_*,x).
\tag{SE6}
\]

若 s₀<s_*<1，则两边可行的一阶极值条件给 F_s=0。若 s_*=s₀，则右导数≤0；有限非负混合（SE10–11）给 D_*≤ns₀q_*。若 s_*=1，则前因子为0，直接 D_*=0，不从不存在的右方向取信息。因此

\[
\boxed{0\le D_*\le ns_0q_*\le cq_*;\qquad
\int_XD_*dx\le c\int_Xq_*dx.}
\tag{SE7}
\]

X 为任意真实 measurable receiver 子集，积分可为扩展非负积分；需要实际有限预算时保留右端。c>log2 是固定正常数，此费用不是可任意缩小的 ε∫q_*。同一 receiver 只收一次，不对每个 V 各收 cq_* 后再忘记求和。

## SE4. 精确联合 Euler 和尺度端点、尖点费用

令面平均测度 Fbar_{s,H} 与 R176 SF3–4 相同，记 M(H)=(Fbar_{s,H}*f)(x)，l(H)=(L_{s,H}*f)(x)。在本节固定选中 x,s=s_*,L=L_*，但 H 为路径变量。置

\[
D(H)=-s(1-s)F_s(s,H,x).
\]

SE3 与原含硬面的尺度 BV 恒等式给路径上准确身份

\[
\partial_{\log H}F(s,H,x)
=l(H)-D(H)+n(1-s)[M(H)-F(s,H,x)].
\tag{SE8}
\]

对一般 L1，它首先是 R176 SF12–13 的 AC 路径/可积面表达。s(x),L(x) 代入的合法性使用同一个公共好集，不要求 f 光滑。

当 L e^ε≤b，令 ⟨G⟩₊=ε^(−1)∫_L^{Le^ε}G(H)dH/H；当 L e^(−ε)≥a，令 ⟨G⟩₋=ε^(−1)∫_{Le^(−ε)}^LG(H)dH/H。由全局极值定义

R₊(ε)=[q_*−F(s,Le^ε,x)]/ε≥0，
R₋(ε)=[q_*−F(s,Le^(−ε),x)]/ε≥0。

保留所有项的 Euler 版本是

\[
\begin{aligned}
n(1-s)\langle M-F\rangle_+&=-R_+(\varepsilon)-\langle l\rangle_++\langle D\rangle_+,\\
n(1-s)\langle M-F\rangle_-&=+R_-(\varepsilon)-\langle l\rangle_-+\langle D\rangle_-.
\end{aligned}
\tag{SE9}
\]

这不把面核当 future 测试；只有体积端点是合法测试。L=a 只有右式；L=b 只有左式，后者的非负 R₋给面差下界，不能作为上界丢弃。若 L 为可微的尺度内极值，则 R±→0；在光滑情形准确 Euler 为 n(1−s)(M(L)−q_*)=D_*−l(L)。可微的左端点只有尺度右导数≤0，右端点只有左导数≥0，符号分别给上、下界；不能都写等于0。

在一般 L1，R±可以保留非零尖点缺陷，且 M(L) 的选中点 trace 不一定由路径代表元确定，所以 SE9 是无平滑误差的安全版本。l(H),D(H) 对 H 连续，故其平均趋向选中值，但 **邻 H 的 s 未必是该 H 的软度最大值**：不能声称整个路径 0≤D(H)≤cq_*。有限 ε 必须保留 ⟨D⟩，或显式支付 ω_D(ε)=sup_{|log(H/L)|≤ε}|D(H)−D_*|。其逐 x 趋0不等于已有可积统一误差费用。SE7 仅控制选中点，不能凭它积分替换 SE9 的邻域费用。

## SE5. 实际 f 加权的 latent 混合：无独立性假设

对 E⊂{1,…,n} 令 P_{E,H} 在 E 中取 φ_H，其余取 h_H。令 a_E(H,x)=(P_{E,H}*f)(x)≥0，则准确有限展开为

\[
F(s,H,x)=\sum_E s^{|E|}(1-s)^{n-|E|}a_E(H,x).
\tag{SE10}
\]

固定任何满足原 FIRST 的当前 (s,L,q)，其中 0<s<1、q>0，定义共同 latent/真实来源后验

\[
\pi(E,dz)=\frac{s^{|E|}(1-s)^{n-|E|}P_{E,L}(x-z)f(z)dz}{q},
\qquad K(E,z)=|E|.
\tag{SE11}
\]

它质量为1。这里仅潜在软度标签采用产品系数；在实际 f 加权后 E 的坐标一般不独立。固定 z 时标签确有独立成功概率 sφ((xᵢ−zᵢ)/L)/b_s((xᵢ−zᵢ)/L)，但对 z 混合后不继承独立性，后文也不用它。微分有限展开直接给

\[
s(1-s)F_s(s,L,x)=q(\mathbb E_\pi K-ns).
\tag{SE12}
\]

原单边 FIRST 因而只给 EK≤ns；它不一般给等号。SE7 的下端点界现在完整成立，因为 EK≥0。新全局选择的 interior s 则给 EK=ns。

## SE6. continuum FIRST 给准确单边指数矩控制

对每个合法 u∈[s,1]，包括 u=1 按多项式端点取值，非负展开给

\[
\mathbb E_\pi\left[(u/s)^K((1-u)/(1-s))^{n-K}\right]
=\frac{F(u,L,x)}{q}\le1.
\tag{SE13}
\]

令 u=s e^θ/(1−s+s e^θ)，直接代入得到

\[
\boxed{\mathbb E_\pi e^{\theta K}
\le(1-s+s e^\theta)^n,\qquad\theta\ge0.}
\tag{SE14}
\]

这来自当前选中 L 上全部合法 future；不是将未知来源矩加为新假设。若使用新全局选择，同一个公式还对 θ≥logit(s₀)−logit(s) 成立，因为此范围恰为 u≥s₀。它不自动给所有负 θ；下端点 s=s₀只有 θ≥0。对邻尺度 H 若归一化为 F(s,H)，右端会出现 q/F(s,H) 的倍率，故 SE11–14 全程在当前 L 且 q=F(s,L) 使用。

在 interior s₀<s<1，EK=ns，而 SE14 两边在 θ=0 的值和一阶导数一致。相减右端减左端在 θ≥0 非负，零点相切，有限多项式的二阶右导数非负，故 E K²≤n²s²+ns(1−s)，即

\[
\operatorname{Var}_\pi K\le ns(1-s).
\tag{SE15}
\]

这是整个 f 后验的结论，不是每个来源子测度各自的结论；也没有以单边 EK<ns 推出同一方差界。s=1 单独处理：只有 E=全坐标有权，K=n 恒定，D_*=0；SE13 的比值写法不在 s=1 使用。

## SE7. 物理 hard-overflow 的准确尾质量及 receiver 费用

先从 SE14 自证尾界。对 θ≥0 和整数 k，1_{K≥k}≤exp(θ(K−k))，因此尾概率≤inf_{θ≥0}exp(−θk)(1−s+s e^θ)^n。当 ns<k<n，取 e^θ=k(1−s)/[s(n−k)] 得

\[
\pi(K\ge k)\le\delta_{n,s}(k):=
\exp\{-n[\tfrac{k}{n}\log\tfrac{k/n}{s}+(1-\tfrac{k}{n})\log\tfrac{1-k/n}{1-s}]\}.
\tag{SE16}
\]

k=n 的极限为 s^n；k≤ns 时本稿仅用1；k>n 为0。不声称后验尾被 binomial 的真实累积尾逐项随机支配，SE16 是其同一个 Chernoff 指数上界。

特别在新选择的下软度面 s=s₀，ns₀≤c，且 log(1+s₀(e^θ−1))≤s₀(e^θ−1)，所以 E exp(θK)≤exp[c(e^θ−1)]。对整数 k>c，取 θ=log(k/c) 给

\[
\pi(K\ge k)\le\delta_c(k):=
\exp[-k\log(k/c)+k-c]\le(ec/k)^k.
\tag{SE17}
\]

可将 δ_c(k) 再与1取小；k>n 时尾实际为0。这是任意给定 c 的维数无关尾，不需输入是原子或乘积。

现在定义真实当前 hard-cube 外坐标数

\[
m_L(x,z)=\#\{i:|x_i-z_i|>L/2\}.
\]

在 SE11 的支持上，任一 i∉E 必须 |xᵢ−zᵢ|≤L/2，否则该 hard 因子为0。因此逐支持点 m_L(x,z)≤K。闭硬面属于 inside，严格外点用 >，没有边界漏项。将 E 求和后获得真正物理输入质量界

\[
\boxed{\int_{m_L(x,z)\ge k}P_{s,L}(x-z)f(z)dz
\le\delta_{n,s}(k)q.}
\tag{SE18}
\]

在新选择下端面 X₀={x:s_*(x)=s₀}，可用 δ_c(k)。对任意 measurable X⊂X₀，真实 receiver dx 费用为

\[
\int_Xdx\int_{m_{L_*(x)}(x,z)\ge k}
P_{s_*(x),L_*(x)}(x-z)f(z)dz
\le\delta_c(k)\int_Xq_*(x)dx.
\tag{SE19}
\]

所以在这些实际 input-kernel 槽中，可按给定 δ>0 选有限 k 使费用≤δ∫_Xq_*，并完整保留 m<k 的补集。没有原概率来源假设。若一族共同来源满足 ∑_Vβ_V≤f dz，且使用同一个当前核、窗口和尾条件，可先对来源求和再用 SE18–19，不重复收多份 q_*；若来源/核/窗口随 V 改变，则该合并不成立。外层 unique-j 的不相交分割可直接并为 X；若实际式保留多重列、历史密度或其他系数，则仍须保留其真实费用。

另有一个已付的下软度面连续子项：在 X₀ 上 s=s₀ 是同一个固定数。对任意 measurable 终点 H†(x)∈[a,b]，先限制 dx 再用 SE4，得到

\[
\int_{X_0}dx\int_a^{H^\dagger(x)}|(f*\mathcal L_{s_0,H})(x)|\frac{dH}{H}
\le\tfrac32\sqrt{ns_0}\log(b/a)\|f\|_1
\le\tfrac32\sqrt c\log(b/a)\|f\|_1.
\tag{SE20}
\]

这里未在 x 积分内选择不同 s，故没有遗漏自适应软度费。它只支付 soft-only 连续子项；SE3 的软度导数路径和 SE9 的邻尺度 D/硬面仍完整保留，不能称为整个 bulk 的维数无关界。

SE18 对原单边 FIRST 本身也成立，但仅当原选中 s 恰有 ns=O(1) 时给维数无关尾。新全局 interior s 虽有 SE15，也可能 ns 很大；s=1 的 m≤n 没有稀疏尾收益。不能把 X₀ 的新付款冒充对全部 receiver 的覆盖。

## SE8. 已取得的结构与准确未付项

新增可直接使用的量为：实际 continuum FIRST 对当前 kernel-f 来源后验的 SE14 指数矩；新全局 interior 的 SE15 方差；下软度面的 SE18–19 物理 hard-overflow receiver 尾质量预算；以及 SE3/SE8 的真实软度—硬面耦合。它们不是自由后验矩门，也不是任意 soft selector 的强界。

以下补集及费用仍保留：

1. 原自适应 s(x) 的 Lsoft/bulk 路径范数，不能从 SE4 免费取得；SE7 的选中点费用不能替换 SE9 的邻尺度平均 D，后者有显式 ω_D/尖点/端点项。
2. latent K 是 mixed-kernel 的软标签计数，m 是当前 x−z 的 hard-overflow；两者均不是旧来源阈值阶梯 k_t(v)。未证明把 SE19 传给旧 pair-score、lowcapture 反权核、same-alpha 或 rho 的全部加权槽。SE19 已付的仅是所写物理 kernel-f 尾质量，任意额外乘子须另估。
3. 极值条件针对同一个完整 f。对 ν≤f，F_s(f)=F_s(ν)+F_s(f−ν) 中后项有符号，不能推导 ν 自身驻点/下降符号；不能对不同来源分别用 SE7/SE15 后不计来源总费用。
4. 新全局 q_*,s_*,L_* 有 receiver FIRST 和 hardmax 支配；原 CJ/history 的 before-V 窗口、共同 q、λ、high、same-alpha 和 β/ν 约束是否可同时重建尚未证明。父稿的可测选择证明不支付这些项，也未证明新 supremum 的 weak bound。
5. 一般 L1 已用公共 AC/有限差分处理，没有引入平滑后免费忽略误差。若后来为真实三点系数作积分分部或正则化，仍需实际 masks、selector 面、trace、导数和极限费用。原 signed 硬面账不得先取正部后声称 SE8 已抵消。

本有界稿至此停止。没有声称 FULL、一般 L1 weak bound 闭合，或原 R175 lowcapture 目标全部付清；不修改其他文件，不 Git/spawn/PDF。
