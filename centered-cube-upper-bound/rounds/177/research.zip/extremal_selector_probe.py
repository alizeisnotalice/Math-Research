#!/usr/bin/env python3
"""R177 bounded physical scale/softness selector diagnostics; no continuum H claim."""
from pathlib import Path
from fractions import Fraction as F
from functools import lru_cache
import json,sys,time,hashlib,importlib.util
HERE=Path(__file__).resolve().parent
VENDOR=Path('/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor');sys.path.insert(0,str(VENDOR));import mpmath as mp
SEED=Path('/Users/zhengzhihao/Desktop/T/output/centered_cube_round175_20261016_final_checkpoint/active_geometry_probe.json')
TOOL=Path('/Users/zhengzhihao/Desktop/T/output/centered_cube_round168_20261016_final_checkpoint/lp_candidate_certificate.py')
sp=importlib.util.spec_from_file_location('r177_interval',TOOL);ct=importlib.util.module_from_spec(sp);sp.loader.exec_module(ct);I=ct.I
EPS=F(1,2**32);THETA=('0.1','1','3')
def M(z):z=F(z);return mp.mpf(z.numerator)/z.denominator
def txt(z):return mp.nstr(z,mp.mp.dps)
@lru_cache(None)
def phi(d,dps):
 with mp.workdps(dps):
  z=abs(M(d));e=lambda t:mp.mpf('.5') if t==0 else mp.expint(3,t)
  return +(1-e(mp.mpf('.5')-z)-e(mp.mpf('.5')+z) if z<=mp.mpf('.5') else e(z-mp.mpf('.5'))-e(z+mp.mpf('.5')))
def mul(a,b):
 out=[mp.mpf(0)]*(len(a)+len(b)-1)
 for i,x in enumerate(a):
  for j,y in enumerate(b):out[i+j]+=x*y
 return out
def val(a,x):return mp.polyval(list(reversed(a)),x)
def derivative(a):return [i*a[i] for i in range(1,len(a))]
def roots_in(a,lo,hi):
 # Recursive critical-point partition of a cubic or lower polynomial. Numerical, not root isolation proof.
 while len(a)>1 and a[-1]==0:a=a[:-1]
 if len(a)<=1:return []
 if len(a)==2:
  z=-a[0]/a[1];return [z] if lo<=z<=hi else []
 critical=roots_in(derivative(a),lo,hi);nodes=[lo]+critical+[hi];scale=max([abs(z) for z in a]+[mp.mpf('1e-100')]);tol=mp.mpf(10)**(-mp.mp.dps+12)*scale;out=[]
 for z in nodes:
  if abs(val(a,z))<=tol:out.append(z)
 for l,r in zip(nodes,nodes[1:]):
  fl,fr=val(a,l),val(a,r)
  if fl*fr>=0:continue
  for _ in range(4*mp.mp.dps):
   mid=(l+r)/2;fm=val(a,mid)
   if fl*fm<=0:r=mid
   else:l=mid;fl=fm
  out.append((l+r)/2)
 out.sort();dedup=[]
 for z in out:
  if not dedup or abs(z-dedup[-1])>mp.mpf(10)**(-mp.mp.dps+10):dedup.append(z)
 return dedup

def inputs():
 old=json.loads(SEED.read_text());out=[]
 for n in (4,16):
  c=next(z['input'] for z in old['certificates'] if z['input']['n']==n)
  out.append(dict(n=n,positions=[F(c[k]) for k in ('v','u','y')]+[F(c['completion_position'])],masses=[F(c['eta']),1-F(c['eta']),F(c['epsilon']),F(c['completion_mass'])]))
 return out

def faces(c,x):return sorted(set([F(1,2),F(1)]+[2*abs(t-z) for t in x for z in c['positions'] if F(1,2)<=2*abs(t-z)<=1]))
def polynomial(c,x,H,left=False):
 n=c['n'];power=[mp.mpf(0)]*(n+1);bern=[mp.mpf(0)]*(n+1);atoms=[]
 for mass,z in zip(c['masses'],c['positions']):
  pp=[mp.mpf(1)];bb=[mp.mpf(1)];factors=[]
  for t in x:
   d=abs(t-z);hard=int(2*d<H or (2*d==H and not left));ph=phi(d/H,mp.mp.dps)
   pp=mul(pp,[mp.mpf(hard),ph-hard]);bb=mul(bb,[mp.mpf(hard),ph]);factors.append((d,hard,ph))
  scale=M(mass)/M(H)**n
  for k in range(n+1):power[k]+=scale*pp[k];bern[k]+=scale*bb[k]
  atoms.append((scale,factors))
 return power,bern,atoms

def fixed(c,x,H,left=False):
 n=c['n'];s0=1-mp.exp(-mp.mpf(1)/n);power,bern,atoms=polynomial(c,x,H,left)
 rs=roots_in(derivative(power),s0,mp.mpf(1)) if n==4 else []
 # At symmetric x0 each atom has a single repeated affine factor: convexity proves endpoint sufficiency.
 if n!=4:assert len(set(x))==1
 candidates=[s0,mp.mpf(1)]+[z for z in rs if s0<z<1];scores=[val(power,z) for z in candidates];winner=max(range(len(scores)),key=scores.__getitem__);s=candidates[winner];q=scores[winner]
 Fprime=val(derivative(power),s);Ds=-s*(1-s)*Fprime
 weights=[bern[k]*s**k*(1-s)**(n-k)/q for k in range(n+1)];mean=mp.fsum(k*w for k,w in enumerate(weights))
 mgf=[]
 for t in THETA:
  theta=mp.mpf(t);ev=mp.exp(theta);mg=mp.fsum(w*ev**k for k,w in enumerate(weights));bn=(1-s+s*ev)**n;po=mp.exp(n*s*(ev-1))
  spost=s*ev/(1-s+s*ev);identity=mg/bn-val(power,spost)/q
  mgf.append(dict(theta=t,mgf=txt(mg),binomial_bound=txt(bn),ratio=txt(mg/bn),numeric_pass=bool(mg<=bn*(1+mp.mpf(10)**(-mp.mp.dps+10))),tilted_softness=txt(spost),tilted_F_ratio=txt(val(power,spost)/q),identity_residual=txt(identity),poisson_mean_ns_bound=txt(po),poisson_mean_one_bound=txt(mp.exp(ev-1)) if winner==0 else None))
 tails=[]
 for k in sorted(set([2,min(4,n)])):
  exact=mp.fsum(weights[k:]);lam=n*s;bd=mp.exp(-lam)*(mp.e*lam/k)**k if k>lam else mp.mpf(1)
  tails.append(dict(k=k,probability=txt(exact),binomial_mgf_Poisson_Chernoff_bound=txt(bd),numeric_pass=bool(exact<=bd*(1+mp.mpf(10)**(-mp.mp.dps+10)))))
 # Scale derivative with hard masks frozen on the selected smooth branch.
 dlogH=mp.mpf(0)
 for scale,fac in atoms:
  fs=[(1-s)*h+s*ph for d,h,ph in fac]
  for i,(d,h,ph) in enumerate(fac):
   z=M(d/H);w=lambda a:mp.mpf(1) if a==0 else mp.expint(2,abs(a));phprime=w(z+mp.mpf('.5'))-w(z-mp.mpf('.5'))
   df=-fs[i]-s*z*phprime;dlogH+=scale*df*mp.fprod(fs[:i]+fs[i+1:])
 atface=any(2*abs(t-z)==H for t in x for z in c['positions']);boundary='lower_s0' if winner==0 else 'upper_1' if winner==1 else 'interior_stationary'
 return dict(H=str(H),branch='left_limit' if left else 'closed_value',hard_face=atface,soft_boundary=boundary,s=txt(s),s0=txt(s0),q=txt(q),F_original_soft_quarter=txt(val(power,mp.mpf('.25'))),soft_roots=[txt(z) for z in rs],soft_root_residuals=[txt(val(derivative(power),z)) for z in rs],soft_candidates=[dict(s=txt(z),F=txt(v)) for z,v in zip(candidates,scores)],D_s=txt(Ds),D_s_over_n_s0_q=txt(Ds/(n*s0*q)),soft_derivative=txt(Fprime),latent_weights=[txt(w) for w in weights],latent_mean=txt(mean),D_over_q_latent_identity_residual=txt(Ds/q-(n*s-mean)),latent_weight_sum_residual=txt(mp.fsum(weights)-1),latent_mgf=mgf,latent_tails=tails,smooth_branch_dlogH_F=txt(dlogH),smooth_branch_dlogH_F_over_q=txt(dlogH/q),scale_Euler='not asserted: finite H menu; a hard face is discontinuous for atomic f',soft_max_scope='n4 numerical complete cubic critical partition; n16 symmetric convex endpoint sufficiency',power_coefficients=[txt(z) for z in power],nonnegative_Bernstein_coefficients=[txt(z) for z in bern])

def ihardmax(c,x):
 candidates=[]
 for H in faces(c,x):
  v=sum((m/H**c['n'] for m,z in zip(c['masses'],c['positions']) if all(2*abs(t-z)<=H for t in x)),F(0));candidates.append((v,H))
 value,H=max(candidates);return dict(value=str(value),H=str(H),method='Fraction exact: hard convolution decreases as H^-n between closed hard faces')

def interval_point(c,x,row,N):
 H=F(row['H']);n=c['n'];s0=1-ct.iv.exp_neg(F(1,n));which=row['soft_boundary'];s=s0 if which=='lower_s0' else I(1) if which=='upper_1' else I(F(row['s']))
 total=I(0);prime=I(0)
 for mass,z in zip(c['masses'],c['positions']):
  factors=[];der=[]
  for t in x:
   d=abs(t-z);h=I(int(2*d<=H));ph=ct.phi_range(I(d/H),N);factors.append(((1-s)*h+s*ph)/I(H));der.append((ph-h)/I(H))
  total+=I(mass)*ct.prod(factors)
  prime+=I(mass)*sum((der[i]*ct.prod(factors[:i]+factors[i+1:]) for i in range(n)),I(0))
 Ds=-s*(1-s)*prime;bound=I(n)*s0*total;diff=bound-Ds;hard=ihardmax(c,x);hardmargin=total/ct.iv.exp_neg(F(1))-I(F(hard['value']))
 return dict(N=N,H=str(H),softness=s.out(),soft_boundary=which,q=total.out(),D_s=Ds.out(),n_s0_q=bound.out(),D_bound_margin=diff.out(),D_bound_status='pass' if diff.lo>=0 else 'undecided' if diff.hi>=0 else 'fail',hard_max=hard,hard_vs_e_q_margin=hardmargin.out(),hard_domination_status='pass' if hardmargin.lo>=0 else 'undecided' if hardmargin.hi>=0 else 'fail',soft_derivative=prime.out(),scope='directed arithmetic enclosure at selected physical H; no H optimum or interior-root enclosure claim')

def main():
 start=time.monotonic();mp.mp.dps=50;c4,c16=inputs();cases=[('stage1_n4_symmetric',c4,[F(0)]*4),('stage2_n4_asymmetric',c4,[F(1,1000)]+[F(2,1000)]*3),('stage2_n16_light',c16,[F(0)]*16)];out=[];alln4=0;alln16=0
 for name,c,x in cases:
  fs=faces(c,x);nodes=set(fs)
  for a,b in zip(fs,fs[1:]):nodes.update(a+(b-a)*F(k,6) for k in range(1,6))
  rows=[]
  for H in sorted(nodes):
   if time.monotonic()-start>120:raise RuntimeError('Approved prescreen budget reached; no expansion')
   rows.append(fixed(c,x,H))
  stage3=[]
  if c['n']==4:
   top=max(rows,key=lambda z:mp.mpf(z['q']));H=F(top['H']);nn=sorted(nodes);idx=nn.index(H);lo=nn[idx-1] if idx else H;hi=nn[idx+1] if idx+1<len(nn) else H
   extra=set(lo+(hi-lo)*F(k,10) for k in range(1,10))-nodes
   for h in sorted(extra):
    if time.monotonic()-start>120:raise RuntimeError('Approved prescreen budget reached')
    stage3.append(fixed(c,x,h))
   alln4+=len(rows)+len(stage3)
  else:alln16+=len(rows)
  allrows=rows+stage3;best=max(allrows,key=lambda z:mp.mpf(z['q']));face_rows=[]
  for H in fs:
   if any(2*abs(t-z)==H for t in x for z in c['positions']):
    closed=next(z for z in allrows if F(z['H'])==H);left=fixed(c,x,H,True)
    face_rows.append(dict(H=str(H),closed=closed,left=left,optimized_value_jump=txt(mp.mpf(closed['q'])-mp.mpf(left['q'])),same_closed_winner_soft_jump=txt(mp.mpf(closed['q'])-val([mp.mpf(a) for a in left['power_coefficients']],mp.mpf(closed['s'])))))
  hard=ihardmax(c,x);oldH=2*max(abs(t-F(9,20)) for t in x);old=fixed(c,x,oldH);oldq=mp.mpf(old['F_original_soft_quarter']);hardv=M(F(hard['value']));q=mp.mpf(best['q'])
  with mp.workdps(80):refined=fixed(c,x,F(best['H']));original80=fixed(c,x,oldH)
  out.append(dict(name=name,n=c['n'],x=[str(a) for a in x],positions=[str(a) for a in c['positions']],masses=[str(a) for a in c['masses']],physical_faces=[str(a) for a in fs],initial_H_count=len(rows),stage3_added_H_count=len(stage3),rows=rows,stage3_rows=stage3,face_sides=face_rows,selected50=best,selected80=refined,hard_max=hard,hard_over_e_newq=txt(hardv/(mp.e*q)),hard_comparison_numeric_pass=bool(hardv<=mp.e*q),old_s_quarter_selector_H=str(oldH),old_s_quarter_q=txt(oldq),new_over_old=txt(q/oldq),original80=original80,selector_scope='maximum over this finite H menu and fixed-H soft interval; not continuum H'))
 prescreen=time.monotonic()-start;assert alln4<=68 and alln16<=19
 cert=[]
 for result,c,x in zip(out[:2],(c4,c4),([F(0)]*4,[F(1,1000)]+[F(2,1000)]*3)):
  cert.append(dict(case=result['name'],refinements=[interval_point(c,x,result['selected80'],N) for N in (128,256)]))
 data=dict(scope='Bounded selector geometry for fixed atomic f, no source mutation or dx integration; finite-H selection only, not FIRST/history/L1 or a general weak bound.',c='1',s0='1-exp(-1/n)',soft_interval='[s0,1]',H_window=['1/2','1'],budget=dict(n4_H_evaluations=alln4,n16_H_evaluations=alln16,max_n4=68,max_n16=19,prescreen_seconds_cap=120,interval_points=2,interval_N=[128,256]),inputs={str(z):hashlib.sha256(z.read_bytes()).hexdigest() for z in (SEED,TOOL,Path(ct.DEP))},local_inputs={'task_contract.md':hashlib.sha256((HERE/'task_contract.md').read_bytes()).hexdigest()},cases=out,interval_checks=cert,notes=['No interval enclosure is claimed for polynomial root locations or H optimization.','At symmetric receivers the soft polynomial is convex by its repeated-factor physical structure; endpoints suffice.','Nonnegative Bernstein coefficients describe latent smoothing counts; mgf/Binomial ratio equals F(tilted s)/F(selected s).','A true fixed-H global soft maximum gives the mgf domination algebraically. Numerical roots merely check this on the fixed cases.','Hard window maximum for these atomic inputs is exactly evaluated at hard faces/endpoints; the hard-max<=e-newq comparison is supported structurally because all these radii are included.','Hard-face jumps and one-sided smooth branch derivatives must not be replaced by an Euler equality.','No integration or receiver volume is inferred.'],runtime=dict(prescreen_seconds=round(prescreen,3),total_seconds=round(time.monotonic()-start,3),python=sys.version,mpmath=mp.__version__))
 (HERE/'extremal_selector_probe.json').write_text(json.dumps(data,indent=2)+'\n')
 print(json.dumps(dict(budget=data['budget'],cases=[dict(name=z['name'],H=z['selected80']['H'],soft=z['selected80']['soft_boundary'],s=z['selected80']['s'],q=z['selected80']['q'],face=z['selected80']['hard_face'],scale_slope=z['selected80']['smooth_branch_dlogH_F_over_q'],new_over_old=z['new_over_old'],hard_over_e_newq=z['hard_over_e_newq']) for z in out],interval_checks=cert,runtime=data['runtime']),indent=2))
if __name__=='__main__':main()
