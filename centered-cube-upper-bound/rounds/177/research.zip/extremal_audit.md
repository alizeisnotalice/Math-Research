# R177 极值几何独立检查点

作者前筛查。仅本责任文件；不跑数值、不改作者、Git/spawn/PDF。本轮task_contract.md初次读取尚未落盘，暂按父级准确命题及已核R176 SF/R175 CJ合同，不读本轮作者稿。

## 1. 原FIRST的一阶信息

固定实际receiver x、原同输入f、窗口[a,b]，记F_x(u,H)=P_(u,H)*f(x)，原q=F_x(s,L)>0，且F_x(u,H)≤q对所有u≥s、H∈[a,b]成立。这里s=s(x)、L=L(x)可依x；不能为了证明另选使几何方便的current参数。

软度方向是有限多项式：P_(u,H)=sum_E u^|E|(1−u)^(n−|E|)P_(E,H)。H≥a>0的component kernel有共同有限上界，任意L1 f下可逐x求u导数。因此s<1时准确有

    partial_u F_x(s,L)≤0.                              (A1)

s=1没有允许的右方向，不能从FIRST断言该符号。s=0右导存在；无需除以s。其他future软度u>s并非触到q，不能在其上直接写同样stationarity。

对0<s<1，定义实际full-input概率

    mu_x^f(dy)=P_(s,L)(x−y)f(y)dy/q.

这是为FIRST极值信息所作的确切归一，与原Pi、nu及tau/mu来源槽不同。A1等价

    E_mu sum_i [(phi−h)/b_s]((x_i−y_i)/L)≤0.

令m=# {i:|x_i−y_i|>L/2}，c=1−phi(1/2)。core内phi≥phi(1/2)，故score每坐标至少−c/(1−sc)；外core恰为1/s。因此

    sum_i(φ−h)/b_s≥[m−nsc]/[s(1−sc)],
    E_mu m≤nsc.                                      (A2)

闭hard边界算inside；对L1输入边界本身零质量。A2是合法一阶overflow约束，不是来源坐标独立、集中或sqrt(n)尾界，也不是原C阈值score k_t或delta。s=0时mu支持hard core，m=0直接成立；s=1不可由不存在的右向条件延拓A2。

## 2. actual尺度处的导数需要额外合法性

若H↦F_x(s,H)在actual L可微，则FIRST给

    a<L<b: partial_logH F_x(s,L)=0,
    L=a:   右导≤0,
    L=b:   左导≥0.                                   (A3)

这不是任意L1的自动逐点结论。R176 SF13给同一receiver满测集上所有s的尺度AC和连续端点，但AC曲线仅保证a.e.H可微；实际L(x)可能专门选中不可微尺度。公共s好集没有解决所选H的可微性。对C_c^1输入等可用pointwise导数；或另证actual选择避开坏尺度。全soft s=1的smooth kernel也可直接用有界kernel导数/DCT处理，但不代表mixed情况。

无任何额外正则时，合法而准确的替代是全future有限差：对每个H∈[a,b]，

    F_x(s,H)−q
    =integral_L^H {B_(s,u)*f(x)
       +n(1−s)[Fbar_(s,u)*f(x)−F_x(s,u)]}du/u≤0.        (A4)

积分按方向解释，R176共同AC/物理端点证明允许actual s(x)、L(x)代入该有符号身份；不得把其中face迹单独在不可微L处强行取值。等价的Dini符号只有forward quotient≤0、backward quotient≥0；并非两个经典导数必相等。

## 3. 从极值条件到原source预算不能省的确切项

即使A3合法并取interior L，SF4只给full f的

    n(1−s)[Fbar_(s,L)*f−q]=−B_(s,L)*f.                 (A5)

它保留正face与负volume补偿。fixeds路径bulk的root范数不能替代actual L处瞬时bulk范数，更不能在s(x)选择后免费取同价。原R176尚未付的adaptive s、face及j/window费用没有被stationarity符号消去。

原nu≤beta≤f不足以将A1/A3直接降到nu或beta；导数kernel是signed，准确关系为

    derivative(P*nu)=derivative(P*f)−derivative(P*(f−nu)). (A6)

后项可能有两种符号，其规模、face和samealpha来源相关性必须保留。任意actual三点/alpha/rho/good/lowcapture权乘进去之后，A1/A5的fullf取消一般不再成立；若用加权积分分部，还须完整计权的尺度/空间变化、hardface traces及原masks/selector BV。不能先丢负体积项，再引用A5领取取消信用。

source上界需要共同f、固定原参数和相同测试权；逐y或逐v分别选择future/clock后再用同一个FIRST q，仍是不合法量词。原tau_j分别subprob和本轮FIRST极值均不自动给跨j/窗口列积分预算。

## 4. 当前判断及一次后审目标

A1和A2为一般正L1实际current输入上的准确可用一阶约束；A3只在所选点可微或相应Dini解释下成立。一般L1应先用A4，不用形式instantaneous face值代替。联合这些条件尚未自证原lowcapture source根阶费；剩余准确义务是控制A6的来源缺额项与加权face/bulk，在实际adaptive receiver和原j/window/history上积分。

作者成稿到达后只核新准确命题是否真正支付这些项、各边界是否保留，以及是否有同一共同输入的全局费用；不再重复基础核推导，不以新未知gate作闭合。检查点交付后等待。


## 5. 新global-soft selector：作者前准确候选筛查

现已实读后落盘的R177 task_contract.md。固定c>log2，s0=1−exp(−c/n)，在同一紧参数集[s0,1]×[a,b]取F_x的最大值q*(x)，先以C_c^infinity正输入处理pointwise尺度Euler。一般正L1下F_x仍对该紧参数集连续（kernel共同有界、移动hard边界对L1源零测），所以最大值存在；可用参数restricted maxima的可测性作lexicographic可测选择。

对每个H，P_(s0,H)≥(1−s0)^n h_H^(tensor n)=exp(−c)h_H^(tensor n)。因此同一尺度族的hardmax≤exp(c)q*。这是真实pointwise目标支配，不是把旧selector假设成globalmax；若讨论全H>0的极大值，须采用相同全H上确界或另行处理端点/窗口，而不能把单个固定窗口等同全局算子。

新最大点(s*,L*)处令Dsoft=−s*(1−s*)F_s(s*,L*)。内soft点导数0，s0端右导≤0，s1端乘子0，且逐kernel有−s(1−s)∂sP≤nsP。因此

    0≤Dsoft≤n s0 q*≤c q*.                            (B1)

可用的精确joint identity为

    B_(s,H)=Lsoft_(s,H)+s(1−s)∂sP_(s,H),
    Lsoft=sum_i s[−phi(r_i)−r_i phi'(r_i)]
                      H^(−n) product_(j≠i)b_s(r_j).    (B2)

Lsoft是latent soft-component的均值零尺度score，固定s时核L1≤sqrt(ns I(phi))；这不证明选定s*(x),L*(x)处的receiver列预算。

若选定尺度可微，记Eface=n(1−s*)(Fbar*f−q*)，则内尺度Eface=Dsoft−Lsoft*f；下端L*=a给Eface≤该右端；上端L*=b只给Eface≥该右端。上端不提供所需的face上界，不能把三种情形都写等号。

一般L1的可靠形式是邻尺度平均Euler。对可用ε>0，令H±=L*exp(±ε)，R±=(q*−F(s*,H±))/ε≥0，则

    avg_right Eface=−R+−avg_right Lsoft+avg_right Dsoft(H),
    avg_left  Eface=+R−−avg_left Lsoft+avg_left Dsoft(H). (B3)

只在H±位于[a,b]时使用；端点仅有一个方向。邻H的Dsoft(H)不是该H的soft最大点，finiteε下不能套B1；可保留其实际平均或显式连续模量。尽管Dsoft(H)→Dsoft(L*)，receiver积分中的uniform小误差/极限费用没有因此自动成立。若当前尺度可微，interior R±→0；hard cusp时不能删它们。

从smooth输入向一般L1传递，只能在已证明新sup的uniform weak界后用近似/Fatou；目前没有该weak界。固定[a,b]甚至可用kernel≤a^(−n)得输入L1近似下sup的uniform收敛；这只解决合法传递，不能创造尚未证明的预算。新sup也不免费继承旧CJ、history或来源删除合同。

## 6. latent-count MGF：作者前独立筛查

在实际current(s,H)使P_(s,H)f=q的行上，0<s<1，定义latent(E,y)联合概率密度

    s^|E|(1−s)^(n−|E|)P_(E,H)(x−y)f(y)/q,
    K=|E|.

对Z=1−s+s expθ、u=s expθ/Z有精确身份

    E exp(θK)=Z^n F_x(u,H)/q.                          (C1)

旧FIRST仅允许u≥s，因此θ≥0时给Binomial(n,s) MGF上界。新global selector允许θ≥logit(s0)−logit(s)，不能免费推广至所有负θ。s=1时K=n为退化情形，直接处理，不能套含logit(1)的变换；s=0时K=0（新selector不取此端点）。

m=#outside hard H-cube≤K a.s.，因为每个outside坐标必须由phi component承担。因此positiveθ给m上尾的Binomial Chernoff界，不需要任何原source独立性。MGF支配不等于对所有事件的Binomial分布随机支配，后者不在本候选中认证。

在新选择器的s=s0支，n s0≤c，k≥c时可取θ=log(k/c)≥0，得到

    P(m≥k)≤min(1,(ec/k)^k),                            (C2)

也可保留更强exp(−c)因子；k>n尾为0。C2只在最低soft支有统一c，不能把任意interior s*的ns*替换成c。

C2准确意味着当前fullf核的未归一尾质量≤δ_k q*(x)，因而真实receiver积分≤δ_k integral q*dx；nu≤f的同kernel尾亦有此未归一上界。不推出原Pi_t、C-threshold k_t的相同尾，更不直接支付含1/K0、samealpha rho及两外来源槽的CJ weighted交通。旧q与新q*不可无条件混同。

## 7. 原FIRST的正growth短路径：作者前独立筛查

父级/Astra精确候选在旧actual参数上成立，且无需选定尺度可微：

    G_(s,H)=∂logH(P_(s,H)dz)+nP_(s,H)dz
            =R_(s,H)dz+n(1−s)Fbar_(s,H)≥0,
    R=P sum_i[−r_i s phi'(r_i)/b_s(r_i)]≥0.            (D1)

R的正性用phi偶递减，s0按零bulk处理。SF13公共尺度AC足以在一般L1同一receiver好集代actual s(x),L(x)。对合法H+≥L，

    integral_L^H+ f*G dH/H
     =F(H+)−q+n integral_L^H+ F(H)dH/H
     ≤nlog(H+/L)q.                                   (D2)

因此log(H+/L)≤ε/n的真实正growth路径有ε q接收价，无须face正负取消或固定s的root范数。向下则须保留缺额：

    integral_H0^L f*G≤q−F(H0)+nlog(L/H0)q.            (D3)

nuV版本的缺额是q−P_(s,H0)nuV，只有H0恰为原K0尺度时才是同一CJ G0。不得逐V分别领一份q；共同kernel/端点时应先用sum nuV≤f。

hardface occupation是可积正kernel

    (1−s)sum_i 1_{L<r_i≤H+} r_i^(−n)
                     product_(k≠i)b_s(z_k/r_i),
    r_i=2|z_i|.                                      (D4)

每面1/2与H根Jacobian2抵消，留下r_i^(−n)，无额外2或n。r_i=0不在L>0窗口。固定receiver下端点source hyperplane对L1输入零测；原子诊断若使用则不能据此忽略原子端点。

若多个upward端点共享同一current s,L且都落在统一短窗口[L,min(b,Lexp(ε/n))]，正性可用该一个共同路径覆盖，无需逐j重复领取εq；任意不同kernel、窗口或j相关归一不在此结论中。D2–D4尚无对CJ真实三点乘子/支持的支配，所以目前仅为正growth的真实dx预算，未登记原raw交通新付款。

以上新候选均已先独筛并向父级/作者反馈，等待准确稿一次后审；不跑数值、不扩展反例搜索。


## 8. latent二阶及原raw尾支：作者前核算

新global soft内点s0<s<1时，C1在theta0双侧邻域成立，且soft stationarity给EK=ns。两MGF在0相切，二阶比较给

    Var K≤ns(1−s).

所有latent矩有限，比较合法，不假设source独立。s=s0处均值可严格小于ns0，不能仅由单侧mgf免费声称相同variance；s1直接K=n。

更重要的原raw新付支不需newselector：对原current s(x),L(x)，令chi_(n,s)(k)为正theta的Binomial Chernoff上界（k≤ns取1，ns<k≤n取exp[−n D(k/n||s)]，k=n+1取0；s1单列n+1）。为给定delta∈(0,1)取最小可行整数k(s,delta)，它是显式可测函数，不是新未知moment gate。原FIRST给

    integral p_y 1_{m_y≥k(s,delta)} f(y)dy≤delta q.

已为该新付价亲读R128原RT1–RT4窄段：RT1外层准确含1_{j(x)=j}，不是依内源或删源后才出现的“唯一j”；RT4的actual far interval在[τ_j,h]，其比例至多b/a≤2。原正J份额经hard∫h_RnuV≤16q/3及outer2Lambda后，保留唯一j至统一正上界，用A≤1、score差≤n、Pi×Pi概率≤1、time≤log2，得

    RawPositive_J[m_y≥k(s,delta)]
       ≤(32Lambda/3)nlog2 ·delta E integral q dx.        (E1)

再用sumV betaV≤f（两外槽同时包括）完成的是原actualdx积分，不是固定receiver toy价。取delta=min{1,3epsilon/(32Lambda nlog2)}，或epsilon小到该值<1时用等号公式，即得epsilon receiver价。若delta=1，原粗帽已≤epsilon；无须负log参数。

该分支可只切R174 R_eta和R175 lowcapture以免与此前已付槽重叠；所有原signed负账不消费。没有免费跨窗口；q、s、L对V共同及实际j(x)身份是费用成立的必要量词。k可能随s增大到n+1而尾支为空，不能一般称为O(logn)稀疏划分。m_y是receiver-currentcube外坐标数，不是原k_t来源阈值。

## 9. 指数权Duhamel及p拆分：作者前核算

D1的正measure G满足准确积分因子恒等式

    integral_H0^L (H/L)^n G_(s,H)dH/H
       =P_(s,L)−(H0/L)^n P_(s,H0)=:T_(H0,L)≥0.         (E2)

sameinput FIRST给f*T=q−c0F(H0)≤q，c0=(H0/L)^n。全窗归一到b也有∫a^b(H/b)^n f*G≤q。这是完整q价，不能与短窗epsilon q混称；去掉衰减权最坏损失(L/H0)^n。

精确分解f*T=(1−c0)q+c0[q−F(H0)]。若log(L/H0)≤epsilon/n，则1−c0≤epsilon，故薄下行路径≤epsilon q+q−F(H0)；缺额项仍必须保留。sumV beta/nu/zeta≤f且同kernel/路径时可先求和应用一个共同q，不能逐V分别付G0。H0=原Hhat且Hhat≤L时才得到p_y=c0 K0_y+T_y；Hhat>L的原分支不在此式，须另留。

CJ companion中一份p替换T后，留下完整系数

    T_y ·[p_y rho_v²J_v/(9Q_v²)] wt_vwt_u/e_t².

即使good，至多变成

    T_y ·[K rho_v²J_v/(9Q_v wg(v))] wt_vwt_u/e_t².

后面的y/v/u相关乘子未由无权f*T≤q控制。这里的“共同来源增长预算”没有证明CJ完整weighted列价；不能把T的正核真实receiver预算直接登记成原source根阶费。

以上准确新候选均已作者前筛查，现接续各稿一次全文后审，不运行数值。


## 10. 作者全文及整合后审

已在第1–9节独立筛查之后实读全部成稿，指定范围通过，无待修理论问题：

- soft_extremal_variation.md：SE1–20准确保留单边/双边soft条件、latent矩、scale端点/尖点与邻尺度D平均。SE20在X0上固定同一s0，给(3/2)sqrt(c)log(b/a)||f||1；未包含硬面或软度导数路径。
- extremal_face_budget.md：OT1–5确实接回原raw，32Lambda nlog2/3及原j(x)、完整beta、hard一次均与第8节独立核验一致。smallmean解析阈值证明正确。EF1–12正增长/Duhamel不去指数权，仍完整留下EF10的实际三点乘子及Hhat>L等补集。
- measurable_extremal_reduction.md：joint continuity、有限层nested closed boxes的Borel精确选择、固定窗口L1 uniform近似均自含成立；不依赖未经验收的一般选择定理。没有免费推出全尺度weak bound或旧history兼容。
- proof.tex.txt与report.md：已一次实读整合范围；原selector的OT真付款与newselector结构明确分开，低overflow补集及weighted三点余项未付。数值证据仍为有限范围，本独审未重跑或认证新数值字段。

## 11. 最终绑定与停止

最终实读/实算理论稿SHA256：

| 文件 | SHA256 |
| --- | --- |
| soft_extremal_variation.md | dcf33d5aebfa69b7720ae72b8e9c7345d3c70c46838983b5ed2a1e7f7c8f0083 |
| extremal_face_budget.md | f615c2e55045f792ec17e3f1e9f2ac900bcca79a91dcf9999ce12018febf61f8 |
| measurable_extremal_reduction.md | d331368012f28db4ad20cef5ccedcc795caf5562412991af0f23b55f42e9efa1 |
| proof.tex.txt | 1ccdd932726a1f39ec435a001030545235ae37289a0e06996309d8af4c13ecb9 |

指定范围通过，无待修理论问题。本轮实际新付款为原outer高overflow尾OT2；其他latent/selector/flux结果各依其准确范围使用。低overflow/完整weighted三点余项及一般结论仍未付。仅编辑本责任文件，无数值、Git/spawn/PDF或他人文件修改；现冻结停止。
