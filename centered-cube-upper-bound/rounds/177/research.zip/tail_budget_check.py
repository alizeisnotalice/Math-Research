"""Exact finite checks of outer-source tail thresholds and payment constants."""
from fractions import Fraction as F
from pathlib import Path
import json
Lambda=F(128,119); epsilon=F(1,100); C=F(32,3)*Lambda
stages={'initial':[4,16], 'pressure':[2,3,64], 'expanded':[256,1024,65536]}
rows=[]
for stage,ns in stages.items():
 for n in ns:
  delta=epsilon/(C*n) # use log(2)<1, so this is conservative
  k=3
  while F(3,k)**k>delta:k+=1
  # mean <=1, Poisson Chernoff plus e<3 yields this rational certificate
  tail=F(0) if k>n else F(3,k)**k
  assert C*n*tail<=epsilon
  rows.append(dict(stage=stage,n=n,kind='mean_at_most_one',k=k,empty=k>n,tail_bound=str(tail),receiver_coefficient=str(C*n*tail),delta=str(delta),pass_exact=True))
  if n<=1024:
   for s in sorted(set([F(1,n),F(1,4),F(1,2),F(3,4)])):
    # fixed theta=log2: exp(-theta*k) BinMGF=(1+s)^n/2^k
    k=0; mg=(1+s)**n
    while k<=n and mg/F(2)**k>delta:k+=1
    tail=F(0) if k>n else mg/F(2)**k
    assert C*n*tail<=epsilon
    if k<=n and k>0:assert mg/F(2)**(k-1)>delta
    rows.append(dict(stage=stage,n=n,s=str(s),kind='fixed_log2_tilt',k=k,empty=k>n,tail_bound=str(tail),receiver_coefficient=str(C*n*tail),delta=str(delta),pass_exact=True))
out=dict(scope='Exact finite rational checks; analytic FIRST mgf and raw domination are proved separately. No exponent fitting.',epsilon=str(epsilon),Lambda=str(Lambda),clock_upper='log(2)<1',rows=rows)
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'cases':len(rows),'all_exact_pass':True,'mean_one_thresholds':[(r['n'],r['k']) for r in rows if r['kind']=='mean_at_most_one']}))
