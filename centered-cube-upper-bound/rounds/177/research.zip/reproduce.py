#!/usr/bin/env python3
from pathlib import Path
import argparse,hashlib,json,shutil,subprocess,sys
BASE=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--verify-only',action='store_true');p.add_argument('--output-dir',type=Path);a=p.parse_args()
m=json.loads((BASE/'inventory.json').read_text())
for n,d in m['files'].items():assert hashlib.sha256((BASE/n).read_bytes()).hexdigest()==d,n
print('Archive bytes verified')
if a.verify_only:sys.exit(0)
if a.output_dir is None:p.error('--output-dir required')
out=a.output_dir.resolve();assert out!=BASE
out.mkdir(parents=True,exist_ok=True);assert not any(out.iterdir()),'Use an empty directory'
for n in m['files']:shutil.copy2(BASE/n,out/n)
for n in ('extremal_selector_probe','tail_budget_check'):
 with (out/(n+'.log')).open('w') as log:subprocess.run([sys.executable,str(out/(n+'.py'))],check=True,stdout=log,stderr=subprocess.STDOUT)
 actual=json.loads((out/(n+'.json')).read_text());expected=json.loads((BASE/(n+'.json')).read_text())
 actual.pop('runtime',None);expected.pop('runtime',None)
 assert actual==expected,n
 print(n+': mathematical fields reproduce')
print('PASS; finite evidence only; external frozen local dependencies required')
