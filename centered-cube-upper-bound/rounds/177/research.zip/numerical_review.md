# R177 numerical review

The scope is three fixed receiver/input pairs and no source search. The exact frozen R175 JSON supplies positions and masses; nu/beta/f are unchanged. Stage1+2 use19+31 n4 radii and19 n16 radii; Stage3 adds8+9 n4 radii. All86 distinct case/radius pairs stay within the approved budget. Left-limit branches reuse these radii. The baseline radius equals the existing completion-face selector (.9 symmetric, .898 asymmetric), avoiding an unnecessary extra asymmetric radius.

The fixed-H power coefficients and nonnegative Bernstein coefficients are independently constructed by polynomial multiplication: power uses [hard,phi-hard], Bernstein uses [hard,phi]. The latter coefficients have no missing binomial factor: coefficient k is the sum over all size-k choices of smoothing coordinates. Their latent posterior weights sum to1 within the recorded precision, and D/F=n s-E[N] and the tilted-F mgf identity are recorded as residuals. Positive theta always tilts s upward within the legal domain. At upper s1, all latent mass is at N=n and the Binomial mgf comparison is equality; a mean-one Poisson envelope is only reported at the lower endpoint. All inequalities from this high-precision maximization are labeled numerical rather than interval proofs.

The n4 cubic critical-partition routine uses recursive derivative critical points, endpoint/tangent tolerance checks and bisection of sign changes. This is a bounded high-precision optimizer, not rigorous polynomial root isolation. Every candidate root and its residual is retained. No selected root is interior in these cases. Symmetric n16 uses the actual repeated-factor convexity, not an unverified numerical high-degree optimization. The50/80-digit comparison only refines selected radii; it does not certify the full scale interval.

The smooth scale derivative is computed by differentiating each product factor with hard masks fixed: its coordinate contribution is minus the factor minus s*z*phi'(z), with phi'(z)=w(z+.5)-w(z-.5). The overall H^-n derivative is included exactly once by the minus-factor term in each coordinate. At hard faces, closed and left-limit masks are separately constructed. A positive same-softness value jump certifies the numerical nondifferentiability diagnosis; it must not be converted into Euler stationarity. All selected faces show a large jump, with nonzero smooth right-branch slope.

The hard maximum uses Fractions at all physical hard faces and window endpoints. This is exact for the fixed atomic hard convolution because it decreases between faces. The inequality hardmax<=e*finite_soft_max has a direct structural reason: every hard candidate radius appears in the soft menu and the lower endpoint gives F(s0,H)>=e^-1 hardF(H). The two selected n4 comparisons are additionally enclosed with directed intervals; no numerical exponential approximation is used for that certificate.

For the two selected n4 points, existing frozen R168/R166 directed Decimal kernels compute q and partial_s F at N128/256. The true irrational s0 is enclosed by1-exp_interval(-1/n), and all softness-dependent factors propagate that interval. The D_s<=n s0 q and hardmax<=e q margins have positive lower endpoints at both resolutions. Their certificate scope is the selected physical point only, independent of the numerical global-soft/max-H assertion. No new interval library, quadrature or software installation is used.

There is no dx integration here. Atomic hard-face jumps, missing continuum scale optimization, and absent original history/L1 eligibility remain explicit limitations. Finite success supports investigating the selector/latent route and confirms the need to retain a scale-face term; it does not pay the general target.

## Reproducibility replay

Copied the final script and unchanged contract to `/tmp/r177_receiver_review/` and ran once. After removing only the runtime object, every JSON field matches exactly, including physical inputs, all soft candidates, face left limits, raw N128/256 endpoints and dependency hashes. No additional radii or receivers were evaluated.

## Exact tail-budget replay

Independently read the parent `tail_budget_check.py`, copied it to `/tmp/r177_tail_review/`, and ran the copy. All34 Fraction checks pass and the entire JSON matches exactly. Only this review file was updated; the selector probe artifacts remain frozen.

The threshold delta=epsilon/(C*n), with C=(32/3)*(128/119), conservatively replaces the clock factor log2 by1. Thus C*n*tail<=epsilon also pays C*n*log2*tail. For latent mean lambda<=1 and k>=3, the Poisson-Chernoff expression exp(-lambda)*(e*lambda/k)^k is at most(e/k)^k, hence at most(3/k)^k by e<3. The script finds a sufficient k with exact rational arithmetic, without claiming minimality after an empty-support shortcut.

The fixed theta=log2 branch correctly uses exp(-theta*k)*(1-s+s*exp(theta))^n=(1+s)^n/2^k. It checks the smallest nonempty k passing the rational threshold when such a k exists. If k>n, the latent count has support at most n, so the tail is exactly0; the code does not mistake a failed mgf threshold for a paid nonempty tail. These are finite constant/threshold checks conditional on the separately proved mgf and raw domination, not a new proof of those inputs.
