# R177 extremal softness/scale diagnostic

All three fixed-input finite-menu winners occur at the lower softness endpoint and at the completion atom's hard face. Their smooth right-branch scale derivatives are nonzero. Thus these atomic cases support the soft endpoint condition while directly demonstrating why a scale Euler equality cannot be imposed at their selected face. They do not certify a continuum scale maximum or a global bound.

Run `python3 extremal_selector_probe.py` from any directory. The script reads only the two frozen R175 inputs, the existing interval kernel and the local task contract. Dependency hashes and raw interval endpoints are in JSON. No new software, integration, source families or receiver grids are used.

## Inputs and bounded stages

Keep exactly the R175 common atomic f=beta>=nu. For n4/n16, nu=(3/25)delta_(.525^n)+(22/25)delta_(-.9^n), with outer y=-.4/-.35 of mass2^-32 and completion r=.45 of the frozen mass. These masses/positions are read from the frozen JSON, rather than refitted. Set c=1, s0=1-exp(-1/n), and H in[.5,1]. The proposed selector is a new construction; its source/history eligibility is not inherited from R175.

1. n4 x=0: H endpoints and hard faces {.5,.8,.9,1}, plus5 equally spaced points in each open interval:19 radii.
2. n4 x=(.001,.002,.002,.002): H endpoints and hard faces {.5,.802,.804,.896,.898,1}, plus5 interior points per interval:31 radii. n16 x=0 uses19 radii with faces .7/.9 and endpoints .5/1. The n16 receiver is only a lightweight comparison.
3. Refine the immediate sampled neighborhood of each n4 winner with at most9 additional interior H values. Deduplication adds8 and9, for67 n4 radii in total. Reevaluate each selected H and the old-softness baseline at80 decimal digits, after a50-digit screen. Only the two n4 selected points receive N128/256 interval coefficient checks. The final screen took0.319s and the total run2.905s; the120s prescreen cap is enforced. Face left limits reuse existing radii and do not expand the menu.

At each fixed H, compute the physical polynomial

`F(u,H,x)=sum_z mass_z H^-n product_i[h_i+(phi_i-h_i)u]`.

For n4, recursively partition the cubic derivative at its critical points, bisect sign changes, and compare all numerical real stationary points in[s0,1] with both endpoints. The coefficients are physical high-precision kernel values, not exact rational coefficients. Root locations/completeness are not interval-certified. At symmetric x0 every atom has one repeated affine factor; its second derivative is nonnegative on the legal soft interval, so convexity proves endpoint sufficiency. This avoids degree15 root finding for n16.

All67 n4 and19 n16 fixed-H winners are soft endpoints; there are no interior winning soft roots. The n4 counts are27 lower-s0 and40 upper-1; n16 counts are10 and9. Interior roots are still retained, including their residuals (largest n4 absolute residual below9e-53). No root grid is used to infer an exponent or a continuum H optimum.

## Selected values and face obstruction

| Case | Selected H | Selected softness | q | New q / old-soft q | Smooth dlogH F/q |
|---|---:|---|---:|---:|---:|
|n4 symmetric|.9|s0≈.2211992|.0068468760044|1.0845524|−3.5595678|
|n4 asymmetric|.898|s0≈.2211992|.0069130359859|1.0844370|−3.5635744|
|n16 symmetric|.9|s0≈.06058694|.00015621305743|7.7195282|−15.5714503|

The old comparison uses softness1/4 at the existing completion-face selector radius: .9 for symmetric receivers and .898 for the asymmetric receiver. Its inputs are otherwise identical.

The jump at each winning H is positive even when softness is held at the closed-side winner. The same-softness jumps are approximately .00683860, .00621628 and .0001562123. Optimizing the left-limit softness separately gives smaller, still positive jumps .00338913, .00343683 and .0001561998. Both the exact left hard mask and the closed hard mask are evaluated; a small H perturbation is not substituted for a left limit. The table's derivative is the smooth branch derivative with the closed hard mask held fixed. None is a derivative across the jump. Scale Euler equality is explicitly never asserted, even at a nonface finite-menu winner.

The original hard-window maximum for these atomic inputs is computed exactly with Fractions: hard convolutions decrease as H^-n between the finitely many hard faces. All hard-max radii are included in the soft menu. Consequently hardmax<=e times the finite soft maximum follows structurally from `(1-s0)^n=e^-1`, without requiring a continuum soft optimum. The numerical ratios hardmax/(e newq) are .655971, .655500 and .671811. Directed checks also certify this comparison at both n4 selected points.

## Soft descent and latent count

Compute the signed descent `D_s=-s(1-s) partial_s F`. At the selected lower endpoints, D_s/(n s0 q) is .544331, .543620 and .594721, respectively. The two n4 N256 enclosures give strictly positive margins for n s0 q-D_s: approximately .00276048 and .00279151. The interval softness is the outward enclosure `1-exp_interval(-1/n)`, propagated through every factor. A rounded decimal is not treated as exact s0. These are coefficient/derivative certificates at selected physical points, not certificates of scale optimization.

The unnormalized nonnegative Bernstein coefficients B_k retain the physical latent smoothing count N. Its posterior weights are `B_k s^k(1-s)^(n-k)/F`. The code checks both the signed identity `D_s/F=n s-E[N]` and, for theta=.1,1,3,

`E exp(theta N)/(1-s+s exp(theta))^n = F(s exp(theta)/(1-s+s exp(theta)))/F(s)`.

The tilted softness remains in[s0,1]. At a true fixed-H global soft maximum, the right side is at most1 by algebra; no scale optimality is required. Here this comparison is numerical because the n4 soft maximization uses high-precision roots. All recorded comparisons pass, including upper-1 equality cases. At the three selected lower endpoints the mgf/Binomial ratios for theta=.1/1/3 are approximately (.9515,.5353,.3386), (.9515,.5357,.3378), and (.9414,.3972,.002144). Poisson-Chernoff tails at k2 and k4, and the lower-endpoint mean-one Poisson mgf envelope, are also recorded; they are finite numerical checks, not an independent proof of the latent theorem.

The decision is narrow: the soft KKT/latent route survives these known physical pressures, whereas exact scale-face selection requires face handling. This probe does not establish the new selector's weak estimate, transfer old eligibility/history, smooth atomic jumps, integrate a receiver measure, or pay the original lowcapture companion and j sum.
