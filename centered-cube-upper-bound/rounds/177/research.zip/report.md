# R177：极值来源计数与原交通越界上尾付款

一般 n^(1/2+o(1)) 一致弱型上界仍未闭合。本轮得到一项接回原交通的明确付款，而非只换记号：原单侧 continuum FIRST 导出的来源越界上尾，在完整 beta 外来源槽上的正 raw ≤epsilon E∫q dx。剩余低越界补集继续保留。

## 本轮实质结论

1. 对当前混合核与同一完整输入f的实际加权来源，增广soft子集标签K。FIRST精确给E exp(theta K)≤(1−s+s exp(theta))^n，theta≥0；不假设f后验坐标独立。物理来源越出当前硬cube的坐标数m≤K，所以有准确Chernoff阈值k_delta(n,s)。
2. 在原R_eta/lowcapture补集中切m≥k_delta。原A≤1、计数差≤n、时长≤log2，以及原唯一j指示、共同kernel、sum beta≤f，使尾支费用≤(32Lambda/3)nlog2 delta E∫q。取明确delta即epsilon价。完整beta=nu+zeta两槽覆盖，不借signed负信用，不重复旧分支。s接近1时阈值可能n+1，尾支为空，不宣称补集总是低维。
3. 在另行构造的联合global-soft极值上，soft下降缺陷≤cq；内部soft极值的latent K均值ns、方差≤ns(1−s)。下端s0=1−e^-c/n的尾阈值有解析logn/loglogn范围，适用条件明确。新selector支配一般hard窗口sup，但其与旧history/source兼容及新sup的弱型界未证明。
4. 正Duhamel增长保留(H/L)^n后获得全窗q价；把一份原p_y换成它后，余下三点乘子完整写在EF10，尚未支付。硬面贡献、上端尺度、尖点缺陷和自适应soft范数费用不消失。

核心详细证明在extremal_face_budget.md OT1–5、soft_extremal_variation.md SE1–20、measurable_extremal_reduction.md与proof.tex.txt。可测选择采用当前compact矩形族的自含嵌套闭盒证明，不凭M04中尚未验收的一般定理名。

## 数值及复现

固定R175原输入，三阶段只检查67个n4尺度与19个n16尺度，未新扫函数族或receiver网格。每个固定尺度比较soft端点与数值三次驻点；三个最高候选都在s0和completion硬面。尺度的光滑右支导数非零、硬面跳严格正，明确禁止对原子选中尺度直接套Euler=0。两n4点N128/256定向区间核值/soft下降/硬max支配检查通过，非全尺度优化证书。

全部记录的theta=.1,1,3 latent mgf比较通过。另34项Fraction精确检验验证有限n/s阈值及epsilon费用常数；初探、已有边界压力、扩大维度均有记录。均值≤1时的保守有理阈值由e<3得到，不拟合阶数。

父级完整阅读实现，在仓库外迁移运行两脚本，非runtime字段全部一致；数值Agent独立复现父级Fraction检查。所有有限数值证据都不代替一般证明。原子模型、有限H菜单、数值根未区间隔离的限制完整保留。未编译PDF。

## 准确剩余目标与下一步

原lowcapture交通现在可先删掉已付外来源高越界尾，再在m<k_delta的真实来源几何中处理EF10三点乘子。这里m以x−y定义，原k_t由y−v定义，不能混同；即便y在当前cube内，v仍可在许多坐标与y分离。baseline、Hhat>L、两个外槽、原window/history和所有selector费用必须一起支付。

本轮没有证明一般根阶预算，没有把newglobal selector直接替换旧结构。下一步应对低越界补集的共同来源空间关系构造可核验的覆盖/transport估计，而不是重新丢掉门取线性正包络。

仅使用4个已有Agent（Astra high、Sol high两名、Sol medium一名），没有为凑数启动Luna。M04用于可测选择条件，H05用于已证明mgf上的Markov和合法参数优化，N04保留累计费用；没有引用未经阅读的外部定理。没有实际扣额明细，不估算模型成本比。
