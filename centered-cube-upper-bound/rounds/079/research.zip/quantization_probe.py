#!/usr/bin/env python3
"""Genuine E2 finite-noise quantization diagnostics plus exact error algebra.

Numerical E2 weights and scalar/tensor evaluations are diagnosed, not interval
certified. Exact Fraction guards verify tensor identities and fee allocation.
The finite quantized kernel is never assumed ray decreasing: only its positive
error majorants have that analytic property. Python standard library only.
"""
from fractions import Fraction as F
from bisect import bisect_left,bisect_right
from pathlib import Path
from functools import lru_cache
from itertools import product
import json, math, random, time

SEED=790611


def clean(x):
    if isinstance(x,F): return str(x)
    if isinstance(x,dict): return {str(k):clean(v) for k,v in x.items()}
    if isinstance(x,(tuple,list)): return [clean(v) for v in x]
    return x


class E2:
    def __init__(self,panels):
        assert panels%2==0
        self.panels=panels; self.endpoint=1/(3*panels)
        self.grid=[(i/panels,(1 if i==panels else 4 if i%2 else 2)/(3*panels)) for i in range(1,panels+1)]

    @lru_cache(None)
    def w(self,x):
        x=abs(float(x))
        if not x:return 1.
        return sum(c*math.exp(-x/s) for s,c in self.grid)

    @lru_cache(None)
    def phi(self,x):
        x=abs(float(x))
        if x<=.5:
            return 1-sum(c*s*(math.exp(-(.5-x)/s)+math.exp(-(.5+x)/s)) for s,c in self.grid)
        return sum(c*s*(-math.expm1(-1/s))*math.exp(-(x-.5)/s) for s,c in self.grid)

    def cell(self,lo,hi):
        assert 0<=lo<hi
        return sum(c*s*math.exp(-lo/s)*(-math.expm1(-(hi-lo)/s)) for s,c in self.grid)

    def tail(self,R):return 2*sum(c*s*math.exp(-R/s) for s,c in self.grid)


class QuantizedNoise:
    def __init__(self,h,R,panels):
        self.h,self.R=F(h),F(R); assert self.h>0 and self.R>=1 and (self.R/self.h).denominator==1
        self.M=int(self.R/self.h); self.actual=E2(panels)
        self.cells=[self.actual.cell(float(j*self.h),float((j+1)*self.h)) for j in range(self.M)]
        self.pR=self.actual.tail(float(self.R))
        pairs=[(F(0),2*self.cells[0]+self.pR)]
        for j in range(1,self.M):pairs.extend([(-j*self.h,self.cells[j]),(j*self.h,self.cells[j])])
        pairs.sort(); self.atoms=[p for p,_ in pairs]; self.weights=[w for _,w in pairs]
        self.prefix=[0.]
        for w in self.weights:self.prefix.append(self.prefix[-1]+w)
        self.mass=sum(self.weights)
        assert all(w>0 for w in self.weights) and abs(self.mass-1)<2e-12

    def q(self,z):
        z=F(z)
        if abs(z)>self.R:return F(0)
        return (1 if z>=0 else -1)*self.h*(abs(z)//self.h)

    @lru_cache(None)
    def phi_q(self,x):
        x=F(x)
        lo=bisect_left(self.atoms,x-F(1,2));hi=bisect_right(self.atoms,x+F(1,2))
        return self.prefix[hi]-self.prefix[lo]

    @lru_cache(None)
    def error(self,x):
        x=abs(float(x));h=float(self.h);R=float(self.R)
        return 4*h*self.actual.w(max(0.,x-.5-h))+self.pR*float(x<=.5)+self.actual.phi(max(x,R-.5))

    def mass_upper(self):
        h=float(self.h);R=float(self.R)
        return 8*h*(1+h)+math.exp(-R)+(2*R+1)*math.exp(1-R)

    def envelope_mass_diagnostic(self):
        h=float(self.h);R=float(self.R);boundary=R-.5
        tail_phi=sum(c*s*s*(-math.expm1(-1/s))*math.exp(-(R-1)/s) for s,c in self.actual.grid)
        return 8*h*(1+h)+self.pR+2*boundary*self.actual.phi(boundary)+2*tail_phi


def scalar_case(h,R,panels):
    q=QuantizedNoise(h,R,panels); points={F(0),F(1,2),-F(1,2),q.R,-q.R,q.R+F(1,2),-q.R-F(1,2),q.R+1,-q.R-1}
    tiny=q.h/1024
    for z in q.atoms:
        for x in (z-F(1,2),z+F(1,2)):
            points.update((x-tiny,x,x+tiny))
    points.update(q.h*F(2*j+1,2) for j in range(-q.M,q.M))
    minimum_margin=float('inf'); maximum_error=0.; maximum_ratio=0.; worst=None
    for x in sorted(points):
        original=q.actual.phi(float(x)); finite=q.phi_q(x); error=abs(finite-original); envelope=q.error(x)
        margin=envelope-error; assert margin>=-2e-11
        minimum_margin=min(minimum_margin,margin);maximum_error=max(maximum_error,error)
        if error/envelope>maximum_ratio:
            maximum_ratio=error/envelope;worst=dict(x=x,phi=original,phi_q=finite,error=error,envelope=envelope,margin=margin)
    # Exact mapping algebra on representative within-cell and tail points.
    mapping=0
    for j in range(q.M):
        for sign in (-1,1):
            z=sign*(j*q.h+q.h/3); image=q.q(z)
            assert abs(image)<=abs(z) and abs(z-image)<=q.h and abs(image)<=q.R
            mapping+=1
    for z in (-q.R,-q.R-q.h,q.R,q.R+q.h):
        image=q.q(z);assert abs(image)<=abs(z)
        if abs(z)>q.R:assert image==0
        mapping+=1
    envelope_mass=q.envelope_mass_diagnostic();assert envelope_mass<=q.mass_upper()+2e-12
    qmoment=sum(float(abs(z))*w for z,w in zip(q.atoms,q.weights));assert qmoment<=2/3+2e-12
    return q,dict(h=q.h,R=q.R,s_panels=panels,positive_probability_atom_count=len(q.atoms),
                   possible_mapping_grid_count=2*q.M+1,
                   probability_mass_diagnostic=q.mass,tail_probability_diagnostic=q.pR,
                   exact_probability_reason='2*sum_j integral_jh^((j+1)h) w + p_R = integral_{abs(z)<=R} w + p_R = 1; atom at zero includes both j=0 signs and tails.',
                   atom_weight_formula='positive j>=1: integral_0^1 s*exp(-j*h/s)*(1-exp(-h/s)) ds; zero: 2*cell(0,h)+p_R',
                   actual_noise_formula='w(z)=integral_0^1 exp(-abs(z)/s) ds; p_R=2*integral_0^1 s*exp(-R/s) ds',
                   sample_points=len(points),sample_recipe='All atoms +/-1/2 cube endpoints and neighbors +/-h/1024, cell midpoints, origin, R, R+1/2, R+1 and sign reflections.',
                   maximum_scalar_error=maximum_error,minimum_envelope_margin=minimum_margin,maximum_error_over_envelope=maximum_ratio,
                   worst_ratio_witness=worst,pointwise_envelope_mass_upper_diagnostic=q.mass_upper(),
                   envelope_mass_diagnostic=envelope_mass,quantized_first_absolute_moment_diagnostic=qmoment,
                   actual_first_absolute_moment=F(2,3),
                   envelope_formula='4h*w((abs(x)-1/2-h)_+) + p_R*h0(x) + phi(max(abs(x),R-1/2))',
                   exact_quantizer_mapping_checks=mapping,quantized_probability_preserved_analytically=True,
                   quadrature_certificate=False)


def stage1():
    cases=[]; objects=[]
    for h,R,N in ((F(1,16),F(2),256),(F(1,32),F(4),512),(F(1,64),F(6),1024)):
        q,record=scalar_case(h,R,N);objects.append(q);cases.append(record)
    # A grid not dividing the hard window length can cause genuine upward
    # staircase jumps. The compensation proof must use the monotone e envelope.
    nonmono=QuantizedNoise(F(3,64),F(3),1024)
    x=F(1,16); tiny=nonmono.h/1024
    left=nonmono.phi_q(x-tiny);right=nonmono.phi_q(x+tiny)
    assert right>left
    return objects,dict(status='DIAGNOSTIC_PASS',scope='Genuine E2 positive noise-cell formulas evaluated by Simpson; scalar endpoint and mesh/tail refinements. Numerical weights are not outward-rounded certificates.',
                        cases=cases,nonmonotone_quantized_kernel_example=dict(h=nonmono.h,R=nonmono.R,x=x,neighbor_offset=tiny,left_value=left,right_value=right,upward_jump=right-left),
                        monotonicity_policy='phi_q may fail ray monotonicity; only e and the positive tensor majorants are used as ray-decreasing kernels.')


def H(x):return F(int(abs(F(x))<=F(1,2)))


def tensor_endpoint(q,v,a):
    a=float(a);base=upper=finite=1.
    for x in v:
        h=float(H(x));p=q.actual.phi(float(x));e=q.error(x);pq=q.phi_q(x)
        psi=(1-a)*h+a*p;psiq=(1-a)*h+a*pq
        base*=psi;finite*=psiq;upper*=psi+a*e
    majorant=max(0.,upper-base)
    assert abs(finite-base)<=majorant+2e-11
    return base,finite,majorant


def stage2(objects):
    cases=[]
    for mesh,q in enumerate(objects):
        for n in (1,2,3):
            ys=[tuple(F(0) for _ in range(n)),tuple(F(1 if j%2==0 else -1,4) for j in range(n)),tuple(F(-3,8) for _ in range(n))]
            weights=[F(1,5),F(3,10),F(1,2)];signs=[F(-1),F(1,3),F(1)]
            coordinates=(F(-1),F(-1,2),F(-1,4),F(0),F(1,4),F(1,2),F(1))
            for delta in (F(1),F(1,2),F(1,16),F(1,256)):
                rows=0;max_error=0.;minimum_margin=float('inf');worst=None;positive=0
                for x in product(coordinates,repeat=n):
                    choices=[]
                    for L in (F(1),F(3,2),F(2)):
                        true=finite=majorant=0.
                        for y,w,sign in zip(ys,weights,signs):
                            v=tuple((xx-yy)/L for xx,yy in zip(x,y))
                            a,aq,ae=tensor_endpoint(q,v,delta/2);b,bq,be=tensor_endpoint(q,v,delta)
                            true+=float(w*sign)*(a-b)/float(L**n)
                            finite+=float(w*sign)*(aq-bq)/float(L**n)
                            majorant+=float(w)*(ae+be)/float(L**n)
                        choices.append((abs(true),L,true,finite,majorant))
                    # Keep the ORIGINAL true contrast's selector for all values.
                    _,L,true,finite,majorant=max(choices,key=lambda z:(z[0],-z[1]))
                    error=abs(finite-true);margin=majorant-error;assert margin>=-4e-11
                    rows+=1;positive+=int(majorant>0);minimum_margin=min(minimum_margin,margin)
                    if error>max_error:
                        max_error=error;worst=dict(x=x,L=L,original_signed_contrast=true,finite_signed_contrast=finite,error=error,positive_majorant=majorant)
                prior_mass=((1-float(delta))+float(delta)*q.mass)**n
                assert abs(prior_mass-1)<2e-11
                cases.append(dict(mesh_index=mesh,n=n,delta=delta,source_positions=ys,source_mu=weights,
                                  source_nu=[w*s for w,s in zip(weights,signs)],physical_scale_family=[F(1),F(3,2),F(2)],
                                  selector='First maximizer of absolute original actual-E2 signed contrast; same selector applied to quantized contrast and error envelope.',
                                  receiver_grid_coordinates=coordinates,receiver_rows=rows,positive_majorant_rows=positive,
                                  maximum_contrast_error=max_error,minimum_majorant_margin=minimum_margin,worst_error_witness=worst,
                                  quantized_soft_product_probability_diagnostic=prior_mass,
                                  finite_noise_state_count_power=n,one_coordinate_noise_state_count=2*q.M+1,
                                  grid_representation='Implicit coordinate product; no full tensor noise grid materialized.',
                                  quadrature_certificate=False))
    return dict(status='DIAGNOSTIC_PASS',scope='Actual finite signed sources, actual E2 kernels, genuine finite q-noise law, common original physical selector. Scalar weights and function integrals remain quadrature diagnostics.',
                cases=cases,case_count=len(cases),receiver_rows=sum(c['receiver_rows'] for c in cases))


def log2_interval(terms=30):
    z=F(1,3);power=z;total=F(0)
    for j in range(terms):total+=2*power/(2*j+1);power*=z*z
    return total,total+2*power/((2*terms+1)*(1-z*z))


def stage3():
    rng=random.Random(SEED);checks=0;witnesses=[]
    for n in (1,2,3):
        for a in (F(1),F(1,2),F(1,16),F(1,256)):
            for _ in range(24):
                h=[F(rng.randrange(2)) for _ in range(n)]
                phi=[F(rng.randrange(17),16) for _ in range(n)]
                errors=[F(rng.randrange(1,5),32) for _ in range(n)]
                phi_q=[max(F(0),p+e*F(rng.randrange(-4,5),4)) for p,e in zip(phi,errors)]
                assert all(abs(pq-p)<=e for pq,p,e in zip(phi_q,phi,errors))
                base=[(1-a)*z+a*p for z,p in zip(h,phi)]
                finite=[(1-a)*z+a*p for z,p in zip(h,phi_q)]
                additions=[a*e for e in errors]
                majorant=math.prod(b+e for b,e in zip(base,additions))-math.prod(base)
                expansion=sum(math.prod(additions[i] if mask>>i&1 else base[i] for i in range(n)) for mask in range(1,1<<n))
                actual_error=abs(math.prod(finite)-math.prod(base))
                assert majorant==expansion and actual_error<=majorant;checks+=1
                if all(w['n']!=n for w in witnesses):
                    witnesses.append(dict(n=n,a=a,h=h,phi_surrogate_values=phi,phi_q_surrogate_values=phi_q,
                                          scalar_error_bounds=errors,exact_tensor_error=actual_error,exact_positive_majorant=majorant))
    ln2=log2_interval();mass_cases=[];fee_cases=[];levels=10
    partial=sum(F(1,2**s) for s in range(levels));tail=F(1,2**(levels-1))
    assert partial+tail==2
    for n in (1,2,3,8,16,64):
        for E in (F(1,16*n),F(1,4*n),F(1,n)):
            assert n*E<=1
            for a in (F(1),F(1,2),F(1,16),F(1,256)):
                mass=(1+a*E)**n-1;bound=3*n*a*E
                assert 0<=mass<=bound
                mass_cases.append(dict(n=n,E=E,a=a,positive_tensor_error_mass=mass,mass_bound=bound,exact_mass_bound_verified=True))
            finite_mass=sum((1+F(1,2**(s+1))*E)**n-1+(1+F(1,2**s)*E)**n-1 for s in range(levels))
            finite_bound=F(9,2)*n*E*partial;tail_bound=F(9,2)*n*E*tail
            assert finite_mass<=finite_bound and finite_bound+tail_bound==9*n*E
            envelope=(1+n*ln2[0],1+n*ln2[1])
            all_fee=(9*n*E*envelope[0],9*n*E*envelope[1])
            fee_cases.append(dict(n=n,E=E,condition_nE=n*E,explicit_dyadic_levels=levels,
                                  finite_actual_majorant_mass_sum=finite_mass,finite_mass_sum_upper=finite_bound,
                                  infinite_remaining_mass_upper=tail_bound,all_layer_majorant_mass_upper=9*n*E,
                                  finite_delta_sum=partial,infinite_remaining_delta_sum=tail,
                                  all_layer_maximal_error_fee_interval=all_fee,
                                  finite_physical_grid_count_factor=F(1),fee_independent_of_physical_grid_count=True))
    warning=[]
    for eps in (F(1,16),F(1,256),F(1,65536)):
        spacing=eps/2;count=int(F(1,4)/spacing)+1;tests=[]
        for x in (F(3,4),F(13,16),F(7,8),F(15,16),F(1)):
            index=(x-F(3,4))//spacing;center=F(3,4)+index*spacing;L=2*center-eps
            assert 1<=L<=2
            difference=abs(H((x-eps)/L)-H(x/L))/L
            assert difference>=F(1,2)
            tests.append(dict(x=x,L=L,kernel_difference=difference))
        # Nearest grid center is within eps/4. Its interval of discrepancy
        # is (center-eps/2,center+eps/2], covering [3/4,1].
        for center in (F(3,4),F(1)):
            L=2*center-eps;assert 1<=L<=2
            for offset in (-eps/4,F(0),eps/4):
                x=center+offset;assert H(x/L)==0 and H((x-eps)/L)==1
        warning.append(dict(epsilon=eps,source_before='delta_0',source_after='delta_epsilon',
                            physical_grid_formula='L_j=2*(3/4+j*epsilon/2)-epsilon; j=0..1/(2epsilon)',physical_grid_count=count,
                            receiver_interval=[F(3,4),F(1)],nearest_center_distance_bound=eps/4,
                            pointwise_maximum_difference_lower=F(1,2),strong_L1_maximum_difference_lower=F(1,8),
                            fixed_L1_scale_difference_integral=2*eps,exact_receiver_tests=tests,
                            scope='Actual hard H kernels; physical family refines with epsilon. Warns against a grid-count-uniform strong return from source weak convergence, not the E2 noise-quantization estimate.'))
    return dict(status='EXACT_VERIFIED',scope='Exact positive tensor error and dyadic fee algebra, conditional on unit scalar kernel mass and the parent ray-envelope payment. Generic rational scalar values do not certify numerical E2 integration.',
                seed=SEED,positive_tensor_cases=checks,saved_rational_tensor_witnesses=witnesses,
                positive_majorant_formula='product_i(psi_a(x_i)+a*e(x_i))-product_i psi_a(x_i)',
                positive_majorant_mass_formula='(1+a*E)^n-1 <= 3*n*a*E when n*E<=1, 0<=a<=1',
                majorant_ray_reason='psi_a and e are nonnegative even and coordinatewise decreasing; the difference is expanded as a positive sum of product kernels.',
                scalar_error_mass_bound_formula='E <= 8*h*(1+h)+exp(-R)+(2*R+1)*exp(1-R)',
                mass_cases=mass_cases,dyadic_fee_cases=fee_cases,log2_interval=ln2,
                all_layer_fee_formula='9*n*(1+n*log2)*E*W; no physical-grid-count multiplier',
                fee_normalization='W=1; multiply linearly by arbitrary source mass W',
                source_atom_shift_warning=warning)


def main():
    start=time.monotonic();objects,first=stage1()
    print('stage1 scalar_cases',len(first['cases']),'samples',sum(c['sample_points'] for c in first['cases']),'seconds',round(time.monotonic()-start,3),flush=True)
    second=stage2(objects)
    print('stage2 actual_tensor_cases',second['case_count'],'receiver_rows',second['receiver_rows'],'seconds',round(time.monotonic()-start,3),flush=True)
    third=stage3()
    out=dict(status='PASS_WITH_SCOPE_LABELS',dependencies='Python standard library only',seed=SEED,
             stage1=first,stage2=second,stage3=third,
             counts=dict(scalar_mesh_tail_cases=len(first['cases']),scalar_point_samples=sum(c['sample_points'] for c in first['cases']),
                         actual_tensor_cases=second['case_count'],actual_tensor_receiver_rows=second['receiver_rows'],
                         exact_tensor_cases=third['positive_tensor_cases'],exact_mass_cases=len(third['mass_cases']),exact_dyadic_fee_cases=len(third['dyadic_fee_cases']),
                         exact_source_shift_warning_cases=len(third['source_atom_shift_warning'])),
             limitations=['Actual E2 scalar weights, densities and physical-input checks are floating quadrature diagnostics.',
                          'Quantization preserves probability analytically; numerical weights are not rational interval certificates.',
                          'phi_q is not assumed ray decreasing.',
                          'Stage3 certifies conditional algebra, not the actual scalar E2 quadrature error.',
                          'No full-band coverage or completed cube-bound claim.'])
    target=Path(__file__).with_name('quantization_results.json');target.write_text(json.dumps(clean(out),indent=2,sort_keys=True)+'\n')
    print('DONE',out['counts'],'seconds',round(time.monotonic()-start,3),'bytes',target.stat().st_size,flush=True)


if __name__=='__main__':main()
