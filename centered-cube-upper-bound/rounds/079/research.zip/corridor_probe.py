#!/usr/bin/env python3
"""R79 actual common-source E2 age decomposition diagnostics.
Only rational gate geometry is exact. Phi quadrature, finite prior sampling,
physical dx importance estimates and finite-latent maxima are diagnostics.
"""
from fractions import Fraction as Q
from pathlib import Path
from functools import lru_cache
import math,random,json,time,hashlib,itertools

def clean(o):
 if isinstance(o,Q):return str(o)
 if isinstance(o,dict):return {str(k):clean(v) for k,v in o.items()}
 if isinstance(o,(tuple,list)):return [clean(v) for v in o]
 return o

def interval(d,z,exact=False):
 lo=Q(0) if exact else 0.;hi=None;half=Q(1,2) if exact else .5
 for v,w in zip(d,z):
  p,q=w-half,w+half
  if p>0:hi=v/p if hi is None else min(hi,v/p)
  elif p<0:lo=max(lo,v/p)
  elif v<0:return None
  if q>0:lo=max(lo,v/q)
  elif q<0:hi=v/q if hi is None else min(hi,v/q)
  elif v>0:return None
 if hi is not None and (hi<lo or hi<=0):return None
 return (lo,hi)

def member(I,L):return I is not None and I[0]<=L and (I[1] is None or L<=I[1])

def geometry_guard():
 checks=0;age=0;rng=random.Random(79019)
 for n in (1,2,4,8,16):
  for _ in range(20):
   d=[Q(rng.randrange(-12,13),8) for j in range(n)];z=[Q(rng.randrange(-12,13),8) for j in range(n)];I=interval(d,z,True)
   for L in (Q(1,4),Q(1,2),Q(1),Q(3,2),Q(2),Q(4)):
    assert member(I,L)==all(abs(dj/L-zj)<=Q(1,2) for dj,zj in zip(d,z));checks+=1
    if I and member(I,L):
     # Full-log and half-log choices: compare rational powers, no root rounding.
     A,B=I
     for power,multiplier in ((n,n+2),(2*n,n)):
      old=multiplier*A**power<=L**power
      if old:
       assert B is None or L**power<=multiplier*B**power
       age+=1
 return dict(status='PASS',gate_membership_checks=checks,old_before_gate_implications=age,scope='Exact rational machine-independent finite geometry fixtures; not continuous E2 integration.')

@lru_cache(maxsize=300000)
def phi_tail(u,M=64):
 u=abs(float(u))
 if u==0:return .5
 def f(t):
  if not t:return 0.
  if u>=.5:return t*t*math.exp(-((u-.5)/t))*(-math.expm1(-1/t))
  return 2*t*(.5-u)+t*t*(math.exp(-(.5-u)/t)-math.exp(-(u+.5)/t))
 return (f(0)+f(1)+sum((4 if j%2 else 2)*f(j/M) for j in range(1,M)))/(3*M)

def phi_integral(lo,hi,M=64):
 if lo>=0:return phi_tail(lo,M)-phi_tail(hi,M)
 if hi<=0:return phi_tail(-hi,M)-phi_tail(-lo,M)
 return 1-phi_tail(-lo,M)-phi_tail(hi,M)

def make_source(name,n,centers,widths,masses,W=Q(1)):
 return dict(name=name,n=n,centers=[tuple(map(Q,c)) for c in centers],halfwidths=list(map(Q,widths)),mass_fractions=list(map(Q,masses)),W=Q(W),scope='Positive mixture of normalized product boxes; L1 input, no atomic source substitution.')

def fixtures():
 base=[('pilot',make_source('one_box_n1',1,[(0,)],[Q(1,4)],[1]),Q(1,2),24,256),('pilot',make_source('one_box_n2',2,[(0,0)],[Q(1,4)],[1]),Q(1,2),32,256),('pressure',make_source('four_separated_n2',2,list(itertools.product((Q(-3,2),Q(3,2)),repeat=2)),[Q(1,8)]*4,[Q(1,4)]*4),Q(1,2),64,512),('pressure',make_source('correlated_two_n4',4,[(Q(-1,2),)*4,(Q(1,2),)*4],[Q(1,8),Q(1,4)],[Q(1,3),Q(2,3)]),Q(1,4),64,512),('expanded',make_source('unequal_micro_n4',4,[(Q(j,4),)*4 for j in range(-4,4)],[Q(1,32)]*8,[Q(j,36) for j in range(1,9)],Q(3)),Q(1,8),64,1024),('expanded',make_source('correlated_four_n8',8,[(Q(j,2),)*8 for j in(-2,-1,1,2)],[Q(1,8)]*4,[Q(1,10),Q(2,10),Q(3,10),Q(4,10)]),Q(1,8),64,1024)]
 endpoint=[]
 for i in (0,3,5):
  stage,src,a,R,S=base[i];src=dict(src,contrast_b=Q(0),name='endpoint_'+src['name'])
  R,S={0:(48,512),3:(96,1024),5:(128,2048)}[i]
  endpoint.append((stage,src,Q(1),R,S))
 legacy=dict(endpoint[-1][1],proposal_legacy_a_only=True,seed_index=8,name='endpoint_legacy_correlated_four_n8')
 return base+endpoint+[('endpoint_initial_pilot',legacy,Q(1),64,1024)]

def P(src,x,L,a,M=64):
 total=0.;L=float(L);a=float(a)
 for y,e,m in zip(src['centers'],src['halfwidths'],src['mass_fractions']):
  e=float(e);prod=1.
  for xx,yy in zip(x,y):
   d=xx-float(yy);hard=max(0.,min(d+e,L/2)-max(d-e,-L/2))/(2*e*L)
   soft=phi_integral((d-e)/L,(d+e)/L,M)/(2*e) if a else 0.
   prod*=((1-a)*hard+a*soft)
  total+=float(m)*prod
 return float(src['W'])*total

def noise(rng):
 t=math.sqrt(rng.random());return (1 if rng.random()<.5 else -1)*t*(-math.log(max(rng.random(),2**-53)))

def ydraw(src,rng):
 r=rng.random();idx=len(src['centers'])-1;acc=0.
 for j,m in enumerate(src['mass_fractions']):
  acc+=float(m)
  if r<acc:idx=j;break
 return [float(v)+(2*rng.random()-1)*float(src['halfwidths'][idx]) for v in src['centers'][idx]]

def receivers(src,a,R,seed):
 rng=random.Random(seed);out=[];scales=(Q(1),Q(3,2),Q(2));mix='contrast_b' in src and not src.get('proposal_legacy_a_only',False)
 for j in range(R):
  y=ydraw(src,rng);L=float(scales[rng.randrange(3)]);parameter=(a if rng.random()<.5 else src['contrast_b']) if mix else a
  x=[v+L*(rng.random()-.5+(noise(rng) if rng.random()<float(parameter) else 0.)) for v in y]
  parameters=(a,src['contrast_b']) if mix else (a,)
  q=sum(P(src,x,l,c) for l in scales for c in parameters)/(3*len(parameters)*float(src['W']));assert q>0
  out.append((x,q))
 return out

def latent_prior(src,S,seed):
 rng=random.Random(seed);return [(ydraw(src,rng),[rng.random() for _ in range(src['n'])],[noise(rng) for _ in range(src['n'])]) for j in range(S)]

def finite_path(src,x,a,prior):
 n=src['n'];a=float(a);b=float(src.get('contrast_b',a/2));r=(n+2)**(1/n);W=float(src['W']);S=len(prior);events={};total=old=0;properties=0
 def event(L,key,delta):
  if 1<L<=2:events.setdefault(L,[0,0,0,0])[key]+=delta
 # Keys total entry/exit, old entry/exit. Closed faces handled entry-before-exit.
 for y,U,Z in prior:
  d=[xx-yy for xx,yy in zip(x,y)]
  for parameter,sgn in ((b,1),(a,-1)):
   z=[zz if u<parameter else 0. for u,zz in zip(U,Z)];I=interval(d,z)
   if I is None:continue
   A,B=I;O=A*r
   if member(I,1):total+=sgn
   event(A,0,sgn)
   if B is not None:event(B,1,sgn)
   if B is None or O<=B:
    if O<=1 and (B is None or 1<=B):old+=sgn
    event(O,2,sgn)
    if B is not None:event(B,3,sgn)
    # Before-gate implication in machine geometry, checked at old entry/window start.
    L=max(1.,O)
    if L<=2 and (B is None or L<=B):
     before=L/r;assert member(I,before) or (abs(before-A)<1e-13 and (B is None or before<=B+1e-13));properties+=1
 best={k:dict(value=0.,L=1.,signed_count=0) for k in ('total','old','fresh')}
 def evaluate(L):
  for key,count in (('total',total),('old',old),('fresh',total-old)):
   value=W*abs(count)/(S*L**n)
   if value>best[key]['value']:best[key]=dict(value=value,L=L,signed_count=count)
 evaluate(1.)
 # Exit at L=1 belongs to initial closed value but disappears immediately after.
 for y,U,Z in prior:
  d=[xx-yy for xx,yy in zip(x,y)]
  for parameter,sgn in ((b,1),(a,-1)):
   I=interval(d,[zz if u<parameter else 0. for u,zz in zip(U,Z)])
   if I and I[1]==1:
    total-=sgn
    if I[0]*r<=1:old-=sgn
 evaluate(1.)
 for L,(te,tx,oe,ox) in sorted(events.items()):
  total+=te;old+=oe;evaluate(L)
  # Right limits matter for supremum; they are not claimed actual closed values.
  total-=tx;old-=ox
  if L<2:evaluate(L)
 assert best['total']['value']<=best['old']['value']+best['fresh']['value']+1e-12
 return dict(maxima=best,breakpoint_events=len(events),old_before_gate_checks=properties,scope='All machine-latent physical gate/age breakpoints enumerated, including right limits; finite prior diagnostic, not exact E2 supremum.')

def stats(v):
 m=sum(v)/len(v);se=math.sqrt(sum((x-m)**2 for x in v)/(len(v)*(len(v)-1)))
 return dict(mean=m,conditional_receiver_SE=se,receivers=len(v))

def run_case(index,stage,src,a,R,S):
 b=src.get('contrast_b',a/2);seed_index=src.get('seed_index',index);receiver_seed=791000+100*seed_index;cloud=receivers(src,a,R,receiver_seed);scales=[Q(1)+Q(j,32) for j in range(33)];baseline=[];refinement=0.;physical=[]
 for j,(x,q) in enumerate(cloud):
  # Exact source-support endpoints (receiver x is a machine rational); all sources.
  bp=sorted(set(2*abs(Q(xx)-yy+sgn*ee) for y,ee in zip(src['centers'],src['halfwidths']) for xx,yy in zip(x,y) for sgn in(-1,1) if 1<2*abs(Q(xx)-yy+sgn*ee)<=2))
  tested=sorted(set(scales+bp));vals=[abs(P(src,x,L,b)-P(src,x,L,a)) for L in tested];mx=max(vals);baseline.append(mx)
  if j<4:
   refinement=max(refinement,max(abs((P(src,x,L,b,128)-P(src,x,L,a,128))-(P(src,x,L,b)-P(src,x,L,a))) for L in scales[::8]));physical.append(dict(x=x,source_support_breakpoints=bp,registered_scale_grid_max=mx))
 batches=[]
 for batch in range(2):
  seed=792000+100*seed_index+batch;prior=latent_prior(src,S,seed);values={k:[] for k in('total','old','fresh')};weak={str(th):{k:[] for k in values} for th in(Q(1,64),Q(1,32),Q(1,16),Q(1,8))};examples=[];events=checks=0;sampling_difference=[]
  for j,((x,q),base) in enumerate(zip(cloud,baseline)):
   path=finite_path(src,x,a,prior);events+=path['breakpoint_events'];checks+=path['old_before_gate_checks'];sampling_difference.append(abs(path['maxima']['total']['value']-base)/q)
   for k in values:values[k].append(path['maxima'][k]['value']/q)
   for th in weak:
    eta=float(Q(th)*src['W'])
    for k in values:weak[th][k].append(eta*float(path['maxima'][k]['value']>eta)/q/float(src['W']))
   if j<3:examples.append(dict(x=x,proposal_density=q,finite_path=path,actual_registered_grid_max=base))
  batches.append(dict(latent_seed=seed,latent_samples=S,L1_estimates={k:stats(v) for k,v in values.items()},normalized_weak_estimates={th:{k:stats(v) for k,v in w.items()} for th,w in weak.items()},finite_total_vs_actual_grid_absolute_difference_dx=stats(sampling_difference),physical_breakpoint_events=events,old_before_gate_checks=checks,examples=examples))
 n=src['n'];m=sum(Q(math.comb(n,k))*abs(b**k*(1-b)**(n-k)-a**k*(1-a)**(n-k)) for k in range(n+1))
 return dict(stage=stage,input=src,contrast_kind='telescoped_endpoint' if 'contrast_b' in src else 'adjacent_layer',a=a,b=b,actual_mask_signed_TV=m,analytic_single_layer_old_L1_upper=float(m)*(1+n*math.log(2))/(n+2)*float(src['W']),h='log(n+2)/n',e_minus_nh=Q(1,src['n']+2),receiver_seed=receiver_seed,receiver_count=R,proposal_softness_parameters=[b,a] if 'contrast_b' in src and not src.get('proposal_legacy_a_only',False) else [a],proposal_physical_scales=[Q(1),Q(3,2),Q(2)],receiver_proposal='equal P_a/P_b mixture at L=1,3/2,2 divided by 6W' if 'contrast_b' in src and not src.get('proposal_legacy_a_only',False) else 'P_a mixture at L=1,3/2,2 divided by 3W',actual_registered_scale_grid_L1=stats([v/q for v,(_,q) in zip(baseline,cloud)]),phi_64_128_spot_refinement_max=refinement,physical_examples=physical,batches=batches,scope='Common registered receiver cloud and two independent coupled latent-prior batches; original dx importance weights. Conditional receiver SE omits latent/quadrature bias; no continuum interval or maximal upper bound.')

def main():
 start=time.monotonic();g=geometry_guard();rows=[]
 for i,(stage,src,a,R,S) in enumerate(fixtures()):
  print(stage,src['name'],flush=True);rows.append(run_case(i,stage,src,a,R,S))
 out=dict(status='PASS',geometry_guard=g,cases=rows,definition='u=P_b-P_a with b=a/2 adjacent or b=0,a=1 endpoint; old latent gates have global physical entry A<=L/exp(h); fresh=u-old, h=log(n+2)/n. Every endpoint shares original source y, Bernoulli activation uniforms U and E2 noise Z.',scope='Finite diagnostic common-source age experiment, actual positive L1 inputs and original dx; exact rational geometry fixtures only. No arbitrary proxy, fitted order, continuum numerical certificate or gridmax exact claim.')
 p=Path(__file__).with_name('corridor_results.json');p.write_text(json.dumps(clean(out),sort_keys=True,separators=(',',':'))+'\n');print('PASS',time.monotonic()-start,'seconds',hashlib.sha256(p.read_bytes()).hexdigest(),flush=True)
if __name__=='__main__':main()
