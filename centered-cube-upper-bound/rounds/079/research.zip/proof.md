# 中心立方体第79轮：共同来源年龄分解、重叠支付与真实核转移

日期：2026-10-11。主目标 **UNPROVED／未完成**。

一般中心立方体弱型常数的 sqrt(n)n^{o(1)} 一致上界仍未证明；全一般保留基准仍为 O(n log n)。本轮没有把有限样本、条件覆盖或辅助分解当作主定理。本轮所有空间积分仍是原始 Lebesgue dx，参数 n 是维数，源原子数和样本数另列。

## 新的无条件结果与精确欠项

1. **共同源年龄分解。** 对每个真实来源与 E2 噪声标记，捕获尺度构成单一区间，保留进入和退出。取年龄 ell=log(n+2)/n，先对软层有符号求和，旧到达部分的强窗口极大费用不超过 2W。精确更新方程含恢复漂移 nF；年龄到期通量费用不超过 (8log2/3)W。近期到达减近期退出的实际首达费用仍未证明。新鲜硬核的质量接近1，不能把短年龄当作小质量。
2. **端点内在重叠。** 真正的核交叠 M_a=min(Psi_a,Psi_{a/2}) 质量不超过 exp(-c_*na)，c_*=(1-1/sqrt2)^2/6。任意正 L1 输入的全部粗层交叠背景可按 O(sqrt n) 强预算支付；全部层的交叠强迫可用维数无关的联合阈值预算支付。跨不同源位置的相反符号贡献尚未支付，不能把卷积前的符号不相交当作卷积后不相交。
3. **量化误差统一支付。** 真实 E2 噪声向有限节点收缩，并把尾部送至零，可保持所有掩码标签、概率质量及 D/K/J 的 Cauchy 接口。存在显式正递减误差包络 E；全部层的 D/K/J 强最大误差分别不超过 9nS_nEW、(9/2)nS_nEW、18nS_nEW，S_n=1+nlog2。网格和截断半径给定显式容差选择，无尺度族大小或节点数费用。量化核本身非单调，不能直接套递减核估计。
4. **覆盖转移的准确方向。** 固定有限尺度族下，共同源量化、边界零测及支配收敛允许用带阈值留量的 robust-low 事件和 Fatou，从统一有限证书费用转回真实核；该转移仍以廉价证书存在为前提。没有通过极限构造出尚未证明存在的覆盖。

最后仍须对一般输入证明真实新到达/退出首达预算，或建立等效的一致廉价混合覆盖；软层路线还明确保留 balanced-source 贡献。任何单窗口结论随后还须完成全尺度回代。本轮未改变这些未决状态。

## 数值证据与复现

本轮为每个采用的新接口做了初步、压力及扩展三阶段检查，精确代数与实际 E2 浮点诊断分别标识：

- 噪声程序检查4691个标量点（含所有登记噪声节点的门边界及左右点）、36组实际有符号输入配置、4788个接收行，以及288个有理张量展开、72个有理质量界、18个全层费用恒等式、3个源位移反例。三次网格细化的最大点态误差约为0.12438、0.03916、0.01787；这些数值不是普遍收敛率证明。
- 年龄程序登记10个配置：6个相邻层、3个有符号端点及1个保留的原提议分布压力案例，输入均为正 L1 盒混合，维数1至8、中心数1至8、质量1或3；648个物理接收点、20个独立潜在来源批次、16384次潜在来源抽样。真实核求积和有限潜在先验的完整事件枚举分别记录，有限网格最大值不称连续最大值。端点初始提议分布的严重采样波动完整保留并可复现，没有删除不利数值。
- 软层守卫检查真实 E2 affinity 细化、维数8/32/128的两批 Hellinger 倾斜抽样、跨源相消及扩展至65536维的已证费用公式。硬面守卫检查精确掩码、实际捕获区间及扩展至2^20维的已证年龄费用。
- 两个独立主程序已由父代理重放，生成的 JSON 与冻结结果逐字节一致；组件守卫及独审结果在下文和 inventory.json 中记录。有限检查不证明未决一般弱型不等式。

解压后用 Python 3 标准库运行 `python3 -B quantization_probe.py`、`python3 -B corridor_probe.py`。报告中的四个 Python 代码块依次为 soft_guard、hardface_guard、coverage_guard 和最终 audit_guard；可分别提取运行，最终独审守卫会检查可移植归档。生产与主代理重放使用 Python 3.12.14。报告含种子、样本范围、偏差及标准误的适用范围。

## 技能、归档及协作

已重新核对64项规范技能入口：277379字节、437个直接本地链接均可读；相对第78轮入口字节未变化。仅声称读取了论证中实际使用的技能边界，不声称已读完全部外部论文或全部技能的每项命题。覆盖、软层、硬面研究使用 gpt-6-astra medium；数值与独审使用 gpt-6.1-sol high。

本轮依赖第78轮已支付的连续中心化通量及有限混合证书定义，均在 rounds/078/research.zip；本轮新结果的证明在本文给出。只提交本轮 README、一个7成员归档，并更新项目总览；草稿和重复重放文件留在仓库外。LaTeX 源保存为 proof.tex.txt，只做静态结构检查，不编译、不生成PDF。

---


# R79 parent: uniform physical-scale noise discretization

**Status: proved auxiliary transfer, not the main weak bound.** All receiver integrals are Lebesgue integrals. No constant below depends on the number of physical scales, source atoms, soft layers, or finite noise nodes. We retain the actual E2 smoothing law and its mask labels. Quantization does not produce a new dimension bound by itself.

The updated 64-tool skills A03, M04 and B02 have been reloaded for this step. Their restrictions are used explicitly: weak convergence is not strong maximal convergence; finite selector ties require a threshold-slack argument; finite sampled constraints are not whole-event certificates. These skills do not certify the new theorem by their names. The following proof supplies the needed estimates directly.

## P79.1 Scalar coupling with a decreasing error majorant

Let h=1_{[-1/2,1/2]}, w(z)=integral_0^1 exp(-|z|/r)dr, and phi=h*w. The density w has mass one, w(0)=1, is even decreasing, and w(z)<=exp(-|z|). For 0<eta<=1 and R>=1, set

    q(z)=sign(z) eta floor(|z|/eta), if |z|<=R;
    q(z)=0, if |z|>R.

Let w_q be the pushforward of w(z)dz and phi_q=h*w_q. The law w_q is a finitely supported positive probability law, including its tail at zero; phi_q is its convolution density with h. This is not a renormalized truncated law. Pointwise |q(z)|<=|z|, and on |z|<=R its displacement is less than eta. Let p_R=integral_{|z|>R} w(z)dz. Then

    |phi_q(x)-phi(x)| <= e(x),
    e(x)=4 eta w((|x|-1/2-eta)_+)
         +p_R h(x)+phi(max(|x|,R-1/2)).                       (P1)

To prove this, use the same scalar noise Z for the two gates h(x-Z) and h(x-q(Z)). On |Z|<=R, different gate values require Z within eta of one of x-1/2 and x+1/2. The two intervals have total length at most 4 eta. Every point in them has modulus at least (|x|-1/2-eta)_+, proving the first term. On the tail, the quantized gate is h(x); its contribution is p_R h(x). The original tail convolution vanishes when |x|<=R-1/2, up to irrelevant endpoints, and is at most phi(x) elsewhere. Its decreasing plateau majorant is the last term of (P1). The same estimate holds with closed gates at their jump points.

All three terms of e are nonnegative, even, and decreasing on [0,infinity). Write E=integral e. Since integral_0^infinity w=1/2,

    integral 4 eta w((|x|-1/2-eta)_+)=8 eta(1+eta).

Also p_R=integral_0^1 2r exp(-R/r)dr<=exp(-R). For u>=1/2, phi(u)<=exp(1/2-u). Splitting the plateau integral at R-1/2 gives

    E <= Ebar:=8 eta(1+eta)+exp(-R)+(2R+1)exp(1-R).            (P2)

This is deliberately an upper bound. Neither numerical quadrature nor an asymptotic fit is used to establish it. In particular, no Fisher estimate for a sharply truncated density is asserted.

## P79.2 Product domination and the scale envelope

Put psi_a=(1-a)h+a phi and psi_aq=(1-a)h+a phi_q for 0<=a<=1. Both have mass one. Although phi_q can fail to be decreasing, psi_aq<=psi_a+a e. Product telescoping therefore gives

    |psi_aq^tensor n-psi_a^tensor n| <= V_a,
    V_a=sum_j a e(x_j) product_{i<j}(psi_a+a e)(x_i)
                         product_{i>j}psi_a(x_i),
    integral V_a=(1+aE)^n-1.                                 (P3)

Every summand is a product of nonnegative even decreasing scalar functions. If nE<=1, the last mass is at most 3naE, using (1+aE)^n<=exp(naE) and exp(t)-1<=3t on [0,1]. For a product with k quantized soft factors and n-k hard factors, the same argument yields a decreasing-product majorant of mass at most 3kE.

For any positive product of even decreasing scalar integrable functions V, layer-cake writes V as a positive mixture of indicators of centered rectangles. For each centered rectangle its dilation-window maximal integral divided by its mass equals

    S_n=1+n log 2.

Indeed, inside the rectangle the maximal value is its undilated density; in the gauge annulus 1<rho<=2 it is rho^(-n) times that density. Integration of n rho^(n-1)rho^(-n) gives n log 2. Tonelli extends this bound to positive mixtures. Translation and positive convolution with mu=|nu|, W=mu(R^n), then imply for any finite J subset [1,2],

    ||max_{L in J}|nu*(psi_aq^tensor n-psi_a^tensor n)_L|||_1
       <=3naE S_n W.                                        (P4)

The same statement holds for the countable supremum, by monotone convergence. For L1 input the bounded kernels produce continuous convolutions in the scale parameter: approximate the input in L1 by smooth compactly supported functions, use bounded kernels uniformly on this window, then use dilation continuity in L1 for the approximants. Thus the countable supremum over a dense set also gives the continuous-window assertion for L1 input. We need only the finite-family assertion for the coverage transfer. No supremum of arbitrary nonmeasurable representatives is taken.

## P79.3 Preserve the labels in D, K and J

Fix delta in (0,1]. The latent mask m in {0,1}^n has endpoint weights

    alpha_m=(delta/2)^|m|(1-delta/2)^(n-|m|),
    beta_m=delta^|m|(1-delta)^(n-|m|),
    q_m=(alpha_m+beta_m)/2,
    zeta_m=(alpha_m-beta_m)/q_m, j_m=q_m zeta_m^2,

with zeta=0 on zero q_m. Let k_m be the product of phi in soft coordinates and h in hard coordinates. The exact kernels are

    D_delta=sum_m(alpha_m-beta_m)k_m,
    K_delta=sum_m q_m k_m,
    J_delta=sum_m j_m k_m.

Quantize only the scalar noise within each already-labelled soft coordinate. The labels and their zeta_m must remain, even when different physical noise atoms collide at zero. The quantized kernels then satisfy exactly

    integral D_delta,q=0, integral K_delta,q=1,
    integral J_delta,q=sum_m j_m=I_delta,
    |D_delta,q|^2<=K_delta,q J_delta,q,
    J_delta,q<=4K_delta,q.

The last two claims follow from labelled Cauchy--Schwarz and |zeta_m|<=2; they need no coordinate independence after observing a receiver. Merging mask labels and then reassigning zeta would change the model and is prohibited.

Endpoint application of (P4) gives positive envelope functions, with masses at most

    D error: (9/2)n delta E S_n W;
    K error: (9/4)n delta E S_n W.                            (P5)

For J, sum the per-mask majorants. Since sum_m q_m |m|=3n delta/4 and j_m<=4q_m,

    J error <=3E S_n W sum_m j_m |m|
            <=9n delta E S_n W.                              (P6)

Here 'error' means the L1 norm of the maximum absolute convolution difference over J. Summing the actual positive majorants over delta_s=2^(-s), s>=0, gives one measurable, integrable error function per family, not a sum of weak quasi-norms:

    ||sum_s max_L |D_s,q-D_s convolved with nu|||_1<=9nE S_n W,
    ||sum_s max_L |K_s,q-K_s convolved with nu|||_1<=(9/2)nE S_n W,
    ||sum_s max_L |J_s,q-J_s convolved with nu|||_1<=18nE S_n W. (P7)

These fees are uniform in finite depth and scale count. They also hold for the full dyadic sum by monotone convergence of the nonnegative majorants.

## P79.4 An explicit prescribed error budget

For any epsilon in (0,1], set E_star=epsilon/(18nS_n). Choose

    0<eta<=E_star/32,
    R>=2+2 log(8/E_star).                                    (P8)

R may be increased to a multiple of eta. Since eta<=1, the local term in (P2) is <=16eta<=E_star/2. Its tail terms are at most 2(R+1)exp(1-R). The elementary inequality (R+1)exp(-R/2)<=2 for R>=0 shows this is <=4e exp(-R/2)<=E_star/2. Thus E<=E_star and nE<=1, and the three all-layer errors in (P7) are respectively at most

    epsilon W/2, epsilon W/4, epsilon W.                    (P9)

The number of noise nodes can be large; it occurs neither in these fees nor in their exponents. Contractivity |q(z)|<=|z| also preserves upper bounds for moments and for the physical representative penalty P(z)=1+n^(-1)sum_i(|z_i|-1/2)_+.

A crucial scope warning: phi_q itself need not be even decreasing away from zero. One must not apply the S_n envelope directly to its product on that basis. Instead use the actual-kernel envelope plus the paid error majorant. For example K_delta,q<=K_delta+V_delta,K gives a window envelope at most S_n[1+(9/4)n delta E]W. Equations (P5)--(P9) supply the corresponding error for high/low event transfer.

## P79.5 Why source approximation needs a different topology

Noise quantization above has a uniform strong maximal error because the continuous noise law supplies an integrable boundary majorant. Weak convergence of the source alone has no such property. In dimension one take mu_epsilon=delta_epsilon -> delta_0. For x in [3/4,1] and 0<epsilon<1/4 choose L=2x-epsilon in [1,2]. Then h_L(x)=0 but h_L(x-epsilon)=1/L>=1/2. Consequently

    integral max_{1<=L<=2}|h_L(x-epsilon)-h_L(x)|dx>=1/8.

A finite sufficiently fine family depending on epsilon gives the same bound up to an arbitrarily small endpoint loss. This analytic example rules out a uniform strong-maximal source-transfer assertion; it does not obstruct finite-family a.e. convergence and Fatou transfer with threshold slack. For a fixed finite physical family, translated cube boundaries have dx measure zero. Coupled source approximations yield gate convergence at almost every receiver and dominated convergence, and both T and F converge. A robust event using max F avoids relying on convergence of a tied maximizing selector. The coverage component provides that separate argument. No cheap covering certificate is constructed by the scalar quantization theorem itself.

## P79.6 Numerical scope and remaining theorem

The accompanying quantization_probe.py checks the actual E2 probability pushforward without renormalization, scalar gate endpoints, decreasing error majorants, nonmonotonicity of phi_q, tensor and labelled mask identities, and physical finite-family convolution errors. Its exact rational cases certify those finite identities; numerical E2 integrals are diagnostics. Mesh refinements and expanded dimensions are reported in quantization_results.json. These tests neither certify a universal mixed-cover cost nor prove the fresh signed arrival/exit estimate. The main sqrt(n)n^{o(1)} goal and the required global-scale passage remain unproved.


# Round 79: an all-input payment for intrinsic endpoint overlap

**Status.** This round proves that the common part of the two actual endpoint kernels has exponentially small mass, and pays its maximal background over all coarse layers at O(sqrt(n)) cost. Its contribution to negative-corridor forcing can in fact be paid over ALL layers by a dimension-independent threshold budget. This is a genuine all-input exception, not a statement restricted to the test sources. The remaining adverse term is opposite-sign contribution from different original source locations. A precise posterior criterion absorbs that term on one branch, but a budget for the balanced-source branch is still missing. The actual signed face flux and its damping are retained; the general centered-cube goal remains unproved.

A02's payment direction and D04's same-joint-source conditional probabilities are respected. No martingale or independent-coordinate assumption is imposed on the input. Coordinate independence is used only for the specified product kernels. The proof below is elementary and uses the actual E2 density. Only the owned soft.md, soft.tex.txt and embedded guard are written; no Git operation or compilation is performed.

## 1. The actual negative corridor and what cannot be discarded

Let f>=0 be arbitrary in L1(R^n), W=||f||_1, T=log 2 and L=exp t. For a in (0,1], b=a/2, retain

    psi_a=(1-a)h+a phi,  Psi_a=psi_a^tensor n,
    P_a(t,x)=f*(Psi_a)_(exp t)(x), u=P_b-P_a,
    kappa=n(1-b), gamma=n(a-b)=na/2.

The R78 exact equation is

    u'=c+v-kappa u-gamma P_a.                         (1)

Here c is the ORIGINAL signed hard-face difference and v the centered continuous difference. Neither is silently changed by the following argument. After deleting the anchor event, the actual first threshold hit and its last same-sign half-threshold excursion yield a negative corridor I(x) with z=-u in [eta/2,eta] and

    eta/2+kappa integral_I z
       =integral_I(-c-v)+gamma integral_I P_a.         (2)

The corridor is an actual function of the same input and physical scale path. Last exits need not be stopping times; only the already-proved deterministic integration identity is used. All spatial integrals are dx, not f(x)dx.

A ratio manipulation alone does not pay the forcing. For example gamma P_a<=kappa z/2 requires z/P_a>=2a/(2-a), which is not automatic on a negative event. Replacing kappa by the smaller n(1-a) and P_a by P_b is merely an equivalent rearrangement. A new independently paid component is needed.

## 2. Sourcewise Hahn decomposition and the actual overlap mass

Define kernel functions BEFORE convolving with f:

    M_a=min(Psi_a,Psi_b),
    D_a^+=(Psi_b-Psi_a)_+,  D_a^-=(Psi_a-Psi_b)_+.

They are nonnegative, and D_a^+ D_a^-=0 pointwise in the kernel displacement variable. Exactly

    Psi_a=M_a+D_a^-, Psi_b=M_a+D_a^+.

At each actual scale define the same-source convolutions

    m=f*(M_a)_L, p=f*(D_a^+)_L, q=f*(D_a^-)_L.

Then P_a=m+q, P_b=m+p and u=p-q. The source f is unchanged for all three terms. Importantly, m is generally NOT min(P_a,P_b), and p,q can both be positive at the same receiver. Their disjointness before convolution does not survive mixing different source locations.

Put

    c_*=(1-1/sqrt 2)^2/6>0.

For the actual phi=h*w, its mass outside the hard interval is

    theta=integral_(|x|>1/2) phi(x)dx
         =2 integral_0^1 v^2(1-exp(-1/v))dv >=1/3.    (3)

Indeed 1-exp(-1/v)>=1-exp(-1)>1/2 on (0,1]. Outside the hard interval psi_a=a phi and psi_b=(a/2)phi. The one-coordinate Hellinger affinity r_a therefore satisfies

    1-r_a=(1/2)integral(sqrt(psi_a)-sqrt(psi_b))^2
          >=(a theta/2)(1-1/sqrt 2)^2 >=c_* a.

Product factorization of the ACTUAL KERNEL law and min(v,w)<=sqrt(vw) now prove

    m_a:=integral M_a <=r_a^n <=exp(-c_* n a).         (4)

There is no product-source assumption. Both endpoint kernels decrease along every ray from the origin; hence their minimum M_a also does. It is an admissible positive ray-decreasing kernel for the finite-window envelope, even though it is not itself a product kernel.

## 3. All coarse overlap backgrounds are paid simultaneously

For any finite physical family in [1,2], the positive ray-envelope inequality gives

    ||max_L f*(M_a)_L||_1 <=(1+nT)m_a W.

Let a_s=2^(-s), and call a layer coarse when a_s>n^(-1/2). The positive numbers x_s=n a_s in that set form a finite dyadic string above sqrt(n). Since 2^j>=j+1,

    sum_(coarse s) exp(-c_* x_s)
       <=1/(exp(c_* sqrt(n))-1)<=1/(c_* sqrt(n)).

Thus the genuine common backgrounds satisfy the all-input strong estimate

    ||sum_(coarse s) max_L f*(M_(a_s))_L||_1
       <=(1+nT)/(exp(c_*sqrt(n))-1) W
       <=(1+nT)/(c_*sqrt(n)) W.                       (5)

The empty coarse set at n=1 causes no exception. This is O(sqrt(n)) with an explicit absolute constant. It pays the full common-kernel background for arbitrary source count, depth and finite scale family, without invoking a packet coverage premise.

The envelope used here is the already-proved positive-kernel estimate: for ordered scales, the terminal kernel plus sum [1-(L_i/L_(i+1))^n] times the preceding kernels dominates their maximum. Its integral is at most (1+nT) times the kernel mass. No conditional weak norms are averaged.

## 4. All-layer overlap forcing has a dimension-independent payment

There is a sharper statement tailored to (2). Define the NONSELECTED positive upper bound

    Q_s(x)=gamma_s integral_0^T f*(M_(a_s))_(exp t)(x)dt,
    gamma_s=n a_s/2.

By Tonelli and (4), with x_s=n2^(-s),

    ||Q_s||_1<=d_s W,
    d_s=(T/2)x_s exp(-c_*x_s).                        (6)

The intervals [x_s/2,x_s] are disjoint and cover (0,n]. On each one, x_s exp(-c_*x_s)<=2 integral_(x_s/2)^x_s exp(-c_*u)du. Consequently

    sum_s ||Q_s||_1 <=(T/c_*)W.                       (7)

This holds over all infinitely many layers and yields almost-everywhere finiteness of their sum. It is not a claim that the full gamma_s P_(a_s) forcing is paid.

To integrate the statement into actual layer thresholds, set Z=sum_s sqrt(d_s) and omega_s=sqrt(d_s)/Z. Each d_s is positive. Similarly,

    sqrt(x_s) exp(-c_*x_s/2)
       <=2 integral_(x_s/2)^x_s u^(-1/2)exp(-c_*u/2)du,
    Z<=2 sqrt(pi T/c_*), Z^2<=4 pi T/c_*.

Markov and the UNION bound therefore give

    lambda |union_s {Q_s>lambda omega_s/8}|
       <=8 Z^2 W<=32 pi T/c_* W.                      (8)

This is dimension independent, source independent and depth independent. Finite-layer truncations only decrease the root sum. If the main proof needs another threshold allocation v_s, it is enough to arrange v_s>=theta omega_s for a fixed theta>0, for example by taking a convex combination of allocations. The right side of (8) is then divided by theta. No summability of weak quasi-norms has been used: each Q_s has a strong L1 estimate, and the displayed inclusion is an ordinary union of level sets.

For each surviving actual corridor with eta_s=lambda v_s, its intrinsic-overlap forcing is at most Q_s<=eta_s/8. Thus (8) supplies a real all-input exception for the original corridor, irrespective of how its last exit was selected.

## 5. What remains after the paid overlap is removed

On a negative corridor z=q-p, hence P_a=m+z+p. Substitution in (2), WITHOUT changing c, gives the exact identity

    eta/2+n(1-a) integral_I z
       =integral_I(-c-v)+gamma integral_I m
                                     +gamma integral_I p.      (9)

Outside the exception (8), it follows that

    3eta/8+n(1-a) integral_I z
       <=integral_I(-c-v)+gamma integral_I p.           (10)

The residual p is the positive kernel-sign contribution of other sources, opposed to the negative total at this receiver. This is an explicit cross-source cancellation term. It is not eliminated by the exponentially small intrinsic kernel overlap.

For a<=1/2, the remaining damping coefficient n(1-a) is at least n/2. Define the actual sign posterior

    pi_+(t,x)=p/(p+q),

on the corridor, where p+q>0. It is a conditional probability under the common positive measure f(y)[D_a^++D_a^-]_L(x-y)dy, not a private posterior chosen for each term. Since z=q-p>0,

    p/z=pi_+/(1-2pi_+).

Therefore the condition

    pi_+<=(1-a)/(2-a)                                 (11)

is exactly sufficient for gamma p<=[n(1-a)/2]z. If it holds throughout the actual corridor, (10) becomes

    3eta/8+[n(1-a)/2] integral_I z<=integral_I(-c-v).    (12)

This branch removes the adverse forcing while retaining half the true damping and the original signed face flux. It still requires the signed face-crossing estimate; it is not a completed volume bound.

For a completely general corridor let I_good be the times satisfying (11), and I_bal its complement. The exact remaining statement is

    3eta/8+[n(1-a)/2] integral_I_good z
                         +n(1-a) integral_I_bal z
       <=integral_I(-c-v)+gamma integral_I_bal p.       (13)

The last term is UNPAID. It has the exact source-mixing interpretation C_mix=(f*|D_a|-|f*D_a|)/2=min(p,q), where D_a=Psi_b-Psi_a and dilation at the same selected scale is understood. On a negative corridor p=C_mix. At each fixed time, integral C_mix dx=(||D_a||_1 W-||u(t)||_1)/2. This is the total-variation contraction defect of convolution, a genuine Jensen gap under the same source. Bounding it just by its total mass gives the old order-na forcing fee, so this identity alone is not a new payment or an entropy decrease. In particular (11) cannot be assumed just because the kernel signs have disjoint supports. The guard gives genuine two-source examples with pi_+ arbitrarily close to 1/2 on a negative contrast event. At fixed points away from kernel boundaries, continuity makes these into positive-volume neighborhoods; ordinary L1 source mollification preserves the strict inequalities. This observation only checks the scope of (11), not the desired weak bound. Analytically, at x=0 take sources y=0 and y=(1,...,1). Their kernel differences are respectively d_plus>0 and -d_minus<0. The balancing first-source weight is p_star=d_minus/(d_plus+d_minus). Replacing it by (1-epsilon)p_star makes z=epsilon d_minus>0 while the opposite contribution remains (1-epsilon)p_star d_plus. Its ratio to z tends to infinity as epsilon tends to zero. Thus the balanced branch is a genuine same-source mixture phenomenon, not a quadrature artifact.

## 6. The top coarse negative branch is separately paid

At a=1, the residual damping in (9) is zero, so it must not be divided out. Instead a negative event satisfies

    P_1-P_(1/2)>eta  implies  P_1>eta.

The actual smooth base P_1=f*(phi^tensor n)_L has the R78 strong maximal estimate

    ||max_L P_1||_1 <=[1+T sqrt(7n/3)]W.               (14)

Thus the entire a=1 negative branch costs O(sqrt(n)), independently of overlap or sign posterior. To use it at the main threshold lambda, reserve a FIXED positive fraction for this layer: if eta=beta lambda, the fee is (1+T sqrt(7n/3))W/beta. Using the exponentially tiny omega_0 from (8) as the sole top-layer threshold would destroy this conclusion. For example the main allocation may reserve one third at s=0, one third for omega, and one third for the other proved layer estimates; this makes the threshold dependencies explicit.

After that top layer, all remaining coarse parameters obey a<=1/2, so the positive damping in (10)--(13) is valid. Fine-layer background payments from R78 remain available; this note does not replace their actual signed-face debt with the overlap estimate.

## 7. Relation to common activation and the remaining target

A single source/noise coupling also realizes all endpoint laws: choose independent U_j uniform on [0,1] and Z_j with density w, then let the noise at softness a be (1_{U_j<=a}Z_j)_j. This is compatible with the same input source. However a martingale in softness does not follow at the same physical receiver: removing random translations changes the argument of the input, and conditional expectations would introduce shifted receivers or an additional state. No entropy descent or optional-stopping claim is made from that coupling.

The companion hard-face route treats exact scale-entry/exit intervals and old-versus-fresh source contributions. The present component does not duplicate its age payment. It retains (1) and proves an independent overlap exception (5)--(8), plus the precise absorptive sign-posterior branch (12). The genuine residual consists of the original signed flux and, on balanced-source corridor times, gamma p in (13). A dimension-appropriate payment for that term or an alternate full crossing argument is still required.

In particular, the main sqrt(n)n^o(1) weak theorem is not established. The new results are unconditional for arbitrary nonnegative L1 inputs, while the remaining balanced-corridor budget is explicitly not assumed.

## 8. Executed three-stage true-kernel guard

The independent embedded guard first refines actual E2 affinity integrals at a=1,1/2,1/8, keeping both one-sided hard traces. It then samples the product Hellinger tilt at n=8,32,128, in two independently seeded batches of 128 samples per case. The proposal is (psi_a+psi_b)/2, generated by the real uniform-plus-E2-noise law; acceptance is 2sqrt(psi_a psi_b)/(psi_a+psi_b). Under ideal exact evaluation this gives the Hellinger tilt. Actual phi evaluation uses quadrature, so these are numerical diagnostics, not exact-law or interval certificates. Standard errors quantify batch sampling variability only, not quadrature bias.

The third stage checks sourcewise Hahn identities on actual two-source examples at n=1,2,4 and displays the gap between f*min(Psi_a,Psi_b) and min(P_a,P_b). It also checks the all-depth positive budgets up to n=65536. This is deliberately a test of the retained forcing and its exception, not an arbitrary total-variation proxy or a scale-grid claim about the exact continuous maximum. The analytic inequalities (3)--(14), not the observed values, supply the universal conclusions.

Guard SHA-256: `88e0d0cdabc9128cc793930fccebce8fe4013269757f32cba943c3a58692d76f`.

Executed stdout:

```text
affinity a=1 realE2=0.96619365 bound=0.98570226 refinement=8.15e-07
affinity a=0.5 realE2=0.987010442 bound=0.99285113 refinement=4.08e-07
affinity a=0.125 realE2=0.997221917 bound=0.998212783 refinement=1.02e-07
overlap n=8 actual_E2_tilt_batch1=0.63786+/-0.0125 batch2=0.627888+/-0.0117 affinity_upper=0.900687 universal_upper=0.944414
overlap n=32 actual_E2_tilt_batch1=0.3694+/-0.0134 batch2=0.356435+/-0.0136 affinity_upper=0.658106 universal_upper=0.795516
overlap n=128 actual_E2_tilt_batch1=0.0648454+/-0.00431 batch2=0.0627314+/-0.00503 affinity_upper=0.187579 universal_upper=0.400494
source_cancellation n=1 u=-0.000412162 opposite/z=72.1585 posterior_plus=0.496559 intrinsic_overlap=0.239086 convolution_min=0.268827
source_cancellation n=2 u=-5.09633e-05 opposite/z=96.3427 posterior_plus=0.497418 intrinsic_overlap=0.0177541 convolution_min=0.0226641
source_cancellation n=4 u=-4.32876e-07 opposite/z=98.9834 posterior_plus=0.497487 intrinsic_overlap=6.38427e-05 convolution_min=0.00010669
budget n=1 forcing_L1_bound_actual_sum=0.686581 rootcost_squared=4.0139
budget n=2 forcing_L1_bound_actual_sum=1.36019 rootcost_squared=7.97615
budget n=16 forcing_L1_bound_actual_sum=9.55362 rootcost_squared=58.3892
budget n=256 forcing_L1_bound_actual_sum=34.8533 rootcost_squared=304.478
budget n=4096 forcing_L1_bound_actual_sum=34.9709 rootcost_squared=316.999
budget n=65536 forcing_L1_bound_actual_sum=34.9709 rootcost_squared=316.999
PASS assertions=43; E2 quadrature and sampling are diagnostics, not exact interval certificates
```

Replay the following Python fence with Python 3.

```python
from math import exp,log,sqrt,pi
from functools import lru_cache
import random
checks=0
def ck(v):
 global checks
 assert v
 checks+=1
c=(1-1/sqrt(2))**2/6
T=log(2)
def simp(fn,a,b,N):
 h=(b-a)/N
 return h*(fn(a)+fn(b)+sum((4 if k%2 else 2)*fn(a+k*h) for k in range(1,N)))/3
@lru_cache(None)
def phi(x,N=64):
 x=abs(x)
 def f(v):
  if v==0:return 0.
  if x<=.5:return v*(2-exp(-(.5-x)/v)-exp(-(.5+x)/v))
  return v*(exp(-(x-.5)/v)-exp(-(x+.5)/v))
 return simp(f,0,1,N)
def psi(x,a,N=64):return (1-a)*float(abs(x)<=.5)+a*phi(x,N)
def affinity(a,N):
 b=a/2
 # Separate both hard traces; omitted tail beyond18 is diagnostic error.
 def fn(x,inside):
  p=phi(x,N)
  return sqrt(((1-a)*inside+a*p)*((1-b)*inside+b*p))
 return 2*(simp(lambda x:fn(x,1.),0,.5,4*N)+simp(lambda x:fn(x,0.),.5,18.,8*N))
outside=2*simp(lambda v:0. if v==0 else v*v*(1-exp(-1/v)),0,1,512)
ck(outside>1/3)
for a in (1.,.5,.125):
 A=affinity(a,64);A2=affinity(a,128)
 ck(A2<=1-c*a+1e-6)
 ck(abs(A2-A)<2e-5)
 print('affinity a=%.6g realE2=%.9g bound=%.9g refinement=%.3g'%(a,A2,1-c*a,abs(A2-A)))
# Hellinger tilted product sampler: density sqrt(psi_a psi_b)/affinity.
# Proposal (psi_a+psi_b)/2; accepted coordinates use actual E2 quadrature.
def sample_coordinate(rng,a):
 while True:
  ap=a if rng.random()<.5 else a/2
  x=rng.random()-.5
  if rng.random()<ap:
   v=sqrt(rng.random());x+=(1 if rng.random()<.5 else -1)*v*(-log(max(rng.random(),1e-300)))
  pa=psi(x,a);pb=psi(x,a/2)
  if rng.random()<=2*sqrt(pa*pb)/(pa+pb):return log(pb/pa)
a=.5;A=affinity(a,128)
for n in (8,32,128):
 vals=[]
 for batch in range(2):
  rng=random.Random(790711+1000*n+batch)
  weights=[]
  for k in range(128):
   score=sum(sample_coordinate(rng,a) for j in range(n))
   weights.append(exp(-abs(score)/2))
  mean=sum(weights)/len(weights);se=sqrt(sum((v-mean)**2 for v in weights)/(len(weights)-1)/len(weights))
  vals.append((A**n*mean,A**n*se))
  ck(0<=mean<=1)
 ck(A**n<=exp(-c*n*a)+1e-6)
 print('overlap n=%d actual_E2_tilt_batch1=%.6g+/-%.3g batch2=%.6g+/-%.3g affinity_upper=%.6g universal_upper=%.6g'%(n,vals[0][0],vals[0][1],vals[1][0],vals[1][1],A**n,exp(-c*n*a)))
# Exact sourcewise Hahn decomposition must precede source convolution.
for n in (1,2,4):
 a=.5;b=a/2
 kp0=psi(0,b)**n;ka0=psi(0,a)**n
 kp1=psi(1,b)**n;ka1=psi(1,a)**n
 dp=kp0-ka0;dn=ka1-kp1
 ck(dp>0 and dn>0)
 pstar=dn/(dp+dn);p=.99*pstar
 Pa=p*ka0+(1-p)*ka1;Pb=p*kp0+(1-p)*kp1
 M=p*min(ka0,kp0)+(1-p)*min(ka1,kp1)
 P=p*dp;N=(1-p)*dn;z=Pa-Pb
 ck(abs(Pa-M-N)<1e-13 and abs(Pb-M-P)<1e-13)
 ck(z>0 and P>0 and N>0 and M<min(Pa,Pb))
 gamma=n*a/2;kappa=n*(1-a/2)
 ck(abs(gamma*Pa-gamma*(M+z+P))<1e-13)
 ck(abs((kappa-gamma)-n*(1-a))<1e-13)
 print('source_cancellation n=%d u=%.6g opposite/z=%.6g posterior_plus=%.6f intrinsic_overlap=%.6g convolution_min=%.6g'%(n,-z,P/z,P/(P+N),M,min(Pa,Pb)))
# All-depth cost and compatible sqrt-threshold sums: analytic proof in note.
for n in (1,2,16,256,4096,65536):
 xs=[n*2.**(-s) for s in range(256)]
 total=sum(x*exp(-c*x) for x in xs)
 roots=sum(sqrt(x)*exp(-c*x/2) for x in xs)
 ck(total<=2/c and roots<=2*sqrt(2*pi/c))
 coarse=sum(exp(-c*x) for x in xs if x>sqrt(n))
 ck(coarse<=1/(exp(c*sqrt(n))-1) if c*sqrt(n)<700 else coarse==0)
 print('budget n=%d forcing_L1_bound_actual_sum=%.6g rootcost_squared=%.6g'%(n,T*total/2,T*roots*roots/2))
print('PASS assertions=%d; E2 quadrature and sampling are diagnostics, not exact interval certificates'%checks)
```


# R79: common-source age reduction and the exact delayed-arrival fee

**Status.** The general square-root weak bound remains unproved. This note proves an all-input, common-source decomposition into old and fresh arrivals. Old arrivals have a strong window payment, which is O(log n) if layers are paid separately and O(1) if the actual signed sum is taken first. The additional age-expiration flux also has an O(1) strong payment after that signed sum. The unresolved term is the actual fresh signed arrival/exit process with its restoring drift. No assertion that a short lifetime automatically gives a small maximal bound is made.

Skills retained: R78 read updated J04 and E01 including their cube interfaces; R79 additionally read updated J05. These explicitly require actual process/compensator contracts and integrability. Here all measures and flows are deterministic, and no martingale, stochastic compensator, or stopping theorem is invoked. The receiver measure throughout is dx.

## 1. One common source space and one interval per source

Let Q=[-1/2,1/2]^n, h=1_[-1/2,1/2], and

    w(z)=integral_0^1 exp(-|z|/r)dr,
    nu_a=(1-a)delta_0+a w(z)dz, psi_a=h*nu_a,
    Psi_a=h^tensor n*nu_a^tensor n.

The letter ell below denotes the age cutoff, to avoid confusing it with the one-dimensional kernel h. Fix f>=0 in L1(R^n), W=integral f, and t=log L in [0,T], T=log 2. The common physical source and noise variables are (y,z). Define

    G_t(x;y,z)=1_Q(e^(-t)(x-y)-z).

For each fixed (x,y,z), put d=x-y and q=e^(-t). Every coordinate condition is the interval constraint q d_i in [z_i-1/2,z_i+1/2]. Their intersection with q>0 is an interval. Hence G_t is the indicator of one time interval [alpha,beta], possibly empty or unbounded. It can enter at most once and exit at most once. In particular there is no repeated-arrival assumption hidden in the representation. If d=0, a nonempty interval may be all of R; this is a dx dy null set, and is also dx-null for each atomic source label. Such pairs may be omitted in the arrival formula.

The endpoints are explicit and Borel. For d_i!=0 intersect the ordered pair [(z_i-1/2)/d_i,(z_i+1/2)/d_i] with q>0; a zero d_i requires |z_i|<=1/2. If the resulting q interval is [qlo,qhi], then alpha=-log qhi and beta=-log qlo, with -log0=+infinity. Empty intersections contribute zero. Boundaries may use any consistent convention; for L1 input the resulting convolutions agree, and later suprema use their continuous representatives.

For b=a/2 define the signed common prior

    Delta_a=nu_b^tensor n-nu_a^tensor n.

The distributions of the exact set S of nonzero noise coordinates are mutually singular (continuous noise has no atom at zero). On that set, Delta_a has constant coefficient

    d_a(S)=b^|S|(1-b)^(n-|S|)-a^|S|(1-a)^(n-|S|)

relative to w on S and delta_0 outside S. Thus its total variation is the actual finite binomial quantity

    m_a=||Delta_a||_TV
       =sum_(k=0)^n binom(n,k)|b^k(1-b)^(n-k)-a^k(1-a)^(n-k)|
       <=min(2,na).                                             (1)

The last estimate follows by product telescoping, since ||nu_b-nu_a||_TV=a. This is not a posterior independence assumption. The posterior obtained after observing x and t generally does not factor.

The true layer difference is exactly

    u_a(t,x)=integral f(y)e^(-nt)G_t(x;y,z) dy Delta_a(dz).        (2)

## 2. Old versus fresh: an all-input strong payment

Fix any ell>0, the same for all layers. Split (2) into old O_(a,ell) with alpha<=t-ell and fresh F_(a,ell) with alpha>t-ell; always retain current survival G_t=1. The interval property gives the exact old gate

    G_t 1{alpha<=t-ell}=G_t G_(t-ell).                           (3)

Consequently, with K_a=h^tensor n*|Delta_a|,

    |O_(a,ell)(t,x)| <=e^(-n ell) (f*(K_a)_(exp(t-ell)))(x).     (4)

The input and the joint signed prior stay fixed across all receivers and times. In particular (4) does not introduce a private representative, a receiver-dependent source partition, or a changed receiver law. The physical interval t-ell in [-ell,T-ell] is allowed even when it starts below zero; its scale ratio is still exactly two.

Each K_a is a positive linear combination, with coefficients |d_a(S)|, of products of h and phi=h*w. Both one-dimensional factors are symmetric decreasing probability densities, so these are positive mixtures of normalized centered rectangles. The derivative phi'(x)=w(x+1/2)-w(x-1/2) proves the needed monotonicity directly. For a normalized centered rectangle R, writing its max-coordinate gauge as rho, its window envelope is K_1 on rho<=1 and rho^(-n)K_1 on 1<rho<=exp T; integration gives exactly 1+nT. Tonelli therefore gives

    ||sup_(0<=t<=T)|O_(a,ell)(t)||_1
       <=e^(-n ell)(1+nT)m_a W.                                (5)

For a_s=2^(-s), s>=0, N=ceil(log_2 n) (N=0 at n=1),

    sum_s m_(a_s)<=2N+2.

Thus even paying each old layer separately has the all-input strong bound

    ||sum_s sup_t |O_(a_s,ell)(t)||_1
       <=e^(-n ell)(1+nT)(2N+2)W.                              (6)

With ell=log(n+2)/n, this is O(log(2+n))W. Markov pays the exceptional set where this sum exceeds any allocated threshold; no weak-quasinorm summation is used. The alternative ell=log n/(2n), n>1, gives O(sqrt(n)log n)W.

There is a better cancellation when the signed sum is taken before the supremum. Because the old filter (3) is independent of a, it is linear in the common prior. Also nu_(2^(-s))^tensor n converges to delta_0^tensor n in total variation, with error 2[1-(1-2^(-s))^n]. Therefore

    sum_s Delta_(a_s)=Delta_*:=delta_0^tensor n-w^tensor n dz,
    sum_s O_(a_s,ell)=O_(*,ell), ||Delta_*||_TV=2,
    ||sup_t |O_(*,ell)(t)||_1<=2e^(-n ell)(1+nT)W.               (7)

At ell=log(n+2)/n, the last coefficient is bounded by 2 for all n>=1, since 1+n log2<=n+2. Equation (7) is an actual cross-layer cancellation with a common filter, not an assertion that sums of weak norms control a supremum. Absolute convergence of (6) also justifies the displayed signed sum on this window.

## 3. Exact fresh arrivals, survival, and age expiration

For fixed x define the marked signed arrival measure of a signed prior Delta by pushing forward

    f(y)exp(-n alpha(x,y,z)) dy Delta(dz)

under (y,z) -> (alpha,beta,y,z). It is denoted A_x(ds,de,dy,dz). The mark e=beta must be retained. The exact fresh process is

    F_(Delta,ell)(t,x)
      =integral_(t-ell<s<=t<e) exp[-n(t-s)] A_x(ds,de,dy,dz).     (8)

Survival t<e is essential: moving-noise packets can exit. Dropping it turns (8) into a different process, even before considering signs. There is no independent-increment or martingale assertion.

Let E_ell be the exit flux restricted to packets whose age at exit is <ell. Let R_ell be the expiration flux at t=alpha+ell, restricted to packets still alive then. Their signed weights at the relevant time t are f(y)e^(-nt)dy Delta(dz). Differentiating the interval indicators gives the exact distributional renewal equation

    (partial_t+n)F_(Delta,ell)=A-E_ell-R_ell.                   (9)

Here A is the arrival flux with no age restriction; a newly arriving packet is fresh when ell>0. A finite exit exactly at expiration may be assigned to either loss term, once, with a consistent half-open convention. This coincidence is negligible for the convolution identities. The exponential drift is n, not an invented hazard.

For completeness all these signed flows are locally finite after integration in dx. At fixed z, the expanding translated box e^t(z+Q) has weighted incoming face rate

    J_in(z)=sum_i[(z_i+1/2)_+ +(1/2-z_i)_+]
           =n+sum_i(|z_i|-1/2)_+.

This follows by integrating the positive normal velocity on its 2n faces; the e^(nt) face-motion factor cancels the density e^(-nt). Translation by y does not change the integral. Edges are null in the face measure. The total exit rate is sum_i(|z_i|-1/2)_+, and the difference is n, in agreement with mass conservation.

The E2 noise has integral |z|w(z)dz=2/3. Thus

    integral J_in(z)|Delta_a|(dz)<=n m_a+na,
    integral J_in(z)|Delta_*|(dz)<=2n+(2/3)n=8n/3.              (10)

These bounds certify integrability and are not claimed as square-root arrival fees. They also give a useful small *expiration* payment. An arrival at s=t-ell survives with weight multiplied by e^(-n ell), hence

    integral_0^T integral |R_ell|(dt,dx)
       <=e^(-n ell)T W integral J_in(z)|Delta|(dz).            (11)

For the actual telescoped Delta_* and ell=log(n+2)/n this is at most (8T/3)W. This is a strong total variation payment of the artificial age-expiration flux only. It does not bound the undiscounted incoming flux A or exit flux E_ell. Layer-by-layer application costs O(log n) with the same cutoff, using sum m_a<=2N+2 and sum a=2.

## 4. Relation to the actual hardface corridor equation

The R78 equation remains exact:

    u_a'=c_a+v_a-kappa_a u_a-gamma_a P_a,
    kappa_a=n(1-a/2), gamma_a=na/2, v_a=B_(a/2)-B_a convolved.

The full untruncated moving-source flux obeys

    A_a-E_a=c_a+v_a+n(a/2)u_a-n(a/2)P_a.                     (12)

Indeed substituting (12) into u_a'=A_a-E_a-nu_a gives the R78 equation term by term. Thus the moving-source flux is NOT the bare hardface c_a. The old adverse coarse-layer forcing has been incorporated exactly into this full flux; it has not been estimated away or declared free. Formula (12) is required whenever transferring a corridor estimate between the two representations.

Equations (7) and (11) show that the full soft-layer sum on this window can be studied through the actual fresh process with a paid old part and a paid expiration correction. For smooth f, and then for general L1 input by approximation, actual first-hit/last-half-hit corridors can be formed for this continuous fresh convolution. On one such corridor I=(rho,tau), with sign sigma and zeta=sigma F between eta/2 and eta, (9) gives

    eta/2+n integral_I |F|dt
       =sigma integral_I (A-E_ell-R_ell).                    (13)

Spatial integration of the R term over any collection of one corridor per receiver is bounded by (11), so it can be charged by Markov at a separately allocated threshold. The exact remaining object is the signed arrival-minus-recent-exit flux on these actual corridors, with restoring drift n|F| retained. For fixed z, the fresh kernel is the indicator of the fixed region (z+Q) minus its intersection with exp(-ell)(z+Q), followed by dilation. Its moving boundary consists of finitely many rectangular faces. The face-velocity parameterization of A and E, and the shifted-arrival parameterization of R, give L1(dx) densities with respect to dt; their norms are bounded by the integrable incoming/outgoing rates above. After integrating |Delta|(dz) and convolving with f, F therefore has an L1 space-time derivative and an absolutely continuous time representative for almost every receiver. The bounded fixed-region convolution also has the continuous representative obtained by uniform smooth L1 approximation. This direct dt-density argument is stronger than merely finite variation and absence of atoms (which alone would not exclude a singular continuous derivative). No stochastic stopping rule is used.

## 5. The exact remaining general hypothesis, and its limits

A sufficient next step would prove a weak volume payment O(sqrt(n) times polylog(n))W for the actual first-crossing corridors of F_(*,ell), after the old, expiration, anchor, and existing smooth terms have their reserved budgets. It must estimate

    sigma integral_I (A_*-E_(*,ell))

relative to eta and n integral_I|F|, using the same joint source and the true survival mark. No such bound is established here. A source-mass packing or posterior argument may use (8), but it must prove its needed receiver/source correlations rather than assume them.

This is a finite-age reduction, not a proof that the new source mass is small. Even the unshifted one-source gate z=0 has fresh kernel

    1_Q(x)-1_(exp(-ell)Q)(x),

of mass 1-exp(-n ell). At ell=log(n+2)/n this is 1-1/(n+2), near one. Thus the fact ell tends to zero does not supply a factor ell in a maximal bound. Summing fresh kernels first also telescopes; that algebra alone cannot solve the cube problem. The next theorem must use actual signed first crossings or a quantitatively paid exception rule, not a rewritten endpoint identity.

## 6. Three-stage reproducible guard

The guard below first checks exact rational common-mask coefficients. It then samples actual E2 latent noise (R=sqrt(U), Z=R times a symmetric unit exponential), constructs physical receivers inside the actual shifted box, and verifies gate intervals, exits, and old-to-earlier membership for both age cutoffs. These are deterministic identity checks on sampled tuples, not estimates of rare probabilities or the maximal constant. Finally it expands dimension and verifies the analytically proved all-layer fee formulas. Floating computations are diagnostics; they do not prove the open fresh-corridor hypothesis. Seed: 79041. The separate numeric agent tests actual E2 box convolutions and corridor equations.

```python
from fractions import Fraction as F
from itertools import product
from math import exp,log,sqrt,ceil,log2
import random
rng=random.Random(79041)
checks=0
# Stage 1: exact common-source mask coefficients and TV fee.
for n in range(1,9):
 for a in (F(1),F(1,2),F(1,16),F(1,1024)):
  cs=[]
  for mask in product((0,1),repeat=n):
   k=sum(mask)
   cs.append((a/2)**k*(1-a/2)**(n-k)-a**k*(1-a)**(n-k))
  assert sum(cs)==0 and sum(map(abs,cs))<=min(F(2),n*a)
  checks+=1
print('stage1 exact mask cases',checks)

def interval(d,z):
 lo=0.;hi=float('inf')
 for di,zi in zip(d,z):
  if di==0:
   if abs(zi)>.5:return None
  else:
   a,b=sorted(((zi-.5)/di,(zi+.5)/di))
   lo=max(lo,a);hi=min(hi,b)
 if hi<=lo:return None
 return (-log(hi),float('inf') if lo<=0 else -log(lo))

def gate(d,z,t):
 return all(abs(di*exp(-t)-zi)<=.5 for di,zi in zip(d,z))
# Stage 2: actual E2-noise construction and physical scale/source tuples.
seen=0;old=0;exits=0
for n in (1,2,8,32,128):
 for trial in range(100):
  a=(1,.5,1/n)[trial%3]
  z=[(1 if rng.random()<.5 else -1)*sqrt(rng.random())*(-log(max(rng.random(),1e-300))) if rng.random()<a else 0 for _ in range(n)]
  t=log(2)*rng.random()
  d=[exp(t)*(zi+rng.uniform(-.5,.5)) for zi in z]
  it=interval(d,z);assert it is not None
  alpha,beta=it;assert alpha<=t<=beta
  exits+=beta<float('inf')
  for age in (log(n+2)/n,log(max(n,1))/(2*n),.1):
   oldgate=alpha<=t-age
   if oldgate:
    assert gate(d,z,t-age);old+=1
   for tt in (t-age,t,t+age):
    assert gate(d,z,tt)==(alpha<=tt<=beta)
   # Exact damping relation evaluated away from endpoints.
   assert abs(exp(-n*t)-exp(-n*age)*exp(-n*(t-age)))<=1e-12
   seen+=1
print('stage2 actual E2 gate checks',seen,'old cases',old,'finite exits',exits)
# Stage 3: expanded dimension, all-layer and telescoped old/expiration fees.
for n in (1,2,4,16,256,4096,1048576):
 N=ceil(log2(n));S=2*N+2;age=log(n+2)/n
 fee=exp(-n*age)*(1+n*log(2))*S
 endpoint=2*exp(-n*age)*(1+n*log(2))
 expiration=exp(-n*age)*log(2)*8*n/3
 assert fee<=(1+n*log(2))/(n+2)*S*(1+1e-12)
 assert endpoint<=2 and expiration<=8*log(2)/3
 print('stage3 n',n,'age',age,'separate_old_fee',fee,'endpoint_old_fee',endpoint,'expiration_fee',expiration)
print('PASS: representation and paid branches only; fresh crossing estimate UNPROVED')
```


# R79 coverage: robust-low Fatou transfer from finite certificates

**Status.** The conditional transfer of a uniform finite-model certificate bound to the actual continuous E2 kernels, arbitrary finite input measures (hence L1 inputs), and the whole physical window [1,2] is proved below. No cheap-certificate existence theorem is proved. In particular, this does not complete the centered-cube weak bound. This file and its TeX companion are the only owned outputs; no Git or compilation.

The relevant A03/M04 boundaries were read: convergence and measurable choices are proved for this concrete construction, rather than inferred from a general compactness or selection claim. The R78 parent reduction and coverage interface were read. Parent R79 owns the quantitative, scale-uniform noise error; this component does not duplicate that result and does not assume quantized kernels are ray decreasing.

## 1. Preserve the actual positive joint source and every mask tag

Fix dimension n, a layer delta, and a finite family J={L_1,...,L_m} in [1,2]. Let mu be a finite positive input measure of mass W. For signed or complex input nu, use mu=|nu| and its measurable phase omega(y), |omega|=1 mu-a.e. The zero input is trivial. For a mask a in {0,1}^n retain the actual Bernoulli weights alpha_a at delta/2 and beta_a at delta. Put q_a=(alpha_a+beta_a)/2 and zeta_a=(alpha_a-beta_a)/q_a, omitting q_a=0. Conditional on a, coordinates of z are independent: delta_0 for a_i=0 and the true w(z_i)dz_i for a_i=1. The measure

    eta(dy,da,dz)=mu(dy) q_a rho_a(dz)

has mass W. Its coefficient is omega(y) zeta_a. The corresponding fields are

    T_L=L^(-n) integral omega(y) zeta_a 1{y+Lz in Q(x,L)} deta,
    F_L=L^(-n) integral 1{y+Lz in Q(x,L)} deta,
    C_L=L^(-n) integral |zeta_a|^2 1{y+Lz in Q(x,L)} deta.

These are exactly the E2 contrast, background and companion field, with |T_L|^2<=F_L C_L and C_L<=4F_L. The companion uses |omega|=1, so its total source mass is I_delta W, I_delta=sum q_a|zeta_a|^2.

Choose finite-range Borel maps Y_N:R^n->R^n converging pointwise to y, and coordinatewise finite-range maps Z_N converging pointwise to z, with Z_N(0)=0 and |Z_N(z)_i|<=|z_i|. For example use a mesh tending to zero inside a growing box, and send the exterior to zero. For complex inputs quantize omega to a finite subset of the unit circle, converging pointwise; for positive inputs it stays one. Push forward the entire common source by these maps, keeping a unchanged. Denote the resulting finite labelled source by eta_N.

All masses stay exactly W and I_delta W. Each conditional noise law remains a probability product law, with the original mask coefficients. Even when a soft noise point maps to zero, its mask label must NOT be merged with a hard-coordinate label; the coefficients zeta_a are different. Coincident physical sites with distinct phases are likewise allowed labelled sources. Combining complex phases first can reduce total variation, so the positive dominating source must remain the specified labelled mu_N of mass W. The R78 finite joint-source LP accepts precisely such labelled sources.

The affine price P(z)=1+n^(-1)sum_i(|z_i|-1/2)_+ does not increase under Z_N. Thus its K and J weighted moments do not increase. We make NO claim that the discretized convolution kernel is ray decreasing.

## 2. Pointwise convergence for each fixed finite physical family

For any fixed L, the exceptional receiver set on which eta assigns positive mass to the boundary of Q(x,L) has Lebesgue measure zero. Indeed, Tonelli gives

    integral_Rn eta{(y,a,z): y+Lz in boundary Q(x,L)} dx=0,

because for each source point the receiver boundary is a finite union of affine hyperplanes. For x outside this null set, almost every original source point is strictly inside or outside the cube. Pointwise convergence of Y_N and Z_N therefore makes its capture indicator converge. The phase and mask coefficients converge and are bounded by 2; the C coefficient is bounded by 4. Dominated convergence on the ORIGINAL common source proves

    T_N,L(x)->T_L(x), F_N,L(x)->F_L(x), C_N,L(x)->C_L(x).

Intersect the full-measure sets for the finitely many L in J. All three finite lists then converge simultaneously, so A_N=max_J |T_N,L| converges to A=max_J |T_L|, and H_N=max_J F_N,L converges to H=max_J F_L. This is stronger than merely asserting weak convergence, but needs no quantitative rate and no factor |J|. It does NOT assert convergence of a maximizing index or of certificate variables. The construction works for arbitrary finite mu without a spatial moment or source-count bound.

## 3. Robust-low event and the actual selected-low finite model

Use absolute thresholds tau>0 and B>0, and define

    E(tau,B;J)={A>tau, H<=B}.

For 0<epsilon<tau, convergence of the finite lists implies, almost everywhere,

    1_E(tau,B;J) <=liminf_N 1_E_N(tau-epsilon,B+epsilon;J).   (F1)

Both threshold margins matter. Let L_N(x) be the finite model's actual maximum-absolute-contrast scale, breaking ties by the smallest index. Then the robust event on the right is contained in the finite model's actual selected-low event

    E_N^sel={A_N>tau-epsilon, F_N,L_N<=B+epsilon}.

Thus a valid R78 mixed certificate for this entire selected-low event also bounds the event in (F1). No convergence of L_N is needed; a tie may switch between scales having different backgrounds. This is why selected-low alone is not used as the limiting event.

If a nonnegative certificate cost C_N has actually been proved to satisfy

    (tau-epsilon)|E_N^sel|<=C_N,

Fatou yields the unconditional implication

    (tau-epsilon)|E(tau,B;J)|<=liminf_N C_N.               (F2)

The assertion concerns weak volume bounds furnished by certificates. It does not claim that optimized certificate values are continuous, that duties converge, or that a finite certificate has a limiting common representative witness. If an infimum is not attained, use a certified value within 1/N of it. Finite source/cell counts may grow arbitrarily; only a uniform upper bound for the paid costs can survive the limit.

A concrete conditional corollary avoids any continuity hypothesis on a putative bound Gamma. Suppose all these finite labelled models admit valid certificates with cost at most Gamma(n,delta,2B/tau+1)W at thresholds tau/2 and B+tau/2. Then

    tau |E(tau,B;J)|<=2 Gamma(n,delta,2B/tau+1)W.         (F3)

The factor two and the inflated background ratio are explicit. If Gamma is locally right-continuous in that ratio and bounds every smaller slack, epsilon may instead tend to zero in (F2), eliminating the factor. Such regularity must be supplied, not presumed. No Gamma of the target size is proved here.

## 4. The robust-low reduction has no new high-background cost

For the TRUE E2 K kernel, not its atomic noise approximation, positivity, probability mass and ray monotonicity give

    integral max_J F_L <=(1+n log2)W.

The enlarged high-background event {max_J F_L>B} therefore costs at most lambda(1+n log2)W/B in lambda-volume. This is the same envelope budget already used in R78; dropping the extra contrast-crossing condition does not change this upper bound.

Specifically, with S=O(log n), tau=lambda/(4S), B=4sqrt(n)S lambda, the union of these enlarged high events across s<S has lambda-volume at most (1+n log2)W/(4sqrt(n)), exactly the R78 bound. Outside that union every scale in every layer has F_s,L<=B. Hence any original core crossing A_s>tau lies in the robust-low E_s. The ratio B/tau=16sqrt(n)S^2 remains explicit. The parent base, fine-tail and continuous-piece payments are unchanged. A certificate for the larger robust core events is a sufficient route; a certificate proved only on the smaller hard-face event needs its own transfer of that extra condition, which is NOT asserted here.

The enlarged high event is paid using the original kernel before this limit argument. No ray monotonicity of quantized phi or K is required. Alternatively the parent quantitative noise error can transfer this budget, but that is not needed for (F2).

## 5. Countable dense scales recover the whole physical window

This passage is made AFTER returning to the ORIGINAL continuous E2 kernel. The hard factor h(u/L) with closed endpoints is right-continuous as L decreases to a fixed positive L from above. The original soft factor phi=h*w is continuous; the same holds for h convolved with the integrable truncated noise density when that version is used. Therefore each original tensor/mask kernel, and its convolution with a finite input measure, is right-continuous in L on [1,2). Dominated convergence is legal because L>=1, the factors have bounded heights, and the source mass is finite. The compensation term H also has this right-continuity. We do not claim this property for every shifted atomic-noise gate.

Choose nested finite J_m whose union is dense from the right, including 1 and 2. Then pointwise

    max_Jm |T_L| increases to sup_[1,2]|T_L|,
    max_Jm F_L increases to sup_[1,2]F_L.

Thus the continuum suprema are measurable, without an unverified general measurable-selection theorem. Define E_infinity={sup|T_L|>tau, sup F_L<=B}. If x is in this event, a contrast crossing occurs in some finite J_m and the background condition holds in all of them. Consequently 1_Einfinity<=liminf_m 1_E(tau,B;J_m). Fatou passes any bound uniform in |J| from (F2) or (F3) to the complete [1,2] event. There is no union bound over physical scales. No continuum argmax or selected index is required.

The order is: fix finite J and threshold slack; atomize the common source and noise; pass N to infinity by Fatou; then grow the finite scale family; optionally send slack to zero under the stated bound regularity. No bound with source-count or |J| dependence is made uniform by changing this order.

## 6. L1 inputs, certificate semantics, and what remains

Every f in L1 defines a finite measure and is already covered by Sections 1–5. For complex f the labelled phase quantization retains its positive dominating source. There is no need to approximate f by atomic measures in total variation, which is generally impossible. The approximation is the common pushforward coupling just proved sufficient at fixed finite scales. For positive f the approximating physical measures themselves are positive finite atomic measures of exactly the same mass.

For each fixed N and J, R78's full rectangular arrangement of source-cube and representative-cube faces exactly represents the entire finite-model event, including its original maximum-contrast selector. One must include all event cells, not a sample. Exact weights of quantized true noise need not be rational; interval or rational weight certification is a separate computational matter. The analytic transfer permits real finite weights and does not declare floating quadrature to be an exact LP input certificate.

The proven bridge is: UNIFORM valid finite-model paid cost => genuine continuous E2 weak event bound => arbitrary L1 inputs => all scales in one physical window. It does not establish the first premise. In particular no dimension-only cheap mixed-certificate theorem, no continuum certificate witness, and no full-scale localization is supplied. The main sqrt(n)n^o(1) goal remains unproved.

## 7. Small deterministic guard

The guard checks three stages: actual hard-gate failure of a scale-uniform strong approximation; actual E2 endpoint/mask algebra under finite probability noise quantization and source quantization; and enlargement of finite physical families with explicit slack and mask invariants. The continuous noise probabilities and true phi fields use deterministic Simpson quadrature only as diagnostics. Exact rational arithmetic is used for the hard-gate geometry and the strict threshold-inclusion checks. The analytic Fubini/DCT/Fatou proof does not rely on quadrature accuracy or a fitted convergence rate.

```python
from fractions import Fraction as Q
from itertools import product
from math import exp
checks=0
def ck(x):
 global checks
 assert x
 checks+=1
# Stage 1: genuine hard gates; growing families defeat uniform strong error.
for m in (4,8,16):
 h=Q(1,8*m);Ls=[Q(1)+Q(j,m) for j in range(m)]
 faces=sorted(set(c+s*L/2 for c in (Q(0),-h) for L in Ls for s in (-1,1)))
 integral=Q(0)
 for a,b in zip(faces,faces[1:]):
  x=(a+b)/2
  val=max(abs(Q(int(abs(x)<=L/2),1)/L-Q(int(abs(x+h)<=L/2),1)/L) for L in Ls)
  integral+=(b-a)*val
 ck(integral>=Q(1,16))
 print('hard_gate scales=%d source_shift=%s max_difference_L1=%s'%(m,h,integral))

def simpson(f,N=256):
 return (f(0.)+f(1.)+sum((4 if j%2 else 2)*f(j/N) for j in range(1,N)))/(3*N)
def wtail(x):
 return simpson(lambda v:0. if v==0 else v*exp(-x/v))
def phi(x,N=256):
 x=abs(float(x))
 def fun(v):
  if v==0:return 0.
  if x<=.5:f=1-(exp(-(.5-x)/v)+exp(-(.5+x)/v))/2
  else:f=(1-exp(-1/v))*exp(-(x-.5)/v)/2
  return 2*v*f
 return simpson(fun,N)
def noise(K,R):
 # True w-bin probabilities: inward quantization, tail sent to zero.
 h=Q(1,K);pos=[]
 for j in range(1,K*R):
  mass=wtail(j/K)-wtail((j+1)/K)
  pos.append((j*h,mass))
 out=[(Q(0),1-2*sum(p for z,p in pos))]
 out +=pos+[(-z,p) for z,p in pos]
 ck(all(p>=0 for z,p in out));ck(abs(sum(p for z,p in out)-1)<1e-12)
 ck(sum(float(abs(z))*p for z,p in out)<=2/3+1e-10)
 return out

def fields(hv,pv,n):
 delta=Q(1,2);A=B=C=0.;Imass=Q(0)
 for mask in product((0,1),repeat=n):
  a=b=Q(1);kernel=1.
  for j,bit in enumerate(mask):
   a*=delta/2 if bit else 1-delta/2
   b*=delta if bit else 1-delta
   kernel*=pv[j] if bit else hv[j]
  q=(a+b)/2;jmass=(a-b)**2/q
  A+=float(a)*kernel;B+=float(b)*kernel;C+=float(jmass)*kernel;Imass+=jmass
 T=A-B;F=(A+B)/2
 ck(T*T<=F*C+1e-12 and C<=4*F+1e-12)
 return T,F,C,Imass
# Stage 2: true E2 fields and probability-preserving quantized noise.
slack_checks=0
for n,K,R,m in ((1,4,2,3),(2,8,3,5),(3,16,4,9)):
 nodes=noise(K,R);Ls=[Q(1)+Q(j,m-1) for j in range(m)]
 x=[Q(2+j,13) for j in range(n)];orig=[];approx=[]
 err=0.;refine=0.
 for L in Ls:
  hv=[float(Q(int(abs(xx)<=L/2),1)/L) for xx in x]
  pv=[phi(xx/L)/float(L) for xx in x]
  qv=[sum(p for z,p in nodes if abs(xx-L*z)<=L/2)/float(L) for xx in x]
  f=fields(hv,pv,n);g=fields(hv,qv,n)
  ck(f[3]==g[3]);orig.append(f);approx.append(g)
  err=max(err,max(abs(a-b) for a,b in zip(f[:3],g[:3])))
  refine=max(refine,max(abs(phi(xx/L,512)-phi(xx/L,256)) for xx in x))
 # Exact arithmetic tests the threshold-slack implication on recorded lists.
 T=[Q(str(a[0])) for a in orig];F=[Q(str(a[1])) for a in orig]
 TN=[Q(str(a[0])) for a in approx];FN=[Q(str(a[1])) for a in approx]
 eps=max([abs(a-b) for a,b in zip(T,TN)]+[abs(a-b) for a,b in zip(F,FN)])+Q(1,10**10)
 A=max(map(abs,T));B=max(F);tau=A/2
 if eps<tau:
  ck(max(map(abs,TN))>tau-eps and max(FN)<=B+eps);slack_checks+=1
 print('E2 n=%d scales=%d noise_nodes=%d max_field_error=%.6g quadrature_refinement=%.3g I=%s'%(n,m,len(nodes),err,refine,orig[0][3]))
ck(slack_checks>=1)
# Stage 3: general L1 source example, uniform interval, atomized independently.
def phicdf(t):
 def fun(v):
  if v==0:return 0.
  def G(s):return (v/2)*exp(s/v) if s<=0 else s+(v/2)*exp(-s/v)
  return 2*v*(G(float(t)+.5)-G(float(t)-.5))
 return simpson(fun)
for K in (4,8,16):
 nodes=noise(K,2+K//8);ys=[Q(-1)+Q(2*j+1,K) for j in range(K)]
 err=0.
 for x,L in product((Q(0),Q(7,8),Q(11,8)),(Q(1),Q(3,2),Q(2))):
  htrue=float(max(Q(0),min(Q(1),x+L/2)-max(Q(-1),x-L/2))/(2*L))
  ptrue=(phicdf((x+1)/L)-phicdf((x-1)/L))/2
  hq=sum(abs(x-y)<=L/2 for y in ys)/(K*float(L))
  pq=sum(p for y in ys for z,p in nodes if abs(x-y-L*z)<=L/2)/(K*float(L))
  f=fields([htrue],[ptrue],1);g=fields([hq],[pq],1)
  err=max(err,max(abs(a-b) for a,b in zip(f[:3],g[:3])))
 print('L1_source source_atoms=%d noise_nodes=%d actual_E2_field_error=%.6g'%(K,len(nodes),err))
print('PASS checks=%d; exact hard geometry/slack; quadrature diagnostics only'%checks)
```

Executed output:

```text
hard_gate scales=4 source_shift=1/32 max_difference_L1=319/1680
hard_gate scales=8 source_shift=1/64 max_difference_L1=52279/288288
hard_gate scales=16 source_shift=1/128 max_difference_L1=7313175618421/41258157969600
E2 n=1 scales=3 noise_nodes=15 max_field_error=0.0526977 quadrature_refinement=9.15e-13 I=4/15
E2 n=2 scales=5 noise_nodes=47 max_field_error=0.037553 quadrature_refinement=9.16e-13 I=228/455
E2 n=3 scales=9 noise_nodes=127 max_field_error=0.023268 quadrature_refinement=2.3e-12 I=41884/58905
L1_source source_atoms=4 noise_nodes=15 actual_E2_field_error=0.156213
L1_source source_atoms=8 noise_nodes=47 actual_E2_field_error=0.0560963
L1_source source_atoms=16 noise_nodes=127 actual_E2_field_error=0.0108266
PASS checks=130; exact hard geometry/slack; quadrature diagnostics only
```


# Round 79: actual common-source age pressure

The registered candidate is the source-age split chosen by the hard-face and soft agents. It retains the actual E2 latent law, positive L1 inputs, physical scale window, and Lebesgue receiver measure. Six adjacent-layer cases and three telescoped-endpoint cases complete three pressure stages; a tenth registered case preserves the unstable endpoint pilot. The tests do not prove or disprove the remaining weak maximal estimate for fresh signed arrivals. In particular, a finite sampled prior introduces fluctuations and discontinuous paths that the original continuous box-input convolution does not have.

## Candidate and what is computed

Write \(\psi_a=h*\nu_a\), with \(\nu_a=(1-a)\delta_0+a w(z)\,dz\) and \(w(z)=\int_0^1e^{-|z|/t}dt\). For a source point \(y\), latent vector \(z\), and original receiver \(x\),
\[
G_L(x,y,z)=\mathbf1\{|(x-y)/L-z|_\infty\le1/2\}.
\]
The positive physical scales at which this gate holds form a single closed interval \([A,B]\), allowing \(A=0\), \(B=\infty\), or an empty interval. The entry is global on \(L>0\), rather than reset at the beginning of the window.

Set \(r=e^h=(n+2)^{1/n}\), \(h=\log(n+2)/n\). The old contribution at scale \(L\) includes \(A\le L/r\) and \(L\le B\). The fresh part is the remainder. For adjacent \(u=P_{a/2}-P_a\), use the same original source \(y\), activation uniforms \(U_j\), and actual E2 noise \(Z_j\) for both endpoints: \(z_{a,j}=Z_j\mathbf1_{U_j<a}\), \(z_{a/2,j}=Z_j\mathbf1_{U_j<a/2}\). No receiver-dependent choice of this latent prior is made.

The gate interval implies pointwise
\[
P_a^{\rm old}(L,x)\le r^{-n}P_a(L/r,x),\qquad r^{-n}=1/(n+2).
\]
The companion theory sharpens the old signed contrast payment using the actual mask total variation
\[
m_a=\sum_{k=0}^n\binom nk\left|(a/2)^k(1-a/2)^{n-k}-a^k(1-a)^{n-k}\right|,
\]
so its one-layer strong window cost is at most
\[
\frac{1+n\log2}{n+2}\,m_a W.
\]
The JSON records the exact rational \(m_a\); decimal evaluations of the logarithmic bound are approximate, not outward intervals. The all-layer payment is an analytic result of the companion component. The six original cases register one adjacent layer per input. The added endpoint cases test the actual telescoped prior \(\Delta_*=\delta_0^{\otimes n}-w^{\otimes n}\,dz\), with \(b=0,a=1\), rather than a finite numerical layer sum. It has exact TV mass two. Its true old strong-window upper is \(2(1+n\log2)W/(n+2)\), at most \(2W\). No infinite layer union is estimated numerically.

The moving-latent arrival flux includes the full velocity flux. It is not labeled as the original hard-face term \(c\) alone. The present test does not assert a martingale, stopping-time, occupation-measure, or independently paid source budget for fresh arrivals.

## Actual L1 inputs and physical density

Each input is a positive mixture of normalized product boxes, with halfwidth \(\epsilon_i>0\), center \(y_i\), and probability mass \(p_i\). Its total L1 norm is the listed \(W\). Sampling the original source within these boxes preserves an L1 input; it does not substitute a finite atomic source for the true baseline convolution.

| Stage | Input | n | Centers | Halfwidths | Mass fractions | W | a | Receivers / latent samples per batch |
|---|---|---:|---|---|---|---:|---:|---:|
| pilot | one box | 1 | 0 | 1/4 | 1 | 1 | 1/2 | 24 / 256 |
| pilot | one box | 2 | (0,0) | 1/4 | 1 | 1 | 1/2 | 32 / 256 |
| pressure | four separated boxes | 2 | all (±3/2,±3/2) | 1/8 | 1/4 each | 1 | 1/2 | 64 / 512 |
| pressure | two correlated boxes | 4 | diagonal −1/2,+1/2 | 1/8,1/4 | 1/3,2/3 | 1 | 1/4 | 64 / 512 |
| expanded | eight unequal microboxes | 4 | diagonal j/4, j=−4,…,3 | 1/32 | 1/36,…,8/36 | 3 | 1/8 | 64 / 1024 |
| expanded | four correlated boxes | 8 | diagonal −1,−1/2,+1/2,+1 | 1/8 | 1/10,2/10,3/10,4/10 | 1 | 1/8 | 64 / 1024 |

For a one-coordinate source box, the hard convolution is the actual interval overlap divided by \(2\epsilon L\). The soft convolution is
\[
\frac1{2\epsilon}\int_{(x-y-\epsilon)/L}^{(x-y+\epsilon)/L}\phi(v)\,dv,
\quad \phi=h*w.
\]
The added endpoint pilot/pressure/expanded registrations reuse respectively the n1 single box, n4 two correlated boxes, and n8 four correlated boxes above, with \(a=1,b=0\). They use 48/96/128 receivers and 512/1024/2048 latent samples per batch. The preserved n8 initial pilot uses 64 receivers and 1024 latent samples per batch.

The script evaluates this integral using the actual Laplace-mixture formula for the CDF of \(\phi\), with 64 Simpson panels. Its 64/128-panel spot refinement difference in the contrast is at most \(1.697\cdot10^{-7}\). This is a diagnostic, not a certified quadrature error. The hard source-support breakpoints \(L=2|x_j-y_{i,j}\pm\epsilon_i|\) are calculated as exact rationals for each machine receiver and included in the baseline scale library alongside \(1+j/32\), \(j=0,\dots,32\). The baseline registered-grid maximum is not an exact scale supremum or an upper bound for it.

## Original dx and shared sampling

Adjacent-layer receivers and the preserved endpoint pilot are sampled from
\[
q(x)=\frac{P_{a,1}(x)+P_{a,3/2}(x)+P_{a,2}(x)}{3W}.
\]
For the three refined endpoint cases, the proposal is instead the equal mixture of \(P_0\) and \(P_1\) at those three physical scales, divided by \(6W\). Both endpoint densities and the hard source mass remain represented. The exact registered softness parameters and physical scales are structured fields in the JSON.

Choose one of the three physical scales, sample a source from the registered box mixture, and sample the actual \(\psi_a\) coordinate as a hard uniform plus activated noise. Noise is generated by a Laplace law at scale \(T=\sqrt U\), whose mixing density \(2t\) gives exactly \(w\) in ideal arithmetic. The receiver remains a physical \(x\). Integrands are divided by the evaluated \(q(x)\); they are not integrated against \(f(x)dx\).

Each case has a single registered receiver cloud and two independently seeded latent-prior batches. The common batch is reused across all receivers and all scales of that case. For the finite prior, every gate entry \(A\), gate exit \(B\), and old entry \(rA\) in \([1,2]\) is enumerated. Entry precedes exit at a closed tied face; right limits are retained for the supremum inside the window. The right limit after an exit at \(L=2\) is excluded. This is a complete finite-latent event enumeration in machine arithmetic, not an exact E2 maximum. The exact finite-count identity is total = old + fresh at each evaluated state.

A conditional receiver SE measures the random receiver integration of this fixed sampled functional. It omits latent-prior sampling error, quadrature error, and machine-law effects. Two independent prior batches expose some of that extra variation; they are not rigorous confidence bounds. The \(2^{-53}\) logarithm floor and finite random-generator law are explicitly retained as diagnostic limitations.

## Pressure findings

All L1 estimates in the following table are divided by \(W\). The fresh estimates show conditional receiver SE; old entries show the two batch means. “Baseline” is the actual-kernel quadrature evaluated on the registered scale library. All decimal entries are approximate.

| Input | Baseline total grid-max L1/W | Fresh batch 1 ± SE | Fresh batch 2 ± SE | Old batches 1 / 2 | Analytic one-layer old upper/W |
|---|---:|---:|---:|---:|---:|
| one box n1 | 0.30805 | 0.35724 ± 0.05613 | 0.33342 ± 0.04648 | 0.06903 / 0.05840 | 0.28219 |
| one box n2 | 0.48893 | 0.55930 ± 0.05649 | 0.63159 ± 0.08088 | 0.07862 / 0.07620 | 0.37286 |
| four separated n2 | 0.56856 | 0.59641 ± 0.05376 | 0.56231 ± 0.04818 | 0.10680 / 0.10996 | 0.37286 |
| two correlated n4 | 0.53315 | 0.78961 ± 0.07349 | 0.62057 ± 0.06135 | 0.11240 / 0.11432 | 0.33925 |
| unequal micro n4 | 0.36057 | 0.38715 ± 0.04968 | 0.43124 ± 0.08093 | 0.07307 / 0.08008 | 0.23427 |
| four correlated n8 | 0.85896 | 1.12260 ± 0.12794 | 1.33677 ± 0.21174 | 0.20152 / 0.13343 | 0.33133 |

For the adjacent-layer cases, the sampled fresh part typically accounts for most of the sampled total maximal value; the sampled old part is smaller in these fixtures. This is pressure information, not a proof of either trend for arbitrary inputs. In dimension eight, the finite-prior total-max estimates are 1.17677 and 1.33386, compared with baseline 0.85896. Finite-prior fluctuations, nonlinear maximization, and baseline scale discretization all contribute to this difference. It cannot be read as a continuum lower-bound certificate, an age-split failure, or evidence that the exact fresh component exceeds a proven weak budget.

The actual telescoped endpoints use TV=2 and are reported separately:

| Endpoint input | Baseline total grid-max L1/W | Fresh batch 1 ± conditional SE | Fresh batch 2 ± conditional SE | Old batch 1 ± SE | Old batch 2 ± SE | True old analytic upper/W |
|---|---:|---:|---:|---:|---:|---:|
| one box n1 | 1.15860 | 1.07137 ± 0.09740 | 1.09058 ± 0.10463 | 0.17647 ± 0.02055 | 0.16764 ± 0.01944 | 1.12876 |
| two correlated n4 | 2.97682 | 4.57808 ± 0.74237 | 3.53537 ± 0.24777 | 0.44942 ± 0.04995 | 0.42810 ± 0.04898 | 1.25753 |
| four correlated n8 | 4.73740 | 6.21851 ± 2.01365 | 9.78497 ± 3.29410 | 0.39860 ± 0.08715 | 0.36200 ± 0.05205 | 1.30904 |

The endpoint initial pilot is retained as `endpoint_legacy_correlated_four_n8`: receiver seed 791800, prior seeds 792800/792801, 64 receivers, 1024 latent samples per batch, and the pure \(P_1\) three-scale proposal. Its old L1 estimates are 5.27718 ± 3.70859 and 0.28869 ± 0.18861; its fresh estimates are 27.54952 ± 11.18449 and 5.24969 ± 2.09041. This is an explicit numerical instability, not a counterexample to the true old upper 1.30904. A finite sampled prior generally lacks the centered-rectangle-mixture/ray-decreasing property of the continuous E2 prior. The same analytic envelope bound therefore need not hold for that sampled functional, even if its conditional receiver integral were exact. Finite-prior maximum fluctuations and sparse importance weights are visible here. The refined proposal and larger batches improve the old estimates, but no sample is required to fall below the true analytic bound.

At threshold \(\eta/W=1/32\), the refined endpoint n8 fresh weak estimates are 0.43016 ± 0.09946 and 0.41787 ± 0.09429; its old estimates are 0.02231 ± 0.01131 and 0.01737 ± 0.01024. The preserved pilot fresh estimates are 1.82782 ± 1.82782 and zero. The refined fresh L1 estimates still vary widely between batches. These diagnostics neither certify a weak budget nor establish an obstruction.

The registered weak thresholds are \(\eta/W\in\{1/64,1/32,1/16,1/8\}\). The JSON saves conditional estimates of \(\eta|\{\max|u^{\rm part}|>\eta\}|/W\) for total, old, and fresh. At \(\eta/W=1/32\), fresh batch estimates are 0.08246 ± 0.02235 and 0.05079 ± 0.01740 for four separated boxes; 0.06198 ± 0.01821 and 0.05766 ± 0.01686 for the two correlated n4 boxes; and 0.03259 ± 0.01595 and 0.02496 ± 0.01422 for the four correlated n8 boxes. The old estimates in the last case are both zero because no sampled receiver crossed this threshold; zero is not an exact volume statement.

No exponent is fitted in source count, dimension, input norm, or softness. The registered cases, limited receiver clouds, the registered adjacent/endpoint contrasts, and physical window \([1,2]\) cannot settle the original goal or the general fresh-arrival interface. No first-hit corridor or selector is manufactured from unrelated receiver data; the new chosen target is the actual global-age representation of the same source convolution.

## Checks, counts, and reproduction

The exact finite geometry guard performs 600 rational gate-membership comparisons and 49 old-before-gate implications, including both \(h=\log(n+2)/n\) and the alternative \(h=\log n/(2n)\). Their rational age comparisons are respectively \((n+2)A^n\le L^n\) and \(nA^{2n}\le L^{2n}\). The initially mistyped exponent in the optional alternative guard was corrected after independent review; the main full-log experiment was unaffected.

The final production record contains ten registered cases on six genuine input templates, 648 physical receiver draws, 20 latent batches, 16,384 source/noise vector draws, 90,624 noise coordinates, and 1,323,008 receiver–latent evaluations. Across the sampled receiver paths there are 413,947 distinct event-time evaluations and 209,415 old-before-gate checks. Event times can repeat across receivers/batches, and these counts are not continuous integration counts. Seeds are receiver \(791000+100i\) and prior \(792000+100i+j\), case \(i=0,\dots,8\), batch \(j=0,1\). The preserved tenth legacy case reuses seed index eight to regenerate the original pilot exactly. Registered source parameters, sampled-functional examples, physical support breakpoints, batch statistics, and seeds are saved; the full prior and receiver clouds are regenerated from these seeds.

From the extracted script directory:

```sh
python3 -B corridor_probe.py
```

The standalone program uses only the standard library. Production used bundled Python 3.12.14, exited zero, and took 15.789712 s. `PASS` refers to the finite geometry and regression checks, not certification of continuous integration or the fresh weak maximal claim.

Frozen code SHA256: `e6dfefd7788a3010aec8428ab1e4012522d18d1e40a82a4af67935a948d29544`.

Frozen results SHA256: `66893e656b16ce5124518c7cc2b64ccb03236aaf97e9c7fa405031cfe1092452` (100,993 bytes).

The final extended record was independently replayed in a temporary directory: exit zero, empty stderr, 15.648860 s wall time (15.608642 s internally), and byte-identical results with the frozen final source and result hashes. The earlier adjacent-only replay is superseded by this completed extended receipt.


# 第79轮独立审计：辅助转移与已付分支通过，主界未闭合

本轮冻结数学稿与数值范围通过独审。真实 E2 噪声量化得到尺度数量无关的强误差预算；fixed-family common-source Fatou bridge、intrinsic overlap 例外支付、old/expiration 年龄分解均合法。主 sqrt(n)n^{o(1)} 弱型界仍未证明：cheap finite-model certificate 的一般存在性、balanced-source forcing、fresh signed arrival/exit crossing 及全尺度闭合仍未付。本审计只写 audit.md、audit_guard.py，不改他人文件，无 Git、TeX/PDF 编译。

按 A02/L03 的已有来源与认证边界核对：保持一个原输入共同产生的来源，逐点正支配在原 Lebesgue receiver 积分下支付；有理几何与预算、真实连续积分的数值近似和随机估计分别说明。没有从技能名称、浮点 PASS、有限采样或新记号推出主定理。

## 1. 噪声耦合与全部层常数

parent_quantization.md 的(P1)–(P9)通过独立推导。q(z)在|z|≤R向零取整、尾部送零，故|q(z)|≤|z|且内部位移<η；w_q是完整概率pushforward，不是重新归一化的截断密度。保留尾部零原子尤其重要。

对同一Z的两closed hard gates，内部mismatch只出现在x±1/2的η邻域，总长度≤4η，其中|Z|≥(|x|−1/2−η)_+。尾部直接付p_R h(x)与原tail capture。后者在|x|≤R−1/2为零，在外侧≤φ(x)，故plateau φ(max(|x|,R−1/2))有效。该论证包括量化原子的closed-gate跳点，不只是在数值网格上成立。

e的三项均非负、偶且射线非增。第一项积分准确为8η(1+η)，因为w(0)=1、∫_0^∞w=1/2；p_R≤e^-R，φ(u)≤e^(1/2−u)给tail plateau积分≤(2R+1)e^(1−R)。于是 E≤8η(1+η)+e^-R+(2R+1)e^(1−R)。φ_q自身可有向上staircase跳跃，不能据此给它射线包络。

独立product telescope用ψ_aq≤ψ_a+a e，对差的每一项取上界，得到正乘积和 V_a，质量准确为(1+aE)^n−1；各项皆射线非增。nE≤1时exp界给质量≤3naE。闭窗口[1,2]的每个中心rectangle envelope系数为S_n=1+nlog2，layer-cake/Tonelli对各正乘积和及μ卷积延伸，因此不会引入|J|、noise-node数、source数或层深度。对有限输入测度先有有限/可数scale结论；L¹输入的kernel dilation连续和一致平滑逼近给连续窗口版本。没有把所有shifted atomic gates都当右连续。

α_m、β_m、q_m、ζ_m原标签完全保留，即使soft noise量化到零，也不能与hard mask合并后重置ζ。核质量D_q=0、K_q=1、J_q=I_δ准确；labelled Cauchy给|D_q|²≤K_qJ_q和J_q≤4K_q。这属于潜变量正源，不需要观察receiver后坐标仍独立。

D一层误差≤(9/2)nδE S_nW，K一层≤(9/4)nδE S_nW；Σq_m|m|=3nδ/4、j_m≤4q_m给J一层≤9nδE S_nW。全部δ_s=2^-s的有限和与无限尾Σδ=2，故D/K/J全层系数依次为9、9/2、18。这是强L¹正误差函数相加，不是平均weak quasi-norm。

(P8) prescribed tolerance常数正确：E*=ε/(18nS_n)、η≤E*/32令local项≤E*/2；tail≤2(R+1)e^(1−R)≤4e e^-R/2，而R≥2+2log(8/E*)使其≤E*/2。故nE≤1且三项总误差≤εW/2、εW/4、εW。P(qz)不增只保noise moment/代表价格；并不把量化核变为射线递减。

## 2. Source atomization、ties 与窗口返程

弱source收敛没有相同的scale-uniform强max误差。μ_ε=δ_ε到δ_0、x∈[3/4,1]、L=2x−ε的实际hard gate差≥1/2，积分≥1/8；finite family随ε加密仍可保该下界。这不反驳连续noise量化的边界majorant，也不妨碍fixed finite J的Fatou bridge。

coverage §1–6通过独审。Y_N、Z_N及unit-circle phase的共同有限pushforward保留原mask，K正源质量W和J正源质量I_δW。复phase不得先抵消再把正来源重命名；同一物理点的不同phase/mask允许保持不同标签。真实noise atom质量可能为实数，有限模型的解析LP定义合法，但计算证书若用有理/interval权重须另作认证。

对fixed L，Tonelli使原source落在receiver cube边界的mass-positive receiver集合为dx-null。对finite J同时DCT后，T/F/C列表及A=max|T|、H=maxF收敛；不用winner index收敛。实际 robust-low E={A>τ,H≤B}在双阈值slack下最终包含于近似robust event，其又包含于近似actual selected-low event。Fatou方向准确为(τ−ε)|E|≤liminf C_N。选择τ/2、B+τ/2给(F3)明确factor2与比值2B/τ+1；若想去factor，必须补所述right-continuity，不能默认。

支付maxF高背景用原TRUE E2 K的S_n概率包络；跨S层B=4sqrt(n)Sλ令S取消，费用仍S_nW/(4sqrt(n))。此时所有尺度都低背景，ties不能把近似selector跳到一个未受控制的高F尺度。只在较小face event上有certificate不能无说明替代robust core event。

返原核后，hard closed因素随L从右逼近右连续，soft φ连续，有限输入测度DCT成立；dense-right有限族包含端点1、2，递增最大值返完整window sup。robust continuum event指示受finite event liminf支配，第二次Fatou不需对scale union收费。原始soft/hard核的这一性质没有套给任意shifted atomic-noise gate。顺序必须是fixed J/slack→共同source atomization→返真实核→增密J；uniform cheap certificate这一前提本轮未证明，bridge不产生廉价见证。

## 3. Intrinsic overlap 是真实已付分支

soft(3)–(14)通过独审。真实outside φ质量θ=2∫_0^1r²(1−e^-1/r)dr≥1/3，由e>2即可。单坐标affinity满足1−r_a≥aθ(1−1/sqrt2)²/2≥c_*a，c_*=(1−1/sqrt2)²/6。实际kernel产品独立及min(v,w)≤sqrt(vw)给 ∫M_a≤e^-c_*na。M_a=min(Ψ_a,Ψ_b)虽不是product，但射线非增，原正kernel recurrence给S_n包络。独立性只属于kernel，不限制f。

coarse dyadic x_s=na_s>sqrt(n)的指数和≤1/(e^(c_*sqrt(n))−1)，故所有coarse overlap max按O(sqrt(n))一次强支付。全层nonselected forcing Q_s=(na_s/2)∫ f*M_a dt质量≤d_sW，d_s=T x_s e^-c_*x_s/2。disjoint [x_s/2,x_s]给Σd_s≤T/c_*；sqrt项积分给 Z=Σsqrt(d_s)≤2sqrt(πT/c_*)。因此ordinary Markov/union费用8Z²W≤32πT/c_* W，dimension独立。有限深度只减小费用；主threshold若不同，必须显式给ω_s所需固定比例，不能消去这个依赖。

源wise Hahn必须在卷积前做：Ψ_a=M+D^-、Ψ_b=M+D^+，m=f*M、p=f*D^+、q=f*D^-，u=p−q。m一般不等于min(P_a,P_b)。负corridor z=q−p，P_a=m+z+p，将恢复系数准确降为n(1−a)。除已付overlap外仍有γp。posterior π_+=p/(p+q)≤(1−a)/(2−a)等价于p≤(1−a)q，恰可半吸收；balanced时间的γp明确未付。

在负corridor，p=C_mix=(f*|D|−|f*D|)/2；一般C_mix=min(p,q)，逐时间积分为(||D||₁W−||u||₁)/2。它正是跨source混合消去，单凭质量仍可给na尺度费用。真实两source balancing weights及L¹mollification说明π_+可趋1/2，不得由kernel signs disjoint来假设(11)。a=1降低后的恢复为零，必须按smooth base另付，并给top layer固定threshold比例；用指数小ω_0当唯一top阈值不成立。

## 4. Age old/fresh 与 delayed expiration

hardface(1)–(13)通过独审。每个fixed(y,z,x)的原affine cube gate在L>0只有一个闭interval[A,B]，可空或无界；old定义用全域entry，不在窗口开始重置年龄，并始终保current survival。interval性给 G_t1{α≤t−ℓ}=G_tG_(t−ℓ)。所以old≤e^-nℓ f*K_a at t−ℓ；shifted窗口[-ℓ,T−ℓ]的ratio仍2。

K_a=H*|Δ_a|是真实连续noise的positive product mixture，m_a=||Δ_a||_TV为准确binomial mask差≤min(2,na)。各层分别max的old费为e^-nℓ S_nΣm_aW=O(log n)W。相反共同old filter独立于a，若先signedsum、再sup，则ΣΔ_a=δ_0−w^n、TV=2，old費≤2e^-nℓ S_nW≤2W（ℓ=log(n+2)/n）。这个改进不能用于已各自选择不同scale的private层max。

marked fresh表示保留entry及exit：积分条件t−ℓ<s≤t<e。分布式renewal为(∂t+n)F=A−E_ℓ−R_ℓ；age恰等exit的损失必须只算一次。incoming正常面速度率 Jin(z)=n+Σ(|z_i|−1/2)_+；outgoing率为后项，两者差n。∫|z|w=2/3给telescoped prior的incoming总价≤8n/3。age expiration折扣e^-nℓ=1/(n+2)，因此窗口强TV费≤8T W/3。未打折incoming与recent exit仍未付，不因寿命短而免费。

本审计要求补全了任意L¹输入的AC证明：finiteTV且无time atoms本身只给continuous BV，不能排除Cantor singular。修后fresh是固定region (z+Q)\[(z+Q)∩e^-ℓ(z+Q)]的dilation；面velocity给对dt的L¹(dx)通量density，integrate|Δ|并卷积f后time导数属于L¹时空，故a.e.receiver有W^{1,1}代表。这是合法理由，无stochastic stopping假设。

full moving flux与原R78 hardface c关系必须保留：A−E=c+v+n(a/2)u−n(a/2)P_a。原κ/γ方程逐项返回，不能把moving signed flux称为c。fresh first-hit/last-half-hit corridor保n|F|恢复及same input/generated corridor；其signed A−E_ℓ的弱体积支付仍未证明。即使z=0，fresh kernel质量1−e^-nℓ≈1，ℓ趋零不提供免费ℓ因子。

## 5. 数值终稿与修复记录

quantization_probe.py的actual E2 bin概率、尾部零原子、完整closed endpoints与非monotone实例正确。它的浮点Simpson weights不是外包围证书。36个signed源实例以给定μ≥|ν|作误差预算并沿 ORIGINAL true contrast selector评估量化差；所用positive源质量不能误称总signed variation。288个Fraction通用product algebra、72个mass实例、18个完整有限和加无限尾、3个actual hard-source shift警告认证各自精确有限命题，不认证真实φ点值。

corridor最终十案例为6个adjacent layers、3个refined telescoped endpoints及1个registered legacy endpoint；648 receivers、20 batches、16384 latent vectors。实际baseline为positive L¹box-mixture的真实Laplace φ-CDF quadrature，在注册physical library和source-support faces取max；它不是exact continuum supremum或rigorous lower bound。有限prior path列出全部machine entry/exit/old-entry，closed entry-before-exit、窗口内部right limits、L=2外侧right limit不计的规则正确。

发现并已修的具体代码问题：optional age=log n/(2n)几何guard原用power2，应为2n；主full-log实验未受影响。最终使用 nA^(2n)≤L^(2n)。另审过box hard overlap/(2εL)、soft φ积分/(2ε)归一化。

接收点 proposal采用记录的softness list与三个physical scales；相邻层用[a]，refined endpoint用[b,a]均匀组合。原receiver为物理x，权重1/q保持dx；共同prior的y/U/Z贯穿全部receivers/scales，真实理想E2 law由Laplace scale sqrt(U)生成。机器RNG与log floor、CDF quadrature、finite prior误差均未被SE覆盖。conditional receiver SE只描述固定sampled functional的receiver随机性；两prior batch不同，receiver cloud共同。

finite empirical prior不必是centered rectangle/ray mixture，故真实continuous old界不能直接用作sampled functional的确定性上界。legacy n8 pure-P1 proposal的old/fresh估计失稳保留在最终JSON/报告，不作弱界反例或数学certificate。refinedproposal改善覆盖也不产生continuum证明。kernel/threshold/scale集、seeds与failed development record均有范围说明。

## 6. 独立运行与归档可移植性

独审不import生产主函数。独立Fraction coupling：5292 joint gates，其中204个closed quantized mismatch；2040个mask rows；320个affine interval fixtures/10502 membership checks/618 old-retention checks；67个old-fee dimensions；28个tensor majorant与24个generic overlap/posterior/source-mix实例，8个rational exponential-tail预算维数。后者为精确表达式与预算检查，不替代解析普遍证明。

JSON独审重建72个mass、18个dyadic fee；以literal exponential-bin differences和direct weighted cube gates重验真实noise；独立重建36个物理signed contrast，最大浮点差1.8865e−16。对corridor以alternative Laplace-CDF primitives重建全部60 proposal examples，最大差1.1102e−16；重新生成共同priors、direct brute closed/rightlimit membership重验8个small-n完整路径，max差0。原source-support breakpoints和mask TV以Fraction检查。上述数值差都是诊断，不是向外积分误差界。

冻结两主脚本temp-copy standalone实际重放：quantization 0.9498秒、corridor 15.6983秒，exit0、empty stderr，两个JSON逐byte-identical。独审guard实际完整PASS 0.9153秒；soft/hardface/coverage组件守卫分别0.4096/0.0344/0.0662秒，PASS43/32 mask+1500 gate diagnostics/130。guard每次重验冻结主py/json hashes、独立data arithmetic及组件guard；不重复耗时主program，完整主replay由这里单独记录。

归档隔离实际测试：仅独审guard、两主py/json及三个提取guard、无任何component md，完整PASS 0.9506秒；只放上述主文件与含四冻结fences的合并proof.md（soft/hardface/coverage/audit），完整PASS 0.9460秒。audit_guard优先同目录component_guard.py，开发时可从component md提取，否则按冻结SHA从proof.md匹配；无需任何归档外文件。最终proof正文与末尾audit守卫共4个Python fences。本audit正文没有新增Python fence。

```sh
python3 -B audit_guard.py
```

该命令须在含冻结两主py/json及合并proof.md（或三个已提取component guards）的目录执行。精确geometry/algebra可复现，实际E2 quadrature、ideal law的有限机器近似和conditionalSE仍为diagnostic。

## 7. 冻结来源 SHA-256

下列文件是所审版本来源标识，不是归档外依赖。数学终审对象为冻结Markdown；未运行TeX/PDF编译。

| 来源 | SHA-256 |
|---|---|
| parent_quantization.md | `72d2cb20eb11b1a7883581f9a22fe6b45426f09b5408366e91931fc75b082427` |
| soft.md | `795a198200e1cc4b591373d653a1528b1e31b9623afd41fdc1fd696d0e2f36d0` |
| hardface.md | `a65127b7b933fdc313e47fc4143e4efa198ed22cf908b7b15b0ff3b272f72e20` |
| coverage.md | `08e97748c1fb33a58c820edbf34189ca74f45c663d674dbbd48b7c1bfe3b15e6` |
| corridor_numeric.md | `c8d2d098acca1e193765cf92810e5d98a03589a8fd02c04c1c33ef003caf33dc` |
| quantization_probe.py | `5f6135f4d021c8ea8aba159b3f7a680627b0f983e30883bf595be787658e0cfb` |
| quantization_results.json | `3a729a7727b56fce06a81243b613f1760f62df6f9a774aa2d0a2dfa496ba0c99` |
| corridor_probe.py | `e6dfefd7788a3010aec8428ab1e4012522d18d1e40a82a4af67935a948d29544` |
| corridor_results.json | `66893e656b16ce5124518c7cc2b64ccb03236aaf97e9c7fa405031cfe1092452` |
| audit_guard.py | `660916ad762f54a2198b7663415d6b87f9f1840c01cc1663c97258a7679b6c54` |

组件fence正文加末尾newline hashes：soft `88e0d0cdabc9128cc793930fccebce8fe4013269757f32cba943c3a58692d76f`；hardface `a0777e0678b724430446367fe4907424ba5467264e14bd16a39912e93b9ad0e5`；coverage `22199e663dc7f288824c030059dc1b7894aac7417320dbb50449cdf8bdc4b11a`。


## 最终独审守卫 audit_guard.py

```python
#!/usr/bin/env python3
"""R79 independent exact coupling/labels/affine gate checks.
Finite rational examples support analytic proofs, not continuum cubature.
"""
from fractions import Fraction as Q
from itertools import product
from pathlib import Path
import math,json,random,time,hashlib,subprocess,tempfile,sys,re
BASE=Path(__file__).resolve().parent

def exp_interval(x,terms=100):
    x=Q(x);assert 0<=x<terms+2
    total=term=Q(1)
    for j in range(1,terms+1):term*=x/j;total+=term
    first=term*x/(terms+1)
    return total,total+first/(1-x/Q(terms+2))

def exp_minus(x):
    lo,hi=exp_interval(x);return 1/hi,1/lo

def ln2_interval(terms=60):
    z=Q(1,3);power=z;lo=Q(0)
    for j in range(terms):lo+=2*power/(2*j+1);power*=z*z
    return lo,lo+2*power/((2*terms+1)*(1-z*z))

def quantize(z,h,R):
    if abs(z)>R:return Q(0)
    return (1 if z>=0 else -1)*h*(abs(z)//h)

def gate(x,z):return abs(x-z)<=Q(1,2)

def coupling_geometry():
    checks=jumps=0
    for h,R in product((Q(1,2),Q(1,4),Q(1,8)),(Q(1),Q(2))):
        zs=[Q(j,16) for j in range(-int(16*(R+1)),int(16*(R+1))+1)]
        for z in zs:
            q=quantize(z,h,R);assert abs(q)<=abs(z)
            if abs(z)<=R:assert abs(z-q)<h
            else:assert q==0
            xs=set([z+Q(1,2),z-Q(1,2),q+Q(1,2),q-Q(1,2)])
            xs|={v+d for v in list(xs) for d in (Q(-1,64),Q(1,64))}
            for x in xs:
                if abs(z)<=R and gate(x,z)!=gate(x,q):
                    assert min(abs(z-x-Q(1,2)),abs(z-x+Q(1,2)))<=h
                    # Both boundary neighborhoods lie outside this inner radius.
                    assert abs(z)>=max(Q(0),abs(x)-Q(1,2)-h)
                    jumps+=int(abs(x-q)==Q(1,2))
                checks+=1
    return {'exact_joint_gate_checks':checks,'closed_quantized_gate_mismatches':jumps,'scope':'Exact source coupling and closed gate boundary geometry; no approximation to E2 bin masses.'}

def mask_labels_and_error():
    checks=0;maxI=Q(0)
    for n in range(1,9):
        for delta in (Q(0),Q(1,16),Q(1,2),Q(1)):
            D=K=J=qk=jk=Q(0)
            for bits in product((0,1),repeat=n):
                k=sum(bits);alpha=(delta/2)**k*(1-delta/2)**(n-k);beta=delta**k*(1-delta)**(n-k)
                q=(alpha+beta)/2;d=alpha-beta
                j=d*d/q if q else Q(0)
                assert j<=4*q
                # Every retained mask's pushforward noise law has mass one,
                # including tail-to-zero mass; signs remain mask labels.
                D+=d;K+=q;J+=j;qk+=q*k;jk+=j*k;checks+=1
            assert D==0 and K==1 and qk==3*n*delta/4 and jk<=3*n*delta
            maxI=max(maxI,J)
    lo,hi=exp_interval(1);assert 2<lo<=hi<3
    constant_cases=0
    for n in (1,2,4,8,16,32,64):
        E=Q(1,2*n)
        for a in (Q(0),Q(1,16),Q(1,2),Q(1)):
            assert (1+a*E)**n-1<=3*n*a*E
            constant_cases+=1
    # All-layer endpoint and posterior-label weights, retaining infinite tails.
    for depth in (1,4,16,64):
        partial=sum(Q(1,1<<s) for s in range(depth));tail=Q(1,1<<(depth-1))
        assert partial+tail==2
        assert Q(9,2)*(partial+tail)==9
        assert Q(9,4)*(partial+tail)==Q(9,2)
        assert 9*(partial+tail)==18
    return {'exact_mask_rows':checks,'largest_exact_I':str(maxI),'rational_tensor_majorant_cases':constant_cases,'contrast_all_layer_multiplier':'9*n*E*(1+n*log2)','K_all_layer_multiplier':'(9/2)*n*E*(1+n*log2)','J_all_layer_multiplier':'18*n*E*(1+n*log2)','scope':'Exact unchanged alpha/beta/zeta mask algebra and complete geometric tails; actual noise masses need the coupling proof.'}

def envelope_constants():
    lnlo,lnhi=ln2_interval();cases=[]
    for n in (1,2,4,16,64,256,4096,16384):
        h=Q(1,64*n*(n+1)**2);R=4*n.bit_length()+8
        emR=exp_minus(R)[1];emRm1=exp_minus(R-1)[1]
        E=8*h*(1+h)+emR+(2*R+1)*emRm1
        assert n*E<=1
        total=9*n*E*(1+n*lnhi)
        assert total>=0
        cases.append({'n':n,'h':str(h),'R':R,'nE_upper':str(n*E),'all_contrast_fee_upper':str(total)})
    # Exact integral of 4h w((|x|-.5-h)_+) from w(0)=1, mass(w)=1.
    for h in (Q(1),Q(1,2),Q(1,64)):
        assert 4*h*(2*(Q(1,2)+h)+1)==8*h*(1+h)
    return {'outward_exponential_budget_dimensions':len(cases),'records':cases,'scope':'Rational upper exponential tail constants; scalar E2 mismatch envelope proved analytically.'}

def gate_interval(x,y,z):
    lower=Q(0);upper=None
    # d <= L(z+.5) and -d <= L(.5-z), L>0.
    for xx,yy,zz in zip(x,y,z):
        d=xx-yy
        for value,slope in ((d,zz+Q(1,2)),(-d,Q(1,2)-zz)):
            if slope>0:lower=max(lower,value/slope)
            elif slope<0:upper=value/slope if upper is None else min(upper,value/slope)
            elif value>0:return None
    if upper is not None and (upper<=0 or lower>upper):return None
    return lower,upper

def interval_and_age():
    rng=random.Random(790611);fixtures=checks=oldchecks=0
    for n in (1,2,3,4):
        for _ in range(80):
            x=[Q(rng.randrange(-8,9),4) for i in range(n)]
            y=[Q(rng.randrange(-8,9),4) for i in range(n)]
            z=[Q(rng.randrange(-6,7),4) for i in range(n)]
            span=gate_interval(x,y,z);Ls={Q(j,8) for j in range(1,33)}
            if span:
                A,B=span
                for endpoint in (A,B):
                    if endpoint is not None and endpoint>0:
                        Ls|={endpoint,endpoint*Q(63,64),endpoint*Q(65,64)}
            for L in Ls:
                actual=all(abs(xx-yy-L*zz)<=L/2 for xx,yy,zz in zip(x,y,z))
                predicted=bool(span and L>=span[0] and (span[1] is None or L<=span[1]))
                assert actual==predicted;checks+=1
                if actual and span[0]>0 and L>Q(3,2)*span[0]:
                    previous=L/Q(3,2)
                    assert previous>=span[0] and (span[1] is None or previous<=span[1])
                    assert all(abs(xx-yy-previous*zz)<=previous/2 for xx,yy,zz in zip(x,y,z))
                    assert L**(-n)==Q(2,3)**n*previous**(-n);oldchecks+=1
            fixtures+=1
    lnlo,lnhi=ln2_interval();dims=0
    for n in list(range(1,65))+[256,4096,16384]:
        # h_age=log(n+2)/n gives exactly exp(-n h_age)=1/(n+2).
        Sn=1+n*lnhi;q=n.bit_length()-1
        anchor=sum(min(Q(2),Q(n,1<<s)) for s in range(q+2))+Q(n,1<<(q+1))
        assert anchor<=2*q+4 and Sn/(n+2)<=1
        assert Sn*anchor/(n+2)<=2*q+4;dims+=1
    return {'exact_affine_gate_fixtures':fixtures,'closed_gate_interval_checks':checks,'old_age_retention_checks':oldchecks,'exact_old_fee_dimensions':dims,'scope':'Original fixed joint-source gate interval and retained exit checked exactly; ideal log-age old fee algebra, not fresh signed crossing coverage.'}

def overlap_algebra():
    lnlo,lnhi=ln2_interval();grid=1<<80
    root=math.isqrt(grid*grid//2);rlo,rhi=Q(root,grid),Q(root+1,grid)
    assert rlo*rlo<=Q(1,2)<=rhi*rhi and rhi<Q(3,4)
    clo=(1-rhi)**2/6;assert clo>0
    assert exp_interval(1)[0]>2
    # Generic positive finite probability kernels check sourcewise overlap;
    # they do not substitute for the genuine E2 outside-mass proof.
    checks=0
    for a in (Q(1),Q(1,2),Q(1,8)):
        pa=[1-a/2,a/4,a/4];pb=[1-a/4,a/8,a/8]
        assert sum(pa)==sum(pb)==1
        for n in range(1,5):
            ma=sum(min(math.prod(pa[i] for i in inds),math.prod(pb[i] for i in inds)) for inds in product(range(3),repeat=n))
            assert 0<=ma<=1;checks+=1
    for a in (Q(1,2),Q(1,8),Q(1,64)):
        edge=(1-a)/(2-a)
        for p in (Q(0),edge/2,edge):
            q=1-p;z=q-p
            assert z>0 and a*p/2<=(1-a)*z/2
            assert p+z==q
            checks+=1
    # Endpoint a=1 has zero reduced damping; no division by 1-a.
    assert 1-Q(1)==0
    # Independent source mixing: disjoint positive/negative kernel pieces
    # can meet after convolution; its opposite part is exactly C_mix.
    for weight in (Q(1,4),Q(1,3),Q(3,8)):
        p=weight*Q(2);q=(1-weight)*Q(1)
        cmix=(p+q-abs(p-q))/2
        assert cmix==min(p,q)
        if p<q:assert cmix==p
        checks+=1
    return {'rational_overlap_posterior_cases':checks,'c_star_certified_lower':str(clo),'scope':'Exact generic kernel/source mixing and posterior absorption algebra; true E2 affinity and Gaussian/dyadic root-sum universal proof is analytic.'}


def independent_phi(x,M=64):
    x=abs(float(x));total=0.
    for j in range(1,M+1):
        r=j/M;c=1 if j==M else 4 if j%2 else 2
        if x<=.5:value=r*(2-math.exp(-(.5-x)/r)-math.exp(-(.5+x)/r))
        else:value=r*(math.exp(-(x-.5)/r)-math.exp(-(x+.5)/r))
        total+=c*value
    return total/(3*M)


def quantization_saved():
    data=json.loads((BASE/'quantization_results.json').read_text());mass=fee=0;diagnostics=[];meshes=[]
    for row in data['stage3']['mass_cases']:
        n=row['n'];E,a=Q(row['E']),Q(row['a']);v=(1+a*E)**n-1
        assert v==Q(row['positive_tensor_error_mass'])<=Q(row['mass_bound'])==3*n*a*E;mass+=1
    lo,hi=map(Q,data['stage3']['log2_interval'])
    for row in data['stage3']['dyadic_fee_cases']:
        n=row['n'];E=Q(row['E']);depth=row['explicit_dyadic_levels']
        partial=sum(Q(1,1<<s) for s in range(depth));tail=Q(1,1<<(depth-1))
        assert partial+tail==2 and partial==Q(row['finite_delta_sum']) and tail==Q(row['infinite_remaining_delta_sum'])
        exact=sum((1+Q(1,1<<(s+1))*E)**n-1+(1+Q(1,1<<s)*E)**n-1 for s in range(depth))
        assert exact==Q(row['finite_actual_majorant_mass_sum'])
        assert list(map(Q,row['all_layer_maximal_error_fee_interval']))==[9*n*E*(1+n*t) for t in (lo,hi)]
        fee+=1
    # Independent literal exp differences in genuine E2 bins, then direct
    # weighted closed cube gate; no production prefix sums or imports.
    for row in data['stage1']['cases']:
        h,R=Q(row['h']),Q(row['R']);M=row['s_panels'];cells=[]
        for k in range(int(R/h)):
            loz=float(k*h);hiz=float((k+1)*h)
            cells.append(sum((1 if j==M else 4 if j%2 else 2)*(j/M)*(math.exp(-loz/(j/M))-math.exp(-hiz/(j/M))) for j in range(1,M+1))/(3*M))
        tail=2*sum((1 if j==M else 4 if j%2 else 2)*(j/M)*math.exp(-float(R)/(j/M)) for j in range(1,M+1))/(3*M)
        x=Q(row['worst_ratio_witness']['x']);atoms=[(Q(0),2*cells[0]+tail)]
        for j in range(1,len(cells)):atoms.extend([(-j*h,cells[j]),(j*h,cells[j])])
        pq=sum(weight for z,weight in atoms if abs(x-z)<=Q(1,2));p=independent_phi(x,M)
        witness=row['worst_ratio_witness'];assert abs(pq-witness['phi_q'])<2e-12 and abs(p-witness['phi'])<2e-12
        assert abs(sum(w for z,w in atoms)-1)<2e-12
        diagnostics.append({'h':str(h),'independent_phi_q':pq,'saved_phi_q':witness['phi_q']});meshes.append((M,atoms))
    physical=0;maxcontrast=0.
    for row in data['stage2']['cases']:
        M,atoms=meshes[row['mesh_index']];witness=row['worst_error_witness'];x=list(map(Q,witness['x']));L=Q(witness['L']);delta=Q(row['delta'])
        def endpoint(a,finite):
            total=0.
            for y,weight in zip(row['source_positions'],row['source_nu']):
                value=1.
                for xx,yy in zip(x,y):
                    v=(xx-Q(yy))/L;hh=float(abs(v)<=Q(1,2))
                    pp=sum(p for z,p in atoms if abs(v-z)<=Q(1,2)) if finite else independent_phi(v,M)
                    value*=float(1-a)*hh+float(a)*pp
                total+=float(Q(weight))*value/float(L**row['n'])
            return total
        true=endpoint(delta/2,False)-endpoint(delta,False);finite=endpoint(delta/2,True)-endpoint(delta,True)
        diff=max(abs(true-witness['original_signed_contrast']),abs(finite-witness['finite_signed_contrast']))
        assert diff<3e-12;maxcontrast=max(maxcontrast,diff);physical+=1
    for row in data['stage3']['source_atom_shift_warning']:
        eps=Q(row['epsilon']);assert Q(row['strong_L1_maximum_difference_lower'])==Q(1,8)
        for witness in row['exact_receiver_tests']:
            x,L=Q(witness['x']),Q(witness['L'])
            assert abs(x/L)>Q(1,2) and abs((x-eps)/L)<=Q(1,2) and 1/L>=Q(1,2)
    assert data['stage1']['nonmonotone_quantized_kernel_example']['upward_jump']>0
    return {'exact_mass_cases':mass,'exact_dyadic_fee_cases':fee,'independent_real_E2_bin_diagnostics':diagnostics,'independent_physical_signed_contrasts':physical,'physical_contrast_max_difference':maxcontrast,'scope':'Exact saved rational mass/fee/geometry; floating actual-E2 bins separately diagnosed, no interval integration guarantee.'}


def independent_phi_integral(lo,hi,M=64):
    # Mixture of Laplace CDF primitives, independent of producer's tail phi.
    total=0.
    for j in range(1,M+1):
        r=j/M;c=1 if j==M else 4 if j%2 else 2
        def primitive(t):return .5*r*math.exp(t/r) if t<=0 else t+.5*r*math.exp(-t/r)
        def window(v):return primitive(v+.5)-primitive(v-.5)
        total+=c*2*r*(window(hi)-window(lo))
    return total/(3*M)


def independent_box_P(src,x,L,a,M=64):
    total=0.
    for center,e,m in zip(src['centers'],src['halfwidths'],src['mass_fractions']):
        e=float(Q(e));value=1.
        for xx,y in zip(x,center):
            d=xx-float(Q(y));left,right=d-e,d+e
            hard=max(0.,min(right,L/2)-max(left,-L/2))/(2*e*L)
            soft=independent_phi_integral(left/L,right/L,M)/(2*e)
            value*=((1-a)*hard+a*soft)
        total+=float(Q(m))*value
    return float(Q(src['W']))*total


def sample_latent(src,count,seed):
    rng=random.Random(seed);out=[];n=src['n']
    for _ in range(count):
        u=rng.random();acc=0.;idx=len(src['centers'])-1
        for j,m in enumerate(src['mass_fractions']):
            acc+=float(Q(m))
            if u<acc:idx=j;break
        e=float(Q(src['halfwidths'][idx]));y=[float(Q(v))+(2*rng.random()-1)*e for v in src['centers'][idx]]
        U=[rng.random() for j in range(n)];Z=[]
        for j in range(n):
            r=math.sqrt(rng.random());sgn=1 if rng.random()<.5 else -1
            Z.append(sgn*r*(-math.log(max(rng.random(),2**-53))))
        out.append((y,U,Z))
    return out


def brute_machine_path(src,x,a,b,prior):
    n=src['n'];r=(n+2)**(1/n);intervals=[];cuts={1.,2.}
    for y,U,Z in prior:
        for softness,sgn in ((b,1),(a,-1)):
            z=[v if u<softness else 0. for u,v in zip(U,Z)]
            # Original inequalities in L, independently from q=1/L code.
            lower=0.;upper=float('inf');possible=True
            for xx,yy,zz in zip(x,y,z):
                d=xx-yy
                for value,slope in ((d,zz+.5),(-d,.5-zz)):
                    if slope>0:lower=max(lower,value/slope)
                    elif slope<0:upper=min(upper,value/slope)
                    elif value>0:possible=False
            if not possible or upper<=0 or lower>upper:continue
            intervals.append((lower,upper,lower*r,sgn))
            cuts|={v for v in (lower,upper,lower*r) if 1<=v<=2}
    best={'total':0.,'old':0.,'fresh':0.}
    for L in sorted(cuts):
        for right in (False,True):
            if right and L==2:continue
            total=sum(sgn for A,B,O,sgn in intervals if A<=L and (L<B if right else L<=B))
            old=sum(sgn for A,B,O,sgn in intervals if O<=L and (L<B if right else L<=B))
            for k,count in (('total',total),('old',old),('fresh',total-old)):
                best[k]=max(best[k],float(Q(src['W']))*abs(count)/(len(prior)*L**n))
    return best


def corridor_saved():
    data=json.loads((BASE/'corridor_results.json').read_text());rows=0;examples=0;brutes=0;maxP=0.;maxpath=0.
    for row in data['cases']:
        src=row['input'];n=src['n'];a,b=Q(row['a']),Q(row['b'])
        assert sum(map(Q,src['mass_fractions']))==1 and all(Q(e)>0 for e in src['halfwidths'])
        m=sum(Q(math.comb(n,k))*abs(b**k*(1-b)**(n-k)-a**k*(1-a)**(n-k)) for k in range(n+1))
        assert m==Q(row['actual_mask_signed_TV']) and Q(row['e_minus_nh'])==Q(1,n+2)
        for batch in row['batches']:
            for example in batch['examples']:
                x=example['x'];params=row.get('proposal_softness_parameters',[b,a] if row['receiver_proposal'].startswith('equal ') else [a]);scales=row.get('proposal_physical_scales',[1,1.5,2]);proposal=sum(independent_box_P(src,x,float(Q(L)),float(Q(parameter))) for L in scales for parameter in params)/(len(scales)*len(params)*float(Q(src['W'])))
                diff=abs(proposal-example['proposal_density']);assert diff<2e-11;maxP=max(maxP,diff);examples+=1
            if n<=2:
                example=batch['examples'][0];prior=sample_latent(src,batch['latent_samples'],batch['latent_seed'])
                maxima=brute_machine_path(src,example['x'],float(a),float(b),prior)
                for k,value in maxima.items():
                    diff=abs(value-example['finite_path']['maxima'][k]['value']);assert diff<2e-12;maxpath=max(maxpath,diff)
                brutes+=1
        for example in row['physical_examples']:
            x=list(map(Q,example['x']));bp=sorted({2*abs(xx-Q(y)+sgn*Q(e)) for center,e in zip(src['centers'],src['halfwidths']) for xx,y in zip(x,center) for sgn in (-1,1) if 1<2*abs(xx-Q(y)+sgn*Q(e))<=2})
            assert bp==list(map(Q,example['source_support_breakpoints']))
        rows+=1
    return {'actual_L1_source_cases':rows,'independent_box_proposal_examples':examples,'independent_brute_finite_prior_paths':brutes,'proposal_max_difference':maxP,'path_max_difference':maxpath,'scope':'Exact saved input/mask/support geometry; independent floating actual-Laplace CDF densities and brute machine-prior paths, not continuous supremum or iid bias certificates.'}


def component_guard(component,expected):
    direct=BASE/(component+'_guard.py')
    if direct.is_file():payload=direct.read_bytes();origin=direct.name
    else:
        origin=component+'.md' if (BASE/(component+'.md')).is_file() else 'proof.md'
        path=BASE/origin
        if not path.is_file():raise FileNotFoundError('Archive needs '+component+'_guard.py or merged proof.md frozen fence')
        fences=re.findall(r'```python\n(.*?)\n```',path.read_text(),re.S)
        matches=[(f+'\n').encode() for f in fences if hashlib.sha256((f+'\n').encode()).hexdigest()==expected]
        assert len(matches)==1;payload=matches[0]
    assert hashlib.sha256(payload).hexdigest()==expected
    return payload,origin


def package_replays():
    expected={'quantization_probe.py':'5f6135f4d021c8ea8aba159b3f7a680627b0f983e30883bf595be787658e0cfb','quantization_results.json':'3a729a7727b56fce06a81243b613f1760f62df6f9a774aa2d0a2dfa496ba0c99','corridor_probe.py':'e6dfefd7788a3010aec8428ab1e4012522d18d1e40a82a4af67935a948d29544','corridor_results.json':'66893e656b16ce5124518c7cc2b64ccb03236aaf97e9c7fa405031cfe1092452'}
    for name,h in expected.items():assert hashlib.sha256((BASE/name).read_bytes()).hexdigest()==h
    receipts=[]
    with tempfile.TemporaryDirectory(prefix='r79-independent-guards-') as tmp:
        for component,h in [('soft','88e0d0cdabc9128cc793930fccebce8fe4013269757f32cba943c3a58692d76f'),('hardface','a0777e0678b724430446367fe4907424ba5467264e14bd16a39912e93b9ad0e5'),('coverage','22199e663dc7f288824c030059dc1b7894aac7417320dbb50449cdf8bdc4b11a')]:
            payload,origin=component_guard(component,h);path=Path(tmp)/(component+'_guard.py');path.write_bytes(payload);start=time.perf_counter()
            proc=subprocess.run([sys.executable,'-B',str(path)],capture_output=True,text=True,check=True);assert proc.stderr==''
            receipts.append({'component':component,'package_source':origin,'guard_sha256':h,'seconds':round(time.perf_counter()-start,4),'stdout':proc.stdout.strip()})
    return {'frozen_numeric_hashes':expected,'component_replays':receipts,'scope':'Frozen main sources/data hash checked; independent arithmetic/data checks and three guard replays. Main full-program byte replay is recorded separately in audit.md.'}


def main():
    start=time.perf_counter()
    out={'status':'PASS','coupling':coupling_geometry(),'labels':mask_labels_and_error(),'constants':envelope_constants(),'age':interval_and_age(),'overlap':overlap_algebra(),'quantization_saved':quantization_saved(),'corridor_saved':corridor_saved(),'package_replays':package_replays()}
    out['elapsed_seconds']=round(time.perf_counter()-start,4);print(json.dumps(out,sort_keys=True))
if __name__=='__main__':main()
```
