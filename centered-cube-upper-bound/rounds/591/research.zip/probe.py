#!/usr/bin/env python3
"""Ten frozen exact full-union cases; no H2/Z clipping or LP."""
import argparse,hashlib,json,math,platform,resource,shlex,signal,sys,time
from fractions import Fraction as F
from functools import cmp_to_key,lru_cache
from pathlib import Path
import flint
from flint import arb,ctx

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=Path(__file__).with_name('ccu_r591_chamber_results.json'));args=ap.parse_args()
 start=time.perf_counter();ctx.prec=512;limit=128*1024**2
 def timeout(*_):raise TimeoutError('120 s guard; family not truncated')
 signal.signal(signal.SIGALRM,timeout);signal.alarm(120)
 Z=();ONE=((1,F(1)),)
 def pack(d):return tuple(sorted((r,c) for r,c in d.items() if c))
 def rat(q):q=F(q);return ((1,q),) if q else Z
 def add(a,b):
  d=dict(a)
  for r,c in b:d[r]=d.get(r,F(0))+c
  return pack(d)
 def scale(a,q):return tuple((r,c*q) for r,c in a if c*q)
 def sub(a,b):return add(a,scale(b,-1))
 def mul(a,b):
  d={}
  for r,c in a:
   for s,e in b:
    g=math.gcd(r,s);rr=r*s//g**2;d[rr]=d.get(rr,F(0))+c*e*g
  return pack(d)
 @lru_cache(None)
 def av(a):return sum((arb(c.numerator)/c.denominator*arb(r).sqrt() for r,c in a),arb(0))
 def sign(a):
  if not a:return 0
  x=av(a)
  if x>0:return 1
  if x<0:return -1
  raise ArithmeticError('Arb512 comparison unresolved')
 def cmp(a,b):return sign(sub(a,b))
 def out(a):return {'exact_squarefree_radical_terms':[[r,str(c)] for r,c in a],'Arb512':av(a).str(65)}
 @lru_cache(None)
 def root(q):
  q=F(q);v=q.numerator*q.denominator;c=F(1,q.denominator);r=1;p=2
  while p*p<=v:
   e=0
   while v%p==0:e+=1;v//=p
   c*=p**(e//2)
   if e%2:r*=p
   p+=1 if p==2 else 2
  if v>1:r*=v
  return ((r,c),)
 weights=[F(1,2),F(1,3),F(1,6)]
 def run(t,u):
  rss=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
  if rss>limit:raise MemoryError('128 MiB guard')
  z=[(F(0),F(0)),(F(4,5)+t,F(0)),(F(2,5)-2*t,F(7,10)+u)]
  records=[];owners=[];endpointmaps=[{},{}]
  for S in range(1,8):
   ids=[i for i in range(3) if S>>i&1];M=sum(weights[i] for i in ids);half=scale(root(M),F(1,2));B=[];owner=[];widths=[]
   for j in range(2):
    lo=min(z[i][j] for i in ids);hi=max(z[i][j] for i in ids);owner.append({'min':[i for i in ids if z[i][j]==lo],'max':[i for i in ids if z[i][j]==hi]})
    a=sub(rat(hi),half);b=add(rat(lo),half);B.append((a,b));widths.append(sub(b,a))
    endpointmaps[j].setdefault(a,[]).append(str(S)+':lo');endpointmaps[j].setdefault(b,[]).append(str(S)+':hi')
   signs=[sign(w) for w in widths];active=all(x>0 for x in signs)
   records.append({'mask':S,'mass':str(M),'bbox_owners':owner,'width_signs':signs,'signed_widths':list(map(out,widths)),'box':B,'active':active})
   owners.append(owner)
  ends=[sorted(em,key=cmp_to_key(cmp)) for em in endpointmaps]
  signature=[[sorted(em[e]) for e in ax] for em,ax in zip(endpointmaps,ends)]
  idx=[{v:i for i,v in enumerate(ax)} for ax in ends];nx,ny=[len(ax)-1 for ax in ends];rows=[0]*nx
  for rec in records:
   if not rec['active']:continue
   B=rec['box'];x0,x1=[idx[0][v] for v in B[0]];y0,y1=[idx[1][v] for v in B[1]];bits=((1<<(y1-y0))-1)<<y0
   for x in range(x0,x1):rows[x]|=bits
  area=Z
  for x,bits in enumerate(rows):
   dx=sub(ends[0][x+1],ends[0][x]);assert sign(dx)>0
   while bits:
    bit=bits&-bits;y=bit.bit_length()-1;bits^=bit;dy=sub(ends[1][y+1],ends[1][y]);assert sign(dy)>0;area=add(area,mul(dx,dy))
  return {'t':str(t),'u':str(u),'positions_rational':[[str(x) for x in p] for p in z],'all_seven_subsets':[dict(mask=r['mask'],mass=r['mass'],bbox_owners=r['bbox_owners'],width_signs=r['width_signs'],signed_widths=r['signed_widths'],active=r['active'],box_bounds=[[out(a),out(b)] for a,b in r['box']]) for r in records],
   'axis_endpoint_order_signature':signature,'axis_endpoints':[[out(e) for e in ax] for ax in ends],'bbox_owner_signature':owners,'full_union_volume':out(area),'arrangement_cell_count':nx*ny},area
 delta=F(1,1000);small={};areas={};base,basev=run(F(0),F(0));small[(F(0),F(0))]=base;areas[(F(0),F(0))]=basev
 for t in (-delta,F(0),delta):
  for u in (-delta,F(0),delta):
   if (t,u)==(0,0):continue
   rec,area=run(t,u)
   assert rec['bbox_owner_signature']==base['bbox_owner_signature'],'Small perturbation crossed bbox-owner wall; stop, do not change amplitude'
   assert rec['axis_endpoint_order_signature']==base['axis_endpoint_order_signature'],'Small perturbation crossed endpoint-order wall; stop, do not change amplitude'
   small[t,u]=rec;areas[t,u]=area
 a=areas[0,0];b=scale(sub(areas[delta,0],areas[-delta,0]),1/(2*delta));c=scale(sub(areas[0,delta],areas[0,-delta]),1/(2*delta));d=scale(add(sub(areas[delta,delta],areas[delta,-delta]),sub(areas[-delta,-delta],areas[-delta,delta])),1/(4*delta**2))
 def polynomial(t,u):return add(add(a,scale(b,t)),add(scale(c,u),scale(d,t*u)))
 for (t,u),area in areas.items():assert sub(area,polynomial(t,u))==Z
 for u in (-delta,F(0),delta):assert sub(add(areas[delta,u],areas[-delta,u]),scale(areas[0,u],2))==Z
 for t in (-delta,F(0),delta):assert sub(add(areas[t,delta],areas[t,-delta]),scale(areas[t,0],2))==Z
 larger,largearea=run(F(1,10),F(0));largeorder=larger['axis_endpoint_order_signature']==base['axis_endpoint_order_signature'];largeowners=larger['bbox_owner_signature']==base['bbox_owner_signature'];extrap=polynomial(F(1,10),F(0));larger['same_endpoint_chamber_as_origin']=largeorder;larger['same_bbox_owners_as_origin']=largeowners;larger['origin_polynomial_extrapolation']=out(extrap);larger['actual_minus_extrapolation']=out(sub(largearea,extrap))
 # A first differing order group is a witness, not a claim of the earliest wall location.
 walls=[]
 for axis,(old,new) in enumerate(zip(base['axis_endpoint_order_signature'],larger['axis_endpoint_order_signature'])):
  if old!=new:
   j=next(j for j in range(min(len(old),len(new))) if old[j]!=new[j]);walls.append({'axis':axis,'first_differing_group_index':j,'origin_group':old[j],'large_group':new[j]})
 larger['order_wall_witnesses']=walls
 signal.alarm(0)
 result={'scope':'One fixed three-label full-scale Efull, all seven actual subset boxes at exactly nine small points plus one large point; no exceptional-set clipping, LP or general weak-bound claim.',
 'input':{'n':2,'lambda':1,'masses':['1/2','1/3','1/6'],'position_formula':['(0,0)','(4/5+t,0)','(2/5-2t,7/10+u)'],'r_convention':'r=sqrt(mS) is cube SIDE length','small_t_u':['-1/1000','0','1/1000'],'large_t_u':['1/10','0']},
 'small_cases':[small[t,u] for t in (-delta,F(0),delta) for u in (-delta,F(0),delta)],
 'small_chamber_certificate':{'all_nine_bbox_owners_identical':True,'all_nine_axis_endpoint_orders_identical':True,'endpoint_orders_include_all_subsets_even_empty_or_zero_width':True,'volume_formula':'a+b*t+c*u+d*t*u','a':out(a),'b':out(b),'c':out(c),'d':out(d),'d_is_nonzero':bool(d),'all_nine_formula_residuals_exact':[],'all_three_t_second_differences_exact':[],'all_three_u_second_differences_exact':[],'joint_affine_claim':'not asserted: d is explicitly retained'},
 'larger_case':larger,'arithmetic':'Exact Fraction canonical squarefree radicals; Arb512 for every nonzero endpoint/width ordering; equality by exact coefficient cancellation. All rectangle endpoints used in complete union, no midpoint sampling or floating signs.',
 'execution':{'interpreter':sys.executable,'python':platform.python_version(),'python_flint':flint.__version__,'precision_bits':ctx.prec,'processes':1,'guard_seconds':120,'guard_bytes':limit,'runtime_seconds':time.perf_counter()-start,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'command':shlex.join([sys.executable,str(Path(__file__).resolve()),*sys.argv[1:]])},'all_assertions_passed':True}
 args.output.write_text(json.dumps(result,ensure_ascii=False,sort_keys=True,indent=2)+'\n')
 print(json.dumps({'small_same_chamber':True,'coefficients':{name:out(v) for name,v in zip('abcd',(a,b,c,d))},'large_same_chamber':largeorder,'large_same_bbox_owners':largeowners,'large_minus_extrapolation':out(sub(largearea,extrap)),'execution':result['execution']}))
if __name__=='__main__':main()
