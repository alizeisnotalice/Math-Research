# R591 最终合并独审

**PASS，可按当前字节归档；未发现必须修复项。** 通过范围是报告实际声称的全尺度付费删除、固定质量坐标代表、条件反馈、限定二阶公式及有限证书。共同保留增益和统一接触coercivity仍未证明；没有认证一般根阶上界。

全文审核对象 `/tmp/ccu_r591_REPORT.tex` 的SHA256：

`64404e8936498860889ac044aface2072c42538224945320b2cd4ed8af3278c2`

本文件合并本轮先行合同、作者后审及最终整合核验的结论。先独立推导，再读取指定作者和root证明；未读无关历史。最终稿已保留actual positive-label class、component translations、gap仅可能开缝、人工anchors及有限步差的全部守卫。

## 关键通过项与必要范围

1. **全尺度对象与极值。** C_{n,d}是至多d正标签、所有阈值、ALL非空原子子集的完整弱比值。严格level与有限闭盒并仅差零测。fixed-d紧化允许先取最好源图component、按其质量归一化并在真正split时减少正标签数，最终平移入[-d,d]^n；有限盒并体积连续，zero padding删去后给实际正标签极值。没有uniform-d紧性或源数上界。矩阵rank中的d按去零后的实际正标签数理解；若attainer只有q≤d标签，可用C_{n,q}=C_{n,d}再重标记。真极值允许物理位置离开人工compactbox，不能把near-max输入无价当驻点。

2. **H2与新G一次全尺度费。** H2使用全部β≥1/√n来源子集的source-disjoint质量降序贪心，费用2√nW，覆盖所有含高β半核的实际父，不是atomholes。独立β门限1/2的新G费用≤2θ^nW/δ≤2e^(1/4)W/δ。若任意轴平行小source cube B边长r/(8n)、与Q(x,r)相交且质量≥δλr^n，则取其全部原来源S，有Σspan/r_S≤δ^(-1/n)/8≤1/2，故β_S≥1/2；拦截S的选中P借共同来源及θr/2距离覆盖x。这证明所有r及全部B同时的cap，没有r_min或逐尺度收费。G包含Zδ，最终入口c_G=2√n+2e^(1/4)/δ不重复付W/δ；R_G明确不同于旧band/grid/atom残余。

3. **最大实际父与半核源费用。** 最大质量实际N捕获恰为其原标签；对每个实t>1，若放大盒质量q≥tM，则真实q标签成为更大见证，矛盾。因此全t薄壳严格上界成立，没有U上限，但不包括t=1，亦不提供内向/耦合流结论。原完整半核K⊆A在ν_A的λ/2 level有实际见证，所以F(A)≤2C_{n,d}M_A，无two-band费；空A为零，没有改父资格或截断carrier。旧单带列价并非该来源恢复所需假设，报告未偷用它。

4. **反馈及L1恢复。** 在真极值或误差ζW的完整近极值序列上，J_G≥(C_{n,d}−ζ−c_G)W。若真的证明同一law满足E M_A≤W/2及(1+η)J_G≤E F+D_nW，则ηC_{n,d}≤(1+η)(c_G+ζ)+D_n。η须有统一正下界，D_n及误差控制须uniform in d；ζ→0后才作sup_d。报告正确把这个gain标为未证。uniform-d有限原子上界K_n可直接恢复任意L1同一个K_n：compact截断、每格精确质量原子化、每个点选一个有严格margin的cube、固定cube边界条收敛、Fatou，然后单调截断。来源数随网格增长正是uniform-d不可省处；不需N_n、4/3或其他尺度损失，也不要求H2/G本身收敛。

5. **坐标顶点表示。** 固定正质量，所有候选z_ik±r_S/2排序后完整并为Σ a_cell∏axis length。它对一个轴的整个位置组仿射，跨轴多仿射。连续性延伸到chamber闭包但不抹去birth/隐藏wall/导数跳跃。与平移anchor和compactbox相交的轴polytope可逐轴取顶点保持全局最大；实际结论包含人工anchors，不把所有rank等式叫exposed接触，也不导出联合凸性或自由质量扰动。

6. **最后共同cut的(1)–(6)。** 在0≤h≤全局相邻坐标gap内，每个crossing父的移动盒单调扩张，包括负宽出生；至少半量的某侧真实子输入在λ/2有盒包含，得X(h)⊆P_L∪(P_U−he_j)。于是外部halo体积≥新crossing体积−完整上侧halo平移项。该项未支付，不能删除。旧E=E_L∪E_U∪X(0)，X(0)⊆X(h)，所以精确旧损失确为正文L(h)；全部新增长分成不交crossing与pure-upper项。极值比较仅给增长≤旧损失，方向不是所需下界。Score的有限breakpoint最大化合法；其充分gain阈值代入配对恒等式系数正确，但未证明。该尝试明确放宽至整个子输入level，未冒称等于原受限半核halo；无gain和无一般不可能性声明均准确。

7. **共同质量—位置公式。** 对全部实际接触行，左零空间兼容与Q=C−CG_0^T(G_0CG_0^T)^daggerG_0C正确；正质量时rangeQ=1^perp∩kerG_0，rank为实际正标签数减1再减rank(G_0C^(1/2))。Q可为零，投影不保嵌套正相关。零位置row仍可有真实质量限制，不能因无位置rank删掉。断开图保留每component平移，人工box不限制物理速度。线性补偿的gap二阶为负半径二阶和，只有相关项非零才真开缝。局部hull-gap损失与完整交盒公式不能双扣；完整光滑trace的half-sum及mixed h_j^TQh_k系数正确，owner/birth/wall及非线性加速度另计。固定P=H2∪G内二阶差绝对值≤2c_GW，但除τ²后无uniform预算；报告没有抹掉这个gap。

## 计算与代码的实际独审范围

绑定代码：

- chamber producer SHA256 `f55b82e1e102df453e14a37c9e396eda1426b02b450e90cdfbf678587256247d`。
- 固定chamber RESULTS SHA256 `e23bf0e6028c363d5bb16f353d9fb917c244d1d057a031d56978b71b1777f120`。
- inclusion-exclusion独立代码 SHA256 `3ed9c0fd937f921d78ec872dd7b55acec6e9ec8f8bbb93670b47bd48d0c83da2`。
- 审读的完整独立结果 SHA256 `c3c151ab3df9f3fef505f00e1d44b8359bb6a2c2b8381c9e35b320355c3b0866`。

代码分别为`/tmp/ccu_r591_chamber_probe.py`和`/tmp/ccu_r591_inclusion_replay.py`。二者自含相同n=2三正来源，完整7个原subset盒，无H2/G裁剪。producer精确Fraction/squarefree根式加Arb512排序，通过完整arrangement并求体积；所有空/零/负宽盒端点仍参与排序。九小点使用实际carrier端点加bbox-owner签名，并非将一般证明的全部冗余候选端点逐个输出；这种已固定owners的表足够该有限检查，正文未扩大为任意chamber认证。

本人实际独立执行producer一次，命令为指定数学Python调用该脚本并`--output /dev/null`，stdout关键数学字段与固定JSON精确匹配，未覆盖作者数据：九点残差和单轴二阶差为0，mixed系数=1；大点bbox owners不变、端点排序改变，actual−extrapolation约−0.05402221016162415且Arb严格负。没有扩展点集。

本人通读独立包含排除代码并检查结果摘要，没有再次执行它。代码不调用producer；重新生成7盒，对每点全部127非空box families计算完整交盒、正确截断空/零宽，共1270项，再与10个最终精确根式列表比较。它认证的是1270项被完整求值、10个最终体积与另一算法一致，并非另有1270项逐项独立参考答案。参考RESULTS raw hash被锁定，报告保留原reference、另名重放的命令正确。

`/tmp/ccu_r591_REPLAY.json`记录root真实执行两实现、相应数学payload匹配；本人读取了记录及摘要，不冒称亲自重跑inclusion程序。root该次独立重放约0.09065秒、75857920 bytes（约72.3MiB），与正文近似数相符。内存/时间是当前Darwin机器观测及脚本段守卫，不是一般复杂度或全流程OS保证。没有LP、极值认证、维数扫描、MATLAB或PDF。上述有限输入不是一般gain证书。

本人另外实际用本机SymPy1.14.0核过H2坐标代数、全尺度反馈固定点及公平质量特例；其他一般结论使用本文列出的书面推导。未把作者记录的运行当作本人计算。

## 可归档状态

新全尺度付费G、完整几何代表和限定有限证书可归档。尚缺的是uniform-d、保全部费用的共同retention增益或可继续非退化噪声的完整有利trace/有限跳跃不等式。局部cap、rank、极值存在、配对恒等式及坐标仿射均未替代该全局步骤。报告清楚保留这个缺口，没有一般阶数改善假称。本轮最终独审结束。
