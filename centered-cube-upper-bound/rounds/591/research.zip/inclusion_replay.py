#!/usr/bin/env python3
"""Independent seven-box inclusion-exclusion replay, exactly ten frozen inputs."""
import argparse,hashlib,itertools,json,math,platform,resource,shlex,signal,sys,time
from fractions import Fraction as F
from functools import lru_cache
from pathlib import Path
import sympy as sp
import flint
from flint import arb,ctx

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--reference',type=Path,default=Path(__file__).with_name('ccu_r591_chamber_results.json'));ap.add_argument('--output',type=Path,default=Path(__file__).with_name('ccu_r591_inclusion_results.json'));args=ap.parse_args()
 start=time.perf_counter();ctx.prec=512;limit=256*1024**2
 def timeout(*_):raise TimeoutError('120s guard; no family truncation')
 signal.signal(signal.SIGALRM,timeout);signal.alarm(120)
 raw=args.reference.read_bytes();reference=json.loads(raw)
 assert hashlib.sha256(raw).hexdigest()=='e23bf0e6028c363d5bb16f353d9fb917c244d1d057a031d56978b71b1777f120'
 assert reference['execution']['script_sha256']=='f55b82e1e102df453e14a37c9e396eda1426b02b450e90cdfbf678587256247d'
 # No import, evaluation or call into the original probe. Independently generate boxes.
 @lru_cache(None)
 def canonical(expr):return sp.expand(expr)
 @lru_cache(None)
 def exact_terms(expr):
  expr=canonical(expr);terms={}
  for term in sp.Add.make_args(expr):
   coefficient,base=term.as_coeff_Mul();assert coefficient.is_Rational
   if base==1:rad=1
   else:
    square=sp.simplify(base**2);assert square.is_Integer and square>0
    rad=int(square);assert base==sp.sqrt(rad)
   terms[rad]=terms.get(rad,F(0))+F(int(coefficient.p),int(coefficient.q))
  return tuple(sorted((r,c) for r,c in terms.items() if c))
 @lru_cache(None)
 def ball(expr):return sum((arb(c.numerator)/c.denominator*arb(r).sqrt() for r,c in exact_terms(expr)),arb(0))
 @lru_cache(None)
 def sg(expr):
  expr=canonical(expr)
  if expr==0:return 0
  v=ball(expr)
  if v>0:return 1
  if v<0:return -1
  raise ArithmeticError('Arb512 sign unresolved')
 def minimum(vals):
  v=vals[0]
  for w in vals[1:]:
   if sg(w-v)<0:v=w
  return v
 def maximum(vals):
  v=vals[0]
  for w in vals[1:]:
   if sg(w-v)>0:v=w
  return v
 weights=[sp.Rational(1,2),sp.Rational(1,3),sp.Rational(1,6)]
 points=[(sp.Rational(t),sp.Rational(u)) for t in ('-1/1000','0','1/1000') for u in ('-1/1000','0','1/1000')]+[(sp.Rational(1,10),sp.Integer(0))]
 refs=reference['small_cases']+[reference['larger_case']];assert len(points)==len(refs)==10
 records=[]
 for (t,u),answer in zip(points,refs):
  assert sp.Rational(answer['t'])==t and sp.Rational(answer['u'])==u
  positions=[(sp.Integer(0),sp.Integer(0)),(sp.Rational(4,5)+t,sp.Integer(0)),(sp.Rational(2,5)-2*t,sp.Rational(7,10)+u)]
  boxes=[];boxsigns=[]
  for S in range(1,8):
   ids=[i for i in range(3) if S>>i&1];m=sum(weights[i] for i in ids);half=sp.sqrt(m)/2
   B=[(canonical(max(positions[i][j] for i in ids)-half),canonical(min(positions[i][j] for i in ids)+half)) for j in range(2)]
   boxes.append(B);boxsigns.append([sg(b-a) for a,b in B])
  total=sp.Integer(0);counts={'positive_area':0,'zero_width':0,'negative_width':0};family_records=[]
  for family in range(1,128):
   ids=[i for i in range(7) if family>>i&1];widths=[]
   for axis in range(2):
    lower=maximum([boxes[i][axis][0] for i in ids]);upper=minimum([boxes[i][axis][1] for i in ids]);widths.append(canonical(upper-lower))
   signs=[sg(w) for w in widths]
   if any(s<0 for s in signs):area=sp.Integer(0);counts['negative_width']+=1
   elif any(s==0 for s in signs):area=sp.Integer(0);counts['zero_width']+=1
   else:area=canonical(widths[0]*widths[1]);counts['positive_area']+=1
   coefficient=1 if len(ids)%2 else -1;total+=coefficient*area
   family_records.append({'box_family_mask':family,'actual_source_subset_masks':[i+1 for i in ids],'width_signs':signs,'intersection_area_terms':[[r,str(c)] for r,c in exact_terms(area)],'inclusion_exclusion_sign':coefficient})
  total=canonical(total);terms=[[r,str(c)] for r,c in exact_terms(total)];expected=answer['full_union_volume']['exact_squarefree_radical_terms'];assert terms==expected
  rss=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
  if rss>limit:raise MemoryError('256MiB guard')
  records.append({'t':str(t),'u':str(u),'actual_source_boxes':7,'individual_box_width_signs':boxsigns,'box_families_evaluated':127,'intersection_classification':counts,'full_union_exact_terms':terms,'full_union_Arb512':ball(total).str(65),'matches_reference_coefficients_exactly':True,'families':family_records})
 signal.alarm(0)
 result={'scope':'Independent inclusion-exclusion of all 127 nonempty families of seven actual boxes at ten frozen points; no arrangement union or original union-function reuse; not a general upper-bound certificate.',
 'input':{'n':2,'lambda':1,'masses':['1/2','1/3','1/6'],'positions':['(0,0)','(4/5+t,0)','(2/5-2t,7/10+u)'],'cube_convention':'r=sqrt(mS) is SIDE length'},
 'reference':{'path':str(args.reference),'raw_sha256':hashlib.sha256(raw).hexdigest(),'producer_script_sha256':reference['execution']['script_sha256'],'usage':'Frozen input/answer comparison only; no original code imported or executed'},
 'cases':records,'total_box_families_evaluated':sum(r['box_families_evaluated'] for r in records),'all_ten_exact_coefficient_comparisons_match':True,
 'arithmetic':'Independent SymPy exact radical expressions and canonical coefficient extraction; Arb512 signs for maxima/minima and intersection widths; zero/negative intersection widths truncated to zero; no floating comparisons.',
 'execution':{'interpreter':sys.executable,'python':platform.python_version(),'sympy':sp.__version__,'python_flint':flint.__version__,'precision_bits':ctx.prec,'processes':1,'guard_seconds':120,'guard_bytes':limit,'runtime_seconds':time.perf_counter()-start,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'command':shlex.join([sys.executable,str(Path(__file__).resolve()),*sys.argv[1:]])}}
 args.output.write_text(json.dumps(result,ensure_ascii=False,sort_keys=True,indent=2)+'\n')
 print(json.dumps({'points':10,'box_families':1270,'all_exact_matches':True,'execution':result['execution']}))
if __name__=='__main__':main()
