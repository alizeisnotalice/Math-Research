# R496 补充：max-only 标量核的来源混合边界账

只检验一个候选：把高祖先到达先沿同一来源结算到 rank 阈值，再估同父来源更新产生的协方差。使用主代理与独审已核的 max-only 正支配核 \(K_0\)，不是原成功链同 law；不修改已冻结 geometry。结论是准确边界式及唯一缺桥，没有新根阶付款。

## 1. 原生标量核与候选

所有父、质量、来源与 mark 仍来自 R495 的真实场 \(\nu_\tau\)。写 \(\widehat A=(A,s_A)\)，\(\widehat\nu=\nu_\tau\otimes ds\)，\(k=\kappa T\)。固定来源 \(x\) 的原 rank 测度为
\[
 \rho_x(d\widehat A)=c_A(x)\widehat\nu(d\widehat A)/m_A,
 \quad U_x=|\rho_x|,
 \quad v_x(\widehat A)=\rho_x\{\widehat C\prec\widehat A\}.
\]
\(K_0\) 只保输入 \(v_x(\widehat A)\ge k\) 和 raw 非空，按最大父输出。令
\(G=\sum_{j\ge0}(K_0^*)^j1\)。分数质量列给有限 \(G\le\mathcal D=3+8rSL/T\)。目标是实际标量上放的
\[
 I_R=\int b_R(\widehat B)G(\widehat B)\,\widehat\nu(d\widehat B),
 \quad b_R=\pi_B\{v_x(\widehat B)<k\}.
\]
需要 \(I_R\le aR_\tau+C\sqrt n\operatorname{polylog}(n)W\)。以下不删去 \(b_R\) 或来源—父相关。

## 2. 保共同来源的阈值通量

增广 mark 使 rank 将 \(\rho_x\) 推为 \([0,U_x]\) 上 Lebesgue 测度。令 \(g_x(v)\) 是 \(G(\widehat A)\) 对该 rank 的条件均值；不是逐来源重新选择父，也不要求 rank 对父一一对应。

实际 adjoint 公式给
\[
 G(\widehat B)=1+\int\pi_B(dx)F_x(v_x(\widehat B)),
 \quad
 F_x(w)=\frac1T\int_{\max\{w,k\}}^{U_x}
       g_x(v)e^{-(v-w)/T}\,dv.                 \tag{1}
\]
下限超过上限时定义为零。令
\[
 L_x=\frac1T\int_k^{U_x}g_x(v)e^{-(v-k)/T}dv.
\]
若 \(w<k\)，准确地 \(F_x(w)=e^{-(k-w)/T}L_x\)。因此同来源的 head 祖先项为
\[
 S_R:=\int\widehat\nu(d\widehat B)
 \int\pi_B(dx)1_{v_x(\widehat B)<k}F_x(v_x(\widehat B))
 =T(1-e^{-\kappa})\int L_x\,\mu(dx).         \tag{2}
\]
\(U_x<k\) 时 \(L_x=0\)，所以端点公式仍成立。质量原子没有额外遗漏项。

记 max-only 链全部空点停止为
\[
 E_0=\int\widehat\nu(d\widehat A)G(\widehat A)
 \int\pi_A(dx)1_{v_x(\widehat A)\ge k}e^{-v_x(\widehat A)/T}.
\]
同一次 rank 换序给
\[
 E_0=Te^{-\kappa}\int L_x\,\mu(dx),
 \qquad S_R=(e^\kappa-1)E_0.                 \tag{3}
\]
故先前可小价累计的空点停止，若用于同来源 head 祖先通量，会被放大 \(e^\kappa-1\)。不能把这个因子省去。用 \(G\le\mathcal D\) 只给
\(S_R\le T\mathcal DW=(3T+8rSL)W\)，仍非根阶。

## 3. 真正来源更新留下的有符号项

令 \(h_x(\widehat B)=1_{v_x(\widehat B)<k}\)，并在下式中写 \(F_x=F_x(v_x(\widehat B))\)。定义准确来源混合差
\[
 \mathcal C=\frac12\int\widehat\nu(d\widehat B)
 \int\pi_B(dx)\pi_B(dz)
 [h_z-h_x][F_x-F_z].                          \tag{4}
\]
全部量来自同一真实父及两次真实后验积分。由 (1) 的直接展开，
\[
 \boxed{I_R=H_0+(e^\kappa-1)E_0+\mathcal C,\qquad
 H_0=\int\min(U_x,k)\,\mu(dx)\le kW.}       \tag{5}
\]
\(\mathcal C\) 没有固定符号。\(F_x\) 内含真实高祖先 \(G\)、捕获、质量次序和中心测度，不能改为不依来源的平均。

max-only 仅有 head 与空点两类停止，分数质量列确保终端到达趋零，所以另有 \(I_R+E_0=R_\tau\)。这说明 (5) 是准确的账，不是独立降低目标难度；特别不能把它与守恒反复代入后声称获得付款。

唯一需要的新几何比较是控制 (5) 中**共同的**阈值祖先通量与来源混合差：
\[
 (e^\kappa-1)E_0+\mathcal C
 \le aR_\tau+\epsilon X+C_\epsilon\sqrt n
 \operatorname{polylog}(n)W,
 \quad a<1.
\]
当前质量 CDF 只支付了 \(H_0\)，并给出上述线性量级的 \(S_R\)；没有证明跨来源协方差与它之间的有价抵消。故本候选没有取得新的整体预算。具体下一决策是寻找同父 low-rank/high-ancestor 来源交换的联合几何，不能仅重复累计空点小概率或抹掉 \(G\) 的来源条件。

## 4. 实际符号核验

指定本机 Python/SymPy 运行以下自含代码，通过10项边界及协方差恒等式。分段 rank 函数仅为算术核验，不认证原生 cube/history 或任何根阶界。

```python
import sympy as s
v,w=s.symbols('v w', real=True)
checks=0
for base in (2,3,5):
 K=s.log(base); U=3*K
 for g1,g2 in ((1,2),(3,1),(s.Rational(1,3),s.Rational(5,2))):
  L=s.integrate(g1*s.exp(-(v-K)),(v,K,2*K))+s.integrate(g2*s.exp(-(v-K)),(v,2*K,U))
  same=s.integrate(s.exp(-(K-w))*L,(w,0,K))
  empty=s.integrate(g1*s.exp(-v),(v,K,2*K))+s.integrate(g2*s.exp(-v),(v,2*K,U))
  assert s.simplify(same-(base-1)*empty)==0; checks+=1
h1,h2,F1,F2,p=s.symbols('h1 h2 F1 F2 p')
cov=(p*h1+(1-p)*h2)*(p*F1+(1-p)*F2)-(p*h1*F1+(1-p)*h2*F2)
assert s.expand(cov-p*(1-p)*(h2-h1)*(F1-F2))==0; checks+=1
print('PASS',checks,'symbolic rank-boundary / covariance identities; '
      'no geometric budget certified')
```
