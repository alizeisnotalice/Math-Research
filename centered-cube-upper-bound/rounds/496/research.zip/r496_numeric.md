# R496：保 lower configuration 的有限 rank 诊断

已实际执行批准的三例，8124 项 Fraction 精确断言通过：21、21、93 个状态。完整保 bit 的 H 与错误 fresh-reset Q 在本组三例的累计 rank 停止质量恰好相同；没有调参强造差异。模型只实现有限 Bernoulli 有序点过程，不是原连续 J、PPP 近似或原成功核的认证。

决策：H 确实可以使 source-only rank 上升、穿过低秩阈值；J 同来源严格降 rank，不能把二者合成单调 rank。一次 rank 价也小于累计价。不过本 max-only、natural-start toy 的到达密度始终对同 parent/mark 为常数，post-J 仅 source-dependent；因而它未区分配置依赖成功筛选后能否直接平均的主问题。精确 ZH=Q 不等于任意配置函数上 H=Q。

## 实际区间与有限点过程

来源为 0、2/5、1 的正质量原子。C0=[−1/2,1/2]、C1=[1/4,5/4]；扩大加 C2=[−1/4,5/4]。完整捕获矩阵由真实区间核，来源均避开端点。

- 初探：μ=(3,1,8)，两父质量 (4,9)，T=4，rank 阈值 a=3/4。
- ties 压力：μ=(3,1,3)，两父质量 (4,4)，T=2，a=3/4。
- 扩大：μ=(3,1,8)，三父质量 (4,9,12)，T=4，a=5/4。

父测度有限，设 ν_C=m_C；不当作 receiver Lebesgue。每父 mark∈{0,1} 等权；总顺序为 lexicographic(实际质量,mark,parent_index)，最后一项明确解决同 mass/mark tie。这不是原连续 uniform mark。

每 type 恰至多一 Bernoulli 点，概率 p=(1/2)/T。type 的来源 rank 权ρ=ν_C/(2m_C)=1/2。当前 type a、来源 x 时，仅允许严格低于 a 且捕获 x 的候选，rank 定义为

v_x(a)=(1/2)·低候选 type 数+1/4。

所有原子来源的总 U≤T，直接核 toy subreference。这里 a、T 不冒称原 κT、高门或成功参数。无 Poisson multiplicity、截断或 max 同 type 多点的模糊处理。

状态为 (当前父 type/mark,来源 x,严格 lower 候选的 presence 子集)。自然 M 的条件来源为完整 π_C=μ|QC/m_C，配置为独立 Bernoulli product。故每状态质量 M=μ(x)/2×配置概率。

## toy 实际 J、H 和 source-only 投影

J 的三分法为：rank<a 则 rank-stop；否则配置空则 empty-stop；否则选配置最大 type B，保留全部严格低于 B 的现存点，来源不变。每个成功边都核 B<a、v_x(B)<v_x(a)。

H 保父/mark，将来源 Z 重抽为完整 π_B：新旧来源同时捕获的 candidate bits 原样复制；Z 捕获而 X 不捕获的 candidate bits 补独立 Bernoulli；其余删除。所有转移精确枚举。

逐项核 H1=1、MH=M、M_iH_ij=M_jH_ji，且 MJ≤M，因此 P=JH 满足 MP≤M。配置有无被选择不通过重新 fresh 来假定。

定义 Z 为固定 parent/mark/source 后对自然配置作条件平均，Q 为固定 parent/mark 后对完整自然 source/config 作平均。精确矩阵恒等 ZH=Q 全部通过，He_R=b_R(parent,mark) 也逐行通过。b_R 保留输出 mark：

- 初探四 type 的 b_R=(1,0,8/9,0)；
- ties 压力 b_R=(1,3/4,0,0)；
- 扩大六 type 的 b_R=(1,1,8/9,8/9,0,0)。

这些差别不能把 mark 丢掉。H≠Q 的矩阵行数为 18、18、90；ZH=Q 没有把整个 H 变成 fresh reset。

## 累计 rank、通量及完整势账

从自然 M 出发，q_j=(P*)^j1；因 J 严格降有限 type，总链最多 2×父数次成功，最终零到达，没有尾误差。每代核以下精确账：

总到达降=rank-stop+empty-stop；

下一代 rank-stop=本代到达 J b_R；

初始 rank 势=累计停止 rank 势+累计 J rank drop−累计 H rank drift。

这里 H drift 有符号，正值表示 source refresh 增 rank。累计也精确满足 rank-stop−一次 M e_R=Σ到达 J b_R。

| 例 | 自然总 R | 一次 rank-stop | 累计 rank-stop | J rank drop | H rank drift | H low→high / high→low |
|---|---:|---:|---:|---:|---:|---|
| 初探 | 13 | 6 | 55/8 | 1305/2048 | 0 | 1/18，1/18 |
| ties 压力 | 8 | 7/2 | 9589/2048 | 3669/4096 | −87/1024 | 3/32，87/512 |
| 扩大 | 25 | 12 | 69581/4608 | 4372241/1179648 | −5/72 | 5/24，5/18 |

三例累计质量均非一次质量；H 双向阈值通量都非零。它们只说明账必须保 drift/停止量，不给原 rank 累计预算阶数。

## full H 与 fresh Q 的零差异及其原因

比较保持同一个 toy J，只把 H 替成 Q（每步重新完整 source/config natural reset）。三例累计 rank-stop、各代质量与势账结果均相同，累计差恰为 0。

代码额外精确核所有实际代数中的两条结构：

1. 到达密度在固定 parent/mark 上为常数；
2. 经过 max-only J 后，密度只依 parent/mark/source，不依 lower configuration。

于是 H 对这些特殊密度的作用与 Q 相同，解释零差异；不是 H=Q。原成功门依赖所选配置、几何和旧标签，可能破坏此结构，本 toy 未包含它们。因而本轮不能据零差异为原链每代重建 fresh PPP 辩护，也不为找到非零差异而扩展模型。

## 资格与复现

实际区间捕获、完整原子质量、有限 mark/tie、Bernoulli 配置和 toy max/update 转移全部精确；未认证原 L1 来源、连续 receiver、连续 uniform mark、lowGram、strict massgap、外置/no-hit/high-h 或原 history。没有将自然条件律当作成功筛选后的条件 fresh。

命令：

`/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/r496_numeric.py`

实际使用指定独立 Python 3.12.14。纯 Fraction 精确算术，无 float、solver、MC、配置 count 截断或无限尾。compute_index 记录解释器、版本、命令和动态耗时。

固定 stdout：`PASS 8124 exact assertions;3 Bernoulli/configuration cases;ZH=Q,rank flux,potential and full/fresh comparison`。

自含输入和全部每代账见 JSON。归档白名单仅 `/tmp/r496_numeric.py`、`/tmp/r496_numeric.json`、`/tmp/r496_numeric.md`。完成限定任务后停止。
