# 第496轮：完整低秩停止流的最大父正支配与显式父核

## 本轮目标及状态

延续已推送 R495，不改变一般中心立方体 n^(1/2+o(1)) 一致弱型目标。当前完整固定带余流保 μ=f dx、W、真实接收 σ=q_A dA、X、原ντ=tσ|t≥τ 与全部原条件记录；低接受率原截断只付一次τX。全质量窗 L=log r+n log(b/a)，T、κ及α沿R495，不重设原质量或原历史。R495已付全部非rank几何失败累计≤ε_g Rτ。

本轮新增一般结构：在相同raw候选域上删除配置成功门，保rank门与最大父规则，得到严格正支配链。其自然初值到达密度在父及mark上闭合，原实际低秩累计费用因而可由显式父Volterra核控制。新链高rank空样本的累计费用有明确的维数无关来源价。没有取得剩余rank根阶价；完整一般目标与母账仍未闭合。

有限数值实际改变了推导方向：max-only toy的full/fresh累计账相等，提示Palm闭合；随后另加预先固定的配置门，验证正支配而非误称原筛选链fresh同律。一般结构由测度/Palm证明和独审认证，不从有限实验外推。

## 原状态与正支配

令自然状态ξ=(Â,x,F)，Â=(A,s_A)，F为全部严格lower raw PPP。μ、ντ和各cube固定，
\[
 \rho_x(d\widehat A)=1_{Q_A}(x)\nu_\tau(dA)ds_A/m_A,
 \quad v_x(\widehat A)=\rho_x\{\widehat C\prec\widehat A\},
 \quad U(x)=\rho_x(\text{全部候选}),\quad K=\kappa T.
\]
增广mark保质量原子。J0只在v_x(Â)≥K且F非空时取F最大点B，并输出同一来源及全部lower raw配置；H仍用同一个交集留点/差集补点机制。投影原额外标签后，原J是该J0的正限制。因此
\[
 J\le J_0,\quad P=JH\le P_0=J_0H.
\]
对非负父密度η，最大点Palm给
\[
 J_0^*\eta(\widehat B,x,F)=\frac1T
 \int_{\widehat A\succ\widehat B}\eta(\widehat A)
 1_{v_x(\widehat A)\ge K}e^{-(v_x(\widehat A)-v_x(\widehat B))/T}
 \rho_x(d\widehat A),
\]
与输出lower配置无关。H将source-only函数送到其π_B平均，故η_j=(P0*)^j1仅依父及mark，而且
\[
 0\le q_j\le\eta_j\le\min\{1,e^{\alpha L}2^{-j}\}.
\]
这不是把实际q_j声称成父密度，也不赋给辅助父任何原成功历史。

## 显式父核及完整目标

对νhat=ντ ds定义父核
\[
 K_0(\widehat A,d\widehat B)=1_{\widehat B\prec\widehat A}
 \frac{\nu_\tau(dB)ds_B}{Tm_B}
 \int\pi_A(dx)1_{Q_B}(x)1_{v_x(\widehat A)\ge K}
 e^{-(v_x(\widehat A)-v_x(\widehat B))/T}.
\]
η_j=(K0*)^j1，相对νhat取伴随。令b_R(Â)=π_A{v_x(Â)<K}，则全部实际低秩累计量满足
\[
 R_{\rm rank}^{\rm actual}\le
 R_{\rm rank}^0:=\sum_{j\ge0}\int\eta_j b_R\,d\widehat\nu.
\]
原完整固定带账仍为
\[
 (1-\varepsilon_g)R_\tau\le R_{\rm rank}^{\rm actual}\le R_{\rm rank}^0.
\]
这与R495整族割是可选的两条上界，不将它们的吸收收益重复使用。原空间中心、完整质量分母、mark与来源积分在K0中全部保留。

首列的source integrand为
\[
 \left[e^{-(K-w)_+/T}-e^{-(U-w)/T}\right]_+,\qquad w=v_x(\widehat B)\le U.
\]
U<K时必须为零，不能保未经截断的负指数差。将此列对π_B平均得到η_1；所有层继承R495分数质量支配。

## 空样本的完整付款与未付量

新链仅有rank停止及高rank空样本停止。自然空样本费≤T exp(−κ)W。令D=3+8rSL/T，则
\[
 R_{\rm empty}^0\le DT e^{-\kappa}W,\qquad
 R_\tau=R_{\rm rank}^0+R_{\rm empty}^0.
\]
等式使用有限停止恒等式及分数质量帽保证终端趋零。固定P=rS、H0=S/τ、Cg=512PH0+4P+S，Tmin=4096PH0，R495完整参数选择还给
\[
 DT e^{-\kappa}\le C_{\rm empty}
 =(256PH_0)^8\left(\frac3{T_{\min}^7}
       +\frac{\varepsilon_g}{2C_g T_{\min}^6}\right).
\]
这是固定参数下的维数无关费用，证明见raw_dominance。于是raw rank与原Rτ仅差一笔已付来源费；将其写成父核并不意味着根阶估计自动成立。只用分数帽仍有DκTW的线性级损失。下一步必须在同一真实cube核上联合估计b_R与累计η_j；不能只重写Green递推或优化empty常数。

## 其他已核结构及没有奏效的尝试

1. 保真实新低rank来源后按整族质量选child，交集上的rank资格可继承。但准确保留比例受m_B/G_F及b_R控制，低Gram给上界而非所需恢复下界。丢量精确等于旧人工来源x到新来源z的冻结族捕获差；不能免费改为child低rank流。geometry保留全部损失，不计新付款。
2. 单步同源J跨阈值自然费用≤TW，比初始κTW少κ；累计仍需真实到达权。rank停止精确为crossing−rescue+refresh，源更新不保持rank。逐父binary协方差与源零阶能量核验通过，但线性恢复仍有时间深度；不把能量界当完整源价。proof保负救回、所有终端及平方/线性权区别。
3. 标量父核下若进一步分析来源协方差，必须保同父mark和指数边界因子；不能用极小empty费用直接支付放大后的head祖先费。scalar_geometry证明精确式 I_rank=H0+(exp(κ)−1)E_empty+C_source，保同父两来源协方差。这只定位具体待证桥，不作为已付源价。

## 本机实验、误差与复现

使用指定独立Python环境，实际运行SymPy与Fraction精确算术。本轮不调用不需要的求解器，不做无目标参数扫描。

numeric：三例Bernoulli有序点过程，21/21/93状态，8124项断言。来源用真实区间捕获的正原子，但父测度和mark离散，不认证原连续接收场、L1来源或全部成功门。初探、同质量压力及扩大实例分别报告。严格核ZH=Q、H不等于Q、自然不变性、双向阈值通量及完整停止账。三例max-only的full/fresh账相等。

domination：唯一预先固定的配置门在扩大例删除18成功行，8980项精确断言。逐状态逐代核J_gate≤J0、真实到达≤raw父密度、累计rank支配及父核基底闭合。人工门下full/fresh差为正；用途是限定闭合的适用范围，未调参寻找反例，不认证原几何门。

geometry另36项Fraction、proof另28项符号/有理检查、raw_dominance另9项符号端点与PGF检查。scalar_geometry另10项符号检查。合计17187项报告核验单位，包含复用的基本矩阵检查，既非独立模型数也非一般证明数。各脚本的有限结果不证明一般阶数。最终replay JSON记录实际stdout与结果规范SHA；仅剔除动态耗时。先独立预审，再阅读作者稿最终核验；详细LaTeX随包，不编译PDF。

## 全入口与下一步判据

总入口倍率64(128/119)/(1−32δ_old−16η_old)继续保留。原初始、跳跃删除、未来被删来源、宽距离、低强度、极端比例及全尺度未付槽不能省。τ及各吸收系数先按母账分配；δ_succ不等于δ_old。

本轮把一个覆盖完整rank量的上界变为可直接研究的显式父核，并支付其空样本项；未支付核心rank量。成功判据仍是对该完整量取得可吸收aRτ加根阶来源价，或返回R495同一实际割取得等价联合预算。有限模型、标量化及单步TW费用都不代替一般闭合。
