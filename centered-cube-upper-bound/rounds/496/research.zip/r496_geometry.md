# R496：同一低秩停止来源的保标签子父分配

本稿只检验一个机制：在 R495 的完整线性 rank 停止流上保留实际新来源 \(z\)，以整族质量权选择子父，利用增广质量次序继承低秩资格。结论是准确的正分拆及恢复上界；该机制没有给出新的根阶费用。它明确为何不能把 \(\Theta_R\) 自动视为 child-lowrank 流，也不将新的符号当作付款。

## 1. 精确输入与候选

沿 R496 合同使用同一 \(\nu_\tau,\mathsf M,J,H_{\rm src},P,q_j\)。实际成功记录 \(\omega\) 保父 \(A\)、原来源、阶段、所有成功门、最大父 \(\widehat B=(B,s_B)\) 与低 Gram 族 \(F_0\)。记
\[
 G_F=\sum_{C\in F_0}m_C,\quad
 E_{\widehat B}=\{z\in Q_B:v_z(\widehat B)<\kappa T\},\quad
 b_R(\widehat B)=\mu(E_{\widehat B})/m_B.
\]
来源更新 \(H_{\rm src}\) 保父与 mark，并新抽 \(z\sim\pi_B\)。因 rank 停止只依该新来源，积分更新后的配置可得准确提升
\[
 d\widetilde\rho_R(\omega,z)
 =\sum_{j\ge0}q_j(s)\mathsf M(ds)J^{\rm rec}(s,d\omega)
 \pi_B(dz)1_{E_{\widehat B}}(z).                 \tag{1}
\]
其记录投影正是原 \(\rho_R\)，不是另一条分析链。式 (1) 保新旧来源区别，亦保全部旧历史；新来源不继承旧来源的门。

按原 \(m_C/G_F\) 附加子父 \(C\)。候选正分支保留 \(z\in Q_C\)。这样没有刷新来源、重建历史或重采父。希望借此把整族需求送到真正低秩子父，而不是只使用无标记低 Gram 容量。

## 2. rank 继承与准确恢复量

每个 lower 子父 \(\widehat C\prec\widehat B\)，且二者秩均用同一全质量窗、同一 \(\nu_\tau\) 定义。因此对每个固定来源 \(z\)，
\[
 v_z(\widehat C)\le v_z(\widehat B).
 \tag{2}
\]
质量原子内部的 mark 次序也满足此式。若 \(z\in E_{\widehat B}\cap Q_C\)，则该子父的同来源 rank 确实小于 \(\kappa T\)。这是合法资格继承，仅涉及 rank，不涉及旧历史。

对 \(b_R>0\) 的实际记录，候选保留的条件行质量为
\[
 r(\omega)=\frac1{b_R(\widehat B)}
 \sum_{C\in F_0}\frac{m_C}{G_F}
 \pi_B(E_{\widehat B}\cap Q_C).                \tag{3}
\]
\(b_R=0\) 的记录没有 \(\rho_R\) 质量，可令 \(r=0\)。有
\[
 0\le r\le1,\qquad
 R_{\rm keep}=\int r\,d\rho_R,
 \quad R_{\rm loss}=\int(1-r)\,d\rho_R,
 \quad R_{\rm keep}+R_{\rm loss}=|\rho_R|.     \tag{4}
\]
丢失项精确为实际低秩新来源落在选中子父之外的费用，不是额外无标记量。最大父始终保留，故 \(r\ge m_B/G_F\)。

## 3. 低 Gram 给的是恢复上界，而非缺失的下界

最大父行满足 \(\sum_{C\ne B}\gamma_{BC}\le1/2\)，且 \(m_C\le m_B\)。所以
\[
 \sum_{C\ne B}\pi_B(Q_C)
 =\sum_{C\ne B}\gamma_{BC}\sqrt{m_C/m_B}\le\tfrac12.
 \tag{5}
\]
保留真实低秩集合，正上放一次给
\[
 \sum_{C\in F_0}\frac{m_C}{G_F}
 \pi_B(E_{\widehat B}\cap Q_C)
 \le\frac{m_B}{G_F}\left(b_R(\widehat B)+\tfrac12\right).
\]
于是准确范围为
\[
 \boxed{\frac{m_B}{G_F}\le r(\omega)
 \le\min\left\{1,\frac{m_B}{G_F}
       \left(1+\frac1{2b_R(\widehat B)}\right)\right\}.} \tag{6}
\]
这里 \(b_R\) 是实际接受中的停止权，不能为了消分母而删掉。若 \(b_R\) 有固定下界，则这种“不改新来源”的候选随 \(G_F/m_B\) 增大反而只能恢复小比例。式 (6) 是一般结构界，不是构造反例，也不否定其他全局分配。

低秩继承亦不自动产生标准 child 来源律。对固定记录和子父，实际未归一来源因子是
\[
 \frac{m_C}{G_F}\pi_B(dz)1_{E_{\widehat B}\cap Q_C}(z)
 =\frac{m_C^2}{G_Fm_B}
 1_{E_{\widehat B}}(z)c_B(z)\pi_C(dz).         \tag{7}
\]
因此必须同时保原父条件权和交集限制；不能将右端径直替换成原 \(\nu_\tau(dC)\pi_C(dz)\) 的低秩头部。来源 \(z\) 所见候选稀少，并不等于原人工来源 \(x\) 的成功族入流稀少。

## 4. lostflow 的真实旧来源—新来源通量

令 \(x=x(\omega)\) 为成功配置原人工来源，并冻结该记录的原族，定义
\[
 a_F(w)=\sum_{C\in F_0}\frac{m_C}{G_F}c_C(w),
 \qquad 0\le a_F\le1,\qquad a_F(x)=1.
\]
由 (1)、(3)、(4)，失去的质量可准确写成同一来源通量的正负差：
\[
 \boxed{R_{\rm loss}=\sum_j\int q_j\,d\mathsf M\,
 J^{\rm rec}(d\omega)
 \int\pi_B(dz)1_{E_{\widehat B}}(z)
 [a_F(x)-a_F(z)].}                            \tag{8}
\]
第一项为原 rank 终止量，第二项为上述保交集分支；二者使用同一个原族和同一停止门。被积差非负，且包含真正的旧人工来源 \(x\) 与新来源 \(z\)，没有将原旧 pair 换成它们。

(8) 不是已付耗散。\(H_{\rm src}\) 的参考可逆性不能直接消掉此差：实际输入带 \(q_jJ^{\rm rec}\)，并只在新来源端带低秩门；测试 \(a_F\) 冻结于更新前的成功族。交换两来源时必须连同配置更新和这些权一起交换，不能将 \(a_F\) 当作同一状态函数的无权平稳差。这正是仍需证明的跨来源联合比较，而非另立一个自由余项。

## 5. 完整账与唯一未付步骤

R495 已付非 rank 累计 \(\varepsilon_gR_\tau\)，一次头部 \(\mathsf M(e_R)\le\kappa TW\)，以及原输入一次低 \(t\) 损失 \(\tau X\)，全部保持。式 (4) 没有额外费用，也没有减去任何原质量。

若要沿本候选得到完整目标，必须对同一实际 \(\rho_R\) 证明：保留部分的来源列价与 \(R_{\rm loss}\) **共同**至多
\(aR_\tau+\epsilon X+C_\epsilon\sqrt n\operatorname{polylog}(n)W\)，且有足够吸收余量。当前 (2) 只保证子父 rank 资格，(6) 不提供该共同付款，(7) 不消除跨父入量。直接对各代使用自然低秩容量仍回到 R495 的 \(\kappa(3T+8rSL)W\)。

所以这条路不能靠“交集保 rank”少付累计深度。下一几何比较须作用于实际旧人工来源 \(x\) 到新低秩来源 \(z\) 的跨 rank 通量，连同丢失项 (4) 一起结算；不能先强求低秩 \(z\) 落入低 Gram 子族，再把失败视为已付。本文没有取得新全局费用估计，亦没有改变 R496 的完整目标。

## 6. 本机小型精确核验

指定 Python 实际运行下列代码，输出 `PASS 36 exact rank-inheritance / retained-loss interface checks; no native-history certification`。有限来源集合只检验共序 rank、分拆及恢复上界；不是原连续接收场或完整成功历史实例。

```python
from fractions import Fraction as F
checks=0
for k in (1,2,3):
 cubes=[{0}|set(range(1+7*i,8+7*i)) for i in range(k+1)]
 B=cubes[-1]; children=cubes[:-1]; m=F(8); G=m*(k+1)
 allx=set().union(*cubes)
 rankB={z:sum(F(i+1) for i,C in enumerate(children) if z in C)
        for z in allx}
 for h in (F(1,2),F(3,2),F(4)):
  E={z for z in B if rankB[z]<h}; b=F(len(E),8)
  ret=sum(m/G*F(len(E&C),8) for C in cubes)
  loss=sum(m/G*F(len(E-C),8) for C in cubes)
  assert ret+loss==b; checks+=1
  assert ret>=m/G*b; checks+=1
  assert ret<=m/G*(b+F(1,2)); checks+=1
  for i,C in enumerate(children):
   for z in E&C:
    rankC=sum(F(j+1) for j in range(i) if z in children[j])
    assert rankC<=rankB[z]<h
  checks+=1
print('PASS',checks,'exact rank-inheritance / retained-loss interface '
      'checks; no native-history certification')
```
