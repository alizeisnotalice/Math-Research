# R496：真实 rank 跨阈值与来源刷新通量

沿 R496 合同的一条固定新链，记自然参考为 \(\mathsf M\)，总量 \(R=R_\tau\)，\(P=JH\)，\(q_j=(P^*)^j1\)，\(h_j=J^*q_j\)。本稿不改原历史或刷新规则。令
\[
 K=\kappa T,\quad r(\xi)=v_x(A,s_A),\quad
 E(\xi)=1_{\{r<K\}},\quad b=HE=\pi_A\{v_z(A,s_A)<K\}.
\]
\(E=e_R\)，低秩先失败，故 \(EJ1=0\)。\(J\) 的实际成功边保持来源 \(x\)，输出增广 rank \(w<r\)；质量原子经 uniform mark 展开。来源刷新 \(H\) 保父与 mark，不能声称保 rank。

本轮证明单步同源跨阈值流的来源价为 \(TW\)，并将它与真实刷新救回通量放入同一精确账。现有累计能量仍留下深度损失，没有取得完整根阶付款。

## 1. 单步同源 crossing 的精确自然价格

固定来源 \(x\)，全窗 rank 长度为 \(U(x)\)。自然输入 rank 为 Lebesgue \(dv\)；raw 最大点 rank 核为
\[
 1_{0<w<v<U}\,T^{-1}e^{-(v-w)/T}\,dw.
\]
它来自自然配置的 Palm 分解，不是实际成功条件下重抽 PPP。去掉成功门只作正上放。因此
\[
 \begin{aligned}
 \mathsf MJE
 &\le\int\mu(dx)1_{\{U>K\}}
   \int_K^U\int_0^K T^{-1}e^{-(v-w)/T}\,dw\,dv\\
 &=T\int 1_{\{U>K\}}
 (1-e^{-K/T})(1-e^{-(U-K)/T})\,d\mu
 \le TW. \tag{1}
 \end{aligned}
\]
输入 \(v<K\) 的实际 \(J\) 为零，这一点已用于第一行。\(U\le K\) 时 crossing 为零；阈值相等集在增广 rank 上零测，未删除质量原子。

真实到达权一般依赖整配置，故只能在正积分后用已证
\(q_j\le a_j=\min(1,e^{\alpha L}2^{-j})\)：
\[
 C_j:=\int h_jE\,d\mathsf M
 =\int q_j\,d\mathsf MJ E\le a_jTW,
 \qquad \sum_jC_j\le A_*TW,
 \quad A_*\le3+4rSL/(T\log2). \tag{2}
\]
不能在固定输入 \(A,x\) 后，把带 \(q_j\) 的配置再当 fresh PPP。式(2)的累计价仍为 \(O((T+L)W)\)，不是根阶。

## 2. 同一实际流上的 crossing、救回与新停止

在成功输出、刷新之前定义
\[
 U_j=\int h_jE(1-b)\,d\mathsf M,\qquad
 D_j=\int h_j(1-E)b\,d\mathsf M.
\]
\(U_j\) 是先由 \(J\) 降至低 rank、再被 \(H\) 救回高 rank 的质量；\(D_j\) 是输出仍高 rank、刷新后变低 rank 的质量。给定整个刷新前状态，后来源的边缘准确为 \(\pi_A\)，所以这两个式子保原记录且不用配置独立假设。逐代有
\[
 \boxed{\langle q_{j+1},E\rangle=C_j-U_j+D_j,\qquad
 D_j-U_j=\langle h_j,b-E\rangle.} \tag{3}
\]
尤其不可将 \(C_j+D_j\) 当作无重复的全部 rank 停止，或删 \(-U_j\) 后宣称有净耗散。

令 \(Z\) 为给定父、mark、来源后对配置的条件均值，\(Q\) 为仅给定父、mark 的条件均值。R486 的自然 \(H\) 满足 \(ZH=Q\)，因此 \(Zq_j=Qq_j\) 对 \(j\ge1\) 成立；这**不**表示 \(q_j=Qq_j\)。由于 \(b-E\) 是来源函数且逐父均值零，
\[
 D_j-U_j=\langle(Z-Q)h_j,b-E\rangle.
\tag{4}
\]
自然参考下
\[
 \|b-E\|_2^2=\int\nu(dA)ds_A\,b(1-b)
 \le\mathsf ME=\int\min(U,K)d\mu\le KW. \tag{5}
\]
这是实际固定测试的来源价。使用已证源零阶能量
\(\sum_j\|(Z-Q)h_j\|_2^2\le R\)，有限 \(N\) 只能直接得到
\[
 \left|\sum_{j<N}(D_j-U_j)\right|\le\sqrt{N KWR}. \tag{6}
\]
低捕获 chaos 能量不与这里的源零阶能量混同，也未重复扣除同一信用。

准确线性停止账为
\[
 \sum_{j\ge0}\langle q_j,E\rangle
 =\mathsf ME+\sum_{j<N}(C_j-U_j+D_j)+\mathcal T_{N+1},
 \quad
 0\le\mathcal T_{N+1}\le\mathsf Mq_{N+1}
 \le e^{\alpha L}2^{-N-1}R. \tag{7}
\]
这里 \(\mathcal T_{N+1}=\sum_{j\ge N+1}\langle q_j,E\rangle\)；其控制来自总停止恒等式，不是将其冒充一个点态密度。所有和有限，由 R495 到达帽保证。

由(2)、(5)–(7)，对任意 \(N\ge1\)、\(\varepsilon>0\) 得真实估计
\[
 \sum_j\langle q_j,E\rangle
 \le KW+A_*TW+\varepsilon R+\frac{NKW}{4\varepsilon}
       +e^{\alpha L}2^{-N-1}R. \tag{8}
\]
取 \(N\asymp\alpha L+\log(1/\varepsilon)\)、\(T\asymp\sqrt{L+1}\) 后，\(NKW\) 仍含 \(\kappa LW\)。所以(8)未改善完整根阶目标；一次 \(TW\) crossing 价不能消去来源刷新次数。

## 3. 截断 rank 势为何没有额外免费符号

用 \(\phi(r)=(1-r/(2K))_+\)，则 \(E\le2\phi\)，\(\mathsf M\phi\le KW\)。同源最大父使 \(\phi(w)-\phi(v)\ge0\)。逐代守恒给完整恒等式
\[
 \sum_{j<N}\langle q_j,e\phi\rangle
 =\mathsf M\phi-\langle q_N,\phi\rangle
 +\sum_{j<N}\int q_j\,d\mathsf MJ^{rec}[\phi(w)-\phi(v)]
 +\sum_{j<N}\langle h_j,H\phi-\phi\rangle. \tag{9}
\]
终端负项保留；\(e=E+e_G\)，不是只 rank 失败。正 rank 降幅位于右边，不能称为支付停止的负信用。

更一般，对单调不增、总变差至多1的 \(\phi\)，阈值 layer-cake 和(1)的 raw crossing 积分给自然单步正降幅至多 \(TW\)；累计仍需真实 \(q_j\)。式(9)没有把刷新 signed 项变为有利符号，也没有使每代固定测试只收费一次。

因此本机制最窄未证比较是：须在**同一实际成功记录与同一刷新**上，对
\(\sum_j(C_j-U_j+D_j)\) 给根阶来源价（或可吸收 \(R\)），而非分别支付自然 crossing 和重复使用固定来源测试。已证(1)及(6)分别给 \(A_*TW\)、\(\sqrt{N KWR}\)，不足以完成该比较。本稿不新增割或改换原 \(\Theta_R\)，也不把精确守恒重新命名为付款。

## 4. 一项有限修补：逐父 binary 协方差的精确能量

为不把父纤维先粗合并，固定增广父 \(\widehat B=(B,s_B)\)，定义
\[
 u_j(\widehat B,x)=Zh_j,\quad g_j(\widehat B)=Qh_j,
 \quad \chi_B=b_B(1-b_B),
\]
\[
 F_j(\widehat B)=g_jb_B-\int u_j(x)E(\widehat B,x)\pi_B(dx).
\]
这里 \(u_j\) 保实际配置的条件平均，不是重新取原接受记录或 fresh PPP。全局刷新通量是 \(\int F_j\,d\nu\,ds_B\)。在 \(0<b_B<1\) 的纤维上作真正正交分解
\[
 u_j-g_j=-\frac{F_j}{\chi_B}(E-b_B)+u_j^\perp,
 \quad \int u_j^\perp\,d\pi_B=\int u_j^\perp(E-b_B)d\pi_B=0.
\]
因此
\[
 \operatorname{Var}_{\pi_B}(u_j)
 =\frac{F_j^2}{\chi_B}+\|u_j^\perp\|_{L^2(\pi_B)}^2. \tag{10}
\]
\(b_B=0\) 或1时 \(F_j=0\)，商定义为0，剩下全部方差；没有零分母假设。

把(10)放入 R490 同参考联合能量，有限时域得到
\[
 \boxed{\sum_{j<N}\int\frac{F_j^2}{\chi_B}\,d\nu ds_B
 +\sum_{j<N}\int q_j^2e\,d\mathsf M
 +\frac34\sum_{j<N}\|(I-\Pi_{\rm hi})h_j\|_2^2
 \le R-\|q_N\|_2^2.} \tag{11}
\]
还可以保留 \(\sum_j\int\|u_j^\perp\|^2d\nu ds_B\) 及原其他非负差。这里付款权是 \(q_j^2e\)，不得改成 \(q_je\)。\(\Pi_{\rm hi}\) 是原 high-only 条件投影，不是 \(Q\)。因此(11)是同流真实能量接口，不借用旧 BH 信用。

这比仅记录无条件协方差保留了每父的稀有低秩因子 \(\chi_B\)，但恢复未平方的累计 signed 通量时仍只得到
\[
 \left|\sum_{j<N}\int F_jd\nu ds_B\right|^2
 \le\left(\sum_{j<N}\int F_j^2/\chi_B\right)
       N\int\chi_Bd\nu ds_B
 \le R N K W. \tag{12}
\]
\(\int\chi_B\le KW\) 是一份固定来源价，而重复的时间因子尚无可求和替代。只有进一步证明同一实际 \(F_j\) 的有符号累积与 J crossing/救回共同减少该时间权，才可能改进(8)。已知 \(q_j\) 的几何帽只能限制有效代数约 \(L/T\)，不使其成为常数。本轮候选据此停下：没有新增超越深度的来源付款，也不把(11)的二次能量当作线性停止收据。

## 5. 实际本机检查

以下脚本以 SymPy 核连续 rank 积分，再用 Fraction 核两来源纤维上的救回符号及能量方向。它不是实际 Lebesgue 接收场或完整成功历史的模拟。

```python
import sympy as s
from fractions import Fraction as F
v,w,T,K,U=s.symbols('v w T K U',positive=True)
inner=s.integrate(s.exp(-(v-w)/T)/T,(w,0,K))
raw=s.integrate(inner,(v,K,U))
target=T*(1-s.exp(-K/T))*(1-s.exp(-(U-K)/T))
assert s.simplify(s.expand(raw-target))==0
checks=1
for a in [F(0),F(1,3),F(1)]:
    for b in [F(0),F(1,2),F(1)]:
        crossing=a/2
        rescue=a/4
        down=b/4
        post=(a+b)/4
        assert post==crossing-rescue+down
        assert down-rescue==(b-a)/4
        vh=(a-b)**2/4
        ve=F(1,4)
        assert (down-rescue)**2==vh*ve
        checks+=3
print(f'{checks} symbolic/Fraction assertions PASS; rank and two-source algebra only.')
```

实际运行 stdout：`28 symbolic/Fraction assertions PASS; rank and two-source algebra only.`。一般证明不依赖有限检查。
