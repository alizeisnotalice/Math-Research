# R496 补充：max-only 正上放链的精确父闭合

本稿不改已冻结的 `r496_proof.md`。结论是：原实际 rank 累计费可由一个明确的父—mark Volterra 链支配，其从自然初值出发的密度不再依赖来源或配置。这个结论仅对删除配置依赖成功门后的新上放链成立；没有把原成功条件下的配置当 fresh PPP，也没有证明根阶来源预算。

## 1. 同一状态、同一 raw 域、不同成功判据

保 R495 重建后的单窗候选域 \(E_\tau\)、原 \(\nu=t\sigma\)、来源 \(\mu\)、质量 \(m_A\) 和 uniform mark。自然状态为 \(\xi=(\widehat A,x,F)\)，\(\widehat A=(A,s_A)\)，\(F\) 是捕获 \(x\)、增广序严格低于 \(\widehat A\) 的全部 raw PPP。定义
\[
 \rho_x(d\widehat A)=c_A(x)\nu(dA)ds_A/m_A,
 \quad v_x(\widehat A)=\rho_x\{\widehat C\prec\widehat A\},
 \quad U(x)=\rho_x(E_\tau\times[0,1]).
\]
自然参考 \(\mathsf M\) 与原 \(J,H\) 完全相同。记 \(K=\kappa T\)。

定义 \(J_0\)：只检查输入 \(v_x(\widehat A)\ge K\) 及 \(F\ne\varnothing\)；通过后取 \(F\) 的增广最大点 \(\widehat B\)，输出 \((\widehat B,x,F_{<\widehat B})\)。删除原其余成功门，不改变候选域、最大点规则或输出的全部 lower 配置。因为原每个成功记录均通过这两个检查，并输出同一个最大父及同一 lower 配置，投影掉其他记录标签后有正核不等式
\[
 0\le J\le J_0,\qquad P=JH\le P_0:=J_0H. \tag{1}
\]
原条件记录的成功概率可依赖整个 \(\xi\)，但仍是 \([0,1]\) 中的薄化因子。若更改 raw 域、输出筛后族 \(F_0\) 或更改 \(H\)，(1)不自动成立；本稿不作这些更改。

## 2. 父密度经 Palm 后为来源密度，刷新后回到父密度

令 \(\eta(\widehat A)\ge0\) 为可测父密度。固定来源 \(x\)，原增广 rank 将 \(\rho_x\) 推为 \([0,U(x)]\) 上 Lebesgue 测度；质量原子由 mark 展开。最大点 Palm 分解给
\[
 (J_0^*\eta)(\widehat B,x,F)
 =h_\eta(\widehat B,x)
 :=\frac1T\int_{\widehat A\succ\widehat B}
 \eta(\widehat A)1_{\{v_x(\widehat A)\ge K\}}
 e^{-[v_x(\widehat A)-v_x(\widehat B)]/T}\rho_x(d\widehat A).
 \tag{2}
\]
输出下方 PPP 的因子恰是自然参考中的同一个因子，故右侧**不依赖 \(F\)**。若 \(\eta\) 自身依赖配置或来源，不能套用(2)得同样闭合。

自然 \(H\) 自伴，且对任意只依赖父、mark、来源的函数 \(h\)，
\[
 Hh(\widehat B,x,F)=\int h(\widehat B,z)\pi_B(dz).
 \tag{3}
\]
这是新来源的边缘为 \(\pi_B\) 的定义，不要求来源与输出配置独立。由 \(P_0^*=HJ_0^*\)，(2)–(3)表明父密度子空间被 \(P_0^*\) 保持。

定义 \(\eta_0=1\)，
\[
 \eta_{j+1}(\widehat B)=\int h_{\eta_j}(\widehat B,x)\pi_B(dx).
 \tag{4}
\]
则严格有
\[
 (P_0^*)^j1=\eta_j(\widehat A),\qquad
 0\le q_j=(P^*)^j1\le\eta_j(\widehat A). \tag{5}
\]
第二式由(1)对非负函数归纳。它对原实际流作正上放，没有把实际 \(q_j\) 宣称成父密度。

## 3. 显式父 Volterra 核与一代公式

写 \(\widehat\nu(d\widehat A)=\nu(dA)ds_A\)。由 Tonelli，(4)是以下次 Markov 父核对 \(\widehat\nu\) 的伴随递推：
\[
 \begin{split}
 K_0(\widehat A,d\widehat B)
 ={}&1_{\{\widehat B\prec\widehat A\}}
 \frac{\nu(dB)ds_B}{Tm_B}\\
 &\times\int\pi_A(dx)c_B(x)1_{\{v_x(\widehat A)\ge K\}}
 e^{-[v_x(\widehat A)-v_x(\widehat B)]/T}.
 \end{split} \tag{6}
\]
所有中心、质量分母、来源及 mark 保留。相同质量时仍有 mark 次序；不得改成严格 \(m_B<m_A\)。核行质量为
\[
 K_01(\widehat A)=\int\pi_A(dx)
 1_{\{v_x(\widehat A)\ge K\}}(1-e^{-v_x(\widehat A)/T})\le1.
\]
故其失败由原低 rank 及高 rank 空样本构成。式(6)不带原其他成功门，不能用于给辅助父继承那些历史资格。

对 \(\eta_0=1\)，令 \(w=v_x(\widehat B)\le U(x)\)。准确一代来源密度为
\[
 h_1(\widehat B,x)
 =1_{\{U(x)\ge K\}}
 \left[e^{-(K-w)_+/T}-e^{-(U(x)-w)/T}\right]
 =\left[e^{-(K-w)_+/T}-e^{-(U(x)-w)/T}\right]_+.
 \tag{7}
\]
再对 \(\pi_B\) 平均即 \(\eta_1\)。当 \(U<K\) 时必须为零；未经截断的两个指数之差为负，不能是列密度。\(U=K\) 时也为零。零来源行或零 \(\nu\) 行按参考零测处理。

删 rank 门只增大 raw 列，所以 \(\widehat\nu K_0\le\widehat\nu\)。R495 分数质量闭尾同样对 \(J_0\) 成立：其证明只用最大点 Palm 及正限制，不需低 Gram 成功。因此
\[
 0\le\eta_j(\widehat A)\le
 \min\{1,(m_+/m_A)^\alpha b_\alpha^j\}
 \le\min\{1,e^{\alpha L}2^{-j}\}. \tag{8}
\]
\(H\) 保父质量，原子处理与 R495 相同。此式保证下面全部累计积分有限。

## 4. 对原 rank 目标的准确含义

记
\(b_R(\widehat A)=\pi_A\{v_x(\widehat A)<K\}\)。因为 rank 测试只依赖父、mark、来源，(5)给出
\[
 \boxed{\sum_{j\ge0}\int q_j e_R\,d\mathsf M
 \le\sum_{j\ge0}\int\eta_j(\widehat A)b_R(\widehat A)
 \,\widehat\nu(d\widehat A).} \tag{9}
\]
左边仍是原链全部实际到达和 rank 停止，原历史没有刷新为辅助父历史；右边是新 max-only 链的正上界。只在这个 rank 泛函的投影比较中丢弃其他标签。对依赖配置、旧来源关系或整个历史的其他费用，不能直接使用相同父闭合结论。

右边可用具体的父 Volterra 算子 \(K_0\) 研究，不再受实际成功 \(q_j\) 的配置记忆阻碍。它**不是**普通 stationarity 推出的收缩；闭合依赖输入父密度、max-only Palm lower 因子及自然 \(H\) 三点。若仅用(8)，仍回到 \(A_*KW\)；本稿没有支付右侧的根阶来源价。新可审目标是对完整实际(6)的 \(\sum_j\widehat\nu K_0^j b_R\) 给 \(\varepsilon X+C\sqrt n\operatorname{polylog}(n)W\)，而不再把一般配置依赖成功核当 fresh 链。

### raw 空样本与完整停止账

上放链的失败恰为两项互斥和
\[
 e_0=1-J_01=e_R+e_{\rm empty},\qquad
 e_{\rm empty}=1_{\{v_x(\widehat A)\ge K\}}1_{\{F=\varnothing\}}.
\]
其自然空样本费保端点为
\[
 \mathsf M e_{\rm empty}
 =T\int1_{\{U>K\}}(e^{-\kappa}-e^{-U/T})\,d\mu
 \le Te^{-\kappa}W. \tag{10}
\]
令 \(A_* =\sum_{j\ge0}\min(1,e^{\alpha L}2^{-j})\)，沿 R495 有
\(A_*\le3+4rSL/(T\log2)\)。由于上放链密度本身等于 \(\eta_j\)，
\[
 R_{\rm empty}^{0}:=\sum_j\int\eta_j e_{\rm empty}\,d\mathsf M
 \le A_*Te^{-\kappa}W. \tag{11}
\]
式(8)使其存活终端质量趋零，所以同一初始质量 \(R_\tau\) 严格分解为
\[
 R_\tau=R_{\rm rank}^{0}+R_{\rm empty}^{0},\qquad
 R_{\rm rank}^{0}:=\sum_j\int\eta_j b_R\,d\widehat\nu,
\]
\[
 \boxed{R_\tau-A_*Te^{-\kappa}W\le R_{\rm rank}^{0}\le R_\tau.} \tag{12}
\]
因此上放 rank 根价与当前 \(R_\tau\) 目标仅差这笔已显式支付的来源量，不能把父标量化称为吸收或新根阶付款。其作用是准确消去配置记忆及全部 raw 非 rank 失败：未来若采用此方向，真正必须估计的是保实际来源/中心/质量的(6)，而非再引用父递推形式本身。实际停止比较(9)只给上界；不声称实际与 raw 两条停止流相等。

在 R495 已冻结的实际参数下，这笔费用还有维数无关的明确常数。为区别算子，写 \(P_0^{\rm par}=rS\)、\(H_0=S/\tau\)，
\[
 C_g=512P_0^{\rm par}H_0+4P_0^{\rm par}+S,\qquad
 T_{\min}=4096P_0^{\rm par}H_0.
\]
R495 的 \(T^2\ge16P_0^{\rm par}C_g(L+1)/\varepsilon_g\) 及
\(\kappa=8\log[T/(256P_0^{\rm par}H_0)]\) 给
\[
 A_*\le3+8P_0^{\rm par}L/T
 \le3+\varepsilon_gT/(2C_g),\qquad
 e^{-\kappa}=(256P_0^{\rm par}H_0/T)^8.
\]
于是
\[
 A_*Te^{-\kappa}\le C_{\rm empty}:=
 (256P_0^{\rm par}H_0)^8
 \left[\frac3{T_{\min}^7}
       +\frac{\varepsilon_g}{2C_gT_{\min}^6}\right]. \tag{13}
\]
固定 \(r,S,\tau,\varepsilon_g\) 时 \(C_{\rm empty}\) 与维数、质量窗宽无关。故(11)确给 \(R_{\rm empty}^0\le C_{\rm empty}W\)，可以用于(12)；它只支付 raw 空样本，不支付几乎全部剩余的 raw rank 流。

## 5. 有界本机符号核验

代码核(7)的高/低/端点区间，以及来源加权自然 PPP 经交集留点/差集补点刷新后密度变成父均值。后者以有限捕获签名的联合 PGF 表达，未模拟实际中心场或全部历史。

```python
import sympy as s
from fractions import Fraction as F
checks=0
v=s.symbols('v',real=True)
for U,w,K,T in [(4,0,2,1),(4,1,2,1),(4,3,2,1),
                 (1,F(1,2),2,1),(2,1,2,1),(4,4,2,1)]:
    U,w,K,T=map(s.Rational,(U,w,K,T))
    lo=max(w,K)
    raw=s.integrate(s.exp(-(v-w)/T)/T,(v,lo,U)) if lo<U else s.Integer(0)
    formula=(s.exp(-max(K-w,0)/T)-s.exp(-(U-w)/T)) if U>=K else 0
    assert s.simplify(raw-formula)==0
    checks+=1
# Given input source i and new source j, output PPP PGF is exactly target PGF.
prob=[s.Rational(1,6),s.Rational(1,3),s.Rational(1,2)]
h=[s.Rational(0),s.Rational(2),s.Rational(3)]
cap=[[1,0,1],[0,1,1],[1,1,0]]
lam=[s.Rational(1,3),s.Rational(1,2),s.Rational(2,3)]
z=s.symbols('z0:3')
mean=sum(prob[i]*h[i] for i in range(3))
for j in range(3):
    out=0
    for i in range(3):
        exponent=sum(lam[k]*(cap[i][k]*cap[j][k]
                     +(1-cap[i][k])*cap[j][k])*(z[k]-1) for k in range(3))
        out+=prob[i]*h[i]*prob[j]*s.exp(exponent)
    target=prob[j]*mean*s.exp(sum(lam[k]*cap[j][k]*(z[k]-1) for k in range(3)))
    assert s.simplify(out-target)==0
    checks+=1
print(f'{checks} symbolic assertions PASS; max-column endpoints and source-PGF closure only.')
```

实际本机 stdout：`9 symbolic assertions PASS; max-column endpoints and source-PGF closure only.`。一般核论证不依赖有限模型。
