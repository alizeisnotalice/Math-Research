# R496 独立补证：raw parent 闭包与配置门正支配

单独复用原三例中的扩大例，93 状态。8980 项 Fraction 精确断言通过，计数含原例的 natural-reference/H/rank 势账及本次 domination/closure，不是 8980 个模型。原冻结 `/tmp/r496_numeric.py/.json/.md` 未改动。

主要结果：raw max-only toy 的有限 scalar parent kernel 与完整状态链逐代一致；加入一个明确人工配置删除门后，同 H 下实际到达密度逐点受 raw parent 密度支配，累计 rank 停止也受支配。不能把人工门伪装为原成功几何。

## 精确模型及新增门

完整来源仍是 0、2/5、1 的原子，质量 (3,1,8)。区间 C0=[−1/2,1/2]、C1=[1/4,5/4]、C2=[−1/4,5/4]，完整质量 (4,9,12)，有限父参考 ν_C=m_C，两个等权离散 mark。总 type 顺序为 (mass,mark,parent index)，type0、1 为 C0 的两个 mark。

有限 Bernoulli lower 配置每 type 至多一个点，p=1/8（T=4）。rank 权每 type=1/2，rank=lower-capture 权之和加当前 type 半权；门阈值 a=5/4。J0 为原 toy：先 rank-stop，非低 rank 配置空则 empty-stop，非空选最大 type 保全部 lower points。H 保父/mark，源刷新 π_B，共捕获 bit 复制、新捕获 bit 独立补 Bernoulli，其余删除。

新增唯一固定门：若 lower mask 同时含 type0 和 type1，则拒绝原本成功的 J0 行；否则保留原 J0。该人工门删去 18 个成功行，记 Jgate。不存在改变转移输出/免费重建配置，只是删除正子核。因此逐项 Jgate≤J0，使用同一 H，Pgate=Jgate H≤J0 H=P0。

本模型仍为有限原子、有限父/mark、Bernoulli 点过程，不是实际连续 PPP J，亦无原 lowGram、no-hit、high-h/history 成功门。数值仅核一般正支配接口的有限实例。

## scalar parent closure 的精确证书

以每个 parent/type 的原参考质量 ν_a=m_parent/2，定义有限 scalar 前向核

K_ab=ν_a^−1 Σ_(state i:type a) M_i Σ_(state j:type b)P0_ij。

JSON 给 6×6 有理 K。脚本不仅从一次输入计算平均，还对六个 parent/type 基底逐一验证：把自然参考限制于 type a 后，用完整 P0 推送，在 type b 的每个完整状态上所得密度恰为 ν_aK_ab/ν_b，与来源/config 无关。

所以 η0=1，η_(j+1)(b)=ν_b^−1Σ_aν_aη_j(a)K_ab 给 raw q_j 的精确 parent/type 密度。每代逐完整状态核 qraw_j(state)=η_j(type)。这种原始 max-only 闭包不是猜测或只比较总质量。

同一起始 M 下，正性给 qgate_j(state)≤η_j(type)。脚本每代每状态用 Fraction 核此比较，包含到达零后的边界，且完整自然参考的 MJ0≤M、MH=M、ZH=Q 已保留核验。

## 停止与 fresh 对比

所有链有限降 type，最终到达零，无尾误差。rank-stop 保原 e_R，刷新后的 b_R 保 mark；raw 和 gated 使用同一 rank 定义。

| 量 | 精确值 |
|---|---:|
| raw 累计 rank-stop | 69581/4608 |
| gated + retained-config H | 956668043/63700992 |
| gated + fresh-reset Q | 3483012060529/231928233984 |
| gated full−fresh | 989888263/2087354105856 |

gated retained-config 的累计 rank≤raw，逐代支配见 JSON 的 steps。实际父闭包 η 的各代六维有理向量也在 steps。

fresh 对比只把 H 换成相同父/mark下完整 source/config 重建 Q，仍用同 Jgate。所加门使这一次 full−fresh 为正，表明原 raw 闭包不自动传到配置筛选后的实际链。门在运行前固定，无参数选择或反例扫描。这一差异不是主证书；主证书是 gated 受 raw parent 链支配，从而有可能用 raw 闭包结算原链，但还需一般实际成功核的正支配证明。

## 复现、依赖与范围

`/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/r496_domination.py`

实际 Python 3.12.14，纯 Fraction。代码是原构造的受控静态复制，仅保扩大例，再加入上述唯一门及 scalar/domination 核验；无需 import 或执行被冻结的 numeric 文件，运行时无其依赖。来源静态复制 SHA256 为 `33c7ce95e9d16f5180159de841a4911f7b8c91b0747649a9a251fae2e4bab827`，也记在 JSON。

没有浮点、solver、Monte Carlo、Poisson multiplicity 截断或无限尾。输出写脚本自身目录。固定 stdout：

`PASS 8980 exact assertions;1 Bernoulli/configuration case;gated domination,scalar closure and cumulative rank`

白名单仅 `/tmp/r496_domination.py`、`/tmp/r496_domination.json`、`/tmp/r496_domination.md`。完成限定单实例后停止。
