from pathlib import Path
from fractions import Fraction as F
from itertools import combinations
import json,sys,platform,time
ROOT=Path(__file__).resolve().parent;start=time.perf_counter();checks=0

def ck(x):
 global checks
 assert x
 checks+=1

def submasks(eligible):
 for k in range(len(eligible)+1):
  for sub in combinations(eligible,k):yield sum(1<<t for t in sub)
def add(row,key,v):
 if v:row[key]=row.get(key,F(0))+v

def mix(rows,weights):
 out={}
 for idx,w in weights.items():
  for j,v in rows[idx].items():add(out,j,w*v)
 return out

def push(mass,rows):
 out=[F(0)]*len(rows)
 for i,w in enumerate(mass):
  for j,p in rows[i].items():out[j]+=w*p
 return out
cases=[('initial_two_unequal',[F(3),F(1),F(8)],2,F(4),F(3,4)),('pressure_two_equal_ties',[F(3),F(1),F(3)],2,F(2),F(3,4)),('expanded_three_unequal',[F(3),F(1),F(8)],3,F(4),F(5,4))]
records=[]
for name,mu,np,T,threshold in cases:
 xs=[F(0),F(2,5),F(1)];intervals=[(F(-1,2),F(1,2)),(F(1,4),F(5,4)),(F(-1,4),F(5,4))][:np]
 B=[]
 for l,u in intervals:
  ck(all(x!=l and x!=u for x in xs));B.append([int(l<x<u) for x in xs])
 masses=[sum(mu[x]*B[a][x] for x in range(3)) for a in range(np)]
 types=sorted([(masses[a],mark,a) for a in range(np) for mark in range(2)])
 nt=len(types);parents=[a for m,mark,a in types];marks=[mark for m,mark,a in types]
 p=F(1,2)/T;rho=F(1,2)
 eligible={(a,x):[t for t in range(a) if B[parents[t]][x]] for a in range(nt) for x in range(3) if B[parents[a]][x]}
 rank={(a,x):rho*len(eligible[a,x])+rho/2 for a,x in eligible}
 ck(max(rho*sum(B[a][x] for a in range(np))*2 for x in range(3))<=T)
 states=[]
 for a,x in eligible:
  for mask in submasks(eligible[a,x]):states.append((a,x,mask))
 idx={key:i for i,key in enumerate(states)};N=len(states)
 confprob={};M=[]
 for a,x,mask in states:
  k=mask.bit_count();prob=p**k*(1-p)**(len(eligible[a,x])-k);confprob[a,x,mask]=prob
  M.append(mu[x]*rho*prob)
 H=[];Z=[];Q=[];J=[]
 for a,x,mask in states:
  row={}
  oldset=set(eligible[a,x])
  for z in range(3):
   if not B[parents[a]][z]:continue
   newset=set(eligible[a,z]);fresh=sorted(newset-oldset)
   keep=mask & sum(1<<t for t in newset)
   for newmask in submasks(fresh):
    prob=p**newmask.bit_count()*(1-p)**(len(fresh)-newmask.bit_count())
    add(row,idx[a,z,keep|newmask],mu[z]/masses[parents[a]]*prob)
  ck(sum(row.values())==1);H.append(row)
  zrow={idx[a,x,mm]:confprob[a,x,mm] for mm in submasks(eligible[a,x])};Z.append(zrow)
  qrow={}
  for z in range(3):
   if not B[parents[a]][z]:continue
   for mm in submasks(eligible[a,z]):qrow[idx[a,z,mm]]=mu[z]/masses[parents[a]]*confprob[a,z,mm]
  ck(sum(qrow.values())==1);Q.append(qrow)
  if rank[a,x]<threshold or mask==0:J.append(None)
  else:
   child=mask.bit_length()-1;lower=mask & ((1<<child)-1)
   ck(child<a);ck(rank[child,x]<rank[a,x]);J.append(idx[child,x,lower])
 # Natural reference exact invariance/reversibility, subreference J, and ZH=Q.
 ck(push(M,H)==M);ck(push(M,Q)==M)
 for i,row in enumerate(H):
  for j,v in row.items():ck(M[i]*v==M[j]*H[j].get(i,F(0)))
 for i in range(N):ck(mix(H,Z[i])==Q[i])
 MJ=[F(0)]*N
 for i,j in enumerate(J):
  if j is not None:MJ[j]+=M[i]
 ck(all(MJ[i]<=M[i] for i in range(N)))
 eR=[int(rank[a,x]<threshold) for a,x,mask in states]
 bR={a:sum(mu[z]/masses[parents[a]]*int(rank[a,z]<threshold) for z in range(3) if B[parents[a]][z]) for a in range(nt)}
 for i,(a,x,mask) in enumerate(states):ck(sum(v*eR[j] for j,v in H[i].items())==bR[a])
 once=sum(M[i]*eR[i] for i in range(N));R=sum(M)
 computations=[]
 for law,refresh in [('retained_config_H',H),('fresh_reset_Q',Q)]:
  rows=[refresh[j] if j is not None else {} for j in J]
  col=push(M,rows);ck(all(col[i]<=M[i] for i in range(N)))
  arrival=M.copy();ranktotal=F(0);emptytotal=F(0);Jdown=F(0);Hdrift=F(0);crossup=F(0);crossdown=F(0);stop_pot=F(0);shift=F(0);history=[]
  initialpot=sum(M[i]*rank[a,x] for i,(a,x,mask) in enumerate(states))
  for gen in range(nt+1):
   if not any(arrival):break
   # In these max-only natural-start fixtures, arrivals stay parent/mark constant.
   for a in range(nt):ck(len(set(arrival[i]/M[i] for i,(aa,xx,mm) in enumerate(states) if aa==a))==1)
   postJ=[F(0)]*N
   for i,j in enumerate(J):
    if j is not None:postJ[j]+=arrival[i]
   for a,x in eligible:ck(len(set(postJ[i]/M[i] for i,(aa,xx,mm) in enumerate(states) if (aa,xx)==(a,x)))==1)
   nrank=sum(arrival[i]*eR[i] for i in range(N));nempty=sum(arrival[i] for i,j in enumerate(J) if j is None and not eR[i])
   nextm=push(arrival,rows);npot=sum(nextm[i]*rank[a,x] for i,(a,x,mask) in enumerate(states))
   pot=sum(arrival[i]*rank[a,x] for i,(a,x,mask) in enumerate(states));jd=hd=cu=cd=sp=sb=F(0)
   for i,(a,x,mask) in enumerate(states):
    wi=arrival[i];j=J[i]
    if j is None:sp+=wi*rank[a,x];continue
    b,z,mm=states[j];jd+=wi*(rank[a,x]-rank[b,z]);sb+=wi*bR[b]
    for h,prob in refresh[j].items():
     bb,zz,mh=states[h];ck(bb==b)
     hd+=wi*prob*(rank[bb,zz]-rank[b,z])
     if rank[b,z]<threshold<=rank[bb,zz]:cu+=wi*prob
     if rank[bb,zz]<threshold<=rank[b,z]:cd+=wi*prob
   ck(pot-npot==sp+jd-hd);ck(sum(arrival)-sum(nextm)==nrank+nempty)
   ck(sb==sum(nextm[i]*eR[i] for i in range(N)))
   ranktotal+=nrank;emptytotal+=nempty;Jdown+=jd;Hdrift+=hd;crossup+=cu;crossdown+=cd;stop_pot+=sp;shift+=sb
   history.append(dict(generation=gen,arrival_mass=str(sum(arrival)),rank_stop=str(nrank),empty_stop=str(nempty),J_rank_drop=str(jd),H_rank_drift=str(hd),H_low_to_high=str(cu),H_high_to_low=str(cd),rank_stop_next_via_bR=str(sb)))
   arrival=nextm
  ck(not any(arrival));ck(ranktotal+emptytotal==R);ck(ranktotal-once==shift);ck(initialpot==stop_pot+Jdown-Hdrift)
  computations.append(dict(law=law,cumulative_rank_stop=str(ranktotal),one_time_rank_stop=str(once),cumulative_over_once=str(ranktotal/once),empty_stop=str(emptytotal),total_stop=str(R),J_rank_drop=str(Jdown),H_rank_drift=str(Hdrift),H_low_to_high=str(crossup),H_high_to_low=str(crossdown),initial_rank_potential=str(initialpot),stopped_rank_potential=str(stop_pot),shifted_success_rank_via_bR=str(shift),generations=history))
 actual=computations[0];fresh=computations[1]
 records.append(dict(name=name,source_positions=list(map(str,xs)),mu=list(map(str,mu)),intervals=[[str(l),str(u)] for l,u in intervals],capture=B,mass=list(map(str,masses)),nu='nu_parent=actual captured mass; not Lebesgue receiver',types=[dict(index=i,parent=parents[i],mass=str(types[i][0]),mark=marks[i]) for i in range(nt)],tie_order='lexicographic(actual mass,mark,parent index); discrete marks only, each type has at most one Bernoulli point',T=str(T),Bernoulli_p=str(p),rank_threshold=str(threshold),states=N,reference_R=str(R),rank_by_type_source=[dict(type=a,source=x,rank=str(v)) for (a,x),v in rank.items()],bR_by_type=[str(bR[a]) for a in range(nt)],H_minus_Q_nonzero_rows=sum(H[i]!=Q[i] for i in range(N)),arrival_structure='Checked every generation: arrival density constant at fixed parent/mark; post-J density depends only on parent/mark/source, not lower configuration. This explains equality of full versus fresh in these max-only natural-start fixtures.',source_only_projection='Z averages configuration at fixed parent/mark/source; exact Z H=Q, where Q averages full natural source/config at fixed parent/mark',computations=computations,cumulative_rank_actual_minus_fresh=str(F(actual['cumulative_rank_stop'])-F(fresh['cumulative_rank_stop'])),qualifications='Actual interval incidence and full atomic masses; finite parent measure, Bernoulli not PPP, marks discrete; no original successful lowGram/cloud/high-h/history gates.'))
result=dict(scope='Exact finite Bernoulli configuration/rank diagnostic, NOT actual original continuous J or a PPP approximation certificate.',compute_index=dict(executable=sys.executable,python=platform.python_version(),command='"'+sys.executable+'" r496_numeric.py',seconds=time.perf_counter()-start),checks=checks,cases=3,records=records,formulas=dict(rank='v_x(type)=sum_lower capturing rho_type+rho_current/2, rho_type=1/2',J='rank<threshold stops; else empty stops; else max present type chosen and all strictly lower present types retained',H='parent/mark fixed; source resampled pi; shared bits copied,newly captured bits independent Bernoulli,other bits removed',source_projection='Z H=Q; does not imply H=Q on configuration-dependent functions',potential='initial rank potential = stopped rank potential + cumulative J drop - cumulative H drift',shift='cumulative rank stop - one-time rank stop = sum arrivals J bR'),decision='Finite states exactly test source-only averaging versus retaining lower configuration. No identity ZH=Q licenses replacing the full conditional H by fresh Q on all later arrival weights.',errors='All arithmetic Fraction; every type presence Boolean with a strict finite score. No multiplicity cutoff, Monte Carlo, infinite tail, matrix approximation or solver. Nilpotence follows strict decrease of parent type in J, at most2*num_parents transitions.')
(ROOT/'r496_numeric.json').write_text(json.dumps(result,indent=2)+'\n')
print('PASS',checks,'exact assertions;3 Bernoulli/configuration cases;ZH=Q,rank flux,potential and full/fresh comparison')
