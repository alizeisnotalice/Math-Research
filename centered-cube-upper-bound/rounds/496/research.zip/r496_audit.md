# R496 独立终审

FINAL PASS（限定范围）。在同候选域及同完整 lower 配置分析状态上，max-only 正上放、父与 mark 闭包、显式 K₀ 和 raw-empty 的维数无关来源价成立。原实际 rank 费受该新父核支配；该核几乎全部停止仍为 rank，根阶来源价未证，完整一般目标及原母账未闭合。

独立 PRE 先于读取本轮作者稿；最终已读白名单十二件。没有发现实质数学阻断，认证范围如下。

- **正核与标签。** 原成功记录取同一 raw 最大父、保全部 lower raw 配置，且先通过 rank/nonempty 门。仅在共同状态投影下 J≤J₀；同 H 给 P≤P₀ 及逐代 q_j≤η_j。不能据此给辅助父原成功历史，也不能将原 joint 标签律当作 fresh 律。若改 raw 域、改为筛后 F₀ 输出或改 H，此结论不自动成立。
- **Palm 与父闭包。** J₀* 对 parent+mark 密度给 source-only 密度，输出 lower PPP 的自然因子精确抵消；H=H* 再取 π_B 均值，故 η_j 仅依父及 mark。K₀ 的 ν_τ(dB)ds_B/(Tm_B)、π_A 来源、捕获和增广顺序均正确。首列为 [exp(−(K−w)₊/T)−exp(−(U−w)/T)]₊；U<K 及 U=K 零支保留，质量原子不能去掉 mark。分数质量列保证该上放链终端趋零。
- **完整 empty 账。** 自然一次空样本费≤Te^(−κ)W，累计≤(3+8rSL/T)Te^(−κ)W。用 R495 的 T²≥16rSC_g(L+1)/ε_g 与 T≥T_min，得到文中 C_empty 的 T_min^(−7)、T_min^(−6) 两项；固定 r,S,τ,ε_g 时确与 n、L 无关。精确停止为 R_τ=R_rank⁰+R_empty⁰。因此 rank 标量化和 empty 付款不是完整 R_τ 的根阶估计；原实际与 raw 停止流也没有被宣称相等。
- **其他精确账。** scalar_geometry 的同来源 head 项=(e^κ−1)E_empty，协方差符号为同父 Eh·EF−E(hF)，无已证正负；不能把小 empty 费直接代替放大后的祖先费。proof 的 crossing−rescue+refresh、有限终端及 binary 方差分解成立，联合信用保 q_j²e 而非 q_je。geometry 保真实后 rank 来源、冻结原 F₀ 与旧人工 x；交集子父 rank 继承正确，但恢复上下界及 lostflow 均没有给来源付款或免费列帽。

实际独立隔离重放使用指定 Python `-I`：geometry 36、proof 28、raw_dominance 9、scalar_geometry 10、numeric 8124、domination 8980，全部 stdout 与冻结 replay 一致，共17187项报告核验单位；包含复用矩阵检查，并非独立模型数。两份 JSON 仅去 compute_index.seconds 后逐字段一致，规范 SHA256 分别为：

- numeric：`b296ab8b0fe84e31f188a39856a2d9419e278100eaec36ce7b964871b825f0db`。
- domination：`5d3dbe7f000826ce95b2944c4a266a8efe17a3a86beb91ea7941f365818f866d`。

数值是完整原子来源、有限父/离散 mark 的 Bernoulli 接口，非连续 PPP、L¹ 来源/勒贝格接收场或原全部成功历史认证。预先固定配置门的实验只证明该有限例的支配/非 fresh 边界；不用于一般阶数外推。原一次 τX、R495 非 rank 收据、入口倍率及其他未付槽继续保留，不重复吸收。真正未付的是同一真实 cube 父核的完整 rank Green 来源价，或 R495 同实际 ρ_R 的全局共同来源割。

## 最终输入绑定

- `r496_main.md`: `2dbf7f7cf84734bf92eb0300ffc25f82964dfb6639d6830fb60b7ed8948e22b6`
- `r496_raw_dominance.md`: `3845a9b81f19b5cc5227003fbab64526f540cd11a33e784fcb314514a0d94640`
- `r496_scalar_geometry.md`: `0ea68648c9cfcd742ee6e9f78242dea4b4bffe637ad25f05e33367e31dcac80d`
- `r496_geometry.md`: `3e3a00420fc2043f115ab3e0bff81d4cec594b32865d2b5347b025521d7af212`
- `r496_proof.md`: `48447be5a0eea5f21246e0882ae0f24d265419897b64e3757cd30b52e60e957b`
- `r496_numeric.md`: `65c4b9355ae8741a2cb57e4f73fb08461f27447a35aff3cfc89556e6b6b332b1`
- `r496_numeric.py`: `33c7ce95e9d16f5180159de841a4911f7b8c91b0747649a9a251fae2e4bab827`
- `r496_numeric.json`: `5626479505dc3d47b9853c4ee4fb9f545dc5937ac5239fa33482288b79df9797`
- `r496_domination.md`: `733e42beeee51e7512736faf52df410557fd6fc4e398d0852173103cf2a7b66a`
- `r496_domination.py`: `315ffd15b6ca62b4a3f88af5c27430c43bdffe64b2131d731b9e38a1f1446283`
- `r496_domination.json`: `dd61b973b4f9b663064d7d851a7d576d0edc32da0e98da845c698aec18c61cdb`
- `r496_replay.json`: `706c7b2efb6a2e06e05bcdc620f58463b48ec39856d46377029677865227eca1`
