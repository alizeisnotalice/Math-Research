# R338 independent preauthor screen — center-near high-past G payment

Owned only /tmp/r338_audit.md, no Git/other-author edits. Derived without reading R338 author proof. The fixed contract is the R337 FULL hard scalar after the single positive nu<=f domination: beta=f, actual receiver du, m_u=q_uR_u^n=f(Q_u), q in[q_-,lambda], finite E, original full J/H/ell. The positive G residue, not the original masked nu traffic itself, has ordered m_u>K m_v and the original global strict past Z_y(m_u/K-)>h. Require finite K>lambda/q_- and h>0. Let alpha>0 be fixed before these integrations.

## Independent verdict: PASS

On the far-mass domain, every receiver in the GLOBAL strict mass past has R_v<R_u, because R_v^n/R_u^n<(lambda/q_-)/K<1. Whenever u appears at r>=R_u, ALL of that global past is therefore already in E_r. Consequently J_y(r)>=Z_y(m_u/K-)>h on the retained high-past source gate, so1/J<=1/h BEFORE dropping that gate. Without K>lambda/q_- (or a separate J>h gate), this step is not justified merely by large global mass past.

Let G_alpha restrict the small receiver CENTER v to Q_(alpha R_u)(u). After the inverse-clock bound and positive removal of H/past gates,

 integral f(y)cu(y)cv(y)dy=I_uv<=m_v,
 (m_u-m_v)I_uv<=m_u*m_v.

Thus integrating dmu(v)=dv/m_v cancels the small mass and leaves m_u/h times actual receiver-center volume. Prefix and mass restrictions may be dropped for this upper bound, and that volume is at most(alpha R_u)^n. Then dmu(u)=du/m_u cancels the large mass. Finally the ORIGINAL inclusive physical tail contributes R_u^(-n), giving

 G_alpha<=alpha^n|E|/h = [alpha^n/(lambda h)] X,   X=lambda|E|.

There is no factor1/2 in this ordered G expansion and no A_n, source-density bound, new cap or winner. This requires only the shared full-f cube mass I_uv<=m_v and real receiver dv. The condition is CENTER containment, not Q_v subset Q_u. At alpha1 it pays every small center in the large actual cube; alpha>1 gives the stated expanded center band. Physical radius atoms and a/b endpoints are included by the original inclusive tail, not split or discarded.

This is a genuine paid positive subdomain of the fixed R337 G_highpast residue, with its exact complementary center-outside subdomain retained. It does not claim an exact allocation of a previously masked source-nu traffic: the R337 positive full-slot domination remains the route. Arbitrary source-z/endpoint masks cannot be inserted through the reverse/favourable source-mass cancellation without that preceding domination or a separate compatible argument.

If alpha^n<=epsilon*lambda*h, its contribution is at mostepsilon X. To describe a band containing the original large cube, also require alpha>=1; the equality choice alpha=(epsilon lambda h)^(1/n) has that property exactly when epsilon lambda h>=1. For h=L sqrt(n)/q_- with fixed L, this is a root source-cost choice for the already paid low-past branch and a conditional dimension/parameter constraint on the expansion. If a symbol q in h=Lsqrt(n)/q is used, it must mean a fixed reference such as q_-, not silently the variable q(u) of a global threshold. The fee is stated against X=lambda|E|; it must NOT be changed to alpha^n X_q/(lambda h), because X_q<=lambda|E| has the opposite direction for that substitution. A safe X_q version would use q_- in that denominator.

All original entry/source/outer/M3 aggregation conditions remain. The center-outside small-mass positive G, general-soft traffic, historical time/suffix terms and overall absorption are not proved by this lemma. Choosing the local epsilon does not allocate it independently to every leaf for free.

## Actual bounded diagnostics and scope

Reviewer executed exact Fraction cancellation checks across physical dimensions/radii/q/expansion values and strict mass-to-radius ordering examples. They are scalar algebra diagnostics, not continuum BH computations, source fixtures or a general proof. The analytical proof above supplies the receipt. No full old pipeline was repeated.

Actual reviewer exact assertion count: 78. Await R338 final author/main/numeric/ledger for file comparison.


## Main X_q parameter choice and author auxiliary comparison

Read complete `/tmp/r338_main.md`, current `/tmp/r338_ledger.md`, frozen `/tmp/r338_aux.md` and641-check script. PASS. The sharper X_q conversion now correctly uses |E|<=X_q/q_-: h=(1+sqrt(n))/(epsilon q_-), alpha^n=1+sqrt(n) pays epsilon X_q for the center branch. The R337 near+twice-favourable joint payment supplies a separate epsilon X_q, while its low-global-past fee uses this SAME enlarged h. Their source sum is EXACTLY(lambda/q_-)[(2+3sqrt(n)+2exp(-sqrt(n)))/epsilon+1+sqrt(n)]W. The main K is exp(sqrt(n)), not e times sqrt(n). All source/endpoint-mask cancellation guards remain explicit.

The heterogeneous center-volume inequality in aux(1) correctly retains R_u^-n and actual center volume before any uniform bound. The y/r-independent gate requirement lets the true shared-source overlap Iuv be integrated BEFORE using dv; no arbitrary source-conditioned choice or private source was substituted. The isotropic center gate may extend beyond the permitted physical radius because it is only a CENTER region, not a new averaging cube/cap. Fixed per-u anisotropic choices use product volume once. The unrestricted union over at most k outside coordinates costs the exact binomial sum; it cannot be charged as one favourable axis. Positive capture in the outside complement implies R_v/R_u>alpha-1, but the physical octave already imposes R_v/R_u>=1/2, so an empty tiny-ratio domain is not a new paid result.

The aux actual-dx fixture uses full J=11/20, strict smaller-mass clock1/2>h, and the original terminal atom. For the stated positive source interval, inside/outside are both nonzero and sum to1/880. Rational polygon clipping, selected cube containment and coordinate union counts in its script agree with the stated scope. It is neither a full f-source integral nor the special all-dimensional root h choice, and no such claim is made. Parent will report its own actual replay; this reviewer did not repeat641 assertions.

The updated original entry adds4epsilon X_q, not2epsilon X_q. Reviewer executed two exact Fraction checks:4*(128/119)*(119/2048)=1/4 and1/4+1/256=65/256. This REPLACES R337's same absorption slot; it does not add another1/4. Same authenticated X/leaf/source/scale aggregation is still required and191/256 is not a proved budget for the remaining branches. Original8lambda H source fee, other entrance terms and outer coefficients stay. Main/ledger explicitly retain outside-center G, general-soft/other hard slots, broad-distance/lowpe/extreme-aspect complements, time/suffix atoms, and all scales/outer fees; no closure claim appears.

Current aux/main bindings:

- `/tmp/r338_aux.md`: `b432c2d74fcec8e3949746fceb5d179719a1e040aef75b376928392ad53202a8`
- `/tmp/r338_aux_checks.py`: `56c3c2b41bbb032c7f30baa8e26e2682f8c9748df510b7e320bd7bc741db3386`
- `/tmp/r338_main.md`: `69d779d69b422fe80e0ebfc92c9fe0eabe45bff783be6ce7eda8fdee9380a357`
- `/tmp/r338_ledger.md`: `38e2b6b22e0165cc27edf18af6defcc87747722589d81677e800175b346a6270`

Await final core/numeric scope if assigned. No additional root payment outside the proved center region is certified.


## Frozen auxiliary posterior-transport core comparison

Read COMPLETE `/tmp/r338_core.md` and2539-check script. PASS as an UPPER transport estimate only. The closed mass-band constant includes all atoms. At selected t, F(t)=Z(t/K-)+gamma([t/K,t]) and F(t-)>=Z(t/K-)>h imply the shifted Hardy bound. The integral of dgamma/F(t) is controlled by log(M/h) with the whole atom d/(a+d)<=integral_a^(a+d)ds/s, or directly by cumulative quantiles; no crossing rank is discarded. The zero-total case and mass atoms are correctly covered.

The same-source posterior P has row<=1. Its column calculation integrates actual du and produces a density bound relative to actual dv, NOT mu or qdu. Dropping the v mass predicate in that column bound is safe; matching f(Q_v)=m_v cancels the remaining small mass. This yields a legitimate upper L2 Schur bound, not a lower overlap, coverage probability, contraction gain or root price. Future-clock a_H retains original J/H/full ell; since all strict old masses are earlier in radius, a_H<=1 includes the terminal atom. The identity G_highpast=integral q_u P_H(u,E)du has the correct q/R/m factors, and P_H<=P, including any separately fixed center subgate.

Displayed L=(2+1/sqrt(n))log_+(A_n/sqrt(n)) is for the stated OLD special choice h=sqrt(n)/q_-. For the current enlarged main threshold one must use the general formula(6) (or a justified monotonic upper bound), not silently identify the two h values. This does not affect the main receipt, which does not use a Schur norm to pay G_out. The final column/row estimates also do not license independent posterior resampling or chronological telescoping.

Its2539 checks are MIXED, not all exact: direct inspection counts360 ordinary70-digit Decimal Hardy/column comparisons and2179 Fraction algebra assertions. The source/receiver incidences are finite algebra fields, not a proof of the real-dx mass envelope or a continuous receiver approximation. No repeat run was performed by this reviewer.

Core binding: `9b2d2d66880ea13224e8008fc950d37f6283c3757d4225d8133b5a34c914be4a`.
Core script binding: `a26eb59cab4e1ec80a3f5d50d3b375721d3026dfdfb14a243aa01290dcfdcb77`.

Await frozen numeric notes/final primary evidence attribution before final receipt.


## Frozen genuine receiver-dx numeric review

Read ALL final `/tmp/r338_numeric.py`, full frozen notes and result scope. PASS. Actual E shells have their true Lebesgue volumes, disjoint selected radii1+i/n in the physical octave, and all selected receiver cubes lie inside the compact uniform Q4 source; q is genuinely1. For every y in positive central Q_delta all receivers capture y, giving exact cumulative shell atoms. The central clock is also an upper bound for every other source position, so its empty cases are global emptiness certificates; positive cases yield an actual central-source lower bound, not a full-source value.

Strict K=e^sqrt(n) mass tests use positive rational Taylor lower/upper bounds with a valid geometric tail; the pointer checks certify strict boundaries without floating exponentials. The small-endpoint subtraction retains the actual cumulative m_v*dmu_v volume, rather than replacing G by its primitive. Reviewed common-integer denominator formulas agree with the exact h_i[m_i Zpast_i-T_i] future-clock expression and the independent prefix expression. The terminal ell tail and every selected physical atom remain. Five literal Fraction comparisons are performed at n<=36; all other dimensions retain the algebraically exact integer construction.

The notes use OLD337 h=sqrt(n)/q_- for the computed G. They separately scan NEW338 h at epsilon1 and1/2, but these are gate flags only. No center-inside/outside classification or integral is computed; nonzero total high-past G does NOT establish nonzero outside G or challenge the proved center payment. The illustrative H=h (or a declared representative root H below h) is enough to keep original high-J gates for the computed central rows; it is not a claim about every historical H. The central source volume delta^n, full W=4^n and X_q are retained, and the tiny global lower-bound/W ratios are honestly reported. There is no full-source G, extremal/root lower bound, full soft FIRST or complete history certificate.

The final script/report states2986 exact assertions, with descriptive floating log10 displays only. I have not repeated this pipeline. At this receipt stage the parent reports aux641 and core2539 actually rerun, but primary numeric was RUNNING and its completion must be recorded only after the process succeeds. The final proof does not depend on this numerical run. No uncompleted run is counted as completed evidence below until the parent's final ledger is received.

Frozen numeric bindings:

- `/tmp/r338_numeric.py`: `1c65c8eaa7c4202439173592aebcc72579428b1f2e9f974bcb817230c0a11e96`
- `/tmp/r338_numeric.md`: `a5d2790b4c66b3c6747598b4c4b46fccffa1b1c485f116490a5263c1fcf4e627`
- `/tmp/r338_numeric_result.json`: `9dd0b4c768e231f652adb3630bd20fed48050433043994df493e1452ca1978a2`


## Final primary replay and ledger-byte recheck

Parent has now reported numeric process78927 exited0 with2986 exact checks and final result SHA9dd0b4c768e231f652adb3630bd20fed48050433043994df493e1452ca1978a2 matching the frozen numeric file. I inspected the final ledger's appended actual-run segment, which distinguishes completed runs from the earlier running state. It reports aux641 exact, core2179 Fraction+360 ordinary70-digit Decimal, numeric2986 exact with stages364/711/1911. These scopes and counts agree with the reviewed scripts/results. The finite-incidence core log comparisons are not interval certificates; displayed floating log10/source lower-bound ratios do not decide gates.

Final main SHA69d779d69b422fe80e0ebfc92c9fe0eabe45bff783be6ce7eda8fdee9380a357 and ledger SHA0c401b6ac2b6a81682140b41e769778842921e07189c00ff46dd4c4ef00218cd were checked against actual bytes. The final ledger honestly keeps old337 nonempty central high-past examples distinct from new338 threshold flags and the uncomputed center-outside classification. It explicitly says the final absorption epsilon119/2048 is not simulated, central source concentration is tiny, and no G_out/root/history certificate follows. The auxiliary positive interval fixture and the operator upper bound are not promoted to a high-dimensional full-slot solution.

## Final bounded verdict

PASS for all reviewed final R338 main/aux/core statements, numerical-code/result scope and ledger integration. The center-near/expanded-band receipt is a genuine paid positive G subdomain, with safe X_q denominatorq_-, original clock atoms and common source preserved. The complete combined source coefficient and4epsilon X_q entrance contribution are correct. No outstanding substantive correction remains in the reviewed final files.

The remaining outside-center G and all listed general-soft, historical, scale and outer-source budgets remain UNPROVED at root size. The upper transport estimate supplies no coverage/absorption gain. This audit does not recertify all earlier historical coefficients or claim word-for-word review/compilation of later research.tex. No Git/other-author edits or full numerical rerun were performed by this reviewer. Earlier awaiting-author/running-state notes are historical and superseded by the present receipt. Reviewer78 initial exact scalar checks and2 exact budget checks are separate from all primary/author executions.

## Final SHA256 bindings

- `/tmp/r338_main.md`: `69d779d69b422fe80e0ebfc92c9fe0eabe45bff783be6ce7eda8fdee9380a357`
- `/tmp/r338_ledger.md`: `0c401b6ac2b6a81682140b41e769778842921e07189c00ff46dd4c4ef00218cd`
- `/tmp/r338_aux.md`: `b432c2d74fcec8e3949746fceb5d179719a1e040aef75b376928392ad53202a8`
- `/tmp/r338_aux_checks.py`: `56c3c2b41bbb032c7f30baa8e26e2682f8c9748df510b7e320bd7bc741db3386`
- `/tmp/r338_core.md`: `9b2d2d66880ea13224e8008fc950d37f6283c3757d4225d8133b5a34c914be4a`
- `/tmp/r338_core_checks.py`: `a26eb59cab4e1ec80a3f5d50d3b375721d3026dfdfb14a243aa01290dcfdcb77`
- `/tmp/r338_numeric.py`: `1c65c8eaa7c4202439173592aebcc72579428b1f2e9f974bcb817230c0a11e96`
- `/tmp/r338_numeric.md`: `a5d2790b4c66b3c6747598b4c4b46fccffa1b1c485f116490a5263c1fcf4e627`
- `/tmp/r338_numeric_result.json`: `9dd0b4c768e231f652adb3630bd20fed48050433043994df493e1452ca1978a2`
