from fractions import Fraction as F
from decimal import Decimal as D, getcontext
from random import Random
getcontext().prec=70
def dec(x): return D(x.numerator)/D(x.denominator)
checks=0; active=0; max_hardy_ratio=D(0)
for seed in range(24):
 rng=Random(seed); nr=8; ns=7; K=F(3,2); h=F(1,3); H=F(3,4)
 f=[F(rng.randint(1,9),7) for _ in range(ns)]
 mu=[F(rng.randint(1,6),7) for _ in range(nr)]
 c=[[int(y==0 or rng.randrange(2)) for y in range(ns)] for _ in range(nr)]
 m=[sum(f[y]*c[u][y] for y in range(ns)) for u in range(nr)]
 du=[m[u]*mu[u] for u in range(nr)]
 z=[[sum(mu[v]*c[v][y] for v in range(nr) if m[v]<m[u]/K) for y in range(ns)] for u in range(nr)]
 L=D(0)
 for y in range(ns):
  M=sum(mu[u]*c[u][y] for u in range(nr))
  candidates=set([m[u] for u in range(nr)]+[m[u]/K for u in range(nr)])
  B=max(sum(mu[u]*c[u][y] for u in range(nr) if s<=m[u]<=K*s) for s in candidates)
  hardy=sum(mu[u]*c[u][y]/z[u][y] for u in range(nr) if z[u][y]>h)
  bound=(1+dec(B/h))*max(D(0),dec(M/h).ln()) if M else D(0)
  assert dec(hardy)<=bound+D('1e-60'); checks+=1
  if bound: max_hardy_ratio=max(max_hardy_ratio,dec(hardy)/bound)
  L=max(L,bound)
  for u in range(nr):
   if z[u][y]>h:
    Ft=sum(mu[v]*c[v][y] for v in range(nr) if m[v]<=m[u])
    assert Ft<=z[u][y]+B; checks+=1
 vols=sorted(set(m)); ell=[1/vols[i]-1/vols[i+1] for i in range(len(vols)-1)]+[1/vols[-1]]
 J=[[sum(mu[u]*c[u][y] for u in range(nr) if m[u]<=r) for y in range(ns)] for r in vols]
 ah=[[z[u][y]*m[u]*sum(e/J[t][y] for t,(r,e) in enumerate(zip(vols,ell)) if r>=m[u] and J[t][y]>=H and J[t][y]>0) if z[u][y]>h else F(0) for y in range(ns)] for u in range(nr)]
 P=[[F(0)]*nr for _ in range(nr)]; PH=[[F(0)]*nr for _ in range(nr)]
 for u in range(nr):
  for y in range(ns):
   assert 0<=ah[u][y]<=1; checks+=1
  for v in range(nr):
   if m[v]>=m[u]/K: continue
   for y in range(ns):
    if z[u][y]<=h: continue
    val=f[y]*c[u][y]*c[v][y]/(m[u]*m[v]*z[u][y])
    P[u][v]+=val
    PH[u][v]+=val*ah[u][y]*(1-m[v]/m[u])
 for u in range(nr):
  row=sum(P[u][v]*du[v] for v in range(nr))
  exact=sum(f[y]*c[u][y]/m[u] for y in range(ns) if z[u][y]>h)
  assert row==exact and row<=1; checks+=1
  assert sum(PH[u][v]*du[v] for v in range(nr))<=row; checks+=1
  if row: active+=1
 for v in range(nr):
  col=sum(du[u]*P[u][v] for u in range(nr))
  assert dec(col)<=L+D('1e-60'); checks+=1
 flow=sum(du[u]*PH[u][v]*du[v] for u in range(nr) for v in range(nr))
 original=F(0)
 for t,(r,e) in enumerate(zip(vols,ell)):
  for u in range(nr):
   if m[u]>r: continue
   for v in range(nr):
    if m[v]>r or m[u]<=K*m[v]: continue
    for y in range(ns):
     if J[t][y]>=H and J[t][y]>0 and z[u][y]>h:
      original+=e*f[y]/J[t][y]*mu[u]*mu[v]*c[u][y]*c[v][y]*(m[u]-m[v])
 assert flow==original; checks+=1
print({'systems':24,'assertions':checks,'active_receiver_rows':active,'max_hardy_to_bound':str(max_hardy_ratio),'scope':'exact finite incidence/prefix algebra; Decimal logarithm checks at 70 digits, tolerance 1e-60; no real-dx or root inference'})
