from fractions import Fraction as F
from math import comb
import json

checks=0
def ck(x):
    global checks
    assert x
    checks+=1

def clip(poly, a,b,c):
    out=[]
    for p,q in zip(poly,poly[1:]+poly[:1]):
        fp=a*p[0]+b*p[1]-c; fq=a*q[0]+b*q[1]-c
        if fp<=0: out.append(p)
        if (fp<0 and fq>0) or (fp>0 and fq<0):
            t=fp/(fp-fq)
            out.append((p[0]+t*(q[0]-p[0]),p[1]+t*(q[1]-p[1])))
    return out

def area(poly):
    if not poly: return F(0)
    return abs(sum(p[0]*q[1]-q[0]*p[1] for p,q in zip(poly,poly[1:]+poly[:1])))/2

# Actual n=1 Lebesgue field: f=nu=1_[−4,4], E_big=[−1/20,1/20],
# R_big=2, E_small=[3/4,5/4], R_small=1. q=1 on all E.
# All receiver cubes capture every y in Y=[3/4,4/5]. Full J=11/20.
u0,u1=F(-1,20),F(1,20)
v0,v1=F(3,4),F(5,4)
y0,y1=F(3,4),F(4,5)
rect=[(u0,v0),(u1,v0),(u1,v1),(u0,v1)]
K=F(3,2); qminus=F(3,4); h=F(1,10)
J=(u1-u0)/2+(v1-v0)
Z=v1-v0
ck(J==F(11,20)); ck(Z==F(1,2)); ck(Z>h); ck(K>1/qminus)
for u in [u0,u1]:
    for y in [y0,y1]: ck(abs(u-y)<=1)
for v in [v0,v1]:
    for y in [y0,y1]: ck(abs(v-y)<=F(1,2))
for u,R in [(u0,2),(u1,2),(v0,1),(v1,1)]:
    ck(u-F(R,2)>=-4 and u+F(R,2)<=4)
ck(F(2)>K); ck(F(1)<F(2)/K)
# Pair can enter only at physical b=2. ell({2})=1/2; m_big-m_small=1.
coef=(y1-y0)*F(1,2)/J/F(2)
full=coef*area(rect)
ck(full==F(1,880))
actual=[]
for t in [F(1),F(11,10),F(6,5),F(5,4)]:
    inside_poly=clip(clip(rect,1,-1,t),-1,1,t)
    inside_area=area(inside_poly)
    outside_area=area(rect)-inside_area
    inside=coef*inside_area; outside=coef*outside_area
    ck(inside>0); ck(outside>0); ck(inside+outside==full)
    ck(inside_area<=2*t*(u1-u0))
    ck(inside<=t*((u1-u0)+(v1-v0))/h)
    actual.append(dict(t=str(t),G_Y_inside=str(inside),G_Y_outside=str(outside),G_Y_total=str(full)))
ck(actual[0]['G_Y_inside']=='1/1760')
ck(actual[0]['G_Y_outside']=='1/1760')

# Exact coordinate-region volumes. A union over arbitrary choices costs the
# binomial sum, whereas one frozen set of m outward axes costs (1+alpha)^m.
volume_checks=0
for n in [1,2,4,8,16,32]:
    for alpha in [F(1,4),F(1,2),F(3,4),F(9,10)]:
        for k in range(n+1):
            selected=(1+alpha)**k
            union=sum(F(comb(n,j))*alpha**j for j in range(k+1))
            ck(selected<=union)
            ck(union<=(1+alpha)**n)
            if k==1: ck(union==1+n*alpha)
            volume_checks+=1
        ck(sum(F(comb(n,j))*alpha**j for j in range(n+1))==(1+alpha)**n)

print(json.dumps(dict(status='PASS',assertions=checks,actual_dx_fixture=actual,coordinate_cases=volume_checks,
 scope='Exact actual positive-Y subtraffic and elementary volume algebra; not the full f-source integral or a root bound for the outside complement.'),indent=2))
