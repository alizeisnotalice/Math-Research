# R338 auxiliary: a paid band of actual receiver centers

## 1. Screen, scope, and exact statement

This note gives a new use of the high-past gate: a positive part of the remaining R337 mass-gap traffic is paid by actual receiver volume. It does not bound the entire high-past complement. In particular, high past alone has not been shown to force enough common-source repetition to settle the genuinely outer centers.

Use exactly the contract and notation of `/tmp/r337_main.md`: arbitrary nonnegative finite L1 source f, actual finite Lebesgue receiver set E, a≤R(u)≤b≤2a, q_u=R(u)^{-n}f(Q_u)∈[q_-,λ], q_-=3λ/4, m_u=q_u R(u)^n, dμ(u)=du/m_u, c_u=1_{Q_u}, full original prefixes J_y(r), and

    ell=b^{-n}δ_b+n r^{-n-1}dr on [a,b].

The inclusive tail is ell([R,b])=R^{-n}. Only b is an explicit ell atom; actual radius laws can also have atoms at a, b, or interior radii. The target G is the full matched f-slot already reached by the positive domination B_H(f,ν)≤B_H(f,f), ν≤f. No arbitrary source mask is transported through that domination or the matching identity below.

Let K>λ/q_- and h>0. Let D(u,v) be any measurable ordered receiver-pair gate, independent of y and r. Write G_D for the exact G_{K,>h} of R337 with this additional gate. Its complement is G_{D^c}, with all the same original factors and gates. Define the actual small-center volume

    V_D(u)=|{v∈E : m_v<m_u/K and D(u,v)}|.

Then

(1)  G_D ≤ (1/h)∫_E V_D(u)/R(u)^n du.

In particular, if V_D(u)≤L R(u)^n for almost every u, then

(2)  G_D≤L|E|/h≤ L X_q/(q_- h),   X_q=∫_E q_u du.

These bounds retain the original high-J threshold H, all physical scales, and the whole physical radius atoms. There is no new copy of source mass and no extra W-source fee for this part. The last denominator is q_-, not λ, when the receiver budget is X_q.

More generally, (1) itself is the heterogeneous volume receipt. If a union of proposed gates is used, its actual union volume enters V_D; one cannot add coverage from several gates while charging only one of their volumes.

## 2. Proof with the actual dx and the common source

For every strict small-mass receiver,

    m_v<m_u/K≤λ R(u)^n/K<q_- R(u)^n,

so R(v)<R(u). Consequently every receiver in the global strict past Z_y(m_u/K-) is already present whenever r≥R(u). On the high-past gate, therefore, J_y(r)>h. This predictability step is where K>λ/q_- is used; it is not a free property of arbitrary mass clocks.

Set I_uv=∫f(y)c_u(y)c_v(y)dy. Positive Tonelli, replacement 1/J≤1/h on the original gate, and then positive deletion of the other gates give

    G_D ≤ (1/h)∬ 1_{m_v<m_u/K} D(u,v)
              (m_u-m_v)/(m_u m_v) I_uv R(u)^{-n} du dv.

The physical tail is R(u)^{-n} because R(v)<R(u). The actual common source gives I_uv≤f(Q_v)=m_v. Thus the last display is at most

    (1/h)∫_E R(u)^{-n}∫_E 1_{m_v<m_u/K}D(u,v)dv du,

which proves (1). Notice the two distinct operations: 1/J is controlled before deleting the high-past gate, and the common f overlap is integrated before applying the receiver-volume bound. Neither a source density cap nor a fixed convolution replacement is used. The bound applies to arbitrary measurable E and radius selectors; m_u≥q_-a^n keeps all denominators legitimate. Zero-J rows contribute zero by the original convention.

The equality

(3)  G_{K,>h}=G_D+G_{D^c}

is a positive partition of the original mass-gap integral. The latter term has not been priced here.

## 3. Largest isotropic band certified by this volume argument

For any measurable t(u)≥1, take

    D(u,v):  ||v-u||∞≤t(u)R(u)/2.

Then V_D(u)≤t(u)^n R(u)^n. At fixed h and target εX_q, the volume argument certifies every t with t^n≤εq_-h. Thus its largest certified isotropic dilation is

(4)  t=(εq_-h)^{1/n}, provided εq_-h≥1.

This is a statement about this sufficient volume calculation, not an optimality theorem for the actual traffic.

The all-dimensional choice

(5)  h=(1+√n)/(εq_-),   t=(1+√n)^{1/n}

gives G_D≤εX_q. This is a center gate only: the side tR(u) is not a new averaging radius, so it need not be an allowed physical radius, and no inflated-radius cap is required. In particular it also covers receiver cubes with R(u)=b.

Combining (3)–(5) with the already proved R337 estimate, using its same ε in the near/favorable payment and K=exp(√n), gives the directly insertable bound

(6)  B_H(f,ν) ≤ G_{D^c}+2εX_q
        +(λ/q_-)[(2+3√n+2exp(-√n))/ε+1+√n] W,

where W=∫f and G_{D^c} retains exactly K, h, full J, ell, and the strict mass ratio. Formula (6) is a paid root-order source budget plus an explicit genuinely outer-center complement; it is not a root bound for the full slot. The reverse-mass domain itself can be empty at some low-dimensional parameter choices: because b/a≤2, m_u/m_v≤(λ/q_-)2^n. Empty ratio domains are not counted as geometric progress.

## 4. Anisotropic outward directions and the real union cost

Instead of (4), let t_i(u)≥1 be measurable and impose

    |v_i-u_i|≤t_i(u)R(u)/2 for every coordinate i,
    ∏_i t_i(u)≤L.

Equation (2) still gives L|E|/h. The axes and widths may be chosen once for each u from the actual field; the single resulting gate must remain independent of y. They cannot be optimized separately for each source y and then all charged as one box.

There is a useful exact description of possible outward centers. A positive common-capture contribution requires |v_i-u_i|≤(R(u)+R(v))/2. On the strict mass-ratio domain,

    R(v)/R(u)<α_K:=(λ/(Kq_-))^{1/n}<1.

Hence only the center box with normalized side 1+α_K can contribute. Choosing one fixed set of m outward coordinates for each u, allowing their full possible outward range, and requiring the remaining center coordinates to stay inside Q_u costs at most

(7)  L=(1+α_K)^m.

For the choice (5), every m with (1+α_K)^m≤1+√n is therefore paid by εX_q. This is an alternative, anisotropic center region, not a free union with the isotropic band.

In contrast, allowing the outside coordinates to be any set of at most k coordinates has exact containing-box union volume

(8)  R(u)^n Σ_{j=0}^k binom(n,j) α_K^j.

Already k=1 costs 1+nα_K. In the nonempty octave ratio regime α_K≥a/b≥1/2 is necessary for there to be any small receiver, so this unrestricted one-face union is generally order n, not order √n. This explains why free selection of favorable coordinate directions would invalidate the root budget. The actual intersection with E and the mass gate may be smaller, but that must be proved or directly retained in (1).

## 5. Exact low-dimensional actual-dx split check

`/tmp/r338_aux_checks.py` is self-contained and uses Python Fraction arithmetic. The actual one-dimensional field is

    f=ν=1_{[-4,4]}, λ=1, q_-=3/4,
    E_big=[-1/20,1/20], R_big=2,
    E_small=[3/4,5/4], R_small=1,
    K=3/2, h=1/10, H≤11/20.

All selected cubes lie in [-4,4], so their actual q is exactly 1. For every source y in the positive interval Y=[3/4,4/5], every receiver captures y. The full original terminal prefix is J=11/20; the strict small-mass past for the big endpoint is Z=1/2>h. The reverse pair can enter only at physical b=2, so its scale payment is exactly the b atom 1/2. The exact G contribution restricted only to this actual positive source interval is 1/880.

The script integrates the actual Lebesgue (u,v) rectangle by rational polygon clipping. For the center side multipliers t below it obtains:

| t | center-band G on Y | outer-center G on Y |
|---|---:|---:|
| 1 | 1/1760 | 1/1760 |
| 11/10 | 7/8800 | 3/8800 |
| 6/5 | 9/8800 | 1/8800 |
| 5/4 | 39/35200 | 1/35200 |

Both pieces are strictly positive in every listed case, and their sum is exactly 1/880. This tests the actual dx split, full J, strict mass gate, and the terminal scale atom; it is not an evaluation of the full outer f-source integral or an extremal example. In particular the fixture uses general K,h, not the special root-budget choice (5).

The script also checks the anisotropic and union volume algebra exactly for n=1,2,4,8,16,32. One fresh run passed 641 assertions, including 276 coordinate-volume cases. These checks support the finite calculations; the measure-theoretic proof is Sections 1–2.

## 6. What is and is not settled

This receipt changes the R337 unpaid region: the original cube of small-receiver centers, a thin isotropic outward band of normalized volume 1+√n, or an explicitly budgeted anisotropic alternative is now paid by εX_q, with no extra source mass fee. Its new mechanism is actual receiver dx volume plus the common-source identity I_uv≤m_v, after using the high-past lower bound on the original J. It is distinct from R337's low-past quantile receipt and from R302's product-of-source-masses pair envelope.

The remaining G_{D^c} is the same original positive high-past traffic with its centers genuinely outside the chosen region. No proof here controls the spatial union of those outer centers at root cost, nor proves that their actual source-conditioned coverage has enough redundancy. That is the precise missing geometric step. No source density, hard winner, component FIRST, or general endpoint weak-convolution principle has been added.
