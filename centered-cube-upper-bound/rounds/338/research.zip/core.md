# R338 — a logarithmic real-dx column bound for the genuine old-source transport

**Status.** This is an auxiliary upper estimate, not a payment of G_{K,>h}. The genuine same-source posterior transport to older small-mass receivers has row mass at most one and column density at most O(log n) against REAL RECEIVER LEBESGUE MEASURE dv. The original gated residual is exactly the outgoing mass of a subkernel that retains its full future inverse clock. The column upper bound supplies neither coverage nor a positive absorption gain. No general root receipt for the remaining exterior-center traffic is proved here; the main round's center-inside/expanded-band receipt is separate.

## 1. Original quantities and two real-dx capacities

Use the R337 contract: f≥0 in L¹, actual finite E, a≤R≤b≤2a,
`m_u=∫_{Q_u}f=q_uR(u)^n`, `q_-≤q_u≤λ`, `q_-=3λ/4`, and
`dμ(u)=1_E(u)du/m_u`. Preserve c_u(y), every original prefix E_r and J_y(r), and `ell=b^{-n}δ_b+nr^{-n-1}dr`. The posterior

\[
 p_u(dy)=f(y)c_u(y)dy/m_u                                  \tag{1}
\]

is the ACTUAL common-source probability measure. No independent copy is substituted for it.

For fixed y let γ_y be the pushforward of c_u(y)dμ(u) under u↦m_u, and write

\[
 F_y(t)=\gamma_y((0,t]),\quad Z_y(t-)=\gamma_y((0,t)),\quad
 M_y=\gamma_y((0,\infty))=J_y(b).
\]

The real-dx envelopes proved in R336–R337 give, including closed-band atoms,

\[
 \gamma_y([s,Ks])\le B_K:=\frac{1+\log K}{q_-},\qquad
 M_y\le M_*:=\frac{A_n}{q_-},\quad A_n=1+n\log(b/a).          \tag{2}
\]

For clarity, the band proof bounds the capturing receiver density by
`min{1/s,1/[q_-(2‖u−y‖∞)^n]}` on `(2‖u−y‖∞)^n≤Ks/q_-`. Its integral is `(1+log K)/q_-`. The full radius envelope integrates to A_n/q_-. These are bounds on receiver du, not on source f-density.

Fix K>λ/q_- and h>0. Define the strict old occupancy

\[
 z_u(y)=Z_y(m_u/K-).
\]

Every receiver counted here has R(v)<R(u), because
`R(v)^n/R(u)^n=(m_v/m_u)(q_u/q_v)<λ/(Kq_-)<1`.

## 2. A shifted Hardy estimate with every mass atom retained

The following estimate holds pointwise in y:

\[
 \boxed{\Lambda_y:=\int
       \frac{1_{Z_y(t/K-)>h}}{Z_y(t/K-)}d\gamma_y(t)
 \le\left(1+\frac{B_K}{h}\right)\log_+(M_y/h).}             \tag{3}
\]

Here log_+(x)=max{0,log x}; the zero-total case gives zero. There is no division by zero on the selected set.

**Proof.** At a selected t, the exact partition into strict old past and a closed band gives

\[
 F_y(t)=Z_y(t/K-)+\gamma_y([t/K,t])
       \le Z_y(t/K-)+B_K
       \le(1+B_K/h)Z_y(t/K-).                               \tag{4}
\]

Furthermore `F_y(t−)≥Z_y(t/K−)>h`, since K≥1. Thus

\[
 \Lambda_y\le(1+B_K/h)
      \int_{F_y(t-)>h}\frac{d\gamma_y(t)}{F_y(t)}
 \le(1+B_K/h)\int_h^{M_y}\frac{ds}{s}.                     \tag{5}
\]

The final inequality explicitly includes all atoms. For an atom of mass d at t with a=F_y(t−)>h, its contribution is `d/(a+d)≤∫_a^{a+d}ds/s`; for the nonatomic part the usual cumulative-mass substitution gives ds/s. A completely unified justification uses the increasing quantile Q(s) of γ_y: Lebesgue measure on (0,M_y) pushes forward to γ_y, and `F_y(Q(s)−)≤s≤F_y(Q(s))` almost everywhere. On the selected set s>h, while `1/F_y(Q(s))≤1/s`. This proves (5) without enumerating atoms or splitting a crossing atom. When M_y≤h the selected set is empty. Equations (4)–(5) prove (3).

Set the uniform finite constant

\[
 L=\left(1+\frac{B_K}{h}\right)\log_+(M_*/h).               \tag{6}
\]

For the specified K=exp(√n), h=√n/q_-,

\[
 L=\left(2+\frac1{\sqrt n}\right)
       \log_+\!\left(\frac{A_n}{\sqrt n}\right)=O(\log(n+2)). \tag{7}
\]

This is an explicit upper bound, not an inferred lower bound on any overlap.

## 3. The same-source transport and its exact measures

Define the nonnegative measurable kernel on actual receivers by

\[
 P(u,dv)=\int p_u(dy)1_{z_u(y)>h}
       \frac{c_v(y)1_{m_v<m_u/K}}{z_u(y)}\,d\mu(v).          \tag{8}
\]

Each source y in this formula is the same source throughout that transition. Its row mass is exactly

\[
 P(u,E)=\int p_u(dy)1_{z_u(y)>h}\le1.                       \tag{9}
\]

Writing P(u,dv)=p(u,v)dv, the density is

\[
 p(u,v)=\frac1{m_um_v}\int f(y)c_u(y)c_v(y)
      \frac{1_{m_v<m_u/K}1_{z_u(y)>h}}{z_u(y)}dy.
\]

Positive Fubini, (3), and the matched mass of Q_v imply

\[
 \begin{aligned}
 \int_Ep(u,v)du
 &\le\frac1{m_v}\int f(y)c_v(y)\Lambda_y\,dy\\
 &\le\frac L{m_v}\int f(y)c_v(y)dy=L.
 \end{aligned}                                             \tag{10}
\]

The column measure in (10) is **dv**, with input integrated against **du**. It is neither μ nor qdu. In particular for every measurable receiver subset A,
`∫_E P(u,A)du≤L|A|`. No f-mass is bounded by the Lebesgue size of A.

As a legitimate consequence of the row and column upper bounds, the operator
`(Pb)(u)=∫b(v)P(u,dv)` satisfies

\[
 \|P\|_{L^2(E,du)\to L^2(E,du)}\le\sqrt L.                 \tag{11}
\]

Indeed Cauchy against the row measure gives `|Pb(u)|²≤∫|b(v)|²P(u,dv)`, and (10) finishes the estimate. This is exclusively an upper operator norm.

## 4. Retaining the ORIGINAL future inverse clock

On z_u(y)>h define

\[
 a_H(u,y)=z_u(y)R(u)^n
      \int_{[R(u),b]}\ell(dr)\frac{1_{J_y(r)\ge H}}{J_y(r)}.
                                                                    \tag{12}
\]

Every old receiver in z_u(y) is present in every r in this integral, so J_y(r)≥z_u(y)>0. The exact inclusive ell tail therefore proves `0≤a_H≤1`, including all physical receiver atoms and the b atom.

Define a subkernel of P by inserting the further factor

\[
 a_H(u,y)(1-m_v/m_u)
\]

inside (8), and call it P_H. This factor lies in [0,1] on its support, so P_H≤P. Both (9) and (10), with their exact measures, continue to hold for P_H.

Most importantly, direct positive Fubini yields the exact identity for the ORIGINAL remaining quantity:

\[
 \boxed{G_{K,>h}=\int_E q_u P_H(u,E)du.}                    \tag{13}
\]

To check all factors, `q_u p_u(dy)R(u)^n=f(y)c_u(y)dy`, because m_u=q_uR(u)^n. The z_u denominator in (8) cancels the z_u in (12). What remains is the original factor `(m_u−m_v)dμ(u)dμ(v)`, the original strict-past gate, and the original integral of `1_{J≥H}/J` over r≥R(u). The other receiver already lies in every such prefix. Thus no future clock is reset and no time/scale remainder is dropped.

## 5. Why this does not yet pay the target

Equation (13) and the row bound give only G_{K,>h}≤X_q. The logarithmic column bound gives a useful estimate for receiver test functions, but it does not force P_H(u,E) to be smaller than a chosen absorption constant, nor does it bound the q-weighted mass of active starting receivers by √n W. Applying the upper Schur bound as if it provided such a lower coverage or contraction gain would be invalid.

The strict mass decrease also does not supply flow conservation across successive transitions: each new receiver has its own true posterior, and composing transitions changes the source distribution. The single-transition proof does not permit freezing or independently resampling that source while preserving the original integral. Therefore no telescoping source-mass receipt follows merely from mass ordering or (11).

The concrete missing estimate remains an actual joint bound on the q-weighted outgoing P_H mass, using the correlated old source occupancy and future inverse clock, beyond the row/column upper bounds. The main round's geometrically paid center-inside/expanded-band component can be removed from P_H by its actual receiver-pair gate; its complement still has the estimates above but no root payment from this argument. This note does not count a norm bound or that restatement of the missing estimate as a new budget. No entrance or outer-scale fee is deleted or absorbed here.

Local verification actually run: `/tmp/r338_core_checks.py` tested 24 finite-incidence common-source systems with their full nested prefixes. Its 2,539 assertions checked the closed-band cumulative bound at selected atoms, the shifted Hardy estimate, row normalization, the REAL-du column formula, 0≤a_H≤1, subkernel domination and the exact original-residual identity (13). There were 131 active receiver rows. Algebraic identities used exact Fraction arithmetic; logarithmic inequalities used Decimal at 70 digits and tolerance 10^-60. All passed. The largest sampled Hardy/bound ratio was approximately 0.40084; it is only a diagnostic, not an asserted improved constant. These finite-incidence checks do not establish the real-dx envelope or a root bound; those parts rely on the analytic statements explicitly proved above.

Only `/tmp/r338_core.md` and `/tmp/r338_core_checks.py` are authored. No Git or other agent's file is changed. Bounded delivery ends here.
