# R338 — genuine high mass-past receiver-dx branch

Run `r338_numeric.py` with the bundled Python. Standard library only; script-relative paths, no old data or solver required. Seven perfect-square dimensions are tested in three bounded stages: n4/9/16 (empty), n25/36 (onset), n64/100 (expanded). The result is small and deterministic; very long exact fractions are represented by an explicitly encoded numerator/denominator digest plus a descriptive decimal. All branch and identity checks use full rational values before compression.

## Actual positive-L1 source and receiver dx

Let n=k², a=λ=1,b=2,q_-=3/4, δ=1/(4n), and f=β=ν=1_Q4. Physical cube parameters are SIDE lengths r_i=1+i/n. E0=Q_(r0−δ), Ei=Q_(ri−δ) minus Q_(r_(i−1)−δ), with actual R=L=r_i,s=0,α=1 on each shell. These are positive-Lebesgue receiver sets with their true volumes, not quadrature weights.

For every receiver u∈Ei, its whole Q_ri(u) lies in Q4, since (r_i−δ)/2+r_i/2<2. Hence actual q=1, FIRST density1_E and actual selected hard response1≤4λ hold throughout E. For every source y∈Qδ, every receiver captures y because (r_i−δ)/2+δ/2=r_i/2. These central source rows have identical actual occupation atoms

h_i=|Ei|/m_i, m_i=r_i^n,
J_i=Σ_(j≤i)h_j.

The source subset is positive volumeδ^n, but the FULL source mass remains W=4^n. No original winner/lowpe/full-history qualification is asserted.

## Exact strict past and global emptiness test

Use the original337 parameters K=exp(√n)=e^k and h=√n/q_-=4k/3. Positive Taylor sums through order160 plus a rational geometric tail enclose e^k. Every strict comparison m_j<m_i/K is certified against these bounds; no floating exp decides a gate.

For central y, let p_i be the last eligible small endpoint. Then the GLOBAL strict past is exactly

Zpast_i=Σ_(j≤p_i)h_j,
T_i=Σ_(j≤p_i)h_j m_j=(r_(p_i)−δ)^n.

Every p_i<i, so all strict mass-past receivers are also physical past. For ANY source y, Z_y(m_i/K−)≤Zpast_i because each receiver indicator is at most1. Thus max_i Zpast_i≤h is a GLOBAL emptiness certificate, not a failure to find source samples. Conversely Zpast_i>h gives a genuine positive-volume central-source branch, with positive-volume large and small receiver sets.

Because this past is already inside the prefix, retained endpoints satisfy J_i>Zpast_i>h. Therefore the computed high-past contribution also satisfies source high-J gate H=h, and any H≤h. In particular the separately declared λ=d=1 representative root H²=(1+n log2)/4 is below h², checked by rational log bounds. This does not reconstruct complete original history.

## Original physical inverse clock and true mass-gap correction

The ell tail includes b's atom: ell_i=r_i^(−n)−r_(i+1)^(−n), ell_n=2^(−n). Define the requested actual inverse clock

Zfuture_i=m_i Σ_(l≥i)ell_l/J_l.

The exact row contribution is

Gcentral=Σ_(Zpast_i>h) h_i [Zpast_i−T_i/m_i] Zfuture_i.

It is independently checked against the prefix expression

Σ_l ell_l/J_l Σ_(i≤l,Zpast_i>h) h_i [m_i Zpast_i−T_i].

The small endpoint mass T_i is RETAINED. The script separately reports the primitive clock sum and its exact subtraction, rather than substituting a first-moment primitive for the original gap. Exact checks give Zfuture_i≤1/J_i and Zpast_i Zfuture_i≤1. At n≤36 the common-integer computation is additionally compared with a direct literal Fraction prefix sum.

An integer common denominator is used for inverse-clock suffix sums to avoid repeated huge rational reductions. This is algebraically exact, not floating approximation. Source lower boundδ^n Gcentral is an actual contribution to full G. The full-source integral G is not evaluated; the central subset is not substituted for all f.

## Actual results

|n|max global strict past attained centrally|old337 h|first retained large side|central G|Ghigh/Gall, central|
|---|---:|---:|---:|---:|---:|
|4|.772476|2.666667|none|0|0|
|9|2.202858|4|none|0|0|
|16|4.432066|5.333333|none|0|0|
|25|7.481108|6.666667|47/25|.940721|.2358|
|36|11.355312|8|31/18|2.760081|.4211|
|64|21.586056|10.666667|49/32|8.594203|.6165|
|100|35.130697|13.333333|141/100|17.761145|.7284|

Thus this is an actual receiver-dx realization of the old nonzero high-past branch, not inflated discrete receiver weights. The maximum oldpast×inverse-clock product is approximately.676,.726,.792,.833 at n25/36/64/100, so the tested clock product is not uniformly tiny. The subtracted small-mass fraction of the primitive is approximately6.113e−4,1.664e−4,1.349e−5,1.237e−6. Those small corrections were still exactly included.

The full-source lower bound divided by W has descriptive base10 logarithm approximately−65.08,−98.93,−191.72,−319.16 at n25/36/64/100. This very small source concentration cost is crucial. A growing central row value is not a large global extremal fee or a dimension-rate lower bound. The full Xq=(2−δ)^n and W=4^n are retained in JSON.

## New338 threshold scans and center scope

Also test h338=(1+√n)/(εq_-) for ε1 and1/2, without changing the source or receiver field:

|n|old337 h branch|new h338, ε1|new h338, ε1/2|
|---|---|---|---|
|4,9,16|globally empty|globally empty|globally empty|
|25|central nonempty|globally empty|globally empty|
|36,64|central nonempty|central nonempty|globally empty|
|100|central nonempty|central nonempty|central nonempty|

These flags follow exact past-mass comparisons, not approximate G evaluation. Smaller absorption ε can make every tested configuration empty and would require larger dimensions to test nonemptiness; no giant-dimension extension is undertaken.

The new theorem's center gate ||v−u||∞≤αR_u/2, α^n=1+√n, is NOT classified or integrated here. The computed Ghigh includes BOTH inside-center and outside-center pairs. Nonemptiness of total high-past G therefore does NOT establish nonemptiness or cost of Goutside, and cannot dispute the new paid center branch. The next substantive question is the real source concentration/overlap cost of the remaining geometric component.

## Replay record

Two standalone actual runs of the exact computation are recorded; the final version additionally includes five independent literal-Fraction comparisons at n≤36. The final fresh run passes2,986 exact assertions:364 empty-stage,711 onset-stage,1,911 expanded-stage. The earlier complete run had2,981 before those five independent comparisons were added; all displayed values agree. Floating log10 values are descriptive only; every nonempty flag and exact G identity is rationally certified. No numerical quadrature, floating gate, arbitrary receiver mass scaling, general root theorem or original-history certificate is asserted. Code, this note and result JSON form the complete portable replay set; only this round's three files are edited.
