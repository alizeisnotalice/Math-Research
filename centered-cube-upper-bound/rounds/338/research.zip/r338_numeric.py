#!/usr/bin/env python3
"""Genuine dx high-mass-past branch in uniform many-radius receiver shells."""
from fractions import Fraction as F
from pathlib import Path
from collections import Counter
from math import factorial,log10,lcm
import hashlib,json
BASE=Path(__file__).resolve().parent
C=Counter()
def ck(k,v):C[k]+=1;assert v,k
def expbounds(k):
 lo=sum((F(k**j,factorial(j)) for j in range(161)),F(0));tail=F(k**161,factorial(161));return lo,lo+tail/(1-F(k,162))
def ln2bounds():
 t=F(1,3);lo=2*sum((t**(2*j+1)/F(2*j+1) for j in range(40)),F(0));return lo,lo+2*t**81/(81*(1-t*t))
def brief(x):
 a=abs(x.numerator)
 if max(a.bit_length(),x.denominator.bit_length())<1400:return str(x)
 raw=(str(x<0)+':'+str(a.bit_length())+':').encode()+a.to_bytes((a.bit_length()+7)//8,'big')+b'/'+x.denominator.to_bytes((x.denominator.bit_length()+7)//8,'big')
 return dict(decimal=float(x),sha256=hashlib.sha256(raw).hexdigest(),encoding='negative:numerator_bitlength:unsigned_numerator_bytes/unsigned_denominator_bytes')
def case(k):
 n=k*k;delta=F(1,4*n);rs=[1+F(j,n) for j in range(n+1)];mi=[r**n for r in rs];side=[r-delta for r in rs];vol=[s**n-(side[j-1]**n if j else 0) for j,s in enumerate(side)];weight=[v/m for v,m in zip(vol,mi)];J=[];acc=F(0)
 for j in range(n+1):
  acc+=weight[j];J.append(acc)
  ck('true_receiver_source_containment',side[j]/2+rs[j]/2<2 and side[j]/2+delta/2==rs[j]/2)
  ck('actual_shell_dx_and_atom',0<weight[j]<=1 and sum(vol[:j+1])==side[j]**n)
 Klo,Khi=expbounds(k);h=F(4*k,3);ck('strict_K_large_enough',Klo>F(4,3));past=[];smallmass=[];ptr=-1;smallindices=[]
 for i in range(n+1):
  while ptr+1<=n and mi[i]>Khi*mi[ptr+1]:ptr+=1
  ck('strict_mass_boundary_certified',ptr==n or mi[i]<=Klo*mi[ptr+1])
  ck('strict_mass_past_is_physical_past',ptr<i)
  z=J[ptr] if ptr>=0 else F(0);t=side[ptr]**n if ptr>=0 else F(0);past.append(z);smallmass.append(t);smallindices.append(ptr)
  ck('smallmass_exact_not_primitive',t==sum(vol[:ptr+1]))
  ck('oldpast_below_current_J',z<=J[i])
  if ptr>=0:ck('smallmass_correction_K_bound',Klo*t<=mi[i]*z)
 ell=[mi[j]**-1-(mi[j+1]**-1 if j<n else 0) for j in range(n+1)]
 ck('physical_ell_terminal_tail',all(sum(ell[i:])==1/mi[i] for i in range(n+1)))
 # Common integer denominator avoids repeatedly reducing huge inverse-clock fractions.
 terms=[ell[i]/J[i] for i in range(n+1)];clockden=lcm(*(t.denominator for t in terms));tn=[t.numerator*(clockden//t.denominator) for t in terms];suffix=[0]*(n+1);accum=0
 for i in range(n,-1,-1):accum+=tn[i];suffix[i]=accum
 L=lcm(*range(n,2*n+1));Lpow=L**n;massden=4**n*Lpow;hn=[];pn=[];accum=0
 for v in weight:
  hnum=v*massden;ck('integer_common_mass_denominator',hnum.denominator==1);hn.append(hnum.numerator);accum+=hnum.numerator;pn.append(accum)
 prod_den=n**n*clockden*massden;prod_num=[]
 def clockF(i):return F((n+i)**n*suffix[i],n**n*clockden)
 high=[z>h for z in past];directnum=prefixnum=Pnum=Cnum=allnum=0;running=0
 for i in range(n+1):
  p=smallindices[i];oldnum=pn[p] if p>=0 else 0;oldvolume=(4*(n+p)-1)**n if p>=0 else 0
  first=hn[i]*(n+i)**n*oldnum;second=hn[i]*oldvolume*Lpow;gapnum=first-second
  ck('inverse_clock_bound',(n+i)**n*suffix[i]*pn[i]<=prod_den)
  prod_num.append((n+i)**n*suffix[i]*oldnum);ck('past_inverse_clock_product_bound',prod_num[-1]<=prod_den)
  ck('genuine_gap_positive',gapnum>=0)
  allnum+=gapnum*suffix[i]
  if high[i]:
   running+=gapnum;directnum+=gapnum*suffix[i];Pnum+=first*suffix[i];Cnum+=second*suffix[i]
   ck('highpast_implies_highJ_h',J[i]>h)
  prefixnum+=tn[i]*running
 gden=massden*massden*n**n*clockden
 ck('inverse_clock_original_G_identity',directnum==prefixnum==Pnum-Cnum)
 Gprefix=F(prefixnum,gden);G_all=F(allnum,gden);primitive=F(Pnum,gden);correction=F(Cnum,gden)
 ck('actual_smallmass_correction_retained',0<=Cnum*Klo<=Pnum and 0<=prefixnum<=allnum)
 ck('central_G_row_upper',Gprefix<=J[-1])
 if n<=36:
  direct_literal=F(0);running_literal=F(0)
  for i in range(n+1):
   if high[i]:running_literal+=weight[i]*(mi[i]*past[i]-smallmass[i])
   direct_literal+=ell[i]*running_literal/J[i]
  ck('independent_literal_fraction_G',direct_literal==Gprefix)
 nonempty=any(high);ck('branch_nonempty_iff_central_G_positive',(Gprefix>0)==nonempty)
 llo,lhi=ln2bounds();Hroot2hi=(1+n*lhi)/4;ck('representative_root_below_h',Hroot2hi<h*h)
 # Central maximum dominates Z_y for EVERY source y, since each c_v(y)<=1.
 # Hence the empty cases are global emptiness certificates, not missed probes.
 scans=[]
 for level in [F(0),h/2,h,3*h/2,2*h]:
  active=[i for i,z in enumerate(past) if z>level]
  scans.append(dict(h_scan=str(level),central_global_past_max=brief(past[-1]),globally_empty_certified=not active,central_source_nonempty=bool(active),large_endpoint_blocks=len(active),first_large_radius=str(rs[active[0]]) if active else None))
 new_scans=[]
 for eps in [F(1),F(1,2)]:
  level=F(4*(1+k),3)/eps;active=[i for i,z in enumerate(past) if z>level]
  new_scans.append(dict(epsilon=str(eps),new_h=str(level),globally_empty_certified=not active,central_source_nonempty=bool(active),first_large_radius=str(rs[active[0]]) if active else None,scope='Full high-past gate only; no outside-center classification or integral computed.'))
 inv=[]
 for target in [h/2,h,2*h]:
  found=next((i for i,j in enumerate(J) if j>target),None)
  inv.append(dict(target_mass=str(target),first_strict_cross_radius=str(rs[found]) if found is not None else None,old_J=brief(J[found-1]) if found else '0',new_J=brief(J[found]) if found is not None else None))
 selected=sorted(set([0,n//2,n]+([high.index(True)] if nonempty else [])))
 details=[dict(i=i,radius=str(rs[i]),strict_past_last_index=smallindices[i],oldpast=brief(past[i]),small_mass_correction_T_over_m=str(smallmass[i]/mi[i]),inverse_clock=brief(clockF(i)),past_clock_product=brief(F(prod_num[i],prod_den)),highpast=high[i]) for i in selected]
 sourcevol=delta**n;W=4**n;lower=sourcevol*Gprefix
 out=dict(n=n,k=k,delta=str(delta),q_actual='1',q_minus='3/4',h=str(h),K_exp_k_lower=str(Klo),K_exp_k_upper=str(Khi),Jcentral=brief(J[-1]),Zpast_max=brief(past[-1]),branch_globally_empty_certified=not nonempty,branch_genuine_central_source_nonempty=nonempty,first_highpast_radius=str(rs[high.index(True)]) if nonempty else None,central_source_volume=str(sourcevol),full_source_mass=str(W),Xq_actual=str((2-delta)**n),G_central_highpast=brief(Gprefix),G_central_highpast_decimal=float(Gprefix),G_central_all_massgap=brief(G_all),highpast_fraction_of_central_G=float(Gprefix/G_all) if G_all else 0.0,primitive_clock_bill=brief(primitive),actual_small_mass_subtraction=brief(correction),subtraction_fraction=float(correction/primitive) if primitive else 0.0,full_source_G_lower=brief(lower),log10_full_source_G_lower_over_W=log10(float(Gprefix))+n*log10(float(delta)/4) if nonempty else None,clock_max_past_product=float(F(max(prod_num),prod_den)),threshold_scan=scans,new338_threshold_scan=new_scans,cumulative_inverse_mass_clock=inv,selected_endpoint_clocks=details,scope='Actual receiver dx shells; central source positive box yields lower bound only. Empty cases global via central Z maximum. Full source G integral not evaluated; W and central concentration retained.')
 print(json.dumps(dict(n=n,done=True,nonempty=nonempty,maxpast=float(past[-1]),h=float(h),Gcentral=float(Gprefix))))
 return out

def main():
 rows=[];stages=[]
 for title,ks in [('empty_gate',[2,3,4]),('first_nonempty',[5,6]),('high_dimension',[8,10])]:
  before=sum(C.values());rows.extend(case(k) for k in ks);stages.append(dict(stage=title,dimensions=[k*k for k in ks],exact_checks=sum(C.values())-before))
 out=dict(status='PASS',total_exact_checks=sum(C.values()),check_counts=dict(C),stages=stages,models=rows,scope='True positive-L1 uniformQ4 and positive-volume receiver shells, actual matched hard q1 caps. Strict K=e^sqrt(n),h=sqrt(n)/qminus; root H<=h retained. Nonempty central subset is exponentially small; no fullG/extremal/root/history assertion.')
 (BASE/'r338_numeric_result.json').write_text(json.dumps(out,sort_keys=True,indent=2)+'\n');print(json.dumps(dict(status='PASS',total_exact_checks=sum(C.values()),stages=stages),sort_keys=True))
if __name__=='__main__':main()
