# R526 最终独审

审核 /tmp/r526_main.tex、r526_numeric.py/json、r526_replay.json。先按已独立通过的bridge/column命题核完整账，再核最终证明与有限证据。结论：**主稿在所声明的全阶段列桥与完整未付joint积分范围内通过；未发现阻断性错误。** H>SA_n定义域收紧已在主稿补入。没有证明一般R_core或原弱界闭合。

## 1. 当前核、全stage包络与零分支：通过

M_i的真实密度含m_B²；d_i=∫s_i p_i R_B^−n c_B正确，行有限且≤SA_n。固定source在core存活的stage前缀上，κ_i递减、H≤d_i≤SA_n。单个正测度包络N_y的质量≤1+Σ(1−d_j/d_j−1)≤1+log(d_0/H)，故以同一z的Σb_i(z)≤1得到Σbhat_i(y)≤L_H。

证明不要求归一行本身单调。共同可测密度版本、有限行、可数非负求和足够处理无限stage和source退出；无退出后除零。H>0是必要的适用条件，H=SA_n允许闭core且L_H=1。H>SA_n时主稿现直接用R_actual≤2HW/θ并略core/lift项；boxed及C_aux只用于0<H≤SA_n，未使用负log帽。W=0或S=0亦明确零处理。

## 2. fair单端lift及主账：通过

旧端边缘θ^−1d_i bhat_i μ乘Ω后只消去一次d_i，留下一个p_i。全stage旧端到达帽θ^−1SL_H σπ；新端用同一z的b_i预算直接得θ^−1Sσπ。公平仅选一端，故C_aux=S(L_H+1)/(2θ)，1/2系数正确。所有原记录/源对/history仍为原投影；Ω是来源给定后的分析核，不是共同合法动作替代。

原soft门对同一个原父A给strict-past共同捕获概率≤λSh_0/H；中间质量闭区间的真实半径子带满足n次方比≤rK_0²，selector列界给概率≤S(1+log r+2√n)/H。质量边界原子归中间，不遗漏。公平标记的两方向平均无需再乘2。

原raw R_core≤SX已单独列明，未从较弱投影推断。因此H≥S²/ε·[r(1+√n)/ε_0+1+log r+2√n]确保方向删费≤εX。若只保投影合同，须额外θ^−1，主稿也写明。剥离费2H/θ仍保留，未重算任何原门或退款旧收据。

闭CDF T_B低支的σπ成本≤λh_0W，对质量原子安全；主账未用未经核实的aux严格过去gap。inner成本α^nA_nW来自同一原selector包络。两项以完整fair到达帽C_aux计价，即使与方向删支重合也只是正上放。由依次限制，主账完整剩余恰为T高、collar及past-exclusive/far-future两方向，future-common和future-exclusive均保留。

boxed式的W系数与各项定义相符，固定依赖参数、root-order H下为O_ε(√n log(n+2))。这是bandwise接口账；原入口倍率、其他未付积分和全ε吸收没有被省略。

## 3. Xi与Q：两个不同lift均准确，不能混用

在aux共同捕获上，旧端joint密度与s_i(B)σπ_B²之比的上界为

\[
\theta^{-1}b_i(z)\,
\frac{m_Bp_i(B)K_i(y,z)}{d_i(y)}.
\]

故Xi公式正确；新端仅将分母换d_i(z)。若按实际fair旧端子支计算，还带1/2；正文写“at most”而使用未减半上界是合法的较粗上界，主账并未因此丢失fair系数。此处K_i不应误换成少一个质量分母的共捕获量。

pair posterior Q_i以q_Bs_i c_yc_z/m_B²除以K_i归一。实际F_i密度乘Q_i后K_i消去，跨stage用b_i(z)预算得到θ^−1Sσπ_B²，确无额外p或log。K_i=0处实际需求为0；K_i非有限的μ×μ零集可按共同版本略去，有限总行保证该处理合法。

Q与Ω的条件质量方向概率不同。主稿未把Q的干净joint到达帽与Ω的方向删费无价拼接，也未用m_B>K_0m_A时旧A是past共同父来抹去Xi偏置。exclusive分支甚至无共同aux父；主稿明确这些joint/occupation/terminal仍未付款。

## 4. 数值和重放范围：通过

脚本仅重建冻结R525输入与core，验证归一有限行、原逐source b预算、正profile变差/离散包络及Arb log界。未模拟parent-incidence、cube或history，也未声称数值验证Xi/Q或joint几何；这些由解析公式承担。

本审实际使用指定Python -I、Fraction/Arb256定向核验：三个模型的seed、μ、θ、δ、R及逐stage core与冻结R525 JSON完全一致；每source精确b预算≤1；累计bhat≤点态profile包络≤正变差预算≤离散密度比预算，并以Arb核其低于log界。退出后0处理正确。独立核指定二source/two-stage例的bhat、包络和离散预算均精确3/2，故没有错误的累计subprobability断言。

同时核当前脚本SHA256与root replay记录相符，检查数11961一致；root记录报告隔离重放除seconds外JSON全部一致。本审没有重复运行旧轮或代称独立全脚本重放。输出：

`PASS targeted frozen-core, exact normalized-budget, Arb-log, minimal 3/2, and replay-hash checks`

## 5. 最终范围

可归档：完整core上的可数stage归一列桥、公平单端提升的完整有价账，以及相应有限代数证据。

仍未闭合：boxed式最后的全部R_joint^Ω、两种lift之间的有价coupling、实际未来/路径occupation及terminal控制、原完整入口吸收。当前未发现需进一步修改的实质问题；本审冻结后停止。
