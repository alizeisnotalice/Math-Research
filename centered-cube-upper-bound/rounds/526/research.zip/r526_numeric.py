#!/usr/bin/env python3
"""R526 normalized column-envelope checks on frozen R525 finite inputs; not cube/parent geometry."""
from fractions import Fraction as Q
from pathlib import Path
import random,json,sys,platform,time
import flint
from flint import arb,ctx
ctx.prec=256
ROOT=Path(__file__).resolve().parent
checks=0

def ck(cond):
 global checks
 assert cond
 checks+=1

def exact(x):return str(x)

def case(name,n,m,seed,theta,delta,stress):
 rng=random.Random(seed)
 mu=[Q(rng.randint(1,9),rng.randint(1,9))*(Q(2)**((a%9)-4) if stress else 1) for a in range(n)]
 ck(all(x>0 for x in mu))
 kernels=[];previous=None
 for i in range(m):
  mat=[[Q(0) for b in range(n)] for a in range(n)]
  for a in range(n):
   for b in range(a,n):
    if previous is None:v=Q(rng.randint(1,12),rng.randint(1,8))
    else:
     # Heterogeneous plateaux and abrupt positive downward jumps, all symmetric.
     ratio=(Q(1,64) if stress and (i+a+2*b)%4==0 else Q(rng.randint(1,8),8))
     v=previous[a][b]*ratio
    mat[a][b]=mat[b][a]=v
  ck(all(mat[a][b]>0 and mat[a][b]==mat[b][a] for a in range(n) for b in range(n)))
  if previous is not None:ck(all(mat[a][b]<=previous[a][b] for a in range(n) for b in range(n)))
  kernels.append(mat);previous=mat
 bvals=[[Q(0) for b in range(n)] for i in range(m)]
 for b in range(n):
  raw=[rng.randint(0,9) for i in range(m)]
  if sum(raw)==0:raw[0]=1
  budget=Q(rng.randint(1,4),4)
  for i in range(m):bvals[i][b]=budget*Q(raw[i],sum(raw))
 ck(all(bvals[i][b]>=0 for i in range(m) for b in range(n)))
 ck(all(sum(bvals[i][b] for i in range(m))<=1 for b in range(n)))
 F=[]
 for i in range(m):
  mat=[]
  for a in range(n):
   row=[]
   for b in range(n):
    upper=bvals[i][b]*mu[a]*mu[b]*kernels[i][a][b]/theta
    value=upper*Q(rng.randint(0,8),8)
    ck(0<=value<=upper);row.append(value)
   mat.append(row)
  F.append(mat)
 R=sum((F[i][a][b] for i in range(m) for a in range(n) for b in range(n)),Q(0));ck(R>0)
 incident=[sum((F[i][a][b]+F[i][b][a] for i in range(m) for b in range(n)),Q(0)) for a in range(n)]
 L=[incident[a]/mu[a] for a in range(n)]
 ck(sum(incident)==2*R)
 # Set threshold from actual demands, then recompute the strict actual incidence gate.
 # This is a deterministic single gate per model, not a parameter scan.
 threshold=sorted(L)[n//2]*Q(7,8);ck(threshold>0)
 A=tuple(a for a in range(n) if L[a]>threshold)
 ck(A and all((a in A)==(L[a]>threshold) for a in range(n)))
 h=delta*theta*threshold/4
 muA=sum((mu[a] for a in A),Q(0))
 ck(muA<=2*R/threshold)
 # Reconstruct only the same stable cores. No old paid/core budget recheck.
 C=set(range(n));cores=[];events=[]
 for i in range(m):
  roundno=0
  while True:
   density={y:sum((mu[z]*kernels[i][y][z] for z in C),Q(0)) for y in C}
   batch=sorted(y for y in C if density[y]<=h)
   if not batch:break
   events.append({'stage':i,'round':roundno,'removed':batch})
   C.difference_update(batch);roundno+=1
  cores.append(set(C))
 H=h
 def ball(v):return arb(v.numerator)/v.denominator
 def astr(v):return v.str(35,radius=True)
 rows=[];bhat_by_stage=[[Q(0) for y in range(n)] for i in range(m)]
 pointwise_plateaux=pointwise_strictdrops=0
 for y in range(n):
  kappas=[[mu[z]*kernels[i][y][z] if y in cores[i] and z in cores[i] else Q(0) for z in range(n)] for i in range(m)]
  for i in range(1,m):
   ck(all(kappas[i][z]<=kappas[i-1][z] for z in range(n)))
   pointwise_plateaux+=sum(kappas[i][z]==kappas[i-1][z] and kappas[i][z]>0 for z in range(n))
   pointwise_strictdrops+=sum(kappas[i][z]<kappas[i-1][z] for z in range(n))
  D=[sum(kappa) for kappa in kappas]
  active=[i for i in range(m) if D[i]>0]
  ck(active==[i for i in range(m) if y in cores[i]])
  ck(all(D[i]>H for i in active))
  ck(not active or active==list(range(active[0],active[-1]+1)))
  if not active:
   ck(all(v==0 for kappa in kappas for v in kappa))
   rows.append({'source':y,'active_stages':[],'bhat_sum_exact':'0','envelope_mass_exact':'0','discrete_budget_exact':'0','log_budget_arb':None,'removed_before_first_core':True})
   continue
  ps={i:[v/D[i] for v in kappas[i]] for i in active}
  envelope=[Q(0)]*n;increment_sum=Q(0);discrete=Q(1);stage_rows=[]
  previous=None
  for i in active:
   ck(sum(ps[i])==1)
   bhat=sum((bvals[i][z]*ps[i][z] for z in range(n)),Q(0));bhat_by_stage[i][y]=bhat
   ck(0<=bhat<=1)
   if previous is not None:
    variation=sum((max(Q(0),ps[i][z]-ps[previous][z]) for z in range(n)),Q(0))
    jump=1-D[i]/D[previous]
    ck(0<=variation<=jump)
    increment_sum+=variation;discrete+=jump
   else:variation=Q(0);jump=Q(0)
   old_env=sum(envelope)
   envelope=[max(envelope[z],ps[i][z]) for z in range(n)]
   if previous is not None:ck(sum(envelope)-old_env<=variation)
   stage_rows.append({'stage':i,'D_exact':exact(D[i]),'bhat_exact':exact(bhat),'profile_positive_variation_exact':exact(variation),'one_minus_density_ratio_exact':exact(jump),'envelope_mass_exact':exact(sum(envelope))})
   previous=i
  total=sum((bhat_by_stage[i][y] for i in range(m)),Q(0));env=sum(envelope)
  ck(total<=env<=1+increment_sum<=discrete)
  # Original source budget, used once under a sourcewise max profile envelope.
  weighted_env=sum((envelope[z]*sum(bvals[i][z] for i in active) for z in range(n)),Q(0))
  ck(total<=weighted_env<=env)
  logbound=1+(ball(D[active[0]])/ball(H)).log()
  ck(ball(discrete)<logbound)
  ck(all(bhat_by_stage[i][y]==0 for i in range(m) if i not in active))
  rows.append({'source':y,'active_stages':active,'D_first_exact':exact(D[active[0]]),'D_last_exact':exact(D[active[-1]]),'bhat_sum_exact':exact(total),'envelope_mass_exact':exact(env),'positive_variation_budget_exact':exact(1+increment_sum),'discrete_budget_exact':exact(discrete),'log_budget_arb':astr(logbound),'bhat_sum_float':float(total),'envelope_mass_float':float(env),'discrete_budget_float':float(discrete),'stage_details':stage_rows,'removed_before_first_core':False})
 original_budgets=[sum(bvals[i][z] for i in range(m)) for z in range(n)]
 ck(all(v<=1 for v in original_budgets))
 actual_max=max(Q(r['bhat_sum_exact']) for r in rows)
 envmax=max(Q(r['envelope_mass_exact']) for r in rows)
 return {'stage':name,'n_sources':n,'n_kernel_stages':m,'seed':seed,'theta_exact':exact(theta),'delta_exact':exact(delta),'H_exact':exact(H),'mu_exact':[exact(v) for v in mu],
 'original_source_budgets_exact':[exact(v) for v in original_budgets],
 'same_R525_input':True,'R_exact':exact(R),'K_gate_exact':exact(threshold),'b_original_by_stage_exact':[[exact(v) for v in row] for row in bvals],'core_source_indices_by_stage':[sorted(C) for C in cores],'core_deletion_events':events,
 'rows':rows,'bhat_by_stage_exact':[[exact(v) for v in row] for row in bhat_by_stage],
 'maximum_actual_original_bhat_sum_exact':exact(actual_max),'maximum_actual_original_bhat_sum_float':float(actual_max),'any_actual_original_bhat_sum_above_one':actual_max>1,
 'maximum_envelope_mass_exact':exact(envmax),'maximum_envelope_mass_float':float(envmax),
 'positive_pointwise_plateaux_count':pointwise_plateaux,'pointwise_strictdrop_count':pointwise_strictdrops,
 'zero_core_stages':[i for i,C in enumerate(cores) if not C],
 'scope':'Abstract finite normalized column kernels only. Original b retained; accumulated bhat is NOT asserted to have subprobability budget. No parent-incidence lift or cube geometry is constructed.'}

def fixed_minimal_algebra_check():
 # Parent-specified fixed algebra example only: K1 has zeros, so this is not
 # one of the three strictly-positive original R525 inputs or cube geometry.
 mu=[Q(1),Q(1)];K=[[[Q(1),Q(1)],[Q(1),Q(1)]],[[Q(0),Q(0)],[Q(0),Q(1)]]]
 b=[[Q(1),Q(0)],[Q(0),Q(1)]];H=Q(1,2)
 C=set(range(2));cores=[]
 for i in range(2):
  while True:
   low={y for y in C if sum(mu[z]*K[i][y][z] for z in C)<=H}
   if not low:break
   C-=low
  cores.append(set(C))
 ck(cores==[{0,1},{1}])
 ck(all(sum(b[i][z] for i in range(2))==1 for z in range(2)))
 y=1;kappa=[[mu[z]*K[i][y][z] if y in cores[i] and z in cores[i] else Q(0) for z in range(2)] for i in range(2)]
 ck(kappa==[[Q(1),Q(1)],[Q(0),Q(1)]])
 D=[sum(row) for row in kappa];profiles=[[v/D[i] for v in row] for i,row in enumerate(kappa)]
 bhat=[sum(b[i][z]*profiles[i][z] for z in range(2)) for i in range(2)]
 envelope=sum(max(profiles[i][z] for i in range(2)) for z in range(2))
 discrete=1+(1-D[1]/D[0])
 ck(bhat==[Q(1,2),Q(1)])
 ck(sum(bhat)==envelope==discrete==Q(3,2))
 ck(sum(bhat)>1)
 return {'scope':'ONE parent-specified minimal algebra check only; K1 has zeros, not original strict-positive R525 inputs or real cube geometry; no search',
 'mu_exact':['1','1'],'K_exact':[[['1','1'],['1','1']],[['0','0'],['0','1']]],'H_exact':'1/2','b_exact':[['1','0'],['0','1']],
 'core_source_indices_by_stage':[sorted(C) for C in cores],'tested_source':1,'kappa_exact':[[exact(v) for v in row] for row in kappa],
 'D_exact':[exact(v) for v in D],'bhat_by_stage_exact':[exact(v) for v in bhat],'bhat_sum_exact':exact(sum(bhat)),
 'envelope_mass_exact':exact(envelope),'discrete_budget_exact':exact(discrete),'original_source_budget_exact':['1','1'],
 'conclusion':'New accumulated normalized column budget can exceed one; discrete envelope bound can be attained exactly.'}

def main():
 start=time.perf_counter()
 models=[case('probe',4,3,52501,Q(1,3),Q(1,2),False),case('heterogeneous_jump_pressure',10,8,52502,Q(2,5),Q(1,3),True),case('expanded_stages_and_points',24,17,52503,Q(3,7),Q(2,5),True)]
 ck(any(m['zero_core_stages'] for m in models))
 ck(any(m['positive_pointwise_plateaux_count']>0 for m in models))
 ck(any(m['pointwise_strictdrop_count']>0 for m in models))
 minimal=fixed_minimal_algebra_check()
 out={'minimal_fixed_algebra_check':minimal,'scope':'R526 bounded finite normalized-column envelope on exactly the R525 three inputs; not old paid/peeling budget scan and not a cube/parent-history realization',
 'explanation':'For each source y, kappa_i^y(z)=1_Ci(y) mu_z K_i(y,z) 1_Ci(z) decreases pointwise. Normalize only on its positive active interval, where D_i>H. Original sourcewise sum_i b_i(z)<=1 yields sum_i bhat_i(y)<=sum_z max_i kappa_i^y(z)/D_i. Positive profile variation gives envelope<=1+sum_j(1-D_j/D_prev), and Arb verifies this <=1+log(D_first/H). After core removal bhat=0; D=0 never appears in a ratio. No universal sum bhat<=1 is claimed; the actual maxima are recorded. Row auxiliary parent lift would require a separate parent-incidence realization, absent here.',
 'environment':{'executable':sys.executable,'python':platform.python_version(),'arithmetic':'fractions.Fraction and Arb only for log','python_flint':flint.__version__,'arb_precision_bits':ctx.prec},'models':models,'checks':checks,'seconds':time.perf_counter()-start}
 (ROOT/'r526_numeric.json').write_text(json.dumps(out,indent=2)+'\n')
 for m in models:print('STAGE',m['stage'],'max actual bhat sum',m['maximum_actual_original_bhat_sum_float'],'max envelope',m['maximum_envelope_mass_float'],'zero core',m['zero_core_stages'])
 print('PASS',checks,'exact normalized-column envelope/discrete-budget checks and Arb log bounds; abstract finite kernels only')
if __name__=='__main__':main()
