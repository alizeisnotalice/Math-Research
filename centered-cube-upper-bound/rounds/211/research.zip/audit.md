# R211 independent premise audit

## 1. Order and actual quantity

Read `task_contract.md` before any R211 author manuscript. The calculations below were completed from the accurate candidates and already reviewed CT/LC definitions before reading their new proofs. Only this file is edited; no Git, spawning, numerical execution or PDF compilation is performed. This screen concerns persistent capture recovery, not the baseline or the entire original raw.

On one original legal row write p=p_y, w_v=w_g(y,v), J_v>0, Q=int J dnu, a_v=T(w_tau-w_h), kappa_v>=0. The same nested actual capture has alpha-minus>=alpha-plus>=0 and Gcap=Q delta-alpha. The persistent common-qualified set C lies in terminal G intersect Ecap-minus intersect {a>0}; all source/clock/outer backgrounds remain common. CT12's nonnegative receiver integrand is

    p/(T e_g) integral_C zplus a Delta-rho dnu.

T>0,e_g>0 and nonempty actual far qualify divisions. The zero/empty source, Q, a, alpha-difference and far cases are handled before their ratios. New entries, denominator decrease, baseline insufficiency, current/gate changes and the full original RT1/beta/source/receiver/j/window account remain separate.

## 2. Exact common-alpha layer and correlated truncation

For delta-alpha>0 define b_v=(a_v-kappa_v)/J_v and

    s_v=[min(alpha-minus,b_v)-alpha-plus]_+/delta-alpha in [0,1].

The exact shared-alpha identity is

    a_v Delta-rho_v=integral_(alpha-plus)^(alpha-minus)
        J_v 1_{b_v>lambda} dlambda
      =delta-alpha J_v s_v
      =min(delta-alpha J_v,(a_v-kappa_v-alpha-plus J_v)_+).

The same alpha interval applies to all targets. Equality on a lambda threshold has zero one-dimensional integration measure; one cannot optimize a different alpha interval for each target. Let pi_J=Jnu/Q and W_v=min(p,KJ_v/(3w_v)). Actual postgood and S>=J give p zplus<=W_v, so the valid correlated truncated receiver bound is

    CT12-row <=Gcap/(T e_g) E_piJ[W_v s_v]
      =1/(T e_g) integral_(alpha-plus)^(alpha-minus)
         integral_(C intersect {b_v>lambda}) J_v W_v dnu dlambda.

This retains the actual J/w/p/capture correlations and caps the inverse-w branch by p. The inactive-alpha slack remains through s_v. It improves the uncapped J/w upper relaxation conditionally but does not give a general source column. No layer can independently spend Gcap or redefine the physical capture set/reserve. Replacing min by a fractional-power upper bound is possible only with its resulting joint inverse-overlap moment explicitly retained.

The physical clock also gives a_v<=T(1-w_v) for terminal survivors, hence the exact common-alpha gain is bounded by min(delta-alpha J_v,[T(1-w_v)-kappa_v-alpha-plus J_v]_+). This is another source-dependent restriction, not independent probabilities or a universal small mass assumption.

## 3. Pointwise high, a column estimate and actual S

High p e_g>=2Kq gives 1/e_g<=p/(2Kq); together with int p beta<=q it gives int_high beta/e_g<=1/(2K). It does not pay int p beta/e_g or allow the y/receiver-dependent W_v s_v multiplier to be taken outside that column without its own uniform or jointly integrated estimate. FIRST int Jnu<=q is likewise a one-sided mass capacity, not a bound for inverse overlap or an arbitrary correlated likelihood moment. Pointwise p/T estimates retain their true scale/c_j/receiver-selector costs.

The scalar choice S=max(J,3pw/K), which would maximize z under only those two inequalities, is merely a relaxation. In the physical family S=p_v+p_vplus+J; scale monotonicity gives p_vplus>=gamma^(-n)p_v, hence S>=J+(1+gamma^(-n))p_v and

    z<=min(J/[J+(1+gamma^(-n))p_v],KJ/(3pw)).

All kernels have the same actual receiver/current parameters. The scalar equality case cannot be declared physically attainable by freely choosing S or J. If the target is additionally high-A, z>=A>=1-eta, so the postgood cap itself need not give a uniform small multiplier; the actual common geometry must be used instead.

## 4. Independently screened normalizer-log candidate

The parent supplied the following new accurate candidate before its proof. Set f_v=zplus Delta-rho_v on terminal C, time fixed, 0<=f<=Fmax, and F(t)=int_C f_v w_t(v)dnu. On the actual far subset,

    e_t>=e_g+integral_C(w_t-w_h)dnu
        >=e_g+[F(t)-F(h)]/Fmax.

Dropping only the true bad probability and the bounded positive gates gives recovery<=int(-F')/e_t. Expanding the nonnegative surrogate integral, rather than inventing an auxiliary posterior outside its domain, yields

    recovery<=Fmax log(1+[F(tau)-F(h)]/(Fmax e_g))
      <=Fmax log(1+Gcap/(T Fmax e_g)).

The first bound is sharper and uses the true F increment; the second uses CT/LC capacity. Fmax=0 or zero increment is zero first, not 0*infinity. Target survival through the full physical [tau,h] and the actual positive e_g are necessary; time-dependent f would add its real test exchange. This is a valid strict improvement over the corresponding positive linear upper relaxation when its argument is nonzero, not a general receiver/source payment. It reuses the established denominator-compensation/terminal-FTC mechanism and is not certified as a new coverage theorem relative to every historical interface.

## 5. One log for a same-clock chain, screened independently

With common a,kappa,J,nu,clock,e_g and monotonically decreasing alpha_i, the parent then supplied a chain candidate. Define fSigma(v)=sum_i 1_Ci(v) z_i Delta-rho_i(v), with each common-qualified Ci in the same terminal surviving set. Since z_i<=1 and all increments are nonnegative,

    0<=fSigma<=sum_i Delta-rho_i=rho_final-rho_initial<=1.

Summing the actual nonnegative recoveries before the derivative estimate uses the same original posterior; their bad/gate factors may each be positively bounded by one. The single combined F_Sigma then satisfies Delta F_Sigma<=sum_i G_i/T=(H_0-H_m)/T. Applying the normalizer estimate once therefore gives

    sum_i recovery_i<=log(1+(H_0-H_m)/(T e_g)).

This does not follow by summing individual log bounds and replacing their sum by a log. Its justification is the common time-fixed combined target weight bounded by one. No source is reselected independently at each time. Changing clock/source/baseline/terminal survival, recharge, entry and actual signed finite exchanges remain outside this fixed-background chain statement.

## 6. Additional soft-geometry candidate check, not a new route

The raw author separately proposed a conditional soft-layer estimate. Its scale algebra passes: the original band gives g/L<=gamma/c_j, and g>=a_win/c_j with g<=b c_j implies c_j^2>=a_win/b>=1/2. Thus, with the true f_s supremum a_s=1-s+s phi(0),

    p_y/T <=sqrt(1+log n)[gamma 2^(3/4) a_s]^n.

The proposed shortcut phi(0)<=1/2 was flagged before any proof: it is false and was withdrawn without being written as a theorem. An elementary check gives phi(0)=2int_0^1 a(1-exp[-1/(2a)])da>1/2. For example split at a=1/2, use e>8/3 on the first half and the fourth-order Taylor lower bound on the second, obtaining phi(0)>1/2+73/384-(log2)/4>1/2+29/1920. Here log2<7/10 follows from exp(7/10)>12013/6000>2. This check only removes the invalid constant; it does not initiate a separate soft-layer research project.

The same row CT/high combination gives recovery<=D p_y/(2KT); after the genuine positive hard reduction its coefficient is 16Lambda/(3K). Any actual D must have a proved common bound or remain in its row weight. Current-column integration and unique-j merging require the original uniform row qualification and window/source account, not merely a fixed-parameter kernel normalization. No general soft/middle closure is certified from this conditional candidate.

Initial-stage status (superseded by sections 7 onward): independent premise screens were completed before reading author proofs. At that stage the correlated truncation and normalizer/chain interfaces had not yet supplied an actual source payment. Section 7 records the later independently verified original-heavy payment; no general closure is inferred.

## 7. Priority original-heavy inheritance and actual recovery payment screen

The parent and raw author then identified a potentially decisive original gate. Independently read the narrow original R122 `mixed_test_capacity_private.md` MC1–7, R122 proof UP1–10, R125 proof AC1–11 and FC2–3, and R128 proof RT1–6 plus its heavy protocol at line 16489. These are original source checks, not new author proofs. The nonzero original high-branch terminal-surviving traffic retains the heavy history

    e_g>ell q c_j^(-n/2) g^n,
    T=c_j^(n/2)/(g^n sqrt(ell)),
    T e_g>sqrt(ell) q,  ell=1+log n.

This is part of the same complete original traffic; it is not an extra hypothesis specific only to a new UP-E kernel superlevel subset. R128 keeps that actual history and the already fixed capture parameter D. The earlier generic high-column/truncated discussions did not use this lower bound and must not be presented as proving that the persistent recovery on actual heavy rows still necessarily faces an inverse-w_g column.

For one qualified persistent comparison, or a qualified same-clock nested chain, Gtot<=H_0<=Dq and the reviewed CT capacity immediately give

    Rtot<=Gtot/(T e_g)<=D/sqrt(ell).

Multiplying by the unchanged original RT1 measure first gives 2Lambda times this row price. Only then T_small<=4X gives 8Lambda D X/sqrt(ell). No separate positive hard cap is taken before this signed/history account, and no extra source, time or j menu appears.

For the actual original D=max(1,epsilon_RC sqrt(ell)/(8Lambda)-16/(3sqrt(ell))), choose parameters jointly before the input with epsilon_RC<=epsilon_rec. If D>1, the new coefficient is epsilon_RC-128Lambda/(3ell)<epsilon_rec, directly paid. If D=1, dimensions n>=N_rec=ceil exp[(8Lambda/epsilon_rec)^2-1] are also directly paid. The only fallback branch is D=1 and n<N_rec. There Rtot<=D/sqrt(ell)<=1 is valid. This bound must not be inferred merely from fSigma<=1 for all dimensions; that unqualified inference was explicitly flagged.

The original finite-dimensional mother estimate T_small<=(16/3)2^n D_mother W_beta, D_mother<=1+(pi/2)sqrt n, then gives source constant C_rec=(32Lambda/3)(1+pi/2)2^N_rec times sqrt n W_beta on that fallback. The repaired common-parent account may further bound W_beta by W_A. Thus this identified persistent recovery admits an independent epsilon_rec X plus finite-constant root-source payment, subject to its actual common-clock/persistent qualifications.

R125 AC11 already spent its original capture-price epsilon_RC slot and replaced the old G price rather than adding it. The new recovery price cannot reuse that slot for free. Parameters must be chosen jointly in advance; a previously frozen epsilon_RC cannot be retroactively changed to prove every smaller epsilon_rec. This payment controls the identified recovery component only. It does not construct a global common-clock deformation from zero baseline, pay target entry/recharge or arbitrary changed-clock/outer/selector exchanges, or close the whole raw problem. These restrictions are part of the acceptance, not optional caveats.

## 8. Full manuscript review and general-source legality

Read the complete `normalizer_log_budget.md` and `receiver_log_probe.md` after the independent screens. The log estimate retains the real terminal denominator and uses a nonnegative physical-clock surrogate when enlarging the actual far set; it does not invent a posterior or history outside that set. For arbitrary positive sources on a finite positive window, w_tau/w_g<=(g/tau)^n and C subset Z_g give integral_C w_tau dnu<infinity. The derivative of F is dominated by M n/tau times this integrable source weight, so Tonelli and the absolutely continuous chain rule justify the displayed FTC without assuming finitely many atoms or subtracting infinite masses. The same-clock sum uses the combined time-fixed fSigma before applying one log. The fixed-probability softplus moment interface is valid only with its true probability normalization and parameters fixed before receiver integration.

Read `joint_capacity.md` in full. JC1--16 correctly reconnect the original heavy history, actual preselected D, complete RT1 measure, T_small<=4X and repaired W_beta<=W_A. JC7's comparisons are non-strict, including zero capture gain. The 2Lambda prefactor and independent epsilon_rec slot are correct; no additional hard 16/3 factor is multiplied. The D=1 finite-dimensional fallback is justified by its actual row bound rather than by fSigma<=1 alone. JC17--18's fixed-kernel mean and uniform variance<45 are accurate auxiliary facts, not used to evade adaptive receiver costs. These conclusions do not transfer to an abstract high-only relaxation that has dropped the original heavy history.

Read all of `auxiliary_budget.md`. The scale comparison, common-alpha response, measurable free-S field supremum, correlated min identity, and positive-net supremum AB3--15 are correct with their stated zero guards. The free field can attain S=m, whereas actual physical equality requires its true shared kernels to attain that field floor on response slots. Keeping old-good Sminus makes the postgood floor redundant; the manuscript correctly does not count cross-min saving as new physical coverage. AB14 is a sufficient zero-positive-net test, not a claim that all core slots pass it. The author added the requested scope distinction: the auxiliary field interface alone leaves AB16, while the actual heavy rows receive the separate joint-capacity payment. The AB8 test proposal's original status is historical; subsequent actual tests are assessed separately below.

## 9. Numerical and driver static review (not a new execution)

Read the complete `log_budget_checks.py`, including the supplemented `field_sup_cases`, and the current numerical notes. The 40-term atanh remainder is a valid directed enclosure; negative dyadic exponents correctly reverse the log2 interval endpoints. The single-step posterior integral retains the full source denominator, and the chain's common f/M proof is independent of the deliberately nonzero sum-of-step-logs gap. Zero M is dispatched before division. Scalar-heavy diagnostics are explicitly not a geometric history certificate.

The three added AB8 arrays recompute full U/H/alpha, genuine min-product a and e_g; their response is checked independently by the shared-alpha activity-layer integral. The m, 3m/2 and 2m comparisons correctly certify the relaxed response and net extrema, with the expanded source's negative signed net retained. Their old-good cross saving is zero and their actual high test is false, both explicitly recorded. The separate cross-min example is pure arithmetic, not a physical input. No code equates such arrays with a common spatial phi/K0/FIRST realization. Final numerical hashes remain pending the author's final supplemented notice and the final integration review; this auditor has not run this script.

Read `report.md` and `reproduce.py`. The current driver checks manifest syntax, path containment and all supplied SHA256 values, runs a relocated script plus contract, compares the entire output JSON byte-for-byte and rechecks hashes. It preserves standard interpreter selection and does not overwrite an existing/protected reference JSON. The manifest and final parent driver do not yet exist at this review stage; no future replay is reported as passed. The report's persistent-recovery scope and separate epsilon allocation match the reviewed mathematics. Its numerical paragraph must follow the final supplemented notes when the new AB8 cases are integrated.

## 10. New virtual-baseline candidate, independently screened before its proof

The parent then supplied a stronger single-actual-row construction. Freeze the final actual nu,a,kappa,J,S,alpha, capture U, all gates/history and target G subset Z_g. Set alpha0=Dq/Q>=alpha and on that very same actual target define rho0=(1-kappa/a-alpha0 J/a)_+ and Delta rho=rho-rho0. This is an algebraic auxiliary weight; no claim is needed that an empty-capture history is legal. For a>0,

    0<=Delta rho,  a Delta rho<= (alpha0-alpha)J,
    (alpha0-alpha)Q=integral U dnu<=Dq.

Thus the actual A=zrho splits exactly into zrho0+zDelta rho. Every original gate, even one depending on actual rho, remains the same actual gate on both summands. Applying the same physical far FTC to the positive recovery gives Rrec<=integral U/(T e_g)<=D/sqrt(ell). The heavy/RT1 payment from section 7 applies directly, without assuming C subset an earlier capture set or constructing a nested common-clock chain. Zero a/Q, empty far and absent targets are isolated before ratios; terminal survival and the real auxiliary window remain essential.

For the signed J account the exact bookkeeping is R_J=(P_baseline-N_original)+P_recovery. The original negative credit is retained only once, with the baseline; no new negative credit or rho-dependent gate is recomputed for the virtual state. If another component has already consumed a portion of N_original, only the still-available original ledger may be written here. This reduces the actual J remainder to an explicit high-alpha0 baseline plus a paid recovery; it does not pay that baseline, other shares, or assert the general weak-type target. Await the author's precise final formulation before certifying its transcription or final file binding.

Full follow-up read: JC19--27 explicitly supplies the original RC definition, handles kappa>=a by zero remainder, keeps actual rho-dependent gates, and uses only the still-available original negative balance. Its algebraic decomposition, far FTC, original-heavy payment and high-alpha0 baseline support all pass. This does not independently imply a source estimate for the baseline support condition.

## 11. Complete rho remainder upgrade, independently screened

The parent then asked whether the same argument can use z=1 and act before splitting the three current-test shares. Independently read original R128 proof RT1--6 and R127 SP2--4/GB12 for this new scope question. R128 RT2's complete original positive remainder has coefficient rho=1-b_rec, not just (J/S)rho. Its actual gates and complete double posterior are unchanged. R127 confirms E=S_g intersect {B_hard=0,Delta>0}, the actual RC U and alpha, and the zero outside-remainder convention. E is terminal surviving and a>0 on its nonzero traffic.

The proof of section 10 only needed 0<=z<=1. Taking z=1 gives integral_E a Delta rho dnu<=G_U and therefore the same row repair bound G_U/(T e_g)<=D/sqrt(ell) directly for the full original rho-positive remainder. The hard source h_R remains in RT1's unchanged outside measure and imposes no extra restriction on this substitution. For any original positive subset already removed as paid, perform the same nonnegative split on exactly its remaining actual domain.

Consequently the valid full signed ledger is

    2Lambda(P_rem(rho)-N_available)
      =2Lambda(P_rem(rho0)-N_available)+2Lambda P_repair.

N_available is the original still-unconsumed negative balance, attached once to the baseline; it includes no invented FA or rho gate. The complete repair is paid by the single independent epsilon_rec slot and the finite-dimensional root-source fallback already reviewed. One must not additionally charge each share's repair against another copy of the same budget. This strengthens the earlier J-share scope, but leaves an explicit full high-alpha0 baseline. Neither that baseline nor the general weak-type theorem is certified. Full follow-up read of JC28--30 and the updated parent normalizer/report confirms that the full-rho version, same remaining domain, no repeated share allowance and near/baseline restrictions are accurately transcribed.

Numerical narrow follow-up: read the final_state_repair addition and the notes' final supplement. It reuses only the three initial final actual arrays, recomputes alpha0=Dq/Q, retains original target z and exact posterior kernel, verifies full final-E capacity and the exact A=A0+repair identity, then compares repair with its actual-target and total-capture log intervals. Its scalar heavy qualification is unchanged and is not called a full spatial history. No new physical input or empty-capture history is claimed. The code and notes correctly distinguish these three reused checks from new clock cases. This is a static review, not an execution by this auditor.

## 12. Final integration conclusion

Read the complete 955-line detailed `proof.tex.txt` against all four mathematical manuscripts, the final report, code, JSON and notes. The full-rho theorem is precisely the same actual remaining R128 RT2 far traffic, with the original 2Lambda RT1 factor, fixed real gates and one available negative balance; its baseline is not paid. The prior persistent and J-share statements are subapplications and do not receive extra copies of the recovery budget. Heavy inheritance, parameter preallocation, D>1 absorption, D=1 fallback, general-source AC and all zero branches match the reviewed proofs. Auxiliary field optimization does not grant physical independent slot realizability. Its historical AB8 proposal now explicitly points to the subsequently executed finite tests.

The finite evidence comprises 9 single-step cases, 1 shared-clock chain, 3 D calibrations, 3 auxiliary field models and a separate arithmetic cross-min calibration; the alpha0 repair checks reuse the first 3 final states. Static JSON reading confirms repair flows 1/120, 1/120, 1/330 and total-capture linear prices 1/7, 1/7, 3/35. No spatial FIRST/high/history realization or general theorem follows from these arrays. The full z=1 theorem is analytic, not inferred from finite original-z samples. The report's final scope and numerical counts match this distinction.

The remaining theorem-level obstacle after the paid replacement is the explicit full far high-alpha0 signed baseline, with its actual common sources and still-available negative credit; original near/other untouched blocks also remain. A separate state-path proof would still owe its real entrance, clock, geometry, recharge and outer-measure exchanges, but such a path is not required to justify this fixed-row algebraic replacement. The general n^(1/2+o(1)) weak-type target is not certified as closed.

Audit actions were source/formula review, code/JSON static reading and actual-byte hashing only. No numerical script or parent reproduction driver was executed by this auditor; no PDF was compiled. The final parent manifest/archive driver is outside this audit's execution claims. Final file bindings below exclude this audit and the future manifest to avoid a hash cycle.

## 13. Final SHA256 bindings and freeze

The five TeX transcription omissions were repaired only by restoring the missing backslashes in eq:outer, eq:A0split (three occurrences) and eq:Wnet. The corrected displays were reread; the 955-line mathematical content is unchanged. No necessary mathematical or transcription correction remains. The final report includes the accurate alpha0 support inequality and complete-far baseline scope.

These 11 files are bound to their actual current bytes; audit.md and the future manifest are deliberately excluded.

| File | SHA256 |
|---|---|
| `auxiliary_budget.md` | `43d69846605553c69976b79a2edb34141fefdef0598340c72db18f0fb95b714c` |
| `joint_capacity.md` | `b7a1dc9550674638b6b21b3c29deb43b1f6b8bc894151f4546ecb04c1d4e86d5` |
| `log_budget_checks.json` | `063d59241173a7eff821462c6a9067b87598c7d4bacecbc5da116175c624ebfc` |
| `log_budget_checks.py` | `6d67bd1d18893150eb36cbb160e368ddf096a30aa790624c1c02f343691603f6` |
| `normalizer_log_budget.md` | `af5f161e7c2a07e05cdc77083e690b02202f75fe6f5d6acb1bd16fb59c68f395` |
| `numeric_notes.md` | `d732457943b63df6fac8649ca686a677caa7c8cb27e23d00fc589cda1992fc36` |
| `proof.tex.txt` | `2c1a8c02229bdf83956487fd1a025c9023a1fd9b8c7f2c3878d12985778a90a7` |
| `receiver_log_probe.md` | `b8d63ce290031ef207dabac98fd26990fe382d978b4af2402a43cff43b6b9d52` |
| `report.md` | `241f9cbdbc70cf41bdb7f1c497b7143c040a755709a867f36803e1fb70fd445a` |
| `reproduce.py` | `996b4eacb57692ae71941168d7b4c70e6929b19fabd8fbeae93fc3d91ce24fd0` |
| `task_contract.md` | `199ed05f94b735148c0207cd6d9baad4e3ee4becf7510cc66b111260bb5fcd09` |

Final status: accepted in exactly the scope in sections 7--12, frozen for parent archiving. The actual full far recovery is paid with its independent preallocated error slot, leaving the explicit original high-alpha0 signed baseline and original untouched blocks open. This auditor did not execute numerical scripts or the parent driver and did not compile a PDF. Parent manifest generation, full package replay and archive status are subsequent work, not certified here.
