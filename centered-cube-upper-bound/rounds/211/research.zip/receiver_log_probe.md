# R211 对数接收量的均值与波动接口（待审候选）

父级normalizer_log_budget给原持续恢复R<=log(1+G/(Teg))，且high与G<=Dq给R<=log(1+D p_y/(2KT))。正hard帽仅一次之后，实际receiver对象是p_y log(1+D p_y/(2KT))，而不是无p_y的log积分。D,T可能依真实行变化，不能无条件常数外提。

对任意概率P、实随机变量L且二阶矩有限，有
 E log(1+exp L)<=log2+E L_+
 <=log2+((E L)+sqrt((E L)^2+Var L))/2。
第二式来自L_+=(L+|L|)/2及Cauchy。尤其均值<=0时，右端<=log2+sqrt(Var L)/2；更一般粗式<=log2+(E L)_++sqrt(Var L)/2。

若固定真实参数下p_y(x)是归一张量密度，且L(x)=log(D p_y(x)/(2KT))，T,D在x积分之前固定，则L是坐标log-density之和加常数。坐标独立（仅在该核诱导概率下，不是原来源独立）给Var L为方差之和。只在均值不产生线性正项且总方差O(n polylog n)时，该固定核对数积分能给根阶。

此段为自包含条件接口，不是假设原自适应参数满足它。真正需要证明：原p的准确归一形式、log-density二阶矩与常数、T/D对接收点的依赖、原j/R/window选择器是否可在同一测度收费，以及均值的实际符号。原混合来源不能直接变成独立核概率；原receiver域可在固定非负核下扩大，但参数随x变化时不能偷换固定参数积分。不能将这段条件接口称作本轮全局闭合。
