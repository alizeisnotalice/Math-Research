#!/usr/bin/env python3
"""R211 exact finite clock diagnostics; not physical FIRST/high/history data."""
import argparse
from fractions import Fraction as F
from functools import lru_cache
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
ZERO = F(0)
ONE = F(1)

# Necessary small kernel copied from frozen R210 threshold_production_checks.py.
# R210 SHA: 208afddbed8f482cfbc6fcf459056c2e6d0b490e6675a97275c6da033791a764.
def atanh_log_interval(r, terms=40):
    assert 1 <= r <= 2
    z = (r-1)/(r+1)
    lo = 2*sum((z**(2*j+1)/F(2*j+1) for j in range(terms)), ZERO)
    tail = 2*z**(2*terms+1)/(F(2*terms+1)*(1-z*z))
    return lo, lo+tail

@lru_cache(None)
def rational_log_interval(x):
    assert x > 0
    k = x.numerator.bit_length()-x.denominator.bit_length()
    r = x/(F(2)**k)
    while r < 1:
        r *= 2
        k -= 1
    while r >= 2:
        r /= 2
        k += 1
    lo, hi = atanh_log_interval(r)
    l2, h2 = atanh_log_interval(F(2))
    return (lo+k*l2, hi+k*h2) if k >= 0 else (lo+k*h2, hi+k*l2)

def dot(a,b):
    return sum((x*y for x,y in zip(a,b)), ZERO)

def weights(beta,t):
    return [min(ONE,b/t) for b in beta]

def state(nu,a,k,j,c,gate):
    qj=dot(nu,j)
    capture=sum((nu[i]*min(a[i],k[i]) for i in gate), ZERO)
    h=c-capture
    assert qj > 0 and h >= 0 and dot(nu,k) <= c
    alpha=h/qj
    rho=[max(ZERO,1-(k[i]+alpha*j[i])/a[i]) if a[i] else ZERO for i in range(len(a))]
    return {'QJ':qj,'capture':capture,'H':h,'alpha':alpha,'rho':rho,'gate':sorted(gate)}

def logarithmic_comparison(actual, df, mass_bound, eg):
    if mass_bound == 0:
        assert actual == df == 0
        return {'zero_branch':True,'actual':actual,'DeltaF':df,'M':mass_bound,'log_interval':[ZERO,ZERO], 'linear':ZERO,'passed':True}
    arg=1+df/(mass_bound*eg)
    lo,hi=rational_log_interval(arg)
    lo*=mass_bound
    hi*=mass_bound
    linear=df/eg
    assert actual <= lo and hi <= linear
    return {'zero_branch':False,'actual':actual,'DeltaF':df,'M':mass_bound,'argument':arg,'log_interval':[lo,hi],'linear':linear,'passed':True}

def single_case(name,stage,nu,h,kind=0):
    beta=[ONE,F(2),F(1,2)]
    start=ONE; g=F(2); tcap=F(1,2)
    wl=weights(beta,start); wh=weights(beta,h); wg=weights(beta,g)
    a=[tcap*(x-y) for x,y in zip(wl,wh)]
    if kind in (1,2,3):
        if kind==1:
            k=[F(1,12),F(1,24),F(1,24)]; j=[F(1,24)]*3; c=F(1,6)
        elif kind==2:
            k=[F(1,12),ZERO,F(1,24)]; j=[F(1,24)]*3; c=F(1,8)
        else:
            k=[F(1,20),F(1,40),F(1,40)]; j=[F(1,48)]*3; c=F(1,10)
    else:
        k=[a[0]/2,a[0]/4,a[0]/4]; j=[a[0]/4]*3; c=dot(nu,k)
    s0=state(nu,a,k,j,c,{0})
    s1=state(nu,a,k,j,c,{0} if kind==4 else {0,2})
    assert s0['QJ']<=c
    zminus=F(1,2); zplus=F(1,3) if kind==3 else F(1,2)
    dr=s1['rho'][0]-s0['rho'][0]
    assert dr>=0
    m=zplus*dr
    eg=dot(nu,wg)
    ac=nu[0]+nu[2]/2
    # Exact integral Pi_v Pi_u dt/t, with complete e(t)=nu_u+ac/t.
    kernel=nu[0]*(1/(ac+nu[1])-1/(ac+nu[1]*h))
    actual=m*kernel
    df=m*nu[0]*(wl[0]-wh[0])
    gain=s0['H']-s1['H']
    assert tcap*df<=gain
    comparison=logarithmic_comparison(actual,df,m,eg)
    capture_bound=logarithmic_comparison(actual,gain/tcap,m,eg) if m else None
    # Exact denominator residual identity on the entire interval, with positive coefficients.
    residuals=[]
    for t in (start,(start+h)/2,h):
        residual=dot(nu,weights(beta,t))-eg-nu[0]*(1/t-1/h)
        independent=nu[0]*(1/h-1/g)+nu[2]*(1/(2*t)-1/(2*g))
        assert residual==independent and residual>=0
        residuals.append(residual)
    delta_a=zplus*s1['rho'][0]-zminus*s0['rho'][0]
    negative=(zminus-zplus)*s0['rho'][0]
    assert delta_a==m-negative
    return {'name':name,'stage':stage,'nu':nu,'beta':beta,'normalized_C':[b/2 for b in beta],
            'start':start,'h':h,'g':g,'Tcap':tcap,'w_start':wl,'w_h':wh,'w_g':wg,'e_g':eg,
            'a':a,'kappa':k,'J':j,'Dq':c,'minus':s0,'plus':s1,'persistent':[0],
            'zminus':zminus,'zplus':zplus,'Delta_rho':dr,'Gcap':gain,'exact_kernel':kernel,
            'restoration':comparison,'capture_relaxation':capture_bound,'denominator_residuals':residuals,
            'heavy_history_diagnostic':{'D':ONE,'sqrt_ell':ONE,'q':c,'T_e_g':tcap*eg,'gate_holds':tcap*eg>c,'conditional_R_le_D_over_sqrt_ell':actual<=1 if tcap*eg>c else None},
            'signed_Delta_A':delta_a,'denominator_negative':negative,'signed_net':delta_a*kernel,
            'entry_weighted_a_rho':nu[2]*a[2]*s1['rho'][2] if kind!=4 else ZERO,'passed':True}

def chain_case():
    nu=[ONE]*4; beta=[ONE,F(2),F(1,2),F(3,4)]
    start=ONE; h=F(3,2); g=F(2); tcap=F(1,2)
    wl=weights(beta,start); wh=weights(beta,h); wg=weights(beta,g)
    a=[tcap*(x-y) for x,y in zip(wl,wh)]
    k=[F(1,12),F(1,24),F(1,24),F(1,16)]; j=[F(1,24)]*4
    c=dot(nu,k); eg=dot(nu,wg)
    states=[state(nu,a,k,j,c,e) for e in ({0},{0,2},{0,2,3})]
    sets=[{0},{0,2}]; fs=[]; dfs=[]; actuals=[]; gains=[]
    ac=F(9,4)
    base=1/(ac+1)-1/(ac+h)
    for i,cs in enumerate(sets):
        assert cs<=set(states[i]['gate'])
        f=[(states[i+1]['rho'][v]-states[i]['rho'][v])/2 if v in cs else ZERO for v in range(4)]
        assert all(x>=0 for x in f)
        df=dot(nu,[f[v]*(wl[v]-wh[v]) for v in range(4)])
        gain=states[i]['H']-states[i+1]['H']
        assert tcap*df<=gain
        fs.append(f); dfs.append(df); gains.append(gain)
        actuals.append(base*dot(f,beta))
    fsum=[sum((f[v] for f in fs),ZERO) for v in range(4)]
    telescoped=[states[-1]['rho'][v]-states[0]['rho'][v] for v in range(4)]
    assert all(0<=fsum[v]<=telescoped[v]<=1 for v in range(4))
    df=sum(dfs,ZERO); gain=sum(gains,ZERO); actual=sum(actuals,ZERO)
    assert gain==states[0]['H']-states[-1]['H'] and df<=gain/tcap
    once=logarithmic_comparison(actual,df,ONE,eg)
    capture=logarithmic_comparison(actual,gain/tcap,ONE,eg)
    assert once['argument']<=capture['argument']
    gaparg=(1+dfs[0]/eg)*(1+dfs[1]/eg)/(1+df/eg)
    gap=rational_log_interval(gaparg)
    assert gaparg>1 and gap[0]>0
    # A sharper common-M version is licensed by the pointwise combined f, not summing step logs.
    sharp=logarithmic_comparison(actual,df,max(fsum),eg)
    return {'name':'two_step_shared_clock_different_persistent_sets','stage':'expanded_chain','nu':nu,
            'beta':beta,'a':a,'kappa':k,'J':j,'Dq':c,'Tcap':tcap,'start':start,'h':h,'g':g,
            'e_g':eg,'states':states,'persistent_sets':[sorted(x) for x in sets],'step_f':fs,
            'f_sum':fsum,'rho_total_increment':telescoped,'step_DeltaF':dfs,'step_Gcap':gains,
            'step_actual_restoration':actuals,'once_log':once,'capture_log':capture,'common_M_log':sharp,
            'sum_unit_step_logs_minus_once_log_argument':gaparg,'strict_positive_log_gap_interval':list(gap),
            'heavy_history_diagnostic':{'D':ONE,'sqrt_ell':ONE,'q':c,'T_e_g':tcap*eg,'gate_holds':tcap*eg>c,'conditional_R_le_D_over_sqrt_ell':actual<=1 if tcap*eg>c else None},
            'entry_costs_excluded':True,'passed':True}

def final_state_repair(row):
    # Reference algebra only: alpha0 is not an asserted empty-capture history.
    a=row['a']; k=row['kappa']; j=row['J']; nu=row['nu']; final=row['plus']
    qj=final['QJ']; alpha0=row['Dq']/qj; captured=final['capture']
    rho0=[max(ZERO,1-(k[v]+alpha0*j[v])/a[v]) if a[v] else ZERO for v in range(len(a))]
    delta=[final['rho'][v]-rho0[v] for v in range(len(a))]
    assert all(x>=0 for x in delta)
    active=final['gate']
    source_capacity=sum((nu[v]*a[v]*delta[v] for v in active),ZERO)
    assert source_capacity<=captured
    for v in active: assert a[v]*delta[v]<=j[v]*captured/qj
    # Existing original target v and its original Splus/zplus and exact posterior kernel.
    z=row['zplus']; original=z*final['rho'][0]; base=z*rho0[0]; repair=z*delta[0]
    assert original==base+repair
    actual=repair*row['exact_kernel']
    # Also retain the stronger actual target-loss log before using total capture.
    df=repair*nu[0]*(row['w_start'][0]-row['w_h'][0])
    assert row['Tcap']*df<=captured
    target_log=logarithmic_comparison(actual,df,repair,row['e_g'])
    argument=1+captured/(row['Tcap']*row['e_g'])
    lo,hi=rational_log_interval(argument); linear=captured/(row['Tcap']*row['e_g'])
    assert actual<=lo and hi<=linear
    heavy=row['heavy_history_diagnostic']['gate_holds']
    if heavy: assert linear<=1 and actual<=1
    return {'scope':'Reference alpha0 algebra in the unchanged final state; no empty-capture history asserted. Actual repair flow uses original target v; full final capture capacity retained.',
            'alpha0':alpha0,'rho0':rho0,'Delta_rho':delta,'final_capture_U':captured,'full_final_E_source_capacity':source_capacity,
            'original_A':original,'baseline_A0':base,'repair_A':repair,'actual_repair_flow':actual,'actual_target_log':target_log,
            'total_capture_log_argument':argument,'total_capture_log_interval':[lo,hi],'total_capture_linear':linear,
            'heavy_gate_unchanged':heavy,'conditional_repair_le_one':actual<=1 if heavy else None,'passed':True}

def field_sup_cases():
    rows=[]
    nu=[ONE]*4; beta=[ONE,F(3,4),F(2),F(1,2)]
    wl=weights(beta,ONE); wh=weights(beta,F(3,2)); wg=weights(beta,F(2))
    a=[F(1,2)*(x-y) for x,y in zip(wl,wh)]
    j=[F(1,48),F(1,48),F(1,96),F(1,96)]
    eg=dot(nu,wg); p=F(1,120); gamma=F(2)
    for idx,(stage,name) in enumerate((('initial','field_active'),('stress','field_inactive'),('expanded','field_denominator_growth'))):
        k=[F(1,12),F(1,8) if idx==1 else F(1,16),F(1,48),F(1,24)]
        c=F(13,48) if idx==1 else F(5,24)
        minus=state(nu,a,k,j,c,{0,1}); plus=state(nu,a,k,j,c,{0,1,3})
        da=minus['alpha']-plus['alpha']; gain=minus['H']-plus['H']
        assert minus['alpha']==1 and plus['alpha']==F(1,3) and gain==F(1,24)
        slots=[]; response_total=ZERO; net_total=ZERO; actual_net_total=ZERO; xs=[]; ys=[]; rs=[]
        for v in (0,1):
            jm=j[v]; sm=2*jm
            post=2*jm if idx==2 and v==0 else jm/2
            postplus=jm if idx==2 and v==0 else jm/2
            sp=jm+post+postplus
            floor=max(sm,jm+(1+1/gamma)*post)
            m=max(floor,3*p*wg[v])
            assert postplus>=post/gamma and sm>=3*p*wg[v] and sp>=3*p*wg[v] and m==floor
            bm=max(ZERO,a[v]-k[v]-minus['alpha']*jm)
            bp=max(ZERO,a[v]-k[v]-plus['alpha']*jm)
            response=a[v]*(plus['rho'][v]-minus['rho'][v])
            assert response==bp-bm==min(da*jm,bp)
            # Independent exact activity-layer integral, splitting at the positive-part threshold.
            cuts=sorted(set([plus['alpha'],minus['alpha']]+[t for t in [(a[v]-k[v])/jm] if plus['alpha']<t<minus['alpha']]))
            layer=sum((jm*(hi-lo) for lo,hi in zip(cuts,cuts[1:]) if a[v]-k[v]>jm*(lo+hi)/2),ZERO)
            assert layer==response
            bound=jm*response/m
            net=max(ZERO,jm*bp/m-jm*bm/sm)
            samples=[]
            for denominator in (m,F(3,2)*m,2*m):
                actual=jm*response/denominator
                signed=jm*bp/denominator-jm*bm/sm
                assert actual<=bound and max(ZERO,signed)<=net
                samples.append({'Splus':denominator,'response':actual,'signed_net':signed,'positive_net':max(ZERO,signed)})
            assert samples[0]['response']==bound and samples[0]['positive_net']==net
            if response>0: assert samples[0]['response']>samples[1]['response']>samples[2]['response']
            actual_signed=jm*bp/sp-jm*bm/sm
            assert sp==m
            no_net=m*bm>=sm*bp
            assert no_net==(actual_signed<=0)
            x=p*jm/floor; y=jm/(3*wg[v])
            assert x<=y and p*jm/m==min(x,y)
            response_total+=bound; net_total+=net; actual_net_total+=actual_signed
            xs.append(x); ys.append(y); rs.append(response)
            slots.append({'v':v,'a':a[v],'J':jm,'R':response,'activity_integral':layer,'bminus':bm,'bplus':bp,'Sminus':sm,'post_current':post,'post_plus':postplus,'Splus':sp,'Ffloor':floor,'m':m,'response_sup':bound,'net_positive_sup':net,'actual_signed_net':actual_signed,'no_positive_net_criterion':no_net,'samples':samples})
        u0=dot(rs,xs); u1=dot(rs,ys); joint=sum((r*min(x,y) for r,x,y in zip(rs,xs,ys)),ZERO)
        saving=min(u0,u1)-joint
        cross=min(sum((r*max(ZERO,x-y) for r,x,y in zip(rs,xs,ys)),ZERO),sum((r*max(ZERO,y-x) for r,x,y in zip(rs,xs,ys)),ZERO))
        assert saving==cross==0
        expected=[(F(1,72),F(1,72)),(F(1,144),F(1,144)),(F(1,96),F(1,144))][idx]
        assert (response_total,net_total)==expected
        if idx==2: assert slots[0]['actual_signed_net']==F(-7,576)
        # Equal alpha gives zero response; a=0 and J=0 scalar auxiliaries are dispatched without division.
        assert all(a[v]*(minus['rho'][v]-minus['rho'][v])==0 for v in (0,1)) and a[2]==0
        jzero_response=max(ZERO,a[0]-k[0]-plus['alpha']*ZERO)-max(ZERO,a[0]-k[0]-minus['alpha']*ZERO)
        azero_response=max(ZERO,a[2]-k[2]-plus['alpha']*j[2])-max(ZERO,a[2]-k[2]-minus['alpha']*j[2])
        assert jzero_response==azero_response==0
        rows.append({'name':name,'stage':stage,'nu':nu,'beta':beta,'a':a,'w_g':wg,'e_g':eg,'J':j,'kappa':k,'Dq':c,'minus':minus,'plus':plus,'p':p,'K':ONE,'gamma':gamma,'slots':slots,'response_sup_total':response_total,'net_positive_sup_total':net_total,'actual_signed_net_total':actual_net_total,'old_good_cross_min_saving':saving,'high_holds':p*eg>=2*c,'zero_auxiliaries':{'equal_alpha_response':ZERO,'a_zero_response':azero_response,'J_zero_response':jzero_response},'scope':'Conditional clock/capture and postgood fields; high fails; no shared spatial kernel realization.','passed':True})
    assert all(not row['high_holds'] for row in rows)
    # Separate unconstrained arithmetic calibration, never registered as old-good improvement.
    x=[ONE,F(4)]; y=[F(3),ONE]; r=[ONE,ONE]
    joint=sum((rv*min(xv,yv) for rv,xv,yv in zip(r,x,y)),ZERO)
    saving=min(dot(r,x),dot(r,y))-joint
    assert saving==2
    return rows,{'scope':'Pure cross-min algebra only; not old-good fields','R':r,'X':x,'Y':y,'joint':joint,'saving':saving,'passed':True}

def d_calibrations():
    rows=[]
    for r in (F(1),F(10),F(100)):
        eps=ONE; lam=ONE
        d=max(ONE,eps*r/(8*lam)-16/(3*r))
        left=8*lam*d/r; right=max(8*lam/r,eps)
        assert left<=right
        rows.append({'sqrt_ell':r,'epsilon_RC':eps,'Lambda':lam,'D':d,'left':left,'right':right,'passed':True})
    return rows

def encode(x):
    if isinstance(x,F): return str(x)
    if isinstance(x,dict): return {k:encode(v) for k,v in x.items()}
    if isinstance(x,(list,tuple)): return [encode(v) for v in x]
    return x

def main():
    parser=argparse.ArgumentParser(); parser.add_argument('--output',type=Path,default=HERE/'log_budget_checks.json'); parser.add_argument('--initial-only',action='store_true')
    args=parser.parse_args()
    cases=[single_case('R210_original_positive_alpha','initial',[ONE]*3,F(3,2),1),
           single_case('R210_alpha_plus_zero','initial',[ONE]*3,F(3,2),2),
           single_case('R210_denominator_negative','initial',[ONE]*3,F(5,4),3)]
    for row in cases: row['final_state_repair']=final_state_repair(row)
    chain=[]
    if not args.initial_only:
        cases += [single_case('target_dominant','stress',[F(2**20),ONE,F(1,2)],F(3,2)),
                  single_case('bad_dominant','stress',[ONE,F(2**20),F(1,2)],F(3,2)),
                  single_case('zero_capture_change','stress',[ONE]*3,F(3,2),4),
                  single_case('near_start','expanded',[ONE,ONE,F(1,2)],F(1001,1000)),
                  single_case('completion_dominant_near_future','expanded',[ONE,ONE,F(2**20)],F(1999,1000)),
                  single_case('rare_target','expanded',[F(1,2**40),ONE,F(1,2**20)],F(7,4))]
        chain=[chain_case()]
    result={'schema':'R211-exact-clock-log-budget-v1','arithmetic':'stdlib Fraction; directed rational log enclosure, 40 atanh terms plus explicit remainder',
            'scope':'Finite conditional min-product clock/capture arrays. Full source normalization retained. No common spatial kernel, receiver dx, original high/postgood/FIRST/history or global theorem certification.',
            'local_inputs':{'task_contract.md':hashlib.sha256((HERE/'task_contract.md').read_bytes()).hexdigest()},
            'log_kernel_provenance':{'source':'R210 threshold_production_checks.py','sha256':'208afddbed8f482cfbc6fcf459056c2e6d0b490e6675a97275c6da033791a764'},
            'counts':{'single_cases':len(cases),'chain_cases':len(chain),'field_sup_cases':0 if args.initial_only else 3},'single_cases':cases,'chain_cases':chain,'D_calibrations':d_calibrations(),'all_passed':True}
    if not args.initial_only:
        result['field_sup_cases'],result['cross_min_calibration']=field_sup_cases()
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(encode(result),sort_keys=True,indent=2)+'\n')
    print(json.dumps(result['counts'],sort_keys=True)+' PASS')

if __name__=='__main__': main()
