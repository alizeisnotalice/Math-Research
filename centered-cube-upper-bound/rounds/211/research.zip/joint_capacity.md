# R211：原重门下持续捕获恢复的共同来源预算

状态：本稿将 R210 CT9–10/CT16 的真实持续恢复重新接回原未放松的重门和 RT1 外测度，得到一次独立的 `epsilon_rec X+C_epsilon sqrt(n)W_A` 预算。它支付共同背景下的持续捕获增量或同钟嵌套有限链，不支付 signed 基线、target 新入口、clock/几何变化、capture 重充或其它 share。此前 CT14 逆终端权列并非这一增量必须经过的步骤。这里没有宣称一般中心立方体目标已经闭合。

## 1. 实际窄读的来源和继承条件

本稿实际读取：

1. R210 冻结 `capture_threshold_budget.md` CT1–17，特别 CT9–10、CT12–17；原持续恢复、同源捕获增益、完整双后验和外测度均沿用它。
2. R128 `/Users/zhengzhihao/Desktop/T/output/centered_cube_round128_20261014/proof.md` RT1–6，约610–667行：原完整历史、原 `T_small<=4X`、核尺度、capture 和 FIRST；`X` 保持该来源预算中的原定义，不另行认作所有接收域上的 `int q dx`。
3. R122 `/Users/zhengzhihao/Desktop/T/output/centered_cube_round122_20261014/proof.md` UP1、UP9–10（约49–165行）及约262–273行的独审段：相同完整 RT1 外测度保留原实际重门
\[
 e_g>\ell q c_j^{-n/2}g^n,\qquad \ell=1+\log n.
\tag{JC1}
\]
UP9–10 已在原完整来源与 far FTC 中使用它，而非对任意抽象概率额外假设。
4. R125 `/Users/zhengzhihao/Desktop/T/output/centered_cube_round125_20261014/proof.md` AC1–8（约70–125行）：原预先固定捕获倍数、同一重门、`T_small<=4X` 与有限维母核补齐。

下文仅对保留 JC1 的这一原历史块成立。若另行正放成只剩 `p_y e_g>=2Kq` 的抽象输入，不能从该较弱条件反推 JC1；这样的放松模型不获本稿结论。相反，在原 RT1 历史未删除 JC1 时，不能因为简写合同只列 high 而把它遗忘。

原共同参数为
\[
 T=\frac{c_j^{n/2}}{g^n\sqrt\ell},\qquad
 \mathsf D=\max\left\{1,
 \frac{\epsilon_{RC}\sqrt\ell}{8\Lambda}
 -\frac{16}{3\sqrt\ell}\right\},\quad
 0<\epsilon_{RC}\le1,\quad\Lambda=128/119.
\tag{JC2}
\]
`epsilon_RC` 在构造之前固定，不能在看到一条行后重选。特别 `mathsf D` 不是任意未计费的绝对常数。JC1 精确给
\[
 T e_g>\sqrt\ell\,q.
\tag{JC3}
\]
这正是 R125 AC5 使用的尺度抵消；不需任何 `nu(V)` 体积帽，也不需 `nu<=beta`。

## 2. 同一原测度上的持续恢复

固定一个原合法窗口及完整行 `(omega,V,j,x,y,硬源z,history)`。两个状态共享 `nu,J,K0,Dq,T,tau,h,g,w_t,Z_t,Pi_t`、所讨论的原外测度和共同资格门。原 capture 迹嵌套 `E_- subset E_+`，且
\[
 a_v=T(w_\tau(v)-w_h(v)),\quad k_v=\mathsf D K_{0v},\quad
 H_\pm=\mathsf Dq-\int1_{E_\pm}\min(a,k)d\nu
 =\alpha_\pm Q_J,
\]
\[
 G_{cap}=H_--H_+=Q_J(\alpha_--\alpha_+)\ge0,
 \qquad 0\le G_{cap}\le H_-\le\mathsf Dq.
\tag{JC4}
\]
所有 alpha 来自同一个真实来源积分，不是逐 target 自由变量。持续集合 `C subset G cap E_- cap{a>0}` 位于原终端 `Z_g`。原 target 分母 `S_+>=S_->=J>0`，`z_+=J/S_+`，`rho_±=(1-k/a-alpha_±J/a)_+`。零 `a,e_g,Q_J`、空 far 窗按 CT 原约定先隔离。

原正恢复是
\[
 R_{per}=\int_{J_{far}}\int_{C\times B}
 \Psi h_{gate}z_v^+(\rho_v^+-\rho_v^-)
 (k_t(v)-k_t(u))_+\,d\Pi_t(v)d\Pi_t(u)\frac{dt}{t}.
\tag{JC5}
\]
这里 `k_v=mathsf D K0v` 是 capture 核，`k_t(v)` 是时间 score；两者不能混用。原 bad 后验仍完整，先用其概率质量不超过1，target 仍保一份 `1/e_t`。CT 的非负 far FTC 及原 `a=T Delta` 已严格证明
\[
 R_{per}\le\frac1{T e_g}\int_Cz_v^+a_v\Delta\rho_v\,d\nu(v)
 \le\frac{G_{cap}}{T e_g}.
\tag{JC6}
\]
将 JC3–4 代入，获得无需 postgood 逆权放松的真实行界
\[
 \boxed{R_{per}\le\frac{G_{cap}}{T e_g}
 \le\frac{G_{cap}}{q\sqrt\ell}\le\frac{\mathsf D}{\sqrt\ell}.}
\tag{JC7}
\]
捕获增益的完整空间信息可保在中间式 `G_cap/q`；此处的最后一步是同一来源 reserve 容量上放，不是来源概率归一。既不需要提出 `p_y`，也不需要给 `J^2/w_g` 一个独立列帽。

共同背景下实际持续 signed 变化为 `R_per-N_S`，其中 CT8 的真实分母负项 `N_S>=0` 原位保留。JC7 仅上放其正恢复，不借用或重复扣除原 `N_del,N_Zc`。

## 3. 完整原外积分：不先取 hard 帽

原共同外测度为
\[
 d\mathcal T_I=1_I1_{j(x)=j}q^{-1}p_yh_R(x-z)a_\omega
 \,dx\,\beta_V(dy)\nu_V(dz).
\tag{JC8}
\]
其全部真实历史、来源标签、hard 源 z、high 门和期望/V/j 求和保留。令原 `T_small` 表示所用完整非负外测度预算，已有
\[
 \mathbb E\sum_{V,j}\int1_{high}\,d\mathcal T_I
 \le T_{small}\le4X.
\tag{JC9}
\]
对 JC7 逐行积分，因此
\[
\begin{split}
 \Delta Raw_{J,per}
 &=2\Lambda\mathbb E\sum_{V,j}\int1_{high}
 (R_{per}-N_S)\,d\mathcal T_I\\
 &\le\frac{2\Lambda\mathsf D}{\sqrt\ell}T_{small}
 \le\boxed{\frac{8\Lambda\mathsf D}{\sqrt\ell}X.}
\end{split}
\tag{JC10}
\]
这是在原 positive recovery 上取上界，没有分别对两个完整 signed raw 取帽后相减。没有再使用 `16/3` hard 帽；故不能把 CT12 的 `32Lambda/3` 又乘进来。原 `p_y beta/e_g` 问题由共同重门先给统一行价而避免，不是声称其无权 high 列免费支付。

唯一 j 及全部原 time/window 费用已经包含在 JC9；没有先删掉唯一 j 再逐项复制 `4X`。若项目另有独立窗口块，则使用其原外测度合账或逐块保 `X_w`，不能对每个窗口免费复用一个 X。

## 4. 独立恢复误差槽与有限维补齐

预先给定新的 `0<epsilon_rec<=1`，并在整套构造开始时选择 `epsilon_RC<=epsilon_rec`。若旧构造已经固定更大的 epsilon_RC，则本节不能事后无代价降低它；此时仍只有 JC10 的实际系数。

由 JC2，
\[
 \frac{8\Lambda\mathsf D}{\sqrt\ell}
 =\max\left\{\frac{8\Lambda}{\sqrt\ell},
 \epsilon_{RC}-\frac{128\Lambda}{3\ell}\right\}
 \le\max\left\{\frac{8\Lambda}{\sqrt\ell},\epsilon_{RC}\right\}.
\tag{JC11}
\]
取
\[
 N_{rec}=\left\lceil\exp\left[(8\Lambda/\epsilon_{rec})^2-1\right]\right\rceil.
\tag{JC12}
\]
n>=N_rec 时，JC10 给 `Delta Raw_J,per<=epsilon_rec X`。

更精确地，若 `mathsf D>1`，JC11 的第二支直接等于 `epsilon_RC-128Lambda/(3ell)<epsilon_rec`，已经吸收，无需有限维回退。尚未直接吸收的分支必有
\[
 \mathsf D=1,\qquad R_{tot}\le1/\sqrt\ell\le1.
\tag{JC13}
\]
因此在这个 fallback 分支，该辅助恢复的行密度不超过1，可用同一母核外测度界，不必声称它是原 signed 基线的一项不交子交通。此处用的是 JC7/JC16 和真实 D 值，不是从合并目标 f_sum<=1 直接推断时间交通<=1。R122 UP7–10/R125 AC 的有限维回退为
\[
 T_{small}\le\frac{16}{3}2^n D_n^{old}W_\beta,
 \qquad D_n^{old}\le1+\frac\pi2\sqrt n,
 \qquad W_\beta\le W_A.
\tag{JC14}
\]
因此在 n<N_rec 的有限范围，
\[
 \Delta Raw_{J,per}
 \le \frac{32\Lambda}{3}(1+\pi/2)2^{N_{rec}}
 \sqrt n\,W_A.
\]
两支合并得到
\[
 \boxed{\Delta Raw_{J,per}
 \le\epsilon_{rec}X+C_{rec}(\epsilon_{rec})\sqrt n\,W_A,\qquad
 C_{rec}=\frac{32\Lambda}{3}(1+\pi/2)2^{N_{rec}}.}
\tag{JC15}
\]
这是显式但极大的常数，只依预先分配的恢复误差。来源修复仅用共同父预算 `W_beta<=W_A`，没有 `nu<=beta`。此处保持原 X；若要换成某种 `E int q dx`，必须另核原 X 的定义及已证比较。

旧 R125 AC 已经使用过的 epsilon 槽仍属于其原捕获项。JC15 是持续恢复的新独立槽，不能将旧付款再次宣称可用。若最终总误差为 epsilon，可在构造之前将其拆为旧捕获、持续恢复及其他必要项的预算，并同步选定 epsilon_RC；本文不自行重排已冻结其他证明的错误预算。

## 5. 同钟链没有额外层数费；其它变化没有被支付

对有限 nested capture 链，若完整 `nu,w,Z,Pi,T,tau,h,g,a,k,J,Dq` 及原外测度共同，实际 `H_0>=...>=H_m>=0`，每步持续集合 C_i 可不同，但均位于同一终端 Z_g。CT16 给
\[
 \sum_iR_{per,i}\le\frac{H_0-H_m}{T e_g}
 \le\frac{\mathsf D}{\sqrt\ell}.
\tag{JC16}
\]
所以 JC10–15 一次支付整条这样的链，不按层或 target 数重复领取储备。也可使用本轮父稿 `normalizer_log_budget.md` 的先合并目标、再归一化对数改进；JC16 的预算不依赖另一次 log 论证。

下列项仍完整保留：新的 capture/active target 入口；clock、T、K0、a、J、g、Pi、来源或原外测度变化；非嵌套 capture recharge；S 分母外的其它门交换；原 baseline cut 不足及所有未分配 share。特别当 `1/(T_i e_gi)` 随步变化时，CT17 的实际加权正变差不能由 JC16 删除。只在各共同块分别得到 JC16 也不自动控制块数。

## 6. 检查点：对数核均值与方差，不把固定参数冒作选择器预算

在发现 JC1 的实际继承前，本稿筛查过父归一化对数界。以下保留一项准确核计算，作为不同于 JC15 的工具；它不被用于主付款。

固定同一 receiver 积分之前的全部参数 `s,L,g,cj,D`，令
\[
 p_y(x)=L^{-n}\prod_i f_s((x_i-y_i)/L),\quad
 f_s=(1-s)h+s\varphi,\quad
 \mu_s=\int f_s\log f_s,\quad V_s=\operatorname{Var}_{f_s}(\log f_s).
\]
令
\[
 M=\log\frac{\mathsf D\sqrt\ell}{2K}
 +n\log\frac{g}{\sqrt{c_j}L}+n\mu_s.
\tag{JC17}
\]
在归一 p_y 核测度下，`log(D p_y/(2KT))` 的均值恰为 M、方差为 nV_s。由 `log(1+exp z)<=log2+z_+` 及中心变量正负均值相等，
\[
 \int p_y\log\left(1+\frac{\mathsf Dp_y}{2KT}\right)dx
 \le\log2+M_++\tfrac12\sqrt{nV_s}.
\tag{JC18}
\]
坐标独立只用于这个真实乘积核诱导的 x 概率计算，不是对原 beta/nu 来源作独立假设。

有统一安全界 `V_s<45`，包括 s=0 的零密度约定。证明：`0<=f_s<=1`；原 `w(r)>=.5 exp(-2|r|)` 给
`phi(x)>=.5 exp(-1-2|x|)`，故 `-log phi(x)<=2+2|x|`。在 hard 核心 `|x|<=.5`，`f_s>=phi`，所以 `int_core f_s(log f_s)^2<=9`。核心外 `f_s=s phi`，因此
\[
 \int_{core^c} f_s(\log f_s)^2
 \le2s(\log s)^2+2s\int\varphi(\log\varphi)^2
 \le\frac8{e^2}+2\left(8+8\frac{13}{12}\right).
\]
这里 `int x²phi=13/12`；合并上界为 `9+8/e²+100/3<45`。没有采用错误的 `phi(0)<=1/2`。

原比例带给 `g/L<=gamma/cj`。更具体，L>=R 时 `g/L=R/g<=cj`，JC17 的几何项非正；L<R 时
\[
 1/c_j\le g/L\le\gamma/c_j,
\]
因而必须保留约 `-(3/2)n log cj` 的正几何项。是否有实际 capture 抑制这一均值，不能仅从固定参数平均推出。若先保捕获增益比例 `vartheta=G_cap/(Dq)`，对数内有额外乘子 vartheta，固定 vartheta 才可在 JC17 加 `log vartheta`；原 vartheta(x,y) 随真实空间变化，不能直接作为固定核常数。

JC18 不授权对实际 x-adaptive s,L,R,g 应用固定核积分，更不免除 soft/scale 包络费。在原持续恢复上，主证明选择 JC3–15 的实际重门预算，因而不必为这一辅助对数核强行购买新的选择器上确界。

## 7. 精确结论

本稿的实质预算是 JC15–16：保留原 heavy 历史后，同源 capture 的总恢复量通过真实 far FTC 与 `T e_g>sqrt(ell)q` 直接结算，免去 CT14 中由先用 postgood 产生的逆 `w_g` 列。该结果只作用于已经严格定义的持续增量及其同钟嵌套链，且只领取一次独立恢复误差额度。

一般目标的第一处剩余不是这条共同背景恢复链，而是实际原流程将多少个这样的块连接起来时出现的新 target 入口、几何/clock 交换和 recharge，以及原 signed 基线本身。没有证明这些变化可由同一有限储备一次覆盖，故不称一般弱型目标闭合。

## 8. 升级：在每个实际最终行上拆出初始 alpha 基线

本节不比较两段可实现的 capture 历史，而在**同一个实际最终行**上作 target 权的代数分解。因此它不要求存在 `E_empty` 的合法实际历史，也不要求原 target 曾在某个较早状态持续存活。第2–5节的两态条件仍适用于其原解释，本节给出更直接、覆盖当前全部实际 target 的应用。

### 8.1 原 RC 身份与零支

实际窄读 R127 `/Users/zhengzhihao/Desktop/T/output/centered_cube_round127_20261014/proof.md` SP4 后第294行及 GB12（约702–714行）：
\[
 E=S_g\cap\{B_{hard}=0,\ \Delta>0\},\quad
 U=1_E\min(a,\kappa),\quad a=T\Delta,\quad\kappa=\mathsf D K_0,
\]
\[
 Q=\int Jd\nu>0,\qquad G_U=\int U d\nu,\qquad
 \alpha=(\mathsf Dq-G_U)/Q.
\tag{JC19}
\]
在 E 上，真实 `b_rec=min(1,(U+alpha J)/a)`；E 外按原约定保持旧 `b_D`，而实际 target 的 hardB1 或 Delta0 部分余权为零。因而 E 内若 `a<=kappa`，rho 为零；若 `a>kappa`，U=kappa。因此全部实际正 target 的原余权可准确写成
\[
 \rho=(1-\kappa/a-\alpha J/a)_+\quad\text{于 }E,
\tag{JC20}
\]
而 a0 target 先取零。这里不是以任意更小权重替代真实 RC，也没有遗失 U。

FIRST 给 `G_U<=int kappa dnu<=mathsf Dq`，故 `0<=alpha`。定义只用于记账的共同基线系数
\[
 \alpha_0=\mathsf Dq/Q,\qquad
 \alpha_0-\alpha=G_U/Q\ge0.
\tag{JC21}
\]
在**同一个实际 E** 上置
\[
 \rho_0=(1-\kappa/a-\alpha_0J/a)_+,\qquad
 \delta\rho=\rho-\rho_0\ge0.
\]
函数 `x_+` 的单调 Lipschitz 性逐 target 给
\[
 0\le a\delta\rho\le(\alpha_0-\alpha)J=(G_U/Q)J.
\tag{JC22}
\]
如果 G_U=0，则全部恢复为零。alpha=0 正常包含，不除 alpha。Q0、e_g0、a0及空 far 行先按原约定隔离；不形成0乘无穷。

### 8.2 原 signed 交通的准确拆分

保实际终端 `G=S_g,B=D_g`、完整 `Pi_t`、全部 Psi/FA/history/high/far 和当前 selector。即使某个实际门由原 rho 决定，它也保持原值，不代入 rho0 重算。原 J 权与基线权定义为
\[
 A=1_E z\rho,\qquad A_0=1_E z\rho_0,\qquad
 z=J/S,\qquad A=A_0+1_Ez\delta\rho.
\tag{JC23}
\]
原 E 已包含于 G；所有权在该实际行的辅助时间中固定。A0 只是同一原积分中的非负较小系数，不用于重算 capture、alpha、E、good/bad 或来源，也不声称它定义另一条完整合法历史。

用 `mathcal S_J(A)` 表示按本项目原账给 J-share 分配、且尚可使用的同一负项余额下的 signed 行泛函。已经被其它步骤消费的部分不重新加入。其正项线性依 A，而原存活负项和删除负项均不依 A。因此精确有
\[
 \mathcal S_J(A)=\mathcal S_J(A_0)+R_U,
\]
\[
 R_U=\int_{J_{far}}\int_{E\times B}
 \Psi\chi_{FA}\,z_v\delta\rho_v
 (k_t(v)-k_t(u))_+\,d\Pi_t(v)d\Pi_t(u)\frac{dt}{t}\ge0.
\tag{JC24}
\]
所有原负信用只留在 `mathcal S_J(A0)` 一份，恢复 R_U 不另领任何负项。若其它 share 尚未支付，它们也原位保留，不能再次领取本节基线所含的同一负余额。

因为 E target 属于真实终端 Z_g，沿整个实际 far 段存活，CT 的同一未归一 FTC 可直接重用：
\[
 R_U\le\frac1{T e_g}\int_E za\delta\rho\,d\nu
 \le\frac{G_U}{T e_g Q}\int_EzJ\,d\nu
 \le\frac{G_U}{T e_g}
 \le\frac{\mathsf D}{\sqrt\ell}.
\tag{JC25}
\]
每一步都在原测度进行；第一步保留两份 e 后先用实际 bad 后验概率质量不超过1，另一份用 `e_t>=e_g`，再积分 `k_t(v)w_t(v)`。没有省掉倒 a 后独立估计时间，也未加入新的 postgood 帽。

### 8.3 对当前实际 J 余项的有价替换

令 `Raw_J(A0)` 为同一原 RT1 外积分、同一实际全部门与唯一 j、同一已分配负项下的基线泛函。JC24逐原行积分及第3–4节完全相同的预算给
\[
 \boxed{Raw_J(A)\le Raw_J(A_0)
       +\epsilon_{rec}X+C_{rec}(\epsilon_{rec})\sqrt n\,W_A.}
\tag{JC26}
\]
前提仍是预先的参数分配 `epsilon_RC<=epsilon_rec`；若未作该分配，准确恢复系数为 JC10，不擅自改原构造。该恢复额度和 JC15 是**同一恢复预算的两种应用**，不能对同一交通将它们相加收费。JC26 不依赖 E_empty 是否可实现，也没有所谓新 target 入口需从一个不存在的早期历史搬入：它直接在最终实际 E 上同时拆分所有 target。

这使当前实际问题可转为高初始系数的基线。由同一合法 J 的 FIRST `Q<=q`，
\[
 \alpha_0\ge\mathsf D,\qquad
 A_0(v)>0\Longrightarrow
 T\Delta_v>\mathsf D K_{0v}+\frac{\mathsf Dq}{Q}J_v
 \ge\mathsf D(K_{0v}+J_v).
\tag{JC27}
\]
本稿没有证明这一基线的根阶来源或可吸收接收预算。JC27 是下一步必须与原空间核/实际后验和负项联合处理的准确高阈值支持，而不是已经付过的 source tail。

第5节的入口/变钟/recharge 限制仍适用于沿实际状态路径累计两态差分；JC26 绕开了对整个最终 target 集合构造虚拟捕获历史的要求，但没有支付原 signed 基线，更没有提供随意改变 clock/来源/外测度后的路径总变差界。

## 9. 同一份额度覆盖 RT2 完整 far 余权，不按 share 重付

原 R128 RT2 的完整 far 正余项系数是 rho，并非必须先乘 J/S。因此第8节可取 `z=1`，直接在**同一剩余实际积分域**上使用；此前已经支付并删去的正子集保持删去，不因本节恢复。

记该 RT2 正泛函为 `mathfrak P_rem(rho)`，只在它的原实际 target 上代入 JC21 的 rho0，保原 Psi、chi_FA、原 history/high、bad 槽、posterior、硬源和全部 selector。它们即使依原 rho 而确定也不重算。线性拆分精确给
\[
 \mathfrak P_{rem}(\rho)
 =\mathfrak P_{rem}(\rho_0)+\mathfrak P_{repair},
\]
\[
 P_{repair}(r)=\int_{J_{far}}\int_{E\times B}
 H_{rem}(r,t,v,u)\,\delta\rho_v
 (k_t(v)-k_t(u))_+\,d\Pi_t(v)d\Pi_t(u)\frac{dt}{t},
 \quad0\le H_{rem}\le1.
\tag{JC28}
\]
`H_rem` 含原全部正门与已支付子集的剩余指示，仅以此符号收集已有实际因子，不添加独立性或新资格。

同一 far FTC、同源 JC22 和重门直接证明
\[
 P_{repair}(r)\le\frac1{T e_g}\int_E a\delta\rho\,d\nu
 \le\frac{G_U}{T e_g}\le\frac{\mathsf D}{\sqrt\ell}.
\tag{JC29}
\]
因此，以 `mathfrak N_avail` 表示原账当前尚可用并已归属该完整 far 余项的负余额，
\[
\begin{split}
 2\Lambda\{\mathfrak P_{rem}(\rho)-\mathfrak N_{avail}\}
 &\le2\Lambda\{\mathfrak P_{rem}(\rho_0)-\mathfrak N_{avail}\}\\
 &\quad+\epsilon_{rec}X+C_{rec}(\epsilon_{rec})\sqrt n\,W_A.
\end{split}
\tag{JC30}
\]
原负余额仅在右侧 baseline 中出现一次；已经消费的负项不重新加入。JC30 是 JC15 同一误差额度的更完整应用，J-share 的 JC26 可作为其限制使用，不能再按 K1/K2/J 各 share 分别重复领取恢复额度。

“完整”在此仅指 R128 RT2 当前剩余的 **far RC 正余项**。它不覆盖此前 near、其它分解块或新窗口，也不宣称右侧高初始 alpha baseline 已付。JC27 的实际空间支持及原负余额仍是该 baseline 的下一步任务。
