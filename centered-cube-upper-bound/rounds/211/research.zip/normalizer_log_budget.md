# R211 保留持续目标归一化的对数恢复界（候审）

共同原行与持续终端集合C沿用R210。令f(v)=zplus(v)Delta rho(v)>=0，在辅助时间t不变，0<=f<=M<=1。令F(t)=int_C f(v)w_t(v)nu(dv)，DeltaF=F(tau)-F(h)，g>=h>=tau。假定C包含于Z_g且实际存活集随时间递减，时钟w非增。原目标恢复的正门不超过1，原bad与C互斥，但下面只使用Pi(B)<=1以及(kv-ku)+<=kv。

M=0时恢复为0。否则对tau<=t<=h，所有终端来源在Z_t，故
 e_t>=e_g+int_C(w_t-w_g)nu>=e_g+int_C(w_t-w_h)nu>=e_g+(F(t)-F(h))/M。
实际原far子域的恢复因此满足
 Rper<=int_far (-F'(t))/e_t dt
 <=int_tau^h (-F'(t))/(e_g+(F(t)-F(h))/M) dt
 =M log(1+DeltaF/(M e_g))。

这里F'对普通t求导，-F'=int_C f k_t w_t nu/t；不能额外漏乘或重复dt/t。第二行使用显式正分母及非负未归一导数扩大积分，不要求在扩展域重建原history门或原Pi。恒等式先有限源/有限量，再对实际非负来源截断处理；若需一般无限来源，须核验e_g和F的有限性/绝对连续与极限，不能先形式相减无穷量。

同一clock的a=T(w_tau-w_h)，DeltaF=(1/T)int_C zplus aDelta rho nu<=Gcap/T。故
 Rper<=M log(1+Gcap/(T M e_g))<=Gcap/(T e_g)。
还可保真实DeltaF，比最后使用Gcap更锐。前一界仍依共同alpha、全终端e_g和原来源背景，不能将其看成固定receiver费用或general弱型闭合。

这改变R210先将e_t全部替为e_g的线性上放，保留持续目标自身时间损失对当前归一化的贡献。未消去bad池、receiver、p_y、hard正帽、选择器或新入口预算。M是同一行上实际合法共同上界，可取esssup_C zplusDelta rho，不允许在积分各t自由选M。

连续capture链逐步有该界，但sum M_i log(1+DeltaF_i/(M_i e_g))不自动由一次log免费统摄；若M_i总量受共同alpha链控制，须单独证明，不能假设。

## 同钟有限链应先合并目标增量，而非求和各行log（新增候审）

假定有限步i共享完整nu、Z_t、w_t、tau、h、g、T、a、kappa、J、Dq，alpha_i非增；各步持续集合C_i均属于同一Z_g，各步z_i∈[0,1]沿辅助t固定。允许实际正门与bad集合随步变化，但每步恢复均由k_v Pi(v)上放。定义
 f_sum(v)=sum_i 1_{C_i}(v) z_i(v)(rho_i(v)-rho_{i-1}(v))。
因共同alpha的rho_i单调且0<=rho_i<=1，点态0<=f_sum<=rho_m-rho_0<=1。所有原正门先保，统一上放后才有限求和；没有复制source预算。令C为Ci并集，F_sum(t)=int_C f_sum w_t nu，DeltaF_sum=(1/T)sum_i int_Ci z_i aDelta rho_i nu <=(H0-Hm)/T。

将上述一次归一证明直接应用于f_sum给
 sum_i Rper_i <= log(1+DeltaF_sum/e_g) <= log(1+(H0-Hm)/(T e_g))。
若有实际共同M_sum=esssup f_sum<1，可使用M_sum log(1+DeltaF_sum/(M_sum e_g))。这不是对每步log使用错误次可加性，而是先在同一时钟和完整后验上合并目标增量，再一次积分。

该结论不要求各步Ci相同；但要求所有目标在共同终端存活，完整归一与时钟不变且rho共享相同a/kappa/J。若这些物理对象改变，不能应用点态telescoping；不同clock、capture重充、new-entry的rho而非Delta rho均另计。只结算持续恢复，不直接结算signed原基线或全量cut不足。

## 一般来源的有限窗合法性补全（候审）

不必将归一log定理限制为有限原子。假设0<tau<=h<=g<infinity、n有限、0<e_g<infinity，C⊂Z_g且实际乘积时钟。每坐标min-product给w_tau(v)/w_g(v)<=(g/tau)^n，因此int_C w_tau nu<=(g/tau)^n e_g<infinity。对tau<=t<=h，k_t<=n且w_t<=w_tau，所以int_C f k_t w_t/t nu<=M(n/tau)int_C w_tau nu，为有限常数。由逐source时钟绝对连续与Tonelli，F(t)在闭窗绝对连续，F(tau)-F(h)=int_tau^h int_C f k_t w_t nu dt/t。所有log分母至少e_g>0，普通绝对连续链式法则即可合法积分；无需对两个无穷积分相减。

即使完整e_t在扩展窗某处不可定义，证明使用的是显式surrogate e_g+(F(t)-F(h))/M；原恢复只在原可定义far域比较，不新建域外Pi。无限范围或e_g不有限的原对象仍须先回到其合法定义/截断，不能由本有限正窗论证自动覆盖。有限链的f_sum<=1采用相同支配，所有一般来源积分同样合法。

## 实际最终行的确定基线拆分（独立命题检查通过，待全文整合）

不必先构造合法嵌套capture历史。固定原实际最终行及其E、U=1_E min(a,kappa)、alpha=(Dq-int U nu)/Q_J，定义alpha0=Dq/Q_J。只在原实际终端target上定义rho0=(1-kappa/a-alpha0 J/a)+，保原实际所有门（即使门依赖原rho也不重算），原rho=(1-kappa/a-alpha J/a)+。则rho=rho0+delta_rho逐点精确，a delta_rho<=J int U nu/Q_J。

原J权A=zrho相应分为zrho0+zdelta_rho，第二份以同一farFTC得Rrepair<=int U nu/(Teg)<=D/sqrtell。原heavy下按joint_capacity的独立epsilon_rec槽和小维母核付款。定义虚拟rho0不声称其来自合法空捕获史，也不改变真实E/Pi/a/geometry/outer measure；这是原实际权的代数拆分，因而不要求C⊂某个旧Eminus。

同一恢复还可用本稿log证明：f=zdelta_rho<=1，DeltaF<=int U nu/T，所以Rrepair<=log(1+int U nu/(Teg))。所有原负项只留在baseline一次，即原signed J交通=(P0-N)+P_repair；不能分给恢复另一份负信用。a=0/QJ=0/空far按原零支先处理。这一逐行替换覆盖全部符合原实际J资格的行，但baseline与其它shares尚未支付，不能宣称一般上界闭合。

上述实际行拆分同样可取z=1，故直接适用于R128 RT2完整far正余项的rho权，而非仅J/S分量：P_rem(rho)=P_rem(rho0)+P_repair。已经删去已付子集时保持同一剩余域；所有尚可用负项只在P_rem(rho0)的signed基线中保留一次。J-share为限制应用，不重复分配恢复误差。不据此扩到near或其它不同原块，也不宣称新baseline已经付款。
