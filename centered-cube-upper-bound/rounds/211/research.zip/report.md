# 第211轮：原far余项的高初始参数基线与恢复付款

本轮目标仍是一般中心立方体 n^(1/2+o(1)) 一致弱型上界；尚未闭合。所处理的是持续捕获恢复，以及原实际最终行到确定alpha0基线的精确有价替换；仍不能代替该基线或包含near等其他部分的全部原余项。

## 实质进展

令f=zplus Delta rho为沿辅助时间固定的持续目标权，0<=f<=M，F(t)=int f w_t nu。利用终端存活和时钟单调性，保留e_t>=e_g+(F(t)-F(h))/M，得到Rper<=M log(1+DeltaF/(M e_g))，其中DeltaF=int zplus aDelta rho nu/T<=Gcap/T。该结论不用来源独立，也不只限有限原子：在有限正窗，w_tau/w_g<=(g/tau)^n提供可积支配，完成一般来源的绝对连续与积分合法性。

同钟链必须先合并f_sum=sum 1_Ci zi Delta rho_i。共同alpha下降给f_sum<=rho_final-rho_initial<=1，故全部持续恢复至多log(1+(H0-Hm)/(T e_g))。这不是把每步log相加后误用次可加性；不同clock、来源、终端、入口和重充不在该链定理内。

更关键的是恢复原历史门：R122、R125与R128完整原行保留heavy e_g>ell q c_j^(-n/2)g^n，所以T e_g>sqrt(ell)q。由真实总捕获增益不超过Dq，持续恢复及合法同钟链的行费<=D/sqrt(ell)。先保原外测度，乘2Lambda再用Tsmall<=4X，得到8Lambda D/sqrt(ell) X；无需先hard帽后产生逆w_g列。

D为原预定D_n=max(1,epsilon_RC sqrt(ell)/(8Lambda)-16/(3sqrt(ell)))。另设独立恢复槽epsilon_rec>=epsilon_RC：D>1分支直接付epsilon_rec X；未直接吸收的小维分支D=1，行费<=1，可用已证有限维母核来源界补齐，常数只依预定误差。旧AC已经消费的epsilon_RC捕获槽不能再次使用。若原epsilon_RC已固定，不能事后任意变小而不调整全套背景；联合构造时应预先分配两项误差。

进一步可直接固定原实际最终行，定义alpha0=Dq/QJ、rho0=(1-kappa/a-alpha0 J/a)+。原rho=rho0+Delta rho精确成立，aDelta rho<=J int U nu/QJ，恢复由上述heavy预算支付。这个拆分保持真实E、所有原门和来源时钟，不需要先构造合法空捕获历史或嵌套链。取目标权系数z=1时，该论证直接作用于R128 RT2完整far正余项；若先前已删去已付正子集，只在同一剩余域拆分。原完整尚可用负项只留在baseline一次；J-share只是子应用，不能重复领取恢复额度。它将原实际far余项有价替换为显式alpha0基线；不是基线本身已付。FIRST的QJ<=q给alpha0>=D，因此基线正支必须满足T Delta>D K0+(Dq/QJ)J>=D(K0+J)；下一步须结合这一明确支持条件与真实空间核和原负余额建立全局预算。

## 保留的条件与未解决项

持续链定理不证明任意输入均有覆盖全局的嵌套历史；新增逐行代数拆分避开了这项要求，可用于全部原实际far合格行，但仍保显式baseline。这条逐行替换后的首要剩余是显式高alpha0基线及其共同来源交通，另保原near等未涉及部分。若后续再采用跨实际状态的变形路径，new-entry、几何/时钟变化、重充和选择器费用仍须另证，不能由同钟链工具自动删除。原signed负信用不被本轮再消费；X保原定义，不擅自替换成无约束全空间积分。

辅助有限维优化保真实旧Sminus与分母增长，能判定部分净增量不正；其自由Splus极值只是放松，不证明物理S达到该值。旧态已good时，postgood下界可能被Sminus覆盖，不宣称冗余截断带来新实际付款。

对数接收量的均值/方差接口保留为条件工具：E softplus(L)<=log2+(mu+sqrt(mu²+Var L))/2。固定张量核的方差控制不能免除原receiver自适应尺度，正均值也不能丢掉。本轮发现原heavy直接支付恢复后，不继续把固定参数估计包装成一般根界。

## 有限计算与复现

本机Python Fraction实际完成初探/压力/扩大三阶段9个单步模型、1个两步共同clock捕获链，以及3个有理参数D校准和3个辅助字段极值模型。log用40项atanh和显式几何尾的有理区间；无浮点求积。全部10个clock模型通过所声明的scalar heavy门，但未声称实现原空间核、FIRST或完整history。完整数值范围和最终脚本哈希见numeric_notes.md、audit.md；新增alpha0拆分只复用前三个既有终态，原门不重算；还检验纯代数cross-min校准。有限检查不替代定理。

解压后执行python3 reproduce.py --verify-only；再执行python3 reproduce.py --output-dir <全新目录>。驱动迁移脚本和contract到临时目录，运行并比较完整JSON，检查前后清单。保留详细LaTeX，不编译PDF。本轮冻结归档前须完成最终独审与父级实际驱动重放。
