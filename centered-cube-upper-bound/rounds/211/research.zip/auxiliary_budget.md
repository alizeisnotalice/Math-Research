# R211：同 alpha 持续恢复的相关截断极值与物理分母下界

状态：给固定真实行的精确响应截断、保相关的自由分母场极值及净增量极值；保原 post-current 核带来的联合分母下界。真实核状态只在其实际分母达到该场边界时取等。旧态 good 在共同 p/wg 下使 postgood floor 对已知 Sminus 冗余，不能将此截断误报为新增 physical 约束。新公式给实际 CT 接收增量的更锐充分费用及可零正恢复的明确来源判据，本辅助不使用原 heavy 门时，不独立支付一般原外测度预算；本轮 joint 主稿已在实际保 heavy 的共同背景下另证独立 epsilon_rec 付款。本文初次推导未读 Astra 空间稿，也不重复父级 normalizer-log 推导。

## AB1　真实输入、共同捕获和零支

沿用冻结 R210 `capture_threshold_budget.md` CT1--10 的同一原(omega,V,j,x,y)行：
\[
 \Pi_t(dv)=1_{Z_t}(v)w_t(v)\nu(dv)/e_t,\quad
 w_t(v)=\prod_i\min(1,\alpha_i(v)/t),\quad
 a_v=\mathsf T(w_\tau(v)-w_h(v)),\quad
 \kappa_v=DK_{0v},\quad Q_J=\int J\,d\nu.
 \tag{AB1}
\]
原 far 包含于[tau,h]、h<=g，持续C⊂G∩Ecap−∩{a>0}终端存活，e_t>=e_g>0。原s/L/R、空间尺度b、T/clock/nu/J/K0、背景和共同资格按CT保持；不逐target重选alpha。

实际Ecap−⊂Ecap+、U±=1Ecap± min(a,kappa)，
\[
 H_\pm=Dq-\int U_\pm d\nu=\alpha_\pm Q_J\ge0,
 \quad\delta\alpha=\alpha_--\alpha_+\ge0,
 \quad G_{cap}=\delta\alpha Q_J.
 \tag{AB2}
\]
alpha由同一真实全source积分产生，不是优化中独立可调的slot参数。

写p=p_y>=0、w_v=w_g(y,v)>0、K>0。C上S_v+>=S_v−>=J_v>0，
\[
 z_v^+=J_v/S_v^+,\quad
 \rho_v^\pm=(1-\kappa_v/a_v-\alpha_\pm J_v/a_v)_+.
\]
a0/J0/QJ0/e_g0、空far先按原零对象处理；本稿不在零槽形成比值。deltaalpha0则持续rho恢复零，双alpha0同样；alpha+0保持，绝不除alpha。p0在实际high正q行不发生，标量辅助直接使p加权恢复零。所有正积分先有限截断，扩展值不作无穷相减。

## AB2　真实尺度给的背景分母不能省略

原P_s,L+与P_s,L同s，L+=min(b,gamma L)，gamma=1+1/n。设lambda=L+/L∈[1,gamma]。因实际f_s偶递减（包括闭硬面），
\[
 P_{s,L^+}(x-v)=\lambda^{-n}L^{-n}\prod_i f_s((x_i-v_i)/(\lambda L))
 \ge\lambda^{-n}P_{s,L}(x-v)\ge\gamma^{-n}P_{s,L}(x-v).
 \tag{AB3}
\]
无需logconcavity。记post-current r_v=P_s,L(x-v)，则
\[
 S_v^+=J_v+r_v+p_v^+\ge J_v+(1+\gamma^{-n})r_v.
 \tag{AB4}
\]
若已知实际lambda，可把gamma^-n换更强lambda^-n；若实际p_v+也已知，S+已是给定值，下面“优化S”只是上包络，不再是原核的自由参数。

postgood给S+>=3pw_v/K。综合所有已给信息，定义
\[
 F_v=\max\{S_v^-,J_v+(1+\gamma^{-n})r_v\},\qquad
 m_v=\max\{F_v,3pw_v/K\},\quad M_v=J_v/m_v\in[0,1].
 \tag{AB5}
\]
J>0使m>0。不能仅用max(J,3pw/K)宣称原物理极值。

特别，两态持续target若都为原good且p,w_g,K共同，旧态已经有Sminus>=3pw/K；因此m=F，postgood新增floor在保实际Sminus的背景下冗余。这一资格必须保留，不能报告为独立新physical约束或strict覆盖。仅在此前丢Sminus的粗摘要层，postgood截断才显式减少上界。

AB3常数作为单source物理比较可取：未clamp、x=v时pplus=gamma^-n pv；纯hard共同core内也可取。一般strictsoft、非零位置且lambda>1时，实际径向因子严格增大，可能严格大于AB3。多source共享同一x/s/L等关联更不允许各slot独立制造赢家。

## AB3　同一 alpha 的精确 target 响应

定义
\[
 b_v^\pm=(a_v-\kappa_v-\alpha_\pm J_v)_+,
 \quad R_v=a_v(\rho_v^+-\rho_v^-)=b_v^+-b_v^-.
\]
正部仿射函数的有限差分精确给
\[
 \boxed{R_v=\min\{\delta\alpha J_v,(a_v-\kappa_v-\alpha_+J_v)_+\}.} \tag{AB6}
\]
证明：令x=a−kappa−alpha+J，deltaalphaJ>=0，则x+−(x−deltaalphaJ)+等于min(deltaalphaJ,x+)。inactive、部分激活和完整线性响应均在同一式内，不能每target另选alpha使其全部取deltaalphaJ。

亦有共同活动区间表达
\[
 R_v=\int_{\alpha_+}^{\alpha_-}J_v
 1_{\{a_v-\kappa_v>\lambda J_v\}}d\lambda,
 \qquad \int_C R_vd\nu\le\delta\alpha Q_J=G_{cap}.
 \tag{AB7}
\]
这正是原LC容量，不另将nu或alpha当概率/自由变量。deltaalpha0时积分零，无归一响应除法。

## AB4　给定 source 字段的有限维精确最优包络

固定所有AB1--5真实字段及共同alpha，仅在辅助放松中允许每slot自由选Splus>=m。对任何有限正原子测度（或可测场的相应正积分），
\[
 \boxed{\sup_{S_v^+\ge m_v}\int_C {J_v\over S_v^+}R_vd\nu
 =\int_C M_v\min\{\delta\alpha J_v,b_v^+\}d\nu.} \tag{AB8}
\]
证明：每个R>=0，目标对S非增，逐slot最小值m同时达到上界；选择S=m为可测字段。若只有限slot，就是独立边界优化，无需概率独立性或强对偶。

AB8的sup是自由分母场的sharp值。给定实际核状态则仅有<=，且在R_v>0的nu-a.e.槽需要真正S_v+=m_v才等号。它还必须满足实际p_v+p_vplus+J关系、共同当前尺度、来源坐标、捕获/历史/FIRST/high等资格，不能用自由选S=m伪造一份physical input。若实际S已给定，本身∫J R/S就是精确值，不叫未知物理最优。

同一共同alpha的保相关表示为
\[
 \int_C M_v R_vd\nu
 =\int_{\alpha_+}^{\alpha_-}\int_C J_vM_v
 1_{\{a_v-\kappa_v>\lambda J_v\}}d\nu\,d\lambda. \tag{AB9}
\]
来源字段、postgood、活动层必须在同一内积分，不能分别给每个层或来源重新选赢家。M若随lambda真实变化，不能继续将本固定字段式外推。

## AB5　不先付倒wg：精确逐source截断和整体分离的损失

p>0时AB5给
\[
 pM_v=\min\{X_v,Y_v\},\qquad
 X_v={pJ_v\over F_v},\quad Y_v={KJ_v\over3w_v}. \tag{AB10}
\]
因此CT12内部的原p加权恢复严格上放为
\[
 \boxed{\int_C pz_v^+R_vd\nu
 \le\int_C R_v\min(X_v,Y_v)d\nu.} \tag{AB11}
\]
这是每source联合截断，绝不先分别取p和1/wg的上确界。后者即使积分发散，右边仍<=p∫R<=pG_cap，故每个有限p/G真实行不引入人为的倒wg发散。

设U0=∫C R Xν、U1=∫C R Yν，两者有限时精确有
\[
 \min(U_0,U_1)-\int_C R\min(X,Y)d\nu
 =\min\left\{\int_C R(X-Y)_+d\nu,
              \int_C R(Y-X)_+d\nu\right\}\ge0. \tag{AB12}
\]
证明分别由U0−joint=∫R(X−Y)+、U1−joint=∫R(Y−X)+；不在无穷量间作减法。只有两种交叉支都有正R质量时严格改善。

但在真实共同旧good且保实际Sminus时，F>=Sminus>=3pw/K，故X<=Y逐槽，AB12的saving=0。不可将仅针对更松、丢Sminus的摘要公式之strict saving登记为actual持续背景的strict改善。AB11仍保实际字段，是正确且有限的付款上包络；它本身不证明一般外measure可付。

可计算截断还有不分离字段的层积分：
\[
 M_v=\int_0^1 1_{\{uF_v<J_v\}}1_{\{3upw_v<KJ_v\}}du.
\]
严格/非严格边界对du零测；p0不用此式除p。与AB9联合时同一lambda/u/source共享原字段，没有额外菜单或每层单独capture预算。

## AB6　保负分母的净正恢复极值

原A变化比单独rho恢复更精确：
\[
 a_v\Delta A_v={J_v b_v^+\over S_v^+}-{J_vb_v^-\over S_v^-}.
\]
仍在自由Splus>=m的同一类，正部也对S非增，因此
\[
 \boxed{\sup_{S_v^+\ge m_v}a_v(\Delta A_v)_+
 =W_v^{net}:=\left[{J_vb_v^+\over m_v}
                   -{J_vb_v^-\over S_v^-}\right]_+}
\]
\[
 =\left[M_vR_v-J_v(1/S_v^--1/m_v)b_v^-\right]_+
 \le M_vR_v. \tag{AB13}
\]
不可把单独负项的正上界当负补偿；这里所有系数是给定真实字段的下界推来的合法整个正部上界。实际有响应槽等号同样需真正Splus=m；不声称physical整体取等。

特别显式条件
\[
 m_v b_v^-\ge S_v^-b_v^+ \tag{AB14}
\]
足以断定该实际source Aplus<=Aminus，共同gate下没有由它产生的净正恢复交通。若bminus0、bplus>0则不能以有限分母满足AB14；双b0先零。此判据保共同alpha/真实a及post-current核下界，不以新增未知moment门替代证明，但未证明所有剩余核心都满足它。

物理scale项J+(1+gamma^-n)pvpost大于旧Sminus时可使该判据生效；postgood冗余并不消除真实post-current上升的denominator信息。它只支付已满足判据的共同持续target净增量，不付新增资格、时钟或原baseline。

## AB7　原far/RT1回代与付款范围

由R210实际farFTC，对共同gate/clock/outer的持续变权，先正放掉负变化再用D+<=kv与et>=eg，得到
\[
 \int_{Jfar}\int_{C\times B}\Psi h_{gate}(\Delta A_v)_+D_t^+
 d\Pi_t^2\,{dt\over t}
 \le{1\over\mathsf T e_g}\int_C a_v(\Delta A_v)_+d\nu
 \le{1\over\mathsf T e_g}\int_CW_v^{net}d\nu
 \le{G_{cap}\over\mathsf T e_g}. \tag{AB15}
\]
这个sourcewise正上界可能丢掉跨target的负抵消，不能宣称优于保完整实际N_S的全部signed比较；它的用途是仅用已给字段即可确证AB14子域不需正恢复付款，并更锐界其补集。

用原一次正hard reduction后，AB15给准确充分接收费用
\[
 {32\Lambda\over3}\,\mathbb E\sum_{V,j}\int dx\,1_{j(x)=j}
 \int {p_y\,\beta_V(dy)\over\mathsf T e_g}
 \int_C W_v^{net}d\nu_V(v). \tag{AB16}
\]
单独rho恢复则将Wnet换AB8；同时保AB10时等价保pM的联合截断，不立即付1/wg。硬源仍保时用原RT1共同measure而不重复领hard帽。

原high/current只给∫high beta/eg<=1/(2K)，不直接支付带p的AB16。z与postgood合用可给旧KJ/(3wg)分支，但AB10显示tinywg应保另一个pJ/F分支；不能在所有source一律替成倒wg列。其仍依真实x/y/alpha/capture/source，未有一般线性WA价，也不因Finite-field sup可取而授source列界。

若同钟nested capture链各step均满足本共同背景，AB15<=Gi/(Teg)可沿原H telescope，无capture层数；各实际sharp字段也可保各step的AB13积分。变钟T/eg、背景源及gate/outer变化，仍保R210的系数正变差、入口/geometry/充值和完整j/window/selector费用。nu、beta只共同父支配；未使用nu<=beta。

本轮改变的是：给原CT12一项完整保相关、可实际计算的sharp自由场上包络，及真实post-current下界造成的净恢复零判据，而不是将CT14未知列改名。它不保证strictphysical扩大或一般root积分闭合；若不使用原 heavy 门，本辅助独立 field 接口的第一处未付量是AB16在原同一RT1/receiver选择中的预算；实际保 heavy 的同钟持续恢复已由本轮joint主稿另获独立epsilon_rec付款。原baseline、入口、变钟、重充及所有界外交换仍未付。

## AB8　最小精确方案（制定时尚未执行；最终有限检查见numeric_notes）

本方案制定时尚未执行；其后三阶段已实际执行，准确证据与范围见最终numeric_notes。原建议为均只Fraction，先固定真实min-product clock/capture再算字段sup；不作随机优化或物理quad，不将有限检查当原全资格证明。

共同四源(v1,v2,u,z)，nu各1；n1,tau1,h3/2,g2,Tcap1/2，阈值(1,3/4,2,1/2)，因此wg=(1/2,3/8,1,1/4)，a=(1/6,1/8,0,1/12)，eg17/8。J=(1/48,1/48,1/96,1/96)，QJ1/16。Ecap−={v1,v2}，Ecap+加z，C={v1,v2}。

初探kappa=(1/12,1/16,1/48,1/24)，Dq5/24。真实U/H重算alpha−1,alpha+1/3,Gcap1/24，持续R1=R2=1/72。取K1,p1/120、Sminus=2J于两target，post-current pv=J/2；gamma2、postpplus可取J/2，使actual字段Splus=2J且满足pplus>=gamma^-1 pv。postgood和oldgood都成立，m=2J，AB8自由场上界为1/72，net上界同1/72。

已知边界压力：保持clock/J、把target2的kappa改1/8、Dq改13/48；其它kappa不变。共同alpha仍1→1/3，Gcap1/24，但target2完整inactive、R2=0，R1=1/72，恢复/net包络均1/144。该阶段应另核deltaalpha0、a_u0/J0辅助零支而不除零，不需新增source模型。

扩大字段：回初探kappa/Dq，target1 postpv改2J、postpplus=J，故Splus=4J，m=4J；target2沿初探。R恢复包络=1/96，但net正包络=1/144（target1已被AB14排除）；其target1净aΔA为−7/576，真正负值保留。固定Sminus的postgood冗余、actualS达到m时field等号、S稍增时严格下降均可独立有理核验。

同时对每个slot分段核R=min(deltaalphaJ,bplus)及原正部差；S取m、2m和一个非二进制rational中间值，验证单调/正部sup。用任意正R两slot的cross-min恒等式作单独纯代数calibration；若保旧good/Sminus，必须验证saving为0，不能挑松摘要cross例假冒actual增强。

这些是完整clock/capture及给定postgood字段的条件数组，不是同一空间phi/K0/current核实现；初探p并不满足实际high，不能标FULL或原全资格输入。供校验极值/截断/零支和正确不可取性范围。一般证明由AB3--15给出，有限测试不替代source/selector付款。
