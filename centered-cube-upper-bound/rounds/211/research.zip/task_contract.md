# R211 原high/postgood与捕获联合容量

目标：推进一般中心立方体 n^(1/2+o(1)) 一致弱型上界。重点是R210 CT12原测度下的持续捕获恢复，不把该增量当作全量raw。

冻结前轮：/Users/zhengzhihao/Desktop/T/output/centered_cube_round210_20261016_final_checkpoint/。允许工具为其CT共同clock捕获FTC、同钟链、JS剩余时间能量及完整Omega交换；R209保A删除势。使用前须核对原稿量词，不能假设尚未证明的B0/Brem/source预算。

准确输入：同一原(omega,V,j,x,y)，Pi=1Z w nu/e，w为物理min-product；a=T(w_tau-w_h)，U=1E min(a,kappa)，H=Dq-int U nu=alpha QJ，QJ=int J nu。两态capture嵌套，其他clock/来源背景相同，持续集合C上Splus>=Sminus>=J>0，z=J/S，rho=(1-kappa/a-alpha J/a)+。Gcap=Hminus-Hplus>=0。原high p_y e_g>=2Kq及int p_y beta<=q；原postgood p_y w_g(v)<=K Splus(v)/3。所有真实接收dx、j/window、high/history/support资格保留。

待控制的准确非负量：CT12中 integral dx 1_j integral beta(dy) p_y/(T e_g) integral_C zplus a Delta rho nu。保留共同source与alpha，不先无条件分别取p_y和1/w_g上确界。数学作者应给该量的更锐联合界并明确原外测度预算能否支付；成功须是改变其真实付款条件的新估计，单纯重命名CT14不算成功。无法全局支付时交付明确局部推导及第一处未付物理积分，不伪称一般闭合。

相关限制：nu<=beta不成立；postgood给逐target上界而非统一wg下界；high列只付beta/e_g，不付p_y beta/e_g；新target入口、补score n-k、变化clock/selector及near均未付。数值三阶段：初探、既知压力、扩大范围；只根据实际运行报告，有限模型不能当完整物理实现。

责任：Astra joint_capacity.md（关键原几何）；Sol auxiliary_budget.md（持续捕获准确有限维极值/截断，避免重复空间推导）；Sol audit.md（先独筛命题再读证明）；数值待准确公式形成再交Sol medium实现。主代理proof.tex.txt/report.md/driver/manifest。所有人不Git、不编译PDF、不修改他人文件，不自行扩大任务或新增Agent。
