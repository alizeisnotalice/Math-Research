# R288 — independent screen of the small-soft linear normalized affinity

## Verdict and scope

PASS for the stated one-dimensional linear normalized-affinity bound, and PASS for its transfer through the actual R279 moving-target menu under the explicit small-soft qualification. The independent derivation below was completed before reading the Astra author file. At initial write time `/tmp/r288_linear_gap.md` was not yet present; the completed author file was subsequently read and cross-audited as recorded below.

The source, posterior, physical-clock and terminal ledger operations imported from R279 remain subject to their original hypotheses. This audit establishes a moving-near branch mechanism and its prices; it does not independently certify the entire weak theorem's global ledger.

## 1. Hard-interval geometry with unequal lengths

Let b/2<=L<=A<=b, 0<=s,sigma<=epsilon<=1/512, and

    p(x)=L^(-1)f_s((x-y)/L),
    q_1(x)=A^(-1)f_sigma((x-v)/A),
    f_s=(1-s)h+s phi, h=1_{[-1/2,1/2]}, phi=h*w.

The kernel w has mass one and satisfies w<=1. Hence phi<=1, every f_s is a probability density, and p,q_1 both integrate to one. Let I,J be the hard intervals centered at y,v of lengths L,A, and delta=|y-v|=br with 0<=r<=1/2.

Because delta<=b/2<=L, the intervals overlap or touch. If one contains the other, |I triangle J|=A-L>=2delta. Otherwise |I triangle J|=2delta. Thus always

    |I triangle J|>=2br.

On the side of the symmetric difference lying INSIDE a hard interval, its associated density is >=(1-epsilon)/A. The other density is outside its own hard interval and is <=epsilon/L<=2epsilon/A. These statements remain valid in either orientation; boundary points have zero Lebesgue measure. The upper bound on the outside density is essential and is available because phi<=1 and A/L<=2.

Therefore the squared square-root gap is at least

    [sqrt(1-epsilon)-sqrt(2epsilon)]^2/A
       >=(479/512)^2/A
       >=(7/8)/A.                                     (1)

The rational margin in the last inequality is exactly 65/262144. No zero-density assumption on the soft tail is used.

## 2. Full affinity first, then the actual normalization

Write H=integral_R sqrt(p q_1). Since both densities have mass one,

    2(1-H)=integral_R(sqrt p-sqrt q_1)^2.

Integrating (1) on I triangle J gives

    1-H>=7br/(8A)>=7r/8.

For 0<=r<=1/2 this implies

    H^2<=(1-7r/8)^2<=1-175r/128.                       (2)

Now put

    Omega=min(1,b C(r)/L),
    D_norm=Omega^(-1/2) integral_{Q_b(y)}sqrt(p q_1).

Because C(r)>=(1-r)_+ and b/L>=1,

    Omega>=1-r>0.

The receiver truncation only lowers the nonnegative affinity. Consequently

    D_norm^2 <=H^2/Omega
       <=(1-175r/128)/(1-r)
       =1-[47r/(128(1-r))]
       <=1-47r/128,

and hence

    D_norm<=exp(-47r/256),             0<=r<=1/2.       (3)

This does not assert that a normalized affinity is automatically <=1: the normalization is paid explicitly by Omega>=1-r. At r=0, (3) is the valid bound <=1; unequal widths or soft parameters may give additional strict loss.

## 3. All displacements and compatibility with the old softness loss

For r>1/2, use the audited R279 displacement result, valid for all soft parameters and legal widths:

    D_norm<=exp[-3kappa min(r^2,1)/128],
    kappa=25/2^68.

On this region min(r^2,1)>=(1/2)min(r,1). Combining with (3) gives the uniform linear displacement estimate

    D_norm<=exp[-3kappa min(r,1)/256].                  (4)

The old R279 source-softness estimate is

    D_norm<=exp[-kappa s/216].

Taking the geometric mean of these two upper bounds gives

    D_norm<=exp[-kappa s/432-3kappa min(r,1)/512]
           <=exp[-c{s+min(r,1)}], c=kappa/432.          (5)

Thus the SAME R279 constant c works with a truncated-linear distance in place of the truncated-square distance. The fact that the near-displacement coefficient in (3) is much stronger causes no conflict; the uniform coefficient in (4) was deliberately weakened to match the old all-displacement estimate.

## 4. Tensorization, the true near window and collar cost

The actual R279 collar estimate remains valid for these small parameters and for the same two moving targets:

    collar contribution <=48 epsilon_h sqrt(s),
    epsilon_h=d/b<=1/(8sqrt(n)).

The product structure here belongs only to the fixed receiver kernels; no source law is assumed to be a product. Applying (5) coordinate by coordinate, retaining the actual window W_y=Q_{b+d}(y), and using s+min(r_i,1)<=2, gives

    integral_{W_y}F_{s,L,A}
       <=exp[-c(ns+D_1)+48e^(2c)n epsilon_h sqrt(s)]
       <=exp[-c(ns+D_1)+6e^(2c)sqrt(ns)].

The same Young inequality as R279 yields

    integral_{W_y}F_{s,L,A}
       <=exp[B_c-(c/2)(ns+D_1)],
    B_c=18e^(4c)/c.                                    (6)

The half-kernel is the original normalized halfproduct, with its actual window retained. The proof does not remove W_y or apply a hard cap to an expanded receiver scale.

## 5. Audit of the actual R279 menu transfer and exact prices

The actual R279 common-soft menu uses sigma_k=k/(n+1), with

    f_s<=gamma f_sigma_k,
    sigma_k<=s+1/n,    n sigma_k>=ns-1.

Thus the explicit original qualification

    n>=1024, s<=1/1024

guarantees every selected source/target common node has sigma_k<=1/512. All menu source and target soft parameters in this moving problem are that SAME sigma_k. There is no illicit substitution of a target parameter 1: the separate J=P_{1,b} target is the previously paid R277 branch and is excluded from this transfer.

For the upward scale menu, the source node B and the two targets A_1*=B, A_2*=min(b,gamma B) satisfy b/2<=B<=A_i*<=b and A_i*/B<=2. Hence every fixed node meets the one-dimensional hypotheses above.

Define the ACTUAL linear-distance tail threshold

    H_T,linear={ns+D_1>=1+(2/c)(B_c+T)}, T>=0.

It implies the source/endpoint-dependent but receiver-independent static node gate

    n sigma_k+D_1>=(2/c)(B_c+T).

Retaining this indicator at each fixed node, (6) gives that node column mass <=e^(-T). The count is at most n(n+1), even after restricting to small-soft nodes. Source/target kernel domination costs gamma^(2n)<=e^2; the true band normalization costs gamma^(n/2)<=sqrt(e). The positive score costs at most n, and the already proved actual j/clock menu sum costs at most n. These are exactly the R279 factors, now with the linear distance.

The per-moving-leg source price is

    (32Lambda/3)e^(5/2)sqrt(K)n^3(n+1)e^(-T)W_beta.

For the two actual moving legs, using a disjoint union assignment if both certify, it is

    (64Lambda/3)e^(5/2)sqrt(K)n^3(n+1)e^(-T)W_beta.       (7)

The hard cap is used only on the original receiver event before receiver extension. The fixed original posterior has its R279 receiver independence at the stage where receiver integration is performed; no posterior conditioned after a physical-clock change is substituted. The terminal source ledger W_beta is the original one, summed once. No nu<=beta comparison is needed.

## 6. Exceptional soft parameters and the remaining moving near branch

The current R279 residual already retains ns<=D and R_2<=D. On its exceptional branch s>1/1024, one has n<1024D. Thus

    kappa_0=2+sqrt(n)/8<=2+4sqrt(D).

The generic R283 raw estimate combined with the old R_2 score integral gives

    P_exception<=16Lambda kappa_0 sqrt(nD)
                [(16/3)W_rho+(1+log B_*)W_nu].         (8)

For D=O(log(n+2)) this is root-polylog, because the remaining kappa_0 is bounded by 2+4sqrt(D). The finite-dimensional branch n<1024 has kappa_0<6 and is covered by the same generic estimate with that absolute bound. The branch assignment should be made disjointly before summing prices; it creates no new source copies.

On n>=1024 and s<=1/1024, pay H_T,linear by (7). Its complement has

    D_1<1+(2/c)(B_c+T),

and is therefore covered by the R288 source/linear-clock result in `/tmp/r288_l1_score.md`, with H=1+(2/c)(B_c+T). Choosing T to pay a prescribed epsilon source price by (7) makes H=O(log(n+2)) for fixed Lambda,K,epsilon (with the inherited extremely large constants depending on c). Thus the two moving-near legs admit a root-polylog completion under the retained R279 residual hypotheses. This is a statement about that precise original branch, and does not by itself audit all previously spent or complementary branches of the global weak theorem.

## 7. Actual bounded diagnostics

A local exact Fraction calculation checked 576 cases: unequal interval symmetric differences, the two normalized near-affinity algebra inequalities for r in {0,.001,...,.5}, and safe common-soft menu bounds at n=1024,2048,1000000. It also checked the geometric-mean coefficient comparison. Output:

    PASS exact interval / normalized-gap / safe-menu checks=576
    sqrt-gap rational margin=65/262144
    kappa=8.470329472543003e-20 c=1.96072441494051e-22

These are exact local geometry/algebra diagnostics. They do not constitute an independent continuous kernel quadrature, a full original-history simulation or a global ledger certification. The analytic derivation above proves the screened lemma. Only this temporary Markdown file was written.

## 8. Completed author-file cross-audit

I subsequently read `/tmp/r288_linear_gap.md` in full. PASS: its interval geometry, normalized-affinity constants, old-softness combination, collar tensorization, restricted actual common-soft menu, static tail gate, and original two-leg source price agree with the independent derivation above. The author explicitly excludes the separately paid J=P_(1,b) target and states only conditional closure of the current moving positive route. No blocking discrepancy was found.

The author's sharper two-way linear clock expression is algebraically identical to equation (9) of `/tmp/r288_l1_score.md`:

    H log(n/H)+(n-H)log[n/(n-H)].

Its bound by H[1+log_+(n/H)] is valid: for H<n/2 use (n-H)log[n/(n-H)]<=H; for H>=n/2 the exact value n log2 is at most the stated bound. Thus the author's simpler linear-clock bound also has the correct root order and endpoint behavior. The author's small-soft source-node condition at n=1024 is safe, including the integer ns endpoint.

The O(log(n+2)) tail threshold statement treats the original Lambda and K as fixed structural parameters along with the requested epsilon; their exact dependence remains explicit in T_epsilon and in the displayed source price. Source-pair-dependent D or other constants must remain within the original outer expectation unless a valid common bound is supplied, as in the parent ledgers. This is an interpretation of the stated fixed-parameter asymptotic, not a new uniformity claim.

This completes the bounded independent statement screen and author-file audit. The global reduction ledger is expressly outside this deliverable.
