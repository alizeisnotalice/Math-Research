# R288 — a source-paid truncated-l1 auxiliary gate with its actual clock integral

## Result and scope

The new original upper-slot gate D_1(y,v)<=H has a root-polylog source payment when H is polylogarithmic, using the established R283 universal raw near estimate. No universal n^(1/4) raw estimate is assumed.

Keep one original source pair rho,nu; all original source/history restrictions, the full Pi_t x Pi_t, the unique actual j, actual q_-<=q<=lambda, the full-soft FIRST cap, the hard maximal cap <=4lambda, a<=L,R<=b<=2a, ns<=D, and the upper-slot R_2(y,v)<=D qualification. Let r=a/(16sqrt(n)) and d=2r. Define the NEW truncated-l1 distance of the actual upper auxiliary slot by

    D_1(y,v)=sum_i min(|y_i-v_i|/b,1).

Let P_current,H denote the SAME current unspent original positive near integrand with the additional slot gate 1{D_1(y,v)<=H}. At physical xi=c_jt/b, retain the original scale qualification L,R>=a_xi=max(a,b xi/gamma). Put

    kappa_0=2+sqrt(n)/8,
    S=(16/3)W_rho+(1+log B_*)W_nu,

where B_*>=1 is the explicit full-soft packet factor of `/tmp/r283_bellman.md` (P0). R283 proves the unconditional full-soft raw near estimate

    T_near(xi)<=2kappa_0 S.                              (1)

It includes the entire actual soft off-core response, arbitrary positive finite L1 sources and all permitted adaptive selectors. Current positive masks can be retained on the left of (1). It does not require a source comparison or a packet coincidence gate.

Let x_0=a/b>=1/2 and T=1-x_0<=1/2. For H,D>=0 define

    J(n,H,D;T)=integral_0^T
                   min(n,H/h,D/h^2) dh/(1-h),            (2)

with J=0 if H=0, D=0 or T=0. Then the original gated branch has the explicit joint source/physical-clock payment

    P_current,H<=4Lambda kappa_0 S J(n,H,D;T).           (3)

In particular,

    J(n,H,D;T)
       <=min{n log2, 4sqrt(nD),
              2H[1+log_+(n/(2H))]},                    (4)

where the last term is defined as zero at H=0. Thus for H=log^p(n+2), fixed p>=0, and D=O(log(n+2)), (3) is sqrt(n) times a polylogarithmic source price. This pays all current near traffic with the new upper-slot l1 gate, without requiring either source capture to be large.

## 1. The new score bound uses the original upper slot

Write r_i(v)=|y_i-v_i|/b and h=1-xi. The actual activation rule is C(r_i)<xi with C(r)>=(1-r)_+. For 1/2<=xi<1, every activated coordinate has r_i>h, and therefore

    min(r_i,1)>h,  min(r_i^2,1)>h^2.

On the retained ORIGINAL upper-slot event D_1<=H and R_2<=D,

    k_t(v)<=min(n,H/h,D/h^2)=f_{H,D}(xi).                 (5)

Since the original positive score increment is <=k_t(v), its full original Pi_t x Pi_t expectation, including the actual slot gates, is <=f_{H,D}(xi). This estimate is made on the original row BEFORE xi=c_jt/b is substituted. The other auxiliary slot receives no D_1 or R_2 restriction unless already present in the original integrand. No source-independent law is assigned to the posterior after the clock change.

For H=0, every retained r_i is zero and C(0)=1, so no coordinate is strictly active even at xi=1. The analogous statement holds when D=0. For H,D>0 the upper bound at xi=1 may be defined to be n; that one endpoint has zero clock measure and causes no integral ambiguity.

After the original probability estimate, retain the common physical lower scales and unique actual j mask through the clock substitution. Its sum is <=1, as in R280. Applying the R283 source price (1) at each qualified xi gives (3), including exactly the original outside 2Lambda once. The near-source factor two already contained in (1) is the established R283 same-coarse-cell price, not a new multiplicity.

## 2. Exact elementary formula for the three-way clock integral

Assume H,D,T>0. Define primitives for positive t<1:

    N(t)=-n log(1-t),
    L(t)=H log(t/(1-t)),
    Q(t)=D[-1/t+log(t/(1-t))].

Their derivatives are respectively n/(1-t), H/[t(1-t)] and D/[t^2(1-t)]. There are only two possible lower-envelope orders.

If H^2<=nD, put

    u=min(T,H/n), v=min(T,D/H).

Then v>=u, and

    J=N(u)+[L(v)-L(u)]+[Q(T)-Q(v)],                      (6)

where an increment with equal endpoints is zero. Equivalently, the score equals n on h<=H/n, H/h on H/n<=h<=D/H, and D/h^2 thereafter, with every interval clipped to [0,T].

If H^2>nD, put u=min(T,sqrt(D/n)). Then

    J=N(u)+[Q(T)-Q(u)].                                 (7)

In this case the linear-distance term never becomes the strict minimum; the score passes directly from n to D/h^2. The two formulas agree at H^2=nD. No primitive is evaluated at t=0 in (6)-(7), because H,D>0 make u and v positive.

For an actual middle clock restricted to xi<=1-delta with 0<=delta<T, replace J in (3) by J(n,H,D;T)-J(n,H,D;delta). For arbitrary shorter original clock windows, retain the corresponding subintegral or extend positively to the stated interval. If b=a, T=0 and the original clock price is zero.

## 3. Endpoint control, useful bounds and small-H limit

The inequalities J<=n log2 and J<=4sqrt(nD) follow respectively from the constant n bound and the established R280 quadratic-score integral. For the new bound, drop the D/h^2 term, use 1/(1-h)<=2, and integrate min(n,H/h) on [0,1/2]. If 0<H<=n/2 this gives

    J<=2H[1+log(n/(2H))].                               (8)

If H>=n/2, use J<=n log2<=2H, proving (4) in all regimes. The exact integral with ONLY n and H/h at T=1/2 is

    n log(n/(n-H))+H log((n-H)/H),   0<H<n/2,
    n log2,                        H>=n/2.             (9)

The three-way J is bounded by (9); a small D can make it strictly smaller even when H>=n/2.

For fixed n,D,T>0, as H decreases to zero, eventually H^2<=nD and D/H>=T. Hence (6) reduces to the n/linear two-piece integral and

    J=H log(n/H)+H[1+log(T/(1-T))]+O(H^2/n),
    J/[H log(n/H)] ->1.                                (10)

In particular J->0, matching the exact H=0 convention. Near xi=1, the score is n only in a terminal interval of width at most H/n (and at most sqrt(D/n)); its finite contribution removes the apparent logarithmic singularity of H/(1-xi). There is no divergent clock factor hidden at that endpoint.

## 4. Exact new residual and optional adaptive payment of its tail

If I_current is the original current positive integrand, INCLUDING its full auxiliary-slot variables, the split is exactly

    I_current=I_current 1{D_1(y,v)<=H}
               +I_current 1{D_1(y,v)>H}.               (11)

The first term is paid by (3). This is a new geometry gate on the actual upper slot, stricter in form than R_2 but with a different, linear activation estimate. It does not replace the R_2 qualifier used in the soft menu.

If not already spent in the parent ledger, the known R287 adaptive capture payments may be applied sequentially to the second term. With target J_cap>=1, use the existing original-source thresholds

    ell_rho(z)=2+log B+log_+[M(z)/(q_-a^n)],
    ell_nu(y)=2+log_+[N(y)/(4lambda a^n)],
    G_rho=1{c_rho>=ell_rho/J_cap},
    G_nu=1{c_nu>=ell_nu/J_cap}.

Here B is the R285/R287 full-soft POINT factor, whereas B_* in (1) is the R283 coarse-packet factor; the two constants are not silently identified. Keep 1{D_1>H} and every current unspent mask in both actual terms, dropping them only in the positive upper estimate. R287 then supplies the additional full score-clock prices

    3Lambda B_D J_cap W_nu,
    16Lambda B_D B J_cap W_rho,

for the tail parts G_rho and (1-G_rho)G_nu respectively. The exact leftover is

    I_current 1{D_1(y,v)>H}
        1{c_rho<ell_rho/J_cap, c_nu<ell_nu/J_cap}.        (12)

This optional combination transfers no posterior and assumes no relationship between D_1 and the source captures. If the parent ledger already paid either adaptive gate, apply only to the remaining original mask and do not charge it again. Any existing fractional allocation such as (1-A) stays inside I_current throughout.

## 5. Bounded history check and evidence boundary

The parent commissioned a separate bounded search of the active repository round README history at `/Users/zhengzhihao/Math-Research-centered-cube-work/centered-cube-upper-bound/rounds/*/README.md`. Its reported result found earlier R280 R_2 clock payments but did not locate this D_1 theorem. That is a bounded retrieval result, not proof that no earlier equivalent statement exists. I did not repeat that search after receiving the result.

The only mathematical imports used here are the actual R280 activation/physical-clock facts and the full-soft universal R283 raw near source price. The R286 radius-2r random-partition estimate is gated by local source expansion and is NOT used as a universal n^(1/4) bound. This route is also distinct from a direct FIRST plus physical hard-window estimate with additional D_infinity localization: the present theorem imposes no such second auxiliary gate.

## 6. Actual local computation

A local 65-digit mpmath calculation evaluated (6)-(7), compared them with direct piecewise quadrature, and checked all three bounds in (4), for 75 cases spanning n=1,8,512; H=0,1e-8,.1,n/2,n; and D=0,1e-12,.1,log(n+2),n. Both degenerate cases and both lower-envelope regimes were exercised. It also checked the small-H limit at n=128,D=2,H=1e-20. Output:

    PASS exact piecewise clock quadrature / bound cases=75
    H->0 ratio J/[H log(n/H)]=1.019644925004083155554471

These are high-precision numerical diagnostics, not interval certificates. The analytic primitives and inequalities above prove the result. Only this temporary Markdown file was written; no repository, Git or PDF changes were made.
