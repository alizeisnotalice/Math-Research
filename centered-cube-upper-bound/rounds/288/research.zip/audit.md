# R288 independent audit: actual auxiliary geometry and source prices

## 1. Independent statement screen before author proofs

The following screen was derived and sent to the parent before reading either R288 author proof. It checks the proposed scalar integrations and source coefficients under their explicitly stated upstream raw/FIRST inputs. Actual gate definitions and the source-FIRST step remain to be compared with the author proofs.

### D1-restricted original upper auxiliary slot

At xi=1-h on 0<=h<=T=1-a/b<=1/2, the stated score bound under D1<=H and R2<=D is k_v<=min(n,H/h,D/h^2). The upper auxiliary gate belongs inside the original full-posterior score expectation. Bounding this original gated expectation by that scalar BEFORE clock substitution is valid; no normalized conditional posterior is introduced.

Write J=integral_0^T min(n,H/h,D/h^2) dh/(1-h). Positivity gives

    J<=n log 2,
    J<=4sqrt(nD),
    J<=2H[1+log_+(n/(2H))].

For the third bound use 1/(1-h)<=2 and integrate min(n,H/h) up to 1/2. If H/n<=1/2, the resulting value is 2H[1+log(n/(2H))]; otherwise it is n<=2H. At H=0 the score is zero for h>0 and the displayed expression has value zero by its continuous/zero-score convention. Likewise D=0 gives zero score off the null clock endpoint.

With the supplied R283 universal actual raw-near bound 2kappa_0 S, kappa_0=2+sqrt(n)/8 and S=(16/3)W_rho+(1+log B_*)W_nu, the original one-time factor 2Lambda gives exactly

    P_D1<=4Lambda kappa_0 S J.

This becomes a root-polylog price for H polylogarithmic and B_* with the stated upstream logarithmic control. The B_D score integral alone is not a full-source budget; the separate actual raw source price remains essential.

### Profile gate D1<=delta and D_infty<=eta

Under the stated score cutoff k=0 for h>=eta and k<=min(n,delta/h) otherwise, and under the stated source-FIRST profile A_n<=2+2nh, the proposed original source price is

    2Lambda W_nu integral_0^eta min(n,delta/h) A_n(h) dh/(1-h).

Assume 0<eta<=1/2 and eta<=delta<=n eta. Then 1/(1-h)<=2 gives the explicit upper bound

    4delta[1+log(n eta/delta)] +4n delta eta-2delta^2
      <=4delta(1+log n)+4n delta eta.

The first expression follows by splitting at h=delta/n and integrating the constant and h-weighted pieces separately. Thus the claimed simpler coefficient is correct. For eta=delta=0 the gate has zero score off the null endpoint; that case should be stated separately or by a continuous zero convention.

The choice delta=eta=n^(-1/4) fits eta<=1/2 only for n>=16. A uniform-in-n statement can use delta=eta=min(1/2,n^(-1/4)), or explicitly restrict the displayed choice to n>=16. This qualification was sent to the parent before author reading.

For delta=eta=1/(8sqrt(n)), the simpler raw scalar coefficient equals

    (1+log n)/(2sqrt(n))+1/16.

The continuous maximum of (1+log n)/(2sqrt(n)) on n>=1 is 1/sqrt(e), so this coefficient is less than one. This confirms the stated special near-auxiliary consequence if the author's actual geometry indeed implies those D1 and D_infty bounds. It does not replace the general profile-gate theorem.

All these paid pieces must be restrictions of the SAME current R287 original residual with all prior allocation masks retained. Their upper auxiliary conditions modify the full original integrand, not its posterior normalization. Their exact complements, all original source costs and original score-clock qualifications must remain explicit. No coverage fraction or global completion is screened here.

## 2. Additional independent FIRST-profile derivation before its author proof

For a fixed original hard point z, the envelope of normalized hard kernels with scales a_xi<=R<=b has exact spatial integral

    A_n(xi)=1+n log(b/a_xi),

provided a_xi<=b; otherwise the actual qualified receiver set is empty. The inner cube contributes one, and its surrounding concentric scale shells contribute n log(b/a_xi). This statement concerns a finite-window actual point envelope, not a norm-one claim for an adaptive selected hard column.

At fixed xi, the original near soft response divided by q is at most one by original full-soft FIRST. Integrating the original soft source first, dropping its near mask only in the positive majorant, and then integrating the hard point envelope therefore gives actual raw near traffic <=A_n(xi)W_nu. This is a full source price. It remains valid for arbitrary measurable actual selectors in the qualified scale window, with every current positive mask retained on the left.

Because a_xi>=bxi/gamma, n log gamma<=1, and xi=1-h>=1/2,

    A_n(xi)<=2+n log(1/xi)<=2+2nh.

This independently establishes the source-FIRST input used in Section 1. It was sent to the parent before reading the second author. Likewise the original near condition |y-z|_1<=r and an additional actual upper-auxiliary gate |v-z|_1<=r imply |y-v|_1<=2r, so both D1 and D_infty are at most 2r/b<=1/(8sqrt(n)). Thus the claimed auxiliary-near special case follows from the general profile result, without replacing its full parameter scope.

## 3. Author readings, hash bindings, and verdict

Both author proofs were subsequently read in full. Their checked SHA256 bindings are

- `/tmp/r288_l1_score.md`: `e5d1ec101fc5da1502cc60d91a8724fd3c0685f169851ac80adc8877f99f7ab3`.
- `/tmp/r288_score_geometry.md`: `77f4261513636236a8b850cbeffcd81217a8538f188eb80e4955b311e51863d1`.

**PASS for both bounded payments and the stated complementary interfaces. No correction to either author proof is requested.** The profile author uses delta=c n^(-1/4), 0<c<=1/2, which resolves the unrestricted n^(-1/4) example qualification raised during the preauthor screen. Its more general theorem clips its actual clock support by T<=1/2, so it allows arbitrary fixed positive L1,U without separately requiring U<=1/2 or L1<=nU.

Only this audit file is owned/written. No author file, repository, Git, or PDF state is changed. The R280 activation/clock facts and R283 universal raw source bound are stated imports, not re-audited upstream results.

## 4. Actual auxiliary gates and full-posterior order

The authors use the same actual upper-slot distances

    d_i(y,v)=min(|y_i-v_i|/b,1),
    D1=sum_i d_i,  D_infty=max_i d_i.

At h=1-xi in [0,1/2], the established activation rule C(r_i)<xi with C(r_i)>=(1-r_i)_+ implies r_i>h, hence d_i>h and min(r_i^2,1)>h^2. Therefore D1<=H and R2<=D give k_t(v)<=min(n,H/h,D/h^2). Under the profile gate D1<=L1,D_infty<=U, positive activation is impossible if h>=min(L1,U), and otherwise k_t(v)<=min(n,L1/h). These are strict-activation conclusions on original rows, not assumptions about a new auxiliary distribution.

The positive pair score is at most k_t(v). The actual upper-slot indicators are retained inside the FULL original Pi_t x Pi_t expectation; then the probability bound is taken BEFORE the physical-clock change. All other positive slot masks may be retained on the left and dropped in this majorant. No restriction is transferred to the lower slot u. The original R2<=D qualification and ns<=D remain in force even when their quadratic improvement is omitted from the displayed simpler profile price.

All source/history/high masks, including the entire current R287 residual weight, remain on the original left-hand integrand. After the pointwise posterior score estimate, the unique actual j stays until its sum is at most one, and the physical receiver qualification gives the actual L,R>=a_xi window. No selector-dependent posterior is treated as independent after substitution.

H=0 or D=0 gives no active coordinate even at xi=1, because retained distances then vanish and C(0)=1 with strict activation. T=0 gives zero clock interval. Positive-cutoff endpoint conventions at h=0 alter a null clock set only. Profile m=0 likewise has zero cost. These zero cases involve no division by a vanishing source mass.

## 5. D1-only clock integral and source price

The first author's unconditional raw source input is exactly the stated R283 full-soft estimate

    T_near(xi)<=2kappa_0[(16/3)W_rho+(1+log B_*)W_nu],
    kappa_0=2+sqrt(n)/8.

It is explicitly distinguished from any source-expansion-gated R286 estimate and from the R285 point factor B. Thus its single existing near-source factor two and the original outside 2Lambda give exactly 4Lambda kappa_0 S J. Current positive masks only reduce the raw traffic. The source price is paid at every actual qualified clock before integrating the scalar J; it is not omitted or absorbed into a posterior probability.

The three primitive derivatives in the author proof are correct. When H^2<=nD, the lower envelope follows n, then H/h, then D/h^2, with breakpoints H/n and D/H clipped to [0,T]. When H^2>nD, H/h is never the strict minimum and the breakpoint is sqrt(D/n). The formulas coincide at equality. Positive H,D,T keep all evaluated primitive endpoints positive. An actual shorter clock window uses the corresponding subintegral, or is enlarged positively. Its small-H expansion and zero limit also have the correct coefficients.

All three J bounds in Section 1 hold, and the elementary two-term exact integral at T=1/2 in author equation (9) is correct. For H=log^p(n+2) and the stated upstream control of log B_*, this is a root-polylog price. Nothing in this audit identifies B_* with B or asserts that the R280 B_D scalar is itself a full-source budget.

## 6. General profile theorem and exact source-FIRST price

The second author's general fixed-profile support is

    m=min(U,L1,T),  T=1-a/b.

After the pointwise full-posterior score bound, original FIRST integrates the original soft y source to at most one. The remaining ORIGINAL hard source is integrated against its exact finite-window point envelope, whose spatial integral is A_n=1+n log(b/a_xi). This reproduces the independent derivation in Section 2. A variable selector R(x) is dominated by that envelope; it is not assigned column integral one. Full soft off-core response causes no problem because it is the original full response receiving FIRST.

The exact pre-majorant profile source price is

    2Lambda W_nu integral_0^m
      min(n,L1/h) A_n(1-h) dh/(1-h).

Using A_n<=2+2nh and 1/(1-h)<=2 gives the author's

    C_n=4 integral_0^m min(n,L1/h)(1+nh) dh,
    P_profile<=2Lambda C_n W_nu.

Splitting at L1/n gives exactly

    C_n=4nm+2n^2m^2                    if m<=L1/n,
    C_n=4L1[1+log(nm/L1)]+4nL1m-2L1^2 otherwise.

Its upper bound C_n<=4L1(1+log n)+4nL1m is valid in both regimes, since m<=L1. It also implies the stated looser bound with U replacing m. No B, kappa, random-grid factor, new j menu, or second Lambda is present.

The z-relative profile variant follows from the clipped-coordinate triangle inequality and original near |y-z|_1<=r: D1(z,v)<=alpha and D_infty(z,v)<=beta imply the y-profile with L1=alpha+r/b,U=beta+r/b. This requires no posterior support in a source packet.

For the actual additional gate |v-z|_1<=r, choose delta=2r/b<=1/(8sqrt(n)). The bound is at most 1/sqrt(e)+1/16, approximately .66903, strictly below 3/4. Thus its original price is strictly less than (3Lambda/2)W_nu. This is a special consequence of the general fixed-profile theorem, not the entirety of the result. The larger choice delta=c n^(-1/4), c<=1/2, yields the displayed root-order coefficient for every n>=1. Arbitrary receiver- or slot-dependent profile cutoffs are not inserted into this integrated source price; the author's warning about fixed menus and responsibility costs is correct.

## 7. Exact original complements and unresolved source interface

For the D1-only payment, the exact unpaid part is the SAME current original integrand times 1{D1(y,v)>H}. For a chosen profile gate G, it is the SAME current original integrand times 1{G(y,z;v)=0}. These slot indicators remain inside the original full auxiliary pair integration. They are not normalized into new posteriors. If both payments are placed in a sequential ledger, retain the first complement on the second branch; the exact final complement is their intersection. Adding their source-price upper bounds then requires no recharge, although overlapping or nested choices need not provide extra coverage.

The present current integrand already includes the R287 exact residual weight (1-A) and its two adaptive-capture failure masks. All those original masks remain in the R288 complement. The first author's optional adaptive-tail paragraph explicitly forbids charging R287's paid gates again. Applied to the actual already-unspent R287 masks at the same thresholds, those gates are not newly available paid traffic.

The profile author's alpha_out is exactly the weighted accepted upper-slot posterior mass on G^c, with its ORIGINAL denominator e_t. On contributing high rows, the stated original monotonicity e_t>=e_g>0 makes that denominator legitimate; null rows carry no traffic. The original R2 score majorant gives a positive upper bound f_D alpha_out for complementary score, not an equality of score and posterior mass. The actual hard capture c_nu has neither this accepted cut nor its clamp weights, so no inequality comparing c_nu to alpha_out is inferred.

Its omega_out loading retains the original source masks, actual time and unique j. Positivity and original FIRST yield 0<=omega_out<=1. Formula (13) is a valid positive source/receiver/clock majorant retaining the same nu in the hard carrier and posterior numerator/denominator. It is correctly left as an unresolved occupation-price interface. Dropping omega_out recovers the known finite-window A_n source fee, which need not be root-polylog after quadratic-score clock integration. No claim that B_D alone pays this full-source complement is made.

Neither theorem proves a positive auxiliary-profile coverage fraction, controls that remaining accepted posterior mass from low capture, or closes the general root upper bound. A new original-source payment or justified source-conserving transfer is still required for the actual complementary integrand.

## 8. Actual bounded local mathematical diagnostics

The default system Python had no mpmath. Without installing anything, the existing local vendored mpmath at `/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor` was used for fresh 50-digit checks. Direct piecewise quadrature of J checked all three bounds at 75 cases spanning n=1,8,512, H=0,1e-8,.1,n/2,n and D=0,1e-12,.1,log(n+2),n. Output:

    PASS actual J quadrature/bound cases=75
    profile near-auxiliary scalar universal bound=0.6690306597126334236037995 <1

A separate fresh run evaluated the ACTUAL pre-majorant FIRST-profile integral with its physical scale transition, compared the exact C_n formula to its own integral, and checked the simpler profile bound. It used 48 cases through n=10000, a/b in {.5,.75,.999999}, and four profiles including zero and an anisotropic profile. Output:

    PASS actual FIRST-profile integral / exact majorant cases=48
    max sampled actual/C=0.4931298435157708218372601
    Ordinary 50-digit diagnostics only; no interval or coverage certificate.

The calculations are local ordinary multiprecision diagnostics, not directed interval certificates, full continuous L1 histories, or evidence of posterior/capture correlation. The universal conclusions follow from the analytic proofs above.

**Final bounded receipt: PASS at the two author hashes in Section 3. Both actual upper-slot branches have their stated complete source/clock prices; their original complementary slot traffic remains unpaid. Only this owned temporary audit file was written.**
