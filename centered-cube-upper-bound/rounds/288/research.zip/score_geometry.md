# R288 — full-posterior anisotropic activation geometry with true clock/source cost

## 1. New theorem, precise scope and constants

Keep the SAME current original positive traffic, including the R287 residual weight, actual high p_y e_g>=2Kq, original FIRST, independent rho and nu, all accepted-hard/source/history masks, actual selectors, unique j(x), original physical clock, and the FULL posterior

Pi_(y,j,t)(dv)=1_{Z_t(y)}(v) w_t(y,v) nu(dv)/e_t(y).

The upper slot is v and score is (k_t(v)-k_t(u))_+. The original near hard source z satisfies |y-z|_1<=r. No source is replaced by a packet posterior. Let

d_i(y,v)=min(|y_i-v_i|/b,1),
D_1(y,v)=sum_i d_i(y,v),  D_infty(y,v)=max_i d_i(y,v).

Choose fixed L1>0 and U>0 for this outer datum, before receiver and auxiliary slots. Multiply the ACTUAL upper-slot integrand by

G_(L1,U)(y,v)=1{D_1(y,v)<=L1, D_infty(y,v)<=U}.

Put m=min(U,L1,1-a/b), and define

C_n(L1,m)=4 integral_0^m min(n,L1/h)(1+n h) dh.              (1)

Zero m gives zero cost. Then the original geometric branch has the source-linear bound

P_current,G <=2Lambda C_n(L1,m) W_nu.                       (2)

The exact elementary value of this upper price is

C_n(L1,m)=4n m+2n^2 m^2,                          m<=L1/n;
C_n(L1,m)=4L1[1+log(nm/L1)]+4n L1 m-2L1^2,       m>L1/n.  (3)

In particular

C_n(L1,m)<=4L1[1+log_+(nm/L1)]+4n L1 m
         <=4L1(1+log n)+4n L1 m.                           (4)

Thus the price is governed by the actual TWO displacement scales L1 and U, through L1 log n+n L1 U. It is not obtained by multiplying a sqrt(n) score fee by a packet kappa. No B, kappa, grid overlap, extra j sum or additional Lambda occurs.
The original R2<=D qualification may also be retained numerically by replacing min(n,L1/h) in (1) with min(n,L1/h,D/h^2); this only decreases the fee and gives zero when D=0. The displayed closed form deliberately does not require that extra estimate.

This gives a root-polylog source payment whenever the displayed price is O(sqrt(n) polylog(n)); for instance L1=U=delta<=1/2 with delta=O(n^(-1/4) polylog(n)) has the explicit price 4delta(1+log n)+4n delta^2. The useful scale is substantially larger than the original near radius r/b=O(n^(-1/2)). Every chosen cutoff is an ACTUAL auxiliary-slot qualification and the exact complement remains in the original posterior.

A joint version ties the qualification to the actual hard source z, which is sampled from the SAME nu as the posterior: choose fixed alpha,beta>0 and impose

D_1(z,v)<=alpha,  D_infty(z,v)<=beta.

The theorem then applies with L1=alpha+r/b and U=beta+r/b, by the clipped-coordinate triangle inequalities. The original near mask is retained when making this implication. This version does not assume the posterior is supported in the z-packet.

## 2. Activation counts and finite clock support, before posterior averaging

On every actual row let xi=c_jt/b and h=1-xi. The actual threshold in coordinate i is b C(|y_i-v_i|/b)/c_j. The established C(s)>=(1-s)_+ gives

coordinate i active => |y_i-v_i|/b>h => d_i(y,v)>h,

because the actual h lies in [0,1/2]. Consequently, on G,

k_t(v)<=min(n,L1/h),
k_t(v)=0 if h>=min(U,L1).                                 (5)

The second fact is essential: the narrow spatial displacement limits the ACTUAL clock support. The endpoint h=0 has zero dt/t measure. Since positive score <=k_t(v), integrating over BOTH FULL original posteriors, with all original positive pair masks retained, gives the pointwise bound

E_(Pi_t x Pi_t)[(k_t(v)-k_t(u))_+ 1_G(v) masks]
 <=1{0<h<min(U,L1)}min(n,L1/h).                            (6)

The probability law was not changed; only the original upper-slot integrand was split. The high condition and source masks remain on the left. No latent soft component is assigned a cap.

## 3. True receiver/source integration and the physical clock

Apply (6) inside the actual row before changing variables. The actual band gives L,R>=a_xi=max(a,b xi/gamma), gamma=1+1/n, while the actual xi is in [a/b,1]. Keep the unique actual j until its sum is at most one.

After taking this positive score majorant, the remaining y factor can be integrated using ORIGINAL FIRST:

integral p_y(x)rho(dy)/q(x)<=1.

The hard source z still carries its ORIGINAL nu. For R>=a_xi the exact hard point-envelope integral is

A_n(xi)=1+n log(b/a_xi).

Thus the true receiver/source/clock cost is at most

2Lambda W_nu integral_{1-m}^1 min(n,L1/(1-xi)) A_n(xi) dxi/xi. (7)

No replacement receiver measure or normalized selected channel is used. Since xi>=1/2,

A_n(xi)<=2+2n(1-xi),  dxi/xi<=2 d(1-xi)

in absolute integration orientation. Substitution h=1-xi proves (1)-(2). Splitting its integral at h=L1/n proves (3), and (4) follows directly. This is a simultaneous geometry-clock-source estimate; using an unscored raw overlap before the clock integral would lose the gain.

If bounds or source pairs vary over original outer data, keep C_n inside that original weighted sum. Current residual weights are only dropped positively in the upper estimate; this theorem does not recreate already-paid traffic.

## 4. Quantitative specializations, including the genuinely new tiny-near improvement

For D_1<=delta and D_infty<=delta, the source cost is bounded by

C<=4delta(1+log n)+4n delta^2.                              (8)

For the actual joint auxiliary near condition |v-z|_1<=r, original |y-z|_1<=r implies delta=2r/b<=1/(8sqrt(n)). Equation (8) gives

C<= (1+log n)/(2sqrt(n))+1/16
 <=1/sqrt(e)+1/16<3/4.

Hence this tiny-near auxiliary branch costs strictly less than (3Lambda/2)W_nu, uniformly in n. This is the improved L1-activation/finite-clock-support result; the weaker R2-based O(log n) consequence is not registered as a new theorem here.

More substantially, choosing delta=c n^(-1/4) with 0<c<=1/2 gives

C<=4c n^(-1/4)(1+log n)+4c^2 sqrt(n).

The theorem is therefore not restricted to an infinitesimal near-ball gate. For anisotropic profiles, retain the smaller product L1 U in (4). One must not insert receiver- or slot-dependent L1,U into an already integrated source price without a further argument: fixed profile menus have the sum of their displayed costs, unless their disjoint original responsibility is separately exploited.

## 5. Exact full-posterior complement and the capture bridge still missing

For either stated profile gate, write G(y,z;v) for its indicator (the y-profile case is independent of z). The exact complementary posterior mass is

alpha_out(y,z,t)=e_t^out(y,z)/e_t(y),
e_t^out(y,z)=integral_{Z_t(y)} w_t(y,v)1_{G(y,z;v)=0}nu(dv). (9)

This is a numerator inside the SAME full posterior. In particular 0<=alpha_out<=1. On high, p_y>0 and e_g>0. Original nested cuts and decreasing clamp weights give e_t>=e_g throughout the actual prior clock, so every denominator in (9) is legitimate on a contributing row. At null/zero rows the traffic is zero.

Retaining the original upper-slot R2<=D condition gives the independently checkable complementary score inequality

E_(Pi_t x Pi_t)[(k_t(v)-k_t(u))_+ 1_{G^c}(v) masks]
 <=f_D(xi) alpha_out(y,z,t),                               (10)

where f_D=min(n,D/(1-xi)^2). The original hard-capture number is instead

c_nu(x,y,z)=nu(B_1(y,r) intersection Q_R(x))/nu(B_1(y,r)).   (11)

Equation (11) has no accepted-cut Z_t or clamp weight w_t and uses only a local source neighborhood. It does NOT bound the weighted accepted numerator outside the much larger profile in (9). We have not inferred alpha_out from low c_nu, or replaced e_t by a local mass.

To state the remaining exact source interface, retain all original non-auxiliary masks in a loading

omega_out(x,z,xi)=q(x)^(-1) integral p_y(x)1_high
             [current near/source/history receiver masks]
             alpha_out(y,z,b xi/c_{j(x)}) rho(dy),           (12)

with actual clock legality and the unique j retained. Since every bracket and alpha_out is in [0,1], ORIGINAL FIRST proves 0<=omega_out<=1. The complementary traffic has the rigorous positive upper estimate

P_current,G^c <=2Lambda integral f_D(xi)
           integral_E integral h_{R(x)}(x-z)omega_out(x,z,xi)
                               nu(dz)dx dxi/xi.            (13)

Formula (12) keeps the same nu simultaneously in the hard carrier and the posterior numerator/denominator; it is not a newly normalized source. Merely dropping omega_out gives the already known A_n(xi) W_nu fee, whose clock integral is generally order nD log(n/D), not root-polylog.

A sufficient additional bridge would be a source-integrated bound on the actual occupation in (13) of polylog(n) W_nu uniformly in xi, or an adequate bound after its f_D clock weighting. Neither low actual capture nor high/FIRST alone supplies that estimate in this proof. The new result is (1)-(8), which pays a larger, explicitly quantified auxiliary geometry region of the ORIGINAL residual; the exact full-posterior complementary interface is (9)-(13). No general closure or coverage fraction is claimed.

## 6. Actual mathematical-tool diagnostics and evidence boundary

A local Python run made 60 exact rational checks of the activated-coordinate count and zero-activation clock support, 144 floating checks of the explicit piecewise price against (4), and 6 tiny-near constant checks; all passed. These are algebra checks of the inequalities following the activation implication, not checks of a new formula for the kernel C.

An independent numeric agent then ran the actual pre-majorant integral (7) and the polynomial/logarithmic majorant at 40 and 60 decimal digits, in stages of 8, 24 and 48 cases through n=10000. The original a/b values included 1/2, 3/4 and 0.999999, with gamma=1+1/n. The quadrature split at h=L1/n and the physical scale transition h=1-gamma a/b; zero profiles were included. All actual-integral <= C and C <=4L1(1+log n)+4n L1 U tests passed. Maximum sampled actual-integral/C was 0.499844; the C formula/quadrature discrepancy was 1.48e-41, and normalized 40/60-digit actual-integral discrepancy was 1.56e-38. The largest sampled tiny-near bound was 0.661118<3/4.

The numeric verifier's reproducible artifacts are /tmp/r288_checks.py and /tmp/r288_checks.json; this task wrote only the present Markdown file. These calculations are ordinary high-precision diagnostics, not interval certificates, original full L1 history constructions, or proof of a posterior/capture correlation. The analytic theorem is Sections 1-4; the unresolved full-posterior coupling is stated in Section 5.
