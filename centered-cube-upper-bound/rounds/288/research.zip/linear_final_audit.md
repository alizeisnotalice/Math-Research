# R288 small-soft linear affinity extension: independent audit

## 1. Independent preauthor statement screen

This screen was derived and sent to the parent before reading the new author proof or separate screen. It checks the supplied coefficient/menu statements, not yet the decisive R279 source-bridge transfer. No general closure verdict is given at this stage. Only this audit file is owned/written; no repository, Git, PDF or author file is changed.

For 0<=r<=1/2, H<=1-7r/8 implies

    H^2<=1-7r/4+49r^2/64<=1-175r/128.

If the intended normalized affinity is D_core=H/sqrt(Omega), with Omega>=1-r, then

    D_core^2<=(1-175r/128)/(1-r)
      =1-(47/128)r/(1-r)
      <=exp[-(47/128)r],

so D_core<=exp[-47r/256]. The actual definition of D_core and the proposed H/Omega bounds must be checked in the author proof.

Given an all-r displacement estimate D_core<=exp[-3kappa min(r,1)/256] and the existing soft estimate D_core<=exp[-kappa s/216], their geometric mean gives coefficients 3kappa/512 on min(r,1) and kappa/432 on s. Hence the common c=kappa/432 is valid, since 3/512>=1/432. The compatibility of the small-r coefficient with the stated all-r constant requires the original kappa range; this is a dependency to inspect rather than an assumed universal kappa.

The common-soft menu index k=min(n,floor(ns)+1), sigma_k=k/(n+1), obeys sigma_k<=s+1/n. Thus actual s<=1/1024 and n>=1024 imply both s and sigma_k are <=1/512. Upward finite-scale rounding still needs to preserve b/2<=L<=A<=b; the old halfproduct/bar-w/source bridge cannot be imported until its sign and normalization conditions are checked.

The separate generic regime accounting is consistent: the supplied R283 raw price 2kappa_0 S and the R280 scalar score integral <=4sqrt(nD), with one outside 2Lambda, give 16Lambda kappa_0 sqrt(nD)S. On actual s>1/1024 and ns<=D, n<1024D, so kappa_0=2+sqrt(n)/8<=2+4sqrt(D). This regime therefore has a root-polylog source price when D and the logarithmic source factors have their stated polylog bounds. For n<1024, kappa_0 is bounded by a universal constant. These positive restrictions do not require the new linear affinity theorem.

The crucial remaining audit obligation is whether the exact R279 all-grid source bridge, with its original bar-w denominator and actual full posterior, transfers from the quadratic displacement score to D1 with the claimed unchanged menu and source factors. Even a valid affinity estimate alone would not certify the entire remaining moving-near mother budget or the full global ledger.

## 2. Author and dependency readings; final bindings

The completed author proof was subsequently read in full. Its corrected normalizer step and added diagnostic section were read before this final receipt. The frozen author binding is

`/tmp/r288_linear_gap.md`: `b5d9154b1e9cb6103ed4b4d96e00b421e53ba3d88cecf6b4f4679aec29de26b4`.

The separate independent screen and its completed author cross-audit were read at

`/tmp/r288_linear_screen.md`: `a913c27617901f728771727b18c33c249f77f409eb1cdde325b353b596ed22a2`.

For the transfer comparison, the actual R279 menu, true-window collar and source-payment sections were read, together with the existing R279 final audit:

- `/tmp/r279_main.md`: `16bb4d5e568fe9b5ecf2e3894964639b1d7e0924f5fb2735567ac7d5148d5d88`.
- `/tmp/r279_final_audit.md`: `14bda2764c7d67c4e6f771a3fab672fc46851f01a627ffa913d968d5c6dd3b9a`.
- The previously independently audited R288 D1-clock proof remains `/tmp/r288_l1_score.md`, hash `e5d1ec101fc5da1502cc60d91a8724fd3c0685f169851ac80adc8877f99f7ab3`.

**Final verdict: PASS for the new small-soft linear normalized-affinity lemma, its full original moving-tail source transfer, and the conditional payment of the precise current moving-positive route described by the author. This receipt does not certify the older full global reduction/absorption ledger or a general weak-type closure.**

## 3. Fixed-kernel proof and corrected normalizer

The author correctly uses probability kernel densities with independent s,sigma<=1/512 and b/2<=L<=A<=b. On the hard-interval symmetric difference, the density on its own hard interval is at least (1-epsilon)/A and the other density is at most 2epsilon/A. The exact square-root separation margin is

    (479/512)^2-7/8=65/262144>0.

The symmetric-difference length is at least 2min(|y-v|,L), including containment, partial overlap and disjointness. For r<=1/2 this proves 1-H>=7r/8 and H^2<=1-175r/128 exactly as screened.

The parent identified an invalid intermediate inequality Omega>=C(r) in an earlier author version. It is corrected in the frozen proof to

    Omega>=min(1,C(r))>=1-r.

This is valid without assuming C(r)<=1, and it supplies precisely the normalization loss needed for D_aff<=exp(-47r/256). No assertion that dividing an affinity by sqrt(Omega) preserves a probability normalization is used. The receiver core Q_b(y) only decreases the full probability affinity.

For r>1/2, the existing audited R279 quadratic displacement bound implies the stated linear loss because min(r^2,1)>=(1/2)min(r,1). With kappa=25/2^68, 47>=3kappa. The existing independent source-softness loss and the geometric mean then give the SAME c=kappa/432, with the coefficient comparison in the correct direction. The new lemma covers independent small source and target softness; the actual moving application uses their common rounded softness.

## 4. Halfproduct collar and actual finite menu

The old collar estimate is used only on the original true near receiver window W_y=Q_(b+d)(y), with d=2r=a/(8sqrt(n)), not as a full-space normalized-affinity theorem. Its target-hard contribution remains present. Since each coordinate exponent s+min(r_i,1)<=2, the same tensorization gives the additive collar exponent 48e^(2c)n(d/b)sqrt(s)<=6e^(2c)sqrt(ns). Young's inequality absorbs it with the unchanged B_c=18e^(4c)/c, leaving exp[B_c-(c/2)(ns+D1)]. No source measure is assumed to factor across coordinates.

The actual moving targets are exactly K1=P_(s,L) and K2=P_(s,min(b,gamma L)), with common actual s. Restricting to s<=1/1024,n>=1024 makes the common selected node sigma_k<=s+1/n<=1/512, including the integer ns endpoint at n=1024. Restricting the old n-node menu to those selected small nodes does not enlarge its count. The separate target J=P_(1,b) is explicitly excluded and must use its existing separate payment; the new lemma cannot be used for it.

For each upward source scale node B, b/2<=B<=A_i*<=b holds for A1*=B and A2*=min(b,gamma B). Both actual-to-node target ratios have the required direction and factor at most gamma. The two soft and two scale inflations in the halfproduct cost at most gamma^(2n)<=e^2. The clamp direction barw_B<=barw_L makes inverse-square-root upper domination valid. D1 uses fixed outer b and is unchanged by the scale mesh.

The actual tail condition ns+D1>=1+(2/c)(B_c+T), together with n sigma_k>=ns-1, implies the receiver-independent static node gate n sigma_k+D1>=(2/c)(B_c+T). Retaining this gate in each node column pays its L1 mass by e^(-T). Thus the adaptive parameter supremum is paid by at most n(n+1) positive node columns, with true window retained. There is no unpriced substitution of an adaptive parameter into a fixed-column integral.

## 5. Original source, posterior, and all multiplicative fees

The actual raw certification p_y w_g<=K K_i gives p_y<=sqrt(K)sqrt(p_y K_i/w_g). The inherited original band relation w_g>=gamma^(-n)barw_L contributes only sqrt(e). The actual near condition together with hard support puts x in W_y before integrating the hard source. The original hard cap/q<=16/3 is used on the ORIGINAL receiver event before extending the remaining receiver integral to its column envelope.

At the original fixed y,j,t stage the full accepted posterior has its inherited receiver independence. The old accepted-cut and positive-denominator qualifications remain in force. Any extra current positive R287 masks may remain on the left and be dropped before this majorant; no source/posterior is replaced or locally normalized. After the legitimate column envelope, the full two-posterior mass is at most one and the score is at most n. The original j/time sum costs at most n by the inherited exact logarithmic sum, rather than by a falsely free posterior after physical substitution.

The per-leg factors are therefore exactly

    (2Lambda)(16/3)(sqrt(K))(sqrt(e))
       *(e^2 n(n+1))*n*n
      =(32Lambda/3)e^(5/2)sqrt(K)n^3(n+1).

The union of the two moving certifications is split disjointly or bounded by the valid two-leg sum, giving

    P_tail<=(64Lambda/3)e^(5/2)sqrt(K)n^3(n+1)e^(-T)W_beta.

The original rho<=beta source ledger is used once after the complete j/time sum. No comparison nu<=beta, new source copy, latent-component FIRST, or previously consumed signed credit enters this transfer. Terminal-source and absorption ledgers remain upstream hypotheses, not newly certified here.

## 6. Exact route partition and parameter qualification

For a prescribed epsilon>0 the author's T_epsilon=log_+[(64Lambda/3)e^(5/2)sqrt(K)n^3(n+1)/epsilon] pays the stated tail by epsilon W_beta, including the case when the logarithm is nonpositive. Its exact complement has ns+D1<H_epsilon=1+(2/c)(B_c+T_epsilon), hence D1<H_epsilon. The constants depending on c are enormous but finite and dimension independent.

The O(log(n+2)) assertion for H_epsilon is accepted here for FIXED Lambda,K,epsilon, or more generally when

    log_+Lambda+(1/2)log_+K+log_+(1/epsilon)=O(log(n+2)).

The exact displayed formula always retains these dependencies. This receipt does not certify a uniform-in-Lambda,K,epsilon interpretation or remove source-pair-dependent parameters from their original outer averages. The author's shorter 'fixed K,epsilon' wording is read with Lambda a fixed structural parameter; if Lambda varies, the explicit condition above must be retained.

On the supplied current R279 moving residual, ns+R2<=D implies both individual qualifications needed by the generic raw/score estimates. Make the exceptional branches disjoint, for example n<1024 first, and then n>=1024 with s>1/1024. The finite-dimensional branch has kappa_0<6 and price <=96Lambda sqrt(nD)S_D. On the high-soft branch n<1024D gives kappa_0<2+4sqrt(D), yielding the stated 16Lambda(2+4sqrt(D))sqrt(nD)S_D. For D=O(log(n+2)) and the inherited full-soft logarithmic source factor, these are root-polylog payments.

On n>=1024,s<=1/1024, allocate the new linear tail and then its exact complement. The complement's actual D1 bound is paid by the already independently audited R288 D1-clock theorem. The author uses the valid sharper two-way score integral

    J_n(H)=H log(n/H)+(n-H)log[n/(n-H)]    if 0<H<n/2,
    J_n(H)=n log2                        if H>=n/2,
    J_n(0)=0.

Its bound J_n(H)<=H[1+log_+(n/H)] holds in all regimes. Combined with the FULL actual R283 raw near price 2kappa_0 S_D, and one original outside 2Lambda, this gives exactly 4Lambda kappa_0 J_n(H)S_D. There is no second sqrt(nD) fee. The smaller actual physical window can be enlarged positively to xi in [1/2,1]. The unique actual j is kept through this alternative scalar-first clock argument; it is not confused with the different all-grid j/time summation used on the tail.

These branches pay the entire PRECISE CURRENT MOVING POSITIVE ROUTE under the stated upstream residual hypotheses and structural parameter control. Their responsibility masks can include the existing R287 fractional/capture residual without recharging earlier paid traffic. The excluded third J target and every earlier reduction, signed term and absorption step remain separate global-ledger obligations. No full general weak theorem is asserted by this receipt.

## 7. Actually run bounded checks and evidence limits

A fresh local Fraction run checked 1,002 small-r algebra/normalizer inequalities on r=j/1000, j=0,...,500, twelve safe common-soft menu instances, the exact rational square-root margin, and both coefficient comparisons. Output:

    PASS exact small-r algebra inequalities=1002 safe common-soft menu instances=12
    sqrt-gap rational margin=65/262144
    Exact finite algebra checks only; no global ledger certification.

The existing local vendored mpmath was used for a fresh 50-digit check of thirty sharper linear-clock formulas and their bounds through n=1024, including zero, tiny-H and saturated regimes. Output:

    PASS sharper linear clock equality/bound cases=30
    50-digit scalar diagnostics only; no interval or global-ledger certificate.

These local finite checks are mathematical diagnostics, not full-history examples, outward-rounded interval certificates, or proof of source/posterior correlation. The analytic proof establishes the universal kernel/menu/source statements. The parent's separately reported continuous-kernel numerical tests and the separate global-ledger audit were not re-run or certified by this bounded receipt.

**Frozen final receipt: PASS at the corrected author hash in Section 2, with explicit fixed-parameter/polylog qualification as in Section 6. The current moving-route completion is conditional on its stated upstream ledgers; the whole global conclusion is not certified here. Only this owned temporary audit file was written for this extension.**
