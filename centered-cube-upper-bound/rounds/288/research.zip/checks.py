#!/usr/bin/env python3
"""Bounded R288 score algebra and actual C activation diagnostics."""
import json,random
from pathlib import Path
import mpmath as mp
R=random.Random(28820261017)
# Sole copied dependency: C from /tmp/r279_numeric.py, no module import.
def C(r):
 r=abs(r)
 return 1-r+mp.mpf(1)/3-mp.expint(4,r)-mp.expint(4,1)+mp.expint(4,r+1) if r<=1 else mp.expint(4,r-1)-2*mp.expint(4,r)+mp.expint(4,r+1)

def score(n,H,D,h):return min(n,H/h,D/(h*h))
def integral(n,H,D,T):
 if not H or not D:return mp.mpf(0),mp.mpf(0)
 points=sorted(set([mp.mpf(0),T]+[p for p in [H/n,D/H,mp.sqrt(D/n)] if 0<p<T]));exact=mp.mpf(0);quad=mp.mpf(0)
 for a,b in zip(points,points[1:]):
  t=(a+b)/2;vals=[mp.mpf(n),H/t,D/t**2];branch=vals.index(min(vals))
  def primitive(h):
   if branch==0:return -n*mp.log1p(-h)
   if branch==1:return H*(mp.log(h)-mp.log1p(-h))
   return D*(-1/h+mp.log(h)-mp.log1p(-h))
  exact+=primitive(b)-primitive(a)
  quad+=mp.quad(lambda h:score(n,H,D,h)/(1-h),[a,b])
 # Independently evaluate the authored two possible envelope orders.
 def NN(t):return -n*mp.log1p(-t)
 def LL(t):return H*(mp.log(t)-mp.log1p(-t))
 def QQ(t):return D*(-1/t+mp.log(t)-mp.log1p(-t))
 if H*H<=n*D:
  u=min(T,H/n);v=min(T,D/H);closed=NN(u)+(LL(v)-LL(u))+(QQ(T)-QQ(v))
 else:
  u=min(T,mp.sqrt(D/n));closed=NN(u)+(QQ(T)-QQ(u))
 assert abs(closed-exact)<=mp.mpf('1e-30')*max(1,abs(exact))
 return exact,quad

def scorecases(count,spread,ns):
 cases=[]
 for j in range(count):
  with mp.workdps(90):
   n=ns[j%len(ns)];H=mp.mpf(10)**R.randint(-spread,spread);D=mp.mpf(10)**R.randint(-spread,spread);T=mp.mpf(R.choice(['0.5','0.1','0.000001']))
   if j%8==0:H=mp.mpf(0)
   elif j%8==1:D=mp.mpf(0)
   elif j%8==2:D=H*H/n
   cases.append((n,*[mp.nstr(x,85) for x in [H,D,T]]))
 err=mp.mpf(0);prec=mp.mpf(0);maxratio=mp.mpf(0)
 for n,hh,dd,tt in cases:
  results=[]
  for dp in [40,60]:
   with mp.workdps(dp):
    H,D,T=map(mp.mpf,[hh,dd,tt]);x,y=integral(n,H,D,T)
    e=abs(x-y)/max(1,abs(x));assert e<mp.mpf('1e-30');err=max(err,e)
    bounds=[n*mp.log(2),4*mp.sqrt(n*D),2*H*(1+max(0,mp.log(mp.mpf(n)/(2*H)))) if H else mp.mpf(0)]
    bound=min(bounds);assert x<=bound+mp.mpf('1e-30')*max(1,bound)
    if bound:maxratio=max(maxratio,x/bound)
    results.append(+x)
  with mp.workdps(80):prec=max(prec,abs(results[0]-results[1])/max(1,abs(results[1])))
 assert prec<mp.mpf('1e-30')
 return {'cases':count,'precision_runs':2*count,'max_analytic_vs_quad_normalized_error':mp.nstr(err,12),'max_40_vs_60_normalized_error':mp.nstr(prec,12),'max_J_to_uniform_min_bound_ratio':mp.nstr(maxratio,12),'max_bound_violation':'0','n_values':ns}

def geometries(ns):
 count=0;acts=0;maxrat=mp.mpf(0)
 for dp in [40,60]:
  with mp.workdps(dp):
   cache={}
   for n in ns:
    for style in ['concentrated','sparse','diffuse','capped']:
     if style=='concentrated':rs=[mp.mpf('0.4')]+[mp.mpf(0)]*(n-1)
     elif style=='sparse':rs=[mp.mpf('0.1') if i%7==0 else mp.mpf(0) for i in range(n)]
     elif style=='diffuse':rs=[mp.mpf('0.4')/n]*n
     else:rs=[mp.mpf(['0','0.01','0.2','1','3'][i%5]) for i in range(n)]
     caps=[min(abs(r),1) for r in rs];H=sum(caps);D=sum(r*r for r in caps);eta=max(caps)
     cs=[]
     for r in rs:
      key=str(r)
      if key not in cache:cache[key]=C(r)
      cs.append(cache[key])
     assert all(1-c<=r+mp.mpf('1e-35') for c,r in zip(cs,caps))
     for h in [mp.mpf('1e-8'),mp.mpf('.001'),mp.mpf('.1'),mp.mpf('.5'),eta,eta+mp.mpf('.01')]:
      if h<=0:continue
      k=sum(c<1-h for c in cs);bound=min(n,H/h,D/h**2)
      assert k<=bound*(1+mp.mpf('1e-30'))
      if h>=eta:assert k==0
      if bound:maxrat=max(maxrat,k/bound)
      acts+=k;count+=1
 return {'activation_checks':count,'precision_values':[40,60],'total_activated_coordinates':acts,'max_count_to_score_bound_ratio':mp.nstr(maxrat,12),'max_activation_violation':'0','max_vanishing_violation':'0','n_values':ns}

def profiles(count,ns):
 cases=[]
 for j in range(count):
  with mp.workdps(90):
   n=ns[j%len(ns)];eta=mp.mpf(R.choice(['.5','.1','.000001']));delta=eta*[mp.mpf(1),mp.sqrt(n),mp.mpf(n)][j%3];aob=mp.mpf(R.choice(['.5','.75','.999999']))
   tiny=(j%4==0)
   if tiny:eta=delta=1/(8*mp.sqrt(n))
   if j==1:eta=delta=mp.mpf(0)
   cases.append((n,*[mp.nstr(x,85) for x in [eta,delta,aob]],tiny))
 maxratio=mp.mpf(0);prec=mp.mpf(0);cerr=mp.mpf(0);tinymax=mp.mpf(0)
 for n,ee,dd,aa,tiny in cases:
  vals=[]
  for dp in [40,60]:
   with mp.workdps(dp):
    eta,delta,aob=map(mp.mpf,[ee,dd,aa]);T=1-aob;gamma=1+mp.mpf(1)/n;m=min(T,eta,delta)
    if m==0:K=price=qprice=mp.mpf(0)
    else:
     points=sorted(set([mp.mpf(0),m]+[x for x in [delta/n,1-gamma*aob] if 0<x<m]))
     def kernel(h):
      z=min(n,delta/h) if h else n
      A=1+n*mp.log(1/max(aob,(1-h)/gamma))
      assert A<=2+2*n*h+mp.mpf('1e-30')
      return z*A/(1-h)
     K=sum(mp.quad(kernel,[a,b]) for a,b in zip(points,points[1:]))
     if m<=delta/n:price=4*n*m+2*n*n*m*m
     else:price=4*delta*(1+mp.log(n*m/delta))+4*n*delta*m-2*delta**2
     ppoints=sorted(set([mp.mpf(0),m]+[delta/n] if 0<delta/n<m else [mp.mpf(0),m]))
     qprice=4*sum(mp.quad(lambda h:min(n,delta/h)*(1+n*h),[a,b]) for a,b in zip(ppoints,ppoints[1:]))
    err=abs(price-qprice)/max(1,abs(price));assert err<mp.mpf('1e-30');cerr=max(cerr,err)
    assert K<=price+mp.mpf('1e-30')*max(1,price)
    loose=4*delta*(1+mp.log(n))+4*n*delta*eta
    assert price<=loose+mp.mpf('1e-30')*max(1,loose)
    if price:maxratio=max(maxratio,K/price)
    if tiny:
     bound=(1+mp.log(n))/(2*mp.sqrt(n))+mp.mpf(1)/16
     assert price<=bound+mp.mpf('1e-30') and bound<mp.mpf('.75');tinymax=max(tinymax,bound)
    vals.append(+K)
  with mp.workdps(80):prec=max(prec,abs(vals[0]-vals[1])/max(1,abs(vals[1])))
 assert prec<mp.mpf('1e-30')
 return {'cases':count,'precision_runs':2*count,'gamma':'1+1/n','max_K_to_exact_majorant_ratio':mp.nstr(maxratio,12),'max_majorant_formula_vs_quad_normalized_error':mp.nstr(cerr,12),'max_K_40_vs_60_normalized_error':mp.nstr(prec,12),'max_tiny_near_displayed_bound':mp.nstr(tinymax,12),'max_bound_violation':'0','includes_zero_profile':True}

settings=[('exploration',16,2,[1,2,10]),('stress',48,8,[1,10,100,1000]),('expanded',96,20,[1,100,1000,10000])]
stages=[{'name':name,'score_integral':scorecases(count,spread,ns),'actual_C_geometry':geometries(ns),'direct_FIRST_profile':profiles(count//2,ns)} for name,count,spread,ns in settings]
out={'status':'PASS','seed':28820261017,'scope':'Ordinary mpmath40/60 diagnostics of exact score integral, physical activation counts, and the direct FIRST profile scalar clock cost. Not interval, FULL source, posterior or FIRST/history certificates. Sole copied dependency C from /tmp/r279_numeric.py.','stages':stages}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,sort_keys=True,indent=2)+'\n');print(json.dumps(out,sort_keys=True,indent=2))
