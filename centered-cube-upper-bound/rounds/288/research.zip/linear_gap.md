# R288 — small-soft linear normalized affinity gap and original moving-source tail

## 1. Screened theorem and precise source consequence

The proposed linear gap is valid. It holds for independent source/target soft parameters s,sigma in [0,1/512], not merely for sigma=s. Let b/2<=L<=A<=b, r=|y-v|/b,

p=L^(-1)f_s((x-y)/L), q1=A^(-1)f_sigma((x-v)/A),
Omega=min(1,b C(r)/L),
D_aff=Omega^(-1/2) integral_{Q_b(y)} sqrt(p q1) dx.

With the SAME R279 constants kappa=25/2^68 and c=kappa/432,

D_aff <=exp[-c{s+min(r,1)}].                              (L)

Consequently, for the two ORIGINAL moving targets K1=P_(s,L), K2=P_(s,min(b,gamma L)), restricted to actual s<=1/1024 and n>=1024, the complete R279 source proof applies with

D1(y,v)=sum_i min(|y_i-v_i|/b,1)

in place of R2. Let B_c=18exp(4c)/c and T>=0. On the ACTUAL gate

ns+D1(y,v)>=1+(2/c)(B_c+T),                               (Tgate)

the original near positive traffic in the raw certification union E1 union E2 obeys

P_mov,Tgate <=(64Lambda/3)e^(5/2)sqrt(K)
                    n^3(n+1)e^(-T) W_beta.               (SP)

All original sources, actual receiver measure dx, high/FIRST, full Pi, accepted-source/history/capture masks and original endpoints remain. This is a new linear-displacement tail source payment, not a fixed-parameter statement substituted for an adaptive integral. The third J target is NOT covered by the small-target-soft lemma; its separately established R277 payment is required when using this consequence on the remaining moving route.

The proof below audits the fixed kernel, collar, actual menu and source transfer. Section 7 states the exact conditional closure of the current moving positive route when the existing R279 and R283 ledgers are supplied. It does not claim that all earlier global reduction ledgers have been audited here.

## 2. Small-soft hard-core separation, with exact constants

Set epsilon=1/512. Let I,J be the hard support intervals centered at y,v with lengths L,A. Both phi and h are bounded by one. On I\J, p>=(1-s)/L>=(1-epsilon)/A while q1<=sigma/A<=2epsilon/A. On J\I, q1>=(1-sigma)/A>=(1-epsilon)/A while p<=s/L<=2epsilon/A because A/L<=2. Thus on the whole symmetric difference,

(sqrt(p)-sqrt(q1))^2
 >=A^(-1)(sqrt(1-epsilon)-sqrt(2epsilon))^2
 >=(7/8)A^(-1).                                         (1)

For the exact last comparison, sqrt(1-epsilon)>=1-epsilon=511/512 and sqrt(2epsilon)=1/16. Hence the squared difference is at least (479/512)^2, and 479^2=229441>229376=(7/8)512^2.

For intervals of lengths L<=A with center distance d, their symmetric difference has length at least 2min(d,L). This follows by separating containment, partial overlap and disjointness: the lengths are respectively A-L, 2d, and A+L; in the containment regime A-L>=2d.

Let H=int_R sqrt(p q1). Both kernels are probability densities. Hence

1-H=(1/2)int_R(sqrt(p)-sqrt(q1))^2
 >=(7/8)min(rb,L)/A.

If 0<=r<=1/2, L>=b/2 gives rb<=L, and A<=b yields

1-H>=(7/8)r,
H^2<=(1-7r/8)^2<=1-(175/128)r.                           (2)

The last step uses r^2<=r/2. No source distribution product assumption is involved; these are one-dimensional normalized kernel densities.

## 3. Normalizer and all-distance/soft combination

Since L<=b and C(r)>=(1-r)_+, for 0<=r<=1/2,

Omega>=min(1,C(r))>=1-r.

The Q_b(y) affinity is at most H, so (2) gives

D_aff^2<=H^2/Omega
 <=[1-(175/128)r]/(1-r)
 =1-47r/[128(1-r)]<=1-(47/128)r.

Therefore

D_aff<=exp[-47r/256],  0<=r<=1/2.                        (3)

This is an upper bound on the NORMALIZED common-window affinity. It does not rely on the false assertion that division by sqrt(Omega) always preserves affinity<=1.

For r>1/2 the audited R279 all-soft quadratic estimate gives

D_aff<=exp[-(3kappa/128)min(r^2,1)]
       <=exp[-(3kappa/256)min(r,1)].                      (4)

The second implication uses min(r^2,1)>=(1/2)min(r,1) on this range. Combining (3) and (4), noting 47>=3kappa, yields the all-distance bound with coefficient 3kappa/256. Independently R279 proves D_aff<=exp[-kappa s/216]. Take the geometric mean of these two valid upper bounds:

D_aff<=exp[-kappa s/432-(3kappa/512)min(r,1)]
       <=exp[-c{s+min(r,1)}],

because 3/512>=1/432. This proves (L), with exactly the SAME c as R279.

## 4. Collar tensorization has the SAME paid constant

Retain the R278/R279 one-dimensional collar estimate

int_{Q_(b+d)(y)\Q_b(y)} sqrt(p q1)/sqrt(Omega)
 <=48 epsilon_h sqrt(s),  epsilon_h=d/b,

d=a/(8sqrt(n)). It holds for independent target sigma and all legal L,A, so it applies to the present restricted parameters without change. It includes target-hard contributions on the collar; no exact-min theorem is used at an enlarged hard scale.

Each exponent s+min(r,1) is at most 2. Tensorizing (L) together with the collar bound over the TRUE near receiver window W_y=Q_(b+d)(y) gives

int_{W_y} sqrt(P_(s,L)(x-y)P_(sigma,A)(x-v)/barw_L(y,v)) dx
 <=exp[-c(ns+D1)+48e^(2c)n epsilon_h sqrt(s)]
 <=exp[-c(ns+D1)+6e^(2c)sqrt(ns)]
 <=exp[B_c-(c/2)(ns+D1)].                                (5)

The last Young inequality is 6e^(2c)sqrt(ns)<=(c/2)ns+B_c. Fixed source kernel products, not source measures, are tensorized. This is the exact R279 collar argument with R2 replaced by D1.

## 5. Actual moving menu: source/target softness and scale order checked

For the original common s, choose k=min(n,floor(ns)+1) and sigma_k=k/(n+1). The established positive coefficient inequalities give f_s<=gamma f_(sigma_k), gamma=1+1/n, and |sigma_k-s|<=1/n. The two ACTUAL moving targets have the SAME s as the source. Therefore both source and target are rounded to this SAME sigma_k; no independently large target-soft parameter is introduced.

If actual s<=1/1024 and n>=1024,

sigma_k<=s+1/n<=1/512.                                   (6)

Thus every node used on this restricted physical branch satisfies the hypotheses of (L) and (5). The original all-soft n-node menu may be restricted to these nodes; its count remains at most n. The fact that R279 originally proved a lemma for arbitrary independent sigma does not mean the two actual moving targets require a large sigma menu. The separate target J=P_(1,b) does require sigma=1 and must remain in its separately paid route.

Round L upwards to a geometric node B in [a,b], with B/L<=gamma; there are at most n+1 such nodes. Set the rounded targets to A1*=B and A2*=min(b,gamma B). Then

b/2<=B<=A_i*<=b,
A1*/L<=gamma,
A2*/min(b,gamma L)<=gamma.

Even kernels are decreasing away from zero, so scale enlargement contributes the established positive density factors. The two soft coefficient inflations and two scale inflations in the halfproduct cost at most gamma^(2n)<=e^2 altogether. The clamp denominator satisfies barw_B<=barw_L, which is the correct direction for upper domination of inverse square roots.

At the selected node, n sigma_k>=ns-1. Thus (Tgate) implies the STATIC node condition

n sigma_k+D1>=(2/c)(B_c+T).                               (7)

D1 is independent of receiver and scale. Retain (7) inside every fixed node column. Equation (5) gives column L1 mass <=e^(-T). Each actual moving leg therefore has a finite nonnegative envelope, with its true window 1_{W_y}(x), of mass at most

e^2 n(n+1)e^(-T).                                        (8)

No fixed-parameter integral has been used as the integral of an adaptive parameter supremum: the finite menu in (8) explicitly pays that operation. Source and target scales, target softness, normalizer direction and the retained window have all been checked.

## 6. Full original source and posterior transfer

On each original raw moving certification event Ei,

p_y w_g(v)<=K Ki(v)
 => p_y<=sqrt(K) sqrt(p_y Ki(v)/w_g(v)).

The original actual band gives c_jg<=gamma L and hence

w_g>=gamma^(-n)barw_L,

adding the factor gamma^(n/2)<=sqrt(e). On an original near pair with h_R(x-z)>0, x lies in W_y. Retain this window before using the ORIGINAL hard maximal cap on E:

q^(-1)(h_R*nu)(x)<=4lambda/q<=16/3.

The full original posterior Pi_(y,j,t)=1_Zt w_t nu/e_t remains unchanged. For fixed ORIGINAL y,j,t it is independent of receiver x; the target menu and actual static node gate permit receiver integration first. Only after this legitimate envelope step are the complete two-posterior probability mass <=1 and score <=n used.

The original legal j/time menu is paid by the established exact sum

sum_{j>=0}(log(b/a)-2j log gamma)_+<=n.

Its cost is not silently replaced by a receiver-independent posterior after a physical clock substitution. The single original outer factor 2Lambda, cap factor 16/3, halfproduct band cost sqrt(e), kernel menu e^2 n(n+1), score n and j/time n give, per moving leg,

(32Lambda/3)e^(5/2)sqrt(K)n^3(n+1)e^(-T)W_beta.

Split the union as E1 and E2\E1, or simply use the valid two-leg upper estimate, to obtain (SP). The original rho<=beta mass is summed once AFTER the complete j/time cost. Original terminal beta_V<=alpha_V disjointness supplies W_beta<=||f||_1. No nu<=beta relation, node FIRST, source-coordinate independence, local posterior renormalization or old signed credit is used.

For any epsilon>0 choose

T_epsilon=log_+[(64Lambda/3)e^(5/2)sqrt(K)n^3(n+1)/epsilon].

Then the indicated actual tail costs <=epsilon W_beta. Its exact complement has ns+D1<H_epsilon with

H_epsilon=1+(2/c)(B_c+T_epsilon).                          (9)

For fixed K,epsilon, this is O(log(n+2)), with very large explicit absolute constants inherited from c. No positive tail coverage or practical smallness of those constants is asserted.

## 7. Conditional sufficiency for the current moving positive route

This section checks the proposed connection to the existing R283 raw near theorem, not the entirety of the older global reduction ledger.

Assume the ORIGINAL current moving remainder already satisfies the accepted R279 qualification ns+R2<=D, and use its R283 FULL-soft raw source bound

T_near<=2kappa_0 S_D,
kappa_0=2+sqrt(n)/8,
S_D=(16/3)W_rho+(1+log B_*(n,D))W_nu.                    (10)

The archived R283 proof explicitly retains actual selectors/caps, original coarse-pair source allocation and all soft tails; (10) is not a local-packet or fixed-channel diagnostic. Its formula has B_*=O(log^4 n) when D=O(log n).

On the new complementary upper-slot gate D1<=H, actual activation implies k_t(v)<=min(n,H/(1-xi)). This is proved BEFORE the physical substitution, retaining the original full posterior and upper slot. Define

J_n(H)=integral_(1/2)^1 min(n,H/(1-xi)) dxi/xi.

For H=0 it is zero. For 0<H<n/2 it equals

J_n(H)=H log(n/H)+(n-H)log[n/(n-H)],

and for H>=n/2 it equals n log 2. Thus always

J_n(H)<=H[1+log_+(n/H)].                                 (11)

Applying (10) on each actual physical receiver subset and keeping the unique actual j gives the source price

P_smallsoft,D1<=H <=4Lambda kappa_0 J_n(H) S_D.             (12)

For H=O(log(n+2)), (12) is root-polylog. There is no second square-root score fee; (11) replaces the old quadratic-distance fee.

The physical branch excluded from the small-soft menu also has a controlled price under ns<=D. If s>1/1024, then n<1024D and kappa_0<2+4sqrt(D). The existing R283/R280 quadratic-score estimate gives

P_exception <=16Lambda(2+4sqrt(D))sqrt(nD) S_D.             (13)

For n<1024, kappa_0<6 gives instead the valid generic price 96Lambda sqrt(nD) S_D, regardless of s. These are root-polylog for D=O(log(n+2)); they introduce no new unproved soft-menu restriction.

Therefore, CONDITIONAL ON the supplied upstream payments that leave only the current moving positive route with ns+R2<=D, that route is paid by the disjoint physical exception branch, the new linear tail (SP), and (12) on its complement. The third J payment, earlier reductions, terminal source ledgers and any absorption constants must still be checked by the parent before claiming the full general centered-cube conclusion.

## 8. Executed local checks

Actual Python Fraction arithmetic passed 1,504 exact gap/normalizer comparisons, 84 interval symmetric-difference cases and 16 small-soft node cases (n=1024,1025,4096,1000000, including actual s=0 and s=1/1024). The normalizer test used Omega>=1-r; the proof correctly obtains this as Omega>=min(1,C(r))>=1-r, without asserting C(r)<=1.

An actual 50-decimal mpmath calculation tested 30 L1 clock integrals across n=1,2,8,64,1024, splitting at H/n and including the saturated regime H>=n/2. Every integral matched the binary-entropy formula and its displayed bound; maximum normalized discrepancy was 9.04e-50.

These tests verify finite algebra and scalar integration only. They are not interval certificates, original full-history examples, or a substitute for the analytic kernel/menu/source proof above.
