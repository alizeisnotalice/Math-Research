#!/usr/bin/env python3
"""Small-soft actual normalized core affinity; ordinary precision refinement only."""
import json,hashlib
from pathlib import Path
from fractions import Fraction as F
import mpmath as m

def mm(x):
 q=F(str(x));return m.mpf(q.numerator)/q.denominator
# Actual E3 convolution kernel and E4 C, copied from R279 numeric definitions.
def phi(x):
 x=abs(x)
 return 1-m.expint(3,m.mpf('.5')-x)-m.expint(3,m.mpf('.5')+x) if x<=m.mpf('.5') else m.expint(3,x-m.mpf('.5'))-m.expint(3,x+m.mpf('.5'))
def C(r):
 r=abs(r)
 return 1-r+m.mpf(1)/3-m.expint(4,r)-m.expint(4,1)+m.expint(4,r+1) if r<=1 else m.expint(4,r-1)-2*m.expint(4,r)+m.expint(4,r+1)
def P(s,L,x):return ((1-s)*int(abs(x)<L/2)+s*phi(x/L))/L
MENU={
 'initial': [('0','0','1','1','0'),('1/512','1/512','1','1','1/10'),('0','1/512','1/2','1','1/4'),('1/512','0','7/10','1','1/2')],
 'boundary_stress':[('0','0','1/2','1/2','1/2'),('1/512','1/512','1','1','1/1000000000000'),('1/512','0','1/2','1','0'),('0','1/512','1','1','499999999999/1000000000000'),('1/512','1/512','1/2','1/2','1/1000000'),('1/1048576','1/512','7/10','7/10','1/2')],
 'expanded':[('1/512','1/1024','1/2','7/10','1/100'),('1/1024','1/512','7/10','9/10','3/10'),('1/2048','1/4096','9/10','1','49/100'),('1/512','0','999/1000','1','1/1000000'),('0','1/512','1/2','501/1000','1/1000'),('1/512','1/512','501/1000','999/1000','1/2'),('1/1000000000','1/512','7/10','1','1/1000000000'),('1/512','1/1000000000','1','1','1/3')]
}
def run(case,dp):
 with m.workdps(dp):
  s,t,L,A,r=map(mm,case);assert 0<=s<=mm('1/512') and 0<=t<=mm('1/512') and mm('1/2')<=L<=A<=1 and 0<=r<=mm('1/2')
  omega=min(1,C(r)/L);assert omega>=1-r-m.mpf('1e-35')
  lo=max(-m.mpf('.5'),-L/2 if s==0 else -m.inf,r-A/2 if t==0 else -m.inf)
  hi=min(m.mpf('.5'),L/2 if s==0 else m.inf,r+A/2 if t==0 else m.inf)
  knots=sorted(set([lo,hi]+[x for x in [-L/2,L/2,0,r-A/2,r+A/2,r] if lo<x<hi]))
  core=sum(m.quad(lambda x:m.sqrt(P(s,L,x)*P(t,A,x-r)),[a,b]) for a,b in zip(knots,knots[1:])) if lo<hi else m.mpf(0)
  D=core/m.sqrt(omega);bound=m.exp(-mm('47/256')*r);margin=bound-D
  assert margin>=-m.mpf('1e-30')
  return tuple(+x for x in [omega,core,D,bound,margin])

# Exact constants used in the independent screen.
eps=F(1,512);gap=F(479,512)**2-F(7,8);assert gap==F(65,262144)>0
assert F(479,512)+F(1,16)==1-eps
assert F(7,8)**2*F(1,2)-F(7,4)==-F(175,128)
assert F(175,128)-1==F(47,128)
assert F(47,128)/2==F(47,256)
# sqrt(1-eps)>=1-eps and sqrt(2eps)=1/16 supply the rational gap.
stages=[]
for stage,cases in MENU.items():
 rows=[];worst=m.mpf(0);maxratio=m.mpf(0)
 for case in cases:
  low=run(case,40);high=run(case,60)
  with m.workdps(90):
   err=max(abs(a-b)/max(1,abs(b)) for a,b in zip(low,high));assert err<m.mpf('1e-25');worst=max(worst,err);maxratio=max(maxratio,high[2]/high[3])
   row={'s':case[0],'sigma':case[1],'L_over_b':case[2],'A_over_b':case[3],'r':case[4],'max_normalized_40_vs_60_error':m.nstr(err,15)}
   row.update({key:m.nstr(value,75) for key,value in zip(['Omega','raw_core_affinity','normalized_core_affinity','exp_minus_47r_over256','bound_margin'],high)})
   rows.append(row)
  print('PASS',stage,case,flush=True)
 stages.append({'name':stage,'cases':len(cases),'precision_runs':2*len(cases),'max_normalized_40_vs_60_error':m.nstr(worst,15),'max_D_to_bound_ratio':m.nstr(maxratio,15),'max_bound_violation':'0','rows':rows})
out={'status':'PASS','scope':'Actual one-dimensional f_s=(1-s)h+s phi normalized receiver-core integrals with b=1, y=0, v=r and independent small source/target softness. Finite ordinary mpmath40/60 evidence, not outward intervals, full affinity integration, a tensor/source/history certificate, or a global ledger audit. Formula dependency: phi and C from /tmp/r279_numeric.py; statement /tmp/r288_linear_screen.md.','exact_fraction_checks':5,'exact_squared_gap_margin':str(gap),'stages':stages}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,sort_keys=True,indent=2)+'\n')
print(json.dumps({'status':'PASS','stage_cases':[len(x) for x in MENU.values()],'max_precision_error':max(float(s['max_normalized_40_vs_60_error']) for s in stages)}))
