"""One-dimensional layer-cake checks underlying the signed empirical CDF test."""
from fractions import Fraction as F
import json
from random import Random
from math import sqrt

def length(intervals):
    ans=F(0)
    right=None
    for a,b in sorted(intervals):
        if right is None or a>=right: ans+=b-a
        elif b>right: ans+=b-right
        right=b if right is None else max(right,b)
    return ans
def test(stage,separation):
    checks=0
    for z in [F(i,separation) for i in range(-separation,separation+1)]:
        for boost in [F(1,2),F(1),F(3,2),F(2)]:
            for level in [F(i,13) for i in range(1,26)]:
                # Superlevel intervals of a tent tilted by a single step.
                t=1-level/boost
                u=1-level
                raw=[(-t,min(t,z)),(max(-u,z),u)]
                raw=[(x,y) for x,y in raw if x<y]
                for a in [F(1,32),F(1,4),F(1),F(2)]:
                    dil=length([(x-a/2,y+a/2) for x,y in raw])
                    assert dil<=length(raw)+2*a
                    checks+=1
    return {'stage':stage,'exact_checks':checks}
def inverse_test(seed):
    rng=Random(seed)
    n=rng.randint(8,128)
    xs=sorted(F(rng.randrange(129),128)-F(1,2) for _ in range(n))
    knots=sorted(set(xs+[F(-1,2),F(1,2)]))
    # The integrated CDF discrepancy is piecewise quadratic, with stationary
    # point t=F_empirical-1/2 in each support interval.
    candidates=set(knots)
    for left,right in zip(knots,knots[1:]):
        p=F(sum(x<=left for x in xs),n)
        s=p-F(1,2)
        if left<=s<=right:candidates.add(s)
    err=max(abs(sum((max(F(0),s-x) for x in xs),F(0))/n-(s+F(1,2))**2/2) for s in candidates)
    ks=max(max(abs(F(sum(x<s for x in xs),n)-s-F(1,2)),abs(F(sum(x<=s for x in xs),n)-s-F(1,2))) for s in knots)
    assert ks*ks<=4*err
    return float(ks),float(err)
def main():
    pairs=[inverse_test(i) for i in range(128)]
    print(json.dumps({'step_tilt':[test(k,n) for k,n in [('initial',2),('edge_stress',5),('expanded',16)]],'exact_inverse_cdf_trials':len(pairs),'largest_KS_over_sqrt_integrated_error':max(k/sqrt(e) for k,e in pairs if e)},indent=2))
if __name__=='__main__':main()
