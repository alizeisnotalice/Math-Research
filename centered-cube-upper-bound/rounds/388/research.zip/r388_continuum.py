"""R388 genuine du positive middle branch; exact Fraction, stdlib only."""
from fractions import Fraction as F
from itertools import product
from math import factorial
from pathlib import Path
import json,hashlib
COUNT=0

def ck(x):
 global COUNT
 assert x
 COUNT+=1

def elog_bounds(x,N=32):
 assert x>=1
 k=0
 while x>2:x/=2;k+=1
 def one(z):
  t=(z-1)/(z+1)
  lower=2*sum((t**(2*j+1)/F(2*j+1) for j in range(N)),F(0))
  return lower,lower+2*t**(2*N+1)/(F(2*N+1)*(1-t*t))
 l,u=one(x);l2,u2=one(F(2));return l+k*l2,u+k*u2

exp4lo=sum((F(4**j,factorial(j)) for j in range(41)),F(0))
exp4hi=exp4lo+F(4**41,factorial(41))/(1-F(4,42))
ck(54<exp4lo<exp4hi<55)

def case(s,P,Bfactor,delta):
 n=16;bg=F(3,4);rv=F(3,4);rs=F(1,2);B=Bfactor*s
 ws=s**n;wv=ws;wb=B**n;Vd=F(1,100)**n
 m0=bg*rs**n;ms=m0+P;mv=bg*rv**n+P;mu=bg+P
 qs=ms/rs**n;qv=mv/rv**n;qu=mu;fD=bg+P/Vd
 C0=F(2);Dnew=F(2);d=F(1,1000);tau=d
 for q in [bg,qs,qv,qu]:ck(bg<=q<=1)
 ck(mu>55*mv and mv>55*ms)
 # Complete source/cube geometry for all receivers of the three positive types.
 lo=[F(47,100)]+[F(1,10)]*15;hi=[F(12,25)]+[F(11,100)]*15
 for centers,R,side in [([F(0)]*n,F(1),B),([F(7,10)]+[F(1,4)]*15,rv,s),([F(1,4)]*n,rs,s)]:
  for i in range(n):
   ck(centers[i]+side/2-R/2<=lo[i] and centers[i]-side/2+R/2>=hi[i])
   ck(abs(centers[i])+side/2+R/2<2)
 ck(s/2<min(lo)) # negative-coordinate sign tiles exclude D
 ck(B>s and B<F(1,100))
 ck(F(1,4)+s/2+rs/2==(1+s)/2)
 ck(-F(1,4)+s/2+rs/2>=F(1,4)-s/2-rs/2)
 ck(B/2+s/2<F(1,4) and s<F(9,20)) # disjoint receivers
 # Actual big/mid original spatial gates on the entire pair boxes.
 e=(B+s)/2
 distances=[F(7,10)]+[F(1,4)]*15
 mins=[x-e for x in distances];excess=[2*x-(1-rv) for x in mins]
 ck((2*max(mins))**n>5)
 ck(all(x>0 for x in excess) and n>F(n,8))
 ck(sum(excess)>F(n,20))
 beta=1+F(1,n);allowance=n*((1+beta)*rv-1)**2/(4*beta*rv)
 ck(sum(excess)>allowance)
 ck((2*(F(1,4)+e))**n<5) # big->small outside fails
 Tsource=1+(n+1).bit_length()
 ck(Tsource==6 and fD>Tsource*max(qs,qv,qu))
 # Frozen source-dependent ranks use EVERY original receiver, not a new field.
 h=ws/(10*ms);H=h
 Tsmall=ws/ms;Tmid=Tsmall+wv/mv;Tbig=Tmid+wb/mu
 Zbig=Tmid;Zmid=Tsmall
 ck(Zbig>h and Zmid>h and Tbig>H)
 ck(Tbig<F(8,5)*Tsmall)
 levels=[];level=2*h
 while level<=Tbig:
  ck(level<=Tsmall);levels.append(level);level*=2
 ck(len(levels)==3 and level>Tbig)
 ck(Tmid>2*h and Zmid>h and mv>55*ms and mu>55*ms)
 ell=[rs**(-n)-rv**(-n),rv**(-n)-1,F(1)]
 ck(sum(ell)==rs**(-n) and ell[-1]==1)
 # R387's near and low-relative-rank receipts both fail on this branch.
 rankratio=Tbig/Tmid-1
 ck(rankratio>d and Tmid>tau*Zbig)
 # Exact integrated original product-center target capture, with pointwise bound.
 for x in distances:ck((1-rv)/2<x-e and x+e<(1+rv)/2)
 pmean=F(7,30)*F(5,6)**15
 pmax=(F(7,30)+F(4,3)*e)*(F(5,6)+F(4,3)*e)**15
 ck(0<pmean<=pmax<1)
 piD=fD*Vd/mu
 c=(wv/mv)/Tbig*(1-mv/mu)*(1-qv/fD)
 Amin=piD*c*(1-pmax)
 ck(c*(1-pmax)>delta and Amin>2*delta)
 G=wb*wv*(1-mv/mu)*(fD-qv)*Vd/(mv*Tbig)*(1-pmean)
 ck(G==qu*wb*piD*c*(1-pmean) and G>0)
 # Actual smaller union also includes mid. Tile-only deficit is an UPPER.
 # Per coordinate loss l=(|u_i|-s/2)+; exact average on [-B/2,B/2].
 mean_l=(B-s)**2/(4*B)
 ck(mean_l>0 and mean_l<(B-s)/2)
 deficit_integral_upper=bg*wb*(1-(1-mean_l)**n)
 deficit_point_upper=bg/mu*n*(B-s)/2
 ck(C0*deficit_point_upper<Amin)
 Gmid_lower=G-C0*deficit_integral_upper
 ck(0<Gmid_lower<=G)
 # New witness uses all full-f posterior source points, including cost-zero ones.
 Jglobal=(2**n-1)*ws/m0+ws/ms+wv/mv+wb/mu
 Flower=h/(h+Jglobal)
 ck(Jglobal>=Tbig and 0<Flower<1)
 # a_mid <= a_original <= pi_big(D), for every actual big receiver.
 ck(c<=1 and Dnew*Flower>=piD)
 wcurrent=h/(h+Tbig)
 ck(Dnew*wcurrent<1) # not full payment by current-source soft factor alone
 # General source price using this legitimate receiver-field uniform J bound.
 loglo,loghi=elog_bounds(1+Jglobal/h)
 ck(0<loglo<=loghi and loghi-loglo<F(1,10**20))
 source_price_upper=Dnew*h*loghi*(bg*4**n+P)
 E=(2**n+1)*ws+wb;X=ws*((2**n-1)*bg+qs+qv)+wb*qu
 ck(bg*E<=X<=E)
 return {'receiver_side_small_mid':str(s),'big_side_factor':str(Bfactor),'P':str(P),'delta_core':str(delta),
  'G_before_R385':str(G),'Gmid_lower':str(Gmid_lower),'Gmid_upper':str(G),
  'Gmid_lower_fraction_of_G':str(Gmid_lower/G),
  'old_union_deficit_integral_upper':str(deficit_integral_upper),'old_union_deficit_point_upper':str(deficit_point_upper),
  'old_R385_coefficient':str(C0),'R386_three_payments':'0','R387_near_payment':'0','R387_lowrelative_payment':'0',
  'rank_excess':str(rankratio),'Tsmall':str(Tsmall),'Tmid':str(Tmid),'Tbig':str(Tbig),'h_H_diagnostic':str(h),
  'Jglobal_full_receiver_bound':str(Jglobal),'new_fullposterior_F_lower':str(Flower),'row_a_upper_piD':str(piD),
  'new_coefficient':str(Dnew),'new_paid_all_designated_Gmid':True,'new_remaining_designated_big_rows':'0',
  'current_source_w':str(wcurrent),'current_source_twice_w':str(Dnew*wcurrent),
  'A_lower':str(Amin),'capture_mean':str(pmean),'capture_point_upper':str(pmax),
  'full_W':str(bg*4**n+P),'full_E_volume':str(E),'full_Xq':str(X),'Gmid_lower_over_Xq':str(Gmid_lower/X),
  'G_before_R385_over_Xq':str(G/X),'analytic_source_fee_upper':str(source_price_upper),
  'qsmall':str(qs),'qmid':str(qv),'qbig':str(qu),'original_Tsource':Tsource,'active_dyadic_levels':len(levels)}

def summary(cases):
 keys=['rank_excess','Gmid_lower','Gmid_lower_fraction_of_G','new_fullposterior_F_lower','row_a_upper_piD','Gmid_lower_over_Xq']
 ans={'executed_parameter_fields':len(cases),'exact_case_digest':hashlib.sha256(json.dumps(cases,sort_keys=True).encode()).hexdigest()}
 for k in keys:
  vals=[F(c[k]) for c in cases];ans[k+'_min']=str(min(vals));ans[k+'_max']=str(max(vals))
 return ans

def main():
 initial=[case(F(1,10**16),F(1,2**20),F(3,2),F(1,10**14))]
 pressure=[case(s,p,b,F(1,10**14)) for s,p,b in product([F(1,2*10**16),F(1,10**16),F(1,5*10**15)],[F(1,2**22),F(1,2**21),F(1,2**20)],[F(3,2),F(8,5),F(5,3)])]
 expanded=[case(s,p,b,de) for s,p,b,de in product([F(1,2*10**16),F(1,10**16),F(1,5*10**15)],[F(1,2**22),F(1,2**21),F(1,2**20)],[F(3,2),F(8,5),F(5,3)],[F(1,10**15),F(1,10**14),F(1,10**13)])]
 result={'scope':'Real L1 f, genuine positive-volume Lebesgue receiver families and exact mass matching/q-band/caps; diagnostic h=H only, not synchronized original historical qualification. Gmid positive lower certificate uses tile-only union deficit upper; no false exact actual-union deficit. New fullposterior witness has a uniform actual-field lower bound and pays every designated big receiver row; zero remaining is asserted only on those rows, not all other receivers or a general remainder. No intermediate source-resampling qualification or general closure is asserted.',
  'exact_fraction_assertions':COUNT,'n':16,'baseline':initial[0],
  'stages':{'initial':summary(initial),'boundary_pressure':summary(pressure),'expanded_core_margin':summary(expanded)}}
 Path(__file__).with_suffix('.result.json').write_text(json.dumps(result,indent=2)+'\n')
 print('PASS',COUNT,'Fraction assertions; stage executions1/27/81')
 print('baseline rankexcess',initial[0]['rank_excess'],'Fmin',initial[0]['new_fullposterior_F_lower'],'piD',initial[0]['row_a_upper_piD'])
if __name__=='__main__':main()
