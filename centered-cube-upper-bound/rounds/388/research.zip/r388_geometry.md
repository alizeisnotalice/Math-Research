# R388 — A paid full-source cumulative-rank witness for the actual middle remainder

## 1. Receipt and its scope

Freeze the actual G_mid left by R387, including all R385/R386 fractional retentions and all original source, target, clock, geometric and history marks. Nothing is deleted from the receiver field E. Let

 T_y(t)=∫_E c_v(y)1_{m_v≤t}dv/m_v,
 J_b(y)=T_y(+∞)≤J_max=A_n/q_-,  A_n=1+n log(b/a).

Use the original h>0. Define the smooth full-source witness

 w_u(y)=h/[h+T_y(m_u)],
 F_u=∫w_u(y)π_u(dy),  π_u(dy)=f(y)c_u(y)dy/m_u.             (1)

At T=0 the displayed value is 1. This is one measurable field computed from the actual cumulative occupation, not a privately selected source window for each receiver.

Let α_u^mid(y) be the exact source cost density obtained by integrating the original marked G_mid against its physical clock, as in the R383 disintegration. In particular

 G_mid=∫q_u a_u du,
 a_u=∫α_u^mid(y)π_u(dy),  0≤α_u^mid≤1.                      (2)

Here a_u is recomputed for the actual post-R387 remainder; it is not the old pre-window core density. Put b_u=∫α_u^mid w_u dπ_u. The new coefficient is D, distinct from the frozen R385 coefficient C_0 (which may equal log(n+2)). For every D≥1 there is a positive splitting of the same actual traffic such that

 G_mid≤Dλh∫f(y)log(1+J_b(y)/h)dy + G_smooth,
 G_smooth=∫q_u[a_u−DF_u]_+du.                              (3)

Consequently the new source price is at most

                 Dλh log(1+J_max/h)W.                    (4)

Every row a_u≤DF_u is paid completely, using all its full-f sources as witnesses. This can pay traffic on a current source whose own witness is small, using other captured sources. The remaining measure is an explicit positive restriction of the original traffic, not merely an abstract positive part. Formula (3) is a general paid branch; no estimate of all of G_smooth by εX_q plus root-order W is asserted.

The result does not use outside/dense/deep to invent a source density bound. It is valid with all those gates retained. Its new ingredient is a globally priced cumulative-rank witness; the unresolved spatial question is whether those gates force its receiver-level shortfall to be small.

## 2. Exact all-source price, including mass atoms

For any finite positive mass-axis measure ν with inclusive CDF T and total J, and any A≥0,

                        ν{t:T(t)≤A}≤min(A,J).              (5)

An atom ending at A is included and an atom crossing A is excluded. This follows directly by taking the supremum of occupied inclusive ranks in this initial segment, and permits continuous and singular parts as well.

The layer-cake identity and (5) imply

 ∫ h/[h+T(t)] ν(dt)
 =∫_0^1 ν{t:T(t)<h(1/s−1)} ds
 ≤∫_0^1 min(J,h(1/s−1)) ds
 =h log(1+J/h).                                            (6)

For J=0 both sides vanish. Equivalently, an atom raising the rank from a to b contributes h(b−a)/(h+b), at most h log[(h+b)/(h+a)]; the continuous occupied ranks give the integral of h/(h+t). In particular no first-jump error or missing atom is charged.

Full matching and actual center integration now give, by Tonelli,

 ∫_E q_u F_u du
 =∫f(y)dy ∫_E q_u c_u(y)h/[h+T_y(m_u)] μ(du)
 ≤λ∫f(y)dy ∫ h/[h+T_y(t)] dT_y(t)
 ≤λh∫f(y)log(1+J_b(y)/h)dy.                              (7)

The q_u factor is bounded only by its actual upper band λ. No m_u du reversibility is used. The constant J_max comes from the certified actual-center envelope; the source-dependent middle expression in (7) is retained when useful.

The capture indicators and mass field are jointly measurable, so the nonnegative parameter integrals defining T_y(t) and T_y(m_u) are measurable. Sources with J_b=0 carry zero joint du π_u mass: ∫fJ_b=|E| exactly, and its restriction to J_b=0 is zero. Thus the harmless value w=1 on zero-rank sources introduces no exceptional-source charge.

## 3. Exact fractional splitting with the same plan

Always 0≤b_u≤min(a_u,F_u). For a_u>b_u define

 ρ_u=[a_u−DF_u]_+/(a_u−b_u),

and set ρ_u=0 when a_u=b_u. Then 0≤ρ_u≤1. Retain the original traffic with the multiplier

                         ρ_u(1−w_u(y)).                   (8)

Its exact row density is ρ_u(a_u−b_u)=[a_u−DF_u]_+. The paid density is min(a_u,DF_u)≤DF_u, so (7) proves (3). When a=b, a≤F≤DF and the whole row is paid; no division by zero occurs. The multiplier depends only on the frozen full field, receiver and current source. It preserves every target, clock and history label and does not assert a new source-exact target plan for later transitions.

On the actual R387 middle support, the current source satisfies T_y(m_u)>T_y(m_v)>2h. Hence w_u(y)<1/3 wherever α_u^mid(y)>0, and

                            b_u≤a_u/3.                    (9)

Thus the receipt is not merely the payment of current low-rank sources: it can pay far more than b_u, including the whole row. In particular R385's witness 1−U_u may vanish identically when U_u=1, whereas (1) remains positive and may pay the row. The proof uses the original entire π_u, including sources that carry zero present cost.

This is an additional disjoint payment applied after G_mid, with price (4). It is not silently substituted for a previous receipt at no cost. All prior paid pieces and source prices stay unchanged. If the proposal or target plan changes, α_u^mid and a_u must be recomputed; no old row qualification is inherited.

## 4. What failure now forces on the full source posterior

A positive remaining row has a_u>DF_u. For every s≥0, (1) gives

 π_u{y:T_y(m_u)≤sh}≤(1+s)F_u<(1+s)a_u/D.                  (10)

For D≥2 and a_u>0, choose s=D/(2a_u)−1≥0. Then strictly more than half of the receiver's full-f source mass satisfies

                    T_y(m_u)>h[D/(2a_u)−1].              (11)

This is an actual-row-dependent quantitative high-rank constraint, stronger than merely having positive lower-mass occupation on almost every captured source. It requires high rank also on much of the source mass that need not carry current traffic.

There is also an exact posterior-variance identity. Let M_u=∫T_y(m_u)π_u(dy); boundedness by J_max makes all quantities finite. Expanding the reciprocal about h+M_u gives

 F_u=h/(h+M_u)
     +h/(h+M_u)^2 ∫[T_y(m_u)−M_u]^2/[h+T_y(m_u)] π_u(dy). (12)

Thus source-rank dispersion increases the witness at fixed posterior mean. In particular a positive remaining row must have

                         M_u>h(D/a_u−1).                 (13)

The variance term in (12) may certify additional full rows through the already proved condition a_u≤DF_u. It is not an extra subtraction or a separately paid credit. No quantitative bound of M_u or this variance using outside/dense/deep has been proved here.

## 5. Full price and the remaining geometric interface

If the frozen R387 ledger reads

 BH≤G_mid+E_387 X_q+S_387,

then this construction gives

 BH≤G_smooth+E_387 X_q+S_387+Dλh log(1+J_max/h)W.             (14)

There is no new X_q coefficient. Under the same original synchronized threshold

 h=(1+√n)/(ε_0q_-),

its displayed source fee is

 [Dλ(1+√n)/(ε_0q_-)]
 log[1+ε_0 A_n/(1+√n)] W.                                 (15)

One may take D=2 in this round; the old C_0-price stays unchanged. For fixed or polylogarithmic D and b≤2a, this is root order times the displayed logarithms and original ε_0 inverse. The original outer multiplier 2Λ applies to this new slot exactly as it does to G_mid; it is not omitted in entrance bookkeeping. No parameter is retuned after the original h is frozen. If J_max≤h, the original strict-past gate already makes the traffic empty.

The remaining exact traffic keeps the R387 intermediate rank ratio, exponential mass separation and all R386/R385 gates, and additionally has the receiver-posterior restrictions (10)–(13). Establishing that these joint conditions have small total original cost is still open in this argument. A useful next geometric statement would bound the original q_u-weighted shortage [a_u−DF_u]_+ using the genuine spatial coupling between the large posterior rank on witness sources and the intermediate rank on traffic sources. Neither an unweighted boundary volume bound nor an independent-coordinate model for f provides that coupling. No terminal-flow or further-history claim is made.

## 6. Reproducible local checks and strict improvement evidence

Executed locally:

    python3 /tmp/r388_geometry_check.py

    PASS {'atomic_price': 243, 'matched_clock_field': 100,
          'row_fraction': 2400, 'posterior_tail': 204} total 2947
    positive {'beyond_current_soft': 162, 'fully_paid': 111,
              'unpaid': 51, 'U_one_and_positive': 2}

All calculations use Fraction; the script variable C is the new mathematical coefficient D, not the old R385 coefficient C_0. Stage 1 certifies the atomic Stieltjes price against rational lower bounds for the logarithm, obtained from the positive atanh series after exact reduction to [1,2]. Stage 2 constructs 100 finite source/receiver incidence fields with exact full source matching, q=1, n=1 and R=m; the complete physical clock is integrated exactly interval by interval and with its terminal atom. It retains strict far/past, regular-rank and middle-rank gates before forming the actual row densities. Stage 3 verifies the exact fractional split and posterior-tail consequences for D=1,2,5.

There are 162 row/D combinations with paid cost strictly exceeding current soft cost b, and 111 positive rows paid completely. In trial 35, row 7, the full-source union has U=1 and

 a=392/21555,
 b=2744/103399335,
 F=527451293/81975064743.

For D=5, a<5F, so this positive middle row is paid completely despite the R385 lower-anchor witness being zero. This is a reproducible finite-incidence diagnosis of the full-source lift; the script does not assert that these incidence fields are actual cubes, octave fields, or synchronized historical examples. Native Lebesgue-center examples, when supplied separately, must retain their own validation scope. The analytical inequalities (3)–(15) apply to the actual original cube field.

Status: the smooth witness supplies a strict generally valid paid branch and a stronger full-source posterior condition on the remainder. A budget for the entire remaining shortage has not been established.
