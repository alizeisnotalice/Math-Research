# R388: genuine positive-dx middle traffic, paid by the full-f rank witness

This supplies a positive Lebesgue-center/source witness for the new receipt. R385/R386/R387 ranks and fields are recomputed from one actual complete f and all original receiver families. The actual union deficit is **not** falsely equated to a tile-only deficit: a certified upper on that deficit gives a positive lower bound on the actual G_mid. A full-source posterior lower bound then proves complete payment of the actual middle row, including its unknown exact old fractional retention. No source resampling/transition eligibility, historical first-crossing qualification, synchronized h/H budget or general closure is asserted.

## Same full source, different real receiver volumes

n=16,a=1/2,b=1,lambda=1. Fix

f=(3/4)1_Q4+(P/|D|)1_D,
D=[.47,.48] times [.10,.11]^15, |D|=10^(-32).

There are 2^16 small receiver center boxes centered at all sign choices (+/-1/4)^16, with side s and actual R=L=1/2. Add a mid box centered at (.7,.25,...,.25), side s, actual R=L=3/4. The big box is centered at zero, side B=bs, actual R=L=1. Hard softness is zero. All are disjoint positive-volume subsets of receiver space, with actual weights wS=wV=s^16,wB=B^16. They are not point quadrature or freely selected weights.

All relevant cubes are inside Q4. Exactly the all-positive small tile, mid and big capture the entire D, uniformly over every point of their receiver boxes; other sign tiles miss D. Thus, with background a0=3/4,

m0=a0 2^(-16), ms=m0+P,
mv=a0(3/4)^16+P, mu=a0+P.

Actual q0=a0, qs=ms/(1/2)^16, qv=mv/(3/4)^16, qu=mu lie in [3/4,1]. Actual q<=lambda and same-full-f matching/cap hold; this does not certify an old historical FIRST selector. Full W=a0 4^16+P, actual |E|=(2^16+1)s^16+B^16 and actual Xq are retained. The original source threshold is T=1+ceil(log2(18))=6, and D satisfies f_D>6max(q).

Every big/mid pair satisfies the R386 spatial/core inequalities on its entire positive-volume domain: strict outside, all sixteen protruding coordinates, deep excess and not-Bplus, plus the original positive core lower bounds. The exact exp(4) certificate is 54<exp(4)<55; mu>55mv and mv>55ms hold. The small tiling receivers themselves fail the big→small outside gate, although their union supplies source coverage. No omitted spatial gate is quietly called a native realization; the checked conditions are precisely the inherited R386 scalar normalizations. Historical low/e/m and synchronized entrance qualifications remain outside scope.

## Literal common ranks and the new middle support

For every y in D,

Tsmall=wS/ms,
Tmid=wS/ms+wV/mv,
Tbig=Tmid+wB/mu,
Zmid=Tsmall, Zbig=Tmid.

Select literal **diagnostic** h=H=wS/(10ms). No global absorption budget is claimed for this choice. Complete physical clock intervals and the terminal atom at b=1 are kept. Positive big→mid traffic uses the terminal clock weight 1/Tbig. J includes every capturing family throughout; previously paid receivers are never deleted from it.

In all cases Tbig<1.6Tsmall, so active dyadic levels 2h,4h,8h end in the small mass atom. The R386 large-u rank-jump window misses mu; the small-v closed low-rank condition fails; and the small-v level-2h window misses mv while its own strict past exceeds h. These three literal payments are zero on the designated positive big→mid branch.

For R387 use d=tau=.001. Every tested case has

Tbig/Tmid-1>d, and Tmid=Zbig>tau Zbig.

Thus neither R387's near-rank nor low-relative-rank receipt pays this branch. This is different from R387's previous equal-volume witness, which was entirely rank-close paid.

## R385 deficit: a genuine lower bound, not an incorrect equality

The union of the small-tile capture supports is the centered cube of side 1+s. It need not cover every big Q1 when B>s. The mid receiver may enlarge this union, so the tile-only uncovered source is an upper bound on the actual smaller-receiver deficit.

For a big center u, one-coordinate loss against the tile union is l_i=(|u_i|-s/2)+. Its exact mean on [-B/2,B/2] is

E l_i=(B-s)^2/(4B).

D is entirely inside the tile union. Thus only the background contributes to its deficit, and actual Lebesgue product integration gives

integral_big q_u(1-U_actual(u))du
 <= a0 wB [1-(1-(B-s)^2/(4B))^16] =: Def_upper.

Also pointwise 1-U_actual<=a0*n(B-s)/(2mu). The old literal R385 coefficient is fixed to C0=2, distinct from the new coefficient. The script checks that each original row has a pointwise core lower A_min>C0 times this deficit upper. Hence its R385 positive-part remainder is positive on every big receiver. Its designated-big-row integrated value need not be computed to certify

0<G-C0 Def_upper <= G_mid <=G.

R386/R387 do not reduce this particular retained branch, by the gates just established. This retains the actual old fractional field: the lower is not substituted for a reconstructed new source or new row. It also avoids claiming a false exact deficit, since the mid family can cover part of a tile boundary loss.

## Exact original cost and complete new payment

All big/mid overlaps are in the affine partial regime for every receiver pair. Integrating the real center boxes yields exactly

pmean=(7/30)(5/6)^15,
G=wB*wV*(1-mv/mu)*(f_D-qv)|D|*(1-pmean)/(mv*Tbig)>0.

The independent posterior formula agrees exactly. Fubini on actual product center domains supplies this formula, without assuming independence of the complete source f. An everywhere-pair geometric bound supplies A_min and all complete-box core tests.

For the new full-source witness write

w_u(y)=h/[h+T_y(mu)], F_u=integral w_u d pi_u,
pi_u(dy)=f(y)1_Q1(u)(y)dy/mu.

Here pi_u is the actual full posterior probability, not the source restricted to D. For every source point its actual occupation is bounded by the sum of **all** receiver family occupations,

Jglobal=(2^16-1)wS/m0+wS/ms+wV/mv+wB/mu.

Therefore, uniformly over every big receiver,

F_u>=h/(h+Jglobal)=F_lower.

The original row cost obeys a_mid(u)<=a_original(u)<=pi_u(D), since its source cost is supported on D and its density is <=1. The script proves pointwise

2 F_lower >= pi_u(D) >= a_mid(u).

The new coefficient Dnew=2 therefore pays the entire actual positive G_mid on the designated big receiver rows, with remaining positive-part row exactly zero on those designated big rows. The JSON keys `new_paid_all_designated_Gmid` and `new_remaining_designated_big_rows` refer only to them; no zero remainder is asserted for other receivers or general inputs. No exact value of F or of the old union deficit is presumed. All sources carrying zero present cost are legitimately retained as witnesses.

This is a full-f lift rather than only the current-source factor: T_y(mu)=Tbig on the cost-carrying D, and 2h/(h+Tbig)<1. Hence the weighted current-source cost alone is strictly less than the full positive row. The new full posterior may nevertheless pay it all. The analytic source fee is bounded using the proved Stieltjes receipt by 2lambda*h*log(1+Jglobal/h)*W; an outward rational logarithm upper from a range-reduced atanh series is recorded. This is an analytic fee upper, not a numerical evaluation of the actual all-source witness integral.

Baseline s=10^-16, b=3/2, P=2^-20, delta_core=10^-14:

| quantity | display of exact rational certificate |
|---|---:|
| G before R385 | 9.947324898e-263 |
| positive actual G_mid lower | 9.947324241e-263 |
| lower/G | .999999933968 |
| Tbig/Tmid-1 | .01083992215 |
| F_lower | 1.408503027e-6 |
| pi_big(D) row-cost upper | 1.271564138e-6 |
| current-source 2w(D) | .1797741663 |
| original complete-box A_min | 2.019223270e-9 |
| h=H, diagnostic | 8.065969231e-253 |
| full W | 3221225472.000000954 |
| full Xq | 4.964544385e-252 |
| G_mid lower/Xq | 2.003673141e-11 |
| analytic new source-fee upper | 7.001183270e-242 |

The cost is tiny and the general fee upper greatly exceeds it. The example demonstrates strict new payment on a real formerly retained branch, not a near-extremal obstruction, an efficient sample total budget, or a positive fraction of all general G_mid.

## Three stages and reproducibility

Stage 1 is the baseline. Stage 2 executes 27 fields with s in {5e-17,1e-16,2e-16}, P in {2^-22,2^-21,2^-20}, and B/s in {3/2,8/5,5/3}. Stage 3 executes those fields at delta_core in {10^-15,10^-14,10^-13}, 81 executions. Repetitions are not counted as independent input models. Every field has positive certified G_mid; the smallest retained fraction is .9999990639, rank excess ranges .0102155 to .0584987, and the new full-source receipt pays every complete big receiver row.

Run `python3 r388_continuum.py`. Standard library only, no old /tmp imports, no optimizer, no Monte Carlo or point-receiver surrogate. It writes `r388_continuum.result.json` beside itself, retaining the rational baseline, exact stage extrema and digests of reproducible case lists. **16,133 exact Fraction assertions** passed. A fresh second process reproduced result bytes. Table decimals are displays of those rationals, not additional float certificates. Only owned R388 files changed; no repository/Git actions.
