# R388 independent audit — FINAL PASS

Owner scope: this file only; no repository or author edits. The proposed soft-rank receipt was independently checked before reading the R388 author proof. It passes the precise screen below. Final author proof, code/result/notes, evidence scope and complete integrated ledger have now been reviewed. PASS is for the exact receipt and accounting below; no general root closure is certified.

## 1. Full-source rank witness and atom-safe price

Fix the same complete f, actual receiver E, positive masses m=qR^n, original physical clock, source-exact plan and actual R387 G_mid marks. Let pi_u(dy)=f(y)c_u(y)dy/m_u, T_y(t)=integral c_v(y)1_{m_v<=t}dv/m_v, J_b=T_y(+infinity)<=Jmax. Take h>0 from the original synchronized field, not from a rebuilt source, and set

    w_u(y)=h/[h+T_y(m_u)], F_u=integral w_u d pi_u.

These are measurable, finite and in[0,1]. The bound Jmax is fixed, so all posterior moments below are finite. Joint captured source/receiver pairs of J_b=0 have zero measure; no positive mass denominator is inserted there.

Full-f matching and Tonelli give

    integral q_u F_u du
       =integral f(y) integral q_u c_u(y) h/[h+T_y(m_u)]du/m_u dy
       <=lambda h integral f(y) integral dT_y(t)/[h+T_y(t)]dy
       <=lambda h integral f(y)log(1+J_b(y)/h)dy
       <=lambda h log(1+Jmax/h) W.

At an atom whose rank increases from l to l+d, the right-CDF term is d/(h+l+d)<=log((h+l+d)/(h+l)). The continuous and singular-continuous parts follow from the same occupied-rank integration. The initial atom is covered by h>0, so there is no omitted crossing/endpoint fee. This is a true same-field source-W receipt derived from q_u<=lambda and real du. No source density bound, private receiver anchor, or uncharged exit measure is used.

## 2. Feasible positive fractional payment

Write the ACTUAL remaining row a_u=integral alpha_mid d pi_u, 0<=alpha_mid<=1, and b_u=integral alpha_mid w_u d pi_u. Then b<=min(a,F). For any C>=1, p=min(a,C F) obeys b<=p<=a. First pay the original w-weighted current traffic, of cost b; then pay the fraction (p-b)/(a-b) of the original (1-w) traffic if a>b. This fraction lies in[0,1]. If a=b, necessarily p=a and all cost is paid; if a=0 there is no cost and no division. The exact remaining row density is

    a-p=(a-C F)_+.

All original source/target/history/clock labels stay in this positive marked residual. On current G_mid support T_y(m_u)>2h, so w<1/3 and b<=a/3 (strict for a>0). This fact does not replace the source marginal by a probability conditioned on the current traffic.

The paid total is at most C integral qFdu and therefore at most

    C lambda h log(1+Jmax/h) W.

There is no new X_q term or target-cap/h/t/template change from this receipt. Its entrance contribution has the original multiplier 2Lambda. Applying it AFTER R385/R386/R387 to exact G_mid is legitimate as an additional price for a new positive restriction; the prior R385 price and actual marks remain once, without subtracting old payment again. Full-source witness mass may overlap prior witnesses, but this new capacity use has its OWN explicitly charged W price. If instead used as an alternative earlier receipt, the whole alternative ledger must be reassembled, rather than mixing exact residuals across plans or parameter fields.

## 3. Necessary conditions for a positive remaining row

If (a-C F)_+>0, then a>0 and F<a/C. For every s>=0, the posterior event T_y(m_u)<=s h has w>=1/(1+s), hence

    pi_u{T_y(m_u)<=s h} <=(1+s)F <(1+s)a/C.

Let mbar_u=integral T_y(m_u)d pi_u. Convexity of h/(h+t) gives F>=h/(h+mbar), so

    mbar>h(C/a-1).

For C>=2 and a>0, s=C/(2a)-1>=0. Thus the full-f posterior has STRICTLY MORE than half its mass at T_y(m_u)>h[C/(2a)-1]. This s is only a receiver-dependent consequence; it cannot be substituted as a free source-only window in a center-capacity theorem. If the threshold exceeds Jmax, the positive remaining row is impossible, rather than requiring a new endpoint convention.

These are necessary conditions, not bounds on the total surviving qdu cost, a source-tail W budget, endpoint history eligibility, or a generally positive paid fraction.

## 4. Exact variance identity, not a second credit

For mbar=E_pi T and finite bounded T, the algebraic reciprocal expansion gives

    F=h/(h+mbar)
       +h/(h+mbar)^2 E_pi[(T-mbar)^2/(h+T)].

The linear centered term has expectation zero. All terms are integrable since h>0 and T<=Jmax. The second term is nonnegative and already part of the SAME actual F. It cannot be separately deducted from a ledger which has already used min(a,C F). Strictness in Jensen gives no uniform coercivity or coverage rate.

## 5. Actual reviewer tool evidence

Reviewer actually ran 5184 Python Fraction cases checking the exact variance identity and the stated failure/Jensen/half-mass implications, including zero ranks and nontrivial atomic posterior mixtures. These are bounded algebraic diagnostics, not native cube/history realizations or substitutes for the measure proof. They are separate from later author/parent counts. No author pipeline was repeated.

PASS for the precisely stated soft-rank receipt, full-source price, fractional marking and necessary remaining-row conditions. Final author and integration reviews follow.


## 6. Author proof, check code and initial integration: reviewed

Read r388_geometry.md and r388_geometry_check.py fully after the independent screen. The final author notation uses D for the NEW coefficient, and C_0 for the OLD R385 coefficient; the preliminary Sections 1--4 above called the new generic coefficient C. All those statements are identical upon C=D; there is no identification D=C_0. The proof's layer-cake and Stieltjes alternatives give the same atom-safe price. Its actual retained multiplier [a-DF]_+/(a-b)*(1-w) reproduces the exact residual, including zero-denominator cases, and need not be a new source-exact plan for future transitions.

The finite script's 2947 Fraction assertions check price using certified rational logarithm lower bounds, full finite-source matching, exact physical clock and fractional marking. Its finite receiver incidence systems are explicitly NOT actual cubes/octave/historical realizations. The source-rank posterior consequences and nonempty examples are accurately limited in the text. No whole pipeline was repeated by the reviewer.

Final main and appended ledger correctly add P388=Dlambda h log(1+Jmax/h) to the prior source coefficient and retain its full 2Lambda multiplier. They add no X coefficient or template/target fee and do not retune the original h. The old variance term is not deducted again. Final file-byte binding is recorded below.

## 7. Independent review of the new positive-du construction

Read the complete r388_continuum.py. As in R387, the full source and capture masses are fixed by genuine receiver center boxes. Small and mid center-box side is s, big side B=Bfactor*s>s; all radii remain 1/2,3/4,1. The packet is captured by the all-positive tile, mid family and big family, so their original occupancies are ws/ms, wv/mv and wb/mu with ws=wv=s^16 and wb=B^16. All other small tiles retain their background masses and participate in the full field. The original source threshold is correctly T=6.

Increasing B above s makes the tile union no longer cover every big cube. The actual smaller capture union also includes the mid family, which can fill some of that deficit. The script therefore correctly treats the TILE-ONLY deficit as an UPPER bound for the actual 1-U, not an exact value for U. For a coordinate u_i uniform on[-B/2,B/2], the lost tile-overlap length is l_i=(|u_i|-s/2)_+, with exact mean (B-s)^2/(4B). Product-center integration gives

    integral_big bg mass(Q_u outside tile union)du
      =bg wb[1-(1-(B-s)^2/(4B))^16].

The high packet lies inside the tile union, so only background contributes to that deficit. Multiplying by C_0 bounds the prior R385 paid cost from above. Subtracting this bound from G thus yields a valid POSITIVE LOWER certificate for remaining G, not an optimistic estimate. The pointwise bound bg/mu*16(B-s)/2, times C_0, is below the original A_lower, proving each continuous big row retains positive cost.

On packet D the ranks Tsmall,Tmid,Tbig include all original capturing families, with the enlarged wb big contribution. The active dyadic levels remain inside the ms atom; mid lies above Kms and Tmid>2h with strict past>h. Hence all R386 payments still miss this designated branch. The new rank excess is above d=1/1000, while Tmid=Zbig>tau Zbig, so both R387 payments also miss it. The same whole-pair spatial margins and partial affine overlap calculations remain valid with coordinate spread (B+s)/2; pmean=(7/30)(5/6)^15 is exact. The alpha/A lower bounds are pointwise, not block-average qualifications.

For the new witness, Jglobal=(2^16-1)ws/m0+ws/ms+wv/mv+wb/mu bounds the actual J_b(y) for every y by the full receiver measure. Consequently F_u>=h/(h+Jglobal) for EVERY posterior source. This lower bound and D=2 are at least pi_big(D), whereas the entire remaining big-row cost is at most pi_big(D). This proves complete new payment of its genuine positive old residual without computing exact U, exact old fractional cost or exact F. The script also checks 2w_current<1, separating this full-source payment from a trivial current-source-only deduction.

The construction has diagnostic h/H/core thresholds rather than synchronized global/historical qualifications; its full W and tiny G/X must be retained. It does not certify a near-extremizer, a positive covered fraction for arbitrary f or a general bound. The final continuum explanation/result and integrated byte bindings have now also been reviewed below.


## 8. Final continuous notes, result scope and full integrated ledger

Read final continuum explanation, current script/result, main and readme in full, and the complete appended ledger. The prior ledger prefix is byte-for-byte unchanged from the bound R387 ledger. The author geometry hash matches the final new-D/old-C_0 distinction. The final continuum result explicitly limits new_paid_all_designated_Gmid and new_remaining_designated_big_rows to the designated big receivers. It does not assert that all receivers' G_mid or every general input has zero remainder.

The final notes correctly separate exact G before R385 from the positive LOWER certificate for actual old G_mid, and retain the unknown exact smaller-union deficit and old fractional row marks. The logarithmic source-fee value in the numeric result is an analytic display UPPER using Jglobal and an outward rational logarithm bound; it is not a computation of the actual all-source witness integral. Complete W, X_q, tiny G/X_q, repeated parameter fields, diagnostic h/H and incomplete historical qualification are expressly retained. The actual construction is a positive-du mechanism example, not a general coverage fraction or an extremal obstruction. All new rows-pay statements are restricted to the designated big rows.

The final complete estimate is

    BH<=G_smooth+(eta+sigma_n+epsilon383+lambda d/q_-+tau)X_q
         +(C338+S386+P388)W,
    P388=Dlambda h log(1+Jmax/h).

The original entrance retains 8lambda H W, 2d_eff A_n W_nu/H, twice G_smooth, twice the stated hard-slot receiver coefficient and twice C338+S386+P388, and is then multiplied by Lambda. The new P388 therefore receives exactly 2Lambda. It is ADDED for this new remaining-traffic receipt, rather than hidden as a free replacement of an old R385/S386 price. There is no new X coefficient, target-cap/template inflation, reused variance/square credit or parameter retuning. R387's unified initialization remains valid; an old already-fixed field is not reassigned a different h.

For the stated recommended D=2, fixed inherited absorption parameters and synchronized h=(1+sqrt(n))/(epsilon0 q_-), this new source coefficient is bounded by the same root times log^(5/2)(n+2) scale as the prior displayed source bill, with original parameter dependence retained. This is a source-slot estimate only; H entry and the other original slots are not paid by it. A growing D would have to carry its explicit factor and cannot silently retain the same fixed exponent.

The exact shortage G_smooth, the high-rank full-posterior conditions, old intermediate rank/space/source/target/history restrictions, H entry/choice, soft/crossing/entry, tail/scale complements, initial/deleted/future-deleted history atoms, aggregation/truncation/limit obligations all remain. The variance identity is already included in F, not a second subtraction. No conservative future flow, new endpoint qualification or all-input root bound is asserted.

Parent reports actual successful executions 2947+16133=19080 Fraction assertions, with reruns and reviewer evidence not counted again. Reviewer actually ran the separate 5184 bounded Fraction cases in Section 5; no parent pipeline was needlessly rerun in this file review. The general mathematical proof is independent of those finite diagnostics. This audit does not certify typesetting/compilation and does not freshly re-prove the entire historical reduction.

FINAL PASS: no outstanding correction found in the precise R388 receipt, native-center example, final ledger or stated scope. General root closure remains open.

## 9. Final byte bindings

| File | SHA256 |
| --- | --- |
| `/tmp/r388_main.md` | `32a5065007e7d29afda4cbe98ede2d5e437fc1fc26df3789b02ef5dbf7693ee6` |
| `/tmp/r388_ledger.md` | `0b6e2e2d45ac4db56e1abfe6497766670c953b2e84766c5890f6065052fa6950` |
| `/tmp/r388_readme.md` | `4e3445381e34d8228f358dc0475f1db5ba40428a2565302448846441a3be187a` |
| `/tmp/r388_geometry.md` | `b3868aa0575a9893734711b9d39d8922f8f43b82fc6afc14791e9beef6ed7d00` |
| `/tmp/r388_geometry_check.py` | `eecce9d10e661cc07cdd3ee5d60ea36cf8bd36eeb087395b77d5a84091a76825` |
| `/tmp/r388_continuum.md` | `0b3ea0a2120959d3bf1086331589e2298ae7e5676a995bce604b755a619017e1` |
| `/tmp/r388_continuum.py` | `17f8ffa33f5455be8f0e487cb6f78ca1d58b2b723129d3c552a30fbcde584e26` |
| `/tmp/r388_continuum.result.json` | `46686d7baf39b82787a783d7d91ef2a97b7664a143aa4dfbab6629be43f9c275` |
| `/tmp/r387_geometry.md` | `683e9f7886d1e893b0923c5268840c5e696f8c94e55f1ecdb92050c4cfb14458` |
| `/tmp/r387_ledger.md` | `c5057600d97b0fb391715cc46d52e8894e9bf55d1f2146cbb080e91c5cc8ead0` |
| `/tmp/r386_geometry.md` | `fe839792aff6ca2b1fcb6787a8073fe71d8ca3dd28b8d46585d350d2c5851bca` |
| `/tmp/r385_geometry.md` | `f39ec03b200b8954695da179d5d24183a1420081a96aaee61f34fb09c353c8eb` |
| `/tmp/r383_flow.md` | `3870009b3c82a3a051e379ea6636940ff583ca945f645d371d0a813e9880c4cd` |
