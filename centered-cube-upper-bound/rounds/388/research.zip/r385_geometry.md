# R385 — A canonical source window from the essential capture spectrum

## 1. Constructive receipt and exact remaining branch

Use the frozen R383 pre-window core from the same actual plan. In particular

π_u(dy)=f(y)c_u(y)dy/m_u,
a_u=∫_{Y_u}α_u(y)π_u(dy) for u∈E_hi,
G_core=∫_{E_hi}q_u a_u du,

with 0≤α_u≤1 and the original strict mass-past gate Z_y(m_u/K−)>h. All q,m,f,J, the physical clock, source/target marks, outside/dense/deep/not-Bplus gates and history fields stay fixed. Let K=exp(√n), so log K=√n. The construction uses the **entire actual receiver field E**, not just E_hi or a selected set of possible successors.

For each source y choose s(y), the essential minimum receiver mass among the actual receivers capturing y, as precisely defined in §2. Set the single global measurable window

                         I(y)=[s(y),K s(y)].                    (1)

Define the actual full-f essential-union fraction

U_u=(1/m_u)∫f(y)c_u(y)1_{Z_y(m_u/K−)>0}dy.                      (2)

The word union refers to positive actual receiver occupation: (2) records whether the source is captured by a positive-du family of receivers whose masses are strictly below m_u/K. It is not an assertion about a possibly exceptional individual cube. It uses all original receivers, so it may include receivers whose pair with u fails other spatial marks. This deliberate outer union is not substituted for the actual gates in the cost.

For the full-source window witness F_u=π_u{m_u∈I(y)}, we prove

                 F_u=1−U_u,             a_u≤U_u.               (3)

Moreover the actual current-source in-window core cost is zero. Thus this is an especially direct full-source witness receipt: all of its nonzero payment comes from witnesses that need carry no original traffic.

Apply the R384 fractional receipt with any fixed C≥1. It gives the **one-fee** decomposition

G_core ≤ [Cλ(1+√n)/q_-]W + R_C,
R_C =∫_{E_hi}q_u[a_u−C(1−U_u)]_+du
    ≤∫_{E_hi}q_u[(C+1)U_u−C]_+du.                             (4)

All receivers satisfying U_u≤C/(C+1) are paid in full, including equality. Any receiver with positive remaining row density satisfies

                         U_u>C/(C+1).                         (5)

For the task's C=2 fractional remainder, this yields

R_frac(I)≤∫_{E_hi}q_u(3U_u−2)_+du,
source fee = 2λ(1+√n)W/q_-.                                   (6)

This is a deterministic global source-window construction, with no covering-number assumption, no choice of private windows indexed by u, and no need to solve a coupled window optimization. It gives a genuine root-order paid branch of the original marked core.

One may instead use C=log(n+2)≥1. This has source price
λ(1+√n)log(n+2)W/q_- and restricts positive remaining traffic to

U_u>1−1/[1+log(n+2)].                                         (7)

This is a replacement using the C-version of the receipt, not an additional fee or an upper bound for the fixed C=2 remainder by the smaller R_C when C>2. No uniform estimate of the remaining majority-union traffic is asserted.

## 2. Measurable essential minimum, null sources, and strict boundaries

The actual assumptions give finite positive mass bounds

m_-=q_-a^n≤m_v≤m_+=λb^n.

For each y define the finite capture measure

ν_y(dv)=c_v(y)dv/m_v,
J_b(y)=ν_y(E),
Z_y(t−)=ν_y{v:m_v<t}.

These are computed from full f and the entire actual E. For J_b(y)>0 put

s(y)=inf{t∈Q_{>0}:Z_y(t−)>0};                                 (8)

for J_b(y)=0 set s(y)=m_-. The rational-threshold definition is measurable by Tonelli and countable operations. On J_b>0 it is the essential infimum of m_v with respect to ν_y, hence lies in [m_-,m_+]. Because the mass bounds are positive, ν_y and c_v(y)dv have the same null sets. No arbitrary pointwise infimum over possibly exceptional receivers is used.

For each such y and every real t>0, the essential-infimum property gives the exact equivalence

                     Z_y(t−)=0  iff  t≤s(y).                  (9)

Indeed the measure below s is zero, while every threshold strictly larger than s has a positive lower-mass set. This proof handles both mass atoms and an unattained infimum. The rational infimum in (8) is only a measurable construction; (9) holds for all real t, including t=s.

The same essential-infimum property yields s(y)≤m_u for ν_y-almost every captured u. Multiplication by f(y) and Tonelli show

                     s(y)≤m_u  for du π_u(dy)-a.e. (u,y).     (10)

Sources with J_b=0 carry no joint duπ mass, since

∫du∫π_u(dy)1_{J_b(y)=0}=∫f(y)J_b(y)1_{J_b(y)=0}dy=0.

Thus the arbitrary fallback value of s on those sources has no effect on any receiver witness or cost, up to the relevant null set. In particular the window endpoints in (1) are finite positive measurable functions everywhere.

Combining (9)–(10), for duπ-a.e. (u,y),

1_{m_u∈[s(y),K s(y)]}
 =1_{m_u/K≤s(y)}
 =1_{Z_y(m_u/K−)=0}.                                         (11)

Integrating against π_u proves F_u=1−U_u. The closed upper endpoint m_u=K s(y) is paid: its strict mass past below m_u/K=s(y) is zero. The lower endpoint is also included. No strict/inclusive endpoint term has been lost.

## 3. Original cost support and actual payment

The original strict-past factor implies α_u(y)=0 whenever Z_y(m_u/K−)≤h; in particular it vanishes on the right side of (11). Therefore

a_u≤π_u{Z_y(m_u/K−)>h}≤U_u,                                  (12)

and the actual in-window cost

b_u=∫_{Y_u}α_u(y)1_{m_u∈I(y)}π_u(dy)

is exactly zero. These deductions use the original gate and the original clock average; they do not replace α by an unweighted occupation proxy. The spatial and source/target marks remain in α and can only decrease this positive cost.

For a_u>0 pay the fraction

                  t_u=min(a_u,C F_u)/a_u

of the original core row; if a_u=0 there is no cost. This is the R384 fractional construction with b_u=0. It preserves every original label and source-exact plan and leaves exact row remainder [a_u−C F_u]_+. All original traffic in this construction is already current-source-window outside, so there is no hidden in-window fee to add.

The total paid amount satisfies

∫q_u min(a_u,C F_u)du≤C∫q_u F_u du
 =C∫f(y)∫_E c_u(y)1_{s(y)≤m_u≤Ks(y)}du/R_u^n dy
 ≤[Cλ(1+log K)/q_-]W.                                        (13)

The last step is the certified R382 actual-center envelope. For completeness, if ρ=2||u−y||∞ and z=q_-ρ^n, actual capture implies m_u≥z, and

1_{s≤m_u≤Ks}/m_u≤1_{z≤Ks}/max(s,z).

Its Lebesgue-center radial integral is (1+log K)/q_-. Use R_u^−n=q_u/m_u≤λ/m_u to obtain (13). This is a joint mass/center bound on the selected real receivers; no independent radius measure or source density bound is inserted.

Equations (11)–(13) prove (4), and a_u≤U_u gives the displayed geometric envelope and strict support (5). The exact remainder, rather than this possibly looser envelope, is retained in any ledger.

## 4. Complete accounting and the one remaining interface

If the starting ledger has already screened the R383 low receiver/source rows, it has the form

BH≤G_core+E_old X_q+S_old.

Replace its single G_core slot by (4):

BH≤R_C+E_old X_q+S_old+[Cλ(1+√n)/q_-]W.                       (14)

If the screening has not yet been charged, its 3δX_q must still be added once as in R383. An outer factor 2Λ multiplies the new source price by exactly 2Λ. There is no new target-cap multiplier, plan reconstruction, h/H change, εX_q absorption, or repeated square/return credit. A previously paid R384 window receipt is replaced here for the same slot, not stacked with (13).

The construction is from the same frozen field and plan. Changing the plan requires recomputing a and its cost partition; an old qualification is not transferred to a new plan. No small receiver is assumed to inherit Y_v or any high-flow property. This receipt does not require such inheritance.

The global unresolved quantity is the actual q_u du-weighted cost on receivers whose full-f mass is overwhelmingly captured by strictly far-smaller actual receivers, as quantified by (4)–(7). Although U_u is a union indicator, its source sets for different u overlap. Their f-masses cannot be summed as disjoint, nor can the true center measure be replaced by a number of cubes. This note proves neither a root-order budget for that repeated majority-union source load nor a bound by εX_q. That is the single remaining interface of this construction.

In particular the proof does not assert a bound on a covering number M, does not assume nested cubes, and does not infer small f-mass from the dense/deep pair's small geometric overlap. The new paid branch includes cases with many overlapping smaller receivers but a modest union f-mass; multiplicity alone does not defeat its price.

## 5. Actual checks and positive-scope evidence

Executed locally:

python3 /tmp/r385_geometry_check.py

PASS {'essential_support_and_boundary': 3309,
      'fractional_payment': 3950, 'zero_occupancy': 30}
total 7289
positive core rows 790
guaranteed covered row/C pairs 2028
positive residual row/C pairs 850

The Fraction script computes all masses from a single full finite source measure. It tests essential-support thresholds at mass atoms, closed-window/strict-past equality, sources of zero receiver occupation, reciprocal J and strict-past marked costs, zero actual in-window cost, the general C fractional identity, and the majority-union paid/complement bounds. These are finite incidence/quadrature checks of the analytic statements, not continuum geometric samples. Both fully paid and positive-residual cases occur; no universal closure is inferred from the diagnostics.

A separate real-Lebesgue-receiver positive example and its exact certificates are supplied by the parent in /tmp/r385_continuum.md and /tmp/r385_continuum.py. That construction uses genuine center boxes and matched cubes, and exhibits positive original cost whose current sources all miss (1) while no-traffic full-f witnesses pay every large row. Its literal diagnostic h,H are not claimed to satisfy the synchronized R379 field/history choices. It is supplementary scope evidence; the continuum theorem (4) is proved independently above.
