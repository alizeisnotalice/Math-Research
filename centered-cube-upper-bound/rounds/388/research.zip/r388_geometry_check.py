from fractions import Fraction as F
from itertools import product
from random import Random

def ln_lower(x):
    assert x >= 1
    k = 0
    while x >= 2:
        x /= 2
        k += 1
    def series(z):
        return 2 * sum((z ** (2*j+1) / (2*j+1) for j in range(45)), F(0))
    return k * series(F(1, 3)) + series((x-1)/(x+1))

counts = {'atomic_price': 0, 'matched_clock_field': 0, 'row_fraction': 0, 'posterior_tail': 0}
first_U_one = None
positive = {'beyond_current_soft': 0, 'fully_paid': 0, 'unpaid': 0, 'U_one_and_positive': 0}
for weights in product(range(1, 4), repeat=4):
    for h in (F(1, 5), F(1), F(3)):
        T = F(0); integral = F(0)
        for w in weights:
            delta = F(w, 3)
            T += delta
            integral += delta * h / (h+T)
        assert integral <= h * ln_lower(1+T/h)
        counts['atomic_price'] += 1

rng = Random(388)
for trial in range(100):
    ns, nr = 5, 8
    f = [F(rng.randrange(1, 8), rng.randrange(1, 5)) for _ in range(ns)]
    cap = [[rng.randrange(2) for _ in range(ns)] for _ in range(nr)]
    for u in range(nr):
        if not any(cap[u]): cap[u][u % ns] = 1
    vol = [F(rng.randrange(1, 7), rng.randrange(1, 5)) for _ in range(nr)]
    mass = [sum(f[y]*cap[u][y] for y in range(ns)) for u in range(nr)]
    mu = [vol[u]/mass[u] for u in range(nr)]
    T = [[sum(mu[v]*cap[v][y] for v in range(nr) if mass[v]<=mass[u]) for u in range(nr)] for y in range(ns)]
    Z = [[sum(mu[v]*cap[v][y] for v in range(nr) if 2*mass[v]<mass[u]) for u in range(nr)] for y in range(ns)]
    h=F(1,100); d=F(1,10); tau=F(1,10)
    # n=1,q=1,R=m: exact physical-clock integration, arbitrary finite incidence.
    radii=sorted(set(mass))
    clock=[(radii[k],1/radii[k]-1/radii[k+1]) for k in range(len(radii)-1)]
    clock.append((radii[-1],1/radii[-1]))
    alpha=[[F(0) for y in range(ns)] for u in range(nr)]
    for r,cw in clock:
        for y in range(ns):
            J=sum(mu[v]*cap[v][y] for v in range(nr) if mass[v]<=r)
            if not J: continue
            for u in range(nr):
                if mass[u]>r or not cap[u][y] or Z[y][u]<=h or T[y][u]>=2*Z[y][u]: continue
                for v in range(nr):
                    if not cap[v][y] or mass[u]<=2*mass[v]: continue
                    if T[y][v]<=2*h or Z[y][v]<=h: continue
                    if T[y][u]<=(1+d)*T[y][v] or T[y][v]<=tau*Z[y][u]: continue
                    alpha[u][y]+=mass[u]*cw/J*(1-mass[v]/mass[u])*mu[v]
    field_price=F(0)
    for u in range(nr):
        pi=[f[y]*cap[u][y]/mass[u] for y in range(ns)]
        w=[h/(h+T[y][u]) for y in range(ns)]
        a=sum(pi[y]*alpha[u][y] for y in range(ns))
        b=sum(pi[y]*alpha[u][y]*w[y] for y in range(ns))
        witness=sum(pi[y]*w[y] for y in range(ns))
        field_price+=vol[u]*witness
        assert 0<=b<=min(a,witness) and b<=a/3 and a<=1
        if a and sum(pi[y] for y in range(ns) if Z[y][u]>0)==1:
            positive['U_one_and_positive']+=1
            if first_U_one is None:
                first_U_one = (trial,u,a,b,witness)
        for C in (F(1),F(2),F(5)):
            paid=min(a,C*witness)
            if a>b:
                retention=max(a-C*witness,F(0))/(a-b)
            else:
                retention=F(0)
            actual_left=sum(pi[y]*alpha[u][y]*(1-w[y])*retention for y in range(ns))
            assert 0<=retention<=1
            assert actual_left==max(a-C*witness,F(0))
            assert paid<=C*witness
            positive['beyond_current_soft']+=bool(paid>b)
            positive['fully_paid']+=bool(a and not actual_left)
            positive['unpaid']+=bool(actual_left)
            counts['row_fraction']+=1
            if actual_left:
                for s in (F(0),F(1),F(3),F(10)):
                    tail=sum(pi[y] for y in range(ns) if T[y][u]<=s*h)
                    assert tail < (1+s)*a/C
                    counts['posterior_tail']+=1
    price_bound=sum(f[y]*h*ln_lower(1+sum(mu[v]*cap[v][y] for v in range(nr))/h) for y in range(ns))
    assert field_price<=price_bound
    counts['matched_clock_field']+=1
print('PASS',counts,'total',sum(counts.values()))
print('positive',positive)
print('first_U_one_trial_row_a_b_F', first_U_one)
