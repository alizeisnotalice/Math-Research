# R386 — Paid rank jumps and paid failure of the small endpoint's strict past

## 1. Same-slot statement and order of payment

Freeze the entire original field and plan. In particular retain full f, real Lebesgue du,dv, m_u=f(Q_u)=q_uR_u^n, q_-≤q_u≤λ, a≤R_u≤b≤2a, K=exp(√n), original J/H/h, the physical clock including its terminal atom, surplus/target marks, and outside/dense/deep gates. The original strict far inequality is m_u>K m_v. No receivers are deleted and no J or Z is rebuilt.

Start from the actual R385 fractional remainder R_min. Its original pre-window row cost a_u and source minimum window are unchanged. The remainder is a positive mark on the original (r,y,u,v,target) traffic, and its positive receiver rows satisfy U_u>C/(C+1). Its already-paid source fee is Cλ(1+√n)W/q_-.

Define the global, inclusive mass-rank function

T_y(t)=∫_E c_w(y)1_{m_w≤t}dw/m_w,
Z_u(y)=Z_y(m_u/K−)=∫_E c_w(y)1_{m_w<m_u/K}dw/m_w,
J_b(y)=T_y(+∞).

The notation T is distinct from a source-window witness F. Put

A_n=1+n log(b/a),  J_max=A_n/q_-,
L=max(0,floor(log_2(J_max/h))).                                (1)

At each source define active mass quantiles t_j(y) at ranks 2^j h, for j=1,...,L, as in §2. The source windows are [t_j(y),K t_j(y)], only where that level is active.

Apply three disjoint payments, in this order, to the same actual R_min:

1. Pay actual traffic whose **large** mass m_u belongs to the union of these active quantile windows.
2. In the remaining traffic, pay actual edges with T_y(m_v)≤2h.
3. In the remaining traffic, pay actual edges whose **small** mass m_v belongs to the active level-2h window [t_1(y),K t_1(y)].

Call the exact remaining marked cost G_next. Then

R_min ≤ P_jump+P_low+P_small+G_next,                            (2)

where the following certified prices suffice:

P_jump ≤ λ L(1+√n)W/q_-,
P_low ≤ 4λh log_+(J_max/h)W,
P_small ≤ B_*(1+√n)W/q_-,
B_*=min(A_n/h, λ log_+(J_max/h)).                              (3)

More precise source-dependent prices are given below. No extra εX_q is introduced. The first price does not carry a factor C: it pays current-source traffic directly after the R385 fractional payment.

Every remaining edge keeps all old marks and satisfies

U_u>C/(C+1),
Z_u(y)>h,
T_y(m_u)<2Z_u(y),
T_y(m_v)>2h,
Z_y(m_v/K−)>h.                                                (4)

The last assertion is a newly established same-source strict-past property of the actual small endpoint. It does not assert Y_v, high row density A_v, a permissible next target plan, or inheritance of the original multi-step history.

## 2. Quantiles, atoms, and the paid large-end branch

The actual-center envelope gives J_b(y)≤J_max: with ρ=2||w−y||∞,

c_w(y)/m_w ≤1_{ρ≤b}/[q_- max(a,ρ)^n],

whose center integral is [1+n log(b/a)]/q_-. This uses the actual selected radii and real dw.

For j≥1 let ℓ_j=2^j h. The level is active at y exactly when J_b(y)≥ℓ_j. On this set define

t_j(y)=inf{t>0:T_y(t)≥ℓ_j}.                                  (5)

A rational-threshold version gives the same quantile and proves measurability. The mass bounds q_-a^n≤m_w≤λb^n make each active quantile finite and positive. The finite measure's right-continuous CDF satisfies T_y(t_j)≥ℓ_j and T_y(t)<ℓ_j for t<t_j. This allows both atoms and continuous or singular mass distributions. On inactive sources choose any finite positive fallback value but mask the window out; an inactive level is not a real window to be charged or used for coverage.

If J_max≤h, the original strict-past gate makes the entire cost zero. More generally L may equal zero. If h<J_max<2h there is no active level of the indicated form, and the argument below says the relevant large-end rank jump cannot occur.

Take any original live source with z=Z_u(y)>h. Suppose

                         T_y(m_u)≥2z.                         (6)

Choose j to be the first positive integer for which 2^j h>z. Then

z<ℓ_j≤2z≤T_y(m_u)≤J_b(y)≤J_max.

Thus j≤L and its level is active. Since ℓ_j exceeds the strict mass rank below m_u/K, its quantile is at least m_u/K. Since T_y(m_u)≥ℓ_j, the quantile is at most m_u. Hence

                   t_j(y)≤m_u≤K t_j(y).                       (7)

This proves that payment 1 contains all sources satisfying (6). Closed window endpoints are required: mass atoms at m_u/K or an exact quantile level are included. The strict inequality z<ℓ_j avoids mistaking an atom below the cutoff for a crossed level.

After payment 1 the exact surviving current sources therefore satisfy

                         T_y(m_u)<2Z_u(y).                    (8)

For N(y)=#{j≥1:2^j h≤J_b(y)}, the R382 large-end source-window receipt and a union bound give the sharper price

P_jump ≤ [λ(1+√n)/q_-]∫f(y)N(y)dy
       ≤ λ L(1+√n)W/q_-.                                    (9)

This is a finite union of actual source windows with every level paid. Its actual traffic is removed only once; overlapping windows do not duplicate cost. No uncountable radius/quantile union is assigned a free price. The construction uses full E and full f, not a pruned receiver family.

## 3. A true column bound on the rank-regular remainder

Before any new estimates, a source-exact target disintegration writes the actual positive cost in the R383 form

dΓ=ell(dr) f(y)dy [1_{J_y(r)≥H}/J_y(r)]
    θ(r,y,u,v)c_u(y)c_v(y)(m_u−m_v) μ(du)μ(dv),                (10)

where 0≤θ≤1 includes all actual residual marks. In particular it includes the original strict past and the regular support (8) after payment 1. This representation neither changes the source law nor assumes target/source independence.

Fix y and v. Use (m_u−m_v)μ(du)≤du and retain the actual labels until this positive bound. Original far matching gives R_v<R_u≤r, so Z_u(y)≤J_y(r). Integrating the **complete** original clock tail gives

∫_[R_u,b]ell(dr)=R_u^−n.

Consequently the actual source/exit cost is dominated by

                  f(y)c_v(y)μ(dv)dy · B_v(y),                 (11)

where

B_v(y)=∫_E [c_u(y)du/R_u^n]
  1_{m_u>K m_v}1_{Z_u>h}1_{T_y(m_u)<2Z_u}/Z_u.               (12)

The outgoing measure in (11) is explicitly f(y)c_v(y)dv/m_v. It is not du, not m_v dv, and not a source probability whose total may be silently dropped.

Using q_u≤λ and (8),

B_v(y)≤2λ∫_E [c_u(y)μ(du)/T_y(m_u)]1_{T_y(m_u−)>h}
      ≤2λ log_+(J_b(y)/h).                                  (13)

The first step also uses Z_u>h and K>1, which imply T_y(m_u−)≥Z_u>h. Dropping the further far-v restriction is a positive bound.

For clarity, the inverse-rank inequality used here is

∫1_{T(t−)>h} dT(t)/T(t)≤log_+(T(+∞)/h).                       (14)

At an atom with preceding rank a>h and new rank b, its contribution (b−a)/b is at most log(b/a). The continuous Stieltjes part integrates dT/T across the corresponding ranks. The occupied rank intervals are disjoint subsets of (h,T(+∞)], so summing gives (14). An initial jump across h is excluded by the strict left-rank condition, which is why no extra 1 is needed. Continuous singular parts satisfy the same monotone-change-of-variable identity. When T(+∞)≤h there is no permitted term. Zero denominators are zero by the original convention.

Equation (13) alone is **not** a W budget. Integrating all exits in (11) introduces J_b(y). The next step uses an actual endpoint restriction before removing that exit measure.

## 4. Payment of low-rank exits and strict-past failures

For every fixed y, the inclusive CDF gives the endpoint occupation estimate

∫_E c_v(y)μ(dv)1_{T_y(m_v)≤2h}≤min(2h,J_b(y)).                 (15)

An atom crossing 2h is excluded; an atom ending exactly at 2h is included. Thus no crossing-atom error term is needed. Applying (13) only to these actual exits proves

P_low ≤2λ∫ f(y)min(2h,J_b(y)) log_+(J_b(y)/h)dy
      ≤4λh log_+(J_max/h)W.                                  (16)

This is payment 2, a real original-cost branch. It does not erase the entire exit mass in (11).

Now consider a still-retained small endpoint with T_y(m_v)>2h but

                         Z_y(m_v/K−)≤h.                      (17)

The level 2h is active. Its quantile t_1 satisfies t_1≤m_v because T_y(m_v)>2h. Also t_1≥m_v/K, because the strict rank below m_v/K is at most h<2h. Therefore

                         t_1≤m_v≤K t_1.                     (18)

Payment 3, which removes this small-end window only after payments 1 and 2, covers every remaining failure (17), including mass atoms. This proves the last inequality in (4). If level 2h is inactive, T_y(m_v)>2h is impossible, so the argument creates no fictitious window.

Use the certified R376/R381 small-end receipt, with the same original source envelope

b_h(y)=min(A_n/h, λ log_+(J_b(y)/h)).

It gives the precise third price

P_small ≤[(1+√n)/q_-]∫ f(y)b_h(y)1_{J_b(y)≥2h}dy
        ≤B_*(1+√n)W/q_-.                                    (19)

The remaining traffic is a positive restriction of the original source-exact plan, so the receipt applies without changing that plan. Unlike payment 1, this is a small-end window and therefore retains its b_h/B_* factor. If this same branch has already been removed by an earlier receipt, its actual cost is zero and its new price can be omitted; it is never paid twice.

No property of Y_v or α_v was used to establish (18). Establishing a next accepted original transition from v would require additional work.

## 5. All scales, original parameters, and full ledger

Suppose the ledger entering R385/R386 is

BH≤G_core+E_old X_q+S_old,

where E_old already includes whichever R383 screening fees were actually taken. Combining R385 once with (2) yields

BH≤G_next+E_old X_q+S_old
 + {[(C+L)λ+B_*](1+√n)/q_-+4λh log_+(J_max/h)}W.              (20)

If starting with R_min and its C-price already written, add only (9), (16), and (19), not that C-price again. In the full entrance, the added positive source prices carry the same original outer multiplier 2Λ. No new receiver-budget coefficient, negative-square credit, target-cap change, or field/plan rebuild is made.

For the synchronized existing high-past choice

h=(1+√n)/(ε_0 q_-),
J_max/h=ε_0 A_n/(1+√n),

all occurrences retain that **same** ε_0. In particular

4λh log_+(J_max/h)
= [4λ(1+√n)/(ε_0q_-)]
   log_+[ε_0 A_n/(1+√n)].                                    (21)

Since b≤2a, A_n≤1+n log2. With the already fixed ε_0≤1, L is at most O(log(n+2)); no scale cost is suppressed. For C fixed or a logarithmic power, the window terms are root order times the displayed logarithmic factors. The endpoint fee is also root order with its explicit ε_0 inverse and logarithm. Any dependence of ε_0 on prior parameter allocations stays in (21); it is not silently replaced by a constant.

The genuine remaining task is G_next on (4). One now has same-source strict-past availability at the actual lower endpoint, but neither a conservative multi-step original-history flow nor a root-order budget for all of G_next has been established. In particular, an edge may reach a v with negligible original outgoing cost or without the next spatial/target marks. Such traffic cannot be deleted on the ground that v would fail a fresh high-row screen.

## 6. Reproducible checks and limitations

Executed locally:

python3 /tmp/r386_geometry_check.py

PASS {'quantile_cover': 2520, 'regular_column': 2520,
      'terminal_exit': 360, 'failed_endpoint_cover': 2520,
      'fractional_union': 261} total 8181
rank-jump covered 614
positive terminal cases 52
empty-level cases 144

The Fraction checks cover inclusive CDF quantiles at atoms, inactive and absent dyadic levels, strict-past equality, the regular-column inequality, the 2h endpoint occupation, the small-end failed-past window, and positive cost-splitting identities. The logarithmic comparisons are certified by rational lower bounds from the positive atanh series after reduction to [1,2], rather than floating-point fits. Tests include positive newly covered rank jumps and positive endpoint branches.

The script's finite rank measures are algebraic/measure-theoretic diagnostics, not native geometric receiver fields. The genuine Lebesgue-center statements and original physical clock costs are proved analytically in §§2–5. Extending the first script from an h endpoint cutoff to 2h initially left an obsolete ≤h test bound, which correctly failed; it was corrected to the proved ≤2h bound and all reported cases were rerun. That failed development run is not counted as passed evidence.
