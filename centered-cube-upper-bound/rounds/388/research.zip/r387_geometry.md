# R387 — Two disjoint rank-tail payments in the original joint traffic

## 1. Exact statement and unchanged contract

Start from the frozen R386 actual remainder G_next. Keep the same full f, receiver Lebesgue measures du,dv, matched masses m_u=f(Q_u)=q_u R_u^n, q_-≤q_u≤λ, K=exp(√n)>λ/q_-, complete physical clock ell, J/H/h, fixed target plan, and every original spatial, surplus and history mark. In particular no receiver family, source law, J, or Z is rebuilt.

Write μ(du)=du/m_u, c_u=1_{Q_u},

T_y(t)=∫ c_w(y)1_{m_w≤t} μ(dw),
Z_u(y)=∫ c_w(y)1_{m_w<m_u/K} μ(dw),
J_b(y)=T_y(+∞)≤J_max=A_n/q_-,  A_n=1+n log(b/a).

The original source-exact positive cost, after target disintegration, is

 dΓ=ell(dr) f(y)dy [1_{J_y(r)≥H}/J_y(r)]
     θ(r,y,u,v)c_u(y)c_v(y)(m_u−m_v) μ(du)μ(dv),       (1)

where 0≤θ≤1 includes all preceding restrictions and fractional retentions. On its support,

 m_u>K m_v,  Z_u>h,  T_y(m_u)<2Z_u,
 T_y(m_v)>2h,  Z_y(m_v/K−)>h,                         (2)

together with R385's near-full-union row support and all original gates. As usual X_q=∫q_u du and W=∫f.

Fix d>0 and 0<τ<1. Partition this same positive measure in the following order:

- Near-rank branch N: T_y(m_u)≤(1+d)T_y(m_v).
- On N's complement, low-relative-rank branch L: T_y(m_v)≤τ Z_u(y).
- The exact remaining branch M.

Then

 G_next=G_N+G_L+G_M,
 G_N≤(λd/q_-)X_q,   G_L≤τ X_q.                      (3)

The first estimate is Sol's rank-close receipt; its short derivation is included to fix the common measures and disjoint accounting. The new complementary receipt proved here is the second estimate. Neither requires the rank-regular condition in (2); regularity is used only to describe the final support.

Every edge of M satisfies the genuine two-end separation

             τ/2 < T_y(m_v)/T_y(m_u) < 1/(1+d),
             m_u>K m_v.                             (4)

Thus both extremely low relative rank and nearly equal rank are paid in the original receiver budget. All old restrictions in (2) remain. This is a paid branch result, not a general root-order bound for G_M.

## 2. Inclusive-rank occupation, including atoms

For a finite positive measure ν on the positive mass axis, let T(t)=ν((0,t]). For every A≥0,

                   ν{t:T(t)≤A}≤A.                   (5)

Indeed this set is an initial segment in the mass order. Its occupied mass is the supremum of its inclusive CDF values, at most A. If its endpoint is excluded, continuity from below gives the same assertion. An atom ending at A is allowed; an atom crossing A is excluded. This proof allows atoms, a continuous part, and a singular continuous part.

For a fixed mass x and B≥T(x), the same argument after removing the initial segment through x gives

              ν{t>x:T(t)≤B}≤B−T(x).                 (6)

All these expressions are measurable: the actual joint capture indicator is measurable, and its nonnegative parameter integrals define the CDF and strict CDF measurably. No exceptional receiver with zero ν-mass is used as a pointwise source witness.

Apply (5) to ν_y(dt), the pushforward of c_v(y)μ(dv), at the fixed (u,y)-dependent threshold A=τZ_u(y). It yields

 ∫ c_v(y)1_{T_y(m_v)≤τZ_u(y)} μ(dv)≤τZ_u(y).         (7)

Retaining the far restriction, actual r-membership, or any additional mark only lowers this bound. In particular a mass atom cannot produce an extra first-jump term.

## 3. The low-relative-rank receipt keeps the full clock

Far matching gives R_v<R_u: otherwise m_u/m_v≤λ/q_-<K. More generally every receiver counted by Z_u has radius below R_u. Hence on the original clock support R_u≤r,

                         Z_u(y)≤J_y(r).             (8)

Use (7) in (1), after retaining the actual near-rank complement until taking a positive upper bound. The loss satisfies (m_u−m_v)μ(du)≤du. Therefore

 G_L
 ≤τ∫ell(dr)∫dy f(y)∫_{R_u≤r}du c_u(y)
             1_{J_y(r)≥H} Z_u(y)/J_y(r)
 ≤τ∫du [∫f(y)c_u(y)dy] ∫_[R_u,b]ell(dr)
 =τ∫du m_u/R_u^n
 =τX_q.                                               (9)

The tail identity uses the entire physical clock, including its terminal atom:

 ell(dr)=nr^(−n−1)1_(a,b)(r)dr+b^(−n)δ_b(dr),
 ell([R_u,b])=R_u^(−n).

The cancellation is full-source matching, not a source density cap or a replacement by boundary volume. The actual cost may have arbitrary source-dependent target and history marks because only 0≤θ≤1 was used. On a live row Z_u>h>0, (8) ensures J>0. Terms with zero J are zero by the original convention and create no division. Receiver masses are positive by the q-band.

## 4. Near-rank receipt and disjoint joint support

For fixed (v,y), far implies m_u>m_v and Z_u≥T_y(m_v). On the near-rank branch (6) gives

 ∫ c_u(y)1_{m_u>K m_v}1_{T_y(m_u)≤(1+d)T_y(m_v)} μ(du)
 ≤d T_y(m_v).                                         (10)

If T_y(m_v)>0, bound 1/J≤1/Z_u≤1/T_y(m_v) in the original clock. After loss≤m_u, full-clock integration and du/R_u^n=q_u μ(du)≤λμ(du), the column cost per actual exit f(y)c_v(y)μ(dv)dy is at most λd. Zero-rank exits have zero μ_y-measure by (5) with A=0. Consequently

 G_N≤λd∫f(y)J_b(y)dy=λd|E|≤(λd/q_-)X_q.             (11)

This uses the exact identity ∫fJ_b=|E|. It is not a W-price, nor a bound obtained by dropping the exit measure.

After N then L are removed, T_v>(τZ_u) and T_u>(1+d)T_v. Since the R386 support has T_u<2Z_u, (4) follows, strictly. The surviving fractional marks are the actual restrictions of (1), not a reconstructed row or target plan.

## 5. Full price and precise remaining task

Let the entire frozen R386 ledger be

                  BH≤G_next+E_386 X_q+S_386.

Then the same-slot ledger is

 BH≤G_M+[E_386+λd/q_-+τ]X_q+S_386.                   (12)

No W-fee, new window, target-cap enlargement, extra square subtraction, or change to the synchronized h is introduced. For an extra same-slot allowance ε, one may set d=εq_-/(2λ) and τ=ε/2 when 0<ε<2. If this slot is carried through the original outer factor 2Λ, the new price is 2Λ(λd/q_-+τ)X_q; allocate the corresponding internal ε accordingly. All R386 source fees and their original h/ε_0 dependence remain exactly as frozen.

For a fixed source y only, any composable sequence of k actual surviving edges has ranks decreasing by a factor greater than 1+d at every step. Because each retained small endpoint has rank >2h,

                (1+d)^k < J_max/(2h).               (13)

In particular k≤ceil(log_+(J_max/(2h))/log(1+d)); if J_max≤2h there are no such edges. This is only a combinatorial statement about a fixed-source sequence whose every edge already satisfies the actual gates. It supplies neither a conservative original flow nor terminal source payment. The actual receiver/source transition redraws the source; (13) cannot be applied across those redraws without a new argument.

The unproved interface is now specific: control the original marked joint traffic satisfying both exponential mass separation and the intermediate source-rank ratio (4), while preserving the cross-source near-full-union support. The present estimates do not give a root-order W budget for that traffic. In particular no small endpoint's Y, row qualification, or next history is inherited, and no sum of fixed-source path lengths is being charged to W.

## 6. Actual local checks

Executed locally:

    python3 /tmp/r387_geometry_check.py

    PASS {'cdf_atoms': 2019, 'clock_matching': 720,
          'joint_support': 4549} path_checks 108 total 7396
    positive_cases {'near': 324, 'low_after_near': 110, 'middle': 475}

All arithmetic uses Python Fraction. Stage 1 tests inclusive CDF cutoffs with repeated masses, exact endpoints and crossing atoms. Stage 2 enforces full finite source matching m_u=Σ_y f(y)c_u(y), q_u=1, R_u=m_u (n=1), and evaluates the complete physical clock exactly on every interval plus its terminal atom. It verifies near and subsequent low payments, their combined price, and the exact surviving rank ratios under nonconstant retained marks. Stage 3 checks the fixed-source rank contraction separately.

The finite incidence systems in stages 2–3 are algebraic diagnostics, not asserted to be native cubes, octave fields, or synchronized historical examples. The actual Lebesgue-cube theorem follows from (5)–(11); computation is only a reproducibility check of its measure and clock algebra. No independent numeric root-budget claim is made.
