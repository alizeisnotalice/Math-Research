# R383 — Receiver-budget absorption before cancelling the source clock

## 1. Original positive flow, with all marks frozen

Fix the same full f≥0 in L¹ and actual Lebesgue receiver set E as in R382. Write c_u=1_{Q_u}, m_u=∫f c_u=q_uR_u^n, q_-≤q_u≤λ, a≤R_u≤b≤2a, μ(du)=du/m_u, E_r={R_u≤r}, J_y(r)=∫_{E_r}c_v(y)μ(dv), and X_q=∫q_u du. The physical clock is

ell(dr)=n r^(−n−1)1_(a,b)dr+b^(−n)δ_b,

so ell([R_u,b])=R_u^(−n), including the terminal atom. Fix K>max(1,λ/q_-), and the original H>0 and strict mass-past threshold h. Zero J rows contribute zero.

Let 0≤θ(r,y,u,v)≤1 contain the original remaining positive marks and be supported on

m_u>K m_v,   Z_y(m_u/K−)>h,

where Z is the original full-field strict mass past. Dense/deep, source-window-complement and surplus/high-density restrictions may be included. All J, m, f and gates remain those of the original field. Define the actual marked remainder

G=∫ell(dr)∫f(y)1_{J_y(r)≥H}/J_y(r)
       ∫_{E_r²}θ c_u(y)c_v(y)(m_u−m_v) μ(du)μ(dv)dy.           (1)

No negative square is added to this already positive G. The results below apply to this precise positive slot and any further positive mark in θ. A transport remainder can enter only after its own source-exact disintegration has produced such a mark with value in [0,1]; its other plan/template fees remain unchanged.

## 2. Exact receiver density and column conservation

For every actual receiver u define two probabilities

ν_u(dr)=R_u^n 1_[R_u,b](r)ell(dr),
π_u(dy)=f(y)c_u(y)dy/m_u.

These are identities from the original clock and full-f matching, not independence assumptions about the source and the marks. Define

b_u(r,y)=1_{J_y(r)≥H}/J_y(r)
          ∫_{E_r}θ(r,y,u,v)c_v(y)(1−m_v/m_u)μ(dv),
α_u(y)=∫b_u(r,y)ν_u(dr),
A_u=∫α_u(y)π_u(dy).                                           (2)

Set b=0 on zero J. Positivity and the original prefix give 0≤b_u,α_u,A_u≤1. The exact cancellation of dimensional factors is q_u R_u^n/m_u=1, and therefore

G=∫_E q_u A_u du≤X_q.                                         (3)

In particular A_u is a cost density relative to the actual receiver-budget measure q_u du. It is not a fraction defined separately for each source y.

More explicitly the complete marked flow is

q_u du ν_u(dr)π_u(dy)
 [1_{J_y(r)≥H}θ(r,y,u,v)c_v(y)(1−m_v/m_u)μ(dv)/J_y(r)].         (4)

Its u marginal is q_uA_u du. Its small-receiver marginal is κ(v)dv, where

κ(v)=1/m_v ∫_E du ∫_[R_u,b]ell(dr)∫f(y)c_u(y)c_v(y)
       1_{v∈E_r}1_{J_y(r)≥H}θ(r,y,u,v)(1−m_v/m_u)/J_y(r)dy.   (5)

Thus ∫κ(v)dv=G exactly. Formula (4) is a subprobability kernel after dividing by q_u du; it does not imply the unrelated column bound κ(v)≤q_v. No such column estimate or reversible measure is assumed. The original (r,y,u,v) labels are retained throughout (4).

## 3. A single εX_q payment with a full-f source capture guarantee

Take 0<ε≤1 and δ=ε/3. Define, using the unmodified functions (2),

E_hi={u:A_u>2δ},   Y_u={y:α_u(y)>δ}.

Split the same positive flow (4), in this order, into:

1. u∉E_hi;
2. u∈E_hi and y∉Y_u;
3. u∈E_hi and y∈Y_u.

Let G_core be the third part. Then

G=G_receiver-low+G_source-low+G_core,
G_receiver-low≤2δX_q,   G_source-low≤δX_q,

and hence the new receiver receipt is

G≤εX_q+G_core.                                                (6)

Proof: the first part is ∫_{A≤2δ}q_u A_u du. For the second, at each retained u,

∫_{α≤δ}α_u dπ_u≤δ.

Both bounds integrate against the original q_u du. They are disjoint payments, not a repeated charge for the same flow.

For every u∈E_hi, the core source set carries definite **full-f** mass:

f(Q_u∩Y_u)/m_u=π_u(Y_u)
≥(A_u−δ)/(1−δ)>δ/(1−δ).                                     (7)

Indeed A_u≤δπ_u(Y_u^c)+π_u(Y_u). Moreover the retained core row density

A_u^core=∫_{Y_u}α_u dπ_u≥A_u−δ>δ.                             (8)

Thus remaining receivers are not merely receivers containing a negligible source probe with a broad mass spectrum. They capture at least δ/(1−δ) of their actual full-f mass in the explicitly defined high-flow source set, and their retained original flow still has density greater than δ relative to q_u du. The strict inequalities and their inclusive low complements cover all threshold atoms.

This is a paid positive branch of the original G, with no new W fee or target-cap multiplier. It is not a root-order bound for G_core. If an outer entrance multiplies G by 2Λ, the added receiver fee is exactly 2ΛεX_q; all existing source, template and other entrance fees remain.

## 4. What the remaining sources actually satisfy

For fixed (u,y), put Z_u(y)=Z_y(m_u/K−). Since K>λ/q_-, every receiver counted in Z_u has R_v<R_u. Hence all of that strict mass past is already in the original J_y(R_u), and for r≥R_u,

0≤b_u(r,y)≤Z_u(y)/J_y(r)≤Z_u(y)/J_y(R_u)≤1,                 (9)

on nonzero rows; define zero ratios as zero where appropriate. Consequently, for π_u-almost every y∈Y_u,

Z_u(y)>h,   Z_u(y)>δ J_y(R_u).                               (10)

The first follows because the original strict-past gate vanishes identically when Z_u≤h; the second follows from α_u>δ and (9). These are genuine statements about the captured full-f source set (7), before cancelling J. They preserve the original prefix and mass atoms. They assert no deterministic value of the later physical r: α is the actual clock average.

If θ contains the original surplus factor and a high-density restriction,

θ≤s_v(y):=(1−q_v/f(y))_+1_{f(y)>Tq_v},

with zero on f=0, then in addition

α_u(y)≤(1−q_-/f(y))_+1_{f(y)>Tq_-}.                           (11)

Thus Y_u lies, up to f-null sets, in

{f>Tq_-}∩{f>q_-/(1−δ)}.

There is also a simpler optional receipt: A_u≤π_u{f>Tq_-}, so all receivers with f(Q_u∩{f>Tq_-})≤εm_u cost at most εX_q. This is an alternative low-receiver criterion, not an extra fee to add to (6). Neither statement bounds the global L¹ mass of the high-density tail.

For every y∈Y_u, the positive α integral witnesses actual small receivers with m_v<m_u/K, captured y, and the original marks. It does **not** show that such a v belongs to E_hi, that the same y lies in Y_v, or that a later endpoint inherits (7)–(10). To use these sets in a mass-descending chain one must either prove transfer to a next eligible receiver or explicitly stop and pay the failed transfer. The column identity (5) alone supplies no such payment. The source sets depend on u; their masses cannot be summed as if disjoint. This is the precise remaining interface, rather than an unproved Carleson claim or an assumption on a second occupation moment.

## 5. Reproducible exact checks and scope

`/tmp/r383_flow_check.py` was actually executed with Fraction arithmetic:

`PASS {'posterior': 1500, 'clock_flow': 7752, 'absorption': 288} total 9540`.

The first stage checks the strict/inclusive posterior thresholds and mass guarantee. The other stages use actual cubes with sides 1, 3/2, 2 in dimensions 2, 3, 4 and a positive piecewise-constant full source between 7/8 and 9/8. Exact cube masses satisfy q∈[3λ/4,λ], λ=9/8. They verify (3) by independently summing the original pair/clock flow and both receiver marginals; check (9)–(11); and check the three disjoint parts and all fees in (6). The source is completed by density 1 outside the tested cells within [-4,4]^n. Receiver integration in these tests is finite positive quadrature, not a native Lebesgue-receiver realization. Rational K examples verify the algebraic K>λ/q_- assertions, not every original exponential parameter. The analytical proof applies to real du, the full continuous clock and its terminal atom.
