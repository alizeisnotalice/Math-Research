# R381 — finite true-source trees: merge the path before paying receivers

Status: proved finite-tree receipts and exact marked-plan accounting. This reduces the repeated node-mass bill to a source entropy bill. It does not prove that arbitrary hard-field residual traffic is covered at a root-order price. No external Bellman theorem or Carleson assertion is used.

## 1. Frozen contract and the finite tree

Let f≥0 be integrable, W=∫f<∞. Actual receiver centers v are integrated with dv, with actual cubes Q_v of side R_v and

m_v=∫_{Q_v}f=q_v R_v^n,   q_-≤q_v≤λ.

All original source marks, J, strict mass past, high-J gates and the physical clock remain frozen. Write c_v(y)=1_{Q_v}(y). Let μ_v be the original high-source measure, or any positive submeasure satisfying

μ_v(dy)≤f(y)c_v(y)dy/m_v.

For example the R379–380 high-source measure is 1_{f>Tq_v}(f−q_v)_+c_v dy/m_v. Let τ_v(dy,dz) be a jointly measurable source-exact plan with first marginal μ_v. Its original nonnegative marked cost satisfies

0≤C_v(y,z)≤b(y)≤B_*.

In the R380 slot one may use b(y)=min(A_n/h,λ log_+(J_b(y)/h)) and B_*=min(A_n/h,λ log_+(A_n/(q_-h))). The statement below also applies to any established bound b. No source dependence is removed from C or recomputed after splitting μ_v.

Fix a finite forest of measurable source sets S_N, independent of v. Roots partition the source measure f(y)dy; children partition their parent modulo that measure. Set M_N=∫_{S_N}f and omit zero-mass nodes. Each source y has a unique root r(y), leaf l(y), and ancestor path P(y), outside one f-null set. Put

L(y)=M_{l(y)},   U(y)=M_{r(y)},

so 0<L(y)≤U(y)≤W. Repeated unary nodes are allowed. These are source sets, not new receiver cubes or new matched-average constraints. The real-center proofs below actually require only measurable source anchors 0<L(y)≤U(y)<∞, not a tree. A true source tree is an optional construction that supplies the exact entropy accounting (4); it is not a necessary restriction on the parent’s general source-anchor theorem.

## 2. Soft path receipt

For m>0 define χ_N(m)=min(m/M_N,M_N/m), and set

w_v(y)=max_{N∈P(y)} χ_N(m_v).

This is measurable. A fixed root-to-leaf ordering selects the first maximizer N_*(v,y), including ties. Although the selected node depends on the receiver, the entire source partition and every M_N remain fixed.

The receipt is

∫dv∫w_v(y)C_v(y,z)τ_v(dy,dz)
≤(1/q_-)∫f(y)b(y)[2+log(U(y)/L(y))]dy.                         (1)

In particular, with

E_T=Σ_leaves ℓ M_ℓ log(M_{r(ℓ)}/M_ℓ),

the right side is at most B_*(2W+E_T)/q_-.

Proof. For any M_N∈[L,U], χ_N(m)/m=min(1/M_N,M_N/m²). Consequently

w_v(y)/m_v≤min(1/L(y),1/m_v,U(y)/m_v²).                         (2)

At a fixed source y set ρ=2||v−y||∞ and x=q_-ρ^n. Actual capture c_v(y)=1 implies R_v≥ρ and m_v≥x. The three terms in (2) decrease with m_v, so

c_v(y)w_v(y)/m_v≤min(1/L,1/x,U/x²).

The Lebesgue volume of {v:2||v−y||∞≤ρ} is ρ^n. Thus integrating over all centers gives

∫ c_v(y)w_v(y)dv/m_v
≤(1/q_-)[∫_0^L dx/L+∫_L^U dx/x+∫_U^∞ U dx/x²]
=[2+log(U/L)]/q_-.

This is an envelope of the actual selector; no independent choice of R_v is made. Source exactness, C≤b, the domination of μ_v, and Tonelli prove (1). ∎

## 3. Whole mass-window option, not an additional bill

Define Ω_v(y)=1_{L(y)≤m_v≤U(y)}. A second, alternative receipt pays all original traffic in this window:

∫dv∫Ω_v(y)C_v(y,z)τ_v(dy,dz)
≤(1/q_-)∫f(y)b(y)[1+log(U(y)/L(y))]dy
≤B_*(W+E_T)/q_-.                                               (3)

Indeed actual capture and the window imply

c_v(y)Ω_v(y)/m_v≤1_{x≤U}/max(L,x),

whose radial integral is [1+log(U/L)]/q_-. Formula (3) has the exact unpaid complement m_v<L(y) or m_v>U(y). Formula (1) instead pays a soft portion even outside this interval. These are alternative decompositions; their fees must not both be charged for the same traffic.

For comparison only, if consecutive parent and child masses obey M_C/M_P≥r_0>0, then w_v(y)≥√r_0 whenever m_v lies between the leaf and root masses. The ratio is child over parent, not its reciprocal: for M_C≤m≤M_P,

w(m)≥max(m/M_P,M_C/m)≥√(M_C/M_P).

Outside the full interval, w=m/L for m<L and w=U/m for m>U. No ratio condition is needed for the hard-window receipt (3).

## 4. Exact entropy accounting and what has been saved

Finite source conservation gives the exact identity

E_T=Σ_internal N Σ_child C of N M_C log(M_N/M_C).                (4)

To prove it, expand log(M_root/M_leaf) as the sum of edge logarithms on that leaf path. The total leaf mass below C is precisely M_C. This is a source-mass telescoping identity, not a receiver-clock telescoping assertion.

If root r has N_r positive-mass leaves, then

E_T≤Σ_roots r M_r log N_r≤W log(max_r N_r).                       (5)

For p_ℓ=M_ℓ/M_r, the bound Σp_ℓ log(1/p_ℓ)≤log N_r follows by applying log t≤t−1 to t=1/(N_r p_ℓ) and summing with weights p_ℓ.

The naive nodewise R380 bound is (2B_*/q_-)Σ_N M_N, counting each source once for every ancestor. In (1) it is replaced by (B_*/q_-)(2W+E_T); in (3) by (B_*/q_-)(W+E_T). Unary repetitions have zero edge entropy and no additional fee, irrespective of depth. This is a genuine reduction of the repeated-source accounting. It is not automatically numerically smaller for every particular tree: a single very unbalanced split can have a large pointwise log ratio, whereas the integrated entropy remains at most W log N.

A usable sufficient source-price condition is B_*(1+E_T/W)/q_-=O(√n polylog(n+2)); it must be checked, not presumed. Even when it holds, coverage of the original residual still requires controlling the explicit complementary source/receiver masses.

## 5. Actual arrival, stopping, children and terminal plans

Here is an exact finite marked flow realizing the soft split, rather than a separate payment at every ancestor. On node N set

r_N(v,y)=1_{S_N}(y)[1−w_v(y)1_{N_*(v,y) is a strict ancestor of N}],

s_N(v,y)=w_v(y)1_{N_*(v,y)=N}.

The incoming plan is r_N τ_v, the stopped plan is s_N τ_v, and outgoing is (r_N−s_N)τ_v. The latter is nonnegative. For every internal node, its children partition S_N, hence their incoming plans sum exactly to its outgoing plan. Roots receive the full plan. At leaves, the terminal plan sums to (1−w_v(y))τ_v. Therefore

Σ_N s_N τ_v+(1−w_v)τ_v=τ_v,                                   (6)

including every original time and source mark, and the same identity holds for costs and target marginals. Integrating r_N against μ_v is the actual node-arrival mass; it is not generally M_N or a fixed multiple of M_N. The terminal cost is exactly ∫(1−w_v)C_v dτ_v and remains unpaid. This is a finite decomposition, with no claim of a nonanticipative stochastic stopping time.

The hard-window option has the simpler exact split Ω_v τ_v+(1−Ω_v)τ_v. It uses (3), not (1).

One may also replace the paid part by its source measure times the original uniform probability U_v on Q_v, and apply an existing source-exact cap-t plan to the remaining source measure. If d_paid and d_rem are their masses, with d_paid+d_rem=d_v≤1, the total target is at most

(d_paid+t d_rem)U_v≤t d_v U_v,  t≥1.                            (7)

Thus there is no new target-cap or uniform-template multiplier. The original C_v and all its marks remain fixed. The terminal plan's actual cost, or its newly constructed R378 Hall-deficit bill, must still be retained; normalization of the residual source does not by itself prove an improved Hall deficit. The (T+t)Γ template and other original fees remain as in the chosen underlying entry. Any original outer multiplier applies to (1) or (3) once, just as to any other source fee.

## 6. Exact remaining issue and verification

This construction avoids charging the same source at every tree level, and supplies a legal receiver-adaptive path choice. It does not establish that a tree with controlled mass entropy covers the difficult actual receivers. A global root of mass W covers the upper inequality m_v≤W, but taking leaves small enough to cover all relevant lower masses can increase the number of leaves and their entropy. There is no free Carleson estimate here, no assumed equality of source density and volume, and no deletion of terminal traffic.

Local exact checks: `/tmp/r381_tree_check.py` was actually executed and returned

`PASS stages [4770, 496, 465] total 5731`.

Stage 1 checks genuine finite mass partitions, path stopping/terminal conservation and the formal logarithm coefficients of (4), for balanced, comb and unary trees. Stage 2 checks rational radial majorants and outer-tail constants. Stage 3 checks arbitrary finite marked-plan splitting, unchanged target marginals and (7); it is an algebraic plan test, not a native cube field or a matching test between its independently chosen source weights and the stage-1 tree masses. None of these finite checks replaces the analytic radial integration or proves the unpaid general coverage assertion.

The E03 tree-budget skill was used to audit arrival/child/terminal definitions. Its external Bellman theorem and constants are not invoked.
