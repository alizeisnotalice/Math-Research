from fractions import Fraction as F
from itertools import product
from collections import Counter
C=Counter()
def ck(k,b):
 C[k]+=1
 assert b,k
# Stage 1: exact source-window envelope, including zero-width and boundaries.
for L in (F(1,8),F(1),F(3),F(9)):
 for ratio in (F(1),F(3,2),F(2),F(9)):
  U=L*ratio
  for z in [L*F(j,8) for j in range(0,81)]+[L,U]:
   for m in [L,L*F(5,4),U,(L+U)/2,U*2]:
    lhs=1/m if L<=m<=U and m>=z else F(0)
    rhs=1/max(L,z) if z<=U else F(0)
    ck('closed_window_envelope',lhs<=rhs)
# Stage 2: finite common-source anchor, nonuniform weights, tied knots.
for weights in product(range(4),repeat=4):
 masses=[F(1,4),F(1),F(1),F(4)]
 def score(s):return sum(w*min(m/s,s/m) for w,m in zip(weights,masses))
 best=max(score(s) for s in masses)
 for s in [F(k,16) for k in range(1,97)]:
  ck('finite_anchor_knots',score(s)<=best)
 # Finite optimal closed ratio window: exact candidates vs dense tests.
 for ratio in (F(1),F(2),F(4)):
  value=lambda s:sum(w for w,m in zip(weights,masses) if s<=m<=ratio*s)
  maximum=max(value(m) for m in masses)
  for s in [F(k,16) for k in range(1,65)]:
   ck('finite_window_knots',value(s)<=maximum)
# Stage 3: varying anchors at distinct sources and probability kernels.
for seed in range(40):
 M=[F(1),F(2),F(4),F(8)];W=[[F(1+(seed+i*3+j)%7) for j in range(4)] for i in range(6)]
 total=F(0);best_fixed=F(0)
 for row in W:
  scores=[sum(w*min(m/s,s/m) for w,m in zip(row,M)) for s in M]
  total+=max(scores)
  p=[F(1,10),F(2,10),F(3,10),F(4,10)]
  ck('probability_anchor_vs_best',sum(a*b for a,b in zip(p,scores))<=max(scores))
 for s in M:best_fixed=max(best_fixed,sum(sum(w*min(m/s,s/m) for w,m in zip(row,M)) for row in W))
 ck('source_adaptation_vs_fixed',total>=best_fixed)
print('PASS',dict(C),'total',sum(C.values()))
print('Finite exact algebra only; continuum occupation is proved analytically.')
