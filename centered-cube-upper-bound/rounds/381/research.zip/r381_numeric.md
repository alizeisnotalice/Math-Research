# R381 — common source anchors, global tree prunings, and layer repetition

## Primary decision evidence

The strongest tested source-common anchor is more flexible than requiring its value to equal a real cluster mass. In the frozen 2D sample it gives χ-weighted share **1**, whereas the best legal depth-0..3 pruning gives 20015/20933 and the best single level gives 1699/1903. In 1D the common anchor cannot separately follow different receiver masses at the same source cell: it exactly matches the best legal global level/pruning, while a receiver-private oracle is strictly larger and repeats source charges.

| Field | Best single global level χ/B | Best legal pruning χ/B | Best common source anchor χ/B | Receiver-private level oracle χ/B |
|---|---:|---:|---:|---:|
| Equal 1D | 3167/3387 | 3167/3387 | 3167/3387 | 1074/1129 |
| Weighted 1D | 3725669/3930069 | 3725669/3930069 | 3725669/3930069 | 1258923/1310023 |
| 2D | 1699/1903 | 20015/20933 | 1 | 20015/20933 |

Here B is the unchanged original **uniform-product** bad cost. These are weighting/qualification statistics, not new transport plans. In particular χ/B=1 does not assert a zero-cost cap2 coupling or contradict the earlier Hall obstruction: it identifies traffic available to a different proposed source-priced receipt. No general anchor-payment theorem or hard-slot bound is numerically certified.

## Frozen input and actual cost

All R380 source densities, positive-volume cells, actual cube matching q=1 and m=R^n, receiver quadrature weights, common original C=L−K, source labels and full finite ω/J/past/clock fields are unchanged. Original B values remain

    1129/304128, 1310023/267079680, 66605/23814144.

Actual source masses are W=4,4,33/4. Receiver integration is finite quadrature, not dx; original gates are the declared finite diagnostic gates, not native high-dimensional hard history. The code reconstructs all fields and uses actual original cost including both receiver weights.

For every original source cell it first aggregates positive bad contributions from **all v**, by their true matched receiver mass m_v. Original fields and density are constant on that cell. No source anchor or window is selected separately for v.

## Exact best arbitrary source-common anchor

For cell y, with its actual integrated bad weights a_m, maximize

    F_y(s)=Σ_m a_m min(m/s,s/m),  s>0.

It suffices to evaluate s at the positive-cost mass values m. Between consecutive such masses,

    F_y(s)=A s+B/s,   A,B≥0,

so it is convex in s and reaches its interval maximum at an endpoint. Below the smallest mass it increases; above the largest it decreases. This elementary finite-profile argument proves candidate sufficiency; the script does not claim an infinite numeric sweep. It evaluates every candidate using Fraction, and also checks the piecewise formula at exact endpoints and midpoint as a harness check.

The optimal anchor is 1 on every positive-bad cell in both 1D fields, shared by m=1 and m=3/2 contributions. In 2D the only two positive-bad source cells are 94 and 106; both have only m=9/4 cost, so the common anchor 9/4 gives χ=1. On all other source cells set s=1, explicitly extending to a global source-only measurable anchor. The saved per-cell table includes weights by m, every candidate score and selected s.

The exact weighted costs are 3167/912384, 3725669/801239040, 66605/23814144, leaving weighting remainders 5/20736,365/1430784,0. The source mass is counted once as W. This is the evaluation of a common source anchor; the analytic source-price lemma is a separate main-proof question.

## Best common source windows

For K=1,4/3,2, on each source cell choose one closed interval [s,Ks] maximizing Σ_m a_m1{s≤m≤Ks}. Candidate left endpoints are the positive-cost masses m. Any nonempty captured set can move its left endpoint to its smallest captured m without losing it, proving finite candidate sufficiency. The same chosen window serves all v at that source. Zero-cost source cells receive an arbitrary default window and do not affect the objective.

| Field | K=1 covered/B | K=4/3 covered/B | K=2 covered/B | Uncovered cost for K=1 or 4/3 |
|---|---:|---:|---:|---:|
| Equal 1D | 909/1129 | 909/1129 | 1 | 5/6912 |
| Weighted 1D | 1105623/1310023 | 1105623/1310023 | 1 | 365/476928 |
| 2D | 1 | 1 | 1 | 0 |

The proposed formal source-window multipliers are 1,1+log(4/3),1+log2, respectively; W is still counted once. These symbolic coefficients are not fitted numerically or asserted as a new proven global bound by this check. Full coverage at K=2 is unsurprising here because nonzero bad cost has only the few listed receiver masses; it is not a general concentration certificate.

## One fixed dyadic source tree and all legal prunings

The source domain [−2,2]^n has one global phase −2 and depths 0,1,2,3, with side lengths 4,2,1,1/2. Zero-mass nodes are omitted. Exact intersections split original cells when needed; source masses and original bad weights split by the exact volume fraction. The same tree is used for every v.

The 1D trees have fifteen positive nodes each and **26 legal prunings** each. The 2D tree has 21 positive nodes and **226 legal prunings**. All 278 are enumerated exactly, not sampled. Every pruning is an antichain covering every positive-source finest path once. It has Σleaf M=W, preserves the whole original B, and evaluates χ and the narrow closed ratio band [1/2,2] with the actual leaf mass M.

The selected global partition maximizes actual χ-weighted bad cost, then narrow-band coverage; ties prefer fewer/coarser leaves. It is one global partition, not a collection of receiver-private partitions. The result saves all pruning objectives, the selected leaves and every node's actual mass and bad-by-v distribution.

Both 1D winners are the four depth-2 intervals, each mass 1. They gain nothing from unequal depths in this bounded tree. The 2D winner has these five positive-source leaves:

- depth 1 index (0,0), mass 11/4;
- depth 1 index (0,1), mass 5/2;
- depth 2 index (2,1), mass 9/4;
- depth 2 index (3,1), mass 1/4;
- depth 1 index (1,1), mass 1/2.

Their masses sum to 33/4 and their boxes are disjoint up to null boundaries. This improves the 2D χ share from 1699/1903 to 20015/20933 while retaining full [1/2,2] coverage. It still falls short of the arbitrary source-anchor share 1 because the tree cannot freely set every relevant leaf mass to 9/4.

## Receiver/private path oracles and source-repeat account

The receiver-level oracle chooses one depth independently for each positive-bad v. It is explicitly **not** a common global partition. In all three samples it uses depths 1 and 2. Paying both complete layers by their source masses would cost 2W: 8,8,33/2, compared with W for every legal pruning.

A finer diagnostic permits each (v,source path) to choose its best depth. It equals the receiver-level oracle on these samples. This oracle is not, by definition, one common global leaf partition charged only once by W; its score can nevertheless coincide with a legal pruning, as in the 2D sample. Its selected node union is examined directly:

- In both 1D fields it selects both depth-1 parents and the two middle depth-2 children. Source union mass is 4, but summed node mass is 6. Exactly source mass 2 is charged twice. The oracle gain therefore cannot silently be combined with the W=4 single-partition fee.
- In 2D the relevant selected nodes are depth 1 (0,0) and depth 2 (2,1); they are disjoint, total mass 5. Adding the untouched source complement gives W=33/4 with no repeated source charge. This explains why a legal nonuniform pruning can attain the same oracle score here.

If all four complete levels were paid, source mass would be counted four times: 4W=16,16,33. These are normalized mass-ledger diagnostics, not computed main-theorem constants. The script verifies the exact identity selected-node mass = source-union mass + repeated source charge, using finest source paths and their ancestor multiplicities.

The restriction here concerns only claiming a single global-partition receipt with a single W charge. It does **not** prohibit the oracle selection in other explicitly paid constructions. The current main tree theorem permits pathmax and supplies a separate 2W+entropy source budget; receiver-private fixed-level choices are also covered by that pathmax bound with its price. The node/repetition totals above are concrete sample mass ledgers, not a computation or refutation of that analytic budget. No entropy fee is evaluated in this experiment.

For the narrow [1/2,2] criterion, every positive-bad source path first qualifies at depth **1** in all three fields. Thus these inputs do not require multilayer selection merely for that band; the layer conflict arises when improving the χ score. Full path records include m, every node mass, all eligible depths, first eligible depth and the private best-χ depth.

There is no universal ordering between the common arbitrary-anchor class and the receiver-private tree oracle: the latter is higher in 1D but lower in 2D because it has incompatible receiver-specific freedom and a restricted mass menu. The code checks only the valid comparisons: common anchors dominate legal source-only prunings; path-private choices dominate the tree restrictions they relax.

## Actual execution and reproduction

The local standard-library Python script actually ran and reran fresh, passing **862 exact grouped assertions**. These cover all 278 pruning antichains/budgets, 25 parent mass/cost identities, eight positive-bad-cell anchor optimizations, 24 common source-window optimizations, original mark reconstruction, exact cell splits and overlap/source-repeat ledgers. No MATLAB, LP, random search or dimensional fit is used.

The implementation initially attempted to inspect child aggregate costs before initializing them and also imposed an invalid ordering between a common-source anchor and a receiver-private oracle. Both were corrected in the harness; the final checks and stated class comparisons above use the correct definitions, with no change to source inputs or objectives.

Standalone reproduction uses `r381_numeric.py` and `r381_numeric.input.json`:

    /Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 r381_numeric.py

`r381_numeric.result.json` stores actual cell anchors/windows, every tree node and pruning score, source-path choices and exact repeated-source ledgers. Optional prepare snapshots frozen R380 input/result with their SHA256; verify reads no older temporary data or scripts. Only R381-owned files are written.

Scope: genuine positive-volume L1 source cells and frozen original finite diagnostic cost, uniform-product baseline, receiver quadrature rather than dx, and finite source-price alignment evidence rather than native hard/root certification. The useful distinction is common-source choice versus receiver-private choice and the exact mass budget required to pass between them.
