# R381 — Geometry scope check and a source-exact first-moment baseline

This bounded note does not claim a new root-order geometric payment. The R381 source-adaptive anchor/window receipts are proved separately in /tmp/r381_anchor.md; they remove the need for a global source partition. The present check keeps the original R379 dense-deep high-source field and identifies what remains unproved.

## Exact baseline for every source-exact plan

Let μ_v^H=1_{f>Tq_v}(f−q_v)_+c_vdy/m_v, and let τ_v have precisely this source marginal. The target may be any legal one from the current construction. Since C_v=L_v−K_v∈[0,L_v],
\[
 G_H(\tau)\le\int_Edv\int L_v(y)\,\mu_v^H(dy)\le X_q. \tag{1}
\]
This is not restricted to the product plan. Here is the direct original-clock proof, without first substituting the uniform logarithmic envelope.

Use the exact original representation
\[
 L_v(y)=\int_Edu\,A_{uv}c_u(y)
 \int_{[R_u,b]}\ell(dr)
 {1_{J_y(r)\ge H}1_{Z_y(m_u/K-)>h}\over J_y(r)},
 \quad 0\le A_{uv}\le1_{\{m_v<m_u/K\}}.
\]
Full source exactness and positive Tonelli bound the sum over v, at fixed u,y,r, by
\[
 \int_E {1_{f>Tq_v}(f-q_v)_+c_v(y)\over m_v}A_{uv}\,dv
 \le f(y)Z_y(m_u/K-)\le f(y)J_y(r).
\]
The final inclusion uses the actual mass/radius matching and K>λ/q_-: every strictly smaller-mass receiver has R_v<R_u≤r. Thus the original reciprocal J cancels on the retained positive gate; zero denominators contribute zero. Removing the remaining positive gates only after this cancellation gives
\[
 \int dv\int L_v\,d\mu_v^H
 \le\int_Edu\int f(y)c_u(y)dy
        \int_{[R_u,b]}\ell(dr)
 =\int_E {m_u\over R_u^n}du=X_q.
\]
The inclusive clock tail includes its physical terminal atom. No mdu-reversibility, density cap, source independence, or old negative-square credit is used.

As an explicitly limited consequence, put
m_-=q_-a^n, m_+=λb^n and s_0=√(m_-m_+). Then every plan above obeys
\[
 \int dv\int C_v(y,z)|\log(m_v/s_0)|\,d\tau_v
 \le\frac12\left[n\log(b/a)+\log(\lambda/q_-)\right]X_q. \tag{2}
\]
This only uses the full allowed mass range and (1). Its dimension-linear width is not the desired root-order concentration and is not recorded as a new payment.

## Exact geometric limit of the present argument

For a fixed source y, write z_v=(v−y)/R_v∈[−1/2,1/2]^n whenever c_v(y)=1. Then
\[
 Q_v=y+R_v\bigl(z_v+[-1/2,1/2]^n\bigr).
\]
For a FIXED normalized offset z, these sets are nested in R because the reference box is convex and contains the origin. The actual selector does not keep z_v fixed. Treating all receivers through y as one nested ray family, or introducing an independently integrated offset/radius, would therefore require an additional proved domination. None has been established here.

The paid sparse/shallow reductions impose, on each retained (u,v), j(u,v)>n/8 and total truncation>n/20. They do not by the present proof align the responsible coordinates, directions, or mass scales for different v through the same y. No conclusion is drawn that such alignment is impossible; only that it has not been deduced from the full matching.

The high-source gate is likewise not a radius-concentration statement: at a source point with f(y)>Tλ it accepts every q_v in the frozen band. Small geometric p_uv remains unrelated to an assumed source density cap.

The outstanding interface is therefore concentration of the ACTUAL cost-weighted receiver mass spectrum for an admissible source-dependent anchor/window, with all original gates and target-plan correlations retained. The source-adaptive receipts can pay the chosen mass window or soft anchor kernel. Their exact outside-window or 1−χ residual has not been bounded here. Equation (2) cannot be relabeled as a √n estimate, and the unknown residual is not assigned a new paid quantity.

## Actual local verification

The saved /tmp/r381_geometry_check.py was executed locally on 2026-10-18:
PASS 162 exact source-clock cases; 108 positive high-source cases

These Fraction checks use the same full f to compute receiver masses and q, retain strict mass-past gates and the physical terminal clock atom, and verify 0≤high-source first moment≤full-surplus first moment≤X_q. They are finite receiver quadrature diagnostics, not native dense-deep Lebesgue examples. The universal first-moment assertion is proved above. No further counterexample or tree-threshold search was undertaken.
