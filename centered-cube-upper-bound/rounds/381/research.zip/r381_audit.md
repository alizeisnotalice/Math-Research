# R381 independent audit — FINAL PASS

Final author-proof, full-code, numeric-scope and complete-ledger review is finished. No substantive correction remains. The source-only adaptive anchors/windows and finite-tree path/entropy receipts pass under the stated original full-f contract. General cost-spectrum concentration, complementary-cost budgets and global closure remain unproved. Only this audit file was modified; historical interfaces were used as identified, not comprehensively re-audited.

The pre-author screens below are preserved as chronology. Their status has been superseded by the completed final review and byte bindings at the end.

## 1. Stronger source-anchor interface: PASS

The R380 actual-center lemma is uniform in its positive reference mass. More precisely, on ONE frozen full-f hard field and for every source point y and every M>0,

    integral_E c_v(y) chi_theta(m_v/M) dv/m_v <= c_theta/q_-,
    chi_theta(t)=min(t,t^-1)^theta,
    c_theta=2/theta (0<theta<=1), 1+1/theta (theta>=1).

The same actual matching/null receiver set is used for every y,M. Its explicit radial majorant proves the statement pointwise in those parameters; this is not a family of unrelated a.e.-in-y statements whose exceptional sets could be selected by M. Consequently any measurable source anchor s(y) in (0,infinity), independent of the receiver v being integrated, is legitimate. It need NOT equal the actual mass of a source cluster.

For any one original high-source-exact plan tau_v, let its full original cost be C_v(y,z), with C<=b_h(y)<=B_star. Source exactness and Tonelli give

    G_s(tau)=integral dv integral chi_theta(m_v/s(y)) C_v d tau_v
    <= (c_theta/q_-) integral f(y)b_h(y)dy
    <= c_theta B_star W/q_-.

The argument retains actual Lebesgue dv, full-f q/m/J/H/omega and all clock/pair/source gates. It positively dominates the original first-source marginal by f(y)c_v(y)dy/m_v. No product assumption on f, source density cap, radius averaging or private q recomputation is involved. The anchor may depend on the entire frozen field and the same plan's aggregate sourcewise cost spectrum: the inequality is uniform over every such choice. It must remain one source-only function, not s(v,y)=m_v selected independently for each receiver.

A measurable probability kernel pi_y(dM) on positive finite masses is equally legal. Define chi_pi(v,y)=integral chi_theta(m_v/M)pi_y(dM). Joint measurability and nonnegative Tonelli first in M then v give the SAME price, since pi_y has total mass one. A subprobability kernel is allowed if the unassigned traffic is explicitly retained. Countably supported source-only weights are a special case. This is more general than a global leaf partition: neither actual cluster masses nor an antichain requirement is necessary for the weighted theorem. Such structures may help produce a useful anchor but are not assumptions of its proof.

The exact identity is G(tau)=G_s(tau)+R_s(tau) on the SAME plan. One may not subtract G_s from an old upper Hall bill. A source-anchor theorem is not a statement that R_s has a root budget or that a fixed fraction of G is paid. The anchor mismatch may remain large under the actual sourcewise cost law.

## 2. Finite-spectrum best anchor: PASS

At a fixed source y suppose the aggregate cost spectrum is a finite nonnegative measure with masses w_l>=0 at actual receiver masses m_l>0. Put x=log M and x_l=log m_l. Its paid score is

    F_y(x)=sum_l w_l exp(-theta |x-x_l|).

For nonzero spectrum, between consecutive distinct knots F_y''=theta^2 F_y>0. Hence no maximum on a nontrivial knot-free interval exceeds its endpoints. Outside the extreme positive-weight knots the function is monotone toward the knots and tends to zero outward. Therefore a maximum is attained at an actual positive-weight mass m_l. Equal masses may be merged. Zero-weight knots may harmlessly remain in the finite candidate list. If all weights vanish, every anchor has zero score and a deterministic positive default is allowed.

For finitely many measurable candidate masses and weights, select the first maximizing index in a fixed order; this is measurable, including ties and zero cases. There is no optimizer theorem or infinite-dimensional attainment claim in this finite result. It optimizes the anchored weighted cost for the chosen frozen plan, not the full original hard-slot cost or a ratio after h/marks are changed. A continuum spectrum requires its own measurable-kernel/selection justification; the finite knot statement alone does not supply one.

## 3. Tree interpretations and valid conservation

A globally selected source leaf partition is a sufficient anchor construction: choose for each y a leaf mass, once for all v. It may depend on the whole frozen field. The leaves' source masses sum to W if they genuinely partition f, but the source-anchor proof does not require this stronger interpretation. A source-only choice of an ancestor, a measurable reference unrelated to a node, or a probability mixture over nodes also has the same receipt.

If a tree is used to construct fractional source weights, a safe sufficient bookkeeping rule is pointwise in original source y:

    root budget b_root(y)<=1,
    spent_node(y)+sum_child b_child(y)<=b_node(y).

Positive induction over finite generations and Tonelli give sum_node spent_node(y)<=1. The spent masses, not every inherited node budget, can then serve as a subprobability mixture over reference node masses. Any carried/unspent limit source must remain an explicit residual. Counting b_node at every level instead would spend the same source repeatedly; mass conservation between parent and children alone does not mean all levels can each charge W.

Receiver-private depth selection j(v,y) is different. The pointwise condition sum_j a_j(v,y)<=1 does not produce a source-only kernel pi_y. For a tree with D complete partition levels, directly summing D per-level receipts gives at most D*c_theta B_star W/q_-, before any additional receiver absorption. Choosing the best node separately for each v cannot silently replace that by a single W charge. A proof needs either source-only weights, an explicit dominating source budget for all used node weights, or a NEW joint center inequality for the actual adaptive selector. The fact that a geometric sequence of reference masses has a bounded pointwise sum of chi weights does not imply its receiver integral has the single-reference c_theta/q_- bound; occupation over many mass scales still requires settlement.

Thus no global tree alignment, Hall-deficit improvement or cross-level summability follows merely by rewriting the R380 weighted receipt. A meaningful new theorem must bound the original cost-weighted anchor mismatch, or give a legal complete plan and explicit price for its complementary source.

## 4. Complete-plan/target-cap requirements

Marking the SAME existing plan by source-only anchor weights does not alter its source or target; the complement is an exact positive restriction. For a rebuilt plan, split the original high source into chi_s*mu_H and (1-chi_s)*mu_H. Paid product target is d_paid U. Apply the R378 layered construction to the normalized residual source only, retaining the same full-f kernel, h and marks. Its target is at most t*d_rem U. Thus total target <=t*d_H U for t>=1, preserving the original (T+t)Gamma tariff. The residual normalized Hall deficiencies must be recomputed; they need not decrease.

With several rebuilt node plans of source masses d_j(v), exact original-source sum and total target inequality are BOTH required. If target_j<=t_j*d_j U, the usable common capacity is the actual sum_j t_j*d_j, not merely sum_j d_j. Uniform t_j<=t gives cap t*d_H if their source pieces partition mu_H. Repeated full residual plans at multiple depths do not acquire target capacity for free. A globally bounded source budget does not by itself prove this target condition.

The two complete accounting options remain separate: actual anchored residual R_s for the old plan, or a newly constructed residual Hall bill with its approximation errors and template tariff. No capture rebate, negative square, old Hall upper bound or different-parameter cost can be combined across those options without a fresh exact identity. Original entrance and all outer/history/soft/scale obligations remain unchanged at this screening stage.

## 5. Bounded local mathematical-tool evidence

Reviewer actually ran a standard-library Fraction check on 2026-10-18: 23,232 finite-spectrum grid comparisons at theta=1 confirmed that the best tested positive anchor does not exceed the actual-mass knot maximum; 69 pointwise fractional spending cases checked parent/child budget conservation; 99 target-capacity scalar cases checked weighted cap aggregation. Total 23,400 assertions PASS. These are bounded scalar verification only, not native continuum high-past realizations, an alignment theorem, or evidence for a general root fee. The analytic proofs above establish the stated screening conclusions. No author/parent pipeline was repeated and these reviewer counts remain separate from the parent totals.

Screen conclusion: the source-anchor/probability-kernel generalization and finite-spectrum maximizer are PASS; tree/target bookkeeping is as stated. No new unweighted general root payment or favorable adaptive alignment has been certified. This was the pre-author conclusion; the author and final ledger reviews below now complete the audit.

## 6. Additional independent screen: source-only closed mass windows

PASS for any given jointly measurable source-only endpoints 0<L(y)<=U(y)<infinity, with no receiver dependence. On the SAME plan restrict the ORIGINAL receiver mass by L(y)<=m_v<=U(y). At a fixed y put z=q_-(2||v-y||_infinity)^n. Capture and the closed mass restriction give

    c_v(y)1_window/m_v <= 1_{z<=U(y)}/max(L(y),z).

The exact center-volume change is dv=dz/q_- for this radial majorant, so its integral is [1+log(U/L)]/q_-. Thus the same-plan window cost is at most

    (1/q_-) integral f(y)b_h(y)[1+log(U(y)/L(y))]dy.

This includes both mass endpoints and any original radius atoms; it does not independently integrate a selector radius. There is no lambda/q_- enlargement. Finite positive endpoints ensure a finite pointwise constant, although its source integral can still diverge for arbitrary windows. Width log(U/L)<=sqrt(n) yields the genuine unweighted subbranch fee (1+sqrt(n))B_star W/q_-. The complementary original mass-marked traffic is retained. A private window per v would be a different quantifier.

The stated given-window result needs no optimization or selection theorem. Rational outward enlargements can approximate any finite closed interval while retaining its endpoint mass atoms; their width excess tends to zero. This fact by itself is not a claim that an optimal measurable window over every sourcewise spectrum has been selected. Such a claim should be separately formulated if needed; the parent proposes to retain only the given-window theorem.

## 7. Independent path-maximum envelope and its actual entropy cost

Let a fixed source-only reference path have its positive mass anchors within [L(y),U(y)]. It may include any finite subset, or the full interval as an envelope. Directly maximizing over M gives

    max_M chi_theta(m/M) = (m/L)^theta if m<L,
                           1 if L<=m<=U,
                           (U/m)^theta if m>U.

Taking the joint sup over actual m>=z produces the original near-zero part of the R380 envelope up to L, the middle density 1/z on [L,U], and the upper tail U^theta/z^(theta+1). Integration is exactly

    [c_theta+log(U/L)]/q_-.

For theta>=1 the lower part is the plateau 1/L and integrates to1, whereas for theta<=1 its integrable power integrates to1/theta. The upper part contributes1/theta in both cases. Therefore theta=1 gives (2+log(U/L))/q_-, including L=U. A finite path maximum is bounded by this interval envelope. No uniform receiver-private path without a source-only envelope is being granted this constant.

For a true global source partition tree with root mass W and terminal leaf mass M_leaf(y), the integrated logarithmic part is

    integral f log(W/M_leaf) = sum_leaf M_leaf log(W/M_leaf)
                            = W H((M_leaf/W)_leaf).

It is not a separate W payment at each depth, but it is also not free: entropy may grow or be infinite. For a finite conservative tree this equals the sum over internal nodes of M_node times the Shannon entropy of its child mass fractions, by exact telescoping. Countable extensions need nonnegative limits and explicit treatment of source not assigned to a positive-mass leaf. This supplies a real width/entropy tariff; a root bound still requires an actual bound on the integrated width/entropy or its original cost-weighted version. None is assumed.

These supplementary claims were screened before new R381 author proofs. Their subsequent author proof and final integration are reviewed below.

## 8. Author anchor proof and code review: PASS

After the independent screens, read /tmp/r381_anchor.md and the complete r381_anchor_check.py. Its source-anchor, source-only probability kernel and closed-window proofs agree with the independent derivations. No actual component-mass interpretation is needed, and no private per-v anchor is allowed. The given-window source tariff keeps b_h before its optional B_star bound and handles closed endpoints and zero-width windows.

The sourcewise cost-spectrum construction in §3 is legitimate. The original positive cost measure has total mass at most B_star integral_E d_v^H dv<=B_star|E|<infinity. Its y marginal is absolutely continuous by original source exactness. On standard Borel spaces it therefore has a measurable disintegration dy nu_y(dt), finite for a.e. y; a common null set can be assigned the zero kernel. This also handles costs with smaller source marginal. The completion convention does not license selecting different null versions for each candidate. Positive finite candidate anchors produce measurable scores; first-tie selection is explicit. The selected anchor remains source-only even when computed from all v in the same frozen plan.

For a fixed finite nu_y, dominated convergence gives continuity of the soft score in log anchor. A fixed countable dense positive candidate set consequently has supremum equal to the full soft supremum. Finite-prefix maxima increase to it; each prefix is covered by the single-selected-anchor theorem, and MCT proves the displayed integral upper bound. No general uncountable argmax selection, endpoint-continuity of hard windows, or interchange of sup with the v integral is used. The proof correctly limits hard-window optimization to given measurable windows or explicit finite candidate lists. For a finite mass spectrum, shifting a nonempty window's left endpoint to its least included mass retains all originally included knots when the ratio is fixed; knots/ties and the all-zero case are handled.

The standalone code's 80,648 assertions have the stated finite scope: 6,640 closed-window envelope comparisons, 24,576 finite soft-knot grid comparisons, 49,152 finite-window comparisons, 240 probability-anchor comparisons and 40 aggregate source-adaptation comparisons. All are rational theta=1 finite algebra. They are not quadrature evidence for a continuum disintegration, a general alignment theorem, or a closed-window argmax. Parent reports the full fresh actual run; this reviewer read the code without repeating it. The analytic proof establishes the continuum statements. The new author file is passed at these interfaces; final integration and byte bindings are completed below.

## 9. Geometry baseline and provisional main/ledger review: PASS

Read the frozen r381_geometry.md and its complete 162-case script. The general first-moment bound holds for every original high-source-exact plan, not merely a product: C<=L, source exactness gives an inner v integral at most f(y)Z_y(m_u/K-), and K>lambda/q_- places every strict smaller-mass receiver inside the actual current radius prefix. Hence Z<=J before removing positive gates. The original reciprocal J cancels only on its nonzero retained gate; the inclusive physical clock then has tail R_u^-n, including b's terminal atom, and matching gives integral q_u du=X_q. Zero gates need no division. The fixed geometric-mean mass anchor then has the displayed dimension-linear cost-weighted log-mismatch bound; it is explicitly not root concentration. Normalized offsets are not fixed by the actual selector, so no unsupported ray nesting is used.

The 162 Fraction cases recompute masses and q from one actual positive interval-source profile, keep the strict past and complete physical-clock weights, and report 108 positive high-source cases. Their receiver measure is finite quadrature and not native dense-deep dx. Parent reports a fresh full run; reviewer read the script without repeating it.

Read the current main and full inherited-plus-increment ledger. The preferred window option uses the SAME completed original plan and exact G=Gwin+Rwin, so its F_D=(1+D)B_star/q_- source tariff adds 2Lambda F_D W at the entrance and introduces no new target-cap or receiver approximation charge. The previous H/entrance, full-field/soft/history/scale/limit obligations and outside-window residual remain. Soft-anchor, window, path-max and rebuilt-Hall options are alternative complete decompositions, not credits summed on one traffic. Finite source-window optimization does not multiply the source tariff by candidate count. Rebuilding the residual keeps the source sum and t-cap target bound but requires its own normalized Hall deficiencies. The inherited epsilon/epsilon-prime errors are not mechanically added when using the exact same-plan residual instead of a Hall upper approximation.

The ledger's source-dependent path-width integral and finite-partition entropy identity agree with the independent screen; neither a generic entropy bound nor a general outside-window bound is claimed. The final tree/numeric/readme review and byte bindings are completed below.

## 10. Finite-tree author proof/code review: PASS

Read the frozen r381_tree.md and complete r381_tree_check.py. The theta=1 path-maximum proof correctly uses the whole reference interval rather than invoking a single-anchor tariff for a receiver-private maximizer. Its bound min(1/L,1/m,U/m^2), followed by capture m>=q_-(2distance)^n, has exact radial integral (2+log(U/L))/q_-. The hard full-window alternative removes the upper tail and has (1+log(U/L))/q_-. All anchors are original finite positive node masses on one source path; null source and zero-mass nodes are omitted. If W=0 every original source cost is zero and no positive-path construction is needed.

The finite forest entropy E_T=sum_leaf M_leaf log(M_root/M_leaf) equals the sum of parent-child edge contributions by source-mass conservation. Its bound by sum_root M_root log(number of positive leaves) follows with the correct log-inequality direction. Unary repetitions add zero entropy. This is an actual finite width/entropy tariff, not a universal root bound and not a claim that every tree is cheaper than every previous formula. Controlled source price still leaves coverage of the original cost outside the path/window unproved.

The marked-node accounting is exact: before the selected maximizer a node carries the whole source plan; at the selected node it stops weight w; descendants carry only 1-w. Children sum to the parent's outgoing restriction because they partition its source set. Leaves carry precisely the original terminal (1-w) plan. The same equality holds for target marginals and all original cost/clock/history marks. This need not be a nonanticipative stochastic stopping time and the author does not call it one. Replacing the total paid source by product and applying a t-cap plan to the residual has target (d_paid+t d_rem)U<=t d_v U, with no repeated per-node target grant. The new residual Hall bill, if used, remains separately required.

The 5731 Fraction script stages [4770,496,465] check finite balanced/comb/unary mass trees, formal log coefficient telescoping, scalar radial majorants and finite marked source-plan/target conservation. Its stage3 independent source weights are expressly not asserted to match the stage1 tree masses or realize a native cube field. Parent reports a fresh actual run; this reviewer did not duplicate it. The completed final numeric/integration review and SHA bindings follow.

## 11. Final numeric input, code, results and scope: PASS

Read the complete frozen numeric.py, final numeric.md, input schema/provenance, saved result summaries and detailed output structure. The input snapshots R380's same complete finite fields and uniform-product baseline. The code rechecks q=1 and m=R^n against the same original full source, reconstructs original diagnostic omega/J/strict-past/physical terminal clock, and reconstructs the all-u common original cost before computing anchor/tree statistics. No source/receiver fit or new plan is smuggled into the comparison.

The global dyadic tree has one fixed phase/domain and exact original-cell intersections. Parent masses and costs sum to children. All 26,26,226 positive-mass prunings are enumerated by either stopping at a node or taking one pruning of every positive child; each antichain covers every finest positive source path once. Global source budget W and original product bad cost are unchanged. The selected pruning is one global choice, not one choice for each receiver. The receiver-level and path-level oracle diagnostics deliberately relax that class, save the actual source multiplicity and do not use their scores with a free single-partition W tariff. The final note explicitly allows the path-max theorem to charge its different 2W+entropy price; these diagnostics are not a prohibition of that separately proved construction. No entropy price is evaluated numerically here.

For the new source-common anchor, original cost is first aggregated over every receiver v on each original source cell. One anchor is then chosen from that source's positive cost masses using exact score comparisons, with a deterministic global default on zero-cost cells. The same source-cell value serves every v. Finite candidate sufficiency follows analytically from the piecewise A*s+B/s convexity; the endpoint/midpoint code checks are harness checks, not a claimed exhaustive continuum sweep. Finite closed-window candidates and their endpoint masses are treated similarly. All saved source-common best-anchor/window and pruning values match the final notes. The 2D anchor share one is a weighted-cost qualification fact, not a zero-cost cap2 optimum or general concentration theorem. The note correctly rejects a universal ordering between different receiver-private and source-common classes.

Saved numeric result is PASS with 862 grouped Fraction assertions: 278+278 pruning coverage/budget tests, 25 parent identities, 8 common-anchor and 24 window optimizations, original finite-field reconstruction and cell-split/source-repeat identities among the remaining checks. The source support is genuine compact positive-volume L1 cells but receiver integration is quadrature and hard/history gates are finite diagnostics. Neither native high-dimensional Lebesgue traffic nor a uniform cost-spectrum concentration theorem is numerically certified. There is no MATLAB/LP/optimizer run claimed. Previously corrected harness order/class-comparison mistakes are disclosed without treating failed runs as passes.

## 12. Final ledger and decision: PASS

Read the final current main, inherited-plus-increment ledger and readme. R381's preferred source-window payment is on the SAME original plan, with exact Rwin outside the source-dependent closed mass window and source fee F_D=(1+D)B_star/q_-. Taking D=sqrt(n) gives its stated root/polylog price; no uniform coverage is inferred. Finite source-window selection does not multiply that price. Same-plan soft-anchor, hard-window and theta=1 tree path-max are distinct complete alternatives and are not charged together. The final ledger's tree constant is correctly 2+H(p), while the full path-span hard window has 1+H(p). General theta pathmax discussed in the independent screen is not attributed to the author's theta=1 theorem without qualification.

No target capacity is changed by merely marking the existing plan. A paid-product plus reconstructed residual-layer plan is a distinct explicit option: combined target remains <=t*d_H U, residual normalized Hall deficiencies must be recomputed, and no old Hall upper bill is reduced by subtracting a positive actual payment. The whole-field parameter h, q/m/J/omega, original time atoms and high-source restrictions are retained. New source tariffs acquire exactly the entrance factor 2Lambda. The original 8lambda H W, 2d_eff A_n W_nu/H, outer Lambda and remaining receiver/soft/history/source-scale/threshold/limit slots are preserved. The displayed kappa choice is only a slot-specific absorption, not a claim that other unpaid terms have been absorbed.

Parent reports fresh actual runs of all four standalone scripts: 80648 anchor, 5731 tree, 162 geometry and 862 numeric, totaling 87403 grouped exact assertions. This reviewer read each complete code/proof and relevant saved data rather than repeating that pipeline. Reviewer-only 23400 scalar Fraction assertions described above are separately counted and not merged with parent evidence. Packaging/re-extraction, LaTeX typesetting and repository actions are outside this audit; no PDF compilation is certified.

The remaining original cost-spectrum/window complement, path entropy/coverage if that option is used, and the complete historical/outer/soft/scale obligations remain unproved. R381 removes an unnecessary true-cluster restriction and gives legal source-adaptive/payment interfaces; it does not prove the desired general root weak bound. No substantive issue remains in the bounded statements and final ledger reviewed here.

## 13. Final SHA256 byte bindings

The following identify the exact reviewed files. The audit hash is reported separately after saving, to avoid a self-reference.

- `/tmp/r381_main.md` — `483f97101530dbef98b8953fbe23824f0aa927908289ff7d4806897814240050`
- `/tmp/r381_ledger.md` — `085b468bf2920f39e4c980b6f913b75e8574a4159df1ad81967acaf2c9bb7b6a`
- `/tmp/r381_readme.md` — `c8ddf660cd2296d77bbc5374c79d785bb46beca6662264be35948e134ef7bc93`
- `/tmp/r381_anchor.md` — `71c2a1c6e0b3281668e2d290839195bcf8c25883b0a2945454bbfd15b4aa4e3e`
- `/tmp/r381_anchor_check.py` — `c93c2b591f4c1314d94fcae96588bfbd5614084e0deaf349b6bd9d4d486146e9`
- `/tmp/r381_tree.md` — `9c959632908cd490fc3c5af0597ecc6cf7049c15df83ab83147ec7fc4051070c`
- `/tmp/r381_tree_check.py` — `48bc204fed7740c80b5c08ddf9bd1fb6020ed0ce0d0a7514d3c8aa9a719e009a`
- `/tmp/r381_geometry.md` — `df86a325407457678613cc00fb4de37023ff29fb5d6ce4b039238c148a2f071f`
- `/tmp/r381_geometry_check.py` — `6bcbc3b0be185536cd9eb3d7c71bf8448e656278aaabf29d50d7654ef8b24420`
- `/tmp/r381_numeric.md` — `d7f65f36661e547bdf14a9f5ef7b6cc60cf2c47645927e6d87cf5caa581f64af`
- `/tmp/r381_numeric.py` — `b5df07800b6ac2610c6a82055233da2cdb559748b2174c5ee30df2578e0fe672`
- `/tmp/r381_numeric.input.json` — `3642db90fbb3b325ae2180ef55fd5e7d6893d5eb1a40564a8b82f11401d70b59`
- `/tmp/r381_numeric.result.json` — `95098ea84b3cb9e280292ac7c6e27f3983fa2d46d640d58c0287f961abaf1d0a`

Necessary inherited interfaces, bound only at their stated uses rather than a fresh comprehensive historic audit:

- `/tmp/r380_geometry.md` — `a31eb2088e8cce3529394120538462b7b84057ed3e9c6844be74d54ae8fa2db9`
- `/tmp/r380_main.md` — `cc2f94bab4e6c7f7381fa69f7d3ef5cd34da439775d59409e9f9a515d99b5703`
- `/tmp/r380_ledger.md` — `2be8d048edd41903866716396c6ba9309bc461f9b92248e523e302f6bb2db52d`
- `/tmp/r380_audit.md` — `c918e17139b22aeb6046eaa2dd48872797e747791eb13c766a3b16e86d5622a5`
- `/tmp/r379_ledger.md` — `5f577d1d01cfe9ac3d992853c9e92cbe85e1fe5fc4e6758591b1858a8dcdc063`
- `/tmp/r378_layered.md` — `8d7f0361b15108b014b9fb7ddc8c124e17f268a2ba98ff7bb8ab2489b188e24d`
- `/tmp/r376_geometry.md` — `16c68acce633ca7df17e8f2506fbc31c4aa00495b89200c84b745289e5b3caa7`
- `/tmp/r370_geometry.md` — `fac02a43e18ed5dc3d5be7ef67a8ac9e34cbd4dd1e69912d6e29dffda597d81a`

FINAL PASS within the explicit scope above. Review stopped; no author/repository edits or general-closure claim.
