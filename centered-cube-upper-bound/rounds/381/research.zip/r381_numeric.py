#!/usr/bin/env python3
"""Fixed global source tree, exact pruning enumeration, and common source anchors."""
from fractions import Fraction as F
from pathlib import Path
from collections import Counter,defaultdict
from itertools import product
import json,sys,hashlib
BASE=Path(__file__).resolve().parent;COUNTS=Counter()
def ck(k,v):
 COUNTS[k]+=1
 assert v,k
def dot(a,b):return sum((F(x)*y for x,y in zip(a,b)),F(0))
def read(p):return json.loads((BASE/p).read_text())
def sha(p):return hashlib.sha256((BASE/p).read_bytes()).hexdigest()
def prepare():
 data=read('r380_numeric.input.json');out=dict(cases=data['cases'],provenance={p:sha(p) for p in ['r380_numeric.input.json','r380_numeric.result.json']},scope='Same real compact positive-L1 source and full finite diagnostic fields; uniform-product baseline. Global tree prunings are legal source partitions; receiver/path oracles are not. Source anchor is one common s(y) for all v, not v-dependent. No optimizer or native hard-gate claim.')
 (BASE/'r381_numeric.input.json').write_text(json.dumps(out,sort_keys=True,indent=2)+'\n');print('PREPARED three frozen fields; finite trees and common anchors only')
def keystr(k):return str(k[0])+':'+','.join(map(str,k[1]))
def ancestor(leaf,d):return (d,tuple(i//(2**(3-d)) for i in leaf[1]))
def fullmarks(c):
 n=c['n'];N=len(c['receivers']);A=c['A'];vol=list(map(F,c['volumes']));x=list(map(F,c['source_mass']));f=[a/b for a,b in zip(x,vol)];R=[F(r['R']) for r in c['receivers']];w=[F(r['weight']) for r in c['receivers']];centers=[list(map(F,r['center'])) for r in c['receivers']];m=[r**n for r in R];mu=[a/b for a,b in zip(w,m)];radii=sorted(set(R));h=F(c['h']);H=F(c['H']);kap=F(c['kappa']);omega=[list(map(F,row)) for row in c['omega']]
 ck('stage2_full_source_same_all_actual_matching',all(dot(row,x)==mass for row,mass in zip(A,m)) and sum(x)==F(c['actual_W']))
 expected=[[F(0)]*len(x) for _ in range(N)]
 for u in range(N):
  for y in range(len(x)):
   past=sum(mu[t]*A[t][y] for t in range(N) if m[t]<m[u]/kap)
   if past<=h:continue
   for l,r in enumerate(radii):
    if r<R[u]:continue
    J=sum(mu[t]*A[t][y] for t in range(N) if R[t]<=r)
    if J>=H:
     ell=r**(-n)-(radii[l+1]**(-n) if l+1<len(radii) else 0)
     expected[u][y]+=h*m[u]*ell/J
 ck('stage2_reconstructed_full_omega_J_past_clock',expected==omega)
 for p in c['plans']:
  v=p['v'];src=p['source_cells'];tgt=p['target_cells'];d=F(p['d']);rows=list(map(F,p['row']));cols=[d*F(u) for u in p['U']];K=[list(map(F,row)) for row in p['K']];L=list(map(F,p['L']));C=[list(map(F,row)) for row in p['cost']]
  ck('stage2_original_source_and_uniform_target_marginals',rows==[vol[y]*(f[y]-1)/m[v] for y in src] and cols==[d*vol[z]/m[v] for z in tgt] and sum(rows)==sum(cols)==d)
  Lv=[];Kv=[]
  for y in src:
   aa=[]
   for u in range(N):
    S=m[u]>kap*m[v] and 2*max(abs(a-b) for a,b in zip(centers[u],centers[v]))>R[u]
    aa.append(mu[u]*(1-m[v]/m[u])/h*omega[u][y]*A[u][y] if S else F(0))
   Lv.append(sum(aa));Kv.append([sum(aa[u]*A[u][z] for u in range(N)) for z in tgt])
  ck('stage2_one_common_objective_all_u_and_original_marks',Lv==L and Kv==K and C==[[L[i]-a for a in row] for i,row in enumerate(K)])
 return True

def partition(c,kind,depth=None):
 cells=[[(F(a),F(b)) for a,b in cell] for cell in c['cells']];x=list(map(F,c['source_mass']));vol=list(map(F,c['volumes']));n=c['n'];pieces={};labels={};domain=[(min(cell[i][0] for cell in cells),max(cell[i][1] for cell in cells)) for i in range(n)]
 for j,(cell,mass) in enumerate(zip(cells,x)):
  if not mass:continue
  if kind=='singleton':parts=[(('cell',j),F(1))];labels[('cell',j)]=dict(original_cell=j,bounds=[[str(a),str(b)] for a,b in cell])
  elif kind=='all':parts=[(('all',),F(1))];labels[('all',)]=dict(domain=[[str(a),str(b)] for a,b in domain])
  else:
   M=2**depth;axis=[]
   for i,(a,b) in enumerate(cell):
    lo,hi=domain[i];w=(hi-lo)/M;axis.append([(k,max(a,lo+k*w),min(b,lo+(k+1)*w)) for k in range(M) if max(a,lo+k*w)<min(b,lo+(k+1)*w)])
   parts=[]
   for tup in product(*axis):
    key=('dyadic',depth)+tuple(z[0] for z in tup);v=F(1)
    for k,a,b in tup:v*=b-a
    parts.append((key,v/vol[j]));bounds=[]
    for i,(k,a,b) in enumerate(tup):
     lo,hi=domain[i];w=(hi-lo)/M;bounds.append([str(lo+k*w),str(lo+(k+1)*w)])
    labels[key]=dict(dyadic_indices=[z[0] for z in tup],bounds=bounds)
  ck('positive_source_cell_exact_partition_no_overlap_mass_loss',sum(a for key,a in parts)==1 and all(a>0 for key,a in parts));pieces[j]=parts
 masses=defaultdict(F)
 for j,parts in pieces.items():
  for key,frac in parts:masses[key]+=x[j]*frac
 ck('global_full_f_cluster_masses_sum_W_once',sum(masses.values())==sum(x)==F(c['actual_W']) and all(m>0 for m in masses.values()))
 keys=sorted(masses,key=repr);ids={key:i for i,key in enumerate(keys)}
 return {j:[(ids[key],frac) for key,frac in parts] for j,parts in pieces.items()},[dict(cluster=i,mass=str(masses[key]),geometry=labels[key]) for i,key in enumerate(keys)]
def model(c):
 fullmarks(c);n=c['n'];W=F(c['actual_W']);rowcost=[];B=F(0);cellmasscost=defaultdict(lambda:defaultdict(F))
 for p in c['plans']:
  U=list(map(F,p['U']));w=F(p['weight']);m=F(c['receivers'][p['v']]['R'])**n
  for src,r,cost in zip(p['source_cells'],map(F,p['row']),p['cost']):
   value=w*r*dot(U,list(map(F,cost)));rowcost.append((p['v'],src,m,value));B+=value
   if value:cellmasscost[src][m]+=value
 # New primary diagnostic: one anchor per original source cell, shared by all v.
 anchors=[];anchorvalue=F(0);windowtotals={K:F(0) for K in [F(1),F(4,3),F(2)]}
 for src,by_mass in sorted(cellmasscost.items()):
  candidates=sorted(by_mass);scores={s:sum(a*min(m/s,s/m) for m,a in by_mass.items()) for s in candidates};s=max(candidates,key=lambda s:(scores[s],-s));score=scores[s];total=sum(by_mass.values())
  ck('common_source_anchor_best_all_candidate_nodes',all(score>=x for x in scores.values()) and 0<=score<=total)
  # Exact interval convex certificate uses F(s)=A*s+B/s; no infinite numeric sweep claimed.
  for lo,hi in zip(candidates,candidates[1:]):
   invcoef=sum(a*m for m,a in by_mass.items() if m<=lo);lincoef=sum(a/m for m,a in by_mass.items() if m>=hi)
   for t in [lo,(lo+hi)/2,hi]:
    actual=sum(a*min(m/t,t/m) for m,a in by_mass.items());ck('anchor_exact_piecewise_As_plus_Bovers',actual==lincoef*t+invcoef/t)
  windows=[]
  for K in windowtotals:
   wscore={left:sum(a for m,a in by_mass.items() if left<=m<=K*left) for left in candidates};left=max(candidates,key=lambda t:(wscore[t],-t));wv=wscore[left];windowtotals[K]+=wv
   ck('common_source_window_best_all_candidate_left_endpoints',0<=wv<=total and all(wv>=z for z in wscore.values()))
   windows.append(dict(K=str(K),left=str(left),right=str(K*left),covered_bad=str(wv),remaining_bad=str(total-wv),candidate_scores={str(k):str(v) for k,v in wscore.items()}))
  anchorvalue+=score;anchors.append(dict(source_cell=src,source_mass=c['source_mass'][src],bounds=c['cells'][src],anchor=str(s),cost_by_receiver_mass={str(m):str(a) for m,a in sorted(by_mass.items())},candidate_scores={str(t):str(v) for t,v in scores.items()},original_bad=str(total),weighted_chi_bad=str(score),unweighted_remainder=str(total-score),window_choices=windows))
 ck('anchor_source_cells_exact_bad_account',sum(F(a['original_bad']) for a in anchors)==B)
 windowout=[]
 for K,z in windowtotals.items():
  ck('source_window_covered_plus_remaining_exact',0<=z<=B and z+(B-z)==B);windowout.append(dict(K=str(K),covered_bad=str(z),covered_fraction=str(z/B),remaining_bad=str(B-z),unit_source_charge=str(W),price_multiplier='1+log('+str(K)+')'))
 ck('source_window_optimal_coverage_nondecreasing_in_K',windowtotals[F(1)]<=windowtotals[F(4,3)]<=windowtotals[F(2)])
 # Build precisely the fixed global dyadic tree (phase -2 on [-2,2]^n).
 nodes={};pieces_by_depth={}
 for d in range(4):
  pieces,clusters=partition(c,'dyadic',d);lookup={z['cluster']:(d,tuple(z['geometry']['dyadic_indices'])) for z in clusters};pieces_by_depth[d]={src:[(lookup[j],f) for j,f in parts] for src,parts in pieces.items()}
  for z in clusters:
   k=lookup[z['cluster']];nodes[k]=dict(mass=F(z['mass']),geometry=z['geometry'],cost_by_v=defaultdict(F))
  for v,src,m,value in rowcost:
   for k,frac in pieces_by_depth[d][src]:nodes[k]['cost_by_v'][v]+=value*frac
 for k,node in nodes.items():
  node['bad']=sum(node['cost_by_v'].values());node['chi']=F(0);node['covered']=F(0)
  for v,value in node['cost_by_v'].items():
   m=F(c['receivers'][v]['R'])**n;ratio=m/node['mass'];node['chi']+=value*min(ratio,1/ratio)
   if F(1,2)<=ratio<=2:node['covered']+=value
  if k[0]<3:
   children=[z for z in nodes if z[0]==k[0]+1 and tuple(i//2 for i in z[1])==k[1]];ck('tree_parent_mass_and_cost_equal_children',sum(nodes[z]['mass'] for z in children)==node['mass'] and sum(sum(nodes[z]['cost_by_v'].values()) for z in children)==node['bad'])
 root=(0,(0,)*n);fine=[k for k in nodes if k[0]==3]
 def enum(k):
  if k[0]==3:return [(k,)]
  children=sorted(z for z in nodes if z[0]==k[0]+1 and tuple(i//2 for i in z[1])==k[1]);out=[(k,)]
  for choices in product(*(enum(z) for z in children)):out.append(tuple(z for part in choices for z in part))
  return out
 prunings=enum(root);evaluated=[]
 for leaves in prunings:
  ck('legal_global_pruning_antichain_covers_each_source_path_once',all(sum(ancestor(z,k[0])==k for k in leaves)==1 for z in fine))
  mass=sum(nodes[z]['mass'] for z in leaves);bad=sum(nodes[z]['bad'] for z in leaves);chi=sum(nodes[z]['chi'] for z in leaves);covered=sum(nodes[z]['covered'] for z in leaves)
  ck('legal_global_pruning_source_budget_once_and_bad_unchanged',mass==W and bad==B and 0<=chi<=B and 0<=covered<=B)
  evaluated.append((chi,covered,leaves))
 best=max(evaluated,key=lambda t:(t[0],t[1],-len(t[2]),-sum(k[0] for k in t[2]),tuple(keystr(k) for k in t[2])));levels=[]
 for d in range(4):
  leaves=tuple(k for k in nodes if k[0]==d);levels.append((sum(nodes[k]['chi'] for k in leaves),sum(nodes[k]['covered'] for k in leaves),d))
 bestlevel=max(levels,key=lambda t:(t[0],t[1],-t[2]));ck('pruning_no_worse_than_best_single_global_level',best[0]>=bestlevel[0])
 # Receiver-level oracle: one depth per v, not one shared global partition.
 activev=sorted({v for v,src,m,value in rowcost if value});oracle=F(0);oraclechoices=[];oraclelevels=set()
 for v in activev:
  scores=[]
  for d in range(4):
   score=F(0);covered=F(0)
   for k in nodes:
    if k[0]!=d:continue
    value=nodes[k]['cost_by_v'].get(v,F(0));m=F(c['receivers'][v]['R'])**n;ratio=m/nodes[k]['mass'];score+=value*min(ratio,1/ratio)
    if F(1,2)<=ratio<=2:covered+=value
   scores.append((score,covered,d))
  win=max(scores,key=lambda t:(t[0],t[1],-t[2]));oracle+=win[0];oraclelevels.add(win[2]);oraclechoices.append(dict(v=v,depth=win[2],weighted_chi_bad=str(win[0]),covered_bad=str(win[1])))
 ck('receiver_private_level_oracle_above_single_level',oracle>=bestlevel[0])
 # Source-path oracle and required-level distribution; illegal pointwise-v layer choice.
 pathvalue=F(0);firstcovered=defaultdict(F);used=set();pathrows=[]
 for v,src,m,value in rowcost:
  if not value:continue
  for leaf,frac in pieces_by_depth[3][src]:
   cost=value*frac;path=[ancestor(leaf,d) for d in range(4)];eligible=[d for d,k in enumerate(path) if F(1,2)<=m/nodes[k]['mass']<=2];ratios=[m/nodes[k]['mass'] for k in path];chi=[min(r,1/r) for r in ratios];d=max(range(4),key=lambda z:(chi[z],-z));pathvalue+=cost*chi[d];used.add(path[d]);firstcovered[str(min(eligible)) if eligible else 'none']+=cost
   pathrows.append(dict(v=v,source_cell=src,fine_source_node=keystr(leaf),original_bad=str(cost),mass_path=[str(nodes[k]['mass']) for k in path],eligible_depths=eligible,first_eligible_depth=min(eligible) if eligible else None,best_chi_depth=d,best_chi=str(chi[d])))
 nodecharge=sum(nodes[k]['mass'] for k in used);union=F(0);repeats=F(0);multiplicity=[]
 for leaf in fine:
  count=sum(ancestor(leaf,k[0])==k for k in used);mass=nodes[leaf]['mass']
  if count:union+=mass
  repeats+=mass*max(count-1,0);multiplicity.append(dict(fine_node=keystr(leaf),source_mass=str(mass),selected_ancestor_multiplicity=count))
 ck('crosslayer_source_charge_exact_overlap_ledger',nodecharge==union+repeats and sum(node['mass'] for node in nodes.values())==4*W)
 ck('common_anchor_dominates_legal_pruning_path_dominates_private_levels',anchorvalue>=best[0] and pathvalue>=best[0] and pathvalue>=oracle)
 nodeout=[dict(node=keystr(k),depth=k[0],indices=list(k[1]),full_source_mass=str(z['mass']),original_bad=str(z['bad']),weighted_chi_bad=str(z['chi']),covered_bad=str(z['covered']),geometry=z['geometry'],cost_by_v={str(v):str(a) for v,a in z['cost_by_v'].items()}) for k,z in sorted(nodes.items())]
 return dict(name=c['name'],stage=c['stage'],n=n,W=str(W),uniform_product_bad=str(B),positive_tree_nodes=len(nodes),legal_pruning_count=len(prunings),best_single_level=dict(depth=bestlevel[2],chi_fraction=str(bestlevel[0]/B),covered_fraction=str(bestlevel[1]/B),source_charge=str(W)),best_legal_global_pruning=dict(leaves=[keystr(k) for k in best[2]],chi_fraction=str(best[0]/B),covered_fraction=str(best[1]/B),source_charge=str(W)),receiver_level_oracle=dict(chi_fraction=str(oracle/B),choices=oraclechoices,distinct_levels=sorted(oraclelevels),unit_source_charge_if_layers_separately_paid=str(len(oraclelevels)*W),not_a_legal_global_partition=True),source_path_oracle=dict(chi_fraction=str(pathvalue/B),first_band_depth_bad={k:str(v) for k,v in firstcovered.items()},selected_nodes=sorted(keystr(k) for k in used),selected_node_charge=str(nodecharge),covered_source_union_mass=str(union),repeated_source_charge=str(repeats),source_charge_including_uncovered_source=str(W+repeats),multiplicity=multiplicity,not_a_legal_global_partition=True),common_source_anchor=dict(chi_fraction=str(anchorvalue/B),weighted_chi_bad=str(anchorvalue),remaining_bad=str(B-anchorvalue),unit_source_charge=str(W),anchors=anchors,not_receiver_dependent=True,default_anchor_outside_positive_bad_cells='1'),common_source_windows=windowout,all_levels=[dict(depth=d,chi_fraction=str(score/B),covered_fraction=str(cover/B),source_charge=str(W)) for score,cover,d in levels],full_tree_multilayer_source_charge=str(4*W),tree_nodes=nodeout,path_diagnostics=pathrows,pruning_objectives=[dict(leaves=[keystr(k) for k in leaves],chi_bad=str(ch),covered_bad=str(cv)) for ch,cv,leaves in evaluated])
def verify():
 data=read('r381_numeric.input.json');cases=[model(c) for c in data['cases']];out=dict(status='PASS',exact_grouped_checks=sum(COUNTS.values()),check_counts=dict(COUNTS),cases=cases,scope=data['scope'],provenance=data['provenance']);(BASE/'r381_numeric.result.json').write_text(json.dumps(out,sort_keys=True,indent=2)+'\n')
 print(json.dumps({k:v for k,v in out.items() if k!='cases'}|{'cases':[{k:v for k,v in c.items() if k in ['name','n','W','positive_tree_nodes','legal_pruning_count','best_single_level','best_legal_global_pruning','receiver_level_oracle','source_path_oracle','common_source_anchor','common_source_windows']}|{'common_source_anchor':{k:v for k,v in c['common_source_anchor'].items() if k!='anchors'},'source_path_oracle':{k:v for k,v in c['source_path_oracle'].items() if k not in ['multiplicity']}} for c in cases]},sort_keys=True,indent=2))
if __name__=='__main__':prepare() if len(sys.argv)>1 and sys.argv[1]=='prepare' else verify()
