# R378 — A common geometric covering construction with logarithmic target capacity

## Frozen setting and intended use

Use the full actual kernel of R375–R377, actual Lebesgue receiver dv, source μ_v^+=d_vP_v (0≤d_v≤1), and uniform U_v on Q_v. All original source-dependent marks, strict past, physical clock and actual m/q remain fixed. Write C_v=L_v−K_v, 0≤C_v≤B=A_n/h. The construction may also use the dense-outward kernel of r378_geometry after that original pair restriction; it changes no source mark. It is an upper construction, not an assertion that the geometric deficiencies below are small.

Unlike the fixed cap-two constructions, permit t=O(log(n+2)) total target capacity. The original floor-plus-good price then uses (t+1)Γ_n. This is affordable within the requested root order with logarithmic loss. The purpose is to connect actual shared capture geometry at all relevant cost levels to a single legal plan, without requiring every source row individually to find half a cube of good targets.

## Finite shared capture relations from actual dyadic boxes

For each v use the standard countable dyadic subcubes D of Q_v, with a fixed half-open boundary convention. For any level τ>0 set
\[
 e_{v,y}(D)=\int 1_{\{D\not\subset Q_u\}}\theta_{v,y}(du),\qquad
 S_{v,D,\tau}=\{y\in D:e_{v,y}(D)\le\tau\}.
\]
Cube closure can be used in the omission test; boundaries are null for P_v and U_v. The actual θ is the R375 receiver measure, not an independent probability. Then
\[
 y\in S_{v,D,\tau},\ z\in D\quad\Longrightarrow\quad C_v(y,z)\le\tau
\]
up to the already specified harmless kernel null sets. This uses containment in the same original cubes, not a density bound on f. Each relevant y has some sufficiently fine admissible D: for θ-almost every u, y is interior to Q_u, and dominated convergence applied to shrinking dyadic cubes containing y gives e(D)→0. This existence does not imply that the union capacity can accommodate the source mass.

Restrict to depths at most M. The finite relation is the union of S_D×D. Partition source space by the Boolean atoms of these finitely many S_D and partition target space by depth-M dyadic cells. Add an edge between atoms when their product lies in one of those rectangles. Let p_i be their P_v masses and u_l their U_v masses; include source atoms with no edges. The maximum flow with source capacities p_i and target capacities u_l has mass 1−δ_{v,τ,M}, where the finite max-flow/min-cut identity gives
\[
 \delta_{v,\tau,M}
 =\max_{I}\left(\sum_{i\in I}p_i-\sum_{l\in N(I)}u_l\right)_+ . \tag{1}
\]
This is the actual joint union capacity: no sum of individual neighborhood volumes substitutes for the union. A finite maximizing flow defines a density plan π with first marginal≤P_v, second marginal≤U_v, and C≤τ on its support, by assigning each positive edge its flow times the normalized product of its two cell measures. Zero-mass cells carry zero flow.

Finite max flow can be chosen measurably in v: enumerate the finitely many possible graph patterns and LP bases, select the first feasible optimal basic solution by a fixed order, and use the constant-coefficient linear systems on each pattern. Capacities are measurable. For completeness, the finite flow polytope is compact, so its mass maximum exists. If a residual source-to-sink augmenting path existed, its positive minimum residual capacity would increase the mass. Thus there is none at a maximum. The residual reachable vertices define a cut attaining that mass. Give the row-to-target edges capacity two, greater than the total source mass one; every neighbor of a reachable row is then reachable. The cut is precisely the source mass outside I plus the target mass in N(I), giving (1); conversely every such cut bounds every flow. A maximizing vertex can be selected among finitely many bases by the fixed order. This proves the finite formula and the measurable construction without an infinite-dimensional strong duality or attainment theorem.

Relations increase with M, so δ_M decreases. Set δ_{v,τ,∞}=inf_M δ_{v,τ,M}. Given any ρ>0, choose the least M with δ_M≤δ_∞+ρ. It is finite and measurable. Thus a finite density plan achieves deficit at most δ_∞+ρ. This is only the closure of this explicit dyadic inner relation; equality with the optimum for an arbitrary full sublevel relation is neither needed nor asserted.

## Simultaneously compatible partial plans

Let 0<τ_0<τ_1<…<τ_J=\bar B with C≤\bar B. For j<J take the preceding partial plan π_j, write its first marginal as a_j(y)P(dy), 0≤a_j≤1, and its missing mass as δ_j. Put r_{−1}=1. Use as the j-th actual flow
\[
 \widehat\pi_j(dy,dz)=r_{j-1}(y)\pi_j(dy,dz),
 \qquad r_j=r_{j-1}(1-a_j).
\]
Every target is at most U and every source increment is at most the remaining source. The residual mass R_j=E_Pr_j satisfies R_j≤E_P(1−a_j)=δ_j. At the last stage use r_{J-1}(y)P(dy)U(dz), with cost≤\bar B. This fills the original source exactly. There are t=J+1 stages, hence total target≤tU. There is no assumption that the partial plans are independent, nested, or chosen after seeing a separately sampled source.

With R_{−1}=1 and R_J=0 the actual cost is bounded by
\[
 \sum_{j=0}^J\tau_j(R_{j-1}-R_j)
 =\tau_0+\sum_{j=0}^{J-1}(\tau_{j+1}-\tau_j)R_j
 \le\tau_0+\sum_{j=0}^{J-1}(\tau_{j+1}-\tau_j)\delta_j. \tag{2}
\]
All source weights d_v are restored before integrating over actual dv. If J=0 use the product plan directly and cost≤\bar B.

## Noncircular dimension and source fees

Fix η,ε,ε'>0. Define BEFORE rebuilding the original h-dependent field
\[
 \bar B=\frac{A_n\eta q_-}{2(1+\sqrt n)},\qquad
 t=1+\max\left(0,\left\lceil\log_2\frac{\bar B}{\varepsilon q_-}\right\rceil\right).
\]
When the ratio≤1 take t=1. Now set
\[
 \mathcal L_{n,t}=2+\frac{72+(t+1)\Gamma_n}{1+\sqrt n},\quad
 \varepsilon_0=\eta/\mathcal L_{n,t},\quad
 h=(1+\sqrt n)/(\varepsilon_0q_-).
\]
Since ε_0≤η/2, the actual B=A_n/h≤\bar B. This avoids choosing a number of layers through a circular dependence on its own template price. If t>1 use τ_j=min(2^jεq_-,\bar B), j=0,…,t−1. Otherwise use one product flow. The ceiling case gives strictly increasing levels before the last level; an exact power of two has no repeated last level.

For the finite approximation choose ρ=ε'q_-/\bar B (if ρ≥1 any finite depth meets the requested accuracy; no smallness assumption is needed). Formula (2) gives the same-field full surplus bound
\[
 G_{\rm layer}\le(\varepsilon+\varepsilon')X_q+\mathcal D,
 \qquad
 \mathcal D=\int_E d_v\sum_{j=0}^{t-2}
 (\tau_{j+1}-\tau_j)\delta_{v,\tau_j,\infty}\,dv. \tag{3}
\]
For t=1, take \mathcal D=0 and G≤εX_q. The error is at most \bar Bρ∫d_vdv≤ε'X_q. Every finite approximation depth may depend measurably on v; depth creates no additional target-capacity charge because each level contributes just one partial plan.

The original positive floor+good decomposition has bounds floor≤min(p,1−d), good≤min(d,tdp), hence their sum≤(t+1)p. Thus the original hard receipt becomes
\[
 B_H\le\mathcal D+(\eta+\varepsilon+\varepsilon')X_q+C_{338}W.
\]
Here C338 retains its full old formula with this ε0; its scale is
\[
 C_{338}=O_{\eta,\varepsilon}\bigl(\sqrt n\log^{3/2}(n+2)\bigr)
\]
for an octave A_n≤1+nlog2. This follows from t=O_{η,ε}(log(n+2)) and Γ_n=O(√(nlog(n+2))), not a numerical fit. No dimension dependence is hidden in ε or η. The outer 2Λ, entrance H costs, histories and all other ledger terms remain payable. One must use this new field consistently if η changes h; one cannot combine its computed deficiencies with a different field's marks.

The unproved problem is the actual geometry bound on \mathcal D (or on an appropriately refined weighted version), after restricting away the genuinely paid sparse-outward branch. Formula (3) gives a legal multi-layer common plan and exactly states that cost; it is not itself a root-order estimate of \mathcal D. The finite cap-two diagnostics do not prove its general size. No benefit from R377 is added on top of (3); different complete plans can only be compared on identical fields.
