from fractions import Fraction as F
from collections import defaultdict

counts=[0,0,0]

def make_tree(kind,n):
    children={};leaf_mass={};serial=[0]
    def node():serial[0]+=1;return serial[0]
    def build(ids):
        u=node()
        if len(ids)==1:
            leaf_mass[u]=F(1,n);return u
        split=len(ids)//2 if kind=='balanced' else 1
        children[u]=[build(ids[:split]),build(ids[split:])]
        return u
    if kind=='unary':
        root=node();u=root
        for _ in range(n):
            v=node();children[u]=[v];u=v
        leaf_mass[u]=F(1)
    else:root=build(list(range(n)))
    mass={};paths={}
    def visit(u,path):
        path=path+[u]
        if u in leaf_mass:mass[u]=leaf_mass[u];paths[u]=path
        else:
            for v in children[u]:visit(v,path)
            mass[u]=sum(mass[v] for v in children[u])
    visit(root,[])
    return root,children,mass,paths,leaf_mass

# Stage 1: finite true-mass partitions, source stopping flows, exact terminal.
for kind in ('balanced','comb','unary'):
    for n in range(2,17):
        root,ch,M,paths,leaf=make_tree(kind,n)
        for m in (F(1,64),F(1,8),F(1,3),F(1),F(3)):
            paid=terminal=F(0)
            for l,path in paths.items():
                chi=[min(m/M[u],M[u]/m) for u in path]
                w=max(chi);selected=path[chi.index(w)]
                incoming=F(1);stopped=F(0)
                for u in path:
                    stop=w if u==selected else F(0)
                    assert 0<=stop<=incoming
                    stopped+=stop;incoming-=stop
                assert stopped==w and incoming==1-w
                assert w<=min(F(1),m/M[l],M[root]/m)
                if m<M[l]:assert w==m/M[l]
                if m>M[root]:assert w==M[root]/m
                for p,c in zip(path,path[1:]):
                    if M[c]<=m<=M[p]:assert w*w>=M[c]/M[p]
                paid+=leaf[l]*w;terminal+=leaf[l]*(1-w)
                counts[0]+=3
            assert paid+terminal==M[root]
            assert all(sum(M[c] for c in cs)==M[u] for u,cs in ch.items())
            counts[0]+=2
        # Formal logarithm coefficients verify the entropy telescoping exactly.
        direct=defaultdict(F);edges=defaultdict(F)
        for l,ml in leaf.items():direct[M[root]]+=ml;direct[M[l]]-=ml
        for p,cs in ch.items():
            for c in cs:edges[M[p]]+=M[c];edges[M[c]]-=M[c]
        assert {k:v for k,v in direct.items() if v}=={k:v for k,v in edges.items() if v}
        counts[0]+=1

# Stage 2: real-center radial majorants with x=q rho^n, all rational.
for L in (F(1,8),F(1,2),F(1),F(2)):
    for ratio in (F(1),F(2),F(4),F(8)):
        U=L*ratio
        for m in (L/2,L,(L+U)/2,U,2*U):
            for x in (m/8,m/2,m):
                w=min(F(1),m/L,U/m)
                assert w/m<=min(1/L,1/x,U/(x*x))
                window=F(int(L<=m<=U))
                assert window/m<=(1/max(L,x) if x<=U else F(0))
                counts[1]+=2
        # Integrals: each outer soft piece contributes exactly one;
        # the hard window has only the central piece plus the common log interval.
        assert L*(1/L)==1 and U*(1/U)==1
        counts[1]+=1

# Stage 3: an actual marked finite source plan, split without target duplication.
source=[F(1,10),F(1,5),F(3,10),F(2,5)]
target=[F(1,6),F(1,3),F(1,2)]
for kind in ('balanced','comb','unary'):
    root,ch,M,paths,leaf=make_tree(kind,4)
    ordered=list(paths)
    for seed in range(31):
        m=F(seed+1,13)
        weights=[]
        for i in range(4):
            path=paths[ordered[i%len(ordered)]]
            weights.append(max(min(m/M[u],M[u]/m) for u in path))
        plan=[[source[i]*target[j] for j in range(3)] for i in range(4)]
        C=[[F((seed+2*i+3*j)%9,8) for j in range(3)] for i in range(4)]
        paid=[[weights[i]*plan[i][j] for j in range(3)] for i in range(4)]
        rem=[[(1-weights[i])*plan[i][j] for j in range(3)] for i in range(4)]
        assert all(paid[i][j]+rem[i][j]==plan[i][j] for i in range(4) for j in range(3))
        assert all(sum(paid[i])+sum(rem[i])==source[i] for i in range(4))
        assert all(sum(paid[i][j]+rem[i][j] for i in range(4))==target[j] for j in range(3))
        cost=sum(plan[i][j]*C[i][j] for i in range(4) for j in range(3))
        split=sum((paid[i][j]+rem[i][j])*C[i][j] for i in range(4) for j in range(3))
        assert cost==split
        # Replacing paid by product and residual by a cap-t plan preserves cap t.
        dw=sum(source[i]*weights[i] for i in range(4));dr=1-dw
        for t in (F(1),F(2),F(3)):assert dw+t*dr<=t
        counts[2]+=5
print('PASS stages',counts,'total',sum(counts))
