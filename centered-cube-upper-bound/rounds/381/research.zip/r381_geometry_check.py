from fractions import Fraction as F
count=0
positive=0
# Finite receiver quadrature for the source-exact first-moment interface.
# q comes from the same full f. Not a native dense-deep Lebesgue example.
for peak in (F(5,2),F(3),F(7,2)):
 for bg in (F(9,10),F(1),F(11,10)):
  low=(F(18,5)-peak)/3
  f=[peak,low,low,low,bg,bg,bg,bg]
  dy=[F(1,8)]*8
  c=[[1]*4+[0]*4,[1]*8]
  R=[F(1,2),F(1)]
  m=[sum(f[y]*dy[y]*c[v][y] for y in range(8)) for v in range(2)]
  q=[m[v]/R[v] for v in range(2)]
  assert all(F(3,4)<=x<=1 for x in q)
  for small_weight in (F(1,10),F(1,5),F(2,5)):
   for large_weight in (F(1,10),F(1,5),F(2,5)):
    du=[small_weight,large_weight]
    for h in (F(1,10),F(1,2)):
     X=sum(du[v]*q[v] for v in range(2))
     high=F(0);full=F(0)
     for y in range(8):
      J=[sum(du[w]*c[w][y]/m[w] for w in range(2) if R[w]<=r) for r in R]
      for v in range(2):
       L=F(0)
       for u in range(2):
        if m[v]>=m[u]/F(3,2):continue
        Z=sum(du[w]*c[w][y]/m[w] for w in range(2) if m[w]<m[u]/F(3,2))
        if Z<=h:continue
        # Physical clock: mass 1 on [1/2,1), mass 1 at the terminal radius 1.
        clock=sum(F(1)/J[k] for k,r in enumerate(R)
                  if r>=R[u] and J[k]>=F(1,10) and J[k]>0)
        L+=du[u]*(1-m[v]/m[u])*c[u][y]*clock
       val=du[v]*dy[y]*c[v][y]*max(f[y]-q[v],F(0))*L/m[v]
       full+=val
       if f[y]>2*q[v]:high+=val
     assert 0<=high<=full<=X
     positive+=int(high>0)
     count+=1
print('PASS',count,'exact source-clock cases;',positive,'positive high-source cases')
