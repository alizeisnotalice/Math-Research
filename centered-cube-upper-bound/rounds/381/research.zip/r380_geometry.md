# R380 — A dimension-free joint mass/radius receipt for global source components

## 1. Main unconditional weighted payment

Keep the complete R379 field, including full f, original q/m matching, actual Lebesgue receiver measures, original source-dependent J and strict past, the full physical clock, and the remaining pair gates
j>n/8, Σd_i>n/20, p_uv<exp(−n/20).
All costs below use this unchanged remaining kernel C_v(y,z)=L_v(y)−K_v(y,z)≥0.

Let f=Σ_j f_j almost everywhere be ANY fixed countable decomposition into nonnegative measurable components, with
\[
 M_j=\int f_j>0,\qquad a_j(y)=f_j(y)/f(y)\quad(f(y)>0).
\]
Ignore zero-mass components and set a_j=0 where f=0. Thus Σ_jM_j=W and Σ_ja_j=1 for f(y)dy-almost every y. A global countable measurable partition S_j is the special case f_j=f1_{S_j}. The decomposition is fixed across all receivers; it may depend on the frozen full f, but cannot be reselected separately for each v.

For θ>0 define
\[
 \chi_{jv}=\exp[-\theta|\log(m_v/M_j)|]
 =\min\{m_v/M_j,M_j/m_v\}^{\theta},\qquad
 \chi_v(y)=\sum_j a_j(y)\chi_{jv}. \tag{1}
\]
Then 0≤χ_v≤1. Let τ_v^H be any plan with the exact original high-source marginal
\[
 \mu_v^H(dy)=1_{\{f(y)>Tq_v\}}
 {(f(y)-q_v)_+c_v(y)\over m_v}\,dy.
\]
The same argument also holds for the entire surplus marginal. No assumption on the target is needed for this local receipt.

Write
\[
 B_*=\min\left\{{A_n\over h},
       \lambda\log_+{A_n\over q_-h}\right\},\qquad
 c_\theta=\begin{cases}2/\theta,&0<\theta\le1,\\
                       1+1/\theta,&\theta\ge1.\end{cases}
\]
The new general weighted estimate is
\[
 \boxed{\int_Edv\int\chi_v(y)C_v(y,z)\,\tau_v^H(dy,dz)
 \le {c_\theta B_*\over q_-}\,W.} \tag{2}
\]
In particular θ=1 costs exactly the certified upper price
\[
 \boxed{2B_*W/q_-.} \tag{3}
\]
The remaining actual cost is EXACTLY the same original integral weighted by 1−χ_v(y). It is not discarded or called small.

For fixed θ, the new W price is at most logarithmic in n on the frozen R379 field. Formula (2), with its explicit θ dependence, is the receipt; no asymptotic choice of θ or source partition is silently made.

## 2. Joint mass/radius center lemma

For every M>0, θ>0, and fixed source point y,
\[
 \boxed{\int_E {c_v(y)\over m_v}
  \min\{m_v/M,M/m_v\}^{\theta}\,dv
 \le {c_\theta\over q_-}.} \tag{4}
\]
This is a pointwise receiver-occupation inequality, for the actual arbitrary selector. It uses m_v=q_vR_v^n≥q_-R_v^n jointly with capture; it does not separately integrate over a free radius.

Proof. Put ρ=2||v−y||∞. If c_v(y)=1, then R_v≥ρ and hence
m_v≥q_-ρ^n. Write x=q_-ρ^n/M and t=m_v/M. The integrand is bounded by
\[
 {1\over M}g_\theta(x),\qquad
 g_\theta(x)=\sup_{t\ge x}
       {\min(t,t^{-1})^\theta\over t}. \tag{5}
\]
Direct monotonicity on t≤1 and t≥1 gives
\[
 g_\theta(x)=
 \begin{cases}
 x^{\theta-1},&0<x\le1,\ 0<\theta\le1,\\
 1,&0<x\le1,\ \theta\ge1,\\
 x^{-\theta-1},&x\ge1.
 \end{cases} \tag{6}
\]
At x=0 any singular envelope when θ<1 concerns only the single center v=y; the following integral is finite. Since |{v:2||v−y||∞≤ρ}|=ρ^n, the change x=q_-ρ^n/M yields exactly
\[
 \int_{\mathbb R^n}{g_\theta(q_-\rho^n/M)\over M}\,dv
 ={1\over q_-}\int_0^\infty g_\theta(x)\,dx
 ={c_\theta\over q_-}. \tag{7}
\]
Restricting to the actual E can only decrease it. This proves (4).

At θ=1 the entire argument can be seen without a supremum:
\[
 {1\over m_v}\min(m_v/M,M/m_v)
 =\min(1/M,M/m_v^2)
 \le\min(1/M,M/(q_-^2\rho^{2n})).
\]
The central part and tail each integrate to 1/q_-, giving (3)'s coefficient 2.

No source-density bound, constant-radius assumption, f-coordinate independence, or μ-to-dv replacement occurs in (4). Unlike a bound on plain center volume, the denominator 1/m_v remains present and is controlled by the joint weight.

## 3. Restoring full f, the original clock, and all source costs

R376 proves on these same fields
\[
 0\le C_v(y,z)\le L_v(y)\le
 b_h(y):=\min\left\{A_n/h,\lambda\log_+(J_b(y)/h)\right\}
 \le B_*. \tag{8}
\]
Its proof uses the original strict-left radius prefix forced by strict mass past and the full physical clock, including the terminal atom. Thus (8) is not a bound obtained by reconstructing receivers from f_j. All m,q,J,ω,H and gates continue to be those of full f.

Source exactness and positive Tonelli give
\[
\begin{aligned}
 &\int dv\int\chi_v(y)C_v(y,z)\,d\tau_v^H\\
 &\quad\le
 \sum_j\int f_j(y)b_h(y)
 \left[\int_E{c_v(y)\over m_v}\chi_{jv}\,dv\right]dy\\
 &\quad\le {c_\theta\over q_-}\int f(y)b_h(y)\,dy
 \le {c_\theta B_*\over q_-}W. \tag{9}
\end{aligned}
\]
The first inequality uses
1_{f>Tq_v}(f−q_v)_+ a_j≤f_j, not a density cap. It keeps the original source-dependent b_h until the final optional uniform bound. The middle expression is a sharper actual-source price.

Every component mass is counted once because Σ_jM_j=W. Countably many components require only nonnegative Tonelli. The same proof covers fractional partitions f_j, so overlap is legitimate only with these weights summing exactly to f. An arbitrary unweighted overlapping cover is NOT given the W price in (2).

The exact complementary identity, for the SAME plan, is
\[
 G_H(\tau)=G_{\chi}(\tau)+G_{1-\chi}(\tau),\qquad
 G_H(\tau)\le {c_\theta B_*\over q_-}W+G_{1-\chi}(\tau). \tag{10}
\]
No additional old capture or return credit is subtracted from (10).

## 4. Two-sided actual capture as a concrete consequence

For component j define the actual full-field overlap
\[
 I_{jv}=\int_{Q_v}f_j\le\min(M_j,m_v).
\]
Given fixed α,β∈(0,1], call (j,v) balanced when
\[
 I_{jv}\ge\alpha M_j,\qquad I_{jv}\ge\beta m_v. \tag{11}
\]
Then
\[
 \alpha M_j\le m_v\le M_j/\beta,\qquad
 R_v^n\in[\alpha M_j/\lambda,\ M_j/(\beta q_-)]. \tag{12}
\]
Intersect this radius window with [a,b]. An empty intersection contributes nothing; an equal-endpoint window is allowed. The actual-center envelope gives
\[
 \int_{v:\,(j,v)\ {\rm balanced}}{c_v(y)\over m_v}dv
 \le {1+\log(\lambda/(\alpha\beta q_-))\over q_-}. \tag{13}
\]
Indeed a positive window [l,u] has exact relaxed center integral
∫sup_{l≤R≤u}1_{ρ≤R}R^{-n}dv=1+nlog(u/l), and (12) bounds its logarithmic width. It is an envelope of the real selector, not an independent dR integral.

Consequently, the actual cost assigned to balanced components, with source weight a_j(y), has the explicit price
\[
 {B_*\over q_-}
 [1+\log(\lambda/(\alpha\beta q_-))]W. \tag{14}
\]
The complement consists of component labels for which at least one inequality in (11) fails. Taking αβ polynomially small in n gives a polylogarithmic W price, with the stated constants; no such coverage is assumed.

There is also a direct link to a genuine capture weight:
\[
 w_{jv}={I_{jv}\over M_j}{I_{jv}\over m_v}
 \le\min(M_j/m_v,m_v/M_j).
\]
Thus w_{jv}^\theta≤χ_{jv}, so (2) also pays that capture-weighted cost. The larger χ weight has the same certified price and is the preferred unconditional result. Equations (2) and (14) are alternative receipts, not two charges on the same traffic.

This differs from paying one previously fixed mass window: the masses M_j are determined by the global source decomposition, every y and v is accounted for, and the total source price is Σ_jM_j=W once. The weighted theorem does not require a receiver to satisfy a fixed two-sided capture threshold.

## 5. A same-cap full-plan option and its exact Hall remainder

The existing low-source identity part remains untouched. For the high source, put
\[
 \mu_v^{H,\rm paid}=\chi_v\,\mu_v^H,\qquad
 \mu_v^{H,\rm rem}=(1-\chi_v)\mu_v^H,
 \quad d_v^{\rm paid}+d_v^{\rm rem}=d_v^H.
\]
Send the paid part by its product with U_v; its total actual cost is bounded by (2), whose proof uses only its source marginal. Apply the already certified R378 layered construction to the normalized residual high source and the SAME original remaining pair kernel, with unchanged levels, t, h and approximation accuracy. When d_v^rem=0 omit this normalized law.

The target is bounded by
\[
 d_v^{\rm paid}U_v+t\,d_v^{\rm rem}U_v
 \le t\,d_v^H U_v\quad(t\ge1). \tag{15}
\]
Hence the full low-plus-high template charge remains (T+t)Γ_n. There is no new target-cap term and no need to rebuild the original field for this plan option.

Let δ^rem be precisely the R378 finite-dyadic-relation deficiency computed using this residual source law and the unchanged actual capture relation. Define its weighted layered bill
\[
 \mathcal D_{\rm rem}
 =\int_E d_v^{\rm rem}\sum_{\ell=0}^{t-2}
 (\tau_{\ell+1}-\tau_\ell)\,
 \delta^{\rm rem}_{v,\tau_\ell,\infty}\,dv. \tag{16}
\]
For t=1 the sum is zero. The two original ε,ε' receiver errors are unchanged because d_v^rem≤d_v^H≤1. Consequently this explicit alternative complete plan obeys
\[
 B_H\le\mathcal D_{\rm rem}
 +(\eta+\sigma_n+\varepsilon+\varepsilon')X_q
 +\left[C_{338}+{c_\theta B_*\over q_-}\right]W. \tag{17}
\]
All original entrance terms and the outer 2Λ/Λ factors are retained: the new W addition in the full entrance is exactly 2ΛcθB*/q_- times W. No negative credit from a different plan is added.

There is NO claim that δ^rem or its bill is automatically smaller than the old normalized Hall deficiency: removing source also changes its normalized target comparison. Equation (17) is a valid additional whole-plan option; one may choose the cheaper complete construction on the same fields. Alternatively (10) preserves the old plan and its exact residual cost without introducing a new Hall certificate.

## 6. Narrow remaining interface: global source alignment

The new theorem pays a nonzero, explicitly weighted part of the general original integral, with a strict source budget independent of dimension apart from the already proved B*. It does not pay the entire D_H,deep.

What remains is the actual 1−χ weighted source cost in (10), or the precisely reconstructed residual Hall bill (16). A useful alignment statement must select ONE global source decomposition and bound these actual residuals. The dyadic Hall source sets depend on v; they cannot simply be declared to be the global components f_j without accounting for all duplication.

For quantitative orientation only,
1−χ_jv≤min{1,θ|log(m_v/M_j)|}.
Thus small mismatch in the same global decomposition would help. No bound for that source-weighted mismatch is proved here, and it is not assigned a paid name or an independent credit.

Small geometric p_uv is still not a bound on I_uv/m_v. The present payment instead exploits source component masses, actual m_v=q_vR_v^n, and one integrated center envelope. The actual deep/outside/history marks were only relaxed positively when bounding C by its original-clock envelope; they remain unchanged in the complementary integral.

## 7. Reproducible three-stage exact checks

Executed locally on 2026-10-18:
python3 /tmp/r380_geometry_check.py

Output:
PASS {'source_windows': 1440, 'fractional_matching': 120, 'joint_envelope': 2094, 'radial_constants': 8, 'clock_bound': 1080} total 4742
EXACT radial coefficient theta=1: 2

Stage 1 verifies full-f fractional partitions, exact ΣMj=W, actual capture inequalities, and radius/mass-window implications. Stage 2 checks the joint mass envelope for integer θ and θ=1/2 on rational/perfect-square grids, together with the exact antiderivative constants for eight rational θ values. Stage 3 checks the original-shape finite physical-clock logarithmic bound with varying q, tied radii, strict mass past and source gates, using rational logarithm certificates.

The script uses Fraction throughout. An optional SymPy import was attempted but is unavailable in this Python environment; no CAS result is claimed or needed. The analytic proofs (5)–(9) establish the general statements. These finite algebraic tests are not claimed to realize native high-past Lebesgue fields. Only /tmp/r380_geometry.md and /tmp/r380_geometry_check.py are produced.
