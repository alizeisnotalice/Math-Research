# R563｜完整旧层后验的 Carleson 占用机制：条件核验

**结论：没有得到新的完整预算。** 本轮只核一个最贴近 \(V_a\) 的机制：在同一真实source概率空间上，对全部旧层占用建立条件 Carleson 尾。原始嵌入定理有显式、无维数常数；但当前合同尚无该条件，而且把终端函数取1时，其根条件已经是要证明的完整来源付款。不能用它绕过OLD capture或旧σ层费用。

使用的64工具：I04《随机 Carleson 占用与 LlogL》，已读当前 SKILL及来源卡。该技能只认证了有packing条件的有限laminar L²分支；没有从一阶质量推出随机LlogL端点。本轮不使用其连续CR鞅的常数e分支，因为当前后验没有相应连续正交驱动与表示条件。只读冻结合同和 `r562_crossmass_bridge.tex` 的实际全后验，不重读历史。

## 唯一核定的原始定理

Jingguo Lai, *The Bellman functions of the Carleson Embedding Theorem and the Doob’s martingale inequality*, [arXiv:1411.5408v3](https://arxiv.org/pdf/1411.5408v3)，2015-02-11。实际阅读PDF p.2 的filtered probability设置、Definition1.2与Theorem1.6/(1.3)–(1.4)，以及相邻sharpness条件。不是从搜索片段引用。

原条件为概率空间 \((X,\mathcal F,\mathbb P)\)、递增filtration \(\{\varnothing,X\}=\mathcal F_0\subset\mathcal F_1\subset\cdots\)，非负且 \(\mathcal F_\ell\)-可测的 \(\alpha_\ell\)，满足
\[
 \mathbb E\!\left[\sum_{k\ge\ell}\alpha_k\mid\mathcal F_\ell\right]\le C
 \quad\text{a.s. 对每个 }\ell.\tag{1}
\]
若 \(1<p<\infty\)、\(h\in L^p(\mathbb P)\)、\(h_\ell=\mathbb E[h\mid\mathcal F_\ell]\)，则
\[
 \mathbb E\sum_\ell\alpha_\ell|h_\ell|^p
 \le (p')^p C\,\mathbb E|h|^p.\tag{2}
\]
特别p=2常数为4，没有空间维数n、节点数或层数。infinitely refining只用于断言常数sharp，不是该上界的必要条件；不要求source坐标独立。**但(1)是每个条件尾的统一控制，绝非仅 \(\mathbb E\alpha_\ell\le C\) 或总质量有限。**

## 与合同的无损对接及准确缺项

必须首先保留共同 \(a_x>0\) 的信用约束
\(R_a(B)=\int a_xw_x(B)d\Xi(x)\le1\)。令完整旧后验占用为
\[
 \mathcal O_a(z,\sigma)=
 \int a_x^{-1}\frac{L_x(z,\sigma)}{L_i(z,\sigma)}\,d\Xi(x)
 =\mathbb E_{\Pi_i(\cdot\mid z,\sigma)}R_{1/a}(B),
\quad V_a=\sum_i\int\mathcal O_a\,d\mu\,d\sigma.\tag{3}
\]
这里的x、\(d\Xi\)、\(w_x\)沿冻结式，包含所有有序父、OLD与NEW capture、核心、首停、真实窗和 **两个M分母**。本稿没有把Xi改为每外父概率，也没有把source cores换成点。

将旧σ轴分为单位区间 \(I_\ell\)，置
\(\alpha_{i,\ell}(z)=\int_{I_\ell}\mathcal O_a(z,\sigma)d\sigma\)。在有限截断上这精确保留
\(V_a=\sum_i\int\sum_\ell\alpha_{i,\ell}\,d\mu\)。若要将(2)用于 \(\mathbb P_i=\mu|_{C_i}/\mu(C_i)\)，需要新增：

1. 一个对全部外父、节点和actions共同的source filtration，使这些真实占用量适应；不能给每条旧窗或每个x另建一个各收W的树。
2. 在同一个可测 \(a_x\) 同时满足 \(R_a\le1\) 时，证明(1)的常数 \(C\le\mathrm{polylog}(n)\)，含OLD与全部旧σ尾。真正的证明必须使用cube相交坐标与实际质量演化；posterior归一化不包含这一结论。
3. 若想利用非恒定h把(2)的终端能量直接对接 \(Q_g\)，须另给真实变量/filtration表示及其终端能量账本；目前没有这个表示，不能将原 \(L_i\) 分母替成任意条件均值。

特别要指出：对h=1，(1)在ℓ=0已经给 \(\mathbb E\sum\alpha_\ell\le C\)，即 \(V_a\le CW\)。所以此时“应用Carleson嵌入付V_a”没有产生新估计；真正工作全在(1)。用(2)写4CW只会放松已经假定的付款。

已知后验归一化只说明每个固定 \((z,\sigma)\) 的 \(\Pi_i\) 总质量为1。若仅有 \(R_{1/a}\le K\)，(3)仅推出 \(\mathcal O_a\le K\)，积分仍为 \(KD_{\rm clk}W\)。这是合同中的实层数，不能解释成Carleson常数K。抽象地，m层均取确定性 \(\alpha_\ell=K\) 时，每层都≤K，但(1)的最佳根常数就是mK；这只说明逻辑缺项，不是声称构造了本合同的几何反例。

## 本轮真实收益与停止

原定理若其缺失条件另获证明，确可保全任意相关source并统一所有层，随后经冻结桥得到 \(C_\star^2\le Q_g\,\mathrm{polylog}(n)W\)。**当前新增付款为0**：未构造合法共同a，未证条件尾packing，未压缩 \(D_{\rm clk}\)，也未证明非恒定终端h的完整交叉表示。故不建议另开泛泛的Lp／LlogL来源支线；下一步需要的是(3)实际占用在共同source filtration下的cube-specific条件尾估计。

检索有界：执行 `martingale Carleson embedding theorem general filtration sharp constant p measures theorem pdf` 与 `"Carleson embedding" "posterior" capacity`，随后只打开上述原始arXiv条件页。未下载PDF、未运行实验、未改他人文件或仓库。

## cluster迁移审核（续派；纯有限树独审，无新增检索）

**结论分开：固定cluster的数值级数成立；generator的有限forest势也成立；完整 \(C_\star\) 的实际forest嵌入仍未给出。** 不得用后两项的形式相似宣称全旧层付款。

### A. 固定H跨父质量的精确级数条件

固定真实同一集合H、\(h=\mu(H)>0\)。若 \(M_j\ge h\)，各质量带 \([\gamma^kh,\gamma^{k+1}h)\) 的**全部已合并费用**重数至多L，则
\[
 \sum_j\frac{h^2}{M_j}
 \le L\sum_{k\ge0}\frac{h^2}{\gamma^kh}
 =\frac{L\gamma}{\gamma-1}\,h.\tag{C1}
\]
连续质量积分的相应式为 \(\int_h^\infty(h^2/M)\,dM/M=h\)。但真实action/父积分不自动等于 \(dM/M\)：平坦质量区间、端点原子、同带的多个父、旧窗及两有序方向必须在L或明确系数中保留。\(\gamma/(\gamma-1)\) 不是与参数无关的绝对常数。

前置的 \((h^2/M^2)\times(M/q)=h^2/(qM)\) 还带着 \(1/q\)。只有在真实完整被积式中明确抵消q（或支付band ratio），才是(C1)的 \(h^2/M\) 费用；一个逐父center帽不能无计数地对所有父相加。

跨所有H时还需source packing，例如H族为一次付费的互斥集合，或有 \(\sum_H\mu(H)\le C\,W\)。一般重叠族不满足；**即使共同laminar树也不够**：概率根上的深D完整二叉树，每深d节点质量 \(h=2^{-d}\)，分母取直接父质量 \(M=2h\)。每层 \(\sum h^2/M=1/2\)，D层合计D/2。每个固定H只有一个M，完全满足其各自级数界，却不能得总O(W)。这是有限树数值反例，不是合同几何反例。

### B. generator实际提出的 \(\Phi=h^2/M\) forest：条件成立时账本通过

generator发来的准确假设为：单一全局有限source forest；各根cluster互斥。节点H质量h、标签 \(M\ge h\)；子节点
\(H_j=A_j\sqcup E_j\)，\(a_j=\mu(A_j)\)、\(e_j=\mu(E_j)\)、\(h_j=a_j+e_j\)，满足：

- 每父的旧部分 \(A_j\subset H\) 两两互斥，允许丢失旧来源；
- 所有新增集合E_j在**整个forest**上互斥，且不重复根来源或任何此前出现的旧来源；
- 每条子边 \(M_j\ge M\)，且 \(h_j\le M_j\)；
- 只有一次全局birth收费，不给每个原父或每棵局部source树重新发W。

于是逐节点恒等式准确：
\[
 \begin{aligned}
 \Phi(H,M)-\sum_j\Phi(H_j,M_j)
 &=\underbrace{\frac{h^2-\sum_ja_j^2}{M}}_{S_H\ge0}
 +\underbrace{\sum_ja_j^2(1/M-1/M_j)}_{D_H\ge0}\\
 &\quad-\underbrace{\sum_j(2a_je_j+e_j^2)/M_j}_{J_H\le2\sum_je_j}.
 \end{aligned}\tag{C2}
\]
S非负用的是旧部分**总质量** \(\sum a_j\le h\)，不只是逐个 \(a_j\le h\)。join界使用 \(a_j+e_j\le M_j\)。有限forest望远镜后，精确保留terminal项：
\[
 \sum_{H\text{ internal}}(S_H+D_H)+\sum_{H\text{ leaf}}\Phi(H,M)
 =\sum_{H\text{ root}}\Phi(H,M)+\sum_HJ_H
 \le \sum_{\rm roots}h+2\sum_je_j\le2W.\tag{C3}
\]
因此generator的 \(\sum release\le2W-\sum leaf\Phi\) 正确；叶势不是零，而是已经含在(C3)账内。根集合与所有birth合计质量≤W必须单独验证。

若某内部父的**每条有效子边**都满足 \(M_j\ge rM\)、r>1，则有真正的raw-phase receipt：
\[
 S_H+D_H\ge(1-1/r)\Phi(H,M).
 \tag{C4}
\]
证明为 \(D_H\ge(1-1/r)\sum_ja_j^2/M\) 加S_H；不能只从一个子边增长推出整个父的(C4)。若仅旧部分显著分裂，也可由S_H付款。反之，单子 \(A_1=H,E_1=\varnothing,M_1=M\) 的release严格为0，重复此flat phase任意次都不产生可付的raw \(\Phi\)；其正费用仍须独立receipt。

### C. 对完整cube合同尚缺的决定性一步

必须把真实 \(d\Xi\) 的所有有序父对、OLD/NEW capture、不同旧σ层、首停和source cores，同时送进**同一**满足B节假设的forest，并将全部正费支配于(C3)/(C4)或另有已付flat receipt。当前尚未构造此映射。尤其：

1. 每个父各自的source tree可把同一H复制成多个兄弟；此时 \(\sum a_j\le h\) 失败，split项会变负，不能引用(C3)。
2. 非嵌套重叠的H不能只按它们的数值质量排序成树；必须给真实旧来源A_j的互斥分配，且保留原费而不删交叉。
3. “首次进入”须在这个全局forest上一次，而非对每个外父、每个旧窗各有第一次。
4. M标签的单调／增长条件须由真实 mass evolution证明；对几何动作半径单调不能替代跨不同父的M单调。

故独审确认的是(C1)的正确假设及(C2)–(C4)的条件性有限tree付款；不确认实际完整 \(C_\star\) 已嵌入。下一份必要输入应是core/cover给出的这个无复制全局映射和flat费用清单，而非再证一次单cluster几何级数。

### D. generator后续的merge invoice：也成立，但付款回到真实旧交质量

若互斥cluster \(H_i\) 的质量为h_i，合并真实质量 \(h=\sum h_i\le M\)，旧denominator \(M_i>0\)，则Cauchy给
\[
 \left(\frac{h^2}{M}-\sum_i\frac{h_i^2}{M_i}\right)_+
 \le\frac{h^2(\sum_iM_i-M)_+}{M\sum_iM_i}.
 \tag{C5}
\]
设M_i是旧cube Q_i的真实质量，新enclosing cube Q真包含所有Q_i，\(M=\mu(Q)\)。置 \(N_{\rm old}=\sum_i1_{Q_i}\)。在(C5)正项域，\(\sum M_i>M\)、\(h\le M\)，故系数 \(h^2/(M\sum M_i)\le1\)，从而
\[
 \text{merge jump}\le(\sum_iM_i-M)_+
 \le\int(N_{\rm old}-1)_+d\mu.
 \tag{C6}
\]
两个旧cube时右端为 \(\mu(Q_1\cap Q_2)\)。本式没有把重叠来源伪装成新arrival，是合法的merge局部invoice。仍须付全局merge次数及原 \(t/R^n\)、真实质量窗与ordered-pair权；重复merge可反复收同一旧交质量，不能各次套(C6)后宣布总O(W)。若H_i本身非互斥，\(h=\sum h_i\)不再是真实并集质量，必须先证明无损分配，不能直接使用本式。此项不改变C节的完整嵌入缺口。
