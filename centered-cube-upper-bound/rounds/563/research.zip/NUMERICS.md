# R563 N3: frozen OLD/NEW complete finite-field decomposition

This is one frozen n16 diagonal-source cube input from R562, with 332 empirical bulk parents, all 64 sources, 1264 action states, all q bands, and the same recovered rho laws. No optimizer was invoked. The original training alpha, parents, weights, actions and solutions were unchanged.

OLD is the subset of each original serialized CSC column whose receiver was already in that parent's g=1 body. NEW is its complement in that same column. The data values, actual mass windows and actual phase indices are unchanged. Thus F=O+N entrywise, and E=||O rho||²+2<O rho,N rho>+||N rho||². The primary is all-band complete with true phase direct sum. No q band is made orthogonal here.

| Law | OLD | 2 OLD·NEW | NEW | Complete E |
|---|---:|---:|---:|---:|
| adaptive | 1.53376366045 | 0.0144718438105 | 0.0103580643635 | 1.55859356862 |
| common | 1.32125018636 | 0.0413569222864 | 0.0302701728318 | 1.39287728148 |
| two | 1.60576098486 | 0.0103503286993 | 0.00756754320796 | 1.62367885676 |
| delta1 | 2.14069111815 | 0 | 0 | 2.14069111815 |
| deltaG | 1.24270849484 | 0.0685939368675 | 0.0589711278369 | 1.37027355955 |
| optimum | 1.23890555202 | 0.0256038870216 | 0.0414829987093 | 1.30599243775 |
| banddiag_optimum | 1.33156470408 | 0.0298539767759 | 0.020619393723 | 1.38203807457 |

The all-band optimum's gain against adaptive is 0.2526011308773. Its OLD energy decreases by 0.2948581084342, while NEW plus mixed energy increases by 0.0422569775569. OLD's cross-old-mass-layer contribution falls from 0.3081304194461 to 0.1430822113763. These are actual-window, actual-phase finite-field statements; old mass layer means the original integer count c0, rather than the q band.

This reduction is highly phase dependent. Erasing phase orthogonality without moving windows gives adaptive 2.25770951824749 versus optimum 2.41574244936101: the optimum is worse under this diagnostic. The complete phase-cross fee is 0.699115949623475 for adaptive and 1.109750011614292 for optimum. The JSON retains the entire phase-pair OLD/NEW Gram, not only these totals.

A separate diagnostic explicitly shifts each action window by -j/8 and then erases phase. It retains residual delta=log2(c/c0)-j/8 in [0,1/8), so OLD is not silently replaced by the frozen old window. Its OLD energies are adaptive 2.12936597497246 and optimum 2.12193899085680, a reduction of about 0.35%, against frozen old-window energy 2.14069111815457. Its complete energies are 2.30585292243071 and 2.46710544154554, respectively. Therefore this experiment supplies no evidence for a large phase-independent reduction of old-layer load. It does not uniquely separate all geometric effects, and it does not prove that phase redistribution is the only possible mechanism.

The JSON contains complete by-qband and by-old-mass-layer OLD/NEW Gram matrices, including both orientations of the mixed term, and the full phase-pair Gram after erasure. The fixed descriptive low/high split is qband k<0 versus k>=0 (q<1 versus q>=1); all 17 observed bands remain. For adaptive the low/high total Gram is [[0.0858882388660,0.210538301337],[0.210538301337,1.05162872708]], and for optimum [[0.0700466280183,0.162767933208],[0.162767933208,0.910409943313]]. Crossband fees are adaptive 1.20921526693770 and optimum 0.951600325472371; these are included in every complete E above.

The literal old-window baseline is delta1 on the same bulk joint parent family (energy 2.14069111815457), not the full original training Qg. Original alpha still comes from the frozen full training field. This finite quadrature/estimated-alpha decomposition cannot certify a Lebesgue or general-dimension result, the complete Cstar posterior transfer, or the multiband mother account.

## Reproduction and certificate interface

Run `/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/ccu_r563_n3.py --optimizer /tmp/ccu_r562_optimizer.json --output /tmp/ccu_r563_n3.json`. No new solve, sampling, dependency install, or R562 writes occur. Input SHA256 is stored in input_optimizer, code SHA256 in code_sha256. Python/NumPy/SciPy versions are serialized.

`matrix_csc` is the exact copied R562 all-band CSC payload. `row_keys` schema is [receiver_atom, phase_j, sigma_segment]. `is_old_data` is a Boolean parallel to CSC data; multiplying the original dyadic float by it or its complement is the entire partition. `column_parent`, `column_parent_band`, `column_old_count`, `offsets`, and all `rhos` are included. The original source masks/action states are recoverable from the SHA-identified optimizer JSON. This permits independent exact Fraction checks of the finite rounded feature matrix; it does not certify ideal logarithms/square roots or the geometry integral.

One initial decomposition pass took 0.23573 s. The final pass adds the complete phase-pair report and took 0.27579 s (peak RSS 140673024 bytes, about 134.2 MiB). There were zero optimization runs. The unshifted independent event sweep agrees with phase-erased CSC energy to less than 1e-11; grouped qband totals agree with primary totals to the same tolerance. Final computation is bounded to this single frozen input; no parameter scan.


## N3.2 follow-up: actual mass-discounted necessary mean platform

This adds a scalar discounted-source projection on exactly the same input and rho, without a new solve or sample. Take one fixed source cell C containing all 64 atoms, W_C=1, and keep all qbands in the same physical field. For every actual action j=floor(log2(kappa)/h), h=1/8, form F(sigma)=sum_j 2^(-jh) integral_C Z_j(y,sigma+jh)dmu(y). Its event amplitude is the actual captured mass count/64 times rho*parentweight/R^16 times 2^(-jh). Equivalently it is rho*parentweight*q0*2^delta with left endpoint s_B+delta, delta=log2(kappa)-jh. The interval has length one. No old-mass substitution is used.

The fixed old mean A=sum_B parentweight*q0*1_[s_B,s_B+1] has norm² 0.756594493864805; its inner-window A_h=sum_B parentweight*q0*1_[s_B+h,s_B+1] has norm² 0.604900756362806. Every law satisfies F>=A_h numerically up to event-sweep roundoff (minimum >=-1.11e-16). The entire platform/residual Gram is retained, including 2<A_h,F-A_h> and ||F-A_h||², so all parent/band cross terms remain.

| Law | ||F||² | 2<Ah,R> | ||R||² | Projection energy ||F||²/Sh | Orthogonal remainder E-projection |
|---|---:|---:|---:|---:|---:|
| adaptive | 0.763899143921 | 0.119207436565 | 0.0397909509925 | 0.153890607157 | 1.40470296147 |
| common | 0.770751194147 | 0.12715624942 | 0.0386941883645 | 0.155270980703 | 1.23760630077 |
| two | 0.762840704777 | 0.117775800869 | 0.0401641475455 | 0.153677380263 | 1.4700014765 |
| delta1 | 0.756594493865 | 0.108395352318 | 0.0432983851836 | 0.152419055525 | 1.98827206263 |
| deltaG | 0.778677516321 | 0.135147321352 | 0.0386294386058 | 0.156867770726 | 1.21340578882 |
| optimum | 0.772833092362 | 0.129217720779 | 0.0387146152209 | 0.155690387614 | 1.15030205013 |
| banddiag_optimum | 0.768240922395 | 0.124313634837 | 0.0390265311951 | 0.15476527619 | 1.22727279838 |

The common actual action family has j=0,...,8, hence the full-support J=9 and Sh=sum_j 2^(-2jh)=4.963910130912434. The common inner-window lower bound is ||Ah||²/Sh=0.121859731624839, and the coarse quarter-old bound is 0.0381047638812577. JSON separately gives the contract ambient J=29 version; it is a weaker valid embedding, not a replacement for the full-support number.

This is a new useful distinction: from adaptive to the all-band optimum, total energy falls by 0.252601130877298, while the necessary mean projection rises from 0.153890607157340 to 0.155690387613878. The orthogonal remainder falls from 1.40470296146667 to 1.15030205013284. Thus this phase optimization has not removed the mass-growth platform: its finite projected mean is slightly more expensive. The unchanged positive platform is far too weak here to close the full upper/mother budget. No source-specific action, independent band square, or source-mass loss was introduced.

The source-OLD-only discounted integral is separately included (field index 3). Its whole-sigma integral is adaptive 1.40015699568876 and optimum 1.33630537020556, whereas true captured-mass discounted integrals are 1.48336023313796 and 1.49593476815110. This distinction is exactly why the platform calculation must use real mass growth. Residual delta across the common complete action set is [0,0.115477217419936], within [0,h); phase endpoint actions remain explicit.

The new discounted_mean_platform fields are floating event-sweep evidence, outside the prior N4 Fraction/feature-audit scope. The prior matrix, masks, rho and result fields remain unchanged; their old audited hashes are recorded under pre_discount_audit_scope. A tiny negative squared difference for delta1 (about -2.2e-16) is subtraction roundoff and is retained as such, not silently clipped. This follow-up uses one fixed source cell to give a valid necessary mean projection of the actual finite field; it does not identify the full general source-cell geometry or prove the Cstar estimate.

Final N3.2 runtime: 0.262115 s, peak RSS 140656640 bytes; zero solver calls. Intermediate local reporting passes reused the same input, with no new numerical design or scan.


---

# R563 N4：OLD/NEW 与跨 band 完整分解的独立精确证书

## 1. 决定性结果与范围

独立证书通过。对 N3 冻结的7个 action law，32673个稀疏特征项的 OLD/NEW mask、原动作接收源、真实 phase 标签均核对通过；以序列化 double 的准确 dyadic Fraction 重算，`E=OO+2ON+NN` 以及全部跨 band / 跨旧质量组分解准确成立，无浮点 residual 付款。

在冻结 all-band optimum law 下：

- OLD：`1.2389055520158119`；
- 两倍 OLD–NEW：`.025603887021572902`；
- NEW：`.041482998709331954`；
- 全能量：`1.3059924377467167`。

OLD 占总能量约94.8631%；单是跨 qband 的 OLD–OLD 项占总能量约69.8344%。所以此有限实例的主要未付对象仍是完整旧来源场及其跨层交叉，不能用 NEW 小便声称完整预算小。

这些值只描述固定序列化矩阵和冻结 law；不是连续 Lebesgue 中心积分证书、理想几何 roundoff 证书或母不等式的吸收结果。本角色没有求解 QP，也没有新增参数或来源实验。

## 2. 冻结输入与独立检查

输入 `/tmp/ccu_r563_n3.json` 的 `matrix_csc`、`row_keys`、`column_parent`、`column_parent_band`、`column_old_count`、`is_old_data`、`offsets`、`rhos`，并对照 `/tmp/ccu_r562_optimizer.json` 的原 action states 和 parents。

矩阵为3411×1264，nnz=32673，332个父、64个原冻结来源原子；row key 是 `(receiver_atom,phase_j,sigma_segment_index)`。N4 检查：

1. N3 CSC 与原 R562 序列化 all-band CSC 逐值相同；row key 和 offsets 也逐项相同。
2. CSC pointer 长度/单调性及 row index 范围合法，全部矩阵值非负。
3. 每个 parent 的初始 action receiver set 从原 states 独立重建；其源数准确等于 old_count。
4. 每个动作来源集合包含同父初始来源集合；来源数与 action count 相同。
5. 对每个实际非零 CSC entry，receiver 在该动作捕获集合中，且 `is_old_data` 准确等于 receiver 是否属于初始集合；其余为 NEW。
6. 每个动作以准确有理比较 `2^j≤(count/old_count)^8<2^(j+1)` 重核 phase，并检查 entry row 的 phase 标签相同。
7. 父编号、qband 与旧来源计数逐列对照原 metadata，没有丢掉低 qband 或跨 band 来源。

N4 不重新判定几何边界或重算σ窗口端点；`distribution` 角色独立从64源云、父 B/R 审计这些几何输入。其报告 OLD flag 全32673项重算零错误，并指出 literal OLD 必须使用**同动作的真实 ell(g)、j(g)**。本精确证书核的是该既定网格上的算术。它没有把 OLD 窗擅自改回原 s_B；也没有认证后来新增的 `−jh` 平移或 phase-erased 矩阵。

## 3. 准确非负分解

令 F 为序列化 matrix，O、N 按同一 CSC data 的 source mask partition：每个项完整进入 O 或 N，所以矩阵恒等式 `F=O+N` 逐项准确成立，没有再次计算 sqrt(window length) 引入不同舍入。

对某个冻结 law ρ，定义 `o=Oρ`、`n=Nρ`。原 receiver 使用同一列ρ_j，不存在按 receiver 重新选择 action。准确恒等式为

`||Fρ||²=||o||²+2<o,n>+||n||²`。

所有量非负，另以 Fraction 核 `(<o,n>)²≤||o||²||n||²`。对每个 qband b 保留 `o_b,n_b`，有

`OO_same=Σ_b||o_b||²`，`OO_cross=Σ_(b≠c)<o_b,o_c>`；

`ON_same=Σ_b<o_b,n_b>`，`ON_cross=Σ_(b≠c)<o_b,n_c>`；

`NN_same=Σ_b||n_b||²`，`NN_cross=Σ_(b≠c)<n_b,n_c>`。

其中 cross 是**全部有序** band pair，非单边三角形；完整能量准确等于

`OO_same+OO_cross+2ON_same+2ON_cross+NN_same+NN_cross`。

实现先在所有 band 的真实 row 上累加，再以全量减 same-band 得 cross，逐项断言非负及准确重构。因此没有把 cross-band 丢掉。旧质量组按照实际 old_count 分组，采用同一恒等式；它只是组标签，不重新分配 source 或 credit。

## 4. 七个 law 的准确总账

表中小数是完整有理值的显示，准确分数都在 JSON。它们不单独作为向外舍入端点。

| law | OLD | 2 OLD–NEW | NEW | total |
|---|---:|---:|---:|---:|
| adaptive | 1.5337636604500466 | .01447184381048676 | .010358064363481688 | 1.558593568624015 |
| common | 1.3212501863570791 | .041356922286381784 | .03027017283183981 | 1.3928772814753008 |
| two | 1.605760984855048 | .010350328699310588 | .007567543207959953 | 1.6236788567623186 |
| delta1 | 2.1406911181545665 | 0 | 0 | 2.1406911181545665 |
| deltaG | 1.2427084948423621 | .06859393686749223 | .05897112783687976 | 1.3702735595467341 |
| optimum | 1.2389055520158119 | .025603887021572902 | .041482998709331954 | 1.3059924377467167 |
| banddiag_optimum | 1.3315647040758118 | .02985397677588653 | .020619393723030486 | 1.382038074574729 |

`delta1` 的 NEW 和 ON 准确为0，是初始来源分区的独立压力核。相比 adaptive，optimum 的 OLD 减少而 NEW 与 ON 的总账增加；不能只报告 NEW 的收益。optimum 的 source OLD 捕获集合本身固定，action 改变的真实窗/phase 分配也会改变 OLD 场，因此 OLD 减少不自动说明已获得新的全局几何 payer。

optimum 的完整 band 六项账为：

| 项 | same qband | 全部 ordered cross qband |
|---|---:|---:|
| OLD–OLD | .32687298796433306 | .9120325640514788 |
| 2 OLD–NEW | .0029344553732244074 | .022669431648348497 |
| NEW–NEW | .024584668936788057 | .016898329772543894 |
| total | .3543921122743455 | .9516003254723713 |

跨旧质量计数组的总项仍为 `.15077295412972025`，其中 OLD–OLD 为 `.14308221137629437`。两种分组的 cross 数字描述不同切分，不能相加当成额外费用，也不能分别使用两份旧信用。

## 5. selected 全 pair 矩阵与浮点差

对 optimum 另独立计算全部17×17 qband 及11×11 old_count 的以下 ordered Gram 矩阵：OLD、NEW、OLD_NEW、total。OLD_NEW 的 `(b,c)` 项严格是 `<o_b,n_c>`；total 使用 `OO+NN+ON+ONᵀ`，没有以2ON代替非对称单项。OO、NN、total 的对称性准确核过；所有精确矩阵保存在 JSON。

与 N3 的 float 全 pair 矩阵逐项比较，最大绝对误差为：

- qband：`3.359437250779744e−17`；
- old_count：`1.296430401039685e−16`。

七个 law 的 total/OO/2ON/NN 浮点摘要误差最大约 `3.28e−16`。这类误差远小于此有限例的 OLD 和跨 band 费用。N3 的分解输出在其浮点精度下与准确矩阵一致，没有发现遗漏 cross 项或错把 NEW 当完整场。

本次保持原冻结 double ρ 来精确复现 N3，而未作 simplex 修补。Fraction 读入后有些 block 和偏离1极微小：adaptive 最大约 `1.77e−16`、optimum 最大约 `2.22e−16`，common 为0。上述分解对任意非负ρ都准确，故不需要把这些 residual 当付款；但不能据此称所有原 float law 已准确归一。R562 的严格有限QP证书另以准确修补候选认证最优值，本次没有重复其优化或 primal–dual任务。

## 6. 实跑、hash与停止点

实际命令：

```
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/ccu_r563_n4.py --n3 /tmp/ccu_r563_n3.json --optimizer /tmp/ccu_r562_optimizer.json > /tmp/ccu_r563_n4.json
```

Python3.12.14、标准库 Fraction；单进程约2.06秒，无求积器、无solver、无新QP。脚本支持 `--n3`，默认读取脚本相邻 `n3.json`；`--optimizer` 未指定时读取 N3 的输入路径。

稳定脚本 SHA256：`72076b2afb5e331dd79378cb94857606fd01e4315218951eed02e3e094f5957e`。

本次 N3 JSON SHA256：`a851d443dac6cbc017cc54c3023bc30dd1a799c70aaf68857f7c98e03324892d`。矩阵 canonical hash 和原 optimizer 文件 hash 亦在 JSON。N3 此后若添加独立研究字段，不属于本证书已审的新增数学结论；已冻 matrix/rhos 可用其独立 hash 对照。

精确证书的对象是序列化 rounded feature matrix/action masks。原有限原子云、proposal/训练估计、几何浮点与真实 L1 source core 的误差均未由此支付。完整 OLD 跨层付款仍未闭合，不能把正确的分解恒等式称作一般根阶证明。仅写本角色三个文件，完成停止。

## 7. N3.2 追加字段的 scope 快检（未重算 Gram）

N3 后续仅新增 `discounted_mean_platform` 决策诊断。此次按主代理要求只作输入一致性检查，不重跑 Fraction Gram、不求解。旧 N4 审计的 N3 JSON hash 为

`a851d443dac6cbc017cc54c3023bc30dd1a799c70aaf68857f7c98e03324892d`，

N3.2 最终 JSON hash 为

`0771d0149dd79c39fc38c111db9652f7febec1d0bdd298e7edc8d56d3aa6e3f5`。

旧 N3 code hash 为 `b665c86ff4502c168c370424315840b8496e20923db86c52789763416e977b8a`，新 code hash 为 `41c262b0e155de9d29aa05eb1c8802ec09a792f4393d373a278e29d0455fb73d`。

实际快检通过：

- 新 `matrix_csc` 的 canonical hash 与旧 N4 保存值准确相同；新矩阵、row key 与原 optimizer 值逐项相同。
- 原 optimizer **整个文件** SHA 与旧 N4 输入 SHA 准确相同。
- 7个 rho 的每个值，分别与这份未变 optimizer 的两组候选、以及原 metadata 上的固定 baseline 公式重建值准确相同；未用容差。
- 原 initial source sets 重建的32673个 flag、column parent/band/old_count、offsets 与新 N3 逐项一致。

N4 未保存旧 N3 完整字节副本，因此这里不声称已直接逐字节比较整个旧/新 N3 JSON。准确矩阵比较依据旧保存的 canonical hash；rho/flag/metadata 比较依据 byte-identical 原 optimizer 及原固定公式。该限制也明确保存在 JSON，而不是以新作者的“未变”文字代替审计。

当前冻结 certificate 输入子集（matrix、row keys、parent标签、flag、offsets、7rho）的 canonical SHA256 为

`0e9df2c1765d39d450129438732eb5637ccb8d30550c9b2eac937ce85a813608`，

7rho 的 canonical SHA256 为

`6732792c7fff4106b55ccbaab1ff917a197bf229fa730e3292b39ad64700b961`。

新增 `discounted_mean_platform` 是**浮点决策诊断**，未作 Arb/对数误差认证，也不在本旧 N4 精确 partition/rho/Gram 证书范围内。本文关于旧预算的严格范围没有扩大；该新字段的数值结论不得引用本证书作严格担保。

### 归档便携接口

当前 N4 脚本已支持两个显式相对路径，`--n3` 默认定位脚本相邻 `n3.json`。若归档命名为 `n4.py`、`n3.json`、`optimizer.json`，在归档目录执行以下命令即可，不需要修改数学代码：

```
python n4.py --n3 n3.json --optimizer optimizer.json > n4.json
```

不能省略 `--optimizer` 后仍依赖 N3 内嵌的旧 `/tmp` 绝对路径。若主代理希望无参数运行，只需把该参数默认值改成 `Path(__file__).resolve().parent / 'optimizer.json'`，并令 `op=args.optimizer`；该接口变动不改变数学步骤，但应重新记录修改后的脚本 hash。此处保持 N4 原代码及其 hash 不变，没有擅改打包方文件。快检补充保存在 `N3_2_append_only_scope_check`，主精确分数与矩阵结果均保持不变。完成停止。


## Parent final reproduction

Parent extracted the byte-verified optimizer.json from the committed R562 research.zip, copied the final N3/N4 scripts unchanged into a clean reproduction directory, and ran both with explicit relative input paths. All N3 numeric payloads (matrix, masks, rho, grouped Grams, shifted and discounted results) matched the authors' final outputs bitwise. N4 exact results and full ordered pair rational matrices matched. Wall-time and path/hash metadata naturally differ. No optimizer was invoked. The archived rational_certificate.json is this actual final parent run. The author's N3.2 append-only scope check remains documentary; the new discounted field is floating evidence, not covered by rational Gram certification.

Reproduction may produce a 2.5 MB n3.json containing a duplicate of the prior input matrix. It is deliberately not archived: numerics_summary.json retains the full result section, and the original matrix is already in the committed R562 dependency. Reproduce from that input using REPRODUCE.md. No PDF was compiled.
