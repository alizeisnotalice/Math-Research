# R563 reproduction (no optimization, no PDF)

Interpreter actually used: `/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python` (Python 3.12.14). N3 uses NumPy 2.5.4 and SciPy 1.18.1; N4 uses standard-library Fraction. No MATLAB or extra solver was needed for these bounded algebra/Gram decisions. No new package installation was performed.

Dependency: the already committed `centered-cube-upper-bound/rounds/562/research.zip`, commit `5437711af449b8a8132a866334fd323562fbe9d6`.
Archive SHA256: `9633cc4d7c793b15b63eea3fa89dea300ddbab6c4568aa9923b6f838dd0e6e09`.
Extract its `optimizer.json` into the working reproduction directory; this is the sole data input.
Optimizer SHA256: `edf8f993d1511e1735621e8855311af8243f0f06231da52789c07cc06a47bbe4`.
Copy this archive's `n3.py` and `n4.py` into the same directory, then run:

```sh
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python n3.py --optimizer optimizer.json --output n3.json
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python n4.py --n3 n3.json --optimizer optimizer.json > n4.json
```

The explicit input flags avoid all recorded historical absolute paths. n3.json is regenerated and deliberately not stored twice in Git. Compare its `results` to numerics_summary.json `results`; compare n4.json `results`, `full_pair_selected_exact`, `input_checks`, `matrix_canonical_sha256` to rational_certificate.json. Runtime and whole-file hash metadata vary with file locations and execution time; the finite arithmetic results do not. The matrix/action geometry is the frozen finite quadrature and empirical-alpha model, not general Lebesgue input.

Evidence levels: N4 certifies exact dyadic arithmetic on the serialized Gram, all ordered band/layer cross terms, and rational action-phase count tests. It does not certify ideal logarithms, square-root rounding against a continuous object, shifted-window diagnostics or N3.2 discounted projection. Those are floating diagnostics independently checked by a second implementation. General analytic statements are proved/audited separately in REPORT.tex and AUDIT.md. No finite test is extrapolated in dimension.
