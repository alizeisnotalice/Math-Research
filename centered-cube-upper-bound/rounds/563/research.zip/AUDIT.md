# R563 integrated audit and complete fee account

General root-order theorem remains open. Original role files are incorporated below with hashes; author conclusions are not independent audits. The report includes corrected full INNER row cap.


---

## audit.md

Source SHA256: `5458eefdda2265df6606d1c8d145394a63f38e53519bc9eb1deded67774cd705`

# R563 独立审计：完整 old/new 的最弱合法信用合同

责任：Astra task 6。只写本文件，不改别人/repo，无子代理、无 PDF。保留上轮上下文，仅先读 R563 新冻结合同；以下独立筛查在阅读 core 新证明之前写成。不是新几何结论。

## 1. 必须审的完整命题与量词

固定原 μ=f dx、Lebesgue 父中心、旧 L_i/α、全部实际 phase/质量窗、原 adaptive I 和行动律。完整 Cstar 包含 old 和 new 接收、全部有序父对与旧质量层、first-stop 实际来源。期望得到

Cstar²≤Qg L(n)W， L(n) 为固定多对数，

或保留所有既有费用的等强可吸收估计。分析收费可依赖接收标记 x；它不改变行动。真正的父动作概率必须仍在接收前共同选择，不能把按最终来源优化出的收费误用成行动选择。

old/new 的区分是同一实际接收事件的正分割。任何局部新壳容量、new 信用付款或单个旧窗长界，不等于上述完整命题。全来源费用必须保留旧 σ 和 1/L_i；逐点后验守恒仅给 Dclk，不会自动缩成一份 W。

## 2. 最弱合法的一份信用，比逐父 Ra≤1 更弱

沿合同已核的 A_x、E_x、D_x，完整量满足 A_x²≤E_xD_x。对同一共同收费 a_x>0，定义

C(a)=∫a_xE_xdΞ=∫R_a(B)dQfr(B)，
V(a)=∫a_x^{−1}D_xdΞ。

真正足够的单份信用条件是 **C(a)≤Qg**。逐父 R_a(B)≤1 是便捷充分条件，不是这个 Cauchy 转移的必要条件。若作者愿意付某些父上 R_a>1，只要完整冻结 score 积分不超 Qg，仍合法；不能在未积分前凭空称“超载抵消”，须明确证明该总约束。

此时 Cstar²≤C(a)V(a)≤QgV(a)。允许使用更小的真实信用 C≤Qg，但相应来源费与信用必须是同一个权 a 下的量。不得拿另一个几何输入或改变后的 α 当 payer。

## 3. 仅 x 层收费的精确最优判据

在继承有限截断上，令

S=∫sqrt(E_xD_x)dΞ。

Cauchy 与显式取权给

inf_{a_x>0} C(a)V(a)=S²。

当 0<S<∞ 时，取

a_x=(Qg/S)sqrt(D_x/E_x)

即有 C(a)=Qg、V(a)=S²/Qg。E_x=D_x=0 的零贡献标记任取 a=1；L_x≤L_i 保证 E_x=0 时实际 L_x=0，不产生隐藏的正贡献。一般非有限情形只能经原允许截断/单调或适当闭包处理，不免费断言最优权可用于所有无限积分。

因此若允许全局信用、且不额外限制 a，只靠 x 层共同收费的最弱完整桥精确是

S²≤Qg L(n)W。                                      (A)

原 Cstar≤S；若 (A) 失败，只说明此无局部亏损的 Cauchy 收费桥不足，不自动否定 Cstar 目标，因为 A_x²≤E_xD_x 的实际亏损可能有用。反过来，优化 a 本身不会支付 (A)，也不会消除 old σ 的真实累计。

这个判据是审计边界：区分“选择了更好的合法收费”与“证明了新的来源容量”。它不是固定多对数来源费的证明。

## 4. 完整 old/new 怎样共用一份信用

可将共同测度按实际接收是否在 Q_B(1) 拆成 old/new 两支，分别定义 E_x^−,D_x^− 与 E_x^+,D_x^+，并允许分析权 a_x^−,a_x^+。

准确总账是

Cjoint=∫a^-E^-dΞ+∫a^+E^+dΞ，
Vjoint=∫(a^-)^{-1}D^-dΞ+∫(a^+)^{-1}D^+dΞ，
Cstar²≤Cjoint Vjoint。

因此需要 Cjoint≤Qg 与 Vjoint≤L(n)W；或给出等强乘积估计。逐父充分条件是 R_a^−+R_a^+≤1，而不是两支各自≤1后不记常数。

若两支确实各付了一份 Qg，可把两支权一起缩小 1/2，修为一份总信用；代价是 Vjoint 加倍。这个常数修复本身合法，不能把未付的 old 来源费用也当作同时修好了。完整来源中 old/new 交叉的平方由最后一次总 Cauchy 保留，不能只加两支平方而漏掉交叉。

原母账的吸收系数必须按总支出计算。由完整 Cstar²≤Qg LW 得 2Cstar≤ζQg+(L/ζ)W；选 ζ<d²/J 才能吸收。若只有 new 版本，则 2old 仍须明确保留并共同扣除余下信用。

## 5. 来稿审查清单与停止点

下一步只核 core 的决定性完整式，要求同时回答：

- 是否仍是原 fixed adaptive 的完整 Cstar，而非切换到 mass-boundary 场或只含 new 的子测度；
- 共享行动与分析收费是否清楚分开；
- 当前权是满足点态行限制，还是只证明总冻结信用；后者也是合法选择，但须实证总量；
- 旧 σ、实际 Li 分母、两份 M_C、节点先合并与所有旧层是否保留；
- cube 坐标交集与实际质量演化在哪一步支付了完整来源费，而非只生成一个几何恒等式；
- 归还原母账后的 ζJ/d²、W 费用及剩余外层费用是否齐全。

已经向 core 索要其决定性公式。未读新作者证明前不作通过判断，不进行反例扫描。

### 独立段实际工具核对

指定本机解释器 Python 3.12.14、SymPy 1.14.0。用三个正符号族 E_j=e_j²、D_j=d_j²，S=Σe_jd_j，a_j=(Qg/S)d_j/e_j。实跑 `cancel(Σa_jE_j−Qg)` 和 `cancel(ΣD_j/a_j−S²/Qg)` 均返回精确 0；联合权减半、倒数费加倍后的乘积差也为 0。该核对仅查收费代数，不是实际 cube 几何证据。无参数扫描、无新优化。

## 6. 明确新输入的独立检查：full-coordinate 两来源可测半径容量

本段在阅读作者新证明之前，按主代理给出的精确核独立推导。固定真实两来源 z（旧）与 y（接收）、g≥1、s=g^{1/n}，并在同一原 phase/window 切片上有 0<L≤R_B≤U。定义 Δ_j=|y_j−z_j|。

对每个 t>0，允许中心集合为

E_t=Q(z,t)∩Q(y,st)。

两 cube 都随 t 扩大，因此 E_t 嵌套。这是关键：不要求原可测赋值 B↦R_B 连续或单调。第 j 坐标交长精确为

t·min{1,((1+s)/2−Δ_j/t)_+}。

于是 |E_t|=t^nP_s(Δ/t)，其中 P_s 为这些截断因子的乘积。该乘积来自 Lebesgue 中心交集的直角结构，不是假定实际来源 μ 的坐标独立。

对实际捕获事件 z∈Q(B,R_B)、y∈Q(B,sR_B)，等价于 B∈E_{R_B}。利用

R_B^{−n}=U^{−n}+n∫_{R_B}^U t^{−n−1}dt

及 E_{R_B}⊂E_t (t≥R_B)，Tonelli 得到

∫R_B^{−n}1_{E_{R_B}}(B)dB
 ≤U^{−n}|E_U|+n∫_L^U t^{−n−1}|E_t|dt
 =P_s(Δ/U)+n∫_L^U P_s(Δ/t)dt/t=:K_{g,L,U}(y,z)。   (C)

因此所给可测半径容量正确。实际 bulk/附加 gates 可留在左边后丢弃为上界。闭边界按原 cube 定义处理；推导从未假定可变半径边界图为 Lebesgue 零集。

必要边界：

- 若 L=U，积分项为零，留下准确固定半径交集 P_s(Δ/U)；
- 若 y=z，P_s≡1，所以 K=1+nln(U/L)，old 平台完整保留；
- g=1 时 K 通常不为零，不能继承 new-shell 的 Γ(1)=0；
- P_s≤1 给 K≤1+nln(U/L)≤1+2lnD0，但丢掉 P 的坐标结构只留下通用粗帽，不能计为 cube-specific 全局增益。

首项 P_s(Δ/U) 不可删除。只有证明其与积分项在全部原来源/旧窗累计后仍可付款，才涉及全局目标。

完整共测度转移须把真实 full w（不只是 w⁺）和完整行 r(B)=∫wΞ 同时使用；来源前行动不变。若改用支撑 esssup 收费，其支撑必须覆盖 y∈Q_B(g) 的全部 old/new 捕获，不能沿用 r_+ 的 new-only 信用证明。该检查要求已发 core。

## 7. nonradial 实稿核验：容量和完整转移通过

独立段之后读取 `/tmp/ccu_r563_pairgeometry.tex`。该稿已经包含完整 old+new 的共同信用及后验转移，以下是对实际证明的审查，不是把新壳结果泛化后的猜测。

### 7.1 容量与坐标增益

作者最小可行边长 r_*(B)=max{2||B−z||∞,2||B−y||∞/s}，以及对 max(L,r_*) 的层积分推导，与独立式 (C) 一致。嵌套性、固定 side-length convention、任意仅可测 R_B 及所有 endpoints 均正确。没有把一个固定半径交体积恒等式直接用于变量半径。

设 ε=(s−1)/2，则每个乘积因子等于 [1−(Δ_j/t−ε)_+]_+。从 product≤exp(−Σ正部) 与 t≤U 的单调性，得到

K_{C,g}(y,z)≤[1+nln(U/L)]exp(−Σ_j(Δ_j/U−ε)_+)
             ≤(1+2lnD0)exp(−E_U(y,z))。

该界通过；保留了真实来源对的全部坐标，既不拆分 μ，也不假定条件独立。分离对有真实局部衰减；近源对特别 y=z 仍承担完整正平台。不能减掉 s=1 的 envelope 来冒充 variable-R new-shell 差，作者已明确不这样做。

### 7.2 完整 old+new 信用和同一核

当前 w 是合同的完整 1_{Q_B(g)} 捕获，r_*(B)=∫wΞ 是完整行，不是 R562 的 w⁺/r⁺。来源支持 esssup 也覆盖全部 old/new 捕获。原规范 κ(1)=1、I=∫ω/κ 明确保持。

完整核心行由 first-stop 反链与 H_T⊂T 支配于原完整 adaptive Gram 行；逐父恢复场 L1=t_Bq_B(2+lnG)/I_B，配原恢复场帽 G C_*(G)，得到安全 Krow=G C_*(G)(2+lnG)。

作者 a_x=1/[1+esssup活跃父 r_*] 与 T、旧 z/σ 无关，仅作分析收费；Fubini 给完整 Ra≤r_*/(1+r_*)≤1。因此 Cstar²≤QgVa 只花一次完整信用。没有按 old/new 各用一次 Qg，也没有把接收后收费变成接收后行动。

### 7.3 两份 M、节点顺序与旧窗口

原外 Ξ 的系数仍为 γt_Cq_C/[I_CM_C(v)²]，内 w 仍保 M_C/(γI_BM_B)。与原 old k_B 的来源积分匹配，未丢任何质量分母。

作者在固定 C,v,g,y 的同一个父积分中先合并所有 T：

F=Σ_T Gate_T·1_H_T(y)·L_x。

反链先给 F≤L_i；同一个已合并分子再用真实两-source capture 和 t_B≤S 给 F≤SK。故

F/L_i≤1_{Σ_C}(σ) min{1,SK/L_i}

方向正确，不存在逐节点分别取 min 后的隐性深度费用。Σ_C=(s_C−1−h,s_C+2+h) 保留全部可能旧窗口；它不是全局旧窗并集已压缩的证明。g=1 的正 old-capture 原子被明确保留，旧平台没有被删成零。

由此作者 Va≤Vpair 的全部积分因子通过：完整两份 M_C、外 γ/I_C、真实接收 μ(dy)、旧来源 μ_i(dz)、旧 σ 和 Li 分母、收费 s 均在同一测度上。对 L_i=0 按零处理。没有把非加权 pair price 当作旧后验。

### 7.4 尚未支付什么

完整 Cstar²≤QgVa 的信用侧已经合法；但作者当前仅证明

Va≤Vpair，
Va≤Krow(1+Krow)DclkW。

第二式不推出 Vpair 的同一上界，作者对此已经正确限定。Vpair≤polylog(n)W 是更强的具体充分条件，目前未证；该上价若很大，也不能单凭它否定原 Cstar 或其他合法收费。

因此当前净几何结果仅是把逐坐标的分离衰减保留到正确的完整来源上价中。旧 σ 累计、低 Li 区域、近源平台及真实质量演化的共同支付仍缺。没有一般根阶结论，也没有把一次局部 n 消除认作全局闭合。

### 本次轻量实跑

同一指定 Python 3.12.14、SymPy 1.14.0：实际检查 y=z 时核的首项与积分和是否等于 1+nln(U/L)，残差精确 0；在 n=2、s=1 且两坐标均处于交集线性内部的 P=(1−a/t)(1−b/t) 分支，核的层积分与 Stieltjes 分部积分残差为 0；L=U 时核减 P(Δ/U) 的残差为 0。没有数值扫描；这些只核代数，容量正确性来自嵌套集合的解析推导。

本段已将准确通过范围与未付 global 条件发给作者、core 和主代理。待 core 组合稿落盘，仅检查其是否保持同一完整对象，不另扩展任务。

## 8. 最终新增输入：完整 low、Jτ 边际、空间 envelope 与 cluster 质量账

按主代理最终指定，只读 core 全文及 pairgeometry 的 Integrated addendum，不重审此前主核。以下先按同一完整共测度独立核要素，再核作者实稿的全账范围。

### 8.1 完整低 Li 部分：PASS

对完整 dM（不是仅 new），原行 r(B)≤K=G C_*(2+lnG) 给

C_low=Σ_i∫_{Li≤τ}∫bulk r(B)k_B dB μ_i(dz)dσ
 ≤K∫_{0<Li≤τ}Li μ_i(dz)dσ
 ≤Kτ DclkW。

因此 τ=Dclk^{−1} 确实付成 KW，无需花 Qg。原 Li 为完整父场、bulk 场≤Li，零场处没有漏掉正贡献。core (2) 与 addendum 同式通过。

高场值可用 core 的常数收费 a=1/K，或 nonradial 已定共同权；两者各自都仅花一次信用。core 的

2Cstar≤2KτDclkW+ζQg+Vhi/ζ

保留了低块实际 W 费及高块未付来源费，未把分支切分当成新行动选择。

### 8.2 core (7)→(8) 的精确远距外边际：PASS

用均匀 e^{−R} 上界后，原外系数仍有 M_C(v)^{−2}。先积分实际接收来源 μ(Q_C(v))=M_C(v) 才消去第一份；剩下一份通过真实恒等式

∫ω(dv)/M_C(v)=I_C/m_C

抵消，不能将 κ_C 当常数。g 的完整质量为 Λ=2+lnG，m_C=q_CR_C^n。因此准确得到

Jτ=γΛ Σ_i∫bulk [t_C/R_C^n]
      ∫_{Σ_C} μ_i{z:Li(z,σ)>τ}dσ dC。

旧 σ 保留，Σ_C 仅依赖 C，故可合法从动作积分提出。该式无任何 z∈Q_C 的空间定位，不是原 Li；以同一 sourcecell 索引并不能将它收成 W。core 明确保留这一失定位边际，未宣称 far 已付。

分离缩放复制的计数也正确：若 primitive 父族允许在同一源格内作所述合法 packing，R^{-n}dC 每份不变、旧 σ 统一平移、Li 数值及 α 保持；内来源质量每份乘ρ^n。所以 Jτ 乘N²ρ^n而 W、Qg、真实完整恢复能量乘Nρ^n。该诊断只针对已经丢掉空间关系的 Jτ，不能用来反驳原核或原目标。

**scope 小修要求：** “任意有限 N 原合同允许”必须限定在 primitive 父族确实允许该合法 packing 复制的范围，不应声称已验证完整原构造历史允许任意 N。已向 core 发出此明确修订建议。原公式 (9) 的代数无需修改；只能作为放松边际的 packing 诊断。

### 8.3 保空间定位的 Aβ 外积分：PASS，但费用指数级

addendum 使用的统一核界

Kpair≤A0 exp((G−1)/2) exp(−||y−z||₁/U_C)

正确：Σ(Δ/U−(s−1)/2)_+≥||Δ||₁/U−n(s−1)/2，而 n(g^{1/n}−1)≤g−1≤G−1。

高场且距离≥DU_C 时，把指数分成 e^{−(1−β)D}e^{−βdistance/U_C}，并用 1/Li≤1/τ，得到原稿 far posterior bound。此处保留的 Aβ 仍有原两份 M、共同收费 s、真实来源 μ_i 和旧 σ。

其完整外积分的付款步骤均通过：

1. μ|_{Q_C(v)}/M_C(v) 是实际概率；以该支持的 supremum 放大指数，不是密度帽。因 Q_C(v)⊂Q(C,G^{1/n}R_C)、U_C≤D0^{1/n}R_C，指数方向正确。
2. 剩余 q_C/M_C(v)=1/[κ_C(v)R_C^n]，∫ω(dv)/[I_Cκ_C(v)]=1 精确。g 留下 Λ；s≤1+K；旧窗长度仍付 3+2h。
3. 写 c=G^{1/n}、d0=D0^{1/n}，固定 R 的真实 Lebesgue 中心积分为 (c+2d0/β)^n。各坐标的一维积分是 c+2d0/β，乘积来自中心积分，不是来源 μ 的独立化。
4. f_R(C)=exp[−βdist₁(z,Q(C,cR))/(d0R)] 随 R 增大单调不减，因为距离比等于 Σ(|z_j−C_j|/R−c/2)_+/d0。原 R_C 仅可测也满足

R_C^{−n}f_{R_C}≤b^{−n}f_b+n∫_a^b t^{−n−1}f_tdt。

积分后的合法 envelope 费为 A_n=1+nln(b/a)。最终按真实 μ_i(z) 积分，Σ_iμ(C_i)=W，没有再按每个中心/旧层发放 W。

所以作者显式上界

Aβ≤γS(1+K)Λ(3+2h)A_n
       [G^{1/n}+(2/β)D0^{1/n}]^n W

全部常数和方向通过。β=1/2、参数对数=o(n) 时该因子约为5^n；不能当作 polylog。当前估计需要包含 O(n)、log(A_n/τ) 以及其他显示参数的距离阈值，未支付仅 O(log Dclk) 的 cutoff。这个指数损失是上界方法的费用，不是实际 Aβ 的指数下界。

### 8.4 固定共同 H 的 phase/window 和质量求和：条件性 PASS

该子估计明确要求同一个真实固定簇 H 满足 H⊂Q_C(v)、y,z∈H、m_H>0。几何近距不能推出这些条件，特别不能推出旧 z∈Q_C(v)。

在真实 M_C(v)∈[γ^ℓ,γ^{ℓ+1})、κ_C(v)∈[γ^{jh},γ^{(j+1)h}) 下，

s_C∈[ℓ−jh−h,ℓ+1−jh)，
Σ_C 的并集⊂(ℓ−jh−1−2h,ℓ−jh+3+h)，

所以旧窗长 4+3h 正确。j≥0 使用原 κ(1)=1 与质量单调性；未放到非原规范。

R_C^n≤γM_ℓ/(qγ^{jh})。包含整个 H 的中心容量由各坐标 essential support width 给出的 product narrowing 正确；乘实际外系数 γt_Cq_C/[I_CM²] 后，得到

γ²Sr·vγ^{−jh}/M_ℓ × product。

两份 M 中一份被中心容量的 M_ℓ 正确抵消，并非丢失分母。使用 product≤1、s≤1+K、完整 ω(v/g) 端点，得到作者 C_cl 的因子 2GΛ、(1−γ^{−h})^{−1} 和旧窗 4+3h 均准确。

最后 M_C(v)≥m_H、M_C(v)<γM_ℓ 强制 M_ℓ>m_H/γ，用更宽的 ≥ 只放大正和，因此

m_H² Σ_{ℓ:M_ℓ≥m_H/γ}M_ℓ^{−1}
 ≤[γ/(1−γ^{−1})]m_H

通过。它支付固定共同簇的全部质量层，没有 Dclk，但必须随后有实际统一分配使 Σ_Hμ(H)≲W 或等强 Carleson 账。

若只把新 y 放入 H_y⊂Q_C(v)，旧 z 留在更大的 H_z，诚实的 pair mass 是 μ(H_y)μ(H_z)，质量级数只能支付 μ(H_z)；多个 H_y 共用 H_z 的重复仍须另付。作者明确写出了该限制，未把所有树节点直接当作一次簇质量。

## 9. 最终总账判定与未证接口

除上述分离复制 scope 的小修外，core low/Jτ 与 addendum 的指数外积分、固定簇质量账均通过。三者互不冲突：core 只否定丢定位后的 Jτ 免费 W 收费；addendum 保定位可给显式指数费，但未给目标对数 cutoff。

仍未证明的 global 接口必须全部保留：

- 完整高 Li 的真实 Va 或其更强 Vpair 上价固定多对数 W 预算；
- 全部实际双源对到共同簇/森林的统一分配，要求共同 H⊂Q_C(v) 且 y,z 同簇；
- 不能共同包含的跨簇部分达到同等强度的付款；
- 全局簇质量的一次预算或真实 weighted Carleson bound，不能按节点/旧层复制 W；
- 使用同一份 Qg 信用后的严格吸收系数及未变的外层恢复/入口/时钟费用。

实际 Va 的粗 K(1+K)DclkW 界仍不推出 Vpair 的同一粗界。近距或坐标窄不推出共同 H⊂Q_C(v)。本轮没有 root-order 闭合。

### 最终轻量工具证据

指定本机 Python 3.12.14、SymPy 1.14.0 实跑：接收 M 与真实 I/m 的抵消残差为0；一维空间积分与 c+2d0/β 残差为0；cluster 旧窗长度精确返回4+3h；复制边际/W缩放比返回N。均为精确符号结果，无扫描、无优化，不代替 global 几何证明。

## 10. Scope 修复复核与本轮冻结

已核对最终 `/tmp/ccu_r563_core.tex`：首段第14–15行、复制段第135–161行及末段第185–186行均把分离复制诊断明确限定于 primitive 冻结父族允许所述合法 packing 的情形；不声称完整原历史任意 N 复制，不据此否定真实全历史对象。该 scope 小修已完成，前节所列待修项解除。文件 SHA-256 实测为 `5a9aa3770629b8c13619194905bfb7f7ef0660f147d50962b5b8a953ed481843`。

最终判定：本轮实际写出的 low-Li 付款、Jτ 精确外边际、variable-radius 空间指数包络积分，以及带共同包含假设的固定簇 phase/window/质量层求和，均 PASS；此前完整共测度、两份 M、旧 σ 和先合并 T 后取 min 的核验继续有效。pairgeometry 的新增积分已纳入第8节审计。第9节所有 global 接口仍未证；显式指数维数费用不构成目标多对数付款，实际 Va 粗帽也不转移为 Vpair 粗帽。

本轮审计到此冻结，不扩展其他候选，不把局部容量改进或条件簇估计记为完整 root-order 闭合。


---

## cluster_audit.md

Source SHA256: `6253ddb87a5ced4d680a9507d58375739a1baaa67ee5647cc29960db6c5d243f`

# R563 独立审查：共同互斥簇的完整 posterior 正子预算

日期：2026-10-23。审查人：Sol 主证明/统一符号。此任务只审 cover 的簇子付款，不重审本人先前 deficit 公式，也不审完整几何闭合。

**结论：修复后 PASS。** `/tmp/ccu_r563_crosslayers.tex` 的 CL4–CL11 在其固定、可数、共同、两两 μ 互斥簇条件下成立。中心体积、旧 σ 总长度、两来源 μ(H)²、两个 M 分母、几何质量求和和常数均独立核准。该结果仅付款完整 posterior 中“双来源同一簇且整簇包含于外父盒”的正子项；跨簇、簇外以及未整体包含的补集全部未付。

核定版本 SHA256：

    641a6f491b3950d0fadbab4f4f3a038e6ccd428a99c8a0b6ac64a0d624896dbc

## 1. 必须先修复的 full INNER row 范围

初稿使用 `2G γ^(2+h) r_band² S` 作为完整内父行帽，存在将 R562 外父 `barΛ_C` 帽转称内父行帽的 scope 问题。本审查不接受这种未经转换的继承。最终稿已改为安全的完整内父帽

\[
 K_{\rm safe}=G C_*(G)\Lambda,\qquad
 \Lambda=2+\ln G,\qquad A=1+K_{\rm safe}.
\]

此修复可从当前 fixed-adaptive 场直接独立核证。令单位恢复父字段

\[
 f_B=I_B^{-1}\int\frac{\omega_0(dg)}{M_B(g)}
       1_{Q_B(g)}1_{\rm true\ window}e_{j_B(g)}.
\]

则真实来源/窗/phase 积分给 `||f_B||_1=Λ/I_B`。先对固定 B 合并全部真实停节点，其核心行是完整 Gram 行的正子项，故

\[
 r_B=\int w_x(B)d\Xi(x)
 \le\langle f_B,\widehat Y^{\rm ad}\rangle.
\]

原 raw 自适应场是来源前概率场，已审逐实际 phase 帽为 C_*。又 η_B≥1/G，所以逐点

\[
 \widehat Y^{\rm ad}\le GY^{\rm ad}\le G C_*.
\]

因此

\[
 r_B\le G C_*\Lambda/I_B\le K_{\rm safe}.
\]

这使用的是完整 old+new 内父行；没有换成仅新壳行，也没有漏掉真实窗口或另乘 J。它针对当前 fixed-adaptive Cstar 合同，不自动推广到任意优化恢复概率。

最终共同 payer 取

\[
 s_{C,v,g,y}=1+\operatorname*{ess\,sup}_{
 B:\Theta_{BC}>0,\ y\in Q_B(g)}r_B,
 \qquad a_x=s_{C,v,g,y}^{-1}.
\]

它不依赖停节点 T 或旧来源 (z,σ)，且 `1≤s≤A`。在原冻结 score 测度下，对 w_x(B)>0 的相关父，有 s≥1+r_B（乘积测度 a.e.），故

\[
 R_a(B)\le r_B/(1+r_B)\le1.
\]

这是分析共同收费；不改变来源前行动，也不按接收者重新选择半径。

## 2. CL3–CL4 的正确积分次序

固定 (C,v,g,y)，必须先在同一个内父 B 积分中合并所有原首次停节点：

\[
 F_{C,v,g,y}(z,\sigma)
 =\sum_T\mathsf G_T1_{H_T^{\rm original}}(y)
                   L_{(i,C,v,g,T,y)}(z,\sigma).
\]

对固定 B，首次停止节点是反链，且 `H_T^original⊂T`，故一个 y 最多属于该父的一个停节点。加上原 head、gate、质量比和帐篷因子都在 [0,1]，得

\[
 0\le F_{C,v,g,y}\le L_i.
\]

这不要求不同 B 或不同外父的原核心互斥。若先向每个原节点各发一个旧窗口预算，此结论不能替代那份重复费用；本稿的次序是正确的。

非零真实同 phase/窗 Gram 强制

\[
 |s_B-s_C|<1+h.
\]

因此所有旧 B 窗均在

\[
 \Sigma_C=(s_C-1-h,s_C+2+h),\qquad |\Sigma_C|=3+2h.
\]

ratio 在 L_i=0 处定义为 0，故 `F/L_i≤1` 合法。完整倒数来源费为

\[
 V_a=\sum_i\int\frac{\gamma t_Cq_C}{I_CM^2}
 dC\,\omega_0(dv)\omega_0(dg)
 \int_{Q_C(v)}\mu(dy)\int\mu(dz)d\sigma\,
        s_{C,v,g,y}\frac{F_{C,v,g,y}(z,\sigma)}{L_i(z,\sigma)}.
\]

这里 M=M_C(v)。本式保留了真正旧后验分母和两份 M，不是把来源后验直接当成独立源概率。

## 3. 固定共同簇的中心容量：无额外 2^n

每个源格内的簇族 H 必须由原输入一次固定，统一用于全部 (C,v,g,T,y,σ)，可数且两两 μ 互斥。令 u=μ(H)>0，只保留

\[
 y,z\in H,\qquad \mu(H\setminus Q_C(v))=0.
\]

于是 M≥u。按实际 M 分互斥档

\[
 M\in[m,\gamma m),\qquad m=u\gamma^k,\quad k=0,1,\ldots.
\]

对固定 v 和该档，因 q_C≥q、κ_C(v)≥1，

\[
 R_C^n=\frac{M}{\kappa_C(v)q_C}\le\gamma m/q.
\]

固定共同簇 H 可以选一个与 C 无关的支点 y_H。采用重心时：若 H 有任何贡献，它本质上包含于某个有界动作盒，故其有限质量一阶矩存在；每个 μ-a.e. 包含 H 的闭凸方盒都包含该重心。完全无贡献的簇无须定义重心，也可直接忽略。

所以所有贡献中心均满足

\[
 2\|C-y_H\|_\infty\le v^{1/n}(\gamma m/q)^{1/n}.
\]

R 是边长约定，因此真实 Lebesgue 中心体积至多

\[
 v\gamma m/q.
\]

没有 2^n；没有要求来源坐标独立；也没有假设 μ 密度有上界。whole-cluster containment 在这里是真条件：仅给 y,z 两点碰巧位于外盒，不能推出 M≥u 或同一固定簇支点限制。

## 4. 旧 σ 长度：为何是 4+2h+log_γ Kmax

在该实际质量档内，1≤κ_C(v)≤Kmax，故

\[
 \log_\gamma m-\log_\gamma K_{\max}
 \le s_C<\log_\gamma m+1.
\]

把此档内全部 Σ_C 一起并入

\[
 (\log_\gamma m-\log_\gamma K_{\max}-1-h,
   \log_\gamma m+3+h),
\]

其长度恰为

\[
 L_\sigma=4+2h+\log_\gamma K_{\max}.
\]

额外 1 来自实际 M 档宽，不应漏掉；无需再加 D_clk，也不应按此档的每个旧质量层各付 W。这里保留实际质量变化，才使 σ 支持受 Kmax 控制。

## 5. μ(H)²/M² 与完整系数

在上面的共同事件内，以 `F/L_i≤1`、s≤A、I_C≥1、t_Cq_C≤Sλ_band 作正上界。由于实际基测度确为 μ(dy)μ(dz)，并且**两个来源均显式限制在 H**，此时两个积分的上界才是 u²。这个乘积来自对真实 tensor 基测度的有界核上界，不是假设原来源或其坐标独立。

每个质量档、固定 v,g 的总费因而至多

\[
 \frac{\gamma S\lambda_{\rm band}}{m^2}
      \frac{v\gamma m}{q}\,A L_\sigma u^2
 =\gamma^2Sr_{\rm band}A vL_\sigma\frac{u^2}{m}.
\]

保两个行动端点的精确积分为

\[
 \int\omega_0(dg)=\Lambda,
 \qquad\int v\omega_0(dv)=2G,
 \qquad\sum_{k\ge0}\frac{u^2}{u\gamma^k}
        =\frac{\gamma}{\gamma-1}u.
\]

故固定 H 的 fee≤L_cl μ(H)，其中**使用修复后的 A**：

\[
 \boxed{\displaystyle
 L_{\rm cl}=\frac{2G\Lambda\gamma^3}{\gamma-1}
            Sr_{\rm band}\,[1+G C_*(G)\Lambda],L_\sigma.}
\]

这与最终 CL6–CL10 一致。若原固定参数配置使各项为固定多对数，该正子费才是固定多对数；不隐去 G、C_*、A 或 σ 费用。

## 6. 互斥的真作用与剩余项

固定共同 μ-disjoint 族有两项确切作用：

1. 对几乎所有实际 (y,z)，同簇指示之和不超过 1，因此这确实是原 V_a 的一个正子项，而非一个重复放大的辅助量。
2. 最后只用一次 Σ_iΣ_H μ(H)≤W，将所有实际 M 档与全部簇一起支付。

若每个外父 (C,v) 自己重新选一套互斥核心，这两项不能推出跨外父的同一 Σμ(H)≤W。嵌套来源树的每层互斥同样不等于全树互斥；只说节点 μ(H)≤M 亦不足。

令 V_diag 为已审事件的正子项，余项定义为原被积核乘 1-P_diag。则

\[
 V_a=V_{\rm diag}+V_{\rm rem},\quad V_{\rm rem}\ge0,
 \quad V_{\rm diag}\le L_{\rm cl}W.
\]

同一个完整 a 满足 R_a≤1，因此只用一份 Qg，完整原桥仍给

\[
 \boxed{\mathcal C_\star^2\le
                 Q_g\,[L_{\rm cl}W+V_{\rm rem}].}
\]

CL11 通过。这里既没有给两部分各发 Qg，也没有把已付子项当成完整 Cstar。V_rem 包含：不同簇、族外来源，以及同簇但未 whole-cluster-contained 的所有贡献。原随 (C,v,T,g) 改变的重叠核心并未被证明能分配到这套共同族；这正是不能宣称全量嵌入已完成的原因。

如未来另外证明同一 a 下 V_rem≤L_rem W，才可把 L_cl+L_rem 送入原共同半吸收母账；当前无此结论。原 J、d、删除信用、source cells、Rstar 和外层费用全部不变。

## 7. 实际工具与冻结状态

先独立核质量档、中心容量、σ 总跨度及系数，再读最终作者稿逐项对照；没有用作者结论替代独审。仅运行指定本机 Python 3.12.14 / SymPy 1.14.0 作精确核验：

- σ 两端之差为 `4+2h+logK`；
- 质量几何和、ω0 两个矩后的 L_cl 系数残差为 0；
- ω0 总质量为 `2+lnG`，一阶体积矩为 `2G`。

没有数值扫描、重计算、PDF、仓库或他人文件修改。审查冻结为：**safe inner-row 修复后，此共同互斥簇的完整 posterior 子预算通过；完整余项付款未证，不认证一般闭合。**


---

## feature_audit.md

Source SHA256: `2d1cde1a9014a085ae4b6e0b11ab2304193bb9123ee7de834f7c872c36cbe271`

# R563：完整 OLD/NEW、band/phase 与真实窗的独立特征审计

日期：2026-10-23。只写本文件，不改其他角色文件/仓库，不编译 PDF，不重复优化。N4 独立审 serialized 矩阵的精确代数，本角色审几何来源掩码、真实窗/phase、全部交叉项及解释范围。

## 1. 先独立确定 OLD/NEW 对象

沿用 R562 已独立核验的有限原子模型：`μ=Σ_s w_sδ_xs`，父 `p` 的正积分权 `ω_p`、`a_p=t_p/R_p^n`，动作 `a` 的捕获 `I_pa(s)=1_Qp(gpa)(x_s)`、真实质量 `M_pa`、窗左端 `ℓ_pa=logγM_pa` 和真实相位 `j_pa=floor(logγκ_pa/h)`。原父旧捕获为 `I_p0(s)=1_Qp(1)(x_s)`，由嵌套性 `I_p0≤I_pa`。

**literal OLD/NEW 必须只拆空间来源掩码，保留同一动作的真实窗与 phase：**

\[
\chi^O_{pa}=a_p I_{p0}(s)
 1_{[\ell_{pa},\ell_{pa}+1]}(\sigma)e_{j_{pa}},
\qquad
\chi^N_{pa}=a_p[I_{pa}(s)-I_{p0}(s)]
 1_{[\ell_{pa},\ell_{pa}+1]}(\sigma)e_{j_{pa}}.
\tag{O1}
\]

因此 `χ=χO+χN` 精确。这里 OLD 不等于旧字段 `k_p`：其窗仍随动作质量移动，并按动作真实 phase 分组。把 OLD 窗强行换成 `logγM_p(1)` 或 `s_p=logγm_p` 的旧窗，只能定义一个**另行标注的 baseline**，不是同一对象的分解。

设完整 all-band 特征 `F` 的行是 `(source s,phase j,σ段 k)`，列为父动作 `pa`，系数是

\[
F_{(s,j,k),pa}=\omega_pa_p\sqrt{w_s\Delta\sigma_k}
 I_{pa}(s)1_{j=j_{pa}}
 1_{(\tau_k,\tau_{k+1})\subset(\ell_{pa},\ell_{pa}+1)}.
\]

逐非零项令 `F_O=F·1_{s∈Q_p(1)}`、`F_N=F·1_{s∉Q_p(1)}`，即一项只落入一边。给定每父共同合法 `ρ`，

\[
O=F_O\rho,\quad N=F_N\rho,\quad F\rho=O+N,
\]

\[
E=\|O\|^2+2\langle O,N\rangle+\|N\|^2. \tag{O2}
\]

OLD 和 NEW **不是 Hilbert 正交标签**：同一来源点可对父 p 是 OLD、对父 q 是 NEW，所以 `ON` 往往严格正。把它们放到互不相交新行再平方会错删 cross。

## 2. 全部父对、band、旧质量层与 phase

对 `X,Y∈{O,N}`，两个具体父动作的精确 Gram 为

\[
H^{XY}_{pa,qb}=\omega_p\omega_q a_pa_q\,
1_{i_p=i_q}1_{j_{pa}=j_{qb}}
\sum_s w_s I^X_{pa}(s)I^Y_{qb}(s)
\big(1-|\ell_{pa}-\ell_{qb}|\big)_+ . \tag{O3}
\]

`I^O=I_p0`，`I^N=I_pa−I_p0`。所有有序父对、两批交叉、动作对与共同来源保留；`NO` 是转置 `ON`，总费用的 `2ON` 不能只计一个次序。

若 `O_b,N_b` 是父 q-band `b` 的贡献，则完整能量为

\[
E=\sum_{b,c}\{\langle O_b,O_c\rangle
 +\langle O_b,N_c\rangle+\langle N_b,O_c\rangle
 +\langle N_b,N_c\rangle\}. \tag{O4}
\]

它不是 `Σ_b||O_b+N_b||²`。old-count 层（原 `M_p(1)` 或 `s_p`）也只是贡献来源标签；若不属于原正交源格，必须先按层求和后平方，同样保全部 `l,l′`。high/low q-band 的拆分应有明确阈值，并含 `HH+HL+LH+LL`，不能删除正的高低交叉费。

原 `H=⊕_(i,j)L²` 中不同真实 phase 正交，因此 (O3) 的 `j≠j′` 项确为零；这不是删项。若为了诊断去掉 phase 标签，则新的能量包含所有 phase 对：

\[
E_{\rm erase}=\left\|\sum_j Z_j\right\|^2
=\sum_{j,j'}\langle Z_j,Z_{j'}\rangle,
\]

交叉窗仍用 `tent(ℓ_pa−ℓ_qb)`。该值是另一个诊断字段，不是原真实 phase 目标。

## 3. 真实 −jh 移窗与未移窗 phase erasure 不同

定义 `U_{−jh}` 为把 phase j 的窗左端从 `ℓ` 移至 `ℓ−jh`。令 `s_p=logγm_p`，则 floor 定义精确给出

\[
\ell_{pa}-j_{pa}h=s_p+\delta_{pa},\quad
\delta_{pa}=\log_\gamma\kappa_{pa}-j_{pa}h\in[0,h).
\tag{O5}
\]

所以移窗后的 OLD 一般仍不是 `k_p=a_pI_p0·1_[s_p,s_p+1]`，而是残差移动 `δ_pa` 的旧空间字段。只有精确可达质量阈值 `κ=γ^(jh)` 才 `δ=0`。本次数值 `m=M(1)`，故 initial 的 `κ=1,δ=0`；不能据此替换所有其他动作。

逐 phase 移窗是 unitary，故

\[
\sum_j\|U_{-jh}Z_j\|^2=\sum_j\|Z_j\|^2=E.
\]

但把所有已移动 phase 真正合并后的能量为

\[
E_{\rm shifted}=\left\|\sum_jU_{-jh}Z_j\right\|^2,
\]

其父动作对窗因子必须改为

\[
\big(1-| (\ell_{pa}-j_{pa}h)
              -(\ell_{qb}-j_{qb}h)|\big)_+ . \tag{O6}
\]

这一般不同于单纯删除 j 标签、仍用原 σ 段的 `E_erase`。若 N3 不另建移后 σ 划分或直接按 (O6) 算，就只能报告 `E_erase`，不能称为实际共同移窗能量。母账的一次 `3h` 窗损失及 `J` 费用仍是原合同条件，数值 phase erasure 不会自行支付它们。

## 4. 旧窗 baseline 的合法定义与范围

冻结旧窗 baseline 可写为

\[
K_p(s,\sigma)=a_pI_{p0}(s)1_{[s_p,s_p+1]}(\sigma).
\]

把每父同一动作概率按真实 phase 汇总 `P_pj=Σ_(a:jpa=j)ρ_pa` 后，可定义 `B_j=Σ_pω_pP_pjK_p`。若 erase phase，`Σ_jB_j=Σ_pω_pK_p` 与动作律无关。这是基线比较，不是 literal OLD。若给 baseline 一个新固定 `j=0` 标签，必须声明它是在另一嵌入中展示旧字段；不能将其直接代入原 `OO`。一般 `m≠M(1)` 时 baseline 必须区分 `s_p=logγm_p` 与 `logγM(1)`；N3 有 `m=M(1)`，两者相同。

## 5. N3/N4 分工与实施前确认

N3 作者已在我读实现前确认：直接用 R562 serialized all-band CSC，OLD 按各父 initial receiver mask 筛同一列来源行；NEW=F−OLD；保真实 count 窗与 phase，另报旧 count 窗 baseline。主口径不移窗；phase erasure 明确不是 `−jh`。此设计与 (O1)–(O6) 相符。

N4 将对同一 data+is_old 拆分作 Fraction 精确矩阵算术、核 `OO+2ON+NN` 和 ordered band cross，不认证 ideal geometry。本角色不重复其精确矩阵运算，只核原来源掩码/窗口和解释。

## 6. N3 最终实现审计：通过

已读 `/tmp/ccu_r563_n3.py`、`.json`、`.md` 最终稳定版。代码 SHA256 为

`b665c86ff4502c168c370424315840b8496e20923db86c52789763416e977b8a`，

与 JSON 相符。输入 optimizer SHA256 为 `edf8f993d1511e1735621e8855311af8243f0f06231da52789c07cc06a47bbe4`。没有调用 N3 主计算或任何优化器；本角色只做下列廉价独立核查。

1. **来源/OLD 掩码。** 从 R562 冻结来源云及每父中心/边长直接用 `2||x_s−B_p||∞≤R_p` 重算旧捕获，而不把 N3 的 `initial` 当依据。核全部 32,673 个原 CSC 非零的 `is_old_data`，错误计数 **0**。N3 的 `source=row_keys[row][0]`、`parent=state[col].parent` 对应正确；OLD/NEW 不按 band 或 phase 另筛来源。
2. **同一真窗/真 phase。** N3 `matrix_csc` 与 R562 已审 all-band serialized 矩阵逐字段完全相同，`row_keys` 也相同。`O.data=F.data*isold`、`N.data=F.data*(~isold)` 只是同一列同行数据的二选一，没有重算 log、平方根、质量窗或 phase。因而 literal 分解是 (O1)，不是旧窗替换。其 `F=O+N` 的代数另由 N4 精确核。
3. **全部 band 与旧层 cross。** `grouped()` 对 band 或 old count 的每个列组先求字段，再形成 `OO`、`NN`、有序 `ON` 和 total 全矩阵；`sum(total_gram)` 包括所有行列组及两次序。低高阈值明定 `band<0` 与 `band≥0`，仍报告 2×2 含高低两个交叉，没有删除父。old mass layer 是原整数 `old_count`，不是 band，也不是把连续 σ 窗重新正交化。
4. **全部 phase cross 的准确对象。** 真实 phase primary 用原直接和，`by_phase` 只是正交分解。`phase_pair_gram_after_erasure` 将每个真实 phase 字段先投到共同 `(source,σ段)` 网格，再作全部 phase-pair 的 OLD/NEW/有序 ON/total Gram，符合未移窗的 phase erasure。所有七种 law 的 phase-pair total 与 `phase_erased.total` 的最大舍入残差 `4.0e−15`。
5. **真正 −jh 移窗。** `shifted_energy()` 每列用 `left=log2(count/64)−phase/8`，按来源建立实际窗起止事件，合并 OLD 与 NEW 两分量并对每段积分外积。它既不保旧 σ 网格假装移窗，也不把 `left` 重设为 `log2(old_count/64)`。独立核得 1,264 状态中有 **442** 个严格正残差，`δ` 范围 `[0,0.11547721741993588]⊂[0,1/8)`。这一非零残差实际被保留。相同位置事件逐次更新只产生零长中间段，不遗漏端点；σ 闭端点仍为零测。
6. **旧窗 baseline。** `oldwindow=F rho_delta1` 对应同一有限 bulk 父、同一 all-band 矩阵的 initial 字段，真实 `j=0` 且本模型 `m=M(1)`，所以是上述旧窗 baseline。它不是完整原 training `Qg`，N3 文档已明确。`OLD_deviation` 是 literal OLD 与此 baseline 在同一原 phase 空间的差，不是纯几何位移估计。

因此没有发现 OLD/NEW、窗、phase、band/layer 有序 cross 的遗漏，也没有发现用错误的 phase-erased 能量替代实际移窗能量。该 verdict 不认证理想 log/平方根的严格误差界；N4 的 Fraction 证书也只针对 serialized rounded 数据。

## 7. 数值读数与决定边界

以下为相同冻结有限输入的完整 all-band、真 phase 读数；不是新 solve。

| law | OLD² | 2 OLD·NEW | NEW² | 完整 E |
|---|---:|---:|---:|---:|
| adaptive | 1.533763660450 | 0.014471843810 | 0.010358064363 | 1.558593568624 |
| common | 1.321250186357 | 0.041356922286 | 0.030270172832 | 1.392877281475 |
| δG | 1.242708494842 | 0.068593936867 | 0.058971127837 | 1.370273559547 |
| all-band optimum | 1.238905552016 | 0.025603887022 | 0.041482998709 | 1.305992437747 |

OLD 的原 old-count 层交叉费在真 phase primary 中从 adaptive 的 `0.308130419446` 降至 optimum 的 `0.143082211376`；这一统计仍受真实 phase 正交分组影响，不能据此声称已降低移窗后跨旧层全局账单。

| law | 未移窗 phase erasure 总费 | 真 −jh 移窗合 phase 的 OLD² | 真 −jh 移窗合 phase 总费 |
|---|---:|---:|---:|
| adaptive | 2.257709518247 | 2.129365974972 | 2.305852922431 |
| common | 2.447411891710 | 2.129948816211 | 2.453701232925 |
| δG | 2.650558586515 | 2.132640817774 | 2.599656299686 |
| all-band optimum | 2.415742449361 | 2.121938990857 | 2.467105441546 |

冻结旧窗 baseline 能量为 `2.140691118155`。optimum 在真 phase primary 中的 OLD 下降很大，但实际移窗合 phase 的 OLD 只比 adaptive 低约 `0.35%`，完整移窗总费反而更高。这支持停止把本输入的优化结果当作大幅降低旧平台联合载荷的证据；它不证明一切几何效果都等于 phase 重分配，也不排除其他合法输入/选择机制。

## 8. 实跑与一般恢复边界

本角色的轻量核查实际使用指定解释器
`/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python`，Python 3.12.14、NumPy 2.5.4、SciPy 1.18.1。核查只读 N3/R562 JSON 与代码，重建原有限来源云、旧几何 masks、检查 serialized 数据相等与真实移窗残差；**没有调用求解器，没有重复 N1/N3 的主要计算**。精确矩阵代数由 N4 独立负责。

有限原子与 empirical 父权的恢复缺口继承 R562：不把原子当一般 L¹，不把有限中心权当真实 Lebesgue，不把多 q-band 模拟 score 自动当原 `Qg`。本次分解也不是完整 `Cstar` 后验积分的数值化，不能从某一项 OLD² 或 NEW² 给两份 `Qg` 信用。原 `J,d,Erem`、窗损失、全部外层恢复费用和全局 old-sigma posterior 付款均未由此关闭。

**最终 verdict：N3 有限对象的 literal OLD/NEW 与全部规定交叉、两种 phase 处理的实现通过；没有得到一般联合预算或根阶进展。完成本角色有界审计并停止。**

## 9. 续派限定追加：N3.2 的真实质量 discount 平台投影

本节仅核 N3.2 新增 `discounted_mean_platform`，不重核旧分解，不重跑 solver。新增口径以 `/tmp/ccu_r563_nearoptimal.tex` 的实际算子为准。最终冻结 N3 代码 hash 为

`41c262b0e155de9d29aa05eb1c8802ec09a792f4393d373a278e29d0455fb73d`，

与 N3.2 JSON 相符。旧版本 hash/原审计范围保存在 `pre_discount_audit_scope`；旧 matrix/partition/ρ/Gram 不改变。此前 N4 exact 证书不自动覆盖本节新浮点投影字段。

### 9.1 独立算子公式与实现对照

本有限模拟全部 64 个来源在同一源格，`w_s=1/64`，故 **同一个 `W_C=Σ_sw_s=1`**；所有 q-band 的父对同一个场贡献。令 `h=1/8,γ=2`，

\[
(\mathcal DZ)(\sigma)=\sum_j2^{-j/8}
 \sum_{s=1}^{64}\frac1{64}Z_j(x_s,\sigma+j/8).
\]

对一列父动作，令 `c=count,c0=old_count`、`κ=c/c0`、`δ=log2κ−j/8`。其精确贡献是

\[
\omega_p\rho_{pa}\frac1{R_p^{16}}
 \frac{c}{64}2^{-j/8}
 1_{[\log_2(c/64)-j/8,\ \log_2(c/64)-j/8+1]}(\sigma)
\]

\[
=\omega_p\rho_{pa}q_p\,2^{\delta}
 1_{[s_p+\delta,s_p+\delta+1]}(\sigma),\qquad
s_p=\log_2(c0/64).
\tag{D1}
\]

N3 `discounted_platform()` 的 type-0 事件正是 (D1)：它用**实际捕获质量 `c/64`**，并非旧质量 `c0/64`，同时保留真实移窗与 `2^{-j/8}`。代码的 type-3 `D_Z_OLD_capture_only` 只是另行标注的旧捕获诊断，不被拿来冒充 `DZ` 或计算主 projection。所有父/q-band 在同一事件和中，无 band 正交化。

同一源格的旧均值与内窗为

\[
A(\sigma)=\sum_p\omega_pq_p1_{[s_p,s_p+1]}(\sigma),\qquad
A^h(\sigma)=\sum_p\omega_pq_p1_{[s_p+h,s_p+1]}(\sigma).
\]

代码 type-2、type-1 事件分别正确实现这两个对象。由于 `0≤δ<h`，每列 (D1) 的窗包含内窗且 `2^δ≥1`；每父 `Σ_aρ_pa=1`，所以 `DZ≥A^h`。`h<1/3` 下原文给出的 `||A||²≤4||A^h||²` 是合法较粗下界，N3 的 `quarter_old_mean_bound` 没有把必要下界写成上界。

### 9.2 两个 J、S_h 与正交余项

在原来源加权 Hilbert 空间中

\[
(\mathcal D^*F)_j(y,\sigma)=2^{-j/8}F(\sigma-j/8),\quad
\mathcal D\mathcal D^*=W_CS_h\,\mathrm{Id},\quad
S_h=\sum_{j=0}^{J-1}2^{-j/4}.
\]

因此 `P=D*D/(W_CS_h)` 是正交投影，

\[
\|PZ\|^2=\frac{\|DZ\|^2}{W_CS_h},\qquad
\|(I-P)Z\|^2=E-\frac{\|DZ\|^2}{W_CS_h}. \tag{D2}
\]

N3 分别报告两种合法 ambient：

- **输入动作的连续 phase 包络 `J=9`：** 所有状态 `0≤j≤8`。实际观测集合是 `{0,1,2,3,4,5,6,8}`，所以字段名 `actual_full_phase_support` 应理解为连续包络，包含未用的 `j=7`，不是精确支持集合。取该包络仍是合法投影，只是没有用空 phase 进一步收紧。
- **原合同统一包络 `J=29`：** `A_n=1+16ln2`、`γ=2,h=1/8` 给 `1+floor(log2(max(2^(1/8),A_n))/(1/8))=29`。代码额外验证 29 覆盖该输入。它是合同统一 ambient，不能把输入的 `J=9` 当作一般输入已有更小 J 的证明。

两者的 `S_h` 分别为 `4.963910130912434`、`6.243922777352907`，loop 与几何级数闭式的差均 `8.9e−16`。它们对应不同 ambient projection，所以其正交余项不同；都合法，不可混用一个 J 的均值与另一个 J 的余项。代码各 scope 内使用同一 `S_h`，范围正确。

`orthogonal_remainder` 是按 (D2) 从已报 `E` **解析扣除**的浮点数，不是独立直接构造 `PZ` 后得到的 exact 范数证书。理想 Hilbert 恒等式保证非负；当前数值没有认证 log/平方根与事件积分的严格误差界。

### 9.3 独立廉价重构与读数

实际运行指定本机 Python，仅对新增标量投影作廉价交叉核验：用每列真实 receiver 集合长度求质量、原父权和 discount 构造 (D1)，再用**直接窗交集长度矩阵**计算 `||DZ||²`、`<DZ,Ah>`、`||Ah||²`，未调用 N3 的 event-sweep 函数或任何 solver。它与事件积分算法独立，且没有重跑旧 Gram。

| law | 独立 `||DZ||²` | `||Ah||²` | `2<Ah,R>` | `||R||²`，`R=DZ−Ah` |
|---|---:|---:|---:|---:|
| adaptive | 0.7638991439205862 | 0.6049007563628057 | 0.1192074365652407 | 0.0397909509925398 |
| optimum | 0.7728330923622116 | 0.6049007563628057 | 0.1292177207785348 | 0.0387146152208712 |

独立 `||DZ||²` 与 N3 JSON 的差分别 `−4.44e−16`、`−9.99e−16`。`A^h`、capture residual 交叉和平方都被保留，并非只报一个均值下界。极小负的 `pointwise_F_minus_Ah_min`（如 adaptive 的 `−4.2e−17`）及 δ1 的 `norm_F_minus_A_squared≈−2.2e−16` 是浮点取消，不能解释为违反非负理论；当前仍只计浮点核查。

同一输入 `J=9` 下，adaptive/optimum 的投影能量分别

\[
0.1538906071573402,\qquad0.1556903876138780,
\]

反而增加；正交余项分别为 `1.4047029614666748`、`1.1503020501328387`。合同 `J=29` 下投影分别 `0.1223428237599760`、`0.1237736467794454`，结论方向相同。该数字分解支持“本次 E 的减少没有消去这一真实质量均值平台”；不能据此证明余项在一般输入中可控，也不能给平台和 capture 各复用一份 `Qg`。

**N3.2 新增口径 verdict：真实 64-source 质量、统一 `W=1`、全 q-band 字段、实际 shift/discount、`A^h`、两个 ambient J 与正交分解公式通过；只认证该冻结有限浮点口径，没有新增全局付款。最终 hash 如本节首段。完成此次续派并停止。**


---

## ledger.md

Source SHA256: `8dc14db4491f5742b785baaaa9b088951a1725c501cecce35aaf9d59e7b177ce`

# R563 联合旧／新吸收账：一次信用、完整缺损与当前阈值

范围：只处理本轮完整old+new联合付款及回代，不重排R562参数表。保持固定adaptive恢复场及原Cstar；不把新选择律的Eχ、零残窗或其他对象与之混接。原Li、α、来源、ordered父对、所有旧质量层、真实窗/j、first-stop节点和真实核心均冻结。无全局闭合。

## 1. 先合旧／新，再领取一次Qg

原x测度dΞ和共同Li不变。按受计价新接收来源y是否已在旧QB(1)中，精确写

    w=w_old+w_new，Cstar=C_old+C_new，
    L_x=L_old,x+L_new,x，A_x=A_old,x+A_new,x，
    E_x=E_old,x+E_new,x，D_x=D_old,x+D_new,x。

这里old/new是同一个完整Cstar的正分解；输出y的两块虽互斥，其旧source/window(z,σ)支持及旧评分信用仍可重叠，不能各领取完整Qg。

若同一共同a_x>0满足

    R_a,total(B)=∫a_x(w_old+w_new)dΞ≤1，
    V_total=∫(D_old,x+D_new,x)/a_x dΞ≤L_joint(n)W，

则同一Cauchy给

    Cstar²≤P V_total≤Qg L_joint(n)W，
    P=∫a_xE_xdΞ=∫R_a,total dQfr≤Qg。                  (J1)

也可分别选a_old,x、a_new,x，但必须核原父层

    R_a,old(B)+R_a,new(B)≤1；

在(x,old/new)的共同索引空间使用一次Cauchy，仍是(J1)。不得先分别证明P_old≤Qg、P_new≤Qg，再把P_old+P_new写成≤Qg。

如果目前只有各支独立R_a,r≤1、V_r≤L_rW，则合法的联合信用缩放是a_r→θ_r a_r、θ_old+θ_new=1。其来源费用为L_old/θ_old+L_new/θ_new，最优选择给

    L_eff=(sqrt(L_old)+sqrt(L_new))²，
    θ_r=sqrt(L_r)/(sqrt(L_old)+sqrt(L_new))。           (J2)

这是当前独立两证能保证的最好通用合并；不能擅自用L_old+L_new。若一支未付或无限，另一支已付不构成完整目标。若已经直接证明共同总负载，则可用真正V_old+V_new，二者前提不同。

线性收费同样区分：两个完全重叠Qg信用的系数必须相加；只有证明credit_old+credit_new≤Qg（例如原评分密度逐父和≤1）时，才可把两系数的最大值作为总系数。输出来源的old/new分割本身不证明这个评分信用分割。

## 2. 完整粗payer可以付信用侧，未付量仍是后验Dclk

本账独立核一个可用的完整粗基准。固定adaptive的恢复父字段Fhat_B有

    ||Yhat||_∞≤G C_*(G)，∫Fhat_B=t_Bq_BΛ/I_B≤t_Bq_BΛ，
    Λ=2+lnG。

Cstar的每个完整B行由β≤1、同B first-stop反链及H_T⊂T⊂QC(v)，逐项不超过同B的完整Cη Gram行。因此对t_Bq_B>0的原bulk父，

    r_total(B)=∫w_x(B)dΞ
      ≤〈Fhat_B,Yhat〉/(t_Bq_B)
      ≤K，K=G C_*(G)Λ。                               (Row)

旧/新均包含；S=0为零流分支。这个正行比较没有删父对，没有把来源核心压成点，也没有将放大字段称为概率一场。它只用已审真实adaptive场帽及恢复后的实际第一矩。

取允许的共同常数a_x=1/K（K>0），则R_a,total≤1。精确旧后验给

    V_a=K∫D_xdΞ
       =KΣ_i∫[∫r_total(B)k_B(z,σ)dB]/Li(z,σ)dμdσ
       ≤K²Dclk W。                                   (Coarse)

零Li处按0。源格互斥，σ范围是原m_B=q_BR_B^n的整个旧窗跨度Dclk；不能换成单个窗口长度1。故完整信用侧可粗闭合，既不只限new，也不等于已付来源容量。

(Coarse)依然给L_joint=K²Dclk，固定参数下为n量级；old块没有凭新壳Γ_C(1)=0而消失。若用R562的1/(1+sup r)而不是常数1/K，只改有限常数，不移除Dclk。本段是完整粗payer与准确缺口，不称为新根阶进展。

## 3. proof的新精确缺损：代数成立，不能重复消费

在P,V有限（或有限截断且最终费用有控制）时，定义

    S_joint=∫sqrt(E_xD_x)dΞ，
    Λ_def=S_joint−Cstar≥0，Γ_def=PV−S_joint²≥0。

完整恒等式为

    Cstar²=PV−Γ_def−2CstarΛ_def−Λ_def²。               (Def)

这是proof通报公式的独立代数核准。PV、Γ_def以及Λ_def必须使用同一个完整old+new索引及同一个a；不能先把两支各自P扩为Qg，再保留原小Γ作抵扣。

局部Δ_x=E_xD_x−A_x²有精确旧／新拆分

    Δ_x=Δ_old,x+Δ_new,x+Δ_on,x，
    Δ_on=DoDn[(Ao/Do−An/Dn)²+Var_old(Li)+Var_new(Li)]。

方差的概率权分别为(L_r/Li)/D_r·dμdσ；D_r=0时该支量为0、交叉项取0。旧/新在旧来源上可重叠，以上只是同Li下真实混合的方差身份，不需要它们独立或互斥。Δ_on非负，但不等于已获一次W付款。

proof最终补充的显式old/new扣项也成立：由原旧场帽0≤Li≤C0，sqrt(ED)+A≤2C0D，所以

    ell_sep=(2C0)^(-1)∫[DoDn/(Do+Dn)](Ao/Do−An/Dn)²dΞ≤Λ_def，
    (Cstar+ell_sep)²+Γ_def≤PV≤QgV。

零分母分支取0。这里实际来源为旧后验(z,σ)，不把它换成新接收点y。它可直接进入完整母账：

    Qg≤(2JK_w/d²+2Brem/d)W
        +(2J/d²)[sqrt(QgV−Γ_def)−ell_sep]。

这是保留真实负扣项的准确版本；尚无ell_sep足量下界或右边联合净容量的几何控制。它不能仅因非负就算已经消掉Dclk费用。该式仅在有限P,V（或共同有限耗尽上有统一控制）使用；定义Λ_def应优先用∫(sqrt(ED)−A)dΞ、Γ_def用非负双积分，避免全量无穷差。

整体a→c a使P→cP、V→V/c，PV、Γ_def、Λ_def均不变；不能靠标量压小R_a免费减低总费用。并且

    PV−Γ_def=S_joint²

本身独立于a。只报告Γ_def很大可能同时把PV放大，不能算净缺损收益。

一条正确的非循环充分目标是：先以外部几何证明Λ_def≥ell≥0，再证明

    PV−Γ_def≤(sqrt(Qg L(n)W)+ell)²。                  (Def-target)

则Cstar=S_joint−Λ_def≤sqrt(Qg L(n)W)。以QgV替PV是更强但也有效的版本；保留实际P不会白丢已有联合信用。ell不能直接用未知Cstar定义。

若仅知V≤K²DclkW、Γ_def≥0、Λ_def≥0，则(Def)没有根阶增益；要压成L=polylog，定量缺损必须消掉几乎全部Dclk级费用，或使真实联合P·V本来就只有Qg·polylogW。无穷截断中不得用∞−∞作缺损付款。当前没有这样的全输入定量估计。

## 4. 最佳完整吸收，不再分支各自开平方

固定本轮原母账，记

    A=J/d²，B=2Brem/d，d=1−3h，
    C=2A K_w+B，Brem=C0S(1+2G)。

若某个真正完整联合payer/deficit证明Cstar²≤Qg L_jointW，则x=Qg/W满足

    x≤C+2A sqrt(x L_joint)。

最佳直接二次解为

    x≤(sqrt(H)+sqrt(H+C))²，H=A²L_joint。              (Best)

与Young参数t=Aζ∈(0,1)等价，最优

    t*=sqrt(H)/(sqrt(H)+sqrt(H+C))≤1/2。

安全半吸收（无需优化常数）为

    Qg/W≤4A K_w+4A²L_joint+2B。                       (Half)

这个J²L_joint/d⁴费用已经是完整old+new一次信用后的费用，不能为旧、新再各套一个(Half)，也不能把a内信用先分配过又给整体重领Qg。代(Coarse)仍为Qg/W=O(A²K²Dclk)，外层R*/W=O(AK Dclk)；固定参数下仍为n·polylog而非sqrt(n)·polylog。

若作者直接给2Cstar≤ζ·credit+L_linW、credit≤Qg，则仍须Aζ<1；若给Cstar≤a·credit+B_starW，则须2Aa<1。这不是只有ζ<1的普通收缩。

## 5. 另一选择律的signed T−D：信用只可用在完整能量一次

合同里的质量边界选择是另一个ρ，不继承固定adaptive的2K_wW。它的准确能量Eχ=S_old−D(p)+T(p)，零残窗母账为Qg≤mEχ+2E_rem。

因此足够付款必须针对完整组合，例如

    T(p)−D(p)≤ζQg−S_old+L(n)W，mζ<1。

不能既在“旧能量”估计中扣D，又在“新来源”账中把同一D再次当信用。只支付T的正子集也不能删其旧--新/新--旧/新--新其余部分。原恒等下界Eχ≥Q_bulk/m≥(Qg−2E_rem)/m继续表明：相位分摊本身不提供严格可吸收余量。当前没有这个完整signed转移估计。

## 6. 当前结论、外层与实际工具

当前可用的是(Row)给完整粗信用侧、proof的精确联合缺损及(Best)/(Half)的准确门槛。成功必须再有一个确实联合旧σ占用与真实质量增长/方体双源关系的L_joint=polylog容量，或同强(Def-target)。局部新壳中心Γ、单独old/new归一、均值平台/ANOVA方差身份，均未证明这个条件。

外层只作一次

    Q≤Qg/b0²，R*/W≤(2/b0)sqrt(Dclk·Qg/W)。

J、G、h、r、S、Dclk及原入口64(128/119)/(1−32δ_old−16η_old)、τX、初始、删除跳跃、未来被删来源、宽距离、低强度、极端比、全尺度/终端槽全部原样保留。其未给齐的显式上游常数不能由本轮局部缺损重新估成0；不重复R562参数表，也不重新认定这些槽已付。

实际工具：指定本机Python3.12.14/SymPy1.14.0，单次轻量精确核验：独立两payer最优θ的导数残差0、有效容量(sqrt(L_old)+sqrt(L_new))²；局部Δ_on残差0；(Def)残差0；(Best)二次回代残差0；(Half)=4A²L_joint+4AK_w+2B；a整体缩放PV残差0。无浮点误差，无扫描/新求解，无仓库或PDF操作。

完成本轮bounded result。完整付款条件仍未证，无全局闭合；需要作者提供的是联合容量或有定量大小的共同缺损，不是再领取一次Qg或重命名PV−Γ。停止。


---

## screening.md

Source SHA256: `7d7cdf49facf24992c564eb68ad49a97076403ed9abbe4b0fe6ee71e44c23e8d`

# R563：完整旧来源后验中的无损 cube 联合统计与费用筛查

## 0. 范围与先行结论

沿 R563 冻结合同，保留同一完整 C_star、原旧 L_i/α、真实 Lebesgue 父中心、实际恢复 I、所有旧 σ 层、共同来源树/核心和全部有序父对。只审全 joint 统计及候选松弛是否保住 cube 几何收益；不重做 axis/ball 测试、旧 DP/Arb、局部树或标量调和帽。

先独立得到的准确结论：**完整旧后验没有必然抹去 cube 信息；抹去信息的是随后作出的 marginal/平台/同伦列松弛。** 可以明确保留一个可逆的几何联合统计，使所有 old/new 捕获、质量曲线和原权仍能准确计算。但保留信息本身不证明全局预算；本稿不把它记作 root 进展。

## 1. 一个无损且可核的完整 joint 统计

固定旧真实来源/窗口点 (z,σ)，在 L_i(z,σ)>0 上使用原后验

    Π_i(dB|z,σ)=k_B(z,σ)dB/L_i(z,σ)。

对同一个父定义

    u_B(z)=2(B−z)/R_B，
    J_(i,z,σ)=Law_Π(R_B,u_B(z))。

Π 的支撑给 u_B(z)∈[−1,1]^n。此 joint 统计对父几何是无损的，因为

    B=z+(R_B/2)u_B(z)。

所以固定原输入后，R_B、t_B、q_B、m_B、完整 M_B(·)、I_B、原 α_B，以及真实 phase/window、head 和 stop 标记，都是同一个恢复出的 B 的原函数。审计中可把这些标记显式附在 J 上，便于检查它们没有被独立放松。

对新核心实际来源 y，

    v_B(y)=2(B−y)/R_B=u_B(z)+2(z−y)/R_B。

因此 old/new 捕获指标在同一个 joint law 中精确为

    C_old=∏_a1_{|v_a|≤1}，
    C_all(g)=∏_a1_{|v_a|≤g^(1/n)}，
    C_new(g)=C_all(g)−C_old。

完整坐标联合关系以及 R 与坐标的相关性保留；没有因式分解概率。可等价保留 (R,u) 的完整联合 CDF/所有坐标矩形概率，而不能只保每坐标边缘、一个方差、最大坐标的均值或总熵。

这与一般对称凸体的审计区别明确：将体积1单位 cube 换成体积1 K 后，捕获事件改成其 gauge 成员事件，而不再是相同坐标积。这里确有 shape 信息；本轮没有再次使用任何固定轴例。

## 2. mass evolution 必须是同一 capture 图像的边缘

无损不是只保留一组坐标名称。实际输入还强制对每个原父、全部 u∈[1,G] 有

    M_B(u)=∫∏_a1_{|2(B_a−ξ_a)/R_B|≤u^(1/n)} μ(dξ)，
    m_B=M_B(1)，κ_B=M_B/m_B，I_B=∫ω(du)/κ_B(u)。

这些质量与后验的坐标 capture 函数来自同一个原 μ、同一个 B、同一个真实半径，不可把一个有利质量曲线独立贴到另一个有利坐标 law 上。相位/窗、原 α 与 head/stop 也必须留在其原函数图像上。

所有 (z,σ) 条件后验还来自同一个联合测度

    k_B(z,σ)dB μ(dz)dσ，

不是逐旧来源自由选择的一族互不相容条件概率。共同动作 ρ_B 必须跨全部真实来源保持同一个；不能在后验化以后让各 (z,σ) 选择不同动作。

因此一个全 posterior/conditional 松弛若保留上述同父图像和跨来源兼容性，可以无损表达原几何；若把质量、坐标、phase 或行动分别优化，得到的是放大的问题，任何几何 gain 都须另证能回到原共同对象。

## 3. 后验精确式同时保留 OLD 和 NEW，而非只付新壳

沿原 x=(i,C,v,g,T,y) 和 Ξ，写

    w_x(B)=b_x(B)C_all(g;B,y)，
    b_x=M_C(v)Θ_BC head·1_firststopT/[γ I_BM_B(g)]。

同一个 b_x 乘 C_old 与 C_new，分别给完整旧/新部分；两者准确相加为 w_x。b_x 中的 I、窗/phase、head、stop 均不能在拆分后更换。

J_(i,z,σ) 给准确条件量 E_Π w_x；对完整旧来源/窗口再积分，

    C_star=Σ_i∫L_i(z,σ)∫E_Π[w_x]dΞ(x) μ(dz)dσ。

共同收费 a_x 的真实来源账则是

    V_a=Σ_i∫∫a_x^(−1)E_Π[w_x]dΞ(x) μ(dz)dσ。

这解释了完整 posterior 的困难：C_star 的表示带 L_i，而 V_a 没有这个有利权；不能将 1/L_i 丢掉，或仅凭 Π 归一化将旧 σ 的 D_clk 成本改为1。

信用端仍要求对原父

    R_a(B)=∫a_xw_x(B)dΞ(x)≤1  （Q_fr-a.e.），

不是只要求它在每个旧条件后验中的某个平均小。成功所需是一套共同 a_x，同时使该父负载条件与 V_a≤polylog(n)W 成立，或给同强的完整有符号桥。旧和新部分共用这一套信用，不能各吸收一份 Q_g。

## 4. 哪些松弛会删除已保留的 coordinate gain

1. 把 J 的坐标联合成员概率换成边缘概率之积，会删除旧捕获条件与新捕获之间的完整相关性；原 μ 不支持这个独立化。
2. 把精确 new 成员差换成同伦 Γ，则只保中心体积 law t^n。它可支付一项合法粗新壳价，但与一般同伦凸体同型，不能称 cube 特有的多项式完整增益。
3. 对 E_Π w_x 只用≤1 或 `F^+≤min(L_i,SΓ)`，会把新来源位置、原半径和质量相位的联合分布压成无条件平台；保留 L_i 分母虽必要，仍没有支付旧 σ 累计。
4. 先对实际来源/phase作均值投影可以是精确正交分解；但若仅用均值平台的通用粗帽，并把几何全部留在未控制残差，便尚未取得几何上界。丢掉非负残差只能给必要下界，不能变成上界付款。
5. 固定 R 的产品接触导数不能代替可测 R_B 图像下的完整流。其平台、全部质量条件和 source-pair 权必须进入同一次旧/新总积分。

这些是具体信息丢失点，不是禁止使用粗界。若候选能证明丢失的部分另由原 score 支付，粗化仍可合法；本审只拒绝将未付部分自动归零。

## 5. 本轮候选对照状态

### 5.1 pairgeometry：坐标 gain 已进完整 old/new 被积账，尚未进净费用

已读 `/tmp/ccu_r563_pairgeometry.tex`。固定外父 C、动作 g 和两真实来源 y,z，令 s=g^(1/n)、Δ_a=|y_a−z_a|，L_C≤R_B≤U_C。所报

    P_s(Δ/t)=∏_a min{1,((1+s)/2−Δ_a/t)_+}，
    K_Cg(y,z)=P_s(Δ/U_C)+n∫_(L_C)^(U_C)P_s(Δ/t)dt/t

确实控制整个 `z∈Q_B(1), y∈Q_B(g)` 的加权中心积分 `∫R_B^(−n)1_oldz,newy dB`。

核验要点：共同中心集合 `A_t=Q(z,t)∩Q(y,st)` 递增，体积恰为 t^nP_s；捕获中心的最小可行边长为 `max(L_C,2||B−z||∞,2||B−y||∞/s)`。对其倒 n 次方一次 Stieltjes/Tonelli 积分正好给上式。这是可测变 R 的合法完整 old+new 包络，不是固定 R 公式硬套，也没有将两个独立体积帽相乘。

衰减

    K_Cg(y,z)≤(1+2lnD_0)exp{−Σ_a(Δ_a/U_C−(s−1)/2)_+}

保留完整坐标向量，未对 μ 的坐标作独立化。y=z 时 K=1+nln(U_C/L_C)，旧平台没有删掉；g=1 原子也非零。

该稿先在同一个父积分中合并停节点，取得同一个分子 F 的两界

    F≤L_i，F≤S K_Cg。

所以其完整来源账中出现

    1_(Σ_C)(σ) min{1,S K_Cg(y,z)/L_i(z,σ)}。

这一步有明确进展：cube 产品几何确实保留到了同一完整 old/new 后验账，而不是一得到 Γ 就被丢掉。I_C、两个 M_C(v) 分母、绝对 μ(dy)μ(dz)、旧 L_i 分母、Σ_C、共同 a_x 和所有端点都在；行预算对整个 row 而不只是新壳证明，未多发一份 Q_g。

但此包络已放松真实同父图像中的质量/相位/stop权，故不是第1节原对象的无损替代。它是一个合法的较大具体 bill V_pair；`V_pair≤polylog(n)W` 尚未证明，不能由几何核本身直接推出。

**饱和区是决定性的审核点。** 即使 `K≤K_0e^(−E)`，后验也只有

    min{1,Ae^(−E)/L_i}，A=SK_0。

在 `L_i≤Ae^(−E)` 上该值仍为1，坐标指数折扣没有变成任何乘法 saving；仅在 `L_i>A` 的未饱和区才能直接继承 e^(−E) 因子。中间区也必须按同一个 Li 与坐标分离的 joint law 结算。不能先对坐标核求小均值，再把 min 和1/L_i移出期望。

因此对**这份具体松弛 bill**，一个无损保留的统计至少是 `(完整Δ向量, L_C,U_C,g, L_i(z,σ), M_C(v),I_C,s_x,σ)` 在真实源对及外父权下的联合分布，而不是 Δ 的边缘分布。其小 Li/多旧 σ 坏尾仍是完整付款缺项。

作者也正确区分了：已证粗界是实际 `V_a≤K_row(1+K_row)D_clkW`，不是对更大的 V_pair 的已证粗界。当前净母账仍为原粗维数费用，不能将 integrand 级指数折扣登记为一般多项式完整增益。

### 5.2 nearoptimal：完整投影身份不丢信息，现有平台估计不使用 cube 收益

已读 `/tmp/ccu_r563_nearoptimal.tex`。实际质量折扣算子 D_i 的系数和 phase 平移均由真实 κ 强制，且 `D_iZ≥A_i^h`。完整正交分解将 source/phase 坐标信息保留在 `(I−P_i)Z` 及实际捕获残余 R_i；作为身份，它没有抹掉几何，也没有只留均值冒充全场。

然而已得到的是必要下界

    E_χ≥Q_mean,old/(4S_h)，

不是上界。近优场与合法 g=1 场的比较只给 `E_χ≤Q_bulk,old/(1−ε)²`，仍无 source-once 预算。当前 Q_mean,old 的付款只有 C_0SA_nW；若最终要 `E_χ≤ζQ_g+L(n)W`，必须共同支付

    Q_mean,old≤4S_hζQ_g+4S_hL(n)W

以及完整残余/方差。不能给平台近一整份 Q_g 后，再给新捕获复用同一信用。

上述折扣、投影和质量守恒不依赖 cube 特有的交集上界。真正几何仍在 `μ(Q_B∩Q_C)−m_Bm_C/W_i` 的完整有符号 covariance 和后验中；逐父对该差可正可负，不能假设非负。作者未证明这个 signed joint 估计，故当前没有 cube 特有的全费用改善，状态声明正确。

### 5.3 本次边界

本次已完成的几何审核对象是完整 pairgeometry 后验账及 actual nearoptimal 平台/残余分解。core 和 crosslayers 的新稿在本次检查时尚未落盘，不据缺失文本认证其候选；若之后出现不同的决定性全预算步骤，应另行交审。本稿不无限等待或自行扩任务。

## 6. 验收线

需要的结论仍是完整 `C_star²≤Q_gL(n)W` 或等价可吸收式，L(n)固定多对数，并保 J/d²、b_0^(−2)、删除/入口/所有尺度及终端费用。J 归一化、局部维数1/n或一个条件几何容量变小，都必须真正改变这一完整费率后才计为全局增益。

本文件的无损统计是审计和定位缺项的接口，不是一项新容量定理。仅写本文件，不进行额外数值扫描、子代理、仓库修改或 PDF 编译。

## 7. 实际轻量工具记录

实际使用 `/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python`，Python 3.12.14、SymPy 1.14.0，仅检查坐标逆映射和后验饱和的代数表达：

```python
import sympy as s
R,u,z,y=s.symbols('R u z y',real=True,positive=True)
B=z+R*u/2
assert s.simplify(2*(B-y)/R-u-2*(z-y)/R)==0
x=s.symbols('x',positive=True)
closed=(1+x-s.Abs(1-x))/2
assert s.simplify(s.Min(1,x).rewrite(s.Abs)-closed)==0
```

实际输出 margin 残差0，`min(1,x)=(1+x−|1−x|)/2`，其导数为 `(1−sign(x−1))/2`。无浮点误差、无实验或扫描。一般 joint 统计和完整费率判断由上文推导承担，不把这个代数核验当作几何新结果。

## 8. 正式交付判定

无损统计/同源兼容性判别、pairgeometry 的完整坐标中心上包络及实际 bill 适用域、nearoptimal 完整均值/残差身份的费用解释：**PASS**。没有认证 `V_pair≤polylog W`、`V_a≤polylog W`、完整 C_star 吸收或一般根阶目标。

本轮真正保留下来的 shape 信息是完整坐标相对位置与同一旧 Li/质量标记的 joint law；最终必须支付其旧 σ 饱和坏尾和 old/new 平台，而不是再次仅付新壳。交付后停止。
