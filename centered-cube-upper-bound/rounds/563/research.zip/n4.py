"""R563 N4 exact rational OLD/NEW and cross-band arithmetic certificate.
No optimization. Rounded serialized feature entries are interpreted as exact.
"""
from fractions import Fraction as F
from collections import defaultdict
from pathlib import Path
import argparse,json,hashlib,platform,sys,time

def canon(x):return hashlib.sha256(json.dumps(x,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def dot(a,b):
    if len(a)>len(b):a,b=b,a
    return sum((v*b.get(k,F(0)) for k,v in a.items()),F(0))
def gram(o,n):return (dot(o,o),dot(o,n),dot(n,n))
def serialized(t):return dict(OLD=str(t[0]),OLD_NEW_ordered=str(t[1]),NEW=str(t[2]),total=str(t[0]+2*t[1]+t[2]))
def display(t):return dict(OLD=float(t[0]),twice_OLD_NEW=float(2*t[1]),NEW=float(t[2]),total=float(t[0]+2*t[1]+t[2]))
def grouped(fields,total):
    diag=tuple(sum((gram(*v)[i] for v in fields.values()),F(0)) for i in range(3))
    cross=tuple(total[i]-diag[i] for i in range(3))
    assert all(x>=0 for x in cross)
    assert tuple(diag[i]+cross[i] for i in range(3))==total
    return dict(diagonal_exact=serialized(diag),ordered_cross_exact=serialized(cross),diagonal_display=display(diag),ordered_cross_display=display(cross),by_group_diagonal={str(k):serialized(gram(*v)) for k,v in sorted(fields.items())})
def full_pair_audit(fields,author):
    keys=sorted(fields);assert keys==author['keys']
    oo=[];nn=[];on=[];tt=[];maxdiff=F(0)
    for i in keys:
        ro=[];rn=[];ron=[];rt=[]
        for j in keys:
            x=dot(fields[i][0],fields[j][0]);y=dot(fields[i][1],fields[j][1]);z=dot(fields[i][0],fields[j][1]);w=dot(fields[i][1],fields[j][0]);t=x+y+z+w
            ro.append(x);rn.append(y);ron.append(z);rt.append(t)
            ii,jj=keys.index(i),keys.index(j)
            for value,name in [(x,'OLD_gram'),(y,'NEW_gram'),(z,'OLD_NEW_ordered_gram'),(t,'total_gram')]:
                maxdiff=max(maxdiff,abs(value-F(float(author[name][ii][jj]))))
        oo.append(ro);nn.append(rn);on.append(ron);tt.append(rt)
    assert all(oo[i][j]==oo[j][i] and nn[i][j]==nn[j][i] and tt[i][j]==tt[j][i] for i in range(len(keys)) for j in range(len(keys)))
    return dict(keys=keys,OLD_gram=[[str(v) for v in r] for r in oo],NEW_gram=[[str(v) for v in r] for r in nn],OLD_NEW_ordered_gram=[[str(v) for v in r] for r in on],total_gram=[[str(v) for v in r] for r in tt],maximum_author_float_entry_error_exact=str(maxdiff),maximum_author_float_entry_error_display=float(maxdiff))

def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--n3',type=Path,default=Path(__file__).resolve().parent/'n3.json');parser.add_argument('--optimizer',type=Path,default=None);args=parser.parse_args();start=time.perf_counter()
    n3=json.load(open(args.n3));op=args.optimizer or Path(n3['input_optimizer']['path']);original=json.load(open(op))
    mat=n3['matrix_csc'];assert mat==original['all_band_feature_matrix_csc'];nr,nc=mat['shape'];data=[F(float(x)) for x in mat['data']];idx=mat['indices'];ptr=mat['indptr'];old=n3['is_old_data'];rows=n3['row_keys'];states=original['summary']['action_states'];parents=original['summary']['frozen_parent_records'];offsets=n3['offsets']
    assert rows==original['all_band_feature_row_keys'] and offsets==original['summary']['offsets']
    assert len(old)==len(data)==len(idx)==ptr[-1] and len(states)==nc and min(data)>=0
    assert len(ptr)==nc+1 and ptr[0]==0 and all(ptr[j]<=ptr[j+1] for j in range(nc)) and all(0<=r<nr for r in idx)
    initial={s['parent']:set(s['receiver_atoms']) for s in states if s['kind']=='initial'}
    assert len(initial)==len(parents)
    for j,s in enumerate(states):
        p=s['parent'];assert n3['column_parent'][j]==p and n3['column_parent_band'][j]==parents[p]['band'] and n3['column_old_count'][j]==parents[p]['old_count']
        captured=set(s['receiver_atoms']);assert initial[p]<=captured and len(captured)==s['count']
        if s['kind']=='initial':assert len(initial[p])==parents[p]['old_count']
        ratio=F(s['count'],parents[p]['old_count'])**8;phase=s['phase'];assert F(2)**phase<=ratio<F(2)**(phase+1)
        for h in range(ptr[j],ptr[j+1]):
            receiver,rowphase,_=rows[idx[h]]
            assert receiver in captured and rowphase==phase
            assert bool(old[h])==(receiver in initial[p])
    results={};full_selected={}
    for law,rawrho in n3['rhos'].items():
        rho=[F(float(x)) for x in rawrho];assert len(rho)==nc and min(rho)>=0
        O=defaultdict(F);N=defaultdict(F);V=defaultdict(F);bands={};layers={}
        for j,p in enumerate(rho):
            band=n3['column_parent_band'][j];layer=n3['column_old_count'][j]
            if band not in bands:bands[band]=(defaultdict(F),defaultdict(F))
            if layer not in layers:layers[layer]=(defaultdict(F),defaultdict(F))
            for h in range(ptr[j],ptr[j+1]):
                r=idx[h];v=data[h]*p;which=0 if old[h] else 1
                (O if old[h] else N)[r]+=v;bands[band][which][r]+=v;layers[layer][which][r]+=v;V[r]+=v
        assert all(V[r]==O[r]+N[r] for r in V)
        t=gram(O,N);assert dot(V,V)==t[0]+2*t[1]+t[2]
        assert t[1]*t[1]<=t[0]*t[2]
        au=n3['results'][law];errs=[abs(t[0]-F(float(au['OLD']))),abs(t[2]-F(float(au['NEW']))),abs(2*t[1]-F(float(au['twice_OLD_NEW']))),abs(dot(V,V)-F(float(au['total'])))]
        residual=max(abs(sum(rho[l:u])-1) for l,u in zip(offsets[:-1],offsets[1:]))
        results[law]=dict(total_exact=serialized(t),display=display(t),old_new_partition_exact=True,probability_simplex_residual_exact=str(residual),by_qband=grouped(bands,t),by_old_count=grouped(layers,t),maximum_author_float_summary_error_exact=str(max(errs)),maximum_author_float_summary_error_display=float(max(errs)))
        if law=='optimum':
            full_selected[law]=dict(by_qband=full_pair_audit(bands,au['by_qband']),by_old_count=full_pair_audit(layers,au['by_old_mass_layer']))
    out=dict(python=sys.executable,python_version=platform.python_version(),script_sha256=hashlib.sha256(open(__file__,'rb').read()).hexdigest(),input_n3_sha256=hashlib.sha256(open(args.n3,'rb').read()).hexdigest(),matrix_canonical_sha256=canon(mat),input_optimizer_sha256=hashlib.sha256(open(op,'rb').read()).hexdigest(),input_checks=dict(shape=[nr,nc],nnz=len(data),source_mask_phase_flags_checked=len(data),actions_checked=nc,parent_count=len(parents),all_OLD_NEW_mask_and_phase_checks_passed=True),results=results,full_pair_selected_exact=full_selected,elapsed_seconds=time.perf_counter()-start,scope='Exact arithmetic of serialized rounded feature matrix/action masks only. No optimizer solve; no ideal geometry, Lebesgue quadrature, true alpha or complete source-budget certificate.')
    print(json.dumps(out,indent=2))
if __name__=='__main__':main()
