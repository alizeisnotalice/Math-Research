"""R563 N3: one frozen finite OLD/NEW decomposition; no optimizer invocation."""
import os
for name in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:os.environ[name]='2'
import argparse,json,hashlib,time,resource,platform,math
from pathlib import Path
import numpy as np
import scipy
from scipy import sparse

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def gram(o,n):return [[float(o@o),float(o@n)],[float(n@o),float(n@n)]]
def stats(o,n):
    g=gram(o,n);return dict(gram_old_new=g,OLD=g[0][0],NEW=g[1][1],twice_OLD_NEW=2*g[0][1],total=float((o+n)@(o+n)))
def grouped(O,N,rho,groups):
    keys=sorted(set(groups));oo=[];nn=[]
    for k in keys:
        p=rho*(groups==k);oo.append(np.asarray(O@p).ravel());nn.append(np.asarray(N@p).ravel())
    oo=np.array(oo);nn=np.array(nn);tot=oo+nn
    og=oo@oo.T;ng=nn@nn.T;on=oo@nn.T;gg=tot@tot.T
    return dict(keys=[int(k) for k in keys],OLD_gram=og.tolist(),NEW_gram=ng.tolist(),OLD_NEW_ordered_gram=on.tolist(),total_gram=gg.tolist(),total=float(gg.sum()),diagonal=float(np.trace(gg)),cross_group_fee=float(gg.sum()-np.trace(gg)),OLD_cross_group_fee=float(og.sum()-np.trace(og)))
def collapse(keys,phase_erased=False):
    ix={};rr=[]
    for z,j,s in keys:
        key=(z,s) if phase_erased else (z,j,s)
        if key not in ix:ix[key]=len(ix)
        rr.append(ix[key])
    return sparse.csr_matrix((np.ones(len(rr)),(rr,np.arange(len(rr)))),shape=(len(ix),len(rr)))
def shifted_energy(rho,parents,states,initial,shift):
    # Explicit window sweep; only this diagnostic uses the common -j*h shift.
    fields=[{},{}]
    for p,s in zip(rho,states):
        if p==0:continue
        b=s['parent'];r=parents[b];old=initial[b];left=math.log2(s['count']/64)-(s['phase']*.125 if shift else 0.)
        amp=p*r['weight']/r['R']**16
        for z in s['receiver_atoms']:
            fields[0 if z in old else 1].setdefault(z,[]).extend([(left,amp),(left+1,-amp)])
    E=np.zeros((2,2))
    for z in set(fields[0])|set(fields[1]):
        events=sorted((x,c,t) for t in range(2) for x,c in fields[t].get(z,[]));v=np.zeros(2);last=events[0][0]
        for x,c,t in events:E+=np.outer(v,v)*((x-last)/64);v[t]+=c;last=x
    return dict(gram_old_new=E.tolist(),OLD=float(E[0,0]),NEW=float(E[1,1]),twice_OLD_NEW=float(2*E[0,1]),total=float(E.sum()))
def discounted_platform(rho,parents,states,energy):
    # All sources in a single fixed source cell C, W=1; all qbands retained.
    h=.125;events=[];residuals=[]
    def add(t,l,u,a):events.extend([(l,t,a),(u,t,-a)])
    for r in parents:
        left=math.log2(r['old_count']/64);massamp=r['weight']*r['q0']
        add(1,left+h,left+1,massamp);add(2,left,left+1,massamp)
    for prob,s in zip(rho,states):
        r=parents[s['parent']];j=s['phase'];kap=s['count']/r['old_count'];delta=math.log2(kap)-j*h;residuals.append(delta)
        left=math.log2(s['count']/64)-j*h
        amp=prob*r['weight']/r['R']**16*2**(-j*h)
        add(0,left,left+1,amp*s['count']/64)
        add(3,left,left+1,amp*r['old_count']/64)
    events.sort();v=np.zeros(4);G=np.zeros((4,4));areas=np.zeros(4);last=events[0][0];mindiff=0.;maxdiff=0.;i=0
    while i<len(events):
        x=events[i][0];width=x-last
        if width>0:
            G+=np.outer(v,v)*width;areas+=v*width;mindiff=min(mindiff,float(v[0]-v[1]));maxdiff=max(maxdiff,float(v[0]-v[1]))
        while i<len(events) and events[i][0]==x:
            _,t,a=events[i];v[t]+=a;i+=1
        last=x
    J=max(s['phase'] for s in states)+1
    scopes={}
    for name,jj in [('actual_full_phase_support',J),('contract_ambient_J29',29)]:
        assert jj>=J;Sh=sum(2**(-2*j*h) for j in range(jj))
        scopes[name]=dict(J=jj,S_h=Sh,mean_projection_energy=float(G[0,0]/Sh),inner_platform_lower_bound=float(G[1,1]/Sh),quarter_old_mean_bound=float(G[2,2]/(4*Sh)),orthogonal_remainder=float(energy-G[0,0]/Sh))
    return dict(source_cell='one fixed C containing all 64 atoms; W_C=1, every frozen parent and qband included',field_order=['D_Z_true_capture','A_h_inner_old_window','A_full_old_window','D_Z_OLD_capture_only'],gram=G.tolist(),integrals=areas.tolist(),pointwise_F_minus_Ah_min=mindiff,pointwise_F_minus_Ah_max=maxdiff,residual_delta_range=[min(residuals),max(residuals)],platform=dict(norm_Ah_squared=float(G[1,1]),twice_inner_Ah_R=float(2*(G[1,0]-G[1,1])),norm_R_squared=float(G[0,0]-2*G[0,1]+G[1,1]),norm_F_squared=float(G[0,0]),norm_A_squared=float(G[2,2]),norm_F_minus_A_squared=float(G[0,0]-2*G[0,2]+G[2,2])),bounds=scopes)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--optimizer',default='/tmp/ccu_r562_optimizer.json');ap.add_argument('--output',default=str(Path(__file__).with_suffix('.json')));args=ap.parse_args();st=time.perf_counter()
    x=json.load(open(args.optimizer));su=x['summary'];states=su['action_states'];parents=su['frozen_parent_records'];csc=x['all_band_feature_matrix_csc'];F=sparse.csc_matrix((csc['data'],csc['indices'],csc['indptr']),shape=csc['shape']);keys=x['all_band_feature_row_keys'];cols=np.repeat(np.arange(F.shape[1]),np.diff(F.indptr));cp=np.array([s['parent'] for s in states]);initial={s['parent']:set(s['receiver_atoms']) for s in states if s['kind']=='initial'}
    isold=np.array([keys[row][0] in initial[cp[col]] for row,col in zip(F.indices,cols)]);O=F.copy();O.data=F.data*isold;N=F.copy();N.data=F.data*(~isold);assert np.array_equal((O+N).toarray(),F.toarray())
    rhos={k:[] for k in ['adaptive','common','two','delta1','deltaG']}
    for s in states:
        r=parents[s['parent']];kap=s['count']/r['old_count'];I=r['I'];kind=s['kind'];l=s['g_lower'];u=s['g_upper']
        if kind=='initial':pp=[1/I,0,.5,1,0]
        elif kind=='terminal':pp=[1/(kap*I),.5,.25,0,1]
        else:pp=[math.log(u/l)/(kap*I),1/l-1/u,.5*(1/l-1/u),0,0]
        for k,v in zip(rhos,pp):rhos[k].append(v)
    rhos['optimum']=x['rho_all_band_optimum'];rhos['banddiag_optimum']=x['rho_band_diagonal_optimum'];bands=np.array([parents[b]['band'] for b in cp]);layers=np.array([parents[b]['old_count'] for b in cp]);C=collapse(keys,True);results={}
    oldwindow=np.asarray(F@np.array(rhos['delta1'])).ravel()
    for law,pp in rhos.items():
        rho=np.array(pp);o=np.asarray(O@rho).ravel();n=np.asarray(N@rho).ravel();res=stats(o,n);res['phase_erased']=stats(C@o,C@n);res['phase_cross_fee']=res['phase_erased']['total']-res['total'];res['old_window_baseline_energy']=float(oldwindow@oldwindow);res['OLD_deviation_from_frozen_old_window_squared']=float((o-oldwindow)@(o-oldwindow));res['OLD_inner_frozen_old_window']=float(o@oldwindow)
        res['by_old_mass_layer']=grouped(O,N,rho,layers);res['by_qband']=grouped(O,N,rho,bands);res['low_high_qband']=grouped(O,N,rho,(bands>=0).astype(int));res['low_high_definition']='0: qband k<0 (q<1); 1: k>=0 (q>=1); fixed descriptive split, no parents removed'
        phase_keys=sorted({k[1] for k in keys});phase_o=np.array([C@(o*np.array([k[1]==j for k in keys])) for j in phase_keys]);phase_n=np.array([C@(n*np.array([k[1]==j for k in keys])) for j in phase_keys]);res['phase_pair_gram_after_erasure']=dict(keys=phase_keys,OLD_gram=(phase_o@phase_o.T).tolist(),NEW_gram=(phase_n@phase_n.T).tolist(),OLD_NEW_ordered_gram=(phase_o@phase_n.T).tolist(),total_gram=((phase_o+phase_n)@(phase_o+phase_n).T).tolist())
        res['by_phase']={str(j):stats(o[np.array([k[1]==j for k in keys])],n[np.array([k[1]==j for k in keys])]) for j in sorted({k[1] for k in keys})}
        res['common_minus_jh_shift_phase_erased']=shifted_energy(rho,parents,states,initial,True)
        res['discounted_mean_platform']=discounted_platform(rho,parents,states,res['total'])
        res['unshifted_sweep_check']=shifted_energy(rho,parents,states,initial,False)
        assert abs(res['unshifted_sweep_check']['total']-res['phase_erased']['total'])<1e-11
        assert abs(res['by_qband']['total']-res['total'])<1e-11
        results[law]=res
    payload=dict(schema='R563.N3.2',pre_discount_audit_scope=dict(code_sha256='b665c86ff4502c168c370424315840b8496e20923db86c52789763416e977b8a',json_sha256='a851d443dac6cbc017cc54c3023bc30dd1a799c70aaf68857f7c98e03324892d',unchanged='matrix, partition, rho and all previous result fields; discounted_mean_platform added outside N4/feature-audit scope'),scope='Frozen finite quadrature and empirical training alpha; no solve, no Lebesgue/general-dimension claim',input_optimizer=dict(path=args.optimizer,sha256=sha(args.optimizer)),code_sha256=sha(__file__),versions=dict(python=platform.python_version(),numpy=np.__version__,scipy=scipy.__version__),definition=dict(OLD='F entries whose source lies in same parent initial receiver_atoms; actual action masswindow and phase unchanged',NEW='remaining same-column same-row entries',primary='all qbands collapsed, true phase direct sum; every OLD/NEW and crossband Gram retained',shift_diagnostic='Separate common -j/8 shift, then erase phase; residual window shift delta=log2(count/oldcount)-j/8 retained, never reset to zero'),matrix_csc=csc,row_keys=keys,column_parent=cp.tolist(),column_parent_band=bands.tolist(),column_old_count=layers.tolist(),is_old_data=isold.tolist(),offsets=x['offsets'],rhos=rhos,results=results,old_window_baseline=stats(oldwindow,np.zeros_like(oldwindow)),cost=dict(total_seconds=time.perf_counter()-st,maxrss_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,optimization_runs=0,parent_count=len(parents),states=len(states),nnz=F.nnz))
    Path(args.output).write_text(json.dumps(payload,indent=2));print(json.dumps(dict(cost=payload['cost'],summary={k:{v:r[v] for v in ['OLD','NEW','twice_OLD_NEW','total','phase_cross_fee']} for k,r in results.items()}),indent=2))
if __name__=='__main__':main()
