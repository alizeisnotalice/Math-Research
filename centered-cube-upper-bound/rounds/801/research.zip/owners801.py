"""Exact cube slicing and rigorous scalar checks for the R801 geometric estimate."""
from argparse import ArgumentParser
from fractions import Fraction as Q
from hashlib import sha256
from math import factorial
from pathlib import Path
import json
import platform
import sys

import flint
from flint import arb, ctx

ctx.prec = 384


def aq(x):
    return arb(x.numerator) / x.denominator


def exact_cube(n):
    h = 1 + Q(1, 32*n)
    d = Q(1, 32)
    omega = Q(n, 16)
    length = h-1+d
    threshold = omega/2
    assert n*d*d == omega/64
    assert (n-1)*length < threshold < n*length
    assert d > h-1 and d < 2
    # After selecting the sign, each coordinate has only one positive interval.
    # Below threshold in even one coordinate's zero atom leaves no tail.
    deficiency = n*length-threshold
    assert 0 < deficiency < length
    from_simplex = (deficiency/(2*h))**n / factorial(n)
    active_probability = length/(2*h)
    from_conditioning = active_probability**n*(deficiency/length)**n/factorial(n)
    assert from_simplex == from_conditioning
    expectation = n*length**2/(4*h)
    assert expectation <= n*(d*d+(h-1)**2)/(2*h)
    mgf = 1 + (3*((aq(length)/3).exp()-1)-aq(length))/(2*aq(h))
    exact_chernoff = n*mgf.log()-aq(threshold)/3
    assert aq(from_simplex).log() < exact_chernoff < -aq(omega)/8
    volume_tail = aq(from_simplex).log()
    return dict(n=n, diagnostic_omega=str(omega), absolute_shift=str(d), container_half_side=str(h),
                actual_squared_shift=str(n*d*d), true_expected_sum=str(expectation),
                exact_tail_formula="(n*(h-1+d)-omega/2)^n / ((2*h)^n * n!)",
                exact_tail_fraction_sha256=sha256(str(from_simplex).encode()).hexdigest(),
                log_exact_tail=volume_tail.str(18), log_exact_mgf_bound=exact_chernoff.str(18),
                log_coarse_bound=str(-omega/8))


def dimension(q):
    n = arb(2)**q
    N = n+2
    ell = N.log()
    rlower = n.sqrt()*ell**2
    olower = ell**4/(8192**2)
    oupper = (rlower+1)**2/(arb(8192)**2*n)
    # H <= C' Htest. All tests below are stated for Htest, without C'.
    Htest = 1+(n.sqrt()+1)/ell**2
    Hlog = Htest.log()
    Asource = Hlog+(arb(2)).log()-rlower/4096
    Atail = Hlog+ell-olower/8
    # log(M N exp(-omega/8)) bounded below despite both ceilings.
    wrong = rlower/4096+ell-oupper/8
    assert wrong > 0
    def signed(x):
        assert (x < 0) or (x > 0)
        return "negative" if x < 0 else "positive"
    return dict(n_power_of_two=q, logN=ell.str(16), lower_omega=olower.str(16),
                upper_log_Htest_M_alpha=Asource.str(16),
                upper_log_Htest_N_tail=Atail.str(16),
                upper_log_Htest_N_tail_sign=signed(Atail),
                lower_log_wrong_M_N_tail=wrong.str(16),
                difference_if_tail_multiplied_by_M="strictly positive lower log bound",
                concrete_radius_gt_one=(olower > 64),
                exact_net_dimension_eligible=(rlower/(16384*ell)>1))


def weighted_deletions():
    # Finite paths each have two actual small labels. A frozen outside event is removed
    # first; the remaining proportional deletion is charged to missing endpoint mass.
    paths=[("a","a",Q(8)),("a","b",Q(1)),("b","c",Q(8)),("c","c",Q(1,2))]
    original=[True]*len(paths)
    live=[False,True,False,True]
    theta=Q(1,8)
    def masses(mask):
        out={i:Q(0) for i in "abc"}
        for (u,v,m),on in zip(paths,mask):
            if on:
                out[u]+=m
                out[v]+=m
        return out
    A=masses(original)
    losses=[]
    for u in ("a","b","c"):
        J=masses(live)[u]
        if not 0 < J < theta*A[u]:
            continue
        paid=Q(0)
        for i,(p,q,m) in enumerate(paths):
            if live[i] and u in (p,q):
                live[i]=False
                paid+=m
        assert paid<=J and J <= theta/(1-theta)*(A[u]-J)
        losses.append(dict(u=u,prior=str(A[u]),current=str(J),removed=str(paid)))
    removed=sum((m for (_,_,m),on in zip(paths,live) if not on),Q(0))
    self_fee=sum(Q(row["removed"]) for row in losses)
    assert losses and self_fee <= 2*theta/(1-theta)*removed
    return dict(ordered_paths=[(u,v,str(m)) for u,v,m in paths], deletions=losses,
                true_event_mass_removed=str(removed), self_fee=str(self_fee),
                coefficient=str(2*theta/(1-theta)))


def main():
    args=ArgumentParser(description=__doc__)
    g=args.add_mutually_exclusive_group(required=True)
    g.add_argument("--check",type=Path)
    g.add_argument("--output",type=Path)
    opt=args.parse_args()
    res=dict(python=sys.version.split()[0],flint=flint.__version__,precision_bits=ctx.prec,
             platform=platform.machine(),exact_owner_slices=[exact_cube(n) for n in (64,128,256)],
             actual_parameter_checks=[dimension(q) for q in (32,128,512,1024,2048,4096,8192)],
             removal=weighted_deletions(),
             scope="Cube-volume slices and scalar interval enclosures. These finite checks do not supply an L1 input realizing the full stopped flow.")
    encoded=json.dumps(res,sort_keys=True,ensure_ascii=False,indent=2)+"\n"
    if opt.output:
        opt.output.write_text(encoded)
    else:
        assert opt.check.read_text()==encoded
        print("byte-identical")
    for record in res["exact_owner_slices"]:
        print(record["n"],record["true_expected_sum"],record["log_exact_tail"])
    print("signs",[(z["n_power_of_two"],z["upper_log_Htest_N_tail_sign"]) for z in res["actual_parameter_checks"]])
    print("deletions",res["removal"]["self_fee"],res["removal"]["true_event_mass_removed"])


if __name__=="__main__":
    main()
