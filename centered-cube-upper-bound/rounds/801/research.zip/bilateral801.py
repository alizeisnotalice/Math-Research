#!/usr/bin/env python3
"""Bilateral payment from separate parent-only true-source transports."""
import argparse
from collections import defaultdict
from fractions import Fraction as F
from hashlib import sha256
import importlib.util
from itertools import product
import json
from pathlib import Path
import platform


ROWS_SHA="04bbd600cd68bd2bb371559590a1902b97a345c02404ffc759a1147fb4b2bae9"
X0=(F(0),F(1,4))
X1=(F(1,2),F(3,4))
XR=(F(13,4),F(7,2))
Y0=(F(2),F(9,4))
Y1=(F(5,2),F(11,4))
YR=(F(9,4),F(5,2))
Z0=(F(-1),F(-3,4))
Z1=(F(-1,2),F(-1,4))
ZR=(F(17,4),F(9,2))


def rows_for_parent(parent,swaps,cells,mu_cell,admissible,base):
    """Preassigned scatter on real own-source cells, with true Lebesgue cap."""
    allowed=[i for i,x in enumerate(cells) if base.inside(x,parent)]
    assert set(admissible)<=set(allowed)
    rows={i:{i:F(1)} for i in allowed}
    full_target=defaultdict(F)
    touched=set()
    for first,second,rate in swaps:
        assert 0<rate<1 and base.inside(first,parent) and base.inside(second,parent)
        S,T=[[i for i in allowed if base.inside(cells[i],B)] for B in (first,second)]
        mS,mT=[base.total(mu_cell[i] for i in V) for V in (S,T)]
        assert mS==mT>0 and not set(S).intersection(T) and not touched.intersection(S+T)
        touched.update(S+T)
        for src,dst in ((S,T),(T,S)):
            mixed={i:(1-rate)*mu_cell[i]/mS for i in src}
            mixed.update({i:rate*mu_cell[i]/mS for i in dst})
            for a in src:
                rows[a]=mixed.copy()
    for a,row in rows.items():
        assert base.total(row.values())==1 and all(i in allowed for i in row)
        for i,x in row.items():
            full_target[i]+=mu_cell[a]*x
    assert all(full_target[i]==mu_cell[i] for i in allowed)
    actual_input={a:rows[a] for a in sorted(admissible)}
    out=defaultdict(F)
    for a,row in actual_input.items():
        for i,m in row.items():
            out[i]+=mu_cell[a]*m
    assert base.total(out.values())==base.total(mu_cell[a] for a in actual_input)
    assert all(w<=mu_cell[i] for i,w in out.items())
    B=max((w/base.length(cells[i]) for i,w in out.items()),default=F(0))
    assert B>0 and all(w<=B*base.length(cells[i]) for i,w in out.items())
    return actual_input,B,out


def shares_from_two_roles(p,q):
    reverse=min(q,1-p)
    residual=1-p-reverse
    assert residual==max(F(0),1-p-q)
    return p,reverse,residual


def outer_add(M,v,w,m):
    for i,a in enumerate(v):
        if a:
            for j,b in enumerate(w):
                if b:
                    M[i][j]+=m*a*b


def blank():
    return [[F(0)]*3 for _ in range(3)]


def paid_resources(projections,reference,edges,plans,source_caps,cells,cell_mu,owner_parts,base):
    attempts=defaultdict(F)
    per_actor_paid=defaultdict(F)
    charge=defaultdict(F)
    actor_input=defaultdict(F)
    recv_paid=defaultdict(F)
    recv_naive=defaultdict(F)
    recv_given=defaultdict(F)
    for (t,u,a,h),mass in projections.items():
        assert 0<mass<=reference[t,u,a,h]
        edge=edges[t,u,a]
        weights=edge["directions"]
        receiver=(u,h)
        recv_given[receiver]+=mass
        recv_paid[receiver]+=mass*(weights[0]+weights[1])
        recv_naive[receiver]+=mass*base.total(edge["predicted"])
        for role,actor in enumerate(edge["actors"]):
            actor_input[actor,a]+=mass
            for j,rate in plans[actor][a].items():
                attempts[actor,j]+=mass*rate
            for j,rate in edge["actual_payment_points"][role].items():
                assert j in edge["intersection_atoms"]
                per_actor_paid[actor,j]+=mass*rate
                charge[j]+=mass*rate

    exposure={i:max((w/cell_mu[a] for (z,a),w in actor_input.items() if z==i),default=F(0))
              for i in plans}
    fixed_input=defaultdict(F)
    for (t,u,a,h),mass in reference.items():
        for actor in edges[t,u,a]["actors"]:
            fixed_input[actor,a]+=mass
    fixed_exposure={i:max((w/cell_mu[a] for (z,a),w in fixed_input.items() if z==i),default=F(0))
                    for i in plans}
    assert all(exposure[i]<=fixed_exposure[i] for i in plans)
    envelopes=[]
    for j,box in enumerate(cells):
        attempt=base.total(attempts[i,j] for i in plans)
        paid=base.total(per_actor_paid[i,j] for i in plans)
        pointwise=base.total(exposure[i]*source_caps[i][0]
                            for i in plans if j in source_caps[i][1])*base.length(box)
        original_capacity=base.total(fixed_exposure[i]*source_caps[i][0]
                                     for i in plans if j in source_caps[i][1])*base.length(box)
        assert 0<=paid==charge[j]<=attempt<=pointwise<=original_capacity
        for i in plans:
            B=source_caps[i][0]
            assert 0<=per_actor_paid[i,j]<=attempts[i,j]<=exposure[i]*B*base.length(box)
        if attempt:
            envelopes.append(dict(actual_price_cell=box,earned_physical_source_charge=paid,
                                  attempted_on_common_source=attempt,
                                  proved_common_Lebesgue_capacity=pointwise,
                                  fixed_unmarked_source_currency=original_capacity))
    true_cap=defaultdict(F)
    for (t,u,a,h),w in reference.items():
        true_cap[u,h]+=w
    witnesses=[]
    for key,m in true_cap.items():
        assert 0<=recv_paid[key]<=recv_given[key]<=m
        u,h=key
        if recv_naive[key]>m:
            witnesses.append(dict(old=u,actual_owner_cell=owner_parts[u][h],actual_uncapped_direction_sum=recv_naive[key],
                                  clipped_actual_receiving_payment=recv_paid[key],
                                  physical_original_capacity=m))
    assert base.total(charge.values())==base.total(recv_paid.values())
    return dict(original_pooled_receiving_mass=base.total(true_cap.values()),
                admitted_pooled_receiving_mass=base.total(recv_given.values()),
                actual_paid_common_source_and_receiver=base.total(charge.values()),
                density_of_real_input_per_parent_exposure=exposure,
                fixed_unmarked_input_exposure_caps=fixed_exposure,
                source_capacity_witnesses=envelopes,
                actual_receiving_cap_witnesses=witnesses)


def test(name,T,U,shares,amp,changes,base):
    parents=T+U
    nT=len(T)
    E=[base.owner(A,s) for A,s in zip(T,shares)]+[base.owner(A,F(1)) for A in U]
    ordered=sorted(E)
    assert all(x[1]<y[0] for x,y in zip(ordered,ordered[1:]))
    m=list(map(base.length,parents))
    v=list(map(base.length,E))
    mu=lambda a:base.real_mass(a,amp)
    assert list(map(mu,parents))==m
    boundaries=sorted({*base.SOURCE,*(F(i,4) for i in range(-32,33)),
                       *(x for A in parents for x in A),
                       *(x for switches in changes.values() for S,T,_ in switches for A in (S,T) for x in A)})
    atoms=list(zip(boundaries,boundaries[1:]))
    cell_mu=list(map(mu,atoms))
    assert all(w>0 and w/base.length(a) in (1-amp,1+amp) for w,a in zip(cell_mu,atoms))
    owner_parts=[[(R[0],base.point(R)),(base.point(R),R[1])] for R in E[nT:]]
    neighbor={}
    admissible=defaultdict(set)
    for t,u in product(range(nT),range(len(U))):
        g=nT+u
        I=base.clip(T[t],U[u])
        full=mu(I)
        if not full or m[g]>=m[t]:
            continue
        price_cells=[a for a,A in enumerate(atoms) if base.inside(A,I)]
        assert base.total(cell_mu[a] for a in price_cells)==full
        K=full/(m[t]*m[g])
        neighbor[t,u]=I,full,K,price_cells
        admissible[t].update(price_cells)
        admissible[g].update(price_cells)
    d=[base.total(v[nT+u]*k for (j,u),(_,_,k,_) in neighbor.items() if j==t) for t in range(nT)]
    assert min(d)>0
    plans,caps,profiles={},{},[]
    for i,A in enumerate(parents):
        source,B,output=rows_for_parent(A,changes.get(i,[]),atoms,cell_mu,admissible[i],base)
        plans[i]=source
        caps[i]=(B,set(output))
        row_density=[(atoms[j],output[j]/base.length(atoms[j])) for j in sorted(output)]
        assert B==max(y for _,y in row_density)
        profiles.append(dict(parent=i,own_true_input_mu=base.total(cell_mu[a] for a in source),
                             full_parent_mu=m[i],max_actual_Lebesgue_density_B=B,
                             actual_output_density_by_cell=row_density,physical_swaps=changes.get(i,[])))

    edges={}
    witnesses={}
    diagonal_misread={}
    for (t,u),(I,whole,K,price_cells) in neighbor.items():
        g=nT+u
        allow=set(price_cells)
        for a in price_cells:
            hits=[{b:q for b,q in plans[i][a].items() if b in allow} for i in (t,g)]
            p,q=[base.total(row.values()) for row in hits]
            cp,cm,r=shares_from_two_roles(p,q)
            granted=[hits[0],{b:s*cm/q for b,s in hits[1].items()} if q else {}]
            assert [base.total(row.values()) for row in granted]==[cp,cm]
            edges[t,u,a]=dict(actors=(t,g),intersection_atoms=sorted(allow),predicted=(p,q),
                              directions=(cp,cm,r),actual_payment_points=granted)
            if (t,u)==(0,0) and (p,q) in ((F(1,2),F(1,2)),(F(1,4),F(1,4))):
                key="two_halves_cover_actual_edge" if p==F(1,2) else "aligned_simultaneous_miss"
                if key not in witnesses:
                    paid_locations=[[dict(true_matched_price_box=atoms[b],conditional_mass=s)
                                    for b,s in sorted(row.items())] for row in granted]
                    assert all(base.inside(l["true_matched_price_box"],I) for row in paid_locations for l in row)
                    witnesses[key]=dict(t=t,u=u,actual_observed_price=atoms[a],
                                        plus=p,minus=q,real_residual=r,
                                        wrong_independent_failure_product=(1-p)*(1-q),
                                        paid_locations=paid_locations,
                                        true_original_arm_mass_on_this_cell=v[t]*v[g]*K*cell_mu[a]/whole)
        if (t,u)==(0,0):
            plus=base.total(cell_mu[a]*edges[t,u,a]["predicted"][0] for a in price_cells)/whole
            minus=base.total(cell_mu[a]*edges[t,u,a]["predicted"][1] for a in price_cells)/whole
            rem=base.total(cell_mu[a]*edges[t,u,a]["directions"][2] for a in price_cells)/whole
            diagonal_misread=dict(actual_competing_edge_mean_residual=rem,
                                   naive_positive_part_after_averaging=max(F(0),1-plus-minus),
                                   mixed_marginal_failure_product=(1-plus)*(1-minus),
                                   mean_directional_coverages=[plus,minus])
    assert witnesses["two_halves_cover_actual_edge"]["real_residual"]==0
    if name!="initial":
        assert witnesses["aligned_simultaneous_miss"]["real_residual"]==F(1,2)
        assert diagonal_misread["actual_competing_edge_mean_residual"]>diagonal_misread["naive_positive_part_after_averaging"]

    clean_projection=defaultdict(F)
    screened_projection=defaultdict(F)
    per_middle=[]
    matrices=[blank(),blank()]
    wrong_screen_residual=F(0)
    for t in range(nT):
        actual=[]
        groups=defaultdict(lambda:[F(0)]*3)
        full_joint_marg=[F(0)]*3
        for (j,u),(_,whole,K,pcs) in neighbor.items():
            if t!=j:
                continue
            g=nT+u
            for a,h in product(pcs,range(2)):
                frac=base.length(owner_parts[u][h])/v[g]
                mass=v[g]*K*cell_mu[a]/whole*frac
                assert mass==cell_mu[a]*base.length(owner_parts[u][h])/(m[t]*m[g])
                charge=edges[t,u,a]["directions"]
                sig=(base.inside(atoms[a],X1),h)
                mark=(t,u,a,h)
                actual.append((mark,mass,charge,sig))
                for i,p in enumerate(charge):
                    full_joint_marg[i]+=mass*p
                    groups[sig][i]+=mass*p
        factor=v[t]/d[t]
        assert base.total(mass for _,mass,_,_ in actual)==d[t]
        complete,screened=blank(),blank()
        for A,B in product(actual,repeat=2):
            aa,x,ca,xa=A
            bb,y,cb,xb=B
            value=factor*x*y
            outer_add(complete,ca,cb,value)
            clean_projection[aa]+=value
            clean_projection[bb]+=value
            if xa==xb:
                outer_add(screened,ca,cb,value)
                screened_projection[aa]+=value
                screened_projection[bb]+=value
        independent,independent_screen=blank(),blank()
        outer_add(independent,full_joint_marg,full_joint_marg,factor)
        for block in groups.values():
            outer_add(independent_screen,block,block,factor)
        assert complete==independent and screened==independent_screen
        all_raw=base.total(w for row in complete for w in row)
        screen_total=base.total(w for row in screened for w in row)
        assert all_raw==v[t]*d[t] and 0<screen_total<all_raw
        r0=base.total(screened[2])
        r1=base.total(row[2] for row in screened)
        wrong=r0*r1/screen_total
        wrong_screen_residual+=wrong
        for M,Q in zip(matrices,(complete,screened)):
            for i,j in product(range(3),repeat=2):
                M[i][j]+=Q[i][j]
        per_middle.append(dict(t=t,d=d[t],raw_law=complete,genuinely_screened_law=screened,
                               false_product_of_screened_residual_marginals=wrong,
                               true_screened_both_residual=screened[2][2]))
    raw_total=base.total(w for row in matrices[0] for w in row)
    mark_total=base.total(w for row in matrices[1] for w in row)
    for (t,u,a,h),w in clean_projection.items():
        g=nT+u
        assert w==2*v[t]*base.length(owner_parts[u][h])*cell_mu[a]/(m[t]*m[g])
    assert base.total(clean_projection.values())==2*raw_total
    assert base.total(screened_projection.values())==2*mark_total
    resources={
        "before_path_screen":paid_resources(clean_projection,clean_projection,edges,plans,caps,
                                            atoms,cell_mu,owner_parts,base),
        "after_genuine_path_screen":paid_resources(screened_projection,clean_projection,edges,plans,caps,
                                                   atoms,cell_mu,owner_parts,base),
    }
    assert resources["before_path_screen"]["actual_receiving_cap_witnesses"]
    assert matrices[0][0][1]>0 and matrices[0][1][0]>0
    assert matrices[1][0][1]>0 and matrices[1][1][0]>0
    if name!="initial":
        assert matrices[1][2][2]>0 and matrices[1][2][2]!=wrong_screen_residual
    raw_both_paid=base.total(matrices[0][i][j] for i,j in product(range(2),repeat=2))
    marked_both_paid=base.total(matrices[1][i][j] for i,j in product(range(2),repeat=2))
    return dict(stage=name,real_nonuniform_source_amplitude=amp,physical_middle_parents=T,physical_old_parents=U,
                actual_disjoint_owner_intervals=E,whole_old_degrees=d,aligned_price_atoms=atoms,
                actual_parent_only_transport_marginals=profiles,
                real_true_edge_witnesses=witnesses,aggregate_checks_on_one_true_edge=diagonal_misread,
                matrix_labels=["first_direction_paid","second_direction_paid_after_clipping","same_edge_residual"],
                by_central=per_middle,original_clean_matrix=matrices[0],joint_screened_matrix=matrices[1],
                clean_both_arms_paid_weight=raw_both_paid,screened_both_arms_paid_weight=marked_both_paid,
                screened_actual_both_arms_residual=matrices[1][2][2],
                screened_wrong_independent_product_by_middle=wrong_screen_residual,
                common_source_and_receiver_checks=resources)


def suite(base):
    T=[base.iv(0,4),base.iv("1/4","17/4"),base.iv("1/2","9/2")]
    U=[base.iv(-1,1),base.iv(3,5),base.iv("9/8","25/8")]
    first={0:[(X0,Y0,F(1,2))],2:[(X0,Z0,F(1,2))]}
    pressure={0:[(X0,Y0,F(1,2)),(X1,Y1,F(3,4))],
              3:[(X0,Z0,F(1,2)),(X1,Z1,F(3,4))]}
    large={0:[(X0,Y0,F(1,2)),(X1,Y1,F(3,4)),(XR,YR,F(3,4))],
           3:[(X1,base.iv("3/2","7/4"),F(1,2))],
           5:[(X0,Z0,F(1,2)),(X1,Z1,F(3,4))],
           6:[(XR,ZR,F(2,3))]}
    return [
      test("initial",[T[0],T[2]],[U[0],base.iv("5/2","9/2")],
           [F(1),F(3,4)],F(1,4),first,base),
      test("pressure",T,U,[F(1),F(3,4),F(1,2)],F(1,2),pressure,base),
      test("expanded",T+[base.iv("3/8","27/8"),base.iv("7/8","31/8")],
           U+[base.iv("1/2",3),base.iv(2,"9/2")],
           [F(1),F(3,4),F(1,2),F(7,8),F(5,8)],F(3,4),large,base),
    ]


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--rows-dir",type=Path,default=Path(__file__).resolve().parent)
    action=p.add_mutually_exclusive_group()
    action.add_argument("--output",type=Path)
    action.add_argument("--check",type=Path)
    args=p.parse_args()
    dep=args.rows_dir/"rows798.py"
    assert sha256(dep.read_bytes()).hexdigest()==ROWS_SHA
    spec=importlib.util.spec_from_file_location("rows798",dep)
    base=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(base)
    data=suite(base)
    out=dict(runtime=dict(python=platform.python_version(),architecture=platform.machine()),
             dependency={"rows798.py":ROWS_SHA},command="python -B bilateral801.py --check bilateral801.json",
             scope=dict(precision="standard-library exact Fraction",
                        source="true compact positive periodic piecewise-constant source on [-8,8]",
                        parent_kernels="one nonanticipative matrix per physical father and old price; equal true-mass block swaps preserve the full own source, then only actual admissible incoming prices are retained",
                        Leb_capacity="every physical target cell quadrature is split at the density phases and the true output-to-Lebesgue ratios give finite exact B_i",
                        common_capacity="both actual arms and both directions share each physical price cell, with a common fixed Lebesgue cap from unmarked input exposure. Each original owner slice has the pooled pre-screen receiving projection as its fixed diagnostic capacity.",
                        selection="direction plus is used first, then direction minus only up to the true same-edge residue; actual sent price is in both fathers",
                        path_screen="the old prices share the same X1-or-complement flag and their actual receiver halves agree",
                        range="true one-dimensional finite diagnostic; no high-dimensional screening asserted"),
             stages=data)
    text=json.dumps(out,sort_keys=True,indent=2,default=str)+"\n"
    if args.output:
        args.output.write_text(text)
    if args.check:
        assert args.check.read_text()==text
    if args.output or args.check:
        for x in data:
            print(x["stage"],"both residual true/wrong",x["screened_actual_both_arms_residual"],
                  x["screened_wrong_independent_product_by_middle"],
                  "same edge remaining",x["aggregate_checks_on_one_true_edge"]["actual_competing_edge_mean_residual"])
        if args.check:
            print("byte-identical")
    else:
        print(text,end="")


if __name__=="__main__":
    main()
