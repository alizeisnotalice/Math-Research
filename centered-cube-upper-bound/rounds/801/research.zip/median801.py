#!/usr/bin/env python3
"""Exact coordinate median, true cap, and ordered pair-distance certificate."""
import argparse
from fractions import Fraction as F
from itertools import product
import json
from pathlib import Path
import platform


def total(xs):
    return sum(xs,F(0))


def cube(center,r):
    return tuple((F(x)-r,F(x)+r) for x in center)


def meet(A,B):
    return tuple((max(a,c),min(b,d)) for (a,b),(c,d) in zip(A,B))


def distance_1d(y,I):
    return max(F(0),I[0]-y,y-I[1])


def point_distance(y,B):
    return total(distance_1d(x,I) for x,I in zip(y,B))


def pair_gap(I,J):
    return max(F(0),I[0]-J[1],J[0]-I[1])


def true_cap(y,T,tau,radii,omega):
    raw=[point_distance(y,B) for B in T]
    picks=[i for i,(value,r) in enumerate(zip(raw,radii)) if value<=omega*r]
    return dict(point=y,true_distances=raw,normalized_distances=[v/s for v,s in zip(raw,radii)],
                qualifying_labels=picks,actual_weight=total(tau[i] for i in picks))


def compute(name,center,s0,defs,omega):
    n=len(center)
    A=cube(center,s0)
    T=[cube(q,r) for q,r,w in defs]
    tau=[w for q,r,w in defs]
    radii=[r for q,r,w in defs]
    assert all(len(q)==n and r>s0 and w>0 for q,r,w in defs)
    J=total(tau)
    s_min=min(radii)
    rate=[t/s for t,s in zip(tau,radii)]
    clipped=[meet(A,B) for B in T]
    assert all(a<=b for B in clipped for a,b in B)

    certificates=[]
    y=[]
    summed_square=F(0)
    paired_layers=F(0)
    for j,(alo,ahi) in enumerate(A):
        I=[B[j] for B in clipped]
        knots=sorted({alo,ahi,*(x for c in I for x in c)})
        integrals=[]
        for lo,hi in zip(knots,knots[1:]):
            p=(lo+hi)/2
            L={i for i,(l,h) in enumerate(I) if l>p}
            R={i for i,(l,h) in enumerate(I) if h<p}
            l=total(rate[i] for i in L)
            h=total(rate[i] for i in R)
            l_raw=total(tau[i] for i in L)
            h_raw=total(tau[i] for i in R)
            assert not (L&R)
            lift=hi-lo
            pair=2*l_raw*h_raw*lift
            assert pair>=2*s_min*s_min*min(l,h)**2*lift
            integrals.append(dict(interval=(lo,hi),left_rate=l,right_rate=h,left_tau=l_raw,
                                  right_tau=h_raw,integrated_min=min(l,h)*lift,
                                  integrated_min_square=min(l,h)**2*lift,ordered_pair_contribution=pair))
        minimum=total(w["integrated_min"] for w in integrals)
        square=total(w["integrated_min_square"] for w in integrals)
        pairs=total(w["ordered_pair_contribution"] for w in integrals)
        endpoint_values=[total(u*distance_1d(v,B[j]) for u,B in zip(rate,T)) for v in knots]
        assert minimum==min(endpoint_values)
        argmin=[p for p,value in zip(knots,endpoint_values) if value==minimum]
        med=(argmin[0]+argmin[-1])/2
        assert alo<=med<=ahi
        assert total(u*distance_1d(med,B[j]) for u,B in zip(rate,T))==minimum
        assert minimum*minimum<=(ahi-alo)*square
        y.append(med)
        summed_square+=square
        paired_layers+=pairs
        certificates.append(dict(axis=j,clipped_intervals=I,knots=knots,tail_intervals=integrals,
                                 median_interval=(argmin[0],argmin[-1]),median_value=med,
                                 independent_endpoint_costs=endpoint_values,axis_min=minimum,
                                 ordered_pair_integral=pairs))

    D=total(c["axis_min"] for c in certificates)
    assert D==total(a*point_distance(y,B) for a,B in zip(rate,T))
    assert all(point_distance(y,B)==point_distance(y,I) for B,I in zip(T,clipped))
    # Independent full-grid verification using the original (unclipped) parents.
    candidate_grid=list(product(*(r["knots"] for r in certificates)))
    enumerated=min(total(a*point_distance(z,B) for a,B in zip(rate,T)) for z in candidate_grid)
    assert enumerated==D

    selected=true_cap(y,T,tau,radii,omega)
    cap_at_y=selected["actual_weight"]
    assert J<=cap_at_y+D/omega
    if cap_at_y<J:
        assert J-cap_at_y<D/omega
    reference_center=true_cap(center,T,tau,radii,omega)
    pairs={}
    directed=F(0)
    for i,j in product(range(len(T)),repeat=2):
        axes=[pair_gap(p,q) for p,q in zip(T[i],T[j])]
        assert axes==[pair_gap(p,q) for p,q in zip(clipped[i],clipped[j])]
        contribution=tau[i]*tau[j]*total(axes)
        directed+=contribution
        if i<j and contribution:
            pairs[f"{i},{j}"]=dict(axes=axes,directed_two_orders=2*contribution)
    assert directed==paired_layers==total(x["directed_two_orders"] for x in pairs.values())
    assert n*2*s0*summed_square>=D*D
    lower=D**2*s_min**2/(n*s0*J**2)
    G=directed/J**2
    assert G>=2*s_min*s_min*summed_square/J**2>=lower
    stats=dict(stage=name,dimension=n,physical_small_A=A,small_radius=s0,
               true_original_central_boxes=T,clip_to_small=clipped,
               s_i=radii,tau=tau,omega=omega,J=J,coordinate_certificates=certificates,
               original_grid_candidates=len(candidate_grid),D_true=D,independent_grid_D=enumerated,
               exact_cap_at_weighted_median=selected,cap_at_small_center=reference_center,
               J_minus_actual_median_cap=J-cap_at_y,proved_J_upper_at_this_median=cap_at_y+D/omega,
               ordered_nonzero_pairs=pairs,ordered_tau_product_pair_sum=directed,
               true_independent_pair_G=G,ordered_pair_via_layer_integral=paired_layers,
               first_bound_using_squared_tail=2*s_min*s_min*summed_square/(J*J),
               target_G_lower_bound=lower,total_integral_of_squared_min_tail=summed_square)
    if name=="common":
        assert D==G==0 and cap_at_y==J
    if name=="pressure":
        assert tuple(y)==(F(-1,2),F(1,2))
        assert D==F(5,3) and G==F(120,121) and lower==F(50,121)
        assert cap_at_y==F(5,2) and reference_center["actual_weight"]==J
    if name=="expanded":
        assert D>0 and G>lower and n==4 and len(set(radii))>2
    return stats


def clip_polygon(vertices,a,b,c):
    """Clip counterclockwise polygon by a*x+b*y <= c."""
    v=[]
    prior=vertices[-1]
    f0=a*prior[0]+b*prior[1]-c
    for x in vertices:
        f=a*x[0]+b*x[1]-c
        if (f0>0)!=(f>0):
            s=f0/(f0-f)
            point=tuple(l+s*(r-l) for l,r in zip(prior,x))
            assert a*point[0]+b*point[1]==c
            v.append(point)
        if f<=0:
            v.append(x)
        prior,f0=x,f
    return v


def polygon_area(vertices):
    return abs(total(x*b-y*a for (x,y),(a,b) in zip(vertices,vertices[1:]+vertices[:1])))/2


def slanted_overlap(pressure):
    R=((-F(1,2),F(1,2)),(-F(1,2),F(1,2)))
    (a,b),(c,d)=R
    square=[(a,c),(b,c),(b,d),(a,d)]
    hats=[]
    for i in (0,1):
        I=pressure["true_original_central_boxes"][i]
        slope=[]
        constant=F(0)
        for (r0,r1),(l,h) in zip(R,I):
            if r1<=l:
                slope.append(F(-1))
                constant+=l
            elif r0>=h:
                slope.append(F(1))
                constant-=h
            else:
                assert l<=r0<=r1<=h
                slope.append(F(0))
        k=pressure["omega"]*pressure["s_i"][i]-constant
        assert all(constant+total(g*x for x,g in zip(y,slope))==point_distance(y,I) for y in square)
        hats.append((*slope,k))
    assert hats==[(F(-1),F(-1),F(1,4)),(F(1),F(1),F(1,4))]
    single=[clip_polygon(square,*p) for p in hats]
    common=clip_polygon(single[0],*hats[1])
    overlap=polygon_area(common)
    assert all(point_distance(v,pressure["true_original_central_boxes"][i])<=
               pressure["omega"]*pressure["s_i"][i] for v in common for i in (0,1))
    assert overlap==1-2*(F(3,4)**2/2)==F(7,16)
    assert [polygon_area(v) for v in single]==[F(23,32)]*2
    return dict(actual_test_square=R,linear_forms_of_true_hats=hats,actual_intersection_vertices=common,
                true_area_of_each_cut=[polygon_area(v) for v in single],
                true_overlap_area=overlap,independent_triangle_area_check=F(7,16))


def oriented(center,r,signature):
    """Place a true central cube by specifying which edge cuts the small father."""
    out=[]
    for x,(sign,bound) in zip(center,signature):
        out.append(x+F(bound)+F(sign)*r if sign else x)
    return tuple(out)


def suite():
    first=[
       ((1,0),F(5,4),F(1)),
       ((F(-3,4),F(1,2)),F(5,4),F(2)),
       ((0,F(-3,4)),F(9,8),F(3,2)),
    ]
    pressure=[((2,2),F(3,2),F(1)),((-2,-2),F(3,2),F(1)),
              ((-2,2),F(3,2),F(1,2)),((2,-2),F(3,2),F(1,4))]
    center=(F(1,4),F(-1,2),F(1,2),F(3,4))
    directions=[
      (F(13,8),F(3,2),((1,"1/2"),(1,"1/2"),(1,"1/4"),(0,0))),
      (F(2),F(2),((-1,"-1/2"),(-1,"-1/4"),(-1,"-3/4"),(0,0))),
      (F(7,4),F(5,4),((1,"3/4"),(-1,"-1/2"),(0,0),(1,"1/2"))),
      (F(9,4),F(7,8),((-1,"-3/4"),(1,"3/4"),(1,"1/2"),(-1,"-1/2"))),
      (F(5,2),F(9,4),((0,0),(1,1),(-1,"-1/2"),(1,"3/4"))),
      (F(15,8),F(2,3),((1,"1/4"),(0,0),(1,"3/4"),(-1,-1))),
    ]
    expanded=[(oriented(center,r,signature),r,w) for r,w,signature in directions]
    examples=[compute("common",(0,0),F(1),first,F(1,2)),
              compute("pressure",(0,0),F(1),pressure,F(5,6)),
              compute("expanded",center,F(3,2),expanded,F(2,3))]
    examples[1]["opposite_slanted_cuts"]=slanted_overlap(examples[1])
    equality=compute("ordered_factor_equality",(0,),F(1),
                     [((F(-5,2),),F(3,2),F(1)),((F(5,2),),F(3,2),F(1))],F(3,4))
    assert equality["D_true"]==F(4,3)
    assert equality["true_independent_pair_G"]==equality["target_G_lower_bound"]==1
    return examples,equality


def main():
    p=argparse.ArgumentParser(description=__doc__)
    act=p.add_mutually_exclusive_group()
    act.add_argument("--output",type=Path)
    act.add_argument("--check",type=Path)
    args=p.parse_args()
    cases,equality=suite()
    data=dict(runtime=dict(python=platform.python_version(),architecture=platform.machine()),
              command="python -B median801.py --check median801.json",
              scope=dict(precision="standard-library exact Fraction",
                         geometry="true physical small cube and strictly larger real central cubes; boundary intersections are allowed",
                         median="coordinate lower and upper tail integration and independent Cartesian grid minimization on the original cubes",
                         cap="actual cap computed at this median, so also a valid lower bound on the global maximum M",
                         G="distance of two independent central labels with replacement, normalized by J^2",
                         clipping="positive coordinate gaps exactly unchanged by clipping both parents to the real small father"),
              stages=cases,sharp_ordered_pair_factor_probe=equality)
    text=json.dumps(data,sort_keys=True,indent=2,default=str)+"\n"
    if args.output:
        args.output.write_text(text)
    if args.check:
        assert args.check.read_text()==text
    if args.output or args.check:
        for s in cases:
            print(s["stage"],"D",s["D_true"],"G",s["true_independent_pair_G"],
                 "bound",s["target_G_lower_bound"],"at-median cap",s["exact_cap_at_weighted_median"]["actual_weight"])
        if args.check:
            print("byte-identical")
    else:
        print(text,end="")


if __name__=="__main__":
    main()
