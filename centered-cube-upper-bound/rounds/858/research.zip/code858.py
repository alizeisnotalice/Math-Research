"""R858 true physical-angle collision with ordered scale enlargement."""

from fractions import Fraction as F
from itertools import combinations, product
from math import prod
import sys


N=4
DELTA=F(1,4)
EPS=F(1,32768)
PRED={"A":(F(1),)*N,"B":(F(3,2),)*N,"C":(F(1),F(6),F(1),F(1))}
COMMON_I=frozenset((0,1))


def axes(x):
    return (F(x),)*N if not isinstance(x,tuple) else tuple(map(F,x))


def overlap(A,B):
    return tuple((max(a,c),min(b,d)) for (a,b),(c,d) in zip(A,B))


def side_length(a):
    return a[1]-a[0]


def window(tails,r,upper):
    if upper:
        return tuple((x-2*r,x) for x in axes(tails))
    return tuple((x,x+2*r) for x in axes(tails))


def center(B):
    return tuple((a+b)/2 for a,b in B)


def contains_core(B,x,e):
    return all(a+e<p<b-e for (a,b),p in zip(B,x))


def expanded(B,r):
    return tuple((a-DELTA*r,b+DELTA*r) for a,b in B)


def separated(A,B):
    bad=[]
    for i,((a,b),(c,d)) in enumerate(zip(A,B)):
        gap=max(a-d,c-b)
        assert abs(gap)>2*EPS
        if gap>0:
            bad.append(i)
    return frozenset(bad)


def error_axes(A,z,tol):
    bad=[]
    for i,((a,b),p) in enumerate(zip(A,z)):
        outside=max(F(0),a-p,p-b)
        assert abs(outside-tol)>EPS
        if outside>tol:
            bad.append(i)
    return frozenset(bad)


def setup():
    # (ID, physical radius window base, actual middle upper faces,
    # actual small-left lower faces, selected left/right contact, menu, weight).
    templates=(
        ("A_s",1,"9/8","33/32","left","A",2),
        ("A_m",4,"5/4","15/16","left","A",1),
        ("A_l",16,"1/2","7/16","left","A",3),
        ("B_s",1,"47/32","45/32","left","B",1),
        ("B_m",4,"25/16","47/32","right","B",3),
        ("B_l",16,"7/4","13/8","left","B",2),
        ("C_s",1,"19/16","67/64","left","C",1),
        ("C_l",16,("25/4","25/4","11/16","11/16"),(6,6,"5/8","5/8"),"left","C",1),
        ("Z",4,"1/4","1/8","left",None,2),
    )
    rows={}
    all_boxes=set()
    factors={}
    for name,R,t,u,cut,tag,weight in templates:
        R=F(R)
        mid=window(t,R,True)
        left=window(u,R,False)
        right=window(-3*R/2,R,False)  # true center -R/2, contains w=0
        assert all(side_length(I)==2*R for B in (mid,left,right) for I in B)
        assert all(contains_core(B,axes(0),2*EPS) for B in (mid,right))
        private=overlap(mid,left)
        assert all(side_length(I)>4*EPS for I in private)
        assert contains_core(mid,center(private),2*EPS) and contains_core(left,center(private),2*EPS)
        C=overlap(mid,left if cut=="left" else right)
        assert all(side_length(I)>2*EPS for I in C)
        bad=(error_axes(C,PRED[tag],DELTA*R/4) if tag is not None else frozenset())
        if tag is None:
            assert all(len(error_axes(C,y,DELTA*R/4))>1 for y in PRED.values())
        else:
            assert len(bad)<=1
        for B in (mid,left,right):
            assert all(-64+EPS<a<b<64-EPS for a,b in B)
            all_boxes.add(B)
        assert EPS<R/(32*N)
        # Raw one-row geometry for the fixed w fibre. A frozen positive
        # multiplier <=1 realizes each displayed row weight; the direction
        # of comparison is not imposing the full original R813 Gamma.
        core=(2*EPS)**N
        private_mass=(2*EPS)**N
        factors[name]=core*private_mass/(2*R)**(2*N)
        rows[name]=(R,mid,left if cut=="left" else right,bad,tag,F(weight),cut)
    centres=[center(B) for B in all_boxes]
    assert all(max(abs(x-y) for x,y in zip(a,b))>2*EPS for a,b in combinations(centres,2))
    unit=min(factors[name]/row[5] for name,row in rows.items())
    assert all(0<unit*row[5]/factors[name]<=1 for name,row in rows.items())
    # sigma=mu=1 on [-64,64]^N: actual box masses are their volumes,
    # and a fixed positive common w core lies in all mids and rights.
    print("Uniform true source; three physical octaves [1,2),[4,8),[16,32).")
    print("  Fixed common w cube halfwidth",EPS,"; disjoint positive receiving cores",len(centres),
          "; one raw weight unit",unit)
    print("  Row (physical R, chosen small father, physical label, bad axes, raw weight units):")
    for name,(R,mid,u,bad,tag,weight,cut) in rows.items():
        print("   ",name,R,cut,tag,tuple(sorted(bad)),weight)
    return rows


def compare(rows):
    different=[]
    for (name,a),(other,b) in combinations(rows.items(),2):
        if a[4] is None or a[4]!=b[4] or a[0]==b[0]:
            continue
        if a[0]<b[0]:
            name,other,a,b=other,name,b,a
        R,mid,u,bad,_,_,_=a
        r,mid_small,u_small,bad_small,_,_,_=b
        forward=separated(expanded(u,R),mid_small)
        reverse=separated(expanded(u_small,r),mid)
        plain=separated(u,mid_small)
        common=bad|bad_small
        assert forward<=common<=COMMON_I
        assert DELTA*(R+r)/4+2*EPS<DELTA*R
        different.append((name,other,plain,forward,reverse,common))
    assert len(different)==7
    ledger={(a,b):(f0,f1,rev,I) for a,b,f0,f1,rev,I in different}
    assert ledger["A_l","A_s"]==(frozenset(),frozenset(),frozenset(range(N)),frozenset())
    assert ledger["B_l","B_s"]==(frozenset(range(N)),frozenset(),frozenset(),frozenset())
    assert ledger["C_l","C_s"][1]==COMMON_I
    print("Orders printed large -> small; axes are zero-based.")
    print("  (pair, unexpanded forward separation, augmented forward, augmented reverse, common deletion):")
    for a,b,c,d,e,f in different:
        print("   ",(a,b),tuple(sorted(c)),tuple(sorted(d)),tuple(sorted(e)),tuple(sorted(f)))


def collisions(rows,h,split):
    total=sum(r[5] for r in rows.values())
    law={}
    accepted=F(0)
    for R,mid,u,bad,tag,weight,cut in rows.values():
        if tag is not None and len(bad)<=h:
            label=(R,tag) if split else tag
            law[label]=law.get(label,F(0))+weight/total
            accepted+=weight/total
    collision=sum(x*x for x in law.values())
    assert collision>=accepted**2/len(law)
    by_pairs=F(0)
    for a,b in product(rows.values(),repeat=2):
        if a[4] is None or a[4]!=b[4] or len(a[3])>h or len(b[3])>h:
            continue
        if split and a[0]!=b[0]:
            continue
        by_pairs+=a[5]*b[5]/total**2
    assert by_pairs==collision
    print("h",h,"; labels", "window-and-index" if split else "same physical point",
          "; p",accepted,"; m",len(law),"; collision",collision,"; p^2/m",accepted**2/len(law))
    return collision


def collision_table(rows):
    independent=collisions(rows,0,False)
    adapted=collisions(rows,1,False)
    split=collisions(rows,1,True)
    assert (independent,adapted,split)==(F(9,32),F(19,64),F(15,128))
    total=sum(r[5] for r in rows.values())
    oriented=sum(a[5]*b[5] for a,b in product(rows.values(),repeat=2)
                 if a[4] is not None and a[4]==b[4] and a[0]>b[0])/total**2
    assert 2*oriented==adapted-split and oriented==F(23,256)
    print("  Ordered larger->smaller part of iid shared-label mass",oriented,
          "; either distinct-scale ordering",2*oriented)
    print("  All these ordered collided pairs pass on axes outside one fixed preselected I=(0,1).")


if __name__=="__main__":
    print("Python",sys.version.split()[0],"| Fraction exact, no sampling.")
    model=setup()
    compare(model)
    collision_table(model)
    print("All exact assertions passed. True positive boxes and local conditional geometry.")
