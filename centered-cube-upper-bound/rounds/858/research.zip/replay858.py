"""Verify the R858 release and reproduce each experiment in a separate clean directory."""
import argparse
from hashlib import sha256
from io import BytesIO
import json
import os
from pathlib import Path
import subprocess
import sys
from tempfile import TemporaryDirectory
from zipfile import ZipFile


PARENTS = {
    "814": "891d8cbcbd35537e6abc18c938e53b1b4f300327357c24c8d14a51a46ad5e190",
    "856": "16496077ed6ce4e48816dfb70d93a8251885db6ff03e033a3109eaa6e2f13fbb",
    "857": "8ef43e82e2905f5f95f685eda948fbee0a5b447ae68b0866708ebc0fb448e07f",
}
# These tuples list the archives read by each experiment. R857 supplies the mathematical/Git parent.
RUNS = {
    "reprice858": ("814", "856"),
    "collision858": ("814",),
    "boxspan858": (),
    "code858": (),
    "transversal858": (),
}
MEMBERS = {"REPORT.tex", "replay858.py"} | {
    f"{name}.{extension}" for name in RUNS for extension in ("py", "txt")
}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(data):
    return sha256(data).hexdigest()


def distinct_keys(pairs):
    fields = dict(pairs)
    require(len(fields) == len(pairs), "duplicate manifest key")
    return fields


def read_release(data):
    with ZipFile(BytesIO(data)) as archive:
        names = archive.namelist()
        require(len(names) == len(MEMBERS) + 1 and set(names) == MEMBERS | {"MANIFEST.json"},
                "unexpected, duplicate or missing archive member")
        require(archive.testzip() is None, "archive CRC mismatch")
        manifest = json.loads(archive.read("MANIFEST.json"), object_pairs_hook=distinct_keys)
        files = {name: archive.read(name) for name in MEMBERS}
    require(set(manifest) == {"round", "parents", "sha256"} and type(manifest["round"]) is int
            and manifest["round"] == 858 and manifest["parents"] == PARENTS,
            "unexpected manifest or parent hashes")
    require(manifest["sha256"] == {name: digest(content) for name, content in files.items()},
            "archive member SHA-256 mismatch")
    return files


def verify_parents(rounds):
    for number, expected in PARENTS.items():
        path = rounds / number / "research.zip"
        require(digest(path.read_bytes()) == expected, f"parent SHA-256 mismatch at {path}")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--rounds", required=True, type=Path)
    parser.add_argument("--work", required=True, type=Path)
    parser.add_argument("--archive", required=True, type=Path)
    options = parser.parse_args()
    rounds = options.rounds.resolve(strict=True)
    work = options.work.resolve(strict=True)
    data = options.archive.read_bytes()
    verify_parents(rounds)
    files = read_release(data)
    require(Path(__file__).read_bytes() == files["replay858.py"], "running driver differs from archive")
    print("Python", sys.version.split()[0], "archive SHA-256", digest(data), flush=True)
    print("R857 verified as the mathematical and Git parent. Experiment inputs are R814 and R856.", flush=True)
    env = dict(os.environ)
    for key in ("PYTHONHOME", "PYTHONPATH", "PYTHONOPTIMIZE"):
        env.pop(key, None)
    for key in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS",
                "VECLIB_MAXIMUM_THREADS", "NUMEXPR_NUM_THREADS"):
        env[key] = "1"
    for name, dependencies in RUNS.items():
        script = f"{name}.py"
        with TemporaryDirectory(prefix=f"replay858-{name}-", dir=work) as tmp:
            clean = Path(tmp)
            local = clean / script
            local.write_bytes(files[script])
            command = [sys.executable, "-B", "-s", script]
            if dependencies:
                command.extend(["--rounds", str(rounds)])
            result = subprocess.run(command, cwd=clean, env=env, capture_output=True, timeout=180)
            require(result.returncode == 0 and not result.stderr,
                    f"{name} exit {result.returncode}, stderr {result.stderr.decode(errors='replace')}")
            expected = files[f"{name}.txt"]
            require(result.stdout == expected,
                    f"{name} stdout SHA-256 {digest(result.stdout)}, expected {digest(expected)}")
            require(list(clean.iterdir()) == [local] and local.read_bytes() == files[script],
                    f"{name} wrote unexpected files or modified its script")
        require(not clean.exists(), f"temporary directory survived for {name}")
        print(f"{name} exited 0 and matched all {len(expected)} stdout bytes", flush=True)
    verify_parents(rounds)
    print("Five exact stdout matches. All subprocesses exited and all temporary directories were removed.")


if __name__ == "__main__":
    main()
