"""Exact shared-central-source collisions for R814's original 4D cross-bin histories."""
import argparse
from collections import defaultdict
from decimal import Decimal, localcontext
from fractions import Fraction as F
from hashlib import sha256
from itertools import product
import json
from pathlib import Path
import sys
from zipfile import ZipFile

PIN = "891d8cbcbd35537e6abc18c938e53b1b4f300327357c24c8d14a51a46ad5e190"
MEMBERS = {
    "comb811.py": "f573f0725c3b1364a5e600123d373fb2d737c6194718f20e967b52ba81dd2837",
    "cell814.json": "5f458f9af30a571ad1f85fdfb9a70093de63c4f77b59695d1ab25aa49eac1f1f",
}


def load(rounds):
    path = rounds / "814" / "research.zip"
    assert sha256(path.read_bytes()).hexdigest() == PIN
    with ZipFile(path) as z:
        assert z.testzip() is None
        manifest = json.loads(z.read("MANIFEST.json"))["members"]
        bodies = {k: z.read(k) for k in MEMBERS}
    for k, data in bodies.items():
        assert sha256(data).hexdigest() == MEMBERS[k] == manifest[k]
    env = {"__name__": "pinned_r814_fixture", "__file__": "comb811.py"}
    exec(compile(bodies["comb811.py"], "comb811.py", "exec"), env)
    stage = env["fixture"](*env["FIXTURES"][-1])
    parents = {p["id"]: p for p in stage["parents"]}
    source = {c["mask"]: c["mass"] for c in stage["cells"]}
    assert stage["dimension"] == 4 and stage["density"]["bump_half_width"] == F(1, 2048)
    lam = {(u, z, half): parents[u]["j"] * weight / (2 * parents[u]["m"])
           for u in parents if parents[u]["role"] == "old"
           for z, weight in source.items() if z & parents[u]["bit"] for half in (0, 1)}
    raw, q95 = {}, defaultdict(F)
    for root in stage["roots_cross"]:
        t, u, g = (root[k] for k in ("t", "u", "g"))
        assert parents[u]["volume_bin"] != parents[g]["volume_bin"]
        assert all(1 <= parents[i]["radius"] < 2 for i in (t, u, g))
        middle = parents[t]
        factor = middle["j"] / (middle["m"]**2 * middle["full_d"])
        check = F(0)
        for z, q, b, h in product(root["z_masks"], root["q_masks"], (0, 1), (0, 1)):
            x, y = (u, z, b), (g, q, h)
            assert (t, x, y) not in raw and z & middle["bit"] and q & middle["bit"]
            raw[t, x, y] = value = factor * lam[x] * lam[y]
            check += value
            if q == 95:
                q95[t, u, g, z] += value
        assert root["root_mass"] == check
    trace = json.loads(bodies["cell814.json"])["original"]
    assert q95 == {(r["t"], r["left_parent"], r["right_parent"], r["z_mask"]): F(r["weight"])
                   for r in trace["rows"]}
    assert len(raw) == 920 and sum(raw.values()) == stage["benchmarks"]["cross"]["mother"]
    return parents, source, lam, raw


def fmt(x):
    with localcontext() as ctx:
        ctx.prec = 12
        return format(Decimal(x.numerator) / Decimal(x.denominator), ".9g")


def summary(keys, values):
    return " ".join(k + "=" + fmt(values[k]) for k in keys)


def density(row, lam, D):
    mass = sum(row.values(), F(0))
    energy = D * sum((v*v/lam[x] for x, v in row.items()), F(0))
    pool = sum((lam[x] for x, v in row.items() if v), F(0)) / D
    assert pool * energy >= mass**2
    return mass, energy, pool


def analyze(row, D, parents, lam, fill, threshold, L, contact):
    """row is ONE probability P_w, or P_w additionally conditioned on one true right-arm fiber."""
    assert sum(row.values()) == 1
    xq, tq, high_xq, marginal_q, full_x = (defaultdict(F) for _ in range(5))
    for (t, x, y), mass in row.items():
        q = y[1]
        xq[x, q] += mass
        tq[t, q] += mass
        full_x[x] += mass
        marginal_q[q] += mass
        if fill[t, y] >= threshold:
            high_xq[x, q] += mass
    h = {z: sum((v for (t, _), v in tq.items() if z & parents[t]["bit"]), F(0))
         for z in {x[1] for x in full_x}}
    C = Z = diff = Cdiff = Zdiff = F(0)
    for (x, q), a in xq.items():
        u, z, _ = x
        for (t, q2), b in tq.items():
            cost = a*b
            hit = contact[u, t]
            price = bool(z & parents[t]["bit"])
            assert not price or hit
            C += cost*hit
            Z += cost*price
            if q != q2:
                diff += cost
                Cdiff += cost*hit
                Zdiff += cost*price
    same = sum((a*a for a in marginal_q.values()), F(0))
    assert same + diff == 1 and 0 <= Zdiff <= Cdiff <= diff and 0 <= Z <= C <= 1
    assert Z == sum(h[x[1]]*v for x, v in full_x.items())
    assert 0 <= Z-Zdiff <= C-Cdiff <= same
    _, E, pool = density(full_x, lam, D)
    first_diff, high = defaultdict(F), defaultdict(F)
    cross_E = cross_high = F(0)
    for (x, q), v in xq.items():
        first_diff[x] += v*(1-marginal_q[q])
        high[x] += high_xq.get((x, q), F(0))
        other = full_x[x] - v
        cross_E += D*v*other/lam[x]
        cross_high += D*high_xq.get((x, q), F(0))*other/lam[x]
    delta, E_diff, pool_diff = density(first_diff, lam, D)
    assert delta == diff and 0 <= cross_E <= E
    assert cross_E + D*sum(v*v/lam[x] for (x, _), v in xq.items()) == E
    for (x, q), amt in high_xq.items():
        hq = sum(v for (t, oq), v in tq.items() if oq == q and x[1] & parents[t]["bit"])
        assert threshold*L*D*amt <= lam[x]*hq
    for x, mass in high.items():
        assert threshold*L*D*mass <= lam[x]*h[x[1]]
    hm, HE, hp = density(high, lam, D)
    hz = sum(h[x[1]]*v for x, v in high.items())
    assert threshold*L*HE <= hz and threshold*L*cross_high <= Zdiff
    return dict(C=C, Z=Z, E=E, pool=pool, same=same, diff=diff, Cdiff=Cdiff, Zdiff=Zdiff,
                E_diff=E_diff, pool_diff=pool_diff, cross_E=cross_E, high=hm, high_E=HE,
                high_Z=hz, high_pool=hp, high_cross_E=cross_high)


def run(parents, source, lam, raw):
    middles = [t for t in parents if parents[t]["role"] == "middle"]
    bins = sorted({parents[t]["volume_bin"] for t in middles})
    assert bins == [64, 128]
    t_right = defaultdict(F)
    for (t, x, y), mass in raw.items():
        t_right[t, y] += mass
    fill = {(t, y): mass*parents[t]["m"]/(parents[t]["j"]*lam[y])
            for (t, y), mass in t_right.items()}
    assert all(0 < v <= 1 for v in fill.values())
    L = min(parents[t]["full_d"] for t in middles)
    # Closed boxes; equality at an endpoint is included even for a zero-volume contact.
    contact = {(u, t): all(max(lo, a) <= min(hi, b) for (lo, hi), (a, b) in
                           zip(parents[u]["box"], parents[t]["box"]))
               for u in parents if parents[u]["role"] == "old" for t in middles}
    print("Python", sys.version.split()[0], "exact Fraction; 814/research.zip SHA-256", PIN)
    print("R814 original 4D octave [1,2), G=A, 34 roots / 920 weighted histories; no asymptotic filling or large-J assumption.")
    print("A(w)=sum_{t contains w} Gamma_D(t)/D; physical shared w integrated with mu. G_t membership is constant on each true mask.")
    print("C=closed A_u intersects A_t' ; Z=z in G_t' ; E=D*int f_w^2 dlambda ; pool=lambda(supp f_w)/D. Suffix diff: distinct q masks.")
    print("The two physical q points are independent draws from continuous conditional laws given w and D; equal physical q mass=0.")
    print("a(t,y)=Gamma(t,y)*m_t/(j_t lambda(y)); tau is the original-weighted lower median within the given D; L=min full_d =", fmt(L))
    print("For all finite rows exact Cauchy: mass^2<=pool*E. High gate satisfies tau*L*D*f<=h_w(z) and tau*L*high_E<=high_Z.")
    for D in bins:
        records = {key: mass for key, mass in raw.items() if parents[key[0]]["volume_bin"] == D}
        by_fill = {k: v for k, v in t_right.items() if parents[k[0]]["volume_bin"] == D}
        acc = F(0)
        for key in sorted(by_fill, key=lambda k: (fill[k], k)):
            acc += by_fill[key]
            if 2*acc >= sum(records.values()):
                threshold = fill[key]
                break
        assert sum(v for k, v in by_fill.items() if fill[k] < threshold) < sum(records.values())/2
        assert sum(v for k, v in by_fill.items() if fill[k] <= threshold) >= sum(records.values())/2
        midbits = sum(parents[t]["bit"] for t in middles if parents[t]["volume_bin"] == D)
        sigs = sorted({w & midbits for w in source if w & midbits})
        lifts, right_lifts = defaultdict(F), defaultdict(F)
        orig_w = defaultdict(F)
        lifted = sum(mass*parents[t]["m"]/D for (t, _, _), mass in records.items())
        assert sum(records.values()) <= lifted < 2*sum(records.values())
        print(f"D={D} original_records={len(records)} positive_w_cells={sum(bool(w & midbits) for w in source)}",
              "Gamma=", fmt(sum(records.values())), "U=", fmt(lifted), "tau=", fmt(threshold))
        for sig in sigs:
            masks = [w for w in source if w & midbits == sig]
            mud = sum(source[w] for w in masks)
            select = {key: mass for key, mass in records.items() if sig & parents[key[0]]["bit"]}
            base = sum(select.values())
            assert base > 0
            A = base / D
            measure = mud*A
            row = {key: mass/base for key, mass in select.items()}
            stats = analyze(row, D, parents, lam, fill, threshold, L, contact)
            # Pure projections of the same histories, before any second right point is held fixed.
            x_only, y_only, x_w, x_y = (defaultdict(F) for _ in range(4))
            for (_, x, y), prob in row.items():
                x_only[x] += prob
                y_only[y] += prob
                x_w[x, (y[0], y[2])] += prob
                x_y[x, y] += prob
            assert x_only == y_only
            assert all(x_w[x, (g, 0)] == x_w[x, (g, 1)] for x, (g, _) in x_w)
            w_ref = {(x, wh): lam[x]*parents[wh[0]]["j"]/2 for x, wh in x_w}
            xy_ref = {(x, y): lam[x]*lam[y] for x, y in x_y}
            assert all(sum(p for (xp, _), p in x_y.items() if xp == x) == v for x, v in x_only.items())
            _, stats["full_Y_E"], _ = density(y_only, lam, D)
            _, stats["joint_X_W_E"], stats["joint_X_W_pool"] = density(x_w, w_ref, D**2)
            _, stats["joint_X_Y_E"], stats["joint_X_Y_pool"] = density(x_y, xy_ref, D**2)
            assert stats["full_Y_E"] == stats["E"] and stats["joint_X_W_E"] <= stats["joint_X_Y_E"]
            for field, number in stats.items():
                lifts[field] += measure*number
            for key in select:
                orig_w[key] += measure*row[key]
            print("  mask_signature", sig, "n=", len(masks), "A=", fmt(A),
                  "U_share=", fmt(measure/lifted), "P_w:", summary(("C","Z","E","pool","same"), stats))
            if 95 in masks:
                print("  physical_w_mask_95: mu=", fmt(source[95]), "U_mass=", fmt(source[95]*A),
                      "same_q_mask_95_pair=", fmt(sum(a for (_, _, y), a in row.items() if y[1] == 95)**2),
                      summary(("diff","Cdiff","Zdiff","E_diff","cross_E"), stats))
            # Add the complete right observation y=(g,q-cell,W-half); first U-half remains explicit.
            # Draw y once with its true row mass, then use two iid conditional histories.
            right = defaultdict(dict)
            for key, probability in row.items():
                right[key[2]][key] = probability
            left_again = defaultdict(F)
            for y, group in right.items():
                b = sum(group.values())
                cond = {key: v/b for key, v in group.items()}
                stats_y = analyze(cond, D, parents, lam, fill, threshold, L, contact)
                assert stats_y["same"] == 1 and stats_y["diff"] == 0
                for field in ("C","Z","E","pool"):
                    right_lifts[field] += measure*b*stats_y[field]
                for (t, x, obs), v in cond.items():
                    assert obs == y and x[2] in (0, 1)
                    left_again[t, x, y] += b*v
            assert left_again == row
            if 95 in masks:
                y = next(y for y in sorted(right) if y[1:] == (95, 0))
                y2 = (y[0], 95, 1)
                a0 = {(t, x): value for (t, x, _), value in right[y].items()}
                a1 = {(t, x): value for (t, x, _), value in right[y2].items()}
                assert a0 == a1 and sum(a0.values()) > 0
                print("  true W half stress", y, y2, "each P_w mass", fmt(sum(a0.values())),
                      "; every retained (t,u,z,U-half) weight matches")
        assert orig_w == {key: mass*parents[key[0]]["m"]/D for key, mass in records.items()}
        s = {field: w/lifted for field, w in lifts.items()}
        assert lifts["diff"] + lifts["same"] == lifted
        print("  all normalized by U:", summary(("C","Z","E","pool","same","diff"), s))
        print("  same/different q masks raw U-costs:", summary(("same","diff","Cdiff","Zdiff","E_diff","cross_E"), lifts))
        print("  restricted normalized by original U:", summary(("diff","Cdiff","Zdiff","E_diff","pool_diff","cross_E"), s))
        if s["diff"]:
            print("  conditional hit rates, explicit denominator U_diff:", "C=", fmt(lifts["Cdiff"]/lifts["diff"]),
                  "Z=", fmt(lifts["Zdiff"]/lifts["diff"]))
        print("  median gate subprobability, original U denominator:",
              summary(("high","high_E","high_Z","high_pool","high_cross_E"), s))
        assert lifts["high_Z"] and lifts["high"] > 0
        print("  median tau*L*high_E/high_Z =", fmt(threshold*L*lifts["high_E"]/lifts["high_Z"]))
        print("  complete original U/W projections (joint energies use D^2):",
              summary(("full_Y_E","joint_X_W_E","joint_X_W_pool","joint_X_Y_E","joint_X_Y_pool"), s))
        full_right = {field: w/lifted for field, w in right_lifts.items()}
        assert full_right["E"] >= s["E"]
        print("  additionally share complete right (g,q,W-half), U-half kept:", summary(("C","Z","E","pool"), full_right))
    print("E_diff uses the first-X submarginal after the distinct-mask test; cross_E is the off-diagonal q-pair Gram cost.")
    print("X,W retains complete left X and the true second owner/half (g,W-half), using lambda_X times its original right marginal j_g/2; X,Y retains the full right fiber.")
    print("In the extra shared-right experiment, conditioning on a single physical q,W inside that fiber gives the same finite (t,X) law.")
    print("Reported decimals round exact fractions; the two central D rows are never mixed.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--rounds", required=True, type=Path)
    args = parser.parse_args()
    run(*load(args.rounds))
