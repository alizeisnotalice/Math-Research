"""Exact central-source repricing on all 920 original R814 cross-bin records."""
from argparse import ArgumentParser
from collections import defaultdict, deque
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
from zipfile import ZipFile
import json
import sys

PIN856 = "16496077ed6ce4e48816dfb70d93a8251885db6ff03e033a3109eaa6e2f13fbb"


def total(x):
    return sum(x, F(0))


def load(rounds):
    z = rounds / "856" / "research.zip"
    assert sha256(z.read_bytes()).hexdigest() == PIN856
    with ZipFile(z) as bundle:
        assert bundle.testzip() is None
        manifest = json.loads(bundle.read("MANIFEST.json"))["sha256"]
        name = "anchor856.py"
        script = bundle.read(name)
        assert sha256(script).hexdigest() == manifest[name]
        env = {"__name__": "true_r814_fixture", "__file__": name}
        exec(compile(script, name, "exec"), env)
    stage, check95 = env["load"](rounds / "814" / "research.zip")
    parents, _, src, _, _, _, _, _, raw, _, _ = env["reconstruct"](stage, check95)
    assert len(raw) == 920
    return parents, src, raw, env["outward"], env["PIN"]


def network(demands, src, price):
    parts = sorted(demands)
    sources = sorted({w for pool in parts for w in pool})
    m = len(parts)
    w_index = {w: i + m for i, w in enumerate(sources)}
    start, end = m + len(sources), m + len(sources) + 1
    graph = [[] for _ in range(end + 1)]
    max_supply = total(demands.values())
    uncut = 1 + max_supply

    def edge(a, b, strength):
        ix = len(graph[a])
        graph[a].append([b, len(graph[b]), strength])
        graph[b].append([a, ix, F(0)])
        return ix

    transfers = {}
    for i, pool in enumerate(parts):
        edge(start, i, demands[pool])
        for w in pool:
            transfers[pool, w] = i, edge(i, w_index[w], uncut)
    for w in sources:
        edge(w_index[w], end, price * src[w])

    carried = F(0)
    while True:
        depth = [-1] * len(graph)
        depth[start] = 0
        bfs = deque([start])
        while bfs:
            node = bfs.popleft()
            for f, _, capacity in graph[node]:
                if capacity and depth[f] < 0:
                    depth[f] = depth[node] + 1
                    bfs.append(f)
        if depth[end] < 0:
            break
        ptr = [0] * len(graph)

        def send(a, ask):
            if a == end:
                return ask
            while ptr[a] < len(graph[a]):
                forward = graph[a][ptr[a]]
                f, rev, cap = forward
                if cap and depth[f] == depth[a] + 1:
                    out = send(f, min(ask, cap))
                    if out:
                        forward[2] -= out
                        graph[f][rev][2] += out
                        return out
                ptr[a] += 1
            return F(0)

        while amount := send(start, uncut):
            carried += amount
    rows, cols = defaultdict(F), defaultdict(F)
    solution = {}
    for (pool, w), (a, ix) in transfers.items():
        amount = uncut - graph[a][ix][2]
        assert amount >= 0
        if amount:
            rows[pool] += amount
            cols[w] += amount
            solution[pool, w] = amount
    assert carried == total(rows.values()) == total(cols.values())
    assert all(x <= demands[k] for k, x in rows.items())
    assert all(x <= price * src[w] for w, x in cols.items())
    cut_rows = tuple(pool for i, pool in enumerate(parts) if depth[i] >= 0)
    cut_cells = tuple(sorted({w for pool in cut_rows for w in pool}))
    assert set(cut_cells) == {w for w, ix in w_index.items() if depth[ix] >= 0}
    demand = total(demands[pool] for pool in cut_rows)
    capacity = total(src[w] for w in cut_cells)
    assert carried == max_supply - demand + price * capacity
    return carried, rows, cols, (demand, capacity, cut_cells)


def peak(demands, src):
    target = total(demands.values())
    price = F(0)
    worst = (F(0), F(0), ())
    while True:
        value, rows, columns, cut = network(demands, src, price)
        if value == target:
            break
        demand, supply, _ = cut
        assert demand > price * supply and supply > 0
        price, worst = demand / supply, cut
    if target:
        assert price > 0 and worst[0] == price * worst[1]
        assert all(columns[w] == price * src[w] for w in worst[2])
    return price, worst


def canonical(demands, src, price):
    shares = {pool: total(src[w] for w in pool) for pool in demands}
    loaded = defaultdict(F)
    for pool, value in demands.items():
        for w in pool:
            loaded[w] += value * src[w] / shares[pool]
    level, top_w = max(((val / src[w], w) for w, val in loaded.items()), default=(F(0), None))
    keep = {w: min(x, src[w] * price) / x for w, x in loaded.items()}
    paid = {pool: value * total(src[w] * keep[w] for w in pool) / shares[pool]
            for pool, value in demands.items()}
    # With canonical edge budgets frozen, a receiver-cut at each source cell
    # proves the optimum without any redistribution.
    assert total(paid.values()) == total(min(x, price * src[w]) for w, x in loaded.items())
    return level, top_w, paid


def strata(raw, src, parents, rule, independent):
    demands = defaultdict(lambda: defaultdict(F))
    original = {}
    clipped = F(0)
    for key, value in raw.items():
        t, left, right = key
        bit = parents[t]["bit"]
        if rule in ("left", "both"):
            bit |= parents[left[0]]["bit"]
        if rule == "both":
            bit |= parents[right[0]]["bit"]
        pool = tuple(w for w in sorted(src) if w & bit == bit)
        budget = right[1] if independent else "shared"
        original[key] = (budget, pool)
        clipped += value * total(src[w] for w in pool) / parents[t]["m"]
        if pool:
            demands[budget][pool] += value
    assert sum(raw.values()) >= total(x for d in demands.values() for x in d.values()) >= clipped
    return demands, original, clipped


def check_receivers(raw, parents, original, demands, achieved_payment, full):
    paid = [defaultdict(F), defaultdict(F)]
    all_ = [defaultdict(F), defaultdict(F)]
    amount = F(0)
    for key, original_mass in raw.items():
        group, pool = original[key]
        scale = achieved_payment[group].get(pool, F(0)) / demands[group][pool] if pool else F(0)
        assert 0 <= scale <= 1 and (not full or scale == 1)
        price = original_mass * scale
        amount += price
        for side, arm in enumerate(key[1:]):
            region = arm[0], arm[2]
            paid[side][region] += price
            all_[side][region] += original_mass
    max_density = []
    for i, (got, old) in enumerate(zip(paid, all_)):
        assert total(got.values()) == amount
        for (u, half), x in old.items():
            assert got[u, half] <= x <= parents[u]["owner_volume"] / 2
            if full:
                assert got[u, half] == x
        max_density.append(max(2 * x / parents[u]["owner_volume"] for (u, half), x in old.items()))
    return amount, max_density


def audit_case(rule, independent, demands, peak_results, original, clipped, raw, src, parents, scale, fmt):
    m = total(raw.values())
    eligible = total(amount for group in demands.values() for amount in group.values())
    optimum, key = max((answer[0], k) for k, answer in peak_results.items())
    cut = peak_results[key][1]
    recorded = {}
    uniform_paid = {}
    canonical_peak = F(0)
    w_peak = None
    v_peak = None
    threshold_cut = F(0)
    unpaid_cut, budget_scope, tight = F(0), None, 0
    for scope, d in demands.items():
        value, rows, cols, cap = network(d, src, scale)
        tight += sum(a == scale * src[w] for w, a in cols.items())
        if cap[0] - scale * cap[1] > unpaid_cut:
            unpaid_cut, budget_scope = cap[0] - scale * cap[1], scope
        recorded[scope] = rows
        threshold_cut += total(d.values()) - cap[0] + scale * cap[1]
        c, w, paid = canonical(d, src, scale)
        uniform_paid[scope] = paid
        if c > canonical_peak:
            canonical_peak, w_peak, v_peak = c, w, scope
    assert canonical_peak >= optimum > 0
    full_case = rule == "central" and optimum <= scale
    real, densities = check_receivers(raw, parents, original, demands, recorded, full_case)
    uniform, _ = check_receivers(raw, parents, original, demands, uniform_paid, False)
    assert real == threshold_cut and 0 < uniform <= real <= eligible
    full_eligible, _ = check_receivers(raw, parents, original, demands, demands, eligible == m)
    assert full_eligible == eligible
    print(f"  {rule}, {'independent q cap' if independent else 'common source cap'}")
    print("    eligible/F, unpayable/F, cut of original central-uniform/F:",
          *(fmt(x) for x in (eligible / m, (m - eligible) / m, clipped / m)))
    print("    peak canonical/C0, best peak/C0 for all eligible:",
          fmt(canonical_peak / scale), fmt(optimum / scale),
          "; canonical peak cell (provider,source cell)", (v_peak, w_peak))
    print("    at C0 canonical and unrestricted paid/F; absolute unrestricted:",
          fmt(uniform / m), fmt(real / m), fmt(real))
    print("    at C0 saturated source rows, largest cut deficit/F and provider:",
          tight, fmt(unpaid_cut / m), budget_scope)
    print("    exact critical worst cut (provider, demand/F, true source mass, source cells):",
          key, fmt(cut[0] / m), fmt(cut[1]), cut[2])
    print("    empty-support original record count:", sum(not s for _, s in original.values()))
    print("    restrict both original receiver margins: same paid and peak; original max densities:",
          *(fmt(x) for x in densities))


if __name__ == "__main__":
    parser = ArgumentParser()
    parser.add_argument("--rounds", type=Path, required=True)
    parents, src, raw, fmt0, pin814 = load(parser.parse_args().rounds)
    fmt = lambda x: fmt0(x) if x else "0"
    records = {}
    for rule in ("central", "left", "both"):
        for independent in (True, False):
            demands, original, clipped = strata(raw, src, parents, rule, independent)
            results = {key: peak(d, src) for key, d in demands.items()}
            records[rule, independent] = demands, results, original, clipped
    scale = max(answer[0] for answer in records["central", True][1].values())
    assert scale > 0
    print("Python", sys.version.split()[0], "Fraction exact; R814/R856 pins", pin814, PIN856)
    print("True 4D comb, 920 original records. Price units are original Gamma per unit true mu.")
    print("Critical scale C0 = minimum common peak across independently funded q markets with central support:",
          fmt(scale), "; full true F:", fmt(total(raw.values())))
    print("Each positive accepted atom retains its own source data and original two physical receiver halves.")
    print("Central/left/both allow only A_t, A_t∩A_u, A_t∩A_u∩A_g, respectively.")
    print("Canonical means uniform true mu inside the chosen allowed support; empty supports stay unpaid.")
    for (rule, independent), data in records.items():
        audit_case(rule, independent, *data, raw, src, parents, scale, fmt)
