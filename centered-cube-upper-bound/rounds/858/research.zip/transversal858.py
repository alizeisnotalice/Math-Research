"""Exact physical contact transversals and Arb checks of the continuum net budget."""
from fractions import Fraction as F
from itertools import product
from math import prod
import sys
from flint import arb, ctx, __version__ as flint_version


def interval(x, radius):
    return x - radius, x + radius


def inter(i, j):
    return max(i[0], j[0]), min(i[1], j[1])


def length(i):
    return max(F(0), i[1] - i[0])


def volume(box):
    return prod(length(i) for i in box)


def truth(patterns):
    n = len(patterns[0][0])
    parent = ((F(-2), F(2)),) * n
    out = []
    for i, pattern in enumerate(patterns):
        pair = []
        for sign, corner in enumerate(pattern):
            widths = [F(2 + (i + 2 * j + sign) % 3, 8) for j in range(n)]
            centers = [(1 if k == "+" else -1) * (F(5, 2) - w)
                       for k, w in zip(corner, widths)]
            smaller = tuple(interval(c, F(1, 2)) for c in centers)
            meet = tuple(inter(a, b) for a, b in zip(parent, smaller))
            assert all(length(j) == w > 0 for j, w in zip(meet, widths))
            assert volume(meet) > 0
            pair.append(meet)
        out.append(pair)
    return out


def axes(boxes, marks):
    chosen = [pair[side] for pair, side in zip(boxes, marks)]
    return tuple((max(i[0] for i in col), min(i[1] for i in col)) for col in zip(*chosen))


def gaps(boxes, marks):
    return tuple(max(F(0), a - b) for a, b in axes(boxes, marks))


def face_grid(boxes, selected_axes):
    pairs = [b for pair in boxes for b in pair]
    n = len(pairs)
    states = {(1 << n) - 1: (F(0), ())}
    for d in selected_axes:
        by_face = {}
        ends = sorted({q for b in pairs for q in b[d]})
        for a, c in product(ends, repeat=2):
            if a > c:
                continue
            mask = sum(1 << k for k, r in enumerate(pairs) if r[d][0] <= c and a <= r[d][1])
            hit = c - a, (a, c)
            if mask not in by_face or hit < by_face[mask]:
                by_face[mask] = hit
        after = {}
        for mask, (u, previous) in states.items():
            for active, (v, one) in by_face.items():
                key = mask & active
                test = u + v, previous + (one,)
                if key not in after or test < after[key]:
                    after[key] = test
        states = after
    return min((v, core, mask) for mask, (v, core) in states.items()
               if all((mask >> (2 * i)) & 3 for i in range(len(boxes))))


def union(boxes):
    boxes = tuple(set(box for box in boxes if volume(box) > 0))
    if not boxes:
        return F(0)
    n = len(boxes[0])
    grid = []
    for d in range(n):
        edges = sorted({e for b in boxes for e in b[d]})
        grid.append(tuple(zip(edges, edges[1:])))
    ans = F(0)
    for tiny in product(*grid):
        p = tuple((a + b) / 2 for a, b in tiny)
        if any(all(u < q < v for q, (u, v) in zip(p, box)) for box in boxes):
            ans += volume(tiny)
    return ans


def projected(boxes, arms, n, delta):
    s = F(2)
    radius = (1 + delta) * s
    width = (2 * s) ** n
    menus = []
    for drop in ((), *((d,) for d in range(n))):
        family = []
        for bits in arms:
            a = axes(boxes, bits)
            centers = tuple((-s, s) if i in drop else inter((-s, s), (lo - radius, hi + radius))
                            for i, (lo, hi) in enumerate(a))
            independently = [box[side] for box, side in zip(boxes, bits)]
            expected = [(-s, s)] * n
            for box in independently:
                for i, (z, w) in enumerate(box):
                    if i not in drop:
                        expected[i] = inter(expected[i], (z - radius, w + radius))
            assert tuple(expected) == centers
            assert volume(centers) == (2 * s) ** len(drop) * prod(
                length(centers[i]) for i in range(n) if i not in drop)
            family.append(centers)
        menus.append((drop, family))
    values = [union(family) / width for _, family in menus]
    geometric = union([box for _, family in menus[1:] for box in family]) / width
    assert 0 < values[0] <= min(values[1:]) <= max(values[1:]) <= geometric <= min(F(1), sum(values[1:]))
    print("  center union, no deleted axis / each single deleted axis / any one deleted:",
          values[0], " ".join(map(str, values[1:])), geometric, "; sum over deletion choices", sum(values[1:]))


def solve(name, patterns, delta):
    boxes = truth(patterns)
    m, n = len(boxes), len(boxes[0][0])
    marks = tuple(product((0, 1), repeat=m))
    formula, choice = min((sum(gaps(boxes, e)), e) for e in marks)
    actual, witnesses, mask = face_grid(boxes, range(n))
    assert actual == formula
    fixed = [sum(gaps(boxes, (q,) * m)) for q in (0, 1)]
    coordinatewise = sum(face_grid(boxes, (i,))[0] for i in range(n))
    assert coordinatewise <= formula <= min(fixed)
    points = []
    for i, pair in enumerate(boxes):
        label = 0 if mask & (1 << (2 * i)) else 1
        current = tuple(inter(r, q) for r, q in zip(pair[label], witnesses))
        assert all(a <= b for a, b in current)
        points.append(tuple((a + b) / 2 for a, b in current))
    assert sum(max(q) - min(q) for q in zip(*points)) == formula
    print(f"{name}: n={n}, measures={m}, δ={delta}; true contacts all positive.")
    print("  total edge length whole-measure switch / fixed two choices / incorrect axis-wise switch:",
          formula, fixed, coordinatewise, "; one optimal sign string", "".join("-+"[k] for k in choice))
    print("  independent face-grid boxes and actual chosen points attain the same length.")
    projected(boxes, marks, n, delta)


def large_budget():
    ctx.prec = 192
    print("Arb 192 bits: ℓ=log(n+2), J=sqrt(n)ℓ^8, M=ceil(128 nℓ/J), k<=J/(100000ℓ).")
    print("Two endpoints per axis on the unit grid with ceil(1000 n/J) subdivisions give at most (1000 n/J + 2)^(2n) codes, bounded by (1002 n/J)^(2n) when J<=n.")
    for n in (64, 4096):
        ell = arb(n + 2).log()
        J = arb(n).sqrt() * ell ** 8
        assert J > n
        print("  small n", n, "J/n", (J / n).str(9), "; fails J<=n/100.")
    for p in (256, 512, 1024):
        nz = 2 ** p
        n = arb(nz)
        ell = arb(nz + 2).log()
        J = arb(2 ** (p // 2)) * ell ** 8
        M = 128 * n * ell / J
        assert 0 < J < n / 100
        grid = 2 * n * (1000 * n / J + 2).log()
        complexity = (M + 1) * arb(2).log() + J * n.log() / (100000 * ell)
        payoff = M * J / 4
        assert complexity < J / 100 and (payoff - grid - complexity) / (n * ell) > 30
        print("  n=2^"+str(p), "M/J <=", ((M + 1) / J).str(9),
              "; log(2^M binom)/J <=", (complexity / J).str(9),
              "; log grid/(nℓ) <=", (grid / (n * ell)).str(9),
              "; net payoff/(nℓ) >=", ((payoff - grid - complexity) / (n * ell)).str(9))


if __name__ == "__main__":
    print("Python", sys.version.split()[0], "python-flint", flint_version, "Fraction exact and rigorous Arb.")
    solve("INITIAL mixed-side witness", (("--", "++"), ("++", "--"), ("--", "++")), F(0))
    solve("PRESSURE no coordinatewise side selection",
          (("--", "++"), ("+-", "-+"), ("--", "++"), ("+-", "-+")), F(0))
    solve("EXPANDED", (("---", "+++"), ("+--", "-++"), ("-+-", "+-+"), ("--+", "++-")), F(1, 8))
    large_budget()
