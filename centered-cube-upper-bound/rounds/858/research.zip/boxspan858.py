"""R858 exact free right-receiver span geometry and common-centre contact."""

from fractions import Fraction as F
from itertools import product
from math import comb, factorial, prod
import sys

from flint import arb, ctx, __version__ as flint_version


def aq(x):
    x=F(x)
    return arb(x.numerator)/x.denominator


def formula(M,beta,L):
    return (beta+L)**M + M*L*(beta+L)**(M-1)


def from_minimum(M,beta,L):
    # In the ambient interval of length T, the minimum is u.
    # The other M-1 coordinates have width min(W,T-u).
    T,W=2*L+beta,L+beta
    return M*(T-W)*W**(M-1) + W**M


def from_complement(M,beta,L):
    # A bad tuple has a unique min and max off zero-volume ties.
    # With their difference t>W, intermediate positions have
    # joint volume t^(M-2), and the min ranges over T-t.
    T,W=2*L+beta,L+beta
    if M==1:
        return T
    complement = M*(M-1)*(T*(T**(M-1)-W**(M-1))/(M-1)
                          -(T**M-W**M)/M)
    return T**M-complement


def min_span(e,beta):
    lo,hi=min(e),max(e)
    return max(F(0),hi-beta/2,-lo-beta/2,hi-lo-beta)


def place_right_prices(e,beta,L):
    # For b in [-L,0] candidate source coordinates must belong to
    # [b,b+L] and their own positive beta neighbourhoods.
    lo=max(-L,max(e)-L-beta/2)
    hi=min(F(0),min(e)+beta/2)
    if lo>hi:
        return False
    q=[max(lo,v-beta/2) for v in e]
    assert all(lo<=p<=lo+L and abs(p-v)<=beta/2 for p,v in zip(q,e))
    assert max((F(0),*q))-min((F(0),*q))<=L
    return True


def exact_checks():
    tests=0
    for M,beta,L in product(range(1,13),(F(0),F(1,3),F(1)),
                            (F(0),F(1,64),F(1,4),F(1,2),F(1))):
        assert formula(M,beta,L)==from_minimum(M,beta,L)==from_complement(M,beta,L)
        tests+=1
    print("Exact minimum-slice and maximum-span complement agree:",tests,"one-axis cases M=1..12.")
    for M,beta in product(range(1,13),(F(0),F(1,3),F(1))):
        lists=([F(i,16) for i in range(M)], [F(-i,16) for i in range(M)],
               [F((-1)**i*i,16) for i in range(M)], [F(0)]*M)
        for e in lists:
            L=min_span(e,beta)
            assert place_right_prices(e,beta,L)
            if L>0:
                assert not place_right_prices(e,beta,L-F(1,2)*min(L,F(1,1024)))
    print("Exact interval witnesses reconstruct allowed q_i on the first feasible span.")
    for M in (1,3,6,12):
        spans=(F(0),F(1,5),F(3,4))
        widths=(F(1,3),F(0),F(1))
        assert prod(formula(M,b,L) for b,L in zip(widths,spans))==prod(
            from_complement(M,b,L) for b,L in zip(widths,spans))
    print("Three-axis anisotropic products checked; the unconstrained price choices factor by axis.")


def coefficients(M,beta):
    return tuple(F((k+1)*comb(M,k))*beta**(M-k) for k in range(M+1))


def moment(M,beta,a):
    # Finite Stieltjes measure of the least span on [0,1].
    # There is one atom beta^M at L=0, included in the term k=0.
    return sum(c*F(factorial(k)*factorial(a),factorial(k+a))
               for k,c in enumerate(coefficients(M,beta)))


def high_product_caps():
    ctx.prec=192
    print("Free-span pool L=1, beta<=1: cell factor <=2^(M-1)(M+2).")
    for M in range(1,13):
        f=formula(M,F(1),F(1))
        assert f==2**(M-1)*(M+2)
        if M==1:
            assert f==3
        else:
            assert f*f<=8**M
        if M in (1,2,4,8,12):
            root=(aq(f).log()/M).exp()
            print("  M",M,"one-axis pool",f,"; base per right receiver",root.str(10),
                  "; fraction of 3^M",F(f,3**M))
    # For M>=2, (M+2)/2<=sqrt(2)^M by induction; the ratio of
    # successive linear factors is <=5/4<sqrt(2).
    assert F(5,4)**2<2
    print("Universal 3->sqrt(8) base improvement for M>=2; M=1,beta=1,L=1 has equality 3.")
    for n in (64,256,1024):
        logs=tuple((n*aq(F(formula(M,F(1),F(1)),3**M)).log()/arb(2).log()).str(10)
                   for M in (2,8,12))
        print("  n",n,"log2 improvement over 3^(nM) at M=2,8,12:",logs)


def pdet_bounds(M,beta,u):
    base=formula(M,beta,F(1))
    lower=formula(M,beta,1-u)
    # P=product of the remaining centre-width fractions 1-L.
    # Require P>=u^n; Markov on P^a gives the product caps below.
    candidates=tuple(moment(M,beta,a)/u**a for a in range(0,9))
    j=min(range(len(candidates)),key=candidates.__getitem__)
    upper=candidates[j]
    assert 0<lower<=upper<=base and moment(M,beta,0)==base
    return lower,upper,j


def exactly_two_axes(M,beta,p):
    # F(1-u) polynomial coefficients in the surviving width u.
    c=coefficients(M,beta)
    g=[sum(v*comb(k,j)*(-1)**j for k,v in enumerate(c) if k>=j)
       for j in range(M+1)]
    h=[-(j+1)*g[j+1] for j in range(M)]
    atom=beta**M
    # Integral over the absolutely continuous portion of axis 1:
    # h(u) [F(1-p/u)-atom]. There are also two one-atom pieces.
    rational=2*atom*formula(M,beta,1-p)-atom**2
    log_coefficient=F(0)
    for i,x in enumerate(h):
        for j,y in enumerate(g):
            w=x*(y-(atom if j==0 else 0))*p**j
            e=i-j
            if e==-1:
                log_coefficient-=w
            else:
                rational+=w*(1-p**(e+1))/(e+1)
    return rational,log_coefficient


def restricted_pool():
    p=F(1,4)
    c,d=exactly_two_axes(1,F(0),p)
    assert (c,d)==(4*(1-p),4*p)
    print("P-volume exact in two axes at u=1/2 (P>=1/4), beta=1:")
    for M in (1,2,4,8,12):
        rational,coef=exactly_two_axes(M,F(1),p)
        actual=aq(rational)+aq(coef)*aq(p).log()
        lo,hi,j=pdet_bounds(M,F(1),F(1,2))
        assert aq(lo**2)<=actual and actual<=aq(hi**2)
        print("  M",M,"exact rational+log integral interval",actual.str(9),
              "; certified sandwich",series((lo**2,hi**2)),
              "; moment order",j)
    for u in (F(1,4),F(1,2),F(3,4)):
        print("Product cutoff P>=("+str(u)+")^n; upper/base factors per axis at beta=1:")
        for M in (2,4,8,12):
            lo,hi,j=pdet_bounds(M,F(1),u)
            base=formula(M,F(1),F(1))
            print("  M",M,"lower/base and upper/base",series((lo/base,hi/base)),
                  "; best proven moment in orders 0..8:",j)


def series(items):
    return tuple(aq(x).str(8) for x in items)


def dist_to_interval(w,I):
    return max(F(0),I[0]-w,w-I[1])


def common_center_width(w,I,W):
    # The middle box contains w and also meets the actual parent axis.
    left=max(w-W/2,I[0]-W/2)
    right=min(w+W/2,I[1]+W/2)
    result=max(F(0),right-left)
    assert result==max(F(0),W-dist_to_interval(w,I))
    return result


def contact_geometries():
    W=F(3,2)
    near=((F(1,8),F(5,8)),(F(-7,8),F(-3,8)),(F(-1,5),F(3,10)))
    tangent=((W-F(1,1024),W+F(511,1024)),*near[1:])
    far=((F(7,4),F(9,4)),*near[1:])
    for name,box in (("near",near),("tiny near",tangent),("far",far)):
        assert all(b-a==F(1,2) for a,b in box)
        ds=tuple(dist_to_interval(F(0),I) for I in box)
        widths=tuple(common_center_width(F(0),I,W) for I in box)
        vol=prod(widths)/W**3
        print("Actual asymmetric",name,"box: outer distances",ds,"; normalized common centres",vol)
    assert prod(common_center_width(F(0),I,W) for I in near)/W**3==F(11,16)
    eps=F(1,4096)
    # The anchor can vary in an actual positive cube. The first two
    # one-axis widths are affine on its entire range and the third
    # is constant, so its uniform source average equals the central value.
    for I in near:
        assert sum(common_center_width(w,I,W) for w in (-eps,eps))/2==common_center_width(F(0),I,W)
    assert common_center_width(eps,far[0],W)==0
    for n in (64,256,1024):
        axis=tuple(common_center_width(F(0),near[k%3],W)/W for k in range(n))
        exact=prod(axis)
        print("  n",n,"repeat asymmetric axes, exact positive anchor-averaged volume log2",
              (aq(exact).log()/arb(2).log()).str(10))


if __name__=="__main__":
    ctx.prec=192
    print("Python",sys.version.split()[0],"python-flint",flint_version,"| exact Fraction and 192-bit Arb")
    exact_checks()
    high_product_caps()
    restricted_pool()
    contact_geometries()
    print("All assertions passed. Scope: actual box geometry and freely chosen prices in their intervals.")
