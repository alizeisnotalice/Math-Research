"""R564 N5: exhaustive ordered frozen action-pair overlap diagnostic, no QP."""
import os
for key in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:os.environ[key]='2'
import json,math,time,hashlib,resource,argparse,platform
from pathlib import Path
from fractions import Fraction
import numpy as np

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def bitmask(v):return sum(1<<int(z) for z in v)
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--optimizer',default='/tmp/ccu_r562_optimizer.json');ap.add_argument('--n3',default='/tmp/ccu_r563_n3.json');ap.add_argument('--output',default=str(Path(__file__).with_suffix('.json')));args=ap.parse_args();start=time.perf_counter()
 x=json.load(open(args.optimizer));ref=json.load(open(args.n3));ss=x['summary']['action_states'];pp=x['summary']['frozen_parent_records'];nv=len(ss)
 parent=np.array([s['parent'] for s in ss]);count=np.array([s['count'] for s in ss],dtype=np.uint8);c0=np.array([pp[b]['old_count'] for b in parent],dtype=np.uint8);phase=np.array([s['phase'] for s in ss],dtype=np.int16);band=np.array([pp[b]['band'] for b in parent],dtype=np.int16);amp=np.array([pp[b]['weight']/pp[b]['R']**16 for b in parent]);oldsets={s['parent']:s['receiver_atoms'] for s in ss if s['kind']=='initial'}
 cap=np.array([bitmask(s['receiver_atoms']) for s in ss],dtype=np.uint64);old=np.array([bitmask(oldsets[b]) for b in parent],dtype=np.uint64);new=cap&~old
 assert np.all(np.bitwise_count(cap)==count) and np.all(np.bitwise_count(old)==c0) and np.all(old&~cap==0)
 components=np.empty((nv,nv,4),dtype=np.uint8)
 for lo in range(0,nv,128):
  hi=min(lo+128,nv)
  for k,(a,b) in enumerate([(old,old),(old,new),(new,old),(new,new)]):components[lo:hi,:,k]=np.bitwise_count(a[lo:hi,None]&b[None,:])
 nf=components[:,:,0]+components[:,:,1];nr=components[:,:,0]+components[:,:,2]
 assert np.array_equal(nf,nr.T)
 assert np.array_equal(components.sum(2),np.bitwise_count(cap[:,None]&cap[None,:]))
 assert np.all(components[nf==0,:2]==0) and np.all(components[nr==0][:,[0,2]]==0)
 fractions=sorted({Fraction(k,int(c)) for c in set(c0) for k in range(int(c)+1)});findex={q:i for i,q in enumerate(fractions)};table=np.zeros((65,65),dtype=np.int16)
 for c in set(c0):
  for k in range(int(c)+1):table[c,k]=findex[Fraction(k,int(c))]
 fi=table[c0[:,None],nf];ri=table[c0[None,:],nr];bi=np.minimum(fi,ri);values=np.array([float(f) for f in fractions]);inv=np.zeros(len(values));inv[1:]=1/values[1:]
 bands=sorted(set(map(int,band)));bindex={b:i for i,b in enumerate(bands)};bids=np.array([bindex[int(b)] for b in band]);nb=len(bands);bp=bids[:,None]*nb+bids[None,:];fd=(fi*nb*nb+bp).ravel();bd=(bi*nb*nb+bp).ravel();shape=(len(fractions),nb,nb,4)
 tent=np.maximum(1-abs(np.log2(count.astype(float)[:,None]/count[None,:])),0);samephase=phase[:,None]==phase[None,:];kernel=tent*samephase/64
 rhomap={'adaptive':np.array(ref['rhos']['adaptive']),'optimum':np.array(x['rho_all_band_optimum']),'delta1':np.array(ref['rhos']['delta1'])};saved=dict(components=components,numerator_forward=nf,numerator_reverse=nr,parent=parent,count=count,old_count=c0,phase=phase,band=band,amp=amp,capmask=cap,oldmask=old,fraction_numerator=np.array([f.numerator for f in fractions]),fraction_denominator=np.array([f.denominator for f in fractions]));results={}
 for law,rho in rhomap.items():
  weight=rho*amp;pref=weight[:,None]*weight[None,:]*kernel;hist=np.zeros(shape);both=np.zeros(shape);bothcost=np.zeros(shape)
  for c in range(4):
   energy=pref*components[:,:,c];hist[:,:,:,c]=np.bincount(fd,weights=energy.ravel(),minlength=np.prod(shape[:3])).reshape(shape[:3]);both[:,:,:,c]=np.bincount(bd,weights=energy.ravel(),minlength=np.prod(shape[:3])).reshape(shape[:3]);bothcost[:,:,:,c]=np.bincount(bd,weights=(energy*(inv[fi]+inv[ri])/2*(bi>0)).ravel(),minlength=np.prod(shape[:3])).reshape(shape[:3])
  total=hist.sum((0,1,2));target=ref['results'][law];assert abs(total.sum()-target['total'])<2e-12;assert abs(total[0]-target['OLD'])<2e-12;assert abs(total[1]+total[2]-target['twice_OLD_NEW'])<2e-12;assert abs(total[3]-target['NEW'])<2e-12
  def summaries(H,C):
   # Every threshold in the input, with all bandpairs and component orientations kept in NPZ.
   cum=H[::-1].cumsum(0)[::-1];cost=C[::-1].cumsum(0)[::-1];out=[]
   for k,q in enumerate(fractions):
    if k==0:continue
    a=cum[k];v=cost[k];diag=np.diagonal(a,axis1=0,axis2=1).sum(1);vd=np.diagonal(v,axis1=0,axis2=1).sum(1)
    out.append(dict(threshold=str(q),admitted_components=a.sum((0,1)).tolist(),invoice_components=v.sum((0,1)).tolist(),fixedband_admitted_components=diag.tolist(),fixedband_invoice_components=vd.tolist(),by_fixedband_admitted_components=[a[j,j].tolist() for j in range(nb)],by_fixedband_invoice_components=[v[j,j].tolist() for j in range(nb)]))
   return out
  directcost=hist*inv[:,None,None,None];r=dict(component_order=['OO','ON','NO','NN'],total_components=total.tolist(),total=float(total.sum()),zero_forward_components=hist[0].sum((0,1)).tolist(),zero_either_direction_components=both[0].sum((0,1)).tolist(),positive_forward_invoice_components=directcost.sum((0,1,2)).tolist(),positive_both_average_direction_invoice_components=bothcost.sum((0,1,2)).tolist(),bandpair_components=hist.sum(0).tolist(),forward_thresholds=summaries(hist,directcost),both_direction_thresholds=summaries(both,bothcost))
  r['positive_forward_energy']=float(hist[1:].sum());r['positive_forward_invoice']=float(directcost.sum());r['zero_forward_energy']=float(hist[0].sum());r['positive_both_energy']=float(both[1:].sum());r['positive_both_average_invoice']=float(bothcost.sum());r['zero_either_direction_energy']=float(both[0].sum());results[law]=r
  saved['rho_'+law]=rho;saved['forward_hist_'+law]=hist;saved['both_hist_'+law]=both;saved['both_invoice_hist_'+law]=bothcost
 outpath=Path(args.output);npz=outpath.with_name(outpath.stem+'_primitive.npz');np.savez_compressed(npz,**saved)
 result=dict(schema='R564.N5.1',scope='Physical ordered chi Gram only, not asymmetric Cstar head/stop/core weights or general L1 theorem',definitions=dict(u_BC='pop(oldmask_B & capmask_Caction)/old_count_B',u_CB='pop(oldmask_C & capmask_Baction)/old_count_C',ordered_energy='rho_a rho_b amp_a amp_b 1_phase_equal tent(log2(count_a/count_b)) pop(cap_a & cap_b)/64',direct_invoice='sum ordered E_ab/u_BC on u_BC>=threshold; zero/small complement separately retained',both_invoice='sum E_ab*(1/u_BC+1/u_CB)/2 where min(u_BC,u_CB)>=threshold; average two original directions, not free cheap-orientation selection',thresholds='all distinct exact rational u=k/c0 in complete frozen action input; no g grid'),input_optimizer=dict(path=args.optimizer,sha256=sha(args.optimizer)),input_n3=dict(path=args.n3,sha256=sha(args.n3)),code_sha256=sha(__file__),versions=dict(python=platform.python_version(),numpy=np.__version__),primitive=dict(path=str(npz),sha256=sha(npz),bytes=npz.stat().st_size),bands=bands,fractions=[str(f) for f in fractions],primitive_checks=dict(source_masks_exact=True,all_ordered_pairs=nv*nv,reverse_numerator_transpose_exact=True,zero_forward_OLD_components_zero=True,zero_reverse_OLD_components_zero=True,component_partition_exact=True,delta1_and_N3_decomposition_matched=True),results=results,cost=dict(total_seconds=time.perf_counter()-start,maxrss_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,solver_calls=0,action_count=nv,threshold_count=len(fractions)))
 outpath.write_text(json.dumps(result,indent=2));print(json.dumps(dict(cost=result['cost'],summary={k:{j:v[j] for j in ['total','zero_forward_energy','positive_forward_energy','positive_forward_invoice','zero_either_direction_energy','positive_both_energy','positive_both_average_invoice']} for k,v in results.items()}),indent=2))
if __name__=='__main__':main()
