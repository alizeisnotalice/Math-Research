# R564 N5: exhaustive true ordered-action overlap and conditional price

One frozen R562 n16 diagonal-cloud cube input was used: 64 sources, 332 empirical bulk parents, 1264 actual action states and all 17 original q bands. Original alpha/training/bulk are unchanged. This is a physical chi-energy diagnostic, not the asymmetric Cstar measure with head/stop/core weights. No optimizer, input search or dimension scan was run.

For ordered actions a=(B,g), b=(C,v), exact uint64 source masks give u_BC=pop(old_B & capture_b)/oldcount_B and u_CB=pop(old_C & capture_a)/oldcount_C. The genuine ordered Gram coefficient is rho_a rho_b (weight_B/R_B^16)(weight_C/R_C^16) times 1_(j_a=j_b) tent(log2(count_a/count_b)) pop(capture_a & capture_b)/64. All 1,597,696 ordered pairs are retained. The four receiver types are OO=old_B∩old_C, ON=old_B∩new_b, NO=new_a∩old_C, NN=new_a∩new_b. Forward numerator equals OO+ON, reverse OO+NO. u=0 forces the corresponding OLD contribution zero; the remaining received source can still produce NEW energy.

Every one of the 37 distinct rational overlap fractions actually present in the input is reported. No fixed threshold grid substitutes for them. Forward admission is u_BC>=tau, with invoice sum E_ab/u_BC on that branch. Both-direction admission is min(u_BC,u_CB)>=tau, with invoice sum E_ab*(1/u_BC+1/u_CB)/2. This is the average invoice of both original orientations of the symmetric chi diagnostic, not permission to select a cheap orientation in asymmetric Cstar. Zero/small overlap complements are explicitly excluded from each admission and remain unpaid until separately treated.

| Law | Complete E | E on u>0 | Invoice on u>0 | E on u=0 | Both-positive E | Both-positive average invoice |
|---|---:|---:|---:|---:|---:|---:|
| adaptive | 1.55859356862 | 1.55807841185 | 1.73000393326 | 0.000515156769535 | 1.55777488156 | 1.72904369804 |
| optimum | 1.30599243775 | 1.30406704433 | 1.39047357375 | 0.00192539341892 | 1.30295603737 | 1.38709740458 |
| delta1 | 2.14069111815 | 2.14069111815 | 2.49766283869 | 0 | 2.14069111815 | 2.49766283869 |

| Law/admission | E at tau=1/4 | Invoice at tau=1/4 | Coverage of full E | Fixed-band E | Fixed-band invoice |
|---|---:|---:|---:|---:|---:|
| adaptive/forward | 1.55394228832 | 1.70523115462 | 99.701572% | 0.348465723987 | 0.374601345651 |
| adaptive/both_direction | 1.5529860868 | 1.70209287323 | 99.640222% | 0.348308475428 | 0.374071420901 |
| optimum/forward | 1.30229487749 | 1.38013509481 | 99.716877% | 0.354030039743 | 0.36923191094 |
| optimum/both_direction | 1.30059867948 | 1.37557527642 | 99.586999% | 0.353855845332 | 0.368723588956 |
| delta1/forward | 2.13149542375 | 2.44313891469 | 99.570433% | 0.457424609125 | 0.508659803155 |
| delta1/both_direction | 2.13017213389 | 2.43803475889 | 99.508617% | 0.457163252035 | 0.507614975984 |

This changes the finite construction decision in a limited but useful way. Nearly all physical energy in this frozen input admits a moderate-overlap conditional relift; the positive-branch reciprocal price is about 11.04% above admitted energy for adaptive and 6.63% above it for optimum. The zero-forward branch is nonzero (0.000515157 adaptive, 0.001925393 optimum), and both-direction zero complement is 0.000818687 versus 0.003036400. It cannot be discarded. The increased zero branch after optimization shows that a lower total chi energy does not by itself remove relifting exceptions.

Restricting to completely included old sources is much more expensive in lost coverage. At u_BC=1, forward admitted energy is 1.26656947141846 (adaptive) and 1.15883981303560 (optimum); requiring both u directions equal one leaves 1.13634002307679 and 1.09447419903968. The corresponding exact 1/u invoices equal admitted energy, but all excluded positive energy still needs its own payer. Thus the data supports investigating conditional relifting with an explicit outside/tiny-overlap invoice, not full-cluster inclusion alone or free normalization.

Every reported admission/invoice keeps ordered OO/ON/NO/NN, source mass, center weights, true mass windows and phase equality. Crossband is included in complete totals. JSON gives fixed-band components and each individual band's diagonal contribution for every threshold. Full band-pair component histograms are stored in the companion NPZ, so crossband payments are reconstructible, not folded into a diagonal-only total. Under u=0, adaptive components are [0,0,0.000296337312952,0.000218819456582], and optimum [0,0,0.00105060310510,0.000874790313817]. This directly exhibits the forced-new branch with both original orientations retained.

## Frozen schema and reproducibility

Run `/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/ccu_r564_n5.py --optimizer /tmp/ccu_r562_optimizer.json --n3 /tmp/ccu_r563_n3.json --output /tmp/ccu_r564_n5.json`.

The companion `/tmp/ccu_r564_n5_primitive.npz` contains exact uint8 allpair components (OO,ON,NO,NN), numerator_forward/reverse, peraction uint64 capmask/oldmask, parent/count/old_count/phase/band/amp, and the original adaptive/optimum/delta1 rho. `forward_hist_LAW`, `both_hist_LAW`, and `both_invoice_hist_LAW` have dimensions (fraction,band_B,band_C,component). Fraction numerators and denominators are stored as integers. `amp` is the original parent center measure weight divided by R^16; no new source-dependent action is selected. Histograms and invoices are floating aggregates, while counts and threshold classifications are exact integer/rational operations.

Primitive checks: all 1264 capture counts and initial counts match exact popcounts, oldmask⊆capture for each action, reverse numerator equals forward transpose, four receiver classes partition each action-pair capture intersection, and zero-u implications hold on all pairs. The delta1 endpoint and adaptive/optimum OLD/NEW totals reproduce N3 to <2e-12. No phase-erased or shifted Gram replaces the real primary energy.

Only this finite input is covered. Tiny overlap can be much worse on other inputs; no general 1/u bound, mother absorption, source-cluster allocation, continuous Lebesgue quadrature accuracy or dimension-order inference follows. The diagnostic does not contain asymmetric Cstar head/stop weights and cannot certify their prices. N6 is independently checking selected finite aggregate arithmetic and normalization; its certificate scope remains separate.

Actual run: 0.427994 s, peak RSS 208863232 bytes (about 199.2 MiB), one process and zero solver calls. Versions: {'python': '3.12.14', 'numpy': '2.5.4'}. Input/code/NPZ SHA256 values are in JSON.

For every threshold, the zero/small excluded complement is exactly recoverable as total_components minus admitted_components, separately for every component and fixed-band diagonal. The complete band-pair histogram permits the same subtraction for every ordered band pair. Fractions are generated as a possible-ratio superset; a read-only check found all 37 actually occur in the frozen numerator/old_count matrix, so no redundant threshold is present in this input.


---

# R564 N6：来源交叠方向、条件核与选定阈值费用证书

## 1. 改变决策的有限结论

对 N5 的同一冻结1264动作、全部1597696个有序动作对，精确 bitset 与条件核方向核验通过；没有第二个 solver，也未新造完整 pair Gram。

对 adaptive 和 optimum 两个冻结 law，严格区间证明：

- `u_BC≥1/4` 分支保留的完整 all-band Gram 能量均 **超过99.7%**；
- `u_BC=0` 分支的完整能量均 **严格为正**，不能全删；
- 正 u 分支的 `1/u_BC` invoice 除以原完整能量，adaptive **大于1.1099**，optimum **大于1.0646**。

因此本有限输入说明“大多数真实 Gram 质量有不太小的旧来源交叠”，但不是免费归一：即使另删去零交叠分支，实算条件重权账仍高于原完整能量。这里的 invoice 是正、有序、对称物理 Gram 的有限诊断，不是带 asymmetric head/stop/core 的原 Cstar 预算；它不证明一般构造失败或成功。

数值依据为下文的严格 Fraction 外包加 Arb192 对数窗，而非把 N5 求和输出当证书。精确有理上下端点保存在 JSON。

## 2. bitset、四来源状态与方向

固定动作为 a=(p,g)、b=(q,v)。令 old_p 为原父 p 的初始来源集合，cap_a 为动作 a 捕获集合；old_p⊂cap_a。每个来源原子质量1/64，`c0p=|old_p|`、`ca=|cap_a|`。

两方向交叠必须是

`u_pq=|old_p∩cap_b|/c0p`，`u_qp=|old_q∩cap_a|/c0q`。

按 source 在两父中的旧/新状态，完整 common source 集分为

- OO=`old_p∩old_q`；
- ON=`old_p∩(cap_b\old_q)`；
- NO=`(cap_a\old_p)∩old_q`；
- NN=`(cap_a\old_p)∩(cap_b\old_q)`。

故准确有

`common_count=OO+ON+NO+NN`，

`numerator_forward=OO+ON`，`numerator_reverse=OO+NO`。

分母分别是原 old_count，不能改为 common_count、动作 ca 或 old–old 来源数。转置关系为 OO、NN 对称，ONᵀ=NO、forwardᵀ=reverse。

实际核验先把 N5 每动作 capmask、oldmask 与原 optimizer action_states 的64来源集合准确比较，再逐行用 uint64 AND + popcount 独立核全部1597696对的四类计数及两方向 numerator。没有只抽样少量 pair 冒充全量。所有代数关系准确通过。

若 forward=0，则 OO=ON=0，实际 common received source 必为 p 的 NEW；但 common_count 仍可正，不能把这批 pair energy当0。本次两个 law 的正零交叠能量正好展示了该区别。delta1 原子 law 的共同捕获源全旧，故其 forward-zero 正能量准确为0；另作结构核通过。

## 3. 条件核归一与原边缘的费用

在正交叠 `I=old_p∩cap_b` 上，令 d=|old_p|、m=|I|>0、u=m/d。原旧源均匀 law 每点质量1/d，条件 law U_I 每点1/m，因此

`dU_I/dU_old=1/u`（在 I 上，外侧为0）。

条件核自身总质量 `m·(1/m)=1`，但它不保持原旧来源边缘。完整恢复是

`U_old=u U_I+(1−u)U_(old\I)`。

脚本对所有实际 old_count（1,…,10、12）及每个m=0,…,d，合计78个有理案例，准确核该混合在内外每个原子上的权重仍为1/d。m=0 时不定义 U_I 或1/u，只保原外补集；m=d 时不定义空补集条件核。这正确处理零分母。

不能拿条件概率“已经归一”跳过1/u的 credit密度，也不能把两方向中便宜者当成同一原边缘的免费 coupling。N5 的双方 invoice 明确平均两个原方向，且另外保留任一方向为0的补集；N6按同一口径认证。此处没有声称两个不同交集自动属于某个共同 actual source cluster。

## 4. 被认证的完整有限 aggregate

本任务使用物理 ordered χGram：

`E_ab=ρ_aρ_b amp_a amp_b ·1_(j_a=j_b) ·tent(log2(ca/cb)) ·common_count/64`，

其中 `amp=parent_weight/R_parent^16` 是序列化 double，两个law的ρ也按序列化 double 的准确 dyadic解释。真实窗长度为 `tent(x)=(1−|x|)_+`；质量1/64在窗的 log差中抵消。所有 OLD/NEW、同/异 qband 都保留；另报 same-band部分以免误将它当全部。

选择的7项：full；forward-zero；forward≥1/4 admitted energy及其invoice；positive-forward invoice；either-direction-zero；positive-both 的两个方向 `[(1/u_pq+1/u_qp)/2]` 平均invoice。`u≥1/4` 用整数 `4 numerator≥old_count` 准确判，不使用float阈值。

以下为可读近似值，完整严格区间在 JSON，表内普通小数不是向外舍入证据。

| 全部 band aggregate | adaptive | optimum |
|---|---:|---:|
| full energy | 1.558593568624 | 1.305992437747 |
| forward-zero energy | .0005151567695 | .0019253934189 |
| forward≥1/4 energy | 1.553942288319 | 1.302294877487 |
| forward≥1/4 invoice | 1.705231154616 | 1.380135094807 |
| positive-forward invoice | 1.730003933257 | 1.390473573754 |
| either-direction-zero energy | .0008186870636 | .0030364003789 |
| positive-both average invoice | 1.729043698038 | 1.387097404576 |

例如严格的有理端点比值区间给：

- adaptive `forward≥1/4 energy/full ∈[.997015719203…, .997015719910…]`；
- optimum 对应比值 `∈[.997168773252…, .997168773960…]`；
- adaptive positive-forward invoice/full `∈[1.109977589712…,1.109977590500…]`；
- optimum 对应比值 `∈[1.064687308343…,1.064687309098…]`。

这些带省略号区间仅展示准确端点的前缀；JSON 保存完整分数。第1节的99.7%、1.1099、1.0646阈值另用 Fraction 对完整端点严格比较通过。

同 band full energy仅约 `.349378301686`、`.354392112274`。全部相差甚大，说明没有从有限数据中消去 cross-band费用。所有invoice也分别保留same-band与all-band两项，不能只选较小者。

## 5. 严格求和误差账和 Arb窗

这不是把numpy求和误差忽略：正 prefactor 按准确整数 `(ca,cb,same_band)` 分组，先计算无 log 的非负系数 C。mass count至多64，真实tent对每个组是同一准确数。

采用 binary64单位舍入 `ε=2^(−53)`。一个组最多1597696项，含每项乘法、必要正除法/平均以及求和路径的保守最大操作数取

`m=1264²+16=1597712`，`γ=mε/(1−mε)≈1.77381664943e−10`。

标准非负浮点误差递推给 `|C_hat−C|≤γ C`，因此

`C_hat/(1+γ)≤C≤C_hat/(1−γ)`。

这里C指由序列化准确dyadic amp/ρ、准确计数和准确条件权构成的系数。没有 cancellation。`np.bincount`内部按何种加法顺序执行都不妨碍此保守界，因为任一路径不超过m步；若实际采用更短的树式加法，只会缩小误差。

脚本检查binary radix2、53位mantissa、round-to-nearest，全部输入/中间正权finite且非负。更强的有理guard检查 `min_positive_rho·min_positive_amp≥2^(−500)`，随后每个非零乘积至少约2^(−1000)，乘正common_count/64后至少2^(−1006)，排除underflow；其余浮点条件权≥1，全部仍finite。mask乘0/1及除64是准确操作；16额外步对实际每项算术有充分余量。

对每个质量比，若 `max(ca,cb)≥2min(ca,cb)`，窗长度准确为0；若相等则准确为1；其余用 Arb192计算 `1−log2(max/min)`，转换成准确有理lower/upper。将这些窗界与系数组界相乘、全部用 Fraction累加，得到 JSON 的最终严格端点。最大full能量区间宽约 `5.53e−10`；本任务要区分的费用差约10^(−1)，远大于这份误差账。

与 N5 相应5项float摘要逐项比较均落在认证区间内。这证明所选诊断在该误差尺度上稳定；不是对 N5 全部37阈值/全部代码路径的逐项证明，也没有把 N5矩阵理解成理想连续几何。

## 6. 来源、实跑和不可迁移的范围

本任务复用 N5 的单次共享 primitive 文件，全部 exactpair counts没有再做source几何或QP。实际命令：

```
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/ccu_r564_n6.py --n5 /tmp/ccu_r564_n5.json --primitive /tmp/ccu_r564_n5_primitive.npz --optimizer /tmp/ccu_r562_optimizer.json --n3 /tmp/ccu_r563_n3.json > /tmp/ccu_r564_n6.json
```

Python3.12.14、NumPy2.5.4、python-flint0.9.0、Arb192；单进程约 `.338` 秒。输出记录解释器实际路径和版本。没有第二solver、没有维数扫描、没有新增source输入。

脚本 SHA256：`99bc46e9f992377abad2012edfdb6972e65648e9becace3bc3d785d23fcd2662`。

N5 JSON SHA256：`ca9f492fd3622fedc589cec453bec3e9a8140eba730fa4db59bb8d1133cf011e`。

共享 primitive SHA256：`3aa5e1b5395e99d2120d3b5c99bcfb56cd6fa7f31c41439ef1ba57aac14d1f50`。

证书只覆盖序列化 source bitsets、固定ρ/amp及准确count-log窗所定义的有限object。原 box边界的几何判定、proposal density、训练α、真正Lebesgue中心和 μ=f dx 的误差均未由本证书控制。原 Cstar 的真实非对称head/stop/core权、双M分母与信用来源也未进入这个对称χGram诊断。故不能由本次高交叠比例宣称完整relift预算可付；零/小u补集和1/u归一费用仍须在原完整对象上付款。有限交付后停止。
