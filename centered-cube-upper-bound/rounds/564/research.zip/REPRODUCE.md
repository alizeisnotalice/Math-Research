# R564 portable reproduction — no optimizer or PDF

Actual interpreter: `/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python`.
Python 3.12.14, NumPy 2.5.4, SciPy 1.18.1 (dependency n3), SymPy 1.14.0 (algebra verification), python-flint 0.9.0 / Arb192.

Extract `optimizer.json` from committed `centered-cube-upper-bound/rounds/562/research.zip`
(commit 5437711af449b8a8132a866334fd323562fbe9d6; archive SHA256 9633cc4d7c793b15b63eea3fa89dea300ddbab6c4568aa9923b6f838dd0e6e09).
Its SHA256 is edf8f993d1511e1735621e8855311af8243f0f06231da52789c07cc06a47bbe4.
Extract `n3.py` from committed `rounds/563/research.zip`
(commit ce025dc55748ef1e8985bc468a7b6cd4ed40615b; archive SHA256 31c32fa46a10e0708482b348bc77e3a00e97f9e771ee453b1586ac390a8ccd89).
Its SHA256 is 41c262b0e155de9d29aa05eb1c8802ec09a792f4393d373a278e29d0455fb73d.
Put these beside this package's n5.py and n6.py in a writable work directory.

```sh
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python n3.py --optimizer optimizer.json --output n3.json
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python n5.py --optimizer optimizer.json --n3 n3.json --output n5.json
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python n6.py --n5 n5.json --primitive n5_primitive.npz --optimizer optimizer.json --n3 n3.json > n6.json
```

These exact commands were actually run from /tmp/ccu_r564_repro using bytes extracted from the committed archives.
The regenerated n5.json `results` matched all original results exactly, and n6.json `results`, `primitive_checks` and `conditional_normalization_cases` matched exactly.
Runtime, absolute path and enclosing-file hashes change with execution; mathematical outputs do not.
Compare strict_certificate.json for every rational interval and numerics_summary.json for decision totals.
The full n5.json and its NPZ are deliberately regenerable rather than duplicated in Git; all 37 threshold/band/OLD-NEW data remain reproducible.

The source primitive is finite empirical quadrature, not continuous Lebesgue input.
N5 computes floating physical chi diagnostics; N6 certifies selected finite aggregate arithmetic using exact source counts and serialized dyadic amplitudes/laws plus Arb count-log windows.
It does not certify the original asymmetric Cstar, geometric quadrature, old alpha, ideal action feasibility, or a dimension-uniform theorem.
No optimization, parameter search, new dimension/input sweep, or PDF compilation is part of reproduction.
