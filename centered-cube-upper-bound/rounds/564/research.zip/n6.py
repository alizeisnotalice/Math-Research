"""R564 N6: exact shared bitsets and bounded aggregate roundoff + Arb certificate.
No QP; no new source geometry or full pair Gram matrix is constructed.
"""
from pathlib import Path
from fractions import Fraction as F
import argparse,json,hashlib,platform,time,sys,math
import numpy as np
import flint
from flint import arb,ctx
ctx.prec=192

def A(x):return arb(x.numerator)/x.denominator if isinstance(x,F) else arb(x)
def sha(p):return hashlib.sha256(open(p,'rb').read()).hexdigest()
def log_window(c,d):
    if max(c,d)>=2*min(c,d):return F(0),F(0)
    if c==d:return F(1),F(1)
    length=1-(A(F(max(c,d),min(c,d))).log()/arb(2).log())
    assert length>0
    return F(str(length.lower().fmpq())),F(str(length.upper().fmpq()))
def interval_summary(lo,hi):
    assert lo<=hi
    return dict(lower_exact=str(lo),upper_exact=str(hi),display=[float(lo),float(hi)],width_display=float(hi-lo))
def certify_sum(terms,codes,lengths,ngroups,gamma):
    assert terms.dtype==np.float64 and np.all(np.isfinite(terms)) and np.all(terms>=0)
    pos=terms[terms>0]
    if pos.size:assert pos.min()>=sys.float_info.min
    sums=np.bincount(codes,weights=terms.ravel(),minlength=ngroups)
    lo=hi=F(0)
    for k,s in enumerate(sums):
        if not s:continue
        q=F(float(s));ll,lh=lengths[k]
        lo+=q/(1+gamma)*ll;hi+=q/(1-gamma)*lh
    return interval_summary(lo,hi)
def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--n5',type=Path,default=Path(__file__).resolve().parent/'n5.json');ap.add_argument('--primitive',type=Path);ap.add_argument('--optimizer',type=Path);ap.add_argument('--n3',type=Path);args=ap.parse_args();start=time.perf_counter()
    meta=json.load(open(args.n5));pp=args.primitive or Path(meta['primitive']['path']);npz=np.load(pp);op=args.optimizer or Path(meta['input_optimizer']['path']);orig=json.load(open(op));n3path=args.n3 or Path(meta['input_n3']['path']);n3=json.load(open(n3path))
    assert sha(pp)==meta['primitive']['sha256']
    cap=npz['capmask'];old=npz['oldmask'];new=cap&~old;comp=npz['components'];nf=npz['numerator_forward'];nr=npz['numerator_reverse'];count=npz['count'];c0=npz['old_count'];phase=npz['phase'];band=npz['band'];parent=npz['parent'];amp=npz['amp'];nv=len(cap);states=orig['summary']['action_states'];parents=orig['summary']['frozen_parent_records'];initial={s['parent']:sum(1<<z for z in s['receiver_atoms']) for s in states if s['kind']=='initial'}
    assert comp.shape==(nv,nv,4) and nf.shape==nr.shape==(nv,nv) and len(states)==nv
    assert np.all((old&~cap)==0)
    for j,s in enumerate(states):
        p=s['parent'];assert int(parent[j])==p and int(cap[j])==sum(1<<z for z in s['receiver_atoms']) and int(old[j])==initial[p]
        assert int(count[j])==int(cap[j]).bit_count() and int(c0[j])==int(old[j]).bit_count()==parents[p]['old_count']
        assert int(phase[j])==s['phase'] and int(band[j])==parents[p]['band']
        assert float(amp[j])==parents[p]['weight']/parents[p]['R']**16
    # Independent per-row exact bitset checks; reuses shared arrays, no Gram.
    for i in range(nv):
        for k,(x,y) in enumerate([(old,old),(old,new),(new,old),(new,new)]):assert np.array_equal(comp[i,:,k],np.bitwise_count(x[i]&y))
        assert np.array_equal(nf[i],np.bitwise_count(old[i]&cap))
        assert np.array_equal(nr[i],np.bitwise_count(cap[i]&old))
    wide=comp.astype(np.uint16);assert np.array_equal(nf.astype(np.uint16),wide[:,:,0]+wide[:,:,1]);assert np.array_equal(nr.astype(np.uint16),wide[:,:,0]+wide[:,:,2]);assert np.array_equal(nf.T,nr)
    assert np.array_equal(comp[:,:,0].T,comp[:,:,0]) and np.array_equal(comp[:,:,3].T,comp[:,:,3]) and np.array_equal(comp[:,:,1].T,comp[:,:,2])
    common=wide.sum(2);assert np.all(common<=64)
    assert np.all(wide[nf==0][:,:2]==0) and np.all(wide[nr==0][:,[0,2]]==0)
    # Every conditional normalization by count, plus mixture equality on/outside I.
    normalization_cases=[]
    for den in sorted(set(map(int,c0))):
        for num in range(den+1):
            u=F(num,den)
            if num:
                assert num*F(1,num)==1 and F(1,num)/F(1,den)==1/u
                assert u*F(1,num)==F(1,den)
            if num<den:assert (1-u)*F(1,den-num)==F(1,den)
            normalization_cases.append(dict(intersection_count=num,old_count=den,u=str(u),density_ratio=str(1/u) if num else None))
    assert sys.float_info.radix==2 and sys.float_info.mant_dig==53 and sys.float_info.rounds==1
    operation_bound=nv*nv+16;unit_roundoff=F(1,2**53);gamma=operation_bound*unit_roundoff/(1-operation_bound*unit_roundoff)
    B=int(count.max())+1;masscode=(count[:,None].astype(np.int64)*B+count[None,:]).ravel();same=(band[:,None]==band[None,:]);codes=masscode+same.ravel().astype(np.int64)*B*B;ngroups=2*B*B
    lengths={}
    for s in [0,1]:
        for c in sorted(set(map(int,count))):
            for d in sorted(set(map(int,count))):lengths[s*B*B+c*B+d]=log_window(c,d)
    # Zero length for unused group codes.
    lengths={k:lengths.get(k,(F(0),F(0))) for k in range(ngroups)}
    legalphase=phase[:,None]==phase[None,:];forward_positive=nf>0;reverse_positive=nr>0;gequarter=(nf.astype(np.uint16)*4>=c0[:,None])&forward_positive
    invf=np.divide(c0[:,None],nf,out=np.zeros((nv,nv),dtype=np.float64),where=forward_positive);invr=np.divide(c0[None,:],nr,out=np.zeros((nv,nv),dtype=np.float64),where=reverse_positive)
    bothfactor=(invf+invr)/2*((forward_positive&reverse_positive))
    results={}
    for law in ['adaptive','optimum']:
        rho=npz['rho_'+law];expected=n3['rhos'][law];assert np.array_equal(rho,np.array(expected)) and np.all(rho>=0)
        assert F(float(rho[rho>0].min()))*F(float(amp[amp>0].min()))>=F(1,2**500)
        w=rho*amp;assert np.all(np.isfinite(w)) and np.all(w[w>0]>=2.0**-500)
        # Every nonzero outer product >=2^-1000; count/64 >=1/64.
        # Hence nonzero unpriced base terms >=2^-1006, excluding underflow.
        base=(w[:,None]*w[None,:])*common/64*legalphase
        for z in [invf,invr,bothfactor]:assert np.all(np.isfinite(z)) and np.all(z>=0)
        metrics={'full':base,'zero_forward':base*(~forward_positive),'forward_ge_1_4_energy':base*gequarter,'forward_ge_1_4_invoice':base*gequarter*invf,'positive_forward_invoice':base*invf,'zero_either_direction':base*(~(forward_positive&reverse_positive)),'positive_both_average_invoice':base*bothfactor}
        rr={}
        for name,terms in metrics.items():
            rr[name]=dict(all_bands=certify_sum(terms,codes,lengths,ngroups,gamma))
            rr[name]['same_band']=certify_sum(terms*same,codes,lengths,ngroups,gamma)
        # Compare only N5's fixed aggregate summaries; not a certificate of its code.
        checkmap={'full':'total','zero_forward':'zero_forward_energy','positive_forward_invoice':'positive_forward_invoice','zero_either_direction':'zero_either_direction_energy','positive_both_average_invoice':'positive_both_average_invoice'}
        for our,their in checkmap.items():
            value=F(float(meta['results'][law][their]));iv=rr[our]['all_bands'];assert F(iv['lower_exact'])<=value<=F(iv['upper_exact'])
        full=rr['full']['all_bands'];flo,fhi=F(full['lower_exact']),F(full['upper_exact'])
        ratios={}
        for key in ['zero_forward','forward_ge_1_4_energy','positive_forward_invoice','zero_either_direction','positive_both_average_invoice']:
            iv=rr[key]['all_bands'];ratios[key+'_over_full']=interval_summary(F(iv['lower_exact'])/fhi,F(iv['upper_exact'])/flo)
        rr['decision_ratios']=ratios
        results[law]=rr
    # delta1: no forward-zero or either-zero positive source energy structurally.
    rd=npz['rho_delta1'];support=rd>0;assert all(states[j]['kind']=='initial' for j in np.flatnonzero(support))
    supportpairs=support[:,None]&support[None,:];assert np.all(common[supportpairs&(nf==0)]==0)
    out=dict(python=sys.executable,python_version=platform.python_version(),numpy=np.__version__,flint=flint.__version__,arb_precision_bits=ctx.prec,code_sha256=sha(__file__),input_n5_sha256=sha(args.n5),primitive_sha256=sha(pp),primitive_checks=dict(actions=nv,ordered_pairs=nv*nv,all_four_bitset_counts_independently_checked=True,u_forward_and_reverse_exact=True,conditional_mixture_normalizations_checked=len(normalization_cases),delta1_forward_zero_energy_exact=0),conditional_normalization_cases=normalization_cases,roundoff_certificate=dict(unit_roundoff=str(unit_roundoff),max_rounding_operations_per_sum_path=operation_bound,gamma_exact=str(gamma),gamma_display=float(gamma),method='Nonnegative normal binary64 sums grouped by integer mass pair and same-band flag; C_hat/(1+gamma)<=C_exact<=C_hat/(1-gamma). Arb192 bounds only exact count-ratio window logarithms.'),results=results,elapsed_seconds=time.perf_counter()-start,scope='Exact shared source bitsets and conditional normalizations; rigorous selected aggregate intervals for serialized dyadic amp/rho plus exact count-log windows. No ideal geometry/proposal/alpha or asymmetric Cstar/coupling-payment certificate; no QP and no full pair Gram reconstruction.')
    print(json.dumps(out,indent=2))
if __name__=='__main__':main()
