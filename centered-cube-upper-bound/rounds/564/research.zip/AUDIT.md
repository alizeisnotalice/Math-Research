# R564 final independent verification ledger

General theorem: NOT CLOSED. The new mass-eligible cluster subbudget is independently proved/audited; the complete small-coverage/matching-deficit payer remains open. A changed remainder label is not counted as progress.

- Astra independent screening preceded author proofs; later audited full original random-partition and mass-eligible cluster arguments.
- Sol proof independently audited low-growth direct Cstar payment; exact I_B normalization removes an avoidable Lambda but does not reduce the full-row K.
- Sol ledger and parent checked one-credit assembly, zero cases and half absorption.
- Sol distribution audited N5 ordered physical features; Sol certificate independently checked exact masks and finite interval aggregates.
- Sol recovery checked complete marked marginals, singular/zero handling and the common-cluster coupling transfer; its final audit is appended below.
- Parent independently reproduced portable archived computation and checked exact decision thresholds and symbolic coefficients (verification.json).

No original full-scale/terminal/entrance gap is erased by these checks. No PDF was compiled.



---

## ccu_r564_audit.md

# R564 独立审查：同一旧 score 下的条件提升、方向选择与对角复用

本段先读 R564 合同及其冻结定义，不读本轮作者稿。审查对象始终是所有真实 ordered tuples、所有旧/新来源、phase/window/head/first-stop 的完整 Cstar。仅分析插入和权重可变；动作及原 Li、alpha、Qg 不变。本文不是新的全局付款证明。

## 1. 最弱完整付款合同

记原联合测度 dM=dΞ w_x(B) k_B(z,σ)dB μ(dz)dσ；其总质量为 Cstar。冻结旧 score 基准为

 dν(B,z,σ)=k_B(z,σ)dB μ(dz)dσ，
 Qfr=∫Li dν=Qg−Erem。

允许重新插入的非负扩展测度 dMtilde，只要逐个原 ordered tuple 的总质量不变。不能只匹配一个投影后的母量而漏掉真实 head/stop 或反向项。对任意正分析权 a，若 Li>0 在所处理测度上几乎处处，则

 Cstar² ≤ C[a] V[a]，
 C[a]=∫a Li dMtilde， V[a]=∫(a Li)⁻¹ dMtilde。

完整目标的最弱数值合同是同一分支总和满足 C[a]≤Qg（更安全地 ≤Qfr）及 V[a]≤L W；这不是已证结论。以冻结 score 支付的可检查充分合同，是 a dMtilde 投影到 (B,z,σ) 后被 dν 支配。也可只证明其 Li 加权积分上界；点态支配是较强条件，不应误报为唯一必要条件。

分支 a、方向、簇权允许依赖实际来源作为分析工具，但必须可测且不改变先于 receiver 冻结的动作。全部分支须用同一份信用：Σ_j C_j≤Qg。由分支 Cauchy 得

 Σ_j sqrt(C_j V_j)≤sqrt((Σ_j C_j)(Σ_j V_j))。

给每个分支重新使用一整份 Qg 会产生真实分支费用，不能漏掉。若采用 2Cstar≤ζQg+L W，代入母账后的严格吸收条件为 ζJ/d²<1。只证某个正分支仍须保留余项；已付 low-Li 可先分离，但阈值必须指原 Li。

## 2. 条件旧来源提升：总质量不变，score 费用不自动不变

固定 (B,C,v)，令 I=Q_B(1)∩Q_C(v)、u=μ(I)/m_B。这里 μ、m_B 取原冻结 insertion 的同一实际旧来源，μ(Q_B(1))=m_B；源格索引 i 始终保留于相应父族。旧概率 P_B=k_B μ(dz)dσ/(t_B q_B) 含原长度 1 的 σ 窗。

对 u>0，P'_BC=P_B|I/u，密度 f=1_I/u；窗口 σ 不移动。逐 tuple ∫f dP_B=1，故 dMtilde=f dM 保住该 tuple 总质量。它不意味着 ∫Li dP'_BC=∫Li dP_B。精确新均值为 E_PB[Li1_I]/u；除非证明真实相关性，只有粗上界 E_PB[Li]/u，不能免费沿用旧 alpha。

以原联合源空间表示，新的信用行是

 R'_a(B,z,σ)=∫a(x,B,z,σ) f_xB(z) w_x(B)dΞ(x)，
 C[a]=∫Li R'_a dν。

完整的 R'_a≤1 足以保原 Qfr。旧的 ∫a w dΞ≤1 本身不够。对于已有原合法 a0，保守选 a=u a0 可消除信用中的 1/u，得到 R'_a≤R_a0；但另一项变为

 V[a]=∫ 1_I/[u² a0 Li] dM。

该显式费用必须继续积分。密度平方的无权旧概率平均恰为 ∫f²dP_B=1/u。注意：这是该表示/保守选择的费用，不是任何条件耦合都必有 1/u 的不可避免下界；实际 Li 相关性或更好的联合 a 可能改善，必须证明。不能因 tiny-u 就宣布目标不可能，也不能把 1/u 隐去。

u=0 时此条件概率不存在。若真实 receiver y∈Q_B(g)∩Q_C(v)，则 y∉Q_B(1) 对该 receiver 的 μ 测度几乎处处成立。这是 a.e. 强制 new-capture，不是每个边界点的点态声明，更不推出 κ_B(g)−1 有统一正下界：实际 core 可以很小。该分支保留其全部实际质量和费用。

## 3. 选择“便宜方向”的准确量词

交换 ordered pairs 只有在同时推送动作 g/v、head、stop/core、窗口、来源及全部权重时才是同一积分的重写。一般 A_BC≠A_CB。不能把 A_BC+A_CB 换成较小的一个，也不能因 u_CB较大就用 m_C/score_C 支付原 B 向贡献而不核转移后的旧 score 边际。

若为同一个 tuple 构造两个都已证明保持总质量的插入选项，可以可测选择或分数混合；但所选择的是联合信用/费用对 (C,V)，不能只最小化 V 而忽略 C。若把两个原方向统一搬到选中的方向，必须证明总权重 A_BC+A_CB 全部转移、原 score 的列/行容量仍满足第1节合同。某方向原权重为零亦不能凭空将另一个方向变为该合法方向。

因此可接受的最小桥是：完整 ordered-tuple 质量守恒 + 原 score 加权边际预算 + 所有零/小交叠余项 + 可积来源费用。这四项缺一不可；单独的 overlap 比或空间对称性不是该桥。

## 4. Singular diagonal：先积分真实 y，再审旧边际

对固定 x 令 z=y 的 δ_y 在非原子 μ 下通常奇异，因此不能写成相对 P_B 的有限密度，也不能套用上一节 1/u 公式。然而这并不自动使 diagonal 不合法：dΞ 本来含真实 μ(dy)，先对 y 积分后的旧来源边际可能绝对连续。

在 old-receiver 分支 y∈Q_B(1)，写 dΞ=dχ ξ_χ(y) μ(dy)，其中 χ 包含 C,v,g,T 及其真实门。将该分支旧源提升为 z=y、σ仍取 B 的完整长度1窗口。其总质量仍为该 old 分支原质量。对 a 可依赖 B,χ,z,σ，投影相对 dν 的密度为

 D_a(B,z,σ)=m_B ∫a(B,χ,z,σ) w_(χ,z)(B) ξ_χ(z)dχ， z∈Q_B(1)。

这里 m_B=t_Bq_B/(t_B/R_B^n)=q_BR_B^n，不能漏掉。D_a≤1 足以保原旧 score；或直接证明 ∫Li D_a dν≤所分配信用。原 r(B)≤K 仅给

 ∫_{Q_B(1)}D_1(B,z,σ) μ(dz)/m_B ≤ r(B)≤K

（a=1 时无 σ 依赖），并不提供 D_1 的点态帽，更不自动给 Li 加权帽。所需新增输入正是 Li 与 diagonal 行负载的相关性/集中付款。取某个依赖 B 的缩放可形式上归一信用，但其倒数必须进入 V，不能把它命名为归一化后删除。

new receiver y∉Q_B(1) 时，z=y 的边际落在该 B 的旧 k_B 支撑外，不能由同 B 的旧 score 直接支配。若改用别的旧父 C 或其他来源，需要完整源边际转移及其预算；不允许把 Li 或 alpha 换成新定义。零 Li、无限倒数、μ-null 上的代表值均须在实际投影测度上处理，不可仅用原 ν-a.e. 声明覆盖任意奇异耦合。

## 5. 待作者稿的决定性核验点与本轮界限

收到核心稿后只核：其实际新测度是否逐 tuple 质量守恒；原 score 加权边际究竟是哪一个；条件化/方向/diagonal 的所有倒数费用是否进入同一 V；零交叠和不共同包含来源是否全部付款；最后是否达到 ζJ/d²<1 或完整 Cstar²≤Qg·polylog·W。共同旧来源落在交集，只说明该 tuple 的两源可位于同一接收 cube；不自动给全局互不相交簇或一次簇质量预算。

当前结论：有可能保留同一原 Qg，但必须提交上述真实加权边际证明。没有从合同推出一般不可能，也没有现成免费 relift。当前仅完成独立审查标准；不算 full-budget 改善，不扫描泛反例，等待具体关键稿。

实际工具：使用指定本机 Python/SymPy 验算 a=u a0 的信用抵消残差为0、付款密度为1/(Li a0 u²)、密度L²平均为1/u；并展开分支合并 Cauchy 差额及母账吸收系数。仅为这些精确代数身份的工具证据，不替代上述全局边际/几何证明。

## 6. Global random-grid：独立标准与作者关键式核验

收到 cover 的具体新构造后，已回读 R563 crosslayers 的 CL1–CL11，尤其 CL6 的全部常数来源。此构造并不重新条件化旧来源；它在真实完整原联合测度上随机分配共同来源簇。以下先核作者发送的关键公式，稿件落盘后另作最终确认。

### 6.1 使用的确切来源费及同一信用

令原完整行帽为 K=G C_*(G)Λ>0。取全局常数分析权 a=1/K，故 R_a=r_B/K≤1；原动作、Li、alpha 均不变。这是 R563 已有的合法完整收费，不是把另一变量 a 的 Va 改名。取 τ=1/Dclk，在

 dν_hi=K 1_{Li>τ} dM/Li

上定义 Vhi=∫dν_hi。它包括全部 old/new、真实 phase/window/head/stop 条件；所有低 Li 项仍由原 C_low≤KτDclkW 支付。

CL6 虽以 s_x=1/a_x≤A=1+K 展示，但其来源费证明只用该上界、T 独立性及真实 F/Li≤1。因此可原样上界此处 s=K≤A，并保守使用原 Lcl。没有将此前的变量权 Va 粗帽转移给新费用。若 K=0 则原行及 Cstar 为零，单独作平凡分支。

固定 grid 的资格事件不依赖 B,T,σ，因此可先在同一内父积分合并全部 T，保留原 F，再乘资格事件及 1_{Li>τ}。之后才用 F/Li≤1。原外系数 γt_Cq_C/(I_CM_C(v)²)、真实 μ(dy)μ(dz)和旧 σ 支撑均不变。

### 6.2 全局法则和精确概率

设 Z=log(8b/a)。只抽取一次 ℓ∈[a/8,b]，密度 dℓ/(ℓZ)，再取 shift s 在 [0,ℓ)^n 均匀。所有源格及所有父/动作共享此法则。对每个 realization，H_(i,k)=C_i∩[s+ℓ(k+[0,1)^n)] 是可数共同 μ-互斥簇族，正质量簇的总质量至多 W。它不按 receiver 或 tuple 重新抽取，也不按尺度新发 W。

资格 E_grid(C,v,y,z) 要求 y,z 同一 grid cell，且整个该 cell 的闭包包含于实际 Q_C(v)。这比 CL5 所需 H_(i,k)⊂_μ Q_C(v) 更强，所以是合法正子项。空质量格对真实双源积分没有贡献。因为 μ≪Lebesgue，源落格边界可忽略；即使 Q 取开盒，闭 cell 恰碰边界的 shift 参数集合亦为零测，故不会改变下式概率。

对固定 ℓ 和 Q=∏(Q_j^−,Q_j^+)，共同 cell 的下端点第 j 坐标需落在

 [ max(max(y_j,z_j)−ℓ,Q_j^−), min(min(y_j,z_j),Q_j^+−ℓ) ]。

因此精确概率为

 p_(Q,ℓ)(y,z)=∏_j [min(min(y_j,z_j),Q_j^+−ℓ)−max(max(y_j,z_j)−ℓ,Q_j^−)]_+/ℓ，
 p_Q(y,z)=∫_[a/8,b] p_(Q,ℓ)(y,z) dℓ/(ℓZ)。

坐标乘积来自 shift 的独立均匀坐标，不假设 μ 的来源坐标独立。Q 的实际可测侧长与中心都保留；不以 enlarged cube 代替。

### 6.3 一次 W 预算与近距概率

对每个固定 grid，资格事件是 CL5 的正子项，CL6 给

 ∫E_grid dν_hi≤LclW，
 Lcl=[2GΛγ³/(γ−1)] S r_band (1+K) [4+2h+log_γ Kmax]。

CL6 的中心容量是实 Lebesgue 中心容量 vγm/q；两个实际来源同簇给 μ(H)²；实际 M 质量档几何和支付一次 μ(H)。旧 σ 在同档总跨度为4+2h+log_γKmax，动作端点给 ∫vω=2G、∫ω=Λ。所有参数必须保持显式，只有这些参数本身属于目标 polylog 配置时才能称为 polylog 费用。

由 Tonelli，完整 weighted payer 成立：∫p_Q dν_hi≤LclW。该步骤一次全局平均，不重复信用或 W。

设实际外盒 Q 侧长 R∈[a,b]。若 y 在 Q 的中央半盒且 ||y−z||_1≤R/16，则对所有 ℓ∈[R/8,R/4]，y 距每面至少 R/4≥ℓ。所有包含 y 的 cell 都位于 Q 内；同 cell 概率为 ∏(1−|y_j−z_j|/ℓ)_+≥1−||y−z||_1/ℓ≥1/2。尺度区间全在全局支持 [a/8,b] 内，其对数长度为 log2。因此

 p_Q(y,z)≥p0:=log2/[2log(8b/a)]。

此结论无需 z 另设中央半盒条件，原给定 l1 距离已足够；若稿件同时要求两者中央则只是较强子事件。

### 6.4 完整母账和补集

任取0<ε≤1，Ωε={p_Q≥ε}，则 Vhi(Ωε)≤LclW/ε。其补集保留真实

 Vbad=∫_{Li>τ,p_Q<ε}K dM/Li。

在同一 a=1/K 下分配信用 C_good、C_bad，C_good+C_bad≤Qg，故

 C_hi²≤Qg [LclW/ε+Vbad]，
 E≤2KwW+2KτDclkW+2sqrt(Qg[LclW/ε+Vbad])。

也可保留精确分数分解 p+(1−p)，得到 Vhi=∫p dν_hi+∫(1−p)dν_hi；两个部分仍只共用一份信用。除以 p 后的 conditional grid 是另一表示，必须计 1/p，不能由 weighted payer 推整个 Vhi≤LclW。

补集包含所有旧 z∉Q_C(v) 的 p=0 部分、边界附近或距离较大导致的小 p、及其他所有未满足资格的真实来源对。近距正支项不证明该补集为空或足够小；μ 可以把大部分实际来源质量放在这些区域。此处不构造泛反例，也不否定目标。新结果是一个完整定义的可付正子费，尚非 full high-source 付款或最终吸收。

实际工具：指定本机 SymPy 实跑确认 ∫_[R/8,R/4]dℓ/ℓ=log2、全局 π 归一化为1、CL6 系数从中心/质量/动作因子化简残差为0。概率与 Tonelli/共同信用部分为解析核验，工具不替代其证明。

### 6.5 allocation 定稿复核

已读实际落盘 `/tmp/ccu_r564_allocation.tex`。A1–A13 的 global grid weighted payer、精确概率、内部 p>0、中央半盒概率及同一完整高源费用均 PASS。作者在 A4 正确直接采用乘子 K，因此常数可从上文保守 Lcl 的 (1+K) 改为 K，即 Ccl(K)=[2GΛγ³/(γ−1)]Sr_band K Lσ；这是对同一证明的合法改善。A12 同时要求 y,z 中央，比独立审查所需略强，不影响结论。A13 在 b/a_geom≤2 时 p0≥1/8 的计算正确。

A14 的低增长直接费是外部引用，不属于本次 grid 新估计的独立证明；在其已获相应审查的前提下，A15–A16 的先剔除互斥分支、同一 Qg 合并及 Vbad 定义正确。A17–A18 只诊断先放松可变半径后的中心边界包络，不构成真实全部约束反例，稿件保持了此范围。grid 本项到此确认，不重复扩展。

## 7. 正式独审：实际质量条件 h_H≤cM 代替整簇包含

按父代理新增指定，先独立推导，再全文核验已落盘 `/tmp/ccu_r564_realization.tex`。判定：定理 real:masslemma、R1–R6 与所述范围 PASS，无需修改。它支付了旧来源 z 可在接收盒外的实际正子费，严格扩大了此前整簇包含条件允许的覆盖范围。

### 7.1 量词及精确被付对象

一族 H_i 必须固定、可数、来源真实 μ-互斥，H⊂C_i 且 h_H=μ(H)>0；其总质量至多 W。c>0 为同一给定参数，不允许对每个 tuple 免费选择不同 c。事件是存在同一簇 H 满足 y,z∈H 且 h_H≤cM_C(v)。作者没有假设 H⊂Q_C(v)，没有把 receiver y 当作旧来源 z。收费始终是完整原测度上的常数 a=1/K；定理直接支付 K∫_E,Li>0 dM/Li，故限制到原 high-Li 或其他任何正子事件也成立。

资格事件在固定 C,v,y,z,H 后不依赖内父 B、停止节点 T 或旧 σ。因此 R1 先在原 B 积分合并全部 T 得 F，再使用 F/Li≤1 合法；没有逐节点复制常数。原外系数仍为 γt_Cq_C/[I_C M_C(v)²]，双方真实 μ 来源和旧窗口均保留。

### 7.2 决定性 Tonelli 顺序与中心容量

固定一个质量 u 的簇，并以 m=(u/c)γ^k、k≥0 划分 M_C(v)∈[m,γm)。u≤cM 恰好保证这些互斥档覆盖全部资格质量，包括阈值等号；γ>1 保证后续收敛。

每档先固定实际 y∈H，利用原积分中真实 y∈Q_C(v)。由 κ_C(v)≥1、q_C≥q 得 R_C^n=M/(κq_C)<γm/q，所以所有有贡献的真实中心 C 都位于以这个固定 y 为中心、侧长 (vγm/q)^(1/n) 的 cube。其 Lebesgue 体积至多 vγm/q。该论证对任意仅可测的实际 R_C 仍成立；它不选择新 R_C，不扩大实际动作，也不要求 H 有重心或整簇包含。

关键是先固定 y 再积分 C，随后积分 y∈H。不能先丢失 y∈Q_C(v) 再声称同一中心帽。作者 R3–R4 的顺序正确。真实 z∈H 给一个 u，随后真实 y∈H 给另一个 u；因此 μ² 因子是 u²。对 old z 是否在 Q_C(v) 完全不作要求。

### 7.3 旧窗、两份 M 与全部常数

原 κ_C(v)≤Kmax、实际 M∈[m,γm) 给 s_C∈[log_γm−log_γKmax,log_γm+1)。结合 Σ_C=(s_C−1−h,s_C+2+h)，该档全部旧窗位于一个长度

 Lσ=4+2h+log_γKmax

的共同区间；不按旧层重新付款。使用 I_C≥1、t_Cq_C≤Sλ_band 后，每档固定 v,g 的费用严格上界为

 γ² S r_band K v Lσ u²/m。

一个 M 被中心体积中的 m 抵消，另一个留下 1/m，未丢分母。实际来源质量和全部动作端点给

 Σ_k u²/[(u/c)γ^k]=cγu/(γ−1)，
 ∫vω(dv)=2G，∫ω(dg)=Λ。

因此每簇费用≤c Lcl(K)u，其中

 Lcl(K)=2GΛγ³/(γ−1)·S r_band K Lσ。

最后只使用一次 Σ_i,H μ(H)≤W，得到完整所声明事件的 cLcl(K)W。R1 的全部原交互/窗口/头/停止条件仅在正上界阶段放宽；没有任何实际系数变差或 recapture 另行收费被隐藏。

### 7.4 直接适用分支、随机化与原信用

R5 取 H=C_i 合法，因为原冻结合同保证双方来源都在同一原 source cell。故固定 c≥1 时，M_C(v)≥μ(C_i)/c 的完整分支可付 cLcl(K)W，即使旧 z 在接收盒外。它未断言任意输入都有固定比例质量落于该分支。

稿中另一充分分支 H⊂_μQ_B(1)、y,z∈H 也正确：h_H≤m_B≤M_B(g)，真实相交单位 log-mass 窗给 M_B(g)<γM_C(v)，因此属于 E_γ。此时 y 为 B 的旧 receiver；不能把它混记为 new capture，稿件已明示。

R6 对一次全局随机共同分簇法则平均，得到 ∫p_c dV≤cLcl(K)W。每次 realization 均须满足同一 μ-互斥族合同；不同 realization 是概率平均，不能按所有树深度求和。p_c≥η 分支费用 cLcl(K)W/η 正确；尚未证明所有来源对具有该概率下界。

原完整信用由 a=1/K 得 (1/K)∫Li dM=(1/K)∫e_B r(B)dB≤Qfr≤Qg。任意先剔除的正子事件只减小它。R7 的低增长直接估计属于 obstacle 的独立输入，本次未重复证明；在该输入有效前提下，R7 之后先 N_δ、再其补集低 Li 的互斥删除、real:combined、R8 与 R9 的同一信用组合及所有系数均 PASS。R9 的半吸收只是 b√(Qg X)≤Qg/2+b²X/2，b=2J/d²，并没有吸收未付 Vrem。

### 7.5 最终范围及停止点

本轮实际新增且独审通过的是完整受限费用定理：整簇包含可放宽为 h_H≤cM，并由固定真实 y 的中心容量付清它。这不是条件 relift 身份；确实能支付此前因旧 z 外接收盒而不属于 whole-containment 事件的正项。

未付部分仍是不同簇来源、同簇但 h_H>cM、随机分配时低 p_c 的全部实际费用。c、1/η 及 Lcl 中所有参数均必须进入母账。没有证明存在全局分簇使这些补集全部可付；不能反复更换 partition 或按树节点各发 W。完整 root-order 目标仍未闭合。

实际本机工具：SymPy 精确核验 R4 两份 M/中心/μ² 化简残差0，质量档级数前因子返回 cγu/(γ−1)，旧窗区间长度返回4+2h+log_γKmax。其余为独立解析及原稿逐式核验。本次未改作者稿、repo、PDF，也未扩展 outside-center 新题。至此本轮新增 capacity 审查完成。

### 7.6 最后同步：direct 归一化常数

作者随后仅强化 R7–R9，R1–R6 未改；已重新读取此段。更新采用 A_cap=GC_*=K/Λ，利用 (1−κ⁻¹)1_{κ−1≤δ}≤δ/κ 和原 I_B=∫ω/κ，将低增长直接费写成 δA_cap SA_nW。该归一化代数准确；完整 field cap/直接能量支配仍按本轮对应角色已审输入使用。于是 δ=(SA_n)⁻¹、τ=Dclk⁻¹ 时 Bdir=K+A_cap；更新 R8 的2J(Kw+K+A_cap)/d²及 R9 的4J(Kw+K+A_cap)/d²等系数一致。本文 §6 对 allocation 较早常数的核验是合法较粗版本，不将其误称最新最强值。质量条件 capacity 的 PASS 不受此次更新影响。

最终冻结：grid weighted payer 及 h_H≤cM 的完整受限来源费均通过；全部未付补集和原母账外层项继续保留。


---

## ccu_r564_feature_audit.md

# R564：真实有序动作对 Gram 与双向旧交集比例审计

日期：2026-10-23。责任：role10 distribution。只写本文件；不改仓库或其他角色文件、不生子 agent、不编译 PDF、不求解优化。先独立规定物理对象，再审 N5。N6 独立做精确计数/方向/归一化证书，不重复全 Gram。

## 1. 独立精确定义：真实动作对，不是 Cstar 的替代权

有限来源 `μ=Σ_s w_sδ_xs`，父 `B` 的积分权 `ω_B>0`、幅度 `a_B=t_B/R_B^n`，初始旧体 `O_B=Q_B(1)`，动作 `a=(B,g)` 的体 `A_a=Q_B(g)`、真质量 `M_a=μ(A_a)`、真窗左端 `ℓ_a=logγM_a`、真 phase `j_a=floor(logγκ_a/h)`。同父全部来源共享同一动作概率 `ρ_a`。

不把 band 当作原正交标签时，完整恢复字段的有序动作对贡献为

\[
E_{ab}=\rho_a\rho_b\omega_B\omega_C a_Ba_C\,
1_{i_B=i_C}1_{j_a=j_b}
\big(1-|\ell_a-\ell_b|\big)_+
\mu(A_a\cap A_b),\qquad b=(C,v). \tag{P1}
\]

完整能量 `E=Σ_(a,b)E_ab` 含所有有序父/动作对、两批交叉及全部共同来源。`B=C` 和 `a=b` 不能删除；不同实际 phase 在此原 direct sum 中正交。未移窗的真窗因子不可换成旧质量窗、`log g`，或移后 residual 窗。若另作共同 `−jh` 移窗并合 phase，则是另一字段，必须另用 `tent[(ℓ_a−j_ah)−(ℓ_b−j_bh)]`，不得混入 (P1)。

同 q-band 的固定问题贡献是 (P1) 乘 `1_bandB=bandC`；all-band diagnostic 要保留所有不同 band cross，不能只列 fixed-band 合计。多 band 模拟的完整字段仍不自动是原固定 q-band 母账实例，原冻结 α/score 不得据此重算。

χ-Gram 的 `E_ab=E_ba`。原 `Cstar` 的定向 head/stop/其他乘子一般不对称，**不在 (P1)**；不能把 χ 的对称性借给原 Cstar 来选免费便宜方向。本计算只判断同一有限恢复字段的交集诊断。

## 2. 两个定向比例与 bitset 公式

以合同给定的原旧质量 `m_B=μ(O_B)>0` 归一（本 N5 有 `m_B=c0_B/64`）：

\[
u_{BC}(a,b)=\frac{\mu(O_B\cap A_b)}{m_B},\qquad
u_{CB}(a,b)=\frac{\mu(O_C\cap A_a)}{m_C}. \tag{P2}
\]

第一方向的分子用 **B 的旧体、C 的当前动作体 v**，不是 B 的当前体与 C 的旧体；它不随 B 自己的 g 改变。第二式相反。两者均在 `[0,1]`，但一般不相等。交换有序动作对时它们互换，不能把其中一个抄给另一方向。

本数据有 64 个等质量来源。设 `O_B,O_C,A_a,A_b` 也表示相应 64-bit 掩码，`pop` 为精确 bit count，`c0_B=pop(O_B)`，则

\[
c_{ab}=\operatorname{pop}(A_a\&A_b),\quad
u_{BC}=\frac{\operatorname{pop}(O_B\&A_b)}{c0_B},\quad
u_{CB}=\frac{\operatorname{pop}(O_C\&A_a)}{c0_C}. \tag{P3}
\]

是分母旧质量计数，不是 `c_ab`、`count(A_a)`，也不是 old-old 交集归一。一般来源权不相等时必须改用加权和，不能继续 pop/oldcount。

在本数据 `γ=2,h=1/8,n=16,t=1`，(P1) 精确物理形式为

\[
E_{ab}=\rho_a\rho_b
\frac{\omega_B\omega_C}{R_B^{16}R_C^{16}}
1_{j_a=j_b}\big(1-|\log_2(c_a/c_b)|\big)_+
\frac{c_{ab}}{64}. \tag{P4}
\]

phase 应用原实际 count/c0 的整数比较结果，不能再近似 floor log。pop 计数有理精确；(P4) 的窗 log、父权和优化概率仍属有限浮点输入，没有因此变成严格一般积分证书。

## 3. OLD/NEW 四个交集与比例方向的交叉核

因为 `O_B⊂A_a,O_C⊂A_b`，定义

\[
\begin{aligned}
n_{OO}&=\operatorname{pop}(O_B\&O_C),\\
n_{ON}&=\operatorname{pop}(O_B\&(A_b\setminus O_C)),\\
n_{NO}&=\operatorname{pop}((A_a\setminus O_B)\&O_C),\\
n_{NN}&=\operatorname{pop}((A_a\setminus O_B)\&(A_b\setminus O_C)).
\end{aligned}
\]

则

\[
c_{ab}=n_{OO}+n_{ON}+n_{NO}+n_{NN},\quad
c0_Bu_{BC}=n_{OO}+n_{ON},\quad
c0_Cu_{CB}=n_{OO}+n_{NO}. \tag{P5}
\]

把 (P4) 中 `c_ab` 分别换成四个计数，就得到四个**有序** Gram 分量；全有序求和后 `ON_total=NO_total`，总能量含两项。不能把逐对 `ON=NO` 当作恒等式，它只在交换 `(a,b)` 后转置相等。

若 `u_BC=0` 而 `E_ab>0`，则任何该对共同捕获来源都不在 B 的旧体，因此来源 y 对 B 必为 NEW。它不推出总体增长大：可以只有一个很小共同来源，旧质量仍很大。`u_BC=u_CB=0` 时该对共同来源均为双方 NEW，但零分支本身仍是要付的正能量，不可从条件化统计中消失。

## 4. 条件旧来源 law 与 1/u 的费用方向

定向原旧来源概率与交集条件概率分别为

\[
P_B(dz)=\frac{1_{O_B}(z)\mu(dz)}{m_B},\quad
P_{B\mid C,v}(dz)=\frac{1_{O_B\cap A_b}(z)\mu(dz)}{m_Bu_{BC}}
\quad(u_{BC}>0),
\]

\[
\frac{dP_{B\mid C,v}}{dP_B}=\frac{1_{A_b}}{u_{BC}}. \tag{P6}
\]

因此 conditioning 的支配系数是 `1/u`，不是节省因子 `u`。`u=0` 无归一化交集 law，必须保留独立零分支，不能用 `1/max(u,epsilon)` 改模型。对任一非负测试成本 H，有精确条件均值 `E_PB[H1_Ab]/u`，以及上界 `≤E_PB[H]/u`；不能声称每个成本恰增 `1/u`，因为其在交集上的相关性也重要。

若 N5 以 (P4) 作为固定有序 pair measure，定义阈值 admission 与 scalar density-price：

\[
A(\theta)=\sum_{a,b}E_{ab}1_{u_{BC}\ge\theta},\quad
P(\theta)=\sum_{a,b:u_{BC}\ge\theta}\frac{E_{ab}}{u_{BC}},
\quad\theta>0,
\]

则它们是该**有限 χ-Gram measure** 的准确诊断，并满足 `A(θ)≤P(θ)≤A(θ)/θ`。它不等于原 Cstar 插入信用的完整实际成本：原物理权、`Li(z,σ)` 和 head/stop 均尚不在 (P4)。

对完整有序 χ 权，两个方向的边缘分布应在交换对后相同；联合分布也应关于交换坐标对称，这是便宜但有效的方向自检。若报告 `max(u_BC,u_CB)` 或选较便宜方向，须另外标明它只是 χ 的对称 diagnostic，不能抛掉原 Cstar 的另一非对称权或未选方向费用。N5 应同时保 fixed-band、crossband 与零/正小 u 分支，不从 admitted 子集外推总付款。

## 5. 已发送的防重复接口与有限停止点

在读取 N5 实现前，(P1)、(P3)–(P6) 已发给 numeric/N6 及主代理，特别标明 u 两个方向的 old/current 关系、所有真实窗/phase、全部有序项与 1/u 方向。N6 负责精确 counts/orientation/归一化与选定聚合误差；本角色随后只核 N5 代码对象与范围，不重建第二套全 Gram、不求解优化。

## 6. N5 代码/数据对象审计：通过

已读 `/tmp/ccu_r564_n5.py`、`.json` 及其 `_primitive.npz`。稳定代码 hash 为

`2e50ae7089b627bf6624ce4725b0302935055091841c0f955aadceb70d0e7566`，

与 JSON 相符。没有执行 N5 主函数、没有重建第二套 full Gram、没有求解器调用。本角色只读取其 primitive 并作方向/阈值/分组检查；N6 的精确计数和算术认证独立进行。

- **真实幅度和 pair 权。** `amp=parent.weight/R^16`，`pref=(rho*amp)_a(rho*amp)_b*samephase*tent/64`；`tent=max(1−abs(log2(count_a/count_b)),0)`，来源四分量 bit count 再乘此共同 pref。它是 (P4)，没有 1/g、遗漏父积分权、重复 64 分母或把质量窗换旧窗。不同 q-band 不在 kernel 中被置零。
- **掩码与两方向。** `old` 来自该父原 initial 来源集，`new=cap&~old`；四分量顺序是 `OO,ON,NO,NN`。`nf=OO+ON`，`nr=OO+NO`，`fi=table[c0_row,nf]`，`ri=table[c0_column,nr]`，符合 (P3)–(P5)。`uint64` 掩码覆盖 64 来源；交集计数在 `uint8` 的 0–64 范围内，互斥分量和也不超过 64。没有发生方向或分母交换。
- **所有有序项。** 共有 `1264²=1,597,696` pair，包括同动作、同父、两批交叉、所有 band 对；不是只算上三角。四分量既不正交化 OLD/NEW，也不把 ON、NO 一律逐对相等化。它们先分别计权，完整求和才作 N3 对照。
- **全部阈值。** `Fraction(k,c0)` 在整数层面排序和索引，`fi,ri` 不依赖浮点阈值比较。生成方法原则上是可能阈值的 superset；本输入只读 primitive 的实际 exact fraction 集核得**37 个值全部实有、无漏无冗余**，包含零；JSON 每个 threshold 表列 36 个正值，零分支另外报告。`bi=min(fi,ri)` 因精确排序而确等于双向最小 u 的分箱。
- **1/u 发票方向。** forward invoice 用 `hist/u_BC`。both invoice 只在 `min(u_BC,u_CB)>0` 时用 `E*(1/u_BC+1/u_CB)/2`，是明确的平均两方向发票，没有选便宜方向后省另一权。`inv[0]=0` 只用于排除无定义的正分支发票；相应零能量及 `zero_either_direction` 明确另外保留，不称其已付。
- **fixed-band/crossband。** histogram 保有有序 `band_B,band_C,component` 三个维度，JSON 又给完整 band-pair 总矩阵；threshold 的 diagonal 与每个 fixed-band 单独列出。阈值 off-diagonal 从 primitive 的全 band-pair histogram 保留，或由完整量扣 diagonal 得到，不能只读 diagonal 表声称 complete。
- **小 u 与补集。** 每个正阈值 admitted 由 exact fraction 后缀和给出；补集由相同四分量的 `total−admitted` 完整恢复，含零与正但更小 u。没有把未 admitted 的动作/来源丢掉。补集发票仍未因此得到有限界，尤其 u=0 不能条件归一。

只读 primitive 独立核得 `nf=nrᵀ` **精确相等**。全能量 band-pair 四分量在交换 band 与 ON/NO 后的最大浮点不对称为 `1.39e−17`；这与有序对的转置关系相符。全部 forward thresholds 对所有三个 law 的 `A(τ)≤invoice(τ)≤A(τ)/τ` 均通过（只作浮点检查，不作严格区间证书）。

## 7. 读数、费用范围与停止点

| law | 完整 E | forward u=0 费 | forward u>0 的 E | forward 1/u 发票 | 双向均正 E | 双向平均发票 |
|---|---:|---:|---:|---:|---:|---:|
| adaptive | 1.558593568624 | 0.000515156770 | 1.558078411854 | 1.730003933257 | 1.557774881560 | 1.729043698038 |
| optimum | 1.305992437747 | 0.001925393419 | 1.304067044328 | 1.390473573754 | 1.302956037368 | 1.387097404576 |
| δ1 | 2.140691118155 | 0 | 2.140691118155 | 2.497662838693 | 2.140691118155 | 2.497662838693 |

N5 对 δ1 与 R563 OLD/NEW 结果作同一输入对照，代码校准容差 `<2e−12`，没有用新模型重算旧 α。表中正 u 发票大于其对应能量，费用方向正确；零分支仍存在并须另付。此有限输入的发票并未暴增，但它不证明统一可控，也不包含真正 Cstar 的非对称 head/stop/core/旧信用权。

本角色的本机数学工具实跑为 Python 3.12.14、NumPy 2.5.4：只读 NPZ/JSON，按各 `c0` 的实际 `nf` 值用 `Fraction` 比较 exact threshold 集，核反向转置、完整 band/component 转置关系及 threshold 发票上下界。没有再次计算百万 pair 的 Gram 或调用优化器。稳定代码/输入/primitive hash 由 N5 JSON 保存，N6 另给选定聚合的精确/Arb 范围。

已读 N5 最终 `.md`：其明确把 `1/u` 称为该 χ diagnostic 的 reciprocal invoice，说明 both 是两原方向平均而非便宜方向，保零/小 u 补集为未付款项，且明确不包含非对称 Cstar 的 head/stop/core。它没有把近 99% 的本输入覆盖外推成一般正来源结论，也没有声称 exact counts 就认证浮点聚合或真实 Lebesgue。文档中的 threshold 补集可恢复范围与代码/NPZ 相符。

**最终 verdict：N5 的有限 physical ordered χ-Gram、双向 u、真实 phase/window、全部 band/OLD/NEW 与发票/补集范围通过；没有发现端点、方向、cheap-orientation 或费用丢失。不能把这项诊断认作原 Cstar 的完整条件旧来源费用，更未得到一般 L¹、真实 Lebesgue 或母账净收益。角色10有界审计完成并停止。**


---

## ccu_r564_ledger.md

# R564 完整条件提升／方向／共同流：唯一信用与实际倒数债

本账独立先推成本，后接作者关键式；固定R564合同的完整adaptive Cstar、原Li/alpha及所有ordered父对、质量层、真实phase/window、head/stop/core。只更换辅助插入，不更换共享动作。W=0为零流；以下W>0，正分母使用原合同可测零分支约定。未证明全局根阶。

## 1. 条件提升保总费，不自动保原信用

把完整待收费标量索引写lambda=(x,B)，dF=t_B q_B w_x(B)dB dXi。其总量为Cstar。旧来源概率nu_B(dz dσ)=k_B(z,σ)dμdσ/(t_Bq_B)，总量1，真实σ窗长1。设I=QB(1)∩QC(v)，u=μ(I)/m_B。对u>0，nu_I=1_I nu_B/u，插入总质量依然1；故完整Cstar不变。u=0的正费原项不能用该提升，必须归入未覆盖项或另一已核提升。由于共同接收y∈QBg∩QC(v)，u=0迫使y在QB(1)外，但不推出足量mass增长。

冻结旧评分e_B=∫Li k_B=C0t_Bq_B alpha_B。条件评分及精确倍率为

    e_I=∫Li k_B 1_I/u，c_lambda=e_I/e_B
       =E_nuB[Li 1_I]/(u E_nuB[Li])。

由正性及原帽Li≤C0，

    c_lambda≤min(1/u,1/alpha_B)<A_n。                    (1)

这只管信用侧。条件来源RN密度仍为1_I/u；不能由(1)删掉它。只用1/alpha_B避免tiny-u的信用爆炸，最坏却重引A_n量级的维数费。

## 2. 一个共同P、一个共同V；逐父充分条件并非必要

对所有选用方向／cluster／条件提升的正分配，允许细化索引r且theta_lambda,r≥0、sum_r theta≤1；余下标量总费记C_un。每个被选nu_lambda,r必须是真实概率、使用冻结评分Li，且其Li=0支的正质量须另付。方向反转若改变phase/σ或原评分字段，必须重新给正支持及信用比较，不由u_CB自动成立。

在共同正插入测度

    dM=sum_r dF theta_lambda,r nu_lambda,r

上取可测a>0（纯分析收费，可依细化父／来源；不是receiver-dependent动作），定义

    P=∫a Li dM，V=∫1/(a Li)dM。

于是完整被覆盖费C_cov²≤PV，仅此一次Cauchy。P是冻结旧信用的真实总负载，不是另一份新评分。若逐父证明所有方向／old/new／cluster负载之和≤1，则P≤Qfr_bulk≤Qg。条件nu_I且a不依z,σ时，这个充分条件准确为

    sum_r∫theta_lambda,r a_lambda,r c_lambda,r w_x(B)dXi≤1

对原评分父几乎处处成立。以1/u代c是更强粗条件，不必强求。更一般，直接证明

    P≤κ Qg+H W，V≤L W                                 (2)

也合法；全局积分约束可容许局部负载>1，因此弱于逐父≤1。可是κ,H必须由全部原评分权显式算出，不能以“平均”替代证明。不同方向各自P≤Qg不构成总P≤Qg。

特别是细化分析a=u b时：信用侧a nu_I=b 1_I nu_B，倒数来源侧却是

    [1/(a Li)]nu_I=1_I/(u² b Li) nu_B
                 =1/(u b Li) nu_I。                    (3)

若使用精确c并取a=b/c，来源侧相应是

    c 1_I/(u b Li) nu_B。                              (4)

(3)的u^-2是相对于原旧来源概率；条件概率下仍为实际1/u债。不得两次套“归一概率1”把它擦掉。这不是断言tiny-u必然数值发散：真实交集质量及Li相关性可能抵消；必须在所写完整积分中证明，不能预先删因子。(4)有时优于粗u^-2，仍需完整积分容量。整体a常数缩放只互换P,V，不能降低PV。

若沿用R563已付低Li分支，必须先在原插入上保留那个完整正子费；条件提升后的“Li≤tau”是另一子费，不能自动继承原K tau Dclk W。对原高分支重新归一时，相关overlap是原高后验落入I的条件概率，不自动等于几何u。

## 3. 方向与cluster不能复制一次信用／W

ordered两向的原权、head/stop/窗均可不同。即使u_BC大于u_CB，选择较便宜方向也必须把两向原标量dF各自完整送入合法概率插入；不能删掉另一向权，也不能直接把两权都计价到较便宜父的原e_B而不核tq及评分的转换。没有该转换时，min(1/u_BC,1/u_CB)不是已证完整费用。

若将一原费分到多个cluster，theta必须sum=1（或未分部分进入C_un），原评分负载必须总和计入同一P。仅各cluster单独P_H≤Qg不能累加成一次Qg；仅各cluster费用≤L μ(H)也须原μ容量sum_H coeff_H 1_H≤1，或显式保留其重叠倍数。whole-cluster inclusion、旧z簇外、交叉cluster及u=0/小u分支全留，不能用近距离替代完整包含。

可利用全局P约束而不强求逐父负载，但原信用总量只有一份；正向/反向、旧/新与簇的选择应先合成一个实际dM再算P,V。独立两payer若只各知P_r≤Qg、V_r≤L_rW，通用合并最多给L_eff=(sum_r sqrt(L_r))²；证明共同总负载后才可用真正sum_r V_r。

## 4. 含全部1/u债与余支的准确母账

记A=J/d²，B=2Brem/d，d=1−3h。若真正完整划分得到

    C_un≤a0 Qg+B0 W，C_cov²≤(κQg+H W)L W，

其中L必须含(3)/(4)的实际倒数债、全部质量层与σ；则x=Qg/W满足

    x≤C+2Aa0 x+2A sqrt(κLx+HL)，
    C=2A(Kw+B0)+B。                                    (5)

对κ>0，Young参数ζ>0的准确门槛及费用为

    A(2a0+κζ)<1，
    x≤[C+AζH+AL/ζ]/[1−2Aa0−Aκζ]。                    (6)

首先必须a0<d²/(2J)；一条免费未估余支不能放进B0。令delta=1−2Aa0>0，安全半吸收ζ=delta/(2Aκ)给

    x≤2C/delta+H/κ+4A²κL/delta²。                     (7)

直接二次解给同假设下更精确的有限上界

    x≤[delta C+2A²κL
        +2A sqrt(A²κ²L²+delta κLC+delta²HL)]/delta²。   (8)

κ=0时只需delta>0，并有x≤[C+2A sqrt(HL)]/delta。若直接证明完整2Cstar≤ζ_credit Qg+LlinW，则是Aζ_credit<1；不能混用(6)里的ζ。

只用条件评分粗帽κ≈A_n而L尚是polylog，不会自动达到目标：总费用有J²κL/d⁴，外层再乘Dclk。若使用共同全局信用证明κ=1（或把κ损失在L中反向回收），并付全部余支，才有可能保住原目标量级。tiny-u单支收费更低本身不决定κL是否更小。

## 5. 可执行验收、工具与当前停止点

候选需同时给：完整标量正分割；每个条件／反向插入的概率性和真实σ/评分支持；实际c及倒数RN项；所有方向／old/new的共同P上界；完整V与余支C_un上界。若只给固定disjoint H的局部费，必须另给全局fractional assignment及所有补集，不能把局部定理当整个L。

末端只做一次Q/W≤b0^-2 x、R*/W≤(2/b0)sqrt(Dclk x)。J/G/h/r/S、Kw、Brem、Dclk、原入口/初始/删除历史/全尺度/终端槽均保持原合同；本轮没有一项因条件归一而自动变零。

实际调用本机Python3.12.14 / SymPy1.14.0精确核验：(8)代入边界二次式残差0；(7)与(6)半吸收参数的代数残差0；(3)的原旧概率密度精确为1/(b Li u²)。这是符号核验，不是缺失容量的证明。未运行新优化、未改其他文件／仓库／PDF。

## 6. 接关键稿后的决定性组合审查

proof通报的完整fallback取h=1_(u>0)1_I/u+1_(u=0)，tilde k=h kB。此时所有原费均保留，u=0不再是被删余项，且c=1_(u>0)c_I+1_(u=0)。其c≤1/alpha帽及第2节真实来源账适用；但u=0的原后验仍在V，不属于已共同cluster的付款。若只对u>0作条件核，则必须重新列其原正余费C_un，不能同时称“全Cstar”又删fallback。

已读mechanism的 /tmp/ccu_r564_relift.tex 并独立核其决定性式：令xi_B(dx)=w_x(B)dXi、r=xi_B(X)，接收边际b_B(y)dμ；c_B=min(b_B,r 1_QB1/mB)构造最大对角子测度，余量用正残差乘积补齐。其coupling Pi_B有x边际xi_B、旧z边际r P_B，真实旧σ窗不变。因此对常数a=1/K，

    P^Pi=(1/K)∫e_B r(B)dB=P_original，
    V^Pi=K∫t_Bq_B r(B)∫[∫window 1_(Li>0)/Li dσ]P_B(dz)dB
        =V_original。                                  (9)

同样对原Li>tau与Li≤tau的子费恒等。此结论不依赖对角量多大，直接否定“只靠边际保持的对角relift加常数a即可降低完整后验账”。对非恒定a_x，准确原评分负载为

    R_a^Pi(B)=(tq/e_B)∫a_x [∫window Li(z,σ)dσ]Pi_B(dx,dz)，

不由原∫a_xw_xdXi≤1推出；其P与V均需重付。对角子测度在μ(dy)μ(dz)下是奇异的（μ无原子），不能直接继承乘积来源cluster的μ(H)²估计。合法正耦合不等于满足此前cluster容量合同。

稿中纯old对角的独立子估计P_old≤A_cap Qg、D_old≤A_cap Dclk W（A_cap=G C*(G)）仍给平方桥容量A_cap²Dclk；它既不能替代正残耦合／new／反向全费，也未移除主Dclk。只要这些剩余没有达到(6)，局部上界不构成全局母账改善。

最终结论：条件提升及保边际耦合均合法地保完整标量费用，但前者须付真实c和倒数RN项，后者在常数payer下P,V完全不变。共同全局信用可以弱于逐父条件，尚无已证构造同时满足全部κ,H,L及余支阈值。所需真实改善是完整κL（连同H与余支）而非单支overlap或diagonal比例。外层、原入口与全部历史槽继续保留；无根阶闭合。有限交付完成，停止，无新扫描。

## 7. 新付款分支的同测度互斥整合：唯一最终母账

本节仅对原插入dM=dXi w_x(B)k_B(z,σ)dB dμdσ，采用generator同一常数a=1/K；不接第6节改变后的耦合，不混用cover原非恒定a=1/s_x的Va。S=0另作零流。对S>0，令

    N={y∈QBg\QB1，κ_B(g)−1≤δ}，
    L=N^c∩{Li≤τ}，R=N^c∩{Li>τ}。

这三个事件在同dM上互斥且穷尽，所有head/stop/window/old-new标签保留。obstacle给真实全场cap与新来源第一矩付款，proof独审保留原I_B后得到严格加强：设F=G C*(G)，则∫_{κ−1≤δ}(κ−1)ω/κ≤δ I_B，故∫N dM≤δF SA_nW；原完整row cap给∫L dM≤KτDclkW。它们都是直接Cstar费，不占Qg，不是Va界。选择δ=1/(SA_n)、τ=1/Dclk，总直接费≤(K+F)W；row常数K=FΛ仍不变，不能也去掉其Λ。交叉N∩{Li≤τ}只在N中出现一次。

R上定义P_R=K^-1∫R Li dM≤Qg及V_R=K∫R dM/Li；唯一Cauchy为(∫R dM)²≤P_RV_R。cover随后确认CL6可统一取同常数a=1/K，generator的mass-admissible放宽已由Astra审查。最终只用这一对完整原Va上的量：

    p_gamma=E_pi[1_{y,z same global cell H}
                    1_{μ(H∩C_i)≤gamma M_C(v)}]∈[0,1]，
    ∫R p_gamma K dM/Li≤gamma Ccl(K)W，
    Ccl(K)=[2GΛgamma³/(gamma−1)] S r_band K Lσ，
    Lσ=4+2h+log_gamma Kmax，Λ=2+lnG。

C_i为原来源格；Kmax沿用cover实际mass/window范围。π是同一global尺度／shift partition法则，所有原父、接收点、旧z及旧窗仍在dM。mass条件依实际C,v的质量，不要求wholecell⊂QC(v)。原wholecontained规则p_Q满足p_gamma≥p_Q；真实inner-contained H⊂QB(1)由MB/MC<gamma可满足该质量门槛，因此可以支付部分z在QC外的原外旧来源。不再把“外旧必p=0”当普遍结论。

本节最终冻结(p_gamma,gamma Ccl(K))这一对；原wholecontained的Ccl(K)是替代规则，不能作为另一份W预算再加。对0<η≤1，在R上定义

    Vrem_gamma(η)=K∫R 1_{p_gamma<η} dM/Li。

则同一原Va的高概率子费≤gamma Ccl(K)W/η，且

    V_R≤gamma Ccl(K)W/η+Vrem_gamma(η)，
    Cstar≤(K+F)W+sqrt{Qg[gamma Ccl(K)W/η+Vrem_gamma(η)]}。

这两个V分支只共享上面的一个P_R≤Qg，不能对它们各领一次Qg。把两项先分别开根再相加反而损失共同信用。余项完整保留mass-admissible规则下的小共同簇概率、尺度／边界失败与未满足mass门槛的source pair，以及N外尚未被p_gamma≥η支付的old和large-growth-new。外旧只在该规则仍失败时留下，不能整类断言未付；large growth也可由高p子费支付。原tiny-u既不推出p_gamma小，也不推出其大。本式没有引入新的条件lift，故不产生新的1/u，但也不免除第1–4节未来条件lift的倒数债。

取共同Young半吸收ζ=d²/(2J)，准确唯一最终式为

    Q ≤ b0^(-2) { [4J(Kw+K+F)/d² + 4Brem/d
                       + 4J² gamma Ccl(K)/(d⁴η)] W
                    + (4J²/d⁴) Vrem_gamma(η) }。              (Final)

一般吸收门槛仅有这一份ζ<d²/J；不存在old/new各自的独立Qg。上式由原mother逐项代入，SymPy精确残差0。原R*外层仍为2sqrt(DclkWQ)，入口／历史／全尺度／终端费用均不改。

实际收益范围：低增长new付款是新增的完整正子费，覆盖所有实际u与所有旧σ（包括尚未低Li的部分），且只须真实κ−1≤1/(SA_n)；无需core比例或小u推增长。p_gamma≥η付款在同原Va上可覆盖old及large-growth-new的一个全球相容子集，包括符合质量门槛的原外旧，代价准确为gamma Ccl(K)/η。若η为polylog的倒数且固定参数合法，该子容量为polylog；它没有支付p_gamma小补集。两者扩大已付范围，但分支可能为空，也未给Vrem_gamma的全输入polylogW上界。因此当前只认证这些新正分支的付款，不认证完整母账最坏阶已改善，更不认证根阶闭合。保持已有完整粗比较可避免把额外直接(K+F)W误称为必然数值增益。

本次具体整合完成，停止。


---

## Recovery and complete coupling transfer (LaTeX audit text)

```tex
\documentclass[11pt]{article}
\usepackage{amsmath,amssymb,amsthm,geometry}
\geometry{margin=25mm}
\newcommand{\dd}{\,\mathrm d}
\newcommand{\1}{\mathbf1}
\title{R564: legal auxiliary source couplings and the original credit}
\date{23 October 2026}
\begin{document}\maketitle

\paragraph{Independent criterion and decision.}
Changing an auxiliary old-source coupling can be legal even when it depends
on the actual receiving point. It is not an action change provided the
original shared action law and the \emph{full marked receiver marginal}
remain fixed. Probability normalization preserves the scalar
$\mathcal C_\star$, but does not preserve the original frozen score or a
source-capacity payment. These require separate marginal and weighted-credit
checks below. A singular diagonal is permitted as a measure; it is not a
product-density change of variables. All zero-overlap, zero-field and
residual mass must remain in the complete bill.

This criterion was derived before reading any R564 coupling author. Only
the R564 contract and the previously frozen lifting were needed. The
one-time check of the delivered mechanism manuscript is recorded later;
the core transfer is not certified before its manuscript is supplied.

\paragraph{The exact original insertion.}
For $B$ in the frozen bulk, $m_B>0$ and
$\int k_B(z,\sigma)\dd\mu_i(z)\dd\sigma=t_Bq_B$. Define the original
old-source probability
\[
 P_B(\dd z)=\frac{\1_{Q_B(1)}(z)}{m_B}\dd\mu_i(z),\qquad
 \lambda_B(\dd z,\dd\sigma)=P_B(\dd z)
                   \1_{[s_B,s_B+1]}(\sigma)\dd\sigma.
 \tag{L1}
\]
Keep the entire ordered marked parameter $p=(B,x)$, where
$x=(i,C,v,g,T,y)$, with positive marginal
\[
 \dd\mathsf P(p)=t_Bq_Bw_x(B)\dd B\dd\Xi(x),\qquad
 \mathcal C_\star=\mathsf P(\mathcal P).
 \tag{L2}
\]
The original lifted measure is exactly
$\dd\mathsf P(p)\lambda_B(\dd z,\dd\sigma)$.
All windows, phases, head, stop, gate, cores, ordered parents and both
endpoint atoms remain in $\mathsf P$. Keeping only its unmarked spatial
$y$ marginal is not sufficient.

\paragraph{Legal normalization versus original-credit transfer.}
Any measurable probability kernel $K_p(\dd\ell)$,
$\ell=(z,\sigma)$, gives the exact scalar identity
\[
 \mathcal C_\star=\int\dd\mathsf P(p)\int K_p(\dd\ell).
 \tag{L3}
\]
Thus it may be used for analysis after $y$ is exposed. It cannot be used to
choose a different $g$ for that $y$, alter $\rho_B$, discard marked source
nodes, change $L_i$ or $\alpha_B$, or replace the actual source core by a
point action. Such changes require a new source-before-receiver action
construction and its original full comparison; they do not follow from
(L3).

For a positive analysis coefficient $a(p,\ell)$, first require that the
relifted measure assigns zero mass to $L_i(\ell)=0$. Then Cauchy gives
\[
 \mathcal C_\star^2\le A_K[a]V_K[a],\quad
 A_K[a]=\int aL_i\dd\mathsf P K_p,\quad
 V_K[a]=\int\frac{a^{-1}}{L_i}\dd\mathsf P K_p.
 \tag{L4}
\]
The exact per-original-parent credit condition is
\[
 A_{K,B}[a]:=t_Bq_B\int w_x(B)
              \int a(B,x,\ell)L_i(\ell)K_{B,x}(\dd\ell)\dd\Xi(x)
 \le e_B=C_0t_Bq_B\alpha_B.
 \tag{L5}
\]
Alternatively a single proved aggregate bound
$\int A_{K,B}[a]\dd B\le Q_g$ is sufficient. Neither follows from
$\int K_p=1$. The complete old-plus-new fee must use this one credit, not
one copy for each branch, node or orientation.

If $K_p\ll\lambda_B$ with density $r_p(\ell)$, the precise old-source
version is
\[
 A_{K,B}[a]=\int L_i k_B
       \left[\int a(B,x,\ell)r_{B,x}(\ell)w_x(B)\dd\Xi(x)\right]
              \dd\mu_i\dd\sigma.
 \tag{L6}
\]
It is the bracket containing the density that must satisfy the original
price-average constraint. The former common condition
$\int a_xw_x(B)\dd\Xi\le1$ cannot simply be reused after relifting.

\paragraph{Three levels of margin preservation.}
It is useful to distinguish the following, none of which implies an action
change.
\begin{enumerate}
\item Normalizing each $K_{B,x}$ preserves the full marked $(B,x)$ marginal
and hence the total scalar fee, but may change every old-source marginal.
\item Preserving the old $\lambda_B$ marginal for each ordered pair is
stronger; its actual receiver distribution and old distribution must be
coupled with their correct positive masses.
\item Preserving only the aggregate old margin after summing all $x$ for a
fixed original parent $B$ is a legitimate and less restrictive alternative.
It permits redistribution among ordered receiver labels, so pairwise
old-margin constraints must not be imposed on it gratuitously.
\end{enumerate}
For the third case, write $\xi_B(\dd x)=w_x(B)\dd\Xi(x)$ and
$r_B=\xi_B(\mathcal X)$. A positive measure $\Pi_B(\dd x,\dd\ell)$
with margins $\xi_B$ and $r_B\lambda_B$ preserves the original parent
old margin. It preserves the unweighted credit and reciprocal old-source
integrals for coefficients constant in $x$. With a receiver-dependent
analysis weight $a_x$, even preservation of both unweighted margins does
not preserve $\int a_xL_i\dd\Pi_B$: the \emph{weighted} old marginal, or
(L5) directly, must be bounded. A coupling of unmarked $y$ can only replace
this construction if the original conditional marked labels are lifted
back, retaining the actual $C,v,g,T$, gate and head distributions.

\paragraph{Intersection conditioning and all complements.}
For an ordered $(B,g;C,v)$ let
$u_{BC}=\mu(Q_B(1)\cap Q_C(v))/m_B$. On $u_{BC}>0$ the normalized insertion
supported in the actual intersection is
\[
 K_{BC}=\frac{\1_{Q_C(v)}(z)}{u_{BC}}\lambda_B,
 \qquad \frac{\dd K_{BC}}{\dd\lambda_B}
             =\frac{\1_{Q_C(v)}(z)}{u_{BC}}.
 \tag{L7}
\]
This is a valid probability and an exact scalar relift, but the original
score cost at that pair becomes
$u_{BC}^{-1}\int_{Q_C(v)}L_i k_B$ instead of $\int L_i k_B$.
It is bounded by $e_B/u_{BC}$ only as a coarse parent-price comparison;
there is no uniform gain. If an originally feasible analysis coefficient
$a$ is replaced by $u_{BC}a$, its first factor is safely restricted to the
intersection, while its reciprocal factor against the original lifted
measure has density $\1_{Q_C(v)}/(u_{BC}^2aL_i)$. Equivalently there is an
additional $1/u_{BC}$ against the already normalized conditional law.
This is an analysis coefficient with the original pair/parent index;
it is not automatically one common $a_x$ for all captured parents. It
displays the normalization debt and does not assert that a square loss is
necessary for every more refined joint estimate.

On $u_{BC}=0$, (L7) is undefined and cannot be given fictitious mass. That
branch must be retained and paid independently. Because actual
$y\in Q_B(g)\cap Q_C(v)$, it lies outside $Q_B(1)$ for $\mu$-almost every
such received point when $u_{BC}=0$. Hence it is new for $B$, but this alone
does not pay it. Small $u_{BC}$ likewise need not imply large total
$\kappa_B(g)-1$, because the real received core may have arbitrarily small
absolute mass.

Under the \emph{pairwise old-margin-preserving} version, the total mass
with old $z\in Q_C(v)$ is exactly $u_{BC}$ regardless of the coupling.
Therefore a probability-one common-source insertion inside that outer cube
is impossible with those original pairwise margins unless $u_{BC}=1$.
For a smaller fixed receiver cluster $H\subset Q_C(v)$ the same upper bound
is $\mu(Q_B(1)\cap H)/m_B$. This restriction does not prohibit a broader
aggregate-parent relift; its compensating residual old mass must then
appear among other $x$ labels with its full original credit invoice.

Any division by the reverse overlap $u_{CB}$ or choosing the cheaper ordered
orientation has the same requirement. The real asymmetric ordered
head/stop weights cannot be dropped or replaced by the favorable orientation.
A positive orientation split is legal only if its two parts sum to the
original full marked measure and all ratio costs and complements are paid.

\paragraph{Diagonal reuse: a measure, not an absolutely continuous relift.}
For $\mu=f\,dx$, the input is nonatomic. Thus
$(\mu\otimes\mu)\{y=z\}=0$. A positive relift with $z=y$ is singular
relative to the original product-source insertion, including when
$y\in Q_B(1)$. There is no finite product Radon--Nikodym density to insert
in (L6). The relift remains legitimate under (L3), but its first factor
must be evaluated as a measure integral (L5). A product-source estimate
using $\mu(H)^2$ cannot automatically be applied to a diagonal, whose mass
on $H\times H$ may instead be one integral over $H$. Singleton clusters
have zero input mass and do not create a once-$W$ payment.

For a precise pairwise diagnostic, fix actual ordered labels and a stop
core and let $J=H_{C,v,T,g}\cap Q_B(g)$ have positive mass. Its actual
normalized receiver law is $\mu|_J/\mu(J)$, while the old spatial law is
$P_B$. If both margins are to be preserved, every diagonal submeasure is
bounded by their common part. Its maximum possible mass is
\[
 \int\min\left\{\frac{\1_{Q_B(1)}}{m_B},
                       \frac{\1_J}{\mu(J)}\right\}\dd\mu
 =\frac{\mu(Q_B(1)\cap J)}{\max\{m_B,\mu(J)\}}.
 \tag{L8}
\]
The common part on the diagonal plus a coupling of the two positive
residual margins attains this mass. The normalized residual is omitted
when its mass is zero; when $\mu(J)=0$ the original pair contribution is
zero and is masked before division. For a more general actual receiver
density one uses its true density in the minimum, not an invented uniform
law. Aggregate-parent couplings have a different, explicitly aggregate
common-part formula; (L8) is not an extra pairwise condition on them.

\paragraph{Zero fields, singular traces and robust source transfer.}
The original product insertion gives zero mass to $L_i=0$, by Tonelli from
$L_i=\int k_B\dd B$. A new kernel need not have this property: copying an
actual new receiver $y$ into old $z$ may land where $L_i(y,\sigma)=0$.
Then (L4)'s factorization fails on positive mass. Defining $1/L_i=0$ there
would discard the fee. One must either prove that the aggregate relift
assigns this set zero mass or retain it as a separate positively paid
branch. Regularizing $L_i$ to $L_i+\varepsilon$ is not a payment; its inverse
factor can diverge as $\varepsilon\downarrow0$.

Individual conditional kernels may be singular but have an absolutely
continuous aggregate old margin after integration over the receiver. This
is sufficient to avoid an automatic trace objection. A convenient robust
condition is that the weighted aggregate charge
\[
 \Gamma_B^a(\dd\ell)=t_Bq_B\int a(B,x,\ell)w_x(B)
                            K_{B,x}(\dd\ell)\dd\Xi(x)
\]
is absolutely continuous with respect to the real old source--window
measure and that $\int L_i\dd\Gamma_B^a\le e_B$ is proved. Domination
$\Gamma_B^a\le k_B\dd\mu_i\dd\sigma$ is sufficient, but not necessary.
If the aggregate charge is singular too, the original $L^2$ norm does not
supply a trace bound or a version-independent credit inequality. A separate
canonical physical-field pairing and its actual bound are then necessary;
no vector transport theorem supplies those automatically. Copying $\sigma$
onto endpoints or other singular sets creates the same issue unless the
actual aggregate old-window margin is controlled. The usual continuous
$\sigma$ insertion in (L1) has no such endpoint problem.

\paragraph{General input, limits and zero denominators.}
All arguments are for fixed finite $n,G,\gamma,h$, the original $L^1$
input, actual marked kernels and frozen primitives. The positive bulk gives
$m_B,M_B(g),M_C(v)>0$ and $I_B\ge1$; no denominator is repaired by changing
the input or old history. Empty receiver/core/intersection branches are
masked before normalizing; arbitrary dummy probabilities on zero original
mass do not authorize adding a charged branch.
For positive small overlap, first restrict to $u\ge\varepsilon$, prove
the exact relift and its complete credit and source prices, then retain
$0\le u<\varepsilon$ as an explicit complement. Letting $\varepsilon\downarrow0$
requires actual uniform cost bounds or monotone positive bookkeeping;
small original pair mass does not bound its inverse-overlap invoice.
The $u=0$ branch can remain positive in the limit.

No atomic numerical diagonal is automatically a general-$L^1$ diagonal
certificate. At an atomic old source, a point selection has a density
proportional to the inverse atom mass when it is in the old support; that
quantity can diverge when atoms are smoothed or refined. Weak convergence
of couplings or shrinking neighborhoods to a diagonal gives neither
uniform original-credit control nor convergence of inverse-$L_i$ costs.
The true source cores, full parent Lebesgue integrals, marked marginals,
zero-field branches, and all ordered complementary mass must converge with
proved costs. Work first on positive finite truncations of centers, nodes,
sources and denominator thresholds, then use Tonelli/monotone limits for
identities and separate integrability or uniform bounds for inequalities.
There is no input-uniform modulus or unproved minimum-attainment assumption.

\paragraph{One-time check of the delivered maximal aggregate relift.}
After the criteria above were obtained independently,
\texttt{/tmp/ccu\_r564\_relift.tex} was read. Its aggregate-parent maximal
coupling is \textbf{PASS} in the assigned legality scope. Its $\xi_B$ keeps
the full $x$ labels. With receiver density $b_B$ and old target
$r_BP_B$, the common part
$c_B=\min\{b_B,r_B\1_{Q_B(1)}/m_B\}$ and positive residual construction
have margins $\xi_B$ and $r_BP_B$, including the $r_B=0$ and zero-residual
cases. It explicitly preserves only aggregate-parent, not pairwise old
margins, so it does not falsely invoke (L8) on each pair.

Because the aggregate old source--window density is
$\int r_Bk_B\dd B\le K L_i$, its zero-field mass is indeed zero; it is not
removed by an inverse convention. For $x$-dependent $a_x$, its stated
credit condition uses the changed coupling directly, as required by (L5).
For constant $a=1/K$, old-margin preservation makes both the original-credit
factor and inverse old-source invoice unchanged, including restrictions
$L_i>\tau$ or $L_i\le\tau$. Thus this maximal diagonal mechanism alone
has no full mother gain. It expressly leaves the entire residual and
nonconstant-weight invoice unpaid. The pure-old diagonal option is also
stated as a separate changed-margin branch with its own charge, not a free
application of the product-source cluster bound. This comparison does not
certify an absent common-cluster embedding or a new high-field price.

\paragraph{Actual short arithmetic check.}
Executed the installed interpreter
\texttt{/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python}
(Python 3.12.14), using exact \texttt{fractions.Fraction}. The two-site
receiver margin was $(3/4,1/4)$ and old margin $(1/2,1/2)$, with coupling
matrix $[(1/2,1/4),(0,1/4)]$. It returned those two margins exactly, constant
old-price integral $7/2$ for old prices $(2,5)$, and inverse integral $7/20$,
both invariant. Receiver analysis weights $(1,2)$ instead gave coupled
credit $19/4$ versus product credit $35/8$. This is only a normalization
and weighted-margin check; it demonstrates why unweighted margin equality
does not preserve a nonconstant analysis credit, and is not a cube example
or a general source-budget proof. No heavy computation, optimizer,
repository change, child agent or PDF compilation occurred.

\paragraph{Current finite verdict.}
Normalized intersection and singular diagonal relifts can be legal analysis
operations. Their exact positive margins, original weighted credit,
zero-field and complementary branches decide whether they transfer to the
complete bill. The delivered constant-rate aggregate diagonal coupling
passes those checks but leaves the inverse old-source bill invariant.
No polylogarithmic complete price or root-order estimate is proved here.
The supplied core transfer is checked once in the final section below; no
repeated old recovery proof is needed.

\section*{Frozen final audit: maximal common-cluster coupling and complete transfer}

\paragraph{Final object and scope.}
The core author was asked for its final manuscript before this one-time
comparison. The completed \texttt{/tmp/ccu\_r564\_core.tex} was then read
for precisely the requested interfaces. Its verified SHA256 is
\texttt{61f1c2d8cb6a7d4d544c22e0adddfaf1cc75fddab595c7635455dd59ad41625c}.
The maximal matching, full positive residual, density formula, preserved
credit and inverse bill, large-block transfer, weighted deficit and final
mother arithmetic are \textbf{PASS}. The underlying mass-cap cluster
lemma, already separately passed by the Astra audit, is used as a stated
input and is not re-proved here. No general payment of the weighted deficit
or new dimensional-order conclusion is certified.

\paragraph{The marked margins and maximal positive matching are exact.}
For nonzero effective $B$, core normalizes
\[
 Q_B(\dd x)=w_x(B)\dd\Xi(x)/r_B,
 \qquad P_B(\dd z,\dd\sigma)=k_B\dd\mu_i\dd\sigma/(t_Bq_B).
\]
Its $Q_B$ preserves every actual mark, not merely the receiver location.
One countable, common $\mu$-disjoint family $\mathcal H_i$ is fixed for the
whole input. For each $H$, the actual eligible receiver event is exactly
\[
 E_H=\{x:y\in H,\ \mu(H)\le cM_C(v)\},\quad
 p_H=P_B(z\in H),\quad q_H=Q_B(E_H).
\]
No whole containment $H\subset Q_C(v)$ is asserted or needed by this
coupling. Source membership $y\in Q_C(v)$ is already in the unchanged
actual receiver measure; $z\in H$ is allowed to lie outside that cube.
The events on each side are disjoint, giving
$\sum_Hp_H,\sum_Hq_H\le1$, not necessarily equality.

For $p_Hq_H>0$, define
\[
 \Gamma_H=\frac{1}{\max(p_H,q_H)}
           (Q_B|_{E_H})\otimes(P_B|_{z\in H}).
 \tag{F1}
\]
Its mass is $p_Hq_H/\max(p_H,q_H)=\min(p_H,q_H)$, and its two marginal
submeasures are $[\min(p_H,q_H)/q_H]Q_B|_{E_H}$ and
$[\min(p_H,q_H)/p_H]P_B|_H$. Every coupling of the given margins has at most
$\min(p_H,q_H)$ in that block; (F1) attains all those disjoint bounds
simultaneously. It is an absolutely continuous common-block coupling,
not the singular diagonal from the separate mechanism.

When either probability is zero, this block is zero before dividing. The
remaining positive measures have the same mass
$\delta_B=1-\sum_H\min(p_H,q_H)$; their product divided by $\delta_B$
restores the two original margins when $\delta_B>0$, and is omitted if
$\delta_B=0$. Uncovered old source, noneligible receiver marks and mass-cap
failures remain in these margins. In particular the core does not replace
$\delta_B$ by a total-variation expression that would forget outside mass.
The entire construction is measurable by integrals and countable sums.
It leaves every action and its source-before-receiver law unchanged.

\paragraph{Constant-rate credit and complete inverse cost are unchanged.}
After multiplying the coupling by $t_Bq_Br_B\dd B$, both the marked
receiver marginal and original old source--window marginal are unchanged.
Therefore with $a=1/K$ its first factor is exactly
\[
 \frac1K\int r_Be_B\dd B\le Q_g-E_{\rm rem}\le Q_g,
\]
and for every $\tau\ge0$ its high inverse cost is exactly
\[
 V_{\rm hi}=K\int r_BD_B^\tau\dd B,
 \quad
 D_B^\tau=\int_{L_i>\tau}\frac{k_B}{L_i}\dd\mu_i\dd\sigma.
 \tag{F2}
\]
These equal the pre-coupling constants and costs, not just upper bounds on
them. High and low masses are preserved too, so the old complete low-field
payment $K\tau D_{\rm clk}W$ transfers directly without spending $Q_g$.
Tonelli and preservation of the original old margin prove zero aggregate
mass on $L_i=0$; the inverse convention does not erase a positive branch.
No invariance for nonconstant $a_x$ is claimed.

\paragraph{Large matching blocks: the precise paid subfee.}
The passed mass-cap cluster input is core (11), on the \emph{original}
product insertion and with actual $E_H$, namely
\[
 K\int_{L_i>0}\sum_H\1_{E_H}(x)\1_H(z)
                  \frac{\dd\mathcal M}{L_i}
 \le cL_{\rm cl}(K)W.
 \tag{F3}
\]
This audit treats its precise hypotheses and constant as supplied; in
particular its actual mass cap $\mu(H)\le cM_C(v)$ replaces any stronger
whole-cluster containment hypothesis. It is the one globally shared family
with $\sum_H\mu(H)\le W$, not a fresh family for each parent or mark.
For blocks with $\max(p_H,q_H)\ge\varepsilon>0$, (F1)'s density relative
to the same original product insertion is at most $1/\varepsilon$.
Consequently their whole positive high inverse subfee satisfies
\[
 V_{\rm paid}^{\tau}\le cL_{\rm cl}(K)W/\varepsilon.
 \tag{F4}
\]
This is a valid transfer of the passed lemma. It pays the subfee already
inside (F2), covering both old and new receivers and eligible external old
sources. It is not an extra $Q_g$ credit and does not pay the small-block
or residual measures. A density bound without (F3) would not suffice.

\paragraph{The exact weighted deficit includes every remaining tuple.}
The large matched blocks have old marginal coefficient
$\min(1,q_H/p_H)$ on $H$. It follows without deleting any mark or orientation
that the inverse cost of all other blocks is exactly
\[
 \boxed{\displaystyle
 V_{\rm bad}^{\tau,\varepsilon}
 =K\int r_B\left[D_B^\tau-
       \sum_{\max(p_H,q_H)\ge\varepsilon}
        \min\left(1,\frac{q_H}{p_H}\right)D_{B,H}^\tau\right]\dd B,
 \quad
 D_{B,H}^\tau=\int_{L_i>\tau,z\in H}\frac{k_B}{L_i}
                                     \dd\mu_i\dd\sigma.}        \tag{F5}
\]
Zero $p_H$ terms are zero before division. The bracket is nonnegative,
because on disjoint $H$ each deducted fraction is at most one. It is the
old marginal left after removing only the large matched blocks; thus it
includes the positive residual product, every small matched block,
uncovered source, noneligible receiver and all supply-demand mismatch.
Equation (F2) decomposes exactly into $V_{\rm paid}^\tau+V_{\rm bad}$.
There is no replacement of this weighted deficit by $\delta_B$ alone.
Even $\delta_B=0$ need not make (F5) small: a full matching split into
arbitrarily many blocks below $\varepsilon$ leaves every such block unpaid.
Nor can their $1/\max(p_H,q_H)$ factors be bounded by one when merging them.
This is the genuine remaining full invoice, not a renaming of a paid part.

\paragraph{One complete mother transfer, with all previous fees.}
Combining the transferred low-field payment with high Cauchy and (F4)--(F5)
gives exactly core (14):
\[
 2\mathcal C_\star\le\zeta Q_g+
 \left[2K\tau D_{\rm clk}
           +\frac{cL_{\rm cl}(K)}{\zeta\varepsilon}\right]W
          +\frac{V_{\rm bad}^{\tau,\varepsilon}}\zeta.
 \tag{F6}
\]
Only the high part uses the one old credit. With
$\tau=D_{\rm clk}^{-1}$, a further actual proof
$V_{\rm bad}^{\tau,\varepsilon}\le L_{\rm bad}(n)W$ would permit
$\zeta=d^2/(2J)$ and yield exactly
\[
 \frac QW\le\frac1{b_0^2}\left[
  \frac{4J(K_w+K)}{d^2}
 +\frac{4J^2}{d^4}
       \left(\frac{cL_{\rm cl}(K)}\varepsilon+L_{\rm bad}(n)\right)
 +\frac{4B_{\rm rem}}d\right].                         \tag{F7}
\]
Here the original $d=1-3h$, $B_{\rm rem}$ and $b_0$ are unchanged.
All original entrance, time-atom, scale, terminal and
$R^*\le2\sqrt{D_{\rm clk}WQ}$ fees remain. The passed large-block transfer
therefore gives a real payable positive subfee with explicit
$1/\varepsilon$ cost. It does not close the mother: the core expressly
leaves (F5) unpaid, and neither normalization, maximal matching nor source
coupling alone proves a fixed polylogarithmic bound for it.

\paragraph{Actual final arithmetic and freeze.}
The same installed Python 3.12.14 interpreter was run using exact
\texttt{Fraction}. For $p=(3/4,1/4)$, $q=(1/2,1/2)$ the matched masses
were $(1/2,1/4)$, residual mass $1/4$, and matching densities $(4/3,2)$;
both residual margins had mass $1/4$. With old inverse weights
$D_H=(2,5)$ and $\varepsilon=3/5$, the paid cost was $4/3$, bad cost
$17/3$, and small-matched plus residual cost was exactly $17/3$ with
zero residual in identity (F5). This checks the algebra and weighted
complement only, not the passed mass lemma or a geometric deficit bound.

Final verdict: \textbf{PASS and frozen} for this complete coupling and its
conditional mother transfer. All supplied zero, singular and complementary
branches are accounted for. The paid result is (F4); the unproved result is
a global bound on (F5). No additional topic was opened and no other file,
repository or PDF was modified.

\end{document}

```
