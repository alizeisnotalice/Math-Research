# R564 source and scope ledger

The authoritative baseline is R563 commit ce025dc55748ef1e8985bc468a7b6cd4ed40615b, with the R562 primitive contract and finite input cited in REPRODUCE.md. No original receiver, center, action or history was replaced by the finite diagnostic.

Applied updated mathematical tool skill:
`/Users/zhengzhihao/.codex/skills/math-d01-kantorovich-duality/SKILL.md`.
It requires actual positive marginals and the correct primal/dual directions; vector-valued KR or path SOT is not permission to alter the original positive source margins. This round uses elementary finite positive flow and explicit couplings, without importing an unverified continuous transport existence theorem.

Primary newly audited analytic estimate: generator realization proof, mass-eligible global disjoint clusters (no whole-cluster containment), independently reviewed by Astra. The center-volume step alone is not a cube-specific polynomial improvement over general symmetric homothets.

Other admitted tools: R563 full-row K, full restored-field cap, exact stop-summed F<=Li and Sigma support, actual-mass binning, old low-field bound, and original mother ledger. All additional conditional statements retain their unproved complete payer.

The optional outside-center E formula was removed from the final evidence because it was not needed for the new estimate and was not independently certified. No conclusion here depends on it.

No new external-paper theorem was required, and no bibliography dump or duplicated historical archive was added. Local audit source hashes are recorded in MANIFEST.json; the mathematical proofs needed this round are integrated in REPORT.tex.
