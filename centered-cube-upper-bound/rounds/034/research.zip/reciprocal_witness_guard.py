from fractions import Fraction as F
from math import comb, factorial
from itertools import combinations,product
from decimal import Decimal as D, localcontext
from pathlib import Path
import random,heapq,json

def C(n,k):return comb(n,k) if 0<=k<=n else 0

def intervals(points,caps,x,a,b):
 out=[]
 for i,(y,c) in enumerate(zip(points,caps)):
  s=max(a,2*max(abs(v-w) for v,w in zip(x,y)))
  if s<=b and s<c:out.append((s,c,i))
 return out

def sweep(iv,k,b,degrees=False):
 # Each clique is counted exactly at its last entry, including entry batches.
 groups={}
 for s,c,i in iv:
  if s<=b and s<c:groups.setdefault(s,[]).append((c,i))
 heap=[];active={};z=0;deg={i:0 for _,_,i in iv}
 for s,new in sorted(groups.items()):
  while heap and heap[0][0]<=s:
   c,i=heapq.heappop(heap);active.pop(i,None)
  q=len(active);v=len(new);z+=C(q+v,k)-C(q,k)
  if degrees:
   old=C(q+v-1,k-1)-C(q-1,k-1)
   for i in active:deg[i]+=old
   for c,i in new:deg[i]+=C(q+v-1,k-1)
  for c,i in new:active[i]=c;heapq.heappush(heap,(c,i))
 if degrees:assert sum(deg.values())==k*z
 return z,deg

def brute(iv,k,b):
 es=[]
 for sub in combinations(iv,k):
  s=max(v[0] for v in sub);c=min(v[1] for v in sub)
  if s<=b and s<c:es.append(tuple(v[2] for v in sub))
 deg={i:sum(i in e for e in es) for _,_,i in iv}
 return len(es),deg,es

def snapshots(iv,k,b):
 # Sum 1/binom(N(cap-),k) over witnesses; death batches handled exactly.
 live=[(s,c,i) for s,c,i in iv if s<=b and s<c]
 total=F(int(sum(s<=b<c for s,c,i in live)>=k))
 for t in sorted({c for s,c,i in live if c<=b}):
  q=sum(s<t<=c for s,c,i in live);d=sum(s<t and c==t for s,c,i in live)
  if q>=k:total+=F(C(q,k)-C(q-d,k),C(q,k))
 return total

def finite_cases():
 rng=random.Random(20261008);rows=[]
 for stage,N in enumerate((7,9,12),1):
  for n in (1,2,4,8,16):
   for k in (2,3,4):
    pts=[tuple(F(rng.randrange(-8,9),8) for _ in range(n)) for j in range(N)]
    caps=[F(rng.randrange(4,33),8) for j in range(N)]
    x=tuple(F(rng.randrange(-2,3),8) for _ in range(n));b=F(3)
    iv=intervals(pts,caps,x,F(1),b)
    z,d=sweep(iv,k,b,True);zb,db,es=brute(iv,k,b)
    assert z==zb and d==db
    snap=snapshots(iv,k,b)
    assert (snap>=1)==(z>0)
    direct=F(0)
    for e in es:
     ce=min([b]+[caps[i] for i in e])
     if ce==b and all(caps[i]>b for i in e):q=sum(s<=b<c for s,c,i in iv)
     else:q=sum(s<ce<=c for s,c,i in iv)
     direct+=F(1,C(q,k))
    assert snap==direct
    rows.append(dict(stage=stage,n=n,N=N,k=k,cliques=z,snapshot=str(snap)))
 # Explicit endpoint/tie cases: death-before-entry and terminal singleton time.
 edge=[(F(1),F(2),0),(F(2),F(3),1),(F(2),F(3),2)]
 assert sweep(edge,2,F(2),True)[0]==1
 assert snapshots(edge,2,F(2))==1
 return rows

def large_sweeps():
 rows=[]
 for N,k in ((128,16),(256,32),(1024,64)):
  iv=[(F(1),F(3+i%7,2),i) for i in range(N)]
  z,d=sweep(iv,k,F(2),N==128)
  assert z==C(N,k)
  if N==128:assert all(v==C(N-1,k-1) for v in d.values())
  # Disjoint batches: exact sum, no fictitious cross-time witnesses.
  iv2=[(F(1+i//16),F(3,2)+i//16,i) for i in range(N)]
  z2,_=sweep(iv2,4,F(N),False);assert z2==(N//16)*C(16,4)
  rows.append(dict(N=N,k=k,complete_clique_digits=len(str(z)),disjoint_batch_cliques=z2))
 return rows

def volumes():
 rows=[]
 for n,N in ((1,5),(2,4),(3,3)):
  for phase in range(3):
   pts=[tuple(F((j*(i+1)+phase)%4,4) for i in range(n)) for j in range(N)]
   caps=[F(5+(j+phase)%3,4) for j in range(N)];a=F(1);b=F(2);k=2
   possible=sorted(set(min(c,b) for c in caps if c>a))
   axes=[]
   for i in range(n):
    cut=sorted({y[i]+sg*c/2 for y in pts for c in possible for sg in (-1,1)})
    axes.append([(u,v) for u,v in zip(cut,cut[1:])])
   hit=F(0);fees=[F(0)]*N;snapint=F(0);cells=0
   for box in product(*axes):
    x=tuple((u+v)/2 for u,v in box);vol=F(1)
    for u,v in box:vol*=v-u
    iv=intervals(pts,caps,x,a,b);z,d=sweep(iv,k,b,True)
    zb,db,es=brute(iv,k,b);assert z==zb and d==db
    cells+=1
    if z:
     hit+=vol
     for i in range(N):fees[i]+=vol*F(d.get(i,0),k*z)
    snapint+=vol*snapshots(iv,k,b)
   assert sum(fees)==hit and snapint>=hit
   rows.append(dict(n=n,N=N,phase=phase,cells=cells,receiver_union_volume=str(hit),source_fees=[str(v) for v in fees],snapshot_volume=str(snapint)))
 return rows

def shapley_brute(iv,k,b):
 ids=[i for s,c,i in iv];N=len(ids);ans=[F(0)]*N
 for j in ids:
  other=[i for i in ids if i!=j]
  for mask in range(1<<len(other)):
   chosen={other[t] for t in range(len(other)) if mask>>t&1};l=len(chosen)
   sub=[v for v in iv if v[2] in chosen]
   h0=sweep(sub,k,b)[0]>0
   h1=sweep(sub+[v for v in iv if v[2]==j],k,b)[0]>0
   if h1 and not h0:ans[j]+=F(factorial(l)*factorial(N-l-1),factorial(N))
 return ans

def entropy_cases(prec):
 rows=[]
 with localcontext() as ctx:
  ctx.prec=prec
  for M in (2,4,8,32,128,1024):
   den=(M+1)*(M+2)*(M+3)
   pa=F(1,6)+F(2,den);pc=F(2,3)-F(1,M+1)+F(2,den)
   pl=F(1,M*(M+1))-F(6,M*den)
   phi=[pc]+[pl]*M+[pa,pa]
   w=[F(M,2*(M+1))]+[F(1,2*(M+1))]*(M+2)
   assert sum(phi)==sum(w)==1
   if M<=8:
    iv=[(F(1),F(4),0)]+[(F(1)+F(3*j+1,M+1),F(1)+F(3*j+2,M+1),j+1) for j in range(M)]+[(F(5),F(59,10),M+1),(F(51,10),F(6),M+2)]
    z,d=sweep(iv,2,F(6),True);assert z==M+1
    assert [F(d[i],2*z) for i in range(M+3)]==w
    assert shapley_brute(iv,2,F(6))==phi
   def dc(q):return D(q.numerator)/D(q.denominator)
   kl1=sum(dc(p)*(dc(p)/dc(q)).ln() for p,q in zip(phi,w))
   kl2=sum(dc(q)*(dc(q)/dc(p)).ln() for p,q in zip(phi,w))
   bound=D(M+1).ln()/3-D(2).ln()
   assert kl1>=bound and kl2>=bound
   rows.append(dict(M=M,phi_isolated=str(pa),uniform_isolated=str(w[-1]),phi_leaf=str(pl),uniform_leaf=str(w[1]),KL_phi_uniform=format(kl1,'.16g'),KL_uniform_phi=format(kl2,'.16g'),proven_lower_bound=format(bound,'.16g')))
 return rows

def plateau(prec):
 with localcontext() as ctx:
  ctx.prec=prec;rows=[]
  for n in (16,64,256,1024,4096):
   T=D(n)*D(2).ln();m=max(int((64*(2+T).ln()).to_integral_value(rounding='ROUND_CEILING')),int(T.sqrt().to_integral_value(rounding='ROUND_CEILING')));k=m+1
   term=(-D(m)).exp();cum=term
   for j in range(1,k):term*=D(m)/j;cum+=term
   tail=1-cum;assert tail>=D(1)/16
   interior=(1-D(1)/(200*n))**n
   ratio=interior*tail*(1+D(k)*T)
   rows.append(dict(n=n,m=m,tail=format(tail,'.16g'),snapshot_fee_lower=format(ratio,'.16g'),critical_shape=format(D(m)+T/m,'.16g')))
  return rows

def axis_guards(precision):
 exact=[]
 for m in (1,2,4,8,16):
  for j in (3*m,4*m):
   N=j+1;beta=F(19*m,10);c=beta/F(N-m+1)
   assert c<=F(19,20)
   for p in (F(1,4),F(1,2),F(3,4)):
    moment=sum((F(C(N,m-l))*p**(m-l)*(beta*(1-p))**l/factorial(l) for l in range(m+1)),F(0))
    bound=F(C(N,m))*(p+c*(1-p))**m
    assert moment<=bound
    exact.append(dict(m=m,j=j,survival=str(p),moment=str(moment),upper=str(bound)))
 rows=[]
 with localcontext() as ctx:
  ctx.prec=precision
  for e in (24,32,40,64,96):
   n=2**e;nd=D(n);T=nd*D(2).ln();m=int(nd.sqrt().to_integral_value(rounding='ROUND_CEILING'));md=D(m)
   assert md>=64*(2+T).ln() and m>=181
   angle=F((n-1)*(n-2),2)*F(1,20*n)**2*F(9,1000)
   assert angle>=F(1,100000)
   birth=D('1.8')*(nd/D('1.8'))**(1/nd);assert birth<D('1.9')
   assert 1-D('3.61')/(D('.04')*md)>=D('.5')
   log_tail=md.ln()+T.ln()-md/40;assert log_tail<=D(64).ln()
   point_lower=T/D(640000000);target=md+T/md
   rows.append(dict(n_power_two=e,m=m,angle_probability_bound=str(angle),birth_rate_per_m_upper=format(birth,'.16g'),log_mT_exp_minus_m_over_40=format(log_tail,'.16g'),degree_column_lower=format(point_lower,'.16g'),lower_over_m_plus_T_over_m=format(point_lower/target,'.16g')))
 return dict(factorial_moments=exact,large_dimension_constants=rows)

if __name__=='__main__':
 f=finite_cases();l=large_sweeps();v=volumes();e=entropy_cases(70);p=plateau(70)
 ax=axis_guards(70)
 assert e==entropy_cases(110) and p==plateau(110) and ax==axis_guards(110)
 out=dict(status='PASS; general square-root bound unproved',finite_geometry=f,axis_column_guards=ax,large_sweeps=l,exact_receiver_volumes=v,allocation_entropy=e,constant_density_plateau=p,notes=['Finite configurations use common-source feasible mark intervals; random.Random(20261008) generates test inputs only, not Monte Carlo estimates.','Fractions certify finite combinatorics and arrangement volume; Decimal70/110 agreement is not interval certification.','Plateau input is actual compactly supported constant density. Entropy obstruction is for allocation transfer, not a weak-type lower bound.'])
 Path(__file__).with_name('results.json').write_text(json.dumps(out,indent=2)+'\n')
 print('PASS',len(f),'finite configurations;',len(l),'large sweeps;',len(v),'exact receiver volumes;',len(e),'allocation entropy vectors;',len(p),'plateau vectors;',len(ax['factorial_moments']),'factorial moments;',len(ax['large_dimension_constants']),'axis constants')
