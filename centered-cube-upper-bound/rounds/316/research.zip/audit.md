# R316 independent preauthor screen

Saved before reading new author proofs. Own this audit only; no Git or other-author edits.

## 1. Root-preserving tent — independent PASS

Fix the ORIGINAL R302 fields, sources, ell_n and high-J threshold H>=d>0. For0<=A<=J with J>=H define r_H(A)=min(d,A)-(d/H)min(H,A). This is nonnegative and zero for A>=H. The identity holds with d*min(H,A)/H; replacing min(H,A) by A gives the stated inequality. For0<A<H put v=r_H(A)/[A(1-A/J)], and put v=0 otherwise.

For A<=d, v=(1-d/H)/(1-A/J)<=1 because A/J<=d/H. For d<A<H, v=(d/A)(1-A/H)/(1-A/J)<=d/A. Thus0<=v<=min(1,d/A), with A=0 handled separately; J=H=A and H=d have no division. The weighted remainder is supported on ORIGINAL capture A<H, rather than on a recomputed source/prefix.

The original small-J payment remains4lambda H Wbeta, including crossing atoms; the high-J linear term is at most(d/H)An Wnu by original FIRST before receiver extension. Therefore

O_d<=4lambda H Wbeta+(d/H)An Wnu+B_H^tent,
B_H^tent=integral beta nu ell 1{J>=H}v(A,J)[A-A²/J].

R315 positive partitions apply to this smaller fee: v depends on fixed y,z,r and is in[0,1], so bottom/deep/top/contact are positively bounded by their full unweighted counterparts and the exact remaining oriented collar-far carries v and A<H. No full-J, source or mask is recomputed. This improves the remainder only; it is not a source-root price for that remainder or a second disjoint credit.

At H0=sqrt(d An/(4lambda)), H0>=d precisely when lambda*d<=An/4. If lambda*d>=An/4, original T<=2O_d<=2An Wnu<=4sqrt(lambda*d*An)Wnu directly. At equality H0=d the tent remainder is zero. This exception pays the target without an additional high-A geometric fee and avoids using the tent outside H>=d. Source-mass-balanced threshold would need its own H>=d check.

## 2. Constructive full hardband entrance — independent PASS for its NEW heavy target

Read the original R104 research.zip::proof.md directly, especially99–117,821–842,844–929, plus its finite-component hypotheses. Its displayed theorem is uniform over fixed measurable G in[0,1], a prereceiver-frozen positive density nu_omega<=f, a measurable selected hard scale in one octave with the stated band, and finite receiver event. Its payment proof uses these hypotheses (cap, ownership, tail and actual component labels), not a special FULL identity. The later historical specialization to a particular FULL gate is not a hidden hypothesis of this broad decomposition.

For fixed full f>=0 inL1, a>0, a<=b<=2a, lambda>0, define G0=sup_[a,b]h_R*f and E={2lambda<G0<=4lambda}. The scale envelope has integralAn W; hence|E|<=An W/(2lambda)<infinity. Joint continuity in(x,R) follows fromL1 source and compact positive scale interval: bounded kernels and moving cube boundaries of zero Lebesgue source mass give dominated convergence. Compact maximization is attained; the minimum argmax is Borel (measurable maximum/closed-radius exhaustion). Choose R* initially and keep it for all constructed gates. This does not require changing a previously frozen selector.

Take the probability space to be a singleton, nu=f dz prereceiver-frozen, and G(x,z)=1_E(x)lambda/[h_(R*(x))*f(x)], zero offE. OnE this lies in[1/4,1/2), is measurable and independent ofz. Direct actual traffic integration is EXACTLY

T=integral_E G(x)h_(R*(x))*f(x)dx=lambda|E|=X.

Thus R104 gives X<=P104+X/768+T_heavy^new, equivalently X<=768/767(P104+T_heavy^new). P104 is the explicit I2 sum with Wcap+Wres=W and the dimension-free known strong-L2 constant C2; its finite root-polylog coefficient is uniform in f,a,b,lambda. The compact K0 tail cutoff depends on finite X and full f, chosen globally before individual receivers. It is an existence construction for arbitraryL1, not an effective integration oracle claim. W=0 or E empty is trivial.

Crucially T_heavy^new is R104's actual residual rebuilt from THIS f,G,R*: high-density excess, harmonic ownership deficit, non-small truncated capture and frozen heavy component. This supplies a direct original whole-hardband entrance to that heavy target; it does NOT identify it with historical R_out or R302 low-pe/high-m traffic. Such an identification or new heavy-source bound is still required, with all complement and multiplier fees. Native hardwinner identity is valid by this initial construction, not by frozen-selector invariance. Full weak-event/band assembly beyond this hardband is not supplied by this entrance.

## Actual local diagnostics

{'tent': 837, 'weight': 837, 'entry_band': 4, 'entry_absorption': 3}

Executed exact Python Fraction scalar tests of the two tent regimes, zero/equality endpoints, legal weight bound, normalized hardband identity and768/767 absorption arithmetic. All PASS. These are scalar diagnostics, not a full FIRST/history/input realization; the continuum statements are proved analytically above. Author comparisons and final bindings follow below.


## First frozen author comparison — PASS

Read /tmp/r316_joint.md after the independent screens were saved. Frozen SHA25675239f99f28677365a14a8e10bc74a4444d7fd229cef996046b4ef93c6fc0d5b agrees with the independently derived tent theorem. The optional preliminary clipped weightw, disjoint first-moment supports, minimal residual, v<=w, original positive pair representation, exact R315 inherited coefficients and H0/a=b regimes are correct. Its unrestricted quota identity is explicitly not commuted through the high-J gate. The declared remaining low-A collar-far fee retains v and original J/A/masks, while the tent is not presented as an original traffic allocation. No correction requested. Numerical1786 scalar assertions are evidence for scalar algebra only; this reviewer has not rerun those author tests.


## Actual common-source transfer audit — PASS as a bounded incomplete route

Read /tmp/r316_geometry.md, SHA256a53f967f3a6de9921e806d8dc40faa7cb180cfb06e7ac4dc67703f4e2c61fd33. Its weighted slack is exact and its tent/R315 compatibility agrees with the independent screen. With actual Y_z(r)={J>=H,0<A<H}, m=beta(Y), C=integral_Y A beta, shared FIRST after dropping the y-activity restriction gives C<=r^n at the original receiver; it is not a virtual-center FIRST. Concavity gives integral_Y g(A)beta<=min(C,dm)-(d/H)C. Maximizing only these scalar necessary constraints indeed yields(1-d/H)min(r^n,dm), hence at most the old A_n scale cost. This is explicitly a relaxation, not an original-kernel counterexample. The pairwise one-interval activity property does not pay repeated cross-row source occupancy. The sufficient inequality(13) is clearly unproved, may be stronger than needed for the collar piece, and is not smuggled into a theorem hypothesis. No correction requested or new root payment recognized. Its810 diagnostics are algebra/relaxation checks; no continuum realization is claimed.


## Constructive entry author comparison — analytic PASS

Read /tmp/r316_entry.md after the independent source/statement derivation. Direct full-hardband traffic is exactly X, and its768/767 multiplier is correct. Its P104 coefficients are correctly expanded:4D104/delta104=24576sqrt(n),4/beta104²=150994944 and cap coefficient768C2²sqrt(n). The displayed uniform K_n bound uses complementary Wcap+Wres=W only, with no hidden dimension dependence in the assumed known C2. The new concrete heavy remainder matches R104 I11 source, gates and component threshold; it is not old R_out. Weighted height bands have weights2^(1-j) with sum4, and remain for one fixed physical octave; no all-scale location sum is supplied.

Also directly read GENERAL_CURRENT_REDUCTION.md §§1–2,7. It explicitly fixes common q (not receiver-varying source threshold) and the all-softness angular/low-source deletions. On the retained native event S>=3q/4 and H>=G0-q/4>7lambda/4, so the proposed high-source joint normalization lambda/(SH)k_s mu has total lambda/H<=4/7, density<=16/(21q)k_s mu, and hard-GOOD joint response exactly lambda. These use both original paid outputs once; they are not consequences of the future-softness cap at s=0. The source mu is prereceiver-frozen by common q. B_pre is added once and remains outside768/767 as stated. Basic R107 soft-majorization is satisfied; FULL/birth/history coverage and its failure complement are NOT thereby established. The optional native R_HP application of broad R104 gives coefficients756/755 and768/755 correctly, and is explicitly an alternative entrance.

## Entry fixture review — one grid clarification and one gate assertion requested

Read primary entry_checks.py before final freeze. Its full L1 comb and actual Lebesgue receiver boxes are genuine, with continuous interval containment/exclusion proving h_r*f=r^(-n) on the prescribed E, R*=1, and G=1/4,T=X. E is only a subset of the whole hard band; this fixture does not certify whole-band coverage or soft FIRST.

For the claimed2^n complete-blob macro mass and single-cell-per-source/index-spacing2 argument, explicitly choose the centered ownership grid A_i=product[i_j-1/2,i_j+1/2), i in Z^n, macro B_i centered at i with side5. This is an authorized deterministic shifted grid in R104. Without this specification, the standard unshifted grid makes integer-centered blobs straddle cells and an outer macro may contain only1.5 full-blob masses per coordinate; the asserted2^n lower bound would be false. Centering the grid repairs the stated proof with no heavy-value change.

The fixture also needs G1's full b_full>=delta104 lambda=1/12288, in addition to the final b_K>=beta104lambda=1/24576. Actual res=1-sqrt(n)eps^n/4 is well above both on the listed n>=4; replacing the recorded retained-capture assertion by the stronger1/12288 verifies both without changing the count. Both bounded requests were sent to the primary; final numeric/log hash binding awaits their correction.


## Final fixture corrections verified — PASS

Read corrected entry_checks.py and the corresponding final combined.md/research.tex paragraphs. Ownership cells are now explicitly centered A_i=product[i_j-1/2,i_j+1/2). The2^n blob-mass lower bound is restricted to CONTRIBUTING macros with v_i>0 (hence u_i>0); other macros may have positive mass, but their u_i=0. Thus no false assertion about every positive-mass macro or every H_i is retained, and Theta=0 follows correctly. The retained-capture assertion now uses res>=1/12288, covering both G1's delta gate and the final beta gate. Primary fresh entry log records1185 PASS after these changes. The analytic source/receiver geometry and heavy value res*X are unchanged.

The entry fixture has actual positive Lebesgue receiver boxes and normalized positive-volume source boxes. Its continuous all-radius formula follows from exact full-box inclusion/exclusion on E, not the finite radius samples. The3^n source count, volume3^n/2^n, W=3^n, M=1, R*=1, G=1/4 and X=receiver_volume/4 are correct. With the stated centered grid, every contributing macro has at least2^n complete residual blobs;2^n>2sqrt(n) on listed n>=4 makes its gate fail. Source-cell index spacing2 gives one connected component, tail0;3^n res>lambda3^sqrt(n)>lambda exp(sqrt(n)) proves the heavy threshold. No original soft FIRST, complete-band test realization or extremality claim is inferred from this specified receiver SUBSET.

## Final integration and evidence — PASS

Read final checkpoint combined.md, README.md and research.tex statically, without compilation or edits. The full-source normalized entrance, exact P104 price, finite-X/measurable-winner contract, concrete native heavy residual, optional high-source joint entrance, and old-capacity tent theorem match the author proofs and independent screens. The two entrances/old-capacity theorem are explicitly NOT asserted to form a closed chain. New H_native is not relabeled old R_out or T. Qualification-failure complements have to be constructed and paid; historical I/J/D/suffix/negative terms arise only on a branch with an authentic history decomposition, rather than being appended without identity to the fresh heavy target. Fixed-octave response bands have geometric weights summing4; no all-physical-scale/octet-location gluing is supplied.

Tent inheritance has no extra source fee or degree/row copies, and removes only its own A>=H variance remainder. It does not change the original pair or source allocation. The exact unpriced remainder retains the weightv, original highJ/fullA/fullJ,0<A<H, collar, low-layer and far-missed-receiver restrictions. R315 receiver/root-source alternatives and R313 quotas are not counted twice. Source/height/aspect dependence through lambda*d is retained. No contact defect is dropped for an uncertified frozen old winner. Fresh native maximizers do have zero defect at their own initially constructed interface.

Inspected primary fresh-run logs: capacity1786 exact Fraction assertions (author/checkpoint JSON byte-identical), packing810, and entry1185, total3781. Their numerical ranges and limitations are correctly described. This reviewer did NOT rerun those logs' full scripts and attributes their execution to the primary. This reviewer independently executed837 tent+837 weight+4 band+3 absorption exact scalar diagnostics recorded earlier; these are separate and not included in3781. The source-envelope and continuum conclusions are analytic, not established by finite diagnostics.

## Frozen bindings

Hashes computed directly from reviewed final bytes. Checkpoint root: /Users/zhengzhihao/Desktop/T/output/centered_cube_round316_20261018_final_checkpoint.

| File | SHA-256 |
|---|---|
| /tmp/r316_entry.md | 11b7d67fce5e8e38dc46b5883a9cad80fd55befacc9c7eb6877625611b1a2bb1 |
| /tmp/r316_joint.md | 75239f99f28677365a14a8e10bc74a4444d7fd229cef996046b4ef93c6fc0d5b |
| /tmp/r316_geometry.md | a53f967f3a6de9921e806d8dc40faa7cb180cfb06e7ac4dc67703f4e2c61fd33 |
| /tmp/r316_input104.md | 9f6823adc67363c2aff02d27b97b96934ef27ef42bb1fd9a98a507834d7d95c6 |
| checkpoint/combined.md | 3161e35efe56b0a01995f92d0145b3b645185eac0f6a932d2b60fc1c9ba7fbc5 |
| checkpoint/research.tex | f201b9278dfe59bdc231a4b4f66765d4ae82fb326675a8e3d0c34f8f9f815af7 |
| checkpoint/README.md | f7ca6cd3739ca4f92b689d1be2ae79b501b97896bb835cb0f0b49d857cd97e43 |
| checkpoint/capacity_checks.py | 21420b5f2fbd695732ed8003c3c89ecc54f126a94bd7d07ef0b7161702303294 |
| checkpoint/capacity_checks.json | 683827cb6008a161eda4c7c0df79266d8b83a5514743f8e154d2ac7010713243 |
| checkpoint/capacity_checks.log | c6957596c392dc2ef1b1c8e9b4fe8ad819624889d157535f05b4490310e2f938 |
| checkpoint/packing_checks.py | 2661a85f035d8ade0e10759ac08be8a75a90a0aa9444978fd7122640bba211f7 |
| checkpoint/packing_checks.log | 1b328b7c891ba22e949942712ce9d8c1bbf9a24653fa9ffafb6a7b8281e8122e |
| checkpoint/entry_checks.py | 5cb0920f76de9446018640609867b6aa9d40d149deebbe4da8f0ff2cb388ee2e |
| checkpoint/entry_checks.json | df960516358e713771e7aee52996be7c4c81f756483e9e4a8ec2ab7e422f0548 |
| checkpoint/entry_checks.log | 5ecb834459b6573fcd2ef7802eb0be28b3bba1b3dadb5f09b056a92ffca6aa30 |

## Final verdict and exact remaining gap

PASS for the bounded statements and final integration. A genuine complete-hardband entrance now exists with coefficient768/767 and concrete positive H_native; the prior absence of that entrance should no longer be cited as its obstacle. Remaining obligations are a source-root bound for this new heavy target OR a proved qualification-preserving transfer with its full positive failure complement. Independently, R302/R315 now leave a smaller weighted low-capture collar-far fee but no source-root bound for it is proved; actual cross-row highJ/lowA packing is missing. The two results are not yet connected. Any subsequent original-history, extreme-aspect, outer-error and all-scale assembly must be justified on the actual route chosen. No general weak-type closure or final global absorption is certified. Audit frozen; no further expansion.
