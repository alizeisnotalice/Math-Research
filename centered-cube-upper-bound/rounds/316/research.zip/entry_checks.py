"""Preregistered R316 complete-source normalization diagnostic.
Three stages n=(1,4),(9,16),(25,36); epsilon=1/4,1/8.
Full L1 tensor grid of 3^n equal-mass epsilon boxes at {-2,0,2}^n.
Receivers: disjoint side-1/2 boxes at the same centers (actual Lebesgue).
All r in[1,2] capture exactly the own source box throughout this E:
max receiver displacement1/4 plus epsilon/2<=1/2;
nearest foreign support distance>=2-1/4-epsilon/2>1.
Thus continuous hard maximum=1, unique R*=1, lambda=1/4, G=1/4.
This E is a positive-volume subset of the full hard band, not the whole band.
No soft FIRST asserted. Heavy residual computed only for n>=4 where
all contributing macro masses (v_i>0, hence u_i>0) >=2^n*b exceed D*b.
Their ownership gates vanish; other macros have u_i=0, so Theta=0.
Ownership cells are explicitly A_i=prod[i_j-1/2,i_j+1/2), i in Z^n,
so source centers lie at cell centers and no source blob straddles cells.
K0 all source cells, one connected component via index-distance2<=3;
source-tail t=0. e<3 supplies an exact sufficient heavy-mass check.
Finite sampled tensor responses check the continuum proof's arithmetic;
no finite grid is offered as proof of a continuous maximum or all-input fee.
"""
from fractions import Fraction as F
from math import isqrt,prod
from pathlib import Path
import json
ct={};rows=[]
def check(key,cond):
 assert cond,key
 ct[key]=ct.get(key,0)+1
for stage,dims in enumerate(((1,4),(9,16),(25,36)),1):
 for n in dims:
  sn=isqrt(n);assert sn*sn==n
  for eps in (F(1,4),F(1,8)):
   N=3**n;lam=F(1,4);vol=F(N,2**n);X=lam*vol;W=F(N)
   cap_each=min(F(1),F(sn,4)*eps**n);res=1-cap_each
   check('source_cap_mass',W==N*cap_each+N*res)
   check('all_radius_own_inclusion',F(1,4)+eps/2<=F(1,2))
   check('all_radius_foreign_exclusion',F(2)-F(1,4)-eps/2>1)
   check('band_and_normalizer',2*lam<1<=4*lam and F(1,4)<=lam<F(1,2))
   check('exact_lebesgue_entrance',lam*vol==X and X/W==F(1,4*2**n))
   for center_pattern in ('central','corner','alternating'):
    centers=[0 if center_pattern=='central' else 2 if center_pattern=='corner' else (-2 if i%2 else 2) for i in range(n)]
    for off in (F(-1,4),F(0),F(1,4)):
     xs=[F(t)+off for t in centers]
     for r in (F(1),F(5,4),F(3,2),F(7,4),F(2)):
      factors=[]
      for x in xs:
       overlap=sum((max(F(0),min(x+r/2,F(c)+eps/2)-max(x-r/2,F(c)-eps/2)) for c in (-2,0,2)),F(0))
       factors.append(overlap/(eps*r))
      resp=prod(factors)
      check('tensor_response',resp==r**(-n))
      check('winner_sample',resp<=1)
   heavy=None
   if n>=4:
    check('ownership_gates_fail',2**n>2*sn)
    check('retained_captured_mass',res>=F(1,12288))
    check('one_component_heavy',N*res>lam*3**sn)
    heavy=lam*res*vol
    check('actual_heavy_identity',heavy==res*X and 0<heavy<X)
   rows.append({'stage':stage,'n':n,'epsilon':str(eps),'source_boxes':N,'W':str(W),'receiver_volume':str(vol),'X':str(X),'cap_mass':str(N*cap_each),'res_mass':str(N*res),'heavy':None if heavy is None else str(heavy),'heavy_scope':'not computed' if heavy is None else 'actual normalized traffic on specified subset E; not whole band'})
check('absorb_direct',1/(1-F(1,768))==F(768,767))
check('absorb_mixed',(F(64,63)/768)==F(1,756))
check('absorb_mixed_coeff',(F(64,63)/(1-F(1,756)))==F(768,755))
check('joint_row',1/F(7,4)==F(4,7))
check('joint_density',1/(F(3,4)*F(7,4))==F(16,21))
out={'status':'PASS','check_counts':ct,'total_checks':sum(ct.values()),'rows':rows,'scope':__doc__}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'status':'PASS','counts':ct,'total_checks':sum(ct.values())}))
