# R316 — clipped variance, a free saturation cutoff, and the remaining low-capture geometry

## 1. Original contract and conclusion

Fix one original outer-data/clock instance. Keep the actual full-soft U_y, all original alpha/low-pe/m/aspect/history qualifications, q>=q_-=3lambda/4, selected a<=L,R<=b<=2a, arbitrary finite positive L1 beta,nu, original FIRST rho(x)=integral U_y(x)beta(dy)<=1, and the same-selected-radius hard cap. Use the unchanged quantities

    A=A_yz(r)=integral_{R(x)<=r}U_y(x)c_x(z)dx,
    J=J_y(r)=integral_{R(x)<=r}U_y(x)dx,
    c_x(z)=1{z in Q_(R(x))(x)},
    ell_n=b^(-n)delta_b+n r^(-n-1)1_(a,b)dr,
    A_n=1+n log(b/a),
    F1=integral beta(dy)nu(dz)ell_n(dr) A<=A_n W_nu,
    T_target<=2O_d,
    O_d=integral beta nu ell_n min(d,A).

Here d=kappa0 psi_inf/(q_-v0)>0 and lambda d=(4/3)kappa0 psi_inf/v0 retain all original costs. The target entry is the supplied R302/common-rate bridge; no complete global ledger is newly asserted.

There is a useful sharpening of the R315 continuation: large accumulated capture A>=H can be deleted from its variance remainder at **no additional first-moment fee**. The remaining variance is multiplied by an explicit weight <=1 and has support 0<A<H. All R315 sequential source prices are inherited unchanged. This reduces the remaining geometry; it does not prove its general source-root payment.

## 2. Clipped inequality and the independently paid high-A part

For J>0, 0<=A<=J, set w=min(1,d/A), with w=1 at A=0. Then

    min(d,A)<=dA/J+w A(1-A/J).                       (1)

For A>=d this is equality. For A<=d the excess on the right is A(d-A)/J>=0. Define the clipped variance functional by integrating its second term over J>=H. For every K>=1 its part A>=Kd, with ANY existing additional multiplier in [0,1], satisfies

    Bclip_high<=F1_high/K<=A_n W_nu/K.               (2)

Indeed w A(1-A/J)=d(1-A/J)<=A/K there. No component FIRST is invoked; F1_high is a restriction of the single original first moment. If a uniform bound J<=J_star is used, the optimal scalar coefficient improves to

    Bclip_high<=K^(-1)(1-Kd/J_star)_+ F1_high.       (3)

The coefficient is attained at A=Kd,J=J_star when Kd<J_star; if Kd>=J_star the high piece is empty or zero. The full-soft row bound permits J_star=A_n Csoft_n/q_-, but neither that bound nor an independently normalized source is needed for (2).

Charging (2) in addition to a full (d/H)F1 fee would be avoidable. On high-J, high-A layers the ORIGINAL clipped integrand min(d,A) is already <=A/K. On the complementary high-J layers use (1). Since the two first-moment supports are disjoint, this gives

    O_d<=4lambda H W_beta
           +max(1/K,d/H)F1+Bclip_{J>=H,A<Kd}.        (4)

The early-row bound is exactly the original R302 bound, including a crossing radius atom. Thus for H>=d the choice K=H/d removes A>=H with no extra A_n/K payment.

## 3. The minimal nonnegative residual and its actual pair weight

Assume H>=d and put c=d/H. Define the tent

    r_(H,d)(A)=min(d,A)-c min(H,A)
      = A(1-c)                   for 0<=A<=d,
        d(1-A/H)                 for d<=A<=H,
        0                        for A>=H.          (5)

It is nonnegative. It is exactly [min(d,A)-cA]_+, so it is the smallest nonnegative pointwise residual possible against the chosen linear fee cA. Consequently

    O_d<=4lambda H W_beta+(d/H)F1+R_(H,d),
    R_(H,d)=integral beta nu ell_n 1{J>=H}r_(H,d)(A). (6)

For 0<A<H and J>=H put

    v_(H,d)(y,r,z)=r_(H,d)(A)/[A(1-A/J)],

and put v=0 elsewhere. Then

    0<=v<=w<=1,
    R_(H,d)=integral beta nu ell_n 1{J>=H}
                           v A(1-A/J).             (7)

For proof, (1) and d/H>=d/J imply r_(H,d)(A)<=w A(1-A/J). At 0<A<H<=J the denominator is positive. At A=0, A>=H, H=d or A=J the residual is zero and our zero definition avoids every division issue. Thus (7) is an actual nonnegative weighted capture/miss pair integral with the SAME J, A and original U. No posterior is recomputed after restriction.

Explicitly, its pair integrand is

    1{J>=H} v/J * U_y(u)U_y(w)c_u(z)(1-c_w(z)),
    R(u),R(w)<=r.                                  (8)

The weight v depends only on the fixed original y,r,z, not on a new choice of the two endpoints. Existing positive pair masks remain in any branch on which they are present; no claim replaces a separately qualified disagreement functional by physical-cube variance.

## 4. Combined R315 continuation, all parameters and fees

For this section use exactly the ADDITIONAL matched full-source contract in `/tmp/r315_geometry.md`: nu<=f, the same-center all-radius ceiling G0<=4lambda, and the actual old defect

    D_eff=integral_E rho(x)[G0(x)-h_(R(x))*f(x)]dx.

The defect is zero only for an authorized actual full-source hard winner. The legacy selected-radius cap alone does not grant this extra contract.

Every R315 sequential positive payment applies to (8), since 0<=v<=1. Retain v, the SAME A,J, and the gate 0<A<H in its unpriced collar-far piece. For fixed 0<eta<1,h>0 write

    r0=a/eta, t_h=max(a,b-2h),
    kappa_h=(1+2h/a)^n-1,
    b0=1+n log(min(b/a,1/eta)).

Let R_low(eta,h) be (8), integrated against beta,nu,ell_n, with ALL additional restrictions

    R(u)>r0,
    z in Q_(R(u))(u)\Q_(eta R(u))(u),
    r<t_h,
    |u-w|_infinity+|R(u)-R(w)|/2>h,
    0<A_yz(r)<H.                                   (9)

The true missed endpoint, both full U factors, original masks, J and v remain. The disjoint R315 bottom/deep/top/contact allocation proves

    R_(H,d)<=[b0+1+log(1+kappa_h)]W_nu
       +min{4eta^n X,(16/3)eta^n A_n Csoft_n W_beta}
       +4kappa_h X+D_eff+R_low(eta,h),               (10)

where X=lambda|E| and Csoft_n<=1+(pi/2)sqrt(n). This is one finite allocation, not a separate fee per A level or per source. Its source-price proof is inherited by positive domination; only the residual in (9) is changed.

All parameter regimes are now explicit. If a=b, O_d<=F1<=W_nu and T_target<=2W_nu directly. Otherwise set

    H0=sqrt(d A_n/(4lambda)).

If lambda d>=A_n/4, then H0<=d and no geometric remainder is needed:

    T_target<=2F1<=2A_n W_nu
                     <=4sqrt(lambda d A_n)W_nu.     (11)

This includes equality H0=d; its tent is identically zero. In the remaining regime lambda d<A_n/4, H0>d and (6) gives

    T_target<=4sqrt(lambda d A_n)(W_beta+W_nu)
                                      +2R_(H0,d).   (12)

For the ROOT-SOURCE choice eta^n=1/A_n and kappa_h=epsilon/4, i.e.

    h=(a/2)[(1+epsilon/4)^(1/n)-1], epsilon>0,

substitute (10) to obtain

    T_target<=4sqrt(lambda d A_n)(W_beta+W_nu)
       +(32/3)Csoft_n W_beta
       +2[2+log A_n+log(1+epsilon/4)]W_nu
       +2epsilon X+2D_eff+2R_low(eta,h).            (13)

These are exactly the R315 source constants, now with its full collar-far residual replaced by the smaller weighted low-A residual (9). There is NO extra A_n/K fee.

Alternatively, for 0<epsilon<8 choose eta^n=epsilon/8 and kappa_h=epsilon/8. The two new source lines in (13) are replaced by

    2[2+log(8/epsilon)+log(1+epsilon/8)]W_nu,

with that choice's own R_low(eta,h), while 2epsilon X and 2D_eff remain. The two eta,h choices cannot be interchanged. Every original outer multiplier Lambda multiplies every term inside its authorized original outer integration. Absorption of epsilon X requires the same independently established finite-X target entry; none is assumed here. No outer time, aspect cost, j copy or source normalization is free.

## 5. Exact relation to R313 quotas and the remaining geometry

This reduction is not a new first-d quota theorem. For the UNRESTRICTED tent occupancy there is the exact identity

    integral beta nu ell_n r_(H,d)(A)=O_d-(d/H)O_H,  (14)

where O_H means the capture-capacity threshold H, not a row cutoff. Its rank representation is the signed flux

    [1{A^o<d}-(d/H)1{A^o<H}]dA^o.

Use the one common theta refinement of each physical radius atom from R313 to interpret this flux. It has positive coefficient 1-d/H before capture rank d, negative coefficient -d/H from d to H, and zero afterward. Both capacities in (14) include the full physical R^(-n) and endpoint atom. Thus the identity neither drops cross-threshold atoms nor permits independently favorable source orders. For the row-restricted R_(H,d), its high-J indicator is kept in the original occupancy definition (6); no unproved interchange of that indicator with the signed flux is made.

R313 already avoids paying variance after the first d captures. What is useful here is narrower: an existing positive R315 variance allocation can be sharpened to a smaller weight with support A<H while preserving all its paid source fees. Paying a first-capture quota up to H afresh would lose this advantage and is not done. The tent itself is an auxiliary upper-bound remainder, not asserted to be a positive allocation of the original one-receiver traffic.

The remaining (9) has large actual row mass J>=H but limited accumulated capture 0<A<H, together with the genuine collar, distant missed endpoint and original masks. No allowed hypothesis yet forces its capture/miss overlap to be large enough for a source-root price. Full-source hard maximality controls same-center shells; it does not control the beta-weighted incidence of many rows still early in their own capture histories of one z. This note proves no general payment for (9), and no complete root theorem.

## 6. Executed exact diagnostics

The independently run self-contained script `/tmp/r316_checks.py` and its result `/tmp/r316_checks.json` use exact Fraction arithmetic and passed 1786 assertions in two fresh runs. There are 681 original clipping/high-gate assertions and 1105 additional tent assertions on 210 tent parameter tuples, including 55 H=d checks, 75 zero-outside-support checks, and 210 each for nonnegativity, domination, weight identity and weight range. The script imports no previous diagnostic model. These are scalar diagnostics only; they do not certify FIRST, the continuum source payment, kernel realizability or the unpriced geometry. The analytic source payments are proved above and in the cited R315 theorem.

Frozen diagnostic SHA256 values:

    r316_checks.py:   21420b5f2fbd695732ed8003c3c89ecc54f126a94bd7d07ef0b7161702303294
    r316_checks.json: 683827cb6008a161eda4c7c0df79266d8b83a5514743f8e154d2ac7010713243

Only `/tmp/r316_joint.md` is authored here. Other authors' files and Git are unchanged.
