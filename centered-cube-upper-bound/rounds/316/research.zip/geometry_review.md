# R316 — clipped collar audit and the exact shared-source packing obstruction

## 1. Scope, proposed estimate, and outcome

Retain exactly the R302/R315 contract: actual full-soft

    U_y(x)=1_E(x)alpha(x,y)P_(s(x),L(x))(x-y)/q(x),
    rho(x)=integral U_y(x)beta(dy)<=1,
    J_y(r)=integral_{R(x)<=r}U_y(x)dx,
    A_yz(r)=integral_{R(x)<=r}U_y(x)c_x(z)dx,
    c_x(z)=1{z in Q_(R(x))(x)},
    ell_n=b^(-n)delta_b+n r^(-n-1)1_(a,b)dr,
    A_n=1+n log(b/a).

The sources beta,nu are finite positive L1 sources, a<=L,R<=b<=2a, q_-=3lambda/4<=q<=lambda, and all original low-pe,m, full e_g, history, aspect and outer qualifications remain in alpha and in the target entry. Original FIRST is used only at original receivers. The same-R hard cap is nu(Q_R(x))<=4lambda R(x)^n. R315 additionally uses nu<=f and the same-center all-radius cap G0<=4lambda; it retains its winner defect D_eff unless R is a certified original full-source maximizer.

The candidate route was to use the clipped disagreement weight to convert repeated source captures into a common hard-source packing bound. The precise attempted improvement is a root bound for the low-source-capture part after the high-row gate J>=H, using the original full-soft high-J condition jointly across beta rows.

The scalar weight and inherited R315 receipts are valid. The attempted common-source packing step gives the explicit bound (9) below, including a negative overlap credit. It does NOT prove the desired root price: its sharp relaxation still permits A_n scale cost. No new root payment is claimed here beyond the inherited receipts and the independently supplied minimum-tent entry. The remaining missing input is stated in (13), for actual original soft rows, rather than assumed as a density or an arbitrary source agreement condition. This is a bounded audit of one concrete transfer attempt, not a counterexample to the original theorem.

## 2. Weighted entry, zero sets, and exact slack

For d>0 and 0<=A<=J, J>0, define

    w_d(A)=min(1,d/A) for A>0, and w_d(0)=1.

Then

    min(d,A) <= dA/J+w_d(A)A(1-A/J),                 (1)

and the right side minus the left side is exactly

    A(d-A)_+/J.                                     (2)

Thus the suggested B^clip_H,d is a valid replacement for B_H in the old R302 upper bound. Its weight depends on the ORIGINAL y,z,r through A_yz(r); it is not frozen as a source-only mask. Since it does not depend on which endpoint is called u or w, the weighted physical disagreement still has its exact symmetric and oriented representations. It is bounded by the original positive B_H, so the R315 bottom, deep, top and contact prices apply to its corresponding pieces. No new FIRST statement for the weighted rows is asserted.

A stronger entry supplied in this round uses H>=d. Define the minimum tent

    g_H,d(A)=min(d,A)-(d/H)A,     0<=A<=H.

Splitting high rows into A>=H and A<H gives

    O_d <=4lambda H W_beta+(d/H)A_n W_nu+R_H,d,
    R_H,d=integral beta(dy)nu(dz)ell_n(dr)
             1{J_y(r)>=H}1{A_yz(r)<H}g_H,d(A_yz(r)). (3)

Here the small-J payment and the single shared first-moment payment are the original R302 ones. No extra source charge is introduced for removing A>=H. This note records (3) for compatibility and does not claim its scalar derivation as a new geometric result.

On the active set 0<A<H<=J,

    v_H,d(A,J)=g_H,d(A)/[A(1-A/J)] lies in [0,1].      (4)

Indeed g is nonnegative and at most A(1-A/H)<=A(1-A/J). Set v=0 when A=0 and at zero denominators. Therefore R_H,d has the original oriented double-receiver representation with the single common factor v_H,d(A,J). It is this factor, not independent endpoint marks, that is retained in the collar remainder.

All functions are measurable functions of the original integrals. The denominators in (4) are positive on its stated support. Positivity permits Tonelli without any unproved selection or minimax step. The complete integrals are finite under the original first-moment bound F1<=A_n W_nu; all signed credits below are also bounded by that finite first moment.

If the usual H=sqrt(d A_n/(4lambda)) is less than d, then lambda d>A_n/4 and the coarse bound T_target<=2O_d<=2A_n W_nu already implies T_target<=4sqrt(lambda d A_n)W_nu. Hence the tent case needed for that choice is H>=d. For H=d the tent is identically zero.

## 3. What the clipped entry inherits, with the correct residual

Use the same sequential R315 allocation, but multiply EVERY positive integrand by v_H,d(A_yz(r),J_y(r)). Denote the final weighted collar-far piece by R_c,far. Its full support is

    J_y(r)>=H, 0<A_yz(r)<H,
    R(u)>a/eta,
    z in Q_(R(u))(u)\Q_(eta R(u))(u),
    r<t_h=max(a,b-2h),
    ||u-w||_infinity+|R(u)-R(w)|/2>h,

and it still contains U_y(u)U_y(w)c_u(z)(1-c_w(z))/J_y(r) times v. No A,J, source restriction or winner is recomputed. Since v<=1, the R315 positive domination arguments imply, for its root-source choice eta^n=1/A_n and kappa_h=epsilon/4,

    R_H,d <= [2+log A_n+log(1+epsilon/4)]W_nu
           +(16/3)Csoft_n W_beta+epsilon X+D_eff+R_c,far. (5)

This is the inherited receipt, not a newly proved root estimate for R_c,far. The receiver version instead has eta^n=kappa_h=epsilon/8 and source coefficient 2+log(8/epsilon)+log(1+epsilon/8), exactly as in R315. The oriented collar subset is bounded by the full symmetric top/contact pieces before using their symmetry.

Combining (3),(5) and T_target<=2O_d retains the original term

    8lambda H W_beta+2(d/H)A_n W_nu,

plus twice the right side of (5). At the usual H this first line is 4sqrt(lambda d A_n)(W_beta+W_nu). The original identity lambda d=(4/3)kappa0 psi_inf/v0, and every original positive outer multiplier and clock, remain on ALL terms. Epsilon X is not absorbed without the separately established matching global entry.

## 4. A true shared-source census, retaining the negative credit

For each fixed ORIGINAL z and r, define the actual active beta rows

    Y_z(r)={y: J_y(r)>=H and 0<A_yz(r)<H},
    m_z(r)=beta(Y_z(r)),
    C_z(r)=integral_(Y_z(r)) A_yz(r)beta(dy).          (6)

These are actual data, not freely chosen weights or new inputs. If m=0, C=0 and all expressions below are zero. If m>0 then 0<C<Hm. The common receiver FIRST gives the genuine geometric bound

    C_z(r)
      <=integral_{R(x)<=r}c_x(z)rho(x)dx
      <=|Q_r(z)|=r^n.                               (7)

The first inequality drops the y-dependent activity restriction only after writing the original beta and receiver integrations. The second uses actual R(x)<=r and capture z to put x in Q_r(z). It does not evaluate FIRST at z or at a virtual center. The pointwise source count m is bounded by W_beta, but no local density ceiling follows.

The tent g_H,d is concave on [0,H]. Jensen, now over this SAME original beta restriction, proves the exact common-source upper certificate

    integral_(Y_z(r)) g_H,d(A_yz(r))beta(dy)
       <= min(C_z(r),d m_z(r))-(d/H)C_z(r).           (8)

In particular, with the nonnegative right side integrated against the original nu(dz)ell_n(dr),

    R_H,d <= integral nu(dz)ell_n(dr)
       [min(C_z(r),d m_z(r))-(d/H)C_z(r)].            (9)

This combines all beta rows BEFORE charging a hard source and keeps a real negative capture credit. It is a usable upper certificate for actual inputs, not an equality with R_H,d and not a new source-root theorem. A collar restriction can only decrease R_H,d; an upper certificate of type (9) for the whole remaining tent also bounds the collar piece. Arbitrary collar-dependent activity may not be substituted into (6) without redoing that inequality.

For comparison, maximizing the right side of (8) under ONLY the valid scalar data 0<=C<=min(Hm,r^n) gives exactly

    (1-d/H)min(r^n,d m).                             (10)

If r^n<=dm the maximum is at C=r^n; otherwise it is at C=dm. For fixed m>0 these values can be approached or attained in the scalar relaxation with equal A across the m units of row mass. This is an optimization of the displayed necessary constraints, NOT an assertion that the optimizer is realized by original full-soft kernels, history or hard winners.

Consequently the inequalities proved so far imply only

    R_H,d <= (1-d/H) integral nu(dz)ell_n(dr)
                                  min(r^n,d m_z(r))
             <=(1-d/H)A_n W_nu.                     (11)

The last integral uses integral r^n ell_n(dr)=1+n log(b/a). For H much larger than d, (11) has essentially the old scale cost. This explicit maximization identifies the exact failed inference: pointwise FIRST occupancy plus clipping, even with the signed Jensen credit, does not algebraically supply a root coefficient. Replacing m by W_beta or discarding the credit cannot repair it.

## 5. The actual additional structure and the smallest unresolved estimate

The original rows provide more than the relaxed constraints in (10). For fixed y,z, both J_y(r) and A_yz(r) are nondecreasing inclusive CDFs, and A<=J. Thus

    {r: J_y(r)>=H and A_yz(r)<H}                     (12)

is an interval in the ordered radius set, possibly empty and with the appropriate one-sided endpoint inclusion. Adding 0<A may remove an initial subinterval. A row cannot repeatedly enter and leave this set. An atom may cross J and A thresholds together, making the interval empty; no continuous crossing is assumed. The interval endpoints need not themselves belong to the set (for example a level can be reached as an infimum without being attained), so (12), not a guessed endpoint convention, is the definition used in all integrals.

However, this single-interval property is for each PAIR (y,z). Charging each such interval a separate W_nu would copy the hard source once for each beta row. Nor does A<H imply a small probability of capture at the next receiver: its definition is cumulative mass, not a conditional probability. The same original kernels must constrain the combined interval occupation (6) across y.

For this concrete common-source route, the remaining sufficient inequality is

    integral nu(dz)ell_n(dr)
       [min(C_z(r),d m_z(r))-(d/H)C_z(r)]
       <=epsilon X+C_epsilon sqrt(A_n)log^p(n+2)
                               (W_beta+W_nu),       (13)

with the actual m,C from (6), original U, and explicit lambda d/H/aspect dependence if present. It would close this upper-certificate route; it may be stronger than necessary for the original collar integral. It is not inferred from (7), interval occupation alone, nu<=f, or hard maximality. A less demanding improvement can directly bound the weighted collar piece in (5), retaining its opposite endpoint and original alpha.

The needed new step is therefore a cross-row estimate connecting the high full-soft row mass J>=H with the source-conditioned interval occupation in (6), or a direct weighted collar overlap bound that avoids Jensen. No such step has been proved in this note. In particular, winner radial growth constrains f(Q_(eta R)(x)) at one receiver, but does not give a lower bound on A_yz/J_y across a different full-soft row. The old R302 selector has no certified higher-softness FIRST; native R312 future caps cannot be imported here.

This changes the attempted proof target in a precise way: the remaining problem is not merely to bound repeated saturated captures (those have already been removed at no extra source fee), and it is not an arbitrary nonnegative radial occupancy. It is the actual common-source occupation of low-capture intervals of high full-soft rows. The formulas above give an executable diagnostic and mark exactly where a geometric estimate is still required. They do not turn the missing estimate into a new assumption of the theorem.

## 6. Fresh finite checks, with limited scope

The following isolated exact-Fraction diagnostic checks the weighted scalar slack, the stronger minimum-tent majorant, and the common-source Jensen certificate. It also checks the exact scalar maximization (10) in three ranges, including H=d, zero activity and capture values at d,H. A fresh isolated Python process passed 270 weighted-slack checks, 162 tent-weight checks, 162 shared-Jensen checks and 216 sharp column-max checks (810 exact checks total). These are finite algebra/relaxation checks, not claims of full-soft realizability or the unproved (13).

```python
from fractions import Fraction as F
from itertools import product
ct={'weighted_slack':0,'tent_weight':0,'shared_jensen':0,'column_max':0}
for stage in ((F(1,4),F(1)),(F(2),F(7)),(F(16),F(64))):
 for d in stage:
  for hm in (F(1),F(2),F(5)):
   H=hm*d
   for jm,am in product((F(1),F(2),F(9)),(F(0),F(1,8),F(1,2),F(1),F(2))):
    J=jm*H;A=min(J,am*H)
    w=min(F(1),d/A) if A else F(1)
    assert d*A/J+w*A*(1-A/J)-min(d,A)==A*max(F(0),d-A)/J
    ct['weighted_slack']+=1
    if A<H:
     g=min(d,A)-d*A/H
     assert 0<=g<=A*(1-A/J);ct['tent_weight']+=1
   for vals,weights in product(
       ((F(0),F(1,4),F(3,4)),(F(1,8),F(1,8),F(1,8)),(F(1,4),F(1,2),F(7,8))),
       ((F(1),F(2),F(3)),(F(0),F(1),F(0)),(F(1,3),F(2,3),F(1,2)))):
    aa=[H*v for v in vals]
    m=sum(weights);C=sum(w*A for w,A in zip(weights,aa))
    value=sum(w*(min(d,A)-d*A/H) for w,A in zip(weights,aa))
    assert value<=min(C,d*m)-d*C/H
    ct['shared_jensen']+=1
   for m,v in product((F(0),F(1,4),F(3)),(F(0),d/8,d,17*d)):
    cap=min(H*m,v)
    candidates=[F(0),cap,min(d*m,cap)]
    optimum=max(min(C,d*m)-d*C/H for C in candidates)
    assert optimum==(1-d/H)*min(v,d*m)
    ct['column_max']+=1
print('PASS',ct)
```

Only /tmp/r316_geometry.md is written. No other author file or Git state is changed. The proof attempt stops at the explicit unproved geometric step (13).
