# 第316轮：完整硬带直接入口与容量截断的最小正余项

## 本轮实质结果与未完成状态

一般 n^(1/2+o(1)) 一致弱型上界仍未证明。本轮有两个不同层次的进展，不把它们冒充已经接通的一条闭合链。

第一，完整原始硬带现在有直接、可构造且已核验系数的几何入口。用原输入归一化实际硬交通，使交通总量严格等于 lambda|E_band|，直接应用R104的通用正交通分解。入口不再需要先猜测旧S_core是否覆盖原输出。

第二，对已有R302容量入口，可以不用新增来源费便删除累计捕获A>=H的全部余项。第315轮全部已付来源价格保持不变；真正剩余的几何带有精确权重，并限制在J>=H、0<A<H的中间薄壳—远遗漏接收点交通。此步降低了需要证明的引理强度，不要求整个旧B_H均根阶。

两者之间的新重组件到旧low-pe/容量目标的合法分支构造尚未完成。未证明的跨行低捕获预算、资格失败补集和全尺度拼接不会被删去。

## 1. 完整硬带的直接归一化

任意完整f>=0∈L1(R^n)、W=∫f、lambda>0和0<a<=b<=2a。令

M(x)=sup_(a<=r<=b) h_r*f(x), E_band={2lambda<M<=4lambda}, X=lambda|E_band|。

h_r是全边长r的中心立方体平均。硬平均在(x,r)、r>0上连续；紧半径区间存在最大值，可选最小最大化半径R*(x)，其可测性由子区间最大值的可测性得到。全硬包络质量A_n=1+n log(b/a)，故2X<=∫M<=A_nW；吸收之前X已有限。

取预先固定的来源nu=f dz、单点概率seed，并定义

G_N(x,z)=1_E(x)lambda/M(x)，在E外定义0，不在零分母处分式求值。

在E内1/4<=G_N<1/2。于是

T_N=∫_E dx∫G_N(x,z)h_(R*(x))(x-z)f(z)dz=X

精确成立。保持原f、真实Lebesgue dx、实际中心/尺度；没有把f替换成逐接收点的捕获来源，没有插入缺乏覆盖证明的FULL门。

R104 proof.md99–117及821–842的正式定理允许任意上述G∈[0,1]；844–929的付款证明不要求其来源于历史S_core。历史FULL实例只是该通用定理的一个应用。将新T_N代入，得到

X<=P104(f,lambda)+X/768+H_native，
X<=(768/767)[P104(f,lambda)+H_native]。

这里H_native是本轮按原通用算法真正构造的正重组件交通，而非旧R_out的新名称。

## 2. 已付系数、重组件与零情形

定义f_cap=min(f,√n lambda)、f_res=(f−√n lambda)_+，W_cap+W_res=W。准确价格为

P104=768 C2²√n W_cap
 +{2√n[1+log(24576√n)]+1+log(150994944)+√n}W_res。

C2保留为已证维度一致立方体强L2常数，不赋予未核数值。P104=O_(C2)(√n log(n+2))W。只有此处真实互补W_cap+W_res=W允许取两个系数的max；其他模块的费用应相加。

W=0或X=0时交通为零，不进行不必要归一化/尾截断。非零时令D=2√n、δ=1/3072、β0=1/6144、H_n=1+nlog2。原边长a半开所有权格A_i与B_i=Q_(5a)(c_i)按实际nu_res=f_res dz冻结。记v_i=nu_res(A_i)、m_i=nu_res(B_i)、u_i=Dv_i/m_i，零分母项置零。定义

H_i(x)=1_{nu_res(B_i∩Q_x)>=m_i/D}1_{nu_res(B_i∩Q_x)>=δ lambda R*^n}，
Theta(x,z)=Σ_i u_i1_(B_i)(z)H_i(x)，
G_1=G_N 1_{nu_res(Q_x)>=δ lambda R*^n}(1−Theta)_+。

选有限格并K0使∫_(K0c)f<=X/(3072H_n)，它只依完整输入和全局X，不依单个接收点。K0内正f质量格按索引无穷距离<=3连接，得到固定不交组件C。实际Q_x正捕获时只有一个组件C_x。记b_K=nu_res(K0∩Q_x)、m_C=nu_res(C)。新余项为

H_native=∫_E dx∫_(K0)G_1(x,z)h_(R*)(x-z)
  1_{b_K>=β0 lambda R*^n}1_{m_(C_x)>lambda a^n exp(√n)}nu_res(dz)。

无组件的接收点贡献0。其高密度excess、所有权缺额、有限来源截断、捕获下界和重组件条件均为实际定义。小捕获、cap和两次来源尾的接收费用合计<=X/768，不重复吸收。新余项可能非零，根阶空间付款仍未证明。

## 3. 软/硬共同来源的可选准确入口

如后续需要原软核共同来源，可在native原基线、物理端点、角坏集、完整低源L2删除后的E_ret上使用已证

S(x)=∫k_s(x,y)mu_hi(dy)>=3q/4，
H(x)=∫k_h(x,z)mu_hi(dz)>7lambda/4。

mu_hi=f1_{f>q√n}固定；k_s=P_(σ,L)GOOD_s，k_h=h_(R*)GOOD_h。硬低源界来自M_all包含s=0，硬BAD来自原两赢家B_all界，不能从s>=σ的future条件偷用。

Gamma_N(x,z;dy)=lambda k_s(x,y)mu_hi(dy)/(S(x)H(x))

满足总质量<=4/7、Gamma_N<=16/(21q)P_(σ,L)(x-y)mu_hi(dy)<=q^-1P mu_hi，并且和实际硬GOOD响应相乘积分恰为lambda|E_ret|。这里没有I_HP门；若另插原high-potential/FULL等门，必须同时保留其正补集。

据此可得替代入口

X_band<=B_pre+(768/767)[P104(mu_hi,lambda)+H_native,hi]，

B_pre=(2C_base+8)√nW+(32/3)κ_nW+(256/3)K_*²√nW_lo。

FIRST只在E_ret使用；B_pre不再乘一遍768/767。此入口与完整f直接入口替代使用，不相加。虽然Gamma满足基本软主导合同，出生、whole-cell、共享LCA、CP/GP及历史资格仍要真实生成；失败补集未获免费预算。

## 4. 原容量入口的最小正余项

另从已经认证的R302目标T<=2O_d开始，保留原U_y、J_y(r)、A_yz(r)、ell_n=b^(-n)delta_b+n r^(-n-1)dr、全部资格和费用，

O_d=∫beta nu ell_n min(d,A)，F1=∫beta nu ell_n A<=A_nW_nu。

d=kappa0 psi_inf/(q_-v0)，lambda d=(4/3)kappa0 psi_inf/v0，不能抹去aspect等参数。

在H>=d时定义

r_(H,d)(A)=min(d,A)−(d/H)min(H,A)
 =A(1−d/H) (A<=d)，d(1−A/H) (d<=A<=H)，0 (A>=H)。

它是对固定线性费(d/H)A的最小非负点态余项：[min(d,A)−(d/H)A]_+。R302低J前缀付款（含跨阈值尺度原子）给

O_d<=4lambda H W_beta+(d/H)A_nW_nu+R_(H,d)，
R_(H,d)=∫beta nu ell_n 1_{J>=H}r_(H,d)(A)。

大捕获A>=H已包含在同一线性费内，没有新增A_n/K费用，也不按捕获层复制来源。

在0<A<H、J>=H时定义v=r_(H,d)(A)/[A(1−A/J)]，其他点v=0。于是0<=v<=min(1,d/A)<=1，且R_(H,d)恰为原捕获/遗漏pair积分乘v。分母为完整J；v按原(y,r,z)计算，不能在切割后重算。

所有参数均覆盖：a=b时T<=2W_nu。a<b且lambda d>=A_n/4时，T<=2A_nW_nu<=4sqrt(lambda d A_n)W_nu，无需余项。在lambda d<A_n/4时令H0=sqrt(dA_n/(4lambda))>d，得到

T<=4sqrt(lambda d A_n)(W_beta+W_nu)+2R_(H0,d)。

此“根阶表达式”仍含真实lambda d；若它随极端aspect变坏，不能宣布一般维度根阶。

## 5. 第315轮费用保持，剩余仅加权低捕获薄壳

追加第315轮同源全半径帽、nu<=f合同。取eta^n=1/A_n，h=a[(1+epsilon/4)^(1/n)−1]/2。原bottom/deep/top/contact正分割全部按v<=1继承，故

T<=4sqrt(lambda d A_n)(W_beta+W_nu)
 +(32/3)Csoft_n W_beta
 +2[2+log A_n+log(1+epsilon/4)]W_nu
 +2epsilon X+2D_eff+2R_low。

Csoft_n<=1+π√n/2。R_low保留原定向权U_y(u)U_y(w)c_u(z)(1−c_w(z))/J、高J门、v和

0<A_yz(r)<H0，R(u)>a/eta，z∈Q_R(u)(u)\Q_(eta R(u))(u)，
r<max(a,b−2h)，||u−w||inf+|R(u)−R(w)|/2>h。

它比上一轮C_(eta,h)小或相等，但尚未有根阶预算。完整receiver替代方案eta^n=epsilon/8、kappa=epsilon/8仍合法，deep/contact总收epsilon X，不把两种残项混同。

无行门的tent有精确恒等式∫r=O_d−(d/H)O_H，其rank形式含从d到H的负通量。带高J门时不将此门任意移入signed rank流；半径原子必须采用同一共同theta细化。不能以此重复领取R313首d配额付款。

## 6. 本轮未成功的共享来源尝试与下一真实瓶颈

对实际活跃行{J>=H,0<A<H}，设C_z(r)=∫A beta、m_z(r)=∫beta。FIRST只给C_z(r)<=r^n；凹性最多给

∫r_(H,d)(A)beta<=min(C_z,d m_z)−(d/H)C_z。

在该信息下的最佳放松上界为(1−d/H)min(r^n,d m_z)。它仍允许线性A_n费用。此项只定位该估计步骤的信息不足，不是实际原输入的反例，也不计作新根阶付款。下一证明必须利用实际软核的跨行关联与高J条件，或直接控制新H_native；不能继续丢掉这些结构后期望得到根阶。

完整硬带入口与旧容量引理现在各自明确，但尚未证明H_native/hi等于或受控于旧T。出生、whole-cell、FULL历史等资格应从新正交通真实构造，并计入失败补集。旧I/J/D、suffix、负项只在确实生成对应历史分解的分支上出现；不能将旧账所有项无身份地叠到新H_native上。

## 7. 数值范围、技能和交付

本机fresh运行：容量/权重1,786项Fraction检查（输出与作者JSON逐字节相同）；共享来源放松810项精确检查；新归一化入口1,185项精确检查。总计3,781项。它们与解析证明的范围严格区分。

新入口检验分三阶段n=1,4 / 9,16 / 25,36，每个n使用ε_box=1/4,1/8。完整来源是位于{-2,0,2}^n的3^n个边长ε_box、每个质量1的小盒，采用精确张量压缩；接收集为同中心边长1/2盒的并，是真实正Lebesgue体积，但只是完整硬带的一个子集。对整个接收集及所有r∈[1,2]，自身来源盒完全捕获、其他盒均不捕获，所以连续M=1、R*=1、lambda=1/4、G=1/4，T=X由解析几何证明。有限r菜单仅检算该公式，不冒充连续最大化证明。

此模型明确选用居中所有权格A_i=∏[i_j−1/2,i_j+1/2)，i∈Z^n，来源盒不跨格。n>=4时，该a=1格中正所有权质量v_i>0（从而u_i>0）的宏包质量至少为2^n b，D=2√n，因而所有有贡献的Hi失败；其他宏包u_i=0，故Theta=0；K0包含全部来源格、其索引间距2形成一个固定连通组件，且m_C>lambda 3^√n>lambda exp(√n)。b>=1/12288同时验证G_1的δ捕获门和最终β0捕获门。故该指定接收子集上的实际新重交通严格为bX>0（b=1−√n ε_box^n/4），不只是人工二元模式。n1不作此重交通计算。该模型没有认证原softFIRST、完整硬带或极值/一般空间界。

本轮使用64项工具A01检查lambda/M和lambda/(SH)的正分母、零输入与来源固定性；未调用CCT/SOS或未经验证的外部迁移定理。保留详细LaTeX、最终证明和独审、原件索引与三份独立复现脚本；生成JSON不重复上传，不编译PDF。实际模型扣额数据不可得，不估算成本比例。

同一octave内可用加权阈值bands（权重和4）得到完整弱事件的相应入口；跨octave及全尺度拼接本轮不认证。一般上界仍未完成，目标保持不变。
