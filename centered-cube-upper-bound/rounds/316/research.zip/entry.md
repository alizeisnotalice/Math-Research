# R316 — constructive complete-input entrance with exact coefficient

**Result:** A usable entrance is available directly from R104’s uniform positive-traffic theorem, without reconstructing historical S_core first. On the COMPLETE original hard octave band, normalize the actual hard response to make the positive traffic equal its output fee exactly. The resulting proved entrance is

`X_band <= (768/767) P104(f,lambda) +(768/767) H_native`,          (D)

with an explicit `P104=O_(C2)(sqrt(n)log(n+2))W` and an explicitly constructed original positive remainder H_native below. Thus `C_ent=768/767`. H_native is NEW native R104 residual traffic; it must not be renamed the old FULL R_out and automatically passed through R105–R302. The missing work has moved to concrete qualification-failure complements and their prices, rather than absence of a complete-band entrance.

The normalized full-traffic construction was suggested by the parent during this audit and independently checked here against R104’s formal hypotheses and proof. Only `/tmp/r316_entry.md` and the requested source extract `/tmp/r316_input104.md` were written. No Git or proof-completion claim.

## 1. Original sources and precise R104 scope

Let `R=/Users/zhengzhihao/Math-Research-centered-cube-work/centered-cube-upper-bound/rounds`. Archive locator `104::proof.md:99` means line99 of that member in `R/104/research.zip`.

R104’s formal input and proof are broader than the historical instance described in its hard-bridge commentary:

- `104::proof.md:99–117` allows measurable E, measurable selected R in[a,2a], full original f>=0 in L1, selected hard band `2lambda<h_R*f<=4lambda`, a source `nu_omega<=f dz` frozen before receiver selection, and ANY jointly measurable `G(x,z,omega) in[0,1]`. Line117 expressly permits simultaneous dependence on x,z,omega without independence or product-source assumptions.
- `104::proof.md:821–842` states the constructive theorem for all such given positive traffic. The proof at844–929 uses density capping, source ownership packages, actual capture gates, a finite source tail and actual component masses. It uses no FULL, birth, CP/GP, previously existing common terminal leaf, or posterior clock as a mathematical prerequisite.
- The cap proof at429–487 uses only G<=1, the unchanged hard selector and the dimension-uniform strong L2 constant C2. The package column proof at128–150 uses only the original source/selected hard upper cap and positive window integration.
- In contrast, `104::proof.md:709–729` describes the PARTICULAR historical instance `G=1_(E\Omega)S_core/q`, hard source `nu_h<=mu_hi`, and preserved historical FULL gates. This gives a legitimate application, not a requirement that every G in the uniform theorem must arise through that instance. The direct construction here uses the uniform theorem, not an assertion that its G equals S_core/q.

The source extract `/tmp/r316_input104.md` preserves original numbered lines97–150,418–487,709–729,817–929 for independent verification. No README status is used to establish these hypotheses.

## 2. Direct COMPLETE-band traffic: exactly X, no missing coverage

Fix arbitrary nonnegative f in L1(R^n), `W=integral f`, lambda>0 and `0<a<=b<=2a`. Define

`M(x)=sup_(a<=r<=b) h_r*f(x)`, `E_band={2lambda<M<=4lambda}`,

and choose the measurable actual hard maximizer `R*(x) in argmax h_r*f(x)` at the outset. All later objects are generated from this selector. The hard averages depend continuously on positive r for L1 f; the compact interval provides a maximum, and the usual measurable extremal selector supplies a measurable choice. This initial-choice availability was separately checked in `/tmp/r315_selector_provenance.md`; no old/new capture comparison is used.

Set `X_band=lambda|E_band|`, `nu=f dz`, take a singleton probability seed, and put

`G_N(x,z)=1_(E_band)(x)lambda/M(x)`.

The denominator is positive on E_band; define G_N=0 off E_band, without dividing there. On E_band, `1/4<=G_N<1/2`. In particular G_N is measurable, bounded by1, and may be independent of z. The source nu=f dz is fixed before receiver selection. Its density is exactly the complete original f, not a receiver-dependent capture measure.

The actual positive measure is

`dT_N=G_N(x,z)h_(R*(x))(x-z) dx f(z)dz`.

It satisfies the EXACT original-input identity

`||T_N||=integral_(E_band)lambda M(x)^(-1)[h_(R*)*f](x)dx=X_band`. (1)

No FULL predicate or source restriction has been inserted into(1), so there is no omitted positive complement at this entrance. Original Lebesgue dx is retained. Source measurability/finiteness are immediate from f inL1 and a>0. In particular the positive hard-octave envelope has mass

`A_n=1+n log(b/a)`,

and `2X_band<=integral M<=A_n W`; hence X_band is finite BEFORE any absorption. If W=0 or X_band=0, the traffic and all residuals are zero. The choice of R* also gives hard-contact defect zero from the start.

Apply R104 I2 to THIS explicit traffic. Its result is

`X_band<=P104(f,lambda)+X_band/768+H_native`.                  (2)

Absorbing1/768 gives(D), with no unknown original-entry multiplier. It holds for every complete positive L1 input and every octave location, under the same accepted strong L2 theorem used in R104.

## 3. The entire P104 price, with its actual dimension order

Use R104’s exact constants

`epsilon104=delta104=1/3072`, `beta104=1/6144`,

`D104=2sqrt(n)`, `H_n=1+n log2`.

For the direct source nu=f, set

`f_cap=min(f,sqrt(n)lambda)`, `f_res=(f-sqrt(n)lambda)_+`,

`W_cap=integral f_cap`, `W_res=integral f_res`, `W_cap+W_res=W`.

The precise source price from `104::proof.md:833–840` is

`P104=768 C2^2 sqrt(n) W_cap`

` +{2sqrt(n)[1+log(24576sqrt(n))]+1+log(150994944)+sqrt(n)}W_res`. (3)

C2 is the accepted finite dimension-uniform cube strong-L2 constant, retained symbolically; no unverified numerical value is used. Formula(3), not the name P104, proves its root/polylog order. Indeed for n>=1 it is at most

`K_n W`,

`K_n=sqrt(n)max{768 C2^2, 4+2log24576+log150994944+log n}`.      (4)

The maximum here is justified ONLY by the actual complementary source identity W_cap+W_res=W. New costs from other modules must be added, not combined by this maximum. No dimension exponent is concealed in C2.

Original proof accounting: the cap costs epsilon104 X; low capture costs delta104 X; choose the finite source truncation with outside mass `t<=X_band/(3072H_n)`, and its two tail transfers cost at most2H_n t. Their sum is exactly at most X_band/768 (`104::proof.md:923–927`). It is not a second X/768 after(2).

## 4. Explicit surviving positive native residual

The residual in(2) is not an unspecified optimal value. It is the R104 I11 construction applied to f_res and the actual normalized G_N.

Take deterministic half-open ownership cells A_i of side a, centers c_i, macro-packages `B_i=Q_(5a)(c_i)`. Under `nu_res=f_res dz`, define

`v_i=nu_res(A_i)`, `m_i=nu_res(B_i)`, `u_i=D104 v_i/m_i`,

with zero terms when m_i=0. At the actual receiver x define

`H_i(x)=1_{nu_res(B_i intersect Q_x)>=m_i/D104}`

`          1_{nu_res(B_i intersect Q_x)>=delta104 lambda R*(x)^n}`,

`Theta(x,z)=sum_i u_i 1_(B_i)(z)H_i(x)`,

`b_full(x)=nu_res(Q_x)`, `Q_x=Q_(R*(x))(x)`,

`G_1(x,z)=G_N(x,z)1_{b_full>=delta104 lambda R*^n}(1-Theta(x,z))_+`.

These packages/coefficients are frozen from the actual source, not selected anew for each receiver. The package capture tests and G_1 are permitted receiver-dependent gates. Source-tail tightness gives a finite union K0 of side-a cells with `integral_(K0^c)f<=X_band/(3072H_n)`. K0 depends on the complete f and the global finite X_band, not on a single receiver. Build the finite graph on its f-positive cells with index-infinity-distance<=3; its fixed components C are frozen source packages. Any actual Q_x captures at most one such component with positive source mass. Call it C_x on active rows; rows without one contribute zero. Let

`b_K(x)=nu_res(K0 intersect Q_x)`, `m_C=nu_res(C)`.

Then the exact retained positive subtraffic is

`H_native=integral_(E_band)dx integral_(K0) G_1(x,z)h_(R*(x))(x-z)`

`          1_{b_K>=beta104 lambda R*^n}`

`          1_{m_(C_x)>lambda a^n exp(sqrt(n))}nu_res(dz)`.       (5)

This is `104::proof.md:855–921` with the newly specified native f,G_N,R*. Its other actual restrictions include positive harmonic ownership deficiency, high source excess, finite truncation, non-small captured mass and a heavy fixed component. The old light-component and ownership costs have both been added in(3). The original proof handles countable package summation by positive Tonelli and finite bounds; no cell-count or depth multiplier is added.

H_native is nonnegative and still unpriced at the desired order. Equation(D) is therefore a useful general entrance, not a completed weak bound.

## 5. Whole octave weak event, if needed, without a new source-copy loss

For an arbitrary threshold eta>0, set `lambda_j=2^(j-1)eta`, `E_j={2^j eta<M<=2^(j+1)eta}`, j>=0. These disjoint bands cover `{M>eta}`. Apply(2) to each COMPLETE input f with its own original band and selector, not by transporting a previous band’s FIRST/history. Multiplying by `eta/lambda_j=2^(1-j)` and summing gives the actual entrance

`eta|{M>eta}| <= (768/767)[4K_n W + H_weak]`,

`H_weak=sum_(j>=0)2^(1-j)H_native(f,lambda_j,E_j)`.             (6)

For fixed a, M<=a^(-n)W, so only finitely many bands can be nonempty at fixed eta. The uniform source coefficient also follows from the convergent positive weight sum4, not an unweighted count of source copies. The heavy aggregate H_weak remains unpaid. Any passage from octaves to all physical scales still requires the original valid all-scale reduction with its exact hypotheses and costs; this audit does not certify that passage. In particular it does not sum an arbitrary single-octave weak receipt over all octave locations.

## 6. A direct HIGH-SOURCE joint representation when later joint tools are desired

The full-source normalized entrance above needs no soft FIRST at all. A second exact construction is useful on the native retained event E_ret AFTER the already-priced baseline, physical endpoints, angular deletion and whole-soft low-source deletion. Keep complete f, the same original q and fresh R*, native soft FIRST sigma,L_s, and fixed `mu=mu_hi=f1_{f>q sqrt(n)}dy`. Native original tools give

`S(x)=integral k_s(x,y)mu(dy)>=3q/4`,

`H(x)=integral k_h(x,z)mu(dz)>7lambda/4`,

`k_s=P_(sigma,L_s)GOOD_s`, `k_h=h_(R*)GOOD_h`.

The two hard-side subtractions have separate original justifications. `312::GENERAL_CURRENT_REDUCTION.md:15` pays the all-soft angular BAD-response event B_all f>q/8; its applicability to BOTH the original soft winner and hard winner is explicitly retained at line125. Thus the hard angular BAD response at R* is at most q/8; this is not inferred from the future-softness cap s>=sigma, which by itself excludes s=0. Independently, lines21–27 define M_all over the entire closed softness interval0<=s<=1 and delete M_all f_lo>q/8. Since P_(0,R*)=h_(R*), the total hard low-source response is also at most q/8. Hence the hard GOOD high-source response obeys H>=G0-q/8-q/8>2lambda-q/4>=7lambda/4, using q<=lambda. The soft GOOD bound S>=3q/4 is exactly lines32–36; line125 records the same native mixed-witness source fields. The selected hard winner and complete-source caps are also retained at `312::native_entry.md:24–40`. No component receives a new FIRST and neither paid output deletion is charged twice.

Define the actual joint source kernel

`Gamma_N(x,z;dy)=lambda/[S(x)H(x)] k_s(x,y)mu(dy)`

and hard source nu=mu, placing GOOD_h(x-z) in the hard gate. Its dependence on z is absent here; a z-dependent native pair gate would also be admissible to R104 if retained explicitly. On E_ret,

`Gamma_N(total)=lambda/H<=4/7`,

`Gamma_N(dy)<=16/(21q) P_(sigma,L_s)(x-y)mu(dy)`

`             <=q^-1 P_(sigma,L_s)(x-y)mu(dy)`.

Thus this is an actual joint measure satisfying the BASIC R107 soft-majorization interface, not merely a scalar G bound. Moreover

`integral_(E_ret)integral h_(R*)(x-z)GOOD_h(x-z)`

`                   Gamma_N(total)mu(dz)dx=lambda|E_ret|` EXACTLY. (7)

There is NO I_HP or arbitrary FULL gate in(7): adding such a gate without retaining its complement would destroy exact coverage. The resulting scalar hard gate is `GOOD_h lambda/H<=4/7`, source nu=mu<=f is fixed, and R104 applies again. With P104 computed by capping the actual mu density, not f, it yields

`X_band<=B_pre+(768/767)[P104(mu,lambda)+H_native,hi]`,        (8)

where B_pre is precisely the native output-deletion fee before the retained set:

`B_pre=(2C_base+8)sqrt(n)W+(32/3)kappa_n W`

`       +(256/3)K_*^2 sqrt(n)W_lo`.

This uses `X_band<=B_pre+lambda|E_ret|`; B_pre is NOT enlarged unnecessarily in(8). The new source price(3) uses W_cap+W_res=W_hi<=W. It is added to B_pre; no unrelated sources are declared complementary. FIRST remains asserted only on E_ret. This provides a native shared-soft/hard joint starting point if needed, with zero hard-winner defect and honest original dx/source coverage.

## 7. What is and is not inherited downstream

Neither(5) nor the high-source joint construction is automatically the old historical S_core/FULL traffic. Original `104::proof.md:713–716` only says its PARTICULAR S_core and restricted hard nu_h satisfy the required upper bounds. It does not say S_core covers all native mu_hi or that nu_h=mu_hi. Here exact native coverage is proved by(1)/(7) instead of asserting that equality.

In particular the generic R104 residual does **not** supply these old qualifications for free:

- **Birth/endpoint prerequisites for R105:** `t_C=(mu_hi(C)sqrt(n)/(e^2q))^(1/n)<=R*` at every participating hard source, and the whole-cell/top-physical deletions used to establish it. Deep birth is a later R105 residual restriction, not a generic R104 output property.
- **Original FULL source-pair/history structure:** the original shared forest, distinct-child LCA, source-once weights, CP/GP parent-mass gates, failure coins, early-exit/continuation gates and the original source identities supporting them. The basic Gamma domination in(7) is not a proof of those gates or a payment of their failure sets.
- **R107 and later retained-source conditions:** deep rank, specific low-mean tree input, rebuilt hard extraction/top-k/light/relative-mass branches, coupled soft residual, forbidden sets and high-m posterior requirements must arise from an actual matching construction, with its existing prices. A newly generated native Gamma can be used as input only to theorems whose hypotheses it actually meets.

The next genuine connector, IF the research route needs old FULL machinery, is now a clear mathematical statement about a known positive measure: construct an actual original-gate allocation F on H_native,hi (or H_native if working with f) and prove the cost of its qualification-failure complement. Schematically

`H_native,hi=H_(native,hi,F)+H_(native,hi,1-F)`

with every factor of F explicitly generated from the fresh native fields; establish the old joint hypotheses on the first term and a proved source/receiver price for the second. One may split first at the explicit birth predicate `t_(C(z))<=R*`, retaining the exact nonnegative failed-birth integral from(5) with its opposite indicator; this is already a concrete original positive complement, not a nonexistent definition. No uniform price for that complement is established here.

Once a legally qualified branch is passed through R116–R123, its actual low-pe, initial, genuine deletion-jump, future-deleted continuous and suffix pieces must ALL remain with their coefficients and negative credits once. Those historical pieces are not additionally appended to the fresh(5) before an identity creates them; doing so would mix two different ancestor ledgers. Far/aspect/contact complements must likewise be kept on whichever actual branch is used.

## 8. Optional native R_HP route and arithmetic evidence

A useful independent alternative is to start with the existing complete native entry `X_band<=A_paid+(64/63)R_HP` and write

`Gamma_HP(x,z;dy)=q^-1 k_s(x,y)I_HP(x,y,z)mu(dy)`,

putting GOOD_h in the scalar hard gate. Actual FIRST gives Gamma_HP(total)<=1. R104 explicitly ALLOWS its z dependence (`104::proof.md:117`), and nu=mu<=f is frozen. Hence

`R_HP<=P104(mu,lambda)+X_band/768+H_HP`,

`X_band <=(756/755)A_paid+(768/755)[P104(mu,lambda)+H_HP]`.    (9)

The exact native I_HP/GOOD masks remain; no assertion that this Gamma is old S_core is needed. This alternative has C_ent=768/755 and adds R104’s fees to the already-paid mixed-route fees. It is not combined with(D) or(8). The direct full-source entrance(D) is simpler and uses fewer inherited lemmas; the high-source representation(8) offers the basic joint domination explicitly.

Actual local Python/Fraction execution verified `1/(1-1/768)=768/767`, `(64/63)/768=1/756`, the coefficients756/755 and768/755 in(9), and the exact joint constants4/7,16/21. The calculation is evidence for constants; the positive-measure identities and source receipts above carry the analytic result. Remaining heavy/native qualification geometry is still open.
