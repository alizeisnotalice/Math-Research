from fractions import Fraction as F
from itertools import product
ct={'weighted_slack':0,'tent_weight':0,'shared_jensen':0,'column_max':0}
for stage in ((F(1,4),F(1)),(F(2),F(7)),(F(16),F(64))):
 for d in stage:
  for hm in (F(1),F(2),F(5)):
   H=hm*d
   for jm,am in product((F(1),F(2),F(9)),(F(0),F(1,8),F(1,2),F(1),F(2))):
    J=jm*H;A=min(J,am*H)
    w=min(F(1),d/A) if A else F(1)
    assert d*A/J+w*A*(1-A/J)-min(d,A)==A*max(F(0),d-A)/J
    ct['weighted_slack']+=1
    if A<H:
     g=min(d,A)-d*A/H
     assert 0<=g<=A*(1-A/J);ct['tent_weight']+=1
   for vals,weights in product(
       ((F(0),F(1,4),F(3,4)),(F(1,8),F(1,8),F(1,8)),(F(1,4),F(1,2),F(7,8))),
       ((F(1),F(2),F(3)),(F(0),F(1),F(0)),(F(1,3),F(2,3),F(1,2)))):
    aa=[H*v for v in vals]
    m=sum(weights);C=sum(w*A for w,A in zip(weights,aa))
    value=sum(w*(min(d,A)-d*A/H) for w,A in zip(weights,aa))
    assert value<=min(C,d*m)-d*C/H
    ct['shared_jensen']+=1
   for m,v in product((F(0),F(1,4),F(3)),(F(0),d/8,d,17*d)):
    cap=min(H*m,v)
    candidates=[F(0),cap,min(d*m,cap)]
    optimum=max(min(C,d*m)-d*C/H for C in candidates)
    assert optimum==(1-d/H)*min(v,d*m)
    ct['column_max']+=1
print('PASS',ct)
