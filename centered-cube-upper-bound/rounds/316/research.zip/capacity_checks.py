#!/usr/bin/env python3
"""R316 bounded exact scalar checks, independently coded from stated formula."""
from fractions import Fraction as F
from pathlib import Path
from collections import Counter
import json

def main():
 counts=Counter(); high=0
 def ck(name,value):
  counts[name]+=1
  assert value,name
 for J in [F(1,1024),F(1,8),F(1),F(3),F(1024)]:
  for d in [F(1,4096),F(1,8),F(1),F(17),F(4096)]:
   for ratio in [F(0),F(1,1024),F(1,16),F(1,2),F(7,8),F(1)]:
    A=J*ratio;w=min(F(1),d/A) if A else F(1);var=w*A*(1-A/J)
    ck('clipped_variance_nonnegative',var>=0)
    ck('scalar_domination',min(d,A)<=d*A/J+var)
    if A>=d:ck('saturated_equality',d==d*A/J+var)
    if A==0:ck('zero_capture',w==1 and var==0)
    for K in [F(1),F(2),F(16),F(1024)]:
     if A>=K*d:
      high+=1;ck('high_gate_A_over_K',var<=A/K);ck('high_gate_d',var<=d)
 # Explicit equality-gate sharpness: A=Kd, J=qA, var/d=1-1/q.
 sharp=[]
 for K in [F(1),F(2),F(16),F(1024)]:
  for d in [F(1,16),F(1),F(17)]:
   A=K*d
   for q in [F(2),F(16),F(1024)]:
    J=q*A;v=d*(1-A/J)
    ck('gate_boundary_sharpness',v/(A/K)==1-1/q)
    sharp.append(dict(K=str(K),d=str(d),J_over_A=str(q),variance_over_d=str(v/d)))
 for d in [F(1,1024),F(1,8),F(1),F(17),F(1024)]:
  for hr in [F(1),F(2),F(16)]:
   H=hr*d
   for jr in [F(1),F(2),F(16)]:
    J=jr*H
    for A in sorted({F(0),d/2,d,H/2,H,J}):
     if A>J:continue
     tent=min(d,A)-(d/H)*min(H,A)
     ck('tent_nonnegative',tent>=0)
     if A>=H:ck('tent_support',tent==0)
     else:ck('tent_inside_formula',tent==min(d,A)-(d/H)*A)
     ck('tent_scalar_domination',min(d,A)<=(d/H)*A+tent)
     variance=A*(1-A/J);v=tent/variance if variance else F(0);w=min(F(1),d/A) if A else F(1)
     ck('tent_weight_range',0<=v<=w<=1)
     ck('tent_weight_identity',tent==v*variance)
     if H==d:ck('tent_H_equals_d',tent==0)
 result=dict(status='PASS',arithmetic='exact Fraction',scope='Scalar finite diagnostics only; no original kernel, FIRST/source budget or realizability certification.',provenance='Self-contained independent implementation of formulas supplied by r286_joint_mass in R316 task; no prior scripts imported.',check_counts=dict(counts),total_checks=sum(counts.values()),high_gate_cases=high,sharpness=sharp)
 Path(__file__).with_suffix('.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
 print(json.dumps({k:result[k] for k in ['status','check_counts','total_checks','high_gate_cases']},sort_keys=True))
if __name__=='__main__':main()
