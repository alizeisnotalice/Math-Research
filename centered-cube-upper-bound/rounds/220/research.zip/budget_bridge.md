# R220 辅助：保原门的有限费用桥（不登记新根阶付款）

**结果范围。** 给一条把固定参数共同重叠界转成原正泛函有限费用的准确不等式。soft费、尺度/比例带菜单、实际Q下界、hard全来源质量、capture上帽和真实clock损失全部列出；没有证明它们在一般原输入下为根阶。以下不是原连续selector已离散化的声明，不重复Astra的D证明，也不重新领取浮动带或signed负账。

已读task_contract及R219冻结DG点态回代/精确乘积差；另读父级已审soft_envelope。只写本文件，无Git/spawn。固定(ω,V,j,y,t)时Π独立x,z；当前物理参数、Q、ρ0/history一般仍依x，不能先抽出。

## BB1 准确有限证书的输入

从原当前未付正项截取一个实际子集，其(L,R)取有限菜单Θj中的真实值；菜单值在固定(ω,V,j)后须独立x、y、t及各来源标签（若依y，须将相应费用留在β积分内，不能套下方统一C*式）；θ∈Θj记这些值，gθ=√(LθRθ)，Aθ,1=Lθ、Aθ,2=min(b,γLθ)、Aθ,3=b。σ1=σ2=s，σ3=1。实际ρ0及history不在网格节点重算。连续原尺度到此菜单的覆盖若未另证，就只估这个有限菜单子集。

对每个(ω,V,j,θ)明确给下列可检验费用：

* qVjθ>0是该实际子集中**原Q(x)**的统一下界（含全部其余标签）；没有该下界时以下价可为∞，不把Q提出x积分。
* 对固定y给ρθ*(y)∈[0,1]，在该子集内实际ρ0(x,y,v)≤ρθ*(y)1{Bhard=0}。安全选择是1；如使用更小值必须来自同一实际capture，不能以节点ρ0代替。零/非eligible行原ρ0=0。
* 给一个仅依(ω,V,j,θ,y)的合法clock上包络区间Iθ(y)=[ℓ,r]，覆盖该子集所有Jfar，且原et在其内有限正、非增，两端取原一侧值。它必须由原过程支持；不能在重段外发明Π。空区间交通与clock费先取零。若历史产生多段则每段单独列同样费用。

父级soft引理给一个只依n的有限节点集Sn，记Nn=|Sn|=O(√n log(n+1))，逐点H_s≤4Σq∈Sn H_q；n1也可用该保守常数。这里H只含半密度乘积、hard_R和固定B门，**不含依soft的Q、ρ0、good或history**。

最后假设所估各θ/腿/节点已获得固定参数几何证书
\[
0\le G_{\theta,m,q}(y,v,z):=
\prod_iD_i-1_{\{R_\theta\le L_\theta\}}\prod_iD_i^\cap
\le b_{\theta,m,q}.\tag{BB1}
\]
D、Dcap是R219/DG6的准确归一积分。证书须对全部实际来源y,v,z一致，或明确只估其已获证的子集。若只有D≤1可取b=1；若有真正uniform soft gap可保较小b。未证明的异尺度腿不能擅取1。令Bθ=Σm=1³Σq∈Sn bθ,m,q。

## BB2 有价回代定理与证明

设M_V=||νV||（hard **全来源**，不限制Zg），并定义
\[
 m_{Vj\theta}=\frac{M_V}{q_{Vj\theta}}(c_j/g_\theta)^n,
 \qquad h_{Vj\theta}(y)=\log\frac{e_{\ell+}(y)}{e_{r-}(y)}\ge0.
\tag{BB2}
\]
对原外2Λ、实际β和两份Π，整个上述有限菜单正量满足
\[
\boxed{\mathcal P_{fin}\le
8\Lambda\sqrt{K/3}\,\mathbb E\sum_{V,j,\theta}
 m_{Vj\theta}B_\theta
 \int\rho_\theta^*(y)h_{Vj\theta}(y)\,\beta_V(dy).}\tag{BB3}
\]
这是真实dx已完成的有限费用，右侧不再有hard z或原pair来源积分；不是把未付三来源列换名。

证明：保原good、ρ0、B和全部正门，先用R219合法点态式
\[
p_y\le\sqrt{K/3}\sum_{m=1}^3
\sqrt{p_yK_m(v)}/\sqrt{w_{g_\theta}(y,v)}.
\]
在θ状态中wg、hard_R、B不依soft。对这个半密度核用soft有限和；**仍保实际ρ0(s(x))、Q(x)、aω及全部门**，不让节点核继承原good/capture资格。随后仅作非负上放：1/Q≤1/q、0≤aω≤1、ρ0≤ρθ*1B0，其余正门≤1。此capture放松的ρθ*已经明确计价，不声称实际ρ0恒定。

此时固定y,t的原Π可移出x；每个节点的receiver积分准确保
\[
\int1_{B=0}\frac{\sqrt{p_{q,L_\theta}(x-y)K_{m,q}(x-v)}}
{\sqrt{w_{g_\theta}(y,v)}}h_{R_\theta}(x-z)dx
=(c_j/g_\theta)^nG_{\theta,m,q}(y,v,z).
\]
先用BB1，再对原全ν(dz)积分得M_V，**不使用也不另乘16/3硬帽**。这是与先用硬帽路线的备选价，不能对同量叠加。两个原Π及δ仍保留。

最后只用δ(v,u)≤kt(v)，先在u上用完整Π归一，再在原clock内积分：
\[
\int_{I_\theta(y)}\iint\delta_t\,d\Pi_t(v)d\Pi_t(u)\frac{dt}{t}
\le\int_{I_\theta(y)}E_{\Pi_t}k_t\frac{dt}{t}
\le\log(e_{\ell+}/e_{r-}).\tag{BB4}
\]
无删除段−∂logt loget=EΠkt，删除给非负log(epre/epost)，故最后方向正确。没有先δ≤n，没有把Π当独立坐标，也未丢删除质量；若终端为零或多段，应分别保∞或各段端点价。恢复2Λ、good的√(K/3)及soft的4，正得BB3。所有步骤先有限截断，有限费用下非负极限合法；未消费任何负项。

## BB3 哪些条件才把有限费变成来源付款

若实际证书进一步给H_Vjθ≥supy ρθ*(y)hVjθ(y)，并且
\[
 C_*:=\sup_{\omega,V}\sum_{j,\theta}
 m_{Vj\theta}B_\theta H_{Vj\theta}<\infty,
\]
则BB3完整付为8Λ√(K/3) C_* Wβ，其中Wβ=EΣV||βV||。**仅在原共同父账另已授Wβ≤WA时**才改写成WA；不由ν≤β推，也不将Wν与Wβ混同。j和θ已经真实求和收费，不能再用唯一j删去该和；多窗口亦按各自父账。

原比例带还给(cj/gθ)^n≤γ^n/max(Lθ,Rθ)^n<e/max(Lθ,Rθ)^n，故m的实际含义是全来源质量对Q·max(L,R)^n的密度比，量纲恰无量纲。它不是eg或ebar。即使b≤1、soft费已为O(√nlogn)，一般输入尚未授这份密度比、clock损失、尺度菜单合计为常数/polylog；不得据此说C*=O(√npolylog)。原Q*容量不支付ν全质量，hard z不能限Zg，ebar≥eg方向不能反用。

**停止结论。** BB3是有限费用桥，不是新一般root付款。它明确说明固定D与soft网格还须实际购买哪几份费用；ρ0与B的唯一放松及代价可检查。当前没有证明原连续尺度覆盖或C*根阶，故原未付支和所有负账保持。没有以近1特殊soft、抽象Schur/row、或已消费恢复槽另报进展。本机仅以Fraction核外常数2Λ·4=8Λ和128组上向比例带的密度单位恒等式；非新交通数值实验。完成停等。
