# R220：不同尺度共同重叠与真实自适应来源费用

上一轮已完成解析几何并推送4496288914d630397f4df3998bf2728c58611875，属实质进展。本轮仍追求一般正L1的一致n^(1/2+o(1))上界，未缩为特殊函数或固定尺度完成。R219冻结材料在 /Users/zhengzhihao/Desktop/T/output/centered_cube_round219_20261016_final_checkpoint。

原核h=1core,w=∫₀¹exp(−|x|/r)dr,φ=h*w,fs=(1−s)h+sφ,F=max(h,φ),C=h*F。原L,R∈[b/2,b],g=√LR，γ=1+1/n，cj=γ^−j，cj+1 g≤min(L,R)≤cj g；三目标腿(A,σ)=(L,s),(min(b,γL),s),(b,1)。严格soft为s>1−2^(−1/n)，非near1。

关键核候选准确是D=(g/cj)/√ω × (1/R)∫_[z−R/2,z+R/2]√[L^−1fs((x−y)/L)A^−1fσ((x−v)/A)]dx，ω=min(1,bC(|v−y|/b)/(cjg))。R219只证L=R=A=b,cj1时D≤1，且独立sσ有gap。一般尺度尚未证，不能从72个数值例宣称它成立。目标优先是能够支撑原root来源付款的有价几何估计；若此美观强型不成立，保留准确尺度/位移代价并利用原硬门，不长篇只否路线。

原硬门B=1_{R≤L}1_{Q_R(x)}(v)；ρ0>0⇒B0，固定尺度真实几何为两个坐标乘积之差。原positive保2ΛEΣVj∫aω/Q p_y h_Rz Mρ0δΠt² dxβdyνdzdt/t；Π=1Zt wtν/et已含两分母，δ=(kv−ku)+。不能ν≤β，hardz不能限Zg，全ebar≥eg方向不能替换；固定ω,V,j,y,t时Π独立x,z，但L,R,s,g/历史仍依x。原浮动已付带之外ρ0(wt−h0)>L0J/p，L0=K√n，h0=L0J/p+K0/(κT)。common FIRST∫pβ≤Q，hardcap16/3，fixedJ列归一，Q*容量为(K1+K2+J)/3≤Q；不可各K1ν≤Q。

分工：Astra负责异尺度解析几何scaled_geometry.md；Sol辅助负责真实自适应与source预算budget_bridge.md；Sol独审先审命题再审作者audit.md；Sol数值待准确探路方案后实现。主代理主要推导、合同、报告、归档与提交。所有人共享目录，不改他人文件、不Git、不自行扩Agent；只读必要R219片段，交付后停等。成功必须标清能否扩大原付款，有限数值不代证明。主代理使用N04误差账，不从单项界推总预算；不编译PDF。完成后独审、迁移driver全JSON字节比较、外部双备份、精简README+zip，独立提交push。
