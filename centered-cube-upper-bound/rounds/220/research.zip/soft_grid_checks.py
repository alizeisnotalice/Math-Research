#!/usr/bin/env python3
"""Finite generic affine-kernel envelope checks; not original traffic certificates."""
import argparse,hashlib,json
from pathlib import Path
import mpmath as mp
CASES=[('initial',2,'balanced'),('initial',8,'balanced'),('initial',32,'balanced'),('stress',2,'endpoint'),('stress',16,'tiny'),('stress',64,'tiny'),('expanded',128,'balanced'),('expanded',1024,'tiny'),('expanded',10000,'endpoint')]
def calc(n,kind,dps):
 with mp.workdps(dps):
  eps=mp.mpf(1)/n;q=1+1/mp.sqrt(n);left=[eps]
  while left[-1]<mp.mpf('.5'):left.append(min(mp.mpf('.5'),q*left[-1]))
  grid=sorted(set(left+[1-x for x in left]))
  if kind=='balanced':groups=[(n,'1','.6'),(n,'0','.2')]
  elif kind=='tiny':groups=[(2*n-1,'1','1e-30'),(1,'0','1e-30')]
  else:groups=[(2*n,'1','.2')]
  gs=[(m,mp.mpf(a),mp.mpf(b)) for m,a,b in groups]
  def logH(s):
   vals=[(m,(1-s)*a+s*b) for m,a,b in gs]
   if any(v==0 for m,v in vals):return mp.ninf
   return sum(m*mp.log(v)/2 for m,v in vals)
  def der(s):return sum(m*(b-a)/((1-s)*a+s*b) for m,a,b in gs)
  # Concavity yields a monotone derivative; evaluate an interior root or endpoint.
  lo=mp.mpf(0);hi=mp.mpf(1)
  def endpoint_der(s):
   for m,a,b in gs:
    if (1-s)*a+s*b==0:return mp.inf if s==0 else mp.ninf
   return der(s)
  if endpoint_der(0)<=0:opt=lo
  elif endpoint_der(1)>=0:opt=hi
  else:
   for _ in range(4*dps):
    mid=(lo+hi)/2
    if der(mid)>0:lo=mid
    else:hi=mid
   opt=(lo+hi)/2
  best=max(logH(s) for s in grid);ratio=mp.exp(logH(opt)-best)
  assert ratio<=4
  local=max([(v-u)*mp.sqrt(n)/min(u,1-v) for u,v in zip(grid,grid[1:])] or [mp.mpf(0)])
  # This floating check is reported without promoting rounding to a certificate.
  bound=2+2*(2+mp.ceil(mp.log(n-1)/mp.log(q)))
  assert len(grid)<=bound
  return {'dps':dps,'groups':groups,'nodes':len(grid),'node_bound':int(bound),'opt_s':mp.nstr(opt,dps),'sup_over_node_max':mp.nstr(ratio,dps),'ratio_le_four_numerical':True,'max_normalized_mesh_width':mp.nstr(local,dps)}
def main():
 p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=Path(__file__).with_suffix('.json'));a=p.parse_args()
 rows=[{'stage':stage,'n':n,'kind':kind,'runs':[calc(n,kind,d) for d in (40,70)]} for stage,n,kind in CASES]
 out={'schema':'R220_generic_soft_grid_v1','scope':'finite affine examples and floating grid; analytic proof separate; no original physical or source budget certificate','script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'cases':rows}
 a.output.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print('complete 9 configurations / 18 precision runs')
if __name__=='__main__':main()
