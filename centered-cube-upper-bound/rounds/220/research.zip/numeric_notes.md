# R220 scaled D：运行前完整菜单

只筛选准确kernel候选D=(g/cj) I/sqrt(omega)，I=(1/R)∫hard_R(z)sqrt[p_s,L(x)K_A(x−v)]dx，b=y单位设置b=1,y=0。omega=min(1,C(|v|)/(cj*g))，g=sqrt(LR)，gamma=1+1/n；actual j以Fraction平方比较定位，禁止浮点log猜索引。三腿为K_L、K_min(1,gamma L)（soft s）、J（A=1,soft1）。保原B0诊断：R≤L时I^n−Icap^n，R>L时I^n；Icap保来源区间与Q_R(v)交集。

完整菜单上限120配置，首个D>1即停网格并作60/80dps、GL192/384阶复核后报告，不继续无界搜例。

- 初探96配置：n=4,16；(L,R)=(.5,1),(1,.5)；s=gate+.001或.5，gate=1−2^(−1/n)；v=.75,1.25；z=0,v/2,v；腿K_L,J。
- 压力12配置：n=128；同两尺度；s=gate+.000001；v=.75,z=−2，或v=1.25,z=v+2=3.25；三腿全部。
- 扩展12配置：n=1024；同两尺度；s=gate+.00000001；v=4,z=2，或v=8,z=8；三腿全部。

每配置25/40dps和GL48/96阶，所有source区间、current及target hard/phi端点分片。C用自包含E4原函数，无外部数值文件依赖；记录本轮合同与参考R219代码的SHA256来源指纹。全部域有限，无无限尾省略；数值不是定向区间证书，不单独认证解析定理，不授原FULL、一般L1输入或source预算。脚本--output，JSON无时间/路径，最终完整字节复跑。首个D>1只否本候选，不称原FULL反例。

## 实际运行结果

120配置、240次精度运行全部完成，未发现D>1，未触发失败扩大精度分支。最大D=0.6559395665322960037016153511703027955208，配置(n,L,R,s选择,v,z,leg)=[16, '1', '.5', 'gate_plus_.001', '1.25', '0', 'J']。不据有限网格认证一般尺度解析定理。

|阶段|配置数|最大D|配置|
|---|---|---|---|
|initial|96|0.6559395665323|[16, '1', '.5', 'gate_plus_.001', '1.25', '0', 'J']|
|stress|12|0.0027380740802846|[128, '1', '.5', 'gate_plus_.000001', '1.25', '3.25', 'J']|
|expanded|12|0.017987373007059|[1024, '1', '.5', 'gate_plus_.00000001', '8', '8', 'K_L']|

25/40dps同时GL48/96的D最大绝对差为 1.3216e-11。每行准确使用gate<s<1、actual j/minratio Fraction平方证书、omega=min(1,C/(cj*g))及归一hard_R的I。源合同与参考R219冻结代码指纹在JSON中；计算自包含，不读取外部数值材料。

Icap及I^n−Icap^n在R≤L时保留，R>L时B0诊断为I^n；同区间Icap复用I避免虚假消减误差。所有乘方由mp高精直接计算，不据同坐标张量例猜一般输入或source付款。极偏来源与远位移结果全部在JSON，不缩窄hard来源到Zg。

有限域求积无需无限尾项；普通mpmath/GL非定向区间证书。没有找到D>1只说明本菜单未筛出强型候选失败；不认证原FULL或独立认证解析定理。

显式--output完整复跑后JSON逐字节一致；SHA256=2b46aa7620f704deadba322d351854d2b3ec7ea49f73250f53382c92ab979a46。脚本自包含，JSON无运行时或输出路径，未修改R219冻结材料。

复现：

```sh
PYTHONPATH=/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor /Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 /Users/zhengzhihao/Math-Research-centered-cube-work/centered-cube-upper-bound/rounds/220/work/scaled_probe.py
```

## V-envelope严格有理证书：运行前方案

只新增v_envelope_certificate.py/json。此证书以父级另证的V_r公式、r单调递增及V(t)单调递减为解析接口，不独立认证最终lemma。全程Fraction，无浮点证书。先取r右矩形64份及t等分40格；每t格[tlo,thi]计算Vupper(tlo)=(1/64)Σ_j V_(j/64)^upper(tlo)，核(1+thi)^2 Vupper(tlo)≤1。若64不够再以128重跑并保留尝试日志。

指数严格包络：x≥0；x=0精确1。x≥64用下界0、上界2^(−floor x)，其理由是e≥2。其余x二分至u=x/2^k≤1，以交错Taylor奇21项截断作下界、偶20项截断作上界；先向下/向上取整至分母10^24，再逐次平方k次并每步定向取整。所有取整和多项式均用Fraction/整数，平方只在非负区间上执行。V_r正指数项取上界，负2exp项取下界，避免相减方向失误。

每格保存准确V上界与归一上界及最大值，记录指数算法、计算计数、网格尝试及源码SHA256。解析单调性与公式仍由作者/独审负责；有限有理核验不是普通浮点探路。显式--output，完整JSON字节复跑，输出无runtime/路径。

## V-envelope严格有理证书：实际结果

64份r右矩形、40格t网格首次全部通过，无需128份。40个cell的比较均以Fraction精确执行；最大归一上界为

115508456693721590759701059838462162527748074964554537441/126765060022822940149670320537600000000000000000000000000

且精确满足最大值≤23/25<1。最大格编号25，端点[5/8,13/20]。这是有限有理证书，不是普通浮点结果。

指数缓存的独立有理输入数为3123；各类分支及定向平方次数完整记录于JSON。每个V_r表达式的两个正指数用上端点，负指数用下端点；每格右矩形上界、t_hi归一上界及剩余间隙都存精确分数。

此文件给出的蕴含链是：若已审V_r公式、r单调性和t单调性成立，则每格真实(1+t)^2V(t)被记录上界控制，故≤1。基本交错Taylor余项和e≥2为指数区间的解析依据。该数值文件不自行认证最终lemma或原traffic/FULL。

更新后两次完整运行（第二次显式--output）JSON逐字节相同。输出SHA256=ff577fbb332e9aaca5c7cb0213f0201980e2ca94c3ca46b1d2ad9f284a15ea34，源码SHA256在JSON内。证书运算全为Python Fraction/整数，复现不依赖mpmath或任何外部数据文件；无runtime/路径字段。

复现：

```sh
/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 /Users/zhengzhihao/Math-Research-centered-cube-work/centered-cube-upper-bound/rounds/220/work/v_envelope_certificate.py
```
