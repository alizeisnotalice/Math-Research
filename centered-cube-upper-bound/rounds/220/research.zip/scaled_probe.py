#!/usr/bin/env python3
"""R220 scaled D with actual proportional index and three kernel legs; not FULL."""
import argparse,hashlib,json
from fractions import Fraction as F
from pathlib import Path
import mpmath as mp
HERE=Path(__file__).resolve().parent
NODES={}
SOURCE_FINGERPRINTS={'task_contract.md': 'f10f2b71c7593e49492e91f891137dba251d87147a283ae27f59bde8ca93d947', 'R219_frozen_triple_scale_probe.py': 'f21bb4f6732f4017fefd5906277d4a74f047eca853be9512d999fc9ff5a1d5ca'}


def phi(x):
    x=abs(x);h=mp.mpf('.5')
    def E3(t):return mp.mpf('.5') if not t else ((1-t)*mp.exp(-t)+t*t*mp.e1(t))/2
    return 1-E3(h-x)-E3(h+x) if x<=h else E3(x-h)-E3(x+h)
def fs(x,s):return (1-s if abs(x)<=mp.mpf('.5') else 0)+s*phi(x)
def primitiveF(x):
    sg=mp.sign(x);t=abs(x);h=mp.mpf('.5')
    return x if t<=h else sg*(h-mp.expint(4,t-h)+mp.expint(4,t+h)+mp.mpf(1)/3-mp.expint(4,1))
def rat(x):return f'{x.numerator}/{x.denominator}'
def index(n,L,R):
    gamma=F(n+1,n);q=min(L,R)**2;j=0
    while gamma**(-2*(j+1))*L*R>q:j+=1
    lower=gamma**(-2*(j+1))*L*R;upper=gamma**(-2*j)*L*R
    assert lower<=q<=upper
    return j,gamma**(-j),{'gamma':rat(gamma),'j':j,'cj':rat(gamma**(-j)),'min_L_R_squared':rat(q),'lower_squared_bound':rat(lower),'upper_squared_bound':rat(upper),'lower_le_min_squared_le_upper':True}
def calc(cfg,dps,degree):
  with mp.workdps(dps):
    n,Lstr,Rstr,schoice,vstr,zstr,leg=cfg;Lf,Rf=F(Lstr),F(Rstr);j,cjf,cert=index(n,Lf,Rf);m=lambda f:mp.mpf(f.numerator)/f.denominator
    L,R,cj=map(m,(Lf,Rf,cjf));g=mp.sqrt(L*R);gamma=mp.mpf(n+1)/n;gate=1-mp.power(2,-mp.mpf(1)/n);s=gate+mp.mpf(schoice.split('gate_plus_')[1]) if schoice.startswith('gate_plus_') else mp.mpf(schoice);v,z=map(mp.mpf,(vstr,zstr));A=L if leg=='K_L' else min(1,gamma*L) if leg=='K_Lplus' else mp.mpf(1);soft=s if leg!='J' else mp.mpf(1)
    assert gate<s<1
    if (dps,degree) not in NODES:NODES[dps,degree]=mp.gauss_quadrature(degree,'legendre')
    nodes,weights=NODES[dps,degree];lo=z-R/2;hi=z+R/2;boundaries=[-L/2,L/2,v-A/2,v+A/2,mp.mpf(0),v]
    def integ(lower,upper):
      if upper<=lower:return mp.mpf(0),[]
      cuts=sorted(set([lower,upper]+[x for x in boundaries if lower<x<upper]));total=mp.mpf(0)
      for a,b in zip(cuts,cuts[1:]):
        mid=(a+b)/2;half=(b-a)/2;total+=half*sum(w*mp.sqrt(fs((mid+half*q)/L,s)/L*fs((mid+half*q-v)/A,soft)/A) for q,w in zip(nodes,weights))
      return total/R,cuts
    I,cuts=integ(lo,hi);caplo=max(lo,v-R/2);caphi=min(hi,v+R/2)
    if caplo==lo and caphi==hi:Icap,capcuts=I,cuts
    else:Icap,capcuts=integ(caplo,caphi)
    C=primitiveF(mp.mpf('.5')-abs(v))-primitiveF(-mp.mpf('.5')-abs(v));wg=min(1,C/(cj*g));H=g/cj*I/mp.sqrt(wg);removed=R<=L;product=I**n;capproduct=Icap**n;B0=product-capproduct if removed else product
    assert B0>=0
    vals={'L':L,'R':R,'g':g,'s_lower_gate':gate,'s':s,'v':v,'z':z,'A':A,'leg_soft':soft,'C_abs_v':C,'w_g':wg,'g_over_cj':g/cj,'I_normalized_hard_R':I,'Icap_normalized_intersection':Icap,'D':H,'I_power_n':product,'Icap_power_n':capproduct,'B0_same_coordinate_product_difference':B0}
    return {'n':n,'s_choice':schoice,'leg':leg,'dps':dps,'degree':degree,'actual_index_certificate':cert,'values':{k:mp.nstr(x,dps) for k,x in vals.items()},'D_le_one_numerical':H<=1,'B0_exclusion_active_R_le_L':removed,'I_cuts':[mp.nstr(x,dps) for x in cuts],'Icap_cuts':[mp.nstr(x,dps) for x in capcuts]}
def main(output):
    initial=[(n,L,R,s,v,z,leg) for n in (4,16) for L,R in [('.5','1'),('1','.5')] for s in ('gate_plus_.001','.5') for v,zlist in [('.75',['0','.375','.75']),('1.25',['0','.625','1.25'])] for z in zlist for leg in ('K_L','J')]
    stress=[(128,L,R,'gate_plus_.000001',v,z,leg) for L,R in [('.5','1'),('1','.5')] for v,z in [('.75','-2'),('1.25','3.25')] for leg in ('K_L','K_Lplus','J')]
    expanded=[(1024,L,R,'gate_plus_.00000001',v,z,leg) for L,R in [('.5','1'),('1','.5')] for v,z in [('4','2'),('8','8')] for leg in ('K_L','K_Lplus','J')]
    assert (len(initial),len(stress),len(expanded))==(96,12,12)
    stages=[];firstfailure=None
    for name,configs in [('initial',initial),('stress',stress),('expanded',expanded)]:
      rows=[]
      for cfg in configs:
        vals=[calc(cfg,p,deg) for p,deg in ((25,48),(40,96))]
        with mp.workdps(50):diff=mp.nstr(abs(mp.mpf(vals[0]['values']['D'])-mp.mpf(vals[1]['values']['D'])),30)
        rows.append({'config':list(cfg),'precision_runs':vals,'D_low_high_abs_difference':diff})
        if any(not v['D_le_one_numerical'] for v in vals):firstfailure=list(cfg);break
      stages.append({'stage':name,'cases':rows});print(name,len(rows),'firstfailure',firstfailure,flush=True)
      if firstfailure:break
    refinement=[calc(tuple(firstfailure),p,deg) for p,deg in ((60,192),(80,384))] if firstfailure else []
    rows=[r for st in stages for r in st['cases']]
    with mp.workdps(50):maxrow=max(rows,key=lambda r:mp.mpf(r['precision_runs'][-1]['values']['D']))
    result={'schema':'R220_scaled_D_kernel_probe_v1','script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'mpmath_version':mp.__version__,'source_fingerprints':SOURCE_FINGERPRINTS,'complete_planned_grid':firstfailure is None,'planned_config_count':120,'actual_config_count':len(rows),'first_failure_config':firstfailure,'failure_refinements':refinement,'stages':stages,'maximum_D_config':maxrow['config'],'maximum_D':maxrow['precision_runs'][-1]['values']['D'],'scope':['Accurate contract D=(g/cj)*I/sqrt(omega), b=1,y=0, hard_R normalized dx/R.','No external data inputs; provenance fingerprints identify the contract and frozen method source.','Actual j/minratio squared certificate uses exact rational arithmetic.','Icap and n-coordinate B0 productdifference retained only as finite diagnostics, not a FULL/source budget.','Ordinary quadrature, not interval evidence or independent certification of an analytic theorem.','First D>1 stops grid and receives 60/80dps refinement; it would refute only this kernel candidate.','No dimension-order fit, arbitrary L1 input or original FULL counterexample.','All integrals have finite hard-source domains; no infinite tails omitted.']}
    output.write_text(json.dumps(result,indent=2)+'\n');print('maximum D',result['maximum_D'],result['maximum_D_config'],flush=True)
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=HERE/'scaled_probe.json');args=ap.parse_args();main(args.output)
