# R220：全部实际尺度共同重叠的常数一定理

本稿给出计算辅助严格证明：对任意 $b>0$、$L,R\in[b/2,b]$、$A\in[L,b]$、$g=\sqrt{LR}$、$c_j\ge\min(L,R)/g$，以及全部独立 $s,\sigma\in[0,1]$、$y,v,z\in\mathbb R$，SG1 定义的固定参数共同重叠满足 $D\le1$。第2–5节先处理直接区域，第6、8、9节闭合原中间剩余。核心标量有限覆盖证书已通过源码、解析接口与全部40格独立审核，并由独立实际复跑确认 JSON 字节一致。该结果覆盖全部三条实际目标腿，但不将核定理登记为原来源付款。

## 1. 固定参数与准确归一化

取原 $L,R\in[b/2,b]$、$A\in[L,b]$、独立 $s,\sigma\in[0,1]$，$g=\sqrt{LR}$。实际三腿是 $(A,\sigma)=(L,s),(\min(b,\gamma L),s),(b,1)$。记

\[
m=\min(L,R),\quad M=\max(L,R),\quad N=\max(A,R),\quad
\theta=m/g\le c_j,
\]

\[
d=|v-y|/b,\quad \alpha=A/b,\quad r=R/b,\quad
\omega=\min\{1,bC(d)/(c_jg)\}.
\]

原一维共同 overlap 为

\[
I=\frac1R\int_{z-R/2}^{z+R/2}
\sqrt{L^{-1}f_s((x-y)/L)A^{-1}f_\sigma((x-v)/A)}\,dx,
\qquad D=\frac{g}{c_j\sqrt\omega}I.
\tag{SG1}
\]

本稿所有积分估计先固定这些参数及 $y,v,z$。$D$ 无量纲，$I$ 有长度倒数单位。记

\[
A_0(q)=(1-|q|)_+,\quad V(q)=(h*\phi)(q),\quad C(q)=(h*\max(h,\phi))(q),
\]

\[
a=(1-s)(1-\sigma),\quad \chi=s(1-\sigma)+(1-s)\sigma,\quad \tau=s\sigma,
\quad a+\chi+\tau=1.
\]

这里 $A_0$ 与物理目标尺度 $A$ 严格区分。

已证 R219 工具是逐点 $\phi(x)\phi(x-q)\le V(q)$，其证明由原 Laplace 混合正相关与三角不等式给出；并有 $C\ge A_0,V$。设 $c=1-\phi(0)>0$，还可用

\[
aA_0(q)+(1-a)V(q)\le C(q)[1-c\min(a,1-a)].
\tag{SG2}
\]

## 2. 普通列界与比例带单调性

Cauchy 先给

\[
I\le\sqrt{\left(\frac1R\int_{Q_R(z)}P_{s,L}(x-y)\,dx\right)
\left(\frac1R\int_{Q_R(z)}P_{\sigma,A}(x-v)\,dx\right)}
\le\frac1{\sqrt{MN}}.
\tag{SG3}
\]

因为每个概率密度既归一又分别不超过 $1/L,1/A$，其与硬均匀密度的 overlap 分别不超过 $1/M,1/N$。故始终有有价界

\[
D^2\le E_0:=\frac{g^2}{c_j^2 MN\omega}.
\tag{SG4}
\]

若 $\omega=1$，则 $g/c_j\le M$，所以 $D^2\le M/N\le1$。

另有更大的可用饱和域。固定 $L,R,A,b,s,\sigma,y,v,z$，把 $c_j$ 暂视为正变量，则

\[
\frac{1}{c_j^2\min(1,bC/(c_jg))}
=\max\left\{c_j^{-2},\frac{g}{bC}c_j^{-1}\right\}
\]

随 $c_j$ 不增。因此可以把 $c_j$ 放到更小的 $\theta=m/g$ 来上控 $D$。在 $C(d)\ge m/b$ 时，$\omega_\theta=1$，$g/\theta=M$，SG3 给

\[
C(d)\ge m/b\quad\Longrightarrow\quad D^2\le M/N\le1.
\tag{SG5}
\]

此降阶只用于单调上界，不声称 $\theta$ 是原离散比例标签。

## 3. 保留硬窗口长度的尺度 $b$ 包络

原 $f_s$ 偶且径向非增；这是 $h$ 与 $\phi$ 的同性质的非负组合。因此 $L,A\le b$ 给

\[
f_s((x-y)/L)\le f_s((x-y)/b),\qquad
f_\sigma((x-v)/A)\le f_\sigma((x-v)/b).
\]

置 $q=(x-y)/b$ 后，原积分窗口成为一个任意位置、长度 $r=R/b\le1$ 的区间 $J$。写 $d_\pm=(v-y)/b$；下面偶核只取 $|d_\pm|=d$。于是

\[
I\le\frac{b}{R\sqrt{LA}}\int_J\sqrt{f_s(q)f_\sigma(q-d_\pm)}\,dq.
\]

对这一个乘积函数用窗口 Cauchy，保留 $|J|=r$。硬硬项最多 $A_0(d)$，两个硬软项各最多 $V(d)$；软软项由 R219 逐点界最多 $rV(d)$。故

\[
\left(\int_J\sqrt{f_s(q)f_\sigma(q-d_\pm)}\,dq\right)^2
\le r\{aA_0(d)+(\chi+r\tau)V(d)\}.
\]

回代全部尺度因子得到

\[
\boxed{\quad D^2\le E_b:=
\frac{b}{c_j^2A\omega}\{aA_0(d)+(\chi+r\tau)V(d)\}.\quad}
\tag{SG6}
\]

这一步没有把 $r\le1$ 粗略换成一；特别保留了软软项的窗口收益。

若原 $\omega<1$，SG6 化为

\[
D^2\le\eta\frac{aA_0(d)+(\chi+r\tau)V(d)}{C(d)},
\qquad \eta=\frac{g}{c_jA}\le\frac MA.
\tag{SG7}
\]

括号内核是 $aA_0+(1-a)V-(1-r)\tau V$，因此

\[
D^2\le\eta\left[1-c\min(a,1-a)-(1-r)\tau\frac{V(d)}{C(d)}\right].
\tag{SG8}
\]

原核确保右侧非负。若 $R\le L$，则 $M=L\le A$；若 $A\ge R$，则也有 $M\le A$。在这两种情形 $\eta\le1$，结合 SG4 的饱和分支，得到

\[
\boxed{\quad R\le L\ \text{或}\ A\ge R
\quad\Longrightarrow\quad D\le1\quad\text{对全部 }d,z,s,\sigma.\quad}
\tag{SG9}
\]

SG8 是非饱和支可用的明确尺度与软度缺口。特别 $A=b$ 的实际 $J$ 腿属于 SG9；其 $\sigma=1$ 不需与来源软度相同。

## 4. 一个严格尾部尺度比较引理

以下引理扩大余下 $R>L,A<R$ 的覆盖，且保留确定常数。

**引理。** 对 $1/2\le\alpha\le1$、$d\ge\alpha$，

\[
V(d/\alpha)\le\alpha C(d).
\tag{SG10}
\]

证明先记 $v_1=V(1)=C(1)>0$、$q_0=\phi(1/2)$、$c_1=1-q_0$。当 $x\ge1$ 时，$V(x)$ 是积分

\[
\int_{[-1/2,1/2]^2}\int_0^1e^{-(x-u-v)/r}\,dr\,du\,dv,
\]

所以 $V(x+h)\le e^{-h}V(x)$。此外 $\phi(1/2+h)\le e^{-h}q_0$，故

\[
v_1=\int_{1/2}^{3/2}\phi(u)\,du\le(1-e^{-1})q_0.
\]

下面严格核验 $v_1\le c_1/2$。原核给

\[
q_0=\frac12-\int_0^1r e^{-1/r}\,dr
\le\frac12(1-e^{-2}),
\]

最后一步是在概率密度 $2r\,dr$ 上对凸函数 $e^{-x}$ 使用 Jensen，且 $\mathbb E(1/r)=2$。用初等 $e<11/4$（例如 $e\le65/24+1/100<11/4$），有 $e^2<8$、$q_0\le7/16$，于是

\[
v_1\le\frac7{11}\frac7{16}=\frac{49}{176}
<\frac9{32}\le\frac{1-q_0}{2}=\frac{c_1}{2}.
\tag{SG11}
\]

对 $0\le d\le1$，原 $C$ 的导数是 $C'(d)=\phi(d+1/2)-1\le-c_1$，故

\[
C(d)\ge v_1+c_1(1-d).
\tag{SG12}
\]

若 $d\ge1$，则 $C(d)=V(d)$，指数衰减及 $\log(1/\alpha)\le1/\alpha-1$ 给

\[
V(d/\alpha)\le e^{-d(1/\alpha-1)}V(d)\le\alpha C(d).
\]

剩下 $\alpha\le d\le1$。此时

\[
V(d/\alpha)\le v_1e^{1-d/\alpha}.
\]

函数 $\log\{\alpha[v_1+c_1(1-d)]/v_1\}+d/\alpha-1$ 在 $d\in[\alpha,1]$ 上为凹函数，故其最小值在端点。端点 $d=\alpha$ 的非负性等价于 $v_1\le\alpha c_1$，由 SG11 和 $\alpha\ge1/2$ 得到；端点 $d=1$ 的非负性是 $\log\alpha+1/\alpha-1\ge0$。故整个区间非负，结合 SG12 完成 SG10。$\alpha=1$ 是直接的 $V\le C$。

## 5. 剩余尺度顺序中的远位移强界

现在只需研究 $R>L,A<R$。在尺度 $A$ 上径向放大来源核 $L$，令 $r_A=R/A>1$。与第三节同样的单窗口 Cauchy 对长度 $r_A$ 仍合法；硬硬与两个硬软项的全线界不变，软软项保留 $r_A$。准确回代为

\[
\boxed{\quad D^2\le E_A:=\frac1{c_j^2\omega}
\{aA_0(d/\alpha)+(\chi+r_A\tau)V(d/\alpha)\}.\quad}
\tag{SG13}
\]

若 $d\ge\alpha$，则 $A_0(d/\alpha)=0$。在非饱和支代入 $\omega=bC(d)/(c_jg)$，使用 SG10 与 $g/c_j\le R$，得到

\[
D^2\le\frac{g}{c_jb}\frac{V(d/\alpha)}{C(d)}(\chi+R\tau/A)
\le\frac{RA}{b^2}\chi+\frac{R^2}{b^2}\tau
\le\left(\frac Rb\right)^2(1-a)\le1.
\tag{SG14}
\]

饱和支已由 SG4 处理。因此

\[
\boxed{\quad |v-y|\ge A\quad\Longrightarrow\quad D\le1
\quad\text{在全部实际尺度顺序上成立。}\quad}
\tag{SG15}
\]

其中 $R\le L$ 或 $A\ge R$ 用 SG9；其余用 SG14。SG14 还给非饱和支的尺度与双软度缺口，较仅处理 $|v-y|\ge b$ 更强。

## 6. 原中间剩余的归约、准确代价与原硬门

第2–5节之后唯一仍需处理的区域为

\[
R>L,\qquad L\le A<R,\qquad d<A/b,\qquad C(d)<m/b=L/b.
\tag{SG16}
\]

最后一条件已删除 SG5 的降阶饱和域。对 SG16 仍有无需附加资格的明确有价估计

\[
D^2\le\min\{E_0,E_b,E_A\},
\tag{SG17}
\]

各项已在 SG4、SG6、SG13 保留全部尺度常数。特别在非饱和支 $E_b\le g/(c_jA)\le R/A$，但 $(R/A)^{n/2}$ 不能免费；只能在其与实际坐标缺口共同回代后结算。

闭合该区域的标量步骤是（第8–9节已证明）：在 SG16 中有

\[
V(d/\alpha)\le\alpha C(d).
\tag{SG18}
\]

由 SG18，SG13 中两个软项分别以 $RA/b^2\le1$ 和 $R^2/b^2\le1$ 付清；硬硬项也有

\[
\frac{g}{c_jb}\frac{A_0(d/\alpha)}{C(d)}
\le\frac Rb\frac{1-d/\alpha}{C(d)}\le1,
\]

因为 $C(d)\ge1-d\ge1-d/\alpha$。三个系数 $a,\chi,\tau$ 和为一，从而闭合 $D\le1$。SG18 在 $d\ge\alpha$ 的情形由第4节给出；在 SG16 中由第8节凹性归约和第9节严格标量证书给出。它始终保留实际非饱和与尺度限制，不外推为无条件全部 $\alpha,d$ 的声明。

原硬门在 $R\le L$ 时为 $B(v)=1_{Q_R(x)}(v)$，$R>L$ 时为零。因此原中间区域 SG16 上 $B$ 自动为零；本稿通过标量比较闭合此域，不依赖该硬门消除它。

在已覆盖的 $R\le L$ 分支，若要保持硬门的准确几何，应定义每坐标 $I_i$ 为 SG1 的全窗口积分（含 $1/R$，但未乘 $g/(c_j\sqrt\omega_i)$），$I_i^{\cap}$ 则以相同被积函数及相同 $1/R$ 改在窗口 $Q_R(z_i)\cap Q_R(v_i)$ 上积分。固定全部参数时，带 $B=0$ 的真实全维量严格等于

\[
\prod_i I_i-\prod_iI_i^{\cap},
\]

$R>L$ 时为 $\prod_iI_i$。归一化后也保持同样的两个乘积之差。不能将它改成各坐标差的乘积，或用错误的 $Q_L(v)$ 替代 $Q_R(v)$。本稿的一维上界删除该非负扣除，因此对实际带门量仍有效。

## 7. 张量化、实际来源费用与验证口径

固定所有物理参数时，半密度与硬立方体均为乘积，因此各坐标 $D_i$ 的乘积控制归一化共同 overlap。所有坐标现均有 $D_i\le1$，故张量化仍为常数一，没有 $C_0^n$ 损失。可逐坐标继续保留 SG8、SG14、SG20 的缺口；SG17 则保留为辅助精确有价上界。

原正量的完整回代仍须保留 $a_\omega/Q$、$\beta_V(dy)\nu_V(dz)$、$\rho_0(v)(k_t(v)-k_t(u))_+\Pi_t(dv)\Pi_t(du)$、high/FIRST、历史与唯一比例带。固定 $(\omega,V,j,y,t)$ 时 $\Pi_t$ 可移出 $x$，但 $L,R,s,g$、终端门和历史仍随 $x$；本稿没有为这类选择器提供包络预算。也没有把全硬来源限制到 $Z_g$、交换 $\beta,\nu$，或把全来源 $\bar e_g$ 当成 $e_g$。没有消费 signed 负账，原浮动已付带没有再次领取。

实际本机 Python `fractions.Fraction` 核验了 SG11 使用的三个有理比较：$65/24+1/100=1631/600<11/4$、$121/16<8$、$9/32-49/176=1/352>0$。这是初等常数的算术核对；一般参数结论由解析归约与第9节计算辅助严格有限覆盖共同证明，后者已独立审核和复跑。普通有限参数积分没有被当作一般证明。

结论：异尺度严格强界 $D\le1$ 已覆盖本稿第1节的全部参数，包含 SG16 和全部三条实际目标腿，并保留可量化缺口。一般原正交通的来源与自适应接收费用仍未付款。


## 8. 经严格标量证书闭合的全域凹性归约

第9节的已审核严格证书给出

\[
V(t)\le(1+t)^{-2}\qquad(0\le t\le1).
\tag{SG19}
\]

下面使用已证 SG19 将 SG16 全部闭合，无需新增尺度假设。

确实，在 SG16 令 $t=d/\alpha<1$，由 $C(d)<L/b\le\alpha$ 及 $C(d)\ge1-d=1-\alpha t$，得到 $\alpha>\alpha_0=1/(1+t)$。$t=0$ 与原非饱和条件矛盾，所以 $t>0$。在 $q\in[\alpha_0,1]$ 上定义 $F_t(q)=qC(qt)$。由于 $0<qt<1$ 时

\[
C'(qt)=\phi(qt+1/2)-1<0,\qquad C''(qt)=\phi'(qt+1/2)\le0,
\]

有 $F_t''(q)=2tC'(qt)+qt^2C''(qt)<0$。由凹性，$F_t(q)$ 不小于两个端点值的最小值。右端点是 $C(t)\ge V(t)$；左端点满足

\[
F_t(\alpha_0)\ge\alpha_0(1-\alpha_0t)=\alpha_0^2=(1+t)^{-2}\ge V(t),
\]

其中最后一步恰为 SG19。因此 $V(d/\alpha)\le\alpha C(d)$，即 SG18 在全部剩余域成立。

代 SG13，不仅得到强型，而且有明确价格

\[
D^2\le\frac Rb\left[a\frac{A_0(t)}{C(d)}+\alpha\chi+\frac Rb\tau\right]
\le\frac Rb\left[a+\alpha\chi+\frac Rb\tau\right]\le1.
\tag{SG20}
\]

这里 $A_0(t)\le A_0(d)\le C(d)$；没有抛弃坐标乘积或附加原来源假设。

## 9. 实际有理证书的解析接口与有限覆盖

本节已核对实际相邻脚本 [v_envelope_certificate.py](v_envelope_certificate.py) 及记录 [v_envelope_certificate.json](v_envelope_certificate.json)。实际方法直接包围 $V_r$，没有采用此前建议的 $H$ 分项相减。当前源文件 SHA256 是 `54417e0e73a436342d7a9c24e7477093524bdc7efe325c16126eb5938b57eb61`。作者已逐项核对源码散列和40个 JSON 有理端点/上界；独审已完整审核源码、40格记录、解析接口，并实际复跑确认输出 JSON 字节一致。证书与本稿解析归约共同构成计算辅助严格证明。

### 9.1 解析接口

记 $e_r(x)=e^{-|x|/r}$。非负 Tonelli 给

\[
V(t)=\int_0^1 V_r(t)\,dr,\qquad
V_r(t)=(h*h*e_r)(t)
=\int_{[-1/2,1/2]^2}e^{-|t-u-v|/r}\,du\,dv.
\]

因此 $r\mapsto V_r(t)$ 单调不减，且可在 $r=0$ 定义为零而不影响积分。对 $0\le t\le1,r>0$，将三角密度 $h*h$ 在 $0,t$ 处分段积分得到精确式

\[
V_r(t)=2r(1-t)+r^2\left(e^{-(1-t)/r}+e^{-(1+t)/r}-2e^{-t/r}\right).
\tag{SG21}
\]

公式也可通过先对 $u$ 再对 $v$ 的初等指数积分逐项验证。正负指数项必须分别用对应方向的界，不能将负号项用上界。

另一方面，原 $\phi$ 偶且径向非增，故

\[
V'(t)=\phi(t+1/2)-\phi(t-1/2)\le0\qquad(t\ge0),
\]

因为 $|t+1/2|\ge|t-1/2|$。所以 $V$ 在 $[0,1]$ 非增。以上给证书所需的全部积分与两个单调性接口。

### 9.2 指数的有理向外包围

代码仅使用 Python 整数与 `fractions.Fraction`，固定舍入分母 $10^{24}$。对有理 $x\ge0$：

- $x=0$ 返回精确区间 $[1,1]$。
- $0<x<64$ 时选整数 $k\ge0$ 使 $u=x/2^k\in(0,1]$。交错级数的项绝对值不增，故 Taylor 部分和满足 $S_{21}(u)\le e^{-u}\le S_{20}(u)$。下界向下取整、上界向上取整到分母 $10^{24}$ 后，再反复平方 $k$ 次，每次也按相同方向舍入。非负轴上平方单调，故每一步保留严格包围方向。
- $x\ge64$ 时，用 $e\ge2$ 给 $0\le e^{-x}\le2^{-\lfloor x\rfloor}$，完全使用有理数。

SG21 中两个正指数项使用上界，系数 $-2$ 的指数项使用下界。因此 `vr_upper(t,r)` 是 $V_r(t)$ 的有理上界。代码断言各指数端点在 $[0,1]$、次序正确，并验证所用 $V_r$ 上界非负。

### 9.3 两层网格覆盖完整连续区间

实际首个预定菜单已通过：$r$ 网格 64 份，$t$ 网格 40 份，没有启动备选 128 份 $r$ 网格。对 $t_i=i/40$，利用 $V_r$ 随 $r$ 非减，直接右矩形给

\[
V(t_i)\le\frac1{64}\sum_{j=1}^{64}V_{j/64}(t_i)
\le U_i,
\]

其中 $U_i$ 是逐项有理向外上界之和。对全部 $t\in[t_i,t_{i+1}]$，

\[
(1+t)^2V(t)\le(1+t_{i+1})^2V(t_i)
\le(1+t_{i+1})^2U_i.
\tag{SG22}
\]

JSON 列出了全部 40 格的精确有理端点与上界；逐格最大值为

\[
\frac{115508456693721590759701059838462162527748074964554537441}
{126765060022822940149670320537600000000000000000000000000}
\le\frac{23}{25}<1.
\]

作者已用 `Fraction` 检查所有40格端点准确衔接 $[0,1]$、所有记录上界不超过 $23/25$，并核对脚本散列；独立审计进一步实际复跑，确认输出 JSON 字节一致。

相邻脚本可复现：

```sh
python3 v_envelope_certificate.py --output v_envelope_certificate.recheck.json
```

独立执行和源码审计均已通过。SG21–SG22 与有理证书共同证明 $V(t)\le(23/25)(1+t)^{-2}<(1+t)^{-2}$，从而严格提供 SG19。随后第八节的凹性归约给全部 SG16 的 SG20，结合其余已证域，得到所有 $L,R\in[b/2,b],A\in[L,b],c_j\ge\min(L,R)/g,s,\sigma\in[0,1],y,v,z\in\mathbb R$ 的固定参数 $D\le1$。这是经独立审核的计算辅助严格定理；原来源费用仍未付款。
