#!/usr/bin/env python3
"""Strict Fraction arithmetic certificate conditional on the stated analytic interfaces.

Analytic interfaces (proved/reviewed elsewhere):
V(t)=integral_0^1 V_r(t) dr, V_r increasing in r, and V decreasing on [0,1].
V_r=2r(1-t)+r^2(exp(-(1-t)/r)+exp(-(1+t)/r)-2exp(-t/r)).
Exponent enclosures use alternating Taylor remainders on [0,1] and positive
monotone squaring; large-x uses exp(1)>=2. No float is used anywhere.
"""
import argparse,hashlib,json
from fractions import Fraction as F
from pathlib import Path
HERE=Path(__file__).resolve().parent
DEN=10**24
CACHE={}
COUNTS={'exp_cache_misses':0,'zero_exp_exact':0,'large_x_bounds':0,'taylor_bounds':0,'directed_squarings':0}

def rat(x):return f'{x.numerator}/{x.denominator}'
def down(x):return F(x.numerator*DEN//x.denominator,DEN)
def up(x):return F(-((-x.numerator*DEN)//x.denominator),DEN)
def exp_interval(x):
    assert isinstance(x,F) and x>=0
    if x in CACHE:return CACHE[x]
    COUNTS['exp_cache_misses']+=1
    if x==0:
        lo=hi=F(1);COUNTS['zero_exp_exact']+=1
    elif x>=64:
        lo=F(0);hi=F(1,2**(x.numerator//x.denominator));COUNTS['large_x_bounds']+=1
    else:
        u=x;k=0
        while u>1:u/=2;k+=1
        term=F(1);partial=F(1);even=None
        for j in range(1,22):
            term=term*(-u)/j;partial+=term
            if j==20:even=partial
        lo=down(partial);hi=up(even)
        assert 0<=lo<=hi<=1
        for _ in range(k):
            lo=down(lo*lo);hi=up(hi*hi);COUNTS['directed_squarings']+=1
            assert 0<=lo<=hi<=1
        COUNTS['taylor_bounds']+=1
    assert 0<=lo<=hi<=1
    CACHE[x]=(lo,hi);return lo,hi

def vr_upper(t,r):
    assert 0<=t<=1 and r>0
    plus1=exp_interval((1-t)/r)[1];plus2=exp_interval((1+t)/r)[1];negative=exp_interval(t/r)[0]
    result=2*r*(1-t)+r*r*(plus1+plus2-2*negative)
    assert result>=0
    return result

def attempt(nr,nt):
    cells=[]
    for i in range(nt):
        tlo=F(i,nt);thi=F(i+1,nt)
        vup=sum((vr_upper(tlo,F(j,nr)) for j in range(1,nr+1)),F(0))/nr
        normalized=(1+thi)**2*vup;passed=normalized<=1
        cells.append({'cell':i,'t_lo':rat(tlo),'t_hi':rat(thi),'V_at_t_lo_right_rectangle_upper':rat(vup),'normalized_upper_using_t_hi':rat(normalized),'one_minus_normalized_upper':rat(1-normalized),'passed_exact':passed})
    worst=max(cells,key=lambda row:F(row['normalized_upper_using_t_hi']))
    return {'r_grid_parts':nr,'t_grid_parts':nt,'right_rectangle_points':'r_j=j/nr, j=1,...,nr','all_cells_passed_exact':all(row['passed_exact'] for row in cells),'maximum_normalized_upper':worst['normalized_upper_using_t_hi'],'maximum_cell':worst['cell'],'maximum_cell_t_lo':worst['t_lo'],'maximum_cell_t_hi':worst['t_hi'],'cells':cells}

def main(output):
    tries=[]
    for nr in (64,128):
        result=attempt(nr,40);tries.append(result)
        if result['all_cells_passed_exact']:break
    assert tries[-1]['all_cells_passed_exact'],'Predeclared grid menu failed; no certificate issued.'
    exp_records=[{'x':rat(x),'lower':rat(bounds[0]),'upper':rat(bounds[1])} for x,bounds in sorted(CACHE.items())]
    exp_bytes=json.dumps(exp_records,sort_keys=True,separators=(',',':')).encode()
    result={'schema':'R220_V_envelope_fraction_certificate_v1','complete':True,'all_assertions_exact_rational':True,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'arithmetic':'Python Fraction and integers only; no float or mpmath','analytic_interfaces_required':['V=integral_0^1 V_r dr with displayed V_r formula','V_r(t) is nondecreasing in r','V(t) is nonincreasing on [0,1]','Alternating-series enclosure S21(u)<=exp(-u)<=S20(u) for 0<=u<=1','exp(1)>=2 for the large-x shortcut'],'exponential_enclosure':{'rounding_denominator':str(DEN),'lower_taylor_degree':21,'upper_taylor_degree':20,'scaling':'x=2^k*u, 0<=u<=1; enclose then square k times','rounding':'floor lower, ceiling upper after initial polynomial and every square','large_x_threshold':'64/1','large_x_bound':'0 <= exp(-x) <= 2^(-floor(x))','zero_bound':'[1,1] exact','cache_records_sha256':hashlib.sha256(exp_bytes).hexdigest(),'counts':COUNTS},'grid_attempts':tries,'final_maximum_normalized_upper':tries[-1]['maximum_normalized_upper'],'final_maximum_cell':tries[-1]['maximum_cell'],'readable_exact_ceiling':'23/25','maximum_le_readable_ceiling_exact':F(tries[-1]['maximum_normalized_upper'])<=F(23,25),'scope':['Exact finite arithmetic certificate conditional on separately reviewed analytic interfaces.','For t in each cell, (1+t)^2 V(t) <= (1+t_hi)^2 Vupper(t_lo) <=1.','Does not independently certify the final analytic lemma, original traffic, or FULL.','No ordinary float is used to establish any inequality.']}
    output.write_text(json.dumps(result,indent=2)+'\n');print('certificate passed',tries[-1]['r_grid_parts'],'r parts;',len(tries[-1]['cells']),'t cells; max=',result['final_maximum_normalized_upper'],flush=True)
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=HERE/'v_envelope_certificate.json');args=ap.parse_args();main(args.output)
