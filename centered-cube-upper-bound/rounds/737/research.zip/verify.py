from itertools import combinations,product
from fractions import Fraction as F
from math import comb,isqrt
import sys,json,subprocess,platform
from pathlib import Path

def compress(f,k):
    for j in range(k):
        b=1<<j
        f={v-b if v&b and v-b not in f else v for v in f}
    return f

def cases(remote):
    out=[]
    for k in (2,3,6,10):
        seq=list(range(1<<k))
        seq.sort(key=lambda x:((x*73+17)^((x+51)*29))%113)
        if k==10:seq=seq[:70]
        f=set();old=set();sizes=[]
        for x in seq:
            f.add(x)
            if remote:
                now=set(f)
                for j in range(k):
                    b=1<<j;fixed={v&~b for v in now};both={v|b for v in fixed if v in now and v|b in now};now=fixed|both
            else:now=compress(f,k)
            assert old<=now and len(now-old)==1 and len(now)==len(f)
            s=next(iter(now-old))
            assert len({w&s for w in f})==1<<s.bit_count()
            sizes.append(s.bit_count());old=now
        out.append([k,len(f),[sizes.count(i) for i in range(k+1)]])
    # Exact one-axis double phase length and product for selected axes
    for p,rad in [(F(9,4),F(5,4)),(F(17,8),F(9,8)),(F(2),F(3,2))]:
        breaks=sorted({F(0),p,rad%p,(-rad)%p});s=F(0)
        for a,b in zip(breaks,breaks[1:]):
            v=(a+b)/2
            if sum(abs(v+t*p)<=rad for t in (-2,-1,0,1,2))==2:s+=b-a
        assert s==2*rad-p
        out.append([str(p),str(rad),str(s/p)])
    # Two-axis corner projections; enumerate second-donor centres independently.
    for units,depth in [(8,2),(16,4),(32,6)]:
        half=units+1
        corners=[(i*(half-depth+(v%2)),j*(half-depth+((v//2)%2))) for v,(i,j) in enumerate(product((-1,1),repeat=2))]
        multi=one=0
        for r in range(units-depth-1,units+1):
            for x,y in product(range(-units,units+1),repeat=2):
                mask=[max(abs(x-u),abs(y-v))<=r for u,v in corners]
                if sum(mask)==1:one+=1
                if sum(mask)>=2:
                    multi+=1
                    assert r>=half-depth and min(abs(x),abs(y))<=depth+r-half
        assert multi and one
        out.append([units,depth,multi,one])
    return out
if '--mac' in sys.argv:
 print(json.dumps([platform.python_version(),cases(True)]));sys.exit()
data=cases(False)
cmd=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=8','macbook-math','/Users/zhengzhihao/.venv/bin/python -B - --mac']
p=subprocess.run(cmd,input=Path(__file__).read_text(),capture_output=True,text=True,check=True,timeout=120)
rv,other=json.loads(p.stdout);assert other==data
from flint import arb,ctx
ctx.prec=256
dims=[]
for n in (256,1024,4096):
 a=32*n;b=arb(2)**(arb(1)/n);h=1+arb(1)/a;rho=1/arb(n).sqrt()
 P=2*h*b;price=(P/2)**n*(1+n*rho)
 # R736 actual H,V,D in the same history; last active donor has ratio 1/16
 K=4096*isqrt(n)*a**n;J=2**n;ell=arb(2).log()/K
 V=arb(J)/(8*a)**n;high=V*ell.expm1()/2
 lg=n*arb(a).log()+(K-5)*n*arb(4).log()+(-(-ell).expm1()).log()
 assert high<V/4 and high>0 and lg>(4*arb(8)**n+1).log()
 dims.append([n,str(price/arb(n).sqrt()),str(high),str(V),str(lg/K),str((lg+arb(3).log())/K),isqrt(n)<=16])
print(json.dumps(dict(python=sys.executable,local=platform.python_version(),remote=rv,cmd=cmd,exact=data,history=dims),indent=2))
