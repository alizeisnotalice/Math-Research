"""One frozen n3 all-subset, same-core batch full receiver-volume certificate."""
from fractions import Fraction as F
from itertools import product
from functools import lru_cache,cmp_to_key
from math import prod
from pathlib import Path
import argparse,json,time,sys,platform,resource,signal,shlex,hashlib
import flint
from flint import arb,ctx
ctx.prec=512
ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=Path(__file__).with_suffix('.json'));args=ap.parse_args();start=time.perf_counter()
def timeout(*_):raise TimeoutError('120-second frozen cap')
signal.signal(signal.SIGALRM,timeout);signal.alarm(120)
# The 81 monomials in cubert(2),cubert(3),cubert(5),cubert(7), exponents0..2.
primes=(2,3,5,7);exps=list(product(range(3),repeat=4));eidx={e:i for i,e in enumerate(exps)};zero=();one=((0,F(1)),)
def pack(d):return tuple(sorted((i,c) for i,c in d.items() if c))
def rat(q):q=F(q);return ((0,q),) if q else zero
@lru_cache(None)
def add(a,b):
 d=dict(a)
 for i,c in b:d[i]=d.get(i,F(0))+c
 return pack(d)
def scale(a,q):q=F(q);return tuple((i,c*q) for i,c in a if c*q)
def sub(a,b):return add(a,scale(b,-1))
@lru_cache(None)
def basis_mul(i,j):
 es=[];fac=1
 for p,a,b in zip(primes,exps[i],exps[j]):
  q,r=divmod(a+b,3);es.append(r);fac*=p**q
 return eidx[tuple(es)],fac
@lru_cache(None)
def mul(a,b):
 d={}
 for i,c in a:
  for j,e in b:
   k,f=basis_mul(i,j);d[k]=d.get(k,F(0))+c*e*f
 return pack(d)
def cube(a):return mul(mul(a,a),a)
def root(m):
 es=[];rem=m
 for p in primes:
  e=0
  while rem%p==0 and rem>1:rem//=p;e+=1
  es.append(e)
 assert rem==1
 fac=prod(p**(e//3) for p,e in zip(primes,es));return ((eidx[tuple(e%3 for e in es)],F(fac)),)
def af(q):q=F(q);return arb(q.numerator)/q.denominator
AB=[(arb(prod(p**e for p,e in zip(primes,es))).log()/3).exp() for es in exps]
def av(x):return sum((af(c)*AB[i] for i,c in x),arb(0))
@lru_cache(None)
def sign(x):
 if not x:return 0
 v=av(x)
 if v>0:return 1
 if v<0:return -1
 raise AssertionError('Unresolved exact-field sign')
def out(x):return {'exact_terms':[{'radicand':prod(p**e for p,e in zip(primes,exps[i])),'coefficient':str(c)} for i,c in x],'Arb512':av(x).str(55)}
def exactsum(xs):
 d={}
 for x in xs:
  for i,c in x:d[i]=d.get(i,F(0))+c
 return pack(d)
z=list(product((-F(1,2),F(1,2)),(-F(1,2),F(1,2)),(-F(9,10),F(9,10))));assert len(z)==8
# labels already sorted by x, fixed y/z lexicographic tie order.
r={m:root(m) for m in range(1,9)}
for m in r:assert cube(r[m])==rat(m)
b=1/arb(3).sqrt()
def bbox(mask):
 ids=[i for i in range(8) if mask>>i&1]
 return tuple((min(z[i][j] for i in ids),max(z[i][j] for i in ids)) for j in range(3))
def box(bb,m):
 h=scale(r[m],F(1,2));bounds=tuple((sub(rat(hi),h),add(rat(lo),h)) for lo,hi in bb)
 return bounds if all(sign(sub(hi,lo))>0 for lo,hi in bounds) else None
def directvol(B):return mul(mul(sub(B[0][1],B[0][0]),sub(B[1][1],B[1][0])),sub(B[2][1],B[2][0])) if B else zero
def intersect(B,C):
 if not B or not C:return None
 pairs=[]
 for (a,b),(c,d) in zip(B,C):
  lo=a if sign(sub(a,c))>=0 else c;hi=b if sign(sub(b,d))<=0 else d
  if sign(sub(hi,lo))<=0:return None
  pairs.append((lo,hi))
 return tuple(pairs)
C={m:box(bbox(m),m.bit_count()) for m in range(1,256)}
Hboxes=[box(bbox(1<<i),2) for i in range(8)]
for mask in range(1,256):
 mass=mask.bit_count();beta=av(directvol(C[mask]))/mass
 if mass==1:assert beta==1
 else:assert beta<af(F(1,2)) and beta<b
G={}
for S in range(1,256):
 if S.bit_count()<2:continue
 first=(S&-S);K=S^first;assert first<K&-K
 assert 1<=K.bit_count() and 2<=S.bit_count()<=16
 G.setdefault(K,[]).append(S)
assert len(G)==127 and sum(map(len,G.values()))==247
order=sorted(G,key=lambda K:(K.bit_count(),K));B={K:box(bbox(K),K.bit_count()+1) for K in order}
# Joint carriers use actual maximum child mass. All children here have equal added mass1.
endsets=[set() for _ in range(3)]
for bx in list(C.values())+Hboxes+list(B.values()):
 if bx:
  for j,pair in enumerate(bx):endsets[j].update(pair)
ends=[sorted(es,key=cmp_to_key(lambda a,b:sign(sub(a,b)))) for es in endsets];dims=tuple(len(x)-1 for x in ends);nx,ny,nz=dims
print(json.dumps({'stage':'complete_geometry_frozen','axis_endpoints':[len(e) for e in ends],'cell_count':prod(dims),'groups':len(order),'children':247}),flush=True)
assert prod(dims)<=100000 and len(order)==127
index=[{v:i for i,v in enumerate(es)} for es in ends];rowmask=(1<<nz)-1;ALL=(1<<prod(dims))-1
@lru_cache(None)
def cells(bx):
 if not bx:return 0
 ix=[(index[j][lo],index[j][hi]) for j,(lo,hi) in enumerate(bx)];bits=0
 rz=((1<<(ix[2][1]-ix[2][0]))-1)<<ix[2][0]
 for x in range(*ix[0]):
  for y in range(*ix[1]):bits|=rz<<((x*ny+y)*nz)
 return bits
CM={s:cells(bx) for s,bx in C.items()};HM=0
for bx in Hboxes:HM|=cells(bx)
EM=0
for mask in CM.values():EM|=mask
RM=EM&~HM;BASE=0
for s in CM:
 if s.bit_count()<2:BASE|=CM[s]&RM
assert BASE==0
# Per x/y row, z-union length is exact endpoint telescoping. No point tests.
xy=[mul(sub(ends[0][x+1],ends[0][x]),sub(ends[1][y+1],ends[1][y])) for x in range(nx) for y in range(ny)]
@lru_cache(None)
def zlength(mask):
 terms=[]
 while mask:
  low=(mask&-mask).bit_length()-1;end=low
  while mask>>end&1:end+=1
  terms.append(sub(ends[2][end],ends[2][low]));mask^=((1<<(end-low))-1)<<low
 return exactsum(terms)
@lru_cache(None)
def volume(bits):
 terms=[]
 for area in xy:
  zm=bits&rowmask
  if zm:terms.append(mul(area,zlength(zm)))
  bits>>=nz
 assert not bits
 return exactsum(terms)
# Verify every single box arrangement volume against its exact product formula.
for s in C:assert volume(CM[s])==directvol(C[s])
for bx in Hboxes:assert volume(cells(bx))==directvol(bx)
prior=BASE;rows=[];fee=zero;aggregate={}
for K in order:
 assert not (CM[K]&RM&~prior),'Core not previously covered'
 hk=0
 for S in G[K]:hk|=CM[S]
 bm=cells(B[K]);ck=CM[K];shell=bm&~ck
 assert not hk&~bm
 fresh=hk&RM&~prior
 gold=shell&~(RM&~prior)
 gout=bm&RM&~prior&~hk
 assert not gout&ck and not gold&gout and not fresh&gold and not fresh&gout
 # E_K is full Rlo complement plus prior. C_K already in E_K.
 assert (fresh|gold|gout)==shell
 c=volume(fresh);old=volume(gold);outside=volume(gout);joint=volume(shell)
 assert add(add(c,old),outside)==joint
 childterms=[]
 for S in G[K]:
  childB=box(bbox(K),S.bit_count());assert childB==B[K]
  childterms.append(sub(directvol(childB),directvol(intersect(childB,C[K]))))
 individual=exactsum(childterms);assert individual==scale(joint,len(G[K]))
 mk=K.bit_count();theory_exact=add(scale(directvol(C[K]),F(1,mk)),rat(F(2,3)));beta=av(directvol(C[K]))/mk;theory=av(theory_exact)
 assert sign(sub(theory_exact,joint))>=0
 if c:assert beta<b
 bb=bbox(K);agg=aggregate.setdefault(bb,{'masses':[],'cores':[],'fresh':zero,'joint':zero,'individual':zero})
 agg['masses'].append(mk);agg['cores'].append(K);agg['fresh']=add(agg['fresh'],c);agg['joint']=add(agg['joint'],joint);agg['individual']=add(agg['individual'],individual)
 rows.append({'core_mask':K,'core_mass':mk,'core_labels':[i for i in range(8) if K>>i&1],'bbox_rational':[[str(a),str(b)] for a,b in bb],'child_masks':G[K],'delta_max':1,'child_mass_M':mk+1,'fresh_cK':out(c),'gain_old':out(old),'gain_out':out(outside),'joint_carrier_shell':out(joint),'sum_individual_child_carrier_shells':out(individual),'theoretical_beta_plus_2_over_n_times_Delta':out(theory_exact),'beta_core_Arb512':beta.str(55),'identity_exact_residual':[],'fresh_cell_count_diagnostic_only':fresh.bit_count()})
 fee=add(fee,c);prior|=hk&RM
assert prior==RM and fee==sub(volume(RM),volume(BASE))
aggrows=[]
for bb,v in sorted(aggregate.items()):
 aggrows.append({'bbox_rational':[[str(a),str(b)] for a,b in bb],'core_count':len(v['cores']),'core_masks':v['cores'],'core_mass_range':[min(v['masses']),max(v['masses'])],'distinct_core_masses':sorted(set(v['masses'])),'fresh_fee':out(v['fresh']),'sum_joint_shells':out(v['joint']),'sum_individual_child_shells':out(v['individual'])})
summary={'full_actual_receiver_volume':out(volume(EM)),'original_H2_volume':out(volume(HM)),'full_Rlo_volume':out(volume(RM)),'base_residual_volume':out(volume(BASE)),'sum_fresh_cK':out(fee),'fresh_partition_identity_exact_residual':[],'sum_joint_carrier_shells':out(exactsum(volume(cells(B[K])&~CM[K]) for K in order)),'sum_individual_child_carrier_shells':out(exactsum(scale(volume(cells(B[K])&~CM[K]),len(G[K])) for K in order)),'distinct_bbox_count':len(aggregate),'positive_fresh_group_count':sum(bool(row['fresh_cK']['exact_terms']) for row in rows),'positive_fresh_bbox_count':sum(bool(v['fresh']) for v in aggregate.values()),'all_group_gain_identities_exact':True,'all_R573_shell_bounds_Arb_certified':True,'all_positive_fresh_cores_low_beta':True}
# Extract sums from the exact serialized records without any rounding.
def unout(o):
 d={}
 for term in o['exact_terms']:
  rr=root(term['radicand']);assert len(rr)==1 and rr[0][1]==1
  d[rr[0][0]]=F(term['coefficient'])
 return pack(d)
for key,field in [('sum_gain_old','gain_old'),('sum_gain_out','gain_out')]:summary[key]=out(exactsum(unout(row[field]) for row in rows))
assert add(add(fee,unout(summary['sum_gain_old'])),unout(summary['sum_gain_out']))==unout(summary['sum_joint_carrier_shells'])
# Additional frozen paid-carrier pass: same input, same endpoint partition.
paidprior=BASE;hpaid={};paidrows=[];skipped=[];elltotal=0;carrierfees=zero;childfreshfees=zero;paidold=zero;paidout=zero;paidshell=zero
for K in order:
 hk=0
 for S in G[K]:hk|=CM[S]
 childfresh=hk&RM&~paidprior
 if not childfresh:
  skipped.append(K);continue
 k=K.bit_count();m=k+1;bb=bbox(K);hb=hpaid.get(bb,0);base_mass=max(k,hb)
 assert base_mass<m and not CM[K]&RM&~paidprior
 ell=max(0,m-base_mass);assert ell==1
 beta=av(directvol(C[K]))/k;assert beta<b
 A=cells(B[K]);basebox=box(bb,base_mass);basecells=cells(basebox)
 assert not basecells&RM&~paidprior and not basecells&~A
 shell=A&~basecells;newcarrier=A&RM&~paidprior;old=shell&~(RM&~paidprior);outgain=newcarrier&~hk
 assert (old|newcarrier)==shell and not old&newcarrier
 assert (childfresh|outgain)==newcarrier and not childfresh&outgain
 vf=volume(childfresh);vn=volume(newcarrier);vs=volume(shell);vo=volume(old);vg=volume(outgain)
 assert vs==sub(directvol(B[K]),directvol(basebox)) and add(vn,vo)==vs and add(vf,vg)==vn
 paidrows.append({'core_mask':K,'core_mass_k':k,'bbox_rational':[[str(a),str(b)] for a,b in bb],'actual_child_mass_m':m,'paid_bbox_mass_before_hB':hb,'base_mass_max_k_hB':base_mass,'ell':ell,'true_fresh_child_volume':out(vf),'true_new_paid_carrier_volume':out(vn),'fullshell_volume':out(vs),'gain_old_covered_shell':out(vo),'gain_uncovered_carrier_outside_current_children':out(vg),'beta_core_Arb512':beta.str(55),'identity_exact_residual':[]})
 elltotal+=ell;carrierfees=add(carrierfees,vn);childfreshfees=add(childfreshfees,vf);paidold=add(paidold,vo);paidout=add(paidout,vg);paidshell=add(paidshell,vs)
 paidprior|=A&RM;hpaid[bb]=max(hb,m)
assert paidprior==RM and carrierfees==fee and add(childfreshfees,paidout)==carrierfees and add(carrierfees,paidold)==paidshell
summary['sum_theoretical_fees_all_groups']=out(exactsum(unout(row['theoretical_beta_plus_2_over_n_times_Delta']) for row in rows))
summary['sum_theoretical_fees_positive_fresh_groups']=out(exactsum(unout(row['theoretical_beta_plus_2_over_n_times_Delta']) for row in rows if row['fresh_cK']['exact_terms']))
summary['sum_joint_shells_positive_fresh_groups']=out(exactsum(unout(row['joint_carrier_shell']) for row in rows if row['fresh_cK']['exact_terms']))
summary['sum_individual_shells_positive_fresh_groups']=out(exactsum(unout(row['sum_individual_child_carrier_shells']) for row in rows if row['fresh_cK']['exact_terms']))
# Independent analytic formula communicated by root, checked in our exact field.
ss=scale(r[4],F(1,2));analytic=add(rat(F(1,5)),scale(mul(mul(sub(scale(ss,2),one),sub(scale(ss,2),one)),sub(ss,mul(ss,ss))),4))
assert analytic==fee and sign(sub(rat(F(9,5)),r[5]))>0
summary['independent_root_analytic_check']={'formula':'1/5+4*(2s-1)^2*(s-s^2), s=2^(-1/3)','exact_volume':out(analytic),'difference_from_full_arrangement_exact':[],'provenance':'Root independently supplied geometric classification and SymPy reduction; current script separately checks algebraic identity, not a dimension extrapolation.'}
assert unout(summary['sum_joint_shells_positive_fresh_groups'])==paidshell
assert childfreshfees==fee and not paidout
paid={'scope':'Same frozen n3 receiver and endpoint partition. Whole real carrier inserted into covered only when an actual child has fresh residual. No generic budget assertion.','paid_group_count':len(paidrows),'skipped_group_count':len(skipped),'paid_distinct_bbox_count':len(hpaid),'sum_ell_exact':elltotal,'original_all_group_sum_Delta_exact':127,'original_positive_fresh_group_sum_Delta_exact':summary['positive_fresh_group_count'],'sum_new_paid_carrier_volume':out(carrierfees),'sum_fresh_current_child_volume':out(childfreshfees),'sum_fullshell_volumes':out(paidshell),'sum_old_overlap_gain':out(paidold),'sum_uncovered_outside_current_children_gain':out(paidout),'complete_target_covered':paidprior==RM,'carrier_fee_equals_complete_Rlo_minus_base_exact':True,'all_two_gain_identities_exact':True,'groups':paidrows,'skipped_core_masks':skipped,'final_hB':[{'bbox_rational':[[str(a),str(b)] for a,b in bb],'largest_paid_mass':h} for bb,h in sorted(hpaid.items())]}
result={'status':'PASS_FROZEN_N3_FULL_RECEIVER_SAME_CORE_BATCH_CERTIFICATE','input':{'sources_rational':[[str(a) for a in p] for p in z],'masses':['1']*8,'n':3,'lambda':1,'L':1,'U':16,'W':8,'top_absent_mass_8_lt_2U_over3':True,'coordinate_order':'increasing x, ties by fixed lexicographic y,z label; group order (core mass,mask)','all_subsets':255,'original_high_family_singletons_only_certified':True},'partition':{'axis_endpoint_counts':[len(es) for es in ends],'axis_endpoints_exact':[[out(t) for t in es] for es in ends],'full_arrangement_cell_count':prod(dims),'full_Rlo_cell_count_diagnostic_only':RM.bit_count(),'method':'Exact axis-box endpoint ranges; whole cell incidence by indices. Bitset union/difference; exact z-length integration on each x/y slab. No midpoint/center samples.'},'summary':summary,'paid_carrier_pass':paid,'groups':rows,'bbox_aggregation':aggrows,'precision_bits':512,'field':'Fraction coefficients in independent cubic-radical monomials cubert(2),cubert(3),cubert(5),cubert(7), exponents0..2','exact_volume_arithmetic_error':0,'unresolved_signs':0,'numerical_scope':'All 255 actual C_S, original H2, all 127 batches/247 children, single frozen n3 geometry. Same-core batching reduces this family of shell fees; cumulative fresh total is exact but not a general source-budget bound. Same-bbox summaries alone do not license cross-core merging.','interpreter':sys.executable,'python_version':platform.python_version(),'python_flint_version':flint.__version__,'command':'OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 '+shlex.join([sys.executable]+sys.argv),'runtime_seconds':time.perf_counter()-start,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'processes':1,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
args.output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');signal.alarm(0)
print(json.dumps({'status':result['status'],'summary':summary,'runtime_seconds':result['runtime_seconds'],'peak_rss_bytes':result['peak_rss_bytes']},indent=2))
