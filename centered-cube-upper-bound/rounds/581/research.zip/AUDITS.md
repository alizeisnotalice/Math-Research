# R581 合并独审

先行命题与作者变体的适用范围分别保留。历史/tmp路径仅标明审读时的来源；定版统一论证见REPORT.tex，最终审核另见FINAL_AUDIT.md。

# R581 同 core children 联合增量：先行命题独审

**先验结论：通过，且这是固定 core 内真实的联合费用改善。** 正确定义允许 children、排除原 H2 内的 singleton 情形并使用 core 质量顺序后，每组 child 的逐项 `sum m_i` 可以换成 `max m_i`，没有因该处理顺序额外购买 C_K 的隐藏费用。仍未得到跨全部 K 的 `sum max m_i` 预算；不能据此声称根阶 J 或一般弱型改善。

本审先独立完成下列推导并向主代理报告，再检查 `/tmp/ccu_r581_sol_joint_gain.md`；该稿在检查时尚不存在，因此本文件是准确分组命题的独立审查，**不自动认证未来作者文字**。只写本文件，无新实验或历史重算。

## 1. 必须固定的分组范围

保持原完整正标签输入、原 H2、原带 `[L,U]` 和完整 R_lo。预先固定全标签按 `(m_i,tie)` 的递增全序 `prec`；删除 S 的最早标签，而不是按 receiver、fresh 情形或几何另选最小者。同质量来源的 ties 只用于唯一归组，不可在组间重复归属。

初始覆盖 `R_lo^c` 及全部实际带内 `[L,2L)` 见证，R_lo 内费用记 c0，已有固定尺度证明给 `c0<=2W`。若 U<2L 则全部目标已在初始部分；W<L 时目标为空。剩余只需处理实际 `2L<=m_S<=U` 的 S。单标签 S 的 C_S 包含于原 H2，因此始终在初始旧覆盖中，不能将其删除得到的空 core 套入半 core 公式。

对每个非空实际 K，准确允许集应是

`I_K={i∉K: i prec j 对所有 j∈K, 2L<=m_K+m_i<=U}`。

每个剩余非 singleton S 恰出现于一个 `K=S\{min_prec S}` 的 child `K union {i}`。不是任意 foreign 标签都可加入本组，也不把其他 K 的 child 混进来。仅处理 I_K 非空的组；其有限性保证

`a_K=max_(i∈I_K) m_i`，`M_K=m_K+a_K`

存在。所有组和所有 max 都依原有限全标签族，允许最大 child 的接收盒为空或已覆盖；这不会损害外包界。

由最小标签条件，`m_i<=min_(j∈K)m_j<=m_K`，故每个组满足

`L<=m_K<M_K<=U`，`M_K<=2m_K`。

特别 child 质量恰为2L、core 质量恰为L、相等原子质量的 ties 都合法。非空 core 和原带端点不能省略。

## 2. 按 m_K 升序时 C_K 确已覆盖

将全部非空组按 m_K 递增、同质量固定 ties 处理，旧覆盖 E_K 包含初始集及所有已处理组的**真实 children 接收盒并**。

对当前 K：若 m_K<2L，则实际 C_K 已在初始低质量并中；若 K 是 singleton，则 C_K 在原 H2 中，也已覆盖。其余情形 `2L<=m_K<U` 且 |K|>=2，令 j=min_prec K、P=K\{j}。原实际 K 恰为 P 组的允许 child：其质量在待处理带内，j 是其全序最小标签。由于原质量正，`m_P=m_K-m_j<m_K`，所以该组已经处理，其真实 child C_K 已加入旧覆盖。

这证明 C_K⊂E_K，不依赖按 child 质量升序，也不需要额外支付一次 core 盒。即使该较早组新增费用为0，仍须保留全部原 children 作为旧覆盖，或者明确它们已包含于此前覆盖；不能因零费用而遗忘旧盒。若一组被安全跳过是因为 children 已全部覆盖，则相同归纳仍成立。同质量组的处理 ties 不影响该严格更小的父 core 关系。

## 3. 联合 carrier、可见组与准确 gains

记 `U_K=union_(i∈I_K) C_(K union {i})`，本组新接收区域 `F_K=U_K\E_K`，`c_K=lambda|F_K|`。全部组处理完后，完整覆盖和互不交新增区域给

`J=c0+sum_K c_K`。

以最大实际 child 质量定义真实共同半径外盒

`B_K=B(K,M_K)=intersection_(j∈K) Q(z_j,(M_K/lambda)^(1/n))`。

因为每个 child 包含 K、实际质量不超过 M_K，准确有 `U_K⊂B_K`、`C_K⊂B_K∩E_K`。B_K 是原非空 core 的显式 outer carrier，**不是**一个实际标签见证，不是新接收动作，也不能在未支付其 overshoot 时将整个 B_K 宣称为以后的免费旧覆盖。

对 c_K>0 的组，取一个 fresh receiver 所属实际 child S。它在原 H2 外，K 是其至少半质量的实际 core，因此已证 hereditary 条件给 beta_K<b。这个低 beta 条件只对有 fresh residual 的组使用；I_K 非空或有大 M_K 本身并不保证它。若只要求 fresh 集合非空，结论也成立，但费用求和过滤为 c_K>0 最清楚。

由 `M_K<=2m_K`，R573 半 core 增量直接给

`c_K <= lambda|B_K\C_K| <= (beta_K+2/n)(M_K-m_K) = (beta_K+2/n)a_K`。

该公式包含 beta_K=0、原 C_K 空盒及全部正部守卫。它同时覆盖本组所有 children，不需要给每个 i 再付一次 core 增量，因此确实从逐 child 的 `sum_(i∈I_K)m_i` 降为一个 `a_K=max m_i`。组顺序只改变实际新接收区和 gains，不引入其他覆盖购买费用。

完整 true gains 可准确保留为

`G_K^old=lambda|(B_K\C_K)∩E_K|`，

`G_K^out=lambda|B_K\(E_K∪U_K)|`。

于是 `c_K=lambda|B_K\C_K|-G_K^old-G_K^out`。三部分是 B_K\C_K 的互不交有限分解，E_K 即使含无界的 R_lo 补集也没有无穷减无穷。故可得完整但尚未结算的上界

`J <= 2W + sum_(K:c_K>0)[(b+2/n)a_K-G_K^old-G_K^out]`。

## 4. 改善范围与验收缺口

每组内 `max` 取代 `sum` 是联合接收外包真实产生的改善，不是假借顺序隐藏另一次 core 费用。一个组只有一个 child 时两者相同；多个 children 时可能节省，但跨 K 的来源仍可重复。来源 i 可以在多个不同 K 的允许集中出现，原 K 之间也可以 crossing，处理顺序没有把它们变成不复制森林。

因此尚未证明 `sum_(K:c_K>0)a_K` 为 O(W)、O(log(U/L)W) 或根阶可付，也没有证明所有真实 gains 足以抵消重复费用。下一步必须支付这份完整联合总账（或另一份覆盖完整 R_lo 的机制），不能只重新命名该未知和。

**无必须修复的代数/顺序错误；条件如上必须保持。** 本次使用有限集合、质量序及已证 R573 增量作书面核验，无需新符号或数值运算；未重跑已有 n=3/n=4、未扫输入、未操作仓库/git/PDF、未开代理或修改他人文件。完成此有界审核并停止。


# R581 作者分组新顺序：差异补审

**结论：作者新版本通过，无必须修复项。** 坐标/tie 顺序不是前审的质量顺序；本补审独立核验其新增 dominant-atom 排除、core 早覆盖归纳及 tail envelope，不以旧审自动覆盖新 order。

被审文件：`/tmp/ccu_r581_sol_joint_gain.md`，SHA256
`99e5b37c3c307cf013af9cc9e28e56cacc5d414be6c034fb0646375dafc9f76b`。
此前 `/tmp/ccu_r581_group_statement_audit.md` 检查作者稿时该文件尚不存在；其 mass-order 先验结论保留为另一准确版本，不与此版本混写。

## 1. 坐标顺序与 dominant-atom 分支

作者固定一个坐标，再以固定标签身份破除坐标 ties，得到全局一次确定、对全部 receiver 共用的全序。删除每个 nonsingleton S 的首标签 i 后，不能再从序关系推断 m_i 最小；作者因此显式加入 `m_i<=m_K`，这一修正必要且充分。

若删除的标签反而满足 `m_i>m_K`，则 `m_i>m_S/2`。该 singleton 的 beta=1，是高 beta 半质量实际 core；原全尺度贪心 H2 已覆盖整个 C_S。也可直接用 i 所属原块质量 `M_P>=m_i`：`r_S<(2m_i/lambda)^(1/n)<=rho_P`，而 `C_S⊂Q(z_i,r_S)⊂H2`。等号 m_i=m_K 时同样有 H2 覆盖；作者把等号保留在允许集内只会产生零目标贡献，不破坏上界。

所以初始低质量覆盖、singleton 免费排除和 dominant-atom 排除之后，全部剩余目标见证仍唯一进入作者式 (1) 的某个真实 group。这里没有删掉原 H2 外的 receiver，没有新增一笔 H2 付款，也没有按 source 或 receiver 私选排序。共址/坐标 ties 仍按原标签处理。

## 2. 新 order 下的 C_K 早覆盖归纳

对每个允许 child，`2L<=m_K+m_i<=U` 且 `m_i<=m_K`，故 `L<=m_K<m_S<=U`。当按 m_K 递增处理组时：

- `m_K<2L`：C_K 在初始实际 `[L,2L)` 见证并中；
- K 为 singleton，或其坐标首标签 j 的质量大于其剩余 core P 的质量：C_K 在原 H2 中，已属于初始 R_lo 补集；
- 其余情形，若 `m_K>=2L`，则 K 恰是 P 组的允许 child，坐标首标签关系和 `m_j<=m_P` 均满足，且 `m_P<m_K`，所以该组更早处理。

这补上了质量顺序原本自动保证、而坐标顺序不再自动保证的分支。若等号 m_j=m_P，则仍允许进 P 组（也可已由 H2 覆盖）；无循环依赖。所有旧真实 children，即使新增费为0，也仍在旧覆盖中。因而 C_K⊂E_K 的证明完整，没有隐藏的单独购买 C_K 费用。

非空 group 的允许标签集合有限，Delta_K 最大值存在，并由一个真实 child 达到；`M_K<=2m_K` 且 `M_K<=U`。作者未把 B_K 当实际标签动作，也未将未付 overshoot 加入未来免费旧覆盖。仅对 c_K>0 组用 beta_K<b 的条件正确。此前审过的 signed same-core 增量因此在本新顺序下仍合法，确实以组内 max m_i 代替逐 child 的 sum m_i；跨 K 的重复费用仍未知。

## 3. Tail envelope 的索引与范围

按该固定坐标全序将原标签编号1,…,N。若 min K=j，则 K 中全部标签都在真实尾 `{j,…,N}` 内，且每个 child 包含原标签 j。对该 j 全部 groups 取最大实际 child 质量 M_j，有限非空时达到最大值，故作者式 (5) 的 source-centered cube 覆盖合法；空 j 组略去。每个 child 仍满足 m_i<=m_K，所以

`M_j<=min(U,2W_j)`，`W_j=sum_(i=j)^N m_i`。

因此准确的求和链为

`sum_(j有group) M_j <=2 sum_(j有group)W_j <=2 sum_(j=1)^N W_j =2 sum_(i=1)^N i m_i`。

作者式 (6) 中的右端尾和应理解为**全1,…,N** 的尾和；也可对缺失组补 M_j=0 后采用该记法。不能把右端仍限制为只有非空组的 j，却继续写与 `sum_i i m_i` 完全相等。按作者“Absent groups are omitted”及其上界语境，加入全部非负尾项是合法放宽，显示 envelope 正确。

等权时 `sum_j W_j=m N(N+1)/2`，而 W=mN。它只说明这一粗 tail-mass envelope 不给维数一致预算：每个标签 i 被计入 i 条坐标尾。它没有证明实际所有 M_j 或新 receiver 体积达到这个量级，更没有构造一般 J 反例。作者明确区分这一点，亦保留 `min(U,2W_j)`、固定原带和全部 receiver gains。初始费用若与这些 covers 合用仍须保留一次 c0<=2W；作者未将其省略为已完成的新总界。

## 范围与实际操作

只审新坐标顺序、剔除条件、归纳补充分支和 tail envelope；没有重复 R573 产品公式、已有 n=3/n=4 或正执行的 R581 数值实验。实际工具仅作文件读取和 SHA 记录；这里有限序与尾和恒等式由上面的书面推导核定，无须重跑作者的符号求和。

**无必须修复项。** 新版本合法保留完整目标，组内 max 改善真实；尾分组仍只是未付重复来源的粗外包，跨 core/tail 与 actual gains 的累计比较尚未证明。未修改作者/仓库，未操作 git/PDF 或开启代理；审核完成，停止。


# R581 已付同 bbox carrier 合并：关键算法独审

**结论：任务给出的严格算法版本及其完整费用上界通过。** 全部 carrier 的新增接收体积确已付款，故同 bbox 可以合法复用并消去重复质量区间；导数系数 `c_n=b+(1+log2)/n` 正确。仍未支付跨 bbox 的联合正差，未得到根阶 J 预算。

先按主代理准确命题独立推导，再读 `/tmp/ccu_r581_astra_bbox_merge.md`，被审 SHA256 为
`c09507b57b1497837a17dde354a8c444f612d18914dc305a08596307d2ea3f61`。
作者稿与准确命题不是同一伪代码；差异及两个需澄清的严格集合 guard 记于第5节，不由旧顺序审查自动认证。

## 1. 完整覆盖、先前 core 与零测处理

在任务版本中，原 R_lo 固定；G 初始包含其整个补集和实际 `[L,2L)` 见证。R_lo 内初始费用 `c0<=2W`。只需处理原带内质量不小于2L的实际 children；singleton 先跳过，因为 C_S 已在原 H2 中，不能给空 K 定义 bbox。

固定坐标/tie 全序删除首标签 i，K=S\{i}。若 `m_i>m_K`，C_S 被原 singleton 高 beta 半质量 core 覆盖，已在 H2 中；等号亦没有原 H2 外贡献。其他允许 child 有

`L<=k=m_K<M=m_S<=U`，`M<=2k`。

按原 child 质量 M 升序，K 自己的实际质量严格小于 M。若 k<2L，C_K 在初始低质量覆盖中；若 K 为 singleton 或其被删首标签支配其余质量，C_K 在 H2；否则实际 K 先前已作为 child 处理。如果先前新 receiver 测度正，则买下包含 C_K 的完整 carrier；若仅有零测新集，则 free 加入真实 C_K。因此在当前事件确有 **C_K⊂G**，而不只是 a.e. 包含。有限原子只有有限个实际子集，所有这种免费加入的差集之并仍是零测。

每个正 fresh 事件完整支付 `p=lambda|B_box(M)\G|` 后才把整个 B_box(M) 加入 G；未触发时不能免费加入 B 或更新其已付上限。最后每个原实际 child 已覆盖，所以任务的 complement-initialized 版本精确有 `J=c0+sum p_e`。G 本身可能无界，但所有新增量与差集限制在有限 carrier 中，没有无限集合测度相减。

## 2. h、baseline、区间消重与精确收益

这里“同 bbox”必须包含位置和全部坐标端点，不能只指跨度向量相同。固定该几何 bbox D，记 `B_D(q)` 为同一组端点在半径 `(q/lambda)^(1/n)` 下的共同接收盒，`F_D(q)=lambda|B_D(q)|`。它是实际几何 carrier，不是另一个原标签集或来源动作。

h_D 只记真正已经付费并加入 G 的完整 carrier 最大 mass，初值0。当前正 fresh 事件必有 h_D<M，否则已付 B_D(h_D) 已包含当前 carrier，C_S 不可能仍有正 fresh 部分。令 `a=max(k,h_D)<M`。若 a=k，`B_D(a)=C_K⊂G`；若 a=h_D，则它是确已付的 carrier，亦在 G。无需对 h_D=0 定义半径，因为 a>=k>0。

由于盒随 q 嵌套，准确得到

`p_e=F_D(M)-F_D(a)-g_e`，

`g_e=lambda|[B_D(M)\B_D(a)]∩G_old|>=0`。

费用 p_e 连 overshoot 都真实支付，不能将它误读成只支付 child C_S 的新增部分。收益 g_e 是实际旧覆盖，已在等式中使用一次，不能另当未用来源信用。

同 D 后续事件的 baseline 至少为全部此前已付 mass cap，故 `(a_e,M_e]` 两两不交（同 mass 若已付就不会再次触发）。总长度 ell_D 合法；所有同一 core 的区间均在 `(k,k+max m_i]` 内，额外相同 bbox 的别的 cores 又可取消重叠 cap。这是已付 receiver 几何的真实合并，不是无复制来源森林或未来 core 的预支。

## 3. 正部与 a.e. 导数系数

固定 bbox 跨度 d_j>=0，令

`beta_D(q)=prod_j(1-d_j/(q/lambda)^(1/n))_+`，`F_D(q)=q beta_D(q)`。

在任一宽度仍非正的开参数区间，乘积恒为0，导数为0；不能把超出[0,1]的 d/r 当 Bernoulli 概率。全部宽度正时，置 `w_j=1-d_j/r∈(0,1]`，则

`q beta'_D(q)=(1/n)sum_j(1-w_j)prod_(l≠j)w_l <=1/n`。

和式是一个辅助独立 Bernoulli 模型的“恰一失败”概率；也可展开 `prod_j[w_j+(1-w_j)]=1`，其为全部非负项的一部分。这不是对真实来源增加独立性假设。正部乘积在每个正质量紧区间连续、分段 C1且绝对连续，有限临界端点可 a.e. 积分，包含 beta_K=0、空原 core 接收盒及 d_j=0。

触发时 C_S 有原 H2 外 fresh receiver，K 是实际半质量 core，因此 `beta_D(k)=beta_K<b`。对当前积分区间 `k<=a<=q<=M<=2k`，

`beta_D(q)<=beta_D(k)+log(q/k)/n <=b+log2/n`。

于是 a.e.

`F'_D(q)=beta_D(q)+q beta'_D(q) <=b+(1+log2)/n=c_n`。

最后 `sum p_e<=c_n sum_D ell_D-sum_e g_e`，任务版本给

`J<=2W+c_n sum_D ell_D-sum_e g_e`。

这已完整计费实际 carrier；缺口正是跨全部变化 bbox 的这份联合差分能否由原来源总量控制。没有 `sum ell_D<=O(W)` 或 gains 可吸收的既有结论。

## 4. 作者额外范围陈述

同 bbox 不同 cores 的 interval cancellation 可以额外改进 sibling max；若限制为 bbox-closed cores，且 closed 指包含原输入中该 bbox 内的全部标签，则同 bbox 已唯一确定同 core，额外合并确退化为 sibling 合并。稿件没有把这个条件假定到一般实际 core 上。

Fresh child 避开所有旧已付 carriers 是实际 receiver 约束，但它不保证违反旧极值的标签携带可比质量，不自动支付不同 bbox 的重复。作者明确停在跨 bbox 预算，未推广成根阶费用或一般弱型改善。

## 5. 作者稿与准确命题的实际差异及定版 guard

当前作者稿使用 **minimum-mass** 删除而非坐标首标签。对非 singleton，这使 m_i<=m_K 自动成立，半 core 证明和按 child mass 的顺序仍合法；它是另一准确 order，不应在正文同时称作固定坐标 deletion。作者只处理 `2L<=m_S<2U/3`，仍覆盖全部 R_lo，所需 C_K 的质量更小且在同范围或 base 中，没有尾端遗漏。

其初始集是原 H2 加较大的固定尺度饱和集合 E_low，而非 R_lo 补集。`lambda|E_low|<=2W`，且它覆盖全部 `[L,2L)` 见证。此版本可能为 R_lo 外的 carrier overshoot 付款，但已经实际计入 p_e，故正文 `J<=2W+sum p_e` 仍成立；不能在这个版本中无条件写 complement 版本的精确等式 `J=c0+sum p_e`。

**严格算法定版须补清两个 guard：**

1. 在删除/计算 bbox 前先略去 singleton（它们已在 H2）；否则作者开头的“删后 k>=M/2”对 singleton 空 core 不成立。
2. 对“无正测 fresh 部分”分支，采用任务指定的 free 加入该真实 child C_S 的零测差集；或者把所有“C_K已覆盖”的包含统一改成 a.e. 包含，并说明有限零测并不影响式(1)。当前稿只写 skip，严格集合包含没有随之保证。费用恒等式本身用 a.e. 版本仍正确，但不能把它自动当成严格 set 版本。

这两个 guard 不改变 p_e、h_D、ell_D、g_e 或任何最终费用系数；任务给出的算法已经包含其修复。除上述作者文字精确化外，无新的费用/导数错误。

## 实际操作与停止

本次仅文件读/hash及书面有限集合、质量序、正部微分核验；未重复作者已有三坐标 SymPy、n=3/n=4 或 R581 数值任务，没有扫描其他输入。未修改任何作者/仓库文件，未 git/PDF 或开启代理。**通过的是明确 guard 后的完整 paid-carrier 算法和准确账；跨 bbox 根阶付款仍未证明。** 完成停止。
