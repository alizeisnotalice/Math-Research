# R661: cube L2 source and the exact adjoint consequence

Checked 2026-11-15. Scope: one original paper, centered axis-parallel cubes; no ball theorem substituted.

## Primary source

Jean Bourgain, *On the Hardy-Littlewood maximal function for the cube*, arXiv:1212.2661v1, submitted 11 December 2012, 20 pages. Official [record](https://arxiv.org/abs/1212.2661) and [full PDF](https://arxiv.org/pdf/1212.2661). Verified metadata; actual reading: PDF introduction, printed pp. 1–4, especially definition (1.1), norm definition (1.2), and the unnumbered main Theorem on printed p. 3. Not an independent audit of the entire proof. The official record inspected displays only v1; this note cites that preprint version and makes no assertion about journal metadata or correction status.

Definition (1.1) uses a fixed centrally symmetric convex body B and the centered averages |B|^{-1} integral_B |f(x+t y)| dy, t>0. The main Theorem states C_p(B_infinity)<C_p for all p>1. Immediately below it, B_infinity=[-1/2,1/2]^n is fixed. Thus this is explicitly the centered cube operator with a common scale in every coordinate, not the strong maximal operator with independent side lengths, and not a supremum over orientations. C_p depends on p, not n. In particular, there is an absolute finite C_2 with ||M_square h||_2 <= C_2 ||h||_2 in every dimension. No numerical value for C_2 is supplied by that theorem. The p=2 case is also recalled on printed p. 1 as an earlier absolute bound for symmetric convex bodies, but the present note does not rely on an uninspected earlier source.

## Consequence proved here: one frozen linearization and its adjoint

All measures below are Lebesgue measure on R^n. Put Q=[-1/2,1/2]^n,

    k_s(x)=s^{-n} 1_Q(x/s),
    A_s h = k_s * h,                  s>0,
    M_square h = sup_{s>0} A_s |h|.

If the project uses Q=[-1,1]^n instead, replacing s by 2s gives the identical full maximal operator and changes no constant.

Let F_1,...,F_m be measurable and pairwise disjoint up to null sets; fix positive scales sigma_1,...,sigma_m. Define T on L2 by

    T h(u) = sum_i 1_{F_i}(u) A_{sigma_i} h(u),

and set T h=0 off F=union_i F_i. This is linear because the sets and scales are frozen before applying T. Pointwise,

    |T h| <= 1_F M_square h,
    ||T||_{2->2} <= C_2.

Since each k_s is real and even, A_s is self-adjoint. Finite summation and the L2 pairing therefore give exactly

    T* g = sum_i A_{sigma_i}(1_{F_i} g),
    ||T* g||_2 <= C_2 ||1_F g||_2 <= C_2 ||g||_2.

This conclusion is a direct duality consequence of the cited theorem, not a separate theorem quoted from Bourgain. It is uniform in n,m,the sets,and the chosen positive scales. For arbitrary g_i supported in F_i, disjointness gives the useful equivalent form

    ||sum_i A_{sigma_i} g_i||_2
        <= C_2 (sum_i ||g_i||_2^2)^{1/2}.

In particular, when |F|<infinity,

    ||sum_i A_{sigma_i} 1_{F_i}||_2^2
        <= C_2^2 sum_i |F_i|.

No separation, convexity, or regularity assumption on the F_i is needed. Disjointness is the reason that T has the pointwise maximal domination with constant one. If scales vary measurably with u, the same forward domination holds, but the displayed fixed-scale convolution formula for T* must be replaced by its actual variable-kernel integral; it must not be reused unchanged.

## Exact limit: nontangential adjoint supremum is still a separate problem

The conclusion above controls one frozen T* in L2, uniformly over choices. It does not, by itself, control the L2 norm of a pointwise supremum over many T*, nor a nontangential supremum involving additional positions, scales, or admissible configurations. Such a claim requires its exact operator definition and an additional domination or maximal argument. A bound for each member of a family cannot simply be moved outside a pointwise supremum. Nothing in the cited cube theorem supplies the main agent's proposed nontangential adjoint estimate as stated.

For a logical diagnostic (not a cube counterexample), on counting-measure ell2^{m+1}, let S_j h=h_j e_0 for j=1,...,m. Then ||sup_j |S_j h|||_2=max_j |h_j|<=||h||_2, yet S_j* e_0=e_j and ||sup_j |S_j* e_0|||_2=sqrt(m). Thus even a common forward maximal L2 bound alone does not abstractly imply an adjoint maximal bound. This finite-rank calculation was actually run in local MATLAB for m=16: maximum individual operator norm=1 and the adjoint-sup test norm=4=sqrt(16). The general identity is the explicit exact calculation above; the numerical run is only a check.

## Provenance and tool record

Only the official arXiv record and original PDF were used. No broad literature review, no ball result, no historical project file read, no Git operation. The academic-literature-search skill was read through local MATLAB after shell startup failed because a configured writable root contains a symlink. PDF textual extraction supplied the definitions and theorem; the screenshot attempt was unavailable. The only report requested is this file, so no separate BibTeX or search-log artifacts were created.
