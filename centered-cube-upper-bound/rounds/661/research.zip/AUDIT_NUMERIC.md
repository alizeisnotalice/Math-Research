# R661 independent numerical certificate audit

**Verdict: PASS for all 21 recorded dimensions and their full stated continuous B,L domains.** All 42 saved critical-root brackets have the correct strict endpoint signs, contain the actual critical points, lie inside the prescribed domain, and have f enclosures strictly below 2401/2500. The saved script hash matches. This numerical certificate does not establish the statement for every integer n>=256; that extension requires the separately reviewed analytic proof.

Only AUDIT_NUMERIC.md, independent_numeric.py, and independent_numeric.json were written. No producer functions were imported, no SciPy scan or Brent solve was rerun, no tensor-grid model was implemented, and no Git operation was performed.

## Definition and equivalence

For n>0 and L>=B>0, log(L/B)>=0, so both sides of the proposed square-root comparison are nonnegative. Directly from the definition,

Phi=-L+2 sqrt(2n exp(L/n) log(L/B)) <= -L/50

is equivalent to

2 sqrt(2n exp(L/n) log(L/B)) <= (49/50)L,

and, after squaring and dividing by L^2>0, to

f=8n exp(L/n) log(L/B)/L^2 <= 2401/2500.

At L=B, f=0 exactly and Phi=-L. No division by log(L/B) is used at this endpoint. The exact rational threshold agrees with every saved record.

The derivative in B is -8n exp(L/n)/(B L^2)<0. Therefore, for each fixed n, its worst allowed value is B0=(5/2)sqrt(n). Bounding f(L,B0) on the larger interval [B0,n log n] covers all admissible pairs B>=B0, B<=L<=n log n, including B values whose own domain starts later. There is no separate numerical B grid.

## Actual finite parameter set

The checked integers are exactly

256,257,511,512,1000,1024,2048,4096,8192,10000,16384,32768,65536,131072,262144,524288,1048576,2097152,4194304,8388608,16777216.

This is the six explicitly named n together with 2^10 through 2^24, deduplicated and sorted: 21 cases. For each, I independently verified B0<2n<n log n. The near-left point is exactly B0(1+10^-6), not the endpoint B0. Saved B0, upper endpoint, and near-left enclosures contain the independently recomputed 256-bit values.

## Complete critical-point coverage

Independent differentiation gives

f_L = 8n exp(L/n) g(L)/L^3,
g(L)=(L/n-2)log(L/B0)+1,
g''(L)=1/(nL)+2/L^2>0.

For every saved n, both root brackets are strictly inside (B0,2n), are disjoint, and occur in increasing order. The first bracket has g(left)>0>g(right); the second has g(left)<0<g(right). Also g(B0)=g(2n)=1; the direct interval evaluations are strictly positive and agree with the saved enclosures.

Continuity gives a root in each bracket. Strict convexity gives at most two roots, so these are the only roots up to 2n. For L>=2n, L>=B0 and (L/n-2)log(L/B0)>=0, so g(L)>=1: there are no further critical points. Consequently the left endpoint, both enclosed critical points, and right endpoint cover every possible maximum of f on [B0,n log n]. The extra near-left point is checked but is not needed to replace missing critical points. Root 1 is a local maximum and root 2 a local minimum; evaluating both is conservative.

Thus these are full continuous-L certificates for the 21 fixed n, not merely sampled values of f. This conclusion uses the stated derivative/root-count argument; the Brent scan alone would not justify completeness.

## Independent Arb checks

The author used 192-bit Arb after SciPy supplied candidate roots. I independently used python-flint Arb at 256 bits and parsed each saved decimal endpoint as an exact Fraction, then converted it through fmpq to an enclosing ball. The floating Brent estimate itself was not treated as a proof object. Each estimate also happens to lie strictly within its saved exact rational bracket.

For every one of the 42 brackets, the script verifies:

- The exact rational ordering and the full domain ordering B0<lo_1<hi_1<lo_2<hi_2<2n<n log n.
- The independent g values have the required strict opposite signs and are contained by the author's printed endpoint enclosures.
- A fresh interval hull contains both exact rational endpoints; direct interval evaluation of f on this **whole bracket** is strictly below 2401/2500 and is contained by the author's printed f enclosure.
- Reconstructing just the author's 192-bit midpoint/radius ball constructor, its ball contains both exact decimal endpoints. The float-derived endpoint strings therefore do not create a containment gap.

The independently recomputed near-left f and right-endpoint f values are also contained by their saved printed enclosures and are strictly below threshold. L=B0 is treated by its exact identity. All pass flags, source precision and worker metadata, and the saved threshold representation were checked for consistency.

The largest certified value is at n=256, L=n log n. Its independent enclosure is

[0.9286096944100628990093977058968656466619953962267313580313272527572220180547 +/- 9.37e-77].

Every other checked whole-root-bracket or endpoint/near-left enclosure lies strictly below that ball. All these upper bounds are below the exact rational 929/1000, which is below 2401/2500=0.9604. The saved worst_scipy location agrees, but this conclusion is established with Arb comparisons rather than its floating ranking.

## Elementary Taylor constants and provenance

The supplied halo_check.py and halo_results.json contain no degree-32 Taylor code or recorded Taylor outputs. GLOBAL_ALLOCATION.md says that an earlier Fraction check was actually run, but no original execution record was supplied to this audit, and the parent also reported receiving no such record. I cannot independently confirm that earlier execution. This provenance limitation does not imply that its constants are false.

I **actually ran a new independent Fraction verification** and recorded its complete rational inputs, lower/upper bounds, comparisons, and source in independent_numeric.py/json. For each rational x>0 with x<34, this uses

S_32(x)=sum_{k=0}^{32} x^k/k!,
0<exp(x)-S_32(x) <= [x^33/33!]/[1-x/34].

This is degree 32, with 33 summands including k=0. The bound follows because successive omitted-term ratios are at most x/34. The independently executed checks are:

| Desired constant | Rational exponential check |
|---|---|
| sqrt(e)<5/3 | upper bound for exp(1) <25/9 |
| log(16/5)<6/5 | lower bound for exp(6/5) >16/5 |
| 11/4<log16 | upper bound for exp(11/4) <16 |
| log16<14/5 | lower bound for exp(14/5) >16 |
| log(896/25)<18/5 | lower bound for exp(18/5) >896/25 |

The exact rational comparison 576/605<2401/2500 also passes. These are finite constant checks attributed to this independent audit run, not a reconstruction of the author's prior tool history. They do not on their own prove the all-n statement.

## Reproduction and resources

From this directory:

OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 /Users/zzh/.local/share/math-research-tools/venv/bin/python independent_numeric.py

Final recorded run: Python 3.12.14, python-flint 0.9.0, one process, one flint thread, BLAS environment limits all one, 256-bit independent precision; approximately 0.0159 s wall and 0.0048 s CPU. The audit does not invoke SciPy. The JSON records SHA-256 hashes of NUMERIC.md, halo_check.py, halo_results.json, and independent_numeric.py. The producer script's SHA-256 is f60c16e9cf683da1c23ba35d731a0a6b623982386795e8488144d4286d1cf62b and matches the saved result field.

The scope remains the finite list of n, with rigorous continuous B,L coverage for each listed n. General n, cube realizations, tensor-grid allocation, and any eventual dimension theorem are outside this numerical audit.
