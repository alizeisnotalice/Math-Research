"""Independent R661 Arb root-bracket audit; no SciPy scan, no producer import.
Finite dimensions only. Also independently records exact degree-32 Taylor constants.
"""
import os
for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):
    os.environ[key]='1'
from pathlib import Path
from fractions import Fraction as Q
import json,hashlib,platform,time,resource
import flint
from flint import arb,ctx,fmpq
P=Path(__file__).resolve().parent
start=time.monotonic();r0=resource.getrusage(resource.RUSAGE_SELF)
ctx.prec=256;ctx.threads=1
source=(P/'halo_check.py').read_bytes()
raw=json.loads((P/'halo_results.json').read_text())
assert hashlib.sha256(source).hexdigest()==raw['sha256']
assert raw['precision_bits']==192 and raw['max_workers']==1
assert Q(49,50)**2==Q(2401,2500)
expected=sorted({256,257,511,512,1000,10000}|{2**i for i in range(10,25)})
assert [r['n'] for r in raw['results']]==expected and len(expected)==21

def ball(q):
    q=Q(q);return arb(fmpq(q.numerator,q.denominator))
def exactq(q):
    q=Q(q);return fmpq(q.numerator,q.denominator)
def saved_contains(saved,value):
    assert arb(saved).contains(value)

data=[];all_f=[];source_box_pass=0
for row in raw['results']:
    nv=row['n'];n=arb(nv);B=5*n.sqrt()/2;end=n*n.log();T=ball(Q(2401,2500))
    def f(z):return 8*n*(z/n).exp()*(z/B).log()/(z*z)
    def g(z):return (z/n-2)*(z/B).log()+1
    assert B>0 and B<2*n and 2*n<end
    saved_contains(row['B_min'],B);saved_contains(row['L_upper'],end)
    saved_contains(row['all_interval_max_f_less_than'],T)
    assert row['L_equals_B_f']=='0 exactly'
    assert row['near_B']['below_threshold'] and row['endpoint']['below_threshold']
    near=B*ball(Q(1000001,1000000));near_f=f(near);end_f=f(end)
    assert B<near<end and 0<near_f<T and 0<end_f<T
    saved_contains(row['near_B']['L'],near);saved_contains(row['near_B']['f'],near_f)
    saved_contains(row['endpoint']['f'],end_f)
    saved_contains(row['g_at_B'],g(B));saved_contains(row['g_at_2n'],g(2*n))
    assert g(B)>0 and g(2*n)>0
    crit=[];previous=None
    for idx,c in enumerate(row['critical']):
        assert c['root']==idx+1 and c['below_threshold']
        lq=Q(c['lo_rational']);hq=Q(c['hi_rational'])
        assert lq<hq and lq<Q.from_float(c['scipy_estimate'])<hq
        l=ball(lq);h=ball(hq);hull=l.union(h)
        assert hull.contains(exactq(lq)) and hull.contains(exactq(hq))
        assert B<l<h<2*n
        if previous is not None:assert previous<l
        previous=h
        gl=g(l);gh=g(h)
        assert ((gl>0 and gh<0) if idx==0 else (gl<0 and gh>0))
        saved_contains(c['g_left'],gl);saved_contains(c['g_right'],gh)
        fh=f(hull)
        assert 0<fh<T
        # Confirms author printed f interval encloses a fresh rigorous evaluation
        # of the entire rational bracket, not just its floating candidate root.
        saved_contains(c['f_enclosure'],fh)
        # Reconstruct only the producer's 192-bit interval constructor to check
        # that its midpoint/radius ball includes BOTH exact decimal endpoints.
        ctx.prec=192
        al=arb(c['lo_rational']);ah=arb(c['hi_rational'])
        author_box=arb((al+ah)/2,(ah-al)/2)
        assert author_box.contains(exactq(lq)) and author_box.contains(exactq(hq))
        ctx.prec=256
        source_box_pass+=1
        crit.append({'root':idx+1,'left_exact':str(lq),'right_exact':str(hq),'g_left_independent':str(gl),'g_right_independent':str(gh),'independent_bracket':str(hull),'f_whole_bracket_independent':str(fh),'saved_enclosures_contain_independent_checks':True,'source_192bit_box_contains_exact_endpoints':True,'inside_B_to_2n':True})
        all_f.append((nv,'critical'+str(idx+1),fh))
    assert len(crit)==2
    # g''(L)=1/(nL)+2/L^2>0, hence at most two roots. These two
    # sign-changing disjoint brackets give exactly two. For L>=2n,
    # (L/n-2)log(L/B)>=0 so g(L)>=1; there are no later roots.
    # f'(L)=8n exp(L/n)g(L)/L^3, so endpoints and these roots cover max f.
    all_f.extend(((nv,'near_B',near_f),(nv,'right_endpoint',end_f)))
    data.append({'n':nv,'B_worst':str(B),'L_upper':str(end),'domain_B0_lt_2n_lt_upper':True,'B_endpoint_f':'0 exactly','B_endpoint_g':str(g(B)),'g_at_2n':str(g(2*n)),'near_B_L':str(near),'near_B_f':str(near_f),'upper_endpoint_f':str(end_f),'critical':crit,'exactly_two_critical_roots':True,'all_L_and_permitted_B_certified_for_this_n':True,'threshold_exact':'2401/2500'})
# Select the largest upper bound, then prove it dominates every other ball.
worst=max(all_f,key=lambda z:float(z[2].upper()))
assert worst[:2]==(256,'right_endpoint')
assert all(v<worst[2] for nn,name,v in all_f if (nn,name)!=worst[:2])
assert all(v<ball(Q(929,1000)) for nn,name,v in all_f)
assert raw['worst_scipy']['n']==256 and raw['worst_scipy']['point']=='end'

# Record an actual independent exact run of the elementary constants named in
# GLOBAL_ALLOCATION.md. This is not evidence of any earlier author tool run.
def exp_degree32(x):
    x=Q(x);assert 0<x<34
    term=Q(1);lo=term
    for k in range(1,33):
        term=term*x/k;lo+=term
    tail=(term*x/33)/(1-x/34)
    return lo,lo+tail
constant_specs=[('e<25/9, hence sqrt(e)<5/3',Q(1),'upper<',Q(25,9)),
                ('log(16/5)<6/5',Q(6,5),'lower>',Q(16,5)),
                ('11/4<log16',Q(11,4),'upper<',Q(16)),
                ('log16<14/5',Q(14,5),'lower>',Q(16)),
                ('log(896/25)<18/5',Q(18,5),'lower>',Q(896,25))]
constants=[]
for statement,x,sense,bound in constant_specs:
    lo,hi=exp_degree32(x)
    assert (hi<bound if sense=='upper<' else lo>bound)
    constants.append({'statement':statement,'exp_argument':str(x),'exp_lower_exact':str(lo),'exp_upper_exact':str(hi),'comparison':sense+str(bound),'pass':True})
assert Q(576,605)<Q(2401,2500)
r1=resource.getrusage(resource.RUSAGE_SELF)
out={'pass':True,'method':'independent 256-bit Arb full-bracket evaluation of all saved rational roots; exact Fraction Taylor bounds; no SciPy execution','dimensions':expected,'dimension_count':21,'root_brackets_checked':source_box_pass,'source_script_hash_matches':True,'source_precision_bits':192,'independent_precision_bits':256,'threshold_equivalence':'Phi<=-L/50 iff 2sqrt(2n exp(L/n)log(L/B))<=(49/50)L iff f<=2401/2500, since L>=B>0','monotonicity_in_B':'partial_B f=-8n exp(L/n)/(B L^2)<0','f_derivative':'partial_L f=8n exp(L/n) g(L)/L^3','g':'(L/n-2)log(L/B)+1','g_second_derivative':'1/(n L)+2/L^2>0','root_coverage':'exactly two roots inside (B,2n) from strict convexity and disjoint sign changes; g>=1 beyond 2n','results':data,'worst_certified':{'n':worst[0],'point':worst[1],'f':str(worst[2]),'every_f_upper_below_rational':'929/1000'},'taylor_checks':{'attribution':'independent audit actually executed; no earlier author execution inferred','earlier_author_execution_record_available':False,'degree':32,'summands':33,'tail_bound':'(x^33/33!)/(1-x/34)','constants':constants,'rational_final_comparison':'576/605 < 2401/2500'},'scope':'all permitted continuous B,L for these 21 integer n only; no all-n result inferred; no tensor-grid model implemented','versions':{'python':platform.python_version(),'python_flint':flint.__version__},'workers':1,'flint_threads':1,'blas_threads':1,'wall_seconds':time.monotonic()-start,'cpu_seconds':r1.ru_utime+r1.ru_stime-r0.ru_utime-r0.ru_stime,'command':'OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 /Users/zzh/.local/share/math-research-tools/venv/bin/python independent_numeric.py','hashes':{name:hashlib.sha256((P/name).read_bytes()).hexdigest() for name in ('NUMERIC.md','halo_check.py','halo_results.json','independent_numeric.py')}}
(P/'independent_numeric.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k not in ('results','taylor_checks')},indent=2))
