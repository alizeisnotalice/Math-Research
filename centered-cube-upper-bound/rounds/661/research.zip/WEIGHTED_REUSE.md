# R661 加权复用与真实高层双来源积分：未闭合记录

结论：本互补路线未证明 Σ_h e^(−B_h)U_h≤A U，也未证明新的全族近支付款。下面冻结失败的自动摊销步骤，并将唯一仍在使用的分析缺口精确限定为 actual high-admission、同一 blocking point 的有序非对角二阶预算。这个归约不算 √n 进展；没有用逐源费用帽、任意密度帽或新的 LP/Hall 条件代替缺口。

所有对象均为 TASK.md 的同一次实际 residual 构造。n≥256，a=32n，τ=8√n，q/tau 全族可行，F_i⊂E_i 真实不交，|F_i|=d_iq_i，U=Σ|F_i|，X_j=E_j\F_j。只对真实损失行选合法饱和点 z_j；不改 q、F 或 z 来拼接不同动作的量。

## 1. 加权复用不从逐 source 切树自动得到

若一个点簇共有实际来源 I，共同 load 为 T，B=T/c−1，c=(1+1/a)^n，其现有 lens 付款为 e^(−B)Σ_{i∈I}|F_i|。

按 source 顺序将簇切成下一 A_k 的内外两子簇，继承到两子的任一共同 F_i 会被计算两次。若两子簇相对父节点的共同 load 增量为 Δ_in、Δ_out，则该 F_i 的折扣总倍率严格为

    exp(−Δ_in/c)+exp(−Δ_out/c)。

仅有当前一行新变成内部子簇共同来源时，该倍率为

    1+exp(−q_k/c)>1。

而 q_k≤a^(−n)，所以不能把这种细分误当成有指数收缩的 Kraft/势能树。几何可能在某些批量分叉中迫使更多真实共同来源出现，但本工作没有证明这样的全族批量分叉规律。这里否定的是自动摊销论证，不是对 near 目标的反例。

逐源 Σ_{h:i∈I_h}e^(−B_h)≤A 是较强的充分条件，本工作没有无根据地要求它；总费用可以由不同来源之间的平均抵消来控制。

## 2. 未截断全空间平方预算已经关闭

令

    N(x)=sup_{r>0} sup_{||z−x||∞≤(1+1/a)r}
             Σ_{s_i≥r}q_i1_{A_i}(z)。

强式 ∫N²≤C nU 不成立。真实同半径 a^n 张量网格、F_i=B_i 铺一个 cube、q_i=a^(−n) 时，所有 q 都由实际递推保留，总 load≤1<τ，且

    ∫N²/U=[5/3+1/a+1/(3a²)]^n。

这与主代理独立计算一致。该家族没有实际损失，故只排除未截断的强式；不能据此否定高阈值 near 目标。以下始终保留实际损失和高负载 admission，不累计该低高度尾。

## 3. 便宜部分的全局付款

对每个 near 损失行 j，真实 near 来源为

    I_j={i:q_i>0,z_j∈A_i,s_j≤s_i<n s_j}，
    Σ_{i∈I_j}q_i>τ/2。

按以下三个真实条件分开 I_j：

- background：A_i⊃A_j；
- local crossers：A_i不包含A_j，且 |B_i∩B_j|>0；
- remote crossers：A_i不包含A_j，且 |B_i∩B_j|=0。

这只是同一行的来源分类，所有预算仍对全族求和。

设 b_j 为 background 的 q-load。若 b_j≥τ/8，则每个 x∈X_j⊂A_j 都有最终 h(x)=Σ_iq_i1_{A_i}(x)≥τ/8。由于损失 pieces 不交且 ∫h=U，此类 near owners 的总体积至多

    V_background≤8U/τ≤U/16。                       (BG)

local crossers 的 load 有已经复核的实际几何小界。令 β=(a+1)/(a−1)。若 s_i≥βs_j 且 receivers 正交，则 A_i包含A_j；所以非包含 local crossers 满足 s_j≤s_i<βs_j。其真实 F_i 全在

    Q(y_j,(2β+1)s_j/a)

内，且 d_i≥d_j。F_i 不交给

    Σ_local q_i≤η_n:=((2β+1)/a)^n。

n≥256 时 η_n<1≤τ/8。

令 J_h 为剩下的真实 near 损失行，即 b_j<τ/8。令 C_j 为其 remote crossers，R_j=Σ_{i∈C_j}q_i。于是

    τ/4<R_j≤τ，              j∈J_h。              (ADMIT)

每个 i∈C_j 严格早于 j：自身 j 属于 background，未来正 q 来源不含合法饱和点 z_j。

## 4. 保留共同 z 的精确有序双来源公式

在这些实际 admitted 损失 pieces 上定义

    E_h=Σ_{j∈J_h}|X_j| R_j²。

对 i,k 定义真实共同 admission 质量

    M_ik=Σ_{j∈J_h: i,k∈C_j}|X_j|。

每个被计入的 j 必须同时满足：

- i,k 是同一个实际 j 的 remote near crossers；
- 同一个 z_j 位于 A_i∩A_k；
- s_j≤min(s_i,s_k)≤max(s_i,s_k)<n s_j；
- 同一个实际 j 满足 ADMIT。

不能为 i 与 k 分别选不同 z，再把两个最大值相乘。有限展开严格得到

    E_h=Σ_i q_i² M_ii + E_off，
    E_off=2Σ_{i<k}q_iq_k M_ik
         =2Σ_k q_k Σ_{j∈J_h:j>k,k∈C_j}|X_j|
                        Σ_{i<k:i∈C_j}q_i。         (PAIR)

这是允许来源重复的全局积分顺序。它没有要求每个 i 的重复费用单独有界；只有全部实际来源的加权总和需要控制。

用任意 pair envelope (A_i∩A_k)+Q(0,c0 min(s_i,s_k)) 替换 M_ik，只能给粗上界，并会丢弃共同的高 admission。本文没有在该替换后无依据地宣称 Cn 界。

## 5. 对角可吸收；唯一未证步骤

q_i≤w_i≤a^(−n)，所以

    E_diag:=Σ_iq_i² M_ii
      ≤a^(−n)Σ_{j∈J_h}|X_j|R_j
      ≤a^(−n)τ V_h，

其中 V_h=Σ_{j∈J_h}|X_j|。由 ADMIT，E_h≥τ²V_h/16。因此

    E_diag≤(16a^(−n)/τ)E_h≤E_h/8，
    E_off≥7E_h/8。                                 (DIAG)

现在仅余以下一条尚未证明的全局几何估计：存在绝对 C，使对可选的实际 owners、tie order 和合法饱和点，PAIR 中保留共同 z 与真实 ADMIT 的量满足

    E_off≤C n U。                                   (OPEN)

若 OPEN 成立，DIAG、τ²=64n 与 BG 精确给

    V_h≤(2C/7)U，
    V_near≤(1/16+2C/7)U。

这提供 OPEN 的明确用途。它不是已经证明的结果，也不是新根阶估计。由于 ADMIT 把 E_h 与 V_h 在常数倍 τ² 内联系，单把 near 目标改写为 OPEN 本身并不构成推进；需要额外的共同 z 方体乘积控制才能真正完成。

本路线尚未给出该控制。尤其没有证明逐 source 细分的共享容量会收缩，也没有将低高度的全空间 L² 界偷换成高层界。按任务范围在这一准确的非对角缺口停止，等待进一步分配。

## 6. 实际复核

本机指定数学 Python/SymPy 实际核验：高层非对角预算至 V_h 的精确常数为2/7；n=256时 background 常数为1/16；网格的未截断因子化简为(5a²+3a+1)/(3a²)。这些只是代数 sanity checks，证明是上述同一次对象的有限展开及真实 owner 积分。未进行扫描、重复重计算、Git 写入或修改他人文件。
