from pathlib import Path
import argparse,ast,hashlib,json,re,shutil,subprocess,sys
p=argparse.ArgumentParser()
p.add_argument("--replay",action="store_true")
p.add_argument("--workdir")
args=p.parse_args()
base=Path(__file__).resolve().parent
m=json.loads((base/"manifest.json").read_text())
for name,r in m["files"].items():
    data=(base/name).read_bytes()
    assert len(data)==r["bytes"] and hashlib.sha256(data).hexdigest()==r["sha256"],name
    if name.endswith(".py"):ast.parse(data,filename=name)
stack=[]
for kind,env in re.findall(r"\\(begin|end)\{([^}]+)\}",(base/"REPORT.tex").read_text()):
    if kind=="begin":stack.append(env)
    else:assert stack and stack.pop()==env,(kind,env)
assert not stack
report_hash=m["files"]["REPORT.tex"]["sha256"]
assert report_hash in (base/"FINAL_REVIEW.md").read_text()
out={"hashes":len(m["files"]),"syntax":"pass","tex_environment_pairs":"pass; no compilation","report_review_binding":report_hash}
if args.replay:
    assert args.workdir,"Explicit new workdir required"
    dest=Path(args.workdir).resolve()
    assert not dest.exists(),"Use a new directory; do not overwrite earlier evidence"
    dest.mkdir(parents=True)
    for name in ["NUMERIC.md","halo_check.py","halo_results.json","independent_numeric.py"]:shutil.copy2(base/name,dest/name)
    run=subprocess.run([sys.executable,str(dest/"independent_numeric.py")],cwd=dest,text=True,capture_output=True)
    (dest/"replay_stdout.txt").write_text(run.stdout)
    assert run.returncode==0,run.stderr
    orig=json.loads((base/"independent_numeric.json").read_text())
    new=json.loads((dest/"independent_numeric.json").read_text())
    excluded={"wall_seconds","cpu_seconds","versions","command"}
    assert {k:v for k,v in orig.items() if k not in excluded}=={k:v for k,v in new.items() if k not in excluded}
    out["replay"]={"pass":True,"dimensions":new["dimension_count"],"critical_brackets":new["root_brackets_checked"],"taylor_constants":len(new["taylor_checks"]["constants"]),"precision":new["independent_precision_bits"],"wall_seconds":new["wall_seconds"],"cpu_seconds":new["cpu_seconds"]}
print(json.dumps(out,ensure_ascii=False,indent=2))
