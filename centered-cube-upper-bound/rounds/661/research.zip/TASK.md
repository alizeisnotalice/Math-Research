# R661 frozen global near-allocation task, 2026-11-15

User's adopted guide: pure C_n<=K sqrt(n), arbitrary L1, all positive scales, fixed Lebesgue background. R660 is independently audited and pushed as 06d23100176b9112dac27fa36f3731ceaa412b2d. No general dimension bound is proved.

## Full object (do not shrink the input)
For every finite family A_j=Q(y_j,s_j) in R^n, a=32n, B_j=A_j/a, d_j=(2s_j)^n, V=|union B_j|, define P=max sum d_j theta_j subject to theta>=0 and sum theta_j 1_Aj<=1 a.e.
Established finite recovery: C_n<=sup V/P<=exp(1/32)C_n.
Choose real disjoint full owners E_j subset B_j; sort s nonincreasingly (ties free). w_j=|E_j|/d_j. For one tau>0 recursively q_j=min(w_j,(tau-esssup_Aj sum_{i<j}q_i1_Ai)_+). Real retained pieces F_j subset E_j have |F_j|=d_j q_j; losses X_j=E_j\F_j. U=sum |F_j|. All have the same actual solution and Lebesgue geometry. P>=U/tau. Arbitrary input f is NOT assumed bounded by 1.

For each q_j<w_j choose z_j in A_j away from all faces where the COMPLETE retained prefix INCLUDING j has load tau. No future positive-q A_i contains z_j. Thus all active containing sources have s_i>=s_j. Far if sum_{s_i>=n s_j,z_j in Ai}q_i>=tau/2, near otherwise.
PROVED for every such finite family:
V=U+V_far+V_near; V_far<=2 exp(33/32) U/tau.
Near I_j={i:q_i>0,z_j in Ai,s_j<=s_i<n s_j} has sum q_i>tau/2.

## One accurate unresolved target
For n>=256 and tau=8 sqrt(n), prove existence of owners, radius ties and legitimate saturation points with V_near<=A U, absolute A; or replace the actual common-weight construction by an explicitly stronger feasible one and prove V<=K sqrt(n)P for all finite families. This sufficient target is not assumed true. All attempts must use general geometry and retain cross-group source costs, not yield another LP-equivalence as claimed progress.

## Available proved shared-source geometry
If one source subfamily (or genuine allocated subpieces) F_i supports every point of finite Z, radii r<=s_i<=nr, real pieces globally disjoint, set c=(1+1/a)^n, U_Z=sum |F_i|, T_Z=sum |F_i|/d_i, B=T_Z/c-1, L=log(U_Z/(c(2r)^n)).
Every target parent radius<=r attached to one point of Z has receiver union W_Z<=U_Z exp(-L+exp(L/n)log(L/B)).
If n>=16 and 2log n<=B<=n/2, full permitted B<=L<=nlog n yields W_Z<=exp(-B)U_Z.
Proof uses cumulative product lens H(s)<=prod_k[2(1+1/a)s-Delta_k]_+ and real receiver disjointness, not density caps on arbitrary sources.
This bound pays ONE shared source group. Intersecting different I_j may destroy load. Summing the same F_i across groups is unpaid. Weighted reuse is allowed only with an actual bound on its total charge.

## Known obstacles / stop rules
Old raw-prefix load replaced by actual retained load in R660, already done; no repeat.
Same-price logarithmic cover rewrite dominated by linear budget (R659), source-only variation at fixed geometry changes no free-action gain.
Old threshold breakpoints need not contain new optimum.
Few-label high-dimensional numerical checks are automatically non-extremal: V/G<=m(32n)^(-n). No root-order inference from them.
Single clique, fixed scale, pairwise lens, arbitrary incidence hypergraph, or conditional grouping alone does not close the target. Retain real cubes, genuine full receivers, and same final packing weights.

## Collaboration and files
Work directory only /Volumes/data/CodexTemp/centered-cube-r661-20261115; no Git by subagents. You are not alone: own only assigned files and do not overwrite others. Relevant R660 main proof at ../centered-cube-r660-20261115/REPORT.tex, 3 main propositions; avoid rereading all history.
Independent start, deliver decisive formula first; exchange only after first independent finding. Audit starts with statement and quantifiers. Stop after bounded delivery and await reassignment.
All computation shares NUMERIC.md; no independent expensive scan. Only run math relevant to a concrete proof decision. Main agent owns final report and integration.
