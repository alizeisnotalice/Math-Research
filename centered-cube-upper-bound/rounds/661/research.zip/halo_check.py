import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[k]='1'
import time,json,platform,hashlib,math
from pathlib import Path
import numpy as np,scipy,sympy as sp,flint
from scipy.optimize import brentq
from flint import arb,ctx
ctx.prec=192;ctx.threads=1
P=Path(__file__).parent
n,B,L=sp.symbols('n B L',positive=True);f=8*n*sp.exp(L/n)*sp.log(L/B)/L**2;g=(L/n-2)*sp.log(L/B)+1
syms={'f_B_derivative':str(sp.diff(f,B)),'f_L_factor_identity':str(sp.simplify(sp.diff(f,L)-8*n*sp.exp(L/n)*g/L**3)),'g_L_second_derivative':str(sp.simplify(sp.diff(g,L,2))),'candidate_f_threshold':'2401/2500'}
assert sp.simplify(sp.diff(f,B)+8*n*sp.exp(L/n)/(B*L**2))==0
assert sp.simplify(sp.diff(f,L)-8*n*sp.exp(L/n)*g/L**3)==0
assert sp.simplify(sp.diff(g,L,2)-(1/(n*L)+2/L**2))==0

def check(N):
 b=2.5*math.sqrt(N);end=N*math.log(N); G=lambda x:(x/N-2)*math.log(x/b)+1; F=lambda x:8*N*math.exp(x/N)*math.log(x/b)/x**2
 grid=np.geomspace(b,end,1000);roots=[brentq(G,float(x),float(y),xtol=1e-10) for x,y in zip(grid[:-1],grid[1:]) if G(x)*G(y)<0];assert len(roots)==2
 an=arb(N);ab=arb(5)*an.sqrt()/2;ae=an*an.log();threshold=arb(2401)/2500
 def ag(x):return (x/an-2)*(x/ab).log()+1
 def af(x):return 8*an*(x/an).exp()*(x/ab).log()/x**2
 data=[]
 for idx,r in enumerate(roots):
  # rational outward endpoints, with width generous against float root error
  lo=math.floor(r*1e7)/10**7-1e-7;hi=math.ceil(r*1e7)/10**7+1e-7
  l=arb(str(lo));h=arb(str(hi));gl=ag(l);gh=ag(h)
  assert (gl>0 and gh<0) if idx==0 else (gl<0 and gh>0)
  z=arb((l+h)/2,(h-l)/2);value=af(z)
  assert value<threshold
  data.append({'root':idx+1,'scipy_estimate':r,'lo_rational':str(lo),'hi_rational':str(hi),'g_left':str(gl),'g_right':str(gh),'f_enclosure':str(value),'below_threshold':value<threshold})
 near=ab*(1+arb(1)/10**6);vn=af(near);ve=af(ae);assert vn<threshold and ve<threshold and ag(ab)>0 and ag(2*an)>0
 return {'n':N,'B_min':str(ab),'L_upper':str(ae),'L_equals_B_f':'0 exactly','near_B':{'L':str(near),'f':str(vn),'below_threshold':vn<threshold},'critical':data,'endpoint':{'f':str(ve),'below_threshold':ve<threshold},'g_at_B':str(ag(ab)),'g_at_2n':str(ag(2*an)),'scipy_values':{'critical':[F(x) for x in roots],'endpoint':F(end)},'all_interval_max_f_less_than':str(threshold),'root_count_evidence':'g strictly convex, g(B)>0, g(2n)>0, two disjoint sign-change brackets inside (B,2n): exactly two roots; g strictly increasing beyond 2n.'}
if __name__=='__main__':
 t=time.monotonic(); dims=sorted(set([256,257,511,512,1000,10000]+[2**i for i in range(10,25)]));out=[check(i) for i in dims];best=max(((x['n'],name,val) for x in out for name,val in [('end',x['scipy_values']['endpoint'])]+[(f'critical{j+1}',v) for j,v in enumerate(x['scipy_values']['critical'])]),key=lambda z:z[2]); result={'task':'R661-HALO-01','symbolic':syms,'results':out,'worst_scipy':{'n':best[0],'point':best[1],'f':best[2]},'precision_bits':ctx.prec,'versions':{'python':platform.python_version(),'numpy':np.__version__,'scipy':scipy.__version__,'sympy':sp.__version__,'flint':flint.__version__},'wall_seconds':time.monotonic()-t,'max_workers':1,'command':'OPENBLAS_NUM_THREADS=1 /Users/zzh/.local/share/math-research-tools/venv/bin/python /Volumes/data/CodexTemp/centered-cube-r661-20261115/halo_check.py','sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'scope':'finite-dimensional interval certificates; not an all-n proof'};(P/'halo_results.json').write_text(json.dumps(result,indent=2)+'\n');print('cases',len(out),'worst',best,'threshold',2401/2500,'wall',result['wall_seconds'])
