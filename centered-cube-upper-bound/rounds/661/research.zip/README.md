# R661 research and verification package

Status: general pure C_n <= K sqrt(n), and the prior general target, remain unproved. REPORT.tex contains the complete proof and cost ledger. The new group theorem allows different targets to share different source subsets with one anchor; it does not construct a globally payable anchor family. Fragmented load and cross-anchor source costs remain explicit.

Files:
- REPORT.tex: final self-contained main argument, exact missing step, finite numerical scope.
- GLOBAL_ALLOCATION.md: author proof, causal selection, L1 parallel-body mechanism, later-supplied author arithmetic record.
- AUDIT.md and FINAL_REVIEW.md: independent statement/proof and final integration reviews.
- NUMERIC.md: unexecuted tensor-grid design (clearly marked), then the actually executed scalar experiment.
- halo_check.py/results.json: SymPy/SciPy plus 192-bit Arb at 21 dimensions and 42 critical roots.
- independent_numeric.py/json and AUDIT_NUMERIC.md: independent 256-bit Arb full-bracket recheck and exact Fraction constants; no SciPy rerun. For each of the 21 dimensions the derivative/root-count and B-monotonicity argument certifies the full permitted continuous B,L domain. It is not an all-dimension computation or a cube-family realization.
- L2_SOURCE.md: original Bourgain theorem and restricted frozen-adjoint consequence, not a nontangential endpoint theorem.
- AUGMENTATION.md and WEIGHTED_REUSE.md: bounded failure records retained to prevent rerunning unchanged reductions; neither is claimed to close the budget.

Original numerical environment:
 /Users/zzh/.local/share/math-research-tools/venv/bin/python
 Python 3.12.14; NumPy 2.5.4; SciPy 1.18.1; SymPy 1.14.0; python-flint 0.9.0.
The independent replay requires only Python and python-flint. Actual frozen scripts set BLAS threads to 1, and use one worker. No PDF was compiled, no sustained full-CPU run is claimed, and no billing/credit consumption data was provided.

Verify hashes, Python syntax, TeX environment pairing and final review binding:

    python verify.py

Replay all 42 independent Arb brackets and the rational constants without modifying the archive:

    python verify.py --replay --workdir /Volumes/data/CodexTemp/centered-cube-r661-replay

Use a new, nonexistent directory. The verifier compares all mathematical records and provenance hashes while excluding run-specific timings, version and command fields. It does not rerun the SciPy search or the unimplemented tensor-grid model. The arithmetic proof is fully finite and uses degree 32 with 33 summands including k=0.

At the time of the independent numerical run, the author's earlier Taylor command/output had not yet arrived, so its JSON retains earlier_author_execution_record_available=false. The author subsequently added its own separate execution transcript to GLOBAL_ALLOCATION.md section 10. The independent run and its certificate remain independently attributed; this is a timestamped provenance boundary, not a mathematical discrepancy.

To rerun halo_check.py itself, copy the archive into another workdir first; the producer writes an adjacent result file and new runtime metadata will change its hash. Keep original certificates intact. The mathematical all-n statement rests on the proof and independent review, not extrapolation from the 21 dimensions.
