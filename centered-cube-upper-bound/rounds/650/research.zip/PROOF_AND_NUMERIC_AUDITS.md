# Source audit: SCORE_INDEPENDENT_AUDIT.md

# R650 independent score-recovery audit — checkpoint before author

If a successor-closed same-epsilon class has finite ratio supremum T and epsilon T=4, and 0<=H/M<=kappa<=4 throughout that class, then F=R-LH/M lies between R-4L and R. Therefore sup F is at least T-4L; a near-maximizer of F has R at least T-4L minus its score tolerance. If T>64L this places such states in the critical kappa band for sufficiently small tolerance. This is a score-supremum argument, not an attained extremizer assumption.

The gain identity suggested by Gamma requires the next score penalty to be controlled by the actual chosen near-minimizing source LP, with all normalizing factors and epsilon fixed. This and epsilon calibration/successor-class recovery remain to be checked against exact definitions. No unconditional general bound is certified.

## Final verdict: valid conditional reduction, not a general proof

The proposed score bridge is valid with the following precise qualifications:

1. Calibrate the RAW ratio supremum on the exact same epsilon-independent, at-most-N, full-ownership class used for all old and normalized successor states.
2. Take the score supremum over ALL states and actual AC sources in that class, not only critical states.
3. Require a positive margin uniform over old states in that fixed calibrated class (or a proved near-score-max margin dominating the near-max tolerance). Pointwise unquantified positivity is insufficient.
4. Include actual E-priority ownership, zero-owner deletion, actual-alpha source selection, and same-epsilon geometric normalization in the assumed legal successor statement.
5. If a proof imposes an additional old threshold H0>=H_*(n), the conclusion includes that threshold: a bound of order max(64L,16H_*), not automatically 64L. Uniform root order needs H_*=O(L).

Under the clean claim with L>=1 and no extra threshold, a margin Gamma>=delta Q' on all critical old states DOES imply the calibrated T_N<=64L. A sufficient expected margin E Gamma>=delta M gives the same conclusion. The unproved full-action margin is the essential remaining condition. No such margin is established by this audit, the source LP alone, or the existing terminal inequalities.

## Exact class and fixed-epsilon calibration

Let C_N contain genuine positive-radius cube families with at most N retained positive-owner labels, actual measurable full receiver-ownership partitions, their entropy optimizers at parameter e, and any actual AC KKT sources. The geometry/ownership choices defining the class must be independent of e. Source choice affects H but not the raw ratio R_e=V/Q_e. At e=0 use the linear optimum VALUE Q_0; there is no need for a positive or unique optimizer at zero.

I actually read the finite-parameter proof in /tmp/ccu_r642_final/REPORT.tex and the full-owner recalibration paragraph in /tmp/ccu_r644_final/REPORT.tex, rather than treating the citations as automatic permissions. Their finite estimates apply to this exact class because they require only v_j>0, v_j<=d_j/a^n, a finite packing polytope containing all coordinate unit vectors and a strictly positive vector. Every member of C_N meets these conditions. For a fixed geometry/ownership:

    0<=Q_{e1}-Q_{e2}<=(e2-e1)V for 0<=e1<e2,
    Q_e/V>=a^n/N.

For positive parameters the two supporting-gradient tests give X<=V+Delta/e1 and Y<=V-Delta/e2 with XY>=V^2, implying Delta<=(e2-e1)V. At zero, test a linear optimizer against the positive-parameter gradient to get Q_0-Q_e<=eV. The finite-N lower bound follows by sending e to infinity to the unique positive log-only optimizer gamma, whose coordinate-unit comparison gives gamma_j>=v_j/V; then Q_e>=d dot gamma>=a^n V/N. These arguments do not need an ordered ownership rule, full geometric compactness, or a maximizer over geometry.

Therefore, for A_N(e)=inf_{C_N}Q_e/V and T_N(e)=1/A_N(e),

    a^n/N<=A_N(e)<=a^n,
    0<=A_N(e1)-A_N(e2)<=e2-e1.

The upper bound comes from the one-label full receiver, which belongs to every at-most-N class with N>=1. Thus e T_N(e)=e/A_N(e) is continuous and strictly increasing from zero to infinity. There is a unique fixed epsilon_N>0 with epsilon_N T_N(epsilon_N)=4. This is a single class-wide choice, not a new parameter after source selection, label deletion, or an outcome.

The same estimates give T_N(0)<=T_N(epsilon_N)<=5T_N(0). The equality of ordered/full-ownership suprema at e=0 is valid by ordering a fixed receiver family and deleting zero-increment labels without changing its union; the retained linear packing optimum cannot exceed the original one. This does not assert equality of the DIFFERENT positive-epsilon ownership-class suprema. Recalibration on C_N is necessary.

## Bounded score and recovery of the old critical band

Write T=T_N(epsilon_N), epsilon=epsilon_N, and L=L_n>=1 deterministic for the entire step and class. The row averages h_j lie in [0,1]. Therefore, in every actual class state, not just the critical branch,

    0<=H=(1+kappa)epsilon sum_j v_j h_j
       <=(1+kappa)epsilon V=kappa M,
    kappa=epsilon R<=epsilon T=4.

For F=R-LH/M and Sigma=sup_{C_N, actual AC sources} F,

    R-4L<=F<=R,
    T-4L<=Sigma<=T.

The supremum is finite, and for every eta>0 there exists an ACTUAL state and an ACTUAL AC source with F>Sigma-eta. No outer geometry/source attainment is used.

For such a state,

    R>T-4L-eta,
    4-epsilon(4L+eta)<kappa<=4.

If T>64L, choose eta sufficiently small that epsilon(4L+eta)<1/4. Then kappa>15/4, hence within [7/2,4], and R>1. The latter uses L>=1 (or another explicit size condition), not calibration alone. The wider [7/2,4] window already follows when T>32L with room for eta. One must choose eta after the fixed-class positive margin is known; its existence is allowed because all the required positive windows are fixed numbers for this class.

A score-near-max state need NOT be arbitrarily raw-ratio-near-max. Only T-R<4L+eta follows. Thus the older estimate D<=eta Q' from raw-R near extremality cannot be reused here. The direct raw bound is only D<=(4L+eta)Q'. An attempted Gamma proof requiring D=o(Q') at these score states has not supplied the claimed reduction.

## Exact next score and AC near-minimum source

Use the actual same-epsilon action and E-priority full ownership, delete precisely genuine zero owners, and recompute actual alpha. Normalize the entire new geometry and the actual source by the inherited common factor. Then

    M_next=Q'>0,  R_next=W/Q',  kappa_next=epsilon W/Q'.

The actual next H is epsilon sum_k p_k h'_k. There is NO additional factor (1+kappa')^(-1) in this H: it cancels between its defining (1+kappa') and normalized owner volume p_k/(1+kappa'). With the stated G_src, H_next=integral G_src dmu'. This is different from the earlier Z_next source moment and must not inherit its normalization factor.

The exact score identity is

    Q'[F_next-F_old]
       =D+L(Q'/M)H-LH_next.

The actual source LP permits, for each tau>0, an actual AC source with

    H_next<=Phi_H+tau M',  M'=(1+kappa')Q'.

Define Gamma=D+L(Q'/M)H-LPhi_H. Then

    Q'[F_next-F_old]>=Gamma-Ltau(1+kappa')Q'.

This preserves the unnormalized M' tolerance factor. There is no boundary atom, no AC minimizer assumption, and no tau=0 substitution. Since the successor belongs to C_N, calibration gives kappa'<=4; no lower bound on kappa' is needed. Supremum comparison is legitimate because Sigma is over the whole class, including low-kappa successors.

If Gamma>=delta Q' with a state-uniform delta>0, choose tau<delta/[2L(1+kappa')]. Then F_next-F_old>delta/2. Taking eta<delta/2 contradicts F_old>Sigma-eta and F_next<=Sigma. This proves T<=64L under the clean stated hypothesis. A delta depending on fixed n,N,epsilon is sufficient; delta must not shrink unpredictably with the particular old near-max state. The final bound does not contain delta because eta and tau can be arbitrarily small ACTUAL approximation tolerances.

Pointwise Gamma>0 with no usable uniform margin does not imply the contradiction. Abstractly, scores 1-1/j can have strictly improving successors j+1 with gain 1/[j(j+1)] while their unattained supremum remains one. This is an illustration of the quantifier issue, not an actual cube counterexample.

## Expected margin: deterministic extraction avoids a source kernel

Fix ONE old near-score-max state and its ONE chosen actual feasible weighted-optimal assignment/product anchor law. Suppose the actual E-priority ownership and source-LP value define a measurable integrable Gamma and

    E Gamma>=delta M.

For any 0<delta'<delta, if Gamma<=delta' Q' almost surely, then E Gamma<=delta' E Q'<=delta'M<delta M, a contradiction. Thus a positive-probability set of actual outcomes satisfies Gamma>delta'Q'. Intersect it with the probability-one set on which the genuine action/ownership/KKT construction is valid and select ONE deterministic outcome there. Only AFTER fixing that outcome select its AC source with tau<delta'/[2L(1+kappa')]. This supplies the same strictly improving actual successor.

There is no need for a measurable family Z -> mu'_Z of near-minimizing AC sources or a measurable minimizer kernel over all actions. There is also no need to select actions or sources measurably as the OLD state varies: the proof uses one fixed near-max state and one successor. A direct pointwise-existence Gamma statement bypasses action-outcome measurability entirely.

What remains necessary for an EXPECTATION proof is a well-defined measurable law for the anchors, a measurable actual ownership selection, and measurable Gamma (including the actual-alpha LP value). These must be established by whichever proof asserts the expectation, or avoided by proving the pointwise-existence alternative. This audit does not silently grant them, and does not mislabel a global measurable AC-source kernel as unavoidable.

Integrability is harmless once these objects are measurable in the fixed finite state: anchors lie in a bounded finite old-cube union, radii t_js_j are fixed, so W is uniformly bounded over the action parameter box; Q'<=M; 0<=Phi_H<=M'=Q'+epsilon W; H is fixed. Hence Gamma is bounded by finite state-dependent constants. No uniform-in-state bound is needed for the expectation extraction.

## Zero owners, class closure, and restoration

Actual zero-owner labels are removed before logarithmic reoptimization; no fictitious 0/0 growth or source demand is assigned. The retained receivers cover the same entire receiver union by the actual E-priority rule. Their radius is rho_j before normalization, with cube volume m_j, and their scaled receivers retain the same a. Whole-geometry/source normalization carries packing constraints and multiplies both entropy objective parts by the same factor, so the same alpha is the actual same-epsilon optimizer. At most N labels remain. These facts give the required same-class successor closure. They do not erase old deleted-image contributions from Gamma's all-old derivation.

The near-minimizing AC-source construction is certified by /tmp/ccu_r649/GEOMETRY_LP_AUDIT.md: actual saturated positive-volume membership cells, exact moments and saturation, finite source LP, and tolerance tau M'. The extra source cost coefficient alpha_k u'_k/(1+u'_k) is nonnegative and bounded by alpha_k; the same finite-cell essential-infimum construction applies. Convex rectangle costs remain continuous on a fixed saturated cell. Exact AC attainment and uniform dual coefficients are not needed for the score contradiction; proving a Gamma margin by a dual certificate could of course need additional geometric estimates.

For original input restoration, once T_N(0)<=K_n uniformly in N, take nonnegative f in L1, threshold t>0, and a compact set of centers with centered-cube maximal average >t. Choose one strict averaging cube per center; its concentric 1/a receiver has that center in its interior. A finite receiver-interior subcover exists. Order the selected family, delete zero increments, and use actual positive full owners of the unchanged receiver union. For every packing beta,

    t sum_j d_j beta_j<=integral f sum_j beta_j 1_Aj<=||f||_1.

Thus t Q_0<=||f||_1 and the covering union has volume V<=K_n Q_0. Exhausting the strict superlevel by compact subsets gives the weak bound K_n||f||_1/t. This uses original f dx in the integral, never the auxiliary entropy source. There is no extra a^n loss because the chosen receivers already cover the selected centers. The finite calibration and full-owner class suffice; no attained extremizer or geometry/source limit is required for this direct all-actual-state route.

If an application imposes H0=(2P0 epsilon)^(-1)>=H_*(n), then H0=T/(8P0)>=T/16 for P0<=2. The contradiction only applies once T>max(64L,16H_*); harmless fixed size floors can also be included. Therefore H_*=O(L) is a real requirement for a root-order conclusion, unless the Gamma theorem removes that threshold. The author correctly records this qualification.

## Cleanup and R645 recovery are extra conditions for narrower proofs

I inspected the R645 strict-interior recovery statement and its explicit exclusions. It recovers actual W,Q',D with positive retained owners under its fixed-polytope/strict-action hypotheses; it does not automatically recover a newly source-dependent score H/M or the actual source-LP value Phi_H. A proof of Gamma only on cleaned, no-universal, tagged, or compactified states therefore needs additional score recovery, not merely the older D recovery.

Specifically a cleanup at an eta-near-score state must control F_clean>=F_old-zeta_clean and recover a successor score gain larger than eta+zeta_clean. A crude possible score change up to 4L in the critical band does not tend to zero with a deleted owner volume. A raw-R cleanup bound cannot be renamed an F cleanup bound. Likewise recovering a source-independent strict D margin does not recover H_next or a Phi_H margin without additional estimates on actual source costs.

There is no cleanup issue if the hypothesized Gamma theorem is proved directly for ALL actual critical states in C_N, including universal rows, contacts, arbitrarily small positive owners, and all allowed actual AC sources. The score-supremum proof then needs only actual states already supplied by the supremum definition. It cannot use an unfinished narrower theorem as that hypothesis.

## Comparison with the completed author audit and remaining dependencies

After the independent checkpoint, I read /tmp/ccu_r650/TARGET.md and the completed /tmp/ccu_r650/SCORE_RECOVERY_AUDIT.md. Their corrected reduction agrees with this audit: fixed exact class; epsilon calibrated to raw T; all-state Sigma; uniform old-state margin; next lower endpoint unnecessary; actual AC tolerance after selecting a favorable action; explicit additional H_* and cleanup requirements. No scope error was found in this corrected conditional version.

Verified inputs in this bounded audit: R642 finite-epsilon proof and its 0-to-positive comparison; R644 full-owner recalibration/zero-e class comparison; relevant R645 strict-interior recovery statement and its limitations; R649 finite-cell AC near-minimum construction as already independently proved. I did NOT re-audit the entire historical R645 cleanup ledger, every original-input compactness/contact reduction, the weighted half-action Gamma estimate, or a measurable-selection theorem for the full outcome-dependent alpha/LP map. The direct all-actual-state conditional theorem avoids the historical limiting bridge; any proof using that bridge must verify the extra score conditions above.

The true remaining condition is a uniform usable Gamma margin for the SAME legal action, E-priority owners, actual alpha and source LP, or a sufficiently strong near-score-max version. There is no proof here of this condition, no proof that the complete original full ledger supplies it, and no unconditional general upper bound.

## Executed mathematical-tool evidence

Ran the installed math Python /Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python with SymPy. The gain identity including the AC tolerance factor returned exact residual zero. At T=64L and eta=0, the algebraic critical lower endpoint is exactly 15/4. These are algebra checks supporting the argument; no numerical extremizer, propagation simulation, or new geometric construction was attempted.


---

# Source audit: JOINT_ALGEBRA_AUDIT.md

# R650 independent joint algebra audit

**Result: PASS for G1-G6 and SOURCE_JOINT J1-J4 after correction of the AC-tolerance mass bound. No positive joint Gamma budget has been proved.**

Scope: finite verification of the same-action full-score grouping, expectation direction, actual harmonic law pi, growth/source/copy signs and all-old deletion terms. The score-supremum sufficiency theorem is separately recorded in SCORE_RECOVERY_AUDIT.md and is not reproved here. I derived the basic score grouping, harmonic covariance split and source envelope from the frozen definitions before checking the author formulas.

Only this file is owned. No author file or completed report was changed.

## Issue found first and corrected by the author

The original LYAPUNOV_JOINT section 5 asserted

  M'<=M+eps sum ell_j=(1+kappa)M+eps Eold.

That derivation omitted fill: W=sum ell_j-O+F does not by itself give W<=sum ell_j. I reported the problem before finalizing this audit. The author has explicitly withdrawn the bound and its tolerance formula.

The corrected general estimate is

  M'=Q'+eps W
    <=(1+kappa)M+eps Eold+eps F.

It retains same-action fill and is not an old-data-only uniform bound. After the independent same-class calibration has established kappa'<=4, the valid stronger bound is M'=(1+kappa')Q'<=5M. A known expected Gamma margin m then survives tolerance tau<=m/(10LM), since L tau M'<=m/2. Without that calibration one can fix a favorable actual action first and use tau<=m_Z/(2LM'(Z)). This step pays only source approximation, not the unproved positive Gamma margin.

I reread and verified the corrected section 5. G1-G6 were unchanged.

## 1. Exact full-action groupings G1 and G2

Write zeta=L eps, theta=H/M, A_diag=sum_ALL a_j u_j k_j, and Xi=Phi_H-H_proto. The actual E-priority identity is

  H_proto=A_diag+eps sum_ALL(f_j-o_j)k_j.

Substituting D=Eold-O+F+RS and Q'=M-S into Gamma gives exactly

  Gamma=Eold+L(H-A_diag)
        +sum f_j(1-zeta k_j)-sum o_j(1-zeta k_j)
        +(R-Ltheta)S-LXi.

This is G1. With Theta=Xi-eps sum o_j k_j, the lost-copy terms collapse to -O-LTheta, giving G2. These are alternative groupings; adding them would duplicate the same source/lost-copy terms.

All sums in A_diag and the owner split are ALL old rows. For a deleted old label p=0, f=0 and o=ell, so a_j u_j k_j-eps o_j k_j=0. Its image loss is retained and cancels only through the exact owner identity. No undefined next u'=0/0 is introduced. The genuine new source/LP rows remain the retained positive-owner labels.

For 0<=zeta<=1, 1-zeta k_j lies in [1-zeta,1]. Also theta<=kappa and kappa=eps R give R-Ltheta>=R(1-zeta)>=0. This preserves a favorable S coefficient; it is not a second independent source reserve. Any later payment by S must consume the coefficient already displayed in this same ledger.

## 2. Actual harmonic probability and growth split G3

The old entropy identity gives sum v_j/u_j=V/kappa. Hence

  pi_j=kappa v_j/(u_j V)=lambda_j d_j/Q,
  sum pi_j=1, E_pi u=kappa.

All old v_j,u_j are positive. This is the actual fixed old-family probability, including rows later deleted; it is not an arbitrary stochastic model.

Set w_j=q(u_j)^2 h_j. Then

  Eold=(V/kappa)E_pi(u-kappa)^2,
  C_H=(eps V/kappa)E_pi[u(u-kappa)w].

Using u(u-kappa)=(u-kappa)^2+kappa(u-kappa) yields

  Eold-L C_H
    =(V/kappa)E_pi[(u-kappa)^2(1-zeta w)]
       -zeta V Cov_pi(u,w),

exactly G3. No absolute value is taken. With zeta<=1, the first term is at least (1-zeta)Eold, whereas only the positive covariance is unfavorable. The old harmonic centering is used with the correct weights.

This branch starts from the exact full D ledger and uses its raw old growth once. It does not also claim the R647 low-input residual or a separately spent reload/high-growth allowance as additional income. If those alternative derived budgets were combined later, their rows/fees would need reconciliation; none are added in G1-G6.

## 3. Expectation direction and the complete lower bound G4-G5

The one fixed uB-weighted minimizing assignment gives

  E A_diag<=H-D_H+C_H.

Since L>0, replacing A_diag in the NEGATIVE term -L E A_diag gives the LOWER bound L(D_H-C_H), which is the direction used in G4. All remaining ownership/source quantities stay under their true same-action expectations. The coefficient R-LH/M is fixed old-state data, so factoring it outside E S is valid without independence.

The gain term is L D_H=(zeta(1+kappa)V/kappa)E_pi[u(1-q^2)h]. Combining it with G3 yields precisely G4. In particular there is no duplicated fill, lost-copy, new-growth, or old-low payment. Xi remains signed and unbounded by the currently proved estimates.

G5 is correctly stated as a sufficient, UNPROVED combined geometric inequality for E Gamma>=m. Its left side retains the signed covariance and source/lost-copy terms. It is a rearrangement identifying the required sign, not a new paid budget. A useful global score contradiction additionally needs a margin of the type in SCORE_RECOVERY_AUDIT.md; arbitrary statewise positivity is not supplied here.

## 4. Same-source form G6

From h_j=m_j^(-1)int_Aj r_j^2 dmu, m_j=(1+u_j)d_j and pi_j=lambda_j d_j/Q,

  H/M=E_pi[u h],
  Cov_pi(u,w)
    =(1/Q)int sum_j lambda_j 1_Aj
       [(u_j-kappa)/(1+u_j)]q(u_j)^2 r_j^2 dmu.

These are G6, with the correct factor 1/(1+u_j). Removing the distance/q factor leaves total integral sum lambda_j d_j(u_j-kappa)=0. That centering does not determine the signed distance correlation. Its coefficient lies between -kappa and 1, but this range is not a sign theorem or a source-density cap.

## 5. SOURCE_JOINT calibration envelope J1-J4

Its J1 is the same G1 grouping and J2 is the same Theta grouping, with all old rows retained. They cannot be added as different credits.

The real source constraints imply 0<=Phi_H<=eps W: every actual admissible source has H_next=eps sum p_j h'_j<=eps W, and the LP infimum is no larger. This argument requires no AC minimizer attainment and no successor lower critical bound.

Using eps W=eps D+kappa Q', the exact envelope is

  Gamma=(1-zeta)D+LQ'(theta-kappa)
             +L(eps W-Phi_H).

The omitted final term is nonnegative. Thus J3 is correct. Since 0<=theta<=kappa and Q'<=M, J4 follows:

  (1-zeta)D-L kappa M<=Gamma<=D+L kappa M.

These inequalities preserve the sign of the genuine D; they do not prove a positive score increment. No kappa'>=7/2 assumption or score-near-max/raw-ratio-near-max confusion is inserted. SOURCE_JOINT explicitly retains that distinction.

## 6. Actual local checks and final scope

Used the installed local math Python with SymPy 1.14.0. Exact residuals for G1, G2, the pointwise polynomial underlying G3 and the source-envelope decomposition were all zero. Pi and G6 follow by the direct moment substitutions written above; no scan or geometric surrogate was used.

The corrected files provide an exact joint algebraic interface, with available coefficients when zeta is small. They do NOT prove G5, a source/collision/covariance payment, a state-uniform positive Gamma margin, or the general weak-type bound. This audit stops at that verified scope.


---

# Source audit: NUMERIC_REVIEW.md

# R650 independent review of the fixed-family ownership experiment

**Verdict: accepted finite evidence for a genuine ownership improvement of the same Gamma_L; no uniform global payment is established.** Stage 3 is stopped by root instruction. The executed scope is exactly ten one-dimensional ownership fixtures: three at zeta=1, three at zeta=3/4, one at zeta=1/2, and three at zeta=1/4. No larger scan was performed for this review.

The same C family is fixed in every comparison: centers +/-1/64, halfside 1, a=32, overlapping receivers of lengths 1/16, and W=3/32. Within each zeta comparison, epsilon, old R,M,H, E, and the symbolic coefficient L are fixed. The comparison is always
\[
\Gamma_L=D+L(Q'/M)H-L\Phi_H.
\]
The old state uses true smaller A with halfside 2/9, genuine disjoint old I, an AC source in two boxes, actual old KKT and a legal nonidentity half action. Old kappa=7/2 is retained, but old R=zeta/16<1. The anchors are fixed representatives from the minimizing assignment's support. This review makes no entire-product-law expectation claim and no complete hard-state claim.

## What the certificates establish

I read the ownership generator and geometric source engine, then independently parsed every interval of the recorded JSON without importing or calling the author's functions. For all ten fixtures the independent check recalculated:

- actual receiver/image memberships and E-priority eligibility on every positive-length interval;
- owner volumes p, lost-copy volumes o, fill volumes f, p=ell-o+f and total receiver coverage;
- actual alpha=p/W, saturated packing, equal positive entropy-gradient multipliers and exact next demands;
- source LP feasibility and exact primal/dual objective agreement;
- the explicit AC next source, its exact cost excess, and both ideal-source and actual-AC Gamma_L coefficients.

The exact endpoint-minus-midpoint coefficients are

| Fixed zeta fixture | Gain in the same Gamma_L |
|---|---:|
| 1 | L * 7/49152 |
| 3/4 | L * 7/147456 |
| 1/4 | L * 7/49152 |

At zeta=1/2, E-priority leaves no free ownership region, even though the B' receivers overlap. That negative control is retained. No owner is dropped, and the source LP uses the positive-volume common C intersection; no null contact is made into a source cell.

The common-cell source minimizer is `x_p=(p1*c1+p2*c2)/W`. A uniform AC source of total mass `m'=2+epsilon W` on `[x_p-1/1024,x_p+1/1024]` gives the exact actual next cost
\[
H_{next,AC}=\Phi_H+\epsilon W/(3\cdot1024^2).
\]
The error is identical across owners of the same fixture, so the actual-AC improvement equals the ideal LP improvement exactly. This is not a claim that an AC source attains the quadratic infimum.

The analytic gain formula is
\[
\Gamma_L(p)-\Gamma_L(W/2)
=L\epsilon\delta^2(p_1-W/2)^2/W.
\]
It proves a real ownership effect in this model and also displays its limitations: the gain can vanish as geometry or the admissible owner interval degenerates. It supplies neither a uniform positive increment for all families nor payment of the inherited complete target. At zeta=3/4 this one local transition even has D=S=E'=0 and old/new kappa=7/2, but R=3/64<1, so it is not a critical hard-state platform.

## Metadata correction

The first JSON named `zeta*s/32` as `old_receiver_halfwidth`. For zeta<1 that quantity is the half-length of the old **owned interval I**, whereas the true old receiver halfside is `s/32`. The execution owner was asked to preserve all numerical results, rename/add the two quantities correctly, and record E'=S=0 explicitly. This is a naming correction, not a change of geometry or outcomes. Final hashes below bind the corrected artifacts.

## Independent reproduction command and exact scope

The following command is the complete independent checker for the final results. It reads only the saved JSON, performs Fraction arithmetic and does not import any author module, mutate results, or rerun the entropy/source optimizer. The interpreter is the installed math Python 3.12.14. Its checks cover all ten recorded fixtures, not an extrapolation to any untested geometry.

```sh
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python - <<'PY'
from pathlib import Path
from fractions import Fraction as F
import json, hashlib, sys

root=Path('/tmp/ccu_r650/numeric')
data=json.loads((root/'results.json').read_text())
rows=data['fixtures']
assert len(rows)==10
W=F(3,32); delta=F(1,32)
centers=[-delta/2,delta/2]
receivers=[(x-F(1,32),x+F(1,32)) for x in centers]
byz={}
for r in rows:
    z=F(r['zeta']); eps=F(r['epsilon'])
    images=[tuple(map(F,q)) for q in r['image_intervals']]
    p=[F(0),F(0)]; lost=[F(0),F(0)]; fill=[F(0),F(0)]
    previous=None
    for seg in r['partition']:
        lo,hi=map(F,seg['interval']); assert hi>lo
        assert previous is None or previous==lo
        previous=hi; x=(lo+hi)/2
        b=[i for i,(a,b) in enumerate(receivers) if a<x<b]
        e=[i for i,(a,b) in enumerate(images) if a<x<b]
        assert b==seg['receiver_labels'] and e==seg['image_labels']
        owner=seg['owner']; assert owner in (e if e else b)
        p[owner]+=hi-lo
        for i in e:
            if i!=owner: lost[i]+=hi-lo
        if not e: fill[owner]+=hi-lo
    assert sum(p)==W and p==list(map(F,r['p']))
    assert lost==list(map(F,r['ownership']['lost']))
    assert fill==list(map(F,r['ownership']['fill_by_owner']))
    ell=list(map(F,r['ownership']['ell']))
    assert p==[ell[i]-lost[i]+fill[i] for i in range(2)]
    assert sum(lost)==F(r['ownership']['O'])
    assert sum(fill)==F(r['ownership']['fill'])
    alpha=[q/W for q in p]
    assert alpha==list(map(F,r['alpha'])) and sum(alpha)==1
    growth=[eps*p[i]/(2*alpha[i]) for i in range(2)]
    kprime=eps*W/2
    assert growth==[kprime,kprime]
    assert F(r['new']['E_prime'])==0 and F(r['new']['S'])==0
    mass=2+eps*W
    assert list(map(F,r['new']['demands']))==[mass,mass]
    for i in range(2): assert 2+eps*p[i]/alpha[i]==mass
    assert F(r['old']['old_receiver_halfwidth'])==F(2,9)/32
    assert F(r['old']['old_owned_halfwidth'])==z*F(2,9)/32
    xp=sum(p[i]*centers[i] for i in range(2))/W
    phi=eps*p[0]*p[1]*delta**2/W
    src=r['source']; assert F(src['phi'])==phi
    assert F(src['minimizer'])==xp
    cell=src['cells'][0]; cost=F(cell['cost'])
    assert cell['membership']==[0,1]
    assert list(map(F,cell['bounds'][0]))==[F(-63,64),F(63,64)]
    assert F(src['primal'][0])==mass and mass*cost==phi
    dual=list(map(F,src['dual']))
    assert sum(dual)<=cost and mass*sum(dual)==phi
    eta=F(src['ac_radius']); excess=eps*W*eta**2/3
    assert F(src['ac_mass'])==mass and F(src['ac_excess'])==excess
    assert F(src['ac_H_next'])==phi+excess
    assert all(abs(xp-c)+eta<1 for c in centers)
    H=F(r['old']['H']); oldR=F(r['old']['R'])
    assert F(r['gamma']['constant'])==W-2*oldR
    assert F(r['gamma']['L_coefficient'])==H-phi
    assert F(r['gamma']['actual_ac_L_coefficient'])==H-phi-excess
    byz.setdefault(z,[]).append(r)
for z,group in byz.items():
    if len(group)==3:
        mid=next(r for r in group if r['label']=='mid')
        base=F(mid['gamma']['L_coefficient'])
        acbase=F(mid['gamma']['actual_ac_L_coefficient'])
        gains=[F(r['gamma']['L_coefficient'])-base
               for r in group if r['label']!='mid']
        acgains=[F(r['gamma']['actual_ac_L_coefficient'])-acbase
                 for r in group if r['label']!='mid']
        assert gains==acgains and gains[0]==gains[1]>0
        print('same_Gamma_gain',z,gains[0])
    else:
        assert z==F(1,2) and len(group)==1
        assert F(group[0]['ownership']['free_length'])==0
print('PASS',len(rows),'exact fixed-family ownership certificates')
print('Python',sys.version.split()[0])
for name in ['ownership_experiment.py','results.json','source_engine.py']:
    print('SHA256',name,hashlib.sha256((root/name).read_bytes()).hexdigest())
PY
```

## Final binding

Final corrected artifact hashes and the actual independent command output are recorded below after the metadata correction. No Stage 3 or additional fixture is authorized by this review.

The displayed independent Python block was actually executed verbatim from this review against the corrected final JSON, using the installed interpreter. It returned:

```text
same_Gamma_gain 1 7/49152
same_Gamma_gain 3/4 7/147456
same_Gamma_gain 1/4 7/49152
PASS 10 exact fixed-family ownership certificates
Python 3.12.14
```

Final SHA-256 bindings:

- `numeric/ownership_experiment.py`: `83e6ef9160e95e39f0386364e7c5c938ca7d5effbddc326379aa1a2efc93a8c6`.
- `numeric/results.json`: `0df8616c63f7a307b679c96b807f10844f9897c2e063ed7b38ebfafc351cd94d`.
- `numeric/source_engine.py`: `3bbe3f458c9260d20e6f48ed3ca197b700f2443bd32f9984f3b318aba86c8914`.

The final check explicitly passed the corrected old receiver/owned-halfwidth metadata and the explicit new S=E'=0 fields. Corrections preserved all ten numerical outcomes and all three gain coefficients. This independent review did not rerun MATLAB, invoke the entropy optimizer, create additional fixtures, or execute Stage 3; any separately recorded MATLAB output belongs to its actual execution owner and is diagnostic floating evidence rather than this Fraction certificate.
