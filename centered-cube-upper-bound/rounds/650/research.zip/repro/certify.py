"""Independent exact-rational certificate checker for a fixed 1-D candidate.
See CERTIFICATE.md for schema and scope. No optimization or candidate generation.
"""
import json, sys
from fractions import Fraction as F

def q(x):
    if isinstance(x, bool) or isinstance(x, float):
        raise ValueError('only rational strings or integers accepted')
    return F(x)

def vec(a): return list(map(q, a))
def check(data):
    rows=data['rows']; N=len(rows)
    if not N: raise ValueError('empty rows')
    e=q(data['epsilon']); delta=q(data['delta'])
    if e<=0 or delta<=0: raise ValueError('epsilon and delta must be positive')
    c=vec([r['center'] for r in rows]); r=vec([r['radius'] for r in rows]); a=vec([r['alpha'] for r in rows]); p=vec([r['p'] for r in rows])
    if any(x<=0 for x in r+a) or any(x<0 for x in p): raise ValueError('radii and alpha must be positive, p nonnegative')
    # B' is explicitly supplied as a finite union of intervals for each row.
    owners=[]
    for i,row in enumerate(rows):
        intervals=[tuple(map(q,b)) for b in row['receiver_intervals']]
        if any(lo>=hi or lo<c[i]-r[i] or hi>c[i]+r[i] for lo,hi in intervals): raise ValueError('invalid receiver interval')
        if sum((hi-lo for lo,hi in intervals),F()) != p[i]: raise ValueError('receiver length differs from p')
        owners.extend((lo,hi,i) for lo,hi in intervals)
    owners.sort()
    if any(owners[j][1]>owners[j+1][0] for j in range(len(owners)-1)): raise ValueError('receiver interiors overlap')
    ends=sorted({c[i]+sgn*r[i] for i in range(N) for sgn in (-1,1)})
    boxes=[]
    for lo,hi in zip(ends,ends[1:]):
        x=(lo+hi)/2
        ids=tuple(i for i in range(N) if c[i]-r[i]<x<c[i]+r[i])
        load=sum((a[i] for i in ids),F())
        if load>1: raise ValueError('packing fails on positive-volume interval')
        boxes.append((lo,hi,ids,load))
    sat=[(lo,hi,ids) for lo,hi,ids,load in boxes if load==1]
    if not sat: raise ValueError('no saturated interval')
    d=[2*x for x in r]; m=[d[i]+e*p[i]/a[i] for i in range(N)]
    coef=[a[i]*e*p[i]/(a[i]*d[i]+e*p[i]) for i in range(N)]
    costs=[]; argmins=[]; lips=[]
    for lo,hi,ids in sat:
        A=sum((coef[i]/r[i]**2 for i in ids),F())
        B=sum((coef[i]*c[i]/r[i]**2 for i in ids),F())
        x=max(lo,min(hi,B/A)) if A else lo
        costs.append(sum((coef[i]*(x-c[i])**2/r[i]**2 for i in ids),F()))
        argmins.append(x)
        lips.append(sum((2*coef[i]*max(abs(lo-c[i]),abs(hi-c[i]))/r[i]**2 for i in ids),F()))
    z=vec(data['lp_primal']); y=vec(data['lp_dual']); lam=vec(data['entropy_multipliers'])
    if len(z)!=len(sat) or len(y)!=N or len(lam)!=len(sat): raise ValueError('witness dimensions mismatch')
    if any(v<0 for v in z+lam): raise ValueError('negative primal or entropy multiplier')
    if any(sum((z[j] for j,(_,_,ids) in enumerate(sat) if i in ids),F())!=m[i] for i in range(N)): raise ValueError('source demand mismatch')
    slack=[costs[j]-sum((y[i] for i in ids),F()) for j,(_,_,ids) in enumerate(sat)]
    if any(v<0 for v in slack): raise ValueError('source dual infeasible')
    primal=sum((z[j]*costs[j] for j in range(len(sat))),F()); dual=sum((y[i]*m[i] for i in range(N)),F())
    if primal!=dual: raise ValueError('source primal-dual gap nonzero')
    if any(sum((lam[j] for j,(_,_,ids) in enumerate(sat) if i in ids),F())!=m[i] for i in range(N)): raise ValueError('entropy KKT stationarity fails')
    # Uniform AC source on a subinterval within each cell, with distance <=delta
    # from its closure minimizer. Pick subinterval width <= min(delta, cell width).
    bound=sum((z[j]*lips[j]*min(delta,hi-lo) for j,(lo,hi,ids) in enumerate(sat)),F())
    print(json.dumps({'status':'exact certificate','rows':N,'packing':'all positive-volume membership intervals','receiver':'finite unions: included, disjoint, exact lengths','entropy_kkt':'exact; sufficient by concavity','source_phi':str(primal),'source_gap':str(primal-dual),'ac_cost_excess_at_most':str(bound),'delta':str(delta),'saturated_cells':[{'bounds':[str(lo),str(hi)],'membership':list(ids),'cost':str(costs[j]),'minimizer':str(argmins[j]),'lipschitz':str(lips[j]),'boundary_minimizer':argmins[j] in (lo,hi)} for j,(lo,hi,ids) in enumerate(sat)]},indent=2))

if __name__=='__main__':
    if len(sys.argv)!=2: raise SystemExit('usage: certify.py candidate.json')
    with open(sys.argv[1]) as fh: check(json.load(fh))
