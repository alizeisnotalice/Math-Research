function crosscheck(path)
% Independent floating diagnostic of a fixed candidate. Not a proof.
s=jsondecode(fileread(path)); rows=s.rows; n=numel(rows);
e=ratval(s.epsilon); centers=zeros(1,n); radii=centers; a=centers; p=centers; intervals=[];
for i=1:n
 centers(i)=ratval(rows(i).center); radii(i)=ratval(rows(i).radius);
 a(i)=ratval(rows(i).alpha); p(i)=ratval(rows(i).p);
 ri=rows(i).receiver_intervals; total=0;
 for j=1:numel(ri)
  pair=ri{j}; lo=ratval(pair{1}); hi=ratval(pair{2});
  assert(hi>lo && lo>=centers(i)-radii(i)-1e-10 && hi<=centers(i)+radii(i)+1e-10);
  total=total+hi-lo; intervals(end+1,:)=[lo,hi]; %#ok<AGROW>
 end
 assert(abs(total-p(i))<1e-9);
end
intervals=sortrows(intervals,1);
if size(intervals,1)>1, assert(all(intervals(1:end-1,2)<=intervals(2:end,1)+1e-10)); end
ends=unique([centers-radii,centers+radii]); costs=[]; member=[];
coef=a.*e.*p./(2*a.*radii+e.*p); demand=2*radii+e*p./a;
for j=1:numel(ends)-1
 lo=ends(j); hi=ends(j+1); mid=(lo+hi)/2;
 ids=abs(mid-centers)<radii; load=sum(a(ids)); assert(load<=1+1e-9);
 if abs(load-1)<1e-9
  A=sum(coef(ids)./radii(ids).^2); B=sum(coef(ids).*centers(ids)./radii(ids).^2);
  if A>0, x=max(lo,min(hi,B/A)); else, x=lo; end
  costs(end+1)=sum(coef(ids).*((x-centers(ids))./radii(ids)).^2); %#ok<AGROW>
  member(end+1,:)=ids; %#ok<AGROW>
 end
end
z=ratvec(s.lp_primal); y=ratvec(s.lp_dual); lam=ratvec(s.entropy_multipliers);
assert(numel(z)==numel(costs) && numel(y)==n && numel(lam)==numel(costs));
stationarity=member'*lam(:)-demand(:); demands=member'*z(:)-demand(:);
slack=costs(:)-member*y(:); gap=costs*z(:)-demand*y(:);
assert(all(z>=-1e-9) && all(lam>=-1e-9) && all(slack>=-1e-9));
assert(max(abs(stationarity))<1e-8 && max(abs(demands))<1e-8 && abs(gap)<1e-8);
fprintf('MATLAB %s: cells %d, phi %.16g, gap %.3g, max stationarity %.3g, max demand residual %.3g, min dual slack %.3g\n',version,numel(costs),costs*z(:),gap,max(abs(stationarity)),max(abs(demands)),min(slack));
end
function x=ratval(v)
if isnumeric(v), x=double(v); return; end
parts=split(string(v),'/'); x=str2double(parts(1)); if numel(parts)==2, x=x/str2double(parts(2)); end
end
function v=ratvec(in)
if isnumeric(in), v=double(in(:)); else, v=zeros(numel(in),1); for k=1:numel(in), if iscell(in), v(k)=ratval(in{k}); else, v(k)=ratval(in(k)); end, end, end
end
