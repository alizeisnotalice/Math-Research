from fractions import Fraction as F
import json
from pathlib import Path
from source_engine import solve_source

D=F(1,32); c=[-D/2,D/2]; B=[(x-D,x+D) for x in c]; W=F(3,32)
s=F(2,9); d=2*s; k=F(7,2); lam=F(1,2); h=D/8

def length(t): return t[1]-t[0]
def intervals(zeta, mode):
    E=[(x-zeta*D,x+zeta*D) for x in c]
    edges=sorted(set(sum(([a,b] for a,b in B+E),[])))
    chunks=[]; owners=[[],[]]; p=[F(0),F(0)]; lost=[F(0),F(0)]; fill=[F(0),F(0)]; free=F(0)
    for left,right in zip(edges,edges[1:]):
        mid=(left+right)/2
        covered=[j for j in range(2) if B[j][0]<mid<B[j][1]]
        if not covered: continue
        images=[j for j in range(2) if E[j][0]<mid<E[j][1]]
        eligible=images if images else covered
        if len(eligible)==2:
            free+=right-left
            parts=[(left,right,0 if mode=='right' else 1)] if mode!='mid' else [(left,mid,0),(mid,right,1)]
        else: parts=[(left,right,eligible[0])]
        for lo,hi,owner in parts:
            q=hi-lo; p[owner]+=q; owners[owner].append([lo,hi])
            for j in images:
                if j!=owner: lost[j]+=q
            if not images: fill[owner]+=q
            chunks.append({'interval':[lo,hi], 'receiver_labels':covered, 'image_labels':images,'owner':owner})
    ell=[zeta/16]*2
    assert p==[ell[j]-lost[j]+fill[j] for j in range(2)]
    assert sum(p)==W
    assert sum(lost)==2*ell[0]-sum(length(x['interval']) for x in chunks if x['image_labels'])
    assert sum(fill)==sum(length(x['interval']) for x in chunks if not x['image_labels'])
    return E,chunks,owners,p,lost,fill,free

def run(z,mode):
    E,chunks,owners,p,lost,fill,free=intervals(z,mode)
    eps=56/z; v=z*d/32; R=2*v/d; alpha=[x/W for x in p]
    old_demand=d+eps*v/lam; oldh=(D*D+2*h*h/3)/(2*s*s)
    H=(1+k)*eps*(2*v)*oldh
    assert old_demand==2 and eps*R==k and sum(alpha)==1
    assert D>2*s/32 and all(abs(x-y)+h<s for x in c for y in c)
    # The source boxes are disjoint; split their unit masses at their own centers.
    assert 2*h<D
    u=[eps*p[i]/(alpha[i]*2) for i in range(2)]
    dem=[2+eps*p[i]/alpha[i] for i in range(2)]
    assert u[0]==u[1] and dem[0]==dem[1]
    st=solve_source([[x] for x in c],[F(1),F(1)],alpha,p,eps)
    assert st['status']=='exact_lp_certificate'
    phi=eps*p[0]*p[1]*D*D/W
    assert phi==st['phi_exact']
    xstar=sum(p[i]*c[i] for i in range(2))/W
    ac_radius=F(1,1024)
    assert all(abs(xstar-x)+ac_radius<1 for x in c)
    ac_excess=eps*W*ac_radius**2/3
    Q=2; M=2; base=W-R*Q; score_coefficient=H-phi
    return {'zeta':z,'label':mode,'centers':c,'receiver_intervals':owners,'receiver_supports':B,'image_intervals':E,
       'partition':chunks,'p':p,'alpha':alpha,'epsilon':eps,'old':{'s':s,'d':d,'lambda':lam,'v':v,'R':R,'M':M,'kappa':k,'demand':old_demand,'source_box_centers':c,'source_box_halfwidth':h,'source_box_mass':1,'h_j':oldh,'H':H,'old_receiver_halfwidth':s/32,'old_owned_halfwidth':z*s/32},
       'ownership':{'ell':[z/16,z/16],'lost':lost,'fill_by_owner':fill,'O':sum(lost),'fill':sum(fill),'free_length':free},
       'new':{'Q_prime':Q,'E_prime':sum(alpha[i]*2*(u[i]-eps*W/Q)**2/eps for i in range(2)),'S':M-Q,'u_prime':u,'kappa_prime':eps*W/Q,'demands':dem,'entropy_dual':dem[0],'kkt_residuals':[dem[0]-dem[1],1-sum(alpha)]},
       'source':{'status':st['status'],'phi':phi,'cells':st['cells'],'primal':st['primal_exact'],'dual':st['dual_exact'],'minimizer':xstar,'ac_radius':ac_radius,'ac_mass':dem[0],'ac_interval':[xstar-ac_radius,xstar+ac_radius],'ac_excess':ac_excess,'ac_H_next':phi+ac_excess},
       'gamma':{'constant':base,'L_coefficient':score_coefficient,'actual_ac_L_coefficient':score_coefficient-ac_excess}}

def stringify(x):
    if isinstance(x,F): return str(x)
    if isinstance(x,dict): return {str(k):stringify(v) for k,v in x.items()}
    if isinstance(x,(tuple,list)): return [stringify(v) for v in x]
    if hasattr(x,'item'): return stringify(x.item())
    return x

if __name__=='__main__':
    fixtures=[]; comparisons=[]
    for z in [F(1),F(3,4),F(1,2),F(1,4)]:
        rows=[run(z,m) for m in (['mid'] if z==F(1,2) else ['left','mid','right'])]
        fixtures.extend(rows)
        if len(rows)==3:
            diff=[r['gamma']['L_coefficient']-rows[1]['gamma']['L_coefficient'] for r in rows]
            assert diff[0]==diff[2]>0 and diff[1]==0
            comparisons.append({'zeta':z,'endpoint_minus_mid_L':diff[0]})
        else: assert rows[0]['ownership']['free_length']==0
    assert len(fixtures)==10
    assert comparisons[0]['endpoint_minus_mid_L']==F(7,49152)
    out={'fixtures':fixtures,'comparisons':comparisons,'negative_control':'zeta=1/2, no free ownership','scope':'representative anchors; old R<1; no product-law expectation or global increment'}
    Path(__file__).with_name('results.json').write_text(json.dumps(stringify(out),indent=2)+'\n')
    print(json.dumps(stringify({'count':len(fixtures),'comparisons':comparisons,'negative_control':out['negative_control']})))
