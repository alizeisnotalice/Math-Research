"""Geometric source LP on real cube membership cells.

All inputs must be exact rational (int, Fraction, or rational/decimal string).
Numeric LP/QP outputs are *not* certificates unless exact primal and dual
witnesses are verified; see source_engine.md for scope and result schema.
"""
from fractions import Fraction as F
from itertools import product
from math import prod


def _f(x):
    if isinstance(x, float):
        raise TypeError('binary floats not accepted; use exact rational input')
    return F(x)


def _cell_cost_1d(bounds, ids, centers, radii, coeff):
    lo, hi = bounds[0]
    A = sum((coeff[i] / radii[i]**2 for i in ids), F(0))
    B = sum((coeff[i] * centers[i][0] / radii[i]**2 for i in ids), F(0))
    x = min(hi, max(lo, B/A)) if A else lo
    return sum((coeff[i] * ((x-centers[i][0])/radii[i])**2 for i in ids), F(0)), x


def _cell_cost_qp(bounds, ids, centers, radii, coeff):
    import cvxpy as cp
    import numpy as np
    x = cp.Variable(len(bounds))
    t = cp.Variable(len(ids), nonneg=True)
    cons = []
    for j, (lo, hi) in enumerate(bounds):
        cons += [x[j] >= float(lo), x[j] <= float(hi)]
    for k, i in enumerate(ids):
        for j in range(len(bounds)):
            cons += [x[j]-float(centers[i][j]) <= float(radii[i])*t[k],
                     float(centers[i][j])-x[j] <= float(radii[i])*t[k]]
    objective = cp.sum(cp.multiply(np.array([float(coeff[i]) for i in ids]),cp.square(t)))
    problem = cp.Problem(cp.Minimize(objective),cons)
    problem.solve(solver='CLARABEL')
    if problem.status not in ('optimal','optimal_inaccurate') or x.value is None:
        raise RuntimeError('QP returned '+str(problem.status))
    point = [float(v) for v in x.value]
    # Evaluating G at a clipped numerical point is diagnostic, not an exact upper bound.
    point = [max(float(lo),min(float(hi),v)) for v,(lo,hi) in zip(point,bounds)]
    cost = sum(float(coeff[i]) * max(abs((point[j]-float(centers[i][j]))/float(radii[i])) for j in range(len(bounds)))**2 for i in ids)
    return cost, point, problem.status


def solve_source(centers, radii, alpha, p, eps, max_boxes=100000):
    """Return geometric cells, row demands and LP witnesses; all rows retained.

    centers[i][axis], radii[i] (half-side), alpha[i], p[i], eps are exact
    rationals. Rows with deleted/zero alpha must be removed before calling.
    Boundaries are treated modulo Lebesgue-null sets.
    """
    C = [[_f(v) for v in c] for c in centers]
    R, A, P, E = list(map(_f,radii)), list(map(_f,alpha)), list(map(_f,p)), _f(eps)
    nrows = len(C)
    if not nrows or len(R)!=nrows or len(A)!=nrows or len(P)!=nrows:
        raise ValueError('nonempty, equal-length row arrays required')
    dim = len(C[0])
    if not dim or any(len(c)!=dim for c in C): raise ValueError('invalid dimension')
    if E<=0 or any(r<=0 for r in R) or any(a<=0 for a in A) or any(v<0 for v in P):
        raise ValueError('require positive radii, eps and retained alpha; p nonnegative')
    ends = [sorted(set(c[j]+sgn*R[i] for i,c in enumerate(C) for sgn in (-1,1))) for j in range(dim)]
    intervals = [[(x,y) for x,y in zip(e,e[1:]) if x<y] for e in ends]
    count = prod(map(len,intervals))
    if count>max_boxes: raise ValueError(f'partition would contain {count} boxes; cap {max_boxes}')
    d = [(2*r)**dim for r in R]
    demand = [d[i]+E*P[i]/A[i] for i in range(nrows)]
    coeff = [A[i]*E*P[i]/(A[i]*d[i]+E*P[i]) for i in range(nrows)]
    cells = []
    for bounds in product(*intervals):
        mid = [(lo+hi)/2 for lo,hi in bounds]
        ids = tuple(i for i in range(nrows) if all(abs(mid[j]-C[i][j])<R[i] for j in range(dim)))
        load = sum((A[i] for i in ids),F(0))
        if load>1: raise ValueError(f'packing violation on positive-volume box {bounds}: {load}')
        if load!=1: continue
        if dim==1:
            cost, arg = _cell_cost_1d(bounds,ids,C,R,coeff)
            item={'membership':ids,'bounds':bounds,'cost':cost,'minimizer':[arg],'cost_status':'exact_rational'}
        else:
            cost,arg,status = _cell_cost_qp(bounds,ids,C,R,coeff)
            item={'membership':ids,'bounds':bounds,'cost':cost,'minimizer':arg,'cost_status':'numerical_uncertified:'+status}
        cells.append(item)
    if not cells: raise ValueError('no positive-volume saturated cells')
    from scipy.optimize import linprog
    import numpy as np
    matrix = np.array([[float(i in c['membership']) for c in cells] for i in range(nrows)])
    costs = np.array([float(c['cost']) for c in cells])
    sol = linprog(costs,A_eq=matrix,b_eq=np.array([float(v) for v in demand]),bounds=(0,None),method='highs')
    if not sol.success: return {'status':'lp_'+str(sol.status),'message':sol.message,'cells':cells,'demands':demand,'coefficients':coeff}
    output = {'status':'numerical_uncertified','dimension':dim,'partition_boxes':count,'cells':cells,
              'volumes':d,'demands':demand,'coefficients':coeff,'phi_approx':float(sol.fun),
              'primal_approx':list(map(float,sol.x)),'dual_approx':list(map(float,sol.eqlin.marginals))}
    if dim==1:
        # Reconstruction only proposes a witness. Exact equations and inequalities decide.
        primal=[F(float(x)).limit_denominator(10**9) for x in sol.x]
        dual=[F(float(x)).limit_denominator(10**9) for x in sol.eqlin.marginals]
        valid = all(z>=0 for z in primal)
        valid &= all(sum((primal[j] for j,c in enumerate(cells) if i in c['membership']),F(0))==demand[i] for i in range(nrows))
        valid &= all(sum((dual[i] for i in c['membership']),F(0))<=c['cost'] for c in cells)
        objp=sum((z*c['cost'] for z,c in zip(primal,cells)),F(0))
        objd=sum((y*m for y,m in zip(dual,demand)),F(0))
        valid &= objp==objd
        if valid:
            output.update(status='exact_lp_certificate',phi_exact=objp,primal_exact=primal,dual_exact=dual)
    return output
