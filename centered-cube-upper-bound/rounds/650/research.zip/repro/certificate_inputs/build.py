import json
from fractions import Fraction as F
from pathlib import Path
out=Path(__file__).resolve().parent
with (out.parent / 'results.json').open() as fh:
 x=json.load(fh)
assert len(x['fixtures'])==10
for k,f in enumerate(x['fixtures']):
 c=list(map(F,f['centers'])); p=list(map(F,f['p'])); eps=F(f['epsilon']); W=sum(p); a=[p0/W for p0 in p]; m=2+eps*W; sep=c[1]-c[0]
 assert list(map(F,f['alpha']))==a and list(map(F,f['new']['demands']))==[m,m]
 phi=eps*p[0]*p[1]*sep**2/W; cell=phi/m
 assert F(f['source']['phi'])==phi
 # Independently inspect each arrangement segment and priority ownership.
 supports=[[F(t) for t in b] for b in f['receiver_supports']]; images=[[F(t) for t in b] for b in f['image_intervals']]
 ends=sorted({v for b in supports+images for v in b} | {F(v) for segment in f['partition'] for v in segment['interval']}); assigned=[F(0),F(0)]
 for l,h in zip(ends,ends[1:]):
  t=(l+h)/2; rec=[i for i,(u,v) in enumerate(supports) if u<t<v]; img=[i for i,(u,v) in enumerate(images) if u<t<v]
  if not rec: continue
  matches=[j for j,b in enumerate(f['partition']) if F(b['interval'][0])<=l and F(b['interval'][1])>=h]
  assert len(matches)==1; owner=f['partition'][matches[0]]['owner']; assert owner in (img or rec); assigned[owner]+=h-l
 assert assigned==p
 lo,hi=map(F,f['source']['ac_interval']); mass=F(f['source']['ac_mass']); assert mass==m and -1+sep/2<lo<hi<1-sep/2
 # Exact average of quadratic on interval, minus exact cell infimum.
 coeff=[a[i]*eps*p[i]/(2*a[i]+eps*p[i]) for i in range(2)]
 ac=mass*sum(coeff[i]*((lo*lo+lo*hi+hi*hi)/3-c[i]*(lo+hi)+c[i]**2) for i in range(2))
 assert ac-phi==F(f['source']['ac_excess']) and ac==F(f['source']['ac_H_next'])
 rows=[{'center':str(c[i]),'radius':'1','alpha':str(a[i]),'p':str(p[i]),'receiver_intervals':f['receiver_intervals'][i]} for i in range(2)]
 data={'epsilon':str(eps),'delta':'1/1099511627776','rows':rows,'entropy_multipliers':[str(m)],'lp_primal':[str(m)],'lp_dual':[str(cell),'0']}
 (out/f'candidate_{k:02}.json').write_text(json.dumps(data,indent=2)+'\n')
 print(f"{k:02} zeta={f['zeta']} owner={f['label']} p={p} phi={phi} supplied_ac_excess={ac-phi} priority=PASS")
