"""Exact algebra only; no sign theorem or general geometric certificate."""
import json
import sympy as s
E,O,F,R,M,S,L,H,X,A,kfill,klost,eps=s.symbols('E O F R M S L H X A kfill klost eps')
Qp=M-S
D=E-O+F+R*S
proto=A+eps*(kfill-klost)
Phi=proto+X
checks={}
checks['complete_joint']=s.expand(D+L*Qp/M*H-L*Phi-(E+L*(H-A)+F-L*eps*kfill-O+L*eps*klost+S*(R-L*H/M)-L*X))
W,Q,hn=s.symbols('W Q hn',positive=True)
checks['score_increment']=s.expand(Q*((W/Q-L*hn/Q)-(R-L*H/M))-(W-R*Q-L*(hn-Q/M*H)))
u,kap,z,w,V=s.symbols('u kap z w V')
checks['centered_growth']=s.expand((u-kap)**2-z*u*(u-kap)*w-((u-kap)**2*(1-z*w)-z*kap*(u-kap)*w))
d,lam=s.symbols('d lam',positive=True)
checks['actual_pi']=s.cancel(kap*(lam*u*d/eps)/(u*(kap*Q/eps))-lam*d/Q)
checks['source_envelope']=s.expand(D+L*Q/M*H-L*Phi-((1-L*eps)*D+L*Q*(H/M-kap)+L*(eps*(D+R*Q)-Phi))).subs(kap,eps*R).expand()
P,T=s.symbols('P T',positive=True)
checks['calibration']=s.simplify((1/(2*P*eps)-T/(8*P)).subs(eps,4/T))
p,W,Delta=s.symbols('p W Delta',positive=True)
checks['same_owner_gain']=s.expand(eps*W*Delta**2/4-eps*p*(W-p)*Delta**2/W-eps*Delta**2*(p-W/2)**2/W)
assert all(v==0 for v in checks.values()),checks
print(json.dumps({'symbolic_residuals':{k:str(v) for k,v in checks.items()},'sympy':s.__version__,'scope':'Seven exact algebra identities; no positive global increment.'}))
