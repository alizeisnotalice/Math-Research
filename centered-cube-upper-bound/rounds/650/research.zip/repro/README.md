# Reproduction and evidence boundaries

Actual interpreter used: `/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python` (Python 3.12.14). SymPy 1.14.0 checks algebra; Fraction checks rational geometry and certificates. SciPy 1.18.1/NumPy 2.5.4 provide source-LP candidate search, but `source_engine.py` reports an exact certificate only after rational primal/dual checking. No floating optimum is promoted to a proof. No new Arb computation was needed for these rational fixtures.

From this directory:

```
python -B check_symbolic.py
python -B ownership_experiment.py
python -B certificate_inputs/build.py
python -B certify.py certificate_inputs/candidate_00.json
```

The archive verifier runs all ten candidates, not only candidate 00. It runs experiments in an isolated temporary copy, leaving archived evidence unchanged. Generated candidate JSON files are intentionally omitted from the archive; the independent adapter regenerates them from `results.json`.

`crosscheck.m` was actually run using the connected MATLAB R2026a Update 4 on all ten candidates. Example: `crosscheck('/absolute/extracted/path/repro/certificate_inputs/candidate_00.json')`. `matlab_output.txt` preserves the actual output; the Python archive verifier does not claim to rerun MATLAB. An initial nested-JSON indexing error in the MATLAB script was corrected before the successful run.

The candidate generator checks the actual old AC/KKT construction and the displayed representative half action. The independent certificate checker verifies new packing, actual receiver partitions, E-priority through the adapter, entropy KKT, source LP zero gap, and exact AC integration. The independent Sol numeric review separately recomputes all-old accounting. All ten models have n=1, old R<1 and fixed representative anchors; none verifies a full product-law expectation or an arbitrary-dimensional bound.

Small runs used one Python process with BLAS constrained to one thread during the experiment, and one MATLAB session. They took seconds or less; sustained CPU saturation is not claimed. No dummy load or third-stage parameter expansion was run. The resource snapshot (15 logical cores, 24 GiB RAM) does not measure mathematical progress.

Evidence stages: initial exact ownership tests, E-priority no-freedom stress test, and independent expanded ownership-value checks within ten frozen fixtures. The proposed broader third stage was deliberately not run. No complete three-stage verification of the general strategy is claimed.
