# Independent R650 certificate: input contract and limitations

Status: **all ten frozen R650 candidates passed the exact checks described below; MATLAB also cross-checked the same mathematical inputs.** It accepts one-dimensional, exact rational data only. This is a verification interface, not candidate generation, not a general critical-old-half certificate, and not evidence for a global bound.

Run `/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/ccu_r650/numeric/certify.py candidate.json`. All numeric values must be integers or exact rational strings such as `"7/12"`, never binary floats. JSON object format:

```json
{
  "epsilon": "positive rational", "delta": "positive rational",
  "rows": [
    {"center": "rational", "radius": "positive rational",
     "alpha": "positive rational", "p": "nonnegative rational",
     "receiver_intervals": [["left", "right"]]}
  ],
  "entropy_multipliers": ["one nonnegative rational per saturated partition interval"],
  "lp_primal": ["one nonnegative rational per saturated partition interval"],
  "lp_dual": ["one unrestricted rational per row"]
}
```

Endpoints of all C intervals partition the line. Saturated intervals appear in increasing order, each with membership determined at its midpoint. The multiplier and LP primal arrays follow this order, including distinct intervals with identical memberships. Receiver intervals must lie in their row's C, have total length p and pairwise disjoint interiors across and within all rows. These explicit measurable sets establish actual receiver geometry for the submitted data; nothing in this checker establishes old A geometry, old KKT, half-action law, old criticality, or joint budget. The entropy check uses gradient `m_i=2 r_i+epsilon p_i/alpha_i`; nonnegative saturated-constraint multipliers with exact stationarity establish global entropy optimality by concavity (uniqueness requires additional strict-concavity hypotheses). Zero-alpha rows must already have been deleted.

For every positive-volume membership interval the checker verifies packing. It computes each saturated cell's exact quadratic infimum over the closure using *only its interior membership*, avoiding extraneous boundary labels. The nonnegative primal must give all m demands, and unrestricted dual must satisfy each cell inequality with exactly zero objective gap. For a closure minimizer x, a one-sided subinterval of length at most `delta` inside the same cell carries the cell's mass with constant density. Its cost excess is bounded by `z_j L_j min(delta, cell_length)` where `L_j` is the computed exact derivative bound. The finite sum gives an explicit absolutely continuous feasible source whose cost lies within the stated bound above the LP value; boundary infima need not be attained. Decreasing delta makes this error arbitrarily small. The output does not assert any numerical value before execution on an actual input.

`crosscheck.m` independently re-evaluates 1-D packing, receiver lengths, entropy stationarity, cell minima and LP witnesses using floating arithmetic. MATLAB checks are diagnostic only, not rigorous evidence. For each frozen candidate invoke `crosscheck('/absolute/path/candidate.json')` in MATLAB; compare against the rational checker and preserve actual output separately.

## Independent Stage-1 fixed-family arithmetic (executed)

Local Python `Fraction` calculation (2026-10-29): `Phi(mid)=21/16384`, `Phi(endpoint)=7/6144`, difference `7/49152`, exact equality true. Choose a uniform AC source interval centered at the quadratic minimizer with length `2^-40`; for this model its *exact*, not merely bounded, source-LP excess is `7/19342813113834066795298816`. The minimizer for p1 in the prescribed range lies in `[-1/192,1/192]`, inside common cell `[-63/64,63/64]`, so the interval is interior. This is a fixed-family calculation, not an entire product-law expectation.

MATLAB MCP actual output:

```text
MATLAB 26.1.0.3312084 (R2026a) Update 4 mid 0.00128173828125 endpoint 0.0011393229166666667 gain 0.00014241536458333326 exact residual -8.1315162936412833e-20
```

The MATLAB result is floating point and is independent corroboration only. The model has n=1, old R=1/16<1, and fixed representative anchors; it does not establish critical-old-R or expected full-action gain.

## Ten frozen candidates: executed independent checks

All ten converted inputs passed `certify.py`: exact packing on every positive-volume cell, disjoint and included owner intervals, correct owner lengths, entropy KKT with nonnegative multiplier, exact source primal/dual feasibility and zero gap. The independent adapter also partitioned every interval at all receiver, image and ownership endpoints, verified E-priority owner eligibility and total p, and integrated each submitted AC source's actual quadratic cost exactly. The raw outputs are [priority_output.txt](certificate_inputs/priority_output.txt), [python_output.jsonl](certificate_inputs/python_output.jsonl), and [matlab_output.txt](certificate_inputs/matlab_output.txt); inputs and the independent adapter are in `certificate_inputs/`. The Python output is a stream of indented JSON objects.

Exact submitted-source excesses above Phi are `7/4194304` for zeta=1, `7/3145728` for zeta=3/4, `7/2097152` for zeta=1/2, and `7/1048576` for zeta=1/4. These correspond to the experiment's actual positive-length AC source intervals, independent of the smaller illustrative 2^-40 interval above. MATLAB R2026a Update 4 checked all ten; maximum absolute floating primal-dual gap was 1.73e-18, with zero reported entropy stationarity and demand residuals. An initial MATLAB run exposed a nested-JSON cell indexing bug in the cross-check script; it was corrected and all ten then ran successfully. MATLAB is corroborative only.

Scope unchanged: n=1, old R<1, fixed representative anchors and no established product-law expectation, global budget, or Stage 3.

The experiment metadata was subsequently corrected (old receiver and owned halfwidth labels, and additional new-state fields); the ten mathematical objects used by the saved MATLAB run did not change. The adapter and exact checks were rerun against the corrected results.
