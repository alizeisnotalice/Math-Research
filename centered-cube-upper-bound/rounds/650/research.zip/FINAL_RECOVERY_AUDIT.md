# R650 final recovery integration audit

Audited report: /tmp/ccu_r650_final/REPORT.tex
Actual SHA256: 7b1dc85dd1196f27ea00caa8caf83af1bc1c5fd5e4601c5a84f8dcfbef99772d
Requested SHA256: 7b1dc85dd1196f27ea00caa8caf83af1bc1c5fd5e4601c5a84f8dcfbef99772d

Verdict: PASS within the scope below. The actual hash matches the requested frozen source. No necessary integration repair was found.

## Scope and method

This is a binding/integration review, not a repetition of the underlying mathematical audit. I read the frozen report, focusing on sections 1–3, original-input restoration, the boundary paragraph, and the opening claim limits. I compared these to the already completed /tmp/ccu_r650/SCORE_INDEPENDENT_AUDIT.md. No report or other author's file was modified, and no previously passed calculation was rerun.

The conditional score theorem is certified as a faithful integration of the independent reduction. This review does NOT certify its unproved uniform Gamma hypothesis, the remaining joint geometric sign in later sections, or the general weak-type bound.

## Same class and calibration

Section 1 correctly retains the general old partial-owner contract: disjoint positive I_j subset B_j without imposing full old receiver coverage. Section 3 separately and explicitly chooses the successor-closed class C_N of at most N actual full-ownership states for calibration and supremum comparison. Thus the narrower calibrated class is not silently substituted for the original broad geometric domain.

The report calibrates the RAW supremum T_N(e), once on that exact epsilon-independent class, to epsilon T_N(epsilon)=4. It neither calibrates the score supremum nor recalibrates after deletion or source selection. The cited finite-epsilon paragraphs were actually checked in the prior independent audit. The bound T_N(0)<=T_N(epsilon), implicit in that calibration citation and used in the contradiction from T_N(0), is one of those verified estimates.

The score supremum is expressly over all actual states and AC sources in the same fixed class. Its lower bound T-4L and the near-score critical window correctly use 0<=H/M<=kappa<=4. With L>=1 and T>64L, small positive eta gives R>1 and kappa>15/4; no attained R or score maximizer is asserted. Successor kappa'<=4 follows from class closure and calibration, while a successor lower critical endpoint is expressly unnecessary.

## Actual score, source minimum and tolerance

The inherited H normalization is integrated correctly: H_next=epsilon sum p_j h'_j, with no extra 1/g factor. The full score identity has Q' as the score-gain multiplier and L tau M' as the AC tolerance. This includes M'=gQ', rather than silently replacing it with normalized source mass.

The source LP uses actual positive-volume saturated cells, actual retained row demands and a convex rectangle cost formed from the fixed cell labels. Its boundary minima do not authorize atomic sources. Only AC near-minimization for arbitrary tau>0 is claimed, and no uniform bound on dual coefficients is used.

The deterministic conditional hypothesis retains a state-uniform positive delta in the fixed n,N,epsilon class. The expected alternative is under a well-defined product action law. The theorem does not substitute mere state-by-state Gamma>0. A positive increment after the chosen AC tolerance defeats the actual near-score supremum without assuming any geometric or source attainment.

The expected-margin proof correctly extracts ONE favorable actual outcome using Q'<=M and then chooses the AC near-minimizing source only for that action. It does not require a measurable source-minimizer kernel over every outcome. The report still requires measurability of Gamma and the ownership choice when it uses an expectation; the prior audit's necessary distinction is preserved.

## Zero owners, thresholds, and input restoration

Actual zero owners are deleted before logarithmic reoptimization, with no artificial positive floors or fictitious demands. E-priority owners cover the full new receiver union. Whole-geometry/source normalization and at-most-N retention supply the calibrated class closure. The old all-row contributions remain in the full ledger.

The theorem's conclusion includes the additional threshold as max(64L,16H_*(n),32), rather than claiming the clean 64L bound despite an extra applicability gate. It explicitly requires H_*=O(L) uniformly in N/input before claiming the conditional root order. Delta may depend on fixed n,N,epsilon; the threshold and L must be uniform in complexity.

The original-input restoration faithfully uses finite strict averaging witnesses and their receivers to cover a compact subset of the maximal superlevel. Ordering/deleting zero increments preserves that receiver union. At the zero-parameter optimum, alpha_0 Q_0<=||f||_1 follows from the packing inequality against ORIGINAL f dx, and V/Q_0 is bounded by the calibrated class's zero-parameter supremum. Compact exhaustion therefore incurs no extra a^n. The auxiliary entropy source is expressly not substituted for the input.

## Boundary obligations and claim limits

The report correctly preserves the warning that score near-maximality gives only D<=(4L+eta)Q', not the old raw-ratio near-max estimate D<=eta Q'. Its conditional hypothesis cannot use the latter without another argument.

It also explicitly says that a Gamma theorem on cleaned or tagged states needs score and source-LP recovery, and that R645 recovery of D alone does not recover these costs. The all-actual-state hypothesis avoids the limiting bridge only if actually proved on that full domain; it does not declare the historical costs paid.

The opening states that the general dimension bound is unproved and that neither the conditional theorem nor finite ownership examples prove the required positive increment. Section 3 labels the conclusion conditional and leaves the genuine all-state Gamma margin unproved. The integration therefore does not upgrade a conditional reduction into a general theorem or claim a new dimension exponent.

Final binding: PASS for the exact SHA256 above and the specified recovery/integration scope only.
