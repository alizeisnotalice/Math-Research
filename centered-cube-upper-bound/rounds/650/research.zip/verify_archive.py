from pathlib import Path
import ast,hashlib,json,re,subprocess,sys,tempfile,shutil
root=Path(__file__).resolve().parent
manifest=json.loads((root/'MANIFEST.json').read_text())
files={str(p.relative_to(root)) for p in root.rglob('*') if p.is_file() and p.name!='MANIFEST.json' and '__pycache__' not in p.parts}
assert files==set(manifest['files'])
for name,digest in manifest['files'].items():
 p=root/name
 assert hashlib.sha256(p.read_bytes()).hexdigest()==digest,name
 if p.suffix=='.py':ast.parse(p.read_text(),filename=name)
doc=(root/'REPORT.tex').read_text();stack=[]
for kind,env in re.findall(r'\\(begin|end)\{([^}]+)\}',doc):
 if kind=='begin':stack.append(env)
 else:assert stack and stack.pop()==env
assert not stack
labels=re.findall(r'\\label\{([^}]+)\}',doc)
refs=re.findall(r'\\(?:eqref|ref)\{([^}]+)\}',doc)
assert len(labels)==len(set(labels)) and set(refs)<=set(labels)
assert all(ord(c)>=32 or c in '\n\t' for c in doc)
sha=hashlib.sha256((root/'REPORT.tex').read_bytes()).hexdigest()
for name in ['FINAL_RECOVERY_AUDIT.md','FINAL_JOINT_AUDIT.md']:
 assert sha in (root/name).read_text()
def run(script,*args):
 r=subprocess.run([sys.executable,'-B',str(script),*map(str,args)],cwd=script.parent,capture_output=True,text=True,check=True)
 assert r.stdout.strip()
 return r.stdout
with tempfile.TemporaryDirectory(prefix='ccu-r650-replay-') as temp:
 rep=Path(temp)/'repro';shutil.copytree(root/'repro',rep)
 algebra=json.loads(run(rep/'check_symbolic.py'))
 print('PASS symbolic identities:',len(algebra['symbolic_residuals']))
 run(rep/'ownership_experiment.py')
 assert (rep/'results.json').read_bytes()==(root/'repro/results.json').read_bytes()
 run(rep/'certificate_inputs/build.py')
 candidates=sorted((rep/'certificate_inputs').glob('candidate_*.json'))
 assert len(candidates)==10
 for candidate in candidates:run(rep/'certify.py',candidate)
 print('PASS exact replay, actual priority and 10 independent LP/KKT certificates')
print(json.dumps({'files':len(files),'latex_labels':len(labels),'report_sha256':sha,'scope':'No PDF; MATLAB is preserved prior execution, not rerun here; no general bound certified.'}))
