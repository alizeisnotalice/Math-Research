# R650 final integrated joint audit

**Result: PASS within the assigned integration scope. No unresolved joint-ledger, owner-interface or numerical-scope issue was found. The global positive-increment budget remains unproved.**

Bound report: `/tmp/ccu_r650_final/REPORT.tex`

SHA-256: `7b1dc85dd1196f27ea00caa8caf83af1bc1c5fd5e4601c5a84f8dcfbef99772d`

Scope: integration of the previously verified G1-G6 joint/covariance formulas, corrected source-tolerance bound, actual ownership objective and eligibility support statement, score/source quantities used by those sections, and the limits assigned to the ten local tests. The separate score-recovery and numeric audits are reused, not broadly recomputed. This audit changes only this file.

## 1. One consistent actual branch

The report fixes one feasible uB-weighted minimizing source assignment, then its actual independent half-actions and E-priority owners. It explicitly does not combine this optimizer with the abandoned unweighted center or physical pair-exchange optimizer. The owner-dependent actual alpha, row demands and source LP are recomputed consistently. Old partial disjoint owners need not cover the old union; new actual owners cover the complete new receiver union.

All subsequently deleted old rows remain in E, O and the all-old diagonal/owner identities. New u', m' and positive denominators are only used on retained rows. Thus the source LP does not invent demands on deleted zero owners, while their old image losses are not erased.

## 2. Actual H, source minimum and score identity

The next H formula uses actual mu'|C_j/m'_j conditional means. Common spatial/mass normalization cancels g pathwise before any expectation, giving H_next=eps sum p_j h'_j. The report does not identify these means with old-source k_j.

The source integrand coefficients chi_j=eps p_j/m'_j are correct, and H_next=int G dmu' has no extra 1/g. Saturated cells refer to the retained actual new family. The closed-rectangle cost uses only the cell's own interior labels; the boundary minimum does not authorize an atom. The AC tolerance is Phi_H+tau M' with M'=gQ', distinct from normalized M_next=Q'. No AC minimizer attainment or uniform dual-price cap is assumed.

The exact score identity is retained with the same deterministic L at old and new states. The all-state same-epsilon calibration is distinguished from old critical-state assumptions and from raw-ratio near maximality. In particular the report correctly records that near-score states have only D<=(4L+eta)Q', not D<=eta Q', and that a state-uniform positive Gamma margin is still needed. It does not assume a lower critical bound for successors.

The conditional recovery statement is explicitly conditional and retains the missing score costs for cleaned/tagged-only arguments. It is not presented as a proof of the required positive Gamma margin.

## 3. Joint identity and actual harmonic covariance

The integrated joint identity equals the verified G1:

  Gamma=E+L(H-sum_all a_j u_j k_j)
        +sum f_j(1-zeta k_j)-sum o_j(1-zeta k_j)
        +S(R-LH/M)-LXi,

with zeta=L eps and Xi=Phi_H-H_proto. Lost-copy/source terms occur once. On a deleted old row, its diagonal term and eps o_j k_j cancel in H_proto; the row is still present in the full identity.

The weighted assignment yields an UPPER bound on E sum_all a_j u_j k_j. Its coefficient in Gamma is negative, so the report correctly turns this into the LOWER bound L(D_H-C_H). Ownership/source terms remain under their actual joint expectation. The S coefficient is fixed old-state data, so it may multiply E S without an independence assumption.

The actual weights pi_j=lambda_j d_j/Q=kappa v_j/(u_j V) form a probability with mean u equal to kappa. The growth identity E=(V/kappa)Var_pi(u), the covariance decomposition and its same-source integral all retain the correct factor 1/(1+u_j). No covariance sign is presumed; negative covariance is not discarded. These are the previously verified G3/G6 formulas, now integrated without changing signs.

For R>=2kappa L the positive variance/fill/slack coefficients have their stated lower bounds. The report also notes that the negative lost-copy coefficient remains large. It does not turn small zeta into payment of overlap or source relocation. The displayed unpaid combined quantity is the correct one from G4/G5, not a second independent source credit.

The raw old growth is used once in this complete score branch. The report does not append the separately paid R647 low-input residual, old reload allowance or next-growth allowance as extra income.

## 4. The corrected source-tolerance bound is integrated accurately

The erroneous draft inference W<=sum ell_j is explicitly withdrawn. The report now retains fill:

  M'<= (1+kappa)M+eps E+eps F.

It does not treat this as an old-data-only uniform estimate. In the independently calibrated successor-closed class, kappa'<=4 and Q'<=M give the valid uniform bound M'<=5M. Therefore tau<=m/(10LM) makes L tau M'<=m/2 for a known expected margin m. Alternatively a favorable finite action can be selected first and its own positive tolerance chosen afterwards.

These statements pay approximation error only. They neither supply m nor assume an optimizing source-selection kernel exists. This corrects the sole substantive issue found in the earlier joint-file audit.

## 5. Ownership objective and eligibility polytope

For a fixed old state/action W, R and H/M are fixed. Rewriting Gamma gives exactly

  Gamma=W-J(p),
  J(p)=(R-LH/M)Q'(p)+L Phi_H(p).

Thus an ownership variation must optimize the actual recomputed entropy/source objective, not just a linear surrogate with frozen alpha. The report makes this distinction explicit.

Finite receiver/image membership cells have real Lebesgue volumes. Splitting each volume among its E-priority eligible labels yields a finite Minkowski sum of simplices. Its linear support minimum is the stated integral of the eligible pointwise minimum price; a fixed-label tie rule realizes it measurably. This does not imply convexity of the nonlinear J or an improving direction.

At positive owners, adding the actual total-mass equality to an all-positive-volume-cell source LP is consistent: integrating 1-L_alpha^C gives zero, so nonnegative source masses outside saturated cells must vanish. Thus this is an alternate fixed-cell formulation rather than a new source relaxation. It does not dispose of the genuine discontinuity caused by zero-owner deletion. The report appropriately refrains from claiming that compact owner volumes alone imply attainment of the nonlinear infimum.

## 6. Numerical scope matches the independent review

I read `/tmp/ccu_r650/NUMERIC_REVIEW.md`. The final report matches its ten-fixture scope, genuine image-priority subinterval ownerships, actual old/new entropy KKT, finite source certificate and explicit AC excess. The three same-score gain coefficients and the no-freedom z=1/2 control agree with that review. No additional checker, MATLAB run or wider scan was performed for this integration audit.

The old examples retain kappa=7/2 but have R=z/16<1. The report says so, and distinguishes a representative exact anchor tuple from a positive-probability product-law event. It does not claim a critical hard-state example or an expected global increment. The AC source excess is retained and is constant across owners in each fixed-z comparison, so comparing the actual AC score, rather than an unattained LP source, is legitimate as described by the independent certificate review.

The old receiver halfwidth is distinguished from the smaller owned halfwidth. Stage-3 scanning is expressly unexecuted, floating MATLAB values are corroboration rather than interval certificates, and no dimension order is inferred from these finite effects. Gain degeneration with geometry is left visible.

## 7. Remaining gap and final binding

The abstract and conclusion correctly say that no dimension exponent has been improved and no general weak-type theorem or uniformly contracting recursion has been established. The unresolved task is a quantitative all-family joint source/collision/covariance estimate yielding a usable state-uniform positive Gamma margin, including source, scale, contact and cleanup costs where applicable.

Thus the report integrates a valid conditional reduction, exact joint accounting and a genuine finite ownership effect without promoting any of them into the missing global budget. Earlier symbolic checks and the independent numeric audit are reused; no new broad computation is claimed.
