# Independent ownership variation derivation

This supporting note was derived independently before reading the construction author. The final report uses only its finite-difference, eligibility and deletion-boundary conclusions. No global ownership-improvement theorem is claimed.

# R650 independent owner-variation audit — first derivation checkpoint

Owned file only. Scope: calibrate the actual-owner joint objective Gamma_L and derive legal finite differences / conditional local derivatives for source-LP value as ownership changes at fixed sampled new cubes. Do not assume convexity or a paid contraction. No old coercivity or separately charged reload budget is used.

Frozen during an ownership variation: all old data (epsilon, lambda, mu, m, a, u, kappa, H, M, gamma), the sampled anchors Z, the actual new cubes C and receivers B', image pieces E and their volumes ell, W, O, fill, and old-source row means k_j. Changed: actual owner volumes p, lost/fill row allocations o,f, retained labels when a boundary is crossed, actual entropy optimizer alpha(p), u'(p), b(p)=m'(p), Q'(p), g(p), M'(p), source costs, saturated cells and source LP value. The successor AC source must be reselected for the changed alpha/b; gamma and the anchors are not redrawn.

Permitted tools: exact finite-dimensional algebra and finite LP/convex minimization in actual positive-volume geometry, plus bounded local symbolic verification. Main obstacles: membership/saturation changes, zero-owner deletion, source demands and costs varying together, and no known geometric sign for the resulting finite difference. The intended deliverable is a legal variation identity/inequality and a precise unproved bridge, not finite-LP existence alone. Derivations below will be completed before reading any author variation proof.

## 1. Calibration of Gamma_L and consistency with lost ownership

Let L be the fixed deterministic dimension coefficient and set F_L=R-LH/M. For every legal fixed-Z ownership and its reoptimized successor,

\[
 Q'[F_L(\mathrm{next})-F_L(\mathrm{old})]
 =D-L[H_{\rm next}-(Q'/M)H].
\]

This is exact, since R_next=W/Q' and M_next=Q'. The correct source cost for H_next is the unnormalized Phi_H; there is no extra 1/g in this identity. If an actual AC source is chosen with Phi_H<=H_next<=Phi_H+tau M', then

\[
 Q'[F_L(\mathrm{next})-F_L(\mathrm{old})]
 \ge\Gamma_L-L\tau M',\qquad
 \Gamma_L=W+(LH/M-R)Q'-L\Phi_H.
\]

Thus Gamma_L is correctly calibrated as a one-action sufficient score increment, with its real AC tolerance. This does not prove that the increment has a positive uniform margin, or that a score argument covers all near-extremal states and recovery fees.

Put A_old=sum over ALL old rows a_j u_j k_j. Exact ownership gives H_proto=A_old+eps(f-o) dot k. Consequently

\[
 \Theta=\Phi_H-A_{\rm old}-\varepsilon f\cdot k
 =(\Phi_H-H_{\rm proto})-\varepsilon o\cdot k,
\]

and

\[
 \Gamma_L=D+L(Q'/M)H-LA_{\rm old}
                 -L\varepsilon f\cdot k-L\Theta.
\]

This checks the lost-copy sign and prevents an artificial second lost-copy credit. If two E-priority partitions have the same p but different f,o, alpha, Phi_H and Gamma_L are unchanged; the corresponding change in Theta cancels the explicit weighted-fill change. Optimizing Theta alone while dropping that fill term would not be optimizing the full joint objective. Deleted owner rows remain in A_old.

### The legal owner domain is usually smaller than a simplex

At this fixed action, let e_T be the volume of the exact E-membership cell T inside union E, and let f_T be the volume of the exact B'-membership cell T inside the fill region. The possible old-image ownership d and fill ownership f have domains

\[
 d\in\sum_T e_T\Delta_T,\qquad
 f\in\sum_T f_T\Delta_T,\qquad p=d+f,
\]

where Delta_T is the simplex supported on covering labels T. Lebesgue measure is nonatomic, so every such finite allocation of cell volume is realized by measurable partitions. This is a compact convex owner polytope P inside sum p_j=W, p_j>=0. Arbitrary points of that whole simplex need not be legal. The formulas below apply to positive p in the legal polytope; allowing the whole positive simplex can at most be an explicitly relaxed investigation.

## 2. What changes when p changes

For p>0 on one retained label set J, the actual alpha(p) uniquely maximizes

\[
 m\cdot\alpha+\varepsilon\sum_{j\in J}p_j\log\alpha_j,
 \quad \alpha\ge0,\quad
 \sum_{j\in K}\alpha_j\le1
\]

over the actual positive-volume C-membership patterns K. Strict concavity from positive p makes alpha unique and positive. Define

\[
 Q'=m\cdot\alpha,\quad
 b_j=m'_j=m_j+\varepsilon p_j/\alpha_j,\quad
 u'_j=\varepsilon p_j/(\alpha_jm_j),
\]
\[
 g=1+\varepsilon W/Q',\quad M'=Q'+\varepsilon W,
 \quad\chi_j=\alpha_j\frac{u'_j}{1+u'_j}
 =\frac{\varepsilon p_j}{b_j}.
\]

All these objects must be recomputed with p. In particular b is not fixed when ownership changes, and chi is not an independent fixed cost weight. Saturated patterns can change even though the actual C geometry remains fixed. The old weighted gamma remains fixed; no redraw, reweighting of anchors, or alpha-independence is introduced.

### Deleted-zero faces are a different problem

When a p_j becomes zero, the contract deletes that owner row before reoptimization. The positive-p entropy objective still contains its linear m_j alpha_j term; the deleted problem does not. Thus no unproved continuity from the positive-p objective to the deleted problem can be used. Packing dimensions, membership patterns, row demands and source LP must be recomputed on each retained set. The old A_old still uses every old row. An owner polytope's compactness alone does not prove that this convention's Gamma_L attains its supremum. A maximum-attainment or boundary-reduction argument needs a separate check; the positive-stratum formulas below do not supply one.

## 3. A fixed-column source LP valid across saturation changes

There is a useful exact formulation that avoids treating current saturated columns as permanently fixed. On a fixed positive retained set, enumerate ALL actual positive-volume exact C-membership cells Omega_K, and define

\[
 c_K(\chi)=\operatorname*{ess\,inf}_{y\in\Omega_K}
            \sum_{j\in K}\chi_jr_j^C(y)^2.
\]

Only positive-volume cells are included. A nonsaturated exact cell need not be a rectangle, so the saturated-rectangle simplification must not be applied to all these costs. The definition by essential infimum is sufficient. Its value is concave and nondecreasing in chi, being an infimum of nonnegative linear functions of chi, and lies between zero and sum_{j in K} chi_j. A current saturated cell does equal its full intersection rectangle modulo null sets; there the existing continuous K-only convex minimization is valid, including its ambient-boundary qualification.

Let B have columns 1_K and augment it by a mass row:

\[
 \widehat B=\begin{pmatrix}B\\\mathbf1^T\end{pmatrix},
 \quad \widehat b(p)=(b(p),M'(p)).
\]

Then exactly the same Phi_H is given by

\[
 \Phi_H(p)=\min\{c(\chi(p))\cdot z:
              \widehat Bz=\widehat b(p),\ z\ge0\}.
\]

Indeed alpha dot b=M', so every feasible z obeys

\[
 \sum_K[1-\alpha(K)]z_K=0.
\]

Every summand is nonnegative by actual packing. Hence all nonsaturated columns automatically receive zero mass. Conversely a feasible saturated source has total mass alpha dot b=M' and satisfies the augmented system. The augmented formulation therefore has genuinely fixed columns on a positive retained stratum, even when saturation changes, and exactly preserves the source mass. It is not the incorrect relaxation obtained by dropping both saturation and total mass.

The augmented dual is

\[
 \max_{\beta,\zeta}\{\beta\cdot b+\zeta M':
              \beta(K)+\zeta\le c_K(\chi)\ \text{for all positive cells}\}.
\]

Finite dual attainment holds, but its new mass coefficient is not uniformly bounded for free. For example, any current saturated-cell dual beta0 can be extended by taking beta=beta0-zeta alpha and sufficiently negative zeta; on nonsaturated cells this requires

\[
 \beta_0(K)+\zeta[1-\alpha(K)]\le c_K.
\]

As saturation deficits tend to zero this construction can require very large |zeta|. This exact extension is not a paid uniform dual estimate, and exposes one concrete coefficient bridge that remains unproved.

## 4. Exact two-endpoint finite differences

Use the same fixed augmented matrix at two positive legal owners p,q. Write c_p=c(chi(p)), bwide_p=(b(p),M'(p)), and let z_p,z_q be optimal primal vectors and eta_p=(beta_p,zeta_p), eta_q be optimal augmented dual vectors. Put Delta c=c_q-c_p and Delta bwide=bwide_q-bwide_p. Weak duality gives the exact bounds

\[
 \boxed{\eta_p\cdot\Delta\widehat b+\Delta c\cdot z_q
 \le\Phi_H(q)-\Phi_H(p)
 \le\eta_q\cdot\Delta\widehat b+\Delta c\cdot z_p.}
\]

For example, the lower bound follows from c_p dot z_q>=eta_p dot bwide_q and Phi_H(p)=eta_p dot bwide_p; the upper bound is the reversed endpoint argument. No differentiability, common optimal basis, or unchanged saturation set is needed. The same positive-volume membership universe and retained labels are needed.

Set a_L=LH/M-R, a scalar unrelated to the inherited low-row mass A_L. Then

\[
 \Gamma_L(q)-\Gamma_L(p)
 =a_L\,m\cdot[\alpha(q)-\alpha(p)]-L\Delta\Phi_H,
\]

and in particular the verified lower variation bound is

\[
 \Delta\Gamma_L\ge
 a_L\,\Delta Q'
 -L[\eta_q\cdot\Delta\widehat b+\Delta c\cdot z_p].
\]

Thus a certified candidate ownership q can be tested without pretending demands are fixed. A uniform positive RHS for some legal q is a substantive missing geometric result; the displayed identity alone gives no such sign.

With actual AC sources chosen within tolerances tau_p,tau_q, the difference between their H_next values and the exact Phi difference lies in [-tau_p M'_p,+tau_q M'_q]. A score comparison must retain the corresponding L-weighted tolerance. A positive margin can permit choosing a smaller positive tau, but no atom or exact AC minimizer is needed or licensed.

## 5. Conditional differential on a stable branch

Here are legal local formulas, not a blanket differentiability claim. Suppose positive p stays in a region where the active entropy packing face is fixed, the source LP uses one stable optimal basis/support, and each used saturated rectangle cost has a differentiable minimizing branch (a unique minimizer suffices). At nonsmooth points use the finite differences above instead.

Choose a full-column-rank matrix A of independent active packing normals. With

\[
 D_\alpha=\varepsilon\operatorname{diag}(p_j/\alpha_j^2),
 \quad E_\alpha=\varepsilon\operatorname{diag}(1/\alpha_j),
\]

differentiating entropy stationarity and active equalities gives

\[
 D_\alpha\,d\alpha+A\,d\eta=E_\alpha\,dp,
 \qquad A^T d\alpha=0,
\]

hence

\[
 d\alpha=[D_\alpha^{-1}
 -D_\alpha^{-1}A(A^TD_\alpha^{-1}A)^{-1}A^TD_\alpha^{-1}]
 E_\alpha\,dp.
\]

Only owner-polytope feasible directions dp may be used. At an active-face change this expression need not remain the derivative.

For each row,

\[
 db_j=\frac\varepsilon{\alpha_j}dp_j
       -\frac{\varepsilon p_j}{\alpha_j^2}d\alpha_j,
\]
\[
 d\chi_j=\frac\varepsilon{b_j}dp_j-\frac{\chi_j}{b_j}db_j
 =\left(\frac{u'_j}{1+u'_j}\right)^2d\alpha_j
       +\frac{\varepsilon m_j}{b_j^2}dp_j.
\]

On a fixed saturated source branch, let y_K be its rectangle minimizer and z_K its primal mass, let beta be a compatible optimal saturated-cell dual, and put

\[
 R_j^*=\sum_{K\ni j}z_Kr_j^C(y_K)^2,
 \qquad \bar h_j^*=R_j^*/b_j.
\]

Differentiating the stable optimum gives

\[
 d\Phi_H=\beta\cdot db+\sum_jR_j^*d\chi_j
 =\varepsilon\sum_j\bar h_j^*dp_j
       +\sum_j(\beta_j-\chi_j\bar h_j^*)db_j.
\]

The first equality follows directly by differentiating c dot z and using complementary equality on its stable positive support. The displayed beta is a source-cost LP dual, not an entropy multiplier. They cannot be silently identified. An augmented-dual version includes zeta dM'.

Although sum_j b_j(beta_j-chi_j hbar_j^*)=0 by primal/dual equality, no rowwise sign for that residual is supplied. Consequently

\[
 d\Gamma_L=a_L\,m\cdot d\alpha
 -L\left[\varepsilon\sum_j\bar h_j^*dp_j
       +\sum_j(\beta_j-\chi_j\bar h_j^*)db_j\right]
\]

has no proved favorable direction merely from packing, weighted-gamma optimality or finite duality. This is a concrete missing bridge rather than a renamed source fee. Stable KKT derivatives, unbounded-source dual residuals and legal owner directions would have to be controlled jointly.

## 6. Curvature: one exact geometric obstruction to assuming convexity

The augmented source value is convex in fixed demands bwide for fixed costs, and concave in chi for fixed demands, by its dual support-function and primal infimum-of-linear-cost representations respectively. Actual ownership changes both arguments through alpha(p); these two separate curvature facts do not establish curvature of their composition.

A very small actual-new-cube/owner geometry proves that Phi_H(p) is not generally convex even on a strictly positive legal owner segment. This is a fixed-new-geometry illustration, not a claimed critical old half-action state.

Take n=1,a=32, epsilon=1, delta=1/64 and

\[
 C_1=[-1,1],\quad C_2=[\delta-1,\delta+1],
 \quad B'_1=[-1/32,1/32],\quad
 B'_2=[\delta-1/32,\delta+1/32].
\]

Take E_j=B'_j so E-priority ownership is ordinary covering ownership with no fill. The receiver union has W=5/64 and the legal owners satisfy p_1 in [1/64,1/16], p_2=W-p_1; both rows remain positive including these endpoints. Because m_1=m_2=2, actual new entropy gives alpha_j=p_j/W, Q'=2, and b_1=b_2=b=2+W. Only the common C-cell is saturated. Its minimizing point lies between the two centers, within their intersection. Since chi_j=p_j/b,

\[
 \Phi_H(p)=\min_x[p_1x^2+p_2(x-\delta)^2]
          =\delta^2\frac{p_1p_2}{W}.
\]

Its second derivative along p_1 is -2delta^2/W=-1/160<0. Thus Phi_H is strictly concave on this segment. With fixed old coefficient and Q', Gamma_L is correspondingly strictly convex there. A blanket claim of convex source minimization in p, or concave Gamma maximization with an interior stationary-point certificate, is false even in this exact actual-new-entropy geometry. This example does not disprove possible concavity of Phi_H in a broader class; no general composition-curvature theorem is proved here. The complete old hard contract is not supplied by this two-label toy and must not be inferred from it.

The proof also shows why optimizing just a differentiable interior candidate could miss a better legal owner-polytope face. That face is not necessarily a deleted-zero face: the toy's endpoint owners are still positive.

## 7. Actually executed local algebra

The existing math interpreter `/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python` was run with SymPy for this bounded independent derivation. Actual outputs:

```text
dchi alternative residual: 0
source differential regrouping residual: 0
joint-score calibration residual: 0
toy W: 5/64
toy Phi second derivative: -1/160
toy endpoint Phi: 1/327680
toy midpoint Phi: 5/1048576
toy strict Jensen concavity gap: 9/5242880
toy positive owner interval: 1/64 1/16
```

The toy's exact rational Jensen gap independently certifies the nonconvexity claim; no floating-point sign is relied on. These outputs are algebra evidence, while the actual positive-volume source/owner feasibility and finite-difference inequalities are justified above. No broad numerical search, old coercivity experiment, or actual old critical-state certificate was run.

## Independent checkpoint and proposed author exchange

The useful new audit result is the fixed-column augmented LP and its exact finite-difference bounds, with a conditional stable-branch derivative and a genuine new-geometry nonconvexity example. Gamma_L's source/lost calibration passes. What remains unproved is a uniform beneficial owner direction or endpoint, a valid treatment of deleted-zero limits/attainment, and a same-action positive margin adequate for all required state/recovery conditions. The audit has not read an author variation proof and is ready for an independent comparison rather than claiming the new bridge closed.
