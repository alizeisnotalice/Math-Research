"""Independent exact actual-history and multipool checks. Finite evidence only."""
from fractions import Fraction as F
from itertools import combinations_with_replacement
from pathlib import Path
import json,hashlib,time,sys
P=Path(__file__).resolve().parent

def merge(intervals):
 out=[]
 for l,r in sorted(intervals):
  if l>=r:continue
  if out and l<=out[-1][1]:out[-1]=(out[-1][0],max(out[-1][1],r))
  else:out.append((l,r))
 return out

def length(intervals):return sum((r-l for l,r in merge(intervals)),F(0))

def weighted_union(intervals):
 endpoints=sorted({e for l,r,w in intervals if w>0 for e in (l,r)})
 total=F(0)
 for l,r in zip(endpoints,endpoints[1:]):
  mid=(l+r)/2
  total+=(r-l)*max([F(0)]+[w for ll,rr,w in intervals if ll<mid<rr])
 return total

def multipool(N):
 a=32;q=F(1,2);alpha=F(1,32);c=F(33,32)
 centers=[F(-N+2*i+1,a) for i in range(N)]
 parents=[(y-1,y+1) for y in centers]
 eps=sorted({x for p in parents for x in p});cells=list(zip(eps,eps[1:]));mids=[(l+r)/2 for l,r in cells]
 rows=[[j for j,x in enumerate(mids) if l<x<r] for l,r in parents]
 load=[F(0)]*len(cells);history=[list(load)];remaining=set(range(N));order=[];theta=[];residual=[];cross={}
 while remaining:
  caps={i:1-max(load[j] for j in rows[i]) for i in remaining}
  chosen=max(remaining,key=lambda i:(caps[i],-i));ri=caps[chosen];th=alpha*ri
  order.append(chosen);residual.append(ri);theta.append(th);remaining.remove(chosen)
  for j in rows[chosen]:load[j]+=th
  assert all(x<=1 for x in load)
  history.append(list(load))
  for i in remaining:
   if i not in cross and max(load[j] for j in rows[i])>=q:cross[i]=len(order)
 assert all((ri<=q)==(i in cross) for i,ri in zip(order,residual))
 active=set()
 for i,m in cross.items():
  active.update(j for j in rows[i] if history[m-1][j]<q<=history[m][j])
 pools={}
 for j in sorted(active):
  tau=next(m for m in range(1,N+1) if history[m][j]>=q)
  pool=tuple(m for m in range(tau) if j in rows[order[m]])
  assert pool and max(pool)==tau-1
  assert sum((theta[m] for m in pool),F(0))==history[tau][j]
  pools.setdefault(pool,[]).append(cells[j])
 pools={k:merge(v) for k,v in pools.items()}
 D=2*sum(theta,F(0));V=F(N,16);bad=F(len(cross),16);H=length([cells[j] for j in active]);assert H<=D/q
 poolrows=[]
 for pool,z in pools.items():
  m=max(pool);h=c*residual[m]/q;B=sum((theta[i] for i in pool),F(0));halo=merge([(l-h,r+h) for l,r in z])
  assert residual[m]<=q+theta[m]
  poolrows.append({'pool':pool,'z':z,'B':B,'h':h,'halo':halo,'mass':length(halo)})
 limit=sum((p['mass'] for p in poolrows),F(0));halo_union=length([x for p in poolrows for x in p['halo']])
 # At every receiver cell test the strongest single common witness and the pair likelihood gain.
 ends=sorted({e for p in poolrows for l,r in p['z'] for i in p['pool'] for e in (l-c*residual[i]/q,r+c*residual[i]/q)})
 checks=[]; maxgap=F(0); extra=F(0)
 for k in (1,2):
  A=pair=U=F(0); minmargin=None
  for l,r in zip(ends,ends[1:]):
   x=(l+r)/2
   nearby=[p for p in poolrows if any(lo<x<hi for lo,hi in p['halo'])]
   U+=(r-l)*int(bool(nearby))
   # Evaluate actual sup across eligible pools at each tuple-dependent radius.
   terms={}
   laws=[]
   for p in poolrows:
    law={}
    for I in combinations_with_replacement(p['pool'],k):
     i=max(I);h=c*residual[i]/q
     if not any(lo-h<x<hi+h for lo,hi in p['z']):continue
     w=F(2 if k==2 and I[0]!=I[1] else 1)
     for j in I:w*=theta[j]/p['B']
     law[I]=w;terms[I]=max(terms.get(I,0),w)
    if p in nearby:laws.append(law)
   val=sum(terms.values(),F(0))
   lb=F(bool(laws))
   # First and last overlapping pools give a valid pair bound without an O(number of pools^2) search.
   if len(laws)>=2:
    u,v=laws[0],laws[-1]
    lb+=sum(abs(u.get(I,0)-v.get(I,0)) for I in u.keys()|v.keys())/2
   assert val>=lb
   A+=(r-l)*val;pair+=(r-l)*lb
  assert U==halo_union and A>=pair>=U
  checks.append([k,float(A/D),float(pair/D),float(U/D)])
 return dict(N=N,pools=len(poolrows),checks=checks)
if __name__=='__main__':
 import multiprocessing as mp
 ns=list(map(int,sys.argv[1:])); workers=min(len(ns),mp.cpu_count())
 with mp.get_context('fork').Pool(workers) as pool:print(json.dumps(pool.map(multipool,ns)))
