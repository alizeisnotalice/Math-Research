"""Enumerate product laws independently of the spatial calculation."""
from fractions import Fraction as F
from itertools import product
from math import prod
import json
from pathlib import Path

weights = list(map(F, ("1/10","1/5","3/10","2/5")))
for left,right in [((0,1),(2,3)), ((0,1),(0,1)), ((0,1,2),(1,2,3)), ((0,1,2),(0,1))]:
    mass = lambda pool: sum(weights[i] for i in pool)
    a = mass(set(left)&set(right))/max(mass(left),mass(right))
    for k in range(1,7):
        law = lambda pool,indices: prod(weights[i]/mass(pool) if i in pool else 0 for i in indices)
        overlap=sum(min(law(left,I),law(right,I)) for I in product(range(4),repeat=k))
        assert overlap == a**k
records=[]
for name in ('mini','laptop','mini-wide','laptop-wide'):
    records.extend(json.loads(Path(__file__).with_name(name+'.json').read_text()))
assert len(records)==len({r['N'] for r in records})==33
print('Exact overlap identity passed 24 cases; spatial outputs contain 33 distinct inputs.')
