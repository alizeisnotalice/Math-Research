# Independent proof audit — R695

Verdict: **PASS**, for the stated finite-family construction and the bounds actually asserted. No root-order upper bound is proved or claimed. The scale estimate remains exponentially dependent on dimension. This audit reads the positive open arrangement cells as a disjoint spatial partition, with each cell's pool taken through its own first crossing of q; under this intended definition g_I is single-valued.

Audited report SHA-256: `954cf75e7d260fa2a78bbc7d5e0c4ed4efd4afddbbea23e578ec527063668d45`

## Exact two-pool total variation

For P,R with positive coefficient masses B_P,B_R, both product likelihoods vanish outside the k-fold common support when taking their minimum. On the common support their numerators agree, so

`min(p^P(I),p^R(I)) = product(theta_i : i in I) / max(B_P,B_R)^k`.

Summing over ordered tuples gives `sum_I min(...) = a_PR^k` exactly, and hence TV equals `1-a_PR^k`. At x in both halos, the essential supremum for each tuple is at least either pool likelihood, so summing gives `T_k(x) >= 1+TV`. Together with `T_k >= 1_U`, this yields precisely the displayed integrated inequality for any one fixed pair P,R. The warning against summing arbitrary pair contributions is necessary and correct.

An actual local Python 3 calculation using fractions.Fraction checked this identity for all 225 ordered pairs of nonempty subsets of four labels, for k=1,2,3,4 (900 exact identities). The shared positive weights were 1/7, 2/9, 3/11, 4/13, and all ordered tuples on the four-label alphabet were enumerated. Every exact overlap and TV assertion passed; the subprocess exited with code 0. This finite check supports the algebra; the argument above proves the general identity.

## Scale truncation with arbitrary finite measurable owners

The integration is valid for arbitrary measurable owners satisfying the stated containment and disjointness, without requiring that an owner be a cube or an interval. Let z be any interior witness in the pool and p=d_m r_m>0 its first-hit price. Greedy prices are nonincreasing because each remaining capacity can only decrease. Thus every contributor i through m has d_i r_i >= p, and since 0<r_i<=1, d_i>=p.

The coefficient update gives `t theta_i <= r_i |E_i|/d_i <= |E_i|/d_i`. If y is in E_i and z is in A_i, then `||y-z||_infty <= c_a s_i`, and consequently `u(y)=(2||y-z||_infty/c_a)^n <= d_i`. For the selected small sources d_i<=Rp one therefore has

`1/d_i <= 1/max(p,u(y))`, and `u(y)<=Rp`.

Disjointness of the actual owners permits the sum of their integrals to be bounded by one integral over the entire radial region u<=Rp. Its radial volume is exactly `|{y:u(y)<=v}|=c_a^n v`. Splitting the integral at v=p yields

`sum_small t theta_i <= c_a^n [integral_0^p dv/p + integral_p^(Rp) dv/v] = c_a^n(1+log R)`.

The full first-hit pool has coefficient mass at least q. Thus the remaining sources carry at least `q-c_a^n(1+log R)/t`. For every remaining d_i>Rp,

`h_m/s_i = c_a (p/(beta d_i))^(1/n) < c_a (beta R)^(-1/n)`.

For every x in the pool halo, its witnessing z lies in every contributing A_i, so x lies in all corresponding cubes enlarged by the common factor `1+c_a(beta R)^(-1/n)`. Integrating the resulting weighted covering inequality over the actual union U gives the report's displayed bound exactly. Null owner sets and arrangement boundaries do not affect these integrals or essential suprema.

With fixed positive c,beta, a>=32n and t=c sqrt(n), positivity of the denominator only permits log R=O(sqrt(n)). Consequently the dilation factor raised to n retains exponential dependence; the report correctly leaves the required joint spatial estimate open.

## Other displayed comparisons

Since d_i r_i is nonincreasing, h_i is nonincreasing. Each finite tuple can use its pool witness at every receiver in H_P; positivity on an open cell makes this valid for the essential supremum. This proves T_k>=1_U.

For the retained comparison, take the latest excluded source l in a pool. Since `r_l>beta+max_i theta_i+q/k`, its witness load through l is strictly below `q-q/k`. Every omitted tuple is supported on indices no later than l. Dividing the corresponding prefix mass by B_P>=q shows that the omitted pool probability is at most `(1-1/k)^k`. The global upper bound on each retained probability sum then gives `|U| <= (D/q+E_k)/(1-rho_k) <= 2D/q+2E_k`, as stated. The argument also covers a pool with no excluded source, where the omitted probability is zero.

Finally the disjoint cells and B_P>=q give `sum_I integral g_I = sum_P |Z_P| <= integral F_final/q = D/q`. This justifies the subtraction term used above.

No changes were made to REPORT.tex or any repository. Only this AUDIT.md was written.
