#!/usr/bin/env python3
"""Whole signed capped error for actual vertex atoms and an affordable uniform cube."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['VECLIB_MAXIMUM_THREADS']='1'
import argparse,json,math,time
from pathlib import Path
from decimal import Decimal,localcontext
import numpy as np
C=1-math.exp(-1)

def vertex_max_log(b):
    b=np.abs(np.asarray(b));n=len(b);floor=float(np.max(np.abs(b-1)));second=np.sort(b+1)
    if floor==0:return math.inf
    logs=n*np.log(2/np.maximum(second,floor))+np.arange(1,n+1)*math.log(2)
    first=n*math.log(2/floor)+int((second<=floor).sum())*math.log(2)
    return max(first,float(logs.max()))

def source_average(b,R):
    n=len(b);R=np.asarray(R);floor=float(np.max(np.abs(b-1)))
    count=(R[:,None]>=b[None,:]+1).sum(axis=1)
    return np.exp(np.where(R>=floor,n*np.log(2/R)+count*math.log(2),-np.inf))

def target_average(b,R):
    R=np.asarray(R)[:,None]
    factors=np.maximum(0,np.minimum(np.minimum(4/R,(1+(4-b[None,:])/R)/2),1))
    return np.prod(factors,axis=1)

def source_rows(b):
    n=len(b);floor=float(np.max(np.abs(b-1)));seconds=sorted(float(t) for t in b+1)
    levels=sorted(set([floor]+[t for t in seconds if t>floor]));prev=0;rows=[]
    for R in levels:
        count=2**sum(t<=R for t in seconds)
        rows.append((R,count-prev));prev=count
    return rows

def exact_source_energy(b):
    n=len(b);q=math.exp(1/n);events=[]
    for R,count in source_rows(b):
        events.extend([(R/q,2**n*count/math.e),(R,-2**n*count)])
    events.sort();coef=0.;value=0.;prev=events[0][0]
    for R,jump in events:
        if R>prev and coef:
            z=coef/prev**n
            value+=z*z*(-math.expm1(2*n*math.log(prev/R)))/2
        coef+=jump;prev=R
    value+=(coef/prev**n)**2/2
    return value

def time_nodes(b,order=8,width_factor=4.):
    n=len(b);q=math.exp(1/n)
    raw=np.r_[np.abs(b-1),b+1,np.abs(b-4),b+4]
    raw=raw[raw>0];cuts=np.unique(np.r_[raw,raw/q]);lower=cuts.min()/2;upper=float(b.max()+4)
    cuts=np.unique(np.r_[lower,cuts[cuts<upper],upper]);s=np.log(cuts)
    width=min(.5,width_factor/n);fine=[s[0]]
    for lo,hi in zip(s[:-1],s[1:]):fine.extend(np.linspace(lo,hi,max(1,int(math.ceil((hi-lo)/width)))+1)[1:])
    fine=np.array(fine);nodes,weights=np.polynomial.legendre.leggauss(order)
    mid=(fine[:-1]+fine[1:])/2;half=(fine[1:]-fine[:-1])/2
    R=np.exp((mid[:,None]+half[:,None]*nodes).ravel());w=(n*half[:,None]*weights).ravel()
    return R,w,lower,upper

def point_energy(b,order=8,width_factor=4.):
    n=len(b);q=math.exp(1/n);R,w,lower,upper=time_nodes(b,order,width_factor)
    a=source_average(b,R);aq=source_average(b,q*R);f=target_average(b,R);fq=target_average(b,q*R)
    ds=aq-a;df=fq-f;error=ds-df
    source=float(w@(ds*ds));target=float(w@(df*df));cross=float(w@(ds*df));total=float(w@(error*error))
    # Both positive massW sources coincide in their average once R≥upper.
    tail=(C*(4/upper)**n)**2/2
    source+=tail;target+=tail;cross+=tail
    exact=exact_source_energy(b)
    return dict(error=total,source=source,target=target,cross=cross,event_source=exact,event_source_relative=abs(source-exact)/max(exact,1e-300),identity_residual=abs(total-(source+target-2*cross)),time_nodes=len(R),lower_halfside=lower,upper_halfside=upper,max_sampled_source_average=float(max(a.max(),aq.max())))

def open_uniform(rng,shape):
    u=rng.random(shape)
    while np.any(u==0):
        z=(u==0);u[z]=rng.random(int(z.sum()))
    return u

def sample_case(n,samples,seed,alphas=(1.,),weights=(1.,),order=16):
    rng=np.random.default_rng(seed);d=n-1;counts=len(alphas);comp=rng.choice(counts,samples,p=weights)
    U=open_uniform(rng,(samples,d));theta=np.ones((samples,n));theta[:,1:]=U**(1/np.array(alphas)[comp,None])
    V=open_uniform(rng,samples);outer=rng.random(samples)>=.5
    logv_ratio=np.where(outer,-np.log(V),np.log(V));r=4*np.exp(logv_ratio/n)
    # q_radial*W=.5 inside and .5*(W/v)^2 outside.
    logprod=np.log(theta[:,1:]).sum(axis=1);terms=np.array([math.log(w)+d*math.log(a)+(a-1)*logprod for a,w in zip(alphas,weights)])
    mx=terms.max(axis=0);logangular=mx+np.log(np.exp(terms-mx).sum(axis=0))
    inverseWq=2*np.exp(np.where(outer,2*logv_ratio,0)-logangular)
    metrics={key:np.zeros(samples) for key in ['error','source','target','cross']};accepted=0;guards=[];extremes=[];minface=math.inf;worst_quad=None;max_abs_quad=0.;max_identity=0.;max_A=0.
    for i in range(samples):
        b=r[i]*theta[i];face=float(np.min(np.abs(b-4)));minface=min(minface,face);logM=vertex_max_log(b)
        if logM>0:continue
        accepted+=1;p=point_energy(b,order);factor=inverseWq[i]
        for key in metrics:metrics[key][i]=p[key]*factor
        guards.append(p['event_source_relative'])
        max_abs_quad=max(max_abs_quad,abs(p['source']-p['event_source']))
        max_identity=max(max_identity,p['identity_residual']);max_A=max(max_A,p['max_sampled_source_average'])
        if worst_quad is None or p['event_source_relative']>worst_quad['relative']:
            worst_quad=dict(x_abs=b.tolist(),relative=p['event_source_relative'],source_gauss=p['source'],source_event=p['event_source'])
        item=dict(x_abs=b.tolist(),theta=theta[i].tolist(),radius=float(r[i]),outer=bool(outer[i]),component=int(comp[i]),log_angular_density=float(logangular[i]),inverse_Wq=float(factor),log_M=logM,source=p['source'],target=p['target'],cross=p['cross'],point_error=p['error'],error_score=p['error']*factor,source_score=p['source']*factor,time_nodes=p['time_nodes'])
        extremes.append(item);extremes.sort(key=lambda t:t['error_score'],reverse=True);del extremes[3:]
    summary={}
    for key,values in metrics.items():
        mean=float(values.mean());se=float(values.std(ddof=1)/math.sqrt(samples))
        summary[key]=dict(mean_over_HW=mean,sample_SE=se,max_score=float(values.max()),contribution_ESS=float(values.sum()**2/np.dot(values,values)) if np.dot(values,values)>0 else 0,top_1percent_fraction=float(np.sort(values)[-max(1,samples//100):].sum()/values.sum()) if values.sum()!=0 else 0)
    strata=[]
    for l,h in [(0,4),(4,5),(5,8),(8,math.inf)]:
        mask=(r>=l)&(r<h)
        strata.append(dict(radius_lower=l,radius_upper=None if math.isinf(h) else h,draws=int(mask.sum()),error_contribution=float(metrics['error'][mask].sum()/samples),source_contribution=float(metrics['source'][mask].sum()/samples)))
    baseline=sum(w for a,w in zip(alphas,weights) if a==1);bound=2*4**n*(6+4*n*math.log(2))/baseline
    assert max_A<=1+1e-9 and minface>0
    return dict(n=n,source_atom_count=2**n,source_atom_mass=4**n,W=8**n,H=1,target_density=1,target_fullside=8,samples=samples,seed=seed,order=order,strata=strata,score_bound=bound,hoeffding95_halfwidth=bound*math.sqrt(math.log(40)/(2*samples)),alphas=list(alphas),weights=list(weights),cap_acceptance=accepted/samples,accepted=accepted,summary=summary,min_receiver_target_face_distance=minface,max_event_source_relative=max(guards,default=0),max_event_source_absolute=max_abs_quad,max_point_identity_residual=max_identity,max_sampled_source_A=max_A,worst_quadrature_receiver=worst_quad,extremes=extremes,scope='Fullspace Lebesgue receiver importance integral of whole signed square; SE is not interval certification.')

def decimal_source_guard(b,precision=100):
    with localcontext() as ctx:
        ctx.prec=precision;n=len(b);bd=[Decimal.from_float(float(t)) for t in b];floor=max(abs(t-1) for t in bd);second=sorted(t+1 for t in bd);levels=sorted(set([floor]+[t for t in second if t>floor]));rows=[];prev=0;maximum=Decimal(0)
        for R in levels:
            count=2**sum(t<=R for t in second);v=(2*R)**n;mass=Decimal(4**n*(count-prev));rows.append((v,mass));prev=count;maximum=max(maximum,Decimal(4**n*count)/v)
        e=Decimal(1).exp();h=1/e;c=1-h;energy=Decimal(0)
        for v,p in rows:
            for w,t in rows:
                small,big=sorted([v,w]);ratio=big/small
                kernel=(2-h-h*ratio*ratio)/(2*big*big) if ratio<=e else -c*c/(2*h*big*big)
                energy+=p*t*kernel
        return maximum,energy

def quadrature_guards(cases):
    rows=[]
    for case in cases:
        receivers=[case['worst_quadrature_receiver']['x_abs']]+[p['x_abs'] for p in case['extremes']]
        for i,b in enumerate(receivers):
            a=point_energy(np.array(b),8);z=point_energy(np.array(b),16);c=point_energy(np.array(b),32)
            weight=receiver_inverse_Wq(b,case)
            rows.append(dict(inverse_Wq_at_machine_receiver=weight,weighted_error8_16=abs(a['error']-z['error'])*weight,weighted_error16_32=abs(z['error']-c['error'])*weight,n=len(b),seed=case['seed'],kind='worst source quadrature' if i==0 else 'large importance error',x_abs=b,energy8=a,energy16=z,energy32=c,error8_16=abs(a['error']-z['error']),error16_32=abs(z['error']-c['error'])))
    return rows

def decimal_extreme_guards(cases):
    rows=[]
    for n in sorted(set(c['n'] for c in cases)):
        top=sorted(((c,t) for c in cases if c['n']==n for t in c['extremes']),key=lambda item:item[1]['error_score'],reverse=True)[:3]
        for case,t in top:
            m80,e80=decimal_source_guard(t['x_abs'],80);m120,e120=decimal_source_guard(t['x_abs'],120)
            with localcontext() as ctx:
                ctx.prec=120;b=[Decimal.from_float(float(x)) for x in t['x_abs']];r=max(b);d=n-1;theta=[x/r for x in b];angularlog=sum(x.ln() for x in theta[1:]);density=sum(Decimal(str(w))*(Decimal(str(a)).ln()*d+(Decimal(str(a))-1)*angularlog).exp() for a,w in zip(case['alphas'],case['weights']));vr=(r/4)**n;inverse=2*(max(Decimal(1),vr)**2)/density
                invrel=abs(Decimal.from_float(t['inverse_Wq'])-inverse)/inverse;energyrel=abs(Decimal.from_float(t['source'])-e120)/max(e120,Decimal('1e-100'));prec=abs(e80-e120)/max(e120,Decimal('1e-100'))
            assert m120<=1
            rows.append(dict(n=n,seed=case['seed'],x_abs=t['x_abs'],actual_decimal_M=str(m120),source_energy_decimal120=str(e120),source_energy80_120_relative=str(prec),float_source_gauss16_relative=str(energyrel),complete_inverse_Wq_relative=str(invrel),scope='Exact machine receiver coordinates, Decimal nearest rounding; not outward interval certification. Target integration separately refined.'))
    return rows

def low_dimensional_integration(order):
    # Independent deterministic true1D cap: G=(-∞,-3]∪[3,∞), symmetryW8.
    nodes,w=np.polynomial.legendre.leggauss(order);total=0.;source=0.;target=0.
    edges=[3,4,5,6,8,12,16,32,64]
    for l,h in zip(edges[:-1],edges[1:]):
        for x,weight in zip((l+h)/2+(h-l)/2*nodes,(h-l)/2*w):
            p=point_energy(np.array([x]),32)
            total+=weight*p['error'];source+=weight*p['source'];target+=weight*p['target']
    # Infinite intervalviax=1/t; Gaussnodesexclude t0.
    for t,weight in zip((nodes+1)/128,w/128):
        p=point_energy(np.array([1/t]),32);total+=weight*p['error']/t**2;source+=weight*p['source']/t**2;target+=weight*p['target']/t**2
    return dict(n=1,spatial_Gauss_order=order,time_Gauss_order=32,error_over_HW=total/4,source_over_HW=source/4,target_over_HW=target/4,scope='Independent deterministic allspace1D cap quadrature, not interval certified; endpoints avoid targetfaces.')

def kappa(n):
    x=math.sinh(1/(2*n))**2
    return n*((1+x)*math.log1p(x)-x*math.log(x))

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--pilot',action='store_true');args=parser.parse_args();start=time.perf_counter();cases=[]
    dims=[1,2,4,8,16] if args.pilot else [1,2,4,8,16,32,64]
    for n in dims:
        samples=128 if args.pilot else (8192 if n<=16 else 16384)
        for seed in ([630000+n] if args.pilot else [633000+n,634000+n]):
            for alphas,weights,offset in [((1.,),(1.,),0),((.5,.7,.85,1.),(.2,.3,.25,.25),10000)]:
                c=sample_case(n,samples,seed+offset,alphas,weights);cases.append(c)
                print(n,c['seed'],alphas,'error',c['summary']['error']['mean_over_HW'],'SE',c['summary']['error']['sample_SE'],'source',c['summary']['source']['mean_over_HW'],flush=True)
    gate=gate_borderline_guards(cases)
    for c in cases:
        for key in ['contribution_ESS','top_1percent_fraction']:c['summary']['cross'].pop(key,None)
    guards=quadrature_guards(cases);decimal=decimal_extreme_guards(cases);low=[low_dimensional_integration(q) for q in [16,32,64]]
    out=dict(cases=cases,gate_borderline_guards=gate,quadrature_guards=guards,decimal_extreme_guards=decimal,independent_1D_allspace=low,spectral_target_bounds=[dict(n=n,entire_space_target_energy_over_HW_upper=kappa(n),scope='Analytic generalL2 squared operator constant; capped target energy also belowthis in exact arithmetic. Finite MCestimates needuncertainty.') for n in dims],scope='Whole actual capped signed error for vertex source and height1 uniform target[-4,4]^n; no general theorem.',normalization='μ=4^nΣverticesδ,H1,W8^n,F=1[-4,4]^n; du=n dR/R,q=e^(1/n).',proposal='Fullspace cube-cone radialvolumev: halfWU,halfW/U,Uopen(0,1); independent fixedangularmixture evaluatedcompletely. Allsigns/faces reduced by exact source/target symmetry.',time_scope='Allatom/targetface arrivalcuts andshiftedcuts, positiveGausslogR subintervalwidth≤min(.5,4/n). Signederror exactlyvanishesafterfullmasscapture; source/target/cross equal tailsaddedseparately. No spatialtruncation.',limits=['Machine random draws approximate continuous law; no machine-unbiasedness certificate.','SampleSE and contributionESS diagnose rareevents; no finite-variance inference from observingmoderate scores.','Hoeffding bound follows uniformangularbaseline and sourcecap/targetvariation plusfarfield Jensen; exponentially wide.','Decimalchecks use nearest rounding; target integrals are refined, not intervalcertified.','Only actualvertexsource tested here; no general source bound, exponentfit, or restricted upperprogress.'],counts=dict(cases=len(cases),receivers=sum(c['samples'] for c in cases),gate_borderline_guards=len(gate),quadrature_guards=len(guards),decimal_extreme_guards=len(decimal),independent1D=len(low)))
    Path(__file__).with_name('results.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n');print('runtime_seconds',time.perf_counter()-start,flush=True)


def receiver_inverse_Wq(b,case):
    b=np.array(b);n=len(b);r=float(b.max());theta=b/r;lp=float(np.log(theta[1:]).sum())
    terms=np.array([math.log(w)+(n-1)*math.log(a)+(a-1)*lp for a,w in zip(case['alphas'],case['weights'])]);mx=terms.max();angular=mx+math.log(float(np.exp(terms-mx).sum()))
    return 2*math.exp(max(0,2*n*math.log(r/4))-angular)

def decimal_gate(b,precision):
    with localcontext() as ctx:
        ctx.prec=precision;n=len(b);bd=[Decimal.from_float(float(x)) for x in b];floor=max(abs(x-1) for x in bd);second=sorted(x+1 for x in bd)
        levels=sorted(set([floor]+[x for x in second if x>floor]));return max(Decimal(2**n)*Decimal(2**sum(x<=R for x in second))/R**n for R in levels)

def gate_borderline_guards(cases):
    rows=[]
    for c in cases:
        n=c['n'];samples=c['samples'];rng=np.random.default_rng(c['seed']);comp=rng.choice(len(c['alphas']),samples,p=c['weights']);U=open_uniform(rng,(samples,n-1));theta=np.ones((samples,n));theta[:,1:]=U**(1/np.array(c['alphas'])[comp,None]);V=open_uniform(rng,samples);outer=rng.random(samples)>=.5;ratio=np.where(outer,-np.log(V),np.log(V));r=4*np.exp(ratio/n)
        closest={True:None,False:None};margin=math.inf
        for i in range(samples):
            b=r[i]*theta[i];logM=vertex_max_log(b);accepted=logM<=0;margin=min(margin,abs(logM));old=closest[accepted]
            if old is None or abs(logM)<abs(old['float_log_M']):closest[accepted]=dict(x_abs=b.tolist(),float_log_M=logM,float_accepted=accepted)
        c['minimum_absolute_float_gate_logmargin']=margin
        for accepted,t in closest.items():
            if t is None:continue
            m80=decimal_gate(t['x_abs'],80);m120=decimal_gate(t['x_abs'],120);match=(m120<=1)==accepted
            assert match
            with localcontext() as ctx:
                ctx.prec=120;diff=abs(m80-m120)/m120
            rows.append(dict(n=n,seed=c['seed'],minimum_case_absolute_logmargin=margin,decimal_M80=str(m80),decimal_M120=str(m120),precision_relative=str(diff),classification_matches=match,scope='Closest retained point on each side among all original receivers; Decimal nearest rounding, not certification of all floating gates.',**t))
    return rows

if __name__=='__main__':main()
