# Round 63: exact positive-cap compression and nonlocal signed-error obstructions

2026-10-11. The objective C_n^square <= sqrt(n) n^{o(1)} remains **UNPROVED**.
The retained fully general benchmark is O(n log n). No finite numerical
experiment here establishes an upper bound for arbitrary inputs.

This round tests two general routes after Round62 disproved polynomial
height on the original cap-distance supports. First, it precisely realizes
a nonlocal reset-to-good-set chain and disproves polynomial occupation and
height for that mechanism. Second, it compresses all original-good-set
cube constraints on a fixed atomic support into a finite capacity problem,
providing an explicit optimized covering interface for the signed dual.
The latter remains unpaid. The examples test general proposed interfaces;
they are not replacements of the original task by special-family bounds.

Global bounded-density target existence alone is elementary and is not
the missing theorem. The difficult requirement is a source-uniform budget
for its full signed error on the ORIGINAL good receivers, followed by the
actual weak-type and all-scale return. Large displacement, density norm,
or occupation does not imply large signed error or a weak-type lower bound.

## Reproduction and arithmetic scope

Extract this five-member archive to a temporary directory, preserve
results.json under another name, then run `python3 -B nonlocal_probe.py`
with NumPy installed. The final default writes results.json beside itself;
do not use --pilot for final reproduction. The verified environment was
Python 3.12.14 and NumPy 2.3.5, with BLAS threads set to one by the script.
Supplementary standard-library and NumPy programs are embedded below;
save each under the stated name to reproduce the additional results.
Analytic proofs, exact integer/Fraction checks, nearest-rounded Decimal
checks, floating quadrature, and sampling evidence are kept distinct.

## Reloaded skill scope

All 64 current installed SKILL.md entries (277108 bytes) were reloaded and
their execution/failure-handling sections reread. All entry hashes match
the previously fully read Round55 baseline; all 437 direct local links
exist. Relevant current method/interface/provenance files were reread by
the assigned researchers. No claim that every external PDF was reread or
that all skill mathematics is certified is made. J03's current shared
ledger resolves successfully, but its historical revision hash is not the
current installed entry hash; it is used only as conditional audit data.
No general CTMC, partial-balayage, infinite-dimensional Farkas, or minimax
theorem is imported into the new proofs.

# Round 63: reset-to-source exit flattening has exponential occupation and height

2026-10-11. This note rigorously obstructs a specific adaptive nonlocal interface: propose a uniform jump of radius \((3/2)\operatorname{dist}(y,G)\), reset to the same source on rejection, and accept only endpoints in the original good set. Even at this displacement factor, where unrestricted allocation for the vertex source has height \(H\), the reset exit algorithm has occupation mass at least \(W e^{cn}\) and terminal height at least \(H e^{cn}/4\), with explicit \(c>0\). The conclusion is about this reset process, not a moving walk, general partial balayage, or the desired cube weak estimate.

## Correct baseline and current interfaces

For every finite positive measure of mass \(W\), global target existence at height \(\beta H\) is elementary: set \(F=\mu*k_R\), where \(k_R\) is the normalized cube kernel of full side \(R\) and \(R^n=W/(\beta H)\). Then \(F\le\beta H\), \(\int F=W\), and the retained sharp theorem gives \(\|DF\|_2^2\le\kappa_n\beta HW\). No target-existence difficulty is claimed here.

The current disk J03, E01, D01 and H05 skills, with their method and centered-cube interface files under /Users/zhengzhihao/.codex/skills, were re-read. J03 requires actual exit locations, including jump overshoot. E01 requires actual process realization rather than merely a weak flow LP. D01 separates positive marginals from signed/vector/path interfaces. H05 requires proved independence and the actual mgf. Those conditions are verified directly below for a discrete reset chain and a product-uniform proposal. No external CTMC, diffusion, general transport, or obstacle theorem is imported.

## A realized general reset-chain identity

Take finite positive atomic \(\mu=\sum_i p_i\delta_{y_i}\) and the original gate \(G=\{M\mu\le H\}\). Let \(k_i\) be probability densities, and assume
\(\epsilon_i=\int_G k_i(z)\,dz>0\).
From source \(y_i\), repeatedly sample independent proposals from \(k_i\). If a proposal lies in \(G\), absorb there; otherwise reset to the same \(y_i\). This is a genuine discrete process, with geometric attempt count of mean \(1/\epsilon_i\), finite almost sure absorption, and terminal density
\[
F_i(z)=\frac{p_i}{\epsilon_i}\mathbf1_G(z)k_i(z),\qquad
F=\sum_iF_i,\qquad \int F=W.
\]
The positive coupling is \(\pi=\sum_i\delta_{y_i}(dy)F_i(z)\,dz\). Its two marginals are \(\mu\) and \(F\,dz\). Define transient occupation
\[
\eta=\sum_i\frac{p_i}{\epsilon_i}\delta_{y_i},
\]
and the one-step kernel from these source states
\[
P(y_i,dz)=(1-\epsilon_i)\delta_{y_i}(dz)+\mathbf1_G(z)k_i(z)\,dz.
\]
Then the exact signed flow identity is
\[
\boxed{\mu-F\,dz=\eta-P^*\eta.} \tag{1}
\]
Both sides have mass zero; \(P\) is mass preserving. This is checked directly coefficient by coefficient, not inferred from an occupation LP. Therefore, for \(D_\sigma(x,u)=A_{qL}\sigma(x)-A_L\sigma(x)\), \(q=e^{1/n}\), \(u=n\log L\),
\[
D_\mu-D_F=D_\eta-D_{P^*\eta}. \tag{2}
\]
The identity holds against bounded test functions. On a finite scale-time window, every finite signed measure maps into spatial L2 by the kernel L2 bound, so (2) is also a genuine L2 identity there. The all-time norm requires a separate integrability estimate; it is not assumed finite. This is a signed-error identity, not an energy estimate. In particular neither (1) nor the positivity of occupation makes the mixed terms orthogonal.

For the counterexample below every \(\epsilon_i>0\), so the process and occupation are genuinely finite. For general proposed kernels, \(\epsilon_i>0\) must be verified separately; it is not silently asserted for every source.

## Vertex source and a repaired displacement scale

Use the Round 62 vertex source
\[
y_\varepsilon=d\varepsilon,\quad p=H(4d)^n,\quad
\varepsilon\in\{-1,1\}^n,\quad W=H(8d)^n.
\]
Its original source distances are exactly \(r_\varepsilon=2d\): the single-atom pole forces the lower bound, and \(g_\varepsilon=3d\varepsilon\) is good since it captures its own atom at radius \(2d\), all other atoms at radius \(4d\), and both corresponding averages equal \(H\). Set
\[
J_\varepsilon=y_\varepsilon+[-3d,3d]^n,\qquad
k_\varepsilon=(6d)^{-n}\mathbf1_{J_\varepsilon}.
\]
These are jumps of radius \((3/2)r_\varepsilon\), not the already-obstructed radius-one construction. Without the acceptance restriction \(z\in G\), an allocation of height \(H\) is possible: assign each source its matching orthant of \((-4d,4d)^n\).

Each proposal has a positive probability of entering \(G\). At \(x=(3d+t)\varepsilon\), \(0<t<d\), the only capture radii are \(2d+t\) and \(4d+t\); both maximal averages are strictly less than \(H\). This persists in an open neighborhood contained in \(J_\varepsilon\). Hence \(\epsilon_\varepsilon>0\). Reflection symmetry of the entire original source and gate makes their probabilities a common \(\epsilon\).

## Exact binomial escape obstruction

For \(\varepsilon=(1,\ldots,1)\), write \(X\) for a uniform point of \(J_\varepsilon\). Its coordinates are independent uniform variables on \([-2d,4d]\). A cube centered at \(X\) of radius \(3d\) always captures the all-positive source vertex. It also captures the opposite sign in coordinate \(j\) exactly when \(X_j\le2d\). Therefore it captures exactly \(2^{K(X)}\) vertices, where
\[
K(X)=\#\{j:X_j\le2d\}\sim\operatorname{Bin}(n,2/3).
\]
If \(X\in G\), that single tested average must satisfy
\[
2^{K(X)}H(2/3)^n\le H,\qquad
K(X)\le an,\qquad a=\log_2(3/2).
\]
Consequently
\[
\epsilon\le T_n
=3^{-n}\sum_{k=0}^{k_n}\binom nk2^k,\qquad
k_n=\max\{k:2^{k+n}\le3^n\}. \tag{3}
\]
This is an exact necessary condition for good-set membership, not a claimed exact description of \(G\). Since \(a<2/3\), \(T_n\) has an exponential upper bound.

For completeness, independence gives \(E e^{\theta K}=(1-q+qe^\theta)^n\), \(q=2/3\). For \(\theta<0\), Markov's inequality gives
\[
P(K\le an)\le
\exp\{n[\log(1-q+qe^\theta)-\theta a]\}.
\]
Optimizing at \(e^\theta=a(1-q)/(q(1-a))<1\) yields
\[
\epsilon\le T_n\le e^{-n c},\qquad
c=D(a\Vert2/3)>0, \tag{4}
\]
where
\(D(a\Vert q)=a\log(a/q)+(1-a)\log((1-a)/(1-q))\).
Positivity follows because this function has its unique minimum zero at \(a=q\), with second derivative \(1/[a(1-a)]>0\). The strict inequality \(a<2/3\) itself follows from \((3/2)^3<2^2\). Numerically \(c\approx0.01450754624808195538\), an illustration rather than a certified interval.

Thus this actual reset chain has
\[
\boxed{\|\eta\|=\frac W\epsilon\ge W e^{nc}.} \tag{5}
\]
Exponential occupation here is a statement about repeated proposals from the same source. No such conclusion is drawn for a walk that moves to rejected positions. Occupation mass alone does not lower-bound the signed energy: a large occupation measure could still be multiplied by small or cancelling one-step errors.

## Terminal height is also exponential at factor \(3/2\)

Let \(n\ge2\),
\[
m=k_n-1=(3^n).\operatorname{bit\_length}()-n-2,\qquad
s=4-1/n,
\]
and take receiver \(x\) with \(m\) coordinates zero and \(n-m\) coordinates \(sd\). It has exactly two capture radii: \((s-1)d\), capturing the \(2^m\) vertices whose high coordinates are positive; and \((s+1)d\), capturing all vertices. Since \(2^m/(3/2)^n\le1/2\) and Bernoulli gives \((1-1/(3n))^n\ge2/3\), the first average satisfies
\[
\frac{A_{2(s-1)d}\mu(x)}H
=2^m[2/(s-1)]^n
=\frac{2^m/(3/2)^n}{(1-1/(3n))^n}\le3/4.
\]
The full capture gives \([4/(s+1)]^n<1\). Therefore \(M\mu(x)<H\). Exactly \(2^m\) of the source jump cubes contain \(x\) in their interiors. The strict maximal-average gap and jump-cube containment inequalities persist in an open neighborhood, so this is an essential-supremum witness, not a pointwise boundary artifact.

On that neighborhood the algorithm's total terminal density is
\[
F(x)=\frac{2^m p}{\epsilon(6d)^n}
=\frac H\epsilon\,2^m(2/3)^n.
\]
The floor inequality gives \(2^m/(3/2)^n>1/4\). Hence
\[
\boxed{\operatorname*{ess\,sup}F\ge\frac H{4\epsilon}
\ge \frac H4 e^{nc}.} \tag{6}
\]
More precisely (3) supplies the exact rational lower certificate
\[
\frac{\operatorname*{ess\,sup}F}{H}
\ge \frac{2^{m+n}}{\sum_{k=0}^{k_n}\binom nk2^k}. \tag{7}
\]
The same rejection interface therefore fails both polynomial occupation and polynomial terminal height, at a radius where unrestricted displacement-only allocation has height \(H\). This is the new obstruction beyond Round 62.

## Scope and remaining error question

For a general proposal radius \(R=2\alpha d\), \(\alpha>1\), the same fixed-radius test gives \(K\sim\operatorname{Bin}(n,1-1/(2\alpha))\) and \(G\) implies \(K\le n\log_2\alpha\). Hence reset occupation is exponentially large whenever
\(\log_2\alpha<1-1/(2\alpha)\).
The two sides cross at a unique \(\alpha_*>1\), because their difference has positive derivative \(1/(\alpha\log2)-1/(2\alpha^2)\) for \(\alpha>1\). Exact rational comparisons place \(\alpha_*\) between \(8/5\) and \(13/8\); illustratively \(\alpha_*\approx1.6133875940\). No height conclusion beyond (6) is asserted from this general escape estimate alone.

The operator identity (2) supplies neither an affordable occupation payment nor the capped signed-energy budget. The proved counterexample shows that this reset-to-good-set algorithm cannot provide the required general affordable replacement. A moving, accumulating, obstacle, or other redistribution scheme would need an independently proved terminal-height bound and an actual signed-energy payment on the original gate. The current work establishes no all-source capped-energy upper estimate, and does not describe mere target existence as the missing lemma.

## Moving-chain flow identity with the finite-time remainder

For any specified Markov chain with transition kernel \(K\), killed upon entering the original \(G\), put \(Q(y,dz)=\mathbf1_\Omega(z)K(y,dz)\), \(R(y,dz)=\mathbf1_G(z)K(y,dz)\), and \(\nu_j=(Q^*)^j\mu\). Let
\[
\eta_N=\sum_{j=0}^{N-1}\nu_j,\qquad F_N=R^*\eta_N.
\]
The exact finite-time identity is
\[
\boxed{\mu-F_N=\eta_N-K^*\eta_N+\nu_N.}
\]
The surviving mass \(\nu_N\) is a necessary boundary term. If \(\sum_j\|\nu_j\|<\infty\), then finite occupation gives \(\nu_N\to0\) in total variation, \(\eta_N\to\eta\), and \(F_N\to F=R^*\eta\), so
\(\mu-F=\eta-K^*\eta\) and \(\|F\|=W\). This is proved by telescoping the actual chain, not by recovering a process from a weak occupation LP. Without these hypotheses the finite-\(N\) remainder must be retained. The identity holds in L2 after applying \(D\) on finite scale windows; a full-time square estimate again requires its own integrability and budget proof. The endpoint measure \(F\) need not have a bounded density. This gives the exact bookkeeping for a moving scheme while leaving its exit, height and signed-energy questions open.

## Independent exact checks

At \(d=H=1\), actual vertices and receiver distances were enumerated in dimensions \(2,\ldots,8\). All seven checks found precisely the two capture radii, count \(2^m\) at the first, the stated strict good-set inequalities, and exactly \(2^m\) containing jump cubes. Tensor formulas and exact Fraction binomial tails were checked for \(n=2,3,4,8,16,32,64,128,256,512,1024,4096\). All 12 checks verified the integer threshold, rational height bound, and good receiver inequalities. Decimal computations at precision 80 and 140 agreed through the displayed rate prefix; this is not an interval claim. These finite checks supplement the proof and do not replace it.

## Standalone independent reproduction

```python
from fractions import Fraction as F
from itertools import product
from math import comb
from decimal import Decimal,localcontext
import json
small_checks=0
for n in range(2,9):
    m=(3**n).bit_length()-n-2
    s=F(4)-F(1,n)
    x=(F(0),)*m+(s,)*(n-m)
    vertices=list(product([-1,1],repeat=n))
    distances=[max(abs(a-b) for a,b in zip(x,v)) for v in vertices]
    assert set(distances)=={s-1,s+1}
    assert distances.count(s-1)==2**m
    assert sum(all(abs(a-b)<3 for a,b in zip(x,v))
               for v in vertices)==2**m
    assert F(2**m)*(F(2)/(s-1))**n<=F(3,4)
    assert (F(4)/(s+1))**n<1
    small_checks+=1
dims=[2,3,4,8,16,32,64,128,256,512,1024,4096]
for n in dims:
    m=(3**n).bit_length()-n-2
    cutoff=m+1
    assert 2**(cutoff+n)<=3**n<2**(cutoff+n+1)
    total=sum(comb(n,k)*2**k for k in range(cutoff+1))
    T=F(total,3**n)
    height=F(2**(m+n),total)
    assert 0<T<1 and height>F(1,4)/T
    s=F(4)-F(1,n)
    assert F(2**m)*(F(2)/(s-1))**n<=F(3,4)
    assert (F(4)/(s+1))**n<1
values=[]
for precision in [80,140]:
    with localcontext() as context:
        context.prec=precision
        a=Decimal('1.5').ln()/Decimal(2).ln()
        q=Decimal(2)/3
        D=a*(a/q).ln()+(1-a)*((1-a)/(1-q)).ln()
        values.append(str(D)[:42])
assert values[0]==values[1]
assert 8**16<2**11*5**16
assert 13**13>2**9*8**13
print(json.dumps({'actual_small_vertex_checks':small_checks,
       'exact_tensor_tail_checks':len(dims),'large_n':dims[-1],
       'Decimal_rate_common_prefix':values[0],
       'interval_claim':False},sort_keys=True))
```


## The actual reset acceptance probability: a positive finite recursion

This calculation evaluates the original good set, not merely the binomial
necessary condition used in the exponential obstruction. Normalize d=H=1
and propose X uniformly in [-2,4]^n from the all-positive vertex. The
coordinates B_i=|X_i| are independent, with continuous distribution function
F(t)=t/3 for 0<=t<=2 and F(t)=(t+2)/6 for 2<=t<=4.

For completeness, the actual vertex halo has the exact description
E_k={max_i B_i<1+R_k, B_(k)<R_k-1}, R_k=2*2^(k/n),
for 1<=k<n, together with E_0={max_i B_i<3} and E_n contained
in E_0. Here B_(k) is the k-th smallest coordinate. Boundary equalities
have proposal probability zero. To see this, a radius R captures at least
one vertex exactly when R>=max_i|B_i-1|; once this holds its captured count
is 2 to the number of coordinates with B_i+1<=R. If an average exceeds one
with k doubled coordinates, then R<R_k, all B_i<1+R_k, and the k smallest
are <R_k-1. Conversely these strict inequalities permit R<R_k capturing
at least 2^k vertices. This proves the union formula directly from the
actual cube counts.

Condition on the maximum r=max B_i. Its density is n F(r)^(n-1)/6
on 3<r<4. Its maximizing index is unique almost surely. The other n-1
coordinates are conditionally independent with distribution F(t)/F(r)
for 0<=t<=r. This statement means the regular conditional law obtained
from the joint density of the maximum and its index; it does not condition
on a positive-probability equality event.

Put c_k=R_k-1<3 and t_k(r)=F(c_k)/F(r), for k=1,...,n-1.
The maximum coordinate never enters these thresholds. Good-set membership
requires the count among the other coordinates below c_k to be <k whenever
r<1+R_k; no condition is imposed at that k otherwise.

Start with alive mass s_0(0)=1. On moving from threshold t_(k-1) to t_k,
given j coordinates already below the old threshold, the number of newly
entered coordinates is Bin(n-1-j,(t_k-t_(k-1))/(1-t_(k-1))). Propagate all
nonnegative state masses, then set masses at counts >=k to zero if k is
eligible. Prior survival depends only on coordinates below the old
threshold, so the remaining conditional coordinates retain this binomial
transition. The sum of surviving masses after the last threshold is P_n(r).
No subtraction of an almost-one killed probability is necessary. Thus

    epsilon_n = integral_3^4 [n/6] F(r)^(n-1) P_n(r) dr.

This is an exact finite expression in exact arithmetic. Split the integral
at the eligible endpoints 1+R_k in (3,4). On each open segment the count
constraints are fixed. A surviving multinomial cell has probabilities
given by differences of F(c_k)/F(r), and the last cell has probability
(F(r)-F(c_(n-1)))/F(r). Multiplication by F(r)^(n-1) cancels the denominator.
The resulting integrand is a polynomial in the affine function F(r), of
degree at most n-1. Therefore Gauss quadrature with q>=ceil(n/2) integrates
each segment exactly in exact arithmetic. Rounded nodes, coefficients,
algebraic breakpoints, and arithmetic prevent interpreting the present
floating implementation as an interval certificate.

For n=1 the accepted proposal interval is [3,4], giving epsilon_1=1/6.
For n=2, the core bad square contributes area 25 inside the proposal
square of area 36. The two extra disjoint arms each have area
(2*sqrt(2)-2)*(4*sqrt(2)-2); their combined area is 40-24*sqrt(2).
Thus epsilon_2=(24*sqrt(2)-29)/36. This supplies an independent closed-form
check of the recursion.

The program reset_exit_probe.py uses two Gauss orders at n=1,2,4,8,16,32,64,
plus two independent seeds per dimension (8192 samples per seed below 16;
32768 at 16,32,64), totaling 262144 independent proposal draws.
All 14 observed sampling discrepancies from the deterministic values are
less than 0.359 times their ideal-law Hoeffding halfwidths; this is a
finite diagnostic, not certification of the floating integral.
The largest order discrepancy is 8.33e-17. At n=64,
epsilon is approximately 0.04805552550, expected attempts 20.80926157,
and the explicit terminal-height witness is approximately 7.68238262 H.
The binomial necessary-condition upper bound is approximately 0.08699387,
which is strictly larger, as required. None of these finite values is used
to fit or guess an asymptotic exponent. The exponential obstruction rests
on the analytic Chernoff proof and exact rational certificates instead.

Monte Carlo uses the actual grouped arrival maximum. Its Hoeffding error
bound describes ideal independent uniforms and exact membership; its
sample standard error is only diagnostic. Neither machine sampling nor
all floating membership decisions have a certified error budget. The
recorded minimum distance from the floating threshold does not remedy
that missing certification. This probability calculation tests a proposed
general mechanism and is not a restricted-family upper-bound substitute.


# Round 63: positive-cap compression and two signed-dual obstructions

This audit supplies three proved structural facts: exact compression of all positive cube constraints to a finite capacity problem on a fixed atomic support; a nonzero signed approximation floor for every bounded nonlocal target of a single atom; and a logarithmic atom-number loss for the canonical positive-part certificate even after its global-mass correction. No source-uniform subpolynomial upper budget is proved, and no weak-type counterexample is claimed.

## Current skills and definitions

The current B01, B02, F05, and L03 `SKILL.md`, `references/method.md`, and `references/cube-interface.md` files were reread from disk. B01 is used only for finite-dimensional Farkas separation, with signs and a proof below. B02 forbids treating sampled cubes as all constraints. F05 distinguishes the actual signed Hilbert quadratic from its positive majorants. L03 distinguishes exact algebraic conclusions from floating evidence. No external theorem or numerical conclusion is imported.

Let \(\mu=\sum_{i=1}^Np_i\delta_{y_i}\), \(W=\sum_i p_i>0\), \(H>0\), and use its original good set \(G=\{M\mu\le H\}\). Set
\[
 A_u\nu(x)=e^{-u}\nu(Q_u(x)),\quad
 Q_u(x)=x+[-e^{u/n}/2,e^{u/n}/2]^n,\quad
 D_\nu=A_{u+1}\nu-A_u\nu.
\]
The actual capped Hilbert space is \(\mathcal Y=L^2(G\times\mathbb R,dx\,du)\), with \(b=D_\mu|_G\), \(TF=D_F|_G\). The finite-source proof from Round61 gives \(b\in\mathcal Y\). The retained spectral bound is \(\|TF\|^2\le\kappa_n\|F\|_2^2\), \(\kappa_n\le3\log(n+2)/n\).

For bounded compactly supported receiver/time tests \(h\), extend \(h\) by zero in time and define
\[
 g(x,u)=h(x,u-1)-h(x,u),\qquad
 a(y)=\int_G\int g(x,u)e^{-u}\mathbf1_{Q_u(x)}(y)\,du\,dx.
\]
Finite-time Fubini and a time shift give \(a=T^*h\) pointwise, \(\int a\,d\mu=\langle b,h\rangle\). These tests are dense in \(\mathcal Y\), and the adjoint extends in \(L^2\). Pointwise atom evaluations below are initially made only for these finite tests.

## 1. All positive cap constraints on fixed atoms have a finite exact compression

For each nonempty atom-index pattern \(I\) that is realized by a closed cube centered in \(G\), define
\[
 c_I=\inf\{|Q(x,r)|:x\in G,\ r>0,
            \{i:y_i\in Q(x,r)\}=I\}.
\]
There are finitely many patterns, at most \(2^N-1\). Each retained \(c_I\) is finite and strictly positive. Indeed original cap feasibility gives \(p_I\le H|Q|\) for every realizing cube, hence \(c_I\ge p_I/H>0\). No infimum attainment or continuity of the pattern map is assumed.

For a nonnegative weight vector \(t\), **all** its positive cube cap constraints on the fixed receiver set are equivalent to the finite constraints
\[
 \sum_{i\in I}t_i\le c_I\quad\text{for every realized }I.
\]
One direction follows by taking the infimum of the relevant volumes; the other uses \(c_I\le|Q|\) for every realizing cube. Empty patterns impose no condition. Add the mass constraint \(\sum_i t_i\le m\), where \(m=W/H\). The actual vector \(t_i=p_i/H\) is feasible. This freezes \(G\) for the capacity problem: alternative weights are constrained on this same receiver set, not on a recomputed good set.

Write the finite rows as \(v_J\in\{0,1\}^N\), with capacities \(\gamma_J\): pattern rows have \(v_I=\mathbf1_I\), \(\gamma_I=c_I\), and the mass row has \(v_0=\mathbf1\), \(\gamma_0=m\). For any real \(w\in\mathbb R^N\), define the positive-cover cost
\[
 \mathcal C(w)=\min_{\theta_J\ge0}
 \left\{\sum_J\gamma_J\theta_J:
       \sum_J\theta_Jv_J\ge w\text{ coordinatewise}\right\}.
\]
Then exactly
\[
 \boxed{\mathcal C(w)=\max_{t\ge0,\ v_J\cdot t\le\gamma_J}t\cdot w.}
\]

Weak duality follows by multiplying the coordinate majorant by \(t\). For the reverse inequality use the finite cone generated by \((v_J,\gamma_J)\), \((-e_i,0)\), and \((0,1)\). Its membership condition for \((w,r)\) is precisely a cover with cost at most \(r\). It is a closed finitely generated cone. For \(r<\mathcal C(w)\), finite Farkas separation gives a functional \((-t,\tau)\) nonnegative on its generators and negative at \((w,r)\). Thus \(t\ge0\), \(\tau\ge0\), and \(v_J\cdot t\le\tau\gamma_J\). The mass row implies that \(\tau=0\) forces \(t=0\), which cannot strictly separate; hence \(\tau>0\). Normalize it to one to get feasible \(t\) with \(t\cdot w>r\). Let \(r\uparrow\mathcal C(w)\), using compactness of the feasible weight polytope. The cover minimum also exists: the mass row makes a cover feasible, all capacities are positive, and a bounded-cost sublevel bounds every coefficient. This proves the exact finite equality without an infinite-dimensional strong-duality claim.

In particular
\[
 \int a\,d\mu-\lambda W
 \le H\mathcal C\bigl((a(y_i)-\lambda)_{i=1}^N\bigr),\qquad\lambda\ge0.
\]
Each pattern coefficient is a positive combination of actual cube constraints with cost arbitrarily close to its infimum; the mass row is the separate global mass constraint. Thus this is a concrete positive cap-certificate problem, rather than an unspecified multiplier space. The reduction is exact but potentially exponential in atom number, and computing the geometric infima still requires all-center/all-radius certification.

## 2. What a paid positive-cover theorem would have to prove

The retained signed distance dual at total height \(\rho=\beta H\) is
\[
 d^2=\sup_{h,\lambda\ge0}
 \left[2\int a\,d\mu-\|h\|^2-2\lambda W
              -2\beta H\int(a-\lambda)_+\right].
\]
The compressed cover gives the genuine upper bound on each dual objective
\[
 2H\mathcal C((a(y_i)-\lambda)_i)-\|h\|^2
       -2\beta H\int(a-\lambda)_+.
\]
Consequently the following independent certificate theorem would suffice:
\[
 \mathcal C((a(y_i)-\lambda)_i)
 \le\beta\int(a-\lambda)_+
        +\frac{\|h\|^2}{2H}+\frac{\varepsilon_nW}{2}
 \quad\text{for every finite test }h\text{ and every }\lambda\ge0.
\]
It would imply \(d^2\le\varepsilon_nHW\), first for dense finite tests and then for the full dual. The cover is an upper relaxation of the actual source pairing, so this sufficient condition can be stronger than the original distance estimate. No such dimension-uniform cover theorem is proved here. Its explicit geometry, threshold defect, and quadratic allowance are the exact unpaid interface.

## 3. A nonlocal signed-error floor forced by arrival jumps

**Lemma (bounded densities are log-volume Lipschitz).** If \(0\le F\le\rho\), then for \(s\ge0\),
\[
 |A_{u+s}F(x)-A_uF(x)|\le\rho(1-e^{-s})\le\rho s,
 \qquad |D_F(x,u+s)-D_F(x,u)|\le2\rho s.
\]
The nested cube shell has volume \(e^{u+s}-e^u\), so its mass is between zero and \(\rho(e^{u+s}-e^u)\). Writing the later average as \(e^{-s}A_u\) plus the normalized shell mass gives both one-sided bounds; the second inequality is the difference of two such averages. This proof uses no source geometry, support restriction, coupling, or differentiability of \(F\).

**Theorem (one-atom signed projection floor).** Let \(\mu=p\delta_y\), use its true \(G\), and assume \(\rho=\beta H\ge H\). Every positive density \(F\le\rho\), with arbitrary support and mass, satisfies
\[
 \boxed{\|D_\mu-D_F\|_{L^2(G\times\mathbb R)}^2\ge\frac{Hp}{180\beta}.}
\]

**Proof.** Put \(q=e^{-1}\), \(c=1-q\), \(v=(2\|x-y\|_\infty)^n\), \(u_0=\log v\), and \(a_0=p/v\). On the receiver annulus \(p/H\le v\le2p/H\), the receiver is good, and \(H/2\le a_0\le H\le\rho\). For \(0<t<1\), the two sides of the downjump are
\[
 D_\mu(x,u_0-t)=q a_0e^t,\qquad
 D_\mu(x,u_0+t)=-c a_0e^{-t}.
\]
Let \(\delta=a_0/(15\rho)\le1/15\). For \(0<t<\delta\), their difference is at least \(a_0e^{-t}\ge14a_0/15\), while the target's difference in these two times has magnitude at most \(4\rho t\le4a_0/15\). Thus the two error values differ by at least \(2a_0/3\), and the sum of their squares is at least \(2a_0^2/9\). Integrating the paired interval yields
\[
 \int_{\mathbb R}|D_\mu-D_F|^2du\ge\frac{2a_0^3}{135\rho}.
\]
The pushforward of Lebesgue measure under \(v\) is \(dv\), since \(|\{x:v(x)\le z\}|=z\). Therefore
\[
 E_{\rm error}\ge\frac{2p^3}{135\rho}
 \int_{p/H}^{2p/H}v^{-3}dv
 =\frac{H^2p}{180\rho}=\frac{Hp}{180\beta}.
\]
The source time endpoints are null and do not affect the paired integration. \(\square\)

This lower bound holds in particular for every positive exact-mass nonlocal target, so it bounds the optimized distance. It rules out a zero-error bounded-density representation at every finite ceiling. It does not rule out the desired upper bound: at \(\beta\asymp n\) the floor is only \(\asymp Hp/n\).

By the exact projection dual, the zero-defect domination
\(\int a\,d\mu\le\lambda W+\beta H\int(a-\lambda)_+\)
cannot hold for every adjoint test and threshold even for a single atom. Otherwise every dual objective would be at most \(-\|h\|^2\), forcing \(d=0\). Dense bounded compact tests suffice for this contradiction because the support function is continuous in \(h\). A quadratic or other nonzero error allowance is indispensable; the theorem quantifies one necessary allowance.

## 4. Exact finite-time positive certificates and the global-mass correction

For finite tests, the pointwise majorant
\[
 a(y)\le\int_G\int g(x,u)_+e^{-u}\mathbf1_{Q_u(x)}(y)\,du\,dx
\]
is valid. Integrating against the actual source and using every original cap gives the certificate
\[
 \int a\,d\mu\le H\int_G\int g_+.
\]
This is a valid **unweighted** cap certificate. The stronger pointwise fact is
\[
 0\le A_u\mu(x)\le m(u):=\min(H,W e^{-u}),\qquad x\in G.
\]
Consequently the actual finite-time mass-weighted positive certificate is
\[
 \boxed{\int a\,d\mu=\int_G\int g A_u\mu
 \le\int_G\int m(u)g(x,u)_+\,du\,dx.}
\]
Both formulas follow directly from the pointwise cap and finite-time Fubini. The weighted form must be included before interpreting any counterexample to the unweighted cost.

Let \(\mu=p\delta_y\), set \(A=p/H\), choose \(B>A\), and take the bounded finite test
\[
 h_B(x,u)=D_\mu(x,u)\mathbf1_{\{A\le v(x)\le B\}}
                 \mathbf1_{[\log A-1,\log B+1]}(u).
\]
It is supported on good receivers and on a bounded spatial/time set. It satisfies
\(\|h_B\|^2\le cHp\) and \(\langle b,h_B\rangle=\|h_B\|^2\).
For every receiver in this annulus, put \(s=u-\log v\). On \(0<s<1\), both time arguments remain inside the retained window and
\[
 h_B(x,u-1)-h_B(x,u)=\frac pv(2-q)e^{-s}>0.
\]
Consequently
The positive part is **exactly** supported on this interval. Before it the difference is negative; afterwards both negative source tails give a negative difference, and truncation at the upper endpoint also gives a negative difference. Hence exactly
\[
 \int_G\int(h_B(x,u-1)-h_B(x,u))_+\,du\,dx
 =c(2-q)p\log(B/A).
\]
The unweighted cost diverges, but the global-mass certificate repairs this particular one-atom example. On its positive interval \(m(u)=p e^{-u}\), so its weighted cost is exactly
\[
 \boxed{\frac{(2-q)(1-q^2)}2p^2(1/A-1/B)\le
       \frac{(2-q)(1-q^2)}2Hp.}
\]
For checking the finite time cutoff, the exact test norm is
\[
 \|h_B\|^2=c p^2(1/A-1/B)
 -\frac{c^2p^2(B-A)}{2e^2B^2}.
\]
Thus the one-atom logarithm is an obstruction only to the weaker cap-only certificate, not to the mass-weighted one.

For a single atom the least good-centered capture volume is \(p/H\), realized at a nearest good receiver. Hence the optimized finite cover is \(\mathcal C(w)=(p/H)w_+\). It too avoids that cap-only logarithm.

## 5. A true separated-source logarithm survives the mass correction

**Proposition.** In dimension one, for every integer \(N\ge4\), there is an actual finite positive source with true good set and a bounded finite receiver/time test such that
\[
 \|h\|^2=\langle b,h\rangle\le cHW,
 \qquad \int_G\int\min(H,W e^{-u})(h(x,u-1)-h(x,u))_+
 =c(2-q)HW(\log N-1).
\]

**Proof.** Take \(H=1\), \(\mu=\sum_{i=1}^N\delta_{y_i}\), \(y_i=10N^2i\), \(W=N\), and \(B=N/e>1\). Around each atom set \(v_i(x)=2|x-y_i|\), and define
\[
 h(x,u)=\sum_{i=1}^N D_{\delta_{y_i}}(x,u)
     \mathbf1_{\{1\le v_i(x)\le B\}}\mathbf1_{[-1,\log N]}(u).
\]
The receiver annuli are disjoint. They are entirely in the true \(G\): a cube capturing only the local atom has average at most \(1/v_i\le1\); if it captures any other atom, its radius is at least \(10N^2-B/2\), so its average is at most \(N/[2(10N^2-B/2)]<1\). At every retained receiver/time pair, even the enlarged cube has radius at most \(eN/2\), less than the distance to any other atom. Therefore the actual full source difference equals the local atom difference on the support of \(h\). This proves \(\langle b,h\rangle=\|h\|^2\le cN\).

Exactly as in Section 4, the positive part at each receiver is supported only at \(u=\log v_i+s\), \(0<s<1\), and equals \((2-q)e^{-s}/v_i\). On that interval \(e^u\le eB=N\), so the global mass correction is inactive: \(\min(1,N e^{-u})=1\). The positive cost of one annulus is \(c(2-q)\log B\). Summing the \(N\) disjoint annuli gives the displayed formula. All source positions, cap inequalities, and time windows are specified; no inferred separated-support approximation is used. \(\square\)

The Hilbert norm and actual source pairing are \(O(HW)\), whereas this canonical mass-weighted certificate costs \(\Theta(HW\log N)\). Thus taking positivity before optimizing the positive cube constraints still fails a source-uniform budget for this source-pairing certificate alone. This is a certificate obstruction, not a large signed-energy example, and does not reuse absolute transport columns or full-history drift. It does not refute an estimate for the full dual objective after its threshold subtraction; that additional cancellation has not been estimated here.

The optimized compressed cover is not ruled out. In this same example each singleton has \(c_{\{i\}}=1\), attained at \(y_i+1/2\in G\). All pattern capacities are at least their cardinalities by original cap feasibility. Thus the capacity polytope is exactly \([0,1]^N\), and \(\mathcal C(w)=\sum_i(w_i)_+\). The actual adjoint values at the atoms are nonnegative and their sum equals the bounded source pairing; using these singleton cube certificates avoids the entire \(\log N\) loss. What remains unpaid is a general estimate of this optimized cover relative to the target threshold integral and the quadratic defect.

## Remaining status

The core-only polynomial Hall route was disproved in Round62. Nonlocal bounded targets exist trivially; that fact does not estimate their signed error. This round proves a finite positive-cap certificate reduction, a nonzero bounded-target error floor, and a canonical-certificate obstruction that survives the global-mass correction. The general source-uniform signed distance upper budget, and hence the intended general centered-cube weak estimate, remain unproved. Vertex cap-energy tests are separate diagnostics and are not used as a theorem in this audit.

## Standalone deterministic diagnostic

The following Python 3 program uses only the standard library. It checks the displayed analytic constants and the finite separated-source geometry at Decimal precisions 80 and 140. It evaluates the theorem's choice \(B=N/e\), not the optional alternative \(B=N/4\). It does not integrate an arbitrary target or search source extrema, and these Decimal comparisons are **not** outward-rounded interval certificates. The exact proofs above, not this diagnostic, establish the conclusions. The exact embedded code was executed successfully: 326 checks passed at each precision, and the largest relative precision-refinement discrepancy was \(7.068\times10^{-80}\). Weighted canonical cost divided by \(HW\) was approximately \(0.39854,1.82877,4.68925,6.11948\) at \(N=4,16,256,1024\).

```python
from decimal import Decimal as D, localcontext

def run(precision):
    with localcontext() as ctx:
        ctx.prec = precision
        one = D(1)
        e = one.exp()
        q = (-one).exp()
        c = one - q
        tol = D(10) ** (-(precision - 12))
        data = {}
        checks = 0

        def close(a, b):
            assert abs(a-b) <= tol * max(one, abs(a), abs(b))

        # Actual jump-pair inequality and its exact integrated floor.
        for p in [D('0.5'), D(1), D(3)]:
            for H in [D('0.25'), D(1), D(4)]:
                A = p/H
                for beta in [D(1), D(2), D(16), D(256)]:
                    rho = beta*H
                    for f in [D('0.5'), D('0.75'), D(1)]:
                        a = f*H
                        delta = a/(D(15)*rho)
                        gap = a*(q*delta.exp()+c*(-delta).exp())
                        gap -= D(4)*rho*delta
                        assert gap + tol >= D(2)*a/D(3)
                        assert delta <= one/D(15)
                        checks += 1
                    floor = D(2)*p**3/(D(135)*rho)
                    floor *= D(3)/(D(8)*A**2)
                    close(floor, H*p/(D(180)*beta))
                    data[f'floor:{p}:{H}:{beta}'] = floor
                    checks += 1

        # Finite-window atom formulas, including signs of the truncated g.
        for ratio in [D(2), D(4), D(16), D(256)]:
            p, H = D(3), D(2)
            A, B = p/H, (p/H)*ratio
            U = B.ln()+one
            norm = c*p*p*(one/A-one/B)
            norm -= c*c*p*p*(B-A)/(D(2)*e*e*B*B)
            weighted = (D(2)-q)*(one-q*q)*p*p*(one/A-one/B)/D(2)
            unweighted = c*(D(2)-q)*p*(B/A).ln()
            assert D(0) < norm <= c*H*p
            assert weighted + tol >= norm
            assert weighted <= (D(2)-q)*(one-q*q)*H*p/D(2)
            tail = c*c*p*p*((-D(2)*U).exp())*(B-A)/D(2)
            close(norm, c*p*p*(one/A-one/B)-tail)
            for v in [A, (A+B)/D(2), B]:
                T = U-v.ln()

                def phi(s):
                    if s < -one or s > T:
                        return D(0)
                    return (q if s < 0 else -c)*(-s).exp()

                for s in [D('-1.5'), D('-0.75'), D('-0.25'),
                          D('0.25'), D('0.75'), D('1.25'),
                          T+D('0.25'), T+D('0.75'), T+D('1.25')]:
                    g = phi(s-one)-phi(s)
                    if D(0) < s < one:
                        close(g, (D(2)-q)*(-s).exp())
                        assert g > 0
                    else:
                        assert g <= tol
                    checks += 1
            data[f'atomnorm:{ratio}'] = norm
            data[f'atomweighted:{ratio}'] = weighted
            data[f'atomunweighted:{ratio}'] = unweighted
            checks += 5

        # True capped separated-atom construction, B=N/e, U=log N.
        for n_int in [4, 8, 16, 64, 256, 1024]:
            N = D(n_int)
            R, B = D(10)*N*N, N/e
            U = N.ln()
            assert B > 1
            assert N/(D(2)*(R-B/D(2))) < 1
            assert R-B/D(2) > e*N/D(2)
            assert R > B  # disjoint annuli
            close(B.ln()+one, U)
            close(U.exp(), N)  # mass correction is inactive at g+'s endpoint
            norm = N*(c*(one-one/B)-c*c*(B-one)/(D(2)*e*e*B*B))
            cost = c*(D(2)-q)*N*B.ln()
            close(cost, c*(D(2)-q)*N*(N.ln()-one))
            assert D(0) < norm <= c*N
            assert cost > 0
            data[f'separatednorm:{n_int}'] = norm
            data[f'separatedcost:{n_int}'] = cost
            data[f'cost_over_HW:{n_int}'] = cost/N
            checks += 9
        return data, checks

low, c80 = run(80)
high, c140 = run(140)
with localcontext() as ctx:
    ctx.prec = 160
    discrepancy = max(abs(low[k]-high[k])/max(D(1), abs(high[k]))
                      for k in high)
    assert discrepancy < D('1e-70')
    print('PASS checks per precision:', c80, c140)
    print('maximum relative refinement discrepancy:', discrepancy)
    for N in [4, 16, 256, 1024]:
        print('N=', N, 'weighted canonical cost / HW=',
              high[f'cost_over_HW:{N}'])
```


## Whole signed error numerical investigation

This round computes the complete signed capped error for the actual vertex source μ=4^n Σ_{y∈{−1,1}^n}δ_y, H=1, W=8^n, with the affordable target F=1_[−4,4]^n. The target has exactly mass W and height H. Its support is unrestricted. The experiment tests this particular target rather than optimizing over all affordable densities or proving a general replacement theorem. The source contains N=2^n atoms, so dimension and source count vary together; no dependence on either is fitted.

The receiver integral is Lebesgue measure on the whole space. Write x=rθ on a cube cone, v=(2r)^n. The normalized radial proposal is q_rad=1/(2W) for v≤W and W/(2v²) otherwise. Its two pieces each integrate to1/2 in dv. The sampler takes v=WU or W/U with probability1/2 each. Uniform signs/faces reduce exactly by source/target symmetry, leaving θ=(1,U2,…,Un). Comparators use uniform free angles or the fixed mixture α=(.5,.7,.85,1), weights(.2,.3,.25,.25), whose free-coordinate density is αθ^(α−1). Every score uses the complete mixture density. Zero machine uniforms are redrawn;1 is excluded by the generator. This ideal continuous proposal gives the score 1_G E_point/(Wq). Machine random draws and arithmetic do not constitute an unbiasedness certificate for the continuum law.

Actual all-scale atomic maxima use simultaneous distance batches: after the first full-coordinate arrival R_min=max_i ||x_i|−1|, each later arrival |x_i|+1 doubles the count. The formula retains these genuine positive-volume vertex ties and evaluates every candidate maximum. G={Mμ≤1} is obtained from this event formula, not a scale grid. Gate values for all draws are floating. Each case retains its closest accepted and rejected receivers; all56 such points were independently checked at Decimal80/120 precision. Their classifications agree, and the minimum recorded |log Mμ| is1.93555×10^−6. These are nearest-rounded high-precision checks, not an interval certification of every gate.

Adjacent-volume increments use q=e^(1/n), du=n dR/R, where R is cube halfside. Source averages factor through vertex counts, and target averages use exact-form coordinate interval overlaps. The code directly squares Dμ−DF, retaining the entire source/target cross term. Time intervals split at every atom arrival, target face arrival and their q-shifted arrivals. Positive Gauss16 integration uses log-radius subinterval width at most min(.5,4/n). The signed error is exactly zero below the first applicable event and after both averages capture their equal total mass. Individual source, target and cross tails agree above the last capture and are added separately. Thus there is no time-tail omission and no spatial-box truncation.

The source-only full-time energy is independently integrated from signed arrival coefficients. It is compared at every accepted draw: maximum relative difference3.76×10^−14, absolute difference1.69×10^−14. The signed identity E_error=E_source+E_target−2E_cross has point residual at most4.45×10^−16. Time orders8/16/32 are compared at112 retained receivers: the three largest importance-error scores in each case and the worst source quadrature receiver. The largest weighted8/16 difference is9.91×10^−10; weighted16/32 is7.64×10^−12. This checks the retained points, not every target integral. Twenty-one global extreme receivers also have Decimal80/120 source Gram and complete proposal checks. Their source-energy precision difference is at most9.70×10^−80, float Gauss16 source relative error7.95×10^−15, and inverse importance-density relative error8.43×10^−15.

Continuous receivers avoid the isolated cell-face drops identified in Round61. No retained draw lies exactly on a target face; the minimum face distance is1.91529×10^−7. Fine-scale events near those faces are included rather than removed. Source ties are retained instead of perturbing the geometry to avoid them.

There are28 final cases: n1,2,4,8,16,32,64; two independent seeds for each of the two angular proposals. Each case uses8192 receivers through n16 and16384 in n32/64, totaling294912 receivers. The table gives the range of estimates over four cases, not a confidence interval.

| n | whole signed error/(HW) | source cap energy/(HW) | capped target energy/(HW) |
|---:|---:|---:|---:|
|1|.3295–.3448|.6943–.7026|.4301–.4363|
|2|.4204–.4391|.5170–.5277|.2095–.2157|
|4|.5039–.5153|.4514–.4591|.0900–.0930|
|8|.5204–.5418|.4672–.4859|.0456–.0478|
|16|.4953–.5605|.4657–.5284|.0266–.0287|
|32|.4240–.6993|.4065–.6826|.0165–.0174|
|64|.2317–.4482|.2217–.4383|.00916–.01001|

High-dimensional uncertainty remains substantial. In n64, the two uniform estimates are .23173±.03650 and .24063±.03201; the two angular-mixture estimates are .44822±.09101 and .43064±.11100, where ± denotes sample standard error only. Uniform contribution ESS is40–56 and mixture ESS15–24 out of16384 draws. The highest1% of contributions supplies66–67% uniformly and about81% in the mixture. n32 has an extreme importance score3565.4 and some ESS as low as10. The radial strata identify most estimated error in4≤r<5, rather than inside r<4. No n64 draw reaches r≥5. Positive fullspace proposal support does not make a finite sample resolve every rare radial or angular contribution. The uniform/mixture discrepancy therefore cannot be read as decay, boundedness, growth, or a reliable ordering of target quality.

Independent one-dimensional allspace integration uses true G= {|x|≥3}, symmetry, finite positive Gauss intervals and x=1/t for the infinite tail. Spatial orders16/32/64 with time order32 give signed error .3384508975/.3384495946/.3384498230 and source energy .69818083824. The spatial refinement difference is about1.3×10^−6, not a certified spatial error bound. It supplies a separate low-dimensional calibration for the sampling estimates.

The retained analytic L2 squared norm constant κ_n=n[(1+x)log(1+x)−x log x], x=sinh²(1/(2n)), gives the entire-space target bound E_F/(HW)≤κ_n. The capped target energy is below the same bound in exact arithmetic. Hence |sqrt(E_error/(HW))−sqrt(E_source/(HW))|≤sqrt(κ_n). The n64 bound is .0418136, while estimated capped target energies are near .01. The bound is analytic, not inferred from the samples; no finite Monte Carlo estimate is asserted to obey it without uncertainty. The high-dimensional cross estimates are small and slightly negative, so this target mostly leaves the noisy source energy unchanged there. Cross summaries retain their signed mean and SE; probability-style ESS fields for cross terms were removed.

For an honest concentration diagnostic, on G the first atom volume is at least4^n. Since Aμ≤min(1,W/v), source point energy is at most1+2log(W/v_min)≤1+2n log2. The target height is1 and its scale average is unimodal, giving target point energy at most2 by total variation. Thus signed point energy is at most6+4n log2. For r≤8 the radial inverse weight is at most2·4^n; for r≥8 a Hilbert-space Jensen tail estimate gives weighted signed energy at most8(1−e^−1)4^n. With uniform angular baseline weight w0, a valid score bound is B_n=2·4^n(6+4n log2)/w0. The ideal independent-score Hoeffding95% halfwidth is B_n sqrt(log40/(2S)). In n64 it is about1.32×10^39 uniformly and5.30×10^39 for the mixture, and is useless near the measured values. Sample SE is not substituted into this rigorous bound or used as a Bernstein/CLT certificate. Spatial overlap between cubes is inside each deterministic receiver score; no independence of cube averages is claimed.

Current L01/L03/H05 entry points and their method, actual centered-cube interface and provenance warnings were reread after the skill reload request. Actual positive measures and an actual feasible density are separated from numerical evidence. The generic interval API is unverified, so Decimal precision agreement is not labeled certified arithmetic. Only basic independent bounded-score concentration is used; no source-specific printed dependent or incorrectly normalized tail formula is imported. There is no exponent fit, general affordable-Hall conclusion, optimized replacement claim, or restricted upper theorem.

The fixed full-energy computation actually ran273.248180 seconds. The subsequently requested gate replay and weighted-guard refresh took2.204966 seconds, without resampling or repeating full-energy calculations. The final standalone program combines these deterministic steps and writes results.json beside itself. It uses existing Python3.12.14/NumPy2.3.5, sets process BLAS threads to one, imports no local research module, and records no runtime in JSON. Reproduce the final data without --pilot:

```sh
/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 -B /Users/zhengzhihao/Desktop/T/output/centered_cube_round063_20261011/nonlocal_probe.py
```

The pilot flag intentionally overwrites results.json with fewer samples. The parent independently replayed the frozen default program from a fresh temporary directory; the full JSON was byte-identical. The actual receipt appears below.

## Proof of the finite importance-score envelope

On the original good set, the first source arrival volume is at least
4^n and A_mu(u)<=min(1,W exp(-u)). Positivity gives
integral |D_mu|^2 <=2 integral A_mu^2 <=1+2n log(2).
For F=1_[-4,4]^n, each coordinate factor of its average, as a function
of t=1/R on its positivity interval, is the minimum of three affine
functions 4t, (1+(4-|x_i|)t)/2, and 1. It is positive concave there,
so log concave. Their product is log concave and hence unimodal in t.
Reversing the radius parameter preserves unimodality. Its values lie
in [0,1], so its total variation is at most 2. The unit-translation
difference has L1 norm at most this variation, and absolute value at
most 1. Thus its time-square integral is at most 2, and the complete
signed point energy is at most 6+4n log(2).

For r<=8, the radial inverse density divided by W is at most 2*4^n.
For r>=8, all source and target points lie inside [-4,4]^n, so their
distance from the receiver is at least r-4. Hilbert-space Jensen and
the single-atom time energy c/v^2, c=1-exp(-1), give complete signed
energy <=4c W^2/[2(r-4)]^(2n). Multiplication by the radial inverse
density divided by W gives at most 8c*(r/(r-4))^(2n)<=8c*4^n.
Finally, the full angular mixture density is at least its uniform
component w0. These prove the reported global score envelope
2*4^n*(6+4n log(2))/w0 under the ideal continuous law. Its enormous
Hoeffding bound is recorded rather than replaced by an uncertified
sample-standard-error interval.

## Supplementary reproducible programs and results

The next exact guard is saved as rejection_exact_guard.py. It writes
rejection_exact_results.json. It checks 23 dimensions through 4096,
including seven explicit vertex enumerations at dimensions 2 through 8.

### rejection_exact_guard.py

```python
"""Exact finite certificates for the fixed-source uniform rejection obstruction."""
from fractions import Fraction as F
from itertools import product
from decimal import Decimal,localcontext
import math,json,hashlib
from pathlib import Path


def actual_max(points,x,n):
    events={}
    for y in points:
        r=max(abs(a-b) for a,b in zip(y,x))
        events[r]=events.get(r,0)+1
    count=0;best=F(0)
    for r,c in sorted(events.items()):
        count+=c
        assert r>0
        best=max(best,F(4**n*count)/(2*r)**n)
    return best


def main():
    rows=[]
    dims=list(range(2,17))+[32,64,128,256,512,1024,2048,4096]
    for n in dims:
        m=(3**n).bit_length()-n-2;k=m+1
        assert 2**(k+n)<3**n<2**(k+n+1)
        assert m>=0
        s=F(4)-F(1,n)
        first=2**m*(F(2)/(s-1))**n
        full=(F(4)/(s+1))**n
        assert first<=F(3,4) and full<1 and 3<s<4
        a=F(2**(m+n),3**n)
        assert F(1,4)<a<=F(1,2)
        term=1;total=1
        for j in range(k):
            term=term*2*(n-j)//(j+1)
            assert term==math.comb(n,j+1)*2**(j+1)
            total+=term
        tail=F(total,3**n)
        density_lower=a/tail
        assert tail>0 and tail<1
        enum=False
        if n<=8:
            points=list(product([F(-1),F(1)],repeat=n))
            x=[F(0)]*m+[s]*(n-m)
            assert actual_max(points,x,n)==max(first,full)
            compatible=sum(max(abs(xi-yi) for xi,yi in zip(x,y))<3 for y in points)
            assert compatible==2**m
            enum=True
        with localcontext() as ctx:
            ctx.prec=80
            D=lambda v:Decimal(v.numerator)/Decimal(v.denominator)
            rows.append({'n':n,'d':1,'H':1,'m_zero_coordinates':m,
             'other_coordinate':str(s),'exact_first_average':str(first) if n<=32 else None,
             'exact_full_average':str(full) if n<=32 else None,
             'actual_atoms_enumerated':enum,'source_cube_halfside':3,
             'binomial_tail_upper_decimal':str(D(tail)),
             'target_height_over_H_lower_decimal':str(D(density_lower)),
             'expected_attempts_lower_decimal':str(1/D(tail)),
             'exact_tail_numerator':str(tail.numerator),
             'exact_tail_denominator':str(tail.denominator),
             'density_lower_numerator':str(density_lower.numerator),
             'density_lower_denominator':str(density_lower.denominator)})
    with localcontext() as ctx:
        ctx.prec=100
        a=Decimal('1.5').ln()/Decimal(2).ln();p=Decimal(2)/3
        rate=a*(a/p).ln()+(1-a)*((1-a)/(1-p)).ln()
        assert 0<a<p and rate>0
        rate_record={'a_log2_1p5':str(a),'p':str(p),'KL_rate':str(rate),
                     'scope':'nearest-rounded Decimal diagnostic; positivity is proved analytically'}
    out={'scope':'fixed-source independent rejection onto true G; not a moving-walk theorem or signed-error lower bound',
         'status':'all exact rational and integer assertions passed',
         'rows':rows,'KL_diagnostic':rate_record,'dimensions':dims}
    Path(__file__).with_name('rejection_exact_results.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'cases':len(rows),'explicit_atom_cases':sum(r['actual_atoms_enumerated'] for r in rows),'status':out['status'],'KL_rate':str(rate)}))


if __name__=='__main__':main()
```

Expected rejection_exact_results.json:

```json
{
  "KL_diagnostic": {
    "KL_rate": "0.01450754624808195538105151864415902848514342752552773143870643390121365081965339723816077671748885348",
    "a_log2_1p5": "0.5849625007211561814537389439478165087598144076924810604557526545410982277943585625222804749180882421",
    "p": "0.6666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666667",
    "scope": "nearest-rounded Decimal diagnostic; positivity is proved analytically"
  },
  "dimensions": [
    2,
    3,
    4,
    5,
    6,
    7,
    8,
    9,
    10,
    11,
    12,
    13,
    14,
    15,
    16,
    32,
    64,
    128,
    256,
    512,
    1024,
    2048,
    4096
  ],
  "rows": [
    {
      "H": 1,
      "actual_atoms_enumerated": true,
      "binomial_tail_upper_decimal": "0.55555555555555555555555555555555555555555555555555555555555555555555555555555556",
      "d": 1,
      "density_lower_denominator": "5",
      "density_lower_numerator": "4",
      "exact_first_average": "16/25",
      "exact_full_average": "64/81",
      "exact_tail_denominator": "9",
      "exact_tail_numerator": "5",
      "expected_attempts_lower_decimal": "1.8000000000000000000000000000000000000000000000000000000000000000000000000000000",
      "m_zero_coordinates": 0,
      "n": 2,
      "other_coordinate": "7/2",
      "source_cube_halfside": 3,
      "target_height_over_H_lower_decimal": "0.8"
    },
    {
      "H": 1,
      "actual_atoms_enumerated": true,
      "binomial_tail_upper_decimal": "0.25925925925925925925925925925925925925925925925925925925925925925925925925925926",
      "d": 1,
      "density_lower_denominator": "7",
      "density_lower_numerator": "8",
      "exact_first_average": "27/64",
      "exact_full_average": "216/343",
      "exact_tail_denominator": "27",
      "exact_tail_numerator": "7",
      "expected_attempts_lower_decimal": "3.8571428571428571428571428571428571428571428571428571428571428571428571428571428",
      "m_zero_coordinates": 0,
      "n": 3,
      "other_coordinate": "11/3",
      "source_cube_halfside": 3,
      "target_height_over_H_lower_decimal": "1.1428571428571428571428571428571428571428571428571428571428571428571428571428571"
    },
    {
      "H": 1,
      "actual_atoms_enumerated": true,
      "binomial_tail_upper_decimal": "0.40740740740740740740740740740740740740740740740740740740740740740740740740740741",
      "d": 1,
      "density_lower_denominator": "33",
      "density_lower_numerator": "32",
      "exact_first_average": "8192/14641",
      "exact_full_average": "65536/130321",
      "exact_tail_denominator": "27",
      "exact_tail_numerator": "11",
      "expected_attempts_lower_decimal": "2.4545454545454545454545454545454545454545454545454545454545454545454545454545454",
      "m_zero_coordinates": 1,
      "n": 4,
      "other_coordinate": "15/4",
      "source_cube_halfside": 3,
      "target_height_over_H_lower_decimal": "0.96969696969696969696969696969696969696969696969696969696969696969696969696969697"
    },
    {
      "H": 1,
      "actual_atoms_enumerated": true,
      "binomial_tail_upper_decimal": "0.20987654320987654320987654320987654320987654320987654320987654320987654320987654",
      "d": 1,
      "density_lower_denominator": "51",
      "density_lower_numerator": "64",
      "exact_first_average": "6250/16807",
      "exact_full_average": "3125/7776",
      "exact_tail_denominator": "81",
      "exact_tail_numerator": "17",
      "expected_attempts_lower_decimal": "4.7647058823529411764705882352941176470588235294117647058823529411764705882352942",
      "m_zero_coordinates": 1,
      "n": 5,
      "other_coordinate": "19/5",
      "source_cube_halfside": 3,
      "target_height_over_H_lower_decimal": "1.2549019607843137254901960784313725490196078431372549019607843137254901960784314"
    },
    {
      "H": 1,
      "actual_atoms_enumerated": true,
      "binomial_tail_upper_decimal": "0.31961591220850480109739368998628257887517146776406035665294924554183813443072702",
      "d": 1,
      "density_lower_denominator": "233",
      "density_lower_numerator": "256",
      "exact_first_average": "11943936/24137569",
      "exact_full_average": "191102976/594823321",
      "exact_tail_denominator": "729",
      "exact_tail_numerator": "233",
      "expected_attempts_lower_decimal": "3.1287553648068669527896995708154506437768240343347639484978540772532188841201717",
      "m_zero_coordinates": 2,
      "n": 6,
      "other_coordinate": "23/6",
      "source_cube_halfside": 3,
      "target_height_over_H_lower_decimal": "1.0987124463519313304721030042918454935622317596566523605150214592274678111587983"
    },
    {
      "H": 1,
      "actual_atoms_enumerated": true,
      "binomial_tail_upper_decimal": "0.42935528120713305898491083676268861454046639231824417009602194787379972565157750",
      "d": 1,
      "density_lower_denominator": "939",
      "density_lower_numerator": "1024",
      "exact_first_average": "823543/1250000",
      "exact_full_average": "105413504/410338673",
      "exact_tail_denominator": "729",
      "exact_tail_numerator": "313",
      "expected_attempts_lower_decimal": "2.3290734824281150159744408945686900958466453674121405750798722044728434504792332",
      "m_zero_coordinates": 3,
      "n": 7,
      "other_coordinate": "27/7",
      "source_cube_halfside": 3,
      "target_height_over_H_lower_decimal": "1.0905218317358892438764643237486687965921192758253461128860489882854100106496273"
    },
    {
      "H": 1,
      "actual_atoms_enumerated": true,
      "binomial_tail_upper_decimal": "0.25864959609815576893766194177716811461667428745618046029568663313519280597469898",
      "d": 1,
      "density_lower_denominator": "1697",
      "density_lower_numerator": "2048",
      "exact_first_average": "34359738368/78310985281",
      "exact_full_average": "1099511627776/5352009260481",
      "exact_tail_denominator": "6561",
      "exact_tail_numerator": "1697",
      "expected_attempts_lower_decimal": "3.8662345315262227460223924572775486152032999410724808485562757807896287566293459",
      "m_zero_coordinates": 3,
      "n": 8,
      "other_coordinate": "31/8",
      "source_cube_halfside": 3,
      "target_height_over_H_lower_decimal": "1.2068355922215674720094284030642309958750736593989393046552740129640542133176193"
    },
    {
      "H": 1,
      "actual_atoms_enumerated": false,
      "binomial_tail_upper_decimal": "0.34969262815627699029619468576944571457603007671594777218919880099578316313570086",
      "d": 1,
      "density_lower_denominator": "6883",
      "density_lower_numerator": "8192",
      "exact_first_average": "6198727824/10604499373",
      "exact_full_average": "387420489/2357947691",
      "exact_tail_denominator": "19683",
      "exact_tail_numerator": "6883",
      "expected_attempts_lower_decimal": "2.8596542205433677175650152549760278948133081505157634752288246404184221996222577",
      "m_zero_coordinates": 4,
      "n": 9,
      "other_coordinate": "35/9",
      "source_cube_halfside": 3,
      "target_height_over_H_lower_decimal": "1.1901787011477553392416097631846578526805172163300886241464477698677902077582450"
    },
    {
      "H": 1,
      "actual_atoms_enumerated": false,
      "binomial_tail_upper_decimal": "0.21312808006909515825839556978102931463699639282629680434893054920489762739419804",
      "d": 1,
      "density_lower_denominator": "12585",
      "density_lower_numerator": "16384",
      "exact_first_average": "163840000000000/420707233300201",
      "exact_full_average": "10485760000000000/79792266297612001",
      "exact_tail_denominator": "19683",
      "exact_tail_numerator": "4195",
      "expected_attempts_lower_decimal": "4.6920143027413587604290822407628128724672228843861740166865315852205005959475566",
      "m_zero_coordinates": 4,
      "n": 10,
      "other_coordinate": "39/10",
      "source_cube_halfside": 3,
      "target_height_over_H_lower_decimal": "1.3018673023440603893524036551450139054429876837504966229638458482320222487087803"
    },
    {
      "H": 1,
      "actual_atoms_enumerated": false,
      "binomial_tail_upper_decimal": "0.28899727345086284272383952310792731460312621720943623092685735575538959169503294",
      "d": 1,
      "density_lower_denominator": "51195",
      "density_lower_numerator": "65536",
      "exact_first_average": "285311670611/549755813888",
      "exact_full_average": "584318301411328/5559060566555523",
      "exact_tail_denominator": "59049",
      "exact_tail_numerator": "17065",
      "expected_attempts_lower_decimal": "3.4602402578376794608848520363316730149428655142103721066510401406387342513917375",
      "m_zero_coordinates": 5,
      "n": 11,
      "other_coordinate": "43/11",
      "source_cube_halfside": 3,
      "target_height_over_H_lower_decimal": "1.2801250122082234593221994335384314874499462838167789823224924309014552202363512"
    },
    {
      "H": 1,
      "actual_atoms_enumerated": false,
      "binomial_tail_upper_decimal": "0.36847928556509565502097128373610617171050031894415372543706639118923831620066950",
      "d": 1,
      "density_lower_denominator": "195825",
      "density_lower_numerator": "262144",
      "exact_first_average": "2337302235907620864/3379220508056640625",
      "exact_full_average": "149587343098087735296/1779197418239532716881",
      "exact_tail_denominator": "177147",
      "exact_tail_numerator": "65275",
      "expected_attempts_lower_decimal": "2.7138567598621217924166985829184220605132133282267330524703178858674837227116048",
      "m_zero_coordinates": 6,
      "n": 12,
      "other_coordinate": "47/12",
      "source_cube_halfside": 3,
      "target_height_over_H_lower_decimal": "1.3386646240265543214604876803268224179752329886378143750797906293884846163666539"
    },
    {
      "H": 1,
      "actual_atoms_enumerated": false,
      "binomial_tail_upper_decimal": "0.24130806618232315534556046673102000033870175616860573422073193449508035699165100",
      "d": 1,
      "density_lower_denominator": "384723",
      "density_lower_numerator": "524288",
      "exact_first_average": "19384006821904192/42052983462257059",
      "exact_full_average": "302875106592253/4503599627370496",
      "exact_tail_denominator": "59049",
      "exact_tail_numerator": "14249",
      "expected_attempts_lower_decimal": "4.1440802863358832198750789529089760684960348094603130044213629026598357779493298",
      "m_zero_coordinates": 6,
      "n": 13,
      "other_coordinate": "51/13",
      "source_cube_halfside": 3,
      "target_height_over_H_lower_decimal": "1.3627674976541563670484998297476366112761649290528510122867621639465277615323233"
    },
    {
      "H": 1,
      "actual_atoms_enumerated": false,
      "binomial_tail_upper_decimal": "0.31019247668132492600307465927544167649842597767202756279624643187108258489653602",
      "d": 1,
      "density_lower_denominator": "1483641",
      "density_lower_numerator": "2097152",
      "exact_first_average": "23303567338232644370432/37929227194915558802161",
      "exact_full_average": "2982856619293778479415296/55448176762342779635202921",
      "exact_tail_denominator": "531441",
      "exact_tail_numerator": "164849",
      "expected_attempts_lower_decimal": "3.2238048153158344909583922256125302549606003069475702006078289828873696534404213",
      "m_zero_coordinates": 7,
      "n": 14,
      "other_coordinate": "55/14",
      "source_cube_halfside": 3,
      "target_height_over_H_lower_decimal": "1.4135171513863528980393504897748174929110209275694052671771675223318848697225272"
    },
    {
      "H": 1,
      "actual_atoms_enumerated": false,
      "binomial_tail_upper_decimal": "0.20303894923843328275805258198411906913885496644448249612322388039730134148893710",
      "d": 1,
      "density_lower_denominator": "2913387",
      "density_lower_numerator": "4194304",
      "exact_first_average": "437893890380859375/1069375531370406656",
      "exact_full_average": "14348907000000000000000/333446267951815307088493",
      "exact_tail_denominator": "4782969",
      "exact_tail_numerator": "971129",
      "expected_attempts_lower_decimal": "4.9251633922990663444300396754705090672814837163754763785243772969399533944512007",
      "m_zero_coordinates": 7,
      "n": 15,
      "other_coordinate": "59/15",
      "source_cube_halfside": 3,
      "target_height_over_H_lower_decimal": "1.4396659283507477722664376548669984454519773720415447724589970367822743768678861"
    },
    {
      "H": 1,
      "actual_atoms_enumerated": false,
      "binomial_tail_upper_decimal": "0.26256868670670641789417595825707607322750552823756308871934752010495758782649206",
      "d": 1,
      "density_lower_denominator": "11302721",
      "density_lower_numerator": "16777216",
      "exact_first_average": "309485009821345068724781056/566977372488557307219621121",
      "exact_full_average": "79228162514264337593543950336/2301619141096101839813550846721",
      "exact_tail_denominator": "43046721",
      "exact_tail_numerator": "11302721",
      "expected_attempts_lower_decimal": "3.8085272564013568060292738359196869497176830251759731130229614621116455055380027",
      "m_zero_coordinates": 8,
      "n": 16,
      "other_coordinate": "63/16",
      "source_cube_halfside": 3,
      "target_height_over_H_lower_decimal": "1.4843519538348332229026975008938113220701457640155852736699419546850709665398270"
    },
    {
      "H": 1,
      "actual_atoms_enumerated": false,
      "binomial_tail_upper_decimal": "0.14436260086103444962572396615269561809464841728245466777056858128069735263632729",
      "d": 1,
      "density_lower_denominator": "267506813910657",
      "density_lower_numerator": "562949953421312",
      "exact_first_average": "822752278660603021077484591278675252491367932816789931674304512/1937114844585011541643853683619338993862294591963291168212890625",
      "exact_full_average": "26959946667150639794667015087019630673637144422540572481103610249216/27842483967545222806855045978857198959816766796965883326074040496532481",
      "exact_tail_denominator": "617673396283947",
      "exact_tail_numerator": "89168937970219",
      "expected_attempts_lower_decimal": "6.9270018275897829065481448791047651890237720684115017268610167021126565217768660",
      "m_zero_coordinates": 17,
      "n": 32,
      "other_coordinate": "127/32",
      "source_cube_halfside": 3,
      "target_height_over_H_lower_decimal": "2.1044322019002038812154142561745315238564396716111533875946624563659523373453331"
    },
    {
      "H": 1,
      "actual_atoms_enumerated": false,
      "binomial_tail_upper_decimal": "0.086993871581041144354233375111143586636731489365383620493430965200226516866065465",
      "d": 1,
      "density_lower_denominator": "298709449312425589649591680257",
      "density_lower_numerator": "1267650600228229401496703205376",
      "exact_first_average": null,
      "exact_full_average": null,
      "exact_tail_denominator": "381520424476945831628649898809",
      "exact_tail_numerator": "33189938812491732183287964473",
      "expected_attempts_lower_decimal": "11.495062604133291988706170702762543323892074069016859112166789787536694695106873",
      "m_zero_coordinates": 36,
      "n": 64,
      "other_coordinate": "255/64",
      "source_cube_halfside": 3,
      "target_height_over_H_lower_decimal": "4.2437579498945506128624537919660323483187784944567200098675660060191211661276664"
    },
    {
      "H": 1,
      "actual_atoms_enumerated": false,
      "binomial_tail_upper_decimal": "0.022521973291685494284638495845073386870533654868040266233142074764355264631884990",
      "d": 1,
      "density_lower_denominator": "265538222163870587512047906709610049455010040938230006053377",
      "density_lower_numerator": "3213876088517980551083924184682325205044405987565585670602752",
      "exact_first_average": null,
      "exact_full_average": null,
      "exact_tail_denominator": "145557834293068928043467566190278008218249525830565939618481",
      "exact_tail_numerator": "3278249656344081327309233416168025301913704209113950692017",
      "expected_attempts_lower_decimal": "44.401082758106859862076056399739694033049845962375585152860835533250149491462103",
      "m_zero_coordinates": 73,
      "n": 128,
      "other_coordinate": "511/128",
      "source_cube_halfside": 3,
      "target_height_over_H_lower_decimal": "12.103252263753628250987134024644805144884605413170886589559237459924944400102872"
    },
    {
      "H": 1,
      "actual_atoms_enumerated": false,
      "binomial_tail_upper_decimal": "0.0028555304601924805323569975317610296303808884211204098327922753613438066429549622",
      "d": 1,
      "density_lower_denominator": "396942869987152613154520738439938206794321460941637525210208538426927456947709847895651030386827879561267950190775563265",
      "density_lower_numerator": "41315998049390537434494706752048189989275292685267576205290549704650361952269459114074325652482205302974450751563959894016",
      "exact_first_average": null,
      "exact_full_average": null,
      "exact_tail_denominator": "572051244350389846769299534113832523103781279047445012311130964732658735101919489469143082938722672929266113335592178747",
      "exact_tail_numerator": "1633509753033549848372513326913325953886096547084928087284808800110812580031727769117905474842913084614271399962039355",
      "expected_attempts_lower_decimal": "350.19763015681288642855440687585316510723251689773065216847699845392181167699809",
      "m_zero_coordinates": 148,
      "n": 256,
      "other_coordinate": "1023/256",
      "source_cube_halfside": 3,
      "target_height_over_H_lower_decimal": "104.08550240675128929490609891943803168536825468096250285628803983118505284246201"
    },
    {
      "H": 1,
      "actual_atoms_enumerated": false,
      "binomial_tail_upper_decimal": "0.000056951171462646026004789483808873940103499790538390423398822186047287159210375120",
      "d": 1,
      "density_lower_denominator": "1100487409531378334583979628978139170635639328947127363386208341128045421217877678214303679772394441531679706915284064624857525814865643412989571628839322518404613204769897691169874188831734747605225820580577486092355336671384779116615165953",
      "density_lower_numerator": "6828046779268970776657768233698567984276232522051489956245767999246374131525255241237946573692471593720760228447675638216590132893818229842292076597586769967201441361422350907866192164773697561322460176523147880429251325990375896362151810433024",
      "exact_first_average": null,
      "exact_full_average": null,
      "exact_tail_denominator": "715679623418107966868669211926651150200054287466789946303131023292683953570945814815479238140223309421854901084984671092783463300049368180892520017730690353428168523471385166028817123052124901411890496284008973207103389061443921592417497649683",
      "exact_tail_numerator": "40758792945606604984591838110301450764282938109152865310600308930668348933995469563492728880459053390062211367232743134253982437587616422703317467734789722903874563139625840413699044030804990652045400762243610596013160617458695522837598739",
      "expected_attempts_lower_decimal": "17558.901324020959664402099773594844922242473384118204251174795290848065216178983",
      "m_zero_coordinates": 298,
      "n": 512,
      "other_coordinate": "2047/512",
      "source_cube_halfside": 3,
      "target_height_over_H_lower_decimal": "6204.5660133236461423989696780928474404258152265955543280739968509292025218748653"
    },
    {
      "H": 1,
      "actual_atoms_enumerated": false,
      "binomial_tail_upper_decimal": "2.9466635140274294288712235684287305604029321274372519829530355010170489547397891E-8",
      "d": 1,
      "density_lower_denominator": "11002601371204125225774006428999516585327134065762482136003280251260832589265772488577085823948219921566906851247541973595162748144993471516517567316535132085365742305774031785487736684532252209298108994624429430404133258240539344926423921313274631587271613908373751795789755599221453478451298604576632175103421339240117587564329074336501832701441164013593880363444794049130751598509916419740082791546123135865034521650331415443911372444103042956017883941233517394805444993540673537",
      "density_lower_numerator": "186488891279541459725915003302255743219297878591197788008793130795023447914265034312582829498376784623639004797535987994439637507318623415582630941091641415935721828845597925212865505833391591948176560535739129197034599753199567707424151456349518515107537270149729381259536769898501845441588618398865438140018821565521761398127276720933930867175185748132430227870774597776111775475490366499873629468140336527765476342012569487845249620983726962887520929697660544042071115699803737559138304",
      "exact_first_average": null,
      "exact_full_average": null,
      "exact_tail_denominator": "1536591970127654500135636848497393367182756283060633776751592311613493994309733544156352629377794144940200679281611008881105872652642637278112556942316087190593381681457870703451880740543030470310995135971385519706985197224352543260660976536611418648638487188160684095168456362381031227508867463129654058445994023898941278115821099008184182104744106145733959431772611617397196416400958281381634008170721479326818626600082192950645707876128627672004932212752054626322126794488486970001467",
      "exact_tail_numerator": "45278194943226852780962989419751097058959399447582231012359177988727706128665730405667019851638765109328834778796469027140587440925899059738755421055700132038542149406477497059620315574206799215218555533433865968741289128561890308339193091824175438630747382338986632904484590943298162462762545697846222942812433494815298714256498248298361451446259934212320495322818082506710911928024347406337789265621905908909607084980787717876178487424292357843694995642936285575331049356134459",
      "expected_attempts_lower_decimal": "33936687.892579354764198427757022779238484113130003615171387936394058234058975720",
      "m_zero_coordinates": 598,
      "n": 1024,
      "other_coordinate": "4095/1024",
      "source_cube_halfside": 3,
      "target_height_over_H_lower_decimal": "16949527.206140351738659653708540037711753044274577788621433009479110443364682538"
    },
    {
      "H": 1,
      "actual_atoms_enumerated": false,
      "binomial_tail_upper_decimal": "7.4537731770284066678639018185812702643392474762654036068420260856845858650984354E-15",
      "d": 1,
      "density_lower_denominator": "1039216033559545896328463644740510243927362097325281612261416345676762692249204864918725595215650073865082569087190565338545539325789912666882944054452372072554786547992663212011126739086952279103884942684551367608155541956089958307817888973731938735524595473897517742419452083986161735679754929886689139416792880098014663143091861796152892061389549041247277661749306015556610435387678123457986465371644272901011532418162095660416336268509524245008417932298128191058109677363200818323342959506611665461215599574205443065782260676768959740122888845027231233099761026325160222437199466004400052895145901115680204377858451672396584497917158279881485649167300393701314732780507558381887811973011757142064444449865589289560524257552338752614144440566974989233555692400114643240695612430191736964279907642194879945789620777317131770431591499981929538786914526139700279829067556186159572206791910833723140492174948297071429691721309573287781700793872120725387641774120961",
      "density_lower_numerator": "69556213141345269407515067115786764991705262549735948303537359111522614176378895669990532984393877424257869264331680209358104836822935374614554679608043721543799333994078233166448732839509381338884749875141583345849788064702954612877462466104677421689448088294080777773965362174599308044327164417092088846031042047278365580585966720455145967136585436087833973984505353126613550736388181582785893315094229488730062957948409704252857268529221075377285067062755595332929103886865297150820576930048624213679773234781064639103418048462727563158233601126703792262163018387042296687430434915196125330685777119717767970019341806901981510528366365657011400439883787084893751229924829447152769796462326141284670937650906274428797367613626454026848298648969369286983979169519208976077834399557390296948941219899625597632161323087361696526000865772268255307923110197940977474400891396850517544211016799549379926055142573277403100946091498432294529676854420081353757434477181439477999992832",
      "exact_first_average": null,
      "exact_full_average": null,
      "exact_tail_denominator": "15491274745137421274303920885223967470289581345999798528862476031467027585266591935942778052890921616447467517569397778550696569136084597290595444186804149937087266842747678521488361697943463238001898012811994196866883856063048134607173404348993852626151572779632598800179288226553854101797624855842039132292916864004415789042761274923453748344764221459023577440299496072718868524355885624361371447405112681387283145326205251211160172854993722021328408088732930828864154737397280430388342926666041776219615967841121270914806358713392177173050817734413737754168840846826111106093709122276600102777329100447028813811227551768642569363906986723838081725350247658609315708093867806163377719093483210042159694488155729164073779996979219517803049998686418666962381877553837131592342216711034084090895701216453837220597184578142048510038803492341285489154381085435797831759885418329835952362365337562701160287253770361822730305400737794589708533361191714166316178629202371852899855929",
      "exact_tail_numerator": "115468448173282877369829293860056693769706899702809068029046260630751410249911651657636177246183341540564729898576729482060615480643323629653660450494708008061642949776962579112347415454105808789320549187172374178683949106232217589757543219303548748391621719321946415824383564887351303964417214431854348824088097788668295904787984644016988006821061004583030851305478446172956715043075347050887385041293808100112392490906899517824037363167724916112046436922014243450901075262577868702593662167401296162357288841578382562864695630752106637791432093891914581455529002925017802493022162889377783655016211235075578264206494630266287166435239808875720627685255599300146081420056395375765312441445750793562716049985065476617836028616926528068238271174108332137061743600012738137855068047799081884919989738021653327309957864146347974492399055553547726531879391793300031092118617354017730245199101203747015610241660921896825521302367730365309077865985791191709737974902329",
      "expected_attempts_lower_decimal": "134160240223283.75644042433371917628440012638799128925602338997024979838238304423",
      "m_zero_coordinates": 1197,
      "n": 2048,
      "other_coordinate": "8191/2048",
      "source_cube_halfside": 3,
      "target_height_over_H_lower_decimal": "66931428014153.880482703534834704987509556638507637929799657885686299449090347980"
    },
    {
      "H": 1,
      "actual_atoms_enumerated": false,
      "binomial_tail_upper_decimal": "6.6190091429830780859723977475400102819399717491129388386457550618629188868798915E-28",
      "d": 1,
      "density_lower_denominator": "12866259685885924311633126055739334771635781700158170640301820103926961786165381695760314650185691831010332174778690009904729681452090401287581179842078016569665272244671230781248844159327123871804329432305035747105618581941246049363593788877047598923909340893877976716495648694400933365145038061805527909742023017208439803296130666490591191848405719133809217009595366340865476465127401662753206003000915629304392012958773683514696627093428746349210387232789636926714392504889322797269271251501212707503562324784304563933975238444149989868083346547725241543283520854230304054582082444080868826299898529757123776739029792671882443070355482838291127908042018890109510654018861896191512886729151625823416542318584976444195991622678868741637680580826950325938890874627399514914673481634558921484915543596496147306011540555921916291295977811812363901226059654784541678918689873414679254105804535451931799323371039212598559302540584614324807063680054920594054294730855410511772157880799327977452014845433735834600845890669214357935035037156467719837967019748696433712245833362112770721176834144200768349660184783794200534884939483014917083279193093461882381857905977253375995893971819417709049997983933942495748623008534156499617791504937642422125517384240172072887881889654397781131003201034045408256975940995375425496511058523419359520212813402212169246256427839913188855419540170947491387779641446799645863406043009501986429813634908089143618461515142366823840812003034682583424615406229428065711836975108821992471980714492520693532399379290393071294660163751983172548051404558193062920301153756804034946110856908511910126635861298500594508129988505730303657307897661773929704942367207547491288074543080236072913772802722129340514260868797967951331810881215238982537245952702252301779421764100344827576032264356020477454586891311900565489749271453511275148866664357575416987998047176059288653702626444944370209261979848357910102017",
      "density_lower_numerator": "9676133573128504701762977603825869017648775530859262471108794726330267482021346258254246486631464375484431421404372412901966863419571883507199662165987263032940890344047842856616597491742552402939591611556775796614685642564522016481850837143905995537468885978764896713608545717525657212898736574553154774102001938360727744283105268219995896583956714244442256696880052887493302620590515637273978652133994262169798419138633593893943965050440248928608464338982570705701515028358698740947133982639083681544452537029493822263157674737051239746577900792959167164896697309374049349085131944187812384114693930625334727218672405367311588774952812062550219174127452590507610604699397804116015218726462361619844556176148493632616350311659065674042880556545010159694844722277599380908393865715340106757677933085442325008339383342368487987957016151700424775836159530489890533780300971946881083392761943598968978912875773557951852212731037126278659285533702203373501600687904055540610301407188949776352837235375339192519816834292319376377601294287716971805357727633355657196210224665147561546315815449055008945905215576970465708604391657679311365057718554607578564163176302362570476921692580671013112455143925784140153110899857051538254359209114126205455776632713142209376816499983738453004175745823004958905824998500090106215165969541098711010875250565732512701774912674544322692349765730997026660912172196949892088844716339334126110021214106369151908173082555970129680596709167166595318571628074534442244164517515785794444694826295542479816670690820533938318921220554016631293137073351427192445889206786972302276746826628342860264125356780970833945932984488076377928751539903195507438085308502892818430828155965884788422419607093825142402382149558535517201799407032689028590775915911995458473204327905925628818479046324081866535083315682993486192123029230370102739847884393278985456385281873183166094994128230903623340957174886125997597659192495221767286784102760448",
      "exact_first_average": null,
      "exact_full_average": null,
      "exact_tail_denominator": "239979593229332476457118978734127495348974797358498394294112114249684608378151265406041638463637106089905940245334495785124632939103740355801506889636442249861001384755362644056356080831820268053144678920461642457260106799878785956131092614904170563703298614741148553129630070770170114616826573543456063287869275167250596893741956698200747670012309992903547102428185196519166106489368516065135326999580054986962630762987816430889166420543328177097200437847830901522486305923518356268335706745796449343947230164583222278584732795649017544630276684728527295010143333211315814843730398755873726784802685433898427752583007255320040469918474332508431462882855748663192342654869598042409577047652380988316140866234720506431249419217886018062548178615721655150886760036655167730966782558178475503693805032916038274974629928456944893509134388592205196078276236360592272175931630236128105685522104310248536296910974092130855615640409947419321112470853488164374639072545550388157251951931096983916515705560459987669168026304243994106557753856543952081405814464137882904379120165858307955252456849001167329925508980096519912984730034472609483687609403703493902433479867859088698944244700123521138556501847415415808063812556237273103804168383566642139518077060168555940700704534028018456599806032333814228331369019568333799999252681589745139011979640876707272232698175907797997189859641664954956741126574037155883498048097844363183910140264167999693431670324200355126568136465341722594059404522218426714004930830310847429691131634550693811276638724277481991666270792523905419844500855958661538803607407225921117113381142774423597404347401757061117153474690572469681258272794260698454930884625324208479750715720575434252925517633114585787805820978298124817465510937558208849638288897728730804437048392963564448822720600404337193739671433749613504364824821638388091840863418257682372466102497179790705229628834483314482253145726810933867038703603608579561708956453041",
      "exact_tail_numerator": "158842712171431164341149704391843639155997304940224328892615063011443972668708415997040921607230763345806570058996172961786786190766548164044212096815777982341546570921867046682084495794162023108695425090185626507476772616558593202019676405889476529924806677702197243413526527091369547717839976071673184070889173051956046954273218104822113479609947149800113790241918102973647857594165452626582790160505131225980148308133008438453044778931219090730992434972711566996473981541843491324311990759274230956834102775114871159678706647458641850223251191947225204238068158694201284624470153630628010201233315182186713293074441884838054852720438059731989233432617517161845810543442739459154480083075945997819957312575123165977728291638010725205403463960826547233813467587992586603884857797957517549196488192549335151926068401924961929522172565577930418533655057466475823196527035474255299433404994264838664189177420237192574806204204748324997618070124134822148818453467350747058915529392584296017926109202885627587664764082335979727593025150079848393061321231465388070521553498297688527421936224002478621600743022022150623887468388679196507200977692511875091134048221941399703653011997770589000617259060912870317884234673261191353306067962193116322537251657286074973924467773511083717666706185605498867370073345621918833290259981770609376792750782743360114151313923949545541424932594703055449231847425269131430412420284067925758392760924791223995289648335090948442479160531292377573143400076906519329775765124800271511999761907315070290523449127041889769069878564839298426519153142693741517534582145145728826495195764302616174402911867882723388989259117354695106880344415577455922283239101327746806025611642965877443379911144717646179188405787629233967059393595249863981941308058052497552832367458028948488592990917975561450056628287801241549256163845105077470973662522933029839358000582420485045107439832653634200114345430226640865457",
      "expected_attempts_lower_decimal": "1510800149082913214255952829.9193164419884337362842479788381238791018717727764612",
      "m_zero_coordinates": 2395,
      "n": 4096,
      "other_coordinate": "16383/4096",
      "source_cube_halfside": 3,
      "target_height_over_H_lower_decimal": "752054894690417636077275106.86467661077576741699651837807829724554832293628581770"
    }
  ],
  "scope": "fixed-source independent rejection onto true G; not a moving-walk theorem or signed-error lower bound",
  "status": "all exact rational and integer assertions passed"
}
```

### reset_exit_probe.py

```python
"""Actual reset exit probability: positive survival DP and independent sampling."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1'
os.environ['VECLIB_MAXIMUM_THREADS']='1'
from pathlib import Path
import math,json
from decimal import Decimal,localcontext
import numpy as np

def cdf(t):
    t=np.asarray(t)
    return np.where(t<=2,t/3,(t+2)/6)

def survival(n,r):
    r=np.asarray(r);d=n-1
    if d==0:return np.ones(len(r))
    j=np.arange(d+1)[:,None];h=np.arange(d+1)[None,:]
    delta=h-j;mask=delta>=0
    coef=np.zeros((d+1,d+1))
    for a in range(d+1):
        for b in range(a,d+1):coef[a,b]=math.comb(d-a,b-a)
    with np.errstate(divide='ignore'):logcoef=np.log(coef)
    states=np.zeros((len(r),d+1));states[:,0]=1
    previous=np.zeros(len(r))
    for k in range(1,n):
        R=2*2**(k/n);t=cdf(R-1)/cdf(r);p=(t-previous)/(1-previous)
        with np.errstate(divide='ignore',invalid='ignore'):
            transition=np.exp(logcoef[None]+delta[None]*np.log(p)[:,None,None]+(d-h)[None]*np.log1p(-p)[:,None,None])
        transition[:,~mask]=0
        states=np.einsum('mi,mij->mj',states,transition,optimize=False)
        states[r<1+R,k:]=0
        previous=t
    return states.sum(axis=1)

def integrate(n,q):
    if n==1:return 1/6
    cuts=np.unique(np.r_[3.,4.,1+2*np.exp2(np.arange(1,n)/n)])
    cuts=cuts[(cuts>=3)&(cuts<=4)]
    nodes,w=np.polynomial.legendre.leggauss(q)
    r=np.concatenate([(a+b)/2+(b-a)/2*nodes for a,b in zip(cuts[:-1],cuts[1:])])
    weight=np.concatenate([(b-a)/2*w for a,b in zip(cuts[:-1],cuts[1:])])
    p=np.concatenate([survival(n,r[i:i+32]) for i in range(0,len(r),32)])
    return float(weight@(n/6*cdf(r)**(n-1)*p))

def max_log_at_receivers(x):
    b=np.abs(x);n=b.shape[1]
    first=np.max(np.abs(b-1),axis=1)
    second=np.sort(b+1,axis=1)
    L=np.maximum(second,first[:,None])
    first_value=n*np.log(2/first)+(second<=first[:,None]).sum(axis=1)*math.log(2)
    values=n*np.log(2/L)+np.arange(1,n+1)*math.log(2)
    return np.maximum(first_value,values.max(axis=1))

def main():
    records=[];samples=[]
    for n in [1,2,4,8,16,32,64]:
        q=max(8,(n+1)//2);a=integrate(n,q);b=integrate(n,2*q)
        cutoff=(3**n).bit_length()-n-1
        tail=sum(math.comb(n,k)*2**k for k in range(cutoff+1))/3**n
        assert 0<b<=tail*(1+1e-12)
        m=cutoff-1
        height=2**m*(2/3)**n/b if n>=2 else None
        records.append({'n':n,'order':q,'exit_probability':a,'double_order_probability':b,
                        'order_difference':abs(a-b),'exact_binomial_upper_float':tail,
                        'actual_expected_attempts':1/b,'actual_height_witness_over_H':height})
        N=8192 if n<16 else 32768
        for seed in [639000+n,639100+n]:
            rng=np.random.default_rng(seed);hits=0;closest=math.inf
            for start in range(0,N,1024):
                x=rng.uniform(-2,4,(min(1024,N-start),n))
                values=max_log_at_receivers(x)
                hits+=int((values<=0).sum());closest=min(closest,float(np.abs(values).min()))
            p=hits/N
            samples.append({'n':n,'seed':seed,'draws':N,'good_hits':hits,'probability':p,
                            'sample_SE':math.sqrt(p*(1-p)/N),'hoeffding95_halfwidth':math.sqrt(math.log(40)/(2*N)),
                            'min_float_gate_log_margin':closest})
        print(n,b,1/b,height,flush=True)
    with localcontext() as ctx:
        ctx.prec=100
        n2=(24*Decimal(2).sqrt()-29)/36
    assert abs(records[1]['double_order_probability']-float(n2))<1e-14
    out={'scope':'actual vertex reset proposal [-2,4]^n into original good set; no moving-walk or general upper theorem',
         'deterministic':records,'independent_sampling':samples,'exact_n2_probability_decimal':str(n2),
         'limitations':['Positive finite recursion and event-aligned polynomial quadrature are exact in exact arithmetic only.',
                        'Floating nodes, transition probabilities, algebraic cuts and Monte Carlo gates have no outward-rounded certificate.',
                        'Hoeffding statement concerns ideal independent uniforms and true gates; machine-law and gate error are not certified.',
                        'No finite-dimension exponent fit. Exact rational necessary-tail obstruction is proved separately.']}
    Path(__file__).with_name('reset_exit_results.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')

if __name__=='__main__':main()
```

Expected reset_exit_results.json:

```json
{
  "deterministic": [
    {
      "actual_expected_attempts": 6.0,
      "actual_height_witness_over_H": null,
      "double_order_probability": 0.16666666666666666,
      "exact_binomial_upper_float": 0.3333333333333333,
      "exit_probability": 0.16666666666666666,
      "n": 1,
      "order": 8,
      "order_difference": 0.0
    },
    {
      "actual_expected_attempts": 7.28578944659278,
      "actual_height_witness_over_H": 3.2381286429301244,
      "double_order_probability": 0.13725348602650778,
      "exact_binomial_upper_float": 0.5555555555555556,
      "exit_probability": 0.13725348602650772,
      "n": 2,
      "order": 8,
      "order_difference": 5.551115123125783e-17
    },
    {
      "actual_expected_attempts": 7.3764961862157445,
      "actual_height_witness_over_H": 2.9141713328259726,
      "double_order_probability": 0.13556571775481596,
      "exact_binomial_upper_float": 0.4074074074074074,
      "exit_probability": 0.13556571775481588,
      "n": 4,
      "order": 8,
      "order_difference": 8.326672684688674e-17
    },
    {
      "actual_expected_attempts": 7.991395499535126,
      "actual_height_witness_over_H": 2.4944944342398916,
      "double_order_probability": 0.1251345900798142,
      "exact_binomial_upper_float": 0.25864959609815574,
      "exit_probability": 0.12513459007981426,
      "n": 8,
      "order": 8,
      "order_difference": 5.551115123125783e-17
    },
    {
      "actual_expected_attempts": 8.876164757809752,
      "actual_height_witness_over_H": 3.4594350030368575,
      "double_order_probability": 0.11266127063720212,
      "exact_binomial_upper_float": 0.2625686867067064,
      "exit_probability": 0.11266127063720213,
      "n": 16,
      "order": 8,
      "order_difference": 1.3877787807814457e-17
    },
    {
      "actual_expected_attempts": 11.84653933416643,
      "actual_height_witness_over_H": 3.5989941213241385,
      "double_order_probability": 0.08441283752090492,
      "exact_binomial_upper_float": 0.14436260086103445,
      "exit_probability": 0.08441283752090492,
      "n": 32,
      "order": 16,
      "order_difference": 0.0
    },
    {
      "actual_expected_attempts": 20.80926156900301,
      "actual_height_witness_over_H": 7.682382624270165,
      "double_order_probability": 0.048055525501663005,
      "exact_binomial_upper_float": 0.08699387158104115,
      "exit_probability": 0.048055525501663005,
      "n": 64,
      "order": 32,
      "order_difference": 0.0
    }
  ],
  "exact_n2_probability_decimal": "0.1372534860265078103122369272509098301575590280290764932288976031049327634191824703447028006628721597",
  "independent_sampling": [
    {
      "draws": 8192,
      "good_hits": 1357,
      "hoeffding95_halfwidth": 0.015005043614373761,
      "min_float_gate_log_margin": 0.00077688937417793,
      "n": 1,
      "probability": 0.1656494140625,
      "sample_SE": 0.004107468748740659,
      "seed": 639001
    },
    {
      "draws": 8192,
      "good_hits": 1363,
      "hoeffding95_halfwidth": 0.015005043614373761,
      "min_float_gate_log_margin": 0.00014999000602254557,
      "n": 1,
      "probability": 0.1663818359375,
      "sample_SE": 0.004114732139760543,
      "seed": 639101
    },
    {
      "draws": 8192,
      "good_hits": 1093,
      "hoeffding95_halfwidth": 0.015005043614373761,
      "min_float_gate_log_margin": 3.069032697533558e-06,
      "n": 2,
      "probability": 0.1334228515625,
      "sample_SE": 0.003756849120329273,
      "seed": 639002
    },
    {
      "draws": 8192,
      "good_hits": 1112,
      "hoeffding95_halfwidth": 0.015005043614373761,
      "min_float_gate_log_margin": 0.00027202603132647774,
      "n": 2,
      "probability": 0.1357421875,
      "sample_SE": 0.0037842873588749028,
      "seed": 639102
    },
    {
      "draws": 8192,
      "good_hits": 1086,
      "hoeffding95_halfwidth": 0.015005043614373761,
      "min_float_gate_log_margin": 0.00025124434349810265,
      "n": 4,
      "probability": 0.132568359375,
      "sample_SE": 0.0037466454636026327,
      "seed": 639004
    },
    {
      "draws": 8192,
      "good_hits": 1120,
      "hoeffding95_halfwidth": 0.015005043614373761,
      "min_float_gate_log_margin": 2.812768837889834e-05,
      "n": 4,
      "probability": 0.13671875,
      "sample_SE": 0.0037957292091640904,
      "seed": 639104
    },
    {
      "draws": 8192,
      "good_hits": 1066,
      "hoeffding95_halfwidth": 0.015005043614373761,
      "min_float_gate_log_margin": 0.00016989234357245309,
      "n": 8,
      "probability": 0.130126953125,
      "sample_SE": 0.0037172057126268715,
      "seed": 639008
    },
    {
      "draws": 8192,
      "good_hits": 1006,
      "hoeffding95_halfwidth": 0.015005043614373761,
      "min_float_gate_log_margin": 0.00020926936328669044,
      "n": 8,
      "probability": 0.122802734375,
      "sample_SE": 0.003626249495140097,
      "seed": 639108
    },
    {
      "draws": 32768,
      "good_hits": 3715,
      "hoeffding95_halfwidth": 0.0075025218071868805,
      "min_float_gate_log_margin": 6.200491031105315e-05,
      "n": 16,
      "probability": 0.113372802734375,
      "sample_SE": 0.0017514590940021623,
      "seed": 639016
    },
    {
      "draws": 32768,
      "good_hits": 3710,
      "hoeffding95_halfwidth": 0.0075025218071868805,
      "min_float_gate_log_margin": 0.00025284403396330646,
      "n": 16,
      "probability": 0.11322021484375,
      "sample_SE": 0.0017504306615951405,
      "seed": 639116
    },
    {
      "draws": 32768,
      "good_hits": 2678,
      "hoeffding95_halfwidth": 0.0075025218071868805,
      "min_float_gate_log_margin": 8.254047087064009e-05,
      "n": 32,
      "probability": 0.08172607421875,
      "sample_SE": 0.0015133573061394238,
      "seed": 639032
    },
    {
      "draws": 32768,
      "good_hits": 2757,
      "hoeffding95_halfwidth": 0.0075025218071868805,
      "min_float_gate_log_margin": 0.00011329349914035447,
      "n": 32,
      "probability": 0.084136962890625,
      "sample_SE": 0.0015334997659506215,
      "seed": 639132
    },
    {
      "draws": 32768,
      "good_hits": 1508,
      "hoeffding95_halfwidth": 0.0075025218071868805,
      "min_float_gate_log_margin": 9.672654026715577e-05,
      "n": 64,
      "probability": 0.0460205078125,
      "sample_SE": 0.001157498015672597,
      "seed": 639064
    },
    {
      "draws": 32768,
      "good_hits": 1524,
      "hoeffding95_halfwidth": 0.0075025218071868805,
      "min_float_gate_log_margin": 0.0003768730268056686,
      "n": 64,
      "probability": 0.0465087890625,
      "sample_SE": 0.0011633245563951442,
      "seed": 639164
    }
  ],
  "limitations": [
    "Positive finite recursion and event-aligned polynomial quadrature are exact in exact arithmetic only.",
    "Floating nodes, transition probabilities, algebraic cuts and Monte Carlo gates have no outward-rounded certificate.",
    "Hoeffding statement concerns ideal independent uniforms and true gates; machine-law and gate error are not certified.",
    "No finite-dimension exponent fit. Exact rational necessary-tail obstruction is proved separately."
  ],
  "scope": "actual vertex reset proposal [-2,4]^n into original good set; no moving-walk or general upper theorem"
}
```

## Actual independent replay receipt

```json
{
  "counts_checked": {
    "cases": 28,
    "decimal_extreme_guards": 21,
    "gate_borderline_guards": 56,
    "independent1D": 3,
    "quadrature_guards": 112,
    "receivers": 294912
  },
  "directory": "/var/folders/lq/2c4qbz2n0354_tnttkv_qsz00000gn/T/round063-replay-qa3uqi8m",
  "frozen_hashes": {
    "nonlocal_construction.md": "c522e9489a47525da53d08f072b7c24e7d5196d5985efac695180f5896ad6d14",
    "nonlocal_probe.py": "bc9308d2988c9a1d9446d83e8114f3d1913adc4816350e1b9beeb35344bf7daf",
    "rejection_exact_guard.py": "ebb99d7dcff531e8b70408aa69aeae2072b492700ee55812c3f09dec6c3fe487",
    "rejection_exact_results.json": "9b7a24ebef853604d848ce48d861eb8d9a92e009bcab1cc809f233697805b6aa",
    "reset_exit_probe.py": "76515d27e642526105ded4257ae0fc8584aba4aaa96e4fe5f52a70a0615516df",
    "reset_exit_results.json": "6cb82cda773cabff2b45d3834a2a68daaf46bb842e28059d00840f1ed82efcaa",
    "results.json": "bf921a3378a15091f4f791daebeb05e797522f021a7e64a50122eeaacc235302",
    "signed_dual_route.md": "55fd5fae631984c505c1ea6fb65f2aa7153b9a4c79581fb218aa79cde25d1365"
  },
  "interpreter": "/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3",
  "replays": {
    "nonlocal_construction_embedded.py": {
      "code_sha256": "ffc5fdaaf2aed4eac2cc31eb263ccc8c8563db245ba134bd986a5683af1d2791",
      "exit_code": 0,
      "stderr": "",
      "stdout": "{\"Decimal_rate_common_prefix\": \"0.0145075462480819553810515186441590284851\", \"actual_small_vertex_checks\": 7, \"exact_tensor_tail_checks\": 12, \"interval_claim\": false, \"large_n\": 4096}\n"
    },
    "nonlocal_probe.py": {
      "exit_code": 0,
      "result_byte_identical": true,
      "result_sha256": "bf921a3378a15091f4f791daebeb05e797522f021a7e64a50122eeaacc235302",
      "seconds": 275.31108220799797,
      "stderr": "",
      "stdout": "1 633001 (1.0,) error 0.33826426234769047 SE 0.005580979692776989 source 0.7026038707005571\n1 643001 (0.5, 0.7, 0.85, 1.0) error 0.3448215010799681 SE 0.005626456903406533 source 0.7004886448130063\n1 634001 (1.0,) error 0.33782512923594804 SE 0.005540002044962389 source 0.7021745847037324\n1 644001 (0.5, 0.7, 0.85, 1.0) error 0.32951507811673636 SE 0.005502030748252588 source 0.6942643844074485\n2 633002 (1.0,) error 0.42281831803399195 SE 0.004870342707932147 source 0.5228242450897569\n2 643002 (0.5, 0.7, 0.85, 1.0) error 0.42040428263255025 SE 0.0051510361672036 source 0.517027242037372\n2 634002 (1.0,) error 0.4391141321085835 SE 0.005022411116752182 source 0.5221210542079018\n2 644002 (0.5, 0.7, 0.85, 1.0) error 0.4326316594046996 SE 0.0052099396585951144 source 0.5277275977530725\n4 633004 (1.0,) error 0.515318098437855 SE 0.006826662231841004 source 0.45877337071174273\n4 643004 (0.5, 0.7, 0.85, 1.0) error 0.5060564151735847 SE 0.006965382009299896 source 0.45324605469152957\n4 634004 (1.0,) error 0.5039190552408203 SE 0.00662028347252933 source 0.45137798006067054\n4 644004 (0.5, 0.7, 0.85, 1.0) error 0.5115154111334019 SE 0.0069440271649948634 source 0.4590693008909057\n8 633008 (1.0,) error 0.5417562305814833 SE 0.013258949172065647 source 0.485916110054305\n8 643008 (0.5, 0.7, 0.85, 1.0) error 0.5250453777725761 SE 0.011307228524616164 source 0.4694508280563623\n8 634008 (1.0,) error 0.5204039146217145 SE 0.011893862419932944 source 0.4672238362446341\n8 644008 (0.5, 0.7, 0.85, 1.0) error 0.5342441232837207 SE 0.011768328386000134 source 0.4782903629021482\n16 633016 (1.0,) error 0.5605345668111279 SE 0.03467121152087035 source 0.5283731015168371\n16 643016 (0.5, 0.7, 0.85, 1.0) error 0.5141561281486478 SE 0.02459624772922332 source 0.48259201473147606\n16 634016 (1.0,) error 0.5481478917933755 SE 0.031191833953609152 source 0.5177919203886204\n16 644016 (0.5, 0.7, 0.85, 1.0) error 0.4952525783597831 SE 0.0191150214226328 source 0.46567701202407485\n32 633032 (1.0,) error 0.6283241793133834 SE 0.14796185246747137 source 0.611495837197155\n32 643032 (0.5, 0.7, 0.85, 1.0) error 0.6993216452646538 SE 0.22066086448663622 source 0.6826180163881144\n32 634032 (1.0,) error 0.4239839965405303 SE 0.02753711230870248 source 0.4064594856656435\n32 644032 (0.5, 0.7, 0.85, 1.0) error 0.5402715917780722 SE 0.07516169568732396 source 0.52320685352568\n64 633064 (1.0,) error 0.23172562947207193 SE 0.036499484903296936 source 0.22171580799311247\n64 643064 (0.5, 0.7, 0.85, 1.0) error 0.4482225325830924 SE 0.09100731275795795 source 0.4382809241987904\n64 634064 (1.0,) error 0.24063274300674914 SE 0.03200691477857526 source 0.23067796590271414\n64 644064 (0.5, 0.7, 0.85, 1.0) error 0.4306382477378355 SE 0.11100190360334851 source 0.4214730227817443\nruntime_seconds 275.26356141699944\n"
    },
    "rejection_exact_guard.py": {
      "exit_code": 0,
      "result_byte_identical": true,
      "result_sha256": "9b7a24ebef853604d848ce48d861eb8d9a92e009bcab1cc809f233697805b6aa",
      "seconds": 0.32401108399790246,
      "stderr": "",
      "stdout": "{\"cases\": 23, \"explicit_atom_cases\": 7, \"status\": \"all exact rational and integer assertions passed\", \"KL_rate\": \"0.01450754624808195538105151864415902848514342752552773143870643390121365081965339723816077671748885348\"}\n"
    },
    "reset_exit_probe.py": {
      "exit_code": 0,
      "result_byte_identical": true,
      "result_sha256": "6cb82cda773cabff2b45d3834a2a68daaf46bb842e28059d00840f1ed82efcaa",
      "seconds": 4.659426750004059,
      "stderr": "",
      "stdout": "1 0.16666666666666666 6.0 None\n2 0.13725348602650778 7.28578944659278 3.2381286429301244\n4 0.13556571775481596 7.3764961862157445 2.9141713328259726\n8 0.1251345900798142 7.991395499535126 2.4944944342398916\n16 0.11266127063720212 8.876164757809752 3.4594350030368575\n32 0.08441283752090492 11.84653933416643 3.5989941213241385\n64 0.048055525501663005 20.80926156900301 7.682382624270165\n"
    },
    "signed_dual_route_embedded.py": {
      "code_sha256": "1c62493a4f4ae43ed73639ecfd241cab4311979f6937f68bfb6d5700e978624b",
      "exit_code": 0,
      "stderr": "",
      "stdout": "PASS checks per precision: 326 326\nmaximum relative refinement discrepancy: 7.067838474327121563666526881508046868219031486564555961886490678666195494212711955818379044025328797541793572475098347444090144291728871185554259479245033792132E-80\nN= 4 weighted canonical cost / HW= 0.39853871792525388936312451548947074915334549597941972220714290482933233543033153455286050442450646293162011518449181682727562210479466993155\nN= 16 weighted canonical cost / HW= 1.8287743955727935058336772154670432993768891447731118223589342772203535577274513489713773083019110433784355417280852002422596637031118058754\nN= 256 weighted canonical cost / HW= 4.6892457508678727387747826154221883998239764423604960226625170220023960023216909778084109160567202042720663948152719670722277468997460777633\nN= 1024 weighted canonical cost / HW= 6.1194814285154123552453353153997609500475200911541881228143083943934172246188107922269277199341247847188818213588653504872117884980632137070\n"
    }
  },
  "scope": "Implementation replay and finite exact/floating diagnostics; no general upper theorem and no floating interval certification."
}
```

## Remaining general proof requirements

The reset-to-source rejection scheme at displacement factor 3/2 cannot
supply an affordable replacement. This does not refute a genuinely moving
chain, optimized redistribution, or the desired weak-type theorem. The
finite-time moving-chain identity retains its surviving-mass boundary term;
terminal height and full-time signed payment require separate theorems.

The cap-only positive certificate loses a spatial logarithm; the total-mass
correction repairs that single-atom example but still loses log N on actual
separated sources. Optimized singleton covers remove the latter loss.
Therefore the optimized finite cap-cover route remains viable as an
explicit sufficient interface, not a proved theorem. Any general estimate
must retain threshold subtraction and a nonzero quadratic defect; the
one-atom Lipschitz/jump floor rules out exact zero-defect domination.
No constant depending on atom number, scale grid, or depth is acceptable
as an absolute constant. The original goal remains active and unproved.
