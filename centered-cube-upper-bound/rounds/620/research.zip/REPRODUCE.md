# R620 最小复现与证据范围

本包为有限诊断与一般条件论证，不证明一般根阶上界。报告 `REPORT.tex` 不编译 PDF。代码实际解释器：
`/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python`。
Python 3.12.14，NumPy 2.5.4，SciPy 1.18.1；证明作者实际用 SymPy 1.14 辅助代数。无需声称调用未使用的 MATLAB/Arb。

## 输入和出处

- `ccu_r619_barrier.json`：R619 已推送包中的真实二维几何、顺序 increments、12 个保存的浮点来源和权重。SHA 82444d7ad5d4f9125ee84c422279dd502695f19a193376b24cf12bb83c3b77b8。
- `ccu_r619_barrier_case0_certificate.json`：上一轮首个来源/packing 核验；本轮只作为首例输入，不重跑 barrier。
- `ccu_r620_split.json`：共同有理源、浮点 MILP owner 和分配。其浮点“optimal”不能代替可行证书。质量上取整费用不能省略。
- `ccu_r620_tree.json`：24 棵实际坐标切树；每个原 receiver 只首次失付一次。
- `MANIFEST.json` 绑定最终保存文件；各计算 JSON 中还区分实际执行时的脚本 hash 与事后加强核验后的 hash，不能把修订 hash 冒称早期执行 hash。

## 必要精确复核

在解压目录运行下面命令。输出另命名，避免覆盖原运行记录。

```sh
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python ccu_r620_certificate.py --input ccu_r620_split.json --source ccu_r619_barrier_case0_certificate.json --geometry-data ccu_r619_barrier.json --output replay_first.json
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python ccu_r620_batch_cert.py --input ccu_r620_split.json --geometry-data ccu_r619_barrier.json --output replay_batch.json
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python ccu_r620_verify_tree.py --geometry ccu_r619_barrier.json --split ccu_r620_split.json --tree ccu_r620_tree.json --output replay_tree.json
```

预期：首例 valid True；其余11例 verified 10；全部24棵树精确复核通过。批量脚本正常退出不表示所有案例可行，必须查看 `valid`。未获证书者为61903、alpha0.0001，一行有约3.25963e-8缺口。树复核还重算全部profile的严格 `<2` 条件，12个均不满足。所有结果仅针对保存的有限几何、阈值和共同有理来源。

## 可选重算浮点优化或构造树

不要为维持CPU负载机械重跑。需要重新产生优化候选时，先创建一个空的输出目录，将以下 `rerun` 替换成它：

```sh
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python ccu_r620_split.py --input ccu_r619_barrier.json --output-dir rerun --phase first --workers 1
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python ccu_r620_split.py --input ccu_r619_barrier.json --output-dir rerun --phase geometry --workers 2
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python ccu_r620_split.py --input ccu_r619_barrier.json --output-dir rerun --phase remaining --workers 8
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python ccu_r620_tree.py --split ccu_r620_split.json --barrier ccu_r619_barrier.json --output-dir rerun --phase first --workers 1
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python ccu_r620_tree.py --split ccu_r620_split.json --barrier ccu_r619_barrier.json --output-dir rerun --phase remaining --workers 12
```

浮点求解器可能返回不同owner；需重新精确认证，不能挪用原证书。程序内部限制BLAS线程为1。12worker是上限，不能保证持续满核；本轮所有实验很短。资源记录见 `RESOURCES.md`。

## 一般论证和技能边界

R619的正权辅助来源/全族恢复为继承工具；R620独审见 `AUDIT.md`。共同选择建模采用A04技能的共享变量原则，不调用其未验证最优性主张；L03技能仅辅助有理残差核验，求解器状态不当作严格证明。有限网格DP适用条件及未运行理由见 `DP_SCOPE.md`。全树几何收缩、近临界统一费用、最大网格单元终端均未证明。
