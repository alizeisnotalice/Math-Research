import argparse,json,sys,time,hashlib,platform,resource
from pathlib import Path
from fractions import Fraction as Q
start=time.perf_counter();cpu=time.process_time();p=argparse.ArgumentParser();p.add_argument('--input',type=Path,required=True);p.add_argument('--geometry-data',type=Path,required=True);p.add_argument('--output',type=Path,default=Path(__file__).with_suffix('.json'));a=p.parse_args()
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
split=json.loads(a.input.read_text());geo=json.loads(a.geometry_data.read_text());assert split['input_sha256']==h(a.geometry_data)
def rect(x):
 r=tuple(map(Q,x));assert len(r)==4 and r[0]<r[1] and r[2]<r[3];return r
def area(r):return (r[1]-r[0])*(r[3]-r[2])
def intersect(r,s):return max(Q(),min(r[1],s[1])-max(r[0],s[0]))*max(Q(),min(r[3],s[3])-max(r[2],s[2]))
f=lambda x:[str(x.numerator),str(x.denominator)]
cache={}
for g in geo['geometries']:
 n=g['N'];ds=list(map(Q,g['d']));vs=list(map(Q,g['v']));stars=list(map(rect,g['stars']));assert len(ds)==len(vs)==len(stars)==len(g['records'])==n and all(v>0 for v in vs) and all(d==area(s) for d,s in zip(ds,stars))
 occupied=set();rs=[];rv=[]
 for r,x,y,cnt in g['records']:
  assert all(isinstance(z,int) for z in (r,x,y,cnt)) and r>0
  new={(i,j) for i in range(x-r,x+r) for j in range(y-r,y+r)}-occupied;assert len(new)==cnt and cnt>0;occupied.update(new);rv.append(Q(cnt,16));rs.append((Q(x-8*r,4),Q(x+8*r,4),Q(y-8*r,4),Q(y+8*r,4)))
 assert rs==stars and rv==vs and sum(vs,Q())==Q(len(occupied),16)==Q(g['V'])
 cells=[rect(x['cell']) for x in g['patterns']];masks=[int(x['mask']) for x in g['patterns']];assert all(mask>=0 and mask<(1<<n) for mask in masks)
 for c,mask in zip(cells,masks):
  A=area(c)
  for i,s in enumerate(stars):assert intersect(s,c)==(A if (mask>>i)&1 else 0)
 cache[g['seed']]=(ds,vs,stars,cells,masks)
results=[]
for rec in split['results']:
 if rec['seed']==61901 and Q(str(rec['alpha']))==Q(1,10):continue
 st=time.perf_counter();ds,vs,stars,cells,masks=cache[rec['seed']];n=len(stars);owners=rec['owner'];den=rec['rounded_source_denominator'];nums=rec['source_numerators'];rawx=rec['x_float'];assert len(cells)==len(nums)==len(rawx) and len(owners)==n and all(o in (-1,0,1) and isinstance(o,int) for o in owners) and den>0 and all(isinstance(z,int) and z>=0 for z in nums)
 srcrow=[r for r in geo['results'] if r['seed']==rec['seed'] and Q(str(r['alpha']))==Q(str(rec['alpha']))];assert len(srcrow)==1;old=list(map(Q,srcrow[0]['source_z']));assert len(old)==len(cells)
 z=[Q(v,den) for v in nums];assert all(q>=v>=0 for q,v in zip(z,old));M=sum(z,Q());assert M==Q(*rec['M_exact']);origM=sum(old,Q());raw=[Q(str(y)) for y in rawx];x=[min(max(Q(),v),q) for v,q in zip(raw,z)];clamp=sum((abs(v-w) for v,w in zip(raw,x)),Q());X=sum(x,Q());
 cover0=[sum((q for q,m in zip(x,masks) if m>>i&1),Q()) for i in range(n)];cover1=[sum((q-v for q,v,m in zip(z,x,masks) if m>>i&1),Q()) for i in range(n)]; transfers=[]
 for j,(owner,d) in enumerate(zip(owners,ds)):
  if owner==-1:continue
  for k,mask in enumerate(masks):
   deficit=d-(cover0[j] if owner==0 else cover1[j])
   if deficit<=0:break
   if not mask>>j&1:continue
   limit=min(z[k]-x[k] if owner==0 else x[k],2*M/3-X if owner==0 else X-M/3)
   for i,o in enumerate(owners):
    if o in (-1,owner) or not mask>>i&1:continue
    margin=(cover0[i] if o==0 else cover1[i])-ds[i];limit=min(limit,max(Q(),margin))
   move=min(max(Q(),limit),deficit)
   if move:
    direction=1 if owner==0 else -1;change=direction*move;x[k]+=change;X+=change;transfers.append({'star':j,'cell':k,'change':f(change)})
    for i in range(n):
     if mask>>i&1:cover0[i]+=change;cover1[i]-=change
 # Recompute all constraints independently after transfers.
 check0=[sum((q for q,m in zip(x,masks) if m>>i&1),Q()) for i in range(n)];check1=[sum((q-v for q,v,m in zip(z,x,masks) if m>>i&1),Q()) for i in range(n)];assert check0==cover0 and check1==cover1
 short=[max(Q(),d-(check0[i] if o==0 else check1[i])) if o!=-1 else Q() for i,(o,d) in enumerate(zip(owners,ds))];bad=[i for i,(q,v) in enumerate(zip(z,x)) if not 0<=v<=q];balanced=M/3<=X<=2*M/3;valid=not bad and balanced and not any(short)
 retained=sum((v for v,o in zip(vs,owners) if o!=-1),Q());lost=sum((v for v,o in zip(vs,owners) if o==-1),Q());assert retained+lost==sum(vs,Q())
 results.append({'seed':rec['seed'],'alpha':str(rec['alpha']),'valid':valid,'balanced':balanced,'budget_violations':bad,'M':f(M),'X':f(X),'source_rounding_cost':f(M-origM),'clamp_L1':f(clamp),'owners':owners,'repaired_x':list(map(f,x)),'coverage0':list(map(f,check0)),'coverage1':list(map(f,check1)),'shortfalls':list(map(f,short)),'retained':f(retained),'lost':f(lost),'V':f(retained+lost),'transfers':transfers,'wall_seconds':time.perf_counter()-st})
print('cases',len(results),'verified',sum(r['valid'] for r in results));assert len(results)==11
out={'results':results,'input_sha256':h(a.input),'geometry_sha256':h(a.geometry_data),'script_sha256':h(Path(__file__)),'runtime':{'sys_executable':sys.executable,'python':sys.version,'platform':platform.platform(),'argv':[sys.executable]+sys.argv,'wall_seconds':time.perf_counter()-start,'cpu_seconds':time.process_time()-cpu,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss},'scope':'fixed 11 allocations, no MILP rerun or general optimality statement'}
a.output.write_text(json.dumps(out,indent=2)+'\n')
