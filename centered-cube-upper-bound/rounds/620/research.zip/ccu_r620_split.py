import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[k]='1'
import argparse,concurrent.futures,hashlib,json,platform,resource,shlex,sys,time,warnings
from pathlib import Path
from fractions import Fraction as F
import numpy as np,scipy
from scipy.optimize import milp,Bounds,LinearConstraint
from scipy.sparse import csc_matrix, hstack, vstack, eye
D=1<<30

def task(arg):
 g,r=arg;start=time.monotonic();cpu=time.process_time();n=len(g['d']); masks=np.array([p['mask'] for p in g['patterns']],dtype=np.uint64);A=((masks[:,None]>>np.arange(n,dtype=np.uint64))&1).astype(np.int64);v=np.array([float(F(a)) for a in g['v']]);d=np.array(g['d'],dtype=np.int64)
 # Fraction(str) ensures deterministic ceil rather than floating multiplications.
 before=np.array([-(-F(a).numerator*D//F(a).denominator) for a in r['source_z']],dtype=np.int64);z=before.copy(); assert (z>=0).all(); deficits=[]
 for j in range(n):
  lack=max(0,int(d[j])*D-int(A[:,j]@z))
  if lack:
   ids=np.flatnonzero(A[:,j]);idx=int(ids[np.argmax(A[ids].sum(axis=1))]);z[idx]+=lack;deficits.append({'star_index':j,'cell_index':idx,'added_numerator':lack})
 assert np.all(A.T@z>=d*D)
 M=F(int(z.sum()),D);zfloat=z.astype(float)/D; Afloat=csc_matrix(A.T.astype(float));I=eye(n,format='csc');Z=csc_matrix((n,n)); row1=hstack([-Afloat,csc_matrix(np.diag(d)),Z],format='csc');row2=hstack([Afloat,Z,csc_matrix(np.diag(d))],format='csc');row3=hstack([csc_matrix((n,len(z))),I,I],format='csc');row4=csc_matrix(np.r_[np.ones(len(z)),np.zeros(2*n)].reshape(1,-1));mat=vstack([row1,row2,row3,row4],format='csc')
 ub=np.r_[np.zeros(n),A.T@zfloat,np.ones(n),float(2*M/3)];lb=np.r_[np.full(3*n,-np.inf),float(M/3)]
 c=np.r_[np.zeros(len(z)),-v,-v];integ=np.r_[np.zeros(len(z),dtype=int),np.ones(2*n,dtype=int)];bounds=Bounds(np.zeros(len(c)),np.r_[zfloat,np.ones(2*n)])
 with warnings.catch_warnings():
  warnings.filterwarnings('ignore',message='Unrecognized options detected')
  sol=milp(c,integrality=integ,bounds=bounds,constraints=LinearConstraint(mat,lb,ub),options={'time_limit':60.,'mip_rel_gap':1e-8,'threads':1})
 out={'seed':g['seed'],'alpha':r['alpha'],'status_code':int(sol.status),'status_message':str(sol.message),'time_limit_seconds':60,'M_exact':[M.numerator,M.denominator],'rounded_source_denominator':D,'source_numerators':z.tolist(),'roundup_increase_exact':[(F(int(before.sum()),D)-sum(map(F,r['source_z']),F())).numerator,(F(int(before.sum()),D)-sum(map(F,r['source_z']),F())).denominator],'repair_only_exact':[sum(x['added_numerator'] for x in deficits),D],'repair_steps':deficits,'elapsed_seconds':time.monotonic()-start,'cpu_seconds':time.process_time()-cpu,'peak_rss_bytes_macos':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'mip_gap':None if getattr(sol,'mip_gap',None) is None else float(sol.mip_gap),'mip_dual_bound':None if getattr(sol,'mip_dual_bound',None) is None else -float(sol.mip_dual_bound),'mip_nodes':None if getattr(sol,'mip_node_count',None) is None else int(sol.mip_node_count)}
 if sol.x is not None:
  x=sol.x[:len(z)];L=sol.x[len(z):len(z)+n];R=sol.x[len(z)+n:];owner=[0 if L[j]>.5 else 1 if R[j]>.5 else -1 for j in range(n)];out.update({'x_float':[format(t,'.17g') for t in x],'owner':owner,'retained_float':float(np.dot(v,np.array(owner)>=0)),'lost_float':float(np.dot(v,np.array(owner)<0)),'max_bounds_violation':float(max(0.,-x.min(),np.max(x-zfloat))),'balance0':float(x.sum()),'threshold_max_violation':float(max([0.]+[max(0.,float(d[j]-((A[:,j]@x) if owner[j]==0 else (A[:,j]@(zfloat-x))))) for j in range(n) if owner[j]>=0]))})
 return out

def main():
 p=argparse.ArgumentParser();p.add_argument('--input',type=Path,default=Path('/tmp/ccu_r619_barrier.json'));p.add_argument('--output-dir',type=Path,default=Path('/tmp'));p.add_argument('--phase',choices=('first','geometry','remaining'),required=True);p.add_argument('--workers',type=int,default=1);a=p.parse_args();assert 1<=a.workers<=8;a.output_dir.mkdir(parents=True,exist_ok=True);raw=a.input.read_bytes();inp=json.loads(raw);geos={g['seed']:g for g in inp['geometries']};results_path=a.output_dir/'ccu_r620_split.json';idx=a.output_dir/'ccu_r620_split_index.json';report=a.output_dir/'ccu_r620_split.md'
 if a.phase=='first':
  out={'input':str(a.input),'input_sha256':hashlib.sha256(raw).hexdigest(),'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'python':sys.version,'numpy':np.__version__,'scipy':scipy.__version__,'platform':platform.platform(),'commands':[],'results':[]};chosen=[r for r in inp['results'] if r['seed']==61901 and r['alpha']==.1]
 else:
  out=json.loads(results_path.read_text());chosen=[r for r in inp['results'] if (r['seed']!=61901 and r['alpha']==.1) if a.phase=='geometry'] if a.phase=='geometry' else [r for r in inp['results'] if r['alpha']!=.1]
 out['commands'].append(shlex.join([sys.executable]+sys.argv));start=time.monotonic()
 def save():
  results_path.write_text(json.dumps(out));lines=['# R620 fixed-source balanced split diagnostic','','One common repaired rational source is split per cell; integer ownership uses a shared allocation and original star thresholds. Source repair is exact; MILP statuses, bounds and allocations are floating solver output and not rigorous certificates.','','| seed | α | status | retained | lost | gap | repaired mass | source repair | CPU seconds |','|---:|---:|---:|---:|---:|---:|---:|---:|---:|']
  for r in sorted(out['results'],key=lambda x:(x['seed'],-x['alpha'])):
   if 'retained_float' not in r:lines.append(f"\nNo incumbent: {r['seed']}, {r['alpha']}, {r['status_message']}");continue
   lines.append('| %d | %.4g | %d | %.8g | %.8g | %s | %.8g | %.3g | %.3g |'%(r['seed'],r['alpha'],r['status_code'],r['retained_float'],r['lost_float'],str(r['mip_gap']),float(F(*r['M_exact'])),float(F(*r['repair_only_exact'])),r['cpu_seconds']))
  report.write_text('\n'.join(lines)+'\n')
 with concurrent.futures.ProcessPoolExecutor(max_workers=a.workers) as pool:
  for f in concurrent.futures.as_completed([pool.submit(task,(geos[r['seed']],r)) for r in chosen]):
   q=f.result();out['results'].append(q);save();print('done',q['seed'],q['alpha'],q['status_code'],q.get('lost_float'),flush=True)
 out['phase_last_elapsed_seconds']=time.monotonic()-start;save();idx.write_text(json.dumps({'input_sha256':out['input_sha256'],'script_sha256':out['script_sha256'],'phase':a.phase,'completed':len(out['results']),'workers':a.workers,'wall_seconds':out['phase_last_elapsed_seconds'],'max_worker_rss_bytes':max(r['peak_rss_bytes_macos'] for r in out['results']),'cpu_sum_seconds':sum(r['cpu_seconds'] for r in out['results']),'commands':out['commands']},indent=2))
if __name__=='__main__':main()
