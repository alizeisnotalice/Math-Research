# R620 分源与完整receiver：独立审计

日期：2026-10-28。先从父任务准确合同及已核R619结构独立推导，初审未读R620作者新稿；其后第8–11节核对作者主稿、bridge及最终整合稿。未改他人文件、未运行Git、未扫描例子。最终独审阶段按指示不启动计算或Agent。

## 1. 冻结对象与natural fractional transfer

全supplied family的B_j、A_j=aB_j及实际receiver increments I_j固定，v_j=|I_j|>0，V=Σv_j=|U|。归一化source μ满足s_j:=μ(A_j)≥d_j=|A_j|，总量M；barrier额外给

s_j=d_j+εv_j/λ_j，M=Q+εV，Σλ_j1_Aj≤1。

令μ_c≥0且Σ_cμ_c≤μ，m_c=μ_c(R^n)。定义t_jc=μ_c(A_j)/s_j。注意t_jc是相对该star原source质量的份额，区别于global capture p_j=s_j/M。

Natural receiver份额是实际measure

R_c(dx)=Σ_j t_jc 1_(I_j)(x)dx，r_c=Σ_jv_jt_jc。

Σ_cR_c≤1_U dx。若μ_0=μ−Σ_cμ_c，则遗漏receiver恰为R_0，并有Σ_c r_c+r_0=V；μ_0不能免费丢弃。只给r_c数值而未说明其是fractional receiver measure，也不能把它冒称child cube union体积。

source约束仅为μ_c(A_j)=t_jc s_j≥t_jc d_j。阈值随j变，不能把μ_c当作所有相关stars都在统一阈值1下bad的child input。用一个小阈值归一会付其倒数；“Σm_c≤M”本身不会取消它。

## 2. 一条精确且可收费的transfer公式

定义全对象的非负field

H(y)=Σ_j [v_j/s_j]1_(A_j)(y)。

Tonelli给出准确恒等式

r_c=∫H dμ_c，r_0=∫H dμ_0，V=∫H dμ。                    (1)

因此对所有subsource ν≤μ都想保证r(ν)≤K ν(R^n)，等价于H≤K μ-a.e.。分割source本身不会改写这个field，也不免费降低其平均费用。

实际barrier下，令e_j=εv_j/(λ_js_j)，则

εH=Σ_jλ_je_j1_Aj≤Σ_jλ_j1_Aj≤1。

所以每块r_c≤m_c/ε是合法、无重复来源费用的transfer。但汇总只给V≤M/ε=Q/ε+V，是**临界恒等费用，不能吸收**。不能因每个e_j<1就宣称存在对family统一的严格收缩率；最小λ/rare-label分支仍需保留。

任何候选如果证明更小的block费用，应明确它控制的是∫H dμ_c、有效阈值成本或其他完整receiver量，而不是只控制m_c。

## 3. Large-capture子族的完整union确可付款

取θ>0，J_θ={j:s_j≥θM}。若空则平凡。先按原顺序仅对该子族重新取增量J_j^θ，u_j=|J_j^θ|，于是Σu_j=|U_θ|，U_θ=∪_(j∈Jθ)B_j。

对任意source点y，所有含y的stars有共同点，且这些重新分配的receiver增量不交，故

Σ_(j∈Jθ:y∈A_j)u_j
 ≤|∪_(j∈Jθ:y∈A_j)B_j|
 ≤P max_(j∈Jθ:y∈A_j)d_j≤PM，P=(1+1/a)^n。

积分一次同一个μ，再用s_j≥θM，得到

θM |U_θ|≤Σ_j u_js_j≤PM²，
故 |U_θ|≤PM/θ。                                        (2)

这是严格证明的完整子族receiver bound，无Ccov、无N因子。θ≤1才可能非空；任意a>1保留P。barrier的strict slack并不需要用来把这个安全≤号改成严格小于。

保留原v_j也能证明Σ_(j∈Jθ)v_j≤PM/θ，但那只控制原ownership pieces，并非完整U_θ。原κ的Markov界Σ_(j∈Jθ)v_j≤κV/θ同样只适用于原ownership，不能换成|U_θ|。

更强的合法transfer是

H_θ(y)=Σ_(j∈Jθ) v_j/s_j·1_Aj(y)≤P/θ，
因此 r_(c,θ)≤P m_c/θ。                                 (3)

以u_j替换v_j亦成立。故large-global-capture分支可对任意subsource进行无重复fractional transfer；这来自共同clique体积容量，不是误套variable-threshold弱型。

**移除与remaining必须二选一地记清：** 可按原I_j分成high/low ownership，完整覆盖U；或先付完整U_θ，再处理U\U_θ。后者可用原low increments裁去U_θ，仍覆盖余部a.e.。不能既只付high的原ownership，却把整个high cubes从剩余几何删除。重新partition后u_j可能大于原v_j，KKT误差εv_j也不能不加说明改成εu_j；(2)–(3)不依赖这种错误替换。

## 4. 变阈值的可修复transfer条件

一个通用、准确的充分证书是：对block c有真正subsource μ_c、child family J_c、统一阈值h_c>0满足μ_c(A_j)≥h_cd_j；assigned receiver measure R_c的density≤a_c 1_(∪Jc B_j)。若child已证的**完整receiver**定理给|∪Jc B_j|≤K_c m_c/h_c，则

r_c≤K_c(a_c/h_c)m_c。                                  (4)

若child定理直接来自普通maximal weak bound，必须把a对应的P水平损失计入K_c，不能自动把center阈值当作整个小cube receiver阈值。

对natural t_jc，只有在assigned t_jc可夹在[h_c,A h_c]之类统一band时，才可令a_c/h_c≤A。把同一μ_c用于许多bands会重复支付m_c，需明确band数量/熵费，或另作真正subsource分配Σ μ_(c,band)≤μ_c。不能把一份μ_c的质量给每个band再领一次。

仅用统一child bound对每个threshold level积分，一般会出现∫dt/t式费用；有限min-positive-threshold或少数blocks不能伪装成对所有family统一的常数。反过来，所有问题也不应被表述成“transfer必然失败”：large-capture的(3)、comparable-threshold的(4)及下面共同质量条件都是合法修复。

即使每个child有一套packing，简单相加child λ也不自动全空间可行：source submeasures支持不交，不意味着整个stars incidence不交。可直接相加已经验证的scalar receiver/source收费，再用M=Q+εV吸收；若声称产出combined packing，则另证全空间combined load≤1。

## 5. 优先可检验的共同质量归并

一项可避开variable-threshold费用的较强几何证书：把待付receiver覆盖成groups G_c，每组stars共同相交，D_c=max_(j∈Gc)d_j；给每组一份真正subsource μ_c，Σμ_c≤μ，且m_c≥ζD_c。则

|U_pending|≤Σ_c P D_c≤(P/ζ)Σ_c m_c≤PM/ζ。                (5)

若要求source归并确实来自该组共同交H_c=∩_(j∈Gc)A_j，可再规定support μ_c⊂H_c。这时分配quota ζD_c的全局容量条件是对所有group集合S，

ζΣ_(c∈S)D_c≤μ(∪_(c∈S)H_c)。                            (6)

有限cells上的流可检验这种共享source allocation。不能只检查每个group单独有足够质量；重叠H_c的source总容量只能使用一次。几何Helly共同点本身也不保证μ(H_c)大：任意L1来源可以避开该共同交。若无法证明(6)或其他全局容量证书，(5)只是可修复目标，尚非一般结论。

(5)若覆盖全部receiver且无其他错误，选ε<P^(−1)ζ即可吸收M=Q+εV；有remaining时须保留其真实receiver预算，不能从该充分条件删除余部。

## 6. 什么才是有效收缩或可求和误差

source残余仅满足m_0≤ρM，不保证receiver残余r_0≤ρV，因为H可在残余上集中。一个真正足够的capturewise条件是

μ_0(A_j)≤ρ μ(A_j) 对所有保留j，

它直接给每个t_j0≤ρ，从而r_0≤ρV。更强的measure domination μ_0≤ρμ也足够。最弱的实际要求是明确证明∫H dμ_0≤ρV。仅取平凡μ_0=ρμ能获得收缩，却不使其余branch自动有更好几何，故仍需paid branch或child class的实质改进。

若递推依靠(4)，须收缩的是**有效预算**Σ_c(a_c/h_c)m_c，不是raw Σm_c。例如paid cost A_n M加children effective budget≤ρM，再有已证child收费及完整receiver覆盖，才可能形成A_n+ρK型递推。必须说明child变得可处理、或已有有限fallback与真正可求和递推；不能把未知原根阶定理再用于同样困难的child。

同一source在不同层被再次使用并非形式上绝对禁止，但所有层费用必须显式可求和；例如有效source预算按ρ^level衰减才给总量M/(1−ρ)。每层都领parent M而只说child数量有限，不是统一付款。

最终若得到V≤K M+ρV+E，则M=Q+εV给

[1−Kε−ρ]V≤KQ+E。

必须保证系数正，并给E的真实、可求和或可吸收上界。没有把原逐项εv_j、remaining volume或threshold inverse丢失。ε可以按既有量词依family选择，但不能将ε/λmin或有效threshold费用未经估计当小量。

## 7. 当前独立结论与停止点

已证：natural fractional receiver恒等式(1)；barrier临界1/ε transfer；完整large-capture union付款(2)与任意subsource的高分支transfer(3)；在所列共同阈值/质量quota/收缩条件下的合法收费推论。

尚缺：为低global-capture且source-cliques交织的实际family构造具有上述有效预算、共同质量容量或receiver收缩的分源。Σμ_c≤μ、λ全正、几何Helly或小p_j本身均未提供它。此审查优先给出可修复且无重复费用的条件，没有生成失败例。

实际调用指定数学venv的SymPy核验fractional ownership、barrier transfer系数及M=Q+εV的最终吸收代数，残差0。没有LP、solver重跑或参数扫描。等待作者具体机制后再作必要核验。

## 8. 原阈值二分、全树slack及终叶：已证范围

先独立核验同源树预算，再读 `/tmp/ccu_r620_main_sol.md`。主稿(1)–(4)通过：对root star，a_j=μ(A_j)=d_j+δ_j，两侧质量s_j、a_j−s_j，较大侧仍达到原阈值d_j当且仅当m_j=min(s_j,a_j−s_j)≤δ_j。整块原I_j只给一侧；两侧均不达标时整行首次失付。root未付L准确满足λ_jδ_j=εv_j所给的截断spill上界。

原barrier source上的cube链在μ-a.e.有load=1，其核可逆，坐标cut流量E=Σλ_j s_j(a_j−s_j)/a_j。m_j/2≤s_j(a_j−s_j)/a_j≤m_j，故root L≤2E/ε。balanced cut的存在不意味着该E足够小。

深node必须改用当前r_j(u)=μ_u(A_j)−d_j，不能再用root δ_j。存活时r减去较小侧质量m；首次失付时把剩余r全部计为已耗。于是对同一原λ、ε，主稿(7)的完整望远镜式准确成立：

S_tree=Σ_(u,j归u)λ_j min(m_j(u),r_j(u))
      =εL_tree+Σ_(存活j)λ_j[δ_j−r_j(leaf)]≤εV。

每行首次失付只计一次，但该行付款可以来自此前路径已耗slack；不能把root的局部L≤2E/ε逐节点直接套用。对当前assigned行，packing load仅≤1，补自环后的核仍可逆；其conductance控制当前截断耗费，给S_tree≤2Σ_uE_u，因此主稿(8)的全局L_tree≤S_tree/ε≤(2/ε)Σ_uE_u成立。

有限cube-face切割可使终叶incidence恒定。存活行在叶source上仍有质量≥d_j>0，故相应叶region共同包含这些stars，存在真实共同交；零质量叶不能有存活正需求行。叶原increments仍不交，所以其receiver≤P M_leaf。叶source互不交，给主稿(6) V≤PM+L_tree，无每层重复M。

主稿尚未证明(9)：Σ_uE_u≤(1−θ_n)εV/2，或足够的直接first-loss/truncated-spill替代。若(9)成立，才有θ_nV≤PM，并按预设ε=θ_n/(2P)吸收。S_tree≤εV本身不是严格收缩；一般balanced树也没有自动可求和费用。这一缺口在主稿与整合稿中正确保留。

## 9. 近临界bootstrap与同源条件桥：分别核验

主稿(5)对同一个原来源ν成立：near行1≤ν(A_j)/d_j≤R使用D_near，far行对ν/R仍达到阈值一；完整receiver union次可加给D≤D_near+D/R。已知有限粗界D≤D0使吸收合法，得到D≤R D_near/(R−1)，不漏P。这里的D是同a的有限receiver常数；若改用普通maximal常数，须重新处理a到a+1的水平损失。

**不能免费拼接的工具：** 原来源ν的upper-average条件并不随log-barrier重优化保留。辅助μ即使总质量近最优，也可能在个别stars有超过Rd_j的平均。若将d≤Az≤Rd加入source LP，其对偶是非负lower/upper乘子α、γ配合有符号净权α−γ，约束M^T(α−γ)≤1、目标d·α−R d·γ；不能仍用原全正λ packing、原KKT和饱和clique Hall。原任意ν也不自动在packing source cells上饱和。

作者补充§3.1提供的是准确的**条件性同源桥**：仅构造一次全family μ_ε，以它实际分类N_ε，保留原full-family v_j、λ_j、ε。若能证明主稿(5a)

Σ_(j∈Nε)v_j≤K_n M_ε

对全部继承数据及足够小ε统一成立，far原ownership由其完整union及μ_ε/R支付，则(5b) V≤[K_n+D/R](Q_ε+εV)成立。near子集λ只需≤1并补自环，root δ_j=εv_j/λ_j仍是继承原值；不能把全M_ε偷换成near子族的Q+εV_near。

以H0=K_n+D0/R，εH0<1−1/R，对任意原可行输入使用Q_ε≤m*≤||ν||1后取sup，准确得到

D≤K_n/[1−1/R−εH0]。

统一小ε极限给R K_n/(R−1)；R=2且εH0≤1/4给至多4K_n。最终REPORT中分母及状态条件正确。但**(5a)尚未由当前树账证明**，所以这里没有消除原near来源与barrier来源的连接缺口，只精确列出了一个能合法连接的充分条件。

## 10. 共同随机网格与maximal antichain：一次付款通过

已读 `/tmp/ccu_r620_bridge_sol.md`。先固定同一个μ，再给全部stars一个共同、嵌套dyadic网格平移θ；θ在最大尺度基本域均匀，模每层边长均匀。对固定真实source点先估跨cell概率，再Tonelli，得到E ell_j≤1/C；对I_j的Lebesgue receiver同样得到E beta_j≤1/(Ca)。不要求各j独立，也未用薄体积推source质量小。

聚合全部v_j的损失后只选**一次**θ，给V_good≥(1−ρ)V，ρ=1/(ηC)+1/(Ca)，且保留行μ|Cj(A_j)≥(1−η)d_j。此结论要求μ在选grid前固定；不能先按该grid重优化μ再免费沿用此平均。

有限嵌套cell族的inclusion-maximal D两两不交，每个C_j归唯一D，故Σμ(D)≤M，所有保留receiver pieces仍在其D。归一化来源ν_D=μ|D/(1−η)恢复原阈值，实际总费用是M/(1−η)，不是M。原full stars可以在D外重叠，不能因此直接相加局部packing。

这个antichain收费针对已证明完整覆盖的保留pieces，不是把主树所有first-loss节点自动当antichain。若将某祖先付费替代子孙，必须确实覆盖并支付其全部子树receiver；仅取最大节点不能免费丢失后代费用。当前bridge以实际保留cell的maximal合并处理，未犯此错误。

bridge(7)在真正终端K_root成立时给V≤ρV+K_root M/(1−η)，其边界损失和归一成本完整。但K_root尚未证，最大D可含几乎全部来源，coarse组只落在factor-2半径带，不保证质量/复杂度收缩。不能将未知原根阶命题代入自身，也不能每层免费重复1/(1−η)与损失ρ。主稿/bridge对此停止点准确。

## 11. 最终报告、数值边界与封存范围

已抽查 `/tmp/ccu_r620_final/REPORT.tex` 的同源near桥、最终吸收分母及状态声明，与第9节一致。全树(6)–(8)和随机网格均是已证结构；(5a)、全树(9)、maximal-cell收缩及coarse终端仍明确未证。

数值验证由root另行执行，本审不启动计算或重复求解器：报告只把11/12自由分源列为严格有限可行，剩余精确阈值短缺一例未认证；贪心修复失败不等于不可行。24树的有理原阈值与逐star slack望远镜检查，不可升级为有理化source仍满足精确barrier KKT，也不可据此声称精确Σλδ=εV。单次成功与有限树存活率均不是一般预算或连续最优。

只以rectangle region恢复assigned集的状态简化，需要全部原source μ(A_j)<2d_j：这保证一行不能同时在两个不交children达标，因而可由region capture恢复owner。≤2不足以排除临界双达标。现有profiles违反该严格前提，DP未执行；即使将来只枚举有限source-face grid cuts，所得也仅是该cut菜单的最优，不能直接认证连续cut最优。

**最终已核：** 原阈值二分；root conductance收费；有限全树first-loss/slack及叶共同交付款；原来源near bootstrap；补充§3.1的条件性同源桥及正确分母；共同随机grid单次选择及maximal antichain一次来源费用。**未证：** (5a)、(9)、网格递推终端/收缩及一般根阶。具体数值与root重放回执未由本审复算，最终归档或commit不在本审认证范围。已按指示仅只读材料并写本文件，无新增计算/Agent/扫描。审计完成，停止。
