# R620 split 与有限 certificate 账目

## Split MILP 阶段

- 输入：R619 barrier JSON，SHA-256 `82444d7ad5d4f9125ee84c422279dd502695f19a193376b24cf12bb83c3b77b8`。共 12 个 MILP 结果（3 个 seed × 4 个 α），每个几何是 40 个二维 stars、约 637–752 个 source patterns。记录环境 Python 3.12.14、NumPy 2.5.4、SciPy 1.18.1，macOS 27.2 arm64。
- 分阶段命令记录为 workers=1（first）、2（geometry）、8（remaining）。12 个结果逐任务 CPU 秒合计 **1.294971 秒**。索引的 **0.685731 秒只对应最后 remaining phase**，不是整项任务总墙钟；first/geometry 阶段墙钟未汇总，所以总 wall time **未知**。
- 最大单 worker 峰值 RSS 是 **117,751,808 bytes**。它不是 8 worker 同时内存快照；不能把逐 worker 峰值相加后称为同步 RAM 使用。8 是并发上限/最后阶段 worker 配置，不代表持续 8 核满载。
- 执行脚本 hash 为 `1af2f1d7f633fcf294259f901f98b92099beb28b64a7866a1fe0fa1be2e6d39c`。当前修订 hash 为 `6673254a4cc65e04a4a84104eb83470aeca1d5a815899c876876b29eb0c7d6f1`。修订只从已保存的 source z 与修复 numerators 更正 `roundup_increase_exact` 账目，没有重跑 MILP；`repair_only_exact` 原已正确。应把结果归于执行 hash，并将当前 hash 理解为事后账目修订版。

## 数值证据与严格证书

- Split 的 12 个 HiGHS 结果状态均为 optimal、MIP gap 记录为0，但这是浮点求解输出。保存的 `threshold_max_violation` 在 12 项中有 3 项非零，最大约 `1.1094e-5`；因此不能仅凭 MILP 状态/零 gap 宣称严格可行或最优。
- Certificate 只补做 seed=61901、α=0.1 的一个固定 40-owner 实例。Fraction 有理核验针对逐块向上有理化 source；向上 source 预算增加精确为 `10538777578927396857/32000000000000000000000000`（约 (3.29\times10^{-7})）。额外 `repair0=repair1=repair_total=0`；浮点分配先裁至源预算内，再做 84 个有理侧别转移，严格满足两侧 owner 阈值、预算和平衡，保留全部 `V=3375/16`，lost=0。它证明该固定实例所给分配可行，不证明 MILP 的一般最优性或一般拆分定理。
- Certificate 运行环境 Python 3.12.14；墙钟 0.223576 秒、CPU 0.219302 秒、峰值 RSS 28,491,776 bytes。certificate script SHA `c3d08e62e1deb272bd096efd198b741b6cc94fb959bfa94371c2c3ecf6086975`；输入、source、geometry hashes 均记录在 JSON/Markdown。
- 机器状态记录（2026-10-28 02:41）是单次快照：15 核、CPU 89.89% idle、23 GB used、550 MB unused、5.5 GB compressor。不是整个实验期间的平均 CPU 或内存计量，不能据此断言批次持续满载。

## 尚无记录

截至本次读取，`/tmp/ccu_r620_tree_index.json` 与 `/tmp/ccu_r620_batch_cert.json` 尚不存在，故 tree/batch 任务数、状态、资源与证据等级均不纳入结论。

## 新增的有理批量证书与树复核

- **Batch rational certificate：** `/tmp/ccu_r620_batch_cert.md` 对原 12 个 MILP 固定分配再做有理核验，11 项中 10 项严格可行；与此前单独通过的首例合并，当前总计 **11/12** 有证书。失败项是 seed 61903、α=0.0001、owner 12，仍短缺 `2607701558239986899/80000000000000000000000000`（约 `3.25963e-8`），**不能计作通过**。修复器失败不证明该 owner 不可行。其他有限证书的质量费用及适用范围沿用各自报告；批量单进程运行 Python 3.12.14/Fraction，墙钟 0.39518 秒、CPU 0.390778 秒、峰值 RSS 30,457,856 bytes。脚本 SHA `9a5d62e5c6ead8d4cb3cdbc282104a52eba941f52492fa542a2bcc6b5949ea66`。
- **Tree batch：** `/tmp/ccu_r620_tree_index.json` 记 12 profiles、24 policy trees。first phase 为 1 worker；remaining phase 12 workers，墙钟 0.139594 秒、worker CPU 合计 0.303183 秒、最大单 worker 峰值 RSS 41,320,448 bytes。`conservative_12_worker_peak_sum_bytes=495,845,376` 是按单 worker 峰值构造的保守总量，不是同步测得的 RSS。12 workers 是并发配置，不说明 12 核持续满载。脚本执行 hash `bbe1f085a64acd00e0d128b96645ef23931a2275a09fa8a9427b1a2b2334ca85`；之后仅从已存 tree 校验每星整数 slack telescope，当前修订 hash `575c44740bebd20fd667e405dd9a56c95711935147fb13bf4e5c79f39fdad425`，未重跑 policies。
- **Root tree replay：** `/tmp/ccu_r620_tree_root_replay.json` 对 24 棵已提供的有限树做 independent exact replay，24/24 标为 verified；耗时 0.147970 秒。它复核所给树的节点/存活/损失分数，不证明这些树最优，也不推出维数定理。replay 文件没有 CPU 或 RSS 字段；输入 geometry/split/tree SHA 与树输入绑定。
- **DP 计划没有运行：** `/tmp/ccu_r620_dp_plan.md` 对 12 个现有 profile 用精确整数比较 (\mu(A_j)<2d_j)，结果全部不符合严格前提；所以未执行 profile DP。这是输入前提不满足后的计算决策，不是 DP 的理论反例，也不是一般猜想的失败。计划中的 profile tree DP 结果数为0。

上述各批次都在亚秒量级结束。CPU 汇总和短墙钟只描述这些实际短任务；8/12 worker 上限不等于持续满载。逐 worker 峰值求和也不等于同步采样的系统 RAM。此前 02:41 系统快照仍仅是单点观察，不代表这些新阶段全过程资源状态。
