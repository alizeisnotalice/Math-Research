import argparse,json,sys,time,hashlib,platform,resource
from pathlib import Path
from fractions import Fraction as Q
start=time.perf_counter();cpu=time.process_time();p=argparse.ArgumentParser();p.add_argument('--input',type=Path,required=True);p.add_argument('--source',type=Path,required=True);p.add_argument('--geometry-data',type=Path,required=True);p.add_argument('--output',type=Path,default=Path(__file__).with_suffix('.json'));a=p.parse_args()
h=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
allocation=json.loads(a.input.read_text());src=json.loads(a.source.read_text());geo=json.loads(a.geometry_data.read_text());assert h(a.geometry_data)==src['source_input_sha256']==allocation['input_sha256']
sel=[r for r in allocation['results'] if r['seed']==src['seed'] and Q(str(r['alpha']))==Q(str(src['alpha']))];assert len(sel)==1;alloc=sel[0]
def rect(x):
 r=tuple(map(Q,x));assert len(r)==4 and r[0]<r[1] and r[2]<r[3];return r
def area(r):return (r[1]-r[0])*(r[3]-r[2])
def intersection(r,s):return max(Q(),min(r[1],s[1])-max(r[0],s[0]))*max(Q(),min(r[3],s[3])-max(r[2],s[2]))
stars=[rect(r) for r in src['stars']];n=len(stars);ds=list(map(Q,src['d']));vs=list(map(Q,src['v']));original_cells=[(*rect(r[:4]),Q(r[4])) for r in src['cells']];den=alloc['rounded_source_denominator'];nums=alloc['source_numerators'];assert den>0 and len(nums)==len(original_cells);cells=[(*c[:4],Q(z,den)) for c,z in zip(original_cells,nums)];assert len(ds)==len(vs)==n and all(x>0 for x in vs) and all(d==area(r) for d,r in zip(ds,stars)) and all(c[4]>=0 for c in cells)
g=[x for x in geo['geometries'] if x['seed']==src['seed']];assert len(g)==1;g=g[0];assert g['N']==len(g['records'])==n
occupied=set(); rebuilt=[];rv=[]
for r,x,y,cnt in g['records']:
 assert all(isinstance(z,int) for z in (r,x,y,cnt)) and r>0
 new={(i,j) for i in range(x-r,x+r) for j in range(y-r,y+r)}-occupied;assert len(new)==cnt and cnt>0;occupied.update(new);rv.append(Q(cnt,16));rebuilt.append((Q(x-8*r,4),Q(x+8*r,4),Q(y-8*r,4),Q(y+8*r,4)))
assert rebuilt==stars and rv==vs and sum(vs,Q())==Q(len(occupied),16)==Q(g['V']);assert [rect(p['cell']) for p in g['patterns']]==[c[:4] for c in cells]
oldM=sum((c[4] for c in original_cells),Q()); roundedM=sum((c[4] for c in cells),Q());assert roundedM==Q(*alloc['M_exact']);assert all(c[4]>=old[4] for c,old in zip(cells,original_cells))
rawx=list(map(lambda z:Q(str(z)),alloc['x_float']));x=[min(max(Q(),v),c[4]) for v,c in zip(rawx,cells)];clamp_cost=sum((abs(v-w) for v,w in zip(rawx,x)),Q());owners=alloc['owner'];assert len(x)==len(cells) and len(owners)==n and all(isinstance(o,int) and o in (-1,0,1) for o in owners)
M=sum((c[4] for c in cells),Q());X=sum(x,Q());assert M>0
budget_violations=[i for i,(v,c) in enumerate(zip(x,cells)) if not Q()<=v<=c[4]]
balanced=M/3<=X<=2*M/3
cover0=[sum((v*intersection(s,c)/area(c) for v,c in zip(x,cells)),Q()) for s in stars];cover1=[sum(((c[4]-v)*intersection(s,c)/area(c) for v,c in zip(x,cells)),Q()) for s in stars]
# Repair within fixed total source z by moving mass between sides, without decreasing any already feasible owner below its threshold.
transfers=[]
for j,(owner,demand) in enumerate(zip(owners,ds)):
 if owner==-1:continue
 for k,c in enumerate(cells):
  deficit=demand-(cover0[j] if owner==0 else cover1[j])
  if deficit<=0:break
  target=intersection(stars[j],c)/area(c)
  if not target:continue
  limit=min((c[4]-x[k] if owner==0 else x[k]),(2*M/3-X if owner==0 else X-M/3))
  for i,o in enumerate(owners):
   if o in (-1,owner):continue
   frac=intersection(stars[i],c)/area(c)
   if frac:
    margin=(cover0[i] if o==0 else cover1[i])-ds[i]
    limit=min(limit,max(Q(),margin)/frac)
  move=min(max(Q(),limit),deficit/target)
  if move:
   direction=1 if owner==0 else -1;x[k]+=direction*move;X+=direction*move;transfers.append((j,k,direction*move))
   for i,s in enumerate(stars):
    gain=direction*move*intersection(s,c)/area(c);cover0[i]+=gain;cover1[i]-=gain
balanced=M/3<=X<=2*M/3
budget_violations=[i for i,(v,c) in enumerate(zip(x,cells)) if not Q()<=v<=c[4]]
shortfalls=[max(Q(),d-(cover0[j] if o==0 else cover1[j])) if o!=-1 else Q() for j,(o,d) in enumerate(zip(owners,ds))]
ret=sum((v for v,o in zip(vs,owners) if o!=-1),Q());lost=sum((v for v,o in zip(vs,owners) if o==-1),Q());V=sum(vs,Q());assert ret+lost==V
repair0=sum((v for v,o in zip(shortfalls,owners) if o==0),Q());repair1=sum((v for v,o in zip(shortfalls,owners) if o==1),Q());MT=M+repair0+repair1;XT=X+repair0;repair_balanced=MT/3<=XT<=2*MT/3
valid=not budget_violations and balanced and not any(shortfalls)
repair_valid=not budget_violations and repair_balanced
f=lambda x:[str(x.numerator),str(x.denominator)]
out={'valid_without_repair':valid,'valid_after_explicit_repair':repair_valid,'budget_violation_indices':budget_violations,'balanced':balanced,'M':f(M),'X':f(X),'owners':owners,'star_source0':list(map(f,cover0)),'star_source1':list(map(f,cover1)),'owner_shortfalls':list(map(f,shortfalls)),'retained':f(ret),'lost':f(lost),'V':f(V),'repair0':f(repair0),'repair1':f(repair1),'repair_total':f(repair0+repair1),'repaired_M':f(MT),'repaired_X':f(XT),'repaired_balance':repair_balanced,'clamp_allocation_l1':f(clamp_cost),'transfers':[{'star':i,'cell':k,'change':f(v)} for i,k,v in transfers],'repaired_x':list(map(f,x)),'original_source_M':f(oldM),'source_rounding_increase':f(roundedM-oldM),'input_sha256':h(a.input),'source_sha256':h(a.source),'geometry_sha256':h(a.geometry_data),'geometry_seed':src['seed'],'source_bound_by_geometry':True,'script_sha256':h(Path(__file__)),'runtime':{'python':sys.version,'sys_executable':sys.executable,'platform':platform.platform(),'argv':[sys.executable]+sys.argv,'wall_seconds':time.perf_counter()-start,'cpu_seconds':time.process_time()-cpu,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss},'scope':'fixed allocation; repair adds source separately, original z-only budget then changes; no solver optimality claim'}
a.output.write_text(json.dumps(out,indent=2)+'\n');print('valid',valid,'repair_valid',repair_valid,'shortfalls',sum(v>0 for v in shortfalls),'retained',float(ret),'lost',float(lost),'repair',float(repair0+repair1),'balance',balanced,'runtime',out['runtime']['wall_seconds'])
