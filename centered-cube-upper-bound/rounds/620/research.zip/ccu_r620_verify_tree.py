import argparse,json,hashlib,time
from pathlib import Path
from fractions import Fraction as F
p=argparse.ArgumentParser();p.add_argument('--geometry',required=True);p.add_argument('--split',required=True);p.add_argument('--tree',required=True);p.add_argument('--output',required=True);a=p.parse_args();start=time.perf_counter()
gdata=json.loads(Path(a.geometry).read_text());sdata=json.loads(Path(a.split).read_text());tdata=json.loads(Path(a.tree).read_text())
geos={g['seed']:g for g in gdata['geometries']};splits={(s['seed'],str(s['alpha'])):s for s in sdata['results']};result=[]
for t in tdata['results']:
 g=geos[t['seed']];s=splits[t['seed'],str(t['alpha'])];z=s['source_numerators'];den=s['rounded_source_denominator'];N=len(g['d']);d=[F(x)*den for x in g['d']];v=[F(x) for x in g['v']];boxes=[tuple(map(F,x['cell'])) for x in g['patterns']];stars=[tuple(map(F,x)) for x in g['stars']];masks=[x['mask'] for x in g['patterns']]
 nodes={n['id']:n for n in t['nodes']};children={};roots=[]
 for n in nodes.values():
  if n['parent'] is None:roots.append(n['id'])
  else:children.setdefault(n['parent'],[]).append(n['id'])
 assert len(roots)==1 and len(nodes)==len(t['nodes'])
 def capture(ids,j):return sum(z[c] for c in ids if masks[c]>>j&1)
 init=[capture(range(len(z)),j)-d[j] for j in range(N)];spent=[F(0)]*N;remaining=[F(0)]*N;lost=[];survived=[];leafmass=0;visited=set();stack=[(roots[0],list(range(len(z))),list(range(N)))]
 while stack:
  ni,ids,recv=stack.pop();assert ni not in visited;visited.add(ni);node=nodes[ni];mass=sum(z[c] for c in ids);caps={j:capture(ids,j) for j in recv};slack={j:caps[j]-d[j] for j in recv};assert all(q>=0 for q in slack.values())
  assert node['receiver_indices']==recv and node['source_mass_numerator']==mass and node['source_cell_count']==len(ids)
  assert list(slack.values())==node['receiver_slack_numerators']
  if node['leaf']:
   assert not children.get(ni)
   if recv:assert all(max(stars[j][2*k] for j in recv)<min(stars[j][2*k+1] for j in recv) for k in range(2))
   lv=sum((v[j] for j in recv),F());assert lv<=F(81,64)*F(mass,den) and lv*16==node['leaf_receiver_cells']
   survived.extend(recv);leafmass+=mass
   for j in recv:remaining[j]=slack[j]
  else:
   axis=node['axis'];cut=F(node['cut_quarter_units'],4);left=[c for c in ids if boxes[c][2*axis+1]<=cut];right=[c for c in ids if boxes[c][2*axis]>=cut];assert len(left)+len(right)==len(ids) and set(left).isdisjoint(right)
   assert sum(z[c] for c in left)==node['left_mass_numerator'] and sum(z[c] for c in right)==node['right_mass_numerator']
   lrecv=[];rrecv=[];ll=[];burn=[]
   for j in recv:
    lc=capture(left,j);rc=caps[j]-lc;b=min(lc,rc,slack[j]);spent[j]+=b;burn.append([j,b])
    if max(lc,rc)<d[j]:ll.append(j)
    else:(lrecv if lc>=rc else rrecv).append(j)
   assert ll==node['first_lost_indices'] and sum(v[j] for j in ll)*16==node['first_lost_cells'] and burn==node['slack_spent_numerators'];lost.extend(ll)
   kids=sorted(children[ni]);assert len(kids)==2;stack.extend([(kids[0],left,lrecv),(kids[1],right,rrecv)])
 assert len(visited)==len(nodes) and sorted(lost+survived)==list(range(N)) and leafmass==sum(z)
 assert all(spent[j]+remaining[j]==init[j] for j in range(N))
 L=sum((v[j] for j in lost),F());S=sum((v[j] for j in survived),F());assert L*16==t['lost_cells'] and S*16==t['survived_cells'] and L+S==sum(v)
 result.append({'seed':t['seed'],'alpha':t['alpha'],'policy':t['policy'],'nodes':len(nodes),'lost':str(L),'survived':str(S),'verified':True})
qualification=[]
for sr in sdata['results']:
 gg=geos[sr['seed']];zz=sr['source_numerators'];dd=sr['rounded_source_denominator'];mm=[pp['mask'] for pp in gg['patterns']];ratios=[F(sum(zc for zc,mask in zip(zz,mm) if mask>>j&1),dd)/F(dj) for j,dj in enumerate(gg['d'])];bad=[j for j,q in enumerate(ratios) if q>=2]
 qualification.append({'seed':sr['seed'],'alpha':sr['alpha'],'strict_near':not bad,'violations':bad,'ratios':[str(q) for q in ratios]})
# Independent exact check of the single discretization-scope example.
from functools import lru_cache
ss=[(F(-3),F(-1)),(F(1),F(3)),(F(-2),F(1,2)),(F(-1,2),F(2))]
source=[(F(-2),F(-1),F(9,4)),(F(1),F(2),F(9,4)),(F(-1,2),F(1,2),F(9,16))]
def smass(l,r):return sum((max(F(0),min(r,b)-max(l,a))*density for a,b,density in source),F())
demand=[r-l for l,r in ss];vv=[q/8 for q in demand];aa=[smass(l,r) for l,r in ss];assert all(d<=a<2*d and a==d+v for d,a,v in zip(demand,aa,vv))
endpoints=sorted(set(x for star in ss for x in star));small=sorted(((l+r)/2-(r-l)/16,(l+r)/2+(r-l)/16) for l,r in ss);assert all(small[i][1]<small[i+1][0] for i in range(3))
for l,r in zip(endpoints,endpoints[1:]):assert sum(F(1,2) for x,y in ss if x<(l+r)/2<y)<=1
M=smass(F(-3),F(3));Q=sum(demand,F())/2;assert M==Q+sum(vv,F())/2==F(81,16)
@lru_cache(None)
def value(i,k):
 js=[j for j,(l,r) in enumerate(ss) if smass(max(endpoints[i],l),min(endpoints[k],r))>=demand[j]]
 if not js:return F(0)
 if max(ss[j][0] for j in js)<min(ss[j][1] for j in js):return sum((vv[j] for j in js),F())
 return max(value(i,t)+value(t,k) for t in range(i+1,k))
face_opt=value(0,len(endpoints)-1);assert face_opt==F(13,16)
left=[j for j,(l,r) in enumerate(ss) if smass(l,min(r,F(0)))>=demand[j]];right=[j for j,(l,r) in enumerate(ss) if smass(max(l,F(0)),r)>=demand[j]];assert left==[0,2] and right==[1,3]
continuous=sum(vv,F());assert continuous==F(9,8)
out={'discretization_example':{'face_grid_optimal':str(face_opt),'continuous_cut_zero':str(continuous),'KKT_exact':True,'root_mass':str(M)},'near_qualification':qualification,'results':result,'trees_verified':len(result),'elapsed_seconds':time.perf_counter()-start,'input_sha256':{k:hashlib.sha256(Path(getattr(a,k)).read_bytes()).hexdigest() for k in ('geometry','split','tree')},'scope':'Independent exact replay of supplied finite trees; no optimality or dimension theorem.'};Path(a.output).write_text(json.dumps(out,indent=2));print('independent exact tree replay:',len(result))
