import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[k]='1'
import argparse,concurrent.futures,hashlib,json,platform,resource,shlex,sys,time
from fractions import Fraction as F
from pathlib import Path
import numpy as np
D=1<<30

def one(g,r,b,policy):
 t=time.monotonic();cpu=time.process_time();n=len(g['d']);w=np.asarray(r['source_numerators'],dtype=np.int64);masks=np.asarray([p['mask'] for p in g['patterns']],np.uint64)
 A=((masks[:,None]>>np.arange(n,dtype=np.uint64))&1).astype(np.int64);starboxes=np.array([[int(4*F(t)) for t in cell] for cell in g['stars']],dtype=np.int64);boxes=np.array([[int(4*F(t)) for t in p['cell']] for p in g['patterns']],dtype=np.int64);assert np.all(boxes[:,0]<boxes[:,1]) and np.all(boxes[:,2]<boxes[:,3]); assert len(w)==len(boxes)
 demand=np.asarray(g['d'],np.int64)*D; vol=np.array([z[-1] for z in g['records']],np.int64); lam=np.array([float(v) for v in b['lambda']]); initial=A.T@w-demand;assert np.all(initial>=0)
 nodes=[]; stack=[(np.arange(len(w)),list(range(n)),0,None)]; lost_total=0; leafV=0; leafM=0; weighted_spend=0.; nodeid=0
 while stack:
  ids,recv,depth,parent=stack.pop();myid=nodeid;nodeid+=1;mass=int(w[ids].sum());cap=A[ids].T@w[ids];assert all(cap[j]>=demand[j] for j in recv)
  record={'id':myid,'parent':parent,'depth':depth,'source_mass_numerator':mass,'source_cell_count':len(ids),'receiver_indices':recv,'receiver_slack_numerators':[int(cap[j]-demand[j]) for j in recv]}
  incidence_constant=len(set(map(int,masks[ids])))<=1
  common=bool(recv) and max(starboxes[j,0] for j in recv)<min(starboxes[j,1] for j in recv) and max(starboxes[j,2] for j in recv)<min(starboxes[j,3] for j in recv)
  if not recv or common or incidence_constant:
   lv=int(vol[recv].sum()) if recv else 0; leafV+=lv;leafM+=mass
   # leaf receiver mass=lv/16; upper bound=(81/64)*mass/2^30.
   assert lv*64*D <=81*mass*16
   record.update({'leaf':True,'terminal_reason':'no_receivers' if not recv else 'assigned_common_intersection' if common else 'incidence_constant','incidence_mask':int(masks[ids[0]]) if incidence_constant else None,'leaf_receiver_cells':lv,'leaf_payment_margin_numerator':str(81*mass*16-lv*64*D)})
   nodes.append(record);continue
  options=[]
  for axis in (0,1):
   L=boxes[ids,axis*2];R=boxes[ids,axis*2+1];cuts=np.unique(np.r_[L,R])
   for cut in cuts[1:-1]:
    left=R<=cut;right=L>=cut
    # Source boxes are full original face-grid cells, so cuts cannot pass their interiors.
    if not np.all(left|right):raise AssertionError('cut crosses source cell; exact volume split required')
    if not left.any() or not right.any():continue
    li=ids[left]; lm=int(w[li].sum());rm=mass-lm; lcap=A[li].T@w[li];rcap=cap-lcap
    losses=[j for j in recv if max(lcap[j],rcap[j])<demand[j]];loss=int(vol[losses].sum()) if losses else 0
    bal=(3*min(lm,rm)>=mass);imb=abs(2*lm-mass)
    key=(loss,imb,axis,int(cut)) if policy=='min_loss' else ((0,loss,imb,axis,int(cut)) if bal else (1,imb,loss,axis,int(cut)))
    options.append((key,axis,int(cut),left,lm,lcap,rcap,losses,loss))
  if not options:raise AssertionError('nonconstant incidence without a valid face cut')
  _,axis,cut,left,lm,lc,rc,losses,loss=min(options,key=lambda z:z[0]);li=ids[left];ri=ids[~left];leftrecv=[];rightrecv=[];spend=[]
  for j in recv:
   a=int(lc[j]);c=int(rc[j]);sl=int(cap[j]-demand[j]);burn=min(a,c,sl);weighted_spend+=lam[j]*burn/D
   spend.append([j,burn]);
   if j not in losses:
    (leftrecv if a>=c else rightrecv).append(j)
  lost_total+=loss;record.update({'leaf':False,'axis':axis,'cut_quarter_units':cut,'left_mass_numerator':lm,'right_mass_numerator':mass-lm,'first_lost_indices':losses,'first_lost_cells':loss,'slack_spent_numerators':spend,'balanced_one_third':3*min(lm,mass-lm)>=mass});nodes.append(record)
  stack.append((ri,rightrecv,depth+1,myid));stack.append((li,leftrecv,depth+1,myid))
 assert lost_total+leafV==int(vol.sum()) and leafM==int(w.sum())
 burn_by_star=np.zeros(n,dtype=np.int64);remaining_by_star=np.zeros(n,dtype=np.int64)
 for node in nodes:
  if node['leaf']:
   for j,sl in zip(node['receiver_indices'],node['receiver_slack_numerators']):remaining_by_star[j]=sl
  else:
   for j,burn in node['slack_spent_numerators']:burn_by_star[j]+=burn
 assert np.array_equal(burn_by_star+remaining_by_star,initial)
 initialpot=float(np.dot(lam,initial.astype(float))/D);residualpot=float(np.dot(lam,remaining_by_star.astype(float))/D)
 return {'seed':g['seed'],'alpha':r['alpha'],'policy':policy,'status':'complete','nodes':nodes,'node_count':len(nodes),'leaf_count':sum(z['leaf'] for z in nodes),'max_depth':max(z['depth'] for z in nodes),'source_denominator':D,'receiver_denominator':16,'V_cells':int(vol.sum()),'lost_cells':lost_total,'survived_cells':leafV,'sum_leaf_source_numerator':leafM,'initial_weighted_slack_float':initialpot,'spent_weighted_slack_float':weighted_spend,'remaining_weighted_slack_float':residualpot,'per_star_slack_telescoping_exact':True,'telescoping_float_discrepancy':initialpot-weighted_spend-residualpot,'lambda_note':'original floating barrier lambda; rounded source does not satisfy exact KKT; no epsilon V identity assumed','elapsed_seconds':time.monotonic()-t,'cpu_seconds':time.process_time()-cpu,'peak_rss_bytes_macos':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
def task(arg):
 g,r,b=arg;return [one(g,r,b,'min_loss'),one(g,r,b,'balanced_then_loss')]
def main():
 p=argparse.ArgumentParser();p.add_argument('--split',type=Path,default=Path('/tmp/ccu_r620_split.json'));p.add_argument('--barrier',type=Path,default=Path('/tmp/ccu_r619_barrier.json'));p.add_argument('--output-dir',type=Path,default=Path('/tmp'));p.add_argument('--phase',choices=('first','remaining'),required=True);p.add_argument('--workers',type=int,default=1);a=p.parse_args();assert 1<=a.workers<=12;a.output_dir.mkdir(parents=True,exist_ok=True)
 split=json.loads(a.split.read_text());bar=json.loads(a.barrier.read_text());geos={g['seed']:g for g in bar['geometries']};bs={(r['seed'],r['alpha']):r for r in bar['results']};path=a.output_dir/'ccu_r620_tree.json';idx=a.output_dir/'ccu_r620_tree_index.json';md=a.output_dir/'ccu_r620_tree.md'
 if a.phase=='first':out={'split_sha256':hashlib.sha256(a.split.read_bytes()).hexdigest(),'barrier_sha256':hashlib.sha256(a.barrier.read_bytes()).hexdigest(),'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'python':sys.version,'numpy':np.__version__,'platform':platform.platform(),'commands':[],'results':[]};selected=[r for r in split['results'] if r['seed']==61901 and r['alpha']==.1]
 else:out=json.loads(path.read_text());selected=[r for r in split['results'] if not(r['seed']==61901 and r['alpha']==.1)]
 out['commands'].append(shlex.join([sys.executable]+sys.argv));start=time.monotonic()
 def save():
  path.write_text(json.dumps(out,separators=(',',':')));L=['# R620 actual-source full coordinate-cut trees','','All cut planes are exact source face coordinates; the original source boxes are endpoint-grid cells, so none is cut internally. Integer 2^-30 source masses and 1/16 receiver cells give exact decisions and slack telescopes. Leaves stop when no receivers remain, assigned stars share a common intersection, or source incidence is constant; every receiver payment was checked. Original floating λ is used only in an approximate weighted slack total; rounded source does not satisfy exact barrier KKT.','','Policy min_loss minimizes immediate first-loss then source imbalance. Policy balanced_then_loss restricts to 1/3–2/3 cuts when available and minimizes loss; when none exists it minimizes imbalance then loss.','','| seed | alpha | policy | lost | retained | nodes | max depth | elapsed s |','|---:|---:|:---|---:|---:|---:|---:|---:|']
  for q in sorted(out['results'],key=lambda z:(z['seed'],-z['alpha'],z['policy'][:2])):L.append('| %d | %.4g | %s | %.8g | %.8g | %d | %d | %.3g |'%(q['seed'],q['alpha'],q['policy'],q['lost_cells']/16,q['survived_cells']/16,q['node_count'],q['max_depth'],q['elapsed_seconds']))
  L+=['','The result is a finite hard-cut diagnostic, not a proof of an n-dimensional bound. Full trees, first-loss indices, per-star actual slack and leaf source payment checks are retained in JSON.'];md.write_text('\n'.join(L)+'\n')
 with concurrent.futures.ProcessPoolExecutor(max_workers=a.workers) as pool:
  for f in concurrent.futures.as_completed([pool.submit(task,(geos[r['seed']],r,bs[(r['seed'],r['alpha'])])) for r in selected]):
   result=f.result();out['results'].extend(result);save();print('done',result[0]['seed'],result[0]['alpha'],'loss',[q['lost_cells']/16 for q in result],flush=True)
 out['last_elapsed_seconds']=time.monotonic()-start;save();idx.write_text(json.dumps({'phase':a.phase,'profile_count':len(out['results'])//2,'policy_trees':len(out['results']),'workers':a.workers,'wall_seconds':out['last_elapsed_seconds'],'cpu_sum_seconds':sum(q['cpu_seconds'] for q in out['results']),'max_worker_rss_bytes':max(q['peak_rss_bytes_macos'] for q in out['results']),'commands':out['commands'],'split_sha256':out['split_sha256'],'barrier_sha256':out['barrier_sha256'],'script_sha256':out['script_sha256']},indent=2))
if __name__=='__main__':main()
