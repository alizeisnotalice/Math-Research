"""R613 bounded exact scalar check for the coordinate-split candidate; no operator claim."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
from fractions import Fraction as Q
from math import comb,isqrt,factorial
from pathlib import Path
import json,time,sys,platform,hashlib,resource
import flint
from flint import arb,ctx
START=time.perf_counter();ctx.prec=256

def A(q):
 q=Q(q);return arb(q.numerator)/q.denominator
def iv(q):return {'lo_exact':str(q.lower().fmpq()),'hi_exact':str(q.upper().fmpq()),'display':q.str(32)}
# Exact Taylor interval: after term40, first omitted term41 and subsequent ratios<=9/42.
J=40;partial=sum((Q(9**j,factorial(j)) for j in range(J+1)),Q(0))
first=Q(9**(J+1),factorial(J+1));remainder=first/(1-Q(9,J+2));upper=partial+remainder
assert Q(8000)<partial<upper<Q(8192)
einv_lo=1/upper;einv_hi=1/partial
rows=[]
for n in [64,128,256,1024]:
 m=n//2;d=isqrt(9*n)
 if d*d<9*n:d+=1
 assert (d-1)**2<9*n<=d*d
 k=m-d;assert k>=0
 threshold=m//2+1
 terms=[comb(k,x)*comb(n-k,m-x) for x in range(max(threshold,m-(n-k)),min(k,m)+1)]
 numerator=sum(terms);denominator=comb(n,m);p=Q(numerator,denominator)
 assert p<=Q(1,8192)<einv_lo
 rows.append({'n':n,'m':m,'d_ceil_3sqrt_n':d,'d_ceiling_exact_squared_guard':True,'k':k,'strict_event':'X>m/2','first_integer_in_event':threshold,
  'model':'X=|S intersect I|, fixed |S|=k, I uniform over all m-subsets of n coordinates',
  'tail_numerator_integer':str(numerator),'tail_denominator_integer':str(denominator),'tail_probability_exact':str(p),'tail_probability':iv(A(p)),
  'positive_numerator_terms':len(terms),'tail_le_1_over_8192_exact':True,'margin_to_1_over_8192_exact':str(Q(1,8192)-p),'conclusion':'tail<=1/8192<e^-9 by e^9<8192; exact finite formula check only'})
alpha_base=Q(256,225)
alpha_coarse=alpha_base/(1-Q(16,8000))
assert 1-Q(16,8000)>0 and alpha_coarse**2<2
alpha_lo=alpha_base/(1-16*einv_lo);alpha_hi=alpha_base/(1-16*einv_hi)
assert alpha_lo<alpha_hi<alpha_coarse and alpha_hi**2<2
out={'status':'PASS_4_EXACT_HYPERGEOMETRIC_TAILS_AND_ALPHA_SCALAR_BOUND','e9_certificate':{'Taylor_last_degree':J,'partial_sum_exact':str(partial),'first_omitted_term_exact':str(first),'remainder_upper_exact':str(remainder),'upper_bound_exact':str(upper),'strict_bounds':'8000<partial<e^9<upper<8192','inverse_exp_minus9_rational_interval':[str(einv_lo),str(einv_hi)],'scope':'Positive exponential Taylor series, remainder geometric since ratios after term41 are at most9/42.'},
 'rows':rows,'alpha_certificate':{'definition':'alpha=(16/15)^2/(1-16e^-9)','rational_lower_bound_exact':str(alpha_lo),'rational_upper_bound_exact':str(alpha_hi),'coarse_upper_using_e9_gt_8000_exact':str(alpha_coarse),'coarse_upper_square_exact':str(alpha_coarse**2),'two_minus_coarse_upper_square_exact':str(2-alpha_coarse**2),'strict_below_sqrt2':True,'display_interval':[iv(A(alpha_lo)),iv(A(alpha_hi))]},
 'scope':'Scalar constants and four prescribed hypergeometric finite tails only. Does not prove the general tail estimate, synchronous tensor estimate, recurrence, or any operator/weak-type bound. Original separate-layer frozen recursion files untouched.',
 'error_policy':'All combinatorial counts, tail probabilities, ceiling guards, Taylor bounds, inverse exponential and alpha inequalities are exact Fraction/integer. Arb256 only provides outward decimal displays. No Monte Carlo or numerical integration.',
 'versions':{'python':platform.python_version(),'python_flint':flint.__version__},'interpreter':sys.executable,'command':[sys.executable,*sys.argv],'arb_bits':ctx.prec,'processes':1,'runtime_seconds':time.perf_counter()-START,'peak_rss_bytes_macos':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
output=Path(sys.argv[1]) if len(sys.argv)>1 else Path('/tmp/ccu_r613_split_certificate.json');output.write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'status':out['status'],'tails':[{'n':r['n'],'d':r['d_ceil_3sqrt_n'],'k':r['k'],'p':r['tail_probability']['display']} for r in rows],'alpha_coarse_upper':str(alpha_coarse),'alpha_hi':A(alpha_hi).str(32),'seconds':out['runtime_seconds'],'script_sha256':out['script_sha256']},indent=2))
