"""R613: separate-layer supremum arithmetic, not an operator inequality."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
from fractions import Fraction as Q
from math import comb,isqrt
from pathlib import Path
import json,time,sys,platform,hashlib,resource
import sympy as sp
import flint
from flint import arb,ctx
START=time.perf_counter();ctx.prec=256
BITS=256;DEN=2**BITS

def A(q):
 q=Q(q);return arb(q.numerator)/q.denominator
def iv(q):return {'lo_exact':str(q.lower().fmpq()),'hi_exact':str(q.upper().fmpq()),'display':q.str(32)}
def root_bounds(k):
 m=isqrt(k*DEN*DEN);lo=Q(m,DEN);hi=lo if m*m==k*DEN*DEN else Q(m+1,DEN)
 assert lo*lo<=k<=hi*hi
 return lo,hi
def radical_sum(weights):
 lo=Q(0);hi=Q(0);value=arb(0)
 for k,w in enumerate(weights):
  l,u=root_bounds(k);lo+=w*l;hi+=w*u;value+=A(w)*A(k).sqrt()
 assert lo<=hi
 return value,lo,hi
def rat_interval(lo,hi):return {'lo_exact':str(lo),'hi_exact':str(hi)}
t,n,k=sp.symbols('t n k',positive=True)
derivative=sp.diff(t**k/(1+t)**n,t)
assert sp.simplify(derivative/(t**(k-1)/(1+t)**(n+1))-(k-(n-k)*t))==0
rows=[]
for dim in [8,16,32,64,128]:
 m=dim//2;bs=[];layers=[]
 for j in range(m+1):
  tt=Q(0) if j==0 else Q(j,dim-j)
  b=Q(1) if j==0 else Q(comb(dim,j)*j**j*(dim-j)**(dim-j),dim**dim)
  if j>0:assert b==Q(comb(dim,j))*tt**j/(1+tt)**dim and 0<tt<=1
  bs.append(b);layers.append({'k':j,'maximizing_t_exact':str(tt),'b_exact':str(b)})
 mass=sum(bs,Q(0));weighted,wlo,whi=radical_sum(bs);rnlo,rnhi=root_bounds(dim)
 lower=Q(3*m,20);assert wlo>lower
 common=[]
 for tt in [Q(1,3),Q(1)]:
  weights=[Q(comb(dim,j))*tt**j/(1+tt)**dim for j in range(m+1)]
  val,lo,hi=radical_sum(weights);wmass=sum(weights,Q(0));p=tt/(1+tt)
  # Cauchy: truncated sqrt expectation <=sqrt(EK)<=sqrt(n/2).
  assert wmass<=1 and val<A(dim*p).sqrt()
  common.append({'common_t_exact':str(tt),'binomial_p_exact':str(p),'truncated_mass_exact':str(wmass),'truncated_E_sqrt_K':iv(val),'truncated_E_sqrt_K_rational_certificate':rat_interval(lo,hi),'over_sqrt_n':iv(val/A(dim).sqrt()),'over_sqrt_n_rational_certificate':rat_interval(lo/rnhi,hi/rnlo),'Cauchy_upper_sqrt_np':iv(A(dim*p).sqrt())})
 rows.append({'n':dim,'k_range':[0,m],'layers':layers,'sum_b_exact':str(mass),'sum_b':iv(A(mass)),'sum_b_over_sqrt_n':iv(A(mass)/A(dim).sqrt()),
  'separate_layer_hypothetical_cost_Ck_sqrt_k':iv(weighted),'separate_cost_rational_certificate':rat_interval(wlo,whi),'separate_cost_over_n':iv(weighted/dim),'separate_cost_over_sqrt_n':iv(weighted/A(dim).sqrt()),'separate_cost_over_sqrt_n_rational_certificate':rat_interval(wlo/rnhi,whi/rnlo),
  'analytic_linear_lower_bound_exact':str(lower),'linear_lower_bound_strictly_passes':True,'common_scale_all_t_upper_sqrt_n_over_2':iv(A(Q(dim,2)).sqrt()),'separate_cost_minus_all_common_scale_upper':iv(weighted-A(Q(dim,2)).sqrt()),'common_t_examples':common})
out={'status':'PASS_5_EXACT_SEPARATE_LAYER_RECURSION_ROWS','definition':'b_nk=max_(0<=t<=1) binom(n,k)t^k/(1+t)^n, 0<=k<=floor(n/2). k0 maximum1 at t0; k>0 maximum at t=k/(n-k).',
 'closed_formula':'b_nk=binom(n,k) k^k(n-k)^(n-k)/n^n for k>0; b_n0=1.',
 'derivative_symbolic_residual':'0 after dividing by positive t^(k-1)/(1+t)^(n+1), derivative sign is k-(n-k)t',
 'independent_vs_common':'Separate cost S_n=sum_(k<=n/2)b_nk sqrt(k). Common F_n(t)=sum_(k<=n/2) sqrt(k) binom(n,k)t^k/(1+t)^n=E[sqrt(K)1_(K<=n/2)], K~Bin(n,t/(1+t)). This is unconditioned/truncated expectation; no renormalization.',
 'analytic_common_bound':'For every single t in[0,1], F_n(t)<=sqrt(EK)<=sqrt(n/2), by Cauchy. Examples t1/3 and1 are not claimed to optimize F_n.',
 'analytic_independent_lower':'At p=k/n, binomial mode is k and variance<=k. Chebyshev places probability>=3/4 in |X-k|<2sqrt(k), containing at most4sqrt(k)+1<=5sqrt(k) integers for k>=1. Thus b_nk sqrt(k)>=3/20, and S_n>=3 floor(n/2)/20. Hence this independent-layer arithmetic cannot stay O(sqrt(n)). No operator inequality asserted.',
 'scope':'Diagnoses the loss in a hypothetical separate-layer recursion Ck=sqrt(k). It does not prove that an actual recursive operator must pay this sum, nor supply an actual geometric input, nor rule out a common-scale approach.',
 'skill':'math-l03-rational-and-interval-certificates, SKILL and provenance read. Uses exact rational squared-endpoint certificates; does not claim the skill audited python-flint API or any external theorem.',
 'rows':rows,'error_policy':'Maximizers, b and mass sums exact Fraction. Every sqrt(k) also bracketed by dyadic rational endpoints using integer isqrt and exact squared comparisons at256 bits; weighted costs/normalizations have independent rational interval certificates. Arb256 evaluates displays and comparisons. No sampling, optimization or parameter scan.',
 'versions':{'python':platform.python_version(),'sympy':sp.__version__,'python_flint':flint.__version__},'interpreter':sys.executable,'command':[sys.executable,*sys.argv],'arb_bits':ctx.prec,'rational_sqrt_bits':BITS,'processes':1,'runtime_seconds':time.perf_counter()-START,'peak_rss_bytes_macos':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
output=Path(sys.argv[1]) if len(sys.argv)>1 else Path('/tmp/ccu_r613_recursion.json');output.write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'status':out['status'],'rows':[{'n':r['n'],'sum_b':r['sum_b']['display'],'separate_cost':r['separate_layer_hypothetical_cost_Ck_sqrt_k']['display'],'separate_cost_over_n':r['separate_cost_over_n']['display'],'common_upper':r['common_scale_all_t_upper_sqrt_n_over_2']['display']} for r in rows],'seconds':out['runtime_seconds'],'script_sha256':out['script_sha256']},indent=2))
