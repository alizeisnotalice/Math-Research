"""Independent exact checks of the two R613 scalar certificate files."""
from fractions import Fraction as F
from math import comb,isqrt
from pathlib import Path
import json,sys
base=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).parent
j=json.loads((base/'RESULTS.json').read_text());q=json.loads((base/'SPLIT_RESULTS.json').read_text())
count=0
for row in j['rows']:
 n=row['n'];lo=F(0);hi=F(0)
 for layer in row['layers']:
  k=layer['k'];p=F(k,n);b=comb(n,k)*p**k*(1-p)**(n-k)
  assert b==F(layer['b_exact'])
  den=1<<320;z=isqrt(k*den*den);l=F(z,den);u=l if z*z==k*den*den else F(z+1,den)
  assert l*l<=k<=u*u
  lo+=b*l;hi+=b*u;count+=1
 c=row['separate_cost_rational_certificate']
 assert F(c['lo_exact'])<=lo<=hi<=F(c['hi_exact'])
 assert lo>=F(3*(n//2),20)
for row in q['rows']:
 n,m,k=row['n'],row['m'],row['k']
 numerator=sum(comb(m,x)*comb(n-m,k-x) for x in range(m//2+1,min(m,k)+1) if 0<=k-x<=n-m)
 assert F(numerator,comb(n,k))==F(row['tail_probability_exact'])<=F(1,8192)
term=F(1);total=term
for i in range(1,41):
 term*=F(9,i);total+=term
upper=total+term*F(9,41)/(1-F(9,42))
assert 8000<total<upper<8192
bound=F(256,225)/(1-F(16,8000))
assert bound==F(5120,4491) and bound*bound<2
print(json.dumps({'independent_layers':count,'radical_bits':320,'independent_hypergeometric_rows':len(q['rows']),'taylor_bounds_and_alpha':True,'scope':'exact scalar certificates only, no operator bound'},ensure_ascii=False))
