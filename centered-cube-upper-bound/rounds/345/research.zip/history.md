# R345 bounded history check: sourcewise top-mass window

## Search boundary

Read existing `/tmp/r339_main.md`, `/tmp/r339_geometry.md`, `/tmp/r340_core.md`, `/tmp/r341_geometry.md`, `/tmp/r342_geometry.md`, `/tmp/r344_geometry.md`, and `/tmp/r344_main.md`; also read the README and searched the Markdown/TeX members of archived `rounds/{339,340,341,342,343,344}/research.zip`. The terms checked included `Mmax`, `esssup`, source/top-mass windows, local source masses, and the `exp(-sqrt(n))` threshold. No broader archive search was done.

## Findings

1. **R339 global mass-window receipt is the nearest already-paid result, but the text fixes its window across source points.** `/tmp/r339_geometry.md:7-17` states, for fixed `0<L≤U`, `G_out[L,U] ≤ [1+log(λU/(q_-L))] W`; `:19-29` applies the fixed global window `[ηW,W]`. The proof reduces the branch to a source-centered count `A_y(r)=|{u:L≤m_u≤U, R_u≤r, y∈Q_u}|` (`:40-57`). It also says the same receipt holds after restricting the source, while endpoint masses remain the original full-f masses (`:17`). The archived `rounds/339/research.zip::geometry.md` and `::main.md` match these statements. They do **not** state the moving window `[η Mmax(y), Mmax(y)]` or name `Mmax(y)`.

   The candidate is a close pointwise-window corollary of that proof: at fixed source `y`, substitute `L(y)=e^{-√n}Mmax(y)` and `U(y)=Mmax(y)` into the center-count receipt; the ratio is `U/L=e^{√n}`, yielding exactly `[1+√n+log(λ/q_-)] f(y)` before source integration. Thus this is not an unrelated new price mechanism. The archived theorem is written for fixed `L,U`; extending it pointwise requires checking measurability/zero-mass conventions for `Mmax(y)` and applying the proof with source-dependent endpoints. No archived section expressly performs that substitution, so classify it as **not previously implemented verbatim; directly suggested by / apparently obtainable from the R339 pointwise proof**, not as an already frozen Mmax branch.

2. **R340–342 pay receiver-centered local source-growth windows, which are different gates.** R341 `/tmp/r341_geometry.md:7-31` uses `M_L(u)=∫_{Q_{2L}(u)}f` and pays `m_u≥ηM_L(u)`; its unpaid complement is still a receiver-indexed growth condition. R342 `/tmp/r342_geometry.md:7-15,55-66` uses `M_L^+(u)=∫_{Q_{2L+b}(u)}f` and similarly pays the large-endpoint branch. R342's shared source-cell splitting does not replace that endpoint gate by a source-point maximum. These are **related local-window payments, not the same Mmax(y) branch**.

3. **R344 pays only the clipped source component on the R342 bad endpoint set.** `/tmp/r344_geometry.md:5-15,140-151` freezes all masses/`J` using full `f`, pays the clipped component, and explicitly leaves `G_A[(f−T)_+ ]` without a root-order budget. It does **not** pay the proposed sourcewise top-mass window for the excess source.

## Conclusion for the proposed idea

No recent archive explicitly implements the exact `Mmax(y)` top-window as a named/persisted paid branch. R339 already contains the same source-centered center-volume mechanism and the matching logarithmic mass-window bound for fixed endpoints; making the endpoints depend on `y` appears to be a direct pointwise extension of its proof, subject to the noted measurability conventions. R340–342 local-growth payments and R344 clipping are distinct and do not already settle the idea on their own. This is a bounded archive conclusion, not a new proof or global novelty claim.
