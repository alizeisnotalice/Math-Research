# R345 — Source-quantile boundary mass and the original large-endpoint error

**Status.** This is a proved auxiliary source-geometry approximation with an explicit error price. It does not pay the remaining internal-cell traffic or prove a new root-order bound. It uses source mass, not boundary volume, so arbitrary thin source concentration is allowed.

## One shared source partition

Let f≥0 belong to L¹(Rⁿ), and let D be any fixed measurable source set with 0<M=∫D f<∞. The set D need not be bounded. Put dσ=1_D f dy. For an integer N≥2, the marginal of σ along each coordinate is atomless, because σ is absolutely continuous with respect to n-dimensional Lebesgue measure. Its cumulative distribution is continuous and has limits 0,M. Thus choose N−1 finite quantile cuts on each coordinate so that the N half-open intervals, including the two unbounded tails, each define a coordinate slab of σ-mass M/N.

Take the product partition into Nⁿ ambient rectangular cells C_j. Use one fixed choice of all cuts for every receiver, source point and physical prefix. The actual source pieces are D∩C_j, with masses W_j=σ(C_j), so

    Σ_jW_j=M,       0≤W_j≤M/N.                       (1)

The second bound follows by containment in any one of the marginal slabs. Null hyperplane faces do not affect σ. Empty pieces are allowed. If M=0, all traffic from D is zero and no quantiles are needed.

## Uniform true boundary-mass estimate

For any finite axis-parallel cube Q, form its inner approximation on D by retaining precisely those complete ambient cells contained in Q, up to faces:

    c_Q^−(y)=1_D(y) Σ_{j:C_j⊂Q}1_{C_j}(y).

In particular an unbounded tail cell is never declared contained in a bounded Q. Let

    e_D(Q)=∫D f(y)[1_Q(y)−c_Q^−(y)]dy.

Then

    0≤e_D(Q)≤min{f(D∩Q), 2nM/N}.                     (2)

Proof. If y∈D∩Q lies in a cell not wholly contained in Q, then in at least one coordinate its marginal interval crosses a face of Q. For each coordinate there are at most two such marginal intervals. Each of their full coordinate slabs has σ-mass M/N. The union bound therefore gives 2nM/N. If a face coincides with a quantile cut, the same estimate holds and may overcount a null face. No volume-to-source-mass inference is made. This is one uniform estimate for every cube, not a favorable partition chosen separately for each cube.

The receiver-dependent condition C_j⊂Q_u is measurable: for finite cell endpoints it is a finite system of inequalities involving u and the given measurable R_u, and unbounded cells fail it. Hence the approximation can be inserted directly into the original integrals.

## Error in the frozen original traffic

Use the full original hard contract from R344 main. In particular all masses m_u=∫Q_u f, q_u=m_u/R_uⁿ, μ, original full J_y(r), high-past Z, strict far-mass gate, outside-center gate, H, and ell remain determined by the full original f. Let A⊂E be any fixed measurable large-endpoint set.

Start from the source contribution G_A[f1_D]. Define G_A,D^− by replacing only the large-endpoint factor 1_D(y)c_u(y) by c_{Q_u}^−(y). Keep the small factor c_v(y) and every other field and gate unchanged. This produces an exact nonnegative split

    G_A[f1_D]=G_A,D^−+Err_A,D.                        (3)

The receiverwise row domination from the original positive traffic gives

    Err_A,D≤∫A q_u e_D(Q_u)/m_u du
       ≤∫A q_u min{1, 2nM/(Nm_u)}du.                (4)

For completeness, on the original far gate m_u−m_v≤m_u. The gated small-endpoint capture integral divided by the original J is at most one. Its multiplication by m_u cancels the large-endpoint factor 1/m_u in μ. Integrating the remaining source error gives e_D(Q_u), and the complete original physical tail is ell([R_u,b])=R_u^(-n). This proves (4). It neither recalculates a posterior from truncated data nor replaces the global denominator by a cell denominator.

For any 0<δ<1, choosing

    N≥max{2, ceil(2nM/(δ q_-aⁿ))}                    (5)

ensures m_u≥q_-aⁿ and hence

    Err_A,D≤δX_q(A).                                 (6)

The entire source is permitted: D=Rⁿ, M=W. No bounded support or bounded density is required. If only a subset of endpoints satisfies m_u≥2nM/(δN), (6) applies to that subset, while (4) remains the exact stated bound for all others. Alternatively, if a posterior concentration condition f(D∩Q_u)/m_u≥θ is separately known and e_D(Q_u)/m_u≤δθ, the retained complete cells carry at least (1−δ)θ of that same actual posterior. This observation does not itself give a lower comparison between m_u and M.

## Complexity and the exact unpaid part

There are Nⁿ source cells. Condition (5) can make N depend strongly on W/(q_-aⁿ) and on δ. These costs are explicit; the construction is not a dimension-free or polynomial-size discretization. Each source point belongs to one cell, but a receiver cube can contain many cells, and its traffic is then split among all of them. Equation (1) does not authorize paying a separate full-W window fee at every receiver or every mass scale.

The internal term is exactly

    G_A,D^−=Σ_j ∫ell∫_{D∩C_j}f(y)1_{J≥H}/J
       ×∬_{E_r²}1_{C_j⊂Q_u}c_v(y)(m_u−m_v)
                     [all original gates]1_A(u)dμu dμv dy.  (7)

In particular m_u may greatly exceed W_j, and no posterior lower bound for an individual retained cell is furnished. A source-window theorem needing such a bound cannot be applied for free. Nor does splitting into many small cells automatically create a lower bound for the original capture square. Those are the remaining source-reuse and overlap questions.

For D=Rⁿ and an outer multiplier B, the approximation costs BδX_q(A), and leaves B G_A,D^− with all its original fields. Other already-paid endpoint/source branches must be made disjoint before using (3); this note adds no standalone source fee and does not add a new root-order receipt to the main ledger. Its content is the source-quantile geometry (2) and the original-traffic error estimate (4)–(6).

## Verification

The saved local script builds one fixed coordinate-quantile partition for each selected N from a nonuniform two-dimensional step source, then checks the exact boundary source mass for many genuine square positions and sizes. All integrations use rational rectangle intersections. It checks the shared partition and mass statement, not the original high-past traffic or a root-order estimate. Actual execution details follow below.

`/tmp/r345_core_checks.py` was actually run with Fraction arithmetic and passed 779 check units: 56 exact marginal-slab masses, 3 complete cell-partition checks, 450 square-boundary mass checks, and 270 posterior-ratio checks for positive captured mass. The fixed source consists of four disjoint rectangles with densities 50,4,3,8 and total mass 11; the narrow dense rectangle is included explicitly. For N=4,8,16, a single exact marginal-quantile partition is used for every one of 150 squares, spanning 25 centers and six side lengths. The largest observed exact loss divided by 2nW/N is 117/128. These are genuine source integrals over positive-volume sets, not point-source approximations. No q-band claim is imposed on this geometry-only fixture, and no G_out/high-past calculation or internal-cell payment is inferred from it. Only this note and its check script were authored; bounded delivery stops here.
