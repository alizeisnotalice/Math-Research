# R345 independent preliminary audit — terminal sourcewise top mass and low-future payment

Owned only `/tmp/r345_audit.md`; no Git/other-author edits and no new R345 author main proof read for these screens. Fixed original full hard field of R344: actual finite receiver du, f>=0 in L1, a<=R<=b<=2a, m_u=f(Q_u)=q_uR_u^n, q_-<=q_u<=lambda, original full J, K=exp(sqrt(n))>lambda/q_-, h,H, strict mass/past/outside gates and inclusive physical ell. All fields are frozen from the ORIGINAL f when a source component0<=g<=f is integrated. No general root closure is inferred.

## 1. Sourcewise essential maximum window — PASS (weaker interface)

Define M(y)=esssup_{u in E:c_u(y)=1}m_u relative to actual receiver du, and M0 when the capturing set is null. Since positive bounded m makes du and dmu equivalent, either receiver measure gives the same essential maximum. A measurable version follows from

 {M(y)>t}={integral_E c_u(y)1_{m_u>t}du>0}

for t>=0, using measurable rational levels. For each fixed y, m_u<=M(y) for capturing du-a.e. u. Tonelli gives the same fact on the joint captured f(y)dy du measure, hence also for every g<=f. Individual exceptional receiver/source pairs are not asserted to satisfy it pointwise. M0 contributes no original receiver-integrated traffic.

On the top-large source-pair gate m_u>=eta M(y), the original masses lie in[eta M(y),M(y)] joint-a.e. At each fixed y, the original small-endpoint posterior/J bound leaves actual large-center volume. The actual clipped radius window and inclusive ell tail give the source-row bound

 k_top(y)<=1+log(lambda/(eta q_-)).

Therefore G_top[g]<=[1+log(lambda/(eta q_-))]integral g for every actual outer source component g<=f, with ALL original fields/gates unchanged. There is no source partition or duplicate W charge. For eta=exp(-sqrt(n)), this is D_n integral g, D_n=1+sqrt(n)+log(4/3).

Comparison with the former R342 cover: if y belongs to Q_u and also Q_w, then Q_w subset Q_(3b)(u), by the coordinate triangle bound R_w+R_u/2<=3b/2. For n>=4,3b<=(1+sqrt(n))b, so M(y)<=f(Q_((1+sqrt(n))b)(u)). Hence every old covered receiver is top-large for almost every captured source. For n<=3, the original high-past traffic is empty at the actual fixed epsilon119/3072, since J_b<=(1+nlog2)/q_-<=4/q_-<h. This last small-dimension comparison MUST be tied to that actual epsilon (or a stated sufficient bound); it is not generally true for every epsilon<1 at n3. The top-window payment itself does not need the old-cover comparison or the small-dimension assertion.

The complementary strict gate m_u<eta M(y) supplies a positive-du-measure set of terminal captured witnesses w with m_w>m_u/eta. It supplies neither a uniformly positive selection probability nor a bounded-reuse assignment. Such w need not belong to the current physical prefix; indeed its larger mass forces a larger physical radius when1/eta>lambda/q_-. No such witness is inserted into J_y(r) for free.

## 2. Stronger low-terminal-future receipt — PASS

Fix s>0. At each source y let the ORIGINAL terminal captured measure be

 rho_y(du)=c_u(y)1_E(u)du/m_u,
 J=J_y(b),  U_y(t)=rho_y{m_u>t},  m_0=q_-a^n.

The sourcewise low-future gate is U_y(Km_u)<=s on the original large endpoint. All other original traffic factors remain; this is not an independent source or a changed posterior. The full source row for any large-endpoint subset B(y) is bounded, after the original inner-row/J cancellation and inclusive physical tail, by

 N_B(y)=integral_B q_u rho_y(du).

In particular N_B<=lambda rho_y(B). This identity retains the real units and full physical clock; it is not an unnormalized receiver count.

If J<=s, the entire original row is at most lambda J<=lambda s. If J>s, define

 tau(y)=inf{t>=m_0:U_y(t)<=s}.

The survival U_y(t)=rho_y(m>t) is nonincreasing and RIGHT-continuous, finite and zero for t>=lambda b^n. Thus tau is finite, U_y(tau)<=s, and U_y(t)>s for m_0<=t<tau. It is measurable: for fixed t>=m_0, {tau<=t}={U_y(t)<=s}. One may set tau=m_0 on J<=s or zero rows as well. This definition deliberately keeps the strict upper-mass convention.

Every low-future endpoint satisfies K m_u>=tau, hence m_u>=tau/K. Split it into its m_u>tau part and its closed middle window[tau/K,tau]. The high part is bounded by the COMPLETE original source row N_high<=lambda U_y(tau)<=lambda s. The middle part is priced at fixed y by the actual radius-window center envelope, with coefficient

 1+log(lambda K/q_-).

The original tau-mass atom lies ENTIRELY in that middle window, not in the high part, and cannot be lost by replacing U(tau) by a left-limit. If tau=m_0 while J>s because of a bottom mass atom, the very same closed middle window contains it; no fractional atom release or extra initialization is required. Radius clipping and the original terminal b atom retain their inclusive conventions.

Consequently the original low-future traffic, for any outer source component0<=g<=f, obeys

 G_lowfuture[g]<=[lambda s+1+log(lambda K/q_-)]integral g.       (1)

This is a genuine sourcewise positive payment for the ORIGINAL traffic. It uses a terminal mass quantile only as an upper-bound decomposition, not as a new current-prefix field or receiver law. It does not divide the original J by the tail measure.

Set s=sqrt(n)/q_-, K=exp(sqrt(n)) and q_-=3lambda/4. Then

 D_future=lambda s+1+log(lambda K/q_-)
         =1+log(4/3)+(7/3)sqrt(n).                              (2)

The zero-tail top-window gate of section1 is included in this low-future gate. Thus this is the stronger main source payment, and the top-window source coefficient is NOT separately added.

## 3. Exact new remainder, clipping and full ledger interface

The remainder is the unchanged original positive G with U_y(Km_u)>s, retaining the original strict LOWER mass-past condition Z_y(m_u/K-)>h, all original r prefixes and every source/center/far/H gate. It has true terminal upper captured measure>s above K m_u, not just an unquantified essential-supremum witness. Upper receivers may have R_w>r, so no claim J_y(r)>h+s follows without an independent prefix condition; terminal J_b>h+s is permitted by disjoint mass sets but supplies no new ledger payment here.

This new gate depends on BOTH y and u. Therefore it should not silently be denoted a fixed receiver set A. Nevertheless the R344 clipping proof applies: multiplying the original positive source kernel by any additional frozen mask in(y,r,u,v) bounded by1 preserves both Gamma(y)<=A_n and its original J_b>h support. Its adjoint moment still uses the full original field E,q,R and its paid receiver term is the FULL X_q, not a privatized subset. Hence, with the same T_clip and f=min(f,T_clip)+(f-T_clip)_+,

 G_highfuture[f]<=epsilon X_q+G_highfuture[(f-T_clip)_+].

Combining directly with the inherited R338 slot, while replacing the former R342 cover and not stacking old localization costs, gives

 BH<=G_highfuture[(f-T_clip)_+]+3epsilon X_q
                +(C_epsilon,n+D_future)W.

The entrance coefficient remains6epsilon X_q after its factor2; the old8lambda H W_beta,2d_eff A_n W_nu/H and all other unpaid slots stay. With the authentic same-X outer multiplier and old CZ account, the previous conditional1/4 and65/256 arithmetic remains. This is not an independent proof that all historical aggregation is valid. No new payment is attributed to the terminal high-future remainder, its source excess, or the bare existence of larger shared-source receivers.

## 4. Actual bounded tool checks and stopping point

Reviewer executed4265 exact Fraction strict-survival/quantile/window assertions over800 finite row/threshold cases, including96 bottom-atom crossing cases with tau=m_0 and J>s. All passed. They confirm the atom conventions and mass inequalities, not a generally realizable cube field, current-prefix future presence, or an integrated high-future traffic budget. The measure-theoretic source-row receipt above is analytical. No new author proof or full numeric pipeline was read/run for this screen.

The earlier rejected boundary-proportion proposal is preserved only as a short preliminary side record in `/tmp/r345_audit_pre.md`; it is not the main result or a source payment. The present main route is the positive sourcewise low-future receipt. Independent screen PASS with the precise terminal/current-prefix and source-dependent-mask guards above. Await final author/main/ledger files for byte-level comparison; only this owned file was written.


## Final geometric author comparison — PASS

Read complete `/tmp/r345_geometry.md` and `/tmp/r345_geometry_checks.py` after the independent screens above. The final positive-s theorem is the stronger main payment; the essential-maximum s0 case is a correctly measurable weaker special case, not an additional source fee. Actual du and dmu have the same null sets because m0<=m<=m1; the stated sourcewise essential bounds therefore transfer to joint captured source/receiver integrals by Tonelli. No pointwise claim is made for arbitrary exceptional representatives.

The strict terminal survival U(t)=rho{m>t} is right-continuous, its quantile is finite/measurable, and the proof correctly uses U(tau)<=s rather than a left limit. All tau-mass is put into the CLOSED middle window; none of the bottom atom is silently discarded when tau=m0 and J_b>s. The high-tail full-clock bound is integral q d rho<=lambda s, with no missing normalization. The middle mass ratio K gives exactly1+log(lambda K/q_-) through the actual center-volume envelope and the original complete ell tail. Source-dependent window endpoints are legal after fixing y; they do not require a preassigned source partition or new q/J. The full source-dependent first-moment bound is explicitly proved, not inferred from high past.

The comparison with the former R342 cover is correct for n>=4 using Q_w subset Q_(3b)(u), and for n<=3 is restricted to the actual epsilon119/3072 (indeed epsilon<=1/2 suffices). No false general n3 emptiness for all epsilon<1 is asserted. The complementary gate has actual terminal upper captured dmu-mass>s; its receivers may lie beyond the current r. The original lower past is in E_r by mass/radius ordering. These facts do NOT allow inserting the upper tail into the original current denominator or obtaining a paid global source-flow budget.

Parent reports actual fresh execution of5190 geometry Fraction assertions. The script includes scalar strict-tail/atom tests and an actual continuous one-dimensional first-moment fixture. Its whole receiver intervals, source mass/q1, covered moment3/2, complement1/2, and zero-future covered moment9/8 are consistent with direct capture-length integration. It is not a simulation or nonempty example of the original root high-past G. The complete physical clock is retained in the proof; a finite-menu compressed layer is not a new atom at the lower scale.

## Final source-quantile auxiliary comparison — PASS, not in the main payment

Read full `/tmp/r345_core.md` and its reproduction script. The source measure1_D f dy is finite and absolutely continuous, hence every coordinate marginal is atomless even if D is unbounded. Finite marginal quantile cuts exist at the distinct mass levels; unbounded tail intervals are included. Their product partition is shared by all cubes and prefixes, with N^n ambient cells and source pieces D intersect C_j. A cell is conservatively kept only when its full ambient rectangle is contained in the actual cube; no unbounded cell is falsely declared contained.

Every missed captured source point lies in one of at most two face-crossing marginal slabs per coordinate, each with true source mass M/N. Thus e_D(Q)<=min(f(D intersect Q),2nM/N) is a genuine source-mass estimate, not a boundary-volume inference. The original-traffic approximation replaces only the large-endpoint source-capture factor and keeps full m,q,J,small endpoint/past/geometric/H/ell fields. Its nonnegative error and bound integral_A q min(1,2nM/(Nm_u))du have the correct normalization and original inclusive tail.

The complexity N^n, possible strong dependence of N on W/(q_-a^n), and remaining complete-cell traffic are explicitly retained. In particular no lower posterior mass for an individual contained source cell is fabricated. The main route does not invoke this approximation, so no auxiliary delta fee or source payment is booked there. Parent reports fresh779 check units on the real nonuniform two-dimensional source and450 squares with a common partition for each N. This geometry-only fixture is not a q-band/high-past traffic field; unit counts do not certify a root budget or inner-cell payment.

## Final numeric code/result/notes — PASS at the disclosed interface scope

Read full `/tmp/r345_numeric.py`, final notes and saved result metadata. It uses actual positive receiver Lebesgue intervals, not receiver quadrature. Original full-source q1 is verified at every moving-response breakpoint; sources are compact period-one step densities with mass1 per period. The zero-length receiver deliberately included in the initial field contributes no captured length, J, essential maximum or traffic. Essential M is computed from POSITIVE capture length, not isolated source-boundary contact.

Source/receiver breakpoints make each fixed-gate row kernel affine on open segments. The script freezes the correct segment M or low-future gate before integrating that segment, and separately tests actual inclusive endpoint classifications. Future threshold crossings are solved exactly and added as rational breakpoints; equality plateaus are included. With masses1 and2 the independent terminal future formula, strict K2 boundary, and full-clock reconstruction are all valid. Diagnostic rational K5/4 or3/2 is not the original exp(sqrt(n)) choice; the claimed budget uses the sharper actual q=lambda1 in these examples, not a reset of a changing input.

The final numeric notes correctly repair the earlier “ell({1})” wording: the compressed lower-menu weight1/2 is the INTEGRAL over the continuous physical interval[1,2), and the terminal b2 atom separately has weight1/2. The script always computed those compressed weights correctly; no arithmetic change or retest was needed for that wording correction. Boundary values of a piecewise-affine source kernel are integrated through their segment limits, not arbitrary essential-M representatives.

Full f, min(f,T) and(f-T)_+ use the SAME original kernel and source-dependent gates. Their masses and integrals split exactly, including the correct excess rather than the full untruncated indicator tail. Logarithmic budgets use outward rational atanh-series bounds; kernel<=a rational LOWER bound for D is a sufficient (stronger) finite check, not a wrong-endpoint inference. Root eta is kept symbolic in the parameter checks rather than approximated to decide a gate.

Parent reports actual fresh2728 exact assertions, matching saved result PASS: top models275/368/383, low-future models439/587/653 and23 parameter checks. Ordinary display decimals are not interval evidence. The original n1 root h exceeds all J in these fields, so the numerics test sourcewise-window/terminal-first-moment interfaces, not a nonempty original high-past residual or complete history. These limitations are stated in main and notes. The primary reported total8697=5190+779+2728 is retained as scoped checks/check units; reviewer4265 preliminary atom checks and the earlier boundary exploration1441 checks are separate and NOT added.

## Final main, bounded history record and complete ledger — PASS

Read final `/tmp/r345_main.md`, `/tmp/r345_ledger.md` and `/tmp/r345_history.md`. The history record explicitly limits its search to recent339-344 files/archives and calls the top-window mechanism a pointwise extension of the earlier R339 argument. It does not assert global novelty or an independent archive-wide priority proof. This reviewer did not repeat the archive search; the actual mathematical applicability was independently proved above. The old boundary-proportion exploration remains only in audit_pre and is not a main payment, history counterexample to the target, or primary numeric total.

The final main accurately adopts CLIP-FIRST, which is sharper than the preliminary full-W ordering. Its exact frozen-field identity is

 G[f]=G[min(f,T_clip)]
       +G_lowfuture[(f-T_clip)_+]+G_highfuture[(f-T_clip)_+].

Thus the new source fee is D_n W_ex with W_ex=integral(f-T_clip)_+, not an additional D_nW bill on top of the former cover. The R344 clipping estimate applies first to the complete original endpoint field and costs epsilon X_q. Then the low-future theorem applies to the actual excess source with the SAME full-f terminal rho,m,q,J,U,past/outside/H/ell. No field is recomputed from the clipped or excess source, no source-dependent future gate is falsely treated as a receiver-only set, and no existing R342 cover fee is stacked again.

The final hard slot is correctly

 BH<=G_bi[g_ex]+3epsilon X_q+C_epsilon,n W+D_n W_ex,
 D_n=1+log(4/3)+(7/3)sqrt(n).

Its entrance retains8lambda H W and2d_eff A_n W_nu/H, doubles the residual/source terms, and has6epsilon X_q. W_beta=f and nu<=f are the same original hard-source contract; unrelated historical source labels are not identified. The inherited entrance/outer coefficients are carried conditionally, not entirely re-certified this round. Local exact arithmetic verifies6*(128/119)*(119/3072)=1/4; adding old CZ1/256 only on the authentic SAME-X account gives65/256, with191/256 unallocated. Relative to R344 no additional receiver cost is introduced; the source fee and residual are replaced, not accumulated round by round.

The exact unpriced remainder retains both lower and terminal upper captured capacities, the actual excess source, strict mass/outside/high-H/past predicates and original clock. Larger captured receivers are not yet a payable source resource or current-prefix credit. General soft dense crossing/post-crossing and nonembedded hard branches, wide/extreme scales and low-pe complements, chronological initial/deletion/future-source atoms, suffix credit, all source/scale/outer sums and limits remain explicitly due. The physical terminal b atom is not a chronological atom. No general root closure or “only constants/logs remain” claim is certified.

## Final byte bindings and disposition

Only this owned audit file was changed during final review. Parent replay reports and saved metadata are distinguished from proof/code inspection; no redundant full pipeline, optimizer or TeX/PDF compiler was run by the reviewer. Prior contract/clip/cover files are bound as inherited interfaces, not a re-audit of every original historical reduction. Earlier awaiting statements record preauthor stages and are superseded by this final comparison.

| File | SHA256 |
|---|---|
| /tmp/r345_main.md | `c460f71f589e2be0111dae203b2d2dc3091c1862fc6f9cfd5bdd196de377647f` |
| /tmp/r345_ledger.md | `c0fb4dbe928b0bd7cbfbba3c9d06e8445e9ac94a209b67a05fe3dbe319c8f2e2` |
| /tmp/r345_geometry.md | `7b8af94f0820e5f6c79b75bd2ee0b89647a53effa38599a95d2e148635148f66` |
| /tmp/r345_geometry_checks.py | `3968dbaa362c3c3081c4eb2535e495c81ff87276703ffd2228362f5466a59789` |
| /tmp/r345_core.md | `3d1060c76b122d2f04465f4881cadaaea9dd826327f379369b42ca6b2c990be7` |
| /tmp/r345_core_checks.py | `bf457c888e2d54181fdcd3ff74b0c5be980276db7be4c4dc7b997546de581393` |
| /tmp/r345_history.md | `f48e2b997d70e0c65320fda8e9a659f344f2e9370dc5542ed4826abcae0170dd` |
| /tmp/r345_numeric.md | `8491e41b25554062f372cc23d96b8dcc72b8528e34422c5243a7b9e6b4692b89` |
| /tmp/r345_numeric.py | `41114154860168efe74d4baa14aecd0ccf3848b197ed13ece5c0c2ba107dd823` |
| /tmp/r345_numeric_result.json | `fba39d6df1e3f17874edea18524bb1b27d2c0317938fe1cf13f8c821d34c5a5c` |
| /tmp/r345_audit_pre.md | `1a807ccb760ae3a13e6313a93831e7753c6173b81a1db7cae0058d4e8c942902` |
| /tmp/r340_core.md | `f030035399e805bb1a6a5f369d9c499bbf1500f74de02b53471d58107bc3ee90` |
| /tmp/r344_geometry.md | `d5b2f2d4468367dc53dbaf927e7cf1be57d1e7f31c777f87c51794a8b9c6b90a` |
| /tmp/r342_geometry.md | `d8d62f1ad59e894ed936fdd64328e608a1b6b682190dbc3b45aed826571dd983` |

Final disposition: PASS for the sourcewise low-future first-moment payment, exact atom conventions, clip-first replacement ledger, auxiliary source approximation and evidence scope. No outstanding correction requested. Frozen after final byte bindings; later content changes need a new binding. The joint high-past/high-future excess-source residual and complete global root budget remain unproved.

Final textual-scope receipt: read the final main opening clarification limiting the history search to339-344 sourcewise-top windows and excluding comprehensive novelty determination. Its current SHA c460f71f589e2be0111dae203b2d2dc3091c1862fc6f9cfd5bdd196de377647f was already captured in the final table. Rechecked all table bindings against current bytes; no mismatch. No formula/ledger change, extra run or outstanding correction.
