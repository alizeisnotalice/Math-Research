#!/usr/bin/env python3
"""Exact source-dependent top-mass windows in real 1D receiver fields."""
from fractions import Fraction as F
from pathlib import Path
from collections import Counter
from math import isqrt
import json
BASE=Path(__file__).resolve().parent
C=Counter()
def ck(k,v):C[k]+=1;assert v,k
def logbounds(x,N=32):
 if x==1:return F(0),F(0)
 if x<1:
  lo,hi=logbounds(1/x,N);return -hi,-lo
 t=(x-1)/(x+1);lo=2*sum((t**(2*j+1)/F(2*j+1) for j in range(N)),F(0));return lo,lo+2*t**(2*N+1)/(F(2*N+1)*(1-t*t))
def source(mode):
 if mode=='uniform':return [(F(-2),F(2),F(1))]
 profile=[(F(0),F(1,4),F(4)),(F(1,4),F(1),F(0))] if mode=='single_packet' else [(F(0),F(1,4),F(3)),(F(1,4),F(1,2),F(1)),(F(1,2),F(1),F(0))]
 return [(a+j,b+j,d) for j in range(-2,2) for a,b,d in profile]
def mass(src,lo,hi):return sum((max(F(0),min(b,hi)-max(a,lo))*d for a,b,d in src),F(0))
def capture_length(Ei,y):
 a,b,R=Ei;return max(F(0),min(b,y+R/2)-max(a,y-R/2))
def essential_M(E,y):return max([F(0)]+[R for a,b,R in E if capture_length((a,b,R),y)>0])
def Xi(E,y,M,eta):return sum((capture_length((a,b,R),y)/R for a,b,R in E if M>0 and R>=eta*M),F(0))

def actual_model(stage,E,mode):
 before=sum(C.values());src=source(mode);W=mass(src,F(-2),F(2));X=sum(b-a for a,b,R in E)
 ck('disjoint_receiver_intervals',all(E[i][1]<=E[i+1][0] for i in range(len(E)-1)))
 for a,b,R in E:
  points=sorted(set([a,b]+[z+s*R/2 for lo,hi,d in src for z in [lo,hi] for s in [-1,1] if a<z+s*R/2<b]))
  for u in points:ck('actual_full_source_q_one',mass(src,u-R/2,u+R/2)==R)
 points=sorted(set([F(-2),F(2)]+[z+s*R/2 for a,b,R in E for z in [a,b] for s in [-1,1]]+[z for a,b,d in src for z in [a,b]]));etas=[F(1,4),F(1,2),F(3,4),F(1)];records=[]
 for eta in etas:
  dl,dh=logbounds(1/(eta*F(3,4)));Dlo=1+dl;Dhi=1+dh;total=F(0);byM=Counter();segments=[];maximum=F(0);clipped={T:F(0) for T in [F(1,2),F(2),F(4)]};excess={T:F(0) for T in clipped}
  for a,b in zip(points,points[1:]):
   y=(a+b)/2;M=essential_M(E,y);fa=Xi(E,a,M,eta);fb=Xi(E,b,M,eta);mid=Xi(E,y,M,eta);J=sum(capture_length(e,y)/e[2] for e in E)
   ck('positive_measure_esssup_only',M==max([F(0)]+[e[2] for e in E if capture_length(e,y)>0]))
   ck('top_kernel_affine_with_frozen_M',mid==(fa+fb)/2)
   rs=sorted(set(e[2] for e in E));layered=F(0)
   for index,r in enumerate(rs):
    ell=1/r-(1/rs[index+1] if index+1<len(rs) else 0)
    volume=sum(capture_length(e,y) for e in E if e[2]<=r and M>0 and e[2]>=eta*M)
    layered+=ell*volume
   ck('physical_ell_tail_with_terminal_atom',layered==mid)
   ck('top_kernel_unchanged_original_bound',0<=mid<=J)
   ck('pointwise_source_window_budget',max(fa,fb)<=Dlo)
   if not M:ck('zero_capture_no_esssup_or_traffic',J==mid==0)
   density=next((d for lo,hi,d in src if lo<y<hi),F(0));integral=(b-a)*(fa+fb)/2;total+=density*integral;byM[str(M)]+=density*integral;maximum=max(maximum,fa,fb)
   for T in clipped:clipped[T]+=min(density,T)*integral;excess[T]+=max(F(0),density-T)*integral
   segments.append(dict(lo=str(a),hi=str(b),M_essential=str(M),Xi_left_limit=str(fa),Xi_right_limit=str(fb),source_density=str(density)))
  # Exact endpoints use their own essential M, not an arbitrary one-sided value.
  for y in points:
   M=essential_M(E,y);value=Xi(E,y,M,eta)
   ck('boundary_point_essential_gate_budget',value<=Dlo)
   ck('zero_receiver_atoms_ignored',M==essential_M([e for e in E if e[1]>e[0]],y))
  ck('full_source_window_integral',total<=Dlo*W)
  clips=[]
  for T,g in clipped.items():
   Wg=sum((b-a)*min(d,T) for a,b,d in src);Wr=sum((b-a)*max(F(0),d-T) for a,b,d in src)
   ck('clipped_and_excess_same_original_kernel',g+excess[T]==total and Wg+Wr==W)
   ck('clipped_window_source_budget',g<=Dlo*Wg and excess[T]<=Dlo*Wr)
   clips.append(dict(T=str(T),g_source_mass=str(Wg),excess_source_mass=str(Wr),g_Xi_integral=str(g),excess_Xi_integral=str(excess[T])))
  records.append(dict(eta=str(eta),D_lower=str(Dlo),D_upper=str(Dhi),D_decimal=float((Dlo+Dhi)/2),Xi_max=str(maximum),full_source_Xi_integral=str(total),full_source_Xi_integral_decimal=float(total),contribution_by_essential_M={k:str(v) for k,v in byM.items()},clipped_and_excess=clips,segments=segments))
 root_h=F(2)/(F(119,3072)*F(3,4));maxJ=max(sum(capture_length(e,y)/e[2] for e in E) for y in points);ck('original_n1_root_gate_empty',maxJ<root_h)
 return dict(stage=stage,source_mode=mode,source_intervals=[list(map(str,e)) for e in src],receiver_intervals=[list(map(str,e)) for e in E],W=str(W),Xq=str(X),actual_q='1',actual_m_equals_R=True,Jmax=str(maxJ),original_n1_root_h=str(root_h),original_root_gate_empty=True,rows=records,exact_checks=sum(C.values())-before,scope='Actual positive receiver dx and compact periodic packet source, original q/m/J frozen. Zero-length receiver atoms have no essential mass. New source-dependent top window only; not original highpast G.')

def future_model(stage,E,mode):
 before=sum(C.values());src=source(mode);W=mass(src,F(-2),F(2));base=sorted(set([F(-2),F(2)]+[z+sgn*R/2 for a,b,R in E for z in [a,b] for sgn in [-1,1]]+[z for a,b,d in src for z in [a,b]]));radii=sorted(set(e[2] for e in E));rows=[]
 def future(y,K,R):return sum(capture_length(e,y)/e[2] for e in E if e[2]>K*R)
 for K in [F(5,4),F(3,2)]:
  for threshold in [F(1,8),F(1,4),F(1,2)]:
   points=set(base)
   for a,b in zip(base,base[1:]):
    for R in radii:
     fa=future(a,K,R);fb=future(b,K,R)
     if (fa-threshold)*(fb-threshold)<0:points.add(a+(threshold-fa)*(b-a)/(fb-fa))
   points=sorted(points);dl,dh=logbounds(K);Dlo=threshold+1+dl;Dhi=threshold+1+dh;total=F(0);maximum=F(0);records=[];parts={T:[F(0),F(0)] for T in [F(1,2),F(2),F(4)]};equal_plateaus=0;changing_gates=0
   for a,b in zip(points,points[1:]):
    y=(a+b)/2;gates={R:future(y,K,R)<=threshold for R in radii};fa=sum(capture_length(e,a)/e[2] for e in E if gates[e[2]]);fb=sum(capture_length(e,b)/e[2] for e in E if gates[e[2]]);mid=sum(capture_length(e,y)/e[2] for e in E if gates[e[2]])
    ck('future_frozen_segment_affine',mid==(fa+fb)/2)
    ck('future_source_row_bound',max(fa,fb)<=Dlo)
    for R in radii:
     Fm=future(y,K,R)
     ck('future_uses_terminal_full_rho',Fm==sum(capture_length(e,y)/e[2] for e in E if e[2]>K*R))
     expected=sum(capture_length(e,y)/2 for e in E if e[2]==2) if R==1 else F(0)
     ck('two_mass_terminal_future_independent',Fm==expected)
     if Fm==threshold:equal_plateaus+=1;ck('future_equality_plateau_included',gates[R])
     if gates[R]!=(future(a,K,R)<=threshold) or gates[R]!=(future(b,K,R)<=threshold):changing_gates+=1
    # Freeze the low-future endpoint gate inside the original physical ell sum.
    layered=F(0)
    for index,r in enumerate(radii):
     ell=1/r-(1/radii[index+1] if index+1<len(radii) else 0);layered+=ell*sum(capture_length(e,y) for e in E if e[2]<=r and gates[e[2]])
    ck('future_full_clock_ell_terminal_exact',layered==mid)
    d=next((d for lo,hi,d in src if lo<y<hi),F(0));integral=(b-a)*(fa+fb)/2;total+=d*integral;maximum=max(maximum,fa,fb)
    for T in parts:parts[T][0]+=min(d,T)*integral;parts[T][1]+=max(F(0),d-T)*integral
    records.append(dict(lo=str(a),hi=str(b),future_by_mass={str(R):str(future(y,K,R)) for R in radii},lowfuture_by_mass={str(R):gates[R] for R in radii},Xi_left_limit=str(fa),Xi_right_limit=str(fb),source_density=str(d)))
   for y in points:
    val=sum(capture_length(e,y)/e[2] for e in E if future(y,K,e[2])<=threshold)
    ck('future_crossing_point_inclusive_budget',val<=Dlo)
   ck('future_full_source_integral_budget',total<=Dlo*W)
   clips=[]
   for T,(g,excess) in parts.items():
    Wg=sum((b-a)*min(d,T) for a,b,d in src);Wr=sum((b-a)*max(F(0),d-T) for a,b,d in src)
    ck('future_clip_excess_same_frozen_kernel',g+excess==total and Wg+Wr==W)
    ck('future_clip_excess_separate_budgets',g<=Dlo*Wg and excess<=Dlo*Wr)
    clips.append(dict(T=str(T),g_mass=str(Wg),excess_mass=str(Wr),g_kernel_integral=str(g),excess_kernel_integral=str(excess)))
   rows.append(dict(K_diagnostic=str(K),s=str(threshold),D_actual_q1_lower=str(Dlo),D_actual_q1_upper=str(Dhi),Xi_low_max=str(maximum),full_source_kernel_integral=str(total),equality_plateau_segments=equal_plateaus,gate_endpoint_changes=changing_gates,clip_and_excess=clips,segments=records))
 ck('strict_mass_future_boundary_K2',future(F(0),F(2),F(1))==0)
 return dict(stage=stage,exact_checks=sum(C.values())-before,rows=rows,scope='New terminal low-future gate; original full rho=capture du/m, actual q1 and all receiver field frozen. Diagnostic rational K, not root K. Physical ell terminal included; no original highpast G simulation.')

def root_parameters():
 before=sum(C.values());lo,hi=logbounds(F(4,3));rows=[]
 for n in [1,4,16,64,256,1024,4096]:
  k=isqrt(n);ck('root_square_n',k*k==n);Dlo=1+k+lo;Dhi=1+k+hi
  ck('root_D_coefficient',Dhi<=k+F(4,3))
  futureDlo=1+F(7,3)*k+lo;futureDhi=1+F(7,3)*k+hi
  ck('root_future_D_coefficient',futureDhi<=F(4,3)+F(7,3)*k)
  rows.append(dict(n=n,eta_symbolic='exp(-sqrt(n))',Droot_lower=str(Dlo),Droot_upper=str(Dhi),Droot_upper_decimal=float(Dhi),upper_sqrt_n_plus_4over3=str(k+F(4,3)),Dfuture_lower=str(futureDlo),Dfuture_upper=str(futureDhi)))
 eps=F(119,3072);six=6*eps;outer=F(128,119);CZ=F(65,256)
 ck('six_epsilon_actual_outer_arithmetic',outer*six==F(1,4))
 ck('given_CZ_coefficient_arithmetic',CZ==F(1,4)+F(1,256))
 return dict(exact_checks=sum(C.values())-before,rows=rows,epsilon=str(eps),six_epsilon=str(six),actual_outer_factor=str(outer),outer_times_six_epsilon='1/4',given_CZ_coefficient=str(CZ),scope='Arithmetic checkpoints only; no new six-payment ledger inferred by numerical tests.')

def main():
 models=[actual_model('initial',[(F(-1),F(-1),F(2)),(F(-1,2),F(0),F(1)),(F(1,4),F(1,2),F(2))],'uniform'),actual_model('stress',[(F(-3,4),F(-1,2),F(1)),(F(-1,4),F(0),F(2)),(F(1,4),F(1,2),F(1))],'single_packet'),actual_model('expanded',[(F(-1),F(-1,2),F(2)),(F(-1,2),F(1,2),F(1)),(F(1,2),F(1),F(2))],'two_level_packet')]
 future=[future_model(m['stage'],[tuple(map(F,e)) for e in m['receiver_intervals']],m['source_mode']) for m in models]
 parameters=root_parameters();out=dict(low_future_models=future,status='PASS',total_exact_checks=sum(C.values()),check_counts=dict(C),actual_models=models,root_parameter_checks=parameters,scope='Source-dependent essential top-mass and terminal low-future window tests only. True receiver intervals and full compact L1 sources, no global highpast/root certification. Exact rational source integration and outward log bounds; float displays diagnostic.')
 (BASE/'r345_numeric_result.json').write_text(json.dumps(out,sort_keys=True,indent=2)+'\n');print(json.dumps(dict(status='PASS',total_exact_checks=sum(C.values()),actual_model_checks=[m['exact_checks'] for m in models],parameter_checks=parameters['exact_checks'],low_future_checks=[m['exact_checks'] for m in future]),sort_keys=True))
if __name__=='__main__':main()
