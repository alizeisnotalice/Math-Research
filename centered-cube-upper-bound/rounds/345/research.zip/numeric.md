# R345 — source-dependent top-mass and terminal low-future windows

This tests source-dependent windows on true one-dimensional receiver Lebesgue intervals, including the new terminal low-future interface. It does not simulate original Gout or certify complete historical qualification. The original n1 root high-past gate is empty in all three fields.

## Frozen field and exact essential supremum

Use hard kernels s=0,L=R, with assigned sides 1 and 2, f on [-2,2], and actual q=lambda=1. The three sources are uniform, single packets per unit period (density4 on the first quarter, zero elsewhere), and two-level packets per period (densities3 and1 on the first and second quarters). Four periods are retained; each has mass1, so W=4. Every selected hard receiver interval stays inside source support, and the script checks the moving-response breakpoints to certify q=1 for every receiver, not by resetting q after a source change.

For fixed y, compute the positive-length capture of each receiver interval E_i:

`length_i(y)=|E_i intersect [y-R_i/2,y+R_i/2]|`.

Then `M(y)=max{R_i:length_i(y)>0}`, or 0 if there is no positive-measure capture. This is the essential supremum of the unchanged actual masses m_u=R_u. It excludes zero-length receiver atoms and isolated boundary contact. The top gate is inclusive `R_i>=eta M(y)`, with eta=1/4,1/2,3/4,1, and

`Xi(y)=sum_i length_i(y) 1{R_i>=eta M(y)}/R_i`.

This equals the physical layer integral: the prefix volume is constant on [1,2), whose continuous clock weight is integral_1^2 r^-2 dr=1/2, and the separate terminal atom is ell({2})=1/2. There is no clock atom at 1; the compressed computational layer weight represents that continuous interval. The code checks that equality on every source segment, so no b-end atom is omitted.

All receiver/source breakpoints are retained. On each open segment M is constant and Xi is affine; source densities are constant. Endpoint integration uses that segment's frozen M. At the breakpoints themselves, the code separately recomputes the actual essential M and checks the bound, rather than assigning an arbitrary one-sided essential supremum.

## Actual three-stage fields

| Stage | receiver intervals and assigned R | source |
|---|---|---|
|initial|[-1,-1],R2 (zero measure); [-1/2,0],R1; [1/4,1/2],R2|uniform|
|stress|[-3/4,-1/2],R1; [-1/4,0],R2; [1/4,1/2],R1|single periodic packets|
|expanded|[-1,-1/2],R2; [-1/2,1/2],R1; [1/2,1],R2|two-level periodic packets|

The zero-measure receiver in the initial fixture deliberately tests the essential-supremum guard. It never contributes to M,J,X,or Xi, even where its cube would meet the source. All other receiver intervals have positive volume. Disjointness, full-source q, zero-capture regions, and source boundaries are checked exactly.

For each eta, the source-row budget is `D=1+log(1/(eta qminus))`, qminus=3/4. An outward rational atanh-series enclosure gives D_lower<=D<=D_upper. The script verifies `Xi<=D_lower`, and therefore the true D bound, on affine endpoints and the actual boundary points. It integrates f Xi exactly and checks `integral f Xi<=D_lower W`. The same original Xi is retained for g=min(f,T) and excess (f-T)_+, T=1/2,2,4: their source integrals and masses add exactly to the original account, and each part satisfies its separate D times source-mass bound. Neither q nor J nor M is recomputed from g.

## Results

Two fresh independent Python runs passed **2,728 exact rational checks**: 275/368/383 for the retained top-mass models, 439/587/653 for the new terminal low-future models, and 23 parameter/arithmetic checks. Logarithms are enclosed by rational series; decimal displays are ordinary diagnostics, not inequality certificates.

| Stage | max original J | Xi max at eta=1/2 | integral f Xi at eta=1/2 | Xi max at eta=3/4 | integral f Xi at eta=3/4 |
|---|---:|---:|---:|---:|---:|
|initial|5/8|5/8|3/4|1/4|9/32|
|stress|3/8|3/8|3/4|1/8|1/4|
|expanded|3/2|3/2|2|1/2|1|

The eta=1/4 results equal eta=1/2 here; eta=1 results equal eta=3/4. The jump is genuine mass-window geometry: where M=2, an actual R1 receiver is included at eta=1/2 **by equality**, and excluded at eta=3/4. In the expanded actual field Xi reaches 3/2, so this is not merely a collection of kernels bounded by 1 before applying the source window. The computed source budgets are valid but not sharp: D is about 1.980829 at eta=1/2 and 1.575364 at eta=3/4.

For n=1,4,16,64,256,1024,4096, the symbolic eta_root=exp(-sqrt(n)) gives exactly

`Droot=1+sqrt(n)+log(4/3) <= sqrt(n)+4/3`.

The logarithmic bound is rationally enclosed and checked. No floating value of eta_root is substituted into a gate. The new low-future root coefficient is also checked as `Dfuture=1+log(4/3)+(7/3)sqrt(n) <= 4/3+(7/3)sqrt(n)`. The actual outer-factor checkpoint is `6*(119/3072)*(128/119)=1/4`, alongside the supplied CZ coefficient `65/256=1/4+1/256`. These are arithmetic checkpoints; no new payment ledger or inverse denominator is inferred from the numerics. The source-window coefficient is a source-mass price, not an extra epsilon-X charge.

The representative n1 original h=2/(epsilon qminus) exceeds J everywhere. Consequently these are tests of the new source-dependent window envelope, not evidence of nonempty original root traffic or a general root proof. In these examples all source integrals are exact positive-L1 integrations and all receivers use true dx; no source point samples or receiver quadrature replace them.

## New terminal low-future interface

The new module retains the **terminal full receiver measure** `rho_y(du)=c_u(y)du/m_u`, not a prefix truncated at an evaluation scale. Define `U_y(t)=rho_y{m_u>t}` with a strict mass tail. For K=5/4 or3/2 and s=1/8,1/4,1/2, it evaluates

`Xi_low(y)=sum_i length_i(y)/R_i * 1{U_y(K R_i)<=s}`.

With the two actual masses 1 and2, the mass1 endpoint has future `J2(y)=sum_{R_i=2}length_i(y)/2`; the mass2 endpoint has future0. The code checks this independent two-mass formula, and separately checks that at K=2 the strict future of mass1 is zero. The two diagnostic K values yield the same gate in these fixtures, but different budget coefficients; this limited mass menu does not test a continuum of K effects.

Every crossing J2=s is added as an exact rational breakpoint. Within a piece, the low-future gate is frozen before integrating the affine Xi_low. Equality plateaus are included (positive source measure), and crossing points are separately evaluated with their actual inclusive `U<=s` gate. Such null points are not arbitrarily assigned to a one-sided segment. The original full rho, q, masses and source densities are unchanged. Exact physical ell summation, including the b=2 terminal atom, again equals this full-clock kernel.

For the sharper actual q=lambda=1 contract the source budget coefficient is

`D_actual=s+1+log K`.

The script checks its outward-log lower bound dominates the kernel and its integral against full f, min(f,T), and (f-T)_+, T=1/2,2,4. The general root qminus=3/4 coefficient is looser and is recorded symbolically in the parameter section.

| Actual field | s | Xi_low max | integral f Xi_low |
|---|---:|---:|---:|
|initial|1/8,1/4,1/2|5/8|3/4|
|stress|1/8,1/4,1/2|3/8|3/4|
|expanded|1/8|1/2|1|
|expanded|1/4|3/4|19/16|
|expanded|1/2|3/2|2|

The expanded field gives nonconstant terminal future and genuine gate crossings. At s=1/4, six segment/mass entries per K are exact equality plateaus and remain included. At s=1/8 and1/4, two segment/mass entries per K change their inclusive classification at an endpoint, explicitly checked. These are new terminal-window interface tests, separate from the earlier Mmax top gate. They still do not certify original high-past traffic or the general source-row theorem by finite examples.

## Reproduce

Only the three owned files are required. The script uses the standard library and writes `r345_numeric_result.json` beside itself, with no old /tmp imports:

```sh
/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 /path/to/r345_numeric.py
```

The JSON contains every source/receiver interval, essential-M segment, top-kernel endpoint, terminal-future crossing segment, exact clipped/excess account, and parameter enclosure.
