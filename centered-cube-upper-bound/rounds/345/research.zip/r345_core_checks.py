"""R345: exact source-quantile boundary checks on real 2D rectangles and squares."""
from fractions import Fraction as F
from itertools import product
source=[((F(0),F(1,10)),(F(0),F(1)),F(50)),
        ((F(1,2),F(3,2)),(F(1,4),F(1,2)),F(4)),
        ((F(2),F(3)),(F(2),F(3)),F(3)),
        ((F(-1),F(-1,2)),(F(3),F(7,2)),F(8))]
def interval_overlap(a,b,c,d):
    lo=a if c is None else max(a,c)
    hi=b if d is None else min(b,d)
    return max(F(0),hi-lo)
def mass(rect):
    return sum(density*interval_overlap(x[0],x[1],rect[0][0],rect[0][1])
               *interval_overlap(y[0],y[1],rect[1][0],rect[1][1])
               for x,y,density in source)
W=mass(((None,None),(None,None)))
assert W==11

def quantiles(axis,N):
    endpoints=sorted({endpoint for block in source for endpoint in block[axis]})
    segments=[]; cumulative=F(0)
    for left,right in zip(endpoints,endpoints[1:]):
        middle=(left+right)/2
        density=sum(block[2]*(block[1-axis][1]-block[1-axis][0])
                    for block in source if block[axis][0]<middle<block[axis][1])
        segments.append((left,right,density,cumulative))
        cumulative+=density*(right-left)
    assert cumulative==W
    cuts=[]
    for k in range(1,N):
        target=k*W/N
        for left,right,density,cumulative in segments:
            if density and cumulative<=target<=cumulative+density*(right-left):
                cuts.append(left+(target-cumulative)/density)
                break
        else:
            raise AssertionError('quantile not found')
    assert all(x<y for x,y in zip(cuts,cuts[1:]))
    bounds=[None]+cuts+[None]
    return list(zip(bounds,bounds[1:]))

def contained(cell,cube):
    return all(lo is not None and hi is not None and cube[d][0]<=lo and hi<=cube[d][1]
               for d,(lo,hi) in enumerate(cell))

counts={"marginal_slabs":0,"cell_partition":0,"square_boundary":0,"posterior_ratio":0}
max_ratio=F(0)
centers=(F(-1,2),F(0),F(3,4),F(5,2),F(3))
sides=(F(1,10),F(1,2),F(1),F(2),F(4),F(8))
for N in (4,8,16):
    axes=[quantiles(d,N) for d in range(2)]
    for d in range(2):
        for interval in axes[d]:
            rect=[(None,None),(None,None)]; rect[d]=interval
            assert mass(rect)==W/N
            counts["marginal_slabs"]+=1
    cells=[tuple(cell) for cell in product(*axes)]
    weights=[mass(cell) for cell in cells]
    assert len(cells)==N*N and sum(weights)==W
    assert all(F(0)<=w<=W/N for w in weights)
    counts["cell_partition"]+=1
    cap=4*W/N
    for cx,cy in product(centers,repeat=2):
        for side in sides:
            cube=((cx-side/2,cx+side/2),(cy-side/2,cy+side/2))
            actual=mass(cube)
            inner=sum(w for cell,w in zip(cells,weights) if contained(cell,cube))
            loss=actual-inner
            assert 0<=loss<=min(actual,cap)
            counts["square_boundary"]+=1
            max_ratio=max(max_ratio,loss/cap)
            if actual:
                assert loss/actual<=min(F(1),cap/actual)
                counts["posterior_ratio"]+=1
print("PASS",counts,"total",sum(counts.values()))
print("source mass",W,"max exact loss/(2nW/N)",max_ratio)
print("One shared partition per N; all square masses are exact positive-volume integrals.")
print("No high-past traffic or free internal-cell payment is asserted.")
