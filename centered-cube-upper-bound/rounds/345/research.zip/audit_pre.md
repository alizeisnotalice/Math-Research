# R345 independent preliminary audit — interior source mass and variable-radius boundary capacity

Owned only `/tmp/r345_audit_pre.md`; no Git/other-author edits and no R345 author proof read. Scope is the full original hard contract of R344: actual finite receiver du, measurable a<=R_u<=b<=2a, same nonnegative compact/integrable source f, m_u=f(Q_u)=q_uR_u^n with q_-<=q_u<=lambda, unchanged source/receiver fields and full J. Fix a source point y and0<delta<1. No global closure is inferred.

## Interior inclusion: PASS

If ||u-y||_infty<=(1-delta)R_u/2, then for every z in the cube of SIDE delta a centered at y,

 ||z-u||_infty<=(1-delta)R_u/2+delta a/2<=R_u/2.

Therefore Q_(delta a)(y) subset Q_u, and the ORIGINAL source mass satisfies

 m_u>=M_y(delta a):=integral_{Q_(delta a)(y)}f.

This is actual common-f mass domination, without a density hypothesis or source/selector reset. It applies to the interior receivers only, not to every captured receiver or to the boundary portion below.

## Proposed boundary proportion times A_n: FAIL

Let t=2||u-y||_infty and define the actual boundary contribution at terminal scale

 J_boundary(y)=integral_E 1_{t<=R_u}1_{t>(1-delta)R_u}du/(q_uR_u^n).

For a contributing receiver, the available actual radii lie in[max(a,t),min(b,t/(1-delta))) with the appropriate capture endpoint. Thus t>(1-delta)a and t<=b, and its density is at most

 1/[q_-max(a,t)^n].

The sublevel set{u:2||u-y||_infty<=t} has volume t^n. Integrating the ACTUAL receiver-center upper envelope gives the correct universal estimate

 J_boundary(y)<= [1-(1-delta)^n+nlog(b/a)]/q_-.          (1)

The proposed [1-(1-delta)^n][1+nlog(b/a)]/q_- is smaller by (1-delta)^n*nlog(b/a)/q_- and is not generally valid when b>a. The logarithmic scale segment is NOT multiplied by a small boundary proportion. Different radii can align different center shells with their actual cube boundaries. For fixed y the envelope in(1) is sharp over allowed selectors: choose R=a on (1-delta)a<t<a and R=t on a<=t<=b, with constant full source density q_- on a large enough compact cube. Every selected cube remains in that source, so actual q=q_-; this is not merely an abstract unrestricted selector example.

At a physical prefix r in[a,b], the identical result holds with b replaced by r. Inclusive capture and strict boundary conventions only affect the natural endpoints, not these Lebesgue center integrals. When b=a the logarithmic part vanishes and the ordinary fixed-radius proportion is recovered.

## Same full-f/q-band positive-source demonstration

A short one-dimensional example also avoids reliance on an exceptional source point. Let a1,b2,q_-1,lambda4/3, f=1_[0,2], E=[1/2,1], and R_u=2u. Then every actual hard cube is[0,2u], m_u=2u and q_u=1 on the ENTIRE positive-volume E; all source/capture data come from that single finite-L1 f. For every y in(0,delta/2), every receiver captures y and satisfies the strict boundary condition u-y>(1-delta)u. Consequently

 J_boundary(y)=integral_(1/2)^1 du/(2u)=(log2)/2.

With delta1/16, the proposed upper coefficient is(1+log2)/16, strictly below(log2)/2 on the positive source-measure interval(0,1/32). Thus the actual full-f/q-band contract does not restore the proposed proportion. This diagnostic is not claimed to satisfy the entire historical hard lower-band/low-pe/high-past qualification or to obstruct the final weak-type theorem; it settles only the advertised universal boundary capacity interface.

Reviewer computed an outward exact rational atanh-series enclosure for log2: the actual boundary lower bound exceeds0.3465735897 while the proposed upper bound is below0.1058216988. These decimals display a strict RATIONAL enclosure comparison, not floating-point evidence. No large counterexample search was performed.

## A valid common-source local-mass interface

Let s=(1-delta)^n and M=M_y(delta a). Split the original J_y(r) EXACTLY into its interior and boundary receiver portions, using the same original denominator, not a normalized subfield. On the interior, both actual constraints hold:

 m_u>=M,  m_u>=q_-R_u^n,
 2||u-y||_infty<=(1-delta)R_u.

The resulting real-center bound is

 J_interior(y,r)<=s H_r(M),
 H_r(M)=integral_0^(r^n) dz/max(M,q_-a^n,q_-z).

This integral has the explicit form

 H_r(M)=[1+nlog(r/a)]/q_-                    if M<=q_-a^n,
 H_r(M)=[1+log(q_-r^n/M)]/q_-                if q_-a^n<M<q_-r^n,
 H_r(M)=r^n/M                               if M>=q_-r^n.

It is continuous at the case boundaries; M0 is covered by the first case. This uses the SAME real source mass M, and does not infer mass from a shell-volume ratio. The boundary term is still only bounded by B_delta,r=[1-s+nlog(r/a)]/q_-. Thus J<=sH_r(M)+B_delta,r is a legal (possibly loose) common-source interface.

One can state a somewhat sharper total envelope by noticing that EVERY captured center with t<= (1-delta)a is interior, while outside that central region the ordinary boundary-capable envelope dominates either possibility. It gives

 J_y(r)<=B_delta,r+s*a^n/max(M,q_-a^n).              (2)

For the latter centers it is only an upper envelope; it does not assert that all choices can simultaneously be realized with a prescribed large M. Formula(2) retains an honest common-f improvement in the central region, while displaying why an unpriced nlog(r/a) contribution persists.

On an original high-past row J_y(r)>h, the first split implies sH_r(M)>h-B_delta,r whenever h>B_delta,r. If h<=B_delta,r, this particular argument provides NO local-source-mass restriction. The boundary term can dominate the original root-sized h on general octave scales, so no root payment follows just by rearranging this inequality. The actual source-weighted boundary occupation, or a separately proved constraint on how the SAME f can be partially captured there, is the remaining relevant parameter. All original physical ell/source gates should remain outside this fixed-row interface; no source-density bound or free choice of delta by private receiver/source point is supplied.

For a fixed field, boundary occupation may of course tend to0 for source-a.e. y as delta decreases (Tonelli/DCT rules out actual cube-face mass for almost every source point). This does not imply a uniform small-delta rate over all allowed fields: the positive-source example above already defeats the proposed quantitative rate. This screen does not rule out a correctly weighted geometric/flow argument.

## Actual tool evidence and stopping point

Reviewer ran1441 exact Fraction pointwise/enclosure assertions for boundary density feasibility, the central common-M envelope, the interior triangle inclusion and the positive-source log2 comparison. All passed. Except for the explicit1D actual f/q field described above, these are local scalar envelope mechanics, not complete original traffic or high-past simulations. No full source/receiver pipeline or broad adversarial search was run.

Preliminary disposition: interior mass inclusion PASS; proposed proportional boundary capacity FAIL; corrected variable-radius center envelope(1) and the stated common-f interior/total interfaces are valid. This audit stops at the requested bounded interface, awaiting any later author proof. No general root closure or new ledger payment is certified. Only this owned file was written.
