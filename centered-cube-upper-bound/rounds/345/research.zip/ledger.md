# 第345轮完整替换总账

一般根阶上界未闭合。原入口、历史外乘及其他分支依赖按既有合同承接，本轮不声称重新认证全部历史归约。W=∫f=W_beta，ν≤f dx，W_nu=ν(Rⁿ)，Xq=∫E q_u du≤X=λ|E|，A_n=1+nlog(b/a)。
\[
T_{\rm entrance}\le8\lambda HW+2d_{\rm eff}A_nW_\nu/H+2B_H.
\]

保持ε=119/3072及原K、h、α。第338轮原槽为
\[
B_H\le G_{\rm out}[f]+2\varepsilon X_q+C_{\varepsilon,n}W,
\quad C_{\varepsilon,n}=\frac\lambda{q_-}[(2+3\sqrt n+2e^{-\sqrt n})/\varepsilon+1+\sqrt n].
\]

按完整f冻结场先分外层来源，再分低/高未来捕获门。W_ex=∫(f−T_clip)_+≤W，D_n=1+log(4/3)+(7/3)√n。本轮替换槽为
\[
B_H\le G_{\rm bi}[g_{\rm ex}]+3\varepsilon X_q+C_{\varepsilon,n}W+D_nW_{\rm ex}.
\]
其中G_bi保留原highpast、far、outside、H、真实du和ell，另加终端U_y(Km_u)>√n/q_-；来源因子为g_ex，m/q/J/U等始终按完整f计算。不得把g_ex当新输入重新套合同。

第342轮的C_cover,n W不再重复计费；第344轮同槽由上式替换。新的来源费D_nW_ex≤D_nW，系数小于旧C_cover,n，但主要改进是剩余域必须具有双侧真实捕获容量。

原入口变为
\[
T_{\rm entrance}\le8\lambda HW+2d_{\rm eff}A_nW_\nu/H+2G_{\rm bi}[g_{\rm ex}]
+6\varepsilon X_q+2C_{\varepsilon,n}W+2D_nW_{\rm ex}.
\]
历史Λ=128/119给6Λε=1/4。若CZ费用1/256属于已经认证的同一X外账，总吸收仍65/256，剩余191/256未分配；这不能支付其他未处理分支。相较344未新增接收费用。

完整未付清单：

1. G_bi的两侧真实捕获与高密度共同来源联合交通；高质量见证可能在当前物理前缀外，未证明其跨尺度付款。
2. 一般软密集C_H−S_H、越阈I_H、hard合同之外的质量可比重尾交通及其他尚未嵌入hard项。
3. 宽距离、低pe、极端尺度比及阈值全部补集，保留高度折扣和逆尺度比费用。
4. 历史初始I_time、删除跳跃J_time、未来被删来源D_time独立预算。物理终端b原子已被保留，不替代这些历史时间原子。
5. 后缀P/Phi_next负信用仅计一次；原H、层、物理尺度、来源、外积分、各极限均未自动结清。

辅助源分位网格没有进入主证明，不加δ费，也不记作内部交通付款。若将来采用它，必须另列外乘后的δXq及Nⁿ格复杂度。不存在“只剩常数和对数优化”的结论。
