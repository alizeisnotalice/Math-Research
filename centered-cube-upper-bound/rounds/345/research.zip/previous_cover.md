# R342 — Paying all source cells reduces localization from n to √n

## General statement

Use the exact original G_out, full source f, actual receiver measure du, masses m_u=q_uR_uⁿ, q_-≤q_u≤λ with q_-=3λ/4, physical radii a≤R_u≤b≤2a, original full J_y(r), high global past, strict far-mass and outer-center gates, and ell=b^{-n}δ_b+n r^{-n-1}dr from `/tmp/r340_core.md` and the R341 proof. No original parameter or denominator is changed. Let W=∫f>0 and X_q(A)=∫_Aq_u du.

Fix any grid side L>0 and any 0<η≤1, 0<β<1. Define

    M_L^+(u)=∫_{Q_{2L+b}(u)} f,
    A_L={u∈E:m_u≥ηM_L^+(u)}.                         (1)

Then the full original traffic on these large endpoints satisfies

    G_out(A_L) ≤ β(1+b/L)ⁿ X_q(A_L)
                   +[1+log(λ/(ηβq_-))]W.             (2)

In fact the same right side bounds the full first moment:

    X_q(A_L) ≤ β(1+b/L)ⁿ X_q(A_L)
                  +[1+log(λ/(ηβq_-))]W.              (3)

The receiver term can be sharpened to β∫_{A_L}q_u(1+R_u/L)ⁿdu. Thus this is a local source-growth covering theorem, and the G_out payment is a consequence of G_out(A_L)≤X_q(A_L). The stronger statement does not require high past, mass-gap, or outer-center gates.

For a desired receiver coefficient 0<δ<1, the exact choice

    β=δ(1+b/L)^{-n}

therefore gives the stronger covering inequality

    (1-δ)X_q(A_L)
      ≤[1+log(λ/(ηδq_-))+n log(1+b/L)]W.              (4)

Unlike R341, (2) does not require each receiver to select only one source cell. A single common source partition splits the actual source integral into disjoint pieces. The resulting repeated appearance of a receiver across cells is paid by the explicit average number of cells intersecting its cube; the source mass itself is charged only once.

## Uniform root-order specialization

For every n≥1 set

    L=(√n/2)b,       η=e^{-√n},       β=δe^{-2√n}.

Then

    β(1+b/L)ⁿ=δe^{-2√n}(1+2/√n)ⁿ≤δ,

by log(1+x)≤x. The neighborhood in (1) now has side

    2L+b=(1+√n)b.

Consequently

    (1-δ)X_q(A_L)≤[1+3√n+log(4/(3δ))]W.

In particular, choose δ=1/2. The original traffic then satisfies the source-only payment

    G_out≤G_smallbad+2[1+3√n+log(8/3)]W,              (5)

where G_smallbad is exactly the original positive G_out with the additional large-endpoint gate

    m_u<e^{-√n}∫_{Q_{(1+√n)b}(u)} f.                 (6)

Since (1+√n)b≤2nb for n≥1, this genuinely shrinks R341's source-growth neighborhood. In particular the previous localbad traffic is now paid on the exact subdomain

    e^{-√n}f(Q_{(1+√n)b}(u))≤m_u
                      <e^{-√n}f(Q_{2nb}(u)).         (7)

The remaining branch (6) is still unpaid. The result is a root-order payment on a larger set of original endpoints, not a proof of the full general target.

## One common grid and the complete original source split

Let t be uniform on [0,L)ⁿ and use the global source cells

    S_j^t=t+Lj+[0,L)ⁿ,       j∈Zⁿ,
    W_j^t=∫_{S_j^t}f,       Σ_jW_j^t=W.              (8)

All cells use the same shift. No source partition is chosen privately for a receiver, a pair, a physical radius, or a source point.

For fixed t, partition the original G_out(A_L) by the actual source y∈S_j^t, and then by the two complementary conditions

    good cell for u: W_j^t≥βm_u,
    small cell for u: W_j^t<βm_u.                    (9)

Call the resulting nonnegative totals G_good(t) and G_small(t). For every shift there is the exact identity

    G_out(A_L)=G_good(t)+G_small(t).                  (10)

Every term retains the original common source y, original small receivers v, full J, ell, and all mass, past, and geometric gates. Only positive upper bounds below discard gates. A receiver can appear in several source-cell terms, but each source y appears in exactly one; there is no duplicate source charge in (10).

If Q_u meets S_j^t, then every z in that cell has

    ||z-u||∞≤L+R_u/2≤L+b/2,

up to irrelevant cell faces. Therefore

    S_j^t⊂Q_{2L+b}(u),
    W_j^t≤M_L^+(u)≤m_u/η       for u∈A_L.           (11)

For a source-cell contribution that is nonzero, the intersection condition is automatic because y belongs to both Q_u and S_j^t. Thus no third mass branch is omitted in (9).

## Good source cells: one source budget for every cell

On the good-cell contribution with source y∈S_j^t, equations (9),(11) imply the original mass window

    ηW_j^t≤m_u≤W_j^t/β.                              (12)

For this fixed cell, apply the proved R339 source-weighted mass-window estimate to f1_{S_j^t} and the large-endpoint subset satisfying (12). The endpoint masses remain their full-f masses. No source isolation or lower posterior capture in S_j^t is assumed. In particular the large-endpoint subsets for distinct j need not be disjoint; the *source* restrictions are disjoint, which is exactly what allows summation of this estimate.

For completeness, after the original small-endpoint row divided by J is bounded by m_u, the real large-center volume at source y has radii confined to

    A_j=max(a,(ηW_j^t/λ)^(1/n)),
    B_j=min(b,(W_j^t/(βq_-))^(1/n)).

An empty interval contributes zero. Otherwise its physical integration is at most

    n log(B_j/A_j)+B_jⁿell([B_j,b])
      =1+n log(B_j/A_j)
      ≤1+log(λ/(ηβq_-)).                             (13)

This uses only actual receiver-center volume ≤rⁿ and the original inclusive tail. The tail contributes exactly 1, including the original b atom; no new atom is inserted at B_j. There is no density bound on f. The coefficient λ/q_- appears only inside the logarithm.

Multiplying (13) by W_j^t and summing (8) proves, for every t,

    G_good(t)≤[1+log(λ/(ηβq_-))]W.                   (14)

Zero-mass source cells contribute zero and need no mass-window argument.

## Small source cells: retain the original row and count actual intersections

Let N_t(u) be the number of source-grid cells meeting the interior of Q_u. This number is finite for every u. Grid-face coincidences are irrelevant for f integration; the cell-count expectation below also ignores only null sets of shifts.

On the original mass-gap domain, the gated small-endpoint row satisfies

    (1/J_y(r)) ∫_{E_r} c_v(y)(m_u-m_v)
                         [all original v gates]dμ(v)
      ≤m_u,

with zero-J rows set to zero. This bound uses the same full J, not a denominator confined to a source cell.

Apply it to G_small(t), then use the full original tail ell([R_u,b])=R_u^{-n}. This gives

    G_small(t)
      ≤∫_{A_L}du R_u^{-n}
          Σ_{j:W_j^t<βm_u}∫_{Q_u∩S_j^t}f
      ≤∫_{A_L}du R_u^{-n} βm_u N_t(u)
      =β∫_{A_L}q_u N_t(u)du.                        (15)

The second line is a source-mass inequality: each counted cell has its *entire actual source mass* W_j^t<βm_u. It does not infer small source mass from a boundary volume. Counting cells with no source only makes the upper bound larger. No assumption that a cell contains u is used.

The use of multiple source cells is therefore fully paid by N_t(u); it is not an uncharged union of receiver labels.

## Exact common-shift occupancy and completion

In one dimension an interval of length R intersects, on average over a common grid shift of period L, exactly

    1+R/L

grid intervals. One way to see this is to count the leftmost cell plus the grid boundaries in the interval: the expected number of boundaries is R/L. This formula holds for R≥L as well as R<L.

For Q_u with side R_u, the number of n-dimensional intersecting cells is the product of its coordinate interval counts. The shift coordinates are independent, so

    E_tN_t(u)=(1+R_u/L)ⁿ≤(1+b/L)ⁿ.                  (16)

Average the exact identity (10), use the uniform good-cell receipt (14), and apply Tonelli to (15),(16). This first proves (2), with the sharper receiver fee stated after (3). Every original traffic gate remains in (10); neither the high-past gate nor the pair overlap supplies an additional saving here.

To prove the stronger first-moment statement (3), run the same source-cell split on the nonnegative measure

    dΞ_A(r,y,u)=ell(dr) f(y)1_{Q_u}(y)1_{u∈A_L∩E_r}dy du.

Its total mass is exactly

    ∫_{A_L}m_u ell([R_u,b])du=X_q(A_L).

For good source cells, the same actual receiver volume and radius-window calculation (12)–(14) applies directly to Ξ_A. For small source cells, its inclusive tail gives directly the first line of (15), now for the corresponding part of Ξ_A; the source-mass and occupancy estimates are identical. Hence

    X_q(A_L)≤[1+log(λ/(ηβq_-))]W
                   +β∫_{A_L}q_u(1+R_u/L)ⁿdu.

This proves (3) and (4). Thus the strongest result is a root-order local source-growth covering estimate for actual receiver centers. It pays original traffic because G_out(A_L)≤X_q(A_L), not because high-past traffic has now been globally controlled.

All required quantities are measurable: cell indices use coordinate floors; (u,y)↦1_{Q_u}(y) is measurable for the given radius selector; cell masses, source-cell pieces, and occupancy counts are measurable by integration and finite coordinate counts. Countability of the global partition and nonnegativity justify the integral interchanges. Each fixed shift has Lebesgue-null and f-null grid faces. Also G_out(A_L)≤X_q(A_L)<∞ by the existing row bound, so all averaged traffic totals are legitimate.

## Full hard-slot replacement and remaining work

Keep the original R338 choices K=e^{√n}, h=(1+√n)/(εq_-), α=(1+√n)^(1/n), and original coefficient

    C_{ε,n}=(λ/q_-)[(2+3√n+2e^{-√n})/ε+1+√n].

Use the covering theorem with δ=1/2, independently of the original ε. It pays all good endpoints with no receiver absorption fee:

    G_out(A_L)≤X_q(A_L)≤2[1+3√n+log(8/3)]W.

Use this directly in the complete R338 slot. The replacement is

    B_H(f,ν)≤G_smallbad+2εX_q
          +{C_{ε,n}+2[1+3√n+log(8/3)]}W.             (17)

It replaces the R341 and earlier localization fees rather than adding them again. The supplied ledger entrance becomes

    T_*≤8λHW_β+2d_eff A_nW_ν/H+2G_smallbad+4εX_q
          +2{C_{ε,n}+2[1+3√n+log(8/3)]}W_β.          (18)

Thus its receiver coefficient is now 4ε. The original ε=119/3072 and supplied external multiplier Λ=128/119 give 4Λε=1/6. If the supplied historical CZ fee 1/256 belongs to this same certified X ledger, the combined amount is 131/768, with 637/768 not allocated. These arithmetic statements do not certify other historical reductions or pay any omitted slot.

The original shared-source pair and high-past structure are preserved in the residual but not needed for the new covering theorem. The genuinely unproved target is now a bound on (6), at source neighborhood side (1+√n)b. General formula (4) exposes the present method's limitation: for L comparable to b, the source-cell occupancy penalty n log(1+b/L) is of order n. Further progress at that scale requires a saving in the actual original small-cell traffic beyond the worst-case cell count (15), for example from the shared pair overlap and full-J redundancy. No such saving is asserted here. This is a proved local-growth covering theorem and a smaller original residual, not a proof that high-past traffic or the general weak-type target has been settled.

## Actually run exact checks

`/tmp/r342_geometry_checks.py` was run with Python Fraction arithmetic and passed 686 exact assertions:

- 36 one-dimensional common-shift occupancy integrals, evaluated over the entire shift period split at all interval-endpoint jumps, including R>L;
- 8 tensor-product occupancy identities;
- 480 exact receiver-fee tuning checks with rational L and β=δ(1+b/L)^{-n}, including δ=119/3072;
- 160 finite source-mass split and small-cell inequalities;
- 2 exact updated-ledger arithmetic checks.

The last group checks scalar source-mass algebra, not a simulated original traffic field. None of these finite checks proves a general bound on G_smallbad; the analytic proof of (2) is above. Reproduce with `python3 /tmp/r342_geometry_checks.py`.
