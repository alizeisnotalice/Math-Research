"""Exact finite diagnostics for R345; not a proof of the traffic theorem."""
from fractions import Fraction as F
from itertools import product

count = 0

def check(value):
    global count
    assert value
    count += 1

# Atomic scalar terminal measures: strict tails, quantile atoms, and both gates.
# These are algebra tests, not replacement receiver fields.
for masses in [(F(1),F(2)),(F(1),F(3,2),F(3)),(F(1),F(1),F(4))]:
    for weights in product((F(1,4),F(1),F(3,2)), repeat=len(masses)):
        total = sum(weights)
        U = lambda t: sum((w for m,w in zip(masses,weights) if m > t), F(0))
        for s in (F(0),F(1,4),total/2,total,total+1):
            tau = min(t for t in sorted(set(masses)) if U(t) <= s)
            check(U(tau) <= s)
            check(sum((w for m,w in zip(masses,weights) if m > tau),F(0)) <= s)
            for K in (F(3,2),F(2),F(3)):
                for m in masses:
                    if U(K*m) <= s:
                        check(K*m >= tau)
                        check(m > tau or tau/K <= m <= tau)

# Actual 1-D receiver geometry: f=1 on [-4,4], small centers [-1,0],R=1;
# large centers [0,1],R=2. Both q=1. The boundary centers have zero du.
def overlap(y, left, right, radius):
    return max(F(0),min(right,y+radius/2)-max(left,y-radius/2))

def lsmall(y): return overlap(y,F(-1),F(0),F(1))
def llarge(y): return overlap(y,F(0),F(1),F(2))

# Integral of the affine small capture length on the listed full breakpoints.
def integrate_small(points):
    return sum(((r-l)*(lsmall(l)+lsmall(r))/2 for l,r in zip(points,points[1:])),F(0))

check(integrate_small([F(-3,2),F(-1,2),F(1,2)]) == 1)
# K=3/2, s=1/4. Small endpoints are accepted iff llarge/2<=1/4.
for y in (F(-5,4),F(-3,4),F(-1,2),F(-1,4),F(1,4)):
    check((llarge(y)/2 <= F(1,4)) == (y <= F(-1,2)))
small_paid = integrate_small([F(-3,2),F(-1,2)])
check(small_paid == F(1,2))
check(1 + small_paid == F(3,2))
check(2-(1+small_paid) == F(1,2))
# Zero-future version pays small endpoints only on y<=-1.
small_top = integrate_small([F(-3,2),F(-1)])
check(small_top == F(1,8))
check(1+small_top == F(9,8))

# Inclusive physical clock tail: B^n ell([B,b])=1, including b's atom.
for n in range(1,17):
    for B in (F(1),F(5,4),F(3,2),F(2)):
        b = F(2)
        check(B**n*(b**(-n)+B**(-n)-b**(-n)) == 1)

# Exact receiver ledger. No unknown maximal norm is assigned a number.
eps=F(119,3072); outer=F(128,119)
check(6*outer*eps == F(1,4))
check(F(1,4)+F(1,256) == F(65,256))
check(1-F(65,256) == F(191,256))
print(f'PASS: {count} exact Fraction assertions. Atomic scalar diagnostics and an actual 1-D first-moment fixture; not a hard-traffic simulation.')
