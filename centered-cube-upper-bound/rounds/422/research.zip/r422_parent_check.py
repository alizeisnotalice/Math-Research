from fractions import Fraction as F
from random import Random
r=Random(422)
counts={}
for stage,ns in [('initial',range(2,8)),('signed_stress',range(8,20)),('expanded',range(20,44))]:
    count=0
    for N in ns:
        # Nested interval source sets with masses 16^-j, true L2(f) Gram 4^-|i-j|.
        # This is an exact Hilbert model, not native history or a fixed native side band.
        rho=F(1,4)
        a=[F(r.randrange(-100,101),r.randrange(1,15)) for _ in range(N)]
        g=[[rho**abs(i-j) for j in range(N)] for i in range(N)]
        norm=sum((a[i]*a[j]*g[i][j] for i in range(N) for j in range(N)),F())
        diag=sum((x*x for x in a),F())
        lower=1-2*rho/(1-rho); upper=(1+rho)/(1-rho)
        assert lower*diag <= norm <= upper*diag
        # Duplicate chains: no lower bound for their union; upper bound 2*upper.
        b=[F(r.randrange(-30,31),r.randrange(1,9)) for _ in range(N)]
        c=[a[i]+b[i] for i in range(N)]
        joint=sum((c[i]*c[j]*g[i][j] for i in range(N) for j in range(N)),F())
        assert joint<=2*upper*(diag+sum(x*x for x in b))
        # Direct-integral probability mixtures preserve the estimate only with their weight.
        weights=[F(1,3),F(2,3)]
        assert sum(weights)*norm<=upper*diag
        count+=1
    counts[stage]=count
print('PASS',counts,'total',sum(counts.values()))
print('Exact rational Hilbert/Gram checks; no native history, flow mixture budget, or global weak-type certification.')
