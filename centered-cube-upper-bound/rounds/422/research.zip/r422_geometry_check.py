from fractions import Fraction as F
# One finite full-source arithmetic check. It tests the source-allocation identity,
# not Lebesgue receiver capacity or any original history gate.
f=[F(3,7),F(5,7),F(2,7),F(11,7)]
c=[[1,1,0,0],[0,1,1,0],[0,0,1,1],[1,0,0,1]]
edges=[(0,2,F(2,9)),(1,3,F(4,9)),(0,1,F(1,9))]
m=[sum(fi*ci for fi,ci in zip(f,row)) for row in c]
column=[F(0) for _ in f]
total=F(0)
for w,t,gamma in edges:
    iw=sum(f[x]*c[w][x]*(1-c[t][x]) for x in range(len(f)))
    it=sum(f[x]*c[t][x]*(1-c[w][x]) for x in range(len(f)))
    assert iw>0 and it>0
    for x in range(len(f)):
        column[x]+=gamma*(F(c[w][x]*(1-c[t][x]),1)/iw+F(c[t][x]*(1-c[w][x]),1)/it)/2
    total+=gamma
assert sum(f[x]*column[x] for x in range(len(f)))==total
assert total==F(7,9)
print('PASS: one exact finite exclusive-source allocation identity; mass =',total)
print('No native center estimate, marked-flow domination, or new payment is asserted.')
# Actual source-retaining finite mass-chain kernels: all rho are exact atoms.
# These are kernel tests, not native Lebesgue/history samples.
from random import Random
rng=Random(422)
chain_cases=0
for length in [5,8,12]:
 for trial in range(12):
  masses=[F(2)**j for j in range(length)]
  rho=[F(rng.randint(1,7),4) for j in range(length)]
  K=F(3);h=F(1)
  Z=[sum(rho[j] for j in range(length) if masses[j]<masses[i]/K) for i in range(length)]
  for lo in masses:
   hi=2*lo
   stop=[Z[i]<=h or masses[i]<=hi for i in range(length)]
   H=[]
   for i in range(length):
    if stop[i]:
     row=[F(int(i==j)) for j in range(length)]
    else:
     row=[sum(rho[k]*H[k][j]/Z[i] for k in range(i) if masses[k]<masses[i]/K) for j in range(length)]
     assert sum(row)==1
    H.append(row)
   for i in range(length):
    if not stop[i]:
     for j in range(length):
      assert H[i][j]<=rho[j]/h
      if lo<=masses[j]<=hi:
       lower=sum(rho[k] for k in range(length) if masses[k]<lo)
       assert H[i][j]<=rho[j]/max(h,lower)
   # Initial density exactly rho gives the largest source-column model used.
   for j in range(length):
    if lo<=masses[j]<=hi:
     entry=sum(rho[i]*H[i][j] for i in range(length) if masses[i]>hi and Z[i]>h)+rho[j]
     Jhi=sum(rho[i] for i in range(length) if masses[i]>hi)
     lower=sum(rho[k] for k in range(length) if masses[k]<lo)
     assert entry<=rho[j]*(1+Jhi/max(h,lower))
   chain_cases+=1
print('PASS: source-retaining first-band kernels',chain_cases)
# Exact Gram domination for real subsets of a finite full-source space.
frame_cases=0
for depth in [2,3,4]:
 for trial in range(8):
  universe=list(range(4**depth))
  sets=[set(rng.sample(universe,4**j)) for j in range(depth+1)]
  gram=[[F(len(sets[i]&sets[j]),2**(i+j)) for j in range(depth+1)] for i in range(depth+1)]
  for i in range(depth+1):
   assert sum(gram[i])<=3
   for j in range(depth+1): assert gram[i][j]<=F(1,2**abs(i-j))
  g=[F(rng.randint(-3,3)) for _ in universe]
  lhs=sum((sum(g[x] for x in sets[j])/2**j)**2 for j in range(depth+1))
  assert lhs<=3*sum(x*x for x in g)
  frame_cases+=1
print('PASS: mass-gap frame models',frame_cases)
