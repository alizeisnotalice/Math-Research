from fractions import Fraction as F
from itertools import product
from math import isqrt
from pathlib import Path
import json

def box(c,s):return tuple((x-s/2,x+s/2) for x in c)
def vol(B):
    v=F(1)
    for a,b in B:v*=b-a
    return v
def inc(C,B,R):
    yes=all(l>=v-R/2 and r<=u+R/2 for (l,r),(u,v) in zip(C,B))
    no=any(r<=u-R/2 or l>=v+R/2 for (l,r),(u,v) in zip(C,B))
    assert yes or no
    return int(yes)
def split(B):
    a,b=B[0];m=(a+b)/2
    return [((a,m),)+B[1:],((m,b),)+B[1:]]
def model(n,rootmass,shared,pattern,amplitude):
    mw=rootmass**2;mt=F(1);M=F(2**n)
    k=isqrt(n)+(isqrt(n)**2<n)
    assert M>3**k*max(mw,mt)
    l=F(1,16)
    left=box((F(-3,10),)+(F(0),)*(n-1),l)
    right=box((F(3,10),)+(F(0),)*(n-1),l)
    B=split(left)+split(right);V=[vol(x) for x in B]
    mass=[mw,mw,mt,mt];roots=[rootmass,rootmass,F(1),F(1)]
    common=shared*mw
    src=[(box((F(0),)*n,F(1,16)),common),
      (box((F(-5,8),)+(F(0),)*(n-1),F(1,16)),mw-common),
      (box((F(5,8),)+(F(0),)*(n-1),F(1,16)),mt-common),
      (box((F(7,8),)*n,F(1,16)),M-mw-mt+common)]
    src=[(C,m) for C,m in src if m]
    for i in range(4):assert sum(m*inc(C,B[i],F(1)) for C,m in src)==mass[i]
    parent=box((F(0),)*n,F(1,32))
    assert sum(m*inc(C,parent,F(2)) for C,m in src)==M
    # An actual edge density on continuous blocks; not a historical Theta realization.
    raw=[[F(0) for j in range(4)] for i in range(4)]
    for i in range(2):
      for j in range(2,4):
        raw[i][j]=F(1) if pattern==0 else (F(int(i==j-2)) if pattern==1 else F(i+j,5))
    maxdeg=max([sum(raw[i][j]*V[j] for j in range(4))/mass[i] for i in range(4)]+[sum(raw[i][j]*V[i] for i in range(4))/mass[j] for j in range(4)])
    scale=amplitude/maxdeg
    e=[[raw[i][j]*scale*V[i]*V[j] for j in range(4)] for i in range(4)]
    out=[sum(e[i]) for i in range(4)];incoming=[sum(e[i][j] for i in range(4)) for j in range(4)]
    assert all(out[i]<=mass[i]*V[i] and incoming[i]<=mass[i]*V[i] for i in range(4))
    total=sum(out);energy=overlap=trace=F(0);pointwise=0
    for C,m in src:
        capture=[inc(C,B[i],F(1)) for i in range(4)]
        E=sum(e[i][j]*(F(capture[i])/roots[i]-F(capture[j])/roots[j])**2 for i in range(4) for j in range(4))
        D=sum((out[i]+incoming[i])*capture[i]/mass[i] for i in range(4))
        O=sum(e[i][j]*capture[i]*capture[j]/(roots[i]*roots[j]) for i in range(4) for j in range(4))
        J=sum(V[i]*capture[i]/mass[i] for i in range(4))+vol(parent)*inc(C,parent,F(2))/M
        assert E==D-2*O and 0<=E<=D<=2*J
        energy+=m*E;overlap+=m*O;trace+=m*D;pointwise+=1
    theta=F(1,8);before_soft=F(0)
    for i in range(4):
      for j in range(4):
        if e[i][j]:
          I=sum(m*inc(C,B[i],F(1))*inc(C,B[j],F(1)) for C,m in src)
          omega=I/min(mass[i],mass[j])
          assert omega<theta
          before_soft+=e[i][j]/(1-omega/theta)
    assert trace==2*total and energy==2*total-2*overlap
    assert overlap<=theta*before_soft/4
    assert total<=energy/2+theta*before_soft/4
    assert 2*(1-theta)*total<=energy<=2*total
    # Coherent unselected pairs exist: no global pairwise orthogonality inference.
    I01=sum(m*inc(C,B[0],F(1))*inc(C,B[1],F(1)) for C,m in src)
    assert I01/(roots[0]*roots[1])==1 and e[0][1]==0
    return {'n':n,'q_w':str(mw),'shared':str(shared),'pattern':pattern,'amplitude':str(amplitude),'R':str(total),'energy':str(energy),'before_soft':str(before_soft),'overlap':str(overlap),'pointwise_checks':pointwise}

stages={
'initial':[(9,r,c,0,F(1)) for r,c in product([F(9,10),F(1)],[F(0),F(1,32),F(1,16)])],
'edge_marks':[(16,r,c,p,F(1,2)) for r,c,p in product([F(9,10),F(1)],[F(0),F(1,32),F(1,16)],[0,1,2])],
'expanded':[(n,F(9,10),c,p,a) for n,c,p,a in product([25,36,64],[F(0),F(1,16)],[1,2],[F(1,3),F(1)])]}
results={k:[model(*r) for r in rows] for k,rows in stages.items()}
flat=[r for rows in results.values() for r in rows]
summary={'counts':{k:len(v) for k,v in results.items()},'total':len(flat),'pointwise':sum(r['pointwise_checks'] for r in flat),'positive_overlap':sum(F(r['overlap'])>0 for r in flat),'coherent_offedge_pairs':len(flat)}
Path(__file__).with_name('r422_aux_result.json').write_text(json.dumps({'summary':summary,'results':results},indent=2)+'\n')
print('PASS',summary)
print('Continuous matched center blocks with nonuniform full L1 source; artificial edge densities obey exact sigma column caps. No original stage/rank/history certification.')
print('r422_aux_result.json')
