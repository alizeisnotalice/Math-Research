from fractions import Fraction as F
from random import Random
rng=Random(42219)
counts={}
for stage,Ns in [('initial',[6,9,12]),('atoms_and_thresholds',[15,20,25]),('expanded',[32,48,64])]:
    configs=checks=0
    for N in Ns:
      for rep in range(8):
        masses=sorted(set(F(rng.randint(1,10000),10) for _ in range(N)))
        weights=[F(rng.randint(1,20),10) for _ in masses]
        K=F(rng.choice([3,4,8,16])); h=F(rng.randint(1,30),10)
        M=masses[rng.randrange(len(masses))]
        targets=[j for j,m in enumerate(masses) if M<=m<=2*M]
        below=sum((w for w,m in zip(weights,masses) if m<M),F())
        denom=max(h,below)
        H=[]
        for i,m in enumerate(masses):
          hit=[F(i==t) for t in targets]
          if m>2*M:
            eligible=[j for j in range(i) if masses[j]<m/K]
            Z=sum((weights[j] for j in eligible),F())
            hit=[sum((weights[j]*H[j][k] for j in eligible),F())/Z if Z>h else F() for k in range(len(targets))]
            for k,t in enumerate(targets):
              assert hit[k]<=weights[t]/denom,(stage,i,t,hit[k],weights[t]/denom)
              checks+=1
          H.append(hit)
        configs+=1
    counts[stage]={'configs':configs,'target_bounds':checks}
print('PASS',counts)
print('Finite exact mass-atom Markov kernels; not native cube realization or original history certification.')
