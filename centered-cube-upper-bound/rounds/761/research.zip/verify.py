"""R761 exact marked-cover, Euclidean box-tail, and interval scalar checks."""

import argparse
from collections import Counter, defaultdict
from fractions import Fraction as Q
from hashlib import sha256
from itertools import combinations, product
import json
from math import comb, prod
from pathlib import Path
from platform import python_version

from flint import arb, ctx, fmpq, __version__ as flint_version


ctx.prec = 256


def ball(x):
    q = Q(x)
    return arb(fmpq(q.numerator,q.denominator))


def cube(x,s):
    return ((x-s,x+s),(-s,s))


def intersect(*boxes):
    return tuple((max(a for a,_ in axis),min(b for _,b in axis)) for axis in zip(*boxes))


def length(interval):
    a,b = interval
    return max(Q(0),b-a)


def volume(box):
    return prod(map(length,box))


def contains(box,point):
    return all(a<z<b for (a,b),z in zip(box,point))


def volume_band(d):
    k = d.numerator.bit_length()-d.denominator.bit_length()
    return k if Q(2)**k<=d else k-1


def price_cover():
    n,a,K = 2,64,Q(4)
    G = (2+Q(1,a))**n
    x = (Q(-3),Q(1,2),Q(-5,8),Q(-1,8),Q(-1,4),Q(-3,16),Q(3))
    s = (Q(3),Q(2),Q(1),Q(1,2),Q(1,8),Q(1,64),Q(3,2))
    A = [cube(c,r) for c,r in zip(x,s)]
    E = [cube(c,r/a) for c,r in zip(x,s)]
    d,v = list(map(volume,A)),list(map(volume,E))
    assert all(volume(intersect(I,J))==0 for I,J in combinations(E,2))
    assert all(r>0 for r in v)
    density = [
        (((Q(-7),Q(6)),(Q(-4),Q(4))),Q(1)),
        (((Q(-1,2),Q(0)),(Q(-1,4),Q(1,4))),Q(5)),
        (((Q(-9,32),Q(-5,32)),(Q(-1,32),Q(1,32))),Q(7)),
        (((Q(3,2),Q(2)),(Q(-1,2),Q(1,2))),Q(3)),
    ]
    endpoints = [sorted({p for B in (*A,*(P for P,_ in density)) for p in B[k]}) for k in range(n)]
    patterns = defaultdict(Q)
    positive_cells = 0
    labels = range(len(s))
    for B in product(*(zip(e,e[1:]) for e in endpoints)):
        mid = tuple((a+b)/2 for a,b in B)
        mass = volume(B)*sum(w for P,w in density if contains(P,mid))
        mask = tuple(i for i in labels if contains(A[i],mid))
        if mass and mask:
            patterns[mask] += mass
            positive_cells += 1

    def mu(B):
        return sum(w*volume(intersect(B,P)) for P,w in density)

    m = [mu(B) for B in A]
    assert all(m[i]==sum(mass for mask,mass in patterns.items() if i in mask) for i in labels)
    assert all(m[i]>d[i] for i in labels)
    pair_mu = {(i,t):mu(intersect(A[i],A[t])) for i,t in product(labels,labels)}
    assert all(mass==sum(w for mask,w in patterns.items() if i in mask and t in mask)
               for (i,t),mass in pair_mu.items())
    receiver = [v[i]/m[i] for i in labels]
    gamma = [r/G for r in receiver]
    kappa = (4,3,1,2,1,4,2)
    source = [kappa[i]*gamma[i] for i in labels]
    W = {mask:sum(receiver[i] for i in mask) for mask in patterns}
    F = {mask:sum(source[i] for i in mask) for mask in patterns}
    assert all(0<F[mask]<=1 and F[mask]/W[mask]<=K/G for mask in patterns)
    alpha = Q(3,4)*max(F.values())
    H_label = defaultdict(Q)
    for i in labels:
        supported = [mask for mask in patterns if i in mask]
        for X,Z in product(supported,repeat=2):
            H_label[X,Z] += gamma[i]
    pair_integral = Q(0)
    eligible = 0
    witness = None
    for X,Z in product(patterns,repeat=2):
        joint = [i for i in X if i in Z]
        H = sum(gamma[i] for i in joint)
        assert H==H_label[X,Z]
        pair_integral += H*patterns[X]*patterns[Z]
        if F[X]<alpha:
            continue
        eligible += 1
        assert W[X]>=alpha*G/K
        post_receiver = sum(receiver[i] for i in joint)/W[X]
        post_source = sum(source[i] for i in joint)/F[X]
        upper = min(Q(1),K*H/alpha)
        assert max(post_receiver,post_source)<=upper
        if 0<upper<1 and post_receiver!=post_source and witness is None:
            witness = {"x_labels":X,"z_labels":Z,"H":str(H),"receiver_posterior":str(post_receiver),
                       "source_posterior":str(post_source),"common_upper":str(upper)}
    assert witness is not None and eligible<len(patterns)**2
    assert pair_integral==sum(gamma[i]*m[i]**2 for i in labels)

    rates = {k:min(s[k[0]],s[k[1]])/max(s[k[0]],s[k[1]]) for k in pair_mu}
    u = 1/(16*(arb(n)*arb(n+2).log()).sqrt())
    # For this particular input all pair selections by u are the same
    # as those by the exact rational trial cut 1/32.
    for rate in set(rates.values()):
        assert ball(rate)<u if rate<=Q(1,32) else ball(rate)>u
    down = [(i,t) for i,t in rates if s[i]>s[t] and rates[i,t]<=Q(1,32)]
    up = [(t,i) for i,t in down]
    records = []
    for name,side in (("big_to_small",down),("small_to_big",up)):
        benchmark = sum(gamma[i]*receiver[t]*pair_mu[i,t] for i,t in side)
        actual = sum(source[i]*receiver[t]*pair_mu[i,t] for i,t in side)
        reverse_sum = sum(w*sum(gamma[i]*receiver[t] for i,t in side if i in mask and t in mask)
                          for mask,w in patterns.items())
        reverse_actual = sum(w*sum(source[i]*receiver[t] for i,t in side if i in mask and t in mask)
                             for mask,w in patterns.items())
        assert 0<actual==reverse_actual<=K*benchmark and benchmark==reverse_sum
        records.append({"direction":name,"benchmark":str(benchmark),"actual_flow":str(actual)})
    assert records[0]["benchmark"]==records[1]["benchmark"]
    assert records[0]["actual_flow"]!=records[1]["actual_flow"]
    shared = max(patterns,key=lambda X:sum(i in X and t in X for i,t in down))
    shared_pairs = [(i,t) for i,t in down if i in shared and t in shared]
    gaps = sorted({volume_band(d[i])-volume_band(d[t]) for i,t in shared_pairs})
    assert len(gaps)>=3
    full = sum(gamma[i]*receiver[t]*mass for (i,t),mass in pair_mu.items())
    assert full==sum(w*W[mask]**2/G for mask,w in patterns.items())<=2*sum(v)
    return {
        "n":n,"a":a,"G_upper":str(G),"K":str(K),"alpha":str(alpha),
        "parent_centers_x":list(map(str,x)),"half_sides":list(map(str,s)),
        "m_over_d":list(map(str,(m[i]/d[i] for i in labels))),
        "price_positive_cells_inside_parents":positive_cells,
        "positive_price_patterns":len(patterns),"H_price_pairs":len(patterns)**2,
        "eligible_ordered_pairs":eligible,"posterior_witness":witness,
        "double_price_integral_H":str(pair_integral),"extreme_trial_cut":"1/32",
        "extreme_direction_flows":records,"shared_price_pattern_labels":shared,
        "same_price_extreme_pairs":shared_pairs,"dyadic_volume_gaps_on_that_price_pattern":gaps,
        "all_pairs_moment_bound":str(full),
    }


def convolution(a,b):
    ans = [Q(0)]*(len(a)+len(b)-1)
    for i,x in enumerate(a):
        for j,y in enumerate(b):
            ans[i+j] += x*y
    return ans


def sliced_polynomial(slices):
    coeff = [Q(1)]
    for inside,outside in slices:
        coeff = convolution(coeff,[inside,outside])
    return coeff


def box_audit(name,z,short_q=None,m=None,shared_middle=True):
    n = len(z)
    h = 1+Q(1,32*n)
    R = 1/h
    w = h*R
    if shared_middle:
        assert all(abs(t)/2<=R for t in z)  # x=0,z have one original parent centered at z/2.
    desired = (-w,w)
    owner = tuple((t-w,t+w) for t in z)
    inside = [length(intersect((I,),(desired,))[0]) for I in owner]
    slices = [(a,2*w-a) for a in inside]
    whole = (2*w)**n
    geom = [q/whole for q in sliced_polynomial(slices)]
    probabilities = [min(Q(1),abs(t)/(2*h*R)) for t in z]
    tail = [Q(1)]
    for p,count in sorted(Counter(probabilities).items()):
        block = [comb(count,j)*p**j*(1-p)**(count-j) for j in range(count+1)]
        tail = convolution(tail,block)
    assert tail==geom and sum(tail)==1
    if n<=8:
        independent = [sum(prod(slices[i][flag] for i,flag in enumerate(bits))
                           for bits in product((0,1),repeat=n) if sum(bits)==k)/whole
                       for k in range(n+1)]
        assert geom==independent
    answer = {
        "n":n,"case":name,"mean_exceeding_axes":str(sum(probabilities)),
        "axis_probability_multiplicities": [[str(v),c] for v,c in sorted(Counter(probabilities).items())],
        "prob_at_least_2_4_8": [ball(sum(tail[k:])).str(13) for k in (2,4,8)],
        "same_middle_parent":shared_middle,
    }
    if short_q is not None:
        pad = 2*R/short_q
        assert all(abs(t)<=pad for t in z)
        outer_slabs = ((-w-pad,-w),(w,w+pad))
        masked_slices = [
            (c,sum(length(intersect((I,),(J,))[0]) for J in outer_slabs))
            for I,c in zip(owner,inside)
        ]
        exact_chopped_volume = sum(sliced_polynomial(masked_slices)[:m+1])/whole
        assert exact_chopped_volume==sum(tail[:m+1])
        padded = sum(sliced_polynomial([(2*w,2*pad)]*n)[:m+1])/whole
        normalized_volume = sum(comb(n,j)*(2/(h*short_q))**j for j in range(m+1))
        assert padded==normalized_volume
        answer.update({"trial_q":short_q,"maximum_allowed_outside_axes":m,
                       "reference_volume_captured":ball(exact_chopped_volume).str(13),
                       "normalized_padded_volume":ball(padded).str(13)})
    return answer


def spatial_tails():
    small = (Q(1,4),Q(-1,2),Q(7,4),Q(0))
    saturation = (Q(3),Q(-1,2),Q(0),Q(0))
    result = [box_audit("initial_exact",small),
              box_audit("saturation_edge",saturation,shared_middle=False)]
    for n in (16,64,256):
        sparse = (Q(7,4),Q(-3,2),Q(3,4))+(Q(0),)*(n-3)
        diffuse = tuple((-1)**j*Q(4,n) for j in range(n))
        result.extend((box_audit("sparse_mean_two",sparse),box_audit("diffuse_mean_two",diffuse)))
        h = 1+Q(1,32*n)
        q = n
        short = tuple((-1)**j*2/(h*q) for j in range(n))
        result.append(box_audit("short_padding",short,q,n.bit_length()-3))
    return result


def scalars():
    result = []
    for k in (4,8,16,64,128):
        n = 2**k
        ell = arb(n+2).log()
        p = 1+1/ell
        h = ball(1+Q(1,32*n))
        u = 1/(16*(arb(n)*ell).sqrt())
        U = 4*n
        N = 3+n*(k+2)
        assert U==2**(k+2)
        bins = (arb(N).log()*(1-1/p)).exp()
        bins_alt = (arb(N).log()/(1+ell)).exp()
        tensor = ((128*(h*u)**2/(p-1)).log1p()*n/2).exp()
        tensor_alt = ((h*h/(2*n)).log1p()*n/2).exp()
        assert abs(bins-bins_alt)<arb(2)**-180 and abs(tensor-tensor_alt)<arb(2)**-180
        assert bins<arb(2).exp() and tensor<(h*h/4).exp()
        L = arb(n).sqrt()*ell**3
        normalized_exponent = u*L/ell
        assert abs(normalized_exponent-ell*ell.sqrt()/16)<arb(2)**-180
        result.append({"log2_n":k,"N":N,"N_to_1_minus_inverse_p":bins.str(14),
                       "tensor_factor":tensor.str(14),"L_over_n":(L/n).str(14),
                       "uL_over_ell":normalized_exponent.str(14)})
    return {"samples":result,
            "limiting_algebra":"N~n log_2 n; tensor base 1+h^2/(2n); uL/ell=ell^(3/2)/16"}


def report():
    return {
        "scope":(
            "Real 2D priced cubes and disjoint full owners with a conservative universal G upper bound. "
            "Posteriors use the displayed finite hats, before complete terminal screening. "
            "The higher-dimensional tests concern uniform Lebesgue volume of boxes. "
            "Arb samples check scalar identities and trends at the chosen dimensions."
        ),
        "python":python_version(),"python_flint":flint_version,"arb_bits":ctx.prec,
        "source_sha256":sha256(Path(__file__).read_bytes()).hexdigest(),
        "commands":["python -B verify.py --out verify.json","python -B verify.py --check verify.json"],
        "price_cover":price_cover(),"box_tails":spatial_tails(),"extreme_scalars":scalars(),
    }


def main():
    parser = argparse.ArgumentParser()
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--out",type=Path)
    group.add_argument("--check",type=Path)
    args = parser.parse_args()
    result = report()
    data = (json.dumps(result,indent=2,sort_keys=True)+"\n").encode()
    if args.out:
        args.out.write_bytes(data)
        print(f"wrote {args.out} ({len(data)} bytes)")
    else:
        assert args.check.read_bytes()==data, "certificate differs"
        print(f"identical rerun of {args.check} ({len(data)} bytes)")
    print(f"{result['price_cover']['H_price_pairs']} H price pairs, {len(result['box_tails'])} box tests, "
          f"{len(result['extreme_scalars']['samples'])} Arb scale tests")


if __name__=="__main__":
    main()

