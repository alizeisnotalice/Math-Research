# R311 conditional higher-soft FIRST certificates

Exact conditional coefficient and finite capacity certificates only. Condition C requires same original x,L,q have full-source P_p,L*beta<=q at referencep>=actuals. This history/selector mapping is not established by these numerical tests and is never inferred from actuals FIRST. Toy matrices explicitly assume/construct C, not a full original kernel. No general root/source certificate.

For k0>=1,p=k0/n,0<=s<=p/2,allk>=k0: b_k(s)<=r b_k(p),r=2^-k0[(1-p/2)/(1-p)]^(n-k0) ifp<1. p1 onlyk=n,r2^-n. b_k(s)=binom(n,k)s^k(1-s)^(n-k); combinatorial factors cancel in ratios. K=n is empty high-degree tail and needs no p>1.

Under C, fixed-x source aggregate of normalized tail<=r, hence pair<=r An Wnu after the hard-column envelope, without any capture probability lower bound. Toy selected masks are frozen and no unweighted component FIRST is assumed.

For canonical FIRST rows, or conditional on the legacy selector bridge, actual softness is strictly above margin1-2^(-1/n). This is not an unconditional legacy-selector requirement; the legacy mapping remains unproved here. Newgate s<=p/2 is nonempty iff(1-p/2)^n<1/2, exact Fraction test. Equality is empty. Bernoulli proves margin>=1/(2n); n1 equality separately guarded.

|original n|qH|original K|k0|r(n+1)|<=eta1/128?|small-s gate nonempty under canonical/conditional margin?|
|---:|---:|---:|---:|---:|---|---|
|256|1/65536|222|223|2.7856274e-44|True|True|
|256|1|111|112|1.7325833e-11|True|True|
|256|65536|12|13|19.158537|False|True|
|1024|1/1048576|251|252|6.91737e-23|True|True|
|1024|1|122|123|6.6231231e-09|True|True|
|1024|1048576|3|4|472.43537|False|True|

The coefficient algebra itself is tested without a selector-margin assumption. Initial all k0=1..n and all tailk for n1,2,4,8. Boundary n1,4,16 includes p0,p1,emptytail,s0 and strict margin equality. Expanded n64,256,1024 uses selected k0 and endpoint/interior tail degrees, not an exhaustive large grid. Original six R309 cutoff records are embedded unmodified, with k0=K+1.

The original higher-soft capacity C remains a hypothesis. The table is not evidence that the original selector/history supplies it; it only reports the exact consequence if supplied. No favorable replacement cutoff K is chosen. Seven finite positive-kernel/source toys test full-source reference capacity and the aggregate/pair conclusion, including p0,p1,emptytail and zero source mass.

Canonical last-FIRST algebra fixture: G=1-4(s-1/2)(s-7/10)(s-9/10), positive degree3 Bernstein coefficients113/50,53/150,187/150,47/50. Last crossing is9/10; earlier1/2 fails to cap all future (G(4/5)>1). Factor identity, four interval signs and100 future grid points are exact. This fixture does not realize the original actual f/history.
