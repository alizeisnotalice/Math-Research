# R311 selector bridge: FIRST sigma versus R107/R292/R309 actual softness

## Exact established statement

The original uncut FIRST ledger explicitly states that, on each remaining receiver row and for one common (q\in[3\lambda/4,\lambda]), there is an original interior global FIRST selector ((\sigma(x),L(x))) such that

`P_(sigma(x),L(x))*f(x)=q`, and `P_(p,L')*f(x)<=q` for every `p>=sigma(x)` and every `L' in [a,2a]`.

Sources: `/Users/zhengzhihao/Desktop/T/output/cube_general_20261003/UNCUT_FIRST_LEDGER.md:7–14` and the current reduction `/Users/zhengzhihao/Desktop/T/output/cube_general_20261003/GENERAL_CURRENT_REDUCTION.md:7–13`. The same (f) is the complete original input. The common q and full octave are explicit. This proves the desired higher-softness cap **with threshold sigma**, on those retained rows.

`first_softness.md:7–13` independently defines sigma as the rightmost softness crossing of the original full-source response and, for the common physical maximum, selects its maximizing scale; it proves all higher softness responses are at most the level at that selected scale. This agrees with the threshold interpretation, but does not identify that object with the `s(x)` symbol in the R107/R309 source interfaces.

## Historical actual-selector chain located

- R107's frozen actual input is written with `s(x)`: `rounds/107/research.zip::proof.md:903–911`, specifically `P_(s(x),L_s(x))*f(x)=q`. The same R107 proof later writes `P_(sigma(x),L_s(x))` in its N1 majorant (`:455–465`) but does not define or assert `sigma(x)=s(x)` in that passage. This is evidence of closely related notation, not an explicit selector identity.
- R112 continues to use the actual selected kernel `P_(s(x),L_s(x))` with `q` common on E (`rounds/112/research.zip::proof.md:401–409`).
- R292's low-pe note defines the **same kernel family** `p_s=(1-s)h+s phi`, `phi=h*w`, then deliberately takes an envelope over `0<=s<=sigma`, where sigma is only “a frozen sigma ... covering the actual softness (sigma=1 always works)” (`rounds/292/research.zip::lowpe_geometry.md:25–36`). This sigma is not identified as the FIRST crossing.
- R309 retains `P_(s(x),L(x))` and calls `s(x)` the common actual softness, with FIRST and same-R cap among its inherited qualifications (`rounds/309/research.zip::r309_geometry.md:7–10`; `r309_combined.md:5–17`). It does not state the stronger all-`p>=s(x)`, all-`L'` cap.
- The kernel itself is the same true product family: R107 R4 (`rounds/107/research.zip::proof.md:933–938`) defines `h=1_[-1/2,1/2]`, `w(u)=integral_0^1 exp(-|u|/t)dt`, `phi=h*w`, `P_s=((1-s)h+s phi)^{tensor n}`; R292 uses the same h, phi and p_s at `lowpe_geometry.md:25–29`; R309 uses the same h,w,phi and actual product expansion at `r309_combined.md:11–20`. The kernel functions match; the selector parameters are a separate issue.

## Source domination and conditional consequence

The later original coupled source satisfies `nu<=zeta_sigma*<=beta^c=alpha-eta_alpha^c<=alpha`, with `alpha_V=mu_hi|V` and `mu_hi=f_hi dy<=f dy` (`rounds/237/research.zip::source_ledger.md:21–26`; current input split is also `GENERAL_CURRENT_REDUCTION.md:19`). Thus the specifically coupled original beta obeys `beta^c<=f`; the hard nu does too. Conditional on identifying R309's actual (s(x)) with the FIRST σ(x) (or proving (s(x)\ge\sigma(x))) and identifying its (q(x)) with the same common q, positivity gives

`P_(p,L')*beta^c(x) <= P_(p,L')*f(x) <= q`

for all `p>=s(x)` and `L' in [a,b]`. At any one fixed `(p,L')`, each nonnegative weighted tensor component of `P_(p,L')*beta^c` is separately bounded by the total response cap. This does not permit changing p/L' independently across terms, nor transfer the cap to a different kernel or source not dominated by f.

## Status of the key bridge and re-selection option

**The archive chain inspected here does not explicitly prove the equality/ordering bridge from the uncut FIRST σ to the `s(x)` used by R107/R112/R292/R309, or the corresponding rowwise q identity from common q to R309 `q(x)`.** R107's N1 symbol is the nearest hint, but R1's actual input and all later interfaces consistently name `s(x)`; R292 uses an upper-envelope sigma; neither establishes the needed mapping. Therefore the higher-softness cap cannot yet be imported into the R309 component-payment argument as a proved property of its actual selector.

One may define a *new* FIRST-based receiver family directly from the original full input, using σ(x) and its first maximizing L(x). The uncut ledger proves the cap for that family. But this is not a historical identity with the R309 remainder: changing the selector can change the actual kernel weight, ratio band, full `e_g/m`, aspect qualification, and the original joint `a_omega`/history masks. No cited construction proves those R309 hypotheses and exact positive allocation survive that reselection. Treating such a redesign as valid would be a new construction proof, not a notation fix.

## Hard-band lower softness margin and the small-softness branch

The same uncut original FIRST ledger explicitly states that its FIRST crossing satisfies `sigma>1-2^(-1/n)` on the retained hard-band event (`UNCUT_FIRST_LEDGER.md:14`). Since

`1-2^(-1/n) >= 1/(2n)` for every integer n>=1,

with equality only at n=1, its strict inequality implies `sigma>1/(2n)` for all n>=1. (The inequality follows from concavity of `x -> 1-2^(-x)` on `[0,1]` and its chord between 0 and 1.) Consequently, **if** the actual `s(x)` used in the R310 tiny-softness endpoint lemma is the same FIRST crossing or is at least that crossing, a row gate `s(x)<=s0<=1/(2n)` is empty on this original retained event. This is an applicability restriction on the original event; it does not invalidate the abstract small-softness kernel/geometry lemma for unconstrained parameters.

The implication to the actual `s(x)` used in the R310 tiny-softness endpoint lemma remains conditional on the selector bridge above. The lower margin alone is a proved statement about FIRST σ, not proof that a differently parameterized or reselected R309 row has the same margin.

## R107/R112 actual row: what is and is not fixed

R107 does not define `s(x)` as a free variable that a later argument may replace. Its input section says to “retain” the original softness `s(x)`, physical selectors `L_s(x),R(x)`, and common q, then records `P_(s(x),L_s(x))*f(x)=q` (`rounds/107/research.zip::proof.md:903–911`). Its actual traffic includes the original history kernel and only states the one-point marginal `Gamma<=q^{-1}P_(s(x),L_s(x))mu_hi` (`:920–938`). R112 repeats that inherited actual-selector input (`proof.md:401–423`). The clauses establish the actual row and its full-source equality, but those passages do not define its construction as “take the rightmost FIRST crossing” nor grant a rowwise freedom to replace it. R107 N1 at `proof.md:455–465` uses σ(x) in a displayed majorant, but there is no local declaration equating it to R1's s(x); taken with R1, this is a notation inconsistency/implicit alias, not a checked bridge.

The full-event FIRST ledger is independently clear: its “every remaining row” is a row in its own stated retained set and has the FIRST σ and common q (`UNCUT_FIRST_LEDGER.md:9–14`). The located files do not state the set identity `E_R107/R112/R309 subset E_uncut` with the same receiver and outer data. Nor does R309 replace its variable q(x) by the uncut common q; it specifies only `q_-<=q(x)<=lambda` (`rounds/309/research.zip::r309_geometry.md:7–10`). These are separate parts of the bridge, not consequences of kernel identity.

## Minimum sufficient bridge to import the cap into R309

A complete, rowwise connector sufficient for the proposed application must state all of the following for the **same retained original R309 rows and same outer seed/data**:

1. Each such x belongs to the uncut-FIRST retained event, with `q(x)=q` equal to its common level and `s(x)>=sigma(x)` (equality is enough).
2. The actual R309 `P_(s(x),L(x))` is the same product kernel (P_s=((1-s)h+s(h*w))^{\otimes n}) used in the FIRST statement, and (L(x)\in[a,b]). The kernel-family equality is already documented at R107 R4 (`proof.md:933–938`), R292 (`lowpe_geometry.md:25–29`), and R309 (`r309_combined.md:11–20`); only the parameter-selector identification is missing.
3. The soft source in the R309 integral is the original coupled β with `beta<=f` (R237 `source_ledger.md:21–26`), not a re-FIRSTed or independently chosen source.
4. The original R309 gates, low/m/e_g, aspect, hard R, `alpha`, history and allocation are evaluated on exactly those same rows and selectors; the bridge may not silently reselect L/s and then reuse old gates.

Then the uncut all-higher-softness/all-octave cap on f plus beta<=f gives the desired beta cap by positivity. At each fixed ((p,L')), its nonnegative mixture components are bounded as weighted terms by the total cap. This consequence does not permit comparing components at different p or L'.

**Could a new FIRST selector be chosen directly?** The uncut construction does provide a measurable FIRST selector for its own remaining rows (`UNCUT_FIRST_LEDGER.md:9–14`; measurability construction in `first_softness.md:11–13`). Replacing R309's inherited `s(x),L(x)` by that selector would define a new row family. No located source proves it has the same R308 remainder, original `a_omega`/history mask, low-pe and m qualification, aspect branch, source allocation, or fees. Therefore this is a possible new construction to prove, not a valid shortcut for the frozen R309 payment.

## Small-softness boundary correction

The hard-band statement is `sigma>1-2^(-1/n)` (`UNCUT_FIRST_LEDGER.md:14`). For n=1, `1-2^(-1/n)=1/(2n)=1/2`; for n>1 the left side is strictly larger than `1/(2n)`. In all dimensions, the **strict** sigma inequality still implies `sigma>1/(2n)`. Thus the R310 gate `s(x)<=s0<=1/(2n)` is empty if the sufficient bridge gives `s(x)>=sigma(x)`. Without that bridge this emptiness applies only to FIRST-σ rows, not automatically to the tiny-softness lemma's named actual-s rows. The abstract small-softness lemma remains valid for unconstrained parameters.
