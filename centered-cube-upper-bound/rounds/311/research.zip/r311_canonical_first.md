# R311 main: explicit canonical FIRST rows from the original L1 input

This is a direct construction on the original input, not a claim that an unlocated legacy selector is identical to it. Its mathematical purpose is to give a fully specified native row family (possibly empty for a given input) where the higher-softness response receipt applies without an extra capacity hypothesis. The full operator upper bound and its legacy history bridge remain unproved.

## Assumptions and original family

Fix n>=1, 0<a<=b<infinity, lambda>0, common q in [3lambda/4,lambda], and an arbitrary nonnegative integrable f on R^n. Define h=1_[-1/2,1/2], w(t)=integral_0^1 exp(-|t|/u)du, phi=h*w, and

 P_(s,L)(v)=L^(-n) product_i[(1-s)h(v_i/L)+s phi(v_i/L)],
 F(x,s,L)=integral P_(s,L)(x-y)f(y)dy,
 G_s(x)=max_(a<=L<=b) F(x,s,L).

All kernels are nonnegative and bounded by a^(-n) for s∈[0,1], L∈[a,b], because phi<=1. h is taken with a fixed closed-cube boundary convention. f is not replaced, truncated or made independent. In applications requiring the previous scale constant assume also b<=2a.

## Continuity and measurable maximizers

F is jointly continuous in (x,s,L). To prove this, let a sequence of parameters converge. For almost every y, no coordinate of the limiting (x-y)/L equals +/-1/2; the exceptional set is a finite union of hyperplanes and has f(y)dy measure zero. h therefore converges there; phi is continuous, for example by its integral representation. The common bound a^(-n)f(y) is integrable. Dominated convergence proves the assertion, including s=0 and1 and scale endpoints. Compactness of [a,b] then gives continuity of G in (x,s) and attainment of the scale maximum.

Work on the Borel original receiver event

 E_can={x:2lambda<G_0(x)<=4lambda and G_1(x)<q}.

For each x in E_can the compact nonempty set A_x={s∈[0,1]:G_s(x)>=q} has a largest element. Define

 sigma(x)=max A_x.

Then 0<sigma(x)<1, G_sigma(x)=q, and G_p(x)<q for every p>sigma(x). Indeed G_0>q and G_1<q, and a value G_sigma>q would persist slightly to its right, contradicting maximality. No monotonicity of G_s is assumed. In particular

 F(x,sigma(x),L_*(x))=q,
 F(x,p,L')<=q for every p>=sigma(x), a<=L'<=b.       (1)

For t∈[0,1], within E_can,
 {sigma>=t}={max_(t<=s<=1)G_s>=q},
which is Borel by compact maximization of a jointly continuous function. Thus sigma is Borel (extend it by zero outside E_can if needed).

Choose L_*(x) to be the minimum of the nonempty compact set of maximizers of L↦F(x,sigma(x),L). It is Borel. For a<t<=b, the condition L_*<t is the union over positive integers j with a<=t-1/j of

 max_(a<=L<=t-1/j)F(x,sigma(x),L)=q.

The maximum is a Borel function, obtained by a supremum over a countable dense subset together with endpoints; composition with sigma is Borel. For t<=a the set is empty and for t>b it is all E_can. Equality cases and L_*=a,b are covered. This proves a measurable selector without assuming a selection theorem for an unspecified graph.

## The genuine hard margin and source capacities

For every s, positivity of the tensor expansion gives G_s>= (1-s)^n G_0. At s_bar=1-2^(-1/n), G_sbar>lambda>=q on E_can. Continuity therefore gives

 sigma>s_bar>=1/(2n),                               (2)

where the last inequality is Bernoulli: (1-1/(2n))^n>=1/2. Equality in that scalar inequality occurs at n=1, but sigma is still strictly larger. Therefore the tiny-softness branch s<=s0<=1/(2n) of the abstract R310 endpoint lemma is EMPTY on these canonical FIRST rows. Its inequality was valid, but is not a substantive payment on E_can. It must not be counted as newly removed original input here.

For any fixed positive sources beta,nu dominated by f(y)dy, (1) gives

 P_(p,L')*beta(x)<=q for all p>=sigma(x), L'∈[a,b],
 h_(R')*nu(x)<=4lambda for all R'∈[a,b].             (3)

The statements retain the same original x and f; no cap is transferred to virtual receivers. For any fixed measurable original gate 0<=alpha(x,y)<=1,
 U_y(x)=1_(E_can)(x)alpha(x,y)P_(sigma(x),L_*(x))(x-y)/q
satisfies the ordinary aggregate FIRST and (3) without a new componentwise FIRST. Arbitrary already specified binary source/history qualification and pair masks may be retained in the subsequent inequalities. They are not reselected after a source subset or a latent degree is observed.

## Consequence for the R311 receipt and its exact scope

On this explicitly constructed native family, the R311 coefficient comparison at p=k0/n is legal whenever sigma<=p/2. It pays the original high-degree capturing pair component by r_(n,k0) A_n W_nu, with actual dx and any fixed original masks satisfying the pair setup. This is a theorem for arbitrary original L1 f on E_can, not merely a finite model or an assumed upper cap.

It does NOT prove that these sigma,L_*,q are the same fields as an existing legacy R310 row, or that its old e_g,m/source histories can be transplanted while keeping the old target equal. Applying the theorem to that target requires the explicit row/event/level/selector/source bridge recorded in r311_selector_bridge.md. Nor does this construction prove the complete global reduction from the maximal event: G_1>=q, hard-band decomposition, scale endpoints, retained input deletions, time atoms and the middle hard-layer history entry keep their original separate ledger obligations. No original unproved global connector is silently repaired.

The construction identifies the exact stronger data needed for the new geometric theory. Subsequent work should derive the hard-layer target directly on these native rows or certify the old row identity; it should not continue to pay abstract branches that (2) excludes from the original FIRST event.
