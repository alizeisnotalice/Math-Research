#!/usr/bin/env python3
"""R311 exact conditional higher-soft FIRST tail certificates; no history mapping."""
import json,math,hashlib
from pathlib import Path
from fractions import Fraction as F
from decimal import Decimal,localcontext
COUNTS={};FAIL=[];ETA=F(1,128)
def ck(ok,label,data):
 COUNTS[label]=COUNTS.get(label,0)+1
 if not ok:FAIL.append({'test':label,'data':data})
CUTOFF_SOURCE_SHA256='e1851971919ff9ad4e02e42be9a5272f8ce1ba4343fa146123411871b071f9ee'
ORIGINAL_SIX_CUTOFFS=[{'stage': 'parameter_pressure', 'n': 256, 'qH': '1/65536', 'K': 222, 'high_softness_threshold': '1603/320', 'nonempty': False}, {'stage': 'parameter_pressure', 'n': 256, 'qH': '1', 'K': 111, 'high_softness_threshold': '413/160', 'nonempty': False}, {'stage': 'parameter_pressure', 'n': 256, 'qH': '65536', 'K': 12, 'high_softness_threshold': '133/320', 'nonempty': True}, {'stage': 'expanded', 'n': 1024, 'qH': '1/1048576', 'K': 251, 'high_softness_threshold': '903/640', 'nonempty': False}, {'stage': 'expanded', 'n': 1024, 'qH': '1', 'K': 122, 'high_softness_threshold': '903/1280', 'nonempty': True}, {'stage': 'expanded', 'n': 1024, 'qH': '1048576', 'K': 3, 'high_softness_threshold': '7/128', 'nonempty': True}]
def bernstein(n,k,s):return F(math.comb(n,k))*s**k*(1-s)**(n-k)
def parameters(n,k0):
 if k0>n:return None,F(0)
 p=F(k0,n)
 if p==1:return p,F(2)**(-n)
 if not p:return p,F(1)
 return p,F(2)**(-k0)*((1-p/2)/(1-p))**(n-k0)
def rational(q):
 with localcontext() as ctx:
  ctx.prec=50;dec=str(Decimal(q.numerator)/Decimal(q.denominator));log=str((Decimal(q.numerator)/Decimal(q.denominator)).log10()) if q>0 else None
 out={'decimal50_diagnostic':dec,'log10_diagnostic50':log}
 if q.numerator.bit_length()+q.denominator.bit_length()<=1500:out['exact_fraction']=str(q)
 else:
  a=abs(q.numerator).to_bytes(max(1,(abs(q.numerator).bit_length()+7)//8),'big');b=q.denominator.to_bytes(max(1,(q.denominator.bit_length()+7)//8),'big');out.update({'exact_binary_rational_sha256':hashlib.sha256(bytes([q.numerator<0])+len(a).to_bytes(8,'big')+a+b).hexdigest(),'numerator_bits':q.numerator.bit_length(),'denominator_bits':q.denominator.bit_length()})
 return out
def margin(n,p):
 upper=p/2;root_comparison=(1-upper)**n;nonempty=root_comparison<F(1,2)
 lower_comparison=(1-F(1,2*n))**n
 ck(lower_comparison>=F(1,2),'exact_original_margin_ge_one_over_2n_Bernoulli',{'n':n})
 if n==1:ck(lower_comparison==F(1,2),'n_one_margin_equality_guard',{})
 else:ck(lower_comparison>F(1,2),'n_gt_one_original_margin_strict',{'n':n})
 ck((not nonempty)==(root_comparison>=F(1,2)),'exact_small_s_gate_vs_strict_original_margin_complement',{'n':n,'p':str(p)})
 if root_comparison==F(1,2):ck(not nonempty,'small_s_gate_margin_equality_empty',{'n':n,'p':str(p)})
 return {'margin_applicability':'For canonical FIRST rows, or conditional on the legacy selector bridge, actual softness is strictly above margin. Legacy applicability is not established by these tests.','original_margin_symbolic':'1-2^(-1/n)','certified_margin_lower_bound':str(F(1,2*n)),'new_small_s_upper_p_over2':str(upper),'exact_root_free_test_one_minus_upper_power_n':rational(root_comparison),'gate_nonempty_with_strict_original_margin':nonempty}
def coefficient_case(n,k0,all_k):
 p,r=parameters(n,k0)
 if p is None:
  ck(sum(bernstein(n,k,F(1,2)) for k in range(k0,n+1))==0,'empty_tail_K_equals_n_no_higher_softness_needed',{'n':n,'k0':k0})
  return {'n':n,'k0':k0,'tail_empty':True,'p':None,'r':rational(r)}
 ks=list(range(k0,n+1)) if all_k else sorted(set([k0,min(n,k0+1),(k0+n)//2,n]));ss=sorted(set([F(0),p/8,p/4,p/2]));references={k:bernstein(n,k,p) for k in ks}
 if p==0:
  ck(all(bernstein(n,k,F(0))==references[k] for k in ks) and r==1,'p_zero_endpoint_actual_s_zero',{'n':n})
 elif p==1:
  ck(k0==n and r==F(2)**(-n) and ks==[n],'p_one_only_degree_n_tail',{'n':n})
 else:ck(bernstein(n,k0,p/2)==r*bernstein(n,k0,p),'exact_r_is_endpoint_degree_k0_ratio',{'n':n,'k0':k0})
 for k in ks:
  vals=[bernstein(n,k,s) for s in ss]
  for s,val in zip(ss,vals):
   ck(0<=val<=r*references[k],'exact_tail_coefficient_domination',{'n':n,'k0':k0,'k':k,'s':str(s)})
   if 0<p<1 and k<n:
    ck(val*bernstein(n,k+1,p)>=bernstein(n,k+1,s)*references[k],'exact_ratio_nonincreasing_degree_cross_product',{'n':n,'k0':k0,'k':k,'s':str(s)})
  ck(all(a<=b for a,b in zip(vals,vals[1:])),'exact_tail_coefficient_monotone_small_s',{'n':n,'k0':k0,'k':k})
 return {'n':n,'k0':k0,'p':str(p),'tail_empty':False,'tested_degrees':ks,'tested_actual_s':list(map(str,ss)),'r':rational(r),'r_times_n_plus1':rational(r*(n+1)),'eta':str(ETA),'r_An_rational_payment_certified':r*(n+1)<=ETA,'margin':margin(n,p)}
def capacity_toy(n,k0,zero_nu=False):
 p,r=parameters(n,k0);p=F(1) if p is None else p;beta=[F(1,2),F(2,3),F(0)];nu=[F(0),F(0)] if zero_nu else [F(2,3),F(5,7)];q=[F(3,4),F(7,8),F(1),F(3,4)];mass=[F(1,8),F(3,16),F(1,4),F(1,16)];R=[F(1),F(5,4),F(3,2),F(2)];capture=[[1,0],[1,1],[0,1],[1,1]];ss=[F(0),p/8,p/4,p/2]
 rows=[];pair=F(0)
 for x in range(4):
  feature=[[F(1+(7*x+5*y+3*k)%13,1+(x+y+k)%5) for k in range(n+1)] for y in range(3)]
  fullraw=sum(beta[y]*sum(bernstein(n,k,p)*feature[y][k] for k in range(n+1)) for y in range(3));scale=q[x]/fullraw
  ref=[scale*sum(bernstein(n,k,p)*feature[y][k] for k in range(n+1)) for y in range(3)]
  tail=[scale*sum(bernstein(n,k,ss[x])*feature[y][k] for k in range(k0,n+1)) for y in range(3)]
  ck(sum(b*v for b,v in zip(beta,ref))==q[x],'toy_condition_C_full_source_reference_capacity_exact',{'n':n,'k0':k0,'x':x})
  ck(all(a<=r*b for a,b in zip(tail,ref)),'toy_same_x_kernel_source_pointwise_tail_domination',{'n':n,'k0':k0,'x':x})
  aggregate=sum(b*v for b,v in zip(beta,tail))/q[x]
  ck(aggregate<=r,'toy_source_aggregate_normalized_le_r',{'n':n,'k0':k0,'x':x})
  for z,v in enumerate(nu):
   selected=sum(beta[y]*tail[y]*capture[x][z]*int((x+2*y+z)%4!=0) for y in range(3))/q[x]
   ck(selected<=r*capture[x][z],'toy_frozen_capture_qualification_no_probability_lower_bound',{'n':n,'k0':k0,'x':x,'z':z})
   pair+=mass[x]*R[x]**(-n)*v*selected
  rows.append({'x':x,'actual_s':str(ss[x]),'q':str(q[x]),'reference_full_source_response':str(sum(b*v for b,v in zip(beta,ref))),'tail_normalized_source_aggregate':rational(aggregate)})
 Ancol=max(sum(mass[x]*R[x]**(-n)*capture[x][z] for x in range(4)) for z in range(2));bound=r*Ancol*sum(nu)
 ck(pair<=bound and Ancol<=n+1,'toy_pair_r_An_Wnu_capacity_certificate',{'n':n,'k0':k0})
 return {'n':n,'k0':k0,'p':str(p),'zero_nu':zero_nu,'scope':'abstract positive component-kernel/source capacity; same x/component array/q at actuals and p, frozen qualification. Not actual original kernel/history realization. Reference capacity is constructed as assumption C, never inferred from actuals FIRST.','beta':list(map(str,beta)),'nu':list(map(str,nu)),'receiver_mass':list(map(str,mass)),'R':list(map(str,R)),'capture':capture,'feature_recipe':'F(1+(7*x+5*y+3*k)%13,1+(x+y+k)%5), multiplied at fixed x by q[x]/reference_full_source_response. Same feature array used at actuals and referencep.','rows':rows,'actual_tail_pair':rational(pair),'r_Ancol_Wnu_bound':rational(bound),'Ancol':str(Ancol),'r':rational(r)}
initial=[coefficient_case(n,k0,True) for n in [1,2,4,8] for k0 in range(1,n+1)]
boundary=[coefficient_case(n,k0,True) for n in [1,4,16] for k0 in sorted(set([0,1,2 if n>=2 else 1,n-1 if n>1 else 1,n,n+1]))]
expanded=[coefficient_case(n,k0,False) for n in [64,256,1024] for k0 in sorted(set([1,2,4,8,n//4,n-1,n]))]
linked=[]
for source in ORIGINAL_SIX_CUTOFFS:
 n=source['n'];K=source['K'];case=coefficient_case(n,K+1,False);case.update({'qH_original':source['qH'],'K_original_unmodified':K,'source_snapshot_record':source});linked.append(case)
toys=[capacity_toy(n,k0) for n,k0 in [(4,1),(4,4),(16,8),(64,32),(16,17),(4,0)]]+[capacity_toy(4,2,True)]
# Canonical last-FIRST direction fixture supplied by the main author.
bernstein_coeff=[F(113,50),F(53,150),F(187,150),F(47,50)];roots=[F(1,2),F(7,10),F(9,10)]
def fixture_G(s):return sum(b*bernstein(3,k,s) for k,b in enumerate(bernstein_coeff))
def factored_G(s):return 1-4*math.prod(s-r for r in roots)
power=[F(0)]*4
for k,b in enumerate(bernstein_coeff):
 for j in range(3-k+1):power[k+j]+=b*math.comb(3,k)*math.comb(3-k,j)*(-1)**j
factor=[F(1)]
for root in roots:
 nxt=[F(0)]*(len(factor)+1)
 for k,v in enumerate(factor):nxt[k]-=v*root;nxt[k+1]+=v
 factor=nxt
factor_power=[-4*v for v in factor];factor_power[0]+=1
ck(power==factor_power and min(bernstein_coeff)>0,'canonical_positive_Bernstein_exact_factored_identity',{})
ck(fixture_G(F(0))>2 and fixture_G(F(1))<1,'canonical_G0_gt_two_lambda_G1_lt_q',{})
for root in roots:ck(fixture_G(root)==factored_G(root)==1,'canonical_three_crossing_roots_exact',{'root':str(root)})
sign_points=[(F(1,4),1),(F(3,5),-1),(F(4,5),1),(F(19,20),-1)]
for x,sign in sign_points:ck((fixture_G(x)-1)*sign>0,'canonical_four_interval_signs',{'s':str(x)})
future_grid=[F(9,10)+F(j,1000) for j in range(1,101)]
for x in future_grid:ck(fixture_G(x)==factored_G(x)<1,'canonical_all_tested_p_after_last_crossing_are_capped',{'p':str(x)})
ck(fixture_G(F(3,5))<1<fixture_G(F(4,5)) and F(4,5)>roots[0],'canonical_early_crossing_does_not_cap_all_future',{})
ck(max(roots)==F(9,10),'canonical_last_crossing_is_nine_tenths',{})
canonical={'scope':'Exact algebra fixture only, not a full actual f/kernel or original history realization. It checks the last-crossing direction without assuming G monotone.','q':'1','lambda':'1','Bernstein_degree':3,'positive_Bernstein_coefficients':list(map(str,bernstein_coeff)),'power_coefficients':list(map(str,power)),'factored_formula':'1-4(s-1/2)(s-7/10)(s-9/10)','three_roots':list(map(str,roots)),'last_crossing':'9/10','interval_sign_samples':[{'s':str(x),'G_minus_q_sign':sign,'G':str(fixture_G(x))} for x,sign in sign_points],'future_grid':'p=9/10+j/1000,j1..100','future_grid_count':len(future_grid),'G0':str(fixture_G(F(0))),'G1':str(fixture_G(F(1))),'earlier_crossing_failure_at_p_four_fifths':str(fixture_G(F(4,5)))}
out={'status':'PASS' if not FAIL else 'FAIL','scope':'Exact conditional coefficient and finite capacity certificates only. Condition C requires same original x,L,q have full-source P_p,L*beta<=q at referencep>=actuals. This history/selector mapping is not established by these numerical tests and is never inferred from actuals FIRST. Toy matrices explicitly assume/construct C, not a full original kernel. No general root/source certificate.','lemma':'For k0>=1,p=k0/n,0<=s<=p/2,allk>=k0: b_k(s)<=r b_k(p),r=2^-k0[(1-p/2)/(1-p)]^(n-k0) ifp<1. p1 onlyk=n,r2^-n. b_k(s)=binom(n,k)s^k(1-s)^(n-k); combinatorial factors cancel in ratios. K=n is empty high-degree tail and needs no p>1.','conditional_payment':'Under C, fixed-x source aggregate of normalized tail<=r, hence pair<=r An Wnu after the hard-column envelope, without any capture probability lower bound. Toy selected masks are frozen and no unweighted component FIRST is assumed.','margin_logic':'For canonical FIRST rows, or conditional on the legacy selector bridge, actual softness is strictly above margin1-2^(-1/n). This is not an unconditional legacy-selector requirement; the legacy mapping remains unproved here. Newgate s<=p/2 is nonempty iff(1-p/2)^n<1/2, exact Fraction test. Equality is empty. Bernoulli proves margin>=1/(2n); n1 equality separately guarded.','coverage':'The coefficient algebra itself is tested without a selector-margin assumption. Initial all k0=1..n and all tailk for n1,2,4,8. Boundary n1,4,16 includes p0,p1,emptytail,s0 and strict margin equality. Expanded n64,256,1024 uses selected k0 and endpoint/interior tail degrees, not an exhaustive large grid. Original six R309 cutoff records are embedded unmodified, with k0=K+1.','cutoff_provenance':{'original_snapshot_sha256':CUTOFF_SOURCE_SHA256,'records':ORIGINAL_SIX_CUTOFFS,'runtime_dependency':'none; embedded snapshot, no old script/file read'},'serialization':'Small fractions exact; large values decimal/log10 diagnostics and canonical binary rational SHA256(sign byte,8byte numerator-length,absolute numerator bytes,denominator bytes). All decisions exact Fraction; no floating root/exp used.','canonical_last_FIRST_algebra_fixture':canonical,'check_counts':COUNTS,'failures':FAIL,'stages':[{'name':'initial_exhaustive_small_coefficients','cases':initial},{'name':'boundary_p0_p1_empty_tail_margin','cases':boundary},{'name':'expanded_selected_coefficients_and_original_cutoffs','cases':expanded,'original_cutoff_linked_cases':linked}],'positive_kernel_capacity_toys':toys}
path=Path(__file__);path.with_suffix('.json').write_text(json.dumps(out,sort_keys=True,indent=2)+'\n');lines=['# R311 conditional higher-soft FIRST certificates','',out['scope'],'',out['lemma'],'',out['conditional_payment'],'',out['margin_logic'],'','|original n|qH|original K|k0|r(n+1)|<=eta1/128?|small-s gate nonempty under canonical/conditional margin?|','|---:|---:|---:|---:|---:|---|---|']
for c in linked:lines.append(f"|{c['n']}|{c['qH_original']}|{c['K_original_unmodified']}|{c['k0']}|{float(c['r_times_n_plus1']['decimal50_diagnostic']):.8g}|{c['r_An_rational_payment_certified']}|{c['margin']['gate_nonempty_with_strict_original_margin']}|")
lines+=['',out['coverage'],'','The original higher-soft capacity C remains a hypothesis. The table is not evidence that the original selector/history supplies it; it only reports the exact consequence if supplied. No favorable replacement cutoff K is chosen. Seven finite positive-kernel/source toys test full-source reference capacity and the aggregate/pair conclusion, including p0,p1,emptytail and zero source mass.','','Canonical last-FIRST algebra fixture: G=1-4(s-1/2)(s-7/10)(s-9/10), positive degree3 Bernstein coefficients113/50,53/150,187/150,47/50. Last crossing is9/10; earlier1/2 fails to cap all future (G(4/5)>1). Factor identity, four interval signs and100 future grid points are exact. This fixture does not realize the original actual f/history.']
path.with_suffix('.md').write_text('\n'.join(lines)+'\n');print(json.dumps({'status':out['status'],'check_counts':COUNTS,'failures':FAIL,'stage_sizes':[len(initial),len(boundary),len(expanded)],'linked':[{'n':c['n'],'qH':c['qH_original'],'K':c['K_original_unmodified'],'k0':c['k0'],'rAn':c['r_times_n_plus1']['decimal50_diagnostic'],'paid':c['r_An_rational_payment_certified'],'margin_nonempty':c['margin']['gate_nonempty_with_strict_original_margin']} for c in linked],'capacity_toys':len(toys)},indent=2));assert not FAIL,FAIL
