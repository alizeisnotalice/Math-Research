# R311 — conditional higher-softness FIRST pays the actual low-p high-degree branch

## 1. Precise claim and the unresolved original-input interface

This is a conditional source receipt, not a proof of the global root bound. Keep the entire original R309/R310 input: arbitrary positive L1 beta and nu, a fixed restriction nu_*<=nu without recomputing full e_g,m or history, actual common s(x),L(x),R(x), a<=L,R<=b<=2a, q_-=3lambda/4<=q(x)<=lambda, original alpha(x,y) in [0,1], actual FIRST, SAME-R hard cap, common binary theta, and all aspect/outer costs. Write

    U_y(x)=alpha(x,y)1_E(x)P_(s(x),L(x))(x-y)/q(x),
    P_(s,L)=sum_(k=0)^n b_(n,k)(s)Q_(k,L),
    b_(n,k)(s)=binom(n,k)s^k(1-s)^(n-k),
    A_n=1+n log(b/a).

Each Q_k is the original normalized positive common-soft component. The physical L(x) is shared by the source rows at x. No source-dependent scale or softness is introduced.

Fix an integer 1<=k0<=n and p=k0/n. The ADDITIONAL response condition needed in this note is

    (HS_p)  [P_(p,L(x))*beta](x)<=q(x)
             for a.e. x in E with s(x)<=p/2.          (1)

The hypothetical assertion that the original current input has FIRST at every higher softness p'>=s(x) implies (1). The historical review found no explicit legacy-selector mapping establishing it for the actual R309 fields; hence it is not adopted unconditionally. Original selected-softness FIRST alone is not (1). The proof below must not be applied unconditionally before that interface is certified. It suffices to verify (1) on the displayed receiver subset; no cap outside it is needed.

Let V_y(x)=alpha1_E/q sum_(k>=k0)b_(n,k)(s(x))Q_(k,L(x))(x-y), and define the capturing endpoint

    V_y^small(x)=V_y(x)1{s(x)<=p/2}.

For ANY original positive pair suballocation whose capturing density is V^small, whose noncapturing endpoint remains the full original U, and whose pair mask is in [0,1], the new source payment is

    R[V^small] <= r_(n,k0) A_n W_nu*,                (2)

where

    r_(n,k0)=2^(-k0)[(1-p/2)/(1-p)]^(n-k0), p<1,
    r_(n,n)=2^(-n).                                  (3)

No lower bound on the actual capture fraction is required. The beta source is integrated once using the full higher-softness response; the hard source nu_* is charged once after all actual scales and all common theta values. No component FIRST is assumed.

The threshold and price are explicit:

    r_(n,k0)<=exp[-(log2-1/2)k0]<=exp(-k0/6).         (4)

Consequently k0>=6 log_+(A_n/zeta) is a sufficient condition for a zeta W_nu* source price. In particular k0>=3 log A_n gives sqrt(A_n) W_nu*. These conditions are not presumed for the inherited cutoff; when they fail the exact price in (2),(3) remains. If the required k0 exceeds n there is no permitted cutoff satisfying that sufficient condition.

## 2. Exact coefficient comparison, including the endpoint p=1

Suppose p<1 and 0<s<=p/2. For k>=k0,

    b_(n,k)(s)/b_(n,k)(p)
       =(s/p)^k[(1-s)/(1-p)]^(n-k).                  (5)

The ratio at k+1 divided by that at k equals s(1-p)/(p(1-s))<=1. Thus the largest ratio occurs at k=k0. At k0=np, the derivative of the logarithm with respect to s is

    k0/s-(n-k0)/(1-s)=n(p-s)/(s(1-s))>=0.

It is therefore largest at s=p/2, giving (3). At s=0 every k>=k0 coefficient is zero, so the inequality holds without using log s. No binomial multiplicity is lost: the same binomial coefficient cancels in (5), and Q_k remains the normalized average over coordinate sets.

For p=1 necessarily k0=n, and the retained sum has ONLY k=n. Directly b_(n,n)(s)=s^n<=2^(-n)=r b_(n,n)(1). There is no division by b_(n,k)(1)=0 for k<n and no assertion about those degrees.

For p<1, (3) also equals exp[-n D(p||p/2)]. To prove (4), use log(1+u)<=u with u=p/[2(1-p)]:

    nD(p||p/2)
       =np log2-n(1-p)log[(1-p/2)/(1-p)]
       >=np(log2-1/2)=k0(log2-1/2).

The p=1 endpoint satisfies the same weaker lower bound. Finally log2>2/3 follows from

    log2=2 integral_0^(1/3) dt/(1-t^2)>2/3,

so log2-1/2>1/6. This proof retains the genuine common softness and does not maximize softenings independently by coordinate.

A useful exact refinement, requiring the same cap at p, is available on any subset s(x)<=p. Replace r by

    r_p(s)=(s/p)^k0[(1-s)/(1-p)]^(n-k0), p<1,
    r_1(s)=s^n, p=1.                                 (6)

Then the aggregate response is bounded by r_p(s(x)), and the receipt is the actual weighted column integral in (10) below with that coefficient. Equation (2) is the uniform and directly source-priced consequence for s<=p/2. Formula (6) gives no uniformly small price as s approaches p.

## 3. Full-source response, then the actual pair integration

Positivity and (5), including the endpoint convention, give on the small-softness set

    sum_(k>=k0)b_(n,k)(s)Q_(k,L)(x-y)
       <=r sum_(k>=k0)b_(n,k)(p)Q_(k,L)(x-y)
       <=r P_(p,L)(x-y).                             (7)

All alpha and source/history qualifications are retained in the component being priced. Dropping only alpha<=1 in a positive upper estimate and integrating the ORIGINAL beta gives

    f_small(x):=integral V_y^small(x)beta(dy)
       <=r 1_E1{s<=p/2}[P_(p,L(x))*beta](x)/q(x)
       <=r 1_E1{s<=p/2}.                             (8)

Thus the operative FIRST is a full kernel cap after beta integration, not a fictitious cap on Q_k or on a reweighted beta. Receiver-dependent alpha causes no difficulty because it is bounded by one; it need not factor by source or be frozen in x.

Here is the exact original pair interface. At each common theta, use the unchanged full row

    J_y(t)=integral_{R(x)<=t}U_y(x)dx,
    sigma_theta(x,y,z)<=1{z in Q_(R(x))(x)},
    chi_theta=1{J_y(t)>=H,p_theta<7/8},
    ell_n(dt)=b^(-n)delta_b(dt)+n t^(-n-1)1_(a,b)dt.

For any original prefix qualification I in [0,1] and original M in [0,1], the component is

    integral beta(dy)nu_*(dz)ell_n(dt) chi_theta I/J_y(t)
      integral_{R(w),R(u)<=t} V_y^small(w)sigma_theta(w,y,z)
           U_y(u)[1-sigma_theta(u,y,z)]M dwdu.         (9)

A zero row is assigned zero; H>0 makes chi zero there. The full bad prefix is bounded by J, without modifying it in (9). Drop chi,I,M only in this positive upper bound. Tonelli and the inclusive tail identity ell_n([R(w),b])=R(w)^(-n), including the atom at b, show (9) is at most

    integral beta(dy)dw V_y^small(w)
          R(w)^(-n) integral sigma_theta(w,y,z)nu_*(dz)
       <=integral dw f_small(w)[h_(R(w))*nu_*](w)
       <=r integral_{E,s<=p/2}[h_(R(w))*nu_*](w)dw.    (10)

The source/history dependence of sigma is safely dominated by its SAME actual hard cube before applying (8). The actual same-R cap implies the integrand response is at most 4lambda on E, but the finite source price instead uses the hard-scale envelope

    integral sup_(a<=R<=b) h_R(x-z)dx=A_n.

Tonelli in z gives (2). The common theta average has total weight one, so the same receiver potential and single source price work for all theta. All operations are nonnegative and measurable; standard truncation and monotone convergence handle infinite receiver domains. In fact the right side is finite for finite W_nu*. The actual dx and selected L,R have never been replaced in the component being paid.

The explicit shared receiver potential after beta aggregation is

    P_r(x)=r 1_E(x)1{s(x)<=p/2}[h_(R(x))*nu_*](x),
    integral P_r<=r A_n W_nu*.                       (11)

This is an aggregate response certificate. It does NOT assert the false rowwise inequality V_y^small<=r U_y; the two soft kernels have different shapes. The proof needs (8), followed by (10), rather than a per-row posterior comparison. No new source copies, per-degree selector, or per-band charge occur.

## 4. Exact entry into the inherited remainder, and the unpriced complement

Use precisely the R310 ledger, with the rational original R309 gate

    Gamma={n s(x)>=28(K+7)/5},
    R_rem=R_lowp(U_hi)+R_allp(U_lo 1_(Gamma^c)).        (12)

Here K is the inherited R308 cutoff, U_hi uses degrees K+1,...,n, and every functional uses the same full bad endpoint, J, M and all original qualifications. This is not a substitution of the sharper CDF gate into an already fixed residual.

If K<n set k0=K+1, p=(K+1)/n, S={s<=p/2}. Under (HS_p), split exactly

    R_rem=R_lowp(U_hi 1_S)
         +R_lowp(U_hi 1_(S^c))
         +R_allp(U_lo 1_(Gamma^c)).                   (13)

The first term is newly paid by r A_n W_nu*. The other two terms are unchanged. If K=n, U_hi=0 and this receipt is unnecessary; setting k0=n+1 would be illegal.

The R309 target entry therefore becomes, conditionally,

    Lambda T <=(4096/5)Lambda lambda d W_beta
       +(128/5)Lambda r A_n W_nu*
       +(128/5)Lambda[
          R_lowp(U_hi 1_(S^c))+R_allp(U_lo 1_(Gamma^c))]. (14)

The original d=kappa0 psi_inf/(q_-v0), kappa0=2K_orig/(ell M), all aspect costs, outer integration and other ledger slots are retained. The source receipt is inside that outer integral. A favorable r does not repair an already large lambda d or establish a missing global target entry.

This connects to R309 as follows. Its low-degree/high-actual-softness receipt has ALREADY been used to obtain (12); it cannot be charged again here. The new small-softness high-degree receipt uses a different positive component. The two estimates do not cover the whole softness axis: high-degree low-p capture for s>(K+1)/(2n) remains, including arbitrarily large s, while low-degree capture still remains on Gamma^c. In particular there is a middle interval between the small-softness threshold and the R309 sufficient large-softness threshold. There is no claim that either shared coefficient comparison or posterior bound is small throughout that interval.

The R310 depth and endpoint payments can be retained on their exact previously assigned low-degree subsets. Applying (13) to the disjoint high-degree component does not duplicate their beta fees. No degree cutoff is enlarged merely to satisfy (4); that would change the inherited R308 split and would require redoing its ledger.

## 5. A quantified certificate defect when higher-softness FIRST is not known

There is an exact way to expose, rather than hide, the missing response qualification. Define the actual higher response and its excess only on S:

    F_p(x)=[P_(p,L(x))*beta](x)/q(x),
    Delta_p=integral_{E intersect S}
         [h_(R(x))*nu_*](x)(F_p(x)-1)_+ dx.           (15)

The SAME proof before the last inequality of (8) gives unconditionally

    R_lowp(U_hi 1_S)<=r[A_n W_nu*+Delta_p].            (16)

Indeed f_small<=rF_p. Original selected FIRST also gives f_small<=1, so the more accurate, still unconditional certificate is

    R_lowp(U_hi 1_S)
       <=integral_{E intersect S}[h_R*nu_*](x)
                    min(1,rF_p(x))dx.               (17)

There is also an unconditional, directly checkable receiver-subset receipt. For any B>0 fixed within the original outer instance set

    C_B={x in E: F_p(x)<=B}.

Keep the original capturing density and restrict it to S intersect C_B. Its original positive pair component satisfies

    R_lowp(U_hi 1_S 1_(C_B))<=r B A_n W_nu*.          (18)

This follows from f_small 1_(C_B)<=rB and the same actual hard-column integral, without (HS_p). The exact high-degree remainder splits into

    U_hi 1_(S^c) + U_hi 1_S 1_(C_B^c)

at the capturing endpoint. Thus a reader with actual source data can test the same-L higher response and use (18) on that subset, while keeping ALL traffic on F_p>B. Choosing B=zeta/(r A_n) gives a zeta source price for this particular subset, but does not assert the subset is large or nonempty. In the target inequality the fee is (128/5)Lambda rB A_n W_nu*, with the two displayed high-degree complements and the entire original low-degree remainder retained. This is a concrete response-cap interface, not an inference of unknown source density or a proof that the complement has a root budget.

These are original receiver integrals, not recomputed pair masses. They identify the precise additional source-response estimate needed if the historical mapping fails. They are not claimed as a new root payment without controlling Delta_p. The elementary bound P_(p,L)<=a^(-n) (h,phi<=1) gives

    Delta_p<=A_n W_nu* [W_beta/(q_-a^n)-1]_+,

which may be very large and is NOT a root closure. Thus nothing in this note silently infers (HS_p) from selected FIRST, nu<=beta, source density, or a component cap. The conditional improvement is real once (1) is certified; the original-input applicability remains an explicit unresolved hypothesis at this freeze.

## 6. Executed finite diagnostics

The embedded standard-library Fraction script checks three stages: small dimensions and zero/end softness; boundary degrees including p=1; and larger exact-rational dimensions. It verifies every retained coefficient inequality, monotonicity in degree, the uniform response implication for finite positive kernel-component mixtures, and the selected-FIRST/excess minimum algebra. These are finite coefficient/response checks, not certification of the historical higher-softness hypothesis or a global geometric theorem. A fresh isolated Python process returned PASS for 1767 coefficient comparisons, 1683 degree-monotonicity comparisons, 84 aggregate-response checks, 140 excess/minimum checks, 27 p=1 endpoint checks and 224 receiver-gate checks; the script writes no files.

```python
from fractions import Fraction as F
from math import comb
ct={'coefficient':0,'degree_monotonic':0,'aggregate_response':0,'defect_minimum':0,'endpoint_p1':0,'receiver_gate':0}
for dims in ((1,2,3),(4,8,16),(32,64,128)):
 for n in dims:
  ks=sorted(set((1,max(1,n//4),max(1,n//2),n)))
  for k0 in ks:
   p=F(k0,n)
   r=F(1,2)**n if p==1 else F(1,2)**k0*((1-p/2)/(1-p))**(n-k0)
   for theta in (F(0),F(1,8),F(1,2)):
    s=theta*p
    old=None
    retained=[]; higher=[]
    for k in range(k0,n+1):
     bs=F(comb(n,k))*s**k*(1-s)**(n-k)
     bp=F(comb(n,k))*p**k*(1-p)**(n-k)
     assert bs<=r*bp;ct['coefficient']+=1
     ratio=bs/bp
     if old is not None:
      assert ratio<=old;ct['degree_monotonic']+=1
     old=ratio
     weight=F(1+(k%5),1+(k%7))
     retained.append(weight*bs);higher.append(weight*bp)
    full=sum(higher)+F(1,7)
    actual=sum(retained)
    assert actual/full<=r;ct['aggregate_response']+=1
    if p==1:
     assert retained[0]/higher[0]==s**n if higher[0] else retained[0]==0
     ct['endpoint_p1']+=1
   for Fp in (F(0),F(1,2),F(1),F(2),F(100)):
    val=min(F(1),r*Fp)
    assert val<=r*(1+max(F(0),Fp-1))
    if Fp<=1:assert val<=r
    ct['defect_minimum']+=1
    for B in (F(1,4),F(1),F(4)):
     if Fp<=B:
      assert val<=r*B;ct['receiver_gate']+=1
print('PASS',ct)
```

Only /tmp/r311_geometry.md is owned and modified for this task. No other author's file or Git state is changed.
