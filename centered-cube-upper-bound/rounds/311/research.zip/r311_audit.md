# R311 independent preauthor audit

Independent screen saved before reading new R311 author proofs. Conditional proposition PASS; historical selector applicability remains a separate obligation. Own file only; no Git/repository or other-author modifications.

## Exact coefficient comparison

Fix integer 1<=k0<=n, p=k0/n, independently of actual receiver/source selection within the outer instance. On 0<=s<=p/2 and p<1, actual degree coefficients satisfy

b_nk(s)/b_nk(p)=(s/p)^k[(1-s)/(1-p)]^(n-k).

For fixed s<=p/2 the ratio is nonincreasing in k; for k>=k0 it is nondecreasing in s up to p/2, since its logarithmic derivative has sign k-ns>=0. Hence for every k>=k0 it is bounded by

r=2^(-k0)[(1-p/2)/(1-p)]^(n-k0).

Because (n-k0)ln[1+p/(2(1-p))]<=k0/2, r<=exp[-(ln2-1/2)k0]. This is the exact Chernoff/relative-entropy expression exp[-n D(p||p/2)]; no asymptotic estimate is used. At p=1 separately, k0=n and only degree n survives; s^n<=2^(-n), and the pure-soft P_1 is exactly Q_n. At s=0 all positive degrees vanish. No division by zero or 0^0 ambiguity is needed.

Thus sum_(k>=k0)b_nk(s)Q_k,L <=r P_p,L pointwise. This uses the SAME physical L and the actual common s, and is a positive whole-kernel domination. It is not an independently granted component FIRST.

## Conditional actual traffic payment and quantifiers

Assume at each original receiver x on the branch that the ORIGINAL source beta satisfies P_(p,L(x))*beta(x)<=q(x) whenever actual s(x)<=p/2. The stronger condition C for every softness >=s is sufficient but only this single p cap is used. With 0<=alpha(x,y)<=1, beta integration gives integral_beta U_hi(x,y)1_small_s<=r. Preserve original source restrictions, full bad U, J, missed-capture, M, prefix/history gates and common theta before positive domination. Any positive original pair suballocation with combined M<=1 is bounded by its actual capturing target through bad-prefix integral<=J and ell([R,b])=R^(-n). Then integrate beta FIRST and retain the SAME receiver hard scale R(x), shared across y:

R_highdegree,small_s <=r integral_E h_(R(x))*nu_*(x)dx <=r A_n W_(nu_*).

The last step is the full hard-scale positive envelope; no selected-scale hard cap or factor 16/3 is needed for this source-nu receipt. Receiver extension occurs after beta integration. If R depended on y, this exact factoring would require a separate argument; it is valid for the stated original receiver field. No capture-probability lower bound, density hypothesis, nu<=beta hypothesis or new FIRST is introduced. Original q(x) may vary because the raised-softness cap uses the SAME q(x) before division. k0=K+1 connects to R309 low-p high degree for K<n; K=n makes that high-degree component zero, without defining p>1. Original Lambda/residual coefficients and outer integration still apply once.

The conclusion is CONDITIONAL until the actual s(x),L(x),q(x),beta identities are linked to the historical all-higher-softness FIRST. A generic abstract selected-response cap alone does not imply C.

## Important R310 applicability correction if that mapping holds

For every n>=1, Bernoulli gives (1-1/(2n))^n>=1/2. Therefore 1-2^(-1/n)>=1/(2n), with equality only at n=1. The original strict margin sigma>1-2^(-1/n), IF actual s=sigma is established, implies actual s>1/(2n). R310 chose s0=min(1/(2n),3eta/(16A_n n)), so its ENTIRE tiny-softness event s<=s0 is empty on that original retained event, for every eta>0. The endpoint lemma remains correct as an abstract source payment, but cannot be advertised as a nonempty additional original branch under this mapped margin. Its combined-height corollary must accordingly be interpreted with an empty endpoint part; the deep-depth payment itself is unaffected. No inference about full general theorem closure follows.

## Actual bounded diagnostics

{'coefficient_domination': 3600, 'hard_margin_Bernoulli': 7, 'rate_bound_mp50': 66}

Executed exact Fraction coefficient tests and Bernoulli margins, plus ordinary 50-digit logarithmic comparisons. All PASS. These finite diagnostics support the analytic inequalities above, not the unresolved historical mapping or a root estimate for the remaining original traffic.

## Author and historical-interface comparison

After the saved independent screen, read the current R311 geometry and selector-bridge notes. PASS in their explicitly conditional scope. The author separates HS_p from selected actual-softness FIRST, keeps p=1/k0=n and K=n endpoint conventions, proves the rate with ln2>2/3, and uses the same actual receiver field L(x),R(x),q(x). Its aggregate response f_small<=r precedes receiver hard-scale integration; no false per-source inequality U_hi<=rU is claimed. The common theta and source-nu fee occur once. The exact high-degree complement s>p/2 and original low-degree remainder remain.

The refinement for s<=p and the unconditional defect receipts are valid: f_small<=min(1,rF_p) under selected FIRST, hence R<=integral h_R*nu min(1,rF_p)<=r[A_n Wnu+Delta_p]. The height bound P_p,L<=a^(-n) gives the displayed coarse finite-mass defect bound, but not a root price. A favorable r alone does not control this defect or original lambda d.

Directly inspected UNCUT_FIRST_LEDGER.md section 1: it asserts original global FIRST, all higher softness/all-octave caps at the common q and strict sigma>1-2^(-1/n), exactly on that ledger's own retained original rows. The selector-bridge note keeps event identity, actual softness ordering/equality, common q identity and beta<=f provenance as separate necessary connectors; it correctly refuses to reselect old L/s while reusing history/e_g/m gates. Its conclusion that the R310 endpoint is conditionally empty under that connector matches the independent Bernoulli proof above. I do not claim a complete archival search proves nonexistence of any additional connector; the bounded claim is that no connector is certified by the inspected interfaces.

Current provisional byte bindings (to be superseded if authors freeze changed bytes):
- /tmp/r311_geometry.md: 68d73c7f3379a69b6f315796d8ed55374cea8c19752a0b8c4067930ed7be7282
- /tmp/r311_selector_bridge.md: 746c0616088caa4f8b85105ef3a1bbe752cb845229266b64c3224d1a1264c4af

## Additional canonical-FIRST construction: independent screen before its new proof

The parent's explicitly NEW original-f construction passes. Let fixed f>=0 be L1, 0<a<=b<infinity, and common q in [3lambda/4,lambda]. With the true h/phi profiles bounded by one, (x,s,L)->P_(s,L)*f(x) is jointly continuous: dominated convergence uses a^(-n)f(y), and the only hard-profile discontinuities at a given limit are a finite union of dy-null cube faces. Taking a compact scale maximum gives continuous G_s(x). On Ecan={2lambda<G0<=4lambda,G1<q}, the closed set {s:G_s>=q} is nonempty, contains a positive neighborhood of zero, and is disjoint from a neighborhood of one. Its maximum sigma lies in (0,1); continuity gives G_sigma=q, and G_p<q for every p>sigma.

On Ecan, {sigma>=t}={max_(s in [t,1])G_s>=q} for t in [0,1], so sigma is Borel (extend arbitrarily outside Ecan). The function F(x,L)=P_(sigma(x),L)*f(x) is Borel in x and continuous in L. Its compact argmax is nonempty; the smallest maximizing L* is Borel by the proposed countable restricted-maximum formula, using only intervals with upper endpoint>=a. Equality to q is legitimate because max F=q on Ecan. This covers strict scale endpoints and a=b as well.

At a hard winner L0, positivity gives q=G_sigma>=(1-sigma)^n G0>2lambda(1-sigma)^n. Thus q<=lambda implies sigma>1-2^(-1/n)>=1/(2n). For beta,nu<=f, all higher-softness/octal-scale response caps and hard caps follow by positivity at the SAME new native receivers; the conditional R311 theorem is unconditional within this newly defined row family. Any qualifications and pair allocations must be defined on that family without transferring old masks. The construction is not proof that the legacy R310 actual s/L/q, history, e_g/m or target entry equals this family. The excluded G1>=q endpoint is outside this construction; its prior payment must be separately connected before any complete ledger claim.

No new author proof for this canonical construction was read before this screen was appended.

## Native canonical-FIRST author comparison

Read r311_canonical_first.md after the independent construction screen above. PASS. The proof supplies joint continuity via dy-null hard faces and integrable domination, continuous compact maxima, Borel last crossing without assuming monotone softness response, and Borel minimum physical argmax with endpoint conventions. It derives the hard margin and labels R310 tiny-s empty on THESE native FIRST rows. It grants higher-softness response caps to sources dominated by the same f, retains actual receiver/source data, and explicitly does not identify this construction with the legacy R310 target or repair its global reduction/endpoint/history connector. Conditional R311 payment is therefore unconditional on this newly specified native family, while legacy application stays conditional.

The final geometric note additionally gives a legitimate unconditional actual subset C_B={F_p<=B} at the capturing receiver: on S intersect C_B its aggregate response<=rB, so its source fee is rB A_n Wnu. The exact complements S intersect C_B^c and S^c high-degree plus original low-degree remainder must remain. Choosing B=zeta/(r A_n) prices only that subset; it asserts no lower coverage or root estimate for its complement.

The inspected numeric note tests exact coefficient/capacity algebra, finite source-response toys and conditional canonical-margin gate arithmetic. It does not certify the legacy selector/history mapping. I requested that its one unqualified sentence about 'original actual softness' explicitly attach the canonical-family/legacy-bridge condition, to match its otherwise correct scope. No mathematical correction to the coefficient or gate test is required.

Current additional author bindings:
- /tmp/r311_geometry.md: 68d73c7f3379a69b6f315796d8ed55374cea8c19752a0b8c4067930ed7be7282
- /tmp/r311_selector_bridge.md: 09b9f86cc9a82a2b78a045854b13473431c6383cea5cd055a29105ec709fd614
- /tmp/r311_canonical_first.md: 9919c171414c5b51427b484f039d60c8a4fb8b1c78d9cfd5fe7a457c7dfa820c

## Final integration review

Read final combined note, README and TeX source without compilation. PASS for ledger formulas and explicit scope. Starting from the already assigned R310 residual, the new paid subset is ONLY R1|Zc,S,C_B. At K<n use k0=K+1; K=n has no R1. The exact unpriced allocation is

R1|Zc,S^c + R1|Zc,S,C_B^c + R2|Zc,E_b<=D.

The new source charge is (128/5)Lambda rB A_n W_(nu_*), once. All previously assigned beta fees and original outer/scale/time/entry ledger terms remain; no new epsilon X is created. Under an actually proved HS_p, B=1 and the second high-degree complement vanishes; it is not deleted unconditionally. Canonical native input and legacy historical target are repeatedly distinguished. The correction to R310 is explicit: its abstract endpoint lemma is correct, but on the newly constructed genuine FIRST rows its tiny-s event is EMPTY; it must not count as a substantive new nonempty original branch there.

The final numeric note now explicitly restricts the actual-softness margin to canonical rows or a certified legacy bridge. The exact nonempty-parameter criterion is correct but says nothing about realized traffic coverage. Its positive degree-3 Bernstein/three-crossing fixture is algebraic, not an original kernel/history realization. The four favorable conditional cutoff prices out of six keep the inherited K and do not establish the missing capacity.

Evidence: this auditor executed 3600 Fraction coefficient cases, 7 Fraction margin checks and 66 ordinary 50-digit rate comparisons as recorded above. The parent reports separate-process fresh reruns of the final author 3925 exact checks and independent numeric 2015 exact checks, with numeric JSON byte equality. The inspected final JSON is PASS with total 2015; author totals 1767+1683+84+140+27+224=3925. These finite tests do not certify original selector/source history or any general root bound. No tests were needlessly repeated at final integration.

The final outstanding TeX clarification requested is to state the physical L,R and q range and M<=1 used by its hard-envelope step; the detailed author proof already has these hypotheses. Final byte receipt below records the resolved version.

Final TeX clarification verified: physical 0<a<=L(x),R(x)<=b<=2a, q_-=3lambda/4<=q(x)<=lambda, M in [0,1], and full bad/J are now explicitly retained. No mathematical correction remains. Final bounded verdict PASS, conditional/native scopes only; audit FROZEN.

### Final byte bindings (supersede intermediate bindings)
- /tmp/r311_geometry.md: 68d73c7f3379a69b6f315796d8ed55374cea8c19752a0b8c4067930ed7be7282
- /tmp/r311_selector_bridge.md: 09b9f86cc9a82a2b78a045854b13473431c6383cea5cd055a29105ec709fd614
- /tmp/r311_canonical_first.md: 9919c171414c5b51427b484f039d60c8a4fb8b1c78d9cfd5fe7a457c7dfa820c
- /tmp/r311_combined.md: c6fe963ba88c05a07c47e3b2fec85017877a702c3e74b1a98255d887192badc2
- /tmp/r311_README.md: ab824192ca202920d5111a76c2588095323d4e2ea5694ac9e08853f8007c5c50
- /Users/zhengzhihao/Desktop/T/output/centered_cube_round311_20261018_final_checkpoint/research.tex: 79b7603726d2de7aa3c2eb900e00510bb0073ad34cbbc9195145f760a64c5555
- /tmp/r311_numeric.py: 8cd4fdc9c90e3b9f80001dd580ab911f37228c5e9e68a6e85148fbd7e923752a
- /tmp/r311_numeric.json: 5f5d02a2977978f974297198832eca333466351471229de339d4a93bdb373276
- /tmp/r311_numeric.md: 1da1075b57929ee734ab2fefcb1df541e6a7ff13f7c9ae30c2ee64c5163d7c28
