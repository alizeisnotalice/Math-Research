from fractions import Fraction as F
from math import comb
ct={'coefficient':0,'degree_monotonic':0,'aggregate_response':0,'defect_minimum':0,'endpoint_p1':0,'receiver_gate':0}
for dims in ((1,2,3),(4,8,16),(32,64,128)):
 for n in dims:
  ks=sorted(set((1,max(1,n//4),max(1,n//2),n)))
  for k0 in ks:
   p=F(k0,n)
   r=F(1,2)**n if p==1 else F(1,2)**k0*((1-p/2)/(1-p))**(n-k0)
   for theta in (F(0),F(1,8),F(1,2)):
    s=theta*p
    old=None
    retained=[]; higher=[]
    for k in range(k0,n+1):
     bs=F(comb(n,k))*s**k*(1-s)**(n-k)
     bp=F(comb(n,k))*p**k*(1-p)**(n-k)
     assert bs<=r*bp;ct['coefficient']+=1
     ratio=bs/bp
     if old is not None:
      assert ratio<=old;ct['degree_monotonic']+=1
     old=ratio
     weight=F(1+(k%5),1+(k%7))
     retained.append(weight*bs);higher.append(weight*bp)
    full=sum(higher)+F(1,7)
    actual=sum(retained)
    assert actual/full<=r;ct['aggregate_response']+=1
    if p==1:
     assert retained[0]/higher[0]==s**n if higher[0] else retained[0]==0
     ct['endpoint_p1']+=1
   for Fp in (F(0),F(1,2),F(1),F(2),F(100)):
    val=min(F(1),r*Fp)
    assert val<=r*(1+max(F(0),Fp-1))
    if Fp<=1:assert val<=r
    ct['defect_minimum']+=1
    for B in (F(1,4),F(1),F(4)):
     if Fp<=B:
      assert val<=r*B;ct['receiver_gate']+=1
print('PASS',ct)
