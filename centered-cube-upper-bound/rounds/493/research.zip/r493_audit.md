# R493 独立终审

FINAL PASS（限定范围）。认证连续协调分配的精确值／缺额与固定输入达到性、同一真实 p-stop 的大族质量尾，以及放大终端分析帽后的全局厚来源接口与式 M 回代。不认证厚来源 all-cut 根价、完整累计停止付款或一般弱型目标闭合。

独立 PRE 在作者阅读前形成并保留。连续定理适用于任意 d>0、非负 L¹ 核：有限 product 条件逼近、有限网络残量割、来源格占比的凹角点和两侧 L¹-Lipschitz 传递均正确。截流 min(a_n,k) 保原边缘约束及真实支持，最优误差≤2ε_n。primal 以 L∞(kρμ) 弱星紧性达到；有界函数对偶的正部积分弱星下半连续，阈值 coarea 得固定输入最优 cut。没有把集合族当作紧集，也没有主张外参可测最优选择。零来源、零核与 Λ=0 的退化范围保留。

tail 先将保 lower 配置的实际 Γ_j 投影上放到 a_j M，才用自然 PPP 指数式；实际成功后的条件律没有被替换。跳跃≤1及真实中心 CDF 给均值 c0=rS/T，Σa_j 的深度仅进入 z*=2c0+log(𝔡/ε_tail)。所得坏 p-stop 质量≤ε_tail R 对所有有限时域一致，极限由非负收敛通过，不能用于未控加权函数。

新 k*=2(1+z*)1_union/G 只扩大终端分析边帽，行帽 d=1 的调用合法；good 上它支配2π_B密度，未继承旧自然列帽一。坏 cut 缺额每条至多1，所以不乘M*。geometry式(9)的双边正部比较成立，仅作非主用辅助，没有重复收费。对 good 的全局 cut 用同一 μ-可测 D，max-flow 值≤ΛW、缺额≤Δ_thick，故主稿 (1−η_rec−2ε_tail)R≤2M(e)+2ΛW+2Δ_thick 及其后续吸收分母正确。Δ_thick 仍含累计实际停止权，不等于初始 ν 的需求；原入口倍数、初始一次价格及旧未付项目保留。

实际独立隔离重放 geometry 12项 Arb、proof 21项有理、numeric 238项精确断言，共271项通过，stdout 与冻结 replay 一致。numeric JSON 仅删除 compute_index.seconds 后全字段一致，canonical SHA256 为 `069aeb8b9a6969b8e23a80d54713325bade3f951b53f43461d43fe46327ee94a`。五个固定有限LP的全部32个来源子集cut与有理重构流零gap；HiGHS仅找候选，不承担认证。有限区间支持／离散记录没有原 Γ、连续接收场或 history 资格，不外推一般几何。

## 冻结输入 SHA256

- `r493_main.md`: `a91d4ad4f443e7f1bf7a92829d2b43c17fac43e007379cd1a340a617083cbabd`
- `r493_geometry.md`: `1b1657cd9f19f957a0f843366c2547ff65264bbb7c1cfa56726d9228e8531a3e`
- `r493_proof.md`: `aac449b90ea22ae46b7394beb70364de15af487c48ffedce2beffacebfa35ca3`
- `r493_numeric.md`: `10e7afa39fd353e3959da097fc9cd79f0f7b76985620c816db2660b86d044b64`
- `r493_numeric.py`: `39404282b4a9942237ec0e1137c07e03614ac2564ae4bd19e2be9e4890e14271`
- `r493_numeric.json`: `c4a611fcf9a3340c289fcc073f31e5a3010a11fa589c1fc2e7b570f04c8fe61d`
- `r493_replay.json`: `358f56ae5cb44d0c0d7bcfa1e1d5cf8b7a0bd60d7c59b4622d61b34646dc18b0`
