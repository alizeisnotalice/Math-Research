# 第493轮：协调来源分配、真实停止大族尾与累计厚来源缺口

## 目标与原合同

目标仍为任意正 L1 输入的一般中心立方体弱型 n^(1/2+o(1)) 上界，尚未证明。本轮沿第486轮自然配置链 P=JH，使用第491轮近线性 p 次停止恢复及第492轮整族来源接口，不更换原静态接受流或旧父链 K。mu=f dx，W=||f||1；真实中心 sigma=q_A dA，nu=t sigma，0≤t≤S，R=nu(E)，X=sigma(E)。原比例带 a≤R_A≤b≤2a、q≤q_A≤lambda、r=lambda/q、质量原子mark、原阶段与历史均保留。零流按零处理。

使用实际有限记录测度
\[
 d\Gamma_j=q_j(s)\mathsf M(ds)J^{\rm rec}(s,d\omega)
 H(\omega,ds')q_{j+1}(s')^{p-1}e(s'),
\quad \rho=\sum_{j\ge0}\Gamma_j,
\quad |\rho|=A_p-\mathsf M(e)\le R.
\]
这里 q_j=(P*)^j1，e=1−J1，A_p=sum_j ∫q_j^p e。初始 M(e)单列。R491的参数选择给 (1−eta_rec)R≤2A_p，p−1的倒数仅有对数损失。新的来源只是末端辅助分配，不改变J、H或停止权，不赋予它原双来源的历史。

## 两项本轮结论

第一，有限记录与来源测度下，任意非负可积边核 k、常数行帽d>0、来源列帽Lambda≥0的最大可分配量，等于所有可测来源集合D的精确cut下确界：
\[
 V=\inf_D\left[\Lambda\mu(D)+\int\min\{d,\int_{D^c}k(\omega,z)d\mu(z)\}\,d\rho\right].
\]
证明采用有限乘积分割、L1核误差的两侧Lipschitz稳定性及弱星紧性；最优流达到，有界函数对偶与阈值分解还给最优cut。没有引用未经核验的无限维Farkas。有限最优流需截到真实核，损失至多L1误差，不能逐行免费归一化。详见proof稿。

第二，在同一真实停止记录上，令成功族总质量G_F=sum_C m_C、最大父B。自然最大父参考下 raw lower总质量比的Poisson指数矩，由真实中心CDF控制；先投影实际记录并用Palm支配，再使用自然PPP公式，不能反过来认定成功条件下仍是PPP。记
\[
 c_0=rS/T,\ b_0=2rS/T<1,\quad
 \mathfrak d=\lceil\sqrt n/\log(1/b_0)\rceil+(1-b_0)^{-1},
 \quad z_*=2c_0+\log(\mathfrak d/\varepsilon_{\rm tail}).
\]
全部代数合计有
\[
 \rho\{G_F>(1+z_*)m_B\}\le\varepsilon_{\rm tail}R.
\]
其证明保留实际下一状态停止权，正上放到1仅用于该指数尾；深度因子放入阈值的对数内。此为已支付的坏支质量，不是仅有单代小概率。参数固定时 z*=O(log(n+2))。详见geometry稿。

## 整体cut接口与母账

设good为上述坏支的完整补集。取新终端边帽
\[
 k^*=2(1+z_*)1_{U_F}/G_F,
 \qquad U_F=\bigcup_{C\in F_0}Q_C,
\]
行帽d=1。它可积，且低Gram给局部行容量至少1；good上 k*≥2 1_QB/m_B。该新帽不继承旧单代来源列帽。定义仍待估计的真正全局厚来源缺额
\[
 \Delta_{\rm thick}(\Lambda)=\sup_D
 \left[\int_{\rm good}(2\pi_B(D)-1)_+\,d\rho-\Lambda\mu(D)\right]\ge0.
\]
所有D均为mu可测，保持同一实际rho。连续分配定理用于good记录、d=1，给
\[
 A_p^{\rm good}\le\Lambda W+\Delta_{\rm thick}(\Lambda),
\]
从而严格恢复
\[
 (1-\eta_{\rm rec}-2\varepsilon_{\rm tail})R
 \le2\mathsf M(e)+2\Lambda W+2\Delta_{\rm thick}(\Lambda). \tag{M}
\]
这不是厚来源缺额已付的声明。新帽只进入允许的终端分配，坏支费用没有被乘以对数；若日后比较别的加权积分，须另算权重损失。

原一次停止账仍为
\[
 \mathsf M(e)\le c_{\rm fail}X+\kappa T N_{\rm band}W,
 \quad c_{\rm fail}=\tau+\delta_{\rm succ}S+4rS^2/T+S^2b_n/T,
\]
其中T=1024rS²/(tau delta_succ)，tau≤S，delta_succ≤1/4，b_n≤3^(−n)，kappa=8log(4/delta_succ)，N_band≤1+[log r+n log(b/a)]/sqrt n。不将此一次价逐代累加。

足够但尚未证明的几何目标是，同一rho上对所有D有
\[
 \Delta_{\rm thick}(\Lambda)\le aR+\epsilon_{\rm cut}X+B_n,
 \quad \Lambda=O(\sqrt n\log^A(n+2)),\quad
 B_n=O(\sqrt n\log^A(n+2)W).
\]
若它成立且d0=1−eta_rec−2epsilon_tail−2a>0，则(M)给
\[
 R\le\frac{2(c_{\rm fail}+\epsilon_{\rm cut})}{d_0}X
 +\frac{2}{d_0}\{\kappa T N_{\rm band}W+\Lambda W+B_n\}.
\]
这是条件回代，不能充当几何证明。全入口还乘 M_entry=64(128/119)(1−32delta_old−16eta_old)^−1；局部吸收必须先除该乘数。原初始、跳跃删除、未来被删来源、宽距离、低强度、极端比例、全尺度及各旧槽仍保留各自未付状态。本轮没有宣称这些槽同时完成。

## 对新收到第486轮后建议的处理

已全文阅读用户文件《Pro_486轮后联合估计攻坚建议_20261021.md》。它提供建议而非新指令或已认证定理。其E1逐代平方耗散与H2高捕获短窗界已被第490—491轮的后续推导覆盖，不再重复作为新成果。其B1—B2真实停止测试/平方来源预算仍属待证桥，保留为互补机制；本轮的终端协调分配不声称自动构造了该测试。第481轮来源—位移路线继续作为独立备选，不与P链混用。该文件强调真实累计权、一次与累计的区别、来源重复及完整母账，已落实到(M)及Delta_thick的量词中。

## 本机检验、边界与下一步

使用指定独立Python环境。proof中21项Fraction断言；geometry中12项192位Arb阈值算术；numeric中238项精确断言，共271项。5个固定有限LP按初探、边帽压力、三参数扩大复核组织，32个全部来源子集cut均枚举；HiGHS仅发现候选，有理重构逐项验证原/对偶可行且gap为零。协调流在初探比固定缩放裁剪多保2/9；压力例仍有不可避免1/6缺额。有限模型不认证原rho、连续中心测度、原成功历史或一般维数。实际复现结果以r493_replay.json为准。

本轮实质增量是协调分配的严格连续接口，以及整族大质量真实停止尾的一次吸收。剩余厚来源量既非初始nu也非自然M；删去实际停止权会恢复深度损失。下一步集中估计同一真实rho下厚来源需求，寻找来源重叠与成功排斥、逐代耗散的联合控制；不再优化已付指数尾常数，不把cut改名当付款。
