# R493：真实成功记录的有边容量来源分配——精确 cut 与有限逼近

这是 R492 分配方式的严格变分接口，不是一般几何 cut 已付款的结论。固定原测度后允许重新分配辅助来源，不能因此重抽原记录或移植历史。

## 1. 固定实际输入与精确值

令记录空间 \(\mathcal R\) 保留 R492 的全部标签（含代数 \(j\)、原状态、成功配置 \(\mathcal F_0\)、刷新后的停止权）；令 \(\rho\) 为式(11)的 \(\sum_j\Gamma_j\)。由 R491，
\(\rho(\mathcal R)=A_p-\mathsf M(e)<\infty\)。也可对任意该测度的正限制使用下述定理。来源仍为 \(\mu=f\,dz\)，\(W<\infty\)。完成的标准 Borel 空间足够；下述函数取共同可测版本，约束为 a.e.。

定义
\[
 G_F=\sum_{C\in\mathcal F_0}m_C>0,
 \quad k(F,z)=\frac{1_{\cup_{C\in\mathcal F_0}Q_C}(z)}{G_F},
 \quad d=\frac23.
\]
R492 保证 \(d\le\int k(F,z)d\mu(z)\le1\)。故 \(k\in L^1(\rho\otimes\mu)\)；原 \(m_C\ge qa^n>0\) 还给点态有界，但证明不需要此额外有界性。**一般适用范围。** 下列(1)—(7)及其证明对任意常数 \(d>0\)、任意非负 \(k\in L^1(\rho\otimes\mu)\) 成立；不要求其行质量为一、至少为 \(d\)，或有统一行上帽。上面的 \(d=2/3\) 和特定 \(k\) 是 R492 应用，§5仍保留这一例子。因而也可取 \(d=1\)、\(k_*=M_*1_{\cup Q_C}/G_F\)，其中固定 \(M_*=2(1+z_*)<\infty\)。这仅放宽辅助分配的边容量，不更改原 \(\rho,\Gamma,J,H\)；此时不能仍声称分配密度至多 \(1/G_F\)，也不能免费沿用自然列帽 \(\nu\pi_B\)。

固定 \(\Lambda\ge0\)，令
\[
 V(k)=\max_a\iint a\,d\rho d\mu,\qquad
 0\le a\le k,\quad
 \int a(F,z)d\mu(z)\le d,\quad
 \int a(F,z)d\rho(F)\le\Lambda. \tag{1}
\]
记录供给上限是 \(d\rho\)，不是免费归一后的 \(\rho\)。最大值达到，且
\[
 \boxed{V(k)=\inf_{D\ \text{measurable}}
 \left\{\Lambda\mu(D)+\int\min\left(d,\int_{D^c}k(F,z)d\mu(z)\right)d\rho(F)\right\}.} \tag{2}
\]
等价精确缺额为
\[
 \boxed{\mathfrak D=d\rho(\mathcal R)-V(k)
 =\sup_D\left\{\int\left(d-\int_{D^c}k(F,z)d\mu(z)\right)_+d\rho
                 -\Lambda\mu(D)\right\}.} \tag{3}
\]
特别，全保 \(d\rho\) 当且仅当(3)每个 cut 表达式 \(\le0\)；允许总缺额 \(\eta\) 当且仅当每个表达式 \(\le\eta\)。不是对某个预选来源集合成立就足够。\(D=\varnothing\) 给非负缺额下界；原 R492 行质量至少为 \(d\) 时该 cut 值恰为零。零输入时全部为零；零来源时 \(V=0\)、\(\mathfrak D=d\rho(\mathcal R)\)；\(\Lambda=0\) 时 \(V=0\)，取全来源得到(3)。

## 2. 不调用连续网络定理的证明和可实施逼近

取递增有限记录分割 \(\mathcal A_n\) 与来源分割 \(\mathcal B_n\)，其联合生成相应完成 σ 代数模零集。令
\[
 k_n=E_{\rho\otimes\mu}[k\mid\mathcal A_n\otimes\mathcal B_n],
 \qquad \epsilon_n=\|k_n-k\|_{L^1(\rho\otimes\mu)}\to0. \tag{4}
\]
收敛可由矩形简单函数在乘积 \(L^1\) 的稠密性与条件期望压缩性证明；不假设通用收敛速率。

对于分块常数 \(k_n\)，记录块 \(I\) 的供给为 \(d\rho(I)\)，来源块 \(B\) 的容量为 \(\Lambda\mu(B)\)，边容量为 \(\iint_{I\times B}k_n\,d\rho d\mu\)。有限流多面体紧，最大流达到。若其残量图有源至汇正容量路径可增流，矛盾；否则源可达顶点形成饱和最小割。因此有限最大流等于
\[
 \min_{I,D}\{d\rho(I^c)+\iint_{I\times D^c}k_n\,d\rho d\mu+\Lambda\mu(D)\}.
\]
固定 \(D\)，记录块逐项选择便得(2)。允许 \(D\) 部分占某个来源块时，成本是各块占比的凹函数（\(\min(d,\cdot)\) 凹），最小值可取超立方体顶点，故不会低于有限块割。零测度块删除。

两边的值都对边核具有 \(L^1\)-Lipschitz 性。对于 primal，若 \(a\le k\) 可行，则 \(\min(a,k')\) 对 \(k'\) 真正可行，损失至多 \(\int(k-k')_+\)；反向同理。对于 cut，\(\min(d,\cdot)\) 为 1-Lipschitz，固定 \(D\) 的成本变化至多 \(\|k-k'\|_1\)，取 inf 后仍成立。因此 \(V(k_n)=C(k_n)\) 取极限即证(2)，不是从有限结论未经误差控制地外推。

更具体，将有限最优流变成块常数密度 \(a_n\) 后，
\[
 a'_n(F,z)=\min\{a_n(F,z),k(F,z)\} \tag{5}
\]
对**原真实核**可行，并有
\[
 \iint a'_n\ge V(k_n)-\epsilon_n\ge V(k)-2\epsilon_n. \tag{6}
\]
有限最优 cut 的原核成本亦至多 \(V(k)+2\epsilon_n\)。这给共同可测的逼近和完整参考误差，绝不声称分块后丢掉原 history；(5)仍是每一条原记录上的真实来源密度。

最后证明 primal 达到。置 \(d\kappa=k\,d\rho d\mu\)，写 \(a=kg\)，\(0\le g\le1\)。\(L^\infty(\kappa)\) 单位区间弱星紧；所有记录集合、来源集合的积分约束均为弱星闭，目标 \(\int g\,d\kappa\) 弱星连续。可行集非空，故最优达到。这不声称最优解随另一个未给出的外部参数可测选择。

## 3. 有界函数对偶与集合 cut 的达到性

有同值对偶
\[
 V=\min_{0\le\alpha,\beta\le1}\left[
 d\int\alpha\,d\rho+\Lambda\int\beta\,d\mu
 +\iint k(F,z)(1-\alpha(F)-\beta(z))_+d\rho d\mu\right]. \tag{7}
\]
弱对偶逐点成立。取 \(I_t=\{\alpha<t\}\)、\(D_t=\{\beta>1-t\}\)，Tonelli 给(7)成本等于
\[
 \int_0^1[d\rho(I_t^c)+\iint_{I_t\times D_t^c}k+\Lambda\mu(D_t)]dt.
\]
每个割成本不小于 \(V\)，而二元函数给所有集合割；结合(2)即证对偶同值。

(7)的最小值达到：可行函数对弱星紧，正部积分等于
\(\sup_{0\le g\le1}\iint k g(1-\alpha-\beta)\)，每个固定 \(g\) 的两个边缘密度都属 \(L^1\)，故成本弱星下半连续。最优函数阈值割的平均为 \(V\)，每个割至少为 \(V\)，所以几乎每个阈值给最优割。再优化记录集合 \(I=\{\int_{D^c}k<d\}\)，便得到(2)–(3)的集合达到。没有把集合族自身误当弱星紧。

## 4. 原停止账及尚未付款的几何条件

最优行量记 \(s(F)=\int a(F,z)d\mu\le d\)。在原记录上保比例 \(s(F)/d\)，源扩充为 \(a(F,z)d\mu/d\)：丢失原记录质量恰为 \(\mathfrak D/d\)，来源列至多 \(\Lambda\mu/d\)。原记录的历史和停止权未变；新来源仅是辅助收据。

由(1)–(3)直接得到
\[
 A_p=\mathsf M(e)+\rho(\mathcal R)
 \le\mathsf M(e)+\frac{\Lambda W+\mathfrak D}{d}. \tag{8}
\]
若实际几何能对**全部 cut**证明 \(\mathfrak D\le\eta X\)，且 \(\Lambda=O(\sqrt n\,\mathrm{polylog}\,n)\)，则 R491 恢复可接(8)。当前未证明这项 cut 几何；(2)并不把固定 \(k\) 的重列认定为不可避免，也不自称已有根价。\(\Lambda W\) 是总列容量，不能再与同一次均匀分配价格重复收费。

## 5. 严格优于统一裁剪的有限证书

取两条记录权 \(\rho=(1,1)\)，两来源块质量 \(\mu=(1,2)\)，
\[
 k=\begin{pmatrix}1&0\\1/3&1/3\end{pmatrix},\quad
 d=\Lambda=2/3.
\]
两行核质量均为一，可视为 singleton cloud 的来源集合质量分别为1与3；此为有限容量证书，不认证原连续接收场或原历史。

先对每行取 \(dk\)，再按来源列统一裁至 \(\Lambda\)，得到
\(a_{\rm clip}=\left(\begin{smallmatrix}1/2&0\\1/6&2/9\end{smallmatrix}\right)\)，总量 \(10/9\)。而
\(a_*=\left(\begin{smallmatrix}2/3&0\\0&1/3\end{smallmatrix}\right)\)
满足全部真实边、行、列帽，总量 \(4/3\) 等于全部供给，严格增加 \(2/9\)。这是可行重分配的改进，不是假设 row 归一化无成本。

```python
from fractions import Fraction as F
from itertools import product
rho=[F(1),F(1)]; mu=[F(1),F(2)]
k=[[F(1),F(0)],[F(1,3),F(1,3)]]
d=cap=F(2,3); checks=0
def ck(v):
    global checks
    assert v
    checks+=1
def mass(a):
    return sum(rho[i]*mu[j]*a[i][j] for i in range(2) for j in range(2))
def feasible(a):
    for i in range(2):
        for j in range(2):ck(0<=a[i][j]<=k[i][j])
        ck(sum(mu[j]*a[i][j] for j in range(2))<=d)
    for j in range(2):ck(sum(rho[i]*a[i][j] for i in range(2))<=cap)
raw=[[d*x for x in row] for row in k]
col=[sum(rho[i]*raw[i][j] for i in range(2)) for j in range(2)]
clip=[[raw[i][j]*min(F(1),cap/col[j]) for j in range(2)] for i in range(2)]
opt=[[F(2,3),F(0)],[F(0),F(1,3)]]
feasible(clip); feasible(opt)
ck(mass(clip)==F(10,9)); ck(mass(opt)==F(4,3))
ck(mass(opt)-mass(clip)==F(2,9))
cuts=[]; deficits=[]
for D in product((False,True),repeat=2):
    tail=[sum(k[i][j]*mu[j] for j in range(2) if not D[j]) for i in range(2)]
    cuts.append(cap*sum(mu[j] for j in range(2) if D[j])+sum(rho[i]*min(d,tail[i]) for i in range(2)))
    deficits.append(sum(rho[i]*max(F(0),d-tail[i]) for i in range(2))-cap*sum(mu[j] for j in range(2) if D[j]))
ck(min(cuts)==mass(opt)); ck(max(deficits)==0)
print(f'{checks} exact Fraction assertions PASS; strict gain = {mass(opt)-mass(clip)}.')
```

本机实际执行：唯一 Python fence 提取到新临时目录，以指定 Python `-I` 隔离运行，stdout：`21 exact Fraction assertions PASS; strict gain = 2/9.`。有限证书不承担连续强对偶或实际几何付款证明。
