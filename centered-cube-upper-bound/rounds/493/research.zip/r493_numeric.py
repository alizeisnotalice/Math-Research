from pathlib import Path
from fractions import Fraction as F
from itertools import combinations
import sys,platform,json,time
import scipy
from scipy.optimize import linprog
ROOT=Path(__file__).resolve().parent;start=time.perf_counter();checks=0

def ck(x):
 global checks
 assert x
 checks+=1

def st(x):return str(x)
def fm(A):return [[st(x) for x in row] for row in A]
def allsub(n):
 for z in range(n+1):yield from combinations(range(n),z)
c=F(2,3)
cases=[dict(name='initial_nested',phase='initial',rho=[F(1),F(1)],mu=[F(1),F(2)],k=[[F(1,3),F(1,3)],[F(1),F(0)]],source=[F(0),F(1)],intervals=[(F(-1,5),F(6,5)),(F(-1,5),F(1,5))],Lambda=F(2,3)),dict(name='pressure_edge_cap',phase='pressure',rho=[F(1),F(1)],mu=[F(1),F(1)],k=[[F(1,2),F(1,2)],[F(1),F(0)]],source=[F(0),F(1)],intervals=[(F(-1,5),F(6,5)),(F(-1,5),F(1,5))],Lambda=F(2,3))]
for lam in (F(1,3),F(2,3),F(1)):
 cases.append(dict(name='expanded_Lambda_'+str(lam),phase='expanded',rho=[F(1),F(1,2),F(3,2),F(1)],mu=[F(1),F(2),F(1)],k=[[F(1,4)]*3,[F(2,3),F(0),F(0)],[F(0),F(1,3),F(1,3)],[F(0),F(0),F(1)]],source=[F(0),F(1),F(2)],intervals=[(F(-1,5),F(11,5)),(F(-1,5),F(1,5)),(F(4,5),F(11,5)),(F(9,5),F(11,5))],Lambda=lam))
records=[]
for case in cases:
 rho=case['rho'];mu=case['mu'];k=case['k'];lam=case['Lambda'];nr=len(rho);ns=len(mu)
 for r,(l,u) in enumerate(case['intervals']):
  for i,x in enumerate(case['source']):
   ck(x!=l and x!=u);ck((k[r][i]>0)==(l<x<u))
 mass=[sum(mu[i]*k[r][i] for i in range(ns)) for r in range(nr)]
 ck(all(c<=z<=1 for z in mass))
 demand=[c*x for x in rho];cap=[[rho[r]*mu[i]*k[r][i] for i in range(ns)] for r in range(nr)];supply=[lam*x for x in mu]
 # HiGHS discovery only: all certification below reconstructs exact rationals.
 A=[];b=[]
 for r in range(nr):A.append([int(j//ns==r) for j in range(nr*ns)]);b.append(float(demand[r]))
 for i in range(ns):A.append([int(j%ns==i) for j in range(nr*ns)]);b.append(float(supply[i]))
 sol=linprog([-1.]*(nr*ns),A_ub=A,b_ub=b,bounds=[(0,float(cap[r][i])) for r in range(nr) for i in range(ns)],method='highs')
 ck(sol.success)
 flow=[[F(float(sol.x[r*ns+i])).limit_denominator(10**6) for i in range(ns)] for r in range(nr)]
 for r in range(nr):
  ck(sum(flow[r])<=demand[r]);ck(all(0<=flow[r][i]<=cap[r][i] for i in range(ns)))
 for i in range(ns):ck(sum(flow[r][i] for r in range(nr))<=supply[i])
 value=sum(map(sum,flow));cuts=[]
 for D in allsub(ns):
  exterior=[sum(cap[r][i] for i in range(ns) if i not in D) for r in range(nr)]
  cut=sum(supply[i] for i in D)+sum(min(demand[r],exterior[r]) for r in range(nr))
  ck(value<=cut)
  cuts.append(dict(D=list(D),source_term=st(sum(supply[i] for i in D)),row_terms=[st(min(demand[r],exterior[r])) for r in range(nr)],cut=st(cut)))
 optimum=min(F(z['cut']) for z in cuts);ck(value==optimum)
 dual=[z for z in cuts if F(z['cut'])==optimum]
 baseline=[[c*cap[r][i] for i in range(ns)] for r in range(nr)]
 oldcol=[sum(baseline[r][i] for r in range(nr)) for i in range(ns)]
 factor=[min(F(1),supply[i]/oldcol[i]) if oldcol[i] else F(1) for i in range(ns)]
 clipped=[[baseline[r][i]*factor[i] for i in range(ns)] for r in range(nr)]
 for r in range(nr):ck(sum(clipped[r])<=demand[r]);ck(all(clipped[r][i]<=cap[r][i] for i in range(ns)))
 for i in range(ns):ck(sum(clipped[r][i] for r in range(nr))<=supply[i])
 clipvalue=sum(map(sum,clipped));ck(clipvalue<=value)
 # Incorrect attempt to restore all rows after clipping; report actual violations.
 scaled=[[x*demand[r]/sum(clipped[r]) if sum(clipped[r]) else F(0) for x in clipped[r]] for r in range(nr)]
 edgeviol=[(r,i,st(scaled[r][i]-cap[r][i])) for r in range(nr) for i in range(ns) if scaled[r][i]>cap[r][i]]
 colviol=[(i,st(sum(scaled[r][i] for r in range(nr))-supply[i])) for i in range(ns) if sum(scaled[r][i] for r in range(nr))>supply[i]]
 if value<sum(demand):ck(bool(edgeviol or colviol))
 if case['name']=='initial_nested':ck(value==F(4,3));ck(clipvalue==F(10,9));ck(value-clipvalue==F(2,9))
 if case['name']=='pressure_edge_cap':ck(value==F(7,6));ck(any(z['D']==[0] for z in dual))
 records.append(dict(name=case['name'],phase=case['phase'],rho=list(map(st,rho)),mu=list(map(st,mu)),c=st(c),Lambda=st(lam),source_positions=list(map(st,case['source'])),actual_intervals=[[st(l),st(u)] for l,u in case['intervals']],k=fm(k),kernel_row_mass=list(map(st,mass)),row_demand=list(map(st,demand)),source_capacity=list(map(st,supply)),edge_capacity=fm(cap),solver_exploration=dict(method='SciPy HiGHS',status=int(sol.status),message=sol.message,objective=float(-sol.fun),maximum_inequality_residual=float(max([0.]+[sum(A[j][i]*sol.x[i] for i in range(nr*ns))-b[j] for j in range(len(b))]))),exact_primal=fm(flow),exact_value=st(value),exact_all_source_subset_cuts=cuts,exact_minimizing_cuts=dual,exact_gap=st(optimum-value),full_row_supply=st(sum(demand)),coordinated_deficit=st(sum(demand)-value),fixed_c_kernel_flow=fm(baseline),column_clip_factors=list(map(st,factor)),column_clipped_flow=fm(clipped),column_clip_value=st(clipvalue),coordination_gain=st(value-clipvalue),wrong_row_renormalized_flow=fm(scaled),wrong_row_renormalization_edge_violations=edgeviol,wrong_row_renormalization_column_violations=colviol))
result=dict(scope='Finite source atoms/discrete records, actual interval support compatibility only. Not original Gamma/history or continuous existence theorem.',compute_index=dict(executable=sys.executable,python=platform.python_version(),scipy=scipy.__version__,command='"'+sys.executable+'" r493_numeric.py',seconds=time.perf_counter()-start),checks=checks,cases=len(records),formulas=dict(primal='max sum a_ri; row<=c rho_r,source<=Lambda mu_i,edge<=rho_r mu_i k_ri',dual_cut='min_D Lambda mu(D)+sum_r min(c rho_r,sum_i_notinD rho_r mu_i k_ri)',baseline='a0=c*rho*mu*k then multiply each source column by min(1,Lambda mu_i/column_i)',warning='Row-normalizing clipped flow is not free; it may violate source or edge caps.'),records=records,decision='Coordination can strictly improve fixed allocation then column clipping, but edge caps can prevent full row retention. Exact certificates concern only supplied finite records, not original stopping flow or geometry/history.',errors='HiGHS only discovers a candidate. Every final flow reconstructed as Fraction and checked against all constraints and every source-subset cut; certified only when exact gap=0. No random scan.')
(ROOT/'r493_numeric.json').write_text(json.dumps(result,indent=2)+'\n')
print('PASS',checks,'exact assertions;5 fixed finite LPs,all rational primal/mincut gaps0;HiGHS discovery only')
