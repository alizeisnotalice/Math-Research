# R493：真实停止云的总质量尾与全局来源 cut 比较

本稿保持 R492 的同一 \(\Gamma_{<N}\)、实际 \(J,H\)、原记录和历史。证明一项可收费正分支：整族质量远大于最大父的记录，总真实 p 次停止质量至多 \(\varepsilon_{\rm tail}R\)。在其完整补集上，允许对数级局部密度上帽时，任何最大父来源重路由都合法嵌入整族重路由。累计厚来源 cut 的根阶预算仍未证明。

## 1. 输入及允许的实际分配

沿 R492，\(\mu=f\,dx\)、\(\nu=t\sigma\)、\(0\le t\le S\)、\(R=\nu(E)\le SX\)。每条 \(\omega\in\Gamma_{<N}\) 保其成功族 \(F_0\)、最大质量父 \(B\)，并记
\[
U_F=\bigcup_{C\in F_0}Q_C,\qquad
G_F=\sum_{C\in F_0}m_C,\qquad Z_F=G_F/m_B-1.
\]
低 Gram 已证 \(\mu(U_F)\ge2G_F/3\)。对该记录允许附加来源密度 \(\psi_\omega(z)\) 满足
\[
0\le\psi_\omega(z)\le M_*1_{U_F}(z)/G_F,
\quad \int\psi_\omega\,d\mu\le1,
\quad \int\psi_\omega(z)\,d\Gamma_{<N}(\omega)\le\Lambda.
\tag{1}
\]
附加来源只用于最终收据，不返回链，不继承旧历史。这里只研究该明确容量，不能用任意点质量重分配。

第 \(j\) 次真实停止前一跳仍为
\[
d\Gamma_j=q_j(s)\mathsf M(ds)J^{\rm rec}(s,d\omega)
 H(\omega,ds')q_{j+1}(s')^{p-1}e(s'),
\qquad |\Gamma_j|=\langle q_{j+1}^p,e\rangle.
\tag{2}
\]
原初始 \(\langle1,e\rangle\) 单列。所有上放都从 (2) 开始。

## 2. 真实最大父参考下的 Poisson 总质量尾

自然最大父状态固定 \((B,s_B,x)\)。其完整 lower 配置为强度
\[
\frac{1_{C\prec B}c_C(x)}{Tm_C}\nu(dC)\,ds_C
\]
的 PPP。定义 \(Z_{\rm raw}=\sum_{C\in F_{\rm lower}}m_C/m_B\)。实际 \(Z_F\le Z_{\rm raw}\)。每个跳跃在 \([0,1]\) 内，包括同质量 mark 原子；真实中心质量 CDF 给
\[
\mathbb E[Z_{\rm raw}\mid B,s_B,x]
=\frac1{Tm_B}\int_{C\prec B}c_C(x)\nu(dC)ds_C
\le c_0:=\frac{rS}{T}.
\tag{3}
\]
这里使用 \(\int_{m_C\le m}c_C(x)\nu(dC)\le rSm\)，由真实 Lebesgue 中心子水平体积 \(\le m/q\) 得到；未假设来源密度帽。

PPP 指数公式与 \(e^{\theta w}-1\le w(e^\theta-1)\)（\(0\le w\le1\)）给
\[
\mathbb E[e^{\theta Z_{\rm raw}}\mid B,s_B,x]
\le \exp\{c_0(e^\theta-1)\},\quad\theta>0.
\tag{4}
\]
这是自然参考的条件式，不是成功后配置条件 PPP 的声明。

令 \(b_0=2rS/T<1\)、\(L=\sqrt n\)，并设
\[
a_j=\min(1,e^L b_0^j),\qquad
\mathfrak d=\left\lceil\frac{L}{\log(1/b_0)}\right\rceil+
\frac1{1-b_0}.
\]
已有同带实际到达界保证 \(h_j=J^*q_j\le a_j\)，且 \(\sum_ja_j\le\mathfrak d\)。在 (2) 中仅将最后的停止权正上放到1，再用实际 Palm 支配 \(\mathsf M J\le\mathsf M\)，可对全部有限 \(N\) 一致地得到
\[
\Gamma_{<N}\{Z_F>z\}\le
 R\mathfrak d\exp\{c_0(e-1)-z\}.
\tag{5}
\]
固定 \(0<\varepsilon_{\rm tail}<1\)，取
\[
\boxed{z_*=2c_0+\log(\mathfrak d/\varepsilon_{\rm tail}).}
\]
由 \(e-1<2\)，
\[
\boxed{\Gamma_{<N}\{G_F>(1+z_*)m_B\}
\le\varepsilon_{\rm tail}R\le\varepsilon_{\rm tail}SX.}
\tag{6}
\]
此为同一真实 p 次停止流的已付正限制；没有按代重复收取 \(W\)。零流单列。固定原参数时 \(z_*=O(\log(n+2)+\log(1/\varepsilon_{\rm tail}))\)。

## 3. 好支的来源 cut 与构造性重路由比较

记 \(\Gamma^{\rm good}=1_{Z_F\le z_*}\Gamma_{<N}\)，选择
\[
M_*=2(1+z_*).
\tag{7}
\]
在每条好记录上，\(Q_B\subset U_F\) 且 \(M_*/G_F\ge2/m_B\)。因此，任何在同一记录上构造的密度
\[
0\le\psi_\omega(z)\le 2c_B(z)/m_B,
\quad \int\psi_\omega d\mu\le1
\]
都满足 (1) 的整族局部容量；其真实列和、接受质量及全部原标签原样保留。这是显式嵌入，不需假定 Hall 条件充分或最优分配存在。

等价的逐 cut 可核比较为：对任意可测来源集 \(D\)，
\[
\begin{split}
&\int\left(1-M_*\frac{\mu(U_F\setminus D)}{G_F}\right)_+
 d\Gamma_{<N}-\Lambda\mu(D)\\
&\quad\le\varepsilon_{\rm tail}R+
\int\left(1-2\pi_B(D^c)\right)_+
 d\Gamma^{\rm good}-\Lambda\mu(D).
\end{split}
\tag{8}
\]
证明只有 (6)、包含关系和 \((\cdot)_+\) 单调性。特别正的好支需求迫使实际最大父满足 \(\pi_B(D)>1/2\)。不把来源体积当成来源质量。

若只允许固定 \(M\)，也有逐记录精确比较
\[
(1-M\pi_B(D^c))_+-M\frac{Z_F}{1+Z_F}
\le\left(1-M\frac{\mu(U_F\setminus D)}{G_F}\right)_+
\le(1-M\pi_B(D^c))_++\frac{Z_F}{1+Z_F}.
\tag{9}
\]
它由 \(m_B\pi_B(D^c)\le\mu(U_F\setminus D)
\le m_B\pi_B(D^c)+m_BZ_F\) 得到。正式主收据用 (6)–(8)，不把 (9) 的均值误差重复收费。

## 4. 完整费用及唯一仍缺的几何比较

令 \(A_{p,N}^{\rm good}=|\Gamma^{\rm good}|\)。严格有
\[
A_{p,N}\le\langle1,e\rangle+
 A_{p,N}^{\rm good}+\varepsilon_{\rm tail}R.
\]
R491 近线性恢复参数为 \(\eta_{\rm rec}\) 时，令 \(N\to\infty\) 得
\[
(1-\eta_{\rm rec}-2\varepsilon_{\rm tail})R
\le2\langle1,e\rangle+2A_p^{\rm good}.
\tag{10}
\]
需 \(2\varepsilon_{\rm tail}<1-\eta_{\rm rec}\)。没有再把尾费乘 \(1+z_*\)；局部上帽的对数增长不改变链或输入价格。

未证明的是 (8) 右端的**实际累计最大父厚来源需求**相对于 \(\Lambda\mu(D)\) 的统一预算。它含 (2) 的真实停止权，不是 \(\nu\) 的厚来源需求。仅删停止权给其最大父边缘 \(\le\mathfrak d\nu\)，继而来源列 \(\le\mathfrak d\,u(z)\)，\(u(z)=\int c_B(z)\nu(dB)/m_B\)；该式不能给所需根价。

因此本轮确实支付 large-\(G_F/m_B\) 尾，并以可控局部失真把剩余 cloud cut 接到同一实际最大父需求；没有证明完整重路由的根阶列或整体闭合。下一步必须估计该真实厚来源停止集中，不能把自然 PPP 或初始 \(\nu\) 当作其累计分布。

## 5. 本机参数核验

以下代码在指定数学 Python 环境实际运行，输出 `PASS 12 Arb tail-threshold checks at 192 bits; parameter arithmetic only`。它只核 (5)–(6) 的有限参数严格算术，不认证原生几何或实际历史；一般尾界由上述解析证明给出。

```python
from flint import arb,ctx
from fractions import Fraction as F
ctx.prec=192
checks=0
for c in [F(1,1024),F(1,128)]:
 for D in [1,4,16]:
  for eps in [F(1,4),F(1,16)]:
   ca=arb(c.numerator)/c.denominator
   ea=arb(eps.numerator)/eps.denominator
   z=2*ca+(arb(D)/ea).log()
   bound=arb(D)*(ca*(arb(1).exp()-1)-z).exp()
   assert bound<ea
   checks+=1
print(f'PASS {checks} Arb tail-threshold checks at 192 bits; '
      'parameter arithmetic only')
```
