"""Round 795. Two orders of integration and true receiving-cell charges over Q."""
import argparse
import itertools
import json
import platform
import sys
from collections import defaultdict
from fractions import Fraction as F
from hashlib import sha256
from math import prod
from pathlib import Path


def corners(c, radius):
    return tuple((x - radius, x + radius) for x in c)


def mass(a, b=None):
    spans = a if b is None else [(max(i, k), min(j, l)) for (i, j), (k, l) in zip(a, b)]
    if any(x >= y for x, y in spans):
        return F(0)
    def primitive(x):
        k = x // F(1, 64)
        t = x - F(k, 64)
        return F(k, 64) + t / 2 + min(t, F(1, 128))
    return (primitive(spans[0][1]) - primitive(spans[0][0])) * prod(y - x for x, y in spans[1:])


def fit(inner, outer):
    return all(x >= i and y <= j for (x, y), (i, j) in zip(inner, outer))


def fstr(x):
    x = F(x)
    if max(x.numerator.bit_length(),x.denominator.bit_length()) < 1600:
        return str(x)
    assert x > 0
    digest=sha256()
    for a in (x.numerator,x.denominator):
        b=a.to_bytes((a.bit_length()+7)//8,"big")
        digest.update(len(b).to_bytes(8,"big"))
        digest.update(b)
    exp=x.numerator.bit_length()-x.denominator.bit_length()-48
    base=F(2)**exp
    k=x//base
    assert k*base <= x < (k+1)*base
    return dict(mantissa_interval=[k,k+1],power_of_two=exp,sha256_canonical_rational=digest.hexdigest())


def case(n, count):
    zero = (F(0),) * n
    def center(x, axis=0):
        return tuple(F(x) if k == axis else F(0) for k in range(n))
    owner_radius = F(1, 4096*n)
    p = (2*owner_radius)**n
    def parent(c, rad):
        a = corners(c, rad)
        mv = (2*rad)**n
        assert mass(a) == mv
        return (c, rad, a, mv)
    small = []
    for axis in range(min(n, 2)):
        for sgn, h in itertools.product((-1, 1), (105, 131, 145, 153)):
            small.append(parent(center(F(sgn*h, 64), axis), F(65+(h%3), 64)))
    if n > 1:
        for e, f in itertools.product((-1, 1), repeat=2):
            small.append(parent((F(109*e, 64), F(109*f, 64))+zero[2:], F(67, 64)))
    cen = [parent(center(F(2*i-count+1, 64)), F(96+i%2, 64)) for i in range(count)]
    shared = parent(center(F(1, 128)), F(88, 64))
    large = parent(center(F(1, 2)), F(125, 64))
    all_parents = small+cen+[shared, large]
    for j, (c, s, _, _) in enumerate(all_parents):
        assert owner_radius <= s/(32*n)
        assert all(any(abs(a-b)>2*owner_radius for a,b in zip(c,h[0])) for h in all_parents[:j])
    assert all(fit(shared[2], v[2]) for v in cen)
    outer = max(v[1] for v in cen)
    D = 2**(min(v[3] for v in cen+[shared]).numerator.bit_length()-1
            - (min(v[3] for v in cen+[shared]).denominator.bit_length()-1))
    while D > shared[3]:
        D = F(D,2)
    while 2*D <= shared[3]:
        D *= 2
    assert D <= shared[3] < 2*D and F(2)**n <= D
    small_weights = [p*F(2+j%3, 4) for j in range(len(small))]
    # Use two actual historical rows over each physical central owner.
    states = []
    eta = F(0)
    for i,v in enumerate(cen):
        for history in (0, 1):
            vweight = p * (F(1,3) if history == 0 else F(2,3))
            q = []
            qtag = []
            for j,u in enumerate(small):
                ij = mass(v[2],u[2])
                eta = max(eta, ij/u[3])
                admissible = (i + 2*j + history) % (5+history) != 2
                q.append((ij/v[3]/u[3])*(small_weights[j]/p) if admissible else F(0))
                common=[(max(x,z),min(y,w)) for (x,y),(z,w) in zip(v[2],u[2])]
                edges=(-8,-1,0,1,8)
                cuts=[mass([(max(x0,common[0][0]),min(x1,common[0][1]))]+common[1:])
                      for x0,x1 in zip(edges,edges[1:])]
                assert sum(cuts)==ij
                qtag.append([q[-1]*v1/ij if ij else F(0) for v1 in cuts])
            dminus = p*sum(q)
            non_down = mass(v[2],large[2])*p/(v[3]*large[3])
            d = dminus + non_down
            assert d > dminus > 0
            states.append((i, history, vweight, q, d, dminus, qtag))
    m = len(small)
    assert 0 < eta < 1
    offs = [F(0), F(1,128), F(1), F(-1), F(5,4), F(-5,4), F(191,128), F(-191,128)]
    prices = [center(c) for c in offs]
    if n > 1:
        prices += [center(F(1,1),1),center(F(-1,1),1)]
    # All actual small owners stay inside their assigned grid cells, of full side two.
    off = F(1,1024)
    def cell(c):
        return tuple((x+1-off)//2 for x in c)
    groups = [cell(v[0]) for v in small]
    for v, g in zip(small, groups):
        assert all(c-owner_radius > 2*k-1+off and c+owner_radius < 2*k+1+off for c,k in zip(v[0],g))
    gc = sorted(set(groups))
    group = [gc.index(c) for c in groups]
    sizes = [p*groups.count(c) for c in gc]
    caps = [F(0),F(0),F(0)]
    totals = defaultdict(F)
    heterogeneous = False
    diag_positive = False
    hist_asymmetry = False
    nonempty = 0
    for pos in prices:
        yp = corners(pos,owner_radius)
        my = mass(yp)
        def active(v):
            z = mass(v[2],yp)
            assert z in (0,my)
            return z == my
        is_shared = active(shared)
        z0 = [[F(0) for _ in range(m)] for _ in range(m)]
        gram = [row[:] for row in z0]
        actual = [row[:] for row in z0]
        trace = F(0)
        fixed_sum = F(0)
        tagged = [row[:] for row in z0]
        trace_tag = F(0)
        for i,hist,vw,q,d,down,qtag in states:
            v = cen[i]
            if not active(v):
                continue
            fixed_sum += vw/v[3]
            assert max(q) <= eta/v[3]
            tr = vw*sum(x*x*p for x in q)/d
            assert tr <= vw*eta/v[3]
            trace += tr
            tr_mark=vw*p*sum(sum(z*z for z in arm) for arm in qtag)/d
            assert tr_mark <= tr
            trace_tag += tr_mark
            for l,ql in enumerate(q):
                for j,qj in enumerate(q):
                    root = vw*ql*qj*p*p/d
                    gram[l][j] += root
                    share = F((i+hist+l+2*j)%4, 3)
                    keep = F(1+(3*i+hist+2*l+j)%4,4)
                    posterior = (1-share)/v[3]+share*int(is_shared)/shared[3]
                    actual[l][j] += root*keep*posterior
                    # The same latent terminal is held fixed across both fresh draws.
                    twice = (1-share)/v[3]**2 + share*int(is_shared)/shared[3]**2
                    assert posterior**2 <= twice <= F(1,D**2)
                    totals["two_fresh_samples_same_terminal_and_price_cell"] += my**2*root*keep*twice
                    totals["wrongly_resampling_terminal_between_prices_diagnostic"] += my**2*root*keep*posterior**2
                    marked_weight=sum(qtag[l][b]*qtag[j][3-b] for b in range(4))
                    tagged[l][j] += vw*p*p*marked_weight/d
        assert trace == sum(gram[j][j]/p for j in range(m))
        assert trace <= eta*fixed_sum
        assert all(D*actual[l][j] <= gram[l][j] for l in range(m) for j in range(m))
        dy = tuple((x-owner_radius,x+owner_radius) for x in pos)
        rel = []
        for a in small:
            rel.append([(x-hi, z-lo) for (x,z),(lo,hi) in zip(corners(a[0],owner_radius),dy)])
        def whole_far(j):
            return any(lo>outer or hi < -outer for lo,hi in rel[j])
        def affine(l,j,t):
            errors = [max(abs(t*a+(1-t)*c),abs(t*b+(1-t)*d1))
                      for (a,b),(c,d1) in zip(rel[l],rel[j])]
            return max(errors)**2 <= outer**2*t*(1-t)
        def hardy(l,j,t):
            for ra, rb in zip(rel[l], rel[j]):
                extremes = [x*y for x in ra for y in rb]
                if max(extremes) > (outer*t)**2 or min(extremes) < -(outer*(1-t))**2:
                    return False
            return True
        def add_test(tag, predicate):
            pairs = [(l,j) for l in range(m) for j in range(m) if predicate(l,j)]
            if not pairs:
                return F(0)
            rows = [0]*m
            cols = [0]*m
            for l,j in pairs:
                rows[l]+=1
                cols[j]+=1
            bilinear = sum(gram[l][j] for l,j in pairs)
            real = sum(actual[l][j] for l,j in pairs)
            assert bilinear**2 <= trace**2*p*p*max(rows)*max(cols)
            assert D*real <= bilinear
            totals[tag] += real*my
            return real
        add_test("reflected_paid", lambda l,j:affine(l,j,F(1,2)))
        pairs_mark=[(l,j) for l in range(m) for j in range(m) if affine(l,j,F(1,2))]
        rr=max((sum(l==i for l,j in pairs_mark) for i in range(m)), default=0)
        cc=max((sum(j==i for l,j in pairs_mark) for i in range(m)), default=0)
        marked_sum=sum(tagged[l][j] for l,j in pairs_mark)
        assert marked_sum**2 <= trace_tag**2*p**2*rr*cc
        totals["true_initial_prices_in_reciprocally_paired_slabs_and_reflected_owners_before_thinning"] += my*marked_sum
        totals["marked_trace_before_normalized_terminal_sampling"] += my*trace_tag
        correlated = add_test("reflected_paid_both_single_probes_far",
                              lambda l,j:whole_far(l) and whole_far(j) and affine(l,j,F(1,2)))
        add_test("three_interpolation_parameters",lambda l,j:any(affine(l,j,t) for t in (F(1,4),F(1,2),F(3,4))))
        add_test("signed_hyperbolic_three_parameters",lambda l,j:any(hardy(l,j,t) for t in (F(1,3),F(1,2),F(2,3))))
        heterogeneous |= correlated>0
        actual_total = sum(map(sum,actual))
        if not actual_total:
            continue
        nonempty += 1
        hist_asymmetry |= any(actual[l][j]!=actual[j][l] for l in range(m) for j in range(m))
        diag_positive |= any(actual[j][j]>0 for j in range(m))
        totals["actual_all_on_test_price_cells"] += actual_total*my
        # Aggregate the ACTUAL conditional law after keeping its asymmetric screen and terminal weights.
        sz=len(gc)
        E=[[F(0)]*sz for _ in range(sz)]
        G=[[F(0)]*sz for _ in range(sz)]
        for l,j in itertools.product(range(m),repeat=2):
            E[group[l]][group[j]] += actual[l][j]
            G[group[l]][group[j]] += gram[l][j]
        rows=list(map(sum,E))
        cols=list(map(sum,zip(*E)))
        assert sum(rows)==sum(cols)==actual_total
        # Rational lower certificate for affinity using AM>=GM in both factors.
        # C_ab >= 2 E_ab/(l_a+r_b); 1/sqrt(p_a p_b) >= 2/(p_a+p_b).
        # This kernel is also bounded above entrywise by the Schur contraction.
        score=F(0)
        upper=F(0)
        for a,b in itertools.product(range(sz),repeat=2):
            if E[a][b]:
                coefficient = 4*E[a][b]/((rows[a]+cols[b])*(sizes[a]+sizes[b]))
                score += D*coefficient*E[a][b]
                upper += coefficient*G[a][b]
        assert score <= upper <= trace
        totals["rational_forward_reverse_collision_score"] += score*my
        totals["independent_Gram_bound_on_rational_score"] += upper*my
        totals["trace_source_integral"] += trace*my
        caps[0]=max(caps[0],trace)
        caps[1]=max(caps[1],eta*fixed_sum)
        caps[2]=max(caps[2],score/trace)
    assert heterogeneous and diag_positive and hist_asymmetry
    assert totals["two_fresh_samples_same_terminal_and_price_cell"] > totals["wrongly_resampling_terminal_between_prices_diagnostic"]
    assert totals["true_initial_prices_in_reciprocally_paired_slabs_and_reflected_owners_before_thinning"]>0
    return dict(n=n,central_count=count,central_histories=len(states),small_parents=m,occupied_owner_cells=len(gc),
                source_price_cells=len(prices),positive_price_cells=nonempty,one_shared_smaller_terminal=True,
                true_initial_overlap_eta=str(eta),minimum_physical_bin_volume=str(D),
                positive_diagonal_and_asymmetric_thinning=True,
                positive_reflection_missed_by_both_single_probes=True,
                reflection_far_share=str(totals["reflected_paid_both_single_probes_far"]/totals["reflected_paid"]),
                trace_maximum=str(caps[0]),local_overlap_trace_upper_maximum=str(caps[1]),
                maximum_rational_score_divided_by_trace=fstr(caps[2]),
                totals={k:fstr(v) for k,v in totals.items()})


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    g = ap.add_mutually_exclusive_group()
    g.add_argument("--output",type=Path)
    g.add_argument("--check",type=Path)
    a=ap.parse_args()
    info=dict(python=sys.executable,version=platform.python_version(),architecture=platform.machine(),
              arithmetic="exact rational; Gram, positive test and conditional-affinity comparisons have zero rounding error",
              scope="Compact periodic-density box; full ascending neighbor included in degrees; terminal either original or common contained cube; normalized Lebesgue owners. Asymmetric diagnostic history screen. Price-cell/owner-subrectangle tests give explicit lower coupons; high-dimensional hard gates and R794 rank histories are not imposed.",
              reproduction="python -B gram795.py --check gram795.json",
              three_stages=[case(n,c) for n,c in ((1,2),(2,4),(4,8))])
    b=(json.dumps(info,sort_keys=True,ensure_ascii=False,indent=2)+"\n").encode()
    if a.output:
        a.output.write_bytes(b)
    elif a.check:
        if b!=a.check.read_bytes():
            raise SystemExit("certificate differs")
        print("gram795: genuine double probes, trace, Schur and measured cell scores agree")
    else:
        print(b.decode(),end="")


if __name__=="__main__":
    main()
