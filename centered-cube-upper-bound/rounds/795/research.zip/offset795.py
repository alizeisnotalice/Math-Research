"""R795: exact continuous offsets and shared-scale product L2 certificates."""

import argparse
from collections import defaultdict
from fractions import Fraction as F
from itertools import combinations, product
import json
from math import isqrt
from pathlib import Path
import platform
import sys

import flint
from flint import arb, ctx, fmpq


ctx.prec=256


def ar(x):
    q=F(x)
    return arb(fmpq(q.numerator,q.denominator))


def ipoly(poly,a,b):
    return sum((c*(b**(j+1)-a**(j+1))/ (j+1) for j,c in enumerate(poly)),F(0))


def psq(p):
    out=[F(0)]*(2*len(p)-1)
    for i,j in product(range(len(p)),repeat=2):
        out[i+j]+=p[i]*p[j]
    return out


def integrate(cells,a,b,degree=2):
    result=F(0)
    for lo,hi,p in cells:
        start,end=max(lo,a),min(hi,b)
        if start<end:
            result+=ipoly(psq(p) if degree==2 else p,start,end)
    return result


class Step:
    def __init__(self, edges, values):
        self.edges=tuple(map(F,edges))
        self.values=tuple(map(F,values))
        assert self.edges[0]==0 and self.edges[-1]==1
        assert all(a<b for a,b in zip(self.edges,self.edges[1:]))
        assert len(self.edges)==len(self.values)+1
        assert min(self.values)>0
        self.mean=sum((b-a)*x for a,b,x in zip(self.edges,self.edges[1:],self.values))
        self.norm2=sum((b-a)*x*x for a,b,x in zip(self.edges,self.edges[1:],self.values))

    def primitive(self,t):
        k=t//1
        r=t-k
        return k*self.mean+sum(max(F(0),min(r,b)-a)*x
                               for a,b,x in zip(self.edges,self.edges[1:],self.values))

    def average(self,s,x):
        return (self.primitive(x+s)-self.primitive(x-s))/(2*s)

    def source_breaks(self,s):
        return sorted({((x+side*s)%1) for x in self.edges for side in (-1,1)})


def affine_between(eval_,a,b):
    m=(eval_(b)-eval_(a))/(b-a)
    return eval_(a)-m*a,m


def value(p,x):
    u,v=p
    return u+v*x


def continuous_step_max(step,s,delta):
    e=delta*s
    t=step.source_breaks(s)
    local=[v+k for v in t for k in (-1,0,1)]
    cuts=sorted({F(0),F(1)}|{(v+sign*e)%1 for v in t for sign in (-1,1)})
    cells=[]
    winners=[0,0]
    exact_witness=None
    for a,b in zip(cuts,cuts[1:]):
        x=(a+b)/2
        lines=tuple(affine_between(lambda u:step.average(s,u+h),a,b) for h in (-e,e))
        flat=tuple((step.average(s,u),F(0)) for u in local if x-e<u<x+e)
        opts=sorted(set(lines+flat))
        stops={a,b}
        for l,r in combinations(opts,2):
            if l[1]!=r[1]:
                q=(r[0]-l[0])/(l[1]-r[1])
                if a<q<b:
                    stops.add(q)
        seq=sorted(stops)
        for lo,hi in zip(seq,seq[1:]):
            x=(lo+hi)/2
            best=max(opts,key=lambda g:value(g,x))
            # A continuous PL function on the whole window has a maximum
            # at an endpoint or one of its genuine internal breakpoints.
            for q in (x,(3*lo+hi)/4,(lo+3*hi)/4):
                raw=[step.average(s,q-e),step.average(s,q+e)]
                raw += [step.average(s,u) for u in local if q-e<u<q+e]
                assert value(best,q)==max(raw)
            cells.append((lo,hi,best))
            if value(best,x)>max(value(line,x) for line in lines):
                winners[0]+=1
                if exact_witness is None:
                    exact_witness=[x,*[value(line,x) for line in lines],value(best,x)]
            else:
                winners[1]+=1
    assert cells[0][0]==0 and cells[-1][1]==1
    assert all(left[1]==right[0] for left,right in zip(cells,cells[1:]))
    return cells,winners,exact_witness


def step_test(step,s,delta):
    centers=[]
    knots=sorted(set(step.source_breaks(s))|{F(0),F(1)})
    for a,b in zip(knots,knots[1:]):
        centers.append((a,b,affine_between(lambda x:step.average(s,x),a,b)))
    J=integrate(centers,F(0),F(1))
    E=sum((b-a)*(s*line[1])**2 for a,b,line in centers)
    assert E<=3*(step.norm2-J)
    g,winners,witness=continuous_step_max(step,s,delta)
    I=integrate(g,F(0),F(1))
    assert J<=I<=(1+12*delta**2)*step.norm2
    return g,dict(centered_norm_squared=J,shifted_continuous_supremum_norm_squared=I,
                  input_norm_squared=step.norm2,s_times_space_derivative_norm_squared=E,
                  exact_energy_over_deficit=E/(step.norm2-J),
                  strict_inside_breakpoint_vs_endpoint_winning_pieces=winners,
                  interior_witness_w_endpoint_left_endpoint_right_true_sup=witness,
                  exact_supremum_affine_segments=g)


def triangular(s,delta):
    assert 0<s<=F(1,4) and 0<=delta<=1
    b=delta*s
    cells=[(F(0),s,(2-s,F(0),-1/s)),
           (s,F(1,2)-s,(F(2),F(-2),F(0))),
           (F(1,2)-s,F(1,2),(1+s+1/(4*s),-1/s,1/s))]
    a=2*integrate(cells,F(0),F(1,2))
    for lo,hi,p in cells:
        assert p[1]+2*p[2]*lo<=0 and p[1]+2*p[2]*hi<=0
    e=2*s**2*sum(ipoly(psq((p[1],2*p[2])),lo,hi) for lo,hi,p in cells)
    G=2*(b*(2-s)**2+integrate(cells,F(0),F(1,2)-b))
    norm=F(7,3)
    deficit=norm-a
    gain=G-a
    assert deficit==F(4,3)*s*s-F(32,15)*s**3
    assert e==4*s*s-F(32,3)*s**3
    assert gain==2*b*(3-6*s)-4*(1+s)*b**3/(3*s)-2*b**5/(5*s*s)
    assert 0<e<=3*deficit and G<=(1+12*delta**2)*norm
    return a,e,deficit,G,gain


def quadratic_gain(n):
    root=isqrt(n)
    assert root*root==n
    delta=F(1,2*root)
    first=triangular(F(1,8),delta)
    fit=triangular(2*delta,delta)
    a,e,D,G,g=fit
    norm=F(7,3)
    # G is the actual continuous shift supremum, not an extremum over a grid.
    assert 0<G-norm and F(0)<(G-norm)/delta**2<F(20,3)
    fixed_linear=first[-1]/delta
    assert 0<fixed_linear<F(9,16)
    lower_log=ar(G/norm).log()*n
    cap_log=ar(1+12*delta**2).log()*n
    assert 0<lower_log<cap_log
    return dict(n=n,delta=delta,single_fixed_delta_times_s_radius=delta/8,
                fixed_s=F(1,8),tuned_s_times_delta=2*delta**2,tuned_s=2*delta,
                exact_centered_to_shifted_gain_over_delta_for_fixed_s=fixed_linear,
                fixed_s_shifted_squared_norm_minus_input=first[3]-norm,
                tuned_squared_norm_increase_over_input_divide_delta_sq=(G-norm)/delta**2,
                tuned_relative_increase_over_input_divide_delta_sq=(G-norm)/(norm*delta**2),
                tuned_energy_over_centering_deficit=e/D,
                exact_tensor_fixed_tuned_scale_log_ratio_over_input_Arb=lower_log,
                log_upper_for_any_one_scale_via_energy_Arb=cap_log,
                center_to_offset_tensor_gain_at_fixed_s_log_Arb=ar(first[3]/first[0]).log()*n,
                actual_tensor_fixed_s_relative_to_input_log_Arb=ar(first[3]/norm).log()*n)


def pushforward(cells):
    distribution=defaultdict(F)
    for lo,hi,p in cells:
        a,b=sorted((value(p,lo),value(p,hi)))
        assert a>0
        distribution[a,b]+=(hi-lo) if a==b else (hi-lo)/(b-a)
    assert sum(w if a==b else (b-a)*w for (a,b),w in distribution.items())==1
    return sorted(distribution.items())


def const_vs_affine(x,c,d,K):
    z=K/x
    y=min(max(z,c),d)
    return K*K*(y-c)+x*x*(d**3-y**3)/3


def rectangle(a,b,c,d,K):
    cuts=sorted({a,b}|{z for z in (K/d,K/c) if a<z<b})
    ans=arb(0)
    for lo,hi in zip(cuts,cuts[1:]):
        u=(lo+hi)/2
        if u*d<=K:
            ans+=ar((hi-lo)*(d-c)*K*K)
        elif u*c>=K:
            ans+=ar((hi**3-lo**3)*(d**3-c**3)/9)
        else:
            ans+=ar((hi**3-lo**3)*d**3/9-(hi-lo)*K*K*c)
            ans+=ar(2*K**3/3)*ar(hi/lo).log()
    return ans


def exact_shared_two(dist,mean):
    K=mean**2
    ans=arb(0)
    for ((a,b),w),((c,d),q) in product(dist,repeat=2):
        if a==b and c==d:
            cell=ar(max(a*a*c*c,K*K))
        elif a==b:
            cell=ar(const_vs_affine(a,c,d,K))
        elif c==d:
            cell=ar(const_vs_affine(c,a,b,K))
        else:
            cell=rectangle(a,b,c,d,K)
        ans+=ar(w*q)*cell
    return ans


def above_and_below(dist,threshold,above,power):
    mass=F(0)
    for (a,b),w in dist:
        if a==b:
            if (a>=threshold if above else a<=threshold):
                mass+=w*a**power
            continue
        lo,hi=(max(a,threshold),b) if above else (a,min(b,threshold))
        if lo<hi:
            mass+=w*(hi**(power+1)-lo**(power+1))/(power+1)
    return mass


def private_moment(dist,mean):
    out=F(0)
    for (a,b),w in dist:
        if a==b:
            out+=w*max(a*a,mean*mean)
        else:
            out+=w*const_vs_affine(F(1),a,b,mean)
    return out


def shared_bounds(f, normG, meanG, private, dist, n):
    A=normG/f.norm2
    B=f.mean**2/f.norm2
    H=f.mean*meanG/f.norm2
    D=(A+B)-private/f.norm2
    P=ar(private/f.norm2)**n
    low=ar(A)**n+ar(B)**n-ar(H)**n
    floor=ar(max(A,B))**n
    upper=ar(A)**n+ar(B)**n-ar(D)**n
    assert 0<floor and 0<upper<P
    # Two actual coordinate groups force different private choices. On their
    # product, every common choice loses at least the fixed one-axis factor.
    high,small=F(9,8),F(7,8)
    high_true_sq=above_and_below(dist,f.mean*high,True,2)
    small_true_prob=above_and_below(dist,f.mean*small,False,0)
    correction=(1-max(small*small,1/high**2))*high_true_sq*small_true_prob*f.mean**2
    assert correction>0
    independent_upper=P-ar(correction/f.norm2**2)*ar(private/f.norm2)**(n-2)
    assert independent_upper<P and independent_upper>0
    return dict(share_lower_dominant_single_scale_only_Arb=floor,
                share_lower_from_pointwise_min_le_geometric_mean_Arb=low,
                share_upper_from_product_of_min_per_axis_Arb=upper,
                share_upper_from_true_mixed_choice_groups_Arb=independent_upper,
                private_independent_axis_scales_exact_power_Arb=P,
                true_high_value_sq_and_true_low_value_prob=[high_true_sq,small_true_prob],
                strictly_positive_certified_gap_private_minus_common_via_mixed_groups_Arb=P-independent_upper)


def two_scale(name, f, s, delta):
    g,one=step_test(f,s,delta)
    full,_,_=continuous_step_max(f,F(1,2),delta)
    assert all(p==(f.mean,F(0)) for a,b,p in full)
    dist=pushforward(g)
    u=integrate(g,F(0),F(1))
    v=integrate(g,F(0),F(1),degree=1)
    private=private_moment(dist,f.mean)
    pt=exact_shared_two(dist,f.mean)/ar(f.norm2**2)
    check=shared_bounds(f,u,v,private,dist,2)
    assert check["share_lower_dominant_single_scale_only_Arb"]<pt
    assert check["share_lower_from_pointwise_min_le_geometric_mean_Arb"]<pt
    assert pt<check["share_upper_from_product_of_min_per_axis_Arb"]
    assert pt<check["share_upper_from_true_mixed_choice_groups_Arb"]
    assert pt<ar((private/f.norm2)**2)
    return dict(name=name,input_step_edges=f.edges,input_step_values=f.values,
                n=2,diagnostic_delta=delta,s_1=s,s_2=F(1,2),actual_first_scale=one,
                real_one_dimensional_value_distribution_atoms_and_ramps=dist,
                full_true_joint_shared_two_scale_relative_squared_norm_Arb=pt,
                full_true_private_per_axis_relative_squared_norm=(private/f.norm2)**2,
                independent_product_group_brackets=check)


def larger_step(f,n):
    root=isqrt(n)
    assert root*root==n
    delta=F(1,2*root)
    g,_=step_test(f,F(1,8),delta)
    normG=integrate(g,F(0),F(1))
    meanG=integrate(g,F(0),F(1),degree=1)
    dist=pushforward(g)
    P=private_moment(dist,f.mean)
    result=shared_bounds(f,normG,meanG,P,dist,n)
    return dict(n=n,delta=delta,scale_set=[F(1,8),F(1,2)],
                exact_one_axis_norm2s_and_private=[normG,f.mean**2,P],reference_input_squared_norm=f.norm2,
                certified_multiaxis_relative_squared_values=result)


def fourier():
    rows=[]
    for t in (F(1,2**40),F(1,2**16),F(1,16),F(1,2),F(1),F(3,2),F(22,7),F(10)):
        x=ar(t)
        s=x.sin()
        ratio=s*s/(1-(s/x)**2)
        assert 0<ratio<3
        rows.append(dict(t=t,actual_Fourier_energy_ratio_Arb=ratio,deficit_under_3_Arb=3-ratio))
    return rows


def main():
    p=argparse.ArgumentParser(description=__doc__)
    out=p.add_mutually_exclusive_group()
    out.add_argument("--output",type=Path)
    out.add_argument("--check",type=Path)
    a=p.parse_args()
    simple=Step((0,F(1,4),1),(2,1))
    pressure=Step((0,F(1,8),F(3,8),F(1,2),F(7,8),1),(4,1,F(5,2),1,2))
    d=dict(
        arithmetic="Exact Fraction on positive periodic profiles; 256-bit Arb natural log integrals and outward tensor bounds.",
        python={"executable":sys.executable,"version":platform.python_version(),
                "architecture":platform.machine(),"python_flint":flint.__version__},
        command="python -B offset795.py --check offset795.json",
        scope=("Torus period one, averaging over [w-s,w+s] with probability normalization. "
               "The tensor signals are products of the same positive single-axis profile. "
               "Continuous shifts are searched through exact envelope breakpoints. "
               "The finite common-scale test has two s values; no assertion about the "
               "operator over all scales on arbitrary signals follows from this fixture."),
        shared_scale_two_axis_pressure=[
            two_scale("positive_single_step",simple,F(1,8),F(1,8)),
            two_scale("positive_asymmetric_multiple_steps",pressure,F(1,8),F(1,4))],
        fixed_scale_triangular_exact_growth=[quadratic_gain(n) for n in (64,1024,16384,2**20)],
        certified_common_scale_high_dimension=[larger_step(simple,n) for n in (4,16,64,256,4096)],
        Fourier_deficit_ratio_near_sharp_and_in_tail=fourier())
    text=(json.dumps(d,indent=2,sort_keys=True,default=str)+"\n").encode()
    if a.output:
        a.output.write_bytes(text)
    elif a.check:
        if a.check.read_bytes()!=text:
            raise SystemExit("certificate differs")
        print("offset795: continuous step envelopes, common scales and quadratic fixed-scale gain agree")
    else:
        print(text.decode(),end="")


if __name__=="__main__":
    main()

