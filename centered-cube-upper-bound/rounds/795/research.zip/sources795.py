"""R795: common binary source stops and receiver unions with actual source price."""

import argparse
from dataclasses import dataclass
from fractions import Fraction as F
from itertools import combinations, product
import json
from pathlib import Path
import platform
import sys


N, A, R = 2, 64, F(16)
H0=F(3,2)


def total(x):
    return sum(x,F(0))


def width(a,b):
    return max(F(0),b-a)


def split_points(interval, lines):
    lo,hi=interval
    cuts={lo,hi}
    for (a,u),(b,v) in combinations(lines,2):
        if u!=v:
            x=(b-a)/(u-v)
            if lo<x<hi:
                cuts.add(x)
    return sorted(cuts)


def mid(a,b):
    return (a+b)/2


def ceil(x):
    return -(-x.numerator//x.denominator)


def log2_floor(x):
    j=x.numerator.bit_length()-x.denominator.bit_length()
    return (j-1) if F(2)**j>x else j


def section(a,b):
    return max(a[0],b[0]),min(a[1],b[1])


def area(b):
    return width(*b[0])*width(*b[1])


def box(c,s):
    return tuple((x-s,x+s) for x in c)


def mass(mu,b):
    return mu.integrate(*b[0])*width(*b[1])


@dataclass(frozen=True)
class Parent:
    label: str
    c: tuple
    s: F

    @property
    def A(self):
        return box(self.c,self.s)

    @property
    def E(self):
        return box(self.c,self.s/A)


class Price:
    """Compact nonuniform absolutely continuous price; opposite halves pair exactly."""
    def __init__(self,dips):
        edges=sorted({F(0),F(8),R}|{k for segment in dips for k in segment})
        slabs=[]
        for a,b in zip(edges,edges[1:]):
            x=mid(a,b)
            value=(F(1) if x>=8 else F(1,4) if any(lo<x<hi for lo,hi in dips) else F(7,4))
            slabs.append((a,b,value))
        self.cells=[(-b,-a,2-k) for a,b,k in reversed(slabs)]+slabs

    def integrate(self,a,b):
        return total(k*width(max(a,lo),min(b,hi)) for lo,hi,k in self.cells) if a<b else F(0)

    def largest(self,a,b):
        return max(k for lo,hi,k in self.cells if width(max(a,lo),min(b,hi))>0)


def first_stops(mu):
    # x then y binary splits. Density is constant in y. A first >h0 node
    # therefore occurs on a split in x, and then y side is twice its x side.
    stacks=[(-R,R,None,0)]
    out=[]
    diffuse=[]
    while stacks:
        a,b,parent_density,depth=stacks.pop()
        p=mu.integrate(a,b)/(b-a)
        if p>H0:
            assert depth and parent_density<=H0 and H0<p<=2*H0
            ly=2*(b-a)
            Ny=2*R/ly
            assert Ny.denominator==1
            out.append((a,b,ly,p,depth))
            continue
        if mu.largest(a,b)<=H0:
            diffuse.append((a,b))
            continue
        h=mid(a,b)
        stacks.extend(((h,b,p,depth+1),(a,h,p,depth+1)))
    by_x=sorted([(a,b) for a,b,*_ in out]+diffuse)
    assert by_x[0][0]==-R and by_x[-1][1]==R
    assert all(u[1]==v[0] for u,v in zip(by_x,by_x[1:]))
    assert total(mu.integrate(a,b) for a,b,*_ in out)+total(mu.integrate(*p) for p in diffuse)==2*R
    return sorted(out),sorted(diffuse)


def category(shortest_side,s):
    if shortest_side<=s/N:
        return "small"
    if shortest_side>=N*s:
        return "large"
    return "middle"


def audit_stops(mu,stops,p):
    per={k:dict(box_count=0,source_in_parent=F(0),whole_source_boxes=F(0))
         for k in ("small","middle","large")}
    small_volume=F(0)
    m=mass(mu,p.A)
    assert m==area(p.A)
    a,b=p.A[1]
    for l,r,ylen,density,_ in stops:
        xpart=section((l,r),p.A[0])
        if width(*xpart)==0:
            continue
        i=max(0,int((a+R)//ylen))
        j=min(int(2*R/ylen),ceil((b+R)/ylen))
        cnt=j-i
        assert cnt>0
        k=category(ylen/2,p.s)
        val=per[k]
        val["box_count"]+=cnt
        val["source_in_parent"]+=mu.integrate(*xpart)*(b-a)
        val["whole_source_boxes"]+=mu.integrate(l,r)*ylen*cnt
        if k=="small":
            small_volume+=(r-l)*ylen*cnt
            expansion=p.s*(1+F(2,N))
            assert p.c[0]-expansion<=l and r<=p.c[0]+expansion
            assert p.c[1]-expansion<=-R+i*ylen and -R+j*ylen<=p.c[1]+expansion
    diffuse=m-total(v["source_in_parent"] for v in per.values())
    cap=2*H0*area(box(p.c,p.s*(1+F(2,N))))
    assert per["small"]["whole_source_boxes"]<=2*H0*small_volume<=cap
    assert diffuse>0 and per["small"]["box_count"]>0 and per["large"]["box_count"]>0
    return dict(parent=p.label,true_m=m,actual_volume=area(p.A),expanded_small_boxes_bound=cap,
                disjoint_small_box_physical_total_volume=small_volume,
                category_counts_and_masses=per,diffuse_source_mass_in_parent=diffuse)


def terrain(stage):
    dips=[(F(1,64),F(1,32)),(F(1,2),F(1))]
    if stage>=2:
        dips.append((F(2),F(5,2)))
    if stage>=3:
        dips.append((F(1,1024),F(1,512)))
    return Price(dips),dips


def root_family(stage):
    w=F(4); r=w/A; eps=r/200
    y0=(r/100,F(3,4))
    Y=box(y0,eps)
    W=[Parent("start_minus",(F(0),-3*r/2),w),Parent("start_plus",(F(0),3*r/2),w)]
    rr=[F(3,4),F(3,2)] if stage==1 else [F(1,4),F(3,4),F(3,2)]
    if stage>=3:
        rr.append(F(5,2))
    T=[]
    for j,s in enumerate(rr):
        rho=s/w
        displacement=r/8 if j%2==0 else -r/8
        T.append(Parent("end_"+str(j),(F(0),(1-rho)*y0[1]+rho*displacement),s))
    assert all(area(tuple(section(a,b) for a,b in zip(u.E,v.E)))==0
               for u,v in combinations(W+T,2))
    assert all(a<=l<h<=b for t in T for (a,b),(l,h) in zip(t.A,Y))
    return W,T,Y


def equations(origin,ends,axis):
    low,high=origin.E[axis]
    lower=[(low,F(0))]
    upper=[(high,F(0))]
    for t in ends:
        rho=t.s/origin.s
        assert 0<rho<1
        m=(rho-1)/rho
        a,b=t.E[axis]
        lower.append((a/rho,m))
        upper.append((b/rho,m))
    return lower,upper


def affine_length(qs,y):
    l,h=qs
    return width(max(a+b*y for a,b in l),min(a+b*y for a,b in h))


def exact_overlap_integral(origin,group,Y,source_density):
    by_axis=[]
    for axis in range(2):
        q=equations(origin,group,axis)
        cuts=split_points(Y[axis],q[0]+q[1])
        by_axis.append(total((b-a)*affine_length(q,mid(a,b)) for a,b in zip(cuts,cuts[1:])))
    return source_density*by_axis[0]*by_axis[1]


def integrated_reception(mu,W,T,Y):
    source_density=mu.integrate(*Y[0])/(Y[0][1]-Y[0][0])
    assert source_density==F(7,4)==mu.largest(*Y[0])
    subsets=[(subset,(-1)**(length+1)) for length in range(1,len(T)+1)
             for subset in combinations(T,length)]
    individual={}
    pair_overlaps={}
    one=[]
    for source in W:
        for t in T:
            individual[source.label,t.label]=exact_overlap_integral(source,(t,),Y,source_density)
            assert individual[source.label,t.label]>0
        for t,s in combinations(T,2):
            h=exact_overlap_integral(source,(t,s),Y,source_density)
            assert h>0
            pair_overlaps[source.label,t.label,s.label]=h
        one.append(total(q*exact_overlap_integral(source,ss,Y,source_density) for ss,q in subsets))
    # All affine-order breakpoints in the common y patch. On every product cell
    # the summed positive receiver length products are bilinear, so exact midpoint
    # integration independently recomputes the total starting receiver union.
    common_cuts=[]
    for axis in range(2):
        lines=[]
        for source in W:
            x,y=equations(source,T,axis)
            lines+=x+y
        r=split_points(Y[axis],lines)
        common_cuts.append(list(zip(r,r[1:])))
    fixed_first=F(0)
    first_sup=F(0)
    for ((a,b),(c,d)) in product(*common_cuts):
        price=(mid(a,b),mid(c,d))
        whole=F(0)
        for source in W:
            real=F(0)
            for ss,k in subsets:
                real+=k*affine_length(equations(source,ss,0),price[0])*affine_length(
                    equations(source,ss,1),price[1])
            assert 0<real<=area(source.E)
            whole+=real
        first_sup=max(first_sup,whole)
        fixed_first+=whole*(b-a)*(d-c)*source_density
    repeated=total(individual.values())
    assert fixed_first==total(one)<repeated
    assert fixed_first<=mass(mu,Y)*total(area(w.E) for w in W)
    return dict(
        root_terminal_accepted_receiver_fees=[(*key,m) for key,m in sorted(individual.items())],
        true_pair_overlap_receiver_fees=[(*key,m) for key,m in sorted(pair_overlaps.items())],
        separate_original_roots_each_union_then_integrate=one,
        fix_y_union_and_sum_all_roots_then_integrate_exact=fixed_first,
        erroneous_count_whole_receiver_for_each_terminal=repeated,
        true_once_over_reused=fixed_first/repeated,
        fixed_price_cell_count=len(common_cuts[0])*len(common_cuts[1]),
        max_midpoint_total_actual_receiver_volume=first_sup),individual


def octaves(mu,stops,terminals):
    xx=sorted({x for t in terminals for x in t.A[0]}|{a for row in stops for a in row[:2]})
    yy=sorted({v for t in terminals for v in t.A[1]})
    masses={}
    witness={}
    for (a,b),(c,d) in product(zip(xx,xx[1:]),zip(yy,yy[1:])):
        x,y=mid(a,b),mid(c,d)
        p=next((row for row in stops if row[0]<x<row[1]),None)
        parents=[u for u in terminals if all(l<q<h for (l,h),q in zip(u.A,(x,y)))]
        if not parents:
            continue
        types=tuple(sorted({log2_floor(u.s) for u in parents}))
        mids=tuple(sorted({log2_floor(u.s) for u in parents if p and category(p[2]/2,u.s)=="middle"}))
        key=(types,mids)
        masses[key]=masses.get(key,F(0))+mu.integrate(a,b)*(d-c)
        witness.setdefault(key,(x,y,tuple(u.label for u in parents),p[2]/2 if p else None))
    assert all(len(m)<=len(k) and len(m)<=2 for k,m in masses)
    broad=max(len(k) for k,m in masses)
    mid_count=max(len(m) for k,m in masses)
    assert broad==len({log2_floor(u.s) for u in terminals}) and mid_count>0
    return dict(actual_max_distinct_available_octaves_y_in_A=broad,
                actual_max_octaves_where_the_true_stop_is_middle=mid_count,
                actual_price_mass_by_available_and_middle_octaves=[(k,m,w,witness[k,m])
                                                                      for (k,m),w in sorted(masses.items())])


def new_prices(mu,stops,Y,ends):
    y=tuple(mid(*axis) for axis in Y)
    a,b,len_y,_,_=next(row for row in stops if row[0]<y[0]<row[1])
    j=(y[1]+R)//len_y
    old=((a,b),(-R+j*len_y,-R+(j+1)*len_y))
    assert all(a<=l<h<=b for (a,b),(l,h) in zip(old,Y))
    rows=[]
    for t in ends:
        assert category(len_y/2,t.s)=="large"
        common=mass(mu,tuple(section(a,b) for a,b in zip(t.A,old)))
        M=mass(mu,t.A)
        assert 0<common<M
        rows.append(dict(t=t.label,right_actual_source_denominator=M,
                         probability_z_is_in_same_source_stopped_box=common/M,
                         probability_new_z_is_outside_that_actual_box=1-common/M))
    return dict(common_old_actual_stopped_box=old,true_source_price_mass_of_old_box=mass(mu,old),
                fresh_source_draw_continuous_law="mu restricted to actual terminal A_t and divided by m_t",
                per_actual_terminal_new_source=rows)


def joint_distinction(individual,W,T):
    # w is uniform in the exact reachable rectangle for each y, branch, root.
    # U is a separately observed point in real E_t. Split each rectangle in
    # its second coordinate into equal halves. Keep matching vs opposing halves.
    prob=F(1,len(T))
    base=total(individual.values())*prob
    assert base>0
    joint_tables={}
    for sign in ("same","opposite"):
        arr=[[F(0),F(0)],[F(0),F(0)]]
        physical_by_terminal={}
        for end in T:
            M=total(value for (s,t),value in individual.items() if t==end.label)*prob
            for row,col in product(range(2),repeat=2):
                if (row==col)==(sign=="same"):
                    arr[row][col]+=M/2
            # The two marginals are identical before integrating y: their
            # density is lambda times 1/area(E_t) times the receiver lengths.
            physical_by_terminal[end.label]=dict(
                right_terminal_actual_probe_volume=area(end.E),
                actual_joint_total_mass_this_terminal=M,
                pointwise_three_variable_density_cap=2*prob/area(end.E),
                pointwise_y_U_density_cap=prob*total(area(w.E) for w in W)/area(end.E))
        assert [sum(r) for r in arr]==[base/2]*2
        assert [arr[0][i]+arr[1][i] for i in range(2)]==[base/2]*2
        joint_tables[sign]=dict(actual_W_U_half_joint_mass=arr,by_terminal=physical_by_terminal)
    assert joint_tables["same"]["actual_W_U_half_joint_mass"][1][1]==base/2
    assert joint_tables["opposite"]["actual_W_U_half_joint_mass"][1][1]==0
    return dict(
        exact_original_contracted_receiver_subflow_with_fixed_terminal_prior=base,
        same_exact_both_one_probe_margins=True,
        normalized_both_upper_probabilities=[F(1,2),F(0)],
        both_real_two_probe_couplings=joint_tables)


def case(stage):
    mu,dips=terrain(stage)
    stops,diffuse=first_stops(mu)
    W,T,Y=root_family(stage)
    assert all(mass(mu,p.A)==area(p.A) for p in W+T)
    fixed,ind=integrated_reception(mu,W,T,Y)
    checks=[audit_stops(mu,stops,t) for t in T]
    assert any(d["category_counts_and_masses"]["middle"]["source_in_parent"]>0 for d in checks)
    return dict(
        stage=stage,h0=H0,real_positive_side_dips=dips,price_value_intervals=mu.cells,
        actual_parent_centres_radii_and_owner_volume=[(p.label,p.c,p.s,area(p.E)) for p in W+T],
        actual_left_price_y_patch=Y,old_price_patch_actual_source_mass=mass(mu,Y),
        stopped_x_slabs_and_alt_axis_intermediate_draw_size=stops,
        diffuse_x_intervals=diffuse,
        jointly_stopped_by_x_slab_counts_same_y_partition=sum(int(2*R/s[2]) for s in stops),
        small_middle_large_diffuse_and_true_m=checks,
        true_big_source_receiver_union_fee=fixed,
        present_octaves=octaves(mu,stops,T),
        actual_freshly_sampled_sources_vs_older_stop=new_prices(mu,stops,Y,T),
        exact_same_single_probe_different_both_probes=joint_distinction(ind,W,T))


def main():
    p=argparse.ArgumentParser(description=__doc__)
    out=p.add_mutually_exclusive_group()
    out.add_argument("--output",type=Path)
    out.add_argument("--check",type=Path)
    opt=p.parse_args()
    doc=dict(
        arithmetic="Exact Fraction for all source and receiver integrals",
        python={"executable":sys.executable,"version":platform.python_version(),"architecture":platform.machine()},
        command="python -B sources795.py --check sources795.json",
        scope=("A two-dimensional compact true source with nonuniform first-axis density obeying f(x)+f(-x)=2. "
               "The global first-stop binary tree alternately halves the two axes, beginning with x. A stopped P crosses "
               "mu(P)>h0|P| and its parent does not. Diagnostic size cut relative to terminal radius s uses "
               "shortest full side b(P)<=s/n for small and b(P)>=n*s for large. All physical parent masses equal their volumes, "
               "and all actual center owner cubes are disjoint. Reachability in the true two-price patch is "
               "the actual affine contraction of w; U for the two-probe diagnostic is an additional independent "
               "terminal owner sample before the displayed same/other halves screen. This tests the finite "
               "source stop and receiving measure interfaces."),
        three_stages=[case(k) for k in (1,2,3)])
    data=(json.dumps(doc,sort_keys=True,indent=2,default=str)+"\n").encode()
    if opt.output:
        opt.output.write_bytes(data)
    elif opt.check:
        if opt.check.read_bytes()!=data:
            raise SystemExit("certificate differs")
        print("sources795: true first stops, new source and common recipient union agree")
    else:
        print(data.decode(),end="")


if __name__=="__main__":
    main()

