# R163 独立初审：原high、三种源测度与共享alpha

只写audit.md，不Git、不改他人。仅读本轮task_contract.md及R147归档audit_astra.md §1–2核对原AA1–2合同；未读本轮作者稿，不重复推旧截顶势。

## 1. 原high的准确量词与三种测度

固定同一实际行(ω,V,j,x,y)及其接收参数。Q,p,q,g、terminal good/bad、ρ和共同ν在当前t∈[τ,h]内固定，并先于外hard第三来源积分选定。它们可依receiver x，但不能逐来源或逐t重选。原合同是
\[
 q\ge\int Q_vd\nu,\quad q\ge Q_J=\int J_vd\nu,\quad
 p e_g\ge2Kq,\quad e_t\ge e_g.
\tag{H1}
\]
本轮不能只使用q≥Q_J而遗忘q≥∫Q。q=0或零来源按原零交通；非零正有限high行必有p,e_g,e_t,q>0。

定义三种不同源测度：
\[
 d\mu_Q=Q_vd\nu/q,\quad \|\mu_Q\|\le1;
 \qquad
 d\Pi_g=1_{Z_g}w_gd\nu/e_g;
 \qquad
 d\mu_{z_g}=1_{B_0}w_gd\nu/E_{z_g}.
\tag{H2}
\]
后两者各自在对应有效域上是概率，第一种仅为次概率。实际
\[
 e_g=\int_{Z_g}w_gd\nu,\qquad
 E_{z_g}=\int_{B_0}w_gd\nu,\qquad
 \eta_g=e_g/E_{z_g}\le1.
\]
不得把deleted terminal e_g等同B₀上的E_{z_g}。也不得把μ_Q条件归一化后丢掉其总质量。

令L_g=Kq/(p e_g)≤1/2，r_g(v)=KQ_v/(p w_g(v))。原终端后验准确为
\(d\Pi_g=1_{Z_g}L_g r_g^{-1}d\mu_Q\)。终端good有r_g≥1，bad严格r_g<1。

## 2. high究竟限制哪一种good质量

令G_g=Z_g∩{p w_g≤KQ}为终端后验内完整good集合。对任意非负可测f支持G_g，
\[
 \int f\,d\Pi_g\le L_g\int f\,d\mu_Q.
\tag{H3}
\]
因此Π_g(G_g)≤L_g μ_Q(G_g)≤1/2。实际terminal role S_g、E_+=G_g∩{ρ>0}若带额外资格只是其子集。若D_g^{bad}=Z_g\setminus G_g为完整严格bad补集，则
\[
 \Pi_g(D_g^{bad})\ge1-L_g\mu_Q(G_g)\ge1/2.
\tag{H4}
\]
如果某记号D₀还带额外门，只能对完整bad集合使用此下界，不能据此声称D₀子域也有半质量。

H3不能反向推出μ_Q(G_g)≤1/2；共同Q次概率的good质量只有≤1及其实际数值。对B₀上的完整good集合G_{B₀}（可含已删来源），另可正确推出
\[
 \mu_{z_g}(G_{B_0})
 \le\frac{Kq}{pE_{z_g}}
 =\eta_g L_g\le\eta_g/2.
\tag{H5}
\]
这保留了e_g/E_{z_g}而未将两者混同。μ_{z_g}本身随实际g(x)变化，H5是逐实际行约束，不因此成为独立于receiver选择的固定积分概率。

还可保原J责任χ_J=J/(3Q)。因q≥Q_J，μ_J=Jν/q亦为次概率；对0≤f≤1支持G_g，
\[
 \int f\chi_Jd\Pi_g
 \le\frac{K}{3pe_g}\int fJ_vd\nu
 =\frac{L_g}{3}\int f\,d\mu_J\le1/6.
\tag{H6}
\]
这只是终端行质量约束，不是完整receiver/time付款。

## 3. 当前与终端的合法组合

原Z_g⊂Z_t，故对终端存活来源准确有
\[
 d\Pi_t|_{Z_g}
 =\frac{e_g}{e_t}\frac{w_t}{w_g}\,d\Pi_g,\qquad
 \frac{e_g}{e_t}\le1,\quad \frac{w_t}{w_g}\ge1.
\tag{H7}
\]
后一个增长因子不能丢掉；e_t≥e_g不使当前Π_t-good自动继承终端的1/2或J责任1/6帽。

更一般地，R147 AA2的原身份为
\[
 d\Pi_t=1_{Z_t}L_t r_t^{-1}d\mu_Q,\quad
 L_t=\frac{Kq}{pe_t}
 =L_g\frac{e_g}{e_t}\le1/2,\quad
 r_t=\frac{KQ_v}{pw_t}=r_g\frac{w_g}{w_t}\le r_g.
\tag{H8}
\]
good条件是r_g≥1，不是早时r_t≥1。若要上界当前good质量，必须保留1/r_t或w_t/w_g，例如
\[
 \Pi_t(G_g)\le L_t\int_{G_g}(w_t/w_g)d\mu_Q,
\quad
 \int_{G_g}f\chi_Jd\Pi_t
 \le(L_t/3)\int_{G_g}f(w_t/w_g)d\mu_J.
\tag{H9}
\]
在原w_t产品结构中可用w_t/w_g≤(g/t)^n，但这是可能很大的维数费用，不能省略。当前归一化还给
\[
 \int_{Z_t}r_t^{-1}d\mu_Q=1/L_t,\qquad
 \int r_t\,d\Pi_t=L_t\mu_Q(Z_t)\le L_t.
\]
这些是同一原次概率下的准确矩，不授权按t分别重归一化μ_Q。e_t、E_z各自单调也不强制η_t=e_t/E_z有统一正下界或与η_g单调比较。

本节不微分e_t/Z_t，不重推R147截顶势；只核当前—终端量词与可用质量界。

## 4. high与共享alpha的严格合法组合

原完整同一余额为
\[
 \alpha Q_J+\int U_vd\nu=Dq,\qquad
 U=1_{\rm good,\Delta>0}\min(T\Delta,DK_0).
\]
因原α,U非负，H1合法给
\[
 \frac{\alpha Q_J+\int U\,d\nu}{pe_g}
 =\frac{Dq}{pe_g}\le\frac{D}{2K},
 \qquad
 \frac{Q_J}{e_g}\le\frac p{2K}.
\tag{H10}
\]
这是全来源预算的上界，不能由它反向推出α有统一正下限。坏来源无U消耗、q≥∫K₀ν、U≤DK₀还给
\[
 \alpha Q_J\ge D\int_{\rm bad}K_0d\nu.
\tag{H11}
\]
若仅当前pair/部分good满足几何，其他good的U_rest仍必须保留；不能用终端good半质量替代全消耗支持。尤其U/(w_g)没有合同内的统一上界，故从Π_g(G_g)≤1/2本身不能估∫U。

在D>0、原s>0使K₀处处严格正、非零有限high行上，H4还蕴含α>0：完整terminal bad集合有正ν质量，故∫badK₀ν>0，H11及Q_J>0强制α>0。此仅为严格正性，绝非统一定量下限；不能免费控制α的负幂。D=0时不作该推论。

更定量地，记B=完整terminal bad集合、b_g=Π_g(B)≥1/2。由B⊂Z_g，
\[
 \int_BK_0d\nu=e_g\int_B(K_0/w_g)d\Pi_g.
\]
故共享容量与high合用得到
\[
 b_g\,\mathbb E_{\Pi_g|B}(K_0/w_g)
 \le\frac{\alpha Q_J}{De_g}\le\frac{q}{e_g}
 \le\frac p{2K},
\quad
 \mathbb E_{\Pi_g|B}(K_0/w_g)\le p/K.
\tag{H12}
\]
该结论是同一terminal bad后验的平均核比约束，不能强化为每个bad u的pointwise小核门，也不能直接替换成当前Π_t或受额外门的D₀条件概率。K₀/w_g没有统一正下限，仍不产生α^-1预算。

ρ>0只在good端且Δ>0上给DK₀+αJ<TΔ；T、Δ、K₀和α均按同一实际selector/全部来源构造。高区质量界与此严格储备条件可以联合保留，但不能分别优化它们或丢掉其他来源消费。

## 5. 初审结论与作者验收项

原high明确限制deleted terminal good质量及终端J责任，另给带η_g的共同core-good质量；不把μ_Q误作概率，也不将其good质量误限为1/2。当前good质量必须保增长比w_t/w_g和同一e_t归一化。共享α可与high合成H10–12，严格正性与定量预算仍须区分。

后续命题须逐项保留：q≥∫Q与q≥Q_J的不同用途；Z_g/Z_t及e_g≠E_{z_g}；实际g/ρ在整窗固定但可依receiver；原pair score与good/bad同点；α全来源消费及未付低核比门；原hard/唯一j/时间与真实外β。没有由以上row质量不等式得到一般root闭合，也不登记旧截顶势为新结果。

初审检查点完成，未读本轮作者；等待精确命题，不另扩展。

## 6. 新补偿耦合：独立盲核

本节在未读本轮作者稿时核验。固定同一实际receiver、selector及原完整来源行；假设p,e_g,q>0，所有核、g、删除集和共享α取原值。以下R(v)=KQ(v)/(pw_g(v))是终端似然比，不是尺度参数。令π_g=1_{Z_g}w_gν/e_g，则
\[
 \int R\,d\pi_g=\frac K{pe_g}\int_{Z_g}Q\,d\nu
 =L_g\mu_Q(Z_g)\le L_g\le\tfrac12.
\tag{C1}
\]
这里μ_Q仍仅为次概率，未把其缺额填成新来源。

记G={R≥1}、a=1_G(2R−1)、d=(1−2R)_+、A=∫a dπ_g、S=∫d dπ_g。补偿d与旧平方余量d_v不是同一对象。由C1，
\[
 0\le A\le\int(2R-1)_+d\pi_g\le S\le1.
\tag{C2}
\]
准确差为S−A=1−2∫R dπ_g+∫_{1/2<R<1}(2R−1)dπ_g。若S=0，R≥1/2 a.e.与C1合成R=1/2 a.e.，因而A=π_g(G)=0；此时Γ=0合法。若S>0，定义
\[
 d\Gamma(v,w)=\frac{a(v)d(w)}S\,d\pi_g(v)d\pi_g(w).
\]
则
\[
 \Gamma_v=a\pi_g,\qquad
 \Gamma_w=(A/S)d\pi_g\le d\pi_g,\qquad
 \Gamma(Z_g^2)=A\le1.
\tag{C3}
\]
Γ是次概率补偿耦合，不是原Π_t⊗Π_t。G保留good闭端R=1；补偿端严格在R<1/2，故包含于完整terminal bad的严格端R<1；R=1/2处无补偿质量，区间[1/2,1)的bad质量未被匹配。

### 6.1 共享α能支付的精确补偿矩

另需原D>0。令κ_0(w)=2KK_0(w)/(pw_g(w))。C3与H11给
\[
 \int\kappa_0(w)d\Gamma
 \le\frac{2K}{pe_g}\int_{Z_g,R<1/2}d(w)K_0(w)d\nu(w)
 \le\frac{2K\alpha Q_J}{Dpe_g}
 \le2L_g\le1.
\tag{C4}
\]
更精确的全消费余额为
\[
 \frac{2K\alpha Q_J}{Dpe_g}
 =2L_g-\frac{2K}{Dpe_g}\int U\,d\nu.
\tag{C5}
\]
因此该矩帽成立，不需除以α；但D=0时不能引用C4的除D形式。不能把ν、q、U、α重新截到Z_g后沿用此结论，不能以q的次概率缺额补偿任意新增来源。原D₀若比完整terminal bad更小，C4只说明补偿支持在完整bad，不能额外断言其落在D₀或满足原pair低c门。

### 6.2 当前边际的恢复范围

在G上令
\[
 M_t(v)=\frac{e_g}{e_t}\frac{w_t(v)}{w_g(v)}
              \frac1{2R(v)-1},
\]
其余处取0。利用Z_g⊂Z_t和C3，得到精确测度恒等式
\[
 M_t\,\Gamma_v
 =1_G\frac{e_g}{e_t}\frac{w_t}{w_g}\pi_g
 =1_{G\cap Z_g}\Pi_t.
\tag{C6}
\]
原交通若另有限制S_g或ρ>0，须把该限制继续放在同一v上。C6没有恢复Z_t\Z_g中的当前good端。在t=g，M_g≤1；在较早t，w_t/w_g≥1且可增长，不能由high删除它。可用粗界仅是
\[
 M_t\le(e_g/e_t)(w_t/w_g)
 \le(e_g/e_t)(g/t)^n.
\]
Γ在固定实际行上不随当前t改变，但可依x及其selector/g，不能将它当成receiver独立来源，免费交换dx或作固定参数乘积核积分。

### 6.3 原pair仍须保留，当前无新增交通付款

Γ_w≤dπ_g是从下方被完整bad后验支配，不是对原badΠ_t的上支配；以补偿w替换原u会改变δ(v,u)、当前k_u、原D₀及pair低c门。特别中间bad带1/2≤R<1和可能的Z_t\Z_g来源没有由Γ恢复。

可供后续使用的严格提升恒等式是：对任意非负、保留原资格的实际pair函数F_t(v,u)，
\[
 \int_{G\cap Z_g}\!\Pi_t(dv)\int F_t(v,u)\Pi_t(du)
 =
 \int\!M_t(v)\left[\int F_t(v,u)\Pi_t(du)\right]
                   \Gamma(dv,dw).
\tag{C7}
\]
这里原u及其δ(v,u)、bad/删除/低c门均仍在F_t内部，w只是额外补偿标签。C4只控制κ_0(w)的Γ平均；合同尚未给出C7右侧被积项与κ_0(w)的联合接收/时间支配。故耦合及其矩预算通过，原pair的新付款尚未成立，不能将其登记成一般root闭合或省略负账。q外消费、原ρ/共同α、hard/history/唯一j和未付补集继续保持。

本次准确命题独立核验完成；只交付C1–C7及以上边界，未读作者稿、不扩展路线。

## 7. 主稿有界后审检查点

实际阅读research.tex后，主稿的S=A+B+H分解与C2的准确差一致：B保留1/2<R<1的中间正矩，H同时保留high余额与q−∫Z_g Qν，不把外来源消费删去。三核分离是严格Q_v/w_g(v)>2Q_w/w_g(w)在三项和上的逐点推论；按固定顺序作互斥可测三支合法，但不指定J必须承担，也未登记三支新付款。主稿G已定义为{R≥1}∩Z_g，故其当前lift正好C6–C7，不漏原u或将补偿w替为bad；若终端嵌套未用必须加Z_t交集的说明正确。κ预算、D>0、S=0、真实ρ及原低c/D₀等门、当前w_t/w_g和全部外价的未付范围均与本审一致，未发现新增闭合断言。

该检查点绑定research.tex SHA256：79c6988a15b04a17b779461222f02e57b0ad8d859815aa68ae11765ed707893d。rank-one附件尚未交付，本审暂不冻结最终版本，不审核未运行数值。

## 8. 作者稿与有限精确计算后审

实际阅读joint_high_geometry.md，HG3–6完整保留σ/ξ、一般可测good子集G及其外需求P−G_+；HG10–14同α补偿矩和低κ/d尾的方向正确。HG15–19准确区分当前倾斜与未倾斜预算，原u保持独立角色；HG17的2^n使用原z≥a/b≥1/2、z_g≤1及t≤g，不是终端到当前的常数比较。HG19a–b三核分离与本审一致。HG21粗价由(2Λ)(16/3)(n/4)(log2)·3(2n+3)D_n正确得到8Λn(log2)(2n+3)D_n，只在其列明的原合法hard/history域上使用，未冒充新root付款。

静态阅读compensation_check.py、JSON摘要及配套md，不重复运行。其有限运输原始问题为固定行需求、列供给上限的最小b_iκ_j费用；列对偶势v_j≤0及u_i+v_j≤b_iκ_j确给下界：∑flow·cost≥∑demand·u+∑supply·v。代码逐项核原始可行、每个对偶约束及有理原始值=对偶值，故有限样本零gap足以认证各样本最优，未仅依赖排序启发式。空需求、ties、κ=0分支均显式处理。恢复因子b_i=T_i/[Z(2R_i−1)]给∑_j b_iΓ_ij=T_iπ_i/Z，保留同一个Z；这是共同支持的抽象倾斜恢复，不宣称恢复原Z_t外新来源。

κ统一乘1/max(1,∑κπ)，确使终端κ矩≤1；该操作是合成输入归一化，不能充作原核/共同α的构造。正统一缩放保持成本排序、最优流及与供给预算的费用比；但会改变“超过1”的绝对判断，代码与md均按缩放后的实际费用重新检查。JSON报告104个抽象有限模型、460个good边际恢复、908列、5398个对偶约束、99例严格改善、2例倾斜最优费超未倾斜供给预算、1例超1，与源码输出项一致。它们不是FULL几何实例、不是104个原receiver或独立核样本，也不构成维数增长或中soft不可能性的证明。

本审未重跑数值；父级报告已在独立目录实际重放，除runtime外数学字段一致。当前JSON中source/contract哈希与实际文件一致。本节绑定：
- joint_high_geometry.md：d8968138824b4642f94ea1dbcac095c814c3451144b9bed17fef24dc537dc717
- compensation_check.py：b9aef6d3c49dd104c2aa813997cccead442b099816d2a28459598f72027c1539
- compensation_check.json：c07318a830108ed099be7ec36086fea76a9742ad2a07206919d0b7552a1a3b02
- compensation_check.md：38b9aeb403dc2dd0b19add9df0a4e86b47008a8666074f2f387dbc2939cbf8db

以上未发现需修正项。rank-one一般补偿附件待交付；不把有限样本证书提升为一般测度达值定理。

## 9. rank-one补偿极值独立筛查与后审

先独立核验：任意有限正μ、σ，质量A≤S，非负有限可测b、κ，均有
\[
 \inf_{\Gamma_v=\mu,\ \Gamma_w\le\sigma}\int b\kappa\,d\Gamma
 =\int_0^A b_\mu^\downarrow(r)\kappa_\sigma^\uparrow(r)dr
 =\int_0^\infty\int_0^\infty
   [\mu\{b>t\}-\sigma\{\kappa\le s\}]_+ds\,dt .
\tag{O1}
\]
第一边事件质量固定、第二边低κ质量至多容量，给layer-cake下界；两分位数事件在rank坐标上占据左端及右端，交长即正部。可数几何值域bins（正值上取1+ε倍，零值独立）上的rank交长λ_ij乘归一化限制测度之乘积，给第一边际μ、第二边际≤σ的明确计划，费用≤(1+ε)^2排序积分。此构造不要求原子能被拆成集合，也不要求来源独立坐标；分流发生在计划中。A=0用零计划，V=0构造费用即零，V=∞由下界已知全部计划费用∞且μ⊗σ/S仍可行。有限正V令ε↓0即可；不需一般空间最优计划达值。

实际b=m_t时∫bμ=Π_t(G)≤1，κπ可积来自原q≥∫K₀ν和high。若σ{κ≤T}≥A，取该子容量与μ的归一化乘积，费用≤T∫bμ≤T；T=0同样有效，A=0无需除法。原资格子需求χμ须保χ在原v上并重核质量，不可据子需求宣布完整good支已付。若χ含原u资格，应先保原u或明示其实际积分形成的0≤χ(v)≤1；不能优化后丢掉pair门。O1是可选择补偿计划的inf，并非给定原δ(v,u)交通的上界；当前原u仍须C7提升以及额外联合接收/时间估计。

实际阅读optimal_compensation.md的(4)–(12)及主稿新增极值节后，上述一般量词、bins近最优构造、原子与零/无穷积分处理、低κ容量充分条件和未付接口均通过。主稿只用有限点值b、κ，不依赖附件可选∞点值的扩展约定。其逐行可自适应不免外层选择费用的限制正确。

实读另捕获附件两处必要修正并已通知作者/主级：(i)π必须明示1_Zg，G⊂Zg，不能把B₀上原ν直接归一成π；(ii)原压力例“当前删除仅保good”违背Zg⊂Zt，应采用完整支持的有限倾斜。父级提出wg=e²、ν=π/e²、wt=(1,e²,e²)、0<e<1/3，则eg=1、et=(1+e−e²)/e≥eg，
\[
 b_{\rm good}=\frac1{e(1+e-e^2)},\quad
 \int b\,d\mu=\frac1{1+e-e^2},\quad
 V=\frac1{4e(1+e-e^2)}.
\]
取Q=2Rwg、K₀=κwg、p=2K、q=1，给∫Qν=1、∫K₀ν=3/4−e/2≤q，终端high及全支持质量次序均保留。这仍只是原必要row标量的构造，不认证实际产品核、w_z函数、共同α/ρ/history或FULL实现。等待实际修定稿读回后再绑定最终SHA。

round_report.md已读，其无新增root、有限合成数值及原δ/外费缺口的状态与本审一致；未审核未来归档动作或未运行复现包装。

## 10. 修订读回与最终冻结

已实际读回optimal_compensation.md两处修订：π的1_Zg、eg及G⊂Zg均明确；三原子压力例使用相同完整支持与w_t≥w_g、e_t≥e_g，费用和矩如§9所核。旧“当前仅保good”错误已撤回，不能沿用旧版本；修改没有声称原产品核/FULL实现。一般inf、显式近优计划、低κ容量门及主稿未付交通边界均通过，无其他修正要求。

最终数学绑定SHA256：
- joint_high_geometry.md：d8968138824b4642f94ea1dbcac095c814c3451144b9bed17fef24dc537dc717
- optimal_compensation.md：2b0569fdb99481975698fa756f5452f874ffc1b2bc79b0a86734f4c2e0b25095
- research.tex：f5f0389188400160e206d6e80d5aa1943c9a69edc85c54a03be30b4d9d9e28fa

§7旧research哈希仅是新增极值节之前的检查点，以本节最终绑定为准。数值三文件仍按§8绑定；本审未重复运行，未认证后来reproduce包装或额外4项Fraction实例的实际执行。round_report的数学状态与审计一致，其后追加归档/运行日志不在本数学绑定之内。

结论：high有符号余额、同α的deepbad补偿及κ矩预算、当前边际lift、rank-one最优费用inf和足够低κ容量门均已严格核验；原δpair到补偿费用的付款方向、实际选择接收/时间及全β外费用仍未证。本轮无新增一般root付款，无新增FULL覆盖认证。本审到此冻结并停止，不扩展。



