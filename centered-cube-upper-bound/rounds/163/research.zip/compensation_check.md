# R163 精确有限补偿、倾斜与运输优化

104个预声明抽象有限模型全部通过Fraction断言；不使用kernel、浮点不等式或外部优化器。这些模型不是原Q/K/共同alpha的几何实现，不能称FULL，不能据此推断n阶。

输入pi为严格正有理概率，R>=0、sum R*pi<=1/2，T>=1，kappa>=0。每例还将原始kappa按 `1/max(1,sum kappa*pi)` 统一缩放，逐例精确检查终端必要矩 `sum kappa*pi<=1`；保存原矩与缩放因子。设a=1_{R>=1}(2R−1)、d=(1−2R)+、A=sum a*pi、S=sum d*pi。程序核A<=S；canonical Gamma_ij=a_i*pi_i*d_j*pi_j/S，S=0时A=0且无good需求。核所有good边际、所有供给不等式，并核

`sum Gamma*kappa=(A/S)*sum d*pi*kappa <= sum d*pi*kappa`。

令Z=sum T*pi，b_i=T_i/[Z(2R_i−1)]。canonical与优化Gamma均逐行精确恢复

`sum_j b_i Gamma_ij=T_i*pi_i/Z=current_good_pi_i`。

这只是当前good边际恢复，没有假设当前bad边际与终端供给相同。

## 有限优化的上下界证书

在固定需求a*pi、供给上限d*pi上，按b降序依次取kappa升序供给，取满A质量即可，未选供给保留。总代价为sum Gamma*b*kappa。kappa统一正缩放保持成本排序、最优流及费用相对源预算的比例。程序既核原始解的每行等式和每列上限，也构造并逐项检查一个对偶下界，因而没有仅凭贪心输出宣称最优。

对偶：行势u_i自由，列势v_j<=0，要求u_i+v_j<=b_i*kappa_j；下界为sum demand*u+sum supply*v。若排序后的行末使用kappa为t_i，末尾补b_{m+1}=0，则代码取

`u_i=sum_{l>=i}(b_l−b_{l+1})t_l`,

`v_j=min(0,min_i(b_i*kappa_j−u_i))`。

每一个有限模型均直接用Fraction检查全部对偶不等式与原始值=对偶值，gap精确为0。空需求时上下界均为0；ties按atom索引稳定排序。小3/4atom同样有严格下界证书，因此不另做运输顶点爆量枚举。JSON保存上下界与零gap；源码从确定输入重建完整势和原始稀疏流。

## 三阶段菜单与实际计数

初步3例：3atom精确meanR=.5、4atom双good及供给、4atom成本tie。压力5例：S=0且R=.5；R=1/.5边界；good上T=2^64；bad上T=2^64；全kappa=0。

扩大：固定seed=16320261015，n=8/16/32各32例。每例首n/4 atom为good候选R取{1,1.25,...,4}、原权整数1..3；次n/4为R=.5/.75、原权2..5；其余R=0/.25、原权12..30；归一化得到pi，仅接受meanR<=.5。本次96次生成均接受。T为2^e，e=0..64，另强制一个atom达到2^64；kappa的分子0..65536、分母1..17。完整生成顺序在源码中固定，无结果驱动菜单扩大；每例输入有SHA摘要。

总104例，104个精确零对偶gap，460个good边际及倾斜恢复、908个供给列、5398个对偶成本约束。99例优化费用严格小于canonical加权费用。全部104例满足终端kappa矩<=1；canonical和优化的未倾斜kappa费用均不超过供给预算。

## 重要预算限制

加b倾斜后的最优费用仍有2例超过未倾斜供给预算，其中1例超过1；这些数值在统一归一化后成立。最简单压力例为

`pi=(1/4,1/4,1/2), R=(1,1/2,0), T=(2^64,1,1)`。

原始kappa=(1,2,3)的总矩9/4，统一乘4/9后 `kappa=(4/9,8/9,4/3)`，终端总矩精确为1。供给kappa预算2/3，而最优加权费用为 `4*2^64/[3*(2^64+3)]>1`（精确等价于2^64>9）。该例没有多个供给成本可交换，greedy无法消掉倾斜费用。

不能把canonical的未倾斜预算不加条件地搬到当前good质量。补上终端kappa必要矩仍未解决这一抽象倾斜压力，但它仍不是原high+shared-alpha反例：没有构造同一q、原K0/J/Q、共同alpha及rho，尤其没有证明实际U=0或其他资格可实现。本轮只核有限测度代数合同，未丢弃该实现缺口。

## 复现与账本

```
/opt/homebrew/bin/python3 /absolute/path/to/compensation_check.py --output /absolute/path/to/compensation_check.json
```

仅需Python标准库（实际Python3.14）。三次producer均成功、无失败：首轮完成全部模型；第二轮补上优化流未倾斜kappa预算及倾斜边际的显式断言；第三轮将全部kappa统一归一化满足终端必要矩并重放同一104例，保持99个严格改善及2个超过源预算的结论，另记录1例最优费用超过1。运行耗时约0.1秒，精确值见JSON。没有kernel/receiver调用，没有安装库。JSON绑定源码和task_contract.md SHA；跨环境路径/耗时不承诺字节相同，所有数学值均为精确有理数。
