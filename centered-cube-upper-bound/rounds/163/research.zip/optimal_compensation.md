# R163：当前倾斜下的最小补偿费用与低成本容量证书

筛查结论：候选的 **infimum 公式成立**，原子允许拆分，不要求来源为产品测度。下面用 layer-cake 给下界，再用可数值域分箱显式构造任意精度的可行计划；不引用最优运输或条件分布定理。一般可测空间下只声明 infimum，不额外声称存在实现精确最小值的确定性配对映射。

## 1. 原行的需求、容量和当前倾斜

固定一个原合法行及时间，零分母行回原零交通。设 \(e_g,e_t>0\)，
\[
d\pi(v)=\mathbf1_{Z_g}(v)w_g(v)d\nu(v)/e_g,\qquad
R(v)=\frac{KQ_v}{p w_g(v)},\qquad \int R\,d\pi\le\frac12.
\]
这里 \(e_g=\int_{Z_g}w_gd\nu\)，所以 \(\pi\) 为概率测度；保留原 \(Z_g\subset Z_t\)，令 \(G=Z_g\cap\{R\ge1\}\)，并定义
\[
d\mu=\mathbf1_G(2R-1)d\pi,\quad A=\mu(V),
\qquad
d\sigma=(1-2R)_+d\pi,\quad S=\sigma(V).
\]
所有对象保持原行、原来源、原共同 \(\alpha\) 和原正门的取值，不因下述优化重算。

令 \(A_+=\int(2R-1)_+d\pi\)。准确地，
\[
S-A_+=1-2\int R\,d\pi\ge0,\qquad A\le A_+\le S\le1.
\tag{1}
\]
不能把 \(A\) 与 \(A_+\) 混同：\(1/2<R<1\) 的源不在 \(G\) 中，但也贡献正部。

费用函数和当前倾斜为
\[
\kappa(w)=\frac{2KK_{0,w}}{p w_g(w)}\ge0,
\qquad
b(v)=\frac{e_g}{e_t}\frac{w_t(v)/w_g(v)}{2R(v)-1}
\quad(v\in G\cap Z_t),
\]
其余处 \(b=0\)。在 \(G\) 上分母至少为 1。由 \(\pi\) 定义及原 \(e_t=\int_{Z_t}w_t d\nu\)，有重要的准确恒等式
\[
\boxed{\quad
B_\mu:=\int b\,d\mu
=\frac1{e_t}\int_{G\cap Z_t}w_t\,d\nu
=\Pi_t(G)\le1.
\quad} \tag{2}
\]
这不是 \(b\le1\)，也不是 terminal good 质量可以直接迁移到 current posterior。

合法补偿计划指非负测度 \(\Gamma\) 满足
\[
(\mathrm{pr}_1)_\#\Gamma=\mu,
\qquad (\mathrm{pr}_2)_\#\Gamma\le\sigma.
\tag{3}
\]
因此总运输质量恰为 \(A\)，第一边在 good，第二边在 deep-bad \(R<1/2\)。当 \(A=0\) 时取零计划，费用为零。以下讨论 \(A>0\)，于是 \(S>0\)。

## 2. 精确 infimum 公式

该节事实上只用有限正测度 \(\mu,\sigma\) 及 \(0<A\le S\)，可在任意可测来源空间实施。主式允许 \(b,\kappa\) 为非负有限值可测函数，积分可为 \(+\infty\)。若允许点值 \(+\infty\)，同一论证在费用约定 \(0\cdot\infty=0\) 下仍成立；原有限有效行不需要额外依赖这个约定。

定义广义逆
\[
b_\mu^\downarrow(r)=\inf\{t\ge0:\mu(b>t)\le r\},\quad0<r<A,
\]
\[
\kappa_\sigma^\uparrow(r)=\inf\{s\ge0:\sigma(\kappa\le s)\ge r\},\quad0<r<S.
\]
空集的 infimum 取 \(+\infty\)。端点取值不影响 Lebesgue 积分。所求值为
\[
\boxed{\quad
\inf_{\Gamma\text{ satisfying }(3)}\int b(v)\kappa(w)\,d\Gamma(v,w)
=\mathcal V:=\int_0^A b_\mu^\downarrow(r)\kappa_\sigma^\uparrow(r)dr.
\quad} \tag{4}
\]
\(\kappa_\sigma^\uparrow\) 是整份容量的升序广义逆，只取最初 \(A\) 质量。\(b\) 必须按需求测度 \(\mu\) 排序，不能按 \(\pi\) 或 current posterior 重新排序。

### 2.1 下界：事件交叠逐层计算

对任意合法 \(\Gamma\) 和 \(t,s\ge0\)，
\[
\Gamma\{b>t,\kappa>s\}
\ge[\mu(b>t)-\sigma(\kappa\le s)]_+.
\tag{5}
\]
因为第一事件总质量固定为 \(\mu(b>t)\)，而运到 \(\kappa\le s\) 的总量至多其容量。

广义逆满足（至多忽略 \(r\) 的零测边界）
\[
\{r:b_\mu^\downarrow(r)>t\}=(0,\mu(b>t)),
\]
\[
\{r:\kappa_\sigma^\uparrow(r)>s\}=(\sigma(\kappa\le s),S).
\]
两者在 \((0,A)\) 的交长恰为 (5) 的右边。因此 Tonelli/layer-cake 给
\[
\begin{aligned}
\int b\kappa\,d\Gamma
&=\int_0^\infty\!\int_0^\infty
\Gamma\{b>t,\kappa>s\}\,dt\,ds\\
&\ge\int_0^\infty\!\int_0^\infty
[\mu(b>t)-\sigma(\kappa\le s)]_+dt\,ds\\
&=\int_0^A b_\mu^\downarrow(r)\kappa_\sigma^\uparrow(r)dr.
\end{aligned}
\tag{6}
\]
这包括 \(\mathcal V=+\infty\) 的情形；没有作无穷量相减。

### 2.2 上界：一般可测空间的显式近最优计划

固定 \(\varepsilon>0\)，令 \(a=1+\varepsilon\)，将每个正有限值区间 \([a^k,a^{k+1})\)、\(k\in\mathbb Z\)，向上量化为 \(a^{k+1}\)。零仍取零；如允许无穷值，另列无穷 bin。记该函数为 \(T_\varepsilon\)，则
\[
x\le T_\varepsilon(x)\le(1+\varepsilon)x.
\tag{7}
\]
设 \(E_i\) 是 \(T_\varepsilon(b)\) 的各个值 bin，值为 \(b_i\)，质量 \(m_i=\mu(E_i)\)；\(F_j\) 是 \(T_\varepsilon(\kappa)\) 的值 bin，值为 \(k_j\)，容量 \(s_j=\sigma(F_j)\)。这些族至多可数。

在 rank 区间上令
\[
I_i=\{r\in(0,A):T_\varepsilon(b_\mu^\downarrow(r))=b_i\},
\]
\[
J_j=\{r\in(0,S):T_\varepsilon(\kappa_\sigma^\uparrow(r))=k_j\},
\qquad \lambda_{ij}=|I_i\cap J_j|.
\]
由上面的广义逆分布恒等式，\(|I_i|=m_i\)、\(|J_j|=s_j\)。两族分别划分 \((0,A)\)、\((0,S)\)，故
\[
\sum_j\lambda_{ij}=m_i,\qquad
\sum_i\lambda_{ij}\le s_j.
\]
忽略零质量项，定义可数个正乘积测度之和
\[
\boxed{\quad
\Gamma_\varepsilon
=\sum_{i,j}\lambda_{ij}
\frac{\mu|_{E_i}}{m_i}\otimes\frac{\sigma|_{F_j}}{s_j}.
\quad} \tag{8}
\]
Tonelli 直接验证其第一边际是 \(\mu\)，第二边际在每个 \(F_j\) 上是容量的一个比例，至多 \(\sigma\)。这是明确的可测计划，不依赖任意 level-set 的条件概率核，也不需要原子可分成集合：原子质量在计划中允许分流。

在每个正质量 bin 对上 \(b\kappa\le b_i k_j\)。因而
\[
\begin{aligned}
\int b\kappa\,d\Gamma_\varepsilon
&\le\sum_{i,j}\lambda_{ij}b_i k_j\\
&=\int_0^A T_\varepsilon(b_\mu^\downarrow(r))
T_\varepsilon(\kappa_\sigma^\uparrow(r))dr\\
&\le(1+\varepsilon)^2\mathcal V.
\end{aligned}
\tag{9}
\]
无穷 bin 如有出现，按前述非负费用约定处理；若 \(\mathcal V<\infty\)，任何正费用无穷 bin 对的交长必为零。

若 \(\mathcal V\) 有限，让 \(\varepsilon\downarrow0\)，(9) 给出 infimum 至多 \(\mathcal V\)；若 \(\mathcal V=0\)，每个该构造的费用已经为零。若 \(\mathcal V=+\infty\)，(6) 已说明所有合法计划费用无穷，且可行集合仍非空（例如 \(\mu\otimes\sigma/S\)）。这证明 (4) 的全部积分量词。

### 2.3 有限原子版精确可达

若两测度有限原子，按 \(b_i\) 降序排列需求原子的质量区间，按 \(\kappa_j\) 升序排列容量原子的质量区间；取最初 \(A\) 容量，令 \(\Gamma_{ij}\) 等于两 rank 区间的交长。行和、列容量及费用都可逐项核验，费用精确等于 (4)。并列值任意排，原子可拆分。一般可测空间上 (8) 已足够证明 infimum；本文件不把有限原子实现冒充一般确定性映射实现。

## 3. 可直接检查的上界证书

### 3.1 全容量 product 计划保留当前倾斜

若 \(B_\kappa:=\int\kappa\,d\sigma<\infty\)，显式计划
\[
\Gamma_{\rm prod}=\mu\otimes\sigma/S
\]
满足
\[
\int\kappa(w)d\Gamma_{\rm prod}=\frac A S B_\kappa,
\qquad
\boxed{\int b(v)\kappa(w)d\Gamma_{\rm prod}
=\frac{B_\mu}{S}B_\kappa\le\frac{B_\kappa}{S}.}
\tag{10}
\]
第一式的 \(A/S\) 不能误移到第二式。若主路线另证 \(B_\kappa\le\mathcal A_\alpha\)，这里只能得 \(\mathcal V\le B_\mu\mathcal A_\alpha/S\)，没有免费消除 \(S^{-1}\)。

### 3.2 足够低 \(\kappa\) 容量给真实 weighted 费用 \(\le T\)

对固定 \(T\ge0\)，令
\[
\sigma_T=\mathbf1_{\{\kappa\le T\}}\sigma,
\qquad S_T=\sigma_T(V).
\]
若
\[
\boxed{S_T\ge A,} \tag{11}
\]
则（\(A>0\) 时 \(S_T>0\)）计划 \(\Gamma_T=\mu\otimes\sigma_T/S_T\) 合法，而且
\[
\boxed{\quad
\mathcal V\le\int b\kappa\,d\Gamma_T
=\frac{B_\mu}{S_T}\int\kappa\,d\sigma_T
\le T B_\mu=T\Pi_t(G)\le T.
\quad} \tag{12}
\]
这是低成本**容量**充分条件，不要求每个 deep-bad 来源的 \(\kappa\) 都小。所有量都是本行原 \(R,\kappa,\pi\) 的明确积分。

同一门也可用于原实际剩余资格形成的子需求。固定原可测 \(0\le\chi\le1\)，不重算任何原对象，令
\[
\mu_\chi=\chi\mu,\quad A_\chi=\mu_\chi(V),\quad
B_\chi=\int b\,d\mu_\chi=\int_G\chi\,d\Pi_t\le1.
\]
条件只需 \(S_T\ge A_\chi\)，相应计划费用至多 \(TB_\chi\le T\)。\(\chi=1\) 才是完整 good 需求；不能付了一个缩减需求就宣称完整 \(G\) 已付。若原规则同时限制可用 deep-bad 容量，也必须先把 \(\sigma\) 换成实际允许的子容量并重新核验质量不等式。

例如，若实际可用容量满足 \(S_T\ge A_\chi\) 且 \(T\le C\sqrt n\)，则本行这份补偿计划的当前 weighted 核费至多 \(C\sqrt n\)。这仍只是 row 核费用，并没有自动包含原 \(\delta(v,u)\)、共同时间和外层费用。

## 4. 一个小型压力例：不能删除当前倾斜因子

以下仅是有限 row 代数压力，不是连续核 FULL 实例。取 \(0<e<1/3\)，三个原子的
\[
\pi=(e,2e,1-3e),\qquad R=(1,1/4,1/2),
\qquad \kappa=(1/4,1/(4e),1/4).
\]
则 \(\int R\,d\pi=1/2\)，\(A=S=e\)，且
\[
\int\kappa\,d\pi=3/4-e/2<1,\qquad
\int\kappa\,d\sigma=1/4.
\]
因此同时满足 high 和 \(\int\kappa\pi\le1\) 的必要条件，不是仅约束 \(\int\kappa\sigma\)。取完整且相同的三原子支持 \(Z_g=Z_t\)，保留嵌套；令
\[
w_g=e^2,\quad d\nu=d\pi/e^2,\quad
w_t=(1,e^2,e^2),\quad w_t/w_g=(e^{-2},1,1).
\]
于是全部权重至多 1，\(e_g=1\)，且
\[
e_t=\frac{1+e-e^2}{e}\ge e_g,\qquad
b_{\rm good}=\frac1{e(1+e-e^2)},\qquad
B_\mu=\frac1{1+e-e^2}.
\]
唯一可用 deep-bad 容量是第二原子，故
\[
\mathcal V=e\cdot\frac1{e(1+e-e^2)}\cdot\frac1{4e}
=\frac1{4e(1+e-e^2)}.
\]
这一发散与 (10) 的准确因子一致。再取 \(p=2K,Q=2Rw_g,K_0=\kappa w_g\)，则 \(q=\int Qd\nu=1\ge\int K_0d\nu=3/4-e/2\)，保留要求的 \(q\ge\int K_0\) 代数必要条件。此例保留相同支持、\(w_t\ge w_g\) 和 \(e_t\ge e_g\)，但不认证这些行数值可由真实多维核及全部历史门同时实现，也不用于否定额外真实几何；它只说明现有总量约束不能单独移除 weighted 费用。

## 5. 与原 \(\delta(v,u)\) 交通之间尚欠的方向

式 (4) 给的是**所有合法补偿计划的最小费用**。它不意味着给定的原 \((\delta(v,u))_+\) pair 交通费用被这个 infimum 上界；一般方向恰相反，任一合法给定计划的费用至少为 \(\mathcal V\)。

要用于原付款，仍须证明：原缺口可以合法选择/重路由为 (8) 或 (12) 的计划，或者原实际 pair 交通被某个已构造计划的 weighted 费用支配；并保留其原后验、\(\rho\)、good/bad、共同 \(\alpha\)、时间及外层聚合。原 \(\delta\) 的两端来源和这些门不能在优化后被删除或重选。

本文件的推进是完整的 infimum 公式、原子/可测实现、当前质量恒等式 (2)，以及明确低 \(\kappa\) 容量门 (11)—(12)。本文件没有证明该容量门对原全部剩余自动成立，也没有证明所构造计划已经接入原 \(\delta\) 付款，更不声称一般根阶目标闭合。

