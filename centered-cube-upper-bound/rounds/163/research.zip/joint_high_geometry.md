# R163：原 high 强制的终端补偿、同 alpha 核预算与当前倾斜缺口

状态：有限严格检查点，**不是新增根阶付款**。本稿只用本轮原合同、原 terminal-survival 来源及初等积分。新连接是：实际 good 交通必须有终端 deepbad 第三来源补偿；该补偿具有同一 alpha 给出的显式 K0 总预算。当前权重倾斜会放大这一预算，尚未证明其真实接收费用可求和。未重报 R147 截顶势、R162 平方门或极小 soft 支。

## 1. 准确命题及量词

固定原完整实际行，包括 x、y、j、s、尺度、原 nu、原 alpha 和 history。允许它们按原规则依 x 自适应。记
\[
 \pi_g(dv)={1_{Z_g}(v)w_g(v)\nu(dv)\over e_g},\qquad
 R(v)={KQ_v\over p w_g(v)},\qquad
 Q_Z=\int_{Z_g}Q_v\,d\nu(v).
 \tag{HG1}
\]
本稿 R(v) 是无量纲终端似然，非原尺度 R。主分支 p,e_g,D>0；原全软 J>0、原 s>0、有限来源点给 Q、K0、wg>0。零分母按原零交通约定先处理，不用以下商式。D=0 若不在原正参数合同内，不属于 alpha 核预算声明。

取 G 为待估交通的原终端存活 good 来源的任意可测子集，故 G⊂Zg，R≥1 于 G，且 G 的来源在实际 Pi_t 支持中；可保留 rho>0、原资格和已付补集。下面的补偿来源只作为终端辅助测度，不擅自换成当前 Pi_t，也不要求把其他删除来源加回当前交通。

准确先行命题：原 high、alpha 同时给出一个终端耦合 Gamma_G，其 good 边际为 1G(2R−1)pi_g，其另一个边际由实际 deepbad R<1/2 的终端质量支配；该边际的无量纲 K0 消费有显式预算≤1。恢复实际 Pi_t 时必须支付来源相关因子
\[
 F_t(v)={e_g\over e_t}\,{w_t(v)/w_g(v)\over2R(v)-1}.
 \tag{HG2}
\]
以下证明此命题及其准确限制，不预设 F 有无关维数的帽。

## 2. high 的完整有符号剩余

定义两个非负原剩余
\[
 \sigma=1-{2Kq\over pe_g}\ge0,\qquad
 \xi={2K(q-Q_Z)\over pe_g}\ge0.
 \tag{HG3}
\]
其中 xi 包含 Zg 外 Q 消费以及 q 相对整个 Q 积分的松弛，不得静默删除后仍称等式。由 high 与 q≥∫Qnu，
\[
 \int(1-2R)\,d\pi_g=\sigma+\xi.
 \tag{HG4}
\]
令
\[
 d(v)=(1-2R(v))_+,\quad a(v)=(2R(v)-1)_+,\quad
 S=\int d\,d\pi_g,\quad P=\int a\,d\pi_g,
 \quad G_+=\int_G(2R-1)\,d\pi_g.
 \tag{HG5}
\]
则精确有
\[
 S=P+\sigma+\xi
  =G_++(P-G_+)+\sigma+\xi.
 \tag{HG6}
\]
尤其 G+≤S≤1。补偿密度 d 只支撑在
\[
 D_{deep}=Z_g\cap\{R<1/2\}\subset D_g.
 \tag{HG7}
\]
原 bad 的中间区 1/2≤R<1 不能补偿 good；其 R>1/2 部分反而计入 P−G+。该区别是使用原 high 后的实际限制，裸 good/bad pair 门没有它。

例如仅有两个终端原子、分别 Rv≥1 和 Ru<1 时，令 good 终端质量为 m，则 high 必须满足
\[
 mR_v+(1-m)R_u\le\tfrac12.
\]
若 m>0，则 Ru<1/2，且
\[
 m\le{1/2-R_u\over R_v-R_u}.
 \tag{HG8}
\]
这是必要的代数检验，不是原 FULL 几何实例。既有单 pair 中间 soft 的正漂移若未同时认证 high，不能反驳保留 HG6 的候选。数值代理确认 R162 裸核 pair 诊断没有同窗 et、eg、q 或原 high 认证。

## 3. 同一个 alpha 对补偿来源的真实核预算

定义无量纲核消费
\[
 \kappa(v)={2K K_{0,v}\over p w_g(v)},\qquad
 A_\alpha={2K\alpha Q_J\over Dpe_g},\qquad
 C_U={2K\int U\,d\nu\over Dpe_g}.
 \tag{HG9}
\]
由原 producer 与 high，准确有
\[
 A_\alpha=1-\sigma-C_U\in[0,1].
 \tag{HG10}
\]
另一方面，U=0 于实际 bad，其他位置 U≤DK0，且 q≥∫K0nu，故
\[
 D\int_{D_g}K_0\,d\nu\le\alpha Q_J.
\]
由 deepbad⊂Dg 得
\[
 \int_{D_{deep}}\kappa\,d\pi_g
 ={2K\over pe_g}\int_{D_{deep}}K_0\,d\nu
 \le A_\alpha.
 \tag{HG11}
\]
这里的 alpha 是原共同值；没有按 good 来源重选，也没有忽略 U 的其余来源消费。HG10 保留了其完整扣减。

令任意 lambda>0，并在 d>0 上分割实际比值 kappa/d。则
\[
 \begin{aligned}
 G_+ +(P-G_+)+\sigma+\xi=S
 &\le\int_{D_{deep}}d\,
       1_{\{\kappa<\lambda d\}}d\pi_g
       +{A_\alpha\over\lambda}.
 \end{aligned}
 \tag{HG12}
\]
证明只用高比值支上 d≤kappa/lambda 与 HG11。等号放在高比值支；d=0 没有补偿质量。HG12 定量说明：若原 alpha 核预算不足以支付补偿，则必须存在具有实际低 K0/(pwg) 的 deepbad 补偿来源。它没有把该低核尾判为已付。

## 4. 一次性的补偿耦合及明确来源成本

若 S=0，则 HG6 给 G+=0，因 2R−1≥1 于 G，pi_g(G)=0，原当前 good 来源亦为零质量，交通为零。以下设 S>0。定义
\[
 \Gamma_G(dv,dw)=
 1_G(v)(2R(v)-1)\pi_g(dv)
 {d(w)\pi_g(dw)\over S}.
 \tag{HG13}
\]
这是由原实际行构造的辅助耦合，不是 nu 独立性假设；它可随 x 变化，不能插入要求固定混合来源的核定理。

其 good 边际恰为 1G(2R−1)pi_g，补偿边际为 (G+/S)d pi_g≤d pi_g。于是
\[
 \int\kappa(w)\,d\Gamma_G(v,w)
 ={G_+\over S}\int d(w)\kappa(w)\,d\pi_g(w)
 \le {G_+\over S}A_\alpha\le1.
 \tag{HG14}
\]
HG14 是已经估计过的实际来源成本，而非假设的 Lq 范数。它保留原 K0、Q、wg、alpha 与 high 余量；未分别最坏化 alpha 与来源。不同 v 不领取多份预算。

## 5. 当前后验的准确恢复与尚未付的倾斜

对原 terminal-survival 的 v∈G，Pi_t 与 pi_g 的 Radon–Nikodym 比为 (eg/et)(wt/wg)。所以
\[
 1_G(v)\Pi_t(dv)=F_t(v)\,\Gamma_G(dv,D_{deep}),
 \qquad \int F_t\,d\Gamma_G=\Pi_t(G)\le1.
 \tag{HG15}
\]
这里原 et 和删除支持不变；没有 eta 下界或把 Zjt 换成共同底集。只恢复 good 边际，不将辅助 w 的终端测度误认为当前后验。

但核成本的当前版本是
\[
 \begin{aligned}
 \int F_t(v)\kappa(w)\,d\Gamma_G
 &= {\Pi_t(G)\over S}
       \int d(w)\kappa(w)\,d\pi_g(w)\\
 &\le {\Pi_t(G)\over S}A_\alpha.
 \end{aligned}
 \tag{HG16}
\]
与 HG14 相比，多出的 Pi_t(G)/S 是当前—终端倾斜，不能用 G+/S≤1 代替。

原 t≤g 给 z≤zg。逐坐标直接比较 min(1,C/z) 与 min(1,C/zg)，得
\[
 1\le {w_t(v)\over w_g(v)}\le(z_g/z)^n\le2^n.
 \tag{HG17}
\]
由 HG15、G+≤S，
\[
 {\Pi_t(G)\over S}
 \le {e_g\over e_t}(z_g/z)^n{G_+\over S}
 \le2^n.
 \tag{HG18}
\]
这是可证的有限成本，并非所需根阶费用。HG17–18 不改善成常数或多项式，因为仅凭当前已用合同没有证明这种改善；本稿不另构造自由似然反例。

更具体地，原时点 J 交通可准确写成
\[
 \begin{aligned}
 p\int F_t(v)\rho_v\chi_{J,v}
   \left[\int_{D_0}\chi_{orig}
       (k_t(v)-k_t(u))_+\,d\Pi_t(u)\right]
      d\Gamma_G(v,w).
 \end{aligned}
 \tag{HG19}
\]
所有原正门、alpha、history 和真实三核似然带均保留在原量中。w 是必须存在的 deepbad 补偿来源；u 仍是原交通的 bad 来源，二者不能认作同一个来源。利用 HG14 的预算支付 HG19，尚需联合控制其当前倾斜 F_t、真实 score 差及同点接收 p；把 F_t 单独取 HG17 的最坏值会损失指数因子。

补偿耦合另有真实三核几何支撑：对 Gamma_G 几乎处处的 (v,w)，原 good 和 deepbad 给
\[
 {Q_v\over w_g(v)}>2{Q_w\over w_g(w)}.
 \tag{HG19a}
\]
因 3Q=K1+K2+J 是同点的三个正核之和，至少一个核标签 a∈{1,2,J} 满足
\[
 {K_{a,v}\over w_g(v)}>2{K_{a,w}\over w_g(w)},
 \qquad
 \log{K_{a,v}/w_g(v)\over K_{a,w}/w_g(w)}>\log2.
 \tag{HG19b}
\]
按固定次序取第一个满足式子的标签，得到三个可测且不交的实际子支。没有来源个数损失；若各子支分别调用一个价格 C，合计最多3C，不能无价复用同一预算。HG19b 不能推出 J 单独分离。原交通 u 及其与 v 的 score 差仍在 HG19 中，辅助补偿来源 w 不替代 u。这给下一步一个由原 high 强制、与真实产品核位移相关的几何约束，而非自由指定似然的模型。

## 6. 原外费用与下一步最小几何目标

HG13–19 是逐原行恒等式/不等式，在积分时仍须保留原
\[
 2\Lambda\mathbb E\sum_{V,j}\int d\beta_V(y)
 \int {dt\over t}\int dx\,{p_x\over q(x)}
 \int d\nu(z')\,h_{R_{scale}}(x-z')a_\omega
 [\text{HG19 中除去 }p\text{ 的内积分}].
 \tag{HG20}
\]
原唯一 j 只能在取得共同整行时间帽后消去；本稿没有提前删除 history。未以 nu 代 beta，未消费负账，未把固定参数概率界视作实际选择器积分。

若只用此前已知的粗帽，独立同分布的两份实际 Pi 满足
\[
 (k-\ell)_+\le k(n-\ell)/n,
 \qquad\iint(k-\ell)_+d\Pi d\Pi\le n/4.
\]
在原 hard 帽16/3、完整时间 log2、共同接收包络3(2n+3)Dn 的合法域上，仍只能登记粗价
\[
 2\Lambda P^{leg,J}
 \le8\Lambda n\log2(2n+3)D_nW_\beta
 \le24\Lambda n(2n+3)\log2\sqrt nW_\beta.
 \tag{HG21}
\]
HG14 没有将 HG21 自动降低到根阶；此粗价只是明确全部费用，并非本轮新付款。若离开原 hard/history 合法域，该外合同也不得沿用。

本轮更准确的最小新几何任务是：在 R162 未付的实际低 c 平方余量尾中，同时保留 (i) 原交通 u 的三核 bad 似然，(ii) HG13 必须出现的 deepbad 补偿 w 及其 HG14 同 alpha 核预算，(iii) HG19 的当前倾斜和 score 差，证明其真实 p dx/时间/原 beta 聚合可付。单纯控制裸 pair (v,u) 而不保留混合 high，或者把辅助 w 与 u 合并，会漏掉本轮已经证明的限制。

到此冻结：得到了精确 high 残差、deepbad 补偿及有界同 alpha 来源成本；未获得一般中间 soft 的新增根阶付款。R162 平方门、R147 势和已有已付补集仍按原证书各保留一次。本稿不扩展任务。
