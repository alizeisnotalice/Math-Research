#!/usr/bin/env python3
"""Verify archive hashes, then rerun the exact finite checks (stdlib only)."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys
from fractions import Fraction as F

root = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
manifest = json.loads((root / 'manifest.json').read_text())
for name, digest in manifest['files'].items():
    assert hashlib.sha256((root / name).read_bytes()).hexdigest() == digest, name
assert args.output.resolve() not in [p.resolve() for p in root.iterdir()]
subprocess.run([sys.executable, str(root / 'compensation_check.py'),
                '--output', str(args.output)], check=True)
expected = json.loads((root / 'compensation_check.json').read_text())
actual = json.loads(args.output.read_text())
for key in expected:
    if key != 'runtime':
        assert actual[key] == expected[key], key
# Independent exact check of the analytical three-source tilt example.
for denominator in [4, 16, 256, 65536]:
    e = F(1, denominator)
    pi = [e, 2*e, 1-3*e]
    R = [F(1), F(1,4), F(1,2)]
    kappa = [F(1,4), 1/(4*e), F(1,4)]
    T = [1/e**2, F(1), F(1)]
    Z = sum(p*t for p,t in zip(pi,T))
    assert Z >= 1 and sum(p*r for p,r in zip(pi,R)) == F(1,2)
    assert sum(p*k for p,k in zip(pi,kappa)) == F(3,4)-e/2
    assert e*(T[0]/Z)*kappa[1] == 1/(4*e*(1+e-e**2))
print('PASS: four exact full-support tilt examples; abstract row only.')
print('PASS: manifest hashes and rerun match; finite abstract model only.')
