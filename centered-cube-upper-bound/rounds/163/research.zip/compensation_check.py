#!/usr/bin/env python3
"""Exact abstract finite compensation/tilted transport checks; no kernel model."""
from fractions import Fraction as F
from pathlib import Path
import argparse,hashlib,json,random,time
ROOT=Path(__file__).resolve().parent

def check(label,stage,pi,R,T,kappa):
    n=len(pi);assert all(len(x)==n for x in [R,T,kappa]);assert sum(pi)==1 and all(x>0 for x in pi)
    assert all(r>=0 for r in R) and sum(p*r for p,r in zip(pi,R))<=F(1,2)
    assert all(t>=1 for t in T) and all(k>=0 for k in kappa)
    raw_kappa_moment=sum(p*k for p,k in zip(pi,kappa));kappa_scale=1/max(F(1),raw_kappa_moment);kappa=[k*kappa_scale for k in kappa]
    assert sum(p*k for p,k in zip(pi,kappa))<=1
    a=[2*r-1 if r>=1 else F(0) for r in R];d=[max(F(0),1-2*r) for r in R]
    demand=[p*x for p,x in zip(pi,a)];supply=[p*x for p,x in zip(pi,d)];A=sum(demand);S=sum(supply);assert A<=S
    Z=sum(p*t for p,t in zip(pi,T));good=[i for i in range(n) if demand[i]>0];bad=[j for j in range(n) if supply[j]>0]
    b={i:T[i]/Z/a[i] for i in good};budget=sum(supply[j]*kappa[j] for j in bad)
    G={(i,j):demand[i]*supply[j]/S for i in good for j in bad} if S else {}
    for i in good:
        assert sum(G.get((i,j),F(0)) for j in bad)==demand[i]
        assert sum(G.get((i,j),F(0))*b[i] for j in bad)==T[i]*pi[i]/Z
    for j in bad:assert sum(G.get((i,j),F(0)) for i in good)<=supply[j]
    kcost=sum(x*kappa[j] for (i,j),x in G.items());assert kcost<=budget
    if S:assert kcost==A/S*budget
    else:assert A==0 and not good
    canonical_cost=sum(x*b[i]*kappa[j] for (i,j),x in G.items())
    # Highest b uses cheapest kappa first; unselected supply remains unused.
    order=sorted(good,key=lambda i:(-b[i],i));cols=sorted(bad,key=lambda j:(kappa[j],j));remaining=supply[:];flow={};ends={};cursor=0
    for i in order:
        need=demand[i]
        while need:
            while cursor<len(cols) and not remaining[cols[cursor]]:cursor+=1
            assert cursor<len(cols)
            j=cols[cursor];x=min(need,remaining[j]);flow[i,j]=x;need-=x;remaining[j]-=x;ends[i]=kappa[j]
    for i in good:assert sum(flow.get((i,j),F(0)) for j in bad)==demand[i]
    for j in bad:assert sum(flow.get((i,j),F(0)) for i in good)<=supply[j]
    optimal_kcost=sum(x*kappa[j] for (i,j),x in flow.items());assert optimal_kcost<=budget
    for i in good:assert sum(flow.get((i,j),F(0))*b[i] for j in bad)==T[i]*pi[i]/Z
    primal=sum(x*b[i]*kappa[j] for (i,j),x in flow.items())
    # Exact LP lower certificate, with <= column supplies: v_j<=0.
    u={};running=F(0)
    for pos in range(len(order)-1,-1,-1):
        i=order[pos];nextb=b[order[pos+1]] if pos+1<len(order) else F(0)
        running+=(b[i]-nextb)*ends[i];u[i]=running
    v={j:min([F(0)]+[b[i]*kappa[j]-u[i] for i in good]) for j in bad}
    for j in bad:
        assert v[j]<=0
        for i in good:assert u[i]+v[j]<=b[i]*kappa[j]
    dual=sum(demand[i]*u[i] for i in good)+sum(supply[j]*v[j] for j in bad)
    assert primal==dual and primal<=canonical_cost
    recovered=sum(T[i]*pi[i]/Z for i in good);assert recovered<=1
    # Weighted costs need not obey the unweighted source budget without b.
    if good:assert primal<=max(b.values())*budget
    return dict(label=label,stage=stage,n=n,raw_kappa_moment=str(raw_kappa_moment),kappa_scale=str(kappa_scale),terminal_kappa_moment=str(sum(p*k for p,k in zip(pi,kappa))),mean_R=str(sum(p*r for p,r in zip(pi,R))),A=str(A),S=str(S),terminal_good_mass=str(sum(pi[i] for i in good)),current_good_mass=str(recovered),kappa_source_budget=str(budget),canonical_kappa_cost=str(kcost),canonical_weighted_cost=str(canonical_cost),optimal_unweighted_kappa_cost=str(optimal_kcost),optimal_weighted_cost=str(primal),dual_value=str(dual),dual_gap='0',optimal_over_source_budget=(str(primal/budget) if budget else None),strict_optimization=primal<canonical_cost,weighted_opt_exceeds_unweighted_budget=primal>budget,weighted_opt_exceeds_one=primal>1,checks=dict(good_rows=len(good),supply_columns=len(bad),dual_inequalities=len(good)*len(bad),tilt_recovery=len(good)),input_sha256=hashlib.sha256(repr((pi,R,T,kappa)).encode()).hexdigest())

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=ROOT/'compensation_check.json');args=ap.parse_args();started=time.monotonic();cases=[]
    def add(label,stage,p,r,t,k):cases.append(check(label,stage,list(map(F,p)),list(map(F,r)),list(map(F,t)),list(map(F,k))))
    add('three_exact_high','initial',[F(1,8),F(3,8),F(1,2)],[2,0,F(1,2)],[1,1,1],[2,3,1])
    add('four_two_good','initial',[F(1,16),F(1,16),F(7,16),F(7,16)],[1,2,0,F(1,4)],[1,2,3,1],[0,1,3,1])
    add('four_tied_costs','initial',[F(1,8),F(1,8),F(3,8),F(3,8)],[1,1,0,0],[1,1,1,1],[1,1,2,2])
    add('S_zero_half_boundary','pressure',[F(1,2),F(1,2)],[F(1,2),F(1,2)],[1,2**64],[0,1])
    add('R_one_half_boundaries','pressure',[F(1,4),F(1,4),F(1,2)],[1,F(1,2),0],[2**64,1,1],[1,2,3])
    add('good_strong_tilt','pressure',[F(1,16),F(1,16),F(7,16),F(7,16)],[1,2,0,F(1,4)],[2**64,1,1,1],[0,1,1000,1])
    add('bad_strong_tilt','pressure',[F(1,16),F(1,16),F(7,16),F(7,16)],[1,2,0,F(1,4)],[1,1,2**64,1],[0,1,1000,1])
    add('zero_kappa','pressure',[F(1,8),F(1,8),F(3,8),F(3,8)],[1,1,0,0],[2**64,1,1,1],[0,0,0,0])
    rng=random.Random(16320261015);attempts=0
    for n in [8,16,32]:
        accepted=0
        while accepted<32:
            attempts+=1;g=n//4;mid=n//4
            w=[rng.randint(1,3) if i<g else (rng.randint(2,5) if i<g+mid else rng.randint(12,30)) for i in range(n)];pi=[F(x,sum(w)) for x in w]
            R=[F(rng.randint(4,16),4) if i<g else (F(rng.choice([2,3]),4) if i<g+mid else F(rng.randint(0,1),4)) for i in range(n)]
            if sum(p*r for p,r in zip(pi,R))>F(1,2):continue
            T=[F(2**rng.randint(0,64)) for _ in range(n)];T[rng.randrange(n)]=F(2**64)
            k=[F(rng.randint(0,65536),rng.randint(1,17)) for _ in range(n)]
            cases.append(check(f'n{n}_{accepted}','expanded',pi,R,T,k));accepted+=1
    out=dict(status='PASS_EXACT_ABSTRACT_FINITE_CONTRACT',source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),contract_sha256=hashlib.sha256((ROOT/'task_contract.md').read_bytes()).hexdigest(),seed=16320261015,menu=dict(initial=3,pressure=5,expanded_per_n=32,n=[8,16,32],expanded_generation_attempts=attempts,selection='reject if meanR>.5; no data-dependent parameter optimization'),summary=dict(cases=len(cases),dual_zero_gap=len(cases),strict_improvements=sum(c['strict_optimization'] for c in cases),weighted_cost_exceeds_unweighted_budget=sum(c['weighted_opt_exceeds_unweighted_budget'] for c in cases),weighted_cost_exceeds_one=sum(c['weighted_opt_exceeds_one'] for c in cases),terminal_kappa_moment_checked=len(cases),good_marginals_checked=sum(c['checks']['good_rows'] for c in cases),supply_columns_checked=sum(c['checks']['supply_columns'] for c in cases),dual_inequalities_checked=sum(c['checks']['dual_inequalities'] for c in cases)),cases=cases,runtime=dict(python=__import__('sys').executable,elapsed_seconds=time.monotonic()-started,dependencies='standard library only'),execution=dict(producer_invocations=3,successful=3,failed=0),scope=['All assertions exact Fraction; no quadrature or floating inequality checks','R,T,kappa synthetic abstract finite coefficients, not kernel/FULL realization','All kappa normalized to sum kappa*pi<=1; does not certify actual high/shared-alpha realization','kappa weighted supply budget verified for unweighted Gamma, not automatically after b tilt','Optimal b*kappa transport has exact feasible primal and lower dual certificate with zero gap','No dimension-growth conclusion or original shared-alpha construction certified'])
    args.output.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out['summary']))
if __name__=='__main__':main()
