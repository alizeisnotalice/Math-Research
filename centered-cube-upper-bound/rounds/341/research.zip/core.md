# R341 — Exact block decomposition under the original full J

## Scope

The radius-adaptive grid investigation did not produce a general root-order payment for R340 growthbad. Charging approximately √n narrow radius bands independently at the old source fee O(√n)W costs O(n)W; the original physical tails do not disappear when the bands are adjacent. A shared-envelope restatement does not resolve that loss. This bounded note instead supplies the requested exact block identity for subsequent joint-potential modeling. It is not a new root receipt.

Keep the original hard-matched field, f, actual du, m_u=∫Q_u f, μ(du)=du/m_u, original physical prefixes E_r, J_y(r), H, ell, and all original G_out gates of R340. Fix any preassigned finite or countable measurable partition {E_j} of E. Empty blocks are allowed. No change is made to m, q, the source, or J.

## Fixed-row definitions

At a fixed source y and physical radius r define the finite positive measure

    ρ(du)=1_{E_r}(u)c_u(y)μ(du).

Set

    J=∫ρ,       V=∫m_uρ(du),       S=∫√m_uρ(du),
    J_j=∫_{E_j}ρ,  V_j=∫_{E_j}m_uρ,  S_j=∫_{E_j}√m_uρ.

On J>0 put

    D=V−S²/J,
    D_j=V_j−S_j²/J_j,     t_j=S_j/J_j,     t=S/J,

with D_j=t_j=0 on J_j=0. On J=0 all energies below are zero. The hard contract m_u≥q_-aⁿ>0 and m_u≤λbⁿ, together with |E|<∞, makes J,V,S finite. In particular Cauchy gives 0≤D_j≤V_j and 0≤D≤V.

The exact pair formula is

    D=(1/(2J))∬(√m_u−√m_v)²ρ(du)ρ(dv).             (1)

This energy uses the original full row J, not a block-normalized substitute.

## Dilution and the full cross-block identity

Let D_within denote the part of (1) with u,v in the same E_j, and D_cross its complementary part. Define

    B=Σ_j J_j(t_j−t)²
      =(1/J)Σ_{j<k}J_jJ_k(t_j−t_k)².                (2)

Then all of the following are exact:

    D = Σ_j D_j + B,                                 (3)
    D_within = Σ_j (J_j/J)D_j,                       (4)
    D_cross = Σ_j (1−J_j/J)D_j + B.                  (5)

Thus the standard within-plus-between decomposition (3) is not the decomposition of the original pair domains. In particular, the original cross-block contribution is generally larger than B. Equation (4) explicitly retains dilution by the full J.

Proof. The block diagonal integral in (1) equals 2J_jV_j−2S_j²=2J_jD_j, giving (4). For distinct j,k, the unordered block-pair contribution is

    (J_kV_j+J_jV_k−2S_jS_k)/J
     =(J_kD_j+J_jD_k)/J+(J_jJ_k/J)(t_j−t_k)².        (6)

Summing (6) yields (5), since Σ_{k≠j}J_k=J−J_j. Adding (4),(5) yields (3). Alternatively, (3) follows by expanding ΣJ_j(t_j−t)²=ΣS_j²/J_j−S²/J. All sums involved in (1),(2),(4),(5),(6) are nonnegative and converge by Tonelli; ΣS_j²/J_j≤ΣV_j=V. Thus countably many blocks require no finite-enumeration assumption or omitted remainder block.

A simple exact algebra diagnostic shows the missing term can be the entire cross energy. Give block 1 two atoms with (ρ-weight,mass)=(1,1),(1,9), and block 2 one atom (2,4). Both block means t_j equal 2, so B=0. Nevertheless D_1=2,D_2=0,J_1=J_2=2,J=4; hence D=2, D_within=1 and D_cross=1. This is an identity check, not a claim that the atomic receiver fixture realizes every original cube constraint.

## Far-mass comparison with every original gate retained

At the same row let χ(y,r,u,v) be precisely the original high-past and outside-center indicators in G_out, optionally with any further nonnegative indicator mask. Keep the strict orientation m_u>K m_v with K>1. Define

    d_gate(y,r)=(1/J)∬1_{m_u>K m_v}χ
                           (√m_u−√m_v)²ρ(du)ρ(dv),
    g_gate(y,r)=(1/J)∬1_{m_u>K m_v}χ
                           (m_u−m_v)ρ(du)ρ(dv).     (7)

Zero rows are zero. For every such pair,

    1≤(m_u−m_v)/(√m_u−√m_v)²
       =(√m_u+√m_v)/(√m_u−√m_v)
       ≤c_K=(√K+1)/(√K−1).

Consequently, without removing any gate,

    d_gate ≤ g_gate ≤ c_K d_gate.                   (8)

Moreover d_gate≤D: the oriented strict far domain and its reversal are disjoint, and the kernel in (1) is symmetric, so the complete unordered energy has enough mass to contain this one orientation. This does not require χ to be symmetric.

Split d_gate into same-block and different-block terms. They obey respectively

    d_gate,within ≤ Σ_j (J_j/J)D_j,
    d_gate,cross ≤ Σ_j (1−J_j/J)D_j+B.               (9)

They do not in general equal those expressions, because the far-mass and original traffic gates have removed pairs. The same split of g_gate is bounded by c_K times the respective right-hand sides. There is no replacement of cross-block traffic by B alone.

Multiplying (8),(9) by the original f(y)1_{J_y(r)≥H}dy ell(dr) preserves every inequality. For the precise χ of G_out this gives, for example,

    D_out ≤ G_out ≤ c_K D_out ≤ c_K 𝓓,
    𝓓=∫ell(dr)∫f(y)1_{J_y(r)≥H}D(y,r)dy.           (10)

The comparison adds no new source fee and no altered physical atom, but 𝓓 has no root-order bound proved here. In particular (10) alone is not a payment. For K=e^{√n}, c_K=(e^{√n/2}+1)/(e^{√n/2}−1); any original outer multiplier applies to all terms without alteration.

## What source sharing would still have to control

Although Σ_j J_j/J=1 on positive rows, those fractions depend on y and the original r. They are not a preassigned source partition with a guaranteed capture fraction at each assigned receiver. Treating them as free source labels would require a separate proof of the actual posterior leakage, and the omitted cross-block term in (5) would still remain.

The exact missing coupled quantity for any proposed blockwise payment is therefore

    ∫ell∫f1_{J≥H}[Σ_j(1−J_j/J)D_j+B],              (11)

or its smaller original-gated counterpart in (7),(9). This identifies which variance remains attached to the real cross-block pairs. It does not introduce a new residual into the original ledger: (11) is only an accounting upper bound for an already existing pair domain. A useful next construction must control this domain jointly with any block-source leakage, rather than use ΣJ_j/J=1 to delete it. No such general control is established in this note.

## Verification

A separate saved Python Fraction script checks (1)–(6), the zero-block convention, the displayed diagnostic, and the far-mass comparison for square-integer masses. Its actual run is recorded below. These are exact algebra checks, not a simulation of the original continuum G_out or evidence of general root-order closure.

`/tmp/r341_core_checks.py` was actually executed with standard-library Fraction arithmetic. It passed 240 block cases, including an empty block in each; 1,440 exact block equalities; 518 strict far-mass comparisons for K=4,9,16,25 and square masses with roots 1,...,30; and three equal-block-mean diagnostic assertions. The block cases exhaust weights in {0,1,2} on four fixed square-mass atoms (excluding the all-zero row), under three distinct partitions. No numerical approximation or continuum-realizability claim enters these checks. Only this note and its checks file are authored; bounded delivery stops here.
