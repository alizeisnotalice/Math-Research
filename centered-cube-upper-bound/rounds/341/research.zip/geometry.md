# R341 — Original traffic retention removes the 1/ε grid padding

## Precise result and what it pays

Use exactly the contract and original G_out in `/tmp/r340_core.md`: arbitrary f≥0 in L¹, W=∫f, actual finite Lebesgue receiver set E, a≤R_u≤b≤2a, m_u=∫_{Q_u}f=q_uR_uⁿ, q_-≤q_u≤λ, q_-=3λ/4, dμ(u)=du/m_u, original E_r,J_y(r), strict global past Z, and ell=b^{-n}δ_b+n r^{-n-1}dr. All original high-J, high-past, strict mass-gap, common-source, and outer-center gates remain as stated there. Fix the original K,h,α; this result does not alter them. Let X_q(A)=∫_Aq_u du.

For 0<η≤1 set

    L=nb,
    M_L(u)=∫_{Q_{2L}(u)}f,
    A={u∈E:m_u≥ηM_L(u)}.                            (1)

For any 0<β<1, the following receipt holds for the original positive traffic:

    G_out(A) ≤ 2β X_q(A)
                +2[1+log(λ/(ηβq_-))]W.              (2)

In particular, take η=e^{-√n} and β=ε/2 with 0<ε<1. Then

    G_out ≤ G_newbad+εX_q
               +2[1+√n+log(8/(3ε))]W,              (3)

where G_newbad is exactly the original G_out with the additional large-endpoint gate

    m_u<e^{-√n} ∫_{Q_{2nb}(u)} f.                    (4)

This replaces the R340 grid size nb/ε by nb. Its receiver fee remains εX_q; its source fee is explicitly twice the displayed root-order coefficient. Since ε<1 and M_{nb}≤M_{nb/ε}, the new bad endpoint set is contained in the previous growthbad set. In particular, (2) pays the old growthbad traffic on

    ηM_{nb}(u)≤m_u<ηM_{nb/ε}(u).

The larger-growth complement (4) remains unpaid. No general closure is asserted.

## One common grid and the exact original traffic split

For a common shift t uniform on [0,L)ⁿ, let

    S_j^t=t+Lj+[0,L)ⁿ,       j∈Zⁿ,
    W_j^t=∫_{S_j^t}f,
    j_t(u)=the cell containing u,
    p_t(u)=(1/m_u)∫_{Q_u∩S_{j_t(u)}^t}f.            (5)

These are actual disjoint source cells, with Σ_jW_j^t=W. The single shift t is shared by all sources and all receivers. Nothing is chosen separately for an endpoint or a source. Every source cell containing u is contained in Q_{2L}(u), so for every u∈A,

    W_{j_t(u)}^t≤M_L(u),
    m_u≥η W_{j_t(u)}^t.                              (6)

Write Γ_A for the original nonnegative traffic measure in variables (r,y,u,v), with u∈A and every factor and gate from G_out retained. Its total mass is G_out(A). Define

    T_t=∫1_{y∈S_{j_t(u)}^t}dΓ_A,
    U_t=∫1_{y∉S_{j_t(u)}^t}dΓ_A.

For every common shift there is the exact identity

    G_out(A)=T_t+U_t.                                (7)

This is a split of the actual shared source y in the original integral. It is not a replacement posterior. Both pieces have all original J, ell, receiver measures, mass and past gates. We will pay T_t and exploit a uniform positive average fraction of retained *traffic*, rather than require containment of the whole cube Q_u.

Split the retained part further:

    T_t=T_t^{pure}+T_t^{thin},
    pure={u∈A:p_t(u)≥β},    thin={u∈A:p_t(u)<β}.      (8)

Here these names describe only the capture fraction in the actual common cell; neither branch replaces the original source density or receiver set.

## Payment of retained traffic with sufficient source capture

Fix t and a cell j. On the pure branch assigned to j, (5)–(6) give

    ηW_j^t≤m_u≤W_j^t/β.                              (9)

For the upper bound, βm_u≤∫_{Q_u∩S_j^t}f≤W_j^t. Thus W_j^t>0 whenever there is such an endpoint.

Apply the proved R339 source-weighted mass-window receipt to the source f1_{S_j^t}, the large endpoints in this cell and branch, and the *full-f* endpoint masses in (9). The small endpoints and original full J are unchanged. Explicitly, after the small-endpoint row is bounded by m_u, the actual large-center volume at source y is supported on the radius interval

    A_j=max(a,(ηW_j^t/λ)^(1/n)),
    B_j=min(b,(W_j^t/(βq_-))^(1/n)).

If A_j>B_j, the branch is empty. Otherwise its source-centered actual receiver volume is bounded by rⁿ between these radii, and by B_jⁿ above B_j. The original clock yields

    n log(B_j/A_j)+B_jⁿell([B_j,b])
       =1+n log(B_j/A_j)
       ≤1+log(λ/(ηβq_-)).                            (10)

The inclusive tail equals 1 also when A_j=B_j or B_j=b, and includes the actual b atom when B_j<b; no atom is introduced at B_j. This is an actual receiver-volume estimate, with no density cap on f.

Summing over the disjoint source cells gives, for every common t,

    T_t^{pure}≤C_βW,
    C_β=1+log(λ/(ηβq_-)).                            (11)

The λ/q_- factor occurs only inside the logarithm. No source mass is reused across cells.

## Low source capture costs only its retained traffic

For an endpoint u, the original gated small-endpoint row divided by J is at most m_u: use m_u-m_v≤m_u, and bound the gated v capture integral by the same original J_y(r). After this bound, the retained source on the thin branch contributes

    T_t^{thin}
      ≤∫_{A:p_t(u)<β}du ell([R_u,b])
                       ∫_{Q_u∩S_{j_t(u)}^t} f
      =∫_{A:p_t(u)<β}q_u p_t(u)du
      ≤βX_q(A).                                     (12)

This pays only the retained source traffic of low-capture endpoints. It does not discard their whole original traffic or assume that their source mass outside the cell is small. The original inclusive tail, including the b atom and all selector atoms, is used in the equality.

Together (11)–(12) prove the shiftwise bound

    T_t≤C_βW+βX_q(A).                                (13)

## Exact retained fraction of the original transport

For fixed real points u,y and a uniform common shift in [0,L)ⁿ, the probability that they fall in the same source cell is

    s_L(u,y)=∏_{i=1}^n(1-|u_i-y_i|/L)_+.            (14)

In one coordinate the set of separating shifts has length |u_i-y_i| when that distance is at most L; when it exceeds L, the same-cell event is empty. Coordinate independence gives (14). Cell-face events have zero shift measure.

On the support of Γ_A, y∈Q_u, hence |u_i-y_i|≤R_u/2≤b/2 and L=nb. Therefore

    s_L(u,y)≥(1-1/(2n))ⁿ≥1/2.                       (15)

The last inequality is Bernoulli's inequality, valid also at n=1. This is a pointwise statement about the actual common source participating in the original traffic, not a whole-cube containment probability.

Positive Tonelli applied to the original traffic measure gives the exact averaged identities

    E_t T_t=∫s_L(u,y)dΓ_A,
    E_t U_t=∫[1-s_L(u,y)]dΓ_A,
    G_out(A)=E_t T_t+E_t U_t.                        (16)

The total traffic is finite because the previously proved original-row estimate gives G_out(A)≤X_q(A)<∞. Equations (13),(15),(16) imply

    (1/2)G_out(A)≤E_t T_t≤C_βW+βX_q(A),

which is precisely (2). All original gates, particularly high global past and outer centers, survive inside Γ_A. No benefit from those gates beyond positivity is being claimed in this step.

Measurability follows from the coordinatewise floor assignment, the measurable radius selector, and Tonelli for (t,u,y)↦f(y)1_{Q_u}(y)1_{S_{j_t(u)}^t}(y). Countability handles the cells. For any fixed t their faces are Lebesgue null and therefore f-null. No favorable shift must be chosen: each shift is a legal common partition, and the proof averages the same original traffic over those partitions.

## Full hard-slot replacement

Retain the original R338 K=e^{√n}, h=(1+√n)/(εq_-), α=(1+√n)^(1/n), and its original complete-slot coefficient

    C_{ε,n}=(λ/q_-)[(2+3√n+2e^{-√n})/ε+1+√n].

With η=e^{-√n}, β=ε/2, combine (3) directly with that complete R338 slot, to obtain

    B_H(f,ν)≤G_newbad+3εX_q
         +{C_{ε,n}+2[1+√n+log(8/(3ε))]}W.            (17)

This replaces the previous R340 localization payment; neither its source fee nor the earlier R339 fee is added again. The original entrance from the supplied ledger therefore becomes

    T_*≤8λHW_β+2d_eff A_nW_ν/H+2G_newbad+6εX_q
         +2{C_{ε,n}+2[1+√n+log(8/(3ε))]}W_β.         (18)

The receiver coefficient remains 6ε, so the supplied ledger's ε=119/3072 and external multiplier Λ=128/119 still give 6Λε=1/4. All other entrance terms and historical unpaid slots remain due. The new result does not pay (4) or certify the full weak-(1,1) root-order target.

The bounded constructive improvement is the removal of the 1/ε padding in the source neighborhood. At a genuinely short grid L comparable to b, formula (14) remains exact, but this proof's universal lower retention factor can be exponentially small in n. No root-cost assertion for that short grid is made here; a further improvement would need a quantitative bound on the actual transport integral in (16), beyond the uniform bound (15).

## Reproducible verification

`/tmp/r341_geometry_checks.py` was actually run using Python Fraction arithmetic and passed 832 exact assertions:

- 75 exact one-dimensional shared-shift integrals, evaluated by partitioning the whole shift period at every cell-index discontinuity;
- 2 tensor-product kernel checks;
- 128 retention lower-bound checks for n=1,...,128;
- 384 receiver-fee checks, including ε=119/3072;
- 243 low-purity retained-row checks with a finite genuine probability vector and bounded row multipliers.

These are finite checks of the scalar mechanics, not a numerical evaluation of G_out or a verification of the remaining growthbad branch. The general payment is the analytic argument above. Reproduce with `python3 /tmp/r341_geometry_checks.py`.
