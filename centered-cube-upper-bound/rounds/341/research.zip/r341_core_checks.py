"""R341 exact algebra checks; atomic measures are diagnostics, not cube fixtures."""
from fractions import Fraction as F
from itertools import product

counts={"block_cases":0,"block_equalities":0,"far_comparisons":0,"diagnostic":0}
roots=[1,2,3,5]
partitions=[(0,0,1,1),(0,1,2,3),(0,1,0,2)]
for weights_int in product(range(3),repeat=4):
    if not any(weights_int):
        continue
    weights=list(map(F,weights_int))
    for labels in partitions:
        J=sum(weights); V=sum(w*x*x for w,x in zip(weights,roots)); S=sum(w*x for w,x in zip(weights,roots))
        D=V-S*S/J
        # Include an empty block in every case.
        blocks=range(max(labels)+2)
        Jj={j:sum(weights[i] for i in range(4) if labels[i]==j) for j in blocks}
        Vj={j:sum(weights[i]*roots[i]**2 for i in range(4) if labels[i]==j) for j in blocks}
        Sj={j:sum(weights[i]*roots[i] for i in range(4) if labels[i]==j) for j in blocks}
        Dj={j:Vj[j]-Sj[j]**2/Jj[j] if Jj[j] else F(0) for j in blocks}
        tj={j:Sj[j]/Jj[j] if Jj[j] else F(0) for j in blocks}
        pair=within=cross=F(0)
        for i in range(4):
            for k in range(4):
                e=weights[i]*weights[k]*(roots[i]-roots[k])**2/(2*J)
                pair+=e
                if labels[i]==labels[k]: within+=e
                else: cross+=e
        between=sum(Jj[j]*(tj[j]-S/J)**2 for j in blocks)
        between_pair=sum(Jj[j]*Jj[k]*(tj[j]-tj[k])**2/J for j in blocks for k in blocks if j<k)
        equalities=[(D,pair),(D,sum(Dj.values())+between),
                    (within,sum(Jj[j]*Dj[j]/J for j in blocks)),
                    (cross,sum((1-Jj[j]/J)*Dj[j] for j in blocks)+between),
                    (between,between_pair),(within+cross,D)]
        for lhs,rhs in equalities:
            assert lhs==rhs
            counts["block_equalities"]+=1
        assert min(D,within,cross,between,*Dj.values())>=0
        counts["block_cases"]+=1

for sqrtK in (2,3,4,5):
    K=sqrtK**2
    cK=F(sqrtK+1,sqrtK-1)
    for a in range(1,31):
        for b in range(1,31):
            if a*a>K*b*b:
                d=(a-b)**2
                g=a*a-b*b
                assert d<=g<=cK*d
                counts["far_comparisons"]+=1

J1=F(2); J2=F(2); D1=F(2); D2=F(0)
assert F(4)/J1==F(4)/J2==2
assert (J1*D1+J2*D2)/(J1+J2)==1
assert (1-J1/(J1+J2))*D1+(1-J2/(J1+J2))*D2==1
counts["diagnostic"]+=3
print("PASS",counts)
print("These exact checks certify block algebra only; original continuum feasibility is not asserted.")
