"""Exact scalar checks for the R341 common-grid retention proof."""
from fractions import Fraction as F
from itertools import product


def floor_q(x):
    return x.numerator // x.denominator


def same_cell_shift_measure(u,y,L):
    # Complete partition of one shift period by every cell-index jump.
    cuts=sorted({F(0),L,u-L*floor_q(u/L),y-L*floor_q(y/L)})
    ans=F(0)
    for left,right in zip(cuts,cuts[1:]):
        t=(left+right)/2
        if floor_q((u-t)/L)==floor_q((y-t)/L):
            ans+=right-left
    return ans/L

counts={'shift_kernel':0,'tensor_kernel':0,'retention':0,'receiver_fee':0,'low_purity_retention':0}
for L in [F(1),F(2),F(3,2)]:
    for u,y in product([F(-7,4),F(-1,3),F(0),F(2,5),F(5,3)],repeat=2):
        exact=same_cell_shift_measure(u,y,L)
        expected=max(F(0),1-abs(u-y)/L)
        assert exact==expected
        counts['shift_kernel']+=1
for us,ys,Ls in [
    ([F(0),F(1,3)],[F(1,4),F(-1,5)],[F(1),F(2)]),
    ([F(-1),F(1),F(0)],[F(-1,2),F(4,3),F(1,7)],[F(2),F(2),F(3)]),
]:
    exact=F(1); expected=F(1)
    for u,y,L in zip(us,ys,Ls):
        exact*=same_cell_shift_measure(u,y,L)
        expected*=max(F(0),1-abs(u-y)/L)
    assert exact==expected
    counts['tensor_kernel']+=1
for n in range(1,129):
    retention=(1-F(1,2*n))**n
    assert retention>=F(1,2)
    counts['retention']+=1
    for eps in [F(1,4),F(1,16),F(119,3072)]:
        beta=eps/2
        assert beta/retention<=eps
        counts['receiver_fee']+=1
# A real four-cell posterior and a bounded original-row multiplier surrogate:
# retained traffic on a low-purity label cannot exceed its posterior mass.
posterior=[F(1,10),F(2,10),F(3,10),F(4,10)]
for label in product([F(0),F(1)],repeat=4):
    purity=sum(p*t for p,t in zip(posterior,label))
    for row in product([F(0),F(1,2),F(1)],repeat=4):
        retained=sum(p*t*r for p,t,r in zip(posterior,label,row))
        if purity<F(1,4):
            assert retained<=purity<F(1,4)
            counts['low_purity_retention']+=1
print({'exact_assertions':sum(counts.values()),'counts':counts,'status':'passed'})
