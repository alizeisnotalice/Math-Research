# R341 independent proposition screen — actual shared-row mass dispersion

Owned only `/tmp/r341_audit.md`; no Git/other-author edits, no author proof read. Scope is the fixed original hard-matched field, actual receiver du, m_u=f(Q_u)=q_u R_u^n, q_-<=q_u<=lambda, 0<a<=R<=b<infinity, finite-volume E, f>=0 in L1, and the unchanged physical prefixes/ell. This is an interface bound, not a new root budget.

## Disposition and exact coefficient: PASS

At each fixed (y,r), let d rho(u)=c_u(y)1_{R_u<=r}du/m_u and set

 J=integral d rho, V=integral m_u d rho, S=integral sqrt(m_u)d rho.

For K>1 put c_K=(sqrt(K)+1)/(sqrt(K)-1). Then

 (1/J) integral integral_{m_u>K m_v}(m_u-m_v)d rho(u)d rho(v)
     <= c_K [V-S^2/J].                                      (1)

Zero rows are assigned zero. The orientation has NO additional factor2 or1/2 on the right. Indeed on a>Kb,

 a-b <= c_K (sqrt(a)-sqrt(b))^2,

since (sqrt(a/b)+1)/(sqrt(a/b)-1)<=c_K. The full symmetric squared-gap integral equals2(JV-S^2), and its a>b half equals JV-S^2; the strict far part is a positive subset of that half. This gives exactly (1). The scalar constant is sharp as a/b decreases to K from above, although neither scalar sharpness nor this diagnostic proves sharpness for a matched cube field. K=1 is excluded; the coefficient diverges at that endpoint.

## Original gates and strongest retained-gate interface

Let M(y,r,u,v) be ANY measurable original gate/multiplier in[0,1], including the existing high-past, center, growthbad or other positive endpoint restrictions, WITHOUT changing J or the row measure. Put

 M_sym(u,v)=1_{m_u>K m_v}M(u,v)+1_{m_v>K m_u}M(v,u).

Its two supports are disjoint, so0<=M_sym<=1. The exact oriented squared-gap upper receipt is

 (1/J) integral integral 1_far M(u,v)(m_u-m_v)d rho^2
   <= c_K/(2J) integral integral M_sym(u,v)
                                      (sqrt(m_u)-sqrt(m_v))^2 d rho^2
   <= c_K [V-S^2/J].                                      (2)

The symmetrized expression retains each original oriented gate at the appropriate swapped orientation. It is NOT licensed to put the original nonsymmetric gate directly in a one-sided variance expression and assume a symmetric half-factor. The high-J indicator is independent of the pair, so it can remain explicitly in front of the dispersion. In particular the actual residual satisfies

 G_out <= c_K integral f(y)ell(dr)1_{J_y(r)>=H}
                      [V_y(r)-S_y(r)^2/J_y(r)]dy.           (3)

One may alternatively retain the sharper M_sym squared-gap receipt from(2). All original physical radius atoms, including the terminal b atom, remain in ell. No component FIRST, new receiver/source law or independently selected source was used.

## Finiteness, measurability and baseline limitation

The fixed hard contract gives q_-a^n<=m_u<=lambda b^n. Hence mu(E)<=|E|/(q_-a^n)<infinity, and J,V,S are jointly measurable finite prefix integrals. Cauchy gives0<=V-S^2/J<=V. When J0, rho0, V0 and S0, so no undefined quotient is integrated. All proof steps use nonnegative Tonelli or finite integrals; no informal disintegration/selection is necessary.

The complete first moment is EXACTLY

 integral f(y)ell(dr)V_y(r)dy
   =integral_E m_u ell([R_u,b])du
   =integral_E q_u du=X_q.                                 (4)

Thus (3) is finite and at present gives only c_K X_q. The original FIRST/cap contract does not by itself establish that its integrated deficit is root-source-priced or a small fraction of X_q. For K=exp(sqrt(n)), c_K=1+2/(exp(sqrt(n)/2)-1) tends to1, but that coefficient improvement is not a bound for the unknown integrated dispersion. The original complete source square/negative credit cannot be subtracted again after replacing this residual by(3). This is a positive upper bound for that residual, not an exact disjoint allocation of the original traffic or a new source payment.

## Precise variance and relative-entropy versions

On a nonzero row define the ORIGINAL probability P=d rho/J, mean mbar=V/J, and the size-biased diagnostic law Q with dQ/dP=m/mbar. Both laws refer to the same actual row; they do not replace its source or denominator in the target. Let

 A_aff=integral sqrt(dQ/dP)dP=S/sqrt(JV).

Then

 V-S^2/J=J Var_P(sqrt(m))=V(1-A_aff^2).

Using squared-Hellinger convention H2=integral(sqrt(dP)-sqrt(dQ))^2=2(1-A_aff),

 V H2/2 <= V-S^2/J <= V H2.

For D_half=-2log(A_aff), the identity is V-S^2/J=V(1-exp(-D_half)). Jensen under P and Q proves

 D_half<=min(KL(P||Q),KL(Q||P)),

hence the deficit is at most V times1-exp(-min KL), and therefore at most V min(1,min KL). These are valid UPPER estimates only if the actual entropy is separately controlled. A small mean bias, differential/Shannon entropy of an arbitrary representation, or an unproved independent mass law supplies no such control. Conversely a small affinity deficit does not control an unrestricted KL without additional likelihood-ratio information. Here actual m is bounded above/below, so the entropies are finite, but their available range bound can depend on log(lambda/q_-)+nlog(b/a); no root integral estimate follows.

An equivalent exact variance-under-tilt description may be useful. Set T=log m and F(t)=log E_P exp(tT). Since T is bounded, F''(t)=Var_{P_t}(T) is legitimate for0<=t<=1. Then

 D_half=F(1)-2F(1/2)+F(0)
       =integral_0^(1/2) t F''(t)dt
          +integral_(1/2)^1 (1-t)F''(t)dt.

These are diagnostic identities for actual shared rows, not a new source tilting operation in the original traffic. An actual quantitative bound for the f*ell weighted affinity/variance deficit (or its gated pair form(2)) is the missing parameter needed to turn this interface into a new payment.

## Actual bounded local verification and stopping point

Reviewer executed768 exact Fraction assertions over positive finite mass/weight rows with K rational squares. They checked the unordered variance identity, oriented far receipt and a nonsymmetric fractional gate with its correct symmetrization. All passed. These are scalar diagnostics, not real cube/source test fields or evidence for an integrated root budget. No author proof or new numeric pipeline was read/run.

Final proposition-screen disposition: PASS for K>1 and the stated frozen hard contract, including the retained-gate form(2). No new epsilon debit or root source bill is certified. Stop at this bounded interface; any later author-file/integration review requires a new appended binding.


## First dispersion main comparison — PASS, no root payment

Read the initial `/tmp/r341_main.md` after the independent screen. Its directed original w and exact E_omit=D-E_w have the correct unordered-pair coefficient. E_omit>=0 by symmetrization of the mutually exclusive orientations, and it cannot be used twice. The proposed budget for D-E_omit is clearly marked unproved. Measurable quadratic minimization t=S/J is legal with zero rows guarded. Internal block contribution is sum(J_j/J)D_j; the cross-block expression retains the complementary internal variances as well as between-block means. No unsupported sum D_j or free source labels appear. This is an accurate interface/identity note, not a new source payment. It may be renamed as an auxiliary in the final integration, so this records content comparison rather than a final byte binding.

## Independent screen of the new retained-source common-grid receipt

This screen precedes reading the forthcoming geometric proof. PASS for the SAME original hard-matched positive G_out, with fixed A={m_u>=eta M(u)}, L=nb, M(u)=f(Q_(2L)(u)),0<eta<=1, and any0<beta<=1. Let a SINGLE global shift define side-L source cells C_j and the unique center label j(u). Define

 p_s(u)=f(Q_u intersect C_{j(u)}(s))/m_u.

For EVERY shift W_j=f(C_j) and the actual center-cell inclusion C_{j(u)} subset Q_(2L)(u) give W_j<=M(u). Thus growthgood implies m_u>=eta W_j even for cubes crossing the cell. Split A by p_s(u)>=beta and its strict complement. This split depends on the shift and large endpoint, but not on source y or the running physical clock within that fixed endpoint.

For the high-p endpoints, p_s(u)>=beta implies beta m_u<=f(Q_u intersect C_j)<=W_j. The ORIGINAL mass therefore lies in [eta W_j,W_j/beta]. Pay only the source portion y in C_j, using the unchanged full J and the R339 source-window center-volume argument. Summing j costs at most

 C_beta W, C_beta=1+log(lambda/(eta beta q_-)).

This is a source-restricted part of the original traffic, not the whole high-p endpoint traffic with its leakage omitted. On the low-p endpoints, the retained source portion is at most q_u p_s(u)<=beta q_u by the original receiver/source density tau_u(y)<=1. Its complete cost is at most beta X_q(A). Consequently, if G_ret(s) denotes the original positive traffic on A with the extra SAME-cell predicate y in C_{j(u)}(s),

 G_ret(s)<=C_beta W+beta X_q(A) for every shift.

The original integrand and all q/J/source/clock/pair gates are fixed independently of this auxiliary shift. For any captured source y in Q_u, the probability under a uniform global shift that u and y share a cell is exactly

 s(u,y)=product_i(1-|u_i-y_i|/L).

Since |u_i-y_i|<=R_u/2<=b/2 and L=nb, this is at least sigma_n=(1-1/(2n))^n>=1/2, the latter by Bernoulli's inequality. This holds also for n=1,R=b; grid/source/cube boundaries are Lebesgue-null and do not affect the averaging. Nonnegative Tonelli now yields

 sigma_n G_out(A)<=average_s G_ret(s)<=C_beta W+beta X_q(A),

so in particular

 G_out(A)<=2C_beta W+2beta X_q(A).

No individual good-p fraction or favorable shift is required; the average is used on the original common source and its actual positive traffic. There is no different shift per source point or receiver. The sharper reciprocal sigma_n is available, but the stated factor2 is uniformly valid. Every source cell mass is charged once per shared partition before averaging; countability/Tonelli settle all cells.

Taking eta=exp(-sqrt(n)), beta=epsilon/2 with0<epsilon<1 gives

 G_out<=G_newgrowthbad+epsilon X_q(A)
          +2[1+sqrt(n)+log(lambda/(beta q_-))]W.

The source coefficient genuinely has factor2 and the extra log(1/beta); the old R340 single source coefficient cannot be reused. The slot's existing2epsilon X_q plus this newepsilon gives3epsilon X_q as before, and the inherited entrance factor2 and outer multiplier must still be applied. The new deterministic growthbad uses Q_(2nb), so it is a subset of R340's Q_(2nb/epsilon) growthbad; no generally positive traffic improvement or bound for this remaining bad set is proved. This replaces the old grid payment, not a second source bill on the same branch. No cap or selector is asserted at the enlarged source-label length.

Reviewer executed550 additional exact Fraction scalar assertions for the retention lower bound, its radius dependence, and high-/low-p mass-window implications. All passed; these are bounded algebra diagnostics, not a numerical proof for the full original G_out. Await final geometric proof and integration; no final R341 archive freeze yet.


## Auxiliary core and posterior numeric file comparison (pending final geometry/ledger binding)

Read full `/tmp/r341_core.md` and its exact-check script. PASS for the stated block identities. Zero blocks and countably many blocks are handled with nonnegative pair sums; full-J dilution within a block is J_j/J, and cross energy contains sum(1-J_j/J)D_j in addition to between-block mean energy. The retained directed d_gate<=g_gate<=c_K d_gate comparison has the correct coefficients, keeps every original gate, and does not require the gate to be symmetric. Core does not register the dispersion as a new root payment. Its recorded240 block cases include1440 exact equalities;518 strict far comparisons and3 diagnostic assertions are separate, rather than counting240 as an extra240 proved equalities. The script is finite atomic algebra, not a claimed original cube realization.

Read full `/tmp/r341_numeric.py` and notes. Its independent shift-interval enumeration validates the triangular same-cell probability, and exact piecewise-affine integration handles the clipped kernel for all tested one-dimensional intervals. Tensor products and multiplicities integrate genuine positive-volume source boxes. Their actual single receiver hard response is q=1 from the assigned source mass R^n, but no whole actual receiver field or original high-past selector is certified. The exact uniform posterior formula for L>=R/2 is1-(1-R/(4L))^n; the separate clipped one-coordinate expression L/R is correctly included for L<R/2. The positive center/face/corner/diagonal examples make no source density cap assumption. They are separate source fixtures, not one freely mixed original field.

The finite tested grids include b,sqrt(n)b,nb; no data-dependent source quadrature replaces integration. All comparisons are Fraction, and very large exact rationals use integer-byte digests rather than float comparisons. Ordinary float displays and potential rounding to1 are clearly excluded from the889 exact assertions (44 basic plus338/169/338). This is evidence about posterior grid retention only, not G_out or its growthbad budget. The analytic uniform-posterior lower bound justifies the limited decision that requiring uniformly SMALL leakage cannot generically remove linear-n padding; it does not rule out the NEW fixed-retention proof above, which changes the mechanism by separately paying low-p endpoints.

The initial dispersion main was moved to auxiliary form; its E_omit credit and min-square interface remain valid without any new payment. One wording guard was sent to the parent: integrals of D,E_omit and the optimum t=S/J are finite, but an arbitrary measurable t need not have a finite quadratic-potential integral without a square-integrability hypothesis (it can still give an extended-value upper bound). Await final corrected auxiliary and geometric proof for final byte binding.


## Final geometric author proof comparison — PASS

Read complete `/tmp/r341_geometry.md` and its saved Fraction check script after the independent retained-source screen above. The original finite positive traffic measure Gamma_A is explicitly retained in variables(r,y,u,v). T_t and U_t are its exact same-cell/source-complement parts for ONE common grid, not receiver-private sources or changed posteriors. At each fixed shift, p_t>=beta is used only to bound the retained source part through ORIGINAL full-f mass windows[eta W_j,W_j/beta], and p_t<beta pays only its retained source traffic by beta X_q(A). The source-cell masses sum to W before averaging, so no source count or overlapping-label multiplier occurs.

The common-shift kernel product_i(1-|u_i-y_i|/L)_+ is exact for real points. On actual traffic y belongs to Q_u, giving the uniform retention lower bound at L=nb, including n1/R=b and null faces. The inequality G_A/2<=average T_t then recovers all original traffic on A. This is an analytic positive payment of the original integral. It neither assumes that the full cube stays inside the label cell nor that its source posterior leakage is small. That distinction is why the earlier short-grid small-leakage obstruction does not refute this new proof. The geometric constant2 and log(1/beta) source cost are both retained in full. Parent reports fresh execution of all832 Fraction scalar assertions:75 full shift-period integrals,2 tensor kernels,128 retention bounds,384 receiver-fee comparisons,243 low-p retained-row tests. These checks verify mechanics, not the actual remaining high-past G_out.

The source-label radius2nb is NOT a new cap/selector radius. The old and new actual source field, q, m, full J, strict mass/high-past/center masks, E_r and physical ell are unchanged. The new bad receiver gate is m_u<eta f(Q_(2nb)(u)); it is contained in the former R340 bad gate at2nb/epsilon whenepsilon<1. A strictly positive traffic increase is not inferred for every field. Localbad remains unpriced.

## Corrected auxiliary and final main/ledger comparison — PASS

The auxiliary now explicitly limits the finite-quadratic-integral assertion to D,E_omit and the optimum t=S/J; arbitrary t requires integrability or gives an extended-value upper bound. This resolves the sole wording correction requested. The threshold beta is explicitly distinguished from historical source subscript W_beta in the final ledger. Neither change alters mathematical source/receiver fees.

Read the final new main and ledger at the bindings below. They correctly replace the R340 localization, rather than add its source bill again. With eta=exp(-sqrt(n)), beta=epsilon/2 and q_-=3lambda/4 the NEW source fee is

 2[1+sqrt(n)+log(8/(3epsilon))]W.

Together with the inherited R3382epsilon X_q this gives3epsilon X_q at the hard slot, and6epsilon X_q under its entrance factor2. The inherited8lambda H W_beta and2d_eff A_n W_nu/H stay intact; no additional slot-internal lambda H completion is introduced. The source in this matched contraction is beta=f; domination nu<=f does not reset q or any denominator. The earlier dispersed-mass auxiliary and full-J block note receive NO additional payment/absorption credit.

Exact local Fraction arithmetic confirms

 6*(128/119)*(119/3072)=1/4,
 1/4+1/256=65/256,  1-65/256=191/256.

The ledger conditions the old CZ combination on the authentic same-X outer aggregation. This is a replacement at the same slot, not an allowance accumulated per research round. It does not license a sum over arbitrary leaves/scales/private source copies. The remaining191/256 is unallocated; no other term is absorbed merely because numerical room remains.

All listed gaps remain: original positive localbad traffic, general soft crossing/post-crossing dense slots, hard branches not embedded in this contract, wide/extreme scales and low-pe threshold complements, chronological initial/deletion/future-source atoms, suffix negative credit, source/scale/outer sums and limits. Physical ell's b atom is not one of those historical time atoms. Neither a small auxiliary variance nor finite posterior-grid probabilities pay these gaps. General centered-cube root closure is not established.

## Final execution scope, bindings and disposition

Primary reports completed actual fresh runs: numeric889 exact posterior-probability assertions; geometry832 exact mechanics assertions; core240 block cases with1440 exact block equalities and positivity guards,518 exact far comparisons and3 diagnostic assertions. The numeric's ordinary float displays are not interval evidence and are excluded from its exact counts. Core atomic rows and numeric single-receiver boxes are not claimed to realize all original high-past/history conditions. Reviewer did not repeat full pipelines; reviewer's separate768+550 scalar assertions above are not added to primary counts.

Final numeric JSON metadata independently reads PASS with889 total,44 basic and338/169/338 stages; its scope agrees with notes and code. No solver, TeX/PDF compilation or detailed typesetting certification is included. The supplied frozen previous contract `/tmp/r340_core.md` may be copied unchanged into the archive as `previous_contract.md` with a locator explanation; it is an inherited contract, not a new re-certification of all historical entrance coefficients. Its hash is bound below. Only this audit file was written by the reviewer.

Earlier awaiting statements record preauthor stages and are superseded by this final comparison. Local final byte bindings:

| File | SHA256 |
|---|---|
| /tmp/r341_geometry.md | `b69bd130187d99e8d8cdb4c3cd5309866541c1f64d1d34ac0c51c666926088e9` |
| /tmp/r341_geometry_checks.py | `8826313abc2544c02f8ab616dcb49d12b172bc842700fb59a3e270d02953c6d6` |
| /tmp/r341_main.md | `24092b4908e18f51969a207555e3c27f7ea4b239e75b36fa9e9542eed0cae9db` |
| /tmp/r341_ledger.md | `a7fabb4da8647779782b77f7423ff8201be1b279dbb94c0797d80ad89c41e41a` |
| /tmp/r341_aux.md | `030564aadead50854edabb9523f1c70d5ae4fff02864d80cec48f17d7eb20967` |
| /tmp/r341_core.md | `d9a144bc4d7826f347d766dc0261ad5fe1b06bc5bf9b9826d4fa34ae334dae5b` |
| /tmp/r341_core_checks.py | `b718706720577751dc7efe88b9fffe8f8ab132eadaa153d28020cd208b57fa3f` |
| /tmp/r341_numeric.py | `7f56684428a9fd7cdc7d3096197baf2da8a3d6c1745ab4c5d1b11da927559008` |
| /tmp/r341_numeric.md | `41a286199b73dfab211f9c83af74eb2ddb04ad3a1ce80ded9c5cc34585a1b0ca` |
| /tmp/r341_numeric_result.json | `3eada7ec9a325751af978f78cfb3047bfc1c8de052f295e313ee169ff25eef9a` |
| /tmp/r340_core.md | `f030035399e805bb1a6a5f369d9c499bbf1500f74de02b53471d58107bc3ee90` |

Final disposition: PASS for the original-integral retained-source payment, exact auxiliary interfaces, final ledger replacement and evidence scope. No outstanding correction requested. Frozen after these final byte bindings; any subsequent content change needs a new binding. General root closure and the complete list of unpaid terms remain unproved.
