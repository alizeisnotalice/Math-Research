#!/usr/bin/env python3
"""Exact posterior grid separation for genuine positive-volume box sources."""
from fractions import Fraction as F
from math import isqrt,comb
from pathlib import Path
from collections import Counter
import json,hashlib
BASE=Path(__file__).resolve().parent
CHECK=Counter()
def ck(k,v):CHECK[k]+=1;assert v,k
def brief(x):
 if max(abs(x.numerator).bit_length(),x.denominator.bit_length())<1800:return str(x)
 a=abs(x.numerator);raw=(str(x<0)+':'+str(a.bit_length())+':').encode()+a.to_bytes((a.bit_length()+7)//8,'big')+b'/'+x.denominator.to_bytes((x.denominator.bit_length()+7)//8,'big')
 try:decimal=float(x)
 except OverflowError:decimal='outside_float_range'
 return dict(decimal=decimal,sha256=hashlib.sha256(raw).hexdigest(),encoding='negative:numerator_bitlength:unsigned_numerator_bytes/unsigned_denominator_bytes')
def interval_same(lo,hi,L):
 points=sorted(set([lo,hi]+[t for t in [-L,F(0),L] if lo<t<hi]));area=F(0)
 for a,b in zip(points,points[1:]):
  fa=max(F(0),1-abs(a)/L);fb=max(F(0),1-abs(b)/L);area+=(b-a)*(fa+fb)/2
 return area/(hi-lo)
def shift_same_direct(y,u,L):
 # Exact common-shift interval enumeration, no assumed triangular formula.
 points=sorted(set([F(0),L,y%L,u%L]));ans=F(0)
 for a,b in zip(points,points[1:]):
  s=(a+b)/2
  if (y-s)//L==(u-s)//L:ans+=b-a
 return ans/L

def basic_checks():
 before=sum(CHECK.values())
 for L in [F(1,3),F(1),F(2),F(7,3)]:
  for y,u in [(F(0),F(0)),(F(-1,4),F(1,4)),(F(-2),F(1)),(F(1,2),F(0)),(L,F(0)),(-L,F(0)),(L/3,-L/6)]:
   ck('exact_common_shift_triangle',shift_same_direct(y,u,L)==max(F(0),1-abs(y-u)/L))
 for R in [F(1),F(3,2),F(2)]:
  for L in [R/4,R/2,R,2*R]:
   direct=interval_same(-R/2,R/2,L)
   expected=1-R/(4*L) if L>=R/2 else L/R
   ck('uniform_1d_clipped_integral',direct==expected)
 for n in [1,2,4,16]:
  q=F(1,4*n)
  ck('tensor_binomial_independent_identity',1-(1-q)**n==sum(((-1)**(j+1)*comb(n,j)*q**j for j in range(1,n+1)),F(0)))
 return sum(CHECK.values())-before

def case(n):
 root=isqrt(n);ck('integer_sqrt_dimension',root*root==n);Rvalues=[F(1),F(3,2),F(2)];out=[]
 for R in Rvalues:
  b=F(2);width=R/(100*n)
  profiles={
   'uniform_capture_cube':[(-R/2,R/2)]*n,
   'positive_center_box':[(-width/2,width/2)]*n,
   'positive_face_box':[(R/2-width,R/2)]+[(-width/2,width/2)]*(n-1),
   'positive_corner_box':[(R/2-width,R/2)]*n,
   'positive_diagonal_box':[(R/4-width/2,R/4+width/2)]*n,
  }
  for grid,L in [('b',b),('sqrt_n_b',root*b),('n_b',n*b)]:
   whole=1-(1-R/L)**n;uniform=1-(1-R/(4*L))**n
   ck('posterior_vs_whole_cube',0<=uniform<=whole<=1)
   ck('uniform_linear_upper',uniform<=n*R/(4*L))
   nx=n*R/(4*L)
   ck('uniform_rational_lower',uniform>=nx/(1+nx))
   pvalues={}
   for name,intervals in profiles.items():
    same=F(1)
    for (lo,hi),multiplicity in Counter(intervals).items():
     ck('positive_volume_actual_capture',-R/2<=lo<hi<=R/2)
     same*=interval_same(lo,hi,L)**multiplicity
    sep=1-same
    ck('posterior_separation_probability_range',0<=sep<=whole)
    if name=='uniform_capture_cube':ck('uniform_tensor_integral_exact',sep==uniform)
    pvalues[name]=sep
   ck('geometry_order_exact',pvalues['positive_center_box']<=pvalues['positive_face_box']<=pvalues['positive_corner_box'])
   ck('corner_vs_uniform_exact',uniform<=pvalues['positive_corner_box'])
   # All models are positive L1 sources of mass R^n on their named box,
   # so receiver u=0 hard R has exact q=1, without a density upper bound.
   point_corner=1-(1-R/(2*L))**n
   ck('positive_corner_enclosed_by_boundary_point',pvalues['positive_corner_box']<=point_corner)
   out.append(dict(R=str(R),b=str(b),grid=grid,L=str(L),whole_cube_crossing_exact=brief(whole),whole_cube_crossing_decimal=float(whole),posterior_uniform_exact=brief(uniform),posterior_uniform_decimal=float(uniform),posterior_over_whole_decimal=float(uniform/whole),profiles={name:dict(probability_exact=brief(v),probability_decimal=float(v)) for name,v in pvalues.items()},boundary_point_corner_exact=brief(point_corner),source_box_width=str(width),actual_receiver_q='1',actual_source_mass=brief(R**n)))
 for target in [F(1,16),F(1,4),F(1,2)]:
  R=F(2);safe=n*R/(4*target);too_small=n*R*(1-target)/(8*target)
  ck('posterior_linear_scale_sufficient',1-(1-R/(4*safe))**n<=target)
  ck('half_necessary_scale_fails',1-(1-R/(4*too_small))**n>target)
 return dict(n=n,sqrt_n=root,rows=out)

def main():
 models=[];stages=[];before=sum(CHECK.values());basic=basic_checks()
 for name,ns in [('initial',[16,64]),('boundary_stress',[256]),('expanded',[1024,4096])]:
  before=sum(CHECK.values());models.extend(case(n) for n in ns);stages.append(dict(name=name,dimensions=ns,exact_checks=sum(CHECK.values())-before))
 out=dict(status='PASS',total_exact_checks=sum(CHECK.values()),basic_exact_checks=basic,stages=stages,check_counts=dict(CHECK),models=models,scope='Exact common-shift posterior probabilities for compact positive-L1 box sources and a fixed actual hard receiver. No original highpast traffic, full receiver selector, or general density cap. Float displays are diagnostics; all comparisons use Fraction.')
 (BASE/'r341_numeric_result.json').write_text(json.dumps(out,sort_keys=True,indent=2)+'\n')
 print(json.dumps(dict(status='PASS',total_exact_checks=sum(CHECK.values()),basic_exact_checks=basic,stages=stages),sort_keys=True))
if __name__=='__main__':main()
