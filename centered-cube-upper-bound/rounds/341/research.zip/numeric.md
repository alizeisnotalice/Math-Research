# R341 — posterior weighting changes the padding constant, not its generic scale

This calculation concerns the random-grid source/receiver separation probability only. It does not evaluate original high-past traffic, select a full receiver field, or certify the remainder of R340. All source examples are compact positive-volume L1 boxes; no density upper bound or source point mass is used for the geometry comparison.

## Exact formulas

For one common uniform shift of a side-L grid, fixed receiver center u and source y belong to the same cell with probability

`prod_i (1-|u_i-y_i|/L)_+`.

The source leakage probability is its complement. In one dimension this follows by partitioning the shift interval at the two fractional locations. The script independently enumerates those shift intervals for 28 rational pairs, including zero distance, negative locations, and distance exactly L.

For the uniform posterior on Q_R(u), independent coordinates have E|y_i-u_i|=R/4. For L>=R/2, exact integration yields

`posterior leakage p = 1-(1-R/(4L))^n`.

For L<R/2 the one-coordinate same-cell expectation is L/R, also checked with the clipped integrand. In comparison, requiring the **whole** Q_R(u) to stay in its center's grid cell has crossing probability

`p_whole = 1-(1-R/L)^n` for L>=R.

Thus posterior weighting changes R/L to R/(4L) in the uniform case. With x=R/(4L), elementary Bernoulli bounds give

`n x/(1+n x) <= p <= n x`.

Consequently, for this genuine uniform posterior, requiring p<=delta necessarily requires

`L >= nR(1-delta)/(4delta)`,

while `L >= nR/(4delta)` suffices. This is an analytic obstruction to replacing n by sqrt(n) using posterior weighting alone for all sources. It is not a fitted dimension exponent or an assertion about the full operator. The script checks these rational bounds and the success/failure of representative scale choices for delta=1/16,1/4,1/2.

## Positive-volume geometry fixtures

Each actual receiver is centered at 0 with hard side R in {1,3/2,2}; b=2. Its source has total mass R^n, entirely inside Q_R, so its actual hard response q=1 exactly. The source is uniform on one of:

- the full capturing cube Q_R;
- a center cube of side w=R/(100n);
- a face cube with first coordinate interval [R/2-w,R/2], remaining intervals [-w/2,w/2];
- a corner cube with all coordinate intervals [R/2-w,R/2];
- a diagonal interior cube with each coordinate interval [R/4-w/2,R/4+w/2].

All are positive L1 sources with finite density. Their posterior probabilities are computed by exact piecewise-affine one-dimensional integration and tensor multiplication. Repeated coordinates are compressed by multiplicity, not sampled. The diagonal box has the same mean absolute coordinate R/4 as the uniform posterior, hence exactly the same leakage despite very different density.

Three stages use n16/64, n256, n1024/4096, with L=b,sqrt(n)b,nb. All dimensions are squares, so every parameter is rational. Two fresh independent Python processes passed **889 exact checks**: 44 basic checks plus stage counts 338/169/338. Decimal displays are ordinary floating-point conversions, excluded from the exact-check count; a displayed 1 may be rounded and need not be exact 1. Large rational values are stored by a deterministic integer-byte digest and recomputed by the script.

## Results that change the decision

For R=b:

| n | uniform posterior, L=sqrt(n)b | uniform posterior, L=nb | whole-cube crossing, L=nb |
|---:|---:|---:|---:|
|16|0.643925870|0.222734829|0.643925870|
|64|0.868915968|0.221580391|0.635013476|
|256|0.982253720|0.221294342|0.632840245|
|1024|0.999674912|0.221222988|0.632300261|
|4096|0.999999891|0.221205159|0.632165471|

At L=b, uniform leakage is already 0.989977404 at n16 and rounds to 1 at larger tested dimensions. At L=nb, posterior leakage is about 35% of whole-cube crossing; the constant improvement is real. At L=sqrt(n)b, uniform leakage approaches 1 over the tested dimensions rather than remaining a small error.

Source geometry can change this substantially. At n4096,R=b,L=sqrt(n)b, the center, face, and corner positive-volume boxes have leakage approximately

`0.0000390617`, `0.00785123`, and `0.999999999999989`.

The corner has many displaced coordinates, while the face has only one. Posterior weighting can therefore be valuable with a genuine concentration or coordinate-displacement receipt. Without such an additional receipt, even a uniform source already forces linear-in-n padding for a fixed small leakage allowance. This experiment does not determine whether traffic weighting or the original high-past gates provide that additional geometry.

## Reproduction

Only `r341_numeric.py`, `r341_numeric_result.json`, and this note are needed. The script uses Python's standard library and writes JSON beside itself:

```sh
/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 /path/to/r341_numeric.py
```

No historical /tmp code/data or external source is imported. The first implementation exposed a float overflow when displaying R^4096; the final script retains the exact integer digest and marks that mass outside float range. This affects no probability or rational comparison.
