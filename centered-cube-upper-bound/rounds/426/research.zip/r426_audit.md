# R426 independent final audit

FINAL PASS — limited to the original-kernel normalization/restoration identities and weighted forcing bound, the native two-terminal-exclusion parent-tail lemma, and its correctly qualified original-terminal upper bound. NO new original-fee payment, absorption, named remainder or general root budget is certified. R425 and its complete account remain unchanged. Independent screening preceded author reading; this final record supersedes PRE for the delivered claims. Only this reviewer audit file was edited.

## 1. Original kernel, stage measure and sharp forcing bound

Read the frozen main, aux, geometry and README in full. M_i is the ORIGINAL symmetric decreasing mixture ∫σs_iπ_A², with source marginal fD_i. It is not recomputed after R423–425 filters. The actual stage source projection satisfies Ξ_i^{yz}≤τ^(-1)b_iM_i, so the stated RN mark κ_i∈[0,1] exists without assuming independence or product AC for a full history record. The discrete stage i is retained in the measure. κ may be asymmetric and stage-dependent.

Set c_i=max(D_i,s), A=∫fD_0/c_0, L=∫f log(c_0/s). Independently derived the same-measure Cauchy–Schwarz estimate. The new-source side integrates its M_i marginal and uses D_i/c_i≤D_0/c_0 and SAME-z Σb_i≤1, hence F_z≤A. For the old row K_i(y,dz),
K_{i+1}/c_{i+1}−K_i/c_i=−(K_i−K_{i+1})/c_i+K_{i+1}(1/c_{i+1}−1/c_i).
Its total positive restoration is at most log(c_0/s), since each jump contributes D_{i+1}(1/c_{i+1}−1/c_i)≤1−c_{i+1}/c_i≤log(c_i/c_{i+1}). This includes jumps crossing s, entire atoms and zero rows. Future sums of the original marks are bounded by 1 at the SAME (y,z). Thus F_y≤A+L and
Σ_i∫κ_i b_i dM_i/√(c_i(y)c_i(z))≤√[A(A+L)].
Finite truncation and nonnegative limits cover countably many stages; no terminal is silently assumed zero. A=0 or W=0 is zero flow. Main's sharper D_0≤SA_n is valid directly from q_A/m_A=R_A^(-n), s_0≤S and the real-center volume integral ≤A_n. Aux's optional SλA_n/q_- is a weaker valid bound. Consequently the displayed W√[1+log_+(SA_n/s)] bound is correct, and the actual weighted Ξ bound has the single τ^(-1) factor.

For N_i=M_i/√c_ic_i, the exact difference is L_i−H_i with BOTH positive loss and restoration measures. The cumulative-mark formula forcing=terminal−initial+weighted-loss−weighted-restoration is correct. Positive-variation estimates, clipped logarithmic potential and finite nonzero terminal terms agree. No varying-threshold switch is canceled by this identity. Original source low-D, clipping and earlier square credits are not recreated.

This is a source-priced WEIGHTED quantity. Recovering |Π425| retains √(c_i(y)c_i(z)); on its actual support both D_i>s. Neither symmetry nor the new K² mass gate bounds that factor by s. The theorem does not pay the unweighted remainder and is not relabeled as such in main.

## 2. Native excluded-center parent tail

Independently checked the new lemma before author reading. On H<m_A≤r, q_-≤q_A≤λ implies
R_A≤(r/q_-)^(1/n), R_A>(H/λ)^(1/n).
Capturing y,z puts the parent center in the two upper cubes' intersection. Centers w,t outside Q_A exclude the union of the two fixed lower cubes centered at w,t. Hence positive layercake gives exactly
T_H^{w,t}(y,z)≤2λ∫_H^∞r^(-3)|Q_(r/q_-)^(1/n)(y)∩Q_(r/q_-)^(1/n)(z) \ [Q_(H/λ)^(1/n)(w)∪Q_(H/λ)^(1/n)(t)]|dr.
The coefficient is 2λ, with no second endpoint-union factor. Strict mass atoms, positive q, chosen side-length measurability and cube-boundary conventions are handled by the set inclusion/positive integral. The two exclusion cubes' mutual intersection is retained by inclusion–exclusion. This compares CENTER-VOLUME ENVELOPES, not f-masses or actual paid source terms. The geometric decrease relative to the unexcluded envelope has not been priced against the source/terminal integral.

## 3. Terminal pushforward and exact remaining limitation

The original fixed-source path has finite depth. From an active start, terminal law is ≤1_{Z≤h}ρ_x/h, including an encountered terminal once. The proof uses the original own-low initial segment of ρ mass at least h and is safe for whole mass atoms. The essential INITIAL OWN-HIGH restriction is retained before averaging the exclusive initial law; otherwise an inactive start would contribute an uncontrolled Dirac term. No normalization by the probability of this active event is performed.

The two generated paths are independent before future filtering, conditional on the original base sources/parent. Upper bounds delete other future positive restrictions before using the product terminal domination. The final restricted law is not asserted independent or Markov with the unrestricted kernel. Terminal own-low, two terminal centers outside the original parent, and m_A>K²max(m_w,m_t) are retained as output restrictions. Original stage sum gives S/h² once. The displayed whole-source upper integral retains f(y)f(z), μ(dw)μ(dt), c_w(y)c_t(z) and the father's q_A/m_A² simultaneously. No π posterior or initial-witness column is transplanted to a terminal.

Thus the geometry (10) and main (7) are valid sufficient upper bounds; their larger integral is not an equality with the original fee, a necessary target, or an already paid quantity. The full matching sublevel H<m_A≤r may contain information lost in its volume envelope. Connecting this coupled terminal integral, or a smaller actual marked version, to tX_q+C_t sW is still unproved. Terminal own-low does not confer original deletion/clock/opposite-source-exclusive/history eligibility.

## 4. Main account and scope corrections

The complete G0/BH/entrance account is precisely R425's, with unchanged R425, C425=C423+Δ_B, V425=V413+Ω_A and Fhat. The 16/32/64 factors, external source/entrance terms and original atom/low-dimensional/full-scale qualifications are retained; no new charge or refund is entered. Aux's residual phrase “geometric payment” was corrected before freezing to “geometric upper bound and inherited account,” consistent with this no-payment scope. README is accurate. No further mathematical revision is required for the bounded deliverable.

## 5. Actual independent replay and evidence boundary

Read both complete scripts and ran isolated temporary copies. Both stdout matched the supplied final .result.txt bytes exactly. The regenerated aux JSON was byte-identical. Aux: 31 finite common-posterior stage models (3/16/12), all positive restoration, 16 nonzero terminal Q_N, 15 zero terminal and 31 marked/unmarked Cauchy–Schwarz checks. Rational roots make the normalized weights exact; a finite positive atanh lower bound already dominates the tested sums, legitimately certifying comparison with the true logarithm. These are finite source/stage models, not actual-center/octave/history realizations.

Geometry: 24 uniform and 12 nonuniform full-f ONE-DIMENSIONAL actual-center configurations; 18+8 actual kernels positive, all 36 refined envelopes strictly smaller than their unexcluded counterpart. Nonuniform mass and q are retained as R+packet_mass and q/m²=1/[R(R+packet_mass)] on the contributing parent domain. Piecewise-affine excluded lengths are integrated exactly by rational primitives. These tests verify the native lemma at n=1, not the n≥9 complete terminal/historical flow. Neither evidence category proves W payment. Temporary PRE arithmetic is not added to these author/parent counts.

No final ZIP extraction, PDF compilation, Git operation or extra experiment was performed by this auditor. The open unweighted bridge and all inherited gaps remain explicit.

## 6. Final byte bindings (SHA-256)

- `r426_main.md`: `1ce69d7fa90f338c81db25e910a1a0311d62114f570cd224c70c08eebe67ff03`
- `r426_readme.md`: `1a9cb027cb2745efab3594a9cc3ae9b209fc5ec68bad1122cae805f673577132`
- `r426_aux.md`: `00c6429a0e309ec5fe4022b7eb95071719833e574a3a55f0c72eb6f5925338a5`
- `r426_geometry.md`: `094b4ad5f9fc00e91f33715110745820cc0e895577912f109af2cf84058d3f02`
- `r426_aux_check.py`: `118de7969ad35f4b243f08445d5042b5daac7cafd30fa66519228f6700f03def`
- `r426_geometry_check.py`: `2c28594ce3913da4eafe8203f4eddb37ffbbaac963ddb7f49ac0b2ffb1c4472c`
- `r426_aux.result.txt`: `ac61bd7950ac9a1ba49468b48aac349900e7fdaff174cbae74f2c2562649a556`
- `r426_geometry.result.txt`: `a4a5793175342192adfced38448eab276c66ebbfa1cf92faca5b26717c75a546`
- `r426_aux_result.json`: `530007c77388e5badf214f95f11b206a64e3cd850c67b045294c5d5a6c9aa411`
- `r425_main.md`: `c0c06b0ddb758275c90e0cd4a3202d35d8ff287d8a89596adc2683c01f76b564`
- `r413_main.md`: `ed03c99fbea15e831c6250832a9fc1f48f04d92cba3475fa60266542badf593f`
- `r423_aux.md`: `0a9953e757529273b8a29075257c5878283566e08bb2848eb13019595d00a0e8`
