from fractions import Fraction as F
from itertools import product
from pathlib import Path
import json

def total(A):return sum(map(sum,A))
def mmadd(A,B):return [[x+y for x,y in zip(a,b)] for a,b in zip(A,B)]
def inner(A,B):return sum(A[i][j]*B[i][j] for i in range(4) for j in range(4))
def log_lower(x,terms=300):
    assert x>=1
    a=(x-1)/(x+1);v=a;s=F(0)
    for j in range(terms):s+=v/F(2*j+1);v*=a*a
    return 2*s

def model(scale,sroot,mode,stop):
    # Four source cells of f-mass 1. Parents: four single cells + one whole union.
    # Genuine common-posterior representation, not an octave/native/history realization.
    roots0=[[8,7,6,5],[6,6,5,4],[4,4,3,3],[2,3,2,2],[0,1,0,1],[0,0,0,0]]
    u0=[F(2),F(3,2),F(1),F(1,2),F(0),F(0)]
    if mode=='proportional':roots0=[[v*t for v in [4,5,6,7]] for t in [4,3,2,1,0,0]];u0=list(map(F,[2,1,1,0,0,0]))
    roots=[[F(scale)*v for v in row] for row in roots0]
    u=[F(scale)*v for v in u0]
    M=[];sparents=[];D=[]
    for row,b in zip(roots,u):
        g=4*b*b;diag=[v*v-b*b for v in row]
        assert min(diag)>=0
        sp=diag+[g];sparents.append(sp)
        mat=[[g/F(16)+(diag[i] if i==j else 0) for j in range(4)] for i in range(4)]
        M.append(mat);D.append([v*v for v in row])
        assert [sum(r) for r in mat]==D[-1]
    for i in range(5):assert all(a>=b for a,b in zip(sparents[i],sparents[i+1]))
    s=F(sroot*sroot);clip=[[max(F(sroot),v) for v in row] for row in roots]
    N=[[[M[i][y][z]/(clip[i][y]*clip[i][z]) for z in range(4)] for y in range(4)] for i in range(6)]
    assert all(total(mat)<=4 for mat in N)
    # Actual scalar-density schedule form b_i=Delta min(f,T)*(1-s/D_i)+ with f=1.
    thresholds=list(map(F,[0]))+[F(1,10),F(1,5),F(2,5),F(4,5),F(1)]
    bs=[[ (thresholds[i+1]-thresholds[i])*max(F(0),1-s/D[i][z]) if D[i][z] else F(0) for z in range(4)] for i in range(5)]
    assert all(sum(bs[i][z] for i in range(5))<=1 for z in range(4))
    pref=[[F(0)]*4 for _ in range(4)];forcing=loss=restore=F(0);Q0=F(0)
    total_loss=total_restore=F(0);raw=F(0);marked_y=marked_z=F(0)
    for i in range(stop):
        kappa=[[F((i+2*y+z)%3,2) for z in range(4)] for y in range(4)]
        charge=[[kappa[y][z]*bs[i][z] for z in range(4)] for y in range(4)]
        forcing+=inner(charge,N[i]);raw+=inner(charge,M[i]);pref=mmadd(pref,charge)
        marked_y+=sum(charge[y][z]*M[i][y][z]/max(s,D[i][y]) for y in range(4) for z in range(4))
        marked_z+=sum(charge[y][z]*M[i][y][z]/max(s,D[i][z]) for y in range(4) for z in range(4))
        assert max(map(max,pref))<=1
        L=[[(M[i][y][z]-M[i+1][y][z])/(clip[i][y]*clip[i][z]) for z in range(4)] for y in range(4)]
        R=[[M[i+1][y][z]*(1/(clip[i+1][y]*clip[i+1][z])-1/(clip[i][y]*clip[i][z])) for z in range(4)] for y in range(4)]
        assert min(map(min,L))>=0 and min(map(min,R))>=0
        assert all(N[i][y][z]-N[i+1][y][z]==L[y][z]-R[y][z] for y in range(4) for z in range(4))
        loss+=inner(pref,L);restore+=inner(pref,R)
        total_loss+=total(L);total_restore+=total(R)
        assert total(L)<=sum((D[i][z]-D[i+1][z])/max(s,D[i][z]) for z in range(4))
    Q=inner(pref,N[stop]);assert forcing==Q-Q0+loss-restore
    unmarked=sum(sum(bs[i][z]*N[i][y][z] for y in range(4) for z in range(4)) for i in range(stop))
    oldrow=sum(sum(bs[i][z]*M[i][y][z]/max(s,D[i][y]) for y in range(4) for z in range(4)) for i in range(stop))
    newcol=sum(sum(bs[i][z]*D[i][z]/max(s,D[i][z]) for z in range(4)) for i in range(stop))
    old_recovery=sum(D[0][y]/max(s,D[0][y])+sum(D[i+1][y]*(1/max(s,D[i+1][y])-1/max(s,D[i][y])) for i in range(stop-1)) for y in range(4))
    assert forcing<=unmarked<=(oldrow+newcol)/2
    assert oldrow<=old_recovery and newcol<=4
    sharp_lower=4+sum(log_lower(max(F(1),v/s)) for v in D[0])/2
    assert unmarked<=sharp_lower
    A=sum(v/max(s,v) for v in D[0])
    log_cert=sum(log_lower(max(F(1),v/s)) for v in D[0])
    assert marked_y<=oldrow<=A+log_cert and marked_z<=newcol<=A
    assert forcing*forcing<=marked_y*marked_z<=A*(A+log_cert)
    assert unmarked*unmarked<=oldrow*newcol<=A*(A+log_cert)
    assert total_restore==total_loss+total(N[stop])-total(N[0])
    discrete_budget=sum((D[i][z]-D[i+1][z])/max(s,D[i][z]) for i in range(stop) for z in range(4))
    assert total_loss<=discrete_budget and forcing<=Q+discrete_budget
    # Certified upper by Phi(D0): log LOWER truncation suffices if it already dominates.
    phi_lower=sum((v/s if v<=s else 1+log_lower(v/s)) for v in D[0])
    assert discrete_budget<=phi_lower
    return {'scale':scale,'sroot':sroot,'mode':mode,'stop':stop,'weighted_forcing':str(forcing),'raw_forcing':str(raw),'loss_credit':str(loss),'restoration':str(restore),'terminal_Q':str(Q),'positive_loss_total':str(total_loss),'positive_restore_total':str(total_restore),'restoration_positive':restore>0,'cs_marked_y':str(marked_y),'cs_marked_z':str(marked_z),'initial_A':str(A),'cs_verified':True}

stages={'initial':[(1,s,'mixed',5) for s in [1,2,3]],
'jump_zero':[(a,s,m,t) for a,s,m,t in product([1,2],[1,2],['mixed','proportional'],[2,5])],
'expanded':[(a,s,'mixed',t) for a,s,t in product([3,5],[1,3],[1,3,5])]}
results={name:[model(*args) for args in rows] for name,rows in stages.items()}
flat=[x for rows in results.values() for x in rows]
summary={'counts':{k:len(v) for k,v in results.items()},'total':len(flat),'positive_restoration':sum(x['restoration_positive'] for x in flat),'nonzero_terminal':sum(F(x['terminal_Q'])>0 for x in flat),'zero_terminal':sum(F(x['terminal_Q'])==0 for x in flat),'cs_verified':sum(x['cs_verified'] for x in flat)}
Path(__file__).with_name('r426_aux_result.json').write_text(json.dumps({'summary':summary,'results':results},indent=2)+'\n')
print('PASS',summary)
print('Exact common-posterior finite stage kernels with density-threshold b_i and asymmetric retained marks. Not native center/octave/full-history fixtures.')
print('r426_aux_result.json')
