"""Exact one-dimensional native check of the R426 terminal-exclusion tail.
Uniform full source and real interval centers; not a full original-history model.
"""
from fractions import Fraction as F


def intersect(*intervals):
    lo = max(x[0] for x in intervals)
    hi = min(x[1] for x in intervals)
    return max(F(0), hi - lo)


def capture(y, z, r):
    return max(y, z) - r / 2, min(y, z) + r / 2


def box(x, r):
    return x - r / 2, x + r / 2


def available(y, z, r, w, t, exclusion_size, block=None):
    I = capture(y, z, r)
    W, T = box(w, exclusion_size), box(t, exclusion_size)
    base = [I] if block is None else [I, block]
    return (intersect(*base) - intersect(*base, W) -
            intersect(*base, T) + intersect(*base, W, T))


def exact_tail(y, z, w, t, H, lam=F(1)):
    # q=1,n=1. V(r) has affine pieces; integrate 2 lambda V(r)/r^3.
    exclusion_size = H / lam
    endpoints = list(box(w, exclusion_size)) + list(box(t, exclusion_size))
    cuts = {H}
    candidates = [abs(y-z)]
    for x in endpoints:
        candidates += [2 * (max(y, z)-x), 2 * (x-min(y, z))]
    cuts.update(r for r in candidates if r > H)
    cuts = sorted(cuts)
    total = F(0)
    for k, a in enumerate(cuts):
        b = cuts[k+1] if k+1 < len(cuts) else None
        p, q = ((2*a+b)/3, (a+2*b)/3) if b else (a+1, a+2)
        vp = available(y, z, p, w, t, exclusion_size)
        vq = available(y, z, q, w, t, exclusion_size)
        slope = (vq-vp)/(q-p)
        constant = vp-slope*p
        if b:
            total += 2*slope*(1/a-1/b)+constant*(1/a**2-1/b**2)
        else:
            total += 2*slope/a+constant/a**2
    return lam * total


count = positive = strict_saving = 0
for y, z in [(F(-1,10),F(1,10)), (F(0),F(1,4)), (F(-1,5),F(1,3))]:
    for w, t in [(F(3,5),F(-13,20)), (F(3,4),F(-3,4)),
                 (F(1,2),F(-1,2)), (F(2),F(-2))]:
        for H in [F(1,2),F(3,4)]:
            # E=[-2,0] union [0,2], side length 1 on the left, 2 on the right.
            # f=1 on [-3,3]; hence true m_A=R_A, q_A=1 throughout E.
            actual = sum(available(y,z,R,w,t,R,block)/R**2
                         for R,block in [(F(1),(F(-2),F(0))),
                                         (F(2),(F(0),F(2)))])
            refined = exact_tail(y,z,w,t,H)
            d = abs(y-z)
            # Unexcluded parent tail 2 int_H^infty (r-d)_+ / r^3 dr.
            lower = max(H,d)
            original = 2/lower-d/lower**2
            assert 0 <= actual <= refined <= original
            positive += int(actual > 0)
            strict_saving += int(refined < original)
            count += 1
print("PASS native terminal-exclusion parent-tail cases:", count)
print("positive actual kernels:", positive)
print("strict pointwise envelope improvements:", strict_saving)
nonuniform = nonuniform_positive = 0
for y,z in [(F(-1,10),F(1,10)), (F(-1,5),F(1,3))]:
    for w,t in [(F(3,5),F(-13,20)), (F(3,4),F(-3,4)),
                (F(1,2),F(-1,2))]:
        for amplitude in [F(1,2),F(1)]:
            # Complete nonuniform f = 1_[-3,3] + amplitude*1_packet.
            # packet is the middle third of [y,z]. All parent cubes capturing
            # both y,z contain it, so their actual mass is R+packet_mass.
            packet_mass = amplitude * (z-y) / 3
            lam = 1 + packet_mass
            assert 1 <= lam <= F(4,3)
            H = F(3,4)
            actual = sum(available(y,z,R,w,t,R,block)/(R*(R+packet_mass))
                         for R,block in [(F(1),(F(-2),F(0))),
                                         (F(2),(F(0),F(2)))])
            refined = exact_tail(y,z,w,t,H,lam)
            d = z-y
            original = lam * (2/H-d/H**2)
            assert 0 <= actual <= refined < original
            nonuniform_positive += int(actual > 0)
            nonuniform += 1
print("PASS nonuniform full-f native matching cases:", nonuniform)
print("positive nonuniform actual kernels:", nonuniform_positive)
print("All integrals are rational exact; n=1 native lemma checks only.")
print("No original high-dimensional terminal paths/history or W budget certified.")
