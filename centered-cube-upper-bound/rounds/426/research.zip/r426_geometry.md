# R426：两个真实终端中心的排除体积与父质量尾

2026-10-20。有界尝试结果：证明了保留两个终端中心位置的原生父核上界，并给出其对原 \(\Pi425\) 的合法作用范围；**没有取得新的 \(tX_q+C_t sW\) 付款**。以下不改变 R425 总账、不新增密度门，也不继续调整 R425 的节点质量权。

## 1. 当前对象与筛查命题

采用 `/tmp/r425_main.md` 的完整 \(f\)、真实 Lebesgue 中心及同一选择器：
\[
 m_A=f(Q_A)=q_AR_A^n,\quad q_-\le q_A\le\lambda,\quad
 a\le R_A\le b\le2a,\quad
 \mu(dA)=dA/m_A,\quad\sigma(dA)=q_A\,dA.
\]
所有 \(R\) 均为立方体**边长**。\(\Pi425\) 保留 R425 的两次实际软权、全部阶段和旧新来源标记、原时钟与历史，以及原双保源路径；总量为 \(R425\)。其正支上，两链每个节点满足
\[
 m_v<m_A/K^2,\qquad K=e^{\sqrt n}.
 \tag{1}
\]
终端记 \(w,t\)，分别保留来源 \(y,z\)。原路径停止规则和已付分支给
\[
 y\in Q_w,\quad z\in Q_t,\quad
 Z_w(y)\le h,\quad Z_t(z)\le h,\quad w,t\notin Q_A .
 \tag{2}
\]
这里 \(w,t\notin Q_A\) 指**中心**不在父立方体；没有断言终端 cube 不与父 cube 相交。初始 exclusive 条件也不能自动传到终端。

本轮筛查的具体候选是：在父中心平方尾中同时保留 (2) 的两个中心排除条件，而不是只留父对 \(y,z\) 的共同捕获。固定 \(y,z,w,t\) 与 \(H>0\)，定义实际父核
\[
 \mathcal T_H^{w,t}(y,z)=
 \int_{\{m_A>H\}}
 \frac{q_Ac_A(y)c_A(z)}{m_A^2}
 1_{\{w,t\notin Q_A\}}\,dA .
 \tag{3}
\]
在当前应用可取
\[
 H=K^2\max(m_w,m_t).
 \tag{4}
\]
这使用原父对两终端的共同质量门，不改变每一步仍为 \(K\) 的生成核。

## 2. 双排除父尾：一般原生命题

设 \(Q_R(x)\) 表示以 \(x\) 为中心、边长 \(R\) 的立方体。令
\[
 R_r=(r/q_-)^{1/n},\qquad r_H=(H/\lambda)^{1/n},
\]
\[
 I_r(y,z)=Q_{R_r}(y)\cap Q_{R_r}(z),\qquad
 B_H(w,t)=Q_{r_H}(w)\cup Q_{r_H}(t).
\]
则
\[
 \boxed{\displaystyle
 \mathcal T_H^{w,t}(y,z)
 \le 2\lambda\int_H^\infty
       r^{-3}\,|I_r(y,z)\setminus B_H(w,t)|\,dr .}
 \tag{5}
\]
对同一固定 \(y,z,w,t\)，右侧等于普通双来源父尾包络减去明确非负量
\[
 \mathcal D_H^{w,t}(y,z)=
 2\lambda\int_H^\infty r^{-3}
       |I_r(y,z)\cap B_H(w,t)|\,dr .
 \tag{6}
\]
这是父中心的几何减项，**不是**已付的来源质量信用。

**证明。**由正层饼，实际核精确等于
\[
 2\int_H^\infty r^{-3}
 \int_{\{H<m_A\le r\}}
 q_Ac_A(y)c_A(z)1_{\{w,t\notin Q_A\}}\,dA\,dr .
 \tag{7}
\]
若 \(m_A\le r\)，则 \(R_A\le R_r\)，所以捕获两个来源的父中心必须落在 \(I_r(y,z)\)。若同时 \(m_A>H\)，则
\[
 R_A=(m_A/q_A)^{1/n}>r_H.
 \]
由 \(w\notin Q_A\) 得 \(\|A-w\|_\infty>R_A/2>r_H/2\)，因此父中心不在 \(Q_{r_H}(w)\)；对 \(t\) 同理。原实际中心集合遂包含于 \(I_r\setminus B_H\)。再以 \(q_A\le\lambda\) 支配内积分，即得 (5)。

该证明保留实际选择器，未将 \(R_A\) 当独立积分变量。质量原子和严格 \(m_A>H\) 已在 (7) 处理；将上端改成 \(m_A\le r\) 与单点 \(r=m_A\) 无积分差异。立方体边界的取法不改变右侧 Lebesgue 体积。

体积可完全显式计算。对任意有限组轴平行盒 \(Q_{s_\nu}(x_\nu)\)，
\[
 \left|\bigcap_\nu Q_{s_\nu}(x_\nu)\right|
 =\prod_{j=1}^n
 \left[\min_\nu(x_{\nu,j}+s_\nu/2)
       -\max_\nu(x_{\nu,j}-s_\nu/2)\right]_+.
 \tag{8}
\]
将 (8) 用于 \(I_r\)、\(I_r\cap Q_{r_H}(w)\)、\(I_r\cap Q_{r_H}(t)\)、以及四盒交集，再作一次并集容斥，就得到 (5) 的全部 integrand。两排除盒可重叠，其交集项不能遗漏。

## 3. 对原终端联合费用的合法回代范围

这里区分**原条件路径生成核**与**受全部未来门限制后的实际联合测度**。后者一般不独立，不能把两个终端当成重新独立抽样的概率。

固定来源 \(x\)，记 \(\rho_x(dv)=c_v(x)\mu(dv)\)，
\(B_x=\{v:Z_v(x)\le h\}\)。由原质量 CDF 首入证明，只要有 active 起点，\(\rho_x(B_x)\ge h\)；若达到秩 \(h\) 的位置为质量原子，该原子仍有严格 far 过去不超过 \(h\)，所以亦被包括。对一个 active 起点，首次进入 \(B_x\) 的终端子核满足
\[
 \mathsf Q_{\rm term}^x(v,dw)
 \le 1_{B_x}(w)\rho_x(dw)/h.
 \tag{9}
\]
可直接按最大剩余步数归纳：下一步可达质量初段为 \(D_v\)，总量为 \(Z_v>h\)。若 \(D_v\subset B_x\)，直接转移密度不超过 \(1/h\)；否则 \(B_x\subset D_v\)，直接项与继续项之和至多
\[
 \frac1{Z_v}+
 \frac{Z_v-\rho_x(B_x)}{Z_vh}\le\frac1h .
 \]
这与 R422 首入带证明是同一真实源秩事实，不是新的付款。原 R411 已移除了初始 own-low 分支，所以对实际余项先保留“初始 active”的正限制，再平均原 exclusive 初始核；该初始子概率总量不超过一，故 (9) 保持。不对初始 active 事件重新归一。

给定原父和 \(y,z\)，原两条完整路径在生成时独立；只有在**上界中删除未来正限制**后，才可用 (9) 的乘积支配。保留 \(w,t\notin Q_A\) 与 (4) 为正限制，用原阶段一次求和和两端逐来源容量 \(S=\beta+C_{\rm col}\)，得到一个合法的、但可能较松的全来源上界：
\[
 \begin{aligned}
 R425\le\frac S{h^2}\int f(y)f(z)\,dy\,dz
 \int&\mu(dw)\mu(dt)\,c_w(y)c_t(z)\\
 &{}\times1_{\{Z_w(y)\le h,\ Z_t(z)\le h\}}\,
 \mathcal T_{K^2\max(m_w,m_t)}^{w,t}(y,z).
 \end{aligned}
 \tag{10}
\]
没有给后继新的原历史资格，没有源刷新，没有路径长度因子，也未把受限制的终端 law 当概率再相乘。原实际 \(\Pi425\) 始终在左侧；右侧确实删除了部分原门。因此 (10) 只是可用上界，**支付右侧并非支付原问题的必要条件**，更不能把它反过来当原费用的等式。

将 (5) 代入 (10)，可以看到两个终端的联合父中心排除真正进入了同一个四变量积分，而不是分别估两次后丢弃交集。但目前仍没有将该积分估成 \(tX_q+C_t sW\)。在从 (7) 到 (5) 时，真实父的额外上界约束 \(f(Q_A)\le r\) 仅通过 \(R_A\le R_r\) 使用；保留这一实际匹配子水平集可能比体积包络更有效，不能宣称几何包络已捕获全部匹配收益。

## 4. 唯一尚缺的结算步骤

精确未消项不是“还缺一条终端概率归一化”，因为 (9) 已给合法归一支配。缺的是下述带权输运结算：对原 stage/双来源/完整路径条件下的终端联合子分布，父同时捕获 \(y,z\) 而排除 \(w,t\) 的真实中心量，必须与两个 terminal cube 的完整来源质量一起积分，得到一次 \(W\) 价，而不能把它们拆成两个任意来源积分。

在可检验的 (10)–(7) 版本，这要求估计
\[
 \begin{aligned}
 \frac2{h^2}\int f(y)f(z)\,dy\,dz\int\mu(dw)\mu(dt)\,
 c_w(y)c_t(z)1_{\{Z_w(y),Z_t(z)\le h\}}\\
 {}\times\int_{K^2\max(m_w,m_t)}^\infty r^{-3}
 \int_{\{K^2\max(m_w,m_t)<m_A\le r\}}
 q_Ac_A(y)c_A(z)1_{\{w,t\notin Q_A\}}\,dA\,dr ,
 \end{aligned}
 \tag{11}
\]
或其保留实际全部条件权的较小版本。式 (11) 前乘 \(S\) 才是 (10) 的右侧。当前尚无
\(S(11)\le tX_q+C_t sW\) 的证明。这里的真实父质量子水平、两个终端中心排除、以及 \(c_w(y)c_t(z)\) 的全来源耦合是同一项，不能分别当已付信用。

由 (5) 得到的显式体积差对固定标签严格改善父核；但未证明其被全来源与终端列权平均后节省固定比例，也未证明其负项自身可以抵消旧已付量。仅将 (11) 的 \(f(y)f(z)\) 外放为 \(W^2\)、或把排除盒的体积当作 \(f\)-质量，均不能完成这一结算。本文不把 (11) 的定义称作新理论成果；本轮可独立使用的新增几何内容仅为 (5) 的双排除包络，未形成新的原费用付款。

## 5. 本机精确检查与停止范围

实际运行 `/tmp/r426_geometry_check.py`，使用标准库 Fraction。首先检查 24 个一维原生 Lebesgue 中心模型：
接收中心 \(E=[-2,0]\cup[0,2]\)，左侧选择边长 1、右侧选择边长 2，完整 \(f=1_{[-3,3]}\)。所有实际父 cube 均匹配 \(m_A=R_A,q_A=1\)。通过真实中心区间的容斥精确计算 (3)，将 (5) 的分段仿射体积精确积分为有理数。18 个配置的实际核为正，24 个配置相对不排除终端中心的父尾包络均有严格改进。

另检查 12 个非均匀完整来源模型：
\[
 f=1_{[-3,3]}+\eta\,1_P,\qquad
 P=\text{来源区间 }[y,z]\text{ 的中间三分之一},\quad
 \eta\in\{1/2,1\}.
 \]
每个同时捕获 \(y,z\) 的实际父 cube 都捕获 \(P\)，故其真实质量为
\(m_A=R_A+\eta|P|\)，父 integrand 为
\(q_A/m_A^2=1/[R_A(R_A+\eta|P|)]\)。全场 \(1\le q_A\le1+\eta|P|\le4/3\)，没有将 \(q_A\) 偷换成常数。12 个配置均通过，其中 8 个实际核为正；双排除包络也全部严格改善。

实际输出：

```text
PASS native terminal-exclusion parent-tail cases: 24
positive actual kernels: 18
strict pointwise envelope improvements: 24
PASS nonuniform full-f native matching cases: 12
positive nonuniform actual kernels: 8
All integrals are rational exact; n=1 native lemma checks only.
No original high-dimensional terminal paths/history or W budget certified.
```

这些是一般维数引理的一维精确原生检查，**不是** \(n\ge9\)、原 \(K=e^{\sqrt n}\)、完整 stage/终端历史余项的实例，更不是全局预算证据。一般 (5) 由 §2 证明。当前没有新付款，R425 的 \(C425,V425,\widehat F\) 与未付 \(\Pi425\) 全部保持；按有界任务停止，不继续扩展新的软门。
