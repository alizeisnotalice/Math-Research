from fractions import Fraction as F
from pathlib import Path
import hashlib,json
rows=[]
menus=[[(F(1),F(1),F(1,2),F(1,2)),(F(1),F(1),F(1,3),F(2,3))],[(F(1),F(65,64),F(1,100),F(9,10)),(F(1),F(1),F(0),F(1))],[(F(1),F(1025,1024),F(1,10**8),F(999,1000)),(F(1),F(1),F(1),F(0))]]
for stage,menu in enumerate(menus,1):
 for l,h,ff,qq in menu:
  for s in [F(0),F(1,100),F(1,10),F(1,2),F(9,10),F(1)]:
   r=1-s;L=l**4;H=h**4;f=ff**2;q=qq**2
   X2=(r/L+s*f)*(r/H+s*q)
   Y=r/(l*l*h*h)+s*ff*qq
   D=r*s*(qq/(l*l)-ff/(h*h))**2
   E=s*F(1,2)*((l/h)*ff-(h/l)*qq)**2
   checks={'identity':X2-Y*Y==D,'nonnegative_remainder':D>=0,'upper_square':(Y+E)**2>=X2,'upper_nonnegative':Y+E>=0}
   assert all(checks.values())
   rows.append({'stage':stage,'L':str(L),'H':str(H),'s':str(s),'f':str(f),'q':str(q),'checks':checks})
result={'scope':'FINITE_EXACT_POINTWISE_ALGEBRA_NOT_KERNEL_REALIZATION_OR_GENERAL_PROOF','arithmetic':'fractions.Fraction','cases':len(rows),'passed':len(rows),'stages':[12,12,12],'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'rows':rows}
p=Path(__file__).with_name('overlap_exact_results.json');p.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'cases':len(rows),'passed':len(rows),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}))
