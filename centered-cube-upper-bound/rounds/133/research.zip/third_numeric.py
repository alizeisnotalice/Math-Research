#!/usr/bin/env python3
"""R133: one frozen run, exact E4 masses vs finite-interval E3 quadrature."""
import datetime
import hashlib
import json
import pathlib
import sys
import time
import traceback

HERE = pathlib.Path(__file__).resolve().parent
VENDOR = pathlib.Path('/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor')
sys.path.insert(0, str(VENDOR))
import mpmath as mp

mp.mp.dps = 80
MENU = [
    (1, '01', '.01', '1', '0'), (1, '02', '.1', '.9', '0'),
    (1, '03', '.5', '.5', '0'), (1, '04', '.9', '1', '.01'),
    (2, '05', '.01', '.5', '.01'), (2, '06', '.1', '.9', '.5'),
    (2, '07', '.5', '1', '.5'), (2, '08', '.9', '.5', '2'),
    (3, '09', '.01', '1', '2'), (3, '10', '.1', '.9', '2'),
    (3, '11', '.5', '.5', '8'), (3, '12', '.9', '1', '8'),
]
OUT = HERE / 'third_numeric.json'
HALF = mp.mpf('0.5')
ORDER_TOL = mp.mpf('1e-70')
QUAD_TOL = mp.mpf('1e-65')

def dec(x):
    return mp.nstr(x, 80)

def E(k, r):
    return mp.mpf(1) / (k - 1) if r == 0 else mp.expint(k, r)

def density(x):
    r = abs(x)
    if r <= HALF:
        return 1 - E(3, HALF - r) - E(3, HALF + r)
    return E(3, r - HALF) - E(3, r + HALF)

def primitive(x):
    if x < 0:
        return -primitive(-x)
    if x <= HALF:
        return x - E(4, HALF - x) + E(4, HALF + x)
    return HALF - E(4, x - HALF) + E(4, x + HALF)

def mass(lo, hi):
    return primitive(hi) - primitive(lo)

def original_C(d):
    lo, hi = -HALF - d, HALF - d
    p, q = max(lo, -HALF), min(hi, HALF)
    correction = q - p - mass(p, q) if p < q else mp.mpf(0)
    return mass(lo, hi) + correction

def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def save(data):
    # Single process only; overwrite its own checkpoint, without auxiliary files.
    OUT.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

def main():
    if OUT.exists():
        raise SystemExit('Refusing a second numerical run: third_numeric.json already exists.')
    data = {
        'status': 'running', 'started_utc': utc(), 'run_count': 1,
        'scope': 'TB RHS and true density masses only; no affinity A, E_M, or FULL certification',
        'precision_dps': mp.mp.dps, 'quad_method': 'tanh-sinh', 'quad_maxdegree': 9,
        'quad_abs_tolerance': dec(QUAD_TOL), 'order_rounding_tolerance': dec(ORDER_TOL),
        'python': sys.version, 'mpmath_version': mp.__version__, 'mpmath_path': mp.__file__,
        'sha256': {name: sha(HERE / name) for name in (
            'third_numeric_protocol.md', 'third_numeric.py', 'third_test_binary.md')},
        'menu': [{'stage': z[0], 'id': z[1], 's': z[2], 'L_over_b': z[3], 'd_over_b': z[4]} for z in MENU],
        'formulas': {
            'tau': '2/3 - 2 E4(1)', 'U': '1/3 + 2 E4(1)',
            'V': 'H(L/2-d) - H(-L/2-d)',
            'C': 'mass([-1/2-d,1/2-d]) + hard_overlap_length - phi_mass(hard_overlap)',
            'omega': 'min(1,C/(gamma^(-j)*sqrt(L)))',
            'j': 'floor(log(sqrt(L)/L)/log(gamma))',
        },
        'cases': [], 'exceptions': [],
    }
    save(data)
    start = time.monotonic()
    try:
        assert mp.__version__ == '1.3.0'
        assert pathlib.Path(mp.__file__).is_relative_to(VENDOR)
        n = 6561
        gamma = 1 + mp.mpf(1) / n
        U = mp.mpf(1) / 3 + 2 * E(4, 1)
        tau = mp.mpf(2) / 3 - 2 * E(4, 1)
        tail_lower = 2 * E(3, 1)
        elementary_lower = mp.exp(-2) / 2
        data['constants'] = {
            'n': n, 'gamma': dec(gamma), 'a': '.5', 'b': '1', 'R': '1',
            'U': dec(U), 'tau': dec(tau), 'two_E3_1': dec(tail_lower),
            'half_exp_minus_2': dec(elementary_lower), 'one_over_18': dec(mp.mpf(1)/18),
            'tau_minus_one_over_18': dec(tau - mp.mpf(1)/18),
            'strict_s_threshold': dec(1 - mp.power(2, -mp.mpf(1)/n)),
            'absolute_tau_chain_pass': bool(tau >= tail_lower >= elementary_lower > mp.mpf(1)/18),
        }
        save(data)
        for stage, case_id, s_text, L_text, d_text in MENU:
            case_start = time.monotonic()
            row = {'stage': stage, 'id': case_id, 's': s_text, 'L': L_text, 'd': d_text}
            try:
                s, L, d = map(mp.mpf, (s_text, L_text, d_text))
                g = mp.sqrt(L)
                j = int(mp.floor(mp.log(g/L)/mp.log(gamma)))
                cj = mp.power(gamma, -j)
                cjg = cj*g
                legal = HALF <= L <= 1 and L-ORDER_TOL <= cjg <= gamma*L+ORDER_TOL
                assert legal, 'Original common scale / c_jg gate failed'
                lo, hi = -L/2-d, L/2-d
                points = [lo] + [x for x in (-HALF, HALF) if lo < x < hi] + [hi]
                V = mass(lo, hi)
                V_quad, quad_error = mp.quad(density, points, method='tanh-sinh',
                                            maxdegree=9, error=True)
                C = original_C(d)
                omega = min(mp.mpf(1), C/cjg)
                assert 0 < omega <= 1
                pI = 1-s*tau
                B1 = mp.sqrt(pI*V) + mp.sqrt(s*tau*(1-V))
                B2 = mp.sqrt(1-tau*tau*(1-s)*(1-s))
                norm1, norm2 = B1/mp.sqrt(omega), B2/mp.sqrt(omega)
                diff = abs(V-V_quad)
                checks = {
                    'scale_and_cjg_gate': bool(legal),
                    'V_exact_vs_finite_quad': bool(diff <= QUAD_TOL),
                    'V_probability_range': bool(0 <= V <= 1),
                    'V_le_U': bool(V <= U+ORDER_TOL),
                    'B1_le_B2': bool(B1 <= B2+ORDER_TOL),
                    'B1_le_1': bool(B1 <= 1+ORDER_TOL),
                    'omega_probability_range': bool(0 < omega <= 1),
                }
                row.update({
                    'j': j, 'g': dec(g), 'cj': dec(cj), 'cjg': dec(cjg),
                    'cjg_minus_L': dec(cjg-L), 'gammaL_minus_cjg': dec(gamma*L-cjg),
                    'quad_breakpoints': list(map(dec, points)),
                    'V_E4': dec(V), 'V_finite_quad': dec(V_quad),
                    'V_abs_difference': dec(diff), 'quad_error_estimate': dec(quad_error),
                    'U_minus_V': dec(U-V), 'C_original': dec(C), 'omega': dec(omega),
                    'omega_saturated': bool(omega == 1), 'p_I': dec(pI),
                    'B1_unnormalized': dec(B1), 'B2_unnormalized': dec(B2),
                    'TB1_normalized_RHS': dec(norm1), 'TB2_normalized_RHS': dec(norm2),
                    'TB1_normalized_exceeds_1': bool(norm1 > 1),
                    'TB2_normalized_exceeds_1': bool(norm2 > 1),
                    'strict_s_input_legal': bool(s > 1-mp.power(2, -mp.mpf(1)/n)),
                    'FULL_certified': False, 'checks': checks,
                    'status': 'passed' if all(checks.values()) else 'check_failed',
                })
            except Exception as exc:
                row.update({'status': 'exception', 'exception': repr(exc), 'traceback': traceback.format_exc()})
                data['exceptions'].append({'case_id': case_id, 'exception': repr(exc), 'traceback': row['traceback']})
            row['elapsed_seconds'] = time.monotonic()-case_start
            data['cases'].append(row)
            save(data)
            print(json.dumps({'case': case_id, 'status': row['status'], 'elapsed_seconds': row['elapsed_seconds']}), flush=True)
        all_pass = data['constants']['absolute_tau_chain_pass'] and all(r['status'] == 'passed' for r in data['cases'])
        data['status'] = 'completed_all_checks_passed' if all_pass else 'completed_with_failures'
    except Exception as exc:
        data['status'] = 'fatal_exception'
        data['exceptions'].append({'exception': repr(exc), 'traceback': traceback.format_exc()})
    data['finished_utc'] = utc()
    data['elapsed_seconds'] = time.monotonic()-start
    data['summary'] = {
        'cases_completed': len(data['cases']),
        'cases_passed': sum(r['status']=='passed' for r in data['cases']),
        'exceptions_count': len(data['exceptions']),
        'max_V_abs_difference': max((mp.mpf(r['V_abs_difference']) for r in data['cases'] if 'V_abs_difference' in r), default=None),
    }
    if data['summary']['max_V_abs_difference'] is not None:
        data['summary']['max_V_abs_difference'] = dec(data['summary']['max_V_abs_difference'])
    save(data)
    print(json.dumps({'status': data['status'], 'summary': data['summary']}, ensure_ascii=False), flush=True)

if __name__ == '__main__':
    main()
