# R365 — Shared-radius matching certificate: exact scope and unresolved bill

## Outcome and precise proposed certificate

No new root-order receipt is proved. This bounded investigation keeps the R364 physical-clock expression, focuses on one actual receiver center and its common radius, and records the exact normalization credit that a radius comparison must retain. The resulting integrable dual interface is valid, but the available certificate costs X_q rather than epsilon X_q. The interface and identities below are not counted as progress toward a general budget by themselves.

The contract is exactly R364: fixed full f>=0 in L1, real E, one measurable actual R_u in[a,b], m_u=f(Q_(R_u)(u))=q_uR_u^n, q_-<=q_u<=lambda, original J_r, original Far_r, and ell=b^(-n)delta_b+n r^(-n-1)dr. Define g_r=f1_{J_r>=H}. Both F_far and F_core use these SAME quantities; no receiver is assigned a separate radius for each source pair.

Let T_R h(u)=integral_(Q_u)h and T_R*psi(y)=integral_E psi(u)c_u(y)du. A concrete sufficient source-linear certificate for F_core is a measurable p_core and signed psi such that

    F_core=integral f(y)p_core(y)dy,
    p_core(y)<=C+T_R*psi(y) for f(y)dy-almost every y,
    integral_E |psi(u)|m_u du<infinity,
    integral_E psi(u)m_u du<=epsilon X_q,                 (1)

with C=O_epsilon(sqrt(n)polylog(n)). Then Tonelli for the positive parts and absolute integrability for the signed part give

    F_core<=C W+epsilon X_q.                              (2)

Only the actual selector appears in T_R; this is a sufficient weak certificate, not an asserted continuum strong-duality or existence theorem. The same statement applies to F_far using p_far below. No certificate achieving the requested C and signed bill was constructed.

## 1. Integrate all source pairs BEFORE comparing radii

For a fixed actual field, freeze J_r, g_r and Far_r. At a given center u, define for any candidate t in[a,b] with m_u(t)=f(Q_t(u))>0,

    N_u(t,r)=integral g_r(y)f(z)1_(Q_t(u))(y)1_(Q_t(u))(z)
                              Far_r(y,z)dy dz,
    P_u(t)=1/m_u(t) integral_[t,b] N_u(t,r)ell(dr).         (3)

For the actual t=R_u, integral_E P_u(R_u)du=F_far. A corresponding P_core uses g_r in BOTH source positions and the actual test g_r(Q_t(u))/m_u(t)>3/4 at each r. Its value at R_u is exactly the R364 core. Candidate profiles with frozen J are only outer-comparison objects; they are not new self-consistent fields obtained by changing R and secretly keeping J fixed.

The feasible same-center candidate set is

    S_f(u)={t in[a,b]:q_-<=m_u(t)/t^n<=lambda}.

Every actual R_u belongs to it. If an envelope over candidates is used, it must bound the whole P_u(t) for the SAME t; the source integrals in (3) precede any supremum. It is invalid to exchange this with an integral of pairwise maximizing radii. Measurability or an integrable measurable majorant is needed before integrating a supremum; no such exchange is needed for (1).

The matching bound available for every t is only

    0<=N_u(t,r)<=m_u(t)^2,
    0<=P_core,u(t)<=P_u(t)<=m_u(t)t^(-n)=q_u(t).           (4)

The last identity uses the inclusive physical clock tail, including b. This gives F_core<=F_far<=X_q for the actual selector. It is a finite receiver bill but does not give the requested small receiver coefficient. The q-band constraints alone do not reduce the right side of (4) to epsilon q_u(t).

## 2. What a genuine same-center radius expansion must pay and keep

The numerator N_u(t,r) in (3) is monotone in t for fixed r. This monotonicity is used for F_far, not for the core's discontinuous richness gate. Fix t1<t2, both with positive masses m1,m2. Put d_m=m2-m1>=0. With the frozen original source gates, the exact identity is

    P_u(t2)-P_u(t1)
      = integral_[t2,b] [N_u(t2,r)-N_u(t1,r)]/m2 ell(dr)
        - (d_m/(m1*m2)) integral_[t2,b] N_u(t1,r)ell(dr)
        - integral_[t1,t2) N_u(t1,r)/m1 ell(dr).           (5)

The second term is a genuine nonnegative normalization credit for the SAME old source pairs. The third is the discarded original physical-clock prefix. They cannot be deleted when arguing that a larger radius is advantageous. Formula (5) includes t2=b: the b atom belongs to the first two terms and not to the deleted prefix.

Let Q1=Q_(t1)(u) and S=Q_(t2)(u) minus Q1. The increment of N is exactly the sum over the disjoint source regions

    (S x Q1), (Q1 x S), (S x S),                           (6)

with the unchanged g_r(y)f(z)Far_r(y,z). In particular its coarse bound is

    0<=N_u(t2,r)-N_u(t1,r)<=2m1*d_m+d_m^2.                (7)

This is actual source shell MASS, not shell volume times an assumed bound on f. Under two feasible radii one also has the exact relation

    m2/m1=[q_u(t2)/q_u(t1)](t2/t1)^n.

Thus source growth, normalization and clock loss are coupled at one center. Substituting only (7) into (5), or discarding its credits, has not produced a source-linear global price: shell masses may be reused by many different real centers. In particular, nested shells at one center do not imply disjoint source charges across centers. No free coverage or Carleson property is asserted.

## 3. Actual integrable certificate and its precise inadequate price

An explicit single-source projection of the actual core is

    p_core(y)=integral_E c_u(y)/m_u du
       integral_[R_u,b] ell(dr)1_{J_r(y)>=H}
           1_{g_r(Q_u)>3m_u/4}
           integral_(Q_u)g_r(z)Far_r(y,z)dz.              (8)

Its f integral is F_core. Replacing g_r(z) and the richness test by f(z) and 1 gives p_far; the high gate in y and Far remain. The actual matching identity implies

    0<=p_core<=p_far<=p0,
    p0(y)=integral_E c_u(y)R_u^(-n)du
           =T_R*(R_u^(-n))(y),
    integral f p0=integral_E m_uR_u^(-n)du=X_q.           (9)

Hence psi0(u)=R_u^(-n), C=0 is a genuine measurable, absolutely integrable certificate, but its bill is EXACTLY X_q. No negative bill is concealed in a difference of divergent integrals.

More generally write psi=psi0-h. Then the source-cover condition in (1) is exactly

    T_R*h(y)<=C+[p0(y)-p_core(y)],                         (10)

and its desired receiver bill is

    integral_E h(u)m_u du>=(1-epsilon)X_q,
    integral_E |h(u)|m_u du<infinity.                     (11)

The bracket in (10) is the ACTUAL nonnegative posterior/clock deficiency, not a new negative square credit. The R364 low-J/noncore payment already bounds discarded positive traffic and cannot be spent again as an assumed lower bound for this bracket. No h satisfying (10)-(11) with the required C is provided. These two inequalities specify the missing common-selector cover, but are just a precise certificate target and are not claimed as a new theorem paying the core.

The independent useful constraint retained from the radius calculation is (5): attempts to construct such h by moving selector radii must simultaneously control (6) against its normalization and physical-time credits, under the actual source-mass constraints. A source-linear aggregate estimate for those changes is missing. The original fixed selector and its J are not changed in the proposed weak certificate.

All original high-J thresholds, both-source core qualification, physical-clock atoms, low-J fees and outside factors remain unchanged. No addition to the main budget is authorized by this note. Work stops at this specific failure to construct an inexpensive signed matching certificate.

## 4. Local algebra checks

The following exact calculation verifies the three terms of the common-radius difference with actual inclusive clock tails, positive matching masses in the q-band, and variable old/new source numerator fractions. It checks only the formula interface; the scalar fractions are not claimed to realize the complete high-J/Far cube field.

~~~python
from fractions import Fraction as F
from itertools import product
count=0
for n,q1,q2,a_old,a_new,a_prefix in product(
        range(1,7),[F(3,4),F(1)],[F(3,4),F(1)],
        [F(0),F(1,3),F(1)],[F(0),F(1,2),F(1)],
        [F(0),F(1,2),F(1)]):
    r1=F(1);r2=F(3,2);b=F(2)
    m1=q1*r1**n;m2=q2*r2**n
    assert m2>=m1
    old=m1*m1*a_old
    new=old+(m2*m2-m1*m1)*a_new
    before=m1*m1*a_prefix
    # [r1,r2) continuous prefix; [r2,b] includes the atom at b.
    prefix=r1**(-n)-r2**(-n)
    tail=(r2**(-n)-b**(-n))+b**(-n)
    P1=before*prefix/m1+old*tail/m1
    P2=new*tail/m2
    gain=(new-old)*tail/m2
    normalization=(m2-m1)*old*tail/(m1*m2)
    lost=before*prefix/m1
    assert P2-P1==gain-normalization-lost
    assert gain>=0 and normalization>=0 and lost>=0
    assert P1<=q1 and P2<=q2
    count+=1
print('PASS common-selector clock identities',count)
~~~


Actual local execution of the final embedded script returned:

~~~text
PASS common-selector clock identities 648
~~~

All these calculations use exact Fraction arithmetic. They validate (5), its signs, and the inclusive-clock normalization, not the existence of a certificate satisfying (10)-(11) or the general root-order estimate.
