# R365 — Actual posterior high-J quantiles: exact common-receiver moments and the weight mismatch

**Outcome.** No new general root budget or new priced geometric branch for F_core is proved. The calculations below identify the shared-input condition that remains unproved. The elementary small-dispersion/Markov split was screened out as a main result; it is not entered in the ledger. H, Far, E_r, full f and the original clock remain unchanged. No negative square is spent.

## 1. Exact local posterior moments

At fixed original (r,u), u in E_r, use the real full-f posterior

    pi_u(dy)=f(y)c_u(y)dy/m_u.

Its coordinates are not assumed independent. Let

    s_u(v)=pi_u(Q_v)=f(Q_u intersection Q_v)/m_u,
    T_u(v,w)=pi_u(Q_v intersection Q_w)
            =f(Q_u intersection Q_v intersection Q_w)/m_u.

All v,w integrations below use the SAME actual mu(dv)=dv/m_v on E_r. Set

    M1(r,u)=E_(pi_u) J_r(Y),
    M2(r,u)=E_(pi_u) J_r(Y)^2.

Tonelli proves

    M1=integral_(E_r)s_u(v)mu(dv),
    M2=integral_(E_r^2)T_u(v,w)mu(dv)mu(dw),              (1)
    Var_(pi_u)(J_r)
       =integral_(E_r^2)[T_u(v,w)-s_u(v)s_u(w)]
                                    mu(dv)mu(dw).        (2)

The bracket is the covariance of two receiver-capture indicators evaluated at ONE common actual source. Individual covariance entries need not be nonnegative; their integrated quadratic form is nonnegative. Replacing T_u(v,w) by s_u(v)s_u(w) would be an additional and generally unjustified independence assertion.

For the exact R364 source mass fraction,

    t_r(u)=pi_u{J_r>=H},

one has only the standard moment bounds

    t_r(u)<=min(1,M1/H,M2/H^2).                           (3)

Thus every retained core receiver necessarily satisfies

    M1>3H/4,  M2>3H^2/4.                                 (4)

These are necessary constraints, not estimates excluding or pricing the core.

The source-pair factor in F_core is itself exactly

    pi_u tensor pi_u{
       J_r(Y)>=H, J_r(Z)>=H, ||Y-Z||_1>=d_*(r)}.          (5)

The two source draws in this PRODUCT integral may be represented as independent copies of pi_u; that fact never makes the coordinates within either copy independent. No altered posterior or source-density cap is used in (1)–(5).

## 2. What the matching and existing center envelope actually give

The matched full masses imply the true joint bounds

    0<=T_u(v,w)<=min(s_u(v),s_u(w))
                    <=min(1,m_v/m_u,m_w/m_u),
    T_u(v,w)=0 if the actual triple intersection is empty. (6)

They do not replace the triple-intersection f mass by its volume. The R363 two-source bound estimates A_r(y,z) after integrating REAL centers; it does not by itself supply a bound on the f-weighted three-receiver incidence T_u in (1).

The available single-source capacity gives, with A_r^*=1+n log(r/a),

    0<=J_r(y)<=A_r^*/q_-.

Consequently M1<=A_r^*/q_- and M2<=(A_r^*/q_-)^2. Substitution into (3) gives no improvement over t<=1 whenever A_r^*/q_- is above H, which is precisely the nonempty high-J regime of interest. There is no valid step deriving a smaller t merely because several high-J sources occur in the same matched receiver.

The unresolved COMMON constraint is quantitative control of (1) under the simultaneous mass equations m_v=f(Q_v), real center geometry, and the same f that weights pi_u. This would have to control the high-J quantile or its far two-source part in (5). Bounds on each separate source center capacity, or on each separate receiver mass, have not supplied this shared-source control.

## 3. Check of the existing unweighted L2 route

Even granting the available dimension-independent unweighted L2 bound for cube maximal averaging, its precise consequence has the wrong source weight for (1). Freeze the actual radius assignment and let

    L_r h(v)=1_(E_r)(v) R_v^(-n) integral_(Q_v)h(y)dy.

If ||L_r||_(L2(dy)->L2(dv))<=C2, its adjoint satisfies the same bound, and

    J_r=L_r^*(1_(E_r)/q),
    integral J_r(y)^2dy
       <=C2^2 integral_(E_r)q_v^(-2)dv
       <=C2^2 |E_r|/q_-^2.                              (7)

This is an UNWEIGHTED Lebesgue-source estimate. In contrast the exact posterior moment is

    M2(r,u)=1/m_u integral_(Q_u) f(y)J_r(y)^2dy.           (8)

The normalization integral_(Q_u)f=m_u does not turn (7) into (8). Such a passage would require additional control of multiplication by sqrt(f), an appropriate weighted operator inequality, or another consequence of the full shared matching geometry. None is established here. Treating (7) as a bound for (8) would silently impose the missing source-weight control.

Nor does integrating (8) over the real receiver measure remove that weight: for example,

    integral_(E_r)m_u M2(r,u)du
       =integral f(y)J_r(y)^2 V_r(y)dy,
    V_r(y)=integral_(E_r)c_u(y)du.                        (9)

This is another weighted source expression. Thus the existing unweighted L2 theorem is compatible with the exact moment identities but does not furnish the needed core budget by the attempted argument.

## 4. Scope and stopping point

The main geometric intuition — a radius field adapted to one source may be unable to support most of a different receiver's f mass at high J simultaneously — has not been converted into a quantitative all-f inequality. Equations (1),(6),(8) specify where it must enter: the same-source triple intersections and their f weight cannot be independently optimized or factored.

This report supplies exact formulas and a checked obstruction in the attempted L2 inference, not a new payment, a counterexample to the desired theorem, or a proof that no stronger joint estimate exists. The original F_core remains unpaid, with precisely the original high-J and far predicates. Only /tmp/r365_geometry.md was written; work stops here.

## 5. Actual local arithmetic check

The following code was actually run. It checks the posterior normalization, first/second shared-incidence moments, covariance quadratic forms and standard quantile bounds with exact Fraction arithmetic. The finite incidence examples are algebra diagnostics, not claimed centered-cube/high-J-core realizations.

```python
from fractions import Fraction as F
from itertools import product
patterns=list(product([0,1],repeat=3))
checks=0; nonzero_covariances=0
for f in [[F(1)]*8,[F(i+1,3) for i in range(8)],[F((i*i+1),7) for i in range(8)]]:
  m=[sum(f[y]*patterns[y][u] for y in range(8)) for u in range(3)]
  volume=[F(2),F(3),F(5)]
  mu=[volume[u]/m[u] for u in range(3)]
  J=[sum(mu[v]*patterns[y][v] for v in range(3)) for y in range(8)]
  assert sum(f[y]*J[y] for y in range(8))==sum(volume)
  checks+=1
  for u in range(3):
    pi=[f[y]*patterns[y][u]/m[u] for y in range(8)]
    s=[sum(pi[y]*patterns[y][v] for y in range(8)) for v in range(3)]
    T=[[sum(pi[y]*patterns[y][v]*patterns[y][w] for y in range(8)) for w in range(3)] for v in range(3)]
    first=sum(pi[y]*J[y] for y in range(8))
    second=sum(pi[y]*J[y]**2 for y in range(8))
    assert first==sum(mu[v]*s[v] for v in range(3));checks+=1
    assert second==sum(mu[v]*mu[w]*T[v][w] for v in range(3) for w in range(3));checks+=1
    cov=[[T[v][w]-s[v]*s[w] for w in range(3)] for v in range(3)]
    nonzero_covariances+=sum(cov[v][w]!=0 for v in range(3) for w in range(3) if v!=w)
    assert second-first**2==sum(mu[v]*mu[w]*cov[v][w] for v in range(3) for w in range(3));checks+=1
    assert second>=first**2;checks+=1
    for H in sorted(set(J)):
      if not H:continue
      t=sum(pi[y] for y in range(8) if J[y]>=H)
      assert t<=min(F(1),first/H,second/(H*H));checks+=1
    for coeff in [[F(1),F(-2),F(3)],[F(2),F(1),F(-1)]]:
      vals=[sum(coeff[v]*patterns[y][v] for v in range(3)) for y in range(8)]
      mean=sum(pi[y]*vals[y] for y in range(8))
      actual=sum(pi[y]*(vals[y]-mean)**2 for y in range(8))
      quadratic=sum(coeff[v]*coeff[w]*cov[v][w] for v in range(3) for w in range(3))
      assert actual==quadratic>=0;checks+=1
print('PASS',checks,'exact posterior shared-incidence checks; nonzero off-diagonal covariances:',nonzero_covariances)
```

Actual output:

```text
PASS 117 exact posterior shared-incidence checks; nonzero off-diagonal covariances: 12
```
