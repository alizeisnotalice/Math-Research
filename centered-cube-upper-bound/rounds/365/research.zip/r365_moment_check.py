from fractions import Fraction as F
from itertools import product
from pathlib import Path
import json
centres=list(product([F(-1,4),F(1,4)],repeat=2)); rs=[F(1),F(3,2)];dx=F(1,4)
cuts=sorted({F(0)}|{c+s*r/2 for p in centres for c in p for r in rs for s in [-1,1]})
cells=[((a+b)/2,(c+d)/2,(b-a)*(d-c)) for a,b in zip(cuts,cuts[1:]) for c,d in zip(cuts,cuts[1:])]
inc={(u,k):[int(abs(x-p[0])<r/2 and abs(y-p[1])<r/2) for x,y,_ in cells] for u,p in enumerate(centres) for k,r in enumerate(rs)}
checks=0;records=[]
for eta in [F(0),F(1,2),F(9,10)]:
 f=[area*(1+eta*(1 if x*y>0 else -1)) for x,y,area in cells]
 m={v:sum(w*c for w,c in zip(f,iv)) for v,iv in inc.items()}
 lam=max(m[u,k]/rs[k]**2 for u,k in inc)
 for nr in [2,3,4]:
  fields=0;posterior_tests=0;core_hits=0;max_variance=F(0)
  for cfg in product([-1,0,1],repeat=nr):
   active=[(u,k) for u,k in enumerate(cfg) if k>=0]
   if any(m[u,k]/rs[k]**2<3*lam/4 for u,k in active):continue
   fields+=1
   X=sum(dx*m[v]/rs[v[1]]**2 for v in active)
   full=F(0)
   for level,ew in enumerate([F(5,9),F(4,9)]):
    vs=[v for v in active if v[1]<=level]
    mu={v:dx/m[v] for v in vs}
    J=[sum(mu[v]*inc[v][i] for v in vs) for i in range(len(f))]
    full+=ew*sum(dx*m[v] for v in vs)
    for u in vs:
     pi=[w*c/m[u] for w,c in zip(f,inc[u])]
     mean=sum(p*j for p,j in zip(pi,J));second=sum(p*j*j for p,j in zip(pi,J))
     sv={v:sum(p*c for p,c in zip(pi,inc[v])) for v in vs}
     tri={(v,w):sum(p*c*d for p,c,d in zip(pi,inc[v],inc[w])) for v in vs for w in vs}
     assert mean==sum(mu[v]*sv[v] for v in vs);checks+=1
     assert second==sum(mu[v]*mu[w]*tri[v,w] for v in vs for w in vs);checks+=1
     var=second-mean**2
     assert var==sum(mu[v]*mu[w]*(tri[v,w]-sv[v]*sv[w]) for v in vs for w in vs)>=0;checks+=1
     max_variance=max(max_variance,var);posterior_tests+=1
     for H in [F(1,8),F(1,4),F(1,2)]:
      t=sum(p for p,j in zip(pi,J) if j>=H)
      assert mean>=t*H and second>=t*H*H;checks+=1
      if mean<H:
       assert t<=var/(var+(H-mean)**2);checks+=1
      core_hits+=int(t>F(3,4))
   assert full==X;checks+=1
  records.append(dict(eta=str(eta),receivers=nr,admissible_fields=fields,posterior_tests=posterior_tests,core_threshold_hits=core_hits,max_variance=str(max_variance)))
out=dict(checks=checks,source_cells=len(cells),scope='Exact real cube source masses and correlated densities; receivers are finite quadrature. All moments use same source posterior. H tests are diagnostics, not original high-past realization; no dimension-growth inference.',rows=records)
(Path(__file__).resolve().parent/'r365_moment_result.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
