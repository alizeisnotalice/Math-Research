# R365 independent audit — preliminary screen and available author review

Status: FINAL PASS for the source-posterior moments, both author notes, the finite diagnostic and final integration, within their expressly limited scope. Only this file is reviewer-owned. No new general root-order source/receiver payment is certified. Bindings below refer to the final bytes reviewed.

## Independent proposition screen before author proofs
Freeze the original hard matched field, full f>=0 in L1, true receiver du, m_u=f(Q_u)=q_u R_u^n with q_->0 and finite band a<=R_u<=b. Fix an actual receiver u with m_u>0 and original physical r. Define pi_u=f 1_Qu/m_u, s_u(v)=pi_u(Q_v), T_u(v,w)=pi_u(Q_v intersect Q_w), J_r(y)=integral_(E_r)c_v(y)dmu(v), dmu=dv/m_v. These identities require the SAME source f and actual receiver field in every quantity. They do not assume conditional independence or assign different sourcewise radii. For a core receiver u one additionally has u in E_r.

Positive Tonelli gives E_pi J=integral s_u dmu and E_pi J^2=double integral T_u dmu dmu. Subtracting the finite product of first moments gives Var_pi J=double integral(T_u-s_u s_u)dmu dmu. The finite-band actual-center majorant gives 0<=J<=A_n(r)/q_- (and the full J_b bound for all prefixes). Therefore all these moments are finite; the signed double integrand is absolutely integrable, bounded in integral by E_pi J^2+(E_pi J)^2. Alternatively finite E and m>=q_-a^n give finite mu directly. No invalid conditional exchange of signed divergent quantities is needed. With f=0 on Qu the posterior is undefined, but such u has m=0 and is excluded by the actual q-band contract.

Matching implies 0<=T_u(v,w)<=min(s_u(v),s_u(w)) and <=min(1,m_v/m_u,m_w/m_u). The Frechet lower bound max(0,s_u(v)+s_u(w)-1) is also valid; T cannot be replaced by s_u(v)s_u(w). Covariances may have either sign and only their full double integral is a nonnegative variance.

The R364 core hypothesis is pi_u{J_r>=H}>3/4 at the SAME r, not under a Far-conditioned or subsequently restricted posterior. It implies E_pi J>=tH and E_pi J^2>=tH^2 for t=pi_u{J>=H}; since H>0 this gives E_pi J>3H/4. It supplies no useful variance upper bound or source-linear budget on its own. Zero J values in this posterior are legal; high-J gates exclude them. All physical clock endpoint/atom qualifications remain those of R364.

## Available author note: shared selector
Read /tmp/r365_selector.md in full after the independent moment screen. PASS. Its T_R is deliberately the UNNORMALIZED actual cube integral, so the adjoint is integral_E psi(u)c_u(y)du and signed Fubini is justified exactly by integral_E |psi|m<infinity. A certificate p_core<=C+T_R*psi f-a.e. and integral psi m<=epsilon X_q would imply the requested budget, but no such cheap certificate is provided. The displayed psi0=R^-n pays exactly X_q, not epsilon X_q. Writing psi=psi0-h preserves both the cover condition and the receiver bill, with no hidden credit or double use of the low-J receipt.

The candidate-radius profile freezes all original J,g_r,Far data; it is only an outer comparison, not a new field with unchanged J. Source integrals must precede a common-radius supremum. The two-radius difference retains the positive shell numerator change, the SAME old-pair normalization subtraction, and the discarded [t1,t2) physical clock; at t2=b the terminal atom remains in [t2,b]. The numerator shell increment uses actual f mass, not shell volume. The core richness predicate need not be monotone in candidate radius. Cross-center source-shell reuse has no free disjointness or Carleson budget.

Author reports 648 Fraction scalar clock/difference checks, explicitly not a full high-J/Far cube realization; reviewer did not rerun that pipeline. A separate reviewer-local Python run actually passed 54 exact Fraction first/second/covariance identities in finite matched-incidence data. This is algebra evidence only, excluded from parent/author counts and not continuum cube geometry.

## Final geometry author review
Read /tmp/r365_geometry.md in full. Its moment identities, normalization, mixed covariance signs, standard quantile bounds and necessary core conditions agree with the independent screen. The two sources inside Fcore may be independent draws from pi_u tensor pi_u; this does NOT assert coordinate independence within pi_u or independence of receiver-incidence indicators under a single draw. The exact triple-overlap upper bounds are legal matching consequences, not density-by-volume estimates.

The L2 section is audited ONLY as a conditional implication: if the actual selected normalized averaging operator has an unweighted L2 bound C2, its adjoint gives integral J_r^2 dy<=C2^2 integral_Er q^-2 du. The desired moment is instead integral_Qu f J_r^2/m_u. Neither posterior normalization nor an extra receiver integration removes that source weight; the latter produces integral f J_r^2 V_r. No weighted interface or cheap source budget follows. This review does not grant an external L2 theorem as a completed interface for this project. The 117 exact finite-incidence checks are author-reported only, not part of the parent's fresh runs or native continuum realization.

## Final code/result and integration review
Read /tmp/r365_main.md, /tmp/r365_ledger.md, /tmp/r365_readme.md, /tmp/r365_moment_check.py and /tmp/r365_moment_result.json in full. PASS without a substantive correction request. The source partition includes zero axes and all candidate-cube faces, hence 64 rectangles on which the correlated density 1+eta sign(xy) and each cube incidence are constant. Source integration is exact. Four candidate centers with two radii and the inactive option define finite receiver QUADRATURE weights dx=1/4, not positive-volume Lebesgue E. The three source densities eta=0,1/2,9/10 remain positive. Full candidate masses determine one lambda per density; the admissibility filter retains only actual selected q>=3lambda/4, with equality accepted and q<=lambda by construction. The all-inactive field is included in the reported 249 admissible configurations.

The script computes J and all first/second/third-incidence terms from the SAME f and radius field, uses nonnegative exact Fraction arithmetic and covariance subtraction, and applies the standard Cantelli inequality only when mean<H. Inclusive radius-layer clock weights 5/9,4/9 have the correct R^-2 tails, including the terminal atom; the full matched first-moment check is consistent with X_q. The result JSON reports 6487 assertions and nine density/receiver-count records. The reported core_threshold_hits only count local t>3/4 events over tested rows/H values; they do not assert the original Far/high-past or full core is nonzero. The continuum J envelope is not transferred into the quadrature model. There is no dimension-growth or general source-payment inference.

Parent reports actual fresh runs of 6487 Fraction moment/quantile checks and the selector's 648 Fraction clock-difference identities. Geometry's 117 checks remain author-reported; reviewer's 54 local Fraction moment checks remain separate. No full pipeline was redundantly rerun for the final audit. No ordinary floating computation is being mislabeled as an interval proof.

The main retains all fixed data and full source weights, labels the moment conditions necessary only, and explicitly grants the L2 statement only conditionally. The sufficient signed selector certificate is not described as attained; the sole explicit psi=R^-n still costs X_q. No new payment, absorption coefficient, H choice or negative-square use is inserted. The final ledger fully preserves the R364 alternative bound with coefficient14lambda H W, both unpriced terms Bnear/Fcore, original entrance2 and outerLambda, and the complete old path ledger as a separate route. It does not add the two routes, repurchase low-J costs or use old square credit twice. All soft, physical-clock, historical-time, scale, source and limit exclusions remain explicit.

General root-order/B_H closure remains unproved. Final PASS concerns mathematical identities, conditional implications, code scope and integration only; it does not independently certify the main's literature-reading records, skill usage, whole historical reductions, TeX/PDF compilation, ZIP integrity or Git state.


Final wording clarification: the main now expressly says the two candidate mechanisms (shared-source triple-overlap control and cross-center shell/normalization/clock settlement) have not been proved equivalent, nor has either been proved sufficient for every remaining term. PASS extends to this corrected limitation; no mathematical proof, code or numerical run changed and no pipeline was repeated.

## Final SHA256 bindings

- `/tmp/r365_geometry.md` — `a18b9fb0e72f2d4768f0c06570cd4229ca8ec8a4c1c4242e0fce1e6d2b5861c4`

- `/tmp/r365_selector.md` — `5da59119ff3ae436dc998c5421de8f7f105a6a0289c97182fbef4b78c40d5ad9`

- `/tmp/r365_main.md` — `8ccf3dc962449d51b841265502681b82d33efefceaac659af252ef6675d461db`

- `/tmp/r365_ledger.md` — `db06cb2d4ed9b17d42113007b1e5f35a5045b2a98c97d3ee8ae2a195e345cc58`

- `/tmp/r365_readme.md` — `2d16b8e70d769cc8f3e3aa888ab97929f8852cf8a47df1e7a4d036c19a324893`

- `/tmp/r365_moment_check.py` — `5b5e68c7f110ddc55c879fee1efc35836112be092eb419255dd654a1cd0cdafa`

- `/tmp/r365_moment_result.json` — `762896cfa26e5a6936a52d950f07b8628e0a8c50409f0a879c3782d50acb4d4c`

- `/tmp/r364_audit.md` — `dc04b83af15c7a3afd2d9cbf2914d39f4212b3ec19756eaa5b27a4e8931065d6`

- `/tmp/r364_ledger.md` — `4ce56ef26d9860b64bcfc119c8d9fbfcd595d00fa3badedd44ed8b6a7a450482`
