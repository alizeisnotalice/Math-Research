from __future__ import annotations

import argparse
import hashlib
import json
import platform
import sys
from dataclasses import dataclass
from fractions import Fraction as F
from itertools import combinations, product
from math import comb, isqrt, prod
from pathlib import Path

import flint
from flint import arb, ctx, fmpq


K_VALUES = (1, 2, 4, 16)
PRECISION = 256


def point(*coordinates):
    return tuple(F(x) for x in coordinates)


def ball(value):
    value = F(value)
    return arb(fmpq(value.numerator, value.denominator))


def enclosure(value):
    return value.str(25)


def dot(left, right):
    return sum((x * y for x, y in zip(left, right)), F(0))


def subfamilies(labels):
    for size in range(1, len(labels) + 1):
        yield from combinations(labels, size)


def coordinate_vector(size, index, value=1):
    return tuple(F(value if axis == index else 0) for axis in range(size))


@dataclass(frozen=True)
class Cube:
    center: tuple
    radius: F

    @property
    def bounds(self):
        return tuple((x - self.radius, x + self.radius) for x in self.center)

    @property
    def volume(self):
        return (2 * self.radius)**len(self.center)

    def scaled(self, factor):
        return Cube(self.center, self.radius * factor)


@dataclass(frozen=True)
class Constraint:
    kind: str
    labels: tuple
    normal: tuple
    bound: F


@dataclass(frozen=True)
class LPCertificate:
    value: F
    primal: tuple
    dual: tuple


def linear_system(matrix, rhs):
    order = len(rhs)
    rows = [[F(x) for x in row] + [F(y)] for row, y in zip(matrix, rhs)]
    for column in range(order):
        pivot = next((i for i in range(column, order) if rows[i][column]), None)
        if pivot is None:
            return None
        rows[column], rows[pivot] = rows[pivot], rows[column]
        scale = rows[column][column]
        rows[column] = [v / scale for v in rows[column]]
        for i, other in enumerate(rows):
            if i != column and other[column]:
                factor = other[column]
                rows[i] = [x - factor * y for x, y in zip(other, rows[column])]
    return tuple(row[-1] for row in rows)


def solve_lp(objective, constraints):
    order = len(objective)
    best = None
    best_value = None
    for choices in combinations(constraints, order):
        vertex = linear_system([c.normal for c in choices], [c.bound for c in choices])
        if vertex is None or any(dot(c.normal, vertex) > c.bound for c in constraints):
            continue
        value = dot(objective, vertex)
        if best is None or value > best_value:
            best = vertex
            best_value = value
    assert best is not None
    tight = [c for c in constraints if dot(c.normal, best) == c.bound]
    for choices in combinations(tight, order):
        certificate = linear_system(list(zip(*(c.normal for c in choices))), objective)
        if certificate is None or any(y < 0 for y in certificate):
            continue
        dual = tuple((c, y) for c, y in zip(choices, certificate) if y)
        assert sum(c.bound * y for c, y in dual) == best_value
        for i in range(order):
            assert sum(c.normal[i] * y for c, y in dual) == objective[i]
        return LPCertificate(best_value, best, dual)
    raise AssertionError("no rational dual certificate")


def positive_cells(cubes):
    axes = []
    for axis in range(len(cubes[0].center)):
        endpoints = sorted({end for cube in cubes for end in cube.bounds[axis]})
        axes.append(list(zip(endpoints, endpoints[1:])))
    for cell in product(*axes):
        middle = [(lo + hi) / 2 for lo, hi in cell]
        members = frozenset(
            i for i, cube in enumerate(cubes)
            if all(lo < z < hi for (lo, hi), z in zip(cube.bounds, middle))
        )
        if members:
            yield members, prod(hi - lo for lo, hi in cell)


def intersection_volume(cubes):
    return prod(
        max(F(0), min(hi for _, hi in axis) - max(lo for lo, _ in axis))
        for axis in zip(*(cube.bounds for cube in cubes))
    )


def ownership(cubes):
    a = 32 * len(cubes[0].center)
    shrunk = [cube.scaled(F(1, a)) for cube in cubes]
    masses = [F(0)] * len(cubes)
    cells = 0
    for members, size in positive_cells(shrunk):
        masses[min(members)] += size
        cells += 1
    for i, cube in enumerate(shrunk):
        check = cube.volume
        for subset in subfamilies(tuple(range(i))):
            check += (-1)**len(subset) * intersection_volume((cube, *(shrunk[j] for j in subset)))
        assert check == masses[i]
    return tuple(masses), cells


def maximal_masks(signatures, labels):
    label_set = frozenset(labels)
    masks = {s & label_set for s in signatures} - {frozenset()}
    return tuple(sorted(tuple(sorted(s)) for s in masks if not any(s < t for t in masks)))


def constraints_for(signatures, labels, caps=None):
    size = len(labels)
    rows = [
        Constraint("parent_cell", mask, tuple(F(i in mask) for i in labels), F(1))
        for mask in maximal_masks(signatures, labels)
    ]
    rows += [
        Constraint("nonnegative", (i,), coordinate_vector(size, k, -1), F(0))
        for k, i in enumerate(labels)
    ]
    if caps is not None:
        rows += [
            Constraint("cap", (i,), coordinate_vector(size, k), cap)
            for k, (i, cap) in enumerate(zip(labels, caps))
        ]
    return rows


def dump_lp(cert):
    return {
        "value": str(cert.value),
        "lambda": list(map(str, cert.primal)),
        "nonzero_dual": [
            {"kind": constraint.kind, "labels": list(constraint.labels), "multiple": str(value)}
            for constraint, value in cert.dual
        ],
    }


def phi(k):
    return k * (1 - (-ball(F(1, k))).exp())


def scalar_price(m, k):
    return m + k * (1 - m + m * m.log())


def audit_family(name, cubes):
    labels = tuple(range(len(cubes)))
    d = tuple(c.volume for c in cubes)
    v, owner_cells = ownership(cubes)
    signatures = {members for members, _ in positive_cells(cubes)}
    uncap_rows = constraints_for(signatures, labels)
    certificates = {}
    worst_ratio = F(0)
    worst_sets = []
    for subset in subfamilies(labels):
        local = tuple(d[i] for i in subset)
        cert = solve_lp(local, constraints_for(signatures, subset))
        owner_mass = sum(v[i] for i in subset)
        ratio = owner_mass / cert.value
        certificates[subset] = cert
        if ratio > worst_ratio:
            worst_ratio = ratio
            worst_sets = [subset]
        elif ratio == worst_ratio:
            worst_sets.append(subset)
    b = tuple(size / worst_ratio for size in v)
    total_b = sum(b)
    raw = certificates[labels]
    for subset, cert in certificates.items():
        assert sum(b[i] for i in subset) <= cert.value
    full_p = tuple(x * y for x, y in zip(d, raw.primal))

    capped_reports = []
    for k in K_VALUES:
        p_caps = tuple(k * demand for demand in b)
        lambda_caps = tuple(cap / size for cap, size in zip(p_caps, d))
        capped = solve_lp(d, constraints_for(signatures, labels, lambda_caps))
        clipped = sum(min(x, cap) for x, cap in zip(full_p, p_caps))
        assert clipped <= capped.value <= raw.value

        u = [F(0)] * len(labels)
        for constraint, multiple in capped.dual:
            if constraint.kind == "cap":
                i = constraint.labels[0]
                u[i] = min(d[i], multiple) / d[i]
        q = tuple(1 - yi for yi in u)
        assert all(0 <= qi <= 1 for qi in q)
        support = solve_lp(tuple(qi * di for qi, di in zip(q, d)), uncap_rows)
        cap_part = sum(cap * yi for cap, yi in zip(p_caps, u))
        assert support.value + cap_part == capped.value
        candidates = [
            t * sum(bi for qi, bi in zip(q, b) if qi >= t)
            for t in set(q) if t > 0
        ]
        m = max(candidates, default=F(0)) / total_b
        mean_q = dot(q, b) / total_b
        assert support.value >= m * total_b
        if 0 < m < 1:
            mb = ball(m)
            assert ball(mean_q) < mb * (1 - mb.log())
        else:
            assert mean_q == m
        assert ball(capped.value / total_b) > phi(k)

        capped_reports.append({
            "K": k,
            "coordinate_cap_on_one_raw_optimum": str(clipped),
            "optimized_capped_lp": dump_lp(capped),
            "capped_optimum_divided_by_demand": str(capped.value / total_b),
            "dual_mixture_q": list(map(str, q)),
            "dual_uncapped_support": dump_lp(support),
            "dual_cap_part": str(cap_part),
            "normalized_tail_envelope_M": str(m),
            "normalized_mean_q": str(mean_q),
        })

    return {
        "name": name,
        "dimension": len(cubes[0].center),
        "cubes": [
            {"center": list(map(str, cube.center)), "radius": str(cube.radius)} for cube in cubes
        ],
        "parent_arrangement_signatures": [list(mask) for mask in sorted(map(sorted, signatures))],
        "positive_shrink_cells": owner_cells,
        "owner_volumes_first_containing_shrink": list(map(str, v)),
        "G0": str(worst_ratio),
        "G0_maximizers": [list(subset) for subset in worst_sets],
        "demand": list(map(str, b)),
        "total_demand": str(total_b),
        "all_subfamily_optima": [
            {"labels": list(subset), "certificate": dump_lp(certificate)}
            for subset, certificate in certificates.items()
        ],
        "capped_runs": capped_reports,
    }


def fixtures():
    return (
        (
            "interval_chain_with_three_way_overlap",
            (
                Cube(point(0), F(2)), Cube(point(1), F(1)), Cube(point(3), F(3, 2)),
                Cube(point("11/2"), F(2)), Cube(point("13/2"), F(1)),
            ),
        ),
        (
            "squares_with_zero_owner_partial_owner_and_face_contact",
            (
                Cube(point(0, 0), F(3, 2)), Cube(point("1/128", 0), F(1, 2)),
                Cube(point("1/32", "1/64"), F(1)), Cube(point("13/8", 0), F(1)),
                Cube(point("11/4", "1/2"), F(5, 4)),
            ),
        ),
        (
            "five_cycle_of_equal_squares_with_fractional_primal",
            (
                Cube(point(0, 0), F(1)), Cube(point("3/2", 0), F(1)),
                Cube(point("5/2", "3/2"), F(1)), Cube(point(1, 3), F(1)),
                Cube(point("-3/4", "3/2"), F(1)),
            ),
        ),
        (
            "concentric_intervals_with_equal_true_owner_volumes",
            tuple(Cube(point(0), F(i, 2)) for i in range(1, 6)),
        ),
    )


def disk_check():
    # This is an abstract down-closed convex set. It is not a cube packing.
    b = (F(3, 5), F(4, 5))
    assert sum(x*x for x in b) == 1
    assert all(x < 1 for x in b) and sum(b)**2 < 2
    p = 1 / arb(2).sqrt()
    assert ball(b[0]) < p < ball(b[1])
    optimum_uncapped = arb(2).sqrt()
    direct = ball(b[0]) + p
    assert direct < ball(sum(b)) < optimum_uncapped
    for k in K_VALUES:
        assert ball(sum(b)) > phi(k) * ball(sum(b))
    return {
        "constraint": "p_1,p_2 >= 0; p_1^2+p_2^2 <= 1",
        "scope": "abstract non-polyhedral down-closed set",
        "demand": [str(x) for x in b],
        "unrestricted_optimum": enclosure(optimum_uncapped),
        "K1_direct_truncation": enclosure(direct),
        "K1_reoptimized": str(sum(b)),
        "K_ge_2_reoptimized": enclosure(optimum_uncapped),
    }


def nested_exact(dimension, layers):
    if dimension == 1:
        volumes = tuple(F(i) for i in range(1, layers + 1))
        radius_rule = "i/2"
    else:
        volumes = tuple((2 * F(i, layers))**dimension for i in range(1, layers + 1))
        radius_rule = "i/m"
    b = tuple(hi - lo for lo, hi in zip((F(0), *volumes[:-1]), volumes))
    total = volumes[-1]
    a = 32 * dimension
    # With radius order, the true owners are successive differences of the shrunk cores.
    assert sum(b) == total and all(x > 0 for x in b)
    raw_restricted = []
    for k in K_VALUES:
        cap = tuple(k * x for x in b)
        weights = [F(0)] * layers
        remaining = F(1)
        for i in range(layers - 1, -1, -1):
            weights[i] = min(cap[i], remaining * volumes[i])
            remaining -= weights[i] / volumes[i]
            if remaining == 0:
                marginal = i
                break
        assert remaining == 0 and dot(weights, [1 / v for v in volumes]) == 1
        eta = volumes[marginal]
        prices = tuple(max(F(0), 1 - eta / v) for v in volumes)
        assert all(eta / v + u >= 1 for v, u in zip(volumes, prices))
        assert all(0 <= p <= c for p, c in zip(weights, cap))
        assert eta + dot(cap, prices) == sum(weights)
        clipped = min(total, cap[-1])
        assert clipped <= sum(weights)
        ratio = sum(weights) / total
        assert ball(ratio) > phi(k)
        if dimension == 1:
            assert ball(ratio) - phi(k) < ball(F(2*k, layers))
        raw_restricted.append({
            "K": k,
            "marginal_rank": marginal + 1,
            "marginal_primal_amount": str(weights[marginal]),
            "full_upper_ranks": layers - marginal - 1,
            "dual_volume_multiplier": str(eta),
            "exact_capped_value": str(sum(weights)),
            "exact_normalized_capped_value": str(ratio),
            "raw_unique_optimum_truncated_normalized": str(clipped / total),
        })

    r = max(1, isqrt(layers))
    near_p = tuple((v / r if j >= layers - r else F(0)) for j, v in enumerate(volumes))
    near_obj = sum(near_p)
    assert dot(near_p, [1 / v for v in volumes]) == 1
    near_report = []
    epsilon = 1 - near_obj / total
    if dimension == 1:
        assert epsilon == F(r - 1, 2*layers)
    for k in K_VALUES:
        near_clip = sum(min(p, k * demand) for p, demand in zip(near_p, b)) / total
        if dimension == 1:
            assert near_clip <= F(k*r, layers)
            upper = 2 * ball(k*epsilon).sqrt() + ball(F(k, layers))
            assert ball(near_clip) < upper
        near_report.append({"K": k, "normalized_clipped_near_optimum": str(near_clip)})
    return {
        "dimension": dimension,
        "layers": layers,
        "rational_radius_rule": radius_rule,
        "all_centers_at_origin": True,
        "P0": str(total),
        "G0": str(F(1, a**dimension)),
        "demand_rule": "successive differences of parent volumes",
        "subfamily_certificate_rule": "largest-volume cube alone, and common open point gives the dual",
        "raw_optimum": "unique; lambda_m = 1",
        "second_best_vertex_ratio": str(volumes[-2] / total),
        "near_optimum_top_ranks": r,
        "near_optimum_relative_gap": str(epsilon),
        "near_optimum_direct_truncations": near_report,
        "capped_runs": raw_restricted,
    }


def harmonic_gap(m, k):
    psi_m = arb(m + 1).digamma()
    lo, hi = 1, m
    while lo < hi:
        middle = (lo + hi) // 2
        candidate = k * (psi_m - arb(middle + 1).digamma())
        if candidate < 1:
            hi = middle
        elif candidate > 1:
            lo = middle + 1
        else:
            raise AssertionError("Arb precision insufficient for the integer threshold")
    j = lo
    tail = psi_m - arb(j+1).digamma()
    assert k * tail < 1 < k * (psi_m - arb(j).digamma())
    remainder = (1 - k * tail) * j
    assert 0 < remainder < k
    ratio = (k * (m-j) + remainder) / m
    limit = phi(k)
    gap = ratio - limit
    assert 0 < gap < ball(F(2*k, m))
    theta = (-ball(F(1, k))).exp()
    assert abs(ball(F(j, m)) - theta) < ball(F(1, m))
    m_envelope = ball(F(j, m))
    assert m_envelope * (1 + tail) < m_envelope * (1 - m_envelope.log())
    return {
        "layers": m,
        "K": k,
        "certified_marginal_rank": j,
        "marginal_primal_amount": enclosure(remainder),
        "normalized_capped_optimum": enclosure(ratio),
        "limit_gap": enclosure(gap),
        "integer_threshold_rule": "K*(H_m-H_j)<1<K*(H_m-H_(j-1))",
    }


def symmetric_scalar(k, power):
    eps = ball(F(1, 2**power))
    optimum = (-ball(F(1, k))).exp()
    minimizer_value = phi(k)
    left = optimum * (1 - eps)
    right = optimum * (1 + eps)
    assert 0 < left < optimum < right < 1
    gaps = (scalar_price(left, k) - minimizer_value, scalar_price(right, k) - minimizer_value)
    independent = (
        k * optimum * ((1 - eps) * (1 - eps).log() + eps),
        k * optimum * ((1 + eps) * (1 + eps).log() - eps),
    )
    assert all(x.overlaps(y) for x, y in zip(gaps, independent))
    lower = k * optimum * eps**2 / (2 * (1 + eps))
    upper = k * optimum * eps**2 / (2 * (1 - eps))
    assert all(0 < lower < gap < upper for gap in gaps)
    return {
        "K": k,
        "relative_perturbation": str(F(1, 2**power)),
        "left_excess": enclosure(gaps[0]),
        "right_excess": enclosure(gaps[1]),
    }


def overlap_length(center_big, center_small, radius_small):
    lo = max(center_big-1, center_small-radius_small)
    hi = min(center_big+1, center_small+radius_small)
    return max(F(0), hi-lo)


def axis_geometry_check():
    summary = []
    rational_samples = 0
    for r0 in (F(1), F(1, 2), F(1, 4)):
        boundary = 1 - r0 / 4
        upper = min(F(1), 2*r0)
        for r in {r0, (r0+upper)/2, upper}:
            for j, l in product(range(9), repeat=2):
                u = boundary + (1-boundary) * F(j, 8)
                v = -1 + F(l, 16)
                assert u-r*v >= 1+r/4
                assert overlap_length(u, r*v, r)/(2*r) <= F(3, 8)
                rational_samples += 1
        assert overlap_length(boundary, -r0/2, r0)/(2*r0) == F(3, 8)
        p = r0/32
        for n in (64, 256, 1024):
            target = (n*p/2).__ceil__()
            lower_tail = sum((comb(n,j)*p**j*(1-p)**(n-j) for j in range(target)), F(0))
            chernoff = (-ball(n*p/8)).exp()
            assert ball(lower_tail) < chernoff
            summary.append({
                "dimension": n,
                "r0": str(r0),
                "ideal_single_axis_event": str(p),
                "target_axes": target,
                "ideal_independent_failure_probability": enclosure(ball(lower_tail)),
                "chernoff_upper": enclosure(chernoff),
                "intersection_ratio_on_success_at_most": str(F(3, 8)**target),
            })
    return {
        "rational_geometry_samples": rational_samples,
        "equality_attained_at_selected_boundary": True,
        "scope": "independent uniform reference coordinates; no inference of independence for actual prices or owners",
        "binomial_exact_sums_with_arb_display": summary,
    }


def report():
    ctx.prec = PRECISION
    script = Path(__file__)
    small = [audit_family(name, cubes) for name, cubes in fixtures()]
    assert F(0) in tuple(map(F, small[1]["owner_volumes_first_containing_shrink"]))
    cycle_cert = small[2]["all_subfamily_optima"][-1]["certificate"]
    assert cycle_cert["value"] == "10" and cycle_cert["lambda"] == ["1/2"]*5
    nested = [nested_exact(d, m) for d, m in ((1, 8), (1, 32), (1, 128), (1, 512), (2, 128), (4, 128))]
    return {
        "schema": "r748-capped-packing-verification-v1",
        "runtime": {
            "python": platform.python_version(),
            "python_executable": sys.executable,
            "python_flint": flint.__version__,
            "arb_precision_bits": PRECISION,
            "script_sha256": hashlib.sha256(script.read_bytes()).hexdigest(),
            "working_directory_for_commands": "directory containing verify.py and verify.json",
            "write_command": [sys.executable, "-B", script.name, "--out", "verify.json"],
            "rerun_command": [sys.executable, "-B", script.name, "--check", "verify.json"],
        },
        "finite_cube_lp_certificates": small,
        "abstract_disk_reoptimization": disk_check(),
        "actual_rational_concentric_cube_certificates": nested,
        "high_layer_sharpness_scalar_only": [
            harmonic_gap(m, k) for m in (2**20, 2**40, 2**60) for k in K_VALUES
        ],
        "arb_price_coefficients": [{"K": k, "coefficient": enclosure(phi(k))} for k in K_VALUES],
        "arb_symmetric_near_optimizer_prices": [
            symmetric_scalar(k, power) for k in K_VALUES for power in (8, 24, 40)
        ],
        "axis_intersection_reference_check": axis_geometry_check(),
        "scope": [
            "Owner volumes use the original ordered partition of the union of shrinks and an independent exact inclusion-exclusion check.",
            "Full and capped finite packing certificates use exact rational constraints at positive-volume parent arrangement signatures. Caps are on p_i=d_i*lambda_i.",
            "G0 is the worst subset ratio using its original owner masses. All subset optima, and primal/dual certificates for each, are recorded.",
            "The exact concentric examples are genuine nested cubes. The disk is only an abstract convex set.",
            "Large layers use Arb harmonic and pricing identities without enumerating cube geometry.",
        ],
    }


def main():
    parser = argparse.ArgumentParser()
    target = parser.add_mutually_exclusive_group(required=True)
    target.add_argument("--out", type=Path)
    target.add_argument("--check", type=Path)
    args = parser.parse_args()
    payload = json.dumps(report(), ensure_ascii=False, indent=2, sort_keys=True) + "\n"
    if args.out:
        args.out.write_text(payload, encoding="utf-8")
        print(f"wrote {args.out} ({len(payload)} bytes)")
    else:
        if args.check.read_text(encoding="utf-8") != payload:
            raise SystemExit("rerun differs from the saved results")
        print(f"identical rerun of {args.check} ({len(payload)} bytes)")


if __name__ == "__main__":
    main()
