# Round 64: hereditary cap covers and spatial obstacle cancellation

2026-10-11. **The uniform objective C_n^square <= sqrt(n)n^{o(1)} remains unproved.**
The retained fully general upper benchmark is O(n log n). This round proves
structural identities valid for arbitrary finite positive sources and tests
the actual original-good-set energy using full-space Lebesgue receivers.
It neither substitutes special-family estimates for the goal nor interprets
large energy, a linear relaxation gap, or stagewise cost as a weak-type counterexample.

The preceding round supplied exact finite cap-cover constraints but left
their general budget unpaid. Here we distinguish common and own-source target
mass budgets, prove their worst-class constants equal the original signed
projection constant, and derive a homogeneous signed free interaction kernel
with exact cube-annular cancellation. The remaining obstacle interaction must
be estimated jointly with that kernel. Separate absolute payments are refuted
by actual near-coincident sources. A source-adapted receiver sampler improves
the numerical envelope without introducing a smallest-mass loss.

## Verified scope and reproduction

This archive has exactly five members: proof.md, proof.tex.txt,
general_cap_probe.py, results.json, inventory.json. Extract to a temporary
directory, preserve the supplied results.json, and run
`python3 -B general_cap_probe.py` with Python 3.12.14 and NumPy 2.3.5.
The default writes a new results.json beside the script; do not use --pilot
for the final reproduction. Three supplementary standard-library programs
are embedded in the proof sections below. Save each Python block and run it
to reproduce the corresponding guard. No omitted draft or external data is
needed to reproduce the reported checks.

The parent independently reran the final main script in a new temporary
directory: the complete JSON was byte-identical. All three embedded guards
were executed. The receipt below records their actual outputs, including a
repaired diagnostic that initially compared nearest-rounded Decimal algebra
by exact equality; the rational coefficient identity is checked separately.
The English standalone LaTeX text is saved as .tex.txt, statically checked,
and was not compiled. No PDF was generated.

## Reloaded skill status

All 64 installed canonical entries and the 437 direct reference paths were
rehashed and checked. They match the Round63 snapshot and all references are
accessible. Current status/section listings were reread; active entries and
their method/interface/evidence files were reread by the researchers. Current
F05, N03, L03 and K04 entrances were also read in full by the parent. Earlier
full readings are retained only for identical entry hashes. This is not a
claim that all external literature was reread or that every skill theorem is
certified. Direct proofs below import no unverified external theorem.



# Round 64: the reweighting gap and an exact hereditary reduction

The optimized positive-cap cover has an arbitrarily large source-pairing relaxation gap for a fixed actual source. Nevertheless its full quadratic dual has exactly the same worst source-uniform normalized constant as bounded-density signed approximation on each source's true good set. This removes an extra reweighting constant, but does not estimate either constant. The general centered-cube weak bound remains unproved.

## Scope and current skills

Current B01, B04, M02 entrances and their method, cube-interface, and provenance files were reread; current F05 and L03 entrances, method, and cube-interface files were also reread. B01/M02 supply only the finite closed-cone certificate already proved in Round63. B04 supplies no infinite-dimensional minimax exchange here. The only exchanged operations below are two suprema. F05 keeps the signed Hilbert norm distinct from positive majorants; L03 governs the exact rational finite diagnostics. Following the latest reload request, the five current entrances and method files were reread again, and each current evidence index was parsed in full with its relevant certificate/source entries inspected. Current entrance SHA-256 prefixes are B01 `d32a083a86be`, B04 `70973b74e527`, M02 `0b60fbd91f77`, F05 `9b61d3e4cb62`, L03 `0e2d41f62f83`; corresponding index row counts are 106, 49, 40, 69, 44. These hashes are byte identities, not theorem certification. The index marks source-presence or pending baseline states; it does not replace provenance or direct proof. All new assertions below have direct proofs. No external source theorem is imported.

Let a finite positive atomic source be \(\mu=\sum_i p_i\delta_{y_i}\), with merged distinct sites, \(W=\mu(\mathbb R^n)>0\), and \(G_\mu=\{M\mu\le H\}\). Write \(A_u\nu=e^{-u}\nu(Q_u)\), where the centered cube \(Q_u(x)\) has side \(e^{u/n}\), and \(D\nu=A_{u+1}\nu-A_u\nu\). Set \(Y_G=L^2(G\times\mathbb R)\), \(T_GF=D_F|_G\), and
\[
 K_{\rho,W}=\{F\in L^2:0\le F\le\rho,\ \int F\le W\},\qquad \rho=\beta H>0.
\]
The retained spectral bound \(\|T_GF\|^2\le\kappa_n\|F\|_2^2\), \(\kappa_n\le3\log(n+2)/n\), is from Round57, not a new consequence of the skills.

Every atom column belongs to \(Y_{G_\mu}\): the cap gives \((2\|x-y_i\|_\infty)^n\ge p_i/H\) on \(G_\mu\); its exact point energy is \(c/v_i^2\), \(c=1-e^{-1}\), and radial integration gives \(\|D\delta_{y_i}\|^2_{G_\mu}\le cH/p_i\). Thus any reweighting on this support defines a continuous finite-dimensional map into this Hilbert space.

Use the exact Round63 capacity polytope
\[
 P_\mu=\{s\ge0:\ \sum_i s_i\le W,\quad
                 \sum_{i:y_i\in Q}s_i\le H|Q|\text{ for every cube centered in }G_\mu\}.
\]
Its finitely many membership-pattern constraints make it compact; \(p\in P_\mu\). It is useful to use physical source masses \(s_i\) rather than the normalized \(t_i=s_i/H\). If \(\mathcal C_\mu\) denotes Round63's normalized cover, then
\[
 H\mathcal C_\mu(w)=\max_{s\in P_\mu}\sum_i s_iw_i.
\]

## 1. Exact robust-distance interpretation

For \(s\in P_\mu\), let \(\nu_s=\sum_i s_i\delta_{y_i}\), discarding zero masses. Define
\[
 d_{G,W}(\nu)^2=\inf_{F\in K_{\beta H,W}}\|D\nu-T_GF\|_{Y_G}^2,
 \qquad R_\mu=\max_{s\in P_\mu}d_{G_\mu,W}(\nu_s)^2.
\]
The maximum exists. Indeed \(T_GK_{\rho,W}\) is a closed convex set: \(K\) is weakly compact in \(L^2\), since \(\|F\|_2^2\le\rho W\), positivity and the ceiling are weakly closed, and the integral constraint is the intersection of the weakly closed constraints \(\int_B F\le W\) over bounded sets \(B\). Its bounded linear image is weakly compact and hence norm closed. Distance to this image is continuous and convex in the source output. Therefore the maximum can be taken over the finitely many vertices of \(P_\mu\). This is an exact finite reduction, with no atom-number-independent bound on the number of vertices asserted.

For bounded compact receiver/time tests \(h\), set \(a=T_G^*h\) pointwise by the finite-time formula from Round63. Then exactly
\[
\boxed{R_\mu=\sup_{h,\lambda\ge0}
 \left\{2\max_{s\in P_\mu}\sum_i s_i a(y_i)-\|h\|^2
       -2\lambda W-2\beta H\int(a-\lambda)_+\right\}.}
\tag{2}
\]
Equivalently, its cover term is \(2H\mathcal C_\mu((a(y_i))_i)\), **without subtracting \(\lambda\) inside the cover**. A thresholded cover has a separate interpretation discussed below. This distinction is essential because the capacity polytope allows source mass strictly below \(W\).

To prove (2), for each fixed \(s\) apply the retained Hilbert projection dual, whose scalar target support function is
\[
 \sup_{F\in K_{\rho,W}}\int aF
 =\inf_{\lambda\ge0}\{\lambda W+\rho\int(a-\lambda)_+\}.
\]
Then exchange \(\sup_s\sup_{h,\lambda}\) with \(\sup_{h,\lambda}\sup_s\). This is a set-theoretic equality of suprema, not a minimax theorem. Compact finite tests suffice by density: source output pairing is continuous on the finite source-column span, and the target support function is \(\|T_G\|\sqrt{\rho W}\)-Lipschitz in \(h\). No arbitrary full-time atom evaluation is needed.

## 2. The thresholded cover: exact penalty, and a safe enlargement

Round63 proposed the sufficient estimate
\[
 \mathcal C_\mu((a_i-\lambda)_i)
 \le\beta\int(a-\lambda)_++\frac{\|h\|^2}{2H}+\frac{\varepsilon W}{2}.
\tag{3}
\]
Its supremum defect is
\[
 \widetilde R_\mu=\sup_{h,\lambda\ge0}
 \{2\max_{s\in P_\mu}\{\langle D\nu_s,h\rangle-\lambda\nu_s(\mathbb R^n)\}-\|h\|^2
        -2\rho\int(a-\lambda)_+\}.
\tag{4}
\]
For each fixed \(s\), the threshold multiplies that source's own mass, so (4) is exactly
\[
\boxed{\widetilde R_\mu=\max_{s\in P_\mu}
 d_{G_\mu,\,\nu_s(\mathbb R^n)}(\nu_s)^2.}
\tag{5}
\]
The own-budget distance is also convex and continuous on \(P_\mu\), so its maximum may likewise be taken at a vertex. Convexity follows by mixing two feasible targets: their blend has mass at most the mass of the blended source, preserves the ceiling, and squared signed norm is convex. For continuity at a nonzero mass \(m\), any fixed near-optimal target may be multiplied by \(\min(1,m_k/m)\) for nearby masses \(m_k\); this proves upper semicontinuity, while the dual supremum proves lower semicontinuity. At the zero source the bound by \(\|D\nu_s\|^2\to0\) suffices. This includes the zero source, whose distance is zero. In particular
\(d_{G_\mu,W}(\mu)^2\le R_\mu\le\widetilde R_\mu\).
Thus the actual Round63 thresholded-cover condition is a robust approximation problem with a **source-dependent exact mass budget**, not the common-budget robust problem in (2). Formula (5) eliminates this distinction correctly. Both versions have the same source-uniform constant below.

The formulation does not require an optimizer of exact target mass. Submass and exact-mass infima agree: if \(F\in K_{\rho,m}\) has deficit \(\delta=m-\int F\), let \(C_R=\int_{[-R,R]^n}(\rho-F)\to\infty\) and add \(g_R=\delta(\rho-F)\mathbf1_{[-R,R]^n}/C_R\). For \(C_R\ge\delta\), \(F+g_R\le\rho\), its mass is exactly \(m\), and \(\|g_R\|_2^2\le\rho\delta^2/C_R\to0\). Boundedness of \(T_G\) proves equality of infima.

## 3. Hereditary good sets remove the source-uniform reweighting loss

**Lemma.** Every \(s\in P_\mu\) satisfies \(G_\mu\subseteq G_{\nu_s}\).

**Proof.** At every \(x\in G_\mu\), all good-centered cube constraints in the definition of \(P_\mu\) give every average of \(\nu_s\) at \(x\) at most \(H\). Taking the supremum over all radii proves the inclusion, including the cap endpoint. No sampled-radius argument is involved.

Consequently, putting \(m_s=\nu_s(\mathbb R^n)\),
\[
 d_{G_\mu,W}(\nu_s)^2\le d_{G_\mu,m_s}(\nu_s)^2
       \le d_{G_{\nu_s},m_s}(\nu_s)^2.
\tag{6}
\]
The first inequality enlarges the target budget; the second restricts the receiver integral. Drop zero masses before using a theorem for positive finite sources.

**Theorem (exact worst-class equivalence).** Fix \(n\) and \(\beta>0\). Define, with suprema over all nonzero finite positive atomic sources and all \(H>0\),
\[
 S_{n,\beta}=\sup_{\mu,H}\frac{d_{G_\mu,W}(\mu)^2}{HW},\quad
 U_{n,\beta}=\sup_{\mu,H}\frac{R_\mu}{HW},\quad
 V_{n,\beta}=\sup_{\mu,H}\frac{\widetilde R_\mu}{HW}.
\]
Then as extended nonnegative numbers,
\[
\boxed{S_{n,\beta}=U_{n,\beta}=V_{n,\beta}.}
\tag{7}
\]
**Proof.** Original feasibility gives \(S\le U\le V\). For any alternative source of mass \(m_s>0\), (6) bounds its own-budget distance by \(S Hm_s\le SHW\). Taking the alternative-source maximum and then the original-source supremum gives \(V\le S\) when \(S<\infty\). If \(S=\infty\), the reverse inequality already forces all three to be infinite. The zero source contributes zero. The same argument can instead be stated pointwise: any uniform bound \(d_{G_\nu,m}(\nu)^2\le\varepsilon_n Hm\) for all finite positive \(\nu\) immediately proves (3) for every original \(\mu\), with exactly the same \(\varepsilon_n\).

This is a genuine elimination of a suspected extra relaxation loss, not an estimate for \(S_{n,\beta}\). It requires the general class of finite sources; a theorem only for a special family need not cover its reweightings. Neither depth nor atom number appears in (6)–(7). No source-uniform \(n^{o(1)}\) estimate is obtained.

## 4. Quantitative comparison with the unpaid cap energy

Define the actual normalized capped-energy constant
\[
 E_n=\sup_{\mu,H}\frac{\|D\mu\|_{Y_{G_\mu}}^2}{HW}.
\]
For a particular source and any feasible target, \(\|T_GF\|\le\sqrt{\kappa_n\beta HW}\). The reverse triangle inequality and the feasible target \(F=0\) give
\[
 \left(\sqrt{\|D\mu\|^2/(HW)}-\sqrt{\kappa_n\beta}\right)_+
 \le\sqrt{d_{G_\mu,W}(\mu)^2/(HW)}
 \le\sqrt{\|D\mu\|^2/(HW)}.
\]
Taking suprema, and using (7), proves
\[
\boxed{(\sqrt{E_n}-\sqrt{\kappa_n\beta})_+
       \le\sqrt{S_{n,\beta}}=\sqrt{U_{n,\beta}}=\sqrt{V_{n,\beta}}
       \le\sqrt{E_n}.}
\tag{9}
\]
Equivalently, \(E_n\le(\sqrt{V_{n,\beta}}+\sqrt{\kappa_n\beta})^2\). These are extended-value inequalities if a supremum is infinite. At \(\beta=n\), the known term is at most \(3\log(n+2)\). Thus a subpolynomial robust-cover bound would pay the cap-energy budget up to an explicit logarithmic term, and a subpolynomial cap-energy bound would pay the cover. The robust reformulation does not itself pay that budget.

## 5. An unbounded fixed-instance linear gap on actual cubes

Take dimension one, \(H=W=1\), \(0<\epsilon\le1/4\), \(\delta=\epsilon/4\), and
\[
 \mu_\epsilon=\epsilon\delta_0+(1-\epsilon)\delta_\delta.
\]
Its bad set is exactly \((\delta-1/2,1/2)\). Indeed intervals capturing both atoms have maximal average above one precisely on this interval; their minimal enclosing centered radius is \(\max(|x|,|x-\delta|)\). The single-atom bad intervals \((-\epsilon/2,\epsilon/2)\) and \((\delta-(1-\epsilon)/2,\delta+(1-\epsilon)/2)\) lie inside it. At source points use arbitrarily small positive radii, rather than a zero-radius average.

Both singleton capacities are exactly \(1-2\delta\); the both-atom capacity is one. For example, the left endpoint \(g=\delta-1/2\in G\) captures only zero at radius \(1/2-\delta\), while every good receiver has at least that distance to zero. Thus
\[
 P_\mu=\{s\ge0:s_0,s_1\le1-2\delta,\ s_0+s_1\le1\}.
\]
Set \(X=[g-\delta/8,g]\), \(L_-=1-\delta\), \(L_+=1-\delta/2\), and
\[
 h(x,u)=\mathbf1_X(x)\mathbf1_{[\log L_- -1,\log L_+-1]}(u).
\]
This is a bounded finite receiver/time test on true good receivers. Throughout its support, the enlarged cube's side \(e^{u+1}\in[L_-,L_+]\) captures zero and excludes \(\delta\): its largest required side for zero is \(1-7\delta/4<L_-\), and the smallest capture side for \(\delta\) is one. The original cube side \(e^u\le L_+/e\) captures neither atom; for instance \(e>2\) and \(\delta\le1/16\) already give the strict inequality. Hence
\[
 a(\delta)=0,\qquad a(0)=\frac\delta8\left(\frac1{L_-}-\frac1{L_+}\right)>0,
 \qquad \|h\|^2=\frac\delta8\log\frac{L_+}{L_-}.
\]
At threshold zero,
\[
 \frac{H\mathcal C_\mu((a(0),a(\delta)))}{\int a\,d\mu_\epsilon}
 =\frac{1-2\delta}{\epsilon}=\frac1\epsilon-\frac12\longrightarrow\infty.
\tag{8}
\]
Thus comparing an optimized positive cover to the actual source pairing test by test with a uniform multiplicative constant is impossible. This does not establish an unbounded ratio of the two optimized distances, and does not refute (3): the target hinge, quadratic defect, and alternative source's good set remain present in that statement. The theorem (7) proves precisely why this linear counterpressure is compatible with no extra worst-class loss.

## 6. What remains to be paid

The optimized thresholded cover is neither an automatically stronger general theorem nor a shortcut around signed approximation: it has exactly the worst-class constant of that approximation. A useful next proof must estimate one of these equivalent constants from actual cube geometry. Replacing (3) by a comparison to the original source pairing discards essential quadratic compensation, and (8) rules it out. The vertex reduction is finite and exact, but no uniform restriction on extreme-source geometry has been proved. The general weak-type objective remains open in this work.

## Executable diagnostics

The code below has three stages: exact all-center/all-radius one-dimensional capacities from the true bad-interval union; exact rational signed cube-feature projection and KKT checks on finite models; and Decimal refinement of the genuine finite-time counterexample. The finite features use \(A_{2L}-A_L\) at rational receiver/side pairs, with counting Hilbert measure. They are **not** a quadrature certificate for the continuous \(u\)-energy or for \(S_{n,\beta}\). They pressure-test the exact supremum/threshold/mass algebra with actual cube columns and positive target-cell columns. Fraction equalities certify these finite instances; Decimal comparisons are not outward-rounded intervals. Execution passed 72 exact counterexample geometry checks and all vertex/KKT/dual checks in the three finite models. Their vertex counts were 5, 8, 8. In model 1 the original, common-budget robust, and own-budget robust squared distances were respectively 0.69921875, 0.9833211762899263, 0.9842647923197492, confirming that the two robust budgets need not agree for a fixed instance. Decimal 80/140 refinement had maximum relative discrepancy \(4.269\times10^{-60}\); the displayed true-cube pairing ratio reached \(2^{64}-1/2\).

```python
from fractions import Fraction as F
from itertools import combinations
from decimal import Decimal as D, localcontext

def dot(a,b): return sum((x*y for x,y in zip(a,b)), F(0))

def solve(A,b):
    n=len(b); M=[list(r)+[v] for r,v in zip(A,b)]
    for j in range(n):
        k=next((k for k in range(j,n) if M[k][j]),None)
        if k is None: return None
        M[j],M[k]=M[k],M[j]
        c=M[j][j]; M[j]=[v/c for v in M[j]]
        for k in range(n):
            if k!=j:
                c=M[k][j]; M[k]=[a-c*b for a,b in zip(M[k],M[j])]
    return tuple(r[-1] for r in M)

def geometry(y,p):
    N=len(y); bad=[]
    for i in range(N):
        for j in range(i,N):
            m=sum(p[i:j+1]); a=y[j]-m/2; b=y[i]+m/2
            if a<b: bad.append((a,b))
    merged=[]
    for a,b in sorted(bad):
        if merged and a<merged[-1][1]:
            merged[-1]=(merged[-1][0],max(b,merged[-1][1]))
        else: merged.append((a,b))
    # Touching open bad components leave their common endpoint good.
    good=[]; left=None
    for a,b in merged: good.append((left,a)); left=b
    good.append((left,None))
    caps=[]
    for i in range(N):
        for j in range(i,N):
            lo=(y[i-1]+y[j])/2 if i else None
            hi=(y[i]+y[j+1])/2 if j+1<N else None
            middle=(y[i]+y[j])/2; values=[]
            for a,b in good:
                l=max(v for v in [lo,a] if v is not None) if lo is not None or a is not None else None
                r=min(v for v in [hi,b] if v is not None) if hi is not None or b is not None else None
                if l is not None and r is not None and l>r: continue
                if l==r and l is not None and (l==lo or l==hi): continue
                x=middle
                if l is not None: x=max(x,l)
                if r is not None: x=min(x,r)
                values.append(2*max(abs(x-y[i]),abs(x-y[j])))
            if values:
                row=tuple(F(int(i<=k<=j)) for k in range(N))
                caps.append((row,min(values)))
    return good,caps

def vertices(rows,N):
    result=set()
    for active in combinations(range(len(rows)),N):
        s=solve([rows[k][0] for k in active],[rows[k][1] for k in active])
        if s is not None and all(dot(a,s)<=b for a,b in rows): result.add(s)
    assert result
    return sorted(result)

def project(b,T,length,rho,W):
    # T is a list of target-cell output columns.
    m=len(T); Gram=[[dot(a,c) for c in T] for a in T]
    z=[dot(t,b) for t in T]; rows=[]
    for j in range(m):
        e=tuple(F(int(k==j)) for k in range(m))
        rows.extend([(tuple(-v for v in e),F(0)),(e,rho)])
    rows.append((tuple(length),W)); candidates=[]
    for count in range(m+1):
        for active in combinations(range(len(rows)),count):
            A=[rows[k][0] for k in active]
            M=[list(Gram[j])+[a[j] for a in A] for j in range(m)]
            M += [list(a)+[F(0)]*count for a in A]
            sol=solve(M,z+[rows[k][1] for k in active])
            if sol is None: continue
            f=sol[:m]; multip=sol[m:]
            if any(v<0 for v in multip) or any(dot(a,f)>v for a,v in rows): continue
            h=tuple(b[k]-sum(f[j]*T[j][k] for j in range(m)) for k in range(len(b)))
            lam=next((multip[j] for j,k in enumerate(active) if k==len(rows)-1),F(0))
            support=lam*W+sum(rho*length[j]*max(F(0),dot(T[j],h)/length[j]-lam) for j in range(m))
            assert support==sum(f[j]*dot(T[j],h) for j in range(m))
            assert 2*dot(b,h)-dot(h,h)-2*support==dot(h,h)
            candidates.append((dot(h,h),h,lam))
    assert candidates
    return min(candidates,key=lambda r:r[0])

def atom(y,x,L): return F(int(abs(x-y)<=L/2),1)/L
def cell(a,b,x,L): return max(F(0),min(b,x+L/2)-max(a,x-L/2))/L

checks=0
for eps in [F(1,2**k) for k in range(2,11)]:
    delta=eps/4; y=[F(0),delta]; p=[eps,1-eps]
    good,caps=geometry(y,p)
    assert good==[(None,delta-F(1,2)),(F(1,2),None)]
    assert dict((tuple(int(v) for v in row),c) for row,c in caps)=={(1,0):1-2*delta,(0,1):1-2*delta,(1,1):F(1)}
    g=delta-F(1,2); X=[g-delta/8,g]; Llo=1-delta; Lhi=1-delta/2
    for x in X:
        assert 2*abs(x)<Llo and 2*abs(x-delta)>Lhi
        assert Lhi/2<2*abs(x)  # e>2 certifies the smaller cube excludes zero
    assert (1-2*delta)/eps==1/eps-F(1,2)
    checks+=8
print('stage 1 exact counterexample checks:',checks)

cases=[([F(0),F(1,8)],[F(1,4),F(3,4)]),
       ([F(0),F(1,4),F(1,2)],[F(1,4),F(1,2),F(1,4)]),
       ([F(0),F(1),F(2)],[F(1,2),F(1),F(1,2)])]
for case,(y,p) in enumerate(cases):
    good,caps=geometry(y,p); N=len(y); W=sum(p)
    rows=caps+[(tuple(F(1) for _ in y),W)]
    rows += [(tuple(-F(int(j==i)) for j in range(N)),F(0)) for i in range(N)]
    V=vertices(rows,N)
    assert all(dot(a,p)<=b for a,b in rows)
    points=sorted(set(v for pair in good for v in pair if v is not None))
    points += [min(y)-2*W,max(y)+2*W]
    features=[(x,L) for x in points for L in [F(1,4),F(1,2),F(1),F(2),F(4),F(8)]]
    B=[tuple(atom(yi,x,2*L)-atom(yi,x,L) for x,L in features) for yi in y]
    edges=[min(y)-W,min(y),max(y),max(y)+W]
    if edges[1]==edges[2]: edges[2]+=F(1,10)
    length=[edges[j+1]-edges[j] for j in range(3)]
    T=[tuple(cell(edges[j],edges[j+1],x,2*L)-cell(edges[j],edges[j+1],x,L) for x,L in features) for j in range(3)]
    def output(s): return tuple(sum(s[i]*B[i][k] for i in range(N)) for k in range(len(features)))
    original=project(output(p),T,length,F(2),W)[0]
    evaluated=[(project(output(s),T,length,F(2),W),s) for s in V]
    (value,h,lam),s=max(evaluated,key=lambda r:r[0][0])
    a=[dot(b,h) for b in B]; cover=max(dot(v,a) for v in V)
    support=lam*W+sum(F(2)*length[j]*max(F(0),dot(T[j],h)/length[j]-lam) for j in range(3))
    assert 2*cover-dot(h,h)-2*support==value
    assert value>=original
    # The own-mass thresholded cover, unlike a double threshold, is exact.
    own=[(project(output(v),T,length,F(2),sum(v)),v) for v in V]
    (ov,oh,ol),os=max(own,key=lambda r:r[0][0])
    ac=[dot(b,oh)-ol for b in B]; oc=max(dot(v,ac) for v in V)
    hinge=sum(F(2)*length[j]*max(F(0),dot(T[j],oh)/length[j]-ol) for j in range(3))
    assert 2*oc-dot(oh,oh)-2*hinge==ov
    assert ov>=value
    print('stage 2 case',case,'vertices',len(V),'original',float(original),'common',float(value),'own',float(ov))

def decimal_run(precision):
    with localcontext() as ctx:
        ctx.prec=precision; data={}
        for k in [2,4,8,16,32,64]:
            eps=D(1)/(D(2)**k); delta=eps/4
            lo=1-delta; hi=1-delta/2
            a=delta/8*(1/lo-1/hi); norm=delta/8*(hi/lo).ln()
            ratio=(1-2*delta)/eps
            assert a>0 and norm>0
            assert ratio==1/eps-D('0.5')
            data[k]=(a,norm,ratio)
        return data
low=decimal_run(80); high=decimal_run(140)
with localcontext() as ctx:
    ctx.prec=160
    err=max(abs(low[k][j]-high[k][j])/max(abs(high[k][j]),D('1e-100')) for k in high for j in range(3))
    assert err<D('1e-50')
    print('stage 3 Decimal relative refinement:',err)
    print('pairing ratios:',[(k,str(high[k][2])) for k in high])
```


# Round 64: spatial obstacle interaction and the cancellation that must be paid

This note proves a new full-space off-diagonal kernel and its cube-annular cancellation, then gives an exact original-good-set decomposition for every finite positive atomic source. It does not construct a moving replacement with a uniform signed-error budget. The desired general weak bound remains unproved.

## Current skill scope

The currently installed E01, J03 and F05 entry, method, cube-interface, provenance and evidence-index files were reread on 2026-10-11 after the latest reload request. Entry SHA256 values are E01 0a5f11101bee3a6b8c0fbb960b5959e4cf78cfb6f011ac5d15f6add087286896, J03 3bb4b64402230c180105e1ba36a9ba617f1f35d28d567f033f04dbbf91ff801d and F05 9b61d3e4cb62f20394285d8b071cace85c44260f56329fdd5ec2b11066a52dc9.

Their applicable restrictions are retained: an occupation LP is not automatically a realizable moving process; exit mass requires finite exit and data on the whole complement; a Schur estimate requires both absolute margins on the stated spaces. No external partial-balayage, spectral multiplier, stochastic-exit or Schur theorem is invoked below. All proofs use actual centered-cube kernels, finite sums and explicitly justified integration. The new interface is a direct derivation, not a theorem inherited from a skill name or a cited paper.

## Normalization and absolute off-diagonal control

Set q=exp(1/n), c=1-exp(-1), u=n log L, and
k_L(x)=L^(-n) 1_{[-L/2,L/2]^n}(x), d_L=k_{qL}-k_L.
For h≠0 define
K_n(h)=∫_{R}∫_{R^n} d_L(x)d_L(x-h) dx du.

This double integral is absolutely convergent. Write a=||h||∞. The outer cubes do not intersect for qL<a; otherwise their intersection has volume at most (qL)^n=eL^n and |d_L|≤L^(-n). Consequently
∫du∫dx |d_L(x)d_L(x-h)| ≤ ∫_{a/q}^∞ eL^(-n) n dL/L = e²a^(-n).
This is a separated-pair bound, not an HW bound after arbitrary source summation.

K_n is even, invariant under coordinate sign changes/permutations, and homogeneous of degree -n. It need not be positive or radial. For a_j=|h_j|, A=(q+1)/2, and B=(q-1)/2, the exact overlap expression is
C_L(h):=∫d_L(x)d_L(x-h)dx
= L^(-2n){q^(-2n)∏(qL-a_j)_+ -2q^(-n)∏min[L,(AL-a_j)_+] +∏(L-a_j)_+}.
The mixed overlap is min[L,(AL-a_j)_+], including its full-overlap plateau. With v=1/L this gives
K_n(h)=n∫_0^{q/||h||∞} v^(n-1){q^(-2n)∏(q-a_jv)_+ -2q^(-n)∏min[1,(A-a_jv)_+] +∏(1-a_jv)_+}dv.
Each event interval has a polynomial integrand of degree at most 2n-1. All factors include the u=n log L normalization.

## Explicit signed angular structure

For t≠0,
K_n(te_1)=2|t|^(-n)/(n+1) [1-q^(-n)(A^(n+1)-B^(n+1))].
Indeed, the inner-inner and outer-outer scale integrals each equal |t|^(-n)/(n+1). The mixed overlap is (AL-|t|)_+-(BL-|t|)_+, giving the stated mixed integral.

The bracket vanishes for n=1. For n≥2 it is strictly positive: the mixed coefficient equals
2^(-n) Σ_{j odd} binom(n+1,j) q^(1-j).
Its coefficients sum to one; each term is ≤ its value at q=1, and at least the j=3 term is strictly smaller.

In particular,
K_1(h)=0 (h≠0),
K_2(t,0)=c/(6t²)>0,
K_2(t,t)=-(1-exp(-1/2))²/(6t²)<0.
For the diagonal formula, the same-scale integrals are 1/(6t²), while the mixed one is q^(-2)[B²+2B/3+1/6]/t². Thus the exact free interaction already has both signs in dimension two.

## Exact cube-annular cancellation; order of integration matters

For every 0<r<R,
∫_{r<||h||∞<R} K_n(h)dh=0.

Proof: C_L is supported on ||h||∞≤qL and its spatial integral is (∫d_L)^2=0. Define the ITERATED signed integral
F(R)=∫du [∫_{||h||∞<R} C_L(h)dh].
The inner integral is exactly zero for L<R/q. For L≥R/q it is bounded in absolute value by (2R)^n eL^(-n), so F(R) exists. Scaling C_L(h)=L^(-n)C_1(h/L), followed by L=Rt, shows F(R)=F(1). On the separated annulus the preceding e²||h||∞^(-n) bound permits Fubini, hence its integral is F(R)-F(r)=0.

This does NOT justify exchanging integrals on the ball containing h=0. In fact ∫du∫_{||h||∞<R}|C_L(h)|dh diverges as L→0, since for sufficiently small L the entire support is in the ball and ∫|C_L|dh is a strictly positive scale-invariant constant. The annular claim is an ordinary absolutely convergent integral on each separated annulus, not an assertion of absolute integrability at the diagonal.

## Exact original-obstacle decomposition for arbitrary finite atoms

Let μ=Σ_i p_i δ_{y_i}, p_i>0, with distinct y_i (combine coincident atoms), W=Σ_i p_i, H>0,
G={Mμ≤H}, Ω={Mμ>H}.
Use the original μ to define both sets. For distinct indices define
K_Ω(y_i,y_j)=∫_Ω∫du d_L(x-y_i)d_L(x-y_j)dx.
Absolute convergence follows from the separated-pair estimate, even if Ω contains the source poles. Thus K_G(y_i,y_j)=K_n(y_i-y_j)-K_Ω(y_i,y_j) exactly.

For v_i(x)=(2||x-y_i||∞)^n, the one-source time integral is
∫du |d_L(x-y_i)|²=c/v_i(x)².
To check it directly, the coefficient is 1/(ev) on v∈[v_i/e,v_i) and -c/v on v≥v_i, where v=L^n=e^u. Integration with du=dv/v gives c/v_i².

For x∈G, p_i/v_i(x)≤H. Since |{x:v_i(x)<s}|=s, the diagonal term
T_G=cΣ_i p_i²∫_G v_i(x)^(-2)dx ≤ cHW.
The exact energy identity, including every mixed term, is
E_G(μ)=T_G+B_free-B_bad,
B_free=Σ_{i≠j}p_ip_jK_n(y_i-y_j),
B_bad=Σ_{i≠j}p_ip_jK_Ω(y_i,y_j).

A concrete remaining all-source estimate is
B_bad ≥ B_free - A_n HW.                         (OB)
If (OB) holds with A_n bounded by a power of log(n+2), then E_G≤(c+A_n)HW. No such bound is proved here. It is an original-obstacle mixed-interaction lower bound relative to an explicit signed homogeneous free kernel. It asks for cancellation; bounding either displayed interaction separately by its absolute size is invalid. Annular cancellation offers structure but the cap-defined Ω destroys unrestricted angular averaging. This is not an independent-coordinate, Gram-orthogonality or pairwise-positivity assumption.

## Analytic near-coincident pressure: separate payments are impossible

In n=2 fix p,H>0 and μ_t=pδ_0+pδ_{te_1}. Then W=2p and
B_free=c p²/(3t²).
Cauchy-Schwarz for two source profiles gives 0≤E_G≤2T_G≤2cHW. Since B_bad-B_free=T_G-E_G, therefore
|B_bad-B_free|≤T_G≤cHW.
As t→0 the two separate interactions diverge positively like c p²/(3t²), while their difference stays bounded by a constant times HW. In particular B_bad/B_free→1. This is a rigorous pressure test on any argument that charges free and obstacle interactions separately; the two-source upper bound is used only to establish this pressure, not as a general-source closure.

For μ_t=pδ_0+pδ_{(t,t)}, instead
B_free=-p²(1-exp(-1/2))²/(3t²).
The same bound holds, so B_bad follows a negatively divergent free term with an O(HW) discrepancy. Both signs matter.

## Signed moving errors: what has and has not advanced

For a finite receiver set and a finite scale window, a redistribution sequence μ_0,...,μ_J has increment profiles V_j=D(μ_{j-1}-μ_j). Its full error is ΣV_j and
||ΣV_j||²=Σ||V_j||²+2Σ_{j<k}⟨V_j,V_k⟩.
The exact multistage guard below tests these mixed terms, source conservation, and an ORIGINAL-source cap gate. It exhibits a loop whose nonzero stage payments cancel completely in the final error. Thus stagewise positive payment is generally wasteful.

The spatial off-diagonal formula above is all-time and Lebesgue-exact for distinct atomic pairs. It cannot be inserted without qualification into an arbitrary μ-F calculation: integrating |y-z|^(-n) against an atom and a density near that atom can diverge logarithmically. Such extensions need a diagonal subtraction/principal-value formulation or regularization, followed by a proved limiting argument. No full signed moving replacement, bounded total target density, or uniform aggregate payment is obtained in this note. This is the remaining obstacle, not the existence of a bounded target alone.

## Reproducible guard and evidentiary scope

The following standalone standard-library program checks:
(1) actual q=exp(1/n) overlap kernels against the axis formula in n=1,...,8, both n=2 signs, and homogeneity on deterministic non-axis directions;
(2) cube-annular angular cancellation in n=2 by successively refined Simpson quadrature;
(3) exact Fraction multistage Gram identities, conservation, and original cap gates for rational q=3/2, n=2, finite volume window [1/64,64] and a specified finite receiver lattice. The rational ratio is an algebraic shape check, not an e-step certificate. The receiver lattice is not a Lebesgue approximation certificate.
Floating checks are finite evidence; no interval or general-budget claim is made.

```python

from fractions import Fraction as F
from math import exp, comb, fsum
import json

def mul(p, q):
    out=[0.0]*(len(p)+len(q)-1)
    for i,a in enumerate(p):
        for j,b in enumerate(q): out[i+j]+=a*b
    return out

def free_kernel(h):
    n=len(h); q=exp(1/n); A=(q+1)/2; B=(q-1)/2
    a=[abs(x) for x in h]; maximum=max(a)
    assert maximum>0
    end=q/maximum
    knots={0.0,end}
    for x in a:
        if x:
            for z in (q,1.0,A,B):
                v=z/x
                if 0<v<end: knots.add(v)
    knots=sorted(knots); total=[]
    for lo,hi in zip(knots,knots[1:]):
        mid=(lo+hi)/2; terms=[]
        for kind,coef in ((0,q**(-2*n)),(1,-2*q**(-n)),(2,1.0)):
            poly=[coef]
            for x in a:
                if kind==0: f=[q,-x] if q-x*mid>0 else [0.0]
                elif kind==2: f=[1.0,-x] if 1-x*mid>0 else [0.0]
                else:
                    value=A-x*mid
                    f=[1.0] if value>=1 else ([A,-x] if value>0 else [0.0])
                poly=mul(poly,f)
            terms.extend(n*b*(hi**(n+i)-lo**(n+i))/(n+i) for i,b in enumerate(poly))
        total.append(fsum(terms))
    return fsum(total)

def axis(n):
    q=exp(1/n); A=(q+1)/2; B=(q-1)/2
    return 2/(n+1)*(1-q**(-n)*(A**(n+1)-B**(n+1)))

def simpson(N):
    vals=[free_kernel((1.0,j/N)) for j in range(N+1)]
    return 8*(vals[0]+vals[-1]+4*fsum(vals[1:-1:2])+2*fsum(vals[2:-1:2]))/(3*N)

# Exact pointwise time Gram on v=L^n in a finite volume window.
# Each profile is coeff/v; integrate du=dv/v on event intervals.
def gram_at(receiver, points, Q=F(9,4), low=F(1,64), high=F(64)):
    n=2
    captures=[(2*max(abs(receiver[j]-y[j]) for j in range(n)))**n for y in points]
    knots=sorted({low,high}|{z for a in captures for z in (a/Q,a) if low<z<high})
    matrix=[[F(0) for y in points] for z in points]
    for lo,hi in zip(knots,knots[1:]):
        mid=(lo+hi)/2
        coef=[F(0) if mid<a/Q else (1/Q if mid<a else -(1-1/Q)) for a in captures]
        weight=(1/lo**2-1/hi**2)/2
        for i in range(len(points)):
            for j in range(len(points)): matrix[i][j]+=weight*coef[i]*coef[j]
    return matrix

def true_good(x, points, weights, H):
    radii=sorted({max(abs(x[j]-y[j]) for j in range(2)) for y,w in zip(points,weights) if w})
    for r in radii:
        mass=sum(w for y,w in zip(points,weights) if max(abs(x[j]-y[j]) for j in range(2))<=r)
        if r==0 or mass>H*(2*r)**2: return False
    return True

def dot(v, K, w):
    return sum(v[i]*K[i][j]*w[j] for i in range(len(v)) for j in range(len(w)))

def run_guard():
    errors=[]
    for n in range(1,9):
        h=(1.0,)+(0.0,)*(n-1)
        errors.append(abs(free_kernel(h)-axis(n)))
    c=1-exp(-1)
    errors.extend([abs(free_kernel((1.,0.))-c/6),
                   abs(free_kernel((1.,1.))+(1-exp(-.5))**2/6)])
    scaling=[]
    for n in range(2,7):
        h=tuple(1.0 if j==0 else ((j*7)%11+1)/13 for j in range(n))
        k=free_kernel(h)
        for t in (0.5,1.5,3.0):
            scaling.append(abs(free_kernel(tuple(t*x for x in h))*t**n-k))
    angular=[simpson(N) for N in (256,1024,4096)]
    assert max(errors)<2e-10 and max(scaling)<2e-10
    assert abs(angular[-1])<2e-7

    points=[tuple(F(z) for z in y) for y in
            ((0,0),(1,0),(0,1),(1,1),(2,0),(-1,1))]
    original=list(map(F,(1,2,1,1,0,0))); H=F(2)
    states=[original,
            list(map(F,(0,2,1,1,1,0))),
            list(map(F,(0,1,1,1,1,1))),
            list(map(F,(1,1,1,1,0,1))),
            original]
    increments=[[a-b for a,b in zip(old,new)] for old,new in zip(states,states[1:])]
    assert all(sum(s)==5 and all(x>=0 for x in s) for s in states)
    assert all(sum(v)==0 for v in increments)
    receivers=[(F(i,2),F(j,2)) for i in range(-4,7) for j in range(-3,6)]
    matrices=[[[F(0) for p in points] for p in points] for z in range(3)]
    counts=[0,0]
    for x in receivers:
        K=gram_at(x,points)
        good=true_good(x,points,original,H)
        counts[int(good)]+=1
        for i in range(len(points)):
            for j in range(len(points)):
                matrices[0][i][j]+=K[i][j]
                matrices[1 if good else 2][i][j]+=K[i][j]
    checks=0; worst_positive=F(0); worst_negative=F(0)
    for K in matrices:
        for i in range(len(points)):
            for j in range(len(points)):
                assert matrices[0][i][j]==matrices[1][i][j]+matrices[2][i][j]
                checks+=1
        # All prefixes, including a nontrivial closed redistribution loop.
        for length in range(1,len(increments)+1):
            selected=increments[:length]
            aggregate=[sum(v[i] for v in selected) for i in range(len(points))]
            diag=sum(dot(v,K,v) for v in selected)
            mixed=2*sum(dot(selected[i],K,selected[j])
                        for i in range(length) for j in range(i+1,length))
            energy=dot(aggregate,K,aggregate)
            assert energy==diag+mixed and energy>=0 and diag>=0
            checks+=1
            worst_positive=max(worst_positive,mixed)
            worst_negative=min(worst_negative,mixed)
            if length==len(increments): assert energy==0 and diag>0 and mixed==-diag
    pressure=[]
    for denominator in (1,2,8,64,512):
        t=F(1,denominator)
        # Exact geometric factor; c remains transcendental.
        pressure.append({"t":str(t),"axis_Bfree_over_c_p2":str(1/(3*t*t))})
    return {"scope":"finite exact Gram/gate checks; floating kernel checks",
            "axis_and_sign_max_abs_error":max(errors),
            "homogeneity_max_abs_error":max(scaling),
            "n2_boundary_integrals_N256_1024_4096":angular,
            "exact_rational_checks":checks,
            "original_bad_good_receiver_counts":counts,
            "largest_positive_multistage_mixed":str(worst_positive),
            "smallest_negative_multistage_mixed":str(worst_negative),
            "closed_loop_final_energy":"0; positive stage cost canceled exactly",
            "near_coincident_axis_pressure":pressure}

if __name__=="__main__":
    print(json.dumps(run_guard(),sort_keys=True))
```

## Actual replay summary

The embedded program completed locally in under one second using the standard Python interpreter. It passed 120 exact Fraction equality/nonnegativity checks on three receiver Gram matrices (all, original good, original bad), four successive conserved redistributions, and every prefix. There were 90 good and 9 bad receiver sites. The largest positive mixed contribution was 6725/2916 and the smallest negative one was -4568271014673841/896168448000. The complete closed loop had zero final error and strictly positive diagonal stage payment, canceled exactly by its mixed terms.

Actual-q axis/sign discrepancy was 4.718447854656915e-16 and homogeneity discrepancy was 1.5421691701433815e-15. The n=2 boundary integrals at Simpson resolutions 256,1024,4096 were respectively 4.4158194519953547e-10, 3.117400940976419e-12, 1.311740971919606e-14. These are ordinary floating observations, not interval certificates. The analytic annular proof supplies the general assertion.


# A source-adapted all-space receiver proposal

This is a numerical integration tool for arbitrary finite positive sources, not a dimension-only cap-energy theorem. Its exact envelope improves the imbalance-sensitive envelope of the global-volume proposal. It retains Lebesgue receivers, all scales, original good receivers, and all source correlations.

Let $\mu=\sum_{i=1}^N p_i\delta_{y_i}$ have distinct sites, positive masses, total mass $W$, and threshold $H>0$. Put $v_i(x)=(2\|x-y_i\|_\infty)^n$, $V_i=p_i/H$, and $G=\{M\mu\le H\}$. The normalized log-volume increment is $D\mu(x,u)=A_{u+1}\mu(x)-A_u\mu(x)$, and $c=1-e^{-1}$.

For any $V>0$, define the radial-volume density
\[
 r_V(v)=\frac{1}{2V}\mathbf1_{0<v\le V}+\frac{V}{2v^2}\mathbf1_{v>V}.
\]
Each piece has integral one half. To sample the spatial density $q_{i,V}(x)=r_V(v_i(x))$, select a cube face uniformly among the $2n$ faces, choose its other $n-1$ normalized coordinates uniformly in $[-1,1]$, and independently choose volume $v$ with density $r_V$. Scale this face point by $v^{1/n}/2$ and translate by $y_i$. The normalized cone measure $d\sigma$ satisfies $dx=dv\,d\sigma$: integrating the angular Jacobian gives derivative one of the cube volume $v$. Equivalently $v=VU$ or $V/U$ with equal probabilities and an independent uniform $U\in(0,1)$. This proves the full-space proposal with no box truncation.

Use the individual-mass proposal
\[
 q_{\rm ind}(x)=\sum_i\frac{p_i}{W}r_{V_i}(v_i(x)).
\]
Every receiver in $G$ satisfies $v_i\ge V_i$, since its centered cube capturing atom $i$ has average at least $p_i/v_i$. The two branches agree at equality. Thus on the ORIGINAL good set,
\[
 q_{\rm ind}(x)=\frac{1}{2HW}\sum_i\frac{p_i^2}{v_i(x)^2}.
\tag{P1}
\]
The single-column all-time identity is
\[
 \int_{\mathbb R}|D(p_i\delta_{y_i})(x,u)|^2\,du=c\,p_i^2/v_i(x)^2.
\]
Indeed before $u=\log v_i-1$ the column is zero; on the next unit interval it equals $p_i e^{-u-1}$; thereafter it equals $-c p_i e^{-u}$. Integrating their two squared exponentials gives $c p_i^2/v_i^2$.

Writing $E(x)=\int|D\mu(x,u)|^2du$, Hilbert Cauchy--Schwarz gives
\[
 0\le E(x)\le cN\sum_i p_i^2/v_i(x)^2.
\]
Consequently the exact importance score has the deterministic envelope
\[
 Z_{\rm ind}(x)=\frac{\mathbf1_G(x)E(x)}{HWq_{\rm ind}(x)}\in[0,2cN],
 \qquad \mathbb E_{q_{\rm ind}}Z_{\rm ind}=\frac{1}{HW}\int_GE(x)\,dx.
\tag{P2}
\]
No small-mass factor $W/p_{\min}$ remains. The density is strictly positive at every finite receiver. Null source sites may be assigned score zero and do not affect the integral. The proof applies to all finite sources and dimensions; it does not assume atom locations or coordinates independent. Coincident sites should be merged before counting $N$.

For the global-volume proposal $q_{\rm glob}=\sum_i(p_i/W)r_{W/H}(v_i)$, use any fixed mixture
$q_\alpha=\alpha q_{\rm glob}+(1-\alpha)q_{\rm ind}$ with $0\le\alpha<1$. Always evaluate this FULL density, including all source centers and both branches. Since $q_\alpha\ge(1-\alpha)q_{\rm ind}$, its exact score is bounded by $2cN/(1-\alpha)$. At $\alpha=1/2$ this is $4cN$. The global part can retain sampling efficiency for highly clustered sources; no variance reduction for every source is claimed.

For $m$ iid ideal continuous draws, Hoeffding therefore gives the two-sided failure probability at most $\delta$ for radius
\[
 \frac{2cN}{1-\alpha}\sqrt{\frac{\log(2/\delta)}{2m}}.
\tag{P3}
\]
This is a finite-sample source-dependent certificate in exact arithmetic, not a dimension-uniform mathematical bound on the integral. It does not certify pseudorandom generators, floating point transforms, or rounding in the gate and energy. Decimal refinement is separately reported and is not outward-rounded interval arithmetic. A simultaneous statement for $K$ separately inspected estimates would require e.g. replacing $\delta$ by $\delta/K$.

The pre-existing global proposal bound was $2cNW/p_{\min}$. The improvement above is algebraic and holds for unequal masses without extrapolating numerical orders. The mass-normalized proposal alone can still be inefficient when many nearby atoms act as one cluster; the new independent refinement stage compares it to the original proposal; the mixed proposal is proved here but not sampled in this round. Finite observations cannot establish a uniform cap-energy budget, and no large energy score is a weak-type counterexample.


## Exact two-vertex calibration; the one-atom value is not universal

This calculation tests and refutes the proposed stronger constant $c$, not the general dimension target. In dimension one take $\mu=4\delta_{-1}+4\delta_1$, $H=1$, $W=8$. The original good set is exactly $G=\mathbb R\setminus(-3,3)$. For $|x|<3$ the cube capturing both atoms has average $4/(|x|+1)>1$; for $x\ge3$ both the single-near-atom average $2/(x-1)$ and the both-atom average $4/(x+1)$ are at most one, and reflection covers $x\le-3$.

For $x\ge3$, the arrival volumes are $v_-=2(x-1)$ and $v_+=2(x+1)$, and $v_+/v_-\le2<e$. Direct integration of the two step-exponential columns gives, for $v\le w\le ev$,
\[
 K(v,w)=\frac{2-e^{-1}-e^{-1}(w/v)^2}{2w^2}.
\]
Using the two diagonal terms $16c/v_-^2+16c/v_+^2$ and the complete mixed term $32K(v_-,v_+)$, the point energy is
\[
 E(x)=4\left[\frac{1-2/e}{(x-1)^2}+\frac{3-2/e}{(x+1)^2}\right].
\]
Reflection and $\int_3^\infty(x-1)^{-2}dx=1/2$, $\int_3^\infty(x+1)^{-2}dx=1/4$ yield
\[
 \frac{E_G}{HW}=\frac{10-12/e}{8}=\frac{5-6/e}{4}
 =0.6981808382428365\ldots,
 \qquad \frac{E_G}{HW}-c=\frac{e-2}{4e}>0.
\]
Thus the numerical two-vertex comparator has a second exact reference, beyond the one-atom calibration. Both references use all receiver space and all times. This strict difference is a proof from explicit integration, not a statistical significance claim.


### Executable analytic-calibration guard

```python
from decimal import Decimal as D, localcontext
from fractions import Fraction as F
from math import exp, fsum
assert 2*(F(1,2)+3*F(1,4))==F(5,2)
assert 2*(-2*F(1,2)-2*F(1,4))==-3
# The preceding coefficients are for E_G/4; dividing by 2 gives E_G/8.
assert F(5,4)-1==F(1,4) and -F(6,4)+1==-F(1,2)
values=[]
for precision in (80,140):
    with localcontext() as ctx:
        ctx.prec=precision;e=D(1).exp();q=1/e
        exact=(5-6*q)/4
        assert abs((exact-(1-q))-(1-2*q)/4)<D(10)**(-precision+3)
        assert exact>1-q
        for x in (D(3),D('3.5'),D(4),D(8),D(64)):
            v,w=2*(x-1),2*(x+1)
            events={v/e:4/e,w/e:4/e,v:D(-4),w:D(-4)}
            knots=sorted(events);coef=D(0);energy=D(0)
            for j,t in enumerate(knots):
                coef+=events[t]
                energy+=coef**2/2*(t**-2-(knots[j+1]**-2 if j+1<len(knots) else 0))
            formula=4*((1-2*q)/(x-1)**2+(3-2*q)/(x+1)**2)
            assert abs(energy-formula)<D(10)**(-precision+8)
        values.append(exact)
q=exp(-1);refinements=[]
for N in (16,64,256):
    dt=.5/N
    f=[(1-2*q)+(3-2*q)/(1+2*j*dt)**2 for j in range(N+1)]
    s=dt*(f[0]+f[-1]+4*fsum(f[1:-1:2])+2*fsum(f[2:-1:2]))/3
    refinements.append(s)
assert abs(refinements[-1]-float(values[-1]))<1e-10
print('exact normalized two-atom cap energy:',values[-1])
print('Simpson16/64/256:',refinements)
print('Decimal80/140 point-event/formula checks: PASS; not interval arithmetic')
```


# Round64: arbitrary positive finite-source cap energy

The fixed experiments compute the actual all-space Lebesgue receiver integral

\[
 E_H/(HW)=\frac1{HW}\int_{M\mu\le H}\int_{\mathbb R}|A_{e^{1/n}L}\mu-A_L\mu|^2\,du\,dx,
 \qquad u=n\log L,
\]

for positive finite atomic sources. The main matrix changes dimension and source count independently. It is a finite numerical pressure test of this energy criterion, not a general upper bound or a weak-type counterexample.

## Run and scope

Run without `--pilot`:

```sh
/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 -B general_cap_probe.py
```

The self-contained script writes `results.json` beside itself; Python3.12.14 and NumPy2.3.5 were used. The final measured run took3.673316 seconds. Timing is printed and omitted from JSON to allow byte-identical replays. No package was installed.

The 36-case pilot used9216 receivers. The final282 source/threshold/seed rows used1,130,496 receivers, with81920 further receivers in10 one-atom calibrations. The total is1,221,632 receivers. The main matrix has240 rows: four families, dimensions1,2,4,8,16, requested counts2,4,8,16,32,64, two independent seeds,2048 receivers per row. Actual coincident positions are merged before all calculations. Three families retain each requested count exactly. In the dyadic unequal cloud, dimension1 requested32 and64 merge to actual30 and62; those actual counts, weights and coordinates are recorded. These are genuine positive sources, not arrival-count proxy models.

The families are an equally weighted correlated diagonal, two separated small clusters, equally weighted positions at nested scales2^{-j}, and a dyadic random cloud with unequal weights proportional to(j+1)^2. Eighteen further nested-source rows vary H=4,16,256 at(n,N)=(1,16),(4,32),(16,64). Twelve explicit vertex rows have n=1,...,6, N=2^n, atom mass4^n and W=8^n; these coupled comparators do not replace the independent main matrix. Six global-proposal heldout refinements and six individual-mass-proposal comparisons use32768 receivers each at(n,N)=(8,64),(16,32),(16,64). These three configurations were selected after the initial matrix showed high sampling variance. Their fresh seeds and estimates are recorded separately, without pooling selection data into the heldout estimates.

## Actual arrival and time formulas

Put a_i=p_i/W, V=W/H and tau_i=(2||x-y_i||_infinity)^n/V. The true all-scale cap is

\[
 M\mu(x)/H=\max_{\text{full arrival batches }j}\frac{\sum_{\tau_i\le\tau_j}a_i}{\tau_j}.
\]

Sorting partial cumulative sums at equal volumes gives the same maximum because the last positive-mass member of a tied group has its largest cumulative mass. The event code places +a_i/e at t=tau_i/e and -a_i at t=tau_i. On each open event interval the signed increment equals H C/t; its time integral is C^2(t_left^{-2}-t_right^{-2})/2. The final infinite interval is included. Equal events have zero interval length; the coefficient on the following positive-length interval contains the whole batch. There is no scale mesh or time truncation. Complete cross terms are retained.

The source diagonal is also recorded, with contribution(1-e^{-1})sum a_i^2/tau_i^2 on each accepted receiver. It need not equal total energy: at n16,N64 the small-cluster diagonal means are.0217/.0226 while total means are.6104/.6344; nested diagonal means.0284/.0304 accompany total means.5995/.5929. For the unequal cloud the diagonal nearly equals the total. These finite differences identify mixed-term behavior; they provide no general sign or absolute-budget estimate.

## Full-space proposals and bounds

For any center and radial volume parameter B>0 use

\[
 q_B(v)=\begin{cases}1/(2B),&v\le B,\\B/(2v^2),&v>B.\end{cases}
\]

Each half integrates to1/2 against dv. Uniform cube cones satisfy dx=dv d sigma: the face and sign are uniform, and each free coordinate is uniform[-1,1]. The selected center has probability p_i/W. The sampler chooses each radial branch with probability1/2, then v=B U or B/U. Machine U=0 is replaced by the next positive float; this endpoint convention is explicit, and no receiver box is imposed.

The first proposal uses B=V at every source center. Its FULL density is the sum over all centers, not the density of the sampled center. In normalized units q=(H/W)qcore with

\[
 qcore=\tfrac12\sum_i a_i\min(1,\tau_i^{-2}).
\]

The second proposal uses B_i=p_i/H=Va_i. Its complete density, including inside components, is

\[
 qcore=\tfrac12\sum_i\min(1,(a_i/\tau_i)^2).
\]

On the actual cap every tau_i>=a_i, so this equals(1/2)sum a_i^2/tau_i^2. Both proposals score the same integral using 1_G Ecore/qcore, where Epoint=H^2 Ecore. The individual proposal materially reduces variance on the tested unequal clouds.

A finite pointwise envelope follows from Hilbert Cauchy: Epoint<=cN sum p_i^2/v_i^2, c=1-e^{-1}. For the individual proposal the normalized score is at most2cN. For the global proposal, each diagonal term divided by its corresponding mixture-density term is at most2W/pmin on G; hence score<=2cN W/pmin. The program checks these analytic envelopes on its samples and reports B sqrt(log40/(2S)), the formal two-sided95% Hoeffding radius for independent ideal continuous-proposal scores. This is a per-row statement, not a simultaneous bound, and does not certify machine transform or integration bias. Even the improved radii remain far wider than sample SE.

## Findings and remaining uncertainty

All282 final estimates range from.300766 to.727820. The initial largest value is the unequal cloud n16,N64,.727820 with SE.122397; the other initial seed gives.685450 with SE.072385. These are noisy observations. Independent refinement and proposal comparison give:

| n,N | global means ± sample SE | individual-mass means ± sample SE |
|---|---|---|
|8,64|.546998±.010293; .559126±.009868|.554297±.003689; .555399±.003681|
|16,32|.604829±.012180; .633203±.013833|.631185±.003497; .637138±.003500|
|16,64|.674966±.025068; .612131±.017914|.624143±.003505; .625525±.003506|

At n16,N64 the global refinements have energy ESS709/1127 and top1% contribution45%/43%; the individual proposal has ESS16118/16147 and top1% contribution2.54%/2.55%. Its cap acceptance is49.3%/49.4%, versus98.4%/98.3% for the global proposal. The respective maximum observed scores are469.94/131.18 and2.579/2.854. Acceptance rate alone is not a variance diagnostic. The individual proposal's formal Hoeffding radius is.60704 for N64 and.30352 for N32, still too wide to substantiate a sharp continuous energy bound.

Nested-source H pressure gives means.580869–.629807, SE.00675–.01506. Increasing the threshold in these particular finite sources exposes additional scales but shows no large observed energy. The n1 two-vertex estimates.702433±.006159 and.698896±.006186 exceed the one-atom baseline c=.63212056; the baseline is not a universal energy upper bound. The larger-dimensional vertex comparisons remain finite-family observations. No dimension or source-count exponent was fitted. These calculations establish neither source-independent boundedness nor absence of rare growth. A large energy would also require a separate argument before implying a weak-type lower bound.

## Arithmetic guards and audit boundary

There are564 closest accepted/rejected gate receivers, retained with their full coordinates, sampled component and float log maximal margin. Decimal80/120 actual-source maxima agree with every retained float classification. The smallest recorded absolute log margin is7.245467e-7. This checks selected borderline samples; it does not certify every receiver gate by outward intervals.

Thirty largest-score receivers are checked independently for each dimension/proposal combination. The full tied-event energy is compared with the signed pair Gram kernel at80/120 digits. Maximum float energy relative error is1.987373e-15, full proposal-density relative error1.347036e-15, energy precision-change relative error3.239691e-78, and Decimal120 event/Gram relative discrepancy1.286809e-118. The guards include the global score469.94 and the largest individual-proposal scores. Twenty one-atom point checks and three actual common-face tie checks are also retained. The tied n2 source has unequal masses1/3,2/3 and distinct positions sharing a coordinate; its equal arrival is valid on an open receiver region.

The single-atom identity E_H/(HW)=c holds analytically in every dimension and mass/height. Under this no-hole proposal its score is0 or2c with equal ideal probability, hence mean c and variance c^2. The ten8192-draw calibrations range.615916–.646164 with SE about.00698; all observed top scores agree with2c within1e-12. This calibrates units, volume Jacobian, time energy and importance density; it is not evidence for a many-source upper bound.

Current L01/L02/L03/H05 SKILL entries, method/interface files and evidence metadata were reloaded for this work. The relevant constraints are: real common sources rather than feasible proxy parameters; no unproved discrete-to-continuous transfer; nearest Decimal agreement is not an outward-rounded certificate; and Hoeffding requires an actual independent-score range. No unreviewed paper theorem is used. Machine source coordinates and retained machine receivers are interpreted exactly in the Decimal comparisons, while weights are the recorded positive rational masses. The ideal continuous sampler is unbiased; finite pseudorandom machine sampling and transforms are not interval-certified. The spatial uncertainty is therefore sampling uncertainty, rather than a box-tail or a spatial-mesh error.


## Exact remaining budget and its limits

Let A_n be the supremum over all nonzero finite positive sources and H>0 of
(B_free-B_bad)/(HW). It is nonnegative because a single atom has no mixed
term. The exact identity E_G=T_G+B_free-B_bad and 0<=T_G<=cHW give

    E_n-c <= A_n <= E_n,       c=1-exp(-1).

Thus a source-uniform subpower bound for the mixed obstacle payment and a
source-uniform subpower bound for the original cap energy are equivalent up
to this additive constant. This explicitly exposes rather than resolves the
remaining challenge. The new information is the exact free kernel, its signs,
annular cancellation and necessary cancellation with the bad-set term.
Annular symmetry cannot be imposed on the cap-defined bad set.

At target ceiling beta H with beta=n, the retained spectral contribution is
kappa_n beta <=3 log(n+2). The proved comparison shows that the optimized
thresholded cover and bounded-density signed projection have precisely the
same worst source-uniform constant, and the cap energy differs only by the
displayed square-root comparison. None has been bounded by n^{o(1)} here.
The final weak-type and all-scale return must use an actually proved budget;
these equivalences alone do not prove it. No atom-count, depth, smallest-mass
or finite-scale dependence may be hidden in an absolute constant.

The next general task is to exploit original-source cap geometry in the
JOINT free-minus-obstacle interaction, or to construct a different stopped
mass budget that avoids this stronger energy criterion. An unrestricted
atom-density kernel substitution near the diagonal is not justified, and
separate positive payments contradict the near-coincident pressure test.
The original goal remains active.

## Actual independent replay receipt

```json
{
  "embedded": {
    "moving_obstacle.md": {
      "exit_code": 0,
      "seconds": 0.1333797080005752,
      "stderr": "",
      "stdout": "{\"axis_and_sign_max_abs_error\": 4.718447854656915e-16, \"closed_loop_final_energy\": \"0; positive stage cost canceled exactly\", \"exact_rational_checks\": 120, \"homogeneity_max_abs_error\": 1.5421691701433815e-15, \"largest_positive_multistage_mixed\": \"6725/2916\", \"n2_boundary_integrals_N256_1024_4096\": [4.4158194519953547e-10, 3.117400940976419e-12, 1.311740971919606e-14], \"near_coincident_axis_pressure\": [{\"axis_Bfree_over_c_p2\": \"1/3\", \"t\": \"1\"}, {\"axis_Bfree_over_c_p2\": \"4/3\", \"t\": \"1/2\"}, {\"axis_Bfree_over_c_p2\": \"64/3\", \"t\": \"1/8\"}, {\"axis_Bfree_over_c_p2\": \"4096/3\", \"t\": \"1/64\"}, {\"axis_Bfree_over_c_p2\": \"262144/3\", \"t\": \"1/512\"}], \"original_bad_good_receiver_counts\": [9, 90], \"scope\": \"finite exact Gram/gate checks; floating kernel checks\", \"smallest_negative_multistage_mixed\": \"-4568271014673841/896168448000\"}\n"
    },
    "optimized_cover.md": {
      "exit_code": 0,
      "seconds": 0.26515487500000745,
      "stderr": "",
      "stdout": "stage 1 exact counterexample checks: 72\nstage 2 case 0 vertices 5 original 1.5131900185032894 common 1.5131900185032894 own 1.5131900185032894\nstage 2 case 1 vertices 8 original 0.69921875 common 0.9833211762899263 own 0.9842647923197492\nstage 2 case 2 vertices 8 original 5.477625203110492 common 5.477625203110492 own 5.477625203110492\nstage 3 Decimal relative refinement: 4.268864389853349153998117726209001229030365595877313718030572388876263629587441890388288066533565157308351110919949252777575935278461190218291806147184601469054E-60\npairing ratios: [(2, '3.50'), (4, '15.50'), (8, '255.50'), (16, '65535.50'), (32, '4294967295.50'), (64, '18446744073709551615.50')]\n"
    },
    "receiver_proposal.md": {
      "exit_code": 0,
      "guard_repair": "Initial nearest-rounded Decimal algebra-equality assertion replaced with precision-scaled residual tolerance; exact coefficient identity separately checked using Fraction. No mathematical formula change.",
      "stderr": "",
      "stdout": "exact normalized two-atom cap energy: 0.69818083824283651760671434475780869883128330345234824823824479745380775638265029496427908848112053438005901208473400718762953631081480648705\nSimpson16/64/256: [0.6981830383990054, 0.6981808469511847, 0.6981808382768819]\nDecimal80/140 point-event/formula checks: PASS; not interval arithmetic\n"
    }
  },
  "frozen_hashes": {
    "general_cap_probe.py": "177e2720f09b2eabbaa78b612bad46727238687a7afd3caa43d394fe909953a2",
    "moving_obstacle.md": "04ad89077e9a08744c365c0208fc87c2500afb635edf6aec8115977092adcd8a",
    "moving_obstacle.tex.txt": "af9f8a370f1587a88cff7ac60e6f2161490bd841069f6201041ee7e49ab25543",
    "numeric_report.md": "6baa3d8e5b7b10f9dcadb7895a6dd4fabd8cd26dce96460d61db964e62cb1ad8",
    "optimized_cover.md": "ac26944b3c5dbe9f137ceff744ae3fb48704a582cd5525fd1f528ae7a9afa693",
    "optimized_cover.tex.txt": "67f83dcb5db920845b8779021c38a4db4ef38c8cc7e207bf9e2bcf00ccc5cb0f",
    "receiver_proposal.md": "b0c76bf4983058a10763cbe20a6cc01cba3afc0d128aefc2621147c2144f64bf",
    "receiver_proposal.tex.txt": "82753622bec7da611a960c98121def2636a06bf9c14375833be7083ca4245251",
    "results.json": "fa8e939421fa8c0b6cda8c8d33e3bc5021e43f808761ab166dc606457e32fd69"
  },
  "main": {
    "exit_code": 0,
    "result_byte_identical": true,
    "seconds": 3.70491949999996,
    "stderr": "",
    "stdout": "{\"runtime_seconds\": 3.6590284580015577, \"status\": \"PASS\", \"counts\": {\"pilot_cases\": 36, \"final_cases\": 282, \"calibration_cases\": 10, \"pilot_receivers\": 9216, \"final_receivers\": 1130496, \"calibration_receivers\": 81920, \"gate_checks\": 564, \"extreme_Gram_checks\": 30}, \"largest_rows\": [[0.7278203227907516, 0.12239730561082382, \"unequal_cloud\", 16, 64], [0.7024330341486742, 0.006159379063438324, \"vertices\", 1, 2], [0.6988959771144694, 0.006186366864841207, \"vertices\", 1, 2], [0.6854502724496883, 0.07238509406107299, \"unequal_cloud\", 16, 64], [0.6749658697142984, 0.025067663194477882, \"unequal_cloud\", 16, 64], [0.6659408834781231, 0.056899865302074894, \"unequal_cloud\", 16, 32], [0.6629620802968877, 0.012062229755449785, \"clusters\", 4, 64], [0.6590536749298517, 0.013060612924964294, \"nested\", 1, 32]]}\n"
  },
  "temporary_directory": "/var/folders/lq/2c4qbz2n0354_tnttkv_qsz00000gn/T/round064-replay-kszqbd89"
}
```
