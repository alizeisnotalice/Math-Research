#!/usr/bin/env python3
"""All-space capped time energy for actual arbitrary positive finite sources.
NumPy receiver batching; exact event formula in real arithmetic, no space/time cutoff.
Run with Python+NumPy; --pilot produces the deliberately small pilot only.
"""
import os
os.environ['OPENBLAS_NUM_THREADS']='1'
os.environ['VECLIB_MAXIMUM_THREADS']='1'
import argparse, itertools, json, math, time
from pathlib import Path
from fractions import Fraction as F
from decimal import Decimal as D, localcontext
import numpy as np
C=1-math.exp(-1)


def source(family,n,N):
    rng=np.random.default_rng(640001+1009*n+37*N)
    if family=='single':
        coords=[[.25]*n]; weights=[F(3)]
    elif family=='vertices':
        coords=list(itertools.product([-1.,1.],repeat=n));weights=[F(4**n)]*len(coords)
    elif family=='diagonal':
        coords=[[(2*j+1-N)/(2*N)]*n for j in range(N)];weights=[F(1,N)]*N
    elif family=='clusters':
        coords=[[(2 if j<N//2 else -2)+((j%(N//2))+.5)/(256*N)]+[((j*(k+3))%N-N/2)/(128*N) for k in range(n-1)] for j in range(N)]
        weights=[F(1,N)]*N
    elif family=='nested':
        coords=[[0.]*n]+[[2.**(-j)]*n for j in range(1,N)];weights=[F(1,N)]*N
    elif family=='unequal_cloud':
        coords=(rng.integers(-512,513,size=(N,n))/1024).tolist();weights=[F((j+1)**2) for j in range(N)]
        total=sum(weights);weights=[p/total for p in weights]
    else:raise ValueError(family)
    merged={}
    for y,p in zip(coords,weights):merged[tuple(y)]=merged.get(tuple(y),F(0))+p
    return dict(family=family,n=n,N_requested=N,N_labels=len(coords),N=len(merged),coords=[list(y) for y in merged],weights=[str(p) for p in merged.values()],W=str(sum(merged.values())))


def arrays(src):
    W=F(src['W']);return np.array(src['coords'],float),np.array([float(F(p)/W) for p in src['weights']])


def point_batch(x,src,H,proposal="global"):
    y,a=arrays(src);n=src['n'];V=float(F(src['W'])/F(H))
    dist=np.max(np.abs(x[:,None,:]-y[None,:,:]),axis=2)
    with np.errstate(divide='ignore'):
        lt=n*np.log(2*dist)-math.log(V)
    ix=np.argsort(lt,axis=1,kind='stable');slt=np.take_along_axis(lt,ix,axis=1)
    cum=np.cumsum(np.broadcast_to(a,lt.shape)[np.arange(len(x))[:,None],ix],axis=1)
    lm=np.max(np.log(cum)-slt,axis=1);cap=lm<=0
    if proposal=='global':q=np.sum(a[None,:]*.5*np.exp(-2*np.maximum(lt,0)),axis=1)
    elif proposal=='mass':q=np.sum(.5*np.exp(-2*np.maximum(lt-np.log(a)[None,:],0)),axis=1)
    else:raise ValueError(proposal)
    energy=np.zeros(len(x));diag=np.zeros(len(x))
    if np.any(cap):
        L=lt[cap];K=len(L)
        ev=np.concatenate([L-1,L],axis=1);change=np.broadcast_to(np.concatenate([a/math.e,-a]),ev.shape)
        order=np.argsort(ev,axis=1,kind='stable');ev=np.take_along_axis(ev,order,axis=1)
        coef=np.cumsum(np.take_along_axis(change,order,axis=1),axis=1)
        # Equal events have zero interval length. Full tied cumulative mass is used next.
        intervals=-np.expm1(2*(ev[:,:-1]-ev[:,1:]))
        energy[cap]=np.sum((coef[:,:-1]*np.exp(-ev[:,:-1]))**2*intervals/2,axis=1)+(coef[:,-1]*np.exp(-ev[:,-1]))**2/2
        diag[cap]=C*np.sum(a[None,:]**2*np.exp(-2*L),axis=1)
    return lm,q,energy,diag


def draw(src,H,S,seed,proposal="global"):
    rng=np.random.default_rng(seed);y,a=arrays(src);n=src['n'];V=float(F(src['W'])/F(H))
    center=rng.choice(len(a),size=S,p=a)
    U=rng.random(S);U=np.maximum(U,np.nextafter(0.,1.))
    inner=rng.integers(0,2,size=S)==0
    lv=math.log(V)+np.where(inner,np.log(U),-np.log(U))
    if proposal=='mass':lv+=np.log(a[center])
    theta=rng.uniform(-1,1,size=(S,n));face=rng.integers(n,size=S);sign=rng.integers(0,2,size=S)*2-1
    theta[np.arange(S),face]=sign
    x=y[center]+(.5*np.exp(lv/n))[:,None]*theta
    return x,center,inner,U,face,sign


def probe(src,H,S,seed,stage,proposal="global"):
    x,center,inner,U,face,sign=draw(src,H,S,seed,proposal)
    batches=[point_batch(x[j:j+512],src,H,proposal) for j in range(0,S,512)]
    lm,q,energy,diag=[np.concatenate([b[k] for b in batches]) for k in range(4)]
    score=energy/q;dscore=diag/q
    bound=2*C*src['N']*(float(F(src['W'])/min(F(p) for p in src['weights'])) if proposal=='global' else 1)
    assert np.all(np.isfinite(score)) and float(np.max(score))<=bound*(1+1e-12)
    def saved(i):
        return dict(receiver=x[i].tolist(),score=float(score[i]),log_M_over_H=float(lm[i]),qcore=float(q[i]),energycore=float(energy[i]),selected_center=int(center[i]),radial_inner=bool(inner[i]),U=float(U[i]),face=int(face[i]),sign=int(sign[i]))
    borders=[]
    for accepted in [True,False]:
        ids=np.flatnonzero((lm<=0)==accepted)
        if len(ids):borders.append(dict(accepted=accepted,**saved(ids[np.argmin(np.abs(lm[ids]))])))
    top=[saved(i) for i in np.argsort(score)[-3:][::-1]]
    sm=float(score.sum());ss=float(score@score);k=max(1,S//100)
    return dict(source=src,H=str(F(H)),stage=stage,proposal=proposal,seed=seed,samples=S,cap_hits=int(np.sum(lm<=0)),mean=float(score.mean()),sample_SE=float(score.std(ddof=1)/math.sqrt(S)),source_diagonal_mean=float(dscore.mean()),source_diagonal_SE=float(dscore.std(ddof=1)/math.sqrt(S)),energy_ESS=sm*sm/ss if ss else 0,top_one_percent_fraction=float(np.sort(score)[-k:].sum()/sm) if sm else 0,max_score=float(score.max()),score_bound=bound,formal_Hoeffding95_radius=bound*math.sqrt(math.log(40)/(2*S)),min_abs_log_M=float(np.min(abs(lm))),extremes=top,closest_gate_receivers=borders)


def decimal_point(src,H,x,precision,energy=True,proposal="global"):
    with localcontext() as ctx:
        ctx.prec=precision
        W=D(F(src['W']).numerator)/D(F(src['W']).denominator);h=D(F(H).numerator)/D(F(H).denominator);V=W/h
        a=[D(F(p).numerator)/D(F(p).denominator)/W for p in src['weights']]
        vols=[(2*max(abs(D.from_float(z)-D.from_float(t)) for z,t in zip(x,y)))**src['n']/V for y in src['coords']]
        groups={}
        for v,p in zip(vols,a):groups[v]=groups.get(v,D(0))+p
        vp=sorted(groups.items());cum=D(0);M=D(0)
        for v,p in vp:cum+=p;M=max(M,cum/v)
        q=sum(p*(D('.5') if v<=1 else D('.5')/v**2) for v,p in zip(vols,a)) if proposal=='global' else sum(D('.5') if v<=p else D('.5')*p*p/v**2 for v,p in zip(vols,a))
        out=dict(M=str(M),qcore=str(q),cap=M<=1,arrival_groups=len(vp))
        if energy:
            e=D(1).exp();ih=1/e;c=1-ih;gram=D(0)
            for v,p in vp:
                for w,t in vp:
                    small,big=min(v,w),max(v,w);rho=big/small
                    kernel=(2-ih-ih*rho*rho)/(2*big*big) if rho<=e else -c*c/(2*ih*big*big)
                    gram+=p*t*kernel
            events={}
            for v,p in vp:
                events[v/e]=events.get(v/e,D(0))+p/e;events[v]=events.get(v,D(0))-p
            ordered=sorted(events);coef=D(0);event=D(0)
            for i,v in enumerate(ordered):
                coef+=events[v]
                event+=coef**2/2*(v**-2-(ordered[i+1]**-2 if i+1<len(ordered) else 0))
            out.update(gram=str(gram),event=str(event),gram_event_relative=str(abs(gram-event)/max(abs(gram),D('1e-1000'))))
        return out


def guards(rows):
    gates=[]
    for row in rows:
        for p in row['closest_gate_receivers']:
            lo=decimal_point(row['source'],row['H'],p['receiver'],80,False,row['proposal']);hi=decimal_point(row['source'],row['H'],p['receiver'],120,False,row['proposal'])
            assert lo['cap']==hi['cap']==p['accepted']
            gates.append(dict(stage=row['stage'],family=row['source']['family'],n=row['source']['n'],N=row['source']['N'],seed=row['seed'],receiver=p['receiver'],float_log_M=p['log_M_over_H'],decimal80=lo,decimal120=hi))
    checks=[]
    # Three largest score receivers in each dimension, all drawn from final rows.
    for n,proposal in sorted(set((r['source']['n'],r['proposal']) for r in rows)):
        choices=sorted([(p['score'],r,p) for r in rows if r['source']['n']==n and r['proposal']==proposal for p in r['extremes']],key=lambda t:t[0],reverse=True)[:3]
        for _,r,p in choices:
            lo=decimal_point(r['source'],r['H'],p['receiver'],80,proposal=r['proposal']);hi=decimal_point(r['source'],r['H'],p['receiver'],120,proposal=r['proposal'])
            target=float(hi['gram']);q=float(hi['qcore'])
            err=abs(p['energycore']-target)/max(abs(target),1e-300)
            assert err<1e-9 and float(hi['gram_event_relative'])<1e-70
            checks.append(dict(proposal=r['proposal'],n=n,N=r['source']['N'],family=r['source']['family'],seed=r['seed'],H=r['H'],receiver=p['receiver'],float_energy_relative_error=err,float_q_relative_error=abs(p['qcore']-q)/q,precision_energy_relative_error=str(abs(D(lo['gram'])-D(hi['gram']))/abs(D(hi['gram']))),decimal80=lo,decimal120=hi))
    # Actual positive-volume ties and asymmetric unequal masses.
    ties=[]
    for n in [1,2,4,8,16]:
        s=source('single',n,1)
        for H in [F(1),F(7,3)]:
            x=np.array([[3.]*n,[.25+.6*(3/float(H))**(1/n)]*n])
            lm,q,en,_=point_batch(x,s,H)
            for j in range(len(x)):
                z=decimal_point(s,H,x[j].tolist(),120)
                exact=C/float((2*max(abs(t-.25) for t in x[j]))**n/(3/float(H)))**2
                assert abs(en[j]-exact)<1e-12*max(1,exact)
                ties.append(dict(n=n,H=str(H),kind='one_atom_point',actual=float(en[j]),analytic=exact))
    s=dict(family='common_face_tie',n=2,N_requested=2,N_labels=2,N=2,coords=[[-.25,0.],[.25,0.]],weights=['1/3','2/3'],W='1')
    for x in [[0.,2.],[.125,2.],[0.,.5]]:
        lm,q,en,_=point_batch(np.array([x]),s,1);z=decimal_point(s,1,x,120)
        assert z['arrival_groups']==1
        if z['cap']:assert abs(en[0]-float(z['gram']))<1e-14
        ties.append(dict(kind='actual_tied_face',receiver=x,decimal120=z,float_energy=float(en[0])))
    return dict(gate_checks=gates,extreme_energy_Gram_checks=checks,one_atom_and_true_tie_checks=ties)


def main(pilot=False):
    start=time.monotonic();families=['diagonal','clusters','nested','unequal_cloud']
    pilotrows=[probe(source(f,n,N),1,256,640100+10000*i+101*n+N,'pilot') for i,f in enumerate(families) for n in [1,4,16] for N in [2,8,32]]
    if pilot:
        result=dict(status='PILOT',rows=pilotrows)
    else:
        rows=[]
        for i,f in enumerate(families):
            for n in [1,2,4,8,16]:
                for N in [2,4,8,16,32,64]:
                    for repeat in [0,1]:rows.append(probe(source(f,n,N),1,2048,641000+100000*i+1000*n+10*N+repeat,'independent_matrix'))
        # Predetermined threshold pressure and explicit vertex models, not selected-fit estimates.
        for n,N in [(1,16),(4,32),(16,64)]:
            for H in [4,16,256]:
                for rep in [0,1]:rows.append(probe(source('nested',n,N),H,8192,649000+1000*n+10*H+rep,'threshold_pressure'))
        for n in [1,2,3,4,5,6]:
            for rep in [0,1]:rows.append(probe(source('vertices',n,2**n),1,8192,648000+100*n+rep,'vertex_comparator'))
        # Held-out independent refinement chosen for high initial sampling variance.
        for n,N in [(8,64),(16,32),(16,64)]:
            for rep in [0,1]:rows.append(probe(source('unequal_cloud',n,N),1,32768,646000+1000*n+10*N+rep,'variance_selected_holdout'))
        for n,N in [(8,64),(16,32),(16,64)]:
            for rep in [0,1]:rows.append(probe(source('unequal_cloud',n,N),1,32768,668000+1000*n+10*N+rep,'mass_proposal_comparison','mass'))
        calibration=[probe(source('single',n,1),H,8192,669000+100*n+H,'one_atom_calibration') for n in [1,2,4,8,16] for H in [1,4]]
        for r in calibration:
            for p in r['extremes']:assert abs(p['score']-2*C)<1e-12
        g=guards(rows)
        result=dict(round=64,status='PASS',numpy_version=np.__version__,counts=dict(pilot_cases=len(pilotrows),final_cases=len(rows),calibration_cases=len(calibration),pilot_receivers=sum(r['samples'] for r in pilotrows),final_receivers=sum(r['samples'] for r in rows),calibration_receivers=sum(r['samples'] for r in calibration),gate_checks=len(g['gate_checks']),extreme_Gram_checks=len(g['extreme_energy_Gram_checks'])),proposal=dict(V='W/H',component='q_i(x)=1/(2V) for v_i<=V; V/(2v_i^2) otherwise; v_i=(2||x-y_i||infinity)^n',mixture='q=sum_i(p_i/W)q_i; sampled center uses p_i/W, uniform face/sign and uniform free cone coordinates; inner/outer radial volume each probability1/2',normalized='a_i=p_i/W,tau_i=v_i/V; q=(H/W)qcore, Epoint=H^2 Ecore; score=1_G Ecore/qcore',score_bound='Global V:2cN W/pmin. Individual V_i=p_i/H:2cN on G, with c=1-exp(-1).',individual_component='Same normalized radial component with V_i=p_i/H; full density on all receivers qcore=sum_i .5 min(1,(a_i/tau_i)^2); on G qcore=.5sum_i a_i^2/tau_i^2. Independent comparison seeds.'),scope=dict(receiver='All-space Lebesgue importance, no spatial cutoff, full mixture density.',time='All scales signed event integration with true arrival ties, no time mesh.',arithmetic='Floating samples and source coordinates; retained machine receivers checked with Decimal80/120 nearest rounding, not outward intervals.',uncertainty='SampleSE is diagnostic; formal two-sided95 Hoeffding radius uses iid exact continuous proposal and analytic score envelope, not machine transform error or simultaneous certification.',interpretation='Finite source-family pressure only; source count varies independently of dimension in main matrix; no exponent fit, general cap bound, or weak-type counterexample inferred.',selection='Pilot fixed first; independent final matrix/threshold/vertex/calibration seeds. No pilot score reused in final estimates. Six variance-selected heldout rows were chosen after the first matrix showed high unequal-cloud variance; their seeds are independent and their means are not pooled with selection data. Six further individual-mass proposal rows use independent seeds on the same three geometries to test variance, preserving the first global proposal matrix.'),pilot_rows=pilotrows,rows=rows,one_atom_calibrations=calibration,guards=g)
    Path(__file__).with_name('results.json').write_text(json.dumps(result,indent=2,sort_keys=True,allow_nan=False)+'\n')
    print(json.dumps(dict(runtime_seconds=time.monotonic()-start,status=result['status'],counts=result.get('counts'),largest_rows=sorted([(r['mean'],r['sample_SE'],r['source']['family'],r['source']['n'],r['source']['N']) for r in result.get('rows',[])],reverse=True)[:8])))
if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--pilot',action='store_true');main(parser.parse_args().pilot)
