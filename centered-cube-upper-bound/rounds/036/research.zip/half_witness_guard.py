from fractions import Fraction as F
from itertools import combinations
from math import comb, factorial
from decimal import Decimal as D, localcontext
from pathlib import Path
import random
import json


def capture_intervals(points, caps, receiver, a, b):
    """Actual full-side-length capture intervals; death is excluded."""
    ans = []
    for i, (y, cap) in enumerate(zip(points, caps)):
        entry = max(a, 2 * max(abs(v - w) for v, w in zip(y, receiver)))
        if entry <= b and entry < cap:
            ans.append((entry, cap, i))
    return ans


def witnesses(iv, k, b):
    return [tuple(v[2] for v in sub) for sub in combinations(iv, k)
            if max(v[0] for v in sub) <= b
            and max(v[0] for v in sub) < min(v[1] for v in sub)]


def brute_values(es, k, r, prices):
    if not es:
        return None
    vectors = [sorted(prices[i] for i in e) for e in es]
    tau = [min(v[j] for v in vectors) for j in range(k)]
    cost = min(sum(v[:r], F(0)) / r for v in vectors)
    # Independent layer calculation from the witness family, not from tau.
    levels = sorted({F(0)} | {v for v in prices})
    layer = F(0)
    for lo, hi in zip(levels, levels[1:]):
        count = min(sum(prices[i] > lo for i in e) for e in es)
        layer += (hi - lo) * F(count, k)
    return cost, tau, layer


def event_states(iv, a, b):
    """Evaluate actual states after all same-time deaths, then entries."""
    times = sorted({a, b} | {s for s, c, i in iv if a <= s <= b}
                   | {c for s, c, i in iv if a <= c <= b})
    entering = {}
    dying = {}
    for s, c, i in iv:
        entering.setdefault(s, []).append(i)
        dying.setdefault(c, []).append(i)
    active = set()
    states = []
    for t in times:
        for i in dying.get(t, ()):
            active.discard(i)
        for i in entering.get(t, ()):
            active.add(i)
        states.append((t, tuple(sorted(active))))
    return states


def event_values(states, k, r, prices, minimum_occupancy=None):
    gate = k if minimum_occupancy is None else max(k, minimum_occupancy)
    tau = [None] * k
    cost = None
    for t, ids in states:
        if len(ids) < gate:
            continue
        v = sorted(prices[i] for i in ids)
        value = sum(v[:r], F(0)) / r
        cost = value if cost is None else min(cost, value)
        for j in range(k):
            tau[j] = v[j] if tau[j] is None else min(tau[j], v[j])
    return None if cost is None else (cost, tau, sum(tau, F(0)) / k)


def geometry_cases():
    rng = random.Random(20261010)
    rows = []
    for stage, N in enumerate((7, 9, 12), 1):
        for n in (1, 2, 4, 8, 16):
            d = N // 2 + 1
            points = [tuple(F(rng.randrange(-12, 13), 16) for _ in range(n))
                      for _ in range(d)]
            receiver = tuple(F(rng.randrange(-2, 3), 16) for _ in range(n))
            source_prices = [F(rng.randrange(0, 33), 8) for _ in range(d)]
            # Repeated marks at one source share its position and price.
            mark_points = [points[i % d] for i in range(N)]
            prices = [source_prices[i % d] for i in range(N)]
            caps = [F(rng.randrange(17, 66), 16) for _ in range(N)]
            a, b = F(1), F(3)
            iv = capture_intervals(mark_points, caps, receiver, a, b)
            states = event_states(iv, a, b)
            for k in (2, 3, 4, 6):
                es = witnesses(iv, k, b)
                for r in sorted({1, k // 2, k - 1}):
                    brute = brute_values(es, k, r, prices)
                    event = event_values(states, k, r, prices)
                    assert brute == event
                    inclusion_checks = 0
                    if brute is not None:
                        cost, tau, layer = brute
                        ell = k - r + 1
                        assert cost <= tau[r - 1] <= F(k, ell) * layer
                        levels = sorted({F(0)} | set(prices))
                        for level in levels:
                            if tau[r - 1] > level:
                                assert all(sum(prices[i] > level for i in e) >= ell
                                           for e in es)
                                assert any(sum(prices[i] > level for i in ids) >= ell
                                           for t, ids in states)
                                inclusion_checks += 1
                    rows.append(dict(stage=stage, n=n, N=N, sources=d, k=k, r=r,
                                     witnesses=len(es), cost=None if brute is None else str(brute[0]),
                                     tau=None if brute is None else [str(v) for v in brute[1]],
                                     layer=None if brute is None else str(brute[2]),
                                     high_price_inclusions=inclusion_checks))
    return rows


def endpoint_cases():
    cases = [
        # The dying price-zero mark must not join the terminal entry batch.
        ([(F(1), F(2), 0), (F(2), F(3), 1), (F(2), F(4), 2)],
         F(2), [F(0), F(2), F(4)], F(2)),
        # No hit: an excluded death endpoint cannot overlap a new entry.
        ([(F(1), F(2), 0), (F(2), F(3), 1)],
         F(2), [F(0), F(1)], None),
        # A genuine terminal singleton-time witness is allowed.
        ([(F(1), F(3), 0), (F(2), F(3), 1)],
         F(2), [F(3), F(1)], F(1)),
        # Death exactly at b is removed, but a surviving pair still hits.
        ([(F(1), F(2), 0), (F(1), F(3), 1), (F(2), F(3), 2)],
         F(2), [F(0), F(3), F(1)], F(0)),
    ]
    rows = []
    for iv, b, prices, expected in cases:
        es = witnesses(iv, 2, b)
        br = brute_values(es, 2, 1, prices)
        ev = event_values(event_states(iv, F(1), b), 2, 1, prices)
        assert ev == br
        assert (None if ev is None else ev[0]) == expected
        rows.append(dict(intervals=[[str(s), str(c), i] for s, c, i in iv],
                         b=str(b), price=None if ev is None else str(ev[0])))
    return rows


def surplus_and_barycenter():
    rows = []
    for k in (2, 3, 4, 8, 16, 32, 64):
        r = k // 2
        for R in (k, 2 * k, 8 * k):
            entries = [F(1) + F(i, 20 * R) for i in range(R)]
            entries += [F(3) + F(i, 20 * R) for i in range(R)]
            caps = [F(2) + F(i, 20 * R) for i in range(R)]
            caps += [F(4) + F(i, 20 * R) for i in range(R)]
            points = [(s / 2,) for s in entries]
            iv = capture_intervals(points, caps, (F(0),), F(1), F(5))
            prices = [F(0)] * (k - 1) + [F(k)] * (R - k + 1) + [F(1)] * R
            states = event_states(iv, F(1), F(5))
            full = event_values(states, k, k, prices)
            half = event_values(states, k, r, prices)
            surplus = event_values(states, k, k, prices, R)
            assert full[0] == surplus[0] == 1
            assert full[2] == surplus[2] == F(1, k)
            assert half[0] == 0
            # Exact combinatorial identity; no enumeration at large R.
            bary = F(comb(R - 1, k - 1), k * comb(R, k))
            assert bary == F(1, R)
            rows.append(dict(k=k, paid_members=r, simultaneous_marks=R,
                             full_cost=str(full[0]), layer=str(full[2]),
                             half_cost=str(half[0]), uniform_R_member_load=str(bary)))
    explicit = []
    for R, k in ((3, 2), (4, 2), (4, 3), (6, 2), (6, 3), (7, 4)):
        es = list(combinations(range(R), k))
        loads = [sum((F(1, k * len(es)) for e in es if i in e), F(0))
                 for i in range(R)]
        assert loads == [F(1, R)] * R
        explicit.append(dict(R=R, k=k, enumerated_subsets=len(es), load=str(loads[0])))
    return rows, explicit


def poisson_tail(z, threshold, precision):
    """Positive series avoids cancellation in very rare tails."""
    if threshold <= 0:
        return D(1)
    term = (-z).exp() * z ** threshold / factorial(threshold)
    total = term
    j = threshold
    tolerance = D(10) ** (-(precision + 8))
    while True:
        j += 1
        term *= z / j
        total += term
        if term <= total * tolerance:
            return total


def two_source_phi(k, r, z, precision):
    m = D(k - 1)
    mass = (-m).exp()
    total = D(0)
    probabilities = []
    for j in range(k):
        probabilities.append(mass)
        if j < r:
            total += D(r - j) * mass * poisson_tail(z, k - j, precision)
        mass *= m / (j + 1)
    phi = D(3) / (4 * r) * total + poisson_tail(z, k, precision) / 4
    ell = k - r + 1
    leading = D(3) / (4 * r) * probabilities[r - 1] / factorial(ell)
    correction = sum((D(r - j) * probabilities[j] / factorial(k - j)
                      for j in range(r - 1)), D(0)) * D(3) / (4 * r)
    correction += D(1) / (4 * factorial(k))
    scaled = phi / z ** ell
    # These analytical brackets hold for r>=2 and 0<z<=1.
    tolerance = D(10) ** (-(precision - 8))
    assert scaled >= leading * (-z).exp() * (1 - tolerance)
    assert scaled <= (leading + z * correction) * (1 + tolerance)
    return phi, scaled, leading


def decimal_two_source(precision):
    rows = []
    with localcontext() as ctx:
        ctx.prec = precision + 20
        for k in (4, 8, 16, 32):
            r = k // 2
            ell = k - r + 1
            for power in (1, 4, 8, 16, 32):
                z = D(2) ** (-power)
                half, half_scaled, half_limit = two_source_phi(k, r, z, precision)
                full, full_scaled, full_limit = two_source_phi(k, k, z, precision)
                tail = poisson_tail(z, ell, precision)
                assert half <= tail * (1 + D(10) ** (-(precision - 8)))
                fmt = lambda v: format(v, '.16g')
                rows.append(dict(k=k, r=r, ell=ell, z_power_two=-power,
                                 Phi_half=fmt(half), high_tail=fmt(tail),
                                 Phi_full_over_z=fmt(full_scaled), full_limit=fmt(full_limit),
                                 Phi_half_over_z_power_ell=fmt(half_scaled),
                                 half_limit=fmt(half_limit),
                                 full_relative_limit_error=fmt(abs(full_scaled / full_limit - 1)),
                                 half_relative_limit_error=fmt(abs(half_scaled / half_limit - 1))))
    return rows


def rational_tail_guards():
    """Integral Taylor series, factored to avoid cancellation/underflow."""
    rows = []
    for k in (4, 8, 16, 32):
        ell = k - k // 2 + 1
        for power in (1, 4, 8, 16, 32):
            z = F(1, 2 ** power)
            previous = None
            stages = []
            for order in (8, 16, 32):
                # H=ell!*P(Poi(z)>=ell)/z**ell.
                upper = sum((F(ell) * (-z) ** j / (factorial(j) * (ell + j))
                             for j in range(order + 1)), F(0))
                next_term = F(ell) * z ** (order + 1) / (factorial(order + 1) * (ell + order + 1))
                lower = upper - next_term
                assert 0 < lower <= upper <= 1
                if previous is not None:
                    assert lower >= previous[0] and upper <= previous[1]
                previous = lower, upper
                stages.append(dict(order=order, normalized_tail_lower=str(lower),
                                   normalized_tail_upper=str(upper)))
            rows.append(dict(k=k, ell=ell, z_power_two=-power, exact_refinements=stages))
    return rows


def axis_constant_guards(precision):
    """Check stated constants, not the exponentially rare annealed integral."""
    rows = []
    with localcontext() as ctx:
        ctx.prec = precision + 20
        for n_int in (1024, 4096, 65536, 2**24, 2**40, 2**64, 2**96):
            n = D(n_int)
            T = n * D(2).ln()
            log_guard = (D(2) + T).ln()
            ceil = lambda x: int(x.to_integral_value(rounding='ROUND_CEILING'))
            m_log = ceil(64 * log_guard)
            safe_m = max(ceil(128 * log_guard), ceil(T.sqrt()))
            for branch, m_int in (('logarithmic_full_price', m_log),
                                  ('guarded_half_payment', safe_m),
                                  ('large_m', n_int * n_int)):
                m = D(m_int)
                k = m_int + 1
                r = k // 2
                mp = k - r
                delta = 1 / (75 * m.sqrt())
                Smax = D(2) / 3 + delta
                angle_lower = (n - 1) / n * D(3) / 40 * delta
                angle_target = 1 / (2000 * m.sqrt())
                beta_ratio = D(3) / 4 * ((n.ln() / n)
                                + (1 - 1 / n) * Smax.ln()).exp()
                log_beta_terminal = (D(3) / 4 * n).ln() + (1 - n) * D(2).ln()
                log_return_upper = (D(3) / 5 * m * T).ln() - m / 20
                depth = m_int - 4 * m_int // 5
                log_return_ratio = ((D(3) / 5 * m * T).ln()
                                    + D(depth) * (D(3) / 4).ln())
                assert angle_lower >= angle_target
                assert beta_ratio < D(3) / 5
                assert log_beta_terminal < (D(3) / 5).ln()
                assert log_return_upper < (D(1) / 8).ln()
                assert log_return_ratio <= log_return_upper
                coefficient = m / 2 * angle_target * 3 / (40 * m.sqrt()) / 8
                assert abs(coefficient - D(3)/1280000) < D('1e-60')
                assert m >= 64 * log_guard
                if branch == 'guarded_half_payment':
                    assert D(mp) >= 64 * log_guard
                    assert m / mp < 2
                full_capacity_lower = 3 * T / (5120000 * k)
                fmt = lambda value: format(value, '.16g')
                rows.append(dict(n=str(n_int), branch=branch, m=str(m_int),
                                 reduced_m=str(mp), T=fmt(T),
                                 angular_bound_ratio=fmt(angle_lower / angle_target),
                                 beta_over_m_upper=fmt(beta_ratio),
                                 log_terminal_beta_over_m=fmt(log_beta_terminal),
                                 log_return_probability_upper=fmt(log_return_upper),
                                 log_return_ratio_upper=fmt(log_return_ratio),
                                 finite_atomic_full_capacity_lower=fmt(full_capacity_lower),
                                 actual_total_coverage_upper=fmt(D(2)/3*(1+1/n)),
                                 half_guard_verified=branch == 'guarded_half_payment'))
    return rows


def main():
    geometry = geometry_cases()
    endpoints = endpoint_cases()
    surplus, barycenter = surplus_and_barycenter()
    decimal = decimal_two_source(70)
    assert decimal == decimal_two_source(110)
    rational = rational_tail_guards()
    axis = axis_constant_guards(70)
    assert axis == axis_constant_guards(110)
    counts = dict(geometry_oracles=len(geometry), endpoint_cases=len(endpoints),
                  surplus_vectors=len(surplus), enumerated_barycenters=len(barycenter),
                  two_source_vectors=len(decimal), rational_tail_vectors=len(rational),
                  rational_refinements=sum(len(row['exact_refinements']) for row in rational),
                  axis_constant_vectors=len(axis))
    out = dict(status='PASS; general square-root bound unproved', counts=counts,
               actual_source_geometry=geometry, endpoint_checks=endpoints,
               surplus_obstruction=surplus, enumerated_barycenters=barycenter,
               same_scale_two_source=decimal, poisson_tail_fraction_certificates=rational,
               axis_constant_guards=axis,
               notes=[
                   'All geometry uses actual source positions and mark caps; repeated marks at one source share its price. Caps>a correspond to legal positive heights below h0.',
                   'The event oracle is an independent finite-state verifier, not the O(N log N) production price algorithm. No scale grid is used.',
                   'The large surplus barycenters use exact combinatorial identities; six additional small barycenters enumerate all subsets.',
                   'Surplus families are feasible deterministic mark configurations; their pointwise obstruction is not an annealed weak-type lower bound.',
                   'The two-source input has high-price-one source at 0 with mass z/m and price-zero source at 1/4 with mass 1, a=b=1, lambda=1, m=k-1. Overlap length is 3/4 and high-only length is 1/4.',
                   'Decimal70/110 agreement at 16 displayed digits is not interval certification. Positive-series tails avoid catastrophic cancellation.',
                   'Exact Fraction integral-Taylor intervals certify the normalized Poisson tail at three orders. They do not certify all Decimal Phi values.',
                   'Limit constants are derived analytically; no exponent is fitted from the finite z values. The general budget remains unproved.',
                   'Axis guards use seven dimensions in three increasing ranges and three admissible parameter rules, with Decimal70/110 agreement at 16 displayed digits. Log probabilities avoid underflow. These constants do not numerically integrate the full high-dimensional pivotal expectation or compute a quantization resolution J.'
               ])
    Path(__file__).with_name('results.json').write_text(json.dumps(out, indent=2) + '\n')
    print('PASS', counts)


if __name__ == '__main__':
    main()
