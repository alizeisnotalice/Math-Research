# R571 Sol 独立发布前组合审查（第一阶段）

审查者：新配置 GPT-6.1 Sol；不启动子代理。仅读原定义与实际证明，再对照定点独审；未以作者 PASS 代替证明。仅写本文件族，无仓库修改、提交或 PDF。R570 的一般目标仍未证明：对任意 n、f≥0∈L¹(Rⁿ)，centered axis-parallel cube maximal operator 的弱型常数是否为 n^(1/2+o(1))。本轮所有新结论必须使用真实 Lebesgue 中心、同一任意相关来源 μ=f dx、实际 cube mass、原 source/window/phase 及完整一次费用。

## 可归档的主清单：建议最多六项

1. **一般输入到新完整单带母式的连接。** `astra_local_entry.md` §§1–4 自主构造全动作包含的共同 source cells、t=1、冻结整场 Li、一次互斥 low/rapid/bulk，并证明
   dQ0≤C0(1+G)W+G√(JQ0 Bπ)。它允许任意合法来源前完整 π。`cover_next.tex` G1–G11 先构造真实来源 f_k，q_k∈[3λ/4,λ]，再以 ΣW_k≤N_nW、N_n=2+ceil(log₂(32n²)) 接上新入口。所需来源总费为一次 O(log n)W；既不需要 G15 的第二份 logarithm，也不需要旧 E_ent/history/collar。未知：同一新 bulk 上合法完整 Bπ 的几何预算。local_entry §5 的有限近优只是可行构造，不能计作小能量定理。

2. **指定 ρ 的全树、head/core、低支与伴随母式。** `history_bridge.md` 从同一新数据重建共同树 first-stop、初始层蛋糕原子、joint wide、head、core、lift 和 χ_new。实际 Bρ 的 Gram 保 1/(gv)；伴随 Yhat 的系数为 a_Bρ，与实际 a_Bρ/g 不同。对 Yhat 独立三窗证明给
   Q0≤CnewW+2(J/d²)√(Q0 VG_new)，
   Cnew=2(J/d²)(Kw+K+Fcap)+2C0(1+G)/d。
   wide/exc 各 KwW、低旧场 KW、低增长新来源 FcapW、low/rapid C0(1+G)W 和零树终端全部在这份新账上一次覆盖。未知：这份完整 VG_new 的几何付款。fixed-g 的 wide/exc 证明仅对指定共同 ρ，不能移给任意 B-dependent Dirac π。

3. **实际行替代 Cauchy 与无外置 γ^h 的 actioncurve 帽。** `actions_attack.tex` 与 `audit_actioncurve.md` 在固定真实 (C,v,j) 时先抽出旧 mass 域，再放松 gates，得到 r_C≤R_A/I_C，R_A=min(K,2GS Hph)，Hph=1+ln(γ^(2+h)r)。同一 demand M 的合法桥为 M²≤Qfr Vcap，其中 Vcap=∫q_C r_C²/ell_C。其已付粗来源界仍含 D，不能把它写成 pointwise VG≤Vcap，更不能因符号替代宣告完整几何费改善。additive 增长缺口必须保 Aact，不能免费换成 min(K,Aact)。

4. **同一来源时钟/分支的有限系数证书。** `astra_clock_attack.tex` 的 sourcewise reciprocal clock 能量、`core_attack.tex` 的 edge 与 smallgrowth 给真实同核约束；例如 Vedge≤196h²Qfr，进入 Cstar 平方根后是 M_edge≤14hQfr，而非给实际 Bπ 一个 196h² 系数。完整旧平台仍贡献一个单位 Qfr。smallgrowth 是其自有 row 的平方费并须保完整交叉；原 χ 含 Nδ^c、S=1、ε=δ=1/A_n 时它为空，不能重复登记为新增非零付款。`astra_lowtail_attack.tex` 只可作为受限 row-square/补充工具存档；其低 tail 费与 full row 的交叉和 LT15 的 √(DW) 仍在，不能给它第七项“完整新付款”头衔。

5. **重建 ε' 的参数相容性突破。** `gamma_budget_audit.md` 的 ε'_j=[2GA_n γ^(2+h)r²(j+1)(j+2)]⁻¹ 同时重建 k'_j、m'_j、head、core 和 χ' 后，wide/exc 各≤S²W，即 S=1 时合计 2W。该合法新划分不蕴含旧新 χ、core 或 VG 的单调性。已用的 row/clock/direct 估计没有倒 ε' 付款。以 γ=A_n^112、h=1/448、J=5，单独 edge 的正确吸收条件 28Jh<d² 有余量 135305/200704；所有显示已付系数保持 polylog。`parameter_certificate.md` 的 p=16,q=16,h=1/256,J=17 针对不同 clock-envelope 系数，是另一合法备选；两个参数组不混用。未知：同一 χ' 除 edge 外的完整旧平台/high-growth/outer-new。

6. **真实 last-threshold 候选及完整 old/new 能量账。** `generator_global.tex` / `energy_global.md` 对每可达 Γ_j 选实际 last hit g_Bj，并用 p_Bj、x_Bj=p_Bj/g_Bj 实现来源前概率。真实动作的 1/g 保留；平台 last-hit 对整个非负场确有不增能量比较。实际旧平方精确为 P−Dgraph−Ddel，完整新 shell 的质量为 ∫q_B Σ(Γ_j−1)x_Bj；一次 Young 包括全部交叉。waterfill 仅最优化正的 separable majorant，不能宣称最小化实际 Bπ。Ddel≤Edel 是同一全→bulk 修正，不能在母式外重扣。逐父对角证书的 floor 1/(JG²) 阻止它独自产生严格 a<d²/(JG²)，这是证书局限而非实际完整能量下界。未知：真实图抵扣、低抵扣旧平台与新 shell 的共同来源预算。

## 最终完整未付总账

两条路线只能择其合法完整对象使用，不能混用阈值：

- 任意合法真实动作：若 Bπ≤a_BQ0+L_BW，需要 a_B<d²/(G²J)；
- 指定 ρ 的伴随/合法替代 Cauchy：若 V≤a_VQ0+L_VW，需要 a_V<d⁴/(4J²)。该 V 可以是同一 demand 的合法替代费，不能先声称 VG≤V。

重建 ε' 后，记 T=S²+K+Fcap、c=C0(1+G)，则当前已完成
Q0≤[2c/d+2JT/d²]W+2(J/d²)M_remaining，且 M_remaining²≤Qfr Vcap'。
若把 edge 合法单独分离，M_edge≤14hQfr≤14hQ0；其余仍未付。真正闭合需要对同一 χ'/Yhat 给完整 Ehat≤28hQ0+Ltot(n)W，Ltot 为固定对数幂，继而
Q0/W≤[2cd+J Ltot]/[d²−28Jh]。
结合 q_k≥3λ/4 的 G11，最终条件式为
λ|{M_cube f>λ}|≤[16e+4N_n/(3(1−η))√(Dold·[2cd+JLtot]/[d²−28Jh])]W。
目前没有该 Ltot 定理。

具体未付：old-overlap/platform 的非 edge 部分；inner-new high-growth；outer-new（并非 actioncurve 的同一 inner-new 事件）；任何未覆盖父族及这些 row 间平方交叉。低 tail 支的 usefulness/非空性、外 spatial-shell 费和补集都未从现有 lemma 自动获得。仅 χ≤1、core 条件质量、sourcewise entropy/clock 恒等式、全行动近优或求解器 surrogate optimum 均不能代付。

## 必须在整合稿修正的陈旧或过度断言

- `astra_local_entry.md` §6 “仍须重建 head/core/stop”及 `astra_integrator_bridge.md` §IV 同类时态，是形成于 history_bridge 前的检查点；最终缺口不再称旧 globalhistory 入口未接。
- integrator_bridge §VI “当前没有该新桥、旧 wide 消灭窗口”已由 history_bridge + gamma_budget_audit 的新阈值完整划分更新。仅沿旧 ε 的旧 Kw 仍有该障碍。
- γ 一改，s_B、Li、α、Q0 均重建；ε 一改，head/core/χ 重建而 Li 冻结。不复用不同 γ 的数值或旧 χ 发票。
- wide/exc 是两份 W，不是一份；edge 经过平方根为 28h 能量系数；old 平台、高增长、outer-new 仍在。
- 低 tail 只付 restricted square，不能当 full row 的线性限制项；S=1 的旧 χ smallgrowth ε=1/A_n 是空支。
- Vcap 是另一次完整同 demand Cauchy 的替代费用；Dgraph/Ddel 是同一真实 Gram 的抵扣，均不产生额外可重复信用。
- 新 `threshold_graph` / `twin_receiver` 即使出现作者或定点审稿，尚未包含本发布审查；不列为已证主成果，待 root 提交新 REPORT 后仅核其纳入范围。

## 独立审查顺序与实际计算

先读 live_next、local_entry、cover_next、history_bridge、generator_global、gamma_budget、energy_global 的命题和实际证明，再读 history_contract/adjoint/waterfill/parameter 等定点审查。另读 R570 原 REPORT，区分新入口解决的问题与旧 finite-cutoff 结论。未复跑已通过的局部代数/数值试验。

本机 Python 3.12 / SymPy 1.14 实跑 `sol_release_audit.py`，只核最终母式组合及两组参数不得混用的精确余量：两个组合残差为 0；p112 edge 余量为 135305/200704；p16 clock 余量为 4530423/50266112。它们不是一般几何证明。输出 `sol_release_audit.json` 同时固定 22 份 proof/audit 的当前 SHA256。此前一次 JSON 序列化遇 SymPy BooleanTrue，转 Python bool 后重跑成功；无数学结果改变。

待 root 提供最终 REPORT，仅做与本主清单、总账及固定 SHA 的定点对照，不制造重复审查任务。

## 固定证据 SHA256

| 文件 | SHA256 |
|---|---|
| `/tmp/ccu_r571_astra_local_entry.md` | `398634a3fb7542cd44c2189ac69a0c1210fa0a1e2e4d94ce7d72564775225919` |
| `/tmp/ccu_r571_cover_next.tex` | `1ab83931158f48cdb657b952dc61e0077df6e0823d67944bb8fa34b62d1c2c18` |
| `/tmp/ccu_r571_astra_integrator_bridge.md` | `8e7226dc13cff2d726b5058ad0f7fe1adf0eb45fe23f2e669484a4f18b67f6eb` |
| `/tmp/ccu_r571_history_bridge.md` | `5271786332e08352e9fdbffc1a74585353552b14a63893a166af337405a8ffef` |
| `/tmp/ccu_r571_audit_history_contract.md` | `6d171d51204771291f7815df8d3996b4ee7936f191fefd30fde8b7b289bb6fe2` |
| `/tmp/ccu_r571_audit_adjoint_bridge.tex` | `a17f0e64c9679121ba7abba652a84f50f3e710b90d5d9f6344cfa29af35ac810` |
| `/tmp/ccu_r571_actions_attack.tex` | `05dea4495148d2a21e73b6762d1d02fd2ac07952ec75d9109298e4d081a2e842` |
| `/tmp/ccu_r571_audit_actioncurve.md` | `c6e008da2868354a25baf44bf3ed5f69618f270437a7bae0a73421ea25abdd08` |
| `/tmp/ccu_r571_core_attack.tex` | `489ba9a552e818018b39a12c283dc8677ddc56922c567eccb0541182e25ad5cc` |
| `/tmp/ccu_r571_astra_clock_attack.tex` | `293877eb6c515b01a99c6917e71cb45fbe0ff46ebc396281d55c6388d97d1c21` |
| `/tmp/ccu_r571_audit_clock_growth.md` | `2ceab244c6b53f0d53c74bb50db5ef10ba5970b5a772c29de1f2ad0b58d8e663` |
| `/tmp/ccu_r571_audit_smallgrowth.md` | `995eb53ab308151fa359897ee727bf8cc62a154f806c7debe1805ccd2d9419b9` |
| `/tmp/ccu_r571_astra_lowtail_attack.tex` | `f67aa609a2f471b2bfdd1b9aad2ddab29065457b6ff96b889aadac774e84d793` |
| `/tmp/ccu_r571_audit_lowtail.md` | `fd10799215e1085fae8d6796bd032a8a830f4ed762678be01fe17d8eac8ed736` |
| `/tmp/ccu_r571_gamma_budget_audit.md` | `649a808890d0ef40e704bf97e069b2aa9c581a0a7d1795de4c7f9cef315007db` |
| `/tmp/ccu_r571_parameter_certificate.md` | `2520fbcc7497ae7c807747df2def7af2a2c02ff470101c376e0c5dff63e2fa20` |
| `/tmp/ccu_r571_parameter_certificate.py` | `98a3edd709c8d1d46e7764fc7ce82ceed4fbfabd49cdf5325ba5fa9f490d6036` |
| `/tmp/ccu_r571_parameter_certificate.json` | `77a9d73e1d5186c31c4b095c41668094037444f95948951ac40be56bfd6c2277` |
| `/tmp/ccu_r571_generator_global.tex` | `6121834d7004e4fc33cfcb859848a8216d0f9be7ad047f7f92bec5ba3539e5f8` |
| `/tmp/ccu_r571_energy_global.md` | `6708bb67e9b0bddd133a02ac1b3f94a7e413b6ae706eedfced160c98e470dc1d` |
| `/tmp/ccu_r571_audit_waterfill.md` | `29039a8240c727f66f20f0717951aff680346432101f6cce3406c62b56b12999` |

## 最后新增定点审查：threshold_bridge §5–§6

本增补只认证两项明确新增命题；不将 graph 连接附录升级为 general payer。先从真实动作和质量独立推导，再读作者证明。所审文件 `/tmp/ccu_r571_sol_threshold_bridge.md`，SHA256 `aaf5e5a23daf474edcc710cf76a69d86b7aef2b388f387f0cce0173cac53f123`。

**§5 精确 d=1：通过。** 每个可达动作严格满足 κ_B(g_Bj)=Γ_j=γ^(jh)，故各真实窗口平移 −jh 后与原旧窗口完全相同。Σ_jx_Bj=Σ_jp_Bj/g_Bj≥1/G，且真实新盒包含旧盒，因此 Z_i≥Lbulk,i/G。对原冻结 Li 的一次直和 Cauchy 给
Q0−Edel≤G√(JQ0Bπ)，Edel≤C0(1+G)W。
所以阈值动作专用母式可取 Q0≤cW+G√(JQ0Bπ)，c=C0(1+G)，不再付 3h 窗移边费。若 Bπ≤aQ0+LW，严格吸收阈值为 a<1/(G²J)。与 Bπ≤2W+2Cstar_graph 连接时，Cstar_graph≤a_*Q0+L_*W 需要 2a_*<1/(G²J)。low/rapid 仍付一次，G 与真实 1/g 从未消失；这不改变指定连续 ρ/Yhat 的另一母式。

**§6 正确 child 质量排除：公式通过，主参数下触发为空。** 固定真实外槽 (C,j)，M=Γ_jm_C，ν=μ|Q_Cj/M；对正质量子节点 T 与来源前矩形 K⊂T，β_T=ν_T(K)，准确质量为
μ(K)=Γ_jm_C ν(T)β_T。
非零真实旧窗 tent 给 m_B<γm_C。于是只有在 Γ_jν(T)β_T≥γ 时，μK>m_B，真实旧盒才不可能包含 K。不能遗漏 ν(T)，也不能把根 M 分给每个 child。由 m_B>m_C/γ 和 q_B≤λ，R_B≥R_−=max(a,[m_C/(γλ)]^(1/n))；若 B∈V_K=Π[v_l−R_−/2,u_l+R_−/2]，其旧盒必含 K，矛盾。故实际中心排除 O_T(θ)∩V_K；可扣的量恰是这个交集的体积，V_K 空或不相交时没有收益。端点可按 μ-null 边界处理。

取 core 球外接矩形与 T 的交是合法来源前选择；β_T>5/8 限定在 Gate=1 的真实非空 core 分支。新 narrow 蕴含旧 narrow，原固定 head/core 可保留；此特定新增容量帽的 b_head 只变小，因此 Cstar_graph⁺≤Cstar_graph 可成立。它与改 ε 后重建 core/head 的情形不同，不能据此推得 gamma 重建的旧新单调性。

实际主参数给出决定性的限制：对同一新 bulk，
Γ_j≤κ_B(G)<max(γ^h,A_nα_B)≤max(γ^h,A_n)。
γ=A_n^16,h=1/256 时 γ^h=A_n^(1/16)<A_n<γ；γ=A_n^112,h=1/448 时 γ^h=A_n^(1/4)<A_n<γ。由于 0≤ν(T)β_T≤1，两个方案均严格有 Γ_jν(T)β_T<γ，故 (17) 在所有真实 contributing 节点上为空，Pexclude=P_T，Pjoint⁺=Pjoint。**此排除盒不能列为这两个主兼容参数下的有效改善。** 它只是一项一般参数下合法、当前主参数不用的几何约束；即使其他参数触发，也未给完整 a_*,L_*。

本机 SymPy 的最终组合脚本新增核定 γ^h 的指数 1/16、1/4 以及 A_n/γ 的指数 −15、−111。其余为上述对全部 A_n>1 的解析不等式，不用有限维扫描冒充一般范围证明。manifest 已固定该稿 SHA；待最终 REPORT 仅核文字是否保留本适用范围。
