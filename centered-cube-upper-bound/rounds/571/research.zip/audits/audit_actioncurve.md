# R571 all-action curve and actual product graph: independent audit

## Verdict and exact scope

**PASS, with the following independent strengthening incorporated by the author:** extract the fixed actual `(C,v,j)` old-mass window before dropping inner action gates. This permits `Hph`, rather than the larger `Hold`, and retains `r_C ≤ R_A/I_C`, where `A=2GS Hph`, `R_A=min(K,A)`. The resulting complete source payment is for the actual-row replacement Cauchy of the same original demand; it is not the assertion `V_G ≤ Vcap`. The product-graph manuscript passes its local-to-complete-invoice identities, but its remaining weighted source integral is unpaid.

Original audit and audit_next are frozen. Only this file is written. No numerical search, children, PDF, or other author's file changes.

## 1. Independent action comparison and the decisive order of operations

Fix an actual outer `(C,v,θ)` and write `M=M_C(v)`, `j=j_C(v)`. On the original nonzero same-phase and true-tent support,

`γ^(jh) ≤ κ_B(g) < γ^((j+1)h)` and `M/γ < M_B(g) < γM`.

Consequently every contributing B satisfies

`M/γ^(1+(j+1)h) < m_B < γM/γ^(jh)`.

This is a condition on physical B and the fixed outer state; critically it does **not** depend on B's action g. Retain this domain, first sum the genuine first-stop antichain so its total gate is at most one, then discard the remaining nonnegative gates bounded by one and integrate the actual old-source probability. This bounds the complete h_C by the integral of `1_QB(g)(y)` over the full, unconditioned original ρ_B. It does not assert a comparison for a phase-conditioned law.

For `π0=ω/Λ`, the functions `F(g)=1_QB(g)(y)` and `d(g)=κ_B(g)^(-1)` are respectively nondecreasing and nonincreasing. The two-copy covariance identity gives `Eπ0(Fd) ≤ Eπ0 F Eπ0 d`, so

`EρB F ≤ Eπ0 F = Λ^(-1) ∫F dω`.

All endpoint atoms and plateaus are included. The denominator `Eπ0 d=I_B/Λ` is strictly positive. This uses the actual restored law, not a new physical action. The original χ, old σ, source cells, head/core/history and fixed full/far scope survive in the definition of h; dropping gates occurs only in this upper bound.

If a source restriction makes the integrated old law a subprobability, its mass is at most one and the upper bound remains valid. Replacing restricted outer mass by full `M_C(v)` is likewise an inequality unless original containment supplies equality.

## 2. Actual radius graph, full action moment, and no repeated normalization

The extracted B domain gives actual side bounds

`L^n=M/[γ^(1+(j+1)h) λband]`, `U^n=γM/[γ^(jh)q]`.

Thus `1+n log(U/L)=Hph=1+log(γ^(2+h)rband)`. Clipping to the original allowed side range can only improve this bound. For each g,y, the layer identity on the **actual graph** R_B gives

`∫ a_B 1_QB(g)(y)dB ≤ Sg[1+n log(U/L)]=Sg Hph`.

Indeed write `R^(-n)=U^(-n)+n∫_R^U t^(-n-1)dt`, and use nested center cubes of volume `g t^n`; there is no free-radius integration, no extra factor 2^n, and no assumption that R_B is continuous. Applying the full-action comparison and `∫g dω=2G` yields

`h_C(v,θ) ≤ (A/Λ)M_C(v)`, `A=2GS Hph`.

Averaging the unchanged outer ρ_C gives `r_C=Eρ,dθ h_C/m_C ≤ A/I_C`. Separately, the previously verified restored field estimate gives `h_C≤Fcap M_C(v)`, hence `r_C≤K/I_C`, not merely K. Therefore

`r_C≤R_A/I_C`, `R_A=min(K,A)`.

This is one restoration followed by its exact mass moment `Eρ κ=Λ/I_C`; I_C is not discounted twice. The earlier point-state cap was `R0=γ^h A`. This genuinely sharpens the available average-row bound, but arbitrary state-dependent φ still requires its own point-state certificate. Do not substitute the average `R_A/I_C` into the earlier unrestricted state-score theorem.

## 3. Complete source payment, plateaus and high growth

The already verified exact row score `f_C=ell_C/r_C` on positive-demand parents pays exactly one Qfr; zero r parents have zero conditional demand. Its fee is

`Vcap=∫ a_C m_C r_C²/ell_C dC`.

Consequently

`Vcap ≤ R_A² ∫ a_Cm_C/(ell_C I_C²)dC ≤ R_A² Dclk W`.

This is a new Cauchy for the original demand M_G; it does not compare the old inverse-Lz fee pointwise with Vcap. The frozen old-field reciprocal source lemma still uses the same real old source measure, same clock interval and one W. No σ or Li is shifted here.

For the independent source bound, put `c=γ^h`, `L=Λ−1>0`, `b_C=max(c,A_n α_C)`. The original atom at g=1 has κ=1, and all other ω mass totals L. Therefore

`I_C≥1+L/κ_C(G)≥1+L/b_C`, `r_C≤R_A b_C/(b_C+L)`.

For a fully flat mass curve I_C=Λ exactly, so this is consistent with its full normalization. For high growth the factor approaches one; no uniform high-growth suppression is claimed. The bulk relation is essential: using merely κ≤A_n would lose the joint relation with α.

Let x=A_n α_C∈(1,A_n]. Then

`α_C^(-1)[max(c,x)/(max(c,x)+L)]² ≤ A_n max{c²/(c+L)²,1/(4L)}`.

On x≤c use x>1. On x≥c use `x/(x+L)²≤1/(4L)`. This also covers A_n<c. With `ell_C=C0 α_C` and the single inherited `∫t_Cq_C≤S A_n W`,

`Vcap ≤ [R_A² S A_n²/C0] max{c²/(c+L)²,1/(4L)} W`.

Thus the minimum of this coefficient and `R_A²Dclk` is a valid full auxiliary fee. These are alternative payments of the same positive fee and cannot be multiplied. Neither A_n nor Dclk may be replaced by log n. Strict improvement over the earlier uniform bound depends on the active minima; the new input-sensitive I_C factor is valid regardless. All conclusions are on the fixed finite primitive. A cutoff-independent theorem still requires further source/score geometry and the inherited outer limits.

## 4. Product manuscript: same numerator, old clock, and full invoice

Audited `/tmp/ccu_r571_product_next.tex`, SHA-256 `e60320c0c5ee9d5a54b5ee95f322edef4fdaf6c0431c283e559f49aa360bdf53`.

**PASS** for pn571:exact/radius/two/harmonic/full and the stated row constraint. With `σ=s_B+θ`, the frozen Li remains at its actual σ. The factors are exactly

`F_g=(M/γ)∫ a_B χ/(I_B M_B(g))dB`, outer coefficient `γ t_Cq_C/(I_C M²)`.

Their product reproduces both restored laws and the old `1/m_B`; there is no additional K. K is only in `a_λ=λ/K`. Extracting `1_QC(v)` or `1_Lz>τ` outside χ is harmless when already present (idempotent indicators).

Intersect the true phase interval with `γ^(σ−1)/λband ≤ R_B^n ≤ γ^σ/q` and the original side interval. The latter condition is exactly the real old window, including its endpoints. Empty intersections contribute zero; equality L=U retains the endpoint capacity term. The nonempty graph has `n log(U/L)≤log(γrband)`. The actual Σ_C support follows from old mass compatibility and θ∈[0,1].

The certified nested two-cube center graph gives `F_g≤min(Lz,Aσ)`, with the entire coordinate product kept inside the real correlated μ_i⊗μ_i integral. Each one-dimensional factor is bounded by the corresponding exponential of its positive separation excess, so `Aσ≤C0 exp(−E)` follows with the stated C0.

For `x>τ`, the function `min(x,A)/(a x+b)` increases until x=A and decreases thereafter. Hence the sharp supremum is `A/[a max(A,τ)+b]`; when A<τ it is an endpoint supremum, not an attained maximum. This proves the harmonic inequality and its complete invoice. It does not pay the outer source integral. The far display uses `ell=C0α` correctly and keeps the inverse α cost.

Finally integrating actual F_g over the old z box and σ window cancels m_B and leaves `(M/γ)a_B/(I_B κ_B(g))`. Bounding this by its same-phase cap and the actual receiver graph yields the author's row constraint. It must be used on F_g itself, not multiplied into the independently relaxed Aσ invoice as an extra discount.

## 5. Verification and freeze status

Local prescribed Python/SymPy was actually run. It returned `(L−x)/(L+x)^3` for the scalar derivative, `(L−x)^2/[4L(L+x)^2]` for its nonnegative maximum residual, `γ^(−h)` for A/R0, and the correct positive/negative harmonic derivatives. These are algebra checks; the all-action and graph assertions are proved above, not inferred numerically.

Original actions_attack manuscript using Hold was already a valid weaker statement. Its independent refinement to fixed `(C,v,j)` Hph and the retained K/I_C is communicated to the author; final revised-file hash is recorded below after checking the author's incorporated revision. No new global product-source payment is claimed.

Final revised actions_attack checked: SHA-256 `476d8f49fbc21462e7e9945a2ab1fd07af780856bcfb1ad060ddb0a039fbc905`. AA4–AA8 now use the fixed outer phase window and Hph; AA1/AA2 retain Ract/I_C; AA10–AA13 correctly use Ract² in the alternative source bound. **Final PASS** for AA1–AA13 with the scope stated above. Product hash unchanged. No outstanding correction for these two assigned manuscripts. This bounded audit is complete.
