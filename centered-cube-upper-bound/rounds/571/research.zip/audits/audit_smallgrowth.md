# R571 independent audit: small actual growth into an old receiver

**Verdict: PASS for the stated branch inequality, with a required scope clarification before claiming new payment in the frozen mother formula.** The formula

`V_epsilon := integral (r_C^epsilon)^2/ell_C d tau(C) <=16 P0 epsilon S An W`

is valid under the inherited physical measure and bulk/source contract. It is not a bound for the entire Vcap. Moreover, the frozen remaining gate already removes `N_delta`, with `delta=(S An)^(-1)`. Thus this small-growth branch is identically zero whenever epsilon<=delta. In particular, epsilon=1/An gives an empty branch in all current S=1 diagnostic models. This prevents interpreting its constant bound as newly paying a nonempty part of those models.

Audited source: `/tmp/ccu_r571_core_attack.tex`, especially attack:receiver, attack:localoccupation, attack:smallgrowth and the final four-row split. The independent definition check used `/tmp/ccu_r565_archive/REPORT.tex` lines 40–73 and 108–114, `/tmp/ccu_r571_core.tex`, and `/tmp/ccu_r571_actions_next.tex`. No new numerical calculation was needed or run.

## 1. Definitions and the actual demand being paid

Write `d tau(C)=a_C m_C dC`, `ell_C=e_C/(a_Cm_C)>0`. Keep the entire frozen directed demand `chi deta0`, including the actual restored action laws, both endpoint atoms, original old z and theta, source cell, mass tent, phase, first-stop/core/head and previously frozen deletions.

Restrict that demand by

`y in Q_C(1)`, `y in Q_B(g) minus Q_B(1)`, and `kappa_B(g)−1<=epsilon`.

Call its nonnegative receiver density after integrating the original B,g,z,v,theta variables `R_C^epsilon(y)`. This is exactly the draft's expression. The averaged row is

`r_C^epsilon=(1/m_C) integral_QC(1) R_C^epsilon(y) dmu_i(y)`.

The draft's V_epsilon is the **exact-row inverse fee for this positive subbranch using its own row**, not the restriction of the full-row inverse fee Vcap. The distinction matters: the latter restricted fee would involve `r_C r_C^epsilon/ell_C`, with cross contributions. The final transmission inequality correctly accounts for this distinction.

If `r_C^epsilon=0`, its entire nonnegative conditional branch demand vanishes by Tonelli. The branch's row score may be assigned 1 there; no positive terminal demand is dropped. If it is positive, the score `ell_C/r_C^epsilon` gives branch credit at most Qfr by the same exact conditional integration as the full-row construction. This fact alone does not allocate Qfr separately to every branch in a sum; the mother formula must retain the cross terms described in Section 6.

## 2. Receiver-local score and Cauchy are valid on the same source

For the original fixed source y let

`T_y(s)=integral (1−|s−t|)_+ nu_y(dt)=integral_s^(s+1) L_i(y,u)du`.

The actual old-source identity is

`ell_C=(1/m_C) integral_QC(1) T_y(s_C)dmu_i(y)`

under the inherited old-box containment. With merely cell-restricted integration, the right side is at most ell_C, which is still sufficient for the upper-bound Cauchy step.

Cauchy at each actual C yields

`[(integral R dmu_i)^2/(integral T dmu_i)] <= integral R²/T dmu_i`,

hence

`V_epsilon <= integral a_C 1_QC(1)(y) R_C^epsilon(y)²/T_y(s_C) dC dmu_i(y)`.

This is an upper bound for the branch's already-defined exact-row fee. It does not replace the original demand source z by y. The variable y is the same receiver present throughout R.

There is also a direct way to validate the receiver-local expression if it is called a score: on nonzero receiver fibers take `f(C,y)=T_y(s_C)/R_C^epsilon(y)`. Its full original branch credit is

`integral chi_epsilon f deta0 =integral a_C 1_{R>0} T_y(s_C) dC dmu_i(y) <=Qfr`,

and its inverse fee is the displayed local integral. This total credit verification is essential; an arbitrary receiver-dependent score would not be justified merely by its name.

The zero-denominator issue is harmless but should be explicit. For half-unit bins I_j, let M_j=nu_y(I_j) and m_j=beta_y(I_j)<=M_j. If M_j>0 then T_y>=M_j/2 on I_j; if M_j=0 then beta_y(I_j)=0. Consequently T_y=0 is null for beta_y, hence null for the actual product measure `a_C1_QC(1)(y)dC dmu_i(y)`. Fubini provides the required almost-everywhere fixed-C interpretation. No positive receiver demand is removed to enforce this.

## 3. The pointwise P0 cap and actual actions

The inherited physical radius-graph estimate, applied at fixed C,v,y, gives the actual inner B,g,z integral at most

`2GS Hph gamma^(−j_C(v) h)`.

The phase index is nonnegative because the physical cubes are nested and kappa>=1. Thus this is at most `P0=2GS Hph`. Averaging the actual rho_C probability and the original unit theta interval proves `0<=R_C^epsilon(y)<=P0`.

This pointwise estimate uses the true mass/phase support to constrain the measurable radius graph before any gate is dropped. It does not use the merely averaged K cap as a pointwise bound. Both endpoint atoms remain in the identity `integral g omega(dg)=2G`, and I_B is never replaced by an action-dependent or renormalized weight.

## 4. The same-source reciprocal clock bound is valid

For fixed y and s_B, nonzero actual phase and tent imply

`|s_C−s_B|<1+h`.

Indeed same phase gives growth-log difference strictly less than h; nonzero new-mass tent gives new-mass log difference strictly less than one. Combining the two yields the old-mass window, without replacing the true tent by a value of one before this deduction.

On each half-unit bin I_j,

`integral_Ij beta_y(ds)/T_y(s) <=2 m_j/M_j<=2`,

with the zero-mass convention justified above. The interval `|s_C−s_B|<1+h` has length `2(1+h)<8/3`; the stated allowance of at most eight half-unit bins is conservative and valid. Therefore its reciprocal occupation is at most 16.

This is a bound on one fixed source's actual parent-start measure. There is no W for each mass level, no phase-count multiplication, and no conversion of singular/atomic start distributions into Lebesgue starts. Original mass atoms are expressly permitted.

## 5. Tonelli and the genuine new-source mass finish the branch bound

Use `R²<=P0R`, expand precisely the same R, and retain the derived old-mass window. Drop other gates only for a positive upper bound. At that point rho_C(dv) and dtheta integrate to one for each actual C; the original B old-source kernel integrates to one under containment (or at most one in the restricted-source variant). The C integral is now bounded by the same-source occupation constant 16.

The result is exactly

`V_epsilon <=16P0 integral a_B rho_B(dg) 1_{kappa_B−1<=epsilon} mu_i(Q_B(g) minus Q_B(1)) dB`.

The physical boxes are nested, so with the original full mass the shell mass is `M_B(g)−m_B=m_B(kappa_B(g)−1)`; restriction to the original cell can only decrease it. Therefore

`V_epsilon <=16P0 epsilon integral t_Bq_B dB <=16P0 epsilon S An W`.

The last inequality is the explicit inherited parent-mass coarse budget, R565 REPORT line 68. The proof charges this source budget once. No thin-shell Euclidean volume assertion is used, and no conditional action law is renormalized after selecting small growth.

## 6. Four rows cover the full support, but their squares do not add

On the true support `y in Q_B(g) intersect Q_C(v)`, these cases partition every tuple:

1. y belongs to both old cubes: row r00.
2. y belongs to old C but not old B, and growth<=epsilon: row r_epsilon.
3. y belongs to old C but not old B, and growth>epsilon: row r_high.
4. y does not belong to old C: row r_outer, including both old/new B possibilities.

All original gates remain in each row. The growth equality boundary belongs to the second row, so there is neither omission nor overlap. Their rows add exactly to r_C.

For a fresh splitting parameter eta>0, set `r_rem=r00+r_high+r_outer`. The valid complete transmission is

`Vcap <=(1+eta) integral r_rem²/ell_C d tau + (1+eta^(-1))16P0 epsilon S An W`.

Use eta rather than delta for this splitting parameter to avoid collision with the already-fixed deletion threshold delta=(SAn)^(-1). This follows directly from the weighted two-term square inequality and pays all cross terms. It does not give each subbranch another Qfr.

The displayed low-score Minkowski version is also valid once the separately proved edge-credit inequality is used: the part of r00 capped by ell_C costs at most `C0 q_* S W` on alpha<=q_*/An; its excess is bounded by h b_C; the epsilon row has the paid norm; high and outer remain together inside their full squared norm. The terms cannot be read as a completed full-fee bound while that last norm and the remaining parent set are unpaid.

A minor neighboring repair is needed for the edge-credit presentation: b_C uses a **strict** old-mass interval whereas B_y is defined using a closed interval. Original starts may have atoms, so the printed identity `b_C=(1/m_C)integral B_y(s_C)dmu_i` need not hold. Replace that identity by <=, which suffices for the Cauchy/edge-credit upper bound, or define B_y with the same open interval. This does not affect attack:smallgrowth.

## 7. Required clarification: overlap with the already deleted branch

The actual frozen remaining object is

`R=N_delta^c intersect {Lz>tau}`, where

`N_delta={y in Q_B(g) minus Q_B(1), kappa_B(g)−1<=delta}`,

`delta=(SAn)^(-1)`.

These are explicit in R565 REPORT lines 108–110 and remain inside the present frozen chi. Accordingly,

`chi_epsilon=chi·1_{y in old C}·1_{new B}·1_{delta<kappa_B−1<=epsilon}`.

This exact identity gives the legal interpretation:

- epsilon<=delta: the new branch is identically zero, so its exact fee is zero.
- epsilon>delta: only the additional growth band `(delta,epsilon]` can remain.
- epsilon=1/An and S=1: zero branch, including the equality boundary.
- epsilon=1/An and S<1: still zero.
- epsilon=1/An and S>1: a potentially nonzero band exists, and the stated constant bound is valid for it.

The positive inequality is therefore correct, but saying that epsilon=1/An pays a new nonempty portion in the current S=1 setup would be false. Nor may the old already-paid deletion be charged again in the mother formula.

A different application could apply this lemma to a pre-deletion chi and redesign which original direct fee is used, or choose epsilon>delta and explicitly retain its added source cost. Either is a separate bookkeeping decision; neither is silently performed in this audit. The present safe mother-formula insertion is the norm transmission in Section 6, applied only to the actual residual growth band.

## 8. Necessary pressure check and audit scope

The dense diagnostic's certified positive donor flow uses full-capture actions with kappa_B−1=1. For epsilon=1/An in that S=1 input it belongs to the high-growth row when the receiver is old C, or the outer row when it is not. It is not covered by this small-growth payment. More strongly, the frozen N_delta deletion makes the proposed small-growth branch empty there. Thus the actual dense-model evidence does not conflict with this lemma and cannot be used to present it as paying the known difficult donor flow.

No new model, counterexample search, numerical run, MATLAB calculation or geometry scan was needed. Only this audit file is written; other authors' sources and the repository are unchanged. The typo `chi\\,mathbf1` in the branch definition should be `chi\\,\\mathbf1` when the author next edits the TeX source.

**Final classification:** branch inequality PASS; complete four-row/cross-term accounting PASS; zero-demand and reciprocal-clock handling PASS with the explicit null-set justification; new-payment interpretation REQUIRES the inherited-deletion clarification; no complete Vcap or general dimensional payment is certified.
