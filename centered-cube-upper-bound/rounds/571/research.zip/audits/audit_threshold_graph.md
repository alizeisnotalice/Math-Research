# R571 threshold-graph bridge 独立预审

**当前判定：给定作者完整定义与以下对象相同，所报wide/exception各≤W、Bπ≤2W+2Cstar_graph的关键系数和量词成立。** 此处先独立推导，尚未把未读作者终稿当作已审；不认证Cstar_graph的来源付款或一般弱型闭合。

## 1. 精确对象：合法阈值图，不是任意π

固定新local_entry输入，a_B=R_B^(−n)、q≤q_B≤λ、r=λ/q，所有扩张盒在同一C_i内。设Γ_j=γ^(jh)，j可用当且仅当Γ_j≤κ_B(G)，并取

    g_Bj=max{g∈[1,G]:κ_B(g)=Γ_j},
    p_Bj≥0, Σ_available j p_Bj=1, x_Bj=p_Bj/g_Bj.

不可用j设p=x=0，不能给其虚构质量。真实μ绝对连续给质量曲线连续，阈值水平集非空紧，最大值可测。等号端点G、零增长平台j=0均保留。p仅依输入和父，不能在收到被积分来源后选择。

真实动作phase严格为j，窗起点s_B+jh。全部同j父对的窗Gram因此是

    T_BC=τ(s_B−s_C),
    Bπ=Σ_iΣ_j∫∫ a_B a_C x_Bj x_Cj T_BC
                      μ(Q_B(g_Bj)∩Q_C(g_Cj))dB dC.       (A1)

原1/(g_Bj g_Cj)准确留在x_Bj x_Cj，未使用恢复Yhat替代。

当T_BC>0，m_B/m_C∈(γ^(−1),γ)，故

    R_Bⁿ/R_Cⁿ=(m_B/m_C)(q_C/q_B)<D₀:=γr,
    g_Bj R_Bⁿ≤G D₀R_Cⁿ=:r_*ⁿ.                         (A2)

这里不再需要γ^h，因为质量阈值精确同j；但这不授权不同j父对使用(A2)。

## 2. 固定外父(C,j)的source树和中心图容量

固定可用外槽(C,j)，Q_Cj=Q_C(g_Cj)，M=μQ_Cj=Γ_j m_C>0，ν=μ|Q_Cj/M。共同矩形二分树只依此实际外槽。对每个实际内图父B，p_BjT=ν_T(Q_B(g_Bj))，首次p>3/4停止。来源树生成全Borel，条件期望收敛给精确反链分解，无终端漏项。根、零质量节点和阈值初始原子按history_bridge的已审定义处理。

取统一参考边长r_*=(GD₀)^(1/n)R_C；它不依内父B或其图值g_Bj。由(A2)，实际Q_B(g_Bj)包含于同中心Q(B,r_*)。因此固定(C,j,T,θ)，真实内父高捕获图的中心集被一个**固定边长**超水平集包含，联合分位/整数矩容量的min仍合法，给

    |{B:T_BC>0,p_BjT>θ,wide}|≤ε_d r_*ⁿ.                (A3)

这里绝不能反过来把g_Bj当成独立随机变量。正确证法是直接用固定r_*包含实际图，p_Bj≤1只在内系数上界中使用。r_*的G损失已明确付出。

同样，参考外中心盒O及p_*(B)=ν_TQ(B,r_*)上的ANOVA head完全与内g无关。取m_d使尾/δ_head²≤ε_d，真实high-capture exception中心体积也≤ε_d r_*ⁿ。若m_d被n截断，尾为0。该论证的product结构是Lebesgue中心盒，不是来源坐标独立。

## 3. 精确费用追踪：Γ_j不产生额外J

设W_BCj=a_Ba_Cx_Bjx_CjT_BC。首次停分解中的每项为

    W_BCj ·M ν(T)·1_stop·1_{p>θ}χθ(dθ).

固定(C,j,T,θ)，非零tent下

    a_Bx_BjT_BC=(q_B/m_B)(p_Bj/g_Bj)T_BC
                ≤γλ/m_C.                              (A4)

注意分母是m_C，**不是M**；若误写γλ/M将漏Γ_j。乘M=Γ_jm_C，再应用(A3)，并保外父系数a_Cx_Cj，内中心积分后至多

    γλ Γ_j ν(T) ε_d G D₀ R_Cⁿ a_C x_Cj
       =γλ G D₀ ε_d ν(T) Γ_j p_Cj/g_Cj.                (A5)

Σ深d节点ν(T)=1，阈值测度总质量1。所有外槽求和时

    Σ_j Γ_j p_Cj/g_Cj ≤ Kmax Σ_j p_Cj ≤ Kmax,           (A6)

其中Γ_j≤κ_C(G)<K_C≤Kmax=max(γ^h,An)。这是同一物理父的全部外概率，**不得先把每个p_Cj放成1后再数J**。内父p_Bj≤1的上放不会改变外父p_Cj仍须保留这一事实。

最后λ∫bulk dC≤r∫bulk q_CdC≤r An W，所以wide或exception各自满足

    Fee≤γ r G D₀ Kmax An (Σ_d ε_d) W.                 (A7)

取

    ε_d=[γ r G D₀ Kmax An (d+1)(d+2)]^(−1),
    Σ_dε_d=[γ r G D₀ Kmax An]^(−1),                    (A8)

两支各≤W。两者互斥并各有自己的同样预算，合计为2W；不是同一份W被声称付两次。这里无额外J、无遗漏Γ_j，无改变fullμ，也没有遗漏1/g外权。

## 4. 真实core及完整remaining object

根据ε_d重新设置k_d、a_d、L_d、m_d及全部narrow/head/core门，不能自动使用旧ε'_d的χ。source核心H_CjT依(C,j,T,r_*)，不依B。joint narrow令Gate成立，首次停p>3/4及核心质量>5/8给p≤2ν_T(Q_B(g_Bj)∩H)。head系数b=(1/p)∫1_{p>θ}1_narrow1_head χθ(dθ)∈[0,1]保全部门。

若作者定义

    Cstar_graph=Σ_iΣ_j∫∫ a_Ba_C x_Bjx_Cj T_BC
       Σ_{T∈S_Bj}b Gate μ(Q_B(g_Bj)∩H_CjT)dB dC,        (A9)

则完整正划分和(A7)精确给

    Bπ≤2W+2Cstar_graph.                                (A10)

它适用于上述任意可测阈值概率p_Bj；不适用于未给(A1)精确同j窗对齐的任意连续动作π。它也不自动给任意旧VG的payer应用权，因为(A9)权和新χ需另行匹配。

若将来证明Cstar_graph≤a_*Q0+L_*W，则新local_entry的吸收要求2a_*<d²/(G²J)。当前(A10)只是准确几何桥，Cstar_graph未付；阈值图的选择也没有因本桥自动成为最优或具有小能量。

## 5. 尚待作者终稿逐式比对

预审需核对作者最终ε_d常数、Γ_j availability、x=p/g、Cstar_graph定义与(A1)–(A9)一致。除这些逐式对应外，关键解析推导已独立完成。只写本角色审稿；未改作者稿、repo或他人文件。

## 6. 作者交换后的更强付款（已独立核，最终采用此式）

作者指出可以保留外父完整动作总L1而去掉(A6)的Kmax粗估。独立核算如下：由λ≤r q_C，(A5)的外积分给

    Fee≤γ r G D₀(Σε_d)
          ∫bulk q_CΣ_j Γ_j p_Cj/g_Cj dC.

积分恰为Σ_ij||A_ij||₁，因为真实动作质量是Γ_jm_C、窗长1。新动作边长P_Cj=g_Cj^(1/n)R_C∈[a,2aG^(1/n)]，对固定来源y，先以Σ_jp_Cj=1将每父的随机selector核支配于同一个径向包络，再对真实Lebesgue中心积分，得

    ∫bulk q_CΣ_j Γ_jp_Cj/g_Cj dC
       ≤Aact W, Aact=1+nln2+lnG.                         (A11)

因此wide/exception各≤γ²r²G Aact(Σε_d)W。最终可取

    ε_d=[γ²r²G Aact(d+1)(d+2)]^(−1).                    (A12)

这比(A8)少Kmax及旧An，其他tree/head/core参数必须随(A12)重新设置。此式无J、无Kmax，不把∫ΣΓp/g错误当≤1；所用新L1付款正是一般随机selector的真实来源包络。其余(A9)(A10)不变。预审§3粗式本身合法，但终审将以(A11)(A12)为作者最终常数，二者不混合。
