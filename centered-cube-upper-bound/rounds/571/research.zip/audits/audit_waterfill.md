# R571 independent audit: full real-action phase waterfill bound

**Verdict: PASS.** Independent derivation and final author-draft comparison are complete. The intended object is the **new local-entry complete field Bpi with t_B=1 and arbitrary source-before-receiver probability laws**, not the old frozen adaptive-rho inverse fee. No numerical experiment is needed for the derivations below.

## 1. Independent definitions and last-hit construction

Take the new local-entry source cells and original frozen Li, with old cubes contained in their source cells, q_B in [lambda/2,lambda], t_B=1, and the actual retained bulk. Let

`m_B=mu(Q_B(1))`, `kappa_B(g)=mu(Q_B(g))/m_B`, `s_B=log_gamma m_B`.

Since mu has an L1 density, boundaries of physical cubes have zero mu mass. Dominated convergence gives continuity of kappa_B(g) on [1,G]; nesting gives monotonicity, and kappa_B(1)=1. Joint measurability follows from the measurable physical center/radius field and Tonelli.

Set `Gamma_j=gamma^(jh)` and `jmax(B)=floor(log_gamma(kappa_B(G))/h)`. For every j from zero through jmax the threshold Gamma_j is reached. Its level set is a nonempty compact interval, so

`g_Bj=max{g in [1,G]:kappa_B(g)=Gamma_j}`

exists. Equivalently, on this reachable set,

`g_Bj=sup{g in [1,G]:kappa_B(g)<=Gamma_j}`.

The latter has a countable rational supremum representation, with the physical endpoints included if needed. It is measurable even when the level set contains no rational equality point; defining last hit by a supremum of *rational exact equalities* would be unsafe. No inverse differentiability or strictly increasing mass assumption is needed.

The selected physical action has **actual** phase j and **actual** mass window `[s_B+jh,s_B+jh+1]`. This includes j=0: if the old mass lies on a nontrivial plateau, g_B0 is its last point and can exceed one. On that plateau the new shell has zero source mass, but the factor 1/g_B0 still matters. If kappa_B(G) equals a threshold, the last selected action is G; if all growth is zero, g_B0=G.

There is no omitted reachable phase: every actual floor phase from zero through jmax has its lower threshold action. The construction does not represent every action or reproduce the original action law. In particular G need not be selected when its mass is not exactly a threshold. This is legal under the new local-entry arbitrary-pi contract. It would not preserve an externally imposed old endpoint floor or the frozen adaptive rho atoms; the result must not be imported into those different contracts without a separate mixture argument.

## 2. The complete old/new decomposition

Choose measurable nonnegative p_Bj summing to one over the reachable phases, and define x_Bj=p_Bj/g_Bj, extended by zero on unavailable j. Then pi_B is the actual finite discrete law with mass p_Bj at the actual g_Bj. The full phase field separates exactly as

`A_ij=O_ij+N_ij`,

where O is the action coefficient on the original old cube and N is the coefficient on the physical shell `Q_B(g_Bj) minus Q_B(1)`. Both use the same genuine shifted unit window and true phase. There is no source replacement or independent-coordinate approximation.

After translating the jth time coordinate by −jh, the old component is exactly

`O'_ij=integral_{bulk in Ei} x_Bj k_B dB`.

This exact common shift is why threshold actions are useful: no fractional window mismatch is left. The source measure and whole-vector cube captures stay unchanged.

## 3. Whole-Li old Gram and the nonnegative deficits

Let `Kold(B,C)=<k_B,k_C>` on the same source cell, and zero across cells. This is symmetric and nonnegative. Write

`e_Bbulk=<Lbulk,k_B> <= e_B=<Li,k_B>=C q_B alpha_B`,

where the last equality uses t_B=1 and `C=1+ln(2gamma)` from the new entry. The deleted and retained parents are all still present in the original Li used for e_B.

For every j,

`||O'_j||²=integral integral Kold(B,C)x_Bj x_Cj dB dC`.

The scalar inequality `2xy<=x²+y²` immediately gives

`sum_j||O'_j||²<=integral e_B sum_j x_Bj² dB`.

More precisely, define

`Dpair=(1/2) integral_bulk integral_bulk Kold(B,C) sum_j(x_Bj−x_Cj)² dB dC`,

`Ddel=integral_bulk(e_B−e_Bbulk) sum_j x_Bj² dB`.

Both are nonnegative, and the exact identity is

`sum_j||O'_j||²=integral e_B sum_j x_Bj² dB−Dpair−Ddel`.

Missing phases must be extended by x=0 before the pair sum. These deficits concern the actual whole frozen old Gram, including cross terms with deleted parents through Ddel. They are not new credit budgets.

## 4. The shell cap applies to arbitrary discrete p

For each phase, the actual full field A_ij obeys the local-entry cap `A_ij<=C*=1+ln(2G gamma^(1+h))`. This is valid for any source-before-receiver probability law, including the current parent-dependent finite discrete law. A way to see this without invoking a continuous-action density is to bound the weighted sum at each B by the supremum over its legal physical radii. Actual mass, time and phase constrain that radius range; the geometric radius-envelope bound controls the resulting center integral. No absolute continuity of pi relative to dg is needed, and no endpoint weight is lost.

Because `0<=N_ij<=A_ij`,

`sum_ij ||N_ij||² <=C* sum_ij ||N_ij||_1`.

Every selected action's unit window has length one, and nesting gives the exact full source-shell mass `m_B(Gamma_j−1)`. The local-entry cell containment gives the same restricted mass. Therefore

`sum_ij ||N_ij||_1 =integral_bulk q_B sum_j p_Bj(Gamma_j−1)/g_Bj dB`

` =integral_bulk q_B sum_j (Gamma_j−1)x_Bj dB`.

This is a single total shell invoice over all phases. It does not attach a separate W to each phase or discard cross-parent shell terms.

## 5. One Young inequality pays all old/new cross terms

For a fixed epsilon>0, apply the Hilbert-space inequality once in the direct sum of all cells and phases:

`Bpi=||O+N||² <=(1+epsilon)||O||²+(1+epsilon^(-1))||N||²`.

Combining the exact old identity and the complete shell cap gives

`Bpi <= integral_bulk q_B[(1+epsilon)C alpha_B sum_j p_Bj²/g_Bj²`

`                  +(1+epsilon^(-1))C* sum_j p_Bj(Gamma_j−1)/g_Bj]dB`

`       −(1+epsilon)(Dpair+Ddel)`.

Dropping the last nonpositive term gives the candidate stated by root. All actual old-new, old-old and new-new cross terms have been included by an equality or an explicit inequality. This is a direct complete-field estimate; it requires neither the old Cstar first-stop/core decomposition nor its history gates.

## 6. Waterfill minimization of the separable positive majorant

At a retained bulk parent let

`c_B=(1+epsilon)C alpha_B>0`, `b=(1+epsilon^(-1))C*`, `d_j=Gamma_j−1`.

The local optimization is

`min { c_B sum_j x_j²+b sum_j d_j x_j : x_j>=0, sum_j g_Bj x_j=1 }`.

The feasible set is nonempty and compact, and c_B>0 makes the minimizer unique. Its KKT formula is

`x_Bj=[zeta_B g_Bj−b d_j]_+/(2c_B)`.

The scalar normalizing function `sum_j g_Bj[zeta g_Bj−b d_j]_+/(2c_B)` is continuous, starts at zero, tends to infinity, and is strictly increasing for zeta>0 because j=0 has d_0=0 and g_B0>=1. It therefore has exactly one positive solution equal to one. A countable rational infimum gives measurable zeta_B, hence measurable x,p and a legitimate actual probability kernel.

The identity at the optimizer is

`minimum =zeta_B−c_B sum_j x_Bj²`.

The bulk lower score bound excludes c_B=0. If the statement is extended beyond bulk, that zero-coefficient case must be separately defined.

This optimizes only the separable nonnegative majorant. The deficits Dpair and Ddel depend on the full family, so this pointwise minimizer is not thereby an optimizer of the deficit-corrected nonlocal bound or of the actual Bpi. Likewise no polylog source estimate follows merely from writing the waterfill formula; the integral of the optimized values still needs a genuine geometric bound.

## 7. Mother-formula position and limits

The new local-entry theorem accepts every legal pi and yields

`Q0 <=2C(1+G)W/d +G² J Bpi/d²`.

The present construction supplies one such pi and an upper bound for its **complete** Bpi, so it may be substituted directly into this mother formula. The original old field, scores, low/rapid deletion and parent set remain fixed. No claim that this pi preserves the old adaptive law or endpoint floor is made.

What remains is to control the actual integrated waterfill majorant, possibly using the exact deficits, at the scale required by the local-entry theorem. Until that is proved, neither the complete geometric budget nor a dimensional weak-type conclusion follows.


## 8. Final author-draft comparison

Read the complete final `/tmp/ccu_r571_generator_global.tex` after completing the independent derivation above. Its audited SHA256 is `6121834d7004e4fc33cfcb859848a8216d0f9be7ad047f7f92bec5ba3539e5f8`.

- GA1–GA3: PASS. Continuous monotone actual mass, measurable last hit by rational sublevels, exact threshold phases/windows, and the plateau comparison with the genuine 1/g factor are correct. No rational-equality selection mistake remains. The author correctly limits the law to the new entry.
- GA4–GA5: PASS. The whole old field is frozen, actual old-source overlap supplies the Gram, unavailable phase coefficients are zero, and both nonnegative deficit terms have the correct signs and normalizations. Cross terms with deleted parents are retained through e_B, not recharged.
- GA6–GA7: PASS. The arbitrary-probability phase cap applies to the discrete parent law; true shell mass supplies the linear growth invoice; one direct-sum Young inequality pays every old/new cross term. Translation is the actual time-translation isometry, so it also preserves the pointwise field cap.
- GA8–GA9: PASS. Positive bulk score ensures strict convexity, the j=0 action ensures unique positive multiplier, and measurable normalization gives a legal source-before-receiver law. The author expressly restricts the optimality claim to the separable positive invoice.
- GA10: PASS as a precisely stated **unproved sufficient condition**. Inserting Bpi<=aQ0+L W into the new local mother requires a<d²/(G²J), as printed. The remaining geometric integral bound is not established by this audit.

No repair of the author's formulas was needed. The endpoints, plateau factors, original whole Li, arbitrary discrete probabilities, full cross terms and the different new/old action contracts were specifically checked. The author's already-run symbolic sanity checks were not repeated; this audit required no new numerical test. Only this audit file was edited.
