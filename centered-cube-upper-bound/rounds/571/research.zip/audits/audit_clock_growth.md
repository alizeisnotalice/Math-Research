# R571 independent audit: reciprocal clock potential and action-growth deficit

## Frozen verdict

**PASS** for the abstract clock inequality and arbitrary shared time-strip bound in `/tmp/ccu_r571_astra_clock_attack.tex`, SHA-256 `293877eb6c515b01a99c6917e71cb45fbe0ff46ebc396281d55c6388d97d1c21`.

**PASS** for the new AA8a–AA8d covariance remainder and full original new-capture/growth constraint in `/tmp/ccu_r571_actions_attack.tex`, SHA-256 `05dea4495148d2a21e73b6762d1d02fd2ac07952ec75d9109298e4d081a2e842`. Earlier AA1–13 audit remains applicable; this review concerns the new remainder block.

These are genuine quantitative constraints. The clock fee is one bulk–full Qfr, and the action remainder consumes no extra W/Qfr. Neither establishes the missing global absorption: the raw clock coefficient is generally too large for that role, and no uniform positive action-deficit lower bound is proved.

## 1. Independent reciprocal-potential test

Let K(t)=(1−|t|)+, 0≤β≤ν locally finite on R. For a bin I of length δ<1 and a finite measure ζ supported there, Tζ=K*ζ satisfies the POINTWISE lower bound `(1−δ)ζ(I)`. Thus ζ(I)>0 implies `p=ζ/Tζ` is finite. This pointwise fact legitimizes forming p, but alone would give the weaker reciprocal bound 1/(1−δ).

The stronger coefficient `cδ=1−δ/2` is valid by a separate energy argument, not a Jensen reversal. For every finite positive p on I,

`E_K(p,p)≥cδ p(I)²`.

Indeed K=1−distance on I×I and the exact layer-cake formula `E|X−Y|=2∫F(1−F)≤δ/2` applies also to atomic laws. For the specific p=ζ/Tζ, positivity and symmetry give

`E_K(p,p)≤(1/2)∫∫K[1/Tζ(s)²+1/Tζ(t)²]ζ(ds)ζ(dt)=∫ζ/Tζ=p(I)`.

Combining yields `∫ζ/Tζ≤1/cδ`. Taking ζ=ν|I and using β≤ν and Tν≥Tζ proves

`∫_I β(ds)/Tν(s)≤1/cδ`.

There is no inference from the mean of Tν to the mean of its inverse. A zero-ν bin has zero β mass. On positive-ν bins the local lower bound is strictly positive everywhere; a countable bin partition proves Tν>0 β-a.e. Local finiteness and compact kernel support also make Tν finite everywhere. Hence 0/0 may be set to zero without deleting positive receiver mass.

## 2. Global bin argument, atoms, and noncompact support

For half-open bins I_j of length δ, η another locally finite positive measure and m_j=η(I_j), a closed window of radius a about any s∈I_i lies in the bins |j−i|≤ceil(a/δ). This remains correct when a/δ is an integer: a point in either next bin has distance strictly larger than a because of the half-open endpoints. Endpoint atoms are therefore not lost.

Apply the reciprocal receiver bound binwise, then the ℓ² convolution norm for this finite positive mask. Its norm is at most 2k+1. The local energy lower bound gives `cδ∑m_j²≤∫Tη dη`. Thus

`∫ B_(a,η)²/Tν dβ ≤(2k+1)²/cδ² ∫Tη dη`.

This is a legitimate two-measure statement; η need not be bounded by ν. The only use of β≤ν was in the receiver reciprocal bound. Set η=β, a=1+h, δ=(1+h)/2. Then k=2 and cδ=(3−h)/4, giving

`∫B_h²/Tν dβ≤[400/(3−h)²]∫Tβ dβ≤[400/(3−h)²]∫Tν dβ`.

The final energy is bulk–full, not full–full. Noncompact measure families cause no hidden ratio-monotonicity claim: the proof applies directly to countably many bins using nonnegative sums and extended ℓ² inequalities. Equivalently, compact restrictions can be used with Fatou on the left and monotone convergence of the nonnegative energy on the right; local kernel/window support gives pointwise eventual agreement at every fixed s. One must not claim the quotient itself is monotone under restriction.

## 3. Physical old receiver, shared H, and absorption scope

For each actual source y, the pushforwards ν_y and β_y use the original weighted parent graph a_C dC and true old boxes, with β_y≤ν_y. In the fixed finite primitive they are finite: centers containing y lie in a bounded box and a_C≤S/a^n. Their triangular potential equals exactly the overlap integral of the frozen Li over the C-old unit clock window.

The author's source Cauchy inequality for b_C²/ell_C is valid on this SAME old probability. Multiplying by a_Cm_C, Tonelli gives exactly `∫T_y dβ_y`, whose integral in μ_i is Qfr. Zero potentials have no positive joint bulk-old-source mass by the preceding β_y-a.e. statement and Tonelli. The original demand's (z,σ) has not been shifted or recomputed; this is a payment using C's frozen score.

For any nonnegative shared H∈L²(dσ), the actual strip `[s+1,s+1+d]`, s∈I_j, is contained in an interval of length δ+d. These intervals overlap at most `ceil(1+d/δ)` times Lebesgue-a.e. Cauchy on the containing interval and the reciprocal receiver bound yield

`∫(A_dH)²/Tν dβ ≤ [(δ+d)ceil(1+d/δ)/(1−δ/2)] ∫H²`.

The stated choices δ=d for 0<d≤1/2 and δ=1/2 for larger d are valid; d=0 is zero. Boundaries of the covering intervals are irrelevant for the Lebesgue H energy, even when β has atoms. The source-level version requires one actual measurable H_y(σ) shared across the C receiver integral. It does not authorize choosing a different arbitrary H_{C,y} and then paying only one H_y energy. A variable nonnegative shift bounded by d is covered by containment in the same strip. The claimed low-field use remains conditional on a separately proved bound for ∫H_y²; spatial new-capture shells remain outside this payment.

The parent clock coefficient is C_h=400/(3−h)². An edge row bounded by h b_C costs h²C_h Qfr. If the supplied complete decomposition r≤ell+h b+g is proved elsewhere, Hilbert triangle gives the author's displayed whole-row bound, but its ell platform still contributes a unit Qfr coefficient. Neither this decomposition nor an absorbable payment of g is established by the clock lemma.

The displayed absorption warning is correct: hJ>log_γ A_n, while the scalar inequality has universal constant at least 9, witnessed by N≥2 equally weighted integer atoms and the ratio 9−10/N. Therefore the raw hB envelope alone cannot meet `2hJ√C_h<(1−3h)²` whenever log_γ A_n≥1/6. This is a limitation of that envelope payment; it does not assert that original history realizes the atomic extremizers or preclude using the remaining actual geometry.

## 4. Independent covariance remainder and original new-capture constraint

For each actual B,y let F_g=1_QB(g)(y), d_g=1/κ_B(g). Both original action atoms are retained. Algebra gives exactly

`Δ_B=(∫F dω)/Λ−∫F dρ_B`

`=1/(Λ I_B) ∫_(g>g') (d_g'−d_g)(F_g−F_g') ω(dg)ω(dg')`.

Nested physical cubes identify F_g−F_g' with the displayed shell indicator. The ordered double integral has no factor 2: the symmetric two-copy factor 1/2 is canceled by restricting to one order. Diagonal pairs contribute zero, including action atoms; mass plateaus give zero d difference. The expression is measurable and nonnegative, and Tonelli is legal in the fixed finite primitive.

The domain B_(C,v) was extracted from actual phase/tent BEFORE dropping g-dependent gates, and is independent of g. Hence the relaxed row is exactly its common-ω row minus D_C(v), where D_C integrates Δ_B against the actual μ_i(Q_C(v)∩shell). Bounding only the common-ω row by the graph cap yields

`h_C(v,θ)≤Aact M/Λ−D_C(v)`,
`r_C≤Aact/I_C−d_C`.

The subtracted D is not formed from an unrelated relaxation. Since the relaxed original-ρ row is nonnegative, D≤Aact M/Λ and the right side remains nonnegative. The inherited competing bound is K/I_C. Consequently AA8c's squared minimum is a valid upper envelope for the SAME exact-row fee. Its displayed reduction is a reduction of this envelope, not an equality for the true fee. No positivity lower bound for d_C is supplied.

The original g'=1 atom has unit ω mass and κ_B(1)=1. Keeping just those ordered pairs gives

`Δ_B(y)≥Λ^(-1)∫ρ_B(dg)1_(QB(g)\QB(1))(y)(κ_B(g)−1)`.

The g=1 term on the right is zero. This calculation retains I_B exactly, since `(1−1/κ)/(Λ I_B)=(κ−1)ρ_B/Λ` as measures. It also covers endpoint G and all intermediate actions.

In U_C, the defining old-source probability, original directed χ and every real mark are unchanged; only the nonnegative new-shell/growth weight is inserted. After the original first-stop sum, these other gates are bounded by one. Every nonzero term remains in B_(C,v). Thus `U_C(v,θ)≤Λ D_C(v)`. Average the actual outer action and relative clock once to get

`0≤u_C≤Λd_C`, hence `r_C+u_C/Λ≤Aact/I_C`.

The restriction to growth κ−1≥η gives the stated strengthened coefficient η/Λ on that actual new-capture row. It is not a new physical action or source selection. All old-capture and low-growth complements remain in r_C. Crucially one cannot replace Aact by min(K,Aact) in this additive inequality merely because r_C≤K/I_C separately. The manuscript explicitly preserves that distinction.

## 5. Actual checks and completion

Ran the prescribed local Python/SymPy. One exact three-action rational law gave covariance identity residual 0; Δ=19/124, the g'=1 contribution 9/124, and nonnegative residual 5/62. Symbolic clock constant residual was 0 and the h=1/3 endpoint was 225/4. These check factors and algebra only; the arbitrary-measure/action proofs are given above.

No correction is required for the audited formulas. A shared-H condition and the fixed finite-primitive scope are essential and consistent with the manuscripts. Further global absorption, positivity of d_C, and spatial growth-source payment remain OPEN. This assigned audit is complete; no new direction or outer ledger has been added.
