# R571 独立定义/历史适用性审查：新 local_entry 到 R561 几何记录

## 审查结论（先于 bridge 作者完整稿形成）

**R561 的 first-stop、联合 wide、head 与 core 可在新绝对连续来源、新父族及指定 adaptive 动作律上从头重建；它们不是旧外部删除历史的随机停止时刻。** 其完整树终端为零，head/core 的选择也不依随后收费的来源点。由这些新定义，可将新真实 action Gram 完整分成 wide、exception 与 Cstar 分支。

但存在一个必须修复的量词：**R561 的两项 `KwW` 付款不能凭现有证明推广到任意来源前概率核 π_B。** 它们固定 g 后使用未加权 Lebesgue 中心体积，再对共同动作测度 ω 积分。来源前只排除对随后 source 的依赖；允许 B↦π_B 为任意可测原子 selector，不能据此使用 fixed-g 体积帽。此点已即时通知作者及 root；作者确认完整 bridge 限定为当前 adaptive `ρ_B=ω/(I_Bκ_B)`，将它与 local_entry 的任意 π 母式分开。

审查不负责最终母式常数（由 integrator 独审）。以下只认证新记录的定义、局部几何工具适用性与直接费用覆盖。

## 1. 独立阅读范围与输入

已独立读取 R561 `/tmp/ccu_r561_archive/REPORT.tex` 第17–45、61–243、270–415、480–659、701–733行的定义和证明；新入口 `/tmp/ccu_r571_astra_local_entry.md` 第1–6节；以及 R565 REPORT 第70–114行中 lift/row/direct-fee 的明确接口。没有泛读全史。

新入口给予：绝对连续 μ=g dx、有限 W；互斥 source cells C_i；可测父 E_i、t=1、q_B∈[λ/2,λ]、R_B∈[a,2a]；全部合法扩张包含 C_i；冻结整父旧场 L_i；一次互斥 low/rapid/bulk；bulk 满足 `1/A<α≤1, κ_B(G)<max(γ^h,Aα)`。这些足以重新定义下列所有对象。原外部删除 history 不作前提，也不再引用它的信用。

## 2. Bπ 与 restored Gram 不得混名

令 a_B=t_B/R_B^n，ω=δ_1+dg/g+δ_G，ρ_B(dg)=ω(dg)/(I_Bκ_B(g))。新 action 字段的 coefficient 为 `a_B/g`，所以其真实 Bρ 的 ordered Gram 是

`[t_Bq_B t_Cq_C/(I_BI_C M_B(g)M_C(v))] × Θ_BC × μ(Q_B(g)∩Q_C(v)) × ω(dg)ω(dv)/(gv)`。

Θ 为真实同相位和单位质量窗 tent。**`1/(gv)` 必须保留。**

另定义 restored 字段 Yhat，coefficient 为 a_B，动作仍为同一个ρ_B。其 Gram 与上述完全相同但没有 `1/(gv)`，正是 R561 式(14)–(16)的结构。这是一个新定义的真实场，不是把 Bρ 的因子无声取消。若 bridge 独立使用 Yhat 证明入口，须在场及剩余项名称中一直区分。

本机 SymPy 已实际验证两种 Gram 代数的对应，精确残差0；这只核代数，不认证几何付款。

## 3. first-stop 的“history”究竟是什么

固定新外父动作 (C,v)，置 M=μ(Q_C(v))>0、ν=μ|Q_C(v)/M。以 Q_C(v) 为根，沿坐标循环作几何中点二分，产生共同可数矩形树 T_d。树只依 (C,v)，所有 B,g 共用。

对每个固定 (B,g) 取从根向下第一次满足 `p_T=ν_T(Q_B(g))>θ0=3/4` 的节点。这里的“第一次”仅是树深顺序，不是旧算法的删除/接受时间。每个父的停节点组成互斥反链，跨父可以重复，绝不作跨父互斥假设。

证明终端：将 source y 看成 ν 随机点，`ν_Td(y)(Q_B(g))` 是 dyadic 条件期望，因循环树生成根盒 Borel σ 域，趋于 `1_QB(g)(y)` ν-a.e.。故 y∈Q_B(g) 的几乎每个点最终超过3/4并停止；其剩余质量趋零。由非负单调/支配收敛，

`ν(Q_B(g))=Σ_{T first-stop}ν(T)ν_T(Q_B(g))`。

该证明对每个固定真实 tuple 成立。无需让所有不可数 (B,g) 共用一个 source 零集；把可测非负恒等式用 Tonelli 积分即可。AC μ 还确保几何边界为零；共同 dyadic 分化本身甚至不需要 source 坐标独立。

层蛋糕使用 `χ=θ0 δ_θ0+1_(θ0,1)dθ`。在已停节点 p>θ0 上，`∫1_{p>θ}dχ=p`。θ0 原子必须保留；这给完整原交质量，没有删除低 root-overlap 或任何 tree terminal。

## 4. head/core 是可在来源抽取前形成的共同几何对象

真实同 phase/tent 支持先给 `m_B/m_C<γ^(1+h)`，从而 `R_B^n≤D0 R_C^n`，D0=γ^(1+h)rband。对固定 (C,v,T,g)，定义参考边长 `r*=(gD0)^(1/n)R_C`。全部分位外盒 O、联合整数矩 K_k、P_T、ε_d、辅助次数 k_d、交互头 H_md 都在这一固定参数上定义。

* O 与 H_md 不依随后积分的 B；H_md 的正交是在 O 的未加权 Lebesgue product measure 上完成，绝不假称实际父权也是 product。
* core 取固定有理中心枚举中首个捕获 `>5/8` 条件质量的闭 l1 球与 T 的交。其选择只依 (C,v,T,g)，不依 B、层蛋糕 θ 或随后受计价的 y/z。
* gate `K_k>a_d` 保证该枚举终止。计数枚举和每个质量条件可测，所以 core 可测。narrow 存活蕴含 gate。
* core 条件质量>5/8，配合每个 stop 父 p>3/4，严格给 `p≤2ν_T(Q_B(g)∩H)`。没有把 core 换成原子，也没有声称 μ(H) 与旧 m_C 可比。

head 权 `b=(1/p)∫1_{p>θ}1_narrow1_head dχ` 在停节点 p>3/4 定义，满足0≤b≤1。乘同一 core 替换不移除 head 条件。于是 wide、exception、remaining 是对**同一新 ordered Gram** 的穷尽正分解；Cstar 只扩大最后 remaining，系数2来自上述真实 core 质量比较。

因此 source-before 合法性成立：动作先依据输入和父 B 决定；树/head/core 是在相应真实动作参数和已积分来源分布上确定的分析对象，不使用随后被积分的来源实现值来重选动作。core 中 `1_H(y)` 是保留需求的门，不是后验改变π。

## 5. 付款量词：adaptive 可过，任意 π 不能直接继承

R561 wide/exc 都先对固定 (C,v,g,T,θ) 给

`|{B:真实同phase/tent, 高捕获, 相应分支}|≤ε_d gD0R_C^n`。

然后用共同 ω(dg)，内系数≤γSλband/(I_BM)≤γSλband/M，外父的 `∫ω/(I_Cκ_C)=1`，以及中心总量 `∫tq≤SAW`。这一步确实只需要新局部几何数据，**不使用旧 deletion history**。

对 restored Gram，原 ε_d 总和1/(2GA)与`∫gω=2G`给每分支≤KwW，Kw=γ^(2+h)rband²S²。

对真实 Bρ，额外 `1/(gv)` 不仅保留，还可帮助付款：内1/g抵消中心帽的g，`∫ω=Λ=2+lnG`；外`∫ω/(vκ_C)≤I_C`。于是每分支≤`[Λ/(2G)]KwW≤KwW`。因此有严格的

`Bρ≤2KwW+2Cstar_raw^ρ`，

其中 Cstar_raw^ρ 自己也保1/(gv)。对 restored 场则是

`||Yhat||²≤2KwW+2Cstar_restored`。

两式的剩余项不可混用。它们各自都以同一完整新输入为对象。

对一般 π_B，fixed-g 体积帽本身仍真，但不能据此给其对 `dB π_B(dg)` 的小质量。最简单的量词诊断：g∈[1,2]，集合 `{B=g}` 对每个固定g的Lebesgue体积为0，而π_B=δ_B使联合图有正质量，乘1/g或1/(gv)也不会变零。这个例子只反驳该 Fubini/体积推理，不声称是原 cube/head 几何的反例。

因此可用的准确判词为：**指定 adaptive ρ 的历史/几何实例化通过；“任意新合法π均有同样2KwW”尚无证明。** 如未来要一般π，须另付其共同动作测度支配常数或证明新的 graph 体积工具。

## 6. lift、row 与两项直接费：没有外部 history 依赖

以下针对 restored Cstar（与现 VG 既定合同一致），而不是把它当作 Bρ 的 raw Cstar。

新记录直接照定义 lift：`x=(i,C,v,g,T,y)`，M=M_C(v)，

`w_x(B)=M Θ_BC b_head 1_{T stop(B,g)}1_QBg(y)/(γ I_B M_B(g))`，
`dXi=γ t_Cq_C/(I_C M²) dC ω(dv)ω(dg) Σ_T Gate_T 1_HT(y) μ(dy)`，
`dM=dXi w_x(B)k_B(z,σ)dB μ(dz)dσ`。

旧核在新μ上的积分是t_Bq_B，所以∫dM恰是新 restored Cstar。真实 tent 给M/(γM_B)<1，且I_B≥1，故0≤w≤1，从而`F_x(z,σ)=∫w_x(B)k_BdB≤L_i`。

**反链必须先合并。** 对每个固定真实父对和动作，停节点互斥且H_T⊂T⊂Q_C(v)，故

`Σ_T Gate_T b_T 1_{T stop(B,g)}1_HT(y) ≤1_QC(v)(y)`。

再用真实同phase/tent的中心包络取得 restored 相关字段帽

`Fcap=GS[1+ln(Gγ^(1+h)rband)]`。

这帽仅用实际 q/t/side 与源格包含，不用old history。对 fixed B 的 full lift row 于是满足`r(B)=∫w_x(B)dXi≤ΛFcap=:K`。该证明保原IB；它不是逐节点重新领K。

直接费可在这个新记录上独立证明：

1. 低旧场 `L_i≤τ`：先使用 full row，得到
   `M{L≤τ}≤K Σ_i∫1_{L_i≤τ}Lbulk,i dμ_i dσ≤Kτ D W=KW`。
   这里D是新旧窗共同支撑长度，τ=1/D。**不可先逐T用F≤L再无限累加Xi。**
2. 低增长的新来源 `y∈Q_B(g)\Q_B(1), κ_B(g)−1≤δ`：反链先合并，外字段≤Fcap，得到
   `M(Nδ)≤Fcap δ∫bulk t_Bq_BdB≤Fcap δSAW=Fcap W`，取δ=1/(SA)。

这两门的并集可按先Nδ再低L作互斥分解；粗预算至多(K+Fcap)W。余下精确为`R=Nδ^c∩{L_i>τ}`，没有遗漏端点、旧来源、相位或树史。

最后，`∫L_i dM=∫r(B)e_BdB≤KQfr`，Qfr=∫bulk e_B≤Q0。因此定义现合同的`V=K∫_R dM/L_i`后，Cauchy给`M(R)≤sqrt(Qfr V)`。所以

`Cstar_restored≤(K+Fcap)W+sqrt(Qfr V)`。

该段是新完整局部记录上的证明；不调用旧删除时刻、未来删除预算或旧入口恢复。所有这些只是一轮静态正分解。new local_entry 的一次 low/rapid 删除已经在其冻结score分账里完成，本段不再次消费它。

## 7. 独立审查状态

上述定义与直接费用证明在收到作者完整 bridge 前形成并已发送修复点。全局 weak 常数及新母式吸收由 integrator 另审。最终对照 bridge 文件的检查将另记于本稿后附，不回写作者稿或仓库。

## 8. 作者完整 bridge 交付后的定点对照：PASS（指定ρ范围）

已对照 `/tmp/ccu_r571_history_bridge.md` 完整稿，重点核 B2–B3、B6–B12、B13–B20。所审 SHA256：`5271786332e08352e9fdbffc1a74585353552b14a63893a166af337405a8ffef`。

* B2/B3 显式分开真实Aρ及伴随Yhat，真实Gram的1/(gv)保留；B12及B20的raw/restored剩余项分别定义，未互换。
* B6–B10 从新μ/父/动作重建共同树、首次停止、χ初始原子、联合wide、head/core，量词与本独审相符。B8明确拒绝任意B依赖Diracπ的fixed-g继承，关键修复已落实。
* B13的lift积分旧来源/旧窗给q_B，准确回到新Cstar。其合并系数与B19的`ν_C μ(dy)μ(dz)dσ χ_new ν_B/m_B`一致。
* B14先合反链再用恢复场相位帽；B15先整row再付低旧场，没有逐T反复消费旧场信用。B16保原ρ归一，μnew/N准确变为(κ−1)/κ，不缺IB。
* B15/B16从尚未扣除这些门的新完整Cstar作一次正划分，余项恰为R，旧门没有再付。B18的Cauchy两权使用同一dM与同一Li，Qfr≤Q0合法；B20的raw版另保1/(gv)。
* χ_new 的physical B/C、同phase/tent、old z/旧窗、core/head/firststop及Nδ补集都明确，0≤χ_new≤1由反链先合并得出。无旧globalhistory假设悄然插入。

**最终定义/历史适用性结论：PASS。** 其范围是新local_entry的指定adaptiveρ及新生成的完整记录，支持两个对应的2KwW+2Cstar分解及direct fees全覆盖。它没有证明任意π的wide/exc付款，也没有证明VG_new的目标几何预算。最终母式系数不属本审查结论，交integrator复核。

本机Python/SymPy另实际检查4项精确恒等式，分别为raw Gram因子、lift到VG系数、低增长row归一及Cauchy的K消去，全部PASS；输出 `/tmp/ccu_r571_audit_history_contract.checks.json`。这些计算只核代数；firststop、可测性、共同ω适用性及完整覆盖由本稿解析审查给出。
