# R571 六项主结论：精简 proof/audit 归档依赖核查

本核查只检查证明来源、附件闭包与陈旧交叉引用，不重做数学审查，不将作者 PASS 当作数学证明。已读 sol_release_audit / live_next，并定点读取下表所列实际证明及其必要上游。只写本文件；未改仓库、他稿，未启动子代理，未做重复数值计算。numeric 文件由独立负责人管理。

## 结论

建议 **22 份核心 proof/audit 附件**；若 REPORT 实际叙述 lowtail restricted-square 命题，再加对应 proof+audit 共 **24 份**。关键的容易漏归档链是 `actions_attack.tex → actions_next.tex → core.tex`：不能只保留最后 attack 稿，因为实际行定义、完整同 demand 的合法替代 Cauchy、旧分数倒数来源付款写在 actions_next，原测度/反向帽写在 core。history_bridge 给新输入上的适用性；R561/R565 只作明确定位的已发布历史引用，不复制其 REPORT。

最终 REPORT 应在同一处明确：把 core/actions_next/actions_attack 的实际 row 论证实例化到 history_bridge 定义的同一个新 χ_new（改 ε 后为 χ'），而不是把旧合同的额外 history gate 搬入新记录。core 中按原合同写的系数 C0 与新 local_entry 的 C0 必须用新定义替换；证明只需其明确的 score/row 假设，不能混用旧 S[1+ln(γr)] 与新 1+ln(2γ)。

## 精简清单与六项对应

以下源路径均为当前绝对路径。归档目标可用去掉 `ccu_r571_` 的同名文件，建议置于 `proofs/` 与 `audits/`，并在 SOURCES 建立一对一映射。表中的证明号/章节优先于临时行号。

| # | 建议保留源文件 | 作用与精确引用点 |
|---:|---|---|
| 1 | `/tmp/ccu_r571_astra_local_entry.md` | 主项1：§§1–4，新 source cells、冻结 Li、一次 low/rapid/bulk、任意合法 π 母式 (13)–(15)。§5 只表示近优可行性；§6 为历史检查点，见下文。 |
| 2 | `/tmp/ccu_r571_cover_next.tex` | 主项1：G1–G11 的一般输入、真实 f_k、q_k 与一次 N_nW 总费；最终新入口组合在 REPORT/sol_release 明写。G13–G15 是旧入口条件式与另选变体，不作为新路线额外费用。 |
| 3 | `/tmp/ccu_r571_history_bridge.md` | 主项2：B2/B3 区分真实 Aρ 与伴随 Yhat；B6–B12 重建树/head/core；B13–B20 lift/row/低支；B21 完整伴随母式。 |
| 4 | `/tmp/ccu_r571_audit_history_contract.md` | 主项2适用性审查：§§2–6 及 §8 完整新记录、零树终端、fixed-g 仅指定 ρ、真实 1/(gv)。 |
| 5 | `/tmp/ccu_r571_audit_adjoint_bridge.tex` | 主项2系数审查：伴随独立窗移测试、B21 系数、direct fees 与两种阈值不能互换。 |
| 6 | `/tmp/ccu_r571_core.tex` | 主项3必需上游：原 dη0/χ/h_C、实际半径图 `r571core:graph`、反向帽 `actualreverse`、完整均值信用与一次 Cauchy `replacement`。 |
| 7 | `/tmp/ccu_r571_actions_next.tex` | 主项3必需上游：AN1–AN2 实际行评分、M²≤Qfr Vcap 与精确行平方费；AN4 合法性；AN5–AN6 单次 DW 来源付款。AN7–AN9 为可选精化。 |
| 8 | `/tmp/ccu_r571_actions_attack.tex` | 主项3：AA3 covariance；AA4–AA8 先抽固定外 phase 的旧 mass 域后用全 action 曲线；AA1/AA2、AA8a–d、AA9–AA13，保 Aact 与竞争 K 帽各自作用。 |
| 9 | `/tmp/ccu_r571_audit_actioncurve.md` | 主项3：实际同 demand Cauchy 与 Hph/R_A 核准；其中 product_next 旁支不进入六项，见省略说明。 |
| 10 | `/tmp/ccu_r571_core_attack.tex` | 主项4：trichotomy、clock/edgecredit 的 196h²；receiver/localoccupation/smallgrowth；完整四行及其交叉的安全传递。 |
| 11 | `/tmp/ccu_r571_astra_clock_attack.tex` | 主项4：局部 reciprocal、同源 bulk–full Schur C_h=400/(3−h)²、实际 receiver、whole/threshold；单位旧平台明确保留。 |
| 12 | `/tmp/ccu_r571_audit_clock_growth.md` | 主项4：同一 ν/β、原子与零分母、实际 clock 与 covariance deficit 的定点审查。 |
| 13 | `/tmp/ccu_r571_audit_smallgrowth.md` | 主项4不可省的范围修复：其自有 row-square 不能作 full-row 线性限制；原 Nδ^c 下 ε≤δ 为空，保完整交叉。 |
| 14 | `/tmp/ccu_r571_gamma_budget_audit.md` | 主项5主要证明：ε'、k'/m'/head/core/χ' 全重建；wide/exc 各 S²W；无倒 ε' 费；p112 单独 edge 正确吸收与未付总账。 |
| 15 | `/tmp/ccu_r571_parameter_certificate.md` | 主项5备选 p16/q16 参数的解析证书、两个 clock 的区分及其限制；计算实现附件另由 numeric 负责人提供。若 REPORT 完全不提此备选，可删此文件，降为21份。 |
| 16 | `/tmp/ccu_r571_generator_global.tex` | 主项6：GA1–GA3 实际 last hit/可测概率；GA4–GA7 全 old/new/Young；GA8 waterfill 仅 separable majorant。 |
| 17 | `/tmp/ccu_r571_energy_global.md` | 主项6：完整 old Gram 精确 P−Dgraph−Ddel、不可重复扣 Ddel、完整新 shell；逐父 diagonal 证书门槛与其局限。 |
| 18 | `/tmp/ccu_r571_audit_waterfill.md` | 主项6：完整真实场、last-hit/端点/平台/旧场与所有交叉的独立核准。 |
| 19 | `/tmp/ccu_r571_threshold_graph_bridge.md` | 主项6新增关键实际证明：TG2 完整图；TG3–TG5 对整张 B→g_Bj 图的共同半径；TG6–TG12 一次真实 source 总量与 wide/exc 各 W；TG13 完整 Cstar_graph。 |
| 20 | `/tmp/ccu_r571_audit_threshold_graph.md` | 主项6图桥独立预推导、A1–A10；作为辅助审稿保留，最终 scope 以 sol_threshold_bridge/release 终审为准。 |
| 21 | `/tmp/ccu_r571_sol_threshold_bridge.md` | 主项6独立解析连接；§5 阈值专用 d=1 母式与吸收；§6 child ν(T) 因子、实际 old-mass 扣盒及其限制。 |
| 22 | `/tmp/ccu_r571_sol_release_audit.md` | 最终六项主清单、完整未付总账、两路线阈值、p112/p16 不混用；最后增补确定 d=1 与主参数下扣盒触发为空。不是用 PASS 替代上面证明。 |

条件附加（只有 REPORT 真正引用 lowtail 命题才收）：

23. `/tmp/ccu_r571_astra_lowtail_attack.tex`；
24. `/tmp/ccu_r571_audit_lowtail.md`。

两者只作 restricted row-square 与 LT15 的 √(DW) 限制说明，不增列为第七个完整 payer。若 REPORT 只用一句话说明该尝试没有支付完整量，release audit 的范围说明足够，不必添加这两份。

## 已发布历史依赖：精确最小定位

以下历史文件已在本机独立快照存在，其 REPORT 当前 SHA 与各轮 MANIFEST 相符。最终 SOURCES 应指向仓库中已发布轮次同名 REPORT，避免保留 `/tmp` 为唯一可访问来源；不用把这些 REPORT 复制入 R571。

- **R561 REPORT**：本机核查 `/tmp/ccu_r561_archive/REPORT.tex`，SHA256 `2080a9e24207d3c87a5190262f9773f2abf12920aa0ede0c89aea0b9e1d79229`。必要局部工具是 §2 的 first-stop/layercake (18)、分位中心体积 (19)–(24)；§3 全向量整数 range moment (26)–(32)、core 反推 (33)–(39)；§4 `ci:rectangle`、`ci:exponential`、`ci:tail` 与实际参考盒/异常体积 `ci:O`、`ci:degree`、`ci:exception-volume`；§5 只在需要辨认旧完整剩余时引用。history_bridge 与 threshold_graph/sol_threshold_bridge 已重建本轮全部记录并重证应用步骤，因此不继承 R561 旧外层删除总账。可核查行段为61–243、270–425、480–659、701–733。
- **R565 REPORT**：本机核查 `/tmp/ccu_r565_archive/REPORT.tex`，SHA256 `de0128c6c06b19b06d47ef81f4f5bfb23ec340f974bd28e1259a8ebf5206bb79`。只需“统一原合同”与“继承的完整子费与冻结母式”（36–147行，特别40–73、108–114）定位旧 ν=aρ、冻结 Li、lift/row、Nδ 与完整 χ 的符号来源。新 history_bridge 的 B13–B20 自己给新记录上的完整 lift/direct/Cauchy，所以无需引用 R565 后续共同前沿/packing 或其依赖 R564 的实现稿。不能把 R565 的“旧 outer closure 未重新认证”当成本轮自主 local_entry 入口仍未接。
- **R570 REPORT**：本机核查 `/tmp/ccu_r570_archive/REPORT.tex`。它仅在 REPORT 交代基线、一般目标未证及旧 cutoff 比较时引用：§1、§3 C1–C4、§5 L1–L10、最终完整总账；不是这六项新证明的必需推导来源。保留基线提交 `eefb16334661928c150920b1e494f7ea164ed9dc` 即可定版，不需复制 R570 REPORT 或其旧合同。
- **R518/R520/R522**：local_entry §7 表明它们是阅读来源；§§1–4 已自主构造并证明，不以这些旧报告作必要推导前提。无需为此添加 R518/520/522 附件。

R561 的整数矩、ANOVA 工具与 R565 的合同定义均已有已发布 REPORT 内的实际证明/定义；不需要再把未发布临时 `r561_*`、`r565_*` 稿连入依赖树。

## 关键临时路径、陈旧状态与处理

1. **必须修复的附件闭包**：actions_attack 开头显式依赖 actions_next，后者依 core。三份均已纳入 #6–#8。core 依原“合同”的地方，应由 #3 的新完整 χ_new 定义和 REPORT 的明确实例化说明闭合；不能仅写一个未归档的 contract.md 路径。原 contract 还含旧 collar、旧入口常数与动态团队信息，不建议作为本轮主证明附件。
2. **过期缺口声明**：local_entry §6“仍需生成 head/core/stop”；astra_integrator_bridge §IV、§VI 的“当前没有新桥/旧 wide 消灭窗口”，均为 history_bridge/gamma_budget 完成前检查点。REPORT 应明示历史时态已被本轮后续文件更新，真实未付是同一新剩余的完整几何预算。不要修改他稿来制造历史一致性。
3. **cover_next 的旧入口条件式**：G13/G14 用 E_ent、G15 另加 J_n 的 own-crossing 变体都不是当前新 local_entry 必需步骤。正文明确只采用 G1–G11 与新入口组合；不要因保留整份 cover 而把这些额外费用加入新母账。
4. **audit_actioncurve 的旁支与旧 SHA**：该审稿 §§4 以后含对 `/tmp/ccu_r571_product_next.tex` 的独立旁支核准；六项主成果不用 product_next，故不归档该稿。审稿尾部保留一个旧 actions_attack SHA（`476d8f...`），release audit 固定的当前 SHA 为 `05dea449...`。最终 manifest 应按当前文件字节实测，不把旧审稿 SHA 当当前稿的身份保证；六项范围以当前 release 终审与实际公式为准。
5. **audit_threshold_graph 的“尚待终稿对照”**：这是预审时态；#21 已给独立实际推导与核准，#22 最后增补给 d=1/扣盒最终 scope。不要把预审 PASS 单独描述为作者终稿已完整终审。
6. **扣盒范围的最终修复**：sol_threshold_bridge §6 写其一般参数几何增强，release 最后增补证明两个主参数均 Γ_j<γ，故 Γ_jν(T)β_T≥γ 永不触发。REPORT 必须保留“主参数下收益为空”，不能以该增强为有效全量付款。
7. **参数文件的 conditional 时态**：parameter_certificate 对 ε' 迁移写条件式；其条件已由 gamma_budget_audit 的实际全划分论证处理。它仍不支付完整剩余；p16 clock-envelope 与 p112 的 196→14→28 edge 方案分别保留，不互换常数。
8. **未归档 numeric 路径**：proof/audit 内引用 `.checks.json`、`.py`、`.json` 是计算证据路径，不能替代解析证明。是否保留由 numeric 负责人统一决定；本清单不将其计入22/24份。SOURCES/REPRODUCE 必须映射最终实际保留文件，不能声称原临时路径可永久复现。

## 明确省略与理由

- `astra_integrator_bridge.md`：其一般组合可直接写入 REPORT，最终 release 已给正确母式与系数；旧记录含过期 head/core 缺口及旧 wide 的参数障碍，保留会增加交叉引用噪声。若 REPORT 不重述该组合的推导而只引用此稿，则必须把它作为第23份（有 lowtail 则总25份）补入；当前推荐 REPORT 自含短推导。
- `contract.md`、`live_next.md`：任务/动态团队合同与历史状态，不是最终新输入证明。其必要数学定义已在 local_entry/history_bridge/core 与 R565 精确来源中闭合。可在 SOURCES 说明阅读来源，不当最终定理依据。
- `core_next.tex`：非线性状态评分已被实际 row score 支配；主项3证明用 actions_next，而不依赖此候选筛查。
- `product_next.tex`、`product_occupation.tex`、其余 product 稿：只供未付的旁支表示，不进入六项精简主结论；audit_actioncurve 的相应段落明确标作不采用。
- `astra_clock.tex`、`astra_lowtail.tex`、`actions.tex`、`generator*.tex` 等早期稿：由上述 final/next/attack/global 稿覆盖，引用它们的作者工作说明不构成关键推导依赖。
- `astra_history.md`、`astra_integrator.md`、`allscale_audit_next.tex`、旧 cover/ledger/证明汇编：旧检查点/重复审稿，当前主证链由 #1–#5 与最终 release 完成；不为阅读历史归档所有中间稿。
- `threshold_graph` 之外的 joint/twin receiver 探索：若 REPORT 不列作已证主成果，无需为了“全都留过”归档。未付表示、有限计算与作者认证不升级成数学结论。

归档验收条件：最终 REPORT 的每个新证明引用要么落到上表22/24份实际归档路径，要么落到已发布 R561/R565 的明确章节/公式；任何只指向省略的临时稿的实质引理，须在 REPORT 自含重述或按上面的余量补收。此条件满足后，六项推导不再仅存在于未归档 `/tmp` 路径。
