# R571 新单带 Bπ：全局相位分配、真实旧重叠抵扣与对角证书门槛

**结论范围。** 直接使用 `/tmp/ccu_r571_astra_local_entry.md` 的同一输入、源格、冻结 L_i、一次 low/rapid 删除和新 bulk。未得到 Bπ≤aQ0+LW、a<d²/(G²J) 的新付款。实际新增的是：在 generator 的真实阈值阶段上，全局分配可利用的旧来源交叉抵扣为明确的非负图能量；而整个“丢弃该抵扣、逐父优化”的证书族都卡在原吸收阈值之上。下面给出可实现动作、完整上界、精确最优化条件，以及尚未付的几何项。对偶重述本身不计进展。

## 1. 固定对象与真实阈值动作

沿新入口：Q0=Σ_i||L_i||²，L_i=L_bulk,i+L_del,i，
\[
 e_B=\langle L_i,k_B\rangle=Cq_B\alpha_B,
\qquad E_{del}=\int_{del}e_BdB\le C(1+G)W=:cW,
\qquad Q_{fr}=\int_{bulk}e_B=Q0-E_{del}.
\]
记 e_B^b=<L_bulk,i,k_B>、Q_bb=∫bulk e_B^b=Σ||L_bulk,i||²。每父最大可达相位数 k_B≤J。

这里与 generator 交换后采用其真实阈值动作，而不重复其质量自适应律。对每个可达 j=0,...,k_B−1，取满足 κ_B(g)=κ_j:=γ^{jh} 的最大 g_{Bj}∈[1,G]。μ绝对连续使 κ_B 连续，阈值水平集非空紧；选择在接收来源前完成。最后可达实际相位若 endpoint 位于阈值之间，只使用已达到阈值的动作；仍为合法非空动作集（j=0 总存在）。其真实质量窗为 [s_B+jh,s_B+jh+1]，实际相位恰为 j。

任意分配概率 p_{Bj}≥0、Σ_jp_{Bj}=1 都给合法完整 π_B。定义
\[
 x_{Bj}=p_{Bj}/g_{Bj},\quad x_{Bj}=0\ (j\ge k_B),\qquad
 \sum_jg_{Bj}x_{Bj}=1. \tag{1}
\]
这允许依赖整个已知输入及全族旧重叠，但不依赖随后抽取的接收来源。新入口不要求保 endpoint floor；若另行要求 floor，须增加其实际字段，本文不隐藏这笔费用。

## 2. 完整旧平方中的真正全局抵扣

逐 phase 将时间平移回 jh。旧接收来源子场精确为
\[
 O_{ij}=\int_{bulk\cap E_i}x_{Bj}k_BdB.
\]
没有残余 h 移窗，因为使用真实阈值 κ_j。令 K_i(B,C)=<k_B,k_C>，它保留真实旧来源交集及旧质量窗帐篷。完整非负 Tonelli 给
\[
 \|O\|^2=\sum_i\iint K_i(B,C)\sum_jx_{Bj}x_{Cj}\,dB\,dC.
\]
用 2uv=u²+v²−(u−v)²，得到
\[
 \boxed{\quad
 \|O\|^2=\int_{bulk}e_B u_BdB-\mathcal D_{graph}(x)-\mathcal D_{del}(x),
 \qquad u_B=\sum_jx_{Bj}^2,
 \quad} \tag{2}
\]
其中
\[
 \mathcal D_{graph}=\frac12\sum_i\iint_{bulk_i^2}
 K_i(B,C)\sum_j(x_{Bj}-x_{Cj})^2dB\,dC, \tag{3}
\]
\[
 \mathcal D_{del}=\int_{bulk}(e_B-e_B^b)u_BdB\ge0. \tag{4}
\]
(3) 是同一实际 source/σ 旧捕获图上的平方差；没有假定父独立，也没有删掉跨父 Gram。它恰好量化“让相互重叠的父分配不同相位/振幅”获得的真实抵扣。全局选择只有产生足够大的 (3)，才能比相同的对角费用证明更强。

由 g≥1、Σgx=1，有 Σx≤1、u_B≤1。因此
\[
 \mathcal D_{del}\le\int_{bulk}(e_B-e_B^b)
 =\sum_i\langle L_{bulk,i},L_{del,i}\rangle
 \le E_{del}\le cW. \tag{5}
\]
删除抵扣只来自已分账的同一 deleted cross，不能再作为独立的大能量信用。moment-payment 角色正在独立核准与最终母账的合并；本式的归一化已交换一致。

## 3. 新来源与完整 Bπ 上界

令 N 为真实新增接收来源 Q_B(g_Bj)\Q_B(1) 的子场，全部实际相位、真实质量窗不变。完整动作场为 O+N（按各 phase 同步平移后），所以全部交叉保留。已有真实帽 N_ij≤A_ij≤C_* 和 κ_j 的实际质量身份给
\[
 \|N\|^2\le C_*\|N\|_1
 =C_*\int_{bulk}q_B\sum_j(\kappa_j-1)x_{Bj}dB. \tag{6}
\]
式 (6) 的 source 发票全族只积分一次，未逐 phase 重新领 W；但右侧还没有 polylog W 控制。

任意 ε>0，完整上界为
\[
 \boxed{\quad B_\pi\le\mathcal F_\varepsilon(x):=
 (1+\varepsilon)\left[\int e_Bu_B-\mathcal D_{graph}-\mathcal D_{del}\right]
 +(1+\varepsilon^{-1})C_*\int q_B\sum_j(\kappa_j-1)x_{Bj}.
 \quad} \tag{7}
\]
这是实际完整场的 Young 上界，不把 O 与 N 当正交。使用它可能损失真实 O/N 交叉结构；本文没有声称该 surrogate 等于全可行最小 Bπ。

## 4. 可实现的全局分配与精确边际价格

写 Aε=1+ε、bε=(1+ε^{-1})C_*。保留 (2) 的全部交叉，最小化的实际凸泛函是
\[
 \mathcal F_\varepsilon(x)=A_\varepsilon\sum_j\|O_j(x)\|^2
       +b_\varepsilon\int q_B\sum_j(\kappa_j-1)x_{Bj},
 \quad x\ge0,\quad\sum_jg_{Bj}x_{Bj}=1. \tag{8}
\]
全局边际价格为
\[
 P_{Bj}(x)=
 \frac{2A_\varepsilon\langle O_j(x),k_B\rangle
       +b_\varepsilon q_B(\kappa_j-1)}{g_{Bj}}. \tag{9}
\]
在同一已冻结 x 上，每父选最小 P_Bj 的真实动作，得到完整合法候选；整族混合后重算价格。该最优化保持实际重复旧来源通过 <O_j,k_B> 发生的影响，不把 e_B 当作独立父成本。最优分配的已使用 phase 具有最小 (9)，其余 phase 的价格不低。有限 J、有限父测度和有界 x 下可用可测有限选项；不需对来源后验选择。

若丢弃 (3)(4)，保守的逐父对角问题可准确求解：
\[
 \min_{x_B\ge0,\,\sum gx=1}
 \left[A_\varepsilon e_B\sum_jx_{Bj}^2+
       b_\varepsilon q_B\sum_j(\kappa_j-1)x_{Bj}\right].
\]
其合法分配是
\[
 x_{Bj}=\frac{[\nu_B^{mult}g_{Bj}-b_\varepsilon q_B(\kappa_j-1)]_+}
                  {2A_\varepsilon e_B}, \tag{10}
\]
唯一乘子 ν_B^{mult} 由 Σg x=1 决定，与原入口 t=1 权无关。bulk 上 e_B>0。该规则自动在可能的新壳成本与旧平方之间分配实际概率；它不差于等振幅 x=1/Σg 等固定规则。但以下门槛说明 (10) 单独不足。

## 5. 对角证书族的明确门槛；需要多少真正抵扣

由 (1) 的 Cauchy，逐父都有
\[
 u_B\ge\frac1{\sum_{j<k_B}g_{Bj}^2}\ge\frac1{JG^2}. \tag{11}
\]
故对任意可实现分配，丢弃图与删除抵扣后的整个证书满足
\[
 \mathcal F^{diag}_\varepsilon(x)
 \ge\frac{1+\varepsilon}{JG^2}Q_{fr}
 \ge\frac{1+\varepsilon}{JG^2}(Q0-cW). \tag{12}
\]
这是**证明方式的下界**，不是 Bπ 的下界。由于目标 a<d²/(JG²)<1/(JG²)，仅优化对角证书不可能在 Q0/W 无先验界时产生所需严格吸收。此结论涵盖 (10) 的全部选择以及等振幅律；不是对全局问题的反例。

任何由 (7) 达到目标的分配都必须满足至少
\[
 (1+\varepsilon)(\mathcal D_{graph}+\mathcal D_{del})
 \ge\left[\frac{1+\varepsilon}{JG^2}-a\right]Q0
       -\left[L+\frac{(1+\varepsilon)c}{JG^2}\right]W. \tag{13}
\]
因为 (5) 仅为一次 O(W)，高 Q0 分支必须有真正的 (3) 量级抵扣，或另行对低抵扣父族证明 Q0 的来源预算；新壳正项还会提高实际所需抵扣。

目前实际增长 κ_j 与系数 g_Bj 的约束，尚未推出 (13)。相邻旧来源父可以具有相同或接近的完整增长 profile，因此仅有“各父可达许多 phase”不强迫 x_B−x_C 大。对这些近同 profile 的父，证明其累计旧平方只收 polylog W，仍需要原方体全坐标与真实相关 μ 的新 packing 估计。均匀密度区域可真实产生相同 profile 而零图抵扣，但其能量本身可由 W 支付；所以这不是反驳“高能量强迫抵扣或来源付款”的例子，恰是缺失二分命题的低抵扣一侧。

## 6. 全凸混合的定位：相关抽动作没有额外免费收益

任何相关整族真实动作抽样 A_ω，其边际 π_B 都是合法来源前核。Hilbert 恒等式
\[
 \mathbb E\|A_\omega\|^2
 =\|\mathbb EA_\omega\|^2+\mathbb E\|A_\omega-\mathbb EA_\omega\|^2
\]
说明边际场已经不劣于相关随机场的平均平方。相关性可以帮助寻找好的边际或某个 realization，但不能给完整凸可行集之外的新“负交叉信用”。真正可以利用的全局抵扣已明确在 (3) 中。

若取全部真实动作的可行场凸闭包 C，其最小范数 P*=inf_C||A||² 的 Hilbert 对偶可写为
\[
 P_* =\sup_H\left[2\int_{bulk}\inf_g\langle H,v_B(g)\rangle dB-\|H\|^2\right].
\]
新入口 Li 的 phase 副本测试重新给
\[
 P_*\ge\frac{[dQ0-cW]_+^2}{G^2JQ0}
\]
（Q0=0 单列）。这是原母式的对偶定位，不是新预算，也不为其另做重复标量检查。

## 7. 精确结束点

已交付 (7) 的实际全族动作上界、(9) 的全 Gram 相位分配机制，以及 (12) 对整个逐父对角证书族的门槛。尚缺：用全部方体坐标和真实增长证明足以支付新壳项并达到 (13) 的图抵扣，或对低图抵扣族给一次 polylog W 上界。有限相位计数、独立父随机化、已有径向帽和旧母式对偶均不能替代此估计。

本次未得到新 a,L；此记录不计作原目标完成。与 generator 和 moment-payment 角色交换了精确归一化，未重做其质量动作/删除独审。root 已指定不重复 exact_certificate 的标量 SymPy/Arb 核验，因此未做第三份计算，也未开展缺乏真实输入判据的有限 LP。未改他人、旧稿或 repo，未开子代理/PDF。
