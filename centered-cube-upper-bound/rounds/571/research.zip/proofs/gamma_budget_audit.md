# R571 γ 参数预算独立审计：重新设计深度阈值可消去 wide/exc 的 γ 幂

**结论：该重新设计合法。** 对指定完整ρ=ω/(Iκ)的新记录，将R561两个正分支的深度预算同时改为下述ε'_d，并同步重建joint容量阶数、head阶数、core和新χ'，可使wide与exception各≤S²W。所审的实际后续reverse/actioncurve/clock/lowfield界不引入1/ε'_d费用。大γ的相位信用吸收窗口因此不再被旧Kw强制封死。不过剩余对象已改变；没有证明新完整剩余已经付款，更没有证明它比旧V小。

审查对象为R561 REPORT §§2–5的实际证明、R571动作/phaseedge/current source付款，以及新history_bridge的B4/B21母式系数。不复做历史主构造；未使用作者PASS代替公式。仅写本文件族，无repo/他稿/子agent/PDF。

## 1. 深度预算的准确通式与新付款

令r=rband，Fγ=γ^(2+h)r²。R561式(22)–(24)在代入特定ε_d之前，wide完整正积分满足

Cwide≤2G Fγ S² A_n (Σ_d ε_d) W。

证据链逐项是：实际phase/tent给D0=γ^(1+h)r及内父系数≤γSλband/M；固定g的真实中心体积≤ε_d gD0 R_C^n；同深度Σ_Tν(T)=1；完整阈值测度质量1；包括两端点的∫gω=2G；外∫ω/κ=I_C恰消归一；最后λband∫t_C≤r S A_nW。没有额外J、节点数或深度费用。

R561 §4 的exception体积证明只需要

m_d=min{n,ceil log2[1/(ε_d δ_head²)]}，δ_head=1/8。

m_d<n时指数交互尾2^(−m_d−1)≤ε_dδ_head²；m_d=n时尾严格0。转回真实有序权后得到完全相同的通式

Cexc≤2G Fγ S² A_n (Σ_d ε_d) W。

现在选择全局深度预算

ε'_d=1/[2G A_n Fγ (d+1)(d+2)]，d=0,1,…。

利用Σ[(d+1)(d+2)]^(−1)=1，确切得到

Σ ε'_d=1/(2G A_n Fγ)，Cwide'≤S²W，Cexc'≤S²W。

wide和exception是新正划分中的互斥部分，但各自使用该数值预算，完整总费为**2S²W**，不能把两笔合称一笔S²W。对于本新入口S=1即为2W。

预算是仅依n与统一局部参数的深度序列；没有按正在计价的B或receiver选择阈值，固定g积分与同深度来源和仍合法。

## 2. 必须同步重建的head/core参数

设旧ε_d为1/[2GA_n(d+1)(d+2)]，所以ε'_d=ε_d/Fγ。定义

k'_d=max{2,ceil[ln(3/ε'_d)/ln(9/8)]}，
a'_d=ε'_d(3/4)^(k'_d)，L'_d=ln(2/ε'_d)+k'_d ln(4/3)，
m'_d=min{n,ceil log2[1/(ε'_d δ_head²)]}。

阶数增加有明确界：

0≤m'_d−m_d≤ceil(log2 Fγ)，
0≤k'_d−k_d≤ceil(ln Fγ/ln(9/8))，
L'_d−L_d=ln Fγ+(k'_d−k_d)ln(4/3)。

因此新增量是O((2+h)lnγ+lnr)，不是Fγ或1/ε'_d。完整深度依赖仍为

k'_d,L'_d,m'_d=O(1+ln(GA_n)+ln(d+2)+(2+h)lnγ+lnr)

（m还截断于n）。不能把任意深度的ln(d+2)藏进O(logn)；这里只是改γ带来的新增成本为O(logγ)。当前支付证明不对这些阶数按深度另求和，所以没有新深度发票。未来若使用core大小作更强几何付款，仍须自己核深度权重。

联合容量改为Pjoint'=min{P_T,θ^(−k'_d)K_k'd}；coreGate为K_k'd>a'_d。严格集中证明中的关键比值仍是

(a'_d/2)/(2/3)^(k'_d−1)=(ε'_d/3)(9/8)^(k'_d)≥1。

由此仍存在真实条件质量>2/3的球，固定有理枚举给条件质量>5/8的core H'_T。其半径是2r_*L'_d，r_*=(gD0)^(1/n)R_C。core始终再与T相交，所以H'_T⊂T⊂Q_C(v)，不会因球变大引入新来源或改变full/restricted mass。

在真实首次停p>3/4上，p≤2ν_T(Q_B(g)∩H'_T)继续使用固定系数2。新的b_head'由阈值积分除以p定义，仍0≤b_head'≤1。证明中没有除以a'_d或ε'_d来付来源费；小概率只用来证明一个固定质量core的存在，不作为之后的importance weight。

**不能声称的单调性：** 单看原分位P_T阈值，缩小ε会扩大其narrow支；但joint容量的k也变化，故整个joint narrow集合并未证明关于旧新参数单调。core球半径增加但首个合格有理中心也可能变化，故H'_T⊇H_T同样未证。新head函数阶数变化也无逐点单调性。正确结论是重新定义一份完整正划分和新χ'，不是宣称实际V'下降。

ANOVA计算复杂度n^(m'_d)或辅助样本数可显著变大，但当前证明没有把该计算量变成算子常数。本任务无计算复杂度上限，不能为了节省此成本删去真实head。

## 3. 新χ'下可保持的后续估计及其必要条件

先固定γ,h和新单带输入，再建立来源格、Li/Q0、low/rapid和bulk；然后才选上述深度预算并构建新head/core。更改γ本身改变s_B=log_γm_B、旧单位窗、Li、e_B和α_B，不能把先前γ下的Q0或实验数值拿来沿用。所有这些对象在新参数下建立后，改ε只改变分析分支，不能再次重算Li或发第二份旧信用。

| 后续工具 | 新χ'可沿用的准确理由 | ε'_d导致的新费用 |
|---|---|---|
| first-stop合并与F≤Li | 树及首次停条件仍同一真实ν；H'_T⊂T，反链互斥，b_head',Gate'≤1；先合反链再估计 | 无 |
| K=ΛFcap前向行帽、完整低旧场 | 只依真实相位场帽、动作归一和合反链；低场∫≤KτDoldW | 无；K仍含lnγ |
| 低增长新来源费FcapW | 实际shell质量M_B−m_B、κ−1≤1/A_n、一次∫tq；其余门只放大到1 | 无；不得与已经删除支重复收费 |
| R571反向帽 | 同phase和实际tent先限制旧mass与半径图，再丢[0,1]门；新core仍同原两盒真实捕获 | 无 |
| actioncurve Ract/I_C及covariance deficit | 同固定外(C,v,j)的旧mass域先抽出，再对未截断ρ比较递增capture；χ'的其他门只用于正上界 | 无；使用Aact避免旧R0中γ^h幂 |
| 行归一f=ell/r与旧父Jensen | r'_C按全部新χ'重算；ell和单份Qfr冻结；旧源概率、Lbulk≤Li、时钟跨度不变 | 无；不得复用旧r_C |
| phaseedge 196h²信用 | r00'≤ell+hb，旧clock ν/β取新γ下冻结父族；界对任意所述完整χ成立 | 无 |
| smallgrowth与clock occupation | 新receiver/旧源保持同核，时钟近mass域与真实shell质量；只需χ'≤1及原捕获 | 无 |

这些论证不仅需要抽象χ'≤1，还需保留实际old-source概率、真实phase/tent、old/new捕获和两端归一；本重建恰保留这些条件。不能任意改变这些结构后仅凭“≤1”套结论。

新增core较大也不会导致本表已付费用出现core重叠倍数：同一内父first-stop反链先求和，H'_T只是T的子集，逐父总指标仍≤1。跨父重叠仍在真正未付的Cstar/Vcap中，未被声明消失。

## 4. 新指定ρ母式与可行相位吸收

history_bridge B4已定点独立核对：伴随场Yhat=∫a_Bρ_B feature，真实概率动作场Aρ=∫a_Bρ_B feature/g。对Yhat直接做三窗证明保旧幅度，因此

dQ0≤Erem+sqrt(JQ0 Ehat)，Erem≤C0(1+G)W，
Q0≤2Erem/d+(J/d²)Ehat。

这里确实不付G²；它不是从Aρ的另一路母式无价删因子。任意π的Bπ母式与这条指定ρ伴随场母式须区分。

重建ε'后的R561组合为

Ehat≤2S²W+2Cstar'。

继续在这个完整新Cstar'中一次划低Li和低增长，得到

Cstar'≤(K+Fcap)W+M'，M'²≤Qfr Vcap'≤Q0 Vcap'。

所以令Aph=J/d²，c0=C0(1+G)，新的母式是

Q0/W≤Cbase+2Aph sqrt[(Q0/W)(Vcap'/W)]，
Cbase=2Aph(S²+K+Fcap)+2c0/d。

若完整Vcap'≤aQ0+LW，仍需a<d^4/(4J²)，完整根式使用该新Cbase。若在Ehat层直接获得a_E Q0+L_EW，则门槛为a_E<d²/J。不能把局部Vedge信用直接当作a_E。

phaseedge的Vedge≤196h²Qfr通过Cstar平方根后给M_edge≤14hQ0，继而Ehat中贡献至多28hQ0。其正确吸收条件是

28Jh<d²。

一个明确统一窗口是

γ=A_n^112，h=1/448，J=1+floor[(log_γA_n)/h]=5，γ^h=A_n^(1/4)。

h<1/6满足R561较严原假设，且

28Jh=5/16，d²−5/16=135305/200704>0。

因此phaseedge确有可吸收余量。此前使用Bπ母式的更保守γ=A_n^(112G²),h=1/(448G²)也合法，但此指定ρ伴随场路线无需它。

**此吸收只处理已经合法分拆出的edge，不支付old-overlap、高增长、outer-new或其它父集。** 若完整r≤ell+hb+growth中的ell项未另付来源，直接Minkowski仍带系数1，不能因edge可吸收就把整个Vcap当小信用。

## 5. 全量参数检查：已付费用保持polylog，尚未付量不作结论

取S=1、固定r≤2、G为固定常数或固定对数幂，使用上一节γ=A_n^112,h=1/448。

A_n=1+nln2+ln(2G)，J=5，
C0=1+lnr+112lnA_n，
Fcap=G[1+lnG+lnr+(112+1/4)lnA_n]，K=ΛFcap，
Aact=2G[1+lnr+(224+1/4)lnA_n]。

所以Cbase、low/rapid、低场、低增长和actioncurve行帽中的已显示系数均为固定对数幂。新预算明确是

ε'_d=1/[2G r² A_n^(225+1/4)(d+1)(d+2)]。

1/ε'_d本身很大，但目前支付证明仅线性使用ε'_d或通过log进入head/core，未出现把此倒数直接乘W的步骤。旧Kw=γ^(2+h)r²=A_n^(224+1/4)r²的幂已由新的Σ ε'_d准确抵消，不能仍一边用旧阈值定义χ、一边只将Kw改成1。

core的实际参考边长还含D0^(1/n)=r^(1/n)A_n^((112+1/4)/n)。固定γ幂指数方案下它随n→∞趋1；无须把这个参考盒体积按core来源量再付，因为H'⊂T且核心质量常数固定。但任何未来用core半径/体积建立新余项界，仍需保留真实r_*L'_d，而不能只引用“新增logγ”。

旧来源窗Dold=1+[lnr+nln2]/[112lnA_n]=O(n/log(n+2))（用O(n)也安全）；source collar还带Dcap−Dold=ln(2G)/lnγ，仍显示保留。现有粗Vcap'≤Ract² DcapW仍含约n的费用，不能凭重新调阈值消去。它给的是有限cutoff可付界，不是所需polylog完整payer。

### 不应偷偷接回的其他γ幂费用

旧near/common-prefix差额路线含Lcl=(2GΛγ³/(γ−1))SrK[4+2h+log_γmax(γ^h,A_n)]，以及B0中的γ²。这些是另一套覆盖/差额的真实费用，改ε'并未消去它们。当前新full-Cstar路线不需要把这些替代路线的费用再加一次；若选择使用它们，则须保留γ幂并重新判断是否仍有净收益。不能称“所有历史上的γ幂均已消去”。

同样，某些尚未付款的product/外中心invoice在放松后可能显式带γ；它们尚不是本段已付Cbase的一部分，也不能因为wide已补偿就获得免费的polylog界。未来若靠这些估计支付完整余项，必须重新核其γ依赖。

## 6. 最高可支持claim

可以严格宣称：在新指定ρ父族中，重新设计一个共同、可求和的深度预算并同步重建实际joint/head/core正划分，能够把两项已付wide/exception从γ幂规模降为各S²W；当前行帽、时钟、直接子费与相位edge信用保持合法，且存在γ=A_n^112、h=1/448、J=5的可吸收edge参数窗口。该变化是合法构造新完整χ'，不是在旧发票上只替换常数。

仍未证明：新完整Cstar'/Vcap'的其余部分具有polylog来源费或足够小的额外信用；新χ'可能更难估计。一般根阶结论保持未证。新source局部化和入口已能将未来同核完整payer转为一般弱型结论，但不能代替这里的剩余几何。

## 实跑记录

指定本机Python/SymPy实际运行 gamma_budget_audit.py，精确核Σ ε'_d、每项wide/exc系数=S²（残差0）、相位参数ph=1/4及J计算、旧Kw与新ε倒数的A_n幂、相位吸收系数及正余量。结果 gamma_budget_audit.json。计算只核代数，完整合法性依据上述原证明链；无参数扫描或重复20scalar试验。

### 供下一份完整payer直接验收的条件式

若后续在**同一新χ'与同一Yhat**上将除已分离edge外的全部剩余连同2S²、低场、低增长等合计证明为L_tot(n)W，即真的得到

Ehat≤28hQ0+L_tot(n)W，

则当前参数直接给

Q0/W≤[2C0(1+G)d+J L_tot]/[d²−28hJ]，

分母由上文135305/200704统一控制。结合新来源局部化的r=4/3版本，便有

λ|{M_cube f>λ}|≤[16e+4N_n/(3(1−η)) sqrt(Dold·[2C0(1+G)d+J L_tot]/[d²−28hJ])]W。

这个接口准确定位剩余任务：证明完整L_tot为固定对数幂，而非继续优化已经可吸收的edge常数。当前尚没有该L_tot定理；所有尚未付的父/receiver分支必须进入它。
