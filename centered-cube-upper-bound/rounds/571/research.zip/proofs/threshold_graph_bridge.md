# R571：last-hit 阈值动作的完整中心图几何桥

**新增全量可付图估计：** 对 generator_global GA1–GA8 的实际 last-threshold 概率律（包括明确给出的 waterfill），可在同一真实 `B_π` 上重建共同来源树、wide、head 与 core，使

`B_π ≤ 2W + 2 Cstar_graph`。                                      (TG1)

这里两笔 W 分别支付互斥的完整 wide 与 exception 分支；`Cstar_graph` 保全部真实 `p_Bj/g_Bj`、来源交集、阈值相位、old-window overlap 与新重建的 tree/head/core。没有 source 密度帽、质量导数下界、光滑性、固定边长或有限维假设。该桥不付最后的 `Cstar_graph`，也不把它等同于旧 adaptive-ρ 的 Cstar/VG。

关键区别是：不是对固定 g 的小中心集合非法积分 `π_B(dg)`，而是为固定外父相位 `(C,j)` 构造一个**对内父全部实际 g_Bj 共同有效**的参考半径，在整个 B→g_Bj 图上证明中心体积帽。增长阈值引入的 Γ_j 由真实动作的共同来源总量支付，不乘 J，也不取 Kmax。

## 1. 同一完整输入与阈值图

沿新local_entry：μ=f dx、W<∞，互斥source cells C_i，所有合法动作盒在本cell内。实际父 B 有可测 `R_B∈[a,2a]`、`q≤q_B≤λband`，`r=λband/q`（新入口r=2），t=1。旧核与旧mass窗冻结：m_B=q_BR_B^n，s_B=log_γm_B。只用原定义的bulk；以下几何甚至不需再利用其α上限或最大κ上限。

令Γ_j=γ^(jh)，`J_B={j≥0:Γ_j≤κ_B(G)}`，

`g_Bj=max{g∈[1,G]:κ_B(g)=Γ_j}`，
`p_Bj≥0, Σ_{j∈J_B}p_Bj=1, x_Bj=p_Bj/g_Bj`，

不可达j令p=x=0。这里p可以直接是GA8明确waterfill；下面不改变它。所有p、g在计价source之前依完整输入及父B确定。

质量函数连续、单调，故可达level集合非空紧致，last hit存在。它也等于`sup{g∈[1,G]:κ_B(g)≤Γ_j}`；用有理g加端点测试得到可测性。j=0初始平台、立即增长的g=1、末端G恰等level、无平台及全部概率原子均包括。整个证明不对g_Bj求导、不把平台长度下界设正。

将phase j的真实字段平移−jh后，完整能量精确为

`B_π=Σ_i Σ_j ∬_{bulk_i²} [x_Bj x_Cj/(R_B^n R_C^n)] T(s_B−s_C)
                         μ(Q_B(g_Bj)∩Q_C(g_Cj)) dB dC`，          (TG2)

T(u)=(1−|u|)_+。x_Bj x_Cj明确保留真实`p_Bj p_Cj/(g_Bj g_Cj)`。全部有序父对、old/new与shell交叉已包含；不存在只看old或仅对角的替代。

## 2. 整张中心图的共同参考边长

固定外父C及一个可达j，置

`v=g_Cj, M=μ(Q_C(v))=Γ_j m_C, ν=μ|Q_C(v)/M`，
`D0=γ r, r_*=(G D0)^(1/n)R_C`。                           (TG3)

若TG2的真实tent非零，则`m_B/m_C∈(γ^-1,γ)`，因为同一Γ_j在两个实际action mass中**精确相消**。因而

`R_B^n≤D0 R_C^n,    g_Bj^(1/n)R_B≤r_*`。                  (TG4)

这对B的可测radius graph逐点成立，没有将R_B或g_Bj冻结。r_*只依(C,j)（数值上依C），不依内父B或其实际g_Bj。

在Q_C(v)上建共同循环坐标二分树。固定正节点T，令ν_T=ν|T/ν(T)。对任意θ>1/2定义

`p_BjT=ν_T(Q_B(g_Bj)),   p_*(B)=ν_T(Q(B,r_*))`。

在真实tent支持上，TG4给`p_BjT≤p_*(B)`。所以任何加有实际threshold-availability、first-stop或其他正门的中心图子集，都可用同一个固定半径的p_*超水平集控制。

具体令P_T(θ)为ν_T的完整分位宽乘积，K_k(ν_T,r_*)为R561的整个来源向量range乘积整数矩，

`Pjoint_T(θ)=min{P_T(θ), θ^(-k_d) K_kd(ν_T,r_*)}`。

由固定半径center identity及分位中心盒，两项分别控制同一个实际center集合，故

`|{B:tent>0,j可达,p_BjT>θ,任何额外正门}|
 ≤ r_*^n Pjoint_T(θ)`。                                  (TG5)

TG5是**整个 B→g_Bj 图的中心体积帽**。它完全绕开对`dB δ_gBj(dg)`使用fixed-g Fubini的错误；作为原子graph也成立。几何损失明确是`r_*^n=Gγr R_C^n`，是G级而不是指数维数。

## 3. 支付Γ_j：同一真实source的一次动作总量

令

`Aact=1+n ln2+lnG`，即全部实际新side `[a,2aG^(1/n)]` 的中心包络。

对每个source y和任意上述概率律，逐点有

`Σ_i∫_{bulk_i}Σ_j p_Bj 1_QB(gBj)(y)/(g_Bj R_B^n) dB≤Aact`。 (TG6)

证明：设P_Bj=g_Bj^(1/n)R_B，ρ=2||B−y||∞。每项合法selector的核至多

`max(a,ρ)^(-n)1_{ρ≤2aG^(1/n)}`。

先对j用`Σp=1`，再对中心B积分；`|{ρ≤u}|=u^n`给总量`1+nln(2G^(1/n))=Aact`。source cell和bulk限制只能减小该非负积分。

由μ-Tonelli和exact threshold mass，TG6给精确预算

`∫bulk q_B Σ_j Γ_j x_Bj dB
 =Σ_i,j ||A_ij||_(L1(μ_i dσ)) ≤ Aact W`。                  (TG7)

窗长度恰为1，phase平移不改此身份。**TG7保真实Γ_j，不取最大增长、不逐phase收W。** last-hit平台或j=0都包含于原完整动作field。其证明仅用source-before概率与合法side范围，不需要质量曲线的coarea密度。

## 4. 新first-stop、wide与exception全量付款

在共同树上对每个实际(B,j)取首次`p_BjT>θ0=3/4`的节点。每父反链及来源分化给

`ν(Q_B(g_Bj))=Σ_{T first-stop}ν(T)p_BjT`。

完整层蛋糕为`χ=θ0δ_θ0+1_(θ0,1)dθ`，在stop上`∫1_{p>θ}dχ=p`。共同树terminal为0，证明逐tuple再用非负Tonelli，不需统一不可数零集。

置

`Hgraph=γ² r² G Aact`，
`ε_d=[Hgraph(d+1)(d+2)]^(-1), Σ_dε_d=1/Hgraph`，
`k_d=max{2,ceil[ln(3/ε_d)/ln(9/8)]}`。                     (TG8)

Pjoint中的k_d使用TG8。按`Pjoint≤ε_d`划wide，补集narrow。对fixed(C,j,T,θ)，这个门与内父B及g_Bj均无关。TG5因此给wide图的中心体积≤ε_d r_*^n。

在真实tent支持上，内父系数满足

`x_Bj/R_B^n ≤1/R_B^n=q_B/m_B≤γ λband/m_C
            =γ Γ_j λband/M`。                            (TG9)

保外父真实系数`x_Cj/R_C^n`。将TG9、TG5乘上树展开的真实来源质量Mν(T)，再在每深度用`Σ_Tν(T)=1`及`χ(total)=1`，得到

`Bwide ≤ γ λband G D0 (Σ_dε_d) ∫bulk Σ_j Γ_j x_Cj dC
       ≤ γ r G D0 Aact (Σ_dε_d) W = W`。                 (TG10)

第二步只用q_C≥q与TG7；没有用父族个数或phase个数。全部有序父对只按其真实外父C锚定一次，不漏反次序。

为head取固定θ0分位参考中心盒

`O=Π_a[q_Ta(θ0)−r_*/2, q_Ta(1−θ0)+r_*/2]`。

所有实际stop父B在O，`|O|≤r_*^n`。在O归一化Lebesgue product measure上对p_*作R561坐标投影，令H_m为≤m阶交互头，δ_head=1/8，

`m_d=min{n,ceil log_2[1/(ε_d δ_head²)]}`。                 (TG11)

原tensor/Jensen工具给`||p_*−H_m||²≤2^(-m-1)`（m=n时尾0）。narrow内按`H_md(B)≤θ−δ_head`划exception，否则head。因为p_*≥p_BjT>θ，exception的未加权center体积≤ε_d|O|≤ε_d r_*^n。与TG9–TG10同一次计算严格给

`Bexc ≤ W`。                                            (TG12)

wide与exception互斥；兩次depth预算均明确支付，不能把总量写成W。空O或零体积O的center贡献为0，这里对B直接积分，原子action graph不破坏这一结论。

门参数的维数代价准确为`log Hgraph=2logγ+2logr+logG+logAact`。因此γ,G至多固定n幂、r固定时，head次数及core logarithmic参数仍为`O(log n+log(d+2))`。这是重建门，不宣称与旧g-dependent门单调等价。

## 5. 新核心、精确Cstar_graph及全部cross terms

令`a_d=ε_d(3/4)^k_d`、`L_d=ln(2/a_d)`，`Gate=1_{K_kd>a_d}`。joint narrow存活蕴含Gate。R561整个向量range矩反推仅需真实ν_T，给半径r_*L_d的l1球捕获>2/3条件质量。用固定有理中心枚举，选首个半径2r_*L_d的闭l1球捕获>5/8，令其与T的交为H_CjT。

H、Gate和O/H_m均依(C,j,T)，**不依内父B、其g_Bj或随后source实现**。零Gate令H空。可数枚举保证可测；AC μ使必要边界无问题。对真实stop p>3/4，

`p≤2ν_T(Q_B(g_Bj)∩H_CjT)`。

定义真实head权

`b_BCjT=(1/p)∫1_{p>θ}1_{Pjoint>ε_d}
                    1_{H_md(B)>θ−δ_head} χ(dθ)`，

非stop置0。0≤b≤1且b=b Gate。设

`Cstar_graph=Σ_i,j ∬ [x_Bj x_Cj/(R_B^nR_C^n)] T(s_B−s_C)
       Σ_{T first-stop(B,j)} b_BCjT Gate_CjT
          μ(Q_B(g_Bj)∩H_CjT) dB dC`。                    (TG13)

从同一完整TG2正分解，head剩余由真实core不等式至多2TG13。合TG10、TG12即得TG1。

TG13没有丢任何old/new来源交叉、p_Bj、1/g_Bj、概率原子、可达phase或实际last-hit cube。core中全部相关来源保留。该新几何的树是对actual outer threshold cube而建；它不需要旧external deletion history，也没有沿用旧adaptive-ρ门。

## 6. 结论与准确剩余

本稿成功给出指定threshold π下**覆盖完整Bπ的中心图几何分解**，并将两个全量几何补集付成2W，参数只多显式G及log门价。它使用全部实际mass threshold的相位对齐、联合reference边长和实际动作source occupation；无需coarea逆导数，因此plateau/原子/一般L1直接合法。

这并不证明最终几何payer。剩余是同一新TG13的`Cstar_graph`，需要例如一个适当可吸收Q0信用加polylog W的全量预算。不得从其名字、core条件质量或新ε_d门本身宣布付款。任何以后对旧ρ、旧g-dependent head/core或旧VG的界，也不能直接移给TG13；必须证明在这一真实threshold图及其完整权上成立。

没有仅停在固定side或有限n：R_B是任意给定可测graph，证明对所有n≥1及一般非负L1 μ成立，所有无穷树深由正Tonelli和已付可求和ε_d处理。允许取GA8的既定waterfill原封不动；本桥不重新优化其权，也不假定可达phase有统一数目。
