# R571：新local_entry的指定adaptive场→真实head/core/firststop→VG完整桥

**已完成严格实例化，未完成几何payer。** 本稿只对新local_entry中的指定
ρ_B(dg)=ω(dg)/(I_Bκ_B(g))，ω=δ₁+dg/g+δ_G，成立。任意来源前π仍享有local_entry母式，但不因此享有本稿R561 fixed-g中心容量付款。

最重要的完整结论是：记Q0为新冻结旧场平方，Erem=E_low+E_rapid≤C₀(1+G)W，d=1−3h，J为真实相位数，Aph=J/d²；则在本文重新构造的VG_new上

    Q0 ≤ Cnew W+2Aph sqrt(Q0 VG_new),                    (B1)
    Cnew=2Aph(Kw+K+Fcap)+2C₀(1+G)/d.

全部初始、low/rapid、共同树终端、wide、exception、low-old-field、low-growth费用均在此式明确支付一次。唯一尚未支付的是同一个新VG_new，**本稿不证明其≤aQ0+LW**。若以后证明该式且a<1/(4Aph²)，则新局部weak入口闭合；不需要旧globalhistory接口。

## 1. 新数据、真实字段与显式伴随场

严格沿已独审local_entry §§1–4的新g≥0、源格C_i、保留中心E_i、t_B=1、R_B∈[a,2a]、q_B∈[λ/2,λ]。令b=2a(2G)^(1/n)，An=1+n ln(b/a)，C₀=1+ln(2γ)。源格包含所有动作盒，μ_i限制不改任何盒质量；Σμ_i=W。旧Li在全部E_i冻结，low/rapid仅一次互斥解析分解，bulk保

    1/An<α_B≤1, κ_B(G)<max(γ^h,Anα_B),
    Qfr=∫bulk〈Li,kB〉dB=Q0−Erem≤Q0.

取0<h<1/6使R561全部常数适用。m_B=q_BR_Bⁿ，M_B(g)=μQ_B(g)，κ=M/m，I_B=∫ω/κ∈[1,Λ]，Λ=2+lnG，j_B(g)=floor(log_γκ/h)。全部质量正；W=0或bulk空独立平凡处理。

真实动作字段与伴随字段**分别**定义为

    A^ρ_ij(y,σ)=∫bulk a_B ∫[1/g]1_QBg(y)1_window(MBg)(σ)
                          1_{j=jB(g)}ρ_B(dg)dB,
    Yhat_ij(y,σ)=∫bulk a_B ∫1_QBg(y)1_window(MBg)(σ)
                          1_{j=jB(g)}ρ_B(dg)dB,
    a_B=R_B^(−n), Bρ=||A^ρ||², Ehat=||Yhat||².            (B2)

因此A^ρ≤Yhat≤GA^ρ逐点，Bρ≤Ehat；绝不把Yhat称为概率动作场。写

    Θ_BC(g,v)=1_{jB(g)=jC(v)} τ(log_γM_B(g)−log_γM_C(v)),
    τ(s)=(1−|s|)_+,
    W_BC(g,v)=q_Bq_C Θ_BC(g,v)/[I_BI_CM_B(g)M_C(v)].       (B3)

则Ehat的精确有序Gram是∫W_BC μ(QBg∩QCv)dB dC ωdg ωdv；真实Bρ的同一Gram**准确多一个1/(gv)**。所有对角、次序、端点原子保留。

按真实phase将Yhat统一移回jh后，新空间盒包含旧盒、旧系数a_B原样保留。local_entry的三窗Gram证明于是给

    dQ0≤Erem+sqrt(JQ0 Ehat),
    Q0≤2Erem/d+J Ehat/d².                               (B4)

这里无G²，因为伴随场用途已直接证明；不是从Bρ母式无价去掉1/g。Yhat相位帽

    Yhat_ij≤Fcap=G[1+ln(2Gγ^(1+h))], K=ΛFcap             (B5)

来自A^ρ相位帽及Yhat≤GA^ρ。所有完整字段有限。

## 2. 全部firststop/history在新来源上重建

固定实际外父动作(C,v)，M=M_C(v)，ν=μ|QCv/M。把QCv作为根，按坐标1,…,n循环在矩形几何中点二分，形成所有内父共用的可数树。正节点T有ν_T=ν|T/ν(T)，零节点忽略。固定(B,g)，沿每条路径首次满足

    p_BgT=ν_T(QBg)>θ₀=3/4

时停止，得到反链S_Bg。条件期望的鞅收敛/生成全Borel的矩形细分给

    ν(QBg)=Σ_{T∈S_Bg}ν(T)p_BgT.                         (B6)

具体地，对ν-a.e. y∈QBg，条件概率趋1，故有限深度前必停；对未停区域的QBg质量趋0。每个(B,g,C,v)分别成立后用非负Tonelli积分，不需要声称一个统一不可数零集。根高捕获和任意低重叠均保留，没有未付树终端。

层蛋糕测度χθ=θ₀δ_θ₀+1_(θ₀,1)dθ，总质量1，且p=∫1_{p>θ}χθ(dθ)。初始原子不可遗漏。这就是新χ的全部停止history；没有旧global接受/删除状态作为额外前提。

## 3. 固定共同ω下重建wide、head、core

下面定义与R561 REPORT式(17)–(39)、§4–5相同，输入全部换成上述已固定新数据；其可用性由以下逐项检查保证。

Θ≠0先给m_B/m_C<γ^(1+h)，R_Bⁿ≤D₀R_Cⁿ，M_B(g)>M/γ，其中D₀=γ^(1+h)·2。固定(C,v,T,g)，取r_*=(gD₀)^(1/n)R_C。ν_T的坐标θ分位宽为w_k(θ)，定义

    P_T(g,θ)=∏_k(1−w_k(θ)/r_*)_+,
    K_k(ν_T,r_*)=∫∏_a(1−range(z_1a,…,z_ka)/r_*)_+
                        ν_T^⊗k(dz_1…dz_k),
    ε_d=[2GAn(d+1)(d+2)]^(−1),
    k_d=max{2,ceil[ln(3/ε_d)/ln(9/8)]},
    Pjoint=min{P_T,θ^(−k_d)K_kd}.                         (B7)

对实际非零Gram的内父超水平中心集，两项各自给**同一个**有效体积帽≤gD₀R_CⁿPjoint，故可取min。这使用相关整个来源向量的乘积样本，没有来源坐标独立假设。

按Pjoint≤ε_d划wide，补集narrow。在共同ω下固定g后做Lebesgue B积分，内系数≤γλ/M，Σ深d ν(T)=1，∫gωdg=2G，外∫ωdv/κ_C=I_C，Σ_d ε_d=1/(2GAn)，以及∫bulk q_CdC≤AnW，严格得到

    Ehat_wide≤Kw W, Kw=4γ^(2+h).                         (B8)

这是一次全深度预算，不是每节点一次W。**该固定g证明不适用于任意B依赖的Dirac动作π_B**，本稿始终指定ρ。

为重建head，取ν_T的固定3/4分位参考中心盒
O=∏_k[q_k(3/4)−r_*/2,q_k(1/4)+r_*/2]。所有实际首次停父B∈O，|O|≤r_*ⁿ；空盒或零体积盒无中心费用。在O的归一化乘积Lebesgue测度上令p_*(B)=ν_TQ(B,r_*)，P_k为积去第k坐标的正交投影，

    F_A=∏_{k∈A}(1−P_k)∏_{k∉A}P_k p_*,
    H_m=Σ_{|A|≤m}F_A,
    δ_head=1/8,
    m_d=min{n,ceil log₂[2GAn(d+1)(d+2)/δ_head²]}.

单来源矩形tensor恒等式及对ν_T的一次Hilbert Jensen给Σ_A2^|A|||F_A||²≤1，故尾≤2^(−m−1)。在narrow内按H_md(B)≤θ−δ_head划exception，否则head。由于p_*≥p>θ，exception的中心体积≤ε_d gD₀R_Cⁿ，同(B8)的固定g付款给

    Ehat_exc≤Kw W.                                      (B9)

wide与exception互斥；两份Kw明确均进入总账。

核心来源集合也重建，不用单点替代。置a_d=ε_d(3/4)^kd，L_d=ln(2/a_d)，Gate=1_{K_kd>a_d}。在Gate上按固定有理中心枚举取首个满足ν_T(Bbar₁(c,2r_*L_d))>5/8的c；真实来源核心H=T∩Bbar₁(c,2r_*L_d)。存在性由R561(32)–(35)的range矩反推，完全只用ν_T。其余参数约定H=∅。H与Gate依(C,v,T,g)，不依内父B或随后计价来源。

在真实首次停节点p>3/4且Gate=1，有

    p≤2ν_T(QBg∩H).

定义

    b_head=(1/p)∫1_{p>θ}1_{Pjoint>ε_d}
                         1_{H_md(B)>θ−δ_head}χθ(dθ),     (B10)

非停节点设0。0≤b_head≤1，b_head=b_head Gate。所有对象由可数树、可测分位/积分/有理枚举形成，参数联合可测。

## 4. 新Cstar的完整定义及保1/(gv)的真实Bρ桥

令

    Cstar=Σ_i∫ W_BC(g,v)Σ_{T∈S_Bg}
           b_head Gate μ(QBg∩H_CvTg) dB dC ωdg ωdv.       (B11)

把W_BC换成W_BC/(gv)得到Cstar^ρ。以上完整正划分与核心不等式给

    Ehat≤2KwW+2Cstar,
    Bρ≤2KwW+2Cstar^ρ≤2KwW+2Cstar.                        (B12)

更精确地真实Bρ的wide、exception各≤[Λ/(2G)]KwW，因为内1/g抵消体积帽的g，∫ω=Λ，外∫ω/(vκ_C)≤I_C；Λ≤2G。本稿后续采用较简洁的安全(B12)，没有删除真实Gram的1/(gv)。

这里所有核心、head和停止标记均是(B6)–(B10)生成，**未自动继承任何旧χ**。低Li/低growth门也尚未塞进Cstar，将在下一节从这个完整正量只划分一次。

## 5. 提升、行帽、两项direct费用和精确VG_new

写x=(i,C,v,g,T,y)，N=M_B(g)，M=M_C(v)，

    w_x(B)=M/(γ I_B N) Θ_BC b_head 1_{T∈S_Bg}1_QBg(y),
    dΞ=γq_C/(I_CM²)dC ωdv ωdg Σ_T Gate 1_H(y)μ_i(dy),
    dℳ=dΞ w_x(B)k_B(z,σ)dB μ_i(dz)dσ.                   (B13)

积分旧(z,σ)给q_B，故∫dℳ=Cstar精确成立。真实Cstar^ρ对应dℳ/(gv)。没有重选physical B,C，也没有改变oldLi。

先对同一内父的实际停止反链求和：H⊂T，停节点互斥，b_head,Gate≤1，故

    Σ_T1_stop b_head Gate 1_H(y)≤1_QCv(y).

利用外父恢复字段Yhat的真实相位帽(B5)，窗Gram恰由积分同一个单位质量窗产生，从而

    r(B)=∫w_x(B)dΞ
     ≤(Fcap/I_B)∫ωdg [μ(QBg)/M_B(g)]
     ≤ΛFcap=K.                                         (B14)

这个步骤必须在逐T累计之前合反链；没有逐节点重领Li或W。

取Dcap=1+log_γ2+n log_γ(b/a)，τ_old=1/Dcap。旧σ真实支撑长度Dold=1+log_γ2+nlog_γ2≤Dcap，低旧场费

    ∫_{Li≤τ_old}dℳ
      ≤K∫_{Li≤τ_old}L_bulk,i dμ_i dσ
      ≤K τ_old Dold W≤KW.                              (B15)

定义本新完整Cstar上的低增长新来源门

    Nδ={y∈QBg\QB1, κ_B(g)−1≤δ}, δ=1/An.

同一合反链、外场帽和准确归一给

    r_Nδ(B)≤Fcap∫ρ_B(dg)(κ_B(g)−1)1_{κ−1≤δ}
            ≤Fcap δ,
    ∫_{Nδ}dℳ≤Fcap δ∫bulk q_BdB≤Fcap W.                 (B16)

这是从(B11)未删门的完整新量一次取出的真实付款，不是在已含Nδ^c的旧χ上再次领费。若额外新结构使该支为空，实际费用取0；本稿不以此声称新增小增长收益。为与合同统一，下文保安全上界FcapW。按先lowLi、再Nδ\lowLi分割即可使两笔发票互斥。

剩余R=Nδ^c∩{Li>τ_old}。定义

    VG_new=K∫_R dℳ/Li(z,σ).                             (B17)

因∫Li dℳ=∫bulk r(B)e_BdB≤KQfr，同一测度Cauchy严格给

    Cstar≤(K+Fcap)W+sqrt(Qfr VG_new)
          ≤(K+Fcap)W+sqrt(Q0 VG_new).                    (B18)

无旧源逆场替换。Li=0区域落入(B15)且dℳ为0 a.e.，不会除零。

把(B13)合并系数，ν_i(dB,dg)=a_BdBρ_B(dg)，ν_i(dC,dv)=q_C/(I_CM)dCωdv，则(B17)正好是

    dVG_new=K ν_i(dC,dv)μ_i(dy)μ_i(dz)dσ
             [1_{Li>τ_old}/Li(z,σ)]
             χ_new(B,g;C,v,y,z,σ)/m_B ·ν_i(dB,dg),       (B19)

其中χ_new明确等于Θ_BC、old z∈QB1与old单位窗、Nδ^c、以及Σ_T1_stop b_head Gate1_QBg(y)1_H(y)的乘积。0≤χ_new≤1先由真实反链得到；QCv包含由H⊂T⊂QCv保留。全部真实phase/tent/head/core/停止历史齐备。**这给当前合同VG公式在新数据上的可审核实例化，不是仅把它改名。**

定义VG_new^ρ=K∫_R dℳ/[gv Li]≤VG_new，则同样Cstar^ρ≤(K+Fcap)W+sqrt(Qfr VG_new^ρ)。因此真实Bρ也有完整连接

    Bρ≤2(Kw+K+Fcap)W+2sqrt(Q0 VG_new^ρ).                 (B20)

## 6. 合并、门槛、真正剩余

(B4)(B12)(B18)给(B1)。若同一完整新对象将来有VG_new≤aQ0+LW，置z=Q0/W，则

    z≤Cnew+2Aph sqrt(a z²+Lz), a<1/(4Aph²).

于是

    z≤Fnew=[Cnew+2Aph²L
             +2Aph sqrt(a Cnew²+Cnew L+Aph²L²)]
             /(1−4Aph²a).                              (B21)

接local_entry原弱入口λ|E|≤2(1−η)^(−1)sqrt(Dold Fnew)W。无需旧入口倍率、β恢复、旧global删除费或旧terminal桥。

如未来只得到真实Bρ≤a_B Q0+L_B W，则也可直接走local_entry(14)，阈值a_B<d²/(G²J)；它与(B21)是两条各自完整的路，不能混用阈值。

未付项目只有(B17)/(B19)这份真实完整正费用的几何控制：不能由χ≤1、Cstar新名称、core条件质量、单父一次来源或全行动近优推出polylog W。R570粗cutoff上界可以应用于本实例，但保留Dcap=O(n)，不产生根阶所需的payer改善。本文不将严格归约登记为一般弱型闭合。

## 审查与实际核验

读R561 REPORT实际共同树、joint宽/异常/core/head和lift所需章节，以及R571合同。density审查独立确认指定ρ的fixed-g限制、firststop无外部history、direct-row/两子费的范围。旧local_entry及history稿未修改。本稿仅写本角色文件，不改repo/他人，无子agent/PDF。

本机Python3.12.14 / SymPy1.14.0实际核验4个精确系数恒等式全部PASS：lift积分恢复Gram、真实Gram保1/(gv)、ν_B/m_B系数、最终二次吸收多项式。输出 `/tmp/ccu_r571_history_bridge.checks.json`；不将这些代数检查充当一般几何证明。
