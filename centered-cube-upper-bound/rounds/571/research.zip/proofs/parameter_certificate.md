# R571 explicit parameter certificate: gamma may grow without an exterior gamma^h fee

**Parameter decision: PASS.** A fixed choice

\[
\boxed{p=16,\quad q=16,\quad G=4,\quad r=2,\quad S=1,
\quad\gamma=A_n^{16},\quad h=1/256}
\]
works uniformly for every n≥2 in the new single-band construction. It gives the safe phase count J=17 and a strict, dimension-independent margin for the requested clock-envelope absorption criterion. This certifies compatibility of the displayed paid fees, conditional on the separately audited threshold transfer. It does not prove the remaining complete \(V_{\rm new}\) geometric payment or close the theorem.

## 1. Analytic screening before calculation

For fixed p>0 and integer q≥1, set \(\gamma=N^p\), \(h=1/(pq)\), where \(N=A_n>1\). Then

\[
\gamma^h=N^{1/q}\le N,\qquad
\frac{\log_\gamma\max(\gamma^h,N)}h=q,
\qquad J=1+\lfloor q\rfloor=q+1.
\]
This identity is exact for all N>1. J is a safe phase count, not asserted minimal. In particular, a floating ball straddling the integer q must not be used to decide the floor.

Since \(\sqrt{C_h}=20/(3-h)\), the requested condition is exactly

\[
\frac{40(q+1)}{3pq-1}
<\frac{(pq-3)^2}{p^2q^2}.
\]
Its positive-denominator residual has numerator

\[
(pq-3)^2(3pq-1)-40p^2q^2(q+1).
\]
For p=16 this is \(2048q^3-15104q^2+528q-9\), so three deliberate candidates q=4,8,16 suffice to exhibit a failure, a narrow pass, and a more comfortable pass. No parameter search is needed.

| p | q | h | J | Right-minus-left exact | Decision |
|---:|---:|---|---:|---|---|
| 16 | 4 | 1/64 | 5 | -108489/782336 | FAIL |
| 16 | 8 | 1/128 | 9 | 86135/6275072 | PASS |
| 16 | 16 | 1/256 | 17 | 4530423/50266112 | PASS |

For the selected q=16,

\[
d=1-3h=253/256,\quad C_h=26214400/588289,
\]
\[
2hJ\sqrt{C_h}=680/767,
\quad d^2=64009/65536,
\quad d^2-2hJ\sqrt{C_h}=4530423/50266112>0.
\]
Arb192 encloses this margin in
\([0.090128773038981013689700,0.090128773038981013689701]\).
The equivalent full-mother clock absorption ratio and its remaining relative margin are exactly

\[
\frac{4J^2h^2C_h}{d^4}
=\frac{1985992877670400}{2410309500579409}<1,
\qquad
1-\frac{4J^2h^2C_h}{d^4}
=\frac{424316622909009}{2410309500579409}>0.
\]
This tests the stated clock-envelope coefficient. It does not identify a Vcap coefficient with a Bpi coefficient or silently allocate separate full credit to several row pieces; the actual complete incorporation is the integrator's proof obligation.

## 2. Threshold reset and its paid costs

Let j≥0 denote tree depth, to avoid confusion with the margin d. Reset

\[
\varepsilon_j=
\frac1{2GN\gamma^{2+h}r^2(j+1)(j+2)}.
\]
The exact telescope \(\sum_{j\ge0}[(j+1)(j+2)]^{-1}=1\) gives

\[
2GN\gamma^{2+h}r^2 S^2\sum_j\varepsilon_j=S^2.
\]
Thus the arithmetic of each proposed wide/exception payment is S²W, rather than carrying \(\gamma^{2+h}r^2S^2W\). This statement is conditional on the integrator's independent proof that the redefined threshold is used consistently throughout the true wide/exception/head/core construction; the scalar computation is not that proof.

For the chosen constants,

\[
\gamma^{2+h}=N^{513/16},\qquad
\boxed{\varepsilon_j=[32N^{529/16}(j+1)(j+2)]^{-1}.}
\]
Hence the inverse threshold is polynomial in N, while its logarithm is

\[
\ln\varepsilon_j^{-1}
=\ln32+\frac{529}{16}\ln N+\ln(j+1)+\ln(j+2).
\]
No inverse-epsilon source fee is introduced by this algebra. Any proposed later step that charges such a fee would need a separate audit and is not covered by the compatibility conclusion.

With the unchanged \(\delta_{\rm head}=1/8\), use the safe redefined degree

\[
m_j=\min\left\{n,\left\lceil
\log_2\frac1{\delta_{\rm head}^2\varepsilon_j}
\right\rceil\right\}.
\]
Then the usual tail factor satisfies \(2^{-m_j}\le\delta_{\rm head}^2\varepsilon_j\) when the degree does not saturate; when m_j=n the tail is zero. Define

\[
k_j=\max\left\{2,\left\lceil\frac{\ln(3/\varepsilon_j)}{\ln(9/8)}\right\rceil\right\},
\quad a_j=\varepsilon_j(3/4)^{k_j},
\quad L_j^{\rm core}=\ln(2/a_j).
\]
Ceiling inequalities, not dimension samples, give for every n≥2 and j≥0

\[
k_j,\ L_j^{\rm core}
=\Theta(\ln(n+2)+\ln(j+2)),
\qquad
m_j=O\big(\min(n,\ln(n+2)+\ln(j+2))\big).
\]
Relative to the prior threshold, the added logarithm is exactly \((2+h)\ln\gamma+2\ln r\), so the degree/core enlargement is additive O(log gamma) for fixed h,r. The proof uses a smaller tail threshold, not a new multiplicative count of all head components.

## 3. All displayed n-dependence, without fitting finite points

In the new local construction with G=4,

\[
N=A_n=1+n\ln2+\ln8=1+(n+3)\ln2=\Theta(n).
\]
For every n≥2, the parameters depend only on n and the fixed constants, not on the weak threshold, scale band, source input or truncation. In particular

\[
\begin{aligned}
C_0&=1+\ln2+16\ln N,\\
F_{\rm cap}&=4[1+\ln8+(257/16)\ln N],\\
K&=(2+\ln4)F_{\rm cap},\\
A_{\rm act}&=8[1+\ln2+(513/16)\ln N],\\
R_A&=\min(K,A_{\rm act}).
\end{aligned}
\]
All five quantities are Theta(log(n+2)). The **final audited action bound** is \(r_C\le R_A/I_C\). There is no exterior \(\gamma^h=N^{1/16}\) factor in this cap. Using the older \(R_0=\gamma^hA_{\rm act}\) at this point would reintroduce a genuine power loss and would invalidate the stated fee orders.

The old witness windows and the larger analysis cutoff have different exact clocks:

\[
D_{\rm local}=1+\frac{(n+1)\ln2}{16\ln N},
\qquad
D_{\rm cut}=1+\frac{N-1+\ln2}{16\ln N}
=1+\frac{(n+4)\ln2}{16\ln N}.
\]
Both are Theta(n/log(n+2)); their exact constants are not silently identified. Each source lemma must retain its own valid clock support.

The core reference scale is
\[
r_*=(g\gamma^{1+h}r)^{1/n}R_C,
\qquad \gamma^{1+h}=N^{257/16}.
\]
For n≥2, N≤(9/4)n and n≤2^{n−1}, hence N^(1/n)≤3. Since g≤G=4 and r=2,

\[
r_*/R_C\le\sqrt8\,3^{257/16}.
\]
Thus even the physical core radius \(2r_*L_j^{\rm core}\) is at most a fixed constant times \(R_C[\ln(n+2)+\ln(j+2)]\). The actual reference-center **volume** factor \(\gamma^{1+h}\) is not bounded independently of n; its wide/exception cost is the one canceled by the threshold reset. Volume and side-length conclusions are kept separate.

The active paid ledger therefore has the following parameter orders:

| Quantity | Order or exact value |
|---|---|
| N | Theta(n) |
| gamma | Theta(n^16) |
| gamma^h | N^(1/16), absent as an exterior final row-cap factor |
| J and d | 17 and 253/256 |
| C0, Fcap, K, Aact, RA | Theta(log(n+2)) |
| Dlocal, Dcut | Theta(n/log(n+2)) |
| reset wide and exception fees | at most S²W each, subject to the separate gate proof |
| low/rapid deletion c=C0(1+G) | Theta(log(n+2)) |
| direct low-field/low-growth source coefficient K+Fcap | Theta(log(n+2)) |
| Brem=C0 S(1+2G) | Theta(log(n+2)) |
| inherited displayed C after reset Kw=S² | O(log(n+2)) because J/d² is constant |
| global cover source repetition, if used | O(log(n+2)); unchanged by this parameter choice |
| head degree and core logarithm | the uniform depth bounds above |
| clock-envelope absorption margin | fixed positive rational, independent of n |

The ordinary complete row source bound \(R_A^2D\) is still Theta(n log(n+2)), not polylogarithmic. Also the score envelope has \(\gamma^h\to\infty\), so its low-score factor tends to one; the alternative \(R_A^2SN^2\beta/C_0\) is generally of order n²log(n+2). Neither generic bound pays the desired smaller complete \(V_{\rm new}\). The successful parameter choice removes the prior *parameter incompatibility* and leaves that precisely stated same-measure geometric payment open.

## 4. One actual implementation check and reproduction

The single saved run checks three exact rational candidate pairs and one n=2 instance. It does not scan dimensions. At n=2 it independently obtains J=17 by the exact identity, k_0=465, m_0=2, and
\(L_0^{\rm core}\in[188.100043627981482170451861,188.100043627981482170451862]\).
The large finite core constant does not affect the analytically proved logarithmic order. All other outward parameter intervals are in JSON.

```sh
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/ccu_r571_parameter_certificate.py --output /tmp/ccu_r571_parameter_certificate.json
```

Applied L03 exact/interval workflow. Ten SymPy residuals are zero. Candidate signs are exact Fraction comparisons and independently enclosed by Arb192. Exact dyadic endpoints are exported through lower()/upper().fmpq(), then decimal endpoints are obtained by exact floor/ceiling at 24 places. Integer phase count J is deliberately not obtained by approximate floor. No optimizer, quadrature, MATLAB, child agent, PDF, repository edit or other-author edit occurred.

Actual versions: {"python": "3.12.14", "interpreter": "/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python", "sympy": "1.14.0", "python_flint": "0.9.0"}. Cost: {"seconds": 0.022516874996654224, "maxrss_bytes_macos": 72351744, "processes": 1, "Arb_bits": 192, "candidate_pairs": 3, "dimension_checks": 1, "optimizers": 0, "quadratures": 0, "MATLAB_runs": 0}.

Script SHA256: `98a3edd709c8d1d46e7764fc7ce82ceed4fbfabd49cdf5325ba5fa9f490d6036`. JSON SHA256: `77a9d73e1d5186c31c4b095c41668094037444f95948951ac40be56bfd6c2277`.

Read formula sources (their proof audits remain assigned separately):

- ccu_r571_history_bridge.md: `5271786332e08352e9fdbffc1a74585353552b14a63893a166af337405a8ffef`.
- ccu_r571_astra_local_entry.md: `398634a3fb7542cd44c2189ac69a0c1210fa0a1e2e4d94ce7d72564775225919`.
- ccu_r571_astra_clock_attack.tex: `293877eb6c515b01a99c6917e71cb45fbe0ff46ebc396281d55c6388d97d1c21`.
- ccu_r571_audit_actioncurve.md: `c6e008da2868354a25baf44bf3ed5f69618f270437a7bae0a73421ea25abdd08`.
