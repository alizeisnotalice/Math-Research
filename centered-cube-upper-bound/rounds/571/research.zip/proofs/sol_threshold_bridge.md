# R571 Sol：真实 last-hit 阈值图的独立核准、零窗移母式与旧质量扣盒

本稿只写 `/tmp/ccu_r571_sol_threshold_bridge.*`。没有修改仓库、他稿或 PDF，没有子 Agent。已读 live_next、generator_global、新 local_entry §§1–4、threshold_graph_bridge、其独审，以及 R561 的实际共同树/整数矩证明。下文重新给出论证，不把聊天中的“已证”当作前提。

**结论范围：完整阈值图几何桥成立，并且精确阈值动作的母式可取 d=1。** 另外，旧质量排除可以用真实子节点质量合法加入同一个可付中心容量。没有得到完整 Cstar_graph 的新 a,L，因而没有证明一般中心立方体 maximal 的目标弱型界。

## 1. 输入、量词和完整真实 Gram

固定任意 n≥1、非负 f∈L¹(Rⁿ)、μ=f dx、W=μ(Rⁿ)<∞。沿新 local_entry，所有父中心是实际 Lebesgue 中心，可测 R_B∈[a,2a]，q≤q_B≤λ，r=λ/q；新入口 q=λ/2、r=2。只取同一新 bulk，旧 L_i、e_B、Q0 完全冻结。源格互斥，每个合法扩张盒都在其源格中，故 full mass 等于 cell restriction；以下不更换任何质量。

设 γ>1、0<h<1/3、G>1，m_B=q_B R_Bⁿ、s_B=log_γm_B，Γ_j=γ^(jh)。对所有可达 j，即 Γ_j≤κ_B(G)，定义

    g_Bj=max{g∈[1,G]:κ_B(g)=Γ_j},
    p_Bj≥0,  Σ_available j p_Bj=1,
    x_Bj=p_Bj/g_Bj,

不可达 j 设 p=x=0。这里任意可测 p 均可；GA8 waterfill 是一个实例。本稿不重选 p。所有对象可依赖完整已知输入，但必须在随后计价 source 之前确定。

μ 绝对连续保证嵌套盒质量曲线连续、非降，故每个可达水平集非空紧。last hit 也是 `sup{g:κ_B(g)≤Γ_j}`，用有理尺度和端点 G 测试给可测性。包括：j=0、立即增长时 g_B0=1、初始质量平台、κ_B(G)=Γ_j、全部概率原子。没有假设平台长度正下界。存在统一有限 J，使全部可达 j∈{0,…,J−1}。

动作 j 的真实质量窗恰为 `[s_B+jh,s_B+jh+1]`，相位恰为 j。对每个 phase 平移 −jh 是等距变换。因此完整真实动作平方严格等于

    Bπ = Σ_i,j ∬_[bulk_i²] a_B a_C x_Bj x_Cj τ(s_B−s_C)
                  μ(Q_B(g_Bj)∩Q_C(g_Cj)) dB dC,       (1)
    a_B=R_B^(−n),  τ(t)=(1−|t|)_+.

这是全部有序父对、真实 source 交集和真实 1/(g_Bj g_Cj)；old/new 与 shell 交叉都在 (1)，不是仅 old 或对角替代。零质量/空 bulk 独立平凡处理。有限性可先由下节包络与新入口 phase cap 得到；后续也可从非负截断用 Tonelli 通过极限。

## 2. 真动作 L¹与全中心图共同参考边长

令

    Aact=1+n ln2+lnG.

对固定来源 y，置 ρ=2||B−y||∞。实际新边长 P_Bj=g_Bj^(1/n)R_B∈[a,2aG^(1/n)]，故

    Σ_j p_Bj P_Bj^(−n)1_[y∈Q(B,P_Bj)]
      ≤ max(a,ρ)^(−n)1_[ρ≤2aG^(1/n)].

先用同一父 Σp=1，再积分真实中心，径向体积 `|{ρ≤u}|=uⁿ` 给

    ∫bulk q_B Σ_j Γ_j x_Bj dB
       = Σ_i,j ||A_ij||₁ ≤ Aact W.                    (2)

窗长为 1。这里保留 Γ_j，不将它替成 Kmax，不逐 phase 领取 W。这是真正随机 selector 的中心包络，不是对原子 graph 误用 fixed-g Fubini。

固定一个实际外槽 (C,j)，记 v=g_Cj、M=Γ_jm_C、ν=μ|Q_C(v)/M。只要 (1) 中 tent 非零，就有

    γ^(−1)<m_B/m_C<γ,
    R_Bⁿ≤D0 R_Cⁿ,   D0=γr,
    g_Bj R_Bⁿ≤G D0 R_Cⁿ=:r_*ⁿ.                        (3)

同 j 的 Γ_j 精确相消，故这里没有额外 γ^h。共同 r_* 只依外父 C，完全不依内父 B 及其实际 g_Bj。在整张 tent-positive 中心 graph 上

    Q_B(g_Bj)⊂Q(B,r_*).                                (4)

参考盒可以越过 source cell；它只用于对真实来源概率作上界，不改变真实动作盒和质量。

## 3. 同一 source 树、中心容量、head 与 core 的逐项核准

在外盒 Q_C(v) 上建循环坐标中点二分的共同矩形树。正节点 T 有条件概率 ν_T；零质量节点略去。每深度 d 有 `Σ_T ν(T)=1`。固定实际内父 (B,j)，首次条件捕获

    c_BjT:=ν_T(Q_B(g_Bj))>θ0=3/4

的节点组成其反链 S_Bj。矩形树生成 Borel，条件期望收敛，故

    ν(Q_B(g_Bj))=Σ_[T∈S_Bj] ν(T)c_BjT.                (5)

这是逐 tuple 的恒等式，然后非负 Tonelli 积分；不需统一不可数零集。所有低重叠也在后续 first-stop 中，无树终端残项。不同内父的停节点可重叠、嵌套，本稿从不假设跨父反链。

在 stop 上，用质量为 1 的层蛋糕测度

    χ=θ0 δ_θ0 + 1_(θ0,1)dθ,
    c=∫1_[c>θ]χ(dθ).                                 (6)

θ0 原子保留；根 stop 也保留。

对固定 (C,j,T)，定义 p_*(B)=ν_T(Q(B,r_*))。由 (4)，c_BjT≤p_*(B) 在真实 tent 支撑成立。令分位宽 w_l(θ)=q_Tl(θ)−q_Tl(1−θ)，

    O_T(θ)=Π_l[q_Tl(θ)−r_*/2, q_Tl(1−θ)+r_*/2],
    P_T(θ)=|O_T(θ)|/r_*ⁿ=Π_l(1−w_l(θ)/r_*)_+.

真实图的 `{c_BjT>θ,tent>0}` 包含于同一个 O_T(θ)。这里使用严格超水平，所以 CDF 平台端点没有错误反推。

对整数 k≥2，令

    K_k=∫ Π_l(1−range(z_1l,…,z_kl)/r_*)_+ ν_T^⊗k(dz).

精确中心身份 `∫p_*^k dB=r_*ⁿ K_k` 来自 k 点同时落入盒的中心交集。它不把 source 坐标当独立。因而实际 graph 的同一中心集有两个容量帽，可以取最小值

    |{B:tent>0,c_BjT>θ,任意额外正门}|
       ≤r_*ⁿ Pjoint_T(θ),
    Pjoint_T(θ)=min{P_T(θ),θ^(−k_d)K_kd}.              (7)

没有将两个体积帽相乘，也没有对 δ_gBj 的 graph 使用 fixed-g 积分。

设

    Hgraph=γ²r²G Aact,
    ε_d=[Hgraph(d+1)(d+2)]^(−1),
    k_d=max{2,ceil[ln(3/ε_d)/ln(9/8)]},
    δ_head=1/8,
    m_d=min{n,ceil log₂[1/(ε_d δ_head²)]}.               (8)

以 `Pjoint≤ε_d` 划 wide。在固定 O=O_T(θ0) 的归一化 product Lebesgue 中心测度上对 p_* 作 ANOVA 分解，H_m 为次数≤m 的 head。空/零体积 O 对中心积分无贡献。

单 source 盒 indicator 在各坐标的平均设为 t_l，则其加权 ANOVA 平方和为 `Π_l[t_l²+2t_l(1−t_l)]=Π_l(2t_l−t_l²)≤1`。对 ν_T 一次 Hilbert Jensen 得

    Σ_A 2^|A| ||F_A||²≤1,
    ||p_*−H_m||²≤2^(−m−1)        (m<n),

m=n 时尾为零。在 narrow 内以 `H_md(B)≤θ−δ_head` 划 exception。因 p_*≥c>θ，Chebyshev 给它的未加权中心体积≤ε_d|O|≤ε_dr_*ⁿ。这个 product 结构只属于 Lebesgue 中心盒。

为 core 置

    a_d=ε_d(3/4)^k_d,  L_d=ln(2/a_d),  Gate=1_[K_kd>a_d].

joint narrow 存活 ⇒ Gate。独立检查集中反推如下：令辅助样本坐标总 range 为 R；乘积核≤exp(−R/r_*)，故 `K>a_d` 强迫

    P{R≤r_*L_d}>a_d/2.

若所有半径 r_*L_d 的闭 ℓ¹ 球质量均≤2/3，该概率≤(2/3)^(k_d−1)。但

    (a_d/2)/(2/3)^(k_d−1)
      = ε_d(9/8)^k_d/3≥1,

矛盾。因此存在质量>2/3 的此类球。用固定有理中心枚举，选首个半径 2r_*L_d、条件质量>5/8 的球，并令其与 T 的交为 H_CjT。Gate=0 时 H=∅。存在性有半径余量，联合可测性由可数枚举得到。它只依 (C,j,T)，不依内父 B 或被计价 source。

真实 stop c>3/4 时 inclusion-exclusion 严格给

    ν_T(Q_Bj∩H)>c−3/8≥c/2.                            (9)

## 4. 两笔全量费用与完整 Cstar_graph

在非零 tent 支撑上

    a_B x_Bj τ≤1/R_Bⁿ=q_B/m_B≤γλ/m_C.                 (10)

注意分母是 m_C，不是 M；后者会漏 Γ_j。固定 (C,j,T,θ)，由 (7) 对 wide 图或由 head 尾界对 exception 图，内中心体积各≤ε_dr_*ⁿ。乘真实来源质量 Mν(T)，保外父 a_Cx_Cj，单项至多

    γλ Γ_j x_Cj G D0 ε_d ν(T).

每深度求节点只用 Σν(T)=1，χ 总质量只用 1。随后外父全部 slots 一起用 (2) 和 λ≤r q_C，得到每一支

    Fee≤γr G D0 (Σε_d)∫q_CΣ_jΓ_jx_Cj dC
       ≤γ²r²G Aact (Σε_d)W=W.                        (11)

故两支互斥但合计付款是 2W；没有 J、Kmax 或节点数量。整张中心 graph、所有 source cells、原子、同一父全部概率均已包含。

在 stop 上定义

    b_BCjT=(1/c_BjT)∫1_[c_BjT>θ]1_[Pjoint>ε_d]
                       1_[H_md(B)>θ−δ_head] χ(dθ),

非 stop 设 0。则 0≤b≤1，且 b=b Gate。令

    Cstar_graph=Σ_i,j ∬ a_Ba_C x_Bj x_Cj τ(s_B−s_C)
          Σ_[T∈S_Bj] b_BCjT Gate_CjT
                         μ(Q_Bj∩H_CjT) dB dC.         (12)

同一正分解中全部 head 剩余由 (9) 至多 2Cstar_graph。于是

    Bπ≤2W+2Cstar_graph.                               (13)

还可直接核 `0≤Cstar_graph≤Bπ`：H⊂T⊂Q_Cj，每内父的停节点互斥，b≤1。这个有限性上界不产生任何小系数。式 (13) 只是完整桥，绝不是 Cstar 已付。

## 5. 精确阈值动作的母式：d=1

记 A_ij 是原真实动作场，U_−jh 平移其质量窗，Z_i=Σ_jU_−jh A_ij。因为每个 action 旧盒包含于新盒，且窗精确对齐，在原 source/σ 空间逐点有

    Z_i≥∫bulk_i k_B Σ_jx_Bj dB≥L_bulk,i/G.             (14)

无残余 δ∈[0,h)，故这里完全没有 3h 窗边费。令 `Edel=E_low+E_rapid≤C0(1+G)W`，旧冻结分账为 `Q0−Edel=Σ_i<L_i,L_bulk,i>`。由 (14) 和一次真实直和 Cauchy，

    Q0−Edel≤G Σ_i<L_i,Z_i>
       ≤G sqrt(Q0 Σ_i||Z_i||²)
       ≤G sqrt(J Q0 Bπ).

因此此动作族确有更精确完整母式

    Q0≤C0(1+G)W+G sqrt(J Q0 Bπ).                      (15)

所有低/rapid 删除仍只领原来一次付款。没有把固定 ρ 的母式或 Yhat 系数搬来。

若将来对同一完整 Bπ 得到 `Bπ≤aQ0+LW`，充分吸收阈值是严格 `a<1/(G²J)`。等价地经 (13) 使用 Cstar 预算时须 `Cstar_graph≤a_*Q0+L_*W` 且 `2a_*<1/(G²J)`。

给出精确常数以便复核：设 c=C0(1+G)、t=G²J、β=ta<1，则 z=Q0/W 满足

    z≤[2c+tL+sqrt(t²L²+4ctL+4βc²)]/[2(1−β)].         (16)

若 z≤c，式子自动覆盖；否则平方 (15) 后解二次式即可。弱入口仍为新 local_entry 的实际 `λ|E|≤2/(1−η) sqrt(DWQ0)`，没有重建旧 history。式 (16) 的新代数由本机 SymPy 实际执行核验；它不核验未知 Cstar 预算。

## 6. 真实方体几何的可加增强：正确子质量下的旧盒排除

这是本次在完整 payer 方向实际核出的额外几何约束；尚不足以收完 (12)。固定 (C,j,T)，取来源前可测轴对齐矩形 `K=Π_l[u_l,v_l]⊂T`，β_T=ν_T(K)。若

    Γ_j ν(T) β_T≥γ,                                  (17)

则 `μ(K)=Γ_jm_Cν(T)β_T≥γm_C>m_B` 对所有非零 tent 内父成立，故真实旧 Q_B(1) 不可能包含 K。

令

    R_−=max{a,[m_C/(γλ)]^(1/n)},
    V_K=Π_l[v_l−R_−/2,u_l+R_−/2],                     (18)

反向端点使盒为空。由 m_B>m_C/γ、q_B≤λ，实际 R_B≥R_−。若 B∈V_K，则旧盒已经包含 K，违反上段结论。因此在 (17) 下，整个实际内父 graph 满足

    {B:tent>0,c_BjT>θ,真实全部门}⊂O_T(θ)\V_K.          (19)

其体积是 `|O_T(θ)|−|O_T(θ)∩V_K|`，绝不能直接减 |V_K|。令 Pexclude 为此差除以 r_*ⁿ；(17) 不成立时设 Pexclude=P_T(θ)。现在可把 (7) 的容量严格增强为

    Pjoint⁺=min{Pjoint,Pexclude}.                      (20)

这是同一真实中心集合的第三个有效帽。因此沿 (8)–(13) 把 wide 改用 Pjoint⁺≤ε_d、head 权 b 同步重建，两个补集仍各≤W，core 构造也继续有效，因为新 narrow 蕴含旧 narrow。新的 Cstar_graph⁺≤旧 Cstar_graph；没有新增一份 W 或重新选物理动作。

一个无需额外假设的 K 选择：取已构造 core 球的坐标外接盒与 T 的交，得到矩形 K⊂T，含 H、β_T>5/8。此时 `Γ_jν(T)≥8γ/5` 是 (17) 的充分条件。若改用实际 β_T，(17) 可更精确。

**这一增强的准确限制：** 必须使用子质量 Γ_jm_Cν(T)，不能把根的 Γ_jm_C 发给每个节点。K 的某一边可以大于 R_−，此时 V_K 为空，(20) 没有改善。即使 V_K 有正体积，也尚未证明它与 O_T(θ) 的交能跨全部 (C,j,T) 支付剩余 graph。现有 core 半径仅为 O(r_*log n) 的 ℓ¹ 半径，不保证含质量>5/8的轴向外接矩形各边≤R_−。

## 7. 停止点与交付判定

已核准：指定任意阈值 p 的全部 source/phase/plateau/概率原子和无穷树极限；完整真 Bπ 的两个全量补集各≤W；head/core 共同于全部内父 graph；精确阈值窗令 d=1；正确子质量的旧盒排除可并入同一可付容量。

未证明：对 (12) 或增强后的同一 Cstar_graph⁺，有跨外父、来源、旧质量层和全部停节点的 `a_*Q0+polylog(n)W`，且 `2a_*<1/(G²J)`。没有新的 a_*,L_* 可代入 (16)。单节点 core 条件质量、old-containment 扣盒、真实 action L¹以及 graph 命名本身均不替代该全局付款。

因此本稿完成的是独立严格连接及一条具体方体容量增强，**不登记为一般弱型目标完成**。未跑重复扫描或数值优化。本机只运行本稿新 (16) 的一次标量符号核验，记录在同前缀 `.checks.json`。
