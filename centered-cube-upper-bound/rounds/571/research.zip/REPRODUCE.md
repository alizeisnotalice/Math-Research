# 第571轮复现与证据范围

先读 `REPORT.tex`；本包不提供一般根阶弱型定理。没有编译 PDF。

实际数学环境：`/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python`，Python 3.12.14、SymPy 1.14.0、NumPy 2.5.4、SciPy 1.18.1、python-flint 0.9.0。本轮沿用64项数学工具中的 L03 有理/区间证书原则：数值优化候选、向外区间、精确代数和一般证明分开；旧 skill 的 API 未核状态不作为本轮软件认证。本包的实际运行与检查结果才是计算证据。

## 推荐：只复核已冻结证书

解压到任意目录，在该目录执行：

```sh
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python run_checks.py --output /tmp/r571_recheck.json
```

其他电脑可使用含上述库的 Python。脚本自动限制 BLAS 线程，创建独立临时输出，核验后清理。它不会改写包内数据，不运行优化，不加中心网格，不运行 MATLAB，不编译 PDF。

检查内容：最终 action-cap/母式的9个符号恒等式和4+5个固定 Arb 点；备选参数的精确判据；重建深度预算的精确代数；冻结二维数据的208个 j0 末次命中和71个 j1 有理多项式根夹逼，以及整体 bulk 的 Arb160 常数。能量部分仅重建保存概率和代理尺度的 binary64 账本。

`VERIFICATION.json` 记录主代理在精简包中实际运行的结果。`numeric/ccu_r571_archive_verify.json` 是独立作者先前复核记录，运行元数据不同不影响数学内容。`gamma_budget_audit.py` 的原始代码有一个历史绝对输出路径；runner 仅在临时副本中重定向该路径并比较全部输出表达式，不覆盖原始记录。其余两个标量脚本支持 `--output`。

## 二维计算已停止，原程序仅用于追溯

`numeric/ccu_r571_sol_joint_numeric.py` 是实际执行代码，JSON 记录全部中心、权重、质量、阈值证书、概率和结果；MD 是原实验笔记。原始代码 SHA 必须与 JSON 中 `code_sha256` 一致。

只运行过 8×8、12×12 两档，后两种候选能量变化超过10%触发预定停止。没有证明连续中心积分，也没有证明浮点最优性。保留这一停止决策，归档验证不重新执行该优化程序。原脚本写固定 `/tmp` 输出，若另行设计新实验，先复制/修改输出路径并另立研究任务，不能覆盖本轮证据。

精确 j1 根的实际相位由质量阈值语义确定，不以浮点 floor 决定。半径夹逼宽2^-48；完整代理 g 误差是2^-47+2^-51。JSON 已保存原元数据遗漏平方舍入项的明确勘误，不把勘误包装为一次新的优化运行。

独立复核发现部分 waterfill 概率最大1+2^-52、行和偏差约4.44e-16。它们只在1e-14容差内可行，不是精确概率证书。能量重建通过不消除此问题，也不认证连续几何。

## 早期 MATLAB 标量检查

`numeric/ccu_r571_numeric.py/.json/.m/.matlab.json` 仅保留20个形式标量的 Python/MATLAB 交叉证据，不能认证物理来源模型或完整 history。该早期支线没有证明全量预算，最终报告不依赖它的几何猜测。

原实际命令为指定 Python 执行 `ccu_r571_numeric.py --output /tmp/ccu_r571_numeric.json`，随后 MATLAB `run('/tmp/ccu_r571_numeric.m')`。若需要独立复现该旧标量检查，复制四个同名前缀文件到独立目录，Python 指向该目录输出，再让 MATLAB run 该目录的 `.m`；`.m` 从自身目录读写数据。不要把它当作二维实验的交叉核验。此次精简包复核没有重跑它。

## 证明来源与陈旧附件语句

`SOURCES.json` 给出每个最终附件的源路径与 SHA，以及基线提交中 R561/R565/R570 报告的可访问地址、包内成员和 SHA。`audits/archive_dependencies.md` 精确列出历史章节、公式与各附件作用。历史报告已在旧轮发布，故本包不复制。

附件中 `/tmp/ccu_r571_...` 对应本包 `proofs/`、`audits/` 下去掉前缀的同名文件；数值文件保留前缀。已省略的旧候选不是最终论证前提。特别说明：

- `astra_local_entry.md` 旧 §6 的 head/core 缺口已由 `history_bridge.md` 完成；后者旧 Kw 预算在 `gamma_budget_audit.md` 同步重建全部对象后更新。
- `cover_next.tex` 只使用 G1–G11；其旧入口和 own-crossing 变体不额外收费。
- `audit_actioncurve.md` 中 product 旁支不进入本报告，旧 SHA 仅为历史快照。最终字节由本包 SHA 清单决定。
- `sol_threshold_bridge.md` 的质量排除盒规则在两组主参数上触发为空；最终审查与 REPORT 明确收益为零。
- `final_review.md` 的“等待总报告”是先前检查点，最新整合稿审查见 `report_final_pass.md`。它提到系统/bundled Python 无 SymPy，不表示用户指定的独立环境缺该库；主代理已实际核实独立环境可用。
- 辅助证明提及未归档临时计算日志时，只作为历史运行说明；本轮主张依解析证明及本包最终证书，不依缺失日志来认证。

当前未付问题是同一完整场的联合几何预算，详见 REPORT 第9节；不能把这些接口、24项检查或附件数量当作该预算已成立。
