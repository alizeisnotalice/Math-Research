# R571 final independent certificate: Hph, sharp K cap, and the new mother

**PASS.** The updated action payment uses the independently audited \(H_{\rm ph}\) and the stronger common denominator \(r_C\le\min(K,A)/I_C\). The new local mother has absorption threshold \(a<d^2/(G^2J)\) and the exact upper root stated below. Old files remain frozen.

## 1. Final action-source coefficient and sharpness

Use distinct notation \(N=A_n\), \(c_\gamma=\gamma^h\), \(\ell=\Lambda-1=1+\ln G\), and

\[
A=2GS[1+\ln(\gamma^{2+h}r)],\qquad R_A=\min(K,A).
\]
The newly audited input is \(r_C\le R_A/I_C\), including \(K/I_C\). Together with
\(I_C\ge1+\ell/\max(c_\gamma,N\alpha_C)\), it gives

\[
\frac{r_C^2}{\alpha_C}
\le R_A^2 N f(x),\qquad
f(x)=\frac1x\left(\frac{\max(c_\gamma,x)}{\max(c_\gamma,x)+\ell}\right)^2,
\quad x=N\alpha_C\in(1,N].
\]
Nonempty original parent radii force \(\ell\le N\). On \(x\le c_\gamma\), f decreases toward its supremum at \(x\downarrow1\). On \(x\ge c_\gamma\), it equals \(x/(x+\ell)^2\), whose derivative is \((\ell-x)/(x+\ell)^3\). If \(\ell\ge c_\gamma\), its peak \(x=\ell\) is in the actual domain. If \(\ell<c_\gamma\), the low-end value exceeds \(1/4\ge1/(4\ell)\). Hence the exact scalar supremum is

\[
\beta=\max\left\{\frac{c_\gamma^2}{(c_\gamma+\ell)^2},\frac1{4\ell}\right\}.
\]
This is a supremum over scalar scores under the stated domain; it does not assert simultaneous attainability by actual geometry. Without the true constraint \(N\ge\ell\), the high-branch peak must be clipped to its actual domain.

The final complete source coefficient certified from these inputs is

\[
\boxed{\mathcal L_{\rm act}
=R_A^2\min\left\{D,\frac{S N^2}{C_0}
\max\left(\frac{\gamma^{2h}}{(\gamma^h+\Lambda-1)^2},
\frac1{4(\Lambda-1)}\right)\right\}.}
\]
Equivalently, normalized by \(A^2\), its sharp score envelope is
\(\min((K/A)^2,1)\beta\).

The earlier nested expression
\(\max\{\min((K/A)^2,c_\gamma^2/(c_\gamma+\ell)^2),1/(4\ell)\}\)
was sharp for the weaker input \(r_C\le\min(K,A/I_C)\). Under the newly audited \(\min(K,A)/I_C\), it remains a valid upper bound but is generally **not sharp**. The fourth case below certifies strict improvement. Thus this update is not merely a substitution of Hph for Hold.

## 2. Exactly the same four action parameter cases

All cases retain S=1 and \(D=1+(N-1+\ln r)/\ln\gamma\). No new parameter grid was explored.

| G | gamma | h | r | N | Active row cap | Winning source branch | Certified final coefficient interval |
|---:|---:|---:|---:|---|---|---|---|
| 4 | 2 | 1/8 | 1 | 16 | A_Hph | alpha | [6199.656003262544727968316470, 6199.656003262544727968316471] |
| 4 | 2 | 1/8 | 1 | 32 | A_Hph | clock | [17895.599505894918763161352910, 17895.599505894918763161352911] |
| 4 | 2 | 1/8 | 1 | 1+2050ln2 | A_Hph | clock | [802734.642930198603910963802414, 802734.642930198603910963802415] |
| 3/2 | 256 | 1/4 | 1 | 29/10 | K | alpha | [636.681291507379878358885043, 636.681291507379878358885044] |

These finite cases establish only their stated comparisons. The general supremum and parameter formulas follow from the exact argument above, not from the table. As before, the coefficient pays the actual-row Cauchy invoice; it does not by itself pay the new local \(B_\pi\) or prove a dimension theorem.

## 3. Independent reconstruction of the local mother

The new local construction has S=1, \(d=1-3h>0\),
\(C_0=1+\ln(\gamma r)\), and \(c=C_0(1+G)\). Its one-time low/rapid decomposition gives deleted score at most cW. The shifted-field inequality gives

\[
G\sum_i\langle L_i,Z_i\rangle
\ge Q_{\rm bulk}-3hQ_0
\ge dQ_0-cW.
\]
Cauchy and \(\sum_i\|Z_i\|^2\le J B_\pi\) then give independently

\[
\boxed{dQ_0\le cW+G\sqrt{JQ_0B_\pi}.}
\]
No old recovery factor or repeated phase loss occurs in this algebra. The factor \(G^2J\) appears only after squaring the one Cauchy term. Young gives the valid weaker expression

\[
Q_0\le\frac{2c}{d}W+\frac{G^2J}{d^2}B_\pi.
\]
The scalar root calculation below is conditional on a genuine payment of the **same new** \(B_\pi\); substituting a Cstar/Vcap fee without its missing bridge would not meet this condition.

## 4. Exact root and exact absorption decision

Assume W>0 and an independently established \(B_\pi\le aQ_0+\mathscr L W\), with \(a,\mathscr L\ge0\). Put

\[
q=Q_0/W,\quad H=G^2J,\quad\Delta=d^2-Ha.
\]
Then \(dq\le c+\sqrt{Hq(aq+\mathscr L)}\). If q is at most c/d, there is already a bound. Otherwise the left side after subtracting c is nonnegative, so squaring is legitimate and yields

\[
\Delta q^2-(2dc+H\mathscr L)q+c^2\le0.
\]
For \(\Delta>0\), its upper root is

\[
\boxed{
q\le F_{\rm new}=
\frac{dc+H\mathscr L/2+
\sqrt{Ha c^2+dcH\mathscr L+H^2\mathscr L^2/4}}
{d^2-Ha}.}
\]
The root is at least c/d because

\[
F_{\rm new}-c/d
=\frac{Ha c/d+H\mathscr L/2+
\sqrt{Ha c^2+dcH\mathscr L+H^2\mathscr L^2/4}}{\Delta}\ge0.
\]
Thus it also covers the branch in which squaring was unnecessary. The polynomial identity and discriminant expansion are exact SymPy identities. Nonnegative square-root choice and the stated signs complete the proof; a floating residual is not used as the proof.

The sharp threshold for **this scalar mother** is

\[
\boxed{a<d^2/H=d^2/(G^2J).}
\]
At or above the threshold, \(Ha\ge d^2\), and
\(\sqrt{Hq(aq+\mathscr L)}\ge dq\) for every q≥0. Therefore the mother inequality itself then supplies **no finite upper bound**. This does not assert divergence of the true geometric quantity.

The relaxed Young consequence is
\[
F_{\rm new}\le\frac{2dc+H\mathscr L}{d^2-Ha}.
\]
For a=0 this is \(2c/d+H\mathscr L/d^2\), matching the local-entry display. Equality/zero cases follow by continuity or direct substitution; W=0 is treated directly by the zero source, not by dividing by W.

## 5. One consistent local critical case

This is separate from the four original action cases. Take
\(n=2,G=4,\gamma=2,h=1/8,r=2,\eta=1/2\), and illustrative paid budget \(\mathscr L=1\). Then

\[
A_{\rm local}=1+5\ln2,\quad
17<8\log_2(A_{\rm local})<18,\quad J=18,
\]
where the strict floor bounds were verified by Arb192. Thus

\[
d=5/8,\quad H=288,\quad D=4,\quad c=5(1+\ln4),
\quad a_{\rm crit}=25/18432.
\]
The old expression \(d^4/(4J^2)=625/5308416\) is not this mother's threshold. Their ratio is exactly \(288/25\).

| a | Delta | New absorption | Old threshold would accept | F_new certified interval |
|---|---|---|---|---|
| 0 | 25/64 | True | True | [774.990456697203481100310725, 774.990456697203481100310726] |
| 25/36864 | 25/128 | True | False | [1550.451309146517007940300811, 1550.451309146517007940300812] |
| 11/8192 | 1/256 | True | False | [77545.601007032615380904017397, 77545.601007032615380904017398] |
| 25/18432 | 0 | False | False | No finite bound from this mother |
| 101/73728 | -1/256 | False | False | No finite bound from this mother |

In particular a=25/36864 and a=11/8192 are valid for the new absorption contract although the old threshold would reject them. The latter has only one percent relative absorption margin and accordingly a much larger root. These numerical examples do not establish the required Bpi geometric payment; they show the correct decision once its a and L are supplied.

For this local r=2, eta=1/2, D=4 case, the local weak multiplier from \(2(1-\eta)^{-1}\sqrt{D F_{\rm new}}\) is \(8\sqrt{F_{\rm new}}\); its interval is also stored in JSON. The global cover and its further source repetition factor are not silently omitted from a claimed global theorem.

## 6. Actual run, precision and reproduction

One saved inexpensive run checked nine exact SymPy zero residuals, the same four action cases, and five exact critical fractions in one local case. No optimizer, scan, quadrature, MATLAB, child agent, PDF or repository/other-author edit was used. Earlier certificates were not modified.

```sh
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/ccu_r571_certificate_final.py --output /tmp/ccu_r571_certificate_final.json
```

Arb precision is 192 bits, one thread. Inputs are exact rationals or explicitly built log/exp expressions. Endpoints are outward-rounded exact dyadics exported through lower()/upper().fmpq(); decimal endpoints are exact rational floor/ceiling at 24 places. The numerical root-equation residual encloses zero as an implementation consistency check. The general root identity is separately exact, and the finite cases are not extrapolated to prove a general assertion.

Actual interpreter and versions: {"python": "3.12.14", "interpreter": "/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python", "sympy": "1.14.0", "python_flint": "0.9.0"}.

Cost: {"seconds": 0.0768030000035651, "maxrss_bytes_macos": 74858496, "processes": 1, "Arb_bits": 192, "action_cases": 4, "absorption_cases": 5, "optimizers": 0, "quadratures": 0, "MATLAB_runs": 0}.

Script SHA256: `d260299e99c0078b047a5c91ff0d7712b2741201ecf7bd344faee143355947bd`. JSON SHA256: `9bc497ef19325dc63ade01619b6dd080aadcce76b204e7bc5562059f622e9375`.

Read input hashes:

- ccu_r571_audit_actioncurve.md: `c6e008da2868354a25baf44bf3ed5f69618f270437a7bae0a73421ea25abdd08`.
- ccu_r571_astra_local_entry.md: `398634a3fb7542cd44c2189ac69a0c1210fa0a1e2e4d94ce7d72564775225919`.
- ccu_r571_astra_integrator_bridge.md: `8e7226dc13cff2d726b5058ad0f7fe1adf0eb45fe23f2e669484a4f18b67f6eb`.
- ccu_r571_astra_action_certificate.json: `da5f8ff511c3dd2388c622eddb3679514845298aceaa9ed2535e42ddfff5a78b`.
