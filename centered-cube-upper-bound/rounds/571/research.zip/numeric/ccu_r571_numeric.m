% R571 independent bounded scalar crosscheck. No geometry/history or figures.
% Root may execute: run('/tmp/ccu_r571_numeric.m')
folder=fileparts(mfilename('fullpath'));
reference=jsondecode(fileread(fullfile(folder,'ccu_r571_numeric.json')));
gamma=2;G=4;h=1/8;Lambda=2+log(G);
K=Lambda*G*(1+log(G*gamma^(1+h)));
R=min(K,2*G*gamma^h*(1+log(gamma^(2+h))));c=K/R;
ratios=[2 4 16 256];weights=[.1 .25 .5 .75 .9];rows=[];
opts=optimset('TolX',1e-12,'Display','off');tic;
for x=ratios
 for w=weights
  r=@(l)(w./(x*l+c*(1-l))+(1-w)./(l+x*c*(1-l)))/(w/x+1-w);
  [l,val]=fminbnd(r,0,1,opts);
  limit=1/(1+(-w*(x-c)/x^2+(1-w)*(x*c-1))/(w/x+1-w));
  rows=[rows; x,w,l,val,(1-l)/(1-l*val),limit]; %#ok<AGROW>
 end
end
elapsed=toc;
py=reference.sensitivity_pressure.rows;
maxerr=0;
for k=1:numel(py)
 maxerr=max(maxerr,abs(rows(k,4)-py(k).endpoint_ratio_float));
end
result=struct('scope','Formula-only independent scalar pressure table; not geometric/history evidence','K',K,'R',R,'c',c,'columns',{{'x','w','lambda','ratio','required_share','lambda1_share_limit'}},'rows',rows,'max_endpoint_ratio_difference',maxerr,'seconds',elapsed,'matlab_version',version);
fid=fopen(fullfile(folder,'ccu_r571_numeric.matlab.json'),'w');fwrite(fid,jsonencode(result,PrettyPrint=true));fclose(fid);
disp(result);assert(maxerr<1e-10);
