# Frozen R571 joint numeric task: stopped at sensitivity limit

This is one actual 2D three-box input, evaluated on the prescribed 64 and 144 tensor midpoint centers. No source sampling, extra grid, parameter scan, second solver, repository edit, PDF or general theorem. The previous certificate file was a 1D unit fixture. Process inspection found no live prior joint-numeric computation.

## Main result

| Law | Bpi, 64 | Bpi, 144 | relative change |
|---|---:|---:|---:|
| old_g1 | 0.571570729562 | 0.571320713804 | 0.0437% |
| last_j0 | 0.254670717396 | 0.229822931772 | 9.7568% |
| first_waterfill | 0.305498809728 | 0.306598437087 | 0.3599% |
| last_waterfill | 0.143306072726 | 0.125489924253 | 12.4322% |
| global_old_gram_surrogate | 0.106579434131 | 0.0921734209857 | 13.5167% |

**UNRESOLVED and stopped:** last waterfill and global surrogate exceed the 10% rule. Finite-grid gains cannot be treated as resolved continuous-center gains.

## Complete energy ledger

Every row uses Bpi=O2+2ON+N2, O2=P-Dgraph-Ddel, and Ddel=0 because the full E was proved bulk before quadrature. Young epsilon=1 yields Bpi <= 2O2+2 Cstar shellL1. Its slack is (O2-2ON+N2)+2(Cstar shellL1-N2); the positive majorant additionally pays 2Dgraph.

### 64 centers

Q0=0.571570729562; X=0.776034116745; j1 available for 22 centers; alpha range [0.29152075050879545, 0.3146786229325112].

| Law | O2 | 2ON | N2 | P | Dgraph | shell L1 | cap minus N2 | Young invoice |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| old_g1 | 0.5715707296 | 0 | 0 | 0.5715707296 | 0 | 0 | 0 | 1.143141459 |
| last_j0 | 0.2546707174 | 0 | 0 | 0.2995319539 | 0.04486123654 | 0 | 0 | 0.5093414348 |
| first_waterfill | 0.3049982842 | 2.821004073e-06 | 0.0004977044882 | 0.3996764194 | 0.09467813516 | 0.006946088873 | 0.0263088648 | 0.663609707 |
| last_waterfill | 0.1429667016 | 2.274596353e-06 | 0.0003370965119 | 0.2062460915 | 0.06327938984 | 0.005720314965 | 0.02173892674 | 0.3300854497 |
| global_old_gram_surrogate | 0.1057717873 | 4.81150087e-06 | 0.0008028353319 | 0.2102885032 | 0.1045167159 | 0.00882354154 | 0.03324925959 | 0.2796477644 |

QP: 6 L-BFGS-B iterations; numerical feasibility -0.0; projected KKT infinity norm 0.0; numerical Frank-Wolfe gap 0.0. Final probabilities have values [0.0, 1.0]. These are ordinary floating diagnostics, not outward-rounded optimality certificates.

Diagnostics on Q0 scale:
- old_g1: Dgraph/Q0=0; Young slack/Q0=1; shell-cap slack/Q0=0.
- last_j0: Dgraph/Q0=0.078487638; Young slack/Q0=0.44556291; shell-cap slack/Q0=0.
- first_waterfill: Dgraph/Q0=0.165645528; Young slack/Q0=0.626538202; shell-cap slack/Q0=0.0460290624.
- last_waterfill: Dgraph/Q0=0.11071139; Young slack/Q0=0.326782614; shell-cap slack/Q0=0.0380336599.
- global_old_gram_surrogate: Dgraph/Q0=0.182858762; Young slack/Q0=0.30279425; shell-cap slack/Q0=0.0581717325.

### 144 centers

Q0=0.571320713804; X=0.776069914264; j1 available for 49 centers; alpha range [0.29154471474032145, 0.31466095267566335].

| Law | O2 | 2ON | N2 | P | Dgraph | shell L1 | cap minus N2 | Young invoice |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| old_g1 | 0.5713207138 | 0 | 0 | 0.5713207138 | 0 | 0 | 0 | 1.142641428 |
| last_j0 | 0.2298229318 | 0 | 0 | 0.2745075037 | 0.04468457192 | 0 | 0 | 0.4596458635 |
| first_waterfill | 0.3061177597 | 1.418149189e-06 | 0.0004792591941 | 0.4007612496 | 0.09464348981 | 0.006817954014 | 0.02583280793 | 0.6648596537 |
| last_waterfill | 0.1251677408 | 1.155315207e-06 | 0.0003210281541 | 0.1819479413 | 0.05678020054 | 0.005583381693 | 0.02122653781 | 0.2934306135 |
| global_old_gram_surrogate | 0.091400679 | 2.354054343e-06 | 0.0007703879355 | 0.1860039164 | 0.09460323738 | 0.00864510057 | 0.03259306186 | 0.2495282576 |

QP: 8 L-BFGS-B iterations; numerical feasibility -0.0; projected KKT infinity norm 0.0; numerical Frank-Wolfe gap 0.0. Final probabilities have values [0.0, 1.0]. These are ordinary floating diagnostics, not outward-rounded optimality certificates.

Diagnostics on Q0 scale:
- old_g1: Dgraph/Q0=0; Young slack/Q0=1; shell-cap slack/Q0=0.
- last_j0: Dgraph/Q0=0.0782127636; Young slack/Q0=0.402266059; shell-cap slack/Q0=0.
- first_waterfill: Dgraph/Q0=0.165657375; Young slack/Q0=0.62707549; shell-cap slack/Q0=0.0452159484.
- last_waterfill: Dgraph/Q0=0.0993841098; Young slack/Q0=0.29395169; shell-cap slack/Q0=0.0371534539.
- global_old_gram_surrogate: Dgraph/Q0=0.16558692; Young slack/Q0=0.27542295; shell-cap slack/Q0=0.0570486262.

## Strict statements actually certified

All-E bulk: every old cube contains core mass 1, so 1<=m<=11/10. Exact rational (11/10)^7<2 gives old-window overlap >6/7. Therefore e>=(49/64)(6/7), and C<12/5 yields alpha>=1225/4928. Arb160 checked A=1+5ln2>89/20 and C=1+ln4<12/5; exact rational (89/20)(1225/4928)>11/10 gives A alpha>kappa(4). Thus no low/rapid deletion on all E, and Ddel=0. Exact (11/10)^4<2 ensures no phase j>=2 is reachable. Each old m is in the physical q band [11/20,11/10]. Source cell length32 and buffer b/2 contain every expanded cube.

For each j0 last hit the saved rational breakpoint has mass exactly m, and mass strictly grows on the immediately following polynomial interval (or it is cap). For j1, saved rational brackets satisfy M(lo)^8<2m^8<M(hi)^8, and the polynomial derivative is positive throughout the bracket. Since every plateau mass is rational while 2^(1/8)m is irrational, this root is both first and last hit. The actual phase is exactly1 by root semantics, never by flooring a floating midpoint. The saved polynomial coefficients and strict residuals are independent exact-Fraction checks.

The JSON records exact centers, weights, m, threshold polynomials/brackets, probabilities and proxy scales. The r bracket width is 2^-48; proxy g error <=2^-47+2^-51, including final binary64 square rounding. The executed script metadata initially omitted the latter term; JSON contains an explicit report-only erratum. Energy sums use ordinary binary64 analytic box products, not outward-rounded intervals. Exact root certificates do not certify these energies or center integration.

## Full mother and scope

C=2.38629436112, Cstar=3.85923211981, A=4.46573590280, d=5/8, D=4. The published global cap gives J=18 even though this input occupies only two phases. The full mother is dQ0 <= C(1+G)W+G sqrt(J Q0 Bpi), or Q0 <=2C(1+G)W/d+G²J Bpi/d². Its strict absorption requirement is a<d²/(G²J)=25/18432=0.00135633680556. The deletion bill is a valid universal allowance; actual deletion here is zero. The same proof may use the input occupied count2, but that is not the global J=18 bound. No polylogarithmic payer follows from this finite example.

Runtime: {'seconds': 0.12929654199979268, 'maxrss_bytes_macos': 84918272, 'processes': 1, 'QP_calls': 2, 'quad_grids': [8, 12]}. Versions: {'python': '3.12.14', 'interpreter': '/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python', 'numpy': '2.5.4', 'scipy': '1.18.1', 'python_flint': '0.9.0'}. No computation repeated after the sensitivity stop.
