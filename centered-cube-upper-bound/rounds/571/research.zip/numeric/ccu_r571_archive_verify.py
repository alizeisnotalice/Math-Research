#!/usr/bin/env python3
"""Independent frozen R571 archive verifier; never optimizes or writes input files.
Run from archive directory: python ccu_r571_archive_verify.py --data ccu_r571_sol_joint_numeric.json --source ccu_r571_sol_joint_numeric.py --report ccu_r571_sol_joint_numeric.md --out ccu_r571_archive_verify
Only finite-grid binary64 ledger consistency is claimed for energies.
"""
import argparse, json, hashlib, time, platform, sys
from pathlib import Path
from fractions import Fraction as F
from datetime import datetime, timezone
import numpy as np
import flint
from flint import arb, ctx

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--data',required=True);ap.add_argument('--source',required=True);ap.add_argument('--report',required=True);ap.add_argument('--out',required=True);args=ap.parse_args()
    start=time.perf_counter();checks=[];failures=[]
    def check(name,ok,detail=''):
        checks.append({'name':name,'passed':bool(ok),'detail':detail})
        if not ok: failures.append(name)
    paths={k:Path(getattr(args,k)) for k in ('data','source','report')}
    raw={k:p.read_bytes() for k,p in paths.items()};data=json.loads(raw['data']);report=raw['report'].decode()
    check('source SHA256 matches saved executed-code hash',hashlib.sha256(raw['source']).hexdigest()==data['code_sha256'])
    boxes=[(list(map(F,a)),list(map(F,b)),F(d)) for a,b,d in data['input']['mu_boxes']]
    expected=[([F(-1,32)]*2,[F(1,32)]*2,F(256)),([F(11,16),F(3,16)],[F(13,16),F(5,16)],F(16,5)),([F(-9,16),F(-13,16)],[F(-7,16),F(-11,16)],F(16,5))]
    check('frozen 2D three-box input',boxes==expected and data['input']['n']==2 and data['input']['h']=='1/8')
    def mass(c,r):
        ans=F(0)
        for a,b,d in boxes:
            ans+=d*max(F(0),min(b[0],c[0]+r/2)-max(a[0],c[0]-r/2))*max(F(0),min(b[1],c[1]+r/2)-max(a[1],c[1]-r/2))
        return ans
    def breaks(c):
        return sorted({F(1),F(2)}|{2*abs(t-c[k]) for a,b,d in boxes for k in range(2) for t in (a[k],b[k]) if 1<2*abs(t-c[k])<2})
    ctx.prec=160
    def ar(q):return arb(q.numerator)/q.denominator
    check('exact core/satellite masses', [d*(b[0]-a[0])*(b[1]-a[1]) for a,b,d in boxes]==[1,F(1,20),F(1,20)])
    # For all c in E each old unit cube contains the entire core: worst boundary is +/-1/16.
    check('all-E core containment',F(7,16)+F(1,32)<=F(1,2))
    check('exact log window and phase guards',F(11,10)**7<2 and F(11,10)**4<2)
    A=1+5*arb(2).log();C=1+arb(4).log();Cs=1+ar(F(33,8))*arb(2).log()
    check('Arb160 bulk bounds',arb(2).log()>ar(F(69,100)) and A>ar(F(89,20)) and C<ar(F(12,5)))
    bulk=F(49,64)*F(6,7)/F(12,5)/F(11,10)
    check('bulk alpha and Aalpha exact residual',bulk==F(1225,4928) and F(89,20)*bulk>F(11,10))
    # On any certified r1 bracket, |r-mid| <= 2^-49 and r+mid <= 4.
    # mid is dyadic with denominator <= 2^49, hence exactly binary64.
    # Squaring that exact midpoint has absolute rounding error <= 2^-51 (safe bound below 4).
    bound=F(1,2**47)+F(1,2**51)
    check('corrected stored proxy bound',F(data['input_evaluation_error']['g_proxy_absolute_error_bound'])==bound and 'bound_erratum' in data['input_evaluation_error'])
    counts=[];energy_diffs=[];probability_defects=[]
    def close(a,b):return abs(float(a)-float(b))<=2e-12*max(1,abs(float(a)),abs(float(b)))
    def inter(c,r,s):
        low=np.maximum(c[:,None,:]-r[:,None,None]/2,c[None,:,:]-s[None,:,None]/2)
        high=np.minimum(c[:,None,:]+r[:,None,None]/2,c[None,:,:]+s[None,:,None]/2)
        out=np.zeros((len(c),len(c)))
        for a,b,d in boxes:out+=float(d)*np.prod(np.maximum(0,np.minimum(high,np.array(b,float))-np.maximum(low,np.array(a,float))),axis=2)
        return out
    check('prescribed archive grids and stop',[(r['grid'],r['nodes']) for r in data['runs']]==[(8,64),(12,144)] and 'stopped' in data['status'] and data['cost']['QP_calls']==2 and data['cost']['quad_grids']==[8,12])
    for run in data['runs']:
        size=run['grid'];n=size*size;certs=run['threshold_certificates'];expected_centers=[(F(-7,16)+F(2*i+1,2*size)*F(7,8),F(-7,16)+F(2*j+1,2*size)*F(7,8)) for i in range(size) for j in range(size)]
        check(f'{n} centers and exact weight',len(certs)==n and [tuple(map(F,c['center'])) for c in certs]==expected_centers and F(run['weight_exact'])==F(49,64*n))
        root_count=0;root_ok=True;j0_ok=True;proxy_ok=True
        for idx,cert in enumerate(certs):
            c=tuple(map(F,cert['center']));m=mass(c,F(1));bs=breaks(c);last=F(cert['r0_last'])
            j0_ok &= F(cert['m'])==m and 1<=m<=F(11,10) and last in bs and mass(c,last)==m and cert['r0_last_right_growth']==(last<2)
            if last<2:
                nxt=min(x for x in bs if x>last)
                j0_ok &= mass(c,(last+nxt)/2)>m
            available=mass(c,F(2))**8>2*m**8
            root_ok &= available==('r1_bracket' in cert)
            if available:
                root_count+=1;lo,hi=map(F,cert['r1_bracket']);a,b,d=map(F,cert['mass_polynomial']);mid=(lo+hi)/2
                root_ok &= 1<=lo<hi<=2 and hi-lo==F(1,2**48) and not any(lo<t<hi for t in bs)
                # Three exact values independently determine the polynomial on this face interval.
                left=max(t for t in bs if t<=lo);right=min(t for t in bs if t>=hi)
                root_ok &= all(a*t*t+b*t+d==mass(c,t) for t in (left,(left+right)/2,right))
                root_ok &= 2*a*lo+b>0 and 2*a*hi+b>0
                root_ok &= mass(c,lo)**8<2*m**8<mass(c,hi)**8
                root_ok &= F(cert['strict_hi_mass_power_residual'])==mass(c,hi)**8-2*m**8 and F(cert['strict_lo_mass_power_residual'])==2*m**8-mass(c,lo)**8
                root_ok &= F(float(mid))==mid and abs(F(float(mid)**2)-mid*mid)<=F(1,2**51)
            for law in run['laws']:
                g=law['g_proxy'][idx]
                j0_target=F(1) if law['law'] in ('old_g1','first_waterfill') else last*last
                proxy_ok &= abs(F(g[0])-j0_target)<=bound
                if law['law']=='old_g1':proxy_ok &= g[1]==0
                elif available:proxy_ok &= F(g[1])==F(float(mid)**2)
                else:proxy_ok &= g[1]==0
        check(f'{n} exact j0 last-hit certificates',j0_ok)
        check(f'{n} exact j1 polynomial/sign certificates',root_ok,'Monotone mass; rational plateau heights cannot equal irrational 2^(1/8)m. Positive affine derivative on bracket proves uniqueness there; no plateau at target globally.')
        check(f'{n} proxy scales and rounding bound',proxy_ok)
        check(f'{n} available phase count',root_count==run['available_j1']);counts.append(root_count)
        c=np.array(expected_centers,float);m=np.array([float(mass(x,F(1))) for x in expected_centers]);wt=float(F(run['weight_exact']));T=np.maximum(0,1-np.abs(np.log2(m[:,None])-np.log2(m[None,:])));K=inter(c,np.ones(n),np.ones(n))*T;e=wt*K.sum(axis=1)
        ledger_ok=close(run['Q0'],wt*e.sum()) and close(run['X'],wt*m.sum());maxdiff=0
        for law in run['laws']:
            p=np.array(law['p']);g=np.array(law['g_proxy']);g[g==0]=1;x=p/g
            ledger_ok &= p.shape==(n,2) and np.min(p)>=-1e-14 and np.max(p)<=1+1e-14 and np.max(abs(p.sum(axis=1)-1))<1e-14
            probability_defects.append({'nodes':n,'law':law['law'],'range_violation':float(max(0,-p.min(),p.max()-1)),'row_sum_defect':float(np.max(abs(p.sum(axis=1)-1)))})
            O=N=ON=B=P=D=0.
            for j in (0,1):
                z=x[:,j];r=np.sqrt(g[:,j]);H=inter(c,r,r)*T;U=inter(c,np.ones(n),r)*T
                O+=wt**2*(z@K@z);B+=wt**2*(z@H@z);ON+=wt**2*(z@(U-K)@z);N+=wt**2*(z@(H-U-U.T+K)@z);P+=wt*np.sum(e*z*z);D+=wt**2/2*np.sum(K*(z[:,None]-z[None,:])**2)
            shell=wt*np.sum(m*(2**(1/8)-1)*x[:,1]);cap=float(Cs)*shell
            vals={'Bpi':B,'O2':O,'twice_ON':2*ON,'N2':N,'P':P,'Dgraph':D,'Ddel':0,'shell_L1':shell,'shell_cap':cap,'shell_cap_slack':cap-N,'positive_majorant':2*P+2*cap,'graph_corrected_Young':2*O+2*cap,'Young_vector_slack':O-2*ON+N,'total_Young_slack':2*O+2*cap-B}
            ledger_ok &= all(close(v,law[k]) for k,v in vals.items())
            maxdiff=max(maxdiff,max(abs(v-law[k]) for k,v in vals.items()))
            ledger_ok &= close(P-D,O) and close(B,O+2*ON+N)
            ledger_ok &= all(abs(v)<1e-12 for v in law['residuals'].values())
        check(f'{n} binary64 archived-probability energy reconstruction',ledger_ok,'No optimizer and no integral certification.');energy_diffs.append(float(maxdiff))
    changes={a['law']:abs(b['Bpi']/a['Bpi']-1) for a,b in zip(data['runs'][0]['laws'],data['runs'][1]['laws'])}
    check('reported finite-grid comparisons and >10% stop',all(close(v,data['relative_primary_changes'][k]) for k,v in changes.items()) and changes['last_waterfill']>.1 and changes['global_old_gram_surrogate']>.1)
    check('report records corrected bound and unresolved scope','2^-47+2^-51' in report and 'UNRESOLVED' in report and 'continuous-center gains' in report)
    check('mother recorded constants',close(data['mother']['C'],float(C)) and close(data['mother']['A'],float(A)) and close(data['mother']['Cstar'],float(Cs)) and data['mother']['J_global']==18 and close(data['mother']['absorption_a_strict_upper'],F(25,18432)))
    result={'status':'PASS within stated scope' if not failures else 'FAIL','created_utc':datetime.now(timezone.utc).isoformat(),'command':[sys.executable,*sys.argv],'versions':{'python':platform.python_version(),'interpreter':sys.executable,'numpy':np.__version__,'python_flint':flint.__version__},'input_sha256':{k:hashlib.sha256(v).hexdigest() for k,v in raw.items()},'checks':checks,'failures':failures,'j1_counts':counts,'energy_max_absolute_differences':energy_diffs,'relative_primary_changes':changes,'probability_numerical_defects':probability_defects,'proxy_absolute_error_bound_exact':str(bound),'limitations':['No optimization rerun; no extra centers or grids.','Exact rational roots and Arb bulk bounds are certificates; reconstructed binary64 energy ledgers are numerical consistency checks only.','Archived waterfill probabilities have row-sum defects up to 4.45e-16, and 64-node last_waterfill has max probability 1+2^-52. Probability feasibility was checked with 1e-14 numerical tolerance, not certified exactly.','No certified continuous-center integral, optimality, gain, or general theorem.'],'seconds':time.perf_counter()-start}
    out=Path(args.out);out.with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n')
    lines=['# R571 independent archive verification',result['status'],'','Command: `'+ ' '.join([sys.executable,*sys.argv])+'`','UTC: '+result['created_utc'],'Versions: '+json.dumps(result['versions']),'',f'Passed {len(checks)-len(failures)}/{len(checks)} checks; j1 counts {counts}; binary64 ledger max differences {energy_diffs}.','',*['- '+c['name']+': '+('PASS' if c['passed'] else 'FAIL') for c in checks],'','For every center in E the unit cube contains the core, giving 1 <= m <= 11/10. Since (11/10)^7 < 2, every old log-window pair has overlap > 6/7. Thus e >= (49/64)(6/7); C < 12/5 and m <= 11/10 give alpha >= 1225/4928, and (89/20)(1225/4928) > 11/10 with Arb A > 89/20 yields the bulk guard. Because (11/10)^4 < 2, no j >= 2 target is reachable.','', 'The r1 midpoint is dyadic with denominator at most 2^49 and exactly binary64; |r-mid| <= 2^-49 and r+mid <= 4 give |r²-mid²| <= 2^-47. Adding safe binary64 square rounding <= 2^-51 proves proxy error <= 2^-47+2^-51. j0 proxies were compared directly to exact rational squares.','',*result['limitations']]
    out.with_suffix('.md').write_text('\n'.join(lines)+'\n');print(json.dumps({k:result[k] for k in ('status','failures','j1_counts','energy_max_absolute_differences','seconds')},indent=2))
    return bool(failures)
if __name__=='__main__':sys.exit(main())
