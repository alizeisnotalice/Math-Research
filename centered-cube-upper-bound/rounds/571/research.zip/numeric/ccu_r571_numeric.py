"""R571 single global-lambda arithmetic on a frozen physical endpoint branch.
No geometric integration or history gate is replaced by a numerical assumption.
"""
import os
for key in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:os.environ[key]='1'
import argparse,json,hashlib,platform,time,resource
from pathlib import Path
from fractions import Fraction
import sympy as s
import scipy
from scipy.optimize import minimize_scalar

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--output',default=str(Path(__file__).with_suffix('.json')));args=ap.parse_args();start=time.perf_counter()
 h=s.Rational(1,8);G=4;gamma=2;Lam=2+s.log(G);K=Lam*G*(1+s.log(G*gamma**(1+h)));Rcore=2*G*gamma**h*(1+s.log(gamma**(2+h)));Kf=float(K);Rf=min(Kf,float(Rcore));c=Kf/Rf
 def ratio(lam):return (1/(4*lam+c*(1-lam))+1/(lam+4*c*(1-lam)))/1.25
 def required(lam):
  r=ratio(lam)
  return (1-lam)/(1-lam*r) if lam<1 else float('nan')
 opt=minimize_scalar(ratio,bounds=(0,1),method='bounded',options={'xatol':1e-14})
 lr=Fraction(float(opt.x)).limit_denominator(4096);l=float(lr)
 V1=s.Rational(1,64);V2=s.Rational(1,256);Imin=s.Rational(3,2)+s.log(2);Imax=s.Rational(3,2)+s.log(4)
 # rho_G=1/(2I); full un-gated nu integrates to total original center volume.
 # Entire chi<=1 fee/K <= 2(V1+V2), since each old z average inverse Li=1/Vb.
 full_upper=2*(V1+V2);endpoint_lower=320*V1*V2*s.Rational(5,8)/(4*Imax**2)
 pressure=[]
 for xx in [2,4,16,256]:
  for ww in [.1,.25,.5,.75,.9]:
   def rr(ll):return (ww/(xx*ll+c*(1-ll))+(1-ww)/(ll+xx*c*(1-ll)))/(ww/xx+1-ww)
   oo=minimize_scalar(rr,bounds=(0,1),method='bounded',options={'xatol':1e-13})
   def ff(ll):return (1-ll)/(1-ll*rr(ll)) if rr(ll)<1/ll else 1e6
   fo=minimize_scalar(ff,bounds=(1e-8,1-1e-7),method='bounded')
   pressure.append({'field_ratio':xx,'forward_raw_direction_weight':ww,'lambda_endpoint_opt_float':float(oo.x),'endpoint_ratio_float':float(oo.fun),'required_share_at_endpoint_opt':ff(oo.x),'lambda_min_required_share_float':float(fo.x),'minimum_required_share_float':float(fo.fun),'required_share_lambda1_limit':1/(1+(-ww*(xx-c)/xx**2+(1-ww)*(xx*c-1))/(ww/xx+1-ww))})
 input_metadata={'n':2,'G':4,'gamma':2,'hwin':'1/8','V1':'1/64','V2':'1/256','delta':'1/1024','pressure_ratios':[2,4,16,256],'pressure_direction_weights':[.1,.25,.5,.75,.9]}
 data={'schema':'R571.global_lambda.scalar.1','scope':'Formula-only continuous-model endpoint decision; conditional on independent true-gate audit. No full-history or all-action geometric evaluation.','input':{'n':2,'G':4,'gamma':2,'hwin':'1/8','S':1,'rband':1,'V1':'1/64','V2':'1/256','source':'two correlated square blobs delta=1/1024, each mass1/2','model_design':'ccu_r571_shape.md','all_other_actions':'retained as unpaid complement, bounded by original_fee/lambda'},'constants':{'Lambda_exact':str(Lam),'K_exact':str(K),'reverse_core_exact':str(Rcore),'R_rule':'min(K,reverse_core)','K_display':Kf,'R_display':Rf,'K_over_R_display':c},'endpoint_formula':{'ratio':'[1/(4lambda+c(1-lambda))+1/(lambda+4c(1-lambda))]/(5/4)','absolute_old':'K*320*J1*J2*mu(H)','Jb':'integral_Eb dB/(2I_B), complete continuous rho and both atoms retained','muH':'strictly >5/8, <=1; gate audit pending','I_exact':'3/2+integral_1^2 dr/[r M_B(r^2)]','I_bounds_exact':[str(Imin),str(Imax)],'ellC':'C0 alphaC=V_C; not inverse oldfield evaluated outside old C support'},'global_endpoint_optimum_float':{'lambda':float(opt.x),'endpoint_ratio':ratio(opt.x),'required_endpoint_fee_share':required(opt.x),'solver':'scipy minimize_scalar bounded, floating diagnostic'},'rational_candidate':{'lambda':str(lr),'lambda_display':l,'endpoint_ratio':ratio(l),'required_endpoint_fee_share':required(l),'complement_inflation':1/l},'samples':[{'lambda':v,'endpoint_ratio':ratio(v),'required_share':required(v) if v<1 else None} for v in [0,.25,.5,.75,.99,1]],'full_fee_test':{'inequality':'Vlambda/VG <= f*r(lambda)+(1-f)/lambda','sufficient_condition':'f>(1-lambda)/(1-lambda*r(lambda)), lambda<1','actual_model_required_share_infimum_lambda1':1/(1+(-.5*(4-c)/16+.5*(4*c-1))/.625),'infimum_reason':'Endpoint ratio r is convex with r(1)=1; positive secant (1-r)/(1-lambda) increases towards rprime(1), hence the sufficient share decreases to 1/(1+rprime(1)). Infimum is approached with vanishing gain as lambda tends1.','endpoint_lower_over_K_exact':str(endpoint_lower),'full_upper_over_K_exact':str(full_upper),'certified_algebraic_endpoint_share_lower_exact':str(s.simplify(endpoint_lower/full_upper)),'endpoint_share_lower_display':float(endpoint_lower/full_upper),'actual_endpoint_share':'not computed: full nonendpoint chi gates/core/history not frozen for evaluation','decision':'Endpoint convex improvement alone does not establish full improvement. The explicit guaranteed share lower bound does not meet the required share; this is failure of this sufficient accounting test, not proof that the actual model or global bridge cannot improve.'},'sensitivity_pressure':{'scope':'Formal scalar parameters only; no new physical/history input or geometric integrals, no claimed realized asymmetric directional weights','rows':pressure},'input_metadata_sha256':hashlib.sha256(json.dumps(input_metadata,sort_keys=True).encode()).hexdigest(),'output_error_status':'floating scalar optimizer successful; no Arb enclosure claimed; complete full-fee share unknown','cost':{'seconds':time.perf_counter()-start,'maxrss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'processes':1,'LP_calls':0,'geometric_integrals':0},'versions':{'python':platform.python_version(),'sympy':s.__version__,'scipy':scipy.__version__},'code_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
 Path(args.output).write_text(json.dumps(data,indent=2)+'\n');print(json.dumps({'constants':data['constants'],'optimum':data['global_endpoint_optimum_float'],'rational':data['rational_candidate'],'guaranteed_share_lower':float(endpoint_lower/full_upper),'cost':data['cost']},indent=2))
if __name__=='__main__':main()
