#!/usr/bin/env python3
"""R571 final independent scalar and new-mother certificate.
No original author code imported, no optimizer/quadrature/MATLAB run.
"""
from fractions import Fraction as F
from pathlib import Path
import argparse,hashlib,json,platform,resource,sys,time
import sympy as s
import flint
from flint import arb,ctx

def B(f):
    f=F(f);return arb(f.numerator)/f.denominator

def dec(f,up=False):
    p=10**24;n=f.numerator*p//f.denominator
    if up and F(n,p)<f:n+=1
    return ('-' if n<0 else '')+str(abs(n)//p)+'.'+str(abs(n)%p).zfill(24)

def iv(x):
    lo,hi=x.lower(),x.upper();assert lo.is_exact() and hi.is_exact()
    l,h=F(str(lo.fmpq())),F(str(hi.fmpq()))
    dl,dh=dec(l),dec(h,True);assert F(dl)<=l<=h<=F(dh)
    return {'lower_exact':str(l),'upper_exact':str(h),'lower_decimal':dl,'upper_decimal':dh}

def amin(x,y):
    assert x<y or y<x
    return x if x<y else y

def amax(x,y):
    assert x<y or y<x
    return x if x>y else y

def main():
    start=time.perf_counter();ctx.prec=192;ctx.threads=1
    x,c,ell,k=s.symbols('x c ell k',positive=True)
    d,H,a,L,C,q=s.symbols('d H a L C q',positive=True)
    Delta=d*d-H*a
    rad=H*a*C*C+d*C*H*L+H*H*L*L/4
    R=(d*C+H*L/2+s.sqrt(rad))/Delta
    t,u,v,h=s.symbols('t u v h',nonnegative=True)
    H1=1+(1+h)*u+v;Hph=1+(2+h)*u+v
    checks={
      'alpha_high_derivative':s.cancel(s.diff(x/(x+ell)**2,x)-(ell-x)/(x+ell)**3),
      'alpha_high_peak_gap':s.cancel(1/(4*ell)-x/(x+ell)**2-(x-ell)**2/(4*ell*(x+ell)**2)),
      'Hph_K_ratio_half_guard':s.expand((2+t)*(H1+t)-Hph-(t*t+(H1+2)*t+1+h*u+v)),
      'mother_squared_polynomial':s.expand((d*q-C)**2-H*q*(a*q+L)-(Delta*q*q-(2*d*C+H*L)*q+C*C)),
      'mother_discriminant':s.expand((2*d*C+H*L)**2-4*Delta*C*C-4*rad),
      'upper_root_polynomial':s.simplify(Delta*R**2-(2*d*C+H*L)*R+C*C),
      'upper_root_above_C_over_d':s.simplify(R-C/d-(H*a*C/d+H*L/2+s.sqrt(rad))/Delta),
      'Young_bound_residual':s.expand((2*d*C+H*L)**2/4-rad-Delta*C*C),
      'zero_a_root':s.simplify(R.subs(a,0)-(d*C+H*L/2+s.sqrt(d*C*H*L+H*H*L*L/4))/d**2),
    }
    assert all(z==0 for z in checks.values())
    cases=[('same_phase_small_An','4','2','1/8','1','16'),
           ('same_phase_larger_An','4','2','1/8','1','32'),
           ('frozen_static_cutoff','4','2','1/8','1','1+2050ln2'),
           ('K_cap_changes_winner','3/2','256','1/4','1','29/10')]
    rows=[]
    for name,gs,gams,hs,rs,ns in cases:
        G,gamma,hh,r=map(B,(gs,gams,hs,rs))
        lnG,lng,lnr=G.log(),gamma.log(),r.log()
        N=1+2050*arb(2).log() if ns=='1+2050ln2' else B(ns)
        ellb=1+lnG;cc=(hh*lng).exp();C0=1+lng+lnr
        hp=1+(2+hh)*lng+lnr;A=2*G*hp
        K=(2+lnG)*G*(1+lnG+(1+hh)*lng+lnr)
        RA=amin(K,A);kb=K/A;m=amin(kb**2,arb(1))
        D=1+(N-1+lnr)/lng
        b0=cc**2/(cc+ellb)**2;bpeak=1/(4*ellb);beta=amax(b0,bpeak)
        beta_new=m*beta
        beta_old=amax(amin(kb**2,b0),bpeak)
        # Avoid ambiguous equality comparison when K is inactive: algebra supplies equality.
        if K<A: assert beta_new<beta_old
        else: assert (beta_new-beta_old).contains(0)
        clock=RA**2*D;alpha=RA**2*N*N/C0*beta
        assert N>ellb>=1 and cc>1 and kb>B('1/2')
        final=amin(clock,alpha)
        rows.append({'label':name,'parameters':dict(G=gs,gamma=gams,h=hs,rband=rs,An=ns,S='1'),
          'active_RA':'K' if K<A else 'A_Hph','winning_source_branch':'clock' if clock<alpha else 'alpha',
          'sharp_scalar_sup_normalized_by_A_squared':'min(k^2,1)*max(c^2/(c+ell)^2,1/(4ell))',
          'old_nested_max_status':'strictly weaker upper bound' if K<A else 'equal here, K inactive',
          'intervals':{key:iv(val) for key,val in {'A_Hph':A,'K':K,'RA':RA,'D':D,'beta':beta,'sharp_beta_with_K_over_A':beta_new,'old_nested_max':beta_old,'clock_coefficient':clock,'alpha_coefficient':alpha,'alpha_minus_clock':alpha-clock,'final_coefficient':final}.items()}})
    assert [r['winning_source_branch'] for r in rows]==['alpha','clock','clock','alpha']
    # One consistent NEW local-entry instance, separate from the four original action cases.
    # n=2,G=4,gamma=2,h=1/8,rband=2,eta=1/2.
    anlocal=1+2*arb(2).log()+arb(8).log()
    phase_arg=8*anlocal.log()/arb(2).log()
    assert phase_arg>17 and phase_arg<18
    J=18;Gq=F(4);dq=F(5,8);Hq=Gq*Gq*J
    critical=dq*dq/Hq;oldcrit=dq**4/(4*J*J)
    assert critical==F(25,18432) and critical/oldcrit==F(288,25)
    Cb=5*(1+arb(4).log());Lb=arb(1);db=B(dq);Hb=B(Hq)
    absrows=[]
    for factor in [F(0),F(1,2),F(99,100),F(1),F(101,100)]:
        aq=factor*critical;delta=dq*dq-Hq*aq
        row={'fraction_of_critical':str(factor),'a_exact':str(aq),'Delta_exact':str(delta),
             'absorbs':delta>0,'old_threshold_would_absorb':aq<oldcrit}
        if delta>0:
            rr=(db*Cb+Hb*Lb/2+(Hb*B(aq)*Cb**2+db*Cb*Hb*Lb+Hb**2*Lb**2/4).sqrt())/B(delta)
            young=(2*db*Cb+Hb*Lb)/B(delta)
            assert rr>Cb/db and rr<young
            resid=db*rr-Cb-(Hb*rr*(B(aq)*rr+Lb)).sqrt()
            assert resid.contains(0)
            row.update(root_F=iv(rr),Young_upper=iv(young),root_equation_residual=iv(resid),
                       weak_local_multiplier_eta_half_D4=iv(8*rr.sqrt()))
        else:
            assert Hq*aq>=dq*dq
            row['conclusion']='No finite upper bound follows: sqrt(H*q*(a*q+L))>=d*q for every q>=0.'
        absrows.append(row)
    return {'status':'PASS: audited Hph/K-over-I update and new local-mother absorption formula',
      'action_input':'r_C<=min(K,A_Hph)/I_C, A_Hph=2GS[1+ln(gamma^(2+h)rband)]',
      'sharpness':'N>=ell=1+lnG from nonempty original radius range; supremum is scalar only, not geometric saturation.',
      'final_action_coefficient':'min(K,A_Hph)^2*min(D, S*An^2/C0*max(gamma^(2h)/(gamma^h+Lambda-1)^2,1/(4(Lambda-1))))',
      'old_nested_max':'Sharp only under weaker min(K,A/I) input; with new min(K,A)/I it is generally a nonsharp upper bound.',
      'mother_assumptions':'W>0,d>0,H>0,c>=0,a>=0,L>=0; same new Bpi<=aQ0+LW. Vcap payment alone is not a Bpi payment.',
      'mother_formula':'q<=[d*c+H*L/2+sqrt(H*a*c^2+d*c*H*L+H^2*L^2/4)]/(d^2-H*a)',
      'absorption_condition':'a<d^2/H, H=G^2J; critical or supercritical inequality imposes no finite upper bound.',
      'symbolic_zero_residuals':{name:str(z) for name,z in checks.items()},
      'action_rows':rows,
      'local_entry_critical_case':{'n':2,'G':'4','gamma':'2','h':'1/8','rband':'2','eta':'1/2','An_local':'1+5ln2','J':J,'phase_floor_argument':iv(phase_arg),'D':'4','d':str(dq),'H':str(Hq),'c':'5(1+ln4)','L_budget':'1','critical_a':str(critical),'critical_a_interval':iv(B(critical)),'old_d4_over_4J2':str(oldcrit),'new_over_old_threshold':str(critical/oldcrit),'rows':absrows},
      'scope':'Finite cases check implementation and strict comparisons only; general formulas follow from exact algebra and stated parameter inequalities. No full geometric Bpi budget or dimension theorem is claimed.',
      'versions':{'python':platform.python_version(),'interpreter':sys.executable,'sympy':s.__version__,'python_flint':flint.__version__},
      'error_policy':'All inputs exact rational or exact log/exp expressions; Arb192 outward dyadic endpoints; decimal floor/ceil24. Root residual containing zero is a numerical consistency check, symbolic polynomial identity is exact.',
      'cost':{'seconds':time.perf_counter()-start,'maxrss_bytes_macos':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'processes':1,'Arb_bits':192,'action_cases':4,'absorption_cases':5,'optimizers':0,'quadratures':0,'MATLAB_runs':0},
      'code_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=Path(__file__).with_suffix('.json'));args=ap.parse_args()
    data=main();args.output.write_text(json.dumps(data,indent=2)+'\n')
    print(json.dumps({'status':data['status'],'action_rows':[{'name':r['label'],'active':r['active_RA'],'winner':r['winning_source_branch'],'final_interval':[r['intervals']['final_coefficient']['lower_decimal'],r['intervals']['final_coefficient']['upper_decimal']]} for r in data['action_rows']],'critical_case':{k:v for k,v in data['local_entry_critical_case'].items() if k not in ['rows','phase_floor_argument']},'absorption_rows':[{'a':r['a_exact'],'Delta':r['Delta_exact'],'absorbs':r['absorbs'],'old_absorbs':r['old_threshold_would_absorb'],'F':r.get('root_F')} for r in data['local_entry_critical_case']['rows']],'cost':data['cost'],'versions':data['versions']},indent=2))
