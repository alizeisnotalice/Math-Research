# R571 independent archive verification
PASS within stated scope

Command: `/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python ccu_r571_archive_verify.py --data ccu_r571_sol_joint_numeric.json --source ccu_r571_sol_joint_numeric.py --report ccu_r571_sol_joint_numeric.md --out ccu_r571_archive_verify`
UTC: 2026-10-24T00:09:29.837807+00:00
Versions: {"python": "3.12.14", "interpreter": "/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python", "numpy": "2.5.4", "python_flint": "0.9.0"}

Passed 24/24 checks; j1 counts [22, 49]; binary64 ledger max differences [5.551115123125783e-17, 3.469446951953614e-18].

- source SHA256 matches saved executed-code hash: PASS
- frozen 2D three-box input: PASS
- exact core/satellite masses: PASS
- all-E core containment: PASS
- exact log window and phase guards: PASS
- Arb160 bulk bounds: PASS
- bulk alpha and Aalpha exact residual: PASS
- corrected stored proxy bound: PASS
- prescribed archive grids and stop: PASS
- 64 centers and exact weight: PASS
- 64 exact j0 last-hit certificates: PASS
- 64 exact j1 polynomial/sign certificates: PASS
- 64 proxy scales and rounding bound: PASS
- 64 available phase count: PASS
- 64 binary64 archived-probability energy reconstruction: PASS
- 144 centers and exact weight: PASS
- 144 exact j0 last-hit certificates: PASS
- 144 exact j1 polynomial/sign certificates: PASS
- 144 proxy scales and rounding bound: PASS
- 144 available phase count: PASS
- 144 binary64 archived-probability energy reconstruction: PASS
- reported finite-grid comparisons and >10% stop: PASS
- report records corrected bound and unresolved scope: PASS
- mother recorded constants: PASS

For every center in E the unit cube contains the core, giving 1 <= m <= 11/10. Since (11/10)^7 < 2, every old log-window pair has overlap > 6/7. Thus e >= (49/64)(6/7); C < 12/5 and m <= 11/10 give alpha >= 1225/4928, and (89/20)(1225/4928) > 11/10 with Arb A > 89/20 yields the bulk guard. Because (11/10)^4 < 2, no j >= 2 target is reachable.

The r1 midpoint is dyadic with denominator at most 2^49 and exactly binary64; |r-mid| <= 2^-49 and r+mid <= 4 give |r²-mid²| <= 2^-47. Adding safe binary64 square rounding <= 2^-51 proves proxy error <= 2^-47+2^-51. j0 proxies were compared directly to exact rational squares.

No optimization rerun; no extra centers or grids.
Exact rational roots and Arb bulk bounds are certificates; reconstructed binary64 energy ledgers are numerical consistency checks only.
Archived waterfill probabilities have row-sum defects up to 4.45e-16, and 64-node last_waterfill has max probability 1+2^-52. Probability feasibility was checked with 1e-14 numerical tolerance, not certified exactly.
No certified continuous-center integral, optimality, gain, or general theorem.
