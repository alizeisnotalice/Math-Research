import sympy as s,json
from pathlib import Path
G,An,ga,h,r,S=s.symbols('G An ga h r S',positive=True)
d=s.symbols('d',integer=True,nonnegative=True)
F=ga**(2+h)*r*r
eps=1/(2*G*An*F*(d+1)*(d+2))
psum=s.summation(eps,(d,0,s.oo))
fee=s.simplify(2*G*F*S*S*An*psum)
p=112*G*G; hn=1/(448*G*G); J=s.Integer(5)
checks={
 'new_companion_p_h':str(s.Integer(112)*s.Rational(1,448)),
 'new_companion_J':str(1+s.floor(s.Rational(1,112)/s.Rational(1,448))),
 'new_companion_edge_Ja':str(28*5*s.Rational(1,448)),
 'new_companion_epsilon_power_An':str(1+112*(2+s.Rational(1,448))),
 'sum_epsilon_prime':str(psum),
 'each_wide_exc_fee_coefficient':str(fee),
 'each_fee_minus_S2':str(s.simplify(fee-S*S)),
 'p_times_h':str(s.simplify(p*hn)),
 'loggamma_An_over_h':str(s.simplify((1/p)/hn)),
 'old_Kw_power_An':str(s.simplify(p*(2+hn))),
 'epsilon_inverse_power_An':str(s.simplify(1+p*(2+hn))),
 'energy_edge_credit_a':str(s.simplify(28*hn)),
 'mother_Ha':str(s.simplify(G*G*J*28*hn)),
 'uniform_margin_at_G1':str((1-s.Rational(3,448))**2-s.Rational(5,16)),
}
Path('/tmp/ccu_r571_gamma_budget_audit.json').write_text(json.dumps(checks,indent=2))
print(json.dumps(checks,indent=2))
