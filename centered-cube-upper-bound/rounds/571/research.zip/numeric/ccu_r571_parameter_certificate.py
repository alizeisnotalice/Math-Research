#!/usr/bin/env python3
"""R571 explicit parameter compatibility certificate, not a V_new proof.
One bounded run: three exact candidate pairs and one Arb n=2 implementation case.
"""
from fractions import Fraction as F
from pathlib import Path
import argparse,hashlib,json,platform,resource,sys,time
import sympy as s
import flint
from flint import arb,ctx

def B(x):
    x=F(x);return arb(x.numerator)/x.denominator

def ceilF(x):return -((-x.numerator)//x.denominator)
def decimal(x,up=False):
    P=10**24;k=x.numerator*P//x.denominator
    if up and F(k,P)<x:k+=1
    return ('-' if k<0 else '')+str(abs(k)//P)+'.'+str(abs(k)%P).zfill(24)
def iv(x):
    lo,hi=x.lower(),x.upper();assert lo.is_exact() and hi.is_exact()
    l,h=F(str(lo.fmpq())),F(str(hi.fmpq()))
    dl,dh=decimal(l),decimal(h,True);assert F(dl)<=l<=h<=F(dh)
    return {'lower_exact':str(l),'upper_exact':str(h),'lower_decimal':dl,'upper_decimal':dh}
def ceilArb(x):
    lo,hi=ceilF(F(str(x.lower().fmpq()))),ceilF(F(str(x.upper().fmpq())))
    assert lo==hi
    return lo

def main():
    start=time.perf_counter();ctx.prec=192;ctx.threads=1
    p,q,N,G,r,S,z=s.symbols('p q N G r S z',positive=True)
    hh=1/(p*q)
    checks={
      'gamma_h_exponent':s.cancel(p*hh-1/q),
      'phase_ratio':s.cancel((1/p)/hh-q),
      'epsilon_power':s.cancel(1+p*(2+hh)-(1+2*p+1/q)),
      'K_log_coefficient':s.cancel(p*(1+hh)-(p+1/q)),
      'Aact_log_coefficient':s.cancel(p*(2+hh)-(2*p+1/q)),
      'sqrt_Ch':s.cancel((20/(3-hh))**2-400/(3-hh)**2),
      'absorption_left':s.cancel(2*hh*(q+1)*20/(3-hh)-40*(q+1)/(3*p*q-1)),
      'absorption_numerator':s.expand((p*q-3)**2*(3*p*q-1)-40*p*p*q*q*(q+1)-(p*p*q*q*(3*p-40)*q-p*q*q*(19*p+40*p)+33*p*q-9)),
      'wide_budget_cancellation':s.cancel((2*G*N*s.Symbol('Gamma',positive=True)*r*r*S*S)/(2*G*N*s.Symbol('Gamma',positive=True)*r*r)-S*S),
      'depth_telescope':s.cancel(1/(z+1)-1/(z+2)-1/((z+1)*(z+2))),
    }
    # The expanded polynomial check above is only a convenience; check against direct expansion.
    assert all(v==0 for v in checks.values())
    candidates=[]
    for pp,qq in [(16,4),(16,8),(16,16)]:
        h=F(1,pp*qq);J=qq+1;d=1-3*h
        sqrtC=20/(3-h);Ch=sqrtC*sqrtC
        lhs=2*h*J*sqrtC;rhs=d*d
        margin=rhs-lhs
        ratio=(lhs/rhs)**2
        candidates.append({'p':str(pp),'q':str(qq),'h':str(h),'J':J,'d':str(d),
          'C_h':str(Ch),'sqrt_C_h':str(sqrtC),'left_exact':str(lhs),'right_exact':str(rhs),
          'margin_exact':str(margin),'absorbs':margin>0,
          'mother_absorption_ratio_exact':str(ratio),'relative_slack_exact':str(1-ratio),
          'margin_Arb192':iv(B(margin))})
    assert [x['absorbs'] for x in candidates]==[False,True,True]
    pp,qq=16,16;h=F(1,256);J=17;d=F(253,256)
    assert 2*h*J*20/(3-h)==F(680,767)
    assert d*d-2*h*J*20/(3-h)==F(4530423,50266112)
    # G=4, r=2, S=1, n>=2. The one evaluated dimension is an implementation check only.
    n=2;g=arb(4);rb=arb(2);ln2=arb(2).log();N0=1+(n+3)*ln2;lnN=N0.log();lng=pp*lnN
    gammh=(lnN/qq).exp()
    C0=1+ln2+lng
    Fcap=4*(1+arb(8).log()+B(F(257,16))*lnN)
    K=(2+arb(4).log())*Fcap
    Aact=8*(1+ln2+B(F(513,16))*lnN)
    RA=K if K<Aact else Aact
    Dlocal=1+(n+1)*ln2/lng
    Dcut=1+(N0-1+ln2)/lng
    eps_exponent=F(529,16)
    # Depth zero: (j+1)(j+2)=2. Use log epsilon to avoid giant exact powers.
    logepsinv=arb(64).log()+B(eps_exponent)*lnN
    eps0=(-logepsinv).exp()
    kdarg=(arb(3).log()+logepsinv)/B(F(9,8)).log()
    k0=max(2,ceilArb(kdarg))
    mdarg=(logepsinv+arb(64).log())/ln2 # delta_head=1/8
    m0=min(n,ceilArb(mdarg))
    Lcore0=arb(2).log()+logepsinv+k0*B(F(4,3)).log()
    assert N0>1 and gammh<N0 and K>0 and Aact>0 and Dlocal<Dcut
    # No floating floor at the integer q boundary: J=q+1 is proved exactly above.
    phase_ratio=lng/pp/lng/B(h)
    assert phase_ratio.contains(16)
    sample={'n':n,'G':'4','rband':'2','S':'1','An_exact':'1+5ln2','J_exact':17,
      'J_method':'exact log_gamma(An)/h=q=16; Arb floor is intentionally not used',
      'k_depth0':k0,'m_depth0':m0,
      'intervals':{key:iv(v) for key,v in {'An':N0,'log_gamma':lng,'gamma_to_h':gammh,'C0':C0,'Fcap':Fcap,'K':K,'Aact':Aact,'RA':RA,'D_local_old_window':Dlocal,'D_full_cutoff':Dcut,'epsilon_depth0':eps0,'log_inverse_epsilon_depth0':logepsinv,'k_argument_depth0':kdarg,'m_argument_depth0':mdarg,'core_L_depth0':Lcore0}.items()}}
    return {'status':'PASS: explicit uniform-in-n parameter compatibility; V_new geometric payment remains open',
      'chosen_parameters':{'p':'16','q':'16','gamma':'An^16','h':'1/256','G':'4','rband':'2','S':'1','J':'17','d':'253/256'},
      'analytic_candidates':candidates,'symbolic_zero_residuals':{k:str(v) for k,v in checks.items()},
      'threshold_redefinition':'epsilon_j=[2G An gamma^(2+h) rband^2 (j+1)(j+2)]^(-1)',
      'exact_redefined_epsilon_chosen':'[32 An^(529/16)(j+1)(j+2)]^(-1)',
      'general_orders_for_all_n_ge_2':{'An':'Theta(n), An=1+(n+3)ln2','gamma':'Theta(n^16)','gamma_h':'An^(1/16), not carried as an outside cap factor','C0':'Theta(log(n+2))','Fcap':'Theta(log(n+2))','K':'Theta(log(n+2))','Aact':'Theta(log(n+2)), final Hph cap only','RA':'Theta(log(n+2))','D_local_and_D_cutoff':'Theta(n/log(n+2))','J':'17 exactly','wide_and_exception_each':'<=S^2 W, conditional on the independently audited threshold transfer','k_j':'Theta(log(n+2)+log(j+2))','m_j':'O(min(n,log(n+2)+log(j+2)))','core_L_j':'Theta(log(n+2)+log(j+2))','rstar_over_old_side':'bounded by an absolute constant for n>=2 with these fixed p,q,G,r','generic_complete_row_source_bound':'RA^2 D=Theta(n log(n+2)); remains too large to stand in for a polylog V_new bound'},
      'not_claimed':['A geometric bound for V_new','general theorem inferred from sample n=2','inheritance of an unaudited threshold/gate proof','a cutoff-independent closed weak estimate'],
      'sample_implementation_check':sample,
      'versions':{'python':platform.python_version(),'interpreter':sys.executable,'sympy':s.__version__,'python_flint':flint.__version__},
      'error_policy':'Exact Fraction/SymPy candidate decisions; Arb192 outward dyadics and floor/ceil24 decimals; general orders proved analytically, never fitted; exact integer J not computed by approximate floor.',
      'cost':{'seconds':time.perf_counter()-start,'maxrss_bytes_macos':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'processes':1,'Arb_bits':192,'candidate_pairs':3,'dimension_checks':1,'optimizers':0,'quadratures':0,'MATLAB_runs':0},
      'code_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=Path(__file__).with_suffix('.json'));args=ap.parse_args()
    data=main();args.output.write_text(json.dumps(data,indent=2)+'\n')
    print(json.dumps({'status':data['status'],'candidates':data['analytic_candidates'],'sample':{k:v for k,v in data['sample_implementation_check'].items() if k!='intervals'},'sample_intervals':{k:[v['lower_decimal'],v['upper_decimal']] for k,v in data['sample_implementation_check']['intervals'].items() if k in ['C0','K','Aact','D_local_old_window','D_full_cutoff','core_L_depth0']},'cost':data['cost'],'versions':data['versions']},indent=2))
