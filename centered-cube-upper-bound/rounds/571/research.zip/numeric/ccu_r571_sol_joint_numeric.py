from fractions import Fraction as F
import os
os.environ['OPENBLAS_NUM_THREADS']='1'
os.environ['OMP_NUM_THREADS']='1'
import numpy as np
import scipy, scipy.optimize as opt
import flint
from flint import arb,ctx
import json,time,resource,platform,sys,hashlib,signal
from pathlib import Path
start=time.perf_counter()
signal.signal(signal.SIGALRM,lambda *args: (_ for _ in ()).throw(TimeoutError('30 second budget')))
signal.alarm(30)
ctx.prec=160
boxes=[([F(-1,32)]*2,[F(1,32)]*2,F(256)),
       ([F(11,16),F(3,16)],[F(13,16),F(5,16)],F(16,5)),
       ([F(-9,16),F(-13,16)],[F(-7,16),F(-11,16)],F(16,5))]
def mass(c,r):
    return sum((den*np_product([max(F(0),min(hi[k],c[k]+r/2)-max(lo[k],c[k]-r/2)) for k in range(2)]) for lo,hi,den in boxes),F(0))
def np_product(a):return a[0]*a[1]
def fracarb(z):return arb(z.numerator)/z.denominator
def iv(a):return [str(a.lower().fmpq()),str(a.upper().fmpq())]
def breakpoint(c):
    return sorted({F(1),F(2)}|{2*abs(v-c[k]) for lo,hi,_ in boxes for k in range(2) for v in [lo[k],hi[k]] if 1<2*abs(v-c[k])<2})
def slots(c):
    m=mass(c,F(1));bs=breakpoint(c);last=F(1)
    for r in bs[1:]:
        if mass(c,r)==m:last=r
        else:break
    # A plateau's last point is certified by a nonconstant polynomial immediately to its right.
    if last<2:
        nxt=next(r for r in bs if r>last)
        assert mass(c,(last+nxt)/2)>m
    else:assert mass(c,last)==m
    cert={'center':list(map(str,c)),'m':str(m),'r0_last':str(last),'r0_last_right_growth':last<2}
    if mass(c,F(2))**8<2*m**8:return [float(last)**2,0.0],cert
    assert mass(c,F(2))**8>2*m**8 # equality impossible for positive rational m
    lo=F(1);hi=F(2)
    # Rational sign isolation also excludes an unobserved terminal plateau.
    for _ in range(48):
        mid=(lo+hi)/2
        if mass(c,mid)**8<=2*m**8:lo=mid
        else:hi=mid
    assert mass(c,lo)**8<2*m**8<mass(c,hi)**8
    left=max(r for r in bs if r<=lo);right=min(r for r in bs if r>=hi)
    # Exact quadratic interpolation on the containing face interval.
    u=left;v=(left+right)/2;w=right
    fu,fv,fw=[mass(c,r) for r in (u,v,w)]
    a=((fw-fv)/(w-v)-(fv-fu)/(v-u))/(w-u)
    b=(fv-fu)/(v-u)-a*(u+v);d=fu-a*u*u-b*u
    assert a*lo*lo+b*lo+d==mass(c,lo)
    assert 2*a*lo+b>0 and 2*a*hi+b>0
    cert.update({'j1_root':'unique r in bracket satisfying (a*r^2+b*r+c)^8=2*m^8; g=r^2; phase exactly 1',
      'r1_bracket':[str(lo),str(hi)],'mass_polynomial':[str(a),str(b),str(d)],
      'strict_hi_mass_power_residual':str(mass(c,hi)**8-2*m**8),
      'strict_lo_mass_power_residual':str(2*m**8-mass(c,lo)**8)})
    return [float(last)**2,float((lo+hi)/2)**2],cert
def intersect_mass(c,r,d,s):
    low=np.maximum(c[:,None,:]-r[:,None,None]/2,d[None,:,:]-s[None,:,None]/2)
    high=np.minimum(c[:,None,:]+r[:,None,None]/2,d[None,:,:]+s[None,:,None]/2)
    z=np.zeros((len(c),len(d)))
    for lo,hi,den in boxes:
        z+=float(den)*np.prod(np.maximum(0,np.minimum(high,np.array(hi,float))-np.maximum(low,np.array(lo,float))),axis=2)
    return z
C=1+np.log(4);A=1+5*np.log(2);Cs=1+(33/8)*np.log(2);gamma1=2**(1/8)
# Exact analytic bulk and phase guards, independently checked here.
assert F(11,10)**7<2
assert fracarb(F(2)).log()>fracarb(F(69,100))
assert 1+5*fracarb(F(2)).log()>fracarb(F(89,20))
assert 1+fracarb(F(4)).log()<fracarb(F(12,5))
assert F(89,20)*F(1225,4928)>F(11,10)
assert F(11,10)**4<2 # kappa<=1.1<2^(1/4), hence only j=0,1.
assert 2*4*np.sqrt(2)/(np.sqrt(2)/4)==32
allruns=[]
for size in [8,12]:
    cs=[(F(-7,16)+(F(2*i+1,2*size))*F(7,8),F(-7,16)+F(2*j+1,2*size)*F(7,8)) for i in range(size) for j in range(size)]
    centers=np.array(cs,float);n=len(cs);wt=float(F(49,64)/n)
    oldm=np.array([float(mass(c,F(1))) for c in cs]);s=np.log2(oldm)
    T=np.maximum(0,1-abs(s[:,None]-s[None,:]))
    K=intersect_mass(centers,np.ones(n),centers,np.ones(n))*T
    e=wt*K.sum(axis=1);alpha=e/(C*oldm);Q0=wt*e.sum()
    assert np.min(alpha)>1/A and np.all(1.1/oldm<A*alpha)
    rootdata=[slots(c) for c in cs];glast=np.array([r[0] for r in rootdata]);cert=[r[1] for r in rootdata]
    avail=glast[:,1]>0;gfirst=glast.copy();gfirst[:,0]=1
    def water(g):
        shell=oldm[:,None]*np.array([0,gamma1-1]);cc=2*e
        def x(z):return np.maximum(0,z[:,None]*g-2*Cs*shell)/(2*cc[:,None])
        lo=np.zeros(n);hi=np.ones(n)*100
        for _ in range(65):
            mid=(lo+hi)/2;val=np.sum(g*x(mid),axis=1)
            lo=np.where(val<1,mid,lo);hi=np.where(val>=1,mid,hi)
        xx=x((lo+hi)/2);return xx*g
    pf=water(gfirst);pl=water(glast)
    safe=glast.copy();safe[~avail,1]=1
    def objective(y):
        x0=(1-y)/safe[:,0];x1=y/safe[:,1]
        val=2*wt**2*(x0@K@x0+x1@K@x1)+2*Cs*wt*np.sum(oldm*(gamma1-1)*x1)
        grad=4*wt**2*(-(K@x0)/safe[:,0]+(K@x1)/safe[:,1])+2*Cs*wt*oldm*(gamma1-1)/safe[:,1]
        return val,grad
    result=opt.minimize(objective,pl[:,1],jac=True,method='L-BFGS-B',bounds=[(0,1) if a else (0,0) for a in avail],options={'maxiter':150,'ftol':1e-14,'gtol':1e-10,'maxls':20})
    y=result.x;val,gr=objective(y);pg=y-np.clip(y-gr,0,avail.astype(float));fw=float(np.sum(gr*y-np.minimum(0,gr)*avail))
    pq=np.stack([1-y,y],axis=1)
    laws=[('old_g1',np.column_stack([np.ones(n),np.zeros(n)]),np.column_stack([np.ones(n),np.zeros(n)])),('last_j0',np.column_stack([np.ones(n),np.zeros(n)]),glast),('first_waterfill',pf,gfirst),('last_waterfill',pl,glast),('global_old_gram_surrogate',pq,glast)]
    reports=[]
    for name,p,g in laws:
        gs=g.copy();gs[gs==0]=1;x=p/gs
        O2=P=Dgraph=N2=ON=full=0.
        for j in [0,1]:
            z=x[:,j];r=np.sqrt(gs[:,j])
            H=intersect_mass(centers,r,centers,r)*T
            U=intersect_mass(centers,np.ones(n),centers,r)*T
            O2+=wt**2*(z@K@z);full+=wt**2*(z@H@z)
            ON+=wt**2*(z@(U-K)@z)
            N2+=wt**2*(z@(H-U-U.T+K)@z)
            P+=wt*np.sum(e*z*z)
            Dgraph+=wt**2*.5*np.sum(K*(z[:,None]-z[None,:])**2)
        shell=wt*np.sum(oldm*(gamma1-1)*x[:,1]);cap=Cs*shell
        young=2*O2+2*cap;major=2*P+2*cap
        resid={'old_identity':P-Dgraph-O2,'full_split':full-O2-2*ON-N2,'Young_slack_identity':young-full-(O2-2*ON+N2+2*(cap-N2))}
        assert max(abs(v) for v in resid.values())<1e-12
        assert cap-N2>-1e-12 and O2-2*ON+N2>-1e-12
        reports.append({'law':name,'Bpi':full,'O2':O2,'twice_ON':2*ON,'N2':N2,'P':P,'Dgraph':Dgraph,'Ddel':0,'shell_L1':shell,'shell_cap':cap,'shell_cap_slack':cap-N2,'positive_majorant':major,'graph_corrected_Young':young,'Young_vector_slack':O2-2*ON+N2,'total_Young_slack':young-full,'residuals':resid,'p':p.tolist(),'g_proxy':g.tolist()})
    allruns.append({'grid':size,'nodes':n,'weight_exact':str(F(49,64)/n),'Q0':Q0,'X':wt*sum(oldm),'alpha_range':[min(alpha),max(alpha)],'available_j1':int(sum(avail)),'threshold_certificates':cert,'laws':reports,'QP':{'method':'L-BFGS-B bounded convex QP, one call','objective':'2 O2 + 2 Cstar shell_L1','success':bool(result.success),'message':result.message,'iterations':result.nit,'feasibility':float(max(np.max(-y),np.max(y-avail),0)),'projected_KKT_inf':float(max(abs(pg))),'FW_gap_numerical':fw,'objective':val}})
changes={a['law']:abs(b['Bpi']/a['Bpi']-1) for a,b in zip(allruns[0]['laws'],allruns[1]['laws'])}
J=1+int(np.floor(np.log2(max(2**(1/8),A))/(1/8)));d=5/8
out={'scope':'one frozen input; finite midpoint-center numerical energies, no Lebesgue integration certificate or general theorem',
     'status':'UNRESOLVED primary change >10%; stopped' if max(changes.values())>.1 else 'fixed-grid sensitivity passed; no continuous integration certificate',
     'input':{'n':2,'R':1,'G':4,'gamma':2,'h':'1/8','epsilon':1,'mu_boxes':[[list(map(str,a)),list(map(str,b)),str(c)] for a,b,c in boxes],'E':'[-7/16,7/16]^2','W':'11/10','cell':'[-16,16]^2'},
     'strict_certificates':{'all_E_bulk':'core mass1; e>=49/64*6/7; C<12/5; alpha>=1225/4928; A>89/20; Aalpha>11/10>=kappaG','log_window':'(11/10)^7<2 exact rational','phase_count':'(11/10)^4<2 exact rational; only 0,1 reachable','root_semantics':'j1 unique increasing polynomial root, strict rational signs at bracket; j0 exact last plateau endpoint with immediate strict growth check'},
     'input_evaluation_error':{'root_side_bracket_max_width':2**-48,'g_proxy_absolute_error_bound':4*2**-49,'floating_energy':'ordinary binary64 analytic box-product evaluation; residual checks are numerical, not outward-rounded energy certificates','source_sampling':False},
     'runs':allruns,'relative_primary_changes':changes,'mother':{'C':C,'Cstar':Cs,'A':A,'D':4,'d':d,'J_global':J,'occupied_phases':2,'absorption_a_strict_upper':d*d/(16*J),'statement':'d Q0 <= C(1+G)W + G sqrt(J Q0 Bpi); Q0<=2C(1+G)W/d+G^2 J Bpi/d^2','no_deletion_stronger':'d Q0 <= G sqrt(2 Q0 Bpi) valid here; no deletion bill incurred'},
     'versions':{'python':platform.python_version(),'interpreter':sys.executable,'numpy':np.__version__,'scipy':scipy.__version__,'python_flint':flint.__version__},'cost':{'seconds':time.perf_counter()-start,'maxrss_bytes_macos':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'processes':1,'QP_calls':2,'quad_grids':[8,12]},'code_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
assert out['cost']['seconds']<30 and out['cost']['maxrss_bytes_macos']<200e6
Path('/tmp/ccu_r571_sol_joint_numeric.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:out[k] for k in ['status','relative_primary_changes','mother','cost','versions']},indent=2))
