#!/usr/bin/env python3
"""Portable checks for the frozen R571 release. No optimizer/grid/MATLAB rerun."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
import tempfile
import time

ROOT = Path(__file__).resolve().parent
META = {'cost', 'versions', 'code_sha256'}

def mathematical_fields(x):
    if isinstance(x, dict):
        return {k: mathematical_fields(v) for k, v in x.items() if k not in META}
    if isinstance(x, list):
        return [mathematical_fields(v) for v in x]
    return x

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    start = time.perf_counter()
    checks = []
    env = os.environ.copy()
    for key in ['OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS']:
        env[key] = '1'
    def run(command):
        result = subprocess.run(command, env=env, text=True, capture_output=True)
        if result.returncode:
            raise RuntimeError(result.stdout + result.stderr)
        return result
    with tempfile.TemporaryDirectory(prefix='ccu-r571-check-') as tmp:
        tmp = Path(tmp)
        for stem in ['certificate_final', 'parameter_certificate']:
            source = ROOT/'numeric'/('ccu_r571_'+stem+'.py')
            output = tmp/(stem+'.json')
            run([sys.executable, str(source), '--output', str(output)])
            actual = json.loads(output.read_text())
            frozen = json.loads(source.with_suffix('.json').read_text())
            assert mathematical_fields(actual) == mathematical_fields(frozen), stem
            checks.append({'name': stem, 'result': 'all mathematical fields equal',
                           'script_sha256': hashlib.sha256(source.read_bytes()).hexdigest()})
        # Preserve the original script bytes in the archive. Redirect its single
        # historical absolute output pathname in a temporary execution copy only.
        source = ROOT/'numeric'/'ccu_r571_gamma_budget_audit.py'
        text = source.read_text()
        old = "'/tmp/ccu_r571_gamma_budget_audit.json'"
        assert text.count(old) == 1
        target = tmp/'gamma_budget.json'
        patched = tmp/'gamma_budget.py'
        patched.write_text(text.replace(old, repr(str(target))))
        run([sys.executable, str(patched)])
        actual = json.loads(target.read_text())
        frozen = json.loads(source.with_suffix('.json').read_text())
        assert actual == frozen
        checks.append({'name': 'gamma_budget_audit', 'result': 'all exact expressions equal',
                       'script_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
                       'execution_change': 'output pathname only, temporary copy'})
        numeric = ROOT/'numeric'
        output = tmp/'archive_verify'
        run([sys.executable, str(numeric/'ccu_r571_archive_verify.py'),
             '--data', str(numeric/'ccu_r571_sol_joint_numeric.json'),
             '--source', str(numeric/'ccu_r571_sol_joint_numeric.py'),
             '--report', str(numeric/'ccu_r571_sol_joint_numeric.md'),
             '--out', str(output)])
        verification = json.loads(output.with_suffix('.json').read_text())
        assert not verification['failures']
        checks.append({'name':'frozen_joint_numeric_certificates',
                       'result':verification['status'],
                       'checks':verification['checks'],
                       'j1_counts':verification['j1_counts'],
                       'energy_max_absolute_differences':verification['energy_max_absolute_differences'],
                       'probability_numerical_defects':verification['probability_numerical_defects'],
                       'limitations':verification['limitations']})
    import sympy, numpy, scipy, flint
    data = {'status':'PASS within the listed finite/symbolic scope',
            'checks':checks, 'interpreter':sys.executable,
            'versions':{'python':platform.python_version(),'sympy':sympy.__version__,
                        'numpy':numpy.__version__,'scipy':scipy.__version__,'flint':flint.__version__},
            'commands':'see this script; all subprocesses use sys.executable',
            'seconds':time.perf_counter()-start,
            'not_run':['optimization','additional grids','MATLAB','PDF compilation'],
            'scope':'Exact scalar algebra and frozen rational root certificates; binary64 energy checks only. No general geometric payer or continuous-center integral is certified.'}
    args.output.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'status':data['status'],'groups':len(checks),'seconds':data['seconds'],'versions':data['versions']},indent=2))

if __name__ == '__main__':
    main()
