"""Verify the two simultaneous loading constraints on the physical R787 examples."""
import argparse
import json
import platform
import sys
from fractions import Fraction as F
from itertools import combinations
from pathlib import Path

from loads787 import ETA, hidden_source_cells, peak_groups, total, volume_bin


def physical_case(n, p, q, clone):
    m, weights, degrees, _, _, _, cubes, _, _, _, price_mass, _, groups, _ = (
        peak_groups(n, p, q, clone)
    )
    members = hidden_source_cells(cubes[:p])
    bins = n + 2
    per_bin = 2 * (1 + F(1, 32 * n)) ** n
    source_bound = ETA * (bins * per_bin) ** 2
    owner_bound = ETA * bins * per_bin
    source_ratios, owner_ratios = [], []
    subset_count = 0
    selected, all_mass = F(0), F(0)
    subsets = [s for count in range(p + 1) for s in combinations(range(p), count)]
    # In these finite families the vector at all owner upper bounds is feasible.
    # Multipliers one on the selected owner caps prove the matching upper bound.
    feasible = [weights[u] / (bins * m[u]) for u in range(p)]
    assert max(total(feasible[u] for u in member) for member in members) <= 1
    caps = {s: total(weights[u] for u in s) / bins for s in subsets}
    for (g, half), rows in sorted(groups.items()):
        beta = weights[g] * price_mass[g] / (2 * m[g])
        h = [total(degrees[v] * m[v] * mass for (i, v), mass in rows.items()
                   if i == u) / beta for u in range(p)]
        source_ratios.append(max(total(h[u] / m[u] for u in member)
                                 for member in members) / source_bound)
        owner_ratios.append(max(h[u] / weights[u] for u in range(p)) / owner_bound)
        k0 = max(source_bound, bins * owner_bound)
        for s in subsets:
            assert total(h[u] for u in s) <= k0 * caps[s]
            subset_count += 1
        for d in sorted({volume_bin(m[v]) for u, v in rows}):
            current = [(u, value) for (u, v), value in rows.items() if volume_bin(m[v]) == d]
            # A preselected diagnostic capacity ceiling admitting one lightest label.
            # The asymptotic threshold in the theorem is much larger in these examples.
            threshold = min(caps[(u,)] for u in range(p))
            allowable = [s for s in subsets if caps[s] <= threshold]
            captured = max(total(value for u, value in current if u in s) for s in allowable)
            selected += captured
            all_mass += total(value for _, value in current)
    assert max(source_ratios) <= 1 and max(owner_ratios) <= 1
    assert 0 < selected < all_mass
    return dict(n=n, visible_groups=len(groups), exact_subset_checks=subset_count,
                max_source_over_explicit_bound=max(source_ratios),
                max_owner_over_explicit_bound=max(owner_ratios),
                diagnostic_paid_fraction=selected / all_mass)


def lower_source(k):
    # The stratified atomic component of the supplied wide-window input.
    # Take positions in the interior of each stratum so the supports below stay in it.
    positions = [(j + F(1, 4) + F((3*j+1) % 5, 10)) / k for j in range(k)]
    radius = F(1, 8*k*k)
    windows = [(x-radius, x+radius) for x in positions[:k//4]]
    atoms_inside = sum(any(a <= x <= b for a, b in windows) for x in positions)
    smoothed_inside = total(
        total(max(F(0), min(b, x+radius/2) - max(a, x-radius/2)) / radius
              for a, b in windows) / k for x in positions
    )
    true_mass = F(atoms_inside, k)
    length = total(b-a for a, b in windows)
    assert true_mass == smoothed_inside == F(1, 4)
    assert true_mass / length == 4*k
    return dict(k=k, source_mass=true_mass, smoothed_mass=smoothed_inside,
                length=length, source_over_length=true_mass/length)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    options = parser.add_mutually_exclusive_group()
    options.add_argument("--output", type=Path)
    options.add_argument("--check", type=Path)
    args = parser.parse_args()
    result = dict(python=platform.python_version(), interpreter=sys.executable,
                  cases=[physical_case(8,2,1,False),physical_case(16,3,2,True),
                         physical_case(32,4,3,True)],
                  lower_source=[lower_source(k) for k in (8,32,128)],
                  arithmetic="fractions.Fraction; exact",
                  scope="Finite cube loading and primal/dual cap checks; a lower-note source component and its absolutely continuous smoothing.")
    encoded = (json.dumps(result, indent=2, sort_keys=True, default=str) + "\n").encode()
    if args.output:
        args.output.write_bytes(encoded)
    elif args.check:
        if args.check.read_bytes() != encoded:
            raise SystemExit("packing certificate differs")
        print("packing787: all load constraints, optimal cap certificates and lower-source checks agree")
    else:
        print(encoded.decode(), end="")


if __name__ == "__main__":
    main()
