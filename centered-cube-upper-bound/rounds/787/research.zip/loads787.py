"""R787: exact conditional source fee on real signed cubes."""

import argparse
from collections import defaultdict
from fractions import Fraction as F
from itertools import product
import json
from pathlib import Path
import platform
import sys


DELTA = F(1, 16)
PERIOD = F(1, 32)
ETA = F(1, 8)


def total(values):
    return sum(values, F(0))


def mult(values):
    answer = F(1)
    for value in values:
        answer *= value
    return answer


def volume(box):
    return mult(max(F(0), hi - lo) for lo, hi in box)


def mu1(interval):
    lo, hi = interval
    if hi <= lo:
        return F(0)

    def primitive(x):
        q = x // PERIOD
        rem = x - q * PERIOD
        return q * PERIOD + rem / 2 + max(F(0), rem - PERIOD / 2)

    return primitive(hi) - primitive(lo)


def mu(box):
    return mult(map(mu1, box))


def cube(center, radius):
    return tuple((c - radius, c + radius) for c in center)


def intersect(a, b):
    return tuple((max(lo, u), min(hi, v)) for (lo, hi), (u, v) in zip(a, b))


def contains(a, b):
    return all(lo <= u <= v <= hi for (lo, hi), (u, v) in zip(a, b))


def volume_bin(m):
    b = m.numerator.bit_length() - m.denominator.bit_length()
    return b - (F(2) ** b > m)


def price_cells(price, refine):
    if not refine:
        return [price]
    lo, hi = price[0]
    middle = (lo + hi) / 2
    return [((lo, middle),) + price[1:], ((middle, hi),) + price[1:]]


def sign_cubes(n, p, q, clone):
    # R786 groups sign construction, with one private axis per hidden / visible
    # label. Passive coordinates have centre zero. Vary the hidden radii.
    small_r = [F(1) + F(i, 8) for i in range(p)]
    right_r = [F(1) + F(g, 16) for g in range(q)]
    middle_r = [F(3, 2) + F((2 * u + g) % 7, 16)
                for u, g in product(range(p), range(q))]
    tagging = [frozenset([i]) for i in range(p + q)]
    tagging += [frozenset((u, p + g))
                for u, g in product(range(p), range(q))]
    radius = small_r + right_r + middle_r
    if clone:
        radius.append(F(31, 16))
        tagging.append(frozenset((0, p)))
    centers = [tuple((s - DELTA) * (1 if i in tag else -1)
                     for i in range(p + q)) + (F(0),) * (n - p - q)
               for s, tag in zip(radius, tagging)]
    return radius, tagging, centers


def hidden_source_cells(boxes):
    """Independent coordinate arrangement, aggregated by hidden-label masks."""
    p = len(boxes)
    n = len(boxes[0])
    masses = {(1 << p) - 1: F(1)}
    for axis in range(n):
        intervals = [a[axis] for a in boxes]
        breaks = sorted({point for interval in intervals for point in interval})
        local = defaultdict(F)
        for lo, hi in zip(breaks, breaks[1:]):
            mask = sum(1 << i for i, (l, h) in enumerate(intervals)
                       if l <= lo < hi <= h)
            if mask:
                local[mask] += mu1((lo, hi))
        cell_mass = defaultdict(F)
        for mask, a in masses.items():
            for other, b in local.items():
                if mask & other:
                    cell_mass[mask & other] += a * b
        masses = cell_mass
    return {tuple(i for i in range(p) if mask & (1 << i)): mass
            for mask, mass in masses.items()}


def owner_mass_fraction(eg, b, keep_half):
    lo, hi = eg[0]
    mid = (lo + hi) / 2
    a, z = (lo, mid) if b == 0 else (mid, hi)
    if keep_half:
        z = (a + z) / 2
    return volume(((a, z),) + eg[1:]) / volume(eg)


def peak_groups(n, p, q, clone):
    r, tag, centers = sign_cubes(n, p, q, clone)
    a = 32 * n
    hidden = list(range(p))
    visible = list(range(p, p + q))
    mids = list(range(p + q, len(r)))
    labels = range(len(r))
    A = [cube(c, s) for c, s in zip(centers, r)]
    E = [cube(c, s / a) for c, s in zip(centers, r)]
    m = [(2 * s) ** n for s in r]
    I = [volume(e) for e in E]
    bins = list(map(volume_bin, m))
    assert all(1 <= s < 2 for s in r)
    assert list(map(mu, A)) == list(map(volume, A)) == m
    assert I == [z / a**n for z in m] and all(contains(x, y) for x, y in zip(A, E))
    J = {(i, j): mu(intersect(A[i], A[j])) for i, j in product(labels, repeat=2)}
    O = {(i, j): volume(intersect(E[i], E[j])) for i, j in product(labels, repeat=2)}
    for i, j in J:
        d = len(tag[i] ^ tag[j])
        assert J[i, j] == (2 * DELTA) ** d * (2 * min(r[i], r[j])) ** (n - d)
        assert O[i, j] == (I[i] if i == j else 0)

    # The diagnostic hard cuts use bin separation and small TRUE source overlap.
    hard = {(i, j) for i, j in J if bins[i] != bins[j]
            and 0 < J[i, j] <= ETA * min(m[i], m[j])}
    K = {edge: J[edge] / (m[edge[0]] * m[edge[1]]) for edge in hard}
    d = {v: total(I[j] * K.get((v, j), 0) for j in labels) for v in mids}
    assert min(d.values()) > 0
    peak_all = total(
        I[u] * I[v] * I[g] * K.get((u, v), 0) * K.get((v, g), 0) / d[v]
        for u, v, g in product(hidden, mids, visible)
    )
    prices = {i: cube(tuple(F(j == i) for j in range(n)), DELTA / 2)
              for i in hidden + visible}
    price_mass = {i: mu(P) for i, P in prices.items()}
    assert all(x == DELTA**n for x in price_mass.values())
    assert all(not volume(intersect(prices[i], prices[j])) for i in prices
               for j in prices if i != j)
    for i in labels:
        for j, P in prices.items():
            assert contains(A[i], P) == (j in tag[i])
            assert mu(intersect(A[i], P)) == (price_mass[j] if j in tag[i] else 0)
    groups = defaultdict(dict)
    for u, v, g, b in product(hidden, mids, visible, range(2)):
        if not (contains(A[v], prices[u]) and contains(A[v], prices[g])):
            continue
        assert (u, v) in K and (v, g) in K
        row = u + int(clone and v == mids[-1])
        keep_half = (row + b) % 2 == 1
        owner_fraction = owner_mass_fraction(E[g], b, keep_half)
        assert owner_fraction == (F(1, 4) if keep_half else F(1, 2))
        # True conditional price laws restricted to the two literal price cubes.
        base = (I[u] * I[v] * I[g] * K[u, v] * K[v, g] / d[v]
                * price_mass[u] / J[u, v] * price_mass[g] / J[v, g])
        # Independently cancel the two true intersection denominators at fixed price.
        direct = (I[u] / m[u]) * (I[v] / (d[v] * m[v] ** 2)) * (I[g] / m[g])
        assert base == direct * price_mass[u] * price_mass[g]
        groups[g, b][u, v] = base * owner_fraction
    assert total(w for runs in groups.values() for w in runs.values()) <= peak_all
    return m, I, d, hard, J, O, A, r, tag, prices, price_mass, mids, groups, peak_all


def pair_fees(group, m, hard, J, O):
    normalizer = total(group.values())
    fee = hard_fee = owner_fee = cross = wrong_squared = F(0)
    witness = None
    for (a, v), left in group.items():
        for (b, w), right in group.items():
            raw_pair = left * right / normalizer
            factor = max(m[v], m[w]) / (m[a] * m[b])
            charge = raw_pair * factor * J[a, b]
            fee += charge
            owner_fee += raw_pair * factor * O[a, b]
            wrong_squared += charge * normalizer
            if (a, b) in hard:
                hard_fee += charge
            if a != b and v != w:
                cross += raw_pair
                if witness is None and charge:
                    witness = {"hidden_a_a_prime": [a, b], "middle_v_v_prime": [v, w],
                               "true_peak_cell_masses": [left, right],
                               "visible_X_cell_mass": normalizer,
                               "paired_mass": raw_pair, "actual_source_fee": charge}
    return fee, hard_fee, owner_fee, cross, wrong_squared, witness


def sorted_fees(group, m, hard, source_cells, I):
    normalizer = total(group.values())
    order = sorted({v for u, v in group}, key=lambda v: (m[v], v))
    densities = {(u, v): weight / (normalizer * m[u]) for (u, v), weight in group.items()}

    def integrands(members):
        cumulative = dict.fromkeys(members, F(0))
        regular = selected = F(0)
        for v in order:
            terms = {u: densities.get((u, v), F(0)) for u in members}
            subtotal = total(terms.values())
            regular += m[v] * subtotal * (subtotal + 2 * total(cumulative.values()))
            selected += m[v] * total(
                terms[i] * (terms[j] + 2 * cumulative[j])
                for i, j in product(members, repeat=2) if (i, j) in hard)
            for u, value in terms.items():
                cumulative[u] += value
        return regular, selected

    fee = hard_fee = F(0)
    for mem, mass in source_cells.items():
        base, selected = integrands(mem)
        fee += mass * base
        hard_fee += mass * selected
    # The disjoint owner sets may be merged into their direct Lebesgue union.
    owner_fee = total(I[u] * integrands((u,))[0] for u in range(len(I))
                      if any(j == u for j, _ in group))
    return tuple(normalizer * x for x in (fee, hard_fee, owner_fee))


def profile(name, n, p, q, clone):
    m, I, d, hard, J, O, A, r, tags, prices, pm, mids, groups, peak_all = (
        peak_groups(n, p, q, clone))
    cells = hidden_source_cells(A[:p])
    for i, j in product(range(p), repeat=2):
        assert total(w for key, w in cells.items() if {i, j} <= set(key)) == J[i, j]
    fee = hard_fee = owner_fee = cross = bad_sq = bad_density_sq = F(0)
    by_hidden = by_middle = ignored_owner = refined = refined_bad = F(0)
    collapsed = defaultdict(lambda: defaultdict(F))
    witness = None
    hot = []
    R = total(w for group in groups.values() for w in group.values())
    for (g, owner), group in groups.items():
        f, h, o, c, sq, wi = pair_fees(group, m, hard, J, O)
        assert (f, h, o) == sorted_fees(group, m, hard, cells, I)
        fee += f
        hard_fee += h
        owner_fee += o
        cross += c
        bad_sq += sq
        bad_density_sq += sq / pm[g]
        if witness is None and wi:
            witness = {"g": g, "g_owner_half": owner, "same_right_price_box": prices[g],
                       **wi}
        # Exact y is equivalent to conditioning on its tag here: each conditional
        # density is constant on the unique original y box for that hidden parent.
        for key in range(p):
            local = {r: z for r, z in group.items() if r[0] == key}
            if local:
                by_hidden += pair_fees(local, m, hard, J, O)[0]
        for key in mids:
            local = {r: z for r, z in group.items() if r[1] == key}
            if local:
                by_middle += pair_fees(local, m, hard, J, O)[0]
        for record, weight in group.items():
            collapsed[g][record] += weight
        hot.append({"g": g, "actual_E_g_half": owner, "distinct_roots": len(group),
                    "group_mass": total(group.values()),
                    "source_and_hard_fees": [f, h]})
        for sub in price_cells(prices[g], True):
            frac = mu(sub) / pm[g]
            assert frac == F(1, 2)
            sub_group = {r: z * frac for r, z in group.items()}
            sub_result = pair_fees(sub_group, m, hard, J, O)
            refined += sub_result[0]
            refined_bad += sub_result[4]
    for group in collapsed.values():
        ignored_owner += pair_fees(group, m, hard, J, O)[0]
    assert 0 < R <= peak_all and 0 < hard_fee < fee and 0 < owner_fee < fee
    assert cross > 0 and witness
    assert refined == fee and refined_bad * 2 == bad_sq
    assert by_hidden != fee and by_middle != fee and ignored_owner != fee
    assert bad_sq != fee != bad_density_sq
    return {"model": name, "n": n, "hidden_parent_count": p, "visible_parent_count": q,
            "middle_parent_labels": mids, "radii": r, "sign_tags": [sorted(t) for t in tags],
            "m_equals_mu_and_Leb_parent": m, "I_equals_disjoint_Leb_owner": I,
            "full_true_degree_by_middle": d,
            "real_hidden_source_membership_cells": len(cells), "group_summaries": hot,
            "original_selected_orientation_peak_mass_before_mark_cuts": peak_all,
            "actual_marked_peak_mass": R, "actual_marked_peak_mass_over_original": R / peak_all,
            "full_source_fee_pair_equals_sorted": fee,
            "hard_hidden_pair_source_fee": hard_fee, "merged_disjoint_owner_fee": owner_fee,
            "cross_middle_and_different_hidden_price_pair_mass": cross,
            "positive_same_visible_price_group_cross_middle_witness": witness,
            "fees_divided_by_actual_marked_peak_mass": {
                "correct": fee / R, "hard": hard_fee / R, "owner": owner_fee / R,
                "extra_condition_same_hidden_y": by_hidden / R,
                "extra_condition_same_middle_v": by_middle / R,
                "omit_observed_owner_half": ignored_owner / R,
                "omit_one_X_normalizer_cell_mass": bad_sq / R,
                "omit_one_X_normalizer_density": bad_density_sq / R,
                "refine_right_true_price_cells_correct": refined / R,
                "refine_right_true_price_cells_omit_one_X_normalizer": refined_bad / R}}


def report():
    return {
        "scope": ("Finite real cubes in one radius octave. Diagnostic hard gate uses "
                  "different volume bins and true overlap <= eta times the smaller source mass. "
                  "C_i=A_i. True peaks use the degrees from all diagnostic neighbours. The observed right "
                  "physical label, its actual price and its actual owner half replace the old-row "
                  "continuation. Price/owner cuts and these dimensions certify this finite interface."),
        "source": "Independent period-1/32 densities 1/2 then 3/2 per axis; finite truncation outside all parents is immaterial.",
        "owner": "Lebesgue-uniform actual E_g; accept the full or the lower half of each observed E_g half depending on the middle label and hidden price tag.",
        "join": "Condition on the same exact z (densities constant on its box), physical g and owner half; multiply the independent conditional weights by the marginal once.",
        "inputs": {"eta": ETA, "sign_corner_margin": DELTA, "a": "32*n"},
        "arithmetic": "fractions.Fraction (zero roundoff)",
        "python": {"executable": sys.executable, "version": platform.python_version(),
                   "machine": platform.machine()},
        "command": "python -B loads787.py --check loads787.json",
        "models": [profile("minimal", 8, 2, 1, False),
                   profile("different_mid_radii_and_owner_strata", 16, 3, 2, True),
                   profile("more_middle_labels", 32, 4, 3, True)]}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    modes = parser.add_mutually_exclusive_group()
    modes.add_argument("--output", type=Path)
    modes.add_argument("--check", type=Path)
    options = parser.parse_args()
    data = json.dumps(report(), sort_keys=True, indent=2, default=str) + "\n"
    if options.output:
        options.output.write_bytes(data.encode())
    elif options.check:
        if options.check.read_bytes() != data.encode():
            raise SystemExit("certificate differs")
        print("loads787: three real cube cases agree exactly")
    else:
        print(data, end="")


if __name__ == "__main__":
    main()

