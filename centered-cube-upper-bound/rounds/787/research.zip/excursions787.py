"""R787. Exact finite record-kernel checks for a strict ascent excursion."""

import argparse
from collections import defaultdict
from fractions import Fraction as F
from itertools import groupby
import json
from pathlib import Path
import platform
import sys


def diag(weights):
    return [{i: w} for i, w in enumerate(weights)]


def multiply(a, b):
    out = []
    for row in a:
        acc = defaultdict(F)
        for k, u in row.items():
            for j, v in b[k].items():
                acc[j] += u * v
        out.append({j: x for j, x in acc.items() if x})
    return out


def chain(matrices, n):
    result = diag([F(1)] * n)
    for matrix in matrices:
        result = multiply(result, matrix)
    return result


def adjoint(a, pi):
    out = [{} for _ in pi]
    for i, row in enumerate(a):
        for j, value in row.items():
            out[j][i] = pi[i] * value / pi[j]
    return out


def restrict(a, keep):
    return [{j: v for j, v in row.items() if keep(i, j)}
            for i, row in enumerate(a)]


def resample(keys, pi):
    blocks = defaultdict(dict)
    for i, key in enumerate(keys):
        blocks[key][i] = pi[i]
    block_mass = {k: sum(row.values()) for k, row in blocks.items()}
    return [{j: p / block_mass[k] for j, p in blocks[k].items()}
            for k in keys]


def rowsums(matrix):
    return [sum(row.values()) for row in matrix]


def l1_difference(a, b):
    return sum(abs(row.get(k, 0) - other.get(k, 0))
               for row, other in zip(a, b)
               for k in row.keys() | other.keys())


def joint(kernel, pi):
    return [{j: pi[i] * value for j, value in row.items()}
            for i, row in enumerate(kernel)]


def transpose(matrix):
    return adjoint(matrix, [F(1)] * len(matrix))


def gram_rank(matrix):
    """Exact symmetric Schur complements; zero pivots require a zero row."""
    n = len(matrix)
    dense = [[row.get(j, F(0)) for j in range(n)] for row in matrix]
    rank = 0
    for k in range(n):
        p = dense[k][k]
        assert p >= 0
        if not p:
            assert not any(dense[k][j] for j in range(k, n))
            continue
        rank += 1
        active = [i for i in range(k + 1, n) if dense[i][k]]
        for i in active:
            for j in active:
                dense[i][j] -= dense[i][k] * dense[k][j] / p
    return rank


def encode_record(record, prices):
    v, left, right = record
    return {"history": v, "left": prices[left], "right": prices[right]}


def follow(start, matrices):
    """Enumerate positive full record paths in one direction."""
    if not matrices:
        yield (start,), F(1)
        return
    for nxt, w in matrices[0][start].items():
        for path, rest in follow(nxt, matrices[1:]):
            yield (start,) + path, w * rest


def trace_weight(path, matrices, pi):
    weight = pi[path[0]]
    for kernel, i, j in zip(matrices, path[:-1], path[1:]):
        weight *= kernel[i].get(j, 0)
    return weight


def path_audit(path_kernels, pi):
    rows = [defaultdict(F) for _ in pi]
    count = 0
    for start in range(len(pi)):
        for path, weight in follow(start, path_kernels):
            original = pi[start] * weight
            assert trace_weight(path[::-1], path_kernels, pi) == original
            rows[start][path[-1]] += original
            count += 1
    return rows, count


def independent_arms(records, pi, history):
    """Wrong summit kernel, restricted to records that actually exist."""
    left = defaultdict(F)
    right = defaultdict(F)
    for (v, a, b), p in zip(records, pi):
        left[v, a] += p / history[v]
        right[v, b] += p / history[v]
    return [
        {j: left[v, a] * right[v, b]
         for j, (w, a, b) in enumerate(records) if v == w}
        for v, _, _ in records
    ]


def wrapped_records(n_histories, n_prices):
    return [(v, a, (a + shift) % n_prices,
             1 + (17 * v + 7 * a + 3 * shift + 3 * a * v) % 19)
            for v in range(n_histories)
            for a in range(n_prices)
            for shift in (1, 2)]


def audit(name, masses, prices, table, steps, exhaustive=False):
    records = [tuple(entry[:3]) for entry in table]
    assert len(set(records)) == len(records)
    assert all(a != b for _, a, b in records)
    assert all(entry[-1] > 0 for entry in table)
    n = len(records)
    pi = [F(entry[-1], sum(row[-1] for row in table)) for entry in table]
    h_keys = [v for v, _, _ in records]
    assert set(h_keys) == set(range(len(masses)))
    history = defaultdict(F)
    for v, p in zip(h_keys, pi):
        history[v] += p
    volume = [masses[v] for v in h_keys]
    full = [resample([r[field] for r in records], pi) for field in (1, 2)]
    for a in full:
        assert rowsums(a) == [1] * n
        assert a == adjoint(a, pi)
    up = [restrict(a, lambda i, j: volume[i] < volume[j]) for a in full]
    down = [restrict(a, lambda i, j: volume[i] > volume[j]) for a in full]
    assert down == [adjoint(a, pi) for a in up]
    sides = [(step + 1) % 2 for step in range(steps)]
    ascending = [up[s] for s in sides]
    descending = [down[s] for s in reversed(sides)]
    p = chain(ascending, n)
    pstar = chain(descending, n)
    assert pstar == adjoint(p, pi)
    c = resample(h_keys, pi)
    assert c == adjoint(c, pi) == multiply(c, c)
    assert rowsums(c) == [1] * n

    path_kernels = ascending + [c] + descending
    q = multiply(multiply(p, c), pstar)
    gamma = joint(q, pi)
    assert gamma == transpose(gamma)
    assert max(rowsums(q)) <= 1
    reach = [defaultdict(F) for _ in pi]
    for row, by_history in zip(p, reach):
        for index, x in row.items():
            by_history[h_keys[index]] += x
    via_gram = []
    for i, row in enumerate(reach):
        by_endpoint = {}
        for j, other in enumerate(reach):
            weight = pi[i] * pi[j] * sum(
                x * other.get(v, 0) / history[v] for v, x in row.items())
            if weight:
                by_endpoint[j] = weight
        via_gram.append(by_endpoint)
    assert via_gram == gamma
    rank = gram_rank(gamma)
    reachable = sorted({h for row in reach for h in row})
    assert 0 < rank <= len(reachable)

    arrival = defaultdict(F)
    for p_i, row in zip(pi, reach):
        for v, x in row.items():
            arrival[v] += p_i * x
    success = sum(arrival.values())
    excursion = sum(rowsums(gamma))
    assert excursion == sum(arrival[v] ** 2 / history[v] for v in history)
    assert 0 < success <= F(1, 2)
    assert success ** 2 <= excursion <= success
    one_loss = 1 - success
    both_loss = 1 - excursion
    slack = 2 * one_loss - both_loss
    assert slack == sum((history[v] - arrival[v]) ** 2 / history[v] for v in history)

    c_bad = independent_arms(records, pi, history)
    c_bad_total = rowsums(c_bad)
    missing_mass = sum(pi[i] * (1 - z) for i, z in enumerate(c_bad_total))
    summit_missing = sum(arrival[v] * (1 - c_bad_total[h_keys.index(v)])
                         for v in history)
    bad_q = multiply(multiply(p, c_bad), pstar)
    assert missing_mass > 0 and summit_missing > 0
    assert sum(rowsums(joint(bad_q, pi))) < excursion
    c_bad_cond = [{j: x / z for j, x in row.items()}
                  for row, z in zip(c_bad, c_bad_total)]
    cond_bad_gamma = joint(multiply(multiply(p, c_bad_cond), pstar), pi)
    assert l1_difference(cond_bad_gamma, gamma) > 0

    bad_order = None
    if sides != sides[::-1]:
        wrong_down = chain([down[s] for s in sides], n)
        wrong_gamma = joint(multiply(multiply(p, c), wrong_down), pi)
        bad_order = {
            "joint_L1_error": l1_difference(wrong_gamma, gamma),
            "reversal_L1_error": l1_difference(wrong_gamma, transpose(wrong_gamma))}
        assert bad_order["joint_L1_error"] > 0
        assert bad_order["reversal_L1_error"] > 0

    wrong_conditioning = None
    if len(set(masses)) < len(masses):
        c_volume = resample(volume, pi)
        volume_gamma = joint(multiply(multiply(p, c_volume), pstar), pi)
        wrong_conditioning = l1_difference(volume_gamma, gamma)
        assert wrong_conditioning > 0

    wrapped = None
    if steps >= 2:
        # Remove the imposed strict order just long enough to witness a return.
        i, j = next((i, j) for i, j in enumerate(records)
                    if volume[i] == min(volume)
                    for j in full[sides[0]][i] if volume[j] > volume[i]
                    and i in full[sides[1]][j])
        wrapped_path = (i, j, i)
        returned = trace_weight(wrapped_path, [full[s] for s in sides[:2]], pi)
        assert returned > 0
        assert trace_weight(wrapped_path, ascending[:2], pi) == 0
        wrapped = {"record_loop": wrapped_path, "unrestricted_path_mass": returned}

    changed = [(qij, i, j) for i, row in enumerate(gamma)
               for j, qij in row.items() if i < j
               and records[i][1] != records[j][1]
               and records[i][2] != records[j][2]]
    witness_mass, i, j = max(changed)
    summit = next(v for v in reach[i] if reach[j].get(v, 0))
    from_i = next(path for path, _ in follow(i, ascending)
                  if h_keys[path[-1]] == summit)
    from_j = next(path for path, _ in follow(j, ascending)
                  if h_keys[path[-1]] == summit)
    witness_path = from_i + from_j[::-1]
    trace_mass = trace_weight(witness_path, path_kernels, pi)
    assert 0 < trace_mass <= witness_mass
    assert trace_weight(witness_path[::-1], path_kernels, pi) == trace_mass
    count = None
    if exhaustive:
        direct_gamma, count = path_audit(path_kernels, pi)
        assert direct_gamma == gamma

    return {
        "model": name, "ascents": steps, "volumes": masses,
        "price_values": prices, "record_table_history_left_index_right_index_weight": table,
        "records": n, "exact_exhaustive_positive_path_count": count,
        "summit_histories_reachable": reachable, "Gram_rank": rank,
        "one_way_success": success, "excursion_success": excursion,
        "one_way_loss": one_loss, "excursion_loss": both_loss,
        "twice_one_way_loss_minus_excursion_loss": slack,
        "excursion_success_minus_one_way_success_squared": excursion - success ** 2,
        "both_mark_values_change_joint_mass": sum(t[0] for t in changed) * 2,
        "positive_changed_prices_example": {
            "endpoints": [encode_record(records[i], prices), encode_record(records[j], prices)],
            "endpoint_pair_mass": witness_mass,
            "one_full_path": [encode_record(records[k], prices) for k in witness_path],
            "path_and_time_reverse_mass": trace_mass},
        "wrong_independent_arms": {
            "missing_probability_under_prior": missing_mass,
            "missing_unnormalized_mass_after_ascent": summit_missing,
            "wrong_excursion_success_no_renormalization": sum(rowsums(joint(bad_q, pi))),
            "joint_L1_error_after_renormalizing_on_true_records":
                l1_difference(cond_bad_gamma, gamma)},
        "wrong_descent_order": bad_order, "L1_error_conditioning_on_volume_only": wrong_conditioning,
        "unrestricted_alternating_loop_rejected_by_strict_ascent": wrapped}


def report():
    minimal = audit("minimal", [2, 3], [F(-3, 4), F(1, 4)],
                    [(0, 0, 1, 1), (0, 1, 0, 2),
                     (1, 0, 1, 3), (1, 1, 0, 1)], 1, exhaustive=True)
    pressure = audit("correlated_arms_tied_summit_volume_and_wrap", [2, 3, 5, 8, 8],
                     [F(-3, 4), F(1, 8), F(3, 4)], wrapped_records(5, 3),
                     2, exhaustive=True)
    large = [audit("larger_finite_record_space", [2, 3, 5, 8, 12, 17, 25],
                   [F(-7, 8), F(-1, 4), F(3, 8), F(7, 8)], wrapped_records(7, 4),
                   j) for j in (3, 4)]
    return {
        "scope": ("Finite exact record models. Each side kernel is conditional on one actual "
                  "rational mark and returns a complete record. Only strict volume order gates "
                  "ascent. Volumes are order labels. No Euclidean owner geometry, high-dimensional "
                  "gates, or exponential estimate is certified."),
        "arithmetic": "fractions.Fraction; roundoff zero; all identities exact",
        "python": {"executable": sys.executable, "version": platform.python_version(),
                   "machine": platform.machine()},
        "reproduce": ["python -B excursions787.py --output excursions787.json",
                      "python -B excursions787.py --check excursions787.json"],
        "cases": [minimal, pressure] + large}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    flags = parser.add_mutually_exclusive_group()
    flags.add_argument("--output", type=Path)
    flags.add_argument("--check", type=Path)
    args = parser.parse_args()
    results = json.dumps(report(), sort_keys=True, indent=2, default=str) + "\n"
    if args.output:
        args.output.write_bytes(results.encode())
    elif args.check:
        if args.check.read_bytes() != results.encode():
            raise SystemExit("certificate differs")
        print(f"PASS {args.check} (four exact cases)")
    else:
        print(results, end="")


if __name__ == "__main__":
    main()

