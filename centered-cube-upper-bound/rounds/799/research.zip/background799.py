"""R799. Exact common-background budgets on genuine cubes, and a symbolic dimension check."""
from __future__ import annotations
import argparse
import hashlib
import json
import platform
import sys
from fractions import Fraction as Q
from itertools import product
from pathlib import Path

import flint
import sympy as sym


def box(first, rest, n):
    return (tuple(map(Q, first)),) + (tuple(map(Q,rest)),) * (n-1)


def volume(*boxes):
    return prodq(max(Q(0),min(hi for lo,hi in terms)-max(lo for lo,hi in terms))
                 for terms in zip(*boxes))


def prodq(seq):
    value = Q(1)
    for entry in seq:
        value *= entry
    return value


def snapshot(n, nt, nu, a, delta, cap):
    b=a-delta
    assert Q(0)<b<a<Q(1)
    C=box((0,1),(0,1),n)
    slab=box((b,a),(0,1),n)
    base=box((-5,5),(-5,5),n)
    left_fill=box((Q(-3,4),Q(-1,2)),(0,1),n)
    right_fill=box((Q(3,2),Q(7,4)),(0,1),n)
    mass=Q(1,2**20)
    parts=[(1,base),(-1,C),(mass/delta,slab),
           ((a-mass)/volume(left_fill),left_fill),
           ((1-b-mass)/volume(right_fill),right_fill)]
    assert all(w>0 for w,_ in parts[2:])
    def mu(*sets):
        return sum(w*volume(*sets,region) for w,region in parts)
    s_big=[Q(16,5)+Q(3,5)*Q(i+1,nt+1) for i in range(nt)]
    s_small=[Q(41,20)+Q(9,20)*Q(i+1,nu+1) for i in range(nu)]
    def parent(S,big):
        return box((a-S,a) if big else (b,b+S),((1-S)/2,(1+S)/2),n)
    cubes=[parent(S,True) for S in s_big]+[parent(S,False) for S in s_small]
    assert all(Q(2)<S<Q(4) for S in s_big+s_small)
    assert all(mu(B)==volume(B) for B in cubes) and mu(C)==mass
    centres=[(lo+hi)/2 for ((lo,hi),*_) in cubes]
    half=min(min(abs(x-y) for i,x in enumerate(centres) for y in centres[i+1:])/5,
             min(s_big+s_small)/(128*n))
    owners=[box((x-half,x+half),(Q(1,2)-half,Q(1,2)+half),n) for x in centres]
    assert not any(volume(X,Y) for i,X in enumerate(owners) for Y in owners[i+1:])
    j=list(map(volume,owners))
    mt=list(map(volume,cubes))
    direct=Q(0)
    reordered=Q(0)
    degrees=[]
    def gate(i,u,side):
        return Q(1+(i+u+side)%3,4)
    for i in range(nt):
        d=sum(j[u]*mu(cubes[i],cubes[u])/(mt[i]*mt[u]) for u in range(nt,len(cubes)))
        assert d>0
        degrees.append(d)
        one=[sum(j[u]*mass*gate(i,u,side)/(mt[i]*mt[u]) for u in range(nt,len(cubes)))
             for side in (0,1)]
        reordered+=j[i]*one[0]*one[1]/d
        for u,v in product(range(nt,len(cubes)),repeat=2):
            hit1=mu(cubes[i],cubes[u])
            hit2=mu(cubes[i],cubes[v])
            assert hit1>=mass and hit2>=mass
            weight=j[i]*j[u]*j[v]*(hit1/(mt[i]*mt[u]))*(hit2/(mt[i]*mt[v]))/d
            direct+=weight*(mass/hit1)*(mass/hit2)*gate(i,u,0)*gate(i,v,1)
    assert direct==reordered>0
    pool1=volume(C,*cubes[:nt])
    pool2=volume(C,*cubes[nt:])
    joint=volume(C,*cubes)
    assert (pool1,pool2,joint)==(a,1-b,delta)
    one_pos=min(Q(1),cap*joint)
    two_pos=min(Q(1),cap*min(pool1,pool2))
    spectral_sq=min(Q(1),cap*cap*pool1*pool2)
    assert one_pos<=two_pos and two_pos**2<=spectral_sq
    # For a positive operator of norm B, integration against the two indicators
    # is <= B sqrt(|P||Q|). The uniform product on P and Q attains it.
    return dict(n=n,big_side_lengths=s_big,small_side_lengths=s_small,
                left_clip=a,right_start=b,source_mass=mass,shared_strip=delta,
                common_left_volume=pool1,common_right_volume=pool2,
                capacity_multiplier=cap,owner_half_width=half,original_degrees=degrees,
                directed_two_leg_types=nt*nu*nu,actual_marked_peak=direct,
                reordered_actual_marked_peak=reordered,
                same_position_maximum_fraction=one_pos,
                separate_marginals_maximum_fraction=two_pos,
                spectral_maximum_fraction_squared=spectral_sq,
                paid_old_leg_by_one_position=direct*one_pos,
                paid_old_leg_by_two_marginals=direct*two_pos)


def star(k):
    # A common left slab and 2^k right orthants with a positive common core.
    M=2**k
    eps=Q(1,64*k*M*M)
    p=(Q(1,2)+eps)**k
    strip=1-(1-2*eps)**k
    single_opt=p
    uniform_product=p*p
    joint_upper=p/M+strip
    assert uniform_product<=joint_upper<2*p*p
    assert (2*eps)**k*p>0
    return dict(axes=k+1,number_of_right_types=M,epsilon=eps,right_and_left_volume=p,
                true_common_core=p*(2*eps)**k,independent_score=uniform_product,
                any_shared_uniform_marginals_upper=joint_upper,
                best_score_separately_for_each_hidden_type=single_opt)


def density_layers(groups):
    """Disjoint pairs [x,x+4] and [x+4-delta,x+6-delta] with true masses 4 and 2."""
    cap=Q(4)
    eps=Q(1,128)
    measures=[]
    for i,(delta,mass,share) in enumerate(groups):
        x=Q(10*i)
        big=(x,x+4)
        small=(x+4-delta,x+6-delta)
        mid=(x+4-delta,x+4)
        split=mid[0]+eps*delta
        # The old price is uniform with respect to mu on the true intersection.
        density=[(big[0],mid[0],(4-mass)/(4-delta)),
                 (mid[0],split,Q(1,4)+(mass-delta/4)/(eps*delta)),
                 (split,mid[1],Q(1,4)),
                 (mid[1],small[1],(2-mass)/(2-delta))]
        def interval_mu(I):
            return sum(max(Q(0),min(I[1],hi)-max(I[0],lo))*a for lo,hi,a in density)
        assert interval_mu(big)==4 and interval_mu(small)==2 and interval_mu(mid)==mass
        assert all(a>=0 for _,_,a in density)
        jt=Q(1,64)*share
        ju=Q(1,64)
        # Centered disjoint owners of these lengths fit radius s/(32 n), n=1.
        assert jt/2<=Q(2,32) and ju/2<=Q(1,32)
        degree=ju*mass/8
        D=jt*ju/8
        e=0
        while Q(2)**e>D:
            e-=1
        assert Q(2)**e<=D<2*Q(2)**e
        highpieces=[(hi-lo)*a for lo,hi,a in density[1:3] if a>cap]
        high=sum(highpieces)
        measures.append(dict(big=big,small=small,intersection=mid,mu_intersection=mass,
                 intersection_length=delta,source_pieces=density,physical_owner_volumes=[jt,ju],
                 source_total=6-mass,original_full_degree=degree,peak=jt*degree,
                 membership_average=mass/delta,raw_price_fraction_high=high/mass,
                 direct_double_high=jt*degree*sum(x*y for x in highpieces for y in highpieces)/mass**2,
                 D=D,bin=e))
    mixing={}
    for row in measures:
        e=row["bin"]
        m,v=mixing.get(e,(Q(0),Q(0)))
        mixing[e]=(m+row["mu_intersection"],v+row["intersection_length"])
    for row in measures:
        m,v=mixing[row["bin"]]
        row["load_bin_average"]=m/v
        row["raw_double_high"]=row["peak"]*row["raw_price_fraction_high"]**2
        assert row["raw_double_high"]==row["direct_double_high"]
        row["member_double_high"]=row["raw_double_high"]*int(row["membership_average"]>cap)
        row["pooled_double_high"]=row["member_double_high"]*int(m/v>cap)
    names=("peak","raw_double_high","member_double_high","pooled_double_high")
    sums={name:sum(row[name] for row in measures) for name in names}
    assert sums["peak"]>=sums["raw_double_high"]>=sums["member_double_high"]>=sums["pooled_double_high"]
    return dict(threshold=cap,relative_width_high_slab=eps,rows=measures,totals=sums)


def values():
    k=sym.symbols("k",positive=True)
    # n powers from H and from the density threshold B_k on both sides.
    assert sym.simplify(sym.Rational(1,2)+2*(k-2)/(4*k)-(1-1/k))==0
    assert sym.simplify((1-2/k)+sym.Rational(1,2)*2/k-(1-1/k))==0
    assert sym.simplify((1-2/k)+2/k-1)==0
    sets=[snapshot(2,2,2,Q(9,16),Q(1,8),Q(2)),
          snapshot(4,3,4,Q(33,64),Q(1,32),Q(2)),
          snapshot(8,5,8,Q(1,32),Q(1,128),Q(8))]
    assert [s["separate_marginals_maximum_fraction"] for s in sets]==[1,1,Q(1,4)]
    assert [s["spectral_maximum_fraction_squared"] for s in sets]==[1,1,1]
    first=(Q(1,2),Q(1,4),Q(1))
    narrow=(Q(1,64),Q(1,4),Q(1))
    layers=[density_layers([first]),density_layers([narrow,first]),
            density_layers([narrow,first,(Q(1,64),Q(1,2),Q(1,4)),(Q(1,32),Q(3,8),Q(1,4))])]
    assert layers[0]["totals"]["raw_double_high"]>0==layers[0]["totals"]["member_double_high"]
    assert layers[1]["totals"]["member_double_high"]>0==layers[1]["totals"]["pooled_double_high"]
    assert 0<layers[2]["totals"]["pooled_double_high"]<layers[2]["totals"]["member_double_high"]
    return dict(density_layer_stages=layers,runtime=dict(executable=sys.executable,python=platform.python_version(),
                             arch=platform.machine(),sympy=sym.__version__,python_flint=flint.__version__),
                inputs="Lebesgue on [-5,5]^n with C removed, uniform central and compensating slabs as in the code; owners are disjoint small cubes. Only positive first-crossing mass equality is tested, not all R798 gates or a near-extremizing input. Two true receiver gates have rational lengths given by gate(). Star tests shared background marginals only.",
                cubes=sets,star=[star(i) for i in (2,4,8)],symbolic_n_exponent="1-1/k",
                code_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())


def main():
    parser=argparse.ArgumentParser()
    group=parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--write",type=Path)
    group.add_argument("--check",type=Path)
    args=parser.parse_args()
    result=values()
    blob=(json.dumps(result,default=str,ensure_ascii=False,sort_keys=True,indent=2)+"\n").encode()
    if args.write:
        args.write.write_bytes(blob)
    else:
        assert blob==args.check.read_bytes()
    for c in result["cubes"]:
        print(c["n"],"true triple types",c["directed_two_leg_types"],"common / separate / spectral squared",
              c["same_position_maximum_fraction"],c["separate_marginals_maximum_fraction"],
              c["spectral_maximum_fraction_squared"])
    print("byte-identical" if args.check else "written")


if __name__=="__main__":
    main()

