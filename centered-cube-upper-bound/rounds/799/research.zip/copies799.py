#!/usr/bin/env python3
"""Conditional original-arm copies and genuine two-sided source intersections."""
import argparse
from collections import Counter, defaultdict
from fractions import Fraction as F
from hashlib import sha256
import importlib.util
from itertools import combinations, combinations_with_replacement, product
import json
from math import factorial, lcm, prod
from pathlib import Path
import platform


ROWS_SHA="04bbd600cd68bd2bb371559590a1902b97a345c02404ffc759a1147fb4b2bae9"
KS=(2,4,6)


def counts_tuple_and_dp(states, weights, k, good_t, good_u):
    """Count all ordered tuples, optionally doing exact multinomial compression."""
    W=sum(weights)
    length=len(states)
    counts=[0,0,0,0]
    any_label_repeated=0
    totals=0
    raw=(length**k<=100000)
    fs=[factorial(i) for i in range(k+1)]
    tuples=product(range(length),repeat=k) if raw else combinations_with_replacement(range(length),k)
    for seq in tuples:
        tm=um=0
        weight=1
        pairlabels=0
        for i in seq:
            t,u=states[i]
            tm|=t
            um|=u
            pairlabels|=1<<i
            weight*=weights[i]
        if not raw:
            multiplier=fs[k]
            for n in Counter(seq).values():
                multiplier//=fs[n]
            weight*=multiplier
        a,b=good_t[tm],good_u[um]
        counts[2*int(a)+int(b)]+=weight
        totals+=weight
        if pairlabels.bit_count()<k:
            any_label_repeated+=weight
    assert totals==sum(counts)==W**k

    dp={(0,0):1}
    for _ in range(k):
        new=defaultdict(int)
        for (m,n),z in dp.items():
            for (a,b),q in zip(states,weights):
                new[m|a,n|b]+=z*q
        dp=dict(new)
    alternative=[0,0,0,0]
    different_t=0
    different_u=0
    for (m,n),z in dp.items():
        alternative[2*int(good_t[m])+int(good_u[n])]+=z
        if m.bit_count()>1:
            different_t+=z
        if n.bit_count()>1:
            different_u+=z
    assert counts==alternative
    independent_distinct=sum(prod(c) for c in combinations(weights,k))*fs[k]
    assert any_label_repeated==W**k-independent_distinct
    def stats(both,central,old):
        joint,left,right=[F(n,W**k) for n in (both,central,old)]
        return dict(p_joint=joint,p_central=left,p_old=right,
                    incorrect_product=left*right,discrepancy=joint-left*right)

    payable=stats(counts[3],counts[2]+counts[3],counts[1]+counts[3])
    high=stats(counts[0],counts[0]+counts[1],counts[0]+counts[2])
    assert payable["p_central"]+high["p_central"]==payable["p_old"]+high["p_old"]==1
    assert payable["discrepancy"]==high["discrepancy"]
    return dict(payable_le=payable,strict_high_compression_gt=high,
                payable_central_only=F(counts[2],W**k),payable_old_only=F(counts[1],W**k),
                probability_an_exact_label_repeats=F(any_label_repeated,W**k),
                probability_distinct_central_labels=F(different_t,W**k),
                probability_distinct_old_labels=F(different_u,W**k),joint_parent_mask_count=len(dp),
                count_denominator=W**k,count_by_payable_category=counts,
                tuple_replay="literal ordered sequences" if raw else "all ordered sequences by exact multinomial count")


def test(name,T,U,shares,amp,C,observation,screen,parts,tau_t,tau_u,base):
    old= [base.owner(A,F(1)) for A in U]
    mid= [base.owner(A,s) for A,s in zip(T,shares)]
    ordered=sorted(old+mid)
    assert all(a[1]<b[0] for a,b in zip(ordered,ordered[1:]))
    mu=lambda b:base.real_mass(b,amp)
    m=list(map(base.length,T))
    sm=list(map(base.length,U))
    J=list(map(base.length,mid))
    j=list(map(base.length,old))
    assert [mu(A) for A in T+U]==m+sm
    rho=mu(C)/base.length(C)
    assert rho>0 and base.inside(observation,C)
    ends=sorted({*base.SOURCE,*C,*observation,*(x for a in T+U for x in a),
                 *(x for a in screen.values() for x in a if x is not None)})
    cells=list(zip(ends,ends[1:]))
    mass_cells=list(map(mu,cells))
    assert min(mass_cells)>0
    observation_ids=[a for a,c in enumerate(cells) if base.inside(c,observation)]
    n_t=len(T)
    n_u=len(U)
    neighbor={}
    for t,u in product(range(n_t),range(n_u)):
        q=base.clip(T[t],U[u])
        p=mu(q)
        if p and sm[u]<m[t]:
            neighbor[t,u]=q,p,p/(m[t]*sm[u])
    d=[base.total(j[u]*v[2] for (b,u),v in neighbor.items() if t==b) for t in range(n_t)]
    left_flow=[defaultdict(F) for _ in cells]
    right_flow=[defaultdict(F) for _ in cells]
    arm_exposure=[F(0)]*n_t
    true_occurrence={}
    for t in range(n_t):
        exactly_left={}
        exactly_right={}
        for (q,u),(I,true_mass,K) in neighbor.items():
            if q!=t:
                continue
            width=j[u]/parts
            steps=[width/j[u]]*parts
            caps=screen.get((t,u),(None,)*parts)
            assert len(caps)==parts
            for a,c in enumerate(cells):
                if not base.inside(c,I):
                    continue
                visible=base.total(r for r,limit in zip(steps,caps) if limit is None or c[1]<=limit)
                p=j[u]*K*mass_cells[a]/(d[t]*true_mass)
                assert p==j[u]*mass_cells[a]/(sm[u]*m[t]*d[t])
                exactly_right[u,a]=p
                if visible:
                    exactly_left[u,a]=p*visible
                true_occurrence[t,u,a]=visible
        assert base.total(exactly_right.values())==1
        arm_exposure[t]=base.total(exactly_left.values())
        original_term=J[t]*d[t]
        for (u,a),la in exactly_left.items():
            for (v,b),rb in exactly_right.items():
                real_mass=original_term*la*rb
                left_flow[a][t,u]+=real_mass
                right_flow[b][t,v]+=real_mass

    original_sum=base.total(I*delta*v for I,delta,v in zip(J,d,arm_exposure))
    assert original_sum>0
    assert all(base.total(mass for prices in side for mass in prices.values())==original_sum
               for side in (left_flow,right_flow))
    for (t,u,a),screen_p in true_occurrence.items():
        raw=J[t]*j[u]*mass_cells[a]/(m[t]*sm[u])
        assert left_flow[a][t,u]==raw*screen_p
        assert right_flow[a][t,u]==raw*arm_exposure[t]

    def all_ratios(geometries,gate):
        ratios={}
        approved={}
        for mask in range(1,1<<len(geometries)):
            box=base.clip(C,*(A for i,A in enumerate(geometries) if mask&(1<<i)))
            size=base.length(box)
            price=mu(box)
            r=price/(rho*size) if size else None
            approved[mask]=bool(r is not None and r<=gate)
            high=bool(r is not None and r>gate)
            assert int(approved[mask])+int(high)==int(r is not None)
            ratios[mask]=dict(box=box,actual_C_intersection_mu=price,actual_C_intersection_Leb=size,
                              ratio_to_density_in_C=r,payable_le_gate=approved[mask],
                              strict_high_compression_gt_gate=high,equal_gate=r==gate)
        return ratios,approved

    t_ratios,g_t=all_ratios(T,tau_t)
    u_ratios,g_u=all_ratios(U,tau_u)
    stages={}
    for direction in ("left","right","pooled"):
        works=[]
        for a in observation_ids:
            if direction=="left":
                flow=left_flow[a]
            elif direction=="right":
                flow=right_flow[a]
            else:
                pair_keys=left_flow[a].keys()|right_flow[a].keys()
                flow={key:(left_flow[a][key]+right_flow[a][key])/2 for key in pair_keys}
            labels=sorted((t,u) for (t,u),w in flow.items() if w)
            if not labels:
                continue
            assert all(base.inside(cells[a],T[t]) and base.inside(cells[a],U[u]) for t,u in labels)
            mass=base.total(flow[t,u] for t,u in labels)
            ratios=[flow[t,u]/mass for t,u in labels]
            common_den=lcm(*(q.denominator for q in ratios))
            weights=[int(common_den*q) for q in ratios]
            assert sum(weights)==common_den
            states=[(1<<t,1<<u) for t,u in labels]
            all_k={str(k):counts_tuple_and_dp(states,weights,k,g_t,g_u) for k in KS}
            works.append(dict(source_price_cell=cells[a],true_mu=mass_cells[a],original_lambda_mass=mass,
                              joint_old_arm_conditional_law=[(t,u,q) for (t,u),q in zip(labels,ratios)],
                              copies=all_k))
        denom=base.total(x["original_lambda_mass"] for x in works)
        assert denom>0
        weighted={}
        for k in KS:
            joint_fields=("p_joint","p_central","p_old","incorrect_product")
            info={}
            for event in ("payable_le","strict_high_compression_gt"):
                both={key:base.total(row["original_lambda_mass"]*row["copies"][str(k)][event][key]
                                     for row in works)/denom for key in joint_fields}
                both["joint_minus_weighted_cellwise_independent_product"]=both["p_joint"]-both["incorrect_product"]
                both["product_after_mixing_rows"]=both["p_central"]*both["p_old"]
                both["reaches_diagnostic_probability_1_over_2"]=both["p_joint"]>=F(1,2)
                info[event]=both
            for field in ("payable_central_only","payable_old_only","probability_distinct_central_labels",
                          "probability_distinct_old_labels","probability_an_exact_label_repeats"):
                info[field]=base.total(row["original_lambda_mass"]*row["copies"][str(k)][field]
                                       for row in works)/denom
            pay,high=info["payable_le"],info["strict_high_compression_gt"]
            assert pay["p_joint"]+high["p_joint"]+info["payable_central_only"]+info["payable_old_only"]==1
            assert pay["joint_minus_weighted_cellwise_independent_product"]==high["joint_minus_weighted_cellwise_independent_product"]
            weighted[str(k)]=info
        trends={}
        for event in ("payable_le","strict_high_compression_gt"):
            sequence=[weighted[str(k)][event]["p_joint"] for k in KS]
            deltas=[b-a for a,b in zip(sequence,sequence[1:])]
            if min(deltas)<0<max(deltas):
                trend="nonmonotone"
            elif min(deltas)>0:
                trend="strictly increasing"
            elif max(deltas)<0:
                trend="strictly decreasing"
            else:
                trend="monotone with ties"
            trends[event]=trend
        stages[direction]=dict(actual_lambda_in_observation=denom,
                               share_of_full_original_one_arm=denom/original_sum,
                               source_profiles=works,lambda_weighted_copies=weighted,
                               observed_trend_from_k_2_4_6=trends)
    if name=="initial":
        assert all(row["copies"]["4"]["payable_le"]["discrepancy"]==0
                   for row in stages["left"]["source_profiles"])
    else:
        assert any(r["copies"]["2"]["payable_le"]["discrepancy"] for r in stages["left"]["source_profiles"])
        assert any(0<r["copies"]["6"]["payable_le"]["p_joint"]<1 for r in stages["left"]["source_profiles"])
        weighted=stages["left"]["lambda_weighted_copies"]
        assert weighted["2"]["payable_le"]["p_joint"]!=weighted["6"]["payable_le"]["p_joint"]
    assert any(0<v["payable_le"]["p_joint"]<1 for st in stages.values() for v in st["lambda_weighted_copies"].values())
    a=stages["left"]["actual_lambda_in_observation"]
    b=stages["right"]["actual_lambda_in_observation"]
    assert stages["pooled"]["actual_lambda_in_observation"]==(a+b)/2
    return dict(stage=name,physical_central_parents=T,physical_old_parents=U,
                actual_central_owners=mid,actual_old_owners=old,full_original_d=d,central_left_screen_probability=arm_exposure,
                full_oriented_residual_mass=original_sum,source_density_amplitude=amp,C=C,mu_C=mu(C),rho_C=rho,
                chosen_observation_window=observation,central_gate=tau_t,old_gate=tau_u,
                physical_receiver_strips_per_old=parts,
                actual_directional_price_screens=[(t,u,q) for (t,u),q in sorted(screen.items())],
                central_intersection_by_mask=t_ratios,old_intersection_by_mask=u_ratios,directions=stages)


def suites(base):
    T=[base.iv(0,4),base.iv("1/4","17/4"),base.iv("1/2","9/2")]
    U=[base.iv(-1,1),base.iv(3,5),base.iv("9/8","25/8")]
    old_screen={(0,0):(None,F(5,8),F(7,8),F(3,4)),
                (1,0):(F(7,8),None,F(9,16),F(11,16)),
                (2,0):(None,None,F(5,8),F(15,16))}
    chosen_rates={(0,2):(None,F(3),F(3),F(49,16)),(1,1):(None,None,F(49,16),F(3))}
    return [
      test("initial",[T[0],T[2]],[U[0],base.iv("5/2","9/2")],[F(1),F(3,4)],
           F(1,4),base.iv("1/8","17/4"),base.iv("1/2","3/4"),{(0,0):(None,F(5,8))},2,F(1),F(1),base),
      test("pressure",T,U,[F(1),F(3,4),F(1,2)],F(1,2),base.iv(0,"9/2"),base.iv(3,"25/8"),
           {**old_screen,**chosen_rates},4,F(1),F(5,4),base),
      test("expanded",T+[base.iv("3/8","27/8"),base.iv("7/8","31/8")],
           U+[base.iv("1/2",3),base.iv(2,"9/2")],[F(1),F(3,4),F(1,2),F(7,8),F(5,8)],
           F(3,4),base.iv(0,"9/2"),base.iv(3,"25/8"),
           {**old_screen,**chosen_rates,(3,0):(None,F(13,16),None,F(7,8)),(4,0):(None,None,F(15,16),None),
            (3,1):(F(3),None,F(3),None)},4,F(1),F(5,4),base)]


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--rows-dir",type=Path,default=Path(__file__).resolve().parent)
    a=p.add_mutually_exclusive_group()
    a.add_argument("--output",type=Path)
    a.add_argument("--check",type=Path)
    args=p.parse_args()
    dep=args.rows_dir/"rows798.py"
    assert sha256(dep.read_bytes()).hexdigest()==ROWS_SHA
    spec=importlib.util.spec_from_file_location("rows798",dep)
    base=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(base)
    cases=suites(base)
    obj=dict(runtime=dict(python=platform.python_version(),architecture=platform.machine()),
             precision="Fraction original geometric input and exact integer tuple multiplicities",
             dependency={"rows798.py":ROWS_SHA},command="python -B copies799.py --check copies799.json",
             experiment=dict(scope="true one-dimensional price and disjoint receiver geometry; pressure and expanded impose a stated diagnostic nonproduct first-arm screen, rather than any high-dimensional mask",
                 conditioning="each tail uses exactly one true physical price cell. Every copy independently uses the entire joint conditional (t,u) distribution",
                 one_arm="sum out the other true original arm at complete original d; left, right and their half-mixture verified",
                 normalized_gate="r=mu(C intersect all respective parents)/(rho_C Leb(C intersect those parents)); payable if and only if r<=tau; strictly high compression means r>tau. Every drawn intersection contains the true observed source cell.",
                 count_order="for lists of counts: neither payable, old only payable, central only payable, both payable",
                 lambda_average="true old arm mass on the observation window normalized separately per direction; comparison uses weighted cellwise product of marginals"),
             stages=cases)
    text=json.dumps(obj,indent=2,sort_keys=True,default=str)+"\n"
    if args.output:
        args.output.write_text(text)
    if args.check:
        assert args.check.read_text()==text
    if args.output or args.check:
        for S in cases:
            for direction,rs in S["directions"].items():
                q=rs["lambda_weighted_copies"]
                if direction=="left":
                    print(S["stage"],"left payable 2/4/6",[str(q[str(k)]["payable_le"]["p_joint"]) for k in KS],
                          "strict high 2/4/6",[str(q[str(k)]["strict_high_compression_gt"]["p_joint"]) for k in KS],
                          "payable gap k=2",q["2"]["payable_le"]["joint_minus_weighted_cellwise_independent_product"])
        if args.check:
            print("byte-identical")
    else:
        print(text,end="")


if __name__=="__main__":
    main()
