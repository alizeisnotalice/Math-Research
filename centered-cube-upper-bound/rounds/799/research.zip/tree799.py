#!/usr/bin/env python3
"""Two-arm first-common-group budgets on actual old-price and receiver pairs."""
import argparse
from collections import defaultdict
from fractions import Fraction as F
from hashlib import sha256
import importlib.util
from itertools import product
import json
from pathlib import Path
import platform


ROWS_SHA="04bbd600cd68bd2bb371559590a1902b97a345c02404ffc759a1147fb4b2bae9"
B=F(3,128)


def frames(order,left_heavy):
    children={}

    def build(node):
        if len(node)==1:
            children[node]=()
            return
        middle=(len(node)+int(left_heavy))//2
        pair=node[:middle],node[middle:]
        children[node]=pair
        for branch in pair:
            build(branch)

    order=tuple(order)
    build(order)
    return order,children


def first_common(u,g,children):
    options=[node for node in children if u in node and g in node]
    node=min(options,key=len)
    assert not any(u in child and g in child for child in children[node])
    return node


def grab(density,cap,marks,xis,smalls,base):
    """Real old-value / own-receiver price atoms, ranked by true side density."""
    xi_used=F(0)
    chosen={}
    fractions=None
    for k in sorted(density,key=lambda i:(-density[i],
                                          abs(base.point(marks[i]["price"])-base.point(smalls[marks[i]["old"]]))
                                          /base.length(smalls[marks[i]["old"]]),i)):
        if xi_used==cap:
            break
        if not density[k]:
            continue
        credit=min(xis[k],cap-xi_used)
        portion=credit/xis[k]
        chosen[k]=portion
        xi_used+=credit
        if portion<1:
            lo,hi=marks[k]["receiver"]
            U=(lo,lo+(hi-lo)*portion)
            assert base.length(U)/base.length(marks[k]["receiver"])*xis[k]==credit
            fractions=dict(atom=k,fraction=portion,actual_prefix_U=U,xi=credit)
    assert 0<=xi_used<=cap
    assert base.total(xis[k]*s for k,s in chosen.items())==xi_used
    return chosen,xi_used,fractions


def actual_two_arms(T,U,shares,parts,screen,amp,base):
    Towner=[base.owner(A,s) for A,s in zip(T,shares)]
    Uowner=[base.owner(A,F(1)) for A in U]
    owners=sorted(Towner+Uowner)
    assert all(x[1]<y[0] for x,y in zip(owners,owners[1:]))
    m=[base.length(A) for A in T]
    small=[base.length(A) for A in U]
    assert all(F(2)<=w<F(4) for w in small)
    measure=lambda q:base.real_mass(q,amp)
    assert [measure(A) for A in T+U]==m+small
    vol_t=list(map(base.length,Towner))
    vol_u=list(map(base.length,Uowner))
    ends=sorted({*base.SOURCE,*(p for b in T+U for p in b),
                 *(x for a in screen.values() for x in a if x is not None)})
    prices=list(zip(ends,ends[1:]))
    true_mu=list(map(measure,prices))
    assert min(true_mu)>0

    marks=[]
    for u,parent in enumerate(U):
        E=Uowner[u]
        step=vol_u[u]/parts
        for k in range(parts):
            own=(E[0]+k*step,E[0]+(k+1)*step)
            for a,p in enumerate(prices):
                if base.inside(p,parent):
                    # j_u=|E_u| in this fixture.
                    xi=vol_u[u]*true_mu[a]*step/(small[u]*vol_u[u])
                    marks.append(dict(old=u,receiver_strip=k,price_atom=a,price=p,receiver=own,xi=xi))
    xis=[a["xi"] for a in marks]
    assert base.total(xis)==base.total(vol_u)

    edges={}
    for t,u in product(range(len(T)),range(len(U))):
        I=base.clip(T[t],U[u])
        w=measure(I)
        if small[u]<m[t] and w:
            edges[t,u]=(I,w,w/(m[t]*small[u]))
    degrees=[base.total(vol_u[u]*e[2] for (t,u),e in edges.items() if t==i)
             for i in range(len(T))]
    law=[]
    admitted=[]
    full=[]
    for t in range(len(T)):
        p,keep={},set()
        for j,c in enumerate(marks):
            u=c["old"]
            if (t,u) not in edges or not base.inside(c["price"],T[t]):
                continue
            I,mass,K=edges[t,u]
            p[j]=vol_u[u]*K/degrees[t]*true_mu[c["price_atom"]]/mass*base.length(c["receiver"])/vol_u[u]
            assert p[j]==xis[j]/(m[t]*degrees[t])
            endpoint=screen.get((t,u),(None,)*parts)[c["receiver_strip"]]
            if endpoint is None or c["price"][1]<=endpoint:
                keep.add(j)
        assert base.total(p.values())==1 and keep
        law.append(p)
        admitted.append(keep)
        Q=vol_t[t]*degrees[t]
        pairs=[(i,j,Q*p[i]*p[j]) for i,j in product(sorted(keep),sorted(p))]
        assert base.total(v for i,j,v in pairs)==Q*base.total(p[i] for i in keep)
        full.append(pairs)
    data=dict(centers=T,old_parents=U,central_owners=Towner,old_owners=Uowner,true_m=m,
              true_old_m=small,old_d=degrees,physical_octave=[F(2),F(4)],
              first_arm_directional_screen=[(t,u,cuts) for (t,u),cuts in sorted(screen.items())],
              price_restricted_xi_by_central_and_little=[
                  [vol_u[u]*edges[t,u][1]/small[u] if (t,u) in edges else F(0)
                   for u in range(len(U))] for t in range(len(T))],
              marked_original_total=base.total(v for pairs in full for i,j,v in pairs),
              original_before_first_arm_screen=base.total(v*d for v,d in zip(vol_t,degrees)))
    return data,marks,xis,law,admitted,full,vol_t,vol_u


def tree_budget(T,U,the_order,left_heavy,data,marks,xis,law,admitted,full,vol_t,vol_u,base):
    root,children=frames(the_order,left_heavy)
    lca={(u,g):first_common(u,g,children) for u,g in product(root,repeat=2)}
    root_covered=F(0)
    local_covered=F(0)
    root_unrestricted_covered=F(0)
    local_unrestricted_covered=F(0)
    changes_distinct=F(0)
    global_rank=F(0)
    local_rank=F(0)
    root_rank_cost=[F(0),F(0)]
    local_rank_cost=[F(0),F(0)]
    physical_union_across_t=[{},{}]
    node_stats=[]
    per_central_union=[]
    example=None
    for t in range(len(T)):
        mt,dt=data["true_m"][t],data["old_d"][t]
        cap=B*mt
        factor=vol_t[t]/(mt*mt*dt)
        q_by={C:[] for C in children}
        for i,j,w in full[t]:
            C=lca[marks[i]["old"],marks[j]["old"]]
            q_by[C].append((i,j,w))
        law_by_group={C:[j for j in law[t] if marks[j]["old"] in C] for C in children}
        true_load={C:base.total(xis[j] for j in inds) for C,inds in law_by_group.items()}
        assert true_load[root]==mt*dt
        assert all(v==base.total(data["price_restricted_xi_by_central_and_little"][t][u] for u in C)
                   for C,v in true_load.items())
        broad={C:base.total(vol_u[u] for u in C) for C in children}
        assert all(true_load[C]<=broad[C] for C in children)

        def integration(C,left,right,cover_full_group=False):
            def on(V,side,possible):
                return base.total(xis[j]*side.get(j,F(0)) for j in law_by_group[V] if j in possible)

            if cover_full_group or not children[C]:
                return factor*on(C,left,admitted[t])*on(C,right,law[t])
            lo,hi=children[C]
            return factor*(on(lo,left,admitted[t])*on(hi,right,law[t])+
                           on(hi,left,admitted[t])*on(lo,right,law[t]))

        def orders(records):
            # The exact two marginals of this set of original LCA records.
            out=[defaultdict(F),defaultdict(F)]
            for i,j,w in records:
                out[0][i]+=w/xis[i]
                out[1][j]+=w/xis[j]
            return [grab(x,cap,marks,xis,U,base) for x in out]

        def ranked_integral(records,left,right):
            return base.total(w*left.get(i,F(0))*right.get(j,F(0)) for i,j,w in records)

        old_t=base.total(w for i,j,w in full[t])
        if true_load[root]<=cap:
            root_covered+=old_t
        if broad[root]<=cap:
            root_unrestricted_covered+=old_t
        choice_root=orders(full[t])
        root_hit=ranked_integral(full[t],choice_root[0][0],choice_root[1][0])
        assert root_hit==integration(root,choice_root[0][0],choice_root[1][0],True)
        global_rank+=root_hit
        for s in range(2):
            root_rank_cost[s]+=choice_root[s][1]
        current_union=[{},{}]
        for C,records in q_by.items():
            q=base.total(w for i,j,w in records)
            left={i:F(1) for i in admitted[t]}
            right={j:F(1) for j in law[t]}
            assert q==integration(C,left,right)
            if true_load[C]<=cap:
                local_covered+=q
                if true_load[root]>cap:
                    distinct=base.total(w for i,j,w in records if marks[i]["old"]!=marks[j]["old"])
                    changes_distinct+=distinct
                    if distinct and example is None:
                        example=dict(terminal=t,LCA=C,first_common_true_xi_weight=true_load[C],
                                     whole_octave_true_xi_weight=true_load[root],threshold=cap,
                                     additional_distinct_true_flow=distinct)
            if broad[C]<=cap:
                local_unrestricted_covered+=q
            if not q:
                continue
            selection=orders(records)
            left,right=selection[0][0],selection[1][0]
            score=ranked_integral(records,left,right)
            assert 0<=score==integration(C,left,right)<=q
            if true_load[C]<=cap:
                assert score==q
            local_rank+=score
            for s in range(2):
                chosen,used,fraction=selection[s]
                local_rank_cost[s]+=used
                for j,v in chosen.items():
                    current_union[s][j]=max(current_union[s].get(j,F(0)),v)
                    physical_union_across_t[s][j]=max(physical_union_across_t[s].get(j,F(0)),v)
            node_stats.append(dict(t=t,node=C,original_LCA_mass=q,xi_t_old_price_restricted=true_load[C],
                                    all_reference_group_xi=broad[C],group_cap=cap,ranked_both_mass=score,
                                    actual_reference_cost_left_right=[x[1] for x in selection],
                                    partial_physical_choices=[x[2] for x in selection]))
        this_central=[x for x in node_stats if x["t"]==t]
        assert base.total(x["original_LCA_mass"] for x in this_central)==old_t
        own_union=[base.total(xis[j]*v for j,v in chosen.items()) for chosen in current_union]
        own_sum=[base.total(x["actual_reference_cost_left_right"][s] for x in this_central)
                 for s in range(2)]
        assert all(u<=v for u,v in zip(own_union,own_sum))
        per_central_union.append(dict(central=t,cap=cap,root_rank_reference_charge=[x[1] for x in choice_root],
                                      local_sum=own_sum,local_physical_union=own_union))

    union_mass=[base.total(xis[j]*s for j,s in v.items()) for v in physical_union_across_t]
    assert all(u<=v for u,v in zip(union_mass,local_rank_cost))
    assert 0<=root_covered<=local_covered<=local_rank<=data["marked_original_total"]
    assert 0<=root_unrestricted_covered<=local_unrestricted_covered<=local_covered
    assert root_covered<=global_rank<=data["marked_original_total"]
    return dict(root=root,node_children=[(C,branches) for C,branches in children.items()],
                whole_group_accepts=root_covered,first_common_group_accepts=local_covered,
                unclipped_reference_whole_group_accepts=root_unrestricted_covered,
                unclipped_reference_first_common_group_accepts=local_unrestricted_covered,
                first_common_distinct_gain=changes_distinct,strict_distinct_gain_example=example,
                original_both_sides_rank_once_per_t=global_rank,
                both_sides_rank_separately_by_first_common_group=local_rank,
                per_t_root_charged_reference_sum=root_rank_cost,
                total_node_reference_charges=local_rank_cost,actual_reference_union=union_mass,
                per_central_reference_occupancy=per_central_union,
                rank_profiles=node_stats)


def case(name,T,U,shares,parts,screen,amp,base):
    d,*linked=actual_two_arms(T,U,shares,parts,screen,amp,base)
    center_order=sorted(range(len(U)),key=lambda i:base.point(U[i]))
    volume_order=sorted(range(len(U)),key=lambda i:(base.length(U[i]),base.point(U[i])))
    center=tree_budget(T,U,center_order,True,d,*linked,base)
    volume=tree_budget(T,U,volume_order,False,d,*linked,base)
    if name=="pressure":
        assert center["first_common_distinct_gain"]>0
        probe=center["strict_distinct_gain_example"]
        assert probe["terminal"]==0 and probe["first_common_true_xi_weight"]==F(3,32)
        assert probe["whole_octave_true_xi_weight"]==F(1,8)
    if name=="expanded":
        assert len(set(d["true_old_m"]))>1 and len(set(d["true_m"]))>1
        assert center["first_common_group_accepts"]!=volume["first_common_group_accepts"]
    return dict(stage=name,amplitude=amp,shared_case=d,
                center_splits=center,volume_splits=volume)


def suite(base):
    T=[base.iv(0,4),base.iv("1/4","17/4"),base.iv("1/2","9/2")]
    U=[base.iv(-1,1),base.iv(3,5),base.iv("9/8","25/8")]
    screen={(0,0):(None,F(5,8),F(7,8),F(3,4)),
            (1,0):(F(7,8),None,F(9,16),F(11,16)),
            (2,0):(None,None,F(5,8),F(15,16))}
    return [
        case("initial",[T[0],T[2]],[U[0],base.iv("5/2","9/2")],[F(1),F(3,4)],2,
             {(0,0):(None,F(5,8))},F(1,4),base),
        case("pressure",T,U,[F(1),F(3,4),F(1,2)],4,screen,F(1,2),base),
        case("expanded",T+[base.iv("3/8","27/8"),base.iv("7/8","31/8")],
             U+[base.iv("1/2",3),base.iv(2,"9/2")],[F(1),F(3,4),F(1,2),F(7,8),F(5,8)],4,
             {**screen,(3,0):(None,F(13,16),None,F(7,8)),(4,0):(None,None,F(15,16),None)},F(3,4),base),
    ]


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--rows-dir",type=Path,default=Path(__file__).resolve().parent)
    a=p.add_mutually_exclusive_group()
    a.add_argument("--output",type=Path)
    a.add_argument("--check",type=Path)
    args=p.parse_args()
    rows=args.rows_dir/"rows798.py"
    assert sha256(rows.read_bytes()).hexdigest()==ROWS_SHA
    spec=importlib.util.spec_from_file_location("rows798",rows)
    base=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(base)
    stages=suite(base)
    result=dict(runtime=dict(python=platform.python_version(),architecture=platform.machine()),
                precision="standard library Fraction; both orders independently exact",
                dependency={"rows798.py":ROWS_SHA},
                command="python -B tree799.py --check tree799.json",
                diagnostic=dict(B=B,scope="one-dimensional true parents, true full two-arm original degree and disjoint owners, finite direction screen; no high-dimensional hard gates",
                                absolute_old_size="2<=old lengths<4",
                                center_tree="median consecutive old centers, extra leaf goes left",
                                volume_tree="median consecutive (true old length, center), extra leaf goes right",
                                group_cost="true partial old-price/owner reference mass restricted to the physical middle father; whole unrestricted reference also recorded",
                                sort="each LCA and side by its true original selected-pair marginal density relative to paired xi, with physical old-center distance breaks; split own receiver in final atom",
                                budget="each fixed t and tested node uses at most B*m_t on each side; no claim their cumulative sums meet one such cap",
                                union="all selected physical receiver prefixes start at their own lower endpoints; union across labels/nodes uses the maximum actual fraction per paired atom"),
                stages=stages)
    out=json.dumps(result,indent=2,sort_keys=True,default=str)+"\n"
    if args.output:
        args.output.write_text(out)
    if args.check:
        assert args.check.read_text()==out
    if args.output or args.check:
        for row in stages:
            s=row["center_splits"]
            print(row["stage"],"whole",s["whole_group_accepts"],"LCA",s["first_common_group_accepts"],
                  "distinct",s["first_common_distinct_gain"],
                  "rank once/local",s["original_both_sides_rank_once_per_t"],
                  s["both_sides_rank_separately_by_first_common_group"],
                  "other tree LCA",row["volume_splits"]["first_common_group_accepts"])
        if args.check:
            print("byte-identical")
    else:
        print(out,end="")


if __name__=="__main__":
    main()
