# R245：原平方项的 terminal-test 重写与最短未付量

本轮对 R244 JB5 的实际后验平方项作了直接检验。high 与 FIRST 确能消去其中的绝对 terminal 逆权，得到下面 JS2 的准确测试测度公式；但归一化只控制 terminal posterior 下的平均，不能控制同一公式中测试核加权的平均。当前没有证明新的原交通根阶预算，也没有增加已付来源门。以下保留实际 receiver、全部原来源及 full posterior，给出可以直接继续检查的最短缺口。

## JS1. 固定的原行与实际定义

窄读 R117 `joint_geometry.md` JG1–11，以及 R128 `proof.md:489–523` 的 JT128-1/2。固定原 ω,V,j,x,y,hard z 和完整 history，记

\[
 p=P_{s(x),L(x)}(x-y),\quad g=\sqrt{LR},\quad
 Q(v)=Q_x^*(v),\quad S=Z_g,
\]
\[
 e_t=\int_{Z_t}w_t\,d\nu,\qquad
 \Pi_t=1_{Z_t}w_t\nu/e_t,\qquad \pi=\Pi_g.
\]

仅在原有效 clock 与 e_t>0 上使用公式；空行先置零。原有限路径 Z_t 随 t 递减，故 t≤g 时 S⊂Z_t。full e_t 不限制到 S，也不限制到 good 或任何来源子集。

原 high 为 pe_g≥2Kq，FIRST 为 ∫Qν≤q。令

\[
 G=\{v\in S:pw_g(v)\le KQ(v)\},\qquad B=S\setminus G.
\]

等号按原 good/bad 约定归 good。于是

\[
 \pi(G)\le\frac{K}{pe_g}\int_GQ\,d\nu\le\frac12. \tag{JS1.1}
\]

这只限制终端 good 质量，未声称早时刻 Π_t(G)≤1/2。辅助 good v、bad u 与外层 hard z 仍是不同来源槽。ν≤β≤f、来源对门、真实 dx、种子和唯一物理分区均不改变。

## JS2. 平方项的准确归一化：high 真正消去什么

令 T(v)≥0 是在整条辅助 clock 上固定的实际测试核，满足

\[
 \int T\,d\nu\le q.
\]

可取原 Q；对 R244 的某一个节点测试 T_i，仅在该节点实际 FIRST 已认证的范围使用，不能为 backward-soft 菜单免费添加这个假设。定义终端上测试子测度与归一化密度比

\[
 \sigma_T(dv)=1_S(v)T(v)\nu(dv)/q,\qquad
 R_t(v)=\frac{e_gw_t(v)}{e_tw_g(v)}\quad(v\in S).
\]

w_g>0，且

\[
 \Pi_t|_S=R_t\pi,\qquad \int_SR_t\,d\pi=\Pi_t(S)\le1,
 \qquad \sigma_T(S)\le1. \tag{JS2.1}
\]

对任意非负可测 ψ_t(v)，包括保留原 u 槽及所有原正门后得到的函数，有准确恒等式

\[
 \boxed{
 P\int_S\psi_t(v)\frac{T(v)}{w_g(v)}\Pi_t(dv)
 =\frac{Pq}{e_g}\int_S\psi_t(v)R_t(v)\sigma_T(dv)
 \le\frac{Pp}{2K}\int_S\psi_tR_t\,d\sigma_T .}
 \tag{JS2.2}
\]

P≥0 可以是节点输入核 P_i(x−y)；只有未移动的输入核才取 P=p。证明是把两边展开为 P/e_t∫ψ_t T w_t/w_g ν，最后一步仅用实际 high。q、e_g 和 p 均属于这个固定 receiver 行，未把依 y 的分母移到 β 积分外。

若平方项使用节点终端 w_{g_i^*}，且已认证 physical upward cover 给 g≤g_i^*≤γ²g，则逐坐标

\[
 1\le w_g/w_{g_i^*}\le(g_i^*/g)^n\le\gamma^{2n}\le e^2.
\]

因此其准确重写是在 JS2.2 的 σ_T 积分内多保因子 w_g/w_{g_i^*}，或者付明确的 e²。它不是另一次免费的 physical cover；若母式已有包含此比较的 e⁴ 统一费用，不再重复乘 e²。R244 的空间权 w_i^{-1}、真实 Ω_i 和 dx 在以上逐点式之外原样保留。节点输入 P_i 不能借 high 擅自改成 p，故右端是 P_i p/(2K)，不是 P_i²/(2K)。

对原正交通，可准确取

\[
 \psi_t(v)=1_G(v)\int_B
 \kappa_t(u,v)[k_t(v)-k_t(u)]_+\Pi_t(du),\qquad0\le\kappa_t\le1, \tag{JS2.3}
\]

其中 κ_t 保 Ψ、capture、FA、未付指示及实际 J_far 门；依 hard z 的门也可在这条固定行内保留。JS2.2 对此 ψ_t 同样成立。因而它没有改动两份 Π，也没有将 hard z 解释为后验来源。

## JS3. 为什么测试容量和 posterior 归一化尚不能闭合

JS2.1 的两个“质量≤1”是不同测度下的陈述。二者相乘不能推出

\[
 \int R_t\,d\sigma_T\le1.
\]

这里不以自由模型反例作研究结果；直接写出两测度的准确关系即可定位缺口：

\[
 A_T(v)=\frac{d\sigma_T}{d\pi}(v)
       =\frac{e_gT(v)}{q w_g(v)},\qquad
 \int R_t\,d\sigma_T=\int A_TR_t\,d\pi. \tag{JS3.1}
\]

原 terminal-good 对 T=Q 给 A_Q≥pe_g/(Kq) 在 G 上的**下界**，不能提供所需的上界。heavy 给 e_t 的正下界，却不直接控制 A_T；它不把 w_g 逐源抬高，也不将完整 e_t 替换为 good 子集质量。

保留 G 后，若相应平方矩有限，令 A=1_G A_T，则有准确中心化分解和 Cauchy 界

\[
 \int_G R_t\,d\sigma_T
 =\sigma_T(G)\Pi_t(S)+\operatorname{Cov}_{\pi}(A,R_t)
 \le1+\sqrt{\operatorname{Var}_{\pi}(A)
                    \operatorname{Var}_{\pi}(R_t)}. \tag{JS3.2}
\]

若平方矩无限，只保非负截断及其极限，不能宣称右端有限。这不是新增付款：把 JS3.2 代回 half-good 的平方后，原 √K 外因子会抵消 high 贡献的 K^{-1/2}，常数部分仍只回到原 p 型预算，不能自动变成 εX；协方差部分更没有原 source 平方预算。保留 ψ_t 时还需同一个实际测试密度对原 positive score 的加权，而不是只检查裸 Var(k_t)。

因此最短待证量是 JS2.2–3 中的

\[
 \int_{J_{far}}\!\int_G R_t(v)
 \left[\int_B\kappa_t(u,v)(k_t(v)-k_t(u))_+\Pi_t(du)\right]
 \sigma_{T_i}(dv)\,\frac{dt}{t}, \tag{JS3.3}
\]

按原 P_i(x−y)p(x,y)/(2K w_i)、Ω_i dx、β(dy)、hard ν(dz) 和所有外资料联合积分。它的来源、归一化及测试核全部明确。仅用 k≤n 或 ∫R_tπ≤1 会放掉恰好需要的 test/score/receiver 关联；本轮没有证明 JS3.3 的 εX+根阶来源价。该式是原平方路线的具体未付步骤，不把给它另命名视为进展。

## JS4. 原 signed 势的检查：Ψ 不能消失

用 D_t(v,u)=k_t(v)−k_t(u)。在原 G×B 上逐点有

\[
 \Psi D_t=D_t-(1-\Psi)D_t
 \le D_t+(1-\Psi)D_t^- . \tag{JS4.1}
\]

正门 κ_pos≤1 只给 Ψ(κ_pos D_t^+−D_t^−)≤ΨD_t；所以即使合法保留同一原 N_{\mathcal Z^c}，转向完整 cut 导数也仍留下明确的反向项

\[
 \int_{J_{far}}\int_{G\times B}
 (1-\Psi_r(u,v))(k_t(u)-k_t(v))_+
 \Pi_t(dv)\Pi_t(du)\,\frac{dt}{t}. \tag{JS4.2}
\]

它要乘同一原 p h_R a_ω/q、真实 dx 与 βν 来源，不能取成常数。当前 Ψ 是原来源对后缀补域，不是一个可分解的 good/bad 单槽指示；R128 JT128-2 明确已消费的 N_\mathcal Z 不返回。JS4.2 正是删除 Ψ 后必须恢复的那部分费用，不能拿过去负项再次抵消。连续 cut 导数之外，未来删除与原 endpoint 资格仍按母账保留。本节仅检查这条尝试为什么没有给新付款，不重新登记 R223 的 signed 恒等式为成果。

## JS5. 本机有限代数检查与结论

本机 Python 实跑 15 项检查，参数完全列于此以便重放：n=3，来源质量 (1,2,1,.5)，四条坐标阈值分别 (.7,.9,1.1)、(1.3,1.5,2.4)、(2,2.2,2.4)、(.8,1.4,2)；w_t=∏min(1,A_i/t)，g=1.8，第四源在 t=1.4 删除，其余三源为 S。取 T=(.8,.05,.1,0)，q=∫Tν=1，K=2，p=4Kq/e_g，在 t=1,1.2,1.4,1.6,1.8 分别检查 JS2.2 的等式、∫R_tπ≤1、JS3.2 的 Cauchy 不等式。实际输出 e_g=2.322530864197531，G={第一源}，π(G)=.05116279069767442，等式最大浮点差4.440892098500626e−16。它们只是归一化和删除方向的有限代数检查；阈值未认证来自真实 C 核，不是 FULL 实例、反例或渐近证据。严格结论是 JS2 的直接恒等式与不等式。

本轮没有证明一般中间硬层的根阶预算。确切收获限于：在原 high 和目标 FIRST 资格下，平方逆权被改写为同一完整 posterior 的 terminal-test 加权变形；所需新几何必须直接支付 JS3.3，或在原 signed 路线支付 JS4.2 的实际后缀反向交互。没有免费 source L²、没有改变 Π、没有重复负信用，也没有把新的未知矩当成闭合。只修改本责任文件，到此有界停止。
