# R245 finite-clock numerical notes

Final actual scope:20 finite correlated-source clocks, three stages4/10/6;20 exact energy identities,63 exact positive-posterior midpoint pair inequalities,66 interval records including3 explicit empty-source branches, and17 applicable normalized mean identities. All cases actually completed. Only the three owned numerical files were edited.

## Exact clock and event accounting

Each nonempty source has positive rational nu mass and a positive rational threshold multiset of total dimensionn. Its true weight is product min(1,A/t), with threshold multiplicities retained. The finite atomic nu is arbitrary on these threshold vectors; its coordinates/posterior are not assumed to factorize. Source deletion times give an actual decreasing survivor set. These are kernel-clock algebra models, not continuous L1/FULL/source-geometry/history examples; no claim is made that their A thresholds arise from the original geometric C kernel or that they satisfy original heavy/born conditions.

All continuous intervals are split at every threshold and deletion time. On each interval the surviving sources and integer scoresk are fixed, w=c t^-k, and the exact energy integral is sum_v k_v[nu_v w_v(lo)-nu_v w_v(hi)]. This is elementary Fraction arithmetic, not numerical quadrature. Threshold births at a simultaneous deletion are charged to the OLD live measure first, then the post-birth deleted score mass is removed. Events at tau have already been applied in the initial measure/score and are not charged again. A closedT includes endpoint births/deletion; an openT uses its internal left limit and excludes those events.

The script independently checks, exactly,

    energy = Q_tau + weighted_births - Q_terminal - deleted_score_mass,
    Q_tau + weighted_births <= n e_tau,
    energy <= n e_tau.

Here Q=e times posterior mean score, equivalently integral k w dnu. The terminal and deleted terms are nonnegative; arbitrary deletion compensation is not treated as negative traffic credit. The event records retain deleted posterior fractions and signed normalized mean jumps. Where the post-deletion measure remains nonempty, the exact jump is d(m_keep-m_removed) and its absolute boundn d is checked.

The unweighted continuous variance integral is separately available as the sum of rational endpoint mean differences on each no-event interval. When initial, terminal and intermediate normalized measures exist, its complete birth/terminal/deletion mean identity is checked with Fractions. This applies to17 cases, including the no-evolution zero-length conventions. Where all sources are deleted or the initial measure is empty, no posterior is invented: empty intervals have continuous cost0 and the normalized identity is not asserted. Their unnormalized energy identity remains valid. T<=tau is an explicitly empty no-evolution window, with effective terminal equal to tau; its Q_terminal/e_terminal fields refer to that effective endpoint, not to backward evolution to the nominalT.

## Executed three-stage menu

Initial4: heterogeneous n2 three sources; n4 four sources without deletion; the same n4 sources with two deletions; n4 simultaneous coordinate births and deletion with multiplicities. The two four-source baselines reuse the supplied score_flux data as inputs to NEW Fraction accounting and refined integration; the old embedded factor-grid30+15 diagnostic scripts were not run or copied as another claimed dataset.

Pressure10: deletion/threshold already applied at tau; closedT event; openT event; all sources deleted midway; single nonzero-score source; single zero-score source; empty source measure; singleton window; empty reversed-endpoint window interpreted as no evolution; all sources already deleted at tau. These retain endpoint/equality/normalizer branches rather than silently removing difficult cases.

Expanded6: n16 with four genuinely different threshold patterns, source masses from1e-4 to1e4 and tau=.5,T4; n128 mixed source scores/deletion; n512 multiple births/deletions; n1024 thresholds within1/n of the initial endpoint and a narrow window to1.25; n64 equal-score sources with deletion; common mass scaling1e8 of the initial heterogeneous case. Every exact threshold, multiplicity,mass, deletion and endpoint is declared in JSON. The n16 window has T/tau8 and tests the general sqrt(log(T/tau)) form only; it is not asserted to be an original window with ratio<=2. No asymptotic order is inferred from these dimensions.

## Actual full-posterior quadrature and the TV metric

At each time all surviving source weights from the SAME finite nu are normalized together. Variance is computed through positive unordered pair terms sum_{i>j}pi_i pi_j(ki-kj)^2, avoiding cancellation of E k^2-(E k)^2. The full positive pair score is Jall=sum_{i>j}pi_i pi_j|ki-kj|, exactly the ordered positive-part product-posterior sum. Every interval with positive midpoint degree checks2 Jall^2<=Var using Fractions. There are63 such actual checks; the other3 interval records are empty and are NOT counted as full-posterior checks. Maximum sampled2Jall^2/Var is approximately.58218822794, with zero-variance ratios explicitly0.

TV density is the original v=E|k-m|/2, not a different pair metric. Numerically it is evaluated as the maximum positive score-cut flow. For a cut ell, sum_{ki>ell,kj<=ell}pi_i pi_j(ki-kj)=sum_{ki>ell}pi_i(ki-m); its maximum is attained by a cut at the mean and equals E|k-m|/2. This positive formula avoids losing half the variation when the mean rounds to a dominant score. It does not replaceTV byJall. The two metrics are stored separately.

Logtime quadrature splits at every event, at deterministic endpoint distances1/n,4/n,16/n,64/n, and at any interior score-mean crossing. The40dps run uses extra uniform thirds; the70dps run refines to fifths and solves crossings to higher precision. A complex-valued variance integral simultaneously accumulates unweightedVar and(e/e_tau)Var. A second complex-valued integral simultaneously accumulates sqrt(e/e_tau)v and sqrt(e/e_tau)Jall using the same full posterior evaluation; no separate large pair-flux parameter search was added.

The resulting checks are

    integral (e/e_tau) Var <= exact_energy/e_tau <= n,
    integral sqrt(e/e_tau) v <= sqrt(n log(T/tau))/2,
    integral sqrt(e/e_tau) Jall <= sqrt(n log(T/tau)/2).

All pass. The maximum weightedTV/root ratio is.1600570587279663; the maximum fullpair/root ratio is.1131774316033185. The refined variance quadrature differs from the independent exact Fraction endpoint value by at most1.85460307534371e-68. Maximum observed40/70 relative precision change across the four integrated metrics is4.41368540731271e-40. Values are displayed to50digits to preserve actual40dps rounding; extra displayed digits do not mean50 correct digits. Ordinary multiprecision/refinement is not an interval error certificate.

The TV/score-pair integrals here are CONTINUOUS clock variation. Actual posterior deletion jumps are recorded separately and are not paid by these root estimates. In particular equal-score sources can have zero continuous score variation while their source posterior still changes at a deletion. The original SF5 born/deletion budget is not certified by these arbitrary deletion models. Fullpair domination can bound arbitrary nonnegative masks at most1 algebraically, but no original G/B/capture/history geometry is certified here. Removing sqrt(e/e_tau), or controlling the resulting reciprocal-degree source cost, remains unproved by this computation.

## Exact certificate representation

Energy/event/endpoint/variance values are Fractions. Integers beyond900bits are saved as sign,bit lengths and SHA256 of numerator/denominator together with an ordinary decimal approximation, keeping the JSON bounded. Replay reconstructs all exact integers from declared sources and reasserts exact zero residual, rather than trusting that approximation. Smaller rational values are stored literally. These are finite exact clock certificates, not a finite proof of the general theorem.

## Reproduction and dependencies

Actual runtime: existing bundled Python3.12.14 and vendor mpmath1.3.0; no NumPy/install/Git action. Run from an extracted package directory containing numeric_checks.py and task_contract.md (or the eventual frozen checkpoint):

```sh
PYTHONPATH=/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor \
/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 \
numeric_checks.py \
--output /tmp/r245_numeric_replay.json \
--contract task_contract.md
```

CLI --output/--contract accepts relocated paths. Script and contract content hashes bind JSON; timestamps,runtime and output-path strings do not enter it. The formal20-case calculation was rerun after the midpoint count correction and contract binding. The completed separate-output replay was byte-identical and took10.72s wall/10.65s user/.06s system. The parent owns the final independent migrated-package replay.

## Frozen content binding

JSON size 163140 bytes. SHA256 source `80803b7f52877f5bcb6a80777df678f88062be5321f1b8dbf9355c5bb043554f`; JSON `90ed5af4d7d2a310b27af2b79f5d3d3691dbdf5db4745ac1536a8a9da32a008a`; contract `47fdaefae69c4874f7bbe5219e0c049894ae2a5ab71dee80439040962f693d3d`. Final counts and reported precision values are from the completed formal post-correction run; no further cases or timing runs are needed.
