#!/usr/bin/env python3
"""Exact finite correlated clocks and ordinary weighted-path integration."""
import argparse,hashlib,json
from fractions import Fraction as F
from pathlib import Path
import mpmath as mp
ROOT=Path(__file__).resolve().parent

def mf(v):return mp.mpf(v.numerator)/v.denominator if isinstance(v,F) else mp.mpf(v)
def enc(v):return mp.nstr(v,50)
def fracsave(v):
 v=F(v)
 if max(v.numerator.bit_length(),v.denominator.bit_length())<=900:return str(v)
 def digest(k):return hashlib.sha256(abs(k).to_bytes((abs(k).bit_length()+7)//8 or 1,'big')).hexdigest()
 with mp.workdps(70):approx=enc(mf(v))
 return dict(sign=1 if v>0 else -1 if v<0 else 0,numerator_bits=abs(v.numerator).bit_length(),denominator_bits=v.denominator.bit_length(),numerator_sha256=digest(v.numerator),denominator_sha256=digest(v.denominator),decimal_approx=approx,scope='Exact Fraction reconstructed and checked on replay; large integers saved by sign/bits/content hashes.')
def source(mass,groups,death=None):return dict(mass=F(mass),groups=[(F(a),int(k)) for a,k in groups],death=F(death) if death is not None else None)
def weight(v,t):
 w=F(1)
 for a,k in v['groups']:w*=min(F(1),a/t)**k
 return w
def score(v,t,strict=False):return sum(k for a,k in v['groups'] if a<t or (not strict and a==t))
def live(v,t,before=False):return v['death'] is None or v['death']>t or (before and v['death']==t)
def endpoint(c,t,before=False,strict=False):
 active=[j for j,v in enumerate(c['sources']) if live(v,t,before)];m=[c['sources'][j]['mass']*weight(c['sources'][j],t) for j in active];ks=[score(c['sources'][j],t,strict) for j in active];e=sum(m,F(0));Q=sum((u*k for u,k in zip(m,ks)),F(0));return active,e,Q

def exact(c):
 n=c['n'];tau=c['tau'];T=c['T'];empty=T<=tau;end=tau if empty else T;openT=c.get('open_T',False) and not empty;src=c['sources'];initial,etau,Q0=endpoint(c,tau);terminal,eT,QT=endpoint(c,end,before=openT,strict=openT);events=sorted(set([a for v in src for a,k in v['groups'] if tau<a<end or (a==end and tau<a and not openT)]+[v['death'] for v in src if v['death'] is not None and (tau<v['death']<end or (v['death']==end and tau<v['death'] and not openT))]));grid=sorted(set([tau,end]+events));birth=F(0);deleted=F(0);birthnorm=F(0);deljump=F(0);eventrows=[];allpositive=etau>0 and eT>0
 for t in events:
  old=[j for j,v in enumerate(src) if live(v,t,True)];kept=[j for j in old if live(src[j],t)];removed=[j for j in old if j not in kept];m={j:src[j]['mass']*weight(src[j],t) for j in old};e=sum(m.values(),F(0));num=sum((m[j]*sum(k for a,k in src[j]['groups'] if a==t) for j in old),F(0));removedQ=sum((m[j]*score(src[j],t) for j in removed),F(0));birth+=num;deleted+=removedQ
  jump=None
  if e:
   birthnorm+=num/e
   if removed:
    ek=sum((m[j] for j in kept),F(0));er=e-ek
    if ek:
     mkeep=sum((m[j]*score(src[j],t) for j in kept),F(0))/ek;mremove=removedQ/er;mpre=sum((m[j]*score(src[j],t) for j in old),F(0))/e;jump=mkeep-mpre;assert jump==er/e*(mkeep-mremove) and abs(jump)<=n*er/e;deljump+=jump
    else:allpositive=False
  eventrows.append(dict(t=str(t),birth_mass=fracsave(num),deleted_score_mass=fracsave(removedQ),deleted_sources=removed,normalized_delete_mean_jump=fracsave(jump) if jump is not None else None,removed_posterior_fraction=fracsave(sum((m[j] for j in removed),F(0))/e) if e else None,empty_after_deletion=bool(old and not kept),birth_before_deletion=True))
 energy=F(0);variance=F(0);intervals=[];maxpair=F(0)
 for lo,hi in zip(grid,grid[1:]):
  if lo==hi:continue
  mid=(lo+hi)/2;active=[j for j,v in enumerate(src) if live(v,mid)];ks=[score(src[j],mid) for j in active];ml=[src[j]['mass']*weight(src[j],lo) for j in active];mh=[src[j]['mass']*weight(src[j],hi) for j in active];emid=[src[j]['mass']*weight(src[j],mid) for j in active];e=sum(emid,F(0));Ei=sum((k*(u-v) for k,u,v in zip(ks,ml,mh)),F(0));assert Ei>=0;energy+=Ei;Vi=F(0);ratio=F(0)
  if e:
   eL=sum(ml,F(0));eH=sum(mh,F(0));Vi=sum((u*k for u,k in zip(ml,ks)),F(0))/eL-sum((v*k for v,k in zip(mh,ks)),F(0))/eH;assert Vi>=0;variance+=Vi;var=sum((emid[i]*emid[j]*(ks[i]-ks[j])**2 for i in range(len(ks)) for j in range(i)),F(0))/e**2;J=sum((emid[i]*emid[j]*abs(ks[i]-ks[j]) for i in range(len(ks)) for j in range(i)),F(0))/e**2;assert 2*J*J<=var;ratio=2*J*J/var if var else F(0);maxpair=max(maxpair,ratio)
  else:allpositive=False
  intervals.append(dict(lo=lo,hi=hi,active=active,ks=ks,energy=Ei,variance=Vi,mid_pair_ratio=ratio))
 assert energy==Q0+birth-QT-deleted and Q0+birth<=n*etau and energy<=n*etau
 if allpositive:assert variance==birthnorm-QT/eT+Q0/etau+deljump
 return dict(tau=tau,end=end,empty=empty,e0=etau,eT=eT,Q0=Q0,QT=QT,birth=birth,deleted=deleted,energy=energy,variance=variance,birthnorm=birthnorm,deljump=deljump,normalized_identity_applicable=allpositive,events=eventrows,intervals=intervals,maxpair=maxpair)

def integration(c,ex,dps,refined=False):
 with mp.workdps(dps):
  n=c['n'];e0=mf(ex['e0']);varint=mp.mpf(0);wvar=mp.mpf(0);tv=mp.mpf(0);pairflux=mp.mpf(0);panelcount=0;crossings=0
  for seg in ex['intervals']:
   if not seg['active']:continue
   ks=seg['ks'];logs=[]
   mid=(seg['lo']+seg['hi'])/2
   for j,k in zip(seg['active'],ks):
    v=c['sources'][j];coef=v['mass']
    for a,count in v['groups']:
     if a<mid:coef*=a**count
    logs.append(mp.log(mf(coef)))
   lu=mp.log(mf(seg['lo']));hu=mp.log(mf(seg['hi']));levels=sorted(set(ks))
   def base(u):
    logweights=[a-k*u for a,k in zip(logs,ks)];shift=max(logweights);ww=[mp.exp(x-shift) for x in logweights];ee=sum(ww);degree=mp.exp(shift)*ee;return ww,ee,degree
   def mean(u):
    ww,ee,_=base(u);return sum(w*k for w,k in zip(ww,ks))/ee
   cuts=[lu,hu]
   for boundary,sign in ((lu,1),(hu,-1)):
    for size in (1,4,16,64):
     p=boundary+sign*mp.mpf(size)/n
     if lu<p<hu:cuts.append(p)
   for i in range(1,5 if refined else 3):cuts.append(lu+(hu-lu)*i/(5 if refined else 3))
   if len(levels)>2:
    mleft=mean(lu);mright=mean(hu)
    for k in levels[1:-1]:
     if mright<k<mleft:
      a=lu;b=hu
      for _ in range(4*dps):
       m=(a+b)/2
       if mean(m)>k:a=m
       else:b=m
      cuts.append((a+b)/2);crossings+=1
   cuts=sorted(set(cuts));panelcount+=len(cuts)-1
   def densities(u):
    ww,ee,degree=base(u);den=ee*ee;variance=sum(ww[i]*ww[j]*(ks[i]-ks[j])**2 for i in range(len(ks)) for j in range(i))/den;J=sum(ww[i]*ww[j]*abs(ks[i]-ks[j]) for i in range(len(ks)) for j in range(i))/den;flows=[sum(ww[i]*ww[j]*(ks[i]-ks[j]) for i in range(len(ks)) for j in range(len(ks)) if ks[i]>level>=ks[j])/den for level in levels[:-1]];v=max(flows,default=mp.mpf(0));return degree,variance,v,J
   # Two complex quadratures share the same actual full posterior evaluations.
   def varfun(u):
    degree,V,_,_=densities(u);return mp.mpc(V,degree/e0*V)
   def flowfun(u):
    degree,_,v,J=densities(u);return mp.sqrt(degree/e0)*mp.mpc(v,J)
   a=mp.quad(varfun,cuts);b=mp.quad(flowfun,cuts);varint+=a.real;wvar+=a.imag;tv+=b.real;pairflux+=b.imag
  length=mp.log(mf(ex['end']/ex['tau'])) if ex['end']>ex['tau'] else mp.mpf(0);tvbound=mp.sqrt(n*length)/2;pairbound=mp.sqrt(n*length/2);exactvar=mf(ex['variance']);err=abs(varint-exactvar);assert err<=mp.mpf('1e-25')*max(1,exactvar);energybound=mf(ex['energy']/ex['e0']) if ex['e0'] else mp.mpf(0);tol=mp.mpf('1e-25');assert wvar<=energybound+tol and tv<=tvbound+tol and pairflux<=pairbound+tol
  return dict(unweighted_variance_integral=enc(varint),exact_variance_quadrature_difference=enc(err),degree_weighted_variance=enc(wvar),degree_weighted_energy=enc(energybound),weighted_TV=enc(tv),weighted_TV_bound=enc(tvbound),weighted_TV_ratio=enc(tv/tvbound if tvbound else 0),weighted_full_pair_flux=enc(pairflux),weighted_full_pair_bound=enc(pairbound),weighted_full_pair_ratio=enc(pairflux/pairbound if pairbound else 0),panels=panelcount,mean_crossings=crossings,quadrature='logtime, all events, 1/n endpoint layers, score-mean crossings; refinedmp70 uses finer uniform cuts')

def cases():
 out=[]
 def add(name,n,sources,tau='1',T='2',stage='initial',**kw):
  assert all(sum(k for a,k in v['groups'])==n and all(a>0 and k>0 for a,k in v['groups']) and v['mass']>0 for v in sources);out.append(dict(name=name,n=n,sources=sources,tau=F(tau),T=F(T),stage=stage,**kw))
 base=[source('1',[('.5',1),('1.25',1)]),source('2',[('.75',1),('1.5',1)]),source('1/3',[('1',1),('2',1)])];add('heterogeneous2',2,base)
 rows=[['.8','1','1.2','1.4'],['.9','1.1','1.3','1.5'],['1.05','1.15','1.25','1.55'],['.7','1.1','1.4','1.6']];basis=[source(m,[(a,1) for a in row]) for m,row in zip(('10','7','5','3'),rows)];add('four_source_no_delete',4,basis,T='1.6');add('four_source_delete',4,[dict(v,death=F('1.1') if i==0 else F('1.4') if i==2 else None) for i,v in enumerate(basis)],T='1.6')
 coincide=[source(1,[('.5',2),('1.25',2)],'1.25'),source(2,[('1.25',3),('2',1)]),source('1/2',[('.75',1),('1.25',3)],'1.5')];add('coincident_birth_then_delete',4,coincide)
 add('initial_event_already_applied',2,[source(10,[('1',2)],'1'),source(1,[('1',1),('1.5',1)])],stage='pressure')
 terminal=[source(1,[('1',1),('2',1)],'2'),source(2,[('1.25',1),('2',1)])];add('terminal_closed',2,terminal,stage='pressure');add('terminal_open',2,terminal,stage='pressure',open_T=True)
 add('all_deleted_midwindow',2,[source(1,[('1.25',2)],'1.5'),source(2,[('.5',1),('1.5',1)],'1.5')],stage='pressure')
 add('single_nonzero_score',2,[source(3,[('.5',2)])],stage='pressure');add('single_zero_score',2,[source(3,[('4',2)])],stage='pressure');add('empty_source_measure',2,[],stage='pressure');add('singleton_window',2,base,tau='1',T='1',stage='pressure');add('empty_window',2,base,tau='2',T='1',stage='pressure');add('initially_deleted_all',2,[source(1,[('.5',2)],'1')],stage='pressure')
 g16=[source('1/10000',[('.25',4),('1',4),('1.5',4),('4',4)]),source('1',[('.5',8),('1.25',4),('3',4)],'1.5'),source('10000',[('.75',4),('1.5',8),('2.5',4)],'2'),source('3',[('1',4),('2',4),('3',4),('4',4)])];add('long_window_mass_ranges',16,g16,tau='.5',T='4',stage='expanded')
 add('n128_mixed',128,[source(1,[('.5',64),('1.25',64)]),source('1/2',[('1.1',32),('1.5',96)],'1.5'),source(3,[('1.25',128)]),source('1/100',[('3',128)])],stage='expanded')
 add('n512_multi_birth_delete',512,[source(2,[('1.1',128),('1.25',128),('1.75',256)],'1.75'),source(1,[('.5',256),('1.5',256)]),source(3,[('1.25',256),('2',256)],'1.25'),source('1/10',[('4',512)])],stage='expanded')
 add('n1024_narrow_layers',1024,[source(1,[(str(F(1025,1024)),1024)]),source('1/2',[(str(F(513,512)),512),('1.125',512)],'1.125'),source(3,[('1.0625',1024)]),source('1/10',[('4',1024)])],T='1.25',stage='expanded')
 add('n64_equal_scores',64,[source(1,[('.5',64)]),source(7,[('.5',64)]),source('1/7',[('.5',64)],'1.5')],stage='expanded')
 add('mass_rescaled_heterogeneous',2,[dict(v,mass=v['mass']*10**8) for v in base],stage='expanded')
 return out

def main(output,contract):
 results=[];maximum=mp.mpf(0)
 for c in cases():
  ex=exact(c);lo=integration(c,ex,40);hi=integration(c,ex,70,True)
  with mp.workdps(100):
   fields=['unweighted_variance_integral','degree_weighted_variance','weighted_TV','weighted_full_pair_flux'];diffs={k:abs(mf(lo[k])-mf(hi[k]))/(abs(mf(hi[k])) if mf(hi[k]) else 1) for k in fields};err=max(diffs.values());assert err<mp.mpf('1e-20');maximum=max(maximum,err)
  params=dict(name=c['name'],n=c['n'],tau=str(c['tau']),T=str(c['T']),stage=c['stage'],open_T=c.get('open_T',False),sources=[dict(mass=str(v['mass']),threshold_groups=[[str(a),k] for a,k in v['groups']],deletion=str(v['death']) if v['death'] is not None else None) for v in c['sources']]);certificate={key:fracsave(ex[key]) for key in ['e0','eT','Q0','QT','birth','deleted','energy','variance','birthnorm','deljump','maxpair']};certificate.update(energy_identity_residual='0',energy_bound_ne_tau=fracsave(c['n']*ex['e0']),initial_plus_birth_le_ne_tau=True,normalized_mean_identity_applicable=ex['normalized_identity_applicable'],event_rows=ex['events'],intervals=[dict(lo=str(v['lo']),hi=str(v['hi']),active_sources=v['active'],constant_scores=v['ks'],energy=fracsave(v['energy']),exact_variance_integral=fracsave(v['variance']),midpoint_2J_squared_over_Var=fracsave(v['mid_pair_ratio'])) for v in ex['intervals']]);results.append(dict(parameters=params,exact=certificate,mp40=lo,mp70_refined=hi,relative_precision_difference={k:enc(v) for k,v in diffs.items()},relative_precision_max=enc(err)));print(c['name'],'done',flush=True)
 payload=dict(source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),scope='Finite arbitrary correlated positive atomic sources with true product clocks and monotone finite deletion; algebra/path tools, not original L1/FULL/heavy/history.',clock_cases=results,counts=dict(clock_cases=len(results),exact_energy_identities=len(results),exact_midpoint_pair_checks=sum(bool(s['active_sources']) for v in results for s in v['exact']['intervals']),interval_records=sum(len(v['exact']['intervals']) for v in results),empty_interval_zero_cost_branches=sum(not s['active_sources'] for v in results for s in v['exact']['intervals']),normalized_mean_identities=sum(v['exact']['normalized_mean_identity_applicable'] for v in results)),maximum_relative_precision_difference=enc(maximum),conventions='Thresholds at tau already in initialscore and deletion at tau already applied. Internal/closedT births precede simultaneous deletion; openT uses internal leftlimit and excludes endpoint events. T<=tau means empty no-evolution window. Empty e means no posterior, continuous costs0 by explicit empty-source convention.',quadrature='mp40 vs refinedmp70 ordinary logtime quadrature, no interval certification. Var and Jall use positive pair sums, TV uses maximum positive scorecut flow to avoid nearly-degenerate posterior cancellation. Same complex integral accumulates TV/fullpair.',large_rational_certificates='Integers exceeding900bits saved as sign/bits/SHA256 with approximation; all exact Fractions reconstructed and identities asserted on replay.')
 if Path(contract).exists():payload['contract_sha256']=hashlib.sha256(Path(contract).read_bytes()).hexdigest()
 Path(output).write_text(json.dumps(payload,indent=2,sort_keys=True)+'\n');print(payload['counts'])
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--output',default=str(ROOT/'numeric_checks.json'));p.add_argument('--contract',default=str(ROOT/'task_contract.md'));a=p.parse_args();main(a.output,a.contract)
