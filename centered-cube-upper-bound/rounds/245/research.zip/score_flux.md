# R245: threshold births, deletion compensation, and degree-weighted energy

This note owns only this file. It proves a threshold-flux identity and
a full-window, degree-weighted root estimate for the original normalized
kernel. It does not pay the unweighted original traffic: the reciprocal
degree needed to remove the weight remains a real source/receiver cost.
No product independence of the posterior is assumed.

## SF1. Original objects and exact endpoint convention

Freeze the original `(omega,V,j,y)`, before receiver x and hard source z.
Use [R117 joint_geometry.md:9–32](/Users/zhengzhihao/Desktop/T/output/centered_cube_round117_20261014/joint_geometry.md:9):

    A_i(y,v)=b C(|y_i-v_i|/b)/c_j,
    w_t(v)=product_i min(1,A_i/t),
    Z_t=D_V(y) intersect [T0(y) minus A_{j,t}(y)],
    mu_t=1_Zt w_t nu_V, e_t=||mu_t||, Pi_t=mu_t/e_t.

The original forbidden block expands right-continuously by finitely
many actual jumps. Its coordinate thresholds A_i are distinct objects.
The nonempty strict-heavy interval I has left endpoint tau=a/c_j,
right endpoint T<=bc_j, and

    e_t>B_j t^n, B_j=ell q c_j^{-n/2}, ell=1+log n.    (SF1)

All right endpoint values are internal one-sided limits if I is open.
The initial measure already includes deletion at tau. No event at tau
is charged a second time. A closed right endpoint is included only if
it is still heavy, as in R117:76–81. An empty or singleton interval
has no continuous cost.

For Stieltjes formulas take `k_t^+(v)=#{i:A_i<=t}` and
`m_t=integral k_t^+ dPi_t`. R117's strict `<t` score agrees for
Lebesgue-a.e. log time. At a simultaneous coordinate birth/deletion,
first apply all coordinate births to the old surviving measure, then
delete the actual forbidden set. This is a bookkeeping convention for
the two jumps, not a modification of the actual right-continuous Pi.

## SF2. Exact normalized birth identity, including deletions

Let u=log t. Define the finite positive birth measure on the internal
events of I by

    dB_y(u)=integral nu_V(dv) sum_i
       1_{tau<A_i<=T} 1_{v in Z_{A_i-}}
       [w_{A_i}(v)/e_{A_i-}] delta_{log A_i}(du).       (SF2)

For an open endpoint replace `<=T` by `<T`. Here Z_{s-} includes
sources about to be deleted at s. At a nondeletion time its value is
Z_s. The source integrand is measurable by the original measurable
kernel construction (R117:131); the event times A_i are explicit
measurable maps. Since e has a positive internal lower bound and nu
is finite, this birth measure is finite. Multiplicities are retained.

At a deletion s put d_s=(e_{s-}-e_s)/e_{s-}; let m_keep and m_removed
be the post-birth mean k_s^+ on its surviving and removed parts.
If no mass is removed set the following term to zero. Then

    Delta_del m_s=d_s(m_keep-m_removed),
    |Delta_del m_s|<=n d_s.                            (SF3)

The complete identity is

    dm=dB_y-Var_{Pi_t}(k_t) du
                       +sum_s Delta_del m_s delta_log(s),
    integral_I Var_{Pi_t}(k_t) dlog t
       =B_y(I)-(m_T-m_tau)+sum_s Delta_del m_s.        (SF4)

Proof: between forbidden-block changes, product differentiation gives
`dPi_t/du=(m_t-k_t)Pi_t`. Apply the product rule to the bounded
score k_t: its derivative is precisely its threshold pushforward,
and the posterior derivative contributes `m_t^2-E k_t^2=-Var k_t`.
The posterior itself is continuous at a pure threshold, so there is
no cross-jump term there. At forbidden-block jumps, conditional
renormalization gives SF3. Summing over the finite deletion intervals
and using bounded-measure Fubini proves SF4, also for continuous
threshold distributions and atoms. Open endpoints follow by internal
limits. This proves the identity without differentiating any original
FA, capture, good/bad, or receiver selector gate.

The original born qualification pays only the known deletion sum:
R117:135–180 gives

    sum_s d_s<=rho_j(T)
      <=[c_j^{n/2}+sqrt(n)c_j^{3n/2}]/ell.             (SF5)

Consequently an upper bound on B alone is not automatically the same
bound on continuous variance: SF4 also contains the signed deleted
mean, whose available absolute estimate is n rho_j(T). These deletion
compensations are not unused signed traffic credit.

## SF3. A true full-window weighted flux and energy budget

The normalizer-weighted birth measure has the explicit bound

    integral_I e_{t-} dB_y(log t)
      =integral nu_V(dv) sum_i
        1_{tau<A_i<=T, v in Z_{A_i-}} w_{A_i}(v)
      <=n e_tau.                                     (SF6)

More precisely its left side plus `e_tau m_tau` is <=n e_tau:
every coordinate can be initially active or can be born once later,
and `w_{A_i}(v)<=w_tau(v)`. Deletions only remove possible future
births. Thus the budget is valid for the complete original nu, not
an artificially independent coordinate product.

Let `Q_t=integral k_t^+ dmu_t=e_t m_t`. Its exact unnormalized identity
is

    Q_T-Q_tau = integral_I e_{t-}dB_y
       -integral_I e_t E_{Pi_t}k_t^2 dlog t
       -sum_s integral_{Z_{s-} minus Z_s}k_s^+ w_s dnu_V.

The terminal Q_T and the deleted k-mass are nonnegative. With the
sharpened SF6 this proves

    integral_I e_t E_{Pi_t}k_t^2 dlog t<=n e_tau,
    integral_I (e_t/e_tau) Var_{Pi_t}(k_t)dlog t<=n.    (SF7)

These are genuine global-in-time bounds; there is no threshold count,
source mass ratio, or static posterior envelope on their right sides.
They keep the price e_t/e_tau in the correct direction.

For the continuous positive variation density
`v_t=E_{Pi_t}|k_t-m_t|/2`, Cauchy--Schwarz now gives

    integral_I sqrt(e_t/e_tau) v_t dlog t
       <=(1/2)sqrt[n log(T/tau)] <=(1/2)sqrt(n log 2).
                                                               (SF8)

The separate posterior deletion variation is still sum_s d_s and
obeys SF5. SF8 is a root estimate for an explicitly weighted path;
it is not an unweighted path bound or an original-traffic payment.

## SF4. Actual sources, heavy conversion, and the first unpaid cost

All formulas above hold rowwise in the original y. They may be
integrated against the original beta_V(dy), original hard nu_V(dz),
and original receiver/RN factor. For example with the genuine mother

    dT_I=1_I 1_{j(x)=j}q^-1 p(x,y)h_R(x)(x-z)a_omega
                              dx beta_V(dy)nu_V(dz),

positive Tonelli gives exactly

    E sum_{V,j} integral dT_I integral_I e_{t-}dB_y
       <=n E sum_{V,j} integral e_tau(y)dT_I.          (SF9)

The mother, original high/far and both complete posteriors are
[R128 proof.md:604–650](/Users/zhengzhihao/Desktop/T/output/centered_cube_round128_20261014/proof.md:604).
SF9 does not replace hard z by auxiliary v, nor drop its hard kernel.
It is a degree-weighted joint source budget, not a budget by W_beta.
The right side contains the actual pair degree e_tau(y). The relation
nu<=beta and common cut/source-born support do not normalize it to one.

For comparison, using only genuine heavy and monotonicity gives

    integral_I Var_{Pi_t}(k_t)dlog t
       <=n e_tau/e_* <= n e_tau/[B_j T^n],
    integral_I v_t dlog t
       <=(1/2)sqrt[n log(T/tau) e_tau/(B_j T^n)].      (SF10)

The normalizer in SF2 also yields the explicit threshold bound

    B_y(I)<=B_j^-1 integral nu_V(dv) sum_i
       1_{tau<A_i<=T, v in Z_{A_i-}}w_{A_i}(v) A_i^-n.
                                                               (SF11)

Both retain the source-scale cost. Neither converts it into input
mass. The born node cap used in SF5 bounds the union of deleted light
blocks; it does not bound all of Z_tau or e_tau by B_j T^n. FIRST is
`integral p(x,y)beta_V(dy)<=q` on the original receiver. It does not
by itself bound that integral with the additional y-dependent factor
`sqrt(e_tau(y)/e_t(y))`. Inserting this factor is precisely what is
required to remove the weight from SF8. Its naive replacement by
`sqrt(nu_V(V)/(B_jt^n))` reintroduces the unpaid source-crowding price.
Likewise, each j can reuse the same sources, so SF9 is not summed for
free merely because the original receiver's j is unique.

The full target needs a joint estimate with the actual receiver kernel,
both posterior normalizers and these reciprocal degrees (or a signed
mechanism paying their loss). SF6--8 isolate a real root weighted
energy, but do not establish that missing joint estimate. No old
negative credit is consumed here. This note stops at this precise gap.

## SF5. Actual local arithmetic diagnostic

A six-case finite-atom calculation at 60 decimal digits verified SF4,
the unnormalized identity, SF6--8: 30 checks passed; maximum identity
residual `1.99136488892e-59`; maximum weighted-TV/root-bound ratio
`0.103107798672`. Atomic inputs here check the kernel algebra only;
they are not FULL examples or simulations of the original forest.
The code below was actually run with local mpmath 1.3.0.

```python
import mpmath as m
m.mp.dps=60
A=[[m.mpf(t) for t in row.split()] for row in
   ['0.8 1.0 1.2 1.4','0.9 1.1 1.3 1.5',
    '1.05 1.15 1.25 1.55','0.7 1.1 1.4 1.6']]
a=m.mpf(1); b=m.mpf('1.6'); n=4; checks=0
err=m.mpf(0); maxv=m.mpf(0)
for factor in [m.mpf('0.5'),m.mpf(1),m.mpf(3)]:
 for kill in [False,True]:
  mass=[factor*t for t in [10,7,5,3]]
  deaths={0:m.mpf('1.1'),2:m.mpf('1.4')} if kill else {}
  def live(t,before=False):
   return [j for j in range(4) if j not in deaths or deaths[j]>t
           or (before and deaths[j]==t)]
  def w(j,t):return m.fprod(min(1,u/t) for u in A[j])
  def k(j,t):return sum(u<=t for u in A[j])
  def stats(t,js):
   e=sum(mass[j]*w(j,t) for j in js)
   mean=sum(mass[j]*w(j,t)*k(j,t) for j in js)/e
   sec=sum(mass[j]*w(j,t)*k(j,t)**2 for j in js)/e
   mad=sum(mass[j]*w(j,t)*abs(k(j,t)-mean) for j in js)/e
   return e,mean,sec-mean**2,sec,mad
  e0,m0,*_=stats(a,live(a)); e1,m1,*_=stats(b,live(b))
  birth=weighted=deljump=delk=m.mpf(0)
  events=sorted(set([u for row in A for u in row if a<u<=b]
                    +list(deaths.values())))
  for t in events:
   js=live(t,True); ep,mp,*_=stats(t,js)
   num=sum(mass[j]*w(j,t)*sum(u==t for u in A[j]) for j in js)
   birth+=num/ep; weighted+=num
   if t in deaths.values():
    ea,ma,*_=stats(t,live(t)); deljump+=ma-mp
    delk+=sum(mass[j]*w(j,t)*k(j,t) for j in js
              if j not in live(t))
  grid=sorted(set([a,b]+events)); iv=energy=vp=m.mpf(0)
  for l,h in zip(grid,grid[1:]):
   js=live((l+h)/2)
   iv+=m.quad(lambda t:stats(t,js)[2]/t,[l,h])
   energy+=m.quad(lambda t:stats(t,js)[0]*stats(t,js)[3]/t,[l,h])
   vp+=m.quad(lambda t:m.sqrt(stats(t,js)[0]/e0)
                           *stats(t,js)[4]/(2*t),[l,h])
  errors=[abs(iv-(birth-m1+m0+deljump)),
          abs(e1*m1-e0*m0-weighted+energy+delk)]
  err=max(err,*errors)
  assert max(errors)<m.mpf('1e-50'); checks+=2
  assert weighted+e0*m0<=n*e0+m.mpf('1e-50'); checks+=1
  assert energy<=n*e0; checks+=1
  assert vp<=m.sqrt(n*m.log(b/a))/2; checks+=1
  maxv=max(maxv,vp/(m.sqrt(n*m.log(b/a))/2))
print(checks,m.nstr(err,12),m.nstr(maxv,12))
```
