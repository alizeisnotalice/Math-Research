"""Exact finite-atom endpoint allocation certificates on actual 2D roots.

The examples use separated clusters of weights 9 and 16 and lambda=100.
Any side <=1 captures atoms from at most one cluster; thus the only possible
nonzero masses are 9,16,25, with exhaustive rational candidate roots
3/10,2/5,1/2. Cell boundaries are null sets. The top endpoint is separate.
"""

from collections import deque
from fractions import Fraction as F
from itertools import combinations, product

LAM = F(100)
ROOTS = (F(3, 10), F(2, 5), F(1, 2))
BINS = (F(1, 16), F(1, 8), F(1, 4))


def roots_and_cells(atoms, margin=F(0)):
    cuts = [set(), set()]
    for t in ROOTS:
        for x, y, _ in atoms:
            for i, v in enumerate((x, y)):
                cuts[i].update((v - t / 2, v + t / 2))
    xx, yy = map(sorted, cuts)
    out = []
    for (x0, x1), (y0, y1) in product(zip(xx, xx[1:]), zip(yy, yy[1:])):
        center = ((x0 + x1) / 2, (y0 + y1) / 2)

        def captured(t):
            return tuple(
                i
                for i, (x, y, w) in enumerate(atoms)
                if abs(x - center[0]) < t / 2 and abs(y - center[1]) < t / 2
            )

        possible = []
        for t in ROOTS:
            ids = captured(t)
            if sum((atoms[i][2] for i in ids), F(0)) == LAM * t * t:
                possible.append((t, ids))
        if possible:
            t, ids = max(possible)
            # All clusters have mass at most 25 < 100*(11/20)^2.
            assert sum(w for _, _, w in atoms) < LAM
            assert F(11, 40) < t < F(11, 20)
            width, height = x1 - x0 - 2 * margin, y1 - y0 - 2 * margin
            if width > 0 and height > 0:
                if margin:
                    for axis, (lo, hi) in enumerate(
                        ((x0 + margin, x1 - margin), (y0 + margin, y1 - margin))
                    ):
                        for atom in atoms:
                            for candidate in ROOTS:
                                for face in (
                                    atom[axis] - candidate / 2,
                                    atom[axis] + candidate / 2,
                                ):
                                    assert face <= lo - margin or face >= hi + margin
                out.append((t, ids, width * height))
    return out


def assign(matrix, masses):
    n = len(masses)
    pairs = []
    for i in range(n):
        for j in range(i, n):
            demand = matrix[i][j] if i == j else matrix[i][j] + matrix[j][i]
            if demand:
                pairs.append((i, j, demand))
    # s -> unordered pair -> endpoint -> t; exact rational Edmonds-Karp.
    N = 2 + len(pairs) + n
    s = 0
    t = N - 1
    capacity = [[F(0) for _ in range(N)] for _ in range(N)]
    for index, (i, j, demand) in enumerate(pairs):
        v = 1 + index
        capacity[s][v] = demand
        capacity[v][1 + len(pairs) + i] = demand
        if j != i:
            capacity[v][1 + len(pairs) + j] = demand
    for i, m in enumerate(masses):
        capacity[1 + len(pairs) + i][t] = m
    residual = [x[:] for x in capacity]
    flow = F(0)
    while True:
        before = [-1] * N
        before[s] = s
        queue = deque([s])
        while queue and before[t] < 0:
            v = queue.popleft()
            for x in range(N):
                if before[x] < 0 and residual[v][x] > 0:
                    before[x] = v
                    queue.append(x)
        if before[t] < 0:
            break
        step = None
        v = t
        while v != s:
            u = before[v]
            step = residual[u][v] if step is None else min(step, residual[u][v])
            v = u
        v = t
        while v != s:
            u = before[v]
            residual[u][v] -= step
            residual[v][u] += step
            v = u
        flow += step
    original = sum(d for _, _, d in pairs)
    assigned = [masses[i] - residual[1 + len(pairs) + i][t] for i in range(n)]
    assert sum(assigned, F(0)) == flow
    routes = []
    for index, (i, j, demand) in enumerate(pairs):
        v = 1 + index
        ni = 1 + len(pairs) + i
        nj = 1 + len(pairs) + j
        to_i = capacity[v][ni] - residual[v][ni]
        to_j = F(0) if i == j else capacity[v][nj] - residual[v][nj]
        assert to_i >= 0 and to_j >= 0
        routes.append((i, j, demand, to_i, to_j))
    return flow, original, assigned, routes


def run_case(name, atoms, margin=F(0)):
    # Atom clusters are separated in l-infinity by >1, so no unit-side cube
    # can capture distinct clusters; one cluster contains at most 9 and 16.
    for i, (x, y, w) in enumerate(atoms):
        assert w in (9, 16)
        for X, Y, other_weight in atoms[i + 1 :]:
            if max(abs(x - X), abs(y - Y)) > F(1):
                continue
            assert (x, y) != (X, Y) and {w, other_weight} == {
                F(9),
                F(16),
            }
    cells = roots_and_cells(atoms, margin)
    if margin:
        assert margin == F(1, 5000)  # 2 delta, where delta=1/10000.
        all_area = sum(area for _, _, area in roots_and_cells(atoms))
        kept_area = sum(area for _, _, area in cells)
        assert 0 < kept_area < all_area
        print(
            "L1 inflated-source restricted geometry: delta=1/10000, kept=",
            kept_area,
            "deleted=",
            all_area - kept_area,
            "full=",
            all_area,
        )
        print(
            "Each block has constant density; all candidate-root faces have margin 2delta. For arbitrary measurable subsets, product source laws disintegrate the blockwise endpoint allocations."
        )
    print("\nCASE", name, "atoms", len(atoms), "positive root cells", len(cells))
    for prediction in ("all", "asymmetric"):
        w = [
            F(1) if prediction == "all" else F(i + 1, len(atoms))
            for i in range(len(atoms))
        ]
        assert all(0 <= x <= 1 for x in w)
        for p in range(len(atoms)):
            for D in BINS:
                selected = [
                    (t, ids, area)
                    for t, ids, area in cells
                    if p in ids and D <= t * t < 2 * D
                ]
                if not selected:
                    continue
                matrix = [[F(0) for j in atoms] for i in atoms]
                for t, ids, area in selected:
                    for i, j in product(ids, repeat=2):
                        if i != p:
                            continue
                        matrix[i][j] += (
                            area * atoms[i][2] * atoms[j][2] * w[j] / (LAM * t**4)
                        )
                masses = [a[2] for a in atoms]
                subsets = []
                for mask in range(1, 1 << len(atoms)):
                    members = [i for i in range(len(atoms)) if mask >> i & 1]
                    inside = sum((matrix[i][j] for i in members for j in members), F(0))
                    subsets.append((inside / sum(masses[i] for i in members), mask))
                best = max(x[0] for x in subsets)
                winners = [mask for value, mask in subsets if value == best]
                flow, demand, assigned, pairs = assign(matrix, masses)
                assert (best <= 1) == (flow == demand)
                assert best <= 1
                left = [sum(row, F(0)) for row in matrix]
                left_max = max(left[i] / masses[i] for i in range(len(atoms)))
                k = sum(w[i] * masses[i] for i in range(len(atoms))) / (LAM * D)
                print(
                    "p=",
                    p,
                    "D=",
                    D,
                    "w=",
                    prediction,
                    "K=",
                    k,
                    "root_sides=",
                    sorted({t for t, ids, a in selected}),
                    "tau_total=",
                    demand,
                    "max_A_tau/mu=",
                    best,
                    "A_masks=",
                    winners,
                    "flow=",
                    flow,
                    "left_only_max_ratio=",
                    left_max,
                    "saturated=",
                    [i for i, a in enumerate(assigned) if a == masses[i]],
                    "left_feasible=",
                    all(left[i] <= masses[i] for i in range(len(atoms))),
                )
                print(
                    "  matrix=",
                    [[str(v) for v in row] for row in matrix],
                    "flow_endpoint_totals=",
                    list(map(str, assigned)),
                    "pair_routes=",
                    [(i, j, str(d), str(a), str(b)) for i, j, d, a, b in pairs],
                )
        # Original edge measure sums the left source p once and all D, not
        # an extra full P tensor P for each p. Same prediction is used at every D.
        matrix = [[F(0) for _ in atoms] for _ in atoms]
        for t, ids, area in cells:
            assert sum(D <= t * t < 2 * D for D in BINS) == 1
            for i, j in product(ids, repeat=2):
                matrix[i][j] += area * atoms[i][2] * atoms[j][2] * w[j] / (LAM * t**4)
        masses = [a[2] for a in atoms]
        subsets = []
        for mask in range(1, 1 << len(atoms)):
            ids = [i for i in range(len(atoms)) if mask >> i & 1]
            inside = sum((matrix[i][j] for i in ids for j in ids), F(0))
            subsets.append((inside / sum(masses[i] for i in ids), mask))
        best = max(v for v, _ in subsets)
        winners = [mask for v, mask in subsets if v == best]
        flow, demand, assigned, routes = assign(matrix, masses)
        assert (best <= 1) == (flow == demand)
        if prediction == "all":
            assert demand == LAM * sum(area for _, _, area in cells)
        left = [sum(row, F(0)) for row in matrix]
        print(
            "COMBINED",
            name,
            "w=",
            prediction,
            "tau_total=",
            demand,
            "max_A_tau/mu=",
            best,
            "A_masks=",
            winners,
            "flow=",
            flow,
            "unallocated=",
            demand - flow,
            "left_only_max_ratio=",
            max(left[i] / masses[i] for i in range(len(atoms))),
            "left_feasible=",
            all(left[i] <= masses[i] for i in range(len(atoms))),
            "saturated=",
            [i for i, v in enumerate(assigned) if v == masses[i]],
        )
        optimal_caps = [best * mass for mass in masses]
        optimum_flow, optimum_demand, optimum_assigned, optimum_routes = assign(
            matrix, optimal_caps
        )
        assert optimum_flow == optimum_demand == demand
        for mask in winners:
            witness_ids = [i for i in range(len(atoms)) if mask >> i & 1]
            witness_mu = sum(masses[i] for i in witness_ids)
            witness_tau = sum(
                (matrix[i][j] for i in witness_ids for j in witness_ids), F(0)
            )
            assert witness_tau == best * witness_mu
            print(
                "OPTIMAL_U",
                name,
                "w=",
                prediction,
                "U=",
                best,
                "A_mask=",
                mask,
                "mu(A)=",
                witness_mu,
                "tau(AxA)=",
                witness_tau,
                "U_capacity_flow=",
                optimum_flow,
                "U_saturated=",
                [
                    i
                    for i, value in enumerate(optimum_assigned)
                    if value == optimal_caps[i]
                ],
            )
        print(
            "  U_pair_routes=",
            [(i, j, str(d), str(a), str(b)) for i, j, d, a, b in optimum_routes],
        )
        print(
            "  combined matrix=",
            [[str(v) for v in row] for row in matrix],
            "pair_routes=",
            [(i, j, str(d), str(a), str(b)) for i, j, d, a, b in routes],
        )


# Same physical atoms may not be double-counted; merge coincident mass first.
def one_atom_tests():
    for name, weight in [("single", F(9)), ("coincident_9_plus_16_merged", F(25))]:
        t = F(3, 10) if weight == 9 else F(1, 2)
        area = t * t
        P = weight / (LAM * t * t)
        tau = LAM * area * P * P
        assert P == 1 and tau == weight
        flow, demand, assigned, _ = assign([[tau]], [weight])
        assert flow == demand == weight and assigned == [weight]
        print(
            "PRESSURE",
            name,
            "mass=",
            weight,
            "t=",
            t,
            "diagonal=",
            tau,
            "ratio=1",
            "endpoint saturated",
        )
    # A superlevel surviving to the top endpoint is a separate endpoint charge;
    # P need not be a probability there. It is not included in internal tau.
    top = F(11, 20)
    weight = F(49)
    area = top**2
    P = weight / (LAM * top**2)
    raw = LAM * area * P * P
    assert P == F(196, 121) and raw == F(9604, 121) > weight
    print(
        "TOP-ENDPOINT separate: t=",
        top,
        "P=",
        P,
        "raw quadratic=",
        raw,
        "mu=",
        weight,
        "not included in internal-root certificate",
    )


def redraw_test(name, atoms, margin=F(0)):
    """Use m_p(C)=|C|/v_C within each actual p, D group."""
    cells = roots_and_cells(atoms, margin)
    masses = [atom[2] for atom in atoms]
    phi = {}
    for p in range(len(atoms)):
        for D in BINS:
            selected = [
                (t, ids, area)
                for t, ids, area in cells
                if p in ids and D <= t * t < 2 * D
            ]
            normalizer = sum((area / t**2 for t, ids, area in selected), F(0))
            if not normalizer:
                continue
            for q in range(len(atoms)):
                hit = sum((area / t**2 for t, ids, area in selected if q in ids), F(0))
                phi[p, D, q] = hit / normalizer
                assert 0 <= phi[p, D, q] <= 1
            print(
                "REDRAW_PHI",
                name,
                "p=",
                p,
                "D=",
                D,
                "m_p=",
                normalizer,
                "phi=",
                [str(phi[p, D, q]) for q in range(len(atoms))],
            )
    base = LAM * sum((area for _, _, area in cells), F(0))
    previous = F(0)
    print("REDRAW_CASE", name, "base lambda*|F|=", base)
    for k in (1, 2, 8, None):
        matrix = [[F(0) for _ in atoms] for _ in atoms]
        for t, ids, area in cells:
            D = next(D for D in BINS if D <= t * t < 2 * D)
            for i, j in product(ids, repeat=2):
                x = phi[i, D, j]
                w = F(int(x > 0)) if k is None else 1 - (1 - x) ** k
                matrix[i][j] += area * masses[i] * masses[j] * w / (LAM * t**4)
        total = sum((sum(row, F(0)) for row in matrix), F(0))
        maxcut = max(
            sum(
                (
                    matrix[i][j]
                    for i in range(len(atoms))
                    for j in range(len(atoms))
                    if mask >> i & 1 and mask >> j & 1
                ),
                F(0),
            )
            / sum((masses[i] for i in range(len(atoms)) if mask >> i & 1), F(0))
            for mask in range(1, 1 << len(atoms))
        )
        assert previous <= total <= base
        previous = total
        print(
            "REDRAW_RESULT",
            name,
            "k=",
            "union" if k is None else k,
            "hit=",
            total,
            "hit/base=",
            total / base,
            "maxcut=",
            maxcut,
        )
        # These examples have one actual capture set per (p,D), so every
        # edge in the original integral has phi=1. No generic inference.
        assert total == base


if __name__ == "__main__":
    one_atom_tests()
    cases = [
        ("two", [(F(0), F(0), F(9)), (F(3, 20), F(3, 20), F(16))]),
        (
            "three",
            [(F(0), F(0), F(9)), (F(7, 20), F(1, 20), F(16)), (F(3), F(0), F(9))],
        ),
        (
            "four",
            [
                (F(0), F(0), F(9)),
                (F(3, 20), F(3, 20), F(16)),
                (F(3), F(0), F(9)),
                (F(67, 20), F(1, 20), F(16)),
            ],
        ),
    ]
    for name, atoms in cases:
        run_case(name, atoms)
    run_case("two_positive_L1_restricted", cases[0][1], F(1, 5000))
    run_case("three_positive_L1_restricted", cases[1][1], F(1, 5000))
    assert F(11, 40) < ROOTS[0] and ROOTS[-1] < F(11, 20)
    assert F(25) < LAM * F(11, 20) ** 2  # no original cluster survives the top.
    redraw_test("two_atomic", cases[0][1])
    redraw_test("three_atomic", cases[1][1])
    redraw_test("three_positive_L1_restricted", cases[1][1], F(1, 5000))
    print(
        "PASS: exact finite actual roots, exhaustive atomic subsets and exact endpoint flow; no general theorem claimed"
    )
