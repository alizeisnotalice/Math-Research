"""Real positive-density two-neighbor examples for the actual same-price source test."""
from fractions import Fraction as F
from itertools import product
from math import inf

LABELS = (-1, 0, 1)
BRANCHES = ((-1, 0), (0, 1))


def check(n):
    # In R^n, equal density blocks have centers at -3/2,0,3/2 on axis 1.
    # Receivers for each neighbor pair occupy a disjoint open rectangle. All
    # interval inequalities below are strict in their interiors.
    delta = F(1, 100*n)
    block_mass = 2**(n-1)
    centers = {j:F(3*j,2) for j in LABELS}
    side = F(2)
    assert F(5,4) < side < F(5,2) < (centers[1]-centers[-1]-2*delta)
    one_axis_lengths = []
    for group in BRANCHES:
        lo = max(centers[j] for j in group) - side/2 + 2*delta
        hi = min(centers[j] for j in group) + side/2 - 2*delta
        assert hi > lo and hi-lo == F(1,2)-4*delta
        # On the closure, all points of either block still fit at side 2-2delta.
        for j in group:
            assert max(abs(lo-centers[j]), abs(hi-centers[j])) + delta <= 1-delta
        one_axis_lengths.append(hi-lo)
    assert side-2*delta > F(5,4)
    assert 2*block_mass == 2**n and (side-2*delta)**n < 2*block_mass
    receipt = sum(one_axis_lengths)*(side-4*delta)**(n-1)
    branch_mass = receipt/2
    # The two receiver boxes are equal in volume and have common v=2^n.
    # Given actual first source in a block, disintegrate its true receiver density.
    available = {p:[i for i, group in enumerate(BRANCHES) if p in group] for p in LABELS}
    phi = {(p,q):sum((F(1,len(available[p])) for i in available[p] if q in BRANCHES[i]), F(0))
           for p in LABELS for q in LABELS}
    assert phi[0,-1] == phi[0,1] == F(1,2) and phi[-1,-1] == 1
    for k in (1,2,8,32,inf):
        edge = {(i,j):F(0) for i in LABELS for j in LABELS}
        for group in BRANCHES:
            for i,j in product(group,repeat=2):
                hit = F(phi[i,j] > 0) if k == inf else 1-(1-phi[i,j])**k
                edge[i,j] += branch_mass*hit/4
        total = sum(edge.values(),F(0))
        expected = F(1) if k == inf else 1-F(1,4*2**k)
        assert total/receipt == expected
        worst = F(0)
        for coeff in product((0,1), repeat=3):
            inside = [j for j, selected in zip(LABELS,coeff) if selected]
            if inside:
                cut = sum((edge[i,j] for i,j in product(inside,repeat=2)),F(0))
                worst = max(worst,cut/(len(inside)*block_mass))
        assert worst == total/(3*block_mass)
        print("continuous two-neighbor", "n", n, "k", k, "hit/M", expected,
              "U*S/M", worst*3*block_mass/receipt)
    print("selected true receipt/source n",n,"M/S (rounded)",float(receipt/(3*block_mass)))



def variable_price_information():
    """Continuous source blocks in one bin, with distinct true root volumes."""
    from flint import arb, ctx

    ctx.prec = 384
    delta = F(1,10000)
    sources = {-1:F(1), 0:F(1), 1:F(3,2)}
    positions = {-1:F(-3,2),0:F(0),1:F(7,4)}
    branches = [((-1,0),F(2)), ((0,1),F(5,2))]
    rows = []
    for group, v in branches:
        lo = max(positions[j] for j in group) - v/2 + 2*delta
        hi = min(positions[j] for j in group) + v/2 - 2*delta
        for j in group:
            assert max(abs(lo-positions[j]),abs(hi-positions[j]))+delta <= v/2-delta
        remote = next(j for j in sources if j not in group)
        assert max(lo-positions[remote],positions[remote]-hi)-delta > F(3,2)
        assert F(3,2) < v-2*delta and v < 3 and sum(sources[j] for j in group) == v
        assert 2 <= v < 4
        rows.append((group,v,hi-lo))
    total = sum(area for group,v,area in rows)
    actual_info = arb(0)
    surprise = arb(0)
    negative = positive = False
    for p in sources:
        row_mass = sum((area/v for group,v,area in rows if p in group),F(0))
        for group,v,area in rows:
            if p not in group:
                continue
            for q in group:
                phi = sum((a/b for g,b,a in rows if p in g and q in g),F(0))/row_mass
                dens = sum((a/b**2 for g,b,a in rows if p in g and q in g),F(0))/row_mass
                ratio = 1/(v*dens)
                assert F(1,2) <= phi*ratio <= 2
                weight = area*sources[p]*sources[q]/v**2/total
                w = arb(weight.numerator)/weight.denominator
                actual_info += w*(arb(ratio.numerator)/ratio.denominator).log()
                surprise -= w*(arb(phi.numerator)/phi.denominator).log()
                negative |= ratio < 1
                positive |= ratio > 1
    assert negative and positive and actual_info > 0 and surprise > 0
    assert actual_info >= surprise and actual_info-surprise < arb(2).log()
    print("continuous variable-root information", "window 3/2,3", "D=2",
          "M", total, "signs present", negative, positive,
          "conditional I", actual_info.str(15), "mean minus log(psi)", surprise.str(15))

if __name__ == "__main__":
    variable_price_information()
    for dimension in (1, 2, 8, 64, 256, 1024):
        check(dimension)
    print("PASS: two disjoint actual receiver regions, one shared physical source, six dimensions.")
