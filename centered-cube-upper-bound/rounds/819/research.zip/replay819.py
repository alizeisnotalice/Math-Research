"""Finite actual-root tests, entropy accounting, and interval parameter checks for round 819."""
from fractions import Fraction as F
from hashlib import sha256
import os
from pathlib import Path
import subprocess
import sys

import flint
from flint import arb, ctx

HERE = Path(__file__).resolve().parent


def iv(q):
    q = F(q)
    return arb(q.numerator) / q.denominator


def sign(x):
    if x > 0:
        return "+"
    if x < 0:
        return "-"
    raise ArithmeticError("undetermined nonzero sign")


def entropy_test(bits):
    ctx.prec = bits
    # Both cubes of source density are fully captured on the open receiver
    # rectangle. The two source coordinates are independent only conditional
    # on this one frozen root. Tags are block identities, not continuous samples.
    delta = F(1, 10000)
    t = F(1, 2)
    area = (t - F(7, 20) - 2*delta) * (t - F(1, 20) - 2*delta)
    weights = [F(9, 25), F(16, 25)]
    base = sum(w*w for w in weights)
    info = -sum(iv(w)*iv(w).log() for w in weights)
    assert area == F(1684501, 25000000)
    assert base == F(337, 625) and F(100)*t*t == 25
    assert info > 0 and info < arb(2).log()
    for theta in (F(1, 8), F(1, 2), F(1), F(2), F(4)):
        b = iv(theta)
        # Event: the tag equals the actual second source block, whose tag
        # is a full reveal only under the actual joint q,xi law.
        assert b < info + (1 + (b.exp()-1)*iv(base)).log()
    print("positive-density tag test", bits, "bits, receiver area", area,
          "true incidence", 100*area, "true hit", 1, "reference hit", base,
          "marginal KL", 0, "joint KL", info.str(12))
    return sum(1 for _ in weights)


def geometric_tests(bits):
    ctx.prec = bits
    outcomes = []
    for j in (16, 64, 256, 1024, 16384, 65536):
        n = arb(2)**j
        ell = (n+2).log()
        H = n.sqrt()*ell
        delta = 2/H
        # Normalize layer-cake cost by sqrt(n)*ell; use the stated scale bound
        # for the number of absolute price bins rather than subtract 1 from exp(log(2)/n).
        cap_ratio = n*ell*delta*(2+(1/delta).log())/H
        assert cap_ratio > 0 and cap_ratio < 4
        bin_upper = 2 + n*(n/arb(2).log()).log()/arb(2).log()
        assert bin_upper < 4*n*ell
        for name, log_k_plus_one in (("polynomial", 3*ell), ("exp_sqrt", n.sqrt()),
                                      ("exp_n_over_log", n/ell), ("exp_n", n)):
            a = 4*(2*ell+log_k_plus_one)
            # If a>n, the close-pair lemma is inapplicable.
            if sign(n-a) == "-":
                status = "a>n"
            else:
                rho = ((a/n)*(1+(n/a).log())).sqrt()
                h_upper = 24*n*rho+16*ell
                status = "valid" if sign(n-h_upper) == "+" and sign(1-8*rho) == "+" else "coarse cut required"
                if status == "valid":
                    # Integer k need not be materialized. log M<=2n*rho.
                    assert sign((h_upper/2)-4*n*rho-2*n*rho-4*ell) == "+"
                    # exp(a/4) times the far reference, with K<=exp(log_k_plus_one).
                    # a/4=2*ell+log(1+K); cancel the common value before
                    # interval evaluation, since log(1+K) can exceed 2**30000.
                    assert bin_upper.log() < 2*ell
            outcomes.append((j, name, status))
            print("parameter", bits, "log2(n)", j, "log(1+K)", name, status)
    return outcomes


def main():
    print("Python", sys.version.split()[0], "python-flint", flint.__version__,
          "FLINT", flint.__FLINT_VERSION__)
    for name in ("endpoint819.py", "recapture819.py"):
        result = subprocess.run([sys.executable, "-B", str(HERE / name)],
                                check=True, capture_output=True, env={**os.environ, "PYTHONHASHSEED": "0"})
        print(name, "stdout sha256", sha256(result.stdout).hexdigest())
        print(result.stdout.decode().rstrip())
    for bits in (256, 384):
        entropy_test(bits)
    assert geometric_tests(256) == geometric_tests(384)
    print("PASS: source cuts and actual endpoint allocation, true positive-density sample, entropy and dimension tests.")


if __name__ == "__main__":
    main()
