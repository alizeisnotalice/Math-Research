"""Exact clipped true slices of the cubical average on positive periodic densities."""
from fractions import Fraction as F
from math import comb, isqrt
import sys


def source_weights(n, spikes, erased, delta):
    # sigma=(3/2)*product g_i on [0,4]^n, eta=sigma. Each spiky factor
    # is 1/delta on the first delta fraction of each period, 0 elsewhere.
    # Every receiver in [1,3]^n is a true strict witness at side 1.
    assert 0 <= spikes <= n and 1 <= erased <= n
    period = F(1, 16*n)
    density = F(3, 2)
    # Any length l>=1 contains full periods plus at most one period's mass
    # in its remaining part (by periodicity even if this part wraps).
    assert density * (1+period) ** spikes < 2
    threshold = F(isqrt(n), erased)
    parts = []
    for active_spikes in range(max(0, erased-(n-spikes)), min(spikes, erased)+1):
        chance = F(comb(spikes, active_spikes)*comb(n-spikes, erased-active_spikes),
                   comb(n, erased))
        actual_slice = density / delta ** (spikes-active_spikes)
        retained = min(F(1), threshold / actual_slice)
        parts.append((chance, retained))
    assert sum(p for p, _ in parts) == 1
    one = sum(p*w for p, w in parts)
    two = sum(p*w*w for p, w in parts)
    marked = sum(p*(1-(1-w)**2) for p, w in parts)
    assert marked == 2*one-two and 0 < one <= 1 and 0 < marked <= 1
    receiver_volume = 2 ** n
    original = density ** 2 * receiver_volume
    source = density * 4 ** n
    assert original/source == F(3, 2**(n+1))
    print(f"n={n}, spike axes={spikes}, averaged axes={erased}, "
          f"delta={delta}, threshold/lambda={threshold}:",
          "one-end and either-end original shares", float(one), float(marked),
          "; exact unit-cell uncut height", density)
    return one, two


def passive_contraction():
    # One active interval sees amounts 1 and 1/2 in alternating passive
    # half-periods, through a bona fide subcut of an ambient density 3/2.
    # A unit passive average exactly integrates one period at any interior center.
    before = (F(1)**2 + F(1,2)**2)/2
    after = ((F(1)+F(1,2))/2)**2
    assert before == F(5,8) and after == F(9,16) and after/before == F(9,10)
    # Taking active solid fractions 2/3 and 1/3 gives these actual amounts.
    assert F(3,2)*F(2,3) == 1 and F(3,2)*F(1,3) == F(1,2)
    print("nonproduct true cut, passive periodic interior: square before/after, ratio",
          before, after, after/before)


if __name__ == "__main__":
    print("Python", sys.version.split()[0], "Fraction exact; displayed shares are rounded.")
    outputs = []
    for n, spikes, erased, delta in (
        (4,0,1,F(1,2)), (4,2,1,F(1,2)), (16,4,4,F(1,4)),
        (64,0,4,F(1,8)), (64,4,4,F(1,8)), (64,32,8,F(1,8)),
        (256,4,16,F(1,8)), (256,32,16,F(1,8))):
        outputs.append(source_weights(n, spikes, erased, delta))
    assert outputs[0] == (1,1) and outputs[3] == (1,1)
    assert 0 < outputs[5][0] < outputs[4][0] < 1
    assert 0 < outputs[-1][0] < outputs[-2][0]
    passive_contraction()
    print("All rational checks passed; these are slice-payment diagnostics, not extremizers.")
