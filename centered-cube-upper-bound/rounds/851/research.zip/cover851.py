"""Exact shared-Poisson cover and original double-flow payments on true boxes."""
from fractions import Fraction as F
from functools import cache
from itertools import combinations, product
import sys

CORE = F(1, 4096)
PACK = F(1, 128)
SIGMA = F(3, 2)


def physical(n, count, witness, offdiag):
    mass = SIGMA * (2 * PACK) ** n
    total_source = count * mass
    packet_centers = [F(2 * i - count + 1, 64) for i in range(count)]
    assert all(b - a > 2 * PACK for a, b in zip(packet_centers, packet_centers[1:]))
    centers = [F(2 * i - len(witness) + 1, 1024) for i in range(len(witness))]
    total_inverse_volume = F(0)
    rates, sets = [], []
    widths = []
    for i, (rate, options) in enumerate(witness):
        side = (F(1), F(5, 4), F(3, 2))[i % 3]
        core_half = CORE * side ** 2
        widths.append(core_half)
        assert 0 < rate <= 1
        assert abs(centers[i]) + core_half + 1 < 4  # all [1,2] averages of sigma equal 3/2
        assert all(abs(p - centers[i]) + core_half + PACK < side / 2
                   for p in packet_centers)
        assert core_half + PACK < side / 2
        # One transverse receiver width is multiplied by rate.
        receiver_volume = rate * (2 * core_half) ** n
        beta = receiver_volume / side ** (2 * n)  # lambda=1
        assert beta == rate * (2 * CORE) ** n
        total_inverse_volume += beta
        assert sum(prob for prob, _ in options) == 1
        for prob, labels in options:
            assert prob > 0 and len(labels) <= 2 and max(labels) < count
            rates.append(prob * beta * total_source)
            sets.append(frozenset(labels))
    assert all(b - a > u + v for a, b, u, v in zip(centers, centers[1:], widths, widths[1:]))
    entry = mass ** 2 * total_inverse_volume
    original = [[entry * (not offdiag or a != z) for z in range(count)] for a in range(count)]
    return mass, total_source, original, rates, sets


def partitions(original, rates, sets, source_mass, order):
    unassigned = set(range(len(original)))
    score = assigned = F(0)
    cut_masses = []
    assert set(order) == set(range(len(rates)))
    for i in order:
        block = unassigned & sets[i]
        unassigned -= block
        cut_mass = source_mass * len(block)
        assert cut_mass <= 2 * source_mass
        cut_masses.append(cut_mass)
        assigned += cut_mass
        score += sum(original[a][z] for a, z in product(block, repeat=2))
    assert assigned + len(unassigned) * source_mass == len(original) * source_mass
    assert sum(cut_masses) == assigned
    return score, assigned


def direct_poisson(original, rates, sets):
    # Recursive integration over first actual clock; irrelevant clocks can be ignored
    # because their witness cannot contain an unassigned source.
    weight = [[x / sum(map(sum, original)) for x in row] for row in original]

    @cache
    def score(unassigned):
        candidates = [(rate, unassigned & cut) for rate, cut in zip(rates, sets)
                      if unassigned & cut]
        if not candidates:
            return F(0)
        total = sum(rate for rate, _ in candidates)
        return sum(rate * (sum(weight[a][z] for a, z in product(block, repeat=2))
                           + score(unassigned - block)) for rate, block in candidates) / total

    return score(frozenset(range(len(original)))) * sum(map(sum, original))


def account(mass, total_source, original, rates, sets):
    count = len(original)
    p = [sum(w for w, cut in zip(rates, sets) if a in cut) for a in range(count)]
    share = [[(w / p[a] if p[a] and a in cut else F(0)) for w, cut in zip(rates, sets)]
             for a in range(count)]
    assigned_by_cut = [mass * sum(share[a][i] for a in range(count)) for i in range(len(sets))]
    assert all(x <= 2 * mass for x in assigned_by_cut)
    assert sum(assigned_by_cut) == mass * sum(x > 0 for x in p)
    assert sum(assigned_by_cut) <= total_source
    independent_selection = poisson = split = F(0)
    for a, z in product(range(count), repeat=2):
        q = sum(w for w, cut in zip(rates, sets) if {a, z} <= cut)
        union = p[a] + p[z] - q
        coassign = q / union if union else F(0)
        independent = sum(f * g for f, g in zip(share[a], share[z]))
        assert 0 <= independent <= coassign <= (q > 0)
        assert independent == (sum(w ** 2 for w, cut in zip(rates, sets) if {a, z} <= cut)
                               / (p[a] * p[z]) if p[a] and p[z] else 0)
        value = original[a][z]
        independent_selection += value * (q > 0)
        poisson += value * coassign
        split += value * independent
    # Physical partition for the independent marginals: split each real packet
    # by consecutive first-coordinate slabs whose lengths are 2*PACK*share[a][i].
    for a, vector in enumerate(share):
        length_used = 2 * PACK * sum(vector)
        assert length_used == (2 * PACK if p[a] else 0)
    return independent_selection, poisson, split, sum(assigned_by_cut), p


def compact(value):
    denom = value.denominator
    power2 = denom & -denom
    return f"{value.numerator}/{denom // power2} * 2^(-{power2.bit_length()-1})"


def run(label, n, count, witness, complete=0):
    mass, source, original, rates, cuts = physical(n, count, witness, offdiag=bool(complete))
    total = sum(map(sum, original))
    assert total > 0
    cap, shared, split, allocated, p = account(mass, source, original, rates, cuts)
    fixed, fixed_assigned = partitions(original, rates, cuts, mass, range(len(cuts)))
    assert fixed <= cap and fixed_assigned == allocated <= source
    if not complete or count <= 8:
        assert direct_poisson(original, rates, cuts) == shared
    print(f"{label}: n={n}, packets={count}, true cores={len(witness)}, marks={len(cuts)}")
    print("  |I|, S, B chosen =", *(compact(x) for x in (total, source, 2 * mass)))
    print("  allocated/S, uncovered/S, pairwise-uncovered I/|I|:",
          allocated / source, (source - allocated) / source, (total - cap) / total)
    print("  paid/|I| pairwise upper, common Poisson exact, independent endpoint split, fixed order:",
          cap / total, shared / total, split / total, fixed / total)
    print("  unpaid/|I| common, independent split, fixed:",
          (total - shared) / total, (total - split) / total, (total - fixed) / total)
    rate_unit = source * (2 * CORE) ** n
    q01 = sum(w for w, cut in zip(rates, cuts) if {0, 1} <= cut)
    print("  probe pair (0,1) p0/κ0,p1/κ0,q/κ0; common coincidence:",
          p[0] / rate_unit, p[1] / rate_unit, q01 / rate_unit, q01 / (p[0] + p[1] - q01))
    if complete:
        active = complete
        assert all(w == rates[0] for w in rates)
        assert shared == cap / (2 * active - 3)
        assert split == cap / (active - 1) ** 2
        indices = [cuts.index(frozenset((i, i + 1))) for i in range(0, active - 1, 2)]
        order = indices + [i for i in range(len(cuts)) if i not in indices]
        fixed_matching, check_mass = partitions(original, rates, cuts, mass, order)
        assert check_mass == allocated
        assert fixed_matching == 2 * (active // 2) * original[0][1]
        print("  same global order with disjoint pairs first, paid/|I|:", fixed_matching / total)


def clique(active):
    return [(F(1), ((F(1), pair),)) for pair in combinations(range(active), 2)]


if __name__ == "__main__":
    print("Python", sys.version.split()[0], "Fraction exact; sigma=3/2 on [-4,4]^n, lambda=1.")
    print("I is the exact selected true double flow; marked κ is s_y |E_y|/(lambda v_y^2) times mark probability.")
    print("All three stages choose B artificially as two equal packet masses; the general R850 B is untested.")
    run("INITIAL, one randomly marked core", 2, 4, (
        (F(1), ((F(1, 2), (0, 1)), (F(1, 2), (0, 2)))),
        (F(1, 2), ((F(1), (1, 2)),)),
        (F(1, 3), ((F(1), (0,)),)),
    ))
    run("PRESSURE, cross-pairs only", 4, 8, clique(7), complete=7)
    run("EXPANDED, cross-pairs only", 16, 17, clique(16), complete=16)
