"""R851 exact translated-grid and mass-coordinate cuts on positive box sources."""

from dataclasses import dataclass
from decimal import Decimal, localcontext
from fractions import Fraction as F
from itertools import combinations
from math import comb, floor, prod
import sys


A = F(1,4)
B = F(1,8)
ENDPOINT_MASS = F(1,64)
BACKGROUND = F(5,4)


def display(q):
    with localcontext() as context:
        context.prec = 10
        return str(Decimal(q.numerator)/Decimal(q.denominator))


def span_probability(points, period=F(1)):
    """Continuous shift replay by splitting its circle at actual endpoints."""
    breaks = sorted({F(0),period} | {p % period for p in points})
    direct = F(0)
    for lo,hi in zip(breaks,breaks[1:]):
        phase = (hi+lo)/2
        if len({floor((p-phase)/period) for p in points})==1:
            direct += (hi-lo)/period
    expected = max(F(0),1-(max(points)-min(points))/period)
    assert direct==expected
    return direct


def rank_moment_checks():
    # E[min of r uniform(-e,e)]/e = -1 + 2 int_0^1 (1-t)^r dt.
    for samples,want in ((2,F(-1,3)),(3,F(-1,2))):
        integral = sum(F((-1)**i*comb(samples,i),i+1) for i in range(samples+1))
        assert 2*integral-1 == want
    for budget in (B, F(3,4)):
        for mass in (F(0),budget/16,budget/2,budget,2*budget):
            assert span_probability((budget/3,budget/3+mass),budget)==max(0,1-mass/budget)


@dataclass(frozen=True)
class Case:
    name: str
    dimension: int
    z: F
    outer: F
    e: F
    witness_side: F
    competitors: int
    exponent: int

    @property
    def heavy_mass(self):
        return F(2)**self.exponent

    @property
    def gap(self):
        return 1-self.z+A


def make_input(case, high_axis):
    n,e = case.dimension,case.e
    a = ((A-e,A+e),)*n
    z = ((case.z-e,case.z+e),)*n
    other_axis = 1-high_axis
    spacing = (case.z-A)/(4*case.competitors)
    thin = min(e,spacing/4)
    marks = []
    for j in range(case.competitors):
        c = (A+case.z)/2 + (j-F(case.competitors-1,2))*spacing
        packet = [((A+case.z)/2-e,(A+case.z)/2+e)]*n
        packet[high_axis] = (case.outer-e,case.outer+e)
        packet[other_axis] = (c-thin,c+thin)
        marks.append(tuple(packet))
    for packet in marks:
        assert packet[high_axis][0] > 1+e
        assert packet[high_axis][1] < 1+A-e
        assert packet[high_axis][0] > case.z+e
        for i in range(n):
            if i != high_axis:
                assert a[i][1] < packet[i][0] < packet[i][1] < z[i][0]
        volume = prod(hi-lo for lo,hi in packet)
        assert case.heavy_mass/case.competitors > BACKGROUND*volume
    for p,q in combinations(marks,2):
        assert p[other_axis][1] < q[other_axis][0]
    assert A+e < case.z-e
    assert A-2*e > 0 and case.z+2*e < case.witness_side/2
    assert 1 <= case.witness_side <= 2
    assert ENDPOINT_MASS > BACKGROUND*(2*e)**n
    # sigma has density 5/4 on [-4,4]^n with overwrite by larger
    # indicated uniform packet densities, and eta is sigma cut to
    # the two endpoint packets and the marked competitors.
    # Roots x in [-e,e]^n miss every competitor for every side <=2.
    assert 1 < BACKGROUND < BACKGROUND + 2*ENDPOINT_MASS < 2
    assert case.outer+e < 2 and 1+e < 4
    # Exact pointwise range checks for several continuum boundary
    # tuples in the marked supports, including competitors.
    for low,high in ((a[high_axis][0],z[high_axis][0]),
                     (a[high_axis][1],z[high_axis][1]),
                     (a[high_axis][0],z[high_axis][1])):
        pp = span_probability((low,high))
        for u in marks[0][high_axis]:
            pt = span_probability((low,high,u))
            assert 0 < pt < pp
            assert pt/pp == (1-u+low)/(1-high+low)
    assert len(marks) == case.competitors
    return (2*e)**n * ENDPOINT_MASS**2 / case.witness_side**(2*n)


def c_moments(case,d):
    """Projection-belt endpoint mass moments, with the same-cell indicator."""
    s,e,m = case.gap,case.e,ENDPOINT_MASS
    g0 = s**d
    c1 = m*(s-e/3)**d
    # Two independently integrated source slots. In the same end packet
    # the extreme among three shifts the mean by e/2, with anchor rank
    # odds 1/3. For different packets both extreme ranks cost 1/2.
    c2 = F(2,3)*m**2*(s-e/2)**d + m**2/2*(s-2*e/3)**d
    q1 = g0 - c1/B
    q2 = g0 - 2*c1/B + c2/B**2
    assert 0 < q1 <= g0
    assert q1*q1/g0 <= q2 <= q1
    return g0,c1,q1,q2


def replay(case):
    raw_a,raw_b = (make_input(case,high) for high in (0,1))
    assert raw_a==raw_b
    n,e,s,m = case.dimension,case.e,case.gap,ENDPOINT_MASS
    level = case.heavy_mass
    assert level>=B and 2*m<B
    p2, endpoint_belt_integral, outside, _ = c_moments(case,n)
    lower_box, _, other_q1, other_q2 = c_moments(case,n-1)
    p3 = (1+A-case.outer)*lower_box
    p3_ratio = p3/p2
    assert F(0) < p3_ratio < 1
    mean_belt_outside = endpoint_belt_integral/p2
    mean_belt_inside = mean_belt_outside + level*p3_ratio
    assert mean_belt_outside < B < mean_belt_inside

    # The conditional shared-cell upper face on the exterior coordinate
    # ranges from z_j to a_j+1. All competitors are inside the remaining
    # coordinate slabs. In the projected-band case, the competitor mass
    # on the upper face's ramp is M*(t-(u-e))/(2e).
    absent_len = case.outer-e-case.z
    full_len = 1+A-case.outer-e
    tiebreak = m*e/(6*B)*(s-e/3)**(n-1)
    absent_accept = absent_len*other_q1 + tiebreak
    partial_accept = e*B/level*other_q2
    inside = absent_accept + partial_accept
    assert 0<inside<outside<p2
    assert (absent_len + full_len + 2*e)*lower_box==p2
    # When projecting ON the exterior coordinate, all competitor mass
    # is outside the belt. On the subevent the same cell holds every
    # competitor, integrate the endpoint belt with the upper face in
    # [u+e,a_j+1]. The A-anchor rank first moment is shifted by e/3.
    all_competitors_fit = full_len*lower_box
    outside_accept_heavy = full_len*other_q1 + tiebreak
    assert (1-2*m/B)*all_competitors_fit < outside_accept_heavy < all_competitors_fit
    assert 0 < outside_accept_heavy < outside
    mixed = (outside+inside)/2
    assert (1-2*m/B)*p2 <= outside
    assert partial_accept <= 2*e*lower_box
    if n==2:
        # Independent polynomial check: with one remaining projection
        # coordinate X=(a-A)-(z-Z), mean 0, variance 2e^2/3.  The
        # acceptance q(X) is affine and the shared-cell weight is s+X.
        q0 = 1-m/B
        qprime = m/(2*e*B)
        variance = 2*e**2/3
        assert other_q1 == s*q0 + qprime*variance
        assert other_q2 == s*(q0**2+qprime**2*variance)+2*q0*qprime*variance

    print(case.name, "n",n,"packets",case.competitors,"; eta_local/B >=",
          f"2^{case.exponent+3}","; z =",case.z,"outside-coordinate u =",case.outer)
    print("  P2 avg",p2,"; P3 avg",p3,"; P3/P2",p3_ratio,
          "; full huge mass in same cell given same-cell =",full_len/s)
    print("  mean true belt mass on the same-grid law, out/inside:",display(mean_belt_outside),
          display(mean_belt_inside))
    print("  final same-block / same-grid: out of belt",display(outside/p2),
          "; inside belt",display(inside/p2),"; blind e1/e2 mixture",display(mixed/p2))
    print("  inside-belt stages / same-grid: absent",display(absent_accept/p2),
          "; partially present",display(partial_accept/p2),"; full mass 0")
    print("  out-of-belt accepted with full huge mass in grid / same-grid",
          display(outside_accept_heavy/p2),
          "; true box mass on this event >= 2^"+str(case.exponent))
    raw = raw_a
    print("  raw ordered tau",display(raw),"; same grid",display(raw*p2),
          "; final out/inside/mixed",*(display(raw*p) for p in (outside,inside,mixed)))
    print("  original out-of-belt accepted mass with eta(C)>=M",display(raw*outside_accept_heavy))
    return raw,p2,p3,outside,outside_accept_heavy,inside


if __name__=="__main__":
    print("Python",sys.version.split()[0],"| exact Fraction; lambda=1, grid side 1, mass cut B=1/8.")
    rank_moment_checks()
    print("Every root has maximal height in [5/4,41/32] on the actual [1,2] scale window.")
    print("Mass cut uses the projected cumulative mass between the same actual endpoints.")
    print("Two physically realised inputs swap the exterior axis; fixed e1 distinguishes them, even mix is identical.")
    baseline = replay(Case("calibration",2,F(3,4),F(9,8),F(1,1024),F(7,4),4,0))
    pressure = replay(Case("mass pressure",2,F(3,4),F(9,8),F(1,1024),F(7,4),64,60))
    assert baseline[:-1]==pressure[:-1] and baseline[-1]>pressure[-1]
    replay(Case("near-certain grid intrusion",4,F(255,256),F(257,256),F(1,4096),F(2),128,120))
    print("All exact assertions passed; rounded display only. Prescribed B; no general high-load claim.")
