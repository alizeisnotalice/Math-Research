"""Exact positive-width multibin record competition and same-block payments."""
from collections import defaultdict
from fractions import Fraction as F
from itertools import permutations, product
from math import factorial
import sys

CORE = F(1, 4096)
PACK = F(1, 128)
SIGMA = F(3, 2)


def side_in_bin(n, j):
    scale = 2 ** 14
    lo, hi = scale, 2 * scale + 1
    target = 2 ** (j + 14 * n)
    while hi - lo > 1:
        mid = (hi + lo) // 2
        if mid ** n <= target:
            lo = mid
        else:
            hi = mid
    side = F(lo, scale)
    assert 1 <= side <= 2 and F(2) ** (j - 1) < side ** n <= 2 ** j
    return side


def true_boxes(n, count, archives, roots):
    packets = [F(2 * a - count + 1, 64) for a in range(count)]
    assert all(b - a > 2 * PACK for a, b in zip(packets, packets[1:]))
    total = sum(len(items) for _, items in archives) + len(roots)
    centers = iter(F(2 * i - total + 1, 1024) for i in range(total))
    seen = []
    mass = SIGMA * (2 * PACK) ** n
    source_total = count * mass

    def coefficient(j, width_fraction):
        s = side_in_bin(n, j)
        y, half = next(centers), CORE * s ** 2
        assert 1 <= s <= 2 and 0 < width_fraction <= 1
        assert abs(y) + half + 1 < 4
        assert all(abs(y - a) + half + PACK < s / 2 for a in packets)
        assert half + PACK < s / 2
        seen.append((y, half))
        measure = width_fraction * (2 * half) ** n
        return measure / s ** (2 * n)  # lambda=1; more than one real position per core.

    poisson = []
    for j, items in archives:
        row = []
        for frac, label in items:
            cut = frozenset(label)
            assert 0 < len(cut) <= 2 and max(cut) < count
            row.append((source_total * coefficient(j, frac), cut))
        poisson.append(row)
    raw = []
    for j, pairs in roots:
        beta = coefficient(j, F(1))
        raw.append((j, {pair: beta * mass * mass for pair in pairs}))
    assert all(b - a > u + v for (a, u), (b, v) in zip(seen, seen[1:]))
    return mass, poisson, raw


def exact_local(count, rows):
    p = [sum(rate for rate, cut in rows if a in cut) for a in range(count)]
    active = {a for a, rate in enumerate(p) if rate}
    actual = [[F(0)] * count for _ in range(count)]
    weights = F(0)
    for order in permutations(range(len(rows))):
        remaining_rate = sum(rate for rate, _ in rows)
        probability = F(1)
        unassigned = active.copy()
        blocks = []
        for i in order:
            rate, cut = rows[i]
            probability *= rate / remaining_rate
            remaining_rate -= rate
            assigned = unassigned & cut
            unassigned -= assigned
            blocks.append(assigned)
        assert not unassigned and sum(map(len, blocks)) == len(active)
        weights += probability
        for block in blocks:
            assert len(block) <= 2
            for a, z in product(block, repeat=2):
                actual[a][z] += probability
    assert weights == 1
    for a, z in product(range(count), repeat=2):
        q = sum(rate for rate, cut in rows if {a, z} <= cut)
        union = p[a] + p[z] - q
        assert actual[a][z] == (q / union if union else 0)
    return active, actual


def rank_enumeration(count, active, alpha, bins, raw, gap):
    k = len(active)
    count_orders = factorial(k)
    prior = [[set() for _ in range(count)] for _ in range(k)]
    for i in range(k):
        for a in range(count):
            prior[i][a] = {j for j in range(i + 1) if a in active[j]}
    source_visits = [0] * count
    joint_record = [defaultdict(int) for _ in bins]
    eligible = [{i for i, j in enumerate(bins) if j <= xbin - gap} for xbin, _ in raw]
    multiplicity = [F(0)] * len(raw)
    coverage = [F(0)] * len(raw)
    for priority in permutations(range(k)):
        retained = []
        low = [k] * count
        for i in range(k):
            chosen = {a for a in active[i] if priority[i] < low[a]}
            retained.append(chosen)
            for a in chosen:
                low[a] = priority[i]
                source_visits[a] += 1
            for a, z in product(chosen, repeat=2):
                joint_record[i][a, z] += 1
        for root, ((_, pairs), accepted) in enumerate(zip(raw, eligible)):
            for (a, z), weight in pairs.items():
                miss = F(1)
                for i in accepted:
                    if {a, z} <= retained[i]:
                        prob = alpha[i][a][z]
                        multiplicity[root] += weight * prob
                        miss *= 1 - prob  # independent Poisson partitions by bin
                coverage[root] += weight * (1 - miss)
    visits = [F(v, count_orders) for v in source_visits]
    harmonic = [sum(F(1, j) for j in range(1, 1 + len(prior[-1][a])))
                for a in range(count)]
    assert visits == harmonic
    for i in range(k):
        for a, z in product(range(count), repeat=2):
            union = len(prior[i][a] | prior[i][z])
            expected = F(1, union) if {a, z} <= active[i] else F(0)
            assert F(joint_record[i][a, z], count_orders) == expected
    for root, ((_, pairs), accepted) in enumerate(zip(raw, eligible)):
        per_bin = [
            sum(weight * alpha[i][a][z] / len(prior[i][a] | prior[i][z])
                for (a, z), weight in pairs.items() if alpha[i][a][z])
            for i in sorted(accepted)
        ]
        assert sum(per_bin) == multiplicity[root] / count_orders
        assert max(per_bin, default=0) <= coverage[root] / count_orders <= (
            multiplicity[root] / count_orders)
    return ([x / count_orders for x in multiplicity], [x / count_orders for x in coverage],
            eligible, visits, prior, joint_record, count_orders)


def display(n, count, label, archives, roots, gap):
    bins = [j for j, _ in archives]
    assert sorted(set(bins)) == bins
    mass, poisson, raw = true_boxes(n, count, archives, roots)
    active, alpha = zip(*(exact_local(count, rows) for rows in poisson))
    multi, cover, eligible, visits, prior, bear, orders = rank_enumeration(
        count, active, alpha, bins, raw, gap)
    returned = sum(visits) * mass
    distinct = mass * sum(v > 0 for v in visits)
    print(f"{label}: n={n}, true archive bins={bins}, root gap={gap}, priority orders={orders}")
    print("  E visits per source packet:", " ".join(map(str, visits)))
    print("  retained source mass / S, distinct/S, repeat/S:",
          returned / (count * mass), distinct / (count * mass), (returned - distinct) / (count * mass))
    print("  AB archive rows (bin, past-active A, past-active B, union, alpha, paid probability):")
    for i, b in enumerate(bins):
        ca, cz = prior[i][0], prior[i][1]
        paid = alpha[i][0][1] * F(bear[i][0, 1], orders)
        print("   ", b, len(ca), len(cz), len(ca | cz), alpha[i][0][1], paid)
    for (rootbin, weights), m, c, accepted in zip(raw, multi, cover, eligible):
        total = sum(weights.values())
        single = [sum(w * alpha[i][a][z] * F(bear[i][a, z], orders)
                      for (a, z), w in weights.items()) for i in sorted(accepted)]
        print("  root bin", rootbin, "eligible", [bins[i] for i in sorted(accepted)],
              "exact |I|", total)
        print("    paid / original I: best single, coverage, multiplicity, never covered:",
              max(single, default=0) / total, c / total, m / total, (total - c) / total)


def witness(*items):
    return tuple((F(rate), tuple(ord(letter) - ord("A") for letter in pair)) for rate, pair in items)


def actual(*pairs):
    return tuple(tuple(ord(letter) - ord("A") for letter in pair) for pair in pairs)


if __name__ == "__main__":
    print("Python", sys.version.split()[0], "Fraction exact; lambda=1; sigma=3/2 on [-4,4]^n.")
    print("Same-bin real Poisson partitions; independent uniform priority numbers across bins.")
    print("B artificially permits two equal packets. Root I uses the toy true-bin gate j<=k-gap.")
    print("Priority comparisons include all preceding bins with p_i>0; the general L_y gate is untested.")
    display(4, 4, "INITIAL", (
        (0, witness(("1", "AB"), ("1/2", "AC"))),
        (1, witness(("1/2", "AB"), ("1", "BD"), ("1/4", "CD"))),
        (2, witness(("1", "AB"), ("1/2", "BC"), ("1/2", "AD"))),
    ), ((3, actual("AB", "BA")), (2, actual("AB", "BA", "AC", "CA"))), 1)
    display(6, 5, "ASYMMETRIC COMPETITION", (
        (0, witness(("1", "AC"), ("1/2", "AD"))),
        (1, witness(("1", "BC"), ("1/3", "BD"))),
        (2, witness(("1", "AD"), ("1/2", "DE"))),
        (3, witness(("1", "AB"), ("1", "AE"), ("1/2", "BD"))),
        (4, witness(("1", "AB"), ("1/2", "BC"))),
    ), ((5, actual("AB", "BA")), (3, actual("AB", "BA"))), 1)
    display(8, 6, "EXPANDED", (
        (0, witness(("1", "AB"), ("1/2", "CD"))),
        (1, witness(("1", "AC"), ("1/2", "BD"), ("1/4", "EF"))),
        (3, witness(("1/2", "AB"), ("1", "AE"), ("1/4", "BF"))),
        (4, witness(("1", "DE"), ("1/2", "CF"))),
        (5, witness(("1", "AB"), ("1/3", "AC"), ("1/2", "BE"))),
        (7, witness(("1/2", "DF"), ("1", "AC"), ("1/2", "BE"))),
    ), ((7, actual("AB", "BA")), (6, actual("AB", "BA", "DE", "ED"))), 2)
