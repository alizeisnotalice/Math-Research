"""R851: continuous passive-block square energy and huge-parameter signed logs."""

from fractions import Fraction as F
from math import ceil, isqrt, prod
import sys

from flint import arb, ctx, __version__ as flint_version


def average(l, left, right, center):
    overlap = min(right,center+l/2) - max(left,center-l/2)
    return max(F(0),overlap)/l


def square_energy(l, source, receivers):
    left,right = source
    low,high = receivers
    faces = (left-l/2,left+l/2,right-l/2,right+l/2)
    knots = sorted({low,high} | {x for x in faces if low<x<high})
    total = F(0)
    for a,b in zip(knots,knots[1:]):
        v0 = average(l,left,right,a)
        v1 = average(l,left,right,b)
        total += (b-a)*(v0*v0+v0*v1+v1*v1)/3
    return total


def lattice_average(l,h):
    reach = ceil(l/(2*h))+2
    return sum(square_energy(l,(j*h,(j+1)*h),(F(0),h))
               for j in range(-reach,reach+1))/h


def expected_ratio(l,h):
    r = h/l
    if r<=1:
        return r-r*r/3
    return 1-1/(3*r)


def passive_geometry():
    one = F(1)
    source = (F(0),one)
    triangle = square_energy(one,source,(F(-1,2),F(3,2)))
    in_cell = square_energy(one,source,(F(0),one))
    left_edge = square_energy(one,source,(F(-1,2),F(0)))
    right_edge = square_energy(one,source,(one,F(3,2)))
    assert (triangle,in_cell,left_edge,right_edge)==(F(2,3),F(7,12),F(1,24),F(1,24))
    assert triangle==in_cell+left_edge+right_edge
    print("l=h=1, 1D single cut: full receiving line",triangle,"; receiver in same source cell",in_cell,
          "; each exterior boundary",left_edge)

    count = 0
    for l in (F(1),F(3,2),F(2)):
        for h in (F(1,4),F(1,2),F(1),F(3,2),F(2),F(3)):
            full = square_energy(l,(F(0),h),(-l/2,h+l/2))
            assert full/h == lattice_average(l,h) == expected_ratio(l,h)
            if h==l:
                # K_l is the overlap average divided by source mass l.
                assert full/l**2==2/(3*l)
            count += 1
    print("Both a direct single-cell integral and a translated period replay verified",count,"(l,h) pairs.")
    print("True finite-domain boundary check, N=7: uncut full-line N-1/3, source receivers N-5/12.")
    N = F(7)
    assert square_energy(one,(F(0),N),(F(-1,2),N+F(1,2))) == N-F(1,3)
    assert square_energy(one,(F(0),N),(F(0),N)) == N-F(5,12)
    assert square_energy(one,(F(0),N),(F(1,2),N-F(1,2))) == N-1

    unit = lattice_average(one,one)
    quarter = lattice_average(one,F(1,4))
    assert (unit,quarter)==(F(2,3),F(11,48))
    print("Inner receivers are one unit from the support boundary; cuts below use l=1.")
    for k in (1,4,16):
        # True Euclidean intervals with even lengths N_j. The interiors
        # [1,N_j-1] contain the whole original side window [1,2].
        # Telescoping keeps the uncut I/S fixed across k.
        sizes = tuple(F(2*(64*k+j)) for j in range(1,k+1))
        source_mass = prod(sizes)
        inner_energy = prod(x-2 for x in sizes)
        assert inner_energy/source_mass == F(64,65)
        partition_unit = inner_energy * unit**k
        partition_quarter = inner_energy * quarter**k
        print("  k",k,"; passive side range",str(sizes[0])+".."+str(sizes[-1]),
              "; true uncut inner I/S",inner_energy/source_mass,
              "; cut/uncut inner h=1:",partition_unit/inner_energy,
              "; h=1/4:",partition_quarter/inner_energy)


def integer_ceil_cuberoot(x):
    upper = 1 << ((x.bit_length()+2)//3)
    lower = 0
    while upper-lower > 1:
        mid = (upper+lower)//2
        if mid**3 >= x:
            upper = mid
        else:
            lower = mid
    assert (upper-1)**3 < x <= upper**3
    return upper


def logarithmic_checks():
    ctx.prec = 192
    log2 = arb(2).log()
    print("192-bit Arb: k=ceil(m^(2/3)), n=m+k, J=ceil(ln(n+2)^2), M=n^2*2^(bJ).")
    print("log2 of sqrt(2M)*(1+m ln 2)*[sqrt(2/3)*(1+2/(R-1))]^k.")
    print("R=2T+1, T=floor(n/(b+1)); compute only an integer exponent and real logs.")
    signs = {}
    for exponent in (6,12,18,21,22,23,24,36):
        m = 10**exponent
        k = integer_ceil_cuberoot(m*m)
        n = m+k
        b = isqrt(n-1)+1
        T = n//(b+1)
        R = 2*T+1
        assert (b-1)**2 < n <= b*b
        assert T*(b+1)<=n<(T+1)*(b+1) and T>0
        j_ball = (arb(n+2).log()**2).ceil()
        j = j_ball.unique_fmpz()
        assert j is not None
        j = int(j)
        arg = arb(n+2).log()**2
        assert j-1 < arg < j

        origin = (1+arb(b)*j)/2 + arb(n).log()/log2
        arity = (1+arb(m)*log2).log()/log2
        passive = (arb(2)/3).log()/2 + (1+arb(2)/(R-1)).log()
        total = origin + arity + k*passive/log2
        # Equivalent expression reducing the factor as a positive Arb
        # square-root and logging its full product. Still no huge power.
        factor = (arb(2)/3).sqrt()*(1+arb(1)/T)
        alternative = origin + arity + k*factor.log()/log2
        assert total.overlaps(alternative)
        sign = 1 if total>0 else -1 if total<0 else 0
        assert sign
        signs[exponent] = sign
        print("  m=10^"+str(exponent), "k",k,"b",b,"T",T,"J",j,"; log2",total.str(10))
    assert signs[6]==signs[12]==signs[21]==1
    assert signs[22]==signs[24]==signs[36]==-1
    print("Positive logs leave the bound above 1. Negative logs certify it below 1 only at tested dimensions.")


if __name__ == "__main__":
    print("Python",sys.version.split()[0],"python-flint",flint_version,"| exact Fraction and 192-bit Arb")
    passive_geometry()
    logarithmic_checks()
    print("All assertions passed; no general unsplit energy decay inferred.")
