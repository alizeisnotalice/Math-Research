"""Exact same-source restart on the R850 real-box kernels."""
from argparse import ArgumentParser
from collections import defaultdict
from fractions import Fraction as F
from pathlib import Path
from runpy import run_path
from zipfile import ZipFile
import sys


def handoff(path):
    if path.suffix == ".zip":
        with ZipFile(path) as bundle:
            members = [name for name in bundle.namelist()
                       if Path(name).name == "handoff850.py"]
            assert len(members) == 1
            source = bundle.read(members[0])
        env = {"__name__": "r850_fixture", "__file__": members[0]}
        exec(compile(source, members[0], "exec"), env)
        return env
    assert path.name == "handoff850.py"
    return run_path(str(path))


def marginal(v, p):
    dest = [F(0)] * len(v)
    for e, value in enumerate(v):
        for f, prob in p[e].items():
            dest[f] += value * prob
    return dest


def restart_kernel(time, delta, a):
    couplings = [{} for _ in delta]
    for w in (0, 1):
        # Optimality is not needed: matching scalar cumulative source mass
        # in increasing bin/core order gives the claimed one-sided handoff.
        sorted_states = sorted(range(len(delta)), key=lambda e: (time[e], e))
        old = [(e, delta[e]) for e in sorted_states if e % 2 == w and delta[e]]
        new = [(f, a[f]) for f in sorted_states if f % 2 != w and a[f]]
        assert sum(x for _, x in old) == sum(x for _, x in new)
        i = j = 0
        while i < len(old) and j < len(new):
            e, left = old[i]
            f, right = new[j]
            assert time[e] <= time[f]
            change = min(left, right)
            couplings[e][f] = change
            old[i] = (e, left - change)
            new[j] = (f, right - change)
            i += change == left
            j += change == right
        assert i == len(old) and j == len(new)
    jmat = [{f: x / delta[e] for f, x in row.items()} for e, row in enumerate(couplings)]
    assert all(sum(row.values()) == bool(delta[e]) for e, row in enumerate(jmat))
    assert marginal(delta, jmat) == a
    return jmat, couplings


def audit_cuts(n, time, mu, p, delta, a):
    edges = [(e, f, mu[e] * prob) for e, row in enumerate(p) for f, prob in row.items()]
    assert all(e % 2 != f % 2 and time[f] < time[e] for e, f, _ in edges)
    tail_sums = []
    for w in (0, 1):
        total = F(0)
        for j in range(n + 2):
            old = sum(delta[e] for e in range(w, len(mu), 2) if time[e] >= j)
            new = sum(a[f] for f in range(1 - w, len(mu), 2) if time[f] >= j)
            cross = sum(x for e, f, x in edges if e % 2 == w and time[e] >= j > time[f])
            assert new - old == cross
            total += cross
        direct = sum(x * (time[e] - time[f]) for e, f, x in edges if e % 2 == w)
        assert direct == total
        tail_sums.append(total)
    return tail_sums


def cycles(a, mu, p, delta, kills):
    flowing = a.copy()
    occupancy = [F(0)] * len(mu)
    terminal = occupancy.copy()
    stop_levels = []
    while any(flowing):
        stop = [x * kill for x, kill in zip(flowing, kills)]
        stop_levels.append(sum(stop))
        occupancy = [a + b for a, b in zip(occupancy, flowing)]
        terminal = [a + b for a, b in zip(terminal, stop)]
        flowing = marginal(flowing, p)
    assert occupancy == mu and terminal == delta
    total = sum(delta)
    length = sum((r + 1) * weight for r, weight in enumerate(stop_levels)) / total
    assert length == sum(mu) / total
    return length, [x / total for x in stop_levels]


def check(model, n, h):
    rows, t, packet = model["real_fixture"](n)
    p, _, _, _ = model["kernels"](rows, n, h)
    time = [row.bin for row in rows for _ in (0, 1)]
    mu = [row.fraction for row in rows for _ in (0, 1)]
    assert sum(mu) == 118
    incoming = marginal(mu, p)
    kills = [1 - sum(row.values()) for row in p]
    a = [m - y for m, y in zip(mu, incoming)]
    delta = [m * k for m, k in zip(mu, kills)]
    assert min(a) >= 0 and min(delta) >= 0
    assert sum(a) == sum(delta) > 0
    crossing = audit_cuts(n, time, mu, p, delta, a)
    j, cpl = restart_kernel(time, delta, a)
    actual = []
    for e, row in enumerate(p):
        joined = defaultdict(F, row)
        for f, weight in j[e].items():
            joined[f] += kills[e] * weight
        # Zero-death rows can use an arbitrary restart, which is multiplied by 0.
        assert sum(joined.values()) == 1
        actual.append(joined)
    assert marginal(mu, actual) == mu
    length, stop_levels = cycles(a, mu, p, delta, kills)
    jump = defaultdict(F)
    for e, row in enumerate(cpl):
        for f, x in row.items():
            assert e % 2 != f % 2
            jump[time[f] - time[e]] += x
    total = sum(delta)
    average_jump = sum(gap * x for gap, x in jump.items()) / total
    assert average_jump == sum(crossing) / total
    assert sum(jump.values()) == total
    if n == 64 and h == 7:
        assert (length, average_jump) == (F(177, 140), F(333, 140))
    if n == 64 and h == 8:
        assert (length, average_jump) == (F(1416, 667), F(7494, 667))
    e, f = max(((e, f) for e, row in enumerate(cpl) for f in row if time[f] > time[e]),
               key=lambda pair: cpl[pair[0]][pair[1]])
    z, y = rows[e // 2], rows[f // 2]
    print(f"n={n}, H/t={h}; {2 * (n + 2)} exact source/cut checks; mu0=t*pack_mass/2")
    print("  |mu|/mu0, |A|/mu0=|Delta|/mu0, occupation-cycle length:", sum(mu), total, length)
    print("  zero birth columns, zero terminal rows:", a.count(0), delta.count(0))
    print("  mean true-bin up-jump, strictly positive share, support:",
          average_jump, 1 - jump.get(0, 0) / total, sorted(jump))
    print("  terminal by original path depth, normalized by |Delta|:",
          " ".join(str(x) for x in stop_levels))
    print("  actual restart witness (slot,true bin,phase,x) -> (...), paired mass/mu0:",
          (z.slot, z.bin, e % 2, z.x), (y.slot, y.bin, f % 2, y.x), cpl[e][f])
    print("  exact mu[P+(1-P1)J]=mu; A sum(P^r)=mu; terminal=Delta.")


if __name__ == "__main__":
    parser = ArgumentParser()
    parser.add_argument("--handoff", type=Path, default=Path(__file__).with_name("handoff850.py"),
                        help="R850 handoff850.py, or its archived research.zip")
    arg = parser.parse_args()
    print("Python", sys.version.split()[0], "Fraction exact; dependency handoff850.py (possibly in ZIP).")
    print("Actual end point is shared on each positive-width packet: terminal retained -> root private.")
    print("The new receiver and the other source point use their true conditional core/packet laws.")
    fixture = handoff(arg.handoff)
    for n, h in ((64, 7), (64, 8), (256, 8)):
        check(fixture, n, h)
