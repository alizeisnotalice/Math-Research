from itertools import combinations,product
from fractions import Fraction as F
import json, platform, sys, subprocess
from pathlib import Path

def blocks(words,n):
    pool=set(words);groups=[]
    while True:
        for a,b in combinations(range(n),2):
            rep={}
            for v in sorted(pool):rep.setdefault(((v>>a)&1,(v>>b)&1),v)
            if len(rep)==4:break
        else:break
        g=tuple(rep[k] for k in sorted(rep));groups.append(g);pool.difference_update(g)
    varying=sum(len({v>>j&1 for v in pool})>1 for j in range(n))
    assert len(pool)<=1+varying
    assert len(pool)+sum(map(len,groups))==len(set(words))
    return len(groups),len(pool)

def peel(edges,w,d,delta,remote):
    live=set(range(len(edges)));removedrows=set();removedcols=set();costrow=costcol=F(0);rounds=0
    while live:
        if remote:
            rows={x:sum((w[c] for k,(c,g) in enumerate(edges) if k in live and x in g),F(0)) for x in {v for _,g in edges for v in g}}
            cols={c:sum(len(g) for k,(s,g) in enumerate(edges) if k in live and s==c) for c in w}
        else:
            rows={};cols={}
            for k in live:
                c,g=edges[k];cols[c]=cols.get(c,0)+len(g)
                for x in g:rows[x]=rows.get(x,F(0))+w[c]
        low={x for x in rows if 0<rows[x]<delta}
        bad={c for c in cols if 0<cols[c]<=d[c]}
        if not low and not bad:break
        assert not (low&removedrows or bad&removedcols);removedrows|=low;removedcols|=bad
        drop=set()
        for k in live:
            c,g=edges[k];val=len(g)*w[c]
            if c in bad:costcol+=val
            elif low.intersection(g):costrow+=val
            else:continue
            drop.add(k)
        live-=drop;rounds+=1
    assert costrow<=4*delta*len(removedrows)
    assert costcol<=sum((w[c]*d[c] for c in removedcols),F(0))
    total=sum((w[c]*len(g) for c,g in edges),F(0))
    rest=sum((w[edges[k][0]]*len(edges[k][1]) for k in live),F(0))
    assert rest+costrow+costcol==total
    return [len(edges),rounds,len(live),str(rest),str(costrow),str(costcol)]

def runs(remote):
    data=[]
    for n in (3,6,9):
        words=list(range(1<<n))
        for family in (words,[x for x in words if x.bit_count()<=1],[x for x in words if x%5 in (1,3)]):
            data.append([n,len(family),*blocks(family,n)])
    # Equal colour classes are matchings; each atom has unit measure.
    for size in (8,32,128):
        edges=[(k%2,(k,k+1)) for k in range(size)]
        edges += [(2,(size+1+i,size+1+(i+1)%4,size+1+(i+2)%4,size+1+(i+3)%4)) for i in (0,)]
        for budget in (0,4):
            data.append(peel(edges,{0:F(1,4),1:F(1,4),2:F(1,2)},{0:budget,1:budget,2:budget},F(3,8),remote))
    return data
if '--mac' in sys.argv:
 print(json.dumps([platform.python_version(),runs(True)]));sys.exit()
local=runs(False)
cmd=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=8','macbook-math','/Users/zhengzhihao/.venv/bin/python -B - --mac']
p=subprocess.run(cmd,input=Path(__file__).read_text(),capture_output=True,text=True,check=True,timeout=100);rv,result=json.loads(p.stdout);assert result==local
from flint import arb,ctx
from math import isqrt
ctx.prec=256;hist=[]
for n in (256,1024,4096):
 a=32*n;K=4096*isqrt(n)*a**n;ell=arb(2).log()/K
 h=1+arb(1)/a;b=arb(2)**(arb(1)/n);half=h*b
 for mult in (1,2):
    r=arb(mult)/isqrt(n);u=h*r
    assert half-(1-r/4)<r and half+r/a<1.5 and half>r
    assert 7*r/8+r/a<r and 1-r/8+7*r/8-r/a>1+arb(6)/n
    assert 1-r/8+7*r/8+r/a-u<1
    assert 2*h*n*r/arb(n).log()>=1
    V=4*(2*r/a)**n;R=V*ell.expm1()/2
    G=n*arb(a).log()+(K-5)*n*arb(4).log()+(-(-ell).expm1()).log()
    assert 0<R and R<V/4 and G>(4*arb(8)**n+4).log()
    assert ell.expm1()/2<arb(1)/64
    hist.append(dict(n=n,radius_multiple=mult,V=str(V),R=str(R),logD_div_K=[str(G/K),str((G+arb(3).log())/K)],blocks_per_occupied_phase=1 if mult==1 else 2,post_peel=0))
print(json.dumps(dict(local=sys.executable,version=platform.python_version(),remote=rv,cmd=cmd,cases=local,histories=hist),indent=2))
