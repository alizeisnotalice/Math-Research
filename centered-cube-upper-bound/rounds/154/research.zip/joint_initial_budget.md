# R154：共同储备的非线性初端预算及其精确适用边界

状态：JI1–JI8 是一般原来源下的严格估计与策略筛选；没有证明新的根阶接收付款。新增可核节省来自非线性闭式 M，不能来自其线性化背包预算：后者在原合法行恒退化。M-tail 在下降侧又被实际 A 峰值支配，因此真正尚待验证的空间机制已缩至上升侧的同点双核覆盖。初端、good 注入及一般大 β 的全部费用仍未闭合。仅写本文件，不改其他作者或 Git。

## JI1. 原对象、有限性与共同 α 约束

固定原合法有限行与时刻 t∈[τ,h]，切口 r，令 a=(r+1)c、0<c≤e_g，保持原 E_*⊂E_+、D0、ν、ρ、α、T、D、J、K0、Q_J。以下主要用于 t=τ；不把随 t 变化的 U,V,R 或 L 视为统一 B 的 primitive。

令 f_r(u)=w_t(u)1_{k_t(u)≤r}，并定义

\[
\begin{split}
 U&=\int_{E_*}w_t1_{k_t>r}
       \left(1-\frac{DK_0}{T\Delta}\right)_+d\nu,\\
 V&=\int_{E_*}w_t1_{k_t>r}\frac{J}{T\Delta}d\nu,
 \qquad \Delta=w_\tau-w_h>0,\\
 A&=U-\alpha V,\qquad B=\int_{D_0}f_r\,d\nu,\\
 K_D&=\int_{D_0}K_0\,d\nu,
 \qquad R_L=\int_{D_0}(f_r-LK_0)_+d\nu\quad(L>0).
\end{split}
\tag{JI1}
\]

U 是本稿聚合量，不是生产脚本 sourcewise min(TΔ,DK0) 的同名量。主分支假设 D>0、Q_J>0、V<∞；原共同余额和实际非负 A 给

\[
 DK_D\le\alpha Q_J,\quad \alpha V\le U,
 \quad B\le LK_D+R_L.
\]

所以对 γ_L=DV/(LQ_J) 有

\[
 \boxed{A+\gamma_L(B-R_L)_+\le U.}
 \tag{JI2}
\]

U≤e_t<∞，B≤e_t<∞。α>0 时 αV≤U 本身保证 V 有限；没有假设 ν 独立，也没有另取 α。K_D 有限由原余额得到（原 α、Q_J 有限）。真正的 Q* 三核容量与 Q_J 仍是原量，不因筛选重新归一化。

零支按以下方式处理。

* U=0：A=0，初端势为零，无需除 U 或 V。
* V=0：A=U，γ=0；可直接使用自由 A 峰值，无尾项，无储备增益。
* α=0、V<∞：原余额给 K_D=0，故 R_L=B；JI2 形式仍合法，但没有非尾坏质量。若 α=0、V=∞，禁止把 0·∞ 当可除表达式，只从原逐源 ρ 公式积分得 A=U 并使用自由帽。
* Q_J=0：不定义 γ=0/0。若原合同仍给有限 α 且 D>0，余额给 K_D=0，R_L=B；仅使用原 A 的自由帽。D=0 也不给本稿储备收益。
* Δ=0 的来源不在本稿原 E_+ 有效分母合同内。不得人为赋 J/(TΔ)=0 后领取预算。

这些分支都不把原 ν 换成外 β。

## JI2. 无尾联合域的准确最大值

对 U>0、0≤γ<∞，置

\[
 M(U,\gamma)=
 \frac{U^2}{\left[\sqrt{a(U+c\gamma)}
              +\sqrt{(U+a\gamma)(U+c)}\right]^2}.
 \tag{JI3}
\]

则

\[
 \boxed{\sup_{A,B\ge0:\ A+\gamma B\le U}
 \frac{AB}{(B+a)(A+B+c)}=M(U,\gamma).}
 \tag{JI4}
\]

证明：势 Ψ 随 A 非减；B>0 时严格增。可令 A+γB=U。以 z=B/A>0 参数化，Ψ 的分母除以其分子中的 z 后为

\[
 \frac{a(U+c)}z+
 \{a(U+c\gamma)+(U+a\gamma)(U+c)\}
 +(U+a\gamma)(U+c\gamma)z.
\]

第一、三项的和在

\[
 z_* =\sqrt{\frac{a(U+c)}{(U+a\gamma)(U+c\gamma)}}
\]

取最小值；代回即 JI3。γ=0 也成立，A=U，B=z_*U。因而

\[
 M(U,0)=\frac{U}{(\sqrt a+\sqrt{U+c})^2},\qquad
 M(U,\gamma)\le\frac{U}{a\gamma}\quad(\gamma>0).
 \tag{JI5}
\]

后一式只是较粗线性化，不能保留 JI3 的全部联合收益。由于约束域随 γ 增大而缩小，M 关于 γ 非增。

## JI3. 同点真实坏尾的闭式预算

对原实际 A,B，DG2 给

\[
 (\partial_B\Psi)_+\le\frac{A}{a(A+c)}
 \le\frac{U}{a(U+c)}=:\lambda_U.
\]

γ_L>0 时取 B0=min{B,(U−A)/γ_L}。JI2 保证 B−B0≤R_L，且 (A,B0) 位于 JI4 的无尾域。因此

\[
 \boxed{\Psi(A,B)\le
 F_L:=M(U,\gamma_L)+\lambda_U R_L.}
 \tag{JI6}
\]

这一步只对增加 B 的正导数作上界；不假定 Ψ 对 B 全局单调。γ=0 时直接用 JI5，不需 B0。保持所有实际量，可取 inf_{L>0}F_L。R_L 关于 L 连续：被 f_r 支配且原 f_r 可积，因此可将 inf 限于正有理数，得到可测量，不需要无价外部选择器。此点态取 inf 不是关于时间的 FTC。

较旧逆核矩归约，JI6 保留 V/U 中的实际 J 加权均值与同一 x 的 K0 截断尾 R_L。没有使用 U²/V≤∫w_tTΔ/J 的 CS，也没有把 R_L 或 Q*/r 当免费容量。它是一条来源预算上界，不是空间付款。

更直接的来源覆盖证书是保留

\[
 C_L:=\int_{D_0}\min\{f_r,LK_0\}\,d\nu,
 \qquad R_L=B-C_L.
\]

以下 JI7 限于 U>0 主分支，此时 λ_U>0；U=0 按 JI1 直接作零势处理。对给定可核目标 b≥0，JI6 的右侧≤b 当且仅当

\[
 \boxed{M(U,\gamma_L)\le b,\qquad
 C_L\ge B-\frac{b-M(U,\gamma_L)}{\lambda_U}.}
 \tag{JI7}
\]

第二个条件在右端非正时自动满足。证书必须使用同一 x 的实际 K0、J、ν、Q_J 和 U,V，不能分别优化两核。它使“非线性储备增益能覆盖多少坏尾”变成显式源积分检验；本稿没有证明该证书在足够多接收点上成立。

## JI4. 线性化背包路径在原合同上恒退化

把 JI5 代入 JI6 会得到

    Ψ≤λ_U inf_{L>0}{κL+R_L},
    κ=Q_J(U+c)/(DV)。

但是在 V,D,Q_J>0 的实际原行上，JI1 已强制

\[
 K_D\le\frac{\alpha Q_J}{D}
       \le\frac{UQ_J}{DV}
       <\frac{(U+c)Q_J}{DV}=\kappa.
\]

故对所有 0≤f≤1，∫D0K0 f dν≤κ：所谓背包约束允许整个 D0。一般测度下也无需调用强对偶，直接有

\[
 \kappa L+R_L\ge B+L(\kappa-K_D)\ge B,
 \qquad\lim_{L\downarrow0}R_L=B.
\]

因此

\[
 \boxed{\inf_{L>0}\{\kappa L+R_L\}=B.}
 \tag{JI8}
\]

K0=0 的自由尾完整包含于 B；极限由 0≤(f_r−LK0)+≤f_r 与主导收敛保证。原始最大化也由 f≡1 取得 B。该精确结论同时覆盖有限与一般来源，不需另造有限 LP 或假设严格对偶。

这条路线不是尚待加强的空间工具，而是已被原共同 α 可行性证明没有新收益：它恒退化为 Ψ≤UB/[a(U+c)]。后续不能引用“背包容量”来支付同一尾。

## JI5. 必须与实际 A 峰值比较：下降侧没有新收益

两条已有强基线是

\[
 P_A=\frac{A}{(\sqrt a+\sqrt{A+c})^2},\qquad
 P_B=\frac{B}{B+a},\qquad \Psi\le\min\{P_A,P_B\}.
\]

定义 B*=√{a(A+c)}。如果当前 B≥B*，则对每个 L，JI2 也在 (A,B*) 成立，因为 (B*−R_L)+≤(B−R_L)+。将 JI6 的统一域估计用于这个点，有

\[
 \boxed{F_L\ge\Psi(A,B*)=P_A,
 \qquad\inf_LF_L\ge P_A\quad(B\ge B*).}
 \tag{JI9}
\]

所以非线性 M-tail 在整个 DG6 坏侧正注入区域及边界均不能改进实际 A 自由峰值。此为精确支配定理，不是浮点观察；大 β 不能自动算作 M 的新覆盖。

唯一可能有新初端收益的区域是 B²<a(A+c)。这不是保证付款：可以 B 大而 A 更大，也可以仅小 B。上升侧确有严格代数收益的精确例：A=B=a=c=1、γ=1/4、U=5/4、R=0 时 M=1/6，且

    1/6 < 1/(1+√2)² = P_A，P_B=1/2。

第一不等式等价于 2√2<3，即 8<9。这里联合边界恰为 Ψ 的切线约束。此例仅证标量估计不是恒被两个基线支配；没有声称这些标量已由 FULL 原核/α/接收配置实现，更不把它当根阶空间证据。

## JI6. 原外价、尚未付域与下一条准确命题

用于初端 t=τ，定义可计算的非负预算

\[
 Z_r:=\min\left\{P_{A_r},P_{B_r},
     \inf_{L\in\mathbb Q_{>0}}F_{r,L}\right\},
\]

零支依 JI1 定义。则 Σ_rΨ_r(τ)≤Σ_r Z_r。原 DG5/ST15 的初端正费用因此满足

\[
 \boxed{\frac{128\Lambda}{3}\mathbb E\sum_{V,j}
 \int p(x-y)\sum_r\Psi_r(\tau)\,dx\,d\beta_V(y)
 \le\frac{128\Lambda}{3}\mathbb E\sum_{V,j}
 \int p(x-y)\sum_r Z_r\,dx\,d\beta_V(y).}
 \tag{JI10}
\]

原 hard 16/3 已包含于前因子；β≠ν；没有时间积分故不再收 log2。实际 j、soft/尺度/history 及所有原选择保留；未取得共同帽前不能先消 j 或将实际接收核免费归一。

JI10 不是新的付款。只有点态严格降低，并不保证可积到根阶。由 JI9，在下降侧 Z_r 等于已有基线 min(P_A,P_B)；新收益只能在实际区域

    B_r(τ)^2<a(A_r(τ)+c)，且某个同点 L 使 F_{r,L}<min(P_A,P_B)

上出现。准确的下一空间命题是：在这个上升侧上，构造可测的实际 L_r(x,ω,V,j,y) 与目标 b_r，使 JI7 的同点双核覆盖证书成立，并以原接收测度证明

\[
 \frac{128\Lambda}{3}\mathbb E\sum_{V,j}\int
 p\sum_r b_r\,dx\,d\beta_V
 \le\varepsilon X+C_\varepsilon\sqrt n\,\mathrm{polylog}(2+n)W_\beta.
 \tag{JI11, 未证}
\]

使用的覆盖部分必须明列，未覆盖初端域仍用原基线并保留为未付；good 注入和终端项也另保留。JI11 的目标不是对每行强加 1/N，而是对同 x 的截断 K0 来源覆盖与 J 加权均值给空间积分上界。没有由 high 推出小 eτ/eg 或 β0，也没有把 ∫Q*ν≤q 替代该证书。

本轮没有建立 JI11 的一般成立域，亦未证明其未覆盖域可吸收。可登记的新结论是闭式 JI4/JI6、全域线性预算退化 JI8、下降侧支配 JI9，以及上升侧实际核证书 JI7；一般根阶目标仍未解决。它们明确排除两个无收益策略并把剩余空间任务收窄，不能登记第二份 R153 坏侧付款。

## JI7. 可复现自检及证明地位

先前 10,000 组浮点检查仅为作者诊断，不是区间证书或独立审计。未另归档数据；下面给出完整复现规则。使用 Python 标准库 Random(153154)，每轮依次采样 c=10^Uniform[-3,3]、a=c·randint(1,50)、U=c·10^Uniform[-3,4]、γ=10^Uniform[-5,5]；计算上述 z_*、A*=U/(1+γz_*)、B*=z_*A*，比较 Ψ(A*,B*) 与 M。随后按同一随机流采 A=U·random()、B0=(U−A)/γ·random()、R=c·10^Uniform[-4,4]、B=B0+R·random()，核 JI6。

```python
import math, random
rng = random.Random(153154)
err = violation = 0.0
for _ in range(10000):
    c = 10**rng.uniform(-3, 3)
    a = c*rng.randint(1, 50)
    U = c*10**rng.uniform(-3, 4)
    gamma = 10**rng.uniform(-5, 5)
    M = U*U/(math.sqrt(a*(U+c*gamma))
             + math.sqrt((U+a*gamma)*(U+c)))**2
    z = math.sqrt(a*(U+c)/((U+a*gamma)*(U+c*gamma)))
    A = U/(1+gamma*z)
    B = z*A
    psi = A*B/((B+a)*(A+B+c))
    err = max(err, abs(psi-M)/max(M, 1e-300))
    A = U*rng.random()
    B0 = (U-A)/gamma*rng.random()
    R = c*10**rng.uniform(-4, 4)
    B = B0+R*rng.random()
    psi = A*B/((B+a)*(A+B+c))
    violation = max(violation, psi-M-U*R/(a*(U+c)))
print(err, violation)
```

原运行输出最大相对误差约 8.67e−16、正超额 0；平台末位可不同。本文证明依 JI2–JI9 的解析推导，不依上述浮点值。实际原核、α、接收样本评估由本轮其他作者独立处理，不能用此标量诊断代替。

所有极限固定原 ν、e、ρ、α、c 和资格，仅处理已定义可积量或截断非负积分，不截断 ν 后重算归一声称单调。完成此有界检查点后停止。
