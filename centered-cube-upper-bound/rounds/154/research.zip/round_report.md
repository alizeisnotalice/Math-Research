# 第154轮：共同来源约束的非线性几何预算

一般一致弱型 n^(1/2+o(1)) 目标仍未闭合。本轮严格新增：共同α给出的联合可行域；势AB/[(B+a)(A+B+c)]的闭式联合最大值M；保留真实K0截断尾的M+tail上界及同点来源覆盖证书。完整假设、一般来源积分和零分支在research.tex及joint_initial_budget.md。Sol先独立审命题，再逐式读作者和主稿，通过，见joint_audit.md。

已知原限制工具保留；没有把原ν换成外β，没有删掉j/history/尺度/soft费用。原初端费用128Λ/3完整保留。实际空间覆盖证书尚未证明；good注入、未覆盖初端和一般重尾仍未付。本轮不新增根阶付款，不把点态M当一般上界。

## 结果与决定

新非线性帽有严格优于两条旧基线的标量例（A=B=a=c=1，gamma=1/4，U=5/4，R=0），但不是FULL实现。下降侧B²≥a(A+c)不优于实际A旧峰；粗线性化的背包约束由原共同余额恒失效，故不再投入强对偶/一般LP验证。真实初端x0控制均处在下降侧，新帽没有初端优势。下一步应研究有符号时间交通及空间几何支付，不能再用更松U峰假报改进，也不把后时低帽拼成无价时间原函数。

## 实际验证

- 标量三阶段5048项Fraction证书：486初探、1562零支/边界压力、3000扩大范围（seed154015，r至64，尺度1e−6至1e6）。以W≥0和W²≥4z²XY核验根式帽；Decimal70比较仅诊断。脚本作者实际运行历史见joint_numeric_plan.md；父级此前重跑一次，本次完整复现又跑一次。
- 原模型直接使用R151 compact.constants.nu_exact（已经加权），六来源R142 x0 mp70核缓存，R136阈值Fraction重建wg及Delta。独立参考72个时间左右/中点/切口/c组合、360个固定L检查。producer初端8行、80个固定/缩放L证书；独立比较960精确字段，零不一致。
- 初端固定40帽全部严格高于实际A旧峰，用有理平方根外夹逼判断。其余时间有低/高混合，不能据此支付统一时间或空间费用。
- 早期producer重复加权ν，另有保存权重及角色口径，均已改正；错误模型结果撤回。适配过程字段名变动及Python整数位数限制导致的假不一致已排除，详见numeric_audit.md。最终角色从重算good得到；保存role只作诊断。
- 主代理实际新目录复现命令：`python3 reproduce.py --rounds /Users/zhengzhihao/Math-Research-centered-cube-work/centered-cube-upper-bound/rounds --destination /Users/zhengzhihao/Desktop/T/output/r154_parent_replay_20261015_a`。退出0；标量JSON及producer JSON与归档逐字节一致，独立960字段PASS。0新增kernel计算、0新增receiver。
- 数学工具使用B01技能的共同乘子、弱界方向及证书审计原则；不调用一般无限维强对偶。缺少实际扣额数据，不估计模型成本比例。

## 限制与复现

mp70十进制冻结为精确有理数仅认证有限冻结模型的代数，不是实际核的区间包围；无空间求积误差或FULL历史认证。作者10000浮点诊断有复现代码但不作为证明。没有编译PDF。

依赖旧139/142/151轮归档，reproduce.py自动提取必要小输入。解压本包后运行`python3 reproduce.py --rounds /绝对路径/rounds --destination /新的不存在目录`，只需Python标准库。新目录必须不存在以免覆盖结果。完整输出JSON为必要绑定证书，未重复打包旧轮源数据。manifest.json记录每个最终成员SHA256。源稿、审稿、数值和最小复现材料集中一个ZIP，外部只新增轮次README/ZIP，更新项目索引。

父级静态检查：Python AST、JSON解析通过；初次TeX检查器错误地比较嵌套环境顺序而失败，改为栈式配对后通过。这是检查器修正，没有改动数学主稿，未编译PDF。
