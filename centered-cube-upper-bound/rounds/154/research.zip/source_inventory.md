# R154 source/input availability inventory

Status: read-only provenance and field-availability note. This inventory does not certify the R153 lemma, any payment inequality, or FULL coverage. It records the bounded inspection already made and does not repeat the historical audit.

## R151 saved receiver detail

Input: /Users/zhengzhihao/Desktop/T/output/centered_cube_round151_20261015/receiver_probe_points.json.

- Root paths: /point_records/4 (600 rows), /point_records/8 (7,776 rows); the other root member is /corrected_overlap_weights.
- Per-row fields include xq (four exact rational coordinate strings), x (float coordinates), float p, q, q_tests, QJ, alpha, six-entry rho, good, E, and hard_sources; also gates, hardmass, m, I, and pair_terms.
- pair_terms records only FA diagnostic terms (segment, source indices v/u, delta, I). No row contains sourcewise K0_v, J_v, Q_v, producer U_v, source thresholds/positions, nu, T,D, or Delta_v = w_tau - w_h.
- alpha and QJ are saved as float64 producer outputs. alpha is the original pointwise shared-alpha calculation in the producer, not alpha inferred from frozen rho, but the detail alone cannot exactly audit or reconstruct its inputs.
- No saved grid row has x=0: exact-coordinate comparison found zero matches in both grids. The R142 x0 kernel vectors therefore cannot be attached to an existing R151 grid row as if they were that row's values.

## R151 producer definition and terminology

Archive: rounds/151/research.zip, members receiver_probe.py and research.tex. Relevant producer functions in receiver_probe.py are build, eval_batch, and one_point.

- build combines R136 I1 source geometry with R142 I1 nu_exact; it applies multiplicities [2**12, 2**12, 2**12, 2**8, 1, 2**8] and renormalizes. Reaggregation at x0 must use this R151-reweighted common nu, rather than blindly reusing aggregate scalars computed under another weighting.
- At receiver x, eval_batch evaluates p(x), source vectors K0_v,K1_v,K2_v,J_v, then Q_v = (K1_v+K2_v+J_v)/3. It forms q = max(nu·K0, nu·J, nu·Q), and Q_J = nu·J (saved scalar field QJ).
- Producer U_v is the sourcewise cap:
  U_v = 1_{E_v} min(T A_v, D K0_v), where E_v = 1_{p w_g(v) <= K Q_v} 1_{A_v>0}.
  The producer's common coefficient is alpha = (D q - sum_v nu_v U_v)/Q_J, and it computes sourcewise rho_v = 1_{E_v}[1-(U_v+alpha J_v)/(T A_v)]_+. These are producer quantities.
- In R153, U_r(t) = integral over E_* of w_t 1_{k_t>r}(1-D K0/(T Delta))_+ dnu is instead a cut/time aggregate; it is not the producer's U_v. Likewise V_r(t) aggregates J_v/(T Delta_v) over the cut. To compute them, first obtain correct sourcewise kernels, Delta_v, role masks, and shared alpha; then perform the cut-weighted integrals.
- The saved detail has good, E, and hard_sources, but does not expose named R153 E_* and D_0 selections. Map those masks from the actual contract/selection rule; do not identify hard_sources with D_0 without that rule.

## R142 x0 cache and R136 I1 inputs

R142 cache: /Users/zhengzhihao/Desktop/T/output/r142_portable_replay_verified_20261015/centered_cube_round142_20261015/numeric_receiver.json, case cases.I1.

- cases.I1.records[id=0] identifies control receiver x=(0,0,0,0). Its paired cases.I1.verifications[id=0, precision="mp70"] stores high-precision decimal strings for p, K0[6], K1[6], K2[6], J[6], Q[6], q_tests, q, QJ, alpha, and sourcewise good, U, rho (plus hard-source fields). These are available kernel values at x0.
- To evaluate the R151 x0 common alpha, reaggregate the sourcewise x0 kernel vectors against the R151-reweighted nu, recompute q = max(nu·K0, nu·J, nu·Q), Q_J = nu·J, then U_v and alpha using the R151 producer definition. Do not assume the cache's already aggregated alpha/QJ automatically equals the reweighted aggregate. The cache supplies values only at x0.
- R142 cache x0 has no matching row in either R151 receiver grid, so it is a standalone control unless x0 is explicitly added as a control point.

R136 input: /Users/zhengzhihao/Desktop/T/output/r142_portable_replay_verified_20261015/centered_cube_round136_20261014/active_traffic_v2.json, case cases[id="I1"].

- parameters and derived store high-precision decimal-string parameters including s,L,y,K,D,b,T and related scale data.
- Each atoms[i] stores source position, base nu, threshold coordinates, wg, wtau, wh, A, source roles and baseline K0,K1,K2,J,Q,U,rho. Here A is the saved Delta_v = wtau - wh. The atom kernel values are baseline x0 values, not general x-dependent kernels.
- derived.alpha is a model/baseline value. Do not substitute it for a receiver-specific R151 alpha; R151's producer reweights nu and computes the shared coefficient at each receiver.
- R136 I1 supplies the non-kernel inputs and source geometry needed to recompute any selected row. The archived producer's kernel_np/kernel_mp definitions and eval_batch show how to evaluate at arbitrary x.

## Reconstruction boundary

At x0, the existing R142 per-source kernel cache plus R136 I1 parameters, weights, and source geometry supports an x0 recomputation, with R151's reweighted nu and producer formula applied explicitly. For a nonzero R151 grid point, detail gives its exact coordinate string but not its sourcewise kernel vectors. Reconstructing U_r,V_r,R_{r,L} there requires fresh evaluations of p(x) and the six-source K0,K1,K2,J (then Q), followed by recomputation of common alpha, producer U_v,rho_v, and the R153 aggregates. These are additional kernel computations over existing inputs, not missing external data; existing saved detail alone is insufficient.

Any resulting computation remains a finite diagnostic on selected points. It does not establish the R153 inequality for all rows or prove a theorem. In particular, do not infer alpha from saved rho, do not promote frozen float coefficients to exact FULL data, and do not call a reconstructed finite sample a FULL certificate.

