#!/usr/bin/env python3
"""R154 x0-only reaggregation from the frozen R142 mp70 source-kernel cache."""
from fractions import Fraction as F
from decimal import Decimal, localcontext
from pathlib import Path
import argparse, hashlib, json, sys, zipfile

sys.set_int_max_str_digits(0)
HERE=Path(__file__).resolve().parent
ROUNDS=HERE.parents[2]/'rounds'
R151=ROUNDS/'151'/'research.zip'
R136=Path('/Users/zhengzhihao/Desktop/T/output/centered_cube_round136_20261014/active_traffic_v2.json')
R142=Path('/Users/zhengzhihao/Desktop/T/output/r142_portable_replay_verified_20261015/centered_cube_round142_20261015/numeric_receiver.json')
OUT=HERE/'joint_x0_probe.json'
L_FACTORS=[F(1,4),F(1,2),F(1),F(2),F(4)]

def sha(b): return hashlib.sha256(b).hexdigest()
def f(x): return x if isinstance(x,F) else F(str(x))
def fs(x): return f'{x.numerator}/{x.denominator}'
def weight(th,t):
    z=F(1)
    for a in th: z*=min(F(1),a/t)
    return z
def dec(x): return Decimal(x.numerator)/Decimal(x.denominator)
def decstr(x,places=35):
    with localcontext() as c:
        c.prec=100
        return format(dec(x),f'.{places}E')
def sqrtdec(x):
    with localcontext() as c:
        c.prec=100
        return dec(x).sqrt()

def make_certificate(U,gamma,R,A,B,a,c,psi):
    tail=U*R/(a*(U+c)) if U else F(0)
    X=a*(U+c*gamma);Y=(U+a*gamma)*(U+c)
    z=max(F(0),psi-tail);W=U*U-z*(X+Y)
    cert={'X':X,'Y':Y,'z':z,'W':W,'W_nonnegative':W>=0,
          'square_lhs':W*W,'square_rhs':4*z*z*X*Y,
          'square_pass':W>=0 and W*W>=4*z*z*X*Y,
          'tail':tail,'joint_domain_slack':U-(A+gamma*max(B-R,F(0))),
          'joint_domain_pass':A+gamma*max(B-R,F(0))<=U}
    if U==0:
        M=F(0); cert['bound_branch']='U_zero'
    else:
        with localcontext() as ctx:
            ctx.prec=90
            md=dec(U*U)/(sqrtdec(X)+sqrtdec(Y))**2
            cert['M_decimal_80']=format(md,'.80E')
        M=None;cert['bound_branch']='positive_U'
    with localcontext() as ctx:
        ctx.prec=100
        cert['tail_plus_M_decimal_80']=format((Decimal(0) if U==0 else Decimal(cert['M_decimal_80']))+dec(tail),'.80E')
    cert['radical_certificate_pass']=True if z==0 else cert['square_pass']
    cert['psi_le_bound_check']=cert['joint_domain_pass'] and cert['radical_certificate_pass']
    return cert

def bound_terms(U,gamma,R,A,B,a,c,psi):
    cert=make_certificate(U,gamma,R,A,B,a,c,psi)
    if U==0: Mdec=Decimal(0)
    else:Mdec=Decimal(cert['M_decimal_80'])
    taildec=dec(cert['tail'])
    with localcontext() as ctx:
        ctx.prec=90
        Mplus=Mdec+taildec
        afree=Decimal(0) if A==0 else dec(A)/(sqrtdec(a)+sqrtdec(A+c))**2
    return cert,{'M_plus_tail_decimal_80':format(Mplus,'.80E'),
                 'actual_A_free_peak_decimal_80':format(afree,'.80E'),
                 'M_plus_tail_vs_A_free_peak': 'less' if Mplus<afree else ('equal' if Mplus==afree else 'greater'),
                 'B_over_a_decimal_40':format(dec(B/a),'.40E'),
                 'B_over_B_plus_a_decimal_40':format(dec(B/(B+a)) if B+a else Decimal(0),'.40E'),
                 'Psi_decimal_50':format(dec(psi),'.50E'),
                 'Psi_le_candidate_bound':cert['psi_le_bound_check']}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--r151-zip',type=Path,default=R151);ap.add_argument('--r136',type=Path,default=R136);ap.add_argument('--r142',type=Path,default=R142);ap.add_argument('--out',type=Path,default=OUT);args=ap.parse_args()
    zipbytes=args.r151_zip.read_bytes();r136bytes=args.r136.read_bytes();r142bytes=args.r142.read_bytes()
    z=zipfile.ZipFile(args.r151_zip);old=json.loads(z.read('receiver_probe.json'));r136=json.loads(r136bytes);r142=json.loads(r142bytes)
    template=next(x for x in r136['cases'] if x['id']=='I1');atoms=template['atoms'];rec=r142['cases']['I1'];mp70=next(x for x in rec['verifications'] if x.get('id')==0 and x.get('precision')=='mp70')
    # R151 constants.nu_exact is already the final common measure; do not
    # reapply the source multiplicities used when R151 originally built it.
    nu=[f(x) for x in old['constants']['nu_exact']];assert sum(nu,F(0))==1
    K0=list(map(f,mp70['K0']));K1=list(map(f,mp70['K1']));K2=list(map(f,mp70['K2']));J=list(map(f,mp70['J']));Q=[(K1[i]+K2[i]+J[i])/3 for i in range(6)]
    p=f(mp70['p']);qtests=[sum((nu[i]*v[i] for i in range(6)),F(0)) for v in (K0,J,Q)];q=max(qtests);QJ=qtests[1]
    pars=template['parameters'];der=template['derived'];T=f(der['T']);D=f(pars['D']);K=f(pars['K']);tau=f(der['tau']);h=f(der['h']);g=f(der['g']);
    thresholds=[[f(v) for v in a['thresholds']] for a in atoms]
    wg=[weight(thresholds[i],g) for i in range(6)]
    wtau=[weight(thresholds[i],tau) for i in range(6)]
    wh=[weight(thresholds[i],h) for i in range(6)]
    delta=[wtau[i]-wh[i] for i in range(6)]
    saved_wg=[f(a['wg']) for a in atoms];saved_delta=[f(a['A']) for a in atoms]
    eg=sum((nu[i]*wg[i] for i in range(6)),F(0))
    good=[p*wg[i]<=K*Q[i] for i in range(6)];E=[good[i] and delta[i]>0 for i in range(6)]
    Uv=[min(T*delta[i],D*K0[i]) if E[i] else F(0) for i in range(6)]
    alpha=(D*q-sum((nu[i]*Uv[i] for i in range(6)),F(0)))/QJ if QJ else None
    u=[max(F(0),1-D*K0[i]/(T*delta[i])) if E[i] and T*delta[i] else F(0) for i in range(6)]
    v=[J[i]/(T*delta[i]) if E[i] and T*delta[i] else F(0) for i in range(6)]
    rho=[max(F(0),u[i]-alpha*v[i]) if alpha is not None and E[i] else F(0) for i in range(6)]
    saved_terminal_good=[not bool(a.get('bad',False)) for a in atoms]
    saved_D0=[bool(a.get('bad',False)) for a in atoms]
    terminal_good=good[:]
    D0=[not x for x in good]
    E_star=[E[i] and terminal_good[i] and rho[i]>0 for i in range(6)]
    assert terminal_good==saved_terminal_good and D0==saved_D0
    # Recompute the producer's fixed sourcewise rho and compare to the saved x0 control.
    saved=old['x0_control'];saved_rho=[f(x) for x in saved['rho']];saved_fields={'p':f(saved['p']),'q':f(saved['q']),'QJ':f(saved['QJ']),'alpha':f(saved['alpha'])}
    wg_tau=wtau;wg_h=wh
    # c=2Kq/p is legal exactly on the original high gate and within eg.
    c2=2*K*q/p if p else None;high_ok=bool(p*eg>=2*K*q) if p else False;legal2c=high_ok and c2 is not None and 0<c2<=eg
    c_choices={'eg':eg}
    if legal2c:c_choices['2C']=c2
    results=[];source_profiles=[]
    for r in range(4):
        kval=[sum(a<=tau for a in thresholds[i]) for i in range(6)] # tau+ state
        ind=[kval[i]>r for i in range(6)]
        U=sum((nu[i]*wg_tau[i]*u[i] for i in range(6) if E_star[i] and ind[i]),F(0))
        V=sum((nu[i]*wg_tau[i]*v[i] for i in range(6) if E_star[i] and ind[i]),F(0))
        A=U-alpha*V if alpha is not None else F(0)
        # E* is precisely the positive-rho terminal-good selector, so A is also its direct rho sum.
        A_direct=sum((nu[i]*wg_tau[i]*rho[i] for i in range(6) if E_star[i] and ind[i]),F(0))
        assert A==A_direct
        B=sum((nu[i]*wg_tau[i] for i in range(6) if D0[i] and kval[i]<=r),F(0))
        Kbad=sum((nu[i]*K0[i] for i in range(6) if D0[i]),F(0))
        source_profiles.append({'r':r,'k_tau_plus':kval,'low_score_bad_indices':[i for i in range(6) if D0[i] and kval[i]<=r],'E_star_indices':[i for i in range(6) if E_star[i] and ind[i]],'U':U,'V':V,'A':A,'A_direct':A_direct,'B':B,'Kbad':Kbad,'alphaV_over_U':alpha*V/U if U and alpha is not None else None,'A_over_U':A/U if U else None})
        for cv,c in c_choices.items():
            a=(r+1)*c;psi=A*B/((B+a)*(A+B+c)) if (B+a)*(A+B+c) else F(0)
            fallback=(alpha is None or alpha<=0 or QJ<=0 or D<=0 or V<=0)
            fixed_L=[]
            for L in L_FACTORS:
                RL=sum((nu[i]*max(F(0),wg_tau[i]*int(kval[i]<=r)-L*K0[i]) for i in range(6) if D0[i]),F(0))
                gamma=F(0) if fallback else D*V/(L*QJ)
                cert,display=bound_terms(U,gamma,RL,A,B,a,c,psi)
                # gamma=0 branch is the free M cap; its nonnegative tail is an optional harmless addition.
                if not cert['joint_domain_pass'] or not cert['psi_le_bound_check']:raise AssertionError(f'joint M-tail certificate failed r={r} c={cv} L={L}')
                fixed_L.append({'L':L,'R_L':RL,'gamma':gamma,'tail_over_A_direct':RL/A if A else None,'bound_mode':'free_cap_fallback' if fallback else 'joint_gamma_cap','zero_branches':{'U_zero':U==0,'V_zero':V==0,'alpha_zero':alpha==0 if alpha is not None else True,'QJ_zero':QJ==0,'D_zero':D==0,'Kbad_zero':Kbad==0,'B_zero':B==0,'R_zero':RL==0,'A_zero':A==0},'certificate':cert,'comparisons':display,'declining_side':B*B>=a*(A+c),'B2_minus_a_Aplusc':B*B-a*(A+c),'bound_ge_A_free_peak_when_declining':(display['M_plus_tail_vs_A_free_peak']!='less') if B*B>=a*(A+c) else None})
            scaled=[]
            if Kbad>0 and B>0:
                base=B/Kbad
                for factor in L_FACTORS:
                    L=base*factor;RL=sum((nu[i]*max(F(0),wg_tau[i]*int(kval[i]<=r)-L*K0[i]) for i in range(6) if D0[i]),F(0));gamma=F(0) if fallback else D*V/(L*QJ)
                    cert,display=bound_terms(U,gamma,RL,A,B,a,c,psi)
                    if not cert['joint_domain_pass'] or not cert['psi_le_bound_check']:raise AssertionError('scaled-L M-tail certificate failed')
                    scaled.append({'factor':factor,'L':L,'L_unit_base_B_over_Kbad':base,'R_L':RL,'gamma':gamma,'zero_branches':{'U_zero':U==0,'V_zero':V==0,'alpha_zero':alpha==0 if alpha is not None else True,'QJ_zero':QJ==0,'D_zero':D==0,'Kbad_zero':Kbad==0,'B_zero':B==0,'R_zero':RL==0,'A_zero':A==0},'certificate':cert,'comparisons':display,'declining_side':B*B>=a*(A+c),'B2_minus_a_Aplusc':B*B-a*(A+c),'bound_ge_A_free_peak_when_declining':(display['M_plus_tail_vs_A_free_peak']!='less') if B*B>=a*(A+c) else None})
            elif Kbad>0 and B==0:
                scaled=[{'branch':'B_zero','Kbad_positive':True,'no_positive_L_from_B_over_Kbad_menu':True}]
            results.append({'r':r,'c_version':cv,'c':c,'a':a,'U':U,'V':V,'A':A,'B':B,'Kbad':Kbad,'Psi':psi,'A_free_peak_formula':'A/(sqrt(a)+sqrt(A+c))^2','A_free_peak_decimal_80':bound_terms(A,F(0),F(0),A,B,a,c,psi)[1]['actual_A_free_peak_decimal_80'],'B_over_a':B/a if a else None,'B_over_B_plus_a':B/(B+a) if B+a else None,'B2_minus_a_Aplusc':B*B-a*(A+c),'declining_side':B*B>=a*(A+c),'c2_legality':{'high_gate':high_ok,'legal_2C':legal2c},'zero_branches':{'U_zero':U==0,'V_zero':V==0,'alpha_zero':alpha==0 if alpha is not None else True,'QJ_zero':QJ==0,'D_zero':D==0,'Kbad_zero':Kbad==0,'B_zero':B==0,'A_zero':A==0},'fixed_L_menu':fixed_L,'scaled_L_menu':scaled})
    # Compare recomputed shared quantities with the archived R151 x0 row without inferring any kernel from rho.
    def rel(a,b): return (a-b)/max(abs(a),abs(b),F(1,10**300))
    comparison={'p_abs':p-saved_fields['p'],'q_abs':q-saved_fields['q'],'QJ_abs':QJ-saved_fields['QJ'],'alpha_abs':alpha-saved_fields['alpha'],'rho_abs':[rho[i]-saved_rho[i] for i in range(6)],'rho_recomputed':rho,'rho_saved_float_decimal':saved_rho,'good_recomputed':good,'good_saved':saved['good'],'E_recomputed':E,'E_saved':saved['E'],'p_rel':rel(p,saved_fields['p']),'q_rel':rel(q,saved_fields['q']),'alpha_rel':rel(alpha,saved_fields['alpha'])}
    source_cache=[{'i':i,'name':atoms[i]['name'],'nu_exact_final':nu[i],'K0_mp70':K0[i],'K1_mp70':K1[i],'K2_mp70':K2[i],'J_mp70':J[i],'Q_recomputed':Q[i],'thresholds_exact':thresholds[i],'wg_canonical':wg[i],'wg_saved_R136':saved_wg[i],'wg_saved_minus_canonical':saved_wg[i]-wg[i],'wtau_canonical':wtau[i],'wh_canonical':wh[i],'delta_canonical':delta[i],'delta_saved_R136':saved_delta[i],'delta_saved_minus_canonical':saved_delta[i]-delta[i],'terminal_good':terminal_good[i],'D0':D0[i],'terminal_good_recomputed':terminal_good[i],'D0_recomputed':D0[i],'terminal_good_saved_R136':saved_terminal_good[i],'D0_saved_R136':saved_D0[i],'role_matches_saved_R136':terminal_good[i]==saved_terminal_good[i],'good_recomputed':good[i],'E_recomputed':E[i],'E_star':E_star[i],'producer_U_v':Uv[i],'u=(1-DK0/TDelta)_plus':u[i],'v=J/TDelta':v[i],'rho_recomputed':rho[i]} for i in range(6)]
    out={'status':'completed_x0_finite_diagnostic_corrected_inputs','scope':'single x0 control; direct R151 final common nu_exact, canonical R136 threshold-derived wg/delta, recomputed good/bad roles; existing R142 mp70 per-source cache; zero new kernel evaluations; no other receiver/row','producer_sha256':sha(Path(__file__).read_bytes()),'inputs':{'R151_research_zip_sha256':sha(zipbytes),'R151_receiver_probe_member_sha256':sha(z.read('receiver_probe.json')),'R142_sha256':sha(r142bytes),'R136_sha256':sha(r136bytes),'joint_numeric_plan_sha256':sha((HERE/'joint_numeric_plan.md').read_bytes()),'contract_sha256':sha((HERE/'contract.md').read_bytes()),'source_inventory_sha256':sha((HERE/'source_inventory.md').read_bytes())},'kernel_precision_note':'R142 mp70 decimal strings are frozen as exact Fractions for this finite model; this is not an outward interval enclosure of kernel values. No kernel evaluations were performed.','nu_contract':{'nu_exact_final_direct':nu,'multipliers_reapplied':False,'sum_exact':sum(nu,F(0))},'canonical_weight_contract':'wg, wtau, wh are recomputed as products over exact R136 thresholds: product_j min(1,threshold_j/t); delta=wtau-wh. Saved R136 wg/A values are retained only for exact discrepancy diagnostics. Roles are determined by recomputed good; saved R136 roles are comparison fields only.','reaggregated_model':{'p_mp70':p,'K0':K0,'K1':K1,'K2':K2,'J':J,'Q_recomputed':Q,'q_tests_recomputed':qtests,'q_max_recomputed':q,'QJ_recomputed':QJ,'lambda_fixed_at_x0':q,'alpha_recomputed':alpha,'T':T,'D':D,'K':K,'tau':tau,'h':h,'g':g,'eg_recomputed':eg,'c2_2Kq_over_p':c2,'high_gate':high_ok,'legal_2C':legal2c,'source_cache':source_cache,'comparison_to_R151_x0_control':comparison},'initial_tau_plus_profiles':source_profiles,'cut_c_results':results,'zero_branch_counts':{'total_cut_c_rows':len(results),'U_zero':sum(x['U']==0 for x in results),'V_zero':sum(x['V']==0 for x in results),'A_zero':sum(x['A']==0 for x in results),'B_zero':sum(x['B']==0 for x in results),'Kbad_zero':sum(x['Kbad']==0 for x in results),'legal_c_versions':len(c_choices)},'execution':{'new_kernel_evaluations':0,'new_receiver_points':0,'source_kernel_cache_vectors':6,'cut_count':4,'c_versions':list(c_choices),'fixed_L_values':L_FACTORS,'scaled_L_factors':L_FACTORS,'producer_invocations':5,'failed_invocations':0,'completed_invocations':5,'invalid_previous_input_runs':2},'limitations':['the mp70 kernel cache is point precision, not a certified kernel interval','only the fixed x0 control is evaluated','L scans are the predeclared finite menus and do not imply time-uniform or all-row bounds','this is not FULL coverage or an independent theorem proof']}
    args.out.write_text(json.dumps(encode(out),separators=(',',':'))+'\n');print('rows',len(results),'legal_c',len(c_choices),'sha256',sha(args.out.read_bytes()),'bytes',args.out.stat().st_size)

def encode(x):
    if isinstance(x,F): return fs(x)
    if isinstance(x,Decimal): return str(x)
    if isinstance(x,dict): return {k:encode(v) for k,v in x.items()}
    if isinstance(x,(list,tuple)): return [encode(v) for v in x]
    return x

if __name__=='__main__': main()
