# R154 x0 joint-bound probe — corrected input run

## Scope and correction history

This is a single-control finite diagnostic at I1's existing x0. It uses the six sourcewise kernel vectors cached in R142 mp70, reaggregates them using R151's final `constants.nu_exact` directly, and recomputes q, QJ, alpha, rho, good/E masks, and four cut profiles. It evaluates no new kernels or receiver points. The mp70 strings are frozen as exact decimal Fractions for this finite calculation; this is not an outward kernel interval certificate, not FULL time coverage, and not an independent theorem proof.

The first two producer runs are invalid and their conclusions are withdrawn. They re-applied the source multiplicities `[4096,4096,4096,256,1,256]` to `R151.constants.nu_exact`, even though that vector already is R151's final common measure, and they used saved R136 `wg`/`A` instead of canonical threshold-derived weights. A later corrected run still sourced the terminalgood/bad role masks from the saved R136 labels; this happened to match the recomputed roles but did not follow the required source of truth. The final run directly sets `terminal_good=good` and `D0=not good`, retaining the R136 role labels only for comparison. It also preserves the adapter-compatible `terminal_good` and `D0` keys as aliases of the recomputed roles. The final run uses the R151 measure unchanged and computes, for each source with exact threshold vector `thresholds`,

`w(t) = product_j min(1, thresholds[j]/t)`, `wg=w(g)`, `delta=w(tau)-w(h)`.

The old saved `wg` and `A` are retained only as exact discrepancy diagnostics. The corrected run is producer invocation 3; invocations 1–2 were completed but invalid, with no failed executions. No kernel evaluations or receiver points were added.

## Corrected x0 result

The final measure sums exactly to 1. All six recomputed role masks match the saved R136 labels. The recomputed `eg` is approximately `5.8955881110e-7`; q and QJ are both approximately `2.3935561602210266e-7`; recomputed alpha is approximately `0.8887705904533536`. Under canonical weights the high gate passes, so both `c=eg` and `c=2Kq/p` are legal. There are eight cut/cost rows.

For both costs, all four cuts have `B^2 >= a(A+c)`, placing x0 on the declining side. For `c=eg`, the four Psi values are approximately `0.1290485711`, `0.1086987459`, `0.0938926935`, and `0.0826366115`; for `c=2C`, they are `0.1327352020`, `0.1129972579`, `0.0983695440`, and `0.0870949358`. The stronger baseline `B/(B+a)` is stored on every result row alongside `B/a`.

The fixed-L and B/Kbad-scaled-L menus each contain 40 rows after including both legal costs. All 80 exact joint-domain and square certificates pass. The displayed M+tail comparisons are high-precision Decimal evaluations of radicals; all 80 are above the corresponding A-free peak in this finite menu. The exact rational W-square checks certify the algebraic candidate inequality for the frozen rational inputs, while the original cached kernels retain only mp70 point precision.

## Files and reproducibility

- Producer: [joint_x0_probe.py](joint_x0_probe.py)
- Output: [joint_x0_probe.json](joint_x0_probe.json)
- External source backup: `/Users/zhengzhihao/Desktop/T/output/joint_x0_probe_R154_source_backup_20261015.py`
- Producer SHA-256: `bfac952af5bb76a705f19010c891f7756c35b6da0d26a6d30ccb9e891682da90`
- JSON SHA-256: `5d38f8b0229d175c94b8573f80a7df4616575a00cdb10c04cbc638cb47a44d11`
- External source backup SHA-256 matches the producer.
- JSON binds `producer_sha256` to the final source and records hashes for R151, R142, R136, and local protocol inputs.
- Final ledger: 5 producer invocations total; 2 invalid nu/weight input runs, 1 completed run with roles taken from saved labels, 1 corrected role-source run, and 1 final adapter-compatible run; 0 failed runs; 0 new kernel evaluations; 0 new receiver points.

The final source passed `py_compile` and was run once after the schema-alias correction. All output rows include exact Fraction data, zero-branch flags, both baseline ratios, fixed/scaled L values, and the exact square/domain certificates. The R136 saved-versus-canonical `wg`, `delta`, and role differences are included per source in `source_cache`.
