#!/usr/bin/env python3
"""Independent R154 x0 reference; formed without reading joint_x0_probe."""
from fractions import Fraction as F
from pathlib import Path
import argparse,hashlib,json,zipfile,math,sys
sys.set_int_max_str_digits(0)
from decimal import Decimal,localcontext
ROOT=Path(__file__).resolve().parent
R142=Path('/Users/zhengzhihao/Desktop/T/output/r142_portable_replay_verified_20261015/centered_cube_round142_20261015/numeric_receiver.json')
R136=Path('/Users/zhengzhihao/Desktop/T/output/centered_cube_round136_20261014/active_traffic_v2.json')
def fr(x):
    if isinstance(x,dict):return F(int(x['numerator']),int(x['denominator']))
    return F(str(x))
def sha(b):return hashlib.sha256(b).hexdigest()
def weight(th,t):
    out=F(1)
    for x in th:out*=min(F(1),x/t)
    return out

def sqrt_box(q,digits=80):
    scale=10**digits; k=math.isqrt(q.numerator*scale*scale//q.denominator)
    lo,hi=F(k,scale),F(k+1,scale)
    assert lo*lo<=q<=hi*hi
    return lo,hi

def reference(r142=R142,r136=R136,archive=ROOT.parents[1]/'151/research.zip'):
    kb=r142.read_bytes();sb=r136.read_bytes()
    assert sha(kb)=='c46a90467707b9d05ae03cb17d0f63e60bf7709dfd5c717550e3d3278957ae55'
    assert sha(sb)=='1090fb2356abe035a997eb851a2f0252a3abe3edbeaf978e99900a38906392de'
    with zipfile.ZipFile(archive) as z:cb=z.read('receiver_probe.json')
    assert sha(cb)=='6bfc604946efcb7461b354e1d1f5347319b519548e1c4448a35643b5f911b731'
    compact=json.loads(cb);nu=list(map(fr,compact['constants']['nu_exact']))
    old=json.loads(kb)['cases']['I1'];cache=next(v for v in old['verifications'] if v['id']==0)
    assert cache['precision']=='mp70';src=next(v for v in json.loads(sb)['cases'] if v['id']=='I1');atoms=src['atoms'];K,D=map(fr,[src['parameters']['K'],src['parameters']['D']]);T=fr(src['derived']['T']);tau,h=map(fr,[src['derived']['tau'],src['derived']['h']]);g=fr(src['derived']['g']);p=fr(cache['p'])
    K0,K1,K2,J=[list(map(fr,cache[name])) for name in ['K0','K1','K2','J']]
    Q=[(K1[i]+K2[i]+J[i])/3 for i in range(6)]
    dots=lambda x:sum((nu[i]*x[i] for i in range(6)),F(0))
    tests=list(map(dots,[K0,J,Q]));q=max(tests);QJ=dots(J)
    th=[list(map(fr,a['thresholds'])) for a in atoms]
    delta=[weight(tt,tau)-weight(tt,h) for tt in th];wg=[weight(tt,g) for tt in th]
    discrepancy=dict(delta=[delta[i]-fr(atoms[i]['A']) for i in range(6)],wg=[wg[i]-fr(atoms[i]['wg']) for i in range(6)])
    good=[p*wg[i]<=K*Q[i] for i in range(6)];E=[good[i] and delta[i]>0 for i in range(6)]
    cap=[min(T*delta[i],D*K0[i]) if E[i] else F(0) for i in range(6)]
    alpha=(D*q-dots(cap))/QJ;assert alpha>=0
    rho=[max(F(0),1-(cap[i]+alpha*J[i])/(T*delta[i])) if E[i] else F(0) for i in range(6)]
    star=[rho[i]>0 for i in range(6)];bad=[not v for v in good]
    u=[max(F(0),1-D*K0[i]/(T*delta[i])) if star[i] else F(0) for i in range(6)]
    v=[J[i]/(T*delta[i]) if star[i] else F(0) for i in range(6)]
    assert all(not star[i] or rho[i]==u[i]-alpha*v[i] for i in range(6))
    reserve=alpha*QJ-D*sum(nu[i]*K0[i] for i in range(6) if bad[i]);assert reserve>=0
    th=[list(map(fr,a['thresholds'])) for a in atoms];eg=sum(nu[i]*weight(th[i],g) for i in range(6));c2=2*K*q/p
    assert 0<c2<=eg
    # All canonical segment endpoints and both threshold sides, plus midpoint controls.
    times=sorted({tau,h}|{x for tt in th for x in tt if tau<x<h});points=[(tau,'right'),(h,'left')]
    points += [(t,side) for t in times[1:-1] for side in ['left','right']]
    points += [((a+b)/2,'middle') for a,b in zip(times,times[1:])]
    rows=[]
    for t,side in points:
        w=[weight(tt,t) for tt in th];k=[sum(x<=t if side!='left' else x<t for x in tt) for tt in th]
        for r in range(4):
            A=sum(nu[i]*w[i]*rho[i] for i in range(6) if star[i] and k[i]>r)
            U=sum(nu[i]*w[i]*u[i] for i in range(6) if star[i] and k[i]>r)
            V=sum(nu[i]*w[i]*v[i] for i in range(6) if star[i] and k[i]>r)
            B=sum(nu[i]*w[i] for i in range(6) if bad[i] and k[i]<=r)
            assert A==U-alpha*V and A>=0
            for cv,c in [('eg',eg),('2C',c2)]:
                a=(r+1)*c;psi=A*B/((B+a)*(A+B+c));tail=[]
                for L in map(F,['1/4','1/2','1','2','4']):
                    R=sum(nu[i]*max(F(0),(w[i] if k[i]<=r else F(0))-L*K0[i]) for i in range(6) if bad[i]);gamma=D*V/(L*QJ)
                    slack=U-A-gamma*max(B-R,F(0));assert slack>=0
                    z=max(F(0),psi-U*R/(a*(U+c)))
                    X=a*(U+c*gamma);Y=(U+a*gamma)*(U+c);W=U*U-z*(X+Y)
                    assert W>=0 and W*W>=4*z*z*X*Y
                    with localcontext() as ctx:
                        ctx.prec=90;dec=lambda f:Decimal(f.numerator)/f.denominator
                        M=dec(U*U)/(dec(X).sqrt()+dec(Y).sqrt())**2 if U else Decimal(0)
                        bound=M+dec(U*R/(a*(U+c)))
                        oldcap=dec(A)/(dec(a).sqrt()+dec(A+c).sqrt())**2 if A else Decimal(0)
                        upperB=dec(B/a);peak=dec(A)/(dec(a).sqrt()+dec(A+c).sqrt())**2 if A else Decimal(0)
                        bstar=(dec(a)*dec(A+c)).sqrt()
                    sx=sqrt_box(X);sy=sqrt_box(Y);sa=sqrt_box(a);sac=sqrt_box(A+c)
                    newlo=U*U/(sx[1]+sy[1])**2+U*R/(a*(U+c)) if U else F(0)
                    newhi=U*U/(sx[0]+sy[0])**2+U*R/(a*(U+c)) if U else F(0)
                    oldlo=A/(sa[1]+sac[1])**2;oldhi=A/(sa[0]+sac[0])**2
                    exact_comparison='new_above_old' if newlo>oldhi else ('new_below_old' if newhi<oldlo else 'unresolved_or_equal')
                    tail.append(dict(exact_new_vs_known_A_peak=exact_comparison,L=L,R=R,gamma=gamma,slack=slack,M_plus_tail=str(bound),old_A_free=str(oldcap),B_over_a=str(upperB),strong_old=min(oldcap,upperB),new_below_strong_old=bound<min(oldcap,upperB)-Decimal('1e-75'),B_side='below_peak' if B*B<a*(A+c) else ('above_peak' if B*B>a*(A+c) else 'at_peak'),B_weight=B/(B+a)))
                rows.append(dict(t=t,side=side,r=r,c_version=cv,c=c,A=A,U=U,V=V,B=B,Psi=psi,L_rows=tail))
    return dict(canonical_discrepancy=discrepancy,delta=delta,wg=wg,u=u,v=v,cap=cap,T=T,D=D,K=K,tau=tau,h=h,g=g,nu=nu,p=p,K0=K0,J=J,Q=Q,q_tests=tests,q=q,QJ=QJ,alpha=alpha,good=good,E=E,E_star=star,D0=bad,rho=rho,source_cap=cap,reserve=reserve,eg=eg,rows=rows)

def short(x):
    if isinstance(x,F):
        with localcontext() as c:c.prec=35;return str(Decimal(x.numerator)/x.denominator)
    if isinstance(x,Decimal):return str(x)
    if isinstance(x,list):return [short(v) for v in x]
    if isinstance(x,dict):return {k:short(v) for k,v in x.items()}
    return x

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--producer');ap.add_argument('--r142',type=Path,default=R142);ap.add_argument('--r136',type=Path,default=R136);ap.add_argument('--r151-zip',type=Path,default=ROOT.parents[1]/'151/research.zip');args=ap.parse_args()
    ref=reference(args.r142,args.r136,args.r151_zip)
    out=dict(status='REFERENCE_PASS',scope='Frozen mp70 decimal rational x0, no kernel interval certification, no new kernels',reference_sha256=sha(Path(__file__).read_bytes()),rows=len(ref['rows']),finite_L_checks=sum(len(r['L_rows']) for r in ref['rows']),aggregate=short({k:v for k,v in ref.items() if k!='rows'}),controls=short(ref['rows']))
    if args.producer:
        pb=Path(args.producer).read_bytes();prod=json.loads(pb);errors=[];checks=0
        assert prod['producer_sha256']==sha(Path(args.producer).with_suffix('.py').read_bytes())
        expected_inputs={'R151_receiver_probe_member_sha256':'6bfc604946efcb7461b354e1d1f5347319b519548e1c4448a35643b5f911b731','R142_sha256':'c46a90467707b9d05ae03cb17d0f63e60bf7709dfd5c717550e3d3278957ae55','R136_sha256':'1090fb2356abe035a997eb851a2f0252a3abe3edbeaf978e99900a38906392de'}
        assert all(prod['inputs'][k]==v for k,v in expected_inputs.items())
        def equal(got,want,label):
            nonlocal checks
            checks+=1
            if isinstance(want,bool):ok=got==want
            else:
                try:ok=fr(got)==want
                except (ValueError,KeyError,TypeError):ok=False
            if not ok:errors.append(label)
        m=prod['reaggregated_model']
        for k,pk in [('p','p_mp70'),('q','q_max_recomputed'),('QJ','QJ_recomputed'),('alpha','alpha_recomputed'),('eg','eg_recomputed')]:equal(m[pk],ref[k],k)
        for k,pk in [('K0','K0'),('J','J'),('Q','Q_recomputed'),('q_tests','q_tests_recomputed')]:
            for i,v in enumerate(ref[k]):equal(m[pk][i],v,k+':'+str(i))
        for i,saved in enumerate(m['source_cache']):
            for k,pk in [('nu','nu_exact_final'),('delta','delta_canonical'),('wg','wg_canonical'),('rho','rho_recomputed'),('cap','producer_U_v'),('good','terminal_good_recomputed'),('E','E_recomputed'),('E_star','E_star'),('D0','D0_recomputed')]:equal(saved[pk],ref[k][i],'source'+str(i)+':'+k)
        for rr in prod['initial_tau_plus_profiles']:
            r=next(x for x in ref['rows'] if x['t']==ref['tau'] and x['side']=='right' and x['r']==rr['r'] and x['c_version']=='eg')
            for k in ['U','V','A','B']:equal(rr[k],r[k],'initial'+str(rr['r'])+':'+k)
        for cc in prod['cut_c_results']:
            r=next(x for x in ref['rows'] if x['t']==ref['tau'] and x['side']=='right' and x['r']==cc['r'] and x['c_version']==cc['c_version'])
            for k in ['c','U','V','A','B','Psi']:equal(cc[k],r[k],str(cc['r'])+cc['c_version']+':'+k)
            equal(cc['B_over_B_plus_a'],r['B']/(r['B']+(r['r']+1)*r['c']),'B/(B+a)')
            equal(cc['B2_minus_a_Aplusc'],r['B']**2-(r['r']+1)*r['c']*(r['A']+r['c']),'peak_side')
            for xx in cc['fixed_L_menu']+cc.get('scaled_L_menu',[]):
                L=fr(xx['L']);t=ref['tau'];ks=[sum(z<=t for z in map(fr,a['thresholds'])) for a in next(v for v in json.loads(args.r136.read_bytes())['cases'] if v['id']=='I1')['atoms']]
                atoms=next(v for v in json.loads(args.r136.read_bytes())['cases'] if v['id']=='I1')['atoms']
                R=sum(ref['nu'][i]*max(F(0),(weight(list(map(fr,atoms[i]['thresholds'])),t) if ks[i]<=r['r'] else F(0))-L*ref['K0'][i]) for i in range(6) if ref['D0'][i]);gamma=ref['D']*r['V']/(L*ref['QJ']);a=(r['r']+1)*r['c'];U=r['U'];c=r['c'];tail=U*R/(a*(U+c));z=max(F(0),r['Psi']-tail);X=a*(U+c*gamma);Y=(U+a*gamma)*(U+c);W=U*U-z*(X+Y);slack=U-r['A']-gamma*max(r['B']-R,F(0))
                equal(xx['R_L'],R,'R_L');equal(xx['gamma'],gamma,'gamma')
                ce=xx['certificate']
                for k,v in dict(X=X,Y=Y,z=z,W=W,square_lhs=W*W,square_rhs=4*z*z*X*Y,tail=tail,joint_domain_slack=slack).items():equal(ce[k],v,'certificate:'+k)
                assert slack>=0 and W>=0 and W*W>=4*z*z*X*Y
        out['producer_comparison']=dict(producer_json_sha256=sha(pb),exact_checks=checks,mismatch_count=len(errors),mismatches=errors)
        out['status']='PASS' if not errors else 'MISMATCH'

    print(json.dumps(out,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
