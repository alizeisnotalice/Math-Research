# R154 联合初端预算有限数值合同

状态：标量三阶段已实际完成，5048条Fraction检查PASS；不作一般证明、真实核行或FULL结论。只检查非线性M及其尾修正。真实sourcewise检验尚未运行。

## 1. 精确标量协议及实际账本

实现为同目录scalar_budget_check.py，只用标准库Fraction、random、json，解释器 `/opt/homebrew/opt/python@3.14/bin/python3.14`，PYTHONPATH未设置。调用：

    /opt/homebrew/opt/python@3.14/bin/python3.14 scalar_budget_check.py

默认输出同目录scalar_budget_check.json。固定seed154015，Python random.Random MT19937，调用顺序冻结于源码。没有新增核、receiver、质量模板。先声明坐标再构造联合域：A,B,R,gamma,slack非负，U=A+gamma*(B−R)_++slack；这仅是合法联合标量域参数化，不声称由原alpha产生。

三阶段：

1. 正内部网格486条：A,s,R,gamma,slack各取1/8、1、8，B=R+s，U=A+gamma*s+slack；(c,r)取(1/3,0)、(2,3)。
2. 同一四值网格中至少一坐标为0的1562条：每坐标取0、1/8、1、8，其余定义相同。覆盖U=0、gamma=0、B=0及联合域等号。
3. 扩大参数3000条：五独立坐标A,B,R,gamma,slack各为i/j乘10^-6、1或10^6，i=0..16、j=1..17，U按联合域公式生成；c为i/j乘上述尺度，i,j=1..17；r=0..64。按源码顺序消耗固定seed，不据结果追加样本。

对U>0令a=(r+1)c，X=a(U+c gamma)，Y=(U+a gamma)(U+c)，psi=AB/[(B+a)(A+B+c)]，z=max(0,psi−UR/[a(U+c)])。每条精确核 `W=U²−z(X+Y)>=0` 及 `W²>=4z²XY`，因此检查z<=M；没有计算sqrt。U=0直接核A=psi=0。gamma>0另核Y>=a gamma U，对应M<=U/(a gamma)的分母比较。没有用有理近似根号来替代证书。全部5048条通过；U=0计63、gamma=0计700、B=0计313、z>0计1196。计数可以交叠。

真实执行共5次：第一次在收到父级停止消息前已完成同5048非线性检查及1005条一般有限背包诊断；第二次移除背包并保存最终三阶段结果。前次背包诊断不纳入有效预算证据，最终代码不再执行它。第三次加入70位Decimal旧帽比较，第四次加入相对/绝对1e-50的近等阈值以免舍入假增益；第五次仅统一精确证书与Decimal显示的limitation文案后复现；五次均成功，无失败。JSON中的actual_invocations_with_model=5是本交付实际已发生次数，并非每次复现自动累加的计数器。

## 已知A旧帽比较（数值显示，与精确平方证书分开）

同菜单用70位Decimal并列 `A/(sqrt(a)+sqrt(A+c))²`、`B/a`、精确Psi的Decimal显示和 `M(U,gamma)+tail`；1e-50乘max(1,各帽绝对值)以内不登记严格增益。5048条中new低于已知A旧帽664条，高于4296条；同时低于旧A帽及B/a仅273条。按A/U<=1/4或>1/4、B/a<=1或>1交叉保存counts；U=0另列。不能仅比较U自由帽夸大收益，也不能据这套无原alpha的标量域把U−A叫原alphaV。真实控制必须另报告alphaV/U、A/U、B/a、R/B（B=0直记分支），定位增益来源。显示比较非根式严格区间证书，只有前述平方检查是精确证书。

## 2. 停止线性背包分支的代数理由

父级和Astra指出，原合法参数满足Kbad<=alpha QJ/D，alpha V<=U。因此在U,V,D,QJ>0且原alpha可控时，kappa=QJ(U+c)/(DV)>=Kbad*(U+c)/U>Kbad（Kbad>0）；Kbad=0时全源预算本已为0。有限背包f=1恒可行，其最优值就是全bad的w质量，故此线性放大不给新的有用付款。一般任意LP的零对偶gap不能改变这条原约束退化，不再测试/扩大该分支。零alpha、QJ、D或V的分支直接按合同自由帽处理，不写0/0或0∞。

## 3. 真实sourcewise最小检验：先缓存x0，后原六控制

仅I1固定ν比例(12,8,8)，采用R151 compact保存的nu_exact及固定lambda，禁止增加质量菜单。x0先只读R142 I1 `verifications` 中id=0的mp70逐源K0/K1/K2/J/Q缓存；136提供T,D、阈值、Delta=w_tau−w_h、源位置。142旧aggregate alpha、q、rho、U不能沿用。R151 detail的浮点alpha/QJ/rho/p/q只能作比对，不能据rho反解alpha或补K0/J。原R136生产脚本sourcewise U_v=min(...)并非本合同U_r。

对每个接收点，用同一ν逐源核同步重新计算三Q容量及q、共同QJ、原good/bad及E*、原alpha和rho、必要资格、FA。逐源保存K0,J,Q、TDelta、u_v=(1−DK0/(TDelta))_+、v_v=J/(TDelta)，核rho_v=u_v−alpha*v_v；Delta=0来源按原定义分支，不除0。必须先核原alpha QJ>=D*sum_D K0ν、rho>0及来源选择合法，再计算A=sum_E* rho*w_t*1score ν，U=sum_E* u*w_t*1score ν，V=sum_E* v*w_t*1score ν，核A=U−alpha V。B来自完整D0的低score质量；对预声明有限L计算R_L=sum_D (w_t1score−L K0)_+ν、gamma=DV/(LQJ)，精确/区间核联合域，再用平方证书。所有来源进入共同e，不删看似无贡献者。

逐cut先检初端tau+；另保h−和原阈值同刻两侧作为诊断，不把逐时最优M直接当统一时间primitive或忽略good注入。r=0..3，c=e_g及c=2Kq/p（仅由重算值验证high和c<=eg合法时）。L菜单固定为{1/4,1/2,1,2,4}，分别报告M+尾项和原Psi，自由帽并列；不据结果增加L。若L的原单位有不同归一化，须先回原定义确认并记录尺度，不能套自由无量纲数冒称最优。

x0已缓存6源，不新增核评价，但mp70数据自身并非核的区间认证；可先冻结其十进制为有理有限模型做精确恒等式，再把真实核误差另列。需与151原x0控制逐字段比较，差异不能藏在宽容差中。x0通过后复用原六控制位置：x0、m4最高weighted-B、m8最高weighted-B各含两个c版本；实际仅3个接收位置，c版本不重复核评价。非x0两位置当前缺sourcewise字段，各需6源共12个source×receiver核组；每组原三核均需评价，若各核一次则36个标量核调用，实际积分调用数按实现日志另计。p等额外接收量也须按原接口计算并计数，不能把“12组”当总积分次数。

先6控制仅实施/核验，不自动全扫。只有原alpha和联合域数值链成立、来源保存及误差口径审核后，才可另授权对原8376行补核；仍保持原网格/ν/位置不变。8376×6=50256组是未扣缓存的source×receiver上限，不是已执行次数或精确去重数。不得把R151保存的rho/alpha倒推缺失核，也不把必要资格当FULL。

## 4. 真实误差及决策口径

真实核如无外向区间只标mp70一致性；联合域/平方证书靠冻结有理输入可精确复现，但不能升级核认证。接近零的TDelta、QJ、V或资格边界先标未决，必要时少量控制提高精度，不盲目扩大网格。记录U,V,A,B,gamma,R,L、原共同alpha、每源贡献及所有异常/零分支。最终逐控制并列new M+tail、已知真实A的旧自由帽、B/a和精确Psi，再比较费用分项及R尾来源；不得由pointwise上界、有限标量或已有dx离散诊断推断一般n阶、统一外空间付款或FULL。
