#!/usr/bin/env python3
"""Portable R154 replay from existing compact round archives; no kernel reevaluation."""
from pathlib import Path
import argparse,json,shutil,subprocess,sys,zipfile,hashlib
p=argparse.ArgumentParser();p.add_argument('--rounds',type=Path,required=True);p.add_argument('--destination',type=Path,required=True);a=p.parse_args()
src=Path(__file__).resolve().parent;dst=a.destination.resolve()
if dst.exists():raise SystemExit('Use a new destination')
dst.mkdir(parents=True)
for name in ['joint_x0_probe.py','joint_x0_verify.py','scalar_budget_check.py','joint_numeric_plan.md','contract.md','source_inventory.md']:
    shutil.copy2(src/name,dst/name)
for rd,member in [('139','active_traffic_v2.json'),('142','numeric_receiver.json')]:
    with zipfile.ZipFile(a.rounds/rd/'research.zip') as z:
        candidates=[n for n in z.namelist() if Path(n).name==member]
        assert len(candidates)==1,(rd,candidates)
        (dst/member).write_bytes(z.read(candidates[0]))
def run(cmd,output=None):
    r=subprocess.run([sys.executable,*map(str,cmd)],cwd=dst,capture_output=True,text=True)
    if output:(dst/output).write_text(r.stdout)
    if r.returncode:raise RuntimeError(r.stderr+r.stdout)
    return r.stdout
run(['scalar_budget_check.py'])
args=['--r151-zip',a.rounds/'151/research.zip','--r136',dst/'active_traffic_v2.json','--r142',dst/'numeric_receiver.json']
print(run(['joint_x0_probe.py',*args,'--out',dst/'joint_x0_probe.json']).strip())
run(['joint_x0_verify.py',*args,'--producer',dst/'joint_x0_probe.json'],'joint_x0_verify.json')
v=json.loads((dst/'joint_x0_verify.json').read_text());assert v['status']=='PASS',v.get('producer_comparison')
for name in ['scalar_budget_check.json','joint_x0_probe.json']:
    assert (src/name).read_bytes()==(dst/name).read_bytes(),name+' differs from archived result'
print(json.dumps({'status':'PASS','reference_rows':v['rows'],'reference_L_checks':v['finite_L_checks'],'comparison':v['producer_comparison'],'new_kernel_evaluations':0},ensure_ascii=False))
