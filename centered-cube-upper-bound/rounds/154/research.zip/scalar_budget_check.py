#!/usr/bin/env python3
"""Finite exact rational diagnostics of R154; no original kernel/FULL claim."""
from fractions import Fraction as F
from decimal import Decimal, localcontext
from pathlib import Path
import argparse, hashlib, itertools, json, random

ROOT=Path(__file__).resolve().parent
SEED=154015

def encode(x):
    if isinstance(x,F): return {'numerator':str(x.numerator),'denominator':str(x.denominator)}
    if isinstance(x,dict): return {k:encode(v) for k,v in x.items()}
    if isinstance(x,(list,tuple)): return [encode(v) for v in x]
    return x

def check(U,gamma,A,B,R,c,r):
    assert min(U,gamma,A,B,R)>=0 and c>0 and r>=0
    assert A+gamma*max(B-R,F(0))<=U
    a=(r+1)*c
    psi=A*B/((B+a)*(A+B+c))
    if U==0:
        assert A==0 and psi==0
        return {'zero_U':1,'zero_gamma':int(gamma==0),'zero_B':int(B==0),'active_z':0}
    X=a*(U+c*gamma);Y=(U+a*gamma)*(U+c)
    z=max(F(0),psi-U*R/(a*(U+c)))
    # z <= U²/(sqrt(X)+sqrt(Y))², without evaluating sqrt.
    W=U*U-z*(X+Y)
    assert W>=0 and W*W>=4*z*z*X*Y
    if gamma>0:
        # denominator >= Y >= a*gamma*U, hence M <= U/(a*gamma).
        assert Y>=a*gamma*U
    return {'zero_U':0,'zero_gamma':int(gamma==0),'zero_B':int(B==0),'active_z':int(z>0)}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--output',default=str(ROOT/'scalar_budget_check.json'));args=ap.parse_args()
    rng=random.Random(SEED);phases={};comparison={};boundary={k:0 for k in ['zero_U','zero_gamma','zero_B','active_z']}
    def run(params):
        flags=check(*params)
        for k,v in flags.items():boundary[k]+=v
        U,gamma,A,B,R,c,r=params
        with localcontext() as ctx:
            ctx.prec=70
            dec=lambda v:Decimal(v.numerator)/Decimal(v.denominator)
            a=(r+1)*c;u,g,aa,b,rr,cc,az=map(dec,[U,gamma,A,B,R,c,a])
            old=Decimal(0) if A==0 else aa/(az.sqrt()+(aa+cc).sqrt())**2
            new=Decimal(0) if U==0 else u*u/((az*(u+cc*g)).sqrt()+((u+az*g)*(u+cc)).sqrt())**2+u*rr/(az*(u+cc))
            cheap=b/az
            psi=aa*b/((b+az)*(aa+b+cc))
            key=('U0' if U==0 else ('A/U<=1/4' if 4*A<=U else 'A/U>1/4'))+'/'+('B/a<=1' if B<=a else 'B/a>1')
            st=comparison.setdefault(key,dict(cases=0,new_below_known_A_old=0,new_below_B_over_a=0,new_below_both=0,new_above_known_A_old=0))
            tol=Decimal('1e-50')*max(Decimal(1),abs(new),abs(old),abs(cheap))
            st['cases']+=1;st['new_below_known_A_old']+=new<old-tol;st['new_below_B_over_a']+=new<cheap-tol;st['new_below_both']+=new<min(old,cheap)-tol;st['new_above_known_A_old']+=new>old+tol
            assert psi<=old+Decimal('1e-50') and psi<=cheap+Decimal('1e-50')

    count=0;interior=0;edge=0
    # Predeclared grid: A,s,R,gamma,slack; B=R+s, U=A+gamma*s+slack.
    vals=[F(0),F(1,8),F(1),F(8)]
    for A,s,R,gamma,slack in itertools.product(vals,repeat=5):
        for c,r in [(F(1,3),0),(F(2),3)]:
            run((A+gamma*s+slack,gamma,A,R+s,R,c,r));count+=1
            if min(A,s,R,gamma,slack)>0:interior+=1
            else:edge+=1
    phases['initial_positive_grid']=dict(checks=interior,values=vals[1:],c_r=[(F(1,3),0),(F(2),3)])
    phases['zero_boundary_grid']=dict(checks=edge,values=vals,criterion='at least one of A,s,R,gamma,slack is zero',c_r=[(F(1,3),0),(F(2),3)])
    count=0
    scales=[F(1,10**6),F(1),F(10**6)]
    for _ in range(3000):
        vals2=[F(rng.randrange(0,17),rng.randrange(1,18))*rng.choice(scales) for _ in range(5)]
        A,B,R,gamma,slack=vals2
        U=A+gamma*max(B-R,F(0))+slack
        run((U,gamma,A,B,R,F(rng.randrange(1,18),rng.randrange(1,18))*rng.choice(scales),rng.randrange(0,65)));count+=1
    phases['expanded_joint_domain']=dict(checks=count,independent_coordinates=['A','B','R','gamma','slack'],numerator=[0,16],denominator=[1,17],scales=scales,r=[0,64])
    result=dict(status='PASS',scope='Finite exact rational scalar checks only; not true-kernel model or FULL or general proof',seed=SEED,rng='Python random.Random MT19937; fixed call order in source',execution=dict(actual_invocations_with_model=5,new_kernel_evaluations=0,new_receiver_points=0),producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),contract_sha256=hashlib.sha256((ROOT/'contract.md').read_bytes()).hexdigest(),phases=phases,numeric_cap_comparison=dict(precision=70,certified=False,groups=comparison,note='Known A old free cap and B/a, not U free cap. U-A is abstract scalar gap, not a reconstructed original alpha*V.'),boundary_counts=boundary,scalar_inequality_checks=2048+3000,superseded_lp_diagnostic=dict(checks=1005,actual_run_before_stop=True,retained_as_evidence=False,reason="Original legal kappa exceeds total bad K0; f=1 feasible, so no useful new budget"),limitation='Exact rational inequality certificates evaluate no sqrt or log. Numeric cap comparisons use Decimal sqrt at precision70 and are not certified. These scalar joint-domain tests do not reconstruct original alpha or kernels.')
    Path(args.output).write_text(json.dumps(encode(result),ensure_ascii=False,indent=2)+'\n');print(json.dumps({'status':result['status'],'scalar_checks':result['scalar_inequality_checks'],'boundary_counts':boundary}))
if __name__=='__main__':main()
