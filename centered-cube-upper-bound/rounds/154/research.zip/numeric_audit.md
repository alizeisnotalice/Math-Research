# R154 x0 独立参考审计

状态：独立canonical参考及最终producer逐字段比较PASS；960个精确字段检查零不一致。只处理R151固定I1(12,8,8)的x0已有缓存，0新增kernel、0新增receiver。不会扩展网格。

## 独立性与输入

先读自己的joint_numeric_plan.md和source_inventory.md，不读joint_x0_probe源码或结果，独立写新reference并第一次实跑成功；随后才读取producer JSON形成adapter。首次reference使用136保存Delta/wg；收到父级canonical要求后，统一从136 thresholds的Fraction重建w、Delta=w_tau−w_h及wg，再独立实跑。未import producer。独立reference形成并实跑后，为排查整数文本解析上限导致的假mismatch，才读取producer的证书函数；它未改变独立新公式。不能将最终adapter阶段描述为未看源码的盲核，独立性在首次reference形成时建立。所有源均保留。

R151 `research.zip` compact `constants.nu_exact` **已经是实际重加权后的共同ν**，不能再乘一次倍率。首次读producer JSON发现它把该向量叫nu_base，再乘4096/256；已通知父级及实现方。此前错误输入运行已撤回，不属于当前有限模型证据。另一次角色来源由保存136角色改为原式重算；最终严格使用重算角色，保存角色仅差异报告。最终必须直接逐项等于原151 compact.constants.nu_exact。R142 cache id=0 mp70仅提供逐源K0/K1/K2/J及p；重新计算Q=(K1+K2+J)/3、q=max(νK0,νJ,νQ)、QJ=νJ。Q/alpha/rho等旧aggregate不复用。

固定SHA：R151 compact `6bfc604946efcb7461b354e1d1f5347319b519548e1c4448a35643b5f911b731`；R142 `c46a90467707b9d05ae03cb17d0f63e60bf7709dfd5c717550e3d3278957ae55`；R136 `1090fb2356abe035a997eb851a2f0252a3abe3edbeaf978e99900a38906392de`。参考会严格核输入SHA。

## 独立计算合同

原terminalgood为p wg<=KQ；E=terminalgood且Delta>0；cap_v=1_E min(TDelta,DK0)，alpha=(Dq−Σνcap)/QJ；rho=1_E[1−(cap+alphaJ)/(TDelta)]_+。E*=rho>0，D0=非terminalgood，不把hard_sources当D0。对E*计算u=(1−DK0/(TDelta))_+、v=J/(TDelta)，精确核rho=u−alpha v；reserve=alphaQJ−DΣ_D0νK0>=0。

cut的A,U,V,B与阈值w/score来自同一canonical模型，严格核A=U−alphaV。初端tau+、末端h−、每个内部threshold左右、每个连续段中点，共72个(t,side,r,c)控制；c=eg及合法2Kq/p，r=0..3。每控制L={1/4,1/2,1,2,4}共360次严格核联合域、W>=0、W²>=4z²XY。这个范围是同一接收点的纯代数后处理，不是新增核样本。

此外对平方根用math.isqrt给80位十进制格上的**有理向外夹逼**，检查lo²<=q<=hi²，再给M+tail和已知真实A旧峰的上下界。因此帽的严格比较与90位Decimal显示分开。B峰所在侧用精确B²−a(A+c)，B/(B+a)本身是Fraction。未把mp70核十进制冻结等同于真实kernel区间认证。

## 当前参考结论

共同alpha≈.8887705904533536；good=[T,T,T,F,F,T]，E*=[T,T,T,F,F,F]，rho≈[.6832621108,.7208007334,.7026420547,0,0,0]。q由νJ最大，三测试约6.15146084e−8、2.39355616e−7、1.13351706e−7；reserve≈2.12709735e−7>0。初端A/U≈.6851524746，故alphaV/U≈.3148475254。

canonical−136保存Delta最大绝对差约7.55e−121，wg最大绝对差约8.17e−121；保存差只作冻结舍入比较，未造额外阈值跳。新rho全部重算，未反演或复制旧rho。

初端8个(r,c)均严格位于真实A旧自由峰右侧。固定五L菜单40帽全部由有理根式夹逼严格证为比已知A旧峰大，故这组初端控制没有新帽优势。全部72控制/360L（还含后续阈值两侧和中点）中194帽严格低于旧A峰、166严格高于；这不把后时pointwise低帽冒称统一时间primitive或空间付款。例r=0,eg：精确Psi≈.1290485711，旧已知A峰≈.1725600002，而固定L菜单最小M+tail≈2.634358144。新帽不能仅与更松的U自由帽比较来报告改善。此为原固定模型的初端诊断，不推一般维数阶、空间付款或FULL。

## 最终运行、结果与冻结

参考脚本只用标准库，解释器 `/opt/homebrew/opt/python@3.14/bin/python3.14`，PYTHONPATH未设置。实际已完成三次reference运行：首次保存Delta口径、canonical修订、加入有理帽比较；三次均exit0。其后共四次adapter运行：第一次nu字段改名KeyError；第二次完成但124个字段假mismatch（Python默认4300digits整数解析上限），读取producer证书函数定位后解除该文本限制；第三次producer正在修schema，terminal_good改名导致KeyError；最终冻结schema后第四次PASS。总计7次本代理reference/adapter调用，2次进程exit1、5次exit0，其中一次exit0报告MISMATCH；严格以JSON状态判通过，不将exit0等同认可。两次KeyError均为adapter读取schema问题，不是数学反例。producer自报5次完成、0进程失败，其中2次错误输入已撤回；这是实现方账本，非本代理执行次数。

    /opt/homebrew/opt/python@3.14/bin/python3.14 joint_x0_verify.py

最终调用：

    /opt/homebrew/opt/python@3.14/bin/python3.14 joint_x0_verify.py --producer joint_x0_probe.json > /tmp/r154_x0_producer_comparison.json

实际结果status=PASS，exact_checks=960，mismatch_count=0。其中六源共同ν、canonical Delta/wg、q的三测试、Q、QJ、alpha、重算good/E/E*/D0/rho/cap、四cut的初端U/V/A/B、8个c/r行及其固定/缩放L共80条证书逐项匹配；每个L的X/Y/z/W、平方两边、tail、domain slack均精确比较。源码SHA和关键输入SHA也严格核验。独立reference自己的固定L覆盖为360次，与producer80条不是同一计数，不相加冒充独立样本。producer额外缩放L只验证所存有限值，不将它扩为新的搜索协议。

最终producer源码SHA256：`bfac952af5bb76a705f19010c891f7756c35b6da0d26a6d30ccb9e891682da90`。
最终producer JSON SHA256：`5d38f8b0229d175c94b8573f80a7df4616575a00cdb10c04cbc638cb47a44d11`。
参考检查程序SHA256：`ecf270488c3f20991680d225d22be48de2e6e1db0560d2a3959445f70b330f76`。
结果报告SHA256：`fb335dd2a0ef912342b61eeb39221bf328805e475454b8f225a0dbbf73a26bbd`。

精确证明范围为冻结mp70十进制的自洽有限有理模型；核自身的真实误差、空间接收付款、外history与FULL未认证。Decimal显示不作为超越数或kernel证书；所报固定L新帽与旧A峰严格顺序由独立有理sqrt夹逼支撑。冻结后停止，不做其他控制或网格。
