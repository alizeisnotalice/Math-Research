# R578 发布前只读代码/范围核验与实际重放

**全部通过。** 三个原脚本逐一实际运行到指定新输出；去掉时间、RSS、解释器/版本/命令元数据后，所有确定数学字段与原结果逐字段相同。未忽略任何几何、计数、精确系数、信用值、分割比值或Arb包含球。原脚本和原结果SHA在运行前后保持不变。

完整回执 `/tmp/ccu_r578_replay.json` 保存每个script、原result、重放result及数学投影SHA、实际命令/版本、返回码、比较规则和资源。

## 实际对象与assert核验

**Overlap。** 仅一个n3/八单位顶点模型、完整70个4-subset witnesses、127个互补非平凡source partitions。19条静态assert（在循环内重复执行）包括全部实际盒正宽、7种盒及pair交集、原H2不相交、实际union公式、face初探、signed D=新体积−overlap、Psi分母正及最优比较。根式体积在Q(∛2)中Fraction精确；Arb512核符号、log与ratio。重放保持全部127个D>0，三个face cuts最佳；不是扫描所有维数或所有任意超平面方向。

**Credit。** 四个固定n1六源输入，每个完整63子集、所有实际端点细胞及其全部witness mass去重。8条静态assert包括正质量/不同坐标、完整band、V非负与log界、信用不等式strict slack、root31个分组。端点、R、V积分和signed D为Fraction精确；F分支用c与1、U/L的准确比较，Arb256只算log与最后费用。实际四输入全部F项都在中间支；原说明稿明确未实测其它F分支，没有误称全分支扫描。A/C信用分别239/300、37/75，B/D残余0，全部保持。

**Plane。** 实际是K∈{2,4,8,16}×u∈{(1,0,0),(1,1,1),(1,2,5),(1,17,257)}共16个固定有限projection laws。Counter与整数投影完整枚举当前输入的投影支持，包含全部ties，按整个tie group前/后各半处理。采样group质量count/(8N)，两侧各count/(16N)；source split mass为before_count/8，保持原单位1/8质量。9条静态assert包含split counts范围、endpoint DeltaPsi包含0/其它strict正、总质量计数、配对下界和axis准确公式。

投影split数量与配对界是Fraction精确；v0、Psi和ED/EDeltaPsi为Arb256包含球。ED采用Astra解析几何恒等式D=v0·被切基底数，不是代码重新枚举所有跨复制source subsets；该解析依据见Astra第2节。所有u的一致障碍是另行解析证明，不由这16条方向数值枚举产生。脚本/JSON已有finite方向scope，Astra也将解析论证与计算分开；未发现必须修改的范围误称。不要在发布摘要中把本次重放改写成“数值扫描所有方向”。

## 实际命令与结果

共同前缀：
`OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 /Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python`

依次运行：

1. `/tmp/ccu_r578_numeric.py --output /tmp/ccu_r578_replay_overlap.json`
2. `/tmp/ccu_r578_credit_numeric.py --output /tmp/ccu_r578_replay_credit.json`
3. `/tmp/ccu_r578_plane_numeric.py --output /tmp/ccu_r578_replay_plane.json`

三个returncode均0，stderr均空，全部数学投影与原始输出相同。Python3.12.14、python-flint0.9.0；overlap另用SymPy1.14.0。原脚本精度分别Arb512、256、256。重放内部运行时约0.0655、0.00519、0.2494秒；含子进程及核验总约0.571秒。每项timeout60秒，串行单进程。plane原脚本没有RSS字段，回执保留为缺失，未造数。

## 原脚本SHA256

|脚本|SHA256|
|---|---|
|overlap|1ed1c1802662b5fbf7766a535cf863a6c492fcb33158fb84bcce8e183a4eedda|
|credit|4a07f79147cc84174cd89d0624aa4bd4c811779925267a10c2a8c497be078360|
|plane|5349e86f8b2924cc1723877b86d1c5fc85c3de2cd55adc4b773e91cec08cc55d|

完整原结果/重放结果SHA见JSON，数学投影SHA也独立保存。此次是只读代码与可重复性核验，不代替一般全方向解析证明的独立审稿。仅写本说明/回执及获准的三个新重放输出，未改原稿、原结果、仓库或他人文件；无LP/扩展扫描/子代理/PDF。完成停止。
