"""Four frozen n1 full-band all-witness credit experiments, exact Fraction cells."""
from fractions import Fraction as Q
from pathlib import Path
import argparse,json,sys,platform,time,resource,shlex
import flint
from flint import arb,ctx
ctx.prec=256
parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,default=Path(__file__).resolve().parent/'credit_numeric.json');args=parser.parse_args();START=time.perf_counter()
def aq(q):q=Q(q);return arb(q.numerator)/q.denominator
def av(q):return aq(q).str(60)
models=[('A_dense',[Q(i,10) for i in range(6)],[Q(1)]*6),('B_even_spacing',[Q(3*i,5) for i in range(6)],[Q(1)]*6),('C_two_dense_clusters',list(map(Q,['0','1/10','1/5','3','31/10','16/5'])),[Q(1)]*6),('D_nonuniform',list(map(Q,['0','1/4','1','3/2','11/4','4'])),list(map(Q,['1/2','1','2','1/2','1','2'])))]
rows=[]
for name,z,weights in models:
 assert len(set(z))==6 and all(w>0 for w in weights)
 W=sum(weights,Q(0));L=min(weights);U=W;T=aq(U/L).log();H=[(x-w,x+w) for x,w in zip(z,weights)]
 subsets=[];coords=set(e for h in H for e in h)
 for mask in range(1,64):
  ids=[i for i in range(6) if mask>>i&1];m=sum((weights[i] for i in ids),Q(0))
  lo=max(z[i] for i in ids)-m/2;hi=min(z[i] for i in ids)+m/2
  assert L<=m<=U
  box=(lo,hi) if lo<hi else None
  if box:coords.update(box)
  subsets.append({'mask':mask,'mass':m,'box':box})
 coords=sorted(coords);E=Q(0);Hvol=Q(0);R=Q(0);credit=Q(0);cells=[]
 for lo,hi in zip(coords,coords[1:]):
  witness=[s for s in subsets if s['box'] and s['box'][0]<=lo and hi<=s['box'][1]]
  insideH=any(a<=lo and hi<=b for a,b in H)
  width=hi-lo
  if witness:E+=width
  if insideH:Hvol+=width
  if witness and not insideH:
   masses=sorted({s['mass'] for s in witness});V=sum((1-a/b for a,b in zip(masses,masses[1:])),Q(0))
   assert V>=0
   if len(masses)>1:assert aq(V)<aq(masses[-1]/masses[0]).log()
   else:assert V==0
   R+=width;credit+=width*V
   cells.append({'interval':[str(lo),str(hi)],'length':str(width),'witness_masks':[s['mask'] for s in witness],'distinct_witness_masses':list(map(str,masses)),'V_exact':str(V),'integrated_V_exact':str(width*V)})
 rhs=arb(0);terms=[]
 for i,w in enumerate(weights):
  c=2*w/L;expT=U/L
  if c>=expT:Fval=arb(0);branch='c>=exp(T): zero'
  elif c<=1:Fval=1+T-aq(c);branch='c<=1: 1+T-c'
  else:Fval=T-aq(c).log();branch='1<c<exp(T): T-log(c)'
  rhs+=aq(w)*Fval
  terms.append({'source':i,'mass':str(w),'c_exact':str(c),'expT_exact':str(expT),'branch':branch,'F_Arb':Fval.str(60),'mass_times_F_Arb':(aq(w)*Fval).str(60)})
 lhs=R+credit;slack=rhs-aq(lhs);assert slack>0
 # Optional finite root partition check, same actual H and complete band.
 v={}
 for mask in range(1,64):
  v[mask]=sum((Q(c['length']) for c in cells if any(s&mask==s for s in c['witness_masks'])),Q(0))
 assert v[63]==R
 partitions=[]
 for left in range(1,63,2):
  right=63^left;D=v[63]-v[left]-v[right]
  partitions.append({'left_mask':left,'right_mask':right,'left_mass':str(sum((weights[i] for i in range(6) if left>>i&1),Q(0))),'v_left':str(v[left]),'v_right':str(v[right]),'D_signed_exact':str(D)})
 assert len(partitions)==31
 rows.append({'model':name,'n':1,'lambda':1,'b':1,'positions':list(map(str,z)),'source_masses':list(map(str,weights)),'W':str(W),'band':[str(L),str(U)],'T_Arb':T.str(60),'original_high_greedy_blocks':'six singletons: distinct positions imply every nonsingleton beta<1','H2_singleton_intervals':[[str(a),str(b)] for a,b in H],'all_subset_count':63,'positive_C_count':sum(s['box'] is not None for s in subsets),'all_subsets':[{'mask':s['mask'],'mass':str(s['mass']),'C':[str(x) for x in s['box']] if s['box'] else None} for s in subsets],'arrangement_interval_count':len(coords)-1,'full_band_E_volume':str(E),'H2_volume':str(Hvol),'residual_volume_exact':str(R),'credit_integral_exact':str(credit),'credit_nonzero':credit>0,'credit_inequality_LHS_exact':str(lhs),'source_exposure_upper_RHS_Arb':rhs.str(60),'RHS_minus_LHS_Arb':slack.str(60),'full_credit_inequality_certified':True,'F_terms':terms,'residual_cells':cells,'root_partitions':partitions,'root_D_counts':{'negative':sum(Q(p['D_signed_exact'])<0 for p in partitions),'zero':sum(Q(p['D_signed_exact'])==0 for p in partitions),'positive':sum(Q(p['D_signed_exact'])>0 for p in partitions)}})
result={'status':'PASS_FOUR_N1_COMPLETE_BAND_CREDIT_INEQUALITIES','rows':rows,'credit_formula':'V=sum_j[1-m_j/m_(j+1)] with all actual distinct witnessing masses at each real residual cell','inequality':'|R|+integral_R V <= sum_i m_i F(2m_i/L,log(U/L)), lambda=1','F_branch_decisions':'Exact Fraction comparison of c with1 and U/L; Arb evaluates logs only after branch fixed','arithmetic_error':'0 for actual intervals, all witness incidence, residual volume and credit','Arb_precision_bits':256,'interpreter':sys.executable,'python_version':platform.python_version(),'python_flint_version':flint.__version__,'command':'OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 '+shlex.join([sys.executable]+sys.argv),'runtime_seconds':time.perf_counter()-START,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'processes':1,'scope':'Four frozen n1 full-band models only; genuine credit implementation, no dimension-order inference or general root-order improvement.'}
args.output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps([{k:r[k] for k in ['model','positive_C_count','residual_volume_exact','credit_integral_exact','credit_inequality_LHS_exact','source_exposure_upper_RHS_Arb','root_D_counts']} for r in rows],ensure_ascii=False,indent=2))
print(json.dumps({k:result[k] for k in ['status','runtime_seconds','peak_rss_bytes']},indent=2))
