"""Frozen n3 eight-vertex all-four-subset signed receiver/Psi experiment."""
from fractions import Fraction as Q
from itertools import product,combinations
from pathlib import Path
import argparse,json,sys,platform,time,resource,shlex
import sympy as S
import flint
from flint import arb,ctx
ctx.prec=512
parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,default=Path(__file__).resolve().parent/'numeric.json');args=parser.parse_args();START=time.perf_counter()
ZERO=(Q(0),)*3;ONE=(Q(1),Q(0),Q(0));alpha=(Q(0),Q(1),Q(0));alpha2=(Q(0),Q(0),Q(1));r8=(Q(2),Q(0),Q(0));SIGN_COUNT=0
A=(arb(2).log()/3).exp()
def aq(x):x=Q(x);return arb(x.numerator)/x.denominator
def add(x,y):return tuple(a+b for a,b in zip(x,y))
def neg(x):return tuple(-a for a in x)
def sub(x,y):return add(x,neg(y))
def scale(x,c):return tuple(a*Q(c) for a in x)
def mul(x,y):
 z=[Q(0)]*3
 for i,a in enumerate(x):
  for j,b in enumerate(y):
   k=i+j;z[k%3]+=a*b*(2 if k>=3 else 1)
 return tuple(z)
def av(x):return aq(x[0])+aq(x[1])*A+aq(x[2])*A**2
def sign(x):
 global SIGN_COUNT
 if x==ZERO:return 0
 SIGN_COUNT+=1;v=av(x)
 if v>0:return 1
 if v<0:return -1
 raise AssertionError('Unresolved cubic-field sign')
def expr(x):return str(sum(S.Rational(a.numerator,a.denominator)*2**S.Rational(i,3) for i,a in enumerate(x)))
def out(x):return {'basis':'1,cuberoot(2),cuberoot(4)','exact_coefficients':list(map(str,x)),'expression':expr(x),'Arb512':av(x).str(60)}
def volume(box):
 v=ONE
 for lo,hi in box:
  width=sub(hi,lo)
  if sign(width)<=0:return ZERO
  v=mul(v,width)
 return v
def intersection(a,b):
 box=[]
 for (al,ah),(bl,bh) in zip(a,b):
  lo=bl if sign(sub(bl,al))>0 else al;hi=bh if sign(sub(bh,ah))<0 else ah
  box.append((lo,hi))
 return tuple(box)
d=scale(add(scale(alpha2,3),alpha),Q(1,4));s=scale(d,Q(1,2));delta=sub(alpha2,d)
core=tuple((scale(delta,Q(-1,2)),scale(delta,Q(1,2))) for _ in range(3));corevol=volume(core)
b=1/arb(3).sqrt();highupper=av(sub(ONE,scale(d,Q(1,2))))
guards={'delta_positive':sign(delta)>0,'d_lt_r8':sign(sub(r8,d))>0,'all_nonsingle_beta_upper_lt_b':bool(highupper<b),'core_H2_coordinate_gap_positive':sign(sub(sub(s,scale(delta,Q(1,2))),scale(alpha,Q(1,2))))>0}
assert all(guards.values())
vertices=list(product([-1,1],repeat=3));positions=[tuple(scale(s,x) for x in v) for v in vertices]
actual=[];uniqueboxes=[];lookup={}
for ids in combinations(range(8),4):
 mask=sum(1<<i for i in ids);box=[]
 for j in range(3):
  lo_source=scale(s,min(vertices[i][j] for i in ids));hi_source=scale(s,max(vertices[i][j] for i in ids))
  box.append((sub(hi_source,scale(alpha2,Q(1,2))),add(lo_source,scale(alpha2,Q(1,2)))))
 box=tuple(box);assert sign(volume(box))>0
 if box not in lookup:lookup[box]=len(uniqueboxes);uniqueboxes.append(box)
 fixed=[j for j in range(3) if len({vertices[i][j] for i in ids})==1]
 actual.append({'mask':mask,'source_indices':list(ids),'fixed_coordinate_count':len(fixed),'fixed_coordinates':fixed,'unique_box_index':lookup[box]})
assert len(actual)==70 and len(uniqueboxes)==7
assert sum(x['fixed_coordinate_count']==1 for x in actual)==6
assert all(x['fixed_coordinate_count'] in [0,1] for x in actual)
assert core in lookup
for i,x in enumerate(uniqueboxes):
 assert intersection(x,core)==core
 for y in uniqueboxes[i+1:]:assert intersection(x,y)==core
# True original H2: eight singleton expanded cubes, side alpha.
H=[tuple((sub(pj,scale(alpha,Q(1,2))),add(pj,scale(alpha,Q(1,2)))) for pj in p) for p in positions]
for x in uniqueboxes:
 for h in H:assert volume(intersection(x,h))==ZERO
vols=[volume(x) for x in uniqueboxes]
def union_volume(indices):
 indices=set(indices)
 if not indices:return ZERO
 v=ZERO
 for i in indices:v=add(v,vols[i])
 return sub(v,scale(corevol,len(indices)-1))
node_boxes={mask:{a['unique_box_index'] for a in actual if a['mask']&mask==a['mask']} for mask in range(1,256)}
v={mask:union_volume(k) for mask,k in node_boxes.items()}
fullformula=add(corevol,scale(mul(d,mul(delta,delta)),6));assert v[255]==fullformula
assert all(v[1<<i]==ZERO for i in range(8))
face_masks=[sum(1<<i for i,vtx in enumerate(vertices) if vtx[j]<0) for j in range(3)]
def phi(m):
 if m<=2:return arb(0)
 if m<=4:return m*aq(Q(m,2)).log()
 return m*(1+arb(2).log())-4
def psi(m):return b*phi(m)+(1-b)*max(m-2,0)
face_initial=[]
for left in face_masks:
 right=255^left
 assert left.bit_count()==4 and right.bit_count()==4
 overlap=sub(add(v[left],v[right]),union_volume(node_boxes[left]|node_boxes[right]))
 assert overlap==corevol
 D=sub(sub(v[255],v[left]),v[right]);assert sign(D)>0
 expectedD=sub(scale(mul(d,mul(delta,delta)),4),corevol);assert D==expectedD
 face_initial.append({'left_mask':left,'right_mask':right,'overlap':out(overlap),'D':out(D),'ratio_Arb':(av(D)/(psi(8)-2*psi(4))).str(60)})
rows=[];best=[]
for left in range(1,255,2):
 right=255^left;ml=left.bit_count();mr=right.bit_count()
 dp=psi(8)-psi(ml)-psi(mr);assert dp>0
 D=sub(sub(v[255],v[left]),v[right])
 childunion=union_volume(node_boxes[left]|node_boxes[right]);overlap=sub(add(v[left],v[right]),childunion);newvol=sub(v[255],childunion)
 assert D==sub(newvol,overlap) and sign(overlap)>=0 and sign(newvol)>=0
 ratio=av(D)/dp
 coordinate=left in face_masks or right in face_masks
 row={'left_mask':left,'right_mask':right,'child_masses':[ml,mr],'is_coordinate_face_partition':coordinate,'v_left':out(v[left]),'v_right':out(v[right]),'child_receiver_overlap':out(overlap),'new_parent_receiver_volume':out(newvol),'signed_D':out(D),'D_sign':sign(D),'DeltaPsi_Arb':dp.str(60),'D_over_DeltaPsi_Arb':ratio.str(60),'_ratio':ratio,'_D':D,'_mass_pair':tuple(sorted((ml,mr)))}
 rows.append(row);i=len(rows)-1
 if not best:best=[i]
 else:
  old=rows[best[0]]
  if D==old['_D'] and row['_mass_pair']==old['_mass_pair']:best.append(i)
  elif ratio<old['_ratio']:best=[i]
  elif old['_ratio']<ratio:pass
  else:raise AssertionError('Unresolved partition optimum')
assert len(rows)==127
coordinate_rows=[i for i,r in enumerate(rows) if r['is_coordinate_face_partition']];assert len(coordinate_rows)==3
noncoordinate=[i for i,r in enumerate(rows) if not r['is_coordinate_face_partition']]
best_noncoord=[]
for i in noncoordinate:
 if not best_noncoord:best_noncoord=[i];continue
 r=rows[i];old=rows[best_noncoord[0]]
 if r['_D']==old['_D'] and r['_mass_pair']==old['_mass_pair']:best_noncoord.append(i)
 elif r['_ratio']<old['_ratio']:best_noncoord=[i]
 elif old['_ratio']<r['_ratio']:pass
 else:raise AssertionError('Unresolved noncoordinate optimum')
result={'status':'PASS_ALL_70_ACTUAL_WITNESSES_127_SOURCE_PARTITIONS','n':3,'N':8,'lambda':1,'band':[4,4],'root_mass':8,'root_mass_above_U_retained':True,'definitions':{'alpha':'cuberoot(2)','r2':'alpha','r4':'alpha^2','d_2s':'(3*alpha^2+alpha)/4','delta':'(alpha^2-alpha)/4','Psi':'b*Phi+(1-b)*(m-2)_+, Phi uses band[4,4] tangent above4, b=1/sqrt3'},'guards':guards,'nonsingle_beta_upper_Arb':highupper.str(60),'b_Arb':b.str(60),'H2_gap':out(sub(sub(s,scale(delta,Q(1,2))),scale(alpha,Q(1,2)))),'d':out(d),'delta':out(delta),'core_overlap_volume':out(corevol),'full_actual_band_union_volume':out(v[255]),'full_union_formula':'delta^3+6*d*delta^2','vertices_sign_labels':vertices,'actual_four_subset_witnesses':actual,'unique_actual_boxes':[{'index':i,'bounds':[[out(e) for e in pair] for pair in box],'volume':out(vols[i])} for i,box in enumerate(uniqueboxes)],'all_distinct_box_pair_intersections_equal_core':True,'all_actual_witness_boxes_disjoint_from_original_H2':True,'union_certificate':'Every distinct box contains same core and every pair intersection equals core; all higher intersections equal core, hence union=sum volumes-(boxcount-1)*core_volume. All 70 witness masks mapped to these actual boxes.','initial_coordinate_face_certificates':face_initial,'coordinate_face_partition_indices':coordinate_rows,'best_partition_indices':best,'best_noncoordinate_partition_indices':best_noncoord,'best_ratio_Arb':rows[best[0]]['D_over_DeltaPsi_Arb'],'best_noncoordinate_ratio_Arb':rows[best_noncoord[0]]['D_over_DeltaPsi_Arb'],'signed_D_counts':{'negative':sum(r['D_sign']<0 for r in rows),'zero':sum(r['D_sign']==0 for r in rows),'positive':sum(r['D_sign']>0 for r in rows)},'partitions':[{k:v for k,v in r.items() if not k.startswith('_')} for r in rows],'exact_volume_arithmetic_error':'0 cubic-field Fraction arithmetic, alpha^3=2','certificate_precision_bits':512,'certified_nonzero_sign_decisions':SIGN_COUNT,'comparison_unresolved':0,'interpreter':sys.executable,'python_version':platform.python_version(),'sympy_version':S.__version__,'python_flint_version':flint.__version__,'command':'OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 '+shlex.join([sys.executable]+sys.argv),'runtime_seconds':time.perf_counter()-START,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'processes':1,'scope':'One frozen n3 finite model only; signed D uses full actual all-four-subset receiver union, not only two child boxes. No general split theorem or dimension inference.'}
args.output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['status','guards','signed_D_counts','coordinate_face_partition_indices','best_partition_indices','best_noncoordinate_partition_indices','best_ratio_Arb','best_noncoordinate_ratio_Arb','runtime_seconds','peak_rss_bytes']},ensure_ascii=False,indent=2))
for i in coordinate_rows+best_noncoord[:1]:
 r=rows[i];print(json.dumps({'index':i,'masks':[r['left_mask'],r['right_mask']],'masses':r['child_masses'],'D':r['signed_D']['expression'],'overlap':r['child_receiver_overlap']['expression'],'newvolume':r['new_parent_receiver_volume']['expression'],'ratio':r['D_over_DeltaPsi_Arb']},ensure_ascii=False))
