from pathlib import Path
from collections import Counter
from itertools import product
from fractions import Fraction as F
from bisect import bisect_left,bisect_right
import json,sys,time,platform,flint,argparse
from flint import arb,ctx
ctx.prec=256
ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=Path(__file__).with_suffix('.json'));args=ap.parse_args();start=time.perf_counter()
def aq(x):
 x=F(x);return arb(x.numerator)/x.denominator
b=1/arb(3).sqrt();a=F(1,2)
def psi(m):
 m=F(m)
 if m<=a:return arb(0)
 if m<=1:return aq(m-a)+b*(aq(m)*aq(m/a).log()-aq(m-a))
 return aq(m)*(1+b*arb(2).log())-(1+b)/2
h=(arb(1)/4).root(3)/2
assert h>arb(1)/4 and h<arb(3)/8
v0=(arb(1)/4)**3-8*(h-arb(1)/4)**3
assert v0>arb(1)/1728
rows=[]
for K in (2,4,8,16):
 N=K**3
 for u in ((1,0,0),(1,1,1),(1,2,5),(1,17,257)):
  offsets=Counter(3*sum(s*j for s,j in zip(e,u)) for e in product((-1,1),repeat=3))
  width=3*sum(abs(j) for j in u)
  centers=[32*sum(c*j for c,j in zip(cube,u)) for cube in product(range(K),repeat=3)]
  atoms=Counter()
  for c in centers:
   for off,count in offsets.items():atoms[c+off]+=count
  mins=sorted(c-width for c in centers);maxs=sorted(c+width for c in centers)
  numer=0;before_count=0;edpsi=arb(0);cap=(1+b)/2
  for t,count in sorted(atoms.items()):
   act_before=bisect_left(mins,t)-bisect_left(maxs,t)
   act_after=bisect_right(mins,t)-bisect_right(maxs,t)
   assert 0<=act_before<=N and 0<=act_after<=N
   numer+=count*(act_before+act_after)
   for left in (F(before_count,8),F(before_count+count,8)):
    delta=psi(N)-psi(left)-psi(N-left)
    if left==0 or left==N: assert delta.contains(0)
    else: assert delta>0
    edpsi+=aq(F(count,16*N))*delta
   before_count+=count
  assert before_count==8*N
  expect=F(numer,16*N)
  pair_bound=F(K*K,384)-F(1,32)
  assert expect>=pair_bound
  if u==(1,0,0):assert expect==F(K*K,2)
  ed=aq(expect)*v0
  assert edpsi>0
  rows.append({'K':K,'N':N,'u':list(u),'projection_groups':len(atoms),'expected_split_count_exact':str(expect),'pair_lower_bound_exact':str(pair_bound),'exact_axis_formula_checked':u==(1,0,0),'v0_Arb':v0.str(40),'ED_Arb':ed.str(40),'EDeltaPsi_Arb':edpsi.str(40),'ratio_Arb':(ed/edpsi).str(40),'scope':'finite complete projection support law, all ties and before/after atoms; no sampled directions'})
result={'status':'PASS_16_COMPLETE_FINITE_SOURCE_PLANE_LAWS','rows':rows,'precision_bits':256,'base':'n3 vertices +/-3/8, masses1/8, lambda=L=U=1; centers4*grid; v0 exact cube minus eight disjoint corner boxes','scope':'Finite K and 4 directions only; all-u unbounded-K obstruction relies on separate analytic proof.','interpreter':sys.executable,'python':platform.python_version(),'flint':flint.__version__,'runtime_seconds':time.perf_counter()-start}
args.output.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'status':result['status'],'seconds':result['runtime_seconds'],'axis_ratios':[r['ratio_Arb'] for r in rows if r['u']==[1,0,0]]}))
