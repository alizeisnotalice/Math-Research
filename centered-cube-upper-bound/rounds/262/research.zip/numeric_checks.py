#!/usr/bin/env python3
"""R262 exact Q recovery diagnostics; D_original=kc-kb, recovery uses -D_original."""
import argparse,hashlib,json
import mpmath as mp
from pathlib import Path
from fractions import Fraction as F

def fs(x):return str(x.numerator)+'/'+str(x.denominator)
def prod(v):
    z=F(1)
    for x in v:z*=x
    return z

def w(A,t):return prod(min(F(1),a/t)for a in A)
def score(A,t):return sum(a<t for a in A)
def events(B,C):return sorted({F(1,2),F(1)}|{a for a in B+C if F(1,2)<a<1})
def integral_piece(B,C,left,right):
    mid=(left+right)/2;kb=score(B,mid);kc=score(C,mid);den=kb+kc
    return F(0)if den==0 else F(kb-kc,den)*(w(B,left)*w(C,left)-w(B,right)*w(C,right))
def suffix_data(B,C):
    knots=events(B,C);U={knots[-1]:F(0)}
    for left,right in reversed(list(zip(knots,knots[1:]))):U[left]=U[right]+integral_piece(B,C,left,right)
    def at(t):
        if t in U:return U[t]
        for a,b in zip(knots,knots[1:]):
            if a<t<b:return U[b]+integral_piece(B,C,t,b)
        raise ValueError(t)
    return knots,U,at

def enc(x):return mp.nstr(x,50)
def m(x):return mp.mpf(x.numerator)/x.denominator if isinstance(x,F)else mp.mpf(x)
def carrier_menu():
    out=[]
    for phase,n in [('initial',2),('stress',8),('expanded',32)]:
        WB=F(4,5)**n
        for label,E in [('unpaid_small_delete',F(1,100)),('paid_large_delete',256/WB)]:
            out.append({'phase':phase,'n':n,'name':label,'sources':[{'class':'B','mass':F(1),'A':[F(1,2)]*n,'delete':None},{'class':'G','mass':F(8),'A':[F(1)]*n,'delete':None},{'class':'G','mass':F(4),'A':[F(7,8)]*n,'delete':None},{'class':'E','mass':E,'A':[F(1)]*n,'delete':F(5,8)}]})
        out.append({'phase':phase,'n':n,'name':'suffix_nonmonotone','sources':[{'class':'B','mass':F(1),'A':[F(1,2)+F(1,64*n)]*n,'delete':None},{'class':'G','mass':F(2),'A':[F(1,2)]*(n//2)+[F(7,8)]*(n//2),'delete':None},{'class':'E','mass':F(1),'A':[F(1)]*n,'delete':F(3,4)}]})
    return out

def setup(model):
    src=model['sources'];bad=[i for i,s in enumerate(src)if s['class']=='B'];good=[i for i,s in enumerate(src)if s['class']=='G'];future=[i for i,s in enumerate(src)if s['class']=='E'];graph=[]
    for b in bad:
        for c in good:
            B,C=src[b]['A'],src[c]['A'];knots,uv,U=suffix_data(B,C);assert all(x>=0 for x in uv.values())
            graph.append((b,c,w(B,F(1))/w(C,F(1))))
    knots=sorted({F(1,2),F(1)}|{a for s in src for a in s['A']if F(1,2)<a<1}|{s['delete']for s in src if s['delete']is not None})
    return bad,good,future,graph,knots

def state(model,t,before=False):
    src=model['sources'];W=[s['mass']*w(s['A'],t)if s['delete']is None or(t<=s['delete']if before else t<s['delete'])else F(0)for s in src];e=sum(W);assert e>0;k=[score(s['A'],t)for s in src];pi=[v/e for v in W];mean=sum(p*kk for p,kk in zip(pi,k));return W,e,k,pi,mean

def Qpairs(model,t,graph):
    src=model['sources'];return [src[b]['mass']*src[c]['mass']*(w(src[b]['A'],t)*w(src[c]['A'],t)-alpha*w(src[c]['A'],t)**2)for b,c,alpha in graph]

def exact_checks(model):
    src=model['sources'];bad,good,future,graph,knots=setup(model);midpoints=[];ledger_count=0
    masks=sorted(set(tuple(v)for v in [[0]*len(good),[j%2 for j in range(len(good))],[1]*len(good)]))
    for left,right in zip(knots,knots[1:]):
        t=(left+right)/2;W,e,k,pi,mean=state(model,t);qs=Qpairs(model,t,graph);assert all(v>=0 for v in qs)
        derivative=F(0);rhs_derivative=F(0);recovery=F(0);comp=F(0)
        for (b,c,alpha),q in zip(graph,qs):
            mass=src[b]['mass']*src[c]['mass'];BC=w(src[b]['A'],t)*w(src[c]['A'],t);C2=w(src[c]['A'],t)**2;Doriginal=k[c]-k[b]
            direct=mass*(-(k[b]+k[c])*BC+2*k[c]*alpha*C2);stated=mass*Doriginal*BC-2*k[c]*q
            assert direct==stated;derivative+=direct;rhs_derivative+=stated;recovery+=mass*(-Doriginal)*BC/e**2;comp+=2*(mean-k[c])*q/e**2
        quotient_derivative=(derivative+2*mean*sum(qs))/e**2
        assert recovery==comp-quotient_derivative
        eB=sum(W[b]for b in bad);kB=sum(W[b]*k[b]for b in bad);FBprime=(eB*sum(ww*kk for ww,kk in zip(W,k))-e*kB)/e**2
        ledgers=[]
        for mask in masks:
            P=N=NE=U=S=loss=F(0)
            for j,c in enumerate(good):
                theta=F(1,j+2)
                for b in bad:
                    D=k[c]-k[b];v=pi[c]*pi[b];psi=mask[j];P+=psi*theta*max(0,D)*v;N+=psi*max(0,-D)*v;S+=(1-psi)*D*v;loss+=psi*(1-theta)*max(0,D)*v
            for c in future:
                for b in bad:
                    D=k[c]-k[b];v=pi[c]*pi[b];NE+=max(0,-D)*v;U+=max(0,D)*v
            assert P-N-NE==FBprime-U-S-loss
            ledger_count+=1;ledgers.append({'Psi':list(mask),'P':fs(P),'N':fs(N),'NE':fs(NE),'U':fs(U),'S_signed':fs(S),'capture_loss':fs(loss),'FBprime':fs(FBprime)})
        midpoints.append({'left':fs(left),'right':fs(right),'Qsum':fs(sum(qs)),'Qprime':fs(derivative),'mean':fs(mean),'recovery_density':fs(recovery),'compensated_density':fs(comp),'quotient_derivative':fs(quotient_derivative),'NC8_ledgers':ledgers})
    wl,el,kl,pil,ml=state(model,F(1,2));wh,eh,kh,pih,mh=state(model,F(1),True);initial=sum(Qpairs(model,F(1,2),graph))/el**2;FBl=sum(pil[b]for b in bad);FBh=sum(pih[b]for b in bad)
    assert initial+FBh-FBl<=1
    jumps=[]
    for t in sorted({s['delete']for s in src if s['delete']is not None}):
        wb,eb,_,_,_=state(model,t,True);wa,ea,_,_,_=state(model,t);QB=sum(Qpairs(model,t,graph));d_inv=1/ea**2-1/eb**2;df=sum(wb[b]for b in bad)*(eb-ea)/(eb*ea);jq=d_inv*QB
        assert jq>=0 and df>=0
        jumps.append({'time':fs(t),'e_pre':fs(eb),'e_post':fs(ea),'Qsum':fs(QB),'Q_recovery_atom':fs(jq),'FB_jump':fs(df),'net_Q_recovery_minus_FBjump':fs(jq-df)})
    return {'phase':model['phase'],'n':model['n'],'name':model['name'],'midpoints':midpoints,'NC8_row_checks':ledger_count,'initial_Q_over_e_square':fs(initial),'FB_start':fs(FBl),'FB_end':fs(FBh),'initial_plus_boundary':fs(initial+FBh-FBl),'initial_boundary_margin_to_one':fs(1-initial-FBh+FBl),'jumps':jumps}

def quadrature(model,certificate,dps):
    with mp.workdps(dps):
        src=model['sources'];bad,good,future,graph,knots=setup(model);R=mp.mpf(0);Comp=mp.mpf(0);NE=mp.mpf(0);positive=mp.mpf(0);negative=mp.mpf(0);parts=[]
        for left,right in zip(knots,knots[1:]):
            mid=(left+right)/2;alive=[s['delete']is None or mid<s['delete']for s in src];k=[score(s['A'],mid)for s in src];coeffF=[s['mass']*prod(a for a in s['A']if a<mid)if alive[i]else F(0)for i,s in enumerate(src)];coeff=[m(v)for v in coeffF]
            # Q is evaluated with -expm1(log(alpha*wc/wb)); zero ratios stay exact.
            rcoef=[alpha*(coeffF[c]/src[c]['mass'])/(coeffF[b]/src[b]['mass'])for b,c,alpha in graph]
            leftQ=Qpairs(model,left,graph);rightQ=Qpairs(model,right,graph)
            def integrand(t,kind):
                ww=[cc*t**(-kk)for cc,kk in zip(coeff,k)];e=sum(ww);mean=sum(v*kk for v,kk in zip(ww,k))/e;rr=mp.mpf(0);cc=mp.mpf(0)
                if kind=='NE':return sum(ww[b]*ww[c]*max(0,k[b]-k[c])for b in bad for c in future)/e**2/t
                for j,((b,c,alpha),rc)in enumerate(zip(graph,rcoef)):
                    if t==m(left):q=m(leftQ[j])
                    elif t==m(right):q=m(rightQ[j])
                    elif rc==1 and k[b]==k[c]:q=mp.mpf(0)
                    else:q=ww[b]*ww[c]*(-mp.expm1(mp.log(m(rc))+(k[b]-k[c])*mp.log(t)))
                    rr+=ww[b]*ww[c]*(k[b]-k[c])/e**2;cc+=2*(mean-k[c])*q/e**2
                return(rr if kind=='R'else cc)/t
            rr=mp.quad(lambda t:integrand(t,'R'),[m(left),m(right)]);cc=mp.quad(lambda t:integrand(t,'C'),[m(left),m(right)]);nn=mp.quad(lambda t:integrand(t,'NE'),[m(left),m(right)])
            R+=rr;Comp+=cc;NE+=nn
            if cc>=0:positive+=cc
            else:negative-=cc
            parts.append({'left':fs(left),'right':fs(right),'direct_recovery':enc(rr),'compensated_continuous':enc(cc),'negative_E_continuous':enc(nn)})
        initial=m(F(certificate['initial_Q_over_e_square']));jump=sum(m(F(j['Q_recovery_atom']))for j in certificate['jumps']);FBchange=m(F(certificate['FB_end'])-F(certificate['FB_start']));FBjumps=sum(m(F(j['FB_jump']))for j in certificate['jumps'])
        rhs=initial+jump+Comp;res=R-rhs;NC8rhs=FBchange-FBjumps+R;NC8new=FBchange+initial+sum(m(F(j['net_Q_recovery_minus_FBjump']))for j in certificate['jumps'])+Comp
        assert abs(res)<mp.mpf('1e-30')and abs(-NE-NC8rhs)<mp.mpf('1e-30')and abs(-NE-NC8new)<mp.mpf('1e-30')
        return {'phase':model['phase'],'n':model['n'],'name':model['name'],'parts':parts,'direct_R':enc(R),'initial_Q_term':enc(initial),'deletion_Q_atoms':enc(jump),'compensated_continuous_total':enc(Comp),'positive_signed_segment_sum':enc(positive),'negative_signed_segment_sum':enc(negative),'RHS':enc(rhs),'R_minus_RHS':enc(res),'full_NC8_Psi_zero_LHS_minus_NE':enc(-NE),'full_NC8_Psi_zero_RHS':enc(NC8rhs),'full_NC8_after_Q_substitution':enc(NC8new),'full_NC8_residual':enc(-NE-NC8new),'scope':'Ordinary segmented quadrature, not outward intervals. Signed segment sums retain both signs; source labels do not certify good/high/FIRST/history.'}

def numericfields(v,prefix=''):
    out={}
    if isinstance(v,dict):
        for k,x in v.items():
            if isinstance(x,str):
                try:out[prefix+k]=mp.mpf(x)
                except ValueError:pass
            elif isinstance(x,(dict,list)):out.update(numericfields(x,prefix+k+'/'))
    elif isinstance(v,list):
        for i,x in enumerate(v):out.update(numericfields(x,prefix+str(i)+'/'))
    return out

def main():
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=Path(__file__).with_suffix('.json'));a=p.parse_args();models=carrier_menu();cert=[exact_checks(v)for v in models];lo=[quadrature(v,c,40)for v,c in zip(models,cert)];hi=[quadrature(v,c,70)for v,c in zip(models,cert)]
    with mp.workdps(100):
        x=numericfields(lo);y=numericfields(hi);assert x.keys()==y.keys();diff=[abs(x[k]-y[k])/max(1,abs(y[k]))for k in x];maxdiff=enc(max(diff));assert max(diff)<mp.mpf('1e-30');maxres=enc(max(abs(mp.mpf(r['R_minus_RHS']))for r in hi))
    geometry=[{'phase':v['phase'],'n':v['n'],'name':v['name'],'sources':[{'class':s['class'],'mass':fs(s['mass']),'thresholds':list(map(fs,s['A'])),'delete':None if s['delete']is None else fs(s['delete'])}for s in v['sources']]}for v in models]
    result={'schema':'R262-Q-recovery-v1','script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'counts':{'carrier_laws':len(models),'exact_midpoint_checks':sum(len(c['midpoints'])for c in cert),'exact_NC8_row_checks':sum(c['NC8_row_checks']for c in cert),'exact_deletion_records':sum(len(c['jumps'])for c in cert),'initial_boundary_checks':len(cert),'laws_with_both_compensated_segment_signs':sum(mp.mpf(r['positive_signed_segment_sum'])>0 and mp.mpf(r['negative_signed_segment_sum'])>0 for r in hi),'precision_fields_compared':len(diff)},'D_convention':'D_original=kc-kb; Qprime=D_original*wb*wc-2kc*Q. Direct recovery integrand uses -D_original=kb-kc.','geometry':geometry,'exact_certificates':cert,'mp40':lo,'mp70':hi,'precision_max_relative_difference':maxdiff,'mp70_max_R_identity_residual':maxres,'scope':'Finite rational clamp laws and fixed suffix graphs, toy endpoint h=1 only; no original h=g identification, FULL, root or good/high/FIRST/history qualification. Fraction algebra exact, mp quadrature ordinary.'}
    a.output.write_text(json.dumps(result,ensure_ascii=False,sort_keys=True,indent=2)+'\n');print(json.dumps({'counts':result['counts'],'maxdiff':maxdiff,'max_R_residual_70':maxres}))
if __name__=='__main__':main()
