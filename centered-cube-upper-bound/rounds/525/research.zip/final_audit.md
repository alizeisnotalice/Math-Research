# R525 最终独审

审核 /tmp/r525_main.tex、r525_check.py/json；不改原contract或作者文件。结论：**本轮完整时序剥离命题、连续来源/可数stage推广及其有限证书通过，未发现阻断性错误。** 全部未付core完整保留，没有取得一般弱界闭合。

## 1. 原实际余流到(2)：通过

原R413高stage边缘门后，逐方向a_i^e≤s_i^e/θ并与同一原b_i(z)匹配，给实际需求阶段投影F_i≤θ^−1 b_i(z)M_i；原条件历史subkernel总质量≤1，故后续原门的正限制继续成立。方向之和已含于s_i≤S，不需另乘2。R433/R509余流在同一旧记录上继续正限制可以沿用；R495重新自然化链没有被混入。

正文明确原M_i、Γ_i、s_i、质量分母及history均不重算；高stage门原X费用继承而不退款。仅有静态S包络或总量SX不能替代(2)，该适用限制写明。

## 2. sourcewise版本、核行与闭core：通过

真实μ×μ密度K_i含m_B²分母。积分一个来源后恰得

\[
D_i(y)=\int s_i(B)R_B^{-n}1_{Q_B}(y)dB\le SA_n.
\]

因此核行有限。原s_i递减且阶段可数，可从显式非负密度选共同可测sourcewise版本，使M_j(y,·)≤M_i(y,·)在j≥i时成立；所需共同零集可统一去除。不能只由抽象总测度比较而省略这一步，正文已有明确K_i与共同版本安排。

每stage同步可测删除批次B_i,k跨stage互斥。有限轮在剩余源上核行>h，递减集合积分的从上连续性给极限≥h。极限可能恰等于h；正文只宣称闭core，正确。stage数与轮数均可数，所有批次费用非负，Tonelli/单调极限不会新增stage或深度因子。

## 3. 完整时序计价：通过

stage j的记录仅在至少一端于stage≤j移除时才计入paid。取最早移除批次，另一端仍在该批次移除前C_i,k。旧端方向用M_j≤M_i及同一新源z的Σ_jb_j(z)≤1，得hμ(B_i,k)/θ；新端方向用对称性及同一来源y的Σ_jb_j(y)≤1，得同一费用。块内双端采用可测tie，或用两方向非负覆盖上放，均不需另造不交性。

互斥批次总来源质量≤μ(A)，所以(4)的2hμ(A)/θ正确。所有当时两端仍在C_j的记录保为core，未来删源不能追溯支付旧记录。取A全空间覆盖全部实际阶段需求；h=cθ√n log^A(n+2)只把paid系数化为2c，并不缩小core。正文没有声称剥离部分必非空。

当前受限度式(6)保s_i p_i及原R_B/m_B；它没有被认作soft严格过去核。未付core仍含全部原标签及闭core门。有限增质量链长度、重写f1_C、R495累计停止费均未被当成core来源付款。原入口、ε吸收与所有其他未付槽也明确保留。

## 4. 时序脚本与冻结JSON：通过限定证据

脚本使用同一原递减对称核、同一非对称F_i及逐来源b_i预算。同步批次删除后才定义该stage core；owner只从删除stage≤当前stage的端点中选择，按stage/round/index决定，另显式检查另一端在pre_set。每条原F_i精确归入paid或core，没有按未来删除回写。

本审未重跑旧静态部分，实际用指定本机Python -I、Fraction对冻结JSON定向核验：每来源outgoing/incoming各≤hμ/θ；paid+core=R及逐来源收费和=paid；总价2hW/θ；移除不重复；core逐stage嵌套；所有被删密度≤h。压力与扩大实例中“先发生、端点后来才删除”的core质量严格为正，且保留为core；初探无剥离事件，未伪造正覆盖。

输出：

`PASS targeted chronological JSON certificate checks; sourcewise two-direction costs, unique deletion, conserved full core, and no future refunds`

JSON报告35218项代数守卫；本审不把它们视为独立几何模型。主代理另作隔离全脚本重放，本审没有代其宣称已完成该重放。有限核不认证立方体/history实现；一般测度结论由正文证明承担。未运行MATLAB。

**可归档范围：** 完整时序剥离组织与有限精确证书。

**仍未闭合：** 同一真实core的联合几何预算、受控递推终端及原完整入口吸收。未发现需修正文稿的实质问题；本审冻结后停止。
