# R525 独立原history合同：任意gate上放丢掉什么

独立读取R433 main §1、4、R495 main；按必要性补读已恢复的R413 main/geometry、R432 main、R495 geometry、R508 main及R509 history。未读本轮几何作者新稿。原目标仍为同一完整实际R≤εX+C_ε√n polylog(n)W。没有得到整体闭合。

## 1. 应保留的原可测标签及其同时适用范围

原R413→R432→R433余流是同一旧记录的连续正限制，应保：原父A及原t/质量/尺度、阶段i、方向e=u/v、旧源y/新源z、early和首次删除分数、soft、来源远域、闭CDF与严格过去、初始/路径/终端标签。每个事件须在该原记录空间评价；“按正积分分组”不赋予新来源或新父原历史资格。

R413留下的实际门包括：T_v(y)>κ_yJ(y)、T_A(z)>κ_zJ(z)；soft共同严格过去C_A(y,z)<h；原旧侧平方根门；stage高边缘s_i^e(A)>θB_e；双当前高占用D_i(y),D_i(z)>s；初始双外侧、own-high、exclusive、双child-collar及终端外侧own-low。θ表示R413 stage阈值，避免与R495父接受率阈值混用。

R432进一步留下每个**实际proper路径目标**的近整父尺度中心排斥，以及原终端质量—距离联合低指标。R433再留下T_G<C_G/(1+√n)、T_loc<C_loc/(1+√n)。这些门可以在同一旧余流上同时成立；原文没有证明交集为空或占固定小比例。proper目标排斥不能扩展为“所有当前核父”都排斥；R433低指标只有在U或局部质量与m_A可比时才给来源距离上界，不能无条件读出O(log n)距离。

R509径向秩拆分可对上述同一旧流作正限制并增加D*，必须保两个orientation和各自历史gate。它只提供内者的完整条件后验，外者仍是原面条件分布；施加旧gate后不得重新归一成独立后验。

## 2. R509任意gate上放确实丢掉的容量

R433(1)的sourcewise支配来自逐阶段a_i^e(A,y)≤B_e、B_u=β、B_v=C_col以及Σ_i b_i(z)≤1，S=β+C_col。将其合成Sσπ_A²后，只留下非负总包络，丢掉了哪一stage/旧源消耗哪一份新源容量、Γ_i嵌套及当前核随i递减的信息。

在stage高边缘门后，R413真正给的是同标签正支配

\[
d\widehat\Theta\le\theta^{-1}\sum_i b_i(z)M_i(dy,dz),\qquad
M_i=\int\sigma(dA)s_i(A)\pi_A(dy)\pi_A(dz).
\tag{1}
\]

其他history标签需要时由原条件subkernel一并携带；(1)不是实际双源独立等式。原M_i对称、非负、逐i递减，其边缘恰为μ(dy)D_i(y)。新增high门后的截断密度本身未必递减，不能用它替代原M_i。任意gate≤1的R509包络没有这些性质；故G=1弱界强度审查不否认实际历史可能另有节省。

## 3. 一个可实际累计付款的高—高需求修复

对(1)支配的任意旧余流正限制，包括保全部D*及其他原门的流，记总量R。令L为其两个原端点的总入射列，∫L dμ=2R，A={L>K}。完整原端点分配给出R≤KW+D(A)，而μ(A)≤2R/K；这些均未使用待证弱界。

固定该可测A，定义**原当前核的受限列**

\[
D_i^A(y)=\frac{M_i(y,A)}{\mu(dy)}
=\int_A K_i(y,z)\mu(dz),\quad
M_i(dy,dz)=K_i(y,z)\mu(dy)\mu(dz).
\]

它随i递减。需求D(A)中至少一端D_i^A≤h_A的分支累计付款不超过

\[
\frac{2h_A}{\theta}\mu(A)
\le\frac{4h_A}{\theta K}R. \tag{2}
\]

新端z低时直接用Σ_i b_i(z)≤1。旧端y低时取原D_i^A(y)首次≤h_A的阶段j_A(y)，用M_i(y,dz)≤M_j(y)(y,dz)并对同一z求和b_i(z)，得到一次h_Aμ(A)/θ，不能逐stage付费。该首次阶段只用于正积分分组，不是改变原存活测试。两支按顺序取互斥限制即可。

因此h_A=δθK/4时得到准确完整递推接口

\[
(1-\delta)R\le KW+D_{\rm both\ restricted\ high},\quad0<\delta<1, \tag{3}
\]

剩余仍带全部原history，且两端在该stage均有D_i^A>h_A。(2)确实恢复了任意gate上放丢失的原stage容量，是可付子流；但(3)没有支付剩余，不是一般根阶定理。K取根阶多对数并不会自动使剩余为空。

## 4. soft严格过去与当前核必须同分母比较

原真实密度为

\[
K_i(y,z)=\int\frac{q_As_i(A)c_A(y)c_A(z)}{m_A^2}\,dA,
\]

不是只含一个m_A的核。对某条原记录父B，以原soft的质量阈值分解

\[
K_i=K_i^{<m_B/K_0}+K_i^{\ge m_B/K_0},\quad K_0=e^{\sqrt n}.
\]

过去部分准确为

\[
K_i^{<m_B/K_0}(y,z)
=\int_{m_A<m_B/K_0}\frac{s_i(A)}{R_A^n}
\frac{c_A(y)c_A(z)}{m_A}\,dA
\le\frac{S}{a^n}C_B(y,z)<\frac{Sh}{a^n}. \tag{4}
\]

费用S/a^n不可省；λS C_B只对应另一个少含m_A的核，其边缘不是D_i。完整当前D_i>s或D_i^A>h_A都不能下放到过去部分。即使由(4)再积分受限来源，只能得

\[
D_i^{A,\rm past,B}(y)\le\frac{Sh}{a^n}
\mu\bigl(A\cap(y+[-b,b]^n)\bigr), \tag{5}
\]

该局部质量未有足够小的统一上界。R433低T_loc/T_G允许大的局部/共同来源质量，是下界方向的信息，不能把(5)右侧免费压小。

未付recent/heavy部分是原同核中m_A≥m_B/K_0的正积分，不是新付款分支。原密度band仅给

\[
m_A\ge m_B/K_0\Rightarrow R_A/R_B\ge(K_0r)^{-1/n};
\quad m_A<m_B/K_0\Rightarrow R_A/R_B<(r/K_0)^{1/n}.
\]

recent可再按[m_B/K_0,K_0m_B)与≥K_0m_B作记账区分，但前者不严格增质量，后者未证明承担固定份额。不能靠该分解启动有界增长递归：新抽的当前共同父没有原history，原路径proper排斥不自动适用它。要把(3)用于整体递归，仍须构造保原到达/首次删除权的共同父转移，证明统一收缩或有价终端；现有合同没有该桥。

## 5. 可沿用估计的对象与费用

- R413两相对秩门删费η_gate X，其中η_gate=2C_col rκ_y+Srκ_z；stage低边缘另付θSX；旧当前低占用一次sW/θ。双侧列界C_y^rel、C_z^rel含log(1/κ)，是原双exclusive见证边缘支配，不是任意当前条件概率上帽。原初始、inner及return重算费用保R413原式，不能末尾加门后追溯退款。
- R432只对原proper路径累计命中/终端对指标付款，新增ΔV W=O(√n log²n)W；R433静态两矩正支各付S(1+√n)W。沿旧流继续限制时只继承已付支后的余流，不能把同一已删支再收一次。
- R508只将原双源限制到量化内盒，任意有帽gate的绝对损失≤(1−γ^−2)SX≤2ηSX；额外核帽H_*与入口C_in必须相乘。新的辅助壳不是旧pair，不能赋予原history。
- R509小盒/高密度分支合计S(1+A_n/M)W；余流D*不抹除以上原stage/路径条件，除非显式上放到更强的任意gate问题。
- R495是**另一条重建自然链**：先删实际父接受密度t_acc<τ_p，付τ_pX；条件旧pair帽为S/τ_p。以同一ν_τ重建JH_src后，原失败门按低rank先停，非rank累计≤ε_gR_τ，初始rank≤κTW；真实累计rank仍留下Δ_mix,rank。其q_j、mark、成功记录权及后来源rank权不可省，不能假定Θ_R≤ν_τ。参考重建保原输入记录，不保证每次来源刷新或最大父更换后仍满足旧R433历史门，不能把其累计收据直接接到旧K链。

这里t_acc是实际接受父边缘相对σ的密度，不应默认为R509任意gate上包络中的baseline t。可先在原实际流按t_acc删低，再用未归一正支配做R509；若改以归一的接受条件pair作新基底，必须保S/τ_p条件帽，不能继续宣称密度≤1。

## 6. 结论与实际核验

可以共同保留的核心是旧R433流的所有原门、R413原单次stage容量与递减M_i，以及其后D*正限制；R495的重新自然化参考另作同流有价构造，不能无条件并入这些旧路径性质。

本审找到的实际修复为(2)：受限当前列的双低子流可用原history一次付款并吸收δR。对完整递归检查后，剩余的双受限高需求仍无价；soft仅制约(4)的严格过去，recent/heavy与重新父化的到达密度尚未控制。当前没有不调用待证弱界的整体高—高容量结论。

实际使用本机指定Python -I、Fraction核一组递减对称核、同一新端Σb≤1、旧端首次低列的累计预算和4h_A/(θK)=δ系数，输出：

`PASS exact same-stage restricted-column first-low budget and full-demand absorption coefficient; finite kernel algebra only`

只验证共同核代数，不冒作实际几何/原history模拟。未扫描反例、未运行MATLAB。

## 7. 主代理提出的时序peeling：完整账核验

本节h_c是新增的当前列阈值，区别于(4)的原soft阈值h。对固定初始来源集A，仅用原M_i和原stage顺序分析分类；不重算Γ_i、s_i、D_i或history。有限原子情形，在stage i的当前集合C中反复移除满足D_i^C(y)≤h_c的原子，统一预定顺序。每个来源只移除一次，记移除stage i_y及其移除前集合C_y。

一条stage j的原记录，只有在某端i_y≤j时才可按该移除付款；选两个端点中最早移除的那个（同轮tie规则预定）。另一端在它被移除时仍属于C_y。对旧端y的outgoing未来总量，由M_j≤M_i_y和同一z的Σ_j b_j(z)≤1，至多M_i_y(y,C_y)/θ≤h_cμ(dy)/θ；对新端y的incoming，用对称性和Σ_j b_j(y)≤1给同一上界。所有移除来源互斥，故

\[
R(A,A)\le\frac{2h_c}{\theta}\mu(A)+R_{\rm core}^A. \tag{6}
\]

core包括该记录发生时两端尚未移除的全部原记录。尤其两端虽在未来stage移除，但此前已发生的记录仍属core；不能用未来低列收据支付。每stage须先完成该stage的peeling再定义其core，则core的两来源都落在当时剩余h_c-core；单个阶段的原记录仍只归入一个分支，没有重复付款。

连续来源可同步作可测分层删除：C_0为上一stage剩余集，B_l={y∈C_l:D_i^{C_l}(y)<h_c}，C_{l+1}=C_l\B_l，取C_∞=∩_lC_l。Tonelli及从上连续性给D_i^{C_l}↓D_i^{C∞}，因而残留处D_i^{C∞}≥h_c，μ几乎处处成立。每轮B_l同时移除，块内双端记录按预定旧端优先规则，另一端仍在移除前C_l。各stage/轮的可测移除块可数且互斥，(6)照样成立。若用≤h_c删除，极限也只无条件保证闭h_c-core（≥h_c），可能有等于h_c的极限残留；不可无证宣称严格>h_c。需要严格门时可以另留阈值余量并计价。

取A为全部来源便得真正完整时序预算R≤2h_cW/θ+R_core；取A={L>K}接前述原端点分配，则

\[
R\le KW+\frac{4h_c}{\theta K}R+R_{\rm core}^A. \tag{7}
\]

该机制保留了原history上放后丢失的阶段单次容量，覆盖所有可按发生时间付款的peel记录。它仍未付款的core不是可略的终端误差；(4)只控制soft严格过去，不能证明当前h_c-core消失或提供其收缩。要得到整体递归，仍需同一core原记录上的几何估计，而不能重建父/来源并继承旧门。

本机Fraction另核一组两stage三来源的明确递减核：base=[[0,2/5,2/5],[2/5,3,1/10],[2/5,1/10,3]]，第二stage为base/4，各b_i=1/2，μ原子权1，h_c=1。stage0先移除来源0，stage1再移除1、2；验证全部记录分账、outgoing/incoming各≤h_c、且stage0中后来才移除的1、2之间记录保为非零core。输出：

`PASS exact chronological peeling ledger, future-time compatibility, and preserved pre-removal core; finite kernel algebra only`

最终判断：(6)–(7)的完整时序账合法，连续版本需上述可测同步分层；整体core容量仍未证明。本合同稿交付后停止。
