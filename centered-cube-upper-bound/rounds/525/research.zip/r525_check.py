#!/usr/bin/env python3
"""R525 bounded exact finite-matrix checks; not a cube/history realization."""
from fractions import Fraction as Q
from pathlib import Path
import random,json,sys,platform,time
ROOT=Path(__file__).resolve().parent
checks=0

def ck(cond):
 global checks
 assert cond
 checks+=1

def exact(x):return str(x)

def case(name,n,m,seed,theta,delta,stress):
 rng=random.Random(seed)
 mu=[Q(rng.randint(1,9),rng.randint(1,9))*(Q(2)**((a%9)-4) if stress else 1) for a in range(n)]
 ck(all(x>0 for x in mu))
 kernels=[];previous=None
 for i in range(m):
  mat=[[Q(0) for b in range(n)] for a in range(n)]
  for a in range(n):
   for b in range(a,n):
    if previous is None:v=Q(rng.randint(1,12),rng.randint(1,8))
    else:
     # Heterogeneous plateaux and abrupt positive downward jumps, all symmetric.
     ratio=(Q(1,64) if stress and (i+a+2*b)%4==0 else Q(rng.randint(1,8),8))
     v=previous[a][b]*ratio
    mat[a][b]=mat[b][a]=v
  ck(all(mat[a][b]>0 and mat[a][b]==mat[b][a] for a in range(n) for b in range(n)))
  if previous is not None:ck(all(mat[a][b]<=previous[a][b] for a in range(n) for b in range(n)))
  kernels.append(mat);previous=mat
 bvals=[[Q(0) for b in range(n)] for i in range(m)]
 for b in range(n):
  raw=[rng.randint(0,9) for i in range(m)]
  if sum(raw)==0:raw[0]=1
  budget=Q(rng.randint(1,4),4)
  for i in range(m):bvals[i][b]=budget*Q(raw[i],sum(raw))
 ck(all(bvals[i][b]>=0 for i in range(m) for b in range(n)))
 ck(all(sum(bvals[i][b] for i in range(m))<=1 for b in range(n)))
 F=[]
 for i in range(m):
  mat=[]
  for a in range(n):
   row=[]
   for b in range(n):
    upper=bvals[i][b]*mu[a]*mu[b]*kernels[i][a][b]/theta
    value=upper*Q(rng.randint(0,8),8)
    ck(0<=value<=upper);row.append(value)
   mat.append(row)
  F.append(mat)
 R=sum((F[i][a][b] for i in range(m) for a in range(n) for b in range(n)),Q(0));ck(R>0)
 incident=[sum((F[i][a][b]+F[i][b][a] for i in range(m) for b in range(n)),Q(0)) for a in range(n)]
 L=[incident[a]/mu[a] for a in range(n)]
 ck(sum(incident)==2*R)
 # Set threshold from actual demands, then recompute the strict actual incidence gate.
 # This is a deterministic single gate per model, not a parameter scan.
 threshold=sorted(L)[n//2]*Q(7,8);ck(threshold>0)
 A=tuple(a for a in range(n) if L[a]>threshold)
 ck(A and all((a in A)==(L[a]>threshold) for a in range(n)))
 h=delta*theta*threshold/4
 muA=sum((mu[a] for a in A),Q(0))
 ck(muA<=2*R/threshold)
 def check_subset(S):
  mass=sum((mu[a] for a in S),Q(0))
  D=[[sum((mu[b]*kernels[i][a][b] for b in S),Q(0)) for a in range(n)] for i in range(m)]
  ck(all(D[i+1][a]<=D[i][a] for i in range(m-1) for a in range(n)))
  lo1=lo2=overlap=union=Q(0)
  for i in range(m):
   for a in S:
    for b in S:
     lowa=D[i][a]<=h;lowb=D[i][b]<=h;value=F[i][a][b]
     if lowa:lo1+=value
     if lowb:lo2+=value
     if lowa and lowb:overlap+=value
     if lowa or lowb:union+=value
  ck(lo1<=h*mass/theta);ck(lo2<=h*mass/theta)
  ck(union==lo1+lo2-overlap);ck(union<=2*h*mass/theta)
  # First-end proof uses the first low stage's dominating kernel, not disjointness.
  for a in S:
   low=[i for i in range(m) if D[i][a]<=h]
   if low:
    first=low[0];ck(low==list(range(first,m)))
    paid=sum((F[i][a][b] for i in low for b in S),Q(0))
    bound=mu[a]*D[first][a]/theta
    ck(paid<=bound<=mu[a]*h/theta)
  for b in S:
   low=[i for i in range(m) if D[i][b]<=h]
   paid=sum((F[i][a][b] for i in low for a in S),Q(0))
   priced=mu[b]*sum((bvals[i][b]*D[i][b] for i in low),Q(0))/theta
   ck(paid<=priced<=mu[b]*h/theta)
  return {'source_indices':list(S),'mu_A_exact':exact(mass),'low_first_endpoint_exact':exact(lo1),'low_second_endpoint_exact':exact(lo2),'overlap_exact':exact(overlap),'union_exact':exact(union),'two_endpoint_bound_exact':exact(2*h*mass/theta),'union_float':float(union),'overlap_positive':overlap>0}
 subsets=[A,tuple(range(n)),tuple(range(0,n,2)),(n//2,)]
 # Exhaust all source subsets only in the four-point probe (16 exact sets).
 if name=='probe':subsets=[tuple(a for a in range(n) if mask>>a&1) for mask in range(2**n)]
 reports=[check_subset(S) for S in subsets]
 actual=check_subset(A)
 branch=Q(actual['union_exact']);bound=2*h*muA/theta
 ck(branch<=bound<=delta*R)
 ck(any(F[i][a][b]!=F[i][b][a] for i in range(m) for a in range(n) for b in range(n)))
 # Complete chronological peeling on the SAME original kernels, b and F.
 # Each stage peels simultaneous batches; records before deletion are never repriced.
 C=set(range(n));deletion={};events=[];cores=[]
 for i in range(m):
  roundno=0
  while True:
   density={a:sum((mu[b]*kernels[i][a][b] for b in C),Q(0)) for a in C}
   batch=sorted(a for a in C if density[a]<=h)
   if not batch:break
   before=tuple(sorted(C))
   for a in batch:
    ck(a not in deletion)
    deletion[a]={'stage':i,'round':roundno,'pre_set':before,'density':density[a]}
   events.append({'stage':i,'round':roundno,'pre_source_indices':list(before),'deleted_source_indices':batch,'deleted_density_exact':{str(a):exact(density[a]) for a in batch}})
   C.difference_update(batch);roundno+=1
  cores.append(set(C))
  ck(all(sum((mu[b]*kernels[i][a][b] for b in C),Q(0))>h for a in C))
  if i:ck(cores[i]<=cores[i-1])
 outgoing=[Q(0)]*n;incoming=[Q(0)]*n
 paid=core=Q(0);stage_rows=[];future_deleted_core=Q(0);overlap_paid=Q(0)
 for i in range(m):
  pi=ci=Q(0)
  for a in range(n):
   for b in range(n):
    value=F[i][a][b]
    if a in cores[i] and b in cores[i]:
     ci+=value
     if any(v in deletion and deletion[v]['stage']>i for v in (a,b)):future_deleted_core+=value
     continue
    pi+=value
    available=[v for v in (a,b) if v in deletion and deletion[v]['stage']<=i]
    ck(bool(available))
    owner=min(available,key=lambda v:(deletion[v]['stage'],deletion[v]['round'],v))
    other=b if owner==a else a
    ck(other in deletion[owner]['pre_set'])
    ck(i>=deletion[owner]['stage'])
    if owner==a:outgoing[owner]+=value
    else:incoming[owner]+=value
    if a not in cores[i] and b not in cores[i]:overlap_paid+=value
  paid+=pi;core+=ci
  stage_rows.append({'stage':i,'core_source_indices':sorted(cores[i]),'paid_exact':exact(pi),'core_exact':exact(ci)})
  ck(pi+ci==sum((F[i][a][b] for a in range(n) for b in range(n)),Q(0)))
 for a in range(n):
  ck(outgoing[a]<=h*mu[a]/theta)
  ck(incoming[a]<=h*mu[a]/theta)
  if a not in deletion:ck(outgoing[a]==incoming[a]==0)
 W=sum(mu)
 ck(set(deletion)==set(range(n))-cores[-1])
 ck(sum(len(e['deleted_source_indices']) for e in events)==len(deletion))
 ck(paid==sum(outgoing)+sum(incoming));ck(paid+core==R)
 ck(paid<=2*h*W/theta)
 chronological={'h_exact':exact(h),'W_exact':exact(W),'events':events,'stage_paid_core':stage_rows,
 'source_first_deletion':{str(a):{'stage':v['stage'],'round':v['round']} for a,v in deletion.items()},
 'charged_outgoing_exact':[exact(v) for v in outgoing],'charged_incoming_exact':[exact(v) for v in incoming],
 'paid_exact':exact(paid),'core_exact':exact(core),'one_time_total_bound_exact':exact(2*h*W/theta),
 'paid_over_one_time_bound_exact':exact(paid/(2*h*W/theta)),
 'past_core_later_deleted_endpoint_mass_exact':exact(future_deleted_core),
 'both_endpoints_outside_stage_core_mass_exact':exact(overlap_paid),
 'max_same_stage_cascade_rounds':max([sum(e['stage']==i for e in events) for i in range(m)],default=0),
 'distinct_deletion_stages':sorted(set(e['stage'] for e in events)),
 'record_assignment':'Original F_i paid exactly when an endpoint is outside that stage stable C_i; assign once to earlier first deletion (stage,round,index); earlier core records remain core even if a source is deleted later'}
 return {'stage':name,'n_sources':n,'n_kernel_stages':m,'seed':seed,'theta_exact':exact(theta),'delta_exact':exact(delta),'mu_exact':[exact(v) for v in mu],'kernel_generator':'symmetric positive rational K0, pointwise multipliers in {1/8,...,1}; stress adds 1/64 jumps; exact seed replay','budget_generator':'sourcewise random nonnegative stage weights, total budget in {1/4,1/2,3/4,1}','demand_generator':'F_i(a,b)=theta^-1 b_i(b) mu_a mu_b K_i(a,b) times independent rational in {0,1/8,...,1}; can be asymmetric','R_exact':exact(R),'L_actual_exact':[exact(v) for v in L],'K_gate_exact':exact(threshold),'h_exact':exact(h),'actual_A':actual,'gate_measure_bound_exact':exact(2*R/threshold),'delta_R_exact':exact(delta*R),'branch_over_delta_R_exact':exact(branch/(delta*R)),'subset_checks':reports,'chronological_peeling':chronological,'actual_A_union_bound_chain_verified':True,'non_disjoint_low_branches_observed':any(r['overlap_positive'] for r in reports)}

def main():
 start=time.perf_counter()
 models=[case('probe',4,3,52501,Q(1,3),Q(1,2),False),case('heterogeneous_jump_pressure',10,8,52502,Q(2,5),Q(1,3),True),case('expanded_stages_and_points',24,17,52503,Q(3,7),Q(2,5),True)]
 ck(models[0]['chronological_peeling']['events']==[])
 ck(models[1]['chronological_peeling']['max_same_stage_cascade_rounds']>=2)
 ck(len(models[1]['chronological_peeling']['distinct_deletion_stages'])>=2)
 ck(models[2]['chronological_peeling']['max_same_stage_cascade_rounds']>=3)
 ck(all(Q(v['chronological_peeling']['past_core_later_deleted_endpoint_mass_exact'])>0 for v in models[1:]))
 ck(all(Q(v['chronological_peeling']['both_endpoints_outside_stage_core_mass_exact'])>0 for v in models[1:]))
 out={'scope':'Finite abstract symmetric pointwise decreasing positive kernels and asymmetric dominated demands; exact algebra only, not real cubes or a full history construction','chronological_explanation':'Same original three seeded finite instances, unchanged h and F. Start C at all sources; at each stage synchronously peel D_i^C<=h until stable. Pay each original F_i record exactly once if an endpoint is absent from that stage core; assign to the earlier first deletion, never retroactively to a prior-stage core record. Exact outgoing and incoming first-deletion charges are each <=h mu/theta, hence total paid<=2h W/theta. Positive-budget core records have both endpoint densities >h. This is finite algebra verification, not a general proof or cube/history realization.',
 'environment':{'executable':sys.executable,'python':platform.python_version(),'arithmetic':'fractions.Fraction'},'models':models,'checks':checks,'seconds':time.perf_counter()-start}
 (ROOT/'r525_check.json').write_text(json.dumps(out,indent=2)+'\n')
 for m in models:print('STAGE',m['stage'],'n',m['n_sources'],'stages',m['n_kernel_stages'],'A',m['actual_A']['source_indices'],'union/deltaR',float(Q(m['branch_over_delta_R_exact'])),'overlap',m['non_disjoint_low_branches_observed'],'cascade',m['chronological_peeling']['max_same_stage_cascade_rounds'],'deletion_stages',m['chronological_peeling']['distinct_deletion_stages'])
 print('PASS',checks,'exact kernel-budget/gate/low-branch checks; finite matrix algebra, not cube/history realization')
if __name__=='__main__':main()
