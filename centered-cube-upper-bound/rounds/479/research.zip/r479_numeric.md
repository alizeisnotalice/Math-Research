# R479主证书：未归一Poisson-rank的列支配与跨阈值通量

本轮增量追加Poisson-rank：89项新检查，与此前fixed-k的154项合计243项；fixed-k数值没有重跑。最终统一脚本默认可一次复现两部分。Poisson部分以SymPy核一般积分，4组有理参数的完整原子推前/跨阈值通量用240-bit Arb严格认证。这里只构造完整未筛选的辅助law，不认证几何success率或原history。

## Poisson-rank主公式

固定来源带的原列总量U，原父也带uniform mark，扩充rank v 的未归一law为dv于[0,U]。在[0,v)取强度1/T的PPP，非空时最大点w的subprobability密度为

K(v,w)=T^{-1} exp(−(v−w)/T)1_{0<w<v}。

这里**不除以非空概率**。SymPy实际核：

- 目标列RN为 ∫_w^U K(v,w)dv=1−exp(−(U−w)/T)≤1；
- 空样本总量为 ∫_0^U exp(−v/T)dv=T(1−exp(−U/T))≤T；
- 目标总质量为U减上述empty；
- 跨任意阈值a∈[0,U]的有向通量为

Φ(a)=∫_{v=a}^U∫_{w=0}^a K(v,w)dw dv
=T(1−exp(−a/T))(1−exp(−(U−a)/T))≤T。

因此任意非降logmass层函数（含质量原子）总对数跨度L的实际期望下降量为∫Φ(a)dlogmass(a)≤TL。有限原子例中，这准确等于各质量跳跃Δlogmass乘对应Φ之和；不是用每个原子的中心点近似其rank区间。

## 四组有限原子证书

沿用下文fixed-k三组原子内部条件身份权重；质量atom展开为连续mark rank区间。对每个atom区间[l,h]，目标质量精确表达为

(h−l)−T[exp(−(U−h)/T)−exp(−(U−l)/T)]。

其内部parent仍按原atom条件权重分配。代码逐parent核目标submass≤原mass，并核总和为U−empty。此为正source-fiber投影证书，不是cube/history资格。

| U/T | T | 原子模型 | empty/T近似 | 实际logmass费用/(TL)近似 |
|---:|---:|---|---:|---:|
| 1/4 | 1 | 全质量同atom | .221199217 | 0（L=0） |
| 1 | 2/3 | mixed_mass_tie | .632120559 | .133123473 |
| 4 | 3/2 | rare_end_atom | .981684361 | .372969454 |
| 16 | 1/4 | mixed_mass_tie | .999999887 | .989280140 |

数值为展示摘要；完整误差球在JSON poisson_rank.cases。最后一例接近TL，表明这一费用在有限层函数上不是纯形式上界。每例还核一个atom内部的a=U/2通量，说明rank通量存在不必对应真实质量跳跃；全同质量例的logmass费用仍恰0。

## 为什么不能按非空归一

若每个v处改成K/(1−exp(−v/T))，其目标列RN变为

exp(w/T)·log[(1−exp(−U/T))/(1−exp(−w/T))]。

SymPy核其v原函数；当w下降到0时它无界。同一个U/T=1例取w/T=1/100，Arb严格给RN约4.19321405>1，直接破坏列帽1。不能把未归一PPP的列支配用于按非空条件化的law。

## 费用与success范围

把rank推回真实parent身份只会保持目标列的正测度支配。故完整未归一辅助parent-source边缘Q≤原parent-source边缘，原列与Q之差的质量≤T；对来源带积分得到总empty损失≤T𝓜≤TNW。它比fixed-k的signed TV比较更直接，且不需要按k层恢复3T常数。

任意正success限制的目标parent-source投影仍≤完整Q，因此这一投影列帽可作外上界继续使用；但限制可能造成额外丢失，**不能自动继承empty≤TNW的保量结论**。投影支配也不产生原旧pair/history的joint密度帽。几何good事件、保留最大父、旧双来源排斥等参数尚未在此计算。不能给筛后旧记录重新赋独立来源law。

## 主证书复现索引

实际增量命令：

`/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python r479_numeric.py --append-poisson`

该模式读取现存fixed-k JSON，只追加新的Poisson证书；此前154项未重跑。完整归档的默认命令`.../python r479_numeric.py`自含重现两部分。Python3.12.14、SymPy1.14.0、python-flint 0.9.0、Arb240-bit；解释器及实际增量用时记录在JSON poisson_compute_index。原子参数为Fraction，指数/log诊断为严格Arb区间，无MC、尾截断或求解器。243检查不是243个独立模型。

最终归档仍只有r479_numeric.py、r479_numeric.json、r479_numeric.md。下面保留fixed-k比较全文；其154计数为原比较部分，不是最终总数。计算已停止。

---

# 比较附件：fixed-k uniform-mark最大父的未筛选边缘TV证书

本轮没有运行平移路径。实际运行指定Python，以SymPy/Fraction/240-bit Arb核154项：k=2,3的初步、质量原子和离散rank区间压力、k=16,128的扩大。共12个有限原子推前表、8个离散rank区间表。检查数含归一化、支持和区间断言，不是154个独立样本。范围仅为完整、未按success筛选的辅助parent-source边缘；不认证原cube/history或success后的边缘。

## 标量law和精确TV

固定来源带(x,j)后原父后验为P。每个原父也独立附Uniform[0,1] mark；若父质量为m，定义扩充rank

v=P{mass<m}+mark·P{mass=m}。

因此v均匀于[0,1]；质量原子被连续mark展开。对于同质量下不同parent身份，给定该atom内rank的身份分布仍按原atom内部权重。下面的“below v”含mark截断，不可偷换为仅按mass≤截断。

给定v，抽k个独立Uniform[0,v] rank，最大rank为w。完整未筛选原v积分后

g_k(w)=∫_w^1 k w^{k−1}v^{-k}dv=k/(k−1)(1−w^{k−1})，k≥2；
G_k(w)=(kw−w^k)/(k−1)。

脚本用SymPy核原函数导数、定积分端点、CDF导数、归一化及G−w=(w−w^k)/(k−1)。g单调下降，g=1的唯一交点a=k^{-1/(k−1)}，因此

TV_probability(g dw,dw)=sup_E|Q(E)−P(E)|=G(a)−a=a/k=k^{-k/(k−1)}。

其L1 variation norm为2a/k；两种常被称为“总变差”的定义不能混淆。脚本独立核正、负两段的积分均为a/k，Arb严格包围a和概率TV。

| k | 概率TV近似 | (k+1)·TV近似 |
|---:|---:|---:|
| 2 | .25 | .75 |
| 3 | .192450089730 | .769800358920 |
| 16 | .051952368509 | .883190264652 |
| 128 | .007519653444 | .970035294304 |

右列仅展示所测k的更准确费用，不据四例冒称一般新常数。

k=1时g_1(w)=−log w，CDF=w(1−log w)，概率TV=e^{-1}。此支可直接支付完整原列质量u<2T，不使用任何k−1分母。

## 完整原子和有限区间压力

三组有限原父质量标签与权重固定为：

- masses(1,1,2,5)，weights(1/8,3/8,1/4,1/4)；
- masses(4,4,4)，weights(1/6,1/3,1/2)；
- masses(1,3,3,8)，weights(1/100,24/100,25/100,1/2)。

每个质量atom占rank区间[l,h]，selected atom质量精确为G_k(h)−G_k(l)，其内部parent身份按原条件权重分配。因此所有k的parent输出权重均为Fraction，质量为1。计算其概率TV并核不大于完整augmented-rank TV。

第二组所有父同质量。此时完整rank law仍改变，但推回未标记parent身份后权重完全不变，概率TV恰0。这清楚区分“augmented rank law改变”和“parent推前边缘改变”，也核了质量原子内部的均匀mark处理。

另固定两个rank分区[0,1/2,1]、[0,1/7,1/3,3/4,1]，以CDF差精确计算分区质量及离散TV。k=2第一分区恰跨密度交点，离散TV精确1/4；其余分区表均严格收缩。没有把midpoint当整个rank区间代表。

## parent-source预算及不能继承的范围

在每个来源带中k=floor(u/T)固定。k≥2时

u·TV ≤u/(k−1)<(k+1)T/(k−1)≤3T。

最后一个不等式的差为2(k−2)T/(k−1)，SymPy核等式，四个实际k均Fraction核。parent身份推前只收缩概率TV。对同一来源带标记边缘u(x)μ(dx)积分，得到

概率TV质量≤3T·𝓜≤3TNW；
L1 variation norm≤6T·𝓜≤6TNW。

k=1的完整质量支付≤2T𝓜，若与k≥2按不交来源带拆分，统一3T𝓜仍足够（L1可用6T𝓜）。这里没有重收同一来源带。

这可以控制**未筛选辅助最大父与原父的parent-source边缘差**。它并没有原旧pair/history条件下的边缘结论：geometrygood、old-source排斥、最大父保留等success事件均依赖原记录和样本；成功限制后不能自动继续使用g_k，不能把success旧标记移到新父。质量原子经mark处理后同样有此范围限制。

## 复现与误差

命令：

`/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python r479_numeric.py`

实际Python3.12.14，SymPy1.14.0，python-flint 0.9.0，Arb240-bit。symbolic identities与有理区间推前无浮点误差；a、log和TV诊断为JSON中严格Arb球。无MC、求解器、枚举扫描或原native几何资格主张。JSON compute_index记录解释器和实际用时，脚本自含且输出自身目录，stdout固定摘要。

归档仅r479_numeric.py、r479_numeric.json、r479_numeric.md。计算已停止。
