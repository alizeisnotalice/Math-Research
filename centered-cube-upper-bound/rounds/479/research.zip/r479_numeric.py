from fractions import Fraction as F
from pathlib import Path
import sys,platform,json,time
import sympy as sp
from flint import arb,ctx
ROOT=Path(__file__).resolve().parent;ctx.prec=240
start=time.perf_counter();append_poisson='--append-poisson' in sys.argv
checks=0

def ck(v):
 global checks
 assert v
 checks+=1

def ar(v):
 v=F(v);return arb(v.numerator)/v.denominator

def st(v):return str(v)
def G(k,x):return (k*x-x**k)/(k-1)
def qG(k,x):return (k*x-x**k)/(k-1)
if not append_poisson:
 # Symbolic identities for the full unfiltered augmented-rank law.
 k=sp.symbols('k',integer=True,positive=True);w,v,a=sp.symbols('w v a',positive=True)
 g=k*(1-w**(k-1))/(k-1);cdf=(k*w-w**k)/(k-1)
 primitive=-k*w**(k-1)*v**(1-k)/(k-1)
 ck(sp.cancel(sp.diff(primitive,v)-k*w**(k-1)/v**k)==0)
 ck(sp.simplify(primitive.subs(v,1)-primitive.subs(v,w)-g)==0)
 ck(sp.simplify(sp.diff(cdf,w)-g)==0)
 ck(cdf.subs(w,0)==0);ck(cdf.subs(w,1)==1)
 ck(sp.cancel(cdf-w-(w-w**k)/(k-1))==0)
 # At the unique crossing a^(k-1)=1/k, G(a)-a=a/k.
 ck(sp.cancel((a-a/k)/(k-1)-a/k)==0)
 # Exact arithmetic behind u/(k-1)<=(k+1)T/(k-1)<=3T.
 ck(sp.cancel(3-(k+1)/(k-1)-2*(k-2)/(k-1))==0)
 ck(sp.diff(-sp.log(w),w)==-1/w)
 
 atom_models=[('mixed_mass_tie',[1,1,2,5],[F(1,8),F(3,8),F(1,4),F(1,4)]),('all_mass_tied',[4,4,4],[F(1,6),F(1,3),F(1,2)]),('rare_end_atom',[1,3,3,8],[F(1,100),F(24,100),F(25,100),F(1,2)])]
 grids=[list(map(F,[0,F(1,2),1])),list(map(F,[0,F(1,7),F(1,3),F(3,4),1]))]
 rows=[]
 for kk in (2,3,16,128):
  aa=(-arb(kk).log()/(kk-1)).exp();tv=aa/kk
  ck(aa>0);ck(aa<1);ck(tv<ar(F(1,kk-1)))
  ck((ar(kk)*(1-aa**(kk-1))/(kk-1)-1).contains(0))
  # Independently integrate each signed side via CDF and compare TV.
  left=G(kk,aa)-aa;right=(1-aa)-(1-G(kk,aa))
  ck((left-tv).contains(0));ck((right-tv).contains(0))
  ck((left+right-2*tv).contains(0))
  atoms=[]
  for name,masses,p in atom_models:
   ck(sum(p)==1);ck(all(z>0 for z in p))
   atom_mass={mm:sum(p[i] for i,m in enumerate(masses) if m==mm) for mm in sorted(set(masses))}
   lo=F(0);output=[F(0)]*len(p);intervals=[]
   for mm,total in atom_mass.items():
    hi=lo+total;selected= qG(kk,hi)-qG(kk,lo)
    ck(selected>=0)
    for i,m in enumerate(masses):
     if m==mm:output[i]=selected*p[i]/total
    intervals.append(dict(mass=mm,rank_interval=[str(lo),str(hi)],atom_weight=str(total),output_atom_weight=str(selected)))
    lo=hi
   ck(lo==1);ck(sum(output)==1)
   ptv=sum(abs(output[i]-p[i]) for i in range(len(p)))/2
   if ptv==0:ck(name=='all_mass_tied')
   else:ck(ar(ptv)<tv or (ar(ptv)-tv).contains(0))
   if name=='all_mass_tied':ck(output==p)
   atoms.append(dict(name=name,parent_mass_labels=masses,original_parent_weights=list(map(str,p)),selected_parent_weights=list(map(str,output)),mass_atom_intervals=intervals,parent_TV=str(ptv)))
  gridrows=[]
  for grid in grids:
   old=[grid[i+1]-grid[i] for i in range(len(grid)-1)];new=[qG(kk,grid[i+1])-qG(kk,grid[i]) for i in range(len(grid)-1)]
   ck(sum(old)==sum(new)==1)
   discrete_tv=sum(abs(new[i]-old[i]) for i in range(len(old)))/2
   if kk==2 and grid==grids[0]:ck(discrete_tv==F(1,4));ck((ar(discrete_tv)-tv).contains(0))
   else:ck(ar(discrete_tv)<tv)
   gridrows.append(dict(grid=list(map(str,grid)),old=list(map(str,old)),new=list(map(str,new)),TV=str(discrete_tv)))
  ck(F(kk+1,kk-1)<=3)
  rows.append(dict(k=kk,crossing_a=st(aa),augmented_rank_TV=st(tv),augmented_rank_L1_variation=st(2*tv),rank_TV_bound_1_over_k_minus_1=str(F(1,kk-1)),u_over_T_interval=[kk,kk+1],TV_mass_over_T_upper=st((kk+1)*tv),simple_TV_mass_over_T_bound=str(F(kk+1,kk-1)),parent_models=atoms,rank_partitions=gridrows))
 # k1 has g=-log(w), crossing e^-1 and TV=e^-1. Its entire mass u<2T
 # may instead be paid, avoiding any singular k-1 expression.
 w1=arb(-1).exp();ck(w1>0);ck(w1<1)
 ck(((-w1*w1.log()+w1)-w1-w1).contains(0));ck(2*w1<2)
 result=dict(scope='Full UNFILTERED auxiliary parent-source marginal only, with original parent also uniformly marked inside each mass atom. No native cube or original-success/history certification.',compute_index=dict(executable=sys.executable,python=platform.python_version(),sympy=sp.__version__,arb_precision_bits=ctx.prec,command='"'+sys.executable+'" r479_numeric.py',seconds=time.perf_counter()-start),checks=checks,formula=dict(g='k/(k-1)*(1-w^(k-1)) for k>=2',CDF='(k*w-w^k)/(k-1)',probability_TV='k^(-k/(k-1))',L1_variation='2*k^(-k/(k-1))',source_band_probability_TV_mass_bound='u/(k-1)<=3T',integrated_probability_TV_bound='3 T M <=3 T N W',integrated_L1_variation_bound='6 T M <=6 T N W',k1_pay_full_mass='u<2T',k1_exact_probability_TV=st(w1)),cases=rows,exactness='Rational atom/rank interval inputs and output weights exact; symbolic density/CDF identities; algebraic-power/log diagnostics rigorously enclosed by 240-bit Arb. No Monte Carlo.')
else:
 result=json.loads((ROOT/'r479_numeric.json').read_text())
 checks=result.get('fixed_k_checks',154)

# Principal new certificate: UNNORMALIZED Poisson-rank maximum law.
poisson_start=time.perf_counter();fixed_checks=checks
U,T,a,w,v=sp.symbols('U T a w v',positive=True)
K=sp.exp(-(v-w)/T)/T
rn=1-sp.exp(-(U-w)/T)
ck(sp.simplify(sp.integrate(K,(v,w,U))-rn)==0)
empty=T*(1-sp.exp(-U/T))
ck(sp.simplify(sp.integrate(sp.exp(-v/T),(v,0,U))-empty)==0)
ck(sp.simplify(sp.integrate(rn,(w,0,U))-(U-empty))==0)
flux=T*(1-sp.exp(-a/T))*(1-sp.exp(-(U-a)/T))
ck(sp.simplify(sp.integrate(sp.integrate(K,(w,0,a)),(v,a,U))-flux)==0)
# The normalized-nonempty variant has a different, unbounded target RN.
normprim=sp.exp(w/T)*sp.log(1-sp.exp(-v/T))
ck(sp.simplify(sp.diff(normprim,v)-K/(1-sp.exp(-v/T)))==0)
poisson=[]
settings=[(F(1,4),F(1),'all_mass_tied'),(F(1),F(2,3),'mixed_mass_tie'),(F(4),F(3,2),'rare_end_atom'),(F(16),F(1,4),'mixed_mass_tie')]
modelmap={name:(m,p) for name,m,p in atom_models} if not append_poisson else { 'mixed_mass_tie':([1,1,2,5],[F(1,8),F(3,8),F(1,4),F(1,4)]),'all_mass_tied':([4,4,4],[F(1,6),F(1,3),F(1,2)]),'rare_end_atom':([1,3,3,8],[F(1,100),F(24,100),F(25,100),F(1,2)]) }
for rho,tt,name in settings:
 uu=rho*tt;masses,p=modelmap[name];ee=ar(tt)*(1-(-ar(rho)).exp());kept=ar(uu)-ee
 ck(ee>0);ck(ee<ar(tt));ck(kept>0);ck(kept<ar(uu))
 am={mm:sum(p[i] for i,m in enumerate(masses) if m==mm) for mm in sorted(set(masses))}
 lo=F(0);out=[arb(0)]*len(p);atomrows=[];loss=arb(0);previousmass=None;fluxrows=[]
 for mm,weight in am.items():
  hi=lo+uu*weight
  selected=ar(hi-lo)-ar(tt)*((-ar((uu-hi)/tt)).exp()-(-ar((uu-lo)/tt)).exp())
  ck(selected>0);ck(selected<ar(hi-lo))
  for i,m in enumerate(masses):
   if m==mm:out[i]=selected*ar(p[i]/weight);ck(out[i]<ar(uu*p[i]))
  atomrows.append(dict(mass=mm,rank_interval=[str(lo),str(hi)],old_atom_mass=str(hi-lo),selected_atom_mass=str(selected)))
  if previousmass is not None:
   aa=lo;fl=ar(tt)*(1-(-ar(aa/tt)).exp())*(1-(-ar((uu-aa)/tt)).exp())
   ck(fl>0);ck(fl<ar(tt))
   jump=ar(F(mm,previousmass)).log();loss+=jump*fl
   fluxrows.append(dict(threshold=str(aa),logmass_jump='log('+str(F(mm,previousmass))+')',exact_flux='T*(1-exp(-a/T))*(1-exp(-(U-a)/T))',flux=str(fl),flux_over_T=str(fl/ar(tt))))
  previousmass=mm;lo=hi
 ck(lo==uu);ck((sum(out,arb(0))-kept).contains(0))
 L=ar(F(max(masses),min(masses))).log()
 if L==0:ck(loss==0)
 else:ck(loss<ar(tt)*L)
 # Also an interior threshold in the all-tied atom: crossing is not the
 # same as a logmass jump, but the rank-flux identity still applies.
 aa=uu/2;midflux=ar(tt)*(1-(-ar(aa/tt)).exp())**2
 ck(midflux>0);ck(midflux<ar(tt))
 entry=dict(U=str(uu),T=str(tt),U_over_T=str(rho),source_parent_model=name,original_parent_mass=[str(uu*z) for z in p],selected_parent_mass=list(map(str,out)),target_RN_max=str(1-(-ar(rho)).exp()),empty_total=str(ee),empty_over_T=str(ee/ar(tt)),selected_total=str(kept),atom_intervals=atomrows,logmass_threshold_fluxes=fluxrows,midpoint_flux=str(midflux),actual_logmass_loss=str(loss),TL_bound=str(ar(tt)*L),actual_logmass_loss_over_TL=None if L==0 else str(loss/(ar(tt)*L)))
 if rho==1:
  ww=tt/100
  normalized_RN=(ar(ww/tt)).exp()*((1-(-ar(rho)).exp()).log()-(1-(-ar(ww/tt)).exp()).log())
  ck(normalized_RN>1)
  entry['normalized_nonempty_counterpoint']=dict(w_over_T='1/100',target_RN=str(normalized_RN),violates_column_RN_cap_1=True)
 poisson.append(entry)
result['fixed_k_checks']=fixed_checks
result['checks']=checks
result['poisson_checks']=checks-fixed_checks
result['poisson_rank']=dict(scope='PRINCIPAL: full PPP subprobability law, no normalization by nonempty/success; no history claim',kernel='exp(-(v-w)/T)/T * 1_(0<w<v<U)',target_RN='1-exp(-(U-w)/T)<=1',empty_total='T*(1-exp(-U/T))<=T',cross_threshold_flux='T*(1-exp(-a/T))*(1-exp(-(U-a)/T))<=T',logmass_bound='actual expected nonnegative logmass loss <= T*L',cases=poisson)
result['poisson_compute_index']=dict(executable=sys.executable,python=platform.python_version(),sympy=sp.__version__,arb_precision_bits=ctx.prec,incremental_command='"'+sys.executable+'" r479_numeric.py --append-poisson',seconds=time.perf_counter()-poisson_start)
(ROOT/'r479_numeric.json').write_text(json.dumps(result,indent=2)+'\n')
print('PASS',checks,'checks; fixed-k154 retained plus Poisson-rank finite certificates; UNNORMALIZED full auxiliary law only')
