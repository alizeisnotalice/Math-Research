# R479：增广质量秩 Poisson 最大父的精确列容量

本稿以同一完整原接受测度 \(\Pi\) 为入口，构造新的辅助扩展。它不是 R478 固定样本数成功流 \(\Xi_*\) 的路径子集。原来源、父、阶段、时钟和所有历史标签均不改变；只增加独立标记及辅助 Poisson 样本。证明列容量、空样本价格和半径误差；成功族几何由本轮另一稿另证。

## 1. 原子安全的真实来源纤维

沿 `/tmp/r478_main.md`，\(\mu=f dx\)、\(\sigma=q_A dA\)、\(m_A=q_AR_A^n\)、\(q\le q_A\le\lambda\)、\(r=\lambda/q\)。原投影为 \(\ell(A,y,z)\sigma\pi_A^2\)，\(0\le\ell\le S\)，父边缘 \(t(A)\sigma(dA)\)。保留完整质量带 \(J_j\)，定义原
\[
\rho_{x,j}(dA)=1_{m_A\in J_j}\frac{t(A)c_A(x)}{m_A}\sigma(dA),
\quad U=u_j(x)=\rho_{x,j}(E),\quad
F_{x,j}(m)=\rho_{x,j}\{m_A\le m\}.
\]
在给定原父后独立附 \(x\sim\pi_A\)，再给原父及每个辅助父附 \(s\sim\mathrm{Unif}(0,1)\)。按 \((m_A,s)\) 字典序排列，增广秩为
\[
v(A,s)=F(m_A-)+s\,[F(m_A)-F(m_A-)].
\tag{1}
\]
增广测度 \(\widehat\rho=\rho\otimes ds\) 的秩推前是 \(dv\) 于 \((0,U)\)。这包括完整质量原子；非原子部分取 \(v=F(m_A)\)。零秩、端点及相等增广秩都是相关测度零集。所有对象随 \((j,x)\) 联合可测，实际中心及独立标记为标准Borel空间，可用有限 Poisson 级数构造以下核。

固定 \(T>0\)。给定原父秩 \(v\)，在严格低于原父的增广中心集合上按强度 \(\widehat\rho/T\) 取 Poisson 点集。其数量有限；若非空，取最大增广秩的实际父 \(B_*\)。这是次概率核，**不条件于非空重新归一**。所有样本仍捕获同一 \(x\)，且 \(m_{B_*}\le m_A\)。辅助父没有原历史资格。

## 2. 精确入列及一次来源损失

秩空间上最大非空点的核为
\[
K_T(v,dw)=\frac1T e^{-(v-w)/T}1_{0<w<v}\,dw,
\qquad P(\mathrm{empty}\mid v)=e^{-v/T}.
\tag{2}
\]
固定纤维把原父 \(dv\) 先积分，得
\[
\int_w^U K_T(v,dw)\,dv
=\bigl[1-e^{-(U-w)/T}\bigr]dw\le dw,
\tag{3}
\]
\[
\int_0^U P(\mathrm{empty}\mid v)dv
=T(1-e^{-U/T})\le T.
\tag{4}
\]
(3)不仅是质量推前结果：Poisson 最大点相对实际增广中心测度的密度就是该秩函数，因此投影回实际中心仍有
\[
\boxed{\Omega_{B_*,x,j}
\le1_{m_{B_*}\in J_j}\frac{t(B_*)c_{B_*}(x)}{m_{B_*}}
\sigma(dB_*)\mu(dx).}
\tag{5}
\]
这里 \(\Omega\) 是原 \(\Pi\) 附 \(x\)、标记、Poisson 点集后的非空次概率扩展。原 \(y,z\) 和其余标签先保持原值，只有计算该投影时才积分它们。\(x\) 积分后，辅助父边缘至多原 \(t(B_*)\sigma(dB_*)\)；源 \(x\) 也没有刷新。

若 \(\mathcal M=\int\#\{j:u_j(x)>0\}d\mu\le NW\)，则准确空样本总量
\[
E_{\rm empty}=\int\sum_jT(1-e^{-u_j(x)/T})d\mu(x)
\le T\mathcal M\le TNW.
\tag{6}
\]
这不需要高占用或半秩门。若仍删 \(t(A)<\tau\)，一次原费用为 \(\le\tau X\)，保持旧 \(t,u,\rho\) 不重建，且正限制后的空样本损失仍由(6)控制。

任意进一步成功/原历史筛选 \(0\le G\le1\) 都保(5)，但其总量须单独核算。令 \(\Omega_G=G\Omega\)，\(F_G=|\Omega-\Omega_G|\)。同一目标空间的测度差满足
\[
\nu_{\rm in}- (\Omega_G)_{B,x,j}\ge0,
\qquad |\nu_{\rm in}- (\Omega_G)_{B,x,j}|
=E_{\rm empty}+F_G,
\tag{7}
\]
其中 \(\nu_{\rm in}=\sum_j\rho_{x,j}(dB)\mu(dx)\)，总量为 \(R=|\Pi|\)。因此 full 列帽可以传给成功流；full 的小丢量不能不加 \(F_G\) 就传给成功流。若删父亦放进 \(G\)，其非空失败量包含于 \(F_G\)，不重复计入(7)。不能由(5)声称新父携带原记录条件分布。

## 3. 同一个最大父的全局质量与半径误差

令 \(m(v)\) 为纤维质量分位数。对任意对数质量层 \(s\)，置 \(a=F(e^s)\)。层跨越积分准确为
\[
\int_a^U\int_0^a \frac1T e^{-(v-w)/T}dw\,dv
=T(1-e^{-a/T})(1-e^{-(U-a)/T})\le T.
\tag{8}
\]
\(\{m(w)\le e^s<m(v)\}\) 与该秩矩形相同，除零集；质量原子的端点不影响 \(ds\) 积分。若该带对数宽度为 \(L_j\)，Tonelli给
\[
\int_0^Udv\int K_T(v,dw)\log\frac{m(v)}{m(w)}\le TL_j.
\]
故对完整 \(\Omega\) 或其任意正限制，
\[
\int\log\frac{m_A}{m_{B_*}}d\Omega_G\le T D_m W,
\qquad D_m=\sum_jL_j=\log r+n\log(b/a).
\tag{9}
\]
使用真实匹配而不是把质量当体积，得到
\[
\boxed{\int\left|\log\frac{R_A}{R_{B_*}}\right|d\Omega_G
\le\frac{TD_m}{n}W+\frac{\log r}{n}R.}
\tag{10}
\]
原生占用 \(R\le S[1+n\log(b/a)]W\) 可用于最后一项。固定 \(T,r,S\) 时(10)为维数一致的来源价格，\(L=\sqrt n\) 时(6)为根阶来源价格。原母账仍完整，\(T\) 的具体几何成功参数由主稿选定。

## 4. 对本轮完整目标的界限

此构造消除了固定 \(k\) 最大父在原子场上的额外入列放大，并把空样本及半径误差精确付到一次来源账。它没有证明非空流全部满足原两来源排斥、亲和行和、族大小条件；这些条件必须在同一 Poisson 扩展上核成功率及 \(F_G\)。

此外，对于有序中心对仍只有精确关系
\[
\pi_A(Q_B^c)=1-m_B/m_A+(m_B/m_A)\pi_B(Q_A^c).
\]
(9)仅将第一项正上界到 \(TD_mW\)，一般仍为 \(nW\)；(5)对第二项只给至多 \(R\)。近等边长不使真实来源对称差小，故不能从(5)、(10)直接推完整根阶预算。这是下一步必须保留的中心平移/来源通量费用。

原固定 \(k\) 候选的原子安全列帽 \(1+k/(k-1)\le3\) 仍正确，但这里无需使用。增广均匀秩的固定 \(k\) 版本列密度为 \(k[1-w^{k-1}]/(k-1)\)（单位秩），其小总变差同样不能自动穿过成功筛选；本稿采用更直接的(3)。

## 5. 实际本机检查

指定本机Python/SymPy实际运行下列完整脚本，输出：

```text
PASS 57 exact symbolic assertions; 3 general identities and 9 finite atom-rank parameter cases.
```

三条一般符号恒等式对应(3)、(4)、(8)；九个有限参数配置将质量原子分成真实均匀秩区间后核入出质量。这是秩核代数验证，不声称构造了完整实际立方体/history。此前固定 \(k\) 版本另实际通过226项Fraction检查，但不作为最终 Poisson 构造的验证依据。

```python
import sympy as s
v,w,U,T,a=s.symbols('v w U T a', positive=True)
checks=0
col=s.integrate(s.exp(-(v-w)/T)/T,(v,w,U))
assert s.simplify(col-(1-s.exp(-(U-w)/T)))==0
checks+=1
empty=s.integrate(s.exp(-v/T),(v,0,U))
assert s.simplify(empty-T*(1-s.exp(-U/T)))==0
checks+=1
cross=s.integrate(s.integrate(s.exp(-(v-w)/T)/T,(w,0,a)),(v,a,U))
assert s.simplify(cross-T*(1-s.exp(-a/T))*(1-s.exp(-(U-a)/T)))==0
checks+=1
for cuts in [(0,1,3),(0,1,2,5),(0,2,3,4,7)]:
    total=s.Integer(cuts[-1])
    for scale in [s.Rational(1,2),s.Integer(1),s.Integer(3)]:
        incoming=[]
        outgoing=[]
        for lo,hi in zip(cuts[:-1],cuts[1:]):
            target=s.integrate(1-s.exp(-(total-w)/scale),(w,lo,hi))
            source=s.integrate(1-s.exp(-v/scale),(v,lo,hi))
            incoming.append(target)
            outgoing.append(source)
            assert s.simplify(target-((hi-lo)-scale*(s.exp(-(total-hi)/scale)-s.exp(-(total-lo)/scale))))==0
            checks+=1
        assert s.simplify(sum(incoming)-sum(outgoing))==0
        checks+=1
        for boundary in cuts[1:-1]:
            z=s.Integer(boundary)
            got=cross.subs({U:total,T:scale,a:z})
            expected=scale*(1-s.exp(-z/scale))*(1-s.exp(-(total-z)/scale))
            assert s.simplify(got-expected)==0
            checks+=1
print(f'PASS {checks} exact symbolic assertions; 3 general identities and 9 finite atom-rank parameter cases.')
```
