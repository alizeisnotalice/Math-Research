# R479：Poisson 质量秩抽样的保最大父恢复与真实几何费用

## 1. 同一原流及未经重算的质量秩

本稿按本轮最终方案重新选择辅助抽样。它保持同一原接受测度 \(\Pi\)，不是宣称新成功流是 R478 有限样本 \(\Xi_*\) 的子测度。设 \(\mu=f\,dx\)、\(W=\mu(\mathbb R^n)\)，实际 Lebesgue 父中心满足
\[
 m_A=\mu(Q_A)=q_AR_A^n,\quad q\le q_A\le\lambda,\quad
 a\le R_A\le b\le2a,\quad r=\lambda/q,\quad \sigma(dA)=q_A\,dA.
\]
原 \((A,y,z)\) 投影为 \(\ell(A,y,z)\sigma(dA)\pi_A(dy)\pi_A(dz)\)，其中 \(0\le\ell\le S\)、\(\pi_A=c_A\mu/m_A\)。其余 stage、clock、early、soft、路径及删除历史仍是原记录的标签。记
\[
 t(A)=\int\ell\,d\pi_A^2,\qquad R=|\Pi|=\int t\,d\sigma,\qquad X=\sigma(E).
\]
\(S=0\) 时全零。以后 \(S>0\)。给定原父，独立附 \(x\sim\pi_A\)；新父没有原历史。

沿用完整不交质量带 \(J_j\)，对数宽 \(L_j\le L\)，\(D_m=\sum_jL_j=\log r+n\log(b/a)\)。单点质量范围单列一带。固定 \((j,x)\)，置
\[
 dF_{j,x}(B)=1_{J_j}(m_B)t(B)c_B(x)\frac{\sigma(dB)}{m_B},\qquad
 U=u_j(x)=F_{j,x}(E),\qquad
 \mathcal M=\int\#\{j:u_j(x)>0\}\,d\mu(x)\le NW,
\tag{1}
\]
其中 \(N\le1+D_m/L\)。原父附源后、积分旧记录的边缘恰为 \(d\mu(x)dF_{j,x}(A)\)。后续截断 **不重算** \(t,F,U\)。

给每个父附独立 \(z_A\in[0,1]\)，以
\[
 v(A,z_A)=F_{j,x}\{m_B<m_A\}+z_A F_{j,x}\{m_B=m_A\}
\]
作增广秩。\(dF_{j,x}(A)dz_A\) 的秩推前是 \(1_{[0,U]}dv\)；这同时包括质量原子和连续部分。秩增大时质量不减。给定原 \((A,x,z_A)\)，在秩 \([0,v)\) 的增广实际父空间取强度 \(dF_{j,x}(B)dz_B/T\) 的 Poisson 点过程。每个样本捕获 \(x\)，质量不大于 \(m_A\)，且在同一带；抽样独立于给定 \(A\) 的旧记录。此处没有另加半秩门。

使用已证真实中心 CDF/Schur 工具：对任何捕获 \(x\) 的实际父 \(C\)，
\[
 \int\gamma_{CB}\,dF_{j,x}(B)\le4rS,\qquad
 \gamma_{CB}=\frac{\mu(Q_C\cap Q_B)}{\sqrt{m_Cm_B}}.
\tag{2}
\]
它来自完整匹配和真实中心体积，不是任意 incidence 矩阵的假设。

## 2. 无半秩损失的成功概率

统一参数为
\[
 0<\delta\le\tfrac14,\quad0<\tau\le S,\quad H=S/\tau\ge1,\quad
 T=\frac{1024rSH}{\delta},\quad
 \kappa=8\log(4/\delta).
\tag{3}
\]
\(\kappa\) 是新的秩阈值参数，区别于原严格质量门的 \(K=e^{\sqrt n}\)。先保留 \(t(A)\ge\tau\)、\(v\ge\kappa T\)。在固定 \((A,x,z_A)\) 下，旧双来源条件密度至多 \(H\pi_A^2\)；不假设它们独立。

记样本数为 \(N_v\)、有向非对角总亲和为 \(O=\sum_{B\ne C}\gamma_{BC}\)，最大增广秩样本为 \(B_*\)。空过程不定义最大父，且包含在下面的样本数坏事件中。有限 Poisson 级数的换指标给 Campbell 一阶和二阶公式：若 \(\Lambda\) 是有限强度，展开 \(e^{-\Lambda(E)}\sum_n\Lambda^{\otimes n}/n!\)，求和中选择一个或两个有序不同索引，分别消去 \(n\) 或 \(n(n-1)\)，得到 \(\mathbb E\sum f=\int f\,d\Lambda\) 和 \(\mathbb E\sum_{i\ne j}g=\int g\,d\Lambda^2\)。非负 Tonelli 使本处无需额外可积性假设。

由此，\(N_v\sim\operatorname{Pois}(v/T)\)，且
\[
 \Pr\{N_v<v/(2T)\}\le e^{-v/(8T)}\le e^{-\kappa/8},\qquad
 \mathbb EO\le\frac{4rSv}{T^2}.
\tag{4}
\]
第一式可用 \(\mathbb Ee^{-sN_v}=\exp[(v/T)(e^{-s}-1)]\)、\(s=\log2\)、\(\log2\le3/4\) 直接证明。故 \(O>v/(16T)\) 的概率至多 \(64rS/T\)。

最大父的**次概率**律为
\[
 e^{-(v-w)/T}\frac{dF_{j,x}(B)dz_B}{T},\qquad w=v(B,z_B)<v.
\tag{5}
\]
给定最大父及其秩 \(w\)，其他样本仍是 \([0,w)\) 上原 Poisson 过程。因此最大父原行和超过 \(1/2\) 的概率至多 \(8rS/T\)。这里先用未筛选过程，再正限制；不把成功后条件律当作 Poisson 律。

由于 \(m_B\le m_A\)，\(\pi_A(Q_B)=I_{AB}/m_A\le\gamma_{AB}\)。对任一固定样本父，两旧来源至少一者被捕获的条件概率至多 \(2H\gamma_{AB}\)。由 (5) 和 (2)，
\[
 \Pr\{B_*\text{ 捕获旧 }y\text{ 或 }z\}\le\frac{8rSH}{T}.
\tag{6}
\]
设命中旧来源的样本总数为 \(N_{\rm hit}\)。一次 Campbell 公式给
\[
 \mathbb E N_{\rm hit}\le\frac{8rSH}{T},\qquad
 \Pr\{N_{\rm hit}>v/(8T)\}\le\frac{64rSH}{v}
 \le\frac{64rSH}{\kappa T}.
\tag{7}
\]
命中事件共享同一旧 \((y,z)\)；证明只使用条件密度和线性期望，没有独立命中假设。

以上五类坏事件的总概率至多
\[
 e^{-\kappa/8}+\frac{72rS+8rSH+64rSH/\kappa}{T}
 \le e^{-\kappa/8}+\frac{144rSH}{T}
 =\frac{25\delta}{64}<\delta.
\tag{8}
\]
在好事件中，删除原行和 \(>1/2\) 的样本至多 \(2O\le v/(8T)\)，再删除旧来源命中样本至多 \(v/(8T)\)。因此保留数至少 \(v/(4T)\)，最大父未删。每个保留父捕获 \(x\)、排斥旧 \(y,z\)，质量位于 \([e^{-L}m_A,m_A]\)。Gram 对角为1、非对角行和至多 \(1/2\)，故谱在 \([1/2,3/2]\)。进一步
\[
 \mu\Big(\bigcup_{B\ \mathrm{retained}}Q_B\Big)
 \ge\frac23\sum_{B\ \mathrm{retained}}m_B.
\tag{9}
\]
确切地，Gram 上界应用于系数 \(\sqrt{m_B}\) 给 \(\int(\sum c_B)^2d\mu\le(3/2)\sum m_B\)，再用 Cauchy 即得 (9)。重复相同立方体不能同时在该行和门内保留。

## 3. 完整原流恢复与父边缘

记 \(\Psi\) 为以上成功事件的原记录辅助正扩展，**不按成功概率重新归一化**。低 \(t\) 费用至多 \(\tau X\)。由原未截断的均匀秩，低秩费用至多 \(\kappa T\mathcal M\)。其余失败费用至多 \(\delta R\le\delta SX\)。因此
\[
 \boxed{R\le|\Psi|+(\tau+\delta S)X+\kappa T\mathcal M.}\tag{10}
\]
也可保留相对形式 \((1-\delta)R\le|\Psi|+\tau X+\kappa T\mathcal M\)，两式不叠加收费。\(L=\sqrt n\) 时，固定 \(r,S,\tau,\delta\) 下 \(\kappa T\mathcal M=O(\sqrt n)W\)。原更早费用不在本式中重新收取。

作为未筛最大父核的精确说明，固定 \((j,x)\) 的原秩与最大秩联合密度是
\[
 1_{0<w<v<U}\,T^{-1}e^{-(v-w)/T}\,dv\,dw.
\]
积分 \(v\) 后，目标秩密度为 \(1-e^{-(U-w)/T}\le1\)。空过程的原秩总损失为 \(T(1-e^{-U/T})\le T\)。所以完整最大父推前不增加原 \(d\mu(x)dF_{j,x}(B)\) 列，成功限制后仍然如此。这只是父/人工来源边缘关系；没有把原旧来源或历史赋予 \(B_*\)。

## 4. 最大父的实际质量、边长误差

对带内质量阈值 \(e^s\)，记 \(F_s=F_{j,x}\{m_B\le e^s\}\)。跨越该质量阈值的原秩与最大秩总量精确为
\[
 \int_{F_s}^{U}\int_0^{F_s}\frac{e^{-(v-w)/T}}T\,dw\,dv
 =T(1-e^{-F_s/T})(1-e^{-(U-F_s)/T})\le T.
\tag{11}
\]
质量原子对应秩平台；平台内部质量对数差为0，故闭/开阈值在 \(ds\) 积分中没有遗漏费用。用非负层饼积分 \(s\)，随后正删除原各门及成功坏集，得到
\[
 \int_\Psi\log\frac{m_A}{m_{B_*}}\le TD_mW,
\qquad
 \boxed{\int_\Psi\left|\log\frac{R_A}{R_{B_*}}\right|
 \le\frac{TD_m}{n}W+\frac{\log r}{n}R.}\tag{12}
\]
最大父确在保留族内。使用已证 \(R\le SA_nW\)、\(A_n=1+n\log(b/a)\)，右端为 \([TD_m/n+SA_n\log r/n]W\)，固定参数下不随维数增长。它不是以待证根阶主界循环得到的。

## 5. 整配置删除后的双中心外置与最终恢复

最终流在上述成功流上再作一次整配置删除；以下费用不含在 (10) 已扣费用中。对非负 \(F(A,B)\)，未筛 Poisson 计数给
\[
 \int_\Psi\sum_{B\ \mathrm{raw}}F(A,B)
 \le\frac1T\int_{m_B\le m_A}
 t(A)t(B)\frac{I_{AB}}{m_Am_B}F(A,B)\,d\sigma(A)d\sigma(B).
\tag{13}
\]
同带和秩限制只在上界中删除。若 \(B\in Q_A\)，固定 \(A\) 用 \(I_{AB}\le m_B\)、\(t(B)\le S\)、\(\sigma\le\lambda dB\)、\(|Q_A|=m_A/q_A\)，内积分至多 \(rS\)。若 \(A\in Q_B\)，固定 \(B\) 用 \(I_{AB}\le m_B\le m_A\)，同样内积分至多 \(rS\)。因此任一原始样本发生任一中心包含的流量至多
\[
 \frac{2rS}{T}R\le\frac{2rS^2}{T}X.\tag{14}
\]
这里包含的是**中心点**，不是来源质量。令 \(\Psi_{\rm ext}\) 删去这类记录，则 (10) 的右边改成
\[
 |\Psi_{\rm ext}|+
 (\tau+\delta S+2rS^2/T)X+\kappa T\mathcal M.
\tag{15}
\]
这是本稿最终恢复式，记最终实际流为 \(\Psi_{\rm ext}\)。删除整条原记录及其抽样配置，而非只删掉发生中心包含的样本后仍保留原记录。因此其全原始族及保留族与 \(A\) 中心双向外置，(12) 仍成立。本节用旧内部中心容量工具，但计数因子由真实 Poisson 强度 \(1/T\) 精确承担。

## 6. 尚未支付的整体缺口

(10) 是中间恢复式；最终 (15) 没有付清 \(|\Psi_{\rm ext}|\)。近守恒目标边缘、同带、近边长和源质量 packing，并不控制跨人工来源 \(x\) 的重复计价。原 \(y,z\) 在整个保留族之外，仍是实际成功联合权的一部分；更换父后不能刷新它们的条件律或继承原历史。现在需要对该**成功后、保最大父的原联合权**给跨父来源平移/共同覆盖的可加 \(W\) 预算或有偿收缩。没有把任意集中 \(f\) 的边界来源质量换成薄层体积，也没有由父边缘不增直接推出循环付款。

## 7. 本机小证书（可独立重放）

以下代码已使用 `/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python` 实际运行。它只核参数算术、精确 Poisson 穿越积分公式及指数边界，包括阈值两端；不声称构造原生高秩历史场。一般证明为以上解析推导。

```python
from fractions import Fraction as F
from flint import arb, ctx
import sympy as sp
ctx.prec=192
checks=0
for delta in (F(1,4),F(1,8),F(1,16)):
 for r in (F(1),F(5,4)):
  for S in (F(1,5),F(3)):
   for ratio in (F(1),F(1,8)):
    tau=S*ratio; H=S/tau; T=1024*r*S*H/delta
    assert 144*r*S*H/T==9*delta/64; checks+=1
    assert delta/4+144*r*S*H/T==25*delta/64; checks+=1
    assert 25*delta/64<delta; checks+=1
    assert 2*r*S*S/T<=delta*tau/512; checks+=1
v,w,U,T,Fc=sp.symbols('v w U T Fc', positive=True)
inner=sp.exp(-(v-Fc)/T)-sp.exp(-v/T)
primitive=-T*sp.exp(-(v-Fc)/T)+T*sp.exp(-v/T)
assert sp.simplify(sp.diff(primitive,v)-inner)==0; checks+=1
cross=primitive.subs(v,U)-primitive.subs(v,Fc)
assert sp.simplify(cross-T*(1-sp.exp(-Fc/T))*(1-sp.exp(-(U-Fc)/T)))==0; checks+=1
for u in (F(1,2),F(2),F(7)):
 for cut in (F(0),F(1,4),F(1,2),F(1)):
  ua=arb(u.numerator)/u.denominator; fa=ua*arb(cut.numerator)/cut.denominator
  val=(1-(-fa).exp())*(1-(-(ua-fa)).exp())
  assert val<1; checks+=1
  assert val.contains(0) if cut in (0,1) else val>0; checks+=1
  assert 1-(-ua).exp()<1; checks+=1
print('PASS 24 rational parameter cases; 12 exponential profile cases;',checks,
      'assertions (96 Fraction, 2 symbolic, 36 Arb).')
```

实际 stdout：`PASS 24 rational parameter cases; 12 exponential profile cases; 134 assertions (96 Fraction, 2 symbolic, 36 Arb).`
