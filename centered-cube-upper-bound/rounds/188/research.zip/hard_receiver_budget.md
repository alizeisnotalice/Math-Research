# R188：hard 剩余交通的实际双容量配对与未付接收积分

本稿给出原互反正 J-share 的一个实际 current-kernel 双容量配对。它保留原 same-alpha good 损失及完整删除分母，将外 β 与内 bad ν 放在同一个受两边当前 FIRST 容量控制的正测度中。该测度还有一个精确的、至多为1的乘积密度。结论仍依赖 receiver x，尚不能用固定源参考的亲和估计支付；本稿不登记第二个根阶分支。本轮实际新增付款由父稿 `outer_bad_geometric_payment.md` 给出。

仅使用已审 R183 `reciprocal_capture_geometry.md` RCG1–9、RCG13–17，R185 原 current/FIRST/source 合同与 R186 HG 必要几何。无 ν≤β、每叶质量帽、来源独立性、重选森林或负信用。所有 dx 都在原接收域 E_rec 或其有限截断内。

## 1. 原行与准确剩余域

固定一个原共同窗口、ω、接收点 x 及原唯一 j=j(x)。当前核记为

    p_z=P_{s,L}(x−z),
    Q_z=(p_z+p_z^++J_z)/3,
    γ=1+1/n,  κ=K(1+γ^(−n))/3.                    (HB1)

实际应用 K=1；若 κ≥1，基本互反域为空。q>0 是该原窗口的共同阈值，不能为了本稿重新选择 q 或其森林。β_V、ν_V 仅分别受共同父来源 A_V 支配；不同 V 的父来源及原当前核资格给出

    Σ_V ∫ p_y β_V(dy) ≤ q,
    Σ_V ∫ p_u ν_V(du) ≤ q.                        (HB2)

这两式只在同一合法共同 current/FIRST 块使用，不将不同窗口各自的 q 免费合并。它们不要求 P_{s,L}f=q，只用 ≤q。

当前实际目标是 R187 soft 尾及 R186 overlap 门的补集，再可交父稿已经支付的 outer-bad separation 门的补集。保留其原 hard、high、good、history、far、same-alpha、low-Fcal、中央时钟及其他必要指示。以下证明允许任意这些额外正乘子；不把 pair-dependent 指示放入一个虚假的单槽 A。

固定原行 (ω,V,x,j,y)。令 ell、g 为其原完整辅助时间端点，e=e_g(y)>0。使用原

    Π_t(dz)=1_{Z_t(y)}(z) w_t(y,z)ν_V(dz)/e_t(y).

R_y 是时间固定的实际互反 bad 集与原必要初始支持的交，允许其中的来源后来删除。原互反和 high 在实际有效行上给

    κ p_y/p_u < w_g(y,u) ≤ 1       (u∈R_y),
    p_y e ≥ 2Kq.                                  (HB3)

原 strictsoft 只用于核正性等原资格，不解释为 s 接近1。未通过 high、e=0 或空时间行均先置零；所有分式只在合法正分母域定义。

## 2. 不丢掉实际 good 损失的完整删除界

取原固定终端权

    A_y(v)=1_good(v) ρ_y(v) J_v/(3Q_v),
    0≤A_y≤1,  supp A_y⊂Z_g(y).

也可乘时间固定的单 target 指示，例如原 high-A 门；其 α、ρ 仍是原值，不能重算。u-dependent low-Fcal 和 t-dependent 时钟、history 等留在剩余乘子 H∈[0,1] 中。定义

    N_ell(y)=∫_{R_y}w_ell(y,u)ν_V(du),
    D_A(y)=∫ A_y(v)[w_ell(y,v)−w_g(y,v)]ν_V(dv),
    ψ_y=D_A(y)/(e+D_A(y)).                         (HB4)

D_A=0 时 ψ=0。D_A 包含原同 α 削减，不是另立可假定小的矩。R183 的完整删除及分母补偿给

    I_H(y)≤I[A_y,R_y]≤[N_ell(y)/e] ψ_y.           (HB5)

这里 I_H 是原 score 差正部、原两槽 Π_t、原 A 和 H 的时间积分；完整 I 在 [ell,g] 上积分。原 A 的终端幸存支持保证 G_A(t)=∫A_yw_tν 无 target 删除，且

    e_t≥e+G_A(t)−G_A(g).

因此 HB5 已计全部 bad 连续衰减和删除，没有另外丢失一个 time、j 或删除次数因子。若保留 R183 的三个显式缺口及 L_mask=I−I_H，则还有同一行的精确式

    I_H=(N_ell/e)ψ−L_R−M_sc−L_den−L_mask.          (HB6)

四项均非负，均属于这一行同一实际积分；不能把其他分支的缺口借来扣当前补集。

由 HB2–3，ν_V(R_y)≤q/(κp_y)，故

    N_ell/e≤ν_V(R_y)/e≤1/(2Kκ).                  (HB7)

以下保留 HB4 的两个实际量，而不先把 HB5 换成 HB7。

## 3. 实际双容量配对：精确密度与两个边缘

在每个实际 high 行定义正测度

    λ_{x,V}(dy,du)
      =(2Kκ/q) (p_y/e_g(y)) 1_high(y)1_{R_y}(u)
                 w_ell(y,u) β_V(dy)ν_V(du).       (HB8)

ell、g、R_y、e_g 和 j(x) 全保留原值。特别 λ 依赖 x；不是 R186 的固定时间 Γ 参考。定义当前有限源容量

    P^β_{x,V}(dy)=p_y β_V(dy)/q,
    P^ν_{x,V}(du)=p_u ν_V(du)/q,
    m_β=||P^β_{x,V}||, m_ν=||P^ν_{x,V}||.        (HB9)

这是质量至多1的测度，未强行归一为概率。在合法正域有精确乘积密度

    λ_{x,V}=a_{x,V}(y,u) P^β_{x,V}⊗P^ν_{x,V},

    a_{x,V}=1_high 1_{R_y}
       [2Kq/(p_y e_g(y))] [κp_y/p_u] w_ell(y,u),
    0≤a_{x,V}≤1.                                  (HB10)

证明：直接相乘，右侧密度为 2Kκ p_y w_ell/(q e_g)，恰为 HB8。high 控制第一个括号，互反控制第二个括号，物理权 w_ell≤1 控制第三个因子。无须 β、ν 的相互支配或坐标独立。

因此同时有更强的两个边缘与总量界

    λ_{x,V}(dy,R^n)≤m_ν P^β_{x,V}(dy)≤P^β_{x,V}(dy),
    λ_{x,V}(R^n,du)≤m_β P^ν_{x,V}(du)≤P^ν_{x,V}(du),
    ||λ_{x,V}||≤m_βm_ν.                           (HB11)

也可直接检验 u 边缘：high 给 p_y/e≤p_y²/(2Kq)，故

    λ(R^n,du)
      ≤ (p_uν_V(du)/q)
          ∫ (p_yβ_V(dy)/q)
             1_high 1_{R_y}(u)(κp_y/p_u)w_ell(y,u)
      ≤ m_β P^ν_{x,V}(du).

y 边缘用 N_ell/e≤m_ν/(2Kκ) 得到同一结论。这里的小量 m_β、m_ν 是原 current 来源质量；没有用输入未知的局部 Lebesgue 密度上界。

合并 V 时保留 V 标签且仅做同 V 的 product。由 HB2，Σ_Vm_β≤1、Σ_Vm_ν≤1，于是

    Σ_V||λ_{x,V}||≤Σ_Vm_βm_ν≤1.                 (HB12)

相应标记边缘分别受 Σ_VP^β_{x,V}、Σ_VP^ν_{x,V} 支配。不能为每叶另领 q，也不能把同 V 的实际配对换成自由的跨叶独立来源。

## 4. 原 raw 回代：真实系数与未付接收账

只用一次原 hard 帽16/3和外因子2Λ。先在原唯一 j 行完成 HB5，再合并 1_{j(x)=j}。对本稿实际剩余交通，有

    Raw_core
      ≤ (32Λ/3) E_ω Σ_V ∫_{E_rec}dx
                        ∫high p_y I_H(y)β_V(dy)
      ≤ (16Λ/(3Kκ)) E_ω Σ_V ∫_{E_rec}q dx
                        ∫ ψ_y λ_{x,V}(dy,du).     (HB13)

最后一步是 HB8 的精确校准：

    q∫ψ_yλ_{x,V}=2Kκ∫high p_yβ_V(dy)(N_ell/e)ψ_y.

若需要保留原非负缺口，HB13 最后一项减去

    (32Λ/3) E_ω Σ_V∫_{E_rec}dx∫high p_yβ_V(dy)
                         [L_R+M_sc+L_den+L_mask]

恰为 capped 的原 I_H 表达；真正含 hard carrier 的 raw 只由它上界。这是同一次正积分的精确记账，不产生新负信用。

HB10 还给出保留 ψ 的实际 reverse-current 列式

    ∫ψ_yλ_{x,V}
       =∫P^ν_{x,V}(du)∫P^β_{x,V}(dy)
                           a_{x,V}(y,u)ψ_y.       (HB14)

因此本稿消除了把 N_ell/e 单独取最坏值所造成的双来源容量损失。但目前由 ψ≤1 和 HB12 能无条件支付的只是

    Raw_core≤(16Λ/(3Kκ)) E_ω∫_{E_rec}q dx.        (HB15)

该固定系数不是可任意指定的小 ε；HB15 也不是根阶来源预算。HB13 不隐含新的 ψ-small 截断定理。原 R184 已付的小损失时段不得重新计费。不同原共同窗口仍按主总账收费；这里没有跨窗口消除费用。

## 5. 最早未付的实质积分步骤

若希望由 HB13 达到目标，尚须对原实际剩余域证明其同一加权积分满足

    E_ω Σ_V∫_{E_rec}q dx∫ψ_yλ_{x,V}
       ≤ [3Kκ/(16Λ)] ε E_ω∫_{E_rec}q dx
           + C_ε sqrt(n) polylog(n) W_A,           (HB16)

或保留 HB6 的实际四缺口后证明相应较弱式。本稿没有证明 HB16，不将它另命名为已知范数。HB10 是精确容量校准；尚缺的是该校准与 receiver 的空间位置联合起作用。

具体障碍可在 HB14 直接看到：P^β、P^ν 含原自适应 s(x)、L(x)，a 含原 e_g、high、R_y、初始端点，ψ 又含真实 target v、same α 和终端 g。这些对象一起依赖 x。即使原固定 (ω,V,j,y,t) 的 Π_t 独立 x，也不能把 HB14 的 λ 或 current product 移出 dx，冒充固定源 Γ 后套用亲和界。对每个 x 的乘积支配不意味着存在同价的 x-independent product 支配。先对 x 取全部 current 正包络只能回到旧高维来源费，尚未利用 tiny good overlap 的联合削减。

同 α 在这里未消失：它完整留在

    D_A=∫1_good [1−(DK0_v+α_yJ_v)/(TΔ_y(v))]_+
                  J_v/(3Q_v) [w_ell(y,v)−w_g(y,v)]ν_V(dv),

以及原剩余门内；K0 使用实际 Hhat。仅控制 bad 的 K0 加权储备，尚不能把 HB14 的 current 配对与这个 good 损失同时线性结算。把 K0/current 或 inverse overlap 分别取上确界会再次丢失所需的三点信息。

## 6. 与已付分离支及原森林边界的准确接缝

父稿 `outer_bad_geometric_payment.md` 支付的是 actual outer-bad 分离交通，并把 hard 参数作显式有限分层。本稿不重复领取该价。其剩余近域是 capped 位移和 D_b(y,u)=Σ_i min(|y_i−u_i|/b,1) 的约束；当前剩余域的 D_b 上界一般不小于1，因此不保证小的未截断 ||y−u||_∞ 位移。只有当 D_b<r<1 时，才有每坐标未饱和及 ||y−u||_∞≤bD_b<br；即使在此子情形，仍无下述 β 边界占用价，不能把整个剩余域免费放进薄边界层。

若某实际 pair 另外满足 u 接近 y，原 u∉A_{j,t}(y) 只推出

    dist_∞(y,A_{j,t}(y)^c)≤||u−y||_∞.             (HB17)

原 A_{j,t} 是共同半开停止分区，但各块边长依路径不同。真正 light 块有 ν(A_y)≤H_j(t)，heavy fallback 不享此帽；没有从该合同得到 β 的边界层占用小费。因此 HB17 不能支付 HB14 的 β 边缘。此点与本轮 `source_reversibility.md` 的窄核一致。

另一方面，R186 HG 的同 α current/J 分离在 high-A 域给出真实三点必要式：若 c_v=(DK0_v+αJ_v)/(TΔ_v)、η_eff=η−c_v>0 且 η<κ²，则

    log[J_v/p_v]−log[J_u/p_u]
      > log[κ²(1−η)/(η_eff(w_g(y,u)²−κ²))]>0.

这个差由平滑位移项和 signed current-hard 面计数差精确组成。固定 L 的小面长度不能直接替换 actual L(x) 的面层积分：对所有 L∈[a,b] 的正并集有 b−a 的额外宽度。所需的新估计必须在 HB14 的真实 current 边缘、aψ 和原 FIRST 选择下控制这一面层，或利用 HB6 的同一行亏损抵消其费用。仅给必要面事件或只给 β 未加权质量，仍未到达 HB16。

## 7. 检查点结论

本稿无条件证明了 HB8–12 的实际双容量 subcoupling、其精确 product 密度与 HB13 的完整原费用回代。它保留原 good 损失 ψ 和四个完整删除缺口，并明确了 current-source 列中唯一尚未支付的 receiver 联合积分。没有新增一般根阶付款，也没有把 parent 的已付 outer-bad 分离支重复计入。到此停止本轮范围，后续应直接研究 HB14 的同输入自适应面层预算，而不再重做行容量或另加未知小矩门。
