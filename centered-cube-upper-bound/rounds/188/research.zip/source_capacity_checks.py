#!/usr/bin/env python3
"""Exact finite source identities, not a certificate of original tree geometry."""
from fractions import Fraction as F
from pathlib import Path
import argparse,json

def run():
 reverse=[]
 for stage,N in [('initial',2),('stress',3),('expanded',6)]:
  K=[[F(0) if i==j else F(1,1+abs(i-j)) for j in range(N)] for i in range(N)]
  beta=[F(i+1,N) for i in range(N)];nu=[F(N-i,2*N) for i in range(N)]
  if N==3:beta[0]=0;nu[2]=0
  en=[sum((K[i][j]*nu[j] for j in range(N)),F(0)) for i in range(N)]
  eb=[sum((K[i][j]*beta[i] for i in range(N)),F(0)) for j in range(N)]
  assert all(e>0 for e in en+eb)
  C=[sum((beta[i]*K[i][j]/en[i] for i in range(N)),F(0))*nu[j] for j in range(N)]
  for i in range(N):
   for j in range(N):
    forward=beta[i]*K[i][j]*nu[j]/en[i]
    back=nu[j]*K[j][i]*beta[i]/eb[j]
    assert en[i]*forward==eb[j]*back
  assert sum(C)==sum(beta)
  reverse.append({'stage':stage,'N':N,'column_mass':str(sum(C)),'beta_mass':str(sum(beta)),'all_weighted_edge_identities_exact':True,'scope':'Arbitrary finite symmetric K: algebra only, not original carrier certification'})
 couplings=[]
 for stage,scale,dy in [('initial',F(1),F(1)),('stress',F(1,1000000),F(0)),('expanded',F(1000000),F(5))]:
  q=scale;K=F(1);kap=F(1,2);py=[F(1),F(2)];beta=[scale/5,scale/5];pu=[F(4,5),F(1),F(1,100)];nu=[scale/5,scale/5,10*scale]
  weights=[[F(1),F(1,2),F(3,10)],[F(1,2),F(1),F(2,5)]]
  e=[sum(w*m for w,m in zip(row,nu)) for row in weights]
  assert sum(p*m for p,m in zip(py,beta))<=q and sum(p*m for p,m in zip(pu,nu))<=q
  assert all(py[i]*e[i]>=2*K*q for i in range(2))
  # R only includes the two actual bad-slot candidates; retain reciprocal comparison.
  R=[[j<2 and py[i]<=pu[j]/kap for j in range(3)] for i in range(2)]
  lam=[[(2*K*kap/q)*(py[i]/e[i])*weights[i][j]*beta[i]*nu[j] if R[i][j] else F(0) for j in range(3)] for i in range(2)]
  margy=[sum(row) for row in lam];margu=[sum(lam[i][j] for i in range(2)) for j in range(3)]
  assert all(margy[i]<=py[i]*beta[i]/q for i in range(2))
  assert all(margu[j]<=pu[j]*nu[j]/q for j in range(3))
  psi=[dy/(1+dy),F(1,2)]
  direct=sum(py[i]*beta[i]/e[i]*sum(weights[i][j]*nu[j] for j in range(3) if R[i][j])*psi[i] for i in range(2))
  via=q/(2*K*kap)*sum(psi[i]*sum(lam[i]) for i in range(2));assert direct==via
  couplings.append({'stage':stage,'mass_scale':str(scale),'total_lambda':str(sum(margy)),'y_marginals':list(map(str,margy)),'u_marginals':list(map(str,margu)),'psi_weighted_original_expression':str(direct),'q_coupling_expression':str(via),'passed':True,'scope':'Finite capacity/high/reciprocal scalar conditions only; no actual alpha, tree, FIRST, or receiver integral certification'})
 return {'reverse_cases':reverse,'capacity_cases':couplings,'all_checks_pass':True,'scope':'Six exact finite algebra models. No unweighted detailed balance, c<=1, or fixed receiver-independent lambda is asserted.'}
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=Path(__file__).with_suffix('.json'));a=p.parse_args();a.output.write_text(json.dumps(run(),indent=2,sort_keys=True)+'\n');print('6 finite source-capacity cases passed')
