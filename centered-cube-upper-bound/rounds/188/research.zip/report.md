# 第188轮：外来源与坏来源分离的实际几何付款

一般中心立方体 n^(1/2+o(1)) 一致弱型上界尚未闭合。本轮将已有同核亲和估计与原固定正流量结合，得到原互反正J-share中外来源y、坏来源u充分分离时的实际来源预算，且不要求好目标v重叠较大。

## 新的实际估计

原互反门给p_y/p_u≤1/kappa，A≤1。因此原被积式p_y A≤sqrt(p_y p_u)/sqrt(kappa)。这一步只对原互反支使用。把它放入第186轮真正不依receiver的三来源score参考Gamma+，保持其总质量L_n W_A，再使用第185轮同核、共同soft/scale的完整选择包络，得到

 Raw[s≤sbar,D_b(y,u)≥d]
 ≤(32Lambda/(3sqrt(kappa))) L_n C_n exp(-G(1-sbar)d) W_A,
 C_n=e(n+1)(1+nlog2), D_b=sum_i min(|y_i-u_i|/b,1).

其中L_n=nTstar/4包含原j/time费用。取d=[log(L_nC_n/sqrt(n))]_+/G即得根阶分支；d>n时几何门为空，不能声称覆盖。sbar=1不除零，pure-hard边界仅用其独立工具，不冒称actualstrictsoft。

对较硬范围q=1-s>h_n作dyadic分层，明确收取m份来源价；G(q_l)≥q²/16，所以整个q²D_b≥16B_n区域有O(sqrt(n)log(n+1))预算。阶数由解析层数计算，不靠有限拟合。已归第187轮soft部分的q=h_n端点排除，其他带下端点照常包含。

## 剩余核心与辅助接口

结合已付软尾和好目标重叠门，未付主区域更集中为：较硬参数、y与u在上述尺度下较近，同时目标v的重叠极小。这不同于旧的u–v近对。必要的同alpha接收硬面分离继续保留，但没有自动得到该核心的接收预算；其他原mother分支仍未处理完。

原来源核的完整carrier经定义核验确实对称；两类型反向列必须带e_beta/e_nu比值，不能以共同父来源假设消去。原receiver-dependent双容量子耦合保留target-loss系数，只提供准确接口，不能作为fixed-reference或额外根阶付款。短终端时钟属于已有付款类型，没有重新计作本轮突破。

## 验证与严格性

独审先筛准确命题，再全文检查OB付款、参数带覆盖及常数；来源资格和补充耦合分别核验。维度、尺度、窗口、原hard帽和外系数、真实Lebesgue dx全部保留，没有nu≤beta或新森林假设。

本机实际使用Python Fraction和已装mpmath：9个有效有理标量例、3个资格拒绝、25个40/60位阈值行、2个分层菜单；另6个精确有限来源模型检查加权反向式和双边缘容量。三阶段检查均通过。父级完整数值JSON重放一致；有限矩阵不是原几何实现，数值不是区间证书，不认证FULL/FIRST/history。详细范围见numerical_review.md。

## 复现和归档

完整证明见outer_bad_geometric_payment.md及proof.tex.txt；两份辅助稿只登记正确资格和未付费用。解压后python3 reproduce.py --verify-only。实际本机环境：

 PYTHONPATH=/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor python3 reproduce.py --output-dir <不存在的新目录>

G03技能仅用于显式来源/矩阵资格核对，未援引未经证明的树平方函数迁移。实际1 Astra high、2 Sol high、1 Sol medium按独立任务交付；无扣额明细，不猜成本。保留详细LaTeX文本，不编译PDF，每轮单独紧凑归档与提交推送。
