# R188 独立预检与后审

仅写本文件，不Git/spawn/他人文件，不重跑旧数值或重证R187已付软尾。首次读task_contract.md时尚未落盘；暂按父级R188明确任务形成独立检查点，未读本轮作者稿。一般目标未闭合。

## 1. 原目标与已付范围

本轮目标是软尾/重叠支之后的较硬参数、极小good重叠原正交通，继续原same-alpha、HG必要似然分离及真实FIRST current尺度/软度、完整删除、原source/windows和Lebesgue dx。不能从必要位移或signed current面差直接登记weighted receiver价格；R187只支付预选软尾，不覆盖任意硬参数矩形。原旧负信用和已付source/ε预算只用一次。

允许固定(omega,V,j,y,t)的原ν/Zt/wt/et/Πt先于x；terminalg/wg/A、alpha/rho、current参数及history仍依x。任何固定source列或耦合必须把这些残余留在真实密度，或以独立有价估计控制，不能换序时消失。

## 2. 独推有向source列的最低合法身份

固定j,t，记K(y,u)=1_{Z_y,t}(u)w_t(y,u)，e_y=∫K(y,z)ν(dz)，P_y(du)=K(y,u)ν(du)/e_y（e_y0取零）。对有限正β，定义

    Cβ(du)=ν(du)∫_{e_y>0} K(y,u)β(dy)/e_y。

不需要任何对称性或β/ν排序，正Tonelli即得Cβ总质量=β{e_y>0}≤||β||。等价地β(dy)P_y(du)是固定相关有向联合reference，源y/u可以相关，来源质量线性。它可用于合法积分换序，但仅是原Markov行质量账；不会自动支付p_y、A_v、e_g或inverse good overlap等receiver相关乘子。所有原bad/score/history/terminal门若随x选，须留其实际接受密度，不能把切下列又归一成新原posterior。

这类固定列的总质量界本身并不优于R186已有固定βΠ参考的质量控制。若要改善hardtinywg，必须给一个新的实际加权列估计或覆盖，不把同一未付密度改名成source budget。

## 3. 完整支持对称的资格，及仍不可省的degree/source费

w_t(y,u)对称只说明距离权重对称；完整K对称还须证明

    1_{Z_y,t}(u)=1_{Z_u,t}(y)

在同一原source域/forest/top、fixedj,t与实际禁块版本成立。对Z_y=D_V(y)∩(T0(y)\A_j,t(y))，须逐项核D-carrier membership互换、top等价以及y→A_j,t(y)是否为同一共同阈值分区（含原heavy fallback）。不可把另一 shifted森林的partition或独立性代入。若仅局部域对称，必须将补集保留并付价。

若上述完整K对称已由原出处证明，正确详细平衡是

    e_yν(dy)P_y(du)=e_uν(du)P_u(dy)。

平稳测度为m=eν；plain ν不是自动平稳。ν外槽反向路径仍有真实e_u/e_y因子，不能用Markov概率总质量删掉。一般β外槽不具此身份，β与ν仅共父；β=η+ζ+、η=β∧ν、ζ+=(β−ν)+时，可仅对正η项上放ν，ζ+另留。更换内ν为共同父以强造可逆性会改e/Π、same-alpha/capture及原历史，不是本任务授权的原模型归约。

## 4. HG到实际receiver价格的最低义务

HG的same-alpha ηeff及J/current分离可迫使远位移或正signed current面差，但必须仍在原dx β Π²时积分里付价。固定L面长度O(|u−v|)在adaptiveL下的粗sup有不消失b−a尺度带；R187的矩形BV有真实n^(3/2)h²成本，不能将其软尾根价无费延到整个硬参数域。原good-v重叠很小，不能从bad-u reciprocal大重叠转给v。

任何新全支结论须列明原剩余集合覆盖、固定reference（或有价receiver依赖）、actual density比较方向、source/window与j/time聚合、source零分母分支。只声明一个可测切片有界或一个定向列质量≤β，不等于整片hardtinywg已支付。单窗价不得无说明提到EΣV之外。

## 5. 初筛停止点

当前合法建设性接口是§2有向列质量身份与§3带degree的精确换向条件；尚未得到hardtinywg的加权接收全支价格。等待合同及作者准确命题先筛后读，不自行扩反例/数值或新路线。


## 6. 合同补读与两类型balance准确候选独筛

task_contract.md现已落盘并实读，起点d803bf4、责任、允许工具及general未闭合状态与第一阶段一致。G03只资格检查，不援引未验证的外部平方函数界。

本轮作者完整稿前，已独立窄读R113 research.zip::proof.md：B2 lines27–34明确β与ν无排序；B5 lines52–56给同V的两个closed距离限制；B10及lines174–184给原半开共同分区（最粗light、无light时原最细fallback）。R114同名proof S3–4 lines235–250给共同q/H_j(t)和相同分区规则。由同V距离对称、top等价与同一半开分区块归属，完整Z在V×V确实对称；再结合w对称才有K对称。此为原实际资格核验，R182已使用，不登记新付款或历史首次结论。

对无序有限正β、ν，令eν(y)=Kν(y)、eβ(z)=Kβ(z)，Pν_y=Kν/eν、Pβ_z=Kβ/eβ。准确两类型身份为

    eν(y)β(dy)Pν_y(dz)=K(y,z)β(dy)ν(dz)
                     =eβ(z)ν(dz)Pβ_z(dy)。

零degree行先取零；相应Kν或Kβ在该行源测度上为零，故等式作为联合测度成立。非加权βPν反向须保eβ(z)/eν(y)，仅在正joint上形成ratio，零行先延拓0。c(z)=∫K(y,z)β(dy)/eν(y)（eν>0）满足∫cν=β{eν>0}≤||β||，因此c有限ν-a.e，但没有c≤1。star再转向仍须保原y行Pν_y(dv)和所有原y-row masks，不能让z行自动继承high/alpha/history。

该构造比错误要求β≤ν更准确，但仍只是固定来源换序、并未支付硬极小重叠的receiver乘子。原β只取B2独立软源；不同模型的β_c即使另有ν≤β_c也不能替换此原交通。准确作者成稿后再核完整证明与所有费用。


## 7. 父outer-bad远对与Sol nearclock准确候选先筛

父候选在原H含reciprocal时有p_y/p_u<wg(y,u)/κ≤1/κ，A≤1，故

    p_y A H≤κ^(−1/2)√(p_y p_u)H。

采用R186完整固定Γ+(j,t,y,v,u)，质量≤L_nW_A，L_n=nTstar/4，不改变Π或source。D_b(y,u)=Σmin(|y_i−u_i|/b,1)仅固定source/window几何，故D_b≥d可先限制该reference。R185同核全selector包络恰给C_n=e(n+1)(1+nlog2)及γ_sbar=(√(1−sbar+sbarφhalf)−√(sbarφhalf))²，0<sbar<1。整个{s≤sbar,D_b(y,u)≥d}正支有

    Raw≤(32Λ/(3√κ))L_n C_n exp(−γ_sbar d)W_A。

L_n>0时取d=[log(L_nC_n/√n)]_+/γ_sbar；只在d≤n时可能提供非空范围，价格≤(32Λ/(3√κ))√nW_A。L0为zero reference先零，sbar1的γ0不得直接除法，多个阈值/soft菜单不免费聚合。此为原outer-y/bad-u而非旧近u-v工具，实际远pair reference合法；尚不覆盖全部hardtinywg。

Sol nearclock候选可按原row先积分，避免假定g先于y：good给p_y A≤KρJ_v/(3wg_v)，逐坐标wt/wg≤(g/t)^n，et≥eg，δ+≤n和Π_u总质量≤1，于是target积分≤Kn/(3eg)(g/t)^n(J*ν)(x)。每行先对actual t≥g exp(−a/n)且t≤hstop积分，再用原high∫β/eg≤1/(2K)，得到

    Raw_nearclock≤(16Λ/9)(e^a−e^u)_+ Wν≤同系数WA，

保守也可用e^a−1。上述high列先保持同window的固定J_b及ν，唯一1j到统一row界后才合并；无额外Tstar费，也未重复hard/外系数。A≤1或good均在原active门上使用，不改变同α。

本独审另窄读R128 archive proof:637：原u>0在全部来源前固定，hstop=gexp(−u/n)，Jfar=I∩[τ,hstop]。故a>u才可能非空，a=.5logn根价须保(e^a−e^u)_+及实际非空资格，不能重选u。原SP/MA旧已付片须先剔除，不认证strict新物理覆盖。两个候选尚未读作者完整证明，待全文核回代及范围。


## 8. OB全文及dyadic硬参数价

outer_bad_geometric_payment.md已全文实读。OB1–3原recip比较、完整Γ+、same-current pair类型、全selector C_n、G(q)≥q²/4、root阈值及d>n空支均通过。OB4取q_l=2^l h_n，band q_l≤q<2q_l下G(q_l)≥q²/16，故q²D_b≥16B_n确保每band真实root门；完整m次来源参考重用收取m√n费，m=O_c(log(n+1))由显式h_n下界推出。不是无费逐pair最优soft参数，也不收费仅一次。

唯一书面边界修项已发父：若q=h_n已归R187soft片并在bands排除，OB5应写q>h_n或明确先除去soft边界，不能说含该端点的集合也contained于已排除的bands。此不改价格。当前待窄修确认，剩余outer-y/bad-u近对与tiny-good-v交集未付。

## 9. Astra真实双边缘接口的作者前筛查

固定原receiver行，A沿t固定且支持Zg，可另乘terminal highA指示而不改α。记e=eg、D_A=∫A(well−wg)ν、ψ=D_A/(e+D_A)。原完整删除/分母补偿给I_core≤Nell ψ/e，其中Nell=∫R wellν，R为整行固定actualreciprocal集合；pair依赖额外门只能正上放，不能伪装成固定A。

在正high行定义

    λ_x(dy,du)=(2Kκ/q)(p_y/e_y)1_high 1_R(y,u)
                         well(y,u)β(dy)ν(du)。

e0/非原资格先零。其y边缘≤p_yβ/q，因为Nell/e≤1/(2Kκ)。high给p_y/e≤p_y²/(2Kq)；rec κpy/pu≤1、well≤1及current∫pyβ≤q给u边缘≤p_uν/q。因此λ是actual current subcoupling、总质量≤1，无β/ν排序；若将V聚合，保原V标签并用同窗Σcurrentβ/ν容量，不能每V再造一份免费q。

系数准确为

    Raw_core≤(16Λ/(3Kκ))EΣV∫_E q∫ψ_y λ_x dx。

ψ保原target same-alpha，λ仍receiver-dependent。此式不赋予λ fixedΓ资格，也未证明∫ψλ小或获得root来源价；其质量≤1仅复原已知fixed接收费。不得把当前双边缘约束或一个自由最优耦合代替实际λ。待作者全文审门/起止/源账后绑定。


## 10. 已交作者/父证明全文后审

source_reversibility.md SR1–8已全文实读，通过。原完整carrier支持对称而非只w对称，halfopen/closed/fallback均保留；两类型degree balance、零degree先零、βPν反向比值、原y-star/history及c总质量无c≤1准确。SR6背景未用另一β_c强造ν≤β；SR11短钟只历史接口、Wν≤WA账与可能空片/旧已付范围均正确，不登记本轮新价。SR3纯措辞已去掉“β=ν时才”，明确Pν本身以eνν可逆独立β。未将这些精确换序当hardtinywg已付。

outer_bad_geometric_payment.md OB5边界窄修已核为q>h_n；proof.tex.txt已全文实读，与OB1–5完全一致。实际H先含reciprocal，才用py/pu；Γ+真fixed且source距离限制可先放入reference，再作wholeselector核积分。全部EΣV、统一windowclock、root外κ、m次source重用和16阈值均保留，未错误使用current/J affinity，也未把dyadic参数最优化免费化。该付支只涉及outer-y/bad-u远对；tiny-good-v的剩余近outerbad核心未付。

## 11. 数值静态范围（未运行）

outer_bad_affinity_checks.py及numerical_review.md已全文实读。9个Fraction合法scalar与3个拒绝输入，25个40/60dps stableγ阈值，以及2个dyadic菜单实现/标签一致。q0不除γ，q1为pure-hard工具边界、actualstrictsoft空，d>n是空几何；universalL>0菜单未虚构zero-reference测试。两层菜单firstlower排h_n，与OB5最终q>h_n相同，m√n全层价及外32Λ/(3√κ)均保留。精度差非interval，无旧affinity重积分、无physical/FULL或一般阶数拟合。

source_capacity_checks.py也已静态全文实读。3个有限对称K的weighted degree边流/列总质量身份、3个high/current/reciprocal容量模型的λ两边缘与ψ coefficient identity均从同数组计算正确。脚本仅scalar容量，不构造实际α、森林、FIRST或receiver积分；不推c≤1、unweighted详细平衡或λfixed。新product校准的解析身份不依赖这些有限样本是否覆盖。


## 12. HB全文后审、最终整合与冻结

hard_receiver_budget.md已全文实读，通过。HB5/6保原fixed terminal A、完整删除与同一row四非负缺口；HB8–12精确λ/current-product密度、两边缘及同V总容量正确，未把共父换互支配或把pair门并入A。HB13系数16Λ/(3Kκ)、capped身份与原hard正量仅受其上界、ψ/λ随x且HB16未付均准确。唯一几何措辞修项已核落实：当前D_b上界一般≥1不保证小未截断∞位移；D_b<r<1则∞≤bD_b<br，但仍无β边界占用价。

report/reproduce/parent_replay已实读，主tex已全文通过。OB只给outer-y/bad-u分离支，m次完整source价与q>h_n边界收费；HB及SR仅准确资格/容量接口，不计第二root。父affinity重放exit0、完整JSON逐字节一致，另独立numeric reviewer的6个source模型隔离全JSON一致回执已读；本独审未运行。数值经验差非interval/physical/FULL，一般hardtinywg核心与其他mother仍未闭合。不编译PDF，不等待未来manifest循环。

最终结论：明确范围内通过。下表为实际实算最终SHA256，不含自身、manifest/inventory或未来归档验证。保存后停止，不扩研究。

| 文件 | SHA256 |
|---|---|
| hard_receiver_budget.md | `850aae86a2e4cb57063ffdb4c104a9e58f2e1406eb741a42d45850e45233156d` |
| numerical_review.md | `516b7615ad6f5d8c625f28504b635570fc4aa954e209eb67e9fca94fb5cfca60` |
| outer_bad_affinity_checks.json | `f0d3e381a3a2a51df429d9edb7b7472e61447b9ddeba3ca0d0fbd664212f31b1` |
| outer_bad_affinity_checks.py | `74b0ee6fcaa8ebf97aea38509c900b6446d92f913e37c89ca0909097ba6a3c37` |
| outer_bad_geometric_payment.md | `82127cc2aacfc7884a7f67a62e7fc483e27aafa6827e801d989da3b4d00343ac` |
| parent_replay.json | `853b9476d65a698c923432cf9a94b5db601198ec8b668df906a384a5705916ea` |
| proof.tex.txt | `2e8fab38a1878e5a4cb30114519743e1c7d00e3dbedc9698037e324e33c16c38` |
| report.md | `048a6c05e44a5448b4fb3e55c787362007c476b4adcfeba52f8117c6f281cb36` |
| reproduce.py | `fc5d5b77d1555e47e9494c22edb3bf6463b4582958385843804bc6f8677f06fa` |
| source_capacity_checks.json | `ac4307fd8a6b5a157ba75245ac8defab11732bca83e928623d3bfafa3e21b408` |
| source_capacity_checks.py | `25bea414465f2643436552c850376f5e4ebe375a57b8b53a12111b104f92040e` |
| source_reversibility.md | `2915ad925ca001c1db8833d99aaaab73ee664620c16372f45a5688d017b14c7a` |
| task_contract.md | `7512c08a733b18ce8ce42671c94f7d041e12866ec06da1bc5f5f9c743367a153` |
