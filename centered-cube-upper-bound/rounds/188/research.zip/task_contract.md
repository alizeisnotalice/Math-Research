# R188: harder tiny-overlap joint geometry

Start: clean main d803bf45ea26f82e2df5a34d6c32ae77f1e3596d, R187 pushed and remote verified. Previous goal turn was progress. General arbitrary-positive-L1 n^(1/2+o(1)) weak bound is not complete.

Frozen tools: R183 full-deletion RF row; R184 high-A/central bridge; R185 calibrated and mixed-affinity budgets; R186 fixed-time positive-score reference and same-alpha current/J separation; R187 whole soft-tail O(sqrt(n)log(n+1)) payment for the specified original reciprocal J-share. Frozen checkpoints outside repo in /Users/zhengzhihao/Desktop/T/output/centered_cube_round186_20261016_final_checkpoint and round187 analogous path.

Current target: actual s<1-h_n and wg(y,v)<delta_n, retaining original masks, same alpha/rho, true Lebesgue dx, FIRST selector, original sources/windows. Do not repeat softtail or invent a small-density cut and call it closure.

Assignments: Astra high r166_raw_budget owns hard_receiver_budget.md for constructive weighted receiver geometry; Sol high r166_exact_certificate owns source_reversibility.md for independent fixed-source support/reverse-flow proof; Sol high r164_audit owns independent_audit.md and screens candidates independently before proofs. Parent owns main derivation, integration, math-tool validation and Git. No child Git/spawn; each preserves other files and stops after bounded delivery. Numerical Sol medium only after an exact candidate is specified.

Source kernel weight w_t(y,z) is symmetric but original Z_j,y,t(z) need not be: establish actual definition before any exchange. Common domination beta,nu<=A does not give beta<=nu. No receiver-dependent reference, new forest, free ownership or window reuse; all branch constants and hard/outer factors retained. Use G03 skill for operator/domain qualification, not an imported unproved square-function bound. Three-stage numerical diagnostics are finite evidence only. Every completed round separately audited/archived/pushed with detailed LaTeX text and compact necessary files, no PDF.
