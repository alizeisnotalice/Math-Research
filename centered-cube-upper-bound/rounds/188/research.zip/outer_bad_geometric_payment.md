# R188: actual outer–bad separation is payable in the original raw

Status: candidate independently screened; full proof below. It is a genuine positive-branch budget, not a claim that all harder tiny-overlap traffic satisfies the separation condition.

## OB1. Fixed sources and exact original density

Retain the original reciprocal positive J-share, after its one hard/source cap 16/3 and outer factor 2Lambda. For each original omega,V,j,y,t, the actual Pi_t and score k_t are fixed before receiver x. R186 supplies the exact positive reference

 dGamma_V^+ = sum_j 1_[a/cj,bcj](t) dt/t beta_V(dy)
                  (k_t(v)-k_t(u))_+ Pi_t(dv)Pi_t(du).

Use the entire three-source reference: u is the actual reciprocal bad slot, y the outer source, and v the actual good target. They cannot be renamed so that a bound for a different pair is silently applied. Let H_x include all actual reciprocal, current, high, terminal, history, unique-j and further complementary gates, but not a duplicate copy of A. Then

 Raw_capped = (32Lambda/3) E sum_V int dx int p_y A_y(v) H_x dGamma_V^+.

On the support of H, actual reciprocal gives p_y/p_u < w_g(y,u)/kappa <=1/kappa, while 0<=A<=1. Thus, pointwise on this actual support,

 p_y A H <= kappa^(-1/2) sqrt(p_y p_u) H.             (OB1)

After this inequality, H may be discarded on its support by positivity. We have not changed the source posterior, alpha, rho, or its true Lebesgue dx.

R186 proves the reference mass bound E sum_V||Gamma_V^+||<=L_n W_A, L_n=n Tstar/4, where Tstar is the supremum of the original window clock sums. Each score law is an actual Pi_t product, with positive difference mean <=n/4. Distinct j references are paid by Tstar, not removed using unique j after changing integration order.

For uniform formulas below one may use the explicit larger clock

 T_n^univ=sum_(j>=0)(log2-2jlog(1+1/n))_+,
 L_n^univ=n T_n^univ/4>0.

It dominates every original window with b/a<=2. It does not authorize extra independent repetitions of the original source family. The zero-time case has no traffic and is handled before logarithms if an exact zero Tstar is used.

## OB2. Same-current-kernel geometry, with full selector expense

For each original window set

 D_b(y,u)=sum_i min(|y_i-u_i|/b,1), 0<=D_b<=n.

This source/window quantity is fixed before x. For 0<sbar<1, R185 SD12–14 prove the true common-selector envelope

 int sup_(0<=s<=sbar,a<=L<=b) sqrt(P_s,L(x-y)P_s,L(x-u)) dx
  <= C_n exp[-G(1-sbar) D_b(y,u)],
 C_n=e(n+1)(1+nlog2),
 G(q)=(sqrt(q+(1-q)c0)-sqrt((1-q)c0))^2,
 c0=phi(1/2).

This is a same-kernel affinity: both kernels use the same actual current s,L. It is not an unjustified current/J substitution. All soft and scale selector fees are included in C_n. For q>0, rationalizing the square-root difference gives

 G(q)=q^2/[sqrt(q+(1-q)c0)+sqrt((1-q)c0)]^2 >=q^2/4. (OB2)

The last inequality uses 0<c0<1 and 0<=q<=1. G is positive when q>0 and zero at q=0; no threshold divides by G(0). At sbar=0 the separate fixed hard-kernel result applies (and is bounded by the displayed coarse C_n); that boundary is not a nonempty original strictsoft branch.

Restrict the original raw to s<=sbar and D_b(y,u)>=d, 0<=d<=n. The distance cut can be put in the fixed reference; the soft cut remains in H. Apply OB1 first, then the envelope for fixed y,u and integrate the remaining fixed source marks. This gives the real original positive-branch theorem

 Raw_original^+[s<=sbar,D_b(y,u)>=d]
 <=(32Lambda/(3sqrt(kappa))) L_n C_n exp[-G(1-sbar)d] W_A. (OB3)

It holds with all previous low-Fcal/high-A/central/tiny-good-overlap restrictions retained. It makes no demand that w_g(y,v) be large and no old B-density cut. It does not assume beta<=nu or independent actual source coordinates.

## OB3. Exact root threshold and actual scope

For L_n>0 put B_n=max(0,log(L_n C_n/sqrt(n))). When 0<sbar<1 define d_n=B_n/G(1-sbar). If d_n<=n, the entire actual geometric slice D_b(y,u)>=d_n has price at most

 (32Lambda/(3sqrt(kappa))) sqrt(n) W_A.               (OB4)

If d_n>n this geometric gate is empty, so the formula is not evidence of coverage. If B_n=0 the full distance range is paid by the already small prefactor. No strict physical difference from an older paid set is asserted without a FULL-qualified instance; the rigorous result is a sufficient budget for this explicitly defined original geometry.

## OB4. Covering the hard parameter range with explicit layer cost

Fix the same h_n=min(1/2,c sqrt(log(n+1)/n)) as R187. Set q_l=2^l h_n for l=0,...,m-1, where m is the smallest integer with 2^m h_n>=1. The disjoint harder bands are

 q=1-s in [q_l,min(2q_l,1)),

with endpoint conventions adjusted to exclude the soft boundary q=h_n if it has already been assigned to R187. The original strictsoft s>0 means q<1. Every band has q_l<1 and is contained in s<=1-q_l. Use the same universal L_n and B_n in each band and apply OB3 at d_l=B_n/G(q_l). Only gates d_l<=n can be nonempty. Each band costs the constant in OB4, so the total has the explicit multiplier m; the fixed reference is reused m times and this is paid rather than hidden.

Since q<2q_l, OB2 gives G(q_l)>=q^2/16. Therefore the following simpler, parameter-adaptive original geometric region is contained in the union of the paid band gates:

 q>h_n and q^2 D_b(y,u)>=16 B_n.                    (OB5)

Its total price is at most (32Lambda/(3sqrt(kappa))) m sqrt(n) W_A. For fixed c>0, m=O_c(log(n+1)), since h_n>=min(1/2,c sqrt(log2)/sqrt(n)). The dimension order follows from this analytic inequality, not numerical fitting.

Combining the disjoint R187 soft part with this outer–bad-separated harder part and the R186 good-overlap harder part uses three explicitly counted source prices. Remove old paid portions before counting a newly selected portion. Different parameter bands cannot each be normalized to an uncharged fresh W_A.

## OB5. The geometric core left by these estimates

For this specified reciprocal J-share, beyond finite empty-threshold caveats the remaining harder small-good-overlap traffic has outer/bad geometry q^2 D_b(y,u)<16B_n (or the sharper exact band threshold G(q_l)D_b<B_n), while the target v can still have very small w_g(y,v). This is a near outer–bad pair coupled to a low-overlap target, not the old R185 near u–v configuration. The original same-alpha likelihood/face separation in R186 remains available, but no weighted face/column budget for this last core is proved here. Other mother shares remain in the original global account.

Thus the present estimate converts an already proved same-kernel envelope into an actual linear-source raw budget using a legitimate fixed score-flow reference and reciprocal comparison. It does not replace the general objective by a fixed-scale or special-input result, and it does not claim the general n^(1/2+o(1)) bound is closed.
