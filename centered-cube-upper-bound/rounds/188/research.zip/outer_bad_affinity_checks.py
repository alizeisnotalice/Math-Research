#!/usr/bin/env python3
"""R188 finite reciprocal algebra and outer-bad affinity threshold diagnostics."""
from fractions import Fraction as F
from pathlib import Path
import argparse,hashlib,json
import mpmath as mp
HERE=Path(__file__).resolve().parent

def enc(x):
 if isinstance(x,F):return str(x)
 if isinstance(x,dict):return {k:enc(v) for k,v in x.items()}
 if isinstance(x,(tuple,list)):return [enc(v) for v in x]
 return x

def algebra(name,stage,py,pu,A,kappa):
 py,pu,A,kappa=map(F,(py,pu,A,kappa));assert py>=0 and pu>=0 and kappa>0 and 0<=A<=1 and py<=pu/kappa
 lhs=(py*A)**2;middle=py**2;rhs=py*pu/kappa;normalized=kappa*py*A*A/pu if pu>0 else None
 assert lhs<=middle<=rhs and (normalized is None or normalized<=1)
 return dict(name=name,stage=stage,p_y=py,p_u=pu,A=A,kappa=kappa,lhs=lhs,intermediate_p_y_squared=middle,rhs=rhs,normalized_ratio=normalized,equality=lhs==rhs,strictpositive_p=py>0 and pu>0,checks_pass=True,scope='Finite reciprocal scalar algebra; not a physical source/FIRST/history instance')

def exact_cases():
 rows=[algebra('reciprocal_tie','initial',2,1,1,F(1,2)),algebra('half_A','initial',2,1,F(1,2),F(1,2)),algebra('zero_A','initial',2,1,0,F(1,2)),algebra('zero_p_y_boundary','stress',0,1,1,F(1,4)),algebra('both_p_zero_boundary','stress',0,0,1,F(1,2)),algebra('strict_reciprocal_margin','stress',1,F(1,4)+F(1,2**20),1,F(1,4)),algebra('large_scale','expanded',10**60,5*10**59,1,F(1,2)),algebra('tiny_scale','expanded',F(1,10**60),F(1,2*10**60),1,F(1,2)),algebra('near_one_A','expanded',1,F(1,3),1-F(1,2**40),F(1,3))]
 invalid=[]
 for name,args in [('A_above_one',(1,1,2,F(1,2))),('reciprocal_failed',(3,1,0,F(1,2))),('zero_kappa',(1,1,1,0))]:
  try:algebra(name,'invalid',*args)
  except AssertionError:invalid.append(dict(name=name,rejected=True,reason='Hypothesis violation rejected before granting a branch payment'))
  else:raise AssertionError('Invalid scalar input accepted')
 return rows,invalid

def numeric(dps):
 mp.mp.dps=dps;c0=mp.mpf('.5')-mp.expint(3,1);tol=mp.mpf('1e-28')
 def geometry(n):
  nn=mp.mpf(n);lg=mp.log1p(1/nn);h=mp.log(2);N=int(mp.floor(h/(2*lg)))+1;T=N*h-lg*N*(N-1);Tbound=h+h*h/(4*lg);L=nn*T/4;logCn=1+mp.log(nn+1)+mp.log1p(nn*mp.log(2));logpref=mp.log(L)+logCn;requested=8*mp.sqrt(mp.log(nn+1)/nn);hn=min(mp.mpf('.5'),requested);assert T<=Tbound+tol and L>0
  return dict(n=n,log_gamma=lg,T_positive_term_count=N,T=T,T_upper=Tbound,L=L,log_Cn=logCn,log_L_Cn=logpref,hn_requested=requested,hn=hn,hn_cap_applied=requested>mp.mpf('.5'))
 def gamma(q):
  if q==0:return mp.mpf(0)
  # Rationalized form avoids subtraction of two close square roots at small q.
  return q*q/(mp.sqrt(q+(1-q)*c0)+mp.sqrt((1-q)*c0))**2
 def threshold(g,q,label,stage):
  n=g['n'];nn=mp.mpf(n);ga=gamma(q);excess=max(0,g['log_L_Cn']-mp.log(nn)/2)
  if q==0:
   return dict(stage=stage,n=n,q_label=label,q=q,sbar=1-q,gamma=ga,gamma_lower=q*q/4,d=None,d_over_n=None,geometry_nonempty_threshold=None,actual_strictsoft_parameter_nonempty=True,status='q=0 zero gap: no division, threshold unavailable',checks_pass=True)
  assert ga+tol>=q*q/4 and ga>0
  d=excess/ga;logprice=g['log_L_Cn']-ga*d;target=mp.log(nn)/2;assert logprice<=target+tol and (excess==0 or abs(logprice-target)<tol)
  nonempty=d<=nn;physical=q<1
  return dict(stage=stage,n=n,q_label=label,q=q,sbar=1-q,gamma=ga,gamma_lower=q*q/4,gamma_lower_gap=ga-q*q/4,d=d,d_over_n=d/nn,geometry_nonempty_threshold=nonempty,actual_strictsoft_parameter_nonempty=physical,log_normalized_raw_price=logprice,log_root_target=target,root_price_identity_residual=logprice-target,price_identity_kind='equality' if excess>0 else 'at_most_root',status=('d>n: empty geometry, no coverage claim' if not nonempty else ('pure hard sbar=0 boundary tool diagnostic; actual strictsoft branch empty' if not physical else 'finite threshold lies in geometric range')),checks_pass=True)
 geometries=[geometry(n) for n in [16,256,4096,65536,1000000]];rows=[]
 for g in geometries:
  stage='initial' if g['n']<=256 else ('stress' if g['n']<=65536 else 'expanded')
  for label,q in [('1/4',mp.mpf(1)/4),('1/2',mp.mpf(1)/2),('1',mp.mpf(1)),('hn',g['hn']),('0',mp.mpf(0))]:rows.append(threshold(g,q,label,stage))
 menus=[]
 for n in [4096,1000000]:
  g=next(x for x in geometries if x['n']==n);lower=g['hn'];bands=[]
  while lower<1:
   upper=min(1,2*lower);t=threshold(g,lower,'band_lower','dyadic');bands.append(dict(lower_gap_inclusive=lower,upper_gap_exclusive=upper,threshold=t,whole_source_price=mp.sqrt(n),external_prefactor='32 Lambda/(3 sqrt(kappa))'));lower=upper
  m=len(bands);menus.append(dict(n=n,start_hn=g['hn'],first_lower_endpoint_excluded=True,bands=bands,layer_count=m,whole_layer_price=m*mp.sqrt(n),whole_layer_price_over_sqrt_n=m,external_prefactor='32 Lambda/(3 sqrt(kappa))',all_layers_charged=True,scope='Actual gaps in (hn,1): first lower endpoint excluded (q=hn belongs to the soft branch), other lower endpoints included; one full fixed-source price per layer, no free selector/layer optimization'))
 def strings(x):
  if isinstance(x,mp.mpf):return mp.nstr(x,50)
  if isinstance(x,dict):return {k:strings(v) for k,v in x.items()}
  if isinstance(x,list):return [strings(v) for v in x]
  return x
 return strings(dict(dps=dps,c0=c0,geometry_inputs=geometries,threshold_table=rows,dyadic_menus=menus))

def run():
 exact,invalid=exact_cases();low,high=numeric(40),numeric(60);diffs=[]
 for a,b in zip(low['threshold_table'],high['threshold_table']):
  keys=['gamma']+(['d','d_over_n','log_normalized_raw_price'] if a['d'] is not None else []);diff={k:mp.nstr(abs(mp.mpf(a[k])-mp.mpf(b[k])),12) for k in keys};assert all(mp.mpf(v)<mp.mpf('1e-25') for v in diff.values())
  assert a['geometry_nonempty_threshold']==b['geometry_nonempty_threshold'];diffs.append(dict(n=a['n'],q_label=a['q_label'],absolute_differences=diff))
 assert [x['layer_count'] for x in low['dyadic_menus']]==[x['layer_count'] for x in high['dyadic_menus']]
 root=Path(mp.__file__).resolve().parent;sha=hashlib.sha256()
 for p in sorted(root.rglob('*.py')):sha.update(p.relative_to(root).as_posix().encode());sha.update(p.read_bytes())
 return enc(dict(schema='r188_outer_bad_affinity_v1',inputs={'task_contract.md':hashlib.sha256((HERE/'task_contract.md').read_bytes()).hexdigest()},dependencies=dict(mpmath_version=mp.__version__,mpmath_source_tree_sha256=sha.hexdigest()),exact_algebra_cases=exact,invalid_inputs=invalid,low_precision=low,high_precision=high,precision_differences=diffs,summary=dict(exact_valid_cases=len(exact),invalid_rejections=len(invalid),threshold_rows=len(high['threshold_table']),dyadic_menus=len(high['dyadic_menus']),all_observed_checks_pass=True),limitations=['Fraction scalar algebra is not a physical source or FIRST/history realization','T universal scale window sums j>=0 with b/a=2; log computations are high precision numerical, not intervals','q=0 never divided; the prescribed universal-window menu has L>0 throughout and does not evaluate zero-reference inputs','q=1 is a pure-hard kernel tool boundary, not an actual strictsoft parameter row','d>n means empty separated geometry and supplies no nonempty coverage claim','Normalized core prices exclude the explicit external factor 32 Lambda/(3 sqrt(kappa)); all dyadic layers pay it','No old affinity integral is rerun, and no numerical table certifies a general asymptotic order']))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=HERE/'outer_bad_affinity_checks.json');a=p.parse_args();r=run();a.output.write_text(json.dumps(r,indent=2,sort_keys=True)+'\n');print(json.dumps(r['summary'],sort_keys=True))
