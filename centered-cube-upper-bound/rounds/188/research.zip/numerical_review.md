# R188 outer-bad affinity finite checks

Nine Fraction scalar examples, three invalid-input rejections, 25 high-precision threshold rows, and two finite dyadic menus all pass. This task checks the new branch's constants and finite substitution, not the already audited affinity integrals, an original FULL/FIRST/history instance, or a general asymptotic order.

## Reciprocal algebra

Every valid scalar case first verifies p_y,p_u≥0, 0≤A≤1, κ>0 and p_y≤p_u/κ. It then checks the exact chain

`(p_y A)²≤p_y²≤p_y p_u/κ`.

A separately normalized ratio is checked when p_u>0. Initial cases cover reciprocal equality, A=1/2 and A=0. Stress includes zero-source boundaries and a strict reciprocal margin; expanded cases include 10^60/10^-60 scales and A=1−2^-40. Zero p values are explicitly not strict-positive physical-kernel instances. All examples are finite algebra rather than physical realizations. A>1, failed reciprocity (even with A=0), and κ=0 are rejected before any branch-payment claim.

## Threshold constants and zero branches

The universal window is b/a=2. The code retains

`T*=Σ_(j≥0)(log2−2j log(1+1/n))+`, `L=nT*/4`,

`Cn=e(n+1)(1+n log2)`.

The positive term count and finite arithmetic-series sum are computed at both 40 and 60 dps. This is numerical evaluation of the exact finite sum, not a directed interval certificate. All prescribed universal-window rows have L>0; a zero-reference input would require its zero branch before logarithms, but is not passed to this finite menu.

The original φ at the hard face is c0=1/2−E3(1). To avoid small-q cancellation the code evaluates

`gamma(q)=q²/[sqrt(q+(1−q)c0)+sqrt((1−q)c0)]²`.

Every positive-q row satisfies the observed analytic lower bound gamma≥q²/4. The threshold is

`d=max(0,log(LCn/sqrt n))/gamma`.

The log-domain core price LCn exp(−gamma d) equals sqrt n when the logarithmic excess is positive, and is at most sqrt n if the chosen threshold is zero. The external factor **32Λ/(3sqrtκ)** and W_A are not part of this normalized numerical core price and remain payable in the actual branch.

At q=0 the threshold is unavailable: gamma=0 is recorded, with no division or 0/0 assertion. At q=1, sbar=0 is only a pure-hard tool-boundary diagnostic; an actual strict-soft branch is empty. Thresholds d>n describe empty separated geometry because D_b≤n, and are never reported as nonempty coverage. The formulas do not assert that all low-F/low-overlap traffic satisfies a separated-source threshold.

## Finite table and full dyadic costs

The table uses n=16,256,4096,65536,1000000 and q=1/4,1/2,1,h_n,0, where h_n=min(1/2,8sqrt(log(n+1)/n)). Requested and capped h_n are both retained. Examples:

| n | q | d/n | geometric threshold range |
|---:|---|---:|---|
| 16 | h_n=1/2 | 2.9186893164 | empty |
| 256 | 1/4 | 1.6896483431 | empty |
| 256 | h_n=1/2 | 0.4209404742 | within range |
| 4096 | h_n | 0.0808496772 | within range |
| 65536 | h_n | 0.0810320857 | within range |
| 1000000 | h_n | 0.0809507510 | within range |

These are finite formula values, not a fitted limiting constant or proof of dimensional order. The positive-q table preserves root-price residuals in logarithms, so no underflowing exponential is mistaken for an exact zero.

The two dyadic menus partition actual hard-branch gaps (h_n,1). The first band excludes its lower endpoint h_n because q=h_n belongs to the R187 soft branch; other bands include their lower endpoints. Every upper endpoint is excluded, every lower is strictly less than 1, and the last upper is 1. The JSON records `first_lower_endpoint_excluded=True` on each menu; numerical lower values are unchanged. Each band uses its own lower-gap threshold and retains one complete sqrt n source price. The menus have m=2 at n=4096 and m=6 at n=1000000, hence total normalized prices 128 and 6000 respectively. Each is still multiplied by 32Λ/(3sqrtκ). No optimizing over q, j, or a layer menu is free; no source price is removed merely because a threshold is large.

## Precision and reproducibility

Both 40 and 60 dps blocks are saved at 50 printed digits (excess printed digits do not imply corresponding accuracy). All observed threshold differences across the two precisions are below 2.1e-36; range flags and dyadic layer counts agree. Residual and precision thresholds are empirical numerical controls, **not rigorous quadrature or directed interval errors**. No old affinity integral is rerun. Assertion failure exits nonzero.

The actual local environment is standard Python 3 with existing mpmath 1.3.0 supplied externally:

```sh
PYTHONPATH=/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor python3 outer_bad_affinity_checks.py
```

The code uses standard import, accepts `--output /tmp/result.json`, records the package's relative-name `.py` source hash (excluding bytecode), and embeds only the local filename `task_contract.md` as an input-hash key. No absolute vendor or output path enters JSON. No installation is needed.

An isolated replay copies only this script and the contract to `/tmp/r188_outer_bad_review/`, supplies the same external PYTHONPATH, and compares the entire JSON. All actual masks, original reciprocal qualification, common source/window prices and global branch coverage remain mathematical responsibilities of the authored proof, not consequences of this finite checker.

## Additional independent finite source-capacity review

The parent's six `source_capacity_checks.py/json` cases were independently read. No substantive issue was found. For the three symmetric-K examples, both normalizers are retained: eν(i)=ΣKijνj and eβ(j)=ΣKijβi. Every edge checks eν(i)·forward(i,j)=eβ(j)·reverse(j,i), and the forward column masses sum to the actual β mass. This is a weighted reverse identity, not unweighted detailed balance or an asserted column density at most one. The stress case includes zero β/ν slots while all divided normalizers remain positive.

The other three scalar models retain both current marginal capacities, the actual high inequality p_y e_y≥2Kq, and the reciprocal restriction p_y≤p_u/κ before constructing λ. The finite weights are in [0,1]. Both λ marginals are checked against p_yβ/q and p_uν/q; the same ψ-weighted expression is checked exactly before and after the q/(2Kκ) coupling factor. The three source mass scales are 1,10^-6,10^6, and the stress ψ contains a zero branch. There is no assertion of an actual alpha, original carrier/tree, FIRST, receiver-independent λ, or physical source realization. The finite tests do not authorize dropping such qualifications in a general application.

Exactly one isolated standard-library replay copied only the source script into `/tmp/r188_source_capacity_review/` and wrote a new `replayed_source_capacity.json` through `--output`. It exited zero and its entire JSON equalled the parent's output. No mpmath dependency, outer-affinity rerun, new sample, or parent-owned source edit was used.

Reviewed source-file SHA256:

- `source_capacity_checks.py`: `25bea414465f2643436552c850376f5e4ebe375a57b8b53a12111b104f92040e`

- `source_capacity_checks.json`: `ac4307fd8a6b5a157ba75245ac8defab11732bca83e928623d3bfafa3e21b408`
