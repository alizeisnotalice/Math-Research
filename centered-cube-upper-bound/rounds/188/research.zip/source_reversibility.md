# R188：原来源 carrier 的对称性与两类型反向列

本稿固定原来源、原森林和原历史，只证明可以直接回代的测度恒等式及其范围。结论是：固定原窗口和 `(j,t)` 的完整 carrier 确实对称；外来源为 β、内来源为 ν 时，详细平衡使用不同的 degree 加权边缘。原未加权 β 行交换后仍有 degree 比值。本文没有取得 hard/tiny-overlap 整支的新来源付款。

## SR1．冻结对象与窄来源核验

固定 `(ω,V,a,b,q,j,t)`，记原共同父为 `A_V=μ_hi,ω|V`，其质量为 M。只用

\[
 0\le\beta_V\le A_V,\qquad 0\le\nu_V\le A_V,
 \qquad W_\beta,W_\nu\le W_A\le\|f\|_1.                 \tag{SR1}
\]

后两个全局不等式按原同一来源构造、随机种子和不交终端叶求和；它们不授权独立重复窗口再收费。本文不假定 β、ν 彼此有序。

本次只核下列原文窄段（行号为归档 `proof.md`，不使用展开 TeX 的行号）：R113 B2，27–34 行给独立软分解并明确不假定 `ν≤β`；B5，52–56 行给距离集；B20，174–184 行给半开停止分区和 heavy fallback。R114 S3–S4，235–250 行给共同阈值与原禁块。R117 JG1–JG2，29–52 行给实际 `Z,w,e,Π` 及物理时间窗。R128 RT4，648–650 行保证固定 `(ω,V,j,y,t)` 的这些来源对象不依 receiver x。共同父的全局预算使用已审 R181 `common_parent_budget.md`，不把两个来源质量相加后再各领一次父预算。

G03 技能当前只允许显式有限矩阵算术，未提供此项目的私有树平方函数定理。本稿没有调用其捕获估计或 PSD 迁移；以下树定义来自上述原文，证明是直接的集合与正测度计算。

## SR2．完整原 carrier 对称，包括 fallback 和边界

令 `γ=1+1/n,c_j=γ^{-j}`，原阈值为

\[
 H_j(t)=q t^n\max\{1,\sqrt n\,c_{j+1}^n,\sqrt n(t/b)^n\}.
\]

`A_{j,t}(y)` 是包含 y 的最粗 `h(A)≤H_j(t)` 节点；若沿原有限树路径没有 light 节点，取该路径的原最细格。原格均半开，等阈值归 light。这里 h 是原合格硬质量，不以 β 替换。

这些选择组成同一停止分区：若一个节点已经 light，则它以下所有点在路径上首先遇到同一节点；其余路径继续到更细节点或最细 fallback。嵌套树中的两个选中节点若相交必包含，其中较细者的路径已有较粗 light 节点，矛盾；fallback 也不可能与另一个选中节点严格嵌套。故选中块不交且覆盖原顶格。每个选中块包含在原顶格分区 `T_0` 内。最细 heavy fallback 只提供分区，不获得 light 质量帽。

对 y,z∈V 定义原集合和核

\[
\begin{split}
 D_y&=V\cap\{z:\|z-y\|_1\le17na\}
             \cap\{z:\|z-y\|_\infty\le b(5\log n+1/2)\},\\
 Z_y&=D_y\cap(T_0(y)\setminus A_{j,t}(y)),\\
 \xi_t&=c_jt/b,\qquad
 w(y,z)=\prod_{i=1}^n\min\{1,C(|y_i-z_i|/b)/\xi_t\},\\
 K(y,z)&=1_{Z_y}(z)w(y,z).
\end{split}                                                       \tag{SR2}
\]

距离条件对称；同顶格是等价关系；共同停止分区给
`z∉A_{j,t}(y) ⇔ y∉A_{j,t}(z)`。因此

\[
 1_{Z_y}(z)=1_{Z_z}(y),\qquad 0\le K(y,z)=K(z,y)\le1.       \tag{SR3}
\]

半开树边界按唯一归属处理，闭距离边界仍留在 D；无需丢掉可能承载原子来源的边界。source-born 限制属于原 ν，不在转置时插入另一套来源规则。此式只对同一 `(ω,V,j,t,q,a,b)` 成立，不能交换不同窗口或森林。receiver 的 high、good、bad、ρ、α、终端 g 与历史门不是 SR3 的组成部分，也不因 SR3 而对称。这一 carrier 对称性已见已审 R182 `global_column_geometry.md` GC4–GC6，本轮是对两类型来源资格的核定，不登记为新付款。

## SR3．两类型详细平衡及零 degree

省略 V，下文 β、ν 均有限。定义

\[
 e_\nu(y)=\int K(y,z)\,d\nu(z),\quad
 e_\beta(z)=\int K(z,y)\,d\beta(y),\quad
 P^\nu_y(dz)=\frac{K(y,z)\nu(dz)}{e_\nu(y)},\quad
 P^\beta_z(dy)=\frac{K(z,y)\beta(dy)}{e_\beta(z)}.       \tag{SR4}
\]

零 degree 行的 P 定义为零核；正 degree 行为概率。原 `Π_{y,t}` 正是 `P^ν_y`。Tonelli 和 SR3 给精确测度恒等式

\[
 e_\nu(y)\beta(dy)P^\nu_y(dz)
 =K(y,z)\beta(dy)\nu(dz)
 =e_\beta(z)\nu(dz)P^\beta_z(dy).                    \tag{SR5}
\]

两边边缘分别是 `e_ν β` 与 `e_β ν`，不是同一无权来源。特别将 β 取为 ν 时，SR5 退化为同类型的平稳测度 `e_ν ν`；`P^ν` 的这项同类型可逆性本来就不依赖 β，ν 本身不因此平稳。正联合测度只见到 `e_ν(y)>0,e_β(z)>0` 的点对，以下比值一律仅在此处形成，别处置零。

原外槽不带 degree，其准确反向式为

\[
 \beta(dy)P^\nu_y(dz)
 =\nu(dz)P^\beta_z(dy)\frac{e_\beta(z)}{e_\nu(y)}.    \tag{SR6}
\]

证明可先限制 `e_ν≥1/N` 逐项相消，再单调取极限，故没有以零行作除法。定义实际列密度

\[
 c(z)=\int_{e_\nu(y)>0}\frac{K(y,z)}{e_\nu(y)}\,d\beta(y)
     =e_\beta(z)\int\frac{P^\beta_z(dy)}{e_\nu(y)}.
\]

则

\[
 \int c\,d\nu=\beta\{e_\nu>0\}\le\|\beta\|\le M.      \tag{SR7}
\]

所以 c 有限 ν-a.e.，这是准确的总质量守恒；没有 `c≤1` 的点态结论。共同父仅给边流量
`∫e_ν dβ=∫e_β dν≤||β||||ν||≤M²`。若 M>0，将边流量除以 M 确能得到质量≤M的固定参考，但原 βP^ν 相对它的密度是 `M/e_ν(y)`；该放大并未消失。M=0 时原交通全零。

## SR4．原两槽星形的精确反向式

对任意非负实际测试 H（可含 receiver x、全部原历史与三点门），SR6 给

\[
\begin{split}
 &\beta(dy)P^\nu_y(du)P^\nu_y(dv)\\
 &\quad=\nu(du)P^\beta_u(dy)P^\nu_y(dv)
                    \frac{e_\beta(u)}{e_\nu(y)}.       \tag{SR8}
\end{split}
\]

也可只转置 y,v，留下 `P^ν_y(du)e_β(v)/e_ν(y)`。在 SR8 上乘原 H 后积分就是原式，H 的 y 参数不更换。剩余内槽仍为 y 行，不得改成 u 行；原 `α_y,ρ_y(v),A_y(v),p_y,Q_v,g_y` 和 score `k_t(y,·)` 均保留。转置后的 u 不自动满足 y 的 high 或终端/history 资格。即使 `w_t(y,u)` 对称，也没有授权整个三槽交通对称。

因此反向 β 列的可用标准是一个带 `e_β(u)/e_ν(y)` 的真实路径测度。SR7 只支付固定测试的全列总量；当测试含该路径的 target 小 `w_g(y,v)` 倒数、同 α 或 receiver p 时，不能把这些依赖略去后使用 SR7。

## SR5．可实际使用的 high 列：已知工具而非新增价

固定实际 x,j,t，仍保留其原资格。对有贡献的 t≤g，`e_t(y)≥e_g(y)`。在 high 门
`p_y e_g(y)≥2Kq` 上，原 FIRST/current 来源容量给

\[
 \int 1_{\rm high,eligible}\frac{d\beta(y)}{e_t(y)}
 \le\frac1{2Kq}\int p_y\,d\beta(y)\le\frac1{2K}.
\]

使用 SR2 的 `K≤1`，得到正测度不等式

\[
 \int 1_{\rm high,eligible}\beta(dy)P^\nu_y(dz)
 \le\frac1{2K}\nu(dz).                               \tag{SR9}
\]

这不需要 SR3 或 `ν≤β`。high 截取仍依 x，故它不是一份完全不依 receiver 的新参考。对固定 target 测试 `J_b(x-z)`，SR9 保留自然 J；再按原 unique `j(x)` 和固定 b 核积分可以用来源质量付款。这正是 R183 JG/R185 JP 及原单槽能量已经使用的列工具。

实际 companion 测试含 `p_y²ρ_y(v)²J_v/(9Q_v²)`，good 仅给它不超过 `K²ρ_y(v)²J_v/(9w_g(y,v)²)`。SR9 没有控制此剩余 y,v 因子。原 raw 的 `p_y A_y(v)` 也不是一个独立于 y 的固定列测试。因此 SR9 不能单独支付当前 tiny-overlap 余项。

## SR6．原 β 的额外结构与不可混用的来源历史

R112 独立软网络在原有限 pieces 上定义提取比例及有限菜单运行最大值，故原独立 β 确为冻结 α 的正 RN 剩余；原 cut 支撑也保留。J27 的 self-edge 给每个原 piece 的正提取比例下界，形如
`p_i=min(1,√n λ |P_i|/α(P_i))`，进而有限窗 `p_V=min_i p_i>0`。这是依输入的提取下界，不是 β 对 Lebesgue 的统一密度上帽，也不给任意树边界层的 β 占用衰减。原 soft 来源没有继承 hard rank 或 hard 低叶均值（R113 B2 明示）。

还须区分 R113 C6–C8 与 I1–I3：那里另外选取耦合软最大流并定义新 `β^c`，才得到 `ν≤β^c≤α`；I1–I3 明文说明新交通 `T_bi,ov^c` 不与旧任意流余项混用，而且该新提取不继承 J27 的逐 α 点严格正抽取。本文使用当前合同允许的共同父性质，对这两种构造均有效，不用新流覆盖现有 β，也不引用两种历史各自的优点作同一来源的资格。

对本轮 near(y,u)、`u∉A_{j,t}(y)`，确有精确的边界必要条件

\[
 \operatorname{dist}_\infty(y,A_{j,t}(y)^c)
 \le\|u-y\|_\infty.                                  \tag{SR10}
\]

但停止块侧长随原路径变化，并无共同 `(j,t)` 侧长。真正 light 只给 `ν(A_y)≤h(A_y)≤H_j(t)`；heavy fallback 没有这项帽。SR10 不给 β 边界占用费，也不给两个来源的联合壳层帽。R182 GC9–GC11 已将反向 degree 分成共同邻点、light/fallback 和 D_y 边界；本轮核验未消去其中尚未支付的共同邻点、fallback、距离边界费用。

## SR7．历史接口：终端短钟不计作本轮新付款

已审 R170 `soft_threshold_energy.md` (10)–(15) 使用终端 `w_t/w_g≤e^a`、good/high 和固定 J 支付联合边界，其结构已经覆盖这一类终端控制。其旧显示来源账不能据此自动解释为 `W_ν≤W_β`；在当前共同父合同中使用 `W_A`。

直接正 raw 的窄短钟计算也可保留：原 target good 给 `p_yA_y(v)≤KJ_v/(3w_g(y,v))`，且 `w_t/w_g≤(g/t)^n`、`δ_+≤n`、`e_t≥e_g`。每一原 y 行先在 `g e^{-a/n}≤t≤g` 积分，得
`n∫(g/t)^n dt/t≤e^a−1`；随后用 high 列，不把依 y 的 g 提出积分。一次原 hard 帽及外系数给

\[
 \operatorname{Raw}_{\rm shortclock}
 \le\frac{16\Lambda}{9}(e^a-1)W_\nu
 \le\frac{16\Lambda}{9}(e^a-1)W_A.                    \tag{SR11}
\]

原所有 mask 和 `1_{j(x)=j}` 保留到统一行时间上界后，再用固定 b 的 J 积分；若先放松不同 j 的窗口则须另付其和。若 far 还要求 `t≤g e^{-u_0/n}` 且 u_0 为统一固定常数，式中系数可写 `(e^a−e^{u_0})_+`；没有统一 u_0 时只用保守 `e^a−1`。相应时间片可能为空。取 `a=(log n)/2` 仅给这一旧类型短钟的根阶上界，不证明该片对未付原域有严格新增覆盖；本轮不以 SR11 登记新突破。

## SR8．全局来源费用与首个未付环节

SR3–SR8 对每个原窗口分别成立，须保留同一 `ω,V,j,t`。即使 SR7 每时刻的列总量≤||β_V||，对全部 j、时间积分仍会重复来源；不得以 receiver unique-j 在一个已经去掉 receiver 的列参考上免费取消该和。可使用已审 R186FL 的实际时间窗费用 `T_n(a_V,b_V)` 或保留原逐窗求和；窗比例不同须逐窗收费或取原窗族的统一上界。来源叶质量的加总由 SR1 支付，不提供额外时间菜单免费重用。

目前明确得到的是原 carrier 的真实对称性、两类型 degree 详细平衡、未加权列的精确总质量和既有 high 列接口。首个尚未支付的量不是 carrier 的非对称误差，而是 SR6/SR8 中 degree 比值与原 target 小 `w_g`、同 α、两槽 mask、score 和 receiver 核的联合权重。原 β 的结构没有提供本轮所需的边界占用帽；反向行也不能替换原历史。故本文不声称一般 hard/tiny-overlap 全支已付，不减少已审固定来源参考的无条件总费用，也不改变任意正 L1 输入、Lebesgue dx 或来源构造。
