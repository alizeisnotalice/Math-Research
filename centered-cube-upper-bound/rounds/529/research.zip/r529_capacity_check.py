from fractions import Fraction as F
from pathlib import Path
import random,json,sys,platform
import sympy as S

def rat(x): return str(x)
def test(n,L,d,u,v,count,seed,flat=False):
 rng=random.Random(seed);left=u-d/2;right=v-L/2
 pieces=[];total=F(0);collapsed=0
 for k in range(count):
  lo=left+(right-left)*F(k,count);hi=left+(right-left)*F(k+1,count)
  s0=L+(d-L)*F(rng.randrange(101),100);s1=L+(d-L)*F(rng.randrange(101),100)
  p=(s1-s0)/(hi-lo);c=s0-p*lo
  if flat and L<=2*(u-hi) and 2*(u-lo)<=d:
   p=F(-2);c=2*u
  slope=1+p/2;intercept=c/2
  l,h=lo,hi
  if slope:
   r0=(u-intercept)/slope;r1=(v-intercept)/slope
   l=max(l,min(r0,r1));h=min(h,max(r0,r1))
  elif not u<=intercept<=v:
   h=l
  else:collapsed+=1
  amount=F(0)
  if l<h:
   assert L<=p*l+c<=d and L<=p*h+c<=d
   if p:amount=((p*h+c)**(1-n)-(p*l+c)**(1-n))/(p*(1-n))
   else:amount=(h-l)/c**n
   assert amount>=0
  total+=amount
  pieces.append([rat(lo),rat(hi),rat(p),rat(c),rat(amount)])
 cap=(v-u)/L**n+(L**(1-n)-d**(1-n))/(2*(n-1))
 assert total<=cap
 return {'n':n,'L':rat(L),'d':rat(d),'I':[rat(u),rat(v)],'seed':seed,'piece_count':count,'positive_length_collapsed_pieces':collapsed,'piece_columns':['B_left','B_right','radius_slope','radius_intercept','weighted_mass_in_I'],'pieces':pieces,'actual_mass':rat(total),'capacity':rat(cap),'slack':rat(cap-total),'arithmetic':'exact Fraction, full pieces retained'}

m,a,d=S.symbols('m a d',positive=True)
cint=(1-(a/d)**m)/(2*m)+S.log(d/a)/2-(1-(a/d)**m)/(2*m)
assert S.simplify(cint-S.log(d/a)/2)==0
A=1/a+m*(1/a-1/d)
assert S.simplify(A-((m+1)/a-m/d))==0
cases=[test(2,F(1),F(2),F(0),F(1,3),24,52901),test(8,F(1),F(2),F(0),F(0),64,52902,True),test(32,F(1),F(33,32),F(1,7),F(1,7)+F(1,10**6),128,52903,True)]
assert cases[1]['positive_length_collapsed_pieces']>0 and F(cases[1]['actual_mass'])>0
out={'scope':'Exact finite piecewise-affine arbitrary-radius tests of a one-dimensional capacity; not full weighted parent-pair budget or asymptotic evidence','environment':{'executable':sys.executable,'python':platform.python_version(),'sympy':S.__version__},'stages':['initial','singleton_contact_atom_pressure','expanded_dimension_narrow_band_and_window'],'transverse_symbolic_identities':['C=(1/2)log(d/a)','A=(m+1)/a-m/d'],'cases':cases}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2))
print('PASS exact selector capacity cases:',[(v['n'],v['piece_count'],v['positive_length_collapsed_pieces']) for v in cases])
