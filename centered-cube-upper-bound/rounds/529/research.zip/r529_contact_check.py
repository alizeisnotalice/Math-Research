import sympy as s
import json,sys
from pathlib import Path
rows=[]
for n in [2,3,4]:
 for sign in [-1,1]:
  B=s.symbols('b:'+str(n)); C=s.symbols('c:'+str(n)); g=s.symbols('g:'+str(n))
  a,R,y=s.symbols('a R y')
  small=a+sum(g[i]*B[i] for i in range(n))
  A=B[0]+sign*small/2; K=C[0]+sign*R/2
  t=(y-A)/(K-A); kappa=sign*(K-y)
  Z=[(1-t)*B[i]+t*C[i] for i in range(1,n)]
  matrix=s.Matrix([t]+Z).jacobian(B)
  for i in range(1,n):
   for j in range(n):
    matrix[i,j]=s.factor(matrix[i,j]-(C[i]-B[i])*matrix[0,j])
    assert s.factor(matrix[i,j]-((1-t) if i==j else 0))==0
  jac=s.factor(matrix[0,0]*(1-t)**(n-1))
  expected=-sign*(1-t)**(n+1)*(1+sign*g[0]/2)/kappa
  residual=s.factor(jac-expected)
  assert residual==0
  rows.append({'dimension':n,'face_sign':sign,'residual':'0','forward_signed_jacobian':'-sigma*(1-t)^(n+1)*(1+sigma*partial_0_RB/2)/kappa'})
out={'scope':'Symbolic smooth affine-radius contact-map derivative only; not a coarea theorem for arbitrary measurable selectors or a geometric budget','executable':sys.executable,'sympy':s.__version__,'checks':rows}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2))
print(json.dumps(out,indent=2))
