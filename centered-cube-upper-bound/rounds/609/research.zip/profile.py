"""Exact bounded coordinate-profile computation for the supplied pair-envelope J."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1';os.environ['MKL_NUM_THREADS']='1'
from pathlib import Path
from fractions import Fraction as Q
from math import comb
import time,json,sys,platform,resource,hashlib
import sympy as sp
import flint
from flint import arb,ctx
START=time.perf_counter();ctx.prec=256
r,t,v=sp.symbols('r t v',positive=True)
# Coordinate-product identity and t=1/r then v=1-t give the diagonal algebra.
assert sp.expand((1-v)*(2-(1-v))-(1-v*v))==0
# The derivative produces the odd-integrand cancellation exactly.
n=sp.symbols('n',integer=True,positive=True)
assert sp.simplify(sp.diff((1-v*v)**n,v)/(1-v*v)**(n-1)+2*n*v)==0

def A(q):
 q=Q(q);return arb(q.numerator)/q.denominator
def iv(q):return {'lo_exact':str(q.lower().fmpq()),'hi_exact':str(q.upper().fmpq()),'display':q.str(32)}
def J(n,k):
 return sum((Q(comb(k,j))*(-Q(1,2))**j*(Q(1,2)**(n+j)+Q(2*n,n+j)*(1-Q(1,2)**(n+j))) for j in range(k+1)),Q(0))
def diagonal_I(n):
 return sum((Q(comb(n-1,j))*(-1)**j*Q(1,2)**(2*j+1)/Q(2*j+1) for j in range(n)),Q(0))
configs=[('initial',n,k) for n in [2,4,8] for k in [1,n]]
configs += [('boundary_pressure',4,0),('boundary_pressure',4,2),('boundary_pressure',8,0),('boundary_pressure',8,4)]
configs += [('expanded_dimension',n,k) for n in [16,32,64,128] for k in [n//2,n]]
assert len(configs)==18
rows=[]
for stage,n,k in configs:
 value=J(n,k);assert value>0
 # Independently reconstruct the finite r-polynomial and integrate each monomial.
 # This uses no quadrature, nor conversion to floating input.
 Vpoly=sp.Poly(sp.expand(r**(n-k)*(r-sp.Rational(1,2))**k),r)
 terminal=Q(Vpoly.eval(2))/Q(2)**(2*n)
 integral=Q(0)
 for (power,),coeff in Vpoly.terms():
  exponent=power-2*n # primitive denominator, always negative
  integral+=Q(coeff)*Q(Q(2)**exponent-1,exponent)
 independent=terminal+2*n*integral
 assert value==independent
 entry={'stage':stage,'n':n,'k':k,'d_infinity':'0' if k==0 else '1/2','J_exact':str(value),'J':iv(A(value)),'2_to_n_J':iv(A(2**n*value)),'2_to_n_J_over_sqrt_n':iv(A(2**n*value)/A(n).sqrt()),'independent_polynomial_integral_residual':'0'}
 if k==0:assert value==2-Q(1,2)**n;entry['k0_identity_residual']='0'
 if k==n:
  I=diagonal_I(n);assert 2**n*value==1+2*n*I
  normalized=A(2**n*value)/A(n).sqrt()
  lower=A(Q(3,4))+1/A(n).sqrt()
  upper=1/A(n).sqrt()+arb.pi().sqrt()*(A(n)/A(n-1)).sqrt()
  assert normalized>lower and normalized<upper
  entry.update({'diagonal_I_exact':str(I),'diagonal_identity_residual':'0','normalized_over_sqrt_pi':iv(normalized/arb.pi().sqrt()),'sqrt_scale_lower':iv(lower),'sqrt_scale_upper':iv(upper),'both_bounds_strictly_certified':True})
 rows.append(entry)
# Strict profile ordering on exactly requested dimensions; no extra geometry scan.
profile=[]
for dim in sorted(set(c[1] for c in configs)):
 ks=sorted(set(k for _,n,k in configs if n==dim));vals=[J(dim,k) for k in ks]
 assert all(vals[i]>vals[i+1] for i in range(len(vals)-1))
 nonzero=[k for k in ks if k>0]
 profile.append({'n':dim,'k_values':ks,'J_strictly_decreases_in_list':True,'same_l_infinity_for_positive_k':'1/2','first_positive_k_to_diagonal_J_ratio':iv(A(J(dim,nonzero[0])/J(dim,dim)))})
# Decisive full-profile calculation: integrate displacement before taking conclusions.
u=sp.symbols('u',real=True);rr,aa,bb=sp.symbols('rr aa bb',positive=True)
one_coordinate=sp.integrate(rr+u,(u,-rr,0))+sp.integrate(rr-u,(u,0,rr))
assert sp.simplify(one_coordinate-rr**2)==0
N_symbol=sp.symbols('N_symbol',integer=True,positive=True)
last_integral=sp.integrate(2*N_symbol/rr,rr)
assert sp.simplify(last_integral-2*N_symbol*sp.log(rr))==0
full_rows=[]
for dim in [8,32,128]:
 pn=Q(dim-1,dim)**dim;An=1+dim*arb(2).log();C=1+arb(2).log()
 assert An/C>2 and An/C>1
 envelope_row=1+2*dim*arb(2).log();lower=A(pn)*envelope_row
 assert lower>1
 # Original G=2, R=1 is strictly non-top iff 2<2^n; exact.
 assert 2<2**dim and Q(1,16)<Q(1,6) and Q(1,8)<Q(1,2)
 full_rows.append({'n':dim,'source':'f=1_D, D=[-4n,4n]^n, finite L1 mass W=(8n)^n',
  'old_centers':'Eold=[-4n+1,4n-1]^n, R=1,t=1; frozen complete old field',
  'certified_bulk_centers':'B in [-4n+2,4n-2]^n; full old score psi=1 exactly, alpha=1/(1+ln2)',
  'parameters':{'a':'1','b':'2','q':'1','lambda_band':'1','r_band':'1','gamma':'2','h':'1/16','G':'2','beta':'1/8','S':'1'},
  'An_over_C':iv(An/C),'high_slow_strict_guard_An_over_C_gt_2':True,
  'actual_endpoint_mass_ratio':'kappa(G)=2 exactly on all Eold; gamma^h<2<An/C for certified interior B',
  'strict_non_top':'R=1<2/2^(1/n), equivalent to 2<2^n exact',
  'source_inner_y':'[-4n+4,4n-4]^n; all contributing centers for radii<=2 lie within certified bulk interior',
  'inner_source_proportion_exact':str(pn),'inner_source_proportion':iv(A(pn)),
  'actual_H_row_integral_on_inner':'1 exactly; H(y,z)=product_j(1-|y_j-z_j|)_+',
  'envelope_J_row_integral_on_inner':iv(envelope_row),
  'envelope_total_over_W_lower_bound':iv(lower),'strictly_greater_than_one':True,
  'actual_H_total_over_W_upper_bound':'1',
  'scope':'Analytically specified actual finite L1 constant-radius input; formulas verified, not source sampling or optimized pi. J is a relaxed displacement envelope, not the actual kernel on this input.'})
full_profile={'symbolic':{'one_coordinate_integral_exact':str(one_coordinate),'one_coordinate_residual':'0','n_coordinate_identity':'integral_R^n V_d(r) dz = r^(2n), product/Tonelli of integral_-r^r(r-|u|)du=r^2',
 'J_integral':'integral_R^n J_|y-z| dz = 1+2n ln(b/a); terminal b^(-2n)b^(2n)=1 and radial term 2n integral_a^b dr/r',
 'radial_antiderivative':str(last_integral),'radial_residual':'0'},'rows':full_rows,
 'decision':'Cannot infer a complete budget from the diagonal sqrt(n) pair profile. Independent per-pair radius optimization/envelope loses the shared actual R_B; relaxed J has a linear-n full displacement row although the actual constant-radius H row is 1. Not a counterexample to the general weak-type goal.',
 'boundary':'J comparison retains the supplied band [1,2] envelope, not original mass denominators/score weights. Original input/bulk certification applies to constant R=1 and G=2; J is a relaxation, not an available-action kernel assertion.'}
out={'status':'PASS_18_PAIR_ROWS_DIAGONAL_AND_3_FULL_PROFILE_FORMULAS','definition':'J=V(2)/2^(2n)+2n integral_1^2 V(r)r^(-2n-1)dr, V(r)=r^(n-k)(r-1/2)^k.','exact_expansion':'sum_{j=0}^k binom(k,j)(-1/2)^j[2^(-n-j)+2n/(n+j)(1-2^(-n-j))]','symbolic_checks':{'coordinate_identity':'(1-v)(1+v)=1-v^2 exact residual0','odd_integral_cancellation_derivative':'d/dv (1-v^2)^n=-2nv(1-v^2)^(n-1), exact SymPy residual0','diagonal_identity':'2^n J(n,n)=1+2n integral_0^(1/2)(1-v^2)^(n-1)dv','general_proof':'See accompanying Markdown; finite exact residuals check implementation, not the proof of arbitrary n.'},'analytic_conclusions':{'profile':'For fixed n and 0<=k<n, V_k(r)>V_(k+1)(r) for every r in[1,2], hence J(n,k)>J(n,k+1). All positive k have identical l_infinity=1/2, so l_infinity loses profile information.','sqrt_bounds':'For n>=2, 3/4+1/sqrt(n) <= (2^n J(n,n))/sqrt(n) <= 1/sqrt(n)+sqrt(pi)*sqrt(n/(n-1)).','limit':'(2^n J(n,n))/sqrt(n) -> sqrt(pi), by u=sqrt(n)v and dominated convergence with exp(-u^2/2) envelope for n>=2.','scope':'Analytic properties of this supplied pair-envelope only. Not an actual source/center input, no original mass denominators/score filtering, no general weak-type bound.'},'rows':rows,'profile_comparisons':profile,'full_profile':full_profile,'error_policy':'All alternating sums and polynomial integrals use exact Fraction. Arb256 encloses conversion from exact rationals, square roots, pi and normalizations. No numerical quadrature, no float cancellation/sign decisions.','versions':{'python':platform.python_version(),'sympy':sp.__version__,'python_flint':flint.__version__},'interpreter':sys.executable,'command':[sys.executable,*sys.argv],'arb_bits':ctx.prec,'processes':1,'BLAS_threads':1,'runtime_seconds':time.perf_counter()-START,'peak_rss_bytes_macos':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
output=Path(sys.argv[1]) if len(sys.argv)>1 else Path('/tmp/ccu_r609_profile.json');output.write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'status':out['status'],'diagonal_rows':[{'n':row['n'],'normalized':row['2_to_n_J_over_sqrt_n']['display'],'over_sqrt_pi':row['normalized_over_sqrt_pi']['display']} for row in rows if row['k']==row['n']],'seconds':out['runtime_seconds'],'script_sha256':out['script_sha256']},indent=2))
