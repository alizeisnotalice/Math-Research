from fractions import Fraction as F
from pathlib import Path
import json,sys,platform,time
import sympy as sp
ROOT=Path(__file__).resolve().parent
start=time.perf_counter();checks=0

def ck(v):
 global checks
 assert v
 checks+=1

SOURCE_HALF=F(1,100);CENTER_HALF=F(1,100);R=F(6,5)
def geometry(source_centers,record_centers):
 B=[];margins=[]
 for a in record_centers:
  row=[];mr=[]
  for x in source_centers:
   dist=abs(a-x)
   maxdist=dist+CENTER_HALF+SOURCE_HALF
   mindist=max(F(0),dist-CENTER_HALF-SOURCE_HALF)
   if maxdist<R/2:
    row.append(1);mr.append(dict(captured=True,strict_margin=R/2-maxdist))
   else:
    ck(mindist>R/2);row.append(0);mr.append(dict(captured=False,strict_margin=mindist-R/2))
  ck(any(row));B.append(row);margins.append(mr)
 for i,a in enumerate(record_centers):
  for b in record_centers[i+1:]:ck(abs(a-b)>2*CENTER_HALF)
 for i,a in enumerate(source_centers):
  for b in source_centers[i+1:]:ck(abs(a-b)>2*SOURCE_HALF)
 return B,margins

def solve_certificate(name,sources,centers,demands,primal,alpha,beta):
 sources=list(map(F,sources));centers=list(map(F,centers));demands=list(map(F,demands));mass=[F(1)]*len(sources)
 primal=[list(map(F,row)) for row in primal];alpha=list(map(F,alpha));beta=list(map(F,beta))
 capacity_multiplier=F(1) # Abstract parameter; not project s=1+sqrt(n).
 cap=[capacity_multiplier*f for f in mass]
 B,margins=geometry(sources,centers);J=len(centers);I=len(sources)
 m=[sum(B[j][i]*mass[i] for i in range(I)) for j in range(J)]
 allocation=[[demands[j]*mass[i]*B[j][i]/m[j] for i in range(I)] for j in range(J)]
 for j in range(J):ck(sum(allocation[j])==demands[j])
 loads=[sum(allocation[j][i] for j in range(J)) for i in range(I)]
 factors=[min(F(1),cap[i]/loads[i]) if loads[i] else F(1) for i in range(I)]
 thin=[[allocation[j][i]*factors[i] for i in range(I)] for j in range(J)]
 for j in range(J):
  ck(all(x>=0 for x in primal[j]));ck(sum(primal[j])<=demands[j]);ck(all(primal[j][i]==0 for i in range(I) if not B[j][i]))
  ck(sum(thin[j])<=demands[j]);ck(all(thin[j][i]==0 for i in range(I) if not B[j][i]))
 for i in range(I):
  ck(sum(primal[j][i] for j in range(J))<=cap[i]);ck(sum(thin[j][i] for j in range(J))<=cap[i])
 ck(all(x>=0 for x in alpha+beta))
 for j in range(J):
  for i in range(I):
   if B[j][i]:ck(alpha[j]+beta[i]>=1)
 optimum=sum(map(sum,primal));thin_total=sum(map(sum,thin));dual=sum(d*a for d,a in zip(demands,alpha))+sum(c*b for c,b in zip(cap,beta))
 ck(optimum==dual);ck(optimum>thin_total)
 row=[sum(p) for p in primal]
 unnormalized_ratios=[];conditional_ratios=[]
 for j in range(J):
  for i in range(I):
   if B[j][i]:
    ck(primal[j][i]<=2*allocation[j][i])
    unnormalized_ratios.append(primal[j][i]/allocation[j][i])
    pi_ji=mass[i]/m[j]
    if row[j]:
     ck(primal[j][i]<=2*row[j]*pi_ji)
     conditional_ratios.append(primal[j][i]/(row[j]*pi_ji))
 cols=[sum(primal[j][i] for j in range(J)) for i in range(I)]
 slack=sum(alpha[j]*(demands[j]-row[j]) for j in range(J))+sum(beta[i]*(cap[i]-cols[i]) for i in range(I))+sum(primal[j][i]*(alpha[j]+beta[i]-1) for j in range(J) for i in range(I) if B[j][i])
 ck(slack==dual-optimum==0)
 # Simultaneous demand/capacity scaling changes neither thinning factors nor improvement ratios.
 scale=F(7,3)
 scaled_loads=[scale*z for z in loads];scaled_caps=[scale*z for z in cap]
 ck([min(F(1),scaled_caps[i]/scaled_loads[i]) if scaled_loads[i] else F(1) for i in range(I)]==factors)
 ck(sum(scale*x for rr in primal for x in rr)==scale*dual)
 return dict(name=name,source_centers=sources,source_packet_mass=mass,source_density=[f/(2*SOURCE_HALF) for f in mass],
  record_centers=centers,record_demands=demands,side=R,source_halfwidth=SOURCE_HALF,center_halfwidth=CENTER_HALF,
  wholeblock_capture=B,strict_geometry_margins=margins,parent_full_f_mass=m,capacity_multiplier=capacity_multiplier,source_capacity=cap,
  fixed_pi_allocation=allocation,source_loads=loads,inverse_load_factors=factors,thinned_allocation=thin,thinned_record_retained=[sum(rr) for rr in thin],
  thinned_total=thin_total,primal=primal,optimal_record_retained=row,optimal_source_load=cols,optimal_total=optimum,deleted_total=sum(demands)-optimum,
  dual_alpha=alpha,dual_beta=beta,dual_value=dual,duality_gap=dual-optimum,relative_gain=optimum/thin_total,
  max_unnormalized_distortion=max(unnormalized_ratios),max_retained_conditional_distortion=max(conditional_ratios),
  scaling_note='d and capacity multiplied together preserve factors/ratios; no original P demands inferred')
rows=[
 solve_certificate('nested_full_reallocation',[0,1],[F(1,2),0],[1,1],[[0,1],[1,0]],[0,0],[1,1]),
 solve_certificate('nested_Hall_deficit',[0,1],[F(1,2),0],[F(1,2),F(3,2)],[[0,F(1,2)],[1,0]],[1,0],[1,0]),
 solve_certificate('three_packet_chain',[0,1,2],[F(1,2),F(3,2),1],[1,1,1],[[1,0,0],[0,0,1],[0,1,0]],[0,0,0],[1,1,1])]
# General weak dual algebra with arbitrary nonnegative feasible row/column slacks.
x=sp.symbols('x00 x01 x10 x11');dd=sp.symbols('d0 d1');cc=sp.symbols('c0 c1');aa=sp.symbols('a0 a1');bb=sp.symbols('b0 b1')
left=sum(dd[j]*aa[j] for j in range(2))+sum(cc[i]*bb[i] for i in range(2))-sum(x)
right=sum(aa[j]*(dd[j]-sum(x[2*j+i] for i in range(2))) for j in range(2))+sum(bb[i]*(cc[i]-sum(x[2*j+i] for j in range(2))) for i in range(2))+sum(x[2*j+i]*(aa[j]+bb[i]-1) for j in range(2) for i in range(2))
ck(sp.expand(left-right)==0)
ck([r['thinned_total'] for r in rows]==[F(3,2),F(5,4),F(2)])
ck([r['optimal_total'] for r in rows]==[F(2),F(3,2),F(3)])
out=dict(scope='Three finite transport interfaces with actual interval wholeblock capture; no original source/history demand or target capacity existence claim',
 executable=sys.executable,python=platform.python_version(),sympy=sp.__version__,checks=checks,fixtures=rows,
 general_dual='min sum_j d_j alpha_j+sum_i cap_i beta_i; alpha,beta>=0; alpha_j+beta_i>=1 on eligible edges',
 weak_dual_identity='dual-primal=sum alpha(row slack)+sum beta(column slack)+sum edgeflow(alpha+beta-1)',
 density_lift='Every edge uses uniform center block times source packet conditional product; row retained mass, source capacity and wholeblock capture hold pointwise as densities',
 caveats=['Numerical capacity multiplier=1 is not project s=1+sqrt(n)',
 'Retained records keep labels/parents/endpoints/history; conditional artificial-source allocation changes',
 'Pressure fixture deletes 1/2 record mass, so full original parent/record marginal is not preserved',
 'Rescaling demand and cap by project s preserves ratios but does not construct original P demand',
 'No claim the original target capacity has a feasible allocation'],
 compute_index=dict(status='complete',command='/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python r464_numeric.py',
 arithmetic='Fraction exact geometry/primal/dual, SymPy general weak-dual identity; no floating solver',seconds=time.perf_counter()-start))
(ROOT/'r464_numeric.json').write_text(json.dumps(out,default=str,indent=2)+'\n')
print(sys.executable,'Python',platform.python_version(),'SymPy',sp.__version__)
for r in rows:print(r['name'],'fixed thinning',r['thinned_total'],'optimal',r['optimal_total'],'dual',r['dual_value'],'deleted',r['deleted_total'])
print('PASS',checks,'exact assertions;',len(rows),'fixed interval geometries')
