# R464 FINAL PASS（限定范围）

独立 PRE 先行，随后核对冻结七输入。PASS 只认证原记录上的有界来源重分配接口、固定提升的最优截流恒等式、含原子的质量秩测试/恢复式与有限证书。**未认证一般可测 \(\psi\) 达到目标列帽和可吸收缺额，未支付原完整根阶预算；母账保持。**

实际父边缘 \(\nu=P_A\le S\sigma\) 可由原静态帽及附加路径次概率直接使用，不需 R462 的 \(\zeta^{-1}\) 上包络。故实际第三源列 \(B\le SD\le SA_n\)，\(\int B\,d\mu=R\)。对可测 \(0\le\psi\le M\)、\(\int\psi\,d\pi_A=r(A)\le1\)，新联合测度原记录边缘确为 \(r(A)P\)，缺额 \(\Delta=\int(1-r)d\nu\)，列为 \(B_\psi\mu\)。若列帽为 \(\Lambda\)，则 \(R\le\Lambda W+\Delta\)，无条件归一消除缺额或历史转授。有限性来自 \(W,R<\infty\) 与有界 \(\psi\)。

fixed lift 的任意记录依赖截流皆受列 \(\min(B,L)\) 限制，\(w_*=\min(1,L/B)\) 可测达到，最少损失 \(\int(B-L)_+d\mu\) 正确；零列不作除法。拉回原记录为 \(r_*P\) 保旧标签，但将残余重新附 \(\pi_A\) 不等于旧 joint 残余，稿件已警示。此最优性只约束固定分配，不排除允许 \(\psi>1\) 的重分配。

首入零原子始终保留。由同一实际记录的 strict 质量门，\(\pi_A(Q_u\cup Q_v)<2/K^2\)，故有界重分配的零原子至多 \(2MR/K^2\le2MSA_nW/K^2\)。若全部来源容量已计 \(\Lambda W\)，不再额外加该原子费；\(M,S\) 的依赖未隐藏。

complement 使用同一实际接受 RN 定义 \(q_AM_y\rho_y\)，不把加权测试流当原流。原 high-rank 门保证整个 eligible 质量原子的左秩 \(>H\)，故 Hardy 上界无跨阈值的额外首项；\(q_AM_y\le\lambda c^2\) 与 \(\lambda h\) 单位正确。闭累计的 Stieltjes (5) 含终端原子，恢复式 (6) 保负累计项。\(J_y\le H\) 为零流分支。原阶段 \(z,\Delta g_i,D_i\) 与父质量秩并非同一时序，未被混用；根阶测试费用不能逆转成原流付款。

数值三个模型使用真实区间 packet 与正体积 center block，全 capture 对块恒定；来源域各自内部、中心域各自内部不交，跨域可相交。均匀 edge lift 保 row 及来源容量，完整 \(f\) 决定各父质量。显式有理 primal/非负弱对偶证书零 gap，未归一和保留后条件失真分别核准 \(\le2\)。压力例保留 \(3/2\)、删除 \(1/2\)，未称全记录边缘保留；容量参数1未冒充原 \(s\)，也未构造原 \(P\) 需求/history。无需一般强输运对偶或 solver 结论。

指定 Python 在隔离目录
`/var/folders/lq/2c4qbz2n0354_tnttkv_qsz00000gn/T/r464_audit_a8ws1yf1`
重放冻结 geometry/complement 代码块及 numeric 脚本，分别通过100、21、133项断言。三 stdout 与 replay 逐字一致，numeric JSON 仅运行 seconds 不同。100为有限入射截流，21为质量轴/Arb160，133为三个有限真实区间捕获及弱对偶接口；不将断言数当独立场覆盖或一般可行性证明。PRE 临时3轮廓辅助不计归档统计。未修改作者或仓库，未编译 PDF。

最终七输入 SHA256：

- `r464_main.md`: `38f93f512d14217902bcbe93648d9814e87955ed9bc91d42a436e69be8c01e32`
- `r464_geometry.md`: `968dbb7b31e80a4d5839b382d1823625eef79708debec5183c8ad0a0697ee718`
- `r464_complement.md`: `9e9317425b7977671eacf9fe7967d04f04a46ff88d54edf09dbb674460dcbbed`
- `r464_numeric_plan.md`: `15083817746d03114917d108dd7033709e5935aa796813ec88ad8a43e55c52d5`
- `r464_numeric.py`: `5816b5b73decaf5f7652bf6f3bde71993ec0ff451e54b73ad0cd40b6840519ae`
- `r464_numeric.json`: `8ef0c3b84da6076136c23c8233da635c51fb139942b425d5b80145246034d41b`
- `r464_replay.json`: `72c01c399df1c3a50cf3300fd549a1f57cdf1e19c9bd6669bf761e03815b4fb6`
