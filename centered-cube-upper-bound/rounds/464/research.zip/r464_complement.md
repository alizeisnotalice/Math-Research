# R464：保接受权的质量秩积分与恢复边界

本轮未取得新的原流付款。唯一尝试是：先按旧来源 \(y\) 的真实父质量秩积分，再处理第二来源。其逆秩测试可付根阶对数价，但恢复原未加权流时，存在一个准确的累计接受边界；原阶段单调性尚不能控制它。下面给出该边界而不把测试流当成原流。

## 1. 原接受权下的准确秩测度

沿用 R463，\(c=(1+\epsilon_0)h\)、\(J_y=\rho_y(E)\le A_n/q\)。令
\[
 T_y(m)=\rho_y\{m_B\le m\},\qquad H=(4-\epsilon_0)h.
\]
R462 正支配允许把实际 canonical 端点投影写成其包络乘某个 \(0\le\omega(A,y,z,u,v)\le1\)。这是原记录推前的 RN 密度，不重新生成历史。所有原接受门仍在 \(\omega\) 中。定义
\[
 M_y(A)=\int\pi_A(dz)\int\beta_y^*(du)\beta_z^*(dv)\,
 \omega(A,y,z,u,v)
 1_{\{u,v\notin Q_A,\ K^2\max(m_u,m_v)<m_A,\
 c_u(z)=c_v(y)=0\}}.
\]
则 \(0\le M_y(A)\le c^2\)，且实际 canonical 总量准确为
\[
 R_{\rm can}=\frac{S}{\zeta h^2}
 \int f(y)\int q_A M_y(A)\rho_y(dA)\,dy.                    \tag{1}
\]
\(S=0\) 时零流；以下取 \(S>0\)。原 high-rank 门使
\[
 M_y(A)>0\ \Longrightarrow\
 Z_A(y)=\rho_y\{m_B<m_A/K\}>H
 \ \Longrightarrow\ T_y(m_A-)>H.                           \tag{2}
\]
因此不只是右端累计秩超过 \(H\)：整个可能的质量原子都在 \(H\) 之后。

令 \(\nu_y\) 为 \(q_AM_y(A)\rho_y(dA)\) 在右端秩 \(t=T_y(m_A)\) 下的推前，并令
\[
 F_y(t)=\nu_y((H,t]),\qquad H\le t\le J_y.
\]
若 \(J_y\le H\)，则 \(\nu_y=0\)。这是保原接受权、完整匹配与父外门的累计量；不是把 \(M_y\) 换成任意常数模型。

## 2. 可付测试及严格原子处理

对质量原子，其秩区间为 \((T_-,T]\)。由 (2) 它完整位于 \((H,J_y]\)，而
\[
 \frac{T-T_-}{T}\le\int_{T_-}^{T}\frac{dr}{r}.
\]
连续部分同理由秩变换成立，故
\[
 \int\frac{h}{t}\nu_y(dt)
 \le\lambda c^2 h\log_+(J_y/H).                            \tag{3}
\]
没有跨 \(H\) 原子的额外常数；这是 (2) 而非仅 \(T>H\) 的作用。于是原流乘测试权 \(h/T_y(m_A)\) 后，总价格至多
\[
 \frac{S(1+\epsilon_0)^2\lambda h}{\zeta}
 \log_+\frac{A_n}{q(4-\epsilon_0)h}\,W.                     \tag{4}
\]
因 \(\lambda h=(\lambda/q)(1+\sqrt n)/\epsilon_0\)，(4) 是根阶对数来源价。但原流没有该权，(4) 不是新增原流付款或新正分支。

## 3. 恢复原流的准确边界，含所有原子

有限正测度的 Stieltjes 分部积分给
\[
 \int_{(H,J_y]}\frac{\nu_y(dt)}t
 =\frac{F_y(J_y)}{J_y}
   +\int_H^{J_y}\frac{F_y(t)}{t^2}\,dt.                    \tag{5}
\]
右端用闭累计 \(F_y\)；端点原子在第一项保留，积分中单点取值无影响。特别地
\[
 \boxed{F_y(J_y)
 =\frac{J_y}{h}\int\frac ht\,\nu_y(dt)
   -J_y\int_H^{J_y}\frac{F_y(t)}{t^2}\,dt.}                \tag{6}
\]
负的累计项不能丢后再称保留了秩耗散。恢复所需的是同一实际接受累计 \(F_y\)，不是单独的全秩 \(T_y\)。若只有 (3)，丢负项会损失
\[
 J_y/h\le A_n/(qh)
 =\epsilon_0 A_n/(1+\sqrt n),
\]
恰为一般 \(O(\sqrt n)\) 因子。直接原中心界仍只恢复 R462 的线性 \(A_nW\) 价；不会得到根阶。

这也定位了原阶段信息尚未进入的地方。把 \(M_y=\sum_iM_{i,y}\) 按原记录的阶段拆开，(5)–(6) 对每项及其非负和均合法。但 \(D_i\) 随阶段递减、\(\sum_i b_i\le1\)，只控制同一来源的阶段删除；它们没有给出 \(F_y(t)\) 随**父质量秩**的下界。这里 \(b_i\) 的截断来源是第二来源 \(z\)，不是秩参数 \(t=T_y(m_A)\)。不能把阶段删除顺序当成父质量顺序，或把 \(\Delta g_i\) 当成 \(dT_y\)。

因此要从 (6) 得到增益，必须证明原接受质量在较早父秩上的累计足够大，能定量抵消第一项的大因子，或者对实际较晚秩接受量给独立来源费用。当前合同只给 \(M_y\le c^2\)、原静态门与阶段容量，未给该比较；R434 clipping 熵也没有已证的 \(M_{i,y}\) 到其耗散的映射。这里没有对任意中心场声称这种比较失败，只是本次推导未建立它。

(1) 是实际接受推前；(3) 是有权测试；(6) 是精确恢复。三者不能互换。R463 的交叉信用费用和所有旧母账保持一次计收，本稿不增加新余项或宣称完整预算。

## 4. 实际有界检查

内嵌代码在本机实际通过 21 项检查：Fraction 核严格左秩门，Arb 160 位区间核完整原子 Hardy 上界。它是质量轴代数模型，不是原连续 cube/history 实现。解析证明不依赖有限检查。

~~~python
from fractions import Fraction as F
from flint import arb,ctx
ctx.prec=160
def ar(x):return arb(x.numerator)/x.denominator
m=[1,2,4,8,16,32]
checks=0
for rho in [[F(1,3)]*6,[F(x,10) for x in [1,7,2,9,1,4]]]:
    J=sum(rho)
    for H in [F(1,4),F(1,2),F(1)]:
        T=F(0);hardy=F(0)
        for i,w in enumerate(rho):
            left=T;T+=w
            Z=sum(rho[j] for j in range(len(m)) if 2*m[j]<m[i])
            if Z>H:
                assert left>H;checks+=1
                hardy+=w/T
        bound=ar(J/H).log() if J>H else arb(0)
        assert ar(hardy)<=bound;checks+=1
print("PASS",checks,"checks: exact strict-left guards plus Arb160 Hardy upper intervals")
~~~
