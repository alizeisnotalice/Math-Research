# R464：固定第三来源提升的最优竞争与精确恢复损失

**范围。** 保留 R463 的实际接受流 \(P(d\xi)\)，\(A=A(\xi)\)，\(R=|P|\)。所有原来源、阶段、路径及首次进入标签均在记录中。本文只核一个跨父分配：对既定第三来源提升作正截流。结论给出该机制的精确最优恢复量；未取得新的完整根阶预算。父内改变第三来源分布是另一机制，不受本最优性结论排除。

## 1. 实际列比外放松列更便宜

设 \(\mu(dx)=f(x)dx\)、\(W=\mu(\mathbb R^n)\)，并令
\[
 d\widetilde P(\xi,x)=dP(\xi)\pi_{A(\xi)}(dx),\qquad
 B(x)=\int\frac{c_A(x)}{m_A}\,P_A(dA).
\tag{1}
\]
在零质量父上无流。实际原流的父边缘满足 \(P_A\le S\sigma\)：原静态支配为 \(S\sigma\pi_A^2\)，附加条件路径保持记录质量，之后正限制及有限核抽稀只减小质量。因此直接对实际流有
\[
 \int B\,d\mu=R,\qquad
 0\le B(x)\le S D(x)\le S A_n,
 \quad D(x)=\int_E c_A(x)R_A^{-n}dA,
 \quad A_n=1+n\log(b/a).
\tag{2}
\]
这里用 \(\sigma(dA)=q_A dA\)、\(m_A=q_AR_A^n\)。无需使用 R462 的双终端上包络，因而 (2) 没有 \(\zeta^{-1}\)。这只是对既有实际父边缘的直接使用，不作为新几何付款。

## 2. 任意首入优先规则的精确最优值

固定容量 \(L>0\)。允许可测 \(0\le w(\xi,x)\le1\)，依赖所有原记录和 R463 首入标签；要求所选联合测度 \(w\widetilde P\) 的来源列密度 \(B_w\le L\)。则
\[
 \boxed{\sup_w\int w\,d\widetilde P
       =\int\min\{B(x),L\}\,d\mu(x).}
\tag{3}
\]
证明：测度支配给 \(B_w\le B\)，故 \(B_w\le\min(B,L)\)。可测权
\[
 w_*(\xi,x)=\min\{1,L/B(x)\}\quad(B(x)>0)
\tag{4}
\]
达到上界；\(B=0\) 处取0，不影响任何质量。于是最小损失严格为
\[
 R-R_{\rm keep}=\int(B-L)_+\,d\mu.
\tag{5}
\]
此证明不要求逐来源条件概率存在，也不依赖边界零测集。首入时间的0原子仍在 \(\widetilde P\) 内。任何按首入时间、端点或父排序的优先规则，都只能改变同一来源列中保留哪些记录；在这个固定提升类内不能超过 (3)。

为回到原流，定义
\[
 r_*(\xi)=\int w_*(\xi,x)\pi_A(dx),\qquad
 P_{\rm keep}=r_*P,\quad P_{\rm loss}=(1-r_*)P.
\tag{6}
\]
这是原历史上的真实正分拆，\(|P_{\rm keep}|\) 等于 (3)，所有旧标签未重建。第三来源不继承历史。注意：若将 \(P_{\rm loss}\) 再独立附加 \(\pi_A\)，所得联合测度一般不等于 \((1-w_*)\widetilde P\)；不能据此免费迭代同一列预算。

## 3. 费用与唯一缺口

由 (2)–(3)，
\[
 R_{\rm keep}\le LW,\qquad
 R_{\rm keep}\ge
 \min\{1,L/(SA_n)\}R \quad(S>0).
\tag{7}
\]
\(S=0\) 时流为空。取 \(L\asymp s=1+\sqrt n\) 虽给所保留正部分根阶来源价，却只保证约 \(s/A_n\) 的恢复比例；单 octave 中这是 \(n^{-1/2}\) 量级，非维数一致收缩。取 \(L\ge SA_n\) 可保全部流，但回到线性价。本文不把 (7) 当新的几何进展或再次计入旧账。

对这一具体构造，尚缺的恰是实际负载尾的估计，例如
\[
 \int(B-L)_+\,d\mu
 \le \eta X+\vartheta R+C_\eta s\operatorname{polylog}(n)W,
 \qquad \vartheta<1,
\tag{8}
\]
且常数不能由待证目标倒推。原双端点首入去重只在同一父内发生；它没有证明 (8) 中不同父对同一 \(x\) 的重复量减少。

**下一步决策。** 不应继续优化固定提升的首入优先级。(3) 已给该类的全部最优空间。允许在 \(Q_A\) 内改变第三来源分布、同时保持实际父边缘，确实可能改变 \(B\)；那必须另证保留质量及来源列容量，不能由 (3) 得到，也不能把新来源赋予原历史。本附件不重述或假设这种输运可行性。

## 4. 本机有限核验

在指定 Python 环境实际运行 100 项 Fraction 断言：三个有限捕获/后验表，每表四个容量 \(L=1/4,1/2,1,2\)。来源质量及捕获行分别为

- \((1,2,1)\)，行 \(110,011\)，父流质量 \((2,1)\)；
- \((2,1,3)\)，行 \(101,110,011\)，父流质量 \((1,3,2)\)；
- \((1,1,1,1)\)，行 \(1100,0110,0011\)，父流质量 \((2,1,3)\)。

每行后验按完整所捕获来源质量归一。核验 (3)、(5)、(6)、容量、(7)，以及按父次序贪心填每个来源列与 (3) 等值。输出：`PASS 100 Fraction assertions`。这是有限测度代数校验；未声明表为原生立方体全场或满足原历史，严格证明是以上逐列支配与显式可测达到式。

以下为本轮实际运行的自包含代码，可用 Python 3 标准库重放：

```python
from fractions import Fraction as F
cases=[([1,2,1],[[1,1,0],[0,1,1]],[F(2),F(1)]),([2,1,3],[[1,0,1],[1,1,0],[0,1,1]],[F(1),F(3),F(2)]),([1,1,1,1],[[1,1,0,0],[0,1,1,0],[0,0,1,1]],[F(2),F(1),F(3)])]
checks=0
for masses,B,P in cases:
 f=list(map(F,masses)); pi=[[F(c)*m/sum(F(d)*v for d,v in zip(row,f)) for c,m in zip(row,f)] for row in B]
 load=[sum(p*r[j] for p,r in zip(P,pi)) for j in range(len(f))]
 R=sum(P); U=max(l/m for l,m in zip(load,f))
 for L in (F(1,4),F(1,2),F(1),F(2)):
  w=[min(F(1),L*m/l) if l else F(0) for l,m in zip(load,f)]
  row=[sum(a*b for a,b in zip(r,w)) for r in pi]
  kept=sum(p*r for p,r in zip(P,row)); target=sum(min(l,L*m) for l,m in zip(load,f))
  assert kept==target;checks+=1
  assert R-kept==sum(max(F(0),l-L*m) for l,m in zip(load,f));checks+=1
  assert all(l*ww<=L*m for l,ww,m in zip(load,w,f));checks+=1
  assert kept<=L*sum(f);checks+=1
  assert kept>=min(F(1),L/U)*R;checks+=1
  for j in range(len(f)):
   rem=L*f[j]; priority=F(0)
   for p,r in zip(P,pi):
    a=min(rem,p*r[j]);priority+=a;rem-=a
   assert priority==min(load[j],L*f[j]);checks+=1
print('PASS',checks,'Fraction assertions; 3 finite incidence/posterior models, 4 capacities each; algebra only, no native-history claim.')
```

实际标准输出：

```text
PASS 100 Fraction assertions; 3 finite incidence/posterior models, 4 capacities each; algebra only, no native-history claim.
```
