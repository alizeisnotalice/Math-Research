# R464：有限第三来源重分配——实际证书

3例均证实：固定π_A分配后的inverse-load损失可以通过同父内重分配减少，且本例不需要超过2的条件密度失真。压力例仍有不可消除Hall缺额。这是有限输运接口，不证明原需求满足目标source容量。

## 几何与比较对象

source packets中心0、1（第三例另加2），半宽1/100，各质量1，密度50。parent side均6/5，centerblocks半宽1/100；每个record需求均匀分布在其整个centerblock。父center为1/2、0时分别完整捕获{0,1}、{0}；第三例center为1/2、3/2、1，分别捕获{0,1}、{1,2}、{1}。整packet/centerblock的最大捕获距离≤13/25<3/5，未捕获最小距离≥49/50>3/5，严格边距成立。中心块之间两两不交，来源包之间两两不交；中心块与来源包允许相交。

输入需求d固定，父质量m_j=Σ_i f_i B_ji。固定原分配a0_ji=d_j f_i B_ji/m_j。source容量是κ f_i，本次κ=1仅是一般capacity参数，绝非项目s=1+√n。固定分配削减因子为min(1,κf_i/load_i)。重分配只改变同一record条件人工source，不移动父、端点或history标签；被删除record质量不再称原边缘全保。

## 精确primal/dual结果

| 例 | d | 固定削减量 | 最优保留 | 删除量 |
|---|---|---:|---:|---:|
| 两source全重配 | (1,1) | 3/2 | 2 | 0 |
| 同图Hall压力 | (1/2,3/2) | 5/4 | 3/2 | 1/2 |
| 三source链 | (1,1,1) | 2 | 3 | 0 |

primal分别将record分配给source(1,0)、给source(1,0)保留(1/2,1)、及给source(0,2,1)。dual为min Σd_j α_j+Σκf_i β_i，α、β≥0，eligible边α_j+β_i≥1。第一/三例α=0、全β=1；第二例α=(1,0)、β=(1,0)。目标分别2、3/2、3，与primal精确相等。故也是全无失真约束可行域的严格最优证书，不依赖solver。加入下述distortion条件后，已知primal仍可行，原较弱dual仍给同一upper，因此无需新增dual。

逐eligible边另核a_ji≤2a0_ji；对每个保留row单独核a_ji/(row_kept·π_ji)≤2。三个例两种最大失真均为2，不能将未归一失真与保留后条件失真混为一项。这意味着**如果**原π_A下某first-entry atom已有≤2/K²，则本例这种保留row条件重配可转移为≤4/K²；本数值没有独立认证原first-entry界或history。

每条edge可提升为centerblock×sourcepacket上的均匀条件乘积密度，所有capture、row质量及source容量逐密度成立。pressure例第二record从3/2删至1，明确未保留全部原parent/record边缘。将d与capacity同时乘任意原项目s会同步缩放可行primal/dual和保留量，保持削减比率/失真；这不构造原P需求，也不证明目标cap存在。

## 一般弱对偶及执行

SymPy精确核验

dual−primal=Σα(row slack)+Σβ(column slack)+Σedgeflow(α+β−1)。

各项非负即一般弱对偶；有限证书验证全部边及slack并达到零gap。实际133项精确断言，含几何、归一、primal/dual、失真和缩放；只有3个预设例，无扫描。Fraction负责全部数值，SymPy1.14.0核一般代数，无浮点solver或数学舍入。

实际命令：

```
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/r464_numeric.py
```

Python3.12.14；最后wall约0.05秒。JSON含全部输入、逐边严格几何margin、两种分配、失真和零gap。输出到脚本自身目录，无旧轮依赖。

决策限于：normalization/load损失未必内在，保distortion≤2仍可能改善；原人工x重配合法lift及目标容量是否可行必须另证，不以此有限结果付款。

冻结白名单：r464_numeric.py、r464_numeric.json、r464_numeric_plan.md。已完成停止。
