# 第102轮：重建全局几何估计策略

本轮按用户要求，先整理为何局部正确估计在全局恢复时变粗，再选择下一步机制。一般 n^(1/2+o(1)) 一致弱型上界仍未闭合。配置为1个Astra、4个Sol、5个Luna；一名Luna因连续连接错误中断，其协议整理由已完成历史工作的Luna接手，没有增加模型人数。

## 主要诊断

问题不在于每次用了不成立的不等式，而在于某些成立的放松提前丢掉了决定全局费用的几何。再对已经丢信息的量要求根阶，可能强于原问题，甚至被反例直接否掉。

|此前放松|丢掉的实际信息|本轮处理|
|---|---|---|
|每块帽费用相加|许多来源对照亮同一接收区域，删除一次即可同时消除贡献|保留同一个接收帽及真实并集体积|
|交叉项用重叠次数或列上确界控制|相对位移、尺度比及交叠体积|保留精确交叠乘积及阈值接受率；重叠数只作备用界|
|先丢正超额阈值再估二次核|大量平均本来没有过阈值|保留完整来源产生的 h² 门|
|对尺度分别最坏化再相加|相邻尺度对同一来源、接收区域的共同占用|用同一来源对、同一帽的全尺度积分|
|用当前后验方差描述所有可用边|迭代压小但原图仍允许的来源边|补充可重新启用原边的显式高列到低列迁移|

反例必须对准它实际否定的命题。昂贵共同包络不证明真实共同列昂贵；一个帽失败不证明所有付费帽失败；区间上界超过预算不证明真实值超过预算。原F2资格与能量帽资格也不能互相借用。

## 主路线：已付远来源对，联合处理近来源对

取整数 n≥1、非负 f∈L1、κ>0；W=∫f=0 时结论平凡，以下取 W>0。A_L 为全边长立方体平均，h=(1−κ/A_L)_+（A_L=0时置零）。真实帽外平方超额可精确写为

\[
E_U=\iint d\mu(y)d\mu(z)\int_0^\infty L^{-2n}
\int_{Q(y,L)\cap Q(z,L)\setminus U}h(x,L)^2\,dx\,\frac{dL}{L}.
\]

这里 μ=fdy，既不假设来源坐标独立，也不把 μ 的质量换成 Lebesgue 体积。主路线保留完整 f 所定义的门和同一个 U。

取 u=κL^n/W<1、s=log(1/u)，按

\[
\frac{\|y-z\|_1}{L}>[s+(1+\eta)\log(1+s)-\log q]_+
\]

定义远对，q≥1、η>0。准确交叠乘积给出对任意非负 L1 输入、任意阈值和任意可测帽均成立的付款：

\[
E_{\rm far}(U)\le\frac{q}{n\eta}\kappa W.
\]

取q=n、η=1，远对只付κW。保留真实阈值使u≥1部分严格为零；短尺度远对尾也有明确可积界。完整证明见策略模块，不能把它理解为全部能量已付。

现在唯一主攻的联合几何量是：近对在不同尺度照亮的真实接收区域，以及同一帽删掉这些区域后的剩余能量。若能对所有正规输入与κ构造同一U⊃Ω，使

\[
|U|\le A_nW/\kappa,\qquad E_{\rm near}(U)\le B_{\rm near,n}\kappa W,
\]

其中A_n、B_near,n都为n^{o(1)}，则原帽返回才给

\[
C_n\le4A_n+8\sqrt{nA_n(B_{\rm near,n}+1)/\log2}.
\]

这两个近对费用尚未证明。近位移集合的Lebesgue体积小，也不能控制任意连续高密度来源的成对质量；必须和真实帽补集的接受率联合估计。不能先丢掉它，再假定一个漂亮的强不等式把信息补回。

## 辅助路线与明确降级的做法

原F2来源迁移保留为辅助路线：使用原捕获核找到低列来源储备，重新启用被当前分配压小的原边。迁移后的实际来源列、低来源捕获比例和来源重叠都明确收费；尚未证明所有F2都存在足够便宜的储备覆盖。

共同核心/壳分块仅作诊断。它能精确指出丢掉了哪些来源质量、坏接收集合需付多少，但普通细分常重新产生O(n)尺度层数。外接盒重叠数、全局阈值平方根分配也只保留为备用界，不作为已取得的新根阶机制。

## 研究和验证顺序

先核对已证精确几何核及远对积分，再探测同一帽上的近对集中机制。物理输入的三阶段方案是：认证基准；相互作用压力；机制通过后扩展跨尺度簇。最终后续数值协议只采用q=n、η=1；策略模块q=1仅保留解析比较，不另作数值菜单。来源标签、真实接收测度、h²、同帽体积、来源余项与近对尾均须保留。尚未执行的方案明确标为方案，不把拟议菜单算成完成实验。

本轮数学证明和已有材料整理与下一步物理输入探路分开。本轮已执行固定几何守卫一次，并由父代理隔离重放一次，确定性输出8053字节完全相同。它只验证4条交叠、3条尾部核和8条 lens 记录，使用525个端点 cell、9216个尺度区间，新增物理L1输入为0；不充当任意L1输入的近对预算证据。不拟合未知维数指数，不把旧模型的重放记作新来源。

第101轮已独立提交并推送ec5dbf0；本轮单独归档、提交。公开只含一般论证和中性范围，私人下界配方及量化压力继续留在本地。详细LaTeX文本不编译PDF。


## astra strategy

## 1. 决定、范围和本轮实际增量

主路线选 **同一来源的成对捕获几何 + 同一个有偿接收帽**。本轮得到一个全输入、全尺度可证明的远对预算；近对的统一有偿帽仍未证明。原 F2 的共同核心分块保留为第二条诊断路线，其坏接收集和跨尺度来源列必须同时收费。它目前没有优于主路线的一般维数预算，不能把分块本身写成根阶方向。

一般中心立方体弱界 `n^(1/2+o(1))` 仍 OPEN。本文没有新增数值执行。新结论只用真实立方体交叠、非负 Tonelli 和一维积分；没有假设来源坐标独立，没有使用待证弱型常数，没有调用外部强对偶或谱隙。

技能已读：更新后的 D01、G01、N04、F05、A02。本文使用它们要求的正计划模型、每个真实重叠/子树收费、有限终端、两侧核测度和放松方向约束；不将技能目录或来源散列当定理。本文所有新证明在下文自足。

## 2. 准确对象：不能先丢掉的三项几何

任取整数 `n>=1`、`f>=0` 属于 `L1(R^n)`、`W=∫f>0`、`κ>0`，记 `dμ=f dy`，全边长立方体为 `Q(x,L)`，

\[
 A_L(x)=L^{-n}\mu(Q(x,L)),\quad
 h(x,L)=\begin{cases}(1-\kappa/A_L(x))_+,&A_L(x)>0,\\0,&A_L(x)=0.\end{cases}
\]

则 `D_L=(A_L−κ)_+=h A_L`。给任意可测接收帽 `U`，允许所有积分为扩展非负数，

\[
 E_U=\int_{U^c}\int_0^\infty D_L(x)^2\,\frac{dL}{L}\,dx.
\tag{1}
\]

对固定两来源点 `y,z`，共同接收盒

\[
 I_L(y,z)=Q(y,L)\cap Q(z,L),\quad
 |I_L(y,z)|=L^n\prod_{j=1}^n\left(1-\frac{|y_j-z_j|}{L}\right)_+.
\tag{2}
\]

真实阈值保留核为

\[
 T_U(y,z)=\int_0^\infty L^{-2n}
     \int_{I_L(y,z)\setminus U}h(x,L)^2\,dx\,\frac{dL}{L},
 \qquad E_U=\iint T_U(y,z)\,d\mu(y)d\mu(z).
\tag{3}
\]

等式由 `D=h L^{-n}∫1_Qdμ` 平方后 Tonelli 得到。两来源副本的乘积测度只是平方的展开，不意味着每一来源点的坐标独立。

必须保留 `(i)` 同一 `h(x,L)`，它由完整来源产生；`(ii)` 同一 `U` 对各来源对、各尺度的共同删除；`(iii)` 各坐标的相对位移乘积。先取径向包络或先各自最大化会丢掉三者的联合关系。R101 的 `K<=κ²Φ(nJ/κ)/n` 正确，但将同一接收点的实际尺度形状压到 `J`；R101 的最优删帽只能优化它自己的代理量。本文从实际 `E_U` 直接展开，不重新支付该标量放松的最坏尺度形状。

## 3. 已证新预算：带两个可选参数的全尺度远对估计

固定有限参数 `q>=1`、`η>0`。定义无量纲尺度与距离

\[
 u=\frac{\kappa L^n}{W},\qquad
 s=\log(1/u)\quad(0<u<1),\qquad
 d_L(y,z)=\frac{\|y-z\|_1}{L},
\]

以及

\[
 t_{\eta,q}(u)=\bigl[s+(1+\eta)\log(1+s)-\log q\bigr]_+
 \quad(0<u<1).
\tag{4}
\]

近对事件是 `0<u<1` 且 `d_L<=t_{η,q}(u)`；远对为其补集。将这个来源对—尺度指示函数插入 (3)，分别定义 `E_near(U)` 与 `E_far(U)`。于是

\[
 E_U=E_{\rm near}(U)+E_{\rm far}(U),\qquad
 \boxed{E_{\rm far}(U)\le\frac{q}{n\eta}\,\kappa W.}
\tag{5}
\]

**量词：** (5) 对上节每个输入、每个阈值和每个可测帽均成立，不需要障碍、F2 门或正规 `L2` 假设。它不是近对预算，不证明有限的全能量。

**证明。** 当 `u>=1`，总质量界 `A_L<=W/L^n<=κ` 给 `h=0`，所以这部分真实能量严格为零。对 `0<u<1`，由 (2) 和 `1-a<=e^{-a}`，

\[
 |I_L(y,z)|\le L^n e^{-d_L(y,z)}.
\tag{6}
\]

如果某坐标距离不小于 `L`，左端为零，(6) 仍有效。若 `t>0` 且为远对，

\[
 e^{-d_L}\le e^{-t}
 =\frac{q u}{(1+s)^{1+\eta}}.
\]

若 `t=0`，其定义给右端不小于一，所以同一上界也有效。使用 `0<=h<=1` 及 `I_L\setminus U⊂I_L`，远对在固定尺度的来源双积分不超过

\[
 W^2 L^{-n}\frac{q u}{(1+s)^{1+\eta}}
 =\frac{q\kappa W}{(1+s)^{1+\eta}}.
\]

又 `dL/L=−ds/n`，因而

\[
 E_{\rm far}(U)
 \le\frac{q\kappa W}{n}\int_0^\infty\frac{ds}{(1+s)^{1+\eta}}
 =\frac{q\kappa W}{n\eta}.
\]

全部交换均为非负 Tonelli，不减去无穷量。`μ=fdy` 无原子，所以 `t=0` 时近对要求 `y=z`，该集合具有零 `μ⊗μ` 测度。证明完毕。

两个有用而不同的选择是 `q=1,η=1`，远对付 `κW/n`；以及 `q=n,η=1`，远对付 `κW`，而近对阈值比前者缩小 `log n` 后截零。二者不得混用：缩窄近对有明确的 `q/n` 费用。

**尺度尾也可严格支付。** 仅对远对，对任意有限 `S>=0`，若截断到 `s<=S`，遗漏尾满足

\[
 E_{\rm far,\,s>S}(U)
 \le\frac{q\kappa W}{n\eta}(1+S)^{-\eta}.
\tag{7}
\]

近对没有这项免费尾界；不得用 (7) 封闭其未算尺度。近对半径 `L t_{η,q}(κL^n/W)` 随 `L` 并非全程单调，也不能换成一个统一膨胀立方体而不收费。

## 4. 主路线下一步究竟做什么

已付远对让问题定位到：同一来源的尺度依赖近对能量是否在真实接收空间中集中到一个便宜的、一般非立方体形状的帽。关键不是再猜一个全空间混合矩，而是先核对 **许多近对及相邻尺度是否反复照亮同一小接收区域**。若是，帽的真实并集只收费一次；若不是，分散的接收体积必须全部计入。

可执行的联合分解如下。

1. 冻结完整 `f,κ,h` 与所需基础障碍帽 `Ω`。选择来源的有限可测分区（另有显式余项），用二叉簇树组织；每对不同叶的来源点唯一归属其最近共同祖先，叶内对归该叶。每个来源对只登记一次，但保留它的所有实际尺度。不得把叶来源当新输入重新运行门或重新选择阈值。
2. 每个记录保留 `(来源对簇, L, I_L, h, 接收单元)`。先用 (4) 删去已付远对，只为近对计算实际接收贡献。来源簇间不能用 `W_iW_j` 直接替代其位置和尺度门后再猜衰减；这种替代只能明确记作上界松弛。
3. 同一接收单元内累加所有近对记录，得到真实近对能量密度 `N(x)`。帽选择只做一次；删除一格的收益是该格中所有近对记录的总收益，体积只收费一次。不同簇自行挑帽后求体积和，通常丢失本轮希望利用的共享接收几何。
4. 在真实 Lebesgue 单元上，以认证的上下能量密度及体积给 `|U|`、`∫_{U^c}N` 的上下证书。可以使用 R101 已审过的量词/平层删除纪律；这里排序的是实际 `N(x)`，不再是 `J` 代理。部分单元删除需实际体积收费；UNKNOWN 既不能当零能量也不能免费删除。
5. 看清有效机制再拟一般引理：需要显示同一 `U` 的几何构造如何把近对块的剩余贡献一同控制，尤其跨相邻尺度共用哪些接收区域。有限记录只检验这个机制，不能证明全输入统一规律。

这里的簇树只是**准确登记来源对**，没有自动树 packing；任何拟用 G01 的子树质量控制都需在实际来源/接收对象上逐子树证明。不同层的源质量不可多次当新的 `W` 花掉。

**完整成功账。** 对正规输入 `f∈L1∩L2` 的 R100 同一障碍 `Ω`，若能对每个输入、每个 `κ` 构造 `U⊃Ω` 并证明维数唯一的

\[
 |U|\le A_n W/\kappa,\qquad
 E_{\rm near}(U)\le B_{\rm near,n}\kappa W,
\tag{8}
\]

那么已付远对给 `B_n=B_near,n+q/(nη)`，现有帽返回为

\[
 C_n\le4A_n+8\sqrt{\frac{nA_n\,[B_{\rm near,n}+q/(n\eta)]}{\log2}}.
\tag{9}
\]

取 `q=n,η=1` 时，只剩 `A_n=n^{o(1)}` 与 `B_near,n=n^{o(1)}` 两项几何付款；它们尚未证明。所有接收、来源分区余项和近对尺度尾必须计入 (8)，不另有免费 terminal。只有取得这种幅度无关统一正规输入界，才对原极大算子单调截断返回任意非负 `L1`。本文没有取得 (8)。

**明确失败判据。** 若使用相同帽后，某个合资格输入的近对下证书仍超过拟定预算，否定该帽/近对构造；若只有松弛上界大，先定位丢失的 `h`、并集体积或相对位置，不宣布方法或目标失败。若近对认证必须以与幅度/尺度跨度相关的无界个数相加，当前一般策略不成立。若仅已付远对很小，不能据此推断近对或总能量小。

## 5. 第二路线：实际共同核心与坏接收集费用（诊断，不作主结论）

冻结 R101 原 F2 的同源 `μ=fdy`、同阈值 `λ`、有限接收集 `B`、全部原门及最早尺度 `L_x∈[1,2]`，满足 `μ(Q(x,L_x))=λL_x^n`。任给可数可测分区 `B=⊔B_i`，每块取共同可测来源核心 `C_i⊂Q(x,L_x)` 对几乎处处 `x∈B_i` 成立。设 `m_i=μ(C_i)`，`0<ε<1`，

\[
 e(x)=\frac{\mu(Q(x,L_x)\setminus C_i)}{\lambda L_x^n},
 \quad B_{\rm bad}=\{e>\varepsilon\},\quad G_i=B_i\setminus B_{\rm bad},
\]

\[
 S=\sum_i\int_{B_i} L_x^{-n}\mu(Q(x,L_x)\setminus C_i)\,dx.
\tag{10}
\]

则

\[
 \lambda|B_{\rm bad}|\le S/\varepsilon.
\tag{11}
\]

若 `G_i` 非零测，则 `m_i>0`。在好行上定义同一正计划

\[
 a_x(y)=\frac{\lambda}{m_i}\mathbf1_{C_i}(y),\qquad
 c(y)=\sum_i\frac{\lambda|G_i|}{m_i}\mathbf1_{C_i}(y).
\tag{12}
\]

每好行的质量为 `λ`，来源列正是 `c(y)`；此计划对所有接收子割同时有效。若真实全块列满足 `c<=C` 几乎处处，则

\[
 \lambda|B|\le CW+S/\varepsilon.
\tag{13}
\]

**证明。** `λe=L_x^{-n}μ(Q_x\setminus C_i)`，积分并用 `e>ε` 即 (11)。好行上 `m_i=λL_x^n(1-e)>= (1−ε)λL_x^n>0`。行质量及列式用 Tonelli 直接计算；积分列得 `λΣ|G_i|<=CW`，加 (11) 得 (13)。没有构造最优计划，没有使用新来源或新门。

**真实立方体给的核心。** 若 `B_i⊂Q(c_i,d_i)`，`L_x∈[ℓ_i,u_i]` 且 `ℓ_i>0`，可取

\[
 C_i=Q(c_i,(\ell_i-d_i)_+).
\tag{14}
\]

零边长的核心作为零 `μ` 质量处理。逐坐标三角不等式证明核心包含；同时 `Q_x⊂Q(c_i,u_i+d_i)`。因此一个安全但可能粗糙的可计算上界是

\[
 S\le\sum_i |B_i|\ell_i^{-n}
 \mu\bigl(Q(c_i,u_i+d_i)\setminus C_i\bigr).
\tag{15}
\]

正核心体积不保证正来源质量；(10) 的实际质量损失才是判据。若 (15) 大而 (10) 小，应保留 (10)。

**尺度费用是该路线的现有障碍。** 相对接收宽度和尺度窗口为 `δ` 时，核心体积比大致包含 `(1−O(δ))^n`；即使均匀来源也常需 `δ=O(1/n)` 才保持固定比例质量。源可集中在边缘，所以这不提供任意来源的统一质量保持。区间 `[1,2]` 以此宽度离散有 `O(n)` 层。空间块数本身不必相加收费，因为接收块不交，但每层单独估来源列再求和会重现 `O(n)`。必须直接计算 (12) 跨**所有**层的同一列，允许同一点同时收到各层费用；没有额外“尺度独立”免费因子。

该路线可作为近簇几何验证器：核心/壳揭示小块化是否真保住来源、哪些接收点因此失效。但在证明 `C+S/(εW)=√n n^{o(1)}` 之前，不能取代主路线。若先删 `B_bad` 后再另算该集合的新来源阈值，需完整新门及原阈值比重；本式没有授权这样的免费重启。

原 F2 外账一项不删：

\[
 \lambda|E_{\rm initial}|
 \le[A_{\rm old}+C_{\rm ext}+\sqrt n+2\lceil\sqrt n\rceil]W
      +\lambda|F_2|,
\]

其中 `A_old,C_ext` 保留 R101 adaptive §7 的完整定义及维数费用；所有尺度返回 `O(log(n+2))` 与若另用的强度分层 `O(log n)`、真实重叠费照旧。如果对 `F2` 用 (13)，只可代入 `[C+S/(εW)]W`；没有证明它为根阶。

## 6. 下一轮先验协议与停止条件

优先以 `η=1`、`q∈{1,n}` 两个冻结选项，输出同一源、同一帽的 `E_near`、`E_far`、真实总 `E`、帽体积及带严格余项的认证区间；检验 `near+far=E` 和 (5)。无需再用大菜单证明已解析支付的远项。

三阶段应分别核对：已知合资格几何上的恒等式与帽费用；会破坏共享接收集的相互作用（源簇位置/相对尺度改变）；只有机制通过后扩大几何范围。新数值由 protocol 角色给完整合同后执行。源混合标签必须在全部坐标共用，不能改成边缘乘积。能量路线只需真实 `f,κ,U,dx` 资格；若测试原 F2，则另核原最早尺度和全部原门，不能互相借资格。

远项截断用 (7)，大尺度由总质量精确杀掉；近项尾需独立上证书。来源簇余项、接收窗口外部、尺度 UNKNOWN 都需单独记账。预算或精度不足时保留 UNKNOWN，禁止用连续采样量称严格体积证书。

## sol geometry

## 1. 对象、量词及三种不能互换的交叠

以下所有恒等式适用于任意维数 n≥1、任意非负 f∈L1(R^n)、有限质量 W=∫f，以及任意可测真实接收帽 U；不要求来源为径向、乘积、有限原子或某一测试族。W=0 平凡。使用全边长

\[
Q(y,L)=y+[-L/2,L/2]^n,\quad A_L f(x)=L^{-n}\int_{Q(x,L)}f(y)dy,
\quad d\nu(x,L)=dx\,dL/L,
\quad D_L=(A_Lf-\kappa)_+ . \tag{1}
\]

接收集 R=U^c 始终不变。非负积分可取 +∞。对 L>0，A_Lf≤W/L^n 有限。定义

\[
h_f(x,L)=\begin{cases}(1-\kappa/A_Lf(x))_+,&A_Lf(x)>0,\\0,&A_Lf(x)=0.\end{cases}\qquad D_L=h_f A_Lf. \tag{2}
\]

此处 h 保留实际来源、实际阈值和原始平均；不得换成一个与来源独立的坐标乘积门。

必须区分：

* **双来源、单接收体积**：Q(y,L)∩Q(z,S) 是那些能同时捕获 y,z 的真实接收点 x 的集合，其体积使用 dx。
* **双接收、共同来源质量**：对原 earliest selector Q_x,Q_{x'}，μ(Q_x∩Q_{x'}) 是共同捕获来源质量，使用 dμ=fdy；它不是前项的 Lebesgue 体积。
* **多个帽的实际并集体积**：|∪U_j| 使用 dx；ΣA_jW_j/τ_j 是由局部质量证书得到的上界账，不是并集的恒等式。

R101 adaptive 的精确共同列公式在原捕获图上为

\[
\int b_B(y)^2d\mu(y)
=\iint_{B\times B}\frac{\mu(Q_x\cap Q_{x'})}{L_x^nL_{x'}^n}\,dx\,dx'. \tag{3}
\]

这保留了共同来源，但不能以 unweighted |Q_x∩Q_{x'}| 取代任意来源 μ。反向 Tonelli 变换能够改变积分顺序，不能改变积分测度或删掉阈值门。

## 2. 带原阈值门的双来源接收核：相对位移与尺度比全部显式

**P-R102（全来源精确几何恒等式）**。任意 y,z∈R^n，L,S>0，置

\[
t=\max(L,S),\quad r=\min(L,S),\quad \rho=r/t,\quad
\delta_i=|y_i-z_i|,\quad
\nu_i=\frac{(\delta_i-(t-r)/2)_+}{r},\quad
\ell_i=(1-\nu_i)_+. \tag{4}
\]

令 I=Q(y,L)∩Q(z,S)。直接一维区间交叠给出

\[
|I|=r^n\prod_{i=1}^n\ell_i. \tag{5}
\]

解释其全部范围：若 δ_i≤(t-r)/2，小区间在大区间内，该坐标交叠为 r；若 (t-r)/2<δ_i<(t+r)/2，交叠为 (t+r)/2−δ_i；否则交叠为零。故 (5) 同时涵盖包含、部分交叠和分离，不把两个边长都当成 t。

任意可测 0≤g(x,L)≤1（可取 g=h_f），定义真实接受率

\[
\omega_{R,g}(y,z;L,S)
=\begin{cases}
|I|^{-1}\int_{R\cap I}g(x,L)g(x,S)dx,&|I|>0,\\
0,&|I|=0.
\end{cases} \tag{6}
\]

则 0≤ω≤1 且

\[
\frac{1}{L^nS^n}\int_{R\cap I}g(x,L)g(x,S)dx
=t^{-n}\Big(\prod_i\ell_i\Big)\omega_{R,g}(y,z;L,S). \tag{7}
\]

这就是保留 R、实际阈值门和全部坐标交叠的确切结构：**乘积几何因子乘以联合接受率**。一般来源下 ω 没有坐标乘积分解。这里没有把 ω 抹掉后再宣称保留了原门。

已证、无需支付整个来源 bounding box 的衰减为

\[
\prod_i\ell_i\le \exp\Big(-\sum_i\nu_i\Big),\qquad
 t^{-n}=\rho^{n/2}(LS)^{-n/2}. \tag{8}
\]

第一式在有零交叠时也成立，否则使用 1-u≤e^{-u}。第二式是恒等式。相对于两个**未遮罩立方体核**的原始 L2 范数乘积，尺度比贡献 ρ^{n/2}；相对位移贡献 exp[−Σ(δ_i−(t-r)/2)_+/r]。允许把这些因子直接留在来源对积分中，不必先删除整块外接盒。

两个重要限制：

1. ρ^{n/2} 相对于原始 L2 范数；不能直接宣称它控制“由 R 和 h 截断后的两个实际范数”之比。门可把两个函数都截在同一很小区域，截断后归一化相关性可为 1。
2. t-r 大时，包含区内 ν_i=0，故没有相对位移衰减；这是实际几何，不能补造 exp(−Σδ_i/r)。

**证明和回接**。中心立方体对称性给 1_{Q(x,L)}(y)=1_{Q(y,L)}(x)。对任意两个非负 L1 来源 f_i,f_j 和任意 g∈[0,1]，Tonelli 给

\[
\int_R g(x,L)g(x,S)A_Lf_i(x)A_Sf_j(x)dx
=\iint f_i(y)f_j(z)\,
\frac{\int_{R\cap Q(y,L)\cap Q(z,S)}g(x,L)g(x,S)dx}{L^nS^n}dy\,dz. \tag{9}
\]

将 (5)–(7) 代入即可。在同尺度 L=S 时，几何因子明确为

\[
 L^{-n}\prod_i\left(1-\frac{|y_i-z_i|}{L}\right)_+,
\quad \prod_i\left(1-\frac{|y_i-z_i|}{L}\right)_+
\le e^{-\|y-z\|_1/L}. \tag{10}
\]

再取 i=j=f、g=h_f、S=L，得到真正一般、所有尺度且不先线性汇总的实际能量表示

\[
\mathcal E_\kappa(f;U)
=\iint f(y)f(z)\,\mathsf T_{U,f,\kappa}(y,z)dy\,dz, \tag{11}
\]

\[
\mathsf T_{U,f,\kappa}(y,z)
=\int_0^\infty L^{-n}
\prod_i\left(1-\frac{|y_i-z_i|}{L}\right)_+
\omega_{U^c,h_f}(y,z;L,L)\,\frac{dL}{L}. \tag{12}
\]

注意 ω 是 h_f² 的接收交集平均，(12) 没有把正超额改成无阈值二次平均。任意 L1 也有 (11)–(12) 的扩展非负恒等式；有限能量不由此自动成立。

## 3. 可直接使用的尾部积分及其不能支付的部分

**Q-R102（精确无门尾部上界）**。取任意 ℓ>0，d_i=|y_i−z_i|，b=max(ℓ,max_i d_i)>0，e_k(d) 为 d_1,…,d_n 的 k 阶基本对称多项式，e_0=1。置

\[
\mathsf K_\ell(d)=\int_\ell^\infty L^{-n}\prod_i(1-d_i/L)_+\,\frac{dL}{L}.
\]

则

\[
\mathsf K_\ell(d)
=\sum_{k=0}^n\frac{(-1)^k e_k(d)}{(n+k)b^{n+k}}
\le\frac1{n b^n}. \tag{13}
\]

证明：L<max_i d_i 时乘积为零；L≥b 时展开 ∏(1-d_i/L)，有限项逐项积分。上界只用乘积≤1。交界点 L=b 不影响 dL/L 积分。交错多项式是一个非负积分的**精确公式**，不能以截断交错项当作未经认证的数值上界。

因此对任意实际帽 U，保留原门后有

\[
\mathcal E_{\kappa,L\ge\ell}(f;U)
\le\iint f(y)f(z)\mathsf K_\ell(y-z)dy\,dz
\le\frac{W^2}{n\ell^n}. \tag{14}
\]

若要计入帽返回 B κ W，粗尾部费为 B_tail=W/(nκℓ^n)。无需删整块 bounding box；可先计算实际来源对的 K_ℓ 更小值。L≥(W/κ)^{1/n} 的真实超额本来为零，故可将 (12) 的积分截到这个质量截止；这是阈值的实际效果，不能与无门尾部的无限尺度混计。

这里仍未支付 0<L<ℓ 的部分。令 ℓ→0 时粗界发散。若 f∈L1∩L2，未遮罩的 ∫_0^1∫(A_Lf)^2 dx dL/L 在 f 非零时发散；实际帽和阈值门正是不能丢掉的结构。一个已付尾部不是全尺度预算。

F05 的两侧 Schur 条件必须在实际 μ⊗尺度空间上另外验证。仅由 ρ^{n/2} 可得 log-scale 裸因子行和 4/n，但同时还有 (LS)^{-n/2}、来源对密度和 ω，不能直接把 4/n 当成实际核的统一能量常数。G01 同样需要实际节点/帐篷的全部 packing 桥梁；盒交叠公式不提供该桥梁。

## 3A. 策略模块的已付远场与近来源对的精确空间范围

Far 证明与统一选择由 astra_strategy.md（本报告相应模块） 负责，本角色不重复著作该证明。本角色独立核对其 cutoff 的正部代数与本文 overlap 因子的连接，独审已给 statement-only PASS；全文证明回执按策略模块记录。

其接口为 W>0、η>0、q≥1，在 u=κL^n/W<1 时令 s=log(1/u)，

\[
t_{\eta,q}(u)=[s+(1+\eta)\log(1+s)-\log q]_+,
\quad \mathsf{Far}=\{(y,z):\|y-z\|_1/L>t_{\eta,q}(u)\}. \tag{14a}
\]

u≥1 的实际 h=0。按 (12) 的实际 pair/scale masks 得 E=E_near+E_far，保持同一个 U、f、κ。策略模块给出的 far 预算为

\[
\mathcal E_{\rm far}\le\frac{q\kappa W}{n\eta}. \tag{14b}
\]

与本文几何的精确连接是 e^{-t_{η,q}}≤q e^{-s}(1+s)^{-1-η}；因此 Far 上可直接利用 (10)，无需删除 bounding box。q=n、η=1 只付 B_far≤1，剩余 Near 对与帽体积仍未付。该不等式的证明归策略模块，不把本角色的独立代数核对重复计为另一项研究进展。

**N-R102（近来源对的精确空间范围）**。对 q≥1，唯一 s0≥0 满足

\[
s_0+(1+\eta)\log(1+s_0)=\log q. \tag{14c}
\]

存在唯一性来自左边连续、严格递增、从零到∞。当 0≤s≤s0 时 cutoff t=0，Near 仅有 y=z；μ=fdy 无原子，μ⊗μ 的对角线质量为零（Tonelli 给 ∫μ({y})dμ(y)=0）。所以真实 Near 只剩

\[
L<(W/\kappa)^{1/n}e^{-s_0/n}. \tag{14d}
\]

此外 (10) 的非零交叠要求各 |y_i−z_i|<L。对 fixed L,u<1,t=t_{η,q}(u)，Near 的有贡献位移集合精确为

\[
z-y\in L\,\mathcal C_n(t),\qquad
\mathcal C_n(t)=[-1,1]^n\cap\{v:\|v\|_1\le t\}, \tag{14e}
\]

仅边界零集不影响上述 volume。其真实 Lebesgue 体积为

\[
|L\mathcal C_n(t)|=L^nF_n(t),\qquad
F_n(t)=\begin{cases}
\displaystyle \frac{2^n}{n!}\sum_{k=0}^n(-1)^k\binom nk(t-k)_+^n,&0\le t\le n,\\
2^n,&t\ge n.
\end{cases} \tag{14f}
\]

证明：除坐标零集外分 2^n 个正交象限；正象限是 [0,1]^n 中 Σv_i≤t。未截 simplex 体积 t^n/n!。用 inclusion-exclusion 排除 v_i>1：指定 k 个这样的坐标后平移各一，所得 simplex 体积 (t−k)_+^n/n!；对所有 k 求和。t≥n 时整个单位正盒均包含。这是任意 n 的精确几何，而不是用一张有限维网格代替 continuum 接收。

(14f) **不控制任意来源质量**。对 fixed L,t>0，可以把全部来源质量放进一个足够小的真实连续来源盒，使所有来源对的位移都在 L·C_n(t)，且 overlap product 趋近 1；没有 universal “lens Lebesgue volume 小 ⇒ μ-pair mass 小”。若另给 ||f||∞ 上界，它也带来实际幅度费用且尚不控制原帽接受率。本例没有要求 R 为此来源的实际障碍帽补集，故只阻断几何体积转任意来源质量的放松，不能反驳 genuine-cap 联合接受估计。

真正剩余是 Near 上的 (12) joint ω：相同尺度的接收交集、来源质量与帽补集必须联合支付。t≥n 时 Near 条件覆盖所有非零交叠，几何 lens 不再给稀疏；很小尺度 s 足够大必进入此范围。t=0 区间已由策略模块 Far 支付；不能因一个较大尺度窗口可付就漏计短尺度 Near。

## 4. 层间合并无需先丢掉阈值亏量：精确非线性树恒等式

**T-R102（任意有限分解、任意有限二叉树）**。取任意有限非负 L1 分解 f=Σ_{j=1}^m f_j，正阈值 τ_j 且 Στ_j=κ。取任意以这些分量为叶的二叉树。节点 C 代表其后代叶，定义

\[
f_C=\sum_{j\in C}f_j,\quad \tau_C=\sum_{j\in C}\tau_j,\quad
r_C=(A_Lf_C-\tau_C)_+,\quad d_C=(\tau_C-A_Lf_C)_+ . \tag{15}
\]

在每一个真实接收/尺度点，内部节点 C=A∪B 置

\[
s_C=r_A+r_B,\quad q_C=\min(s_C,d_A+d_B),\quad
\gamma_C=2s_Cq_C-q_C^2\ge0. \tag{16}
\]

因为 A_Lf_C−τ_C=r_A+r_B−d_A−d_B，所以 r_C=s_C−q_C，精确得到

\[
r_C^2+\gamma_C=r_A^2+r_B^2+2r_A r_B. \tag{17}
\]

在有限树中先逐点望远镜，再对**同一个** R×(0,∞) 积分，得到

\[
\mathcal E_\kappa(f;U)+\sum_{C\text{ internal}}\int_{R\times(0,\infty)}\gamma_Cd\nu
=\sum_j\mathcal E_{\tau_j}(f_j;U)
+2\sum_{C=A\cup B}\int_{R\times(0,\infty)}r_A r_Bd\nu. \tag{18}
\]

所有项非负；此式是扩展非负等式，不作 ∞−∞。如果要把左侧亏量移到右侧作净预算，必须先有相应有限性。

每个 cross_C 也有保留阈值的实际接收交叠层积

\[
\int_{R\times(0,\infty)}r_A r_Bd\nu
=\int_0^\infty\int_{\tau_A}^\infty\int_{\tau_B}^\infty
|R\cap\{A_Lf_A>u\}\cap\{A_Lf_B>v\}|\,dv\,du\,\frac{dL}{L}. \tag{19}
\]

使用 layer cake 和 Tonelli 证明，不要求超水平集为盒或乘积。聚合节点的捕获不是原分量的独立事件；(19) 保留了真实共同接收点。改用 \((\sum_jr_j)^2\) 时丢掉的正是 (18) 的全部 γ_C；再用 weighted Cauchy 丢掉的是实际 cross_C 的位置、尺度、阈值支持结构。两个损失不同。

(18) 可以改变树的分组以显式展示哪些 cross 与亏量抵消，但不是声称能量因换树而变：左端实际根能量相同，cross 与 γ 的各自和可能改变。有限树身份对每个任意原始 f 有效，因而是一般精确工具；它仍不提供无代价的无限树极限、最优树或子幂净 cross 预算。

## 5. 不满足全局阈值打包时，实际低于局部门的共同捕获必须另付

任意 countable f=Σf_j，ΣW_j=W<∞，任意 τ_j>0（不要求 Στ_j<∞），定义

\[
r_j=(A_Lf_j-\tau_j)_+,\quad S=\sum_jr_j,\quad
T=\sum_j\min(A_Lf_j,\tau_j),\quad Z=(T-\kappa)_+. \tag{20}
\]

由于每项有 A_Lf_j=r_j+min(A_Lf_j,τ_j)，Tonelli 和 A_Lf<∞ 给 S+T=A_Lf。故

\[
D_L=(S+T-\kappa)_+\le S+Z.
\]

对固定真实 U，令

\[
G_{ij}=\int_{R\times(0,\infty)}r_i r_jd\nu,\qquad
I=\int_{R\times(0,\infty)}Z^2d\nu .
\]

则

\[
\mathcal E_\kappa(f;U)\le\left(\sqrt{\sum_{i,j}G_{ij}}+\sqrt I\right)^2. \tag{21}
\]

若两边子项有限，Minkowski 给证明；若 ΣG 或 I 无限，右边无限，结论是扩展平凡上界。G 的精确 receiver layercake 为 (19) 的分量版本。ΣG 通过 Tonelli 恰等于 ∫S²。

重要：I 是所有来源“各自未过局部阈值”的部分共同越过全局阈值的实际能量；它不是可从局部 G_{jj} 控制的余项。Στ_j≤κ 时 T≤κ，I=0；否则不能只凭来源支撑互不交或帽互不交删掉 I。

## 6. 能检查但粗糙的接收影子 fallback，不作主机制

此段应作为失败或基准诊断；主机制是 (12)、(18) 的实际带门几何。

若 f_j 支撑在有限闭轴盒 B_j，W_j=∫f_j>0，令 R_j=(W_j/τ_j)^{1/n}、P_j=B_j+[-R_j/2,R_j/2]^n。若 r_j(x,L)>0，则由质量上界得 L<R_j；由真实支撑捕获得 x∈P_j。对整数 q≥1，令 m(x)=Σ1_{P_j}(x)、V_q={m>q}。在帽 U⊃V_q 外，同时 r_j>0 的数≤q，所以

\[
\int_{U^c\times(0,\infty)}S^2d\nu\le q\sum_j\mathcal E_{\tau_j}(f_j;U). \tag{22}
\]

若 q=0，单独定义 V_0={m>0}。在帽 U⊃V_0 外没有任何正 r_j，因此 S=0，保留区上的 ∫S²dν=0；这个结论直接由支撑得到，不代入 (22) 的系数，亦不写 0·∞。

有限盒的 |V_q| 可用所有坐标端点分格，在每个开 cell 上计 m 再加实际 cell 体积，边界零；countable 情形用 m_N↑m 与 V_{q,N}↑V_q 的单调体积极限。粗界 (q+1)|V_q|≤Σ|P_j|。大外接盒、细支撑或大量分量会使其很贵。

若 Στ_j=κ、局部帽在各自**原阈值** τ_j 的证书为

\[
|U_j|\le A_jW_j/\tau_j,\qquad
\mathcal E_{\tau_j}(f_j;U_j)\le B_j\tau_jW_j,
\]

取整数 q≥1 与真实 U=V_q∪∪U_j 时只得到

\[
 A_{\rm actual}=\frac{\kappa|V_q\cup\bigcup_jU_j|}{W}
\le\frac{\kappa|V_q|}{W}+\sum_j\frac{A_jW_j\kappa}{\tau_jW},
\qquad B\le q\sum_jB_j\frac{\tau_jW_j}{\kappa W}. \tag{23}
\]

若 q=0 且 Στ_j=κ，则 S=0 又 T≤κ，故实际 Eκ(f;U)=0，直接取 B=0；帽体积仍按实际 U 付费，不以 (23) 的乘积推导。

(23) 可验证却重新汇总为线性重叠数，故不是本轮新主策略。保留原 source/阈值，不意味着费用小；以 τ_j 替代曾在 κ 下认证的旧证书需要新的证书。

## 7. 实际 receiver union、重复来源收费与全局回代

对有限或 countable 可测局部帽 U_j，N(x)=Σ1_{U_j}(x)，有真正并集体积恒等式

\[
|\bigcup_jU_j|=\int 1_{\{N>0\}}dx,
\quad\sum_j|U_j|=\int Ndx,
\quad\sum_j|U_j|=|\bigcup_jU_j|+\int(N-1)_+dx \tag{24}
\]

最后式为非负恒等式，避免无限减无限，始终成立。有限 N 时亦可将每帽以 1/N 分摊；无限 N 处不能把每项 0 相加误作并集计费。并集折扣与來源质量 W_j 的重复使用是不同账。

(18) 的树阈值条件使每片叶的帽费用是 A_jW_j/τ_j；真实交叠能降低 actual union，却不能由质量账自动获得这个折扣。全局帽返回使用实际 dimension-only 一致常数

\[
|U|\le A_nW/\kappa,\qquad\mathcal E_\kappa(f;U)\le B_n\kappa W,
\quad C_n\le4A_n+8\sqrt{nA_nB_n/\log2}. \tag{25}
\]

因此成功要同时找到每个 f、每个 κ 都合法的 U 与实际几何预算，使 A_n,B_n=n^{o(1)}。精确改写 (11)、(18) 或较小来源依赖费用，不满足这个一致量词。原 F2 分支的 A_old、C_ext、unit/mesh、强度层与全尺度费用仍按 R101 ledger/adaptive 完整保留；本稿没有替换其原图或证明 Hall 根容量。

## 8. 已证工具、实际放松损失与明确阻断

已证工具：一维区间交叠及其 n 维乘积；中心立方体对称捕获；非负 Tonelli；原始 L2 归一化下的尺度比因子；任意 ℓ>0 的精确尾部核；实际正超额/亏量树望远镜；实际 receiver 超水平集 layercake；真实 union 恒等式。本角色拥有的主要证明在本文内给出，不依赖未核外部定理；Far 预算按明示归属引用策略模块。

明确阻断：

* 把 (12) 的 ω 取 1 丢掉帽与阈值的联合接受关系；这是所有后续短尺度发散与 raw-cap 压力所针对的放松。
* 把乘积几何因子取 1 丢掉位移/尺度衰减；这些因子本身可直接积分使用，但尚无原来源上的统一 source-pair 行列预算。
* 对任意来源没有“门在各坐标独立”的原则；共享 mixture 标签、任意来源关联及任意帽形状均可破坏这种分解。
* (18) 丢 γ 后再线性 Cauchy 汇总，先丢亏量抵消再丢 actual cross geometry；逆向猜测强混合矩或谱隙不能恢复已丢信息。
* bounding-box shadow 付费没有隐含子幂体积；(22)–(23) 仅是可验证 fallback。

成功判据：原来源对核 (12) 的 gate acceptance 与真实帽体积能联合支付；或 (18) 中实际跨项减亏量可在同一 receiver union 与原阈值下支付，连同局部 inverse-threshold 费用成为维数一致的子幂证书。失败判据：仅给出未知核的新名字、有限测试、未付的 ∫ω 减小假设、未付的全尺度小块数量、或把 coarse multiplicity q 默认为子幂。当前没有达到成功判据。

## sol allocation

## 1. 对象、原资格及迭代盲点

令 \(\mu=fdy\ge0\)，\(W=\mu(\mathbb R^n)<\infty\)，\(\lambda>0\)，\(B\subset F_2\) 为可测实际 Lebesgue 接收割，\(D=\lambda|B|<\infty\)。原最早接触立方体 \(Q_x=Q(x,L_x)\) 满足 \(1\le L_x\le2\)、\(\mu(Q_x)=\lambda L_x^n\)。定义
\[
k_x(y)=L_x^{-n}\mathbf1_{Q_x}(y),\qquad
b_0(y)=\int_Bk_x(y)dx\le H_n=1+n\log2. \tag{1}
\]

原 F2 保留同一个 f、λ、selector 及 anchor、连续全窗 P1、原 selected-coarse、captured-middle、全部 shift 的 packet/physical 门，以及已付 unit/mesh 删除。具体仍有
\[
A_1f<\lambda/\sqrt n,\quad A_{r_j}f<\lambda/2\ (r_j\le L_x),\quad
\pi_{0,x}(Q_x\setminus Q(x,r_-(x)))>1/2, \tag{2}
\]
其中 \(r_j=2^{j/N},N=\lceil\sqrt n\rceil\)，原单位严格 anchor 处理前驱零。原 \(\pi_{0,x}=k_x\mu/\lambda\) 同时满足 \(E_{\pi_0}\Phi_1>b_n\)、\(E_{\pi_0}\Phi_\theta<\alpha\)；不能用 whole-window coarse 代換。壳质量不自动保持有效 tilted 质量，原 score deficit 可非正。

给定任意可测原图可行计划 a≥0：每行对 μ 的质量为 λ，原图外为零，列 \(b(y)=\int_Ba_x(y)dx\le H<\infty\)。令 \(E=\int b^2d\mu\)。可取 canonical 初始化及 H=Hn。零 D 或 W 无迁移需求；下文非平凡情形均取 D,W>0。

R101 的 \(V=\lambda\int_B\operatorname{Var}_{a_x\mu/\lambda}(b)dx\) 只看**当前**后验，不测量原图上存在但被压小的替代来源边。原门约束 π0，不能直接转给当前后验；V 小不证明列小、全图 KKT 或最优容量。本文保留原行捕获低负担来源的实际比例和迁移后的实际接收列，可激活当前 a 为零的原边。

## 2. 单储备：显式高列到低列刷新

取 \(0\le v<u\le H\)、\(0<p\le1\)，令
\[
S_+=\{b\ge u\},\quad S_-=\{b\le v\},\quad
h_x=\lambda^{-1}\int_{S_+}a_xd\mu,\quad
p_x=\lambda^{-1}\int_{S_-}k_xd\mu,\quad A=\{x\in B:p_x\ge p\}. \tag{3}
\]
可测性由 Tonelli；h,p_x∈[0,1]。列集合按 μ-a.e. 代表定义。除 A 外不计算 1/p_x，相应项置零。定义
\[
c(y)=\mathbf1_{S_+}(y)\int_Aa_x(y)dx,\quad
\ell(y)=\mathbf1_{S_-}(y)\int_A\frac{h_xk_x(y)}{p_x}dx,\quad
M=\lambda\int_Ah_xdx. \tag{4}
\]
有 \(\int c d\mu=\int\ell d\mu=M\)、0≤c≤b≤H，且实际迁移列
\[
J=\mu\text{-}\operatorname{ess\,sup}\ell\le H_n/p. \tag{5}
\]
J 是本次 A、当前 h、原 selector、当前低来源集的联合量；右端只是丢几何的后备。M=0 时直接不更新；M>0 时 J>0。对
\[
0<\varepsilon\le\min\{1,(u-v)/(H+J)\},\qquad
 a_x^+=a_x-\varepsilon\mathbf1_A(x)a_x\mathbf1_{S_+}
 +\varepsilon\mathbf1_A(x)h_x\frac{k_x\mathbf1_{S_-}}{p_x}, \tag{6}
\]
所得计划同源、同 λ、同原图，且
\[
0\le b^+\le H,\qquad E^+\le E-\varepsilon(u-v)M. \tag{7}
\]

证明：S+、S−不交，扣除最多为 a；新增非负、在原图内。每个 A 中行扣 ελh_x，加相同质量。列为 b+=b−εc+εℓ；高列不增且非负，低列至多 v+εJ≤u≤H，其余不变。准确能量差是
\[
E^+-E=-2\varepsilon\int bc d\mu+2\varepsilon\int b\ell d\mu
+\varepsilon^2\bigl(\int c^2d\mu+\int\ell^2d\mu\bigr). \tag{8}
\]
前两项≤−2ε(u−v)M；平方项≤ε²(H+J)M，得 (7)。没有后验独立、当前门继承、comparator 或优化器存在假设。

失败判据：A 中无当前高需求即 M=0；或 p 很小使后备 Hn/p 昂贵；或实际 J 很大使已证迁移慢。这些只说明**本储备、本阈值、本步**效率差。未筛完其他储备及中继路径时，不能写为最优 Hall 容量下界。

## 3. 双边局部化与真实 receiver-column

取有限或可数可测来源储备 \(S_i\subset S_-\)，可测接收集 \(B_i\subset B\)，可测权重 \(\theta_i(x)\ge0\)，令
\[
\tau(x)=\sum_i\theta_i(x)\le1,\qquad
p_i(x)=\lambda^{-1}\int_{S_i}k_xd\mu. \tag{9}
\]
要求 θ_i 在 B_i 外及 p_i<p_{i,0} 处为零，每个 p_{i,0}>0 是**实际核验**下界。仅在 θ_i≠0 处除 p_i，其余置零。B_i 可重叠；权重总和限制阻止重复计算整行。

定义
\[
c=\mathbf1_{S_+}\int_B\tau(x)a_xdx,\quad
\ell_i(y)=\mathbf1_{S_i}(y)\int_{B_i}\frac{h_x\theta_i(x)k_x(y)}{p_i(x)}dx,
\quad\ell=\sum_i\ell_i,\quad M=\lambda\int_Bh_x\tau(x)dx. \tag{10}
\]
若合并的 \(J=\mu\text{-}\operatorname{ess\,sup}\ell<\infty\)，则按同样步长取
\[
a_x^+=a_x-\varepsilon\tau(x)a_x\mathbf1_{S_+}
+\varepsilon h_x\sum_i\theta_i(x)\frac{k_x\mathbf1_{S_i}}{p_i(x)} \tag{11}
\]
仍有 (7)，M=0 时不更新。逐行用 Σθ=τ 证明行质量；非负 Tonelli 证明来源列及两端总迁移质量都是 M。τ≤1 给 c≤b；所有 Si 在同一低集合，使 (8) 适用于**合并后**的 ℓ，不能免费分开各 Ji。

可直接核验的几何支付为
\[
C_i=\mu\text{-}\operatorname{ess\,sup}_{y\in S_i}
\int_{B_i}L_x^{-n}\mathbf1_{Q_x}(y)dx,
\quad \ell_i\le\mathbf1_{S_i}C_i/p_{i,0},
\quad J\le\mu\text{-}\operatorname{ess\,sup}_y\sum_i\mathbf1_{S_i}(y)C_i/p_{i,0}. \tag{12}
\]
μ(S_i)=0 时置 Ci=0（此储备不能承接正权重）。Si 在来源侧 μ-a.e. 不交时 J≤sup_i Ci/p_{i,0}；若实际来源重叠度≤r，则 J≤r sup_i Ci/p_{i,0}。r 未证时不能省略。面数、packet 数、储备数都不能免费求和，必须经过实际 source overlap。保留 hθ/p_i 的精确列还能改进 J。

Ci 保留来源 y 所见的局部 receiver 集、原尺度及真实捕获；常尺度 Lx=L 于 Bi 时，由中心立方体对称关系，
\[
\int_{B_i}k_x(y)dx=L^{-n}|B_i\cap Q(y,L)|\quad(y\in S_i). \tag{13}
\]
这是实际 Lebesgue 接收体积。变尺度时只保留 (12) 的原 selector 积分；使用全空间无约束 scale envelope 重新回到 Hn。任何子割 A⊂B 的完成计划都是这一套计划的限制，列自动不超过全 B 列；不能对子割独立造计划后省略相加费用。

一个无需额外假设的局部上界是 Ci≤|Bi|（因为原 Lx≥1）。若 Bi 上 Lx∈[r,R]，则
\[
C_i\le r^{-n}\mu\text{-}\operatorname{ess\,sup}_{y\in S_i}|B_i\cap Q(y,R)|. \tag{13a}
\]
进一步丢掉 Bi，使用整个 Q(y,R) 体积，代价为 (R/r)^n。原 N≈√n mesh 单带 R/r=2^(1/N)，这个代价为 2^(n/N)=exp(O(√n))，不是小误差。必须保留真实 Bi 交集、原权重 Lx^−n，或使用已证 Hn 后备；不能将 shell 宽度直接当成此粗化的根阶支付。若来源储备不交且每个实际 |Bi|/p_{i,0}≤C，则式(12)直接给 J≤C；这是一个具体几何证书的支付，未证明所有 F2 有此分解。

这个步骤需要具体储备、权重、p 下界、Ci 和 J，提供可核验的重分配，不以好 comparator 为前提。但目前没有从原 F2 门为全输入构造这些储备，也没证明这些费用具有根阶预算，故工具不是一般根阶进展。

## 4. 有限预算与直接终止条件

在同一 B、μ、λ、Qx 上重复，每步可根据 b 改变储备。这是分配变化，不是源限制、selector 重启或原门重分类。若各步按已证条件作 ε_j、δ_j=u_j−v_j、M_j 的更新，则
\[
\sum_{j<m}\varepsilon_j\delta_jM_j\le E_0-E_m,\qquad
E_m\ge D^2/\mu(N_B)\ge D^2/W,
\quad N_B=\{y:\int_B\mathbf1_{Q_x}(y)dx>0\}. \tag{14}
\]
N04 仅用于此有限望远镜及有限下终端。D>0 保证 μ(NB)>0，canonical E0≤HnD。下降可和不证明根阶列、极限计划或后验门继承。

任一有限步也可沿 R101 已证 reciprocal route：令 Rm(x)=λ^−1∫a_{m,x}(y)b_m(y)dμ，Tonelli 给 λ∫Rm dx=Em。在 Rm≤C 上付同一套列≤C+s 的计划时，剩余 demand 仍只有 λ|{Rm>C}|≤Em/C。不能把有限能量下降直接宣布为剩余 receiver 已付；这个余项与式(14)的能量下终端是两种不同账目。

下面是**可直接检查的充分成功测试，未证明 F2 满足**。固定 0≤v<u≤H、κ∈(0,1]、0≤J0<∞，在所需每一步构造储备并实际验证
\[
J_j\le J_0,\qquad c_j(y)\ge\kappa b_j(y)
\quad\mu\text{-a.e. on }\{b_j\ge u\}. \tag{15}
\]
后一条表示高来源负担中至少 κ 的当前 receiver 质量有原图低储备可去；b>0 时 c/b=E_{a_x(y)dx/b(y)}τ(x) 是其准确双边含义。它必须从真实高来源—接收—低来源关系支付，不能由存在 comparator 或小 V 推出。

取固定 0<ε≤min{1,(u−v)/(H+J0)}，令 q=1−εκ∈[0,1)，由 (11) 逐点得到
\[
\|b_m\|_{L^\infty(\mu)}\le\max\{u,q^mH\}. \tag{16}
\]
证明：当前高列≤qb；新增只到 b≤v 的低列且最终≤u；(v,u) 中列不变，逐步归纳。若 H=u 初始已完成；若 H>u 且 q=0 则单步足够。H>u、0<q<1 时 m≥ceil(log(H/u)/(−logq)) 给同一完成计划列≤u，对所有子割 λ|A|≤u μ(NA)。无需无限计划存在。迭代次数本身不乘弱型来源费用，因为始终是一套固定来源计划；独立拼接多套 receiver 计划仍付合并列。

只有**对每一个原 F2 有限 B**构造且核验 (15) 或别的完整终止预算，u=n^(1/2+o(1))，才有目标返回。当前覆盖、低捕获和实际 J 都未证；(15) 只是成功判据，不能写成已付谱隙或一般进展。有限成功数据不满足统一量词。

完整原账仍是
\[
\lambda|E_{initial}|\le[A_{old}+C_{ext}+\sqrt n+2\lceil\sqrt n\rceil]W
+\lambda|F_2|,\qquad C_{ext}=2H_n/\sqrt{n+2}. \tag{17}
\]
Aold 的 frozen 每项继承 R101 adaptive §7：base、旧极低、selected-coarse Tsoft/α、packet、physical union 一次。刷新不换源/阈值，故不追加这些分类费，也不消除末项需求。未闭合时保留 canonical HnW、R99 外壳 2n log2 W 后备。只支付部分 receiver 时剩余需求不能被 (14) 删除。optional 全窗 coarse/near-anchor 此处没用；若用再付 Tsoft/α、1+n log(1+1/√n)。全尺度返回 O(log(n+2))，另做强度分层仍有 Jn=O(log n) 和实际重叠。换 μ_i、λ_i 时重新核门、保留 t_i=λinitial/λ_i、Σt_i(√n+2ceil√n)Wi、分类费及 terminal；本文未做该递归。

## 5. 放松损失、保留量、边界

| 放松 | 丢失 | 保留量 | 未付项 |
|---|---|---|
| 当前后验方差 | 被压小原边的低来源可用性 | 原 k 捕获 pi(x) | 原 F2 是否产生足够低储备 |
| 全 receiver/全尺度包络 | 实际接收集与原 Lx | 精确 ℓ、Ci、式(13) | 所有输入的 Ci/pi 预算 |
| 储备独立求列后忽略相加 | 同 y 承接多迁移 | 合并 Σℓi、式(12) | source overlap r |
| source cell 用内块代替 | 边界来源截获 | 完整 Qx∩Si 的 μ 质量 | 任意 L1 可集中边界层，无免费删除；原 thin-shell 恰更危险 |
| 下降可和 | 高列最后 level、未完需求 | 式(14)和实际式(15) | 统一根阶终端 |

packet/entropy 不自动给 pi 下界：分散质量仍可落在很多高列来源，cell 小也不控制 source overlap。receiver 分片不交不保证 source 储备不交。原窄壳给同一行壳质量，不给高来源所见接收点的替代低储备覆盖 (15)。这些需由实际联合关系证明，不能重新线性汇总后靠强混合矩补救。

## luna losses

# 放松损失地图（R101 coverage / nonlinear maximal / adaptive）

范围：只盘点 R101 已写出的实际不等式，目标仍是对所有非负 \(L^1\) 输入、真实 Lebesgue 接收和全部尺度得到一致 \(n^{1/2+o(1)}\) 弱界。R101 没有证明该目标。以下“可逆”指能否仅凭已经记录的量恢复被丢弃的几何；不是说原不等式可以反向。PRIVATE 配方、构造参数和程序细节不在此公开。

## 决定性损失（8项）

### 1. 将尺度超额压为未来占用 \(J\)

**精确量 → 放松量。** 对 \(D_L(x)=(A_Lf(x)-\kappa)_+\)，精确接收能量为
\[
K(x)=\int_0^\infty D_L(x)^2\,\frac{dL}{L}.
\]
立方体嵌套给出未来尾关系 \(J_{\ge L}(x)\ge \frac{\kappa}{n}G(t)\)，其中 \(A_Lf=\kappa(1+t)\)、\(G(t)=t-\log(1+t)\)。链式积分后
\[
K(x)\le S(x):=\frac{\kappa^2}{n}\Phi\!\left(\frac{nJ(x)}{\kappa}\right),\quad
J(x)=\int_0^\infty D_L(x)\,\frac{dL}{L}.
\]
这是同一真实输入及真实尺度上的定理，使用未来尾 \(J_{\ge L}\) 后再积分；没有把各尺度当作独立变量。

**丢失几何与费用。** 从 \(K\) 只留下 \(J\) 的总量，忘掉超额在尺度轴上的具体位置、间隔和簇结构。公式中没有在原有 n 系数之外再乘一个常数；但把尺度分布压成总占用可能丢失大量真实尺度几何，且 K→J 上界转成可支付联合预算时仍可能带来很大的有效损失。n 的显式位置是 \(nJ/\kappa\) 与 \(\kappa^2/n\)；这不代表整体放松没有维数代价。要用它得到弱界，仍须同一删除集上的体积与 \(\int S\) 联合预算。单独的点态支配不产生任何接收体积界。

**可逆性 / 反例。** 仅给 \(J\) 一般不能重建 \(K\) 的尺度分布；若后续有真实保留集上的联合预算则此放松足够，不需逆推出尺度轨迹。R101 没有合资格反例推翻此不等式，也没有证明所需联合预算。

### 2. 用 \(J\)-高度集删除并以分位数选门槛

**精确量 → 放松量。** 对 \(T>0\)，同一个严格删除集 \(U_{J,T}=\Omega\cup\{x\in\Omega^c:J(x)>T\}\) 满足
\[
|U_{J,T}|\le 2W/\kappa+V_J(T),\quad
E_\kappa(f;U_{J,T})\le\frac{\kappa^2}{n}\int_{\Omega^c\cap\{J\le T\}}\Phi(nJ/\kappa)
\le \kappa\frac{\Phi(nT/\kappa)}{nT/\kappa}R_J(T).
\]
按 \(V_J(T)\le aW/\kappa\) 的最小可行分位数选 \(T\)，在严格高度帽类内同时最小化中间实际积分、实际保留能量及其递增上界。对一般 measurable 删除，有限正预算下的代理最优论证以存在一个有限保留成本的可行竞争者为前提；若每个可行删除后的保留成本都为无穷，则下确界也是无穷，不能得到付费结论。存在有限竞争者时，可按 nonatomic Lebesgue 测度在阈值 level set 上选 tie 子集，并把该子集的实际体积计入预算；由此 \(S\) 的删减问题有精确最优解。

**丢失几何与费用。** 受限高度帽只按单点 \(J(x)\) 排序，可能丢掉输入来源、接收点间相关性和连通簇信息；任意形状最优的实际 \(K\)-帽也未由此刻画。若 \(a_n,B_n\) 是对每个规则输入和每个 \(\kappa\) 一致成立的常数，返回式才是
\[
C_n\le4(2+a_n)+8\sqrt{n(2+a_n)B_n/\log2}.
\]
根号内的显式 \(n\) 因子不能略去；要达目标，联合预算系数需为次幂量级。单个输入上的有限 \(a,B\) 不够。

**可逆性 / 反例。** 分位数是严格高度类内可逆的精确优化，但不能推出全形状 cap 最优；SURROGATE 最优也不等于实际能量最优。尚无合资格反例否定全形状联合预算；尚无一般证明它。\(T=0,\infty\) 及 level tie 的边界情形须按原文分别处理，不能靠乘积 \(0\cdot\infty\) 处理。

### 3. 以显式混合幂替代反函数代价

**精确量 → 放松量。** 对 \(q=nJ/\kappa\)，R101 证明
\[
\max\{q^2/2,(2\sqrt2/3)q^{3/2}\}\le\Phi(q)
\le q^2+(2\sqrt2/3)q^{3/2}\le3\Phi(q).
\]
因此可用
\[
S_{pow}=nJ^2+(2\sqrt2/3)\sqrt{n\kappa}\,J^{3/2},\qquad S\le S_{pow}\le3S.
\]

**丢失几何与费用。** 只损失绝对因子 3，不额外损失维数幂；量纲/维数开销明确为 \(n\int J^2\) 与 \(\sqrt{n\kappa}\int J^{3/2}\)。真正缺口是同一付费接收集上的这两个**实际混合矩**及其尾部体积，而不是幂次不等式。

**可逆性 / 反例。** 上下比较可在固定体积预算的最优保留积分层面双向转换（常数 3），且两分数排序一致；不能从有限分区的估计恢复连续空间的一般预算。R101 未给出对此代理等价的反例，也没有矩预算定理。

### 4. 把分量和控制为逐点活跃阈值 packing

**精确量 → 放松量。** 记 \(W_j=\int f_j>0\)、\(W=\sum_jW_j<\infty\)、\(p_j=W_j/W\)，零质量分量略去。\(D_j\) 是接收/尺度空间中的可测 active mask，\(\mathcal D\) 是计算的 active 区域，\(V\) 是另付的接收删除集合；最终帽为 \(U=V\cup\bigcup_jU_j\)。取 \(0\le\eta<1\)、\(s=1-\eta\)。对 \(f=\sum_j f_j\)，若实际分量证书在阈值 \(\kappa\theta_j\) 成立，每个保留 active 行 \((x,L)\) 的活跃分量满足 \(\sum_{j\in I}\theta_j\le s\)，且非活跃残量 \(F=\sum_j\mathbf1_{D_j^c}A_Lf_j\le\eta\kappa\)，则
\[
(A_Lf-\kappa)_+^2\le s\sum_j\mathbf1_{D_j}(A_Lf_j-\kappa\theta_j)_+^2/\theta_j.
\]
积分后 cap 费为 \(A=\kappa|V|/W+\sum_j A_jp_j/\theta_j\)，能量费为 \(B=s\sum_jB_jp_j+D_0\)。这里 \(D_0\kappa W\) 是同一最终帽外、\(\mathcal D^c\) 上的实际正超额能量上界。软远场时，把 pointwise 残量条件换成同帽外、\(\mathcal D\) 上 \((F-\eta\kappa)_+^2\) 的能量上界 \(D_1\kappa W\)，得到 \(B=[(\sqrt{s\sum B_jp_j}+\sqrt{D_1})^2+D_0]\)。两项预算均须另行支付，不能从分量证书取得。

**丢失几何与费用。** 点态 packing 把实际的共同来源联系压成活跃数/阈值预算；\(F\) 必须另付 pointwise reserve 或真实保留能量。逐分量 cap 的并集只用次可加估计，重叠可能让上界过付，但不能把这笔账删掉。所有费用及最终 cap 均针对同一个输入、阈值和接收测度。

**可逆性 / 反例。** 若真实来源邻域 overlap \(q\) 已知、每个分量在 \(\kappa/q\) 有共同 \(A_0,B_0\) 证书，返回系数为 \(A=qA_0,B=B_0\)，再付 \(C_n\le4qA_0+8\sqrt{nqA_0B_0/\log2}\)。若有阈值 reserve (s)，cap 项额外有 (1/s)，不能从能量节省中抵消。R101 已核验的实际例证否定“分量零能量证书可无条件相加”这一步。它只打击该 gluing 放松，不构成一般弱型下界。

### 5. 用全局质量 cutoff 取代实际 overlap 几何

**精确量 → 放松量。** \(R=(W/\kappa)^{1/n}\)、\(\mathcal D=\{L<R\}\) 时，\(A_Lf\le W/L^n\le\kappa\) 对 \(L\ge R\)，故补区域 \(D_0=0\)。对同一全局 \(R\)，由来源支撑定义 mask；若每行实际支撑重叠数 \(q\) 有界，即可应用上项。

**丢失几何与费用。** cutoff 精确删去远尺度，却不压住 \(L<R\) 内簇的来源重叠；\(R\) 取决于总质量，不能为每个小分量各自缩小而不付 cross-source far field。重叠费用 \(q\) 留在 cap 及弱返回的根号中。

**可逆性 / 反例。** 给定分离条件可恢复 \(q=1\)，但这是额外空间假设。R101 已核验的实际例证表明，全局质量 cutoff 内仍可能有许多来源同时参与同一组见证尺度；因此“去掉大尺度即可让实际 overlap 小”不成立。该例不推出一般弱型反例，具体构造与修复留在内部记录。

### 6. 全局阈值分配引入质量分散账

**精确量 → 放松量。** 假设每个分量在所有正阈值 \(\sigma>0\) 都有实际证书 \(|U_{j,\sigma}|\le A_jW_j/\sigma\)、\(E_\sigma(f_j;U_{j,\sigma})\le B_j\sigma W_j\)，并且同一 \(A_j>0,B_j\) 在选择分配前对 \(\sigma\) 一致成立。全部来源每行活跃且 \(\sum_j\theta_j\le1\) 时，仅在 \(\sum_j\sqrt{A_jW_j}<\infty\) 的条件下取 \(\theta_j\propto\sqrt{A_jW_j}\)，得到
\[
|U|\le \kappa^{-1}(\sum_j\sqrt{A_jW_j})^2,\qquad
E_\kappa(f;U)\le\kappa\sum_jB_jW_j.
\]
这是通过分量证书得到的可行上界优化，不是实际 union 的最小 cap 测度。

**丢失几何与费用。** 该平方和不看 cap 交叠、共享来源或可重新分组的局部结构。等质量、共同 \(A_0\) 的 \(m\) 片账单是 \(mA_0W\)；有限总质量且 \(W_j\asymp j^{-2}\) 时账单仍可发散。这里无 \(n\) 幂可隐藏，费用直接由质量分布决定。

**可逆性 / 反例。** 这是该选定分配账本的精确下界/最小值，但不是实际 union 下界；不能借助人工切碎一个源推出弱型坏例。R101 private ledger 明确指出这一限制；没有一般真实输入反例。

### 7. 在真实捕获图上作平衡，只付累计方差/比较熵

**精确量 → 放松量。** 对同一 F2 接收割 \(B\)、同一真实图 \(Q_x\)、行质量 \(\lambda\)，列 \(b=\int_Ba_xdx\le H_n=1+n\log2\)，在以下公式取 \(H=H_n\)，R101 更新保持行和支撑，并有
\[
E_{j+1}\le E_j-\eta(2-\eta H)V_j,\quad
\eta(2-\eta H)\sum_{j<m}V_j\le E_0-E_m,\quad E_m\ge D^2/W.
\]
有限比较计划 \(a^*\) 另给
\[
E_m\le E^*+2K_0/(\eta m)+2\eta H^2D.
\]
全部是在真实联合测度上的有限步结论。

**丢失几何与费用。** \(H_n\sim n\)，初始只有 \(E_0\le H_nD\)（另有粗 \(H_n^2W\) 型费用），尚非根阶源预算。累计小 \(V_j\) 是当前行分布内的方差，不是列均匀、KKT/所有边可达、或原始 gate 对更新后分布仍成立。比较法的 \(K_0,E^*\) 是须另给的假设，不由 gates 产生。由 \(E_j\) 得坏接收需求仍仅
\[
\lambda|\{R_j>C\}|\le E_j/C.
\]
原外层费用及未分配需求照付；切换到不同迭代的子集还要累加各自列费用。

**可逆性 / 反例。** 有原后验和更新后后验的有限步比较，但仅有乘子界 \((1\pm\eta H)^j\)，以及
\[
\|P_m-P_0\|_{TV}\le\tfrac12\sqrt{\frac{m\eta(E_0-E_m)}{D(2-\eta H)}};
\]
此界随步数增长；完整步没有正的统一下界。故没有免费 gate transfer。原文给出一个**未证充分条件**：每个可达 iterate 满足 \(V_j\ge\gamma(E_j-C_nD)_+\)，它成立时可推出 cut 容量；不得当作已证明输入。R101 没有合资格高负载反例来否定该条件，也没有此几何耗散证明。

### 8. 正则输入结论回到任意 \(L^1\) 的极限接口

**精确量 → 放松量。** 若先在 \(L^1\cap L^2\) 规则输入上得到对所有输入与阈值统一的 cap/能量或弱型常数，才可对非负截断单调收敛，得到原最大算子的 \(L^1\) 结论。

**丢失几何与费用。** 这里没有额外维数因子，但“一输入有有限势能/有限 cap”不等于 uniform 常数；如果输入截断、阈值、来源分解变动时预算不一致，极限不能闭合。R100/R101 的 obstacle 也不自动对任意 \(L^1\) 有有限 \(L^2\) 势能。

**可逆性 / 反例。** 单调极限本身在统一弱界前提下是标准的；它不能反向提供该统一界。R101 没有相关反例，缺的是前提，而非极限步骤的几何修补。

## 建议主方案保留的真实量

1. Coverage：实际 \(D_L,J_{\ge L},K\)；删除集合上的 \(V_J(T)\) 与 \(\int_{\{J\le T\}}\Phi(nJ/\kappa)\)，或等价到因子 3 的实际保留混合矩 \(n\int J^2+(2\sqrt2/3)\sqrt{n\kappa}\int J^{3/2}\)。保持体积和矩使用同一个实际删除指示。
2. Nonlinear gluing：每个 \((x,L)\) 的真实共同来源集、相交分量的实际阈值和、非活跃总余场 \(F\)，补尺度 \(D_0/D_1\)，以及最终 cap 实际并集而非分量 cap 费用和。若用空间局部化，直接记载 \(q(x,L)\) 的分布/簇，而非只报最坏 \(q\)。
3. Adaptive：原始真实边 \(Q_x\)、联合分配 \(a_x(y)dx\,d\mu(y)\)、列 \(b(y)\)、当前行后验、真实同一接收割 \(B\) 与其所有子割；单独记录 \(E_j,V_j\)、比较计划 \(E^*,K_0\)、门函数对后验的 covariance/有限步转移费用，以及剩余需求。不得把 gate 对初始后验的量直接搬到更新后分布。

这些量是复核用的 bookkeeping，不是新强猜想，也不暗含任何尚未支付的假设。已有反例只否定它实际击中的放松/账本（分量能量无条件相加、截断后的 overlap 自动小），不能泛化成目标弱界反例。

## luna tools

## Scope and status

Object: for every dimension `n>=2`, nonnegative `f in L1(R^n)`, `W=∫f`, and `κ>0`, control the Lebesgue measure of `{x: sup_{L>0} L^{-n}∫_{x+[-L/2,L/2]^n}f > κ}` by `n^{1/2+o(1)}W/κ`, uniformly over all scales. This remains OPEN. The tool conditions below are screening conditions, not a proof route already closed.

The R101 verified object that is most relevant geometrically is the **actual capture graph**: for each selected receiver `x`, its earliest cube `Q_x` and source measure `μ=f dy` give the row law `π_x(dy)=L_x^{-n}1_{Q_x}(y)dμ(y)/λ`. The receiver and source are coupled through the same `f`; no product law or independent-coordinate model is available. R101's adaptive allocation preserves this graph and row mass, but its canonical common-column ceiling is `H_n=1+n log 2`. The finite variance descent and comparator estimate are exact, while a root-order column or a uniformly payable high-load complement is still missing.

## Four screened tools

| Tool and actual useful statement | Entry conditions and match to this problem | Fee / dimension consequence |
|---|---|---|
| **D01 Kantorovich / positive-plan certificate.** For ordinary static positive transport, a feasible coupling and dual potentials with `φ+ψ≤c` give primal/dual bounds in the stated direction; strong duality or attainment requires a matching theorem. R101 explicitly uses D01 only to keep the positive-plan model and feasible-certificate direction explicit. | Need the actual source/receiver marginals, a common capture support, finite cost/integrability, and a specified cost. The R101 rows have common source `μ` and receiver demand `λ dx` on a selected set, but the unresolved issue is a common column cap on the **original capture graph**. A generic OT coupling can move mass off `Q_x`; an admissible comparator with finite entropy/energy is not supplied by D01. No product posterior or optimizer existence follows. | Existing canonical allocation pays `H_n D` energy, with `H_n=1+n log 2=O(n)` and receiver demand `D=λ|B|`; its residual estimate is `λ|{R>C}|≤E/C`. A root ceiling `C_n=O(√n polylog n)` would be a geometric improvement, but D01 by itself pays no such fee. The frozen outer ledger remains `A_old+C_ext+√n+2⌈√n⌉`, with `A_old` containing `T_soft/α`; for fixed packet parameter `p0`, current formulas give `O(√n log²(n+2))` outer cost, but this does not pay the remaining `F₂` demand. |
| **B01 finite LP/Farkas certificates.** In a finite nonnegative linear system, feasibility can be certified by an exact primal solution or a separating dual/Farkas vector; weak duality gives a certificate direction. R101 explicitly confines B01 to the positive-plan model and feasible-certificate direction. | A discretized graph must include every source/receiver edge relevant to the claim, exact or certified cell masses, and a correctly oriented cut inequality. Finite feasibility/capacity certificates apply to that finite graph. Continuum passage additionally needs a limit/compactness or monotone exhaustion argument and control of boundary cells. General cone/infinite-dimensional strong duality is not licensed; skill flags qualification/topology/closedness conditions. | A finite graph certificate has its own cell/edge count and enclosure error; those are not a dimension-only theorem fee. A finite certificate can falsify a proposed universal constant or validate a fixture, but cannot reduce the `H_n=O(n)` continuum ceiling without an error bound uniform in source, threshold, scale, and `n`. If used to bound retained J, R101 still requires both `|D|≤a_n W/κ` and retained surrogate `∫_{D^c} S ≤ B_n κW`, with `S=(κ²/n)Φ(nJ/κ)`; then the return costs `4(2+a_n)+8√(n(2+a_n)B_n/log2)`. |
| **G01 Carleson box/tent packing.** The screened skill supports finite-tree packing only after the tree, base measure, all node coefficients, and child partitions are explicit; its nearby PDE results require their stated domain/boundary geometry and analytic hypotheses. | Our cubes form a continuum family with a common source and Lebesgue receiver measure, but no tree/tent encoding with a proved comparison to actual cube overlap is supplied. One must define box/tent geometry and prove the bridge, including all scales and the relevant union conditions. Neither finite-tree packing nor PDE/UR results apply by name to the centered-cube maximal set. | No fee is currently earned. A valid transfer would have to bound the actual common-source overlap/load (for example `b_B(y)=∫_B L_x^{-n}1_{Q_x}(y)dx`) with its full `n`-dependent packing constant, plus tree discretization and boundary/remote-scale errors. A bare Carleson constant could still leave the R101 `H_n` or the `F₂` remainder unpaid. |
| **G02 outer-Lp / size and stopping.** The tool defines outer distribution through a covering outer measure and a specified size; stopping/embedding conclusions require threshold capture, exceptional-set fee, packing, and the theorem's exact geometry/parameter conditions. | The target measure is ordinary Lebesgue measure of a pointwise maximal superlevel set. Converting it to an outer distribution requires an explicitly defined generating family, cover cost, size, and proof that the resulting outer estimate controls the original receiver measure. R101's `J` is actual receiver occupation; replacing it by a generic outer size risks discarding joint-source overlap. The skill itself says the general centered-cube/tree interface is unproved. | No direct subpower fee. A valid bridge must charge cover overlap, stopping exceptional sets, scale multiplicity, and any `p`/size constants, then still meet the same actual J volume-and-retained-energy joint budget. For root return, the missing coefficients must be `a_n,B_n=n^{o(1)}`; a dimension-dependent but `O(n)` packing or a scale count `O(log n)` multiplied by an untracked `n` loss does not suffice. |

## Failure tests and geometric quantities to retain

1. **Shared source is mandatory.** Any proposed overlap bound must use one measure `μ` and the same `Q_x` for all receivers in the tested set. Independent row couplings or productizing a mixture changes the object. The actual quantity `b_B(y)=∫_B L_x^{-n}1_{Q_x}(y)dx` is source-column load; its square integral is tied exactly to R101's canonical posterior burden, `λ∫_B R_B dx=∫b_B²dμ`. Neither identity bounds it at root order.
2. **Retain intersection geometry.** For two receivers/scales the needed datum is the actual intersection `Q(x,L)∩Q(x',L')`, weighted against the same source. Replacing it by the worst-case volume loses source placement and common-capture correlation. A cluster argument must state which overlap graph/components are counted and pay the component multiplicity and boundary spill.
3. **Keep both cap budgets together.** R101 coverage has an exact actual-score deletion formulation, but the unpaid requirement is a single retained set with both volume and score paid. With `S=(κ²/n)Φ(nJ/κ)`, the explicit score `S_pow=nJ²+(2√2/3)√(nκ)J^(3/2)` is within factor 3, pointwise. This scalar factor does not pay spatial concentration or a deletion-volume fee. The return needs uniform subpower `a_n` and `B_n`; no screened tool above derives them.
4. **Known qualified counterexample scope.** R101's qualified centered radial mixtures certify the original obstacle and actual shared-source capture; they do not establish an adversarial high-load failure for the original `F₂` gate. The physical corner-source allocation examples in the private adaptive appendix are not original-earliest-selector/F₂ inputs. Do not use either as a counterexample to the general target or as evidence that the missing joint estimate holds.

## Evidence boundary

Read the four installed entries `math-d01-kantorovich-duality`, `math-b01-lagrange-farkas`, `math-g01-carleson-measure-box-and-tent-test`, and `math-g02-outer-lp-size-and-tree-stopping`, including their applicability and failure clauses. R101 adaptive states that D01/B01/N04 were read in full, but only D01/B01 are included here because they directly concern common plans/certificates; no specific external theorem beyond the verified scopes restated above is imported. G01/G02 are skill-level applicability screens, not cited theorem transfers. No un-read theorem is invoked.

# R102 三阶段几何数值协议

状态：仅为后续认证设计，不运行实验、不报告数值结论。一般中心立方体弱界仍 OPEN。本协议依 Astra 冻结的 source-pair 恒等式及 near/far cutoff；公式定位见 本报告策略模块 §§2–4、§6，near 的精确位移体见 本报告几何模块 §3A。

**资格范围。** 主能量/source-pair 路线的 fixture 只要求真实非负密度 \(f\in L^1(\mathbb R^n)\)、\(W=\int f>0\)、阈值 \(\kappa>0\)、真实 Lebesgue 接收测度 \(dx\)，以及全计算中固定的同一个可测帽 \(U\)。这里连续来源指 \(\mu=fdy\) 对 Lebesgue 测度绝对连续、无原子；允许分段密度，不要求 \(f\) 为连续函数。它不要求原 \(F_2\) 最早 selector 或其它 \(F_2\) 门。只有若另行声称结果涉及原 \(F_2\) 共同容量或给出 \(F_2\) 合资格反例，才须对那个同一 \((f,\lambda,L_x)\) 逐项证明最早接触、anchor、连续全窗 \(P_1\)、captured-middle、selected-coarse、packet、physical 门及适用的既有删除费用；分量不能继承这些门。不要混用原 selector 阈值 \(\lambda\) 与能量阈值 \(\kappa\)。

## 每阶段固定的量与证书

每个 fixture 使用一个真实来源 \(d\mu=f(y)dy\)、一个能量阈值 \(\kappa\)、一个实际帽 \(U\supseteq\Omega\)（若研究不需障碍帽，可取一般可测 \(U\)），以及真实接收测度 \(dx\)。障碍帽只在已具其资格的正规输入上使用。记
\[
 A_L(x)=L^{-n}\mu(Q(x,L)),\quad h(x,L)=\begin{cases}(1-\kappa/A_L(x))_+,&A_L(x)>0,\\0,&A_L(x)=0.\end{cases}\quad
 I_L(y,z)=Q(y,L)\cap Q(z,L).
\]
直接认证
\[
 E_U=\iint\!\int_0^\infty L^{-2n}
 \int_{I_L(y,z)\setminus U}h(x,L)^2\,dx\,\frac{dL}{L}\,d\mu(y)d\mu(z).
\]
必须保留实际 \(h^2\)、同一来源对的交叠 \(I_L(y,z)\setminus U\)、同一帽 \(U\) 和其真实体积。混合来源时一个标签共同决定全部坐标；不可把混合边缘改成坐标乘积。逐来源或逐簇独立选帽后再相加不合格。

所有阶段冻结 \(q=n,\eta=1\)，令 \(u=\kappa L^n/W\)，只在 \(0<u<1\) 上定义 \(s=\log(1/u)\)、\(t=[s+2\log(1+s)-\log n]_+\)。near 为 \(0<u<1\) 且 \(\|y-z\|_1/L\le t\)，far 为其补集。按真实 pair/scale mask 切分 \(E_U=E_{near}(U)+E_{far}(U)\)，使用已证全输入界 \(E_{far}(U)\le\kappa W\)；\(u\ge1\) 归 far，但实际 \(h=0\)。不扫描 \(q,\eta\) 菜单，不把远项上界当近项结果。每阶段输出近、远、总能量的严格区间、同一帽的 \(\kappa|U|/W\)、尺度尾与来源分区余项；区间无法认证就记 UNKNOWN。

## 三阶段

1. **单源基准。** 选择一个此前未用于本轮数值、具备明确公式的真实 \(L^1\) 密度。固定一只实际帽，对 source-pair 恒等式做连续尺度分段积分，确认 \(E_U=E_{near}+E_{far}\)、远项证书、接收交叠和帽体积都闭合。目标是查实现与误差账，不是再跑便宜 \(J\) 特殊族或拟合维数指数。除非本阶段另行主张 \(F_2\) 资格，否则不要求 \(F_2\) 门。
2. **两簇相互作用。** 构造一个真实连续来源的双簇几何，只改变簇间相对位置或尺度，使同一接收区域同时被簇内/跨簇 near 对照亮。对完整来源和同一个 \(U\) 累加全部簇对能量，并单独报告共同 receiver 的实际 Lebesgue 交叠体积及 cross-pair 项；不把分量当新输入，不给每个簇另选帽。若额外研究原 \(F_2\)，才对最终总输入重新逐门证明资格；门未证时只停止 \(F_2\) 声称，不抹去其一般能量/source-pair 计算。
3. **跨尺度簇与 near 尾。** 仅在 stage 2 的共同接收机制有认证证据后，构造少量嵌套/错位尺度簇，测试相邻尺度的近对是否共享同一接收区域；继续对完整输入、单一阈值、单一帽积分。短尺度、簇边界、接收窗外、来源截断及 \(t\ge n\) 区段分别记账；远场尾可用已证式 (7)，near 尾必须另有严格上界，未知部分不得置零。此阶段仍然无需 \(F_2\) 门，除非另作该范围的声明。

## 成败判据与停止规则

本稿只是后续设计，不是已经冻结、执行的物理输入菜单。任何新的 producer 执行前，必须先冻结具体来源及资格、阶段参数和扩展触发、该 fixture 的预先预算、来源分区余项、接收窗口及近对尺度尾的认证参数与停止规则；把准确 statement-only 包送审，通过后才执行。

fixture 级成功只表示在该输入上，实际 near 能量与同帽体积有了认证上界，且 source-pair 恒等式、真实 receiver overlap、\(h^2\) 和 near/far 分割的区间账闭合。失败下界若超过预先明示的该 fixture 预算，只否定该帽/该 near 构造；若只是松弛上界太大，先定位丢失的 \(h^2\)、pair 相对位置或 receiver 并集，不宣称一般机制失败。预算或数值精度不足时保留 UNKNOWN 并停止该阶段。只有在额外声称原 \(F_2\) 结果时，资格门不全才停止该额外声称。

三阶段均不猜测 \(n\) 的幂指数、不从有限维现象外推 \(n^{o(1)}\)，也不重跑 R101 的 \(J\) 排序/分位数、角点帽拼接或固定图分配旧菜单。要形成一般进展仍需另证：对全部目标输入及每个 \(\kappa\)，有同一帽的统一 \(A_n=n^{o(1)}\)、\(B_{near,n}=n^{o(1)}\) 预算（Astra strategy (8)–(9)）；有限 fixture 不能替代该全称命题。


## 对象与有限量词

只验证sol_geometry.md已证的通用轴平行立方体交叠核、正函数全尺度尾部核及截断l1 lens的连续体积公式。参数是立方体边长、相对位移、尺度下限和lens半径，没有来源密度、障碍帽、私人下界配方或原F2门。有限menu证书不支持任意L1输入的Near预算、Hall根容量或一般维数律；目标仍OPEN。

## 冻结三阶段菜单

所有数值用Fraction，y=0，z为表内位移，L/S是全边长。

| 阶段 | overlap菜单 | K_ell菜单 | lens菜单 |
|---|---|---|
| 初探 | n2，L=S=2，z=(1/3,5/4) | n2，d=(0,1/2)，ell=1 | n1，t=1/3 |
| 边界压力 | n3，L=1,S=3，z=(1,3/2,2)及(1,3/2,1999/1000) | n3，d=(1,0,1/2)，ell=1/2 | n3，t=0,1,3/2,3,7/2 |
| 扩大维数 | n6，L=3/2,S=5/2，z=(0,1/2,3/4,1,5/4,199/100) | n6，d=(0,1/8,1/4,1/2,3/4,1)，ell=3/4 | n6，t=5/2,6 |

固定4 overlap records、3 tail records、8 lens records，不按结果扩张，不拟合n阶，不制造新物理输入数。边界菜单包括完全包含的交界、部分交叠、零切触和近切触；tail包含某些零d、ell跨maxd；lens包含零、整数界面及饱和。

## 独立认证方法

Overlap：对每坐标收集两盒端点并分成无缝interval，笛卡尔分格，用midpoint判断整cell是否在两盒内，直接累计实际cell volume。再独立用r=min(L,S)、tmax=max(L,S)、nu_i=(d_i−(tmax−r)/2)_+/r计算r^n∏(1−nu_i)_+。认证体积相等及volume/(L^nS^n)=tmax^(−n)∏(1−nu_i)_+。有限直接坐标积分是连续恒定indicator的精确积分，不是随机sample。

Tail：K_ell(d)=∫_ell^∞L^(−n−1)∏(1−d_i/L)_+dL。设b=max(ell,maxd)>0，先前区间[ell,b]乘积严格为零或为空。独立对正integrand在[b,64b]做6个dyadic slabs、每slab512个等宽区间，共3072 scale intervals/record。每[lo,hi]的lower=hi^(−n−1)∏(1−d_i/lo)，upper=lo^(−n−1)∏(1−d_i/hi)，乘真实width。每项Fraction精确计算后，lower向下、upper向上舍入到共同2^128分母，用整数累计；补∞tail upper=1/[n(64b)^n]（同向ceil到2^128），lower=0。额外舍入lower损失<3072/2^128，upper含tail增益<3073/2^128，额外总区间宽度<6145/2^128，不能把3073写为双侧总费用。所有菜单至少一个d>0，故未舍入tail严格小于upper。另用完整elementary-symmetric polynomial公式求精确K，再判其在该独立正函数Riemann包围内；不以多项式重排表达式自验，也不截断交错项。

Lens：正象限V_n(t)=|{x∈[0,1]^n:Σx_i≤t}|，V_0为非负半轴indicator。从V_n(t)=∫_0^1V_(n−1)(t−x)dx出发，用integer knots上的连续piecewise polynomial primitive递推，精确计算slice integral；与(1/n!)∑(-1)^k binom(n,k)(t−k)_+^n比较。最终真实lens体积是2^nV_n(t)。独立递推不调用inclusion-exclusion公式；全部系数与端点有理，避免浮点抵消。有限check不替代已证任意n公式。

## 判据与费用

Overlap和lens的两独立方法必须精确相等；tail多项式必须落在已付∞tail的正函数上下Riemann区间。若不相等或落区间外则记录FAIL并定位代码/证书错误；区间宽度只说明精度，不反驳核定理。报告实际尺寸、分格cell数、尺度区间数、∞tail收费和精确端点；不编造assertion数、source数或运行覆盖。

这些证明型核/continuum-volume检查没有实际receiver cap接受率omega或任意source pair质量。lens体积小不支付任意fdy质量；无门K_tail不支付短尺度Near；原始L2归一化因子不控制masked相关性。不得把有限guard写成全输入目标进展。

## 实际执行与审读回执

主代理和独立Sol审核者在producer执行前实际筛查本固定statement/protocol：PASS。附加共同2^128定向舍入亦于执行前分别获PASS。随后本恢复/验证角色在本轮**实际执行一次**geometry_guard.py，未复制重放、未追加菜单、未执行R101程序。独立Sol审核者实际完整静态读取最终producer代码：PASS，其没有执行本程序；最终完整报告读后回执另行登记。

| 项目 | 实际回执 |
|---|---|
| 生产脚本SHA-256 | `700fc2f577cf4ffea5bbbf85d1da6309fb9ff348dd58b67557508a48612a37f2` |
| 确定性stdout SHA-256 | `28cf84fd62f9326f4f9e9e3fe9ccd9a4da01654d263c6eccb23e3fecf3fa6db0` |
| stdout字节数 | 8053 |
| exit code | 0 |
| producer内耗时 | 0.12323349999996935秒（perf_counter，诊断字段） |
| 子进程外耗时 | 0.1436125830000492秒（本角色外层perf_counter） |
| stderr | 仅 `{"runtime_seconds_diagnostic": 0.12323349999996935}\n`，不是空stderr |

确定性stdout没有计时字段。输出hash不需“排除计时字段”才能一致；计时只在stderr。脚本不写邻接JSON或任何结果文件。下方完整JSON是该stdout的归档副本，不依赖临时路径或其他机器上的scratch文件。审读/重放不应增加几何record数或physical source数；代码没有instrumented assertion counter，不能编造断言数量。

实际15条记录：4 overlap、3 tail、8 lens；三阶段记录数分别3、8、4。overlap直接积分合计525个真实端点cell；tail 3×3072=9216个连续scale rectangles；physical L1 source inputs为0。slice_polynomial_pieces_through_dimension表示递推建出的有限piece数，不是样本数、独立来源数或断言数。

### 独立核验的精确结果与边界

- overlap：初探体积5/4、kernel5/64；切触体积/kernel0；近切触体积1/2000、kernel1/54000；n6异尺度体积27/1280、kernel16/2109375。端点边界没有正volume；近切触保留严格正交叠，不能与触边零volume合并。
- tail：三个精确完整polynomial值为1/3、7/120、427/84480，全部落于独立正函数Riemann+∞tail区间。每条记录b=1、R=64；后两条的[ell,b]确为zero integrand段。∞tail严格上界分别1/8192、1/786432、1/412316860416；严格性是未舍入的积分小于该上界，舍入后仍是合法非严格upper。
- lens：n1,t=1/3体积2/3；n3,t=0,1,3/2,3,7/2分别0,4/3,4,8,8；n6,t=5/2,6分别5633/360,64。slice recursion与incl-excl全部Fraction exact equality，包含zero/integer/saturation分支。
- 三个tail区间相对宽度为JSON中的exact rational，阅读用小数约0.00563101、0.0104274、0.0197206。该宽度是积分enclosure精度，不是几何定理误差或一般输入预算。

没有失败或额外执行，无新物理输入、原门资格或Near预算。全部code/output只含通用几何参数，不含私人来源下界配方。

### 复现

直接运行公开标准库脚本：

```sh
python3 geometry_guard.py  # 先提取本报告末尾 Python 代码
```

stdout应为下方8053字节JSON，含末尾换行；stderr计时随执行变化。用脚本当前SHA冻结版本复现，不比较计时值，不用单元midpoint采样解释替代端点cell恒定indicator积分。低于b段与∞tail收费都已经包含；lens体积不认证任意source pair mass，no-mask tail不支付短尺度，normalized raw kernel不认证masked norms。目标仍OPEN。

### 完整确定性stdout

```json
{
  "counts": {
    "distinct_physical_source_inputs": 0,
    "endpoint_cells": 525,
    "lens_records": 8,
    "overlap_records": 4,
    "scale_cells": 9216,
    "tail_records": 3
  },
  "lenses": [
    {
      "exact_equality": true,
      "inclusion_exclusion_volume": "2/3",
      "n": 1,
      "slice_polynomial_pieces_through_dimension": 1,
      "sliced_recursive_volume": "2/3",
      "stage": "pilot",
      "t": "1/3"
    },
    {
      "exact_equality": true,
      "inclusion_exclusion_volume": "0",
      "n": 3,
      "slice_polynomial_pieces_through_dimension": 6,
      "sliced_recursive_volume": "0",
      "stage": "boundary_pressure",
      "t": "0"
    },
    {
      "exact_equality": true,
      "inclusion_exclusion_volume": "4/3",
      "n": 3,
      "slice_polynomial_pieces_through_dimension": 6,
      "sliced_recursive_volume": "4/3",
      "stage": "boundary_pressure",
      "t": "1"
    },
    {
      "exact_equality": true,
      "inclusion_exclusion_volume": "4",
      "n": 3,
      "slice_polynomial_pieces_through_dimension": 6,
      "sliced_recursive_volume": "4",
      "stage": "boundary_pressure",
      "t": "3/2"
    },
    {
      "exact_equality": true,
      "inclusion_exclusion_volume": "8",
      "n": 3,
      "slice_polynomial_pieces_through_dimension": 6,
      "sliced_recursive_volume": "8",
      "stage": "boundary_pressure",
      "t": "3"
    },
    {
      "exact_equality": true,
      "inclusion_exclusion_volume": "8",
      "n": 3,
      "slice_polynomial_pieces_through_dimension": 6,
      "sliced_recursive_volume": "8",
      "stage": "boundary_pressure",
      "t": "7/2"
    },
    {
      "exact_equality": true,
      "inclusion_exclusion_volume": "5633/360",
      "n": 6,
      "slice_polynomial_pieces_through_dimension": 21,
      "sliced_recursive_volume": "5633/360",
      "stage": "expanded_dimension",
      "t": "5/2"
    },
    {
      "exact_equality": true,
      "inclusion_exclusion_volume": "64",
      "n": 6,
      "slice_polynomial_pieces_through_dimension": 21,
      "sliced_recursive_volume": "64",
      "stage": "expanded_dimension",
      "t": "6"
    }
  ],
  "overlap": [
    {
      "L": "2",
      "S": "2",
      "direct_endpoint_cell_volume": "5/4",
      "direct_normalized_kernel": "5/64",
      "endpoint_cells": 9,
      "exact_equality": true,
      "n": 2,
      "normalized_product_kernel": "5/64",
      "normalized_product_volume": "5/4",
      "positive_intersection_cells": 1,
      "stage": "pilot",
      "y": [
        "0",
        "0"
      ],
      "z": [
        "1/3",
        "5/4"
      ]
    },
    {
      "L": "1",
      "S": "3",
      "direct_endpoint_cell_volume": "0",
      "direct_normalized_kernel": "0",
      "endpoint_cells": 12,
      "exact_equality": true,
      "n": 3,
      "normalized_product_kernel": "0",
      "normalized_product_volume": "0",
      "positive_intersection_cells": 0,
      "stage": "boundary_pressure",
      "y": [
        "0",
        "0",
        "0"
      ],
      "z": [
        "1",
        "3/2",
        "2"
      ]
    },
    {
      "L": "1",
      "S": "3",
      "direct_endpoint_cell_volume": "1/2000",
      "direct_normalized_kernel": "1/54000",
      "endpoint_cells": 18,
      "exact_equality": true,
      "n": 3,
      "normalized_product_kernel": "1/54000",
      "normalized_product_volume": "1/2000",
      "positive_intersection_cells": 1,
      "stage": "boundary_pressure",
      "y": [
        "0",
        "0",
        "0"
      ],
      "z": [
        "1",
        "3/2",
        "1999/1000"
      ]
    },
    {
      "L": "3/2",
      "S": "5/2",
      "direct_endpoint_cell_volume": "27/1280",
      "direct_normalized_kernel": "16/2109375",
      "endpoint_cells": 486,
      "exact_equality": true,
      "n": 6,
      "normalized_product_kernel": "16/2109375",
      "normalized_product_volume": "27/1280",
      "positive_intersection_cells": 1,
      "stage": "expanded_dimension",
      "y": [
        "0",
        "0",
        "0",
        "0",
        "0",
        "0"
      ],
      "z": [
        "0",
        "1/2",
        "3/4",
        "1",
        "5/4",
        "199/100"
      ]
    }
  ],
  "round": 102,
  "scope": "Fixed continuous geometry kernels/volumes only; no physical L1 source, F2 qualification or Near budget.",
  "status": "PASS",
  "tails": [
    {
      "R": "64",
      "b": "1",
      "d": [
        "0",
        "1/2"
      ],
      "ell": "1",
      "enclosure_width_over_exact": "239516767546015396432649856033686943/42535295865117307932921825928971026432",
      "independent_enclosure_contains_exact": true,
      "infinity_tail_strict_before_rounding": true,
      "infinity_tail_upper_exact": "1/8192",
      "infinity_tail_upper_rounded": "1/8192",
      "lower_rounding_error_bound": "3/332306998946228968225951765070086144",
      "n": 2,
      "polynomial_exact": "1/3",
      "positive_riemann_finite_upper": "113685101709987904294019732767795944837/340282366920938463463374607431768211456",
      "positive_riemann_lower": "113087928704733475191227577122339873757/340282366920938463463374607431768211456",
      "positive_riemann_plus_tail_upper": "113726640084856182915047976738429705605/340282366920938463463374607431768211456",
      "rounding_denominator": "340282366920938463463374607431768211456",
      "scale_cells": 3072,
      "stage": "pilot",
      "upper_rounding_error_bound": "3073/340282366920938463463374607431768211456",
      "zero_before_b": false
    },
    {
      "R": "64",
      "b": "1",
      "d": [
        "1",
        "0",
        "1/2"
      ],
      "ell": "1/2",
      "enclosure_width_over_exact": "1552362989234206805063696968204073295/148873535527910577765226390751398592512",
      "independent_enclosure_contains_exact": true,
      "infinity_tail_strict_before_rounding": true,
      "infinity_tail_upper_exact": "1/786432",
      "infinity_tail_upper_rounded": "216345702438951151188770680384171/170141183460469231731687303715884105728",
      "lower_rounding_error_bound": "3/332306998946228968225951765070086144",
      "n": 3,
      "polynomial_exact": "7/120",
      "positive_riemann_finite_upper": "19952915335796344729262064409660219233/340282366920938463463374607431768211456",
      "positive_riemann_lower": "19746366295303328390889282355260444469/340282366920938463463374607431768211456",
      "positive_riemann_plus_tail_upper": "19953348027201222631564441951020987575/340282366920938463463374607431768211456",
      "rounding_denominator": "340282366920938463463374607431768211456",
      "scale_cells": 3072,
      "stage": "boundary_pressure",
      "upper_rounding_error_bound": "3073/340282366920938463463374607431768211456",
      "zero_before_b": true
    },
    {
      "R": "64",
      "b": "1",
      "d": [
        "0",
        "1/8",
        "1/4",
        "1/2",
        "3/4",
        "1"
      ],
      "ell": "3/4",
      "enclosure_width_over_exact": "5596500112024154794683492336266210505/283790177100079538864962807369853566976",
      "independent_enclosure_contains_exact": true,
      "infinity_tail_strict_before_rounding": true,
      "infinity_tail_upper_exact": "1/412316860416",
      "infinity_tail_upper_rounded": "825293359523586849932749483/340282366920938463463374607431768211456",
      "lower_rounding_error_bound": "3/332306998946228968225951765070086144",
      "n": 6,
      "polynomial_exact": "427/84480",
      "positive_riemann_finite_upper": "1736985714345342635182533716199154837/340282366920938463463374607431768211456",
      "positive_riemann_lower": "1703067532673519905041372127730290923/340282366920938463463374607431768211456",
      "positive_riemann_plus_tail_upper": "27140401799541187417283133845811005/5316911983139663491615228241121378304",
      "rounding_denominator": "340282366920938463463374607431768211456",
      "scale_cells": 3072,
      "stage": "expanded_dimension",
      "upper_rounding_error_bound": "3073/340282366920938463463374607431768211456",
      "zero_before_b": true
    }
  ]
}
```

# 第102轮整合审核与执行记录

主目标仍为 UNPROVED，保留 O(n log n) 基准。本轮已证来源对能量恒等式、远对有偿估计、精确交叠核及有限阈值树恒等式、原边重启的有偿来源迁移。近对的共同接收帽体积与保留能量预算尚未证明；F2低列储备的统一存在与费用亦未证明。

策略、几何、迁移的完整论证由主代理阅读全文，并经独立Sol全文审查。几何模块q=0的0乘无穷边界已改为直接证明零能量，q次上界仅在q≥1使用。精确交叠、位移体积以及尺度尾核不假设来源独立，不由Lebesgue体积推出任意来源质量界。历史材料仅用于定位放松损失，不能充当新定理依据。

更新后的64项技能按相关条目核验条件：D01输运对偶、B01有限对偶证书、G01/G02树装箱和外测度接口、F05尺度Schur费用、A02/N04误差账。相关结论的必要假设保留在模块中。本轮没有以未读原文的前沿定理填补几何预算。

## 已执行与未执行

公开几何守卫生产者实际运行一次，主代理从冻结代码另作一次临时目录隔离执行。两次确定性标准输出完全相同：8053字节，SHA-256 `28cf84fd62f9326f4f9e9e3fe9ccd9a4da01654d263c6eccb23e3fecf3fa6db0`。代码SHA-256 `700fc2f577cf4ffea5bbbf85d1da6309fb9ff348dd58b67557508a48612a37f2`。独立审核者完整阅读代码、报告并核对嵌入输出，没有执行自己的重放。

固定三阶段几何菜单共15条记录：4个长方体交叠、3个连续尺度尾核、8个位移体体积；525个接收端点单元、9216个尺度区间。精确Fraction计算和有向舍入尾包围通过。重复执行不增加输入或记录数。实际L1来源实例数为0；此守卫验证通用几何公式，不验证某一实际帽的Near预算、原F2门或一般弱型常数。

生产者外层耗时0.143612583秒、程序内层0.1232335秒。主代理外层耗时0.14182333300004757秒、程序内层0.12211620900006892秒。两次exit0；stderr均仅为计时JSON，并非空。计时不是证书的一部分。完整输出与独立计算方法见几何验证模块；复现程序嵌在proof.md末尾，仅依赖Python标准库。

后续物理输入的三阶段协议仅为设计，尚未执行。它使用完整输入、同一阈值和同一接收帽；不以旧J模型重放冒充新来源，不把尚未估计的Near尾置零。

## 归档边界

只公开一般证明、公开几何守卫、必要结果和方法范围。私人下界配方、私有程序及量化压力不在本包。详细LaTeX保留数学推导并作控制字符、环境、括号和引用静态检查，不编译PDF。第101轮已单独提交并推送，本轮另作独立提交。


## 公开几何核验证程序

```python
"""Public R102 fixed-menu continuous geometry certificates; no source recipes.

Overlap: endpoint-cell integration versus normalized geometric product.
Tail: positive scale Riemann enclosure plus infinity payment versus polynomial.
Lens: independent slicing/primitive recurrence versus inclusion-exclusion.
Stdlib, exact Fraction inputs; tail contributions round outward to 2**128.
Prints deterministic certificate JSON to stdout, timing only to stderr.
"""
from fractions import Fraction as F
from itertools import product
import json
import math
import sys
import time

GRID = 1 << 128
SUBINTERVALS = 512
SLABS = 6


def floor_fraction(x):
    return x.numerator // x.denominator


def ceil_fraction(x):
    return -floor_fraction(-x)


def direct_overlap(y, z, left_side, right_side):
    """Integrate both actual box indicators over all endpoint cells."""
    left = [(v - left_side / 2, v + left_side / 2) for v in y]
    right = [(v - right_side / 2, v + right_side / 2) for v in z]
    axes = []
    for a, b in zip(left, right):
        endpoints = sorted(set(a + b))
        axes.append(list(zip(endpoints, endpoints[1:])))
    volume = F(0)
    cells = accepted = 0
    for box in product(*axes):
        cells += 1
        midpoint = [(lo + hi) / 2 for lo, hi in box]
        inside = all(a[0] <= x <= a[1] and b[0] <= x <= b[1]
                     for x, a, b in zip(midpoint, left, right))
        if inside:
            volume += math.prod(hi - lo for lo, hi in box)
            accepted += 1
    return volume, cells, accepted


def normalized_overlap(y, z, left_side, right_side):
    """Separate geometric formula; not called by endpoint-cell integration."""
    small = min(left_side, right_side)
    large = max(left_side, right_side)
    offsets = [abs(a - b) for a, b in zip(y, z)]
    nus = [max(F(0), d - (large - small) / 2) / small for d in offsets]
    factors = [max(F(0), 1 - v) for v in nus]
    return small ** len(y) * math.prod(factors), large ** (-len(y)) * math.prod(factors)


def overlap_record(stage, z, left_side, right_side):
    y = [F(0)] * len(z)
    direct, cells, accepted = direct_overlap(y, z, left_side, right_side)
    geometric, kernel = normalized_overlap(y, z, left_side, right_side)
    direct_kernel = direct / (left_side ** len(z) * right_side ** len(z))
    assert direct == geometric and direct_kernel == kernel
    return {'stage': stage, 'n': len(z), 'y': list(map(str, y)), 'z': list(map(str, z)),
            'L': str(left_side), 'S': str(right_side), 'direct_endpoint_cell_volume': str(direct),
            'normalized_product_volume': str(geometric), 'direct_normalized_kernel': str(direct_kernel),
            'normalized_product_kernel': str(kernel), 'endpoint_cells': cells,
            'positive_intersection_cells': accepted, 'exact_equality': True}


def tail_polynomial(d, ell):
    """Full elementary-symmetric formula; separate from positive integrand."""
    n = len(d)
    b = max(ell, max(d))
    elementary = [F(1)] + [F(0)] * n
    used = 0
    for v in d:
        used += 1
        for k in range(used, 0, -1):
            elementary[k] += v * elementary[k - 1]
    exact = sum(((-1) ** k * elementary[k] / ((n + k) * b ** (n + k))
                 for k in range(n + 1)), F(0))
    return exact


def positive_scale_enclosure(d, ell):
    """No polynomial coefficients: bound the positive integrand on scale cells."""
    n = len(d)
    b = max(ell, max(d))
    lower_integer = upper_integer = cells = 0
    for slab in range(SLABS):
        start = b * 2 ** slab
        width = start / SUBINTERVALS
        for j in range(SUBINTERVALS):
            lo = start + j * width
            hi = lo + width
            assert lo >= max(d) and lo > 0
            lower = width * hi ** (-n - 1) * math.prod(1 - v / lo for v in d)
            upper = width * lo ** (-n - 1) * math.prod(1 - v / hi for v in d)
            assert 0 <= lower <= upper
            lower_integer += floor_fraction(lower * GRID)
            upper_integer += ceil_fraction(upper * GRID)
            cells += 1
    cutoff = b * 2 ** SLABS
    infinity_upper_exact = F(1, n) / cutoff ** n
    infinity_integer = ceil_fraction(infinity_upper_exact * GRID)
    return {'b': b, 'R': cutoff, 'lower': F(lower_integer, GRID),
            'finite_upper': F(upper_integer, GRID),
            'upper': F(upper_integer + infinity_integer, GRID),
            'infinity_upper_exact': infinity_upper_exact,
            'infinity_upper_rounded': F(infinity_integer, GRID), 'cells': cells,
            'lower_rounding_error_bound': F(cells, GRID),
            'upper_rounding_error_bound': F(cells + 1, GRID)}


def tail_record(stage, d, ell):
    exact = tail_polynomial(d, ell)
    enc = positive_scale_enclosure(d, ell)
    assert 0 < exact and enc['lower'] <= exact <= enc['upper']
    assert exact <= F(1, len(d)) / enc['b'] ** len(d)
    assert any(v > 0 for v in d)
    return {'stage': stage, 'n': len(d), 'd': list(map(str, d)), 'ell': str(ell),
            'b': str(enc['b']), 'zero_before_b': ell < enc['b'], 'R': str(enc['R']),
            'polynomial_exact': str(exact), 'positive_riemann_lower': str(enc['lower']),
            'positive_riemann_finite_upper': str(enc['finite_upper']),
            'infinity_tail_upper_exact': str(enc['infinity_upper_exact']),
            'infinity_tail_upper_rounded': str(enc['infinity_upper_rounded']),
            'infinity_tail_strict_before_rounding': True,
            'positive_riemann_plus_tail_upper': str(enc['upper']),
            'enclosure_width_over_exact': str((enc['upper'] - enc['lower']) / exact),
            'scale_cells': enc['cells'], 'rounding_denominator': str(GRID),
            'lower_rounding_error_bound': str(enc['lower_rounding_error_bound']),
            'upper_rounding_error_bound': str(enc['upper_rounding_error_bound']),
            'independent_enclosure_contains_exact': True}


def polynomial_value(coefficients, x):
    value = F(0)
    for coefficient in reversed(coefficients):
        value = value * x + coefficient
    return value


def polynomial_subtract(a, b):
    return [(a[k] if k < len(a) else F(0)) - (b[k] if k < len(b) else F(0))
            for k in range(max(len(a), len(b)))]


def polynomial_shift(a, shift):
    out = [F(0)] * len(a)
    for j, coefficient in enumerate(a):
        for k in range(j + 1):
            out[k] += coefficient * math.comb(j, k) * shift ** (j - k)
    return out


def sliced_lens_pieces(n):
    """From V_0(s)=1_{s>=0}, recursively integrate V_(m-1)(t-x), x in [0,1].

    Coefficients represent V_m(t) on each integer interval [k,k+1].
    Construct primitive continuously at knots, then take F(t)-F(t-1).
    No inclusion-exclusion terms or formula are used here.
    """
    pieces = []  # V_0 has no finite pieces; its primitive is s_+.
    for previous_dimension in range(n):
        primitives = []
        area = F(0)
        for k, coeff in enumerate(pieces):
            primitive = [F(0)] + [c / (j + 1) for j, c in enumerate(coeff)]
            primitive[0] = area - polynomial_value(primitive, F(k))
            primitives.append(primitive)
            area = polynomial_value(primitive, F(k + 1))
        exterior = [area - previous_dimension, F(1)]
        new_pieces = []
        for k in range(previous_dimension + 1):
            first = primitives[k] if k < previous_dimension else exterior
            second = ([F(0)] if k == 0 else polynomial_shift(primitives[k - 1], F(-1)))
            new_pieces.append(polynomial_subtract(first, second))
        pieces = new_pieces
        # Check continuity independently of inclusion-exclusion values.
        assert polynomial_value(pieces[0], F(0)) == 0
        assert polynomial_value(pieces[-1], F(previous_dimension + 1)) == 1
        for k in range(1, len(pieces)):
            assert polynomial_value(pieces[k - 1], F(k)) == polynomial_value(pieces[k], F(k))
    return pieces


def sliced_lens_volume(n, t):
    pieces = sliced_lens_pieces(n)
    if t <= 0:
        orthant = F(0)
    elif t >= n:
        orthant = F(1)
    else:
        orthant = polynomial_value(pieces[floor_fraction(t)], t)
    return 2 ** n * orthant


def inclusion_exclusion_lens(n, t):
    if t >= n:
        return F(2 ** n)
    return F(2 ** n, math.factorial(n)) * sum(
        ((-1) ** k * math.comb(n, k) * max(F(0), t - k) ** n for k in range(n + 1)), F(0))


def lens_record(stage, n, t):
    sliced = sliced_lens_volume(n, t)
    alternating = inclusion_exclusion_lens(n, t)
    assert 0 <= sliced <= 2 ** n and sliced == alternating
    return {'stage': stage, 'n': n, 't': str(t), 'sliced_recursive_volume': str(sliced),
            'inclusion_exclusion_volume': str(alternating), 'exact_equality': True,
            'slice_polynomial_pieces_through_dimension': n * (n + 1) // 2}


def run():
    overlap = [
        overlap_record('pilot', [F(1, 3), F(5, 4)], F(2), F(2)),
        overlap_record('boundary_pressure', [F(1), F(3, 2), F(2)], F(1), F(3)),
        overlap_record('boundary_pressure', [F(1), F(3, 2), F(1999, 1000)], F(1), F(3)),
        overlap_record('expanded_dimension', [F(0), F(1, 2), F(3, 4), F(1), F(5, 4), F(199, 100)], F(3, 2), F(5, 2)),
    ]
    tails = [
        tail_record('pilot', [F(0), F(1, 2)], F(1)),
        tail_record('boundary_pressure', [F(1), F(0), F(1, 2)], F(1, 2)),
        tail_record('expanded_dimension', [F(0), F(1, 8), F(1, 4), F(1, 2), F(3, 4), F(1)], F(3, 4)),
    ]
    lenses = [lens_record('pilot', 1, F(1, 3))]
    lenses += [lens_record('boundary_pressure', 3, t) for t in (F(0), F(1), F(3, 2), F(3), F(7, 2))]
    lenses += [lens_record('expanded_dimension', 6, t) for t in (F(5, 2), F(6))]
    return {'round': 102, 'status': 'PASS',
            'scope': 'Fixed continuous geometry kernels/volumes only; no physical L1 source, F2 qualification or Near budget.',
            'counts': {'overlap_records': len(overlap), 'tail_records': len(tails),
                       'lens_records': len(lenses), 'scale_cells': sum(r['scale_cells'] for r in tails),
                       'endpoint_cells': sum(r['endpoint_cells'] for r in overlap),
                       'distinct_physical_source_inputs': 0},
            'overlap': overlap, 'tails': tails, 'lenses': lenses}


if __name__ == '__main__':
    started = time.perf_counter()
    certificates = run()
    print(json.dumps(certificates, sort_keys=True, indent=2) + '\n', end='')
    print(json.dumps({'runtime_seconds_diagnostic': time.perf_counter() - started}), file=sys.stderr)
```
