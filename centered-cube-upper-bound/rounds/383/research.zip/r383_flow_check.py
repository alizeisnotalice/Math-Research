from fractions import Fraction as F
from itertools import product
from math import prod
count={'posterior':0,'clock_flow':0,'absorption':0}
# Exact bounded-posterior threshold statements, including threshold atoms.
P=[F(1,6),F(1,3),F(1,2)]
for aa in product([F(0),F(1,8),F(1,3),F(2,3),F(1)],repeat=3):
 A=sum(p*a for p,a in zip(P,aa))
 for d in (F(1,100),F(1,12),F(1,6),F(1,3)):
  mass=sum(p for p,a in zip(P,aa) if a>d)
  low=sum(p*a for p,a in zip(P,aa) if a<=d)
  assert low<=d
  assert mass>=(A-d)/(1-d)
  if A>2*d: assert mass>d/(1-d) and A-low>d
  count['posterior']+=3
# Genuine cubes and full piecewise-constant f; positive receiver quadrature only.
for n in (2,3,4):
 R=[F(1),F(3,2),F(2)]
 centers=[[F((u*(i+1))%5,4)-F(1,2) for i in range(n)] for u in range(3)]
 cubes=[[(centers[u][i]-R[u]/2,centers[u][i]+R[u]/2) for i in range(n)] for u in range(3)]
 axes=[]
 for i in range(n):
  b=sorted({x for Q in cubes for x in Q[i]});axes.append(list(zip(b,b[1:])))
 cells=[]
 for idx,box in enumerate(product(*axes)):
  mid=[(a+b)/2 for a,b in box]
  c=[int(all(a<mid[i]<b for i,(a,b) in enumerate(Q))) for Q in cubes]
  if any(c):cells.append((prod(b-a for a,b in box),F(1)+F(idx%3-1,8),c))
 m=[sum(vol*f*c[u] for vol,f,c in cells) for u in range(3)]
 q=[m[u]/R[u]**n for u in range(3)]
 lam=F(9,8);qm=3*lam/4
 assert all(qm<=a<=lam for a in q)
 du=[F(1,2),F(2,3),F(3,4)];mu=[du[u]/m[u] for u in range(3)]
 ell=[R[j]**(-n)-(R[j+1]**(-n) if j<2 else 0) for j in range(3)]
 X=sum(q[u]*du[u] for u in range(3))
 for K in (F(2),F(8)):
  for h in (F(0),F(1,10000)):
   for T in (F(1),F(9,8)):
    alpha=[[F(0) for cell in cells] for u in range(3)]
    direct=F(0);column=[F(0)]*3
    H=F(1,10000)
    for u in range(3):
     assert sum(R[u]**n*ell[j] for j in range(u,3))==1
     for i,(vol,f,c) in enumerate(cells):
      if not c[u]:continue
      past=sum(mu[v]*c[v] for v in range(3) if m[v]<m[u]/K)
      JR=sum(mu[v]*c[v] for v in range(u+1))
      for j in range(u,3):
       J=sum(mu[v]*c[v] for v in range(j+1))
       if J<H or past<=h:continue
       for v in range(j+1):
        if not m[u]>K*m[v] or not c[v] or not f>T*q[v]:continue
        surplus=max(F(0),1-q[v]/f)
        z=surplus*(1-m[v]/m[u])*mu[v]/J
        alpha[u][i]+=R[u]**n*ell[j]*z
        amount=du[u]*ell[j]*vol*f*z
        direct+=amount;column[v]+=amount
      assert alpha[u][i]<=1
      assert alpha[u][i]<=past/JR
      assert alpha[u][i]<=max(F(0),1-qm/f)
      if alpha[u][i]>0:assert past>h and f>T*qm
      count['clock_flow']+=4
    A=[sum(vol*f*c[u]*alpha[u][i]/m[u] for i,(vol,f,c) in enumerate(cells)) for u in range(3)]
    assert direct==sum(q[u]*du[u]*A[u] for u in range(3))==sum(column)
    assert all(0<=a<=1 for a in A) and direct<=X
    count['clock_flow']+=3
    for d in (F(1,10000),F(1,1000),F(1,100),F(1,12)):
     lowR=sum(q[u]*du[u]*A[u] for u in range(3) if A[u]<=2*d)
     lowY=rem=F(0)
     for u in range(3):
      if A[u]<=2*d:continue
      Ymass=sum(vol*f*c[u] for i,(vol,f,c) in enumerate(cells) if alpha[u][i]>d)
      assert Ymass>d*m[u]/(1-d)
      for i,(vol,f,c) in enumerate(cells):
       amount=q[u]*du[u]*vol*f*c[u]*alpha[u][i]/m[u]
       if alpha[u][i]<=d:lowY+=amount
       else:rem+=amount
     assert direct==lowR+lowY+rem
     assert lowR<=2*d*X and lowY<=d*X and direct<=3*d*X+rem
     count['absorption']+=3
print('PASS',count,'total',sum(count.values()))
