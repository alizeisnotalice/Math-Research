# R383 independent audit — FINAL PASS

Final bounded proof, full-code, numeric-scope and complete-ledger review is finished. The actual-du joint-capacity flow, endpoint/energy identities and disjoint receiver-budget absorption receipt pass. No substantive issue remains. General weighted endpoint/core budgets and the inherited outer/soft/history/scale obligations are unproved. Only this audit was modified; prior interfaces were used as stated, not comprehensively re-audited.

Independent screens below are retained as chronology; their pending status is superseded by the completed final review and byte bindings.

## 1. Fixed-clock common-source kernel: PASS with actual du reference

At fixed physical r restrict receivers to E_r={u:R_u<=r}. Put mu(du)=du/m_u and J_r(y)=integral_(E_r)c_u(y)mu(du). The proposed density with respect to dv is

    p_r(u,v)=integral f(y)c_u(y)c_v(y)/[m_u m_v J_r(y)]dy,

zero on J=0. It is symmetric in u,v. Positive Tonelli gives the row identity integral p_r(u,v)dv=1 for actual du-a.e u in E_r: the inner v integral is J, and zero-J captures contribute zero under f(y)c_u(y)mu(du)dy since their u integral is J*1_{J=0}=0. The exceptional u set is also du-null because m is bounded above/below by positive finite constants on the frozen octave field. This is not a separate arbitrary null-set deletion for each chosen receiver.

Thus P_r(u,dv)=p_r(u,v)dv is a symmetric Markov kernel under actual du. It is not normalized with respect to m_u du or mu(du). The unnormalized symmetric common-source kernel S_r satisfies integral S_r(u,v)mu(dv)=m_u; dividing by m_u and converting mu(dv)=dv/m_v yields the displayed P. Measurable versions can be chosen on the joint (r,u,v) space. Tonelli with the original ell(dr) proves the zero-J conclusion jointly, including a terminal atom at b; no Lebesgue-in-r argument may discard that atom. The degenerate a=b case likewise has only its correct terminal physical atom.

## 2. The actual bad-kernel domination and strict orientation

Restore the original omega as its complete clock integral BEFORE defining the per-r bad density. Factor the exact loss (m_u-m_v) from the far factor du*(1-m_v/m_u). The remaining actual h_r(u,v) contains, under the common-source integral, the original high-J/past and pair masks, the high-source density fraction g_v(y)/f(y) in[0,1], and the conditional target/history loss in[0,1] from the SAME source-exact plan. Hence

    0<=h_r(u,v)<=p_r(u,v),
    h_r supported on m_u>K m_v,
    G=integral ell(dr) integral (m_u-m_v)h_r(u,v)du dv.

No target-source independence is needed. The domination is valid for positive restrictions of the exact plan/history measure; it would not follow from renormalizing an eligible history event and then forgetting its probability. The conditional target law is normalized under the actual original source marginal, with zero-source rows arbitrary; it is not a new input. Any original mask with its own coefficient must remain in the source integral, not be replaced by an unmarked I_uv after interchange.

Strict orientation makes h_r(u,v) and h_r(v,u) disjoint. Since P is symmetric,

    h_r+h_r^T<=p_r,
    out_r(u)+in_r(u)<=1,

where out=integral h_r(u,v)dv and in=integral h_r(v,u)dv are densities in the SAME du reference. Thus H is row-subprobability and du H<=du; all signs and measures are correct. Equal masses give no far edge. This also gives integral h_r du dv<=|E_r|/2; it does not give a source-W budget for the mass-weighted cost.

## 3. The canonical finite conserving chain, and what it preserves

There is an exact useful construction at each r. Let sigma_r=1_(E_r)du,

    alpha_r=1-in_r, beta_r=1-out_r,
    I_r=alpha_r sigma_r.

Both are nonnegative, alpha>=out follows from out+in<=1, and

    sigma_r=I_r+sigma_r H_r,
    I_r(E_r)=integral beta_r d sigma_r.

Every H edge strictly decreases the actual mass by factor K. With m_-=q_-a^n and m_+=lambda b^n, a safe finite upper state/edge-generation cutoff is floor(log(m_+/m_-)/log K)+1. Products above that cutoff vanish, including actual receiver mass atoms, since strict inequalities multiply along each path. Finite telescoping therefore yields

    sum_(j>=0) I_r H_r^j = sigma_r,
    terminal law = beta_r sigma_r.

This constructs a canonical chain whose total single-edge occupation is sigma_r(du)H_r(u,dv). Its mass potential identity is exact:

    G_r=integral (m_u-m_v)h_r(u,v)du dv
       =integral m_u(alpha_r-beta_r)du.

All expressions are finite on the frozen finite E: H is bounded in row/column, m is bounded, and depth is finite. Their joint-r integral must retain the actual ell, its prefixes and b atom. Dropping the terminal mass only gives integral ell integral_(E_r)m_u alpha_r du<=integral_E m_u R_u^-n du=X_q, recovering the known order-one baseline, not the desired small receiver coefficient or root W tariff.

This canonical chain preserves the actual one-edge marked marginal if each edge's original source/target/history labels are disintegrated and sampled with their original conditional law. It is NOT automatically the old rank process or an original multi-edge history: composing independently normalized edges can combine different old sources/contexts. No old first-crossing qualification, shared-source path event, nonanticipativity property, target-plan rebate or multi-edge negative-square identity is inherited merely from equality of edge occupation. A claimed source/terminal bound must explicitly retain its joint labels and prove the required incoming capacity.

## 4. A limited L2 capacity consequence, not payment

The same capacity inequality implies, for real g in L2(du),

    2 |integral g(u)h_r(u,v)g(v)du dv|
      <= integral (out_r+in_r)g^2 du <= ||g||_2^2.

Use |g(u)g(v)| and 2ab<=a^2+b^2; no incorrect mdu reversibility is used. This is a legitimate numerical-radius/coercivity fact for the actual density. It does not bound the original clock/mass-weighted initial source or terminal W occupation. It is recorded as a limited capacity consequence, not an additional root receipt or a substitute for original target/capture accounting.

## 5. Independent screen of the announced receiver absorption split

Suppose the actual same-field formula is G=integral q_u A_u du with A_u=E_(pi_u) alpha_u(y), pi_u=f c_u dy/m_u and0<=alpha<=1 obtained from the FULL normalized original clock. For0<delta<1, delete the true positive restrictions A_u<=2delta and then, on A_u>2delta, alpha_u(y)<=delta. Their costs are at most2delta X_q and delta X_q. They are disjoint and total at most3delta X_q; choose delta=epsilon/3. The remaining exact cost retains both marks.

For each retained u, letting Y_u={alpha_u>delta},

    pi_u(Y_u)>= (A_u-delta)/(1-delta)>delta/(1-delta).

Thus its full-f source mass exceeds delta m_u/(1-delta). This is a real posterior mass statement about EACH original receiver, not a source-W capacity summed over receivers. If the exact normalized-clock construction additionally proves alpha_u<=1_{Z_u>h}Z_u/J_y(R_u), then alpha>delta implies Z_u>h and Z_u>delta J_y(R_u), with the original clock and inclusive J unchanged. Such conditions are entrance qualifications only; they cannot be transferred to descendants of the canonical H chain. The author proof establishes these exact alpha/clock formulas as reviewed below.

The high-A event is nonempty only when A_u<=1 permits it; for large delta the core can be empty. The useful intended epsilon is small, and no claim of a fixed positive covered fraction or core mass is made. The above is a paid receiver sublevel branch, not a source-W budget for its complement.

## 6. Bounded actual mathematical-tool evidence

Reviewer actually ran a local standard-library Fraction harness:120 finite symmetric-kernel/capacity/flow identities,300 quadratic capacity cases and375 receiver/source-threshold split cases, total795 assertions PASS. The finite Markov matrices were not claimed to realize native cube/history fields; they check only the algebra of the independently proved general interfaces. An initial harness used Python's floating empty-sum zero and failed an exact rational identity; it was corrected to start all sums at Fraction(0), then the entire run passed. No failed run is counted as a pass. No parent/author pipeline was repeated, and these reviewer counts remain separate from all future author/parent totals.

Initial conclusion: the actual-du P/H domination, strict-orientation capacity and canonical conserving-chain identities pass under their stated original positive-kernel hypotheses. They do not by themselves pay root source cost or transfer old history/target qualifications. The announced receiver sublevel split passes abstractly, with its original-clock factorization subsequently established in the author review below. Final proof/numeric/ledger review is now completed below.

## 7. Author geometry and flow proofs: PASS

After the independent screen, read the entire final geometry.md (including its added J=0 Tonelli paragraph), flow.md and both complete standalone scripts. The actual H_r includes the original high-source fraction and true conditional target loss, with the algebraic mass-loss factor outside H, giving the exact (m_u-m_v)H cost. H<=P, strict oriented support and actual-du symmetry imply H+H*<=P despite asymmetric remaining source/history/window marks. The author's zero-J calculation uses the correct common joint measure and proves pi_u-null omission for actual du-a.e receiver. Applying the same positive Tonelli calculation with ell handles terminal radius atoms. Conditional acceptance biases the source and is correctly not reset to pi_u.

The incident inequality(5) is valid also for a complex L2 inner product: take absolute values under the positive kernel and use2|x(u)||x(v)|<=|x(u)|^2+|x(v)|^2. Coercivity and the constant2 resolvent follow. Finite mass-gap nilpotence with N=ceil(log(Mplus/Mminus)/log K) is correct: N retained edges force a strict mass ratio>K^N>=Mplus/Mminus, a contradiction. The actual entrance alpha du, endpoint beta du and occupation du are finite measure identities. No mdu reference, nested cube assumption or old multi-hop qualification is introduced. All signed endpoint integrals have finite separate parts before exchanging fdy and clock. The elementary center endpoint bound is only A_n W and is not called root.

The energy alternative is also correctly normalized. The far inequality m_u-m_v<=cK(sqrt(m_u)-sqrt(m_v))^2 and H+H*<=P give at most half the symmetric P Dirichlet form. Full matching identifies this form with integral_(E_r)m_u du minus the displayed common-source square; complete inclusive ell then gives X_q-Q_flow. Hence G<=min(X_q,cK(X_q-Q_flow)), Q_flow>=0 and Q_flow<=X_q. This is a new upper estimate for the stated positive G, not a free second subtraction of the old BH square or a source occupation payment. Its sourcewise integrand is exactly f J Var(sqrt(m)); constant2 unweighted L2 control does not bound that source/clock/mass-weighted quantity.

The flow proof restores q_u du times the exact two probability references nu_u=R_u^n ell_[R_u,b] and pi_u=f c_u/m_u. Their product is a reference factorization of the marked original flow, not a claim of independence after acceptance. The resulting b_u,alpha_u,A_u are in[0,1] and yield G=integral q_u A_u du. Both low pieces use original probabilities, their disjoint order pays at most3delta X_q, and the precise posterior lower bound is >=(A-delta)/(1-delta)>delta/(1-delta). The core retains original u/r/y/v labels, strict/inclusive threshold atoms and positive alpha density. Bounds alpha<=Z/J(R_u), high-source tail implications and the optional tail-mass criterion have their correct directions. No small-v column bound kappa<=q_v is inferred, and no next receiver inherits Y_u or the entrance conditions.

Parent confirms fresh9540 flow and648 geometry Fraction runs. Flow uses actual finite cube-cell integration and receiver quadrature with its stated rational q band; geometry uses finite source/receiver incidence kernels and rational probes, not native continuous dense-deep/root gate realizations. The geometry probe tests are real rational x, while the complex inequality is justified by the analytic positive-kernel argument above. No pipeline was repeated by this reviewer. The scripts do not certify a general weighted endpoint/variance or core budget.

## 8. Full ledger review: PASS

Read current main/complete ledger/readme. The R383 input G is explicitly one fixed same-plan R382 double-window residual (retaining its F2), or the original no-window G with F2=0. Applying G<=epsilon383 X_q+G_core then adds only epsilon383 to the prior exact-cost receiver coefficient; it does not pay old Hall epsilon/epsilon-prime errors again. Entrance addition is exactly2Lambda epsilon383 X_q. With sigma<=eta/2, eta=kappa/(6Lambda), epsilon383=kappa/(4Lambda) gives2Lambda(eta+sigma+epsilon383)<=kappa, subject to epsilon383<=1. Original epsilon still chooses t but is not an extra receiver fee in this exact-cost option.

The energy alternative replaces that same G by its complete min bound; it is not added as another negative square. If instead applied after the receiver screening, H must be rebuilt for G_core while P is the same full reference, which the ledger expressly states. Previously paid windows, source/template capacity and parameter synchronization are not silently removed. All H/source entrance terms, outer Lambda, and historical/soft/extreme-scale/threshold/limit obligations remain unpaid as specified. Final numeric scope clarification and byte bindings are completed below.

## 9. Final numeric code, complete saved result and scope: PASS

Read the full standalone numeric.py, final note and complete result schema/seven case summaries, row records, endpoint spectra and residual splits. The source is genuine compact positive-volume f=(3/4)1_Q4+P s^-n 1_Qs, and receivers are true Lebesgue shells. Varying r_min adjusts P=(1/4)r_min^n so every actual q=m/R^n remains in[3/4,1], with q0=1. Receiver shells contain the full packet and their cubes lie in Q4; volumes, packet surplus masses and both receiver weights are retained. Nothing is independently fitted. Full W, not packet mass P, is used in source normalization.

The physical clock uses exact rational interval-tail differences and the terminal b atom; the original packet J and strict far/past masks use the same full f. Exact Taylor brackets classify exp(sqrt(n)) for the tested perfect-square dimensions. The target-capture tensor formula is the R382 four-term shell inclusion-exclusion of exact one-dimensional interval-overlap products. Those analytic geometry formulas are reused, while n-dimensional tensor powers/cost totals and row selections are evaluated with ordinary mpmath50/80. The unused independent helper is not counted as a new executed independent-integration verification. No new exact all-pair cost certificate or interval computation is claimed.

The seven saved cases agree with the note: baseline n4/16/64 plus r_min5/4,3/2 pressures at n16/64. The baseline R382 cost values reproduce. At epsilon=.001, all n16/64 whole-shell blocks have average cost below that budget; n4 leaves about0.0008344715 X_q. At epsilon=.1,.01 all seven complete relaxed costs are paid in the displayed partition. The proportional residual is genuinely a positive restriction of each whole-shell cost matrix and its small-end spectrum sums to that actual residual. It is not an assertion that all continuous u in that shell have the same pointwise A_u.

The requested scope clarification is present in final numeric.md and main: numerical row means an entire shell-block average, not the receiver theorem's pointwise A_u; the code did NOT compute the theorem's Y_u or exact G_core. Its fractional block allocation paid_i=min(B_i,epsilon X_i) is a different legal integrated positive restriction. No simulation of the two pointwise theorem filters is inferred from it. The row bound (P/m_i)(past_i/J_i) follows by d_v<=P/m_v and the original complete clock tail; it uses actual mass normalization, not an assumed small incoming surplus. Saved largest-row incoming surplus near1/4, whole-cost weighted means, P/m_i and past/J values support the stated limited mechanism.

All numeric cases use diagnostic H=h=J_final/64 and omit outside/dense/deep/history and other remaining-pair masks. They are not the native synchronized R379 remaining branch and do not certify historical FIRST/old-selector qualifications. No source probe, receiver sampling or coordinate independence of f replaces the actual integrals, but genuine dx alone does not restore omitted gates. Full B/W remains tiny at large n even after increasing P. Neither broad spectra nor small finite residuals establish a general endpoint/core payment.

Parent confirms a fresh14320 Fraction and7115 ordinary MP run. Exact tests comprise1004 geometry/q-band and13316 far classifications, including repeated precision executions; ordinary diagnostics include precision agreement, cost positivity, model-specific row bounds and block splits. They are separately counted and are not all exact mathematical certificates. Saved50/80 differences are below1e-39 as claimed. mpmath1.3.0 and its actual local vendor fallback are disclosed; this is not a dependency-free standard-library-only script. No MATLAB/optimizer/asymptotic fit is reported.

## 10. Final complete ledger and decision

Read the final current main/ledger/readme after the J0, posterior inequality and shell-average scope clarifications. The main now uses f-a.e source qualifications consistently. The first posterior inequality is >=(A-delta)/(1-delta); strictness arises only from A>2delta. The initial screen's overly strict first sign has been corrected in this audit. For the exact analytic definitions, positive alpha also yields the displayed strict-past and prefix-ratio conditions on retained sources; no such condition is transported to a next receiver for free.

The ledger explicitly chooses one exact input G: prior same-plan R2 retaining its already charged F2, or no-window G with F2=0. Its preferred positive split adds epsilon383 X_q and retains actual G_core with every original mark. There is no extra old Hall epsilon/epsilon-prime receiver fee in this exact-cost version, no altered target/template and no h reset. With sigma<=eta/2, eta=kappa/(6Lambda), epsilon383=kappa/(4Lambda), the full slot absorption is2Lambda(eta+sigma+epsilon383)<=kappa; epsilon383<=1 is explicitly required. Old epsilon may still choose t but is not the newly charged coefficient.

The complete energy alternative substitutes min(X_q,cK(X_q-Q_flow)) for that SAME chosen G and retains all other fees. It cannot be added as an independent negative old-square credit. If used on G_core instead, its accepted H is recomputed for that core and shares the unthinned full-f P; no old-chain qualification or conditional source law is reset. The numerical-radius/resolvent facts concern actual du, not mdu or an unproved source occupation measure. The canonical flow supplies exact finite receiver edge/endpoint occupation, not an already paid root terminal/source bound.

The entire entrance still has8lambda H W,2d_eff A_n W_nu/H,2G_core, twice the relevant receiver coefficient and source tariff, followed by Lambda. All H selection, soft/crossing/entry, heavy-tail/wide-distance/low-pe/extreme-scale complements, initial/deleted/future-deleted source histories, all-scale/source aggregation, truncation and limit-exchange obligations remain explicit. Physical terminal-clock atoms are not substituted for historical atoms. The slot kappa allocation is not global closure.

Parent reports fresh9540+648+14320=24508 Fraction assertions and separately7115 ordinary MP diagnostics. This reviewer read all three complete proofs/scripts and saved numeric results without repeating the parent pipelines. Reviewer-only795 bounded scalar/kernel assertions remain separately stated; an initial empty-sum harness mistake was corrected before the complete successful run and was not counted as proof. No archive re-extraction, LaTeX compilation or Git action is certified by this audit.

Final decision: FINAL PASS for these bounded original-flow/absorption/selection and complete-ledger statements. No general n^(1/2+o(1)) weak bound, core budget or weighted endpoint/variance estimate is established.

## 11. Final SHA256 bindings

Exact reviewed current files follow. The audit hash is reported separately after saving.

- `/tmp/r383_main.md` — `f09a77929c8e3bd8a166dc0a44364b52c50d0dcf64f3a2f90982a6ffaec55f28`
- `/tmp/r383_ledger.md` — `445da37e4f5e826f3b3e5829a170cdf72509d38d7bd7ee937aaf2b5071ec1b80`
- `/tmp/r383_readme.md` — `d64625cc2f7cf56ff8e5007463ae563068d95d1c1d36917f2e45a77464379d5a`
- `/tmp/r383_flow.md` — `3870009b3c82a3a051e379ea6636940ff583ca945f645d371d0a813e9880c4cd`
- `/tmp/r383_flow_check.py` — `9165a6ac4ff70cd64f5338dd093cc0c785b37437fb42a73d130559ba3ab50ea4`
- `/tmp/r383_geometry.md` — `d517afb88200f231b3ff30ce9424522e51df9be4a18a9dad6c072d1426f478ae`
- `/tmp/r383_geometry_check.py` — `59167e05cceed32dd4b641949910326b58b4f01bc5bf700b75e16e8a8505edf7`
- `/tmp/r383_numeric.md` — `55794f9efd82899cc05bc3309891a354855f17b09f1445a459a733247078fcd3`
- `/tmp/r383_numeric.py` — `e0fe76db2de15a4bb8301bafc7405876d083eb508c7641be53ff9d8f39bd0f55`
- `/tmp/r383_numeric.result.json` — `1ad2c5b97136bfe50e6b163e08a0ea5019a7cd00c1bc5abd45d47f7a5d73bdca`

Necessary inherited interfaces, only at the explicitly audited boundaries:

- `/tmp/r382_geometry.md` — `e596a311e4eca9be309c10aafe75db0e1938aa815dd258538461bdf0d47f2944`
- `/tmp/r382_selection.md` — `d0bd157001bcec7a3836a3bf757d3a7cf8f902eb9496dc1b40e9ada9fc301f79`
- `/tmp/r382_clock.md` — `e58f537148f6abaddf6f6f8668dd55a600edcb1cf2b3824cab429a94c7a4b901`
- `/tmp/r382_ledger.md` — `5039bc2e99f5e8d9783fb42aae1d34bb36ad55d385acd7e5444a2e0c55ab3938`
- `/tmp/r382_audit.md` — `53d6eec4d3613f446600ba63c5c0294a972dee690a970c71460fb7a4419ca085`
- `/tmp/r381_geometry.md` — `df86a325407457678613cc00fb4de37023ff29fb5d6ce4b039238c148a2f071f`
- `/tmp/r379_ledger.md` — `5f577d1d01cfe9ac3d992853c9e92cbe85e1fe5fc4e6758591b1858a8dcdc063`
- `/tmp/r378_layered.md` — `8d7f0361b15108b014b9fb7ddc8c124e17f268a2ba98ff7bb8ab2489b188e24d`
- `/tmp/r377_geometry.md` — `16b083e57cd84fe7d3b8b9a077d2211941e7efd340d3bf3bc7fdb0fcaa85a29d`

FINAL PASS. Review stopped; no author/repository edits and no general-closure claim.
