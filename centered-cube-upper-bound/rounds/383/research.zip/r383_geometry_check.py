from fractions import Fraction as F
from itertools import product

def mm(A,B):
 return [[sum(a*b for a,b in zip(row,col)) for col in zip(*B)] for row in A]
def vm(v,A):return [sum(v[i]*A[i][j] for i in range(len(v))) for j in range(len(v))]
counts={'matching_marked_kernel':0,'flow_identity':0,'incident_energy':0}
positive=0
# Exact finite source/receiver quadratures, not native continuous hard-gate samples.
# Full f determines m. Every H keeps a common-source and target-loss thinning.
for seed in range(1,19):
 f=[F(1+(seed+3*y)%9,4) for y in range(8)]
 dy=[F(1,8)]*8
 c=[[int(i<=y<min(8,i+length)) for y in range(8)]
    for i,length in [(0,8),(0,4),(2,4),(1,2),(5,2)]]
 m=[sum(f[y]*dy[y]*cu[y] for y in range(8)) for cu in c]
 w=[F(1+(seed+i)%4,7) for i in range(5)]
 for k in (F(5,4),F(3,2),F(2)):
  for cut in (3,4,5):
   c0=c[:cut];m0=m[:cut];w0=w[:cut];N=cut
   J=[sum(w0[i]*c0[i][y]/m0[i] for i in range(N)) for y in range(8)]
   P=[[sum(f[y]*dy[y]*c0[i][y]*c0[j][y]/J[y]
            for y in range(8) if J[y])/m0[i]/m0[j]*w0[j]
       for j in range(N)] for i in range(N)]
   H=[[F(0) for j in range(N)] for i in range(N)]
   for i in range(N):
    for j in range(N):
     if m0[i]<=k*m0[j]:continue
     for y in range(8):
      if not(J[y] and c0[i][y] and c0[j][y]):continue
      # Literal target kernel on captured source cells, source-dependent tilt.
      target=[F(c0[j][z],sum(c0[j])) for z in range(8)]
      avg=sum(target[z]*c0[i][z] for z in range(8))
      tilt=F(y%3,2)
      target=[target[z]*(1+tilt*(c0[i][z]-avg)) for z in range(8)]
      assert sum(target)==1 and min(target)>=0
      loss=sum(target[z]*(1-c0[i][z]) for z in range(8))
      high=F(1+(y+seed)%3,3)
      past=sum(w0[t]*c0[t][y]/m0[t] for t in range(N) if m0[t]<m0[i]/k)
      gate=int(past>F(1,10))*int(J[y]>=F(1,10))
      H[i][j]+=w0[j]*f[y]*dy[y]*loss*high*gate/(m0[i]*m0[j]*J[y])
   row=[sum(r) for r in H]
   col=[sum(w0[i]*H[i][j] for i in range(N))/w0[j] for j in range(N)]
   for i in range(N):
    assert sum(P[i])==1
    assert row[i]+col[i]<=1
    for j in range(N):
     assert w0[i]*P[i][j]==w0[j]*P[j][i]
     assert H[i][j]+w0[j]*H[j][i]/w0[i]<=P[i][j]
   counts['matching_marked_kernel']+=1
   alpha=[w0[i]*(1-col[i]) for i in range(N)]
   beta=[1-row[i] for i in range(N)]
   occ=[F(0)]*N;cur=alpha[:]
   for z in range(N):
    occ=[occ[i]+cur[i] for i in range(N)];cur=vm(cur,H)
   assert cur==[0]*N and occ==w0
   loss=sum(w0[i]*H[i][j]*(m0[i]-m0[j]) for i in range(N) for j in range(N))
   tel=sum((alpha[i]-w0[i]*beta[i])*m0[i] for i in range(N))
   assert loss==tel
   assert sum(alpha)==sum(w0[i]*beta[i] for i in range(N))
   positive+=int(loss>0)
   counts['flow_identity']+=1
   for x in ([F(i+1,3) for i in range(N)], [F((-1)**i*(i+1),3) for i in range(N)]):
    hx=[sum(H[i][j]*x[j] for j in range(N)) for i in range(N)]
    norm=sum(w0[i]*x[i]**2 for i in range(N))
    inner=sum(w0[i]*x[i]*hx[i] for i in range(N))
    assert 2*inner<=norm
    residual=sum(w0[i]*(x[i]-hx[i])**2 for i in range(N))
    assert norm<=4*residual
    # Exact polynomial Dirichlet identity, using arbitrary rational test function.
    energy=sum(w0[i]*P[i][j]*(x[i]-x[j])**2 for i in range(N) for j in range(N))/2
    square=sum(f[y]*dy[y]/J[y]*(sum(w0[i]*c0[i][y]*x[i]/m0[i] for i in range(N)))**2 for y in range(8) if J[y])
    assert energy==norm-square
    assert sum(w0[i]*H[i][j]*(x[i]-x[j])**2 for i in range(N) for j in range(N))<=energy
    counts['incident_energy']+=1
print('PASS',counts,'total',sum(counts.values()),'positive marked costs',positive)
