# R383 — A source-exact, jointly capacitated receiver flow

This note proves an actual marked-flow construction, its joint incident capacity, an exact endpoint settlement, and a capture-square upper bound for the original remaining cost. It does **not** prove the requested general root-order payment. The endpoint source-load and its equivalent energy quantity are retained explicitly. No new source price is charged.

## 1. Contract and exact marked kernel

Keep all R382 fields and gates, including the actual Lebesgue receiver set E of finite measure, full f, m_u=f(Q_u)=q_u R_u^n, q_-≤q_u≤λ, a≤R_u≤b≤2a, K=exp(√n)>λ/q_-, original J/H/strict past, and the entire physical clock ℓ. Write E_r={u:R_u≤r}. All equalities of kernels are understood up to Lebesgue null sets. Put

J_y(r)=∫_{E_r} c_w(y)dw/m_w,
π_u(dy)=f(y)c_u(y)dy/m_u.

Fix any one of the actual source-exact high-source plans τ_v from R382. Its source marginal is s_v(y)π_v(dy), where

s_v(y)=1_{f(y)>Tq_v}(1−q_v/f(y))_+ ∈[0,1],

with value zero when f(y)=0. Standard Borel disintegration gives τ_v(dy,dz)=s_v(y)π_v(dy)κ_{v,y}(dz), with κ a probability kernel wherever the source marginal is nonzero. A null-source version can be chosen arbitrarily. A measurable family of plans is assumed, as in the existing construction. Define

a_{uv}(y)=∫(1−c_u(z))κ_{v,y}(dz) ∈[0,1].

Let η_{r,u,v}(y) be the product of all retained 0/1 gates: u∈E_r, the actual far condition m_u>K m_v, original spatial gates, J_y(r)≥H, strict mass past>h, and any two-ended residual window indicators. Soft residual factors may also be included. Crucially 0≤η≤1 and η vanishes unless m_u>K m_v. The algebraic mass-loss factor 1−m_v/m_u is NOT included in η.

Define a kernel on E_r by

H_r(u,dv)=dv/(m_u m_v) ∫ f(y)c_u(y)c_v(y)/J_y(r)
                         η_{r,u,v}(y)s_v(y)a_{uv}(y)dy.                 (1)

Zero denominators contribute zero. The original R382 cost is exactly

G=∫ℓ(dr) ∫_{E_r}du ∫_{E_r}(m_u−m_v) H_r(u,dv).                      (2)

Indeed substitution of the original ω cancels hR_u^n, and (m_u−m_v)/(m_um_v)=(1−m_v/m_u)/m_v. The full original gates remain in (1). Far matching gives R_v<R_u, so every retained v belongs to E_r. Arbitrary dependence of target on source is retained through a_uv; no product-plan assumption is used.

## 2. True du reversibility and joint incident capacity

The unthinned receiver kernel is

P_r(u,dv)=dv/(m_um_v) ∫ f(y)c_u(y)c_v(y)/J_y(r)dy.                    (3)

This has an exact two-step realization: draw y from the complete full-f law π_u, then draw v from c_v(y)dv/(m_vJ_y(r)) on E_r. The second law has total mass one on the relevant source set. Thus P_r1=1 almost everywhere, and du P_r(u,dv) is symmetric. This is reversibility for **du**, not for m_u du. For the zero-denominator convention, Tonelli gives ∫_{E_r}du/m_u ∫_{J_y(r)=0}f(y)c_u(y)dy=∫_{J=0}f(y)J_y(r)dy=0. Hence the omitted source set is π_u-null for almost every actual u, so normalization holds almost everywhere.

The accepted kernel H_r is obtained from this realization by retaining probability η s_v a_uv. Before acceptance the source draw is exactly π_u. Conditional on a successful step, the source law is generally biased by acceptance; it must not be reset to π_u. Different steps use their own actual source draws; no assertion that a whole path has one common source or nested cubes is made.

Let H_r* be the adjoint kernel for du, and write o_r=H_r1, i_r=H_r*1. Since H_r≤P_r and the strict far supports of H_r and H_r* are disjoint,

                 H_r+H_r* ≤ P_r,
                 o_r(u)+i_r(u) ≤ 1.                               (4)

The first inequality is a kernel inequality, stronger than separate row/column capacities. It holds despite every asymmetric original gate and target-plan dependence: at most one orientation can survive for any (u,v), and each surviving density is bounded by the symmetric P density.

For any x∈L²(E_r,du), positive-kernel arithmetic gives

2|⟨x,H_rx⟩| ≤ ∫|x(u)|²[o_r(u)+i_r(u)]du ≤ ||x||².                 (5)

Consequently Re⟨x,(I−H_r)x⟩≥||x||²/2. This joint incident estimate does not lose a factor equal to the number of possible mass scales.

## 3. Finite-depth conservative flow, with endpoint costs retained

Set M_-=q_-a^n, M_+=λb^n and

N=ceil(log(M_+/M_-)/log K)=O(√n).

Any path with N accepted edges would have m_start>K^N m_end≥K^N M_-≥M_+, which is impossible. Thus H_r^N=0. In particular (I−H_r)^−1=Σ_{k=0}^{N−1}H_r^k and (5) implies the dimension-independent bound

                       ||(I−H_r)^−1||_{2→2} ≤ 2.                  (6)

Define actual entrance and termination densities

α_r=1−i_r,                 β_r=1−o_r.

Both are nonnegative; (4) also gives α_r≥o_r and β_r≥i_r. As measures,

             Σ_{k=0}^{N−1}(α_r du)H_r^k = du.                    (7)

This follows by telescoping α_r du=du−du H_r. Start paths with α_rdu, use the subprobability transition H_r, and terminate at u with probability β_r(u). Their total occupation is exactly du, edge occupation exactly du H_r, and terminal measure exactly β_rdu. Entrance and terminal total masses agree. This is a genuine conserved receiver flow, with the full-source sampling construction of §2 at every attempted step.

The original loss telescopes along those paths. Equivalently, direct Fubini gives the exact settlement

G_r := ∫du∫(m_u−m_v)H_r(u,dv)
     =∫m_u[α_r(u)−β_r(u)]du
     =∫f(y)∫_{E_r}c_u(y)[α_r(u)−β_r(u)]du dy.                     (8)

After integrating ℓ, define the signed endpoint center-load

B_end(y)=∫ℓ(dr)∫_{E_r}c_u(y)[α_r(u)−β_r(u)]du.

Then **G=∫f(y)B_end(y)dy**. All measures here are finite: m has positive lower and finite upper bounds, E has finite measure, and the clock has finite mass. The positive and negative endpoint terms may therefore be exchanged separately.

Equation (7) is not a terminal W payment. A decreasing path telescopes to its entrance mass minus its terminal mass; its length alone does not bound that difference by O(N) times the smaller terminal mass. Reversing the entire flow moves the same unresolved weighted load to the large terminal. This is a limitation of the proposed settlement, not a claim that further geometry cannot estimate it.

The direct center estimate only gives

B_end(y) ≤∫ℓ(dr) r^n = 1+n log(b/a)=A_n,

because 0≤α≤1 and all centers whose Q_u contains y and R_u≤r lie in a center cube of volume r^n. It yields G≤A_nW. The already proved source-clock baseline G≤X_q is usually preferable. Neither is the desired new root receipt.

## 4. An exact capture-square energy bound for this same cost

There is a second unconditional consequence retaining the full matching. Let

c_K=(√K+1)/(√K−1),
Q_flow=∫ℓ(dr)∫ f(y)/J_y(r)
                     [∫_{E_r} c_u(y)/√m_u du]²dy.                 (9)

Then

             0≤Q_flow≤X_q,
             G ≤ min{X_q, c_K(X_q−Q_flow)}.                       (10)

For each retained far edge,

m_u−m_v ≤ c_K(√m_u−√m_v)².

By (4), integrating its symmetric square against H is at most half its integral against P. Full matching and (3) give the exact Dirichlet identity

(1/2)∫du P_r(u,dv)(√m_u−√m_v)²
 =∫_{E_r}m_u du
  −∫ f(y)/J_y(r)[∫_{E_r}c_u(y)/√m_u du]²dy.                       (11)

The full physical tail ∫_[R_u,b]ℓ=R_u^−n implies
∫ℓ(dr)∫_{E_r}m_u du=X_q. This proves the second bound in (10); the first is the R381/R382 exact original-clock bound. The nonnegativity of (11) also proves Q_flow≤X_q.

This is an upper bound for the current positive remaining G and can replace its estimate in the ledger. Q_flow is **not** an additional free negative term to be added to the old BH square credit, nor to a previous payment of G. No such double counting is made here.

Sourcewise, with ν_{r,y}(du)=c_u(y)du/(m_uJ_y(r)), the integrand in (11) is f(y)J_y(r) Var_{ν_{r,y}}(√m_u). Thus the precise still-unproved source/geometry interface is a root-order estimate of this actual clock-integrated variance (or of the signed endpoint load in (8)), using full matching and remaining spatial gates. The constant-2 resolvent alone gives no such weighted estimate: its reference norm is L²(du), whereas (8) pairs a signed endpoint defect with m_u and then integrates the physical clock.

## 5. Cost accounting and bounded outcome

On the fixed fields and any fixed admissible source-exact plan, the existing R382 inequality remains

BH ≤ G + (η_old+σ_n)X_q + C338 W + already-chosen window prices.

Here G may already include the exact two-end outside-window factors. Equations (8) and (10) can substitute for this **one** G, with no additional template tariff or source price. If using (10), the substituted term is min{X_q,c_K(X_q−Q_flow)}; no other credit is altered. The general target εX_q+root-polylog W has not been established.

The completed new structure is the actual-source construction, the joint incident bound (4), the constant resolvent (6), and the exact matching/clock settlements (8)–(11). The unresolved part is the full-f weighted endpoint/variance estimate, not existence of a conservative receiver flow and not uncontrolled path multiplicity. No arbitrary translated cube has been added to the receiver family.

## 6. Actual exact checks

Ran locally: python3 /tmp/r383_geometry_check.py

PASS {'matching_marked_kernel': 162, 'flow_identity': 162,
      'incident_energy': 324} total 648 positive marked costs 102

Stage 1 computes m from the same full finite f, uses actual captured-cell target probability kernels with source-dependent tilts, keeps strict mass-past and J gates, and checks P normalization/reversibility and H+H*≤P. Stage 2 checks finite conserved occupation, endpoint equality and equal entrance/exit totals. Stage 3 checks the incident quadratic inequality, constant-2 inverse estimate on rational probes, and the exact Dirichlet/capture-square identity on rational test functions. All arithmetic is Fraction; no numerical fit is used.

These are finite source/receiver quadrature diagnostics, not native continuum dense-deep hard-gate examples. Their test ratios are rational. The universal original K=exp(√n), continuum, source-exact and clock assertions are proved analytically above. The tests do not replace the missing root-order estimate.
