#!/usr/bin/env python3
"""R383 true-dx receiver-row cost diagnostic. Stdlib exact geometry + ordinary MP evidence.
No old /tmp imports. mpmath 1.3.0 required; known local vendor fallback below.
"""
from fractions import Fraction as F
from decimal import Decimal, localcontext
from pathlib import Path
from functools import lru_cache
import hashlib, json, sys
try:
    import mpmath as mp
except ImportError:
    sys.path.insert(0, '/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor')
    import mpmath as mp
BASE=Path(__file__).resolve().parent
COUNTS={'exact_geometry':0,'exact_far':0,'mp_diagnostics':0}
def ck(v, category):
    assert v, category
    COUNTS[category]+=1

def fm(x): return mp.mpf(x.numerator)/x.denominator

def exp_bounds(k, terms=160):
    s=F(1); term=F(1)
    for j in range(1,terms+1):
        term*=F(k,j); s+=term
    nxt=term*F(k,terms+1)
    return s,s+nxt/(1-F(k,terms+2))

def tent(a,b):
    x,y=sorted((a,b)); return x*x*y-x*x*x/3
@lru_cache(None)
def overlap(a,b,r,s):
    U,u=(a+b)/2,abs(a-b)/2
    V,v=(r+s)/2,abs(r-s)/2
    return tent(U,V)-tent(U,v)-tent(u,V)+tent(u,v)
def trap(a,b,x): return max(F(0),min(a,b,(a+b)/2-abs(x)))
def independent(a,b,r,s):
    cuts=sorted(set((F(0),abs(a-b)/2,(a+b)/2,abs(r-s)/2,(r+s)/2)))
    total=F(0)
    for x,y in zip(cuts,cuts[1:]):
        fun=lambda z:trap(a,b,z)*trap(r,s,z)
        total+=(y-x)*(fun(x)+4*fun((x+y)/2)+fun(y))/3
    return total

def analyze(n,rmin,dps):
    mp.mp.dps=dps
    s=F(1,4*n); M=n; a=F(3,4); packet=(1-a)*rmin**n
    r=[rmin+(2-rmin)*F(j,M) for j in range(M+1)]
    outer=[x-s for x in r];inner=[F(0)]+outer[:-1]
    w=[x**n-y**n for x,y in zip(outer,inner)]
    m=[a*x**n+packet for x in r];q=[z/x**n for z,x in zip(m,r)]
    for j in range(M+1):
        ck(w[j]>0 and F(3,4)<=q[j]<=1 and q[0]==1,'exact_geometry')
        ck(outer[j]+s==r[j] and outer[j]+r[j]<4,'exact_geometry')
    lo,hi=exp_bounds(int(n**.5))
    far=[[False]*(M+1) for _ in r]
    for i in range(M+1):
        for j in range(i):
            rat=m[i]/m[j]; ck(rat<lo or rat>hi,'exact_far');far[i][j]=rat>hi
    hinc=[fm(x/y) for x,y in zip(w,m)];J=[];acc=mp.mpf(0)
    for t in hinc:acc+=t;J.append(acc)
    h=J[-1]/64;H=h
    ell=[fm(r[j]**(-n)-r[j+1]**(-n)) for j in range(M)]+[fm(r[-1]**(-n))]
    past=[sum((hinc[j] for j in range(i) if far[i][j]),mp.mpf(0)) for i in range(M+1)]
    clock=[sum((ell[k]/J[k] for k in range(i,M+1) if J[k]>=H),mp.mpf(0)) if past[i]>h else mp.mpf(0) for i in range(M+1)]
    surplus=[fm(packet*(1-(s/r[j])**n)/m[j]) for j in range(M+1)]
    matrix=[[mp.mpf(0)]*(M+1) for _ in r]
    for i in range(M+1):
        for j in range(i):
            if not far[i][j] or not clock[i]:continue
            prod=(fm(overlap(outer[i],outer[j],r[i],r[j]))**n-fm(overlap(inner[i],outer[j],r[i],r[j]))**n-fm(overlap(outer[i],inner[j],r[i],r[j]))**n+fm(overlap(inner[i],inner[j],r[i],r[j]))**n)
            p=prod/fm(w[i]*w[j]*r[j]**n)
            ck(0<=p<=1,'mp_diagnostics')
            matrix[i][j]=fm(w[i]*w[j])*surplus[j]*fm(1-m[j]/m[i])*clock[i]*(1-p)
    row=[sum(x) for x in matrix];B=sum(row);X=fm(sum((x*y for x,y in zip(w,q)),F(0)));W=fm(a*4**n+packet)
    budget=[fm(x*y) for x,y in zip(w,q)];density=[x/y for x,y in zip(row,budget)]
    splits={}
    for ep in [F(1,10),F(1,100),F(1,1000)]:
        eps=fm(ep);paid=sum(min(c,eps*b) for c,b in zip(row,budget));res=[max(mp.mpf(0),c-eps*b) for c,b in zip(row,budget)]
        lowcost=sum(c for c,z in zip(row,density) if z<=eps)
        cols=[sum((matrix[i][j]*(res[i]/row[i]) for i in range(M+1) if row[i]),mp.mpf(0)) for j in range(M+1)]
        ck(abs(B-paid-sum(res))<mp.mpf(10)**(-dps+12)*max(1,B),'mp_diagnostics')
        ck(paid<=eps*X and abs(sum(cols)-sum(res))<mp.mpf(10)**(-dps+12)*max(1,B),'mp_diagnostics')
        splits[str(ep)]={'absorbed_cost':paid,'absorbed_fraction':paid/B if B else mp.mpf(0),'residual_cost':sum(res),'residual_over_Xq':sum(res)/X,'residual_over_W':sum(res)/W,'low_row_full_cost':lowcost,'high_row_count':sum(z>eps for z in density),'residual_small_v_spectrum':cols}
    rows=[]
    for i in range(M+1):
        if not row[i]:continue
        bound=fm(packet/m[i])*past[i]/J[i]
        ck(density[i]<=bound+mp.mpf(10)**(-dps+10),'mp_diagnostics')
        rows.append({'row_density_upper':bound,'fraction_of_row_upper':density[i]/bound if bound else mp.mpf(0),'i':i,'m':fm(m[i]),'q':fm(q[i]),'row_cost':row[i],'q_volume':budget[i],'row_density':density[i],'packet_mass_over_mu':fm(packet/m[i]),'cost_weighted_small_v_surplus':sum(matrix[i][j]*surplus[j] for j in range(M+1))/row[i],'J_i_over_Jfinal':J[i]/J[-1],'strict_past_over_J_i':past[i]/J[i]})
    ck(B>=0 and all(x>=0 for x in row),'mp_diagnostics')
    return {'n':n,'r_min':str(rmin),'background_density':str(a),'packet_mass':str(packet),'sourcepacket_side':str(s),'full_W':W,'Xq':X,'Jcentral':J[-1],'h_H_diagnostic':h,'max_strict_past_over_h':max(past)/h,'B':B,'B_over_Xq':B/X,'B_over_W':B/W,'max_row_density':max(density),'cost_weighted_incoming_surplus':sum((matrix[i][j]*surplus[j] for i in range(M+1) for j in range(M+1)),mp.mpf(0))/B if B else mp.mpf(0),'cost_weighted_packet_mass_over_mu':sum((row[i]*fm(packet/m[i]) for i in range(M+1)),mp.mpf(0))/B if B else mp.mpf(0),'positive_row_count':len(rows),'native_massfar_pair_count':sum(map(sum,far)),'log10_mass_range':mp.log10(fm(m[-1]/m[0])),'matched_masses':[fm(t) for t in m],'incoming_surplus_fractions':surplus,'original_small_v_spectrum':[sum(matrix[i][j] for i in range(M+1)) for j in range(M+1)],'splits':splits,'positive_rows':rows}

def js(obj):
    if isinstance(obj,dict):return {k:js(v) for k,v in obj.items()}
    if isinstance(obj,list):return [js(v) for v in obj]
    if isinstance(obj,mp.mpf):return mp.nstr(obj,32)
    return obj

def main():
    cases=[]
    specs=[('baseline',4,F(1)),('baseline',16,F(1)),('baseline',64,F(1)),('parameter_pressure',16,F(5,4)),('parameter_pressure',16,F(3,2)),('expanded',64,F(5,4)),('expanded',64,F(3,2))]
    for stage,n,rmin in specs:
        a=analyze(n,rmin,50);b=analyze(n,rmin,80)
        err=max(abs(a[k]-b[k])/max(abs(b[k]),mp.mpf('1e-100')) for k in ['B','max_row_density','Jcentral'])
        ck(err<mp.mpf('1e-39'),'mp_diagnostics');b['relative_50_80_difference']=err;b['stage']=stage;cases.append(b)
        print(stage,n,str(rmin),'B/X',mp.nstr(b['B_over_Xq'],8),'maxrow',mp.nstr(b['max_row_density'],8),flush=True)
    result={'scope':'Genuine positive L1 source and real dx receiver shells, actual q<=lambda and same-full-f matching/cap, not historical FIRST qualification. Geometry-relaxed product-surplus bad only: physical clock/J/strict massfar retained, outside/deep/history masks omitted. H=h=J/64 is diagnostic and not synchronized total ledger. MP50/80 ordinary evidence, not intervals. No source or receiver weights independently adjusted.', 'counts':COUNTS,'cases':cases,'dependency':'mpmath1.3.0; existing local vendor fallback if default import unavailable'}
    (BASE/'r383_numeric.result.json').write_text(json.dumps(js(result),indent=2)+'\n')
    print(json.dumps(COUNTS))
if __name__=='__main__':main()
