# R383: actual receiver-row density, not coverage fraction alone

This uses the R382 real-dx shell construction, copied into one self-contained script with no old /tmp imports. It freezes the full actual f/q/m/clock field for each case, then diagnoses its geometry-relaxed product-surplus bad matrix. Outside/deep/history and other remaining-pair masks are omitted. Actual q<=lambda and same-full-f matching/cap are realized; historical first-crossing/old-selector qualification is not certified. It is not a native remainder or a general root bound.

## Three bounded stages and true geometry

Set a=lambda=1,b=2, sourcepacket side s=1/(4n), background density a0=3/4, and

f=a0 1_Q4 + P s^(-n)1_Qs.

For n+1 radii r_j=rmin+(2-rmin)j/n, take P=(1-a0)rmin^n and actual shells E_j=Q_(r_j-s) minus the previous outer cube (inner side zero for j=0). All actual Q_(r_j)(u), u in E_j, contain Q_s and are inside Q4. Thus actual m_j=a0 r_j^n+P, q_j=a0+P/r_j^n is exactly in [3/4,1], with q_0=1. All selected hard averages are <=lambda<4lambda. No source or receiver weight is independently adjusted. The full mass W=a0 4^n+P, actual receiver volume, q-weighted Xq, actual matched masses and original source-end spectra are retained.

Stage 1 reproduces n=4,16,64, rmin=1. Stage 2 changes the sourcepacket/background ratio through rmin=5/4,3/2 at n16, with the above required q-band adjustment of P. Stage 3 repeats those pressures at n64. There are seven cases, and up to 65 distinct actual masses per case. No optimizer or further fixture search is used.

The physical mass-far test uses K=exp(sqrt(n)) with exact rational Taylor brackets. The sourcepacket has common J_i=sum_(j<=i)|E_j|/m_j and strict past_i=sum_(m_j<m_i/K)|E_j|/m_j. Each case selects **diagnostic H=h=J_final/64**. This is not the synchronized R379 epsilon0/h, and no global H entrance budget is asserted. No synchronized high-past reachability conclusion follows from this cost table.

The physical clock weights include the continuous intervals and terminal b atom, exactly as in R382. Source surplus d_v=P[1-(s/r_v)^n]/m_v is fully integrated over its complete support Q_s. Receiver-pair target capture is the exact tensor shell inclusion-exclusion of interval-overlap products; no receiver/source sampling replaces dx or source integrals. Ordinary MP50/80 arithmetic evaluates its powers/costs; this is not an interval certificate. All baseline R382 costs reproduce.

## Positive row split and mechanism

Here a numerical row is a whole-shell block average, not the pointwise A_u of the receiver absorption theorem. This diagnostic does not compute the pointwise sets Y_u or that theorem’s exact G_core. Its proportional cost splitting is a legitimate positive restriction of the whole-shell traffic.

Let B_i=sum_v B_iv and X_i=q_i|E_i|. For each epsilon=1/10,1/100,1/1000, use

paid_i=min(B_i,epsilon X_i), residual_i=(B_i-epsilon X_i)_+.

This is an exact positive decomposition at the mathematical level; the executable checks it to ordinary MP precision, sums paid<=epsilon Xq, and attributes each row's residual proportionally to its original small-v entries. It also separately records full cost on rows B_i<=epsilon X_i and high-row counts. Thus no row/source cost is silently discarded or double counted. Source-end residual spectra, matched masses and surplus fractions are in the small JSON.

For this particular shell/source model a useful cancellation is

B_i/X_i <= (P/m_i) (past_i/J_i).

Indeed d_v<=P/m_v, all other mass-gap/capture factors are <=1, and the clock tail is <=r_i^(-n)/J_i. Substitution gives the displayed expression. The executable checks it on every positive row at both precisions. This is a model-specific explanatory bound, not a new universal receiver-density theorem.

| n | rmin | B/Xq | max_i B_i/X_i | epsilon=.001 residual/Xq |
|---|---|---:|---:|---:|
| 4 | 1 | 1.24363e-3 | 3.03950e-3 | 8.34472e-4 |
| 16 | 1 | 1.11636e-5 | 7.65508e-4 | 0 |
| 64 | 1 | 2.81005e-19 | 8.34946e-6 | 0 |
| 16 | 5/4 | 1.51968e-4 | 4.73916e-4 | 0 |
| 16 | 3/2 | 2.70392e-4 | 6.85354e-4 | 0 |
| 64 | 5/4 | 2.56365e-13 | 7.17407e-6 | 0 |
| 64 | 3/2 | 1.10208e-8 | 6.43260e-6 | 0 |

At epsilon=.1 or .01 all seven cases are wholly paid. At epsilon=.001 only n4 retains a row; its paid fraction is .3290013, leaving .6709987 of its cost. Its residual spectrum is entirely the smallest-v mass. All other cases are individually row-paid, a stronger statement than merely B<=epsilon Xq.

For n64,rmin=1 the maximal-density row has P/m_u=7.34010e-5 and past/J_i=.120750, yielding the upper 8.86319e-6; actual density is 94.20% of that upper. Its cost-weighted incoming surplus is .25, so calling its incoming surplus small would be misleading. At the complete-cost level the incoming surplus mean is .0278201. The corresponding maximal-density row values for rmin=5/4,3/2 preserve P/m_u=7.34010e-5, while past/J_i decreases to .105230 and .0953609; actual densities are 92.88% and 91.90% of their bounds. Thus the small row density is closely explained by upper-receiver mass normalization and the past/J factor, even after greatly increasing P.

The pressure increases n64 total B/Xq from 2.81e-19 to 1.10e-8, but still does not produce a row costing .001 X_i. Moreover full B/W remains 1.34417e-38, 1.22631e-32, 5.27173e-28 at rmin=1,5/4,3/2. Full W is enormous, never replaced by P. Broader endpoint spectra therefore do not make these inputs difficult for an epsilon Xq+root W objective. The data support investigating how real source mass and receiver normalization suppress row cost, rather than insisting on complete window coverage. They do not prove this mechanism for general inputs or synchronized native gates.

## Reproduction and evidence counts

Run:

`/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 r383_numeric.py`

It writes `r383_numeric.result.json` beside itself. The executable is self-contained as to models/helpers and uses standard library plus **mpmath 1.3.0**. On this machine bundled Python has no default mpmath; runs use the existing local vendor fallback `/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor`. Another environment may use `python3 -m pip install mpmath==1.3.0` or an existing PYTHONPATH. No third-party vendor archive is required. MP50/80 relative differences are below 1e-39. A fresh process was run twice and result bytes match.

Final executed assertions: **14,320 exact Fraction** (1,004 actual geometry/q-band checks, 13,316 exact mass-far classifications), separately **7,115 ordinary MP diagnostics**. Both precision passes are included in counts; these are execution counts, not independent theorems. No claim that MP assertions are exact, or that diagnostic H/h and omitted geometry/history have been paid. No repository or other-agent file changes.
