# R481 FINAL PASS（仅限已列明结论）

独立预审先于作者稿阅读；本次终审核对全部七项冻结输入。PASS 认证真实中心短边价格、长边归一化二次势及条件恢复、径向松弛量积分和质量势比较，不认证完整原流根阶付款。

短边从实际 pair 投影正上放，得到 F≤S²b_nX/T，η=1/32 时 b_n<3^{-n}；完整恢复必须保留 Δ_ℓ=Δ+F 及 Cη=257。新版全维数回代以已证 R≤SA_nW 支付 (log r/n)R，故 R≤2w_ℓ/η²+εX/2+C_{ε,r,S}√nW，无低维遗漏，也未假定有符号 w_ℓ 非负。实际 work 的式(10)尚未证明，原母账及其他未付积分仍保留，一般目标未闭合。

附件的三段 selector 包络给精确 C_n=1/(n+1)+(n/(n+1))^{n+1}log(b/a)，含 a=b 基项；同参考端点误差给 |W_α/n−∫|a_x−b_x|²/(2n)|≤Δ_α/8+ℒ/2。该式未支付二端相关。质量势 proper 后继 Green 比较与 Q log_+(QT/(rSR))≤TD_mW 合法，但仅支持所述线性维数诊断，不提供无权完整流量价。

实际复现：在独立临时目录使用指定 Python，提取三个正文内嵌脚本并运行 numeric.py；22、50、108、84 项检查全部通过，四段 stdout 与 replay 逐字一致。numeric JSON 仅剔除 compute_index.seconds 后全字段一致，canonical SHA256 为 bf24378b7d006f23850067ff006b08b99aa98c775b0eb20fc1466424f6350b72。有限核验分别为解析/标量系数及一维匹配中心接口，不认证原完整 history；未运行 LP 或编译 PDF。

冻结输入 SHA256：

- `r481_main.md`: `83544e5e7691cd3d366002bdd7c4f6a807941f976f6e32d102122f47a82af524`
- `r481_geometry.md`: `89e25368496036855aba8e08f2c24cdaa6a073c7b682f222fafb2befaa7345c8`
- `r481_complement.md`: `e33124246200559914d07f73480e753ddee5eb74581bbe20055a01de705a111a`
- `r481_numeric.md`: `d1452491b440f0500d5b8cd1c165053cead1482f51ba28897e3acaf7c9301bfb`
- `r481_numeric.py`: `79cee743ba474a25f94c854a6268baa7b6578f1aa8907074b2262c2d253887ae`
- `r481_numeric.json`: `f1cb5591145120da99dab3ebeafc66f9db28c8e9654ff615a17217df35def6c7`
- `r481_replay.json`: `4db5488b9f54698cac97bf9833f00f96b48bffbd1553b905ced9de477306436a`
