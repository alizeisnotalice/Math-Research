from fractions import Fraction as F
from pathlib import Path
from math import factorial
import sys,platform,json,time
import sympy as sp
from flint import arb,ctx
ROOT=Path(__file__).resolve().parent;ctx.prec=256
start=time.perf_counter();checks=0

def ck(v):
 global checks
 assert v
 checks+=1

def ar(v):
 v=F(v);return arb(v.numerator)/v.denominator
eta=F(1,32);pi=arb.pi();ee=arb(1).exp()
# Exact e upper estimate: sum to5 plus geometric bound on tail from6.
e_upper=sum((F(1,factorial(j)) for j in range(6)),F(0))+F(7,6*factorial(6))
ck(e_upper<F(11,4));ck(ee<ar(e_upper));ck(pi<ar(F(22,7)))
base=2*ar(eta)*(2*pi*ee).sqrt()
base2_rational=F(121,1792) # 2*(22/7)*(11/4)/16^2
ck(base**2<ar(base2_rational));ck(base2_rational<F(1,9));ck(base<ar(F(1,3)))
# Gaussian volume inequality is supplied/proved in the main geometry text;
# here only its arithmetic constant and the listed exact volumes are checked.
n,e,W,L,D,H,Q=sp.symbols('n e W L D H Q',positive=True)
# E<=2work+n*(Delta+short)/4+2n*L and E>=eta^2*n*Q.
work=sp.symbols('work',nonnegative=True)
expr=(2*work+n*(D+H)/4+2*n*L)/(e**2*n)
target=2*work/(e**2*n)+(D+H)/(4*e**2)+2*L/e**2
ck(sp.cancel(expr-target)==0)
ck(sp.diff(target,H)==1/(4*e**2));ck(sp.diff(target,D)==1/(4*e**2))
ck(F(1,4)/eta**2==256);ck(F(2)/eta**2==2048)
rows=[]
for nn in (1,2,4,8,16,64,256,1024):
 if nn==1:
  exact_coefficient=4*eta;bn=ar(exact_coefficient);power_pi=0
  ck(exact_coefficient==F(1,8))
 else:
  power_pi=nn//2
  exact_coefficient=(2*eta)**nn*F(nn**power_pi,factorial(power_pi))
  bn=ar(exact_coefficient)*pi**power_pi
 upper=base**nn;third=ar(F(1,3**nn))
 ck(bn>0);ck(bn<upper);ck(upper<third)
 # The work coefficient retains n; Delta/short and L coefficients do not.
 cw=F(2,nn)/eta**2;cd=F(1,4)/eta**2;cl=F(2)/eta**2
 ck(cw==F(2048,nn));ck(cd==256);ck(cl==2048)
 # Exact zero/base and short-only coefficient witnesses, not geometry.
 for ww,dd,hh,ll in [(F(0),F(0),F(1,7),F(0)),(F(2,3),F(1,5),F(0),F(1,11)),(F(1),F(0),F(0),F(0))]:
  dprime=dd+hh;upperE=2*ww+F(nn,4)*dprime+2*nn*ll
  exactQ=upperE/(eta**2*nn)
  ck(exactQ==cw*ww+cd*dprime+cl*ll)
 rows.append(dict(n=nn,phase='initial' if nn<=2 else ('coefficient_pressure' if nn<=16 else 'expanded'),eta=str(eta),exact_b_coefficient=str(exact_coefficient),exact_pi_power=power_pi,bn=str(bn),gaussian_envelope=str(upper),one_third_power=str(third),b_over_third_power=str(bn/third),log10_bn=str(bn.log()/arb(10).log()),short_deficit_fee_coefficient_times_S_over_T=str(256*bn),Qlong_coefficients=dict(work=str(cw),Delta_prime=str(cd),L=str(cl)),Delta_prime='Delta+short',scope='Euclidean volume and scalar algebra only; actual pair short-cost estimate is supplied by main proof'))
result=dict(scope='No LP. Gaussian-volume arithmetic and long-edge coefficient certificate only; no actual cube/history success claim.',compute_index=dict(executable=sys.executable,python=platform.python_version(),sympy=sp.__version__,arb_precision_bits=ctx.prec,command='"'+sys.executable+'" r481_numeric.py',seconds=time.perf_counter()-start),checks=checks,constants=dict(eta='1/32',gaussian_base=str(base),base_squared_rational_upper=str(base2_rational),exact_e_upper=str(e_upper),pi_upper='22/7',e_coarse_upper='11/4',general_comparison='Assuming vol(B2^n)<= (2*pi*e/n)^(n/2), b_n<=base^n<(1/3)^n for every n>=1'),formula=dict(bn='vol(unit Euclidean nball)*(2*eta*sqrt(n))^n',raw_short_bound='short<=(S/T)*bn*R (geometric theorem supplied externally)',long_energy_lower='E>=eta^2*n*Qlong',deficit='Delta_prime=Delta+short',upper_energy='E<=2*worklong+n*Delta_prime/4+2*n*L',Qlong='Qlong<=2*worklong/(eta^2*n)+Delta_prime/(4*eta^2)+2*L/eta^2',short_substitution_fee='[bn/(4*eta^2)]*(S/T)*R =256*bn*(S/T)*R'),cases=rows,exactness='Listed volumes use exact rational coefficient times integer power of pi; finite interval diagnostics are 256-bit Arb. Scalar coefficients and witnesses exact Fraction/SymPy. General Gaussian volume proof and actual short-edge pair measure estimate are not inferred from these samples.')
(ROOT/'r481_numeric.json').write_text(json.dumps(result,indent=2)+'\n')
print('PASS',checks,'checks;8 dimensions, Gaussian constants and long-edge scalar coefficients only; no LP/history claim')
