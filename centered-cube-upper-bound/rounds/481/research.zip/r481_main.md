# 第481轮：真实中心短边预算与全流二次势的维数修复

## 结论和范围

对第479轮同一成功流，短欧氏位移可由真实接收中心Lebesgue体积直接支付；其补集有维数n量级的位移能量。将第480轮精确二次势应用于此补集并除以n，消除了此前nΔ的费用放大。这是任意正L1输入下的同流估计，不是特殊函数例，也没有使用来源密度帽。

修复后所有显式几何误差可纳入 εX+C_{ε,r,S}√n W；尚有一个明确的实际来源—位移相关积分未控。因此一般一致弱型上界未闭合。本轮并未声称源相关积分已支付，也没有以有限数值代替一般证明。

## 1. 冻结原始入口

μ=f dx，f≥0，W=∫f<∞，真实中心A，a≤R_A≤b≤2a，m_A=μ(Q_A)=q_AR_A^n，q≤q_A≤λ，r=λ/q≥1。σ=q_A dA，π_A=1_{Q_A}μ/m_A，X=σ(E)，S固定。原记录Π投影为ℓσπ_A²，0≤ℓ≤S，t(A)=∫ℓdπ_A²，R=|Π|≤SX。Π保留原阶段、时钟、旧双来源、early、future、soft和质量路径条件。W=0或S=0时为零流。

附x∼π_A及uniform mark后，原父—来源参考ν=t(A)σ(dA)π_A(dx)，质量R。质量对数带宽L_b=√n，D_m=logr+nlog(b/a)，带数N≤1+D_m/√n，𝓜≤NW。选择0<τ≤S、0<δ≤1/4，H=S/τ，T=1024rS²/(τδ)，κ=8log(4/δ)。

第479轮成功流Ω=Ψ_ext质量Q、两端父—来源边缘≤同一ν，旧来源在保留父族之外，double-center-external。Δ=R−Q满足
\[
Δ≤[τ+δS+2rS²/T]X+κT𝓜. \tag{1}
\]
其半径费用
\[
\mathcal L=\int_Ω|\log(R_A/R_B)|
≤\frac{TD_m}{n}W+\frac{\log r}{n}R. \tag{2}
\]
本轮仅正限制同一Ω，不改变t、秩、原条件或原质量。

## 2. 同一成功pair的实际中心支配

给定原(A,x,mark)，raw最大父律为e^{−(v−w)/T}dF_{j,x}(B)ds_B/T，w<v，其中dF=t(B)1_{Q_B}(x)σ(dB)/m_B。所有成功筛选只降低测度。积分原记录和marks，再去掉指数及秩门，仅用于非负上界，得到
\[
 dΩ(A,B,x)≤\frac{t(A)t(B)}{T}
 \frac{1_{Q_A}(x)1_{Q_B}(x)}{m_A m_B}
 σ(dA)σ(dB)μ(dx). \tag{3}
\]
这不是将旧record换成新record；Ω的其余标签仍保留。式(3)只陈述其pair投影的上支配。

取η=1/32，短边集合D={|B−A|_2<η√n R_A}，F=|Ω|_D，长边Ω_ℓ=Ω|_{D^c}，Q_ℓ=Q−F，Δ_ℓ=R−Q_ℓ=Δ+F。由于R_B≥R_A/2且σ(dB)/m_B=R_B^{−n}dB，对任意实际(A,x)，
\[
\int_D t(B)1_{Q_B}(x)\frac{σ(dB)}{m_B}
≤S(2/R_A)^n\,|B_2^n(0,η√n R_A)|=S b_n,
\quad b_n=|B_2^n|(2η√n)^n.
\]
因此
\[
F≤\frac{S b_n}{T}R≤\frac{S²b_n}{T}X. \tag{4}
\]
这里小的是接收中心体积，来源μ从未被Lebesgue体积替代。

Gaussian体积界可直接证明：对任意u>0，1_{|z|≤1}≤exp(u−u|z|²)，故|B_2^n|≤e^u(π/u)^{n/2}；取u=n/2得到|B_2^n|≤(2πe/n)^{n/2}。于是
\[
b_n≤(2η√{2πe})^n<3^{-n}. \tag{5}
\]
最后常数只需π<4、e<3：基数平方=8η²πe<3/32<1/9。一般界来自此解析证明，八个维度的区间计算仅校验常数和实现。

## 3. 长边二次势与完整恢复

置z=(x−A)/R_A，d=(B−A)/R_A，ρ=R_A/R_B，h(C,x)=|x−C|²/R_C²∈[0,n/4]。逐点
\[
|d|²−2z\cdot d=h(B,x)−h(A,x)+(ρ^{-2}−1)h(B,x).
\]
Ω_ℓ两端仍≤ν，且各自缺额恰Δ_ℓ，因h在[0,n/4]内，势差绝对值≤nΔ_ℓ/4。单octave内|ρ^{−2}−1|≤8|logρ|，故若
\[
w_ℓ:=\frac1n\int_{Ω_ℓ}z\cdot d,
\]
则
\[
\int_{Ω_ℓ}|d|²≤2nw_ℓ+nΔ_ℓ/4+2n\mathcal L.
\]
长边支持给左侧≥η²nQ_ℓ，因此
\[
Q_ℓ≤\frac{2}{η²}w_ℓ+\frac{Δ_ℓ}{4η²}+\frac{2}{η²}\mathcal L. \tag{6}
\]
与第480轮相比，Δ_ℓ和半径误差不再乘n。恢复R必须把被删质量也加回来：记C_η=1+1/(4η²)=257，
\[
R≤\frac{2}{η²}w_ℓ+C_ηΔ_ℓ+\frac{2}{η²}\mathcal L. \tag{7}
\]
用F≤S²b_nX/T而不是默认为零，令
\[
α=τ+δS+2rS²/T+S²b_n/T.
\]
(1)—(7)给完整同流结算
\[
\left(1-\frac{2\log r}{η²n}\right)R
≤\frac{2}{η²}w_ℓ+C_ηαX+
\left[C_ηκTN+\frac{2TD_m}{η²n}\right]W. \tag{8}
\]
替代做法若保F≤(Sb_n/T)R，左边还要扣C_ηSb_n/T，不能遗漏。本稿固定使用(8)。

## 4. 参数和全部显式费用

任取ε>0，固定
\[
τ=\min\{S,ε/(8C_η)\},\qquad
δ=\min\{1/4,ε/(8C_ηS)\}.
\]
T仍按原合同定义，不自由降低。因r≥1、δ≤1/4、b_n≤1/3，
\[
2rS²/T=τδ/512,\quad S²b_n/T≤τδ/(3072r),
\quad α≤2τ+δS≤3ε/(8C_η).
\]
不必再按维数拆分或吸收式(8)的R项。原已证R≤SA_nW、A_n=1+nlog(b/a)，直接给
\[
\mathcal L≤\left[\frac{TD_m}{n}+\frac{S\log r\,A_n}{n}\right]W
≤[T(\log r+\log2)+S\log r(1+\log2)]W.
\]
将此式直接代回(7)，同时N≤1+logr/√n+√nlog2，得到对所有n≥1成立的统一估计
\[
\boxed{R≤\frac{2}{η²}w_ℓ+\frac ε2X+C_{ε,r,S}\sqrt n\,W.} \tag{9}
\]
可取
\[
C_{ε,r,S}=C_ηκT(1+\log r+\log2)
 +\frac2{η²}[T(\log r+\log2)+S\log r(1+\log2)].
\]
这里用线性维数工具支付已经除以n的半径误差，没有用它替代目标主积分；全部常数仅依ε,r,S，所有维数均覆盖。

w_ℓ为有符号实际积分；(9)本身没有假定它非负。若以后证明
\[
w_ℓ≤\frac{η²ε}{4}X+C_{ε,r,S}\sqrt nW, \tag{10}
\]
才可把(9)回代为本轮原R的εX+根阶预算。式(10)尚未证明。旧母账乘数和所有其他未付积分仍须另外汇总吸收，(9)没有自动认证全局总账。

## 5. 仍须解决的真实几何相关

令a=(x−A)/R_A、b=(x−B)/R_B，则
\[
w_ℓ=\frac1n\int_{Ω_ℓ}(|a|²−ρ^{-1}a\cdot b).
\]
第二项含实际选择与成功权，不能按中心对称或来源独立性置零。单端共同参考只给单端矩，不给pair相关；原Schur估计也不能未经证明移植到此带符号核。

辅助附件保留一个实际径向slack的O(W)预算及质量加权最大父估计，分别说明其对切向相关仍欠哪一步。它们不等于(10)。主要新收益是短边已付款且长边恢复的显式误差降至根阶，后续应直接控制归一化相关而非再承担人为nΔ。

原宽距离、低pe、初始、跳跃、未来被删来源、极端尺度和全尺度拼接仍完整保留。一般n^(1/2+o(1))弱型上界尚未证明。

## 6. 验证与交付

指定本机独立Python，数值附件实际84项检查，包括8个维度、Arb包围、有理Gaussian常数和SymPy恢复系数；有限维数检查不能外推一般式(5)。主稿另有27组参数共108项有理账目复核；几何/辅助附件另列实际运行的检查。最终独审及隔离复现与SHA绑定随包。仅归档详细LaTeX文本和必要复现，不编译PDF。限定历史索引未在470—480轮定位同一短边体积机制，不宣称全面查无先例。

主稿参数账的有限有理复核（一般不等式已在第4节逐项证明）：

```python
from fractions import Fraction as F
eta=F(1,32); C=1+1/(4*eta*eta); checks=0
for eps in [F(1,100),F(1,2),F(4)]:
 for S in [F(1,100),F(1),F(100)]:
  for r in [F(1),F(2),F(100)]:
   tau=min(S,eps/(8*C));delta=min(F(1,4),eps/(8*C*S))
   T=1024*r*S*S/(tau*delta)
   alpha=tau+delta*S+2*r*S*S/T+S*S/(3*T)
   assert alpha<=2*tau+delta*S
   assert C*alpha<=3*eps/8
   assert C*alpha<=eps/2
   assert 2/eta**2*(eta**2*eps/4)==eps/2
   checks+=4
print(f'PASS {checks} exact Fraction parameter-account assertions; 27 parameter triples, not a full-flow certificate.')
```
