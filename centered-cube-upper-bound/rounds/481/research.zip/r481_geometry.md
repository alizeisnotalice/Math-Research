# R481：真实来源径向松弛量与长边上的归一化平移势

## 1. 冻结原流与本轮结论

保留 R479 的同一 \(\Omega=\Psi_{\rm ext}\)，包括原 \(A,y,z\)、人工 \(x\)、最大父 \(B\)、全部族及原历史。\(\mu=f\,dx\)，\(m_A=q_AR_A^n\)，\(q\le q_A\le\lambda\)，\(a\le R_A\le b\le2a\)，\(r=\lambda/q\)，\(\sigma=q_A\,dA\)，\(\pi_A=c_A\mu/m_A\)。原父接受边缘为 \(t(A)\sigma(dA)\)，\(0\le t\le S\)，\(R=|\Pi|\)、\(Q=|\Omega|\)、\(X=\sigma(E)\)。两端 \((A,x,j)\)、\((B,x,j)\) 均由同一
\[
 \nu(dA,dx,j)=1_{J_j}(A)t(A)\sigma(dA)\pi_A(dx)
\]
支配。\(\Delta=R-Q\) 及 \(\mathcal L=\int_\Omega|\log(R_A/R_B)|\) 已分别有根阶加显式 \(X\) 价、以及 \(O(W)\) 价，具体常数沿用 R479。Poisson 参数 \(T=1024rS(S/\tau)/\delta\) 不改。

本稿证明一个全来源径向松弛量的精确 \(O(W)\) 界，并核清短边剔除后平方势的维数修复。二者仍未控制同一成功流的二端来源相关，故没有证明完整 \(Q\) 的根阶预算。

## 2. 任意实际选择器的精确径向松弛量预算

定义有界非二次量
\[
 s_A(x)=1-\frac{2\|A-x\|_\infty}{R_A},\qquad x\in Q_A.
\]
对任意可测实际边长选择器，任意固定 \(x\)，都有
\[
 \int_E\frac{c_A(x)}{R_A^n}s_A(x)\,dA
 \le C_n(a,b):=\frac1{n+1}
 +\left(\frac n{n+1}\right)^{n+1}\log(b/a).
\tag{1}
\]
**证明。** 令 \(u=2\|A-x\|_\infty\)。中心子水平体积精确为 \(u^n\)。在 \(a\le R\le b\)、\(R\ge u\) 下，\(R^{-n}(1-u/R)\) 的最大值取于
\(R=\operatorname{clip}((n+1)u/n,a,b)\)。记 \(c=n/(n+1)\)。故包络分为 \(0\le u\le ca\)、\(ca<u<cb\)、\(cb\le u\le b\) 三段，分别为
\[
 a^{-n}(1-u/a),\qquad \frac{c^n}{n+1}u^{-n},\qquad
 b^{-n}(1-u/b).
\]
外面为0。对 \(d(u^n)=nu^{n-1}du\) 积分，首末段之和是 \(1/(n+1)\)：各自出现的 \(c^n(1-c^2)\) 恰好相消；中段是 \(c^{n+1}\log(b/a)\)。这证明 (1)，包括 \(a=b\) 时的固定边长基项。只在上界取包络，没有逐来源重建实际选择器或原流。

由 \(\sigma/m_A=R_A^{-n}dA\)、\(t\le S\) 及 Tonelli，
\[
 \int s_A(x)\,d\nu\le SC_nW,
 \qquad
 \boxed{\int_\Omega[s_A(x)+s_B(x)]\le2SC_nW.}\tag{2}
\]
因此任意 \(\varepsilon_c>0\)，实际正支 \(s_A(x)\ge\varepsilon_c\) 或 \(s_B(x)\ge\varepsilon_c\) 的质量至多 \(2SC_nW/\varepsilon_c\)。例如 \(\varepsilon_c=(1+\sqrt n)^{-1}\) 给根阶来源价。这是可用的辅助收据；本稿没有将它与其他分支重复收费。余下两端都接近各自真实立方体的某个面，但这只控制径向松弛量，不控制切向位移或任意集中 \(f\) 的边界质量。

## 3. 同一流的欧氏短边价格修复了二次势的维数损失

固定 \(0<\alpha<1/10\)。原最大父的次概率律由 Poisson 计数律支配；删除正限制后，实际父对上界为
\[
 \frac1Tt(A)t(B)\frac{I_{AB}}{m_Am_B}\,d\sigma(A)d\sigma(B),
 \qquad I_{AB}=\mu(Q_A\cap Q_B),\quad m_B\le m_A.
\tag{3}
\]
对 \(|B-A|_2\le\alpha\sqrt nR_A\)，先用 \(I_{AB}/m_A\le1\)、\(t(B)\le S\)、\(\sigma(dB)/m_B=R_B^{-n}dB\)、\(R_B\ge R_A/2\)。欧氏球体积满足
\[
 |B_2(0,\alpha\sqrt nR_A)|
 \le(\sqrt{2\pi e}\,\alpha R_A)^n,
\]
可由球内 \(e^{-n|u|^2/(2r_*^2)}\ge e^{-n/2}\) 并积分全空间 Gaussian 直接得到。因此短边正支质量 \(Q_{\rm sh}\) 满足
\[
 Q_{\rm sh}\le\frac ST(2\sqrt{2\pi e}\,\alpha)^nR
 \le\frac{S^2}{T}(10\alpha)^nX.\tag{4}
\]
取 \(\alpha=1/20\) 时上界为 \(S^2 2^{-n}X/T\)。没有用来源密度帽。

令 \(\Omega_\alpha\) 为同一流的长边正限制，\(Q_\alpha=|\Omega_\alpha|\)、\(\Delta_\alpha=R-Q_\alpha=\Delta+Q_{\rm sh}\)。设
\[
 a_x=(x-A)/R_A,\quad b_x=(x-B)/R_B,\quad
 d=(B-A)/R_A,\quad\rho=R_A/R_B,
\quad \mathcal W_\alpha=\int_{\Omega_\alpha}a_x\cdot d.
\]
R480 的逐点恒等式仍成立，但现在 \(\int|d|^2\ge\alpha^2nQ_\alpha\)。两端势 \(|a_x|^2,|b_x|^2\) 均在 \([0,n/4]\)，故
\[
 \boxed{Q_\alpha\le
 \frac{2\mathcal W_\alpha}{\alpha^2n}
 +\frac{\Delta_\alpha}{4\alpha^2}
 +\frac{2\mathcal L}{\alpha^2}.}\tag{5}
\]
这里确实消除了 R480 的 \(n\Delta\) 障碍：固定 \(\alpha\) 时，后两项有原已证尺度的费用。主账若使用 (4)–(5)，需同时回代原 \(\tau,\delta\) 吸收参数；本附件不把这些旧费用再次计为新付款。

## 4. 唯一剩余步骤：实际二端相关不能由单端边缘消去

归一化 work 的准确展开为
\[
 \frac{\mathcal W_\alpha}{n}
 =\int_{\Omega_\alpha}\frac{|a_x|^2-\rho^{-1}a_x\cdot b_x}{n}.
\tag{6}
\]
原人工来源独立性仅在给定原 \(A\) 时、选择新父和成功筛选之前成立。\(B\) 和全部成功事件都依赖同一 \(x\)；(6) 中不能刷新 \(x\)，也不能按中心对称把交叉项置零。

更明确地，由 \(|1-\rho^{-1}|\le2|\log\rho|\)、\(|a_x\cdot b_x|\le n/4\)，以及两个同参考边缘，得到
\[
 \left|\frac{\mathcal W_\alpha}{n}
 -\int_{\Omega_\alpha}\frac{|a_x-b_x|^2}{2n}\right|
 \le\frac{\Delta_\alpha}{8}+\frac{\mathcal L}{2}.\tag{7}
\]
这是一次精确相关核查，不是新的付款：右侧所比较的非负二端位移能量仍然是实际联合量。仅凭 \(a_x,b_x\in[-1/2,1/2]^n\) 只能界其为 \(Q_\alpha/2\)，代入 (5) 不能吸收。Schur 的完整 cube 来源内积界也没有自动给这个带原 rank/成功权、同 \(x\) 的有符号交叉项预算。

所以真正未证的一步是对 (6) 的实际全流来源—位移相关作共享 \(W\) 结算，例如取得 \(\mathcal W_\alpha/n\le\eta X+C_\eta\sqrt n\operatorname{polylog}(n)W\)。该式目前未证明，不能把它作为新工具。式 (2) 虽将两端径向松弛付清，却没有给切向相关符号或共同来源重复的价格。本稿至此停止；未新增抽样结构、未改原历史，也不以 (7) 的等价改写声称整体进展。

## 5. 本机有限证书

指定环境 `/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python` 实际运行如下代码。它核六个 cube-point 配置中的 work 恒等式、径向包络原函数及常数；不认证完整原历史实例。

```python
from fractions import Fraction as F
import sympy as sp
from flint import arb,ctx
ctx.prec=192
checks=0
for n in (2,7):
 for rb in (F(3,4),F(1),F(5,4)):
  a=[F(9,20)]+[F(1,8)]*(n-1)
  d=[(1+rb)/2-F(1,10)]+[F(0)]*(n-1)
  rho=1/rb;b=[rho*(x-y) for x,y in zip(a,d)]
  E=sum(x*x for x in d);work=sum(x*y for x,y in zip(a,d))
  aa=sum(x*x for x in a);bb=sum(x*x for x in b);ab=sum(x*y for x,y in zip(a,b))
  assert E-2*work==bb-aa+(1/rho**2-1)*bb;checks+=1
  assert work/n==sum((x-y)**2 for x,y in zip(a,b))/(2*n)+(aa-bb)/(2*n)+(1-1/rho)*ab/n;checks+=1
  assert E>F(n,400);checks+=1
n,t,A=sp.symbols('n t A',positive=True)
c=n/(n+1)
F0=t**n/A**n-n*t**(n+1)/((n+1)*A**(n+1))
assert sp.simplify(sp.diff(F0,t)-n*t**(n-1)/A**n*(1-t/A))==0;checks+=1
assert sp.simplify(n*c**n/(n+1)-c**(n+1))==0;checks+=1
assert sp.simplify(F0.subs(t,A)-1/(n+1))==0;checks+=1
assert 2*(2*arb.pi()*arb(1).exp()).sqrt()<10;checks+=1
print('PASS 6 exact work configurations; 22 assertions (18 Fraction, 3 SymPy, 1 Arb).')
```

实际输出：`PASS 6 exact work configurations; 22 assertions (18 Fraction, 3 SymPy, 1 Arb).` 一般结论依赖以上解析证明，有限核验不替代来源或中心积分。
