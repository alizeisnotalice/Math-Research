# R481：真实中心消质量的有序输运收缩

本稿针对同一 R479 成功流 \(\Omega=\Psi_{\rm ext}\)、\(Q=|\Omega|\)，保留原 \(\Pi\) 的所有来源、阶段和历史。结果是实际质量势的一步及全后继收缩；与既有对数质量差联合后仍仅得到一般线性维数价格，没有完成根阶目标。它不沿用二次平移功估计。

## 1. 一个真实中心容量引理

沿 `/tmp/r480_main.md`，\(m_B=q_BR_B^n\)、\(q\le q_B\le\lambda\)、\(r=\lambda/q\)、\(0\le t(B)\le S\)，原附源固定为 \(x\)。对任意 \(M>0\)，
\[
\boxed{\int_{m_B\le M}t(B)c_B(x)\,\sigma(dB)\le rSM.}\tag{1}
\]
证明：\(c_B(x)=1\) 蕴含 \(2\|B-x\|_\infty\le R_B\)，而匹配下界给 \(R_B^n\le M/q\)。故所有这些**实际中心**都在边长 \((M/q)^{1/n}\) 的立方体中。用 \(tq_B\le S\lambda\) 积分真实Lebesgue中心，得 \(S\lambda M/q\)。这里仅估中心体积，没有把 \(f\) 或来源边界质量换成体积；任意可测半径选择器均适用。

该引理可正限制于原质量带和原增广秩，常数不变。

## 2. 最大父及全部后继的质量势

固定原记录的 \((A,x,j,s)\)，原增广秩为 \(v\)。R479 未筛非空最大父核相对实际增广中心测度 \(\widehat\rho_{x,j}\) 的密度不超过 \(1/T\)，且目标秩低于 \(v\)，所以 \(m_B\le m_A\)。记 \(c=rS/T\)。由(1)，
\[
\mathbb E\left[\frac{m_{B_*}}{m_A}1_{\rm nonempty}\mid A,x,j,s\right]
\le\frac1{Tm_A}\int_{m_B\le m_A}t(B)c_B(x)\sigma(dB)
\le c.\tag{2}
\]
这是质量分母 \(m_B\) 与被积质量精确消去后的收缩，不需要旧 \(y,z\) 在给定 \((A,B,x)\) 后仍独立。

更强地，R480 的固定 \(x,j\)、不刷新标记的 raw Green 核为 \(1_{w<v}dw/T\)。保实际中心条件纤维，得到
\[
\boxed{\mathbb E\left[\sum_{i\ge1}\frac{m_{A_i}}{m_A}\ \middle|\ A,x,j,s\right]\le c.}\tag{3}
\]
此处求和只含成功的 proper 后继，不含初始父；对实际带成功门的递推亦成立，因为其完整核由 raw 核正支配。若采用 R480 的新原记录提升，必须仍保同一 \(x,j\) 和增广标记；新记录不是原旧历史的延续。式(3)不能把每个后继当作又一份独立来源预算。

(2)对原 \(\Pi\) 积分及任意成功正限制给
\[
M_\Omega:=\int_\Omega\frac{m_B}{m_A}\le cR.\tag{4}
\]
所以全部旧门与 \(x\) 倾斜都可保留；只在估计被积正量时放掉成功条件。

## 3. 与同一对数质量差联合后的完整价格

对 \(Q>0\)，Jensen及R479已经证明的最大父对数误差给
\[
Q\log\frac{Q}{M_\Omega}
\le\int_\Omega\log\frac{m_A}{m_B}
\le TD_mW,
\qquad D_m=\log r+n\log(b/a).
\]
结合(4)，包括零量约定后可写
\[
\boxed{Q\log_+\frac{QT}{rSR}\le TD_mW.}\tag{5}
\]
这是真正同一成功流的有序质量势比较；没有改变实际接受权，也没有以无标记静态测度替代左侧。

但它还不是根阶收据。令R479已有恢复误差为
\[
E=[\tau+\delta S+2rS^2/T]X+\kappa T\mathcal M,
\qquad R\le Q+E,\quad\mathcal M\le NW.
\]
若 \(Q\ge E\) 且 \(T>2rS\)，则 \(R\le2Q\)，(5)仅推出
\[
Q\le\frac{TD_m}{\log[T/(2rS)]}W.
\]
若 \(Q<E\)，只用原误差价。统一可保
\[
Q\le E+\frac{TD_m}{\log[T/(2rS)]}W.\tag{6}
\]
固定 \(r,S,\tau,\delta\) 时 \(T\) 固定，整octave的 \(D_m\) 仍为 \(O(n)\)。增大 \(T\) 也不消除 \(T/\log T\) 的价格。因此质量收缩及已付质量差合用仍没有给 \(\varepsilon X+C_\varepsilon\sqrt n\operatorname{polylog}(n)W\)。这里没有新增扣款或重收旧误差；(6)只用于判断该候选的实际强度。

## 4. 有界势与终端的明确限制

在每个固定带，\(\log(m_A/m_{j,-})\) 是振幅至多 \(L_j\) 的有界势，质量序保证其沿边下降。然而该振幅乘全带失败量一般仍收 \(L_j\) 倍；(5)的每单位流漂移只有固定常数级，不能无偿升级为 \(\sqrt n\)。质量势 \(m_A\) 的尺度则随父而变，将它除以各自 \(m_A\) 得到(2)，但这一归一化不能在跨父望远镜时视为固定势。

特别是(3)付的是各节点的质量比，不是节点数或原无权流量。把它恢复成无权计数需要至少终端/当前质量的下界；在同带仅有 \(m_B/m_A\ge e^{-L_j}\)，这样会损失指数因子。不能据(3)声称全部终端已付。

目前唯一缺少的实质比较，是使 double-center-external、原来源排斥及完整接受权对(5)提供比固定常数更大的平均质量势增益，或减少其 \(TD_mW\) 总价。现有列支配、(1)及原高低门没有给出该比较。本轮主稿另研究真实中心短欧氏边与长边平移功；本稿的质量比收缩没有建立对该有向平移功的符号或上界，不能直接与之相消，也不重复其证明。本稿停止于(1)—(5)这一具体正估计，不将隐式线性价称为新根阶进展。

## 5. 本机真实中心核验

以下脚本在指定Python实际运行，输出：

```text
PASS 50 exact Fraction assertions; native 1D matched center intervals, no original history gates.
```

模型为 \(f=1_{[-4,4]}\)，真实中心 \(B\in[-2,2]\)：负半轴边长1、\(t=1/2\)，正半轴边长 \(3/2\)、\(t=1\)。全部盒包含于来源支持，故完整匹配 \(m_B=R_B\)、\(q=\lambda=S=1\)。原父中心取1、边长 \(3/2\)，附源取其盒内五个有理点。按真实中心交区间算低质量原子及等质量原子的增广秩；核(1)及Green质量积分。它不是完整原history实例，也不认证原高门或 \(\Psi_{\rm ext}\) 非空。

```python
from fractions import Fraction as F
checks=0
length=lambda a,b,c,d:max(F(0),min(b,d)-max(a,c))
mA=F(3,2)
for x in [F(1,4),F(1,2),F(1),F(3,2),F(7,4)]:
    l0=length(F(-2),F(0),x-F(1,2),x+F(1,2))
    l1=length(F(0),F(2),x-F(3,4),x+F(3,4))
    u0=l0/2
    u1=l1/mA
    assert u0+mA*u1<=mA
    checks+=1
    for mark in [F(1,4),F(1,2),F(3,4)]:
        v=u0+mark*u1
        for T in [F(4),F(10),F(20)]:
            total=(u0+mA*(v-u0))/(T*mA)
            assert total<=1/T
            checks+=1
print(f'PASS {checks} exact Fraction assertions; native 1D matched center intervals, no original history gates.')
```
