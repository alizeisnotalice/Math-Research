# R671 A1 — minimum-mass geometric cores and their true cumulative debit

## Status and exact scope

The local core fee can be genuinely reduced: among all auxiliary subweights of a valid common pool with total rate at least mu=tau/4, its least R670 certificate uses exactly rate mu and fills the smallest source radii first. The proof relies on the actual disjoint owner geometry, not only on a linear program. For an initial occupied-cell pool of load T>5tau/16, the resulting certificate is smaller than the full-pool certificate by an additional factor at most exp(−27tau/512).

This is an improvement of a valid one-group upper certificate. It is not a corresponding multiplicative reduction of the actual receiver volume, and it does not yet pay repeated cheap sources across different groups. No new complete AU or absorbable eta V_near+CU bound is proved.

The R670 paid scale-edge branch and fixed-range construction are used unchanged. Within one fixed subinterval [a,b), the actual source range is G={i:q_i>0,b≤s_i<na}; each remaining target has the exact pool J_h={i∈G:z_h∈A_i}, load greater than 5tau/16, and the fixed function g_G is at most 1 throughout its entire small box B_h. The actual F_i and X_h are disjoint in their respective families, and all original center-admission, witness and radius constraints are retained. Original I_h may contain h; no original label, rate, Poisson pool, first-k list, mask or clip is changed below.

## 1. Auxiliary weights are realized by genuine source pieces

Fix a group C of actual targets in the same fixed subinterval and a common source pool J whose parents contain every z_h, h∈C. Write

    T=Σ_{i∈J}q_i,   U_J=Σ_{i∈J}q_i d_i,
    d_i=(2s_i)^n,   mu=tau/4,   c=c0^n≤32/31.

Assume T≥mu and the geometric hypotheses of the independently audited R670 extension of R662. Every core parent has radius at least b, which exceeds every target radius in this subinterval; the upper source-scale condition is also retained from fixed G.

For any auxiliary numbers

    0≤theta_i≤q_i,      t=Σ_{i∈J}theta_i≥mu,               (1.1)

Lebesgue nonatomicity permits measurable F_i^theta⊂F_i with

    |F_i^theta|=theta_i d_i.

These are genuine subsets of the original owners. They remain disjoint across labels and remain in B_i. If theta_i=0, that label is omitted only from this deterministic auxiliary certificate. It remains in the original construction and process.

Let S(theta)={i:theta_i>0}, r_C=max_{h∈C}s_h, and

    K(theta)=intersection_{i∈S(theta)} A_i.

All group witnesses lie in K(theta), so the actual receiver union satisfies

    Y_C:=union_{h∈C}X_h ⊂ K(theta)+c0r_C Q.                (1.2)

Applying the complete-intersection bound to these actual auxiliary pieces and their auxiliary rate t gives the valid local certificate

    |Y_C|≤exp(−t/8) Σ_i theta_i d_i.                      (1.3)

The exponent uses the retained rate t, never the discarded original rate T. The local deterministic theorem can be used on such reduced owner pieces without changing the original Poisson construction. All its geometric and threshold conditions must still hold, and here t≥mu is precisely the audited threshold.

## 2. At fixed total rate, smallest-radius filling minimizes mass

For 0≤t≤T define

    M(t)=min{Σ_i d_i theta_i:
             0≤theta_i≤q_i, Σ_i theta_i=t}.              (2.1)

Sort labels by nondecreasing d_i, equivalently by radius s_i, with a fixed order within ties. The minimum is obtained by filling each q_i in this order until total rate t is reached; at most one cutoff label is partially used. The exchange proof is immediate: transferring positive rate from a larger d_j to an unfilled smaller d_i lowers the mass. Tied radii give the same cost; different tie choices can affect the geometric capture set, but not M(t).

Thus M is continuous and piecewise affine. On an open segment with cutoff radius s and d=(2s)^n,

    M′(t)=d.                                              (2.2)

Every chosen owner piece on that segment comes from a source of radius at most s. Choose any common point z of the original pool J. For u∈F_i^theta,

    ||u−z||∞≤||u−y_i||∞+||y_i−z||∞
             ≤s_i/a+s_i=c0s_i≤c0s.

The actual chosen pieces are disjoint, so their union has volume M(t) and is contained in Q(z,c0s). Hence the genuinely geometric constraint is

    M(t)≤(2c0s)^n=c d,
    M′(t)/M(t)≥1/c                 for a.e. t>0.          (2.3)

This implication need not hold for arbitrary numerical arrays q_i,d_i. Its proof uses both the common point and the actual disjoint owner pieces. It is the additional fact which eliminates a generic greater-rate price optimization.

Ties still have the same slope d. The finitely many breakpoints cause no difficulty: M is absolutely continuous, and log M is absolutely continuous on each [t0,T] with t0>0. At a partially used cutoff, nonatomicity supplies the exact requested owner volume without imposing any regularity on F_i.

## 3. The local certificate is strictly increasing in retained rate

From (2.3), for 0<t1≤t2≤T,

    M(t2)≥M(t1) exp((t2−t1)/c).                           (3.1)

Set P(t)=M(t)exp(−t/8). Then

    P(t2)≥P(t1) exp((1/c−1/8)(t2−t1))
          ≥P(t1) exp((27/32)(t2−t1)),                    (3.2)

because c≤32/31. In particular P is strictly increasing on positive-rate intervals. Equivalently, its almost-everywhere derivative satisfies

    P′(t)≥(1/c−1/8)P(t)>0.

Therefore the least certificate (1.3), over every allowed auxiliary vector with total rate at least mu, is achieved at **exactly t=mu**, using the smallest-radius filling from §2. No search over larger rate, stationary points or affine breakpoints is required.

Since M(T)=U_J, the exact comparison with the original full-pool certificate is

    M(mu)exp(−mu/8)
      ≤U_J exp(−T/8)
           exp(−(1/c−1/8)(T−mu)).                         (3.3)

For an initial occupied-cell pool, T>5tau/16 and mu=tau/4, so

    exp(−(1/c−1/8)(T−mu))≤exp(−27tau/512).                (3.4)

This can delete an expensive large-radius source entirely when its rate is not needed in the smallest-radius prefix. Such a source then incurs zero debit for that core, even if it belonged to the original common pool. Conversely, a source still used in many optimized prefixes remains a genuinely repeated cost. A merged group with T=mu can have no saving from (3.3), and is not assigned the initial-cell margin without proof.

Equations (3.3)–(3.4) compare two valid upper certificates. They do not state that a real receiver volume decreases when auxiliary source weights are trimmed.

## 4. A concrete geometric capture rule with the reduced capacities

A direct finite rule can use the optimized cores without first charging every source in every occupied arrangement cell.

Within one fixed subinterval, take the earliest currently uncovered actual target h in the original radius-descending order. Use its full fixed-range pool J_h, and select the smallest-radius auxiliary prefix theta^(h) of total rate mu as in §§2–3. Let

    S_h={i:theta_i^(h)>0},
    K_h=intersection_{i∈S_h}A_i.

Capture every currently uncovered target g in this same subinterval whose **actual witness** z_g lies in K_h. The seed is captured, so the procedure terminates after finitely many groups. The chosen target order gives s_g≤s_h for every newly captured g. Therefore the whole group's true receiver union is contained in

    K_h+c0s_h Q,                                         (4.1)

and is paid by its valid certificate M_h(mu)exp(−mu/8). A group can contain witnesses from several original arrangement strata: discarding unnecessary parent constraints can enlarge K_h and permits genuine geometric coalescence. The rule tests the full selected intersection, not a pairwise similarity condition.

All captured target demands remain their original X_g. No full neighborhood of K_h, no unoccupied arrangement cell, and no own-key-only random union is substituted for that receiver set. The original low-load condition remains available: the trimmed load is bounded by g_G, hence is at most 1 on each captured B_g, while its load at a captured witness is exactly mu.

The rule constructs a legal cover, but its total price has not been bounded. For two groups chosen at different stages, a later seed must lie outside the earlier selected intersection, so at least one earlier positively weighted parent excludes it. This geometric fact does not yield a uniform positive missing-rate amount: the excluding label may carry arbitrarily small rate. It does not prove a spatial separation or a summable source-return bound.

There is a small exact support distinction, which also falls short of a cumulative budget. The original q-mass of a smallest-radius prefix support is at most mu+a^(−n), because only its cutoff label may be partly used and every q_i≤a^(−n). Thus a later target's pool of load greater than 5tau/16 has rate greater than tau/16−a^(−n) outside any one earlier prefix support. These extra labels need not be new relative to the union of all earlier groups; they may already have financed many other groups. This one-support statement is not used as a global fresh-capacity or separation assertion.

## 5. Full fractional source debit: the remaining precise target

For any nonnegative weighted receiver cover by valid groups C, let theta_i,C be each group's smallest-radius auxiliary prefix of rate mu, and let lambda_C be its cover weight. Receiver coverage must still hold for the actual X_h; the construction in §4 gives an integral partition and lambda_C=1 as one possible choice.

The exact optimized core fee is

    B_trim
      =exp(−mu/8) Σ_C lambda_C Σ_i d_i theta_i,C
      =Σ_{i:q_i>0}|F_i|
           [exp(−mu/8) Σ_C lambda_C (theta_i,C/q_i)].       (5.1)

A source is charged only its actually retained fraction theta_i,C/q_i for that group. Zero-rate sources are omitted, so there is no 0/0. Auxiliary subsets of the same F_i may overlap across different groups; every reuse is counted again in (5.1). No disjointness across those group-specific copies is assumed.

Including the already proved R670 scale-edge branch, a complete deterministic account would be

    V_near≤[8e^(2c0)/tau]U+B_trim.                         (5.2)

Thus the remaining task is a bound B_trim≤A0 U, or another direct actual-receiver payment. It is permissible to bound the weighted total in (5.1); a uniform count or column cap for every source is not necessary. The source fractions and the new exponent exp(−mu/8) must both be present in any such argument.

The current proof does not control (5.1). Radius-prefix optimization eliminates unnecessary large-radius capacity at the one-group level and may enlarge a capture region, but it supplies no bound on how often a comparatively cheap source reappears in different selected intersections. Original center admission and the fixed high/low witness-box geometry are retained; they have not been converted into a summable bound for those repeated fractional debits.

In particular, a price-weighted generic LP cannot silently inherit (2.3): that inequality used ordering by the real radii and a common geometric containing cube. Replacing d_i by arbitrary congestion-adjusted prices would require a new geometric proof. Nor does the exponential local comparison (3.4) justify summing an arbitrary number of groups. These are the exact unproved steps, not an impossibility claim for the reduced-cost approach.

## Verification and bounded stop

The geometric monotonicity argument was independently checked against the parent's MAIN_GEOMETRIC_PRICE.md: smallest-radius filling, real owner containment, ties, partial cutoff realization, absolute continuity, and the strict positive derivative all agree. The parent reported that the separately assigned independent Sol proof also passed. Final file/hash binding remains part of that audit workflow.

No numerical breakpoint scan or unrelated computation was needed after (2.3) settled the rate decision analytically. No new MATLAB session, abstract model scan, Git operation, PDF compilation or edit to another agent's file was performed.

The bounded result is the sharper legitimate charging rule (5.1), with its optimal rate and actual fractional source capacities. The general all-input receiver bound remains open because the accumulated fractional cheap-source reuse has not been paid. Work stops here.
