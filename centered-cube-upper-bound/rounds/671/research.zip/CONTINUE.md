# R671 continuation

General all-L1/all-scale/fixed-Lebesgue C_n<=K sqrt(n) remains OPEN. R670 latest prior push5b1b93914bc82e2de726bfb707479b460de613ce supplied the lowered threshold, paid upper rim, fixed spatial source range and legitimate cover. Do not redo those results. R671 price improvement is local, not full AU.

New proved real-geometric pricing rule: for a fixed common pool J, minimize mass M(t)=min sum di ti with0<=ti<=qi and totalrate t. Canonical optimum uses smallest-radius prefix with at most one partial label. Genuine Fi portions are disjoint and inside Q(z,c0 s_cut), so M(t)<=c d_cut, M'=d_cut a.e. Thus log[M(t)e^-t/8] derivative >=1/c-1/8>=27/32, globally by AC. Over legal rate t>=mu=tau/4, minimum is exactlymu. Generic LP stationary behavior alone does not establish this; common-point geometry is essential.

Auxiliary portions do NOT change original q/I/process. For initial cell fullrate T>5tau/16, minmass certificate improves old full-pool certificate by factor <=exp(-27tau/512). This is comparison of upper bounds, not actual volume shrinkage; merged groups atT=mu may have no extra factor. Do not count the saving twice when using fractional mass pricing.

Exact remaining budget becomes B_trim=e^-mu/8 sum_i di sum_C lambda_C theta_iC, equivalently sum_i |Fi| e^-mu/8 sum_C lambda_C theta_iC/qi. Zeroqi omitted. All group-specific portions may reuse same Fi: never treat them as globally disjoint. The open objective is B_trim<=A U for a true cover, or direct receiving payment. Full-pool label occurrence bounds are stronger than necessary; cheap-source fractional reuse still unpaid.

Concrete legal cover: earliest uncovered target in one fixed subinterval, choose its minimum-mass mu prefix, capture every remaining actual witness in selected-parent intersection. Because seed earliest, captured target radius<=seedradius; realX union covered by selected intersection+c0 sh Q. Group's fullcommonpool is subset of seedpool containing selectedsupport, so chosen minimizer still optimal for that fixed group. No global algorithm optimality claimed. Later seed missing a source can have arbitrarily tiny missing rate. Extra rate outside one earlier prefix need not be fresh relative to all previous groups.

Complementary hull code: at most2n actual witnesses determine hull, cores containing fixed source bounded by(mi,B+1)^(2n); full fee max over BOTH source i and subinterval B. Actual qcap makes this counting upper envelope enormous, not actual column lower bound. Owner volume yields qmin dependence, no uniform fee. Do not repeat generic hull count, entropy relabeling, abstract counterexample scans.

Actual local computation prescribedPython3.12.14/SymPy1.14.0/Fraction: derivatives and27/32,27/512 exact. No finite geometric certificate, no actual high-dimensional simulation, no MATLAB/PDF. Scripts and final independent audit in archive.

Next main focus: real fixed-arrangement cheap-source return geometry, with high depth at witness, low load throughout genuine receiverBh, disjoint owners and center admission. Keep original R669 self correction and R670 fullaccount U+(Kfar+Kup)U/tau+Vrem. At most1Astra+3Sol; use only independent tasks; all rounds separately audited/committed/pushed.
