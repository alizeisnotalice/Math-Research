from pathlib import Path
import ast,hashlib,json,re
p=Path(__file__).resolve().parent
for name in ('PRICE_CHECK.py','verify.py'):ast.parse((p/name).read_text())
r=json.loads((p/'PRICE_RESULT.json').read_text());assert r['pass'] and r['monotonicity_rate_lower']=='27/32'
assert r['script_sha256']==hashlib.sha256((p/'PRICE_CHECK.py').read_bytes()).hexdigest()
s=(p/'REPORT.tex').read_text()
assert s.count(r'\begin{document}')==s.count(r'\end{document}')==1
assert sorted(re.findall(r'\\begin\{([^}]+)\}',s))==sorted(re.findall(r'\\end\{([^}]+)\}',s))
for name in ('REPORT.tex','A1_COLUMN_GEOMETRY.md','S2_HULL_BUDGET.md'):
 assert hashlib.sha256((p/name).read_bytes()).hexdigest() in (p/'S1_REVIEW.md').read_text(),name
m=p/'MANIFEST.json'
if m.exists():
 for name,v in json.loads(m.read_text())['members'].items():
  b=(p/name).read_bytes();assert len(b)==v['bytes'] and hashlib.sha256(b).hexdigest()==v['sha256']
print(json.dumps({'pass':True,'scope':'artifact integrity, exact-check record and audit bindings; not a proof verifier','manifest_checked':m.exists()}))
