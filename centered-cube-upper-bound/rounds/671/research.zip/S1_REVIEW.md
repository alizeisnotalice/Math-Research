# R671：真实共点几何下最优局部证书总rate的独立审查

**独立statement结论PASS。** 对R670同一真实有限共点来源族，在固定rate t下按dᵢ递增填满所得最小owner质量M(t)，满足真实几何约束M(t)≤c·d_cut(t)。因此F(t)=M(t)e^(−t/8)在正rate域严格递增；若T=Σqᵢ≥μ=τ/4，可行总rate t∈[μ,T]的最优局部证书总rate唯一为μ。ties可能使具体最优子片不唯一，不影响总rate结论。

本节结论在独立推导并发送父代理后写入；截至第8节尚未读作者A1结论。只沿用R670局部交集桥与既有真实几何合同，不把general LP导数检查当几何证明。不spawn/Git/PDF/MATLAB，不改其他文件。

## 1. 准确可行域及局部价格的含义

固定n≥256、a=32n、c₀=1+1/a、c=c₀ⁿ≤32/31、τ=16384√n、μ=τ/4=4096√n。J是有限actual common-point pool：Aᵢ=Q(yᵢ,sᵢ)共同含z，sᵢ≥r>0，真实Fi⊂Bi=Q(yᵢ,sᵢ/a)两两不交，dᵢ=(2sᵢ)ⁿ>0，qᵢ=|Fi|/dᵢ。

对每个t∈[0,T]、T=Σ_{i∈J}qᵢ，定义

M(t)=min{Σ_{i∈J}dᵢtᵢ : 0≤tᵢ≤qᵢ， Σtᵢ=t}。

这些tᵢ是auxiliary proof weights，不是把原Poisson rate qᵢ或actual first-k lists改成tᵢ。可行集合有限维compact，最小值达到。若T<μ，则没有允许t≥μ的可行证书，不存在“取μ”的结论；若T=μ结论为单点域情形。qᵢ=0时只能tᵢ=0，可删除；高门槛保证当前讨论的t>0且M(t)>0。

这里优化的是R670继承的**局部upper certificate**M(t)e^(−t/8)，不是实际intersection volume本身，也不是所有可能证明方法的最优价格。R670对真实auxiliary subpieces、同一common point和scale条件适用，因为t≥μ恰为它的新load门槛。

## 2. fractional knapsack、ties及连续性

对positive-q来源按dᵢ非减排序，ties任取固定顺序。若dᵢ<dⱼ而tᵢ<qᵢ、tⱼ>0，将小量rate从j移到i严格减少质量。所以存在canonical最优解：按该顺序填满q，最后至多一个来源partial，其余为0。

有ties时，其他最优解可以在同一d-level有多个partial；不能声称每个最优解都至多一个partial。canonical固定顺序解足够，所有tie选择有同一M(t)。将相等d合并后，M是continuous piecewise linear、绝对连续函数，slopes是非减的d-levels；对a.e.t，

M′(t)=d_cut(t)。

在finite累计rate断点两侧slope可跳变，但M本身不跳；端点t=T使用左极限即可，a.e.导数与积分结论不受影响。t=0无active cutoff，无需在该点写几何导数式。

## 3. 关键新几何不等式M(t)≤c d_cut

任取canonical最优tᵢ。Lebesgue measure无原子，故可取真实measurable Fi(t)⊂Fi使|Fi(t)|=dᵢtᵢ；full来源取整个Fi，唯一partial取所需子片。原Fi不交，因此所有选中子片也不交。

设active cutoff的半径为s_cut，d_cut=(2s_cut)ⁿ。所有选中来源均有sᵢ≤s_cut。z∈Aᵢ和Fi(t)⊂Q(yᵢ,sᵢ/a)给

Fi(t)⊂Q(z,c₀sᵢ)⊂Q(z,c₀s_cut)。

于是其真实union volume满足

M(t)=Σ|Fi(t)|≤|Q(z,c₀s_cut)|=c d_cut。

ties不改变containment，partial片仍在原Bi内；不需Fi的perimeter、坐标独立或任意input density cap。每个t可分别选择子片，不需假设随t平移的law；也可用固定coordinate quantile取nested partial片，但结论不依赖这一额外构造。

这一步不是一般fractional LP的性质；它使用真实不交owners与common-point geometry。仅有M′=d_cut的general LP导数记录不能代替它。

## 4. 全可行rate域的严格单调性

F(t)=M(t)e^(−t/8)绝对连续，且对a.e.t>0，

F′(t)=[d_cut(t)−M(t)/8]e^(−t/8)
      ≥(1/c−1/8)M(t)e^(−t/8)
      ≥(27/32)F(t)>0，

因为1/c≥31/32。M在breakpoints连续，所以不存在跳下去的价格；不能只检查各线性段内部而漏掉knots。对任意0<t₁<t₂≤T，logF也在该compact区间绝对连续，积分得到

F(t₂)≥exp[(1/c−1/8)(t₂−t₁)]F(t₁)>F(t₁)。

故在所有允许t≥μ的certificate中，最优总rate必为μ；超过μ即严格提高已优化owner质量之后的price。具体source选择可因ties不唯一。这里没有把−1/8漏成−t/8，也没有将M′不等式方向倒置。

## 5. 与局部R670交集证书的接口

对选中子片，auxiliary weights tᵢ仍≤qᵢ，真实Fi(t)⊂Bi不交，共点和sᵢ≥r保持。t≥μ且n≥256，因此R670 theorem可用；对选中positive-t来源的完整intersection，取其sample-size上界的inf给

| (∩_{i:tᵢ>0}Aᵢ)+c₀rQ |
≤[Σdᵢtᵢ]e^(−t/8)。

若需上界原完整J intersection，其包含于上述选中来源的intersection，故同样有效。若J是某actual receiver group的full common core，所有选中parents仍含该group全部witnesses，因此原group覆盖也保持。这里只是选择确定性cover certificate，不把实际共享first-k过程的label law改成tᵢ/t。

所以在这个具体certificate族内，先对固定t做owner-mass最小化、再优化t的顺序合法，所得最优总rateμ。若优化对象另含实际体积、shape或column constraints，则不能直接套用这个标量最优结论。

## 6. 跨group source reuse仍需完整收费

对多个group g，其各自最优price可写成

e^(−μ/8)M_g(μ)
=e^(−μ/8)Σ_i|Fi|·(tᵢ^g/qᵢ)，

qᵢ=0项定义为0。带fractional cover weights λ_g求和后，exact source debit仍是

Σ_i|Fi| e^(−μ/8)Σ_gλ_g(tᵢ^g/qᵢ)。

每个group的fraction≤1不控制跨groups的总和；不同group可能反复选同一批便宜来源。local rate最优为μ没有支付这个column，没有提供AU、strict gain或一般sqrt(n)结论。必须保留实际cover及source-column约束。

## 7. 本机实际轻量核对

按用户数学工具偏好运行已有Python数学环境的SymPy与Fraction，未跑grid。实际检查输出：

- general derivative identity residual=0；
- `[d−m/8]−(1/c−1/8)m=(cd−m)/c`；
- `1/(32/31)−1/8=27/32>0`。

这只核对新的导数/常数代数；真实符号残差非负来自第3节M≤cd的几何证明，不能靠general LP计算自行认证。主代理此前MAIN/PRICE_CHECK只含general LP derivative不构成本命题证明；本独立审查已补足真实几何步骤。

## 8. 独立阶段交付

statement的ties、fractional片、连续性/AC、threshold/zero branches、原过程不变及global column缺口已逐项审清，无必须修正点。已先向父代理发送核心结论。待作者A1稿形成，只定点对照该几何证书和量词，不扩展预算方向。

## 9. 追加有界独审：hull编码的完整费用与方向

按父代理追加指令实际读取S2_HULL_BUDGET.md；主数学statement PASS，不认证新column付款。

1. 冻结R670 integral terminal cover中，若两个groups的full cores相同，其intersection还是该core且load≥μ，所以merge规则尚可继续。因此terminal cover确无相同cores。该事实针对unit-weight terminal cover，不自动限制任意fractional cover的λ总权。
2. 固定subinterval及source i，含i的group witness hull是非空且包含于Ai。任何能包含该hull的Aj必与Ai相交，因此只需H_i={j∈G:Aj∩Ai非空}，m_i=|H_i|。每坐标的lower threshold集合{j:ell_j≤p}和upper threshold集合{j:q≤u_j}各有至多m_i+1种；闭边界/相等endpoints不会增加种数。2n个门槛集合交集决定full core，所以possible distinct cores≤(m_i+1)^(2n)。这不需target count，也未凭空给code概率或source容量。
3. terminal actual column D_i=Σ_{C:i∈J_C}e^(−T_C/8)因T_C≥μ而被上放为(m_i+1)^(2n)e^(−τ/32)。这只是一个上包络，不是actual D_i或realized code数的lower bound。
4. 若column非空，q_j≤a^(−n)和某core总load≥μ给m_i≥|J_C|≥μaⁿ。故这个**上包络表达式**的log至少有2n²log(32n)+2nlogμ，n≥256下足以超过τ/32及τ/64的吸收尺度。由“一个upper bound很大”只能判定这个粗certificate没完成吸收，不能推出actual column大、所有codes实现、不能存在更优cover或实际输入反例。S2明确保留此方向，正确。
5. 对participating i∈G，H_i内source j与Ai相交给Fj⊂Q(yi,si+c₀sj)⊂Q(yi,(1+c₀)nα)。真Fi不交且sj≥β，因此Q_i=Σ_{H_i}q_j≤[((1+c₀)n)α/β]ⁿ≤[(1+c₀)n]ⁿ。q_min,i为这个finite positive-q邻居族最小值时，m_i q_min,i≤Q_i，所以m_i≤Q_i/q_min,i。代入code上界的q_min倒数方向正确，所得log fee仍含2nlog(1/q_min,i)及O(n²logn)。没有input-independent positive lower bound可用，admission的q-weighted center-capture不能代替all-intersection-neighbor cardinality。

全族式有一项记号须明确：m_i在文中按**固定subinterval**定义；乘nL_n后的global最大值必须遍历所有participating (i,B)（B为fixed subinterval），或预先将m_i定义为跨B最大值。已向父代理指出，应写max_{i,B}(m_{i,B}+1)^(2n)。local equations不改。等最终scope微调后只绑定哈希。

## 10. MAIN_GEOMETRIC_PRICE对照及初始pool额外削费

在第1–8节独立证明后实际读取MAIN_GEOMETRIC_PRICE.md，其真实子片containment、M≤cd、a.e. slope、AC/log积分与第3–4节完全一致。只在可行T_J≥μ的pool上解释其threshold结论；所有R670-local条件仍必须保留。

因为M(T_J)=U_J，严格price增长还给

M(μ)e^(−μ/8)
≤U_Je^(−T_J/8) exp[−(1/c−1/8)(T_J−μ)]。

初始occupied-cell core有T_J>5τ/16，故T_J−μ>τ/16、1/c−1/8≥27/32；相对原full-pool certificate的factor至多e^(−27τ/512)。这是两个合法upper certificates之间的比较，不是实际receiver volume按该factor随机收缩。merged group若T_J=μ可能没有这一额外factor。

主代理此前generic LP的stationary maximum恒等式仍作为代数成立，但真实geometry保证d−M/8≥(27/32)M>0，所以该stationary point不落在admissible positive-rate segment内部。新论证确实用到一般LP不具备的几何条件；不能把MAIN/PRICE_CHECK里的generic derivative记录追认成这条几何定理。

全局fee仍是e^(−μ/8)Σ_i d_iΣ_Cλ_Ct_i,C。再好的单组削费都必须把同一Fi被多组重复选择的fraction列和记入，未知column预算没有消失。

## 11. A1最终稿：seed-trim-capture独审与局部最优范围

完成独立命题后实际读取A1_COLUMN_GEOMETRY.md，SHA-256：

`58f98826a44824107391cbeff00a1355cf33256a5009b7206bde4d57b855e23f`。

作者§1–3与第1–5节独立证明一致。R670阈值μ、真实子片、cutoff geometry、ties/AC及initial factor e^(−27τ/512)都正确，未保留已丢弃rate作为指数。具体capture rule也PASS：

- 仅在同一个fixed subinterval内取earliest uncovered actual target h。用其Jh的minimum-mass rate-μ prefix，所有selected parents仍含seed witness。
- capture所有当前uncovered且actual witness位于selected intersection Kₕ的targets。seed必被capture，故有限终止；original order使这些targets满足s_g≤sₕ。
- 每captured receiverX_g位于z_g+c₀s_gQ⊂Kₕ+c₀sₕQ，selected sources半径≥β>sₕ，真实Fi^theta满足R670。它是实际receiver cover，不是把整个expanded body当作新receiver。
- selected support⊂每个captured J_g，因为同fixed G内J_g={i∈G:z_g∈Ai}。group含seed，所以full J_C⊂J_seed且包含selected support。
- 在J_C中，seed的μ-vector仍可行。缩小source集合使minimum mass不能降低，而原vector达到seed minimum；因此该vector仍是group的minimum-mass μ certificate。这仅是这个group的局部最优，不证明capture algorithm的global最优。
- trimmed load≤g_G≤1在每个capturedBg上，captured witness处全部selected parents包含它故trimmed load恰μ。原actual pools、Poisson histories和receivers均未改。

后来seed在earlier selected intersection外的事实正确，但一个排除label的positive rate可任意小。canonical support原q-mass≤μ+a^(−n)也正确：仅cutoff可能留下unused fraction，全部support mass为μ+(q_cut−theta_cut)。后来target Jh rate>5τ/16给其在任一旧support外rate>τ/16−a^(−n)；不能把这些labels认作相对于所有earlier groups的新容量。

作者§5保留每group retained fraction θᵢ,C/qᵢ和共同e^(−μ/8)，包括zero-q omission、cross-group portions可重叠以及λ cover权重。没有claimed column或新AU。Congestion-adjusted任意prices不能继承真实dᵢ下M≤cd，也被正确列为未证。

## 12. S2全族bin修复及主报告初读

S2_HULL_BUDGET.md修复后已实际读取；最终SHA-256：

`db83aec07613e405024d9031cc1b69f6ee2293aebe3c67824304233e3441cea0`。

其式(0)现明确max_{i,B}遍所有actual fixed subintervals，解决第9节的global索引项。local count、qcap使粗upper-envelope失去吸收及qmin依赖的方向均PASS；没有把它作为actual debit下界或actual-input反例。

完整实际读取主REPORT.tex的版本SHA-256：

`e1474cb647a84263acbc35f0f1bb28f622625653ff44579a5ad08eade0bdb761`。

主稿的monotonicity theorem、seed capture与保持group minimum的论证、full fractional source debit以及局部/全局最优范围全部PASS。明确不能在已优化selected mass的exactfee外再乘一次initial saving；该saving已经体现在M(μ)中。原R670 rim一次payment、Kfar、Cadm、P₀≥U/τ及未付Vrem保留正确，没有重复旧mask费用。

发现一个需要explicit scope的显示式：hull节的Σ_{j:A_j∩A_i非空}q_j≤[(1+c₀)n]ⁿ必须将j限制为当前fixed ground G（且participating i∈G）。此前该节上下文确为fixedG，但公式自身省去G会被读为所有尺度的邻居；volume proof使用si,sj<nα、sj≥β，不能用于全体原来源。已通知主代理最小修复。除此之外没有必须修改的数学项；待修复后只绑定最终哈希，不扩展任务。

## 13. 最终scope修复与最终哈希绑定

已实际读取主报告最后的fixed-ground修复：i明确属于G、m_i仅数同一G中的邻居，volume-rate显示式也明确Σ_{j∈G:Aj∩Ai非空}。这准确补回证明所需si,sj∈[β,nα)条件，无其他数学内容改变。

最终实际核对的版本：

- REPORT.tex SHA-256：`4ddad39850beb7d001b88b016f2ab7a0c8620447c897d8c89d8fd2a0b1ad2775`。
- A1_COLUMN_GEOMETRY.md SHA-256：`58f98826a44824107391cbeff00a1355cf33256a5009b7206bde4d57b855e23f`。
- S2_HULL_BUDGET.md SHA-256：`db83aec07613e405024d9031cc1b69f6ee2293aebe3c67824304233e3441cea0`。

**最终独审PASS，无剩余必须修复项。** 真几何下μ-rate局部最优、initial certificate削费、seed capture的合法性/保持group minimum、exact fractional source charge及hull upper-envelope失败范围均已核对。没有global capture最优或AU结论；重复cheap-source容量仍未付。

所有授权有界审核完成。只写/追加本S1，无spawn/Git/PDF/MATLAB，不重复既过计算，交付停止。
