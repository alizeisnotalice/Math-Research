from pathlib import Path
import sympy as s,json,platform,sys,hashlib
t,d,b=s.symbols('t d b',real=True)
f=(d*t+b)*s.exp(-t/8)
d1=s.diff(f,t);d2=s.diff(f,t,2)
assert s.simplify(d1-s.exp(-t/8)*(d-(d*t+b)/8))==0
assert s.simplify(d2.subs(b,8*d-d*t)+d*s.exp(-t/8)/8)==0
from fractions import Fraction as F
assert 1/F(32,31)-F(1,8)==F(27,32)
assert F(27,32)*(F(5,16)-F(1,4))==F(27,512)
out={'monotonicity_rate_lower':'27/32','initial_certificate_saving_exponent':'27tau/512','pass':True,'python':platform.python_version(),'sympy':s.__version__,'interpreter':sys.executable,'first_derivative':str(d1),'second_at_stationarity':str(s.simplify(d2.subs(b,8*d-d*t))),'conditions':'d>0 and positive t; b may have either sign','scope':'symbolic identities for auxiliary one-core mass-price optimization, not a global source budget','script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
Path(__file__).with_name('PRICE_RESULT.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
