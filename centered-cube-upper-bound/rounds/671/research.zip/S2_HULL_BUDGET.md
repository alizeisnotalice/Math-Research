# R671 S2 — exact hull-code fee and the unpaid entropy bridge

**Bounded verdict: no hull/entropy payment is proved.** The true hull admits an endpoint code independent of target count, giving at most (m_i+1)^(2n) possible cores for a fixed source i. Substitution into the SAME R670 column account yields the complete fee

    n L_n exp(-tau/32) max_{i,B} (m_{i,B}+1)^(2n) U,
    L_n=ceil(log_2 n)+2.                                      (0)

Here B ranges over the actual fixed subintervals, and m_{i,B} is the neighboring-source count defined locally below in that subinterval. Thus the maximum in this full-family formula is taken across both i and B.

This particular counting certificate cannot be absorbed by exp(-tau/32). The large quantity is the **naive counting upper envelope**, not a lower bound on actual debit or on the best cover. No impossibility result for a better geometric or weighted cover is claimed.

Success was fixed at the start: obtain a true within-subinterval source column at most exp(tau/64), or another explicit bound that becomes absolute after the full nL_n exp(-tau/32) factor. Merely proving that 2n witnesses determine a hull is insufficient. The calculations below give the entire dimensional and small-weight fee and then stop.

Only the assigned hull-encoding route is considered. The frozen R670 cores and thresholds are unchanged. No alternative merge algorithm, source-subweight construction, abstract scan, numerical job, Git action or PDF compilation is introduced. Only this file is written.

## 1. Frozen receiving account

Fix one target subinterval [alpha,beta), with beta/alpha=2^(1/n), and the fixed source ground set

    G={i:q_i>0, beta<=s_i<n alpha}.

Each actual initial target has J_h={i in G:z_h in A_i}, of load greater than 5tau/16. An actual group's witness box hull Z_C gives its EXACT full common core

    J_C={i in G:Z_C subset A_i}.

Final legal cores have only T_C=sum_{i in J_C}q_i>=tau/4; the initial 5tau/16 bound cannot be retained through merges. The actual receiving pieces satisfy

    Y_C=union_{h in C} X_h subset K_C+c0r_C[-1,1]^n,
    K_C=intersection_{i in J_C} A_i,  r_C=max_{h in C}s_h<beta.

The proved local theorem therefore gives

    |Y_C|<=exp(-T_C/8) sum_{i in J_C}|F_i|.

For the frozen integral terminal cover define the actual source column

    D_i=sum_{C:i in J_C} exp(-T_C/8).                         (1)

Its debit is sum_i |F_i|D_i. The parent account allows at most nL_n subintervals for any source. Hull coding must control THIS quantity, with every reuse still charged.

The terminal R670 merge rule has no two groups with identical cores: their intersection would equal that core and would still have load at least tau/4, so the existing rule would not have terminated. Thus distinct-core counting bounds the number of summands in (1). This is a property of the frozen terminal cover, not an added algorithm.

## 2. True geometric compression and exact count

Choose witnesses attaining every coordinate minimum and maximum of a finite nonempty group. At most 2n actual witnesses, with repetitions allowed, have exactly its coordinate hull. A raw target-label count would cost at most N^(2n), hence logarithmic fee 2n log N. No control of N is supplied by this statement.

A source-boundary code removes N. For a fixed source i, a group with i in J_C has its whole witness hull inside A_i. Define the actual neighboring set

    H_i={j in G:A_j intersects A_i},   m_i=|H_i|.              (2)

Sources outside H_i cannot contain any nonempty hull inside A_i. Write the coordinate endpoints of A_j as ell_jl,u_jl and those of the hull as p_l<=q_l. Its exact membership test is

    j in J_C iff ell_jl<=p_l and q_l<=u_jl for every l.        (3)

For each coordinate, each of these two monotone threshold families has at most m_i+1 distinct source-subset values. Inclusive inequalities handle boundary witnesses; equal endpoints only reduce the count. Hence the number M_i of possible distinct full cores containing i satisfies

    M_i<=(m_i+1)^(2n).                                       (4)

This preserves the actual box geometry and improves the raw target count. It has not assigned source capacity or probability to a code.

Since every final T_C>=tau/4, (1) and (4) give only

    D_i<=(m_i+1)^(2n) exp(-tau/32).                          (5)

This yields precisely (0), not an absolute global payment.

## 3. Substitute the whole fee: dimension defeats this counting certificate

To meet the parent's sufficient within-subinterval criterion using (4), one would need

    2n log(m_i+1)<=tau/64=256 sqrt(n).                        (6)

The natural source cap already makes THIS scalar certificate too expensive. If source i belongs to any final core, q_j<=a^(-n) and T_C>=tau/4 imply

    |J_C|>=(tau/4)a^n,   m_i>=|J_C|>=(tau/4)a^n.             (7)

Consequently

    2n log(m_i+1)
      >=2n^2 log(32n)+2n log(tau/4)
      >2n^2 log(32n).                                       (8)

For n>=256, log(32n)>1 and n^(3/2)>=4096. Thus the last quantity exceeds 8192 sqrt(n), which is larger than BOTH tau/64=256 sqrt(n) and the full decay tau/32=512 sqrt(n). The logarithm of the scalar envelope in (0), for a nonempty column, exceeds 7680 sqrt(n)+log(nL_n) under these crude replacements.

**Direction:** equations (7)-(8) show that the bound expression in (5) cannot pass the absorption test. They do not show that M_i is actually this large, that D_i is large, or that all possible codes are realized by actual admitted receivers. This is not an actual-input counterexample. It rules out calling this elementary counting upper bound sufficient.

No uniform mass separation between distinct final cores has been inferred from terminal nonmergeability.

## 4. Genuine owner volume gives an explicit minimum-weight dependence

Let q_min,i=min_{j in H_i}q_j>0. For j in H_i, actual parent intersection implies

    ||y_j-y_i||_infinity<=s_i+s_j,
    F_j subset Q(y_i,s_i+c0s_j)
        subset Q(y_i,(1+c0)n alpha).

The true F_j are disjoint and s_j>=beta, so

    Q_i:=sum_{j in H_i}q_j
      =sum_{j in H_i}|F_j|/(2s_j)^n
      <=[(1+c0)n alpha/beta]^n
      <=[(1+c0)n]^n.                                       (9)

Therefore

    m_i<=Q_i/q_min,i<=[(1+c0)n]^n/q_min,i.                    (10)

Substituting into the SAME column gives the valid but unpaid estimate

    D_i<=exp(-tau/32)
           [1+((1+c0)n)^n/q_min,i]^(2n).                    (11)

The logarithm of the full bound contains 2n log(1/q_min,i) and an O(n^2 log n) term, in addition to log(nL_n)-tau/32. The frozen construction supplies an upper cap on q_i and no positive input-independent lower bound. Genuine source-owner disjointness has therefore not provided a uniform code fee.

Equation (9) is only an upper estimate. No assertion that this large local rate or the code count is attained is made.

Actual center admission bounds a q-weighted directed center-capture relation. It does not bound the number of tiny-weight source boundary positions. Also A_j intersects A_i in (2) is weaker than directed center capture. The R669 paid source triangle therefore cannot simply be substituted for all these neighboring sources.

## 5. Exact unpaid entropy-to-capacity connection

Three shortcuts would omit a real fee.

1. Witness codes are not source-owner samples. Their points are actual target witnesses. A target may have q_h=0 and positive receiver demand. Charging its label through |F_h| repeats the R669 measure mismatch; the valid comparison costs a^(-n)/q_h when positive, and has no finite counterpart at q_h=0.

2. Source-boundary labels have no free probability law. Equation (3) gives a finite code but does not show a cover-preserving way to weight that code by q_j or |F_j|. Introducing such weights and then dividing by them leaves reciprocal probabilities. Equations (10)-(11) expose the minimum-weight dependence of the direct count.

3. The local exp(-T_C/8) is already spent as a deterministic receiving-volume bound. It is not an independent probability for selecting a hull or an extremal witness and cannot be spent a second time. Final nonmergeability says only that the intersection of two full cores has load below tau/4. Individual final loads may approach tau/4; no uniform weighted packing gap follows.

A further proved estimate on the REALIZED weighted columns in (1), using geometric occupancy or a justified owner-weighted code law, would be needed to turn hull compression into a payment. It does not follow from the 2n-witness certificate, (4), or (9). It is neither assumed here nor recast as an all-subsets Hall requirement.

This is the stopping point. No new experiment was warranted after the explicit fee calculation, and none was run. The parent and Astra are separately evaluating other source-capacity constructions; this note does not duplicate or prejudge them. The original global receiving budget remains open by this route alone.

