from fractions import Fraction as F
from math import comb
from flint import arb, ctx
ctx.prec = 256
exact = 0
print('Stage 1: exact alpha=1 full-cube Laplace integral')
for n in (1,16,64):
    integral = sum((F((-1)**k * comb(n-1,k), (2*k+1)*2**(2*k+1)) for k in range(n)), F(0))
    value = 1+n*integral
    assert value*value <= 16*n
    exact += 1
    print('n=', n, 'I1=', float(value), 'I1^2 <= 16n: exact PASS')
print('Stage 2: rational scalar U_alpha and tangent bound')
scalar = 0
for denominator in (1,2,3,4):
    alpha=F(1,denominator)
    for k in range(11):
        base=F(40+k,40)
        t=base**denominator
        if t>2: continue
        u=2/t-1+2/(alpha+1)*(1-base**(-denominator-1))
        upper=1-alpha*((t-1)/t)**2
        assert 0<u<=upper<=1
        scalar+=1
exact+=scalar
print('scalar exact assertions:',scalar)
print('Stage 3: Arb checks of full minimal-selector entropy and cubic inequality')
interval=0
l2=arb(2).log()
for n in (1,16,64):
    d=1+n*l2
    h=1+n*(l2+l2*l2/2)+n*(n-1)*(3*l2-2)
    assert h>=d
    assert d**3 < 64*n*h/l2
    interval+=2
    print('n=',n,'D=',d,'H=',h,'cubic PASS')
print('TOTAL:',exact,'Fraction assertions;',interval,'Arb interval assertions')
print('Scope: scalar/full-cube geometric fixtures only; the general proof is analytic. No source matching or original history certification.')
