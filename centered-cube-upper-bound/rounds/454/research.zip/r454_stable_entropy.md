# R454：来源条件化熵的分区稳定上界

固定n≥1，0<a≤b≤2a，可测接收集E和边长R_A∈[a,b]。Q_A为中心A边长R_A立方体。对每个来源点y定义E_y={A∈E:y∈Q_A}、D(y)=∫E_y R_A^{-n}dA，以及
\[
H_y=\int_{E_y}R_A^{-n}\log\frac{eR_A^n}{|E_y\cap Q_A|}\,dA.
\]
零局部交集的异常点取扩展值；下面证明它们对相应接收测度为零。所有量可测，由参数积分/Tonelli得到。设f≥0属L1，W=∫f，X=∫fD，H=∫fH_y。

## 一般几何估计（不需要密度带）

对固定y，E_y包含于边长b的y中心立方体。将该立方体每坐标等分四段，得到N=4^n个盒C_l，每边长b/4≤a/2。对A∈C_l，C_l⊂Q_A（边界无影响）。令t_l=|E_y∩C_l|，ρ_l=∫E_y∩C_l R_A^{-n}dA。若ρ_l>0，则t_l≥a^nρ_l>0，对该胞中的A有
\[
|E_y\cap Q_A|\ge t_l,\quad
\log\frac{eR_A^n}{|E_y\cap Q_A|}
\le \log\frac{e(b/a)^n}{ρ_l}.
\]
ρ_l=0的胞无贡献。因此
\[
H_y\le\sum_l ρ_l\log\frac{e(b/a)^n}{ρ_l}
\le D(y)\log\frac{e[4b/a]^n}{D(y)}.
\tag{1}
\]
最后用h(t)=t log(C/t)的凹性，或令ρ_l/D为有限概率向量并使用其熵≤logN。D=0时右边按0定义。因为局部交集≤R_A^n，H_y≥D；另一方面D≤(b/a)^n使右边为正。式(1)不依赖输入接收盒如何表示或细分，对任意可测接收场直接成立。

若W>0，以f/W为概率测度再用同一凹函数的Jensen，得到
\[
\boxed{\quad H\le X\log\frac{e[4b/a]^nW}{X}\le(1+n\log8)X+W/e.\quad}
\tag{2}
\]
W=0或X=0时H=0。所有Jensen合法：D有一致有限上界，h连续延拓到0，因而在有界区间有界；无需任何来源密度帽或压缩密度的L1收敛。第二不等式使用u log(1/u)≤1/e。式(2)保留真实来源质量及来源相关的接收集合，没有把E_y改为E。

## 与根阶目标的关系

这是消除R453人为细分X logN费用的一般估计，不是目标H≤Cn polylog(n)W。若qband成立，则X仍只能由已有工具控制为O(n)W；式(2)因此通常仍是O(n²)W。即使另能证明F=∫fD²≤C H，也尚不能由本式推出F=O(n polylog n)W。这里没有新原余项付款、没有全尺度或历史门回代。

需要真正改进的是利用完整matching把来源条件化熵的X量级费用压低；不能把本式的nX记成nW。其价值是使下一次联合几何估计面对表示不变的量，避免继续支付任意网格细化费用。
