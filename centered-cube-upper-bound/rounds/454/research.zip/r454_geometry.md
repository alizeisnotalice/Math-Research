# R454 — source-preserving allocation: exact change of marginal, no new payment

**Bounded outcome.** The attempted shared-center allocation does not establish
the requested \(H\lesssim_r n\operatorname{polylog}(n)W\), or the separate
matched-source comparison of the second moment with \(H\). The calculation
below identifies the exact cost change that this particular route would have
to compensate. It does not rely on a pointwise comparison between \(D(y)^2\)
and the entropy at \(y\), and supplies no new term for the original ledger.

## 1. The common actual field

Let \(f\ge0\) be integrable, \(W=\int f\), and let the actual receiver field
have side lengths \(a\le R_A\le b\le2a\),

\[
m_A=\int_{Q_A}f=q_AR_A^n,\qquad q\le q_A\le\lambda.
\]

Write \(c_A(y)=1_{Q_A}(y)\), \(\sigma(dA)=q_A\,dA\),

\[
E_y=\{A\in E:c_A(y)=1\},\quad
D(y)=\int_{E_y}R_A^{-n}\,dA,\quad
L(A,y)=|E_y\cap Q_A|.
\]

The task's actual entropy is

\[
H=\int f(y)\int_{E_y}R_A^{-n}
       \log\frac{eR_A^n}{L(A,y)}\,dA\,dy.
\tag{1}
\]

All sets here retain the same source \(y\). The full receiver set does not
replace \(E_y\). For almost every \(A\in E_y\), \(L(A,y)>0\), by Lebesgue
differentiation and \(R_A\ge a>0\); null exceptions do not affect (1).

## 2. The attempted allocation and its exact accounting

The natural joint source/center measure is

\[
\gamma(dy,dA)=f(y)c_A(y)R_A^{-n}\,dy\,dA
             =\sigma(dA)\pi_A(dy),
\qquad \pi_A(dy)=\frac{f(y)c_A(y)}{m_A}\,dy.
\tag{2}
\]

Full matching gives both of its marginals exactly:

\[
\gamma_A=\sigma,\qquad \gamma_y=f(y)D(y)\,dy,
\qquad \gamma(\mathrm{all})=X_q=\int fD.
\tag{3}
\]

Consider any measurable probability kernel relocating \(A\) to actual
centers which capture the *same* \(y\). It can depend on the full field and
on \(A,y\). The resulting joint measure still has source marginal \(fD\).
Consequently, even a dimension-only conditional coding/covering price
at each source is multiplied by \(fD\), not by \(f\). This observation is
about this allocation route, not a claim that all possible geometric
proofs must have that loss.

The exact normalization that changes the source marginal to \(f\) is

\[
\widehat\gamma(dy,dA)=1_{\{D(y)>0\}}\frac{\gamma(dy,dA)}{D(y)}.
\tag{4}
\]

Its total mass is \(W_{\rm cov}=\int_{D>0}f\le W\), but its actual parent
marginal becomes

\[
\widehat\gamma_A(dA)
 =q_A\left(\int\frac{1_{\{D(y)>0\}}}{D(y)}\,\pi_A(dy)\right)dA.
\tag{5}
\]

This is generally not \(\sigma\). Both (4) and (5) are finite by Tonelli;
zero-\(D\) sources carry no original joint measure. In particular matching
does not make the posterior inverse-\(D\) factor in (5) equal to one.
Keeping the original entropy rather than changing its meaning requires

\[
H=\int D(y)\log\frac{eR_A^n}{L(A,y)}\,
                   \widehat\gamma(dy,dA).
\tag{6}
\]

Thus source normalization alone does not remove the occupancy factor.
No signed cancellation, parent redistribution with a priced defect, or
geometric domination for the weighted expression (6) was obtained.

## 3. The single missing step and the decision

The shared-cover mechanism would need a joint, full-matching estimate
which compensates **both** the posterior inverse-\(D\) change in the parent
weight (5) and the \(D\)-weighted logarithmic loss in (6). A cover bound
charged only after conditioning on \(y\) leaves the original \(fD\)
marginal in place; merely dividing by \(D\) changes the parent budget.
Neither operation supplies the required source price.

The independently established stable entropy bound can therefore be used
as such, but it is not improved here. No pointwise \(D^2\lesssim H_y\)
inequality is assumed, and a possible integrated comparison using full
matching remains open. The next construction must use matching in a
genuine joint compensation, rather than treating the per-source cover
and the source marginal as two independent estimates. This attachment
stops at that specific failed step; it does not introduce a new remainder
or assert that the full target is false.

## 4. Actual local verification and its scope

`/tmp/r454_geometry_check.py` was run with the designated math Python;
stdout is `/tmp/r454_geometry.result.txt`. It uses exact `Fraction`
arithmetic on a native one-dimensional field: source packets centered at
\(\pm1/4\), half-width \(1/1000\), each of mass \(1/2\); actual center
intervals \([-3/5,-2/5]\), \([-1/20,1/20]\), and \([9/20,11/20]\), all
with selected side length one. Full capture gives masses
\((1/2,1,1/2)\), hence an actual band \([1/2,1]\).

The script checks complete incidence inequalities, matching, the two
original marginals, a source-preserving relocation, and (5). Here
\(D=(3/10,1/5)\), original parent masses are \((1/10,1/10,1/20)\), and
the normalized parent masses become \((1/3,5/12,1/4)\). These computations
verify only the stated conservation and change of marginal. They are
neither a high-dimensional entropy estimate nor an original-history
example or a counterexample to the desired bound.
