# R454 — a universal cubic center-entropy bound

## Statement and scope

Let \(n\ge1\), \(0<a\le b\le2a\), and let \(A\mapsto R_A\in[a,b]\) be a measurable **side-length** selector on a measurable set of real Lebesgue centers \(E\subset\mathbb R^n\). Write \(Q_A=A+[-R_A/2,R_A/2]^n\). Fix a source point \(y\), and set
\[
 F=E_y=\{A\in E:y\in Q_A\},\quad
 d\nu(A)=1_F(A)R_A^{-n}dA,\quad D=\nu(F),\quad
 p(A)=\frac{|F\cap Q_A|}{R_A^n},
\]
\[
 H=\int_F\log\frac e{p(A)}\,d\nu(A)\in[0,\infty].
\]
The conventions at \(p=0\) are the usual extended nonnegative ones. No source density or matching assumption is used. Then
\[
 \boxed{D^3\le \frac{64}{\log2}\,nH.}\tag{1}
\]
This is a weaker, genuinely general replacement for the proposed dimension-free square comparison. It does **not** prove \(D^2\lesssim H\), a root-dimensional source budget, or the original remaining-flow estimate.

## A geometric Laplace bound

For every \(0<\alpha\le1\),
\[
 I_\alpha:=\int_Fp(A)^\alpha\,d\nu(A)
 \le4\sqrt{n/\alpha}.\tag{2}
\]
Translate \(y=0\) and dilate by \(b/2\); all quantities above are invariant. Thus \(F\subset[-1,1]^n=:C\), and every selected side length lies in \([1,2]\). For a fixed center \(A\in C\), the one-coordinate overlap length
\[
 g_j(t)=|[-1,1]\cap[A_j-t/2,A_j+t/2]|
\]
is concave, nonnegative, and vanishes at zero. Consequently \(g_j(t)/t\) is nonincreasing. Hence
\[
 t^{-n}\left(\frac{|C\cap Q(A,t)|}{t^n}\right)^\alpha
\]
is nonincreasing in \(t>0\). Since capture of zero requires \(R_A\ge2\|A\|_\infty\), enlarging \(F\cap Q_A\) to \(C\cap Q_A\), then enlarging the center domain to \(C\), gives an upper bound obtained with the minimal side length
\[
 t_*(A)=\max(1,2\|A\|_\infty).
\]
This is an envelope argument, not a change of the original selector.

The inner cube \([-1/2,1/2]^n\) contributes 1. Integrating the outer shells, whose unique maximal coordinate may be selected outside a Lebesgue null set, gives
\[
 I_\alpha\le1+n\int_1^2t^{-1-\alpha}U_\alpha(t)^{n-1}\,dt,\tag{3}
\]
where
\[
 U_\alpha(t)=\frac2t-1+\frac2{1+\alpha}(1-t^{-1-\alpha}).
\]
Indeed the maximal-coordinate normalized overlap is \(1/t\); the average of the remaining one-coordinate normalized overlap to power \(\alpha\) is \(U_\alpha(t)\).

For \(0\le z\le1\), concavity gives \(z^\alpha\le1-\alpha(1-z)\). Applying this inside the coordinate average and using
\[
 U_1(t)=1-\left(\frac{t-1}{t}\right)^2
\]
yields
\[
 U_\alpha(t)\le1-\alpha\left(\frac{t-1}{t}\right)^2
 \le\exp[-\alpha(t-1)^2/4].\tag{4}
\]
For \(n\ge2\), (3) is at most
\[
 1+n\int_0^\infty e^{-\alpha(n-1)x^2/4}\,dx
 =1+\frac{n\sqrt\pi}{\sqrt{\alpha(n-1)}}
 \le4\sqrt{n/\alpha}.
\]
Here \(n/(n-1)\le2\), \(\sqrt{2\pi}<3\), and \(1\le\sqrt{n/\alpha}\). For \(n=1\), simply \(I_\alpha\le D\le1+\log2<2\). This proves (2), including all measurable selectors and the fixed-scale case.

## Deduction of (1)

If \(D=0\) or \(H=\infty\), the assertion is immediate. Otherwise Jensen under \(\nu/D\) gives
\[
 D\exp[-\alpha H/D]
 \le D\exp[\alpha(1-H/D)]
 \le I_\alpha\le4\sqrt{n/\alpha}.\tag{5}
\]
If \(D\ge8\sqrt n\), choose \(\alpha=64n/D^2\in(0,1]\). The right side is \(D/2\), so \(\alpha H/D\ge\log2\), which is (1). If \(D<8\sqrt n\), use \(H\ge D\): \(D^3\le64nD\le64nH\). No boundedness of \(H\) was presumed.

## What this does and does not settle

The initially considered stronger packing estimate \(I_\alpha\le C/\alpha\) is not valid uniformly in dimension. Already for \(F=C\), minimal selector \(t_*\), and \(\alpha=1\), the shell integrand is
\[
 nt^{-2}[1-((t-1)/t)^2]^{n-1}.
\]
Its integral over \([1,1+1/(2\sqrt n)]\) is at least \(\sqrt n/6\), by Bernoulli's inequality and \(t^2\le9/4\). This explains why that stronger sufficient route was abandoned; it is not a counterexample to the original matched-source objective.

For any nonnegative integrable source \(f\), (1) can be integrated without changing the center selector:
\[
 \int fD^3\le(64/\log2)n\int fH.
\]
If a separate argument supplies \(\int fH\lesssim nW\), Hölder would give only \(\int fD\lesssim n^{2/3}W\). Thus the present estimate alone does not attain the requested root scale. The source-integrated entropy estimate is outside this file's assignment and is not asserted here.

## Reproducible local verification

`r454_mainproof_check.py` was actually run with the local math Python environment; stdout is `r454_mainproof.result.txt`. It passed **44 Fraction assertions and 6 Arb interval assertions** at 256-bit precision:

1. Exact polynomial evaluation of \(I_1=1+n\int_0^{1/2}(1-u^2)^{n-1}du\) for \(n=1,16,64\), checking \(I_1^2\le16n\).
2. Forty-one rational checks of (4)'s scalar tangent bound for \(\alpha\in\{1,1/2,1/3,1/4\}\) and rational perfect-power \(t\in[1,2]\).
3. Interval checks of the cubic inequality on the full minimal-selector cube, using
\[
 D=1+n\log2,\qquad
 H=1+n(\log2+\tfrac12\log^22)+n(n-1)(3\log2-2).
\]

These are geometric/scalar checks, not original matching/history fixtures. The proof above is analytic and does not rely on finite verification. An earlier temporary ordinary-float inner-shell probe was used only for exploratory screening. It is not an archived reproducibility attachment and is not used as proof evidence; the analytic lower bound above is self-contained.
