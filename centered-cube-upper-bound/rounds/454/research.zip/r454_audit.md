# R454 independent audit — FINAL PASS（限定一般引理与列明证据）

FINAL PASS：认证本轮对任意可测单octave接收场的稳定来源条件熵界、Iα覆盖积分界与D³≤(64/log2)nH_y，以及附件的准确边缘核算和有限验证。**没有认证D²≤CH、H的所需根阶源价、一般M2或完整原余项预算；原母账不变，无新增付款。** 作者稿前形成的独立PRE及cubic推导保留于后。

## 1. 核心一般结果及常数

Stable entropy稿与独立推导一致：固定source整体4^n个b/4胞的覆盖用真实side下界，零胞不贡献，局部交集异常点为接收零测；参数积分保联合可测。两次凹Jensen的归一质量分别为D和W，最终乘子为X，而非W。准确界H≤Xlog[e(4b/a)^nW/X]及O(n)X+W/e成立，Xlog(W/X)不能无条件删除。

Mainproof的fullcube正上放、固定中心交长g_j(R)凹且g_j(R)/R非增、最小合法capture side、内base 1与外面Jacobian均正确。Uα(t)、U1的二次亏损及Gaussian尾给Iα≤4√(n/α)，n1独立处理；没有偷换原selector成按source自由选择的等式。Jensen实际含e^α更强因子，稿中弱式合法。D≥8√n时α=64n/D²给D/2上界和64/log2常数；低D用H_y≥D补齐，D0/∞情形处理正确。fullcube例否定dimension-free Iα≤C/α的下界只筛此更强packing，非matched-source目标反例。

积分后∫fD³≤(64/log2)nH，Hölder给F≤[(64/log2)nH]^(2/3)W^(1/3)。根稿明确即便未来H≤O(n)W也只给F≤O(n^(4/3))W，不能宣称nW或root闭合。当前stable预算本身仍含nX。

## 2. 附件、数值与原账

Geometry的同一γ=σπ_A之source边缘为fD；保source迁移不改变它，除D后接收边缘为q_A Eπ_A[1_{D>0}/D]dA，通常不是σ。零D来源原联合质量零、归一后总量W_cov≤W，Tonelli保证有限。该边缘缺口未被充作新补偿或付款。

Numeric两个真一维packet/连续receiver场的fullcapture、完整质量、side/q-band与E_y正确；按当前中心side分段计算真实局部volume，再积分log，未使用全E代替E_y。Fraction/SymPy表达式和256-bit Arb strict gaps匹配。N=1/2/16只改变同一场表示，R映射和source条件集合不变；旧界精确增XlogN，稳定界不变。稳定界无需逐次小于粗旧界，稿件已明说。来源mass不等的第二场不被冒称复杂相关性压力或完整history实例。

## 3. 实际隔离复现与有限性

指定数学Python `/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python` 在新目录
`/var/folders/lq/2c4qbz2n0354_tnttkv_qsz00000gn/T/r454_audit_isolated_yruszywv`
实际运行三个归档脚本；三份stdout与冻结结果逐字节一致，numeric生成JSON亦逐字节一致。最终mainproof纯格式修改未改数学/脚本，临时float probe已明确不归档、不作证明。

正式证据分类：mainproof 44 Fraction+6 Arb断言；geometry一个native一维场的边缘有理核算；numeric两真一维场/N1,2,16的67项精确、符号和区间检查。一般结果依解析证明，不从检查数推出。PRE临时符号/局部积分仅审查辅助，不追加归档统计。资源记录为作者实跑，未推扣额、未加入新扫描。无未修实质阻断项；原R433、初始/删除/未来限制/全尺度入口/吸收手续仍按原账保留。

## 4. 最终字节绑定（14输入）

- `r454_main.md`: `e92c1c4cd792f49d9f100152c72445f96888a99f182e693c14ec2eb490582636`
- `r454_stable_entropy.md`: `3f82b6beb9e8e21fc329464014711fdf5bdb3a753871b0df7e002f51ff93e1f1`
- `r454_geometry.md`: `fec4be5503e536d5eb6413a9b82c935e4d4b19d97171d571971f5d6a65c7fb43`
- `r454_geometry_check.py`: `db10262dd2813c7026ac8d372f237d785db2185f6776c4170376149aa6c05de3`
- `r454_geometry.result.txt`: `2955d2179b5e8abe346a5dd0dbf61b452a7af5f39f46af0c70bb1a46dbb250af`
- `r454_mainproof.md`: `d19dd6357cae44a142243c87eae97d67eebd5c74dee030c0a16f9ba24c46fa22`
- `r454_mainproof_check.py`: `9d9a18d127a8728a9f311720e7c0c1fd8ab3abf0e08a0ef5815974f4243ec62b`
- `r454_mainproof.result.txt`: `b17d9420861431a61fab2c89ffd54669e39243176b34a6fce494694e4c58b94d`
- `r454_numeric.md`: `02caa64306f1ab1c073930087243c54632bfede26d28a481e758f23e43391814`
- `r454_numeric.py`: `d867ecbd9c0449d73bd8d62de270cc0c38af41f253a709297227ca4ee80a8ffa`
- `r454_numeric_certificate.json`: `a3f25665faa99f4333148418afcb8906e54adec253c0c66130cf2cac3b8c4a5b`
- `r454_numeric_run.txt`: `5fc1aef1a25b30d4e01774bb2e546ddf8e8459c135b48becf18d0782fdb4db72`
- `r454_numeric_resources.txt`: `0c20afe00e71d0df637286558afaf75ace6f46c953fa3404d3a7a0d5ea2d6229`
- `r454_numeric_compute_index.md`: `a5b2746a2f454522fd2329b4c84f671188d15b7f0b1f1408ef7f050b0c91200f`

---

# R454 independent audit — PRE：stable source-conditioned entropy lemma PASS

PRE ONLY。本轮先独立推导两条精确熵界，再读 `r454_stable_entropy.md`；该lemma通过，尚非整轮FINAL或原预算付款。不读/预认后续F≤CH或matching压价结论，仅修改本文件。

## 1. 点态几何与可测性

设n≥1、0<a≤R_A≤b≤2a、E及R可测。E_y={A∈E:y∈Q_A}包含于以y为中心边长b的盒；不需E自身有界/有限。将其每坐标分四段，得到4^n个半开胞C_l(y)，每边b/4≤a/2。若A,B同胞，|B−A|∞≤b/4≤R_A/2，因此C_l⊂Q_A；这里使用真实R_A下界，不给每个source自由另选radius。等号和闭cube面不改变任何接收Lebesgue积分。

记t_l=|E_y∩C_l|、ρ_l=∫E_y∩C_l R_A^−n dA。ρ_l≥0、Σρ_l=D(y)，且t_l≥a^nρ_l。对ρ_l>0的胞及其中A，真实局部交集|E_y∩Q_A|≥t_l>0。ρ_l=0等价于t_l=0，这些胞对当前A积分零；无须把log∞乘成正费用。对每个y，局部零交集点在Ey的接收测度为零。

A,y→1_E(A)c_A(y)可测，|E_y∩Q_A|=∫_E c_B(y)c_A(B)dB是联合参数积分；胞可随y平移而仍联合可测。因而D、H_y、ρ_l(y)及后续f积分可测；逐y零异常通过Tonelli也对fdy×接收测度为零。R权有正上下界，所有点态D≤(b/a)^n；无需来源密度帽、source产品结构或任何history转授。

## 2. 精确熵上界

逐胞用R_A^n≤b^n与t_l≥a^nρ_l，得

    H_y≤Σ_l ρ_l log[e(b/a)^n/ρ_l]
       ≤D(y) log[e(4b/a)^n/D(y)]。

后一步为有限4^n胞的概率熵≤log4^n或凹Jensen；未取无穷分割极限。D=0时Ey接收测度零，H_y=0，右侧连续延拓为0。原局部交集≤R_A^n也给H_y≥D；该上界的对数项不会产生负价。它对任意可测Ey直接成立，完全不依赖输入接收盒如何人为细分。

设f≥0、W=∫f<∞、X=∫fD、H=∫fH_y。W>0时在概率fdy/W上再次Jensen给

    H≤X log[e(4b/a)^n W/X]
     ≤[1+n log(4b/a)]X+W/e
     ≤(1+n log8)X+W/e。

凹函数u log(C/u)在[0,(b/a)^n]连续有界，故Jensen及积分有限性都有先验保证，不作∞−∞或未经证明的极限交换。X=0给f-a.e D=0，从点态界H=0；W=0也为0。积分归一化质量是W，但Jensen所得乘子是X，不能把它替换成W。

重要scope：没有X/W下界时，精确式中的X log(W/X)必须保留，不能笼统推出H≤O(n)X；合法粗式是O(n)X+W。作者稿式(2)已保这一项，不需修订。即使full matching下X≤A_nW，现有结果通常仍只给O(n²)W。没有H≤Cn polylog W、没有把nX当nW。

## 3. 原目标和后审门槛

本lemma修复R453按每个接收胞独立收费导致的XlogN不稳定，提供真实source-conditioned、表示不变的量。它没有证明F=∫fD²≤CH，也没有用匹配为H压低来源价；两者不能从该上界或有限计算中默认。即便另有F≤CH，当前式(2)亦非原目标的根阶源预算。

后续若作者给F比较，需保同一Ey、实际R_A、完整f及乘数；如使用原history剩余的投影，还须指出真实可用source权和原初始/删除/clock费用，不能将无门lemma自动成为原支付。任何额外KL/entropy信用都须同流且只结一次。原R433及完整母账当前不变。

## 4. 实际本机辅助与输入绑定

指定math-research-tools Python实际用SymPy核一维R=1、E=[−δ/2,δ/2]、f=1_[−2,2]的准确积分：

    X=δ， H=δ(1−logδ)+δ²/2。

这是Ey小区间相互包含时的真实source-conditioned积分。δ=1/4、1/16用192-bit Arb核其与两条lemma上界的严格方向；仅有限局部核查，不作高维/原history覆盖，也不另计新增正式模型。它同时说明为何不能无条件删除Xlog(W/X)。通用证明由第1–2节给出，不靠这些参数核验。

已读作者短稿与上述独立证明一致。此处绑定当前lemma输入（最终白名单齐备后另审）：

- `r454_stable_entropy.md`: `3f82b6beb9e8e21fc329464014711fdf5bdb3a753871b0df7e002f51ff93e1f1`

PRE结论：两条精确一般熵界 PASS；稳定性成立，但原root来源价/完整F比较未证。完成本有界预审，等待作者后续具体步骤。


## 5. 新一般Iα/cubic lemma的独立审查（先于mainproof）

对0<α≤1，定义Iα(y)=∫Ey R_A^−n p_y(A)^αdA，p_y(A)=|Ey∩Q_A|/R_A^n。独立审查结果：

    Iα(y)≤4√(n/α)，
    D(y)³≤(64/log2)nH_y。

证明可以完全脱离q-band/matching/history，对任意本轮可测单octave场成立：

(1) 平移y=0、按b/2缩放，Ey⊂[-1,1]^n，实际side∈[2a/b,2]⊂[1,2]。先把p中的Ey扩大到整个[-1,1]^n，并把积分域上放到该cube（每个A仍需捕获0）。对固定A∈[-1,1]^n，单坐标交长g_i(R)随R的斜率依次1、1/2、0，故凹、g_i(0)=0，g_i(R)/R非增。于是fullcube版 integrand R^−n∏[g_i(R)/R]^α非增。可以取最小合法capturing side R*=max(1,2||A||∞)作正上界；这里是已经上放后的显式共同envelope，不假称原selector随source改变，也不是把自由半径价当原等式。

(2) 内cube[-1/2,1/2]^n的贡献为1。外部以t=2||A||∞∈[1,2]作face分解；面上极值坐标交长为1，其他坐标均匀积分的归一因子是

    Uα(t)=2/t−1+2∫_{1/t}^1 z^α dz
         =2/t−1+[2/(α+1)](1−t^−(α+1))。

故正上界恰为1+n∫_1^2 t^−1−α Uα(t)^(n−1)dt。取α=1，U1=1−((t−1)/t)²；由0<α≤1时z^α≤1−α(1−z)，Uα≤1−α((t−1)/t)²。

(3) n≥2令u=(t−1)/t，t^−1−αdt=(1−u)^(α−1)du≤2du，得外项≤2n∫_0^∞exp[−α(n−1)u²]du=n√π/√(α(n−1))。加内1后小于4√(n/α)：用π<4及n/(n−1)≤2，比例不超过1/√2+2√2=5/√2<4即可。n=1由Iα≤D≤1+log2单独成立，避免n−1分母零。以上均保真实中心Lebesgue面Jacobian与base贡献。

(4) 对D>0在概率R_A^−n1_Ey dA/D上Jensen，有更强式

    D exp[α(1−H_y/D)]≤Iα，

所以题给弱式Dexp(−αH_y/D)≤Iα正确。H_y有限由已证stable lemma保证，p=0异常可先截断log再单调收敛；不需要假设来源密度连续。若D≥8√n，选α=64n/D²∈(0,1]，上界恰D/2，故αH_y/D≥log2，得到cubic结论。若D<8√n，D³≤64nD≤64nH_y，同一常数64/log2仍够；D=0平凡。所有参数选择点态可测，不能把作者尚未给的F≤CH作为此推导前提。

于是积分后∫fD³≤(64/log2)nH，并由Hölder

    F=∫fD²≤[(64/log2)nH]^(2/3)W^(1/3)。

即使未来H≤O(n)W，该式也只给F≤O(n^(4/3))W，不能错记为nW或一般根阶付款。当前stable H≤O(n)X+W本身并未提供这种额外H源价。

指定数学Python/SymPy实际核α=1,1/2,1/4的face积分原函数、U1二次恒等式及α=64n/D²时4√(n/α)=D/2；Fraction核Gaussian常数比较25/2<16。它们仅为审查辅助符号核，不替代以上一般coarea/凹性证明，不追加native/history模型计数。后续等作者冻结稿再核其表述与最终总账。
