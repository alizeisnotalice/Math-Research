from fractions import Fraction as F

# One native 1D, full-capture, fixed-side field; no original-history claim.
packets = [(F(-251,1000), F(-249,1000)),
           (F(249,1000), F(251,1000))]
centers = [(F(-3,5),F(-2,5)), (F(-1,20),F(1,20)),
           (F(9,20),F(11,20))]
mass = [F(1,2), F(1,2)]
B = [[1,0],[1,1],[0,1]]
vol = [b-a for a,b in centers]
for j,(l,r) in enumerate(centers):
    for i,(p,q) in enumerate(packets):
        if B[j][i]:
            assert p >= r-F(1,2) and q <= l+F(1,2)
        else:
            assert q < l-F(1,2) or p > r+F(1,2)
m = [sum(mass[i]*B[j][i] for i in range(2)) for j in range(3)]
assert m == [F(1,2),F(1),F(1,2)]
D = [sum(vol[j]*B[j][i] for j in range(3)) for i in range(2)]
gamma = [[mass[i]*vol[j]*B[j][i] for j in range(3)] for i in range(2)]
source = [sum(row) for row in gamma]
parent = [sum(gamma[i][j] for i in range(2)) for j in range(3)]
assert D == [F(3,10),F(1,5)]
assert source == [mass[i]*D[i] for i in range(2)]
assert parent == [vol[j]*m[j] for j in range(3)]
assert sum(source) == sum(parent) == F(1,4)

# Source-preserving relocation to a different actual capturing center law.
relocated = [[source[i]*F(B[j][i],sum(B[k][i] for k in range(3)))
              for j in range(3)] for i in range(2)]
assert [sum(row) for row in relocated] == source
relocated_parent = [sum(relocated[i][j] for i in range(2)) for j in range(3)]
assert relocated_parent == [F(3,40),F(1,8),F(1,20)]
assert relocated_parent != parent

# Dividing by actual D yields source mass, but a different parent marginal.
normalized = [[gamma[i][j]/D[i] for j in range(3)] for i in range(2)]
new_parent = [sum(normalized[i][j] for i in range(2)) for j in range(3)]
assert [sum(row) for row in normalized] == mass
assert new_parent == [F(1,3),F(5,12),F(1,4)]
for j in range(3):
    posterior_inverse = sum(mass[i]*B[j][i]/(m[j]*D[i]) for i in range(2))
    assert new_parent[j] == parent[j]*posterior_inverse
assert sum(new_parent) == 1 and new_parent != parent
print('PASS: native full-capture incidences and exact matching')
print('D =', D, '; original source marginal =', source)
print('original parent marginal =', parent)
print('source-preserving relocated parent marginal =', relocated_parent)
print('D-normalized parent marginal =', new_parent)
print('Scope: marginal bookkeeping only; no H or M2 estimate, no history claim.')
