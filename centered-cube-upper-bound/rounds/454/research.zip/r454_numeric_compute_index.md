# R454 计算索引

- 责任：Sol medium，仅/tmp/r454_numeric*，无repo/他人修改、git或spawn。
- 阅读：r454_stable_entropy.md、r453_geometry_check.py；未执行别人脚本，不依赖其输出。
- 真几何输入：两正体积source packets，三个连续receiver区间。场1 W1,X3/10,a=b1；场2 source质量1/3,2/3、central side2，W1,X1/4,a1b2。全部输入本轮脚本自含。
- 运算：Fraction验证全捕获/matching/union及X；SymPy分段log积分、稳定界细分不变、旧界增XlogN、凹性；256-bit Arb strictgap。
- 实际范围：两场，各N1,2,16；67checks PASS，无额外扫描或三阶段扩例。
- 环境：指定数学Python3.12.14、SymPy1.14.0、python-flint0.9.0；.25s、RSS73,859,072bytes。
- 结论：两场H严格小于稳定界，实际H及稳定界不随表示细分改变；非一般proof、非原history、非根阶预算。
- 输出：r454_numeric.py、r454_numeric_certificate.json、r454_numeric_run.txt、r454_numeric_resources.txt、r454_numeric.md、此index。
- 状态：冻结停止。
