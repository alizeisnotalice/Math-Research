#!/usr/bin/env python3
"""Two genuine L1 source-conditioned entropy fields; representation invariance."""
from fractions import Fraction as Q
from pathlib import Path
import json,sys,platform
import sympy as s
import flint
from flint import arb,ctx
ctx.prec=256
ROOT=Path(__file__).resolve().parent
checks=0
def ck(x):
 global checks
 assert x
 checks+=1
def rat(x):return s.Rational(x.numerator,x.denominator) if isinstance(x,Q) else s.Rational(x)
def interval_union(intervals):
 out=[]
 for l,r in sorted(intervals):
  if out and l<=out[-1][1]:out[-1]=(out[-1][0],max(out[-1][1],r))
  else:out.append((l,r))
 return out
def eval_arb(x):
 if x.is_Rational:return arb(int(x.p))/int(x.q)
 if x.func==s.log:return eval_arb(x.args[0]).log()
 if x.func==s.Add:return sum((eval_arb(t) for t in x.args),arb(0))
 if x.func==s.Mul:
  z=arb(1)
  for t in x.args:z*=eval_arb(t)
  return z
 if x.func==s.Pow and x.args[1].is_Integer:return eval_arb(x.args[0])**int(x.args[1])
 raise ValueError(x)
def entropy_for_source(Ey):
 total=s.Integer(0);pieces=[]
 for al,ar,R in Ey:
  cuts=sorted(set([al,ar]+[p+sign*R/2 for l,r,_ in Ey for p in (l,r) for sign in (-1,1) if al<p+sign*R/2<ar]))
  for l,r in zip(cuts,cuts[1:]):
   mid=(l+r)/2;intercept=Q(0);slope=Q(0)
   for el,er,_ in Ey:
    if max(el,mid-R/2)>=min(er,mid+R/2):continue
    lo=(el,Q(0)) if el>=mid-R/2 else (-R/2,Q(1))
    hi=(er,Q(0)) if er<=mid+R/2 else (R/2,Q(1))
    intercept+=hi[0]-lo[0];slope+=hi[1]-lo[1]
   Ll=intercept+slope*l;Lr=intercept+slope*r
   ck(Ll>0 and Lr>0)
   if slope:
    primitive=lambda z:rat(z)*(s.log(rat(z))-1)
    integral=((rat(r-l)*(1+s.log(rat(R))))-(primitive(Lr)-primitive(Ll))/rat(slope))/rat(R)
   else:integral=rat((r-l)/R)*(1+s.log(rat(R/intercept)))
   total+=integral
   pieces.append(dict(left=l,right=r,R=R,local_volume_intercept=intercept,local_volume_slope=slope,contribution=str(integral)))
 return s.expand_log(s.simplify(total),force=True),pieces
P=[(Q(-251,1000),Q(-249,1000)),(Q(249,1000),Q(251,1000))]
BASE=[(Q(-3,5),Q(-2,5)),(Q(-1,20),Q(1,20)),(Q(2,5),Q(3,5))]
def run(name,weights,sides):
 E=[(l,r,R) for (l,r),R in zip(BASE,sides)]
 B=[]
 for l,r,R in E:
  row=[]
  for pl,pr in P:
   full=pl>r-R/2 and pr<l+R/2
   miss=pr<l-R/2 or pl>r+R/2
   ck(full!=miss);row.append(int(full))
  B.append(row)
 ck(B==[[1,0],[1,1],[0,1]])
 W=sum(weights);masses=[sum((a*b for a,b in zip(weights,row)),Q(0)) for row in B]
 densities=[m/R for m,(_,_,R) in zip(masses,E)]
 X=sum(((r-l)*m/R for (l,r,R),m in zip(E,masses)),Q(0))
 H=s.Integer(0);source_data=[]
 for i,a_i in enumerate(weights):
  Ey=[g for g,row in zip(E,B) if row[i]]
  Hy,pieces=entropy_for_source(Ey)
  D=sum(((r-l)/R for l,r,R in Ey),Q(0))
  H+=rat(a_i)*Hy
  source_data.append(dict(source_mass=a_i,Ey=Ey,D=D,Hy=str(Hy),pieces=pieces))
 H=s.expand_log(s.simplify(H),force=True)
 a,b=min(sides),max(sides);n=1
 stable=rat(X)*(1+s.log(rat(4*b*W/(a*X))))
 old=sum((rat((r-l)*m/R)*(1+s.log(rat(2*R/(r-l)))) for (l,r,R),m in zip(E,masses)),s.Integer(0))
 ck(eval_arb(H-rat(X))>0)
 ck(eval_arb(stable-H)>0 and eval_arb(old-H)>0)
 refinement=[]
 for N in (1,2,16):
  sub=[(l+(r-l)*k/N,l+(r-l)*(k+1)/N,R) for l,r,R in E for k in range(N)]
  for i in range(len(P)):
   before=[(l,r) for (l,r,R),row in zip(E,B) if row[i]]
   after=[(l+(r-l)*k/N,l+(r-l)*(k+1)/N) for (l,r,R),row in zip(E,B) if row[i] for k in range(N)]
   ck(interval_union(after)==interval_union(before))
  refined_X=sum(((r-l)*masses[j//N]/R for j,(l,r,R) in enumerate(sub)),Q(0))
  ck(refined_X==X)
  refined_stable=rat(refined_X)*(1+s.log(rat(4*b*W/(a*refined_X))))
  ck(s.simplify(refined_stable-stable)==0)
  refined_old=sum((rat((r-l)*masses[j//N]/R)*(1+s.log(rat(2*R/(r-l)))) for j,(l,r,R) in enumerate(sub)),s.Integer(0))
  ck(s.simplify(s.expand_log(refined_old-old,force=True)-rat(X)*s.log(N))==0)
  refinement.append(dict(N=N,X=refined_X,stable=str(refined_stable),stable_interval=str(eval_arb(refined_stable)),
    old=str(s.expand_log(refined_old,force=True)),old_interval=str(eval_arb(refined_old)),old_increase=str(rat(X)*s.log(N))))
 return dict(name=name,source_packets=P,source_weights=weights,receivers=E,receiver_mass=masses,q_min=min(densities),q_max=max(densities),
  n=n,a=a,b=b,W=W,X=X,H=str(H),H_interval=str(eval_arb(H)),stable=str(stable),stable_interval=str(eval_arb(stable)),
  stable_gap_interval=str(eval_arb(stable-H)),old_base=str(s.expand_log(old,force=True)),old_gap_interval=str(eval_arb(old-H)),
  sources=source_data,refinements=refinement)
results=[run('R453_equal_side_equal_source', [Q(1,2),Q(1,2)],[Q(1),Q(1),Q(1)]),
 run('unequal_source_central_side_two',[Q(1,3),Q(2,3)],[Q(1),Q(2),Q(1)])]
ck(results[0]['W']==1 and results[0]['X']==Q(3,10))
ck(results[1]['a']==1 and results[1]['b']==2 and results[1]['X']==Q(1,4))
t=s.symbols('t',positive=True);C=s.symbols('C',positive=True)
ck(s.simplify(s.diff(t*s.log(C/t),t,2)+1/t)==0)
out=dict(scope='two finite native one-dimensional entropy checks, not the general proof/history',
 executable=sys.executable,python=platform.python_version(),sympy=s.__version__,python_flint=flint.__version__,arb_bits=ctx.prec,checks=checks,cases=results)
def enc(x):
 if isinstance(x,Q):return str(x)
 raise TypeError(type(x).__name__)
(ROOT/'r454_numeric_certificate.json').write_text(json.dumps(out,default=enc,indent=2)+'\n')
print('executable:',sys.executable,'Python:',platform.python_version(),'SymPy:',s.__version__,'python-flint:',flint.__version__,'Arb bits:',ctx.prec)
for r in results:
 print(r['name'],'W=',r['W'],'X=',r['X'],'qband=',r['q_min'],r['q_max'],'a,b=',r['a'],r['b'])
 print(' H=',r['H']);print(' H interval=',r['H_interval']);print(' stable=',r['stable']);print(' stable gap=',r['stable_gap_interval'])
 for z in r['refinements']:print(' N=',z['N'],'stable=',z['stable_interval'],'old=',z['old_interval'],'old increase=',z['old_increase'])
print('PASS',checks,'exact/symbolic/Arb checks; two fields, N=1,2,16, no scan')
