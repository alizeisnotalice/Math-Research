# R454 稳定来源熵上界的有限核验（冻结）

指定R453原场及一个简单两尺度非均匀L¹场均通过。实际H由真实来源条件集合 E_y 的分段log积分精确计算，再用256-bit Arb认证H严格小于稳定上界。N=1,2,16只是同一receiver场的表示细分：真实H、X和稳定界不变，旧cell界精确增加X log N。主证明不依赖这两个有限实例，本轮不认证一般二阶矩或原history界。

## 1. 共同真几何与两场

来源是以±1/4为中心、半宽1/1000的两个正体积packets，各自上密度常数。receiver为三个实际连续区间：

`L=[−3/5,−2/5]`，`O=[−1/20,1/20]`，`R=[2/5,3/5]`。

每个receiver区间指定一个side；脚本对完整source packet及整个receiver区间核全捕获或全不捕获。捕获表严格为`[(1,0),(1,1),(0,1)]`，故任意左source点的 E_y=L∪O，右source点的 E_y=O∪R。H的真实积分不把 E_y 改成E。

- 指定R453场：source质量各1/2，side全1。W=1、X=3/10、n=1、a=b=1；完整receiver质量为(1/2,1,1/2)，q-band=[1/2,1]。
- 简单两尺度场：source质量1/3、2/3，side为(1,2,1)。W=1、X=1/4、n=1、a=1,b=2；完整receiver质量为(1/3,1,2/3)，q-band=[1/3,2/3]，octave2。来源是非均匀L¹函数；因几何镜像，两source的H_y恰相同，未将此例当作复杂来源相关性测试。

只读了root稿`r454_stable_entropy.md`及`r453_geometry_check.py`，未执行或覆盖别人脚本/输出。计算脚本内置本轮全部输入，无旧轮运行依赖。

## 2. 实际H与稳定界

对每段receiver A，精确求 `|E_y∩Q_A|=u+vA`，在分段端点处验证严格正值。以有理端点的 `(u+vA)log(u+vA)` primitive 计算

`H=∫f(y)∫_(A∈E_y) R_A^-1 log(e R_A/|E_y∩Q_A|)dA dy`。

SymPy保留精确elementary log表达式；Arb从有理数直接评价并认证以下strict gaps，不用浮点符号判断。

| 场 | 实际H（显示值） | 稳定界 X log(e·4^n(b/a)^n W/X) | 稳定界−H |
|---|---:|---:|---:|
| W1,X3/10,a=b1 | .7419803871960530 | 1.0770801496337480 | .3350997624376950 |
| W1,X1/4,a1,b2 | .6248307938932566 | 1.1164339756999316 | .4916031818066750 |

第一场精确H为 `1/2−log(3)/5+log(10240)/20`，稳定界为 `3/10+(3/10)log(40/3)`。第二场精确H可写为 `7/20+(9/20)log2+(1/4)log5−(2/5)log3`，稳定界为 `1/4+(1/4)log32`。JSON保存SymPy原表达式、分段primitive及完整Arb误差区间；上述稳定gap区间下端均严格大于0。另核H>X及h(t)=t log(C/t)的二阶导数−1/t。

## 3. N=1,2,16的表示细分

逐receiver区间分为N个等长子区间，R不变；每个source条件集合的子区间union精确等于原E_y。脚本核合并后的端点及X相等，因此实际H不因表示改变。

采用R453同一旧cell界及其variable-side直接延拓：

`Old_N=Σ_receiver m_j |E_j|/R_j · [1+log(2R_j N/|E_j|)]`。

这里每个receiver区间直径≤a/2，故同cell中心互相被真实cube覆盖。自己的完整cell已给局部交集下界，额外2因子只是保留既有较粗旧界。第一场该式严格就是R453旧界；第二场明确按各自真实R计算，未偷用side1。

SymPy逐个N精确核 `Old_N−Old_1=X log N`，同时核稳定界符号差为0。

| 场 | N=1旧界 | N=2旧界 | N=16旧界 | 新稳定界（各N相同） |
|---|---:|---:|---:|---:|
| X=3/10 | 1.060090245954208 | 1.268034400122192 | 1.891866862626143 | 1.077080149633748 |
| X=1/4 | .894960991304506 | 1.068247786444492 | 1.588108171864451 | 1.116433975699932 |

稳定界不保证比每个粗分区旧界都小；本轮验证的是其不受任意表示细化影响。没有把稳定公式中的nX误记成nW，未推出一般根阶付款。

## 4. 复现与范围

```sh
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/r454_numeric.py
```

实际Python3.12.14、SymPy1.14.0、python-flint0.9.0、Arb256bits。67项精确/符号/区间检查PASS；实际.25秒、最大RSS73,859,072bytes。没有为“三阶段”另加实例、无scan/solver，无git/spawn/repo或他人修改。

冻结白名单：`r454_numeric.py`、`r454_numeric_certificate.json`、`r454_numeric_run.txt`、`r454_numeric_resources.txt`、`r454_numeric.md`、`r454_numeric_compute_index.md`。脚本自含、同目录写证书，完成停止。
