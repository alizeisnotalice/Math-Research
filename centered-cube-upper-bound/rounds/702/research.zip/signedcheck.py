"""Exact adaptive-sign tree stress test; no complement signs are observed."""
import sys,json,os,socket,time
from multiprocessing import get_context
def run(arg):
    n,rows=arg; masks=(1<<n)-1
    seen=0
    for seed in rows:
        length=2+seed%min(6,n-1)
        yes=0
        for word in range(1<<n):
            avail=list(range(n)); seq=seed+11; matched=True
            for step in range(length):
                k=avail.pop(seq%len(avail))
                predict=((seq//7)+k+step)%2
                bit=(word>>k)&1
                if bit!=predict:matched=False;break
                seq=(3*seq+11*k+bit+step)%1009
            yes+=matched
        assert yes==1<<(n-length)
        seen+=1
    return seen,os.getpid()
if __name__=='__main__':
    parity,w=map(int,sys.argv[1:]); rows=[(n,range(i,i+8)) for n in range(6+parity,18,2) for i in range(0,64,8)]
    with get_context('fork').Pool(w) as pool: out=pool.map(run,rows,1)
    print(json.dumps(dict(host=socket.gethostname(),python=sys.version,tests=sum(item[0] for item in out),workers=len(set(item[1] for item in out)),parity=parity)))
