"""Arb bounds on the matched row/column coefficients at integer dimensions."""
import sys,json,flint
from flint import arb,ctx
ctx.prec=192
checks=0
records=[]
for b in range(16,1001):
    n=2**b
    L=arb(n).log()
    K=64
    u=(L-2*L.log()+2*arb(K).log())/n
    e=u*(1+arb(1)/(32*n))**2
    sq=arb(n).sqrt()
    logpi=arb(n)/2*(-u).log1p()
    row=(arb(n)*(arb(1)/(32*n)).log1p()+logpi-L/2).exp()*(1-n/logpi)
    col=(arb(n)*(e/2).log1p()-L/2).exp()*(1+n*e/(2+e))
    assert row<arb(1)/8 and col<128
    if b in (16,32,64,256,1000):records.append([b,str(row),str(col)])
    checks+=1
print(json.dumps(dict(version=flint.__version__,python=sys.version,prec=ctx.prec,count=checks,samples=records)))
