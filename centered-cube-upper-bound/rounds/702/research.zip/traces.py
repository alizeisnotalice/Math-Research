"""Split integer enumeration of projection/envelope and tree bounds."""
import itertools,json,os,sys,socket,time
from multiprocessing import get_context
from functools import lru_cache
d=int(sys.argv[1]); phase=int(sys.argv[2]); workers=int(sys.argv[3])
sub=range(1<<d)
def pop(x):return bin(x).count('1')
gray=[x^(x>>1) for x in sub]
# e=2/5, projection sampling p=1/6. Multiply normalized envelope by 5**d.
def batch(span):
    count=tight=0
    max_trace=0
    for f in range(*span):
        if f%2!=phase:continue
        words=[x for x in gray if (f>>x)&1]
        if not words:continue
        trace=[len({x&m for x in words}) for m in sub]
        mass=sum(t*5**(d-pop(m)) for t,m in zip(trace,sub))
        edges=[pop(x^y) for x,y in zip(words,words[1:])]
        upper=6**d+sum(6**d-5**k*6**(d-k) for k in edges)
        # independent union enumeration on the three states in every coordinate
        # 0 means inside, 1 and 2 mean the two exterior signs
        direct=sum(w for m,b,w in states if any((x&m)==b for x in words))
        assert direct==mass<=upper
        tight+=mass==upper;count+=1;max_trace=max(max_trace,max(trace))
    return count,tight,max_trace,os.getpid(),time.process_time()
states=[]
for pattern in itertools.product(range(3),repeat=d):
    mask=sum(1<<j for j,z in enumerate(pattern) if z)
    bits=sum(1<<j for j,z in enumerate(pattern) if z==2)
    states.append((mask,bits,5**(d-pop(mask))))
if __name__=='__main__':
    N=1<<(1<<d)
    start=time.monotonic()
    with get_context('fork').Pool(workers) as pool:
        out=pool.map(batch,[(i,min(i+128,N)) for i in range(0,N,128)],1)
    print(json.dumps(dict(host=socket.gethostname(),version=sys.version,d=d,phase=phase,families=sum(i[0] for i in out),equal=sum(i[1] for i in out),max_trace=max(i[2] for i in out),pids=len(set(i[3] for i in out)),elapsed=time.monotonic()-start)))
