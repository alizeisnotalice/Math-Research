from fractions import Fraction as F
from itertools import product
from math import factorial
from pathlib import Path
import json

def cmul(a,b):return a[0]*b[0]-a[1]*b[1],a[0]*b[1]+a[1]*b[0]
def cpow(a,k):
    z=(F(1),F(0))
    for _ in range(k):z=cmul(z,a)
    return z

def fourier(freq):
    n=len(freq);alpha=[F(a) for a in freq if a];k=n-len(alpha);m=len(alpha)
    z=[F(0),F(0)]
    for signs in product([-1,1],repeat=m):
        w=sum((s*a for s,a in zip(signs,alpha)),F(0));v=cpow((1/(1+w*w),w/(1+w*w)),k+1)
        sign=1
        for s in signs:sign*=s
        z[0]+=sign*v[0];z[1]+=sign*v[1]
    z=cmul(z,cpow((F(0),F(-1)),m));den=factorial(n)*2**m
    for a in alpha:den*=a
    real,imag=(v*factorial(k)/den for v in z)
    assert imag==0
    return real

records=[]
for n in range(1,13):
    assert fourier([0]*n)==1
    records.append(dict(stage='normalization',n=n,frequency=[0]*n,value='1'))
for n in [1,2]:
    for freq in product(range(5),repeat=n):
        v=fourier(freq);assert v>0
        records.append(dict(stage='pilot',n=n,frequency=list(freq),value=str(v)))
assert fourier([1,1,3])==F(-1,780)
for q in [F(1,4),F(1,2),F(1),F(2),F(4),F(16)]:
    freq=[q,q,3*q];v=fourier(freq)
    # Independent sine-product expression in dimension three.
    sine=sum((F(s)*w/(1+w*w) for s,w in [(1,-q),(1,3*q),(1,3*q),(-1,5*q)]),F(0))/4
    assert v==sine/(6*3*q**3)
    records.append(dict(stage='pressure',n=3,frequency=list(map(str,freq)),value=str(v)))
for n in range(3,9):
    # Deterministic frequency search, no asymptotic fit or source model.
    fs=set(tuple([a]*(n-1)+[b]) for a in [1,2,4] for b in range(1,4*n+1))
    fs.update(tuple([a,b,c]+[0]*(n-3)) for a,b,c in [(1,1,3),(2,2,7),(1,2,4)])
    values=[(freq,fourier(freq)) for freq in sorted(fs)]
    for freq,v in values:
        records.append(dict(stage='expanded',n=n,frequency=list(freq),value=str(v)))
    best=min(values,key=lambda x:x[1])
    print('n',n,'records',len(values),'minimum',str(best[1]),'frequency',best[0])
result=dict(scope='Exact Fourier multipliers of a positive radial kernel; no actual lower-input recipe, maximal weak bound, or semigroup claim.',kernel='exp(-norm_inf(x))/(2^n n!)',fourier_convention='integral exp(-i x dot xi) kernel(x) dx',countervalue='-1/780 at n=3, xi=(1,1,3)',counts={stage:sum(r['stage']==stage for r in records) for stage in ['normalization','pilot','pressure','expanded']},records=records)
Path(__file__).with_name('parent_gamma_results.json').write_text(json.dumps(result,indent=2)+'\n')
print('PASS',len(records),'exact records')
