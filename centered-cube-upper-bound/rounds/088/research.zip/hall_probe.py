#!/usr/bin/env python3
"""PUBLIC R88 exact finite Hall/principal certificates and bridge arithmetic.
All graphs/radial proxies NONPHYSICAL. No private recipe; no actualFnew claim.
"""
from fractions import Fraction as F
from pathlib import Path
import json,random
SEED=880612

def clean(v):
    if isinstance(v,F):return str(v)
    if isinstance(v,dict):return {str(k):clean(x) for k,x in v.items()}
    if isinstance(v,(list,tuple)):return [clean(x) for x in v]
    return v

class Flow:
    def __init__(self,n):self.n=n;self.cap={};self.adj=[set() for _ in range(n)];self.f={}
    def add(self,u,v,c):
        assert c>=0;self.cap[u,v]=self.cap.get((u,v),F(0))+c;self.adj[u].add(v);self.adj[v].add(u);self.f.setdefault((u,v),F(0));self.f.setdefault((v,u),F(0))
    def run(self,s,t):
        total=F(0)
        while True:
            pred={s:None};queue=[s]
            for u in queue:
                for v in sorted(self.adj[u]):
                    if v not in pred and self.cap.get((u,v),F(0))-self.f[u,v]>0:pred[v]=u;queue.append(v)
                if t in pred:break
            if t not in pred:break
            path=[];v=t
            while v!=s:u=pred[v];path.append((u,v));v=u
            a=min(self.cap.get(e,F(0))-self.f[e] for e in path)
            for u,v in path:self.f[u,v]+=a;self.f[v,u]-=a
            total+=a
        seen={s};q=[s]
        for u in q:
            for v in sorted(self.adj[u]):
                if v not in seen and self.cap.get((u,v),F(0))-self.f[u,v]>0:seen.add(v);q.append(v)
        cut=sum(c for (u,v),c in self.cap.items() if u in seen and v not in seen)
        assert cut==total
        for (u,v),c in self.cap.items():assert 0<=self.f[u,v]<=c
        for v in range(self.n):
            net=sum(self.f.get((v,j),F(0)) for j in self.adj[v]);assert net== (total if v==s else -total if v==t else 0)
        return dict(value=total,residual_source_side=sorted(seen),cut_capacity=cut,arcs=[dict(u=u,v=v,capacity=c,flow=self.f[u,v]) for (u,v),c in sorted(self.cap.items())])

def density(masses,rows):
    N=len(masses);best=F(0);maxim=[];cuts=[]
    for S in range(1,1<<N):
        p=sum(masses[i] for i in range(N) if S>>i&1)
        forced=[j for j,r in enumerate(rows) if r['mask']&~S==0]
        d=sum((rows[j]['d'] for j in forced),F(0));k=d/p;cuts.append(dict(mask=S,mass=p,forced_rows=forced,demand=d,density=k))
        if k>best:best=k;maxim=[S]
        elif k==best:maxim.append(S)
    U=0
    for S in maxim:U|=S
    forced=[j for j,r in enumerate(rows) if r['mask']&~U==0]
    mass=sum(masses[i] for i in range(N) if U>>i&1);d=sum((rows[j]['d'] for j in forced),F(0))
    assert d==best*mass
    return best,U,forced,maxim,cuts

def flow_certificate(masses,rows,K):
    N=len(masses);J=len(rows);s=0;r0=1;y0=1+J;t=y0+N;f=Flow(t+1);D=sum((r['d'] for r in rows),F(0));big=D+K*sum(masses)+1
    for j,r in enumerate(rows):
        f.add(s,r0+j,r['d'])
        for i in range(N):
            if r['mask']>>i&1:f.add(r0+j,y0+i,big)
    for i,p in enumerate(masses):f.add(y0+i,t,K*p)
    out=f.run(s,t);assert out['value']==D
    out.update(source_node=s,sink_node=t,row_node_start=r0,source_bin_node_start=y0)
    return out

def canonical(masses,rows,T):
    out=[]
    for i,p in enumerate(masses):
        v=[r for r in rows if r['mask']>>i&1];mom=[sum((r['d']/sum(masses[z] for z in range(len(masses)) if r['mask']>>z&1)*r['u']**q for r in v),F(0)) for q in range(3)]
        b,a,c=mom;var=c/b-(a/b)**2 if b else F(0);assert var>=0
        out.append(dict(source=i,b=b,m1=a,m2=c,variance_proxy=var,above_T=b>T))
    I=sum((masses[i]*r['variance_proxy'] for i,r in enumerate(out) if r['above_T']),F(0))
    return out,I

def graph_case(name,p,data,stage):
    p=list(map(F,p));rows=[dict(mask=m,d=F(d),u=F(u)) for m,d,u in data];N=len(p);assert all(r['mask'] and r['mask']<(1<<N) for r in rows)
    K,U,forced,maxim,cuts=density(p,rows);mainflow=flow_certificate(p,rows,K)
    active=(1<<N)-1;remaining=[dict(r,index=j) for j,r in enumerate(rows)];blocks=[];prefixrows=[];prefixS=0;prev=None
    while remaining:
        pp=[p[i] if active>>i&1 else F(0) for i in range(N)]
        ids=[i for i in range(N) if active>>i&1];compact=[p[i] for i in ids]
        cr=[dict(r,mask=sum(1<<z for z,i in enumerate(ids) if r['mask']>>i&1)) for r in remaining]
        k,S,fr,allmax,subcuts=density(compact,cr);fullS=sum(1<<ids[z] for z in range(len(ids)) if S>>z&1)
        if prev is not None:assert k<prev
        assigned=[remaining[j] for j in fr];oldids=[r['index'] for r in assigned];prefixrows+=oldids;prefixS|=fullS
        orig=[rows[j] for j in prefixrows];neighbor=0
        for r in orig:neighbor|=r['mask']
        assert neighbor==prefixS
        D=sum((r['d'] for r in orig),F(0));mass=sum(p[i] for i in range(N) if prefixS>>i&1)
        cols,I=canonical(p,orig,F(10));blockp=[p[i] for i in ids if fullS>>i&1]
        blockids=[i for i in ids if fullS>>i&1]
        br=[dict(r,mask=sum(1<<z for z,i in enumerate(blockids) if r['mask']>>i&1)) for r in assigned]
        bf=flow_certificate(blockp,br,k)
        blocks.append(dict(density=k,source_mask=fullS,row_indices=oldids,residual_maximizer_masks=allmax,residual_compact_sources=ids,
          residual_cuts=subcuts,block_flow=bf,principal_prefix=dict(row_indices=list(prefixrows),source_mask=prefixS,source_closure_mask=neighbor,
          demand=D,source_mass=mass,v=D/mass,D_over_W=D/sum(p),canonical_columns=cols,I_T_proxy=I,T=F(10),
          qualification='NONPHYSICAL finite graph with rational u proxy; R85 geometric estimate is not assumed.')))
        active&=~fullS;remaining=[dict(r,mask=r['mask']&active) for j,r in enumerate(remaining) if j not in fr];prev=k
        assert all(r['mask'] for r in remaining)
    cols,I=canonical(p,rows,F(10));D=sum((r['d'] for r in rows),F(0))
    assert sum(p[i]*r['b'] for i,r in enumerate(cols))==D
    return dict(name=name,stage=stage,scope='NONPHYSICAL exact finite source/row graph. No positive-dx or firstcontact/gates are claimed.',source_masses=p,rows=rows,
      optimal_K=K,union_all_maximizers=U,all_maximizers=maxim,all_source_cuts=cuts,optimal_flow=mainflow,
      principal_blocks=blocks,total_D=D,W=sum(p),D_over_W=D/sum(p),canonical_columns=cols,canonical_max=max(r['b'] for r in cols),I_T_proxy=I)

def bridge(n,T,v):
    n,T,v=int(n),F(T),F(v);R=(T*T-96)/(24*n);assert R>=0
    res=(v-T)**2-24*n*R-48*v/T
    fact=(v-2*T)*(v-48/T);assert res==fact
    assumed=v<=T or res<=0
    if assumed:assert v<=2*T
    return dict(n=n,T=T,R=R,v=v,quadratic_residual=res,factorized_residual=fact,assumption_satisfied=assumed,
      conclusion_v_le_twoT_if_assumption=not assumed or v<=2*T,scope='Exact conditional scalar bridge arithmetic only; no canonical variance estimate is proved.')

def main():
    graphs=[graph_case('pilot_shared',(1,1),[(1,2,0),(3,2,F(1,2)),(2,1,1)],1),
      graph_case('pilot_nested',(1,2,1),[(1,4,0),(3,3,F(1,3)),(7,2,1)],1),
      graph_case('pressure_large_density_zero_variance',(1,1),[(1,100,0),(3,2,1),(2,1,F(1,2))],2),
      graph_case('pressure_tied_maximizers',(1,1,2),[(1,4,0),(2,4,1),(4,2,F(1,2))],2)]
    rng=random.Random(SEED)
    for j,N in enumerate((4,5,6,7,8,8)):
        p=[F(rng.randint(1,9),rng.randint(1,5)) for _ in range(N)];data=[]
        for i in range(N):data.append((1<<i,F(rng.randint(1,30),rng.randint(1,5)),F(rng.randint(0,4),4)))
        for _ in range(4):data.append((rng.randint(1,(1<<N)-1),F(rng.randint(1,30),rng.randint(1,5)),F(rng.randint(0,4),4)))
        graphs.append(graph_case('expanded_'+str(j),p,data,3))
    bridges=[bridge(n,T,v) for n in (1,16,256,4096) for T in (10,20,100) for v in (F(T,2),T,2*T,2*T+1)]
    count=dict(graphs=len(graphs),principal_blocks=sum(len(r['principal_blocks']) for r in graphs),whole_source_cuts=sum(len(r['all_source_cuts']) for r in graphs),
      residual_source_cuts=sum(len(b['residual_cuts']) for r in graphs for b in r['principal_blocks']),flow_arcs=sum(len(r['optimal_flow']['arcs'])+sum(len(b['block_flow']['arcs']) for b in r['principal_blocks']) for r in graphs),scalar_bridge_records=len(bridges))
    out=dict(schema='R88-public-neutral-principal-flow-v1',seed=SEED,publication='PUBLIC generic finite graph/conditional arithmetic; private physical recipes excluded',
      scope='No actual fully-qualified highload or principal I_T result; geometric prerequisites are absent in all public graphs.',counts=count,graphs=graphs,conditional_bridge_records=bridges)
    Path(__file__).with_name('hall_results.json').write_text(json.dumps(clean(out),indent=2,sort_keys=True)+'\n');print('PASS',count)
if __name__=='__main__':main()
