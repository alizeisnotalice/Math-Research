# 中心立方体极大算子第88轮：通量抵消、质量熵与逐主割核验

2026-10-12。一般非负 L1 输入的 n^(1/2+o(1)) 一致弱型上界仍未证明，保留一般基准 O(n log n)。第87轮已提交并确认推送 feda240864390ae031dcd11298092a37addd78eb。本轮没有用条件性回代、特殊来源或有限数值成功替代一般闭合。

八个子任务按既定分工完成：三位 Astra high 路线作者、Astra high 与 Sol high 独立审计、两位 Sol high 数值和证书作者、一位 Sol high 文献与技能核验作者。主代理补充逐主割的完整条件返回及 Gamma 核路线，整合并隔离重放。各重要命题先发给两审独立检查，再提供证明；审核结论仅及所列范围。

本报告保留详细证明、LaTeX 文本及必要公开复现材料。私人实际压力配方不公开，原始文献 PDF 不重复入库，不编译 PDF。公开有限模型明确标为 NONPHYSICAL；它们核验代数与证书，不能认证连续接收体积或任意维数命题。


## 第88轮主账与剩余量

令 mu=fdy，Q(x,L)=x+[-L/2,L/2]^n，L∈[1,2]，需求为实际 lambda dx。保持第82轮原锚点 A1<lambda/2、全窗口原 P1≤lambda/2、严格后见证、原最早硬接触 A_L*=lambda 和原中间下限 exp(-s_n)/2；不更换平滑核或下截断。每次实际删源并重选时重新检查全部门。正规紧致集仅要求 B 紧且原 L|B 连续，不附加光滑边界、横截或正裕量条件。

所有先前已付费用原样保留。设 H=1+n log2，theta=log^-2(n+2)，alpha=epsilon=1/[10log(n+2)]，c=1-alpha-epsilon，beta=c/2。

- B0=4+2log2 sqrt(7n/3)，Bext=2H/sqrt(n+2)。
- Tsoft=1+log2 min(2n,sqrt[n(theta^-1+4theta/3)])，粗平滑已付费 Tsoft/alpha。
- 原指定 h0=1/(16n²) 网格，a=n^-p、rho=n^-1/2，p>0固定，Fdom={eta_a≥rho}；Pdom=(5+3log(1/a))/rho。
- h*=1/(16n^(3/2))，E=exp(nh*)，B_h=1+E[1+(2n²+n)h*]。实际后验物理碰撞≥3/4或平均网格熵≤sqrt n的并集仅支付一次 Pphys=2[E+B_h+2(1+E)sqrt n]。
- 完整未付余集为 Fnew=(F\Fdom)∩{C_h*<3/4,Hbar_h*>sqrt n}，F为原中间事件中的原粗平滑低分支。

若 Dnew 支付整个 Fnew，则 C_n^square≤C_loc log(n+2)[B0+Bext+Tsoft/alpha+Pdom+Pphys+Dnew]。仅逐原 kappa 二进层证明时另付 O(log n) 层数；不能按背景比值直接倍增后漏付线性层数。本轮没有改变完整事件或减少这些费用。

### 连续主割与真正缺少的方差预算

对紧致 B⊂Fnew、连续原 L，保留最优来源列 b* 与主割 A_s,S_s。N(A_s)^ess=S_s mod mu，D_s=lambda|A_s|=∫S_s b* dmu，且旧硬前缀、接触及整个后验在限制来源后保持。严格后见证及原中间平滑下限不自动保持。原输入仍用于需要这些门的证明。

规范列 b_A(y)=∫A L^-n 1_Q dx≤H。I_T(A)=∫{b_A>T} Var(u|y)dmu 为规范联合律下不加权的条件方差，u=log max(1,2||x-y||∞)。它不对子集单调；不能换成可能奇异的优化耦合条件律。

本轮严格证明：若对每个原输入、每个正规紧致B及每个正主割，重新计算后均有 I_T(A_s)≤R_n mu(S_s)/n，其中 T=sqrt(24nR_n+96)，则每个主割比值≤2T。Lusin与内正则性无额外费用地给全部可测割，Borel Hall定理再给完整Fnew正耦合。这一假设仍开放，R_n=n^{o(1)}并未建立。

实际规范接收往返核P给 I_T≤D/T[omega²+(log2)²epsilon_cross+4/n²]。这里omega为真实尺度块内logL振幅，epsilon_cross为同一来源条件两次抽样的跨块概率。需支付的右侧保留D/T，谱隙下界不是所需能量上界。没有从细分源块、优化列常数或局部LSI推出这项缺失估计。

### 连续通量与质量熵的已证部分

一般L1输入满足 ∂L F+div J=0，∫|J|²/F≤nW/12。任意可测停止图的有符号通量等于接触需求减锚点；尖锐截断的正Dirichlet能量在正侧边界迹条件下至少按1/epsilon发散。精确立方体分部积分给有限的 face-minus-interior 共同来源恒等式，两项各≤nlog2 M，恢复 D≤HM。新的根号阶有符号抵消尚未证明。

实际坏来源递推另有质量势 Psi(D,W)=D[1+log(HW/D)]，0≤Psi≤HW。其下降恰分为二元相对熵、删除需求势和严格子代损失三项。乘回阈值补偿权重后，临界质量比例下所有一次齐次质量势均可能保持不变；不加权下降不能支付重复费用。真实高负载步具有物理质量缩减、正二元熵、burden下降三分，但中间分支及跨分支循环未付。终端H t_m W_m继续保留。

最优耦合的来源往返核保持每个负载层，非恒定负载导致零谱隙；这不是规范核的结论。分割局部亏损的组合与精确跨层费用已核对。任意给定正需求紧致余集允许某些来源分割在随深度缩小的接收子集上积累线性深度费用；此定理不保存高Hall比值，也不排除精心选择的低费用树。

### Gamma 替代路线与检验范围

指数无穷范数核 Psi_n,t 的 Gamma(n+1,1) 正混合给 M_Psi≤M_cube≤c_n M_Psi，c_n=n!e^n/n^n≤6sqrt n。其三维 Fourier 值恰有 -1/780，不能直接作为非负自伴生成元的正时间半群核。直接平滑尺度变差支付2n/c_n，乘回后总费c_n+2nlog2仍为线性阶，未改善基准。公开460项有理核记录已执行；初始零频程序使用精确可表示浮点1.0已被独审指出并改为Fraction，全量重跑。

公开新有限Hall/主割证书和独立guard给出精确复现范围。私人真实来源的训练和独立检验、连续标量门、固定源径向重要性积分及共同阈值测试均单独记录；没有认证高负载主割或完整Fnew。零命中不意味着空集、零方差或一般上界。共同阈值、接收体积、首次根和粗平滑门仍各有认证责任。匿名结果及实际隔离重放写入最终清单。

本轮使用更新技能的精确适用域并记录实际原文阅读范围。64个入口的哈希快照不等于全文读完或全部定理认证。一般目标仍开放；下一轮应直接攻实际共同来源抵消或低费用选择，以及稀尾真实测度探路，避免再次只重写条件返回。


## 1. Status and quantifiers

The general root-order Hall estimate remains **OPEN**. This note proves a common-source continuity equation, a dimension-explicit action bound, and an exact stopping identity valid for merely measurable receiver sets and selectors. It also proves that the natural sharp-cut Dirichlet energy genuinely diverges under a positive side-boundary trace. Thus this proposed route does not establish the fresh principal-cut radial estimate in the contract. The obstruction concerns this energy argument, not the cube maximal theorem.

Fix $n\ge2$, $f\ge0$ in $L^1(\mathbb R^n)$, $d\mu=f\,dy$, and $W=\mu(\mathbb R^n)$. Cube side lengths are full side lengths. Write
\[
 F_L(x)=L^{-n}\int_{Q(x,L)}f(y)\,dy,\qquad
 J_L(x)=L^{-n}\int_{Q(x,L)}\frac{x-y}{L}f(y)\,dy.                 \tag{1}
\]
These definitions make sense for every $L>0$. At $F_L=0$, $J_L=0$, and the quotient $|J_L|^2/F_L$ below is defined to be zero.

A principal cut is always taken from the original input and original continuous selector on a compact $B\subset F_{\rm new}$. Let $A=A_s\subset B$, $S=S_s$, $M=\mu(S)$, $\tau=L_*|_A$, and $D=\lambda|A|$. The retained principal theorem gives $N(A)=S$ modulo $\mu$. With $g=f1_S$, every old hard prefix and contact is preserved for almost every $x\in A$:
\[
 A_Lg(x)=A_Lf(x)\quad(1\le L\le\tau(x)),\quad
 A_{\tau(x)}g(x)=\lambda,\quad A_1g(x)<\lambda/2.              \tag{2}
\]
There is no claim that $g$ inherits the strict later witness or middle lower smooth gate. All identities using $g$ below require only (2). No normalized conditional variance is transferred from $B$ to $A$.

## 2. A common-source continuity equation and exact action cost

For every input in §1,
\[
 \partial_LF_L+\operatorname{div}_xJ_L=0                     \tag{3}
\]
in distributions on $\mathbb R^n\times(0,\infty)$. Moreover,
\[
 |(J_L)_i|\le F_L/2,\qquad
 \int_{\mathbb R^n}\frac{|J_L|_2^2}{F_L}\,dx\le\frac n{12}W. \tag{4}
\]
In particular, for $0<a<b<\infty$, the spacetime action is at most $nW(b-a)/12$.

**Proof.** With $C=[-1/2,1/2]^n$, direct change of variables gives
\[
 F_L(x)=\int_C f(x-Lz)\,dz,\qquad
 J_L(x)=\int_C zf(x-Lz)\,dz.
\]
For smooth $f$, differentiation proves (3). For arbitrary $L^1$ input, approximate in $L^1$ by nonnegative smooth inputs. On any compact side interval $[a,b]\subset(0,\infty)$, the differences of the resulting $F$'s and individual $J$'s are bounded uniformly in $x,L$ by $a^{-n}\|f_k-f\|_1$ and $a^{-n}\|f_k-f\|_1/2$, respectively. This proves the distributional passage. It also proves joint continuity and uniform continuity on every compact spacetime set. A compactly supported smooth approximation in fact gives uniform continuity for all $x$ on a fixed compact side interval.

Pointwise weighted Cauchy–Schwarz gives
\[
 \frac{|J_L(x)|^2}{F_L(x)}\le\int_C |z|^2f(x-Lz)\,dz.
\]
Integrating and using $\int_C|z|^2dz=n/12$ proves (4). The independent uniform cube variable in this calculation is an exact representation of the averaging kernel. No independence between coordinates of the physical source is assumed. The same proof gives the useful matrix version
\[
 \int\frac{J_L^T R J_L}{F_L}\,dx\le \frac{\operatorname{tr}R}{12}W
 \quad(R\succeq0\text{ fixed}).                             \tag{5}
\]

For a smooth compactly supported spacetime test $\psi$, (3) gives the exact weak identity
\[
 \int\!\int(F_L\partial_L\psi+J_L\cdot\nabla_x\psi)\,dx\,dL=0.
                                                                    \tag{6}
\]
For tests supported in sides $[a,b]$,
\[
 \left|\int\!\int J_L\cdot\nabla_x\psi\right|
 \le\sqrt{\frac{nW(b-a)}{12}}
       \left(\int\!\int F_L|\nabla_x\psi|^2\right)^{1/2}.    \tag{7}
\]
The rightmost weighted spatial energy is essential; the coefficient $\sqrt n$ by itself is not a weak maximal estimate.

## 3. Exact stopping at an arbitrary measurable graph

Let $A$ be bounded measurable and $\tau:A\to[1,2]$ measurable. No boundary or selector regularity is imposed. Put
\[
 \chi(x,L)=1_A(x)1_{\{1<L<\tau(x)\}}.
\]
Its time derivative is the finite signed measure
\[
 \partial_L\chi=\int_A\big(\delta_{(x,1)}-\delta_{(x,\tau(x))}\big)\,dx.
                                                                    \tag{8}
\]
For $\tau=1$ the two atoms cancel. Choose a nonnegative, even, smooth mollifier of integral one supported in the Euclidean unit ball of spacetime. Let $\chi_\varepsilon=\chi*\zeta_\varepsilon$, $0<\varepsilon<1/4$. Apply (6) to this smooth compactly supported function, using the actual cube fields also for $L\in(1/2,5/2)$. Then
\[
 \mathcal F_\varepsilon:=\int\!\int J_L\cdot\nabla_x\chi_\varepsilon
 =-\int\!\int F_L\partial_L\chi_\varepsilon
 \longrightarrow\int_A(F_{\tau(x)}(x)-F_1(x))\,dx.            \tag{9}
\]
The limit is a **signed flux limit**. It does not claim finite total spatial variation or a classical boundary trace for $A$.

For a uniform modulus of continuity $\omega_F(\varepsilon)$ over the needed spacetime neighborhood, convolution of (8) gives the quantitative estimate
\[
 \left|\mathcal F_\varepsilon-\int_A(F_\tau-F_1)\,dx\right|
 \le2|A|\omega_F(\varepsilon).                              \tag{10}
\]
Indeed each endpoint value changes by at most the modulus; the total variation of (8) is at most $2|A|$. This proof is valid even for a nowhere differentiable continuous selector. It does not approximate the selector by uniformly controlled Lipschitz selectors.

Define
\[
 \mathcal E_\varepsilon(A,\tau;f)
 =\int\!\int F_L(x)|\nabla_x\chi_\varepsilon(x,L)|^2\,dx\,dL.

a_\varepsilon=\int_A(F_\tau-F_1)\,dx-2|A|\omega_F(\varepsilon).
\]
Since the test is supported in $L\in[1-\varepsilon,2+\varepsilon]$, (7) gives the unconditional, finite-thickness bound
\[
 (a_\varepsilon)_+
 \le\sqrt{\frac{nW(1+2\varepsilon)}{12}
                 \mathcal E_\varepsilon(A,\tau;f)}.          \tag{11}
\]

For a principal cut, apply this theorem to $g=f1_S$, with its own modulus and fields. Contact and anchor yield
\[
 \left(D/2-2|A|\omega_{F^S}(\varepsilon)\right)_+
 \le\sqrt{\frac{nM(1+2\varepsilon)}{12}
                 \mathcal E_\varepsilon(A,\tau;g)}.          \tag{12}
\]
Thus, if $M>0$,
\[
 \liminf_{\varepsilon\downarrow0}\frac{\mathcal E_\varepsilon}{M}
 \ge\frac{3}{n}\left(\frac D M\right)^2.                    \tag{13}
\]
If $M=0$, contact implies $|A|=0$. Equation (13) is only a necessary energy lower bound and can be vacuous because its left side can be infinite. It is not the missing upper bound for $I_T(A)$.

## 4. The classical stopped identity and why its terms cannot be discarded

For comparison only, assume additionally that $A$ is a bounded Lipschitz domain and $\tau$ extends to a Lipschitz function on its closure. Then
\[
 \int_A(F_\tau-F_1)\,dx
 =\int_A J_{\tau(x)}(x)\cdot\nabla\tau(x)\,dx
  -\int_{\partial A}\int_1^{\tau(x)}J_L(x)\cdot\nu_A(x)\,dL\,d\mathcal H^{n-1}(x).
                                                                    \tag{14}
\]
For smooth $f$, let $K(x)=\int_1^{\tau(x)}J_L(x)dL$. The chain rule yields
$\operatorname{div}K=F_1-F_\tau+J_\tau\cdot\nabla\tau$; the divergence theorem proves (14). For $L^1$ input, the uniform approximations used in §2 allow passage in every term because the boundary area is finite and $\nabla\tau$ is integrable. No trace of $f$ itself is taken.

Principal source closure localizes the source mass in (14) to $M$. It does not remove the receiver side boundary, and it does not bound $\nabla\tau$. The contract's compact/continuous regularity does not imply either hypothesis of this comparison formula. The measurable identity (9), rather than (14), is the valid general principal-cut statement.

## 5. A proved divergence mechanism for the proposed energy

The obstacle in (12) is stronger than an unverified uniform estimate. Suppose a stopped domain has a compact $C^2$ side-boundary patch $\Gamma$ inside a larger smooth chart, with an injective normal tube whose Jacobian is at least $1/2$. Suppose for a fixed interval $[a,b]\subset(1,2)$, the stopped indicator equals $1_A(x)$ throughout a neighborhood of this tube and time interval; this means the entire interval lies strictly below the local stopping graph. Suppose also $F_L(x)\ge c>0$ on that neighborhood. Then for all sufficiently small $\varepsilon>0$,
\[
 \mathcal E_\varepsilon(A,\tau;f)
 \ge \frac{c\,\mathcal H^{n-1}(\Gamma)(b-a)}{8\varepsilon}.
                                                                    \tag{15}
\]
One may shrink $[a,b]$ initially to ensure that the convolution neighborhood remains in the assumed region.

**Proof.** Let $\nu(z)$ be the outward unit normal. At $z-2\varepsilon\nu(z)$ and $z+2\varepsilon\nu(z)$, the mollified indicator equals one and zero, respectively. The signed distance is $2\varepsilon$ in magnitude, while the spatial support radius of the mollifier is at most $\varepsilon$; the time support is harmless by the neighborhood assumption. For each $z\in\Gamma$ and $L\in[a,b]$, the fundamental theorem and Cauchy–Schwarz give
\[
 \int_{-2\varepsilon}^{2\varepsilon}
 |\partial_s\chi_\varepsilon(z+s\nu(z),L)|^2ds\ge\frac1{4\varepsilon}.
\]
Since $|\partial_s\chi_\varepsilon|\le|\nabla_x\chi_\varepsilon|$, multiply by $F\ge c$, use the tubular Jacobian bound, and integrate $z,L$. This proves (15).

This is a general local positive-trace fact about the proposed proof mechanism. It makes no claim that every principal cut has such a patch, and constructs no new gated input. It proves that adding smooth boundary and smooth selector hypotheses would still not justify taking a free zero-thickness Cauchy limit. The finite signed limit in (9) can coexist with divergent positive energy in (15); the latter has discarded cancellations.

## 6. A finite face-minus-interior replacement

The divergent Dirichlet energy can be avoided at baseline cost by retaining the exact cube-variable cancellation. This is valid for every bounded measurable $A$ and measurable $\tau$, using the same stopped indicator as §3. For a source $g\in L^1_+$ of mass $M$, define
\[
 \mathcal B=\int_1^2\frac{dL}{L}\int g(y)\,dy\,
  \frac12\sum_{i=1}^n\sum_{\sigma\in\{-1,1\}}
  \int_{[-1/2,1/2]^{n-1}}
  \chi(y+Lz,L)\big|_{z_i=\sigma/2}\,dz_{-i},
\]
\[
 \mathcal V=n\int_1^2\frac{dL}{L}\int g(y)\,dy\int_C\chi(y+Lz,L)\,dz.

a=\int_A F^g_1(x)\,dx.
\]
On actual old contact rows,
\[
 D-a=\mathcal B-\mathcal V,\qquad
 0\le\mathcal B,\mathcal V\le n\log2\,M.                  \tag{16}
\]
Equivalently, let $p_y(L)$ be the uniform-cube average of $\chi(y+Lz,L)$ and let $q_y(L)$ be its average over a uniformly chosen one of the $2n$ faces, with uniform measure on that face. Then
\[
 \mathcal B-\mathcal V
 =n\int g(y)\,dy\int_1^2[q_y(L)-p_y(L)]\,\frac{dL}{L}.
\]
The proposed gain is a signed common-source face-versus-interior discrepancy gain; $p_y,q_y\in[0,1]$ alone supplies no such gain.

Both terms use the **same source, same receiver set and same stopping graph**. No row, source packet, or interior fresh mass is removed.

**Proof.** For the smooth test $\chi_\varepsilon$, substitute (1) into its spatial flux and integrate by parts in $z\in C$:
\[
 \int_C z\cdot\nabla_x\chi_\varepsilon(y+Lz,L)\,dz
 =\frac1L\left[
 \frac12\sum_{i,\sigma}\int_{z_i=\sigma/2}\chi_\varepsilon(y+Lz,L)\,dz_{-i}
 -n\int_C\chi_\varepsilon(y+Lz,L)\,dz\right].              \tag{17}
\]
On each face $z\cdot\nu_C=1/2$, explaining the factor. The smooth-test side integral initially runs over $[1-\varepsilon,2+\varepsilon]$. Contributions outside $[1,2]$ tend to zero because the face and volume weights have total mass at most $nM\,dL/L$.

For the remaining limit, source integration gives the face weight a genuine Lebesgue density in $x,L$: each face term has density
\[
 (x,L)\longmapsto\int_{[-1/2,1/2]^{n-1}}
 g(x-Lz)\big|_{z_i=\sigma/2}\,dz_{-i}.
\]
This is a measurable $L^1(dx\,dL)$ function on the compact side interval, with spatial integral $M$ at each $L$. This is an almost-everywhere density statement, not an evaluation of an arbitrary representative of $g$ on a fixed null hyperplane. The volume term likewise has density $F_L^g$. Since $0\le\chi_\varepsilon\le1$ and $\chi_\varepsilon\to\chi$ Lebesgue almost everywhere, dominated convergence applies to these finite absolutely continuous measures. Equation (9) then proves the identity in (16). The two bounds follow by replacing $\chi$ by one; the $2n$ unit-area faces carry total weight $n$.

Since $a\le M$ and $\mathcal V\ge0$, this yields exactly the known window baseline
\[
 D\le(1+n\log2)M.                                      \tag{18}
\]
It introduces no background-layer multiplier. The assertion holds for each original principal cut after restricting the source to its closure, because it uses only the preserved hard prefixes and contact. It is not a new improvement on the baseline. The identity itself needs no earliest-contact assumption. The additional true prefix inequalities $F_L^g(x)\le\lambda$ for $1\le L<\tau(x)$ remain available, but no multirow cancellation gain has been derived from them.

Equation (16) is the finite replacement for the failed zero-thickness energy route. A root-order discount would require a genuinely better bound on the signed face-minus-interior occupation, using additional multirow geometry or the original gates. Bounding its two terms separately loses precisely the possible cancellation. Nothing here proves that near-optimal source columns impose such a cancellation. This is an exact remaining geometric expense, with finite terms, rather than an implicitly infinite Sobolev budget.

## 7. Precise finite-thickness alternative and remaining gap

Besides the finite cancellation identity (16), one may keep finite thickness and the demand error in (10). For example, to extract a useful estimate from (12), one would need a thickness with
\[
 2\omega_{F^S}(\varepsilon)\le\lambda/4
 \quad\text{and a proved bound on }\mathcal E_\varepsilon/M.
                                                                    \tag{19}
\]
The first condition makes the retained demand at least $D/4$, and then (12) gives
\[
 D/M\le\sqrt{\tfrac43 n(1+2\varepsilon)\mathcal E_\varepsilon/M}.
                                                                    \tag{20}
\]
Neither a source-uniform admissible thickness nor the required energy upper bound has been proved. Optimizing over smooth tests instead of a mollified characteristic function is permissible only if their temporal pairing retains the claimed fraction of demand; this constraint is not free. Equations (19)–(20) are a transparent list of expenses, not a new sufficient hypothesis being presented as closure.

In particular, no estimate
$I_T(A_s)\le R_n\mu(S_s)/n$, $R_n=n^{o(1)}$, is established here. There is no deduction from optimized column flatness to canonical radial concentration, no receiver-subset variance monotonicity, no new lower construction, and no gain from the original layer gates in this route. The original full-window, middle, coarse, physical-entropy and collision gates remain available on the original input, but the continuity argument has not converted them into a bound for its transverse flux.

The smallest next quantitative claim on the finite objects is the following **unproved research target**, quantified for every original input and every positive-mass principal cut of every regular compact $B\subset F_{\rm new}$:
\[
 \mathcal B_s-\mathcal V_s\le C_n\mu(S_s)+\theta\lambda|A_s|,
 \qquad 0\le\theta<1\text{ uniform},\qquad
 C_n=\sqrt n\,n^{o(1)}.                                  \tag{21}
\]
The version with $\theta=0$ is stronger than the absorption version. By (16) and $a_s\le\mu(S_s)$, (21) would give
$\lambda|A_s|\le(1+C_n)\mu(S_s)/(1-\theta)$, and the retained principal theorem would give the desired capacity on the whole residual. This implication is stated only to fix the next experiment and proof target; it is not a quantitative advance established in this round. The fresh radial target is another possible route and is not needed if (21) can be proved directly.

Already excluded are a uniformly bounded zero-thickness energy from smoothness alone (15), a two-row-prefix-only overlap discount (retained R86), and concentration inferred solely from small labels of an arbitrarily refined partition. No counterexample here excludes (21), nor is a separate root-order bound on $\mathcal B_s$ asserted false without a fully qualified example. The next step must use actual shared-source face/interior correlation or the original gates, and keep both finite occupation terms until a proved cancellation is available.

## 8. Verification and scope

The statements were sent to both independent auditors before proof drafting. The continuity/action, stopped signs and $L^1$ trace passage received blind checks; the measurable-subgraph statement was separately sent before proof. The boundary-divergence and finite face-minus-interior statements were also sent separately before proof. Both independent auditors subsequently read the complete MD and TeX proofs and returned PASS, including the finite face-minus-interior addendum, its $L^1$ absolute-continuity passage, and the explicitly unproved absorption target. The independent guard reports 224 coverage checks: 216 finite-thickness/action/divergence constant checks and 8 dimension/reference-polynomial cube-divergence checks. Its combined run passed 10,082 checks in 7.938750 seconds; these are generic exact/algebra checks, not actual gated input certificates.

Numerical coordination preserves the assigned high-load search: no low-load two-row or previously removed grid artifact is used to test the principal target. The three pressure stages for this analytic route are (i) the exact uniform-cube action and stopped-sign check, (ii) the positive side-boundary divergence mechanism, and (iii) arbitrary $L^1$, arbitrary measurable graphs, and original source-closed principal cuts with dimensions left explicit. Generic algebra checks are not actual gated input certificates. The numerical owner reports no fully qualified high-capacity principal cut and no certified $I_T$ estimate in this round; partial gate and sampled-point calculations are not used in any proof here.

The updated E03 and M03 skill, method and cube-interface files were read. E03 does not supply tree flow conservation for these nonnested receiver cubes. M03 supplies no general rigidity theorem turning a high principal level into canonical radial control. No external PDE or stability theorem is imported.

**Round conclusion:** exact general signed flux accounting is proved, and the naive sharp-cut energy route is rigorously obstructed. The finite face-minus-interior identity recovers the baseline without divergent energy. A new general Hall discount was not obtained. The unpaid signed occupation cancellation or finite-thickness spatial energy, and the contract's fresh principal-cut $I_T$ estimate, remain open.

## 1. Current-input scope and finite laws

Fix n≥2 and H=1+n log 2. For each current positive L1 input μ_i=f_i dy, W_i=μ_i(R^n), threshold λ_i, impose all original R82 gates: anchor, the whole-window original smooth gate, strict later witness, earliest hard contact L_i∈[1,2], original middle floor, and any retained layer. Delete the paid coarse and fixed-grid dominant-packet branches. Then delete the R87 physical union C_{h*}≥3/4 OR Hbar_{h*}≤sqrt n, using h*=1/(16n^{3/2}). The whole remainder is

F_i^new=F_i^diff∩{C_{h*}<3/4, Hbar_{h*}>sqrt n}.

Each branch uses the unchanged current selector. Every restriction of source and threshold recomputes all gates, fixed-grid masses, captured physical collision and averaged grid entropy. Current receivers B_i⊂F_i^new are nested; whole F_i^new need not be nested. No normalized radial-variance subset monotonicity is used.

Let the actual positive captured stopping kernel satisfy
0≤k_i≤L_i^{-n}1_{Q_i}, c_iλ_i<d_i=∫k_i dμ_i≤(1−ε_i)λ_i,
where c_i=1−α_i−ε_i>0. Set q_i=∫_{B_i}k_i dx, S_i={q_i>K}, μ_{i+1}=μ_i|S_i, λ_{i+1}=β_iλ_i with β_i=δ_i c_i∈(0,1). Only rows whose stopped-source share r_{S_i}>δ_i continue. Their strict witness A_{L_i}f_{i+1}>λ_{i+1}, together with the new anchor, forces L_{i+1}<L_i and nested actual cubes on B_{i+1}⊂B_i.

Write b_i(y)=∫_{B_i}L_i^{-n}1_{Q_i}(y)dx, D_i=λ_i|B_i|=∫b_i dμ_i, R_i=D_i/W_i. The full-window envelope gives 0≤q_i≤b_i≤H. A zero-demand child terminates the current receiver chain. For positive demand define the actual hard-capture joint law

P_i(dx,dy)=D_i^{-1}1_{B_i}(x)L_i(x)^{-n}1_{Q_i(x)}(y)dx μ_i(dy),

on the common standard Borel space B_0×R^n, extending by zero. Its source marginal is ν_i=b_i μ_i/D_i and the physical source reference is π_i=μ_i/W_i. These are the only probability laws used in the entropy statements; no source-coordinate independence is imposed.

At a positive-child step abbreviate

ρ_i=W_{i+1}/W_i=π_i(S_i), p_i=ν_i(S_i), C_i=p_iD_i,
s_i=|B_{i+1}|/|B_i|, D_{i+1}=β_i s_iD_i,
t_i=λ_0/λ_i, v_i=t_iW_i, d_i^0=t_iD_i=λ_0|B_i|.

Here d_i^0 is compensated demand, distinct from the stopping gain d_i(x). Then

C_i>D_{i+1}, C_i≤HW_{i+1}, D_i−C_i≤H(W_i−W_{i+1}),
R_{i+1}=(β_i s_i/ρ_i)R_i, v_{i+1}/v_i=ρ_i/β_i.                    (1)

The first inequality is the integrated strict old bad-row witness, not source nesting alone. The other two follow by integrating b_i≤H on S_i and its complement. All statements below retain these actual-input facts.

## 2. A sharper mass-entropy budget with its complete decrement

For 0≤D≤HW define

Ψ(D,W)=D[1+log(HW/D)], Ψ(0,W)=0.

If W=0 only D=0 is admissible. Then

0≤Ψ(D,W)≤HW,  ∂_DΨ=log(HW/D)≥0.                                   (2)

The function is homogeneous of degree one. This is an improved uniform source-mass bound relative to the R87 geometric potential's bound; it is not claimed to dominate that potential pointwise in either direction.

Let d_bin denote binary KL, using 0 log 0=0 and the usual matching zero-mass conventions. The finite two-cell entropy identity gives the EXACT decomposition

Ψ(D_i,W_i)−Ψ(D_{i+1},W_{i+1})
 =D_i d_bin(p_i||ρ_i)
  +Ψ(D_i−C_i,W_i−W_{i+1})
  +[Ψ(C_i,W_{i+1})−Ψ(D_{i+1},W_{i+1})].                            (3)

Every term on the right is nonnegative. Indeed the first term is KL; the complement is admissible by (1); and the final difference is nonnegative by (1) and monotonicity (2). For a positive child, C_i>D_{i+1}, so the last difference is strictly positive even if C_i=HW_{i+1}: the derivative is positive throughout the nonempty interval below its upper endpoint. If S_i has zero source mass set p_i=ρ_i=0. If a child is empty, retain (3) with D_{i+1}=0 and its actual W_{i+1}; the final term is Ψ(C_i,W_{i+1}). If S_i is the whole source, the complement is zero. Thus no infinite entropy subtraction is used.

For completeness, substitute C=pD and W'=ρW into the sum of the two source-block Ψ terms. Their sum is Ψ(D,W)−D[p log(p/ρ)+(1−p)log((1−p)/(1−ρ))], which proves (3) after adding and subtracting Ψ(C,W').

Let Q_i^bin, Q_i^shell, Q_i^res denote the three terms in (3). For every finite actual chain,

Ψ(D_m,W_m)+Σ_{i<m}(Q_i^bin+Q_i^shell+Q_i^res)
 =Ψ(D_0,W_0)≤HW_0.                                                 (4)

This removes the nD_0 geometric allowance from this unweighted entropy accounting and gives a nonnegative, fully paid terminal. It is not a root-order estimate: H is linear in n, and original-threshold compensation remains necessary.

## 3. The compensated drift and a necessary fee-progress dichotomy

Set X_i=t_iΨ(D_i,W_i)=d_i^0 a_i, a_i=1+log(H/R_i)≥1. Multiplying (3) by t_i yields the exact finite ledger

X_m+Σ_{i<m}t_i(Q_i^bin+Q_i^shell+Q_i^res)
 =X_0+Σ_{i<m}(t_{i+1}−t_i)Ψ(D_{i+1},W_{i+1}).                       (5)

No terminal or positive compensation term is dropped. More usefully, direct homogeneity and (1) give the exact drift

(X_i−X_{i+1})/d_i^0
 =(1−s_i)[1+log(H/R_i)]+s_i log(β_i s_i/ρ_i).                        (6)

This identifies a concrete progress requirement, without treating a new hypothesis as a proved geometric estimate. Suppose a proof proposes to pay a positive fee F_i v_i from this potential's one-step decrease, where F_i>0 is any declared coefficient, including repeated branch and source-shell fees. Necessarily at least one of

1−s_i≥ F_i/[2R_i(1+log(H/R_i))],
ρ_i≤β_i exp[−F_i/(2R_i)]                                           (7)

holds. To prove this, use s_i log s_i≤0 and
s_i log(β_i/ρ_i)≤max(0,log(β_i/ρ_i)) in (6). If both conclusions fail, the normalized drift is strictly less than F_i/R_i, contradicting X_i−X_{i+1}≥F_i v_i. The result is a necessary condition for THIS potential to finance that fee; it does not assert that all actual steps satisfy it.

There is a robust quantitative obstruction to such financing. If 0≤ε<1, s_i≥1−ε, and ρ_i/β_i∈[1−ε,1+ε], then

X_i−X_{i+1}≤d_i^0[ε a_i−log(1−ε)].                                 (8)

For ε≤1/2 this is at most ε(a_i+2)d_i^0. Hence a positive payment F_i v_i requires ε≥F_i/[R_i(a_i+2)] in that range. These are exact restrictions on the actual fractions, not assertions that a near-critical actual chain exists.

At the critical values ρ_i=β_i and s_i=1, R_{i+1}=R_i and X_{i+1}=X_i EXACTLY. More generally every degree-one potential P(D,W) is compensated-stationary there: t_{i+1}P(β_iD_i,β_iW_i)=t_iP(D_i,W_i). Consequently no such mass-only potential can pay a positive extra fee at a critical step. The full right side of (3) is then used exactly to offset threshold compensation. Since Q_i^res>0, binary KL alone is STRICTLY smaller than the compensation; it cannot absorb it at any feasible positive critical step. This is stronger than merely observing that a particular entropy upper bound is too large.

An auxiliary numerical necessary bound illustrates the scale. At a critical step p_i>β_i, so d_bin(p_i||β_i)≤log(1/β_i). Binary-only absorption would require

R_i≥H exp[1−log(1/β_i)/(1−β_i)].                                    (9)

But (3) shows that even satisfying this necessary numerical condition would not suffice. In the retained fixed-β range the right side is a fixed positive fraction of H, far above root-order load as n grows.

## 4. An unconditional actual-input progress trichotomy

This subsection uses the retained fixed c=1−2/[10log(n+2)], δ=1/2 and β=c/2. Let 0<K<H and consider a positive-child step with R_i≥8K/c. If this threshold exceeds H the statement is vacuous; it is not a small-dimensional certificate.

Because ∫q_i dμ_i>cD_i, q_i≤b_i on S_i, and q_i≤K off S_i,

p_i>c−(K/R_i)(1−ρ_i)≥7c/8.                                        (10)

Exactly one of the following three alternatives occurs:

- **Physical source contraction:** ρ_i≤c/4. Then v_{i+1}≤v_i/2.
- **Positive binary information:** c/4<ρ_i≤3c/4. Then d_bin(p_i||ρ_i)≥c²/32.
- **Load-ratio progress:** ρ_i>3c/4. Then R_{i+1}<2R_i/3.

The second bound follows from d_bin(p||ρ)≥2(p−ρ)² and p−ρ>c/8. A self-contained proof of that scalar inequality fixes ρ, notes the first derivative vanishes at p=ρ, and integrates the second derivative 1/[p(1−p)]≥4. The third bound uses s_i≤1 in (1). No independence, mass-tail premise, or small-share inference is used.

This is a genuine necessary trichotomy for every actual high-burden step. Its second branch is deliberately not called a paid threshold step: critical ρ=β lies inside it, and §3 proves that its entropy gain can be fully consumed by compensation. Nor does load-ratio decrease alone control the weighted source occupation; ρ>β actually increases v_i. Cycles or long near-critical sequences therefore cannot be summed for free. New geometry must control their occurrence or supply another paid receiver/source reduction.

## 5. All weak fees and the terminal are still present

At finite depth the retained original receiver accounting is

λ_0|E_init|≤Σ_{i<m}t_i[A_iW_i+G_i^fee(W_i−W_{i+1})]+Ht_mW_m,
G_i^fee=K/[c_i(1−δ_i)].                                             (11)

The one-step fee tested in (7) can, for example, be the actual coefficient F_i=A_i+G_i^fee(1−ρ_i). It must not be replaced by the binary term or deleted merely because (4) holds.

For the retained choices A_i includes B_base+B_ext+T_soft/α+P_packet+P_phys, with
B_base=4+2log2 sqrt(7n/3), B_ext=2H/sqrt(n+2), α=1/[10log(n+2)],
P_packet=(5+3log(1/a))/ρ_packet, a=n^{-p}, ρ_packet=n^{-1/2},
P_phys=2[E_*+B_*+2(1+E_*)sqrt n], E_*=exp(nh*), B_*=1+E_*[1+(2n²+n)h*].
The physical union is charged once. Any further R83 deletion, layerwise O(log n) summation, or final all-scale logarithm remains separately charged. These constants are recomputed or reapplied to each current source as required; source masses may be charged repeatedly with t_i.

The terminal in (11) is H v_m, whereas the potential terminal in (5) is only X_m≤Hv_m. Paying or bounding X_m does NOT upper-bound H v_m. The direction is essential. A finite-depth or infinite-depth closure needs an independent upper budget for that terminal as well as the repeated fees. No such root-order budget is established here.

The next corrected route is now specific: an actual geometric argument must exclude enough near-critical high-burden steps, quantitatively force one of the fee-scale conditions (7), or directly pay their accumulated fees and H v_m. The unconditional trichotomy (10) narrows the missing mechanism: its binary branch needs an additional common-source/selector statement, not another entropy chain-rule rewrite. Whole-event radial forcing remains on freshly recomputed F_i^new; nothing here substitutes a current B_i variance for it.

## 6. Qualified relaxation pressure: what the entropy data cannot decide

The following is a NONPHYSICAL common-law model, not a Euclidean cube input and not an example satisfying the original smooth, coarse or F_i^new gates. It shows that the common-law/contact/column/threshold algebra retained in §§1–4 does not, by itself, force useful weighted progress.

Fix a finite horizon, β=cδ, c<ζ≤1−ε_stop, p>δ, a=pR/β, b=(1−p)R/(1−β), with
0<b<a≤H and ζb<K<ζa. Choose strictly decreasing L_i∈(1,2) and M≥aL_0^n. Receivers form a circle of length M, all retained. Source coordinates are (u,z)∈[0,1]×the same circle with common measure du dz/M. Let Z_i=[0,β^i]×circle and use μ_i=μ_0|Z_i. Set b_i=a on Z_{i+1}, b_i=b on Z_i\Z_{i+1}, and b_i=0 outside Z_i. Define an ARTIFICIAL capture relation by

(x−z mod M)<L_i^n b_i(u),

and its hard kernel by L_i^{-n} times the indicator. Its proportional stopping kernel is ζ times that kernel. The circle length prevents saturation. Source integration gives each row contact λ_i=Rβ^i/M, while receiver integration gives exactly column b_i. Therefore D_i=Rβ^i, W_i=β^i, q_i=ζb_i, and the actual common superlevel {q_i>K} is precisely Z_{i+1}. Every row has source share p>δ, old witness pλ_i>βλ_i, and stopping gain ζλ_i>cλ_i. Child capture edges are nested because on their source support the old column is a, the child column is at most a, and L_i decreases. Thus ρ_i=β and s_i=1 for arbitrarily prescribed finite horizons, with strictly positive binary KL but compensated mass potential constant.

There are no Euclidean distances behind this artificial relation, no certified earliest cube selector, and no original smooth or physical-dispersion gates. The proportional kernel is not asserted to arise from the actual captured-noise stop. The model therefore does not refute a general cube estimate, nor prove existence of an actual critical chain. It proves the precise algebraic limitation: additional actual geometry is indispensable to convert the entropy trichotomy into a paid threshold recursion.

The general $\sqrt n\,n^{o(1)}$ weak bound remains **UNPROVED**. The optimized-allocation spectral route has an exact structural obstruction: every function of the optimized source load is invariant under its source--receiver--source Markov chain. Splitting that chain along principal loads has zero boundary but preserves the unknown Hall ratios. A different, explicitly conditional route uses the original canonical chain and pays the demand lost in source partitioning. Neither a spectral gap nor the required small local deficiencies is established on the whole remaining event.

## 1. Same-source laws and spectral conventions

Let $B$ be a compact regular subset of the whole R88 event $F_{\rm new}$, with original continuous selector $L:B\to[1,2]$, original $\mu=fdy$, and $\nu=\lambda1_Bdx$. Assume $D=\nu(B)>0$ and write $N=\bigcup_{x\in B}Q_x$, $Q_x=Q(x,L(x))$. All original gates concern this same $f$ and selector. Sources outside $N$ are irrelevant to this allocation problem. The actual captured posterior is
\[
 K_x(dy)=\frac{1_{Q_x}(y)\,d\mu(y)}{\lambda L(x)^n}.
\]
The canonical plan is $\pi_0(dx,dy)=\nu(dx)K_x(dy)$, with source marginal $b_0\mu$ and $0\le b_0\le H=1+n\log2$. Its normalized joint law is $\Pi_0=\pi_0/D$ and source stationary probability is $\sigma_0=b_0\mu/D$.

Let $\pi_*$ be the R87 quadratic minimizer and $b_*$ its unique marginal load. Its receiver marginal is again $\nu$, but its row conditionals need not be $K_x$ and may be singular. Write $\Pi_*=\pi_*/D$ and $\sigma_*=b_*\mu/D$. The R87 row-minimum certificate is
\[
 b_*(y)=m(x)\quad\pi_*\text{-almost everywhere},\qquad
 m(x)=\operatorname*{ess\,inf}^{\mu}_{Q_x}b_*.
 \tag{1}
\]
For either joint law, disintegrate first source to receiver and then receiver to source, obtaining a source Markov kernel $P$. Its stationary law is the corresponding $\sigma$. Reversibility follows because, conditional on a receiver, the two source draws are exchangeable. For real bounded $g$, our Dirichlet convention is
\[
 \mathcal E_P(g,g)=\frac12\int\sigma(dy)P(y,dz)(g(y)-g(z))^2
 =\int\frac{d\nu(x)}D\operatorname{Var}(g(Y)\mid x).
 \tag{2}
\]
A spectral gap $\gamma>0$ means $\mathcal E_P(g,g)\ge\gamma\operatorname{Var}_{\sigma}(g)$ for all bounded real $g$. This is a definition, not a gap assertion for the present data. In particular it always refers to the stated stationary source law.

## 2. Optimized mixing preserves the unknown load

**Invariant-load theorem.** For every bounded Borel $\phi$,
\[
 P_*\phi(b_*)=\phi(b_*)\quad\sigma_*\text{-almost everywhere},
 \qquad \mathcal E_{P_*}(\phi(b_*),\phi(b_*))=0.
 \tag{3}
\]
Indeed, for $\nu$-almost every receiver, its optimized conditional source law is supported on the set $b_*=m(x)$ by (1). In a stationary source--receiver--source triple $(Y,X,Z)$, both $b_*(Y)$ and $b_*(Z)$ therefore equal $m(X)$ almost surely. This proves (3), including when the row conditionals are singular.

Consequently a positive spectral gap for $P_*$ forces $b_*$ to be constant $\sigma_*$-almost everywhere. This says nothing about unused source mass where $b_*=0$. More generally, every source level set of $b_*$ has zero stationary flow to its complement. In particular the principal pairs
\[
 A_s=\{m\ge s\},\qquad S_s=\{b_*\ge s\},\qquad s>0,
\]
satisfy
\[
 \sigma_*P_*(S_s,S_s^c)=0,\qquad
 \frac{\nu(A_s)}{\mu(S_s)}
   =\frac{\int_{S_s}b_*\,d\mu}{\mu(S_s)}\ge s
 \tag{4}
\]
when the denominator is positive. R87 proves that these are actual compact receiver cuts with $N(A_s)=S_s$ modulo source null sets. Their zero spectral boundary does not lower their ratio. If a component has constant load $c>0$, its receiver demand divided by its used source mass is still $c$.

This is an obstruction to inferring a capacity estimate from optimized-plan mixing or zero-boundary splitting alone. It is a theorem for the actual cube allocation, not a physical lower-bound construction and not a counterexample to the desired cube bound. A local geometric theorem capable of bounding each remaining component would still be needed. Global disconnected-copy pressure gives an additional familiar failure of a uniform global gap; (3) is stronger in a different direction, because it applies within a single actual optimized law whenever its load varies.

## 3. Canonical conductance supplies an exact, limited discount

For a Borel source set $S\subset N$, put
\[
 p_S(x)=K_x(S),\qquad
 Q_0(S,S^c)=\int_S\sigma_0(dy)P_0(y,S^c).
\]
Conditional independence of the two source draws given $x$ is part of the construction of the Markov kernel; it is not independence of physical source coordinates. Direct integration gives
\[
 DQ_0(S,S^c)=\int_Bp_S(x)(1-p_S(x))\,d\nu(x),\qquad
 D\sigma_0(S)=\int_Bp_S(x)\,d\nu(x)=\int_S b_0\,d\mu.
 \tag{5}
\]
If a receiver set $A\subset B$ has $\mu(Q_x\setminus S)=0$ for $\nu$-almost every $x\in A$, then $p_S=1$ there and
\[
 \nu(A)\le\int_Bp_S^2d\nu
 =\int_Sb_0d\mu-DQ_0(S,S^c).
 \tag{6}
\]
This includes the R87 principal pair $(A_s,S_s)$, while still using the original canonical law.

If, as an additional hypothesis, $P_0$ has gap $\gamma$, applying (2) to $1_S$ gives $Q_0(S,S^c)\ge\gamma\sigma_0(S)(1-\sigma_0(S))$. Thus for $\mu(S)>0$,
\[
 \frac{\nu(A)}{\mu(S)}
 \le\frac{\int_Sb_0d\mu}{\mu(S)}
             [1-\gamma(1-\sigma_0(S))].
 \tag{7}
\]
Both the averaged canonical load and the stationary source mass in this formula belong to the same original joint law. With only $b_0\le H$, it yields at most $H[1-\gamma(1-\sigma_0(S))]$. A fixed gap bounded away from zero does not, through this formula alone, change the power of $n$ in $H$. To reduce this envelope to order $\sqrt n\,n^{o(1)}$ on small stationary cuts would require $1-\gamma$ of order $n^{-1/2+o(1)}$, or a separate improvement of the cut-average load. Large stationary cuts require their own bound. No such uniform input follows from low physical collision or high averaged Shannon entropy.

The gap is not transported from $P_*$ to $P_0$. Their source stationary laws and their row kernels differ; optimized conditional allocations may be singular. Neither the canonical radial age estimate nor physical overlap formula may be attached to $P_*$ without a proved comparison.

## 4. Local deficits and the exact partition price

Partition $N$ into finitely or countably many disjoint Borel source sets $S_j$. Let measurable $w_j:B\to[0,1]$ satisfy $\sum_jw_j=1$, and put $\nu_j=w_j\nu$, $D_j=\nu_j(B)$, $\kappa_j=K\mu|_{S_j}$, $M_j=\kappa_j(N)$, for a proposed capacity $K\ge0$. All local plans must use the original closed cube relation $E=\{(x,y):y\in Q_x\}$. Write $N(A)=\bigcup_{x\in A}Q_x$ and define
\[
 \delta_j(K)=\sup_{A\subset B\ {\rm Borel}}
                [\nu_j(A)-K\mu(S_j\cap N(A))]_+.
 \tag{8}
\]
Analytic source neighborhoods are measured in the completed finite source measure. The weighted receiver measures are absolutely continuous with respect to the original $\nu$; their use here does not assert that the original geometric gates hold at a row-dependent threshold.

**Local partial-flow theorem.** The maximum mass of a legal positive measure with receiver marginal at most $\nu_j$ and source marginal at most $\kappa_j$ is $D_j-\delta_j(K)$. The maximum is attained, including when $D_j>M_j$.

For necessity, every partial plan misses at least $\nu_j(A)-\kappa_j(N(A))$ on a cut $A$. For sufficiency, add a dummy source of mass $\delta_j$, legal to all rows. The definition of $\delta_j$ makes every cut satisfy Hall with this added capacity. The full-row cut gives $M_j+\delta_j\ge D_j$, so an isolated dummy receiver of nonnegative mass $M_j+\delta_j-D_j$ balances the two sides. It is legal to every source. The compact closed-relation Hall proof from R87, with these isolated dummy points, supplies a full coupling; it applies to finite weighted receiver measures as well as $\lambda1_Bdx$. Discard all dummy edges. The remaining actual flow misses at most $\delta_j$ and the cut lower bound forces equality. Zero row or source mass causes no difficulty.

For completeness, attainment does not require $S_j$ to be closed. Partial measures live on the original compact ambient relation $E$, have uniformly bounded mass, and satisfy domination by the fixed finite measures $\nu_j$ and $\kappa_j$. Under weak convergence, these marginal inequalities persist when tested against nonnegative continuous functions, and hence as measure inequalities. The limit remains supported on closed $E$ and dominated by $\kappa_j$, so it cannot acquire source mass outside the Borel set $S_j$. Mass is continuous on the compact ambient space.

Let $\delta_K(B)$ be the corresponding global minimum missing demand with source cap $K\mu|_N$. Summing locally optimal partial flows gives
\[
                         \delta_K(B)\le\sum_j\delta_j(K).
 \tag{9}
\]
The receiver marginals sum to at most $\sum_j\nu_j=\nu$ and the disjoint source capacities sum to exactly $K\mu|_N$. Countable sums are well-defined by monotone convergence, since their total demand is $D$. There is no number-of-pieces fee and no copied source capacity in (9).

Take the canonical fractional assignment $w_j=p_j$, where $p_j(x)=K_x(S_j)$. Let $j(x)$ be the first index attaining $\max_jp_j(x)$, and define winner demand $\widehat\nu_j=1_{\{j(x)=j\}}\nu$. A countable probability vector has an attained positive maximum, and the first-max rule is measurable. With the same source cap, the one-sided variation of each demand measure gives
\[
 \widehat\delta_j\le\delta_j+
                   \int(1_{\{j(x)=j\}}-p_j(x))_+d\nu(x).
\]
Indeed this follows on every cut before taking its supremum. Summation yields the precise rounding price
\[
 \sum_j\widehat\delta_j\le\sum_j\delta_j+
 \underbrace{\int_B(1-\max_jp_j(x))d\nu(x)}_{E_{\rm part}}.
 \tag{10}
\]
The coefficient is one, independent of dimension or the partition size. The unconditional bound $E_{\rm part}\le D$ is not enough to guarantee a fixed fraction of demand can be served. Low collision does not give a small upper bound for this loss.

The useful all-cut success criterion is the following. Suppose $K$ and $0\le\varepsilon<1$ are uniform and, for **every** Borel receiver cut $A\subset B$, a source partition and row assignment for the same original input certify
\[
             \sum_j\delta_{j,A}(K)\le\varepsilon\nu(A).
 \tag{11}
\]
The partition may depend on $A$. By (9), there is a legal partial flow serving at least $(1-\varepsilon)\nu(A)$ using cap $K\mu$; all of its sources lie in $N(A)$. Therefore
\[
 (1-\varepsilon)\nu(A)\le K\mu(N(A))\quad\hbox{for every }A,
 \qquad K_{\rm opt}(B)\le\frac{K}{1-\varepsilon}.
 \tag{12}
\]
Here the last step is the proved R87 Hall interface. This method has no depth or reselection fee: all cuts are handled directly with the old selector and original $f$. It is conditional on proving (11), not on a whole-$B$ defect bound. The new local pieces have not been declared fully qualified physical inputs, so no theorem requiring their own middle or later gates has been invoked. A proof that instead reselects contacts must explicitly pay all the original gates and branch costs.

## 5. Why a collision telescope does not pay repeated splitting

Consider a finite binary source partition tree and one actual row posterior. Write $p_v$ for the mass at a node and $p_{v0},p_{v1}$ for its children, with $p_{v0}+p_{v1}=p_v$ and root mass one. Zero-mass terms are defined as zero. The cumulative local-rounding charge from processing every fractional node law is
\[
 L_{\rm tree}=\sum_{v\ {\rm internal}}\min(p_{v0},p_{v1}).
\]
This counts charges at successive levels, not disjoint terminal missed demand; a single path of irrevocable winner decisions would have a different accounting.
The boundary of the conditional posterior at node $v$, multiplied by its row mass $p_v$, is
\[
 C_v=p_v\frac{p_{v0}}{p_v}\frac{p_{v1}}{p_v}
                  =\frac{p_{v0}p_{v1}}{p_v},\qquad
 C_{\rm tree}=\sum_v C_v.
 \tag{13}
\]
These are the weights required by the canonical conductance calculation (5) on the local fractional row law. Directly,
\[
 C_{\rm tree}\le L_{\rm tree}\le2C_{\rm tree}.
\]
By the Shannon chain rule and the concavity chord bound
$h(q)\ge2\log2\min(q,1-q)$ for binary entropy $h$,
\[
 L_{\rm tree}\le\frac{H(p_{\rm leaves})}{2\log2}.
 \tag{14}
\]
This is not a dimension-free payment. For equal masses on $2^d$ leaves of a balanced depth-$d$ tree,
\[
 L_{\rm tree}=d/2,\qquad C_{\rm tree}=d/4,
 \qquad H(p_{\rm leaves})=d\log2.
\]
In contrast the unnormalized squared boundary telescopes:
\[
 \sum_{v\ {\rm internal}}2p_{v0}p_{v1}
                =1-\sum_{\ell\ {\rm leaf}}p_\ell^2\le1.
 \tag{15}
\]
Replacing (13) by (15) silently drops the factor $1/p_v$. Thus a bounded collision telescope cannot pay the actual conditional boundaries without an additional mass or depth bound. The balanced example is generic probability algebra, not an asserted fully gated high-load cube construction.

At a fixed physical side $h$, a captured cube meets at most $(2/h+2)^n$ grid cells, so this entropy payment is at most $n\log(2/h+2)/(2\log2)$ per row. At the retained $h_*=1/(16n^{3/2})$ this is $O(n\log n)$, before any further capacity or recursive fee; it is not the required root-order bound. Random grid translation changes the row probabilities but not the normalization issue. Arbitrary correlations of physical coordinates do not change any of these identities.

The one-shot price (10) avoids this sum over tree levels, but can approach all of $D$. The meaningful weakened route is therefore to prove the terminal all-cut criterion (11) directly with $K=\sqrt n\,n^{o(1)}$ and a fixed $\varepsilon<1$, using a new geometric local-capacity estimate. Merely proving local mixing, or replacing conditional boundaries by a quadratic telescope, does not provide that estimate.

## 5.1. Arbitrary-tree pressure on an existing actual input

**Actual-input quantifier theorem.** For every existing positive-demand compact regular $B$ as above and every finite integer $d\ge1$, there are a common Borel binary source-partition tree of depth $d$ and a compact receiver set $A\subset B$ with $\nu(A)>0$ such that, for every $x\in A$,
\[
 L_{\rm tree}(x)\ge d/3,\qquad
 C_{\rm tree}(x)\ge d/6,\qquad
 \sum_v2p_{v0}(x)p_{v1}(x)\le1.
 \tag{16}
\]
The original source, threshold, selector and all original gates are unchanged. The tree and $A$ may depend on $d$, and $A$ may shrink as $d$ increases. There is no lower bound for $\nu(A)$ uniform in $d$, no preservation of a large Hall ratio or high-load principal label, and no assertion against the existence of a specially chosen low-cost tree.

To prove the statement, choose $x_0$ in the support of $\nu|_B$. Its captured posterior $K_{x_0}$ is atomless because $\mu\ll dy$. Partition $N$ into $2^d$ Borel cells $S_\ell$ with $K_{x_0}(S_\ell)=2^{-d}$; for example, the continuous first-coordinate distribution of this absolutely continuous probability permits such a finite partition. Organize the leaves into a balanced binary tree. This is one common partition of the existing source space, not a separate law chosen for each receiver.

For every fixed leaf, the function
\[
 p_\ell(x)=\frac{\mu(S_\ell\cap Q(x,L(x)))}{\lambda L(x)^n}
\]
is continuous on $B$. Indeed the denominator is positive and continuous, and dominated convergence applies to $f1_{S_\ell}$ under the moving cube indicators: the limiting cube boundary has Lebesgue and source measure zero. Arbitrary boundaries of $S_\ell$ create no additional moving-boundary issue.

Since there are only finitely many leaves, a relative neighborhood $U$ of $x_0$ in $B$ has
\[
                     p_\ell(x)\ge\frac{2}{3\cdot2^d}
            \quad\hbox{for every leaf and every }x\in U.
\]
The support-point choice makes $\nu(U)>0$, and inner regularity supplies a compact $A\subset U$ with positive demand. At tree level $k$, each of the $2^k$ nodes has two children containing $2^{d-k-1}$ leaves apiece. Thus the minority mass at each node is at least $2/(3\cdot2^{k+1})$, and the sum over that level is at least $1/3$. Summing over $d$ levels proves the first inequality in (16). The inequality $C_{\rm tree}\ge L_{\rm tree}/2$ proves the second; (15) proves the third.

In particular these cumulative charges, integrated over $A$, are at least $d\nu(A)/3$ and $d\nu(A)/6$, whereas the raw squared boundary is at most $\nu(A)$. This rules out a depth-free demand-relative payment valid for all arbitrary source trees on all original receiver cuts. It does not rule out a geometric algorithm selecting favorable trees, and it is not a lower-bound construction for the maximal operator. No new source input was constructed. The same input's physical $C_{h_*}$ and averaged Shannon statistic remain exactly what they were before this auxiliary partition was introduced.

## 6. Three-stage pressure and the remaining task

**Pilot: exact laws and one split.** The invariance proof uses the actual optimized row-minimum identity, including singular conditional laws. The canonical conductance calculation is a direct conditional-probability identity. Exact rational finite checks verify the disjoint-capacity gluing and one-sided winner correction. These checks are generic finite allocation algebra; they do not provide a new physical input or a dimension estimate.

**Known-mechanism pressure: the two operators differ.** An explicit nonphysical four-source test has unit source masses. One row of demand $4$ captures the first two sources, a row of demand $1$ captures the last two, and a bridge row of demand $1$ captures all four. The canonical load is $(9/4,9/4,3/4,3/4)$. Its two-step source operator has eigenvalues $1,7/9,0,0$, hence gap $2/9$. Allocating the bridge entirely to the last pair gives the optimized load $(2,2,1,1)$; row minima certify its optimality and the optimized chain has a nonconstant invariant load. On the first pair, $D=6$, $\sigma_0(S)=3/4$, $Q_0(S,S^c)=1/24$, and the closed-row demand $4$ is at most $\int p_S^2d\nu=17/4$. Every displayed value was checked with rational arithmetic. Thus even a positive canonical gap need not be a positive optimized gap, and their boundaries cannot be interchanged.

A separate nonphysical two-component test has row demands $(2,98)$, source masses $(1,100)$, and each row captures only its corresponding source. At $K=1$ the whole-set deficit is $1$, just $1\%$ of the total demand, but the optimal capacity is $2$. This disproves a whole-set-only version of (12): $1/(1-0.01)<2$. It is an abstract quantifier check, not a fully gated cube counterexample. Disconnected physical replication remains an independently retained obstruction to a global gap; no new physical recipe is asserted here.

**Expanded parameters, tree depth, and dependent masses.** Author-side Fraction arithmetic checked 36 partition/rounding cases: four graphs at each of the row/source sizes $(2,3),(4,5),(6,8)$, each with capacities $1/2,1,3$, exhaustive receiver cuts, and nonuniform rational masses. All global-defect/glued-defect inequalities and winner corrections passed. Sixteen nonuniform rational posterior trees of depths $1,2,4,8$ satisfy the exact collision telescope and $C_{\rm tree}\le L_{\rm tree}\le2C_{\rm tree}$. Compressed exact level sums at depths $1,2,8,32,128$ give the balanced charges $d/2,d/4$ and bounded raw collision. The entropy comparison is proved by concavity and the chain rule, rather than inferred from floating logarithms. Arbitrary dependence is allowed in the probability laws; no coordinate factorization is used.

The physical dimension statement is analytic: (1)--(15) hold for every admissible dimension, while the available grid-entropy ceiling at $h_*$ grows as $O(n\log n)$. The finite graph sizes and abstract depths are not a sweep of fully gated physical dimensions. No Monte Carlo gate classification or fitted exponent is used. Both auditors independently prechecked all proposed statements before reading the detailed proofs. Both auditors completed full Markdown and corresponding LaTeX mathematical audits, including the actual-input addition (16), with PASS receipts. The independent public guard also passed its generic tree, local-defect and spectral checks; its execution counts and runtime are recorded by the audit owner. Those finite tests are not a qualification test for an actual gated input: the analytic proof establishes (16). Author execution remains separately identified above.

The actual unresolved input is a uniform geometric estimate for the original canonical cut profiles or the local terminal deficiencies in (11), on every receiver cut of the whole $F_{\rm new}$. A proved $K=\sqrt n\,n^{o(1)}$ and fixed $\varepsilon<1$ there would give the desired residual capacity, with the original separately paid branches, all-scale logarithm and any layer fee still retained. No such estimate was obtained here.

The new qualified obstruction is exact: the optimized Markov chain automatically preserves the quantity whose size must be bounded, and raw collision telescoping misses the normalization of local conditional boundaries. The remaining viable variant uses the canonical law and terminal all-cut deficiency, with the partition loss (10) written explicitly. This variant avoids a fictitious depth-free payment; it still requires new common-source geometry. No local source piece is silently treated as retaining the original middle lower gate or strict later witness, and the target stays open.

Status: proved interfaces and a source-proof boundary; the arbitrary-input cube target remains open. The R82 baseline ledger and every retained gate remain in force. No new dimension-uniform capacity estimate is claimed. All constants below use natural logarithms. Old round files are read-only.

## S1. The actual canonical receiver kernel

Let B be a Borel receiver cut of finite positive Lebesgue measure, with its original Borel contact side L(x) in [1,2]. Set D=lambda|B|, h_x(y)=L(x)^(-n)1_{Q_x}(y), b(y)=integral_B h_x(y)dx. The actual contact equality is integral h_x dmu=lambda, and integral b dmu=D. Use the actual probability joint law

    Gamma(dx,dy)=D^(-1)h_x(y) dx mu(dy).

Its receiver marginal is pi(dx)=lambda 1_B(x)dx/D and source marginal is sigma(dy)=b(y)mu(dy)/D. The forward and reverse conditional kernels are

    K(x,dy)=h_x(y)mu(dy)/lambda,
    K*(y,dz)=h_z(y)1_B(z)dz/b(y).

Ignore the sigma-null set b=0, and define exceptional null rows arbitrarily. The receiver return kernel P=KK* is

    P(x,dz)=lambda^(-1) integral h_x(y)h_z(y)/b(y) mu(dy) dz.       (S1)

Tonelli and contact give P1=1 pi-a.e. The measure pi(dx)P(x,dz) is symmetric. Conditional Jensen shows P is a positive self-adjoint contraction on L2(pi): <v,Pv>=integral(K*v)^2 dsigma>=0. This is the canonical law, not the optimized law of the principal theorem.

For every bounded measurable v,

    E_P(v,v):=1/2 integral (v(x)-v(z))^2 pi(dx)P(x,dz)
             =D^(-1) integral b(y) Var(v(X)|Y=y) mu(dy).           (S2)

Proof: conditional on Y=y, take two independent receiver draws from K*(y,.); their squared difference has expectation twice the conditional variance. Every distribution and conditional weight is from the same actual Gamma. No source-coordinate independence is used.

## S2. A radial upper bound with an explicit crossing cost

Write t(x)=log L(x), u(x,y)=log max(1,2||x-y||_infinity), and a=t-u. The retained row-age estimate gives Gamma(a>r|X=x)<=exp(-nr), hence E_Gamma a^2<=2/n^2. In each source fibre,

    Var(u|y)<=2 Var(t|y)+2 E(a^2|y).

For the UNWEIGHTED retained high-load statistic I_T(B)=integral_{b>T}Var(u|y)dmu, T>0, this yields the proved bound

    I_T(B)<=2D E_P(t,t)/T+4D/(T n^2).                            (S3)

Now partition B into finitely many measurable blocks with oscillation of t at most omega in each block. Let

    epsilon=Pr_{pi(dx)P(x,dz)}[block(x) != block(z)].

Same-block differences are at most omega and all differences at most log2. Consequently

    E_P(t,t)<=1/2[omega^2+(log2)^2 epsilon],
    I_T(B)<=D/T[omega^2+(log2)^2 epsilon+4/n^2].                  (S4)

This epsilon has an exact common-source form. Put b_j(y)=integral_{B_j}h_x(y)dx and r_j=b_j/b on b>0. Then

    epsilon=1-D^(-1) integral b(y) sum_j r_j(y)^2 mu(dy).          (S5)

Thus the missing estimate is a genuine *scale-block* crossing estimate for the actual conditional receiver law, at a fine enough scale omega. Fine physical source packets, entropy of their shares, and local spectral-gap lower bounds do not themselves give (S5). A partition with low average escape is not supplied by the retained gates. Refining a partition generally increases escape.

For a principal cut B=A_s supported canonically on S_s, put v_s=D/mu(S_s). A sufficient condition for the contract's freshly required I_T(A_s)<=R_n mu(S_s)/n is

    omega^2+(log2)^2 epsilon+4/n^2 <= R_n T/(n v_s).             (S6)

This records the load dependence explicitly. Applying it needs a fresh bound for each principal cut; conditional variance is not subset monotone. The source restriction does not inherit the middle lower smooth gate or strict later witness. Keeping the original f is essential when using these gates. No estimate establishing (S6) for the unpaid whole event is presently proved.

The parent's conditional Jensen implication also checks exactly. With T^2=24nR_n+96, the retained estimate gives (v_s-T)_+^2<=T^2-96+48v_s/T. If r=v_s/T>2, subtraction gives (r-2)(T^2 r-48)>0, a contradiction. Hence v_s<=2T under the stipulated fresh variance bound. This verifies the implication, not that variance hypothesis.

## S3. Precise primary decomposition tool and its actual boundary

Primary: Jerrum, Son, Tetali and Vigoda, *Elementary bounds on Poincare and log-Sobolev constants for decomposable Markov chains*, Annals of Applied Probability 14(4) (2004), 1741-1765, DOI 10.1214/105051604000000639; [author preprint/reprint math/0503537v1](https://arxiv.org/pdf/math/0503537). Read finite-chain setup, Theorem 1 and proof (equations 4-17), Theorem 4 and proof, and its entropy addendum; applications and all cited auxiliary papers are not claimed read.

Theorem 1 concerns a finite reversible chain, its projection to a finite partition, and restriction chains that hold exiting transitions at the current state. If projection gap is gbar and every restriction gap is at least gmin, its lower bound is

    g>=min(gbar/3, gbar*gmin/(3gamma+gbar)),
    gamma=max_x P(x,outside its own block).                    (S7)

Theorem 4 has the same expression for classical log-Sobolev constants, in the convention E(v,v)>=alpha Ent(v^2). These are lower bounds, with local and projection constants as hypotheses.

The following extension of (S7) to a standard Borel reversible kernel is OUR proof, not an assertion that the printed finite theorem already has this scope. Assume a finite measurable partition with positive pi-block masses, restriction gaps >=gmin>0, projection gap >=gbar>0, and gamma=essential supremum of exit probabilities. Let w_jk=integral_{B_j}P(x,B_k)pi(dx), barP_jk=w_jk/pi(B_j), and pi_j be the normalized block law. Decompose Var_pi v=W+V, where W=sum_j pi(B_j)Var_pi_j v. Decompose energy into within-block E_w and cross-block E_c. Then W<=E_w/gmin.

For w_jk>0 define exit-conditioned law pi_hat_j^k(dx)=pi_j(dx)P(x,B_k)/barP_jk. Split the difference of block means into the difference to the exit mean, the two exit means' difference, and the difference from the other exit mean. The inequality (a+b+c)^2<=3(a^2+b^2+c^2), projection Poincare, and Jensen for the actual cross-block coupling give

    V <=3 E_c/gbar+3 gamma W/gbar.

Indeed sum_{j!=k}w_jk(mean_j-mean_hat_j^k)^2<=gamma W; the corresponding other endpoint is equal by reversibility; the middle sum is <=2E_c. Therefore

    Var_pi v <=(3/gbar) E_c
                +(3gamma+gbar)/(gbar*gmin) E_w,

which proves (S7) by comparison with E_c+E_w. Integrals are finite for v in L2(pi), since stationarity bounds both marginals. No finite-mesh limiting argument is needed.

For the actual P in S1 this is a legal conditional tool. No retained assumption supplies either gmin or gbar. The mean crossing epsilon in S4 cannot replace the worst-state gamma. Optimized-law load levels are invariant and can have zero conductance; their spectral information does not transfer to Gamma. Even a successful lower bound g controls energy *from below*, whereas S3 needs an upper bound for the specific observable t. Thus this decomposition does not close S6.

## S4. Classical LSI cannot survive receiver nonatomicity

This is a generic NONPHYSICAL functional check, not an actual-input lower construction. Any stationary discrete-time Markov kernel on a nonatomic probability law has classical LSI constant zero. Choose sets A of arbitrarily small positive pi mass and test v=1_A. Then

    E_P(v,v)=pi(A)-integral_A P(x,A)pi(dx)<=pi(A),
    Ent_pi(v^2)=pi(A)log(1/pi(A)).

The quotient is at most 1/log(1/pi(A)), which tends to zero. The fully refreshing kernel nevertheless has Poincare gap one. A finite approximation has alpha<=1/log(1/pi_min); positive mesh LSI constants provide no dimension-uniform continuum constant. The same argument applies to uniformly bounded jump rates, with the rate bound in the numerator. It does not apply to an unbounded diffusion generator whose indicator need not lie in its form domain, and it says nothing by itself about modified LSI.

This phenomenon is already recorded in Del Moral-Ledoux-Miclo, Section 5 Remark 5.3(d); our short proof independently verifies the actual receiver-law obstruction. It is not labelled a new literature discovery.

## S5. Modified entropy source: exact reference and reading boundary

Primary: Del Moral, Ledoux and Miclo, *On contraction properties of Markov kernels*, Probability Theory and Related Fields 126 (2003), 395-420, DOI 10.1007/s00440-003-0270-6; [author-hosted journal PDF](https://perso.math.univ-toulouse.fr/miclo/files/2012/04/contraction.pdf). Read adjoint construction in Section 2 and Section 5 Proposition 5.1, its proof, Lemma 5.2 proof and Remarks 5.3. The whole paper and its external citations are not claimed read.

With actual input reference nu and actual output nuK, Proposition 5.1 compares the KL contraction loss alpha(K,nu) to the MODIFIED LSI constant l(nu,KK*_nu), within an unspecified universal factor 0<rho<1. No stationarity of K is required. The adjoint and symmetrization depend on nu. This statement does not give l for cube posteriors, a uniform numeric rho, or a threshold cost.

The printed lower-proof passage on journal p411 uses conditional interpolation f_t=e^(-t)f+(1-e^(-t)) while the conditional mass a_y=K*_nu f(y) need not be one. Its displayed entropy-integral identity is not verified beyond this normalization scope. A generic NONPHYSICAL two-state check has conditional law (1/2,1/2), f=(2,4): Ent(f)=5log2-3log3, whereas that baseline-one integral is (log2)/3. The mass-preserving conditional interpolation is e^(-t)f+(1-e^(-t))a_y. This flags the proof step, not a counterexample to Proposition 5.1. We do not silently replace the printed proof or use its unrestricted lower estimate to pay the cube problem.

The secondary Saloff-Coste-Zuniga paper [arXiv:1104.1560](https://arxiv.org/pdf/1104.1560), Section 4.5, was read as a dependency pointer to this proposition, not an independent completed modified-LSI proof. Its finite propagated-reference setting does not identify the adaptive conditioned laws with propagated kernels. No constant is imported from its printed reciprocal calculation.

## S6. A direct likelihood-band comparison with all costs

Let pi(dx)K(x,dy) be any common probability joint on standard Borel spaces, sigma=piK, reverse K*, P=KK*. Suppose a normalized input likelihood f satisfies 0<m<=f<=M<infinity. With H(z)=z log z, H''=1/z, Taylor's integral remainder gives, for every probability law supported in [m,M],

    Var(f)/(2M)<=Ent(f)<=Var(f)/(2m).

Here Ent(f)=E H(f)-H(E f), also for conditional means different from one. Therefore the exact conditional entropy decomposition implies

    Delta:=D(f pi||pi)-D((f pi)K||sigma)
           =integral Ent_{K*(y)}(f) sigma(dy)
           >=E_P(f,f)/(2M).                                   (S8)

If this actual P has Poincare gap g, then Ent_pi f<=Var_pi f/(2m) yields

    D((f pi)K||piK)<=(1-g m/M)D(f pi||pi).                     (S9)

This is a proved restricted comparison. It remains valid for canonical S1, with pi the receiver law, if its additional gap and likelihood-band assumptions are verified. It is not unrestricted SDPI. The actual cube input f(y), the receiver perturbation likelihood f in S8, and a newly restricted source density must not be confused. No retained cube gate supplies a uniform likelihood floor or a gap. Zeros, support holes, and unbounded density ratios invalidate the band assumption. No product reference or independence is assumed.

For a nonhomogeneous finite-alphabet sequence let p_next=pK be an ACTUAL propagated law, r=qK the transported reference, and q_next a new reference. Under absolute continuity and log-ratio integrability,

    D(p_next||q_next)=D(pK||qK)
                      +integral log((qK)/q_next) dp_next.       (S10)

If log((qK)/q_next)<=a on the p_next support and this step has a verified KL contraction loss delta, the safe inequality is

    d_next <=(1-delta)d+a.                                     (S11)

For finitely many steps, iteration weights the additive errors by subsequent products of (1-delta). A weighted source budget needs its own bounds on these errors and on the chosen outer weights. A constant kernel can enforce a formal pushforward for arbitrary selected laws, but then the reference-switch fee can carry the entire discrepancy; that is no geometric gain. The actual adaptive recursion's posterior reselection is not automatically a specified propagated common-law chain. S10 does not establish summability, pay U, or pay the terminal H t_m W_m term. The adaptive author's new homogeneous binary potential has its own elementary proof and is not attributed to these sources.

## S7. Skills, pressure stages, and exact remaining boundary

Read this round: F05 method/interface require both Hilbert measures and both row/column costs. Actual conditional Jensen supplies S1's contraction, not a maximal-operator gap. [N04](</Users/zhengzhihao/.codex/skills/math-n04-summable-error-entropy-descent/SKILL.md>) and its method require finite potential lower bounds and genuine partial-sum error budgets. [E03](</Users/zhengzhihao/.codex/skills/math-e03-tree-bellman-cross-layer-budget/SKILL.md>) and its cube interface require a genuine induced tree and masses. [F05](</Users/zhengzhihao/.codex/skills/math-f05-l2-spectral-parameter-schur-test/SKILL.md>) plus method/interface were read; none supplies a universal spectral or entropy theorem merely by its name. R87 D04 actual conditional-weight scope is retained. No skill hash substitutes for source reading.

Pilot: actual common-law normalization and S2 were derived from contact and Tonelli. Known-pressure checks: optimized/canonical laws differ; a lower spectral gap is the wrong direction for S3; a nonatomic receiver invalidates classical LSI; the conditional baseline-one entropy interpolation has an explicit generic algebraic failure. Expanded NONPHYSICAL finite checks: 96 exact Fraction cases, rows 2,3,5,8 by source states 2,3,7,16, six positive rational joint laws each, verified stochasticity, reversibility, conditional energy identity, crossing identity and block-energy upper bound. No actual receiver geometry or gate is inferred from those finite checks. Separately, 96 floating bounded-likelihood Jensen checks passed with largest positive residual 0; they are diagnostics, not certificates. Analytic proofs carry the claims.

Both auditors received the precise S1-S4, S8-S11 and integral decomposition statements before proof review. Final FULL MD and FULL TeX own-algebra/scope reviews passed from both auditors. Sol also independently browsed JSTV Theorem 1, its equations 4-17 proof, and Theorem 4/entropy convention. Both independently checked the generic conditional baseline-one calculation; neither final receipt claims an independent reread of the Del Moral printed page. Its parsed-primary reading provenance remains the source author's. No broader full-paper audit is claimed.

Result: a new actual radial-energy/crossing interface S3-S6, a qualified continuum Poincare decomposition, and a likelihood-band entropy comparison with explicit reference-switch error. The unpaid step is dimension-uniform control of actual high-load scale-crossing or equivalent common-source geometry for every principal cut, or payment of the adaptive weighted compensation and terminal expenses. The general root-order target remains UNPROVED. Global replication, support holes, and changing conditioned laws remain live obstructions; no private physical construction is exposed here.

# R88 conditional all-cut return — parent derivation

Status: CONDITIONAL ONLY. Both independent auditors checked the exact proposed statement before this proof was written. No fresh variance bound has been proved. This records the single missing analytic input without replacing it by a change of notation.

Let n>=2, mu=fdy with nonnegative L1 f, lambda>0. Retain the original source and whole current Fnew as defined in the R87 ledger. Put H=1+n log2. Canonical contact yields lambda|Fnew|<=H mu(R^n), so receiver demand is finite. Earliest L is Borel and all statistics defining Fnew are measurable. Completed measurable receiver events may be replaced by Borel versions.

Here a regular compact set means ONLY a compact B subset Fnew with continuous original L restricted to B. No smooth boundary, root derivative, transversality or interior positive margin is assumed. The R87 continuum optimization proof uses only this compactness, continuity, original contact and source absolute continuity; extra regularity must not be added silently.

Fix R_n>=0 depending only on n and set T=sqrt(24nR_n+96)>=sqrt96>2. The missing uniform hypothesis is:

For every such original input and regular compact B, and each positive principal level s with W_s=mu(S_s)>0, the freshly computed CANONICAL field of A_s satisfies

I_T(A_s) <= R_n W_s/n.

The optimizing coupling is used only to define principal A_s,S_s; its possibly singular conditional laws do not define I_T. The hypothesis is not inferred from I_T(B), from any whole-event estimate, or from retained labels of a newly restricted input.

For a fixed cut, source closure implies b_(A_s)=0 mu-almost everywhere outside S_s, and integral_Ss b_(A_s)dmu=lambda|A_s|=D_s. Thus Jensen for z -> (z-T)_+² and the retained R85 canonical forcing give

W_s (v_s-T)_+² <= integral(b_(A_s)-T)_+²dmu
<=24n²I_T(A_s)+48D_s/T <=W_s[24nR_n+48v_s/T],

where v_s=D_s/W_s. If v_s<=T there is nothing to prove. Otherwise define

F(v)=(v-T)²-48v/T-24nR_n.

F(2T)=T²-96-24nR_n=0. For v>=2T,
F'(v)=2(v-T)-48/T>=2T-48/T>0,
since T²>=96. The preceding inequality F(v_s)<=0 therefore implies v_s<=2T. Principal saturation gives v_s>=s whenever that level has positive mass. Since every 0<s<esssup b* has positive mass, esssup b*<=2T. This yields a feasible 2T-capacity coupling for B and bounds every measurable receiver cut within B.

To pass to arbitrary A subset Fnew, use finite-measure Lusin plus inner regularity to obtain compact K_j subset A with L|K_j continuous and lambda|K_j| -> lambda|A|. Nestedness is unnecessary. One can first choose compact Lusin sets whose complement has demand <1/(2j), then take a compact subset of their intersection with a Borel representative of A losing <1/(2j). All original gates on K_j are inherited from the ORIGINAL input; no source is removed. The hypothesis above gives

lambda|K_j| <=2T mu(N_(K_j)^ess) <=2T mu(N_A^ess),

because canonical section integrals for K_j are pointwise at most those for A. Taking the numerical limit yields every measurable Hall cut with fee2T. The R87 Borel-selector Hall theorem then gives a positive coupling for the whole event. It may be singular relative to receiver-times-source measure. There is no approximation factor, unproved maximizing cut, or extra source restriction here.

With the unchanged R87 partition of the original retained event, full return is

C_n^square <= C_loc log(n+2) [B0+Bext+Tsoft/alpha+Pdom_improved+Pphys+2sqrt(24nR_n+96)].

All quantities are those of the R87 ledger. If the new hypothesis is proved only on individual kappa layers, the corresponding residual term must be summed over the O(log n) layers before this return; the full-event statement above pays no such sum by assumption. If R_n=n^{o(1)}, this conditional formula has the required exponent. No numerical fit or finite model establishes that hypothesis, and the general upper bound remains OPEN.

Three-stage logical pressure scope: pilot is the exact Jensen/polynomial calculation; known-obstruction checks exclude source-subset variance monotonicity, optimized-law substitution, and inheritance of middle/later gates after restriction; scope enlargement is the Lusin passage from compact continuous-selector sets to every measurable cut. These are analytic checks, not qualified high-dimensional numerical evidence. Numerical and adversarial probes of the missing hypothesis are separately owned and must be reported with their actual outcomes.


# R88 parent: a Gamma majorant and a verified semigroup obstruction

Status: general kernel comparison PROVED; proposed automatic semigroup transfer FAILS; the weak bound for the smoothing maximal operator remains OPEN. This is a bounded alternative-route check, not a proof of the cube target. Both auditors independently checked the statements before the following proof.

Here only, U_r(x)=(2r)^(-n)1_{||x||_infinity<=r} uses HALF-SIDE r; this convention differs from the full-side L in the main ledger. Let

Psi_(n,t)(x)=exp(-||x||_infinity/t)/(2^n n! t^n), t>0.

Gamma has shape n+1 and rate1. Direct nonnegative layer integration gives

Psi_(n,t)(x)=integral_0^infinity U_(tr)(x) r^n exp(-r)/n! dr.

Consequently Psi is a continuous probability density. At the corner of the radius-r cube, Psi_(n,r/n) is minimal on that cube, yielding the exact pointwise comparison

U_r <= c_n Psi_(n,r/n), c_n=n! exp(n)/n^n.

For positive L1 input this entails M_Psi f<=M_cube f<=c_n M_Psi f. The first inequality uses positive normalized mixing; it does not bound the new maximal weak constant by a smaller quantity. No averaging of weak norms is used.

The factor has an elementary bound c_n<=6sqrt(n). From the Gamma integral,
c_n=n integral_0^infinity exp(n(logu-u+1))du.
On 0<u<=1, logu-u+1<=-(u-1)^2/2. On 1<=u<=2, write v=u-1 and use v-log(1+v)=integral_0^v s/(1+s)ds>=v²/[2(1+v)]>=v²/4. On u>=2, the derivative 1/u-1<=-1/2 and log2<=3/4 give logu-u+1<=-1/4-(u-2)/2. The three integrals, multiplied by n, are at most sqrt(pi/2)sqrt n, sqrt(pi)sqrt n, and2exp(-n/4). Their sum is less than6sqrt n for n>=1. This is an analytic bound, not an exponent inferred from the finite computation.

A subpower uniform weak(1,1) estimate for M_Psi would therefore prove the general cube goal directly, without the R82 event reduction. Such an estimate has NOT been proved here. In particular the kernel is not an available heat/Poisson semigroup kernel. With Fourier convention integral exp(-ix dot xi)Psi(x)dx, layer integration in n=3 gives

Fourier(Psi_(3,1))(1,1,3)
=1/18 integral_0^infinity exp(-r)sin²(r)sin(3r)dr
=1/18 [3/20-5/104-1/8] = -1/780.

This exact negative continuous multiplier prevents Psi_(3,1) from being a positive-time member of a selfadjoint convolution semigroup exp(-sA) with nonnegative selfadjoint generator; such an operator has nonnegative spectrum. It does not prevent a general discrete Markov convolution kernel from having this density. Positivity of the spatial probability kernel and positivity of its Fourier multiplier are distinct. The nonpositive-definite restriction in dimension3 also prevents e^(-||x||_infinity) from being positive definite in any higher dimension: a positive-definite function restricts to positive-definite functions on coordinate subspaces. No general nonsymmetric or differently constructed maximal theorem is ruled out.

Three-stage exact probing in parent_gamma_probe.py uses only standard-library rational arithmetic. Pilot: all integer frequencies0..4 in dimensions1 and2 are positive, with correct zero-frequency normalization. Pressure: the exact dimension3 negative value is checked by an independently written sine-product identity across six rational frequency scales. Expanded: deterministic frequency tests in dimensions3 through8 include negative multipliers, and zero-frequency normalization is checked through dimension12. All460 records pass their stated arithmetic predicates. These are kernel tests, not physical lower-bound input recipes, and they give no maximal weak estimate. The exact identity and sign are proved above independently of the search.

Updated F04 SKILL/method/cube interface was read: Gamma shape/rate, generator existence and maximal-limit transfer are explicit requirements. Updated F02 SKILL distinguishes spatial nonnegativity from spectral positivity and disallows tensor rules for coordinate-coupled kernels. This Psi is coupled through the infinity norm. The skill does not supply its generator or weak maximal estimate. A primary-source search produced no verified additional estimate used here; the displayed statements are direct derivations. The failed automatic semigroup transfer is recorded to prevent future repetition.

## The direct smooth-variation estimate still pays linear dimension

The radial variable R=||X||_infinity/t for X with density Psi_(n,t) has Gamma(shape n,rate1) density r^(n-1)e^-r/(n-1)!, distinct from the shape n+1 mixing variable above. Differentiating the spatial density gives the logarithmic-scale score R-n. Thus

||partial_(log t) Psi_(n,t)||_1=E|R-n|
=2 n^n e^-n/(n-1)! =2n/c_n.

Indeed E(R-n)=0 and integration by parts on [n,infinity) gives the positive deviation integral n^n e^-n/(n-1)!. This proves the identity with all constants. For positive L1 f, the fundamental theorem of calculus and Tonelli then give

||sup_(t0<=t<=2t0) Psi_(n,t)*f||_1
<= [1+(2n/c_n)log2] ||f||_1.

One can first use bounded compactly supported f, and then pass monotonically using positive kernels; the derivative absolute integral is integrable by the displayed exact norm. Equivalently the positive derivative majorant integrates the entire compact t-window. Multiplying by the cube majorization factor yields c_n+2nlog2. This is still O(n) and does not improve the retained hard-window estimate. A root-order comparison factor cannot be counted without the cost of the smoothed maximal operator. This exact ledger closes the direct-variation version of the route as a failed gain, while other genuine estimates of M_Psi remain open.

## A recent neighboring result does not supply the missing endpoint

The introduction and Theorem1.1 statement of [Ciccone–Wróbel, arXiv:2607.06041v1](https://arxiv.org/pdf/2607.06041) were read in the primary PDF. That theorem concerns Euclidean radial log-concave densities and fixed1<p<infinity. Our infinity-norm kernel is not Euclidean radial for n>=2, and the required endpoint is weak(1,1). Neither change of scope is supplied by that statement. No full proof read or endpoint transfer is claimed; no result from this paper is used in the displayed kernel derivations.


本轮没有得到完整新余集的高负载证书，也没有证明逐主割的径向方差预算或一般平方根界。公开程序提供新的一组有限图与条件算术证书；实际来源权重优化保留在私有文件中。两类材料的测度和资格不同，不能相互替代。

对一个有限图，来源质量 \(p_i>0\)、行需求 \(d_r>0\) 和捕获邻域 \(N_r\) 都是有理输入。程序精确枚举全部非空来源割并计算
\[
 K=\max_{S\ne\varnothing}\frac{\sum_{r:N_r\subset S}d_r}{\sum_{i\in S}p_i}.
\]
它保存全部最大割、它们的并、割的强制行，以及容量 \(Kp_i\) 下饱和全部需求的有理流。独立核对每条容量、每个内部节点的守恒和残余割值，因此枚举的下界与可行流的上界相等。

程序按“全部最大密度割的并”剥离强制行及来源块，再从剩余邻域删除此前来源。剩余块密度严格下降。每个累积主割都保存原始行索引、原始来源邻域并、来源质量和需求；精确检查来源闭合及 \(D/\mu(S)\)。逐块流使用残余邻域，而累积主割的规范列始终使用原始邻域。这避免把后块的残余输送误当成原始来源限制后的重新接触。

同一行需求下，规范列由 \(d_r/\mu(N_r)\) 计算，程序另存 \(D/W\)、最优 \(K\) 和规范列最大值。每行还有一个有理 \([0,1]\) 标量代理，供检查规范条件矩和来源加权过滤方差的账本。这些图与代理全部明确为**非物理**：没有真实接收体积、连续最早接触、原平滑门槛或径向几何。大密度而代理方差为零的压力图说明，有限主割与流恒等式本身不能提供所缺的几何方差定理；它不是实际算子的反例。

另有 48 条准确的条件桥算术记录。令 \(T^2=24nR+96\)，则
\[
 (v-T)^2-24nR-48v/T=(v-2T)(v-48/T).
\]
当 \(v>T\) 时，\(T\ge\sqrt{96}\) 保证第二因子为正。因此，若已经证明左侧非正，就有 \(v\le2T\)。代码检查假设成立、边界相等和假设失败三种情况。它没有证明规范方差预算，也没有借用方差对子集的单调性。

检验分三个阶段：小共享邻域初探；大密度、零代理方差及最大割并列的压力；扩大来源数和共享邻域的有理随机图。总计 10 个图、37 个主块、766 个原始来源割、1,393 个残余来源割、463 条流弧和 48 条条件桥记录。程序只用 Python 标准库，自包含；本机运行约 0.05 秒。确切分数、邻域和流见 `hall_results.json`。这些有限证书不认证任何实际完整余集。

实际私有探索主动改变共同来源的权重与阈值，并在训练后冻结输入，再使用独立留出接收样本；扩大阶段没有复用旧轮低负载参数。训练目标包含粗平滑过滤，不能只选择最大的硬事件负担。输入相关的整块捕获结构给出了另一个可明确归一化的输送候选，用于区别规范点列与优化容量。其容量公式依赖真实接收体积；Monte Carlo 体积估计不是流可行性证书。

本轮训练和留出没有检出粗低的合格压力候选。部分输入门槛可由有理包络与统一核界验证，但最早连续根、所选粗平滑及真实体积分割仍有未认证环节。因此“零命中”不表示完整余集为空或实际容量为零。规范列只查询有限来源点，不给来源质量积分，也不提供逐主割 \(I_T\)。高维孤立接收样本若直接附上积分权重，会产生虚假的大 Hall 比值；本轮没有把这种采样图当作真实体积输送。

当前缺口是：在实际完整余集或其真正来源闭合主割上，认证稀尾接收体积、连续门槛及共同来源的径向方差预算。公开条件算术和私有低命中搜索都没有支付这个缺口。一般目标仍未证明。

Independent R88 audit: the new positive lemmas and their detailed MD/TeX proofs pass within the following scopes. The general arbitrary-input sqrt(n) times subpower weak bound remains OPEN.

- Conditional principal-cut return: with T=sqrt(24 n R_n+96), a fresh ORIGINAL canonical bound I_T(A_s)<=R_n mu(S_s)/n for every original input, every compact B in the whole Fnew with continuous original selector, and every positive principal cut implies residual Hall capacity at most 2T. Lusin approximation extends this to all measurable cuts. This variance hypothesis has not been established. Neither optimized conditionals nor variance inheritance under restriction may replace it.
- Exact coverage accounting: the common-source continuity equation, action nM/12, measurable stopped-graph signed limit and finite-thickness error are valid. A positive smooth side trace can force the sharp energy to diverge as 1/epsilon. The repaired finite identity is D minus anchor = face occupation minus interior occupation; each positive occupation costs at most n log2 M. It recovers the linear baseline. A root-order bound for their signed difference remains unproved.
- Actual allocation and partition interfaces: optimized load levels are invariant under their own two-step chain. Canonical conductance and disjoint-source partial-flow deficits use their correct laws and capacities. A useful deficit criterion must hold on EVERY receiver cut. Winner rounding and tree charges retain all boundary costs. On any existing positive-demand compact regular input, arbitrary finite source trees can have charges proportional to depth on a smaller positive-demand receiver set; that set may shrink and need not preserve a high Hall ratio. This does not exclude a favorable algorithmically chosen tree.
- Adaptive potential: Psi(D,W)=D[1+log(HW/D)] has an exact nonnegative three-term decrement and is at most H W. The full threshold-weighted drift, near-critical necessary progress and actual high-burden trichotomy pass. At critical source scaling with all receivers retained, the compensated mass potential is stationary. The repeated branch fees, positive compensation and terminal H t_m W_m are not paid by the unweighted identity. The artificial common-law pressure is not an actual cube recursion example.
- Spectral and entropy interfaces: the canonical Gibbs energy gives a proved radial bound with explicit scale-block crossing and load costs. The continuum finite-partition gap comparison requires actual restriction/projection gaps and essential-supremum escape. Likelihood-band KL contraction requires a positive likelihood floor, finite range and actual gap; changing reference pays its explicit drift. These hypotheses are not supplied by the current gates. Direct algebraic audits are separate from the source author's stated primary-paper reading scope.
- Gamma comparison: the probability kernel is a Gamma(shape n+1) mixture of radius-r cube kernels, with comparison c_n=n! exp(n)/n^n<=6sqrt(n). Its dimension-three Fourier value at (1,1,3) is exactly -1/780, excluding the proposed automatic nonnegative self-adjoint semigroup substitution. Its own radial variable has Gamma(shape n), and direct variation costs 2n/c_n. After comparison the window cost is c_n+2n log2, still linear. A subpower maximal estimate for this new family remains unproved.

The final return retains all original gates and the freshly recomputed whole Fnew. The physical collision/entropy union is paid once. Source restriction preserves old hard prefixes/contact and captured statistics but does not automatically preserve the middle lower gate or strict later witness. Any layerwise proof must pay its layer count, in addition to the all-scale logarithm. Finite algebraic guards and kernel Fourier records do not certify physical high-load geometry. The private scalar replay verifies only its explicitly conditional scalar statements; floating searches give no certified current high-load cut, variance budget or active recursion.

## R88 independent public audit — final receipt

The general arbitrary-input square-root dimensional weak bound remains **UNPROVED**. This audit confirms the stated conditional implications, exact identities and finite certificates. It does not supply the missing common-source variance, cancellation or all-cut geometric estimate.

The original Sol auditor completed the independent statement prechecks and final proof readings reported below; its timestamped blind record is retained locally outside the public extraction. It read the full final Markdown and matching TeX for the parent return/Gamma sections, adaptive mass potential, alternative spectral/local-deficiency route including its actual arbitrary-tree addition, coverage flux including its finite face-minus-interior addition, and source-law interfaces. Its receipt is PASS within the stated hypotheses, including static control-character checks. The replacement Sol auditor read the contract, introduction, ledger, existing audit and complete frozen guard, checked their stated scope and file identities, and independently executed the portable guard as described below. The replacement did not repeat all author proof readings or private floating runs. No PDF compilation was performed.

The principal-cut bridge gives the exact capacity coefficient 2T, with T²=24nR_n+96, only under a fresh ORIGINAL canonical variance estimate for every required principal level; that hypothesis remains unproved. Source closure supplies its normalization; optimized conditionals do not define that variance. Lusin and inner regularity extend compact continuous-selector cuts to all measurable cuts without an additional fee. “Regular” adds no unproved transversality. Original lower smooth and strict-later gates are not inherited after source restriction. The original R82 event, source measure mu=fdy, actual demand lambda dx, R87 branch costs, all-scale localization and any separate layer sum remain charged.

The new mass potential has a nonnegative exact three-term decrement and upper bound HW. Its threshold-weighted compensation and the larger terminal Ht_mW_m remain unpaid; critical compensated stationarity prevents a free entropy payment. Optimized source mixing preserves its load levels, while canonical conductance uses another joint law. Local deficiencies glue with disjoint physical capacities, but their useful estimate must hold on EVERY original receiver cut. Tree conditional boundaries retain their normalization and can accumulate with depth; the actual arbitrary-tree theorem permits a shrinking positive-demand receiver set and does not disprove existence of a favorable geometric tree.

Coverage's measurable stopped flux has a valid L1 passage. Its sharp-cut positive energy can diverge; the finite face and interior occupations use the same physical source and stopping graph and recover the baseline. A root-order signed cancellation estimate is still missing. Source Poincare and likelihood-band tools retain their actual stationary/reference laws, required gaps, likelihood bounds and explicit reference-switch fee. The original auditor independently reread the finite theorem statements and relevant decomposition proof in the [Jerrum–Son–Tetali–Vigoda primary paper](https://arxiv.org/pdf/math/0503537); its constants and finite scope match. It independently checked the separate conditional entropy-normalization calculation algebraically, without claiming a successful reread of the timed-out Del Moral–Ledoux–Miclo primary page.

The Gamma(n+1,1) cube mixture and its square-root pointwise majorant are valid; the kernel's radial law is Gamma(n,1). The exact negative Fourier value −1/780 excludes the proposed nonnegative selfadjoint convolution-semigroup substitution. The direct smooth-window estimate pays c_n+2n log2, still linear in dimension. One exact-code issue was corrected before freeze: the zero-frequency sum now starts with sum(..., Fraction(0)) rather than floating 1.0; all 460 records were rerun and all saved Fourier calculations remain rational.

### Executed independent verification

The following original-auditor executions are retained as its completed receipts, not claimed as new replacement-auditor work:

- Public Hall pair: all 10 **NONPHYSICAL** graphs, 37 principal blocks, 766 whole source cuts, 1,393 residual source cuts, 463 flow arcs and 48 conditional bridge records were independently reconstructed from JSON. Checks cover every enumerated density, union of maximizers, residual source mapping, block and whole-flow topology/capacity/conservation/residual cut equality, original cumulative source closure, source-weighted moments and proxy variance. No author program was imported for this verification. These graphs lack actual receiver geometry, continuous contact and retained gates.
- Gamma pair: all 460 saved exact multipliers were independently recomputed by a separately written trigonometric-polynomial convolution and rational Laplace recurrence, including zero-frequency normalization and −1/780. This is kernel arithmetic, not a weak maximal bound.
- Original auditor's new scalar guard: pilot 365, pressure 687 and expanded 625 assertions, followed by exact mass-log coefficient, spectral and saved-certificate checks. Dimensions and abstract depths are explicit in the guard. Tests of the artificial common law, graphs and reference polynomials are **NONPHYSICAL**; analytic proofs carry the general assertions.
- Separate isolated producer replays returned exit zero, empty stderr and byte-identical JSON: Hall 0.050097 seconds; Gamma 0.392605 seconds. These execution receipts are distinct from independent certificate reconstruction.
- Final portable guard was extracted from the sole Python fence in a temporary seven-member environment containing only the public proof pair, two public program/data pairs and inventory. It passed **10,090 assertions**, including all four frozen hashes, fence byte identity and proof control-character checks, in **7.873941 seconds** wall time with empty stderr. It depends on no component source documents, skills, private program or external path. It does not rerun the producer programs; the separate receipts above do.

The parent separately reported four isolated component replays: public Hall in 0.054 seconds and Gamma in 0.421 seconds reproduced exact JSON; private Hall in 15.159 seconds reproduced exact JSON; private flux in 52.664 seconds matched after removing only the top-level runtime_seconds field. These are parent execution receipts, not additional proof or gate certification.

The replacement auditor verified all five SHA-256 identities below and inspected the complete guard: it reads the two public JSON files, hashes the four public program/data files, checks a sole Python fence when proof.md is present, and imports no author algorithm. It then built a separate temporary seven-member public **mockproof** environment, extracted the sole fence byte-for-byte, and executed the unchanged guard. This new run passed **10,090 assertions** in **8.058016 seconds** wall time (8.032376 seconds reported by the guard), exit zero and empty stderr, with the same Hall counts, 460 Gamma records and archive-fence PASS. This verifies guard portability and the frozen certificates; it is not a new full reading or execution check of the parent's eventual assembled proof pair.

Frozen SHA-256 identities:

| Public file | SHA-256 |
|---|---|
| hall_probe.py | b2a3dce411e80f9108281bbc46fb58d3d75a979d888e11d20d33c494bdfb874b |
| hall_results.json | 08a094804f8ab8f9a21632b45ac92a875f5ce119ed80dab6e94abe1ea53c083e |
| parent_gamma_probe.py | 131bcfbd6c3ace22e26b642b3b6c989eda8cd3c06d63aa9345e76ed1a290cc37 |
| parent_gamma_results.json | ed53c43255c8d49b299a04940bbae2307172dcd10b6e6da463dfb289eee481a1 |
| embedded audit_guard.py | aef0b6ca120a4592f805cd55bef0b174ec6c15970aae1e4922756417e71c5050 |

Private pressure recipes are excluded from this public extraction and from the portable guard. The original auditor's separate private scalar replay checks only the independent scalar gates; it does not certify the continuous earliest hard root, coarse event, receiver volume, high-load principal source mass or canonical variance. Anonymous numerical status is only that actual high-load qualification remains unproved: zero floating detections imply neither an empty residual nor zero variance/capacity. No finite check here proves the general target or substitutes a different receiver measure or source law.

## 独立公开证书审核程序

```python
#!/usr/bin/env python3
"""R88 independent public guard. All finite arrays below are NONPHYSICAL.
No original cube gate or general dimensional bound is certified by them.
Standalone standard library; both frozen public pairs are required.
"""
from fractions import Fraction as F
from math import factorial
from pathlib import Path
import hashlib, json, random, time, re

EXPECTED={
 'hall_probe.py':'b2a3dce411e80f9108281bbc46fb58d3d75a979d888e11d20d33c494bdfb874b',
 'hall_results.json':'08a094804f8ab8f9a21632b45ac92a875f5ce119ed80dab6e94abe1ea53c083e',
 'parent_gamma_probe.py':'131bcfbd6c3ace22e26b642b3b6c989eda8cd3c06d63aa9345e76ed1a290cc37',
 'parent_gamma_results.json':'ed53c43255c8d49b299a04940bbae2307172dcd10b6e6da463dfb289eee481a1',
}

COUNT = 0
STAGES = {}
def ck(p):
    global COUNT
    assert p
    COUNT += 1

def factors(q):
    q=F(q); out={}
    for v,sgn in ((q.numerator,1),(q.denominator,-1)):
        d=2
        while d*d<=v:
            while v%d==0:
                out[d]=out.get(d,0)+sgn; v//=d
            d+=1
        if v>1: out[v]=out.get(v,0)+sgn
    return {p:e for p,e in out.items() if e}

def add(a,b,scale=F(1)):
    o=dict(a)
    for k,v in b.items(): o[k]=o.get(k,F(0))+scale*v
    return {k:v for k,v in o.items() if v}

def logform(q,scale=F(1)):
    return {p:scale*e for p,e in factors(q).items()}

def psi(D,W,H):
    if not D: return {}
    return add({0:D},logform(H*W/D,D))

def entropy_split():
    # Formal rational log coefficient cancellation, not floating equality.
    for H in (F(8),F(32),F(128)):
        for R in (F(1),F(2),F(3)):
            D=R; W=F(1)
            for rho in (F(1,4),F(1,2),F(3,4)):
                for p in (F(1,3),F(1,2),F(2,3)):
                    C=p*D
                    if C>H*rho or D-C>H*(1-rho): continue
                    for beta in (F(1,5),F(1,4)):
                        for s in (F(1,2),F(1)):
                            child=beta*s*D
                            if child>=C: continue
                            kl=add(logform(p/rho,D*p),logform((1-p)/(1-rho),D*(1-p)))
                            rhs=add(add(kl,psi(D-C,1-rho,H)),add(psi(C,rho,H),psi(child,rho,H),-1))
                            ck(add(psi(D,1,H),psi(child,rho,H),-1)==rhs)
                            # compensated drift expressed formally
                            a=add({0:F(1)},logform(H/R))
                            drift=add(psi(D,1,H),psi(child,rho,H),-1/beta)
                            expected=add({k:D*(1-s)*v for k,v in a.items()},logform(beta*s/rho,D*s))
                            ck(drift==expected)

def bridge(n,R):
    # Substitute v=z*T. Multiplication by T^2 removes irrational roots.
    T2=24*n*R+96
    ck(T2>=96)
    for z in (F(2),F(201,100),F(5,2),F(3),F(10)):
        residual=(z-1)**2*T2-48*z-24*n*R
        ck(residual==0 if z==2 else residual>0)
    ck(2*T2-48>0)
    rng=random.Random(n+int(R*100))
    values=[F(rng.randrange(1,30),3) for _ in range(7)]
    weights=[F(i+1,28) for i in range(7)]
    for T in (F(2),F(7),F(10)):
        mean=sum(w*v for w,v in zip(weights,values))
        ck(max(mean-T,0)**2<=sum(w*max(v-T,0)**2 for w,v in zip(weights,values)))

def common_law(n,m):
    # Artificial circle edges, not Euclidean cubes or actual noise stopping.
    c=F(4,5); beta=F(2,5); delta=F(1,2); zeta=F(9,10)
    p=F(7,10); R=F(3); H=F(10); a=p*R/beta; b=(1-p)*R/(1-beta); K=F(3)
    ck(c<zeta and p>delta and zeta*b<K<zeta*a and a<=H)
    L=[F(3,2)+F(m-i,4*m) for i in range(m+1)]
    M=a*L[0]**n
    W=F(1); D=R; t=F(1)
    for i in range(m):
        ck(a*L[i]**n<=M)
        ck(L[i+1]<L[i] and a*L[i+1]**n<a*L[i]**n)
        ck(a*beta**(i+1)+b*(beta**i-beta**(i+1))==R*beta**i)
        lam=R*beta**i/M
        ck(lam*L[i]**n==L[i]**n*(a*beta**(i+1)+b*(beta**i-beta**(i+1)))/M)
        ck(p*lam>beta*lam and zeta*lam>c*lam)
        ck((t/beta)*(beta*D)==t*D and (beta*W)/(beta*D)==W/D)
        # Ψ logarithmic argument and prefactor preserved exactly.
        ck(H*beta*W/(beta*D)==H*W/D)
        W*=beta; D*=beta; t/=beta

def deficit(dem,neigh,mass,K,source=None):
    source=set(range(len(mass))) if source is None else set(source)
    ans=F(0)
    for mask in range(1<<len(dem)):
        rows=[i for i in range(len(dem)) if mask>>i&1]
        union=set().union(*(neigh[i] for i in rows)) if rows else set()
        ans=max(ans,sum((dem[i] for i in rows),F(0))-K*sum((mass[j] for j in union&source),F(0)))
    return ans

def partitions(nr,ns,seed):
    rng=random.Random(seed)
    for trial in range(4):
        mass=[F(rng.randrange(1,8),3) for _ in range(ns)]
        dem=[F(rng.randrange(1,9),4) for _ in range(nr)]
        neigh=[{j for j in range(ns) if rng.randrange(3)} for _ in range(nr)]
        for v in neigh:
            if not v: v.add(rng.randrange(ns))
        groups=[set(range(j,ns,3)) for j in range(3)]
        shares=[[sum((mass[j] for j in v&g),F(0))/sum(mass[j] for j in v) for g in groups] for v in neigh]
        for K in (F(1,2),F(1),F(3)):
            local=[]; win=[]; rounding=F(0)
            for j,g in enumerate(groups):
                ds=[dem[i]*shares[i][j] for i in range(nr)]
                winner=[max(range(3),key=lambda k:shares[i][k]) for i in range(nr)]
                ws=[dem[i] if winner[i]==j else F(0) for i in range(nr)]
                dj=deficit(ds,neigh,mass,K,g); wj=deficit(ws,neigh,mass,K,g)
                correction=sum((max(ws[i]-ds[i],F(0)) for i in range(nr)),F(0))
                ck(wj<=dj+correction)
                ck(K*sum((mass[k] for k in g),F(0))+dj>=sum(ds))
                local.append(dj); win.append(wj); rounding+=correction
            ck(deficit(dem,neigh,mass,K)<=sum(local))
            ck(rounding==sum(dem[i]*(1-max(shares[i])) for i in range(nr)))
            ck(sum(win)<=sum(local)+rounding)

def tree(depth,seed):
    # Explicit dependent rational leaf law, depth at most 8.
    rng=random.Random(seed); nums=[rng.randrange(1,17) for _ in range(1<<depth)]
    leaves=[F(v,sum(nums)) for v in nums]; level=leaves; L=C=G=F(0)
    while len(level)>1:
        nxt=[]
        for i in range(0,len(level),2):
            a,b=level[i:i+2]; p=a+b
            L+=min(a,b); C+=a*b/p; G+=2*a*b
            ck(a*b/p<=min(a,b)<=2*a*b/p)
            nxt.append(p)
        level=nxt
    ck(G==1-sum(p*p for p in leaves)); ck(C<=L<=2*C)

def spectral():
    demands=[F(4),F(1),F(1)]
    canon=[[F(1,2),F(1,2),F(0),F(0)],[F(0),F(0),F(1,2),F(1,2)],[F(1,4)]*4]
    opt=[canon[0],canon[1],canon[1]]
    for rows,expect in ((canon,[F(9,4)]*2+[F(3,4)]*2),(opt,[F(2)]*2+[F(1)]*2)):
        b=[sum(d*row[j] for d,row in zip(demands,rows)) for j in range(4)]
        ck(b==expect)
        P=[[sum(d*row[i]*row[j] for d,row in zip(demands,rows))/b[i] for j in range(4)] for i in range(4)]
        for i in range(4):
            ck(sum(P[i])==1)
            for j in range(4): ck(b[i]*P[i][j]==b[j]*P[j][i])
        if rows is opt:
            for i in range(4): ck(sum(P[i][j]*b[j] for j in range(4))==b[i])
        else:
            ck(sum(P[0][2:])==F(1,18)); ck(sum(P[2][:2])==F(1,6))
            sig=sum(b[:2])/6; Q=sum(b[i]*sum(P[i][2:]) for i in range(2))/6
            ck(sig==F(3,4) and Q==F(1,24))
            ck(F(4)<=sum(d*sum(row[:2])**2 for d,row in zip(demands,rows))==F(17,4))
    ck(deficit([F(2),F(98)],[{0},{1}],[F(1),F(100)],F(1))==1)
    ck(F(2)>1/(1-F(1,100)))

def flux_constants(n):
    # Generic exact action, demand-error and boundary-CS algebra only.
    for M in (F(1,3),F(1),F(7)):
        for eps in (F(1,16),F(1,64),F(1,4096)):
            D=3*M
            needed=3*D*D/(n*M)
            ck(n*M/F(12)*needed==(D/2)**2)
            finite=12*(D/4)**2/(n*M*(1+2*eps))
            ck((D/M)**2==F(4,3)*n*(1+2*eps)*finite/M)
            width=4*eps; cs=1/width
            lower=F(1,2)*cs
            ck(lower==1/(8*eps))
            ck(2*lower==1/(8*(eps/2)))
    # Reference z-divergence polynomial chi=z_1^2: exact face-minus-volume.
    vol=F(1,12); face=F(1,4)+(n-1)*vol
    ck(face-n*vol==F(1,6))

def joint_energy(nr,ns,seed):
    rng=random.Random(seed)
    raw=[[F(rng.randrange(1,10)) for _ in range(ns)] for _ in range(nr)]
    total=sum(sum(r) for r in raw); joint=[[v/total for v in r] for r in raw]
    pi=[sum(r) for r in joint]; sigma=[sum(joint[i][j] for i in range(nr)) for j in range(ns)]
    P=[[sum(joint[i][j]*joint[k][j]/sigma[j] for j in range(ns))/pi[i] for k in range(nr)] for i in range(nr)]
    t=[F(i,2*nr) for i in range(nr)]
    E=sum(pi[i]*P[i][k]*(t[i]-t[k])**2 for i in range(nr) for k in range(nr))/2
    fibre=F(0)
    for j in range(ns):
        m=sum(joint[i][j]*t[i] for i in range(nr))/sigma[j]
        fibre+=sum(joint[i][j]*(t[i]-m)**2 for i in range(nr))
    ck(E==fibre)
    for i in range(nr):
        ck(sum(P[i])==1)
        for k in range(nr): ck(pi[i]*P[i][k]==pi[k]*P[k][i])
    blocks=[i%2 for i in range(nr)]
    cross=sum(pi[i]*P[i][k] for i in range(nr) for k in range(nr) if blocks[i]!=blocks[k])
    recross=1-sum(sum(joint[i][j] for i in range(nr) if blocks[i]==b)**2/sigma[j] for j in range(ns) for b in (0,1))
    ck(cross==recross)
    omega=max((abs(t[i]-t[k]) for i in range(nr) for k in range(nr) if blocks[i]==blocks[k]),default=F(0))
    ck(E<=(omega**2+F(1,2)**2*cross)/2)

def gamma(n):
    # Radial volume derivative and factorial integrals, no cubature.
    ck(F(n*factorial(n-1),factorial(n))==1)
    ck(F(factorial(n),factorial(n-1))==n)
    # c_n times score coefficient cancels exp(n) algebraically.
    ck(F(factorial(n),n**n)*F(2*n**n,factorial(n-1))==2*n)
    # Integration-by-parts coefficient at cutoff n for upper deviation.
    ck(F(factorial(n),factorial(n-1))*sum(F(n**k,factorial(k)) for k in range(n+1))-n*sum(F(n**k,factorial(k)) for k in range(n))==F(n**n,factorial(n-1)))

def cmul(a,b):
    return (a[0]*b[0]-a[1]*b[1],a[0]*b[1]+a[1]*b[0])

def independent_fourier(freq):
    # Convolve exact Fourier-exponential polynomials of sin(ar)/a.
    # Zero frequencies contribute powers of r. Integrate via Laplace recurrence.
    poly={F(0):(F(1),F(0))}; zeros=0
    for a in map(F,freq):
        if a==0: zeros+=1; continue
        nxt={}
        for w,z in poly.items():
            for shift,coef in ((a,(F(0),-F(1,2)/a)),(-a,(F(0),F(1,2)/a))):
                val=cmul(z,coef); key=w+shift; old=nxt.get(key,(F(0),F(0)))
                nxt[key]=(old[0]+val[0],old[1]+val[1])
        poly=nxt
    real=imag=F(0)
    for w,coef in poly.items():
        # Integral r^k e^(-(1-iw)r): recurrence I_k=k I_(k-1)/(1-iw).
        inverse=(1/(1+w*w),w/(1+w*w)); integral=inverse
        for k in range(1,zeros+1):
            val=cmul(integral,inverse); integral=(k*val[0],k*val[1])
        val=cmul(coef,integral); real+=val[0]; imag+=val[1]
    ck(imag==0)
    return real/factorial(len(freq))

def saved_gamma(root):
    obj=json.loads((root/'parent_gamma_results.json').read_text())
    ck(len(obj['records'])==460)
    counts={}
    for row in obj['records']:
        ck(row['n']==len(row['frequency']))
        v=independent_fourier(row['frequency']); ck(v==F(row['value']))
        if row['stage'] in ('normalization','pilot'): ck(v>0)
        counts[row['stage']]=counts.get(row['stage'],0)+1
    ck(counts==obj['counts'])

def verify_flow(rec,mass,rows,K):
    N=len(mass); J=len(rows); s=0; sink=1+J+N
    D=sum(r['d'] for r in rows); large=D+K*sum(mass)+1
    caps={(s,1+i):r['d'] for i,r in enumerate(rows)}
    for i,r in enumerate(rows):
        for j in range(N):
            if r['mask']>>j&1: caps[1+i,1+J+j]=large
    caps.update({(1+J+j,sink):K*p for j,p in enumerate(mass)})
    seenarcs={}; balances=[F(0)]*(sink+1)
    residual=[[] for _ in balances]
    for arc in rec['arcs']:
        u,v=arc['u'],arc['v']; c,f=F(arc['capacity']),F(arc['flow'])
        ck((u,v) not in seenarcs and caps.get((u,v))==c and 0<=f<=c)
        seenarcs[u,v]=c; balances[u]+=f; balances[v]-=f
        if f<c: residual[u].append(v)
        if f>0: residual[v].append(u)
    ck(seenarcs==caps)
    ck(balances==[D]+[F(0)]*(sink-1)+[-D])
    reached={s}; queue=[s]
    for u in queue:
        for v in residual[u]:
            if v not in reached: reached.add(v); queue.append(v)
    ck(sink not in reached)
    cut=sum(c for (u,v),c in caps.items() if u in reached and v not in reached)
    ck(cut==D==F(rec['value'])==F(rec['cut_capacity']))
    ck(sorted(reached)==rec['residual_source_side'])
    ck(rec['source_node']==s and rec['sink_node']==sink and rec['row_node_start']==1 and rec['source_bin_node_start']==1+J)

def cuts(mass,rows,saved):
    ck(len(saved)==(1<<len(mass))-1)
    best=F(0); maxim=[]
    for mask in range(1,1<<len(mass)):
        p=sum(mass[j] for j in range(len(mass)) if mask>>j&1)
        ids=[i for i,r in enumerate(rows) if not(r['mask']&~mask)]
        D=sum((rows[i]['d'] for i in ids),F(0)); density=D/p
        row=saved[mask-1]
        ck(row['mask']==mask and row['forced_rows']==ids)
        ck(F(row['mass'])==p and F(row['demand'])==D and F(row['density'])==density)
        if density>best: best=density; maxim=[mask]
        elif density==best: maxim.append(mask)
    union=0
    for mask in maxim: union|=mask
    return best,maxim,union

def moments(mass,rows,saved,I):
    result=F(0); D=sum(r['d'] for r in rows)
    ck(len(saved)==len(mass))
    colmass=F(0)
    for j,p in enumerate(mass):
        m=[F(0)]*3
        for r in rows:
            if r['mask']>>j&1:
                cap=sum(mass[k] for k in range(len(mass)) if r['mask']>>k&1)
                for q in range(3): m[q]+=r['d']*r['u']**q/cap
        b,a,c=m; v=c/b-(a/b)**2 if b else F(0)
        row=saved[j]
        ck(row['source']==j and [F(row[k]) for k in ('b','m1','m2')]==m)
        ck(F(row['variance_proxy'])==v>=0 and row['above_T']==(b>10))
        if b>10: result+=p*v
        colmass+=p*b
    ck(result==F(I) and colmass==D)

def saved_hall(root):
    obj=json.loads((root/'hall_results.json').read_text())
    ck(obj['schema']=='R88-public-neutral-principal-flow-v1')
    totals={'graphs':len(obj['graphs']),'principal_blocks':0,'whole_source_cuts':0,'residual_source_cuts':0,'flow_arcs':0,'scalar_bridge_records':len(obj['conditional_bridge_records'])}
    for case in obj['graphs']:
        ck('NONPHYSICAL' in case['scope'])
        p=list(map(F,case['source_masses']))
        rows=[{'mask':r['mask'],'d':F(r['d']),'u':F(r['u'])} for r in case['rows']]
        ck(all(r['d']>0 and 0<r['mask']<(1<<len(p)) for r in rows))
        best,maxim,union=cuts(p,rows,case['all_source_cuts'])
        ck(best==F(case['optimal_K']) and maxim==case['all_maximizers'] and union==case['union_all_maximizers'])
        verify_flow(case['optimal_flow'],p,rows,best)
        moments(p,rows,case['canonical_columns'],case['I_T_proxy'])
        ck(F(case['canonical_max'])==max(F(r['b']) for r in case['canonical_columns']))
        D=sum(r['d'] for r in rows)
        ck(F(case['total_D'])==D and F(case['W'])==sum(p) and F(case['D_over_W'])==D/sum(p))
        active=list(range(len(p))); remaining=list(range(len(rows))); prefix=[]; maskprefix=0; prev=None
        for block in case['principal_blocks']:
            ck(block['residual_compact_sources']==active)
            cr=[dict(rows[i],mask=sum(1<<j for j,k in enumerate(active) if rows[i]['mask']>>k&1)) for i in remaining]
            k,allmax,U=cuts([p[j] for j in active],cr,block['residual_cuts'])
            chosen=[remaining[j] for j,r in enumerate(cr) if not(r['mask']&~U)]
            sm=sum(1<<active[j] for j in range(len(active)) if U>>j&1)
            ck(k==F(block['density']) and allmax==block['residual_maximizer_masks'])
            ck(chosen==block['row_indices'] and sm==block['source_mask'])
            ck(prev is None or k<prev)
            bi=[j for j in active if sm>>j&1]
            br=[dict(rows[i],mask=sum(1<<j for j,k0 in enumerate(bi) if rows[i]['mask']>>k0&1)) for i in chosen]
            verify_flow(block['block_flow'],[p[j] for j in bi],br,k)
            prefix+=chosen; maskprefix|=sm; pr=block['principal_prefix']
            union0=0
            for i in prefix: union0|=rows[i]['mask']
            ck(union0==maskprefix==pr['source_mask']==pr['source_closure_mask'])
            ck(prefix==pr['row_indices'])
            mass=sum(p[j] for j in range(len(p)) if maskprefix>>j&1); d=sum(rows[i]['d'] for i in prefix)
            ck(F(pr['demand'])==d and F(pr['source_mass'])==mass and F(pr['v'])==d/mass and F(pr['D_over_W'])==d/sum(p))
            ck(F(pr['T'])==10 and 'NONPHYSICAL' in pr['qualification'])
            moments(p,[rows[i] for i in prefix],pr['canonical_columns'],pr['I_T_proxy'])
            active=[j for j in active if not(sm>>j&1)]; remaining=[i for i in remaining if i not in chosen]; prev=k
            totals['principal_blocks']+=1; totals['residual_source_cuts']+=len(block['residual_cuts']); totals['flow_arcs']+=len(block['block_flow']['arcs'])
        ck(not remaining and len(prefix)==len(rows) and len(set(prefix))==len(rows))
        totals['whole_source_cuts']+=len(case['all_source_cuts']); totals['flow_arcs']+=len(case['optimal_flow']['arcs'])
    for row in obj['conditional_bridge_records']:
        n=row['n']; T=F(row['T']); v=F(row['v']); R=F(row['R'])
        ck(T*T==24*n*R+96 and R>=0)
        res=(v-T)**2-24*n*R-48*v/T
        ck(res==F(row['quadratic_residual'])==F(row['factorized_residual'])==(v-2*T)*(v-48/T))
        ck(row['assumption_satisfied']==(v<=T or res<=0))
        ck(row['conclusion_v_le_twoT_if_assumption']==(v>T and res>0 or v<=2*T))
    ck(totals==obj['counts'])
    return totals

def main():
    started=time.perf_counter()
    for name,dims,sizes,depths in (
        ('pilot',(2,3,4),(2,3),(1,2)),
        ('pressure',(32,128,512),(4,5),(4,8)),
        ('expanded',(4096,65536),(6,8),(8,))):
        begin=COUNT
        for n in dims:
            for R in (F(0),F(1,16),F(1)): bridge(n,R)
            flux_constants(n)
        partitions(*sizes,seed=dims[0]+880611)
        joint_energy(*sizes,seed=dims[0]+880613)
        for d in depths: tree(d,d+880612)
        for d in (depths[0],depths[-1],32):
            # compressed uniform tree, no 2^32 enumeration
            ck(F(d,2)==sum(F(1,2) for _ in range(d)))
            ck(F(d,4)==sum(F(1,4) for _ in range(d)))
            ck(sum(F(1,2**(j+1)) for j in range(d))==1-F(1,2**d))
        common_law(dims[0],depths[-1]+1)
        for n in (dims[0],min(dims[-1],128)): gamma(n)
        STAGES[name]=COUNT-begin
    entropy_split(); spectral()
    ck((F(3,20)-F(5,104)-F(1,8))/18==F(-1,780))
    root=Path(__file__).resolve().parent
    for filename,digest in EXPECTED.items():
        ck(hashlib.sha256((root/filename).read_bytes()).hexdigest()==digest)
    data={'hall':saved_hall(root)}
    saved_gamma(root); data['gamma_records']=460
    # Final archive needs no individual author MD/TeX or private files.
    if (root/'proof.md').exists():
        text=(root/'proof.md').read_text()
        fences=re.findall(r'^```python\n(.*?)^```\s*$',text,re.M|re.S)
        ck(len(fences)==1)
        ck(fences[0].encode()==Path(__file__).read_bytes())
        tex=(root/'proof.tex.txt').read_text()
        for s in (text,tex): ck(not any(ord(c)<32 and c not in '\n\t' for c in s))
        data['archive_fence_identity']='PASS'
    print(json.dumps({'status':'PASS','assertions':COUNT,'stages':STAGES,
      'saved_data':data,
      'scope':'Independent exact scalar and NONPHYSICAL common-law/graph checks; no actual full-gate or dimension certificate.',
      'elapsed_seconds':time.perf_counter()-started},sort_keys=True))

if __name__=='__main__': main()
```
