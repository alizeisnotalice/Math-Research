# R395 complete-reference audit — FINAL PASS

FINAL PASS for the high-only mixed receiver reference, prefix-adaptive guaranteed improvement, explicit amplitude optimization and limited numerical evidence. No root source budget or new paid BH branch is certified. Only this audit file is edited. The independent screen below read R331 before the R395 author proof. All f, receiver E/R/q/m, J/A, physical clock and source fields stay frozen.

## The full-all upper reference and the low-clock question

Use the complete R331 feature phi_y(r,u,v)=c_u(y)c_v(y)/sqrt(J_y(r)) under xi=ell(dr)1_(u,v in E_r)mu(du)mu(dv), with zero rows zero, and let G=Phi f>=0. The actual nonnegative source integrand gives BH(f,nu)<=BH(f,f)<=B_all(f,f). Full matching yields

    B_all=X_q-E_all,
    E_all>=Q_all=||G||^2,
    ||G||^2<=X_q.

The E_all>=Q_all inequality follows by symmetry in the two full source variables and arithmetic-geometric mean of their reciprocal J denominators. A zero J row has A=0 and contributes zero. Consequently, for any actual Hilbert reference h,

    BH(f,nu)<=X_q-||G||^2
             <=X_q+||h||^2-2<h,G>.

Thus the proposed U_t is a legitimate FULL-ALL reference upper bound with no extra lambda H W completion fee. This uses BH<=B_all and X_q, not the a_H-Q_all route in R331 equation (1). The latter route has its own completion charge and must not be confused with this one. No old crossing or square credit is booked twice. A decrease of U is only a reference improvement; it does not prove that U itself is of root size or pay the remaining core.

## Capacity and support requirements

For ell-almost every r with positive |E_r|, S1_r(u,v)=m_u m_v/|E_r| has exact row marginal m_u under mu=dv/m_v. On a measurable local partition, the analogous within-block product kernel S0 is symmetric, saturated and zero between distinct blocks. Measurable r-dependent partitions are permitted if all their kernels/regions are jointly measurable. On a zero-volume prefix define both kernels zero. Null blocks are irrelevant to the actual pair measure; do not divide by their volume.

The off region must be a measurable pair region disjoint from the support of S0 (e.g. pairs from distinct local blocks). It is not an extra arbitrary source selector. This disjointness is essential for the claimed square-root estimate. A general saturated S0 that is nonzero on the alleged off region does not automatically give this exact two-region proof.

For global scalar t in [0,1], St=(1-t)S0+tS1 remains a symmetric saturated row-capacity kernel. Theta remains identically one, independent of r. The R331 bill is therefore

    ||h_i||^2=X_q-D_i,
    D_i=(1/4) integral xi S_i(sqrt(m_u)-sqrt(m_v))^2>=0.

The same holds prefixwise without ell. All quantities are finite. The actual inclusive physical tail, including its b atom, gives integral ell integral_(E_r) m_u du=X_q. No unrelated scale envelope or repeated prefix fee occurs.

## Independent decrease derivation

Define Cdiag=<h0,G> and Coff=<h1 1_off,G>, both nonnegative. On diag use sqrt(St)>=sqrt(1-t)sqrt(S0); on off, sqrt(St)=sqrt(t)sqrt(S1). Therefore

    <h_t,G>>=sqrt(1-t)Cdiag+sqrt(t)Coff.

One must NOT claim sqrt(a+b)>=sqrt(a)+sqrt(b) on the same diagonal region. The separate support regions, rather than such a false pointwise inequality, justify the estimate.

D_t=(1-t)D0+tD1, so ||h_t||^2-||h0||^2=t(D0-D1)<=tD0. Since 1-sqrt(1-t)<=t,

    U_t<=U0-2sqrt(t)Coff+t(2Cdiag+D0).

Cauchy-Schwarz and ||G||,||h_i||<=sqrt(X_q) give Cdiag,Coff<=X_q. Also D0<=X_q. When X_q>0 the proposed t=(Coff/(3X_q))^2 lies in [0,1/9], and

    U_t<=U0-Coff^2/(3X_q).

If X_q=0 the entire Hilbert space contribution is zero and t=0 is the convention. Coff=0 likewise gives t=0 and no asserted strict improvement. Strict decrease is guaranteed only when Coff>0.

## Prefix-adaptive strengthening

For the fiber at r put X(r)=integral_(E_r)m_u du. Matching and the same full-source zero-row argument yield ||G_r||^2<=X(r); norm references and all relevant C/D are bounded by the same X(r). These quantities are jointly measurable by positive integration of the fixed actual kernels and features. Define

    t(r)=[Coff(r)/(3X(r))]^2 when X(r)>0,
    t(r)=0 otherwise.

This only changes S_r. It does not silently change theta to a prefix-dependent function, so the exact capacity/tail bill is still legal. Applying the preceding estimate in every fiber and integrating gives the actual reference improvement

    integral ell Coff(r)^2/[3X(r)],

with 0/0=0. This is finite, at most X_q/3. Cauchy-Schwarz in the same physical ell measure, using integral ell X(r)=X_q, proves

    integral ell Coff(r)^2/[3X(r)]
      >=Coff_total^2/(3X_q).

All prefix/terminal atoms are retained. No number-of-prefixes multiplier is introduced. This is still a reference optimization, not a general geometric bound for Coff or for the residual reference price.

## Bounded local arithmetic

Reviewer actually ran 21 finite-reference Fraction/algebra checks on four-state saturated block/global kernels, with three mass lists including unequal perfect-square masses. Square roots were enclosed by explicit rational isqrt floors; the scalar t optimization identity was exact. Numerical cross-term comparisons allowed an explicitly stated rational rounding tolerance of 10^-25, so these are bounded diagnostics, not independent certification of the general inequality. The general conclusions above follow from the displayed analytic argument. The finite model was not declared an actual cube/full-hard field. No author R395 proof was read before this screen.

Independent-screen result: PASS with the full-all and off-support conventions above. The preferred final high-only proof and numerical integration review follow. No original general root bound or new source payment is certified.


## Independently checked sharper constant 2 (preferred)

The constant 3 above is valid but unnecessary. The same exact budget gives

    Cdiag<=sqrt[(X_q-D0)X_q],
    2Cdiag+D0<=2sqrt[X_q(X_q-D0)]+D0<=2X_q.

The last step uses 0<=D0<=X_q and (2X_q-D0)^2-4X_q(X_q-D0)=D0^2>=0, with both square-root sides nonnegative. Hence the preferred choice is

    t=(Coff/(2X_q))^2<=1/4,
    U_t<=U0-Coff^2/(2X_q).

The fiberwise version uses the identical inequality with X(r),D0(r). Its gain is integral ell Coff(r)^2/[2X(r)]>=Coff_total^2/(2X_q). This sharpens only the safely controlled scalar reference bound; it is not a new geometric receipt or a claim that 2 is optimal for every actual field. The weaker constant-3 derivation is retained above as the historical initial screen, not as the preferred final statement.


## Completed high-only author-proof review (preferred actual slot)

Read final r395_aux.md SHA d6b6b0110333b2ab861661e37c0ba32111b70b05336b2b30f2081771299b1650 and its entire check script. The author's strengthened construction uses the original high-source feature G_H, not the all-row reference of the initial independent screen. This is a valid stronger actual-slot formulation. The exact original identity is

    BH(f,f)=L_H-Q_H-R_cross-R_clock,

where the high/low crossing term is nonnegative and the high/high denominator-square term has exactly the displayed factor 1/2. All terms are finite: the original nonnegative high square is at most L_H<=X_q. Original zero-J rows are zero, and the physical clock retains its b atom.

Crucially U_t^H is DEFINED with both credits:

    U_t^H=L_H-R_*+||h_t||^2-2<h_t,G_H>
         =BH(f,f)+||h_t-G_H||^2.

If those credits were omitted, the last equality would be false. The actual final author definition includes them, so BH(f,nu)<=U_t^H and no completion fee is needed. The initial all-row route above remains a valid alternative but is not added to this preferred high-only formula. Q_H<=Q_all<=X_q and its fiberwise analogue justify all the same Gram-compatible scalar bounds.

The countable common partition and exact real-prefix saturated kernels are measurable; null-volume prefixes/blocks contribute zero. On a diagonal block S1/S0=v_j/V, giving the exact factor sqrt(1-t+t v_j/V). Off-block h_t=sqrt(t)h1. The full expression retains same-block fit and D1; its constant-t minimum exists by continuity and convexity. The guaranteed constant-2 decrease follows with the actual Gram constraint, not independently unconstrained C0,D0 scalars.

The explicit prefix choice t_*(r) is measurable, changes S_r only and leaves theta=1, source gates and original prefixes fixed. Its guaranteed integrated gain is finite and at least the constant-t GUARANTEE by weighted Cauchy-Schwarz. This does not imply the actual adaptive bound is smaller than every other constant-t actual bound. The author correctly retains min{U1,U[t_*]} and does not claim the explicit t_* is an exact optimizer. Positive C_off ensures a strict reference improvement, not a fixed paid fraction of BH or a general root fee.

Reviewer actually executed r395_aux_check.py: exit 0, 3423 Fraction checks, split 2304 scalar loss, 768 explicit gain, 288 prefix capacity, 36 norm bill, 27 adaptation. The scalar tests enforce a sufficient Gram-compatible C0. Their finite positive quadrature/prefix examples are not native all-source cube fixtures; the analytic proof supplies the continuum statement. Reviewer reruns are not new independent cases.

## Completed information-candidate review: no receipt

Read all of r395_geometry.md and r395_geometry_check.py. The disintegration is with the SAME old source Y of the actual core measure, not a new endpoint witness. Strict original past gives T_u>h and actual mass lower m_*>0. The projected edge density obeys g<=C1=lambda/(h m_*). For a positive edge both conditional source RN derivatives relative to pi_u or pi_v are <=C1/g. This yields finite integrated KL, bounded by integral g log(C1/g)<=C1|E|^2/e. It does not assume finite differential entropy of f.

The joint law normalized by G has a bounded density relative to the finite product of full-source probability f/W and the two uniform actual receiver measures. Therefore the required mutual informations and conditional chain rules are finite. The identity

    integral log(m_u/m_v) dgamma
      =D_out-D_in+I_out-I_in

and I_out-I_in=G[I(Y;V)-I(Y;U)] have no undefined infinity-minus-infinity. Zero rows or edges are omitted under their zero marginal. The bounded field/positive G conditions make these disintegrations legitimate on the actual Euclidean measurable spaces.

The retained middle-rank atomic prefix bound gives k_u(y)<=beta, hence D_out<=integral a log(beta/a)d(qdu)<=beta X_q/e. This is a receiver price only. Strict far mass gives sqrt(n)G<=mass-work, but the combination I_out-I_in-D_in remains unpriced. The source geometry/self-support conditions have not yet supplied the needed n-polylog W bound, so no old absorption allocation can be spent on the controlled term alone.

Reviewer actually executed the full information script: exit 0, 12 finite matched-incidence cases [4,4,4], with exact rational log identities represented by prime-factor coefficient vectors. No transcendental inequality is estimated by floats. These are finite rank diagnostics with a rational mass gap, not a native real-du realization of all old core/history/spatial gates. No new W receipt is certified.

Both frozen proof notes PASS within these limits. Final parent integration and numerical review are completed below.


## Independent prefix-amplitude optimization screen

For any saturated mixed shape h_t on a fixed prefix,

    N_r=||h_t(r)||^2
       =(X(r)+integral S_t sqrt(m_u m_v)dmu(u)dmu(v))/2,

hence X(r)/2<=N_r<=X(r). Put C_r=<h_t(r),G_H(r)> and a_r=C_r/N_r when N_r>0, zero otherwise. Both are measurable, C_r>=0 and C_r^2<=N_r Q_H(r), so a_r<=sqrt(2) and integral ell a_r^2 N_r<=Q_H<=X_q. A zero-N_r prefix is a zero-X(r) prefix and contributes nothing.

This is an arbitrary Hilbert reference a(r)h_t, not an invocation of the R331 prefix-INDEPENDENT theta signed-potential identity with a forbidden variable theta_r. The direct square proves

    U_amp=L_H-R_*-integral ell C_r^2/N_r
         =BH(f,f)+||a(r)h_t-G_H||^2.

It is <=the zero reference L_H-R_* and <=the same theta=1 reference U_t, whose difference from it is integral ell (N_r-C_r)^2/N_r>=0. Thus the mixed shape's guaranteed cross improvement relative to UNOPTIMIZED U0 is inherited. It must not be restated as an equal-sized improvement relative to an already amplitude-optimized local reference without another proof. No root bound follows merely from this amplitude minimization.

Reviewer ran 126 exact Fraction scalar assertions of feasibility and the displayed amplitude-gap identity under the required Cauchy-Schwarz constraint. These finite scalar checks are separate from the author's field diagnostics and do not realize original receiver/source geometry. The author amplitude addendum and final numeric/main bindings are reviewed below; approval remains limited to the displayed reference algebra and evidence scope.


## Author amplitude addendum verified

Read final auxiliary §3b (proof SHA 13882cb68f0f396c0291b6812f0fcf49fb81c50b74c83be5cdead1552366e6cc) and the entire updated script. It implements the independently screened amplitude exactly, keeps U_opt[t_*]<=U0-I_mix relative to the unoptimized baseline only, and retains min of separately optimized local/global/adaptive candidates rather than claiming a false ordering. There is no extra receiver-potential certificate or completion fee.

Reviewer actually reran the updated auxiliary script: 3459 Fraction grouped checks PASS, including 36 amplitude cases. The previous 3423 are its unchanged subset, not an additional independent count. The 12 information cases and the reviewer's own 21 rounded-reference/126 exact amplitude diagnostics remain separately scoped. The completed final main/ledger/numerical-note review and bindings follow.


## Final real-interval numerical audit

Read all final r395_numeric.py, result JSON and numerical note. The final code uses a normal mpmath import; it no longer embeds this machine's vendor path. One initial bare-default-Python attempt failed with ModuleNotFoundError for mpmath and is NOT counted as a passed test. Reviewer then supplied the documented existing vendor via PYTHONPATH and actually ran the final script successfully: exit 0, 1652 Fraction assertions plus 1780 ordinary mpmath diagnostics over eight fields. The generated result bytes agree with the final bound hash. Dependency mpmath 1.3.0 and the local reproduction environment are explicitly stated in the note/readme; the script is not claimed to be standard-library-only.

The geometric fixture is truly Lebesgue, not receiver point quadrature. Disjoint actual receiver intervals have positive widths; every source packet has positive volume and a constant explicitly assigned density. Exact endpoint tests prove that a packet is fully captured or completely missed throughout a receiver interval. Thus m, q, mu, J, A and all source/receiver products are constant on the relevant actual blocks, making the finite sums exact integrations of this particular field. The same complete f matches q=m/R in [3/4,1]. Full W, X_q and actual receiver widths are retained.

For radii 1 and 2 the earlier weight 1/2 is the exact integral of r^(-2) on [1,2), while the last weight 1/2 is the genuine terminal atom at b=2. For single-radius fields the complete tail is retained as well. Original source high/low classification uses exact rational J and H. Positive source packets with low J are not discarded from the full source; they appear in the ordered R_cross. G_H, Q_H and the high/high reciprocal-square R_clock are computed on the same prefix and source masses. Unequal masses produce a genuinely nonzero clock credit. The exact B=L-E and actual capacity identities are Fraction-tested; radicals/Gram and credit recombinations are ordinary multiple-precision diagnostics, not rigorous interval certificates.

The mixed shape uses the full diagonal formula sqrt(1-t+t v_j/V), off-block sqrt(t), and the exact norm price. Explicit constant-2 t and prefix-adaptive t are checked with the true cross coefficient. The amplitude variant uses the direct Hilbert projection and full norm integral. Every optimized candidate is compared with BH and the zero-reference baseline; the script does not claim that actual adaptive U always beats every fixed-t candidate. Its empirical ordering is reported only for these cases. The safe improvement remains referenced to UNOPTIMIZED local U0, not an already amplitude-fitted baseline.

The disjoint Coff=0 fixture correctly yields no guaranteed mixing improvement; full mixing can worsen its unscaled reference. The common-packet fixture is matched exactly by the full-prefix reference. The mixed_equal case has positive original BH=0.075, optimized local about 0.13225768 and adaptive about 0.12869708, retaining a nonzero gap about 0.05369708. Chain14 retains an even larger absolute gap. Tiny near-zero multiple-precision residuals (such as the separated optimized value about 3.45e-77) are numerical rounding, not a strictly positive exact theorem. None of these eight n=1 fields certifies synchronized high-past/historical selector/core qualifications, a near-extremizer, or a dimension-rate estimate.

The 40/75-digit cross-comparison uses tolerances and printed values; its very small output difference is a stability diagnostic, not an error enclosure. The note states this explicitly. The earlier 1652-mp version is superseded, not an additional experiment. Final author execution counts are 3459 Fraction auxiliary, 12 rational-log cases, 1652 Fraction field checks, and 1780 ordinary MP diagnostics, each once. Reviewer reruns repeat those same cases and are not added. Reviewer-only scalar checks remain separately scoped.

## Final main/readme and unchanged ledger

Read final r395_main.md and r395_readme.md. They keep the original high-only square, both original nonnegative credits and the exact physical clock. They distinguish a reference approximation improvement from a newly paid subset of original traffic, require Coff>0 for a strict guaranteed decrease, and retain the zero-reference/amplitude comparisons so a poor local baseline cannot be mistaken for a global budget advance. No uniform positive coverage fraction is asserted.

The information candidate's row term is only an X_q estimate, while the joint information balance is still unpriced. No infinity-minus-infinity or external-source cancellation is used to manufacture a W receipt. No infinite-dimensional strong duality, extremizer stability theorem, arbitrary source independence or coordinate-product hypothesis is invoked.

The complete r392 ledger is unchanged. A future source bound for this WHOLE BH reference would replace that whole old BH slot; it cannot be stacked with its old internal fees or spend Q_H/R_cross/R_clock a second time against the G_core route. All entrance, H, soft/crossing, scale, history and terminal-atom obligations remain. FINAL PASS is limited to the exact reference family, its proved decrease/projection and the honest finite evidence. The desired general root comparison of the remaining full-source cost is unproved.

## Frozen SHA256 bindings

Final files below are bound to the bytes reviewed. Earlier proof hashes in the review narrative identify intermediate stages only; these final bindings are authoritative. Historical dependencies are inherited context, not a re-audit of the entire prior reduction.

- `/tmp/r395_main.md`: `5feec2bdf23552c48300654287dda9d634aa8c35dd60f00a068ec6ab891960f8`
- `/tmp/r395_readme.md`: `ede2bda7e235226d6723b50eb4ac76c71917b3cc9d74891e851eb6fe09562572`
- `/tmp/r395_aux.md`: `13882cb68f0f396c0291b6812f0fcf49fb81c50b74c83be5cdead1552366e6cc`
- `/tmp/r395_aux_check.py`: `4a0c6ae98caa45b21fb809e4406a7ab866dc971bee98432de7aceb751c4609dc`
- `/tmp/r395_geometry.md`: `4ada415929ab917cce709d553072780d40f2142cb116462fb7c560f244c68518`
- `/tmp/r395_geometry_check.py`: `4e6021d3da1ef423c5d60364232db4306b666f759bcfbec15ca6766f0e0ad21b`
- `/tmp/r395_numeric.md`: `757849ebccead69bdd91c80587f4a57fa853e2dff082f3e21d239e41fe3226fb`
- `/tmp/r395_numeric.py`: `eedb08dddd0d9df919b5e15ea5f2dc496c4fd7d71a429b10413c5baffbf56bbc`
- `/tmp/r395_numeric.result.json`: `81309492d2a6a847cd9064d106531597c550b8d609d2024b84c95e2ee3486600`
- `/tmp/r392_ledger.md`: `4031079b6dcb0660da0460e316c19e4d71ff2dff055ba616aa41a4d376cc79f1`
- `/tmp/r331_core.md`: `1858c2eb422b64acc9796a53cbbac30efbe6be1fd58a9786f84ced40b9f9c227`
- `/tmp/r329_core.md`: `a0839511190d64279c89a81b819f5cad8d68d774edbffdf5c48726dc62affacc`

Final freeze clarification: the actually reviewed numeric.py (eedb08...) already contains the explicit amplitude-gap accumulation and close identity. No numerical code or counts were changed for the parent's transient stale-version concern. The final main additionally records that per-model billing data were unavailable, with no mathematical change.
