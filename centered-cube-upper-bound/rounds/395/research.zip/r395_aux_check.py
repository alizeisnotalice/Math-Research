from fractions import Fraction as F
from itertools import product

cnt={'scalar_loss':0,'explicit_gain':0,'prefix_capacity':0,'norm_bill':0}
for X in (F(1),F(3,2),F(7,3)):
    for c0,co,d0,d1 in product((F(0),F(1,4),F(1,2),F(1)),repeat=4):
        C0,Co,D0,D1=[X*z for z in (c0,co,d0,d1)]
        for st,sc in ((F(3,5),F(4,5)),(F(5,13),F(12,13)),(F(8,17),F(15,17))):
            t=st*st
            assert st*st+sc*sc==1
            fine=-2*st*Co+2*(1-sc)*C0+t*(D0-D1)
            coarse=-2*st*Co+t*(2*C0+D0)
            assert fine<=coarse
            cnt['scalar_loss']+=1
        # Enforce a sufficient Gram-compatible C0 bound for the constant-2 receipt.
        Csafe=min(C0,X-D0)
        assert Csafe*Csafe<=(X-D0)*X
        root=Co/(2*X); t=root*root
        guaranteed=2*root*Co-t*(2*Csafe+D0)
        assert guaranteed>=Co*Co/(2*X)
        cnt['explicit_gain']+=1

# n=2, exact original ell tail on finitely many receiver radii;
# positive receiver quadrature only, not a continuum fixture.
for N in (3,4,5):
    for offset in range(3):
        radii=[(F(1),F(3,2),F(2))[(i+offset)%3] for i in range(N)]
        mass=[r*r for r in radii] # q=1, sqrt(m)=R
        dw=[F(i+1,7) for i in range(N)]
        mu=[dw[i]/mass[i] for i in range(N)]
        X=sum(dw)
        levels=sorted(set(radii))
        for t in (F(0),F(1,9),F(1,2),F(1)):
            norm=D=F(0)
            for k,r in enumerate(levels):
                ell=1/(r*r)-(1/(levels[k+1]**2) if k+1<len(levels) else 0)
                active=[i for i in range(N) if radii[i]<=r]
                V=sum(dw[i] for i in active)
                vb={j:sum(dw[i] for i in active if i%2==j) for j in (0,1)}
                S={}
                for i in active:
                    for j in active:
                        S0=mass[i]*mass[j]/vb[i%2] if i%2==j%2 else F(0)
                        S1=mass[i]*mass[j]/V
                        S[i,j]=(1-t)*S0+t*S1
                        norm+=ell*mu[i]*mu[j]*S[i,j]*(radii[i]+radii[j])**2/4
                        D+=ell*mu[i]*mu[j]*S[i,j]*(radii[i]-radii[j])**2/4
                for i in active:
                    assert sum(S[i,j]*mu[j] for j in active)==mass[i]
                    cnt['prefix_capacity']+=1
            assert norm+D==X
            cnt['norm_bill']+=1
cnt['prefix_adaptation']=0
for ratios in product((F(0),F(1,4),F(3,4)),repeat=3):
    ell=(F(1,3),F(2,5),F(3,7)); Xs=(F(1,2),F(2),F(7,3))
    Cs=[x*r for x,r in zip(Xs,ratios)]
    gain=sum(e*c*c/(2*x) for e,c,x in zip(ell,Cs,Xs))
    C=sum(e*c for e,c in zip(ell,Cs)); X=sum(e*x for e,x in zip(ell,Xs))
    assert gain>=C*C/(2*X)
    cnt['prefix_adaptation']+=1
cnt['amplitude']=0
for X in (F(1),F(3,2),F(7,3)):
    for k in (F(3,4),F(4,5),F(1)):
        N=X*k*k
        for r in (F(0),F(1,3),F(2,3),F(1)):
            C=r*X*k
            assert X/2<=N<=X and C*C<=N*X
            amp=C/N
            assert 0<=amp and amp*amp<=2
            old=N-2*C; new=amp*amp*N-2*amp*C
            assert new==-C*C/N and old-new==(N-C)**2/N
            assert new<=min(old,F(0))
            cnt['amplitude']+=1
print('PASS',cnt,'total',sum(cnt.values()))
