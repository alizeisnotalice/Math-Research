from fractions import Fraction as F
from collections import defaultdict

def factors(n):
    ans={}; p=2
    while p*p<=n:
        while n%p==0:
            ans[p]=ans.get(p,0)+1; n//=p
        p+=1
    if n>1: ans[n]=ans.get(n,0)+1
    return ans

def addlog(d,w,x):
    assert x>0
    for p,e in factors(x.numerator).items(): d[p]+=w*e
    for p,e in factors(x.denominator).items(): d[p]-=w*e

def equal(*terms):
    d=defaultdict(F)
    for sign,a in terms:
        for p,x in a.items(): d[p]+=sign*x
    assert all(x==0 for x in d.values())

counts=[]
for n in (5,7,9):
    count=0
    for seed in range(4):
        f=[F(1+(y+seed)%3) for y in range(n)]
        m=[sum(f[:i+2]) for i in range(n-1)]
        mu=[F(1,1+(i+seed)%3) for i in range(n-1)]
        sigma=[m[i]*mu[i] for i in range(n-1)]
        T={(y,i):sum(mu[w] for w in range(n-1) if y<w+2 and m[w]<=m[i]) for y in range(n) for i in range(n-1)}
        G=defaultdict(F)
        for y in range(n):
            for u in range(n-1):
                for v in range(n-1):
                    if y>=min(u,v)+2: continue
                    if not (m[u]>F(3,2)*m[v] and F(1,10)*T[y,u]<T[y,v]<F(3,4)*T[y,u]): continue
                    chi=F(1+(u+v+y+seed)%4,4)
                    G[y,u,v]=f[y]*mu[u]*mu[v]*chi/T[y,u]
        assert G
        edge=defaultdict(F); out=defaultdict(F); inc=defaultdict(F)
        oy=defaultdict(F); iy=defaultdict(F); sy=defaultdict(F)
        for (y,u,v),w in G.items():
            edge[u,v]+=w; out[u]+=w; inc[v]+=w; oy[y,u]+=w; iy[y,v]+=w; sy[y]+=w
        total=sum(G.values())
        work=defaultdict(F); dout=defaultdict(F); din=defaultdict(F)
        io=defaultdict(F); ii=defaultdict(F); iyv=defaultdict(F); iyu=defaultdict(F)
        for (u,v),w in edge.items(): addlog(work,w,m[u]/m[v])
        for (y,u),w in oy.items():
            addlog(dout,w,w*m[u]/(out[u]*f[y]))
            addlog(iyu,w,w*total/(sy[y]*out[u]))
            assert w/(sigma[u]*f[y]/m[u])<=F(3,4)
        for (y,v),w in iy.items():
            addlog(din,w,w*m[v]/(inc[v]*f[y]))
            addlog(iyv,w,w*total/(sy[y]*inc[v]))
        for (y,u,v),w in G.items():
            addlog(io,w,(w/edge[u,v])/(oy[y,u]/out[u]))
            addlog(ii,w,(w/edge[u,v])/(iy[y,v]/inc[v]))
        equal((1,work),(-1,dout),(1,din),(-1,io),(1,ii))
        equal((1,io),(-1,ii),(-1,iyv),(1,iyu))
        count+=1
    counts.append(count)
print('PASS exact rational-log identities; stages',counts,'total',sum(counts))
