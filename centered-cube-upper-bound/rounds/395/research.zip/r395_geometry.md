# R395 — one logarithmic mass-work candidate; no new payment

**Outcome.** No root-order budget for the actual R391 core has been proved. The single candidate below has an exact finite-information decomposition and a controlled row term, but its genuinely joint information term remains unpriced. The R391 core coefficient and all existing fees are unchanged. This is a bounded screening result, not an attack breakthrough.

## Candidate and actual measure

Keep the original fully marked core measure

\[
 d\Gamma(y,u,v)=f(y)\frac{q_u\chi_{\rm core}(y,u,v)}{T_y(m_u)}
 c_u(y)c_v(y)\,dy\,\mu(du)\mu(dv),\qquad
 \gamma=\Gamma(E_y,du,dv),\quad G=G_{\rm core}.
\]

Every old clock, history, target, spatial, rank and core mark remains in χ. On its support `m_u>K m_v`, with `log K=√n`, and `T_y(m_u)>h`. Write `σ=qdu`, `π_u=f c_u dy/m_u` and `β=(1+d)^{-1}`.

The proposed intermediate geometric bound was

\[
 \mathcal W:=\int\log(m_u/m_v)\,d\gamma\ \lesssim\ n\log^A(n+2)W
 \quad\text{up to an explicitly small }\sqrt n X_q\text{ term}. \tag{1}
\]

Indeed `√n G≤𝓦`. The purpose was to use the exact posterior ratio on the same original shared source, rather than substitute an external witness. The issue is whether contributions from different edges can be settled jointly. The derivation below identifies the exact remaining obstruction; (1) itself is not proved.

## Exact joint-source identity and finiteness

Assume G>0; otherwise there is no remaining cost. Disintegrate Γ over its endpoint projection γ and write `r_uv` for the resulting conditional source probability. Its support is in `Q_u∩Q_v`. Thus

\[
 \log\frac{d\pi_v}{d\pi_u}(y)=\log\frac{m_u}{m_v}
 \quad r_{uv}\text{-a.e.}
\]

and consequently

\[
 \operatorname{KL}(r_{uv}\Vert\pi_u)
 -\operatorname{KL}(r_{uv}\Vert\pi_v)=\log(m_u/m_v).             \tag{2}
\]

These quantities can safely be integrated here. To see this without assuming an entropy bound on f, put `m_*=q_-a^n>0` and let `g(u,v)` be the density of γ relative to `du dv`. Then

\[
 0\le g(u,v)\le C_1:=\lambda/(h m_*),\qquad
 \frac{dr_{uv}}{d\pi_u},\frac{dr_{uv}}{d\pi_v}
 \le C_1/g(u,v)
\]

on edges with positive density. Hence both integrated KL terms in (2) are finite, bounded above by
`∫g log(C_1/g)du dv≤C_1|E|²/e`. This is only a finiteness bound, not a useful source price.

Let `a(u)=dγ_out/dσ` and `b(v)=dγ_in/dσ`. Denote the row and column conditional source laws by `p_u^out` and `p_v^in`. Define unnormalized conditional entropies

\[
 D_{\rm out}=\int\operatorname{KL}(p_u^{\rm out}\Vert\pi_u)\,d\gamma_{\rm out},
 \qquad
 D_{\rm in}=\int\operatorname{KL}(p_v^{\rm in}\Vert\pi_v)\,d\gamma_{\rm in}.
\]

Under the probability law Γ/G, let

\[
 I_{\rm out}=G I(Y;V\mid U),\qquad I_{\rm in}=G I(Y;U\mid V).
\]

The conditional relative-entropy decomposition of the two finite terms in (2) proves

\[
 \boxed{\mathcal W=D_{\rm out}-D_{\rm in}+I_{\rm out}-I_{\rm in}.} \tag{3}
\]

The information terms are finite as well. For example Γ/G has bounded density relative to
`(f(y)dy/W)⊗(du/|E|)⊗(dv/|E|)`, bounded by
`λW|E|²/(h m_*²G)`. The finite joint relative entropy controls the needed mutual informations. Ordinary finite chain rules therefore also give

\[
 I_{\rm out}-I_{\rm in}=G[I(Y;V)-I(Y;U)].                        \tag{4}
\]

There is no formal `∞−∞` cancellation and no use of separate differential entropies of f. Equations (2)–(4) concern the original source Y throughout.

## The row term has an actual receiver-volume price

The exact outgoing source measure is

\[
 d\Gamma_{Y,U}=\sigma(du)\pi_u(dy)k_u(y),\qquad
 k_u(y)=\frac1{T_y(m_u)}\int\chi_{\rm core}(y,u,v)c_v(y)\mu(dv).
\]

The retained middle-rank condition `T_y(m_v)<βT_y(m_u)` gives `0≤k_u(y)≤β`, including mass atoms: the occupation of that strict rank prefix is at most `βT_y(m_u)`. All further marks only decrease it. Therefore `a(u)=π_u k_u≤β` and

\[
 D_{\rm out}=\int\sigma(du)\int\pi_u(dy)k_u(y)\log[k_u(y)/a(u)]
 \le\int a(u)\log[\beta/a(u)]\,\sigma(du)
 \le\frac\beta e X_q.                                         \tag{5}
\]

Zero rows contribute zero. Combining (3)–(5), without spending any previous negative square, gives the valid but incomplete bound

\[
 \boxed{\sqrt n\,G_{\rm core}
 \le\int a\log(\beta/a)d\sigma-D_{\rm in}+I_{\rm out}-I_{\rm in}
 \le(\beta/e)X_q-D_{\rm in}+I_{\rm out}-I_{\rm in}.}              \tag{6}
\]

Thus the controlled term alone contributes at most `β/(e√n) X_q`. It is not an additional recorded absorption: the information balance in the same inequality remains unpaid, and the old epsilon allocation is frozen.

The precise still-unproved property for this candidate is an `O(n log^A(n+2) W)` upper bound on

\[
 I_{\rm out}-I_{\rm in}-D_{\rm in},                             \tag{7}
\]

using the original spatial gates and the self-supported two-endpoint occupancy of R391. The identity itself has not exploited those spatial/self-support hypotheses; that is exactly the missing geometric step. Conditional information measures repeated source distinctions between endpoint fibers, but neither the L4 bound on Lebesgue occupancy nor strict-far finite height bounds its difference by nW. Giving it a new name does not settle it.

Were (7) proved, (6) would yield a root source coefficient plus the displayed X_q coefficient; small dimensions could separately use the elementary bound `G≤λβ J_max W`. No such conditional result is entered in the ledger. In particular the original entrance coefficient `4Λ G_core` remains: substituting (6) would also multiply its entire unpaid information balance by `4Λ/√n`.

## Executed check and bounded stop

Executed `python3 /tmp/r395_geometry_check.py`:

    PASS exact rational-log identities; stages [4, 4, 4] total 12

The script uses standard-library Fraction and represents logarithms of positive rationals by their exact prime-factor coefficient vectors. It verifies (3), (4), and the pointwise `k≤β` in 12 finite matched-incidence fields. The diagnostic retains a rational strict mass ratio and actual atomic rank restrictions. Its receiver masses/weights are finite algebraic data, not native du or a realization of all core/history/spatial gates; it is not evidence for (7). No numerical inequality for transcendental logs is used as proof.

Only this note and its same-prefix check script were written. No further information-theoretic route or counterexample search is pursued. Work stops with no new general payment.
