# R395 bounded real-field numerical evidence

Frozen scope: eight **real positive-volume one-dimensional Lebesgue receiver fields**, with compact positive-volume source packets and f=β=ν. This is not receiver point quadrature. Every source-packet × receiver-interval capture is constant, checked by exact endpoints. The actual hard kernel has s=0, L=R, m=∫f c, q=m/R∈[3/4,1], λ=1. Disjoint receiver intervals, full source mass W, and every physical prefix are retained. Historical selector/FIRST-crossing qualifications, original high-past gates and general root bounds are not certified.

The script independently constructs all geometry. Source packets have halfwidth 1/20; the initial common packet is also small enough for every selected cube. Receiver radii are 1 or 2. For mixed-radius fields the compressed prefix weight 1/2 at R=1 is the integral of r^-2 dr over [1,2), not a new clock atom; the final R=2 weight 1/2 is the genuine terminal atom.

For each H>0 the **main** reference uses G_H=Σ_z f_z 1{J_z≥H}c_uz c_vz/√J_z. It keeps the complete original high-only common-source square Q_H. The script checks

BH=L_H−Q_H−Rcross−Rclock,

with Rcross the high/low ordered square and Rclock the high/high reciprocal-square mismatch. Both are retained in every candidate bound. In particular unequal masses generate nonzero Rclock; mixed_equal has Rcross=1/80 and mixed_mass has both corrections positive. There is no λHW completion in this high-only formulation.

S0 is saturated within a fixed spatial receiver partition; S1 is saturated on the whole prefix; both exact row capacities are checked. θ=1. For the mixture h_t, the complete bound is U_t=L_H+||h_t||²−2〈h_t,G_H〉−Rcross−Rclock=BH+||h_t−G_H||². Tests include the exact diagonal/off-block cross-term formula, norm X−D_t, constant-2 safe parameter t=(Coff/(2Xq))², and prefix-adaptive t_r=(Coff_r/(2Xr))². Their guaranteed gains are Coff²/(2Xq) and Σell Coff_r²/(2Xr), respectively. The latter is checked ≥ the former; this does not assert an ordering of actual selected U values.

The additional amplitude optimization a_r=C_r/N_r is a direct Hilbert-square reference optimization, not an invocation of the old common-θ signed-ψ formula. It checks N_r≥Xr/2, a_r≤√2 and U_t−Uopt_t=Σell(N_r−C_r)²/N_r. Uopt_t=L_H−Rcross−Rclock−Σell C_r²/N_r is checked between BH and the zero-reference bound Uzero=L_H−Rcross−Rclock. No safe-gain claim relative to **optimized** local Uopt0 is inferred.

Three stages: initial common four-block and separated Coff=0 fields; stress three overlapping two-radius fields with mixed high/low J, unequal masses or widths; expanded chains with 6, 10 and 14 source packets and 11, 19 and 27 positive receiver intervals. Initial H values are 1/10 and 1/20; stress H=1/8,1/8,1/10; chains H=1/20. These are diagnostic thresholds, not a synchronized original proof budget.

| Field | actual BH | Uzero | U0 | opt0 | optadaptive | opt1 | Xq/W |
|---|---:|---:|---:|---:|---:|---:|---:|
| common4 | 0 | 0.2 | 0.2 | 0.15 | 0.086252065 | 0 | 0.2 |
| disjoint_zero_off | 0 | 0.2 | 0 | 3.45446742e-77 | 3.45446742e-77 | 0.1 | 0.1 |
| mixed_equal | 0.075 | 0.2875 | 0.287238032 | 0.132257682 | 0.128697081 | 0.154650892 | 0.125 |
| mixed_mass | 0.0684339731 | 0.2697967 | 0.269710231 | 0.125758717 | 0.121850556 | 0.143048031 | 0.127586207 |
| mixed_width | 0.054187809 | 0.286503031 | 0.145533452 | 0.108527968 | 0.106509281 | 0.139464126 | 0.107886905 |
| chain6 | 0.0787137862 | 0.481036654 | 0.367542495 | 0.298357263 | 0.29788313 | 0.373370181 | 0.0916666667 |
| chain10 | 0.143109391 | 0.83098107 | 0.63136088 | 0.513672662 | 0.512848012 | 0.718586125 | 0.095 |
| chain14 | 0.207504995 | 1.18092549 | 0.904700018 | 0.73450406 | 0.733635514 | 1.06658487 | 0.0964285714 |

The common four-block field reaches BH=0 with the full-prefix reference t=1; its local reference loses off-block square. The separated field has Coff=0, safe t=0, and global t=1 worsens the bound. Mixed_equal gives a genuine positive original BH=.075: unscaled adaptive U falls from .2872380317 to .2815904726, while amplitude optimization gives .1322576823→.1286970809. The remaining gap .0536970809 is substantial. Thus the full bound really improves, but most improvement over the raw reference comes from amplitude fitting, and mixing is not a general budget closure. For chain14 the optimized improvement is only .000868546375, with BH=.2075049950 and bound .7336355141. No dimension-rate inference follows from these low-dimensional fields.

The JSON records all actual gains, guaranteed gains, X/W, BH/X, Rcross/Rclock, and the empirical adaptive/global ordering. The best unscaled value means min(Uzero,U1,Uadaptive); the best amplitude value includes optimized local/global/adaptive/full-prefix references. Trivial BH≤Xq is independently checked in Fraction. These benchmarks prevent treating improvement over a poor U0 as an improvement over every available reference.

Reproduce with:

```sh
PYTHONPATH=/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor \
/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 r395_numeric.py
```

Dependencies: Python standard library plus mpmath 1.3.0 (`python -m pip install mpmath==1.3.0` in a chosen environment). The script uses a normal mpmath import. The command above supplies this computer’s existing vendor through PYTHONPATH; an ordinary installation needs no PYTHONPATH. The third-party vendor tree is not copied. Outputs are beside the script, with no old /tmp imports.

Actual fresh runs: **1652 exact Fraction assertions** (geometry, matching, prefix algebra, saturated capacities and BH≤Xq), separately **1780 ordinary mpmath diagnostic assertions** across 40 and 75 digits, including accuracy comparisons. These are not interval certificates for radical computations. All printed 27-digit values agree across the two precisions; recorded maximum printed-output difference is 2.8698593e-41. No optimizer or sampling was used.
