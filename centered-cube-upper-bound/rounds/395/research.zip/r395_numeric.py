"""R395 real interval fields; Fraction geometry and ordinary mpmath diagnostics."""
from fractions import Fraction as F
from pathlib import Path
import json
import mpmath as mp
COUNT={'exact_fraction':0,'mp_diagnostic':0}
def ck(x):
 COUNT['exact_fraction']+=1
 assert x
def q(x): return mp.mpf(x.numerator)/x.denominator if isinstance(x,F) else mp.mpf(x)
def close(a,b):
 COUNT['mp_diagnostic']+=1
 assert abs(a-b)<mp.mpf('1e-32')*max(1,abs(a),abs(b)),(a,b)
def le(a,b):
 COUNT['mp_diagnostic']+=1
 assert a<=b+mp.mpf('1e-32')*max(1,abs(a),abs(b)),(a,b)
def models():
 # (center,mass) source packets have common halfwidth 1/20.
 out=[]
 out.append(('initial','common4',[(0,F(1))],[(F(c,10),F(1,20),F(1),i) for i,c in enumerate([-3,-1,1,3])],F(1,10)))
 out.append(('initial','disjoint_zero_off',[(0,F(1)),(3,F(1))],[(F(c),F(1,10),F(1),i) for i,c in enumerate([0,3])],F(1,20)))
 for name,masses,widths,H in [('mixed_equal',[F(1)]*4,[F(1,10)]*5,F(1,8)),('mixed_mass',[F(3,4),F(1),F(7,8),F(1)],[F(1,10)]*5,F(1,8)),('mixed_width',[F(1),F(3,4),F(1),F(3,4)],[F(1,20),F(1,8),F(1,12),F(1,10),F(1,16)],F(1,10))]:
  centers=[F(0),F(1),F(-1,2),F(1,2),F(3,2)]
  rec=[(c,widths[i],F(1 if i<2 else 2),int(c>=F(1,2))) for i,c in enumerate(centers)]
  out.append(('stress',name,list(zip([-1,0,1,2],masses)),rec,H))
 for N in [6,10,14]:
  src=[(i,F(3+(i%2),4)) for i in range(N)]
  rec=[(F(i),F(1,20),F(1),i//3) for i in range(N)]
  rec +=[(F(2*i+1,2),F(1,20),F(2),i//3) for i in range(N-1)]
  out.append(('expanded','chain'+str(N),src,rec,F(1,20)))
 return out

def prepare(model):
 stage,name,src,rec,H=model; delta=F(1,20); ns=len(src); nr=len(rec)
 C=[]
 for x,w,R,b in rec:
  row=[]
  for y,m in src:
   inside=abs(x-F(y))+w/2+delta<=R/2
   outside=abs(x-F(y))-w/2-delta>=R/2
   ck(inside or outside); row.append(int(inside))
  C.append(row)
 for i in range(nr):
  for j in range(i): ck(abs(rec[i][0]-rec[j][0])>=(rec[i][1]+rec[j][1])/2)
 m=[sum(src[z][1]*C[i][z] for z in range(ns)) for i in range(nr)]
 for i in range(nr): ck(F(3,4)<=m[i]/rec[i][2]<=1)
 mu=[rec[i][1]/m[i] for i in range(nr)]; W=sum(x[1] for x in src)
 X=sum(rec[i][1]*m[i]/rec[i][2] for i in range(nr))
 radii=sorted(set(x[2] for x in rec)); layers=[]
 for k,r in enumerate(radii):
  ell=1/r-(1/radii[k+1] if k+1<len(radii) else 0)
  ids=[i for i in range(nr) if rec[i][2]<=r]; V=sum(rec[i][1] for i in ids)
  J=[sum(mu[i]*C[i][z] for i in ids) for z in range(ns)]
  A=[[sum(mu[i]*C[i][z]*C[i][zz] for i in ids) for zz in range(ns)] for z in range(ns)]
  B=sum(src[z][1]*src[zz][1]*(A[z][zz]-A[z][zz]**2/J[z]) for z in range(ns) if J[z]>=H for zz in range(ns))
  L=sum(src[z][1]*sum(rec[i][1]*C[i][z] for i in ids) for z in range(ns) if J[z]>=H)
  E=sum(src[z][1]*src[zz][1]*A[z][zz]**2/J[z] for z in range(ns) if J[z]>=H for zz in range(ns))
  cross=sum(src[z][1]*src[zz][1]*A[z][zz]**2/J[z] for z in range(ns) if J[z]>=H for zz in range(ns) if J[zz]<H)
  ck(B==L-E)
  bv={rec[i][3]:sum(rec[j][1] for j in ids if rec[j][3]==rec[i][3]) for i in ids}
  for mode in [0,1]:
   for i in ids:
    cap=sum((m[i]*m[j]/(V if mode else bv[rec[i][3]]) if mode or rec[i][3]==rec[j][3] else 0)*mu[j] for j in ids)
    ck(cap==m[i])
  layers.append(dict(ids=ids,ell=ell,J=J,A=A,B=B,L=L,E=E,cross=cross,V=V,bv=bv,X=sum(rec[i][1]*m[i] for i in ids)))
 ck(sum(l['ell']*l['X'] for l in layers)==X)
 ck(sum(l['ell']*l['B'] for l in layers)<=X)
 return stage,name,src,rec,H,C,m,mu,W,X,layers

def evaluate(data,dps):
 mp.mp.dps=dps
 stage,name,src,rec,H,C,m,mu,W,X,layers=data; ns=len(src)
 feats=[]; BH=L=Q=Cross=Clock=C0=Coff=D0=D1=mp.mpf(0)
 for l in layers:
  ids=l['ids']; G={}; h0={}; h1={}; xi={}; s0={}; s1={}
  for i in ids:
   for j in ids:
    key=i,j; xi[key]=q(mu[i]*mu[j]); G[key]=sum(q(src[z][1])*C[i][z]*C[j][z]/mp.sqrt(q(l['J'][z])) for z in range(ns) if l['J'][z]>=H)
    s1[key]=q(m[i]*m[j]/l['V']); s0[key]=q(m[i]*m[j]/l['bv'][rec[i][3]]) if rec[i][3]==rec[j][3] else mp.mpf(0)
    h0[key]=mp.sqrt(s0[key])*(mp.sqrt(q(m[i]))+mp.sqrt(q(m[j])))/2
    h1[key]=mp.sqrt(s1[key])*(mp.sqrt(q(m[i]))+mp.sqrt(q(m[j])))/2
  dot=lambda a,b:sum(xi[k]*a[k]*b[k] for k in xi)
  qr=dot(G,G); c0=dot(h0,G); coff=sum(xi[k]*h1[k]*G[k] for k in xi if rec[k[0]][3]!=rec[k[1]][3])
  d0=q(l['X'])-dot(h0,h0); d1=q(l['X'])-dot(h1,h1)
  clock=sum(q(src[z][1]*src[zz][1]*l['A'][z][zz]**2)/2*(1/mp.sqrt(q(l['J'][z]))-1/mp.sqrt(q(l['J'][zz])))**2 for z in range(ns) if l['J'][z]>=H for zz in range(ns) if l['J'][zz]>=H)
  close(q(l['E']),qr+q(l['cross'])+clock); le(qr,q(l['X'])); le(2*c0+d0,2*q(l['X']))
  ell=q(l['ell']); BH+=ell*q(l['B']); L+=ell*q(l['L']); Q+=ell*qr; Cross+=ell*q(l['cross']); Clock+=ell*clock
  C0+=ell*c0; Coff+=ell*coff; D0+=ell*d0; D1+=ell*d1
  feats.append((l,G,h0,h1,xi,s0,s1,c0,coff,d0,d1))
 close(BH,L-Q-Cross-Clock)
 def U(ts,opt=False):
  norm=inner=gap=credit=amplitude_gain=mp.mpf(0)
  for t,ft in zip(ts,feats):
   l,G,h0,h1,xi,s0,s1,c0,coff,d0,d1=ft
   ht={k:mp.sqrt((1-t)*s0[k]+t*s1[k])*(mp.sqrt(q(m[k[0]]))+mp.sqrt(q(m[k[1]])))/2 for k in xi}
   nr=sum(xi[k]*ht[k]**2 for k in xi); cr=sum(xi[k]*ht[k]*G[k] for k in xi)
   close(nr,q(l['X'])-(1-t)*d0-t*d1)
   formula=sum(xi[k]*h0[k]*G[k]*mp.sqrt(1-t+t*q(l['bv'][rec[k[0]][3]]/l['V'])) for k in xi)+mp.sqrt(t)*coff
   close(cr,formula)
   le(q(l['X'])/2,nr)
   if nr:
    le(cr/nr,mp.sqrt(2));credit+=q(l['ell'])*cr**2/nr
    amplitude_gain+=q(l['ell'])*(nr-cr)**2/nr
   ell=q(l['ell']);norm+=ell*nr; inner+=ell*cr;gap+=ell*sum(xi[k]*(ht[k]-G[k])**2 for k in xi)
  u=L+norm-2*inner-Cross-Clock;close(u-BH,gap);le(BH,u)
  close(u-(L-Cross-Clock-credit),amplitude_gain)
  return L-Cross-Clock-credit if opt else u
 u0=U([mp.mpf(0)]*len(feats));tg=(Coff/(2*q(X)))**2;ug=U([tg]*len(feats)); gg=Coff**2/(2*q(X))
 ta=[(ft[8]/(2*q(ft[0]['X'])))**2 for ft in feats]; ua=U(ta);ga=sum(q(ft[0]['ell'])*ft[8]**2/(2*q(ft[0]['X'])) for ft in feats)
 le(gg,u0-ug);le(ga,u0-ua);le(gg,ga)
 u1=U([mp.mpf(1)]*len(feats))
 uz=L-Cross-Clock
 op0=U([mp.mpf(0)]*len(feats),True);op1=U([mp.mpf(1)]*len(feats),True);opg=U([tg]*len(feats),True);opa=U(ta,True)
 for op in [op0,op1,opg,opa]:le(BH,op);le(op,uz)
 best=min(uz,u1,ua);bestopt=min(uz,op0,op1,opg,opa)
 def st(v):return mp.nstr(v,27)
 return {k:st(v) for k,v in dict(Uzero=uz,opt0=op0,opt1=op1,optglobal=opg,optadaptive=opa,best_unscaled=best,best_amplitude_optimized=bestopt,best_gap_to_BH=bestopt-BH,BH=BH,X=q(X),W=q(W),X_over_W=q(X/W),BH_over_X=BH/q(X),QH=Q,Rcross=Cross,Rclock=Clock,Coff=Coff,U0=u0,Uglobal=ug,Uadaptive=ua,U1=u1,tglobal=tg,global_guarantee=gg,adaptive_guarantee=ga,global_actual_gain=u0-ug,adaptive_actual_gain=u0-ua,global_bound_over_X=ug/q(X),adaptive_bound_over_W=ua/q(W)).items()}|{'H':str(H),'prefixes':len(layers),'high_sources_per_prefix':[sum(j>=H for j in l['J']) for l in layers],'low_positive_sources_per_prefix':[sum(0<j<H for j in l['J']) for l in layers],'adaptive_actual_le_global':ua<=ug+mp.mpf('1e-32')}

def main():
 results=[];maxerr=mp.mpf(0)
 for model in models():
  data=prepare(model);low=evaluate(data,40);high=evaluate(data,75)
  for k in high:
   if k in ['H','prefixes','high_sources_per_prefix','low_positive_sources_per_prefix','adaptive_actual_le_global']:continue
   err=abs(mp.mpf(low[k])-mp.mpf(high[k]));maxerr=max(maxerr,err);le(err,mp.mpf('1e-24'))
  results.append({'stage':model[0],'name':model[1],**high})
 out={'scope':'Real positive-volume one-dimensional source packets and disjoint receiver intervals; actual hard full-f matching q in [3/4,1], all source and physical clock prefixes. Not original historical selector/high-past qualification or general root bound. Fraction geometry/capacity versus ordinary noninterval mpmath diagnostics are separated.','version':mp.__version__,'check_counts':COUNT,'max_40_75_output_difference':mp.nstr(maxerr,8),'results':results}
 path=Path(__file__).with_suffix('.result.json');path.write_text(json.dumps(out,indent=2,sort_keys=True)+'\n');print(json.dumps({'checks':COUNT,'cases':len(results),'result':str(path)}))
if __name__=='__main__':main()
