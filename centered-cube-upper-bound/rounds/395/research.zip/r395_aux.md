# R395 — global cross-block mixing of the same receiver reference

**Result and limit.** A feasible prefix-adaptive global mixing construction gives an explicit decrease of the R394 local-reference upper bound, measured by an actual cross-block common-source integral. It retains every physical prefix and uses the original square once. This is a reference improvement, not a newly paid portion of BH and not a root-order theorem. The missing comparison with the total positive source cost is stated below.

This is not a direct instance of R373's surplus-source/uniform-target tilt. That construction fixes two source/target marginals and perturbs a product density for a linear reward. Here the feasible marginals are the actual receiver capacities at every physical prefix; the Hilbert reference depends on the square root of the coupling. The mixture creates positive cross-block support where the local coupling is zero. R373's displayed bounded-density tilt relative to that local zero support cannot do this.

## 1. Exact slot, measures and the square used

Use exactly the hard matched slot of R329/R331:

f≥0 in L1, m_u=∫f c_u=q_uR_u^n, q_-≤q_u≤λ,
a≤R_u≤b≤2a, dμ(u)=1_Edu/m_u,
E_r={u∈E:R_u≤r}, J_y(r)=∫_{E_r}c_u(y)dμ(u),
ell=b^−n δ_b+n r^−n−1 1_[a,b]dr.

Set W=∫f, X_q=∫_E qdu≤X=λ|E|, Y_r={J_y(r)≥H},
a_H(y)=∫ell(dr)1_Yr(y)∫_{E_r}c_u(y)du, L_H=∫a_H f.
Keep the original high-source feature, not an all-row relaxation:

G_H(r,u,v)=∫ f(y)1_Yr(y)c_u(y)c_v(y)/√J_y(r)dy,
dξ=ell(dr)1_{u,v∈E_r}dμ(u)dμ(v), Q_H=||G_H||².             (1)

Zero-rank integrands are zero. No receiver block or previously paid radius layer is removed from these prefixes. The high gate is the original one. Set A_yz(r)=∫_{E_r}c_u(y)c_u(z)dμ(u). The two nonnegative credits are exactly

R_cross=∫ell(dr)∫_{y∈Y_r,z∉Y_r}f(y)f(z)A_yz(r)²/J_y(r)dy dz,
R_clock=.5∫ell(dr)∫_{Y_r×Y_r}f(y)f(z)A_yz(r)²
                     [1/√J_y(r)−1/√J_z(r)]²dy dz,
R_*=R_cross+R_clock.

The R329 shared-source identity gives

BH(f,ν)≤BH(f,f)=L_H−Q_H−R_*, 0≤ν≤f.                       (2)

Thus the high-only reference below retains both original credits and requires no λH W completion fee. Also 0≤Q_H≤X_q. For example Q_H≤Q_all by nonnegative features; the original all-row square E_all=∫ell∫f(y)f(z)A_yz²/J_y is at most ∫ell∫fV=X_q because A_yz≤J_y. Symmetrizing the denominators gives Q_all≤E_all. The same argument holds before ell integration. All comparisons preserve the inclusive terminal atom.

## 2. A common mixture feasible on every original prefix

Fix a measurable countable partition E=⊔B_j. Write v_j(r)=|B_j∩E_r| and V(r)=|E_r|. Zero-volume blocks contribute zero. Define

S0_r(u,v)=m_um_v/v_j(r) if u,v∈B_j∩E_r, and zero otherwise,
S1_r(u,v)=m_um_v/V(r) on E_r²,
S_t=(1−t)S0+tS1, 0≤t≤1.                                   (3)

Both kernels, and hence their mixture, are measurable and symmetric with exact row marginal

∫_{E_r}S_t(u,v)dμ(v)=m_u.

This is a common actual-receiver coupling. First consider a scalar t common to the entire field; §3a permits the stronger common-prefix choice t=t(r), still never a different choice for individual sources or pairs. In the R331 construction take the prefix-independent θ≡1 and set

h_t=.5√S_t(√m_u+√m_v),
D_t=.25∫S_t(√m_u−√m_v)²dξ.

Capacity and the original ell tail imply exactly

||h_t||²=X_q−D_t, D_t=(1−t)D0+tD1, 0≤D0,D1≤X_q.             (4)

Equivalently the same signed receiver potential ψ0=−1 pays the Hilbert norm, leaving −D_t. No extra receiver constraint is imposed.

Define the high-source-reference upper bound

U_t^H=L_H+X_q−D_t−2⟨h_t,G_H⟩−R_*.                         (5)

Write U_t=U_t^H below. Hilbert's square identity and (2) prove BH(f,ν)≤U_t. More precisely,

U_t−BH(f,f)=||G_H−h_t||².                        (6)

Thus U_t contains a nonnegative reference approximation error. Its improvement is not an independent negative-square credit to subtract again from another BH decomposition.

## 3. Exact one-parameter formula and quantitative cross-block gain

Let diag mean that u,v belong to the same B_j, and off its complement. Set

C0=⟨h_0,G_H⟩,
C_off=⟨1_off h_1,G_H⟩
 =.5∫ell(dr)∫_off (√m_u+√m_v)√[m_um_v/V(r)]
       [∫f(y)1_Yr(y)c_u(y)c_v(y)/√J_y(r)dy] dμ(u)dμ(v).            (7)

All terms are true full-source weighted intersections at the same original prefix. In particular C_off can vanish; no uniform positive fraction is assumed. On a same-block pair put w_j(r)=v_j(r)/V(r). Then exactly

h_t=h_0√[1−t+t w_j(r)] on diag,
h_t=√t h_1 on off.

Consequently the complete scalar formula is

U_t=L_H+X_q−R_*−(1−t)D0−tD1
    −2∫_diag h_0G_H√[1−t+t w_j(r)]dξ−2√t C_off.             (8)

The best bound supplied by the constant-t subfamily is min_{0≤t≤1} U_t, with (8), rather than dropping its within-block fit cost. This minimum exists: (8) is a continuous convex function of t, by dominated convergence and convexity of negative square root. It is a scalar choice for the whole field, requiring no measurable selection over y or r.

In particular,

U_t≤U_0−2√t C_off+2(1−√[1−t])C0+t(D0−D1).                 (9)

Equation (9) retains the exact D1 credit. It uses only √[1−t+t w_j]≥√[1−t], so it is weaker than the exact formula (8). If C_off>0, its negative √t term dominates all order-t losses as t↓0; therefore a purely local reference is not optimal in this larger family.

A fully explicit choice follows from Cauchy–Schwarz and (1),(4):

0≤C0≤X_q, 0≤C_off≤X_q.

For X_q>0 put t_*=[C_off/(2X_q)]². Since 1−√(1−t)≤t and D1≥0,

U_t*≤U_0−C_off²/(2X_q).                                   (10)

Indeed (9) is at most U_0−2√t C_off+t(2C0+D0), and Cauchy–Schwarz gives C0≤√[(X_q−D0)X_q]. Thus 2C0+D0≤2√[(X_q−D0)X_q]+D0≤2X_q, using 2√(1−d)+d≤2 for 0≤d≤1. If C_off=0 take t_*=0; if X_q=0 all traffic vanishes. Formula (10) is an explicit, nonnegative improvement with no assumptions on the density of f. It couples different blocks globally rather than summing their costs.

## 3a. Stronger prefix-adaptive mixing, with no additional clock price

The capacity restriction is on S_r, whereas only θ must be independent of r. Thus a measurable common-prefix choice t(r) is legal while θ≡1 stays fixed. It does not change R, J, ell or the original prefix.

Define all quantities before the ell integration:

X(r)=∫_{E_r}m_u du,
Q_H(r)=∫_{E_r²}G_H(r,u,v)²dμ(u)dμ(v),
C0(r)=∫_{E_r²}h_0G_H dμ⊗dμ,
C_off(r)=∫_off h_1G_H dμ⊗dμ,
D_i(r)=.25∫_{E_r²}S_i(√m_u−√m_v)²dμ⊗dμ.

The same full-f matching and symmetry used in §1 prove Q_H(r)≤X(r). Capacity gives ||h_i(r)||²=X(r)−D_i(r), hence C0(r),C_off(r),D_i(r)≤X(r). Crucially,

∫ell(dr)X(r)=∫_E m_uR_u^−n du=X_q.                        (11)

For arbitrary measurable t(r)∈[0,1], define U[t] by integrating the right side of (8) prefixwise, with X(r),D_i(r),t(r) and the within-prefix integrals, and then adding L_H−R_*. Explicitly,

U[t]=L_H−R_*+∫ell(dr){X(r)−(1−t(r))D0(r)−t(r)D1(r)
 −2∫_diag h_0G_H√[1−t(r)+t(r)v_j(r)/V(r)]dμ⊗dμ
 −2√t(r)C_off(r)}.                                        (12)

All exact Hilbert identities remain valid, in particular BH≤U[t] and its exact gap above BH(f,f) equals ||G_H−h_t||². Choose the explicit measurable function

t_*(r)=[C_off(r)/(2X(r))]² if X(r)>0, and zero otherwise.

The pointwise version of (9)–(10), followed by the unchanged ell integration, gives

BH≤U[t_*]≤U_0−I_mix,
I_mix=∫ell(dr) C_off(r)²/[2X(r)]
     ≥C_off²/(2X_q).                                      (13)

The zero-denominator integrand is zero. The last inequality is weighted Cauchy–Schwarz with weights ell and X(r); ∫ell C_off(r)=C_off. Thus adaptation can only strengthen the displayed guaranteed improvement and charges no number-of-prefix factor. Finiteness follows from C_off(r)≤X(r) and (11), and joint measurability follows directly from the prefix integrals. No minimizer selection theorem is required for this explicit choice.

The full global coupling t(r)≡1 is also retained as a candidate, so a convenient complete upper estimate is

BH≤min{U_1,U[t_*]}≤min{U_1,U_0−I_mix}.                     (14)

No claim is made that the explicit t_* minimizes (12). In particular (12), not just its guaranteed improvement, retains the complete same-block fit and Dirichlet costs.

## 3b. Explicit amplitude optimization; no worse than the zero reference

For any one of the measurable shapes h_t(r) above, put

N(r)=||h_t(r)||²=X(r)−D_t(r), C(r)=⟨h_t(r),G_H(r)⟩.

Saturation and symmetry give the additional exact norm formula

N(r)=X(r)/2+.5∫_{E_r²}S_t(u,v)√(m_um_v)dμ(u)dμ(v).

Therefore X(r)/2≤N(r)≤X(r). Set a(r)=C(r)/N(r) when N(r)>0, and zero otherwise. Cauchy–Schwarz yields C(r)²≤N(r)Q_H(r)≤N(r)X(r), hence 0≤a(r)≤√2. It is an explicit measurable amplitude and a(r)h_t remains in L²(ξ).

This reference is now used directly in the Hilbert square identity. We do NOT apply the R331 signed-potential identity with a prefix-dependent θ. Its exact norm price is ∫ell a(r)²N(r), and its exact pairing is ∫ell a(r)C(r). Consequently

BH(f,ν)≤U_opt[t]:=L_H−R_*−∫ell(dr) C(r)²/N(r),              (15)

with zero value for the quotient on N=0. More precisely,

U_opt[t]−BH(f,f)=||G_H−a h_t||²≥0,
U[t]−U_opt[t]=∫ell(dr)[N(r)−C(r)]²/N(r)≥0.                 (16)

Thus (15) is no worse than both the unoptimized reference U[t] and the zero-reference value L_H−R_*. It retains the same original high-source square and credits exactly once. It is an explicit one-dimensional projection at each prefix, not a new receiver-potential certificate or a root payment.

In particular the earlier guaranteed improvement remains valid with its stated unoptimized local baseline:

U_opt[t_*]≤U[t_*]≤U_0−I_mix.                               (17)

This does NOT assert U_opt[t_*]≤U_opt[0]−I_mix. A complete comparison may simply retain min{U_opt[0],U_opt[1],U_opt[t_*]}; all three are legitimate global references and all are at most the zero-reference bound. No existence claim for an infinite-dimensional optimizer is needed. The unresolved issue is still whether their captured common-source energy in (15) suffices for the general root estimate.

## 4. What has and has not been paid

Including the explicit amplitude optimization, a general valid estimate from this construction is

BH(f,ν)≤min{U_opt[0],U_opt[1],U_opt[t_*]}≤U_0−I_mix.

This is stronger than the displayed local-reference bound whenever C_off>0 (and potentially more strongly through I_mix). It is not known to be stronger than other existing global BH bounds, and it is not a claim that C_off²/(2X_q) equals a separately identified positive part of the original traffic. It reduces the approximation error in (6). In particular it must not be combined with a separately retained Q_off subtraction: Q_H and the two original credits have already been used once in (6). The adaptive version obeys the same restriction.

The concrete unresolved geometric requirement for the optimized family is that its actual captured feature energy ∫ell C(r)²/N(r) cover L_H−R_* up to εX+C_ε√n log^A(n+2)W. The unoptimized comparison in (12) is a sufficient but weaker requirement. Neither real q matching nor row saturation alone supplies this comparison. The cross-block reward in (7) contains the original source-dependent J; replacing it by J_max or treating the two captured sources independently would lose precisely the association being tested.

Thus the new estimate does not close the general target. It provides a concrete globally feasible correction to R394 and an exact family of common-prefix scalar choices that can be audited without presuming a favourable partition. It also exposes the remaining limitation: creating cross-block reference support does not prove that the resulting common-source intersection reward is large enough compared with X_q. No further unpaid term is hidden in a new source/coupling definition.

If this family were to prove a full BH price, it would replace that entire slot. The original entrance terms and outer multiplier would remain as required; this high-only construction adds no λH W completion fee, and previously paid BH pieces would not be charged or subtracted again. No new εX receipt is asserted in this note.

## 5. Local checks and limits

The companion `/tmp/r395_aux_check.py` verifies exact finite-prefix capacity, the norm/Dirichlet budget (4), and the algebraic bounds leading to (9)–(10), using Fraction arithmetic. These are algebra checks; they do not establish the missing geometric comparison or a continuum extremal estimate. Independent matched-incidence diagnostics are being handled by the numeric agent and are not counted here.

Actual run:

`PASS {'scalar_loss': 2304, 'explicit_gain': 768, 'prefix_capacity': 288, 'norm_bill': 36, 'prefix_adaptation': 27, 'amplitude': 36} total 3459`

The final 36 checks verify exact amplitude minimization, its bound by √2 and domination of both the unoptimized and zero references. The constant-2 scalar tests enforce the Gram-compatible bound on C0; they do not treat C0 and D0 as unconstrained independent inputs. The prefix tests use positive receiver quadrature, n=2, q=1, exact rational radius levels and exact original tail weights. They are not a native Lebesgue realization of every source feature. The analytic Cauchy–Schwarz and full-f matching proofs supply that generality.
