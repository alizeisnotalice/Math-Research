#!/usr/bin/env python3
"""R775 exact double endpoint change and geometry payment certificate."""

import argparse
from collections import defaultdict
from fractions import Fraction as F
import hashlib
from itertools import product
import json
from pathlib import Path
import platform
import sys


MODEL_SHA = "8fdd6ddf88d8b2b8a8be4bac44199ba8cff67aa153cca624420bff0d641d78d2"
DEFAULT_MODEL = (Path(__file__).resolve().parents[2] /
                 "centered-cube-r774-20261119" / "number" / "verify.py")


def load_model(path):
    src = path.read_bytes()
    assert hashlib.sha256(src).hexdigest() == MODEL_SHA
    namespace = {"__name__":"frozen_r774_geometry", "__file__":str(path)}
    exec(compile(src,str(path),"exec"),namespace)
    return namespace


def verify(mod):
    (m_parent,centers,octaves,A,E,v_owner,histories,labels,I,C,keys,overlap,K,
     volume,degree,down,p,breaks,prices,Y,int_H,Q_peak,common_rows,deleted) = mod["make_model"]()
    mu,meet,size,summation = (mod[key] for key in ("density_integral","meet","size","summation"))
    m = tuple(volume(e) for e in keys)
    H_coeff = tuple(I[e]/m[e] for e in keys)
    J = {(a,b):size(meet(A[labels[a]],A[labels[b]])) for a,b in product(keys,repeat=2)}
    assert all(m[e]==size(A[labels[e]]) for e in keys)
    arms = {e:tuple(u for u in keys if m[u]<m[e] and K[e,u]>0) for e in keys}
    arm_probability = tuple(summation(I[u]*mu(overlap[e,u])/(m[e]*m[u]*degree[e])
                                     for u in arms[e]) for e in keys)
    assert arm_probability == p
    assert Q_peak==summation(I[e]*down[e]**2/degree[e] for e in keys)

    def price_rows(probe=None):
        for cell in prices:
            if probe is not None:
                cell = meet(cell,probe)
            if not size(cell):
                continue
            x = sum(cell)/2
            for octave in sorted(set(octaves)):
                H = {e:H_coeff[e] for e in keys
                     if octaves[labels[e]]==octave and C[e][0]<x<C[e][1]}
                if H:
                    yield cell,mu(cell),H,summation(H.values())

    def old_side_integrals(rows):
        # Condition on the actual first marked intersection for each original edge e->u.
        out,wrong_norm,omit_p = (defaultdict(lambda:defaultdict(F)) for _ in range(3))
        for _,mass,H,total in rows:
            for u in H:
                eta = {v:arm_probability[v]*r for v,r in H.items() if u in arms[v]}
                subtotal = summation(eta.values())
                if not subtotal:
                    continue
                assert 0<subtotal<=total
                for e in H:
                    if u not in arms[e]:
                        continue
                    mark_mass = mu(overlap[e,u])
                    assert mark_mass>0
                    for v,r in eta.items():
                        if not K[e,v]:
                            continue
                        n = mass*r/mark_mass
                        out[e,u][v] += n/total
                        wrong_norm[e,u][v] += n/subtotal
                        omit_p[e,u][v] += mass*H[v]/(mark_mass*total)
        assert all(summation(row.values())<=1 for row in out.values())
        return out,wrong_norm,omit_p

    def method_old(left,right,squared_degree=False):
        coeffs = defaultdict(F)
        old_split = defaultdict(F)
        for e in keys:
            divisor = degree[e]**(2 if squared_degree else 1)
            for u,g in product(arms[e],repeat=2):
                root = I[e]*I[u]*I[g]*K[e,u]*K[e,g]/divisor
                for (v,a),(w,b) in product(left.get((e,u),{}).items(),right.get((e,g),{}).items()):
                    mass = root*a*b
                    coeffs[e,v,w] += mass
                    old_split[e,u,g,v,w] += mass
        return coeffs,old_split

    def price_first_B(rows):
        # Freeze e,v and integrate the fraction of actual common lower parents.
        B = defaultdict(F)
        cell_values = {}
        for cell,mass,H,total in rows:
            for e,v in product(H,repeat=2):
                if not K[e,v]:
                    continue
                root = summation(H[u] for u in set(arms[e]).intersection(arms[v],H))
                T = root/total
                assert 0<=T<=1
                if T:
                    B[e,v] += mass*T
                    cell_values[e,v,cell] = T
        assert all(0<w<=mu(overlap[e,v]) for (e,v),w in B.items())
        assert all(B[e,v]==B[v,e] for e,v in B)
        return B,cell_values

    def method_new(B_left,B_right):
        coeffs,P = {},{}
        for v,w,e in product(keys,repeat=3):
            if not K[e,v] or not K[e,w]:
                continue
            b,c = B_left.get((e,v),F(0)),B_right.get((e,w),F(0))
            if b and c:
                P[e,v,w] = I[e]*p[v]*p[w]*b*c/(degree[e]*m[e]**2)
                coeffs[e,v,w] = H_coeff[v]*H_coeff[w]*P[e,v,w]
        return coeffs,P

    all_rows = list(price_rows())
    left,wrong_norm,omit_p = old_side_integrals(all_rows)
    old,split = method_old(left,left)
    B,table = price_first_B(all_rows)
    new,P = method_new(B,B)
    assert old==new and all(new[e,v,w]==new[e,w,v] for e,v,w in new)
    total = summation(old.values())
    assert 0<total<Q_peak

    wrong_d2 = summation(method_old(left,left,True)[0].values())
    wrong_single_norm = summation(method_old(wrong_norm,left)[0].values())
    wrong_single_p = summation(method_old(omit_p,left)[0].values())
    assert min(wrong_d2,wrong_single_norm,wrong_single_p)>total

    # A genuinely two-price rectangular probe with disjoint actual price intervals.
    price_probes = (F(-11,4),F(-1,4)), (F(1,8),F(13,8))
    probe_rows = tuple(list(price_rows(q)) for q in price_probes)
    probe_old,probe_split = method_old(*(old_side_integrals(rows)[0] for rows in probe_rows))
    probe_new,_ = method_new(*(price_first_B(rows)[0] for rows in probe_rows))
    assert probe_old==probe_new and 0<summation(probe_old.values())<total
    rich_probe = [word for word in probe_split
                  if labels[word[1]]!=labels[word[2]] and labels[word[-2]]!=labels[word[-1]]
                  and all(0<p[i]<1 for i in word[-2:])]
    probe_word = max(rich_probe,key=probe_split.get)
    assert probe_split[probe_word]<split[probe_word]

    e,u,g,v,w = probe_word
    probe_fibres = []
    for source,target,rows in ((u,v,probe_rows[0]),(g,w,probe_rows[1])):
        for cell,mass,H,total_H in rows:
            if not {e,source,target} <= H.keys():
                continue
            common = sorted(set(arms[e]).intersection(arms[target],H))
            assert source in common
            fraction = summation(H[i] for i in common)/total_H
            probe_fibres.append({"actual_price_interval":cell,"mu_mass":mass,"H":total_H,
                                 "true_common_down_history":common,"T":fraction})
            break
    assert len(probe_fibres)==2
    B_lebesgue = defaultdict(F)
    for (e,v,cell),value in table.items():
        B_lebesgue[e,v] += size(cell)*value
    contrasting_B = next((e,v,B[e,v],B_lebesgue[e,v]) for e,v in B
                         if B[e,v]!=B_lebesgue[e,v])

    # The three root choices are three distinct independent Lebesgue rectangles.
    breaks_A = sorted({x for a in A for x in a})
    A_cells = list(zip(breaks_A,breaks_A[1:]))
    def section(a,b):
        lo,hi = meet(A[labels[a]],A[labels[b]])
        return tuple(z for z in A_cells if lo<=z[0] and z[1]<=hi)

    pair_cells = {pair:section(*pair) for pair in J}
    assert J=={pair:summation(map(size,cells)) for pair,cells in pair_cells.items()}

    def root_area(root,a,b):
        return summation(size(x)*size(y) for x,y in product(pair_cells[root,a],pair_cells[root,b]))

    def geometric_terms(e,v,w):
        return (J[e,v]*J[e,w],m[e]*J[e,v]*J[v,w]/m[v],m[e]*J[e,w]*J[v,w]/m[w])

    def pay(threshold,strict_endpoints):
        endpoints = defaultdict(dict)
        for (e,v,w),weight in P.items():
            if strict_endpoints and m[e]<=max(m[v],m[w]):
                continue
            G = geometric_terms(e,v,w)
            g_e = I[e]*summation(G)/m[e]**2
            assert g_e>0
            endpoints[v,w][e] = (weight,g_e,G)
        totals = defaultdict(F)
        witness = None
        lingering_witness = None
        surplus_pair_count = 0
        for (v,w), group in endpoints.items():
            endpoint_weight = H_coeff[v]*H_coeff[w]
            whole = summation(a for a,_,_ in group.values())
            root_capacity = summation(b for _,b,_ in group.values())
            paid_local = summation(min(a,threshold*b) for a,b,_ in group.values())
            paid_pooled = min(whole,threshold*root_capacity)
            paid_endpoint = min(whole,threshold*(root_capacity+J[v,w]))
            assert 0<paid_local<=paid_pooled<=paid_endpoint<=whole
            for name,x in (("mass",whole),("local",paid_local),("pooled_without_endpoint",paid_pooled),
                           ("pooled_with_endpoint",paid_endpoint)):
                totals[name] += endpoint_weight*x
            if paid_pooled>paid_local:
                deficit=[e for e,(a,b,_) in group.items() if a>threshold*b]
                surplus=[e for e,(a,b,_) in group.items() if a<threshold*b]
                assert deficit and surplus
                surplus_pair_count += 1
                benefit = endpoint_weight*(paid_pooled-paid_local)
                stronger = witness is None or benefit>witness["weighted_pure_pooling_gain"]
                lingering = (labels[v]!=labels[w] and paid_pooled<paid_endpoint<whole and
                             (lingering_witness is None or benefit>lingering_witness["weighted_pure_pooling_gain"]))
                if stronger or lingering:
                    for e,(_,_,terms) in group.items():
                        alternate = (root_area(e,v,w),m[e]*root_area(v,e,w)/m[v],
                                     m[e]*root_area(w,e,v)/m[w])
                        assert alternate==terms
                    detail = {"endpoint_histories":[v,w],"endpoint_volumes":[m[v],m[w]],
                               "endpoint_owners":[E[labels[v]],E[labels[w]]],
                               "endpoint_reference":endpoint_weight,
                               "centres":[{"history":e,"m":m[e],"d":degree[e],"P":a,"g":b,
                                            "B_left":B[e,v],"B_right":B[e,w],"G_terms":terms}
                                           for e,(a,b,terms) in sorted(group.items())],
                               "centres_with_deficit":deficit,"centres_with_surplus":surplus,
                               "endpoint_J":J[v,w],"total_P":whole,"total_g":root_capacity,"local_paid":paid_local,
                               "pooled_paid_without_endpoints":paid_pooled,
                               "pooled_paid_with_endpoints":paid_endpoint,
                               "unpaid_after_pooled":whole-paid_endpoint,
                               "weighted_pure_pooling_gain":benefit}
                    if stronger:
                        witness = detail
                    if lingering:
                        lingering_witness = detail
        totals["residual_after_endpoint"] = totals["mass"]-totals["pooled_with_endpoint"]
        return {"t":threshold,"strict_two_new_downward_ends":strict_endpoints,
                "endpoint_groups":len(endpoints),"groups_with_strict_pure_pooling_gain":surplus_pair_count,
                "totals":totals,"strongest_pure_pooling_witness":witness,
                "distinct_endpoints_pooling_gain_with_residual_witness":lingering_witness}

    thresholds = (F(1,1024),F(1,256),F(1,64),F(1,16))
    payment = [pay(t,strict) for t,strict in product(thresholds,(False,True))]
    assert all(x["totals"]["mass"]==total for x in payment if not x["strict_two_new_downward_ends"])
    assert any(x["distinct_endpoints_pooling_gain_with_residual_witness"] for x in payment)
    by_octave = {O:summation(w for (e,_,_),w in new.items() if octaves[labels[e]]==O)
                 for O in sorted(set(octaves))}
    assert sum(by_octave.values())==total and all(by_octave.values())
    return {"model_sha256":MODEL_SHA, "ordered_physical_parents":len(A),"historical_labels":len(I),
            "scope":"true marked hard graph of R774, both original arms strictly downward; no upstream high-dimensional or long-path masks",
            "old_peak_mass":Q_peak,"double_replacement_mass":total,"double_replacement_mass_by_octave":by_octave,
            "correct_through_old_arm_histories":len(split),"positive_center_and_new_endpoint_triples":len(new),
            "B_symmetric_positive_hard_edges":len(B),"positive_T_price_cells":len(table),
            "largest_common_root_fraction":max(table.values()),
            "contrasting_B_using_actual_mu_vs_lebesgue_as_e_v_Bmu_Bdx":contrasting_B,
            "wrong_checks":{"squared_original_degree":wrong_d2,"conditionally_renormalize_only_left":wrong_single_norm,
                            "drop_only_left_private_p":wrong_single_p},
            "disjoint_actual_price_probe":{"x_y_intervals":price_probes,"mass":summation(probe_new.values()),
                "largest_old_and_new_word_e_u_g_v_w":probe_word,"word_mass":probe_split[probe_word],
                "p_v_p_w":[p[e] for e in probe_word[-2:]],"original_center_degree":degree[probe_word[0]],
                "positive_exact_T_fibres":probe_fibres},
            "payment_domain":"for each endpoint pair use exactly the positive hard centre paths in both calculations",
            "thresholds":payment}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model",default=DEFAULT_MODEL,type=Path)
    mode=parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--output",type=Path)
    mode.add_argument("--check",type=Path)
    args=parser.parse_args()
    data=verify(load_model(args.model))
    data["runtime"]={"python":sys.version.split()[0],"interpreter":sys.executable,"machine":platform.machine(),
                     "exact":"Fraction, no floating certificate conditions",
                     "model":"read-only R774 number/verify.py; pass --model if stored at another path",
                     "commands":["python -B verify775.py --output verify.json",
                                 "python -B verify775.py --check verify.json"]}
    text=json.dumps(data,indent=2,sort_keys=True,default=str)+"\n"
    if args.output:
        args.output.write_text(text)
    else:
        assert args.check.read_text()==text, "stored certificate differs from independent calculation"
    print(f"R775: {data['positive_center_and_new_endpoint_triples']} true routes; "
          f"double replacement={float(data['double_replacement_mass']):.12g}")


if __name__=="__main__":
    main()
