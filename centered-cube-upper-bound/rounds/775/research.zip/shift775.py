#!/usr/bin/env python3
"""R775 certificate for true owner shifts after dividing the original price load."""

from bisect import bisect_left
from collections import defaultdict
from fractions import Fraction as F
from itertools import combinations, product
import argparse
import json
from pathlib import Path
import sys

from verify775 import DEFAULT_MODEL, MODEL_SHA, load_model


def cert(mod):
    (m,centres,octaves,A,E,owner_volumes,histories,labels,I,C,keys,overlap,K,
     volume,d,down,p,breaks,prices,Y,price_mass,Q,common_rows,deleted) = mod["make_model"]()
    mu,meet,size,ss = (mod[name] for name in ("density_integral","meet","size","summation"))
    deltas = tuple((b-a)/2 for a,b in E)
    expansions = tuple((a-2*de,b+2*de) for (a,b),de in zip(A,deltas))
    j_over_m = tuple(ss(I[e] for e in keys if labels[e]==i)/m[i] for i in range(len(A)))
    assert all((a+b)/2==c for (a,b),c in zip(E,centres))
    arms = {e:tuple(g for g in keys if K[e,g]>0 and volume(g)<volume(e)) for e in keys}
    right_cut = F(-3,8),F(9,8)
    atoms = sorted(set(breaks)|set(right_cut)|{F(k,8) for k in range(-96,97)})

    def W(x, closed=False, octave=None):
        return ss(j_over_m[i] for i,(a,b) in enumerate(expansions)
                  if (octave is None or octaves[i]==octave)
                  and (a<=x<=b if closed else a<x<b))

    def full_cell_data(crop):
        segments = defaultdict(lambda:[F(0),F(0)])
        independently_over_t = independently_raw = F(0)
        needed = same_octave_sup_ratio = F(0)
        expansion_tests = defaultdict(int)
        original_paths = set()
        for price in zip(atoms,atoms[1:]):
            y = sum(price)/2
            if crop and not right_cut[0]<y<right_cut[1]:
                continue
            real_price_mass = mu(price)
            if not real_price_mass:
                continue
            for e in keys:
                if not C[e][0]<y<C[e][1]:
                    continue
                i = labels[e]
                active = [g for g in arms[e] if C[g][0]<y<C[g][1]]
                t = ss(I[g]/volume(g) for g in active)
                if not t:
                    continue
                if not p[e]:
                    continue
                span = price[0]-deltas[i],price[1]+deltas[i]
                O = octaves[i]
                knots = sorted(set(span)|{z for k,q in enumerate(expansions) if octaves[k]==O
                                          for z in q if span[0]<z<span[1]})
                values = [W(z,closed=True,octave=O) for z in knots]
                values.extend(W((a+b)/2,octave=O) for a,b in zip(knots,knots[1:]))
                assert min(values)>=t
                same_octave_sup_ratio=max(same_octave_sup_ratio,t/min(values))
                independently_over_t += real_price_mass*I[e]*p[e]/volume(e)
                independently_raw += real_price_mass*I[e]*p[e]*t/volume(e)
                for g in active:
                    k = labels[g]
                    assert deltas[i]<=2*deltas[k]
                    left,right = price[0]-deltas[i],price[1]+deltas[i]
                    requirement = max(F(0),(A[k][0]-left)/deltas[k],(right-A[k][1])/deltas[k])
                    needed = max(needed,requirement)
                    for candidate in (0,1,2):
                        expansion_tests[candidate] += requirement>candidate
                    assert requirement<=2
                    # Integrate the left private price with its true mass; keep the right density.
                    raw_g = I[g]*K[e,g]*real_price_mass/mu(overlap[e,g])
                    for u in arms[e]:
                        path_mass = I[e]*I[u]*K[e,u]*raw_g/d[e]
                        contribution = path_mass/size(price)
                        segments[i,price][0] += contribution/t
                        segments[i,price][1] += contribution
                        original_paths.add((u,e,g))
        exact_F = ss(a*size(q) for (_,q),(a,b) in segments.items())
        exact_H = ss(b*size(q) for (_,q),(a,b) in segments.items())
        assert exact_F==independently_over_t
        assert exact_H==independently_raw
        if not crop:
            assert exact_H==Q
        return segments,exact_F,exact_H,needed,dict(expansion_tests),len(original_paths),same_octave_sup_ratio

    def linear_slabs(segments):
        by_owner = defaultdict(list)
        slope = defaultdict(lambda:defaultdict(lambda:[F(0),F(0)]))
        for (i,(a,b)),(payload,raw) in sorted(segments.items()):
            by_owner[i].append((a,b,payload,raw))
            delta = deltas[i]
            for point,sign in ((a-delta,1),(a+delta,-1),(b-delta,-1),(b+delta,1)):
                slope[point][i][0] += sign*payload/(2*delta)
                slope[point][i][1] += sign*raw/(2*delta)
        points = sorted(set(slope)|{z for q in expansions for z in q})
        ends = {i:[b for _,b,_,_ in items] for i,items in by_owner.items()}

        def direct_at(i,x):
            delta = deltas[i]
            left,right = x-delta,x+delta
            f=h=F(0)
            for k in range(bisect_left(ends[i],left),len(ends[i])):
                a,b,payload,raw = by_owner[i][k]
                if a>=right:
                    break
                w = size(meet((a,b),(left,right)))/(2*delta)
                f += w*payload
                h += w*raw
            return f,h

        values = [[F(0),F(0)] for _ in A]
        speeds = [[F(0),F(0)] for _ in A]
        slabs = []
        for left,right in zip(points,points[1:]):
            for i,(step_f,step_h) in slope[left].items():
                speeds[i][0] += step_f
                speeds[i][1] += step_h
            for i in by_owner:
                assert tuple(values[i])==direct_at(i,left)
            next_vals = [[f+(right-left)*sf,h+(right-left)*sh]
                         for (f,h),(sf,sh) in zip(values,speeds)]
            f_pair = [ss(row[0] for row in vals) for vals in (values,next_vals)]
            h_pair = [ss(row[1] for row in vals) for vals in (values,next_vals)]
            middle_W = W((left+right)/2)
            for pt,f,h in zip((left,right),f_pair,h_pair):
                assert 0<=h<=middle_W*f
                assert h<=W(pt,closed=True)*f
            components = [(a[0],b[0]) for a,b in zip(values,next_vals)]
            slabs.append(((left,right),f_pair,h_pair,middle_W,components))
            values=next_vals
        assert not any(a or b for a,b in values)
        return slabs

    def quadratic(q, f, g):
        f0,f1=f
        g0,g1=g
        return size(q)*(2*f0*g0+f0*g1+f1*g0+2*f1*g1)/6

    def merged(intervals):
        union=[]
        for a,b in intervals:
            if union and a==union[-1][1]:
                union[-1] = union[-1][0],b
            elif a<b:
                union.append((a,b))
        return union

    def fubini_gate(segments, intervals):
        # Independent cumulative area of the rectangle (true price, owner shift).
        def cumulative(x,a,b,delta):
            plus_square=lambda z:max(F(0),z)**2
            return (plus_square(x-a+delta)-plus_square(x-b+delta)
                   -plus_square(x-a-delta)+plus_square(x-b-delta))/2

        out_F = out_H = F(0)
        for (i,(a,b)),(f,h) in segments.items():
            delta=deltas[i]
            support=a-delta,b+delta
            for head,tail in intervals:
                if not size(meet(support,(head,tail))):
                    continue
                weight=(cumulative(tail,a,b,delta)-cumulative(head,a,b,delta))/(2*delta)
                out_F += f*weight
                out_H += h*weight
        return out_F,out_H

    def one_case(crop):
        segments,orig_F,orig_H,needed,expansions_fail,path_count,octave_ratio = full_cell_data(crop)
        slabs=linear_slabs(segments)
        F_area=H_area=F2=diag=cross=majorant=W2=F(0)
        sup_ratio=F(0)
        for q,f,h,Wp,components in slabs:
            length=size(q)
            F_area += length*sum(f)/2
            H_area += length*sum(h)/2
            F2 += quadratic(q,f,f)
            active=[g for g in components if any(g)]
            diag += ss(quadratic(q,g,g) for g in active)
            cross += 2*ss(quadratic(q,g,g2) for g,g2 in combinations(active,2))
            majorant += length*Wp*sum(f)/2
            W2 += length*Wp**2
            sup_ratio=max([sup_ratio]+[b/(Wp*a) for a,b in zip(f,h) if Wp*a>0])
        assert F_area==orig_F and H_area==orig_H<=majorant
        assert F2==diag+cross and min(diag,cross)>0

        tests=[]
        for tau in map(F,("1/4","1/3","1/2","2/3")):
            paid_F=paid_H=paid_W2=F(0)
            low_length=high_length=F(0)
            low=[]
            for q,f,h,Wp,_ in slabs:
                if not any(f):
                    continue
                length=size(q)
                low0,low1=(s<=tau*Wp for s in f)
                if low0 and low1:
                    u,vv=F(0),F(1)
                elif not low0 and not low1:
                    high_length+=length
                    continue
                else:
                    split=(tau*Wp-f[0])/(f[1]-f[0])
                    assert 0<=split<=1
                    u,vv=(F(0),split) if low0 else (split,F(1))
                pay_length=length*(vv-u)
                low_length+=pay_length
                high_length+=length-pay_length
                if pay_length:
                    low.append((q[0]+length*u,q[0]+length*vv))
                paid_F+=pay_length*(2*f[0]+(u+vv)*(f[1]-f[0]))/2
                paid_H+=pay_length*(2*h[0]+(u+vv)*(h[1]-h[0]))/2
                paid_W2+=pay_length*Wp**2
            union=merged(low)
            assert (paid_F,paid_H)==fubini_gate(segments,union)
            assert paid_H<=tau*paid_W2<=tau*W2
            tests.append({"threshold":tau,"paid_true_mass":paid_H,"unpaid_true_mass":H_area-paid_H,
                          "area_of_paid_F":paid_F,"low_high_positive_support_lengths":[low_length,high_length],
                          "number_of_low_intervals":len(union),"bound_from_W_plus_squared":tau*paid_W2})
        assert any(r["paid_true_mass"]>0 and r["unpaid_true_mass"]>0 for r in tests)
        return {"right_price_rule":"one-sided y in [-3/8,9/8]" if crop else "both original downward arms",
                "path_count":path_count,"true_constant_input_price_segments":len(segments),
                "area_dividing_by_original_t":F_area,"area_undivided":H_area,"global_upper_integral_W_plus_F":majorant,
                "sharpest_slab_endpoint_ratio_H_to_W_plus_F":sup_ratio,
                "integral_F_squared":F2,"diagonal_F_squared":diag,"cross_F_squared":cross,
                "integral_W_plus_squared":W2,"payment":tests,
                "maximum_t_e_over_minimum_shifted_W_plus_of_its_physical_octave":octave_ratio,
                "largest_expansion_coefficient_for_actual_selected_price_atoms":needed,
                "actual_price_atom_support_failures_for_expansion_1_plus_beta_over_a":expansions_fail}

    def octave_tail():
        alpha = F(1,16)
        checks=[]
        for O in sorted(set(octaves)):
            grid=sorted({a for i,q in enumerate(expansions) if octaves[i]==O for a in q})
            cells=[(b-a,W((a+b)/2,octave=O)) for a,b in zip(grid,grid[1:])]
            low=ss(dx for dx,w in cells if 0<w<=alpha)
            high=ss(dx for dx,w in cells if w>alpha)
            assert low>0 and high>0
            for order in (1,3,5):
                lhs=alpha**order*ss(dx*w**2 for dx,w in cells if w>alpha)
                rhs=ss(dx*w**(order+2) for dx,w in cells)
                assert 0<lhs<=rhs
                checks.append({"octave_left":O,"alpha":alpha,"d":order,
                               "positive_low_and_high_lengths":[low,high],"lhs":lhs,"rhs":rhs})
        return checks

    def local_density_gate():
        # This gate uses the full source support and a fixed, unrenormalized t_e>alpha.
        alpha = F(1,32)
        histories_geometry = {}
        boundary_atoms = 0
        boundary_mass = F(0)
        for e in keys:
            if not p[e]:
                continue
            i = labels[e]
            coefficient = p[e]*I[e]/volume(e)
            segments,selected = {},[]
            for price in zip(atoms,atoms[1:]):
                y = sum(price)/2
                if not C[e][0]<y<C[e][1]:
                    continue
                active = [g for g in arms[e] if C[g][0]<y<C[g][1]]
                t = ss(I[g]/volume(g) for g in active)
                if t==alpha:
                    boundary_atoms+=1
                    boundary_mass+=coefficient*t*mu(price)
                if t<=alpha:
                    continue
                price_weight = mu(price)
                raw = ss(I[e]*I[u]*I[g]*K[e,u]*K[e,g]*price_weight/
                         (d[e]*mu(overlap[e,g]))
                         for u,g in product(arms[e],active))
                assert raw/t==coefficient*price_weight
                segments[i,price] = (raw/(t*size(price)),raw/size(price))
                selected.append(price)
            if not segments:
                continue
            row = []
            for q,f,h,_,_ in linear_slabs(segments):
                # Independent true mu in (w+c_i-E_i), without using the divided path weights.
                density = tuple(ss(mu(meet(z,(w-deltas[i],w+deltas[i]))) for z in selected)/
                                owner_volumes[i] for w in q)
                assert tuple(f)==tuple(coefficient*x for x in density)
                if not any(h):
                    continue
                O = octaves[i]
                Wo = W(sum(q)/2,octave=O)
                assert Wo>alpha and all(0<=b<=Wo*a for a,b in zip(f,h))
                assert size(meet(q,expansions[i]))==size(q)
                row.append((q,density,f,h))
            assert row
            histories_geometry[e] = (segments,row)

        tail_square = {}
        for O in sorted(set(octaves)):
            ends = sorted({z for i,p_i in enumerate(expansions) if octaves[i]==O for z in p_i})
            tail_square[O] = ss((b-a)*w**2 for a,b in zip(ends,ends[1:])
                                if (w:=W((a+b)/2,octave=O))>alpha)

        def accepted_fraction(D,level):
            if max(D)<=level:
                return F(0),F(1)
            if min(D)>level:
                return F(0),F(0)
            split = (level-D[0])/(D[1]-D[0])
            assert 0<=split<=1
            return (F(0),split) if D[0]<=level else (split,F(1))

        def integrate(q,density,l,r):
            return size(q)*(r-l)*(2*density[0]+(l+r)*(density[1]-density[0]))/2

        tests = []
        all_high_load_mass = None
        for level in map(F,("3/4","1","9/8","5/4")):
            geometry = {}
            by_octave = defaultdict(lambda:[F(0),F(0)])
            for e,(segments,slabs) in histories_geometry.items():
                passed,failed = [],[]
                total = paid = divided_paid = F(0)
                for q,D,f,h in slabs:
                    l,r = accepted_fraction(D,level)
                    total += integrate(q,h,0,1)
                    paid += integrate(q,h,l,r)
                    divided_paid += integrate(q,f,l,r)
                    if r>l:
                        passed.append((q[0]+size(q)*l,q[0]+size(q)*r))
                    if l:
                        failed.append((q[0],q[0]+size(q)*l))
                    if r<1:
                        failed.append((q[0]+size(q)*r,q[1]))
                low,high = merged(passed),merged(failed)
                assert (divided_paid,paid)==fubini_gate(segments,low)
                assert 0<=paid<=total
                O = octaves[labels[e]]
                by_octave[O][0] += paid
                by_octave[O][1] += total-paid
                geometry[e] = (low,high,total,paid,divided_paid)
            mixing_witness = None
            for e,u in product(geometry,repeat=2):
                if e==u or labels[e]!=labels[u]:
                    continue
                candidates = [meet(s,t) for s,t in product(geometry[e][0],geometry[u][1])]
                positive = next((z for z in candidates if size(z)),None)
                if positive:
                    mark = sum(positive)/2
                    samples = []
                    for history in (e,u):
                        q,D,_,h = next(row for row in histories_geometry[history][1]
                                       if row[0][0]<=mark<=row[0][1])
                        weight = (mark-q[0])/size(q)
                        samples.append((D[0]+weight*(D[1]-D[0]),h[0]+weight*(h[1]-h[0])))
                    assert 0<samples[0][0]<=level<samples[1][0] and all(p[1]>0 for p in samples)
                    mixing_witness={"passes_history":e,"fails_history":u,"shared_parent":labels[e],
                                    "open_price_shift_interval":positive,"actual_shift_point":mark,
                                    "D_and_true_density_at_point_by_history":samples}
                    break
            paid = ss(w[0] for w in by_octave.values())
            failed = ss(w[1] for w in by_octave.values())
            for O,(pmt,_) in by_octave.items():
                assert pmt<=level*tail_square[O]
            assert paid<=level*ss(tail_square.values())
            if all_high_load_mass is None:
                all_high_load_mass = paid+failed
            assert all_high_load_mass==paid+failed
            tests.append({"local_density_threshold":level,"true_payment":paid,"true_residual":failed,
                          "tail_square_total_budget":level*ss(tail_square.values()),
                          "paid_residual_by_octave":by_octave,
                          "raw_paid_divided_paid_by_history":{e:entry[2:] for e,entry in geometry.items()},
                          "same_physical_parent_different_gate_witness":mixing_witness})
        assert 0<all_high_load_mass<Q
        assert sum(bool(row["true_payment"] and row["true_residual"]) for row in tests)==3
        assert boundary_mass>0
        return {"raw_price_load_threshold":alpha,"raw_price_load_atoms_exactly_on_threshold":boundary_atoms,
                "raw_price_load_mass_exactly_on_strict_threshold":boundary_mass,
                "reference":"full true source, no earlier crop; D_e is the true mu on w+c_i-E_i over v_i",
                "positive_original_high_load_mass":all_high_load_mass,
                "raw_mass_excluded_by_strict_original_load_gate":Q-all_high_load_mass,
                "positive_histories":len(histories_geometry),"tail_square_by_octave":tail_square,
                "gates":tests}

    full,bounded = one_case(False),one_case(True)
    assert 0<bounded["area_undivided"]<full["area_undivided"]
    assert 0<bounded["area_dividing_by_original_t"]<full["area_dividing_by_original_t"]
    witness = max((deltas[i]/deltas[k],i,k) for i,k in product(range(len(A)),repeat=2)
                  if octaves[i]==octaves[k])
    ratio,i,k=witness
    assert 1<ratio<2
    return {"scope":"true 1D R774 hard graph without upstream terminal screens; W_plus combines both octaves",
            "price_load":"original sum over the downhill hard neighbors of each middle history, retained on the price-cropped case",
            "owner_shift":"true uniform owner E_i of the middle history; shift by the sampled owner minus its center",
            "full_parent_support_shift_example":{"owner_parent":i,"price_parent":k,
                "radius_ratio_as_required_expansion_coefficient":ratio,
                "price_parent_upper_boundary":A[k][1],
                "outer_shifted_boundary":A[k][1]+deltas[i],
                "under_1_plus_1_over_a_boundary":A[k][1]+deltas[k],
                "under_1_plus_2_over_a_boundary":A[k][1]+2*deltas[k]},
            "cases":[full,bounded],"octave_weight_tail_moment_checks":octave_tail(),
            "new_local_density_gate":local_density_gate()}


if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model",default=DEFAULT_MODEL,type=Path)
    arguments=parser.parse_args()
    print(json.dumps({"python":sys.version.split()[0],"command":"python -B shift775.py",
                      "arithmetic":"Fraction","dependency_sha256":MODEL_SHA,
                      "certification":cert(load_model(arguments.model))},
                     sort_keys=True,indent=2,default=str))
