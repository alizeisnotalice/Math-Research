#!/usr/bin/env python3
"""Exact strict-rank selection for two genuine price arms of the R774 finite model."""
import argparse
import hashlib
import json
from collections import defaultdict
from fractions import Fraction as F
from pathlib import Path

DIGEST = "8fdd6ddf88d8b2b8a8be4bac44199ba8cff67aa153cca624420bff0d641d78d2"


def run(model):
    src = model.read_bytes()
    if hashlib.sha256(src).hexdigest() != DIGEST:
        raise ValueError("R774 model digest mismatch")
    mod = {"__name__": "r774_frozen", "__file__": str(model)}
    exec(compile(src, str(model), "exec"), mod)
    (_, _, octaves, _, _, _, _, labels, mass, block, states, _, kernel, volume,
     degree, _, p, _, cells, _, _, q, _, _) = mod["make_model"]()
    mu = mod["density_integral"]
    zero = F(0)
    out = {}
    for tau in (F(1,32), F(1,16), F(1,8), F(1,4)):
        original = defaultdict(F)
        high = defaultdict(F)
        corrected = defaultdict(F)
        reference = defaultdict(F)
        loss = zero
        ceiling = zero
        max_atom_used = zero
        low_positive_roots = 0
        for lo, hi in cells:
            x = (lo + hi) / 2
            dm = mu((lo, hi))
            for octv in sorted(set(octaves)):
                h = {s:mass[s]/volume(s) for s in states
                     if octaves[labels[s]] == octv and block[s][0] < x < block[s][1]}
                H = sum(h.values(), zero)
                for u in h:
                    eta = {e:h[e]*p[e] for e in h if kernel[e,u] and volume(e)>volume(u)}
                    by_volume = defaultdict(F)
                    for e, weight in eta.items():
                        by_volume[volume(e)] += weight
                    atom = max(by_volume.values(), default=zero)
                    deleted = zero
                    for e in eta:
                        lower = {v:w for v,w in eta.items() if volume(v)<volume(e)}
                        t = sum(lower.values(), zero)
                        base = dm*h[u]
                        original[e] += base
                        if t < tau*H:
                            deleted += eta[e]
                        else:
                            high[e] += base
                        for v, w in lower.items():
                            if kernel[e,v]:
                                reference[e,v] += base*w/H
                                if t >= tau*H:
                                    corrected[e,v] += base*w/t
                    assert deleted <= tau*H+atom
                    if deleted>tau*H:
                        low_positive_roots += 1
                        max_atom_used = max(max_atom_used, (deleted-tau*H)/atom)
                    loss += dm*h[u]*deleted
                    ceiling += dm*h[u]*(tau*H+atom)
        def peaks(sides):
            return sum((mass[e]*sides[e]**2/(volume(e)**2*degree[e]) for e in states), zero)
        hard = {e:sum((corrected[e,v] for v in states),zero) for e in states}
        side_loss = sum((mass[e]*original[e]*(original[e]-high[e])/
                         (volume(e)**2*degree[e]) for e in states),zero)
        assert q == peaks(original) and side_loss == loss <= ceiling
        qhi, qok = peaks(high), peaks(hard)
        assert 0 <= qok <= qhi <= q and q-qhi <= 2*loss
        ratios=[]
        for e in states:
            for v in states:
                if corrected[e,v]:
                    ratios.append(corrected[e,v]/reference[e,v])
        assert all(tau*x<=1 for x in ratios)
        out[str(tau)] = {
            "all_local_peaks": str(q), "one_side_removed": str(loss),
            "two_sides_both_above_rank_threshold":str(qhi),
            "both_new_edges_hard_strictly_down":str(qok),
            "strict_rank_bound":str(ceiling),
            "root_cells_requiring_atom_term":low_positive_roots,
            "largest_fraction_of_atom_used":str(max_atom_used),
            "largest_positive_single_arm_coefficient_ratio":str(max(ratios,default=zero))
        }
    return out


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model",required=True,type=Path)
    arg = parser.parse_args()
    print(json.dumps(run(arg.model), indent=2, sort_keys=True))
