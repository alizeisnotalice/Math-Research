"""Exact common-center and endpoint-local Hilbert checks for round 833.

Replay from the same directory as row833.py:
  python3 -B joint833.py --archive /path/to/814/research.zip --prior /path/to/832/research.zip

All original row weights, source-cell means, coordinate hulls, projections
and graph-cut arithmetic are rational. The reference real source may range
over an entire positive-width cell. Its centroid is only used to choose a
fixed predictor allowed by the corresponding endpoint label.
"""

import argparse
from collections import defaultdict, deque
from fractions import Fraction as F
from functools import cache
from hashlib import sha256
from itertools import product
from pathlib import Path
from zipfile import ZipFile

from row833 import PRIOR_PIN, ROUNDS, interval_text, marginals


def sign(x):
    return (x > 0) - (x < 0)


def profile_mean(profile):
    return sum((hi**2 - lo**2) * weight / 2 for lo, hi, weight in profile)


def conditional_mean_labels(rows, profiles, dimension):
    masks = {arm[1] for _, x, y in rows for arm in (x, y)}
    means = {mask: tuple(profile_mean(profiles[axis, mask]) for axis in range(dimension))
             for mask in masks}
    weights_left, weights_right = defaultdict(F), defaultdict(F)
    sums_left, sums_right = defaultdict(lambda: [F(0)] * dimension), defaultdict(lambda: [F(0)] * dimension)
    for (_, x, y), weight in rows.items():
        weights_left[x] += weight
        weights_right[y] += weight
        for i, (z, q) in enumerate(zip(means[x[1]], means[y[1]], strict=True)):
            sums_left[x][i] += weight * (z - q)
            sums_right[y][i] += weight * (z - q)
    assert weights_left == weights_right
    # Each key is its own old physical parent and true source-cell label.
    # In particular current t was summed out before choosing either rule.
    left = {x: tuple(sign(v / weights_left[x]) for v in delta) for x, delta in sums_left.items()}
    right = {y: tuple(sign(v / weights_right[y]) for v in delta) for y, delta in sums_right.items()}
    assert all(left[x] == tuple(-s for s in right[x]) for x in left)
    return left, right


def absolute(interval):
    lo, hi = interval
    return (min(abs(lo), abs(hi)) if lo * hi > 0 else F(0), max(abs(lo), abs(hi)))


def scaled(interval, scalar):
    return tuple(sorted(x * scalar for x in interval))


def summed(a, b):
    return tuple(x + y for x, y in zip(a, b, strict=True))


def scalar_point(r, a, u, v):
    w = sum(d * (x + y) / 2 for d, x, y in zip(r, u, v, strict=True))
    radius = sum((1 - abs(d)) * abs(x - y) / 2 for d, x, y in zip(r, u, v, strict=True))
    assert all(2 * abs(x) <= 1 - abs(d) for x, d in zip(a, r, strict=True))
    diff = w + sum(alpha * (x - y) for alpha, x, y in zip(a, u, v, strict=True))
    j = max(F(0), abs(w) - radius)
    assert j <= abs(diff) <= abs(w) + radius
    return j, abs(diff)


def scalar_box(cube, z_hull, q_hull, b, left, right):
    w, radius, signed_diff = (F(0), F(0)), (F(0), F(0)), (F(0), F(0))
    axis_data = []
    for (t0, t1), z, q, u, v in zip(cube, z_hull, q_hull, right, left, strict=True):
        c = (t0 + t1) / 2
        assert t1 - t0 == b and t0 <= z[0] < z[1] <= t1 and t0 <= q[0] < q[1] <= t1
        r = ((z[0] - q[1]) / b, (z[1] - q[0]) / b)
        assert -1 <= r[0] <= r[1] <= 1
        abs_r = absolute(r)
        w = summed(w, scaled(r, F(u + v, 2)))
        radius = summed(radius, scaled((1 - abs_r[1], 1 - abs_r[0]), F(abs(u - v), 2)))
        cq, cz = ((c - q[1]) / b, (c - q[0]) / b), ((c - z[1]) / b, (c - z[0]) / b)
        signed_diff = summed(signed_diff, summed(scaled(cq, u), scaled(cz, -v)))

        # Pointwise co-containment certificate, valid throughout the hull:
        # 2 alpha + r = 2(c-q)/b, 2 alpha-r=2(c-z)/b. Bounding both
        # quantities (and their negatives) by 1 certifies 2|alpha|+|r|<=1.
        assert all(-F(1, 2) <= lo <= hi <= F(1, 2) for lo, hi in (cq, cz))
        axis_data.append((c, z, q, u, v))

    w_abs = absolute(w)
    lo = max(F(0), w_abs[0] - radius[1])
    hi = max(F(0), w_abs[1] - radius[0])
    d_lo, d_hi = absolute(signed_diff)
    assert d_hi >= lo and hi >= lo and d_hi >= d_lo

    # Independent direct samples use the two opposite hull schemes and
    # centers. The certificate above, rather than these samples, covers all q,z.
    for az, aq in ((F(0), F(1)), (F(1), F(0)), (F(1, 2), F(1, 2))):
        ss, aa, pr, pl = [], [], F(0), F(0)
        for c, z, q, u, v in axis_data:
            z0, q0 = z[0] + az * (z[1] - z[0]), q[0] + aq * (q[1] - q[0])
            ss.append((z0 - q0) / b)
            aa.append((c - (z0 + q0) / 2) / b)
            pr += u * (c - q0) / b
            pl += v * (c - z0) / b
        j, diff = scalar_point(ss, aa, right, left)
        assert diff == abs(pr - pl)
        assert lo <= j <= hi and d_lo <= diff <= d_hi
    return (lo, min(hi, d_hi)), (max(lo, d_lo), d_hi)


def weighted_exact_net(rows, cubes, sides, profiles, left, right):
    value = F(0)
    for (t, x, y), weight in rows.items():
        for i, (u, v) in enumerate(zip(right[y], left[x], strict=True)):
            lo, hi = cubes[t][i]
            mean, mean_abs = graph_pair_expectation(
                profiles[i, x[1]], profiles[i, y[1]], sides[t], lo, hi
            )
            value += weight * (mean * (u + v) - (1 - mean_abs) * abs(u - v)) / 2
    return value


def report_boxes(name, rows, cubes, sides, signed_hulls, profiles, left, right, graph_net=None):
    mother = sum(rows.values())
    total_j, total_d = (F(0), F(0)), (F(0), F(0))
    positive_j_mass, zero_j_mass = F(0), F(0)
    positive_j, positive_d, zero_j = 0, 0, 0
    largest = F(0)
    for (t, x, y), weight in rows.items():
        j, d = scalar_box(cubes[t], signed_hulls[x[1]], signed_hulls[y[1]], sides[t],
                          left[x], right[y])
        total_j = summed(total_j, scaled(j, weight))
        total_d = summed(total_d, scaled(d, weight))
        positive_j += j[0] > 0
        zero_j += j[1] == 0
        positive_d += d[0] > 0
        positive_j_mass += weight * (j[0] > 0)
        zero_j_mass += weight * (j[1] == 0)
        largest = max(largest, j[1])
    signed = weighted_exact_net(rows, cubes, sides, profiles, left, right)
    if graph_net is not None:
        assert signed == graph_net
    lo_j = max(total_j[0], signed)
    lo_d = max(total_d[0], signed)
    assert 0 <= lo_j <= total_j[1] and 0 <= lo_d <= total_d[1]
    print("POINTWISE GEOMETRY", name, "rows", len(rows), "strict-J hulls", positive_j,
          "zero-J hulls", zero_j, "undetermined-J hulls", len(rows) - positive_j - zero_j,
          "strict-P-difference hulls", positive_d)
    print("  mother-normalized", {
        "guaranteed positive J mass": interval_text((positive_j_mass / mother,) * 2, 18),
        "possible positive J mass": interval_text((1 - zero_j_mass / mother,) * 2, 18),
        "E J": interval_text((lo_j / mother, total_j[1] / mother), 18),
        "E |P_R-P_L|": interval_text((lo_d / mother, total_d[1] / mother), 18),
        "E signed lower predictor": interval_text((signed / mother,) * 2, 18),
        "sup J upper bound": interval_text((largest,) * 2, 18),
    })
    assert largest <= len(next(iter(cubes.values())))


def dot(a, b):
    return sum(x * y for x, y in zip(a, b, strict=True))


def vadd(a, b):
    return tuple(x + y for x, y in zip(a, b, strict=True))


def vscale(c, a):
    return tuple(c * x for x in a)


def hilbert_synthetic():
    # Two-coordinate physical cube in a separate two-dimensional Hilbert
    # space for the projected predictors, with an axis-aligned zonotope.
    # q=(-1/4,-1/4), z=(1/4,1/4), b=1, r_i=1/2.
    q, z = (F(-1, 4),) * 2, (F(1, 4),) * 2
    u = ((F(2, 3), F(1, 3)), (F(1, 3), F(2, 3)))
    v = ((F(0), F(1, 3)), (F(1, 3), F(0)))
    w = (F(1, 3), F(1, 3))
    zonotope_axes = ((F(1, 6), F(0)), (F(0), F(1, 6)))
    assert zonotope_axes == tuple(vscale(F(1, 4), vadd(ui, vscale(-1, vi)))
                                 for ui, vi in zip(u, v, strict=True))
    closest = vadd(*zonotope_axes)
    assert closest == (F(1, 6), F(1, 6))
    residual = vadd(w, vscale(-1, closest))
    distance_sq = dot(residual, residual)
    assert distance_sq == F(1, 18)

    # Exact dual support calculation with the unnormalized maximizer h.
    h = (F(1), F(1))
    dual_numerator = dot(h, w) - sum(abs(dot(h, axis)) for axis in zonotope_axes)
    assert dual_numerator > 0 and dual_numerator**2 / dot(h, h) == distance_sq
    for a, b in product(range(-3, 4), repeat=2):
        g = (F(a), F(b))
        gap = max(F(0), dot(g, w) - sum(abs(dot(g, axis)) for axis in zonotope_axes))
        assert gap**2 <= dot(g, g) * distance_sq

    for center, expected_norm_sq in (
        ((F(0), F(0)), F(2, 9)),
        (q, distance_sq),
        (z, F(1, 2)),
    ):
        pr, pl, alpha_sum, w_rebuilt = ((F(0), F(0)),) * 4
        for qi, zi, ci, ui, vi in zip(q, z, center, u, v, strict=True):
            assert max(abs(ci - qi), abs(ci - zi)) <= F(1, 2)
            ri, alpha = zi - qi, ci - (zi + qi) / 2
            assert abs(alpha) <= (1 - abs(ri)) / 2
            pr = vadd(pr, vscale(ci - qi, ui))
            pl = vadd(pl, vscale(ci - zi, vi))
            w_rebuilt = vadd(w_rebuilt, vscale(ri / 2, vadd(ui, vi)))
            alpha_sum = vadd(alpha_sum, vscale(alpha, vadd(ui, vscale(-1, vi))))
        diff = vadd(pr, vscale(-1, pl))
        assert w_rebuilt == w and vadd(w, alpha_sum) == diff
        assert dot(diff, diff) == expected_norm_sq >= distance_sq
        assert dot(pr, pr) <= sum(dot(x, x) for x in u) * sum((a-b)**2 for a,b in zip(center, q))
        assert dot(pl, pl) <= sum(dot(x, x) for x in v) * sum((a-b)**2 for a,b in zip(center, z))
    print("VECTOR ZONOTOPE", "Q^2", "W", w, "closest point", closest,
          "projection distance squared", distance_sq,
          "squared differences at (midpoint,q,z)", (F(2, 9), distance_sq, F(1, 2)))

    # Positive-width real endpoint boxes inside a side-one physical cube.
    # Work with one coordinate and exact multiplicity in large dimensions.
    current = ((F(-1, 2), F(1, 2)),)
    qbox = ((F(-9, 32), F(-7, 32)),)
    zbox = ((F(7, 32), F(9, 32)),)
    # All endpoint choices also fit for all centers in this positive-width box.
    centers = (F(-7, 32), F(7, 32))
    assert all(abs(endpoint - center) <= F(1, 2)
               for endpoint, center in product((*qbox[0], *zbox[0]), centers))
    aligned, same_diff = scalar_box(current, zbox, qbox, F(1), (1,), (1,))
    opposed, _ = scalar_box(current, zbox, qbox, F(1), (-1,), (1,))
    assert aligned == same_diff == (F(7, 16), F(9, 16))
    assert opposed == (0, 0)
    assert scalar_point((F(1, 2),), (F(0),), (1,), (1,)) == (F(1, 2), F(1, 2))
    for n in (16, 4096, 16384, 65536):
        low, high = (n * val for val in aligned)
        # Each predictor's norm is sqrt(n), so the sum squared is 4n.
        print("POSITIVE-WIDTH CUBES", n, "each endpoint box volume", f"(1/16)^{n}",
              "J aligned at central offsets", F(n, 2), "J range", (low, high),
              "J opposed", 0, "(B_R+B_L)^2", 4*n,
              "common-center box volume", f"(7/16)^{n}")


def graph_loss(edges, left_labels, right_labels):
    return sum(
        w * (s - r * (left_labels[left] + right_labels[right]) / 2
             + (1-s) * (left_labels[left] != right_labels[right]))
        for left, right, w, r, s in edges
    )


def graph_exact_cut(edges):
    """Minimize the integrated signed loss via an exact max-flow/min-cut."""
    edges = tuple(edges)
    assert edges and all(isinstance(w, F) and isinstance(r, F) and isinstance(s, F)
                         and w > 0 and abs(r) <= s <= 1 for _, _, w, r, s in edges)
    capacity = defaultdict(lambda: defaultdict(F))
    fields = defaultdict(F)
    span = sum(w * s for _, _, w, _, s in edges)

    def arc(u, v, value):
        if value:
            capacity[u][v] += value
            capacity[v][u] += F(0)

    source, sink = (-1, None), (-2, None)
    capacity[source], capacity[sink] = defaultdict(F), defaultdict(F)
    for left, right, weight, signed, absolute in edges:
        u, v = (0, left), (1, right)
        fields[u] += weight * signed / 2
        fields[v] += weight * signed / 2
        disagreement = weight * (1 - absolute)
        arc(u, v, disagreement)
        arc(v, u, disagreement)
        capacity[u]
        capacity[v]

    field_sum = sum(map(abs, fields.values()))
    assert 0 <= field_sum <= span
    for node, field in fields.items():
        if field > 0:
            arc(source, node, 2 * field)
        elif field < 0:
            arc(node, sink, -2 * field)

    residual = {u: dict(adjacent) for u, adjacent in capacity.items()}
    flow_value = F(0)
    while True:
        visited = {source: None}
        queue = deque([source])
        while queue and sink not in visited:
            u = queue.popleft()
            for v, spare in residual[u].items():
                if spare > 0 and v not in visited:
                    visited[v] = u
                    queue.append(v)
        if sink not in visited:
            break
        path = []
        v = sink
        while v != source:
            u = visited[v]
            path.append((u, v))
            v = u
        flow = min(residual[u][v] for u, v in path)
        assert flow > 0
        for u, v in path:
            residual[u][v] -= flow
            residual[v][u] += flow
        flow_value += flow

    # Independent feasible dual and matching cut, even with antiparallel arcs.
    for u, adjacent in capacity.items():
        net_out = F(0)
        for v, cap in adjacent.items():
            flow = cap - residual[u][v]
            reverse = capacity[v][u] - residual[v][u]
            assert -capacity[v][u] <= flow <= cap and flow == -reverse
            net_out += flow
        expected = flow_value if u == source else -flow_value if u == sink else F(0)
        assert net_out == expected
    cut = sum(cap for u in visited for v, cap in capacity[u].items() if v not in visited)
    assert cut == flow_value

    left_labels = {label: (1 if (side, label) in visited else -1)
                   for side, label in fields if side == 0}
    right_labels = {label: (1 if (side, label) in visited else -1)
                    for side, label in fields if side == 1}
    loss = graph_loss(edges, left_labels, right_labels)
    assert loss == span - field_sum + cut
    assert 0 <= loss <= span  # A global sign reaches loss <= span.
    return {
        "span": span,
        "loss": loss,
        "net": span - loss,
        "field_sum": field_sum,
        "cut": cut,
        "left": left_labels,
        "right": right_labels,
    }


@cache
def graph_pair_expectation(left_profile, right_profile, side, lo, hi):
    assert hi - lo == side > 0
    for profile in (left_profile, right_profile):
        assert all(lo <= l < h <= hi and d > 0 for l, h, d in profile)
        assert sum((h-l) * d for l, h, d in profile) == 1
    left_mean = sum((h*h-l*l) * d / 2 for l, h, d in left_profile)
    right_mean = sum((h*h-l*l) * d / 2 for l, h, d in right_profile)
    signed = (left_mean - right_mean) / side

    absolute = F(0)
    for (zl, zh, zw), (ql, qh, qw) in product(left_profile, right_profile):
        # Mixed rectangular primitive of |z-q| is -|z-q|^3/6.
        integral = (abs(zh-ql)**3 + abs(zl-qh)**3 -
                    abs(zh-qh)**3 - abs(zl-ql)**3) / 6
        assert 0 <= integral <= side * (zh-zl) * (qh-ql)
        absolute += zw * qw * integral / side
    assert abs(signed) <= absolute <= 1
    return signed, absolute


def graph_fixture(name, cubes, sides, rows, profiles):
    """Consume row833 profiles indexed by (axis, true source mask)."""
    assert all(weight > 0 and rows[t, right, left] == weight
               for (t, left, right), weight in rows.items())
    total_mass = sum(rows.values())
    dimension = len(next(iter(cubes.values())))
    all_axis = []
    for axis in range(dimension):
        edges = []
        for (t, left, right), weight in rows.items():
            lo, hi = cubes[t][axis]
            r, s = graph_pair_expectation(
                profiles[axis, left[1]], profiles[axis, right[1]], sides[t], lo, hi
            )
            edges.append((left, right, weight, r, s))
        assert sum(w * r for _, _, w, r, _ in edges) == 0
        all_axis.append(graph_exact_cut(edges))

    span, loss, net, fields, cuts = (
        sum(axis[k] for axis in all_axis)
        for k in ("span", "loss", "net", "field_sum", "cut")
    )
    assert net == span - loss == fields - cuts
    assert span > 0
    print("EXACT ENDPOINT GRAPH", name, "rows", len(rows),
          "left/right labels", (len(all_axis[0]["left"]), len(all_axis[0]["right"])),
          "mass", total_mass)
    print("  mass-normalized",
          {k: format(float(x/total_mass), ".12g") for k, x in (
              ("span", span), ("loss", loss), ("net", net),
              ("field_sum", fields), ("cut", cuts))},
          "net/span", format(float(net/span), ".12g"),
          "loss/span", format(float(loss/span), ".12g"))
    for i, axis in enumerate(all_axis, start=1):
        print("  axis", i, "span", format(float(axis["span"]/total_mass), ".12g"),
              "loss", format(float(axis["loss"]/total_mass), ".12g"),
              "field_sum", format(float(axis["field_sum"]/total_mass), ".12g"),
              "cut", format(float(axis["cut"]/total_mass), ".12g"),
              "net", format(float(axis["net"]/total_mass), ".12g"),
              "net=0 exact", axis["net"] == 0)
    return all_axis


def graph_synthetic_checks():
    uniform = ((F(0), F(1), F(1)),)
    lower = ((F(0), F(1, 4), F(4)),)
    upper = ((F(3, 4), F(1), F(4)),)
    assert graph_pair_expectation(uniform, uniform, F(1), F(0), F(1)) == (0, F(1, 3))
    assert graph_pair_expectation(upper, lower, F(1), F(0), F(1)) == (F(3, 4), F(3, 4))
    positive = (
        ("x", "a", F(1), F(1), F(1)),
        ("y", "a", F(1), F(1), F(1)),
    )
    symmetric = (
        ("x", "y", F(1), F(1, 4), F(1, 2)),
        ("y", "x", F(1), F(-1, 4), F(1, 2)),
        ("x", "x", F(1), F(0), F(1, 3)),
        ("y", "y", F(1), F(0), F(1, 3)),
    )
    asymmetric = (
        ("x", "y", F(1), F(3, 4), F(3, 4)),
        ("x", "x", F(1, 2), F(-1, 4), F(1, 2)),
        ("y", "x", F(1), F(-3, 4), F(3, 4)),
    )
    for name, edges, expected in (
        ("positive boundary", positive, (F(2), F(0), F(2))),
        ("symmetric shared arms", symmetric, (F(5, 3), F(5, 3), F(0))),
        ("asymmetric competing arms", asymmetric, None),
    ):
        solution = graph_exact_cut(edges)
        choices = tuple((0, k) for k in solution["left"]) + tuple((1, k) for k in solution["right"])
        brute = None
        for labels in product((-1, 1), repeat=len(choices)):
            assignment = dict(zip(choices, labels, strict=True))
            loss = graph_loss(edges, {k: assignment[0, k] for k in solution["left"]},
                              {k: assignment[1, k] for k in solution["right"]})
            brute = loss if brute is None else min(brute, loss)
        assert brute == solution["loss"]
        totals = tuple(solution[k] for k in ("span", "loss", "net"))
        if expected is not None:
            assert totals == expected
        print("SYNTHETIC ENDPOINT GRAPH", name, "span/loss/net", *(str(x) for x in totals))


def run_fixture(name, stage, prior):
    cubes, sides, _, _, true_hulls, rows = prior["verified_rows"](stage)
    mu = {c["mask"]: F(c["mass"]) for c in stage["cells"] if F(c["mass"]) > 0}
    active = {arm[1] for _, left, right in rows for arm in (left, right)}
    dimension = len(next(iter(cubes.values())))
    profiles = marginals(tuple(cubes.values()), stage["density"], mu, active)
    exact_hulls = {cell: tuple((profiles[i, cell][0][0], profiles[i, cell][-1][1])
                              for i in range(dimension)) for cell in active}
    assert all(true_hulls[cell] == exact_hulls[cell] for cell in active)
    assert dimension == 4
    assert all(F(1) <= sides[t] / 2 < F(2) for t, _, _ in rows)
    # In four dimensions J <= |W| <= sqrt(4)/2 * (B_R+B_L).
    # The examples cannot meet any large-dimension gate requiring a
    # strictly larger ratio than that, regardless of all other filters.
    print("TRUE FIXTURE", name, "positive rows", len(rows), "left/right source-support hulls", len(active),
          "dimension", dimension, "common physical radius octave [1,2)",
          "J/(B_R+B_L) at most 1; no high-dimensional gate claimed")
    left, right = conditional_mean_labels(rows, profiles, dimension)
    report_boxes(name + " conditional centroid directions", rows, cubes, sides, exact_hulls,
                 profiles, left, right)
    axes = graph_fixture(name, cubes, sides, rows, profiles)
    graph_left = {x: tuple(a["left"][x] for a in axes) for x in left}
    graph_right = {y: tuple(a["right"][y] for a in axes) for y in right}
    report_boxes(name + " graph-optimized directions", rows, cubes, sides, exact_hulls,
                 profiles, graph_left, graph_right, sum(a["net"] for a in axes))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--archive", type=Path, default=ROUNDS / "814/research.zip")
    parser.add_argument("--prior", type=Path, default=ROUNDS / "832/research.zip")
    args = parser.parse_args()
    assert sha256(args.prior.read_bytes()).hexdigest() == PRIOR_PIN
    with ZipFile(args.prior) as archive:
        code = archive.read("foot832.py")
    print("PRIOR SHA256", PRIOR_PIN, "foot832.py", sha256(code).hexdigest())
    prior = {"__name__": "archived_foot832"}
    exec(compile(code, "foot832.py", "exec"), prior)
    hilbert_synthetic()
    graph_synthetic_checks()
    for name, stage in prior["fixtures"](args.archive):
        run_fixture(name, stage, prior)
    print("PASS common-center identity, interval gates, Hilbert projection and exact graph cuts")


if __name__ == "__main__":
    main()
