"""Certified continuous coordinate integrals on the two R814 four-dimensional flows.

  python3 -B row833.py --archive /path/to/814/research.zip \\
      --prior /path/to/832/research.zip

The current original row keeps its full weight. At the same complete true
right arm Y=(g,q,W), draw the partner z from the original whole-flow left
marginal at Y. The right factor is common on each true q-mask and owner E_g,
so the partner law is constant on that right cell, while q is still integrated
with the exact continuous source density. Receiver laws stay unchanged.
"""

import argparse
from collections import defaultdict
from decimal import Context, Decimal, ROUND_CEILING, ROUND_FLOOR, ROUND_HALF_EVEN
from fractions import Fraction as F
from functools import cache
from hashlib import sha256
from itertools import product
from pathlib import Path
from zipfile import ZipFile


ROUNDS = Path(
    "/Volumes/data/CodexProjects/T/Math-Research-cube-sqrt-20261114/"
    "centered-cube-upper-bound/rounds"
)
PRIOR_PIN = "3eef2e83aab159531aa5b1049715568779e8c599998dde494ce0ea0e238c0303"
LOG_FLOOR = Context(prec=55, rounding=ROUND_FLOOR)
LOG_CEIL = Context(prec=55, rounding=ROUND_CEILING)
LOG_NEAR = Context(prec=55, rounding=ROUND_HALF_EVEN)
ZERO = (F(0), F(0))


@cache
def logarithm(x):
    assert x > 0
    if x == 1:
        return ZERO
    num, den = Decimal(x.numerator), Decimal(x.denominator)
    lo = LOG_NEAR.ln(LOG_FLOOR.divide(num, den))
    hi = LOG_NEAR.ln(LOG_CEIL.divide(num, den))
    return F(LOG_FLOOR.next_minus(lo)), F(LOG_CEIL.next_plus(hi))


def add(a, b):
    return a[0] + b[0], a[1] + b[1]


def difference(a, b):
    return a[0] - b[1], a[1] - b[0]


def scale(x, a):
    lo, hi = a if x >= 0 else reversed(a)
    return x * lo, x * hi


def bounds(lo, hi, area):
    assert lo <= hi and hi >= 0 and lo <= area
    return max(F(0), lo), min(area, hi)


def rect_difference(primitive, a, b, c, d):
    return difference(add(primitive(b, d), primitive(a, c)),
                      add(primitive(b, c), primitive(a, d)))


@cache
def psi_primitive(s, b):
    """Even second primitive of psi(|s|/b), matching value and slope at |s|=b."""
    if s <= b:
        v = s**3 / (12 * b)
        return v, v
    v = s**2 / 2 - b * s / 4 - b**2 / 6
    return add((v, v), scale(-b * s / 2, logarithm(s / b)))


@cache
def psi_rectangle(q_lo, q_hi, z_lo, z_hi, b):
    interval = rect_difference(lambda q, z: scale(F(-1), psi_primitive(abs(z - q), b)),
                               q_lo, q_hi, z_lo, z_hi)
    return bounds(*interval, (q_hi - q_lo) * (z_hi - z_lo))


@cache
def deficit_primitive(delta, epsilon):
    """Mixed primitive for epsilon/(delta+epsilon), with the zero corner by continuity."""
    if delta == epsilon == 0:
        return ZERO
    v = delta * epsilon / 2
    return add((v, v), scale((epsilon**2 - delta**2) / 2,
                             logarithm(delta + epsilon)))


@cache
def deficit_rectangle(q_lo, q_hi, z_lo, z_hi, a, b):
    assert a <= q_lo < q_hi <= b
    value = ZERO
    if z_hi > b:
        value = add(value, rect_difference(deficit_primitive,
                                            b - q_hi, b - q_lo,
                                            max(z_lo, b) - b, z_hi - b))
    if z_lo < a:
        value = add(value, rect_difference(deficit_primitive,
                                            q_lo - a, q_hi - a,
                                            a - min(z_hi, a), a - z_lo))
    return bounds(*value, (q_hi - q_lo) * (z_hi - z_lo))


def axis_intervals(cubes, axis, density):
    lo, hi = map(F, density["support"])
    period = F(density["period"])
    center = F(density["bump_center_mod_period"])
    half = F(density["bump_half_width"])
    floor = F(density["density_floor_one_axis"])
    peak = F(density["density_peak_one_axis"])
    assert lo < hi and 0 <= center < period and 0 < 2 * half < period
    assert 0 < floor < peak
    cuts = {lo, hi}
    cuts.update(v for box in cubes for v in box[axis] if lo < v < hi)
    for k in range(int(lo // period) - 1, int(hi // period) + 2):
        cuts.update(x for x in (k * period + center - half, k * period + center + half)
                    if lo < x < hi)
    cuts = sorted(cuts)
    intervals = []
    for a, b in zip(cuts, cuts[1:]):
        mid = (a + b) / 2
        level = peak if abs((mid % period) - center) < half else floor
        mask = sum(1 << i for i, box in enumerate(cubes) if box[axis][0] < mid < box[axis][1])
        if intervals and intervals[-1][2:] == (mask, level):
            intervals[-1] = (intervals[-1][0], b, mask, level)
        else:
            intervals.append((a, b, mask, level))
    return intervals


def marginals(cubes, density, mu, active):
    n = len(cubes[0])
    intervals = [axis_intervals(cubes, i, density) for i in range(n)]
    by_axis = []
    for part in intervals:
        masses = defaultdict(F)
        for a, b, mask, level in part:
            masses[mask] += (b - a) * level
        by_axis.append(masses)
    result = {}
    all_bits = (1 << len(cubes)) - 1
    for axis in range(n):
        other = {all_bits: F(1)}
        for j, masses in enumerate(by_axis):
            if j == axis:
                continue
            nxt = defaultdict(F)
            for (x, p), (y, q) in product(other.items(), masses.items()):
                nxt[x & y] += p * q
            other = nxt
        measure = defaultdict(F)
        for support_mask, other_weight in other.items():
            for axis_mask, axis_weight in by_axis[axis].items():
                measure[support_mask & axis_mask] += other_weight * axis_weight
        assert measure == mu
        for key in sorted(active):
            profile = []
            for a, b, mask, level in intervals[axis]:
                weight = level * sum(v for rest, v in other.items() if rest & mask == key) / mu[key]
                if weight == 0:
                    continue
                if profile and profile[-1][1] == a and profile[-1][2] == weight:
                    profile[-1] = (profile[-1][0], b, weight)
                else:
                    profile.append((a, b, weight))
            assert sum((b - a) * weight for a, b, weight in profile) == 1
            result[axis, key] = tuple(profile)
    return result


def interval_text(interval, digits=30):
    scale = 10**digits
    lo, hi = interval
    down = lo.numerator * scale // lo.denominator
    up = -((-hi.numerator * scale) // hi.denominator)
    def text(v):
        sign = "-" if v < 0 else ""
        whole, fractional = divmod(abs(v), scale)
        return f"{sign}{whole}.{fractional:0{digits}d}"
    return f"[{text(down)}, {text(up)}]"


def current_groups(rows):
    by_current, by_partner = defaultdict(F), defaultdict(F)
    for (t, (_, z), y), w in rows.items():
        by_current[t, y] += w
        by_partner[z, y] += w
    right_mass = defaultdict(F)
    partner_mass = defaultdict(F)
    for (_, y), w in by_current.items():
        right_mass[y] += w
    for (_, y), w in by_partner.items():
        partner_mass[y] += w
    assert right_mass == partner_mass
    pi = defaultdict(dict)
    for (z, y), w in by_partner.items():
        pi[y][z] = w / right_mass[y]
    assert all(min(p.values()) > 0 and sum(p.values()) == 1 for p in pi.values())
    return by_current, pi


def run_fixture(name, stage, prior):
    cubes, sides, bins, _, _, rows = prior["verified_rows"](stage)
    parents = {p["id"]: p for p in stage["parents"]}
    mu = {cell["mask"]: F(cell["mass"]) for cell in stage["cells"] if F(cell["mass"]) > 0}
    active = {z for _, (_, z), _ in rows} | {q for _, _, (_, q) in rows}
    profiles = marginals(tuple(cubes.values()), stage["density"], mu, active)
    cur, pi = current_groups(rows)
    total_mass = sum(cur.values())
    assert total_mass == sum(rows.values()) and len(cur) == 32 and len(pi) == 15
    print("FIXTURE", name, "rows", len(rows), "true Y cells", len(pi), "(t,Y) groups", len(cur),
          "mass", total_mass, "actual side", {t: str(sides[t]) for t in stage["middle_labels"]},
          "middle volume bins", {t: str(bins[t]) for t in stage["middle_labels"]})

    @cache
    def pair(t, z, q):
        D, m = ZERO, ZERO
        for axis, (a, b) in enumerate(cubes[t]):
            for (ql, qh, qw), (zl, zh, zw) in product(profiles[axis, q], profiles[axis, z]):
                factor = qw * zw
                D = add(D, scale(factor, deficit_rectangle(ql, qh, zl, zh, a, b)))
                m = add(m, scale(factor, psi_rectangle(ql, qh, zl, zh, sides[t])))
        return D, m

    values = {}
    td, tm = ZERO, ZERO
    outside = F(0)
    for (t, y), w in sorted(cur.items()):
        q = y[1]
        h = parents[t]["bit"]
        assert q & h
        D, m = ZERO, ZERO
        for z, prob in pi[y].items():
            if not z & h:
                outside += w * prob
            x, v = pair(t, z, q)
            assert (x == ZERO) == bool(z & h)
            D, m = add(D, scale(prob, x)), add(m, scale(prob, v))
        values[t, y] = D, m, difference(D, m)
        td, tm = add(td, scale(w, D)), add(tm, scale(w, m))
    avg = tuple(scale(1 / total_mass, v) for v in (td, tm, difference(td, tm)))
    assert all(0 <= lo <= hi <= 4 for lo, hi in avg[:2])
    assert all(hi - lo < F(1, 10**45) for lo, hi in avg)
    print("ORIGINAL MASS WEIGHTED MEAN",
          {k: interval_text(v) for k, v in zip(("D", "m", "D-m"), avg, strict=True)})
    for i, label in enumerate(("D", "m", "D-m")):
        intervals = [(a[i], k) for k, a in values.items()]
        low = (min(v[0] for v, _ in intervals), min(v[1] for v, _ in intervals))
        high = (max(v[0] for v, _ in intervals), max(v[1] for v, _ in intervals))
        print("RANGE OF CELL MEANS", label, "min", interval_text(low),
              "max", interval_text(high))
    print("DEFICIT SIGN", "positive D-m groups", sum(v[2][0] > 0 for v in values.values()),
          "negative D-m groups", sum(v[2][1] < 0 for v in values.values()))
    print("PARTNER OUTSIDE CURRENT CUBE",
          interval_text((outside / total_mass,) * 2))
    example = ("t0", ("u1", 23))
    if example in values:
        print("EXAMPLE", example, {k: interval_text(v)
                  for k, v in zip(("D", "m", "D-m"), values[example], strict=True)})


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--archive", type=Path, default=ROUNDS / "814/research.zip")
    parser.add_argument("--prior", type=Path, default=ROUNDS / "832/research.zip")
    args = parser.parse_args()

    # Two independent integral checks at the kink and at the zero corner.
    assert psi_rectangle(F(0), F(1), F(0), F(1), F(1)) == (F(1, 6),) * 2
    lo, hi = deficit_rectangle(F(0), F(1), F(1), F(2), F(0), F(1))
    assert lo <= F(1, 2) <= hi
    lo, hi = deficit_rectangle(F(0), F(1), F(-1), F(0), F(0), F(1))
    assert lo <= F(1, 2) <= hi

    assert sha256(args.prior.read_bytes()).hexdigest() == PRIOR_PIN
    prior = {"__name__": "archived_foot832"}
    with ZipFile(args.prior) as archive:
        code = archive.read("foot832.py")
    print("PRIOR SHA256", PRIOR_PIN, "foot832.py", sha256(code).hexdigest())
    exec(compile(code, "foot832.py", "exec"), prior)
    for name, stage in prior["fixtures"](args.archive):
        run_fixture(name, stage, prior)
    print("PASS exact original rows and all continuous marginal masses")


if __name__ == "__main__":
    main()

