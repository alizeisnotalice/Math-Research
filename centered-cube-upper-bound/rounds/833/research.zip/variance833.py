"""Exact common-center loss and perturbation checks for round 833.

Run: python3 -B variance833.py
All integrations are exact over a uniformly distributed reference coordinate
U. Coordinates of the reference cube are independent. A menu uses one common
U for all partners, and one partner label may control every axis. All example
menus are explicit discrete measures on real offsets from q=0 with b=1.
Two labels with identical tested one-axis projections can be distinguished by
their distinct offsets in a second axis.
"""

from dataclasses import dataclass
from fractions import Fraction as F
from itertools import product


@dataclass(frozen=True)
class Loss:
    """Clipped loss with affine oriented distance, extending g to all r."""

    length: F
    direction: int = 1
    scale: F = F(1)
    shift: F = F(0)

    def __post_init__(self):
        assert self.length >= 0 and self.direction in (-1, 1) and self.scale > 0

    def value(self, u):
        if not self.length:
            return F(0)
        oriented = u if self.direction == 1 else 1 - u
        distance = self.scale * oriented + self.shift
        return max(F(0), 1 - max(F(0), distance) / self.length)

    def breaks(self):
        if not self.length:
            return set()
        oriented = {(-self.shift) / self.scale, (self.length - self.shift) / self.scale}
        ref = oriented if self.direction == 1 else {1 - x for x in oriented}
        return {u for u in ref if 0 < u < 1}


def integrate(menu):
    """Integrate the mean loss and its square on a shared partition."""
    assert all(weight > 0 for weight, _ in menu) and sum(w for w, _ in menu) == 1
    cuts = sorted({F(0), F(1)}.union(*(loss.breaks() for _, loss in menu)))
    mean, mean2 = F(0), F(0)
    for lo, hi in zip(cuts, cuts[1:]):
        a = sum(weight * loss.value(lo) for weight, loss in menu)
        b = sum(weight * loss.value(hi) for weight, loss in menu)
        mean += (hi - lo) * (a + b) / 2
        mean2 += (hi - lo) * (a * a + a * b + b * b) / 3
    return mean, mean2


def cross(left, right):
    """Integrate the product on the partition of the two component losses."""
    cuts = sorted({F(0), F(1)} | left.breaks() | right.breaks())
    value = F(0)
    for lo, hi in zip(cuts, cuts[1:]):
        a, b = left.value(lo), left.value(hi)
        c, d = right.value(lo), right.value(hi)
        value += (hi - lo) * (2*a*c + a*d + b*c + 2*b*d) / 6
    return value


def menu_stats(menu):
    mean, mean2 = integrate(menu)
    one_means = [integrate(((F(1), loss),))[0] for _, loss in menu]
    cov = {
        (i, k): cross(left, right) - one_means[i] * one_means[k]
        for (i, (_, left)), (k, (_, right)) in product(enumerate(menu), repeat=2)
    }
    var = mean2 - mean**2
    var_av = sum(weight * cov[i, i] for i, (weight, _) in enumerate(menu))
    var_cov = sum(menu[i][0] * menu[k][0] * cov[i, k] for i, k in cov)
    gap = sum(
        menu[i][0] * menu[k][0] * (cov[i, i] + cov[k, k] - 2 * cov[i, k]) / 2
        for i, k in cov
    )
    assert mean == sum(w * mu for (w, _), mu in zip(menu, one_means, strict=True))
    assert 0 <= var == var_cov <= var_av
    assert var_av - var == gap
    for i, (_, loss) in enumerate(menu):
        if loss.scale != 1 or loss.shift:
            continue
        a = loss.length
        if a <= 1:
            assert one_means[i] == a / 2
            assert cov[i, i] == a / 3 - a**2 / 4
        else:
            assert one_means[i] == 1 - 1 / (2*a)
            assert cov[i, i] == F(1, 12) / a**2
    return mean, var, var_av, tuple(one_means), cov


def antipodal(a, same_direction=False):
    return (F(1, 2), Loss(a)), (F(1, 2), Loss(a, 1 if same_direction else -1))


def report_menu(label, menu):
    mu, conditional, averaged, _, cov = menu_stats(menu)
    print(label, {"mean": str(mu), "var_of_menu_mean": str(conditional),
                  "menu_mean_of_variances": str(averaged),
                  "gap": str(averaged - conditional), "cov_first_pair": str(cov[0, 1])})
    return mu, conditional, averaged


def coarse_and_adversarial():
    print("COARSE")
    unit = report_menu("balanced opposite a=1", antipodal(F(1)))
    half = report_menu("balanced opposite a=1/2", antipodal(F(1, 2)))
    long = report_menu("balanced opposite a=3/2", antipodal(F(3, 2)))
    assert unit == (F(1, 2), F(0), F(1, 12))
    assert half == (F(1, 4), F(1, 48), F(5, 48))
    assert long == (F(2, 3), F(0), F(1, 27))

    print("ADVERSARIAL")
    for a, opposite in ((F(1), unit), (F(1, 2), half), (F(3, 2), long)):
        same = report_menu(f"balanced same-direction a={a}", antipodal(a, same_direction=True))
        assert same[0] == opposite[0] and same[1] > opposite[1] and same[2] == opposite[2]
        assert same[1] == same[2]
    mixture = ((F(1, 4), Loss(F(0))), (F(1, 4), Loss(F(2, 3), -1)),
               (F(1, 6), Loss(F(3, 2))), (F(1, 3), Loss(F(3, 4))))
    report_menu("unequal lengths, unequal probabilities, mixed directions and zero", mixture)


def directly_integrate_pair(batch):
    """Exact product Simpson integration of first and second moments."""
    dimension = 2
    cuts = []
    for i in range(dimension):
        parts = sorted({F(0), F(1)}.union(*(legs[i].breaks() for _, legs in batch)))
        cuts.append(tuple(zip(parts, parts[1:])))
    mu, prediction_sq, sampled_sq = F(0), F(0), F(0)
    for cell in product(*cuts):
        node_rules = [
            ((lo, F(1, 6)), ((lo + hi) / 2, F(2, 3)), (hi, F(1, 6)))
            for lo, hi in cell
        ]
        area = (cell[0][1] - cell[0][0]) * (cell[1][1] - cell[1][0])
        for (u, w), (v, z) in product(*node_rules):
            prob = area * w * z
            losses = [(p, first.value(u) + second.value(v)) for p, (first, second) in batch]
            mixture = sum(p*x for p, x in losses)
            mu += prob * mixture
            prediction_sq += prob * mixture**2
            sampled_sq += prob * sum(p*x**2 for p, x in losses)
    return mu, prediction_sq - mu**2, sampled_sq - mu**2


def shared_partner_pair():
    menu = ((F(1, 3), Loss(F(1, 2))), (F(2, 3), Loss(F(3, 2), -1)))
    common = tuple((p, (loss, loss)) for p, loss in menu)
    independent = tuple((p*q, (left, right)) for (p, left), (q, right) in product(menu, repeat=2))
    common_mom = directly_integrate_pair(common)
    independent_mom = directly_integrate_pair(independent)
    assert common_mom == (F(19, 18), F(13, 1944), F(59, 216))
    assert independent_mom == (F(19, 18), F(13, 1944), F(127, 648))
    assert common_mom[2] - independent_mom[2] == 2 * F(25, 648)
    print("DIRECT 2D PRODUCT SIMPSON", {
        "common_label_mean,prediction_variance,random_loss_variance": tuple(map(str, common_mom)),
        "independent_labels_mean,prediction_variance,random_loss_variance": tuple(map(str, independent_mom)),
    })


def shared_partner_batch(n):
    # Pick one label for all n coordinates, never n separate labels in the
    # correlated batch. The same per-axis menu is used in the comparison.
    # E_pi[sum g_i(U_i)] is a sum of functions of independent U_i, even
    # with correlated offsets. For a truly sampled label use total variance.
    menu = ((F(1, 3), Loss(F(1, 2))), (F(2, 3), Loss(F(3, 2), -1)))
    mu, predict_var, mean_var, one_means, _ = menu_stats(menu)
    between = sum(weight * (value - mu)**2
                  for (weight, _), value in zip(menu, one_means, strict=True))
    across_axes_with_same_partner = sum(weight * value**2
                                      for (weight, _), value in zip(menu, one_means, strict=True)) - mu**2
    assert across_axes_with_same_partner == between > 0
    one_axis_random_var = mean_var + between
    independent_partner_var = n * one_axis_random_var
    correlated_partner_var = n * mean_var + n**2 * between
    assert correlated_partner_var == independent_partner_var + n*(n-1)*across_axes_with_same_partner
    assert n*predict_var < n*mean_var < correlated_partner_var
    print("CORRELATED BATCH", n, {"predicted_mean": str(n * mu),
          "var_of_menu_prediction_same_for_both_couplings": str(n * predict_var),
          "mean_fixed_partner_var": str(n * mean_var),
          "random_loss_var_shared_partner": str(correlated_partner_var),
          "random_loss_var_independent_partner_labels": str(independent_partner_var),
          "one_pair_cross_axis_cov_given_common_batch_label_mixture": str(between)})


def grid(n):
    tiny = F(1, n*n)
    kappa = 1 + F(1, n)
    h = 1 + F(1, 32*n)
    b_star = kappa*h
    bound_from_geometry = (b_star - 1 + kappa / (32*n)) / b_star
    assert 0 < bound_from_geometry < F(2, n)
    lengths = (F(0), tiny, F(1, 2*n), F(1, n), F(1, 2), F(1), F(3, 2), F(n))
    normalized = (
        (F(1), -F(2, n)),
        (F(1), F(2, n)),
        (kappa, -F(1, 2*n)),
        (kappa, F(1, 2*n)),
        (b_star, -F(1, 2*n)),
        (b_star, F(1, 2*n)),
    )
    cases = 0
    worst = F(0)
    worst_half = F(0)
    for a, sign, (scale, shift) in product(lengths, (1, -1), normalized):
        base = Loss(a, sign)
        perturbed = Loss(a, sign, scale, shift)
        before = integrate(((F(1), base),))[0]
        after = integrate(((F(1), perturbed),))[0]
        amount = abs(after - before)
        # Monotone displacement sandwiches g(r+δ) and g(r−δ).
        # On a uniform interval the integral changes by at most δ because
        # translation swaps endpoint intervals of length δ and range <= 1.
        uniform_delta = max(abs(shift), abs(scale - 1 + shift))
        assert amount <= uniform_delta <= F(2, n)
        worst = max(worst, amount)
        if scale != 1:
            worst_half = max(worst_half, amount)
        cases += 1

    # A mixed direction menu sees the same U; each partner may use an
    # opposite oriented shift. The very short displacement is much smaller
    # than the perturbation, so a scale-sensitive bound is not uniform.
    baseline = ((F(2, 5), Loss(tiny)), (F(3, 5), Loss(F(3, 2), -1)))
    for shift in (-F(2, n), F(2, n)):
        bumped = ((F(2, 5), Loss(tiny, 1, F(1), shift)),
                  (F(3, 5), Loss(F(3, 2), -1, F(1), -shift)))
        diff = abs(integrate(bumped)[0] - integrate(baseline)[0])
        assert diff <= abs(shift)
    before = integrate(((F(1), Loss(tiny)),))[0]
    down = integrate(((F(1), Loss(tiny, 1, F(1), -F(2, n))),))[0]
    up = integrate(((F(1), Loss(tiny, 1, F(1), F(2, n))),))[0]
    assert before == tiny / 2 and down == before + F(2, n) and up == 0
    assert worst == F(2, n)
    print("RATIONAL PARAMETER GRID", n, {"cases": cases, "a_min_positive": str(tiny),
          "geometry_remaining_margin_bound": str(bound_from_geometry),
          "max_mean_change": str(worst), "max_half-step_scaled_mean_change": str(worst_half),
          "tiny_original_mean": str(before), "tiny_shift_minus_mean": str(down),
          "tiny_shift_plus_mean": str(up)})


def main():
    coarse_and_adversarial()
    shared_partner_pair()
    print("EXPANDED")
    for n in (16, 256, 4096, 65536):
        a = F(1, n*n)
        mean, prediction, average = report_menu(f"microscopic antipodal n={n}", antipodal(a))
        assert mean == a/2 and prediction == a/6 - a*a/4 and average == a/3 - a*a/4
        shared_partner_batch(n)
        grid(n)
    print("PASS exact piecewise integration, common-center covariance and finite perturbation grid")


if __name__ == "__main__":
    main()
