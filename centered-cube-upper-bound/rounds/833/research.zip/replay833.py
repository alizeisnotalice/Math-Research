"""Recompute the four round-833 checks and keep the complete machine transcript."""

import argparse
from concurrent.futures import ThreadPoolExecutor
from hashlib import file_digest, sha256
import json
import os
from pathlib import Path
import subprocess
import sys


ARCHIVE_SHA256 = "891d8cbcbd35537e6abc18c938e53b1b4f300327357c24c8d14a51a46ad5e190"
PRIOR_SHA256 = "3eef2e83aab159531aa5b1049715568779e8c599998dde494ce0ea0e238c0303"
CHECKS = (
    ("row833.py", True),
    ("variance833.py", False),
    ("joint833.py", True),
    ("rank833.py", True),
)
MAX_JOBS = 3
ARCHIVE_LABELS = ("<R814 research.zip>", "<R832 research.zip>")
SETTINGS = {"PYTHONHASHSEED": "0", "PYTHONIOENCODING": "utf-8"}
LOG_HEADER = b"Round 833 computational verification\n"


def digest(path):
    with path.open("rb") as source:
        return file_digest(source, "sha256").hexdigest()


def check_arguments(uses_archives, archive, prior):
    if not uses_archives:
        return []
    return ["--archive", str(archive), "--prior", str(prior)]


def run_check(directory, archive, prior, check):
    script, uses_archives = check
    arguments = check_arguments(uses_archives, archive, prior)
    return subprocess.run(
        [sys.executable, "-B", script, *arguments],
        cwd=directory,
        env={**os.environ, **SETTINGS},
        capture_output=True,
        check=False,
    )


def heading(script):
    return f"\n===== {script} =====\n".encode()


def write_transcript(evidence, results):
    metadata = json.dumps(evidence, ensure_ascii=False, sort_keys=True).encode()
    sections = [LOG_HEADER, b"Evidence JSON: ", metadata, b"\n"]
    for (script, _), result in zip(CHECKS, results, strict=True):
        sections.extend(
            (
                heading(script),
                b"----- stdout -----\n",
                result.stdout,
                b"\n----- stderr -----\n",
                result.stderr,
                b"\n",
            )
        )
    sections.append(f"\nReplay status: {evidence['status']}\n".encode())
    return b"".join(sections)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--archive", type=Path, required=True, help="Path to the original R814 research.zip")
    parser.add_argument("--prior", type=Path, required=True, help="Path to the original R832 research.zip")
    parser.add_argument("--jobs", type=int, choices=range(1, MAX_JOBS + 1), default=MAX_JOBS)
    parser.add_argument("--output", type=Path, help="Save the full transcript here; default is stdout")
    args = parser.parse_args()

    replay = Path(__file__).resolve()
    directory = replay.parent
    archive = args.archive.resolve(strict=True)
    prior = args.prior.resolve(strict=True)
    input_hashes = {archive: ARCHIVE_SHA256, prior: PRIOR_SHA256}
    if archive == prior:
        parser.error("--archive and --prior must point to the two distinct input archives")
    for path, expected in input_hashes.items():
        actual = digest(path)
        if actual != expected:
            parser.error(f"unexpected archive SHA-256 for {path}: {actual}, expected {expected}")
    script_hashes = {script: digest(directory / script) for script, _ in CHECKS}
    replay_hash = digest(replay)
    protected_paths = {replay, archive, prior, *((directory / script) for script in script_hashes)}
    if args.output and args.output.resolve() in protected_paths:
        parser.error("the output must be distinct from all input files")

    with ThreadPoolExecutor(max_workers=args.jobs) as workers:
        pending = [workers.submit(run_check, directory, archive, prior, check) for check in CHECKS]
        results = [job.result() for job in pending]

    for path, expected in input_hashes.items():
        if digest(path) != expected:
            parser.error(f"{path} changed during replay")
    if digest(replay) != replay_hash:
        parser.error("the replay script changed during replay")
    for script, script_hash in script_hashes.items():
        if digest(directory / script) != script_hash:
            parser.error(f"{script} changed during replay")

    runs = {}
    for (script, uses_archives), result in zip(CHECKS, results, strict=True):
        arguments = check_arguments(uses_archives, *ARCHIVE_LABELS)
        runs[script] = {
            "arguments": arguments,
            "script_sha256": script_hashes[script],
            "exit": result.returncode,
            "stdout_bytes": len(result.stdout),
            "stdout_sha256": sha256(result.stdout).hexdigest(),
            "stderr_bytes": len(result.stderr),
            "stderr_sha256": sha256(result.stderr).hexdigest(),
        }
    passed = all(result.returncode == 0 for result in results)
    evidence = {
        "round": 833,
        "status": "PASS" if passed else "FAIL",
        "python": sys.executable,
        "python_version": sys.version,
        "dependencies": {},
        "settings": SETTINGS,
        "jobs": args.jobs,
        "input_r814": str(archive),
        "input_r814_sha256": ARCHIVE_SHA256,
        "input_r832": str(prior),
        "input_r832_sha256": PRIOR_SHA256,
        "replay_sha256": replay_hash,
        "individual_runs": runs,
    }
    transcript = write_transcript(evidence, results)
    if args.output:
        args.output.write_bytes(transcript)
    else:
        sys.stdout.buffer.write(transcript)
    return 0 if passed else 1


if __name__ == "__main__":
    raise SystemExit(main())
