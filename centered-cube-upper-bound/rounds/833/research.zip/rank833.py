"""Certified R814 source-rank gates on two actual finite four-dimensional comb flows."""

import argparse
from collections import defaultdict
from decimal import Context, Decimal, ROUND_CEILING, ROUND_FLOOR, ROUND_HALF_EVEN
from fractions import Fraction as F
from functools import cache
from hashlib import sha256
from itertools import combinations, product
from math import comb, prod
from pathlib import Path
from platform import python_version
from zipfile import ZipFile


ROUNDS = Path(
    "/Volumes/data/CodexProjects/T/Math-Research-cube-sqrt-20261114/"
    "centered-cube-upper-bound/rounds"
)
PRIOR_PIN = "3eef2e83aab159531aa5b1049715568779e8c599998dde494ce0ea0e238c0303"
FLOOR = Context(prec=45, rounding=ROUND_FLOOR)
CEIL = Context(prec=45, rounding=ROUND_CEILING)
NEAR = Context(prec=45, rounding=ROUND_HALF_EVEN)


@cache
def log1plus(x):
    assert x >= 1
    if x == 1:
        return F(1), F(1)
    a, b = Decimal(x.numerator), Decimal(x.denominator)
    lo = NEAR.ln(FLOOR.divide(a, b))
    hi = NEAR.ln(CEIL.divide(a, b))
    return 1 + F(FLOOR.next_minus(lo)), 1 + F(CEIL.next_plus(hi))


def format_interval(lo, hi, digits=16):
    assert 0 <= lo <= hi
    units = 10**digits
    down = lo.numerator * units // lo.denominator
    up = -((-hi.numerator * units) // hi.denominator)
    def format_grid(x):
        return f"{x // units}.{x % units:0{digits}d}"
    return [format_grid(down), format_grid(up)]


def rank_cutoff(base, cost):
    """Enclose base*u with u>=1 and Psi(u)=cost/base."""
    assert cost > base > 0
    lower, upper = F(1), cost / base
    for _ in range(42):
        mid = (lower + upper) / 2
        l_log, u_log = log1plus(mid)
        lo, hi = mid * l_log**2, mid * u_log**2
        if base * hi <= cost:
            lower = mid
        elif base * lo > cost:
            upper = mid
        else:
            break
    return base * lower, base * upper


def rank_staircases():
    """Finite rational masses, including ties and high ratios."""
    tests = (
        ("little source", F(4), (F(3), F(5), F(1, 3), F(3, 7))),
        ("high contrast", F(1, 512), (F(1, 16), F(16), F(512), F(4096))),
        ("all tied", F(3), ()),
        ("unequal atoms", F(1, 16), tuple(F(j**2, 256) for j in range(1, 32))),
        ("fine then large", F(1), (F(1, 32),) * 200 + (F(32), F(256), F(4096))),
    )
    for label, base, more in tests:
        masses = (base, *more)
        current, lower, upper = F(0), F(0), F(0)
        for weight in masses:
            current += weight
            ll, lh = log1plus(current / base)
            lower += weight / (current * lh**2)
            upper += weight / (current * ll**2)
        ll, _ = log1plus(current / base)
        cap = 2 - 1 / ll
        assert 1 <= lower <= upper <= cap < 2
        print("RANK STAIRCASE", label, "integral", format_interval(lower, upper),
              "cdf steps", len(masses))


def corner_root_geometry():
    """Check hard roots and rank/deficit separation on true positive boxes."""
    for n in (4, 16, 128):
        eta = F(1, 2000 * n**2)
        own_max = F(1, 4) + 2 * eta
        opposite_min = F(3, 4) - 2 * eta
        assert 0 < 2 * own_max < 1 < 2 * opposite_min
        central = 1 - F(1, 2**n)
        corner = F(1, 2**n)
        parent = central + corner
        source = central + 2**n * corner
        assert parent == 1 and source == 2 - F(1, 2**n)
        # Side 1 has mass 1. Above it up to first opposite corner the
        # mass stays 1; afterwards even all source mass is too small.
        assert (2 * opposite_min)**n > 2 > source
        assert source / parent < 2
        rad_lo, rad_hi = F(1, 4) - 2 * eta, F(1, 4) + 2 * eta
        assert rad_lo > 0 and own_max < F(1, 2)
        dl, dh = ratio(rad_lo, rad_hi), ratio(rad_hi, rad_lo)
        assert (dl, dh) == (F(1, 2) - 4 * eta, F(1, 2) + 4 * eta)
        probabilities = [F(comb(n, k), 2**n) for k in range(n + 1)]
        assert sum(probabilities) == 1
        mean = sum(k * p for k, p in enumerate(probabilities))
        assert mean == F(n, 2)
        assert sum(probabilities[n//2:]) >= F(1, 2)
        print("CORNER ROOT", n, "eta", eta, "rank upper", source / parent,
              "conditional outer-source mean D", format_interval(mean * dl, mean * dh))


def exact_source_mass(density):
    lo, hi = map(F, density["support"])
    period = F(density["period"])
    center = F(density["bump_center_mod_period"])
    half = F(density["bump_half_width"])
    floor = F(density["density_floor_one_axis"])
    peak = F(density["density_peak_one_axis"])
    assert 0 < floor < peak and 0 <= center - half < center + half <= period

    def primitive(x):
        k = x // period
        shift = x - k * period
        return 2 * half * k + min(2 * half, max(F(0), shift - center + half))

    @cache
    def mass(a, b):
        a, b = max(a, lo), min(b, hi)
        if a >= b:
            return F(0)
        return floor * (b - a) + (peak - floor) * (primitive(b) - primitive(a))

    return (lo, hi), mass


def face_boxes(cubes, support, mass):
    """Partition the full continuous product source by exact cube-face cuts."""
    axes = []
    for i in range(len(cubes[0])):
        cuts = sorted({*support, *(v for cube in cubes for v in cube[i]
                                   if support[0] < v < support[1])})
        axis = []
        for a, b in zip(cuts, cuts[1:]):
            x = (a + b) / 2
            mask = sum(1 << index for index, cube in enumerate(cubes)
                       if cube[i][0] < x < cube[i][1])
            axis.append(((a, b), mask, mass(a, b)))
        axes.append(axis)
    boxes = defaultdict(list)
    ns = len(cubes)
    for pieces in product(*axes):
        mask = (1 << ns) - 1
        for _, entry, _ in pieces:
            mask &= entry
        boxes[mask].append((tuple(interval for interval, _, _ in pieces),
                            prod(weight for _, _, weight in pieces)))
    return boxes


def current_companion_weights(rows):
    current = defaultdict(F)
    companion = defaultdict(lambda: defaultdict(F))
    for (t, (_, z), y), mass in rows.items():
        current[t, z, y] += mass
        companion[y][t] += mass
    prior = {y: {t: val / sum(block.values()) for t, val in block.items()}
             for y, block in companion.items()}
    assert all(sum(block.values()) == 1 for block in prior.values())
    pair = defaultdict(F)
    for (t, z, y), origin in current.items():
        for s, p in prior[y].items():
            pair[t, s, y[1], z] += origin * p
    assert sum(pair.values()) == sum(rows.values()) == sum(current.values())
    return pair


def ratio(epsilon, delta):
    if epsilon <= 0:
        return F(0)
    return epsilon / (epsilon + delta)


def axis_deficit(q, z, a):
    ql, qh = q
    zl, zh = z
    low, high = a
    assert low <= ql < qh <= high
    if low <= zl and zh <= high:
        return F(0), F(0)
    if zl >= high:
        return ratio(zl - high, high - ql), ratio(zh - high, high - qh)
    assert zh <= low
    return ratio(low - zh, qh - low), ratio(low - zl, ql - low)


def cdf_profile(q_box, cube, mode):
    """Use each coordinate's min or max deficit over the whole current q box."""
    for (ql, qh), (a, b) in zip(q_box, cube, strict=True):
        assert a <= ql < qh <= b
        if mode == "min":
            yield a, b, qh - a, b - ql
        else:
            yield a, b, ql - a, b - qh


def source_cdf(support, mass):
    total_axis = mass(*support)

    @cache
    def one(profile, h):
        if h >= 1:
            return total_axis
        a, b, left, right = profile
        k = h / (1 - h)
        return mass(a - k * left, b + k * right)

    def quick(profile, d, lower):
        return prod(one(col, d / len(profile) if lower else d) for col in profile)

    def grid(profile, d, bins, lower):
        if d == 0:
            return quick(profile, d, lower)
        h = d / bins
        accum = [F(1)] + [F(0)] * bins
        for col in profile:
            atom = one(col, F(0))
            weights = [atom] + [F(0)] * bins
            previous = atom
            for k in range(1, bins + 1):
                now = one(col, k * h)
                weights[k if lower else k - 1] += now - previous
                previous = now
            out = [F(0)] * (bins + 1)
            for i, v in enumerate(accum):
                if v:
                    for j, w in enumerate(weights[:bins + 1 - i]):
                        if w:
                            out[i+j] += v * w
            accum = out
        return sum(accum)

    return quick, grid


def greatest_variation(q, z, cube):
    """Choose one coordinate split using the worst deficit variation."""
    def thin(box, i):
        lo, hi = box[i]
        mid = (lo + hi) / 2
        return box[:i] + ((lo, mid),) + box[i+1:], box[:i] + ((mid, hi),) + box[i+1:]

    choices = []
    for i, (qi, zi, ai) in enumerate(zip(q, z, cube, strict=True)):
        dl, dh = axis_deficit(qi, zi, ai)
        if dh <= dl:
            continue
        for split_q, old_box in ((True, q), (False, z)):
            child = thin(old_box, i)
            fragments = (axis_deficit(b[i], zi, ai) if split_q else axis_deficit(qi, b[i], ai)
                         for b in child)
            gain = dh - dl - max(h - l for l, h in fragments)
            choices.append((gain, old_box[i][1] - old_box[i][0], split_q, child))
    if not choices:
        return None
    _, _, split_q, child = max(choices)
    return split_q, child


def coupling_reward(flow, scores):
    return sum(weight * scores[edge] for edge, weight in flow.items())


def tree_flow(weights, edges):
    """Solve one candidate transportation basis by eliminating leaves."""
    rest = {(side, g): w for side in (0, 1) for g, w in weights.items()}
    remaining = set(edges)
    flow = {}
    while remaining:
        neighbors = defaultdict(list)
        for g, h in remaining:
            neighbors[0, g].append((g, h))
            neighbors[1, h].append((g, h))
        leaf = next((node for node, links in sorted(neighbors.items()) if len(links) == 1), None)
        if leaf is None:
            return None
        g, h = edge = neighbors[leaf][0]
        weight = rest[leaf]
        if weight < 0:
            return None
        flow[edge] = weight
        rest[0, g] -= weight
        rest[1, h] -= weight
        remaining.remove(edge)
    return flow if all(v == 0 for v in rest.values()) else None


def optimal_right_coupling(weights, scores):
    gs = tuple(sorted(weights))
    diag = {(g, g): weights[g] for g in gs}
    best, best_value = diag, coupling_reward(diag, scores)
    feasible = 0
    # Every extreme transportation plan has acyclic positive support,
    # by the alternating cycle perturbation. Extend that forest to a
    # spanning tree with zero-weight edges, then eliminate its leaves.
    for edges in combinations(tuple(product(gs, repeat=2)), 2 * len(gs) - 1):
        candidate = tree_flow(weights, edges)
        if candidate is None:
            continue
        feasible += 1
        value = coupling_reward(candidate, scores)
        if value > best_value:
            best, best_value = candidate, value
    assert feasible > 0
    symmetric = {(g, h): (best.get((g, h), F(0)) + best.get((h, g), F(0))) / 2
                 for g, h in product(gs, repeat=2)}
    assert all(sum(symmetric[g, h] for h in gs) == weights[g] for g in gs)
    assert all(sum(symmetric[g, h] for g in gs) == weights[h] for h in gs)
    assert all(v >= 0 for v in symmetric.values())
    assert coupling_reward(symmetric, scores) == best_value
    return symmetric, best_value, feasible


def right_pairing(rows, bits):
    """Pair g at one fixed real q; only then sample each original record."""
    law = defaultdict(lambda: defaultdict(lambda: defaultdict(F)))
    for (t, (_, z), (g, q)), weight in rows.items():
        law[q][g][t, z] += weight
    accum = [F(0)] * 3
    total_mass = sum(rows.values())
    block_mass_sum = F(0)
    for q, raw in sorted(law.items()):
        totals = {g: sum(block.values()) for g, block in raw.items()}
        block_mass = sum(totals.values())
        block_mass_sum += block_mass
        weights = {g: w / block_mass for g, w in totals.items()}
        assert sum(weights.values()) == 1 and 1 <= len(weights) <= 3
        conditionals = {g: {k: w / totals[g] for k, w in raw[g].items()} for g in raw}
        assert all(sum(block.values()) == 1 for block in conditionals.values())
        gs = tuple(sorted(weights))
        scores = {}
        for g, h in product(gs, repeat=2):
            scores[g, h] = sum(p * v
                               for ((t, z), p), ((s, r), v) in product(conditionals[g].items(),
                                                                       conditionals[h].items())
                               if z & bits[s] and r & bits[t])
        assert all(0 <= v <= 1 and v == scores[h, g] for (g, h), v in scores.items())
        diag = sum(weights[g] * scores[g, g] for g in gs)
        independent = sum(weights[g] * weights[h] * scores[g, h] for g, h in scores)
        optimal, value, bases = optimal_right_coupling(weights, scores)
        assert max(diag, independent) <= value <= 1
        for i, v in enumerate((diag, independent, value)):
            accum[i] += block_mass * v
        fmt = lambda x: format_interval(x, x)
        print("RIGHT PAIRING q CELL", q, "q mass share", fmt(block_mass / total_mass),
              "true g weights", {g: fmt(weights[g]) for g in gs},
              "reward upper triangle", {(g, h): fmt(v) for (g, h), v in scores.items() if g <= h},
              "feasible trees", bases, "best over diagonal", fmt(value - diag),
              "symmetric off-diagonal", {(g, h): fmt(w)
                  for (g, h), w in optimal.items() if g < h and w > 0})
    assert block_mass_sum == total_mass
    diag, independent, optimal = (x / total_mass for x in accum)
    assert max(diag, independent) <= optimal <= 1
    fmt = lambda x: format_interval(x, x)
    print("RIGHT PAIRING GLOBAL", "same g", fmt(diag), "independent", fmt(independent),
          "optimal", fmt(optimal), "optimal minus same g", fmt(optimal - diag),
          "optimal minus independent", fmt(optimal - independent))


def fixture(name, stage, prior, depths, bins, multipliers):
    cubes, _, _, _, _, rows = prior["verified_rows"](stage)
    bits = {p["id"]: p["bit"] for p in stage["parents"]}
    mu = {c["mask"]: F(c["mass"]) for c in stage["cells"] if F(c["mass"]) > 0}
    parent_mass = {p["id"]: F(p["m"]) for p in stage["parents"]}
    support, mass = exact_source_mass(stage["density"])
    boxes = face_boxes(tuple(cubes.values()), support, mass)
    assert {mask: sum(w for _, w in v) for mask, v in boxes.items()} == mu
    full_mass = mass(*support)**4
    assert full_mass == sum(mu.values()) == 16**4
    assert all(prod(mass(a, b) for a, b in cube) == parent_mass[s]
               for s, cube in cubes.items())

    pairs = current_companion_weights(rows)
    total = sum(pairs.values())
    old = sum(w for (_, s, _, z), w in pairs.items() if z & bits[s])
    outside = total - old
    assert outside > 0
    assert all(q & bits[s] and q & bits[t] and z & bits[t] for t, s, q, z in pairs)
    # Away from source faces, an outside z has D>0 and T>a_s.
    cutoff = {(t, s, k): rank_cutoff(parent_mass[s], k * parent_mass[t])
              if k * parent_mass[t] > parent_mass[s] else None
              for t, s, _, _ in pairs for k in multipliers}
    print("FIXTURE", name, "full source support", support, "mass", full_mass,
          "original rows", len(rows), "total", total, "joint blocks", len(pairs))
    print("OLD FULL-BOX fraction", format_interval(old/total, old/total),
          "OUTSIDE fraction", format_interval(outside/total, outside/total))
    right_pairing(rows, bits)
    quick, grid = source_cdf(support, mass)
    for depth in depths:
        certain, maybe = defaultdict(F), defaultdict(F)
        visited = 0

        @cache
        def coarse(s, q, z):
            ds = tuple(axis_deficit(x, y, a) for x, y, a in zip(q, z, cubes[s], strict=True))
            dl, dh = sum(a for a, _ in ds), sum(b for _, b in ds)
            most = tuple(cdf_profile(q, cubes[s], "max"))
            least = tuple(cdf_profile(q, cubes[s], "min"))
            return dl, dh, most, least, quick(most, dl, True), quick(least, dh, False)

        @cache
        def finer(s, q, z):
            dl, dh, most, least, lo, hi = coarse(s, q, z)
            return max(lo, grid(most, dl, bins, True)), min(hi, grid(least, dh, bins, False))

        def classify(todo, lo, hi, weight):
            undecided = []
            assert lo <= hi <= full_mass
            for k, bound in todo:
                if hi <= bound[0]:
                    certain[k] += weight
                    maybe[k] += weight
                elif lo <= bound[1]:
                    undecided.append((k, bound))
            return undecided

        def visit(s, q, z, weight, todo, budget):
            nonlocal visited
            visited += 1
            *_, lo, hi = coarse(s, q, z)
            todo = classify(todo, lo, hi, weight)
            if not todo:
                return
            split = greatest_variation(q, z, cubes[s]) if budget else None
            if split is None:
                if bins > 0:
                    todo = classify(todo, *finer(s, q, z), weight)
                for k, _ in todo:
                    maybe[k] += weight
                return
            split_q, children = split
            old_box = q if split_q else z
            i = next(i for i in range(len(q)) if old_box[i] != children[0][i])
            a, b = old_box[i]
            child_weights = [mass(*box[i]) / mass(a, b) for box in children]
            assert min(child_weights) > 0 and sum(child_weights) == 1
            for box, p in zip(children, child_weights, strict=True):
                visit(s, box if split_q else q, z if split_q else box, p * weight, todo, budget-1)

        for (t, s, q, z), w in sorted(pairs.items()):
            if z & bits[s]:
                continue
            todo = [(k, cutoff[t, s, k]) for k in multipliers if cutoff[t, s, k] is not None]
            if not todo:
                continue
            coefficient = w / (mu[q] * mu[z])
            for (q_box, qw), (z_box, zw) in product(boxes[q], boxes[z]):
                visit(s, q_box, z_box, coefficient * qw * zw, todo, depth)
        print("PARTITION", "depth", depth, "cdf grid bins", bins, "visited", visited)
        assert all(0 <= certain[k] <= maybe[k] <= outside for k in multipliers)
        assert list(map(certain.get, multipliers)) == sorted(certain.get(k, F(0)) for k in multipliers)
        assert list(map(maybe.get, multipliers)) == sorted(maybe.get(k, F(0)) for k in multipliers)
        for k in multipliers:
            lo, hi = certain[k], maybe[k]
            print("GATE", k, "NEW fraction", format_interval(lo/total, hi/total),
                  "excluded outside fraction", format_interval((outside-hi)/total, (outside-lo)/total),
                  "original mass fraction covered by old or new",
                  format_interval((old+lo)/total, (old+hi)/total))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--archive", type=Path, default=ROUNDS / "814/research.zip")
    parser.add_argument("--prior", type=Path, default=ROUNDS / "832/research.zip")
    parser.add_argument("--depth", type=int, nargs="+", default=[4])
    parser.add_argument("--bins", type=int, default=12)
    parser.add_argument("--multipliers", type=int, nargs="+", default=[1, 2, 4, 8])
    args = parser.parse_args()
    assert min(args.depth) >= 0 and args.bins >= 0
    assert sorted(set(args.multipliers)) == args.multipliers and min(args.multipliers) > 0
    assert sha256(args.prior.read_bytes()).hexdigest() == PRIOR_PIN
    prior = {"__name__": "archived_foot832"}
    with ZipFile(args.prior) as archive:
        code = archive.read("foot832.py")
    print("PRIOR SHA256", PRIOR_PIN, "foot832.py", sha256(code).hexdigest(),
          "Python", python_version())
    exec(compile(code, "foot832.py", "exec"), prior)
    rank_staircases()
    corner_root_geometry()
    for name, stage in prior["fixtures"](args.archive):
        fixture(name, stage, prior, args.depth, args.bins, args.multipliers)
    print("PASS original rows, true source masses, directed rank enclosure, and ties")


if __name__ == "__main__":
    main()

