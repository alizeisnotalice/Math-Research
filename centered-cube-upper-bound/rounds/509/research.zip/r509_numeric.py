#!/usr/bin/env python3
"""R509 finite exact nonuniform continuous 1D gate and high-density interfaces."""
from pathlib import Path
import json,sys,platform,time
import sympy as sp
from fractions import Fraction
ROOT=Path(__file__).resolve().parent
B,s=sp.symbols('B s',real=True)
checks=0

def ck(x):
 global checks
 assert bool(x)
 checks+=1

def integ(expr,lo,hi):return sp.factor(sp.integrate(sp.expand(expr),(B,lo,hi)))
def case(stage,w,H,e,M):
 W=2+2*w*H;q=W/4;a=sp.Integer(2)
 F=W-1-B+s/2;L=W/2-1-B+s/2
 ck(sp.simplify(F.subs(s,2)-(W-B))==0)
 ck(sp.simplify(L.subs(s,2)-(W/2-B))==0)
 # Original pair integral at fixed B and radius r is product of two source masses.
 # First source gate x<=0 contributes L; second source contributes F.
 pair=F*L/W**2
 ck(sp.simplify(sp.diff(pair,s)-(F*sp.diff(L,s)+L*sp.diff(F,s))/W**2)==0)
 # In ungated rank coordinates v=F/W, d(v^2)=2v dv exactly.
 ck(sp.simplify(sp.diff((F/W)**2,s)-2*(F/W)*sp.diff(F/W,s))==0)
 cutoff=4*(W-1-B)/(M*W-2)
 b_full=2/M-1;b_positive=W*(1-M/2)
 ck(M*W-2>0);ck(b_full>0);ck(b_positive>0)
 cuts=sorted({sp.Integer(0),e,*[x for x in [b_full,b_positive] if 0<x<e]})
 direct=sp.Integer(0);ox=sp.Integer(0);oz=sp.Integer(0);ungated=sp.Integer(0);pieces=[]
 for lo,hi in zip(cuts,cuts[1:]):
  mid=(lo+hi)/2
  if mid>=b_positive:U=sp.Integer(2)
  elif mid<=b_full:U=2*(1+B)
  else:U=cutoff
  ck(U.subs(B,mid)>=2)
  du=sp.factor(q*(pair.subs(s,U)-pair.subs(s,2)))
  xu=sp.factor(q/W**2*sp.integrate(F*sp.diff(L,s),(s,2,U)))
  zu=sp.factor(q/W**2*sp.integrate(L*sp.diff(F,s),(s,2,U)))
  nu=sp.factor(q/W**2*(F.subs(s,U)**2-F.subs(s,2)**2))
  ck(sp.simplify(du-xu-zu)==0)
  # high gate: q_s=F/s > M q_B. Endpoints have source product measure zero.
  if mid<b_positive:
   ck(sp.simplify((F-M*q*s).subs(s,cutoff))==0)
   ck((F-M*q*s).subs({B:mid,s:(2+U.subs(B,mid))/2})>0)
  pd,px,pz,pn=[integ(z,lo,hi) for z in [du,xu,zu,nu]]
  direct+=pd;ox+=px;oz+=pz;ungated+=pn
  pieces.append({'B_interval':[lo,hi],'upper_s':U,'direct_gate_integrand_B':du,'outer_original_x_integrand_B':xu,'outer_original_z_integrand_B':zu,'direct_integral':pd,'orientation_x_integral':px,'orientation_z_integral':pz})
 direct=sp.factor(direct);ox=sp.factor(ox);oz=sp.factor(oz);ungated=sp.factor(ungated)
 small=integ((W-B)*(W/2-B)/(4*W),0,e)
 small_ungated=integ((W-B)**2/(4*W),0,e)
 total=W*e/8;total_ungated=W*e/4
 A=1+sp.log(2);bound=A*W/M
 ck(direct==ox+oz);ck(direct>0);ck(ox!=oz);ck(ox>0 and oz>0)
 ck(0<direct<=ungated);ck(0<small<=small_ungated<=W)
 ck(small+direct<=total);ck(ungated< W/M);ck(bound>W/M)
 # Global gate mass is exactly half by symmetry, despite unequal sorted labels.
 ck(total==total_ungated/2)
 # An explicit rational inner-source cap, valid for this finite model only.
 # q_s>Mq, s>=2 implies 1/F < 1/(2Mq), while outer source mass<=W.
 # Sorted inner column wrt mu is <=2*q*e*W/W^2=e/2 before gating.
 inner_column_cap=e/2
 ck(inner_column_cap<=1/M) # A1=1+log2>1; this finite cap is <=A1/M.
 return {'stage':stage,'w':w,'H':H,'e':e,'M':M,'W':W,'m_B':W,'q_B':q,'a':a,'b':4,'t':1,'S':1,'A1':A,'B_full_threshold':b_full,'B_high_nonempty_threshold':b_positive,'gate_total':total,'ungated_total':total_ungated,'gate_small_integral':small,'ungated_small_integral':small_ungated,'gate_high_original_pair_integral':direct,'gate_high_outer_x_contribution':ox,'gate_high_outer_z_contribution':oz,'wrong_double_outer_x':2*ox,'wrong_double_outer_z':2*oz,'ungated_high_integral':ungated,'high_bound_SA1W_over_M':bound,'high_stronger_verified_rational_bound':W/M,'sorted_inner_source_column_finite_cap':inner_column_cap,'pieces':pieces}

def main():
 start=time.perf_counter();cases=[]
 for stage,w,H,e in [('initial',sp.Rational(1,8),sp.Integer(4),sp.Rational(1,4)),('concentration_pressure',sp.Rational(1,16),sp.Integer(16),sp.Rational(1,2)),('expanded_amplitude',sp.Rational(1,32),sp.Integer(64),sp.Rational(1,2))]:
  for M in [sp.Rational(3,2),sp.Rational(7,4)]:
   z=case(stage,w,H,e,M);cases.append(z)
   print(stage,'M',M,'W',z['W'],'small',z['gate_small_integral'],'high',z['gate_high_original_pair_integral'],'orientation',z['gate_high_outer_x_contribution'],z['gate_high_outer_z_contribution'],flush=True)
 def serial(x):
  if isinstance(x,sp.Basic):return str(x)
  raise TypeError(type(x))
 out={'scope':'six exact continuous nonuniform 1D cases; original ordered gate x<=0, kernel=1; no general history/root claim','model':{'f':'1[-1,1]+H*1[-w,w]','receiver_E':'[0,e]','R_B':4,'t':1,'a':2,'b':4,'gate':'original first label x<=0','kernel':1},'environment':{'executable':sys.executable,'python':platform.python_version(),'sympy':sp.__version__},'checks':checks,'cases':cases,'compute_seconds':time.perf_counter()-start}
 (ROOT/'r509_numeric.json').write_text(json.dumps(out,default=serial,indent=2)+'\n')
 print('PASS',checks,'exact checks; 6 continuous nonuniform configurations; no general-history claim')
if __name__=='__main__':main()
