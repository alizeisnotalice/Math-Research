# R509：原双来源共同尺度的尾界与逆体积费用

## 1. 同一原流上的尺度变量

沿geometry的完整原合同，设V为两个原来源质量秩的最大值；给定原中心B，P(V≤v)=v²，密度2v dv。保两个方向及原条件历史，不在接受后重新归一。余门D_*为s≥a且q_s≤M q_B，M≥1。定义
\[
Z=n\log(R_B/s),\qquad A=(R_B/s)^n,\qquad T=(b/a)^n.
\]
s≤R_B且m_s=Vm_B，故
\[
q_s/q_B=V(R_B/s)^n=VA.
\]
因此在D_*上
\[
0\le Z\le\log M-\log V,\qquad
1\le A\le\min\{T,M/V\}.
\tag{1}
\]
这里T是单比例带真实上限，不能在临界矩中抹掉其维数依赖。若只依赖无截断的V矩，以下次临界界不需使用T。

## 2. 不删除小质量秩的可积尺度尾

对y≥0，(1)给
\[
\mathbb E_B[1_{D_*}1_{Z>\log M+y}]\le e^{-2y}.
\tag{2}
\]
记L=log M≥0。对整数k≥0，由2v dv的精确积分，
\[
\mathbb E_B[1_{D_*}Z^k]
 \le\int_0^1 2v(L-\log v)^k\,dv
 =\sum_{j=0}^k {k\choose j}L^{k-j}\frac{j!}{2^j}.
\tag{3}
\]
k=0理解为D_*的概率≤1。特别地
\[
\mathbb E_B[1_{D_*}\log(R_B/s)]\le\frac{L+1/2}{n},
\quad
\mathbb E_B[1_{D_*}\log^2(R_B/s)]
 \le\frac{L^2+L+1/2}{n^2}.
\tag{4}
\]
这些是原双来源概率下未归一化限制的量，而不是条件在D_*或旧接受gate后的期望。任意0≤旧gate≤1、任意原条件历史概率核只会降低正测试的积分。因此将(2)—(4)乘ν(dB)积分，得到同一真实原记录的尾/矩预算，右边乘R_τ；它们不是以W计价的根阶付款。

例如共同盒与原盒同心、实际包含两个原来源，且R_B−s≤b log(R_B/s)，故其平均边长收缩≤b(L+1/2)R_τ/n。对真有边长Lipschitz常数K的旧测试，其改变可据此付K倍费用；一般硬门无该常数，不能如此替换。外部见证盒、rank及历史的重新生成不受这个连续距离界认证。

## 3. 逆体积费用的精确阈值

若后续同流比较产生A^β而0≤β<2，则
\[
\mathbb E_B[1_{D_*}A^\beta]
 \le M^\beta\int_0^1 2v^{1-\beta}dv
 =\frac{2M^\beta}{2-\beta}.
\tag{5}
\]
特别地，一次逆体积的费用≤2M，半次逆体积≤(4/3)√M。该结论保原归一化概率；在把中心密度改写成t_v q_s后，积分基底是dv且t_v=2t(s/R_B)^n，不能再次免费叠用2v的衰减。

若需要临界或更高矩，必须保T。令
\[
I_\beta(M,T)=\int_0^1 2v\min(T,M/v)^\beta dv.
\]
T≤M时I_β=T^β；T>M时设z=M/T∈(0,1)，有
\[
I_\beta=M^2T^{\beta-2}+2M^\beta\int_z^1 v^{1-\beta}dv.
\tag{6}
\]
于是
\[
I_1=2M-M^2/T,\qquad
I_2=M^2[1+2\log(T/M)],
\tag{7}
\]
而β≠2时
\[
I_\beta=\frac{2M^\beta}{2-\beta}
 -\frac{\beta M^2T^{\beta-2}}{2-\beta}.
\tag{8}
\]
这是截断上包络的精确积分，不称原几何达到等号。对于β=2，log T=n log(b/a)仍产生线性维数费用；例如β=3的包络是3M²T−2M³，不能被(5)的常数取代。这定位后续几何比较能负担的逆体积次数，而不是对一般根阶目标给反例。

取geometry的M=max(1,A_n/√n)，已付两支为S(1+√n)W；剩余源对的平均对数尺度误差为O(log(n+2)/n)。但一次逆体积矩可达上包络O(√n)，平方逆体积还保更多费用。二者必须随实际出现的核一起记账，不能仅取有利的平均距离而丢掉密度归一。

## 4. 接回硬流时的完整费用限定

geometry分解针对0≤G≤1的原记录。若原完整积分为H G且仅知0≤H≤H_*，两项原来源付款、所有正尾/矩测试都须按需要乘H_*，不能只给其中一个分支补帽。若H无已证上界，则保真实H加权积分，不套该无权概率预算。全入口外乘数及各旧未付项另行完整保留。

本稿不要求先删V<α；若后续工具需要统一密度带，删流代价仍可明确写成α²R_τ，带核帽为H_*α²R_τ。是否值得删，须同工具对新带比Mr/α的费用比较。没有证明外面锚与内后验的完整联合余流已有根阶来源价。

## 5. 最小本机精确检查

以下代码核2v矩、对数多项式和截断逆体积积分的所有参数分段。仅有限代数检查；一般结论依赖(1)与上述解析积分。实际解释器与标准输出记录在r509_replay.json。

```python
import sympy as s
v,t,L=s.symbols('v t L',positive=True)
count=0
for k in range(7):
    exact=s.integrate(2*s.exp(-2*t)*(L+t)**k,(t,0,s.oo))
    formula=sum(s.binomial(k,j)*L**(k-j)*s.factorial(j)/2**j for j in range(k+1))
    assert s.simplify(exact-formula)==0;count+=1
for M,T in [(s.Rational(1),s.Rational(1)),(s.Rational(3),s.Rational(2)),
            (s.Rational(1),s.Rational(4)),(s.Rational(3,2),s.Rational(8)),
            (s.Rational(5),s.Rational(16))]:
    for beta in [s.Rational(0),s.Rational(1,2),s.Rational(1),s.Rational(3,2),s.Rational(2),s.Rational(3)]:
        if T<=M:
            exact=s.integrate(2*v*T**beta,(v,0,1));formula=T**beta
        else:
            z=M/T
            exact=s.integrate(2*v*T**beta,(v,0,z))+s.integrate(2*v*(M/v)**beta,(v,z,1))
            formula=M**2*(1+2*s.log(T/M)) if beta==2 else (2*M**beta-beta*M**2*T**(beta-2))/(2-beta)
        assert s.simplify(exact-formula)==0;count+=1
        if beta<2:
            assert s.simplify(2*M**beta/(2-beta)-exact).is_nonnegative is True;count+=1
# The signs above are checked symbolically for these exact algebraic inputs.
for alpha in [s.Rational(1,4),s.Rational(1,2),s.Rational(3,4)]:
    assert s.integrate(2*v,(v,0,alpha))==alpha**2;count+=1
print('PASS',count,'exact identities and signs; general bounds follow from the displayed proof')
```
