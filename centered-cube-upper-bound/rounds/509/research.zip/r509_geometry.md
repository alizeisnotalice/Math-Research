# R509 几何：原内侧来源支付共同盒的高密度分支

本稿给出实际改变原双来源预算的估计：小共同盒分支的原来源列至多 S，高密度共同盒分支的原内侧来源列至多 SA_n/M。两种来源都是原记录已有的来源，不重抽；任意不对称旧 gate 及其条件历史保留两个方向标签。余流仍缺根阶几何桥，本文不宣称完整弱型上界闭合。

## 1. 合同与精确有向拆分

μ=f dx≥0，W=μ(R^n)<∞；真实原中心 B∈E，a≤R_B≤b≤2a，m_B=μQ(B,R_B)=q_BR_B^n>0，q≤q_B≤λ，dν=tq_BdB，0≤t≤S。记 A_n=1+n log(b/a)。以下 Q(B,r) 的边长为 r。原双来源律为 ν(dB)π_B(dx)π_B(dz)，π_B=μ|Q_B/m_B。历史使用原条件核 H_{B,x,z}(dω)，任意原记录 gate G(B,x,z,ω) 满足 0≤G≤1。核帽超过 1 时，付款应乘实际已证核帽。

置 F_B(r)=μQ(B,r)，d_B(x)=2||x−B||∞，s=max(d_B(x),d_B(z))。由于 μ 绝对连续，d_B(X) 的分布没有原子，F_B 连续，故 U=F_B(d_B(X))/m_B 为 Uniform(0,1)。质量平台不影响此结论。两个来源独立时 V=max(U_x,U_z) 有分布 P(V≤v)=v²；s=s_B(v):=inf{r:F_B(r)≥vm_B} 几乎处处，F_B(s_B(v))=vm_B。

令 σ_{B,v} 为原来源在质量秩 v 上的正则条件分布，支撑在共同盒边界；令 π_{B,v}=μ|Q(B,s_B(v))/(vm_B)。有向标签 I=1 表示原 x 为外者，I=2 表示原 z 为外者。原正测度严格等于两项之和：

    ν(dB) v dv σ_{B,v}(do) π_{B,v}(di) H_{B,o,i}(dω),  I=1,
    ν(dB) v dv σ_{B,v}(do) π_{B,v}(di) H_{B,i,o}(dω),  I=2.

两项 gate 分别为 G(B,o,i,ω) 和 G(B,i,o,ω)，不能把任意不对称 gate 写成 2G(B,o,i,ω)。等价地，中心层密度是 2v tq_BdB dv，方向各取 1/2，但历史随方向不同。内者仍是原两个来源之一，条件律 π_{B,v} 是真实完整后验，不是重新抽样的替代来源。条件后验只是在 (B,v) 给定、尚未施加旧 gate 时成立；施加 gate 后应保留其密度。

## 2. 小共同盒分支：原固定来源列 ≤S

设 D_0={s<a}。由于 a≤R_B，u_B=F_B(a)/m_B≤1，原双来源在 D_0 的质量概率为 u_B²。逐中心

    q_B u_B² = [F_B(a)/a^n] u_B(a/R_B)^n ≤ F_B(a)/a^n.

因此其总质量≤SW。更强地，把每个 D_0 原记录计到其原第一来源 x。去掉上帽为 1 的 gate 后，来源列为

    K_0(y)=∫_E t(B) q_B F_B(a)/m_B² ·1_{Q(B,a)}(y)dB
          =∫_E t(B)u_B(a/R_B)^n ·1_{Q(B,a)}(y)/a^n dB ≤S.

这是同一原正测度的直接边缘控制。无需 min(F_B(a),m_B)：本合同已经有 F_B(a)≤m_B。边界事件为零。

## 3. 高密度分支：原内侧来源列 ≤SA_n/M

取 M≥1。定义 q_{B,v}=F_B(s_B(v))/s_B(v)^n=vm_B/s_B(v)^n，以及

    D_M={s≥a, q_{B,V}>M q_B}.

在 D_M 上，把原记录计到其内侧来源 i，保留原方向及历史。令

    g_1(B,v,y)=∫σ_{B,v}(do)∫H_{B,o,y}(dω)G(B,o,y,ω),
    g_2(B,v,y)=∫σ_{B,v}(do)∫H_{B,y,o}(dω)G(B,y,o,ω).

每个 g_j 在 [0,1]。该原内来源列的精确公式为

    K_M(y)=∫_E tq_B∫_0^1 v ·1_{D_M(B,v)}
                    [1_{Q(B,s_B(v))}(y)/(vm_B)] [g_1+g_2] dv dB.

由于高密度门给出 q_B/(vm_B)=q_B/(q_{B,v}s_B(v)^n)≤1/(M s_B(v)^n)，

    K_M(y)≤(2S/M)∫_0^1 v ∫_{E_v}
                    1_{Q(B,s_B(v))}(y)/s_B(v)^n dB dv,
    E_v={B∈E:s_B(v)≥a, q_{B,v}>Mq_B}.

现在才可调用确定 selector 的单比例带列界：固定 v 后，B↦s_B(v) 是一个可测确定半径，且在 E_v 上位于 [a,b]。对固定 y，令 d=2||B−y||∞，则其核逐点受

    1_{d≤b}/max(a,d)^n

支配；Lebesgue 积分恰为 1+n log(b/a)=A_n。因此

    K_M(y)≤(2SA_n/M)∫_0^1 v dv = SA_n/M,
    |原 D_M 接受流|≤(SA_n/M)W.                     (H)

关键合法次序是先对原双来源作径向秩/内者换序，再固定 v 应用 selector 列界。没有对随来源变化的 s(B,x,z) 直接调用无条件 A_n；也没有把外侧面来源当成新父完整后验。式(H)是逐原来源列付款，故比仅比较总接收质量更强。旧历史完全留在 g_1,g_2 中，仅在支付这个正分支时利用上帽 1。

## 4. 完整分解及真正剩余项

令 D_*={s≥a,q_{B,V}≤Mq_B}，三门互斥且覆盖原记录（忽略零集）。用 D_0 的原第一来源及 D_M 的原内者作分支指定 payer，联合已付来源列≤S(1+A_n/M)。因此原完整 gate 量 R_G 满足

    R_G≤S(1+A_n/M)W+R_*,                         (B)

其中 R_* 是同一原正测度在 D_* 上的真实限制，方向、原来源、历史与 gate 均不变。取 M=max(1,A_n/√n)，则前项≤S(1+√n)W；这确实是完整预算中的两个根阶可付款分支，但没有估计 R_*。

给定 v，R_* 的中心行密度是 2v tq_B dB，而完整内侧后验为 π_{B,v}。用新密度 q_{B,v} 写时真实系数为

    t_v=2v t q_B/q_{B,v}=2t(s_B(v)/R_B)^n≤2S.

在 D_* 上还同时有

    v q_B≤q_{B,v}≤M q_B,
    q_{B,v}∈[vq,Mλ],   新密度带比≤Mr/v,
    0≤log(R_B/s_B(v))≤log(M/v)/n.

这些信息同时成立；外者仍是 σ_{B,v} 而非 π_{B,v}，原 hard gate 也未迁移。若后续桥的 v 依赖只有 log^A(1/v)，可以沿 dv 积分，没必要提前删小 v；对整数 k≥0，∫_0^1(log(1/v))^k dv=k!，∫_0^1 2v(log(1/v))^k dv=k!/2^k。应根据实际中心系数选择 dv 或 2v dv，不能重复领取 2v 衰减。仅在后续桥确需统一 v 下界时才删 {V<α}，其原记录质量≤α²ν(E)≤α²SX。

精确剩余桥可以表述为：在上述有向原历史流上，利用完整内者后验、外者面锚和同一 B 的门 D_*，证明

    R_*≤εX+C√n log^A(n+e)W

（并核算任何全入口乘数、S、密度带比及原核帽）。单纯应用 π_{B,v} 的一来源 A_n 列界，仍只得到线性维数费用。不能将 σ_{B,v} 换成独立完整后验，也不能在新盒上重新运行原停止历史。

## 5. 外者面锚的精确几何式

对原外者 o，几乎每个中心 B 有唯一 winner 坐标 j、符号 ε∈{−1,1}。写

    B=o−s w,   w_j=ε/2,   w_k=u_k∈[−1/2,1/2] (k≠j).

固定 o 后，(s,u)↦B 的 Lebesgue Jacobian 是 s^{n−1}/2。其共同盒为

    Q(B,s)=o+s([-1/2,1/2]^n−w).

对固定 (o,j,ε,u)，该锚定盒随 s 嵌套，o 在指定面上。记 h_1,h_2 为原两方向已积分历史的 gate，任意径向共同盒门 D 的准确原量为

    Σ_{j,ε} ∫μ(do)∫_0^∞∫_[−1/2,1/2]^{n−1}
      [s^{n−1}/2] ·1_E(B)1_{s≤R_B}1_D(B,s) t(B)q_B/m_B²
      ·∫_{Q(B,s)}[h_1(B,o,i)+h_2(B,o,i)] μ(di) du ds.

B 在此恒取 o−sw；所有 m_B、R_B、q_B 和旧 gate 都属于该原中心。这是无需原 R_B 光滑性的真实中心换元。它把同一面锚下的盒嵌套显露出来，却仍有 2n 个面及其真实权重；本文未得到从这个精确式节省到 √n 的新估计。把其 μ(do)μ(di) 直接替成 W 不是合法付款。

## 6. 最小本机精确核验

已在 `/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python -I` 实跑以下内嵌程序，SymPy 1.14.0 输出 `PASS 72 exact algebra/order-statistic tests; SymPy 1.14.0`。系统 python3 没有 SymPy，随后使用既有数学环境成功。测试核对不对称双来源单项式的两方向拆分、权重归一、小盒不等式、高密度列系数及小秩质量；一般维数的结论来自上述正测度证明，不由有限测试代替。

```python
import sympy as s
from fractions import Fraction as F
v,h=s.symbols('v h', nonnegative=True)
count=0
for p in range(5):
 for q in range(5):
  ordered=s.integrate(v*s.integrate(v**p*(v*h)**q+(v*h)**p*v**q,(h,0,1)),(v,0,1))
  assert ordered==s.Rational(1,(p+1)*(q+1));count+=1
assert s.integrate(2*v,(v,0,1))==1;count+=1
for ratio in (F(1),F(3,2),F(2)):
 for u in (F(0),F(1,7),F(1,2),F(1)):
  for n in (1,2,7):
   assert u*u/ratio**n<=u;count+=1
for M in (F(2),F(5),F(11)):
 for v0 in (F(1,7),F(1,2),F(1)):
  qs=M*F(3);qb=F(3);ss=F(4);m=qs*ss**3/v0
  assert 2*v0*qb/(v0*m)==2*v0/(M*ss**3);count+=1
rho=s.symbols('rho',nonnegative=True)
assert s.integrate(2*v,(v,0,rho))==rho**2;count+=1
print('PASS',count,'exact algebra/order-statistic tests; SymPy',s.__version__)
```
