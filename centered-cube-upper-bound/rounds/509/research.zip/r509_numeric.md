# R509：六个非均匀连续一维模型的精确有限证书

## 实际运行及范围

实际命令：

```sh
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python -I /tmp/r509_numeric.py
```

实际环境为Python 3.12.14、SymPy 1.14.0。最终stdout：

```text
initial M 3/2 W 3 small 95/1152 high 13/1152 orientation 35/4608 17/4608
initial M 7/4 W 3 small 95/1152 high 5381/681408 orientation 7253/1362816 3509/1362816
concentration_pressure M 3/2 W 4 small 79/384 high 169/4608 orientation 229/9216 109/9216
concentration_pressure M 7/4 W 4 small 79/384 high 17/1344 orientation 23/2688 11/2688
expanded_amplitude M 3/2 W 6 small 95/288 high 17/441 orientation 733/28224 355/28224
expanded_amplitude M 7/4 W 6 small 95/288 high 9649/582624 orientation 13015/1165248 6283/1165248
PASS 152 exact checks; 6 continuous nonuniform configurations; no general-history claim
```

所有积分均用SymPy有理数及符号积分，未用无误差界的float估算；JSON中的有理数为精确结果，`A1=1+log(2)`保留符号。最初曾拟定三维多面体算法，但未执行该扫描；接获明确参数后以本文的一维分段精确积分完全替换。只执行以下六例，不延伸扫描，不认证一般history或根阶结论。

模型为 `μ=f dx`、`f=1[-1,1]+H·1[-w,w]`，`W=2+2wH`；真实连续接收积分 `B∈E=[0,e]`，`R_B=4`，`m_B=W`，`q_B=W/4`，`t=S=1`，`ν=(W/4)dB`，`π_B=μ/W`。取 `a=2,b=4`，符合 `b≤2a`；`A1=1+log2`。原核恒为1，原有序gate为 `G(x,z)=1_{x≤0}`。这只是界为1的旧来源标签接口，不声称原rank gate或任何实际history。

|阶段|w|H|e|W|M|
|---|---|---|---|---|---|
|初探|1/8|4|1/4|3|3/2、7/4|
|集中来源压力|1/16|16|1/2|4|3/2、7/4|
|集中幅度与接收范围扩大后的参数|1/32|64|1/2|6|3/2、7/4|

第三阶段相对初探扩大e与集中幅度；相对第二阶段保持e，仅继续收窄集中块、提高幅度。父盒全捕获源，但s及highdensity门仍随真实连续B变化。

## 原pair与外内表示

定义 `D_B(x)=2|x−B|`，`s=max(D_B(x),D_B(z))`，`F_B(r)=μQ(B,r)`、`L_B(r)=μ(Q(B,r)∩(−∞,0])`。对固定B，原有序pair在 `s≤r` 且通过原gate的质量准确为

`P_G(s≤r | B)=L_B(r)F_B(r)/W²`。

这是直接对原两个来源区间的面积（μ产品质量）求积，无排序代换。所取参数使s≥2时集中块完整落入新盒；在 `2≤s≤smax(B)=2(1+B)` 上：

`F_B(s)=W−1−B+s/2`，`L_B(s)=W/2−1−B+s/2`。

特别地 `F_B(2)=W−B`，`L_B(2)=W/2−B`。到smax时二者分别为W与W/2；更大s只有零质量平台。

独立按Stieltjes径向分解并保原标签，原x为外者贡献 `F_B dL_B/W²`，原z为外者贡献 `L_B dF_B/W²`，两项相加等于 `d(L_B F_B)/W²`。由于 `F_B−L_B=W/2>0`，两项通常不相等。本模型s≥2区间有dF=ds/2、dL=ds/2，但两个前因子不同。故不能把任意一项乘2代替有序gate。每个B分段中脚本先精确核对两个表示的被积式恒等，再独立积分原面积差与两项Stieltjes表达式。

未加gate时，以质量秩 `v=F_B(s)/W` 表示，max秩CDF为v²，径向微分 `d(v²)=2v dv`。脚本核对这个换元恒等式及上述保标签恒等式；不重复泛扫已知CDF。排序后条件inner律为 `μ|Q(B,s)/F_B(s)`。乘外因子 `2F_B(s)/W` 后，inner小分母精确取消，恢复原大分母W²的排序产品密度。带gate时两orientation分别继承原标签，不能仅保“outer≤0”后乘2。

## small与非空highdensity分支

small分支原有序gate积分完全精确为

`I_small=∫_0^e (W−B)(W/2−B)/(4W) dB`；

未加gate版本为 `∫_0^e (W−B)²/(4W)dB`。六例均核对 `0<I_small≤I_small,ungated≤SW=W`。这是核恒1时的真实删除积分与正质量，没有把无界核的积分混同于质量。

highdensity分支定义为 `s≥2` 且 `q_s=F_B(s)/s > Mq_B=MW/4`。因为MW−2>0，上限为

`U(B)=min(2(1+B), 4(W−1−B)/(MW−2))`，仅在U>2时有贡献。

上限选择的切换点为 `B_full=2/M−1`；非空high分支的B范围为 `B<W(1−M/2)`。脚本在这些有理阈值与0、e之间真实分段积分；当超过非空阈值时直接令U=2、贡献零。每个非空分段还以内部有理点严格核对high不等式，所有六例的总high积分严格大于0。边界严格/非严格的差异为原产品零测集。

直接原pair计算为

`I_high=∫_0^e [F_B(U)L_B(U)−F_B(2)L_B(2)]/(4W) dB`。

保原标签重建为

`I_high,xouter=∫_0^e (1/(4W))∫_2^U F_B(s)/2 ds dB`，

`I_high,zouter=∫_0^e (1/(4W))∫_2^U L_B(s)/2 ds dB`。

精确结果如下。small值按阶段相同；high及orientation按M改变。

|W,e|M|I_small|I_high|原x为外者|原z为外者|
|---|---|---|---|---|---|
|3,1/4|3/2|95/1152|13/1152|35/4608|17/4608|
|3,1/4|7/4|95/1152|5381/681408|7253/1362816|3509/1362816|
|4,1/2|3/2|79/384|169/4608|229/9216|109/9216|
|4,1/2|7/4|79/384|17/1344|23/2688|11/2688|
|6,1/2|3/2|95/288|17/441|733/28224|355/28224|
|6,1/2|7/4|95/288|9649/582624|13015/1165248|6283/1165248|

每行严格满足两orientation之和等于原pair high积分，两项均正且不等。JSON同时列出错误的两倍单项以便追溯。全原gate积分为 `We/8`，未加gate为 `We/4`；每例核对small+high不超过全原gate质量（其余为s≥2的非high分支）。

未加gate的high积分另由 `[F_B(U)²−F_B(2)²]/(4W)` 精确积分。每例有 `I_high≤I_high,ungated<W/M<(1+log2)W/M=SA1W/M`；因此本有限模型验证目标帽且有严格余量，不需要区间近似或未定积分。

## inner来源列的有限上界与限制

以dμ为参考，未筛选的sorted-inner列具有代表

`K_inner(z)=2∫_0^e (1/4)(1−F_B(D_B(z))/W)dB ≤ e/2`。

原标签gate及high选择器均在[0,1]，故相应inner子列也受e/2支配。六例精确参数满足 `e/2≤1/M<A1/M`，于是该有限模型的inner列有同形式帽；对μ积分也得到不超过A1W/M。该帽来自本例固定R_B=4且接收域很短的显式支配，**不构成一般来源列或一般highdensity选择器的证明**。

本证书确认非均匀真实连续源、真实B积分、非空high分支、原有序gate、质量秩/外内表示的兼容以及orientation的重要性。它不认证任意history、任意来源和半径场、一般维数依赖、一般A_n最优费用或任何新的根阶主张。一般命题仍需独立解析证明。

## 冻结

最终脚本和JSON生成后写本文，再对三文件一次性计算SHA256并在任务交付消息记录；不在本文写入自身散列以免循环。冻结后停止，不新增扫描。
