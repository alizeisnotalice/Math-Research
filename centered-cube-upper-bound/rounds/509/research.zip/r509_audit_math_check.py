from fractions import Fraction as F
import sympy as sp

checks=0
def ck(value):
    global checks
    assert bool(value)
    checks+=1

u,v,s=sp.symbols('u v s', real=True)
# One- and two-rank laws, and the ordered outer/inner marginals.
ck(sp.integrate(1,(u,0,v))==v)
ck(sp.integrate(2*u,(u,0,v))==v**2)
ck(sp.integrate(2*u,(u,0,1))==1)
ck(sp.integrate(2*(1-u),(u,0,1))==1)
ck(sp.simplify(2*u+2*(1-u))==2)
# Asymmetric inherited gate L(original first rank,original second rank)=1[first<second].
original_gate_mass=sp.integrate(sp.integrate(1,(v,0,u)),(u,0,1))
wrong_unswapped_sorted_gate_mass=sp.Integer(0)
orientation_labelled_mass=sp.integrate(sp.integrate(2*sp.Rational(1,2),(v,0,u)),(u,0,1))
ck(original_gate_mass==sp.Rational(1,2))
ck(wrong_unswapped_sorted_gate_mass!=original_gate_mass)
ck(orientation_labelled_mass==original_gate_mass)
# Explicit real L1 plateau example: f=1[-2,-1]+1[1,2], B=0, R_B=6.
# For X in the positive component, rank=|X|-1; negative component is identical.
rank_density_integral=sp.integrate(sp.Rational(1,2),(u,0,v))*2
ck(rank_density_integral==v)
# Small-scale coefficient inequality at representative exact compatible parameter points.
for n in range(1,5):
    for radius_ratio in (F(1),F(3,2),F(2)):
        for p in (F(0),F(1,10),F(1,2),F(1)):
            ck(p*p<=p*radius_ratio**n)
# Original large denominator cancels; no inverse inner-mass singularity.
m,ms,t,q=sp.symbols('m ms t q',positive=True)
ck(sp.simplify((2*ms/m)*(t*q/m)/ms-2*t*q/m**2)==0)
# Exact face coordinates: dx=(s^(n-1)/2) ds du_face on each face.
for n in range(1,5):
    coords=sp.symbols('w:'+str(n-1))
    for sign in (-1,1):
        image=sp.Matrix([sign*s/2]+[s*z for z in coords])
        determinant=sp.simplify(image.jacobian((s,)+coords).det())
        ck(sp.simplify(determinant-sign*s**(n-1)/2)==0)
    ck(sp.simplify((2*n)*(s**(n-1)/2)-n*s**(n-1))==0)
print(f'PASS {checks} exact rank, asymmetric-gate, small-scale, cancellation and face-Jacobian checks; no high-density/root bound')
