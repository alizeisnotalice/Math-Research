#!/usr/bin/env python3
"""One prescribed real three-cube low-tau fixture exhibiting a nonadmitted direction collision."""
from fractions import Fraction as F
from pathlib import Path
from itertools import product,combinations_with_replacement
from collections import Counter
from math import factorial,prod
import hashlib,json,sys,platform,time
BASE=Path(__file__).resolve().parent

def enc(x):
    if isinstance(x,F):return str(x)
    if isinstance(x,dict):return {str(k):enc(v) for k,v in x.items()}
    if isinstance(x,(tuple,list)):return [enc(v) for v in x]
    return x

def volume(B):return prod(max(F(0),hi-lo) for lo,hi in B)
def intersection(B,C):return [(max(a,c),min(b,d)) for (a,b),(c,d) in zip(B,C)]
def inside(x,B):return all(lo<t<hi for t,(lo,hi) in zip(x,B))
def all_masks(A):
    n=len(A[0]);masks={};axes=[]
    for d in range(n):
        ends=sorted({v for B in A for v in B[d]})
        axes.append([((l+h)/2,(l,h)) for l,h in zip(ends,ends[1:])])
    rawcells=0
    for coords in product(*axes):
        x=[p for p,I in coords];mask=sum(1<<i for i,B in enumerate(A) if inside(x,B))
        rawcells+=1
        if mask:masks.setdefault(mask,x)
    return masks,rawcells

def run():
    started=time.time();n=2;a=64;c0=F(65,64);w=F(1,4096);tau=2*w
    centers=[(F(0),F(-9,10)),(F(1,5),F(9,10)),(F(3,2),F(0))];radii=[F(1),F(1),F(3,4)]
    A=[[(y-s,y+s) for y in C] for C,s in zip(centers,radii)]
    B=[[(y-s/a,y+s/a) for y in C] for C,s in zip(centers,radii)]
    assert all(any(B[i][d][1]<B[j][d][0] or B[j][d][1]<B[i][d][0] for d in range(n)) for i in range(3) for j in range(i))
    masks,rawcells=all_masks(A);q=[];prefixmax=[]
    def load(mask,stop):return sum((q[i] for i in range(stop) if mask>>i&1),F(0))
    for j in range(3):
        m=max((load(mask,j) for mask in masks if mask>>j&1),default=F(0))
        prefixmax.append(m);q.append(min(w,max(F(0),tau-m)))
        assert all(load(mask,j+1)<=tau for mask in masks)
    assert q==[w,w,F(0)]
    losses=[i for i,v in enumerate(q) if v<w];assert losses==[2]
    admissions=[]
    for j in range(3):
        rate=sum((q[i] for i in range(j) if all(abs(centers[j][d]-centers[i][d])<=c0*radii[i] for d in range(n))),F(0))
        assert rate<=1;admissions.append(rate)
    z=(F(7,8),F(0));assert all(inside(z,C) for C in A)
    assert sum(q,F(0))==tau and load(7,3)==tau
    # Complete positive source set at the target shared witness, removing anchor.
    P={i for i in range(3) if q[i]>0 and inside(z,A[i])}-{2};assert P=={0,1}
    X=B[2];Xvol=volume(X);rho=radii[2]
    assert q[2]==0 and Xvol==F(9,16384)
    pairdist=[abs(centers[1][d]-centers[0][d]) for d in range(n)]
    failed=[d for d in range(n) if pairdist[d]>c0*radii[0]];assert failed==[1]
    # Entire closed receiver box lies strictly above both source x upper faces.
    assert all(X[0][0]>A[i][0][1] for i in P)
    # In fact receiver y is strictly inside both original source y intervals.
    assert all(A[i][1][0]<X[1][0] and X[1][1]<A[i][1][1] for i in P)
    degrees=[]
    for k in range(2,7):
        cats=dict(no_distinct_collision=F(0),admitted_only=F(0),mixed=F(0),nonadmitted_only=F(0));details=[]
        for tup in combinations_with_replacement(sorted(P),k):
            key=tuple(sorted(Counter(tup).items()));support={i for i,m in key}
            coef=prod(q[i]**m for i,m in key)/prod(factorial(m) for i,m in key)
            I=[(max(A[i][d][0] for i in support),min(A[i][d][1] for i in support)) for d in range(n)]
            H=[(lo-c0*rho,hi+c0*rho) for lo,hi in I]
            overlap=intersection(H,X);assert volume(overlap)==Xvol
            # Source-face partition of actual H intersect X; no face cuts it here.
            axes=[]
            for d,(lo,hi) in enumerate(overlap):
                cuts=sorted({lo,hi}|{v for i in support for v in A[i][d] if lo<v<hi})
                axes.append(list(zip(cuts,cuts[1:])))
            assert prod(len(axis) for axis in axes)==1
            for cell in product(*axes):
                x=[(lo+hi)/2 for lo,hi in cell];directions={}
                for i in support:
                    violated=[(d,-1 if x[d]<lo else 1) for d,(lo,hi) in enumerate(A[i]) if x[d]<lo or x[d]>hi]
                    assert violated;directions[i]=violated[0];assert directions[i]==(0,1)
                r=sum(m for i,m in key);assert r==k
            haspair=len(support)==2
            cat='nonadmitted_only' if haspair else 'no_distinct_collision'
            fee=coef*Xvol;cats[cat]+=fee
            details.append(dict(multi_index=key,support=sorted(support),coefficient=coef,original_anchor=2,rho=rho,intersection=I,halo=H,actual_X=X,halo_X_volume=volume(overlap),source_first_violated_directions=directions,r=k,category=cat,weighted_volume=fee,pair=dict(i=0,j=1,i_center=centers[0],j_center=centers[1],radius_ratio=F(1),full_gate_threshold=c0,pair_center_distances=pairdist,failed_coordinates=failed,failed_other_coordinate_count=1,admitted=False,tag_pair_multiplicity=dict(key)[0]*dict(key)[1]) if haspair else None))
        total=sum(cats.values(),F(0));expected=tau**k/factorial(k)*Xvol
        assert total==expected
        assert cats['nonadmitted_only']==F(2**k-2,factorial(k))*w**k*Xvol
        assert cats['no_distinct_collision']==F(2,factorial(k))*w**k*Xvol
        assert cats['admitted_only']==cats['mixed']==0
        degrees.append(dict(k=k,key_count=k+1,pure_repeat_key_count=2,distinct_pair_key_count=k-1,category_weighted_volumes=cats,total_weighted_volume=total,expected_total=expected,nonadmitted_fraction_of_all_outside=F(2**k-2,2**k),full_admitted_fraction_of_distinct_pair=F(0),details=details,all_checks_passed=True))
    result=dict(title='R680 prescribed three-cube gap fixture: actual nonadmitted distinct direction pair',python=sys.executable,python_version=sys.version,platform=platform.platform(),command=[sys.executable,str(Path(__file__).resolve())],script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),elapsed_seconds=time.time()-started,n=n,a=a,c0=c0,w=w,tau=tau,centers=centers,radii=radii,source_cubes=A,small_cubes=B,closed_small_cubes_disjoint=True,raw_endpoint_cells=rawcells,positive_masks=[dict(mask=m,representative=x,prefix_loads=[load(m,j) for j in range(4)]) for m,x in sorted(masks.items())],q=q,prefix_esssup=prefixmax,losses=losses,expanded_center_admission=admissions,shared_witness=z,strict_P=sorted(P),actual_receiver_X=X,actual_receiver_volume=Xvol,original_anchor=2,original_anchor_radius=rho,pair_failed_coordinates=failed,degrees=degrees,all_checks_passed=True,scope='Single prescribed true geometric low-tau fixture; exact complete endpoint-cell enumeration recomputes q. It exhibits the nonadmitted distinct-pair branch missing from older fixtures. It is not a hard-tau example and does not refute the global target. No unrelated scan or old-file modification.')
    (BASE/'GAP_RESULT.json').write_text(json.dumps(enc(result),indent=2)+'\n')
    print(json.dumps(enc(dict(all_checks_passed=True,q=q,positive_masks=len(masks),raw_endpoint_cells=rawcells,admission=admissions,failed_pair_coordinates=failed,actual_receiver_volume=Xvol,k=[dict(k=D['k'],nonadmitted_fraction=D['nonadmitted_fraction_of_all_outside'],distinct_pair_keys=D['distinct_pair_key_count']) for D in degrees],script_sha256=result['script_sha256']))))
if __name__=='__main__':run()
