# R680 S3 independent global-pair pre-review

Status: FINAL PASS within the bounded scope below. No mandatory mathematical correction found in the finalized REPORT and two author notes. The admission/deletion recurrence was independently derived before reading R680 author drafts. It is not contractive or a complete source payment.

## 1. Full finite objects and branch quantifiers

Retain the entire original finite input, original source indices/radius order, actual owners, static q, original center admission, R677 fixed self-corrected cores and the same actual residual receiver union Y. For each positive degree r use those SAME cores to define eligibility, earliest core a(m), original-anchor radius rho_m, intersection, halo and causal mask. Let K_m(x) be the complete all-outside kernel, retaining all those conditions and the actual receiver x. Define

    D_out,r=sum_{|m|=r} (q^m/m!) integral_Y K_m(x) dx.

The desired degree-k same-direction distinct-source pair budget remains the complete R679 D_pair target. A deterministic global direction choice depends only on (i,x).

For an unambiguous disjoint key partition, an admitted branch can mean that the counted key at x has AT LEAST ONE qualifying distinct-source direction pair i<j with y_j in c0 A_i. Its complement within the pair kernel has NO admitted qualifying pair. A key can otherwise have both admitted and nonadmitted pairs; calling the two pair-existence events disjoint would be wrong. Overlapping upper-bound sums are permissible when their overcount is stated.

## 2. Genuine owner F_i times F_j times Y identity

For a nonnegative marked-pair integrand G_i,j(x),

    q_i q_j integral_Y G_i,j(x) dx
      =integral_Fi integral_Fj integral_Y
                   G_i,j(x)/(d_i d_j) dx dv du.

This is exact with the TRUE owner measures. Finite nonnegative sums and these integrals may be interchanged by Tonelli. No atoms at centers replace the owners. Even though labeled owner-product sets are disjoint, their total unweighted mass is quadratic in U; disjointness alone is not a linear-U estimate.

The original gate y_j in c0 A_i remains a center gate under this identity. It does not automatically become a new admission test at an arbitrary point of F_j. A moving owner/receiver transport would need its own exact representation and cost.

## 3. When the admission rate can really be used once

Original admission gives, for each genuine positive source j,

    sum_{i<j: y_j in c0 A_i}q_i<=1.

This is a valid once-per-fixed-j weighted rate bound. It does NOT justify replacing a sum of q_i K_i by a chosen K_j when K_i depends on the added source i. At that stage one only has a weighted average or a supremum, whose kernel still needs payment.

There is, however, a legal common dominating kernel. For a full key m=v+e_i+e_j of degree k>=2, delete just the marked occurrence i. The positive-degree key m'=v+e_j has

    a(m')<=a(m), rho_m'>=rho_m,
    I_m' contains I_m, H_m' contains H_m,
    Z_m' contains Z_m.

Its outside constraints are weaker. Thus K_m(x)<=K_m'(x). This is the all-outside geometry, not preservation of a direction pair after deleting its member.

For fixed v,j, the shorter kernel K_(v+e_j) is independent of the ADDED index i. This remains true if the fixed v already contains that label. Only AFTER this domination may the original admitted i-rate be summed as at most one. No unproved conditional iid law or source-independent first-group assignment is used.

The new first core still has its own explicit self deletion. Its sources strictly precede its own anchor and all causal receivers. Deleting an occurrence does not introduce a self source, change original indices, rerun q, or preserve an obsolete first-group radius; its earlier/larger geometry is included in the inequality.

## 4. Exact recurrence and all factorial fees

Upper-mark every qualifying admitted distinct pair. A fixed m is then counted with the sum of m_i m_j over its qualifying pairs, at least one on the admitted branch. Dropping the direction condition after the legal deletion gives

    D_adm,k
      <=sum_j q_j sum_{|v|=k-2}(q^v/v!)
                    integral_Y K_(v+e_j)(x) dx
       =(k-1) D_out,k-1.

The equality follows from the source-marking identity at degree k-1: sum_j m'_j=k-1. There is no missing 1/k, pair-count denominator or second deletion gain. Marking may overcount; that overcount is retained in this upper certificate.

With

    F_r=r! D_out,r/T_*^r,
    F_adm,k=k! D_adm,k/T_*^k,

the exact resulting upper coefficient is

    F_adm,k <=[k(k-1)/T_*] F_k-1.

At the prescribed parameters,

    k>=128sqrt(n), k-1>=127sqrt(n), T_*<=6144sqrt(n),
    k(k-1)/T_* >=(127/48)sqrt(n)>=127/3>1.

The leading size is (8/3)sqrt(n). This coefficient is not small or uniform. It is a limitation of THIS upper recurrence, not a lower bound for the actual branch and not an impossibility theorem for a better normalized selection/charge.

Neither lower-degree eligibility nor a factorial identity supplies a terminal bound. Repeatedly invoking this recurrence would retain every multiplier and eventually require a real positive-degree terminal cost. Deleting to degree zero is outside the defined intersection/halo kernel. No terminal source budget or contractive recursion is certified here.

## 5. The nonadmitted direction pair supplies geometry, not payment

For i<j, original radius order gives s_i>=s_j. R679's same-direction pair relation already proves |y_i,l-y_j,l|<=c0s_i in their common outside coordinate l. If the full center gate fails, there is another coordinate d with

    |y_i,d-y_j,d|>c0s_i,

and necessarily d differs from l. Positive parent intersection further implies |y_i,d-y_j,d|<s_i+s_j, hence s_j>(c0-1)s_i=s_i/(32n). These are genuine geometric restrictions.

They do not create another independently spendable capacity. The new coordinate need not lie after l in the coordinate order; choosing it does not make different source populations disjoint, freeze the common point, or pay the remaining coordinates. Any recursive use must preserve the complete key, actual receiver, selected halo, direction assignments and all marking/branch factors.

## Preliminary disposition

Legal once-rate use requires explicit domination by the shorter, i-independent complete kernel. With that step, the displayed admission/deletion recurrence is valid and has exactly the stated degree/factorial fee. True owner-product Fubini is valid. The admitted branch is not thereby bounded by C U or C tau P0, the recurrence is not contractive, and the nonadmitted new-coordinate branch remains unpaid.

No R680 author draft was read in deriving this pre-review. No subagent, Git/PDF action, numerical experiment or arbitrary counterexample scan was undertaken. Only S3_REVIEW.md is written. Final-author comparison and source binding remain pending.

## 6. Available pair/gap source and metadata inspection

Read PAIR_CHECK.py and GAP_FIXTURE.py completely, and inspected compact metadata/scope of their saved JSON. Neither script was executed by this reviewer. Per-cell and per-key data were not manually audited.

PAIR_CHECK reuses the saved R677 actual strips and strict original P minus its anchor. It keeps full first-core-like eligibility, original-anchor halos, future actual receivers, source multiplicities and exact rational source-face partitions. Within each all-outside cell it computes the first violated signed coordinate, enumerates DISTINCT source pairs, checks the center gate in ALL coordinates, and records failed coordinates. Each receiver-key-cell gets one disjoint category: no distinct collision, admitted-only, mixed or nonadmitted-only. Its separate pair-marked mass retains m_i m_j and is not confused with cell demand.

Metadata records 100 degree/policy/fixture records, 3335 scanned cells, 1045 all-outside cells, 640 admitted-only cells, 405 no-distinct-collision cells, and no mixed/nonadmitted cells. It records 840 admitted pair occurrences and agreement of all 100 outside aggregates with the prior R679 crossing reference. These particular older fixtures do not explore the missing nonadmitted branch; their zero count is not an all-input theorem or a paid budget.

The prescribed GAP fixture recomputes a true low-threshold three-cube static recursion from all realizable positive endpoint masks. Its listed data give q=(w,w,0), w=1/4096, tau=2w, original center-admission rates zero, and an actual loss receiver B_2 of volume 9/16384. Its two positive sources share the stated face-free saturation witness, both avoid the entire receiver in the same first coordinate, and their full center gate fails in the second coordinate. Every listed first-anchor halo covers the receiver. Algebraically, mixed-source keys carry fraction 1-2^(1-k) of the total all-outside degree-k weight; pure repeated labels carry the remainder. This agrees with the source/metadata definitions.

This is n=2 and low tau, using strict P rather than a hard K'. It is NOT an actual hard-regime residual counterexample. In particular the inherited real far/up classification would put that toy target in an upper-paid class. Its proper role is to show that the nonadmitted geometric pair possibility is not absent from all static real-cube examples, not to disprove the complete goal or the hard-core route. No unrelated scan is inferred or performed.


## 7. Final mathematical comparison and added owner geometry

Read REPORT.tex, A1_FULL_PAIR_PAYMENT.md and S2_OWNER_PAIR.md in full. Their complete actual-receiver target, disjoint admitted/complement event definition, original full center gate, explicit shorter-kernel domination, exact (k-1)D_out,k-1 recurrence, normalized k(k-1)/T_* coefficient, and unproved terminal/complement costs agree with the independent derivation. No mandatory mathematical correction remains.

For a failed center coordinate p, the whole smaller owner statement is valid: every v in B_j satisfies |v_p-y_i,p|>c0s_i-s_j/a>=s_i. Thus B_j and F_j are outside A_i in that coordinate. This is different from the common receiver-violation coordinate; it does not move the receiving x integral to the owner or produce a full capture edge.

A1's stated owner-coordinate bounds also follow directly: owner displacement in the captured coordinate is at most (1+3/a)s_i, while in the failed coordinate it exceeds s_i-s_j/a. They preserve a near relation in one coordinate and an outside relation in another, not a paid all-coordinate relation.

The positive-intersection width defect is valid. A failed center separation greater than c0s_i forces the pair/whole-key width in that coordinate below s_j-s_i/a. It also gives s_j>s_i/a. The stronger bound s_i/s_j<n/2 follows for any pair in a fixed eligible core, since all its source radii lie between its original anchor radius and n times its minimum remaining target radius divided by two. Hence the proposed far-pair condition s_i>=n s_j is empty in this eligible universe; no payment is credited to it.

These absolute width restrictions do not give a fresh relative loss against a shorter-key intersection already narrowed by other labels. Repeated failed coordinates therefore cannot be charged as independent contractions without a new cumulative argument. Original low load throughout B_j controls labels STRICTLY before j, whereas the other labels in the completed key need not all precede j. The author notes and report correctly retain that history obstacle.

The degree-one envelope D_1<=(1+c0)^n U is valid because the eligible single-source halo radius is at most its source radius. It is only an exponential upper certificate. No degree-zero kernel, omitted terminal cost or uniform U budget is inferred from it. Consistent use of the larger full-first variant preserves deletion geometry too, but must retain its own radius and causal mask throughout; it cannot borrow a smaller core-first cost.

## 8. Final finite-evidence scope and archive transformation

The final report explicitly states that the prescribed GAP target has far rate zero and upper rate 2w, so is UPPER-PAID. This is the correct interpretation of its listed n=2 radii. It does NOT show D_N,k>0 under the frozen hard residual/core contract. The fixture only tests the raw low-threshold recursion/admission implication. Its nonadmitted pair is not a counterexample to the sought complete bound, and it is not counted as evidence that the hard complementary branch is nonempty.

The older pair experiments' admitted-only findings likewise do not prove that hard complement empty. The actual hard complementary geometry remains unresolved. This scope is stated at the report's outset and conclusion, rather than being hidden behind a local diagnostic.

A read-only structural JSON comparison confirmed that PAIR_AGGREGATES.json equals PAIR_SUMMARY.json after removing ONLY each record's cell_records field, plus adding archive_note and full_result_sha256. All 100 aggregate records remain unchanged. This is a provenance/serialization check, not a rerun of rational cell calculations. The source algorithms and compact metadata were inspected; no claim is made that every cell or per-key result was manually read or independently recomputed. GAP_RESULT.json remains the complete saved local result, with its algorithm and scope inspected rather than a numerical rerun.

The saved script hashes match their result metadata. PAIR references the prior actual input and the R679 crossing result by hash; the prescribed GAP fixture is generated explicitly by its own saved source. No unrelated example scan was launched by this reviewer.

## Final disposition and artifact binding

FINAL PASS covers the exact genuine-owner Fubini identity, the qualified once-per-center admission use AFTER full-kernel domination, source timing/self preservation, multiplicity/factorial costs, the noncontractive recurrence, complementary owner/scale/width geometry, truthful diagnostic scope, and bounded report/algorithm/metadata consistency.

No complete admitted-branch C U payment, uniform contracting recursion, hard-residual nonadmitted-branch example, terminal payment, whole-pair owner transport, general root-order bound or impossibility theorem is certified. The complete original actual receiver and full-family P0 objective remain unchanged.

Final SHA-256 values under /Volumes/data/CodexTemp/centered-cube-r680-20261115:

- REPORT.tex: 0deeaee91e2c1a78eb7e8a60a05595fbc6d1e9dbe331d03b1d818e4a0a7c59d6
- A1_FULL_PAIR_PAYMENT.md: 6efcfcb727a3cd211a557c25df9a5f20ae391552ff853c9393c475a75c915db0
- S2_OWNER_PAIR.md: b58add36f49d5a25b712c083764c8aec89b62c3c9578d0d39ee0d8227103e941
- PAIR_CHECK.py: 053d23d2a8c997515490283caf5fb53a7fb7b823c59c8672bf47a84e58792a9b
- PAIR_AGGREGATES.json: e6a0171a8830eb97b2b639819fda69b0ffc3a13b2ddb77e1863982b2c73ee1c6
- GAP_FIXTURE.py: 82d8ee2cdaf9afb5b8494a64d2812931fb437a7066872547d4a2207fe030b197
- GAP_RESULT.json: afd51692767be1d85aea28330f6805430d606e6fbe3b3fc374d119ecee45c57c

Referenced prior input: 51133281e98e46889690d01d1a3a47a114c6dad79ec123cb9d3929f95e16d642. Referenced prior full crossing result: fd473eb2e7399e2be86eb1109703ff86569f3cd6d9698b3c62b920bbaec03bb4. Hashes bind artifacts, not mathematical truth or an independent per-cell data audit. Only S3_REVIEW.md was written by this reviewer. No subagent, Git/PDF action or numerical experiment rerun was performed. Bounded audit complete; stop.
