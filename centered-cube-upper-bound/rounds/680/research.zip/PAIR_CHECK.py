#!/usr/bin/env python3
"""R680: finite actual-cell distinct direction-collision versus full center-admission test."""
from pathlib import Path
from fractions import Fraction as F
from itertools import combinations_with_replacement,combinations,product
from collections import Counter
from math import factorial,prod
import argparse,json,hashlib,sys,platform,time
BASE=Path(__file__).resolve().parent

def enc(x):
    if isinstance(x,F):return str(x)
    if isinstance(x,dict):return {str(k):enc(v) for k,v in x.items()}
    if isinstance(x,(tuple,list)):return [enc(v) for v in x]
    return x

def volume(box):return prod(max(F(0),h-l) for l,h in box)
def intersection(B,C):return [(max(a,c),min(b,d)) for (a,b),(c,d) in zip(B,C)]
def parts(A,support,box):
    axes=[]
    for d,(lo,hi) in enumerate(box):
        ends=sorted({lo,hi}|{t for i in support for t in A[i][d] if lo<t<hi})
        axes.append(list(zip(ends,ends[1:])))
    return axes

def run(args):
    started=time.time();raw=args.input.read_bytes();src=json.loads(raw);records=[];allcells=0
    reference_info=None;reference_values={}
    if args.crossing_reference:
        rr=args.crossing_reference.read_bytes();ref=json.loads(rr)
        assert ref['input_sha256']==hashlib.sha256(raw).hexdigest()
        reference_info=dict(path=str(args.crossing_reference.resolve()),sha256=hashlib.sha256(rr).hexdigest(),owning_script_sha256=ref['script_sha256'])
        reference_values={(R['fixture'],R['policy'],R['k']):F(R['global_r_equals_k']) for R in ref['records']}

    for fi in src['fixtures']:
        assert fi['all_checks_passed'];n=fi['n'];a=fi['a'];c0=F(fi['c0']);q=list(map(F,fi['q']))
        centers=[list(map(F,C['y'])) for C in fi['cubes']];radii=[F(C['s']) for C in fi['cubes']]
        A=[[(y-radii[i],y+radii[i]) for y in C] for i,C in enumerate(centers)]
        X=[]
        for h,C in enumerate(centers):
            B=[(y-radii[h]/a,y+radii[h]/a) for y in C];B[0]=(F(fi['receiver_strips'][h]['cut']),B[0][1])
            assert volume(B)==F(fi['receiver_strips'][h]['X_volume']);X.append(B)
        for policy,pr in fi['policies'].items():
            groups=pr['groups'];P=[set(G['positive_sources'])-{G['anchor']} for G in groups]
            for k in range(2,7):
                keys=sorted({tuple(sorted(Counter(t).items())) for p in P for t in combinations_with_replacement(sorted(p),k)})
                cats={s:F(0) for s in ('no_distinct_collision','admitted_only','mixed','nonadmitted_only')};counts={s:0 for s in cats}
                pairfees=dict(admitted=F(0),nonadmitted=F(0));paircounts=dict(admitted=0,nonadmitted=0)
                cellrecords=[];scanned=0;alloutsidecells=0
                for key in keys:
                    support={i for i,m in key};mult=dict(key);first=next(b for b,p in enumerate(P) if support<=p)
                    rho=radii[groups[first]['anchor']];coef=prod(q[i]**m for i,m in key)/prod(factorial(m) for i,m in key)
                    I=[(max(A[i][d][0] for i in support),min(A[i][d][1] for i in support)) for d in range(n)]
                    H=[(lo-c0*rho,hi+c0*rho) for lo,hi in I]
                    commonz=list(map(F,groups[first]['witness']))
                    assert all(all(lo<commonz[d]<hi for d,(lo,hi) in enumerate(A[i])) for i in support)
                    for b in range(first,len(groups)):
                        for h in groups[b]['members']:
                            clip=intersection(H,X[h])
                            if not volume(clip):continue
                            for B in product(*parts(A,support,clip)):
                                scanned+=1;x=[(lo+hi)/2 for lo,hi in B];v=prod(hi-lo for lo,hi in B)
                                directions={}
                                for i in sorted(support):
                                    violated=[(d,-1 if x[d]<lo else 1) for d,(lo,hi) in enumerate(A[i]) if x[d]<lo or x[d]>hi]
                                    if violated:directions[i]=violated[0]
                                if len(directions)!=len(support):continue
                                alloutsidecells+=1;weighted=coef*v
                                for i,j in combinations(sorted(support),2):
                                    if directions[i][0]==directions[j][0]:assert directions[i][1]==directions[j][1]
                                pairs=[]
                                for i,j in combinations(sorted(support),2):
                                    if directions[i]!=directions[j]:continue
                                    d,sign=directions[i]
                                    dist=[abs(centers[j][t]-centers[i][t]) for t in range(n)]
                                    limit=c0*radii[i];failed=[t for t in range(n) if dist[t]>limit]
                                    admitted=not failed;assert radii[i]>=radii[j]
                                    kind='admitted' if admitted else 'nonadmitted'
                                    tagged_pair_mult=mult[i]*mult[j]
                                    pairfees[kind]+=weighted*tagged_pair_mult;paircounts[kind]+=1
                                    pairs.append(dict(i=i,j=j,directed_coordinate=[d,sign],i_center=centers[i],j_center=centers[j],i_radius=radii[i],j_radius=radii[j],radius_ratio_i_over_j=radii[i]/radii[j],center_coordinate_distances=dist,full_gate_threshold=limit,full_center_admitted=admitted,failed_gate_coordinates=failed,failed_other_coordinates=[t for t in failed if t!=d],failed_other_coordinate_count=sum(t!=d for t in failed),source_tag_pair_multiplicity=tagged_pair_mult))
                                yes=any(p['full_center_admitted'] for p in pairs);no=any(not p['full_center_admitted'] for p in pairs)
                                cat='mixed' if yes and no else ('admitted_only' if yes else ('nonadmitted_only' if no else 'no_distinct_collision'))
                                cats[cat]+=weighted;counts[cat]+=1
                                # One category per receiver-key-cell, even when mixed
                                # or several admitted/nonadmitted pairs are present.
                                cellrecords.append(dict(multi_index=key,first_eligible_group=first,original_anchor=groups[first]['anchor'],target_group=b,receiver=h,cell_bounds=B,representative=x,weighted_cell_volume=weighted,source_first_violated_directions=directions,category=cat,distinct_collided_pairs=pairs))
                alloutside=sum(cats.values(),F(0));collided=cats['admitted_only']+cats['mixed']+cats['nonadmitted_only'];covered=cats['admitted_only']+cats['mixed']
                assert collided==covered+cats['nonadmitted_only']
                if reference_values:assert alloutside==reference_values[(fi['name'],policy,k)]
                stages=[]
                if n in (1,2) and k==2:stages.append('initial_n1_n2_k2')
                if 'multiscale' in fi['name'] and k in (3,4):stages.append('stress_multiscale_k3_k4')
                if n in (3,4,6) and k in (5,6):stages.append('expanded_n3_n4_n6_k5_k6')
                records.append(dict(fixture=fi['name'],n=n,k=k,policy=policy,stages=stages,key_count=len(keys),scanned_cells=scanned,all_outside_cells=alloutsidecells,category_weighted_volumes=cats,category_cell_counts=counts,all_outside_weighted_volume=alloutside,distinct_collision_weighted_volume=collided,full_admitted_available_weighted_volume=covered,nonadmitted_required_weighted_volume=cats['nonadmitted_only'],full_admitted_available_fraction_of_collision=covered/collided if collided else None,tag_pair_multiplicity_weighted_volumes=pairfees,pair_occurrence_counts=paircounts,cell_records=cellrecords,all_checks_passed=True))
                allcells+=scanned
    totals=dict(records=len(records),scanned_cells=allcells,all_outside_cells=sum(R['all_outside_cells'] for R in records),nonadmitted_pair_occurrences=sum(R['pair_occurrence_counts']['nonadmitted'] for R in records),admitted_pair_occurrences=sum(R['pair_occurrence_counts']['admitted'] for R in records),records_with_nonadmitted_required=sum(bool(R['nonadmitted_required_weighted_volume']) for R in records),category_cell_counts={cat:sum(R['category_cell_counts'][cat] for R in records) for cat in ('no_distinct_collision','admitted_only','mixed','nonadmitted_only')})
    stage_stats={}
    for stage in ('initial_n1_n2_k2','stress_multiscale_k3_k4','expanded_n3_n4_n6_k5_k6'):
        rr=[R for R in records if stage in R['stages']]
        stage_stats[stage]=dict(records=len(rr),category_cell_counts={cat:sum(R['category_cell_counts'][cat] for R in rr) for cat in totals['category_cell_counts']},admitted_pair_occurrences=sum(R['pair_occurrence_counts']['admitted'] for R in rr),nonadmitted_pair_occurrences=sum(R['pair_occurrence_counts']['nonadmitted'] for R in rr))
    result=dict(title='R680 actual low-tau distinct direction collisions versus full center admission',input_path=str(args.input.resolve()),input_sha256=hashlib.sha256(raw).hexdigest(),script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),python=sys.executable,python_version=sys.version,platform=platform.platform(),command=[sys.executable,str(Path(__file__).resolve()),'--input',str(args.input)]+(['--crossing-reference',str(args.crossing_reference)] if args.crossing_reference else []),elapsed_seconds=time.time()-started,self_contained=True,crossing_reference=reference_info,reference_records_checked=len(records) if reference_values else 0,original_recursion_rerun=False,totals=totals,stage_statistics=stage_stats,records=records,all_checks_passed=True,definitions=dict(strict_P='original positive_sources minus original anchor',cells='actual causal H_m intersect actual receiver X_h, split at key support source faces; retain only all support sources outside at x',direction='first violated coordinate (smallest index), signed - below lower face and + above upper face',pair='distinct source identities i<j with identical first violated directed coordinate; repeated tags retain mi*mj multiplicity',full_gate='for every coordinate, abs(yj[d]-yi[d])<=c0*si',category_fee='q^m/m! times cell volume; each receiver-key-cell assigned exactly once including mixed cells',additional_pair_total='sum cell fee*mi*mj over every distinct collision pair, separately admitted/nonadmitted; raw pair-tag mass, no unspecified pairkernel denominator claimed'),scope='Finite original low-tau geometry only, k2..6. Tests whether full admission is available on these pair cells, not a pair budget proof. A repeated single-source tag does not count as a distinct pair. Higher-dimensional centers reuse trailing zero coordinates. No hard-tau extrapolation.')
    (BASE/'PAIR_SUMMARY.json').write_text(json.dumps(enc(result),indent=2)+'\n')
    lines=['# R680 finite direction-pair admission decision','',f"Python {platform.python_version()}, `{sys.executable}`. Input SHA256 `{result['input_sha256']}`. Script SHA256 `{result['script_sha256']}`.",'',f"All {len(records)} fixture/policy/k records passed. Scanned {allcells} exact source-face cells; retained {totals['all_outside_cells']} all-source-outside cells. Admission is checked in every coordinate for each distinct collided pair i<j, not only its collision coordinate. Sources, original radii, center differences, failed coordinates and mi*mj pair multiplicities are saved.",'',f"Category cell counts: `{totals['category_cell_counts']}`. Admitted pair occurrences: {totals['admitted_pair_occurrences']}; nonadmitted pair occurrences: {totals['nonadmitted_pair_occurrences']}. Records with nonadmitted-only required volume: {totals['records_with_nonadmitted_required']}.",'','Each receiver-key-cell fee q^m/m! times volume is counted once. Mixed cells retain both pair lists but their receiver-key-cell fee is not duplicated. Additional mi*mj-weighted pair masses are explicitly separate; no unspecified pairkernel denominator is assumed. All actual examples and exact rational category volumes are in PAIR_SUMMARY.json.','', 'All 100 all-outside aggregate values were additionally checked against the existing R679 r=k distribution. Its reference path and hash are saved when --crossing-reference is supplied.','', 'The finite decision is restricted to these low-tau fixtures. The script is self-contained and does not rerun the original recursion. Repeated single-source tags supply no distinct source pair. Empty pair examples, if present, are reported without expanding the scan. No geometric pair-budget or high-tau conclusion follows.','']
    (BASE/'NUMERIC.md').write_text('\n'.join(lines))
    print(json.dumps(enc(dict(all_checks_passed=True,totals=totals,stage_statistics=stage_stats,script_sha256=result['script_sha256']))))
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input',type=Path,default=BASE/'WITNESS_RESULT.json')
    p.add_argument('--crossing-reference',type=Path)
    run(p.parse_args())
