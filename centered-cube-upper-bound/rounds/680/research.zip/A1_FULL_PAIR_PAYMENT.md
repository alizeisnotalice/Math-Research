# R680 A1 — complete-center deletion and the unpaid transverse pair branch

## Outcome

No estimate D_pair<=C U T_min^k/k!, or its full-original-family P0 alternative, is proved. The complete-center-admitted branch permits a legal whole-key deletion inequality, but its normalized coefficient grows like sqrt(n). The nonadmitted branch supplies a definite transverse intersection-width defect, not a uniformly fresh contraction of the remaining key. Real owner double integration has not converted these facts into a summable total debit.

The R679 all-out, distinct-same-direction-pair cover is held fixed. No further birthday or receiver-cover reduction is introduced. Core-first and full-first kernels may each be used, with their own halo and causal mask throughout; a smaller core cost is never substituted into a full-first argument.

## 1. Degree-dependent kernels on the same fixed cores

For each integer t>=1, use the same actual cores K'_a, actual ordered receiver groups Y_a, and original anchor radii. An eligible degree-t multiindex m is supported on some K'_a. Its earliest index a_t(m) is defined by the chosen core-first or full-first rule. Write

    I_m=intersection_{i in support(m)}A_i,
    rho_m=s_{r_{a_t(m)}},
    H_m=I_m+c0 rho_m Q,
    E_m=union_{b>=a_t(m)}Y_b,
    O_m=intersection_{i in support(m)}A_i^c,
    D_out,t=sum_{|m|=t, eligible}(q^m/m!)|H_m intersect E_m intersect O_m|.

The degrees do not change the actual cores or their lower rate T_min=3tau/8-a_geom^(-n). Original q, radius order, genuine owners and the original-family packing optimum are unchanged.

If one occurrence of a label i is deleted from m, the reduced key m' remains eligible. Its earliest index can only decrease, its original anchor radius can only increase, and I_m is contained in I_m'. Hence

    H_m intersect E_m intersect O_m
       subset H_m' intersect E_m' intersect O_m'.            (1)

This accounts for the moving earliest group and halo exactly. It does not freeze them during deletion.

## 2. A legitimate admitted-pair estimate, with its full factorial cost

For i<j define the genuine admission gate

    chi_ij=1{y_j in Q(y_i,c0 s_i)}.

Original expanded-center admission gives

    sum_{i<j}q_i chi_ij<=1.                                 (2)

Let D_adm,k be the part of D_pair whose whole key, at the actual receiver, has at least one qualifying distinct same-direction pair i<j with chi_ij=1. It is bounded above by marking all such pairs and, if convenient, dropping the same-direction condition after marking. Use ordered-word notation for the remaining k-2 slots. Equation (1), followed by (2), gives

    D_adm,k
      <=1/(k-2)! sum_{j,i<j}q_j q_i chi_ij
           sum_{ordered rest}q^rest |whole-key receiver set|
      <=1/(k-2)! sum_j q_j
           sum_{ordered rest}q^rest |reduced-key receiver set|
      =(k-1)D_out,k-1.                                    (3)

The label i is removed; j remains marked. Repetitions in the other slots retain their exact factorial multiplicities. Every nonnegative restriction dropped in deriving (3) is dropped in the upper-bound direction. The actual receiver mask is enlarged only as allowed by (1).

Define the volume-normalized quantity

    R_t=t!D_out,t/T_min^t.

Then (3) yields

    k!D_adm,k/T_min^k
       <=[k(k-1)/T_min]R_k-1.                              (4)

Both factors are essential: the marked-label factor k-1 in (3) and the further factor k/T_min from changing degree. With k~128sqrt(n) and T_min~6144sqrt(n), the coefficient in (4) is asymptotic to (8/3)sqrt(n). It is not a uniform contraction and does not by itself give the desired absolute constant budget.

Choosing a single admitted pair instead of marking every pair does not automatically remove this coefficient. That choice depends on the completed key and actual receiver; after deletion, different insertions can select different surviving marked labels. No bounded weighted-preimage or collision-normalized selection rule has been proved that improves (4) sufficiently. A key can have only one qualifying pair, so an unconditional division by the number of all possible pairs is invalid.

## 3. The nonadmitted branch: a real width defect but no fresh contraction

Consider a qualifying pair i<j, so s_i>=s_j. Its common violated coordinate ell gives the R679 bound

    |y_i,ell-y_j,ell|<=c0 s_i.

If chi_ij=0, there is another coordinate p!=ell with

    |y_i,p-y_j,p|>c0 s_i.                                  (5)

Since the two parents have positive intersection, their intersection width in p is at most s_i+s_j-|y_i,p-y_j,p|. Thus the complete key satisfies

    ell_m,p <s_j-s_i/a_geom<=s_j.                           (6)

This is an actual transverse restriction. Its halo width obeys

    ell_m,p+2c0 rho_m
       <s_j-s_i/a_geom+2c0 rho_m.                          (7)

However, (6) is an absolute comparison with the smaller parent, not a ratio to the intersection of the remaining key after deleting i. Other labels may already impose an equal or smaller width in p. The new pair can then produce no further decrease in that coordinate. Moving the earliest halo under deletion can also enlarge the comparison body, so it must remain in any proposed recurrence.

Consequently a recursion cannot charge a fixed contraction every time it discovers another nonadmitted pair or another violated coordinate. Reusing an already narrow coordinate does not produce a new geometric factor. No argument here bounds those repeated visits by a uniform source budget, or proves that sufficiently many coordinates incur quantitatively fresh losses. Merely recording p!=ell is not progress toward the full payment.

## 4. Real owner double integration does not yet pay the remaining coordinates

The pair weight has the exact owner representation

    q_i q_j=(d_i d_j)^(-1) integral_{F_i}du integral_{F_j}dv. (8)

This preserves the actual disjoint sets F_i. For every u in F_i and v in F_j, the same-direction coordinate and (5) imply, respectively,

    |u_ell-v_ell|<=(1+3/a_geom)s_i,
    |u_p-v_p|>s_i-s_j/a_geom.                              (9)

The first bound uses the two small owner radii s_i/a_geom and s_j/a_geom; the second subtracts them from the strict center separation in (5). Thus owner averaging retains a near relation in one coordinate and a far relation in another. It does not turn the pair into full expanded-center containment.

For a fixed later owner, admission controls earlier sources whose entire expanded parents contain its center. The nonadmitted sources in (5) are outside that gate. Their pieces are genuinely disjoint, but summing their normalized pair weights still requires a spatial capacity estimate for the complete key, including all remaining coordinates and its actual receiver mask. Disjointness of F_i alone does not justify replacing that sum by 1 or by the admitted sum (2).

The exact two-point issue from R679 remains: both the receiving point and an owner point can be outside a larger parent in different coordinates while the whole key shares an original intersection. A common-point fiber representation retains the key-dependent inverse fiber volume; clamp coarea retains all the corresponding traces. Neither density has been bounded in the present owner double integral. The whole-key common point cannot be replaced by the receiving point or owner point when applying the original q-load.

## Final checkpoint

The whole-key estimate (3) is valid and correctly handles moving first eligibility, but (4) shows why it is not a closed budget. The complementary branch has the genuine width defect (6), yet no fresh-loss accounting or joint all-coordinate owner estimate has been established. This is the precise unpaid step for the frozen D_pair.

The parent team's separately executed GAP fixture is a genuine low-threshold original-routing example, but its n=2 target has far load 0 and upper load 2w and is entirely upper-paid under the original far/upper classification. It therefore does not establish that the present hard residual D_N is nonempty. Its scope is only that raw admission and a common witness do not by themselves force the full pair gate; it is neither a counterexample for the current unpaid branch nor a proof of failure. No duplicate scalar computation or new local scan was run here. No child agent, Git operation, PDF, MATLAB session, or edit to another agent's file was performed. Work stops at this bounded checkpoint, without claiming a complete U or P0 payment.
