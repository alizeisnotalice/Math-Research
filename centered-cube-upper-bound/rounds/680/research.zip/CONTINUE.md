# R680 checkpoint: global pair payment still open

Read REPORT.tex and independent review. General C_n<=K sqrt(n) and earlier n^(1/2+o(1)) remain unproved. The R679 >97% complete-cover restriction to all-outside keys with a distinct same-direction pair stays fixed. Do not make another covering probability or another local coordinate label the main next task.

Actual proved comparison: full center-admitted pair event has D_A,k <= (k-1)D_out,k-1 by marking, deleting the earlier source occurrence, enlarging the ENTIRE key geometry, THEN invoking original admission. With fixed-core degree normalization r!D_r/T_*^r, the coefficient is k(k-1)/T_* >=127/3 in the hard regime, not a contraction. The second k cannot be discarded. Degree-one rough envelope is exponential; all complementary intermediate/terminal fees remain.

Nonadmitted pair has a genuine transverse cut and F_j entirely outside A_i, but not a paid receiver-to-owner transport. The smaller pair source is not necessarily the smallest source of the whole key. A previously narrowed coordinate need not incur a fresh loss. Same-core source ratios are <n/2, so a proposed source-pair far branch s_i>=n s_j is empty here.

Next actual mathematical target: a multiplicity-sensitive joint owner estimate repairing the FULL normalized pair budget, or a genuine uniformly contracting recursion with payable complementary and terminal costs. No assumption that the hard nonadmitted branch is empty or nonempty is supplied by the local example below.

## Numerical scope and reproduction

Independent Python: /Users/zzh/.local/share/math-research-tools/venv/bin/python.

PAIR_CHECK.py --input /path/to/R677/WITNESS_RESULT.json --crossing-reference /path/to/R679/CROSSING_SUMMARY.json (check script --help for exact reference option). Original input SHA256 51133281e98e46889690d01d1a3a47a114c6dad79ec123cb9d3929f95e16d642. The R679 full crossing result can be regenerated from its archived script; this round's summary binds the actual comparison input. All 100 prior-record comparisons passed. Full per-cell pair details stay local in PAIR_SUMMARY.json; archived PAIR_AGGREGATES.json removes only cell_records and binds the full-result hash.

GAP_FIXTURE.py is self-contained and reconstructs one exact three-cube low-tau recursion. q=(w,w,0), only target loss, disjoint small boxes and admission all verified. BUT its far rate=0 and upper rate=2w, so it is UPPER-PAID under the actual classification. It is not an example of the hard residual D_N, and does not refute the global goal. It only demonstrates that raw admission/shared-witness structure alone cannot force full center capture. Its mixed-key fractions 1/2,...,31/32 must not be extrapolated to hard tau.

verify.py independently checks all 100 pair totals, five gap degrees, the gap far/upper classification, bad-recursion constant, script/result/review bindings and manifest. It is not a general proof checker. Existing finite inputs use n<=6, low tau and repeated trailing coordinates. No MATLAB opened; no PDF compiled.

One Astra and at most three GPT-6.1 Sol active. Keep next research on the complete budget, not more scans of easy cases. Preserve compact finished-round archive, one commit per round, clean dedicated clone and actual remote push confirmation.
