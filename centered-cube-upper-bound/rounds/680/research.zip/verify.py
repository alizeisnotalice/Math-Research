from pathlib import Path
from fractions import Fraction as F
from math import factorial
import ast,hashlib,json,re
p=Path(__file__).resolve().parent
for n in ['PAIR_CHECK.py','GAP_FIXTURE.py','verify.py']:ast.parse((p/n).read_text())
r=json.loads((p/'PAIR_AGGREGATES.json').read_text());g=json.loads((p/'GAP_RESULT.json').read_text())
assert r['all_checks_passed'] and g['all_checks_passed']
assert r['script_sha256']==hashlib.sha256((p/'PAIR_CHECK.py').read_bytes()).hexdigest()
assert g['script_sha256']==hashlib.sha256((p/'GAP_FIXTURE.py').read_bytes()).hexdigest()
assert r['input_sha256']=='51133281e98e46889690d01d1a3a47a114c6dad79ec123cb9d3929f95e16d642'
assert len(r['records'])==100 and r['reference_records_checked']==100
for z in r['records']:
 v={k:F(x) for k,x in z['category_weighted_volumes'].items()}
 assert sum(v.values())==F(z['all_outside_weighted_volume'])
 assert sum(v[k] for k in ['admitted_only','mixed','nonadmitted_only'])==F(z['distinct_collision_weighted_volume'])
 assert v['admitted_only']+v['mixed']==F(z['full_admitted_available_weighted_volume'])
 assert v['nonadmitted_only']==F(z['nonadmitted_required_weighted_volume'])
 assert sum(z['category_cell_counts'].values())==z['all_outside_cells']
assert sum(z['all_outside_cells'] for z in r['records'])==1045
q=list(map(F,g['q']));w=F(g['w']);tau=F(g['tau']);s=list(map(F,g['radii']))
assert q==[w,w,0] and w==F(1,4096) and tau==2*w
assert g['losses']==[2] and g['closed_small_cubes_disjoint']
far=sum(q[i] for i in [0,1] if s[i]>=g['n']*s[2])
upper=sum(q[i] for i in [0,1] if g['n']*s[2]/2<=s[i]<g['n']*s[2])
assert far==0 and upper==tau # The diagnostic is upper-paid, NOT a hard residual.
V=F(g['actual_receiver_volume']);assert V==F(9,16384)
for z in g['degrees']:
 k=z['k'];total=V*(2*w)**k/factorial(k)
 assert F(z['total_weighted_volume'])==total==F(z['expected_total'])
 assert F(z['nonadmitted_fraction_of_all_outside'])==1-F(2,2**k)
 cats={key:F(x) for key,x in z['category_weighted_volumes'].items()}
 assert sum(cats.values())==total and cats['admitted_only']==cats['mixed']==0
 assert sum(F(t['weighted_volume']) for t in z['details'])==total
assert F(128*127,6144)*16==F(127,3)>1
text=(p/'REPORT.tex').read_text();stack=[]
for m in re.finditer(re.escape(chr(92))+r'(begin|end)\{([^}]+)\}',text):
 if m[1]=='begin':stack.append(m[2])
 else:assert stack and stack.pop()==m[2]
assert not stack
review=(p/'S3_REVIEW.md').read_text()
for n in ['REPORT.tex','A1_FULL_PAIR_PAYMENT.md','S2_OWNER_PAIR.md','PAIR_CHECK.py','PAIR_AGGREGATES.json','GAP_FIXTURE.py','GAP_RESULT.json']:
 assert hashlib.sha256((p/n).read_bytes()).hexdigest() in review,n
if (p/'MANIFEST.json').exists():
 for n,v in json.loads((p/'MANIFEST.json').read_text())['members'].items():
  b=(p/n).read_bytes();assert len(b)==v['bytes'] and hashlib.sha256(b).hexdigest()==v['sha256']
print(json.dumps(dict(passed=True,pair_records=100,gap_degrees=5,gap_far=str(far),gap_upper=str(upper),gap_is_upper_paid=True,manifest_checked=(p/'MANIFEST.json').exists(),scope='recorded exact arithmetic and integrity; not proof of hard residual or general bound')))
