# R680 finite direction-pair admission decision

Python 3.12.14, `/Users/zzh/.local/share/math-research-tools/venv/bin/python`. Input SHA256 `51133281e98e46889690d01d1a3a47a114c6dad79ec123cb9d3929f95e16d642`. Script SHA256 `053d23d2a8c997515490283caf5fb53a7fb7b823c59c8672bf47a84e58792a9b`.

All 100 fixture/policy/k records passed. Scanned 3335 exact source-face cells; retained 1045 all-source-outside cells. Admission is checked in every coordinate for each distinct collided pair i<j, not only its collision coordinate. Sources, original radii, center differences, failed coordinates and mi*mj pair multiplicities are saved.

Category cell counts: `{'no_distinct_collision': 405, 'admitted_only': 640, 'mixed': 0, 'nonadmitted_only': 0}`. Admitted pair occurrences: 840; nonadmitted pair occurrences: 0. Records with nonadmitted-only required volume: 0.

Each receiver-key-cell fee q^m/m! times volume is counted once. Mixed cells retain both pair lists but their receiver-key-cell fee is not duplicated. Additional mi*mj-weighted pair masses are explicitly separate; no unspecified pairkernel denominator is assumed. All actual examples and exact rational category volumes are in PAIR_SUMMARY.json.

All 100 all-outside aggregate values were additionally checked against the existing R679 r=k distribution. Its reference path and hash are saved when --crossing-reference is supplied.

The finite decision is restricted to these low-tau fixtures. The script is self-contained and does not rerun the original recursion. Repeated single-source tags supply no distinct source pair. Empty pair examples, if present, are reported without expanding the scan. No geometric pair-budget or high-tau conclusion follows.
