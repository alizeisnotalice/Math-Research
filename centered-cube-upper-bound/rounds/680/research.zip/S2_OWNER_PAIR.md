# R680 S2 — owner-based pair deletion and the still-unpaid failed-admission transport

**Bounded result.** Full expanded-center admission pays the deletion of ONE older source in the complete admitted-pair kernel, giving the valid global comparison

    D_adm,k <=(k-1)D_out,k-1.                               (1)

After the required factorial/rate normalization the coefficient is
k(k-1)/T_*, asymptotic to (8/3)sqrt(n), not a contraction. Thus (1) is NOT a payment of the admitted branch at the requested CU T_*^k/k! scale.

For failed pairs there is a real owner geometry: if i<j and y_j is outside c0A_i, the ENTIRE B_j, hence F_j, is outside A_i. The failed coordinate is different from their shared receiver-violation coordinate. This gives a true direction-switch configuration, but no bounded transfer of the actual receiver integral onto F_j or a complete pair charge.

No new complete D_pair budget is proved. The exact global comparisons and the owner-integral gap are retained below. Only this assigned file is written; no current-round Astra draft, new child, Git operation, PDF or numerical scan is used.

## 1. Same full kernel at every positive degree

Keep the original R677 cores, source owners, ordered groups, causal receiver union and first-core rule fixed. For every degree d>=1 and eligible multiplicity vector m with |m|=d, put

    a(m)=earliest K'_a containing support(m),
    rho_m=s_{r_{a(m)}},
    I_m=intersection_{m_i>0}A_i,
    H_m=I_m+c0rho_m Q,
    Z_m=union_{b>=a(m)}Y_b,

    K_m(x)=1_{H_m}(x)1_{Z_m}(x)
                 product_{i:m_i>0}1_{A_i^c}(x),

    D_out,d=sum_{|m|=d, eligible}(q^m/m!)integral K_m(x)dx.

The degree changes below do NOT change the original cores or source data. Noneligible summands are zero. The core-first radius is not a spatial-first-hit radius. The larger full-P-first version cannot be substituted without using its own kernel and cost throughout.

Deleting a source occurrence leaves an eligible shorter key with an earlier-or-equal first group, a larger-or-equal intersection, halo radius and causal receiver union, and fewer outside constraints. Therefore

    K_m(x)<=K_{m-e_i}(x)                                   (2)

whenever |m|>=2 and m_i>0. This uses whole key geometry, not a projection or a fixed-pool sampling surrogate.

## 2. Admitted pairs: true original admission applies

At the actual receiver x, directions are the first violated coordinate of each parent. Let chi_ij=1{y_j in Q(y_i,c0s_i)} for i<j. This is FULL n-dimensional center capture, not the one-coordinate consequence of a collision.

Define D_adm,k by restricting D_out,k to keys with some distinct-source same-direction pair satisfying chi_ij=1. A nonnegative marking upper bound is

    D_adm,k
      <=sum_j q_j sum_{i<j}q_i chi_ij
           sum_{|v|=k-2}q^v/v!
             integral K_{v+e_i+e_j}(x)
                      1{directions(i,x)=directions(j,x)}dx.

The multiplicity factors are in the valid direction:
for m_i,m_j>=1, marking contributes m_i m_j times q^m/m!, so this is an UPPER bound for an event with at least one such pair.

Now delete i using (2), and drop only the remaining nonnegative same-direction indicator. The shorter kernel is independent of i. The exact original center-admission inequality at y_j gives

    sum_{i<j}q_i chi_ij<=1.

Thus

    D_adm,k
      <=sum_j q_j sum_{|v|=k-2}q^v/v!
                      integral K_{v+e_j}(x)dx
      =(k-1)D_out,k-1,

proving (1). All actual receiver masks, other key labels and first-group changes have been paid by the monotone enlargement in (2). No fixed common point or inverse-fiber density was pulled outside the summation.

### Exact normalization

Write B_d=d!D_out,d/T_*^d. Equation (1) gives

    k!D_adm,k/T_*^k
       <=[k(k-1)/T_*] B_{k-1}.                             (3)

Since k~128sqrt(n) and T_*~6144sqrt(n), the coefficient is asymptotic to (8/3)sqrt(n). The missing k arises from changing (k-1)! to k!; it cannot be dropped.

Accordingly this is a valid global source-deletion estimate but not an absorbed or fully paid branch. It cannot close the desired constant normalized bound by itself.

## 3. Retaining multiplicity does not currently give the missing gain

For a full key at x let

    N_adm(m,x)=sum_{i<j}m_i m_j chi_ij
                      1{directions(i,x)=directions(j,x)}.

On its admitted event N_adm>0. Keeping the factor 1/N_adm gives an exact marked representation instead of the preceding upper bound. But the supplied hypotheses give only N_adm>=1 on that event, not a uniform larger lower bound on the key/receiver configurations carrying cost.

Deleting i changes the key, its first group and this multiplicity. No proved geometric or weighted-correlation estimate permits replacing 1/N_adm by 1/[k(k-1)] or another factor that repairs (3). This is not an assertion that a better average bound is false; it states precisely what has not been established.

Repeated occurrences of the same source are not a pair of distinct owners and are not used to obtain a free admission edge.

## 4. Failed full capture puts the whole smaller owner outside

Now let a distinct same-direction pair i<j fail full capture:

    y_j notin Q(y_i,c0s_i),    s_i>=s_j.

The R679 collision lemma already gives expanded capture in their common violated coordinate l. Therefore there exists ANOTHER coordinate p!=l with

    |y_j,p-y_i,p|>c0s_i.

For every v in B_j,

    |v_p-y_i,p|
       >=|y_j,p-y_i,p|-s_j/a_geom
       >c0s_i-s_j/a_geom
       =s_i+(s_i-s_j)/a_geom
       >=s_i.

Consequently

    B_j subset A_i^c,   F_j subset A_i^c.                   (4)

This is a whole-owner statement, with a strict coordinate separation. The actual receiver x misses A_i in its shared collision coordinate l, while F_j has a guaranteed failed coordinate p different from l.

It does NOT say that F_j is inside A_i in coordinate l: only c0-expanded center capture was proved there. No additional full center relation is inferred.

## 5. What the real F_j change of integration order leaves

In the marked failed-pair sum the genuine owner substitution is exactly

    q_iq_j integral_Y G_{i,j,ell}(x)dx
      =integral_{F_i}du integral_{F_j}dv integral_Y
                   G_{i,j,ell}(x)/(d_i d_j)dx,               (5)

where ell is the remaining multiplicity vector and G retains the COMPLETE key K_{ell+e_i+e_j}, the actual receiver indicator, same-direction test, failed chi_ij, and any exact multiplicity normalization one chooses to retain.

Nonnegative Tonelli proves (5). The substitutions do not move the receiver x. The owner variables u,v simply realize q_iq_j. Replacing the x integral by one on F_j would remove a real volume factor or require a new transport map and a proved density/Jacobian bound. No such map is provided by (4).

There is also a historical obstacle to applying the load-one property at F_j to the whole remaining key. Original admission gives

    sum_{i<j}q_i1_{A_i}<=1 throughout B_j.

But j is only the smaller-radius member of the CHOSEN pair. It need not be the smallest-radius / largest-index label of the WHOLE key. Other labels can be later than j. They remain before the actual receiver's label but are not covered by the strict-before-j bound on F_j. Treating the entire remaining product as load at most one at F_j would therefore be invalid.

Even for the older labels, the failed i contributes zero throughout F_j by (4), rather than the positive term needed to spend an original full-capture triangle. Its mass has not been charged merely by recognizing that it lies outside.

Inserting the prior-round common-point fiber formula does not remove this gap: its inverse intersection-fiber volume and first-group radius depend on the entire key. That density must remain with (5); it cannot be replaced by an unrelated constant q-capacity at a new owner point.

## 6. The nonempty source-scale range rules out a proposed far escape

For the CURRENT core-eligible key universe, all sources of a key belong to one K'_a. Hence

    max source radius <n r_min,a/2,
    min source radius >=s_{r_a}>=r_min,a,

so any two source radii satisfy

    s_i/s_j<n/2  when s_i>=s_j.                            (6)

Thus a branch requiring s_i>=n s_j is EMPTY for these keys. It cannot be advertised as a global thin-halo payment. This statement concerns the core-eligible universe; enlarging the universe to arbitrary full-P keys would need a separate scale audit.

Constant changes to a far threshold do not automatically price the remaining nonempty near ratios. No such complementary budget is proved here.

## 7. Precise unpaid joint quantity and stop

The admitted-event estimate (1) retains the same original all-space kernel and uses the true full center test, but has the unfavorable normalized coefficient (3). The failed event yields the genuine direction-switch owner geometry (4), yet (5) still contains the actual receiving integral, the whole moving intersection, its first-group selector and all remaining labels.

A successful next step must supply a simultaneous owner/receiver estimate for that FULL quantity, or a genuine complete packing construction. The one-coordinate collision relation, true owner disjointness, and the before-j admission bound have not yet supplied it. No source column condition is declared necessary, and no normalization identity is counted as a global improvement.

This is the bounded author checkpoint. No new global pair budget or contraction is claimed, and no further local direction layer is pursued. The next task is the actual joint owner density/transport normalization, not another cover-constant optimization.
