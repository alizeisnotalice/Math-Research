#!/usr/bin/env python3
"""R78 actual E2 Fisher quadrature diagnostics and exact fine-layer algebra.

Stages 1 and 2 use floating Simpson quadrature and refinement only. They do
not certify quadrature errors or replace the parent's analytic Fisher proof.
Stage 3 uses Fraction/integer tests for the fine-tail allocation identities.
All dependencies are in Python's standard library.
"""
from fractions import Fraction as F
from pathlib import Path
from functools import lru_cache
import json, math, random, time

SEED=780611


def clean(x):
    if isinstance(x,F): return str(x)
    if isinstance(x,dict): return {str(k):clean(v) for k,v in x.items()}
    if isinstance(x,(tuple,list)): return [clean(v) for v in x]
    return x


def simpson(f,a,b,panels):
    assert panels>0 and panels%2==0
    if a==b: return 0.
    step=(b-a)/panels
    return step*(f(a)+f(b)+sum((4 if j%2 else 2)*f(a+j*step) for j in range(1,panels)))/3


def laplace_smoothed(x,s):
    """Stable f_s and f_s' on x>=0; inside uses two nonpositive exponents."""
    x=abs(float(x)); s=float(s); assert s>0
    if x<=.5:
        a=math.exp(-(.5-x)/s); b=math.exp(-(.5+x)/s)
        return 1-(a+b)/2,-(a-b)/(2*s)
    f=-.5*math.expm1(-1/s)*math.exp(-(x-.5)/s)
    return f,-f/s


def component_integral(s,panels):
    """I2=integral x^2 f'^2/f, J=I2-1. Outer exponential moments analytic.

    The inside boundary coordinate u=(.5-x)/s avoids a huge flat bulk interval
    as s->0. The positive derivative-energy integrand decays like exp(-2u).
    A cap at u=24 is an un-certified numerical truncation, explicitly recorded.
    """
    s=float(s); limit=min(.5/s,24.)
    def inside(u):
        a=math.exp(-u); b=math.exp(-(1/s-u))
        f=1-(a+b)/2; x=.5-s*u
        return x*x*(a-b)**2/f
    inside_I2=simpson(inside,0.,limit,panels)/(2*s)
    mass_factor=-math.expm1(-1/s)
    outside_I2=mass_factor*(1/(4*s)+1+2*s)
    outside_J=mass_factor*(1/(4*s)+s)
    I2=inside_I2+outside_I2; J=I2-1
    assert J>0 and I2>1
    return dict(J=J,I2=I2,inside_derivative_energy=inside_I2,
                outside_derivative_energy=outside_I2,outside_J=outside_J,
                boundary_coordinate_upper=limit,boundary_integral_truncated=(limit<.5/s))


def stage1():
    cases=[]
    for denom in (1,2,16,256,1024,2**20,2**40,2**100):
        s=F(1,denom); sv=float(s); refinements=[]
        for panels in (1024,2048,4096):
            refinements.append(dict(panels=panels,**component_integral(sv,panels)))
        fine=refinements[-1]; bound=float(1/(2*s)+2*s)
        assert fine['J']<=bound*(1+1e-9)
        differences=[abs(b['J']-a['J']) for a,b in zip(refinements,refinements[1:])]
        f_boundary,fp_boundary=laplace_smoothed(.5,sv)
        assert f_boundary>0 and fp_boundary<0
        cases.append(dict(s=s,refinements=refinements,successive_J_differences=differences,
                          final_relative_refinement_difference=differences[-1]/fine['J'],
                          analytic_parent_J_upper=bound,observed_J_over_parent_upper=fine['J']/bound,
                          s_times_J=sv*fine['J'],boundary_density=f_boundary,boundary_derivative=fp_boundary,
                          boundary_formula_agrees=True,quadrature_certificate=False))
    return dict(status='DIAGNOSTIC_PASS',scope='Actual h*Laplace(s) component Fisher diagnostics. Outside moments are analytically reduced and floating-evaluated; inside Simpson refinement and u-tail cutoff are not error certificates.',
                component_formula='inside f=1-(exp(-(.5-x)/s)+exp(-(.5+x)/s))/2; outside f=.5*(1-exp(-1/s))*exp(-(x-.5)/s)',
                J_identity='J(f_s)=integral x^2 f_s_prime^2/f_s - 1',
                outside_I2_formula='(1-exp(-1/s))*(1/(4s)+1+2s)',
                parent_analytic_bound='J(f_s)<=1/(2s)+2s',cases=cases,
                small_s_handling='Positive boundary-energy coordinate u and analytic outer moments retain the 1/s divergence; no tiny-s integral is inferred to be zero from exponential underflow.')


class ActualPhi:
    def __init__(self,panels):
        assert panels>0 and panels%2==0
        self.panels=panels
        self.grid=[]
        for i in range(1,panels+1):
            s=i/panels; c=(1 if i==panels else 4 if i%2 else 2)/(3*panels)
            self.grid.append((s,c,-math.expm1(-1/s)))
        self.endpoint_weight=1/(3*panels)

    def evaluate(self,x):
        x=float(x); assert x>=0
        if x<=.5:
            correction=derivative=0.
            for s,c,_ in self.grid:
                a=math.exp(-(.5-x)/s); b=math.exp(-(.5+x)/s)
                correction+=c*s*(a+b); derivative-=c*(a-b)
            if x==.5: derivative-=self.endpoint_weight
            return 1-correction,derivative
        d=x-.5; phi=minusprime=0.
        for s,c,weight in self.grid:
            term=c*weight*math.exp(-d/s)
            phi+=s*term; minusprime+=term
        return phi,-minusprime


def phi_integrals(s_panels,inside_panels,outside_panels,xmax):
    phi=ActualPhi(s_panels); minimum_phi=1.
    @lru_cache(None)
    def values(x):
        nonlocal minimum_phi
        f,dp=phi.evaluate(x); assert f>0 and dp<=1e-14
        minimum_phi=min(minimum_phi,f)
        return f,dp
    def integral(which):
        def integrand(x):
            f,dp=values(x)
            if which=='J': return (f+x*dp)**2/f
            if which=='I2': return x*x*dp*dp/f
            if which=='mass': return f
            return x*dp
        # x=.5 +/- u^2 resolves the boundary's nonuniform small-s layer and
        # suppresses an artificial endpoint weight from the nested s grid.
        inside=lambda u:2*u*integrand(max(0.,.5-u*u))
        outside=lambda u:2*u*integrand(min(xmax,.5+u*u))
        return 2*(simpson(inside,0.,math.sqrt(.5),inside_panels)+
                  simpson(outside,0.,math.sqrt(xmax-.5),outside_panels))
    J=integral('J'); I2=integral('I2'); mass=integral('mass'); moment=integral('xfprime')
    assert 0<J<7/3 and 0<I2<10/3
    return dict(s_panels=s_panels,inside_x_panels=inside_panels,outside_x_panels=outside_panels,
                x_tail_cutoff=xmax,J=J,I2=I2,mass=mass,integral_x_phi_prime=moment,
                x_integration_coordinate='inside x=.5-u^2; outside x=.5+u^2; Jacobian 2u',
                J_minus_I2_plus_1=J-I2+1,minimum_phi_on_quadrature_grid=minimum_phi,
                nonzero_density_on_all_quadrature_nodes=True,
                phi_at_zero=values(0.),phi_at_half=values(.5),phi_at_cutoff=values(xmax),
                quadrature_certificate=False)


def stage2():
    specs=((256,512,1024,24.),(512,1024,2048,32.),(1024,2048,4096,40.))
    refinements=[phi_integrals(*spec) for spec in specs]
    deltas=[dict(J_difference=abs(b['J']-a['J']),I2_difference=abs(b['I2']-a['I2']),
                 mass_difference=abs(b['mass']-a['mass'])) for a,b in zip(refinements,refinements[1:])]
    assert deltas[-1]['J_difference']<1e-4 and deltas[-1]['I2_difference']<1e-4
    return dict(status='DIAGNOSTIC_PASS',scope='Direct actual E2 phi=integral_0^1 2s*(h*Laplace(s)) ds and its derivative; nested piecewise Simpson, grid refinement and expanding outer cutoff. No certified quadrature error.',
                mixture_formula='w(x)=integral_0^1 2s*Laplace(s)(x) ds = integral_0^1 exp(-abs(x)/s) ds; phi=h*w',
                stable_inside_formula='phi=1-integral_0^1 s*(exp(-(.5-x)/s)+exp(-(.5+x)/s))ds; phi_prime=-integral_0^1(exp(-(.5-x)/s)-exp(-(.5+x)/s))ds',
                stable_outside_formula='phi=integral_0^1 s*(1-exp(-1/s))*exp(-(x-.5)/s)ds; phi_prime=-integral_0^1(1-exp(-1/s))*exp(-(x-.5)/s)ds',
                refinements=refinements,successive_differences=deltas,
                parent_analytic_bounds=dict(J_phi=F(7,3),derivative_energy_phi=F(10,3)),
                evidence_limit='Observed convergence, normalization and bound margins support numerical diagnostics only; no floating result is promoted to an exact Fisher certificate.')


def log2_interval(terms=30):
    z=F(1,3); power=z; total=F(0)
    for j in range(terms): total+=2*power/(2*j+1); power*=z*z
    upper=total+2*power/((2*terms+1)*(1-z*z))
    assert 0<total<=upper<1
    return total,upper


def tensor_value(h,phi,eps):
    psi=[(1-eps)*a+eps*b for a,b in zip(h,phi)]
    contrast=math.prod(h)-math.prod(psi)
    telescope=F(0); majorant=F(0)
    for i in range(len(h)):
        outside=math.prod(psi[:i])*math.prod(h[i+1:])
        telescope+=eps*outside*(h[i]-phi[i])
        majorant+=eps*outside*(h[i]+phi[i])
    assert contrast==telescope and abs(contrast)<=majorant
    return contrast,majorant


def stage3():
    rng=random.Random(SEED); algebra_checks=0; witnesses=[]
    for n in range(1,9):
        for eps in (F(0),F(1,2),F(1,8),F(1,64)):
            for _ in range(12):
                h=[F(rng.randrange(2)) for _ in range(n)]
                phi=[F(rng.randrange(17),16) for _ in range(n)]
                d,v=tensor_value(h,phi,eps); algebra_checks+=1
                # Finite fine-layer contrast sum has the same endpoint telescope.
                fine=sum(math.prod((1-eps/F(2**(s+1)))*a+eps/F(2**(s+1))*b for a,b in zip(h,phi))-
                         math.prod((1-eps/F(2**s))*a+eps/F(2**s)*b for a,b in zip(h,phi)) for s in range(5))
                endpoint=math.prod((1-eps/32)*a+eps/32*b for a,b in zip(h,phi))-math.prod((1-eps)*a+eps*b for a,b in zip(h,phi))
                assert fine==endpoint
                if eps>0 and v>0 and all(z['n']!=n for z in witnesses):
                    witnesses.append(dict(n=n,epsilon=eps,h_values=h,phi_surrogate_values=phi,
                                          contrast=d,positive_majorant=v,finite_5_layer_contrast_sum=fine))
    ln2=log2_interval(); dimensions=list(range(1,129))+[256,4096,2**20]; records=[]
    for n in dimensions:
        target=16*n*(1+n)**2; S=0
        while 2**(2*S)<target: S+=1
        assert 2**(2*S)>=target and (S==0 or 2**(2*(S-1))<target)
        eps=F(1,2**S); mass=2*n*eps; coarse_fee=2*n*(1+n)*eps
        assert coarse_fee*coarse_fee<=F(n,4)
        fee=(2*n*(1+n*ln2[0])*eps,2*n*(1+n*ln2[1])*eps)
        assert fee[1]<=coarse_fee
        root=math.isqrt(n)
        records.append(dict(n=n,S=S,epsilon=eps,V_epsilon_mass=mass,
                            threshold_integer_target=target,chosen_square_power=2**(2*S),previous_square_power=None if S==0 else 2**(2*(S-1)),
                            fine_maximal_fee_interval=fee,coarse_fee_rational_upper=coarse_fee,
                            coarse_fee_squared=coarse_fee**2,target_fee_squared=F(n,4),
                            target_fee_if_n_is_square=F(root,2) if root*root==n else None,
                            bound_verified_by_integer_square=True,
                            representation='Implicit n-factor tensor mass and positive-kernel formulas; no tensor grid or 2**n mask enumeration.'))
    return dict(status='EXACT_VERIFIED',scope='Exact positivity/telescope allocation identities and layer-selection fee algebra; parent analytic kernel payment supplies actual-operator applicability.',
                seed=SEED,pointwise_rational_algebra_checks=algebra_checks,
                finite_telescope_layers_per_case=5,saved_rational_witnesses=witnesses,
                rational_witness_scope='h indicator values and rational phi surrogate values test generic positive-factor identities, not numerical E2 phi integration.',
                psi_formula='psi_epsilon=(1-epsilon)h+epsilon*phi',
                positive_majorant_formula='V_epsilon=epsilon*sum_i psi_epsilon^(tensor i-1) tensor (h+phi) tensor h^(tensor n-i)',
                exact_mass_formula='mass(V_epsilon)=2*n*epsilon since mass(h)=mass(phi)=mass(psi)=1',
                ray_monotonicity_reason='h and actual phi are even and nonincreasing in absolute coordinate; positive sums, products, psi and h+phi preserve that property.',
                fine_telescope_limit='sum_{s>=S}(Psi_{2^-(s+1)}-Psi_{2^-s})=H-Psi_{2^-S}',
                finite_window_payment_premise='norm_L1(max_{1<=L<=2} mu*(V_epsilon)_L) <= 2*n*(1+n*log2)*epsilon*W',
                log2_interval=ln2,selection_formula='S=min integer with 2^(2S)>=16*n*(1+n)^2 = ceil(log2(4*sqrt(n)*(1+n)))',
                target_formula='fine maximal fee <= sqrt(n)/2 * W',normalization='W=1; multiply all fees by arbitrary W',
                dimension_records=records,dimension_count=len(records),
                exact_mixture_bound_algebra=dict(mass_of_mixing_law=F(1),integrated_component_bound=1+F(4,3),J_phi_parent_upper=F(7,3),I2_phi_parent_upper=F(10,3)))


def main():
    start=time.monotonic(); first=stage1()
    print('stage1 component_cases',len(first['cases']),'seconds',round(time.monotonic()-start,3),flush=True)
    second=stage2()
    print('stage2 actual_phi_J',second['refinements'][-1]['J'],'I2',second['refinements'][-1]['I2'],'seconds',round(time.monotonic()-start,3),flush=True)
    third=stage3()
    out=dict(status='PASS_WITH_SCOPE_LABELS',dependencies='Python standard library only',seed=SEED,
             stage1=first,stage2=second,stage3=third,
             counts=dict(component_s_cases=len(first['cases']),component_refinements=3*len(first['cases']),
                         actual_phi_refinements=len(second['refinements']),exact_positive_tensor_cases=third['pointwise_rational_algebra_checks'],
                         exact_layer_selection_dimensions=third['dimension_count']),
             limitations=['Stages1/2 are floating quadrature diagnostics, not rigorous integration certificates.',
                          'Generic rational factor values in stage3 do not replace actual phi.',
                          'The finite-window positive-kernel payment and analytic Fisher inequalities are parent-proof premises.',
                          'No full-band coverage or general cube-bound conclusion is inferred from these diagnostics.'])
    target=Path(__file__).with_name('fisher_results.json'); target.write_text(json.dumps(clean(out),indent=2,sort_keys=True)+'\n')
    print('DONE',out['counts'],'seconds',round(time.monotonic()-start,3),'bytes',target.stat().st_size,flush=True)


if __name__=='__main__': main()
