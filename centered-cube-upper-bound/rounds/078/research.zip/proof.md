# 中心立方体第78轮：连续通量支付与带费用的混合覆盖

2026-10-11。**目标 C_n^square≤sqrt(n)n^{o(1)} 尚未证明；全一般保留基准仍为 O(n log n)。** 本轮接续R77留下的低背景动态缺口，研究真实尺度导数及允许支付例外的覆盖，未回到优化特殊输入的上下界。

## 已证进展及其边界

对真实未截断 E2 核，给出自包含的尺度Fisher上界 J_phi≤7/3。中心化连续导数的单坐标方差≤(10/3)a−a²；只在产品核中使用坐标独立，不假设一般输入具有张量结构。故每一软层的连续中心化动态部分可按 O(sqrt(n δ)) 强L1支付，所有层总费 O(sqrt n)W；所有固定尺度锚点总费 O(log n)W。

尺度导数剩余的是硬面流入与负漂移的差。二者总质量抵消，不能分开取总变差后声称根号维数。全部硬面层差相加恰恢复原立方体的补偿尺度导数，因此代数分解本身没有解决主困难。本轮明确保留这一限制。

同时，把既有正核包络与细软尾预算整合：选择 S=ceil(log₂[4sqrt(n)(1+n)])，即可按 O(sqrt n) 支付平滑基准、全部无限细层尾及高背景事件。剩余只有 S 个真实核心层，各层阈值 λ/(4S)，背景阈值4sqrt(n)Sλ，相对背景16sqrt(n)S²。该剩余并集的维数一致预算仍未证明；有限窗口也不能直接当作全尺度结论。

覆盖模块引入按来源预先指定的尺度职责（duty），允许不同来源使用不同的尺度集合，同时逐项支付其正积分费用。残余用新增均匀标签保留在一个共同源上，不能把尺度相关残余冒充固定卷积输入。精确有限尺度费用及优化代表的积分支付形成可审查的混合证书；全一般便宜证书的存在性仍缺。

将连续支付接入有限核心层时，再明确支付阈值为λ/(8S)的总锚点/连续项异常集。最终只剩原层真实选择处的补偿硬面事件，已付费用为O(sqrt(n)log(2+n)+log²(2+n))W。额外的首达分析给出正负两侧不同的漂移恒等式，并对a≤n^(-1/2)的深软层背景强迫项按O(sqrt n)一次支付；有符号面通量和粗层强迫仍未解决。

一个必须记录的失败迁移：将真实噪声硬截断会使支撑端点附近密度线性消失、导数非零，尺度Fisher积分对数发散。不能将新连续估计直接套在该截断核上。合法办法是在未截断真核证明，再使用R77已经支付的最大余项转移到零质量核心。

## 原始测度、验证和技能

本轮所有一般估计使用原始Lebesgue dx、实际输入及真实物理尺度。数值程序使用实际E2核、原来源权重、全物理硬面breakpoints与完整并发跳变，记录负漂移。有限求积和Monte Carlo均为诊断；有理/整数代数检查只认证所述有限或符号条件，不能替代一般性证明。

核验64个canonical技能入口与437处直接引用，相比R77无变化。实际使用的A02正支配、共同源/LP边界、N04可求和预算及L03证据分类均按假设核对。F05的单算子谱界未被扩大为动态sup结论；I/J类补偿术语也不使真实面流自动成为鞅。

覆盖和软层主推导使用Astra medium；数值实现和独审使用6.1 Sol high，父代理整合并独立重放。详细推导、失败候选、验证范围和剩余接口见下列组件。LaTeX源只做静态检查，未编译、未生成PDF。GitHub仅新增轮次说明与精简压缩包，并更新项目总览。


# R78 parent：真实 E2 Fisher 预算与有限核心层归约

2026-10-11。状态：以下为全一般输入的已证接口，不是根号维数弱型主定理。有限物理尺度族 J⊂[1,2]，ν∈L¹(Rⁿ) 可有符号或复值，W=||ν||₁。所有空间积分为 Lebesgue dx；不把来源抽样概率替代体积。R77 的噪声截断余项支付仍保留，但本节先使用实际未截断 E2 核，避免硬截断产生的 Fisher 发散。

## 1. 一维真实核及可独立核对的 Fisher 上界

令 a=1/2，h=1_[−a,a]，ℓ_r(x)=e^(−|x|/r)/(2r)，0<r≤1，f_r=h*ℓ_r。实际 E2 核为

w(x)=∫₀¹e^(−|x|/r)dr，φ=h*w=∫₀¹2r f_r dr。

权重 2r dr 总质量一；f_r、φ 亦为概率密度。对 x≥0，

f_r(x)=1−(e^(−(a−x)/r)+e^(−(a+x)/r))/2，0≤x≤a；
f_r(x)=(1−e^(−1/r))e^(−(x−a)/r)/2，x≥a。

两段在 a 连续且一阶导数一致。内部 f_r≥(1−e^(−1/r))/2≥1/4（e>2），且 |f_r′(x)|≤e^(−(a−|x|)/r)/(2r)。因此

∫_|x|≤a x² f_r′²/f_r dx ≤ ∫_|x|≤a f_r′² dx ≤1/(4r)。

外部直接积分给

∫_|x|>a x² f_r′²/f_r dx=(1−e^(−1/r))(1/(4r)+1+2r)。

令尺度 score g_r=−f_r−xf_r′。分部积分 ∫xf_r′=−1，指数尾使边界项消失，故

J(f_r):=∫g_r²/f_r=−1+∫x²f_r′²/f_r≤1/(2r)+2r。

这不是把位移 Fisher 与尺度 Fisher 混同。混合 Cauchy 给逐点

[∫₀¹2r g_r dr]²/[∫₀¹2r f_r dr] ≤∫₀¹2r g_r²/f_r dr。

由 Tonelli 和上面的可积上界，混合导数可以在弱导数意义取入积分，并得

J(φ)=∫(φ+xφ′)²/φ≤∫₀¹2r(1/(2r)+2r)dr=7/3，
∫x²φ′²/φ=J(φ)+1≤10/3。

另可由 ∫|g_r|≤sqrt(J(f_r))、其对2rdr可积，证明上述混合弱导数为 L¹ 函数，再获得通常的尺度 W¹,¹ 表示。没有依赖未核验的外部 Fisher 不等式：混合步骤正是带权 Cauchy。

## 2. 未截断平滑基准一次强 L¹ 支付

Φ=φ^⊗n。尺度导数 G=−nΦ−x·∇Φ 为 n 个独立零均值 score 之和乘 Φ；各坐标方差≤7/3。因此

||G||₁≤sqrt(7n/3)。

尺度 u=log L 的概率密度 Φ_e^u 满足 ∂_uΦ_e^u=G_e^u；这可先在 W¹,¹ 中证明，再使用卷积与 Fubini。对任意有限 J⊂[1,2]，

max_J |ν*Φ_L| ≤ |ν*Φ_1|+∫₀^log2 |ν*G_e^u|du，

故

||max_J |ν*Φ_L|||₁ ≤ [1+(log2)sqrt(7n/3)]W。 (P78.1)

没有尺度数量损失。该结果只用于一个倍尺度窗口；不是未经证明的全尺度强 L¹ 估计。

## 3. 无限细软层可整体支付，不引入输入深度

ψ_ε=(1−ε)h+εφ，Ψ_ε=ψ_ε^⊗n，H=h^⊗n。代数望远镜给

H−Ψ_ε=εΣ_{i=1}^n ψ_ε^⊗(i−1)⊗(h−φ)⊗h^⊗(n−i)。

令 V_ε 将其中 h−φ 替为 h+φ。V_ε≥|H−Ψ_ε|，质量2nε。由于 h、φ 均偶且在正半轴递减，V_ε 沿每条从原点出发的射线递减。这里 φ 的单调性由上述 f_r 显式式及正混合取得，无需假设一般卷积都具有该性质。

对任意正 ray-decreasing k，质量 v，尺度 1≤L₁<…<L_m≤2，有

max_j k_Lj ≤ k_Lm+Σ_{j<m}[1−(L_j/L_{j+1})ⁿ]k_Lj。

证法：k_Lj≤k_Lj+1+[1−(L_j/Lj+1)ⁿ]k_Lj，逐步取max；这是未归一化 k 沿射线单调所给的点态关系。积分系数≤1+nlog2。进一步 max_j μ*k_Lj≤μ*(max_j k_Lj)，Tonelli 得

||max_J |ν*(H−Ψ_ε)_L|||₁≤2n(1+nlog2)εW。 (P78.2)

选择 S 为最小非负整数使

2^(2S)≥16n(1+n)²，ε=2^−S。

则 2n(1+nlog2)ε≤sqrt(n)/2。S=ceil(log₂[4sqrt(n)(1+n)])=O(log(2+n))，维数1端点亦覆盖。这里可使用整数平方不等式认证，不用数值拟合决定次数。

实际相邻层 D_s=Ψ_{2^(−s−1)}−Ψ_{2^(−s)}，有限代数恒等式为

H=Φ+Σ_{s=0}^{S−1}D_s+(H−Ψ_ε)。 (P78.3)

它直接将所有无限尾层合为一个已支付卷积差。无需假定绝对无限层逐项取sup的可和性。

## 4. 将有限核心层的高背景一次支付，给出准确剩余事件

对每个 s<S，令 K_s=(Ψ_{δ_s/2}+Ψ_{δ_s})/2，δ_s=2^−s；F_s,L=|ν|*K_s,L。K_s 为正概率 ray-decreasing 核。因此

∫max_J F_s,L ≤(1+nlog2)W。

令 A_s=max_J|ν*D_s,L|，用预定的最小索引打破相等值得到可测实际最大选择 L_s(x)。选定层阈值 τ=λ/(4S)，以及共同背景阈值 B=4sqrt(n)Sλ。定义

E_high,s={A_s>τ，F_s,Ls>B}，
E_low,s={A_s>τ，F_s,Ls≤B}。

则

λ|∪_{s<S} E_high,s|≤[(1+nlog2)/(4sqrt(n))]W。 (P78.4)

这是与输入、有限族大小无关的实际事件预算。低背景的相对比值为 B/τ=16sqrt(n)S²；不得删掉 S² 或把它当绝对常数。

从(P78.3)，若 M_Jν:=max_J|ν*H_L|>λ，则至少出现下面一个事件：

(i) max_J|ν*Φ_L|>λ/4；
(ii) max_J|ν*(H−Ψ_ε)_L|>λ/4；
(iii) 某 s<S 有 A_s>λ/(4S)。

若三者均不发生，则总上界为3λ/4，故包含关系保守但正确。于是(P78.1)--(P78.4)给

λ|{M_Jν>λ}| ≤ [4+4(log2)sqrt(7n/3)+2sqrt(n)+(1+nlog2)/(4sqrt(n))]W
                         + λ|∪_{s<S}E_low,s|。 (P78.5)

这是一条已证的全一般有限窗口归约：基准、无限细软尾、高背景三者全部付清。剩下 O(log n) 个实际未截断低背景层，阈值及背景比均显式。若能证明最后的并集具有 sqrt(n)n^o(1)W 预算，才得到同阶有限窗口结论；还需全尺度局部化，不能因此宣布主定理成立。

R78 soft 组件进一步对核心层变化的连续中心化部分按 O(sqrt n) 强 L¹ 支付。它不能自动替代此处最后一个集合的估计；把其硬面项加起来会恢复原立方体的补偿尺度通量，这个代数事实必须保留。

## 5. 数值与证据边界

fisher_probe.py 的三个阶段实际结果另见 fisher_results.json：一维显式 f_r 的边界层积分、真实混合 φ 的细化诊断，以及 V_ε 质量与整数 S 选择的有理/整数检查。所有连续积分近似仅作探索和实现核对；解析普遍界由第1--4节证明，不由有限样本推断。无随机源权重或有限维代理被当作一般输入证明。

技能使用：A02要求逐点支配、误差方向和最后预算均明示；N04要求截断及求和有独立预算；F05的单算子Schur技能不提供动态sup，因此本证明没有引用一个不存在的谱迁移定理。R77通过的支付、容量及舍入仍保留；本归约不要求已证伪的无例外平均代表覆盖。

## 6. 与连续支付合并：最终待估项确实只剩补偿硬面

为避免把两个独立结论仅并排列出，现明确组合方式。使用 soft 组件的准确分解

T_s,L=A_s^anchor+R_s,L+Y_s,L，
P(x)=Σ_{s≥0}(|A_s^anchor|+sup_[1,2]|R_s,L|)，
||P||₁≤C_P(n)W，
C_P(n)=2floor(log₂n)+4+(log2)sqrt(10n/3)(3+2sqrt2)。

这里 A_s^anchor 是尺度1锚点，勿与第4节的最大量 A_s 混淆。在 (P78.5) 的实际原层最大选择 L_s 上，支付事件 {P>λ/(8S)}，其 λ体积≤8S C_P(n)W。在其补集上，任一 E_low,s 的原层值超过 λ/(4S)，故

|Y_s,Ls|≥|T_s,Ls|−|A_s^anchor|−|R_s,Ls|>λ/(8S)。

定义真实剩余硬面事件

E_face,s={max_J|T_s,L|>λ/(4S), F_s,Ls≤4sqrt(n)Sλ, |Y_s,Ls|>λ/(8S)}。

于是 (P78.5) 可以替换为

λ|{M_Jν>λ}|≤[C_paid(n)+8S C_P(n)]W+λ|∪_{s<S}E_face,s|， (P78.6)

其中 C_paid(n) 为(P78.5)方括号，全部已付费用为 O(sqrt(n)log(2+n)+log²(2+n))W，故属于目标允许的 sqrt(n)n^o(1) 范围。这里 sqrt(n)log n 的额外损失来自明确的阈值分配，未隐入常数。

E_face,s 仍使用原层的真实最大选择，不改成另一个更有利的 Y 最大选择。它不是任意子事件，也不是独立坐标模型。证明最后并集的足够弱预算仍是未解决任务。本式才是本轮连续支付真正接入全一般目标的位置；单纯的全层硬面望远镜不提供所需估计。


# Round 78: centered continuous dilation is paid; compensated hard faces remain

**Status.** An exact signed dilation decomposition is proved for the actual E2 product kernels. The centered continuous component of every soft layer has strong maximal L1 cost O(sqrt(n delta)); these costs are summable over all layers. All scale-one anchors also have an explicit O(log n) total strong L1 cost. The remaining process is a signed hard-face flux with its negative drift retained. No sufficient dynamic weak bound for that process is proved. Summing the unestimated face terms merely recovers the hard cube dilation generator, so this decomposition is not a reduction of the underlying difficulty by itself. The desired general sqrt(n)n^o(1) weak bound remains open.

The proof uses the real phi=h*w, not a Gaussian surrogate. R77's zero-mass D_R^0/K_R^0/J_R^0 construction and its already-paid maximal remainder are retained. A literal hard noise cutoff has infinite dilation Fisher information; it must not be substituted in the new finite-Fisher argument. No old file, other agent's file, Git state or compiled TeX artifact is changed.

## 1. Actual one-dimensional kernels and the Fisher estimate

Let h=1_{[-1/2,1/2]}, w(x)=integral_0^1 exp(-|x|/v)dv and phi=h*w. Thus w and phi have mass one, and

    phi'(x)=w(x+1/2)-w(x-1/2).

The density phi is positive and even. Its derivative is continuous, and its exponential tail justifies integral x phi'(x)dx=-1. Its second moment is 13/12: h has variance 1/12 and w has variance one. For 0<a<=1 set psi_a=(1-a)h+a phi and Psi_(n,a)=psi_a^tensor n.

The following sharper Fisher estimate is supplied by the parent and checked independently here:

    J_phi:=integral (phi+x phi')^2/phi <=7/3,
    integral x^2 phi'^2/phi =J_phi+1<=10/3.             (1)

A self-contained verification is short. Write ell_v(x)=exp(-|x|/v)/(2v), f_v=h*ell_v and phi=integral_0^1 2v f_v dv. Inside |x|<=1/2,

    f_v=1-exp(-1/(2v))cosh(x/v)>=1/4,
    |f_v'|<=exp(-(1/2-|x|)/v)/(2v).

Therefore integral_inside x^2 f_v'^2/f_v<=1/(4v). Outside the interval, f_v(x)=(1-exp(-1/v))exp(-(|x|-1/2)/v)/2, and exact integration gives

    integral_outside x^2 f_v'^2/f_v
       =(1-exp(-1/v))[1/(4v)+1+2v]
       <=1/(4v)+1+2v.

Since J(f_v)=-1+integral x^2 f_v'^2/f_v, J(f_v)<=1/(2v)+2v. Pointwise weighted Cauchy for the mixture's dilation numerator gives J_phi<=integral_0^1 2v J(f_v)dv<=7/3. All quantities are nonnegative before Tonelli, and the final bound is integrable at v=0. No independence assumption on the original source is used.

## 2. Centering the ordinary continuous derivative

Define the signed density

    b_a(x)=-a psi_a(x)-a x phi'(x),
    s_a(x)=b_a(x)/psi_a(x),  0<a<=1.                  (2)

Its mass is zero. In particular, the ordinary continuous dilation derivative is NOT b_a alone: subtracting the hard-face compensator leaves exactly this centered term. Its score variance is

    integral s_a^2 psi_a
       =a^2[integral x^2 phi'^2/psi_a-1]
       <=(10/3)a-a^2=:v(a).                           (3)

The identity uses integral psi_a=1 and integral x phi'=-1; the inequality uses psi_a>=a phi and (1). All cross terms are integrable by Cauchy and (1). Put b_0=0 and v(0)=0. No division by psi_0 outside its support is required.

Tensorize only the actual product KERNEL law, not the arbitrary input source:

    B_(n,a)(u)=sum_(j=1)^n b_a(u_j) product_(k!=j)psi_a(u_k).

Under independent coordinates U_j with density psi_a, B/Psi=sum_j s_a(U_j), whose summands have mean zero. Consequently

    integral B_(n,a)=0,
    ||B_(n,a)||_1<=sqrt(n v(a))<=sqrt(10na/3).         (4)

This applies after convolution with any finite signed or complex measure nu of total variation W, because ||nu*B||_1<=W||B||_1. It does not assert independent source coordinates. That distinction is essential for arbitrary inputs.

## 3. The exact hard-face-minus-drift identity

Let beta=(delta_{-1/2}+delta_{1/2})/2, a probability measure on the two faces. Define the signed finite measure

    H_(n,a)=(1-a) sum_j beta_j tensor psi_a^(others)
                           -n(1-a)Psi_(n,a),          (5)

of total mass zero. For a finite measure K, its dilation K_L is the pushforward under u->Lu; for a density this agrees with L^(-n)K(x/L). In the distributional sense in x and log L,

    d/dlog L (Psi_(n,a))_L=(B_(n,a))_L+(H_(n,a))_L.   (6)

Proof in one coordinate: x h'(x)=-(delta_{-1/2}+delta_{1/2})/2=-beta. Hence -psi_a-x psi_a'=(1-a)beta-psi_a-a x phi'=b_a+(1-a)(beta-psi_a). Apply the product rule and dilation to obtain (6). It includes a=0, where B=0 and only the compensated hard faces remain, and a=1, where H=0 and only the smooth density remains.

For a smooth test function, (6) integrates between any two positive scales by ordinary differentiation. Approximation and the finite total variations give the measure identity for all scales. The integral of the positive face measures over a nontrivial scale interval has a Lebesgue density, apart from irrelevant zero sets, so convolution with a finite measure gives a legitimate almost-everywhere function. Alternatively define the integrated compensated process by the exact difference in (8) below, avoiding any pointwise interpretation of a single-scale singular face measure.

For finite atomic sources and almost every receiver, the physical breakpoints are exactly L=2|x_j-y_{i,j}|. At a simple crossing the kernel jump is

    L^(-n)(1-a) product_(k!=j)psi_a((x_k-y_(i,k))/L).

Between crossings, the ordinary derivative is B_(n,a)-n(1-a)Psi_(n,a), dilated and convolved with the original signed source. At simultaneous crossings the exact jump is the difference of the full product's two one-sided traces; one must not add separate jumps using inconsistent values of the remaining hard factors. Generic within-atom ties lie on null receiver hyperplanes. Numerical checks use direct one-sided product differences even at deliberate ties.

The negative drift in (5) is not an optional error. Its mass cancels that of the face arrivals. Taking absolute values before this cancellation can cost order n, whereas the centered continuous density has the sqrt(n a) bound (4). For the contrast with parameters delta/2 and delta, the ordinary continuous derivative has total mass -n delta/2; hence its L1 norm is at least n delta/2. Thus a sqrt(n delta) strong estimate for that uncentered term is already impossible when delta is fixed and n grows. Centering changes the explicitly identified term being paid, not this lower bound.

## 4. Actual soft-layer decomposition and unconditional strong payments

Write delta_s=2^(-s), s>=0, and

    D_s=Psi_(n,delta_s/2)-Psi_(n,delta_s),
    T_(s,L)nu=nu*(D_s)_L,
    Q_s=B_(n,delta_s/2)-B_(n,delta_s),
    Z_s=H_(n,delta_s/2)-H_(n,delta_s).

Set, for 1<=L<=2,

    A_s=nu*D_s,
    R_(s,L)=integral_1^L nu*(Q_s)_r dr/r,
    Y_(s,L)=T_(s,L)nu-A_s-R_(s,L).                    (7)

Then exactly

    T_(s,L)nu=A_s+R_(s,L)+Y_(s,L),
    Y_(s,L)=nu*integral_1^L (Z_s)_r dr/r.              (8)

The latter identity can be interpreted as finite measures or distributions first, with (7) giving its function representative. It preserves the original physical scale. No new winner or receiver measure is introduced.

Let q=1/sqrt(2). Equations (3)--(4), Tonelli and the absolute-continuity bound for the time integral give

    ||sup_(1<=L<=2)|R_(s,L)|||_1
       <=log 2 [sqrt(n v(delta_s/2))+sqrt(n v(delta_s))]W
       <=log 2 sqrt(10n/3)(1+q)delta_s^(1/2)W.         (9)

This is a true strong L1 maximal estimate for the centered continuous component, uniform over arbitrary input and over every finite physical scale family. It does not apply to T_s or Y_s by itself. Summing all s is legitimate because the positive integrals are summable:

    ||sum_(s>=0) sup_L |R_(s,L)|||_1
       <=log 2 sqrt(10n/3)(3+2sqrt 2)W.                (10)

In particular this series is finite almost everywhere. The ordinary uncentered continuous derivative has mass -n(1-a), so substituting it in (9) would be false.

The anchors also have a concrete all-layer payment. Bernoulli coupling of the endpoint masks gives

    ||D_s||_1<=min(2,n delta_s),
    ||sum_(s>=0)|A_s|||_1
       <=[2 floor(log_2 n)+4]W.                       (11)

For n>=1, split s at floor(log_2 n); the remaining geometric tail is at most two. Thus all anchors and centered continuous terms can be removed together by ONE strong L1 exception. For any finite S or S=infinity where the sum is defined, put

    P(x)=sum_(s<=S)[|A_s(x)|+sup_L|R_(s,L)(x)|].

Then lambda|{P>lambda}| is at most the sum of the explicit coefficients in (10)--(11) times W. This payment uses no conditional coverage hypothesis and no sum of weak quasi-norms. It also bounds sup_L sum_s|A_s+R_(s,L)|.

For finite S, outside {P>epsilon lambda}, a crossing of the signed sum of the actual soft layers above lambda implies a crossing of sum_s Y_(s,L) above (1-epsilon)lambda. This is a correct paid-exception implication. It does NOT establish the needed residual weak estimate.

## 5. Why the residual remains the original difficulty

The sharp issue is now the process Y, with hard-face arrivals and their damping drift kept together. A sufficient per-layer target would bound

    ||max_(L in J)|Y_(s,L)nu|||_(1,infinity)<=a_s W,
    (sum_s sqrt(a_s))^2<=sqrt(n)n^o(1),               (12)

or provide a joint stopped weak payment of the same order on the remaining actual low-background events. This is an OPEN target. The already-paid R77 high-background and zero-mass-tail exceptions may be used, with their stated parameters, but neither grants (12).

Only the following coarse strong estimate is immediate:

    ||sup_L|Y_(s,L)|||_1
       <=log 2 min(4n,2n^2 delta_s)W.                 (13)

Indeed ||H_(n,a)||_TV<=2n(1-a), giving 4n for a difference. For the small-delta estimate, expand (5). If a=delta/2,b=delta, product telescoping and ||psi_a-psi_b||_1<=delta show the face part is bounded by n[delta/2+(n-1)delta] and the drift part by n[delta/2+n delta], whose sum is 2n^2 delta. This retains the bad n scale in the core layers and is not the desired bound.

There is an exact telescoping warning. In finite measures,

    sum_(s=0)^S Z_s=H_(n,2^(-S-1))-H_(n,1)
                    =H_(n,2^(-S-1)),
    sum_(s=0)^S Q_s=B_(n,2^(-S-1))-B_(n,1).

As S tends to infinity these converge in total variation and L1 respectively to H_(n,0) and -B_(n,1). Thus globally summing first simply returns the compensated dilation generator of the hard cube; the smooth-base derivative cancels the continuous sum. No reduction in mathematical difficulty follows from this algebra alone. The new useful estimate is the source-general, summable strong payment (9)--(11); a genuinely stopped or weighted weak estimate for the residual is still required.

## 6. Compatibility with the zero-mass core and the cutoff Fisher trap

R77 constructed the nonnormalized noise-cutoff kernels D_(s,R)^0, K_(s,R)^0 and J_(s,R)^0 with zero contrast mass, a common latent Cauchy pair, and a common radius such that

    ||sup_L sum_s |nu*[(D_s)_L-(D_(s,R)^0)_L]|||_1
       <=2 exp(-a)W.                                 (14)

Here the radius is R=3/2+2log[4n(1+n log2)]+2a and the finite-window/family scope is retained. Consequently (8) transfers to the zero-mass core by subtracting the error in (14). Together with (10)--(11), the correction is a paid strong L1 exception for every input. This transfer uses the previously proved maximal error; it does not differentiate that error or presume its variation is small.

One MUST NOT simply replace phi by the literal cutoff phi_R=h*(w 1_{[-R,R]}) in (1)--(4). For every finite R>0, put c=R+1/2. As epsilon decreases to zero,

    phi_R(c-epsilon)=integral_(R-epsilon)^R w(z)dz
                    =w(R)epsilon+o(epsilon),
    phi_R'(c-epsilon)=-w(R-epsilon) ->-w(R).

Since w(R)>0 and c>0, (phi_R+x phi_R')^2/phi_R is asymptotic to c^2 w(R)/epsilon, whose integral diverges. Thus its dilation Fisher information is INFINITE. The same endpoint issue affects the centered score for psi_(a,R) whenever a>0; adding the R77 correction supported in the hard cube cannot change this outer endpoint. This is an analytic statement, not a numerical extrapolation. The correct use of the core in this round is the paid-error transfer (14).

## 7. Verification and exact remaining claim

The companion flux_probe.py and numeric report, owned by the numerical collaborator, test the complete scale identity with actual E2 phi and phi', the original signed atomic sources, all physical hard breakpoints, direct tied jumps and the negative drift. Their numerical results are evidence for implementation, not a proof of the universal estimate. The completed pressure run reports 24 signed pointwise flux rows, including 7 simultaneous-crossing events, with largest fundamental-theorem residual 7.73e-6. Two independent 512-sample batches at each setting check the actual product-mixture integral: at n=64 and delta=1/n, centered contrast estimates are about 0.50 and 0.45, while the ordinary continuous and negative-drift terms are about 22 in absolute integral; at n=64 and delta=1/2 the centered estimates are about 9.16 and 9.32, below the analytic 16.55 bound. The associated Monte Carlo standard errors and exact fixtures are recorded in the companion report. These samples are diagnostics and no order of growth is fitted. This note's independent embedded guard checks three E2 quadrature refinements, the Fisher and centered-variance formulas, and exact rational coefficient identities. It uses no replaced kernel and no source-coordinate independence assumption.

The actual numeric value of the Fisher integral is approximately 0.99017 in these finite-cutoff quadratures, safely below the proved upper bound 7/3. Quadrature errors are not certified intervals; truncating the numerical x integral at 18 has a small nonzero tail. The theorem rests on the analytic proof (1), not these decimals. The guard's three stages refine the actual integration mesh; the companion provides the broader source/dimension/scale pressure stages.

The main unresolved object is the compensated hard-face contrast process on arbitrary-input actual low-background dynamic events, after the paid exceptions. No new Gaussian approximation, entropy coverage assumption, strong energy inequality or martingale structure for arbitrary sources has been asserted. Establishing such a structure, or a direct stopped flux budget, is still necessary to reach the stated cube weak-type target.

Guard SHA-256: `f7bf7cb28bba691d374f9a84fbe4947adab61922188e8e590b86c2d91a6228d4`.

Executed stdout:

```text
E2 refinement=32 mass=1.000010358 moment2=1.083334172 Fisher=0.990168348 max_center_error=8.69e-05 max_var_ratio=0.577718
E2 refinement=64 mass=1.000001314 moment2=1.083333009 Fisher=0.990169015 max_center_error=2.61e-05 max_var_ratio=0.577678
E2 refinement=128 mass=1.000000164 moment2=1.083332816 Fisher=0.990166060 max_center_error=7.07e-06 max_var_ratio=0.577666
PASS assertions=65; E2 quadrature diagnostics do not certify interval errors
```

Replay the following Python fence with Python 3.

```python
from math import exp,sqrt,log
from fractions import Fraction as Q
checks=0
def ck(v):
 global checks
 assert v
 checks+=1
def simpson(fn,a,b,N):
 step=(b-a)/N
 return step*(fn(a)+fn(b)+sum((4 if k%2 else 2)*fn(a+k*step) for k in range(1,N)))/3
# Actual E2 phi and derivative, no synthetic noise profile.
def phip(x,N):
 x=abs(x)
 def f(v):
  if v==0:return 0.
  if x<=.5:return v*(2-exp(-(.5-x)/v)-exp(-(.5+x)/v))
  return v*(exp(-(x-.5)/v)-exp(-(x+.5)/v))
 def d(v):
  if v==0:return 0.
  return exp(-(x+.5)/v)-exp(-abs(x-.5)/v)
 return simpson(f,0,1,N),simpson(d,0,1,N)
def stage(N):
 # Integrate each side of the hard boundary separately using one-sided h.
 # Endpoints carry zero Lebesgue mass; piecewise quadrature retains both traces.
 rows=[]
 for inside,left,right,panels in ((True,0.,.5,N),(False,.5,18.,8*N)):
  step=(right-left)/panels
  for k in range(panels+1):
   x=left+k*step;p,dp=phip(x,N)
   weight=2*step/3*(1 if k in (0,panels) else 4 if k%2 else 2)
   rows.append((x,p,dp,float(inside),weight))
 mass=sum(p*w for x,p,dp,h,w in rows)
 second=sum(x*x*p*w for x,p,dp,h,w in rows)
 jf=sum((p+x*dp)**2/p*w for x,p,dp,h,w in rows)
 ck(abs(mass-1)<.003 and abs(second-Q(13,12))<.003)
 ck(jf<7/3)
 maxmean=0.;maxratio=0.
 for a in (1.,.5,.1,.01):
  mean=0.;variance=0.
  for x,p,dp,h,w in rows:
   psi=(1-a)*h+a*p;b=-a*psi-a*x*dp
   mean+=b*w;variance+=b*b/psi*w
  ck(abs(mean)<.003)
  ck(variance<10*a/3-a*a)
  maxmean=max(maxmean,abs(mean));maxratio=max(maxratio,variance/(10*a/3-a*a))
 print('E2 refinement=%d mass=%.9f moment2=%.9f Fisher=%.9f max_center_error=%.3g max_var_ratio=%.6f'%(N,mass,second,jf,maxmean,maxratio))
 return mass,second,jf
previous=None
for N in (32,64,128):
 current=stage(N)
 if previous:ck(max(abs(x-y) for x,y in zip(current,previous))<.02)
 previous=current
# Exact symbolic identities and all-layer geometric budgets.
for a in (Q(1),Q(1,2),Q(1,16),Q(1,128)):
 # Epsi score mean = -a - a*integral x phi' = 0.
 ck(-a-a*(-1)==0)
 ck(Q(10,3)*a-a*a>=0)
for n in (1,2,16,256,4096):
 m=n.bit_length()-1
 partial=sum(min(2,n*2.**(-s)) for s in range(100))
 ck(partial<=2*m+4+1e-12)
 coeff=sum(sqrt(2.**(-s))*(1+1/sqrt(2)) for s in range(100))
 ck(coeff<=3+2*sqrt(2)+1e-12)
 # Distributional jump coefficient plus regular integral has total mass zero.
 for a in (Q(1),Q(1,2),Q(1,16)):
  ck(n*(1-a)-n*(1-a)==0)
print('PASS assertions=%d; E2 quadrature diagnostics do not certify interval errors'%checks)
```


# R78: actual signed first-excursion flux and a paid fine-layer drift branch

**Status.** The general square-root weak bound remains unproved. This component proves an all-input signed flux identity and pays the adverse background forcing in the regime a<=n^(-1/2). It does not estimate the remaining signed face flux. The compact variation obstruction below is a stress gate, not a weak-type counterexample.

Skills read: updated J04 jump compensation/exit settlement and E01 occupation/flow LP, including their cube-interface files. Their warnings are retained: no compensator, martingale, or occupation-LP equivalence is inferred from notation. Everything below is a deterministic convolution calculation with Lebesgue receiver measure. No external theorem from an unread evidence PDF is used. R77's main proof and objective were consulted; the current argument does not reuse the disproved random representative premise.

## 1. Exact equation, including the two different signs

Initially let f>=0 be smooth with compact support, W=integral f. Put t=log L in [0,T], T=log 2, a in (0,1], b=a/2,

    P_a(t,x)=f*(Psi_a)_(exp t)(x), u=P_b-P_a,
    C_a=(1-b) sum_j beta_j tensor psi_b^(others)
         -(1-a) sum_j beta_j tensor psi_a^(others),
    V_a=B_b-B_a, kappa=n(1-b), gamma=n(a-b)=na/2.

Here beta=(delta_(-1/2)+delta_(1/2))/2, and the tensors have their indicated coordinate locations. All C kernels are finite signed measures; all dilations preserve mass. The stated decomposition of the scale derivative gives exactly

    partial_t u = c+v-kappa u-gamma P_a,                (1)
    c=f*(C_a)_(exp t), v=f*(V_a)_(exp t).

This formula follows because (1-b)Psi_b-(1-a)Psi_a=(1-b)(Psi_b-Psi_a)+(a-b)Psi_a. In particular the last term is nonpositive because f>=0. The main cube target permits this restriction by replacing arbitrary input with its absolute value.

Fix eta>0. Remove the anchor event |u(0,x)|>=eta/2. On each remaining point with sup_[0,T]|u|>eta, let tau be the first hit of |u|=eta, sigma=sign u(tau), and rho the last hit of u=sigma eta/2 before tau. Continuity and the intermediate value theorem give rho<tau and eta/2<sigma u<eta on (rho,tau). Let I_sigma(x,t) indicate this actual corridor and crossing sign. These are Borel functions; no adaptedness is claimed. The last-exit time rho need not be a stopping time, which is harmless for deterministic Fubini but would invalidate an unproved optional-stopping invocation.

Writing z=sigma u and integrating (1) along this one corridor gives

    eta/2 + kappa integral_I z dt
      + gamma integral_I P_a dt = integral_I (c+v) dt   (sigma=+1), (2+)
    eta/2 + kappa integral_I z dt
      = integral_I (-c-v) dt + gamma integral_I P_a dt  (sigma=-1). (2-)

The drift restores toward zero for either sign. The nonnegative background helps positive crossings but can create negative crossings. Replacing it by a mean-zero term is incorrect. Every x is charged for one corridor only. Integrating over x is valid: c has total-variation L1 bound <=2nW at each t, v is integrable, P_a has integral W, and T is finite. Thus all terms are absolutely integrable for fixed a,n. All receiver integrations use dx, never f(x)dx.

These identities extend to every nonnegative L1 input. The distributional scale derivative is the displayed L1 space-time function, with finite integral over [0,T] times R^n; consequently u has an absolutely continuous time representative for almost every receiver. Also psi_a<=1, so smooth L1 approximants converge uniformly in x and t on this physical window (the convolution error is <=2||f-f_m||_1). Thus the continuous representative, its first hits, and its last excursions agree with the ordinary convolution formula. This proves the all-input scope directly rather than assuming a stochastic limiting theorem.

## 2. All-input payment of the fine-layer forcing

Choose a0=2^(-s0)<=n^(-1/2), a_k=a0 2^(-k), r=2^(-1/2), w_k=(1-r)r^k, eta_k=lambda w_k. Thus sum w_k=1. Define

    Q_k(x)=gamma_k integral_0^T P_(a_k)(t,x) dt.

Tonelli gives ||Q_k||_1=(n a_k T/2)W. Consequently

    lambda | union_k {Q_k>eta_k/8} |
       <=4nT sum_k a_k/w_k W
       =4nT a0/(1-r)^2 W <=4T/(1-r)^2 sqrt(n) W.       (3)

Outside this paid event, the negative-corridor forcing in (2-) is <=eta_k/8. Therefore every remaining negative crossing requires

    integral_I (-c-v) dt >=3eta_k/8
                                  +kappa_k integral_I z dt.       (4-)

Every positive crossing satisfies the stronger eta_k/2 version by (2+). This branch covers every nonnegative input; there is no special-input assumption. It is a payment of a positive time-integrated background quantity, not a separately assumed occupation theorem. Constants are independent of source count, scale grid, and depth. The factor T is the actual logarithmic window length.

For comparison, a pointwise absorbing variant is also valid. The E2 kernels are positive mixtures of centered interval densities, hence the product kernels are positive mixtures of centered rectangles. For a normalized rectangle K, its dilation-window envelope has integral 1+nT, by integrating in its max-coordinate radius; Tonelli gives

    ||sup_(0<=t<=T) P_a(t)||_1 <=(1+nT)W.

Remove E_k={sup_t P_(a_k)>eta_k/(4a_k)}. Then

    lambda |union E_k| <=4(1+nT)a0/(1-r)^2 W=O(sqrt(n))W. (5)

Outside E_k, on a negative corridor z>=eta_k/2,

    gamma_k P_(a_k)<=n eta_k/8 <=(kappa_k/2)z.

Thus (2-) gives eta_k/2+(kappa_k/2) integral_I z <=integral_I(-c-v). This is an actual damping statement with a paid exception. Equation (3) is cheaper and requires only mass preservation; (5) additionally records pointwise absorption. These are alternative payments, not cumulative costs.

Anchors can be paid without summing infinitely many constant estimates: ||Psi_b-Psi_a||_1<=min(2,na) by product telescoping and ||psi_b-psi_a||_1<=a. Hence the square-root threshold allocation using these anchor norms gives O(log^2(2+n))W for all layers (and also for the fine subfamily). The threshold budget for anchors, continuous terms, coarse layers, and fine layers must be allocated separately; the w_k above reserve only the fine subfamily's budget.

## 3. What remains, stated as an actual signed hypothesis

The continuous v terms can be charged using the proved Fisher bound and the appropriate independent threshold allocation. A sufficient face interface on the surviving points of Section 2 would bound the volume of actual corridors satisfying

    sigma integral_(rho(x))^(tau(x)) c_a(t,x) dt
       >=c_* eta + (kappa/2) integral_(rho(x))^(tau(x)) |u(t,x)| dt,

after charging the continuous contribution, with total lambda-volume O(sqrt(n) times polylog(n))W under a summable threshold allocation. The corridors must be generated by this same f and u, not selected freely. This precise signed flux estimate is UNPROVED. It has damping, single excursions, true threshold geometry, and no adverse forcing debt in the paid fine regime. Coarse layers a>n^(-1/2) still need a forcing estimate or another branch as well as face control. The damping O(n) is not by itself an O(sqrt(n)) face bound: the source/receiver correlation between new face arrivals and u is the remaining issue.

Duhamel is valid but does not solve that issue:

    u(t)=exp(-kappa t)u(0)
       +integral_0^t exp(-kappa(t-s))[c(s)+v(s)-gamma P_a(s)] ds.

The apparent lifetime 1/kappa cannot be multiplied into the spatial supremum without proving a fresh-arrival versus persistence estimate. Every source may enter different receivers at different physical scales. Summing the unselected face flux simply returns the old linear-dimensional charge.

## 4. Compact stress gate: compensation does not give small variation

Let q=integral_(outside [-1/2,1/2]) phi. For the actual E2 kernel,

    q=2 integral_0^1 r^2(1-exp(-1/r)) dr,
    q0:=2(1-exp(-1))/3 <=q<=2/3.

On the union of the relative interiors of the 2n unit-cube faces, the singular mass of H_(a/2)-H_a equals

    n d_n(a), d_n(a)=(1-a/2)(1-aq/2)^(n-1)
                         -(1-a)(1-aq)^(n-1).

At a=1/n, n>=2, differentiation in a and Bernoulli's inequality give d_n>=q0/24. (Use (n-1)/n>=1/2, 1-a>=1/2, and (1-q/n)^(n-2)>=1/3.) The absolutely continuous drift cannot cancel this singular measure. Thus its total variation is at least q0 n/24.

This also has an explicit L1 realization at physical scales. Let epsilon=q0/(1000n), f_epsilon=(2epsilon)^(-n)1_[-epsilon,epsilon]^n, of mass one. At scale L use the union of strips |x_j-sign L/2|<=epsilon, with every other |x_i|<=L/2-2epsilon. The strips are disjoint up to null sets. Since psi_a<=1, tangential trimming loses at most 6n(n-1)epsilon/L in the signed face mass. Only the positive face measure needs trimming in this lower bound; the negative face measure is bounded above by its full interior-face mass, so the loss is not doubled. The convolved continuous drift has absolute density <=2n L^(-n), so its integral over these strips is at most 8n^2 epsilon/L. Consequently, uniformly for 1<=L<=2,

    || f_epsilon*(H_(a/2)-H_a)_L ||_1
       >=n q0/24-14n^2 epsilon >=q0 n/40.              (6)

This rules out a square-root strong variation payment even for a fixed concrete input and a fixed physical window. It says nothing adverse about its weak crossing volume. The new corridor interface deliberately retains cancellation and damping rather than using (6) as a weak-type obstruction.

## 5. Reproducible three-stage guard

The code below is diagnostic where it uses floating E2 quadrature. Exact rational checks certify only the drift algebra and absorption inequalities. The allocation identities are proved analytically above and checked with floating arithmetic in the guard; no check certifies the conjectural face estimate. It covers initial algebra exploration, actual E2 face/forcing stress, and expanded dimension/depth with quadrature refinement. No fitted exponent is asserted.

```python
from fractions import Fraction as F
from math import exp, expm1, log, log1p, sqrt

def qmid(N):
    return 2*sum((r:=(j+.5)/N)**2*(-expm1(-1/r)) for j in range(N))/N

# Stage 1: exact two-sign algebra, including adversarial forcing ratios.
checks=0
for n in (1,2,7,64):
 for a in (F(1),F(1,2),F(1,16),F(1,1024)):
  b=a/2;kappa=n*(1-b);gamma=n*(a-b)
  for pa,pb in ((F(1),F(3)),(F(3),F(1)),(F(100),F(99)),(F(1),F(1))):
   u=pb-pa
   assert -n*((1-b)*pb-(1-a)*pa)==-kappa*u-gamma*pa
   eta=F(1,10); z=eta/2; allowed=eta/(4*a)
   assert gamma*allowed<=kappa*z/2
   checks+=1
print('stage1 exact drift/sign/absorption cases',checks)
# Stage 2: actual E2 kernel integral and critical-layer singular contrast.
qvals=[qmid(N) for N in (256,1024,4096)]
assert abs(qvals[-1]-qvals[-2])<1e-7
q=qvals[-1];q0=2*(1-exp(-1))/3
assert q0<q<2/3
rows=[]
for n in (2,4,16,64,256,1024,4096):
 a=1/n
 dn=(1-a/2)*exp((n-1)*log1p(-a*q/2))-(1-a)*exp((n-1)*log1p(-a*q))
 eps=q0/(1000*n)
 certified_lower=n*q0/24-14*n*n*eps
 assert dn>=q0/24 and certified_lower>=q0*n/40
 rows.append([n,round(dn,9),round(n*dn,6),round(eps,12)])
print('stage2 E2 quadrature',qvals,'[n,d_n,n*d_n,physical_epsilon]',rows)
# Actual L1 box input: pointwise logscale equation, both signs of u.
from math import prod

def phi_pair(z,R):
 rr=[(j+.5)/R for j in range(R)]
 if abs(z)<=.5:
  p=sum(t*(2-exp(-(z+.5)/t)-exp(-(.5-z)/t)) for t in rr)/R
 else:
  p=sum(t*(exp(-(abs(z)-.5)/t)-exp(-(abs(z)+.5)/t)) for t in rr)/R
 dp=sum(exp(-abs(z+.5)/t)-exp(-abs(z-.5)/t) for t in rr)/R
 return p,dp

def actual_box(n,a,x,L,eps,R,Y=32):
 states=[]
 for aa in (a,a/2):
  ps=[];bs=[];faces=[]
  for xx in x:
   hard=max(0,min(eps,xx+L/2)-max(-eps,xx-L/2))/(2*eps*L)
   soft=zd=0
   for j in range(Y):
    yy=-eps+2*eps*(j+.5)/Y;z=(xx-yy)/L;p,dp=phi_pair(z,R)
    soft+=p/(L*Y);zd+=z*dp/(L*Y)
   pp=(1-aa)*hard+aa*soft;ps.append(pp);bs.append(-aa*pp-aa*zd)
   faces.append(sum(abs(xx-sg*L/2)<eps for sg in (-1,1))/(4*eps))
  P=prod(ps)
  B=sum(bs[i]*prod(ps[:i]+ps[i+1:]) for i in range(n))
  C=(1-aa)*sum(faces[i]*prod(ps[:i]+ps[i+1:]) for i in range(n))
  states.append((P,B,C))
 pa,ba,ca=states[0];pb,bb,cb=states[1];u=pb-pa
 return u,cb-ca+bb-ba-n*(1-a/2)*u-n*a*pa/2

errors=[];signs=set()
for R in (64,256,1024):
 for n,x in ((1,[.65]),(2,[.65,.1]),(2,[.7,.7]),(4,[.65,.1,.1,.1])):
  a=.5;L=1.3;eps=.08;dt=1e-5
  u,rhs=actual_box(n,a,x,L,eps,R);signs.add(u>0)
  d=(actual_box(n,a,x,L*exp(dt),eps,R)[0]-actual_box(n,a,x,L*exp(-dt),eps,R)[0])/(2*dt)
  errors.append(abs(d-rhs));assert abs(d-rhs)<1e-7
assert signs=={True,False}
print('stage2 actual unit-mass L1 boxes: 12 logscale identities; max residual',max(errors))
# Stage 3: expanded fine-layer threshold budget, forcing and depth.
r=2**(-.5)
for n in (1,2,16,256,4096,65536):
 s0=0
 while 2**(-s0)>n**(-.5):s0+=1
 a0=2**(-s0)
 for depth in (4,16,64,256):
  total=sum((a0*2**(-k))/((1-r)*r**k) for k in range(depth))
  closed=a0*(1-r**depth)/(1-r)**2
  assert abs(total-closed)<=1e-12*max(1,closed)
  assert 4*n*log(2)*total<=4*log(2)/(1-r)**2*sqrt(n)*(1+1e-12)
  for k in (0,depth-1):
   a=a0*2**(-k);eta=(1-r)*r**k;pa=eta/(4*a)
   assert n*a*pa/2<=n*(1-a/2)*(eta/2)/2*(1+1e-12)
print('stage3 dimensions=1..65536 depths=4,16,64,256 PASS; no face-crossing bound tested or claimed')
```


# R78 coverage: source-dependent scale duties with an exact payment functional

**Status.** The source-dependent scale payment, measurable common-source residual lift, normalized representative payment, and conditional two-positive-kernel return below are proved for arbitrary input. A dimension-only existence theorem selecting inexpensive duties and giving residual coverage is NOT proved. The main centered-cube weak bound remains open. This is a new rigorous hybrid interface with explicitly paid exceptions, not a claim that low representative yield implies short scale support. Only coverage.md and coverage.tex.txt are written; no Git or compilation.

R77 proof.md was read by its theorem components, including the hard actual-winner obstruction, the full actual E2 low-branch obstruction, zero-mass compensation, and all-layer high-background payment. The retained constraints are original Lebesgue receiver measure, one common source, and the original selected physical scale. Relevant canonical skills A02/B01/E03/N04/L03 were read: we use explicit positive domination, finite linear epigraphs, and sums of actual fees. We do not invoke an unverified tree mass flow, infinite-dimensional strong duality, or free entropy descent.

## 1. Exact scale cost for a common source duty

Let 0<L_1<...<L_m be a finite physical family, v_j=L_j^n, v_0=0. For a duty vector d=(d_1,...,d_m) in [0,1]^m define

    E_n(d)=sum_{j=1}^m (v_j-v_{j-1}) max_{k>=j}(d_k/v_k).       (D1)

This functional is homogeneous, monotone, convex, continuous and piecewise linear. It is the exact integral

    integral_Rn max_k d_k L_k^(-n) 1_{x in L_k K} dx
       = |K| E_n(d)                                           (D2)

for every measurable bounded star body K whose dilates satisfy |rK|=r^n|K| and are nested (boundaries are immaterial here). Proof: on the shell L_j K minus L_{j-1}K, the available indices are exactly k>=j, so the maximum is the constant max_{k>=j}d_k/v_k. Integrate shell by shell. This is especially valid for K=conv(0,b+[-1/2,1/2]^n), which may have 0 on its boundary; nested-volume differences still prove the formula and no interior gauge is needed.

For binary d supported on a nonempty set of scales s_1<...<s_r, it reduces exactly to

    E_n(1_S)=1+sum_{j<r}[1-(s_j/s_{j+1})^n]
            <=min(r,1+n log(s_r/s_1)).                         (D3)

For d=0 it is zero. No charge is made for gaps before the first or after the last active scale. A source can therefore use a different short scale window from every other source without paying for their combined global span. The obvious interval covering bound is only an upper bound for (D1), not its definition.

For finite numerical optimization, (D1) has the exact epigraph

    minimize sum_j (v_j-v_{j-1}) h_j,
    h_j>=d_k/v_k for all k>=j,  h_j>=0.                        (D4)

It uses O(m^2) inequalities, and no integer interval selection. This is a finite polyhedral identity, not an infinite-dimensional LP duality claim.

## 2. General signed joint-source payment

Use a finite positive measure eta on theta=(y,z,ell), with y,z in R^n and an optional discrete or measurable latent label ell. Let zeta(theta) be measurable, complex if needed, with |zeta|<=2. Put

    k_theta,L(x)=L^(-n) 1{y+Lz in x+[-L/2,L/2]^n},
    T_L(x)=integral zeta(theta) k_theta,L(x) deta(theta),
    F_L(x)=integral k_theta,L(x) deta(theta),
    C_L(x)=integral |zeta(theta)|^2 k_theta,L(x) deta(theta).

Thus |T_L|^2<=F_L C_L and C_L<=4F_L. The actual E2 source, its bounded-noise core, and its R77 zero-mass-compensated core all have this form; a signed/complex input phase is included in zeta. The following proof also applies to any fixed measurable selector taking values in the finite family. It does not require a new private selector for each source.

A **common source duty** is a collection d_theta,k in [0,1], jointly measurable in theta and the finite scale index. It may depend on the input, threshold and fixed scale family, but not on the receiver x. Define exact allowed and residual contrasts

    T_D,L=integral zeta d_theta,L k_theta,L deta,
    T_R,L=integral zeta (1-d_theta,L) k_theta,L deta,
    T_L=T_D,L+T_R,L.                                          (D5)

Let

    P(z)=1+(1/n)sum_i (|z_i|-1/2)_+,
    Dcost(d)=integral |zeta(theta)| P(z) E_n(d_theta) deta(theta).

Then the following strong integral payment is unconditional:

    integral sup_{L in family}|T_D,L(x)| dx <=Dcost(d).        (D6)

Proof: K_z=z+[-1/2,1/2]^n is contained in K_z^*=conv(0,K_z), a bounded star body of volume P(z), by the R76 visible-face pyramid formula. Triangle inequality and supremum subadditivity bound the left side by the eta-integral of |zeta| times the integral of max_L d_theta,L L^-n 1{x-y in L K_z^*}. Apply (D2), then Tonelli. Thus no receiver measure is changed and no weak quasi-norm is averaged. For a singleton physical source with z=0 and fixed scalar phase the bound is an equality. For general shifted cubes it can be strict because the star hull enlarges the gate.

For duties depending only on y and with full noise integration, an alternative is to use the actual positive signed-coefficient envelope V_delta and its ray monotonicity, obtaining cost v_delta integral E_n(d_y) d|nu|(y), without the P(z) enlargement. This follows from the finite-scale envelope with the same duty formula: if k is ray decreasing, a stepwise layer-cake in radial superlevel sets, or the recurrence k_Lnext >=(L/Lnext)^n k_L, bounds the weighted maximum integral by mass(k) E_n(d). One can also prove this directly: put H_j=max_{k>=j}d_k/v_k, H_{m+1}=0; max_k d_k k_Lk <=sum_j v_j(H_j-H_{j+1})k_Lj, whose coefficient sum is E_n(d). This uses H_j-H_{j+1}>=0 and k_Lj>= (L_k/L_j)^n k_Lk for j>=k. It applies to the R77 compensated positive envelope as well, whose total mass is <=v_delta. This sharper option has no noise-price overhead.

## 3. The residual remains a fixed common source

Scale-dependent removal does NOT leave a fixed convolution input. It must not simply be renamed nu_R and inserted into a theorem for fixed nu. Instead enlarge the original source once to eta'=eta times Lebesgue measure on u in [0,1]. At scale L use the residual capture gate

    A_R,x={ (theta,u): y+L(x)z in Q(x,L(x)), u>d_theta,L(x) }.

This is a fixed nonatomic common source and one measurable receiver-dependent capture set, not a private source for each receiver. The original latent coefficient is still zeta(theta). Then

    F_R=L^(-n) eta'(A_R,x),
    C_R=L^(-n) integral_{A_R,x}|zeta|^2 deta',
    T_R=L^(-n) integral_{A_R,x} zeta deta',
    |T_R|^2<=F_R C_R, 0<=C_R<=4F_R, F_R<=F.                 (D7)

Every packet is fixed in the enlarged source; its membership cannot depend on x or L. The K and J positive source measures are respectively eta' and |zeta|^2 eta'. Their total masses remain m_K=eta(Theta) and m_J=integral |zeta|^2 deta. The source is not charged anew at every scale. Its captured portion changes with L through the displayed gate, exactly as specified. Additional splitting in u does not bypass capacity constraints.

## 4. Paid normalized representative LP on the residual

For either positive residual source xi, write G=xi(A_R,x)/L^n, and for a fixed packet P let w=xi(P), a_P=xi(P intersect A_R,x), pi_P=a_P/xi(A_R,x). Choose one common affine representative c(L)=a+Lb, with physical gate g_c=1{c(L(x)) in Q(x,L(x))}. We deliberately permit the representative's physical gate even when its own duty would exclude it; this only makes the covering functional stronger, while the following payment remains valid. Define normalized column

    b(P,c;E)=integral_E G g_c pi_P^(1+t) dx /P(b).            (D8)

Use finite common source-capacity families sum alpha_P 1_P<=1 xi-a.e., allowing multiple representative choices for the same packet, with their coefficients all counted in the load. Let Bhat_t^R(E;xi) be the supremum of total normalized score. On an actual amplitude band a<G<=beta a,

    Bhat_t^R(E;xi) <=(1+log beta+1/t) xi(Theta').             (D9)

Proof, included to expose the dependence on residual capture: a_P<=w and hence G pi_P^(1+t)<=min(G,w/L^n,(w/L^n)^(1+t)G^(-t)). On the physical affine gate, x-a belongs to L K_b^*. Integrate the radial majorant with volume variable v using the nested star hulls. The three ranges v<=w/(beta a), w/(beta a)<v<=w/a, and v>w/a contribute at most w, w log beta, and w/t, times P(b). Divide by P(b), then integrate the source capacity. The proof uses neither fixed convolution structure nor complete-winner geometry of residual captures. Zero packets contribute zero. Supremum is used; representative attainment is not required.

This is an optimized physical-representative score. It is not silently equated with the weaker averaged random representative score refuted in R77. The additional u coordinate is just part of the common source in its capacity constraints.

## 5. A precise hybrid implication with no extra background factor

Fix the ORIGINAL selector L(x) for a genuine contrast crossing event

    E={x: |T_L(x)|>lambda, F_L(x)<=H lambda}, H>=1.

Duties are fixed as above. Define the directly paid exception and residual event

    E_D={x in E: |T_D,L(x)(x)|>lambda/2},  E_R=E minus E_D.

Markov and (D6) give lambda|E_D|<=2Dcost(d). On E_R, |T_R|>lambda/2. By (D7),

    lambda/4<F_R<=H lambda,
    lambda/(4H)<C_R<=4H lambda.                           (D10)

These are actual residual positive bands, so beta_K=4H and beta_J=16H^2 work. Put Q_K=1+log(4H)+1/t and Q_J=1+log(16H^2)+1/t. If, for some positive kappa_K,kappa_J, the two genuine residual coverage inequalities hold,

    Bhat_t^R(E_R;eta') >=kappa_K integral_E_R F_R,
    Bhat_t^R(E_R;|zeta|^2 eta') >=kappa_J integral_E_R C_R, (D11)

then the complete low-event estimate is

    lambda|E| <=2Dcost(d)
        +2 sqrt[Q_K Q_J m_K m_J/(kappa_K kappa_J)].       (D12)

Proof: (lambda/2)|E_R|<integral_E_R |T_R|<=integral sqrt(F_R C_R)<=sqrt[(integral F_R)(integral C_R)]. Apply the two paid LP bounds and add E_D. One may first intersect E_R with bounded sets to avoid assuming finite volume, and pass by monotone convergence; (D11) is only needed on the stated event and finite occupation is already ensured by (D9) and positive kappas. If m_J=0 the crossing event is empty. This route avoids the unnecessary multiplicative H loss that comes from using only the J occupation lower bound.

For R77 compensated kernels m_K<=W and m_J<=I+2d times W; if n exp(-R)<=1, then 2d<=delta and I>=delta/3 give m_J<=(I+delta)W<=4IW. Therefore (D12) becomes at most

    2Dcost(d)+4 sqrt(I Q_K Q_J/(kappa_K kappa_J)) W.      (D13)

All threshold/layer-dependent H values remain inside the logarithms, not a silently fixed constant. The already-paid R77 high-background and tail branches can be added separately. Summation across layers still requires an explicit summable bound on duties and inverse coverage; this note supplies no free tree telescoping or whole-scale localization.

## 6. Candidate existence statement and exact remaining gap

The most promising general statement from this module is now explicit: for each actual low-background E2 event after R77's correction, find common measurable duties with Dcost<=A_n,delta W AND both inequalities (D11), where the right side of (D13), after the chosen layer thresholds, has a summable total O(sqrt(n)n^o(1))W. The duties may vary with the real source point, including its noise/mask coordinate; they may not vary with the receiver. The residual selector remains the original selector. Optimized normalized representatives and the real residual K/J sources are the ones in (D11).

This is a conditional target, NOT a proved existence theorem. In particular we have not shown that low representative yield bounds E_n(d), that every expensive duty instance leaves a covered residual, or that a finite sampled LP certifies a continuum event. The additional flexibility does not by itself imply those facts.

A finite atomic/receiver version can be made concrete. Introduce d_ik in [0,1] and h_ij>=d_ik/v_k for k>=j. The objective sum_i p_i|zeta_i|P(z_i) sum_j (v_j-v_{j-1})h_ij is linear. If a set of receiver rows is assigned to the paid branch, fix the actual phase s_r=T_r/|T_r|; imposing

    sum_i p_i Re(conj(s_r) zeta_i) k_i,Lr(x_r) d_i,Lr >=theta |T_r|

is a linear sufficient condition for |T_D,Lr|>=theta|T_r|. No phase optimization is hidden. Finite primal witnesses certify only those rows unless a separate covering/regularity argument controls the continuum. The complementary residual representative problem must retain the same duties and original selected scales; independent private optima are not a common witness.

## 6a. A directly paid hybrid covering LP, with a weak dual

There is also a certificate that does not assume (D11). It is useful for jointly choosing duties and paid coverage rather than first guessing kappas. Freeze the ORIGINAL event E, selector L(x), the original F/C source measures, and a finite bank of original packet/representative columns V_l(x)=G(x)g_l(x)pi_l(x)^(1+t)/P(b_l). Suppose E lies in a valid amplitude band for each used G, and put K_l=(1+log beta_G+1/t)w_l. Each column has integral_E V_l<=K_l by the same radial proof as (D9). These columns use original captures, not residual captures depending on the unknown duty.

Define U_D,L(x)=integral |zeta| d_theta,L k_theta,L(x)deta. Its maximal L1 norm is bounded by Dcost exactly as in (D6). Any common duties and nonnegative column multipliers satisfying

    U_D,L(x)(x)+sum_l alpha_l V_l(x)>=tau  a.e. on E            (D14)

give the unconditional certificate

    tau |E|<=Dcost(d)+sum_l alpha_l K_l.                       (D15)

This permits duties and representative coverage to be optimized in one program. There is NO uncharged source-capacity assumption: repeated representative use is charged through sum_l alpha_l w_l. If desired one can expose source loads explicitly as z(theta)=sum_l alpha_l 1_{P_l}(theta); the cost is the corresponding weighted source integral, with the appropriate K or J amplitude-band constant. Declaring z<=1 without checking it would be invalid. The all-duty choice d=1 is feasible whenever the actual contrast satisfies |T|>tau, so the primal has a valid fallback, but its O(n) cost is not the desired theorem.

For an atomic joint source, let i index atoms of masses p_i, and k(r) be the original selected scale in receiver row r. Put A_ri=p_i|zeta_i| k_i,Lk(r)(x_r)>=0 and c_i=p_i|zeta_i|P(z_i). The primal is the finite LP

    minimize sum_ij c_i Delta(v_j) h_ij + sum_l K_l alpha_l,
    sum_i A_ri d_i,k(r)+sum_l V_rl alpha_l>=tau       (all rows r),
    h_ij>=d_ik/v_k (j<=k), h_ij>=0, 0<=d_ik<=1, alpha_l>=0.   (D16)

A weak dual, with all y_r,beta_ijk,gamma_ik>=0, is

    maximize tau sum_r y_r -sum_ik gamma_ik,
    sum_r y_r V_rl<=K_l,
    sum_{k>=j}beta_ijk<=c_i Delta(v_j),
    sum_{r:k(r)=k} y_r A_ri<=sum_{j<=k}beta_ijk/v_k+gamma_ik.  (D17)

It follows by multiplying the primal inequalities and cancelling each variable coefficient. These signs and the upper-bound penalty gamma are essential; omitting d<=1 would produce a different problem. Finite primal and dual witnesses can be checked with rational arithmetic when input powers and payment upper bounds are rational. No continuum strong duality is claimed.

An exact continuum implementation exists for EVERY finite atomic joint source and finite physical family, not just a chosen sample of receiver points. Split a containing rectangle along ALL coordinate faces y_i+L_k z_i +/-L_k/2 of all source cubes, and along all representative-cube faces at every physical scale in the bank. On each open cell, every source and representative gate at every scale is constant. Thus the actual max-absolute-contrast selector with smallest-scale tie break, the event, the F/C amplitudes and every V_l are constant. Include every nonempty event cell in (D16), optionally aggregating identical rows and adding their EXACT Lebesgue volumes. Outside the containing rectangle all original contrasts vanish. Cell boundaries are null. A primal witness therefore certifies the entire actual event through (D15), not a quadrature approximation. The dual (D17) bounds the best cost of this chosen finite-bank certificate, not the weak constant itself.

The executed mixed LP examples below all choose zero representative coefficients at optimum. They verify that the direct mixed program, its weak dual and its continuum cell semantics work; they do NOT provide evidence that representative columns improve the duty-only optimum. Every nonzero representative column has its explicit positive analytic cost, and no coverage benefit is free.

The actual E2 joint noise is continuous. Its infinite-dimensional measurable certificate (D14)--(D15) is fully valid, but the finite rectangular-cell implementation is NOT automatically an exact E2 discretization. Using it there requires rigorous kernel/selection error and an independently paid uncovered region. This round does not supply that transfer. The executable guard applies the exact finite model to genuine whole hard-convolution crossing events, including signed input, and verifies both primal and dual, not a toy receiver-measure replacement.

For an atomic unshifted positive hard source, an instructive explicit feasible duty is d_i(L)=min(1,tau L^n/p_i). At a crossing sum_i p_i L^-n 1_capture>tau, the allowed sum is sum_i min(p_i L^-n,tau)1_capture>=tau. In the one-atom case with tau L_m^n<=p, all d_i/L_i^n=tau/p, so Dcost=tau L_m^n exactly. This is amplitude clipping, not merely choosing a binary interval. For multiple atoms the cost may retain entropy or dimension dependence. For nonatomic packets, captured mass can be strictly between zero and total mass, so clipping whole packet mass does NOT have this pointwise proof. We make no such extension.

## 7. Pressure tests of the interface, not substitute input theorems

* R77 hard revealed U: all true winner lengths lie in [2(1+2epsilon),2(1+3epsilon)]. Set every duty to one on this interval and zero outside it. Its hard-source price is <=1+n log[(1+3epsilon)/(1+2epsilon)]<1.01 per unit source mass. Thus this hybrid accepts that exponential-coverage-loss event as an inexpensive exception, without demanding that a representative cover it.
* R77 actual soft full low branch at one physical scale: d=1 there has one-scale price. Direct V_delta integration gives <=v_delta W<=2W, including the zero-mass compensated case. The sharp-Young counterexample therefore does not contradict the hybrid target.
* Widely separated source components with different winner scales can each receive their own narrow interval. The new fee is the SOURCE-MASS-WEIGHTED average of these costs, not the size of their union or their number. Global interval covering can overcharge such separated scale populations. This is a benefit of (D6), not evidence of a general separation theorem.
* A warning against dropping amplitude control: for a single hard source at zero, the actual winner is L=2||x||infinity. On 1<=L<=2 its occupation is n log2, although the level lambda=2^(-n) has weak fee <=1. Any duty required to retain a fraction theta of its source contribution at EVERY such receiver must satisfy d(L)>=theta and therefore has continuum cost at least theta(1+n log2). On a fixed amplitude band of ratio beta, however, its winner lengths have logarithmic span at most log(beta)/n and the same direct price is <=1+log beta. The general hybrid must preserve the genuine bands or independently pay high backgrounds. A bound on strong source traffic cannot replace the weak target.

The guard below uses actual all-scale complete-batch hard winners and exact finite affine-cube integrals. Its finite signed joint-source examples test the algebraic general theorem; they are not a substitute noise law for the E2 analytic application. No empirical evidence is used to assert (D11) or the existence statement.

## 8. Embedded reproducible guard

```python
from fractions import Fraction as Q
from itertools import product, combinations
import random
rng=random.Random(78021)
checks=0

def ck(x):
 global checks
 assert x
 checks+=1

def scaleprice(n,L,d):
 v=[Q(0)]+[x**n for x in L]
 return sum((v[j+1]-v[j])*max(d[k]/v[k+1] for k in range(j,len(L))) for j in range(len(L)))

def cube_gate(x,y,L,z=None):
 if z is None:z=[Q(0)]*len(x)
 return all(abs(x[j]-y[j]-L*z[j])<=L/2 for j in range(len(x)))

def exact_shift_envelope(n,L,d,z):
 faces=[sorted(set(L[k]*(z[j]+s) for k in range(len(L)) for s in (Q(-1,2),Q(1,2)))) for j in range(n)]
 ans=Q(0)
 for indices in product(*(range(len(a)-1) for a in faces)):
  x=[(faces[j][a]+faces[j][a+1])/2 for j,a in enumerate(indices)]
  vol=Q(1)
  for j,a in enumerate(indices):vol*=faces[j][a+1]-faces[j][a]
  ans+=vol*max([Q(0)]+[d[k]/L[k]**n for k in range(len(L)) if cube_gate(x,[Q(0)]*n,L[k],z)])
 return ans

# Stage 1: exact whole-space weighted cube-envelope integration.
for n in (1,2,3):
 for m in (2,3,5):
  L=[Q(1)+Q(j,m) for j in range(m)]
  for rep in range(3):
   d=[Q(rng.randrange(5),4) for _ in L]
   z=[Q(rng.randrange(-4,5),2) for _ in range(n)]
   P=1+sum(max(Q(0),abs(a)-Q(1,2)) for a in z)/n
   integral=exact_shift_envelope(n,L,d,z)
   ck(integral<=P*scaleprice(n,L,d))
   ck(exact_shift_envelope(n,L,d,[Q(0)]*n)==scaleprice(n,L,d))
   binary=[Q(int(j%2==0)) for j in range(m)]
   selected=[L[j] for j in range(m) if binary[j]]
   ck(scaleprice(n,L,binary)==1+sum(1-(a/b)**n for a,b in zip(selected,selected[1:])))
print('stage1 exact_affine_envelopes=27; zero_shift_equalities=27; binary_prices=27')

# Exact rational two-phase simplex: max c*x subject to A*x<=b, x>=0.
# Every returned primal and dual is independently checked below.
def lpmax(A,b,c):
 m=len(b);n=len(c)
 D=[[Q(0) for _ in range(n+2)] for _ in range(m+2)]
 B=[n+i for i in range(m)];N=list(range(n))+[-1]
 for i in range(m):
  for j in range(n):D[i][j]=A[i][j]
  D[i][n]=-1;D[i][n+1]=b[i]
 for j in range(n):D[m][j]=-c[j]
 D[m+1][n]=1
 def pivot(r,s):
  inv=Q(1)/D[r][s]
  for i in range(m+2):
   if i==r:continue
   for j in range(n+2):
    if j!=s:D[i][j]-=D[r][j]*D[i][s]*inv
  for j in range(n+2):
   if j!=s:D[r][j]*=inv
  for i in range(m+2):
   if i!=r:D[i][s]*=-inv
  D[r][s]=inv;B[r],N[s]=N[s],B[r]
 def simplex(phase):
  obj=m+1 if phase==1 else m
  for steps in range(20000):
   choices=[j for j in range(n+1) if not(phase==2 and N[j]==-1)]
   s=min(choices,key=lambda j:(D[obj][j],N[j]))
   if D[obj][s]>=0:return True
   rows=[i for i in range(m) if D[i][s]>0]
   if not rows:return False
   r=min(rows,key=lambda i:(D[i][n+1]/D[i][s],B[i]))
   pivot(r,s)
  raise RuntimeError('pivot limit')
 r=min(range(m),key=lambda i:D[i][n+1])
 if D[r][n+1]<0:
  pivot(r,n)
  ck(simplex(1) and D[m+1][n+1]==0)
  for i in range(m):
   if B[i]==-1:
    choices=[j for j in range(n+1) if D[i][j]!=0]
    if choices:pivot(i,min(choices,key=lambda j:(D[i][j],N[j])))
 ck(simplex(2))
 x=[Q(0)]*n
 for i in range(m):
  if 0<=B[i]<n:x[B[i]]=D[i][n+1]
 y=[Q(0)]*m
 for j in range(n+1):
  if n<=N[j]<n+m:y[N[j]-n]=D[m][j]
 ck(all(v>=0 for v in x) and all(v>=0 for v in y))
 ck(all(sum(a*z for a,z in zip(row,x))<=bb for row,bb in zip(A,b)))
 ck(all(sum(A[i][j]*y[i] for i in range(m))>=c[j] for j in range(n)))
 ck(sum(c[j]*x[j] for j in range(n))==sum(b[i]*y[i] for i in range(m)))
 return x,-sum(c[j]*x[j] for j in range(n)),y

# Build every continuum arrangement cell, then compress identical event rows.
def full_event(n,sites,p,zeta,L,tau,H,reps):
 faces=[]
 for j in range(n):
  faces.append(sorted(set(y[j]+sign*l/2 for y in sites+reps for l in L for sign in (-1,1))))
 rows={};cellcount=0
 for inds in product(*(range(len(a)-1) for a in faces)):
  x=tuple((faces[j][a]+faces[j][a+1])/2 for j,a in enumerate(inds))
  vol=Q(1)
  for j,a in enumerate(inds):vol*=faces[j][a+1]-faces[j][a]
  profiles=[]
  for k,l in enumerate(L):
   gates=tuple(cube_gate(x,y,l) for y in sites)
   F=sum(p[i]*gates[i] for i in range(len(p)))/l**n
   T=sum(p[i]*zeta[i]*gates[i] for i in range(len(p)))/l**n
   C=sum(p[i]*zeta[i]**2*gates[i] for i in range(len(p)))/l**n
   profiles.append((T,F,C,gates))
  k=max(range(len(L)),key=lambda k:(abs(profiles[k][0]),-k))
  T,F,C,gates=profiles[k]
  if abs(T)<=tau or F>H*tau:continue
  repgates=tuple(cube_gate(x,a,L[k]) for a in reps)
  key=(k,T,F,C,gates,repgates)
  rows[key]=rows.get(key,Q(0))+vol;cellcount+=1
 return list(rows.items()),cellcount

def log2ceil(x):
 k=0;power=Q(1)
 while power<x:power*=2;k+=1
 return k # log x <= ceil(log_2 x), because log 2 <1

def mixed_model(n,sites,p,zeta,L,tau,H,reps):
 rows,cells=full_event(n,sites,p,zeta,L,tau,H,reps)
 ck(bool(rows));N=len(p);m=len(L);v=[l**n for l in L]
 cols=[]
 for kind in (0,1):
  weights=p if kind==0 else [p[i]*zeta[i]**2 for i in range(N)]
  vals=[key[2+kind] for key,vol in rows]
  # G>a with a=min(G)/2; beta=2max/min. t=1, exactly rational powers.
  fee=Q(2+log2ceil(2*max(vals)/min(vals)))
  for mask in range(1,2**N):
   w=sum(weights[i] for i in range(N) if mask>>i&1)
   if not w:continue
   for rep in range(len(reps)):
    column=[]
    for key,vol in rows:
     k,T,F,C,gates,repgates=key;G=F if kind==0 else C
     cap=sum(weights[i]*gates[i] for i in range(N) if mask>>i&1)
     pi=cap/(G*v[k]);column.append(G*pi*pi*repgates[rep])
    if any(column):cols.append((tuple(column),fee*w))
 # Remove duplicate columns, retaining the smallest valid analytic cost.
 unique={}
 for col,cost in cols:unique[col]=min(cost,unique.get(col,cost))
 cols=list(unique.items())
 num=2*N*m+len(cols);cost=[Q(0)]*num
 for i in range(N):
  for j in range(m):cost[N*m+i*m+j]=p[i]*abs(zeta[i])*(v[j]-(v[j-1] if j else 0))
 for ell,(col,c) in enumerate(cols):cost[2*N*m+ell]=c
 A=[];b=[]
 def add(entries,rhs):
  row=[Q(0)]*num
  for j,a in entries:row[j]+=a
  A.append(row);b.append(rhs)
 for r,(key,vol) in enumerate(rows):
  k,T,F,C,gates,repgates=key
  entries=[(i*m+k,-p[i]*abs(zeta[i])*gates[i]/v[k]) for i in range(N)]
  entries +=[(2*N*m+ell,-col[r]) for ell,(col,c) in enumerate(cols)]
  add(entries,-tau)
 for i in range(N):
  for k in range(m):
   add([(i*m+k,Q(1))],Q(1))
   for j in range(k+1):add([(i*m+k,1/v[k]),(N*m+i*m+j,Q(-1))],Q(0))
 x,opt,y=lpmax(A,b,[-a for a in cost])
 weak=tau*sum(vol for key,vol in rows)
 ck(weak<=opt)
 duty=sum(cost[j]*x[j] for j in range(2*N*m))
 cover=sum(cost[j]*x[j] for j in range(2*N*m,num))
 # All-cell primal certificate; source copies have no receiver-dependent membership.
 for r,(key,vol) in enumerate(rows):
  k,T,F,C,gates,repgates=key
  paid=sum(p[i]*abs(zeta[i])*gates[i]*x[i*m+k]/v[k] for i in range(N))
  represented=sum(col[r]*x[2*N*m+ell] for ell,(col,c) in enumerate(cols))
  ck(paid+represented>=tau)
  # Exact common-u lift: combine duty breakpoints once, then integrate its cells.
  cuts=sorted(set([Q(0),Q(1)]+[x[i*m+j] for i in range(N) for j in range(m)]))
  FR=CR=TR=Q(0)
  for a,bb in zip(cuts,cuts[1:]):
   u=(a+bb)/2
   for i in range(N):
    if gates[i] and u>x[i*m+k]:
     mass=p[i]*(bb-a)/v[k];FR+=mass;CR+=mass*zeta[i]**2;TR+=mass*zeta[i]
  ck(FR==sum(p[i]*(1-x[i*m+k])*gates[i]/v[k] for i in range(N)))
  ck(TR*TR<=FR*CR and CR<=4*FR and FR<=F)
 print('whole_event n=%d sources=%d scales=%d cells=%d rows=%d cols=%d weak=%s optimum=%s duty=%s repr=%s'%(n,N,m,cells,len(rows),len(cols),weak,opt,duty,cover))
 return opt

# Stage 2: actual complete finite-scale contrast events, all Lebesgue cells.
mixed_model(1,[(Q(-1),),(Q(0),),(Q(1),)],[Q(1,3)]*3,[Q(1),Q(-1),Q(2)],[Q(1),Q(3,2),Q(2)],Q(1,10),Q(8),[(Q(-1),),(Q(0),),(Q(1),)])
mixed_model(2,[(Q(-1),Q(0)),(Q(1),Q(0))],[Q(1,2)]*2,[Q(1),Q(-1)],[Q(1),Q(3,2),Q(2)],Q(1,10),Q(8),[(Q(-1),Q(0)),(Q(0),Q(0)),(Q(1),Q(0))])
mixed_model(3,[(Q(-1),Q(0),Q(0)),(Q(1),Q(0),Q(0))],[Q(1,2)]*2,[Q(1),Q(-1)],[Q(1),Q(3,2),Q(2)],Q(1,25),Q(16),[(Q(-1),Q(0),Q(0)),(Q(0),Q(0),Q(0)),(Q(1),Q(0),Q(0))])

# Stage 3: true all-scale hard winners, plus source-size and dimension growth.
winners=0
for n,N in ((1,3),(2,5),(4,8),(8,12)):
 sites=[tuple(Q(rng.randrange(-5,6)) for _ in range(n)) for i in range(N)]
 masses=[Q(i+1,N*(N+1)//2) for i in range(N)]
 for trial in range(8):
  x=tuple(Q(rng.randrange(-20,21),3) for _ in range(n))
  if x in sites:continue
  batches={}
  for y,p in zip(sites,masses):
   r=max(abs(a-b) for a,b in zip(x,y));batches[r]=batches.get(r,Q(0))+p
  total=Q(0);best=None
  for r,p in sorted(batches.items()):
   total+=p;ratio=total/(2*r)**n
   if best is None or ratio>best[0]:best=(ratio,2*r)
  G,Lwin=best
  # Atomwise clipping is a rigorous finite-source duty witness at this winner.
  tau=G/2
  allowed=sum(min(p/Lwin**n,tau) for p,y in zip(masses,sites) if cube_gate(x,y,Lwin))
  ck(allowed>=tau);winners+=1
for n in (1,4,16,64,256):
 L=[Q(1),Q(5,4),Q(3,2),Q(7,4),Q(2)]
 tau=Q(1,2**(n+1));d=[tau*l**n for l in L]
 ck(scaleprice(n,L,d)==tau*L[-1]**n==Q(1,2))
 # R77 revealed winner window, rational log upper bound log(1+u)<=u.
 e=Q(1,100*n)
 ck(n*((1+3*e)/(1+2*e)-1)<Q(1,100))
print('stage3 actual_allscale_winners=%d; clipping_growth_dimensions=1,4,16,64,256'%winners)
print('PASS exact_assertions=%d; rational primal/dual checked; no E2 discretization claim'%checks)
```

Executed guard output:

```text
stage1 exact_affine_envelopes=27; zero_shift_equalities=27; binary_prices=27
whole_event n=1 sources=3 scales=3 cells=14 rows=7 cols=4 weak=2/5 optimum=1/2 duty=1/2 repr=0
whole_event n=2 sources=2 scales=3 cells=70 rows=10 cols=5 weak=4/5 optimum=4/5 duty=4/5 repr=0
whole_event n=3 sources=2 scales=3 cells=350 rows=10 cols=5 weak=16/25 optimum=16/25 duty=16/25 repr=0
stage3 actual_allscale_winners=32; clipping_growth_dimensions=1,4,16,64,256
PASS exact_assertions=228; rational primal/dual checked; no E2 discretization claim
```

Initial guard run failed its exact dual check because the simplex artificial pivot used Python integer division and introduced floats. Changing the pivot reciprocal to Fraction(1)/pivot restored rational arithmetic; the successful run above independently checks primal feasibility, dual feasibility, and exact objective equality. The failed run is not counted as a pass.


# Round 78: actual E2 scale flux diagnostics

The computation supports the centered-score / hard-face / negative-drift decomposition on the actual untruncated E2 kernel. It does not prove the original maximal-operator goal or an estimate for the remaining compensated face process. The numerical integrals below are floating quadrature or Monte Carlo diagnostics, with exact rational source and breakpoint geometry. No dimension order is fitted.

## Interface and signs

Use
\[
h=\mathbf1_{[-1/2,1/2]},\quad w(u)=\int_0^1e^{-|u|/t}\,dt,\quad
\phi=h*w,\quad \psi_a=(1-a)h+a\phi,
\]
with \(\phi'(u)=w(u+1/2)-w(u-1/2)\). Define
\[
b_a=-a\psi_a-au\phi',\qquad
B_{n,a}(u)=\sum_j b_a(u_j)\prod_{i\ne j}\psi_a(u_i).
\]
The centered term has full mass zero. Between physical hard-face crossings the ordinary derivative of \(L^{-n}\prod_j\psi_a((x_j-y_j)/L)\), with respect to \(\log L\), is the scaled \(B_{n,a}-n(1-a)\Psi_{n,a}\). Thus the continuous derivative itself is not centered. In the distributional derivative, each coordinate face contributes the scaled \((1-a)\beta_j\otimes\psi_{a,\ne j}\), where \(\beta=(\delta_{-1/2}+\delta_{1/2})/2\).

For the actual contrast \(D_\delta=\Psi_{n,\delta/2}-\Psi_{n,\delta}\), continuous ordinary mass and negative-drift mass both equal \(-n\delta/2\); the total positive-minus-negative face mass is \(+n\delta/2\). These are analytic identities. They do not depend on the Monte Carlo mass estimates being close to their targets.

The theoretical full-domain bound used for comparison is
\[
J_\phi=\int(\phi+u\phi')^2/\phi\le7/3,\qquad
\int b_a^2/\psi_a\le (10/3)a-a^2.
\]
Independence and Cauchy–Schwarz give
\[
\|B_{n,\delta/2}-B_{n,\delta}\|_1
\le\sqrt{n((10/3)(\delta/2)-(\delta/2)^2)}+
\sqrt{n((10/3)\delta-\delta^2)}.
\]
These inequalities are supplied by the accompanying theory, rather than certified by this quadrature. No literal noise cutoff is applied; its additional faces and possible endpoint Fisher divergence are outside this test.

## Stage 1: actual coordinate density and centered score

Physical \(dx\) integration is split at \(\pm1/2\) on \([-12,12]\), so each smooth interval uses its own hard-state endpoint value. Coarse/fine rules use 512/1024 Simpson panels per interval and 128/256 panels in the actual Laplace-mixture evaluation of \(\phi\). The softness values are \(1,1/2,1/4,1/8,1/64\).

| a | Diagnostic \(\int_{-12}^{12}b_a^2/\psi_a\) | Analytic full-domain upper | Coarse/fine difference |
|---:|---:|---:|---:|
| 1 | 0.990023 | 2.333333 | 0.00000526 |
| 1/2 | 0.723844 | 1.416667 | 0.00001585 |
| 1/4 | 0.421753 | 0.770833 | 0.00001138 |
| 1/8 | 0.225986 | 0.401042 | 0.00000656 |
| 1/64 | 0.0299084 | 0.0518392 | 0.000000916 |

The common diagnostic Fisher value is 0.990023; \(\int u^2\phi'^2/\phi\) is 1.990019. The finite-domain centered-mass identity
\[
\int_{-A}^{A}b_a
=a(1-a)\left(\int_{-A}^{A}\phi-1\right)-2aA\phi(A)
\]
is checked separately from the full-domain zero-mass statement. Its largest residual is \(9.663\cdot10^{-6}\); the largest coarse/fine difference among the recorded coordinate integrals is \(6.224\cdot10^{-5}\). The JSON records a crude analytic tail expression \(a(1-a+2A)e^{1/2-A}\), but that expression does not bound quadrature error. Decimal values and refinement differences are not outward intervals.

## Stage 2: signed original sources, physical scales, and complete jumps

The three original signed atomic inputs are:

| Input | Dimension | Source locations | Signed weights | \(\delta\) | \(W=\sum|w_i|\) |
|---|---:|---|---|---:|---:|
| signed pair | 1 | \(-1/4,1/4\) | \(1,-1\) | 1/2 | 2 |
| signed square | 2 | all \((\pm1/4,\pm1/4)\), lexicographic order | \(1,-1,-1,1\) | 1/2 | 4 |
| correlated signed | 4 | diagonal points at \(-3/4,-1/4,1/4,3/4\) | \(1,-2,3,-1\) | 1/4 | 7 |

No absolute-value replacement of these weights occurs inside the convolution. Each input has eight physical receivers: four registered diagonal points and four seeded rational points (seed \(780211+n\)); all coordinates are archived. For each receiver every exact rational physical breakpoint \(L=2|x_j-y_j|\) in \((1,2]\) is retained. The initial \(L=1\) is closed, and a jump at \(L=2\) is included. There are 24 point rows and seven events where more than one source-coordinate crosses at the same scale.

Within each open scale segment, the hard-state mask is fixed and the centered term and negative drift are integrated separately in \(d\log L\). Coarse/fine rules use 16/32 scale panels and 64/128 kernel panels. At a tied crossing the jump is the complete right-product minus complete left-product, including all simultaneous coordinate changes. An isolated-face sum with inconsistent other-coordinate states is not used.

For every point, the reconstructed identity is
\[
D_2(x)-D_1(x)=\int_1^2(B_{\rm diff}+\mathrm{drift}_{\rm diff})(x,L)\,d\log L
+\sum_{1<L_*\le2}\bigl(D_{L_*}(x)-D_{L_*^-}(x)\bigr).
\]
The maximum fine residual is \(7.726\cdot10^{-6}\); the maximum sum of coarse/fine differences across the four recorded terms is \(2.815\cdot10^{-5}\). For the correlated signed source at \(x=(5/4)^4\), the endpoint change 0.24067437 decomposes as centered integral −0.02729927, negative-drift integral +0.22817528, and the four-coordinate \(L=2\) jump +0.03980095; the residual is −0.00000259. Omitting that jump leaves a macroscopic error.

Original physical \(dx\) is also retained in fixed midpoint cubatures on \([-2,2]^n\): 32 nodes for the pair and 64 for the square, with node volume weights 1/8 and 1/4. Absolute integrals of the separate scale-integrated terms and signed integrals are both saved. Symmetry makes the signed totals nearly zero, so they alone would conceal the variation. The cubature sums of absolute reconstruction residual are \(6.172\cdot10^{-6}\) and \(1.050\cdot10^{-5}\). These are finite spatial cubatures, not certified Lebesgue integrals, and no spatial or scale supremum is optimized.

## Stage 3: actual product-mixture pressure

For each \(n\in\{1,2,4,8,16,32,64\}\), test the distinct values \(\delta=1/n\) and \(\delta=1/2\). Each case uses two independent batches of 512 samples. The proposal is the actual endpoint mixture \((\Psi_{n,\delta/2}+\Psi_{n,\delta})/2\), with a common component chosen for the whole vector and independent coordinates conditional on it. Each \(\psi_a\) coordinate is sampled as a uniform hard coordinate, plus, with probability \(a\), Laplace noise at scale \(T=\sqrt U\); the mixing density \(2t\) produces exactly \(w\). Density ratios are evaluated by log-sum-exp and are at most two in ideal arithmetic. Sampling represents original \(dx\) at physical scale one; dilation invariance transfers the kernel norm to another scale, but does not certify a scale supremum.

The table gives two independent estimates of \(\|B_{n,\delta/2}-B_{n,\delta}\|_1\), each followed by its ordinary sample SE. The last column is the corresponding two estimates of the ordinary continuous derivative's L1 norm. All entries are approximate.

| n | \(\delta\) | Centered batch 1 ± SE | Centered batch 2 ± SE | Analytic centered upper | Ordinary L1 batches 1 / 2 |
|---:|---:|---:|---:|---:|---:|
| 4 | 1/4 | 0.4208 ± 0.0312 | 0.3956 ± 0.0326 | 3.0225 | 1.0873 / 1.0850 |
| 16 | 1/16 | 0.3868 ± 0.0279 | 0.4353 ± 0.0346 | 3.0935 | 5.1268 / 5.0864 |
| 64 | 1/64 | 0.4995 ± 0.0415 | 0.4477 ± 0.0371 | 3.1109 | 22.5205 / 21.5119 |
| 4 | 1/2 | 0.5774 ± 0.0372 | 0.5616 ± 0.0366 | 4.1364 | 1.3920 / 1.4328 |
| 16 | 1/2 | 2.9840 ± 0.1043 | 3.0847 ± 0.1265 | 8.2728 | 9.5936 / 9.2755 |
| 64 | 1/2 | 9.1641 ± 0.2586 | 9.3166 ± 0.2751 | 16.5457 | 62.1057 / 63.8661 |

At \(n=64,\delta=1/64\), negative-drift L1 estimates are 22.9698 ± 0.6167 and 21.9163 ± 0.5816, despite its exact signed mass −1/2. Centering materially changes what is paid. This is not a counterexample to the compensated face estimate: that estimate must keep its face and drift together. Ordinary signed-mass estimates in this case are 1.5145 ± 1.1523 and −1.0028 ± 1.0993; their wide sampling error illustrates why a finite batch is not an integral certificate. The source is a single unit atom for these kernel-norm comparisons; the earlier signed source tests are not used to infer source-count growth.

All 13 cases, 26 batches, 13,312 vector draws, and 258,048 coordinate draws are archived. Seeds are \(783000+100n+\lfloor100\delta\rfloor+j\), \(j=0,1\). There is no training/selection/held-out optimization in this test; the two batches independently evaluate registered cases. The JSON stores batch statistics and seeds, not individual sample vectors. The first four vectors of each batch are reevaluated with 128 versus 64 kernel panels; the maximum contrast-score difference is 0.0009242. This spot check does not bound the error of the remaining vectors.

## Reproduction and limits

From the extracted directory containing the standalone script, run with standard-library Python 3 (the production runtime was bundled Python 3.12.14):

```sh
python3 -B flux_probe.py
```

The refined production run exited zero and took 5.186337 s. `PASS` means the finite regression assertions completed; it does not upgrade Simpson refinement or sample SE to a rigorous interval. Floating kernel evaluation, finite random-generator laws (including a \(2^{-53}\) logarithm floor), limited physical window \([1,2]\), finite receivers, and finite cubature domains remain explicit limitations. The test preserves the true kernel, signs, source positions, physical scales, and \(dx\), but establishes neither the original selector supremum nor a universal operator estimate.

Frozen code SHA256: `e6bff6d5ecc537132eaec7da265514d4997fbd8ae51f45e85ebe7636dbb565e2`.

Frozen results SHA256: `e7499defa4554472fb5530c282d5f7de5a00db11ef22340208696c7c7c96a1c8` (57,613 bytes).

Parent independent replay (`parent_replay_receipt.json`) exited zero with empty stderr, took 5.207569 s wall time (5.165713 s internally), and reproduced the frozen results byte for byte.


# 第78轮独立审计：冻结通过，主弱型界仍未闭合

真实 E2 Fisher、中心通量全层强支付、一般有限窗口有限层归约、fine-layer 背景支付及共同 source-duty 混合接口通过独审。两个数值主脚本冻结重放 byte-identical，三组件守卫通过，归档隔离路径通过。主根号维数弱型界仍未证明：实际 signed-face crossing 估计、hybrid duty 的一般存在性及全尺度闭合均尚缺。本审计只写 audit.md、audit_guard.py，不改他人文件，不操作 Git 或编译/PDF。

A02/L03/D04 的当前边界仍适用：核对逐点支配、原输入测度与 Lebesgue 观察积分；有理端点与连续积分近似分开；共同选择器不改成私有来源/接收点选择。这里没有从通用浮点库状态或未经证明的动态谱迁移推出上界。

## 真实一维核及尺度 Fisher 常数

实际 `w(x)=∫_0^1 e^{−|x|/r}dr` 质量一，h为长度一中心区间指标。必须将 `ℓ_r=e^{−|x|/r}/(2r)` 归一化；令 `f_r=h*ℓ_r`，则 `φ=h*w=∫_0^1 2r f_r dr`，混合权重2r dr也为概率，不能遗漏2r或另加硬原子。

内部 `|x|≤1/2` 的最小密度 `(1−e^{−1/r})/2>1/4`，`|f_r′|≤e^{−(1/2−|x|)/r}/(2r)`。利用 `x²/f_r≤1`，积分后得内部加权导数能量≤1/(4r)。外部直接计算准确为

`(1−e^{−1/r})(1/(4r)+1+2r)`，

故总能量≤1/(2r)+1+2r。指数尾允许分部积分 `∫x f_r′=−1`，因此尺度 score 的 Fisher（不是位移 Fisher）为 `J(f_r)=∫(f_r+x f_r′)²/f_r=energy−1≤1/(2r)+2r`。

带权 Cauchy 对真实混合 score 给 `J(φ)≤∫_0^1 2r J(f_r)dr≤1+4/3=7/3`。混合的弱导数取入积分可以由上述 score L¹ 可积性证明；φ正、C¹、指数尾也直接允许 `∫xφ′=−1`。所以 `∫x²φ′²/φ=J(φ)+1≤10/3`。r→0虽单个Fisher发散，但混合权重2r使所用界可积，不存在隐藏端点项。

## 中心通量的独立推导及支付边界

对 `ψ_a=(1−a)h+aφ`、0<a≤1，定义 `b_a=−aψ_a−a xφ′`。∫b_a=0，故在ψ_a概率下其score均值0，且准确

`Var(b_a/ψ_a)=a²[∫x²φ′²/ψ_a−1]≤(10/3)a−a²`。

这里用ψ_a≥aφ；a=0必须单列b_0=0，不能在1/a界中直接代入。a=1时方差就是J(φ)≤7/3，端点一致。

张量 `B_(n,a)=Σ_i b_a(x_i)∏_(j≠i)ψ_a(x_j)` 的score是独立零均值变量之和，交叉项消失。于是 `||B_(n,a)||₁≤sqrt(n[(10/3)a−a²])≤sqrt(10na/3)`。独立性属于卷积核的产品概率，不要求任意输入ν为产品；对一般ν用Young L¹卷积不等式支付W倍核范数。

有限窗口尺度积分的中心部分，可将每层两端B_(n,δ/2)、B_(n,δ)的强L¹范数先相加，再对logL∈[0,log2]积分。全部δ=2^(−s)的几何和给

`(log2)sqrt(10n/3)·(1+1/sqrt2)/(1−1/sqrt2)·W`。

这是强L¹正积分后Tonelli的支付，没有平均弱L¹准范数。固定尺度层锚点另有 `Σ_s min(2,n2^(−s))W≤[2floor(log2n)+4]W`。

完整尺度导数含硬面的分布项。令 `face=(δ_(−1/2)+δ_(1/2))/2`；独立代数准确给

`−ψ_a−xψ_a′=b_a+c_a`，`c_a=(1−a)(face−ψ_a dx)`。

两个分量均为零质量，c_a不能拆为独立正费用后宣称仍有sqrt(n)预算。张量 C_(n,a) 的硬面与漂移保持同一参数ψ_a；相邻层差为B_a−B_(2a)+C_a−C_(2a)。有限层硬面差望远镜成C_(n,ε)−C_(n,1)=C_(n,ε)，ε→0回到原H的硬面−nH尺度通量。这个剩余保留了原问题，不能把已付B部分误作全层变化已付。

直接硬截断的 `φ_R=h*(w 1_{|z|≤R})` 不能用该Fisher预算。在正支撑边缘x=R+1/2−d，R固定且w(R)>0，φ_R∼w(R)d、φ_R′→−w(R)，故加权导数能量含常数乘1/d，积分对数发散。正确路线先对未截断真核分解，再用第77轮独立已付的core余项迁移；新增零shift补偿标签不会修复支撑边缘的这种发散。

## 一般有限窗口有限层归约

parent_reduction.md 的Φ=φ^⊗n尺度score独立和给 `||G||₁≤sqrt(7n/3)`。W¹,¹尺度基本定理和卷积/Fubini使有限物理族J⊂[1,2]的平滑基准max可按 `[1+(log2)sqrt(7n/3)]W`一次强L¹支付，无尺度数量项。

有限参数望远镜 `H−Ψ_ε=εΣ ψ_ε^前⊗(h−φ)⊗h^后` 以h+φ替换给正V_ε，质量2nε，沿原点射线递减。有限窗口正包络系数总和≤1+nlog2，于是整个细软尾费用≤`2n(1+nlog2)εW`。这整合了此前耦合差与ray-envelope工具，不需要宣称一条新外部定理。

最小非负整数S由 `2^(2S)≥16n(1+n)²`选择，ε=2^-S。它给ε≤1/[4sqrt(n)(1+n)]，log2<1故细尾≤sqrt(n)W/2；n≥1时S≥3，阈值分配不会除0。S仅依赖n并为O(log(2+n))，不引入输入深度。

对S个真实contrast最大选择层，τ=λ/(4S)，背景B=4sqrt(n)Sλ。各K_s为正概率ray-decreasing核，共同finite-window envelope≤(1+nlog2)W。实际高背景层并集Markov后S与背景分母S准确抵消，费用为 `[(1+nlog2)/(4sqrt(n))]W`。剩余低背景相对比B/τ准确为16sqrt(n)S²，不能删除S²。

若基准、细尾都≤λ/4且每个层max≤λ/(4S)，全部望远镜贡献≤3λ/4。因此父式(P78.5)完整成立：

`λ|{max_J |ν*H_L|>λ}| ≤ [4+4(log2)sqrt(7n/3)+2sqrt(n)+(1+nlog2)/(4sqrt(n))]W + λ|∪_(s<S) E_low,s|`。

前面三类部分已付，最后并集尚未付。中心通量支付不能自动替代该低事件集合估计；即使有限窗口闭合，还需要全尺度局部化。本轮不由这些保留接口宣布主目标已完成。

## 真实 selector 接入及 hardface 终稿

父稿(P78.6)保留原层T的实际最大选择器L_s(x)。soft的全层支付函数P满足∫P≤C_P W，其中 C_P=2floor(log2n)+4+(log2)sqrt(10n/3)(3+2sqrt2)。移除{P>λ/(8S)}的费用准确为8S C_P W。其外若同一个L_s的|T|>λ/(4S)，则|Y|>λ/(8S)。因此原低事件并集归约到保留原selector和背景约束的 E_face,s；不是重新对Y作私有最优化。新增费用为O(sqrt(n)log(2+n)+log²(2+n))W，最后实际face事件并集仍未付。

hardface终稿对f≥0的准确方程是 u′=c+v−κu−γP_a，κ=n(1−a/2)、γ=na/2。正cross的背景帮助回落，负cross的背景是adverse forcing。除去锚点后，以真实first-hit和同号last-excursion构造一条corridor，两个积分恒等式的符号正确：正号把γ∫P放在左边；负号把它放在右边。last-exit不是stopping time；这里只使用确定性积分/Fubini，不把signed face当鞅。有限signed kernel质量给L¹时空导数，L¹平滑逼近的统一卷积误差给任意非负L¹输入的连续代表，故该全输入延伸合法。

令a0≤n^(-1/2)、a_k=a0 2^-k、r=1/sqrt2、w_k=(1−r)r^k。Q_k=(na_k/2)∫_0^log2 P_a dt的质量为na_k(log2)W/2。并集{Q_k>λw_k/8}可按 4n(log2)a0/(1−r)² W≤4(log2)sqrt(n)/(1−r)² W支付。其外负cross必须产生至少3λw_k/8加恢复项的真实signed flux。另一sup背景吸收branch按4(1+nlog2)a0/(1−r)² W支付；它是替代方案，不能与第一种支付当作同一笔相加。所有几何尾在证明和守卫中显式保留。

这没有证明剩余signed-face corridor体积界，也没有解决a>n^(-1/2)粗层。连续项的阈值分配要独立保留；不能将其sqrt(a)范数直接除同一sqrt(a)权重后无限相加。Duhamel的寿命1/κ不允许无证地乘入空间supremum。

hardface强variation压力例的常数通过：真实 q=2∫_0^1 r²(1−e^(-1/r))dr，q0=2(1−e^-1)/3≤q；a=1/n时相对内部面质量差至少q0 n/24。实际单位质量小盒f_ε、ε=q0/(1000n)，面切片只需损失正面质量，给6n(n−1)ε/L；漂移给8n²ε/L。故整个窗口强L¹variation≥q0 n/40。此为固定真实L¹输入的强支付障碍，绝不是weak-type反例。12个实际小盒有限差分恒等式仍是浮点诊断。

## Coverage 的共同来源与直接混合 LP

coverage终稿(D1)–(D17)通过独审。有限尺度 duty 的准确价格是 Σ_j(v_j−v_(j−1))max_(k≥j)d_k/v_k；star hull shell积分给该式，不收费不活跃的前后空档。对正ray-decreasing核的独立验证：设H_j=max_(k≥j)d_k/v_k，则 Σ_j v_j(H_j−H_(j+1))k_(L_j)逐点支配每个d_k k_(L_k)，总系数为同一价格。方向与非负系数正确。

source-dependent duty禁止依赖receiver；共同η⊗du residual lift以同一门u>d_(θ,L(x))实现实际F_R、C_R、T_R，容量来源不随receiver重建。物理affine代表gate不要求自身通过duty门，只扩大score，而单packet的径向支付仍合法。其原band、posterior幂、P(b)除数都保留。|T_R|>λ/2给λ/4<F_R≤Hλ及λ/(4H)<C_R≤4Hλ，两个band比4H及16H²正确。K/J occupation Cauchy返回(D12)无额外H乘数，但覆盖不等式(D11)本身是待证条件。

直接mixed LP的每个列明确收费，不借用未检查的source-capacity免费复用。d≤1产生弱对偶的−Σγ目标罚项；本文及守卫核验系数取消与方向。有限atomic来源及有限物理scale的全部source/representative faces作直角arrangement，actual max-|T|最小index tie break、事件、G和代表列在每个open cell上常数；边界Lebesgue-null，故精确cell primal认证整个真实有限模型事件。不能自动迁移为连续E2 noise证书。

组件守卫的三整事件 mixed optimum分别为1/2、4/5、16/25，代表费用全部为0；它们验证接口和精确primal/dual，不证明代表带来收益。独审守卫另以独立有理duty/dual fixture验证weak-dual罚项（primal 22523/5184、dual 43/81），及二维单hard atom、L=1,2、τ=1/8的整个真实事件：clipped duty价格=1/2=τ×事件体积。一般低价duty与有效残余覆盖的存在性仍未证明。

## 数值源、运行与认证范围

本次独审没有导入生产主代码来重用其数值函数。fisher部分另以physical-x score积分核验s=1,1/2,1/16，与作者boundary-u energy积分不同；两种方法一致属于浮点诊断。实际φ的最新J≈0.9901650894、energy≈1.9901650894及质量refinement不作向外积分区间。极小s的1/s增长保留，不能把underflow当低Fisher证据。131个整数S及细尾质量记录、384个通用有理product/telescope实例精确重建；这些有理φ-surrogates不声称真实E2点值。

flux部分独立重建24个signed原子来源receiver记录和7个完整tied-arrival product jumps。源breakpoints、原W和gate geometry为Fraction精确；连续B使用division-free表达式、独立真实2r Laplace-mixture φ积分，负drift保留原符号。浮点jump差最大1.3877787807814457e−17，连续B/drift表达式差最大5.551115123125783e−17；这不是连续积分误差证书。完整FT重建误差7.725e−6、标量b质量误差9.663e−6被保留为diagnostic。

实际mixture proposal先共同选择一个endpoint再按坐标独立生成ψ，权重使用原dx下(Ψ_a+Ψ_b)/2，两个density/proposal比之和为2。理想s=sqrt(U)给权重2s的Laplace mixture；有限机器RNG不是精确连续law。26个独立batch共13312 vectors/258048 coordinates、原signed mass线性恒等式标签通过；只有每batch前4vectors作score refinement，不能把它升级为所有draw的误差界。iid SE不作确定性覆盖保证。

标准库 audit_guard.py 完整实际运行PASS，elapsed 6.5835秒。包含165个Laplace显式式有理Taylor外包围、12个独立产品score实例、21个中心几何尾模型、8个独立整数S/24阈值实例、21个fine-forcing有限加无限尾模型；连续普遍结论由本审计解析链负责，有限sample表达式不是cubature证书。

冻结主脚本在temp-copy独立目录重放：fisher 0.4942秒、flux 5.2045秒，两个JSON均逐byte-identical。soft守卫0.0634秒PASS65；coverage 0.1443秒PASS228；hardface 0.3664秒PASS64 exact sign cases及12 actual L¹ box诊断。生产quadrature和随机统计的误差标签保持未认证。

进一步实际归档隔离：只放独审guard、两主py/json与三个提取guard，不带任何component md，完整PASS 6.6274秒；只放上述主文件及包含三个冻结Python fences的合并proof.md，完整PASS 6.6908秒。audit_guard优先读取同目录component_guard.py，其次开发component md、否则按冻结SHA从proof.md提取；归档不需要任何外部组件文件。隔离proof测试使用相同冻结fence bytes，正文内容不参与guard提取。最终合并proof须带soft/hardface/coverage三冻结fences与本audit守卫，共4个Python fences。本审计正文不新增Python fence。

## 冻结来源 SHA-256

下列哈希标识实际审计版本；文件名是来源标识，不是归档外依赖。

| 来源 | SHA-256 |
|---|---|
| parent_reduction.md | `820afe98045214e8a6d4a07ed1a9f47fc9395b917e7708fb891df8a3e642ff74` |
| soft.md | `1cf1fbf9127f278eddd50164f3d054b99f2f85431b8f685a113b4fef873ea89b` |
| hardface.md | `39a88d501b7678497252e733bfb557d06c7987d73e369e07f54da52f9b39a568` |
| coverage.md | `a2dcaac262dfb5d5accb2ed0f475fea8a882d386a46be3cbd49e623c3f86620f` |
| flux_numeric.md | `8569bd4c8a405cd4285cbdf1aa0ec672ed5e5a187a75e1f7f848196b9c1a757f` |
| fisher_probe.py | `84f7d00a00a33e12091f2c0ca2864e0b94d39101f6ca9d0f5f9b5108cba90d89` |
| fisher_results.json | `b603f7816f4659049e3e3668d869fc22e116b8f739a078e2d2c906329f517351` |
| flux_probe.py | `e6bff6d5ecc537132eaec7da265514d4997fbd8ae51f45e85ebe7636dbb565e2` |
| flux_results.json | `e7499defa4554472fb5530c282d5f7de5a00db11ef22340208696c7c7c96a1c8` |
| audit_guard.py | `3d0bad88c0277b3000dd77975e4dbf0c52f45296b2f239e83ae2a82bcc2e77ca` |

组件guard按fence正文加末尾newline冻结：soft `f7bf7cb28bba691d374f9a84fbe4947adab61922188e8e590b86c2d91a6228d4`；hardface `b9e767174b6b080e0f410d9a171ad6bc70fdaa770dbe4331be7eb7d59a8deae2`；coverage `5673c9cf18a886810a417393bb3e7d0859f501124feb13c0acdbfa60b53fbec0`。未编译TeX/PDF；数学终审对象是上述冻结Markdown证明，配套TeX仅是另行交付的源码。


## 最终独审守卫 audit_guard.py

```python
#!/usr/bin/env python3
"""R78 independent true-E2 Fisher envelopes and centered tensor algebra.
Rational enclosures certify sampled analytic expressions, not continuum cubature.
The continuum inequalities and the literal-cutoff obstruction need the proof.
"""
from fractions import Fraction as Q
from itertools import product
import math,json,time,hashlib,tempfile,subprocess,sys,re,random
from pathlib import Path
from functools import lru_cache
BASE=Path(__file__).resolve().parent

def exp_interval(x,terms=80):
    x=Q(x);assert 0<=x<terms+2
    total=term=Q(1)
    for j in range(1,terms+1):term*=x/j;total+=term
    first=term*x/(terms+1)
    return total,total+first/(1-x/Q(terms+2))

def exp_minus(x):
    lo,hi=exp_interval(x);return 1/hi,1/lo

def sqrt_interval(x,bits=80):
    x=Q(x);grid=1<<bits;lo=math.isqrt(x.numerator*grid*grid//x.denominator)
    hi=lo+int(lo*lo*x.denominator!=x.numerator*grid*grid)
    assert lo*lo*x.denominator<=x.numerator*grid*grid<=hi*hi*x.denominator
    return Q(lo,grid),Q(hi,grid)

def ln2_interval(terms=60):
    z=Q(1,3);p=z;lo=Q(0)
    for j in range(terms):lo+=2*p/(2*j+1);p*=z*z
    return lo,lo+2*p/((2*terms+1)*(1-z*z))

def fisher_laplace():
    checks=0;minimum_lower=Q(1)
    # All expressions are for h convolved with NORMALIZED Laplace(s).
    for s in (Q(1,8),Q(1,4),Q(1,2),Q(3,4),Q(1)):
        em=exp_minus(1/s)
        for j in range(33):
            x=Q(j,64);u,v=(Q(1,2)+x)/s,(Q(1,2)-x)/s
            eu,ev=exp_minus(u),exp_minus(v)
            flo=1-(eu[1]+ev[1])/2
            assert flo>Q(1,4);minimum_lower=min(minimum_lower,flo)
            # x>=0: |f_s'|=(exp(-v)-exp(-u))/(2s).
            diff_hi=ev[1]-eu[0]
            assert diff_hi<=ev[1] and x*x*diff_hi*diff_hi/(4*s*s*flo)<=ev[1]*ev[1]/(4*s*s)
            checks+=1
        inside_majorant=Q(1,4)/s*(1-em[0])
        outside_actual_hi=(1-em[0])*(Q(1,4)/s+1+2*s)
        assert inside_majorant<=Q(1,4)/s
        assert outside_actual_hi<=Q(1,4)/s+1+2*s
        assert Q(1,4)/s+(Q(1,4)/s+1+2*s)-1==Q(1,2)/s+2*s
    # Uniform proof of f_s>=1/4 for 0<s<=1 follows from e>2.
    elo,ehi=exp_interval(1);assert elo>2
    # Exact mixing weights 2s have mass one; integrate polynomial J envelope.
    mixed_J=Q(1)+Q(4,3)
    assert mixed_J==Q(7,3) and mixed_J+1==Q(10,3)
    return {'rational_inside_expressions':checks,'f_s_lower_min_certified':str(minimum_lower),'true_phi_scale_Fisher_upper':'7/3','true_phi_weighted_derivative_upper':'10/3','scope':'Finite rational Laplace expression enclosures plus exact integrated polynomial majorant; continuum proof is separate.'}

def tensor_algebra():
    # Independent rational probability fixtures with centered scores.
    # They verify the product variance identity, not actual-E2 cubature.
    fixtures=[[(Q(1,3),Q(-2)),(Q(2,3),Q(1))],[(Q(1,4),Q(-3)),(Q(1,2),Q(1)),(Q(1,4),Q(1))]]
    cases=0
    for law in fixtures:
        assert sum(p for p,z in law)==1 and sum(p*z for p,z in law)==0
        v=sum(p*z*z for p,z in law)
        for n in range(1,7):
            norm=second=mean=Q(0)
            for draw in product(law,repeat=n):
                mass=math.prod(p for p,z in draw);score=sum(z for p,z in draw)
                norm+=mass*abs(score);mean+=mass*score;second+=mass*score*score
            assert mean==0 and second==n*v and norm*norm<=second;cases+=1
    for a in (Q(0),Q(1,64),Q(1,8),Q(1,2),Q(1)):
        if a==0:assert a*a==0;continue
        bound=Q(10,3)*a-a*a
        assert bound>=0 and bound<=Q(10,3)*a
    return {'rational_product_laws':cases,'scope':'Exact product-score centering/Cauchy algebra; these fixtures are not E2 noise laws.'}

def layer_budgets():
    lnlo,lnhi=ln2_interval();rlo,rhi=sqrt_interval(Q(1,2));cases=0
    factor_hi=(1+rhi)/(1-rhi)
    for n in (1,2,4,16,256,4096,16384):
        rootlo,roothi=sqrt_interval(Q(10*n,3))
        bound=lnhi*roothi*factor_hi
        for m in (2,8,64):
            partial_hi=(1+rhi)*sum(rhi**s for s in range(m))
            tail_hi=(1+rhi)*rhi**m/(1-rhi)
            assert partial_hi+tail_hi==factor_hi
            assert lnhi*roothi*partial_hi<=bound
            # Actual contrast endpoint variation anchors, including infinite tail.
            exact=sum(min(Q(2),Q(n,1<<s)) for s in range(m))
            tail=Q(n,1<<(m-1))
            total_upper=exact+tail
            # If tail begins after saturation, the tail formula is exact;
            # otherwise it is still a valid overestimate, so only compare
            # after choosing m>=floor(log2 n)+1.
            q=n.bit_length()-1
            if m>=q+1:assert total_upper<=2*q+4
            cases+=1
    assert rlo*rlo<=Q(1,2)<=rhi*rhi
    return {'finite_plus_infinite_tail_models':cases,'centered_all_layer_fee_formula':'log(2)*sqrt(10*n/3)*(1+1/sqrt(2))/(1-1/sqrt(2))*W','anchor_fee_upper':'(2*floor(log2(n))+4)*W','scope':'Exact outward rational constants and geometric tails; no finite-layer extrapolation.'}

def cutoff_obstruction():
    # Local linear edge model forced by positive w(R): on edge-distance d,
    # phi_R is comparable to d and its derivative is bounded away from zero.
    # A dyadic shell of c/d contributes a constant, hence no finite Fisher.
    lnlo,lnhi=ln2_interval();checks=0
    for m in (2,8,64,256):
        assert m*lnlo>0
        # Exact integral proxy for lower bound c/d across [2^-m,1].
        assert sum(lnlo for _ in range(m))==m*lnlo
        checks+=1
    return {'dyadic_edge_divergence_models':checks,'scope':'Algebraic local-edge divergence mechanism; not a Fisher bound for the literal cutoff kernel.'}


def finite_window_reduction():
    lnlo,lnhi=ln2_interval();assert lnhi<1
    cases=0;records=[]
    for n in (1,2,3,4,16,256,4096,16384):
        rhs=16*n*(1+n)**2;S=0
        while (1<<(2*S))<rhs:S+=1
        assert S>=3 and (1<<(2*S))>=rhs>(1<<(2*S-2))
        eps=Q(1,1<<S);tail=2*n*(1+n*lnhi)*eps
        assert tail*tail<=Q(n,4)
        # Exact layer telescope coefficient in the parameter epsilon.
        assert Q(1)+sum(Q(1,1<<(s+1))-Q(1,1<<s) for s in range(S))==eps
        for lam in (Q(1,4),Q(1),Q(7)):
            threshold=lam/(4*S)
            assert lam/4+lam/4+S*threshold==3*lam/4
            # Square-dimension background cancellation uses rational sqrt.
            root=math.isqrt(n)
            if root*root==n:
                background=4*root*S*lam
                assert S*lam/background==Q(1,4*root)
                assert background/threshold==16*root*S*S
            cases+=1
        records.append({'n':n,'S':S,'epsilon':str(eps),'squared_tail_fee_upper':str(tail*tail),'squared_target':str(Q(n,4))})
    return {'integer_tail_threshold_dimensions':len(records),'threshold_cases':cases,'records':records,'scope':'Exact tail cutoff and finite-layer threshold/high-budget algebra; residual low-event union remains unpaid.'}


def hardface_and_hybrid_algebra():
    rlo,rhi=sqrt_interval(Q(1,2));lnlo,lnhi=ln2_interval()
    models=0
    for n in (1,2,4,16,256,4096,65536):
        s0=0
        while 1<<(2*s0)<n:s0+=1
        a0=Q(1,1<<s0);assert n*a0*a0<=1
        for m in (4,16,64):
            # a_k/w_k = a0 r^k/(1-r), exact geometric partial+tail.
            partial=sum(rhi**k for k in range(m))/(1-rhi)
            tail=rhi**m/(1-rhi)**2
            assert partial+tail==1/(1-rhi)**2
            assert (n*a0)**2<=n
            for eta in (Q(1,8),Q(1),Q(7)):
                for a in (a0,a0/2,a0/64):
                    kappa=n*(1-a/2);gamma=n*a/2
                    assert gamma*eta/(4*a)<=kappa*(eta/2)/2
                    # A negative crossing needs eta/2 minus at most eta/8.
                    assert eta/2-eta/8==3*eta/8
            models+=1
    # An independent coefficient-wise weak-dual check for the duty epigraph,
    # including the indispensable negative gamma penalty from d<=1.
    N=2;L=[Q(1),Q(3,2),Q(2)];v=[l*l for l in L]
    masses=[Q(1,3),Q(2,3)];zeta=[Q(1),Q(2)]
    duty=[[Q(1,4),Q(1,2),Q(3,4)],[Q(1,2),Q(1,3),Q(1,4)]]
    h=[[max(duty[i][k]/v[k] for k in range(j,3)) for j in range(3)] for i in range(N)]
    c=[masses[i]*zeta[i] for i in range(N)]
    dv=[v[0],v[1]-v[0],v[2]-v[1]]
    rows=[(0,[Q(1,3),Q(4,3)]),(1,[Q(4,27),Q(0)]),(2,[Q(1,12),Q(1,3)])]
    columns=[[Q(1),Q(1,2),Q(1,4)],[Q(1,4),Q(1,2),Q(1)]]
    alpha=[Q(1,4),Q(1,2)];K=[Q(4),Q(4)]
    tau=min(sum(A[i]*duty[i][k] for i in range(N))+sum(columns[j][r]*alpha[j] for j in range(2)) for r,(k,A) in enumerate(rows))
    y=[Q(1),Q(2),Q(1)]
    assert all(sum(y[r]*columns[j][r] for r in range(3))<=K[j] for j in range(2))
    beta={(i,j,k):c[i]*dv[j]/(3-j) for i in range(N) for j in range(3) for k in range(j,3)}
    assert all(sum(beta[i,j,k] for k in range(j,3))==c[i]*dv[j] for i in range(N) for j in range(3))
    gamma=[[max(Q(0),sum(y[r]*A[i] for r,(kr,A) in enumerate(rows) if kr==k)-sum(beta[i,j,k]/v[k] for j in range(k+1))) for k in range(3)] for i in range(N)]
    assert sum(sum(g) for g in gamma)>0
    primal=sum(c[i]*dv[j]*h[i][j] for i in range(N) for j in range(3))+sum(K[j]*alpha[j] for j in range(2))
    dual=tau*sum(y)-sum(sum(g) for g in gamma)
    assert dual<=primal
    # One actual whole-event continuum certificate independently: one hard
    # atom in R^2, physical scales 1 and 2, threshold 1/8. Smallest-scale max
    # selects 1 on [-1/2,1/2]^2 and 2 on the surrounding side-2 shell.
    # Clipped duties d_k=tau*v_k pay exactly tau*4=1/2=weak event fee.
    clipped=[Q(1,8)*vv for vv in (Q(1),Q(4))]
    exact_price=Q(1)*max(clipped[0],clipped[1]/4)+Q(3)*clipped[1]/4
    assert exact_price==Q(1,2)==Q(1,8)*4
    return {'fine_partial_plus_infinite_tail_models':models,'independent_finite_duty_primal_cost':str(primal),'independent_weak_dual_lower':str(dual),'actual_whole_event_clipped_duty_price':'1/2','scope':'Rational two-sign absorption, complete geometric tail, coefficient-wise finite weak dual, and independent actual hard-cube cell certificate; no face coverage estimate.'}


@lru_cache(None)
def independent_phi(x,panels=128):
    x=float(x);z=abs(x);values=[];derivs=[]
    for i in range(panels+1):
        r=i/panels;coefficient=1 if i in (0,panels) else 4 if i%2 else 2
        if not i:
            f=0.;d=-1. if z==.5 else 0.
        elif z<=.5:
            right=math.exp(-(.5-z)/r);left=math.exp(-(.5+z)/r)
            f=2*r*(1-(left+right)/2);d=left-right
        else:
            f=r*(math.exp(-(z-.5)/r)-math.exp(-(z+.5)/r));d=-f/r
        values.append(coefficient*f);derivs.append(coefficient*d)
    value=sum(values)/(3*panels);derivative=sum(derivs)/(3*panels)
    return value,derivative if x>=0 else -derivative

def independent_endpoint(source,x,L,a,left=False,hstates=None,panels=128):
    n=source['n'];ys=[tuple(map(Q,y)) for y in source['sites']];weights=list(map(Q,source['weights']));P=B=drift=0.
    for idx,(y,w) in enumerate(zip(ys,weights)):
        z=[float(xx-yy)/float(L) for xx,yy in zip(x,y)]
        h=[float(2*abs(xx-yy)<L if left else 2*abs(xx-yy)<=L) for xx,yy in zip(x,y)] if hstates is None else hstates[idx]
        pair=[independent_phi(v,panels) for v in z];psi=[(1-a)*hh+a*f for hh,(f,dp) in zip(h,pair)]
        product_density=math.prod(psi);factor=float(w)/float(L)**n
        P+=factor*product_density
        B+=factor*sum((-a*psi[j]-a*z[j]*pair[j][1])*math.prod(psi[:j]+psi[j+1:]) for j in range(n))
        drift-=factor*n*(1-a)*product_density
    return P,B,drift

def fisher_saved_checks():
    data=json.loads((BASE/'fisher_results.json').read_text());dims=0
    for row in data['stage3']['dimension_records']:
        n,S=row['n'],row['S'];rhs=16*n*(n+1)**2
        assert 1<<(2*S)>=rhs>1<<(2*S-2)
        eps=Q(1,1<<S);mass=2*n*eps;fee=2*n*(1+n)*eps
        assert eps==Q(row['epsilon']) and mass==Q(row['V_epsilon_mass'])
        assert fee==Q(row['coarse_fee_rational_upper']) and fee*fee==Q(row['coarse_fee_squared'])<=Q(n,4)
        lo,hi=map(Q,data['stage3']['log2_interval']);saved=list(map(Q,row['fine_maximal_fee_interval']))
        assert saved==[2*n*(1+n*log)*eps for log in (lo,hi)] and saved[1]<=fee;dims+=1
    rng=random.Random(data['stage3']['seed']);algebra=0
    for n in range(1,9):
        for eps in (Q(0),Q(1,2),Q(1,8),Q(1,64)):
            for _ in range(12):
                h=[Q(rng.randrange(2)) for i in range(n)];phi=[Q(rng.randrange(17),16) for i in range(n)]
                psi=[(1-eps)*a+eps*b for a,b in zip(h,phi)]
                differences=[eps*math.prod(psi[:i])*math.prod(h[i+1:])*(h[i]-phi[i]) for i in range(n)]
                bounds=[eps*math.prod(psi[:i])*math.prod(h[i+1:])*(h[i]+phi[i]) for i in range(n)]
                assert math.prod(h)-math.prod(psi)==sum(differences) and abs(sum(differences))<=sum(bounds);algebra+=1
    for row in data['stage3']['saved_rational_witnesses']:
        n=row['n'];eps=Q(row['epsilon']);h=list(map(Q,row['h_values']));phi=list(map(Q,row['phi_surrogate_values']))
        endpoint=lambda a:math.prod((1-a)*x+a*y for x,y in zip(h,phi))
        assert endpoint(0)-endpoint(eps)==Q(row['contrast'])
        assert endpoint(eps/32)-endpoint(eps)==Q(row['finite_5_layer_contrast_sum'])
    diagnostics=[]
    # Direct physical-x integration of the score, distinct from the producer's
    # boundary-u integral of I2 followed by subtracting one.
    for row in data['stage1']['cases'][:3]:
        r=float(Q(row['s']));N=8192;step=.5/N
        def fn(x):
            u=math.exp(-(.5-x)/r);v=math.exp(-(.5+x)/r)
            f=1-(u+v)/2;d=(v-u)/(2*r)
            return (f+x*d)**2/f
        inside=2*step/3*(fn(0)+fn(.5)+sum((4 if j%2 else 2)*fn(j*step) for j in range(1,N)))
        outside=(-math.expm1(-1/r))*(.25/r+r)
        value=inside+outside;saved=row['refinements'][-1]['J']
        assert abs(value-saved)<2e-7*max(1.,saved)
        diagnostics.append({'s':row['s'],'direct_x_J':value,'saved_J':saved})
    assert all(row['quadrature_certificate'] is False for row in data['stage2']['refinements'])
    return {'exact_dimension_records':dims,'regenerated_rational_tensor_cases':algebra,'independent_direct_x_component_diagnostics':diagnostics,'scope':'Exact generic algebra separated from floating real-E2 diagnostics.'}

def flux_saved_checks():
    data=json.loads((BASE/'flux_results.json').read_text());points=ties=0;maxjump=0.;maxcontinuous=0.
    for row in data['stage2']['point_rows']:
        source=row['source'];n=source['n'];x=tuple(map(Q,row['x']));ys=[tuple(map(Q,y)) for y in source['sites']];delta=float(Q(source['delta']))
        bp=sorted({2*abs(xx-yy) for y in ys for xx,yy in zip(x,y) if Q(1)<2*abs(xx-yy)<=Q(2)})
        assert bp==list(map(Q,row['breakpoints']))
        assert sum(abs(Q(w)) for w in source['weights'])==Q(source['W'])
        def diff(L,left=False,hstates=None):
            a=independent_endpoint(source,x,L,delta/2,left,hstates);b=independent_endpoint(source,x,L,delta,left,hstates)
            return tuple(u-v for u,v in zip(a,b))
        assert abs(diff(Q(1))[0]-row['D1'])<1e-12 and abs(diff(Q(2))[0]-row['D2'])<1e-12
        for jump in row['jumps']:
            L=Q(jump['L']);mult=sum(2*abs(xx-yy)==L for y in ys for xx,yy in zip(x,y))
            assert mult==jump['multiplicity'];ties+=int(mult>1)
            before=diff(L,True)[0];after=diff(L)[0]
            err=max(abs(before-jump['D_left']),abs(after-jump['D_right']),abs(after-before-jump['signed_jump']))
            assert err<1e-12;maxjump=max(maxjump,err)
        B=drift=0.;lo=Q(1)
        # Independently reconstruct hard state and direct (division-free) B.
        for hi in sorted(set(bp+[Q(2)])):
            mid=(lo+hi)/2;hstates=[[float(2*abs(xx-yy)<mid) for xx,yy in zip(x,y)] for y in ys]
            if hi>lo:
                start,stop=math.log(float(lo)),math.log(float(hi));M=row['scale_panels'];step=(stop-start)/M
                vals=[diff(math.exp(start+j*step),hstates=hstates) for j in range(M+1)]
                for e in (1,2):
                    value=step/3*sum((1 if j in (0,M) else 4 if j%2 else 2)*v[e] for j,v in enumerate(vals))
                    if e==1:B+=value
                    else:drift+=value
            lo=hi
        err=max(abs(B-row['centered_B_integral']),abs(drift-row['negative_drift_integral']))
        assert err<1e-11;maxcontinuous=max(maxcontinuous,err);points+=1
    batches=draws=0
    for row in data['stage3']['cases']:
        for b in row['batches']:
            n,delta=b['n'],b['delta'];assert n==row['n'] and delta==row['delta']
            assert b['analytic_centered_mass']==0 and b['analytic_negative_drift_mass']==-n*delta/2
            assert b['analytic_ordinary_mass']==-n*delta/2 and b['analytic_total_face_mass']==n*delta/2
            bound=math.sqrt(n*((10/3)*(delta/2)-(delta/2)**2))+math.sqrt(n*((10/3)*delta-delta**2))
            assert abs(bound-b['centered_contrast_L1_upper'])<1e-13
            # Signed mass identity remains a linear identity under common weights.
            assert abs(b['ordinary_continuous_mass']['mean']-b['centered_B_mass']['mean']-b['negative_drift_mass']['mean'])<1e-11
            batches+=1;draws+=b['samples']
    return {'exact_original_source_point_rows':points,'complete_tied_events':ties,'independent_jump_max_difference':maxjump,'direct_B_and_drift_reconstruction_max_difference':maxcontinuous,'diagnostic_batches':batches,'registered_vector_draws':draws,'scope':'Exact rational geometry; floating independent expression checks, not integration certificates or Monte Carlo guarantees.'}

def component_guard(component,expected):
    direct=BASE/(component+'_guard.py')
    if direct.is_file():payload=direct.read_bytes();origin=direct.name
    elif (BASE/(component+'.md')).is_file():
        origin=component+'.md';fences=re.findall(r'```python\n(.*?)\n```',(BASE/origin).read_text(),re.S)
        matches=[(f+'\n').encode() for f in fences if hashlib.sha256((f+'\n').encode()).hexdigest()==expected]
        assert len(matches)==1;payload=matches[0]
    elif (BASE/'proof.md').is_file():
        origin='proof.md';fences=re.findall(r'```python\n(.*?)\n```',(BASE/origin).read_text(),re.S)
        matches=[(f+'\n').encode() for f in fences if hashlib.sha256((f+'\n').encode()).hexdigest()==expected]
        assert len(matches)==1;payload=matches[0]
    else:raise FileNotFoundError('Package requires '+component+'_guard.py or proof.md with its frozen Python fence')
    assert hashlib.sha256(payload).hexdigest()==expected
    return payload,origin

def replays():
    expected={'fisher_probe.py':'84f7d00a00a33e12091f2c0ca2864e0b94d39101f6ca9d0f5f9b5108cba90d89','fisher_results.json':'b603f7816f4659049e3e3668d869fc22e116b8f739a078e2d2c906329f517351','flux_probe.py':'e6bff6d5ecc537132eaec7da265514d4997fbd8ae51f45e85ebe7636dbb565e2','flux_results.json':'e7499defa4554472fb5530c282d5f7de5a00db11ef22340208696c7c7c96a1c8'}
    for name,h in expected.items():assert hashlib.sha256((BASE/name).read_bytes()).hexdigest()==h
    receipts=[]
    with tempfile.TemporaryDirectory(prefix='r78-independent-') as tmp:
        target=Path(tmp)
        for code,result in [('fisher_probe.py','fisher_results.json'),('flux_probe.py','flux_results.json')]:
            (target/code).write_bytes((BASE/code).read_bytes());start=time.perf_counter()
            proc=subprocess.run([sys.executable,str(target/code)],capture_output=True,text=True,check=True)
            assert (target/result).read_bytes()==(BASE/result).read_bytes()
            receipts.append({'code':code,'byte_identical':True,'seconds':round(time.perf_counter()-start,4),'stdout':proc.stdout.strip()})
        for component,h in [('soft','f7bf7cb28bba691d374f9a84fbe4947adab61922188e8e590b86c2d91a6228d4'),('coverage','5673c9cf18a886810a417393bb3e7d0859f501124feb13c0acdbfa60b53fbec0'),('hardface','b9e767174b6b080e0f410d9a171ad6bc70fdaa770dbe4331be7eb7d59a8deae2')]:
            payload,origin=component_guard(component,h);path=target/(component+'_guard.py');path.write_bytes(payload);start=time.perf_counter()
            proc=subprocess.run([sys.executable,str(path)],capture_output=True,text=True,check=True)
            receipts.append({'component':component,'package_source':origin,'guard_sha256':h,'seconds':round(time.perf_counter()-start,4),'stdout':proc.stdout.strip()})
    return receipts

def main():
    start=time.perf_counter();out={'status':'PASS','laplace':fisher_laplace(),'tensor':tensor_algebra(),'layers':layer_budgets(),'literal_cutoff':cutoff_obstruction(),'finite_window':finite_window_reduction(),'hardface_hybrid':hardface_and_hybrid_algebra(),'fisher_saved':fisher_saved_checks(),'flux_saved':flux_saved_checks(),'replays':replays()}
    out['elapsed_seconds']=round(time.perf_counter()-start,4);print(json.dumps(out,sort_keys=True))
if __name__=='__main__':main()
```
