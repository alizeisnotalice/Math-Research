#!/usr/bin/env python3
"""R78 actual E2 centered dilation score, physical face jumps and drift.
Quadrature and iid score statistics are diagnostics, not interval certificates.
Exact rational original-source positions and physical face breakpoints retained.
"""
from fractions import Fraction as Q
from pathlib import Path
from functools import lru_cache
import math,random,itertools,json,time,hashlib

SEED=780211

def clean(o):
 if isinstance(o,Q):return str(o)
 if isinstance(o,dict):return {str(k):clean(v) for k,v in o.items()}
 if isinstance(o,(tuple,list)):return [clean(v) for v in o]
 return o

@lru_cache(maxsize=200000)
def phi_wprime(x,M=128):
 x=abs(float(x))
 def fw(t,z):return math.exp(-z/t) if t else float(z==0)
 def fp(t):
  if not t:return 0.
  if x>=.5:return t*math.exp(-(x-.5)/t)*(-math.expm1(-1/t))
  return t*(2-math.exp(-(.5-x)/t)-math.exp(-(.5+x)/t))
 phi=(fp(0)+fp(1)+sum((4 if j%2 else 2)*fp(j/M) for j in range(1,M)))/(3*M)
 def w(z):
  z=abs(z)
  if z==0:return 1.
  return (fw(0,z)+fw(1,z)+sum((4 if j%2 else 2)*fw(j/M,z) for j in range(1,M)))/(3*M)
 prime=w(x+.5)-w(x-.5)
 return phi,prime

def actual_phi(x,M=128):
 p,d=phi_wprime(abs(float(x)),M);return p,d if x>=0 else -d

def simpson(f,lo,hi,M):
 if hi==lo:return 0.
 step=(hi-lo)/M
 return step/3*(f(lo)+f(hi)+sum((4 if j%2 else 2)*f(lo+j*step) for j in range(1,M)))

def one_dim(A,Mx,Mphi):
 records=[]
 for a in (1.,.5,.25,1/8,1/64):
  out={k:0. for k in ('psi_mass','phi_mass','phi_second_moment','b_mass','ordinary_mass','b_variance','phi_fisher','phi_dilation_moment')}
  for lo,hi,h in ((-A,-.5,0.),(-.5,.5,1.),(.5,A,0.)):
   def values(x):
    p,dp=actual_phi(x,Mphi);psi=(1-a)*h+a*p;b=-a*psi-a*x*dp;ordinary=b-(1-a)*psi
    return dict(psi_mass=psi,phi_mass=p,phi_second_moment=x*x*p,b_mass=b,ordinary_mass=ordinary,b_variance=b*b/psi,phi_fisher=(p+x*dp)**2/p,phi_dilation_moment=x*x*dp*dp/p)
   # Equal panel counts within each smooth hard-state interval; endpoints use its side.
   for key in out:out[key]+=simpson(lambda x:values(x)[key],lo,hi,Mx)
  pA,_=actual_phi(A,Mphi)
  predicted=a*(1-a)*(out['phi_mass']-1)-2*a*A*pA
  out.update(a=a,domain_halfwidth=A,x_panels_per_piece=Mx,phi_panels=Mphi,finite_domain_b_mass_prediction=predicted,b_mass_identity_residual=out['b_mass']-predicted,full_domain_b_variance_upper=(10/3)*a-a*a,full_domain_phi_fisher_upper=7/3,full_domain_phi_dilation_moment_upper=10/3,full_domain_phi_second_moment=13/12,finite_domain_b_mass_tail_bound=a*((1-a)+2*A)*math.exp(.5-A),scope='Actual E2 numerical dx integrals on a finite interval; analytic full-domain bounds supplied by theory, not certified quadrature.')
  records.append(out)
 return records

def stage1():
 coarse=one_dim(12.,512,128);fine=one_dim(12.,1024,256);records=[]
 for c,f in zip(coarse,fine):
  f['refinement_differences']={k:abs(f[k]-c[k]) for k in ('psi_mass','phi_mass','phi_second_moment','b_mass','ordinary_mass','b_variance','phi_fisher','phi_dilation_moment')}
  # Loose regression checks only; no certified error claim.
  assert f['b_variance']<=f['full_domain_b_variance_upper']+1e-3
  assert f['phi_fisher']<=7/3+1e-3
  records.append(f)
 return dict(status='PASS',records=records,scope='Continuous actual E2 quadrature diagnostic; hard faces split before dx integration.')

def source(name,n,sites,weights,delta):
 return dict(name=name,n=n,sites=[tuple(map(Q,y)) for y in sites],weights=list(map(Q,weights)),delta=Q(delta),W=sum(abs(Q(w)) for w in weights))

def fixtures():
 return [source('signed_pair_n1',1,[(-Q(1,4),),(Q(1,4),)],[1,-1],Q(1,2)),source('signed_square_n2',2,list(itertools.product((-Q(1,4),Q(1,4)),repeat=2)),[1,-1,-1,1],Q(1,2)),source('correlated_signed_n4',4,[(-Q(3,4),)*4,(-Q(1,4),)*4,(Q(1,4),)*4,(Q(3,4),)*4],[1,-2,3,-1],Q(1,4))]

def endpoint(src,x,L,a,hstates=None,side='closed',M=128):
 n=src['n'];tot=[0.,0.,0.]
 for idx,(y,w) in enumerate(zip(src['sites'],src['weights'])):
  z=[float(x[i]-y[i])/float(L) for i in range(n)]
  h=[float(2*abs(x[i]-y[i])<L if side=='left' else 2*abs(x[i]-y[i])<=L) for i in range(n)] if hstates is None else hstates[idx]
  pp=[actual_phi(v,M) for v in z];psi=[(1-a)*h[i]+a*pp[i][0] for i in range(n)]
  prod=math.prod(psi);sc=sum((-a-a*z[i]*pp[i][1]/psi[i]) for i in range(n));factor=float(w)/float(L)**n
  B=factor*prod*sc;drift=-n*(1-a)*factor*prod
  tot[0]+=factor*prod;tot[1]+=B;tot[2]+=drift
 return tot # actual Psi convolution, centered B convolution, negative drift

def fields(src,x,L,hstates=None,side='closed',M=128):
 d=float(src['delta']);a=endpoint(src,x,L,d/2,hstates,side,M);b=endpoint(src,x,L,d,hstates,side,M)
 return dict(D=a[0]-b[0],B=a[1]-b[1],drift=a[2]-b[2],ordinary=a[1]-b[1]+a[2]-b[2])

def breaks(src,x):
 return sorted(set(2*abs(x[i]-y[i]) for y in src['sites'] for i in range(src['n']) if Q(1)<2*abs(x[i]-y[i])<=Q(2)))

def ode_integral(src,x,scale_panels,phi_panels):
 jumps=[];bp=breaks(src,x);left=Q(1);B=drift=0.
 for right in sorted(set(bp+[Q(2)])):
  midpoint=(left+right)/2;hstates=[[float(2*abs(x[i]-y[i])<midpoint) for i in range(src['n'])] for y in src['sites']]
  if right>left:
   def integrand(s,key):return fields(src,x,math.exp(s),hstates,M=phi_panels)[key]
   B+=simpson(lambda s:integrand(s,'B'),math.log(float(left)),math.log(float(right)),scale_panels)
   drift+=simpson(lambda s:integrand(s,'drift'),math.log(float(left)),math.log(float(right)),scale_panels)
  if right in bp:
   before=fields(src,x,right,side='left',M=phi_panels)['D'];after=fields(src,x,right,M=phi_panels)['D'];multiplicity=sum(2*abs(x[i]-y[i])==right for y in src['sites'] for i in range(src['n']))
   jumps.append(dict(L=right,multiplicity=multiplicity,D_left=before,D_right=after,signed_jump=after-before))
  left=right
 start=fields(src,x,Q(1),M=phi_panels)['D'];end=fields(src,x,Q(2),M=phi_panels)['D'];J=sum(j['signed_jump'] for j in jumps);res=end-start-B-drift-J
 return dict(x=x,D1=start,D2=end,endpoint_difference=end-start,centered_B_integral=B,negative_drift_integral=drift,continuous_integral=B+drift,signed_jump_sum=J,jumps=jumps,breakpoints=bp,residual=res,scale_panels=scale_panels,phi_panels=phi_panels)

def point_receivers(src):
 n=src['n'];points=[(Q(0),)*n,(Q(3,4),)*n,(Q(5,4),)*n,(Q(7,4),)*n]
 rng=random.Random(SEED+n)
 for _ in range(4):points.append(tuple(Q(rng.randrange(-40,41),17) for i in range(n)))
 return list(dict.fromkeys(points))

def stage2():
 rows=[];dx=[];count=ties=0
 for src in fixtures():
  for x in point_receivers(src):
   c=ode_integral(src,x,16,64);f=ode_integral(src,x,32,128);count+=1;ties+=sum(j['multiplicity']>1 for j in f['jumps'])
   f['source']=src;f['joint_refinement_difference']=abs(f['endpoint_difference']-c['endpoint_difference'])+abs(f['centered_B_integral']-c['centered_B_integral'])+abs(f['negative_drift_integral']-c['negative_drift_integral'])+abs(f['signed_jump_sum']-c['signed_jump_sum'])
   f['coarse_residual']=c['residual'];assert abs(f['residual'])<2e-4;rows.append(f)
  if src['n']<=2:
   n=src['n'];M=32 if n==1 else 8;half=Q(2);step=2*half/M;weight=float(step**n);tot={k:0. for k in ('endpoint_difference','centered_B_integral','negative_drift_integral','signed_jump_sum','residual')};absres=0.;points=0;absolute={k:0. for k in tot if k!='residual'}
   for indices in itertools.product(range(M),repeat=n):
    x=tuple(-half+(Q(i)+Q(1,2))*step for i in indices);r=ode_integral(src,x,24,96)
    for key in tot:tot[key]+=weight*r[key]
    for key in absolute:absolute[key]+=weight*abs(r[key])
    absres+=weight*abs(r['residual']);points+=1
   dx.append(dict(source=src,domain='[-2,2]^n',dx_rule='fixed Cartesian midpoint cubature, original physical x',nodes=points,node_volume_weight=weight,signed_integrals=tot,absolute_integrals=absolute,integral_absolute_residual=absres,scope='Finite dx cubature of actual physical-scale fundamental theorem; not a certified spatial integral.'))
 return dict(status='PASS',point_rows=rows,point_count=count,tied_jump_events=ties,dx_cubature=dx,scope='Untruncated actual E2 signed-source endpoint identity, all physical hard-face breakpoints, direct complete-tie jumps. Phi/log-scale integrals diagnostic.')

def stats(values):
 n=len(values);mean=sum(values)/n;se=math.sqrt(sum((v-mean)**2 for v in values)/(n*(n-1)))
 return dict(mean=mean,SE=se,samples=n)

def draw_psi(a,n,rng):
 x=[]
 for _ in range(n):
  v=rng.random()-.5
  if rng.random()<a:
   t=math.sqrt(rng.random());u=max(rng.random(),2**-53);v+=(1 if rng.random()<.5 else -1)*t*(-math.log(u))
  x.append(v)
 return x

def product_scores(x,a,b,M=64):
 pp=[actual_phi(v,M) for v in x];logs=[];sums=[]
 for c in (a,b):
  psi=[(1-c)*float(abs(v)<=.5)+c*p[0] for v,p in zip(x,pp)]
  logs.append(sum(math.log(z) for z in psi));sums.append(sum(-c-c*v*p[1]/z for v,p,z in zip(x,pp,psi)))
 peak=max(logs);logq=peak+math.log((math.exp(logs[0]-peak)+math.exp(logs[1]-peak))/2);r=[math.exp(z-logq) for z in logs]
 return r,sums

def pressure_case(n,delta,seed,S=512):
 rng=random.Random(seed);a,b=delta/2,delta;B=[];ordinary=[];drift=[];refinement=0.;maxcoord=0.
 for j in range(S):
  x=draw_psi(a if rng.random()<.5 else b,n,rng);maxcoord=max(maxcoord,max(abs(v) for v in x));r,s=product_scores(x,a,b)
  score=r[0]*s[0]-r[1]*s[1];d=-n*(1-a)*r[0]+n*(1-b)*r[1];B.append(score);drift.append(d);ordinary.append(score+d)
  if j<4:
   rr,ss=product_scores(x,a,b,128);refinement=max(refinement,abs(score-(rr[0]*ss[0]-rr[1]*ss[1])))
 bound=math.sqrt(n*((10/3)*a-a*a))+math.sqrt(n*((10/3)*b-b*b))
 return dict(n=n,delta=delta,seed=seed,samples=S,proposal='actual endpoint product mixture (Psi_delta/2 + Psi_delta)/2; x remains physical kernel coordinate, density ratio computed by log-sum-exp',centered_B_mass=stats(B),centered_B_L1=stats([abs(v) for v in B]),ordinary_continuous_mass=stats(ordinary),ordinary_continuous_L1=stats([abs(v) for v in ordinary]),negative_drift_mass=stats(drift),negative_drift_L1=stats([abs(v) for v in drift]),analytic_centered_mass=0,analytic_ordinary_mass=-n*delta/2,analytic_negative_drift_mass=-n*delta/2,analytic_total_face_mass=n*delta/2,centered_contrast_L1_upper=bound,max_abs_coordinate=maxcoord,first_four_score_refinement_max=refinement,scope='Actual Psi-mixture iid integral estimates; ordinary sample SE, finite RNG/phi evaluation diagnostic, no certified integration/rate. No source-count change or fitted order.')

def stage3():
 out=[]
 for n in (1,2,4,8,16,32,64):
  for delta in sorted(set((1/n,.5))):
   seed=783000+100*n+int(delta*100);out.append(dict(n=n,delta=delta,batches=[pressure_case(n,delta,seed+j) for j in range(2)]))
 return dict(status='PASS',cases=out,dimensions=[1,2,4,8,16,32,64],samples_per_batch=512,scope='Two independent actual-kernel mixture batches per dimension/softness case; estimates not certified continuous bounds.')

def main():
 start=time.monotonic();print('STAGE1 actual coordinate score',flush=True);a=stage1();print('STAGE2 physical signed face flux',flush=True);b=stage2();print('STAGE3 product-mixture pressure',flush=True);c=stage3()
 out=dict(status='PASS',seed=SEED,stage1=a,stage2=b,stage3=c,definitions=dict(psi='(1-a)h+a phi',b='-a psi-a u phi_prime',B='sum_j b_j product_{k!=j} psi_k',ordinary_derivative='B-n(1-a)Psi',contrast='Psi_delta/2-Psi_delta',physical_window=[1,2],breakpoints='L=2|x_j-y_j|; start L1 closed, include jumps in (1,2], ties use full product left/right difference'),scope='Actual untruncated E2 diagnostics; exact rational source/breakpoint geometry, no certified phi/log-scale/spatial quadrature or fitted dimension order.')
 path=Path(__file__).with_name('flux_results.json');path.write_text(json.dumps(clean(out),sort_keys=True,separators=(',',':'))+'\n');print('PASS elapsed',time.monotonic()-start,'sha256',hashlib.sha256(path.read_bytes()).hexdigest())
if __name__=='__main__':main()
