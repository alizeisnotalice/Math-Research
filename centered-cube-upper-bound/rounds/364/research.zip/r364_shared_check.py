from fractions import Fraction as F
from itertools import product
from pathlib import Path
import json
centres=[(F(-1,4),F(-1,4)),(F(1,4),F(-1,4)),(F(-1,4),F(1,4)),(F(1,4),F(1,4))]
radii=[F(1),F(3,2)];dx=F(1,4)
cuts=sorted({x+s*r/2 for c in centres for x in c for r in radii for s in [-1,1]})
cells=[]
for a,b in zip(cuts,cuts[1:]):
 for c,d in zip(cuts,cuts[1:]):cells.append(((a+b)/2,(c+d)/2,(b-a)*(d-c)))
f=[z[2] for z in cells];W=sum(f);nz=len(f)
inc={};checks=0
for u,c in enumerate(centres):
 for v,r in enumerate(radii):
  inc[u,v]=[int(abs(z[0]-c[0])<r/2 and abs(z[1]-c[1])<r/2) for z in cells]
  assert sum(f[z]*inc[u,v][z] for z in range(nz))==r*r;checks+=1
params=list(product([F(1,8),F(1,4),F(1,2)],[F(1,4),F(1,2),F(3,4)]))
rows=[]
for nr in [2,3,4]:
 best={p:F(0) for p in params};witness={p:None for p in params};outer={p:[[F(0)]*nz for _ in range(nz)] for p in params}
 config_count=0
 for cfg in product([-1,0,1],repeat=nr):
  config_count+=1
  active=[(u,v) for u,v in enumerate(cfg) if v>=0]
  X=len(active)*dx
  mats=[]
  for level in [0,1]:
   A=[[F(0)]*nz for _ in range(nz)]
   for u,v in active:
    if v>level:continue
    indices=[z for z in range(nz) if inc[u,v][z]]
    weight=dx/radii[v]**2
    for y in indices:
     for z in indices:A[y][z]+=weight
   mats.append(A)
  ew=[F(5,9),F(4,9)]
  full=sum(ew[j]*sum(f[y]*f[z]*mats[j][y][z] for y in range(nz) for z in range(nz)) for j in range(2))
  assert full==X;checks+=1
  for H,delta in params:
   p=(H,delta);total=F(0)
   for y in range(nz):
    for z in range(nz):
     val=F(0)
     for j,A in enumerate(mats):
      J=A[y][y]
      if J>=H and A[y][z]<=delta*J:val+=ew[j]*A[y][z]
     total+=f[y]*f[z]*val
     if val>outer[p][y][z]:outer[p][y][z]=val
   assert 0<=total<=X;checks+=1
   if total>best[p]:best[p]=total;witness[p]=cfg
 for p in params:
  ob=sum(f[y]*f[z]*outer[p][y][z] for y in range(nz) for z in range(nz))
  assert ob>=best[p];checks+=1
  rows.append(dict(receivers=nr,configurations=config_count,H=str(p[0]),delta=str(p[1]),shared_max=str(best[p]),witness=witness[p],pairwise_relaxation=str(ob),gap=str(ob-best[p]),ratio=None if not best[p] else str(ob/best[p])))
out=dict(scope='Exact source cells for uniform f on [-1,1]^2 and actual cubes; receivers are weighted quadrature, not continuum E. Low-capture gate p<=delta is an algebraic diagnostic motivated by R363; geometric Far is not computed and its continuum envelope is not asserted in this quadrature model. Complete shared-radius enumeration includes inactive choice. No native high-past or root-exponent claim.',checks=checks,source_cells=nz,W=str(W),rows=rows)
(Path(__file__).resolve().parent / 'r364_shared_result.json').write_text(json.dumps(out,indent=2)+'\n')
print('PASS',checks,'checks',nz,'source cells')
for row in rows:
 if row['H']=='1/8':print(row)
