# R364 independent audit — preliminary proof review

Status: FINAL PASS for the direct joint low-row receipt, stopped-clock kernel, finite shared-selector diagnostic and final integration. Only this audit file is reviewer-owned. No general root-order bound or fresh historical reduction audit is claimed. Final bindings refer to the bytes reviewed below.

## Independent proposition screen
In the frozen matched-hard contract, BOTH original sources are f, m_u=f(Q_u)=q_u R_u^n, q_->0, alpha=1,s=0,L=R, dmu=du/m_u and the actual receiver measure is Lebesgue du. At every SAME original physical r, g_r=f 1{J_r>=H}, l_r=f-g_r and t_r(u)=g_r(Q_u)/m_u. Equality J=H is high. This is neither a terminal high-past set nor a source posterior conditional on Far.

The original far positive first moment splits positively into HL, HH noncore (t<=3/4), and HH core (t>3/4), retaining Far in each exact subtraffic. Dropping Far only for upper bounds, the first two have a JOINT fixed-(r,u) coefficient m[t(1-t)+t^2 1{t<=3/4}]<=3m(1-t). When t<=3/4 the left bracket is t, not two independently charged terms; on the complement it is t(1-t). Thus the two discarded pieces share ONE low-J first-moment budget.

For each source z, positive Tonelli bounds integral ell 1{J_r(z)<H}V_r(z) by integral c_u(z)q_u 1{J_(R_u)(z)<H}dmu(u)<=lambda H. The strict inclusive low gate excludes any entire radius atom crossing H; continuous approach/equality and R=a,b do not add overshoot. Consequently Ffar<=Ffar_core+3lambda H W and B_H<=Bnear+Ffar_core+3lambda H W, using the R363 original-square positive decomposition. In the stated original entrance 8lambda H W+...+2B_H this changes that coefficient to 14, not 11 or 16; the outer Lambda still applies. No new X_q absorption fee. This is a fresh alternative analysis of original B_H and cannot be stacked with the already paid path decomposition or a second use of its square. Both Bnear and the two-high-source, high-receiver-t far core remain unpaid in general.

## Stopped physical clock
For the inclusive finite-band cumulative J, tau_y=inf{J>=H} has high clocks [tau_y,b] when nonempty; right continuity includes crossing atoms. Far threshold r log_+(A_n(r)/(delta q_-H)) is continuous nondecreasing, so its clock set is an initial CLOSED interval [a,T] or empty. For R<=T and tau<=T the exact tail is max(R,tau)^(-n)-chi T^(-n), chi=1{T<b}; otherwise zero. Thus tau=T<b has zero continuous-clock mass while tau=T=b retains b^(-n). No private receiver choice or restart occurs at tau.

With phi(t)=t^(-n)[max(t,tau)^(-n)-chi T^(-n)], the actual receiver integrand is at most phi(s(u))/q_-, s(u)=max(a,2||u-y||inf,2||u-z||inf), because phi is nonnegative nonincreasing. The sublevel center volume is V_t=product(t-|y_i-z_i|)_+. Stieltjes integration by parts phi(T)V_T-integral_a^T V_t phi'(t)dt gives author formula(6). Its a base mass is included implicitly, not lost. The terminal term is (1-chi)V_T/T^(2n); the first integral coefficient tau^-n-chi T^-n is nonnegative; the second integrand coefficient 2/t^(2n+1)-chi T^-n/t^(n+1) is nonnegative for t<=T. Substitution of the distance exponential preserves the upper-bound direction. Endpoint tau=a, tau=T and r=a are valid.

Dropping all stops/endpoints yields the homogeneous product kernel and bound 2n!/(q_-||y-z||1^n) for y!=z. Its singular diagonal and factorial cannot be hidden or integrated as a source-linear/root budget. The finite stopped kernel is the pertinent conditional estimate. The late-tau window in(9) is an elementary existing first-moment envelope, explicitly not entered as a new payment.

## Author/code review and numerical scope
Read /tmp/r364_astra.md, /tmp/r364_clock.md, /tmp/r364_shared_check.py and its result JSON in full. They agree with the above. The shared finite model has uniform f on [-1,1]^2, exact 49 source face cells, true cube captures and matched masses q=1 for each chosen radius, but receiver weights dx=1/4 at only 2/3/4 centers are QUADRATURE, not real continuum E. The shared global configuration includes an inactive choice and two radii. Its p<=delta gate is a low-capture algebraic diagnostic, not the actual physical-distance Far predicate. Taking the source-pair maximum separately is an outer relaxation and may violate the common selector; observed gap does not certify an original high-past realization or a root upper bound.

Result JSON records 1205 exact Fraction assertions and 27 parameter rows; parent reports a fresh successful full run of the final shared script. The final main/numeric notes report a separate actual fresh run of all 504 stopped-clock checks. Astra reports 15450 initial plus 20600 sharpened scalar Fraction checks, not actual geometry. Clock author reports 504 checks: 336 clock-tail and 84 monotonicity exact rational; 84 integral comparisons use 65-digit Decimal log evaluations with tolerance, not interval arithmetic. No full pipeline was repeated by the reviewer. A separate reviewer-local Python run actually passed 53 narrow Fraction endpoint and joint-coefficient checks; this is scalar interface evidence only and is excluded from parent/author totals.

## Final main/ledger/numeric/readme review
Read /tmp/r364_main.md, /tmp/r364_ledger.md, /tmp/r364_numeric.md and /tmp/r364_readme.md in full, and re-read the final shared script with its relative-to-script output path. PASS without a substantive correction request. The script model, threshold equalities, inactive radius option, exact source-cell areas and result scope match the notes. The archived JSON's scope/results are consistent with the final code; no numerical pipeline was needlessly rerun by the reviewer.

The main retains delta=1/4 Far/Near, the original high-J normalization, the shared same-r g_r predicate and explicit A expansion before imposing receiver t>3/4. The alternative original entrance is correctly 14lambda H W+2d_eff A_n W_nu/H+2Bnear+2Fcore, all then multiplied by Lambda=128/119. No extra X_q term is inserted. The new fee is only root order when the original permitted lambda H is root order; H is not reselected without its other original costs. The unresolved Bnear and Fcore are explicit. The stopped envelope, its homogeneous singular limit and finite common-radius relaxation are not treated as source-linear receipts.

The full R363/R362 path ledger is retained as an ALTERNATIVE history, explicitly not appended to the new direct bound. Old entrance, outer factors, D-count head, initial-rank W_ex fee, recomputed direction and unfinished F_(>L,deep), conditional same-X CZ absorption and all soft/time/scale/exterior complements are preserved. Its LaTeX W_\nu has no embedded newline or broken control word. The original square is spent only in the direct R363 Near/Far positive decomposition and is not also charged as old-path credit. Any future epsilon bounds for the two unpriced direct terms would contribute 2Lambda(epsilon1+epsilon2), and are correctly not inserted now.

Evidence in final reporting: parent actually reran 1205 Fraction shared-selection assertions and 504 stopped-clock checks (420 Fraction tail/monotonicity and 84 65-digit Decimal integral comparisons). Ordinary Decimal is not an interval certificate. Astra's 15450+20600 exact scalar runs are AUTHOR-reported and were not independently rerun by the parent; reviewer 53 narrow Fraction checks remain separate. Exact source integration in the finite model does not turn receiver quadrature into real positive-volume dx; p<=delta does not certify geometric Far, high-past, or other original difficult gates. The example ratio267/113 concerns max over a common finite selector versus a source-pair-dependent relaxation only, not a continuum dimension exponent.

No full historical re-audit, literature/PDF-reading claim, TeX compilation, ZIP contents/integrity or Git state is certified here. General weak-type/root closure and all stated unpriced complements remain open.

## Final SHA256 bindings

- `/tmp/r364_main.md` — `6f8fffd3e2172a8e20f5f27e2f6a49fa8739acfc14850e7b27a94da276dc083e`

- `/tmp/r364_ledger.md` — `4ce56ef26d9860b64bcfc119c8d9fbfcd595d00fa3badedd44ed8b6a7a450482`

- `/tmp/r364_numeric.md` — `248cfde5b77c22e1988ab665fea354e3b93f1915523c9ef838e31aad83ddaf53`

- `/tmp/r364_readme.md` — `a3412dc3a1701a63d4707ea94afe13de8fe1f941b54a8aefc54ab1bde4554a45`

- `/tmp/r364_astra.md` — `125e328405ec194f2ec7f009f2f166da8429db851db9e46b48566ec0283946c4`

- `/tmp/r364_clock.md` — `30d76a5d96e0dd1dba8aca103dc6f63994530643455c10bfeb404d2d1dc0ee73`

- `/tmp/r364_shared_check.py` — `85971aa34bdff288b0c075197ae3c2ac994130b43fa2c774af4fc1526ca67f98`

- `/tmp/r364_shared_result.json` — `b01da6db745260f4a6ab5adda81f495611b2f939c0f0832daecd5e212d9b0a6d`

- `/tmp/r363_audit.md` — `8ebe106b035a2149a8036986a42bd5a61a2a564ca0954501db81ef651dfe0b10`

- `/tmp/r363_variance.md` — `cb6fca2f3ac79aa316e44be4e8f31ad14598be2bf9e8ccb94dcb1c9e9c26cdb5`

- `/tmp/r363_ledger.md` — `951c3fd22ffe368788e29444c70b4e273d0162d5513e3b254eb335eb38d7783d`
