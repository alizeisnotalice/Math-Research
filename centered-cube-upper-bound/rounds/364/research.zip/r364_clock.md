# R364 — Source-pair clock fusion with the original high-row stopping time

## Scope and outcome

Use precisely the full-f hard matching contract of R363 and R337: real receiver du, mu(du)=du/m_u, m_u=q_u R_u^n, q_-<=q_u<=lambda, a<=R_u<=b<=2a, and the unchanged ell=b^(-n)delta_b+n r^(-n-1)dr. No source density bound is assumed.

R363 named the far negative credit E_far but did not separately name its positive first moment. Here F_far means the stronger positive quantity

    F_far=integral ell(dr) integral f(y)f(z)
             1_{J_y(r)>=H} A_r(y,z)1_{Far_r}(y,z)dy dz,     (1)
    Far_r={||y-z||_1>=r log_+(A_n(r)/(delta q_-H))},
    A_n(r)=1+n log(r/a), 0<delta<1, H>0.

Thus the positive far variance with extra factor 1-A_r/J_y is also bounded by (1). The new result below is a clock-fused geometric upper kernel for (1), retaining the actual high-J first crossing and the far-distance upper clock cutoff. It does not prove the requested root bound for F_far; no W^2 estimate is used or offered as a source budget.

## 1. Exact clock fusion, before a receiver extension

Let

    tau_y=inf{r in[a,b]:J_y(r)>=H},

with tau_y=infinity if the set is empty. Since J is the inclusive cumulative measure of the actual radius selector, it is right continuous, and its high set, when nonempty, is [tau_y,b]. Crossing atoms and an equality crossing are included. Nothing is restarted at tau_y.

The distance threshold defining Far_r is continuous and nondecreasing. For each source pair its accepted clocks form an initial closed interval [a,T_yz], possibly empty or all of [a,b]. This definition handles a zero plateau of the logarithm; T_yz is the last accepted clock, not a privately chosen receiver radius.

Fix a nonempty pair with tau=tau_y<=T=T_yz. For R<=T put

    L_(tau,T)(R)=max(R,tau)^(-n)-chi T^(-n),
    chi=1 if T<b, and chi=0 if T=b.                       (2)

Set L=0 if R>T. The exact inclusive clock identity is

    integral ell(dr)1_{r>=R}1_{r>=tau}1_{r<=T}
       =L_(tau,T)(R).                                    (3)

When T<b the continuous interval has no atom at its upper endpoint. When T=b the original b atom cancels the subtraction. In particular tau=T=b still has a nonzero atom; tau=T<b has zero clock mass.

Positive Tonelli now gives the EXACT original receiver expression

    F_far=integral f(y)f(z) K_actual(y,z)dy dz,
    K_actual=integral_E c_u(y)c_u(z)
                       L_(tau_y,T_yz)(R_u) du/m_u.        (4)

All physical times have been integrated, while the original tau_y, actual m_u and actual common capture remain. Formula (4) is not a bound by two independent source masses.

## 2. A stopped geometric kernel with both source distances

Put d_i=|y_i-z_i|, d_infty=max_i d_i, and

    V_t=product_i(t-d_i)_+,
    phi_(tau,T)(t)=t^(-n)[max(t,tau)^(-n)-chi T^(-n)]
                    for a<=t<=T, and zero for t>T.

On [a,T], phi is nonnegative and nonincreasing, continuous at tau. It vanishes at T if T<b. Since any center capturing both points has actual radius at least

    s(u)=max(a,2||u-y||_infinity,2||u-z||_infinity),

matching gives the REAL CENTER inequality

    K_actual(y,z)<=K_env(y,z)
       :=q_-^(-1) integral_{s(u)<=T}phi_(tau,T)(s(u))du.    (5)

The level-volume of s is V_t. Stieltjes integration by parts yields the explicit formula

    q_- K_env = (1-chi)V_T/T^(2n)
       +n(tau^(-n)-chi T^(-n)) integral_a^tau V_t/t^(n+1)dt
       +n integral_tau^T V_t[2/t^(2n+1)
                                  -chi T^(-n)/t^(n+1)]dt. (6)

Take K_env=0 if tau>T, the far interval is empty, or tau=infinity. Formula (6) includes the zero-overlap region t<d_infty automatically. It retains the physical upper atom through its first term. The endpoint tau=T is allowed, with the conventions just explained.

For T=b this simplifies to

    q_- K_env = V_b/b^(2n)
       +n tau^(-n) integral_a^tau V_t/t^(n+1)dt
       +2n integral_tau^b V_t/t^(2n+1)dt.                 (7)

Thus the stopping time has not been replaced by a fixed H denominator or discarded from the clock. Formula (6) is the simultaneous integration of the joint minimal radius t>=d_infty and the clock. It is stronger than dropping either tau or the far upper cutoff.

The product also keeps the ell^1 separation:

    V_t/t^n<=exp(-||y-z||_1/t).

Because each coefficient in (6) is nonnegative on its integration interval, this inequality may be substituted into (6) without changing its direction. One obtains explicit one-dimensional incomplete-gamma-type integrals with the SAME tau,T cutoffs. No product of source masses need be introduced.

## 3. Homogeneous kernel and the cost that remains

Dropping the stop, far cutoff and finite scale endpoints only for a further upper bound gives, for y!=z,

    K_actual(y,z)<=K_env(y,z)<=K_hom(y-z),
    K_hom(d)=(2n/q_-) integral_(d_infty)^infinity
                    t^(-n-1) product_i(1-d_i/t)_+ dt
             <=2 n!/[q_- ||d||_1^n].                     (8)

This follows from the same real-center envelope with phi(t)=t^(-2n), followed by the substitution v=||d||_1/t in the exponential estimate. The exact product integral in (8) is homogeneous of degree -n and involves no a or b. Its displayed factorial cannot be absorbed into an unspecified dimension-independent constant. At d=0 the homogeneous bound is infinite, although the original stopped finite-scale kernel is finite.

Equation (8) answers the narrow kernel question affirmatively: clock fusion does produce a scale-independent source-pair kernel. It does NOT answer the source-budget question. Integrating this homogeneous majorant against f(y)f(z) would lose the actual matching constraints and may diverge even for bounded compactly supported positive f, owing to its degree -n diagonal singularity. We therefore do not use that integral as an estimate for (1). The stronger stopped kernel (6) is the relevant finite expression.

As a baseline check, the entire high-row first moment on sources with tau_y>=t0 is bounded by

    [1+n log(b/t0)] integral_{tau_y>=t0}f(y)dy,
       a<=t0<=b.                                         (9)

Indeed M_y(r)=V_y(r)=integral_(E_r)c_u(y)du<=r^n, and the original clock above t0 gives the displayed coefficient, including its b atom. For t0>=b exp(-1/sqrt(n)), (9) is a root-order source price. This late-crossing window is an elementary existing receiver-envelope branch, not claimed as a new general payment. The early-crossing complement remains.

The unresolved step is a SOURCE-LINEAR estimate for the finite stopped pair functional on the right of (4)–(6), using that the SAME f sets every m_u and tau_y. The pointwise center envelope alone has forgotten the accepted receivers' individual f-averages. Replacing those constraints by q_- globally leaves a quadratic source functional; no argument here converts it to epsilon X_q+C_epsilon sqrt(n) polylog(n)W. Thus there is a stronger geometry-and-clock bound, but no new global root receipt or charge to the main ledger. Any eventual use must retain the old far credit, all other source fees and exterior factors exactly once.

## 4. Local checks

The embedded script independently evaluates (6) and the direct Stieltjes volume integral of phi, with crossing endpoints and the terminal atom. It checks monotonicity of phi and the exact clock tail. It is a formula-interface verification, not a claimed full-field numerical proof of a source-linear estimate.

~~~python
from fractions import Fraction as F
from decimal import Decimal,getcontext
getcontext().prec=65
counts={'stieltjes':0,'clock_tail':0,'monotone':0}
def ck(x,k):
    assert x,k
    counts[k]+=1
def D(x):return Decimal(x.numerator)/Decimal(x.denominator)
def integ(power,l,r):
    if r<=l:return Decimal(0)
    if power==-1:return (D(r)/D(l)).ln()
    p=power+1
    return D((r**p-l**p)/p)
def sym(ds):
    e=[F(1)]
    for x in ds:
        e.append(F(0))
        for k in range(len(e)-1,0,-1):e[k]+=x*e[k-1]
    return e
def volume(t,ds):
    v=F(1)
    for d in ds:v*=max(F(0),t-d)
    return v
def phi(t,tau,T,chi,n):
    return t**(-n)*(max(t,tau)**(-n)-chi*T**(-n)) if t<=T else F(0)
for n in range(1,8):
  for seed in range(1,13):
    a=F(1);b=F(2);T=F(3,2) if seed%2 else b
    chi=int(T<b);tau=a+(T-a)*F(seed%5,4)
    ds=[F((seed*(i+2)+i)%13,10) for i in range(n)]
    e=sym(ds);low=max([a]+ds)
    env=direct=Decimal(0)
    if low<=T:
      # Integration by parts: formula (6).
      env=D((1-chi)*volume(T,ds)*T**(-2*n))
      for k,x in enumerate(e):
        coef=D((-1)**k*x)
        env+=coef*Decimal(n)*D(tau**(-n)-chi*T**(-n))*integ(-k-1,low,tau)
        env+=coef*(Decimal(2*n)*integ(-n-k-1,max(low,tau),T)
                    -Decimal(n)*D(chi*T**(-n))*integ(-k-1,max(low,tau),T))
      # Base atom plus integral phi(t) V'(t)dt, evaluated independently.
      direct=D(volume(a,ds)*phi(a,tau,T,chi,n))
      for k,x in enumerate(e):
        coef=D((-1)**k*x*(n-k))
        direct+=coef*D(tau**(-n)-chi*T**(-n))*integ(-k-1,low,tau)
        direct+=coef*(integ(-n-k-1,max(low,tau),T)
                       -D(chi*T**(-n))*integ(-k-1,max(low,tau),T))
    ck(abs(env-direct)<Decimal('1e-52'),'stieltjes')
    vals=[phi(a+(T-a)*F(j,30),tau,T,chi,n) for j in range(31)]
    ck(all(v>=w>=0 for v,w in zip(vals,vals[1:])),'monotone')
    for R in [a,tau,T,b]:
      start=max(R,tau)
      direct_tail=(start**(-n)-T**(-n)+int(T==b)*b**(-n)) if start<=T else F(0)
      formula=(start**(-n)-chi*T**(-n)) if R<=T else F(0)
      ck(direct_tail==formula,'clock_tail')
print('PASS stopped-clock checks',counts,'total',sum(counts.values()))
~~~


Actual local execution of the final embedded script returned:

~~~text
PASS stopped-clock checks {'stieltjes': 84, 'clock_tail': 336, 'monotone': 84} total 504
~~~

Clock-tail and monotonicity checks use exact rational arithmetic. Independent integral formulae are evaluated at 65-digit Decimal precision. These results verify the specified finite interfaces only; the continuum bound is the monotone-center and Stieltjes argument above.
