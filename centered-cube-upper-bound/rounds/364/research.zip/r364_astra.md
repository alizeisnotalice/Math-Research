# R364 — Direct far first-moment split by the second source and its actual receiver core

**Outcome.** A direct, exactly priced branch of F_far is identified below:

    F_far <= F_far,core(theta) + C_theta lambda H W,
    C_theta=max(1,(1-theta)/theta),  0<theta<1.                                             (0)

For theta=1/4 the fee is 3 lambda H W. The remaining core has both original sources high-J at the SAME original physical time, and more than 3/4 of the CURRENT real receiver's full-f mass lies on that high-J source set. This is an elementary matching/low-clock receipt, not a new geometric theorem and not a solution of the remaining core. Its source fee is root order only when the original chosen lambda H has that order. No threshold H or distance cutoff is changed. The old high-past reduction is not recalculated or called a new result.

## 1. Keep the original far integral and introduce a true same-time source split

Use exactly the task's E_r, mu=du/m_u, full f, J_r, H and original clock ell. Fix delta=1/4 and the already defined d_*(r). Write

    Far_r(y,z)=1_{||y-z||_1>=d_*(r)},
    g_r(y)=f(y)1_{J_r(y)>=H},
    l_r(y)=f(y)1_{J_r(y)<H}.

Equality belongs to g_r. For a real receiver u in E_r put

    t_r(u)=g_r(Q_u)/m_u in [0,1].                          (1)

This quantity uses the same r as J_r. It is not an inherited high-past condition, a property of later path states, or a posterior conditioned on far success.

Expand the actual receiver measure in A_r and split only the second source:

    F_far=F_HL,far+F_HH,far,
    F_HL,far=integral ell(dr) integral_(E_r)du/m_u
       integral g_r(y)l_r(z)c_u(y)c_u(z)Far_r(y,z)dy dz,
    F_HH,far=the same expression with g_r(z).              (2)

All terms remain positive and use real receiver Lebesgue measure.

## 2. One same-time low-source-row budget

Define the UNRESTRICTED source cross traffic

    C_HL=integral ell(dr) integral g_r(y)l_r(z)A_r(y,z)dy dz.

Matching both source integrals at each actual receiver gives the exact identity

    C_HL=integral ell(dr) integral_(E_r)
                   m_u t_r(u)(1-t_r(u))du.               (3)

By symmetry of A_r and positivity,

    C_HL
      <= L_low:=integral ell(dr) integral f(z)1_{J_r(z)<H}
                    V_r(z)dz
      =integral ell(dr) integral_(E_r)m_u(1-t_r(u))du
      <=lambda H W,                                     (4)

where V_r(z)=integral_(E_r)c_u(z)du. The last step is the already established original low-J clock lemma. For clarity, its entire endpoint argument is included here.

Fix z. Tonelli and the inclusive original tail ell([R_u,b])=R_u^(-n) give

    integral ell(dr)1_{J_r(z)<H}V_r(z)
      <= integral_E c_u(z)q_u 1_{J_(R_u)(z)<H}mu(du)
      <=lambda H.

Because J_r(z) is nondecreasing, the receivers satisfying the strict last gate occupy a cumulative mu mass at most H. A whole radius atom which crosses H is excluded by the strict inequality; it is not partially counted. Integrating against the unchanged f(z) proves (4). The ell atom b^(-n)delta_b is retained.

No additional source-density estimate is used. Equation (4) is one common low-source-row budget, used jointly below rather than separately charged for each positive subpiece. Retaining L_low instead of first replacing it by C_HL sharpens the combined coefficient.

## 3. Jointly pay the opposite-low source and non-core receiver pieces

Split F_HH,far by the actual receiver predicate

    Core_theta(r)={u in E_r:t_r(u)>1-theta}.

Let F_far,core(theta) be exactly its restriction to Core_theta. It is explicitly

    integral ell(dr) integral_(Core_theta(r))du/m_u
       integral g_r(y)g_r(z)c_u(y)c_u(z)Far_r(y,z)dy dz.   (5)

The complement is NOT hidden in a changed kernel. At fixed (r,u), dropping the far mask only as a positive upper bound gives

    HL_far(u)<=m_u t(1-t),
    HH_far(u)1_{t<=1-theta}<=m_u t^2 1_{t<=1-theta}.

For t in [0,1],

    t(1-t)+t^2 1_{t<=1-theta} <= C_theta(1-t).            (6)

On the non-core side the left side of (6) equals t and t/(1-t)<=(1-theta)/theta. On the core side it equals t(1-t)<=(1-t). This proves (6) also at t=0,1. Consequently the EXACT positive decomposition (2),(5) and the one budget (4) yield

    F_HL,far+F_HH,far,noncore <= C_theta L_low
                             <=C_theta lambda H W.

This proves (0). For theta=1/4, the retained current receiver satisfies g_r(Q_u)>3m_u/4 and the discarded combined branch costs at most 3lambda H W. There is no X_q absorption term. There is no independent second low-J charge.

If this split is used in a fresh original-B_H argument, insert this one fee there. It is not added on top of the legacy path ledger or an already charged version of the same low-clock source-row traffic.

## 4. What the direct matching calculation still does not pay

The retained integral (5) is still an actual positive far-source first moment. Both sources have J_r>=H, and their real common receiver is mostly supplied by such sources. The pair envelope from R363 gives p<=delta on far pairs, hence the original far negative term cannot cancel more than delta of (5). It does not bound (5) by a source budget.

The degree identity for this core is

    g_r(Q_u)=t_r(u)m_u,

not an upper bound on f at a source, not a bound on the physical volume of the high-J set, and not a bound on the mass of a thin source layer. In particular the joint pricing above cannot be repeated on Core_theta: its remaining second-source low-J mass is already small, precisely the condition that makes (6) ineffective for the retained t>1-theta part.

No adequate geometric estimate for (5) was obtained from high J and matching. The calculation supplies an honest direct branch receipt and a sharper stated remaining condition; it does not establish the requested general far budget or a general root weak-type estimate. It also does not claim a newly proved low-clock theorem. Work stops at this specific two-high-source, same-time receiver core.

## 5. Actual local calculation and reproduction

The initial weaker bound using C_HL/theta was checked in 15,450 exact Fraction cases. The sharper bound (6), using L_low directly, was then checked in a separate 20,600-case run. Neither run was a numerical search for geometric examples. Both executed snippets are preserved below.

Initial weaker check:

```python
from fractions import Fraction as F
count=0
for theta in [F(1,4),F(1,3),F(1,2)]:
  for den in range(1,101):
    for k in range(den+1):
      t=F(k,den)
      # maximum high-low far contribution is t(1-t), and maximum
      # high-high far contribution is t^2; the actual far restrictions
      # only reduce these positive terms.
      cross=t*(1-t)
      low_receiver=t*t if t<=1-theta else F(0)
      assert cross+low_receiver<=cross/theta
      count+=1
print('PASS',count,'exact joint high-low/core-slice inequalities')
```

Actual output:

```text
PASS 15450 exact joint high-low/core-slice inequalities
```

Sharpened check actually executed afterward:

```python
from fractions import Fraction as F
count=0
for theta in [F(1,4),F(1,3),F(1,2),F(3,4)]:
  C=max(F(1),(1-theta)/theta)
  for den in range(1,101):
    for k in range(den+1):
      t=F(k,den)
      discarded=t*(1-t)+(t*t if t<=1-theta else F(0))
      assert discarded<=C*(1-t)
      count+=1
print('PASS',count,'exact sharpened joint low-row inequalities')
```

Actual output:

```text
PASS 20600 exact sharpened joint low-row inequalities
```

These checks validate scalar algebra only. The continuum source/receiver matching and endpoint-clock argument are the analytic proof above. Only /tmp/r364_astra.md was written.
