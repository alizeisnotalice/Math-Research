#!/usr/bin/env python3
"""R232 finite common-survivor weighted-loss and same-posterior Gini checks."""
import argparse,hashlib,json
from fractions import Fraction as F
from pathlib import Path
import mpmath as mp
HERE=Path(__file__).resolve().parent
ETA=F(25,2**69)
def m(v):
 v=F(v);return mp.mpf(v.numerator)/v.denominator

def phi_levels(H,masses,costs,dps):
 with mp.workdps(dps):
  H=F(H);mu=list(map(F,masses));Fs=list(map(F,costs));assert H>0 and min(mu,default=0)>=0 and min(Fs,default=0)>=0
  levels=sorted(set([F(0)]+Fs));level_rows=[];phi=mp.mpf(0);layer=F(0)
  for a,b in zip(levels,levels[1:]):
   tail=sum((p for p,c in zip(mu,Fs) if c>(a+b)/2),F(0));layer+=(b-a)*tail;phi+=m(b-a)*mp.log1p(m(tail/H));level_rows.append({'from':str(a),'to':str(b),'tail_mass_exact':str(tail)})
  weighted=sum((p*c for p,c in zip(mu,Fs)),F(0));assert layer==weighted
  order=sorted(range(len(mu)),key=lambda i:(-Fs[i],i));cum=F(0);rearranged=mp.mpf(0);sortrows=[]
  for i in order:
   after=cum+mu[i];rearranged+=m(Fs[i])*mp.log1p(m(mu[i]/(H+cum)));sortrows.append({'atom_index':i,'cumulative_before':str(cum),'cumulative_after':str(after)});cum=after
  assert cum==sum(mu,F(0))
  Fmax=max(Fs,default=F(0));jensen=m(Fmax)*mp.log1p(m(weighted/(Fmax*H))) if Fmax else mp.mpf(0)
  maxcap=m(Fmax)*mp.log1p(m(cum/H));linear=m(weighted/H);tol=mp.mpf(10)**(-dps+8)*max(1,abs(phi),abs(jensen),abs(min(maxcap,linear)))
  assert abs(phi-rearranged)<=tol and phi<=jensen+tol and jensen<=min(maxcap,linear)+tol
  return {'Phi':mp.nstr(phi,32),'reordered_integral':mp.nstr(rearranged,32),'identity_abs_difference':mp.nstr(abs(phi-rearranged),16),'Jensen_bound':mp.nstr(jensen,32),'maxcap_bound':mp.nstr(maxcap,32),'linear_bound':mp.nstr(linear,32),'weighted_mass_exact':str(weighted),'sum_mu_exact':str(cum),'H_exact':str(H),'masses_exact':[str(v) for v in mu],'costs_exact':[str(v) for v in Fs],'levels':level_rows,'reordered_exact_mass_intervals':sortrows,'zero_cost_or_mass_branch':phi==0}

def cost_menu():
 patterns=[('zero_mass',['0','0'],['0','100']),('zero_cost',['1','2','0'],['0','0','0']),('same_cost',['1','2','5'],['3','3','3']),('mixed',['0','1','3','1/9'],['0','1','7','2']),('rare_high',['1','1e-30','2'],['1','1e12','0']),('split_cost',['7','1/100','1/999','0'],['1/4','2','11','11'])]
 return [{'stage':('initial' if H=='1' else 'stress' if H=='1/100' else 'expanded'),'name':name,'H':H,'masses':mu,'costs':Fs} for H in ('1','1/100','1e-80') for name,mu,Fs in patterns]

def weight_exact(atom,t):return F(atom['mass'])*mp_product_fraction(min(F(1),F(a)/t)**count for a,count in atom['thresholds'])
def mp_product_fraction(xs):
 z=F(1)
 for x in xs:z*=x
 return z

def clock_model(n,kind):
 S=[{'mass':'1','cost':'1','thresholds':[['3/5',n]]},{'mass':'2','cost':'3','thresholds':[['4/5',n]]}]
 E=[{'mass':'3','thresholds':[['11/20',n]],'delete':'3/4'},{'mass':'1/7','thresholds':[['19/20',n]],'delete':'17/20'}]
 if kind=='all_alive':
  for a in E:a['delete']=None
 elif kind=='same_weights':
  for a in S:a['thresholds']=[['3/4',n]];a['cost']='2'
  E=[]
 elif kind=='zero_loss':
  for a in S:a['thresholds']=[['5/4',n]]
 elif kind=='rare_high':S[1]['mass']='1e-30';S[1]['cost']='1e12'
 elif kind=='empty_S':S=[]
 return {'stage':('initial' if n==2 else 'stress' if n==16 else 'expanded'),'n':n,'kind':kind,'tau':'1/2','T':'1','persistent_sources':S,'outside_sources':E,'scope':'Finite positive product clocks with fixed S and complete current normalizer; not geometry/FULL.'}

def integrate_clock(c,dps):
 with mp.workdps(dps):
  S=c['persistent_sources'];E=c['outside_sources'];tau=F(c['tau']);T=F(c['T']);H=sum((weight_exact(a,T) for a in S),F(0));mu=[weight_exact(a,tau)-weight_exact(a,T) for a in S];cost=[F(a['cost']) for a in S]
  if not H:
   assert not S
   return {'H_exact':'0','mu_exact':[],'direct_integral':'0','Phi':'0','empty_S_zero_traffic_branch':True,'no_division_by_zero':True}
  bound=phi_levels(H,mu,cost,dps);knots=sorted(set([tau,T]+[F(a0) for a in S+E for a0,count in a['thresholds'] if tau<F(a0)<T]+[F(a['delete']) for a in E if a['delete'] and tau<F(a['delete'])<T]))
  def wt(a,t):return m(a['mass'])*mp.fprod(min(1,m(alpha)/t)**cnt for alpha,cnt in a['thresholds'])
  pieces=[];total=mp.mpf(0)
  for lo,hi in zip(knots,knots[1:]):
   mid=(lo+hi)/2;alive=E.copy();alive=[a for a in alive if not a['delete'] or mid<F(a['delete'])];scores=[sum(cnt for alpha,cnt in a['thresholds'] if F(alpha)<mid) for a in S]
   def integrand(u):
    t=mp.exp(u);ws=[wt(a,t) for a in S];e=sum(ws)+sum(wt(a,t) for a in alive)
    return sum(m(a['cost'])*k*w for a,k,w in zip(S,scores,ws))/e
   val=mp.quad(integrand,[mp.log(m(lo)),mp.log(m(hi))]);total+=val;pieces.append({'from_t':str(lo),'to_t':str(hi),'persistent_scores':scores,'alive_outside_count':len(alive),'integral':mp.nstr(val,32)})
  P=sum(m(F(row['to'])-F(row['from']))*mp.log1p(m(F(row['tail_mass_exact'])/H)) for row in bound['levels']);tol=mp.mpf('1e-29')*max(1,abs(P));assert total<=P+tol
  return {'H_exact':str(H),'mu_exact':[str(v) for v in mu],'direct_integral':mp.nstr(total,32),'Phi':bound['Phi'],'margin_Phi_minus_direct':mp.nstr(P-total,32),'same_weight_constant_cost_saturation':c['kind']=='same_weights','complete_current_normalizer':True,'fixed_persistent_S':True,'pieces':pieces,'Phi_cost_identity':bound,'scope':'Ordinary log-clock quadrature with all threshold/deletion endpoints split; not outward interval error certification.'}

def gini_menu():
 return [{'stage':('initial' if n<=16 else 'stress' if n==512 else 'expanded'),'n':n,'r':r,'pattern':p} for n in (2,16,512,10**20,10**24) for r in ('0','1/2','999999/1000000','1') for p in ('balanced_endpoints','rare_endpoints','three_scores')]

def gini(c,dps):
 with mp.workdps(dps):
  n=c['n'];r=F(c['r']);a=1-r
  if c['pattern']=='balanced_endpoints':scores=[F(0),F(n)];probs=[F(1,2),F(1,2)];extra=[F(0),F(0)]
  elif c['pattern']=='rare_endpoints':scores=[F(0),F(n)];probs=[F(99,100),F(1,100)];extra=[F(0),F(n,10)]
  else:scores=[F(0),F(n//3),F(n)];probs=[F(1,5),F(2,5),F(2,5)];extra=[F(0)]*3
  Delta=[a*k+z for k,z in zip(scores,extra)];assert sum(probs)==1 and all(d>=a*k for d,k in zip(Delta,scores))
  weights=[mp.exp(-m(ETA*d)) for d in Delta];lhs=sum(E*m(p*q*max(k-l,0)) for E,p,k in zip(weights,probs,scores) for q,l in zip(probs,scores));z=m(ETA*a*n)
  bound=-mp.expm1(-z)/(4*m(ETA*a)) if a else m(F(n,4));limit=m(F(n,4));assert lhs<=bound*(1+mp.mpf(10)**(-dps+8)) and bound<=limit*(1+mp.mpf(10)**(-dps+8))
  return {'scores_exact':[str(v) for v in scores],'probabilities_exact':[str(v) for v in probs],'Delta_exact':[str(v) for v in Delta],'eta_exact':str(ETA),'eta_n_one_minus_r':mp.nstr(z,32),'weighted_positive_pair':mp.nstr(lhs,32),'proposed_bound':mp.nstr(bound,32),'unweighted_limit_n_over_four':mp.nstr(limit,32),'bound_over_unweighted_limit':mp.nstr(bound/limit,32),'lhs_over_bound':mp.nstr(lhs/bound,32),'r_one_exact_limit_branch':a==0}

def precision_difference(a,b,key):
 with mp.workdps(70):
  diff=abs(mp.mpf(a[key])-mp.mpf(b[key]))/max(1,abs(mp.mpf(b[key])))
  assert diff<mp.mpf('1e-25')
  return mp.nstr(diff,16)

def main(output):
 costs=[];clocks=[];ginis=[]
 for c in cost_menu():
  lo=phi_levels(c['H'],c['masses'],c['costs'],40);hi=phi_levels(c['H'],c['masses'],c['costs'],70);costs.append({'configuration':c,'at_40dps':lo,'at_70dps':hi,'Phi_relative_precision_difference':precision_difference(lo,hi,'Phi')})
 for n in (2,16,512):
  for kind in ('all_alive','delete_outside','same_weights','zero_loss','rare_high','empty_S'):
   c=clock_model(n,kind);lo=integrate_clock(c,40);hi=integrate_clock(c,70)
   with mp.workdps(70):diff=abs(mp.mpf(lo['direct_integral'])-mp.mpf(hi['direct_integral']))/max(1,abs(mp.mpf(hi['direct_integral'])))
   assert diff<mp.mpf('1e-25');clocks.append({'configuration':c,'at_40dps':lo,'at_70dps':hi,'relative_precision_difference':mp.nstr(diff,16)})
 for c in gini_menu():
  lo=gini(c,40);hi=gini(c,70);ginis.append({'configuration':c,'at_40dps':lo,'at_70dps':hi,'bound_ratio_precision_difference':precision_difference(lo,hi,'bound_over_unweighted_limit'),'lhs_ratio_precision_difference':precision_difference(lo,hi,'lhs_over_bound')})
 with mp.workdps(70):
  summary={'cost_cases':len(costs),'clock_cases':len(clocks),'gini_cases':len(ginis),'maximum_cost_Phi_relative_precision_difference':max((a['Phi_relative_precision_difference'] for a in costs),key=mp.mpf),'maximum_clock_relative_precision_difference':max((a['relative_precision_difference'] for a in clocks),key=mp.mpf),'maximum_gini_bound_ratio_precision_difference':max((a['bound_ratio_precision_difference'] for a in ginis),key=mp.mpf),'maximum_gini_lhs_ratio_precision_difference':max((a['lhs_ratio_precision_difference'] for a in ginis),key=mp.mpf),'maximum_reordered_identity_abs_difference_70dps':max((a['at_70dps']['identity_abs_difference'] for a in costs),key=mp.mpf),'same_weight_constant_cost_clock_cases':sum(a['configuration']['kind']=='same_weights' for a in clocks),'H_zero_clock_cases':sum(a['at_70dps'].get('empty_S_zero_traffic_branch',False) for a in clocks),'weighted_Gini_parameter_range_eta_n_one_minus_r':[min((a['at_70dps']['eta_n_one_minus_r'] for a in ginis),key=mp.mpf),max((a['at_70dps']['eta_n_one_minus_r'] for a in ginis),key=mp.mpf)]}
 result={'summary':summary,'schema':'R232_common_survivor_weighted_v1','complete':True,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'contract_sha256':hashlib.sha256((HERE/'task_contract.md').read_bytes()).hexdigest(),'mpmath_version':mp.__version__,'case_count':len(costs)+len(clocks)+len(ginis),'finite_cost_cases':costs,'finite_product_clock_cases':clocks,'same_posterior_weighted_gini_cases':ginis,'scope':['Fraction exact cost-level sorting/layercake and mass normalization implementation checks, plus ordinary log evaluation.','Common fixed persistent S and complete current original finite normalizer retained; deletions only outside S.','40/70dps log-clock quadrature cross-checks are numerical evidence, not interval certificates.','Weighted Gini uses finite normalized iid score atoms and exact eta, including huge n through compressed atoms.','No separate conditional normalizer per cost layer; no general theorem, source-price, histories, or FULL certification.']}
 output.write_text(json.dumps(result,indent=2)+'\n');print('complete',result['case_count'],'cost',len(costs),'clock',len(clocks),'gini',len(ginis),flush=True)
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=HERE/'weighted_checks.json');main(ap.parse_args().output)
