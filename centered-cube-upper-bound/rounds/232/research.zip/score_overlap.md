# R232：保 QG 缺口的同后验 score 界

**结论。** QG 的节点缺口可以直接与实际 score 共同估计，不必固定后验或控制 degree 比。下文证明同一真实后验的加权 Gini 界 `(1-e^{-cn})/(4c)`，终端连续取 `n/4`。它给每节点的显式对数 clock 费，并使 R230 的全节点来源价多乘一个真正的 far 衰减因子；在非空原窗 `0<U<n log2` 中，`H_{n,η}(U)≤min(1,2/(ηU))`。来源拥挤比 `||ν||/(qa^n)` 仍在；这不是一般 `W_β` 付款。加性缺口 Δ 与此前 `−log w` 的 deficit 层严格区分。

## SO1 准确原节点与实际 clock

使用本轮 `task_contract.md`、R229 冻结 `adaptive_geometry.md` AG1–7、R230 冻结 `coupled_geometry.md` CG1–6，以及 R224 已审 QG。不重复 soft 菜单、尺度覆盖和线性节点求和的证明。

固定原 `(ω,V,j)`，`γ=1+1/n`、`c=c_j=γ^{-j}`，`a≤L,R≤b≤2a`。R229 向上节点记 `M≥M_0=a/c²`，`g^*=cM`、`d_*=cg^*=c²M=min(L^*,R^*)`。对固定 y,v 令

\[
 \alpha_i=bC(|y_i-v_i|/b),\qquad
 \omega_i=\min(1,\alpha_i/d_*),\qquad
 \Delta_*(y,v)=\sum_{i=1}^n(1-\omega_i),\qquad
 E_*(y,v)=e^{-\eta\Delta_*},\quad \eta=\kappa/2=25/2^{69}. \tag{SO1}
\]

固定 `(j,y,t)` 后，实际 `Π_t(dv)=1_{Z_t(y)}(v)w_t(y,v)ν(dv)/e_t(y)` 与实际 `k_t(y,v)` 不依 receiver x。有效正分母行 Π 是概率测度；无效行共同取零。两份 Π 必须是同一实际后验。允许原实际删除，不改 carrier，也不将删除跳项当作 `dt/t` 密度或负信用。

节点上 actual clock `t≤g^*` 时，写 `r=t/g^*`，实际 a.e. score 恰为

\[
 k_t(y,v)=\sum_i1_{\{\alpha_i<ct\}}
          =\sum_i1_{\{\omega_i<r\}},\qquad
 \Delta_*\ge(1-r)k_t(y,v). \tag{SO2}
\]

等号阈值可任取有界 a.e. 版本，不改变 clock 积分。原 far 门 `t≤g(x)e^{-U/n}`、`U≥0` 固定，在节点中给

\[
 r_0=M_0/M\le r\le r_1=e^{-U/n}\le1,
 \qquad r_0\ge a/(bc²)\ge1/2. \tag{SO3}
\]

若 `r_1≤r_0`，该节点 clock 为零。这里 `r` 是无量纲时间，不是 soft 菜单变量。

固定 v 确有 `∫_{r0}^1 k_t dr/r≤Δ_*/r0≤2Δ_*`：每坐标的积分为 `log(1/max(ω_i,r0))`，上界为 `(1-ω_i)/r0`。但这不能直接对随时间变化的 Π 积分。本稿实际使用下面逐时刻的同后验引理。

## SO2 加权 Gini 引理：不用后验的时间正则性

**引理。** 令 π 为概率测度，`k∈[0,n]`，`c_0≥0`。若 `0≤E(v)≤e^{-c_0k(v)}`，则

\[
 \boxed{\iint E(v)(k(v)-k(u))_+\pi(dv)\pi(du)
 \le\frac{1-e^{-c_0n}}{4c_0},} \tag{SO4}
\]

`c_0=0` 的右侧按连续延拓为 `n/4`。质量 `m≤1` 的子概率版本右侧再乘 `m²`。

**证明。** 当 `k(v)>k(u)` 时，

\[
 E(v)(k(v)-k(u))\le e^{-c_0k(v)}(k(v)-k(u))
 \le\int_{k(u)}^{k(v)}e^{-c_0s}ds.
\]

其余 pair 两边取零。Tonelli 后右侧变成

\[
 \int_0^n e^{-c_0s}\pi\{k>s\}\pi\{k\le s\}ds
 \le\frac14\int_0^n e^{-c_0s}ds.
\]

子概率时两个质量和为 m，其乘积≤`m²/4`。证毕。它是正上界，不把原不对称 good/bad/capture 门的反向负项借回；这些门仅按 `[0,1]` 正上放。

由 SO2 对每个真实时刻取 `c_0=η(1-r)`，无需对 `e_t` 求导，得到

\[
 \boxed{\iint E_*(y,v)\delta_t(v,u)\Pi_t(dv)\Pi_t(du)
 \le\frac{1-e^{-\eta n(1-r)}}{4\eta(1-r)},\qquad
 \delta_t=(k_t(v)-k_t(u))_+.} \tag{SO5}
\]

终端 r=1 的极限为 n/4，故没有不可积的人工终端奇点。单独写成 `C/(1-r)` 再积分会丢失这一截断。

## SO3 每节点的精确 clock 函数

定义空区间为零，并令

\[
 \mathcal I_{n,\eta}(r_0,r_1)
 =\int_{r_0}^{r_1}\frac{1-e^{-\eta n(1-r)}}{4\eta(1-r)}\frac{dr}{r}.
 \tag{SO6}
\]

它是实际 weighted pair 的合法统一 clock 价。两个直接上界是

\[
 \mathcal I_{n,\eta}\le\frac n4\log(r_1/r_0),\qquad
 \mathcal I_{n,\eta}\le\frac1{4\eta r_0}
 \int_{\eta n(1-r_1)}^{\eta n(1-r_0)}\frac{1-e^{-z}}z\,dz. \tag{SO7}
\]

第一式用 SO4 的 `n/4`；第二式代换 `z=ηn(1-r)` 后用 `1/r≤1/r0`。被积函数在 z=0 连续取1。写 `Ein(x)=∫_0^x(1-e^{-z})dz/z`，则

\[
 \mathcal I_{n,\eta}\le\frac1{2\eta}
 \min\{x,1+\log_+x\},\quad x=\eta n(1-r_0). \tag{SO8}
\]

因为 `Ein(x)≤x`，且分拆 `[0,1]` 与 `[1,x]` 给 `Ein(x)≤1+log_+x`。因此长节点的 clock 费至多 `O_κ(log(n+1))`，同时可取较小的原 `n log(r1/r0)/4`。若 `r1<1`，SO7 还可用 `∫dz/z` 给显式非终端对数差。所有这些界直接对实际移动后验成立，不经过静态 envelope。

## SO4 全节点与全比例带：明确额外 far 因子

令

\[
 H_{n,\eta}(U)=
 \frac{1-e^{-z_U}}{z_U},\qquad
 z_U=\eta n(1-e^{-U/n}),\qquad H_{n,\eta}(0)=1. \tag{SO9}
\]

函数 `(1-e^{-z})/z=∫_0^1e^{-zs}ds` 沿 z 非增。SO3 给 `r≤e^{-U/n}`，所以 SO5 右侧≤`(n/4)H_{n,η}(U)`，进而

\[
 \mathcal I_{n,\eta}(r_0,r_1)
 \le\frac n4\log(r_1/r_0)H_{n,\eta}(U). \tag{SO10}
\]

非空原窗必有 `U<n log2`，且 `1-e^{-U/n}≥U/(2n)`（在 `[0,log2]` 积分 `e^{-s}≥1/2`）。故

\[
 H_{n,\eta}(U)\le\min\{1,2/(\eta U)\},\qquad 0<U<n\log2\quad\text{（非空原窗）}. \tag{SO11}
\]

保 R229 三腿和一份公共 soft 菜单，先 receiver-first 用 QG
`J_node(y,z,v)≤M^{-n}E_*(y,v)Φ(y,z,v)`，只将 capture 比例 `Φ≤1` 正上放，仍保 E；然后 hard z 积分只得真实 `||ν||`。原 Π 与 score 固定 `(j,y,t)` 不依 x,z，故此后用 SO5。全过程的精确节点价为

\[
 \mathcal P_{far}(U)\le
 2\Lambda\sqrt{K/3}\,(24e^4N_n)\,
 \mathbb E\sum_{V,j}\frac{\|\beta_V\|\|\nu_V\|}{q}
 \sum_{M\in\mathcal M_j}M^{-n}
 \mathcal I_{n,\eta}(M_0/M,e^{-U/n}). \tag{SO12}
\]

常数24=3腿×2朝向×4覆盖，`N_n≤8+4√n log(n-1)`；每节点的时间价已含 Gini 的1/4。没有将 hard z 当 Π 来源，没有重算原 high/capture/FIRST、soft 或原唯一 j。

用 SO10 及 R230 已证 `Σ_M M^{-n}nℓ_M≤3e^{-U}c_j^{2n}a^{-n}`，得到实际改进

\[
 \boxed{\mathcal P_{far}(U)\le
 2\Lambda\sqrt{K/3}\,(18e^4N_n)e^{-U}H_{n,\eta}(U)
 \mathbb E\sum_{V,j}\frac{c_j^{2n}}{q a^n}
                 \|\beta_V\|\|\nu_V\|.} \tag{SO13}
\]

相较 R230，额外 `H(U)` 没有增加任何包络质量。若同 V 的 `q,a,β,ν` 不随 j 变，直接 `Σ_jc_j^{2n}≤4/3` 给

\[
 \mathcal P_{far}(U)\le
 2\Lambda\sqrt{K/3}\,(24e^4N_n)e^{-U}H_{n,\eta}(U)
 \mathbb E\sum_V\|\beta_V\|\frac{\|\nu_V\|}{qa^n}. \tag{SO14}
\]

没有该共同来源资格则只用 SO12–13。它们估原连续正量，不领取任何删除、反向、boundary、FA 或已付浮动带的负信用。

## SO5 真正的加性缺口层；不偷换 logdeficit

对原真实 receiver 定义 `Δ_g(y,v)=Σ_i[1-min(1,α_i/(cg(x)))]`。向上节点 `g^*≥g` 给 `Δ_*≥Δ_g`，故实际分支 `Δ_g≥D` 可合法传成固定节点门 `Δ_*≥D`。

对任意固定 `θ∈(0,1]`，

\[
 E_*1_{\{\Delta_*\ge D\}}
 \le e^{-(1-\theta)\eta D}e^{-\theta\eta\Delta_*}.
\]

于是 SO13–14 对原 `Δ_g≥D` 子交通仍成立，只需将 `H_{n,η}(U)` 换成

\[
 F_{n,\eta}(D,U)=\inf_{0\le\theta\le1}
 e^{-(1-\theta)\eta D}H_{n,\theta\eta}(U), \tag{SO15}
\]

其中 `θ=0` 项连续定义为 `e^{-ηD}`。对每个固定 θ 都已证明，故可对这些数值上界取 inf；不是在 receiver 内新增自由 selector。若只要纯加性层价，可直接选 θ=0。

另一方面 `Δ_g≤-log w_g`，反向下界没有在本合同授予。一个非常小的 ω 可以令 `−log w_g` 大而 Δ_g 仍≤该坐标的1。因此 R231 的 `−log w_g>D` 互补域不能直接当作 SO15 的 `Δ_g≥D` 分支。SO15 也不结算任意 D 的补集。

## SO6 实际检查与明确剩余费用

本机 mpmath 60位精度实际完成244项检查：n=2,16 的八来源有限实际乘积 clock，r=1/2,7/10,99/100,1，三种 η（含真实 `25/2^69`），随 r 删不同来源并用真实 `w_rν/e_r` 归一；检查 SO2、SO5。另对 n=2,512,10^6,10^24 的多个 U 检查 SO9–11。结果全部 PASS。这是有限高精度证据，不是向外舍入证书或 FULL/history 输入认证。一般证明由 SO2–15 承担。

可在已有 mpmath 的 Python 中复现以下实际脚本；本机运行时把现有 vendor 库路径 `/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor` 加入 `PYTHONPATH`，没有安装或改写依赖。

```python
from fractions import Fraction as F
import mpmath as mp
mp.mp.dps=60
count=0
for n in (2,16):
  omegas=[[F(1+((seed*(i+3)+i*i)%29),30) for i in range(n)]
          for seed in range(1,9)]
  for r in (F(1,2),F(7,10),F(99,100),F(1)):
    ks=[sum(o<r for o in row) for row in omegas]
    ds=[sum(1-o for o in row) for row in omegas]
    raw=[]
    for j,row in enumerate(omegas):
      w=F(j+1)
      for o in row: w*=min(F(1),o/r)
      raw.append(w if (j+int(r*100))%5 else F(0))
    total=sum(raw); ps=[p/total for p in raw]
    def m(x): return mp.mpf(x.numerator)/x.denominator
    for eta in (F(25,2**69),F(1,10),F(1,2)):
      e=m(eta); c=e*(1-m(r))
      lhs=sum(m(p)*m(q)*mp.exp(-e*m(d))*max(k-l,0)
              for p,k,d in zip(ps,ks,ds) for q,l in zip(ps,ks))
      rhs=mp.mpf(n)/4 if not c else -mp.expm1(-c*n)/(4*c)
      assert lhs<=rhs+mp.mpf('1e-55'); count+=1
      for k,d in zip(ks,ds):
        assert d>=(1-r)*k; count+=1
for n in (2,512,10**6,10**24):
  for U in (mp.mpf(0),mp.mpf('0.25'),mp.mpf(1),
            min(mp.mpf(10),mp.mpf(n)*mp.log(2)/2)):
    if U>=mp.mpf(n)*mp.log(2): continue
    eta=mp.mpf(25)/mp.mpf(2)**69
    z=eta*n*(-mp.expm1(-U/n))
    H=mp.mpf(1) if not z else -mp.expm1(-z)/z
    assert H<=1+mp.mpf('1e-55'); count+=1
    if U:
      assert H<=2/(eta*U); count+=1
print({'mpmath_dps':mp.mp.dps,'assertions':count,'result':'PASS',
       'nature':'finite high-precision checks, not interval certificate'})
```

实际返回 `mpmath_dps=60,assertions=244,result=PASS`。

SO8 是实际每节点 `O_κ(log(n+1))` 改进，SO13 是保全部来源的实际 far 改进；它们仍含 `||ν||/(qa^n)`、`√K`、soft 菜单及来源总和。SO11 在 `ηU` 小时只给接近1的因子，且原 U 上端≤`n log2`；不能以它无价消除任意来源拥挤。SO15 只控制真正的加性缺口子支。没有得到一般 `εX+C√n polylog(n)W_β`，也没有从固定 v 的 `2Δ` 恒等式偷渡对移动 Π 的免费预算。本有界辅助任务止于这些新正上界。
