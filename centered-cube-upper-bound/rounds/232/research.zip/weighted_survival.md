# R232：一个共同终端质量的加权持久来源势

**新结论。** 不作uniform deficit截断。对一个固定且真实存活到T的集合S，使用同一个终端质量H_T，对所有来源代价层共同结算。若μ是这些来源从τ到T的真实权损失、F(v)是静态非负列代价，则早段正交通满足

\[
 \boxed{I_F\le\Phi_{H_T}(F,\mu):=
 \int_0^\infty\log\left(1+\frac{\mu\{F>\lambda\}}{H_T}\right)d\lambda.}
 \tag{WS1}
\]

实际列代价F≤B时，还有可直接从两个端点计算的界

\[
 \boxed{\Phi_{H_T}(F,\mu)
 \le B\log\left(1+\frac{\int F\,d\mu}{BH_T}\right)
 \le B\log\left(1+\frac{\mu(S)}{H_T}\right).}
 \tag{WS2}
\]

所有层使用同一个H_T；没有逐deficit层重复分配全ν质量。这个定理保任意小的终端权，且允许S外来源删除。其实际空间/来源回代见WS10：全部source和节点费用仍明列。没有证明这些端点势的原β积分由W_β支付，因此不宣布一般root弱型闭合。

本稿只用冻结R231 LD12–15的真实资格、固定节点local-cap/QG列，以及R230同后验Gini界。原v是terminal-good来源，u是另一pair来源；不得反向使用存活资格。

## WS2 固定持久集合的准确输入

固定原(j,y)及有限原正测度ν，取有效时域τ≤T。令S⊂Z_{j,T}(y)可测并沿本段固定。Z_t随t递减，故S⊂Z_t对τ≤t≤T成立。原权满足

\[
 0<w_t(y,v)\le1,\qquad
 -\frac{d w_t(y,v)}{d\log t}=k_t(y,v)w_t(y,v)\quad\hbox{a.e.},
 \qquad0\le k_t\le n.
\]

这是原坐标threshold乘积的导数；不是对删除后e_t求导。设

\[
 \Pi_t(y,dv)=1_{Z_{j,t}(y)}(v)w_t(y,v)\nu(dv)/e_t(y),
 \quad e_t(y)=\int_{Z_{j,t}(y)}w_t(y,v)\nu(dv),
\]
\[
 H=H_T=\int_S w_T(y,v)\nu(dv),\qquad
 \mu(dv)=1_S(v)[w_\tau(y,v)-w_T(y,v)]\nu(dv).
 \tag{WS3}
\]

若ν(S)=0，该段原good来源交通为零，势定义为0。否则有限物理时域内权严格正，故H>0；μ有限且非负。共同域上原过程无效处后验取零，只缩小所估正交通。下面不把Π条件化到S。

对静态可测F:S→[0,∞]，定义

\[
 I_F=\int_\tau^T\frac{dt}{t}
 \int_S\int F(v)(k_t(y,v)-k_t(y,u))_+
 \Pi_t(y,dv)\Pi_t(y,du).
 \tag{WS4}
\]

实际history、capture、high或其他正门仍可保在原量中；以下上界允许将它们≤1上放。F必须独立辅助t，不能把正在变化的实际selector或原Q当作静态F。

## WS3 共同终端质量势的证明

对λ≥0，令E_λ=S∩{F>λ}，并定义其剩余可消耗权

\[
 R_\lambda(t)=\int_{E_\lambda}[w_t(y,v)-w_T(y,v)]\nu(dv)\ge0.
\]

因为整个S持久存活，原归一化总量满足

\[
 e_t(y)\ge\int_S w_t(y,v)\nu(dv)
 \ge H+R_\lambda(t).
 \tag{WS5}
\]

这里H包含**全部S**的终端质量，而不是E_λ自身的终端质量。S外来源可任意合法删除，不影响此不等式。固定E_λ后，R_λ绝对连续，`−dR_λ/dlogt=∫E_λ k_t w_tν`，且R_λ(τ)=μ(E_λ)、R_λ(T)=0。因此

\[
 \int_\tau^T\int_{E_\lambda}k_t(y,v)\Pi_t(y,dv)\,\frac{dt}{t}
 \le\int_\tau^T\frac{-dR_\lambda(t)}{H+R_\lambda(t)}
 =\log\left(1+\frac{\mu(E_\lambda)}H\right).
 \tag{WS6}
\]

由δ_+≤k_t(y,v)、另一份Π质量≤1，再对F的非负layer-cake用Tonelli，便得WS1。对无界F可先截断再单调收敛。全过程只对固定集合的原w积分求导，没有使用e_t的导数、删除jump或任何已付负信用。

## WS4 可计算端点形式与严格改善

若0≤F≤B<∞，μ-layer-cake给 `∫_0^B μ{F>λ}dλ=∫F dμ`。对λ的均匀概率测度dλ/B使用log的凹性，直接得到WS2。B=0时势为0。进一步有

\[
 \Phi_H(F,\mu)\le\min\left\{
 B\log\left(1+\frac{\mu(S)}H\right),\quad
 \frac{\int F\,d\mu}{H}\right\}.
 \tag{WS7}
\]

若希望保完整分布，令F↓为F关于损失测度μ的递减重排，则另一次Tonelli给准确表示

\[
 \Phi_H(F,\mu)=\int_0^{\mu(S)}\frac{F^\downarrow(r)}{H+r}\,dr.
\]

因此p>1时Hölder给一个可选端点矩上界

\[
 \Phi_H(F,\mu)\le
 (p-1)^{1-1/p}\left(\frac{\int F^p\,d\mu}{H}\right)^{1/p}.
\]

这些全是两端点与实际静态F的费用，不是将原时间积分换名；仍需在原β来源上结算它们。

一个完全显式的改善机制：设损失分成两类，低代价a的损失质量为H，高代价B≥a的损失质量为εH。共同势准确为

\[
 \Phi_H=a\log(2+\varepsilon)+(B-a)\log(1+\varepsilon)
 \le a\log2+B\varepsilon.
 \tag{WS8}
\]

最后一步用log(2+ε)≤log2+ε/2、log(1+ε)≤ε。统一最坏代价只给B log(2+ε)≥B log2。取ε=B^{-2}、固定a，新势≤a log2+1/B，而统一价随B线性增长。这只是端点定理的可核分布族，不宣称已经认证原FULL输入或所有空间约束；它准确说明保留的大终端质量如何支付稀少昂贵来源的损失。此前分别归一高代价子集会丢掉这种共用H的收益。

## WS5 实际节点列与时域：全deficit都允许

固定原(ω,V,j)的R229向上节点M，c=c_j，g*=cM，m*=c²M，τ=a/c。原actual terminal g满足 `g*/γ²≤g≤g*`。固定far偏移U≥0，记

\[
 h_M=g^*e^{-U/n},\qquad g_-=g^*/\gamma^2,\qquad
 T_M=\min(g_-,h_M).
\]

若h_M≤τ，节点无交通。若T_M≥τ，在早段取

\[
 S_M(y)=Z_{j,T_M}(y),\quad
 H_M(y)=\int_{S_M(y)}w_{T_M}(y,v)\nu(dv),\quad
 \mu_M(y,dv)=1_{S_M(y)}(w_\tau-w_{T_M})\nu(dv).
 \tag{WS9}
\]

所有实际terminal-good v都属于S_M：因为T_M≤g_-≤g_actual，且原G⊂Z_gactual。这里不截取任何 `w_T≥e^-D` 子集，所有正终端权都保留。使用T_M而不是无条件g_-，保留了原far窗缩短造成的真实损失μ变化。若T_M<τ，不在τ以前调用Z；早段费用记零，整节点只需下述晚段处理。

原receiver集Ω满足全部B∈[a,b]的hard local cap。R231的真实固定节点列除以共同q，被下列显式static来源函数控制：

\[
 F_M(y,v)=\min\left\{
 \frac{C_0}{\sqrt{\bar w_{m^*}(y,v)}},\quad
 B_M E_{m^*}(y,v)\right\},\quad
 B_M=\frac{\|\nu\|}{qM^n}=\rho(a/M)^n,\quad C_0=16/3.
\]

其中bar w和E是原C=h*max(h,φ)给出的threshold權及QG缺口，`0≤F_M≤B_M`。第一帽来自真实Ω上的H_R*ν≤C0q及归一两半密度affinity≤1；第二帽来自同一hard窗口的QG后对原全ν(z)积分。它们是**同一列**的两个上界取min，不能解释成先hard cap再额外乘QG。

更精细时可对每条腿/soft/朝向保

\[
 F_{exact}(y,v)=q^{-1}\int\nu(dz)\int_\Omega
 h_{R^*}(x-z)\frac{\sqrt{P_{r,L^*}(x-y)P_{\sigma,A^*}(x-v)}}
 {\sqrt{\bar w_{m^*}(y,v)}}1_{x\notin Q_d(v)}\,dx.
\]

Ω使用原hardband的固定接收超集，d只用已认证的固定节点capture排除；其余依t门不能塞进F_exact。于是F_exact≤F_M，且势具有单调性 `Phi_H(F_exact,μ)≤Phi_H(F_M,μ)`。这个选择保留实际来源尾与共同窗口，不能再把它的来源价叫免费。统一F_M与腿/soft/朝向无关，才允许后面提出6N_n。

## WS6 晚段和完整原量接口

定义

\[
 \ell_M=\bigl(\log(h_M/\tau)\bigr)_+,\qquad
 \ell_M^{late}=\left(\log\frac{h_M}{\max(\tau,g_-)}\right)_+.
\]

在晚段不声称S_M继续存活，直接使用原同Π的iid Gini及F_M≤B_M：费用≤`B_M n ell_late/4`。特别

\[
 \frac n4\ell_M^{late}\le\frac{(2n\log\gamma-U)_+}{4}.
\]

若U≥2n logγ（尤其U≥2），所有节点晚段都为空。此时整个原far节点交通都由WS1的一次加权端点势控制，不需要sup_v F；非空节点自动T_M≥τ。一般U的晚段费用明确保留，并未假设删除后的包络质量或端点逆度免费。

原剩余正交通首先作R229的合法点态覆盖：全部实际L/R/s、原三腿、实际capture/history及far门均保原值，外费用4e⁴及一份soft菜单。固定(j,y,t)的Π不依x/z，故receiver和hard-source先积分后使用F_M。早段保固定1_{S_M}，再应用WS1；其他正门可上放为1。原两份Π仍是同一后验，并未分别归一损失层。

设H_M=0或早段为空时Phi项为0；令

\[
 \mathcal K_M(y)=\min\left\{
 B_M\frac{n\ell_M}{4},\quad
 \Phi_{H_M(y)}(F_M(y,\cdot),\mu_M(y,\cdot))
 +B_M\frac{n\ell_M^{late}}4\right\}.
\]

第一个界来自全节点F_M≤B_M与原Gini；第二个界是新加权早段和真实晚段之和。完整原量因此满足

\[
 \boxed{P_{far}(U)\le
 2\Lambda\sqrt{K/3}\,(24e^4N_n)\,
 \mathbb E\sum_{V,j}\sum_{M\in\mathcal M_j}
 \int\mathcal K_M(y)\,\beta_V(dy).}
 \tag{WS10}
\]

24=4覆盖×3条腿×2朝向；ν(v/u)已保在原Π及μ/H内，没有额外全质量因子。hardν(z)和q已经准确包含在静态列F_M/B_M内。所有原j/物理节点仍显式求和；没有重新领取唯一j、FIRST或hard cap费用。若逐腿保F_exact，则将24N_n还原为4乘对腿/朝向/soft的有限和，每一项分别用其势。

WS2允许将新项替换为明确的端点矩

\[
 B_M\log\left(1+
 \frac{\int F_M(y,v)[w_\tau(y,v)-w_{T_M}(y,v)]1_{S_M(y)}\nu(dv)}
 {B_M\int_{S_M(y)}w_{T_M}(y,v)\nu(dv)}\right).
 \tag{WS11}
\]

无终端质量时按前述零行规则。WS11不是已获得原source总价；它精确展示现在要支付的一个共同端点损失矩。

WS10保第一个min入口，因而不会比R230直接物理质量估计更差：对每j，R230给 `sum_M B_M n ell_M/4≤(3/4)rho c_j^{2n}e^-U`。这只是既有备选上界，不是两次收费。新入口会在保留终端质量大、昂贵来源损失尾小的真实行上严格更小；它不需要先按D截取或把整来源质量重复放入每层。

## WS7 准确未付部分与停止点

WS1–2是一个新、分布敏感、端点可计算的正预算定理；WS10把它接入原共同来源和实际尺度。它覆盖任意小终端权，不添加源质量排序假设，也不消费删除信用。深far U≥2时，整个对应原分支无晚段sup费用。

仍未证明的是WS10中实际β积分及跨V/j/M总和可由 `C polylog(n)W_β` 支付。即使给出了Jensen端点矩，极小H_M或原空间上聚集的加权损失仍可能昂贵；本稿没有给它们新的普遍空间尾界。未付项现在保为一个共同H_M及真实损失测度μ_M，而不是每deficit层独立source质量。不能把这个更强端点定理改称一般root闭合，也不能用当前far结果支付原near或其他终端互补分支。

## WS8 实际本机验证

实际使用本机mpmath 50位，n=16，τ=1、T=1.5、g*=γ²T。3个持久来源、2个在早段删除的外部来源，均使用原形式 `w_t=prod_i min(1,a_i/t)`；静态代价取 `min(C0/sqrt(w_g*),1000 E_g*)`。改变第三持久来源质量为1、0.01、0.0001，对所有阈值和删除点分段积分。每组均实际验证
`weighted pair≤weighted score≤Phi≤Jensen≤uniform partition cost`。

| 昂贵来源质量 | weighted pair | weighted score | Phi | Jensen | uniform |
|---:|---:|---:|---:|---:|---:|
| 1 | 5.51929194697 | 5.82574930835 | 24.9191507677 | 26.0256419855 | 207.505174796 |
| 0.01 | 3.68561179246 | 3.90891066837 | 7.35485003122 | 7.94159168787 | 162.726435769 |
| 0.0001 | 3.66718511977 | 3.88969492419 | 7.17422330040 | 7.75878269060 | 162.267596373 |

这是真实threshold乘积时钟的有限核查，包含S外删除；不是原空间Ω/high/cut/rank全部认证的FULL输入，也不据此推断n阶。严格结论依据WS3的证明。复现代码：

```python
import mpmath as mp
mp.mp.dps=50
n=16; gam=1+mp.mpf(1)/n; tau=mp.mpf(1); T=mp.mpf('1.5'); gs=gam**2*T
C0=mp.mpf(16)/3; B=mp.mpf(1000); kap=mp.mpf(25)/mp.mpf(2)**68
thresholds=[[mp.mpf('1.8')]*n,[mp.mpf('1.3')]*n,
            [mp.mpf('.7')]*8+[mp.mpf('1.45')]*8,
            [mp.mpf('.8')]*n,[mp.mpf('1.7')]*n]
delete=[mp.inf,mp.inf,mp.inf,mp.mpf('1.1'),mp.mpf('1.35')]
def wt(i,t): return mp.fprod(min(1,a/t) for a in thresholds[i])
def kk(i,t): return sum(a<t for a in thresholds[i])
F=[min(C0/mp.sqrt(wt(i,gs)),B*mp.exp(-kap/2*sum(1-min(1,a/gs)
   for a in thresholds[i]))) for i in range(3)]
points=list(map(mp.mpf,['1','1.1','1.3','1.35','1.45','1.5']))
for eps in map(mp.mpf,['1','.01','.0001']):
    masses=[mp.mpf(1),mp.mpf('.2'),eps,mp.mpf(50),mp.mpf(20)]
    H=mp.fsum(masses[i]*wt(i,T) for i in range(3))
    mu=[masses[i]*(wt(i,tau)-wt(i,T)) for i in range(3)]
    prev=mp.mpf(0); potential=mp.mpf(0)
    for level in sorted(set(F)):
        tail=mp.fsum(mu[i] for i in range(3) if F[i]>=level)
        potential+=(level-prev)*mp.log1p(tail/H); prev=level
    moment=mp.fsum(F[i]*mu[i] for i in range(3))
    jensen=B*mp.log1p(moment/(B*H))
    worst=B*mp.log1p(mp.fsum(mu)/H)
    def integrand(t,pair):
        weights=[masses[i]*wt(i,t) if t<delete[i] else mp.mpf(0) for i in range(5)]
        den=mp.fsum(weights); probs=[w/den for w in weights]
        if pair:
            val=mp.fsum(F[i]*max(0,kk(i,t)-kk(j,t))*probs[i]*probs[j]
                       for i in range(3) for j in range(5))
        else:
            val=mp.fsum(F[i]*kk(i,t)*probs[i] for i in range(3))
        return val/t
    score=mp.fsum(mp.quad(lambda t:integrand(t,False),[a,b])
                 for a,b in zip(points,points[1:]))
    pair=mp.fsum(mp.quad(lambda t:integrand(t,True),[a,b])
                for a,b in zip(points,points[1:]))
    assert pair<=score<=potential<=jensen<=worst
    print(eps,*(mp.nstr(v,16) for v in (pair,score,potential,jensen,worst)))
```

实际Python为 `/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3`，PYTHONPATH为 `/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor`。只写本稿，不改其他工作文件。
