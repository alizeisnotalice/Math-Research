# R232: common persistent-source weighted loss budget

Start clean main fab318b89655e4b1c1c61d467dcb5a30455b594a. General arbitrary positive L1 root weak target remains open.

Primary candidate (author and auditor independently screen): fixed persistent S⊂Z_T, decreasing original positive weights w_t, scores k=-dlogw/dlogt∈[0,n], same actual posterior Π_t with e_t≥∫Swtν. Let H=∫S w_Tν, μ=(w_τ-w_T)1Sν. For fixed nonnegative bounded costF(v), prove weighted survivor integral ≤Φ_H(F,μ)=∫_0∞log(1+μ{F>λ}/H)dλ. No separate deficit-band normalizers. Positive score pair≤good score. Handle H0/νS0, inactive processes, deletion outsideS; no derivativee or reclaimed negative credit. Apply original early node gminus=g*/γ² and all terminal-good sources without a D cutoff. Exact column costF=min(C0/sqrtw_node,ρ(a/M)^n E_node) with originalΩ and realν source. Retain actual source/normalizer/time fees and late shortwindow. Success means actual strengthened common-source bound with explicit paid conditions/finite endpoint example, not naming Φ as a free constant.

Auxiliary candidate: actual threshold score yields Δ_node≥(1-t/g*)k_t. Preserve E=exp(-ηΔ),η=25/2^69. Prove same-posterior weighted Gini price (1-exp(-ηn(1-t/g*)))/(4η(1-t/g*)) and keep its exact clock integral/node costs. Do not identify Δ with terminal logdeficit or assert retained source fee paid.

Allowed tools: R229 pointwise covering, R224 exact QG, R230 sameposterior Gini, R231 actual receiver cap/persistent source and cut-column interfaces. All q,a,β,ν sameV acrossj when summing; otherwise retain individual terms. No new source density assumptions.

Ownership: Astra r217_peak weighted_survival.md; Sol r217_compare score_overlap.md; Sol r217_audit audit.md; Sol r217_numeric weighted_checks.py/json,numeric_notes.md. Parent proof.tex.txt/report.md/reproduce.py. Agents not alone, no other file edits, Git/PDF/spawning; deliver bounded proofs then stop. Numerics: preliminary finite identities, deletion/rare-cost/zero-boundary pressure, larger n/scale precision; actual local math only, finite evidence not FULL or general theorem.
