# R232 运行前有限方案

主表18个有限成本分布：6个cost/mass模式乘H=1,1/100,1e−80，含零质量/零cost、相同cost、稀有高cost。用Fraction独立构造成本level宽度与尾mass，精确核layercake加权质量；Phi由level sum计算，另一按cost降序的重排积分逐段log((H+r_after)/(H+r_before))独立计算。40/70dps比较Phi、Jensen Fmax log(1+∑Fμ/(FmaxH))、maxcap与linear；零cost/零mass独立零分支。

18个有限实际product clock：n2/16/512，6个模式为完整normalizer、只删除S外来源、同权饱和对照、零loss、稀有高cost、空persistent S。窗tau=.5,T=1；每个来源用阈值与重数精确定义w_t=product min(1,alpha/t)，保固定S与所有S外当前活来源质量，删除点与threshold全分片。H=∑S wTν，mu_i=(w_tau−wT)ν；直接对logt积分∑S Fi ki wtν/e_t，与同固定S的Phi比。H0且S空时交通0，不除0/不造Phi。按40/70dps独立积分复核；不是有向区间证书。

60个加权Gini表：n2/16/512/1e20/1e24，r0/1/2/(1−1e−6)/1；三有限概率分布，真归一pi，score∈[0,n]，Delta_i≥(1−r)ki。eta精确25/2^69；算Ei=exp(−eta Delta_i)与完整iid正score差，加权界用−expm1(−eta n(1−r))/(4eta(1−r))，r1用n/4极限。大n仅压缩2–3个score原子，不枚举维度。共96例，保全部参数/完整JSON/--output/合同绑定，最终独立路径字节复跑。不拟合阶、不认证FULL。

## 实际结果与精度范围

本机实际完成96例（18 cost、18 clock、60 weighted Gini），未增加菜单。18成本表的Phi与独立重排积分在70dps最大绝对差约1.85460e−68；Phi≤Jensen≤min(maxcap,linear)逐例通过，Fraction层质量恒等式及重排累计总质量精确成立。零质量/零cost分支均给0。40/70dps的32有效位Phi输出一致；这不代表无数值误差或严格区间相等。

稀有高cost例说明付费结构而非取全局Fmax：H1、mu=(1,1e−30,2)、F=(1,1e12,0)时，Phi≈.69314718，Jensen≈1，maxcap≈1.38629e12，linear≈1。H1e−80同分布下Phi≈1.15129e14，Jensen≈1.56576e14、maxcap≈1.85305e14、linear≈1e80。这里并未省掉commonH或真实loss质量；数值不把Phi重新命名为免费常数。

所有18个product clock直接积分≤同一固定S的Phi，完整当前e_t保留S外活来源。n512完整外来源存活时积分≈8.50714，Phi≈343.15396；只删S外来源后积分≈258.13622，仍低于该相同Phi。删除不兑换负项或重设normalizer。n2/16/512的同权同cost2、无S外来源模型分别直接积分≈1.15072829/9.20582632/294.58644219，与Phi达到等号（解析式2n log(4/3)）；这是有限clock饱和对照，不是几何/FULL原输入。三例空S明确H0零交通，不除零；三例阈值全高于T给mu0与交通0。n512稀有高cost模式积分≈8.32097e13、Phi≈1.14249e14，也通过。

每个clock先按全部threshold和S外删除时点分片，40/70dps各自直接对logt积分。保存每分片完整S score、活S外原子数与积分；两个精度的32有效位直接积分输出一致。普通mpmath求积与精度交叉检查不是有向区间误差证书，等号时微小数值差不作严格符号断言。

60个weighted Gini中，每例pi精确和1，score为0至n的有限整数，Delta_i≥(1−r)ki精确检查成立；eta固定25/2^69。全部实际Ei加权iid正差低于所提界，所提界低于n/4。r1显式用n/4，避免0/0。eta n(1−r)最大约42351.64736；r0时n1e20的界/n4≈.2326999388，n1e24约.0000236118324143，说明测试已实际分辨eta n效应。大n只用2–3个压缩score原子，并不构造对应完整空间几何或推维数阶。40/70dps两种归一比的32位输出一致。

本轮证据范围仅有限cost层/同固定persistentS的真实productclock/归一iid score核验；一般重排、生存者与加权Gini证明仍归作者/独审。未认证原source容量价格已付、历史/后验几何资格、FULL或全局目标。完成后不扩大搜索。

最终源码以独立--output路径完整复跑，JSON逐字节一致。JSON SHA256：32ff8f6a2f0d1f06ce2886576b28a9d0ed7c01efaa376c426d41222d0b8133a0；源码SHA256：7f7347234c67f70a96883346165a6fbacecfc3fd6c51e25b7e35a423391e7c83。JSON不含runtime/输出路径字段。96例全部完成，停止。
