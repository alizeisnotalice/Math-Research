# R232 independent audit

## Statement-first screening, before author proofs

Read `task_contract.md` and use the frozen R231 persistent-source and original-carrier qualifications. No R232 author proof was read before this checkpoint. Only this audit is edited; no new source-density cap is assumed.

### Weighted common-normalizer survivor bound

Fix a finite positive clock window \([\tau,T]\), a persistent measurable \(S\subset Z_T\), and its original weights. Assume \(0<H:=\int_S w_T\,d\nu<\infty\) and finite \(\mu=(w_\tau-w_T)1_S\nu\). Let \(F\ge0\) be bounded and measurable, fixed before the clock integration. For \(E_\lambda=S\cap\{F>\lambda\}\), set
\[
 R_\lambda(t)=\int_{E_\lambda}(w_t-w_T)\,d\nu.
\]
On original valid times, \(e_t\ge H+R_\lambda(t)\). Absolute continuity gives \(-dR_\lambda/d\log t=\int_{E_\lambda}k_tw_t\,d\nu\). Therefore
\[
 \int_\tau^T\int_{E_\lambda}k_t\,d\Pi_t\,d\log t
 \le\log\left(1+\frac{\mu(E_\lambda)}H\right).
\]
Inactive rows are zero and only decrease the integral. Tonelli in \(\lambda\) proves the desired statement
\[
 \boxed{\int_\tau^T\int_S Fk_t\,d\Pi_t\,d\log t
 \le\Phi_H(F,\mu):=\int_0^\infty
 \log\left(1+\frac{\mu\{F>\lambda\}}H\right)d\lambda.}
\]
The pair version follows from \((k_v-k_u)_+\le k_v\) and the other original posterior's mass at most one. No normalizer derivative, deletion credit or source exchange is involved. The common denominator is the terminal mass of all S, not the terminal mass of each level set.

At \(T=\tau\), both loss and traffic vanish. An empty S or zero source mass is zero. In the original finite-window positive product-weight class, \(H=0\) also means zero persistent contribution; bounded score prevents a positive weight from reaching zero in finite logarithmic time. One must handle that branch before division, rather than assign an arbitrary log ratio. Infinite/undefined normalizers do not define an original active posterior.

### Actual all-deficit node application

For a R229 node set \(g^*=c_jM\), \(g_-=g^*/\gamma^2\le g(x)\), \(h_M=g^*e^{-U/n}\), and \(T_M=\min(g_-,h_M)\). If \(T_M\ge\tau_j\), use \(S=Z_{T_M}(y)\). Every actual terminal-good source on that node fiber belongs to S by the frozen original survivor inclusion. No lower bound on its terminal weight and no D-cutoff are needed. If the early interval is empty, do not define a past carrier.

The proposed normalized column cost
\[
 F_M(y,v)=\min\left\{\frac{C_0}{\sqrt{w_*(y,v)}},\,
 \rho(a/M)^n E_*(y,v)\right\}
\]
is static in t and x and bounded by \(\rho(a/M)^n\). It follows from two alternative bounds on the same hard-source/receiver column, with the actual \(\Omega\) retained for its local cap and the exact node QG bound for its second term. The true hard \(\nu\) has already been integrated in that column; it is not made into a posterior. The original good indicator is enlarged to the fixed S only after its inclusion has been proved, and is retained through the receiver step. No conditionalization of \(\Pi\) occurs.

The late interval is contained in \([\max(\tau_j,g_-),h_M]\), with logarithmic length at most \((2n\log\gamma-U)_+/n\). Its coarse fee is thus at most \(\sup_vF_M\,(2n\log\gamma-U)_+/4\) by the original Gini bound. In particular the late slice is empty for \(U\ge2n\log\gamma\), and uniformly for \(U\ge2\). This removes that slice only from the chosen far branch; the corresponding shallow traffic is not paid.

F must be genuinely static and depend only on the survivor source for this direct lemma. A receiver cut or column cost still depending on t or on the second auxiliary source cannot be silently inserted; its level sets would not be the fixed sets above. The exact \(H_M(y)\), loss measure \(\mu_M(y)\), original \(\beta(dy)\), all j/nodes and the source/kernel costs remain in the resulting bound. Naming their sum \(\Phi\) does not pay it.

### Quantitative sufficient conditions and common-source charge

With \(F^*\) the decreasing rearrangement under \(\mu\), Tonelli also gives
\[
 \Phi_H(F,\mu)=\int_0^{\mu(S)}\frac{F^*(r)}{H+r}\,dr.
\]
For p>1, Hölder yields the explicit sufficient moment bound
\[
 \Phi_H\le(p-1)^{1-1/p}
 \left(\frac{\int F^p\,d\mu}{H}\right)^{1/p}.
\]
Alternatively, a proved actual tail condition \(\mu\{F>\lambda\}/H\le(B/\lambda)^p\) for all \(\lambda>0\), p>1, implies
\[
 \Phi_H\le B\left[p+\log2+\frac1{p-1}\right]
\]
by splitting the integral at B. These are sufficient conditions, not new source assumptions granted by FIRST; their B or moment costs must still be averaged against the original beta and summed over nodes.

The common charge avoids an artificial partition cost: for F=1, H=1 and N unit loss groups it is \(\log(1+N)\), whereas separately charging each group with the same H gives \(N\log2\). The common rearrangement expression is the sharp universal loss charge if only total terminal mass, loss distribution and arbitrary monotone release paths with sufficient release time are prescribed (release smaller costs first). This does not assert sharpness for a prescribed short clock, the original iid positive pair, or realizability by every original coordinate-threshold/history construction. The pair step \(\delta_+\le k_v\) can be loose.

As local math-tool diagnostics, a two-cost persistent/deleting product-weight example satisfied actual weighted score ≤ \(\Phi_H\) ≤ its p=2 moment bound; equal-cost partitions N=2,16,100 displayed the stated common-versus-separated charge. These ordinary 50-digit checks do not certify original spatial geometry or a global source tail.

### Auxiliary overlap-score screening

For a fixed node, let \(\omega_i=\min(1,\alpha_i/(cg^*))\), \(\Delta=\sum_i(1-\omega_i)\), and r=t/g*≤1. The original threshold score is \(k_t=\sum_i1_{\omega_i<r}\) a.e., so \(\Delta\ge(1-r)k_t\). With \(E=e^{-\eta\Delta}\), \(\eta=25/2^{69}\), this gives \(E(v)\le e^{-c k_v}\), c=\(\eta(1-r)\). For the same posterior of mass at most one,
\[
 \iint E(v)(k_v-k_u)_+\,d\Pi(v)d\Pi(u)
 \le\frac{1-e^{-cn}}{4c},
\]
with n/4 at c=0. Indeed \(e^{-ck_v}(k_v-k_u)_+\le\int_{k_u}^{k_v}e^{-cs}ds\), followed by the same tail-product identity. No variance or normalizer-ratio assumption is used.

All node clocks satisfy r≥r0=\(M_0/M\ge1/2\). Integrating this bound over r∈[r0,r1] yields
\[
 \frac1{4\eta r_0}\int_{\eta n(1-r_1)}^{\eta n(1-r_0)}
 \frac{1-e^{-z}}z\,dz,
\]
which is at most \((2\eta)^{-1}\min\{Z,1+\log_+Z\}\), \(Z=\eta n(1-r_0)\). It remains a clock/overlap price with original hard-source costs. The additive \(\Delta\) is not the terminal logarithmic deficit, and one cannot replace one of their gates by the other.

**Screening conclusion.** The all-deficit weighted survivor statement and its actual early-node application are valid with their explicit common-normalizer costs. The overlap-score statement is also valid on its original node clock. Neither supplies the required global input-mass budget or any new signed credit. Await author proofs for integration review.

## Author and implementation review

Read all of `weighted_survival.md` (author version `a4cdd50a105cb43aa6b9531823632cc981a0e7e8bf75549eb96a60244e557db4`). **Pass for WS1–11 and the stated unpaid interface.** The proof retains one terminal H for all nested cost levels, the actual persistent set, the complete original normalizer and its outside deletions. Its rearrangement, Jensen, linear and Lp bounds are correct. WS8's rare-expensive-loss distribution gives a real strict endpoint improvement, with no claim that all such distributions satisfy original spatial/FULL constraints.

The actual node application uses \(T_M=\min(g^*/\gamma^2,h_M)\), an empty early branch without a past carrier, and the static common set \(Z_{T_M}\). The local-cap/QG minimum is the same physical column, and the hard source is included in F rather than redefined as an auxiliary posterior. All deficits are allowed, but the genuine H/loss/cost charge remains. The late slice is paid only by its stated global B cap. WS10 has the correct \(24e^4N_n\) coefficient; the old Gini bound and new endpoint price are two bounds on the same node, not two credits. If exact columns differ by leg/soft/orientation, the text correctly restores their finite sum rather than extracting a nonexistent common cost.

Read all of `score_overlap.md`. **Pass for SO2–15 on the stated actual node windows**, with the explicit nonempty-window qualification for its \(1/U\) comparison to be bound in the final version. The score/overlap connection is pointwise for the raw coordinate thresholds; the weighted Gini proof uses the same posterior twice and no regularity or degree-ratio hypothesis. The terminal singularity is canceled correctly, the Ein integral and constants are correct, and SO13/14 have the proper 18/24 factors. The auxiliary additive-deficit transfer uses \(\Delta_g\), not the unqualified large logarithmic-deficit complement. No original negative credit is used.

Independently extracted and executed the complete SO embedded script: **244 high-precision assertions passed**. Its per-r masks are pointwise posterior tests, not one certified nested deletion history; that distinction is immaterial to the pointwise lemma and does not certify FULL.

Statically reviewed the entire `weighted_checks.py`, raw JSON and numerical notes, then independently executed the complete script with a local mpmath 1.3.0 environment and external output path. It returned `complete 96 cost 18 clock 18 gini 60`; the **entire JSON was byte-identical** to the archive. The exact rational cost levels and independent sorted-mass rearrangement agree; zero-cost, zero-mass and empty-persistent-set branches avoid division by zero. The clock computations split every source threshold and outside deletion and retain the full current normalizer. The compressed huge-n Gini examples test the abstract score inequality, rather than claiming full n-coordinate spatial realizations. Precision agreement is numerical evidence, not an interval certificate. The three same-weight constant-cost models saturate the score-potential identity, not the original iid pair/FULL bound.

The archived numerical source/JSON hashes are `7f7347234c67f70a96883346165a6fbacecfc3fd6c51e25b7e35a423391e7c83` / `32ff8f6a2f0d1f06ce2886576b28a9d0ed7c01efaa376c426d41222d0b8133a0`. The author's three extra WS endpoint examples are reported finite model evidence; the main archived 96-case execution above is independently reproduced.

Read the main proof in full. Equations (1)–(9) have the correct measures, zero branches and constants. Equation (10) legitimately takes the minimum of two actual node upper bounds: the common-potential plus real late slice, and the independently retained score/QG-overlap clock price. The uniform F used there permits the common leg/menu factor; optional exact costs must keep their qualifying static-v dependence and any restored finite sums. Equation (11) follows from the already audited physical scale sum. The proof and report retain the beta/y integral, all j/nodes, real H and loss correlation, \(\sqrt K\), and shallow/near/terminal complements. None of these remaining fees has been declared paid.

## Final integration verdict — 2026-10-17, frozen

The final SO introduction and SO11 now explicitly restrict \(H(U)\le\min(1,2/(\eta U))\) to nonempty original windows \(0<U<n\log2\); the empty traffic branch is separate. This was a scope clarification, without changing the 244-check code. The parent proof also explicitly limits optional exact costs to a static function of the survivor source and certified capture data; a cut depending on t or the other posterior source remains in the original weighted integral. The report correctly states three score-potential equality examples and does not assert sharpness or realization of the original iid pair/FULL traffic.

Read the final report and statically reviewed `reproduce.py`. The report does not exceed the accepted estimates: it removes the uniform-deficit restriction by retaining the actual common endpoint charge, and preserves the unpaid spatial/source moment, H correlation, K and complementary branches. The driver copies the contract and self-contained numerical script into a fresh external directory, runs the complete 96-case computation, compares the **entire** JSON byte-for-byte and checks the manifest before and after. It inherits the recorded local mathematical environment. The parent's final package replay and external receipt occur after this freeze; this audit does not pre-claim that run.

**Final verdict: pass for the bounded R232 results; no outstanding requested correction.** The all-deficit common-survivor potential and weighted score/overlap bounds are valid original far-traffic interfaces with explicit costs. The independent complete 96-case JSON replay matched byte-for-byte, and the SO embedded 244 checks independently passed. No new source-density assumption, independent band normalization, negative credit or duplicate hard cap has been introduced. The arbitrary-positive-\(L^1\) global root endpoint remains unproved. Audit writing stops here.

Final reviewed SHA256 bindings (excluding this audit itself):

| File | SHA256 |
|---|---|
| task_contract.md | `58ddfbdb6629499cae42a4a4cadafa294c745705e7416a1ff6246e928c195357` |
| proof.tex.txt | `3f6f6c464ddb9aa40ae1d613887d56293744a67745606a1508d6463d8b53619c` |
| report.md | `d790a4282f8bc68394a6d613a4888821b0870fe09dd2b2f32c852f9ce5becf8a` |
| reproduce.py | `fe43e8d0e43544c24ceaacbc1f45987d8506e948042c2e624cc62d2a6df2053a` |
| weighted_survival.md | `a4cdd50a105cb43aa6b9531823632cc981a0e7e8bf75549eb96a60244e557db4` |
| score_overlap.md | `f8b037501e35178fec56203ebe974c2943e59e6bed5bf1bfc70dc32a4dd0d989` |
| weighted_checks.py | `7f7347234c67f70a96883346165a6fbacecfc3fd6c51e25b7e35a423391e7c83` |
| weighted_checks.json | `32ff8f6a2f0d1f06ce2886576b28a9d0ed7c01efaa376c426d41222d0b8133a0` |
| numeric_notes.md | `e87e06674391a740b0e09d49762713d8ccfae8180dc4e1a9995bb8aa24f67ca5` |
