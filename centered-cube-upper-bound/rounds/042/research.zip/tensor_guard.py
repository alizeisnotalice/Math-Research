#!/usr/bin/env python3
"""Exact finite guards for a bounded coordinate-selection decision certificate.
Source: (sum_{j=0}^{N-1} delta_j)^tensor d, positive weights throughout.
Fraction arithmetic decides every assertion. Decimal is presentation only.
No LP, sampling, fitting, or enormous source enumeration is performed.
"""
from fractions import Fraction as F
from decimal import Decimal as D, localcontext
from itertools import product
from pathlib import Path
import json


def fs(q):
    return str(q.numerator) if q.denominator == 1 else f'{q.numerator}/{q.denominator}'


def dd(q):
    with localcontext() as ctx:
        ctx.prec = 90
        z = D(q.numerator)/D(q.denominator)
        return '0' if z == 0 else format(z,'.28E')


def value(q, expression):
    result = {'decimal':dd(q), 'exact_expression':expression}
    if max(q.numerator.bit_length(), q.denominator.bit_length()) <= 1200:
        result['fraction'] = fs(q)
    else:
        result['numerator_bits'] = q.numerator.bit_length()
        result['denominator_bits'] = q.denominator.bit_length()
    return result


def interval_experiment(N, delta):
    assert N >= 2 and 0 <= delta <= F(1,2)
    L = 2*(1+delta)
    positions = list(map(F,range(N)))
    edges = sorted({y-L/2 for y in positions} | {y+L/2 for y in positions})
    cells = []
    conditional_rows = [F(0)]*N
    categories = {1:F(0),2:F(0),3:F(0)}
    for lo,hi in zip(edges[:-1],edges[1:]):
        x = (lo+hi)/2
        captured = tuple(j for j,y in enumerate(positions) if abs(x-y) < L/2)
        assert all(abs(x-y) != L/2 for y in positions)
        assert 1 <= len(captured) <= 3
        count = len(captured)
        numerator = sum((-1)**j for j in captured)
        posterior_parity = F(numerator,count)
        probability = (hi-lo)*count/(N*L)
        assert probability > 0
        for j in captured:
            conditional_rows[j] += (hi-lo)/L
        categories[count] += probability
        cells.append({'interval':(lo,hi), 'captured':captured,
                      'probability':probability, 'posterior_parity':posterior_parity})
    assert conditional_rows == [F(1)]*N
    assert sum(categories.values()) == 1
    s = 1/(N*(1+delta))
    t = 3*delta*(N-2)/(N*(1+delta))
    assert categories[1] == s and categories[3] == t
    assert categories[2] == 1-s-t
    assert all(abs(cell['posterior_parity']) == {1:F(1),2:F(0),3:F(1,3)}[len(cell['captured'])]
               for cell in cells)
    return cells,categories


def displayed_cells(cells):
    return [{'interval':list(map(fs,cell['interval'])),
             'captured_indices':list(cell['captured']),
             'positive_source_count':len(cell['captured']),
             'marginal_observation_probability':fs(cell['probability']),
             'posterior_parity_mean':fs(cell['posterior_parity'])} for cell in cells]


def decision_formula(N,d,delta):
    s = 1/(N*(1+delta))
    t = 3*delta*(N-2)/(N*(1+delta))
    C,A,B = (1-F(1,N))**d,(1-s)**d,(1-s-t)**d
    Va = 1-C/2
    Vb = 1-A/2+(A-B)/6
    gap = Vb-Va
    assert 0 <= Va <= 1 and 0 <= Vb <= 1 and 0 <= s+t <= 1
    return Va,Vb,gap,s,t,C,A,B


def enumerate_tensor(cells,d):
    histogram = {F(0):F(0),F(1,3):F(0),F(1):F(0)}
    count = 0
    for states in product(cells,repeat=d):
        probability = F(1)
        for state in states:
            probability *= state['probability']
        maximum = max(abs(state['posterior_parity']) for state in states)
        histogram[maximum] += probability
        count += 1
    assert sum(histogram.values()) == 1
    reward = sum(probability*(1+maximum)/2 for maximum,probability in histogram.items())
    return reward,histogram,count


def coordinate_case(N,delta):
    a_cells,a_categories = interval_experiment(N,F(0))
    b_cells,b_categories = interval_experiment(N,delta)
    Va,Vb,gap,s,t,C,A,B = decision_formula(N,1,delta)
    direct_a = sum(cell['probability']*(1+abs(cell['posterior_parity']))/2 for cell in a_cells)
    direct_b = sum(cell['probability']*(1+abs(cell['posterior_parity']))/2 for cell in b_cells)
    assert direct_a == Va and direct_b == Vb
    return {'N':N,'delta':fs(delta),'a':'2','b':fs(2*(1+delta)),
            'source_weights':'all positive and equal; prior 1/N',
            'a_boundary_cells':displayed_cells(a_cells),'b_boundary_cells':displayed_cells(b_cells),
            'a_count_category_probabilities':{str(k):fs(q) for k,q in a_categories.items()},
            'b_count_category_probabilities':{str(k):fs(q) for k,q in b_categories.items()},
            'a_singleton_probability':fs(F(1,N)),'b_singleton_probability':fs(s),
            'b_triple_probability':fs(t),'one_coordinate_Va':fs(Va),'one_coordinate_Vb':fs(Vb),
            'scope':'Full one-dimensional boundary partition, exact posterior and marginal probabilities; omitted exterior has zero observation probability.',
            'status':'PASS'}


def tensor_enumeration_case(N,d):
    delta = F(1,d)
    a_cells,_ = interval_experiment(N,F(0))
    b_cells,_ = interval_experiment(N,delta)
    direct_a,ha,count_a = enumerate_tensor(a_cells,d)
    direct_b,hb,count_b = enumerate_tensor(b_cells,d)
    Va,Vb,gap,s,t,C,A,B = decision_formula(N,d,delta)
    assert direct_a == Va and direct_b == Vb
    assert ha == {F(0):C,F(1,3):F(0),F(1):1-C}
    assert hb == {F(0):B,F(1,3):A-B,F(1):1-A}
    return {'N':N,'dimension':d,'delta':fs(delta),'source_atom_count':N**d,
            'tensor_a_states_enumerated':count_a,'tensor_b_states_enumerated':count_b,
            'direct_Va':fs(direct_a),'direct_Vb':fs(direct_b),'formula_Va':fs(Va),
            'formula_Vb':fs(Vb),'decision_gap':fs(gap),'decision_gap_decimal':dd(gap),
            'a_max_abs_posterior_histogram':{fs(k):fs(q) for k,q in ha.items()},
            'b_max_abs_posterior_histogram':{fs(k):fs(q) for k,q in hb.items()},
            'joint_TV_lower_from_this_reward':fs(max(F(0),gap)),
            'scope':'Every product of actual boundary-cell states is enumerated. The decision chooses one coordinate and its parity sign; no finite-grid quadrature.',
            'status':'PASS'}


def power_case(N,d,family):
    delta = F(1,d)
    Va,Vb,gap,s,t,C,A,B = decision_formula(N,d,delta)
    identity_upper = 1-(1/(1+delta))**d
    lower = max(F(0),gap)
    assert lower <= identity_upper
    return {'N':N,'dimension':d,'family':family,'delta':fs(delta),
            'source_cardinality_expression':f'{N}^{d}',
            'positive_source':'Product of N equally weighted positive integer-grid atoms in each coordinate.',
            'Va':value(Va,'1-(1-1/N)^d/2'),
            'Vb':value(Vb,'1-(1-s)^d/2+((1-s)^d-(1-s-t)^d)/6'),
            'decision_gap':value(gap,'(1-1/N)^d/2-(1-s)^d/3-(1-s-t)^d/6'),
            'joint_TV_lower':value(lower,'max(0,Vb-Va)'),
            'identity_kernel_joint_TV_upper':value(identity_upper,'1-(d/(d+1))^d'),
            's':fs(s),'t':fs(t),'constant_certificate_hypotheses_hold':N>=16*d,
            'scope':'Exact rational powers of the analytically proved cell probabilities; huge product sources are represented symbolically, not enumerated. Identity is an upper bound only.',
            'status':'PASS'}


def finite_constant_case(N,d,family):
    assert d >= 2 and N >= 16*d
    Va,Vb,gap,s,t,C,A,B = decision_formula(N,d,F(1,d))
    negative_term = -(A-C)/2
    positive_term = (A-B)/6
    assert A >= C and A-C <= F(d,N)
    assert negative_term >= -F(d,2*N) >= -F(1,32)
    assert A >= 1-d*s >= F(15,16)
    assert d*t >= F(15,8) and d*(s+t) >= F(15,8)
    assert B < F(1,4)
    rational_taylor_lower = 1+F(15,8)+F(15,8)**2/2
    assert rational_taylor_lower == F(593,128) > 4
    assert negative_term+positive_term == gap
    assert -F(1,32)+(F(15,16)-F(1,4))/6 == F(1,12)
    assert gap >= F(1,12)
    return {'N':N,'dimension':d,'family':family,
            'negative_term':value(negative_term,'-((1-s)^d-(1-1/N)^d)/2'),
            'positive_term':value(positive_term,'((1-s)^d-(1-s-t)^d)/6'),
            'A_lower_guard':value(A,'(1-s)^d >= 15/16'),
            'd_t':fs(d*t),'d_s_plus_t':fs(d*(s+t)),
            'B_upper_guard':value(B,'(1-s-t)^d < 1/4'),
            'decision_gap':value(gap,'Vb-Va >= 1/12'),
            'universal_rational_lower_under_hypotheses':'1/12',
            'exponential_step':'B <= exp(-d(s+t)) <= exp(-15/8) < 1/4; e^(15/8) > 1+15/8+(15/8)^2/2 = 593/128 > 4.',
            'scope':'Exact parameter checks for the proved finite certificate, not a numerical proof of its uniform validity.',
            'status':'PASS'}



def finite_experiment_small_certificate():
    def collapse(N,delta):
        cells,_ = interval_experiment(N,delta)
        labels = sorted({cell['captured'] for cell in cells})
        matrix = [[F(0) for _ in labels] for _ in range(N)]
        for cell in cells:
            column = labels.index(cell['captured'])
            for j in cell['captured']:
                matrix[j][column] += cell['probability']*N/len(cell['captured'])
        assert all(sum(row) == 1 for row in matrix)
        return labels,matrix
    labels_a,A = collapse(2,F(0))
    labels_b,B = collapse(2,F(1,2))
    assert labels_a == labels_b == [(0,),(0,1),(1,)]
    T = [[F(2,3),F(1,3),F(0)], [F(0),F(1),F(0)], [F(0),F(1,3),F(2,3)]]
    assert all(sum(row) == 1 and all(q >= 0 for q in row) for row in T)
    AT = [[sum(A[j][u]*T[u][v] for u in range(3)) for v in range(3)] for j in range(2)]
    tv = sum(abs(AT[j][v]-B[j][v]) for j in range(2) for v in range(3))/4
    assert AT == B and tv == 0
    return {'source':[0,1],'prior':['1/2','1/2'],'a':'2','b':'3',
            'labels':[list(q) for q in labels_a], 'A':[[fs(q) for q in row] for row in A],
            'B':[[fs(q) for q in row] for row in B],'T':[[fs(q) for q in row] for row in T],
            'AT':[[fs(q) for q in row] for row in AT], 'joint_TV':'0',
            'scope':'Actual finite conditional experiment, exact collapsed membership states and a feasible stochastic matrix. No LP solver required.', 'status':'PASS'}


def one_coordinate_parity_certificate():
    N,d,delta = 6,1,F(1,2)
    a_cells,_ = interval_experiment(N,F(0))
    b_cells,_ = interval_experiment(N,delta)
    Va = sum(cell['probability']*(1+abs(cell['posterior_parity']))/2 for cell in a_cells)
    Vb = sum(cell['probability']*(1+abs(cell['posterior_parity']))/2 for cell in b_cells)
    assert Vb-Va == F(1,12)
    old_square_bound = delta*(N-5)/(12*N*(1+delta))
    assert old_square_bound == F(1,216) < Vb-Va
    return {'N':N,'dimension':d,'delta':fs(delta),'Va_direct':fs(Va),'Vb_direct':fs(Vb),
            'bounded_parity_decision_joint_TV_lower':'1/12',
            'previous_square_risk_joint_TV_lower':fs(old_square_bound),
            'scope':'True positive six-atom prior; bounded parity classification reward. Strict lower bound on every garbling, not an optimal LP value.', 'status':'PASS'}


def general_scale_case(d,delta,label):
    assert d >= 1 and 0 < delta <= F(1,2)
    U = 1-(1+delta)**(-d)
    L = (1-((1-2*delta)/(1+delta))**d)/6
    x = d*delta
    minimum = min(x,F(1))
    assert U/6 <= L <= U
    assert x/(1+x) <= U <= minimum
    assert minimum/12 <= U/6 <= L
    approximants = []
    for multiplier in (8,32,128):
        N = multiplier*d
        Va,Vb,gap,s,t,C,A,B = decision_formula(N,d,delta)
        assert abs(gap-L) <= F(d,N)
        approximants.append({'N':N,'multiplier_of_d':multiplier,
                             'decision_gap':value(gap,'Va,Vb at finite N'),
                             'finite_gap_minus_limit_L':value(gap-L,'Delta_N-L'),
                             'absolute_gap_from_limit_L':value(abs(gap-L),'abs(Delta_N-L)'),
                             'proved_power_difference_error_upper':fs(F(d,N))})
    return {'dimension':d,'delta':fs(delta),'delta_label':label,'d_delta':fs(x),
            'limiting_product_prior_lower_L':value(L,'[1-((1-2delta)/(1+delta))^d]/6'),
            'identity_universal_upper_U':value(U,'1-(1+delta)^(-d)'),
            'U_over_6':value(U/6,'U/6 <= L'),
            'Bernoulli_lower_on_U':fs(x/(1+x)), 'coarse_lower_min_d_delta_over_12':fs(minimum/12),
            'coarse_upper_min_d_delta':fs(minimum),'finite_N_approximants':approximants,
            'scope':'Exact parameter guards for the analytic worst-prior interface L<=D<=U. L uses N->infinity, not a bound asserted for each fixed finite prior. Approximant errors are reported without assuming monotonicity.',
            'status':'PASS'}


def main():
    Ns = (2,3,5,6,8)
    coordinate = [coordinate_case(N,delta) for N in Ns for delta in (F(1,2),F(1,3),F(1,4),F(1,8))]
    enumerated = [tensor_enumeration_case(N,d) for N in Ns for d in (2,3,4)]
    dims = (2,4,8,16,32,64,128,512)
    powers = [power_case(N,d,family) for d in dims for family,N in
              (('fixed_N6',6),('N_equals_16d',16*d),('N_equals_d_squared',d*d))]
    finite = [finite_constant_case(mult*d,d,f'N_equals_{mult}d') for d in dims for mult in (16,17,32)]
    finite += [finite_constant_case(d*d,d,'N_equals_d_squared') for d in dims if d >= 16]
    tiny_experiment = finite_experiment_small_certificate()
    parity_certificate = one_coordinate_parity_certificate()
    general = []
    for d in (1,2,8,32,128):
        labels = [('fixed_1_2',F(1,2)),('fixed_1_8',F(1,8)),('fixed_1_32',F(1,32)),
                  ('inverse_dimension',F(1,d)),('inverse_dimension_squared',F(1,d*d))]
        for label,delta in labels:
            if delta <= F(1,2):
                general.append(general_scale_case(d,delta,label))
    with localcontext() as ctx:
        ctx.prec = 90
        limiting_gap = (1-(-D(3)).exp())/6
        limit_display = format(limiting_gap,'.28E')
    enum_gaps = [F(row['decision_gap']) for row in enumerated]
    finite_gaps = [decision_formula(row['N'],row['dimension'],F(1,row['dimension']))[2] for row in finite]
    summary = {'status':'PASS','executed_case_entries':len(coordinate)+len(enumerated)+len(powers)+len(finite)+len(general)+2,
               'exact_feasible_two_atom_matrix_certificates':1,
               'six_atom_one_coordinate_parity_certificates':1,
               'general_scale_limit_parameter_cases':len(general),
               'general_scale_finite_N_approximants':sum(len(row['finite_N_approximants']) for row in general),
               'finite_N_power_difference_error_guards_abs_gap_minus_L_le_d_over_N':sum(len(row['finite_N_approximants']) for row in general),
               'coordinate_boundary_cases':len(coordinate),
               'coordinate_boundary_cells_checked':sum(len(row['a_boundary_cells'])+len(row['b_boundary_cells']) for row in coordinate),
               'small_tensor_exact_enumeration_cases':len(enumerated),
               'small_tensor_a_states_enumerated':sum(row['tensor_a_states_enumerated'] for row in enumerated),
               'small_tensor_b_states_enumerated':sum(row['tensor_b_states_enumerated'] for row in enumerated),
               'fixed_and_growing_source_power_cases':len(powers),'finite_constant_parameter_cases':len(finite),
               'small_tensor_decision_gap_range_decimal':[dd(min(enum_gaps)),dd(max(enum_gaps))],
               'finite_constant_decision_gap_range_decimal':[dd(min(finite_gaps)),dd(max(finite_gaps))],
               'finite_constant_all_gaps_at_least':'1/12',
               'N_d_squared_analytic_limit_expression':'(1-exp(-3))/6',
               'N_d_squared_analytic_limit_decimal':limit_display,
               'fixed_N6_vs_growing_N_note':'Fixed N6 does not give the growing-source constant limit; the source is allowed to depend on dimension.',
               'scope':'Bounded decision certificate obstructs a universal O(1/d) joint-TV garbling interface. It does not obstruct the cube weak endpoint itself. Values derive from exact partitions and proved tensor formulas, not fits or an identity-kernel lower-bound claim.'}
    result = {'source':'mu=(sum_{j=0}^{N-1}delta_j)^tensor d; prior mu/N^d; a=2, b=2(1+delta), 0<delta<=1/2; fine family delta=1/d',
              'decision':'Action (i,sigma), 1<=i<=d, sigma in {-1,1}; reward 1{sigma=(-1)^Y_i} in [0,1].',
              'analytic_TV_certificate':'For every Markov kernel Xa -> Z, any target optimal decision has reward at most Va+TV((Y,Z),(Y,Xb)); therefore TV >= max(0,Vb-Va).',
              'posterior_fact':'Positive product prior and product noise give product posterior uniform on each coordinate captured index interval.',
              'exact_formulas':{'s':'1/[N(1+delta)]','t':'3delta(N-2)/[N(1+delta)]',
                                'Va':'1/2+[1-(1-1/N)^d]/2',
                                'Vb':'1/2+[1-(1-s)^d]/2+[(1-s)^d-(1-s-t)^d]/6'},
              'summary':summary,'coordinate_boundaries':coordinate,'small_tensor_full_enumeration':enumerated,
              'fixed_and_growing_sources':powers,'finite_constant_guard':finite,
              'two_atom_finite_experiment_matrix':tiny_experiment,
              'one_coordinate_six_atom_parity':parity_certificate,'general_scale_limit_guard':general}
    Path(__file__).with_name('results.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(summary,indent=2))


if __name__ == '__main__':
    main()
