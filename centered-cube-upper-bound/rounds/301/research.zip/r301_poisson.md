# R301 — legal intensity splitting and an optimized mixed Poisson receipt

## 1. Scope, units and the actual bridge being used

Keep the finite original positive L1 sources beta,nu, masses B,W_nu, the original receiver set E, fields p_y,L,R,q, and ALL original low-pe/high-m/history/source masks. Write q_-=3lambda/4 and

    U_y(u)=1_E(u)p_y(u)/q(u), I_y=integral U_y(u)du,
    kappa0=2K/(ell M), psi_inf=3-2/(3gamma^n).

Row intensities are finite by the existing full-soft physical envelope. Zero rows carry zero traffic. All source partitions below are frozen partitions by THIS actual I_y; no e_g,m, receiver selector or source law is recomputed.

Fix a target edge allocation for which the established covered/rank bridge grants, at rate t>0, a covered fee d integral C_t beta and a residual bounded by the Poisson rank integral. Use the SINGLE notation

    d=kappa0 psi_inf/(q_-v0),                           (1)

INCLUDING q_- in d. In the basic ordered-capture construction the rank bridge is valid on L>=R with v0=1. Any independently proved qualified v0 extension must supply the same bridge; FIRST alone does not extend the rank integral to unqualified L<R. The inequalities below concern that target. The low-intensity payment itself is valid on all orientations.

Here d and I_y have units reciprocal to a source density, t has density units, d t and t I_y are dimensionless, and lambda h is dimensionless for an intensity threshold h. In particular no additional division by q_- occurs in d.

## 2. Poisson capacity and its exact rank relation

Take a Poisson process of witnesses with finite intensity t U_y(u)du, so its mean count is t I_y. Let M_t(z) be its smallest capturing hard radius, infinity if none captures, and set

    A_yz(r)=integral 1{R(u)<=r,z in Q_(R(u))(u)}U_y(u)du,
    C_t(y)=E integral M_t(z)^(-n)1{M_t(z)<infinity}nu(dz).

The failure probability is exp(-t A_yz(r)). The exact layer-cake capacity formula is

    C_t(y)=b^(-n)integral[1-exp(-t A_yz(b))]nu(dz)
       +n integral_a^b r^(-n-1)
                        integral[1-exp(-t A_yz(r))]nu(dz)dr. (2)

With the inclusive cumulative intensity A, the R300 atomic argument applies to g_t(s)=(1-exp(-ts))/t. Thus

    J_t(y):=integral nu(dz)integral r^(-n)exp(-t A_yz(r))dA_yz(r)
       <=C_t(y)/t.                                    (3)

The difference is EXACTLY the nonnegative sum over intensity atoms s of r^(-n)[g_t(A(r))-g_t(A(r-))-exp(-t A(r))Delta A(r)], integrated against nu. Equality holds for nonatomic captured-radius intensity. No normalization by I_y is inserted into (3).

The original hard cap at each actual witness gives C_t<=4lambda t I_y. If B_infinity(y) is the true limiting minimum-radius capacity from R300, then also

    C_t(y)<=min{4lambda t I_y,
                    B_infinity(y)[1-exp(-t I_y)]}.      (4)

Indeed any nonempty configuration has capacity at most B_infinity, while the probability of a nonempty Poisson process is 1-exp(-t I_y). This is a genuine saturation bound with its actual source capacity retained; no uniform bound on B_infinity is assumed.

## 3. The companion Jensen input, with its source mass explicit

For any frozen original beta subset S of mass B_S>0, the independently derived FIRST/Jensen capacity bound is

    integral_S C_t(y)beta(dy)
       <=t W_nu G_A(t a^n/B_S), A=(b/a)^n,              (5)
    G_A(u)=(1-exp(-u))/u+integral_1^A exp(-uv)dv/v.

For units and source conservation, its short underlying observation is

    integral_S A_yz(r)beta(dy)
       =integral_E 1{R<=r,z in Q_R(u)}
                        [integral_S p_y(u)beta(dy)/q(u)]du
       <=r^n.

Jensen in the SAME subset S is applied before (2). The full actual receiver expression on the middle line can be retained for a sharper occupancy bound. This note uses (5) as the companion input, not as a separate new geometric breakthrough. Replacing B_S immediately by B recovers a global mass logarithm of the type already present in R296.

The following positive representation makes all endpoint claims stable:

    G_A(u)=(1/u)integral_(1<=s<=A) [1-exp(-us)]eta_A(ds),
    eta_A(ds)=s^(-2)1_[1,A](s)ds+A^(-1)delta_A(ds).     (6)

Eta_A is a probability measure and its mean is 1+log A. Thus G_A decreases, uG_A increases, and

    G_A(0+)=1+log A,  uG_A(u)->1 as u->infinity,
    G_A(u)<=min{1+log A,1/u,
                         1+exp(-1)+log_+(1/u)}.        (7)

The logarithmic bound follows by splitting integral_1^infinity exp(-uv)dv/v at v=1/u when u<1; the remaining exponential tail is <=exp(-1). Formula (6) follows by one integration by parts and is exact also at A=1, where eta is delta_1.

## 4. Legal low-I payment and the mixed high-I cost

For a frozen h>=0 partition ORIGINAL beta into

    S_lo(h)={I_y<=h}, S_hi(h)={I_y>h},
    B_hi(h)=beta(S_hi(h)),
    L(h)=4lambda integral_(S_lo(h)) I_y beta(dy).

The actual hard cap at the ORIGINAL receiver, BEFORE any extension, proves for the ENTIRE low-row traffic

    T_lo<=L(h)<=4lambda h beta(S_lo(h)).                (8)

It is unnecessary to spend a Poisson source fee on these rows. Original FIRST gives the exact legal high-mass bound

    h B_hi(h)<=integral_(S_hi(h)) I_y beta(dy)
       <=integral I_y beta(dy)<=|E|,                  h>0. (9)

No source density or source ordering is inferred from (9).

On the high rows only, combine the established covered fee d integral C_t beta with the matching rank residual (3). This yields the NEW mixed intensity-distribution receipt

    T_target<=L(h)+(d+1/t) integral_(S_hi(h)) C_t beta
       <=L(h)+(1+d t)W_nu G_A(t a^n/B_hi(h)).           (10)

The first line also permits the stronger TRUE saturation source cost

    integral_(S_hi(h)) min{4lambda t I_y,
                       B_infinity(y)(1-exp(-t I_y))}beta(dy) (11)

instead of the Jensen cost. It is an independently computed capacity/intensity function, not an assumed small cover. If the actual weighted B_infinity budget is favorable, (11) can be strictly better. Its size is not guaranteed by FIRST.

There is only ONE low/high split and ONE hard-source fee W_nu in (10). Different thresholds are alternative valid bounds; their W_nu fees are not summed. All other original outer factors multiply the selected raw receipt once.

## 5. Scalar rate optimization and a single threshold parameter

For alpha>=0 define the exact positive scalar optimization

    H_A(alpha)=inf_(u>0) (1+alpha u)G_A(u).             (12)

For B_hi>0 put alpha=d B_hi/a^n and u=t a^n/B_hi. Then (10) gives

    T_target<=inf_(h>=0){L(h)+W_nu H_A(d B_hi(h)/a^n)}. (13)

Zero high mass contributes zero, not a quotient. The endpoint values in (12) are 1+log A at u down to zero, and alpha at u to infinity. With these endpoints it is a minimization of a continuous function on a compactified interval, so the infimum is well defined and may occur at an endpoint. Infinite-rate endpoints mean limits of valid finite-rate inequalities; no infinite-intensity witness process is postulated.

For A=1 the exact answer is

    H_1(alpha)=min(1,alpha).                            (14)

Indeed (1/u+alpha)(1-exp(-u)) is at least alpha for alpha<=1 and at least one for alpha>=1, using exp(u)>=1+u; its two endpoints attain those values.

For alpha>0, a useful explicit rate is the SAME t=1/d for every row and threshold. Equations (15)-(16), which contain 1/alpha, are used only on this domain; the B_hi=0 case remains separately zero as above. It corresponds to u=1/alpha, giving the genuinely one-parameter threshold receipt

    T_target<=inf_h {L(h)+2W_nu G_A(a^n/(d B_hi(h)))}.  (15)

The common-rate oracle factor two is consistent with the main common-rate note: if u<=1/alpha, monotonicity gives G_A(u)>=G_A(1/alpha); if u>=1/alpha, monotonicity of uG_A gives alpha uG_A(u)>=G_A(1/alpha). Hence

    G_A(1/alpha)<=H_A(alpha)<=2G_A(1/alpha).            (16)

This is a scalar verification, not an additional source allocation. In particular

    H_A(alpha)<=min{1+log A,alpha,
                    2[1+exp(-1)+log_+alpha]}.          (17)

Thus the best scalar bound has a finite exact endpoint, a linear small-mass endpoint, and a logarithmic middle regime, with no hidden n-count. The direct nonlinear optimization can be evaluated from

    G_A(u)=(1-exp(-u))/u+E1(u)-E1(Au),
    G_A'(u)=[exp(-u)-1+u exp(-Au)]/u^2.

No uniqueness of an interior minimizer is assumed.

## 6. Exactly when this gives a paid mixed branch

For any chosen h, if lambda h<=H and

    log_+(d B_hi(h)/a^n)<=J,

then (8),(13),(17) give the explicit source payment

    T_target<=4H beta(S_lo(h))
                    +2[1+exp(-1)+J]W_nu.              (18)

Root-polylog H,J therefore pay that branch by a root-polylog coefficient. These are verifiable conditions on the original intensity distribution and the actual high-intensity source mass; they have NOT been established uniformly for arbitrary inputs. Relation (9) supplies B_hi<=|E|/h if one wants to verify them from receiver data, but that substitution leaves the genuine ratio

    d |E|/(h a^n),

rather than proving it small. A finite receiver truncation and separately proved entry are required for any subsequent absorption. This note makes no unconditional root claim.

The real profile gain in (13) is that very large ORIGINAL beta mass at tiny I_y is charged its actual small L(h), while only B_hi enters the high-source logarithm. Coarsening B_hi to B and L(h) to a loose total bound can erase this gain and merely reproduce R296's global concentration logarithm. The exact occupancy term preceding (5) or the real B_infinity term (11) can improve it further, but neither is silently assumed small.

The target must retain its rank qualification. The low-row payment (8) is valid for all traffic; unqualified high-row L<R traffic remains outside (10)-(18) unless the independent matching covered/rank bridge in Section 1 has actually been proved. No Poisson reparametrization alone resolves that mismatch.

## 7. Actual bounded scalar diagnostics

A local 40-digit mpmath run checked 28 cases: log A=0,log2,log1024,100 and alpha=10^(-6),0.01,0.1,1,3,100,10^6. It evaluated the positive optimization, exact A=1 endpoints, bound (17), and the common-rate factor-two comparison. All passed. A scalar intensity-profile evaluation, with B_lo=10^6,I_lo=10^(-12),B_hi=1,I_hi=1,lambda=1,q_-=0.75,a=1,d=4/3,W_nu=1,log A=100, gave an unsplit optimized coefficient 18.3795439245033919 and a split fee 1.33333733333333333. This evaluates the proved fee formulas; it is not asserted to realize a full original low/m cube instance or to certify a global scalar minimum by interval arithmetic.

Only this Markdown deliverable was written. The following actual-run reproduction uses a log-rate grid and local golden-section refinement, and writes no files.

```python
import sys
try:
    import mpmath as mp
except ImportError:
    sys.path.insert(0,'/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor')
    import mpmath as mp
mp.mp.dps=40
def G(u,T):
    return -mp.expm1(-u)/u+(mp.e1(u)-mp.e1(u*mp.exp(T)) if T else 0)
def optimize(T,alpha):
    f=lambda z:(1+alpha*mp.exp(z))*G(mp.exp(z),T)
    grid=[mp.mpf(-40)+mp.mpf(j)/4 for j in range(321)]
    vals=[f(z) for z in grid];best=min(1+T,alpha)
    for j in range(1,len(grid)-1):
        if vals[j]<=vals[j-1] and vals[j]<=vals[j+1]:
            left,right=grid[j-1],grid[j+1];gr=(mp.sqrt(5)-1)/2
            x=right-gr*(right-left);y=left+gr*(right-left)
            fx=f(x);fy=f(y)
            for _ in range(90):
                if fx<fy:
                    right,y,fy=y,x,fx
                    x=right-gr*(right-left);fx=f(x)
                else:
                    left,x,fx=x,y,fy
                    y=left+gr*(right-left);fy=f(y)
            best=min(best,fx,fy)
    return best
count=0
for T in [mp.mpf(0),mp.log(2),mp.log(1024),mp.mpf(100)]:
    for alpha in map(mp.mpf,['.000001','.01','.1','1','3','100','1e6']):
        val=optimize(T,alpha);explicit=2*G(1/alpha,T)
        assert val<=min(1+T,alpha,explicit)+mp.mpf('1e-30')
        assert explicit<=2*val+mp.mpf('1e-28')
        bound=min(1+T,alpha,2*(1+mp.exp(-1)+max(0,mp.log(alpha))))
        assert val<=bound+mp.mpf('1e-28')
        if not T:assert abs(val-min(1,alpha))<mp.mpf('1e-30')
        count+=1
unsplit=optimize(mp.mpf(100),mp.mpf('1000001')/mp.mpf('.75'))
mixed=mp.mpf('0.000004')+optimize(mp.mpf(100),1/mp.mpf('.75'))
print('PASS positive-mixture scalar optimization and endpoints=',count)
print('single profile bound: unsplit=',mp.nstr(unsplit,18),
      'split=',mp.nstr(mixed,18))
```
