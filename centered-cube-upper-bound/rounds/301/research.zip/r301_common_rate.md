# R301: one implementable Poisson rate achieves the coupling oracle within two

Fix the complete original outer field and original finite positive L1 sources beta,nu. Retain actual q>=q_-=3lambda/4, a<=L,R<=b, original FIRST, hard caps and complete low,m>M/history/source masks. Fix v0>0 and target the original v(L,R)=min(1,(L/R)^(n/2))>=v0 branch. Put

 d=kappa0 psi_inf/(q_- v0)>0.

The case of zero target or zero source is handled directly. No division by a zero source mass is used.

Let alpha(x,y) be a measurable original row gate in [0,1], independent of the hard source z, with original target mask I0(x,y,z)<=alpha(x,y). Define U_y(x)=alpha(x,y)1_E(x)p_y(x)/q(x), I_y=integral U_y dx, and

 A_yz(r)=integral 1{R(x)<=r,z in Q_(R(x))(x)}U_y(x)dx.

The R301 geometry theorem uses actual Poisson witnesses with intensity tU_y dx and gives, for EVERY ONE common t>0,

 T_target <= F(t):=(d+1/t) C(t),
 C(t)=integral beta(dy)nu(dz){b^-n[1-exp(-t A_yz(b))]
              +n integral_a^b r^(-n-1)[1-exp(-t A_yz(r))]dr}. (1)

The rank measure in this argument is dA, not the normalized dF; no I_y is dropped. Original low/high heights are used before the receiver envelope is enlarged. The exact original outer multiplier must still be applied.

## 1. The coupled oracle and a common rate that actually realizes its bound

Introduce the finite positive measure

 dOmega=beta(dy)nu(dz)[b^-n delta_b(dr)+n r^(-n-1)1_(a,b)(r)dr].

Its total mass is a^-n W_beta W_nu. It is an auxiliary exact layercake measure, not a replacement for receiver Lebesgue measure. Then C(t)=integral[1-exp(-tA)]dOmega. Define the explicit positive coupling cost

 O_d=integral min(d,A_yz(r))dOmega.                       (2)

It is finite. All values in (2) are given by the ORIGINAL sources and receiver field, with the chosen original row gate. It is not an asserted remainder norm or a guessed dimension bound.

For every d>0,A>=0,t>0 the scalar inequalities are

 min(d,A) <= (d+1/t)[1-exp(-tA)],
 (d+d)[1-exp(-A/d)] <=2min(d,A).                         (3)

For the first, write x=tA,y=td. If x<=y, use (1+y)(1-exp(-x))>=(1+x)(1-exp(-x))>=x, the last by exp(x)>=1+x. If x>=y, lower 1-exp(-x) to 1-exp(-y) and apply the same argument with y. For the second use 1-exp(-u)<=min(1,u). Zero A satisfies both by equality. Therefore

 O_d <= inf_(t>0) F(t) <= F(1/d) <= 2 O_d,
 T_target <= F(1/d) <= 2 O_d.                           (4)

Thus a SINGLE common implementable rate t=1/d achieves within factor two the lower bound obtained by allowing each coupling-layer value to choose its own scalar limiting cost. The pointwise infimum over t is min(d,A), attained as a limit t down to0 or up toinfinity depending on A versus d. We do not exchange that infimum with the integral to claim equality. In fact (4) proves a factor-two guarantee for the best common-rate bound, without requiring that the optimal rate exist.

Crucially O_d is a lower bound for the family of Poisson UPPER BUDGETS F(t), not a lower bound for actual T_target. The valid actual estimate is the second line of (4). No independently chosen favorable rate for each actual edge has been inserted into the original witness construction.

The exact split O_d=d Omega{A>=d}+integral_{A<d}A dOmega retains the strong and weak coupling expenses. Their combined root-order source estimate is NOT proved by this split.

## 2. Keep actual row geometry before any cross-row Jensen step

The clipping min(d,A) takes place before integrating beta, unlike replacing the whole row family by its total beta mass and a full receiver cube. This preserves variation of actual overlap across sources. For each row put

 O_d(y)=integral nu(dz)[b^-n min(d,A_yz(b))
                     +n integral_a^b r^-n-1 min(d,A_yz(r))dr].

The original actual hard cap separately gives T_y<=4lambda I_y. The rowwise version of (4) gives T_y<=2O_d(y). Hence the simultaneous original bound is

 T_target<=integral min{4lambda I_y,2O_d(y)}beta(dy).     (5)

Both row quantities are measurable, so selecting the cheaper estimate rowwise adds no source copies or stopping multiplicity. Formula (5) is an unconditional fixed-field upper estimate on the stated original target branch; it is not a claim that its right side is universally root-order. The low-I/high-I split in the companion note is a computable coarsening of the available row choices, with its own displayed fees.

If alpha is restricted further to another admissible gate alpha'<=alpha that STILL dominates the same target mask, then A'<=A pointwise. Thus C'(t)<=C(t), O'_d<=O_d and I'_y<=I_y. The proofs apply anew to the same target with U'. This proves genuine monotone improvement of all budgets (1),(4),(5) without claiming that the capture probability itself increases. A gate depending on z would not define one common row witness law and is not licensed by this statement.

## 3. Scope of the new result

The point is an implementable constant-factor optimization of the actual coupled budget, together with a legitimate actual-row baseline. The purely scalar optimization does not supply the missing geometry. Coarsening A by full cube volume after beta integration recovers the older source-log estimate; that coarsening is not registered as a new root-order result. To complete the original goal one must bound the actual coupled cost (5), or the companion occupancy budget, by root-polylog times the original source ledger and pay the complementary aspect and outer branches.

A01 fractional-normalization discipline is used for positive parameters, zero rows and the distinction between a pointwise oracle and a common realizable parameter. No external minimax or transport strong-duality theorem is invoked. Finite local computations test the scalar inequalities and true-cell source/receiver geometry separately; they do not establish the all-input dimension exponent.
