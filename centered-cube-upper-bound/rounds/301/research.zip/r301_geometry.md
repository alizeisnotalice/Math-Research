# R301 — a common-rate Poisson cross-row budget from the actual FIRST response

## 1. Precise proved improvement and its scope

Keep the complete original low-pe,m>M positive traffic and all R299/R300 hypotheses. In particular beta,nu are arbitrary finite positive L1 sources; a<=L,R<=b<=2a; q_-=3lambda/4<=q<=lambda; E is the original accepted receiver set; original FIRST and the original maximal hard cap hold there. Original e_g,m, common selected s,L,R, unique band and every history/source/terminal mask are unchanged. Set

    kappa0=2K/(ell M), psi_inf=3-2/(3gamma^n), gamma=1+1/n,
    U_y(u)=alpha(u,y)1_E(u)p_y(u)/q(u), I_y=integral U_y du,
    v(L,R)=min(1,(L/R)^(n/2)).

Here alpha(u,y) is any original measurable row mask in [0,1], independent of z, satisfying I0(x,y,z)<=alpha(x,y) on the target branch. Alpha=1 is always legal. More efficiently it may retain the ORIGINAL low-pe,m>M row qualifications and the target aspect gate v>=v0; their full e_g and m are evaluated from the original sources and never recomputed. All pair-dependent qualifications remain in I0. Only genuinely z-independent row qualifications may be put in alpha.

The full-soft bound I_y<=S/q_-, S=(1+n log(b/a))Csoft_n, ensures finiteness. The construction below DOES NOT normalize U_y by I_y. Keeping alpha is a source-cost improvement on the entire same target branch, not a new capture gate leaving additional target traffic unpaid.

Choose a single rate t>0, fixed across all beta rows for this outer instance. Define actual cumulative capture

    A_yz(r)=integral 1{R(u)<=r}1{z in Q_(R(u))(u)}U_y(u)du,
    A_z(r)=integral A_yz(r)beta(dy).

Let W=W_beta>0. If W=0 all traffic and prices are zero. Define the explicit cross-row profile

    L_t = W b^(-n)integral [1-exp(-t A_z(b)/W)]nu(dz)
       + W n integral_a^b r^(-n-1)
                   integral [1-exp(-t A_z(r)/W)]nu(dz)dr.       (1)

Then, for any 0<v0<=1, the ORIGINAL actual aspect branch satisfies

    T_{v>=v0} <=[kappa0 psi_inf/(q_-v0)+1/t] L_t.                (2)

The same theorem has a sharper exact source cost C_t<=L_t in place of L_t, defined in section 2. In contrast to the R300 fixed-count ledger, (2) contains neither an individual I_y multiplier nor a separate stopping time or sample count on each row. It uses a single actual cross-row cumulative FIRST response A_z(r). All hard-source integration is performed once.

The actual FIRST identity gives

    A_z(r)=integral_{E,R(u)<=r,z in Q_(R(u))(u)} f(u)du,
    f(u)=integral alpha(u,y)p_y(u)beta(dy)/q(u)<=1,
    0<=A_z(r)<=r^n.                                           (3)

Thus (1) can retain actual receiver occupancy and actual subunit FIRST response. It is not a source-density bound on nu, beta, or their ratio. This is the completed general cross-row estimate. A universal root bound for (1), or the corresponding exact cost, is NOT proved. Section 5 identifies exactly the loss incurred when only (3)'s crude last inequality is used.

## 2. Unnormalized common-rate witnesses and their true source cost

For each y use the finite Poisson receiver intensity t U_y(u)du, of total mass t I_y. Every sampled receiver is original accepted; radii are its actual R(u). If I_y=0, the configuration is empty and the row has zero traffic. For a nonempty finite configuration, assign each captured z to its containing witness of minimum radius, ties by index. The source pieces D_i are frozen during the actual traffic receiver integral. Define

    B_t(y)=E integral max_i[r_i^(-n)1_cube_i(z)]nu(dz),
    C_t=integral B_t(y)beta(dy).                              (4)

The probability of at least one capturing witness of radius <=r is exactly 1-exp(-t A_yz(r)). Therefore

    B_t(y)=b^(-n)integral [1-exp(-t A_yz(b))]nu(dz)
       +n integral_a^b r^(-n-1)
                   integral [1-exp(-t A_yz(r))]nu(dz)dr.       (5)

It is bounded by the first-moment cost

    B_t(y)<=t integral U_y(u)h_(R(u))*nu(u)du
           <=4lambda t I_y.                                 (6)

This bound proves integrability because integral I_y beta<=S W/q_- is finite. Equation (4), rather than the last crude bound in (6), preserves true source overlap and repeated-capture savings.

Apply the R299 single-witness penalty

    chi_r(L,R)=min{1,(L/r)^(n/2)min[1,(R/r)^(3n/2)]}

to each minimum-radius source piece. For each finite configuration let Hmax be its maximum chi-weighted capture. The exact configuration source fee is sum_i r_i^(-n)Psi_G((b/r_i)^n)nu(D_i), so averaging gives

    T_(E Hmax)<=(kappa0 psi_inf/q_-)C_t.                      (7)

Poisson expectations mean the ordinary nonnegative series over m>=0, with weight exp(-tI_y)/m! and product intensity (tU_y du)^m. Measurability follows from this explicit series; no measurable global choice of a random configuration is needed. Each configuration is finite almost surely. Positive Tonelli justifies the sum, even before the finite upper bound (6) is inserted.

## 3. The common rate cancels the row normalization in the rank payment

Push U_y(u)1_capture du forward by actual R(u), obtaining a finite measure alpha_yz on [a,b] with inclusive CDF A_yz. Its total mass is not required to be <=1. The actual miss factor is exp(-t A_yz(R)). Define

    J_t(y)=integral nu(dz)integral r^(-n)
                                   exp(-t A_yz(r))alpha_yz(dr).

At an atom of mass d with CDF endpoints A-,A, the nonnegative deficit is

    [exp(-tA-)-exp(-tA)]/t-exp(-tA)d>=0.

The nonatomic quantile identity and these atom intervals imply

    J_t(y)<=B_t(y)/t.                                       (8)

There is equality in (8) for atomless capture-radius measures; the inclusive endpoint at an atom only improves the inequality. Thus no radius-tie convention is silently changing the rank measure.

For each actual edge, a witness of radius r<=R has chi_r(L,R)>=v(L,R). The averaged max mask therefore satisfies

    E Hmax>=v(L,R)[1-exp(-t A_yz(R))].

On v>=v0 this gives the pointwise domination

    1<=(E Hmax)/v0+exp(-t A_yz(R)).                          (9)

Multiply (9) by the original positive traffic. The first term uses (7)/v0. In the second term, retain actual U_y dx, hard normalization R^(-n), and hard support, then drop remaining nonnegative masks. It is bounded by integral J_t beta<=C_t/t. Hence

    T_{v>=v0}<=[kappa0 psi_inf/(q_-v0)+1/t]C_t.               (10)

There is no I_y left in the residual fee because the intensity is tU_y, not a fixed count under U_y/I_y. The rank term does not pay 1/v0. The source allocation and scale penalty are justified for each configuration before averaging; the final actual-x-dependent mask is not incorrectly treated as a source-only frozen mask.

## 4. FIRST across rows: Jensen and the retained geometry

For each fixed r,z, concavity of 1-exp(-t x) under the probability beta/W gives

    integral [1-exp(-t A_yz(r))]beta(dy)
                 <=W[1-exp(-t A_z(r)/W)].                   (11)

Integrating (11) in the positive layer formula (5) proves C_t<=L_t and therefore (2). Identity (3) follows by positive Tonelli from the ORIGINAL kernels with the admissible original row mask alpha; restricted FIRST follows from alpha<=1. Since every receiver counted by A_z(r) has R(u)<=r and z in Q_(R(u))(u), it lies in Q_r(z). This proves A_z(r)<=r^n without assigning a density cap to either source.

There is an unconditional monotone localization improvement before applying Jensen. Denote by U^all the choice alpha=1 and by a star the choice of an admissible original alpha. Pointwise A^*_yz(r)<=A^all_yz(r), hence

    B_t^*(y)<=B_t^all(y), C_t^*<=C_t^all, L_t^*<=L_t^all. (11a)

Nevertheless (2),(10) still pay the SAME entire original target branch: its density is bounded by U^*_y(x)h_R(x-z), since I0<=alpha, so the Poisson-rank argument is valid with dA^*, without discarding any target edge. This removes unrelated accepted receiver witnesses at no additional fee and no newly introduced target complement. The cost decrease in C_t is strict whenever A^*<A^all on a set of positive beta-by-nu measure carrying positive endpoint/layer weight. Even without strictness, it never worsens the proved bound. A reduced capture probability by itself is not used as domination of the old one; the rank proof is rerun using the smaller legitimate actual row measure. The original e_g and all positive source and outer budgets stay fixed.

This differs from selecting an arbitrary helpful receiver subset: if I0<=alpha has not been proved, that replacement is not allowed. In particular no z-dependent forbidden-source condition may be moved into alpha and then used as though the witness probability were common to all hard sources.

For precision the exact Jensen loss at each r,z is

    Jgap_t(r,z)=integral exp(-t A_yz(r))beta(dy)
                             -W exp(-t A_z(r)/W)>=0.

Consequently C_t equals L_t minus the positive layer integral of Jgap_t, with endpoint weight b^(-n) and density n r^(-n-1). Source-row variation may therefore further improve the true cost; Jensen does not assume that every source has its average capture profile.

There is also an explicit actual-occupancy gain relative to the full-cube estimate in the next section: its layer integrand is

    W[exp(-t A_z(r)/W)-exp(-t r^n/W)]>=0.                  (12)

Both improvements retain original source and receiver geometry. The final bound can use L_t without computing Jgap_t, or keep C_t when the true row profiles are available. Merely naming a positive deficit does not prove it has root size; no lower bound for these deficits is asserted.

## 5. Explicit scalar envelope, comparison with the known baseline, and the gap

Put A=(b/a)^n and c=t a^n/W. Replacing A_z(r) by r^n in (1), changing variable v=(r/a)^n, and integrating by parts gives the exact scalar upper bound

    L_t<=t Xi(c,A) W_nu,
    Xi(c,A)=(1-exp(-c))/c+integral_1^A exp(-cv)dv/v.       (13)

Indeed the unsimplified expression is

    (1-exp(-cA))/(cA)
                 +integral_1^A [1-exp(-cv)]/(cv^2)dv,

which equals Xi. Endpoints A=1 and all c>0 are included. In particular

    Xi(c,A)<=1+log A=A_n,
    Xi(c,A)<=1+log_+(1/c)+1/e,
    Xi(c,A)<=1/c when c>=1.                              (14)

For the second inequality split at v=1/c when c<1 and bound the remaining integral by integral_1^infinity exp(-u)du=1/e; for c>=1 the third follows from integral_c^infinity exp(-u)du/u<=exp(-c)/c. These are ordinary positive estimates, not claims about asymptotic equality.

For example t=q_-v0/(kappa0 psi_inf) in (10),(13) yields

    T_{v>=v0}<=2 Xi(q_-v0 a^n/(kappa0 psi_inf W),A)W_nu. (15)

The coarse consequence of (15) has logarithmic dependence on the global normalized beta mass, while retaining the cap A_n. That order is already available from earlier R296 column estimates. It is NOT registered here as a new global root theorem. The new cross-row information is (1)-(3),(10)-(12), including the cost-monotone whole-target row localization (11a), before discarding actual occupancy and row variation.

The actual first-moment bridge, including the same admissible row mask, is also recovered exactly:

    integral I_y B_1(y)beta(dy)
      =integral_E f(u)h_(R(u))*nu(u)du
      <=min{A_n W_nu,4lambda|E|},                        (16)

where B_1 is the one-witness normalized-pi cost for this same row measure, as in R300, not B_t. Equation (6) and (16) alone would give C_t<=t A_n W_nu. Formula (13) is always no larger, and the actual profile (1) can be still smaller. Neither inequality turns the worst A_n factor into root order on arbitrary inputs.

A precise sufficient condition for a desired source-linear price P is

    [kappa0 psi_inf/(q_-v0)+1/t]L_t
                                      <=P(W_beta+W_nu). (17)

Here L_t is the explicit original FIRST/capture profile (1), with no stopping variables or per-row source charges left. Condition (17) is not presumed. A future geometric proof must either control this profile (or the smaller true C_t) uniformly at root-polylog cost for some common t, or use the Jensen/occupancy deficits quantitatively, while also paying v<v0. The known caps alone permit A_z(r) up to r^n and provide no demonstrated root deficit. This is the concrete remaining inequality for THIS transfer.

No new beta/nu domination, density bound, unsupported source cube cap, independent band sum, or replacement of original e_g is used. The complement of the aspect branch is the original traffic with v<v0. All estimates are conditional on the original outer variable xi; the original positive factor Lambda(xi) multiplies (2) or (10) inside its existing source/clock ledger. There is no free reintegration over xi.

## 6. Actual bounded checks

A local run passed 36 finite atomic Poisson-rank comparisons and 12 cross-row Jensen/layer comparisons using Python math double precision with the displayed 1e-13 comparison tolerance. Separately, 12 scalar-envelope identities passed using mpmath at 45-digit working precision with the displayed 1e-35 tolerance. A further 16 admissible-row Poisson cost monotonicity checks, including strict and equal cases, used Python math double precision and the direct comparisons shown in the code. These test small, intermediate and large Poisson rates and endpoint/nontrivial scale ranges. The finite checks support the algebra; they do not prove a root estimate for arbitrary original input. Reproducible code follows and writes no files.

```python
from fractions import Fraction as F
import math
counts={'poisson_rank':0,'crossrow_jensen':0,'scalar':0}
for n in [1,2,8]:
 for t in [.01,.5,3,20]:
  rs=[1,1.5,2]
  rowA=[[.05,.25,.4],[.2,.2,.6],[0,.1,.15]]
  beta=[.5,1,1.5]; W=sum(beta)
  C=0;upper=0
  for amounts,w in zip(rowA,beta):
   old=0; B=0;J=0
   for r,a in zip(rs,amounts):
    B+=r**(-n)*(math.exp(-t*old)-math.exp(-t*a))
    J+=r**(-n)*math.exp(-t*a)*(a-old);old=a
   assert J<=B/t+1e-13
   C+=w*B;counts['poisson_rank']+=1
  mean=[sum(w*A[j] for w,A in zip(beta,rowA))/W for j in range(3)]
  f=[W*(-math.expm1(-t*x)) for x in mean]
  upper=rs[-1]**(-n)*f[-1]+sum((rs[i]**(-n)-rs[i+1]**(-n))*f[i] for i in range(2))
  assert C<=upper+1e-13;counts['crossrow_jensen']+=1
try:import mpmath as mp
except ImportError:
 import sys
 sys.path.insert(0,'/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor')
 import mpmath as mp
mp.mp.dps=45
for c0 in ['.0001','.01','1','100']:
 for A0 in ['1','2','1000']:
  c=mp.mpf(c0); A=mp.mpf(A0)
  left=(-mp.expm1(-c*A))/(c*A)+mp.quad(lambda v:(-mp.expm1(-c*v))/(c*v*v),[1,A])
  right=(-mp.expm1(-c))/c+mp.quad(lambda v:mp.exp(-c*v)/v,[1,A])
  assert abs(left-right)<mp.mpf('1e-35')
  assert right<=1+mp.log(A)+mp.mpf('1e-35')
  counts['scalar']+=1
print('PASS',counts)
count=0
for t in [.01,.5,3,20]:
 for a,b in [(0,.2),(.1,.2),(.2,.2),(.3,2)]:
  assert -math.expm1(-t*a)<=-math.expm1(-t*b)
  if a<b:assert -math.expm1(-t*a)<-math.expm1(-t*b)
  count+=1
print('PASS admissible-row Poisson cost monotonicity:',count)
```

Only /tmp/r301_geometry.md was written. Other author files, prior frozen proofs and Git state were not changed.
