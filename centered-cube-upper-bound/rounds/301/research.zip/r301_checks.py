#!/usr/bin/env python3
"""R301 real L1 cube kernels: FIRST-coupled receiver law and iid cost ledgers."""
import json,random,sys
try:
 import mpmath as mp
except ImportError:
 sys.path.insert(0,"/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor")
 import mpmath as mp
from pathlib import Path
from fractions import Fraction as F
from decimal import Decimal as D,localcontext
R=random.Random(30120261018);FAIL=[];COUNTS={};MENU=[1,2,4,8,16,32,64];EPS=F(1,8)
def ck(ok,label,data):
 COUNTS[label]=COUNTS.get(label,0)+1
 if not ok:FAIL.append({'test':label,'exact_data':data})
def dd(x):return D(x.numerator)/D(x.denominator)
def cellvol(h,n):return F(2*h,32)**n

def make(name,n,kind):
 if kind=='disjoint':
  X=[(0,0),(128,0),(256,0)];eh=[1,2,1];ls=[32]*3;rs=[32]*3
  Y=[(v,4) for v in [4,132,260,452]];Z=list(Y)
 elif kind=='chain':
  X=[(-16,0),(0,0),(16,0)];eh=[1,2,1];ls=[32,48,64];rs=[32,32,48]
  Y=[(v,4) for v in [-28,-12,4,20,36,100]];Z=list(Y)
 else:
  X=[(0,0),(16,0),(0,16),(16,16)];eh=[1,2,2,1] if n>=8 else [1,2,1,2]
  ls=[32,48,64,32];rs=[48,32,64,48]
  if kind=='tied':ls=rs=[32]*4
  Y=[(x,y) for x in [-12,4,20,36] for y in [-12,4,20,36]]
  Z=[(-12,-12),(4,4),(20,4),(4,20),(20,20),(36,20),(100,100)]
 if n==1:X=[[x] for x,y in X];Y=[[x] for x,y in Y];Z=[[x] for x,y in Z]
 else:X=[list(v)+[0]*(n-2) for v in X];Y=[list(v)+[4]*(n-2) for v in Y];Z=[list(v)+[4]*(n-2) for v in Z]
 def incidence(points,sides,label):
  A=[]
  for i,(x,s,h) in enumerate(zip(X,sides,eh)):
   row=[]
   for j,z in enumerate(points):
    inside=all(2*(abs(a-b)+h+1)<=s for a,b in zip(x,z));outside=any(2*(abs(a-b)-h-1)>s for a,b in zip(x,z))
    ck(inside or outside,label,{'case':name,'receiver':i,'source_cell':j});row.append(int(inside))
   A.append(row)
  return A
 soft=incidence(Y,ls,'exact_soft_pair_whole_inside_or_outside');hard=incidence(Z,rs,'exact_hard_pair_whole_inside_or_outside')
 for tag,points,hs in [('E',X,eh),('Y',Y,[1]*len(Y)),('Z',Z,[1]*len(Z))]:
  ck(all(any(abs(z[k]-w[k])>=hs[j]+hs[l] for k in range(n)) for j,z in enumerate(points) for l,w in enumerate(points[:j])),'positive_cells_disjoint_'+tag,{'case':name})
 vol=[cellvol(h,n) for h in eh];L=[F(s,32) for s in ls];rr=[F(s,32) for s in rs]
 br=[F(R.randint(1,10),R.randint(1,10)) for _ in Y];vr=[F(R.randint(1,10),R.randint(1,10)) for _ in Z]
 bresp=[sum(v*a for v,a in zip(br,row))/l**n for row,l in zip(soft,L)];bscale=1/max(bresp);beta=[bscale*v for v in br]
 vresp=[sum(v*a for v,a in zip(vr,row))/r**n for row,r in zip(hard,rr)];vscale=4/max(vresp);nu=[vscale*v for v in vr]
 first=[sum(v*a for v,a in zip(beta,row))/l**n for row,l in zip(soft,L)];hardresp=[sum(v*a for v,a in zip(nu,row))/r**n for row,r in zip(hard,rr)]
 for i,(f,h) in enumerate(zip(first,hardresp)):
  ck(f<=1,'actual_FIRST_q1',{'case':name,'receiver':i,'response':str(f)})
  ck(h<=4,'actual_same_radius_hardcap_lambda1',{'case':name,'receiver':i,'response':str(h)})
 I=[sum(vol[i]*soft[i][j]/L[i]**n for i in range(len(X))) for j in range(len(Y))]
 pi=[[vol[i]*soft[i][j]/L[i]**n/ij if ij else F(0) for i in range(len(X))] for j,ij in enumerate(I)]
 ck(sum(b*ij for b,ij in zip(beta,I))==sum(v*f for v,f in zip(vol,first))<=sum(vol),'FIRST_integrated_rowI_identity',{'case':name})
 return {'name':name,'n':n,'X':X,'Ehalf':eh,'Y':Y,'Z':Z,'L':L,'R':rr,'soft':soft,'hard':hard,'vol':vol,'beta':beta,'nu':nu,'first':first,'hardresp':hardresp,'I':I,'pi':pi}

def rowcosts(case,j):
 pi=case['pi'][j];n=case['n'];groups=[]
 for z in range(len(case['nu'])):
  d={}
  for i,r in enumerate(case['R']):
   if case['hard'][i][z] and pi[i]:d[r]=d.get(r,F(0))+pi[i]
  prev=F(0);g=[]
  for r,p in sorted(d.items()):g.append((r,prev,prev+p,p));prev+=p
  groups.append(g)
 B={};J={}
 for N in range(1,66):
  b=jj=F(0)
  for mass,g in zip(case['nu'],groups):
   for r,left,right,p in g:
    b+=mass/r**n*((1-left)**N-(1-right)**N);jj+=mass/r**n*(1-right)**N*p
  B[N]=b;J[N]=jj
  ck(b<=4*N,'true_conditional_BN_le_4N',{'case':case['name'],'source_row':j,'N':N})
 for N in range(1,65):
  ck(J[N]<=B[N+1]/(N+1),'true_conditional_J_budget',{'case':case['name'],'source_row':j,'N':N})
  ck(0<=B[N+1]-B[N]<=J[N],'true_conditional_increment',{'case':case['name'],'source_row':j,'N':N})
 direct2=F(0)
 for i in range(len(pi)):
  for k in range(len(pi)):
   cost=F(0)
   for z,mass in enumerate(case['nu']):
    hit=[case['R'][t] for t in [i,k] if case['hard'][t][z]]
    if hit:cost+=mass/min(hit)**n
   direct2+=pi[i]*pi[k]*cost
 ck(direct2==B[2],'conditional_B2_exact_receiver_pair_enumeration',{'case':case['name'],'source_row':j})
 cap=next((N for N in range(1,65) if B[N]/(4*N)<=EPS),None);dyad=next((N for N in MENU if B[N]/(4*N)<=EPS),None)
 sharp=next((N for N in range(1,65) if J[N]<=4*EPS),None);budget=next((N for N in range(1,65) if B[N+1]/(N+1)<=4*EPS),None)
 if cap and dyad:ck(B[cap]<=B[dyad]<=2*B[cap],'conditional_dyadic_true_cost_two_approx',{'case':case['name'],'source_row':j})
 return B,J,{'capacity':cap,'dyadic_capacity':dyad,'sharp_J':sharp,'J_budget':budget}

def rate_oracle(case,actual):
 # Stieltjes atoms implement b^-n endpoint + n integral r^-n-1 dr exactly.
 n=case['n'];b=F(2);levels=sorted(set([F(1),b]+case['R']));atoms={};raw=zero=0
 for j,beta in enumerate(case['beta']):
  for k,nu in enumerate(case['nu']):
   for l,h in list(zip(levels,levels[1:]))+[(b,None)]:
    w=beta*nu*(l**(-n)-(h**(-n) if h else F(0)))
    A=sum(case['vol'][i]*case['soft'][i][j]/case['L'][i]**n*case['hard'][i][k] for i,r in enumerate(case['R']) if r<=l)
    cumulative=sum(case['pi'][j][i]*case['hard'][i][k] for i,r in enumerate(case['R']) if r<=l)
    ck(A==case['I'][j]*cumulative,'oracle_exact_A_equals_I_cumulative_probability',{'case':case['name'],'j':j,'k':k,'r':str(l)})
    ck(w>=0 and A>=0,'oracle_nonnegative_atom',{'case':case['name']})
    atoms[A]=atoms.get(A,F(0))+w;raw+=1;zero+=int(A==0)
 ck(sum(atoms.values())==sum(case['beta'])*sum(case['nu']),'oracle_exact_Omega_mass',{'case':case['name']})
 ck(sum(A*w for A,w in atoms.items())==actual,'oracle_exact_linear_traffic_identity',{'case':case['name']})
 records=[];maxerr=mp.mpf(0)
 def mm(x):return mp.mpf(x.numerator)/x.denominator
 for d in [F(1,16),F(1),F(16)]:
  O=sum(w*min(d,A) for A,w in atoms.items());vals=[]
  for prec in [40,60]:
   with mp.workdps(prec):
    row=[]
    for k in range(-6,7):
     t=F(2)**k/d;value=(mm(d)+1/mm(t))*mp.fsum(mm(w)*(-mp.expm1(-mm(t*A))) for A,w in atoms.items())
     tol=mp.mpf('1e-30')*mm(O) if O else mp.mpf(0)
     ck(value+tol>=mm(O),'oracle_F_ge_exact_O_ordinary_mp',{'case':case['name'],'d':str(d),'k':k,'precision':prec})
     if k==0:ck(value<=2*mm(O)+tol,'oracle_rate_one_over_d_le_two_O_ordinary_mp',{'case':case['name'],'d':str(d),'precision':prec})
     row.append(value)
    vals.append(row)
  with mp.workdps(70):
   errors=[abs(a-z)/max(abs(z),mp.mpf('1e-1000')) for a,z in zip(*vals)];error=max(errors);maxerr=max(maxerr,error)
   ck(error<mp.mpf('1e-30'),'oracle_mp_40_60_refinement',{'case':case['name'],'d':str(d),'relative_error':mp.nstr(error,12)})
   best=min(range(13),key=lambda i:vals[1][i]);records.append({'d':str(d),'exact_O':str(O),'finite_grid_best_k':best-6,'finite_grid_best_F_over_O':mp.nstr(vals[1][best]/mm(O),32) if O else '0','F_one_over_d_over_O':mp.nstr(vals[1][6]/mm(O),32) if O else '0','grid_F_60digits':[mp.nstr(x,60) for x in vals[1]],'max_relative_40_60_error':mp.nstr(error,12)})
 return {'scope':'Exact finite radial Stieltjes atoms from these same FIRST-induced receiver laws. Ordinary mpmath comparisons are finite numerical evidence, not interval certification or continuous rate optimization.','a':'1','b':'2','raw_atoms':raw,'raw_zero_A_atoms':zero,'distinct_A_atoms':len(atoms),'zero_A_weight':str(atoms.get(F(0),F(0))),'atoms':[{'A':str(A),'Omega_weight':str(w)} for A,w in sorted(atoms.items())],'rate_grid':'t=2^k/d, k=-6,...,6; d=1/16,1,16','records':records,'max_relative_40_60_error':mp.nstr(maxerr,12)}

def verify(case):
 name=case['name'];n=case['n'];E=sum(case['vol']);beta=case['beta'];I=case['I'];nu=case['nu'];Rr=case['R'];soft=case['soft'];vol=case['vol'];L=case['L'];pi=case['pi']
 groupnames=['I_zero','I_over_E_le_1_over_4','I_over_E_le_1_over_2','I_over_E_gt_1_over_2']
 groups={g:{'rows':[],'beta_mass':F(0),'beta_I_mass':F(0),'fees':{N:F(0) for N in MENU},'stopfees':{k:F(0) for k in ['capacity','dyadic_capacity','sharp_J','J_budget']},'unmet':{k:0 for k in ['capacity','dyadic_capacity','sharp_J','J_budget']}} for g in groupnames}
 rows=[];Bweighted={N:F(0) for N in MENU};stopweighted={k:F(0) for k in ['capacity','dyadic_capacity','sharp_J','J_budget']}
 for j,(bj,ij,p) in enumerate(zip(beta,I,pi)):
  ratio=ij/E;ck(0<=ratio<=1,'exact_rowI_group_range',{'case':name,'row':j,'I_over_E':str(ratio)})
  g=groupnames[0 if not ij else 1 if ratio<=F(1,4) else 2 if ratio<=F(1,2) else 3];group=groups[g];group['rows'].append(j);group['beta_mass']+=bj;group['beta_I_mass']+=bj*ij
  if not ij:
   ck(all(not x for x in p),'inactive_source_row_zero_probability',{'case':name,'row':j});rows.append({'row':j,'I':str(ij),'I_over_E':str(ratio),'group':g,'pi':[str(x) for x in p],'stops':None});continue
  ck(sum(p)==1,'actual_soft_kernel_pi_normalization',{'case':name,'row':j});B,J,stops=rowcosts(case,j)
  direct=sum(p[i]*case['hardresp'][i] for i in range(len(p)));ck(direct==B[1],'B1_actual_receiver_hard_response_identity',{'case':name,'row':j})
  for N in MENU:group['fees'][N]+=bj*ij*B[N];Bweighted[N]+=bj*ij*B[N]
  for k,v in stops.items():
   if v:group['stopfees'][k]+=bj*ij*B[v];stopweighted[k]+=bj*ij*B[v]
   else:group['unmet'][k]+=1
  rows.append({'row':j,'I':str(ij),'I_over_E':str(ratio),'group':g,'pi':[str(x) for x in p],'B1':str(B[1]),'B64':str(B[64]),'stops':stops})
 actual=sum(v*f*h for v,f,h in zip(vol,case['first'],case['hardresp']));ck(actual==Bweighted[1],'real_kernel_traffic_equals_beta_I_B1',{'case':name,'actual':str(actual),'row_sum':str(Bweighted[1])})
 ck(actual<=4*E,'real_kernel_traffic_le_4E_volume',{'case':name,'traffic':str(actual),'E_volume':str(E)})
 for N in MENU:ck(Bweighted[N]<=4*N*sum(b*ij for b,ij in zip(beta,I))<=4*N*E,'coupled_weighted_BN_budget',{'case':name,'N':N})
 # This finite E also gives a stronger exact restricted column test; log An is only numerical data.
 columns=[sum(vol[i]*case['hard'][i][z]/Rr[i]**n for i in range(len(vol))) for z in range(len(nu))]
 ck(all(c<=1 for c in columns) and actual<=sum(nu),'finite_E_exact_coarse_nu_comparison',{'case':name})
 logvals=[]
 for dp in [40,60]:
  with localcontext() as c:
   c.prec=dp;An=1+D(n)*D(2).ln();receipt=An*dd(sum(nu));ck(dd(actual)<=receipt,'numerical_An_nu_comparison',{'case':name,'precision':dp});logvals.append((+An,+receipt))
 with localcontext() as c:
  c.prec=90;err=max(abs(a-b)/max(D(1),abs(b)) for a,b in zip(*logvals));ck(err<D('1e-30'),'An_decimal_precision_refinement',{'case':name})
 outputgroups=[]
 for g,v in groups.items():outputgroups.append({'group':g,'source_rows':v['rows'],'beta_mass':str(v['beta_mass']),'sum_beta_I':str(v['beta_I_mass']),'weighted_BN_fees':{str(N):str(x) for N,x in v['fees'].items()},'weighted_stop_fees_met_rows_only':{k:str(x) for k,x in v['stopfees'].items()},'unmet_stop_rows':v['unmet']})
 return {'common_rate_oracle':rate_oracle(case,actual),'name':name,'dimension':n,'receiver_cells':len(vol),'beta_source_cells':len(beta),'nu_source_cells':len(nu),'receiver_volume':str(E),'beta_masses':[str(x) for x in beta],'nu_masses':[str(x) for x in nu],'FIRST_responses':[str(x) for x in case['first']],'same_radius_hard_responses':[str(x) for x in case['hardresp']],'sum_beta_I':str(sum(b*ij for b,ij in zip(beta,I))),'sum_beta_I_over_E':str(sum(b*ij for b,ij in zip(beta,I))/E),'actual_traffic':str(actual),'four_E_volume':str(4*E),'traffic_over_four_E':str(actual/(4*E)),'weighted_BN_fee_over_four_E':{str(N):str(x/(4*E)) for N,x in Bweighted.items()},'weighted_stop_fees_met_rows_only':{k:str(v) for k,v in stopweighted.items()},'weighted_stop_fee_over_four_E_met_rows_only':{k:str(v/(4*E)) for k,v in stopweighted.items()},'unmet_stop_rows_total':{k:sum(g['unmet'][k] for g in groups.values()) for k in stopweighted},'coarse_An_ordinary_decimal':str(logvals[1][0]),'coarse_An_nu_receipt_ordinary_decimal':str(logvals[1][1]),'coarse_log_precision_error':str(err),'rowI_groups':outputgroups,'rows':rows,'geometry':{'coordinate_denominator':32,'receiver_centers_num':case['X'],'receiver_halfwidth_num':case['Ehalf'],'beta_cell_centers_num':case['Y'],'nu_cell_centers_num':case['Z'],'source_halfwidth_num':1,'L':[str(x) for x in L],'R':[str(x) for x in Rr],'soft_receiver_by_beta_incidence':soft,'hard_receiver_by_nu_incidence':case['hard']}}
settings=[('initial',[('disjoint_n1',1,'disjoint'),('overlap_chain_n1',1,'chain')]),('boundary_coupled_source',[('cross_n4',4,'cross'),('tied_n4',4,'tied')]),('expanded',[('cross_n8',8,'cross'),('cross_n16',16,'cross')])]
stages=[{'name':stage,'cases':[verify(make(name,n,kind)) for name,n,kind in specs]} for stage,specs in settings]
out={'status':'PASS' if not FAIL else 'FAIL','seed':30120261018,'scope':'True finite positive-volume L1 source/receiver cells and actual s=0 product cube kernels. All receiver/source cell pairs are wholly inside or strictly outside with both halfwidths included. beta and nu masses rescaled to FIRST q=1 and actual same-radius hard caps4 on every receiver cell. Conditional pi is induced by the same actual soft source kernel, never chosen independently. No full m/e_g, low/high or continuous maximal-hard-cap history is asserted; no general n-order claim.','source_realization':'Constant nonnegative densities on each disjoint positive-volume source cell with the given exact masses. Whole-cell incidences also make the identities valid for arbitrary within-cell L1 densities of those masses.','I':'I_j=sum_i |E_i| L_i^-n soft_incidence_ij','pi':'pi_ji=|E_i| L_i^-n soft_incidence_ij/I_j; zero for inactive I_j=0','identity':'sum_j beta_j I_j B1_j=sum_i |E_i| FIRST_i*(h_Ri*nu)_i<=4|E|','rowI_grouping':'Frozen by I_j/|E|:0,(0,1/4],(1/4,1/2],(1/2,1]. a=1.','stop_epsilon':'1/8','stop_search':'all integerN1..64; dyadic1,2,4,8,16,32,64. J_budget=Bnext/(N+1) is not sharp exact J. Unmet row fees are excluded and explicitly counted, never treated as paid.','check_counts':COUNTS,'failures':FAIL,'stages':stages}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,sort_keys=True,indent=2)+'\n');print(json.dumps({'status':out['status'],'check_counts':COUNTS,'failures':FAIL,'cases':[{'name':c['name'],'n':c['dimension'],'traffic_over_4E':c['traffic_over_four_E'],'rowI_groups':[(g['group'],len(g['source_rows'])) for g in c['rowI_groups']]} for s in stages for c in s['cases']]},indent=2))

assert not FAIL, "R301 finite checks failed; inspect JSON exact_data"
