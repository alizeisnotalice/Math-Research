from fractions import Fraction as F
import math
counts={'poisson_rank':0,'crossrow_jensen':0,'scalar':0}
for n in [1,2,8]:
 for t in [.01,.5,3,20]:
  rs=[1,1.5,2]
  rowA=[[.05,.25,.4],[.2,.2,.6],[0,.1,.15]]
  beta=[.5,1,1.5]; W=sum(beta)
  C=0;upper=0
  for amounts,w in zip(rowA,beta):
   old=0; B=0;J=0
   for r,a in zip(rs,amounts):
    B+=r**(-n)*(math.exp(-t*old)-math.exp(-t*a))
    J+=r**(-n)*math.exp(-t*a)*(a-old);old=a
   assert J<=B/t+1e-13
   C+=w*B;counts['poisson_rank']+=1
  mean=[sum(w*A[j] for w,A in zip(beta,rowA))/W for j in range(3)]
  f=[W*(-math.expm1(-t*x)) for x in mean]
  upper=rs[-1]**(-n)*f[-1]+sum((rs[i]**(-n)-rs[i+1]**(-n))*f[i] for i in range(2))
  assert C<=upper+1e-13;counts['crossrow_jensen']+=1
try:import mpmath as mp
except ImportError:
 import sys
 sys.path.insert(0,'/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor')
 import mpmath as mp
mp.mp.dps=45
for c0 in ['.0001','.01','1','100']:
 for A0 in ['1','2','1000']:
  c=mp.mpf(c0); A=mp.mpf(A0)
  left=(-mp.expm1(-c*A))/(c*A)+mp.quad(lambda v:(-mp.expm1(-c*v))/(c*v*v),[1,A])
  right=(-mp.expm1(-c))/c+mp.quad(lambda v:mp.exp(-c*v)/v,[1,A])
  assert abs(left-right)<mp.mpf('1e-35')
  assert right<=1+mp.log(A)+mp.mpf('1e-35')
  counts['scalar']+=1
print('PASS',counts)
count=0
for t in [.01,.5,3,20]:
 for a,b in [(0,.2),(.1,.2),(.2,.2),(.3,2)]:
  assert -math.expm1(-t*a)<=-math.expm1(-t*b)
  if a<b:assert -math.expm1(-t*a)<-math.expm1(-t*b)
  count+=1
print('PASS admissible-row Poisson cost monotonicity:',count)
