#!/usr/bin/env python3
"""Large-I real s=0 concentric shell diagnostic; no full history claim."""
import json,sys,hashlib
from pathlib import Path
from fractions import Fraction as F
try: import mpmath as mp
except ImportError:
 sys.path.insert(0,'/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor')
 import mpmath as mp
if hasattr(sys,'set_int_max_str_digits'):sys.set_int_max_str_digits(0)
counts={};fail=[]
def ck(ok,label,data):
 counts[label]=counts.get(label,0)+1
 if not ok:fail.append({'test':label,'data':data})
def mm(x):return mp.mpf(x.numerator)/x.denominator
def run(n):
 delta=F(1,100*n);m=4*n;L=[1+F(i,m) for i in range(m+1)]
 volumes=[];prev=F(0)
 for l in L:
  now=(l-2*delta)**n;volumes.append(now-prev);prev=now
 I=sum(v/l**n for v,l in zip(volumes,L));pi=[v/l**n/I for v,l in zip(volumes,L)]
 ck((2*delta)**n>0,'positive_volume_common_beta_nu_support',{'n':n})
 ck(sum(volumes)==(2-2*delta)**n,'exact_shell_volume_telescope',{'n':n})
 ck(sum(pi)==1 and all(p>0 for p in pi),'exact_FIRST_induced_probability',{'n':n})
 ck(I*I>n,'exact_I_greater_than_sqrt_n',{'n':n})
 ck(I>1,'exact_large_I',{'n':n})
 for i,l in enumerate(L):
  ck((l-2*delta)/2+delta==l/2,'whole_source_receiver_support_in_actual_cube',{'n':n,'shell':i})
  ck(l**(-n)<=1,'exact_actual_FIRST_q1',{'n':n,'shell':i})
  ck(4*l**(-n)<=4,'exact_actual_same_radius_hardcap',{'n':n,'shell':i})
 actual=4*sum(v/l**(2*n) for v,l in zip(volumes,L))
 B1=4*sum(p/l**n for p,l in zip(pi,L))
 ck(actual==I*B1,'exact_FIRST_cross_traffic_identity',{'n':n})
 ck(B1<=4 and actual<=4*sum(volumes),'exact_B1_and_traffic_caps',{'n':n})
 cumul=[];a=F(0)
 for p in pi:cumul.append((a,a+p));a+=p
 ck(a==1 and all(0<=x<y<=1 for x,y in cumul),'exact_cumulative_rank_partition',{'n':n})
 rows=[]
 for N in [1,2,4,8]:
  # Rank probabilities exact Fractions. Their weighted radius expectation
  # is evaluated at two ordinary precisions to avoid huge fraction sums.
  ranks=[(1-x)**N-(1-y)**N for x,y in cumul]
  ck(all(p>=0 for p in ranks) and sum(ranks)==1,'exact_minimum_rank_probability',{'n':n,'N':N})
  ck(all(l**(-n)<=1 for l in L),'exact_rankwise_BN_le_four',{'n':n,'N':N})
  if N==8:ck(sum(ranks)==1 and all(p>=0 and l**(-n)<=1 for p,l in zip(ranks,L)) and F(4,32)==F(1,8),'exact_N8_stop_certificate',{'n':n})
  vals=[]
  for dp in [40,60]:
   with mp.workdps(dp):
    B=4*mp.fsum(mm(p)/mm(l)**n for p,l in zip(ranks,L));vals.append(B)
    ck(0<=B<=4+mp.mpf('1e-35'),'ordinary_mp_BN_le_four',{'n':n,'N':N,'precision':dp})
    if N==8:ck(B/32<=mp.mpf(1)/8+mp.mpf('1e-35'),'ordinary_mp_strong_capacity_stop_N8',{'n':n,'precision':dp})
  with mp.workdps(70):
   err=abs(vals[0]-vals[1])/max(abs(vals[1]),mp.mpf('1e-100'));ck(err<mp.mpf('1e-30'),'BN_40_60_refinement',{'n':n,'N':N})
   if N==1:ck(abs(vals[1]-mm(B1))<mp.mpf('1e-50'),'numeric_B1_matches_exact_fraction',{'n':n})
   rows.append({'N':N,'B_N':mp.nstr(vals[1],60),'b_N_over_N':mp.nstr(vals[1]/(4*N),60),'relative_40_60_error':mp.nstr(err,12)})
 with mp.workdps(60):
  return {'dimension':n,'shell_count':m+1,'source_halfwidth':str(delta),'common_beta_nu_source_volume':str((2*delta)**n),'beta_mass':'1','nu_mass':'4','I':mp.nstr(mm(I),60),'I_over_sqrt_n':mp.nstr(mm(I)/mp.sqrt(n),60),'exact_I_greater_than_sqrt_n':I*I>n,'exact_I_fraction':str(I),'traffic':mp.nstr(mm(actual),60),'traffic_over_four_receiver_volume':mp.nstr(mm(actual)/(4*mm(sum(volumes))),60),'B1_exact_fraction':str(B1),'rank_definition':'F_i=sum_{k<=i} |E_k| L_k^-n/I; probability minimum captured radius is L_i equals (1-F_(i-1))^N-(1-F_i)^N','B_N_scope':'Rank probabilities and B_N<=4 certificate are exact Fraction; displayed weighted sums are ordinary mpmath40/60, not interval arithmetic. Every witness captures all of the same positive-volume nu source.','N8_stop_exact_certificate':'B8<=4 since rank probabilities sum1 and all radii>=1, hence b8/8=B8/32<=1/8.','values':rows}
cases=[run(n) for n in [16,32]]
out={'status':'PASS' if not fail else 'FAIL','scope':'Two actual s=0 concentric receiver-shell models. Source beta and nu share a positive-volume cube; masses1 and4; q=lambda=a=1,b=2. Shells have disjoint interiors and complete source/receiver incidences, including both halfwidths. Only actual FIRST and same-radius hard caps are asserted. Full maximal hard caps and original low-m/e_g histories are not implemented. No general dimension-order claim.','construction':'delta=1/(100n),m=4n,L_i=R_i=1+i/m,i=0..m; E0=Q_(1-2delta),Ei=Q_(L_i-2delta)\\Q_(L_(i-1)-2delta). Centered cubes; Q denotes side length. beta and nu support Q_(2delta).','check_counts':counts,'failures':fail,'cases':cases}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,sort_keys=True,indent=2)+'\n')
print(json.dumps({'status':out['status'],'check_counts':counts,'cases':[{k:c[k] for k in ['dimension','shell_count','I','I_over_sqrt_n','traffic','values']} for c in cases]},indent=2))
assert not fail,fail
