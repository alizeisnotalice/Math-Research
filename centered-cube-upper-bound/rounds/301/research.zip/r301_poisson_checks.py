import sys
try:
    import mpmath as mp
except ImportError:
    sys.path.insert(0,'/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor')
    import mpmath as mp
mp.mp.dps=40
def G(u,T):
    return -mp.expm1(-u)/u+(mp.e1(u)-mp.e1(u*mp.exp(T)) if T else 0)
def optimize(T,alpha):
    f=lambda z:(1+alpha*mp.exp(z))*G(mp.exp(z),T)
    grid=[mp.mpf(-40)+mp.mpf(j)/4 for j in range(321)]
    vals=[f(z) for z in grid];best=min(1+T,alpha)
    for j in range(1,len(grid)-1):
        if vals[j]<=vals[j-1] and vals[j]<=vals[j+1]:
            left,right=grid[j-1],grid[j+1];gr=(mp.sqrt(5)-1)/2
            x=right-gr*(right-left);y=left+gr*(right-left)
            fx=f(x);fy=f(y)
            for _ in range(90):
                if fx<fy:
                    right,y,fy=y,x,fx
                    x=right-gr*(right-left);fx=f(x)
                else:
                    left,x,fx=x,y,fy
                    y=left+gr*(right-left);fy=f(y)
            best=min(best,fx,fy)
    return best
count=0
for T in [mp.mpf(0),mp.log(2),mp.log(1024),mp.mpf(100)]:
    for alpha in map(mp.mpf,['.000001','.01','.1','1','3','100','1e6']):
        val=optimize(T,alpha);explicit=2*G(1/alpha,T)
        assert val<=min(1+T,alpha,explicit)+mp.mpf('1e-30')
        assert explicit<=2*val+mp.mpf('1e-28')
        bound=min(1+T,alpha,2*(1+mp.exp(-1)+max(0,mp.log(alpha))))
        assert val<=bound+mp.mpf('1e-28')
        if not T:assert abs(val-min(1,alpha))<mp.mpf('1e-30')
        count+=1
unsplit=optimize(mp.mpf(100),mp.mpf('1000001')/mp.mpf('.75'))
mixed=mp.mpf('0.000004')+optimize(mp.mpf(100),1/mp.mpf('.75'))
print('PASS positive-mixture scalar optimization and endpoints=',count)
print('single profile bound: unsplit=',mp.nstr(unsplit,18),
      'split=',mp.nstr(mixed,18))
