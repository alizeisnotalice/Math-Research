# R301 independent preauthor screen

Only /tmp/r301_audit.md is owned here. No R301 author file was read before saving this screen. All original R299/R300 low-pe,m>M, accepted, history/source gates, q, FIRST and same-radius hardcaps remain. Finite original positive L1 beta,nu; actual receiver Lebesgue dx; a<=L,R<=b<=2a; q_-=3lambda/4. This is fixed-field analysis, with original outer multipliers/entry/source-clock ledger still required.

## 1. Exact cross-row FIRST ledger

Let U_y(x)=1_E(x)p_y(x)/q(x), I_y=integral U_y dx, and pi_y=U_y dx/I_y on nonzero rows. Put H(x)=h_(R(x))*nu(x), F(x)=integral U_y(x)beta(dy)<=1_E(x). The one-witness capacity is B_1(y)=integral H(x)pi_y(dx). Positive Tonelli gives EXACTLY

    integral I_y B_1(y)beta(dy)=integral_E F(x)H(x)dx.

Original FIRST, the physical hard scale-envelope integral A_n=1+n log(b/a), and original selected hard cap H<=4lambda imply

    integral I_y B_1 beta <=min(A_n W_nu,4lambda|E|).

This is a legitimate source-linear/receiver bound without a source density assumption or nu<=beta. Zero I rows contribute zero; no normalized pi is required there. The inequality holds for every frozen beta restriction, using the restricted actual FIRST. It can also retain actual partial nu sources and their exact responses.

## 2. Poisson normalization and exact atomic rank

For intensity t U_y(x)dx, t>0, let A_yz(r)=integral_{R(x)<=r,z in Q_R(x)} U_y(x)dx=I_y F_yz(r). It is a finite captured-radius measure's inclusive CDF, not a probability CDF when I_y differs from one. A finite Poisson process has minimum-capture sub-CDF 1-exp(-t A_yz(r)). Let C_t(y) be the expected inverse-volume maximum/minimum-witness capacity.

Its physical layercake is b^-n integral [1-exp(-t A(b))]dnu+n integral_a^b r^-n-1 integral[1-exp(-t A(r))]dnu dr. The ACTUAL row rank is

    K_t(y)=integral nu(dz)integral r^-n exp(-t A_yz(r))dA_yz(r).

Inclusive-CDF chain rule, with a nonnegative atom deficit, gives K_t<=C_t/t. On nonatomic captured-radius measures this is equality. The normalized bare-rank integral under pi is K_t/I_y; therefore its bound is C_t/(t I_y), not C_t/t. The original receiver integral contains I_y and is K_t. This normalization distinction must be preserved in all source integration and stopping claims.

The linear inequality 1-exp(-tA)<=tA gives C_t<=t I_y B_1(y), hence

    integral C_t beta<=t min(A_n W_nu,4lambda|E|).

This alone is linear in t and pays no root-polylog budget. Concavity in t and a nonlinear saturation formula are exact profile information, not a quantitative source improvement until an actual geometric bound on integral C_t is supplied.

## 3. Cover/receiver ledger and lawful row splits

The R300 chi-weighted maximum proof may be averaged over a finite Poisson count (intensity tI_y). On the qualified actual aspect gate v>=v0 it gives the valid positive-majorant budget

    T_v0 <=[kappa0 psi_inf/(q_-v0)]integral C_t beta
                                    +(1/t)integral C_t beta.

The same finite Poisson law is used in both terms; zero row intensity has zero original traffic. Substituting only the preceding linear source estimate does not create a nonlinear capacity or root bound. A receiver-dependent rate or a rate chosen separately for each hard source is not this common row construction. A row-dependent measurable rate may be defined before actual x integration, but the resulting exact integrals and source/outer fees must remain.

For fixed-N sampling B_N<=N B_1. Thus on the frozen row set Y_s={I_y>=s}, s>0,

    integral_Ys B_N beta <=(N/s)integral_Ys I_y B_1 beta
                            <=(N/s)A_n W_nu.

This is a genuine large-I mixed-source bound. It does not automatically give the rank term a 1/N gain: the original shared-FIRST estimate only gives integral I_y B_N/N beta<=integral I_y B_1 beta. On I_y<=s, one instead has integral I_y B_N/N beta<=(s/N)integral B_N beta, retaining that source capacity. Any useful combination must display these actual fees; neither source restriction changes the original e_g,m or supplies FIRST for normalized beta weights.

A fixed source partition preserves original restricted FIRST and source caps by positivity. When summing row blocks, their actual FIRST responses can share the one original budget if the restrictions are disjoint/aggregate<=1 and the hard responses are dominated by the same original nu. Paying a separate full W_nu per block and discarding multiplicity is not justified. The hard scale envelope A_n remains unless some separately proved profile/geometry removes it.

## 4. Actual bounded local diagnostics

An actual Python Fraction finite positive integration ledger verified the exact cross-row I B1 identity. A local mpmath run at 50 digits checked 27 finite atomic Poisson configurations (three n, three t, three row masses), verifying C_t/t-K_t equals its nonnegative weighted atomic deficit and C_t<=t integral r^-n dA. All PASS. These are finite bookkeeping diagnostics, not original-traffic or dimension-order proofs.

Independent-screen verdict: the cross-row FIRST identity, Poisson atom-correct rank budget, stated linear capacity estimate, and conditional large-I mixing are valid. A source-linear root improvement from a nonlinear capacity or a source partition remains to be proved with its complete quantifiers/costs. Await author proofs for bounded comparison; no other files or Git changed.

## 5. Additional independently screened cross-row nonlinear occupancy profile

For W_beta=B>0, define A_z(r)=integral A_yz(r)beta(dy). Positive Tonelli and original FIRST give the EXACT identity

    A_z(r)=integral_{E,R(x)<=r,z in Q_R(x)(x)} F(x)dx<=r^n.

The upper bound is geometric: that actual receiver region lies in Q_r(z); it is not a density bound on either source. Concavity of 1-exp(-t s), with respect to the ORIGINAL beta probability beta/B, yields the actual cross-row nonlinear profile

    integral C_t(y)beta(dy)
      <=B[b^-n integral(1-exp(-t A_z(b)/B))nu(dz)
           +n integral_a^b r^-n-1
                         integral(1-exp(-t A_z(r)/B))nu(dz)dr].

Zero B entails zero original traffic and is handled separately. Finite original sources and positive a make these quantities finite, and all suprema/scale selectors remain inside the original receiver region used to define A.

If one discards actual occupancy and uses A_z(r)<=r^n, positive integration by parts gives precisely

    integral C_t beta <= t W_nu Xi(c,A),
    Xi(c,A)=(1-exp(-c))/c+integral_1^A exp(-c u)du/u,
    c=t a^n/B, A=(b/a)^n.

Indeed the bracket before integration by parts is (B/a^n)[A^-1(1-exp(-cA))+integral_1^A u^-2(1-exp(-cu))du]. Its boundary terms leave the displayed Xi, with no missing endpoint. Xi<=1+log A=A_n; this coarse bound alone is not a new dimension-root theorem. The exact shared-FIRST occupancy profile and any Jensen deficit may retain useful geometry, but its required integrated source/outer cost is not assumed. This statement screen was saved before author-file reading.

## 6. Independent common-rate oracle screen

Let d=kappa0 psi_inf/(q_-v0)>0, A=A_yz(r)>=0, and let Omega be the finite positive product measure beta(dy)nu(dz)[b^-n delta_b(dr)+n r^-n-1 1_[a,b](r)dr]. The actual Poisson capacity budget is F(t)=(d+1/t)integral(1-exp(-tA))dOmega. Define the clipped original-field source cost O_d=integral min(d,A)dOmega.

For every t>0, min(d,A)<=(d+1/t)(1-exp(-tA)). With x=tA,y=td, this is (1+y)(1-exp(-x))>=min(x,y). If x<=y use 1+y>=1+x and exp(x)>=1+x; if x>=y use monotonicity in x followed by the same inequality at y. At t=1/d, the reverse upper comparison F(1/d)<=2O_d follows from 1-exp(-A/d)<=min(1,A/d). Thus

    O_d<=inf_(t>0)F(t)<=F(1/d)<=2O_d,
    ORIGINAL T_v0<=F(1/d)<=2O_d.

The single actual common rate 1/d realizes the comparison. There is no pair-specific rate hidden inside the minimum. The left inequality bounds the optimized POISSON EXPENSE from below, not the actual traffic from below. The minimum stays inside the original beta integration, retaining true row/pair heterogeneity rather than applying Jensen first. Zero source cases contribute zero; d>0 is essential for the displayed rate. This is a valid optimization/realizability result for that explicit fee, not a dimension-root bound on O_d. Its source and original outer ledger still require payment. This statement was screened before the common-rate author proof.

## 7. Geometry author-file comparison — PASS

Read /tmp/r301_geometry.md after the independent screen. Its Poisson positive series, finite intensity and zero-row convention are valid. The actual rank measure is the unnormalized dA, so no I_y is lost in (8)-(10). The exact first-moment FIRST bridge, beta-Jensen profile, occupancy restriction, scalar integration by parts and Xi bounds (13)-(16) agree with the independent calculations, including A=1 and c>0. Its explicit Jensen and occupancy deficits have the correct signs and are not claimed large enough for a dimension-root theorem.

The additional admissible row-mask localization is valid: alpha is required z-independent and I0<=alpha on the target, so target density is still dominated by U*=alpha1_E p/q. All accepted sampled receivers retain same-radius caps; actual original low/high heights remain applied only on target traffic. Repeating the rank argument with dA* therefore proves the same target upper budget, while 1-exp(-tA) monotonicity makes C_t* and L_t* no larger. It does not claim capture itself increases, and excludes unsupported z-dependent row masks. Measurability and original outer/aspect complements remain explicit. No mathematical correction is required.

Geometry SHA256: 489065da3f429120850543e00645ddb4752b5b7ed88a9ddce222cc51f30ab3de

## 8. Common-rate author-file comparison — PASS

Read /tmp/r301_common_rate.md after the independent oracle screen. Its finite Omega has total mass a^-n W_beta W_nu; the receiver measure remains actual dx in the underlying proof. The scalar lower/upper comparisons give exactly the stated common-rate factor-two guarantee. O_d bounds the family of upper EXPENSES F(t) from below; the text explicitly does not turn this into a traffic lower bound or exchange infimum and integration. The single rate t=1/d is implemented by one actual row Poisson law.

For each fixed row the same rank/cover proof works before beta integration and yields T_y<=2O_d(y), while original hardcap and I0<=alpha give T_y<=4lambda I_y. Taking their measurable rowwise minimum is therefore valid, with no extra source copies, no I omission and no changed FIRST. Further admissible z-independent alpha restriction decreases I, A, C, O and the minimum, while retaining target domination. The full root-order cost and original aspect/outer complements remain explicit. No correction is needed.

Common-rate SHA256: 522704b803a070e35be9d93f7b03abfbb9dbca4ec45d8ed318cc7ae6ec139ebd

## 9. Mixed-intensity author-file comparison — PASS

Read /tmp/r301_poisson.md. The unnormalized Poisson rank uses dA, actual units and q_- once. The saturation bound uses the actual B_infinity, not a guessed uniform capacity. The low-I original traffic is paid by actual hardcap before extension, while the high-I frozen original beta restriction retains restricted FIRST and its true mass B_hi. Equations (10)-(11) therefore retain a valid mixed-source fee, not a free second full W_nu allocation.

The positive eta_A representation is exact and its mass/mean, monotonicity, scalar derivative and endpoints follow as stated. H_1(alpha)=min(1,alpha) and the midpoint common-rate factor-two bound are valid. The 1/alpha formulas apply to alpha>0; zero B_hi is explicitly treated as zero cost separately. The conditional H,J source bound does not assert those hypotheses on arbitrary inputs, and the genuine |E|/(h a^n) concentration ratio remains. Basic ordered rank remains restricted to L>=R unless an independent matching aspect bridge is supplied, which the geometry theorem now does on its qualified subset. No mathematical correction is required; only a minor explicit domain phrase for 1/alpha was requested before final hash binding.

The final geometry evidence-only wording correctly distinguishes Python math double precision (36 rank+12 Jensen, 1e-13 comparison tolerance; 16 direct monotonicity checks) from mpmath 45-digit scalar checks (12 identities, 1e-35 tolerance). The analytic proof was unchanged. Its final mathematical/evidence binding will supersede the earlier geometry hash in Section 7.

## 10. Final integration and evidence — PASS and frozen

Read final /tmp/r301_README.md. It matches the three proof files: original admissible row gates, unnormalized tU and dA rank, one actual common rate, oracle lower bound only for Poisson expense, true rowwise minimum, mixed low/high original-source fee and all zero-mass/domain conventions. The oracle comparison is not an infimum/integral exchange or a traffic lower bound. Uncontrolled source/coupling cost, extreme aspect complement and original outer/entry/history ledger remain explicit. The final poisson note now explicitly restricts reciprocal-alpha formulas to alpha>0 and treats zero B_hi separately. No remaining formula or scope correction is needed.

Inspected actual evidence artifacts: main JSON has PASS, no failures and check-count sum 16152; the 468 oracle lower-budget and 36 common-rate upper-oracle counts match README. Geometry log records 36 Poisson-rank plus 12 Jensen comparisons at the stated double-precision tolerance, 12 mpmath scalar checks at 45 digits and 16 row-gate checks. Mixed-source log records 28 scalar parameter/endpoint checks; its numeric optimization is explicitly not interval-certified global minimization. Parent reports actual reruns; auditor inspected the frozen outputs without repeating full scripts. Auditor's own exact cross-row ledger and 27 fifty-digit Poisson atom checks are separately documented in Section 4.

The added shell evidence was scope-checked, not treated as an original global theorem: its JSON is PASS with no failures and sum 646. The code constructs positive-volume common beta/nu support and concentric receiver shells; source support is wholly inside each selected actual cube by the displayed halfwidth equality. FIRST uses actual s=0 cube heights and same-radius hardcaps. Exact Fraction checks establish I^2>n and nonnegative minimum-rank probabilities summing to one; all radii>=1 give the exact B_N<=4 certificate and b_8/8<=1/8. Displayed capacities are ordinary 40/60-digit mpmath refinements. The README's n=16,32, large I and capacity figures agree with those outputs. Full original m/e_g/history and all-radius maximal-cap qualifications are not inferred by this finite diagnostic or promoted to a universal large-I redundancy statement. Thus the README preserves its proper evidence boundary.

Final SHA256 bindings (these supersede any earlier provisional hashes in this file):
- /tmp/r301_README.md: 35cfa33eb1f0db82723e9094e7405508e3e5521014979b9938558b30e8945a78
- /tmp/r301_geometry.md: 415dbce18531395b10effc57bee8ca982868bb949a8eedcd2ca8e7e532426597
- /tmp/r301_common_rate.md: 522704b803a070e35be9d93f7b03abfbb9dbca4ec45d8ed318cc7ae6ec139ebd
- /tmp/r301_poisson.md: e072973aa737aec0079a502640fb66955737bb5c8e9df9f5102fc485cc284683
- /tmp/r301_checks.py: 3b57b976242068e0ae0c0a2be68158b5300e87d071445cbc2d9afea8f772dc43
- /tmp/r301_checks.json: 9c3b32a02221ad6762987ece336c2a7b4b171af55754aa469c23959c4e547873
- /tmp/r301_checks_run.log: bcd59c6c8fe387e46e0a01a6a3df137df71b91bb972a49a0e9788fa06ed1c87d
- /tmp/r301_geometry_checks.py: 77359e29d1ed7b314f8cdf148a69422a647731b1327fb4952498f093e5d77129
- /tmp/r301_geometry_checks.log: 9344b76e07407a77a66f8b3d2a10a3342834191ebf168d4073613aeebba668c4
- /tmp/r301_poisson_checks.py: 234db46d164263e2029d780eb926b23b4b1fe3515187775661c6c04c73d4009d
- /tmp/r301_poisson_checks.log: 5f780e35c7a1f8a63dc68f710c248848f2b5ee790d4ce88cc088515235073dab
- /tmp/r301_shell_checks.py: 37c3c834910f7f76f1a9d0fe1bd7cd25c4a98cf47bc3608a91715a35d6184a89
- /tmp/r301_shell_checks.json: c92603637c8a64c1546845dec4a54959f6e40c48cf55575b21a3172622db8a98
- /tmp/r301_shell_checks_run.log: 56fd089a7b7dbede400eb680aca2e3d004a0ae2c4f1c0d290bd7e322c4aeb808

Final bounded verdict: PASS. The implemented common-rate oracle gives a valid constant-factor comparison of explicit coupled expenses, and the mixed intensity/row localization estimates retain legitimate source savings. A uniform root-polylog bound for those actual expenses, universal low/high intensity conditions or large-I redundancy, the aspect complement and original global/outer ledger remain unproved. No density/source-order premise, unsupported FIRST transfer or source duplication was introduced. Audit frozen; no repository/Git/PDF or other author file changed.
