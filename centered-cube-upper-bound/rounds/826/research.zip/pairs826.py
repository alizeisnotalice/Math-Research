#!/usr/bin/env python3
"""Exact positive-width antipodal source pairing and scalar high-dimension checks."""
from fractions import Fraction
from functools import lru_cache
from itertools import combinations, product
from math import factorial, prod

from flint import arb, ctx

F = Fraction
ZERO = F(0)
HALF = F(1, 2)
T0 = F(3, 2)
SMOOTHING = F(1, 8)
KAPPA = F(3239, 4608)
SMALL_DIMENSIONS = (6, 7, 8, 10)
LARGE_DIMENSIONS = (10**4, 10**64, 10**96, 10**160)


def ar(value):
    return arb(value.numerator) / value.denominator


def uniform_sum_power(x, widths, order):
    """Box simplex inclusion-exclusion, with all uniforms centered at zero."""
    shifted = x + sum(widths) / 2
    total = ZERO
    for count in range(len(widths) + 1):
        for subset in combinations(widths, count):
            remaining = shifted - sum(subset)
            if remaining > 0:
                total += (-1)**count * remaining**order
    return total / (factorial(order) * prod(widths))


@lru_cache(maxsize=None)
def source_average(x, center, half_width, side):
    """Dimensionless one-coordinate original soft value from an actual block."""
    lower = (x - center - half_width) / side
    upper = (x - center + half_width) / side
    widths = (F(1), SMOOTHING, SMOOTHING)
    return side * (
        uniform_sum_power(upper, widths, len(widths))
        - uniform_sum_power(lower, widths, len(widths))
    ) / (2 * half_width)


@lru_cache(maxsize=None)
def paired_axis_average(x, first_radius, second_radius, side):
    """Direct five-uniform density; the two opposite centers cancel."""
    widths = (F(1), SMOOTHING, SMOOTHING, first_radius / side, second_radius / side)
    return uniform_sum_power(x / side, widths, len(widths) - 1)


def shape(n, side):
    peak = side * (HALF - F(1, 8 * n))
    short = side / (128 * n)
    long = side / (64 * n)
    radius_of_receivers = side / (32 * n)
    return peak, short, long, radius_of_receivers


def blocks(n, side):
    peak, short, long, _ = shape(n, side)
    result = {}
    for signs in product((-1, 1), repeat=n):
        long_axis = 0 if signs[0] == 1 else 1
        radii = tuple(long if i == long_axis else short for i in range(n))
        centers = tuple(peak * sign for sign in signs)
        result[signs] = centers, radii
    return result


def cube_capture_fraction(point, side, centers, radii):
    return prod(
        (
            max(ZERO, min(x + side / 2, c + w) - max(x - side / 2, c - w)) / (2 * w)
            for x, c, w in zip(point, centers, radii)
        ),
        start=F(1),
    )


def centered_soft_closed(n):
    base = 1 - F(1, n)
    short_axis = 1 - (base**2 + F(1, 768 * n**2)) / 2
    long_axis = 1 - (base**2 + F(1, 192 * n**2)) / 2
    return long_axis, short_axis


def check_exact_dimension(n):
    side = T0
    peak, short, long, receive_radius = shape(n, side)
    source_blocks = blocks(n, side)
    assert len(source_blocks) == 2**n
    assert peak > long  # Distinct signs separate the corresponding source boxes.
    assert all(prod(radii) == long * short**(n - 1) for _, radii in source_blocks.values())

    weight = side**n / 2**n
    source_mass = weight * len(source_blocks)
    receive_volume = (2 * receive_radius)**n
    first_success = side * (1 - F(5, 32 * n))
    assert first_success / 2 == peak + long + receive_radius
    assert 1 <= first_success < side < 2
    assert source_mass / first_success**n > 1
    assert source_mass / side**n == 1
    assert receive_volume / source_mass == F(1, (16 * n)**n)
    assert source_mass**2 / (len(source_blocks) * weight**2) == 2**n

    # Enumerate the actual ordered pair marginals, with source mass used once per side.
    first_marginal = {}
    second_marginal = {}
    for signs, (centers, radii) in source_blocks.items():
        opposite = tuple(-sign for sign in signs)
        other_centers, other_radii = source_blocks[opposite]
        first_marginal[signs] = first_marginal.get(signs, ZERO) + weight
        second_marginal[opposite] = second_marginal.get(opposite, ZERO) + weight
        assert all(first + second == 0 for first, second in zip(centers, other_centers))
        midpoint_radii = tuple((first + second) / 2 for first, second in zip(radii, other_radii))
        assert midpoint_radii[:2] == (3 * side / (256 * n),) * 2
        assert all(radius == short for radius in midpoint_radii[2:])
        assert max(midpoint_radii) + receive_radius < (HALF - SMOOTHING) * side
    assert first_marginal == second_marginal == {signs: weight for signs in source_blocks}
    assert sum(first_marginal.values()) == source_mass

    # The whole physical receiver box F is verified by the endpoint bound above.
    # These actual x samples then check hard values and two independent densities.
    receivers = (
        (ZERO,) * n,
        (receive_radius,) * n,
        tuple((-1)**i * receive_radius for i in range(n)),
        tuple((F(i % 3) - 1) * receive_radius / 2 for i in range(n)),
    )
    max_soft = ZERO
    center_soft = None
    for point in receivers:
        hard_before = ZERO
        hard_root = ZERO
        soft = ZERO
        midpoint_soft = ZERO
        for signs, (centers, radii) in source_blocks.items():
            opposite = tuple(-sign for sign in signs)
            _, other_radii = source_blocks[opposite]
            hard_before += weight * cube_capture_fraction(point, first_success, centers, radii)
            hard_root += weight * cube_capture_fraction(point, side, centers, radii)
            soft += weight / side**n * prod(
                source_average(x, center, radius, side)
                for x, center, radius in zip(point, centers, radii)
            )
            midpoint_soft += weight / side**n * prod(
                paired_axis_average(x, first, second, side)
                for x, first, second in zip(point, radii, other_radii)
            )
        assert hard_before == hard_root == source_mass
        assert soft <= KAPPA**n
        assert midpoint_soft == 1
        max_soft = max(max_soft, soft)
        if point == receivers[0]:
            long_value, short_value = centered_soft_closed(n)
            center_soft = soft
            assert soft == long_value * short_value**(n - 1)

    # Necessary geometric volume of the entire lambda=1 hard window event.
    span = 2 * (peak - long)
    # With 1 to n-1 double-sign axes a successful scale t would satisfy
    # t >= span > T0*2^(-1/n) > t; the exact power comparison is the middle step.
    assert 2 * (span / side)**n > 1
    assert side / 2 < 1
    overlap_side = side + 2 * long - 2 * peak
    assert overlap_side / side == F(9, 32 * n)
    print(f"Fraction n={n}: {len(source_blocks)} actual source boxes, "
          f"{len(receivers)} hard/soft/midpoint receiving tests; "
          f"soft(0)≈{float(center_soft):.12g}, max tested soft≈{float(max_soft):.12g}; "
          f"F/S=(16n)^(-n), entire lambda=1 window/S≤(9/(32n))^n.")


def check_scalar(n, bits):
    ctx.prec = bits
    nn = arb(n)
    center_bound = 1 - (1 - F(11, 8 * n))**2 / 2
    assert center_bound <= KAPPA < F(3, 4)
    long_axis, short_axis = centered_soft_closed(n)
    long_eps = ar(2 * long_axis - 1)
    short_eps = ar(2 * short_axis - 1)
    correction = long_eps.log1p() + (nn - 1) * short_eps.log1p()
    assert arb(3) / 2 < correction < arb(201) / 100
    log_soft_per_dimension = -arb(2).log() + correction / nn
    assert log_soft_per_dimension < ar(KAPPA).log()
    log_selected_per_dimension = -(16 * nn).log()
    log_entire_upper_per_dimension = (arb(9) / (32 * nn)).log()
    assert log_selected_per_dimension < log_entire_upper_per_dimension < -arb(2).log()
    assert nn * (-arb(9) / (32 * nn)).log1p() > -arb(2).log()
    assert ar(T0 * (1 - F(5, 32 * n))) > 1
    print(f"Arb {bits} n={n}: log soft(0)/n={log_soft_per_dimension.str(10)}, "
          f"log soft(0)+n log2={correction.str(10)}, "
          f"log selected ratio/n={log_selected_per_dimension.str(10)}, "
          f"log entire upper/n={log_entire_upper_per_dimension.str(10)}.")


def check_two_price_windows():
    """Two spatially disjoint genuine supplies at two fixed side lengths."""
    early, late, displacement = F(5, 4), F(7, 4), F(8)
    for n in (6, 10, 32):
        combined = early**n + late**n
        assert combined < 2**n  # No scale above the window can succeed at lambda=1.
        assert early * (1 - F(5, 32 * n)) > 1
        # Each selected cube and every hard or soft t<=2 observation in it
        # sees only its own support. Even the soft support radius is at most 5/4.
        assert displacement - (early + late) / 2 - early / (32 * n) > F(5, 4)
        assert displacement - (early + late) / 2 - late / (32 * n) > F(5, 4)
        assert ((early / (16 * n))**n + (late / (16 * n))**n) / combined == F(1, (16 * n)**n)
        if n >= 10:
            assert arb(n) * ar(late / early).log() > arb(n).sqrt()
    print("Two-copy geometry: separate true scales 5/4 and 7/4, with fresh disjoint "
          "source supplies; their log-volume gap exceeds sqrt(n) for n>=10.")


def main():
    assert 1 - (1 - F(11, 48))**2 / 2 == KAPPA
    for n in SMALL_DIMENSIONS:
        check_exact_dimension(n)
    for bits in (256, 384):
        ctx.prec = bits
        for n in LARGE_DIMENSIONS:
            check_scalar(n, bits)
        check_two_price_windows()
    print("PASS. Finite exact geometry and high-dimensional scalar checks; "
          "no linear weak-type lower bound.")


if __name__ == "__main__":
    main()
