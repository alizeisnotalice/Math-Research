#!/usr/bin/env python3
"""Exact one-dimensional kernel checks and scalar high-dimensional bounds.

Half the side of the unit box is 1/2. No high-dimensional spatial array
or general-input transfer from the hard maximal operator is constructed.
"""
from fractions import Fraction
from itertools import product
from math import isqrt

from flint import arb, ctx

F = Fraction
ZERO = F(0)
HALF = F(1, 2)
WIDTHS = (F(1, 4), F(1, 5), F(1, 8), F(1, 16), F(1, 100), F(1, 2**20))
DIMENSIONS = (128, 10**4, 10**8, 10**64, 10**96, 10**160)


def ar(value):
    return arb(value.numerator) / value.denominator


def tent_cdf(x, a):
    """Area of two narrow uniform coordinates cut by a diagonal line."""
    return (max(ZERO, x + a)**2 - 2 * max(ZERO, x)**2 + max(ZERO, x - a)**2) / (2 * a**2)


def tent_density(x, a):
    return max(ZERO, a - abs(x)) / a**2


def kernel_geometry(x, a):
    return tent_cdf(x + HALF, a) - tent_cdf(x - HALF, a)


def kernel_derivative_geometry(x, a):
    return tent_density(x + HALF, a) - tent_density(x - HALF, a)


def shoulder(x, a):
    absolute = abs(x)
    sign = -1 if x < 0 else 1
    if absolute <= HALF - a:
        return F(1), ZERO
    if absolute <= HALF:
        v = (absolute - HALF + a) / a
        return 1 - v**2 / 2, -sign * v / a
    if absolute < HALF + a:
        v = (HALF + a - absolute) / a
        return v**2 / 2, -sign * v / a
    return ZERO, ZERO


def exact_poly_integral(function, left, right, breaks):
    knots = sorted({left, right} | {point for point in breaks if left < point < right})
    return sum(
        ((b - a) * (function(a) + 4 * function((a + b) / 2) + function(b)) / 6
         for a, b in zip(knots, knots[1:])),
        start=ZERO,
    )


def kernel_knots(a):
    return (-HALF - a, -HALF, -HALF + a, HALF - a, HALF, HALF + a)


def kernel_integral(a, left, right):
    return exact_poly_integral(lambda x: kernel_geometry(x, a), left, right, kernel_knots(a))


def smoothed_fine_mass(a, delta, left, right):
    """Integrate first over the observation interval and then over the source."""
    def shifted_mass(shift):
        return kernel_integral(a, left - shift, right - shift)

    shift_knots = [endpoint - knot
                   for endpoint in (left, right) for knot in kernel_knots(a)]
    return exact_poly_integral(shifted_mass, -delta / 2, delta / 2, shift_knots) / delta


def hard_fine_mass(delta, left, right):
    def shifted_mass(shift):
        return max(ZERO, min(right, shift + HALF) - max(left, shift - HALF))

    shift_knots = [end + sign * HALF for end in (left, right) for sign in (-1, 1)]
    return exact_poly_integral(shifted_mass, -delta / 2, delta / 2, shift_knots) / delta


def test_exact_geometry():
    shoulder_checks = 0
    convolution_checks = 0
    for a in WIDTHS:
        for x in sorted(set(kernel_knots(a)) | {F(i, 36) for i in range(-32, 33)}):
            value, derivative = shoulder(x, a)
            assert value == kernel_geometry(x, a)
            assert derivative == kernel_derivative_geometry(x, a)
            shoulder_checks += 1
        raw_retained = 1 - a / 3
        assert kernel_integral(a, -HALF, HALF) == raw_retained
        assert kernel_integral(a, -HALF - a, HALF + a) == 1
        assert kernel_integral(a, HALF, HALF + a) == a / 6
        # Fixed x in the flat region of a source with density 1 on [-3,3].
        for x in (-1, F(1, 3), 1):
            assert kernel_integral(a, x - 3, x + 3) == 1
            assert (
                kernel_integral(a, x - 3, -HALF) + kernel_integral(a, HALF, x + 3)
                == 1 - raw_retained
            )
        for delta in (a, a / 4, a / 16):
            nominal_soft = raw_retained - delta**2 / (12 * a) + delta**3 / (96 * a**2)
            core_soft = raw_retained - delta / 2 - delta**2 / (3 * a) + delta**3 / (12 * a**2)
            core_half = (1 - delta) / 2
            full_half = HALF + a + delta / 2
            assert smoothed_fine_mass(a, delta, -HALF, HALF) == nominal_soft
            assert smoothed_fine_mass(a, delta, -core_half, core_half) == core_soft
            assert smoothed_fine_mass(a, delta, -full_half, full_half) == 1
            assert hard_fine_mass(delta, -HALF, HALF) == 1 - delta / 4
            assert hard_fine_mass(delta, -core_half, core_half) == 1 - delta
            assert hard_fine_mass(delta, -full_half, full_half) == 1
            if delta <= a / 4:
                assert core_soft / (1 - delta) < 1 - a / 5
            convolution_checks += 6

        # A fixed positive-volume corner region is hard-successful.
        # On it the full soft single-window maximal function has the bound
        # (1+a/2)^(-n) for either a point mass or a uniform source with delta=a/16.
        delta = a / 16
        corner_start = HALF - a / 8
        assert corner_start < HALF - delta / 2
        assert (corner_start - delta / 2) / (1 + a / 2) > HALF - a / 2
        assert kernel_geometry(HALF - a / 2, a) == F(7, 8) < 1 / (1 + a / 2)

    print(f"Fraction: {shoulder_checks} kernel/derivative checks against diagonal areas, "
          f"{convolution_checks} exact fine-source two-integral checks.")
    print("Per-axis hard-box retention: point 1-a/3; fine nominal "
          "1-a/3-delta^2/(12a)+delta^3/(96a^2).")


def fisher_series_interval(a, terms):
    """Independent rigorous integral by a finite positive geometric series."""
    c = HALF - a
    outer_minus_one = 1 / a + 1 + 4 * a / 3
    inner = sum(
        (
            (c**2 / (2 * j + 3) + 2 * a * c / (2 * j + 4) + a**2 / (2 * j + 5))
            / 2**j
            for j in range(terms)
        ),
        start=ZERO,
    )
    lower = outer_minus_one + 2 * inner / a
    remainder = F(1, 2**terms) / (a * (2 * terms + 3))
    return lower, lower + remainder


def exact_fisher_arb(a):
    aa = ar(a)
    square_root = arb(2).sqrt()
    capital_c = square_root * (1 + square_root).log()
    log_two = arb(2).log()
    return (
        capital_c / aa + 3 + 4 * log_two - 4 * capital_c
        + aa * (12 * capital_c - 8 * log_two - 8)
    )


def check_fisher(bits):
    ctx.prec = bits
    for a in WIDTHS:
        low, high = fisher_series_interval(a, bits // 2)
        closed = exact_fisher_arb(a)
        assert ar(low) < closed < ar(high)
        assert closed > 1 / ar(a)
        print(f"Arb {bits} bits Fisher a={a}: {closed.str(16)}.")


def check_high_dimension(bits):
    ctx.prec = bits
    for n in DIMENSIONS:
        square_root = isqrt(n)
        assert n == 128 or square_root**2 == n
        for label, a in (("fixed", F(1, 4)), ("root", F(1, square_root)), ("inverse", F(1, n))):
            assert a <= HALF / 2
            delta = a / 16
            hard_inner = 1 - delta
            soft_inner = 1 - a / 3 - delta / 2 - delta**2 / (3 * a) + delta**3 / (12 * a**2)
            inner_deficit = (hard_inner - soft_inner) / hard_inner
            assert a / 5 < inner_deficit < a
            # log1p avoids losing the deficit for n=10^160 at 256 bits.
            atom_log = arb(n) * (-ar(a / 3)).log1p()
            fine_log = arb(n) * (-ar(inner_deficit)).log1p()
            fisher = exact_fisher_arb(a)
            assert atom_log < -ar(F(n) * a / 4)
            assert atom_log > -ar(F(n) * a / 2)
            assert fine_log < -ar(F(n) * a / 5)
            assert fine_log > -ar(F(2 * n) * a)
            assert arb(n) * fisher > ar(F(n) / a)
            name = str(n) if n == 128 else f"10^{len(str(n)) - 1}"
            print(
                f"Arb {bits} bits n={name} a={label}: "
                f"log(point retention)={atom_log.str(10)}, "
                f"log(fine core soft/hard)={fine_log.str(10)}, "
                f"aI(a)={(ar(a) * fisher).str(10)}."
            )


def scaled_kernel_1d(a, t, x, source):
    return kernel_geometry((x - source) / t, a) / t


def test_cross_scale_and_price_bins():
    dimensions = (2, 7, 31)
    coordinate_checks = 0
    product_checks = 0
    for n in dimensions:
        multiplier = 1 + F(4, n)
        for a, t in product(WIDTHS, (F(1), F(5, 4), F(7, 5))):
            source = -F(2, 3)
            shifts = (-F(1, n), -F(3, 4 * n), ZERO, F(1, 3 * n), F(1, n))
            for shift in shifts:
                moved = source + shift * t
                fixed_knots = set(kernel_knots(a)) | {
                    ZERO, F(1, 4), -F(1, 4), F(1, 4) + F(1, 8 * n),
                    F(1, 4) - F(1, 8 * n), HALF + a + F(1, 3 * n),
                }
                # These points land exactly on each of the moved kernel faces.
                moved_knots = {shift + multiplier * knot for knot in kernel_knots(a)}
                knots = sorted(fixed_knots | moved_knots)
                test_points = sorted(set(knots) | {(lo + hi) / 2 for lo, hi in zip(knots, knots[1:])})
                hard_product = F(1)
                expanded_product = F(1)
                coordinate_pairs = []
                for normalized in test_points:
                    x = source + t * normalized
                    old = scaled_kernel_1d(a, t, x, source)
                    expanded = scaled_kernel_1d(a, multiplier * t, x, moved)
                    assert old <= multiplier * expanded
                    coordinate_pairs.append((old, expanded))
                    coordinate_checks += 1

                # Keep the tensor factors exact while mixing all nonzero regimes.
                positive_pairs = [pair for pair in coordinate_pairs if pair[0] > 0]
                assert positive_pairs
                for coordinate in range(n):
                    old, expanded = positive_pairs[coordinate % len(positive_pairs)]
                    hard_product *= old
                    expanded_product *= expanded
                assert hard_product <= multiplier**n * expanded_product
                product_checks += 1

    print(f"Fraction cross-scale: {coordinate_checks} coordinate comparisons, "
          f"{product_checks} exact tensor comparisons.")

    ctx.prec = 256
    for n in dimensions:
        height = arb(n).sqrt()
        multiplier = 1 + F(4, n)
        price_step = n * ar(multiplier).log()
        assert arb(4) / 3 < price_step < 4
        window_width = n * arb(2).log()
        final_index = int(float((window_width / height).mid()))
        assert final_index * height < window_width < (final_index + 1) * height
        start_count = final_index + 1
        assert arb(start_count) < 1 + height

        fine_counts = [0] * start_count
        scale = F(1)
        while scale <= 2:
            price = n * ar(scale).log()
            bucket = int(float((price / height).mid()))
            if scale != 1:
                assert bucket * height < price < (bucket + 1) * height
            fine_counts[bucket] += 1
            scale *= multiplier
        for count in fine_counts:
            assert arb(count) < 1 + height / price_step
        print(f"Price bins n={n}, H=sqrt(n): {start_count} starts; "
              f"fine-scale counts per bin {fine_counts}.")

    # Analytic count uses log(1+u) between u/(1+u) and u, while
    # [1,2] has n log 2 units of log volume. Changing an entire frozen
    # library between price bins does not increase the count of their starts.
    print("Bin-start count applies when each frozen library carries one start charge; "
          "it does not estimate other within-bin costs.")


def main():
    test_exact_geometry()
    test_cross_scale_and_price_bins()
    for bits in (256, 384):
        check_fisher(bits)
        check_high_dimension(bits)
    print("PASS. Products are verified by scalar logarithms; no dense arrays or general transfer.")


if __name__ == "__main__":
    main()
