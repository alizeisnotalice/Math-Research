"""Replay the original same-record allocations and the four R826 computations."""
import argparse
import hashlib
from importlib.metadata import version
from pathlib import Path
import platform
import subprocess
import sys
from tempfile import TemporaryDirectory
from zipfile import ZipFile
import flint


ROOT = Path(__file__).resolve().parent
INPUTS = {
    "814": "891d8cbcbd35537e6abc18c938e53b1b4f300327357c24c8d14a51a46ad5e190",
    "823": "49fb22a6274856e4c8d39af4cfb80b10265467bebac89c3ef30a305131a71ebd",
}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for key in INPUTS:
        parser.add_argument("--r" + key, type=Path, required=True)
    args = parser.parse_args()
    if not __debug__:
        raise RuntimeError("Enable assertions before running.")
    paths = {k: getattr(args, "r" + k).resolve() for k in INPUTS}
    for key, path in paths.items():
        assert hashlib.sha256(path.read_bytes()).hexdigest() == INPUTS[key]
    print("Python", platform.python_version(), "python-flint", flint.__version__,
          "FLINT", flint.__FLINT_VERSION__, "NumPy", version("numpy"), "SciPy", version("scipy"), flush=True)
    print("R814", INPUTS["814"], "R823", INPUTS["823"], flush=True)
    with TemporaryDirectory(prefix="prices-", dir=ROOT) as folder, ZipFile(paths["823"]) as bundles:
        file = Path(folder) / "replay823.py"
        module = {"__name__": "pinned_prices", "__file__": str(file)}
        exec(compile(bundles.read(file.name), file.name, "exec"), module)
        module["prices"](paths["814"])
    for filename in ("roots826.py", "comb826.py", "pairs826.py", "kernels826.py"):
        print("\nRUN", filename, flush=True)
        args = [sys.executable, "-E", "-B", str(ROOT / filename)]
        if filename == "comb826.py":
            args += ["--r814", str(paths["814"])]
        subprocess.run(args, cwd=ROOT, check=True)
    print("PASS complete round 826 exact replay")


if __name__ == "__main__":
    main()
