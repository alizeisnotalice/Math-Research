"""True central owner brightness and price changes on the two archived R814 combs."""
import argparse
from collections import defaultdict
from fractions import Fraction as F
from functools import lru_cache
from hashlib import sha256
from itertools import product
import json
from math import factorial, prod
from pathlib import Path
from zipfile import ZipFile

PIN = "891d8cbcbd35537e6abc18c938e53b1b4f300327357c24c8d14a51a46ad5e190"
WIDTHS = (F(1,32), F(1,16), F(1,8), F(1,4))
ZERO = F(0)


@lru_cache(None)
def knots(widths):
    # Group equal subset sums before evaluating the truncated powers.
    terms = {ZERO: 1}
    for w in widths:
        updated = dict(terms)
        for s, coefficient in terms.items():
            updated[s + w] = updated.get(s + w, 0) - coefficient
        terms = {s: v for s, v in updated.items() if v}
    half = sum(widths, ZERO) / 2
    return tuple(sorted((s - half, v) for s, v in terms.items()))


@lru_cache(None)
def pdf(widths, x):
    """Density of the sum of independent centered uniform intervals."""
    if 2 * abs(x) >= sum(widths, ZERO):
        return ZERO
    deg = len(widths) - 1
    numerator = sum((c * (x - s)**deg for s, c in knots(widths) if s < x), ZERO)
    value = numerator / (factorial(deg)*prod(widths))
    assert value >= 0
    return value


def check_recurrence(widths, x):
    rest, w = widths[:-1], widths[-1]
    l, r = x-w/2, x+w/2
    breaks = sorted({l,r} | {s for s,_ in knots(rest) if l < s < r})
    result = ZERO
    for lo, hi in zip(breaks, breaks[1:]):
        # Five-point closed Newton-Cotes is exact through degree five.
        result += (hi-lo) / 90 * sum((wt*pdf(rest,lo+(hi-lo)*i/4)
                                      for i,wt in enumerate((7,32,12,32,7))), ZERO)
    assert result/w == pdf(widths, x)


def source_parts(bounds, density):
    l,r = bounds
    support = tuple(map(F,density["support"]))
    l,r = max(l,support[0]),min(r,support[1])
    assert l < r
    period, phase, width = (F(density[k]) for k in ("period","bump_center_mod_period","bump_half_width"))
    base, peak = (F(density[k]) for k in ("density_floor_one_axis","density_peak_one_axis"))
    pieces = [(l, r, base)]
    for j in range(l//period-1, r//period+2):
        a,b = max(l,j*period+phase-width), min(r,j*period+phase+width)
        if a < b:
            pieces.append((a,b,peak-base))
    total = sum(((b-a)*w for a,b,w in pieces), ZERO)
    return total, tuple(((a+b)/2,b-a,(b-a)*w/total) for a,b,w in pieces)


@lru_cache(None)
def brightness(a, side, owner, left, right):
    ow, oc = owner[1]-owner[0], sum(owner)/2
    common = (side,side*a,side*a,ow)
    one = sum((mass*side*pdf(tuple(sorted(common+(w,))), abs(oc-c))
               for c,w,mass in left), ZERO)
    both = sum((mass*mass2*side*pdf(tuple(sorted(common+(w/2,w2/2))), abs(oc-(c+c2)/2))
                for c,w,mass in left for c2,w2,mass2 in right), ZERO)
    assert 0 <= one <= 1 and 0 <= both <= 1
    return one,both


def posterior_cost(groups):
    rs = sorted({r for r,D in groups})
    changes = []
    for r in rs:
        Ds = sorted(D for rr,D in groups if rr == r)
        banks = []
        for D in Ds:
            weights = groups[r,D]
            m = sum(weights.values(),ZERO)
            banks.append({key:v/m for key,v in weights.items()})
        ordered = folded = ZERO
        for old,new in zip(banks,banks[1:]):
            levels = set(old) | set(new)
            diff = {key:old.get(key,ZERO)-new.get(key,ZERO) for key in levels}
            tv = sum(map(abs,diff.values()),ZERO)
            push = defaultdict(F)
            for (z,q),w in diff.items():
                push[tuple(sorted((z,q)))] += w
            tv2 = sum(map(abs,push.values()),ZERO)
            assert 0 <= tv2 <= tv <= 2
            ordered += tv
            folded += tv2
        changes.append((r,len(Ds),ordered,folded))
    nontrivial = [x for x in changes if x[1]>1]
    assert nontrivial
    print("CROSS_PRICE_BUDGET", "multi_bin_rows",len(nontrivial),
          "ordered_TV_range", min(x[2] for x in nontrivial),max(x[2] for x in nontrivial),
          "unordered_TV_range",min(x[3] for x in nontrivial),max(x[3] for x in nontrivial),
          "max_unordered_float",float(max(x[3] for x in nontrivial)))
    # Conditional on each original membership label, the normalized actual source law
    # is the same across price bands. The unordered-label TV dominates true midpoint TV.


def evaluate(name,stage,lib):
    parents = {i["id"]:i for i in stage["parents"]}
    cells = {i["mask"]:F(i["mass"]) for i in stage["cells"]}
    M = F(stage["benchmarks"]["cross"]["mother"])
    roots = stage["roots_cross"]
    count = 0
    summaries = defaultdict(lambda:[ZERO,ZERO,ZERO])
    groups = defaultdict(lambda:defaultdict(F))
    for root in roots:
        t,u,g = (parents[root[k]] for k in ("t","u","g"))
        B = lib["box"](t,"box")
        T = lib["box"](t,"owner")
        Z = lib["intersection"](B,lib["box"](u,"box"))
        Q = lib["intersection"](B,lib["box"](g,"box"))
        lparts = [source_parts(axis,stage["density"]) for axis in Z]
        rparts = [source_parts(axis,stage["density"]) for axis in Q]
        lm,rm = prod(x[0] for x in lparts),prod(x[0] for x in rparts)
        assert lm == sum((cells[z] for z in root["z_masks"]),ZERO)
        assert rm == sum((cells[q] for q in root["q_masks"]),ZERO)
        assert lm*rm*F(root["coefficient"]) == F(root["root_mass"])
        share = F(root["root_mass"])/M
        for a in WIDTHS:
            values = [brightness(a,2*F(t["radius"]),axis,l[1],rr[1])
                      for axis,l,rr in zip(T,lparts,rparts)]
            single = prod(x[0] for x in values)
            mid = prod(x[1] for x in values)
            summaries[a][0] += share*single
            summaries[a][1] += share*mid
            summaries[a][2] += share*int(mid>single)
        for z,q in product(root["z_masks"],root["q_masks"]):
            count += 1
            base = F(root["coefficient"])*cells[z]*cells[q]/M
            for r,mr in cells.items():
                if r & t["bit"]:
                    groups[r,F(t["volume_bin"])][z,q] += base*mr/F(t["m"])
    assert count == 230 and len(roots)==34
    assert sum((sum(g.values(), ZERO) for g in groups.values()),ZERO) == 1
    print("COMB",name,"roots",len(roots),"positive pairs",count,"true mass",M)
    for a,(one,both,share) in summaries.items():
        print("BRIGHT",name,a,"single",float(one),"pair",float(both),
              "fraction_of_root_weight_with_greater_pair_mean",float(share),
              "exact",one,both,share)
    posterior_cost(groups)
    print("These are true-price/central-receiver diagnostics; no independent library qualification or high-dimensional gate inferred.")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--r814",required=True,type=Path)
    path=parser.parse_args().r814
    assert sha256(path.read_bytes()).hexdigest()==PIN
    for widths in [(F(1),F(1,8),F(1,8),F(1,16),F(1,4)),
                   (F(1),F(1,8),F(1,8),F(1,16),F(1,4),F(1,7))]:
        for x in (ZERO,F(1,16),F(3,8),F(1,2),F(5,8),F(2)):
            check_recurrence(widths,x)
    print("Independent spline recurrence",12,"rational cases")
    with ZipFile(path) as z:
        n1,n2 = {"__name__":"frozen_fixture"},{"__name__":"frozen_source"}
        for name,ns in (("comb811.py",n1),("trade813.py",n2)):
            exec(compile(z.read(name),name,"exec"),ns)
        evaluate("original",n1["fixture"](*n1["FIXTURES"][-1]),n2)
        evaluate("rebuilt",json.loads(z.read("comb814-rebuilt.json"))["stages"][0],n2)
    print("PASS true two-arm continuous price and receiver brightness, price-bank variation")


if __name__=="__main__":
    main()
