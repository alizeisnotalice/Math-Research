"""Exact rational convolution at genuine 2D maximal-root receiver cells.

Source densities are positive constants on disjoint squares. The convolution
is exact at the stated center. Receiver-cell enclosures use a rigorous kernel
Lipschitz bound and all candidate-root masks are checked against the full
positive receiver square. Equal-vs-independent smoothing is an algebraic
fixed-parameter comparison, not an optimization charged to individual records.
"""

from fractions import Fraction as F
from itertools import product

LAM = F(100)
WINDOW = (F(9, 20), F(9, 10))
CENTER = (F(1, 25), F(0))
T = F(1, 2)
H = F(1, 10**10)
AS = (F(1, 32), F(1, 16), F(1, 8), F(1, 4))
DIAGNOSTIC = (F(1, 2), F(1), F(2))


def pos(x):
    return max(F(0), x)


def kernel(a, x):
    return sum(
        (
            (-1) ** (i + j + k) * pos(x + F(1, 2) + a - i - a * j - a * k) ** 2
            for i, j, k in product((0, 1), repeat=3)
        ),
        F(0),
    ) / (2 * a * a)


def primitive(a, x):
    return sum(
        (
            (-1) ** (i + j + k) * pos(x + F(1, 2) + a - i - a * j - a * k) ** 3
            for i, j, k in product((0, 1), repeat=3)
        ),
        F(0),
    ) / (6 * a * a)


def factor(a, x, source, eps, scale=T):
    return (
        primitive(a, (x - source + eps) / scale)
        - primitive(a, (x - source - eps) / scale)
    ) / (2 * eps)


def certify_root(sources, eps, center=CENTER, t=T, h=H):
    # Source squares and all receiver points in CENTER+[-H,H]^2 stay
    # strictly on one side of every relevant subset-candidate root face.
    roots = []
    for mask in range(1, 1 << len(sources)):
        m = sum((w for i, (x, y, w) in enumerate(sources) if mask >> i & 1), F(0))
        if not LAM * WINDOW[0] ** 2 < m < LAM * WINDOW[1] ** 2:
            continue
        got = []
        for i, (x, y, w) in enumerate(sources):
            distance = max(abs(center[0] - x), abs(center[1] - y))
            inside = 4 * (distance + eps + h) ** 2 < m / LAM
            outside = distance > eps + h and 4 * (distance - eps - h) ** 2 > m / LAM
            assert inside or outside, (mask, i, "candidate face not resolved")
            if inside:
                got.append(i)
        if sum(1 << i for i in got) == mask:
            roots.append((m, mask))
    assert roots and max(roots)[0] == LAM * t * t
    assert sum(w for x, y, w in sources) < LAM * WINDOW[1] ** 2
    ids = []
    for i, (x, y, w) in enumerate(sources):
        distance = max(abs(center[0] - x), abs(center[1] - y))
        if distance + eps + h < t / 2:
            ids.append(i)
        else:
            assert distance - eps - h > t / 2
    assert sum(sources[i][2] for i in ids) == LAM * t * t
    return ids, roots


def value(sources, eps, a, b, inside, center=CENTER, t=T, h=H):
    terms = []
    for i, (x, y, w) in enumerate(sources):
        f0 = factor(a, center[0], x, eps, t)
        f1 = factor(b, center[1], y, eps, t)
        assert f0 >= 0 and f1 >= 0
        terms.append(w * f0 * f1 / LAM)
    old = sum((v for i, v in enumerate(terms) if i in inside), F(0))
    new = sum((v for i, v in enumerate(terms) if i not in inside), F(0))
    # k_a <= 1; its total-variation derivative gives Lipschitz <=2/a.
    # Product scaling in n=2, center displacement <=H each coordinate.
    error = 2 * h * sum((p[2] for p in sources), F(0)) / (LAM * t**3) * (1 / a + 1 / b)
    return old, new, error


def midpoint_library_density_1d(a, scale, block_halfwidth, coordinate):
    """K_a,t convolved with midpoint of two independent uniform blocks."""
    # Each half of an independent uniform [-eps,eps] has width eps;
    # after scaling by t this adds two normalized boxes of width eps/t.
    extra = block_halfwidth / scale
    widths = (F(1), a, a, extra, extra)
    half = sum(widths, F(0)) / 2
    denominator = 24
    for width in widths:
        denominator *= width
    u = coordinate / scale
    numerator = F(0)
    for bits in product((0, 1), repeat=5):
        shift = sum((width * bit for width, bit in zip(widths, bits)), F(0))
        numerator += (-1) ** sum(bits) * pos(u + half - shift) ** 4
    result = numerator / denominator / scale
    assert result >= 0
    return result


def midpoint_transport_test():
    # The real source masses are 9 and 11. Their independent normalized point
    # pair has original product mass 99; its normalized midpoint pushforward
    # is ONE library measure of mass 1, not an extra copy of full f.
    a = F(1, 8)
    scale = F(3, 5)
    eps = F(1, 10000)
    h = F(1, 100000)
    pair_mass = F(9) * F(11)
    library_mass = F(1)
    factor0 = midpoint_library_density_1d(a, scale, eps, F(0))
    center_value = factor0**2 / LAM
    uniform_error = 2 * h * library_mass / (LAM * scale**3) * (2 / a)
    assert pair_mass == 99 and center_value > uniform_error > 0
    print(
        "MIDPOINT_PAIR_LIBRARY raw_independent_pair_mass=",
        pair_mass,
        "normalized_single_pushforward_mass=",
        library_mass,
        "midpoint_support_halfwidth=",
        eps,
        "receiver_root=",
        scale,
        "a=",
        a,
        "soft_brightness_at_center=",
        center_value,
        "uniform_abs_error<=",
        uniform_error,
        "strict_lower=",
        center_value - uniform_error,
        "center~",
        float(center_value),
    )


def finite_replacement_test():
    """Three disjoint price windows and translated unit intervals."""
    intervals = [(F(0), F(1)), (F(2), F(3)), (F(4), F(5)), (F(6), F(7))]
    windows = [(F(0), F(1)), (F(1), F(3, 2)), (F(3, 2), F(3))]
    assert all(windows[i][1] == windows[i + 1][0] for i in range(2))
    assert sum((b - a for a, b in windows), F(0)) == windows[-1][1] - windows[0][0]
    variation = F(2)  # TV of a unit-interval indicator.
    total = F(0)
    for stage, ((a, b), (c, d)) in enumerate(zip(intervals, intervals[1:])):
        overlap = max(F(0), min(b, d) - max(a, c))
        l1 = (b - a) + (d - c) - 2 * overlap
        assert l1 <= variation
        total += l1
        print(
            "REPLACEMENT stage=",
            stage + 1,
            "L1=",
            l1,
            "TV=",
            variation,
            "price_window=",
            windows[stage],
            "cost=",
            l1,
        )
    assert total == variation * (len(intervals) - 1) == 6
    print(
        "REPLACEMENT total_boundary_cost=",
        total,
        "price_window_union_length=",
        windows[-1][1] - windows[0][0],
        "no_double_count=true",
    )


def run(name, sources, eps):
    ids, roots = certify_root(sources, eps)
    print(
        "\nCASE",
        name,
        "source_halfwidth=",
        eps,
        "receiver_halfwidth=",
        H,
        "mu_total=",
        sum(x[2] for x in sources),
        "inside=",
        ids,
        "true_root=",
        T,
        "candidate_root_mass_masks=",
        roots,
    )
    vals = {}
    for a in AS + DIAGNOSTIC:
        old, new, error = value(sources, eps, a, a, ids)
        if a in AS:
            vals[a] = old + new
        assert old >= 0 and new >= 0
        print(
            "a=",
            a,
            "scope=",
            "theorem" if a in AS else "outside_range_diagnostic",
            "old=",
            old,
            "new=",
            new,
            "G=",
            old + new,
            "G~",
            float(old + new),
            "new~",
            float(new),
            "uniform_abs_error<=",
            error,
        )
    # Shared a on both axes versus independent choices, each sampled uniformly
    # from the same fixed menu AS (no recordwise best-a selection).
    common = sum(vals.values(), F(0)) / len(AS)
    independent = (
        sum(
            (
                sum(value(sources, eps, a, b, ids)[:2], F(0))
                for a, b in product(AS, repeat=2)
            ),
            F(0),
        )
        / len(AS) ** 2
    )
    print(
        "SHARED_AXIS same-menu average=",
        common,
        "independent-axis average=",
        independent,
        "difference=",
        common - independent,
        "difference~",
        float(common - independent),
    )


if __name__ == "__main__":
    # Normalization identities for the exact B-spline density.
    for a in AS + DIAGNOSTIC:
        assert primitive(a, F(1, 2) + a) - primitive(a, -F(1, 2) - a) == 1
        assert kernel(a, 0) >= 0
    # Single-block comparison; same actual window and lambda.
    run("single_block", [(F(0), F(0), F(25))], F(1, 100000))
    sources = [
        (F(0), F(0), F(16)),
        (F(-19, 100), F(0), F(9)),
        (F(35, 100), F(0), F(11)),
        (F(55, 100), F(0), F(22)),
    ]
    # Two actual source squares on opposite sides of the early hard cube:
    # their separation is 27/50 > T. Their midpoint lies in a positive
    # receiver square whose own genuine last root is 3/5.
    early_ids, _ = certify_root(sources, F(1, 10000))
    left, right = sources[1], sources[2]
    midpoint = ((left[0] + right[0]) / 2, (left[1] + right[1]) / 2)
    midpoint_h = F(1, 100000)
    assert abs(left[0] - right[0]) == F(27, 50) > T
    assert 1 in early_ids and 2 not in early_ids
    mid_ids, mid_roots = certify_root(
        sources, F(1, 10000), midpoint, F(3, 5), midpoint_h
    )
    a = F(1, 8)
    # Both entire source blocks and the midpoint receiver cell lie in the
    # strict support of the same early-root kernel K_(a,T)(CENTER-·).
    radius = T * (F(1, 2) + a)
    assert all(
        max(abs(CENTER[0] - p[0]), abs(CENTER[1] - p[1])) + F(1, 10000) + H < radius
        for p in (left, right)
    )
    assert (
        max(abs(CENTER[0] - midpoint[0]), abs(CENTER[1] - midpoint[1])) + midpoint_h + H
        < radius
    )
    assert (
        kernel(a, (CENTER[0] - left[0]) / T) > 0
        and kernel(a, (CENTER[0] - right[0]) / T) > 0
    )
    old, external, error = value(
        sources, F(1, 10000), a, a, early_ids, midpoint, F(3, 5), midpoint_h
    )
    local, local_external, _ = value(
        sources, F(1, 10000), a, a, mid_ids, midpoint, F(3, 5), midpoint_h
    )
    assert old + external == local + local_external and external > 0
    print(
        "\nMIDPOINT source indices=1,2 separation=",
        abs(left[0] - right[0]),
        "early_root=",
        T,
        "early_inside=",
        early_ids,
        "midpoint=",
        midpoint,
        "positive_receiver_halfwidth=",
        midpoint_h,
        "midpoint_true_root=",
        F(3, 5),
        "midpoint_true_capture=",
        mid_ids,
        "window=",
        WINDOW,
        "a=",
        a,
        "full_f=",
        old + external,
        "early_root_source_library=",
        old,
        "outside_early_library=",
        external,
        "midpoint_hard_source_library=",
        local,
        "outside_midpoint_hard_library=",
        local_external,
        "uniform_abs_error<=",
        error,
        "center_floats=",
        float(old + external),
        float(old),
        float(external),
    )
    midpoint_transport_test()
    finite_replacement_test()
    # An exterior positive source block is captured only very near the top
    # of the scale window: verify first-touch and full-entry bounds uniformly
    # over the positive receiver square.
    short_eps = F(1, 100000)
    short_pos = F(12, 25)
    first_touch = 2 * (short_pos - CENTER[0] - short_eps - H)
    full_entry = 2 * (short_pos - CENTER[0] + short_eps + H)
    assert T < first_touch < full_entry < WINDOW[1]
    assert 0 < WINDOW[1] - first_touch < F(21, 1000)
    print(
        "\nSHORT scale-window contact: first_touch>=",
        first_touch,
        "full_entry<=",
        full_entry,
        "contact_length<=",
        WINDOW[1] - first_touch,
    )
    run(
        "short_residence_block",
        [(F(0), F(0), F(25)), (short_pos, F(0), F(11))],
        short_eps,
    )
    # Same source masses/positions and true early root, two concentrations.
    run("ray_blocks_wider", sources, F(1, 10000))
    run("ray_blocks_concentrated", sources, F(1, 1000000))
    print(
        "\nPASS exact center convolution plus rigorous positive receiver-cell bounds; no general extremal conclusion"
    )
