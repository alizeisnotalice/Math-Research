#!/usr/bin/env python3
"""Joint two-scale lattice-packet statistics with exact receiver dx compression."""
from fractions import Fraction as F
from math import comb,isqrt
from itertools import product
from pathlib import Path
from collections import Counter
import json,hashlib
BASE=Path(__file__).resolve().parent;C=Counter()
def ck(k,v):
 C[k]+=1
 assert v,k
def brief(x):
 x=F(x);d=hashlib.sha256()
 for a in [x.numerator,x.denominator]:
  raw=abs(a).to_bytes(max(1,(abs(a).bit_length()+7)//8),'big');d.update(len(raw).to_bytes(8,'big'));d.update(raw)
 out={'display':float(x),'fraction_sha256':d.hexdigest()}
 if x.numerator.bit_length()+x.denominator.bit_length()<1000:out['exact']=str(x)
 return out
def geometry(a,h):
 rs=[F(a),F(3*a+1,3),F(3*a+2,3),F(a+1)];points={F(0),F(1)}
 for r in rs:
  for z in range(-a-3,a+4):
   for p in [z-h-r/2,z+h-r/2,z-h+r/2,z+h+r/2]:
    if 0<p<1:points.add(p)
 groups=Counter();kept=[];discard=F(0)
 for lo,hi in zip(sorted(points),sorted(points)[1:]):
  sig=[];valid=True
  for r in rs:
   count=0
   for z in range(-a-3,a+4):
    inside=(hi-r/2<=z-h and z+h<=lo+r/2)
    outside=(z+h<=lo-r/2 or z-h>=hi+r/2)
    if inside:count+=1
    elif not outside:valid=False
   sig.append(count)
  if valid:
   ck('whole_positive_packet_receiver_geometry',sig[0]==a and sig[3]==a+1 and tuple(sig[1:3]) in [(a,a),(a,a+1),(a+1,a+1)])
   groups[tuple(sig[1:3])]+=hi-lo;kept.append([str(lo),str(hi),sig])
  else:discard+=hi-lo
 ck('complete_1D_classification',sum(groups.values())+discard==1)
 ck('three_joint_count_category_weights',len(groups)==3 and all(w==F(1,3)-4*h for w in groups.values()))
 return rs,groups,kept,discard
def statistics(distribution):
 total=sum(distribution.values(),F(0));X=sum((q*p for q,p in distribution.items()),F(0));tail=F(0);best=F(0);bestlambda=F(0);bestabove=F(0)
 for q in sorted(distribution,reverse=True):
  tail+=distribution[q]
  if q*tail>best:best=q*tail;bestlambda=q
  if q>1:bestabove=max(bestabove,q*tail)
 return total,X,best,bestlambda,bestabove
def run(stage,n):
 before=sum(C.values());a=isqrt(n)
 if a*a<n:a+=1
 h=F(1,100*n);rs,groups,intervals,discard=geometry(a,h);w=F(1,3)-4*h;unit=w**n
 qs=[[F(a+1)**d*F(a)**(n-d)/r**n for d in range(n+1)] for r in rs[1:3]]
 dist=[Counter(),Counter(),Counter()];statecount=0;ambiguous=F(0)
 for z in range(n+1):
  for y in range(n-z+1):
   x=n-y-z;count=comb(n,z)*comb(n-z,y);q1=qs[0][z];q2=qs[1][y+z];q=max(F(1),q1,q2);statecount+=1
   dist[0][max(F(1),q1)]+=count;dist[1][max(F(1),q2)]+=count;dist[2][q]+=count
   if q1>1 and q2>1:ambiguous+=count*unit
 ck('multinomial_complete_receiver_domain',sum(dist[2].values())==3**n)
 if n<=4:
  direct=[Counter(),Counter(),Counter()]
  for st in product(range(3),repeat=n):
   z=st.count(2);y=st.count(1);q1=qs[0][z];q2=qs[1][z+y]
   for dd,q in zip(direct,[max(F(1),q1),max(F(1),q2),max(F(1),q1,q2)]):dd[q]+=1
  ck('independent_small_tensor_enumeration',all(direct[j]==dist[j] for j in range(3)))
 dist=[{q:count*unit for q,count in dd.items()} for dd in dist]
 V=(3*w)**n;stats=[statistics(dd) for dd in dist]
 ck('positive_receiver_dx_compression',all(t[0]==V for t in stats))
 ck('joint_true_max_average_dominates_each_scale',stats[2][1]>=max(stats[0][1],stats[1][1]))
 ck('finite_four_menu_first_moment_bound',stats[2][1]<=4)
 ck('joint_weak_ratio_dominates_one_scale',stats[2][2]>=max(stats[0][2],stats[1][2]))
 if n>=4:ck('nontrivial_joint_tail_strictly_improves_single_scales',stats[2][4]>max(stats[0][4],stats[1][4]))
 eps=F(119,3072);s=1+isqrt(n);required=F(s)/eps
 ck('four_menu_highpast_necessary_threshold_excluded',4<required)
 bands=[]
 for lam in [F(1),F(5,4),F(3,2),F(2),F(3)]:
  vol=sum((p for q,p in dist[2].items() if F(3,4)*lam<=q<=lam),F(0));X=sum((p*q for q,p in dist[2].items() if F(3,4)*lam<=q<=lam),F(0));strict=sum((p for q,p in dist[2].items() if q>lam),F(0));qJ=F(3,4)*lam*vol
  ck('qband_actual_first_moment',F(3,4)*lam*vol<=X<=stats[2][1])
  ck('original_highpast_necessary_gate_empty',qJ<required)
  bands.append(dict(lambda_=str(lam),qband_volume=brief(vol),qband_lambda_volume=brief(lam*vol),strict_weak_ratio=brief(lam*strict),packet_column_J=brief(vol),qminus_J=brief(qJ),required_s_over_epsilon=str(required),highpast='empty'))
 L=100*n*a;B=a+2;interior=F(2*(L-B),2*L+1)**n
 ck('finite_L1_source_and_receiver_margin',B>rs[3]/2+h+1 and L-B>rs[3]/2+1)
 return dict(stage=stage,n=n,a=a,b=str(rs[3]),packet_halfwidth=str(h),radii=list(map(str,rs)),receiver_1D_intervals=intervals,discarded_1D_length=str(discard),tensor_states=statecount,receiver_volume=brief(V),both_noninteger_averages_above_one_volume=brief(ambiguous),comparisons=[dict(reference=name,Xq=brief(t[1]),strict_weak_supremum_left_limit=brief(t[2]),threshold_left_limit=brief(t[3]),strict_weak_supremum_lambda_above_one=brief(t[4])) for name,t in zip(['integer_baseline_plus_a_one_third','integer_baseline_plus_a_two_thirds','joint_two_noninteger_scales'],stats)],bands=bands,finite_truncation=dict(L=L,full_source_mass=f'({2*L+1})^{n}',receiver_interior_periods=f'({2*(L-B)})^{n}',period_ratio=brief(interior),joint_finite_weak_supremum_left_limit=brief(stats[2][2]*interior),joint_finite_weak_supremum_lambda_above_one=brief(stats[2][4]*interior)),exact_checks=sum(C.values())-before)
def main():
 rows=[run(st,n) for st,ns in [('initial',[1,4]),('stress',[16,64]),('expanded',[100,256])] for n in ns]
 out=dict(status='PASS',total_exact_checks=sum(C.values()),check_counts=dict(C),models=rows,scope='True positive receiver dx compression and full packet capture geometry; periodic calculation legalized only through explicit finite lattice-box interior. No original BH, source overlap integral, or original highpast path simulation. qminus J highpast necessity handled explicitly, not inferred just from J<=1.')
 (BASE/'r354_numeric_result.json').write_text(json.dumps(out,sort_keys=True,indent=2)+'\n');print(json.dumps(dict(status='PASS',total_exact_checks=sum(C.values()),models=[dict(n=x['n'],weak_above_one=[y['strict_weak_supremum_lambda_above_one']['display'] for y in x['comparisons']],X=[y['Xq']['display'] for y in x['comparisons']],states=x['tensor_states']) for x in rows]),sort_keys=True))
if __name__=='__main__':main()
