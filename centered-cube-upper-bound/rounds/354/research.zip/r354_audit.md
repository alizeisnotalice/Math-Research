# R354 final independent audit — PASS as a diagnostic-model result, no new receipt

Read the final main, unchanged-price ledger, README, lattice bridge including its larger-padding variable map, numeric code/result/notes, and bridge-check code. Only owned audit files were written. No author files, Git state, or full optimization pipeline were modified/repeated. General weak-type closure and the full historical reduction are not certified by this audit.

## 1. Exact actual receiver-volume model: PASS

The one-dimensional face-breakpoint partition tests complete capture or complete exclusion of every packet throughout each positive receiver interval, for all four menu sides. Transition intervals are discarded explicitly. The finite index search covers all packets that could intersect the bounded cubes. The integer sides have exact average one on retained intervals. The two noninteger counts have precisely the three recorded signatures, with exact total length 1/3-4h each.

The tensor compression is actual Lebesgue receiver volume, not random receiver samples. Coordinates of these signatures produce the exact multinomial weights and the correlated pair of noninteger averages. q1 uses z high-count coordinates; q2 uses y+z, preserving their dependence. Multinomial weights sum to the complete retained domain, and independent explicit small-dimensional enumeration checks the compression. All selected averages are actual masses divided by the actual cube volumes. n=256 has (257*258)/2=33,153 states. The tested dimensions are perfect squares; isqrt plus exact integer comparison chooses a=ceil(sqrt(n)) without floating decisions.

The computed joint tails strictly improve both individual noninteger-scale tails for the reported n>=4 on the same retained domain. This is a finite-model decision, not a lower dimension exponent, an overall norm above one, or an upper bound on the unrestricted maximal operator. The omitted transition receivers remain untested and are not charged as captured.

## 2. Strict weak ratios versus bands: PASS

For a finite distribution of q values, statistics() accumulates P(Q>=q) at each support value and computes q P(Q>=q). This is the correct left limit of lambda P(Q>lambda) as lambda approaches q from below. It is not the strict value at lambda=q, and the notes/main expressly preserve that distinction. The lambda>1 calculation excludes the baseline q=1 support value. The actual strict values at the five recorded lambda use q>lambda; the separate q-band uses 3lambda/4<=q<=lambda. Their volumes and first moments are not identified.

All comparisons/optimizations in the scripts use Fraction arithmetic. float() values in displays and tables are summaries, not comparison certificates. The n=256 displayed 0.511924 joint tail and its individual comparators match the stored output. No near-1 p-dependent maximal constant or a general dimension-order extrapolation is introduced.

## 3. Finite positive-L1 realization and padding: PASS

The infinite periodic source is only the exact computational device. The bridge constructs an actual source from finitely many mass-one packets, of exact mass (2M+1)^n, and uses only an integer-period receiver interior with enough padding that every menu average there agrees exactly with its periodic value. Positivity and actual receiver dx are retained.

The final extra bridge sentence correctly maps script variables: source index radius L=100na, receiver half-width L-Bpad, Bpad=a+2, and maximum menu radius a+1. This padding is larger than the minimum required by ceil(B/2)+1; the exact volume ratio is [2(L-Bpad)/(2L+1)]^n. The Bernoulli estimate uses the actual padding, with no dimension-uniform limiting shortcut. In particular the n=256 factor 0.988504 is the display of that exact rational quantity.

The finite-source values obtained by multiplying the periodic receiver statistic by this factor are certified LOWER bounds from the retained interior on the actual finite-source weak ratio (or suprema of those certified bounds). They are not exact optima of the full finite-source maximal operator, which can have additional exterior/transition receivers. The final bridge explicitly supplies this inequality; the report's approximately 0.506039 conversion is valid in that sense, and the final main/README now explicitly call it a certified interior lower bound rather than the complete finite-source norm. Strict E_alpha, rather than a closed band at its endpoint, is used for strict-halo lower bounds.

## 4. True inverse-mass column and high-past scope: PASS

For a source point inside any packet, face exclusion makes capture constant across that packet. For every base receiver t, summing its integer translates that capture this source counts the same N_R(t) lattice packets captured by its selected cube. Therefore the periodic column J_y=int_Eper c_x(y)/m_x dx equals |E_band|. Finite receiver truncation only decreases J, including for source packets near the finite source boundary.

The correct dimension/threshold inequality is q_-J<=int_Eband q<=m, where m is the number of menu sides. Its last bound follows from each fixed-radius periodic average having full-period integral one; it is not merely a finite experiment. With m=4, the necessary strict high-past threshold is impossible for this family. J<=1 alone would be insufficient because q_-=3lambda/4 varies with lambda. The bridge and main correctly retain this dependence and cover all bands in this four-menu model, rather than only the five displayed lambda.

This says nothing comparable for arbitrary many radii, nonuniform sources, or the general difficult field. The final necessary large-menu condition lambda|E_band|>(4/3)(1+sqrt(n))/epsilon is correct but is not an existence or impossibility theorem. The reported model cannot realize the remaining original high-past/B_H core. Its multiscale weak-tail gain does not validate original B_H, its all-source overlap square, the R353 crossing load, or full native/historical qualifications.

## 5. Evidence and actual execution scope

The parent reports fresh executions: numeric PASS 157 Fraction assertions and bridge_checks PASS 6,942 exact translated-count/padding checks. I read their entire code and the frozen result rather than repeat those pipelines. The numeric result contains the six stated dimensions, 33,153 states at n=256, and the stated table values.

The bridge script's translated-count checks evaluate a finite rational grid of centers and three packet locations; they are exact diagnostics, not the proof of the universal periodic identity. Its padding checks use exact rational powers and isqrt on the selected square dimensions. The analytic bridge proves the full continuous claims independently. No floating decision enters those checks.

My independent preliminary process ran 13 Fraction lattice-count/q-band/padding assertions. In final review I also checked metadata and one exact discrete example distinguishing a strict threshold value from its left-limit value. These are auditor checks, separate from parent/author totals. No solver or new external literature assertion is part of this round's adopted result.

## 6. Ledger and unresolved global task: PASS, no new payment

The final ledger keeps R353's exact order G_core->clock-near->source-inner->restricted R352 recapture->F_edgefresh, including its initial-witness-only spatial gate. It changes no price or absorption coefficient. Conditional on the historical CZ contribution belonging to the same certified X account, the coefficient remains <889/2304 and unallocated headroom >1415/2304. This is not a payment for the remaining terms.

The fresh cross-path occupation, general soft/crossing terms, hard-contract exterior coupled tails, low-pe/distance/extreme-scale/threshold complements, all historical initial/deletion/future-deleted-source atoms, H/layer/source/physical-scale/outer-integral/truncation-limit costs are retained. Physical terminal atoms and rank stopping do not substitute for chronological atoms, and negative overlap credit remains single-use. The four-menu model's empty high-past gate is not used to remove the general high-past slot. Unused heatbath/Astra/Gram notes are not certified as new paid tools in the adopted archive.

## Conclusion

PASS for the exact multiscale diagnostic, finite-L1 bridge, model-specific high-past exclusion, final evidence scope, and unchanged complete ledger. This round supplies no new generally payable B_H branch. General arbitrary-input root-order weak type remains unproved; the report's decision to change future diagnostic geometry is supported only within these precise limitations.

## Frozen SHA256 bindings

Current adopted files plus necessary inherited ledger interfaces. Historical bindings do not mean that all past reductions were re-audited.

```
7999dd67eecc094ad582d7885525dcdeee350e8492382e5d48b18b94e6ccccd9  /tmp/r354_main.md
4a69b9234fa7e42361564fb209f710308368d5e9070dc71b63ce153dce62fb4b  /tmp/r354_ledger.md
5f21930e779959f8cf966f9cc1cfe239b8562400fef2128a06845428dbb357eb  /tmp/r354_readme.md
7ffefa8f47230ced7c1fcf1d43bd8e6a40fa31e80c2f2307bafa2167855b50a6  /tmp/r354_lattice_bridge.md
62bb051d12471ff2d2e42ef1803890b245f2237f434557e6c1e886fe38169ac9  /tmp/r354_numeric.py
3a13fa2090392cef61ee34f70d8952d9bf392b688e0195c649bf1abe585bd1ca  /tmp/r354_numeric_result.json
1be2d1cd638c8c0976ea6d5c4b3932a31dc3718d839d5467fbc07df05566981f  /tmp/r354_numeric.md
384424cac1e059afafd2a100e640ef6d9ec54f6b4ebd2bd8f53cd38dcbe95c22  /tmp/r354_bridge_checks.py
7dd73e9a1df3381204306f261047e68f9692a53c76e2fb1635a765df2579b7ee  /tmp/r354_audit_pre.md
77250864bef33b7df84c46fe0fff6353b91b6a566ec5a436388112ab08624eae  /tmp/r353_ledger.md
c0a99aa47c05f0425bb89596a82698682fc92b462320146fbf373a7ee4fdba42  /tmp/r353_geometry.md
3395925e97e1b2f4b983f03cb47a643b46fb3883e9386c27a77ba5916d13fd5a  /tmp/r353_audit.md
```
