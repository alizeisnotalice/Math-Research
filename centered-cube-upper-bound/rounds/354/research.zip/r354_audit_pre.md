# R354 independent preliminary audit — periodic lattice diagnostic bridge

No new R354 author proof was read before this screen. Only the parent-supplied propositions and frozen hard matched-field conventions are used. This is a diagnostic migration result, not a general B_H payment or a proof of a dimension-order bound.

## 1. Precise model and periodic capture identity — PASS

Assume 0<h<1/2, one nonnegative packet of total mass one centered at each z in Z^n, with support in the cube of side 2h. Fix a finite menu R_1,...,R_m in (0,B] and a measurable Z^n-periodic selector taking values in that menu. In the base unit cell, remove all points where any selected-menu cube face is within h of an integer coordinate. On the remaining periodic receiver set, every packet is either wholly captured or wholly missed, so the full periodic source mass m_x is the integer N(x) counting captured lattice packets. The active q-band subset E_0 must have m_x>0 and q_x=N(x)/R_x^n in [q_-,lambda]. Positive measure of that subset is an additional model property to be checked; face exclusion and a menu alone do not guarantee it.

For any source y in a packet (up to irrelevant source boundary null sets), capture is constant across that whole packet. For fixed base point s, summing capture over translated receivers s+k counts exactly N(s) lattice points. Since the selector and denominator N are periodic,
 J_y(b)=int_{R^n}1_{E_per}(x)c_x(y)/m_x dx
       =int_{E_0}[sum_{k in Z^n}c_{s+k}(y)]/N(s) ds
       =|E_0|.
The sum is locally finite because all radii are <=B. Tonelli justifies the interchange. The same identity holds on every packet by translation; no assertion about source-free points is needed. Receiver truncation preserves the old field on its retained receivers and only decreases this nonnegative J.

## 2. Correct high-past emptiness test — PASS

The useful inequality is
 q_- J_y <= q_-|E_0| <=int_{E_0}q_x dx<=m.
For each fixed menu radius, its periodic average convolution over a base cell equals the source mean one. Splitting E_0 by the actual selected radius and enlarging each selector piece to the entire base cell proves the last bound. No independent choice of a radius at each source is introduced.

Consequently if m<=(1+sqrt(n))/epsilon, the original strict gate J_y>(1+sqrt(n))/(epsilon q_-) is empty on the actual source packets, also for any finite receiver truncation. The simpler observation J_y<=1 does NOT alone prove that emptiness, because q_-=3lambda/4 and the gate depends on lambda. The result is particular to this finite-menu complete-packet periodic family; it cannot rule out original high-past inputs generally.

## 3. Finite L1 realization and padding factor — PASS

Take an integer L>=1 and receivers in [-L,L)^n. Set c=ceil(B/2)+1 and M=L+c (integer), and retain source packets centered at z in [-M,M]^n intersect Z^n. Then W=(2M+1)^n. The source padding is sufficient to make every menu average at those receivers exactly its periodic value: all packets meeting any allowed cube are retained. Selected true masses, q-band, and complete-packet capture are therefore unchanged.

Let E_alpha be the base-cell subset where the selected average is STRICTLY greater than alpha (or any certified subset of the strict menu halo). The finite positive-L1 maximal-function ratio satisfies
 alpha |{M f>alpha}|/W >=alpha |E_alpha| [2L/(2M+1)]^n.
Use a strict E_alpha when the target halo is strict; a mere >=alpha selector value cannot by itself certify membership. Integer L ensures the receiver box contains exactly (2L)^n complete unit cells.

Since 2M+1=2L+2c+1, convexity/Bernoulli yields
 [2L/(2M+1)]^n=[1+(2c+1)/(2L)]^{-n}
 >=1-n(2c+1)/(2L)>=1-tau
when 0<tau<1 and L>=n(2c+1)/(2tau). One may round L upward to an integer. This is a dimension-dependent finite padding choice. With n fixed the factor tends to one as L increases; fixed L does not give a dimension-uniform limiting assertion. No lower halo asymptotic or general upper bound follows without a separately certified |E_alpha|.

## 4. Actual local computation and scope

Executed a fresh Python Fraction diagnostic with h=1/20 and menu {1,3/2,2} in one dimension. Partitioning the base cell at all excluded-face endpoints, choosing a maximal menu average, and counting capture over receiver translates gave allowed base volume 3/5, integrated selected q=7/10, q in [1,4/3], and packet J=3/5. Additional rational padding tests checked the stated factor in dimensions 1,4,16. Total 13 exact assertions. These are auditor diagnostic checks, not a high-dimensional original high-past realization, and are not added to parent/author counts.

Status: the periodic capture identity, menu-count high-past obstruction, and finite-L1 migration are valid with the stated positivity/strict-halo/integer-padding conditions. Await the author proof and final scope before file-level certification. No new general root budget is proved by this screen.

## After-screen author-file comparison

Read the delivered lattice bridge after completing the independent screen. PASS: the author explicitly requires integer L, strict E_alpha for a weak-halo lower ratio, positive band rows, full actual receiver integrals, and the q_-J/menu inequality rather than using J<=1 alone. Its padding bound is written equivalently as (1-z)^n>=1-nz with z=(2c+1)/(2M+1); the stated stronger L condition suffices. Its last necessary condition lambda|E0|>(4/3)(1+sqrt(n))/epsilon is correct, not an existence claim. No general payment or dimension-uniform asymptotic is asserted.

Author bytes reviewed: `ea3c1224c6510ec6e32768a73f530a4c92287214ed35ddf19e2704c314a52cab  /tmp/r354_lattice_bridge.md`. This comparison does not audit any later R354 main/numeric/ledger files.
