# R354 — Finite L1 realization and the correct homogeneous-column test

This is a diagnostic-model realization, not a proof of the general root upper bound. It prevents the current numerical exploration from treating a periodic nonintegrable source or a finite menu as the original hard problem.

Fix n, a finite rational radius menu R_1,...,R_m with B=max R_j and B/a<=2, and 0<h<1/2. Place mass-one uniform packets on z+[-h,h]^n for each integer z. The infinite periodic field is only a calculation device. Let G be the subset of [0,1)^n on which no coordinate of either face x_i +/- R_j/2, for any j, is within distance h of an integer. The excluded volume is at most 4mnh by the union bound; no approximation based on this bound is used when the actual cell lengths are computed exactly.

For x in G each packet is entirely captured or entirely missed by every menu cube. Let N_j(x) be the number of captured lattice points. The exact cube average is q_j(x)=N_j(x)/R_j^n. Any measurable translation-equivariant menu selector defines a periodic R(x), m(x)=N_R(x), q(x)=m(x)/R(x)^n. Restrict receivers to a positive-mass band E0 subset G with 3lambda/4<=q<=lambda; zero-mass rows are excluded. All source and receiver integrals below are actual Lebesgue integrals, not weights at receiver samples.

## Finite realization with an explicit boundary factor

Take integers L>=1 and c=ceil(B/2)+1 and put M=L+c. Define the actual integrable source

  f_M(y)=(2h)^(-n) sum_{z in Z^n intersect [-M,M]^n} 1_{z+[-h,h]^n}(y).

Its exact mass is W_M=(2M+1)^n. Use only receivers x in [-L,L)^n and their periodic good set and selector. Every packet meeting a menu cube at such x belongs to the chosen finite source box; the margin c exceeds B/2+h. Hence all menu masses/averages at those receivers agree exactly with the periodic calculation.

For any exactly computed strict superlevel set E_alpha={x in G:max_j q_j(x)>alpha}, its replicated finite receiver volume is (2L)^n |E_alpha|. Thus the actual L1 maximal weak ratio is at least

  alpha |E_alpha| [2L/(2M+1)]^n.

The same factor converts the exact band ratio lambda |E0| to the finite band's lambda|E|/W_M (this is a band diagnostic, not by itself a strict superlevel at lambda). If 0<tau<1 and L>=n(2c+1)/(2tau), Bernoulli's inequality gives

  [2L/(2M+1)]^n >=1-n(2c+1)/(2M+1)>=1-tau.

One may equally use any larger integer padding c>=ceil(B/2)+1; all exact formulas and the Bernoulli bound use that actual c. The numerical script names the source-box radius L and the receiver half-width L-Bpad, with Bpad=a+2 and maximum menu radius a+1; this is the same construction with M=L, receiver parameter L-Bpad, and actual padding Bpad.

All parameters are finite. No dimension-uniform passage h to zero is invoked. Near cube-face transition regions are excluded explicitly, and their exact lengths enter the experiment; omitted receivers are never charged as if tested.

## Actual inverse-mass column in the periodic band

For any y in the interior of one source packet, all capture indicators on the good receiver set are unchanged as y varies through that packet. Define the periodic column

  J_y = integral over all periodic band receivers 1_{y in Q_R(x)(x)} / m(x) dx.

Only finitely many translates can capture that y. Write x=k+t, t in E0. For a fixed t, the number of integer k for which y lies in Q_R(t)(k+t) equals the number N_R(t) of integer source packets captured by Q_R(t)(t). The equality follows from k -> -k, and remains valid for every y inside a packet by the good-face exclusion. Consequently

  J_y = integral_E0 N_R(t)/N_R(t) dt = |E0|.

For the truncated receiver set, its column is at most this periodic column. It is not permissible to conclude that high-past is empty merely from J<=1: its threshold h_past=(1+sqrt(n))/(epsilon q_-) depends on lambda.

The valid finite-menu check is instead

  q_- J_y <= (3lambda/4)|E0| <= integral_E0 q(x) dx <= m.

Indeed every fixed-radius periodic cube average has integral 1 per unit cell (by periodic convolution/Fubini), and the chosen q is at most sum_j q_j, including outside G for this upper bound. Thus if m <= (1+sqrt(n))/epsilon, the strict original high-past condition Z_y(m_u/K-) > (1+sqrt(n))/(epsilon q_-) cannot hold anywhere in this finite-band model. This statement remains true for the finite L1 realization. It is only a finite-menu exclusion test, not a bound independent of menu size or a general cube maximal estimate.

For arbitrary large menus, homogeneous periodic mass transport gives the necessary condition for nonempty high-past

  lambda |E0| > (4/3)(1+sqrt(n))/epsilon.

Whether such weak ratios can occur is not decided here. The observation directs future numerical work toward nonuniform source columns if the purpose is to realize the unresolved high-past/core geometry. It does not rule out uniform lattice inputs in general, nor does it prove the target upper bound.
