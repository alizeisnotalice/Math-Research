R354 actual lattice-packet / joint-scale numerical exploration

Frozen fresh local Python processes returned PASS 157 exact Fraction assertions. The three stages are initial n=1,4; stress n=16,64; expanded n=100,256. This is an exploration of true receiver-volume integrals and selected average distributions, not a repeated single-step probability check. All optimization over the finite distribution uses rational comparisons; decimals in the result and tables are displays only.

Reproduce:

```
/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 r354_numeric.py
```

The self-contained script writes r354_numeric_result.json beside itself. No solver, historical temporary input, or nonstandard Python package is required. Only this note, script, and result are deliverables.

Actual geometry and joint compression. Set a=ceil(sqrt(n)), h=1/(100n), and use sides {a,a+1/3,a+2/3,a+1}, all within [a,2a]. Every integer lattice point carries a uniform packet of side 2h and mass 1. For every 1D receiver interval, all breakpoints where a cube face meets a packet endpoint are inserted. A subinterval is retained only if every packet is wholly captured or wholly missed by every menu side. This exact classification includes the integer baselines as well as both noninteger sides; partial capture intervals are discarded, not approximated.

The two noninteger counts have three possible joint signatures (a,a), (a,a+1), (a+1,a+1), each of exact total 1D length 1/3-4h. For x,y,z coordinates of the three types, x+y+z=n, the exact receiver volume is n!/(x!y!z!)(1/3-4h)^n. The two actual averages are

q1=(a+1)^z a^(n-z)/(a+1/3)^n,
q2=(a+1)^(y+z) a^x/(a+2/3)^n.

The selector uses max(1,q1,q2), with the integer baseline when it wins. These are actual masses divided by actual cube volumes; no average is reset. Each single-scale comparator uses the identical retained receiver domain and max(1,qj). Independent small-dimensional tensor enumeration checks the count compression. The n=256 calculation uses 33,153 multinomial states, rather than receiver samples or 3^256 explicit coordinates.

Decision-relevant finite results:

| n | sup over lambda>1, first noninteger scale | second scale | joint two scales | joint integral q per source period |
|---:|---:|---:|---:|---:|
| 4 | 0.438037 | 0.560224 | 0.630252 | 1.102498 |
| 16 | 0.425710 | 0.371379 | 0.528784 | 1.119258 |
| 64 | 0.364831 | 0.393687 | 0.523660 | 1.133072 |
| 100 | 0.373677 | 0.395908 | 0.527521 | 1.135923 |
| 256 | 0.360717 | 0.374534 | 0.511924 | 1.140140 |

The weak quantity is lambda times the actual strict superlevel volume, per unit source period. The displayed suprema are computed through exact left limits at the finitely many average values; a left-limit threshold need not attain the strict supremum. The result separately provides actual strict values at lambda=1,5/4,3/2,2,3. For example, at n=256 and lambda=5/4, the joint strict weak ratio is 0.396612, while the q-band ratio lambda |{3lambda/4<=q<=lambda}| is 0.712008. These different sets are never identified. The overall weak supremum including lambda approaching 1 from below is dominated by the integer baseline and is not evidence for multiscale improvement; the table deliberately isolates lambda>1.

Thus two noninteger scales measurably improve their individual nontrivial tails on this true-volume model. No computed ratio exceeds 1; no general dimension exponent or asymptotic growth is inferred. This is distinct from the earlier abandoned one-noninteger-scale baseline, for which the Markov obstruction gave no useful multiscale decision.

Finite L1 realization. The periodic source is only a calculation device and is not claimed integrable. The actual source consists of packets centered at lattice points in [-L,L]^n, with L=100na; its total mass is (2L+1)^n. Only receiver unit cells inside [-L+B,L-B)^n are used, B=a+2. The code checks a margin stronger than B>(a+1)/2+h+1, so every selected receiver cube sees exactly the periodic packet masses. The exact receiver-period/source-period factor is [2(L-B)/(2L+1)]^n. It is 0.977703 at n=4, 0.986960 at n=64, and 0.988504 at n=256. Thus the real finite-source ratios lose a controlled small factor, rather than an exponential source/receiver imbalance. The n=256 joint lambda>1 strict weak supremum after this factor is approximately 0.506039. All source and retained receiver sets have positive volume; omitted transition and outer-boundary receivers are not charged as though tested. See the parent's separate r354_lattice_bridge.md for the analytic realization argument; the script independently checks its explicit finite margins and factors.

Correct high-past diagnosis. Within a packet, all retained capture indicators are constant. Translation mass transport, or counting all receiver-cell translates capturing that packet, gives the periodic terminal column J=|E_band per period|, not merely its contribution from the central receiver cell. The truncated column is no larger. J<=1 alone DOES NOT rule out the original high-past threshold, because q_-=3lambda/4 varies with lambda. Instead, for a menu of M=4 sides,

q_- J <= integral_E q <= integral_period max_menu q <= M=4.

The first-moment bound is tested exactly; at each of the five recorded lambda bands the program also records and compares the actual q_-J. With epsilon=119/3072 and s=1+sqrt(n), 4<s/epsilon in every tested dimension, so the necessary original high-past condition q_-J>s/epsilon is absent throughout this finite-menu family. This explains why its successful weak-ratio comparison does not probe the remaining high-past/core traffic. It neither excludes arbitrary large menus nor proves a general upper bound. For large menus, the necessary condition lambda |E_band|>(4/3)s/epsilon must be retained; source homogeneity alone does not settle it.

Not computed: original BH, all-source overlap square, R353 spatial-crossing load, or full historical/native rank qualifications. The task was narrowed by the parent to actual lattice multiscale weak-ratio and q-band diagnostics once the original vertex model and single noninteger menu were found insufficient. The model gives a concrete positive multiscale effect, but no paid remainder or root-bound claim.
