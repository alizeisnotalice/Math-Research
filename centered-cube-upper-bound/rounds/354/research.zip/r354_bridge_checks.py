from fractions import Fraction as F
from math import isqrt
checks=0
for a in [1,2,4,8,10,16]:
 h=F(1,100*a*a)
 for R in [F(a),F(a)+F(1,3),F(a)+F(2,3),F(a+1)]:
  for t in [F(j,97) for j in range(97)]:
   if any(abs(t+sgn*R/2-z)<=h for sgn in [-1,1] for z in range(-a-3,a+4)):continue
   N=sum(abs(F(z)-t)<=R/2 for z in range(-a-3,a+4))
   for y in [-h/2,F(0),h/2]:
    translated=sum(abs(F(k)+t-y)<=R/2 for k in range(-a-3,a+4))
    assert translated==N
    checks+=1
for n in [1,4,16,64,100,256]:
 a=isqrt(n);L=100*n*a;pad=a+2;M=L;inner=L-pad
 ratio=F(2*inner,2*M+1)**n
 assert ratio>=1-F(n*(2*pad+1),2*M+1)
 assert pad>F(a+1,2)+F(1,100*n)
 checks+=2
print('PASS',checks,'exact translated-packet count and finite-padding checks')
