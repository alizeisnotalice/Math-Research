# 第354轮完整总账：沿用353，未增加付款

沿用351原入口和352已认证分支，不重新认证历史全局归约。\(W=\int f\)，\(X_q=\int_Eq\le X=\lambda|E|\)，\(W_{ex}=\int g_{ex}\)，\(\varepsilon=119/3072\)，\(\Lambda=128/119\)，\(s=1+\sqrt n\)。原入口不变：
\[
T_{entrance}\le8\lambda HW+2d_{eff}A_nW_\nu/H+2B_H.
\]
取 \(A_n=1+n\log(b/a)\)，\(\sigma^n=\min(1,s/A_n)\)。第353轮从351的原标记核心重新准确分解：先取 \(r\ge\sigma R_{w_0}\)；再取其补集中 \(y\in\sigma Q_{w_0}\)；剩余R才应用352的首次回捕分解。因此
\[
G_{core}=G_{clock}+G_{inner}+B_{rec,R}+F_{edgefresh}.
\]
四项非负且无重复。初始w0上的core门、原y,u,v,r和原字段均冻结。由sourcewise秩列与原时钟，
\[
G_{clock}\le c_{eff}X_q,\quad G_{inner}\le sW_{ex},\quad
B_{rec,R}\le\alpha_{rec}X_q.
\]
原highpast必要条件失效则全流零、c_eff=alpha_rec=0；否则
\[
c_{eff}=(\lambda/q_-)e^{-\sqrt n}\max(1,A_n/s)<\varepsilon/16,
\quad\alpha_{rec}=N/(e^{\sqrt n}-1)<\varepsilon/16.
\]
N及原质量带同352。新R的边缘仍不超过q且祖先严格质量链不变，故352可同价应用。不得同时再收旧whole-Gcore的首次回捕费。

完整当前硬层账：
\[
B_H\le F_{edgefresh}
+[(13/3)\varepsilon+\gamma_{eff}+\beta+\alpha_{rec}+c_{eff}]X_q
+[C_{\varepsilon,n}+4s]W+(D_{top,n}+C_{hit,n}+s)W_{ex}.
\]
\(\beta=\varepsilon/16\) 为350/351原级联费，不重复增加；\(\gamma_{eff}=0\) 或 \((8/3)e^{-\sqrt n}<\varepsilon/16\) 仍由原highpast条件决定。
\[
C_{\varepsilon,n}=\frac\lambda{q_-}\left[\frac{2+3\sqrt n+2e^{-\sqrt n}}\varepsilon+1+\sqrt n\right],\quad
D_{top,n}=s+\log(4/3),\quad
C_{hit,n}=2(\lambda/q_-)s(1+\log(1/\varepsilon)).
\]
第353轮相较352新增c_eff Xq与sWex；本轮354不增加任何新费或收据，完整沿用此账。入口2和外乘Lambda作用于全部新旧项。接收系数为
\[
13/36+2\Lambda(\beta+\gamma_{eff}+\alpha_{rec}+c_{eff}).
\]
只有历史CZ的1/256属于同一认证X账时，合计才是
\[
853/2304+2\Lambda(\gamma_{eff}+\alpha_{rec}+c_{eff})<889/2304.
\]
未分配吸收余额大于1415/2304，不是任何未付积分的估计。新增来源费外乘后为2Lambda sWex。

剩余F_edgefresh：原初始见证满足 \(r<\sigma R_{w_0}\) 且 \(y\notin\sigma Q_{w_0}\)，故 \(y\notin Q_r(w_0)\)。新路径没有首次祖先回捕。两种条件分别绑定原初始标记和真实后续历史；不把原r与后来终点配对。其来源加权跨路径终端占用仍只有线性粗界，没有一般根阶预算。

独立未付槽全部保留：一般软层C_H-S_H、越阈I_H、hard合同外质量可比重尾；宽距离、低pe、极端尺度比及全部阈值补集；初始I_time、删除跳跃J_time、未来被删来源D_time；H选择、分层、来源、物理尺度、外积分、截断及极限费用。原ell末端原子和辅助秩核终止不替代历史时间原子。负重叠信用只允许使用一次。

第354轮没有新的全局付款，也未证明B_H全体或一般一致弱型上界，也未证明只剩常数与对数打磨。

本轮有限格点菜单的高过去排空只适用于已明确的诊断模型，绝不能据此删除一般高过去槽。有限L1截断桥只认证这些计算模型，不认证一般弱型上界。
