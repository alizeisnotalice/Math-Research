# 中心立方体第77轮：覆盖反例、零质量核心与全层高背景支付

2026-10-11。**主目标 C_n^square≤sqrt(n)n^{o(1)} 仍未证明；全一般保留基准仍为 O(n log n)。** 本轮严格否定若干过强覆盖前提，保留已证支付/舍入工具，并证明任意输入的零质量近核修正和所有层高背景事件的一次 O(sqrt(n)) 支付。剩余低背景动态事件尚未解决。

## 结果与依赖变化

1. **真实硬赢家子事件上的全部源包障碍，已证。** 均匀顶点源的 k 坐标揭示可由正勒贝格体积的实际全尺度赢家实现。自包含二点超收缩、张量化及 Fourier 计算给 k≈sqrt(n)、t=1/sqrt(n) 时随机代表覆盖≤2^{−(1/3+o(1))sqrt(n)}。优化固定、仿射乃至任意共同尺度曲线仍≤2^{−(1/4+o(1))sqrt(n)}。在此事件逐包所有共同曲线恰等优化源顶点代表。事件弱费用极小，不能据此声称完整带或主弱型反例。
2. **真实完整软层分支的随机代表反例，已证。** 通过已核验的 sharp Young 不等式，对所有共同 joint-noise packets 统一上界。实际 E2、δ=1/2、单尺度、均匀大盒的完整低背景分支，使 Bavg/T 在 t=1/sqrt(n) 时至多 exp[−(sqrt(n)/4)log n+O(sqrt(n))]。O(log n) 噪声截断后仍成立，且与本轮新正对合并证明完整零质量补偿核心分支仍有相同障碍。这是实际完整分支的反例，排除无例外 random-representative 覆盖假设；不排除优化代表 LP。该完整事件可由单尺度强 L1 成本≤2W支付，所以并非主弱型反例。
3. **消去修正，已证且对任意输入成立。** 噪声截断质量缺陷 d=(1−δe_R/2)^n−(1−δe_R)^n≥0。令 D_R^0=D_R−dH，K_R^0=K_R+dH/2，J_R^0=J_R+2dH；新增潜变量分数−2使 Cauchy 与共同源结构保持，且∫D_R^0=0、∫K_R^0≤1。共同半径 R=3/2+2log[4n(1+nlog2)]+2a，使所有层总余项强 L1 支付≤2e^{−a}W。矩费用保持 K≤(1+δ/2)W、J≤10IW，未隐藏来源数或尺度数。
4. **全层高背景根号维数支付，已证且对任意输入成立。** 取 w_s=1/[(s+1)(s+2)]、层阈值λw_s、背景比 H_s=sqrt(n)/w_s²。正核有限窗口包络和并集 Markov 给全部层实际高背景事件之并的 λ体积≤[(1+nlog2)/sqrt(n)]W。余下事件满足 |T_s^0|>λw_s 与 F_s≤sqrt(n)λ/w_s，尚无足够覆盖或弱体积估计。H_s 随层增长，不能当作固定常数偷偷回代。

R76 的几何价格、正积分支付、LP与共同时钟舍入继续有效；需要删除的是在每个任意子事件或每个完整真实低分支上都要求无例外有限t覆盖的前提。研究目标不收缩为这些测试族；测试族只用于否定不可用的普遍命题。新修正与高背景结算直接覆盖任意输入的对应分支。

## 数值及复现范围

实际赢家与Boolean揭示程序完整枚举 n=2..4 的65,805非空包，经4,386个XOR轨道计算27个参数目标。随机代表与优化固定代表的上下端点由有理根夹逼、XOR可行容量和均匀对偶给出；非整数幂区间宽度至多2^−64。扩大维数包含1,056个显式候选案例、80个完整子立方体家族优化案例，均明确只是全局下界或家族最优；不能冒充所有源包上界。真正渐近上界来自解析证明。

补偿程序核验280个精确质量案例、17,850个mask实例、960个有符号密度接收行、36个隐式费用模型，以及12个全层高背景阈值模型/296层。潜变量有理代理只认证代数，不认证连续φ积分。软层守卫在n=16,256,4096上实际计算E2卷积及mask聚合，Simpson细化只是诊断；稀有尾下溢不承担理论结论。覆盖守卫与独审另行运行，实际结果、时间和哈希在inventory.json。

两个主程序已由父代理在独立目录重放，JSON逐字节一致；覆盖、软层、独审守卫实际通过。只有LaTeX静态检查，未编译或生成PDF。解压到临时目录并备份JSON后，执行 `python3 -B reveal_probe.py`、`python3 -B compensation_guard.py`。proof.md恰有三个Python块，顺序coverage_guard.py、soft_guard.py、audit_guard.py；用 `re.findall(r"```python\n(.*?)\n```",text,re.S)` 提取运行，独审守卫须与两程序及JSON在同目录。全部只依赖Python标准库。

## 技能与文献核验

重新检查64个canonical技能入口和437处直接引用；相较R76，B03广义矩入口有更新，已重新阅读：它明确区分无支撑限制条件尾上确界与附加支撑约束，不把强对偶/有限原子表示自动迁移。本轮没有调用该未验证迁移。实际使用A02/A04的正支配与共同源边界、D04有限共同概率分解、N04可求和误差、L03有理证书边界。入口可读不等于64项全部文献已读或定理验收。

超收缩有自包含证明，另核验Bonami原文及作者课程讲义的适用指数。sharp Young使用 [Barthe Theorem 1](https://arxiv.org/pdf/math/9704210)，应用中逐一核对指数关系、归一化、正函数Lp条件和维数常数。没有将来源仅有的二维、有限矩或条件结论当成一般输入假设。

覆盖/软层使用Astra medium；实现/独审使用6.1 Sol high。主代理整合及独立重放。GitHub白名单仍为轮次README、research.zip、项目总览三项；研究中间稿和缓存留在仓库外，旧依赖未擅删。

## 最小剩余任务

在已经支付零质量修正余项、全层高背景及可直接支付的短尺度覆盖事件后，对所有输入的剩余低背景动态事件建立充分弱体积估计，或有完整例外预算的优化代表覆盖。随后核对基准项及全尺度回代。无例外平均代表路线已被否定，应避免重复证明；主目标保持未完成。

以下为完整组件证明、数值笔记及独立审计。组件内“未操作Git”仅描述子代理职责，最终逐轮同步由主代理完成。

# R77: a genuine hard-winner obstruction to subsetwise packet coverage

Status: proved obstruction on a positive-Lebesgue-measure subevent of one actual amplitude band. This is not a counterexample to the desired weak bound or to coverage on the entire band. The general dimension-only upper theorem remains open. No Git or TeX compilation. A02 and L03 are used only for explicit domination directions and rational finite checks.

## 1. Actual geometry, flow, and weak fee

Let n>=4, 1<=k<n, epsilon=1/(100n), and mu uniform on {−1,1}^n. For every k-subset S and signs sigma on S, let U(S,sigma) have x_j=sigma_j s_j with 2+2epsilon<=s_j<=2+3epsilon for j in S, and |x_j|<=epsilon otherwise. These boxes are disjoint up to null boundaries. Write U for their union. The first complete distance batch consists exactly of vertices agreeing with sigma on S, of mass F=2^(−k), at radius r=max_{j in S}(s_j−1). Unselected-coordinate distances are <=1+epsilon; every mismatching vertex has distance >=3+2epsilon. Thus the first batch is the unique best batch whenever

    2^k ((1+3epsilon)/(3+2epsilon))^n < 1.                 (1)

Indeed every later cube has density <=[2(3+2epsilon)]^(−n), below the first density. Between complete batches density decreases. This proves the all-scale true winner claim, with no radius grid. In particular (1) holds for k=floor(sqrt(n)): the ratio is <1/2, and k<n.

Put M=2^(−k)(2r)^(−n), T=integral_U M dx. Every label (S,sigma) has exactly the same M-weighted flow, by coordinate/sign symmetry. Therefore the normalized flow induces uniform S and sigma. Conditional internal coordinates affect M but not captured vertices. Set lambda=2^(−k)[2(1+3epsilon)]^(−n)/2. Then U lies in {lambda<M<=3lambda}, since 2[(1+3epsilon)/(1+2epsilon)]^n<3.

The actual Lebesgue volume and direct weak fee obey

    |U|=binom(n,k) 2^n epsilon^n,
    lambda |U| <= T <= binom(n,k) 2^(−k) epsilon^n (1+2epsilon)^(−n).
                                                               (2)

In particular T<=2^n(100n)^(−n), superexponentially small. This formula pays this particular event directly. It does not provide a covering or summable exception rule for arbitrary input, and does not change the receiver measure.

## 2. Exact random-representative LP reduction

For a nonempty packet A of vertices let p=mu(A), f=1_A, and Z(S,sigma)=E[f(X)|X_S=sigma], for uniform X. Captured packet mass a=2^(−k)Z, and posterior a/F=Z. The R76 averaged random-representative score is

    b_avg(A)/T=2^(−k) E Z^(2+t)/p.                       (3)

The representative is sampled once from A and then used for all receivers. The factor a/p is its gate probability. No receiver-adaptive selection occurs.

Source capacity is sum_A alpha_A 1_A(v)<=1. Integration against mu gives sum alpha_A p_A<=1. XOR translates of any A all have the same score and each vertex occurs in exactly |A| of the 2^n translates. Assigning coefficient 1/|A| to every translate (duplicates may be combined) saturates each source. Hence exactly

    B_avg(U)/T=max_{A nonempty} 2^(−k) E Z^(2+t)/p^2.    (4)

This is a finite source statement; no nonatomic limit is invoked. Fractional packet densities 0<=f<=1 also satisfy the bounds below, because E f^(1+rho)<=E f=p. Thus such an extension cannot defeat the upper bound.

## 3. Self-contained hypercontractive ingredient

For 1<=h<=2 and real a,b,

    a^2+(h−1)b^2 <= ((|a+b|^h+|a−b|^h)/2)^(2/h).      (5)

Proof: normalize a=1 (a=0 immediate), set u=|b/a|. For 0<=u<1 all even generalized-binomial coefficients binom(h,2j), j>=1, are nonnegative. Thus the average is >=1+h(h−1)u^2/2; Bernoulli with exponent 2/h>=1 proves (5). At u=1 use continuity. For u>1 use homogeneity and the result at 1/u, obtaining u^2+h−1 >=1+(h−1)u^2. Endpoints h=1,2 follow directly or continuously.

Consequently the two-point noise operator with Fourier multiplier sqrt(h−1) contracts L_h to L_2. Tensorization is elementary: for operators A and B on separate probability coordinates that contract L_h to L_2, apply B for each fixed first coordinate, exchange the mixed norms using Minkowski (h<=2), then apply A for each fixed second coordinate. Explicitly

    ||ABf||_{L2(x)L2(y)}
      <=||Af||_{L2(x)Lh(y)}
      <=||Af||_{Lh(y)L2(x)} <=||f||_h.

Iterating proves ||T_sqrt(rho) f||_2<=||f||_(1+rho), 0<=rho<=1. This includes all signs of f and all finite dimensions. The operator is the product Markov noise operator, equivalently Fourier multiplier rho^(|D|/2). A primary author exposition was read: Ryan O'Donnell, Lecture 16 (2007), Theorem 1.1 and tensorization pp.3–5, https://www.cs.cmu.edu/~odonnell/boolean-analysis/lecture16.pdf . Its later pictorial two-point discussion is not needed for our proof (5).

Parseval after conditional expectation gives

    E Z^2=sum_D fhat(D)^2 P(D subset S)
         <=sum_D fhat(D)^2 (k/n)^|D|
         <=p^(2/(1+rho)), rho=k/n.                    (6)

Here P(D subset S)=(k)_d/(n)_d<=rho^d, or zero when d>k. These are exact finite identities and inequalities.

## 4. Uniform packet bound and exponential failure

Let d=2rho/(1+rho)=2k/(n+k). Since Z<=1, (6) and (4) bound each normalized column by 2^(−k)p^(−d). Also Z<=2^k p and E Z=p imply the other bound 2^(kt)p^t. Their intersection therefore gives, for 0<k<n and every t>0,

    B_avg(U)/T <= 2^[−k t(1−d)/(t+d)].                 (7)

The calculation is explicit: write p=2^(−v). The two logarithmic bounds are −k+dv and kt−tv; their minimum is maximized where v=k(1+t)/(t+d). Enlarging v beyond its actual interval [0,n] is a valid upper bound.

For n=m^2, k=m, t=1/m, d=2/(m+1), the exponent is

    k t(1−d)/(t+d)=m(m−1)/(3m+1),

so B_avg/T<=2^[−m(m−1)/(3m+1)]. This is smaller than every inverse polynomial in n. The assertion requested at k approximately sqrt(n), t=1/sqrt(n) also follows directly from (7), with exponent (1/3+o(1))sqrt(n). At t=0 the conclusion vanishes, consistently with full coverage at zero power.

## 5. Even optimized common representatives fail on U

Let c(L) be any deterministic measurable scale-only curve, including fixed or affine representatives. For each S and absolute internal coordinates the winner L is independent of sigma. For a selected coordinate the positive-sign winner interval has lower endpoint >=1−epsilon>0, and the negative-sign interval has upper endpoint <=−1+epsilon<0. Hence at most one sigma can satisfy c(L) in Q*(x), and E_flow gate<=2^(−k). The flow weighting is independent of sigma.

**Exact reduction of every common scale curve to a fixed source vertex.** Under the probability measure M dx/T on U, the pushforward law of L conditional on each label (S,sigma) is identical. Indeed, a coordinate permutation and sign reflection carry any one query box to any other, preserving Lebesgue measure, r, M, and L. Thus L is independent of the finite label (S,sigma), not merely independent of sigma conditional on S.

For any c in R^n define V(c)_j=+1 when c_j>=0 and −1 when c_j<0. If c lies in the winner cube, then every selected coordinate has sign sigma_j, because its winner interval lies strictly in the corresponding open half-line; a zero coordinate cannot pass a selected-coordinate gate. Consequently V(c) matches sigma on S. Every such matching vertex belongs to the winner cube: selected-coordinate distance is s_j−1<=r and unselected-coordinate distance is <=1+epsilon<r. Therefore, pointwise on U,

    1{c(L) in Q*(x)} <= 1{V(c(L))_S=sigma}.            (8a)

The convention V(0)=+1 is harmless: if that coordinate is selected, the left gate is zero, and if unselected, either vertex sign is allowed. For a Borel curve, V(c(L)) is measurable. Define the finite vertex objective

    H_A(v)=E_{S,sigma}[1{v_S=sigma} Z(S,sigma)^(1+t)].

Independence of L and the labels, together with Z depending only on labels, proves

    b_c(A)/T <= E_L H_A(V(c(L))) <= max_v H_A(v).

Conversely any fixed vertex v is itself a constant common Borel curve and its gate is exactly 1{v_S=sigma}. Thus the supremum over all common Borel scale curves is attained by a fixed source vertex, with the exact identity

    sup_c b_c(A)=max_{v in {−1,1}^n} b_v(A)=T max_v H_A(v). (8b)

The same identity holds for optimized fixed and unrestricted affine representatives, since those classes contain constant vertices and are contained in the common-curve class. It holds packet by packet, hence also for the associated common-source capacity LP and partition optimum on this U. In particular a full finite LP using all source packets and all fixed vertices computes the entire common-curve optimum exactly for this event. Merely sampling packets or vertices is still only a restricted numerical problem. Normalization by an affine ray price C(b)>=1 preserves equality when constant curves b=0 have price one. No statement here permits a private receiver-dependent representative.

For q=1+t, define b_c(A)=integral_U M gate Z^q. Cauchy and (6) show

    b_c(A)/(Tp)<=2^(−k/2)p^[−rho/(1+rho)].

The separate bound Z<=2^k p and gate probability<=2^(−k) gives

    b_c(A)/(Tp)<=2^(kt)p^t.

They are uniform over c, hence remain true after optimizing c. For a=rho/(1+rho), source capacity gives

    B_curve(U)/T<=2^[−k t(1/2−a)/(t+a)].               (8)

For n=m^2,k=m,t=1/m, the exponent is m(m−1)/(2(2m+1)), asymptotic m/4. Paid affine columns normalized by ray price C(b)>=1 are also bounded this way. This says nothing about receiver-dependent c(x), which would invalidate the sign-count argument and the common representative requirement.

## 6. Consequences, repairs, and remaining debt

Equations (7),(8) disprove a dimension-subpolynomial coverage lower bound required on every arbitrary measurable subevent of a genuine hard-winner band. Even allowing arbitrary shared scale trajectories does not repair that strong statement. They do not disprove the same lower bound restricted to complete bands, since U occupies a tiny fraction of potential band mass. Nor do they imply a large weak constant: (2) shows the opposite for this event.

A logically valid future interface may discard a set E_bad with a direct bound lambda|E_bad|<=A_n W and require coverage only on E_good, or use a single joint bound lambda|E_bad|+Ct W/kappa on the actual partition. It must prove an all-input rule producing those sets; choosing U only for this example is not such a rule. No such rule is proved here. The general finite-t coverage or a sufficient globally paid alternative, the soft-layer return, and full-scale localization remain open.

## 7. Reproducible guard

The following standard-library guard checks three stages: exact complete-batch winners, exhaustive/sampled Boolean packets with exact Fourier identities, and dimension growth using rational exponents. Irrational moment evaluations are floating diagnostics, explicitly not interval certificates. The proofs above supply the universal assertions.

```python
from fractions import Fraction as F
from itertools import combinations, product
from math import comb, sqrt
import random
rng=random.Random(77019)
checks=0
# Stage 1: exact all-distance-batch winner, increasing dimension/source count.
for n in (2,3,4,6,8,10):
 k=int(sqrt(n)); e=F(1,100*n)
 assert 2**k*((1+3*e)/(3+2*e))**n<1
 vertices=list(product((-1,1),repeat=n))
 for trial in range(5):
  S=set(rng.sample(range(n),k)); signs={j:rng.choice((-1,1)) for j in S}
  x=[signs[j]*(2+2*e+e*F(rng.randrange(11),10)) if j in S else e*F(rng.randrange(-10,11),10) for j in range(n)]
  batches={}
  for y in vertices:
   r=max(abs(x[j]-y[j]) for j in range(n)); batches[r]=batches.get(r,0)+1
  total=0; best=None
  for r,num in sorted(batches.items()):
   total+=num; density=F(total,2**n)/(2*r)**n
   if best is None or density>best[0]:best=(density,r,total)
  assert best[1]==max(abs(x[j])-1 for j in S)
  assert best[2]==2**(n-k)
  for y in vertices:
   assert (max(abs(x[j]-y[j]) for j in range(n))<=best[1])==all(y[j]==signs[j] for j in S)
  checks+=1
print('stage1 exact_winners=30 dimensions=2,3,4,6,8,10 sources=4..1024')
# Stage 2: all packets through n=3; random/nonrandom at n=4,6,8.
packets=0
for n,k in ((2,1),(3,1),(3,2),(4,2),(6,2),(8,3)):
 N=2**n; subsets=list(combinations(range(n),k)); rho=F(k,n)
 masks=list(range(1,2**N)) if n<=3 else [1,2**N-1]+[rng.getrandbits(N) or 1 for _ in range(15)]
 for mask in masks:
  f=[(mask>>v)&1 for v in range(N)]; p0=F(sum(f),N)
  Z=[]
  for S in subsets:
   counts=[0]*2**k
   for v in range(N):counts[sum(((v>>j)&1)<<l for l,j in enumerate(S))]+=f[v]
   Z.extend(F(c,2**(n-k)) for c in counts)
  ez2=sum(z*z for z in Z)/len(Z)
  rhs=F(0); noisy=F(0)
  for D in range(N):
   fh=F(sum(f[v]*(-1 if (v&D).bit_count()%2 else 1) for v in range(N)),N)
   d=D.bit_count(); inclusion=F(comb(n-d,k-d),comb(n,k)) if d<=k else F(0)
   assert inclusion<=rho**d
   rhs+=fh*fh*inclusion; noisy+=fh*fh*rho**d
  assert ez2==rhs and rhs<=noisy
  assert float(noisy)<=float(p0)**(2/(1+float(rho)))+1e-12
  t=1/sqrt(n); moment=sum(float(z)**(2+t) for z in Z)/len(Z)
  ratio=2**(-k)*moment/float(p0)**2
  d=2*float(rho)/(1+float(rho))
  bound=2**(-k*t*(1-d)/(t+d))
  assert ratio<=bound+1e-12
  assert all(z<=min(1,2**k*p0) for z in Z)
  # Common fixed corners: gate selects one sign for each S.
  for corner in (0,N-1,rng.randrange(N)):
   score=0.0
   for si,S in enumerate(subsets):
    sign=sum(((corner>>j)&1)<<l for l,j in enumerate(S))
    score+=float(Z[si*2**k+sign])**(1+t)
   ratiofixed=score/(len(subsets)*2**k*float(p0))
   a=float(rho)/(1+float(rho))
   assert ratiofixed<=2**(-k*t*(.5-a)/(t+a))+1e-12
  # XOR orbit has exact constant source capacity.
  if n<=3:
   for v in range(N):assert sum(f[v^g] for g in range(N))==sum(f)
  packets+=1; checks+=1
print('stage2 packets=%d exact_Fourier_and_XOR; floating_moment_diagnostics'%packets)
# Stage 3: rational exponent checks; no giant vertex enumeration.
for m in (2,4,8,16,32,64,128):
 n=m*m; k=m; t=F(1,m); d=F(2*k,n+k); a=d/2
 ga=k*t*(1-d)/(t+d); gc=k*t*(F(1,2)-a)/(t+a)
 assert ga==F(m*(m-1),3*m+1)
 assert gc==F(m*(m-1),2*(2*m+1))
 assert ga>=F(m-1,4) and gc>=F(m-1,6)
 e=F(1,100*n)
 assert (1+3*e)/(3+2*e)<F(1,2)
 print('growth n=%d avg_log2_upper=%.6f curve_log2_upper=%.6f'%(n,-float(ga),-float(gc)))
 checks+=1
print('PASS checks=%d; no universal claim inferred from numerics'%checks)
```

Guard stdout:

```text
stage1 exact_winners=30 dimensions=2,3,4,6,8,10 sources=4..1024
stage2 packets=576 exact_Fourier_and_XOR; floating_moment_diagnostics
growth n=4 avg_log2_upper=-0.285714 curve_log2_upper=-0.200000
growth n=16 avg_log2_upper=-0.923077 curve_log2_upper=-0.666667
growth n=64 avg_log2_upper=-2.240000 curve_log2_upper=-1.647059
growth n=256 avg_log2_upper=-4.897959 curve_log2_upper=-3.636364
growth n=1024 avg_log2_upper=-10.226804 curve_log2_upper=-7.630769
growth n=4096 avg_log2_upper=-20.891192 curve_log2_upper=-15.627907
growth n=16384 avg_log2_upper=-42.223377 curve_log2_upper=-31.626459
PASS checks=613; no universal claim inferred from numerics
```


# Round 77: the averaged-representative coverage interface fails on a genuine easy branch

**Status.** This round proves an all-packet upper bound for the R76 averaged-representative LP and applies it to a genuine, untruncated E2 soft-layer full low-background branch. At t=1/sqrt(n), its coverage fraction is smaller than every negative power of n. The same obstruction survives the prescribed O(log n) noise truncation. The entire example has a dimension-free single-scale strong L1 payment: this is an obstruction to demanding coverage on every branch, not an obstruction to the desired weak bound. A general paid-exception decomposition is recorded, with its residual clearly unpaid. The main centered-cube upper bound is NOT proved.

Only this round's soft.md and soft.tex.txt are written. No Git operation, old-file modification or TeX compilation is performed. A02 and D04 were read for the payment direction and the single-joint-law information identity. The only external theorem used is the precise sharp Young inequality specified below; all of its hypotheses are checked in the application.

## 1. The actual joint source and an information identity

Retain R76 notation: h=1_{[-1/2,1/2]}, H=h^tensor n, w(z)=integral_0^1 exp(-|z|/v)dv, phi=h*w. For endpoint probabilities alpha_m=Bernoulli(delta/2)^n(m), beta_m=Bernoulli(delta)^n(m), put q_m=(alpha_m+beta_m)/2 and j_m=2(alpha_m-beta_m)^2/(alpha_m+beta_m), omitting zero denominators. The noise measures are rho_K=sum q_m rho_m and rho_J=sum j_m rho_m, where hard coordinates have delta_0 and soft coordinates have the actual w density. Their masses are 1 and I, respectively; I<=min(4,2n delta).

For either positive noise measure rho of mass m, set eta(dy,dz)=mu(dy)rho(dz), M=m W. At a selected scale L(x), A_x={(y,z):y+L(x)z in Q(x,L(x))}, Fcap=eta(A_x), G=Fcap/L^n. A fixed measurable packet P has w_P=eta(P), a_P=eta(P intersect A_x), pi_P=a_P/Fcap and f_P=a_P/w_P. Its averaged-representative score is

    b_t(P;E)=integral_E G pi_P^(1+t) f_P dx
            =integral_E a_P^(2+t)/(L^n Fcap^t w_P) dx.

Zero packets contribute zero. B_t^avg(E) is the supremum of sum alpha_P b_t(P;E) over finite families with sum alpha_P 1_P<=1 eta-almost everywhere. R76 proved payment and O_t^avg<=B_t^avg<=(1+t)O_t^avg, but no positive finite-t coverage fraction.

For any common finite partition, fix a receiver with Fcap>0, write c=Fcap/M and p_P=w_P/M. Then pi_P=p_P f_P/c, and exactly

    sum_P pi_P^(1+t)f_P = c sum_P pi_P^(2+t)/p_P
         =E_{P distributed as pi}[exp(-t S_P-Z_P)],
    S_P=-log pi_P,  Z_P=-log f_P,
    E_pi Z=log(1/c)-D(pi||p).                           (1)

All positive-posterior terms have p_P,f_P>0. The last identity follows just by substituting pi/p=f/c. Equivalently it is the KL chain rule for the actual posterior eta(.|A_x), prior eta/M, and the common partition. No differential entropy of the noise is invoked. With X distributed by G dx/T_E and then P by pi(X), the normalized partition score is E exp(-tS-Z). This explains the tradeoff: refining can reduce the failure-to-capture term Z while increasing S. It does not establish a bound for the tradeoff. The counterexample below shows that even true low-background events can force this score to be very small.

## 2. A sharp Young upper bound for every joint packet

Here L=1 is fixed. Suppose the pushforward of eta under (y,z)->y+z has Lebesgue density u with 0<=u<=U, and total mass M. The pushforward of eta restricted to any packet P has a density g_P satisfying 0<=g_P<=u<=U and integral g_P=w_P. Importantly, this remains true for arbitrary measurable packet membership involving BOTH y and z. Capture is exactly a_P=g_P*H; no noise profile is replaced by an averaged label.

For t>0 put q=2+t, p=q/2, r=q/(q-1), and C_s=s^(1/(2s))/(s')^(1/(2s')), where s'=s/(s-1). The sharp Young theorem gives

    ||g*H||_q <=(C_p C_r/C_q)^n ||g||_p ||H||_r,
    1/p+1/r=1+1/q.

Source: Franck Barthe, *Optimal Young's inequality and its converse: a simple proof*, Theorem 1, pp. 1--2, https://arxiv.org/pdf/math/9704210 . The statement and normalization were read directly. Here all three exponents exceed one, g_P belongs to L^p because it is bounded and integrable, and H belongs to L^r with norm one. Since C_r=1/C_q and integral g_P^p<=U^(p-1)w_P, the consequence is

    integral a_P^(2+t) <=A(t)^n U^t w_P^2,
    A(t)=(C_((2+t)/2)/C_(2+t)^2)^(2+t).                 (2)

Thus, on any genuine receiver set E with G>a>0,

    b_t(P;E)<=A(t)^n (U/a)^t w_P,
    B_t^avg(E)<=A(t)^n (U/a)^t M.                       (3)

The second inequality uses precisely the common source capacity: sum alpha_P w_P<=M. This is an upper bound for ALL packets and ALL common finite capacity families, not for a restricted numerical list. Countable families follow by monotone convergence. Arbitrary atom splitting in the joint source cannot evade (3).

A useful exact expression and bound are

    log A(t)=(1+t)log((2+t)/(1+t))-log 2
                         +(t/2)log(t/(2+t)),
    log A(t)<=(t/2)log t-c0 t,   c0=(1-log 2)/2>0.      (4)

For proof, subtract (t/2)log t from the first line and call the result g(t). Then g(0)=0 and g'(t)=log(sqrt(2+t)/(1+t))-1/2<=log(sqrt 2)-1/2=-c0. In particular, at t=1/sqrt(n),

    A(t)^n<=exp[-(sqrt(n)/4)log n-c0 sqrt(n)].           (5)

This estimate is derived from a published sharp theorem, not claimed as an elementary new proof of that theorem.

## 3. A genuine untruncated E2 full low-background branch

Fix delta=1/2, one actual physical scale L=1, and

    R=1/2+log(100n),  D=4nR,
    mu=1_{[-D/2,D/2]^n}dy,   W=D^n,
    tau=exp(-4)/40,  lambda=tau/2,  B=1/lambda.

This is a finite nonnegative L1 input. The single-scale selector is the exact selector for the one-element physical family; no grid approximation to a continuous maximum is asserted. Put

    F=mu*K, C=mu*J, T=mu*Dcontrast,
    E={x: |T(x)|>lambda, F(x)<=B lambda}.

Since K is a probability kernel and 0<=mu density<=1, F<=1=B lambda globally. Thus E is the FULL actual contrast level set {|T|>lambda}, and also the full actual low-background branch for this fixed absolute B. Everywhere on E, restricted Cauchy gives C>lambda^2; also C<=4F<=4. Hence the original genuine low-branch J band is valid on the whole E, not merely on a chosen subset.

Consider the following 2n disjoint face strips S_{j,+},S_{j,-}. In coordinate j, x lies inside the source box at distance between 1 and 2 from the designated face. In every other coordinate its distance from both faces is at least R. R>2, so these strips are disjoint. Their union S has

    |S|=2n(D-2R)^(n-1)>=W/(4R).                       (6)

Indeed the ratio is (2R)^(-1)(1-1/(2n))^(n-1), and Bernoulli's inequality bounds the final factor below by 1/2.

For x in S, the hard one-dimensional convolution with the source interval is one in every coordinate. Let 1-epsilon_j be the corresponding phi-convolution. In the designated face coordinate,

    epsilon_j>=P(U+Z>2)>=P(U>=0)P(Z>2)
       >=(1/2) integral_(1/2)^1 v exp(-2/v)dv
       >=exp(-4)/8,                                  (7)

where U is uniform on [-1/2,1/2] and Z has density w. In other coordinates,

    epsilon_k<=P(|U+Z|>=R)<=P(|Z|>=R-1/2)
              <=exp(1/2-R)=1/(100n).                 (8)

Both endpoint convolutions factor for this actual product-box source, so

    T=product_k(1-epsilon_k/4)-product_k(1-epsilon_k/2)
      >=(epsilon_j/4) product_(k!=j)(1-epsilon_k/2)
      >=(199/200)exp(-4)/32 > tau.                    (9)

Also F>=product_k(1-epsilon_k/2)>=199/400>0.49. Consequently S is contained in the FULL E, and C>=T^2/F>=tau^2 on S. The full branch occupation satisfies

    T_E:=integral_E C >=tau^2 W/(4R).                 (10)

For eta_J=mu(dy)rho_J(dz), the pushforward density u=mu*rho_J is at most I, and M=IW. Apply (3) to the WHOLE E with U=I,a=lambda^2:

    B_t^avg(E)<=A(t)^n (I/lambda^2)^t I W,
    B_t^avg(E)/T_E
       <=(16R/tau^2)(4/lambda^2)^t A(t)^n.             (11)

At t=1/sqrt(n), (4) shows that this ratio tends to zero faster than every n^(-c), c>0. Therefore a uniform lower bound n^(-o(1)) for the R76 averaged-representative coverage on all actual low branches is FALSE. The counterexample uses the true E2 kernel, the true dx measure and continuous joint noise. It does not rely on a large raw-source entropy or on changing the source profile. It also does not refute the unrestricted optimally chosen affine representative LP, whose score can exceed its random-representative average. In fact, for every fixed c>0, t=c/n gives an upper bound O_c(log n)n^(-c/2), so even that parameter choice cannot yield a uniform n^(-o(1)) coverage statement without exceptions.

## 4. Stability under the actual noise cutoff

The previous counterexample is already untruncated. It also persists in the actual truncated core needed in R76, so it cannot be dismissed as a missing deep-noise tag. Let rho_K,R0, rho_J,R0 and rho_D,R0 be the same noise measures restricted to ||z||infinity<=R0, without renormalization. For delta=1/2,

    ||Dcontrast-Dcontrast,R0||_1
       <=2 rho_K(||z||infinity>R0)
       <=n exp(1/2-R0)=:epsilon.                      (12)

Because the source density is bounded by one, |T-T_R0|<=epsilon pointwise. Choose

    R0=1/2+log(8n/tau), so epsilon<=tau/8.

Then T_R0>=7tau/8>lambda on S. The positive truncated K kernel has mass at most one, so F_R0<=1, and latent restricted Cauchy gives C_R0>lambda^2 on the FULL truncated event

    E_R0={|T_R0|>lambda,F_R0<=1}.

Moreover its occupation is at least (7tau/8)^2 W/(4R). The joint truncated J pushforward still has density bounded by its mass I_R0<=4 and total mass I_R0 W. Applying (3) gives the same superpolynomial failure as (11), with only its fixed prefactor multiplied by 64/49. Thus the actual bounded-noise near-core version fails too.

For comparison with a zero-mass correction, let d0=integral Dcontrast,R0; then |d0|<=epsilon. Subtracting d0 H changes T_R0 by at most epsilon pointwise for this bounded source. The positive contrast on S remains at least 3tau/4. This is a stability statement for the positive face event; a new compensated Cauchy pair must be specified before claiming a full compensated J-band theorem. The counterexample above does not depend on such a choice.

## 5. The entire counterexample is paid: a necessary exception branch

Let V_delta=sum_m |alpha_m-beta_m| k_m, a positive ray-decreasing kernel dominating |Dcontrast|, and v_delta=integral V_delta. Coupling each Bernoulli(delta/2) bit with the Bernoulli(delta) bit by the same uniform variable yields

    v_delta=sum_m |alpha_m-beta_m|
       <=2[1-(1-delta/2)^n]<=min(2,n delta).            (13)

For every signed input nu and every one fixed scale,

    integral |T_L nu|<=v_delta ||nu||_1,
    lambda |{|T_L nu|>lambda}|<=v_delta ||nu||_1.       (14)

Thus the ENTIRE event in Section 3 is paid at cost at most 2W, uniformly in dimension, although its averaged-representative coverage is superpolynomially small. A no-exception coverage premise is therefore unnecessarily strong even for a simple full actual branch. Neither this counterexample nor its large LP loss gives a large weak-type constant.

Here is an explicit all-input exception rule on any finite physical family in [1,2]. Choose a deterministic collection of m scale intervals [a_j,b_j], and let E_easy be any portion of the actual contrast crossing event whose selected scale belongs to their union. The finite-window positive-kernel envelope applied to V_delta gives

    lambda |E_easy|
       <=v_delta W sum_(j=1)^m [1+n log(b_j/a_j)].      (15)

One may choose the intervals using the input and its actual selector, provided one collection is then fixed and covers the claimed exception; no private choice for each source contribution is permitted. The cost is the displayed total. A singleton scale has a_j=b_j and costs one. This handles the complete example, and more generally any chosen portion of receivers whose selected scales can be covered at total cost O(sqrt(n) n^o(1)). The complementary event remains to be covered or paid; partitioning the whole window into many short intervals merely recovers O(n), not the target.

For completeness, the envelope behind (15) is elementary. For ordered scales a<=L_1<...<L_N<=b and a positive ray-decreasing kernel k of mass v, the pointwise supremum is bounded by k_(L_N)+sum_(i<N)[1-(L_i/L_(i+1))^n]k_(L_i). Its integral is at most [1+n log(b/a)]v. Apply to |nu|*V_delta and then Tonelli; omitted endpoints or one-point intervals cause no problem. This is positive integral payment, not averaging weak norms.

There is a second universal exception, useful for avoiding the separate high-background overcharge. For H0>0 and the actual positive background F_L,

    E_high={|T_selected|>lambda,F_selected>H0 lambda},
    lambda |E_high|<=(1+n log 2)W/H0.                 (16)

For the truncated background its mass is at most one, so the same bound holds. Choosing H0=sqrt(n) gives an O(sqrt(n)) paid high-background exception for EVERY input. No coverage is needed there. Unlike the low-branch counterexample in Section 3, the artificial flat-core event produced only by nonzero truncated contrast mass is typically included in this easily paid very-high-background regime.

Equations (15) and (16) are valid before imposing any residual coverage hypothesis. Their union is paid by the sum of the displayed fees. What remains is the crossing event with F_selected<=H0 lambda and selected scales outside the chosen easy intervals. This round does not prove averaged-representative coverage, an alternative packet coverage or a sufficient volume estimate on that residual. Even a rule based solely on large occupation compared with IW cannot be inferred from R76; an event's occupation must be weighed against its actual available payment.

## 6. What changes for the next interface

R76's random-representative LP, its capacity payment, its finite Boolean LP, its clock rounding and its t=0 full-coverage supremum remain correct. The additional conjecture that its finite-t coverage is n^(-o(1)) on every true low branch is now disproved. The failure applies even to the exact bounded-noise source and survives a small zero-mass correction at the face witnesses.

A sufficient next interface must permit the all-input fees (15)--(16), or another independently proved exception payment, before demanding finite-t coverage. Alternatively it must use a stronger score, such as optimized representatives, for which the sharp Young upper bound in Section 2 is not the applicable functional. It is not valid to silently replace the random-representative score by that stronger score while retaining a proof only for its expectation.

The present work supplies a concrete obstruction and an unconditional way to pay it. It does not show that every remaining input admits a scale cover with small total cost, and it does not establish the desired general n^(1/2+o(1)) weak estimate. All constants and the source mass W are retained above.

## 7. Executed three-stage guard

The embedded standard-library guard uses the genuine E2 tail formula, valid for d>1/2,

    P(U+Z>d)=integral_0^1 v^2[exp(-(d-1/2)/v)
                                      -exp(-(d+1/2)/v)]dv.

It checks actual endpoint contrast, F, C and I at a face witness for n=16,256,4096, changing the dimension and source box size while preserving the exact one-scale physical selector. The C calculation sums the actual mask coefficients with binomial aggregation; it does not replace the E2 kernel by a Gaussian or another model. Simpson 256/512 refinement is only a numerical diagnostic, not interval certification. Tiny remote-face tails may underflow in floating-point arithmetic; the analytic bounds (7)--(9) establish the theorem independently. Exact rational Bernoulli volume checks and the Young-exponent algebra are kept separate. The reported coverage numbers are upper bounds from the proved all-packet theorem, not estimates from a finite packet search.

The first stage is deliberately too small for the coarse universal upper bound to be less than one; the next two stages show the eventual obstruction. No asymptotic claim is inferred from fitting these values.

Guard SHA-256: `3d5b20dfa75089e154e803e20eea05ea879f33aec57a1fc48866dd3b3ba7bf45`.

Executed stdout:

```text
true_E2 n=16 T=0.0152599125 F=0.977110131 C=2.28926171 I=2.34387212 face_volume/W=0.0394223992 log_coverage_upper=20.3547947 refinement=7.75e-13 high_exception_fee=3.02258872
true_E2 n=256 T=0.0152599125 F=0.977110131 C=3.90828932 I=3.99984531 face_volume/W=0.0285164662 log_coverage_upper=-3.35141578 refinement=1.3e-12 high_exception_fee=11.1528549
true_E2 n=4096 T=0.0152599125 F=0.977110131 C=3.90844052 I=4 face_volume/W=0.0225951379 log_coverage_upper=-122.245377 refinement=1.3e-12 high_exception_fee=44.3770446
noise_stability n=16 Rnoise=13.0409097 contrast_error_bound=5.72363715e-05
noise_stability n=256 Rnoise=15.8134984 contrast_error_bound=5.72363715e-05
noise_stability n=4096 Rnoise=18.5860872 contrast_error_bound=5.72363715e-05
PASS assertions=137; true-E2 quadrature is diagnostic, exact rational/analytic inequalities are separate
```

Replay the following single Python fence with Python 3.

```python
from math import exp,log,log1p,lgamma,sqrt
from fractions import Fraction as Q
checks=0
def ck(x):
 global checks
 assert x
 checks+=1
def logA(t):
 return (1+t)*log((2+t)/(1+t))-log(2)+(t/2)*log(t/(2+t))
c0=(1-log(2))/2
tau=exp(-4)/40;lam=tau/2
for n in (1,2,4,16,64,256,1024,4096):
 R=.5+log(100*n);D=4*n*R
 ck((1-Q(1,2*n))**(n-1)>=Q(1,2))
 for t in (.01,.05,.1,.5,1.):
  ck(logA(t)<=.5*t*log(t)-c0*t+1e-14)
  q=2+t;p=q/2;r=q/(q-1)
  ck(abs(1/p+1/r-1-1/q)<1e-14)
# Exact simplex/conditional information identity, with nontrivial prior.
pri=(Q(1,5),Q(3,10),Q(1,2));frac=(Q(1,7),Q(2,3),Q(4,5))
c=sum(p*f for p,f in zip(pri,frac));post=tuple(p*f/c for p,f in zip(pri,frac))
for t in (0.,.2,1.):
 score=sum(float(p)**(1+t)*float(f) for p,f in zip(post,frac))
 alternate=float(c)*sum(float(p)**(2+t)/float(w) for p,w in zip(post,pri))
 ck(abs(score-alternate)<1e-14)
H=-sum(float(p)*log(float(p)) for p in post)
KL=sum(float(p)*log(float(p/w)) for p,w in zip(post,pri))
Z=-sum(float(p)*log(float(f)) for p,f in zip(post,frac))
ck(abs(Z+KL+log(float(c)))<1e-14)
# Genuine phi tail for d>.5: U uniform[-.5,.5], Z density w.
def phitail(d,steps):
 def fn(t):
  if t==0:return 0.
  return t*t*(exp(-(d-.5)/t)-exp(-(d+.5)/t))
 return (fn(0)+fn(1)+sum((4 if k%2 else 2)*fn(k/steps) for k in range(1,steps)))/(3*steps)
def binomprob(n,k,p):
 return exp(lgamma(n+1)-lgamma(k+1)-lgamma(n-k+1)+k*log(p)+(n-k)*log1p(-p))
def stage(n,steps):
 R=.5+log(100*n);D=4*n*R
 eb=phitail(1.5,steps)+phitail(D-1.5,steps)
 eo=2*phitail(D/2,steps)
 A=(1-eb/4)*exp((n-1)*log1p(-eo/4))
 B=(1-eb/2)*exp((n-1)*log1p(-eo/2))
 contrast=A-B; F=(A+B)/2
 I=0.;C=0.
 for k in range(n+1):
  a=binomprob(n,k,.25);b=binomprob(n,k,.5)
  if a+b==0:continue
  j=2*(a-b)**2/(a+b);I+=j
  v=(n-k)/n*exp(k*log1p(-eo))
  if k:v+=k/n*(1-eb)*exp((k-1)*log1p(-eo))
  C+=j*v
 ck(contrast>tau>lam)
 ck(F<=1 and F>.49)
 ck(C>=contrast*contrast/F-1e-12)
 ck(C<=4*F+1e-10 and I<=4+1e-9)
 ck(eb>=exp(-4)/8)
 volume_ratio=1/(2*R)*exp((n-1)*log1p(-1/(2*n)))
 ck(volume_ratio>=1/(4*R))
 t=1/sqrt(n)
 logbound=log(4*R*I/tau**2)+t*log(I/lam**2)+n*logA(t)
 # Whole-window high-background exception and compact scale-family costs.
 Hcut=sqrt(n); hi_fee=(1+n*log(2))/Hcut
 return contrast,F,C,I,volume_ratio,logbound,hi_fee
for n in (16,256,4096):
 coarse=stage(n,256);fine=stage(n,512)
 error=max(abs(a-b) for a,b in zip(coarse[:4],fine[:4]))
 ck(error<1e-7)
 print('true_E2 n=%d T=%.9g F=%.9g C=%.9g I=%.9g face_volume/W=%.9g log_coverage_upper=%.9g refinement=%.3g high_exception_fee=%.9g'%((n,)+fine[:6]+(error,fine[6])))
# Analytic truncation stability: these are deterministic bound calculations.
for n in (16,256,4096):
 Rnoise=.5+log(8*n/tau)
 eps=n*exp(.5-Rnoise)
 ck(eps<=tau/8*(1+1e-12))
 ck(tau-eps>lam)
 print('noise_stability n=%d Rnoise=%.9g contrast_error_bound=%.9g'%(n,Rnoise,eps))
print('PASS assertions=%d; true-E2 quadrature is diagnostic, exact rational/analytic inequalities are separate'%checks)
```


# R77：保留零质量消去的统一近核修正

状态：以下是对任意有限符号/复测度 ν 的一般核分解与强 L1 余项支付，常数独立于原子数、有限尺度族和层数。没有证明剩余近核的根号 n 弱型上界。该修正不声称修复本轮真实边界条带覆盖反例。

## 1. 为什么要补偿，以及准确核定义

使用原 E2 一维噪声 w(z)=∫_0^1 exp(−|z|/s)ds、h=1_{[-1/2,1/2]}、H=h^⊗n、φ=h*w。对 δ=2^−s，α_m、β_m 分别为 Bernoulli(δ/2)^n、Bernoulli(δ)^n 在mask m上的概率。令 q_m=(α_m+β_m)/2，ζ_m=(α_m−β_m)/q_m，j_m=q_m ζ_m²，零 q 项省略。ρ_m 的硬坐标是 δ_0，软坐标是 w(z)dz。

原核 D=Σ(α_m−β_m)H*ρ_m、K=Σq_m H*ρ_m、J=Σj_m H*ρ_m 满足 ∫D=0、∫K=1、∫J=I，|ζ_m|≤2。将所有mask的噪声共同限制到 ||z||∞≤R，得到未重新归一化的 ρ_{m,R} 和 D_R,K_R,J_R。共同限制保持潜变量 Cauchy，但通常 ∫D_R≠0，不能继续声称核心保留原消去。

记 e_R=∫_{|z|>R}w(z)dz。Tonelli 给 e_R=2∫_0^1 s exp(−R/s)ds≤exp(−R)，且 ∫ρ_{m,R}=(1−e_R)^|m|。因此核心的质量缺陷是准确的

    d_δ(R)=∫D_R=(1−δe_R/2)^n−(1−δe_R)^n,
    0≤d_δ(R)≤nδe_R/2≤(nδ/2)exp(−R).                 (C77.1)

中间上界由 u↦(1−u)^n 的导数绝对值≤n 得到，不以浮点差分判断符号。

定义补偿核心及其正对：

    D_R^0=D_R−d_δ H,
    K_R^0=K_R+(d_δ/2)H,
    J_R^0=J_R+2d_δ H.                                (C77.2)

这是在原共同潜变量空间上添加一个质量 d_δ/2、符号分数 ζ=−2、噪声 z=0 的独立标签，位置源仍是同一个 y。无需把负核错误地当成正包。显然 ∫D_R^0=0，J_R^0≤4K_R^0；K_R^0,J_R^0 非负，且原数据处理、共同源容量与随机代表结构仍可逐个正核使用。

## 2. 任意输入的 Cauchy 与噪声矩预算

令 μ=|ν|、W=μ(R^n)。对任意实际共同选尺 L(x)>0，令 T_R^0=ν*(D_R^0)_L，F_R^0=μ*(K_R^0)_L，C_R^0=μ*(J_R^0)_L。将 ν 相对 μ 的复相位并入潜变量系数，它的模至多1。对原mask项和新负号标签一起应用加权 Cauchy，得到

    |T_R^0(x)|²≤F_R^0(x)C_R^0(x),
    0≤C_R^0(x)≤4F_R^0(x).                             (C77.3)

所有观察积分仍用原始 dx，未改变选尺也未移动观察点分布。正对的噪声表示只新增 z=0 标签，因此仿射价格 C(z)=1+n^−1∑(|z_i|−1/2)_+ 的矩预算为

    M_K^0/W≤1+δ/2+d_δ/2,
    M_J^0/W≤I+2δ+2d_δ.                                (C77.4)

这里使用 R76 已证的全噪声矩上界，截断只减小正积分。还有更强的准确质量恒等式 ∫K_R^0=(1−δe_R/2)^n≤1：K_R原质量是两端保留质量的平均，加上其差的一半恰为α端保留质量。新增零噪声标签的价格超额 C(0)−1=0，因此 M_K^0≤(1+δ/2)W。若 n exp(−R)≤1，则 d_δ≤δ/2，故

    M_K^0≤(1+δ/2)W,
    M_J^0≤(I+3δ)W≤10IW,                              (C77.5)

最后用已证 I≥δ/3。高度也有 K_R^0≤∫K_R^0≤1、J_R^0≤I+2d_δ。新正核仍有共同源提升，因此 R76 的随机代表支付/舍入适用；并没有因此得到覆盖下界。

## 3. 整个有限物理窗口的包络，独立于尺度个数

设 k≥0 沿每条原点射线非增，质量 m。对 1≤L_1<…<L_M≤2，射线单调性给

    k_{L_{j+1}}(x)≥(L_j/L_{j+1})^n k_{L_j}(x).

从最后一项倒推最大值，点态有

    max_j k_{L_j}≤k_{L_M}+Σ_{j<M}(1−(L_j/L_{j+1})^n)k_{L_j}.

系数和≤1+n log2，因为 1−e^−u≤u。对 ||x||∞>S 积分并换元，每项的尾阈值 S/L_j≥S/2，故

    ∫_{||x||∞>S}max_j k_{L_j}(x)dx
      ≤(1+n log2)∫_{||u||∞>S/2}k(u)du.               (C77.6)

本式直接证明，没有把不同尺度的 L1 范数无偿相加。对 H，在所有 L∈[1,2] 取上确界的积分恰为 1+n log2：单位方体内部贡献1，外层半径 r∈(1/2,1] 上最小可选L=2r，立方体极坐标给 n∫_{1/2}^1dr/r=n log2。任意有限子族的积分因此不超过此值。

K 是偶、逐坐标非增乘积核的正混合，满足 (C77.6)。若 r≥1/2，则单个软坐标的 φ 尾不超过 e^{1/2−r}，因为 φ=h*w；K的平均软坐标概率为3δ/4。并集界给

    ∫_{||u||∞>r}K(u)du≤nδ exp(1/2−r).                (C77.7)

硬坐标在此范围没有尾质量。

## 4. 未截断核与补偿核心之间，全部软层一次支付

原被删噪声核 D−D_R 的全变差被 2K 的对应噪声部分控制。若 H(v−z)>0 且 ||z||∞>R，则 ||v||∞>R−1/2。故对于 R≥3/2、任意有限尺度族 Jcal⊂[1,2]，(C77.6)–(C77.7) 给

    ||max_L |ν*(D−D_R)_L|||_1
      ≤2n(1+n log2)δ exp(3/4−R/2)W.                 (C77.8)

此处 max 为有限族；符号输入由 μ 正支配，Tonelli 合法。补偿项另付

    ||max_L |d_δ ν*H_L|||_1
      ≤d_δ(1+n log2)W
      ≤[n(1+n log2)/2]δ exp(−R)W.                  (C77.9)

令 Q_n=n(1+n log2)，选共同半径

    R_n(a)=3/2+2log(4Q_n)+2a,  a≥0.                (C77.10)

则第一费用等于 δe^−a W/2；第二为 δe^−3/2 e^−2a W/(32Q_n)，小于 δe^−a W/2。R_n 满足 n e^−R≤1，因此上述噪声矩界亦同时成立。记 R_δ=D−D_R^0，则

    ||max_L |ν*(R_δ)_L|||_1≤δe^−a W.

对 δ_s=2^−s，s≥0，非负 Tonelli 与 Σδ_s=2 得

    ∫Σ_{s≥0}max_{L∈Jcal}|ν*(R_{δ_s})_L| dx≤2e^−a W. (C77.11)

和式几乎处处有限，从而余项绝对收敛。Markov 不等式直接给其阈值越限体积支付，没有调用弱 L1 准范数的三角不等式。

这允许在原逐层望远镜恒等式中，合法地把所有 D_δ 替换为零质量 D^0_{δ,R_n}，总差异由 (C77.11) 一次处理。R=O(log n+a)，不按来源数或深度额外收费。没有把单物理窗口结果写成全尺度结论。

## 5. 从反例到正确的覆盖目标

均匀大盒源在未补偿截断核心的内区上会产生 T=d_δ，虽然原核总质量为零。仅以这种人工平台否定完整核心覆盖，会遗漏它本来可以由余项支付的事实。补偿 (C77.2) 在核支撑完整落于均匀内区时严格消除此平台。该修正对任意输入和全部软层有 (C77.11)，并非只针对该模型。

但是本轮 soft.md 的真实边界条带反例来自原未截断 E2 核，不能用“人工平台”解释。固定一个尺度时，任意输入的整个 contrast 已有

    ||ν*D_L||_1≤||D||_1 W≤Σ_m|α_m−β_m| W≤min(2,nδ)W.

最后一个界可用坐标独立的最大耦合：每坐标两 Bernoulli 端点不同概率δ/2，乘积律总变差至多nδ/2，L1距离至多nδ；平凡界2同时成立。有限 M 个尺度粗相加还会有 M，不能藏入常数或当成目标。

因此新接口必须容许直接支付的事件。一个形式正确的目标是，在实际事件 E 上构造同一规则的 E_good 与 E_bad，证明 λ|E_bad|≤A_nW，并对 E_good 给共同容量覆盖或直接弱预算，使两者总费用≤√n n^{o(1)}W。也可证明 additive 覆盖关系 B_t(E)≥κ_n(T_E−A_nW)_+。这些都是待证目标，不是本轮结果；固定尺度强 L1 只说明为何覆盖比例小本身不构成弱型障碍。

本轮确定的前进方向是：保留零质量核心、同一正对及合法尾预算；对真正造成高占用的动态事件建立带支付例外的覆盖。当前一般上界仍未改进于保留的 O(n log n)，目标保持未完成。

## 5a. 所有层的高背景事件，统一按根号 n 支付

上述准确质量恒等式还允许在覆盖之前，无条件支付全部层的高背景事件。取

    w_s=1/[(s+1)(s+2)],  Σ_{s≥0}w_s=1,
    λ_s=λw_s,  H_s=√n/w_s².

每层 K_{s,R}^0 为正射线非增核，质量≤1。射线单调性来自正mask乘积：截断 w 仍偶且非增，h*w_R 亦然；后者可将 w_R 写成中心区间的正层蛋糕，而两个中心区间卷积的重叠长度沿正半轴非增。新增 H 也保此性质。因此有限窗口包络满足

    ∫max_{L∈Jcal} μ*(K_{s,R}^0)_L ≤(1+n log2)W.

令 E_high,s 为该层实际越阈事件中、实际选尺下 F_s>H_sλ_s 的部分。它包含于 {max_L F_{s,L}>√nλ/w_s}。Markov、并集界和 Σw_s=1 给

    λ|∪_{s≥0}E_high,s|
       ≤[(1+n log2)/√n] W.                           (C77.12)

这是真正针对所有输入、所有软层的一次 O(√n) 弱体积支付。阈值分配及背景截断先固定，未使用弱准范数三角不等式。更一般任何正和为一的 w_s 与 H_s=√n/w_s² 都成立。部分和 Σ_{s=0}^{m−1}w_s=m/(m+1)、尾和1/(m+1)使无限层极限没有隐藏损失。

支付余项及 (C77.12) 后，尚需处理各层 |T_s^0|>λw_s 且 F_s≤√nλ/w_s 的剩余事件。该处相对低背景阈值 H_s 随 s 增长，不能把它改写成固定绝对 B，也不能从已有低分支条件式直接声称根号 n 主界。主定理仍未闭合。此结论的作用是让下一轮仅对真正未支付的动态部分提出覆盖目标。

## 5b. 补偿后完整核心分支仍否定无例外平均覆盖

这是与本轮 soft.md 解析反例的严格合并，不修改其输入。沿用其 δ=1/2、τ=e^−4/40、λ=τ/2、R_geom=1/2+log(100n)、边长D=4nR_geom和均匀大盒源。选噪声截断半径 R*=max{R_n(0),1/2+log(8n/τ)}。原contrast至截断contrast的逐点误差≤τ/8，且 d≤τ/8，因此在同一面条带上补偿contrast T^0≥3τ/4。

准确质量 ∫K^0≤1 和源密度≤1 给 F^0≤1 全域成立。因此 E^0={|T^0|>λ,F^0≤1} 就是完整补偿核心越阈事件，并为B=1/λ的实际低背景分支。其新正对满足 C^0>λ²，且在面条带上 C^0≥9τ²/16。故

    T_E^0=∫_{E^0}C^0≥9τ² W/(64R_geom).

新J噪声质量 I^0=I_R+2d≤4+τ/4<5，联合源在(y,z)→y+z下的密度至多I^0。应用 soft.md 中已经核验、针对所有joint packets的sharp Young上界，得到

    Bavg_t(E^0)/T_E^0
       ≤[320R_geom/(9τ²)] (5/λ²)^t A(t)^n.

t=1/√n时仍超多项式衰减。因此零质量修正并未把无例外平均覆盖变成正确假设，且这一否定针对完整的补偿核心分支。它不否定优化代表接口，也不否定允许直接支付的弱形式。

补偿核心固定尺度的强 L1费用仍≤min(2,nδ)W，无需多加d：将被保留潜变量正/负总系数质量记为P_R,N_R，则d=P_R−N_R≥0。加上新的负d标签后，绝对系数总质量为P_R+N_R+d=2P_R≤2P_original=v_δ，后者即原mask两端的L1距离。这样本例完整补偿分支也仍可直接按≤2W支付。

## 6. 验证与技能范围

更新A02的外放松/正支配方向、A04共同选择及N04可求和误差边界用于上述转移。解析证明负责所有维度与输入；compensation_guard.py以有理噪声尾质量、精确mask权和扩大维数公式检查质量缺陷、正对Cauchy及预算方向。其有理代理不是φ连续积分证书，有限诊断不替代上述证明。实际执行结果与范围在最终inventory及数值笔记中列明。


# Round 77: common random representatives under coordinate revelation

Complete packet optimization for n=2–4 shows that source-sampled common random representatives can lose coverage relative to optimized fixed representatives on genuine hard-winner receiver events. At n=4, two revealed coordinates and t=1, the exact optima are `Bavg=11/32` and `Bfixed=9/20`. Both use the original uniform vertex source and actual all-scale cube winner. Larger-dimensional computations give explicit achieved lower bounds only; they neither certify an all-packet decay bound nor disprove the centered-cube weak-type goal.

This round uses exact integer counts, Fraction arithmetic and certified rational root brackets. There is no floating kernel, Monte Carlo spatial integral, optimizer tolerance, training/held-out split or fitted order. Decimal table entries are approximate displays of rational enclosures stored in JSON.

## Actual source and positive-volume winner realization

The source is `mu=2^(−n) sum_(v in {−1,1}^n) delta_v`. A query consists of a k-coordinate set S and a sign assignment sigma on S. Its captured face is `A_(S,sigma)={v: v_i=sigma_i for i in S}`, with original mass `F=2^(−k)`. Every one of the `binom(n,k)·2^k` queries has equal normalized occupation traffic.

This is realized on a positive-volume hard-winner subevent, rather than prescribed posterior vectors. Put `epsilon=1/(16n)` and take the open receiver box centered at `x_i=2sigma_i` for i in S and zero otherwise, with every coordinate displacement less than epsilon. The face is the actual all-scale winner throughout the box. Its winning radius r is the largest distance to a face vertex and lies in `[1−epsilon,1+epsilon]`.

To check every possible radius, before that face is complete the captured set, if nonempty, imposes at least one extra sign restriction on a free coordinate and has mass at most F/2. Hence its density cannot beat the full face, because `((1+epsilon)/(1−epsilon))^n<3/2<2`. An opposite sign in any revealed coordinate arrives only at radius at least `3−epsilon`; every such later cube has mass at most one, while `(3−epsilon)/(1+epsilon)>2` implies its density is smaller than the face density even when k=n. For k=n the earlier nonempty proper-face case is absent. These strict inequalities cover all intermediate complete-distance batches and preserve the prescribed smallest-radius winner rule.

The boxes are disjoint. Signed coordinate permutations preserve the original source and receiver volume, carry any query box to any other at the same k, and preserve its actual density `M=F/(2r)^n`. Consequently their M-occupation integrals are exactly equal, without estimating those integrals. Each union of query boxes lies in the actual original band `(lambda,2lambda)`, with the rational common threshold

`lambda=(3/4)·2^(−k)/(2(1+epsilon))^n`.

The uniform ratio bound `<3/2` gives the upper band inequality. Thus the query averages below are exactly the normalized hard-winner score on this union of boxes. The union is a selected band **subevent**, not the whole maximal-function band. Its small volume may be cheaply discarded in a separate weak-volume argument; no such budget is calculated here.

The geometric guard checks 129 rational open-box separation/band margins for n=2,3,4,8,16,32,64, along with 1,634 actual all-distance-batch center/corner winners in n=2–4. It also checks 23,792 source-vertex gates and 1,634 arbitrary rational fixed-representative domination instances, seed 770211. Center/corner checks supplement the uniform argument above; they are not used alone to infer the open-box statement.

## Common randomness, fixed gates and exact capacity reduction

For each fixed nonempty source packet P, put `m=|P|`, `p=m/2^n`, and `a=|P intersect Aquery|/2^n`. The representative is sampled once uniformly from P, then used at every receiver; it is not resampled in response to a query. Its expected gate is `a/p`, so the normalized column is exactly

`bavg(P)=Equery[(a/F)^(1+t)·(a/p)]`.

All packet coefficients are common and satisfy the original source capacities `sum_(P contains v) alpha_P≤1`. Optimizing the expectation of the common random score needs only its one-query marginal; this does not assert that independent receiver-wise choices are allowed or that every random realization achieves the expectation. The tested random law is specifically the source law restricted to P. Allowing arbitrary optimized random laws would include Dirac laws at the best fixed representative and would be a different problem.

For the fair fixed comparison, all representatives in Euclidean space are allowed. On these receiver boxes each one is dominated by a source sign vertex. If a gate is nonzero in a query box, its revealed coordinates satisfy `sigma_i c_i≥1−2epsilon>0`. Completing those coordinate signs to a vertex yields a vertex in the winner cube for every corresponding query box. Equivalently, one may first clamp to the source bounding box. The chosen vertex gates every box compatible with its signs; any partial gate of the original representative is dominated pointwise. Thus all `2^n` sign vertices suffice, and their gates are exactly the matching-k-sign indicators. The center c=0 gates no box for k≥1. There is no artificial omission of a useful fixed interior representative.

Write `bfixed(P,c)=Equery[(a/F)^(1+t)·1{c in Aquery}]`. In particular `bavg(P)` is the average of `bfixed(P,c)` over c in P, so `Bavg≤Bfixed`. On hard winners a singleton representative automatically gates whenever its posterior is nonzero; no extra ungated singleton relaxation changes either family.

The XOR group of all source sign flips acts transitively on vertices and preserves the full query traffic. For either column family, its source-capacity optimum is

`B=max_(packet and permitted representative) b(P)/p`.

For the upper bound, every feasible packing has `sum alpha_P p≤1`. For the lower bound, take all `2^n` XOR translations of an optimizing packet, with the representative translated as well in the fixed case, and give each indexed column coefficient `alpha=1/m`. Each source vertex belongs to exactly m translated packets, so its capacity load is exactly one. The total objective is `2^n b(P)/m=b(P)/p`. Coincident translated subsets may be merged without changing this calculation. The JSON stores these orbit primal constructions and uniform dual prices `Bupper/2^n` per site; its small-n uniform dual covers every packet/representative column.

## Certified powers and complete small-n search

The tested t values are `0,1/2,1,1/ceil(sqrt(n))`. For n=2–4 the last equals 1/2 and is recorded as an alias rather than recomputed. For t=1/d, every posterior factor `(c/face_size)^(1/d)` is enclosed on the grid `D=2^64`. The integer lower root l satisfies `l^d·face_size≤c·D^d`; the upper root is l or l+1 and satisfies the reverse inequality. Square roots use `isqrt`, and other roots use integer binary search. At t=0 every nonzero-count factor is one and zero-count summands vanish; t=1 is exactly rational. No floating root can determine an optimum or feasibility decision.

All nonempty packets are enumerated: 15 at n2, 255 at n3 and 65,535 at n4, totaling 65,805. Exact XOR canonicalization reduces objective evaluations to 6,45 and 4,335 orbits, totaling 4,386. This is a complete symmetry reduction, not a sampled packet restriction. For each of the 27 distinct `(n,k,t)` objectives the maximum lower and maximum upper column-density bounds enclose the complete optimum. Orbit primal feasibility is checked exactly, and the uniform dual has the enumerated upper objective. The largest small-n enclosure width is `2^(−64)≈5.42e−20`. For t=0 and t=1 every endpoint is exact.

All t=0 optima are one. All k=n optima are one for every tested t, achieved by singleton packets. The nontrivial cases are shown below; square-root decimals are rounded approximations, not outward intervals. Exact rational root bounds are in JSON.

| n | k | Bavg, t=1/2 | Bfixed, t=1/2 | Bavg, t=1 | Bfixed, t=1 |
|---:|---:|---:|---:|---:|---:|
| 2 | 1 | ≈.7071067812 | ≈.7071067812 | 5/8 | 2/3 |
| 3 | 1 | ≈.5690355937 | ≈.6495190528 | 1/2 | 4/7 |
| 3 | 2 | ≈.7071067812 | ≈.7071067812 | 1/2 | 1/2 |
| 4 | 1 | ≈.5151650429 | ≈.5952636752 | 1/2 | 49/88 |
| 4 | 2 | 1/2 | ≈.5196152423 | 11/32 | 9/20 |
| 4 | 3 | ≈.7071067812 | ≈.7071067812 | 1/2 | 1/2 |

At n4,k2,t1, the Bavg winner has four vertices forming a codimension-two subcube. Its complete XOR orbit attains 11/32. The fixed winner has five vertices forming the radius-one Hamming ball around its representative; the matching fixed query sees three of those five vertices, giving `Bfixed=(16/5)·(1/4)·(3/4)^2=9/20`. At t=1/2 the same fixed ball gives `3sqrt(3)/10`, strictly larger than Bavg=1/2. These are strict actual-subevent coverage gaps, not merely a packet-by-packet comparison.

## Larger dimensions: achieved bounds and a restriction failure

The next stage evaluates whole sources, singletons, every coordinate-prefix subcube, parity packets, Hamming balls and seeded random packets. The actual vertex populations are materialized as bitsets at n8 and n12. There are 30 and 36 distinct candidates respectively. Every query in the registered k families is counted exactly: k=1,2,4,8 for n8 and k=1,2,3,12 for n12. Complete revelation k=n uses the exact candidate-density identity `1/|P|` rather than a query loop. Each uses t=0,1/2,1 and the target 1/ceil(sqrt(n)), yielding 1,056 candidate-score cases. Random seeds are 771008 and 771012; four packets per prior density 1/2,1/4,1/8,1/16 are attempted and duplicates are merged. No random receiver sampling is used. The exact packets and root-enclosed achieved values are archived.

A separate analytic count evaluates every codimension-j subcube, j=0,…,n, at n=8,12,16,32,64 and k in `{1,floor(n/4),n/2,n}`. These 80 family-optimization cases avoid materializing `2^64` vertices. If r is the overlap between the query's k coordinates and the packet's j fixed coordinates, then

`Ravg(n,k,j,t)=2^(−k−jt)·E[2^(r(1+t))]`,

where `Pr(r)=binom(j,r)binom(n−j,k−r)/binom(n,k)`. The exact binomial sum and rational power bounds certify each **achieved** XOR-subcube value. A best-in-family upper endpoint encloses that family's candidate value, not the unrestricted all-packet optimum. A matching fixed vertex in a subcube achieves the same column density, so these are fixed-family lower bounds as well.

At k=n/2 and target t, the best subcube among those dimensions is the singleton, with value `2^(−(n−k)t)`:

| n | k | target t | best subcube achieved value |
|---:|---:|---:|---:|
| 8 | 4 | 1/3 | ≈.3968502630 |
| 12 | 6 | 1/4 | ≈.3535533906 |
| 16 | 8 | 1/4 | 1/4 |
| 32 | 16 | 1/6 | ≈.1574901312 |
| 64 | 32 | 1/8 | 1/16 |

This decreasing sequence is not an all-packet upper bound or proof of asymptotic decay. At k=1 the whole packet still gives 1/2 in the large-dimensional tested families, and complete revelation gives one. These different regimes rule out treating the number of queries alone as a coverage-loss parameter.

Moreover, restricting to subcubes already loses achievable coverage: at n12,k3,t1/4, the 13-vertex radius-one Hamming ball gives approximately `.224937229834`, while **every** codimension-j subcube has value at most approximately `.215757085797` (best j=9, certified by the complete finite family scan). The rational intervals are disjoint. The Hamming-ball orbit is a genuine source-capacity feasible family. It is not a general optimum, and it does not license discarding other packet shapes.

## Scope, execution and reproduction

The three executed stages are exact geometric realization; complete n2–4 packet optimization; and explicit larger-dimensional pressure/family bounds. The small-n results are complete for Boolean source packets and fixed/common-source-sampled representatives on the stated actual query subevents. The larger-n results are strictly lower bounds unless explicitly labeled as best within the subcube family. They do not establish a complete-band cover, a dimension-uniform positive fraction, or the general `C_n≤sqrt(n)n^{o(1)}` upper bound. Source capacities, the original all-scale winner and receiver volume are retained throughout.

Final production exited zero in 1.059629417 seconds under bundled Python 3.12.14, using the standard library only. The independent guard passed in 25.4943 seconds: it independently generated all 4,386 XOR orbits covering 65,805 packets, recomputed all 27 small-case average/fixed primal/dual endpoints, all 1,056 explicit pressure intervals and all 2,192 individual subcube intervals. Its full temporary-copy replay exited zero in 1.0818 seconds and produced byte-identical JSON at the frozen hash. The compact deterministic JSON is 921,811 bytes and stores geometry counts, query/parameter definitions, full small-n interval endpoints and primal/dual constructions, explicit pressure packets, seeds and all subcube-family interval values. Runtime is printed and excluded from JSON. No Git, network, installation, compilation, old-round edit or unfinished process is part of this result.

Reproduce without overwriting the archive:

```sh
stage_dir=$(mktemp -d)
cp /Users/zhengzhihao/Desktop/T/output/centered_cube_round077_20261011/reveal_probe.py "$stage_dir/reveal_probe.py"
/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 "$stage_dir/reveal_probe.py"
cmp "$stage_dir/reveal_results.json" /Users/zhengzhihao/Desktop/T/output/centered_cube_round077_20261011/reveal_results.json
```

Frozen source SHA256: `e63fe02c36e29ecc156f9f00f300dd3d1122e4436ac6243a34edd6951d71fae6`. Results SHA256: `c8a69a2896b5f818f077ad3f3e023e3295bf18eb7ba3897dfc354ace72061587`.


# 第77轮独立证书与解析接口审计

结论：冻结的解析主张和数值证书通过独立审计。硬赢家障碍限于指定真实带内子事件 U；软层稿确实给出平均代表接口在真实单尺度整低背景事件上的覆盖反例，但整个反例已有维数无关强 L¹ 支付。零质量近核修正、全层余项及高背景事件支付成立。一般剩余动态低背景事件与主 `sqrt(n)` 上界仍未证明，保留的上界为 O(n log n)。本审计只写 audit.md 与 audit_guard.py，无 Git 或编译。

本轮应用当前 A02、L03、D04 的边界：正支配逐点证明，原共同源容量不改，精确有理端点及原/对偶分别核验；不认证通用浮点区间 API，不把有限诊断升级为连续核积分定理。

## 完整赢家和对称性

参考源为 `{−1,1}^n` 上均匀概率，固定 `1≤k≤n`、`ε=1/(100n)`。在 `U_{S,σ}` 上，S 的 k 个坐标满足 `x_j=σ_j s_j`，各 `s_j∈[2+2ε,2+3ε]` 可不同，其余坐标绝对值不超过 ε。

第一批完整到达的半径为 `r_0=max_{j∈S}(s_j−1)`，正是全部匹配 S 上符号的源，质量 `2^(−k)`。其余坐标距离最多 `1+ε<r_0`。后续半径为各不同的 `s_j+1`；若已有 m 个揭示坐标可以不匹配，累计质量为 `2^(m−k)`，不能把不等的 s_j 误写为仅两个 arrival。任意后批次与第一批密度比不超过

`2^m[(1+3ε)/(3+2ε)]^n≤[2(1+3ε)/(3+2ε)]^n<1`。

因此第一批是唯一全尺度完整赢家。半径间源质量固定，平均密度严格下降，不产生其他最大值。

所有固定 k 的 `S,σ` 矩形由原产品源的坐标置换与符号翻转互相对应；实际 L、M 与原 dx 同时保持，所以交通积分严格相等。取 `λ=(3/4)2^(−k)/[2(1+3ε)]^n`，最大/最小 M 比小于 `4/3`，全部 U 落在真实 `λ<M≤2λ` 带。不同 k 的这一 λ 不同，混合不同 k 到同一阈值带需额外核验。

## XOR 容量归约

设 `b(P)` 是在上述整个对称子事件上的分包系数，并对源顶点 XOR 翻转不变。令 `p(P)=|P|/2^n`，`R=max_P b(P)/p(P)`。任何共同容量族满足 `Σα_P p(P)≤1`，故 LP≤R。

反向取一个最大比值包 P 的全部 `2^n` 个 XOR 平移，每个给系数 `1/|P|`。每个源顶点恰出现在 `|P|` 个平移包中，负载恰为 1，目标为 R。因此完整 whole-subset LP 精确等于最大单包 score/mass。重复包可合并，不改变负载或收益。

对 averaged representative 目标，联合函数 `a^(2+t)/w` 凸，故分数密度 `0≤f≤1` 的有限源 layer-cake 分解也受 whole-subset 列支配：`f=Σλ 1_{Pλ},Σλ≤1`，补零列后 Jensen 给 `b(f)≤Σλb(Pλ)`，同时源负载保持。这里不能把同一论证自动套在非凸的 fullness 指标上。若数值只使用有限代表库，XOR 归约还要求该库在相应翻转下闭合；任意优化共同曲线类与 Bavg 本身具备此对称性。

## 二次超收缩上界及全部共同曲线

对一个包（或分数密度）写 `f`、`p=Ef`，随机均匀选择 k 个揭示坐标 S 和其符号。设 `Z=E[f|X_S]`、`ρ=k/n`。实际后验就是 Z，原包捕获率是 `2^(−k) Z/p`，所以

`b_avg(P)/p=2^(−k)p^(−2) E Z^(2+t)`。

Walsh 正交展开精确给出 `E Z²=Σ_A Pr(A⊂S) fhat(A)²`。固定大小抽样满足 `Pr(A⊂S)≤ρ^|A|`，因此它至多是 `||T_(sqrtρ)f||₂²`。Bonami 原文 Chapter III Theorem 2 的范数为 1 的乘积扩展及 Theorem 3 的参数条件，在输入指数 `1+ρ`、输出指数 2 时给出 `||T_(sqrtρ)f||₂≤||f||_(1+ρ)`；这是均匀 Boolean 产品源上的结论。[Bonami 1970，印刷页374–376](https://www.numdam.org/article/AIF_1970__20_2_335_0.pdf)。本审计实际读取了该定理及其二点/乘积论证段落，没有仅凭摘要引用。

利用 `0≤Z≤1`、`0≤f≤1` 得 `E Z^(2+t)≤E Z²≤p^(2/(1+ρ))`。另有 `Z≤2^k p` 和 `EZ=p`。故每列的比值满足

`b_avg(P)/p≤min{2^(−k)p^(−2ρ/(1+ρ)), 2^(kt)p^t}`。

消去 p 后得到统一上界

`2^{−kt(1−ρ)/[t(1+ρ)+2ρ]}`。

对任意接收点独立的共同 Borel 曲线 `c(L)`，固定 S、各 s_j 与未揭示坐标后，L 不依赖 σ。每个活动坐标的正/负实际捕获区间彼此分离（间隔至少 `2(1−ε)>0`），因此 c(L) 至多门入一个 σ。由原交通在 σ 上均匀，`Eg≤2^(−k)`。这个论证适用于所有共同曲线，尤其共同仿射代表；不适用于私有 `c(x)`。

Cauchy、`Z^(2+2t)≤Z²` 和同一二次超收缩给出

`b_curve(P)/p≤min{2^(−k/2)p^(−ρ/(1+ρ)), 2^(kt)p^t}`

及消去 p 后的统一上界

`2^{−kt(1−ρ)/[2t(1+ρ)+2ρ]}`。

对所有共同容量列求和仍然使用 `Σαp≤1`，没有原子数倍数。收费归一化的费用至少 1，所以上界同样成立。取 `t≈n^(−1/2),k≈sqrt(n)`，两类接口在 U 上均可有指数于 `−sqrt(n)` 的覆盖上界；这仍仅是子事件障碍，其弱体积费用及完整事件结算必须另证。

没有使用高次随机揭示/噪声算子的无证明比较。此类全 p 比较一般失败：单 bit `f=1_{+}`、揭示率 `1/2`、指数4时，揭示四次能量 `9/32` 大于噪声 `T_(1/sqrt2)` 的 `17/64`。二次公式才是本轮已验证的路线。仅对坐标子立方体可另用 falling-factorial 展开证明 `E2^{q|S∩J|}≤[1+(2^q−1)k/n]^|J|`，它不能单独控制所有包。

## 初始独立精确守卫

本轮独立 `audit_guard.py` 已执行 PASS，实测0.8058秒：224 个不同揭示幅度的实际完整赢家实例，含544个后到达批次；全部 `n=2,3,4`、各 k 的262,935个精确 q=2 averaged-subset 系数及均匀价格对偶不等式；9个 XOR 轨道等值原对偶容量证书；1014个精确子立方体 hypergeometric 比较。没有调用生产系数或 LP 代码。q=2 是精确有限模型检查，不冒充非整数目标指数的积分证书。


## 全部共同曲线的精确归约

最终 coverage.md 增加的强归约通过核验。在原 M dx/T 交通下，各固定 k 的查询标签 `(S,σ)` 条件下，实际胜者 L 的推前律完全相同，因为坐标置换/反射保持 dx、L、M。故 L 与查询标签独立。对任何共同 Borel 曲线，取坐标符号顶点 V(c(L))。实际捕获区间在活动坐标上有严格正负间隙，故曲线 gate 被 `V(c(L))_S=σ` 的顶点 gate 逐点支配。包后验 Z 只依赖查询标签，因此

`b_c(P)/T ≤ E_L H_P(V(c(L))) ≤ max_v H_P(v)`，

其中 `H_P(v)=E_(S,σ)[1_{v_S=σ} Z^(1+t)]`。常数顶点曲线实现反向不等式。于是包包优化后，所有共同 Borel 曲线、仿射曲线和固定顶点具有相同最优值；费用 C(b)≥1 且常数曲线费 1 时仍如此。此结论靠标签与 L 的真实交通独立性，不能推广到私有 c(x) 或任意未对称事件。

## 数值实际事件、整数根及完整有限容量 LP

reveal_probe.py 的实际事件与 coverage.md 使用不同的盒族：数值盒中心活动坐标为 ±2、其余为0，每坐标误差小于 `e=1/(16n)`。此时在完整匹配面到齐前，可以先有部分匹配源到达，不能套用前文“第一批即完整面”的证明。数值报告正确使用：此前非空到达面至少多限制一个自由符号，质量最多完整面的1/2；半径在 `[1−e,1+e]`，密度比至多 `(1/2)[(1+e)/(1−e)]^n<3/4`。活动坐标的不匹配源最早于 `3−e` 到达，后批次/完整面密度比小于 `2^k[(1+e)/(3−e)]^n<1`。k=n 的前批次不存在。全部完整到达批次因此仍有唯一完整面赢家，beta=2 的共同阈值、等交通及顶点 gate 均合法。角点/中心核验辅助严格的全盒解析边界，不能单凭角点外推。

整数根证书使用 GRID=2^64，直接比较 `lo^d b ≤ a GRID^d ≤ hi^d b`；d=2 用整数平方根，其他 d 用整数二分。零计数项贡献0；t=0 非零根为1，t=1 精确有理。最大下端点来自可行 XOR 轨道，最大上端点给全源均匀价格 `Bupper/2^n`；这覆盖全部包与全部固定代表，不是优化器浮点状态。每个最大值区间宽至多2^-64。数值小维目标 t=1/2 是 `1/ceil(sqrt(n))`，n=2,3 时不是 `1/sqrt(n)`，报告明确此边界。

独立守卫不导入生产代码：以逐源 XOR 映射独立生成全部轨道并证明覆盖所有非空包，再从逐坐标查询构造重算全部27个目标的平均/固定端点和原对偶见证。n=4,k=2,t=1 的 Bavg=11/32、Bfixed=9/20 均精确复现。n=8,12 的1,056个显式候选及n≤64的2,192个子立方体区间也逐项重新计数、根比较。大维结果全部是已实现下界或限定子立方体族的值；候选上端点不认证全包最优上界。有限 query 值在指定正体积真实子事件上是精确归一化交通值，不是全空间连续积分覆盖证书。

## 真实 E2 软层整低分支障碍

soft.md 的信息恒等式来自同一联合源与实际捕获后验：`π=p f/c` 给 `E_π[-log f]=log(1/c)−D(π||p)`，有限分区的正后验项均有正先验和正捕获率，无微分熵或私有参考源替换。该恒等式只解释覆盖损失，没有凭熵形式推出下界。

对固定 L=1、联合源推前密度 u≤U，任意可测联合包 P 的推前测度被 u dx 支配，因此有密度0≤g_P≤U、质量 w_P；真实捕获为 `a_P=g_P*H`。本审计独立阅读了 [Barthe，Theorem 1，印刷页2](https://arxiv.org/pdf/math/9704210) 的 sharp Young 常数，核对 q=2+t、p=q/2、r=q' 满足指数等式。由于 H 的 L^r 范数1、`∫g_P^p≤U^(p−1)w_P`，得到

`∫a_P^(2+t)≤A(t)^n U^t w_P²`，

`Bavg(E)≤A(t)^n(U/a)^t M`，适用于真实 `G>a` 的整事件及所有共同容量包。此处容量积分 `Σαw_P≤M` 保留真实连续联合源，任意原子分裂或包形状都被该上界覆盖。

常数核验：`log A=(1+t)log((2+t)/(1+t))−log2+(t/2)log(t/(2+t))`。减去 `(t/2)log t` 后，其导数为 `log(sqrt(2+t)/(1+t))−1/2≤−(1−log2)/2`。于是 t=1/√n 时 A^n 至多 `exp[−(√n/4)log n−c0√n]`。

真正输入是大盒密度1，δ=1/2，单个真实物理尺度1，K质量1故 F≤1；取 Bλ=1，则 E 就是整个 `|T|>λ` 低背景分支。2n个互不相交的内侧面条带在活动坐标距面1至2，其余距面至少 R=.5+log(100n)；实际 φ 的软尾给活动缺陷≥e^-4/8、其余缺陷≤1/(100n)。乘积端点 contrast 及 Cauchy 因而给 `T_E≥τ²W/(4R)`。U≤I≤4、真实 E 上 C>λ²，代入 Young 上界确实给 Bavg/T_E 超多项式小。这是连续核的解析结论，不依赖数值积分。实际噪声截止的均匀误差≤τ/8，故条带与全截断分支结论稳定。

该结果推翻“每个真实低分支都须有 n^-o(1) 平均代表覆盖”的无例外接口。它没有控制更强的优化代表目标，也没有给出大的弱型常数：单尺度全部 contrast 有 `∥ν*D_L∥1≤min(2,nδ)W≤2W`，整个反例一次支付。soft.md 的有限窗口 scale-interval 支付和高背景 Markov 支付方向成立；互相重叠的例外可用并集与费用和处理，剩余动态事件仍有未付债务。

soft 嵌入守卫对真正 E2 尾使用 Simpson 256/512，仅作浮点诊断；137项检查与所列stdout复现。它不是 outward 核积分证书；远端尾 underflow 不参与上述解析定理。不可将这些浮点显示与数值 reveal 的整数根证书混为一类。

## 零质量修正、余项及所有层高背景费用

parent_compensation.md 的准确缺陷 `d=(1−δe_R/2)^n−(1−δe_R)^n` 非负，导数界给 d≤nδe_R/2。新增独立零shift标签质量d/2、ζ=−2，准确给 D0=DR−dH、K0=KR+dH/2、J0=JR+2dH，保留任意符号或复输入的同选尺 Cauchy、J0≤4K0与共同原位置源。K0 质量准确等于 α 端保留质量≤1；新增标签的价格超额为0，故 M_K0≤(1+δ/2)W。J噪声预算 I+2δ+2d≤I+3δ≤10I（使用I≥δ/3）合法。

有限窗口 ray 单调式方向已逐步核验：`k_(Lnext)≥(L/Lnext)^n k_L`，从最后一项倒推 max 得到正系数上界。系数和≤1+n log2；外区域换元的尾阈值至少S/2，方向正确。截断噪声部分不必自身射线单调：它被 `2K(v)1_{|v|∞>R−.5}` 支配，因L≥1可先以共同外域截断包络，再对完整正 K 使用窗口尾界。这排除了对已删除噪声私自假设单调性的隐患。

Q=n(1+n log2)、R=1.5+2log(4Q)+2a 的尾费准确为δe^-a/2；补偿费≤δe^-1.5 e^-2a/(32Q)≤δe^-a/2。因此全部层的强 L1 余项≤2e^-aW，Tonelli给a.e.绝对收敛；没有平均弱准范数或忽略层数。人工平台被准确移除，但真实面条带障碍仍在。

新增全层高背景规则 `w_s=1/((s+1)(s+2)),λ_s=λw_s,H_s=√n/w_s²`，每层 K0 正射线非增且质量≤1，故 envelope 积分≤(1+n log2)W。实际事件包含于 `max_L F_s>√n λ/w_s`；Markov 后乘λ并求并集费用为 `[(1+n log2)/√n]W Σw_s`。Σw_s=1、部分和m/(m+1)、尾1/(m+1)，全部层一次O(√n)支付无损失。剩余层的相对低背景阈值 H_s 随s增长，不能悄然改写为固定B后声称主界。

compensation_guard.py 的第2阶段是声明清楚的有理离散软噪声代理，使用实际端点 Bernoulli 系数。独审用端点乘积重构 D/K、独立mask求J，重验全部960条带符号输入行及保存见证；这验证代数接口，不认证连续φ。36个大维fee模型与12个高背景预算模型是隐式有理预算，未枚举2^16384个mask；解析 ray/tail 前提由主文负责。

## 跨组件加强：完整零质量核心也需支付例外

父稿最终§5b把以上两套已核验接口严格合并，此加强亦通过独审。取 `R*=max{R_n(0),.5+log(8n/τ)}`，真实原核至截断核的逐点差≤τ/8，d≤τ/8；同一面条带的补偿 contrast 因此≥3τ/4。K0质量≤1及源密度≤1使 F0≤1 全域成立，所以 `E0={|T0|>λ,F0≤1}` 是完整补偿核心 level set，而不是仅条带见证。新 Cauchy 给 E0 上 C0>λ²，条带上 C0≥9τ²/16，故 occupation 至少 `9τ²W/(64R_geom)`。

新联合 J0 源质量 `I0=I_R+2d≤4+τ/4<5`、推前密度≤I0，同一 sharp Young 全包上界得到

`Bavg(E0)/T_E0 ≤[320R_geom/(9τ²)](5/λ²)^t A(t)^n`。

常数320/9及 t=1/√n 的超多项式衰减均正确；这确认**严格零质量的完整核心低分支**也不能要求无例外平均代表覆盖。与此同时，保留潜变量的正负系数质量记 P_R,N_R，有d=P_R−N_R≥0；追加负d后绝对系数总质量为 `P_R+N_R+d=2P_R≤2P_original=vδ≤min(2,nδ)`。因此完整补偿分支的单尺度支付仍≤2W，而非原费用再加d。这一加强是解析合并，未声称有新增连续积分数值证书；优化代表与剩余动态事件主界仍未证明。

## 冻结执行记录

开发目录的完整独立审计实测 **PASS 25.4943秒**；随后修复归档输入查找后的最终版本，在独立最小目录实测 **PASS 25.1077秒**（外部进程25.1309秒）。两次均为Python3.12标准库，无生产模块导入，数值内容与检查数一致：

- 原几何224实例、544后批次；精确q=2全部262,935列及同数对偶不等式、9轨道证书；1,014个子立方体hypergeometric比较。
- 独立生成4,386个XOR轨道，覆盖65,805非空包；27个完整small目标（54个avg/fixed区间及见证）；1,056压力候选区间、2,192结构区间。
- 280个质量重分组实例、960个独立端点乘积signed行、36个fee模型、12个无限层高背景预算模型。
- 临时副本执行 reveal_probe.py **1.0818秒**、compensation_guard.py **0.4377秒**，两份 JSON 与归档逐字节一致；冻结源码/结果 SHA 均匹配。
- 从主文实际提取守卫执行：coverage **0.2571秒 / 613检查**，soft **0.0201秒 / 137检查**。coverage guard SHA `c1dfa6ffff2156b96af2bac41a7c703cec6eb3c41cce6cc56b470b7e28dbc4a8`；soft guard SHA `3d5b20dfa75089e154e803e20eea05ea879f33aec57a1fc48866dd3b3ba7bf45`。

归档可移植性曾有一个实际失败：父任务第一次在只有两主py/json、audit和已提取coverage_guard.py/soft_guard.py的目录重放时，计算检查完成，但旧 replays() 读取不存在的coverage.md，抛FileNotFoundError，约24.88秒。该次结果是FAIL，保留其失败记录，不计为PASS。

最终修复只改包内守卫定位，按顺序读取同目录 `coverage_guard.py` / `soft_guard.py`，开发目录的component.md，或合并的proof.md。proof fallback按已冻结守卫SHA匹配Python fence，避免误认其他代码块；所有分支核对冻结守卫字节。最小必需输入为 audit_guard.py、两主py/json，以及两提取guard或含其冻结fence的proof.md。**不需要归档外的coverage.md、soft.md或工作目录文件。**

实际可移植重放创建独立临时目录，只复制上述7个py/json，未复制单篇Markdown：完整PASS，reveal重放1.0800秒、compensation0.4333秒，两份JSON逐字节一致；coverage613项/0.2525秒、soft137项/0.0204秒通过。随后删去两提取guard，仅保留合并proof.md的两个原始代码fence，单独执行完整 replays()，两主JSON再度逐字节一致，proof两守卫分别0.2578秒/0.0197秒通过。proof-only这一步只重验输入定位及重放，没有再次宣称全枚举重跑。

执行复现：在按上述要求提取的归档目录运行 `python3 audit_guard.py`；守卫自身在系统临时目录重放两主程序及两个辅助守卫，不覆盖归档JSON。重复执行打印时钟可能变化，确定性JSON内容必须不变。主文 TeX companion 已对照关键式、参数和状态；无编译。

冻结文件 SHA256（报告的 receipt 追加亦已纳入）：

| 文件 | SHA256 |
|---|---|
| reveal_probe.py | `e63fe02c36e29ecc156f9f00f300dd3d1122e4436ac6243a34edd6951d71fae6` |
| reveal_results.json | `c8a69a2896b5f818f077ad3f3e023e3295bf18eb7ba3897dfc354ace72061587` |
| reveal_numeric.md | `600bb0b1a66467f4ea12da160d6389218af2f108bf07b07788ffdca8949c8647` |
| compensation_guard.py | `7e76ff9960d3185e3f4fc59a59965e0fa7a58be5a2408b399151cf74f79b5bb4` |
| compensation_results.json | `ef027dba34a21b4a1611f4c24fa167bdeeda652c9da5b3283e5733d43a517e4a` |
| coverage.md | `9fbdca9ba56c51fe090e9b78a0578eb8e6a0a71e57752b45f73e0c30561bbfa8` |
| coverage.tex.txt | `6012327a49dfb4dabcb9a0c8fda86e2382d4f7810ab84479c57352ced5ea2eb1` |
| soft.md | `cfcd7506a557270a245ae01f58e2ea3f0f1c3fc1f1586721389ece7420a496ca` |
| soft.tex.txt | `d9b6a2fa2f89e4505fcae5eb318dba01750038b4ebe99dd680ab62162437d4e7` |
| parent_compensation.md | `22d9bac8481379d89b4b1d22ba0ecf41fea59f7684720fe6861b6e0986aa4292` |
| parent_compensation.tex.txt | `da1b4c5cdc8cb91c647e40faf5a7f1a954f0c724fb77caa0837a1ffb7320075f` |
| audit_guard.py | `800c36246bcdd64df6cc80a7763f6f4ab7ef5fc07ad2a8914ca7a2f2a9c68c39` |

审计未发现需要修复的最终数学或数值证书错误。可认证范围是以上具体解析接口与精确有限证书；不会从它们自动推出完整尺度局部化、未支付动态低背景事件覆盖或中心立方体主根号界。


## 最终独立守卫 audit_guard.py

```python
#!/usr/bin/env python3
"""R77 independent exact codimension-reveal and XOR-orbit guards."""
from fractions import Fraction as F
from itertools import product, combinations
from pathlib import Path
import math,random,json,time,hashlib,tempfile,subprocess,sys,re
from functools import lru_cache

BASE=Path(__file__).resolve().parent

def actual_winner(points,x):
    radii=sorted(set(max(abs(x[i]-y[i]) for i in range(len(x))) for y in points))
    values=[]
    for r in radii:
        captured=[j for j,y in enumerate(points) if all(abs(x[i]-y[i])<=r for i in range(len(x)))]
        values.append((F(len(captured),len(points))/(2*r)**len(x),r,captured))
    # Exact rational maximum; first volume breaks any ties.
    return max(values,key=lambda v:(v[0],-v[1])),values

def winner_checks():
    rng=random.Random(770711)
    count=0; distinct_late_batches=0
    for n in (2,3,4,5):
        points=list(product((-1,1),repeat=n));eps=F(1,100*n)
        for k in range(1,n+1):
            minM=F(1,2**k)/(2*(1+3*eps))**n
            maxM=F(1,2**k)/(2*(1+2*eps))**n
            lam=F(3,4)*minM
            assert lam<minM and maxM<=2*lam
            for _ in range(16):
                S=rng.sample(range(n),k);signs={i:rng.choice((-1,1)) for i in S}
                x=[F(rng.randint(-8,8),8)*eps for i in range(n)]
                for order,i in enumerate(S):x[i]=signs[i]*(2+2*eps+F(order+1,k+1)*eps)
                winner,events=actual_winner(points,x)
                r0=max(abs(x[i])-1 for i in S)
                expected=[j for j,y in enumerate(points) if all(y[i]==signs[i] for i in S)]
                assert winner[1]==r0 and winner[2]==expected
                assert len(events)==k+1
                assert lam<winner[0]<=2*lam
                assert all(v[0]<winner[0] for v in events[1:])
                distinct_late_batches+=len(events)-1;count+=1
    return {'exact_complete_winner_cases':count,'nonfirst_arrival_batches':distinct_late_batches}

def coefficient(mask,reveals,N):
    # q=2 exact averaged representative score, rather than a fullness gate.
    size=mask.bit_count();D=(reveals[0]).bit_count()
    return F(sum((mask&r).bit_count()**3 for r in reveals),len(reveals)*D*D*size)

def xor_checks():
    counts={'all_subset_coefficients':0,'uniform_dual_inequalities':0,'exact_orbit_certificates':0}
    records=[]
    for n in (2,3,4):
        N=1<<n
        for k in range(1,n+1):
            reveals=[]
            for S in combinations(range(n),k):
                for signs in product((0,1),repeat=k):
                    reveals.append(sum(1<<v for v in range(N) if all((v>>j&1)==s for j,s in zip(S,signs))))
            best=F(0);bestmask=None;coeff={}
            for mask in range(1,1<<N):
                b=coefficient(mask,reveals,N);coeff[mask]=b
                ratio=b*N/mask.bit_count()
                if ratio>best:best=ratio;bestmask=mask
                counts['all_subset_coefficients']+=1
            for mask,b in coeff.items():
                assert best*mask.bit_count()/N>=b
                counts['uniform_dual_inequalities']+=1
            sites=[i for i in range(N) if bestmask>>i&1];size=len(sites)
            orbit=[sum(1<<(i^shift) for i in sites) for shift in range(N)]
            alpha=F(1,size)
            assert all(sum(alpha for m in orbit if m>>i&1)==1 for i in range(N))
            assert all(coeff[m]==coeff[bestmask] for m in orbit)
            assert sum(alpha*coeff[m] for m in orbit)==best
            counts['exact_orbit_certificates']+=1
            records.append({'n':n,'k':k,'q':2,'value':str(best),'witness_mask':bestmask})
    counts['records']=records
    return counts

def hypercontractive_sanity():
    # Shows why generic Lp erasure/noise comparisons need an actual theorem.
    rho=F(1,2)
    reveal=F(1,16)+rho*(F(1,2)-F(1,16))
    noise=(1+6*rho+rho*rho)/16
    assert reveal==F(9,32)>noise==F(17,64)
    # Falling-factorial hypergeometric moment, valid for coordinate subcubes.
    checks=0
    for n in range(2,15):
        for k in range(1,n+1):
            for ell in range(1,n+1):
                c=F(3) # 2**q-1 for q=2
                exact=sum(F(math.comb(ell,h)*math.comb(n-ell,k-h),math.comb(n,k))*(1+c)**h for h in range(max(0,k-(n-ell)),min(k,ell)+1))
                assert exact<=(1+c*F(k,n))**ell
                checks+=1
    return {'erasure_noise_direction_counterexample':'p=4,rho=1/2: 9/32 > 17/64','exact_subcube_hypergeometric_checks':checks}


@lru_cache(None)
def rooted(a,b,d):
    grid=1<<64
    if not a:return 0,0
    if not d:return grid,grid
    low=math.isqrt(a*grid*grid//b) if d==2 else a*grid//b
    if d not in (1,2):
        low=0;high=grid+1
        while high-low>1:
            mid=(high+low)//2
            if b*mid**d<=a*grid**d:low=mid
            else:high=mid
    high=low+(b*low**d!=a*grid**d)
    assert b*low**d<=a*grid**d<=b*high**d
    return low,high

def independent_score(packet,n,k,d):
    N=1<<n;size=packet.bit_count();face=1<<(n-k);rows=[]
    av=[0,0];fixed=[[0,0] for _ in range(N)]
    for S in combinations(range(n),k):
        for signs in product((0,1),repeat=k):
            vertices=[v for v in range(N) if all((v>>i&1)==z for i,z in zip(S,signs))]
            count=sum(packet>>v&1 for v in vertices)
            lo,hi=rooted(count,face,d)
            for e,r in enumerate((lo,hi)):
                av[e]+=count*count*r
                for v in vertices:fixed[v][e]+=count*r
            rows.append(vertices)
    Z=len(rows);grid=1<<64
    return [F(N*z,face*size*size*Z*grid) for z in av], [F(N*max(v[e] for v in fixed),face*size*Z*grid) for e in (0,1)]

def frozen_reveal():
    data=json.loads((BASE/'reveal_results.json').read_text());orbits={};maps={}
    for n in (2,3,4):
        N=1<<n;seen=set();reps=[]
        for P in range(1,1<<N):
            if P in seen:continue
            sites=[i for i in range(N) if P>>i&1]
            orbit={sum(1<<(i^z) for i in sites) for z in range(N)}
            assert P==min(orbit)
            seen.update(orbit);reps.append(P)
        assert len(seen)==(1<<N)-1
        orbits[n]=reps
    cases=0;root_checks=0
    for row in data['exhaustive']:
        n,k,t=row['n'],row['k'],F(row['t']);d=0 if not t else t.denominator
        assert t in (0,F(1,2),1)
        maxima=[[F(0),F(0)],[F(0),F(0)]]
        for packet in orbits[n]:
            a,b=independent_score(packet,n,k,d)
            for j,vals in enumerate((a,b)):
                for e,v in enumerate(vals):maxima[j][e]=max(maxima[j][e],v)
        assert maxima[0]==list(map(F,row['Bavg_interval']))
        assert maxima[1]==list(map(F,row['fixed_interval']))
        for key,certkey,fam in [('Bavg_interval','avg_orbit_certificate',0),('fixed_interval','fixed_orbit_certificate',1)]:
            cert=row[certkey];P=cert['packet'];N=1<<n;m=P.bit_count()
            orbit=[sum(1<<(i^z) for i in range(N) if P>>i&1) for z in range(N)]
            assert all(sum(F(1,m) for packet in orbit if packet>>i&1)==1 for i in range(N))
            assert independent_score(P,n,k,d)[fam][0]==maxima[fam][0]==F(cert['value_lower'])
            dualkey='avg_uniform_dual_price_per_site' if fam==0 else 'fixed_uniform_dual_price_per_site'
            assert F(row[dualkey])*(1<<n)==maxima[fam][1]
            assert maxima[fam][1]-maxima[fam][0]<=F(1,1<<64)
            if d in (0,1):assert maxima[fam][0]==maxima[fam][1]
        cases+=1
    for row in data['subcube_family']:
        n,k,t=row['n'],row['k'],F(row['t']);d=0 if not t else t.denominator
        for j,saved in enumerate(row['all_codimension_intervals']):
            vals=[F(0),F(0)]
            for r in range(max(0,k-n+j),min(k,j)+1):
                factor=F(math.comb(j,r)*math.comb(n-j,k-r),math.comb(n,k))*F(2)**(r-k)
                for e,z in enumerate(rooted(1,1<<(j-r),d)):vals[e]+=factor*F(z,1<<64)
            assert vals==list(map(F,saved));root_checks+=1
        j=row['best_codimension'];assert list(map(F,row['best_interval']))==list(map(F,row['all_codimension_intervals'][j]))
        assert F(row['best_interval'][0])==max(F(z[0]) for z in row['all_codimension_intervals'])
    pressure=0
    for row in data['pressure']:
        n,k,t=row['n'],row['k'],F(row['t']);d=0 if not t else t.denominator;N=1<<n;face=1<<(n-k)
        for candidate in row['candidates']:
            packet=int(candidate['packet_hex'],16);size=packet.bit_count();vals=[0,0];queries=0
            if k==n:
                assert list(map(F,candidate['achieved_interval']))==[F(1,size)]*2
                pressure+=1;continue
            for S in combinations(range(n),k):
                counts=[0]*(1<<k)
                for v in range(N):
                    if packet>>v&1:counts[sum((v>>i&1)<<j for j,i in enumerate(S))]+=1
                for count in counts:
                    for e,z in enumerate(rooted(count,face,d)):vals[e]+=count*count*z
                queries+=len(counts)
            vals=[F(N*v,face*size*size*queries*(1<<64)) for v in vals]
            assert vals==list(map(F,candidate['achieved_interval']));pressure+=1
    return {'complete_small_cases':cases,'independent_XOR_orbits':sum(map(len,orbits.values())),'structured_subcube_intervals':root_checks,'explicit_pressure_intervals':pressure}

def compensation_checks():
    data=json.loads((BASE/'compensation_results.json').read_text());mass=rows=fees=0
    for r in data['stage1']['records']:
        n,delta,e=r['n'],F(r['delta']),F(r['e_surrogate']);A=B=J=Dtv=F(0)
        for k in range(n+1):
            count=math.comb(n,k);a=(delta/2)**k*(1-delta/2)**(n-k);b=delta**k*(1-delta)**(n-k)
            A+=count*a*(1-e)**k;B+=count*b*(1-e)**k
            J+=count*(2*(a-b)**2/(a+b) if a+b else 0)*(1-e)**k
            Dtv+=count*abs(a-b)*(1-(1-e)**k)
        assert [A,B]==list(map(F,r['endpoint_core_masses']))
        assert F(r['signed_core_mass'])==A-B and F(r['J_core_mass'])==J
        assert F(r['K_compensated_mass'])==A<=1
        assert F(r['J_compensated_mass'])==J+2*(A-B)<=4*A
        assert F(r['D_tail_total_variation'])==Dtv;mass+=1
    for case in data['stage2']['cases']:
        n,delta,e=case['n'],F(case['delta']),F(case['e_surrogate']);rng=random.Random(case['seed'])
        ys=[tuple(F(rng.randrange(-6,7),8) for _ in range(n)) for _ in range(3)]
        assert ys==[tuple(map(F,y)) for y in case['source_positions']]
        xx=[tuple(F(rng.randrange(-16,17),8) for _ in range(n)) for _ in range(16)]+ys+[(F(0),)*n]
        weights=list(map(F,case['source_mu']));signed=list(map(F,case['source_nu']));d=(1-delta*e/2)**n-(1-delta*e)**n
        generated=[]
        for rid,x in enumerate(xx):
            L=(F(1),F(3,2),F(2))[rid%3];K=J=D=Hm=Hn=F(0)
            for y,w,nu in zip(ys,weights,signed):
                v=[(a-b)/L for a,b in zip(x,y)]
                hard=[F(abs(a)<=F(1,2)) for a in v]
                soft=[(1-e)*sum(p for z,p in ((F(-1,4),F(1,4)),(F(0),F(1,2)),(F(1,4),F(1,4))) if abs(a-z)<=F(1,2)) for a in v]
                endA=math.prod((1-delta/2)*h+delta/2*s for h,s in zip(hard,soft))
                endB=math.prod((1-delta)*h+delta*s for h,s in zip(hard,soft))
                jp=F(0)
                for bits in product((0,1),repeat=n):
                    k=sum(bits);a=(delta/2)**k*(1-delta/2)**(n-k);b=delta**k*(1-delta)**(n-k)
                    jp+=(2*(a-b)**2/(a+b) if a+b else 0)*math.prod(s if bit else h for bit,h,s in zip(bits,hard,soft))
                K+=w*(endA+endB)/(2*L**n);D+=nu*(endA-endB)/L**n;J+=w*jp/L**n
                Hm+=w*math.prod(hard)/L**n;Hn+=nu*math.prod(hard)/L**n
            K0,J0,D0=K+d*Hm/2,J+2*d*Hm,D-d*Hn
            assert D0*D0<=K0*J0 and J0<=4*K0
            generated.append((K,J,D,Hm,Hn,K0,J0,D0));rows+=1
        for i,r in zip(case['saved_witness_indices'],case['saved_witness_rows']):
            assert generated[i]==tuple(F(r[key]) for key in ('K_core','J_core','D_core_signed','H_mu','H_nu_signed','K0','J0','D0_signed'))
    for r in data['stage3']['models']:
        n,b=r['n'],F(r['b_equals_exp_minus_a_surrogate']);lo,hi=map(F,r['Q_interval']);v=F(r['v_upper_for_exp_minus_R'])
        assert v==b*b/(64*lo*lo)
        tail=2*hi*F(9,4)*b/(8*lo);comp=hi*v/2
        assert tail==F(r['tail_fee_per_delta_upper']) and comp==F(r['compensation_fee_per_delta_upper'])
        assert tail+comp<=b and F(r['all_scale_combined_fee_upper'])==2*(tail+comp)<=2*b;fees+=1
    high=0
    for stage in data['high_background_budget_guard']['stages']:
        m=stage['explicit_layer_count']
        for r in stage['models']:
            n=r['n'];root=math.isqrt(n);weights=[F(1,(s+1)*(s+2)) for s in range(m)]
            assert root*root==n and sum(weights)==F(m,m+1)
            assert F(r['exact_all_layer_payment_coefficient'])==F(1,root)
            partial=list(map(F,r['finite_high_background_budget_interval']));tail=list(map(F,r['remaining_high_background_budget_interval']));whole=list(map(F,r['all_layer_high_background_budget_interval']))
            assert [a+b for a,b in zip(partial,tail)]==whole
            for z in r['first_last_layers']:
                w=F(1,(z['s']+1)*(z['s']+2));assert F(z['w'])==w and F(z['H'])==root/(w*w) and F(z['payment_coefficient'])==w/root
            high+=1
    return {'exact_binomial_mass_cases':mass,'independent_endpoint_product_signed_rows':rows,'implicit_fee_models':fees,'all_layer_high_budget_models':high}


def guard_source(component):
    """Only package-local inputs: extracted guard, component md, or proof md."""
    expected={'coverage':'c1dfa6ffff2156b96af2bac41a7c703cec6eb3c41cce6cc56b470b7e28dbc4a8',
              'soft':'3d5b20dfa75089e154e803e20eea05ea879f33aec57a1fc48866dd3b3ba7bf45'}[component]
    direct=BASE/(component+'_guard.py')
    if direct.is_file():
        payload=direct.read_bytes();origin=direct.name
    elif (BASE/(component+'.md')).is_file():
        origin=component+'.md'
        fences=re.findall(r'```python\n(.*?)\n```',(BASE/origin).read_text(),re.S)
        assert len(fences)==1
        payload=(fences[0]+'\n').encode()
    elif (BASE/'proof.md').is_file():
        origin='proof.md'
        fences=re.findall(r'```python\n(.*?)\n```',(BASE/origin).read_text(),re.S)
        matches=[(f+'\n').encode() for f in fences if hashlib.sha256((f+'\n').encode()).hexdigest()==expected]
        assert len(matches)==1, 'proof.md must contain exactly one frozen '+component+' Python guard'
        payload=matches[0]
    else:
        raise FileNotFoundError('Package needs '+component+'_guard.py, '+component+'.md, or proof.md containing its frozen Python fence')
    assert hashlib.sha256(payload).hexdigest()==expected, 'Frozen '+component+' guard bytes differ'
    return payload,origin

def replays():
    frozen={'reveal_probe.py':'e63fe02c36e29ecc156f9f00f300dd3d1122e4436ac6243a34edd6951d71fae6','reveal_results.json':'c8a69a2896b5f818f077ad3f3e023e3295bf18eb7ba3897dfc354ace72061587','compensation_guard.py':'7e76ff9960d3185e3f4fc59a59965e0fa7a58be5a2408b399151cf74f79b5bb4','compensation_results.json':'ef027dba34a21b4a1611f4c24fa167bdeeda652c9da5b3283e5733d43a517e4a'}
    for name,h in frozen.items():assert hashlib.sha256((BASE/name).read_bytes()).hexdigest()==h
    receipts=[]
    with tempfile.TemporaryDirectory(prefix='r77-independent-') as tmp:
        target=Path(tmp)
        for code,result in [('reveal_probe.py','reveal_results.json'),('compensation_guard.py','compensation_results.json')]:
            (target/code).write_bytes((BASE/code).read_bytes());start=time.perf_counter()
            proc=subprocess.run([sys.executable,str(target/code)],capture_output=True,text=True,check=True)
            assert (target/result).read_bytes()==(BASE/result).read_bytes()
            receipts.append({'code':code,'byte_identical':True,'seconds':round(time.perf_counter()-start,4),'stdout':proc.stdout.strip()})
        for component in ('coverage','soft'):
            payload,origin=guard_source(component);path=target/(component+'_guard.py');path.write_bytes(payload)
            start=time.perf_counter();proc=subprocess.run([sys.executable,str(path)],capture_output=True,text=True,check=True)
            receipts.append({'component':component,'package_source':origin,'guard_sha256':hashlib.sha256(payload).hexdigest(),'seconds':round(time.perf_counter()-start,4),'stdout':proc.stdout.strip()})
    return receipts

def main():
    start=time.perf_counter()
    out={'status':'PASS','actual_winners':winner_checks(),'xor_orbits':xor_checks(),'hypercontractivity_sanity':hypercontractive_sanity(),
         'frozen_reveal':frozen_reveal(),'compensation':compensation_checks(),'replays':replays(),
         'scope':'Actual codim-k winner and exact q=2 finite-reveal functional; no continuum coverage or generic hypercontractivity claim.'}
    out['elapsed_seconds']=round(time.perf_counter()-start,4)
    print(json.dumps(out,sort_keys=True))

if __name__=='__main__':main()
```
