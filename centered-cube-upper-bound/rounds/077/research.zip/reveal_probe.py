#!/usr/bin/env python3
"""R77 exact finite reveal-query coverage, actual hard-winner geometry guards.
Small n exhaustive packets; larger n structural/random lower bounds ONLY.
Rational power intervals use integer-root inequalities, no floating oracle.
"""
from fractions import Fraction as Q
from functools import lru_cache
from pathlib import Path
import itertools,math,random,json,time,hashlib
GRID=1<<64

def clean(o):
 if isinstance(o,Q):return str(o)
 if isinstance(o,dict):return {str(k):clean(v) for k,v in o.items()}
 if isinstance(o,(list,tuple)):return [clean(v) for v in o]
 return o

@lru_cache(None)
def root_bounds(a,b,d):
 """Enclose (a/b)^t: t=0 when d=0, otherwise t=1/d."""
 if a==0:return 0,0
 if d==0:return GRID,GRID # t=0
 if d==1:
  lo=a*GRID//b;return lo,lo+int(lo*b!=a*GRID)
 target=a*GRID**d//b
 if d==2:lo=math.isqrt(target)
 else:
  L,H=0,GRID+1
  while H-L>1:
   m=(L+H)//2
   if m**d<=target:L=m
   else:H=m
  lo=L
 hi=lo+int(lo**d*b!=a*GRID**d)
 assert lo**d*b<=a*GRID**d<=hi**d*b
 return lo,hi

def coordinate_masks(n):
 N=1<<n
 return [sum(1<<v for v in range(N) if v>>i&1) for i in range(n)]

def translate(P,v,n,coords=None):
 coords=coordinate_masks(n) if coords is None else coords;full=(1<<(1<<n))-1
 for i in range(n):
  if v>>i&1:P=((P&(full^coords[i]))<<(1<<i))|((P&coords[i])>>(1<<i))
 return P

def canonical(P,n,coords):
 best=P;value=P;previous=0
 for j in range(1,1<<n):
  g=j^(j>>1);flip=(g^previous).bit_length()-1;step=1<<flip;cm=coords[flip];full=(1<<(1<<n))-1
  value=((value&(full^cm))<<step)|((value&cm)>>step);best=min(best,value);previous=g
 return best

@lru_cache(None)
def queries(n,k):
 coords=coordinate_masks(n);full=(1<<(1<<n))-1;out=[]
 for S in itertools.combinations(range(n),k):
  for bits in itertools.product((0,1),repeat=k):
   mask=full;chosen=0;select=sum(1<<i for i in S)
   for i,b in zip(S,bits):
    mask&=coords[i] if b else full^coords[i]
    if b:chosen|=1<<i
   out.append((mask,select,chosen))
 return tuple(out)

def optimum_update(old,num,den,P,vertex=None):
 if old is None or num*old['den']>old['num']*den:return dict(num=num,den=den,P=P,vertex=vertex)
 return old

def score(P,n,k,d,query=None):
 N=1<<n;m=P.bit_count();f=1<<(n-k);query=queries(n,k) if query is None else query
 if k==n:
  value=Q(1,m);return dict(avg_lower=value,avg_upper=value,fixed_lower=value,fixed_upper=value,vertex=(P&-P).bit_length()-1)
 counts=[(P&a).bit_count() for a,_,_ in query];bounds=[root_bounds(c,f,d) for c in range(f+1)];Z=len(query)
 alo=sum(c*c*bounds[c][0] for c in counts);ahi=sum(c*c*bounds[c][1] for c in counts)
 # Average representative gate equals average of the matching source-vertex gates.
 vlo=vhi=-1;bestv=0
 for v in range(N):
  lo=hi=0
  for c,(_,select,chosen) in zip(counts,query):
   if v&select==chosen:lo+=c*bounds[c][0];hi+=c*bounds[c][1]
  if lo>vlo:vlo=lo;bestv=v
  vhi=max(vhi,hi)
 return dict(avg_lower=Q(N*alo,f*m*m*Z*GRID),avg_upper=Q(N*ahi,f*m*m*Z*GRID),fixed_lower=Q(N*vlo,f*m*Z*GRID),fixed_upper=Q(N*vhi,f*m*Z*GRID),vertex=bestv)

def winner(n,x):
 N=1<<n;batches={}
 for v in range(N):
  y=tuple(Q(1 if v>>i&1 else -1) for i in range(n));r=max(abs(x[i]-y[i]) for i in range(n));batches.setdefault(r,0);batches[r]|=1<<v
 captured=0;best=None
 for r,arrivals in sorted(batches.items()):
  captured|=arrivals;M=Q(captured.bit_count(),N)/(2*r)**n
  if best is None or M>best[0]:best=(M,r,captured)
 return best

def geometry_guard():
 rng=random.Random(770211);counts=dict(rational_open_box_margins=0,actual_complete_batch_winners=0,fixed_vertex_gate_equivalence=0,arbitrary_fixed_vertex_domination=0)
 for n in (2,3,4,8,16,32,64):
  e=Q(1,16*n)
  assert ((1+e)/(1-e))**n<Q(3,2)<2 and (3-e)/(1+e)>2
  for k in range(1,n+1):
   lam=Q(3,4)*Q(1,1<<k)/(2*(1+e))**n
   assert Q(1,1<<k)/(2*(1+e))**n>lam
   assert Q(1,1<<k)/(2*(1-e))**n<2*lam
   counts['rational_open_box_margins']+=1
 for n in (2,3,4):
  e=Q(1,16*n);N=1<<n
  for k in range(1,n+1):
   lam=Q(3,4)*Q(1,1<<k)/(2*(1+e))**n
   for face,select,chosen in queries(n,k):
    center=tuple(Q(2*(1 if chosen>>i&1 else -1)) if select>>i&1 else Q(0) for i in range(n))
    offsets=[(Q(0),)*n]+list(itertools.product((-e,e),repeat=n))
    for offset in offsets:
     x=tuple(a+b for a,b in zip(center,offset));M,r,cap=winner(n,x)
     assert cap==face and lam<M<2*lam;counts['actual_complete_batch_winners']+=1
     for v in range(N):
      gate=all(abs(x[i]-(1 if v>>i&1 else -1))<=r for i in range(n))
      assert gate==(v&select==chosen);counts['fixed_vertex_gate_equivalence']+=1
     c=tuple(Q(rng.randrange(-48,49),32) for i in range(n));clamped=tuple(max(Q(-1),min(Q(1),z)) for z in c);v=sum(1<<i for i,z in enumerate(clamped) if z>=0)
     cg=all(abs(x[i]-c[i])<=r for i in range(n));vg=all(abs(x[i]-(1 if v>>i&1 else -1))<=r for i in range(n))
     assert not cg or vg;counts['arbitrary_fixed_vertex_domination']+=1
 return dict(status='PASS',seed=770211,epsilon='1/(16n)',band_lambda='(3/4)*2^(-k)/(2*(1+epsilon))^n',beta=2,counts=counts,scope='Exact all-distance-batch corner/center checks and rational uniform-margin checks; open-box proof supplied in report.')

def orbit_certificate(P,n,value,vertex=None):
 N=1<<n;m=P.bit_count();coords=coordinate_masks(n);packets=[translate(P,v,n,coords) for v in range(N)]
 loads=[sum(bool(packet>>i&1) for packet in packets)*Q(1,m) for i in range(N)]
 assert all(z==1 for z in loads)
 return dict(packet=P,packet_size=m,alpha_each=Q(1,m),translations=N,loads=loads,value_lower=value,representative_vertex=vertex,rule='Use every XOR translate with coefficient 1/|P|; fixed reps translate by the same XOR. Duplicate indexed columns may be merged.')

def exhaustive():
 out=[];count=orbits=0
 for n in (2,3,4):
  N=1<<n;coords=coordinate_masks(n);representatives=[]
  for P in range(1,1<<N):
   count+=1
   if canonical(P,n,coords)==P:representatives.append(P)
  orbits+=len(representatives);print('EXHAUSTIVE',n,'packets',(1<<N)-1,'xor_orbits',len(representatives),flush=True)
  for k in range(1,n+1):
   for d in (0,2,1):
    best={key:None for key in ('avg_lower','avg_upper','fixed_lower','fixed_upper')}
    for P in representatives:
     s=score(P,n,k,d)
     for key in best:
      val=s[key];best[key]=optimum_update(best[key],val.numerator,val.denominator,P,s['vertex'] if key.startswith('fixed') else None)
    al,au,fl,fu=(best[key] for key in ('avg_lower','avg_upper','fixed_lower','fixed_upper'))
    avglo=Q(al['num'],al['den']);avghi=Q(au['num'],au['den']);fixlo=Q(fl['num'],fl['den']);fixhi=Q(fu['num'],fu['den'])
    assert avglo<=avghi and fixlo<=fixhi and avglo<=fixhi
    out.append(dict(n=n,k=k,t=Q(0) if not d else Q(1,d),t_labels=['0'] if not d else (['1/2','1/ceil_sqrt_n'] if d==2 else ['1']),packet_enumeration=(1<<N)-1,xor_orbits=len(representatives),Bavg_interval=[avglo,avghi],fixed_interval=[fixlo,fixhi],Bavg_best_packet=al['P'],Bavg_best_size=al['P'].bit_count(),fixed_best_packet=fl['P'],fixed_best_size=fl['P'].bit_count(),fixed_best_vertex=fl['vertex'],avg_orbit_certificate=orbit_certificate(al['P'],n,avglo),fixed_orbit_certificate=orbit_certificate(fl['P'],n,fixlo,fl['vertex']),avg_uniform_dual_price_per_site=avghi/N,fixed_uniform_dual_price_per_site=fixhi/N,avg_upper_enumeration_packet=au['P'],fixed_upper_enumeration_packet=fu['P'],scope='Complete packet optimum, exact integer-root enclosure; arbitrary fixed representatives dominated by vertices on the actual query boxes.'))
 return out,dict(all_nonempty_packets=count,xor_orbits_evaluated=orbits,optimization_cases=len(out))

@lru_cache(None)
def subcube_score(n,k,j,d):
 """Exact hypergeometric subcube density. t=0 or 1/d."""
 # Sum 2^(-k-j*t) E[2^(r*(1+t))] without positive-root overflow.
 # Per overlap term =2^(r-k) * (2^(r-j))^t.
 lo=hi=Q(0)
 for r in range(max(0,k-(n-j)),min(k,j)+1):
  prob=Q(math.comb(j,r)*math.comb(n-j,k-r),math.comb(n,k));a,b=root_bounds(1,1<<(j-r),d)
  factor=prob*Q(2)**(r-k)
  lo+=factor*Q(a,GRID);hi+=factor*Q(b,GRID)
 return lo,hi

def structures(n,k,d):
 vals=[subcube_score(n,k,j,d) for j in range(n+1)];j=max(range(n+1),key=lambda j:vals[j][0])
 return dict(n=n,k=k,t=Q(0) if not d else Q(1,d),best_codimension=j,best_interval=list(vals[j]),all_codimension_intervals=vals,scope='Certified achieved XOR-subcube lower bound; upper endpoint encloses this candidate score, NOT the all-packet optimum.')

def sampled_packets(n,seed=771000):
 rng=random.Random(seed+n);N=1<<n;full=(1<<N)-1;packets={full:'whole',1:'singleton'}
 for j in range(1,n+1):packets[sum(1<<v for v in range(N) if v&((1<<j)-1)==0)]='subcube_codim_'+str(j)
 packets[sum(1<<v for v in range(N) if v.bit_count()%2==0)]='even_parity'
 for radius in range(1,n//2+1):packets[sum(1<<v for v in range(N) if v.bit_count()<=radius)]='hamming_ball_'+str(radius)
 for denom in (2,4,8,16):
  for j in range(4):
   P=sum(1<<v for v in range(N) if rng.randrange(denom)==0)
   if P:packets[P]='random_density_1/'+str(denom)+'_draw_'+str(j)
 return list(packets.items())

def pressure():
 out=[];struct=[];counts=dict(finite_candidate_cases=0,structured_cases=0)
 for n in (8,12):
  packets=sampled_packets(n);ks=(1,2,4,8) if n==8 else (1,2,3,12)
  print('PRESSURE',n,'candidates',len(packets),flush=True)
  for k in ks:
   for d in dict.fromkeys((0,2,1,math.isqrt(n-1)+1)):
    candidates=[]
    for P,label in packets:
     if k==n:s=score(P,n,k,d)
     else:
      # Average pricing only for large explicit packets; no fixed all-vertex optimization.
      query=queries(n,k);N=1<<n;m=P.bit_count();f=1<<(n-k);hist={}
      for a,_,_ in query:c=(P&a).bit_count();hist[c]=hist.get(c,0)+1
      lo=hi=0
      for c,num in hist.items():
       a,b=root_bounds(c,f,d);lo+=num*c*c*a;hi+=num*c*c*b
      s=dict(avg_lower=Q(N*lo,f*m*m*len(query)*GRID),avg_upper=Q(N*hi,f*m*m*len(query)*GRID))
     candidates.append(dict(label=label,packet_hex=hex(P),packet_size=P.bit_count(),achieved_interval=[s['avg_lower'],s['avg_upper']]))
    best=max(candidates,key=lambda v:v['achieved_interval'][0]);counts['finite_candidate_cases']+=len(candidates)
    out.append(dict(n=n,k=k,t=Q(0) if not d else Q(1,d),seed=771000+n,candidates=candidates,best_achieved=best,scope='Explicit packet XOR-orbit lower bounds only; candidate interval upper endpoints are not global upper bounds.'))
 for n in (8,12,16,32,64):
  for k in sorted(set((1,max(1,n//4),n//2,n))):
   for d in sorted(set((0,2,1,math.isqrt(n-1)+1))):struct.append(structures(n,k,d));counts['structured_cases']+=1
 return out,struct,counts

def main():
 start=time.monotonic();guard=geometry_guard();small,sc=exhaustive();large,struct,lc=pressure()
 data=dict(status='PASS',root_grid=GRID,query_formula='E[(a/F)^(1+t)*(a/p)]',capacity_optimum_formula='max_packet score(packet)/p by XOR translations alpha=1/|P|',geometry_guard=guard,exhaustive_counts=sc,exhaustive=small,pressure_counts=lc,pressure=large,subcube_family=struct,scope='Complete small-n packet intervals; larger-n achieved lower bounds only; actual-band query subevents, not full band coverage theorem.')
 path=Path(__file__).with_name('reveal_results.json');path.write_text(json.dumps(clean(data),sort_keys=True,separators=(',',':'))+'\n');print('PASS',json.dumps(sc),json.dumps(lc),'elapsed',time.monotonic()-start,'sha256',hashlib.sha256(path.read_bytes()).hexdigest())
if __name__=='__main__':main()
