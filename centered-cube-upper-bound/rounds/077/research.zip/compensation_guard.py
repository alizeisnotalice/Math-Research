#!/usr/bin/env python3
"""R77 exact latent algebra and rational finite-window fee guards.

The endpoint Bernoulli mask coefficients are the actual coefficients. Soft
noise in stage 2 is an explicitly declared rational discrete surrogate, not
the E2 density w or an actual phi integral. Large dimensions use implicit
formulas and elementary proved inequalities; 2**n masks are not enumerated.
"""
from fractions import Fraction as F
from pathlib import Path
from itertools import product
from functools import lru_cache
import json, math, random, time

SEED=770611
LOG_TERMS=30


def clean(x):
    if isinstance(x,F): return str(x)
    if isinstance(x,dict): return {str(k):clean(v) for k,v in x.items()}
    if isinstance(x,(tuple,list)): return [clean(v) for v in x]
    return x


def log_two_interval():
    z=F(1,3); p=z; total=F(0)
    for j in range(LOG_TERMS): total+=2*p/(2*j+1); p*=z*z
    tail=2*p/((2*LOG_TERMS+1)*(1-z*z))
    return total,total+tail


def exp_interval(x,terms=30):
    """Positive Taylor partial sum with geometric upper tail; x rational."""
    x=F(x); assert 0<=x<terms+2
    total=term=F(1)
    for j in range(1,terms+1): term*=x/j; total+=term
    first=term*x/(terms+1)
    return total,total+first/(1-x/F(terms+2))


LN2=log_two_interval()
EXP34=exp_interval(F(3,4))
EXP32=exp_interval(F(3,2))
assert EXP34[1]<F(9,4) and EXP32[0]>4


@lru_cache(None)
def masks(n,delta):
    delta=F(delta); ans=[]
    for mask in range(1<<n):
        k=mask.bit_count()
        alpha=(delta/2)**k*(1-delta/2)**(n-k)
        beta=delta**k*(1-delta)**(n-k)
        q=(alpha+beta)/2; diff=alpha-beta
        j=diff*diff/q if q else F(0)
        assert q>=0 and j>=0 and abs(diff)<=2*q and j<=4*q
        ans.append((mask,k,alpha,beta,q,diff,j))
    assert sum(z[2] for z in ans)==sum(z[3] for z in ans)==sum(z[4] for z in ans)==1
    assert sum(z[5] for z in ans)==0
    return tuple(ans)


def mass_record(n,delta,e):
    delta,e=F(delta),F(e); assert 0<=delta<=1 and 0<=e<=1
    mm=masks(n,delta)
    a=sum(alpha*(1-e)**k for _,k,alpha,_,_,_,_ in mm)
    b=sum(beta*(1-e)**k for _,k,_,beta,_,_,_ in mm)
    K=sum(q*(1-e)**k for _,k,_,_,q,_,_ in mm)
    J=sum(j*(1-e)**k for _,k,_,_,_,_,j in mm)
    d=sum(diff*(1-e)**k for _,k,_,_,_,diff,_ in mm)
    assert a==(1-delta*e/2)**n and b==(1-delta*e)**n
    assert d==a-b and 0<=d<=n*delta*e/2
    K0=K+d/2; J0=J+2*d
    assert K0==a<=1
    assert J<=4*K and J0<=4*K0
    assert d-d==0
    Ktail=1-K
    DtailTV=sum(abs(diff)*(1-(1-e)**k) for _,k,_,_,_,diff,_ in mm)
    assert Ktail<=F(3,4)*n*delta*e
    assert DtailTV<=2*Ktail
    assert DtailTV+d<=2*n*delta*e
    return dict(n=n,delta=delta,e_surrogate=e,mask_count=1<<n,
                endpoint_core_masses=[a,b],signed_core_mass=d,
                signed_core_mass_formula='(1-delta*e/2)^n-(1-delta*e)^n',
                mass_defect_bound=n*delta*e/2,
                K_core_mass=K,J_core_mass=J,K_compensated_mass=K0,J_compensated_mass=J0,
                compensated_signed_mass=F(0),new_channel_q=d/2,new_channel_zeta=F(-2),
                K_tail_mass=Ktail,D_tail_total_variation=DtailTV,
                full_vs_compensated_total_variation_bound=DtailTV+d,
                universal_TV_bound=2*n*delta*e,
                K0_mass_equals_alpha_core_mass=True,exact_bounds_verified=True)


def stage1():
    records=[]; scale_sums=[]
    for n in range(1,9):
        for s in range(7):
            delta=F(1,2**s)
            for e in (F(0),F(1,64),F(1,8),F(1,2),F(1)):
                records.append(mass_record(n,delta,e))
        finite=sum(F(1,2**s) for s in range(7)); tail=F(1,2**6)
        assert finite==2-tail and finite+tail==2
        scale_sums.append(dict(n=n,levels_explicitly_tested=7,finite_delta_sum=finite,
                               infinite_remaining_delta_sum=tail,infinite_total_delta_sum=F(2)))
    return dict(status='VERIFIED',scope='Exact Bernoulli-mask algebra for rational tail-mass surrogates; n1..8 all masks enumerated.',
                records=records,finite_scale_sums=scale_sums,
                case_count=len(records),mask_instances=sum(r['mask_count'] for r in records))


def H(v): return F(int(all(abs(t)<=F(1,2) for t in v)))


def coordinate_soft(v,e,full=False):
    core=sum(weight*int(abs(v-z)<=F(1,2)) for z,weight in ((F(-1,4),F(1,4)),(F(0),F(1,2)),(F(1,4),F(1,4))))
    value=(1-e)*core
    if full: value+=e*sum(F(1,2)*int(abs(v-z)<=F(1,2)) for z in (F(-2),F(2)))
    return value


def density_triplet(n,delta,e,v,full=False):
    hard=[F(int(abs(z)<=F(1,2))) for z in v]
    soft=[coordinate_soft(z,e,full) for z in v]
    K=J=D=F(0)
    for mask,_,_,_,q,diff,j in masks(n,delta):
        factor=math.prod(soft[i] if mask>>i&1 else hard[i] for i in range(n))
        K+=q*factor; J+=j*factor; D+=diff*factor
    assert D*D<=K*J and J<=4*K
    return K,J,D


def density_case(n,delta,e,seed):
    rng=random.Random(seed); delta,e=F(delta),F(e)
    yy=[tuple(F(rng.randrange(-6,7),8) for _ in range(n)) for _ in range(3)]
    weights=[F(1,5),F(3,10),F(1,2)]
    signs=[F(-1),F(1,3),F(1)]
    receivers=[tuple(F(rng.randrange(-16,17),8) for _ in range(n)) for _ in range(16)]
    receivers+=yy+[tuple(F(0) for _ in range(n))]
    d=(1-delta*e/2)**n-(1-delta*e)**n
    rows=[]; min_core_margin=None; min_corrected_margin=None; nonzero=0; signed_negative=0
    for rid,x in enumerate(receivers):
        # One common receiver scale; no separate selector for the positive pair.
        L=(F(1),F(3,2),F(2))[rid%3]
        K=J=D=Kfull=Jfull=Dfull=Hmu=Hnu=F(0)
        for y,w,sign in zip(yy,weights,signs):
            v=tuple((xx-zz)/L for xx,zz in zip(x,y)); h=H(v)/L**n
            k,j,t=density_triplet(n,delta,e,v)
            kf,jf,tf=density_triplet(n,delta,e,v,True)
            K+=w*k/L**n; J+=w*j/L**n; D+=w*sign*t/L**n
            Kfull+=w*kf/L**n; Jfull+=w*jf/L**n; Dfull+=w*sign*tf/L**n
            Hmu+=w*h; Hnu+=w*sign*h
        K0=K+d*Hmu/2; J0=J+2*d*Hmu; D0=D-d*Hnu
        assert D*D<=K*J and J<=4*K
        assert D0*D0<=K0*J0 and J0<=4*K0
        assert Dfull*Dfull<=Kfull*Jfull
        assert abs(Dfull-D0)<=abs(Dfull-D)+d*abs(Hnu)
        # Direct appended-channel equality, rather than a hidden renormalization.
        assert D0==D+(-2)*(d/2)*Hnu and J0==J+(-2)**2*(d/2)*Hmu
        core_margin=K*J-D*D; corr_margin=K0*J0-D0*D0
        min_core_margin=core_margin if min_core_margin is None else min(min_core_margin,core_margin)
        min_corrected_margin=corr_margin if min_corrected_margin is None else min(min_corrected_margin,corr_margin)
        nonzero+=int(K0>0); signed_negative+=int(D0<0)
        rows.append(dict(x=x,L=L,K_core=K,J_core=J,D_core_signed=D,
                         H_mu=Hmu,H_nu_signed=Hnu,K0=K0,J0=J0,D0_signed=D0,
                         D_full_surrogate_signed=Dfull,core_Cauchy_residual=core_margin,
                         corrected_Cauchy_residual=corr_margin,corrected_J_le_4K_residual=4*K0-J0))
    selected=[0]
    for predicate in (lambda r:r['corrected_Cauchy_residual']>0,lambda r:r['D0_signed']<0):
        index=next((i for i,row in enumerate(rows) if predicate(row)),None)
        if index is not None and index not in selected: selected.append(index)
    return dict(n=n,delta=delta,e_surrogate=e,seed=seed,source_positions=yy,
                source_mu=weights,source_nu=[w*sign for w,sign in zip(weights,signs)],
                source_mass=F(1),receiver_count=len(rows),signed_core_mass=d,
                core_soft_law='(1-e)*(delta_-1/4/4 + delta_0/2 + delta_1/4/4)',
                full_soft_law='core + e*(delta_-2/2 + delta_2/2)',
                surrogate_cutoff='Any R with 1/4 <= R < 2 retains exactly the core soft law.',
                nonzero_corrected_rows=nonzero,negative_corrected_signed_rows=signed_negative,
                minimum_core_Cauchy_residual=min_core_margin,minimum_corrected_Cauchy_residual=min_corrected_margin,
                appended_channel_exactly_verified=True,compensated_signed_kernel_integral=F(0),
                saved_witness_indices=selected,saved_witness_rows=[rows[i] for i in selected],
                receiver_replay='Random(seed): draw three n-vectors randrange(-6,7)/8, then sixteen n-vectors randrange(-16,17)/8, append source positions and zero; scales (1,3/2,2) cyclic.')


def stage2():
    cases=[]
    for n in (1,2,3,4):
        for didx,delta in enumerate((F(1),F(1,2),F(1,8))):
            for eidx,e in enumerate((F(0),F(1,8),F(1,2),F(1))):
                cases.append(density_case(n,delta,e,SEED+n*100+didx*10+eidx))
    assert sum(c['nonzero_corrected_rows'] for c in cases)>0
    assert sum(c['negative_corrected_signed_rows'] for c in cases)>0
    return dict(status='VERIFIED',scope='Exact signed-source convolutions of rational discrete noise surrogates and the actual endpoint mask coefficients. No numerical w or phi integral.',
                cases=cases,case_count=len(cases),receiver_rows=sum(c['receiver_count'] for c in cases))


def stage3():
    models=[]; S=12
    delta_sum=sum(F(1,2**s) for s in range(S)); tail=F(1,2**(S-1))
    assert delta_sum+tail==2
    for n in (1,2,8,16,64,256,1024,4096,16384):
        Qlo=n*(1+n*LN2[0]); Qhi=n*(1+n*LN2[1])
        Hlo,Hhi=1+n*LN2[0],1+n*LN2[1]
        for b in (F(1),F(1,2),F(1,8),F(1,64)):
            # Actual advertised R implies e^-R <= v by e^(3/2)>=4.
            # Q_actual>=Qlo. sqrt(v)=b/(8Qlo) is rational exactly.
            v=b*b/(64*Qlo*Qlo)
            sqrtv=b/(8*Qlo); assert sqrtv*sqrtv==v and 0<v<=1
            tail_per_delta=2*Qhi*F(9,4)*sqrtv
            compensation_per_delta=Qhi*v/2
            combined=tail_per_delta+compensation_per_delta
            assert combined<=b
            fees=[]
            for s in range(S):
                delta=F(1,2**s)
                d_bound=n*delta*v/2
                comp_bound=d_bound*Hhi
                assert comp_bound==delta*compensation_per_delta
                layer=delta*combined; assert layer<=delta*b
                fees.append(dict(s=s,delta=delta,mass_defect_upper=d_bound,
                                 tail_fee_upper=delta*tail_per_delta,compensation_fee_upper=comp_bound,
                                 combined_fee_upper=layer,target_fee=delta*b))
            finite_fee=delta_sum*combined; remainder_fee=tail*combined
            assert finite_fee+remainder_fee==2*combined<=2*b
            models.append(dict(n=n,b_equals_exp_minus_a_surrogate=b,
                               Q_interval=[Qlo,Qhi],finite_window_max_H_integral_interval=[Hlo,Hhi],
                               advertised_R='3/2 + 2*log(4*Q_actual) + 2*a',
                               v_upper_for_exp_minus_R=v,sqrt_v_upper=sqrtv,
                               v_reason='exp(3/2)>=4, exp(-2a)=b^2, Q_actual>=Q_lower',
                               actual_tail_mass_upper='e_R <= exp(-R) <= v',
                               dimension_representation='Implicit product/mass formula only; no 2**n masks enumerated in this stage.',
                               d_implicit_formula='(1-delta*e_R/2)^n-(1-delta*e_R)^n',
                               d_used_bound='0 <= d <= n*delta*e_R/2 <= n*delta*v/2',
                               fee_normalization='W=1; all fees multiply linearly by arbitrary source mass W',
                               checked_scale_level_count=S,saved_first_last_layers=[fees[0],fees[-1]],
                               all_layers_replay_formula='delta_s=2^-s; tail=delta_s*tail_per_delta; compensation=delta_s*Q_upper*v/2; s=0..11',
                               tail_fee_per_delta_upper=tail_per_delta,compensation_fee_per_delta_upper=compensation_per_delta,
                               per_delta_combined_fee_upper=combined,target_per_delta_fee=b,
                               finite_delta_sum=delta_sum,infinite_remaining_delta_sum=tail,
                               finite_combined_fee_upper=finite_fee,infinite_remaining_fee_upper=remainder_fee,
                               all_scale_combined_fee_upper=2*combined,all_scale_target_fee=2*b,
                               exact_fee_inequality_verified=True))
    return dict(status='VERIFIED',scope='Rational deterministic consequences of the advertised R and analytic finite-window/tail premises. Not a measured actual-phi tail integral.',
                ln2_interval=LN2,log_terms=LOG_TERMS,
                exp_3_over_4_interval=EXP34,exp_3_over_4_upper_used=F(9,4),
                exp_3_over_2_interval=EXP32,exp_3_over_2_lower_used=F(4),
                models=models,model_count=len(models),explicit_scale_levels=S,
                fee_premises=['Tail fee <= 2 Q delta exp(3/4-R/2) W.',
                              'Compensation fee <= d*(1+n log 2) W.',
                              'e_R <= exp(-R).'],
                large_dimension_not_enumerated=True)


def high_background_budget_guard():
    """Threshold allocation only: the parent proves the actual event payment.

    K0 has mass alpha_retained<=1, so its finite-window positive envelope has
    integral at most (1+n log2)W. No sampled event is substituted for that
    analytic premise here. Square dimensions make sqrt(n) exact rational.
    """
    stages=[]
    for m in (2,8,64):
        records=[]
        for n in (1,16,256,16384):
            root=math.isqrt(n); assert root*root==n
            weights=[F(1,(s+1)*(s+2)) for s in range(m)]
            thresholds=[F(root)/(w*w) for w in weights]
            coefficients=[F(1)/(h*w) for h,w in zip(thresholds,weights)]
            assert all(c==w/root for c,w in zip(coefficients,weights))
            partial=sum(weights); tail=F(1,m+1)
            assert partial==F(m,m+1) and partial+tail==1
            coefficient_sum=sum(coefficients)
            assert coefficient_sum==partial/root
            coefficient_tail=tail/root
            assert coefficient_sum+coefficient_tail==F(1,root)
            # lambda cancels exactly in lambda/(H_s * lambda_s).
            for lam in (F(1,4),F(1),F(7)):
                assert all(lam/(h*lam*w)==c for h,w,c in zip(thresholds,weights,coefficients))
            envelope=(1+n*LN2[0],1+n*LN2[1])
            whole_budget=(envelope[0]/root,envelope[1]/root)
            finite_budget=(partial*envelope[0]/root,partial*envelope[1]/root)
            tail_budget=(tail*envelope[0]/root,tail*envelope[1]/root)
            assert all(f+t==a for f,t,a in zip(finite_budget,tail_budget,whole_budget))
            records.append(dict(n=n,sqrt_n=root,explicit_layer_count=m,
                                weight_formula='w_s=1/((s+1)(s+2)); s=0..m-1',
                                threshold_formula='H_s=sqrt(n)/w_s^2; lambda_s=lambda*w_s',
                                event_definition='Ehigh_s subset {F_s > H_s*lambda_s}',
                                first_last_layers=[dict(s=s,w=weights[s],H=thresholds[s],
                                   payment_coefficient=coefficients[s]) for s in (0,m-1)],
                                exact_weight_partial_sum=partial,exact_weight_tail=tail,
                                exact_payment_coefficient_partial_sum=coefficient_sum,
                                exact_payment_coefficient_tail=coefficient_tail,
                                exact_all_layer_payment_coefficient=F(1,root),
                                lambda_cancellation_cases=3,
                                positive_envelope_mass_interval=envelope,
                                finite_high_background_budget_interval=finite_budget,
                                remaining_high_background_budget_interval=tail_budget,
                                all_layer_high_background_budget_interval=whole_budget,
                                budget_normalization='W=1; multiply by arbitrary W',
                                union_budget_formula='lambda*|union_s Ehigh_s| <= ((1+n log2)/sqrt(n))*W',
                                exact_allocation_identities_verified=True))
        stages.append(dict(explicit_layer_count=m,models=records,status='VERIFIED'))
    return dict(status='VERIFIED',scope='Exact threshold-allocation algebra and rational log2 enclosure only, conditional on the analytic positive-envelope payment. No actual event sampling certificate.',
                critical_kernel_mass_identity='integral K_R^0 = alpha_retained = (1-delta*e_R/2)^n <= 1',
                positive_envelope_premise='integral max_{1<=L<=2} mu*(K_R^0)_L <= (1+n log2)*W',
                infinite_weight_sum=F(1),stages=stages,model_count=12,
                checked_explicit_layer_instances=sum(stage['explicit_layer_count']*len(stage['models']) for stage in stages))


def main():
    start=time.monotonic(); first=stage1()
    print('stage1 cases',first['case_count'],'mask_instances',first['mask_instances'],'seconds',round(time.monotonic()-start,3),flush=True)
    second=stage2()
    print('stage2 cases',second['case_count'],'receiver_rows',second['receiver_rows'],'seconds',round(time.monotonic()-start,3),flush=True)
    third=stage3(); high_background=high_background_budget_guard()
    out=dict(status='VERIFIED',seed=SEED,dependencies='Python standard library only',
             arithmetic='Exact Fraction, rational Taylor/atanh remainder enclosures; no floating certificate.',
             stage1=first,stage2=second,stage3=third,high_background_budget_guard=high_background,
             counts=dict(exact_mass_cases=first['case_count'],explicit_mask_instances=first['mask_instances'],
                         signed_density_cases=second['case_count'],signed_density_receiver_rows=second['receiver_rows'],
                         implicit_fee_models=third['model_count'],implicit_fee_layers=third['model_count']*third['explicit_scale_levels'],
                         exact_high_background_budget_models=high_background['model_count'],
                         exact_high_background_layer_instances=high_background['checked_explicit_layer_instances']),
             limitations=['Stage2 soft noise is a rational discrete surrogate, not actual E2 w or phi.',
                          'Stage3 uses the stated analytic tail and finite-window premises; it does not numerically certify their actual-kernel integrals.',
                          'No full-band coverage or general dimension-uniform cube bound is asserted.'])
    target=Path(__file__).with_name('compensation_results.json')
    target.write_text(json.dumps(clean(out),indent=2,sort_keys=True)+'\n')
    print('DONE',out['counts'],'seconds',round(time.monotonic()-start,3),'bytes',target.stat().st_size,flush=True)


if __name__=='__main__': main()
