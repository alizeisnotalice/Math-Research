#!/usr/bin/env python3
"""Bounded single-parent high-p integral bridge checks, no geometry/LP/OT."""
import argparse, hashlib, itertools, json, math, platform, resource, shlex, sys, time
from fractions import Fraction as F
from pathlib import Path
import sympy as sp
import flint
from flint import arb,ctx

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=Path(__file__).with_suffix('.json'));args=ap.parse_args()
 start=time.perf_counter();ctx.prec=512
 u,t,c=sp.symbols('u t c',real=True);symbolic=[];exact_checks=0
 for p in (2,4,8):
  target=(1+(2*t-1)**(p+1))/(2*(p+1)*t)
  lower=sp.integrate(u**p,(u,1-2*t,1))/(2*t)
  upper=(sp.integrate((-u)**p,(u,1-2*t,0))+sp.integrate(u**p,(u,0,1)))/(2*t)
  assert sp.simplify(lower-target)==sp.simplify(upper-target)==0
  avg=sp.integrate((u-c)**p,(u,-t,t))/(2*t)
  convex=sp.Poly(sp.expand(sp.diff(avg,c,2)),t,c)
  assert all(coef>=0 for _,coef in convex.terms())
  endpoint=sp.simplify(avg.subs(c,1-t)-target);assert endpoint==0
  symbolic.append({'p':p,'t_le_half_residual':'0','t_ge_half_residual':'0','endpoint_residual':'0','second_derivative_monomials':[[list(m),str(co)] for m,co in convex.terms()], 'convexity_domain':'t>=0; all c powers even, coefficients nonnegative'})
  for tt in map(F,('1/1024','1/4','1/2','3/4','1')):
   for frac in (F(0),F(1,2),F(1)):
    cv=(1-tt)*frac
    val=F(avg.subs({t:sp.Rational(tt.numerator,tt.denominator),c:sp.Rational(cv.numerator,cv.denominator)}))
    end=(1+(2*tt-1)**(p+1))/(2*(p+1)*tt)
    assert val<=end;exact_checks+=1
 # Product-union inequality certificate in independent success t and failure q variables.
 # On q_i=1-t_i: 1+(n-1)prod(t)-sum_i prod_(j!=i)t_j
 # = sum_{|B|>=2} prod_(i in B)q_i prod_(i notin B)t_i.
 product_ids=[]
 for n in (2,3,4):
  ts=sp.symbols('t0:'+str(n));beta=sp.prod(ts)
  rhs=sum(sp.prod(1-ts[i] if i in B else ts[i] for i in range(n)) for k in range(2,n+1) for B in itertools.combinations(range(n),k))
  assert sp.expand(1+(n-1)*beta-sum(sp.prod(ts[j] for j in range(n) if j!=i) for i in range(n))-rhs)==0
  product_ids.append({'n':n,'residual':'0','nonnegative_subset_terms':2**n-n-1})
 exact_multi=0
 for n in (2,3,4,8):
  for p in (2,4,8):
   for widths in ([F(1)]*n,[F(1,1024)]+[F(1)]*(n-1),[F(1,1024)]*(n//2)+[F(1)]*(n-n//2),[F(3,4)]*n):
    beta=math.prod(widths);lhs=beta*sum((1+(2*x-1)**(p+1))/(2*(p+1)*x) for x in widths)
    assert lhs<=(1+(n-1)*beta)/(p+1);exact_multi+=1
 def af(x):x=F(x);return arb(x.numerator)/x.denominator
 def ball(x):return {'Arb512':x.str(65),'radius':x.rad().str(12)}
 def calc(n,p,label,groups):
  beta=arb(1);summ=arb(0)
  for labelt,tt,count in groups:
   assert tt>0 and (labelt=='1' or tt<1)
   beta*=tt**count
   if labelt=='1':fp=arb(1)/(p+1)
   else:fp=(1+(2*tt-1)**(p+1))/(2*(p+1)*tt)
   summ+=count*fp
  lhs=beta*summ;rhs=(1+(n-1)*beta)/(p+1);gap=rhs-lhs
  equality=label=='all_one'
  if equality:assert (lhs-rhs).contains(0)
  else:assert gap>0
  return {'pattern':label,'groups':[{'t':a,'multiplicity':k,'value':ball(v)} for a,v,k in groups], 'beta':ball(beta),'lhs':ball(lhs),'rhs':ball(rhs),'gap':ball(gap),'certificate':'symbolic equality (t_j=1)' if equality else 'strictly positive Arb512 gap'}
 cases=[]
 for n in (2,3,4,8,16,64,256,1024,65536):
  q=2*n
  threshold=arb(n)*arb(q).log()/af(F(5,4)).log()
  h=(threshold/2).floor().unique_fmpz();assert h is not None
  p=2*(int(h)+1);assert p>=2 and p%2==0
  drift=af(F(5,4)).log()-arb(n)*arb(q).log()/p
  previous=arb(n)*arb(q).log()/(p-2)-af(F(5,4)).log() if p>2 else arb(1)
  assert drift>0 and previous>0
  bal=(-arb(n).log()/(2*n)).exp()
  uneven=arb(n).sqrt()**(-1)
  patterns=[('all_one',[('1',arb(1),n)]),('balanced_half',[('1/2',af(F(1,2)),n)]),('one_extreme_thin',[('1/1048576',af(F(1,1048576)),1),('1',arb(1),n-1)]),('multiple_thin',[('1/1024',af(F(1,1024)),n//2),('1',arb(1),n-n//2)]),('beta_n_minus_half_balanced',[('n^(-1/(2n))',bal,n)]),('beta_n_minus_half_unbalanced',[('n^(-1/2)',uneven,1),('1',arb(1),n-1)])]
  cases.append({'n':n,'q':q,'p_min_even':p,'p_threshold':ball(threshold),'log_kappa_power_n_upper_guard':ball(drift),'previous_even_failure_guard':ball(previous),'kappa_power_n':ball((arb(n)*arb(q).log()/p).exp()),'patterns':[calc(n,p,name,groups) for name,groups in patterns]})
 data={'scope':'Dimension-only q=2n calibration, not an input-adaptive p certificate based on A,B,J. Single actual-parent integral bridge only. No global bound: sum of parent masses M, joint source reuse, coupling return, and full-family selection remain unpaid.',
 'definitions':{'t':'carrier width/r =1-bbox source spread/r in (0,1]','beta':'product t_j','normalized_coordinate':'u=2(x-z_j)/r','f_even_p':'[1+(2t-1)^(p+1)]/[2(p+1)t]','source_condition':'each actual source coordinate lies in bbox; convexity makes endpoint source location maximal','bridge':'lambda integral_CN cp/(r/2)^p <= M beta sum_j f_p(t_j) <= M[1+(n-1)beta]/(p+1)'},
 'proof_boundary':{'first_inequality':'coordinate integral convex in source displacement; verified polynomial second derivative for p=2,4,8; general convexity is analytic, not inferred from finite checks','second_inequality':'(p+1)f_p(t)<=1/t since (2t-1)^(p+1)<=1; beta sum 1/t<=1+(n-1)beta by nonnegative subset expansion; formula shown for n=2,3,4 only by symbolic checks','t_zero':'not numerically included; degenerate carrier has zero Lebesgue volume and is handled separately, no division by zero','high_p':'all interval input roots/logs evaluated with Arb512; no machine-float comparison used as certificate'},
 'symbolic_integrals':symbolic,'finite_endpoint_checks':exact_checks,'symbolic_product_identities':product_ids,'finite_multidimensional_fraction_checks':exact_multi,'cases':cases,
 'counts':{'dimensions':len(cases),'compressed_patterns':sum(len(x['patterns']) for x in cases),'strict_interval_patterns':45,'symbolic_equalities':9},
 'execution':{'interpreter':sys.executable,'python':platform.python_version(),'sympy':sp.__version__,'python_flint':flint.__version__,'precision_bits':ctx.prec,'command':shlex.join([sys.executable,str(Path(__file__).resolve()),*sys.argv[1:]]),'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'runtime_seconds':time.perf_counter()-start,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss},'all_assertions_passed':True}
 args.output.write_text(json.dumps(data,ensure_ascii=False,sort_keys=True,indent=2)+'\n');print(json.dumps({'dimensions':len(cases),'patterns':54,'runtime_seconds':data['execution']['runtime_seconds'],'peak_rss_bytes':data['execution']['peak_rss_bytes'],'p':[x['p_min_even'] for x in cases],'all_assertions_passed':True}))
if __name__=='__main__':main()
