# R313 — exact capture quotas, radius atoms, and the remaining geometric budget

## 1. Scope and conclusion

This note does NOT prove a new root bound for B_H. The attempted positive-innovation estimate is explicitly discarded because the exact original clipped capacity gives a stronger inequality. The useful conclusion is an atom-correct, source-preserving target that is strictly less expensive than paying all variance innovations. It explains precisely what geometric estimate is still missing, instead of charging an artificial positive variance increment after its capture quota is exhausted.

Keep all definitions and assumptions of `/tmp/r313_input_302.md`: actual U_y(x)=alpha(x,y)1_E(x)P_(s(x),L(x))(x-y)/q(x), full original beta,nu, actual FIRST integral U_y(x)beta(dy)<=1, original same-receiver cap nu(Q_(R(x))(x))<=4lambda R(x)^n, a<=L,R<=b<=2a and q>=q_-. No new source density, virtual receiver cap or higher-softness FIRST is assumed. Alpha is z-independent and retains its original full e_g,low-pe,m and aspect qualifications. All originally required outer costs remain fixed.

The existing bridge is

    T_target<=2 O_d,
    O_d=integral beta(dy)nu(dz)ell_n(dr) min(d,A_yz(r)),
    A_yz(r)=integral_{R(x)<=r} U_y(x)c_x(z)dx,
    c_x(z)=1{z in Q_(R(x))(x)},
    J_y(r)=integral_{R(x)<=r}U_y(x)dx,
    ell_n(dr)=b^(-n)delta_b(dr)+n r^(-n-1)1_(a,b)dr,
    d=kappa0 psi_inf/(q_-v0),
    kappa0=2K/(ell M), psi_inf=3-2/(3gamma^n).         (1)

The statement proved below is, for every H>0,

    O_d=O_before(H)+N_(H,d),
    O_before(H)<=4lambda H W_beta,
    T_target<=8lambda H W_beta+2N_(H,d).              (2)

N_(H,d) is an explicitly specified positive first-d capture flux, not B_H renamed: it involves only captures whose released cumulative row mass is >=H and whose released cumulative captured mass is still <d. The equality and price include every radius atom. At each nonzero such flux the capture fraction is <d/H. Its full definition is in section 2. N is an auxiliary allocation of O_d constructed from the original incidence; it is NOT asserted to be a disjoint positive allocation of T_target, whose entry is only the inequality T_target<=2O_d.

Formula (2) already follows from the information in the original clipped capacity; it is NOT advertised as a new general geometric root theorem. Its main relevance is that the global bound need not pay variance generated after the first d captures. The unresolved source geometry is a bound on the remaining first-d captures. The proof of (2) alone does not provide that bound.

## 2. One common refinement of each actual radius atom

For a fixed y, push U_y(x)dx forward by its actual R(x), giving a finite positive measure mu_y on [a,b]. Write

    h_y(r)=mu_y({r}), J_y(r-)=mu_y([a,r)),
    a_yz(r)=integral_{R(x)=r}U_y(x)c_x(z)dx,
    A_yz(r-)=integral_{R(x)<r}U_y(x)c_x(z)dx.

At an atom h_y(r)>0, release a fraction theta in [0,1] of the ENTIRE actual receiver block at that radius:

    J_y(r,theta)=J_y(r-)+theta h_y(r),
    A_yz(r,theta)=A_yz(r-)+theta a_yz(r).              (3)

The same theta is used for every z in that block. Its capture increment is a_yz(r)dtheta; this is shorthand for integral_{R(x)=r}U_y(x)c_x(z)dx dtheta. It neither introduces a new cube nor asserts a cap at an averaged center. The physical radius weight is the actual r^(-n) throughout the block. At non-atoms use the continuous Stieltjes increments dA_yz(r), with inclusive CDF A_yz(r)=A_yz(r-) almost everywhere for that continuous measure. Denote the resulting ordered capture increment by dA_yz^o and the corresponding cumulative values by A_yz^o,J_y^o. The order is increasing physical radius, then theta only within a radius atom.

The notation is measurable: r->h_y(r) and a_yz(r) are the differences of the measurable inclusive and left-limit CDFs. Their atomic integrals can be written using the measurable kernels above and an extra [0,1] integral, while the continuous part is the CDF Stieltjes measure minus its atoms. Positive kernel integration or finite approximations give the same construction. No ordering chosen independently for each source z is used.

The elementary absolute-continuous identity at an atom is

    min(d,A_yz(r))-min(d,A_yz(r-))
       =integral_0^1 1{A_yz(r,theta)<d}a_yz(r)dtheta.  (4)

If a_yz(r)=0 both sides are zero, including a plateau exactly at d. Otherwise the single equality threshold has theta-measure zero. The continuous Stieltjes chain rule gives the analogous identity off the atoms. It follows that

    min(d,A_yz(r))
       =integral_{physical radius <=r}1{A_yz^o<d}dA_yz^o.

Positive Tonelli and ell_n([s,b])=s^(-n), including the endpoint b atom, now prove the EXACT quota formula

    O_d=integral beta(dy)nu(dz)
              integral R^(-n)1{A_yz^o<d}dA_yz^o.     (5)

Define

    N_(H,d)=integral beta(dy)nu(dz)
              integral R^(-n)1{J_y^o>=H,A_yz^o<d}dA_yz^o. (6)

The complementary part J_y^o<H is O_before(H). This is an exact disjoint split of (5). Whenever its positive increment in (6) occurs, J_y^o>=H>0 and A_yz^o/J_y^o<d/H. On the original retained aspects and low-pe gates these quantities are still calculated from exactly the same actual U. They are not reconstructed from a degree component or a restricted hard source.

## 3. True early-row source payment, including a crossing atom

At an actual radius r atom, the same-receiver hard cap gives

    integral a_yz(r)nu(dz)
       =integral_{R(x)=r}U_y(x)nu(Q_r(x))dx
       <=4lambda r^n h_y(r).                         (7)

The corresponding inequality holds for continuous radius increments. This uses the original receivers before any extension, not a virtual theta receiver.

If I_y<H there is no threshold crossing and the entire row lies before H, so N contributes zero. Otherwise define tau_y=inf{r in [a,b]:J_y(r)>=H}; the inclusive CDF gives a legal crossing at tau_y, including a or b. In a crossing atom h_y(tau_y)>0, the release fraction is theta_H=(H-J_y(tau_y-))/h_y(tau_y) in [0,1]. A continuous crossing has J_y(tau_y)=H; a plateau contributes no increment until mass resumes. Thus neither the crossing nor the portion charged before H is inferred from a nonexistent continuous radius interpolation.

Drop 1{A^o<d} only positively in O_before(H). Its row contribution is bounded by

    4lambda integral 1{J_y^o<H}dJ_y^o
       =4lambda min(H,I_y)<=4lambda H,               (8)

where I_y=J_y(b). The equality is valid because the refinement releases each atom continuously: a crossing atom contributes only its portion up to H. There is no lost or duplicated internal variance and no charge for its unused portion. Integrating beta proves (2).

Original FIRST is retained but is not needed for (8); it remains available for the difficult N. One unconditional coarse bound, used only as a finite check, is

    N_(H,d)<=O_d<=integral beta nu ell_n A_yz(r)
       =integral_E [integral U_y(x)beta(dy)]
                           [h_(R(x))*nu](x)dx
       <=A_n W_nu, A_n=1+n log(b/a).                 (9)

This is the old linear-scale bound, not a root improvement. There is no assumption nu<=beta.

Choosing H=C sqrt(A_n)/lambda in (2), with a fixed C>0, makes the explicit beta fee 8C sqrt(A_n)W_beta and forces the remaining rank fraction below

    d/H=lambda d/[C sqrt(A_n)].                     (10)

All lambda d=(4/3)kappa0 psi_inf/v0 costs are retained. If lambda d is large, (10) need not be small, and the displayed beta price does not repair that aspect/height cost. Multiplication by any original outer factor Lambda is inside the existing outer integration, giving 8Lambda lambda H W_beta+2Lambda N. Neither a new global target entry nor an unpriced outer integral is introduced.

## 4. Why a tempting innovation proof would be weaker

At a state J>=d, set

    E_d(J,A)=min(d,A)-dA/J>=0.

It satisfies min(d,A)=dA/J+E_d and E_d<=A-A^2/J. The difference from the full variance can be substantial; paying B_H is sufficient for the old bound but is not necessary to pay the clipped capacity.

Along a continuously released actual receiver block, write p=A/J and dA=c dJ, where c is either a binary receiver capture or a block's actual mean capture. Then

    dE_d=1{A<d}dA-(d/J)dA+(dA/J^2)dJ.               (11)

The last term is positive dilution of old captures by newly arriving row mass. For J>=H, its full weighted source price is at most

    integral beta nu integral R^(-n)(dA/J^2)dJ
       <=(d/H) integral beta nu integral R^(-n)dA
       <=(d/H)A_n W_nu.                             (12)

To verify the first inequality, expand the cumulative A as the integral of prior capture increments, exchange the nonnegative integrals, use the nondecreasing physical radius and

    integral_{J>=max(H,J_prior)} J^(-2)dJ<=1/H.

This bound is valid with the same atomic refinement. The high-J initial state also has a cap-based source price. However, deriving a bound for O_d by adding these innovation prices would be WEAKER than (5),(2): the exact clip is constant after A reaches d, so the positive and negative terms in (11) then cancel in min(d,A). The quota formula needs no post-quota dilution fee at all. We therefore do not register (12) as a new geometric improvement or add its source charge to (2).

For the uncapped variance F=A-A^2/J, increments may remain positive when new receivers miss previously captured sources. Those increments are exactly the kind of cost that can inflate B_H while the original min(d,A) has already saturated. A monotone-chain crossing estimate cannot by itself justify spending them on behalf of the original clipped target. This is the concrete reason to retain the d truncation in the next geometric attempt.

## 5. The precise unproved geometric interface

The remaining task is to price the true source quota allocation (6), not to show that every large row has small cube disagreement. A sufficient new estimate would be

    N_(H,d)<=epsilon X/2+C_epsilon sqrt(n)polylog(n)
                                     (W_beta+W_nu),  (13)

with its explicit dependence on lambda d, H, v0 and the original outer data. Combined with (2) at H of root size, this would give the requested target estimate whenever the separate original entry licenses the same X. No such estimate is proved here.

What must be used beyond the existing tools is now specific. A receiver increment in (6) captures z, yet almost all of its preceding actual U_y row mass can have missed z. Its quota for this y,z has not been used up. FIRST controls the sum over beta of current receiver densities, but the quota is DIFFERENT for different y,z. The hard cap controls the nu mass of each actual captured cube; it gives (8), but it does not bound how many different large-prefix rows can be making their early captures of the SAME z. The source is not copied in (6); the difficulty is its actual weighted incidence with many rows before each pair's quota is filled.

The ordered monotone-chain result from `/tmp/r313_input_310.md` does not fill this interface. The original receivers need not form an endpoint-monotone chain, and even a source crossing count on a valid chain does not control the beta-weighted quota incidence across all rows. Routing each pair through a virtual affine cube path would still need its true cut-congestion price and would not authorize FIRST on the virtual centers.

A successful next proof must either control that cross-row early-capture incidence using actual full-soft geometry and original qualifications, or construct a source-conserving common witness allocation that dominates (6) with a root source price. Merely invoking the small ratio A^o/J^o<d/H, treating it as a small probability after conditioning on the fact of capture, or replacing it by a boundary-volume/density estimate is insufficient. The finite tests below do not certify (13). No full B_H bound, root closure, or improved general exponent is claimed.

## 6. Executed finite checks with exact radius atoms

The following standard-library Fraction script checks three actual finite cube-incidence stages, including a repeated-radius atom and equality thresholds. Receiver row masses in the diagnostic are arbitrary finite occupation weights; they are NOT claimed to realize the full original soft kernel/FIRST history. The cube captures and hard cap are checked exactly. The analytic proof above applies to the original actual U_y dx. A fresh isolated Python process returned PASS for 108 quota identities, 108 disjoint splits, 108 early-cap bounds and 198 positive rank-gate checks. The code writes no files.

```python
from fractions import Fraction as F
from itertools import product
ct={'quota_identity':0,'split_identity':0,'early_cap':0,'rank_gate':0}
for n in (1,2,4):
 centers=[(F(0),)*n,(F(1,2),)*n,(F(3,2),)*n]
 radii=[F(1),F(1),F(2)]
 zs=centers+[tuple(x+F(1,2) for x in c) for c in centers]
 masses=[F(1,len(zs))]*len(zs)
 caps=[[int(all(abs(z[j]-c[j])<=r/2 for j in range(n))) for z in zs]
       for c,r in zip(centers,radii)]
 for row in ((F(1,4),F(1,2),F(1,4)),(F(2),F(3),F(1)),(F(0),F(4),F(0))):
  blocks=[]
  for r in sorted(set(radii)):
   ids=[i for i in range(3) if radii[i]==r]
   h=sum(row[i] for i in ids)
   az=[sum(row[i]*caps[i][z] for i in ids) for z in range(len(zs))]
   assert sum(m*a for m,a in zip(masses,az))<=4*r**n*h
   blocks.append((r,h,az))
  for d,H in product((F(1,4),F(1),F(3)),(F(1,4),F(1),F(3),F(6))):
   A=[F(0)]*len(zs);J=F(0);quota=early=N=direct=F(0)
   for j,(r,h,az) in enumerate(blocks):
    endA=[v+a for v,a in zip(A,az)]
    layer=r**(-n)-(blocks[j+1][0]**(-n) if j+1<len(blocks) else 0)
    direct+=layer*sum(m*min(d,v) for m,v in zip(masses,endA))
    t0=F(0) if J>=H or h==0 else min(F(1),(H-J)/h)
    for z,mass in enumerate(masses):
     pre=min(d,A[z]+t0*az[z])-min(d,A[z])
     inc=min(d,endA[z])-min(d,A[z])
     quota+=mass*r**(-n)*inc
     early+=mass*r**(-n)*pre
     N+=mass*r**(-n)*(inc-pre)
     if inc>pre:
      assert J+h>H and az[z]>0
      theta_lo=max(t0,F(0))
      theta_hi=min(F(1),(d-A[z])/az[z])
      assert theta_hi>theta_lo
      theta=(theta_lo+theta_hi)/2
      assert J+theta*h>=H and A[z]+theta*az[z]<d
      ct['rank_gate']+=1
    A=endA;J+=h
   assert quota==direct;ct['quota_identity']+=1
   assert quota==early+N;ct['split_identity']+=1
   assert early<=4*H;ct['early_cap']+=1
print('PASS',ct)
```

Only /tmp/r313_geometry.md is owned and written. Other authors' files, the supplied frozen inputs and Git are unchanged.
