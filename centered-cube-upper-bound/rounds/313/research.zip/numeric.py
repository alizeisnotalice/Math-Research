#!/usr/bin/env python3
"""R313 exact finite cube/source diagnostic; standard library only."""
from fractions import Fraction as F
from itertools import product
from collections import Counter, defaultdict
from pathlib import Path
import json, hashlib
counts=Counter()
def ck(name, test):
    counts[name]+=1
    assert test, name

def box(center,side): return tuple((x-side/2,x+side/2) for x in center)
def volume(b):
    out=F(1)
    for lo,hi in b: out*=max(F(0),hi-lo)
    return out

def intersection(*boxes):
    return tuple((max(t[0] for t in items),min(t[1] for t in items)) for items in zip(*boxes))
def source_mass(sources,*boxes):
    return sum((mass*volume(intersection(src,*boxes))/volume(src) for src,mass in sources),F(0))
def partition(cubes,sources):
    ledger=defaultdict(F); cells=0
    for src,mass in sources:
        cuts=[]
        for axis,(lo,hi) in enumerate(src):
            points=sorted({lo,hi}|{z for cb in cubes for z in cb[axis] if lo<z<hi})
            cuts.append(list(zip(points,points[1:])))
        for cell in product(*cuts):
            mid=[(a+b)/2 for a,b in cell]
            pattern=tuple(all(lo<x<hi for x,(lo,hi) in zip(mid,cb)) for cb in cubes)
            ledger[pattern]+=mass*volume(cell)/volume(src); cells+=1
    return dict(ledger),cells

def fixture(name,n,centers,radii,weights,sources,stage):
    return dict(name=name,n=n,centers=centers,radii=radii,weights=weights,sources=sources,stage=stage)

def models():
    out=[]
    def one(name,cs,rs,hs,lo,hi,stage):
        out.append(fixture(name,1,[(F(x),) for x in cs],list(map(F,rs)),list(map(F,hs)),[(((F(lo),F(hi)),),F(1))],stage))
    one('separated',[-1,1],[1,1],[1,1],-2,2,'initial')
    one('overlap',[0,F(1,2)],[1,1],[1,1],-1,F(3,2),'initial')
    one('duplicates',[0,0,0],[1,1,1],[1,2,3],F(-3,4),F(3,4),'pressure')
    one('nested',[0,0,0],[1,F(3,2),2],[1,2,3],F(-5,4),F(5,4),'pressure')
    one('high_overlap',[0,F(1,16),F(-1,16)],[1,1,F(3,2)],[1,2,1],F(-3,4),F(3,4),'pressure')
    one('zero_prefix',[0,F(1,4),F(3,4)],[1,1,F(3,2)],[0,0,1],-1,2,'pressure')
    for n in [2,4,8]:
        centers=[(x,)+(F(0),)*(n-1) for x in [F(0),F(1,8),F(-1,8),F(1,16)]]
        sources=[(tuple((F(-3,4),F(3,4)) for _ in range(n)),F(1)),(box((F(1,2),)+(F(0),)*(n-1),F(1,4)),F(1,2))]
        out.append(fixture('expanded_n'+str(n),n,centers,[F(1),F(1),F(3,2),F(2)],[F(1),F(2),F(1),F(3)],sources,'expanded'))
    return out

def run(model):
    n=model['n']; radii=model['radii']; cubes=[box(c,r) for c,r in zip(model['centers'],radii)]; sources=model['sources']
    ledger,cells=partition(cubes,sources); W=sum((m for _,m in sources),F(0)); size=len(cubes)
    ck('partition_mass',sum(ledger.values())==W)
    caps=[source_mass(sources,c) for c in cubes]
    lam=max((caps[i]/(4*radii[i]**n) for i in range(size)),default=F(0))
    for i in range(size):
        ck('capture_mass',sum((m*p[i] for p,m in ledger.items()),F(0))==caps[i])
        ck('hard_caps',caps[i]<=4*lam*radii[i]**n)
        for j in range(size):
            ck('overlap_mass',sum((m*p[i]*p[j] for p,m in ledger.items()),F(0))==source_mass(sources,cubes[i],cubes[j]))
    output=[]; crossing=[]; anova_count=0
    for scale in [1,16,256]:
        hs=[scale*h for h in model['weights']]; rows=[]; oldJ=F(0); oldA={p:F(0) for p in ledger}; oldF=F(0)
        for r in sorted(set(radii+[F(2)])):
            block=[i for i in range(size) if radii[i]==r]; h=sum((hs[i] for i in block),F(0))
            A={p:oldA[p]+sum((hs[i]*p[i] for i in block),F(0)) for p in ledger}; J=oldJ+h
            M=sum((mass*A[p] for p,mass in ledger.items()),F(0)); M2=sum((mass*A[p]**2 for p,mass in ledger.items()),F(0)); fee=M-M2/J if J else F(0)
            Q=sum((hs[i]*hs[j]*(caps[i]+caps[j]-2*source_mass(sources,cubes[i],cubes[j])) for i in range(size) for j in range(i+1,size) if radii[i]<=r and radii[j]<=r),F(0))
            ck('pair_identity',Q==J*M-M2)
            ck('variance_nonnegative',fee>=0)
            intrinsic=sum((mass*(A[p]-oldA[p])*(1-(A[p]-oldA[p])/h) for p,mass in ledger.items()),F(0)) if h else F(0)
            between=sum((mass*(oldA[p]/oldJ-(A[p]-oldA[p])/h)**2 for p,mass in ledger.items()),F(0))*oldJ*h/J if oldJ and h else F(0)
            ck('grouped_atom_anova',fee-oldF==intrinsic+between)
            ck('anova_nonnegative',intrinsic>=0 and between>=0); anova_count+=1
            rows.append(dict(r=r,J=J,A=A,M=M,F=fee,h=h,oldJ=oldJ,intrinsic=intrinsic,block_size=len(block),previous_A=dict(oldA)))
            oldJ,oldA,oldF=J,A,fee
        for H in sorted({F(1,4),F(1),F(3),F(8),F(scale,4),F(scale),F(3*scale),F(8*scale)} | {row['J'] for row in rows if row['J']}):
            crosses=[row for row in rows if row['J']>=H]
            if crosses:
                row=crosses[0]
                ck('crossing_prefix',row['oldJ']<H)
                residual=row['F']-row['intrinsic']; bound=8*lam*row['r']**n*H
                ck('crossing_initialization',residual<=bound)
                theta=(H-row['oldJ'])/row['h']
                AH={p:row['previous_A'][p]+theta*(row['A'][p]-row['previous_A'][p]) for p in ledger}
                FH=sum((mass*(AH[p]-AH[p]**2/H) for p,mass in ledger.items()),F(0))
                ck('rank_release_fraction',0<theta<=1)
                ck('rank_initialization',0<=FH<=4*lam*row['r']**n*H)
                ck('post_rank_remainder',row['F']>=FH)
                crossing.append(dict(scale=scale,H=H,R=row['r'],Jprev=row['oldJ'],Jpost=row['J'],h=row['h'],residual=residual,bound=bound,theta_release=theta,F_H=FH,rank_bound=4*lam*row['r']**n*H,post_rank_remainder=row['F']-FH,equality_atom=row['J']==H,large_atom=row['h']>=8*H))
        for d in [F(1,16),F(1),F(16)]:
            table=[]
            for row in rows:
                J=row['J']; A=row['A']; M=row['M']; fee=row['F']
                C=sum((mass*min(d,A[p]) for p,mass in ledger.items()),F(0))
                E=sum((mass*max(F(0),min(d,A[p])-d*A[p]/J) for p,mass in ledger.items()),F(0)) if J else F(0)
                base=d*M/J if J else F(0)
                ck('clip_budget',C<=base+E)
                ck('excess_vs_old',0<=E<=fee and E<=C)
                for p in ledger:
                    a=A[p]
                    ck('pointwise_clip',not J or min(d,a)<=d*a/J+a*(1-a/J))
                table.append(dict(r=row['r'],J=J,J_over_d=J/d,F=fee,C=C,E=E,base=base,F_over_C=fee/C if C else None,F_over_E=fee/E if E else None))
            Hs=sorted({d,rows[-1]['J']/2}|{row['J'] for row in rows if row['J']})
            budgets=[]
            for H in Hs:
                if not H: continue
                acc={k:F(0) for k in ['F','C','E','base']}
                for j,row in enumerate(table):
                    w=row['r']**(-n)-(table[j+1]['r']**(-n) if j+1<len(table) else F(0))
                    ck('layer_nonnegative',w>=0)
                    if row['J']>=H:
                        for k in acc: acc[k]+=w*row[k]
                ck('integrated_clip_budget',acc['C']<=acc['base']+acc['E'])
                ck('integrated_excess',acc['E']<=acc['F'])
                budgets.append(dict(H=H,**acc))
            output.append(dict(scale=scale,d=d,prefixes=table,high_prefix_budgets=budgets))
    return dict(name=model['name'],stage=model['stage'],n=n,source_mass=W,source_boxes=model['sources'],centers=model['centers'],side_lengths=radii,base_weights=model['weights'],lambda_hard=lam,partition_cells=cells,capture_patterns=len(ledger),ledger=[dict(pattern=list(p),mass=m) for p,m in sorted(ledger.items())],anova_count=anova_count,crossings=crossing,results=output)

def serial(x):
    if isinstance(x,F): return str(x)
    if isinstance(x,dict): return {k:serial(v) for k,v in x.items()}
    if isinstance(x,(list,tuple)): return [serial(v) for v in x]
    return x

def main():
    reports=[]; stage_checks=Counter()
    for model in models():
        before=sum(counts.values()); reports.append(run(model)); stage_checks[model['stage']]+=sum(counts.values())-before
    ratios=[(row['F_over_C'],r['name'],case['scale'],case['d'],row['r'],row['J_over_d'],row['F_over_E']) for r in reports for case in r['results'] for row in case['prefixes'] if row['F_over_C'] is not None]
    largest=max(ratios)
    result=dict(status='PASS',arithmetic='exact fractions',scope='Real positive-volume piecewise-constant L1 sources and actual axis-aligned cube capture; finite nonnegative receiver quadrature, not actual FIRST or full selector history.',check_counts=dict(sorted(counts.items())),total_checks=sum(counts.values()),stage_check_counts=dict(stage_checks),stages={s:sum(r['stage']==s for r in reports) for s in ['initial','pressure','expanded']},maximum_F_over_clip=dict(zip(['ratio','model','scale','d','R','J_over_d','F_over_E'],largest)),models=reports)
    target=Path(__file__).with_suffix('.json'); target.write_text(json.dumps(serial(result),sort_keys=True,indent=2)+'\n')
    print(json.dumps(serial({k:result[k] for k in ['status','check_counts','total_checks','stage_check_counts','stages','maximum_F_over_clip']}),sort_keys=True))
if __name__=='__main__': main()
