# R313 — exact Stieltjes innovations and a source-paid threshold initialization

## 1. Proposition, original scope and notation

Use exactly /tmp/r313_input_302.md. In particular U_y(x) is the ACTUAL original full-soft row density, a<=R(x)<=b, beta,nu are the original finite positive L1 sources, and every hard cap is at an actual accepted receiver and its SAME selected radius. Let mu_y be the R-pushforward of U_y dx, J_y its inclusive cumulative, and

    A_yz(r)=integral_(R(x)<=r) U_y(x)1_(Q_(R(x))(x))(z)dx,
    F_y(r)=integral [A_yz(r)-A_yz(r)^2/J_y(r)]nu(dz),
    F_y(r)=0 when J_y(r)=0.

Thus the ORIGINAL fee is B_H=integral beta(dy)ell_n(dr)1{J_y(r)>=H}F_y(r), with ell_n=b^(-n)delta_b+n r^(-n-1)1_(a,b)dr. Keep the original d,H,q, selected softness/scales, full-source qualifications and outer factors. No source density or cap at a virtual receiver is assumed.

The main initialization payment, using a COMMON source-independent mass split inside the crossing radius block and retaining its full remaining innovation, is

    B_H<=4lambda H W_beta+B_H^after-rank.              (1r)

Section 4 defines the exact nonnegative rank remainder. A separate whole-atom initialization statement is

    B_H<=8lambda H W_beta+C_H+D_H,                    (1)

where C_H is the EXACT internal capture variance of the whole radius atom first crossing H, and D_H is the exact subsequent Stieltjes innovation fee, defined below. If crossing is atom-free for beta-a.e. active row, C_H=0 and 8 improves to 4. Neither residual in these two alternatives is declared paid or silently identified with the other. These initialization payments are additional to the exact innovation identity; all source costs are included in Section 5.

## 2. General radius measure: continuous innovations and full atoms

Suppress y. There is a jointly measurable v(r,z) in [0,1] such that

    dA_z(r)=v(r,z)mu(dr).

It is the true conditional capture fraction at physical radius r. It can be defined directly as a Radon–Nikodym derivative of the joint capture measure against beta(dy)mu_y(dr)nu(dz). No single receiver or invented cap represents this conditional block. In particular v need not be binary even when mu has no atoms.

At a physical radius atom r write

    j=J(r-), h=mu({r}), t(z)=A_z(r-)/j when j>0,
    v(z)=Delta A_z(r)/h when h>0.

When a denominator is zero, its multiplying term below is zero and its fraction may be set to zero. The EXACT jump formula is

    Delta F(r)=h integral v(1-v)nu
             +[j h/(j+h)]integral(v-t)^2 nu.          (2)

This follows by expanding F before and after A_new=j t+h v, J_new=j+h. Both terms are nonnegative. All receivers with that SAME actual R belong to one atom. Discarding a crossing atom's remainder after only charging the fraction needed to reach H is invalid. A common fractional mass split that keeps the SAME physical radius and ALL remaining innovation is legitimate; Section 4 gives that exact alternative.

Let mu^c denote the entire nonatomic part, including any singular-continuous radius measure. At mu^c-a.e. r with J(r)>0 put t_r(z)=A_z(r)/J(r). Then

    dF^c(r)={integral [v(r,z)(1-v(r,z))
                                  +(v(r,z)-t_r(z))^2]nu(dz)}mu^c(dr). (3)

Proof: on J>=epsilon>0, the continuous BV chain rule for A-A^2/J gives density v-2tv+t^2, which is exactly the bracket in (3). Localizing and then decreasing epsilon to zero is legitimate since F<=J W_nu and the bracket is between zero and one pointwise. The zero-prefix contribution therefore vanishes. Equivalently one may parametrize continuous increments by their true row mass; this includes singular-continuous mu without replacing it by dr. Formula (2) remains a separate finite jump evaluation at each physical atom. No interpolated part of a physical atom is assigned a different R or a different hard cap.

Together (2),(3) give a positive Stieltjes measure dF, with F(a-)=0. The within-radius term v(1-v) DOES NOT disappear merely because the radius distribution is nonatomic: an R-level can contain many actual receivers with different source captures. The remaining square is the true prediction error against the accumulated previous capture fraction.

## 3. Exact high-window identity and the whole crossing contribution

If J(b)<H, this row contributes zero. Otherwise define

    tau=inf{r in [a,b]:J(r)>=H}.

Right continuity gives J(tau)>=H and j=J(tau-)<=H. The last inequality need NOT be strict: J may approach H continuously and then jump at tau. At tau=a the prior prefix is zero. At tau=b its full radius atom is included.

For W_H(r)=1{J(r)>=H}F(r), W_H(a-)=0, the exact Stieltjes measure is

    dW_H=F(tau)delta_tau+1_(tau,b]dF.

Positive Tonelli, using ell_n([r,b])=r^(-n), proves

    integral ell_n(dr)1{J(r)>=H}F(r)
       =tau^(-n)F(tau)+integral_(tau,b]r^(-n)dF(r).    (4)

Thus a continuous threshold crossing can create an INITIAL GATE ATOM F(tau), even when F itself is continuous. Replacing the first term by Delta F(tau), or by only a fraction of the crossing atom while omitting its remaining innovation, is wrong. The compensated common split below keeps the entire equality.

For an active row let h=mu({tau}) and define

    C_H(y)=tau^(-n)h integral v_tau(1-v_tau)nu,
    D_H(y)=integral_(tau,b]r^(-n)dF_y(r),
    W_H^init(y)=tau^(-n)F_y(tau)-C_H(y).

For h=0 take C_H(y)=0. Set all three to zero on rows never reaching H. They are measurable positive quantities. Their beta integrals, denoted C_H,D_H,W_H^init, satisfy EXACTLY

    B_H=W_H^init+C_H+D_H.                             (5)

The full continuous and atomic expansions of D_H are (3) and (2), each multiplied by its ACTUAL r^(-n), with atoms strictly after tau. Initial C_H is one whole atom's internal source variance; nothing is silently omitted.

## 4. New initialization payment with SAME-radius caps

At the crossing atom h>0, (2) gives

    tau^n W_H^init(y)=F(tau-)
                        +[j h/(j+h)]integral(v-t)^2nu.

Since h/(j+h)<=1, combine the overlap terms BEFORE estimating:

    F(tau-)+[j h/(j+h)]integral(v-t)^2nu
       <=j integral [t(1-t)+(v-t)^2]nu
        =j integral [t+v^2-2vt]nu
       <=j integral(t+v)nu.                           (6)

The ACTUAL old and incoming row blocks obey

    integral t nu<=4lambda tau^n,
    integral v nu<=4lambda tau^n.                     (7)

For the first, average nu(Q_(R(x))(x))<=4lambda R(x)^n over ORIGINAL receivers with R<tau and use R<=tau. For the second, average the cap over ORIGINAL receivers with R=tau. These are not caps at a new radius or at a conditional/virtual receiver. With j<=H, (6),(7) prove

    0<=W_H^init(y)<=8lambda j<=8lambda H.             (8)

If j=0 the initialization remainder is exactly zero, even for a very large first atom. Its whole internal variance stays in C_H. If h=0, continuity gives J(tau)=j=H and

    W_H^init(y)=tau^(-n)F(tau)<=4lambda H.             (9)

This proves (1), and its 4lambda H improvement on atom-free-crossing rows. The constant 8 in (8) accounts jointly for past potential and crossing prediction; estimating them separately by 4lambda H and 8lambda H would unnecessarily give 12. No claim that the crossing atom's internal variance costs 4lambda H or 8lambda H is made. Its mass h can be much larger than H.

### Common same-radius rank split: a uniform 4lambda H initialization

For h>0 put theta=(H-j)/h in [0,1]. Uniformly split the ORIGINAL incoming measure U_y1{R=tau}dx into theta and 1-theta times that measure. This SAME theta is used for every source z. Set

    A_H(z)=A_z(tau-)+(H-j)v(z),
    F_H=integral [A_H(z)-A_H(z)^2/H]nu(dz).

When h=0 set A_H=A(tau), F_H=F(tau); then J(tau)=H. These are bookkeeping fractions of actual receiver mass, not a source-favorable choice of receivers or a new physical scale. Linear use of the ORIGINAL caps gives

    0<=F_H<=integral A_H nu<=4lambda tau^n H.          (R1)

Indeed the retained old mass is j, the retained incoming mass is H-j, and both capture means in (7) are <=4lambda tau^n. No cap at a conditional or virtual point is used.

Let h_rest=J(tau)-H and t_H=A_H/H. Applying the exact block identity to the remaining fraction, at the SAME physical radius tau, gives

    F(tau)-F_H=h_rest integral v(1-v)nu
          +[H h_rest/(H+h_rest)]integral(v-t_H)^2nu>=0. (R2)

If h_rest=0 the expression is zero. The after-rank remainder is defined EXACTLY by

    B_H^after-rank(y)=tau^(-n)[F_y(tau)-F_H(y)]
                             +integral_(tau,b]r^(-n)dF_y(r). (R3)

It is zero on never-crossing rows. Equation (4) becomes

    B_H(y)=tau^(-n)F_H(y)+B_H^after-rank(y).

After integrating beta, (R1) proves (1r). Formula (R2) retains both the internal variance and drift of the crossing atom's ENTIRE remaining mass; every term keeps tau^(-n). This is the precise meaning of innovations after mass rank H. It does not pretend that R varies continuously inside a physical atom. When h=0, B_H^after-rank(y)=D_H(y).

The whole-atom remainder C_H+D_H and the after-rank remainder (R3) differ and are not asserted to be ordered. The smaller source constant 4 in (1r) cannot be combined with the old whole-atom remainder without proof.

## 5. Direct substitution in the R302 budget, with full constants

The INPUT R302 bound at THIS SAME H is

    T_target<=8lambda H W_beta+(2d/H)A_n W_nu+2B_H,
    A_n=1+n log(b/a).

Using the common rank initialization (1r) gives the fully accounted source contribution

    T_target<=16lambda H W_beta+(2d/H)A_n W_nu
                                             +2B_H^after-rank. (10r)

In particular keep the ORIGINAL R302 H0=sqrt(d A_n/(4lambda)). Then

    T_target<=4sqrt(lambda d A_n)(2W_beta+W_nu)
                                           +2B_(H0)^after-rank. (11r)

Optimizing the displayed mass-independent source terms instead gives

    T_target<=4sqrt(2lambda d A_n)(W_beta+W_nu)
                          +2B_H^after-rank
                    at H=sqrt(d A_n/(8lambda)).       (12r)

The remainder must be evaluated at the displayed H; optimizing H does not keep the H0 remainder unchanged. With positive source masses the mass-balanced choice H=sqrt(d A_n W_nu/(8lambda W_beta)) gives source term 8sqrt(2lambda d A_n W_beta W_nu), again at THAT H. Zero-source cases vanish directly.

The whole-atom alternative (1) gives

    T_target<=24lambda H W_beta+(2d/H)A_n W_nu
                                                   +2(C_H+D_H). (10)

At the ORIGINAL H0 this is precisely

    T_target<=4sqrt(lambda d A_n)(3W_beta+W_nu)
                                                +2(C_(H0)+D_(H0)). (11a)

The low-J source cost from the original input and the new initialization cost are ADDED, not used twice as one credit. With H=sqrt(d A_n/(12lambda)), this alternative becomes

    T_target<=4sqrt(3lambda d A_n)(W_beta+W_nu)
                                                   +2(C_H+D_H), (11)

at the displayed threshold. The original aspect and low/high costs stay in lambda d=(4/3)kappa0 psi_inf/v0. If both sources are positive, the mass-balanced alternative H=sqrt(d A_n W_nu/(12lambda W_beta)) gives source term 8sqrt(3lambda d A_n W_beta W_nu), with C_H,D_H evaluated at THAT H. Zero source cases give zero target directly.

If crossing is atom-free on beta-a.e. active row, the whole-atom residual has C_H=0 and agrees with the rank residual D_H, so (9) gives

    T_target<=16lambda H W_beta+(2d/H)A_n W_nu+2D_H,
    T_target<=4sqrt(2lambda d A_n)(W_beta+W_nu)+2D_H
                     at H=sqrt(d A_n/(8lambda)).      (12)

All displayed source terms are actual payments. The rank remainder, or the alternative C_H and post-threshold innovations D_H, are explicit nonnegative UNPAID fees; the Stieltjes decomposition alone gives no root bound for them. Prediction agreement can yield further conditional inequalities, but no arbitrarily selected good-error branch is marketed here as a new general source estimate.

The first source moment in this R302 input is the UNQUALIFIED capture enlargement F1=integral beta nu ell A, possibly larger than T_target. Its bound F1<=A_nW_nu cannot be replaced silently by T_target in an absorption. This note makes no such substitution and certifies no global receiver-volume entry. An original positive Lambda multiplies every term once, within its original outer allocation.

Finally, physical-radius atoms of the R-pushforward U_y dx are NOT the historical deletion-time atoms in the original I/J/D slots. An R atom can arise simply because a receiver selector is constant on a positive-volume set. Paying (8) does not pay any independent initial, deleted-time, future-deleted or suffix slot, nor certify their adoption/coverage ledger.

## 6. Actual exact-Fraction checks

A standard-library run passed 25 continuous-density algebra checks, 56 full physical-atom innovation identities, 72 complete threshold Stieltjes identities, 72 whole-atom initialization payments and 72 compensated common-rank splits with the 4lambda H payment. Receivers at the SAME radius were coalesced before computing v and the threshold. Tests include zero rows, first-atom crossing, intermediate/terminal crossing and crossing mass above H. They are finite capture-incidence diagnostics; actual full-soft original realizability is not inferred from them. Reproduction:

```python
from fractions import Fraction as F
from itertools import product
R=[F(1),F(1),F(3,2),F(2)];levels=sorted(set(R))
nu=[F(1,4),F(1,3),F(5,12)]
profiles=[[F(1,4),F(1,2),F(1,4),F(1,2)],
 [F(0),F(1),F(1),F(0)],[F(1),F(0),F(0),F(3)],[F(0)]*4]
patterns=[[[1,0,1],[0,1,1],[1,1,0],[0,0,1]],
          [[1,1,0],[1,1,0],[1,1,0],[1,1,1]]]
ct=dict(continuous_density=0,atom_jump=0,threshold_identity=0,warmstart=0,rank_split=0)
for p,v in product([F(0),F(1,4),F(1,2),F(3,4),F(1)],repeat=2):
 assert v-2*p*v+p*p==v*(1-v)+(v-p)**2
 ct['continuous_density']+=1
for n,U,cap in product([1,2,8,32],profiles,patterns):
 lam=max(sum(nu[z]*cap[i][z] for z in range(3))/(4*R[i]**n)
         for i in range(4))
 J=F(0);A=[F(0)]*3;Fprev=F(0);blocks=[]
 for r in levels:
  inds=[i for i in range(4) if R[i]==r];h=sum(U[i] for i in inds)
  if not h:
   blocks.append((r,J,Fprev,F(0),F(0)));continue
  v=[sum(U[i]*cap[i][z] for i in inds)/h for z in range(3)]
  t=[a/J for a in A] if J else [F(0)]*3
  intrinsic=h*sum(nu[z]*v[z]*(1-v[z]) for z in range(3))
  pred=J*h/(J+h)*sum(nu[z]*(v[z]-t[z])**2 for z in range(3))
  newA=[A[z]+h*v[z] for z in range(3)];newJ=J+h
  Fnew=sum(nu[z]*(newA[z]-newA[z]**2/newJ) for z in range(3))
  assert Fnew-Fprev==intrinsic+pred
  ct['atom_jump']+=1
  blocks.append((r,newJ,Fnew,Fnew-Fprev,intrinsic))
  J,A,Fprev=newJ,newA,Fnew
 for H in [F(1,4),F(1),F(2),F(4)]:
  BH=sum((r**(-n)-(levels[k+1]**(-n) if k+1<len(levels) else 0))*FF
   for k,(r,JJ,FF,dd,ii) in enumerate(blocks) if JJ>=H)
  cross=next((k for k,B in enumerate(blocks) if B[1]>=H),None)
  if cross is None:
   assert BH==0;continue
  r,Jc,Fc,delta,ic=blocks[cross]
  assert BH==r**(-n)*Fc+sum(B[0]**(-n)*B[3] for B in blocks[cross+1:])
  ct['threshold_identity']+=1
  assert r**(-n)*(Fc-ic)<=8*lam*H
  ct['warmstart']+=1
  j0=sum(U[i] for i in range(4) if R[i]<r);h0=Jc-j0
  old=[sum(U[i]*cap[i][z] for i in range(4) if R[i]<r) for z in range(3)]
  inc=[sum(U[i]*cap[i][z] for i in range(4) if R[i]==r) for z in range(3)]
  fraction=(H-j0)/h0 if h0 else F(0)
  AH=[old[z]+fraction*inc[z] for z in range(3)]
  FH=sum(nu[z]*(AH[z]-AH[z]**2/H) for z in range(3))
  v0=[a/h0 for a in inc] if h0 else [F(0)]*3
  remaining=Jc-H
  innovation=remaining*sum(nu[z]*v0[z]*(1-v0[z]) for z in range(3))
  innovation+=H*remaining/Jc*sum(nu[z]*(v0[z]-AH[z]/H)**2 for z in range(3))
  assert Fc-FH==innovation>=0 and FH<=4*lam*r**n*H
  after=r**(-n)*innovation+sum(B[0]**(-n)*B[3] for B in blocks[cross+1:])
  assert BH==r**(-n)*FH+after
  ct['rank_split']+=1
print('PASS',ct)  # actual: 25, 56, 72, 72, 72
```

Only /tmp/r313_innovation.md was written. Other authors' files and Git were preserved.
