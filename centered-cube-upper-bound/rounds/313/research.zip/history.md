# R313 有界历史索引：截断差费用 / 高捕获列

范围：只读核对 R300–311 的已保存报告，重点 R302–305、R308；不是新证明。没有遍历全部历史。

## 结论

- **有精确的截断 min 代数，但未找到将其作为新全局残项、完整取代 B_H 的既成付款结论。** R302 已证明 min(d,A) ≤ (d/J)A + A(J−A)/J，0≤A≤J；因此 E_d(J,A):=min(d,A)−(d/J)A ≤ A(J−A)/J。左侧正是题设两段式：A≤d 时 A(1−d/J)，A≥d 时 d(1−A/J)。这是已有逐点 domination；右侧经源积分正是 Q_y(r)/J_y(r)，仍收费原 B_H。R302 主预算没有把 B_H 替换成一个独立且已付的 E_d-fee。

- **找到 d/H 乘第一矩的高累计行付款，不是按列条件 A≥T 直接给 (d/T)F1 的另一项新结论。** R302 在 J≥H 上由同一夹逼积分得到 (d/H)F1+B_H，其中 F1=∫β(dy)ell_n(dr)M_y(r) ≤ min{4λ∫I_y dβ, A_n Wν, 4λ|E|}。这是对 row denominator J≥H 的已证明结果。本次定向稿中没有找到再按列的 A≥T 条件把原始 clipped 交通直接付成 (d/T)F1 并由此消除 B_H。

- R305 的高捕获付款是不同机制：对 p=A/J≥1−η，Jp(1−p)≤ηA，故 B_high≤ηT；其完整剩余项仍有 p<η 与中间区间（R305 §2，式 (7)）。不能把这个 high-capture 分支说成覆盖低捕获项，或说它用 d/T 付掉了 B_H。

## 精确定位

1. /tmp/r302_geometry.md §2，行 71–88：精确重叠恒等式 Q=JM−∫A²dν（式 (7)）；行 79–86 给上述 clipping inequality（式 (8)）及积分式 ∫min(d,A)dν≤min{M,(d/J)M+Q/J}。这是 E_d≤Q/J 的直接出处。原始费用定义在 §1 行 37–45：B_H=∫β ell_n 1_{J≥H}Q/J，主界为 O_d≤4λHWβ+(d/H)A_nWν+B_H。行 102–145 证明低 J 用 4λH，高 J 用 (d/H)F1+Q/J；行 156 起的 B_H 替代仅在额外 overlap 条件下成立，仍然是 B_H≤εF1。
2. /tmp/r302_overlap_checks.md 行 5–7：有限 Fraction overlap diagnostics 使用 min(d,A_z) 并检验 O≤4HWβ+(d/H)CmenuWν+B_H，等号阈值放入大 J 支。它是组件模型检查，文件行 3 明示未实现完整 maximal-hardcap / low-m 历史，不能升级成一般闭合。
3. /tmp/r305_joint_budget.md §2，行 30–66：按 p=A/J 划分 low/middle/high；式 (4) 仅给 B_high≤ηT，式 (7) 明列余项 ∫1_{J≥8d,p<7/8}(A−A²/J)。行 60 明说 B_low 不能由 ηT 付款。§5 行 122–129 明列中间项仍只有 A_nW_{ν_*} 的 order-n 粗界，低支同样未闭合。
4. /tmp/r308_joint_capacity.md 行 183–190：后来仍逐字保留 low capture 未付款、high capture 单独用 R305 的 T/8，以及 low / reduced-middle 的真实权重和原分母；没有截断差费用替换 B_H 的记录。

## 可复用边界

若后续计算只需要某个点态余项，可直接引用 R302 (8)：E_d(J,A)≤A(1−A/J)，再用 Q/J 对源积分；若能另外证明更便宜地控制 ∫E_d，那会是新费用改进，不能说 R302 已经支付了它。R302 的 (d/H)F1 是 J-threshold 结果，R305 的 ηT 是高捕获 p-分支结果；本次检索未发现它们与“A≥T 列条件 ⇒ (d/T)F1”等同的原文。

