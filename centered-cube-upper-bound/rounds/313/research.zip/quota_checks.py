from fractions import Fraction as F
from itertools import product
ct={'quota_identity':0,'split_identity':0,'early_cap':0,'rank_gate':0}
for n in (1,2,4):
 centers=[(F(0),)*n,(F(1,2),)*n,(F(3,2),)*n]
 radii=[F(1),F(1),F(2)]
 zs=centers+[tuple(x+F(1,2) for x in c) for c in centers]
 masses=[F(1,len(zs))]*len(zs)
 caps=[[int(all(abs(z[j]-c[j])<=r/2 for j in range(n))) for z in zs]
       for c,r in zip(centers,radii)]
 for row in ((F(1,4),F(1,2),F(1,4)),(F(2),F(3),F(1)),(F(0),F(4),F(0))):
  blocks=[]
  for r in sorted(set(radii)):
   ids=[i for i in range(3) if radii[i]==r]
   h=sum(row[i] for i in ids)
   az=[sum(row[i]*caps[i][z] for i in ids) for z in range(len(zs))]
   assert sum(m*a for m,a in zip(masses,az))<=4*r**n*h
   blocks.append((r,h,az))
  for d,H in product((F(1,4),F(1),F(3)),(F(1,4),F(1),F(3),F(6))):
   A=[F(0)]*len(zs);J=F(0);quota=early=N=direct=F(0)
   for j,(r,h,az) in enumerate(blocks):
    endA=[v+a for v,a in zip(A,az)]
    layer=r**(-n)-(blocks[j+1][0]**(-n) if j+1<len(blocks) else 0)
    direct+=layer*sum(m*min(d,v) for m,v in zip(masses,endA))
    t0=F(0) if J>=H or h==0 else min(F(1),(H-J)/h)
    for z,mass in enumerate(masses):
     pre=min(d,A[z]+t0*az[z])-min(d,A[z])
     inc=min(d,endA[z])-min(d,A[z])
     quota+=mass*r**(-n)*inc
     early+=mass*r**(-n)*pre
     N+=mass*r**(-n)*(inc-pre)
     if inc>pre:
      assert J+h>H and az[z]>0
      theta_lo=max(t0,F(0))
      theta_hi=min(F(1),(d-A[z])/az[z])
      assert theta_hi>theta_lo
      theta=(theta_lo+theta_hi)/2
      assert J+theta*h>=H and A[z]+theta*az[z]<d
      ct['rank_gate']+=1
    A=endA;J+=h
   assert quota==direct;ct['quota_identity']+=1
   assert quota==early+N;ct['split_identity']+=1
   assert early<=4*H;ct['early_cap']+=1
print('PASS',ct)
