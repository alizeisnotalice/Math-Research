# R313 independent preauthor screen

Read only the supplied original /tmp/r313_input_302.md before this screen; no new R313 author proof was read. Own audit only; no Git or other-author modification. The proposed identities PASS with the continuum qualification below. They are an exact positive accounting of the known boundary fee, not yet a new root source payment.

## Fixed-row variance and finite scale blocks

Fix y and the ORIGINAL finite receiver measure U_y dx pushed by actual R into [a,b]. Let J(r) be its inclusive CDF and A(r,z) its cumulative ORIGINAL binary cube-capture mass. Sources beta,nu are finite positive L1, though the following scalar identities need only finite nu. Extend F=integral(A-A^2/J)nu by zero when J=0. This is the existing Q/J physical disagreement fee, using full original J. All actual source/history/clock qualifications of the original target stay in the original input; no new gates or independent source ordering are assumed.

For an added disjoint scale block with total mass h and normalized capture v(z) in [0,1], set past J>0 and t(z)=A/J. Then exactly

F(J+h,A+h v)-F(J,A)
 =h integral v(1-v)nu + Jh/(J+h) integral(v-t)^2 nu >=0.

This is the variance/ANOVA decomposition; if J=0 initialize F=h integral v(1-v), and if h=0 increment zero. It is essential to retain internal block variance. A physical radius atom may contain many actual receiver centers, so v is generally fractional even though each individual cube capture is binary. Merging equal-radius atoms before updating is legitimate and avoids any spurious ordering inside an actual scale atom.

For the nonatomic part of the radius measure, dA=v(r,z)dJ with v a conditional capture mean. The correct derivative is

dF = integral[v(1-v)+(v-t)^2]nu dJ,

where t=A/J at positive nonatomic J. Equivalently it is conditional expectation of the square (c_x(z)-t)^2 of the ACTUAL binary cube capture c_x, averaged over the receiver conditional law at radius r. Merely squaring the conditional mean difference (v-t)^2 would omit real internal conditional variance. This applies to singular-continuous as well as absolutely continuous radius mass; no density in radius may be invented. Zero-J initialization is handled by monotone extension/finite blocks.

## Stieltjes and threshold endpoint accounting

J,A are right-continuous inclusive cumulative quantities, and F is finite, right-continuous and nondecreasing by the block identity. Its Stieltjes measure includes any atom at a, with F(a-) declared zero. Positive Tonelli and ell_n([s,b])=s^(-n) give

integral ell_n(dr)F(r)=integral_[a,b] s^(-n)dF(s).

All endpoint atoms are included; ell is an auxiliary exact layer identity and does not replace actual receiver dx.

For the true B_H gate, set W_H(r)=1{J(r)>=H}F(r), with H>0. This is also right-continuous nondecreasing. If J(b)<H it is zero. Otherwise tau=inf{r in[a,b]:J(r)>=H} is attained by right continuity and

B_H(row)=tau^(-n)F(tau)+integral_(tau,b] r^(-n)dF(r).

The first term is the FULL crossing initialization, not merely Delta F(tau), and it survives continuous threshold crossings as well as jump-over/land-on-H atoms. At tau=a it includes the a endpoint; at tau=b it is the full b terminal term. No physical time/deletion atom identification follows from this auxiliary threshold mass.

## Budget meaning and the missing actual saving

These are valid exact identities for the original B_H, but are the same monotone joint-variance potential mechanism already encountered in R304. Their right side is nonnegative and still carries the original physical r^(-n) normalization and both original sources. No new source-root expense has been proved merely by writing dF as innovation. Original FIRST controls the aggregate receiver density and pays the global first moment by A_n Wnu; same-selected-radius hard caps control captured source mass, not a small factor for cube disagreement or source mass in thin boundary layers. The new identities do not by themselves improve B_H<=A_n Wnu. This is not an impossibility theorem; it is the precise present proof gap.

To change the budget, a further actual-source geometric estimate must control BOTH the scale-weighted crossing initialization tau^(-n)F(tau) and the subsequent integrated internal-variance/drift innovations, after beta integration, by a root-level source expense (or by a rigorously matched original finite-target absorption plus source fee). One sufficient type is a genuine weighted agreement saving Q<=epsilon J M on the relevant original high layers, with epsilon=O(A_n^(-1/2)); alternatively a new cross-row/scale overlap or routing estimate must retain the actual common source and r weights and prove an equally strong integrated saving. A bound for one radius, one receiver row, or unweighted monotone chain is not such a global certificate. Fractional capture means may not be declared deterministic to erase internal variance.

## Actual bounded diagnostics

{'atomic_ANOVA': 567, 'layer_Stieltjes': 27, 'threshold_initialization': 135, 'conditional_variance_guard': 1}

Executed exact Fraction atomic identities, layer/threshold receipts and a conditional-variance guard. All PASS. These finite scalar capture fixtures verify algebra, not realization of the original selected full-soft kernel/history or root budget for arbitrary original sources. Author comparison and final delivery binding remain pending.

## Additional independently screened initialization SOURCE payment

Before reading any new R313 author proof, independently checked the parent's sharper crossing estimate. This is a real additional partial source price, not merely the preceding Stieltjes rewrite. At first crossing tau with h=mu_y{tau}>0, let j=J(tau-), p=A(tau-)/j (zero if j=0), v=Delta A/h. Always j<=H, NOT necessarily j<H: a continuous prefix can approach H followed by a positive jump at tau. Exact block variance gives

F(tau)-h integral v(1-v)nu
 =j integral p(1-p)nu + jh/(j+h) integral(v-p)^2nu
 <=j integral[p+v^2]nu.

Past actual receiver radii are <=tau and original SAME-radius caps give integral p nu<=4lambda tau^n. The cross block comprises actual accepted receivers of radius exactly tau, so integral v^2nu<=integral vnu<=4lambda tau^n. Consequently

0<=tau^(-n)[F(tau)-h integral v(1-v)nu]<=8lambda H.

If h=0, continuous crossing has J(tau)=H and full tau^(-n)F(tau)<=4lambda H. At tau=a,j=0 the excess is exactly0; tau=b, landing at H, jumping across H and j=H endpoints remain covered. No cap at virtual cubes, source density or nu<=beta is needed. Joint measurability follows from original cumulative row fields and their left limits; tau is a measurable first crossing, and block means are defined by measurable ratios only on positive masses.

Thus BH initialization except its genuine radius-atom intrinsic part is paid once by8lambda H Wbeta. This can be root order for the original H choice, with original lambda d/aspect/outer factors retained. The radius-atom intrinsic h integral v(1-v), plus subsequent weighted innovations, remain exact and unpaid. These are radius-pushforward atoms, not deletion/history-time I/J/D atoms. This source fee may be combined with the old small-J fee only by explicitly adding its constant, not declaring the original full BH paid.

Actual new Fraction diagnostics PASS: 5103 initialization/excess cap inequalities, including 2187 j=H prefix cases. Scalar profiles satisfy the displayed source-moment assumptions; these are not claimed as full original kernel/history realizations.

## Sharper common-quota first-initialization payment: independent screen

The parent's stronger quota mechanism also PASSes before author-file comparison. At a crossing atom h>0, release a deterministic fraction theta0=(H-j)/h in[0,1] of the ENTIRE true receiver block, the SAME fraction for all z. Past capture plus this fractional block has actual row mass exactly H, auxiliary capture A_H=A(tau-)+theta0 Delta A, and auxiliary variance F_H=integral(A_H-A_H^2/H)nu. This is a true submeasure of original U dx; no virtual cube or favorable independent z selector is used. Its source moment is bounded by original accepted-radius caps:

F_H<=M_H<=4lambda tau^n H.

Monotonicity of the variance under adding the rest of the same true block gives F(tau)-F_H>=0. Thus the EXACT original boundary fee is

BH(row)=tau^(-n)F_H
 +tau^(-n)[F(tau)-F_H]+integral_(tau,b]r^(-n)dF(r).

For nonatomic crossing use F_H=F(tau), for j=H at a positive atom use theta0=0, and for tau=a use j=0. Endpoint tau=b and landing exactly on H are included. No-cross rows contribute zero. All post-H rank increments, including intrinsic cross-atom variance and drift, remain in the nonnegative bracket; it cannot be discarded. Original BH uses original J and its original gate throughout; auxiliary J=H is only an accounting state, not a recomputed input or replacement denominator in the target.

Consequently BH<=4lambda H Wbeta+B_after_rank. In the original R302 bound this yields, at H=sqrt(dAn/(4lambda)),

T_target<=4sqrt(lambda dAn)(2Wbeta+Wnu)+2B_after_rank.

This is a new genuine root-priced auxiliary initialization contribution, with all original d/aspect/outer costs still present. It does not assert the entire new bound is better than the8lambda decomposition because its residual differs. Atom labels are physical-radius rank parameters, not historical deletion/clock atoms. New Fraction quota diagnostics PASS5103 cases.

## Author comparison

After the independent screens above, read full /tmp/r313_geometry.md and final /tmp/r313_innovation.md. PASS in their stated scopes. Innovation note retains the correct continuum conditional variance (including singular-continuous radius mass), whole scale atoms, threshold gate initialization and j<=H endpoint. Its wording now explicitly permits common quota refinement with every complementary innovation retained. The final 4lambdaH rank initialization exactly matches the independent construction; its8lambdaH whole-atom alternative remains separate. Neither residual ordering nor a global root bound is asserted.

All substitution constants check. At original H0=sqrt(dAn/(4lambda)), common rank gives4sqrt(lambda dAn)(2Wbeta+Wnu)+2B_after; whole atom gives4sqrt(lambda dAn)(3Wbeta+Wnu)+2(C_H+D_H). Optimizing the displayed common-rank source coefficients uses H=sqrt(dAn/(8lambda)), with4sqrt(2lambda dAn)(Wbeta+Wnu); whole-atom uses H=sqrt(dAn/(12lambda)), with4sqrt(3lambda dAn)(Wbeta+Wnu). Mass-balanced alternatives and zero-source conventions are valid, and their residuals stay at the SAME selected H. No unqualified first moment is silently replaced by the original target T. All original outer factors/aspects remain. Radius-pushforward atoms are not historical I/J/D deletion atoms.

Geometry note's direct clipped-capacity quota formula is also correct. Every actual radius atom uses a COMMON theta release for every z, yielding min(d,A_post)-min(d,A_pre)=integral1{A_theta<d}dA_theta. Continuous/singular-continuous capture increments satisfy the same chain rule; equality thresholds have zero capture-increment mass after refinement. Common atoms of A are dominated by the row radius measure, so no independent source-specific radius ordering is hidden. Positive Tonelli preserves actual r^(-n) and the terminal b atom. Its O_before<=4lambdaH Wbeta includes the crossing fraction and exactly retains N on J^o>=H,A^o<d. N is an auxiliary exact allocation of O_d, NOT an exact allocation of original T, whose bridge is only T<=2O. The low capture ratio in this quota does not furnish a small probability conditional on capture.

The optional positive-dilution d/H first-moment estimate in the quota note is valid by exchanging old capture increments and using nondecreasing physical radius, but the authors explicitly discard it as weaker than the exact clip. It is not booked as a new source improvement. Likewise monotone-chain crossing counts do not supply missing cross-row quota congestion.

The historical note correctly limits its search to saved R300--311 reports; its existing clipping/high-capture identities do not establish a root payment for the new remainder. I make no exhaustive historical novelty certification. The inspected numeric note uses actual positive-volume L1 source boxes and exact real cube intersections, while receiver weights remain finite arbitrary occupation fixtures; its large variance/clip ratios diagnose loss of clipping without claiming an original FIRST realization, dimension lower bound or cube weak-type counterexample.

Current author bindings:
- /tmp/r313_geometry.md: d51378774b1a6a8bf2ce22771395d9bec6fd2fbe0ea27ec96792a65ed6c81360
- /tmp/r313_innovation.md: 73b63f56b36ec01b6e0a729b73b20f24f87e2c4b985943b048e8e7f54ce74c92
- /tmp/r313_history.md: ffee56f742804379d805520f68e8fe426bb9764156c455c3ab547098f42e4d7e

## Final integration and execution evidence

Read final checkpoint combined.md, research.tex and README. PASS: the common-quota initialization formula and entire post-rank remainder agree with the detailed author proof; original J/target gates are not replaced by quota J. The full local R302 back-substitution is16lambdaH Wbeta+(2d/H)An Wnu+2B_after(H), and at H=sqrt(dAn/(8lambda)) its explicit fee is4sqrt(2lambda dAn)(Wbeta+Wnu). The threshold-dependent residual remains evaluated at the selected H. The alternative old-H and whole-atom formulas are separate and do not assert total-bound ordering. All original lambda d/aspect/outer/source costs remain.

The final documents distinguish the R302 full variance from the R303 near-window numerator with its FULL denominator J. The new exact innovation identity must not be silently applied to a different near-only J; positive enlargement to the full fee is possible but must keep the enlarged residual explicit. Old global X_old, width/extreme-aspect, initial I_rem, deletion-time J_rem, future-deleted D_rem, suffix and once-only negative slots remain separate. The complete adopted absorption table and original entry bridge are still uncertified. R312 native alternative/corridor is not added to this old ledger. New initialization source payment does not pay historical I/J/D atoms or produce a new global epsilon-X entry.

Actual evidence inspected: checkpoint quota_checks.log reports108 quota+108 split+108 early-cap+198 rank=522; innovation_checks.log reports25 density+56 atom+72 threshold+72 whole warmstart+72 common rank=297; numeric_checks.log and frozen JSON report4192 exact checks in634/1788/1770 stages. Final JSON SHA256fc19bcca5b5ca631878495055263d24c229ec08033744ae064310d86b51f0369 matches the parent's byte-equality receipt. The parent confirms fresh separate-process runs. This auditor actually executed its separate exact cases recorded above; parent runs are not mislabeled as a second audit execution. No redundant final reruns were needed.

Finite numeric source boxes and cube intersections are genuine positive-volume L1 geometry; receiver occupation weights remain quadrature fixtures, not certified original full-soft/FIRST/history realizations. Large F/clip ratios are not weak-type counterexamples or dimension-order evidence. The quota identity is a useful exact accounting refinement but is not counted as a new root source theorem. The truly new paid piece is the threshold initialization source fee, while B_after or the sharper first-d quota N remain without a cross-row root source budget.

Final bounded verdict PASS. No unresolved mathematical correction to the delivered local statements remains. General root weak bound and every listed original global/outer/source slot remain open. Audit FROZEN.

### Final byte bindings
- /tmp/r313_innovation.md: 73b63f56b36ec01b6e0a729b73b20f24f87e2c4b985943b048e8e7f54ce74c92
- /tmp/r313_geometry.md: d51378774b1a6a8bf2ce22771395d9bec6fd2fbe0ea27ec96792a65ed6c81360
- /tmp/r313_history.md: ffee56f742804379d805520f68e8fe426bb9764156c455c3ab547098f42e4d7e
- /tmp/r313_input_302.md: a66a045f1917a426e816ca137607290090bd40865c6309e5e25be3a795916d6e
- /tmp/r313_input_303.md: d32113b1bf00e020774a2b8626164aeb2533ce2494d287088b087787b1d0473a
- /tmp/r313_input_310.md: 9fbfc56255ef4429184ede082930c42809fb6820c5f4531c66d9f3227a625305
- /Users/zhengzhihao/Desktop/T/output/centered_cube_round313_20261018_final_checkpoint/combined.md: 02e82b0ae765cc7155dd42354162f138cb9d3e03b43251070bd65b8d51d0712d
- /Users/zhengzhihao/Desktop/T/output/centered_cube_round313_20261018_final_checkpoint/research.tex: 1e5d2687e47efc110252b06096be5bc4ed770ec0feba8385e9cca54e7f70a2a4
- /Users/zhengzhihao/Desktop/T/output/centered_cube_round313_20261018_final_checkpoint/README.md: 0a951f25ae8ca7bf7771c565fd6bddf3c3e2f1185bacc2607c0800514e39dcf7
- /tmp/r313_numeric.py: 39a1c087d32435eecc257e087168bbf37211a797d2d795e3826cd079ee2c86d2
- /tmp/r313_numeric.json: fc19bcca5b5ca631878495055263d24c229ec08033744ae064310d86b51f0369
- /tmp/r313_numeric.md: 682eebfb697ad52359ad14518ad24e04b57e47defc0be02472dc95735f70d899
- /Users/zhengzhihao/Desktop/T/output/centered_cube_round313_20261018_final_checkpoint/numeric.py: 39a1c087d32435eecc257e087168bbf37211a797d2d795e3826cd079ee2c86d2
- /Users/zhengzhihao/Desktop/T/output/centered_cube_round313_20261018_final_checkpoint/quota_checks.py: a23469e06860e8f83f30e6e288507ee3876e31ce3f0f8cb423d9a2a74ae4ceee
- /Users/zhengzhihao/Desktop/T/output/centered_cube_round313_20261018_final_checkpoint/innovation_checks.py: a0705280d9f6a96149816e56da195ad08862f292275caf1f54794626691855ab
- /Users/zhengzhihao/Desktop/T/output/centered_cube_round313_20261018_final_checkpoint/numeric_checks.log: f1d964f586aeeccb51e3b7fc30dba4390be4977b6ef07c82537d9dc94ca6b276
- /Users/zhengzhihao/Desktop/T/output/centered_cube_round313_20261018_final_checkpoint/quota_checks.log: da6bb9dc363b36a3b3d4ab9f1018329964d1fc21f01bb043fd1caee164f98ed0
- /Users/zhengzhihao/Desktop/T/output/centered_cube_round313_20261018_final_checkpoint/innovation_checks.log: 4d4f1a8d3f9c331b6bec28d17b1f34b8dddcde099a88d87d26461e3fd0edb73e
