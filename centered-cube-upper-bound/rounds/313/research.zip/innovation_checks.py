from fractions import Fraction as F
from itertools import product
R=[F(1),F(1),F(3,2),F(2)];levels=sorted(set(R))
nu=[F(1,4),F(1,3),F(5,12)]
profiles=[[F(1,4),F(1,2),F(1,4),F(1,2)],
 [F(0),F(1),F(1),F(0)],[F(1),F(0),F(0),F(3)],[F(0)]*4]
patterns=[[[1,0,1],[0,1,1],[1,1,0],[0,0,1]],
          [[1,1,0],[1,1,0],[1,1,0],[1,1,1]]]
ct=dict(continuous_density=0,atom_jump=0,threshold_identity=0,warmstart=0,rank_split=0)
for p,v in product([F(0),F(1,4),F(1,2),F(3,4),F(1)],repeat=2):
 assert v-2*p*v+p*p==v*(1-v)+(v-p)**2
 ct['continuous_density']+=1
for n,U,cap in product([1,2,8,32],profiles,patterns):
 lam=max(sum(nu[z]*cap[i][z] for z in range(3))/(4*R[i]**n)
         for i in range(4))
 J=F(0);A=[F(0)]*3;Fprev=F(0);blocks=[]
 for r in levels:
  inds=[i for i in range(4) if R[i]==r];h=sum(U[i] for i in inds)
  if not h:
   blocks.append((r,J,Fprev,F(0),F(0)));continue
  v=[sum(U[i]*cap[i][z] for i in inds)/h for z in range(3)]
  t=[a/J for a in A] if J else [F(0)]*3
  intrinsic=h*sum(nu[z]*v[z]*(1-v[z]) for z in range(3))
  pred=J*h/(J+h)*sum(nu[z]*(v[z]-t[z])**2 for z in range(3))
  newA=[A[z]+h*v[z] for z in range(3)];newJ=J+h
  Fnew=sum(nu[z]*(newA[z]-newA[z]**2/newJ) for z in range(3))
  assert Fnew-Fprev==intrinsic+pred
  ct['atom_jump']+=1
  blocks.append((r,newJ,Fnew,Fnew-Fprev,intrinsic))
  J,A,Fprev=newJ,newA,Fnew
 for H in [F(1,4),F(1),F(2),F(4)]:
  BH=sum((r**(-n)-(levels[k+1]**(-n) if k+1<len(levels) else 0))*FF
   for k,(r,JJ,FF,dd,ii) in enumerate(blocks) if JJ>=H)
  cross=next((k for k,B in enumerate(blocks) if B[1]>=H),None)
  if cross is None:
   assert BH==0;continue
  r,Jc,Fc,delta,ic=blocks[cross]
  assert BH==r**(-n)*Fc+sum(B[0]**(-n)*B[3] for B in blocks[cross+1:])
  ct['threshold_identity']+=1
  assert r**(-n)*(Fc-ic)<=8*lam*H
  ct['warmstart']+=1
  j0=sum(U[i] for i in range(4) if R[i]<r);h0=Jc-j0
  old=[sum(U[i]*cap[i][z] for i in range(4) if R[i]<r) for z in range(3)]
  inc=[sum(U[i]*cap[i][z] for i in range(4) if R[i]==r) for z in range(3)]
  fraction=(H-j0)/h0 if h0 else F(0)
  AH=[old[z]+fraction*inc[z] for z in range(3)]
  FH=sum(nu[z]*(AH[z]-AH[z]**2/H) for z in range(3))
  v0=[a/h0 for a in inc] if h0 else [F(0)]*3
  remaining=Jc-H
  innovation=remaining*sum(nu[z]*v0[z]*(1-v0[z]) for z in range(3))
  innovation+=H*remaining/Jc*sum(nu[z]*(v0[z]-AH[z]/H)**2 for z in range(3))
  assert Fc-FH==innovation>=0 and FH<=4*lam*r**n*H
  after=r**(-n)*innovation+sum(B[0]**(-n)*B[3] for B in blocks[cross+1:])
  assert BH==r**(-n)*FH+after
  ct['rank_split']+=1
print('PASS',ct)  # actual: 25, 56, 72, 72, 72
