# R313 finite real-cube clipping diagnostic

The standalone standard-library script uses exact `Fraction` arithmetic. It partitions each positive-volume uniform source box by every witness-cube boundary, integrates the resulting constant capture patterns, and separately verifies all one-cube and two-cube intersection masses by tensor interval intersection. Overlapping source boxes represent the sum of their densities. `Q_R` has side length R, hence halfwidth R/2.

All 4,192 assertions pass: initial 634 (two one-dimensional cases), pressure 1,788 (four one-dimensional cases), expanded 1,770 (n=2,4,8, four cubes each). Receiver weights have scales 1,16,256; d is 1/16,1,16. There are 216 prefix clip comparisons, 307 exact finite-layer high-prefix comparisons, 72 grouped-atom ANOVA identities, and 177 first-crossing initialization checks. The largest source partition has 10,937 positive-volume cells, compressed to five capture patterns without changing integrals. JSON contains geometry, actual source mass, partition ledger, and every summarized prefix/budget.

For each prefix, J=sum h, A=sum h capture, M=integral A, F=integral A(1-A/J), C=integral min(d,A), E=integral [min(d,A)-dA/J]_+. Zero J is treated as zero. Checks include the independently computed pair-disagreement identity, nonnegativity, E<=F, E<=C, and C<=dM/J+E. Radius layers have exact weight r^(-n)-r_next^(-n), with terminal atom 2^(-n), and the gate J>=H is inclusive. The script checks both old and new high-prefix fees without assuming any FIRST-derived global source bound.

A nondegenerate one-dimensional separated-cube example has source uniform on [-2,2] with mass 1, witnesses of side 1 centered at -1 and 1, and weights 256 each. With d=1/16: J/d=8192, F=64, C=1/32, E=1/64. Thus F/C=2048 and F/E=4096. The cubes cover distinct positive-volume source regions. At the same geometry with d=1, increasing weight scale 1,16,256 gives F/C=1/2,8,128 respectively. This isolates loss of the clipping scale rather than a dimension trend.

In the n=8 expanded case at the final prefix and scale256,d=1/16, J/d=28672, F=21921152/45927, C=3/32, E=3517/122472. Hence F/C=701476864/137781 (about 5091.245), F/E=175369216/10551. Duplicated cubes and the single-positive-weight case instead have F=E=0. These diagnostics support retaining d clipping in the finite geometric relaxation; they give no dimension-order conclusion.

ANOVA uses the entire same-radius atom simultaneously: if its mass is h and its source capture fraction is v, while the earlier prefix has mass J and fraction t, then F_post-F_pre = h integral v(1-v) + Jh/(J+h) integral(v-t)^2. Zero prefixes and zero-weight blocks are included. For initialization, lambda=max_i nu(Q_i)/(4 R_i^n) enforces the actual same-radius hard caps. At the first inclusive crossing Jpost>=H, all 177 cases satisfy Fpost-h integral v(1-v)<=8 lambda Rcross^n H, with Jprev<H. The tested thresholds include exact atoms Jpost=H and crossing blocks h>=8H. The same 177 crossings also use common fractional release theta=(H-Jprev)/h, A_H=Aprev+theta(Apost-Aprev), and verify 0<theta<=1, 0<=F_H=integral(A_H-A_H^2/H)<=4 lambda Rcross^n H, and Fpost-F_H>=0. This rank initialization retains the full original atom variance in the remainder. The constant-8 whole-atom residual and constant-4 fractional-release statements are distinct. Subsequent correlation/post-crossing fees are not paid by these checks.

Scope: the source is genuinely positive-volume L1 and the cube containment/intersection geometry is actual. The receiver side is finite nonnegative quadrature, not a realization of original FIRST, full low/e/m history, forest selection, or all-input closure. The arbitrary scaling of receiver weights is a diagnostic interface, not evidence that those weights can occur in an original selected row. Native FIRST applicability is established elsewhere analytically; this script neither verifies nor replaces it.

Reproduce in a fresh process:

```
/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 /tmp/r313_numeric.py
```

The JSON is written beside the script. There are no external packages, random draws, timestamps, imports of prior temporary scripts, floating-point certificate decisions, or repository changes. Decimal ratios in this note are descriptive; all assertions use exact fractions.
