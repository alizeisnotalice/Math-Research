# R277 independent likelihood-route screening

**Verdict:** the fractional-moment bound and a finite all-parameter positive-kernel cover are rigorous. They do not presently pay a new root-order branch: the weighted affinity/source-score budget, including the terminal inverse clamp weight, still requires proof. This screen was completed before reading any R277 author output.

Only the original definitions in the previously read R117 JG1–6 are used: common actual same-soft targets, Q=(K1+K2+J)/3, original terminal good/bad, terminal high, and the x-independent full posterior at fixed (omega,V,j,y,t). No author proof was read and no repository/Git/PDF was changed.

## 1. Correct factor and exact joint-cut scope

Fix physical parameters and a terminal g with positive degree. As functions of the receiver x, let `p=P_{s,L}(x-y)`, `Q_v=(K1_v+K2_v+J_v)/3`, and similarly Q_u. Fix `a_v=w_g(y,v)>0`, `a_u=w_g(y,u)>0`, K,q>0, and a number `0<theta<1`. Put

`G_v={p a_v<=K Q_v}`, `B_u={p a_u>K Q_u}`, `Hi={p e_g>=2Kq}`.

The original terminal-carrier indicators must also be retained. For any original nonnegative mask `0<=Gamma<=1`, define the actual fixed-parameter cut mass

`C=integral p Gamma 1_Hi 1_Gv 1_Bu dx`.

Then

`C <= (K/a_v)^theta integral p^(1-theta) Q_v^theta Gamma 1_Hi 1_Bu dx`

`<= (K/(3a_v))^theta sum_{i=1}^3 integral p^(1-theta) K_i,v^theta Gamma 1_Hi 1_Bu dx`.        (L1)

One can also take the minimum with `integral p Gamma 1_Hi 1_Bu`. The bad/high gates are in the same receiver integral; neither is independently averaged or given a new cap. Positive removal is an upper bound, not an equality to the original cut.

The factor is **3^{-theta}**, because `(K1+K2+J)^theta<=K1^theta+K2^theta+J^theta`. It cannot be replaced by 1/3 in a general nonnegative-leg inequality; concentrating the scalar sum in one leg forces the coefficient 3^{-theta}. The alternative argument that some leg exceeds `p a_v/K` is valid but pays the weaker factor K^theta rather than (K/3)^theta.

For fixed parameters every p and K_i is a normalized product density, so the unrestricted leg affinity

`H_theta(p,K_i)=integral p^(1-theta)K_i^theta dx`

factors into one-dimensional integrals and is at most 1 by Holder. This is a statement about receiver integration, not source-coordinate independence. The mixture affinity before splitting is also at most 1 but need not factor. The prefactor `(K/a_v)^theta` is not automatically small; a_v may be tiny. Thus Holder's bound by 1 alone gives no useful root-order traffic price.

The exact joint cut also forces the strict oriented inequality `Q_v/a_v>Q_u/a_u`. Keeping it or keeping B_u in L1 may preserve additional geometry. Good Markov by itself does not exploit it. Introducing a negative power of Q_u via a second Chernoff factor creates a different integral and requires an actual integrability/capacity proof; it is not an ordinary two-density affinity bound.

## 2. Endpoints, zero cases, and original high

- The Markov inequality is used on p>0. Where p=0 the original p-weighted receiver mass is zero; no likelihood ratio is needed there. Positive powers at zero are defined normally.
- The actual Q is strictly positive because its J leg is positive at finite positions. In a more general nonnegative-target formulation, Q_v=0 makes good impossible when p,a_v>0; Q_u=0 merely makes bad true. L1 never divides by Q_u.
- The actual pure clamp weights are positive for finite positions. A hypothetical a_v=0 needs a separate branch and is not covered by the inverse-weight formula.
- The closed good endpoint, strict bad endpoint, and inclusive high endpoint are kept. There is no probability-one argument discarding a positive receiver level set.
- The kernel inequalities with positive powers cover s=0 and s=1. At s=0, p can vanish outside its hard support; this is handled by zero p-mass, not by inventing a finite log p. No lower soft bound is added or removed from the original remainder.
- Original high is terminal `p e_g>=2Kq`, not `p e_t>=2Kq`. It can be retained as in L1 or removed positively. It cannot be used to cancel an earlier-time inverse degree without the actual weight/degree ratio.
- The theta and parameters in the unrestricted affinity calculation are fixed before the receiver integral. An arbitrary receiver-dependent choice is not bounded by a single fixed affinity.

## 3. A precise finite-cover bridge from R276

There is a valid uniform *positive-power* cover, distinct from merely centering the net-count statistic. Let gamma=1+1/n and `c_n=gamma^n<e`.

Use R276's n common soft nodes `sigma=k/(n+1)`, and at most n+1 upward scale nodes for each input scale and target scale. For an actual same-soft pair p,K_i,

`p<=c_n^2 p_node`, `K_i<=c_n^2 K_i,node`,

hence

`p^(1-theta)K_i^theta<=c_n^2 p_node^(1-theta)K_i,node^theta`.               (L2)

For J the fixed target needs no node, and the same c_n^2 is safe. This is why the R276 density cover can be used for these fractional products. Its concentration-about-a-mean conclusion is not itself a likelihood-ratio theorem.

The actual denominator a_v=w_{g(x)}(y,v) remains receiver-dependent. For a nonempty original j band, g lies in `[a/c_j,b c_j]`, whose endpoint ratio is at most 2. Put a separate upward gamma mesh G on this interval, with at most n+1 nodes. Pure clamp monotonicity gives

`w_g(y,v)^(-theta)<=w_G(y,v)^(-theta)`.

The right side is now static at a fixed menu node, but it has **not** been bounded by 1 or by FIRST. The clamp ratio between neighboring nodes is at most c_n, if such a comparison is later needed. Pure weights are defined for every source; this does not grant a new terminal carrier or a new good set at G.

A safe envelope has at most `n(n+1)^3` tuples `(sigma,input-L,target-A,G)`. For example, after splitting the original three legs one may use

`sum_nodes w_G(y,v)^(-theta) p_sigma,L(x-y)^(1-theta)`

`   * [2 P_sigma,A(x-v)^theta + P_1,b(x-v)^theta]`                         (L3)

multiplied by `c_n^2 (K/3)^theta`. The repetition of the J term over the target-scale nodes is conservative, not free. Coupled physical menus may reduce the count but are not assumed here. The soft nodes can be backward relative to actual s; they are analytic envelopes only and are **not** certified current/future FIRST parameters.

In the original positive mother integral, one can first apply the actual receiver hardcap, then use L3, remove the original positive pair masks, and integrate the other posterior slot using

`integral (k_t(v)-k_t(u))_+ Pi_t(du)<=k_t(v)`.

This gives the explicit sufficient upper-bound interface

`P_current <= (32 Lambda/3)c_n^2(K/3)^theta E sum_{V,j}`

` integral beta_V(dy) integral_band dt/t integral Pi_{j,y,t}(dv) k_t(v)`

` * sum_nodes w_G(y,v)^(-theta) [2H_theta(p_sigma,L,y,P_sigma,A,v)+H_theta(p_sigma,L,y,P_1,b,v)]`.       (L4)

Here P_current includes its original outside 2 Lambda. The factor 16/3 comes from the original hardcap/q, used before expanding x. The complete posterior remains the original one, held fixed before the receiver integral. No inverse degree is deleted: it remains in Pi_t. No target-node FIRST is used. The original positive masks can be retained for a stronger bound, but then their receiver dependence must also remain.

L4 is a genuine usable finite-cover target: a proved normalized, score-weighted source bound for its right side would imply a corresponding actual traffic bound, with polynomial menu and clock fees visible. It is not yet such a bound. Substituting `H_theta<=1` leaves precisely `integral k_t w_G^{-theta} dPi_t`, which can carry the old heavy/terminal-loss cost. Optimizing theta, summing nodes, or using original FIRST cannot silently remove that inverse weight. The bad-source likelihood geometry was dropped in this safe cover; it has not been paid through an alleged source independence.

## 4. What a new root route still needs

A nontrivial advance would be a uniform bound on a retained joint-cut affinity (including its bad/high/oriented ratio gate), or a source-weighted bound for L4 that pays its terminal inverse weights, score, full clocks, and node sum. Original FIRST only controls actual unweighted target source mass. R276's already paid fluctuation event may still be removed once, but does not alone bound this new fractional likelihood integrand. Any factor exponential in a normalized loss, any input-mass ratio, or a soft-grid norm must stay in the actual source budget until proved payable.

The current note does not certify a newly paid root-order branch. It preserves the original source collection, full posterior, terminal classification and signed-credit ledger, and stops at the explicit finite-cover interface.

## 5. Actual bounded arithmetic diagnostic

A local mp50 run passed **54 finite probability-array assertions** checking the joint-cut Markov inequality, the exact 3^{-theta} splitting coefficient, and affinity<=1 for theta in {.25,.5,.75}, K in {.1,1,4}, and terminal weights in {.1,.7}. These artificial positive normalized arrays test algebra only; they are not physical kernels, interval certificates, or original FULL instances. The proof is analytic above. Reproduce with the local mpmath vendor path if needed:

```python
import mpmath as m
m.mp.dps=50
p=[m.mpf(k)/28 for k in range(1,8)]
legs=[[p[(j+r)%7] for j in range(7)] for r in (1,2,3)]
qu=[(legs[0][j]+2*legs[1][j]+legs[2][j])/4 for j in range(7)]
qv=[sum(K[j] for K in legs)/3 for j in range(7)]
checks=0
for theta in map(m.mpf,['.25','.5','.75']):
    for K in map(m.mpf,['.1','1','4']):
        for wv in map(m.mpf,['.1','.7']):
            wu,q,eg=m.mpf('.4'),m.mpf('.2'),m.mpf(1)
            good=[p[j]*wv<=K*qv[j] for j in range(7)]
            bad=[p[j]*wu>K*qu[j] for j in range(7)]
            high=[p[j]*eg>=2*K*q for j in range(7)]
            gate=[bad[j] and high[j] for j in range(7)]
            mass=sum(p[j] for j in range(7) if good[j] and gate[j])
            mix=(K/wv)**theta*sum(p[j]**(1-theta)*qv[j]**theta
                                      for j in range(7) if gate[j])
            split=(K/(3*wv))**theta*sum(
                sum(p[j]**(1-theta)*leg[j]**theta
                    for j in range(7) if gate[j]) for leg in legs)
            assert mass<=mix+m.mpf('1e-45')
            assert mix<=split+m.mpf('1e-45')
            assert sum(p[j]**(1-theta)*qv[j]**theta
                       for j in range(7))<=1+m.mpf('1e-45')
            checks+=3
print('PASS',checks)
```
