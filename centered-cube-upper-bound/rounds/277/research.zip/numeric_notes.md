# R277 actual Chernoff-affinity probe

Executed with bundled Python3.12.14 and mpmath1.3.0 vendor. Replay: `PYTHONPATH=/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor /Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 /tmp/r277_numeric.py --output /tmp/r277_numeric.json`.

The bounded three-stage menu has6 physical geometries and18 leg-labelled rows (6/6/6), retaining same-L, same-Lplus and fixed phi_b targets. There are15 unique whole-line integrals per precision; clipping/pure-phi duplicate legs are cached and not counted as independent computations. Theta=.5,.25,1/16; soft0,.5,1 and nearzero1e−6/.01; displacement0,.25,.5,1,2,4; equal and unequal L/R are represented. Twelve leg rows have active C<m.

C is the integral of max(h,phi) over the displacement window, evaluated as exact hard-overlap length plus E4 soft primitives. Every noncompact affinity integrates both infinite tails directly; no finite cutoff was substituted. Compact support for s0 is used exactly. Hard and phi core endpoints split finite integrals. Numerical agreement of198 fields at40/60 is 2.960898517326826326950933914814605525665793740411835420446240000000000000000000001530785712921920333e-41; ordinary mpquad tail arithmetic is not an interval certificate.

Decisive positive regime: s=.5,L=R=b1,r=.5,theta=.25,m1,w=.628034991114724. Moving same-L H=.890605691356531 and logH−theta logw=+.00043635329212977549. Lplus clips to the same leg. J has H=.923889620051091 and gain+.037127175637258400. Thus3 positive leg rows correspond to2 distinct positive integrals. The exactly identical hard baseline has gain0.

Other sampled regimes have negative gain. Nearzero soft1e−6,L.5,R1,r1,theta.5: moving gain−7.30331 and J gain−.743887. At r2,theta1/16,s.01,L.75,R.5: moving−.385934,J−.0628658. At r4,theta1/16,s.5,L.5,R.75: moving−.313599,J−.0305971. These signs locate finite kernel regimes and do not establish a universal sign or dimension-order law.

The terminal clamp uses physical m=min(L,R), not an asserted original c_j approximation qualification. A positive exponent gain is not a counterexample to the original FULL budget: no source law/FIRST/high/history constraints were constructed or certified.

Source SHA256: 8811e897751768966c43c696926cc4d45181ff8ca4bd4b3bd19b5542024bd757

JSON SHA256: cff2f818c97511e232ca6c0c6b1d2846cb93387d5c1c74e027d25aa92cf3d32d
