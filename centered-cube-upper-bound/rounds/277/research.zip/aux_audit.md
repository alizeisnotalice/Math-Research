# R277 independent auxiliary audit

Verdict: no blocking formula, constant, support, or scope error found in K2–K8 or the screened finite-cover interface. This audit does not certify the main J final payment, an adaptive source/clock budget, or FULL. The two supplied code blocks were extracted without mathematical edits into a standalone replay script and actually executed locally. The old18-row and7-row window suites were not rerun.

## Proposition/support screen before proof

K2 is only for0<theta<=1/4; K3 extends to0<theta<1 with q_theta=min(theta,(1−theta)/3). There is no theorem at theta0 or1 hidden in a logarithmic convention. Hard s0 is supported on its genuine interval; positive-power Holder arguments are legitimate and disjoint hard supports have H=0,logH=−infinity. No log f0 outside its support is used. L<=A<=b,0<s or s0,0<=sigma<=1 are respected. The actual clamp parameter needs0<m<=b; in the stated original band min(L,R)<=m<=gamma min(L,R), not the reversed inequality.

## K2–K3 constants and interpolation

f_s<=exp(.5)exp(−abs x) includes both endpoints s0 and1: f_s<=1 on the hard core, and phi inherits the exponential envelope outside. At quarter power, f_s^(3/4)exp(c abs z/4)<=exp(3/8)exp(−abs z/2) for c=L/A<=1, giving integral<=4exp(3/8). Interpolating this integrand with f_s gives exponent4theta. Target-envelope factor exp(theta/2) combines with exp(3theta/2), yielding C0=4^4 exp2=256exp2. Rescaling contributes(L/A)^theta and displacement exp(−theta abs r/A). Holder supplies the independent cap1.

For theta>1/4, p^(1−theta)k^theta is a Holder combination of p^(3/4)k^(1/4) and k with weight4(1−theta)/3. This gives q_theta=(1−theta)/3, not theta; K3 correctly retains the possibly uncancelled far-radius growth. No universal normalized-affinity cap1 is asserted.

## K4–K6 lower envelope, actual m and tensor

The selected radial interval has length1/[2(1+x)] and gives w(x)>=exp(−x−1)/[2(1+x)]. Two integrations over unit hard cores yield phi(x)>=exp(−3/2)exp(−abs x)/[3(1+abs x)] and C(D)>=(2exp(−2)/9)exp(−D)/(1+D). Constants therefore give Cstar=C0/c0=1152exp4. Active-clamp division contributes m/b and exp(D)(1+D); combining it with K2 leaves exactly Lm/(Ab) and exp(−abs r(1/A−1/b)).

Inactive coordinates cost at most1; active-coordinate second bounds multiply for the fixed product receiver kernel. This uses product receiver density only, not posterior source-coordinate independence. The signed exponent in K6 is valid; dropping negative aspect/radius terms gives the stated weaker active-count bound because L/A<=1,m/b<=1. A separate m0=min(L,R) comparison costs at most gamma^(theta n)<=exp(theta) once; using actual m directly does not incur that fee again. The diagnostic m=sqrt(.99),L=.99,R1,gamma129/128 is compatible with the j0 original band and m<=b.

The no-gain sufficient example A<=b/2,D>=16 is mathematically nonempty but lies at L=A=a=b/2 under the other a,b constraints. It is not an open universal geometry. log Cstar<12 and16−log17>12 justify the displayed coarse threshold. For J,A=b,the residual exponential vanishes; the note correctly keeps its radius cost.

## K7–K8 mixture and tails

K7 splits the three whole tensor kernels after taking the fractional power, so the coefficient is3^(−theta), not1/3 and not3^(−n). No independent coordinate menu is inserted. The screen also correctly keeps all source/FIRST obligations unproved.

For K8, the density envelope product is exp(.5)L^(theta−1)A^(−theta)exp(−lambda abs x−mu abs(x−r)),lambda=(1−theta)/L,mu=theta/A. When B>=abs r, the right and left tail integrals are exp(±mu r)exp(−(lambda+mu)B)/(lambda+mu). Their sum is precisely the stated2cosh(mu r) coefficient. The exact hard-overlap formula also has the correct L^(theta−1)A^(−theta) dimensional factor. The embedded ordinary code checks K3/K5/C lower/hard cases; it does not claim to implement outward interval quadrature or numerically certify K8 tails. K8 remains an analytic positive-tail interface.

## Independent screen

The joint-cut Markov inequality uses p>0 only, retains the same bad/high mask, and divides by positive a_v only. Closed good,strict bad and inclusive high are correct; together they force Qv/av>Qu/au. The finite cover uses common soft nodes and upward scale nodes, product density factor c_n², and a separate upward g-node for inverse clamps. The n(n+1)^3 menu bound is conservative; repeating J over target-scale nodes is explicitly charged. No new node-FIRST, terminal carrier, original posterior, or earlier-time degree cancellation is granted. L4 keeps the original score orientation and inverse weight. This is an interface needing a genuine source-clock budget, not a root result.

## Actual replay

Local bundled Python3.12.14 plus mpmath1.3.0 vendor executed the integrated script successfully. Kernel code:54 assertions total at35/55 digits,8 actual overlap configurations per precision plus4 hard-support cases per precision. Fullsoft r8 normalized overlaps reproduced1.15812543871663319(theta.1),1.58142791073900981(theta.25),6.38104590882887215(theta.5); scaled35/55 difference5.95502177884e−34. Screen code:54 separate finite positive probability-array assertions at50 digits. These54 totals have different meanings; there are not108 actual kernel configurations. None is an interval certificate or FULL input.

Replay: `PYTHONPATH=/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor /Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 /tmp/r277_aux_checks.py`. The script embeds both exact Markdown code blocks, so archive replay does not require their original /tmp paths. Optional `--output PATH` stores its deterministic summary.

Reviewed kernel Markdown SHA256: 734ba002db93df6c6534cf85085e2d83c72b6439ff48f0e4593e8581a3d363e8

Reviewed screen Markdown SHA256: 5789e6d4392a9ce97a84de4393ab2d2bdd9cafa09e159751623779f0f8954f29

Replay script SHA256: b28f2dfbc34badf24ac5843675de495f112623395ea47b7dcc7530b7852dce50
