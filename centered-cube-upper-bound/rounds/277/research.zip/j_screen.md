# R277 independent J-dominated original-positive screening

**Verdict: PASS for the corrected `barw_L` formulation below.** The originally proposed direct invocation of R266 G10 with denominator `barw_b` is not justified by that theorem. Correcting the denominator costs at most an additional `sqrt(c_n)<sqrt(e)` once; all later raw-source and clock accounting then works. This screen was completed before any R277 author proof was read.

## 1. Normalization correction and primary qualification

Write `gamma=1+1/n`, `c_n=gamma^n<e`, `d=a/(8sqrt(n))`, `epsilon_h=d/b`, and

`barw_L(y,v)=product_i min(1,b C(|y_i-v_i|/b)/L)`.

The exact old R266 G10, read narrowly to check its normalization, bounds the half-kernel with denominator **sqrt(barw_L)**. R224's exact-min theorem likewise has m=min(L,b)=L, not b. Since `barw_L>=barw_b`, an estimate for the former does not automatically bound the larger half-kernel with denominator sqrt(barw_b). No falsehood of that strengthened inequality is asserted; it is simply not the cited interface.

The actual original scale band repairs this directly. R229 `adaptive_geometry.md`, AG2, explicitly gives `g=sqrt(LR)` and `c_j/gamma <= min(L,R)/g <= c_j`. Consequently

`c_j g<=gamma min(L,R)<=gamma L`,

and the original pure clamp weight satisfies

`w_g(y,v)>=gamma^(-n) barw_L(y,v)=c_n^(-1)barw_L(y,v)`.       (J1)

This is the known original comparison, not a new FIRST claim. The weaker `w_g>=barw_b` is also true on the original band, but does not fix the G10 interface.

## 2. Fixed-window half-mass and the all-soft menu

Let `J_x(v)=P_{1,b}(x-v)` and `W_y=Q_{b+d}(y)`. R266 G10 and its collar proof give, for every fixed `s in [0,1]`, `L in [a,b]`, and every y,v,

`integral_{W_y} sqrt(P_{s,L}(x-y)J_x(v)/barw_L(y,v)) dx`

`<= exp[-c_J n+exp(c_J)n epsilon_h sqrt(2s)]`,               (J2)

where `c_J=25/(20*2^68)>0`. Its hypotheses hold since `b<=2a` implies L>=b/2. The old G10 is a half-mass estimate, not a squared-kernel estimate; no L^p-to-source conversion is needed here.

For clarity, the collar estimate does cover the whole closed soft interval: outside the source-centered Q_b core the source hard component vanishes. The extra one-coordinate integral is at most `epsilon_h sqrt(2s)` using L>=b/2 and the old pointwise soft-product bound. Thus the core bound `exp(-c_J)` tensorizes after adding this positive collar. This does not discard soft tails on an infinite domain; the relevant receiver support is the finite W_y.

Use the R276 common soft nodes `sigma=k/(n+1)`, k=1,...,n, and the at most n+1 upward physical nodes B. For every actual s,L,

`P_{s,L}<=c_n^2 P_{sigma,B}`, `B>=L`, and `barw_B<=barw_L`.

It follows that the half-kernel normalized by barw_L is bounded by `c_n` times the matching node half-kernel normalized by barw_B. Combine this with (J1). The actual original inverse-w_g half-kernel is therefore covered at price `c_n^(3/2)`, not merely c_n. Summing the finite nodes and using sigma<=1 gives

`integral sup_actual 1_W sqrt(P_{s,L}J/w_g) dx`

`<= c_n^(3/2) n(n+1) exp[-c_J n+exp(c_J)sqrt(2n)/8]`.       (J3)

The supremum is understood through this finite measurable upper envelope; w_g retains its original band relation before the comparison. No current/future FIRST qualification is assigned to an auxiliary menu node.

## 3. Raw original positive J-dominated subset

Within the original currently unpaid positive mother integral define

`E_J={p_y(x) w_g(y,v)<=K J_x(v)}`.

For p>0, pointwise

`p 1_EJ <= sqrt(K) sqrt(p J_x(v)/w_g(y,v))`.               (J4)

At p=0 both sides contribute zero. All pure terminal weights are positive at finite positions. This is a positive-subset bound; it does not reclassify the original G/B sets or alter signed negative terms.

On the actual near hard-source support, `z in Q_R(x)` and `||z-y||_1<=d/2` force `x in W_y`, since R<=b. Retain this implication when integrating the hard source. First use the actual receiver hardcap/q<=16/3 on the original E, then expand the remaining receiver integral only to W_y. The J event does not depend on hard z.

For fixed `(omega,V,j,y,t)` the complete original posterior pair is independent of x, so the node envelope can be integrated before those two probability slots. Positive removal of terminal/classifier/history masks is legal only after the original pointwise bound; the complete posterior itself is unchanged. Use raw score<=n and the complete j-band clock sum<=n, as independently proved in R276. Restoring the original outside factor `2 Lambda` exactly once gives

`P[E_J] <= (32 Lambda/3) sqrt(K) c_n^(3/2) n^3(n+1)`

`        * exp[-c_J n+exp(c_J)sqrt(2n)/8] W_beta`.           (J5)

In particular, `c_n^(3/2)<e^(3/2)` gives a simple dimension-independent scalar prefactor. The proposed factor e is replaced by e^(3/2); no other polynomial, clock, source or target-leg factor is missing. There is no factor 3^{-1/2} for this particular gate, whose definition uses J directly rather than the averaged Q.

The same original terminal-leaf source ledger as R276 gives `W_beta<=W_hi<=||f||_1`; no comparison `nu<=beta` is used. For one fixed original K, the explicit negative linear exponent eventually beats the positive sqrt(n) collar term and every displayed polynomial. All finite-n constants remain extremely large because c_J is tiny and are not suppressed. If K varies with outer data, sqrt(K) must remain inside the corresponding expectation/source charge; no unweighted W_beta conclusion follows by removing it.

Thus the corrected formula is a genuinely linear actual-source bound for this original positive subset. It neither pays the moving-target complement nor proves the full global upper bound.

## 4. Complementary moving-leg reduction

On original terminal good, `p w_g<=K(K1+K2+J)/3`. If E_J fails, then `KJ<p w_g`, so

`K(K1+K2)>2 p w_g`.

At least one of K1,K2 therefore satisfies `p w_g<K K_i`. A measurable deterministic tie-breaking rule can split that remaining positive set between the two moving legs. This is only a positive allocation; it does not change FIRST, choose a new threshold, or duplicate any original negative credit. The already-paid positive J subset must be removed before charging its complement.

## 5. Actual bounded arithmetic evidence

A local standard-library Python run passed **216 exact Fraction assertions** checking the original clamp transfer (J1) and upward-node denominator monotonicity at n in {1,2,8}. This is finite algebra evidence, not a new proof of R266's uniform J gap, an interval certificate, or a FULL instance. Reproduce:

```python
from fractions import Fraction as F
from functools import reduce
checks=0
for n in (1,2,8):
    gam,b=F(n+1,n),F(1)
    for L in (F(1,2),F(3,4),F(1)):
        B=min(b,gam*L)
        for m in (L/gam,L,min(gam*L,b)):
            for c in (F(1,10000),F(1,10),F(1,2),F(1)):
                cs=[min(F(1),c+F(i%3,100)) for i in range(n)]
                prod=lambda zs:reduce(lambda x,y:x*y,zs,F(1))
                wg=prod(min(F(1),b*C/m) for C in cs)
                wL=prod(min(F(1),b*C/L) for C in cs)
                wB=prod(min(F(1),b*C/B) for C in cs)
                assert wg>=wL/(gam**n);checks+=1
                assert wB<=wL;checks+=1
print('PASS',checks,'exact Fraction clamp-transfer/upward-node checks')
```

No R277 author proof was read and no repository file was modified. Stop at this corrected bounded proposition and its still-unpaid moving complement.
