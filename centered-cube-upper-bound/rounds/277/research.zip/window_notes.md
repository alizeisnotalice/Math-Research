# R277 retained-window J numerical screen

Executed seven J-only finite examples using the correct denominator Omega_L=min(1,C(r)/L). The original six geometries contribute2/2/2 stages and one s1,L.5,r0 highsoft corner is extra. No previous18-row wholeline menu was rerun or changed. No C-denominator strengthening was computed.

Core[-.5,.5] and the two collars are independently integrated with actual E3 phi and explicit core-boundary splits at40/60 precision. All one-coordinate core,collar,sum and repeated-tensor log bounds passed. Actual maximum scaled difference across121 numeric fields is 3.990117085449734772898383981829051315367525219500657870146806169058501616935486758238090559538666838e-41. This is ordinary arithmetic, not a proof of the tiny cJ.

Kappa=25/2^68 and cJ=kappa/20=5/2^70 are exact Fractions. Six scalar G10 tests use min((4/5)/Omega,1−kappa(1−Omega))<=1−kappa/10 and split at Omega9/10; the upper branch8/9 comparison is exact as well. Those are scalar interface certificates, not an independent proof of the external phi/core estimate.

Tensor bound is explicitly −cJ*n+exp(cJ)*n*epsilon*sqrt(2s), obtained from the one-coordinate sum. epsilon=.5/(8sqrt n). The original wg>=gamma^(−n)Omega_L comparison and its sqrt(e) factor are external analytic steps, not implemented original geometry.

Replay: `PYTHONPATH=/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor /Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 /tmp/r277_window.py --output /tmp/r277_window.json`. Python3.12.14,mpmath1.3.0. No FULL/FIRST/high/history/source payment or dimension-order conclusion.

Source SHA256: 24b4879676b44abd8db4a7390e969ceb5512ac17b8828351475389bf1c92029a

JSON SHA256: 4691c17ddfd4043e43477f739b604bb8546c6c46c763f2cf06f9bf3c40f180db
