# R277: an actual fractional overlap bound retaining active clamps, radius and aspect

## K1. Scope and corrected original scale direction

These are fixed-parameter, one-dimensional receiver-Lebesgue inequalities and their product-kernel consequences. They do not pay adaptive receiver selectors, source integrals, clock factors or original signed traffic.

Let h=1_[−1/2,1/2], w(x)=integral_0^1 exp(−|x|/r)dr, phi=h*w, and f_s=(1−s)h+s phi, allowing s=0 without discarding its support. Put F=max(h,phi), C(D)=integral_[−1/2,1/2] F(u−D)du. Fix 0<a<=L,R<=b<=2a, L<=A<=b, 0<=s,sigma<=1, and
\[
 p(x)=L^{-1}f_s(x/L),\quad k(x)=A^{-1}f_\sigma((x-r)/A),
 \quad H_\theta(r)=\int p^{1-\theta}k^\theta dx,
\]
\[
 w_m(r)=\min\{1,bC(|r|/b)/m\},\quad D=|r|/b,
 \quad \ell_m(r)=\log(1/w_m(r)).
\]
The original tests have A=L or A=min(b,gamma L), sigma=s, and the J test has A=b,sigma=1. All are included.

The actual original ratio band is min(L,R)<=m=c_j g<=gamma min(L,R), gamma=1+1/n; it is **not** m<=min(L,R). This is R128 `proof.md:636–650` and R273 frozen proof. The bounds below use actual m directly and only require m<=b, so they incur no extra gamma cost. If a separate application first uses m_0=min(L,R), then w_m>=gamma^-1 w_m0 per coordinate, hence at most gamma^(theta n)<=e^theta for the complete tensor, once. That comparison must not be charged twice.

## K2. A uniform small-power overlap estimate with cost exp(O(theta))

Define
\[
 C_0=256e^2,\qquad c_0=2e^{-2}/9,\qquad C_*=C_0/c_0=1152e^4.
\]
For every 0<theta<=1/4,
\[
 \boxed{H_\theta(r)\le\min\left\{1,
       [C_0(L/A)e^{-|r|/A}]^\theta\right\}.}            \tag{K2}
\]
The constant is raised to theta; there is no fixed per-coordinate entropy factor greater than one surviving as theta decreases.

Proof: all f_s are probability densities and, uniformly including s=0,
\[
 f_s(x)\le e^{1/2}e^{-|x|}.
\]
On the hard core this follows from f_s<=1; outside it w<=exp(−|.|) and convolution over a unit interval gives the displayed envelope. Let c=L/A<=1. At theta=1/4,
\[
 \int f_s(z)^{3/4}e^{c|z|/4}dz
 \le e^{3/8}\int e^{-|z|/2}dz=4e^{3/8}.
\]
Holder interpolation with integral f_s=1 therefore gives, for 0<theta<=1/4,
\[
 \int f_s(z)^{1-\theta}e^{\theta c|z|}dz
 \le(4e^{3/8})^{4\theta}.
\]
This statement uses only nonnegative powers, with its endpoint handled directly; it does not evaluate log f_0 off the hard support. Now use the target envelope and |x−r|>=|r|−|x|, then rescale x=Lz. The resulting factors are
\((L/A)^\theta e^{\theta/2-\theta|r|/A}(4e^{3/8})^{4\theta}\),
which give C_0. Holder between the two normalized densities also gives H_theta<=1.

For the entire domain 0<theta<1 put
\[
 q_\theta=\min\{\theta,(1-\theta)/3\}.
\]
Interpolation between the quarter-power overlap and integral k=1 gives
\[
 \boxed{\log\frac{H_\theta(r)}{w_m(r)^\theta}
 \le\theta\ell_m(r)+q_\theta\min\{0,\log C_0+\log(L/A)-|r|/A\}.} \tag{K3}
\]
For theta>1/4 the proof is the direct Holder decomposition of the quarter-power integrand and k; no convention 0^0 is needed. If H_theta=0 the logarithm is minus infinity and the inequality is understood accordingly. The theta>1/4 statement deliberately retains the possible uncancelled far-radius exponent; it is not advertised as a uniform strong clamp bound.

## K3. Explicit lower bound for C and active-clamp cancellation

For x>=0 choose t in [1−1/(2(1+x)),1]. Then t^-1<=1+1/(1+x), hence
\[
 w(x)\ge e^{-x-1}/[2(1+x)].
\]
Integrating twice over the unit core and using F>=phi gives
\[
 \phi(x)\ge\frac{e^{-3/2}}3\frac{e^{-|x|}}{1+|x|},\qquad
 \boxed{C(D)\ge c_0\frac{e^{-D}}{1+D}.}                 \tag{K4}
\]
For example the first integration uses |x−u|<=|x|+1/2 and 1+|x|+1/2<=(3/2)(1+|x|); the second gives the additional factor (2/3)e^-1/2. The constants are explicit, not fitted to a numerical tail.

If the coordinate is inactive, bC(D)>=m and H_theta/w_m^theta<=1. On an active coordinate, ell_m=log(m/b)−log C(D). Combining K2 and K4 gives, for 0<theta<=1/4,
\[
 \boxed{\frac{H_\theta(r)}{w_m(r)^\theta}
 \le\min\left\{e^{\theta\ell_m(r)},
 \left[C_*\frac{Lm}{Ab}(1+D)
         e^{-|r|(1/A-1/b)}\right]^\theta\right\}.}       \tag{K5}
\]
This keeps the actual aspect and radius, including negative gains. The residual exponential decay is genuine for moving targets A<b. For J, A=b, this particular residual vanishes and the remaining explicit radius cost is polynomial to the power theta. Neither Hellinger squared<=C nor a pointwise product-to-min inequality is assumed.

## K4. Tensor and the actual three-target mixture

For fixed vectors y,v, parameters and a common soft value in every coordinate, the receiver integral of the fractional product factors exactly into product_i H_theta(v_i−y_i). This is independence of the **product receiver kernel**, not of posterior source coordinates. Let I_act={i:bC(|v_i−y_i|/b)<m}, N_act=|I_act|. For theta<=1/4, a useful positive upper bound obtained from K5 is
\[
 \frac{\int P_{s,L}(x-y)^{1-\theta}P_{\sigma,A}(x-v)^\theta dx}
      {\bar w_m(y,v)^\theta}
 \le\exp\left\{\theta\sum_{i\in I_{act}}
  [\log C_*+\log(Lm/(Ab))+\log(1+D_i)
                         -|v_i-y_i|(1/A-1/b)]\right\}. \tag{K6}
\]
One may retain the smaller individual factor in K5 in this product. Inactive coordinates contribute at most one. Thus the full cost is explicitly controlled by the active-coordinate count and actual radii, rather than an artificial per-coordinate mixture expansion.

If D_i<=D_max, a weaker but convenient bound is
\(\exp\{\theta N_{act}[\log C_*+\log(1+D_{max})]\}\).
For instance a verified geometric branch satisfying theta times that displayed sum <=log G has kernel gain at most G. For n>=4, theta=1/n and D_max=O(log n), this weaker gain is O(log n) with its explicit absolute constant. Choosing theta is not free in a source/clock proof: any 1/theta, 1/theta² or 1/theta³ factor of that proof must still be paid. For n>=16, taking theta=1/sqrt n generally yields exp(O(sqrt n log log n)), which is subexponential but is not a root or n^o(1) source payment.

For the actual Q=(K_1+K_2+J)/3 one can use
\[
 \int P_{s,L}^{1-\theta}Q^\theta/\bar w_m^\theta
 \le3^{-\theta}\sum_{i=1}^3
       \int P_{s,L}^{1-\theta}K_i^\theta/\bar w_m^\theta. \tag{K7}
\]
This is the scalar subadditivity of the theta-power after the three **whole tensor** kernels have been formed. It incurs at most a global three-leg sum, never 3^n or an independent per-coordinate soft menu. Each term is covered by K3–K6 with its own true target scale; no new FIRST is granted.

There is also an explicit no-gain geometric branch for a moving leg. If every active coordinate satisfies
\[
 |r_i|(1/A-1/b)\ge\log C_*+\log(Lm/(Ab))+\log(1+|r_i|/b),
\]
then K6 gives normalized tensor overlap at most 1, for all theta<=1/4. More generally the signed sum in K6 can be nonpositive even without this condition at every coordinate. This is a checkable sufficient geometry, not a claim that the original sources satisfy it. As a coarse nonempty example, A<=b/2 and every active D_i>=16 suffice: the left side is at least D_i, log(Lm/(Ab))<=0, log C_*<12, and D−log(1+D)>12 for D>=16. The same argument does not provide this no-gain branch for the J leg A=b; its cost remains in K5/K7. No source or clock payment follows merely from this fixed-kernel condition.

## K5. A finite-interval certification interface and exact hard endpoint

For every theta in (0,1), let lambda=(1−theta)/L and mu=theta/A. The same elementary density envelopes imply, for B>=|r|,
\[
 \int_{|x|>B}p^{1-\theta}k^\theta dx
 \le\frac{2e^{1/2}L^{\theta-1}A^{-\theta}}{\lambda+\mu}
          \cosh(\mu r)e^{-(\lambda+\mu)B}.               \tag{K8}
\]
Thus H_theta can be evaluated on a finite interval with an analytic positive tail bound. Split the body at the actual hard-core endpoints ±L/2 and r±A/2; all boundary jumps are then explicit. A future interval evaluation may certify the remaining positive smooth one-dimensional integrals. The ordinary numeric checks below are not such interval certificates.

When s=sigma=0 there is an exact support formula:
\[
 H_\theta=|[-L/2,L/2]\cap[r-A/2,r+A/2]|\,
                      L^{\theta-1}A^{-\theta}.
\]
It is zero for disjoint hard supports. This is retained, rather than replacing the s=0 family by a positive artificial density.

## K6. Bounded actual-kernel diagnostic (code and output below)

```python
import sys
sys.path.insert(0,'/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor')
import mpmath as m

def run(dps):
    m.mp.dps=dps
    def phi(x):
        x=abs(x)
        if x<=m.mpf('.5'):return 1-m.expint(3,m.mpf('.5')-x)-m.expint(3,m.mpf('.5')+x)
        return m.expint(3,x-m.mpf('.5'))-m.expint(3,x+m.mpf('.5'))
    def prim(x):
        if x<0:return -prim(-x)
        if x<=m.mpf('.5'):return x-m.expint(4,m.mpf('.5')-x)+m.expint(4,m.mpf('.5')+x)
        return m.mpf('.5')-m.expint(4,x-m.mpf('.5'))+m.expint(4,x+m.mpf('.5'))
    def C(D):
        if D<=1:return 1-D+prim(D+m.mpf('.5'))-prim(m.mpf('.5'))
        return prim(D+m.mpf('.5'))-prim(D-m.mpf('.5'))
    def f(s,x):return (1-s if abs(x)<=m.mpf('.5') else 0)+s*phi(x)
    def overlap(s,sig,L,A,r,th):
        lo=-L/2 if s==0 else -m.inf;hi=L/2 if s==0 else m.inf
        if sig==0:lo=max(lo,r-A/2);hi=min(hi,r+A/2)
        if hi<=lo:return m.mpf(0)
        pts=[lo]+sorted({q for q in [-L/2,L/2,r-A/2,r+A/2,m.mpf(0),r] if lo<q<hi})+[hi]
        def integrand(x):
            p=f(s,x/L)/L;k=f(sig,(x-r)/A)/A
            return p**(1-th)*k**th if p and k else m.mpf(0)
        return sum(m.quad(integrand,[x,y]) for x,y in zip(pts[:-1],pts[1:]))
    L=m.mpf('.99');A=L*m.mpf(129)/128;actual_m=m.sqrt(L)
    configs=[]
    for th in ['.1','.25','.5']:
        configs.append((m.mpf(1),m.mpf(1),m.mpf(1),m.mpf(1),m.mpf(1),m.mpf(1),m.mpf(8),m.mpf(th)))
    for th in ['.1','.25']:
        configs.append((m.mpf('.01'),m.mpf('.01'),L,A,actual_m,m.mpf(1),m.mpf(2),m.mpf(th)))
        configs.append((m.mpf('.01'),m.mpf(1),L,m.mpf(1),actual_m,m.mpf(1),m.mpf(8),m.mpf(th)))
    configs.append((m.mpf(0),m.mpf(1),L,m.mpf(1),actual_m,m.mpf(1),m.mpf(2),m.mpf('.25')))
    rows=[];checks=0
    for s,sig,L,A,mm,b,r,th in configs:
        H=overlap(s,sig,L,A,r,th);cc=C(r/b);ww=min(1,b*cc/mm)
        lowC=2*m.exp(-2)/9*m.exp(-r/b)/(1+r/b)
        assert cc>=lowC;checks+=1
        ratio=H/ww**th;ell=-m.log(ww)
        q=min(th,(1-th)/3);e0=m.log(256)+2+m.log(L/A)-r/A
        bound=m.exp(th*ell+q*min(0,e0))
        assert ratio<=bound*(1+m.mpf('1e-25'));checks+=1
        if th<=m.mpf('.25') and ww<1:
            radius=(1152*m.exp(4)*L*mm/(A*b)*(1+r/b)*m.exp(-r*(1/A-1/b)))**th
            assert ratio<=radius*(1+m.mpf('1e-25'));checks+=1
        rows.append((s,sig,L,A,r,th,H,ratio,bound))
    for r in map(m.mpf,['0','.5','1','1.5']):
        L=A=m.mpf(1);th=m.mpf('.25')
        H=overlap(m.mpf(0),m.mpf(0),L,A,r,th)
        exact=max(m.mpf(0),1-r)
        assert abs(H-exact)<m.mpf('1e-25');checks+=1
    return rows,checks
lo,c1=run(35)
hi,c2=run(55)
m.mp.dps=90
err=max(abs(x[-2]-y[-2])/max(1,abs(y[-2])) for x,y in zip(lo,hi))
assert err<m.mpf('1e-25')
print('PASS',c1+c2,'checks; actual overlap configurations',len(hi),'per precision')
for row in hi[:3]:print('fullsoft r8 theta',row[5],'normalized overlap',m.nstr(row[-2],18))
print('max scaled 35/55 normalized-overlap difference',m.nstr(err,12))
```

Actual local execution at 35/55 digits returned `PASS 54 checks; actual overlap configurations 8 per precision`. Four exact-support hard cases were also checked per precision. The normalized full-soft same-scale overlap at r=8 was approximately 1.15812543871663319 at theta=1/10, 1.58142791073900981 at theta=1/4, and 6.38104590882887215 at theta=1/2. The maximum scaled normalized-overlap difference between the two precisions was 5.95502177884e-34. These ordinary quadratures locate the relevant radius dependence; they are not interval certificates or FULL instances. No unproved universal bound by one is used anywhere in K2–K8.

The retained outcome is the all-parameter analytic upper function K3, its active/radius refinement K5–K6, and the finite-tail interface K8. Passing any of them to an adaptive original receiver or source/clock integral still requires its genuine joint budget. No original source is removed, no posterior is replaced, and no previously paid positive piece or negative credit is charged here.
