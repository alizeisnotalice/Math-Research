#!/usr/bin/env python3
"""R277 actual retained-window J halfkernel, correct barw_L denominator."""
import argparse,hashlib,json
from pathlib import Path
from fractions import Fraction as F
import mpmath as mp

def enc(x):return mp.nstr(x,100)
def mm(x):
 q=F(x);return mp.mpf(q.numerator)/q.denominator
def phi(x):
 x=abs(x)
 if x<=mp.mpf('.5'):return 1-mp.expint(3,mp.mpf('.5')-x)-mp.expint(3,mp.mpf('.5')+x)
 return mp.expint(3,x-mp.mpf('.5'))-mp.expint(3,x+mp.mpf('.5'))
def C(r):
 r=abs(r)
 if r<=1:return 1-r+mp.mpf(1)/3-mp.expint(4,r)-mp.expint(4,1)+mp.expint(4,r+1)
 return mp.expint(4,r-1)-2*mp.expint(4,r)+mp.expint(4,r+1)
def P(s,L,x):return ((1-s)*(1 if abs(x)<L/2 else 0)+s*phi(x/L))/L
def quad(fn,a,b,knots):
 pts=sorted(set([a,b]+[x for x in knots if a<x<b]));return sum(mp.quad(fn,[x,y]) for x,y in zip(pts,pts[1:]))
def menu():return [('initial',8,'0','1/2','0',False),('initial',8,'1/2','1','1/2',False),('stress',64,'1/1000000','1/2','1',False),('stress',64,'1','1','1/4',False),('expanded',512,'1/100','3/4','2',False),('expanded',512,'1/2','1/2','4',False),('stress',64,'1','1/2','0',True)]
def run(dps):
 with mp.workdps(dps):
  cJ=mp.mpf(25)/(20*2**68);rows=[]
  for stage,n,ss,ls,rr,extra in menu():
   s,L,r=map(mm,[ss,ls,rr]);epsilon=mp.mpf('.5')/(8*mp.sqrt(n));half=(1+epsilon)/2;cr=C(r);omega=min(mp.mpf(1),cr/L)
   fn=lambda x:mp.sqrt(P(s,L,x)*phi(x-r)/omega);knots=[-L/2,L/2,r-mp.mpf('.5'),r+mp.mpf('.5'),mp.mpf(0),r]
   core=quad(fn,-mp.mpf('.5'),mp.mpf('.5'),knots);left=quad(fn,-half,-mp.mpf('.5'),knots);right=quad(fn,mp.mpf('.5'),half,knots);collar=left+right;total=core+collar
   corebound=mp.exp(-cJ);collarbound=epsilon*mp.sqrt(2*s);bound=corebound+collarbound;logtensor=n*mp.log(total);logtensorbound=-cJ*n+mp.exp(cJ)*n*epsilon*mp.sqrt(2*s)
   assert core<=corebound+mp.mpf('1e-30') and collar<=collarbound+mp.mpf('1e-30') and total<=bound+mp.mpf('1e-30') and logtensor<=logtensorbound+mp.mpf('1e-28')
   rows.append({'stage':stage,'extra_highsoft_corner':extra,'n':n,'s':ss,'L':ls,'r':rr,'epsilon':enc(epsilon),'C_r':enc(cr),'Omega_L_min_1_C_over_L':enc(omega),'core_integral':enc(core),'left_collar':enc(left),'right_collar':enc(right),'collar_integral':enc(collar),'whole_retained_window_integral':enc(total),'core_bound_exp_minus_cJ':enc(corebound),'core_margin':enc(corebound-core),'collar_bound':enc(collarbound),'collar_margin':enc(collarbound-collar),'total_bound':enc(bound),'total_margin':enc(bound-total),'tensor_log_integral':enc(logtensor),'tensor_log_bound':enc(logtensorbound),'tensor_log_margin':enc(logtensorbound-logtensor)})
  return {'kappa':enc(20*cJ),'cJ':enc(cJ),'cases':rows}

def exact_G10():
 kappa=F(25,2**68);cJ=kappa/20;assert cJ==F(5,2**70);Vupper=F(4,5);records=[]
 for omega in [F(1,100),F(1,2),F(899,1000),F(9,10),F(999,1000),F(1)]:
  lhs=min(Vupper/omega,1-kappa*(1-omega));rhs=1-kappa/10;assert lhs<=rhs
  records.append({'Omega_exact':str(omega),'minimum_upper_exact':str(lhs),'bound_exact':str(rhs),'margin_exact':str(rhs-lhs)})
 assert F(8,9)<=1-kappa/10
 return {'kappa_exact':str(kappa),'cJ_exact':str(cJ),'V0_upper_used_exact':str(Vupper),'split_Omega_exact':'9/10','upper_branch_8_over9_margin_exact':str(1-kappa/10-F(8,9)),'cases':records,'scope':'Pure exact scalar G10 screens at barw_L Omega; the phi/core lemma is analytic external input. No C-denominator strengthening certified.'}

def fields(obj,path=''):
 out={}
 if isinstance(obj,dict):
  for k,v in obj.items():
   if isinstance(v,str) and k not in ['stage','s','L','r']:
    try:out[path+k]=mp.mpf(v)
    except ValueError:pass
   elif isinstance(v,(dict,list)):out.update(fields(v,path+k+'/'))
 elif isinstance(obj,list):
  for i,v in enumerate(obj):out.update(fields(v,path+str(i)+'/'))
 return out

def main():
 p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=Path(__file__).with_suffix('.json'));a=p.parse_args();lo=run(40);hi=run(60);ex=exact_G10()
 with mp.workdps(120):
  x=fields(lo);y=fields(hi);assert x.keys()==y.keys();diff={k:abs(x[k]-y[k])/max(1,abs(y[k])) for k in x};worst=max(diff,key=diff.get);md=enc(diff[worst]);assert diff[worst]<mp.mpf('1e-28')
 out={'schema':'R277-correct-barwL-retained-J-window-v1','script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'counts':{'actual_J_window_cases_per_precision':7,'main_six_stages':{'initial':2,'stress':2,'expanded':2},'extra_highsoft_corners':1,'G10_exact_scalar_cases':6,'precision_fields_compared':len(diff)},'mp40':lo,'mp60':hi,'G10_exact':ex,'precision_max_relative_difference':md,'precision_worst_field':worst,'definitions':{'F':'1_W sqrt(P_s,L(x) phi(x-r)/Omega_L)','Omega_L':'min(1,C(r)/L)','W':'[-(1+epsilon)/2,(1+epsilon)/2],epsilon=.5/(8sqrt n)','one_coordinate_bound':'exp(-cJ)+epsilon sqrt(2s)','tensor_log_bound':'-cJ*n+exp(cJ)*n*epsilon*sqrt(2s)'},'scope':['Correct denominator is barw_L=min(1,C/L), not C and not the old physical m clamp. No C-denominator numerical strengthening was computed or used as evidence. Original wg comparison and sqrt(e) loss are analytic external steps.','Finite retained-window core/collar integrals with explicit source/target hard boundaries,ordinary40/60 mpmath. The tiny cJ gap is not claimed as a rigorous numeric certificate; exact Fraction scalar screens are separately identified.','Seven finite J-only examples reuse six old geometries plus a highsoft corner; old18 wholeline Chernoff rows are not rerun or modified. Tensor powers are repeated-coordinate factorization only.','No original FIRST/high/history/FULL/source-payment or dimension-order theorem is certified.']}
 a.output.write_text(json.dumps(out,sort_keys=True,indent=2)+'\n');print(json.dumps({'counts':out['counts'],'maxdiff':md,'worst':worst}))
if __name__=='__main__':main()
