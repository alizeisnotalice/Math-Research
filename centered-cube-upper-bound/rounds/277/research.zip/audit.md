# R277 final independent audit

**Verdict: PASS for the corrected J-certified original-positive subbranch and its linear source-mass bound. This does not certify the moving-certified complement or the global weak-type goal.**

## Versions and screening order

Final integrated proof read in full and its SHA rechecked after the read:

- `/tmp/r277_proof.tex.txt`
- SHA256 `eee2b376186f4cb86719a634e136a2029bbe68567e56aae040c59cbbed621fa6`.

Author source subsequently reviewed:

- `/tmp/r277_main.md`
- SHA256 `5394aa7d88d9ae8d912726cfacb9ec11aad826d51c88a5820a4356cefc63918e`.

The statements were independently screened before the author was read. The general likelihood screen is `/tmp/r277_screen.md`, SHA256 `5789e6d4392a9ce97a84de4393ab2d2bdd9cafa09e159751623779f0f8954f29`. The corrected J screen is `/tmp/r277_j_screen.md`, SHA256 `f6e35ae5d996f29d4be3fd0629cb0e067f079ca715f6ba7190246de1e08de4db`.

## Mathematical review

1. **Certified event and actual measure pass.** The proof bounds the currently unpaid original positive integral additionally restricted to near and `p w_g(v)<=K J(v)`. It preserves its outside `2 Lambda`, original complete posteriors, terminal classification, source collection, and signed-credit ledger. The elementary pointwise square-root domination has factor sqrt(K), with no extra 3^{-1/2}, since this particular gate uses J directly rather than the averaged Q. At p=0 its receiver contribution vanishes; positive pure weights and zero-degree rows are handled without invalid division.

2. **Exact normalization repair passes.** R266 G10 has denominator sqrt(barw_L); it cannot simply be changed to sqrt(barw_b). The original band gives `c_j g<=gamma L`, and therefore `w_g>=gamma^{-n}barw_L`. The proof retains the resulting gamma^{n/2}. This was the sole substantive interface correction identified during the independent initial screen, and it is present in equations (6) and (2). The cited R266 integrated proof was checked at its frozen SHA `e427ea2f3a1071706ccd81b21c7010c0f286aa47a00dabd13eb64867d8bfde97`; its G10 and following collar formula are precisely the interfaces used. The final proof only invokes the source-centered Q_b(y) core specialization.

3. **Fixed half-mass and whole-soft menu pass.** Every input/node scale lies in [b/2,b], and both the G10 strict overlap loss and its collar estimate apply for all s in [0,1]. The source-centered collar has total extra side length d, and its bound retains the explicit sqrt(s) term. The n common soft nodes cover the closed interval, including s=0 and s=1. Upward L rounding gives at most n+1 nodes, preserves `barw_B<=barw_L`, and contributes another gamma^n to the half-kernel, because the two density-domination costs are square-rooted. Thus the combined cost is at most e^{3/2}, not e. No new node FIRST or posterior is asserted.

4. **Original receiver/source accounting passes.** Original near and hard support imply x in W_y before hard-source integration. The proof applies the actual receiver hardcap/q<=16/3 before enlarging x. It then integrates the finite L1 kernel envelope at fixed (omega,V,j,y,t), where the two full posterior slots are independent of x and have total mass at most one. Score<=n is a legitimate positive upper bound. The complete j-band clock sum is explicitly charged by `S_n<=n`; no implicit posterior mixture over j or free selector count is used. Together these yield exactly the stated `(32 Lambda/3)e^{3/2}sqrt(K)n^3(n+1)` prefactor. No missing hard-source mass, lambda, q, receiver-volume factor, target-leg factor, or second Lambda remains.

5. **Source qualification and limits pass.** W_beta is charged only on the same pre-frozen terminal-leaf source collection, with beta<=alpha and disjoint terminal leaves. The previously verified R112/R276 source bridge yields W_beta<=W_hi<=||f||_1. No nu<=beta, source-coordinate independence, or false statement about Pi_{g(x)} is used. The proof states the K dependence explicitly. If K is outer-data dependent, sqrt(K) cannot be removed from the corresponding source expectation; the fixed-absolute-K conclusion is correctly qualified.

6. **Huge finite constant passes.** The two inequalities

   `n^3(n+1)<=2n^4`,

   `A sqrt(n)<=c_J n/2+A^2/(2c_J)`

   leave `n^4 exp(-c_J n/2)`, whose supremum over positive real n is `(8/(e c_J))^4`. Equation (9) has the right factor 64 Lambda/3 and the correct exponent. The resulting dimension-independent constant is finite but enormous. Its existence is an analytic statement, not a numerical claim about useful moderate dimensions.

7. **Complementary allocation passes.** On original good but outside E_J, `KJ<p w_g` and `K(K1+K2+J)>=3p w_g` force at least one moving target to satisfy `K K_i>p w_g`. A deterministic positive allocation is valid. It does not remove J from original Q, bad, or high, reselect FIRST, or supply a second signed credit. The original moving complement remains explicitly unpaid; this round does not close the overall goal.

## Actual arithmetic receipt and reproducibility

The author code was independently extracted unchanged and actually executed: **522 exact Fraction conjunction assertions for the two soft coefficients, 6 exact gamma-grid inequalities, and 6 ordinary floating-point clock checks all passed**. The independent statement screen had already actually run **216 exact Fraction clamp-transfer/upward-denominator assertions**. These bounded calculations check scalar algebra only; they are not FULL instances or interval integration certificates and do not replace the kernel theorem.

A combined reproducible script is saved at `/tmp/r277_main_checks.py`, SHA256 `3afb6e62c08cf6cd79093fc2e4abde1597687a4a257a341d3b82b6d398731da4`. It consists of the unchanged extracted author block followed by the unchanged independent clamp-check block. The two blocks have the execution receipts just stated; no old window/kernel suite was rerun for this final audit.

No further mathematical repair is necessary for the stated scope. No repository file, Git state, or PDF was modified. Audit work stops here.
