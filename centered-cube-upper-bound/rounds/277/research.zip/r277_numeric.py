#!/usr/bin/env python3
"""R277 actual one-dimensional Chernoff affinities, finite physical-scale probe."""
import argparse,hashlib,json
from fractions import Fraction as F
from pathlib import Path
import mpmath as mp

def enc(x):return mp.nstr(x,100)
def mm(x):
 q=F(x);return mp.mpf(q.numerator)/q.denominator
def phi(x):
 x=abs(x)
 if x<=mp.mpf('.5'):return 1-mp.expint(3,mp.mpf('.5')-x)-mp.expint(3,mp.mpf('.5')+x)
 return mp.expint(3,x-mp.mpf('.5'))-mp.expint(3,x+mp.mpf('.5'))
def C(r):
 r=abs(r)
 if r<=1:return 1-r+mp.mpf(1)/3-mp.expint(4,r)-mp.expint(4,1)+mp.expint(4,r+1)
 return mp.expint(4,r-1)-2*mp.expint(4,r)+mp.expint(4,r+1)
def P(s,L,x):return ((1-s)*(1 if abs(x)<L/2 else 0)+s*phi(x/L))/L

def geometry_menu():
 return [('initial',8,'0','1/2','1/2','0','1/2'),('initial',8,'1/2','1','1','1/2','1/4'),('stress',64,'1/1000000','1/2','1','1','1/2'),('stress',64,'1','1','1/2','1/4','1/4'),('expanded',512,'1/100','3/4','1/2','2','1/16'),('expanded',512,'1/2','1/2','3/4','4','1/16')]

def one(dps,s,L,A,r,theta,sigma):
 with mp.workdps(dps):
  def integrand(x):
   p=P(s,L,x);q=P(sigma,A,x-r)
   return p**(1-theta)*q**theta if p and q else mp.mpf(0)
  endpoints=sorted(set([-L/2,L/2,r-A/2,r+A/2,mp.mpf(0),r]))
  if s==0:
   lo,hi=-L/2,L/2;pts=sorted(set([lo,hi]+[x for x in endpoints if lo<x<hi]));left=right=mp.mpf(0)
  elif sigma==0:
   lo,hi=r-A/2,r+A/2;pts=sorted(set([lo,hi]+[x for x in endpoints if lo<x<hi]));left=right=mp.mpf(0)
  else:
   pts=endpoints;left=mp.quad(integrand,[-mp.inf,pts[0]]);right=mp.quad(integrand,[pts[-1],mp.inf])
  middle=sum(mp.quad(integrand,[a,b]) for a,b in zip(pts,pts[1:]));H=left+middle+right;assert 0<H<=1+mp.mpf('1e-25')
  return {'H_theta':enc(H),'log_H_theta':enc(mp.log(H)),'left_tail_integral':enc(left),'middle_integral':enc(middle),'right_tail_integral':enc(right),'integration_breakpoints':[enc(x) for x in pts],'tail_mode':'exact compact support from a hard factor' if s==0 or sigma==0 else 'both infinite tails directly integrated by mpmath, not truncated'}

def run(dps,pilot=False):
 rows=[];cache={};calls=0
 with mp.workdps(dps):
  menu=geometry_menu()[1:2] if pilot else geometry_menu()
  for gi,(stage,n,ss,ls,rs,ds,ts) in enumerate(menu):
   s,L,R,r,theta=map(mm,[ss,ls,rs,ds,ts]);m=min(L,R);w=min(mp.mpf(1),C(r)/m)
   for leg in ['same_L','same_Lplus','J_phi_b']:
    A=L if leg=='same_L' else min(mp.mpf(1),(1+mp.mpf(1)/n)*L) if leg=='same_Lplus' else mp.mpf(1);sigma=mp.mpf(1) if leg=='J_phi_b' else s
    key=(s,L,A,r,theta,sigma)
    if key not in cache:cache[key]=one(dps,s,L,A,r,theta,sigma);calls+=1
    result=cache[key];gain=mp.mpf(result['log_H_theta'])-theta*mp.log(w)
    rows.append({'stage':stage,'n_for_Lplus':n,'s':ss,'L':ls,'R':rs,'r':ds,'theta':ts,'target_leg':leg,'target_sigma':enc(sigma),'target_scale_A':enc(A),'physical_m_min_L_R':enc(m),'C_r':enc(C(r)),'w':enc(w),'active_C_less_than_m':C(r)<m,**result,'log_affinity_minus_theta_log_w':enc(gain),'gain_positive':gain>0})
 return {'rows':rows,'unique_wholeline_integrals':calls}

def fields(obj,path=''):
 out={}
 if isinstance(obj,dict):
  for k,v in obj.items():
   if isinstance(v,str) and k not in ['stage','s','L','R','r','theta','target_leg','tail_mode']:
    try:
     z=mp.mpf(v)
     if mp.isfinite(z):out[path+k]=z
    except ValueError:pass
   elif isinstance(v,(dict,list)):out.update(fields(v,path+k+'/'))
 elif isinstance(obj,list):
  for i,v in enumerate(obj):out.update(fields(v,path+str(i)+'/'))
 return out

def main():
 p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=Path(__file__).with_suffix('.json'));a=p.parse_args();lo=run(40);hi=run(60)
 with mp.workdps(120):
  x=fields(lo);y=fields(hi);assert x.keys()==y.keys();diff={k:abs(x[k]-y[k])/max(1,abs(y[k])) for k in x};worst=max(diff,key=diff.get);md=enc(diff[worst]);assert diff[worst]<mp.mpf('1e-28')
 out={'schema':'R277-actual-Chernoff-affinity-v1','script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'counts':{'leg_rows_per_precision':18,'stages':{'initial':6,'stress':6,'expanded':6},'physical_geometries':6,'unique_wholeline_integrals_per_precision':hi['unique_wholeline_integrals'],'active_leg_rows':sum(r['active_C_less_than_m'] for r in hi['rows']),'positive_log_gain_rows':sum(r['gain_positive'] for r in hi['rows']),'precision_fields_compared':len(diff)},'mp40':lo,'mp60':hi,'precision_max_relative_difference':md,'precision_worst_field':worst,'definitions':{'p':'P_s,L(x),inputy0','target':'P_s,L(x-r),P_s,min(1,gammaL)(x-r),or phi(x-r)','C':'Integral_[r-.5,r+.5] max(h,phi),evaluated by exact hard length plus E4 soft primitive','terminal_clamp':'w=min(1,C(r)/m),physical m=min(L,R)','H_theta':'integral_real p^(1-theta) target^theta','reported_gain':'log H_theta-theta log w'},'scope':['Finite actual one-dimensional physical kernels with all three target legs retained. m=min(L,R) is a physical initial diagnostic and is not the original c_j-scale qualification or FULL source law.','Every noncompact integrand is integrated over both infinite tails directly, split from finite core pieces. Hard factors give exactly compact support. No finite tail truncation is substituted; ordinary mpquad tail errors are not certified intervals.','Duplicate target legs at clipped A=L=b or pure phi are cached, reported separately by leg label, and unique quadrature count is explicit.','Ordinary40/60 numerical evidence only: signs of sampled gains locate regimes, do not refute the original theory, prove a universal inequality, fit dimension order, or certify FIRST/high/history/FULL/root claims.']}
 a.output.write_text(json.dumps(out,sort_keys=True,indent=2)+'\n');print(json.dumps({'counts':out['counts'],'maxdiff':md,'worst':worst}))
if __name__=='__main__':main()
