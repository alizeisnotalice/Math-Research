"""Verify saved hashes; default also replays all bounded R277 checks."""
from pathlib import Path
import argparse,hashlib,json,subprocess,sys,tempfile
root=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--check-only',action='store_true');args=p.parse_args()
manifest=json.loads((root/'manifest.json').read_text())
for name,sha in manifest['sha256'].items():
 assert hashlib.sha256((root/name).read_bytes()).hexdigest()==sha,name
print('PASS manifest',len(manifest['sha256']))
if not args.check_only:
 with tempfile.TemporaryDirectory(prefix='r277-replay-') as td:
  for stem in ['r277_numeric','r277_window']:
   target=Path(td)/(stem+'.json')
   subprocess.run([sys.executable,str(root/(stem+'.py')),'--output',str(target)],check=True)
   assert target.read_bytes()==(root/(stem+'.json')).read_bytes(),stem
   print('PASS byte-identical replay',stem)
 for name in ['main_checks.py','aux_checks.py']:
  subprocess.run([sys.executable,str(root/name)],check=True)
 print('PASS all bounded checks; not an interval or FULL certificate')
