# Extracted unchanged from R277 author main, bounded scalar checks only.
from fractions import Fraction as F
import math
checks=0
for n in [1,2,3,8,32,128]:
    g=F(n+1,n)
    for k in range(1,n+1):
        sig=F(k,n+1)
        for s in [F(k-1,n),F(2*k-1,2*n),F(k,n)]:
            assert s <= g*sig and 1-s <= g*(1-sig)
            checks+=1
    assert g**n>=2
    h=math.log1p(1/n); ell=math.log(2)
    val=sum(max(0,ell-2*j*h) for j in range(n+2))
    assert val <= n+1e-12
    checks+=2
print({'exact_soft_coefficient_checks':checks-12,
       'grid_clock_checks':12,'status':'PASS'})

# Independent clamp/upward-node checks, previously run during statement screen.
from fractions import Fraction as F
from functools import reduce
checks=0
for n in (1,2,8):
    gam,b=F(n+1,n),F(1)
    for L in (F(1,2),F(3,4),F(1)):
        B=min(b,gam*L)
        for m in (L/gam,L,min(gam*L,b)):
            for c in (F(1,10000),F(1,10),F(1,2),F(1)):
                cs=[min(F(1),c+F(i%3,100)) for i in range(n)]
                prod=lambda zs:reduce(lambda x,y:x*y,zs,F(1))
                wg=prod(min(F(1),b*C/m) for C in cs)
                wL=prod(min(F(1),b*C/L) for C in cs)
                wB=prod(min(F(1),b*C/B) for C in cs)
                assert wg>=wL/(gam**n);checks+=1
                assert wB<=wL;checks+=1
print('PASS',checks,'exact Fraction clamp-transfer/upward-node checks')
