from fractions import Fraction as F
from pathlib import Path
import json,time,sys,resource,itertools
from flint import arb,ctx
ctx.prec=512
START=time.perf_counter()
def compute(cfg):
 START=time.perf_counter()
 N=cfg['n']; one=F(1); S=one; gamma=F(2); h=F(1,100); a=one;b=F(2); expansion=cfg['s'];G=expansion**N
 base=[(F(-4999,10000),F(4999,10000))]*(N-1)
 # Other-coordinate center width .9998, and all source coordinates within +/-1e-6.
 parents=[{'name':'background_growth','H':[(F(-1,5),cfg['bg_right'])]+base,'R':one,'t':one},
  {'name':'target_small','H':[(cfg['target_left'],F(0))]+base,'R':one,'t':one},
  {'name':'target_large','H':[(F(1,100000),F(2,100000))]+base,'R':F(5001,5000),'t':one},
  {'name':'zero_growth','H':[(F(1,5),F(20001,100000))]+base,'R':one,'t':1/G**2}]
 other=[(F(-1,1000000),F(1,1000000))]*(N-1)
 sources=[{'name':'core','U':[(F(-1,1000000),F(1,1000000))]+other,'M':one},
  {'name':'old_extra','U':[(F(10001,20000),F(25003,50000))]+other,'M':F(1,1000)},
  {'name':'common_new','U':[(cfg['new_lo'],cfg['new_hi'])]+other,'M':F(19,1000)},
  {'name':'background_new','U':[(cfg['bg_lo'],cfg['bg_hi'])]+other,'M':F(3,100)}]
 def vol(box):
  r=one
  for lo,hi in box:r*=hi-lo
  return r
 def A(x):
  x=F(x);return arb(x.numerator)/x.denominator
 def iv(x):return {'lo':str(x.lower().fmpq()),'hi':str(x.upper().fmpq()),'display':x.str(32)}
 def log2(x):return A(x).log()/arb(2).log()
 def tau(x):
  if x>=0:z=x
  elif x<=0:z=-x
  else:raise AssertionError('unresolved abs')
  if z<1:return 1-z
  if z>=1:return arb(0)
  raise AssertionError('unresolved tau')
 def sig(H,r,U):
  inside=all(ch-r/2<=ul and cl+r/2>=uh for (cl,ch),(ul,uh) in zip(H,U))
  outside=any(ch+r/2<=ul or cl-r/2>=uh for (cl,ch),(ul,uh) in zip(H,U))
  assert inside != outside, 'partial capture: '+str((H[0],r,U[0]))
  return int(inside)
 for p in parents:
  p['V']=vol(p['H']);p['I']=[[sig(p['H'],p['R']*s,z['U']) for z in sources] for s in [one,expansion]]
  p['m']=[sum((z['M']*v for z,v in zip(sources,row)),F(0)) for row in p['I']]
  p['q']=p['m'][0]/p['R']**N
  for z in sources:assert z['M']>0 and vol(z['U'])>0
  assert p['m'][0]>0
 # Actual distinct disjoint boxes, all belong to a single grid interior with b/2 margin.
 assert all(parents[i]['H'][0][1]<parents[j]['H'][0][0] or parents[j]['H'][0][1]<parents[i]['H'][0][0] for i in range(4) for j in range(i))
 q=min(p['q'] for p in parents);lam=max(p['q'] for p in parents);rband=lam/q
 C=1+(A(gamma*rband)).log();An=1+N*arb(2).log();W=sum(z['M'] for z in sources)
 def oldK(p,r):
  m=sum((z['M']*i*j for z,i,j in zip(sources,p['I'][0],r['I'][0])),F(0))
  return A(p['t']*r['t']*m/(p['R']**N*r['R']**N))*tau(log2(p['m'][0]/r['m'][0]))
 K=[[oldK(p,r) for r in parents] for p in parents]
 for i,p in enumerate(parents):
  psi=sum((A(r['V'])*K[i][j] for j,r in enumerate(parents)),arb(0));alpha=psi/(C*A(p['t']*p['q']))
  assert alpha<=1
  assert An*alpha>1
  # Here A_n alpha is certified larger than gamma^h, so max branch is fixed.
  assert An*alpha>(arb(2).log()*A(h)).exp()
  assert A(p['m'][1]/p['m'][0])<An*alpha
  assert a<=p['R']<=b and p['R']*expansion<b # strict non-top, exact
  p['alpha']=alpha;p['Kslow']=An*alpha
  p['phase']=[]
  for mass in p['m']:
   u=log2(mass/p['m'][0]);j=int(float(u.mid())/float(h))
   while not (u>=A(j*h)):j-=1
   while u>=A((j+1)*h):j+=1
   assert u>=A(j*h) and u<A((j+1)*h)
   p['phase'].append(j)
 # Slots contain true window start log mass and exact phase. Cross terms all retained.
 slots=[(i,k) for i in range(4) for k in range(2)]
 def gram(i,k,j,l,part='full'):
  p,r=parents[i],parents[j]
  if p['phase'][k]!=r['phase'][l]:return arb(0)
  if part=='full':ip,iq=p['I'][k],r['I'][l]
  elif part=='old':ip,iq=p['I'][0],r['I'][0]
  else:raise ValueError(part)
  mass=sum((z['M']*x*y for z,x,y in zip(sources,ip,iq)),F(0))
  return A(p['V']*r['V']*p['t']*r['t']*mass/(p['R']**N*r['R']**N*(G if k else 1)*(G if l else 1)))*tau(log2(p['m'][k]/r['m'][l]))
 M=[[gram(i,k,j,l) for j,l in slots] for i,k in slots]
 def energy(weights):return sum((A(weights[u]*weights[v])*M[u][v] for u in range(8) for v in range(8)),arb(0))
 w0=[F(0),one]*4
 Eend=energy(w0)
 Qbulk=sum((A(p['V']*r['V'])*K[i][j] for i,p in enumerate(parents) for j,r in enumerate(parents)),arb(0))
 assert (energy([one,F(0)]*4)-Qbulk).contains(0)
 # Directions replace only each target's endpoint by its old action.
 ds=[]
 for i in [1,2]:
  d=[F(0)]*8;d[2*i]=one;d[2*i+1]=-one;ds.append(d)
 def bil(u,v):return sum((A(u[i]*v[j])*M[i][j] for i in range(8) for j in range(8)),arb(0))
 c=[bil(d,w0) for d in ds];H=[[bil(d,e) for e in ds] for d in ds]
 det=H[0][0]*H[1][1]-H[0][1]*H[1][0]
 assert H[0][0]>0 and det>0
 x=[(-H[1][1]*c[0]+H[0][1]*c[1])/det,(H[1][0]*c[0]-H[0][0]*c[1])/det]
 assert all(z>0 and z<1 for z in x)
 # Analytic unique global optimum on the two-probability square, coefficients interval certified.
 Emin=Eend+c[0]*x[0]+c[1]*x[1]
 assert Eend-Emin>0
 # Rational feasible law near optimum, exact normalization.
 D=2**160
 xr=[F(round(float(z.mid())*D),D) for z in x]
 w=w0[:]
 for d,z in zip(ds,xr):w=[v+z*e for v,e in zip(w,d)]
 assert all(z>=0 for z in w) and all(w[2*i]+w[2*i+1]==1 for i in range(4))
 Emix=energy(w);assert Eend-Emix>0
 # Independent common-source/time feature evaluation with full centers integrated as V_p.
 # Intersect clocks analytically, sum source columns before source integration.
 Esource=arb(0);O2=arb(0);ON=arb(0);N2=arb(0)
 for u,(i,k) in enumerate(slots):
  for v,(j,l) in enumerate(slots):
   p,r=parents[i],parents[j]
   if p['phase'][k]!=r['phase'][l]:continue
   coeff=A(w[u]*w[v]*p['V']*r['V']*p['t']*r['t']/(p['R']**N*r['R']**N*(G if k else 1)*(G if l else 1)))*tau(log2(p['m'][k]/r['m'][l]))
   for z,ip,iq,op,oq in zip(sources,p['I'][k],r['I'][l],p['I'][0],r['I'][0]):
    Esource+=coeff*A(z['M']*ip*iq);O2+=coeff*A(z['M']*op*oq);ON+=coeff*A(z['M']*op*(iq-oq));N2+=coeff*A(z['M']*(ip-op)*(iq-oq))
 assert (Esource-Emix).contains(0) and (Emix-O2-2*ON-N2).contains(0)
 # Exact old-source disintegration masses sum to one for each p; never replace by unrelated probabilities.
 assert all(sum((z['M']*ip/p['m'][0] for z,ip in zip(sources,p['I'][0])),F(0))==1 for p in parents)
 report={'status':'PASS_TRUE_LEBESGUE_BLOCK_BULK_AND_STRICT_MIXING_GAIN','n':N,'parameters':{'a':str(a),'b':str(b),'G':str(G),'G_decimal':A(G).str(18),'gamma':'2','h':str(h),'beta':'1/4','S':'1','q':str(q),'lambda_band':str(lam),'W':str(W),'An':iv(An),'C':iv(C)},'geometry':{'source_density':'Each true uniform box has density M/volume(U), finite positive exact rational.','source_cell':'One grid cell centered at zero, side n*b/beta, with beta=1/4; all expanded source cubes inside with margin.','centers':'Exact H_p, dB unchanged, all 8 action capture/exclusion signatures certified on entire blocks.','other_center_coordinates':list(map(str,base[0])),'other_source_coordinates':list(map(str,other[0]))},'sources':[{'name':z['name'],'first_coordinate':list(map(str,z['U'][0])),'mass':str(z['M'])} for z in sources],'parents':[{'name':p['name'],'first_center_coordinate':list(map(str,p['H'][0])),'R':str(p['R']),'t':str(p['t']),'V':str(p['V']),'V_decimal':A(p['V']).str(18),'m':list(map(str,p['m'])),'signature':p['I'],'phase':p['phase'],'alpha':iv(p['alpha']),'Kslow':iv(p['Kslow']),'bulk':'PASS high, slow strict, non-top strict; frozen full old E score'} for p in parents],'energies':{'Q_bulk':iv(Qbulk),'endpoint':iv(Eend),'rational_mixture':iv(Emix),'endpoint_minus_mixture':iv(Eend-Emix),'relative_gain':iv((Eend-Emix)/Eend),'restricted_analytic_minimum':iv(Emin),'endpoint_minus_restricted_minimum':iv(Eend-Emin),'O2':iv(O2),'twice_ON':iv(2*ON),'N2':iv(N2)},'optimization_certificate':{'scope':'Only target_small and target_large old probabilities vary in [0,1]^2; background and zero-growth fixed endpoint. Not global over all parents/all g.','formula':'E(x)=Eend+2 c^T x+x^T H x; x*=-H^-1 c, exact analytic expression with Arb enclosure.','H00':iv(H[0][0]),'det_H':iv(det),'c':[iv(z) for z in c],'x_star':[iv(z) for z in x],'rational_old_probabilities':list(map(str,xr)),'strict_interior':True,'positive_definite':True,'rational_law_exactly_normalized':True},'guards':{'two_distinct_R':True,'two_distinct_m':True,'common_new_source_targets':'common_new, captured by both endpoint targets and neither old target','same_phase_cross_parent':'Both endpoint targets phase2, true window starts identical log2(51/50), hence positive full overlap; both old actions phase0 also positive overlap.','zero_growth':'zero_growth has m(1)=m(G)=51/50, hence whole mass curve constant and every g phase0. Positive original t=G^-2 preserved.','all_bulk':True,'all_four_bulk_parents_have_normalized_legal_laws':True,'delta1_equals_Qbulk':True,'all_cross_parent_terms':True,'source_feature_and_Gram_difference_contains_zero':True,'full_split_difference_contains_zero':True,'old_source_denominator_normalizations_exact':True},'limits':['Finite exact construction only; no general weak-type bound.','Mixture uses two legal atoms {1,G}; does not certify R604 continuous Xi-tilted policy.','Minimum certificate is restricted two-probability family, not all-action/full-gap optimum.','Tiny gain and large G do not establish useful mother-ledger absorption.','No midpoint-center approximation, Monte Carlo, or numerical source sampling.'],'runtime_seconds':time.perf_counter()-START,'maxrss_bytes_macos':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'interpreter':sys.executable,'arb_bits':ctx.prec,'processes':1,'search':'Two hand-constructed candidates (initial n256, retained n56); no grid or random parameter scan.'}
 return report

initial=compute({'n':256,'s':F(33,32),'bg_right':F(-189,1000),'target_left':F(-1,100000),'new_lo':F(51,100),'new_hi':F(5101,10000),'bg_lo':F(-703,1000),'bg_hi':F(-702,1000)})
final=compute({'n':56,'s':F(9,8),'bg_right':F(-3,20),'target_left':F(-1,100),'new_lo':F(27,50),'new_hi':F(541,1000),'bg_lo':F(-141,200),'bg_hi':F(-88,125)})
final['initial_n256_candidate']=initial
final['total_runtime_seconds']=time.perf_counter()-START
(Path(sys.argv[1]) if len(sys.argv)>1 else Path('/tmp/ccu_r606_numeric.json')).write_text(json.dumps(final,indent=2)+'\n')
for r in [initial,final]:
 print(json.dumps({'n':r['n'],'status':r['status'],'G':r['parameters']['G_decimal'],'energies':{k:v['display'] for k,v in r['energies'].items()},'x_star':[v['display'] for v in r['optimization_certificate']['x_star']],'alpha':[p['alpha']['display'] for p in r['parents']],'Kslow':[p['Kslow']['display'] for p in r['parents']],'seconds':r['runtime_seconds']},indent=2))
