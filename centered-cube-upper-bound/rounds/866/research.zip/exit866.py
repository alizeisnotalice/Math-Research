"""Exact two-layer coupon escape in genuine overlapping physical parents."""

from dataclasses import dataclass
from fractions import Fraction as F
from sys import version

from flint import __version__ as flint_version
from flint import arb, ctx

ctx.prec = 320
LAMBDA = F(3,4)
J1 = F(1,256)
ONE = frozenset((0,))
TWO = frozenset((1,))
BOTH = ONE|TWO


def ball(x):
    return arb(x.numerator)/x.denominator


def fmt(x):
    return (x if isinstance(x,arb) else ball(x)).str(10)


@dataclass(frozen=True)
class Cell:
    layer: str
    interval: tuple
    members: frozenset
    eta: F


def physical_geometry(delta,owner_ratio,refined=False):
    parents=((F(-1),F(1)),(1-delta,3-delta))
    assert all(b-a==2 for a,b in parents)
    j2=J1*owner_ratio
    receivers=((F(0),J1),(2-delta-j2,2-delta))
    assert receivers[0][1]<receivers[1][0]
    js=[hi-lo for lo,hi in receivers]
    # True receiver heights on the physical edge-length window [1,2].
    # The side-two witness misses at most one short endpoint piece of a
    # unique region. Any window that sees the spike has side >=2(1-delta-j_max).
    unique_density=1/(2-delta)
    jmax=max(js)
    assert 1-jmax*unique_density/2>LAMBDA
    assert unique_density+1/(2*(1-delta-jmax))<2*LAMBDA

    points=sorted({x for parent in parents for x in parent})
    cells=[]
    for layer in ("S","X"):
        if not refined:
            cuts=(F(0),F(1))
        elif layer=="S":
            cuts=(F(0),F(1,3),F(2,3),F(1))
        else:
            cuts=(F(0),F(1,2),F(1))
        for lo,hi in zip(points,points[1:]):
            mid=(lo+hi)/2
            is_in=frozenset(i for i,(a,b) in enumerate(parents) if a<mid<b)
            assert is_in
            density=1/(hi-lo) if layer=="S" else LAMBDA
            for u,v in zip(cuts,cuts[1:]):
                left,right=lo+(hi-lo)*u,lo+(hi-lo)*v
                cells.append(Cell(layer,(left,right),is_in,density*(right-left)))
    source_mass=[sum(c.eta for c in cells if c.layer=="S" and i in c.members)
                 for i in range(2)]
    assert source_mass==[2,2]
    assert sum(c.eta for c in cells if c.layer=="S")==3
    assert sum(c.eta for c in cells if c.layer=="X" and c.members==BOTH)==LAMBDA*delta
    costs=[j/m for j,m in zip(js,source_mass)]  # r_i=1, true owner Lebesgue weights
    return cells,costs


def label_law(members,costs,m,forced=()):
    assert set(forced)<=members and len(forced)<=m
    rate=sum(costs[i] for i in members)
    if len(members)==1:
        return {members:F(1)}
    choices={frozenset((i,)):(costs[i]/rate)**(m-len(forced))
             for i in members if all(j==i for j in forced)}
    choices[BOTH]=1-sum(choices.values())
    assert all(probability>=0 for probability in choices.values())
    return choices


def transition(members,cells,costs,m,forced=()):
    laws=label_law(members,costs,m,forced)
    actual_eta={selected:sum(c.eta for c in cells if selected<=c.members)
                for selected in laws}
    out=[sum((q*c.eta/actual_eta[selected] for selected,q in laws.items()
              if selected<=c.members),F(0)) for c in cells]
    assert sum(out)==1
    return out


def row_product(row,matrix):
    return [sum(weight*entry for weight,entry in zip(row,col)) for col in zip(*matrix)]


def multiply(left,right):
    return [row_product(row,right) for row in left]


def apply_power(row,matrix,length):
    current=[r[:] for r in matrix]
    while length:
        if length%2:
            row=row_product(row,current)
        length//=2
        if length:
            current=multiply(current,current)
    return row


def reversible(cells,costs,m,matrix):
    pi=[c.eta*sum(costs[i] for i in c.members)**m for c in cells]
    assert all(pi[i]*matrix[i][j] == pi[j]*matrix[j][i]
               for i in range(len(cells)) for j in range(len(cells)))
    assert row_product(pi,matrix)==pi
    return pi


def mesh_audit(delta,owner_ratio,m,cells,costs,matrix,pi):
    fine,prices=physical_geometry(delta,owner_ratio,True)
    assert costs==prices
    rows=[transition(c.members,fine,prices,m) for c in fine]
    masses=reversible(fine,prices,m,rows)
    keys=[(c.layer,c.members) for c in cells]
    marks=[keys.index((c.layer,c.members)) for c in fine]
    for j,amount in enumerate(pi):
        selectors=[i for i,label in enumerate(marks) if j==label]
        assert sum(masses[i] for i in selectors)==amount
        for index,row in enumerate(rows):
            assert sum(row[i] for i in selectors)==matrix[marks[index]][j]
    for prefix in ((0,1),(0,0)):
        refined=transition(BOTH,fine,prices,m,prefix)
        plain=transition(BOTH,cells,costs,m,prefix)
        for j,amount in enumerate(plain):
            assert sum(v for v,u in zip(refined,marks) if u==j)==amount


def finite_exits(start,killed,length):
    alive=apply_power(start,killed,length-1)
    return 1-sum(alive)


def arb_exit(start,killed,length):
    alive=apply_power(list(map(ball,start)),[list(map(ball,row)) for row in killed],length-1)
    value=1-sum(alive)
    assert 0<value<1 and value.rad() < arb(2)**-200
    return value


def exercise(label,delta,m,owner_ratio,times,long=None):
    cells,costs=physical_geometry(delta,owner_ratio)
    matrix=[transition(c.members,cells,costs,m) for c in cells]
    pi=reversible(cells,costs,m,matrix)
    mesh_audit(delta,owner_ratio,m,cells,costs,matrix,pi)
    src=[j for j,c in enumerate(cells) if c.layer=="S"]
    killed=[[matrix[i][j] for j in src] for i in src]
    start_point=1-delta/2
    assert next(c for c in cells if c.layer=="S" and c.interval[0]<start_point<c.interval[1]).members==BOTH
    mixed=transition(BOTH,cells,costs,m,(0,1))
    same=transition(BOTH,cells,costs,m,(0,0))
    mixed=[mixed[j] for j in src]
    same=[same[j] for j in src]
    overlap_index=[cells[j].members for j in src].index(BOTH)
    both_exit=LAMBDA*delta/(1+LAMBDA*delta)
    one_exit=LAMBDA/(1+LAMBDA)
    alpha=costs[0]/sum(costs)
    all_same=alpha**m+(1-alpha)**m
    p_from_overlap=1-sum(killed[overlap_index])
    assert 1-sum(mixed)==both_exit
    assert p_from_overlap==one_exit*all_same+both_exit*(1-all_same)
    assert 1-sum(same)==one_exit*alpha**(m-2)+both_exit*(1-alpha**(m-2))

    T=times[-1]
    pi_s=[pi[j] for j in src]
    escape=[1-sum(row) for row in killed]
    via_telescoping=sum(pi_s)-sum(apply_power(pi_s,killed,T))
    row=pi_s[:]
    true_terminal=[]
    for _ in range(T):
        true_terminal.append(sum(a*b for a,b in zip(row,escape)))
        row=row_product(row,killed)
    assert sum(true_terminal)==via_telescoping
    assert 0<via_telescoping<sum(pi_s)

    print(f"{label}, delta={delta}, overlap density={1/delta}, m={m}, true j2/j1={owner_ratio}.")
    print(f"  physical fixed source z=1-delta/2, forced parent indices (i,t)=(1,2), lambda={LAMBDA}.")
    print(f"  forced mixed one-step exit {fmt(both_exit)}, forced equal indices one-step {fmt(1-sum(same))}.")
    print(f"  free overlap one-step exit {fmt(p_from_overlap)}, all-same coupon probability {fmt(all_same)}.")
    q=[finite_exits(mixed,killed,t) for t in times]
    assert q[:2]==[both_exit,both_exit+(1-both_exit)*p_from_overlap]
    assert all(a<b for a,b in zip(q,q[1:]))
    print("  fixed mixed cumulative physical exits",[(t,fmt(x)) for t,x in zip(times,q)])
    print(f"  pi detailed balance exact on both layers. Killed telescoping at T={T}, raw pi charge {fmt(via_telescoping)}, "
          f"normalized charge {fmt(via_telescoping/sum(pi_s))}.")
    if long:
        # While the actual source remains in overlap, failure to remain there
        # has probability <= p_both+s. Reaching an exclusive cell is only
        # counted as potential success in this unconditional upper envelope.
        poly=m*m
        up=both_exit+(poly-1)*(both_exit+all_same)
        polynomial=arb_exit(mixed,killed,poly)
        assert both_exit<delta and up<poly*(delta+all_same)
        assert polynomial<ball(up) and up < F(1,2**24)
        rare=arb_exit(mixed,killed,long)
        assert rare>arb("0.2")
        print(f"  T=m^2={poly}, exit {fmt(polynomial)}, analytic union upper {fmt(up)}.")
        print(f"  longer real relabel horizon T={long}, exit {fmt(rare)} certified in Arb.")
    print("  Repartitioning S and X into different exact physical subdivisions preserves all the rows and weights.")
    return both_exit,q[-1]


if __name__=="__main__":
    print(f"Python {version.split()[0]}, python-flint {flint_version}, exact Fractions and Arb {ctx.prec} bits.")
    print("Two real intervals of length 2, one common delta-wide unit-mass source and one exclusive unit source per parent.")
    print("Original mass in each true parent is 2. Each receiving interval E_i is positive, disjoint and in the same height band.")
    print("eta on S is mu and on X is lambda dx. A coupon chooses a_i=j_i/m_i from true owner i available at the physical position.")
    print("The ordered coupons are iid after the actual forced indices. Their intersection resamples eta in the two layers.")
    print("pi=(W*)^m eta; Q is the killed source block, and Q^T in the charge denotes a T-step power.")
    a=exercise("INITIAL",F(1,8),2,F(1),(1,2,16))
    b=exercise("SOURCE CONCENTRATION ONLY",F(1,2**48),2,F(1),(1,2,16))
    c=exercise("EQUAL OWNER COUPON PRESSURE",F(1,2**120),40,F(1),(1,2,16),2**39)
    d=exercise("TRUE OWNER WEIGHT CHANGE",F(1,2**120),40,F(1,15),(1,2,16))
    assert a[0]>b[0]>c[0]==d[0]
    assert b[1]>F(9,10) and c[1]<F(1,2**34) and d[1]>F(1,4)
    print("For equal owners and delta=2^(-3m), the forced mixed exit by T is bounded by T*(2^(-3m)+2^(1-m)).")
    print("Thus any horizon polynomial in the coupon count is small along this family.")
    print("The certificate covers this two-parent finite operator geometry. There is no full high-dimensional history.")
