"""R866: finite two-layer Gibbs walk with four real parent coupons."""
from argparse import ArgumentParser
from collections import defaultdict, deque
from fractions import Fraction as F
from functools import reduce
from hashlib import sha256
from itertools import product
from math import prod
from pathlib import Path
from zipfile import ZipFile
import json
import sys

from flint import arb, ctx, __version__ as FLINT

PIN_BOXES="b0c76daebb3fe4ce5e399d80dc85f2a31da995df1e5c927004bc81dbad54c3eb"
PIN_ARCHIVE="7e9a3f93ae1328b6c8d62e6d34e1d67082963fc6c44e20d74055193808bd617d"
TIMES=(1,2,4,8,64)
LEVELS=(1,10**5,10**8)


def helpers(rounds):
    archive=rounds/"865"/"research.zip"
    assert sha256(archive.read_bytes()).hexdigest()==PIN_ARCHIVE
    with ZipFile(archive) as z:
        name="boxes865.py"
        code=z.read(name)
        manifest=json.loads(z.read("MANIFEST.json"))["sha256"]
        assert manifest[name]==PIN_BOXES
    assert sha256(code).hexdigest()==PIN_BOXES
    env={"__name__":"chain866_upstream","__file__":"boxes865.py"}
    exec(compile(code,"boxes865.py","exec"),env)
    return env


def A(x):
    return arb(x.numerator)/x.denominator


def fmt(x):
    return "0" if x==0 else (A(x) if isinstance(x,F) else x).str(10,radius=True)


def physical_cells(parents):
    all_bits=sum(p["bit"] for p in parents.values())
    data={all_bits:F(1)}
    for axis in zip(*(p["box"] for p in parents.values())):
        boundary=sorted({x for b in axis for x in b})
        row=defaultdict(F)
        for a,b in zip(boundary,boundary[1:]):
            x=(a+b)/2
            bits=sum(p["bit"] for p,(u,v) in zip(parents.values(),axis) if u<x<v)
            row[bits]+=b-a
        nxt=defaultdict(F)
        for (a,v),(b,w) in product(data.items(),row.items()):
            nxt[a&b]+=v*w
        data=nxt
    data.pop(0,None)
    for code in range(1,all_bits+1):
        boxes=[p["box"] for p in parents.values() if p["bit"]&code]
        exact=prod(max(F(0),min(b for a,b in d)-max(a for a,b in d)) for d in zip(*boxes))
        assert exact==sum(v for q,v in data.items() if q&code==code)
    return dict(sorted(data.items()))


def convolve(coupons,arity,seed=0):
    out={seed:F(1)}
    for _ in range(arity):
        nxt=defaultdict(F)
        for (bits,mass),(b,w) in product(out.items(),coupons.items()):
            nxt[bits|b]+=mass*w
        out=nxt
    return dict(out)


class Walk:
    def __init__(self,parents,src,leb,source_cut,receiver_cut,records):
        self.source={q:src[q] for q in sorted(source_cut)}
        self.leb=leb
        self.rates={p["bit"]:receiver_cut[i]*p["j"]/p["m"] for i,p in parents.items()
                    if receiver_cut[i]}
        self.coupons={y:{i:v for i,v in self.rates.items() if y&i}
                      for y in sorted(set(self.source)|set(self.leb))}
        self.W={y:sum(p.values()) for y,p in self.coupons.items()}
        self.laws={y:convolve(p,4) for y,p in self.coupons.items() if p}
        for y,g in self.laws.items():
            assert sum(g.values())==self.W[y]**4
        self.unconditioned=convolve(self.rates,4)
        self.first={}
        endpoint=sorted({(t,x[0],x[1]) for t,l,r in records for x in (l,r)})
        for t,g,y in endpoint:
            a,b=(parents[i]["bit"] for i in (t,g))
            assert a in self.coupons[y] and b in self.coupons[y]
            v=convolve(self.coupons[y],2,a|b)
            normalizer=self.W[y]**2
            assert sum(v.values())==normalizer
            self.first[t,g,y]={k:p/normalizer for k,p in v.items()}
        self.families={}
        for k in self.unconditioned:
            d={y:v for y,v in self.source.items() if y&k==k}
            p={y:v for y,v in self.leb.items() if y&k==k}
            self.families[k]=(d,p,sum(d.values()),sum(p.values()))
        assert all(d and p and m>0 and v>0 for q in self.first.values()
                   for k in q for d,p,m,v in (self.families[k],))

    def kernel(self,level,anchor=None):
        fixed=0 if anchor is None else anchor[1]
        order=4 if anchor is None else 3
        conditioned=(self.laws if anchor is None else
                     {y:convolve(v,order,fixed) for y,v in self.coupons.items()
                      if fixed in v})
        first_law=(self.first if anchor is None else
                   {arm:p for arm,p in self.first.items() if arm[0]==anchor[0]})
        unconditional=(self.unconditioned if anchor is None else convolve(self.rates,order,fixed))
        assert first_law
        posterior={}
        for k,(d,p,m,v) in self.families.items():
            den=m+level*v
            if not den:
                continue
            posterior[k]={(0,y):w/den for y,w in d.items()} | {(1,y):level*w/den for y,w in p.items()}
            assert sum(posterior[k].values())==1

        def mix(prob):
            row=defaultdict(F)
            for k,w in prob.items():
                for cell,p in posterior[k].items():
                    row[cell]+=w*p
            assert sum(row.values())==1
            return dict(row)

        common={y:mix({k:w/self.W[y]**order for k,w in v.items()}) for y,v in conditioned.items()}
        start={arm:mix(q) for arm,q in first_law.items()}
        prior={}
        for arm,q in first_law.items():
            old=sum(w*min(F(1),level*self.families[k][3]/self.families[k][2]) for k,w in q.items())
            true=sum(v for (sheet,y),v in start[arm].items() if sheet==1)
            assert old/2<=true<=old
            prior[arm]=old
        states=tuple((r,y) for r,q in enumerate((self.source,self.leb)) for y in q)
        kernel={x:common.get(x[1],{x:F(1)}) for x in states}
        assert all(dest in kernel for r in kernel.values() for dest in r)
        pi={(i,y):(level if i else F(1))*data[y]*self.W[y]**order if y in common else F(0)
            for i,data in enumerate((self.source,self.leb)) for y in data}
        assert all(pi[x]*p==pi[y]*kernel[y].get(x,F(0))
                   for x,row in kernel.items() for y,p in row.items())
        incoming=defaultdict(F)
        for x,row in kernel.items():
            for y,p in row.items():
                incoming[y]+=pi[x]*p
        assert all(incoming[q]==pi[q] for q in pi)
        flux=[sum(pi[x]*p for x,row in kernel.items() if x[0]==side
                  for y,p in row.items() if y[0]!=side) for side in (0,1)]
        separate=F(0)
        for k,w in unconditional.items():
            _,_,d,v=self.families[k]
            if d and v:
                separate+=w*d*level*v/(d+level*v)
        assert flux[0]==flux[1]==separate>0
        totals=tuple(sum(p for x,p in pi.items() if x[0]==side) for side in (0,1))
        first_h={arm:sum(w for x,w in row.items() if x[0]) for arm,row in start.items()}
        # A positive initial self-mask survivor and regular self-loop
        # rule out exact full hitting at every finite time.
        for arm,row in start.items():
            x=(0,arm[2])
            assert row[x]>0 and kernel[x][x]>0
        return kernel,start,prior,first_h,totals,separate


def hitting(kernel,start,bits):
    ctx.prec=bits
    sources={x:row for x,row in kernel.items() if x[0]==0}
    def local(row):
        base=sum(w for x,w in row.items() if x[0])
        jump={x:A(w) for x,w in row.items() if not x[0]}
        assert base+sum(w for x,w in row.items() if not x[0])==1
        return A(base),jump

    regular={x:local(row) for x,row in sources.items()}
    first={a:local(row) for a,row in start.items()}
    prev=dict.fromkeys(sources,arb(0))
    kept={}
    for step in range(1,max(TIMES)+1):
        def step_from(spec):
            base,jump=spec
            val=base+sum((p*prev[x] for x,p in jump.items()),arb(0))
            assert 0<=val or val.overlaps(arb(0))
            assert val<=1 or val.overlaps(arb(1))
            return val
        if step in TIMES:
            kept[step]={a:step_from(spec) for a,spec in first.items()}
        new={x:step_from(spec) for x,spec in regular.items()}
        assert all(new[x]>=prev[x] or new[x].overlaps(prev[x]) for x in prev)
        prev=new
    return kept


def aggregate(h,raw,parents):
    value=[arb(0)]*3
    spots=[defaultdict(arb),defaultdict(arb)]
    original=[defaultdict(F),defaultdict(F)]
    for (t,l,r),w in raw.items():
        a,b=(h[t,i,y] for i,y,k in (l,r))
        f=(a.sqrt(),b.sqrt(),a.max(b).sqrt())
        for j,x in enumerate(f):
            value[j]+=A(w)*x
        for j,(i,y,k) in enumerate((l,r)):
            spots[j][i,k]+=A(w)*f[-1]
            original[j][i,k]+=w
    for table,unclipped in zip(spots,original):
        assert sum(table.values(),arb(0)).overlaps(value[-1])
        for (i,k),w in unclipped.items():
            assert w<=parents[i]["owner_volume"]/2
            assert table[i,k]<A(w) or table[i,k].overlaps(A(w))
    peak=tuple(reduce(arb.max,(2*w/A(parents[i]["owner_volume"]) for (i,k),w in q.items()))
               for q in spots)
    return tuple(x/A(sum(raw.values())) for x in value),peak


def residual_cut_flow(capacities,start,end):
    graph=defaultdict(list)
    forward={}
    for (u,v),capacity in capacities.items():
        assert u!=v and capacity>=0
        forward[u,v]=len(graph[u])
        graph[u].append([v,len(graph[v]),capacity])
        graph[v].append([u,len(graph[u])-1,F(0)])
    total=F(0)
    roots=sum(c for (u,v),c in capacities.items() if u==start)
    while True:
        levels={start:0}
        q=deque([start])
        while q:
            u=q.popleft()
            for v,back,capacity in graph[u]:
                if capacity>0 and v not in levels:
                    levels[v]=levels[u]+1
                    q.append(v)
        if end not in levels:
            break
        cursors=defaultdict(int)
        def add_flow(u,remaining):
            if u==end:
                return remaining
            while cursors[u]<len(graph[u]):
                arc=graph[u][cursors[u]]
                v,back,capacity=arc
                if capacity>0 and levels.get(v,-1)==levels[u]+1:
                    sent=add_flow(v,min(capacity,remaining))
                    if sent:
                        arc[2]-=sent
                        graph[v][back][2]+=sent
                        return sent
                cursors[u]+=1
            return F(0)
        while sent:=add_flow(start,roots):
            total+=sent
    # Explicit feasible flow and explicit cut have matching exact values.
    balance=defaultdict(F)
    witness={}
    for (u,v),capacity in capacities.items():
        sent=capacity-graph[u][forward[u,v]][2]
        assert 0<=sent<=capacity
        witness[u,v]=sent
        balance[u]-=sent
        balance[v]+=sent
    assert balance[start]==-total and balance[end]==total
    assert all(v==0 for k,v in balance.items() if k not in (start,end))
    cut=sum(cap for (u,v),cap in capacities.items() if u in levels and v not in levels)
    assert cut==total
    return total,set(levels),sum(v>0 for v in witness.values())


def deficiency_report(walk,kernel,Z):
    # Both layers of Q are unmodified. Here Lebesgue is a sink, and all
    # positive stationary source states stand in for the high set.
    start,end="input","Leb sink"
    pi={y:m*walk.W[y]**4 for y,m in walk.source.items() if walk.W[y]}
    actual=sum(pi.values())
    assert actual==Z[0]
    J={}
    for y,m in pi.items():
        row=kernel[0,y]
        for z in pi:
            if y!=z and row.get((0,z),F(0)):
                J[y,z]=m*row[0,z]
        exit_flow=m*sum(v for (r,z),v in row.items() if r)
        assert exit_flow>0
        J[y,end]=exit_flow
    assert all(x in pi for (x,y) in J)
    assert all(J[z,y]==v for (y,z),v in J.items() if z!=end)
    print("   Local sample proof diagnostic: every positive stationary source cell is high.",
          "Unnormalized exact pi(S):",actual)
    for phi in map(F,("1/64","1/8","1/2")):
        c=J|{(start,y):phi*m for y,m in pi.items()}
        value,frontier,used=residual_cut_flow(c,start,end)
        E=set(pi)&frontier
        weight=sum(pi[y] for y in E)
        internal=sum(v for (y,z),v in J.items() if y in E and z not in E and z!=end)
        sink=sum(J[y,end] for y in E)
        deficiency=actual-value/phi
        assert deficiency==weight-(internal+sink)/phi>=0
        print("    phi",phi,"; d/pi(S)",fmt(deficiency/actual),
              "; mincut normalized by phi*pi(S)",fmt(value/(phi*actual)),
              "; matching feasible arcs",used)
        print("      maximizing E (true source masks)",tuple(sorted(E)),
              "; pi(E)/pi(S), internal crossing/pi(S), Leb crossing/pi(S):",
              *(fmt(v/actual) for v in (weight,internal,sink)))


def param_report(walk,groups,parents,level):
    kernel,start,old,one,Z,flux=walk.kernel(F(level))
    low=hitting(kernel,start,192)
    hi=hitting(kernel,start,384)
    assert all(hi[t][a].overlaps(low[t][a]) for t in TIMES for a in walk.first)
    assert all(hi[1][a].overlaps(A(one[a])) for a in walk.first)
    print(" lambda =",level,"; reversible one-step crossing flux per stationary source, Leb, total:",
          *(fmt(flux/d) for d in (*Z,sum(Z))),
          "; stationary Leb fraction",fmt(Z[1]/sum(Z)))
    if level==1:
        print("   exact stationary source-normalized crossing flux:",flux/Z[0])
    print("   exact first-step hit bounds across actual endpoints:",fmt(min(one.values())),fmt(max(one.values())))
    if level in (1,10**5):
        deficiency_report(walk,kernel,Z)
    for name,d in groups:
        x,_=aggregate({a:A(p) for a,p in old.items()},d,parents)
        print("   ",name,"previous clipped four-parent L/R/max (same lambda):",tuple(fmt(y) for y in x))
    for T in TIMES:
        print("   T =",T)
        for name,d in groups:
            x,peak=aggregate(hi[T],d,parents)
            print("    ",name,"h_L^(1/2), h_R^(1/2), max",tuple(fmt(y) for y in x),
                  "; original U/W half peak",tuple(fmt(y) for y in peak))



def anchored_report(walk,parents,groups):
    print(" Fixed-t control for lambda=1: after the initial t,g,h,k redraw, keep actual t and refresh three iid coupons.")
    frames={}
    for bits in (192,384):
        joint={T:{} for T in TIMES}
        for t in sorted({a[0] for a in walk.first}):
            kernel,start,_,_,_,_=walk.kernel(F(1),anchor=(t,parents[t]["bit"]))
            hit=hitting(kernel,start,bits)
            for T,d in hit.items():
                assert not (d.keys() & joint[T].keys())
                joint[T].update(d)
        assert all(d.keys()==walk.first.keys() for d in joint.values())
        frames[bits]=joint
    for T in (1,2,8,64):
        assert all(v.overlaps(frames[192][T][a]) for a,v in frames[384][T].items())
        for name,d in groups:
            x,_=aggregate(frames[384][T],d,parents)
            print("  fixed-t",T,name,"L/R/max actual marks",tuple(fmt(y) for y in x))

def local_small_flow(src,leb,parents,t,smalls,receiver,source_cut):
    bit=parents[t]["bit"]
    mass_t=parents[t]["m"]
    chi=({x:src[x]/mass_t for x in sorted(source_cut) if x&bit},
         {x:m/mass_t for x,m in leb.items() if x&bit})
    assert sum(chi[0].values())==sum(chi[1].values())==1
    a={parents[i]["bit"]:receiver[i]*parents[i]["j"]/parents[i]["m"] for i in smalls}
    assert a and min(a.values())>0
    family={}
    for bits in convolve(a,3):
        d=sum(m for x,m in chi[0].items() if x&bits==bits)
        v=sum(m for x,m in chi[1].items() if x&bits==bits)
        family[bits]=(d,v)
    weights={}
    two_layers={}
    sheets=tuple((layer,y,m) for layer,q in enumerate(chi) for y,m in q.items())
    for layer,y,m in sheets:
        laws={b:w for b,w in a.items() if y&b}
        if not laws:
            continue
        W=sum(laws.values())
        grouped=convolve(laws,3)
        assert sum(grouped.values())==W**3
        row=defaultdict(F)
        for b,q in grouped.items():
            den=sum(family[b])
            assert den>0
            for to,x,n in sheets:
                if x&b==b:
                    row[to,x]+=q*n/(W**3*den)
        assert sum(row.values())==1
        two_layers[layer,y]=dict(row)
        weights[layer,y]=m*W**3
    for u,row in two_layers.items():
        assert all(weights[u]*p==weights[v]*two_layers[v].get(u,F(0)) for v,p in row.items())
    pi={y:m for (layer,y),m in weights.items() if not layer}
    return pi,{y:two_layers[0,y] for y in pi},len(chi[0]),len(chi[1]),len(family)


def anchored_small_defects(parents,src,leb,raw,hard,source_cut,freeze):
    print("Actual small-only anchored defect (m=3 small coupons plus fixed t, lambda=1).")
    print("Both true measures in each A_t are divided by m_t; all eligible small rates are a_i=r_i j_i/m_i.")
    print("The eligible lists come from actual original left/right labels, with no higher-dimensional J, eta or d gate inferred.")
    print("All positive stationary source cells are high for this finite diagnostic.")
    for name,rows,B,r in (("full anchored",raw,set(src),dict.fromkeys(parents,F(1))),
                          ("hard anchored",hard,source_cut,freeze)):
        allowance={}
        values={phi:{} for phi in map(F,("1/8","1/2"))}
        for t in sorted({key[0] for key in rows}):
            assert r[t]>0
            elig=tuple(sorted({x[0] for k,l,g in raw if k==t for x in (l,g)
                               if r[x[0]]>0}))
            assert all(parents[i]["role"]=="old" for i in elig)
            pi,Q,nS,nL,nF=local_small_flow(src,leb,parents,t,elig,r,B)
            P=sum(pi.values())
            allowance[t]=r[t]*parents[t]["j"]
            J={(x,y):pi[x]*p for x,row in Q.items() for (sheet,y),p in row.items()
               if not sheet and x!=y}
            exits={x:pi[x]*sum(p for (sheet,y),p in Q[x].items() if sheet) for x in pi}
            J|={(x,"Leb sink"):p for x,p in exits.items()}
            print(" ",name,t,"small labels",elig,"; positive active source cells",len(pi),
                  "out of",nS,"; Leb cells",nL,"; coupon families",nF,
                  "; exact pi_t(S)",P,"; r_t j_t",allowance[t])
            for phi in values:
                arcs=J|{("input",x):phi*w for x,w in pi.items()}
                value,cut,npaths=residual_cut_flow(arcs,"input","Leb sink")
                E=set(pi)&cut
                cross=sum(w for (x,y),w in J.items() if x in E and y not in E)
                d=P-value/phi
                assert d==sum(pi[x] for x in E)-cross/phi>=0
                values[phi][t]=d
                print("   phi",phi,"d_t",fmt(d),"; d_t/pi_t(S)",fmt(d/P),
                      "; cut masks",tuple(sorted(E)),"; matching feasible arcs",npaths)
        denom=sum(allowance.values())
        for phi,m in values.items():
            assert m.keys()==allowance.keys()
            bracket=[]
            for bits in (192,384):
                ctx.prec=bits
                powers={t:(A(d).log()*2/3).exp() if d else arb(0) for t,d in m.items()}
                q=sum((A(allowance[t])*v for t,v in powers.items()),arb(0))/A(denom)
                bracket.append(q)
            assert bracket[0].overlaps(bracket[1])
            print(" ",name,"phi",phi,"r_t j_t denominator",denom,
                  "; weighted mean of d_t^(2/3):",fmt(bracket[-1]))


def replay(rounds):
    old=helpers(rounds)
    parents,src,raw,hard,source,pin,cut=old["load"](rounds)
    A_cut,B,_=cut[-3:]
    qbox=tuple((q-old["QRAD"],q+old["QRAD"]) for q in old["Q"])
    muq=old["real_mass"](source,qbox)
    assert 0<muq<src[95] and 95 in B
    for p in parents.values():
        if p["bit"]&95:
            assert all(x<a<b<y for (a,b),(x,y) in zip(qbox,p["box"]))
        else:
            assert old["volume"](old["meet"](p["box"],qbox))==0
    q_ratio=muq/src[95]
    qfull={k:w*q_ratio for k,w in raw.items() if k[2][1]==95}
    qhard={k:w*q_ratio for k,w in hard.items() if k[2][1]==95}
    assert qfull and qhard
    leb=physical_cells(parents)
    full=dict.fromkeys(parents,F(1))
    freeze={i:F(sum((i,h) in A_cut for h in (0,1)),2) for i in parents}
    print("Python",sys.version.split()[0],"python-flint",FLINT,"; exact Fraction transitions and 192/384 Arb hitting.")
    print("Pinned R865 archive",PIN_ARCHIVE,"; boxes865.py",PIN_BOXES,"; fixed true R814",pin)
    print("Full/hard original records",len(raw),len(hard),"; actual physical Leb cells",len(leb))
    print("Original fixed right q-neighborhood uses its true mu weight",muq,"; full (hard) share of original F",
          fmt(sum(qfull.values())/sum(raw.values())),fmt(sum(qhard.values())/sum(raw.values())))
    print("Initial actual labels t,g and two additional independent same-window coupons; all later source refreshes four iid coupons.")
    print("Conditional rates on true membership cells r_i j_i/m_i; contour G_i=A_i as archived. Source/Leb redraw uses true masses mu_B and lambda dx.")
    print("Inactive source cells remain in the table with isolated self loops and zero stationary weight.")
    print("Detailed balance verified for the unnormalized stationary weights mu_B W^4 and lambda dx W^4; exact flux also integrated by coupons.")
    print("Each mark is max(h_left^(1/2), h_right^(1/2)) on the existing two-arm record and preserves both original weights.")
    print("Each group is normalized by its own original mass. Positive source self-loops exclude exact finite-time certainty.")
    frame=(
        ("full physical window",raw,set(src),full,(("full original",raw),("same q",qfull))),
        ("hard physical half-core and source cut",hard,B,freeze,(("hard original",hard),("same q hard",qhard))),
    )
    for label,d,source_cells,g,groups in frame:
        walk=Walk(parents,src,leb,source_cells,g,d)
        inactive=tuple(q for q in walk.source if not walk.W[q])
        print(label,"; source cells",len(walk.source),"inactive",inactive,
              "; first actual endpoints",len(walk.first),
              "; joint coupon families",len(walk.families),
              "; actual receiver selector",tuple(g.items()))
        for level in LEVELS:
            param_report(walk,groups,parents,level)
        anchored_report(walk,parents,groups)
    anchored_small_defects(parents,src,leb,raw,hard,B,freeze)
    print("All assertions passed. The four-dimensional empirical finite chain is not an all-dimensional exit bound.")


if __name__=="__main__":
    parser=ArgumentParser()
    parser.add_argument("--rounds",type=Path,required=True)
    replay(parser.parse_args().rounds)

