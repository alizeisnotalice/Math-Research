"""Finite deterministic guards for mean occupation / dePoissonization.

Only stdlib is used. Rational geometry and truncated-potential fees/drift
are exact. Decimal 70/110 agreement is a stability guard, not directed
interval arithmetic or a proof for arbitrary measures/dimensions.
"""
from decimal import Decimal as D, localcontext
from fractions import Fraction as F
from math import ceil
from pathlib import Path
import json


def dec(x):
    if isinstance(x, F):
        return D(x.numerator) / D(x.denominator)
    return D(x)


def show(x):
    return format(x, '.17g')


def lower_tail(mean, threshold):
    """Exact finite formula P(Poi(mean)<threshold), Decimal evaluation.

    Every summand is nonnegative; no subtraction of an almost-one CDF.
    """
    term = D(1)
    total = term if threshold > 0 else D(0)
    for j in range(1, threshold):
        term *= mean / D(j)
        total += term
    return (-mean).exp() * total


def poisson_guard(precision):
    with localcontext() as ctx:
        ctx.prec = precision
        rows = []
        for stage, ms in enumerate(((16, 24, 32), (64, 128, 256),
                                   (512, 1024, 2048)), 1):
            for m in ms:
                r = m // 8
                for qm in (F(1, 4), F(1, 2), F(1), F(2), F(32)):
                    q = F(m) * qm
                    tail = lower_tail(dec(q), r)
                    bound1 = (-dec(q) / 8).exp()
                    bound2 = dec(4 * q / m) * (-D(m) / 32).exp()
                    assert q >= F(m, 4) and r <= q / 2
                    assert 0 <= tail <= bound1 <= bound2
                    rows.append(dict(stage=stage, m=m, r=r, q_over_m=str(qm),
                                     q=str(q), lower_tail=show(tail),
                                     exp_minus_q_over_8=show(bound1),
                                     linear_mean_bound=show(bound2),
                                     tail_over_first_bound=show(tail / bound1)))
        return rows


def point_with_entry(entry, n, kind, receiver):
    """All coordinates rational; at least one has norm entry/2."""
    offsets = []
    for j in range(n):
        if j == 0:
            value = entry / 2 * (-1 if kind % 2 else 1)
        else:
            value = entry / 2 * F(((j + 2 * kind) % 5) - 2, 3)
        offsets.append(value)
    return tuple(x + y for x, y in zip(receiver, offsets))


def fixture(name, n):
    a, b, lam = F(1), F(4), F(3, 2)
    receiver = tuple(F((j % 3) - 1, 7) for j in range(n))
    if name == 'spike':
        m = 16
        atoms = [(receiver, lam / 2)]
    elif name == 'asymmetric_multimass':
        m = 64
        specs = [(F(1, 2), F(1, 8)), (F(1), F(1, 8)),
                 (F(3, 2), F(1, 6)), (F(3, 2), F(1, 12)),
                 (F(5, 2), F(1, 3)), (F(4), F(1, 10)),
                 (F(5), F(1, 7))]
        # The two initial atoms have total mass lambda/4 exactly.
        atoms = [(point_with_entry(e, n, j, receiver),
                  lam * (max(a, e) ** n) * w)
                 for j, (e, w) in enumerate(specs)]
    else:
        assert name == 'nested_correlated'
        m = 512
        specs = [(F(1), F(1, 16)), (F(5, 4), F(1, 3)),
                 (F(2), F(1, 8)), (F(3), F(1, 3)),
                 (F(3), F(1, 6)), (F(4), F(1, 4))]
        atoms = [(point_with_entry(e, n, j + 5, receiver), lam * e ** n * w)
                 for j, (e, w) in enumerate(specs)]
    return a, b, lam, m, receiver, atoms


def merge(intervals):
    out = []
    for lo, hi in sorted(intervals):
        if lo >= hi:
            continue
        if out and lo <= out[-1][1]:
            out[-1] = (out[-1][0], max(hi, out[-1][1]))
        else:
            out.append((lo, hi))
    return out


def path_case(name, n):
    a, b, lam, m, receiver, atoms = fixture(name, n)
    c = F(m, 4)
    entries = [2 * max(abs(y - x) for y, x in zip(p, receiver))
               for p, _ in atoms]
    groups = {}
    for e, (_, weight) in zip(entries, atoms):
        if a < e <= b:
            groups[e] = groups.get(e, F(0)) + weight
    initial_mass = sum((w for e, (_, w) in zip(entries, atoms) if e <= a), F(0))
    scales = sorted({a, b, *groups})
    initial_q = F(m) * initial_mass / (lam * a ** n)
    mass = initial_mass
    fees = F(0)
    drift = F(0)
    occupation = D(0)
    exact_exp_occupation = F(1)
    min_integral = D(0)
    pieces = []
    jump_rows = []
    tol = D('1e-35')
    for lo, hi in zip(scales, scales[1:]):
        qlo = F(m) * mass / (lam * lo ** n)
        qhi = F(m) * mass / (lam * hi ** n)
        length = D(n) * dec(hi / lo).ln()
        # dq/dt=-q exactly on every open interval, since t=n log(L/a).
        assert qhi == qlo * (lo / hi) ** n and qhi <= qlo
        above = D(0)
        if qlo >= c and qlo > 0:
            above = min(length, dec(qlo / c).ln())
            exact_exp_occupation *= min((hi / lo) ** n, qlo / c)
        occupation += above
        # Exact integral of q 1_{q<c}; equality points have zero dt mass.
        below_drift = max(F(0), min(qlo, c) - qhi)
        drift += below_drift
        min_piece = dec(c) * above + dec(below_drift)
        min_integral += min_piece
        pieces.append(dict(left=str(lo), right=str(hi), mass=str(mass),
                           q_after_left=str(qlo), q_before_right=str(qhi),
                           duration=show(length), mean_above_time=show(above),
                           exact_below_drift=str(below_drift),
                           integral_min_q_c=show(min_piece)))
        addition = groups.get(hi, F(0))
        qplus = qhi + F(m) * addition / (lam * hi ** n)
        fee = min(qplus, c) - min(qhi, c)
        assert addition >= 0 and fee >= 0
        fees += fee
        if addition:
            jump_rows.append(dict(scale=str(hi), added_mass=str(addition),
                                  q_minus=str(qhi), q_plus=str(qplus),
                                  exact_potential_fee=str(fee)))
        mass += addition
    final_q = F(m) * mass / (lam * b ** n)
    exact_residual = min(final_q, c) - min(initial_q, c) - fees + drift
    assert exact_residual == 0
    # Independent prefix method: direct source membership at every candidate
    # boundary, then form and union threshold intervals in t coordinates.
    independent_boundaries = sorted({a, b, *(e for e in entries if a < e < b)})
    threshold_intervals = []
    independent_min = D(0)
    for lo, hi in zip(independent_boundaries, independent_boundaries[1:]):
        prefix_mass = sum((w for e, (_, w) in zip(entries, atoms) if e <= lo), F(0))
        tlo = D(n) * dec(lo / a).ln()
        thi = D(n) * dec(hi / a).ln()
        if prefix_mass == 0:
            continue
        # q(t)=m*prefix_mass/(lambda*a^n)*exp(-t).
        # In exp(t) coordinates both threshold endpoints are rational, even
        # when the crossing L itself has an irrational nth root.
        exp_start = (lo / a) ** n
        exp_end = min((hi / a) ** n, 4 * prefix_mass / (lam * a ** n))
        if exp_end > exp_start:
            threshold_intervals.append((exp_start, exp_end))
        qstart = F(m) * prefix_mass / (lam * lo ** n)
        qend = F(m) * prefix_mass / (lam * hi ** n)
        if qstart <= c:
            integral = dec(qstart - qend)
        elif qend >= c:
            integral = dec(c) * (thi - tlo)
        else:
            integral = dec(c) * dec(qstart / c).ln() + dec(c - qend)
        independent_min += integral
    united = merge(threshold_intervals)
    union_time = sum((dec(hi / lo).ln() for lo, hi in united), D(0))
    independent_exp_occupation = F(1)
    for lo, hi in united:
        independent_exp_occupation *= hi / lo
    assert independent_exp_occupation == exact_exp_occupation
    assert abs(dec(exact_exp_occupation).ln() - occupation) < tol
    assert abs(union_time - occupation) < tol
    assert abs(independent_min - min_integral) < tol
    assert abs(min_integral - (dec(c) * occupation + dec(drift))) < tol
    T = D(n) * dec(b / a).ln()
    assert -tol <= occupation <= T + tol
    # Deterministic path inequality: derivative equality between entries and
    # nonnegative jumps gives dq >= -q dt as a measure.
    return dict(fixture=name, n=n, m=m, threshold=str(c), a=str(a), b=str(b),
                lambda_value=str(lam), receiver=[str(x) for x in receiver],
                atoms=[dict(position=[str(x) for x in p], mass=str(w),
                            entry_scale=str(e))
                       for (p, w), e in zip(atoms, entries)],
                interval_count=len(pieces), actual_jump_count=len(jump_rows),
                group_count=len(groups), outside_window_atoms=sum(e > b for e in entries),
                initial_q=str(initial_q), final_q=str(final_q),
                T=show(T), D_event=show(occupation), D_independent_union=show(union_time),
                exact_exp_D_event=str(exact_exp_occupation),
                exact_exp_D_independent_union=str(independent_exp_occupation),
                integral_min_q_c=show(min_integral),
                independent_integral_min_q_c=show(independent_min),
                exact_drift=str(drift), exact_jump_fees=str(fees),
                exact_potential_identity_residual=str(exact_residual),
                derivative_between_entries='dq/dt = -q; jumps >= 0',
                intervals=pieces, jumps=jump_rows,
                union_exp_t_intervals=[[str(lo), str(hi)] for lo, hi in united],
                union_t_intervals=[[show(dec(lo).ln()), show(dec(hi).ln())]
                                   for lo, hi in united])


def paths_guard(precision):
    with localcontext() as ctx:
        ctx.prec = precision
        return [path_case(name, n)
                for name in ('spike', 'asymmetric_multimass', 'nested_correlated')
                for n in (1, 2, 4, 8, 16)]


def box_guard(precision):
    with localcontext() as ctx:
        ctx.prec = precision
        rows = []
        for stage in range(3):
            n = (8, 32, 128)[stage]
            m = ceil((D(n) * D(2).ln()).sqrt())
            # Integer N >= m/2 is N >= ceil(m/2).
            half = (m + 1) // 2
            mean = D(2 * m)
            tail = lower_tail(mean, half)
            denominator = F(m - 1, m)
            failure_bound = tail / dec(denominator)
            chernoff_bound = (-D(9 * m) / 16).exp() / dec(denominator)
            assert m > 1 and half - 1 < F(m, 2)
            assert 0 <= tail <= (-D(9 * m) / 16).exp()
            assert failure_bound <= chernoff_bound
            R_over_b = F(n * 2 ** stage)
            # Uniform box [-R,R]^n; all cubes of side L<=b around a core
            # receiver fit in the support when |x_i|<=R-b/2.
            core_ratio = (1 - F(1, 2) / R_over_b) ** n
            boundary_ratio = 1 - core_ratio
            # An outer cube of receiver locations with positive overlap fits
            # within [-R-b/2,R+b/2]^n; record this ratio independently too.
            outer_ratio = (1 + F(1, 2) / R_over_b) ** n
            density = F(2)  # lambda=1, hence rho=2 lambda and qcore=2m.
            assert density == 2 and mean == 2 * m
            rows.append(dict(stage=stage + 1, n=n, m=m,
                             m_choice='ceil(sqrt(n*ln(2)))', half_count=half,
                             q_core=str(2 * m), rho_over_lambda='2',
                             R_over_b=str(R_over_b),
                             exact_core_volume_ratio=str(core_ratio),
                             exact_boundary_volume_ratio=str(boundary_ratio),
                             exact_outer_volume_ratio=str(outer_ratio),
                             core_volume_ratio=show(dec(core_ratio)),
                             boundary_volume_ratio=show(dec(boundary_ratio)),
                             poi_core_lower_tail=show(tail),
                             exact_markov_denominator=str(denominator),
                             short_occupation_probability_upper=show(failure_bound),
                             chernoff_probability_upper=show(chernoff_bound),
                             positive_margin_lower=show(1 - chernoff_bound),
                             normalized_good_occupation_receiver_volume_lower=show(dec(core_ratio) * (1 - chernoff_bound) / 2),
                             occupation_event='O_half < T/m, any T>0',
                             applicability='stationary marginal Poi(2m) at core receiver; no independence in time is assumed'))
        return rows


def lattice_guard():
    """Analytic count-bound guards; no exponentially large grid is built."""
    rows = []
    for stage, ns in enumerate(((1, 2, 4), (8, 16, 32), (64, 128, 256)), 1):
        for n in ns:
            delta = F(1, 10 * n)
            lower = F(1, 2) * (1 - delta) ** n
            upper = F(1, 2) * (1 + delta) ** n
            core = (1 - F(1, 2 * n)) ** n
            normalized_fee_per_T = core * (1 - delta) ** n
            assert (1 - delta) ** n >= 1 - n * delta == F(9, 10)
            assert core >= 1 - n * F(1, 2 * n) == F(1, 2)
            assert lower >= F(9, 20) and upper < 1
            assert normalized_fee_per_T >= F(9, 20)
            rows.append(dict(stage=stage, n=n, delta=str(delta), R_over_b=str(n),
                             density_over_lambda='1/2',
                             exact_q_lower_over_m=str(lower),
                             exact_q_upper_over_m=str(upper),
                             exact_core_ratio=str(core),
                             exact_normalized_band_fee_over_T_lower=str(normalized_fee_per_T),
                             verified_lower_over_m_at_least='9/20',
                             verified_core_at_least='1/2',
                             verified_normalized_band_fee_over_T_at_least='9/20',
                             scope='analytic source-count bound, conditional on grid spacing epsilon/a <= delta; no grid enumeration or weak maximal-ratio computation'))
    return rows


def rotation_guard(precision):
    """Abstract transport source guard, explicitly not cube convolution."""
    with localcontext() as ctx:
        ctx.prec = precision
        rows = []
        for stage, (n, T) in enumerate(zip((3, 8, 32), (256, 1024, 4096)), 1):
            m = ceil(D(T).sqrt())
            assert m >= 16
            c = D(m) / 4
            log4 = D(4).ln()
            assert log4 < dec(F(2 * T, m)) < D(T)
            emT = (-D(T)).exp()
            denominator = 1 - emT
            b = (D(T) / n).exp()  # a=1; t=n log(L).
            bn = D(T).exp()
            assert abs(b ** n / bn - 1) < D('1e-50')
            V = D(T) * bn / denominator
            mass = D(m) * V * denominator / D(T)
            normalized_weak_ratio = V / (mass / D(m))  # lambda=1.
            assert abs(normalized_weak_ratio / (D(T) / denominator) - 1) < D('1e-50')
            assert abs(mass / bn - D(m)) < D('1e-50')
            phase_mass = D(m) * denominator
            phase_truncated = c * log4 + c - D(m) * emT

            def mass_interval(lo, hi):
                return D(m) * ((-lo).exp() - (-hi).exp())

            def truncated_interval(lo, hi):
                result = D(0)
                if lo < log4:
                    result += c * (min(hi, log4) - lo)
                if hi > log4:
                    result += mass_interval(max(lo, log4), hi)
                return result

            phases = []
            for fraction in (F(0), F(1, 4), F(3, 4)):
                start = D(T) * dec(fraction)
                split_mass = mass_interval(start, D(T)) + mass_interval(D(0), start)
                split_truncated = (truncated_interval(start, D(T))
                                   + truncated_interval(D(0), start))
                assert abs(split_mass - phase_mass) < D('1e-50')
                assert abs(split_truncated - phase_truncated) < D('1e-50')
                phases.append(dict(start_phase_over_T=str(fraction),
                                   full_q_phase_integral=show(split_mass),
                                   truncated_q_phase_integral=show(split_truncated)))
            # At the first radius bound R1=a*T/(8*pi*n), cancel pi.
            # These are upper envelopes for the final radius min(R1,a/16).
            energy_over_A_a_squared = F(5, 32 * n * n)
            energy_cap_over_A_a_squared = F(1, 12 * n)
            speed_max = F(1, 2 * n)
            assert energy_over_A_a_squared <= energy_cap_over_A_a_squared
            assert F(4, T) * F(T, 8 * n) == speed_max
            assert F(10, T * T) * F(T, 8 * n) ** 2 == energy_over_A_a_squared
            # For these fixtures T>=2n and pi<4 imply R1>=a/16, so the
            # final radius is exactly a/16. Use only the elementary pi<4
            # bound to check its speed/energy, without numeric pi.
            assert T >= 2 * n
            final_radius_over_a = F(1, 16)
            actual_speed_upper = F(1, T)  # pi/(4T) < 1/T.
            actual_energy_upper = F(5, 8 * T * T)  # 5*pi^2/(128T^2).
            assert actual_speed_upper <= speed_max
            assert actual_energy_upper <= energy_over_A_a_squared
            assert 4 * final_radius_over_a == F(1, 4) < 1
            rows.append(dict(stage=stage, n=n, T=T, m=m, a='1', b=show(b),
                             exp_minus_T=show(emT),
                             exact_one_minus_exp_minus_T='1-exp(-T)',
                             weak_ratio_closed='T/(1-exp(-T))',
                             weak_ratio_numeric=show(normalized_weak_ratio),
                             occupation_D=show(log4), short_threshold_2T_over_m=str(F(2 * T, m)),
                             phase_mass_integral_closed='m*(1-exp(-T))',
                             phase_mass_integral_numeric=show(phase_mass),
                             phase_truncated_integral_closed='(m/4)*(log(4)+1)-m*exp(-T)',
                             phase_truncated_integral_numeric=show(phase_truncated),
                             phase_integral_checks=phases,
                             radius_choice='R=min(a*T/(8*pi*n),a/16)',
                             first_radius_bound_R1_times_pi_over_a=str(F(T, 8 * n)),
                             exact_final_radius_over_a=str(final_radius_over_a),
                             exact_energy_upper_envelope_over_A_a_squared=str(energy_over_A_a_squared),
                             exact_energy_cap_over_A_a_squared=str(energy_cap_over_A_a_squared),
                             actual_energy_closed_over_A_a_squared='5*pi^2/(128*T^2)',
                             exact_actual_energy_upper_using_pi_less_than_4=str(actual_energy_upper),
                             exact_coordinate_speed_upper_envelope_over_a=str(speed_max),
                             exact_coordinate_speed_cap_at_a_over_a=str(speed_max),
                             actual_coordinate_speed_closed_over_a='pi/(4*T)',
                             exact_actual_speed_upper_using_pi_less_than_4=str(actual_speed_upper),
                             exact_projection_support_width_over_a=str(4 * final_radius_over_a),
                             projection_incompatibility='support x1 width is at most a/4, whereas a nonzero positive cube convolution at scale a has x1 projection support width at least a',
                             V_choice_closed='T*b^n/(1-exp(-T))', V_numeric=show(V),
                             total_q_mass_A_numeric=show(mass),
                             global_cap_closed='A/b^n=m', global_cap_numeric=show(mass / bn),
                             source_type='abstract rotating annulus times a transverse box; not a fixed-measure cube convolution',
                             scope='tests insufficiency of summarized transport properties only; not a counterexample to the centered-cube maximal operator'))
        return rows


def compare_results(left, right, path='root'):
    """17-digit presentations must agree up to a relative 1e-15.

    Exact Fractions/labels remain byte-identical. Very tiny tails are compared
    relatively too, rather than hidden by a fixed absolute tolerance.
    """
    if isinstance(left, dict):
        assert left.keys() == right.keys(), path
        for key in left:
            compare_results(left[key], right[key], path + '.' + key)
    elif isinstance(left, list):
        assert len(left) == len(right), path
        for j, (x, y) in enumerate(zip(left, right)):
            compare_results(x, y, path + f'[{j}]')
    elif left == right:
        return
    else:
        assert isinstance(left, str) and isinstance(right, str), (path, left, right)
        with localcontext() as ctx:
            ctx.prec = 110
            x, y = D(left), D(right)
            norm = max(abs(x), abs(y))
            if norm == 0:
                assert x == y, (path, left, right)
            else:
                assert abs(x - y) <= norm * D('1e-15'), (path, left, right)


def main():
    at70 = dict(poisson=poisson_guard(70), atomic_paths=paths_guard(70),
                uniform_box=box_guard(70), lattice_band=lattice_guard(),
                abstract_rotation=rotation_guard(70))
    at110 = dict(poisson=poisson_guard(110), atomic_paths=paths_guard(110),
                 uniform_box=box_guard(110), lattice_band=lattice_guard(),
                 abstract_rotation=rotation_guard(110))
    compare_results(at70, at110)
    assert len(at110['poisson']) == 45
    assert len(at110['atomic_paths']) == 15
    assert len(at110['uniform_box']) == 3
    assert len(at110['lattice_band']) == 9
    assert len(at110['abstract_rotation']) == 3
    assert max(row['interval_count'] for row in at110['atomic_paths']) <= 5
    result = dict(status='PASS finite mean occupation guards',
                  precisions=[70, 110], precision_comparison='relative 1e-15 at 17-digit presentation, all checks passed',
                  counts=dict(poisson=45, atomic_paths=15, uniform_box=3,
                              lattice_band=9, abstract_rotation=3),
                  scope=[
                      'No random simulation, fitted growth order, or claim of a general upper-bound proof.',
                      'Poisson lower tails use the complete finite positive sum, with no truncated count tail.',
                      'Atomic path geometry, mass prefixes, jump fees and drift are exact Fractions; log integrals use Decimal.',
                      'Closed centered cubes include atoms at their entry scale; a terminal birth at b contributes a fee but zero occupation time.',
                      'Mean path has no random caps: q=m*mu(Q_L)/(lambda*L^n), t=n*log(L/a).',
                      'Three actual atomic fixtures have at most 7 sources and 5 open scale intervals; finite examples do not certify arbitrary source geometry.',
                      'Uniform-box probability bound uses expectation of below-half occupation and Markov, with stationary one-time marginals; it does not assert independence or turn an integrated log MGF into a mixed probability.',
                      'Box core/outer ratios refer to support [-R,R]^n and cubes of side at most b; lambda cancels. T must be positive in the short-occupation event.',
                      'Lattice-band guards check analytic count bounds with exact rational arithmetic and do not enumerate the finite grid.',
                      'The abstract rotating-annulus source satisfies only summarized transport properties; it is not a cube-convolution source or an operator counterexample.',
                      'Rotation denominator 1-exp(-T) rounds to 1 at these precisions; exp(-T) and exact symbolic formulas are separately preserved. Agreement does not certify that tiny correction by directed rounding.',
                      'Decimal repeats are numerical stability checks, not outward-rounded interval certificates.'
                  ], results=at110)
    destination = Path(__file__).with_name('results.json')
    destination.write_text(json.dumps(result, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
    print(json.dumps(dict(status=result['status'], **result['counts'])))


if __name__ == '__main__':
    main()
