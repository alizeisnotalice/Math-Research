"""Exact real overlap certificates and an algebraic payment test."""
from dataclasses import dataclass
from decimal import Decimal, ROUND_CEILING, ROUND_FLOOR, localcontext
from fractions import Fraction as F
from itertools import combinations, pairwise, product
from math import prod
import sys

TERMS, BITS = 28, 72


def show(lo, hi=None):
    hi = lo if hi is None else hi
    assert lo <= hi
    with localcontext() as ctx:
        ctx.prec = 15
        ctx.rounding = ROUND_FLOOR
        a = Decimal(lo.numerator)/Decimal(lo.denominator)
        ctx.rounding = ROUND_CEILING
        b = Decimal(hi.numerator)/Decimal(hi.denominator)
    return f"[{a}, {b}]"


def series(x):
    t = (x-1)/(x+1)
    assert 0 <= t <= F(1, 3)
    lo = 2*sum(t**(2*j+1)/(2*j+1) for j in range(TERMS))
    return lo, lo+2*t**(2*TERMS+1)/((2*TERMS+1)*(1-t*t))


LN2 = series(F(2))


def log_bounds(x):
    k = x.numerator.bit_length()-x.denominator.bit_length()
    k -= x < F(2)**k
    a, b = series(x/(F(2)**k))
    lo, hi = a+k*LN2[0], b+k*LN2[1]
    base = 1 << BITS
    return F(lo*base//1, base), F(-(-hi*base//1), base)


def box(center, width):
    return tuple((x-width, x+width) for x in center)


def volume(box):
    return prod(b-a for a, b in box)


def separated(a, b, distance=F(0)):
    return any(max(u-y, x-v) > distance for (x, y), (u, v) in zip(a, b, strict=True))


@dataclass(frozen=True)
class Record:
    X: tuple
    L: F
    D: int
    true_mass: F
    J: F
    mask: frozenset


def geometry(n, delta):
    w = F(1, 128*n)
    origin = box((F(0),)*n, w)
    packets = [(origin, delta)]
    provisional = []
    for signs in product((-1, 1), repeat=n):
        if signs[-1] < 0:
            radius, private = F(15, 32), F(7, 8)
            L, D, mass = 1+F(1, 8*n), 1, F(5, 4)
        else:
            radius = 1-F(1, 16*n)
            private = 2*radius
            L, D, mass = F(2), 2**n, F(5, 4)*2**n
        X = box((a*radius for a in signs), w)
        Z = box((a*private for a in signs), w)
        assert mass > delta > 0
        packets.append((Z, mass-delta))
        provisional.append((X, L, D, mass))
    assert all(separated(a, b) for (a, _), (b, _) in combinations(packets, 2))
    assert all(separated(a[0], b[0]) for a, b in combinations(provisional, 2))
    rows = []
    for i, (X, L, D, m) in enumerate(provisional, 1):
        mask = frozenset((0, i))
        for j, (source, _) in enumerate(packets):
            if j in mask:
                assert all(max(abs(y-u), abs(v-x)) < L/2
                           for (x, y), (u, v) in zip(X, source, strict=True))
            else:
                assert separated(X, source, F(1))
        assert sum(packets[j][1] for j in mask) == m > L**n
        assert 1 <= L <= 2 and D <= L**n < 2*D
        if D == 1:
            M_upper = m
        else:
            dist = 1-F(5, 64*n)
            for j in mask:
                support = packets[j][0]
                assert min(max(u-y, x-v) for (x, y), (u, v)
                           in zip(X, support, strict=True)) == dist
            M_upper = m/(2*dist)**n
            assert M_upper <= F(80, 59)
        assert M_upper <= 2
        J = volume(X)*packets[0][1]*packets[i][1]/L**(2*n)
        assert J > 0
        rows.append(Record(X, L, D, m, J, mask))
    return packets, rows


def assess(n, delta):
    packets, rows = geometry(n, delta)
    m = [r.true_mass for r in rows]
    raw = [[sum(packets[k][1] for k in a.mask & b.mask) for b in rows] for a in rows]
    assert all(raw[i][j] == (m[i] if i == j else delta)
               for i in range(len(rows)) for j in range(len(rows)))
    direction = [[K/m[i] for K in a] for i, a in enumerate(raw)]
    sym_min = [[K/max(m[i], m[j]) for j, K in enumerate(a)] for i, a in enumerate(raw)]
    sym_max = [[K/min(m[i], m[j]) for j, K in enumerate(a)] for i, a in enumerate(raw)]
    print("n", n, "rows", len(rows), "common q mass", delta, "receiver volume", volume(rows[0].X))
    print("  true m", m[:2], "volume D", [r.D for r in rows[:2]], "witness L", [r.L for r in rows[:2]])
    print("  original ordered J_X(small,large)", [r.J for r in rows[:2]],
          "smallest private fraction", 1-delta/min(m))
    print("  K matrix diagonal m_i; every non-diagonal", delta,
          "directions (small to large, large to small)", (direction[0][1], direction[1][0]))
    print("  unweighted conditional K mean for uniform rows by type", [sum(k)/len(rows) for k in raw[:2]])
    for i, r in enumerate(rows, 1):
        assert all(i == j or i not in other.mask for j, other in enumerate(rows, 1))
        assert raw[i-1][i-1]/r.true_mass == 1
    print("  each private endpoint: one original active row, K=m_i and O=1")
    minimum_J = min(r.J for r in rows)
    for name, selected in (("original nomination", [r.J for r in rows]),
                           ("equal positive subflow", [minimum_J]*len(rows))):
        assert all(0 < w <= r.J for r, w in zip(rows, selected, strict=True))
        R = sum(selected)
        law = tuple(w/R for w in selected)
        assert sum(law) == 1
        use = [[sum(p*K for p, K in zip(law, line, strict=True)) for line in mat]
               for mat in (raw, direction, sym_min, sym_max)]
        expect, O, lower, upper = use
        assert all(k/r.true_mass == o for k, r, o in zip(expect, rows, O, strict=True))
        assert all(0 <= a <= b <= c <= 1 for a, b, c in zip(lower, O, upper, strict=True))
        averages = tuple(sum(p*r for p, r in zip(law, score, strict=True)) for score in (lower, O, upper))
        assert averages[0] < averages[1] < averages[2]
        print(" ", name, "R total", R, "p for one small/large row", law[:2])
        for i in (0, 1):
            print("   D", rows[i].D, "conditional raw K", expect[i], "O/min/max", (O[i], lower[i], upper[i]))
        print("   global min, direction, max", [show(x) for x in averages])


def verify_two_anchor_redraw():
    print("Separate actual two-anchor redraw with six symmetric ordered rows.")
    positions = {"q": F(-9, 20), "z": F(9, 20), "u": F(-27, 20), "v": F(33, 20)}
    weights = {"q": F(13, 20), "z": F(13, 20), "u": F(9, 10), "v": F(29, 20)}
    packets = {mark: box((value,), F(1, 4096)) for mark, value in positions.items()}
    assert all(separated(a, b) for a, b in combinations(packets.values(), 2))
    plans = ((F(0), F(1), "q", "z"),
             (F(-4, 5), F(5, 4), "q", "u"),
             (F(17, 20), F(2), "z", "v"))
    rows = []
    masses = []
    supports = []
    cores = []
    for center, length, first, second in plans:
        X = box((center,), F(1, 256))
        cores.append(X)
        marks = frozenset((first, second))
        supports.append(marks)
        for name, bounds in packets.items():
            if name in marks:
                (x, y), (u, v) = X[0], bounds[0]
                assert max(abs(y-u), abs(v-x)) < length/2
            else:
                assert separated(X, bounds, F(1))
        m = sum(weights[name] for name in marks)
        assert 1 <= length <= 2 and m/length > 1
        masses.append(m)
        if (first, second) == ("z", "v"):
            assert separated(X, packets["v"], F(3, 4))
            # l<=3/2 sees mass at most weights[z]; l>=3/2 sees at most m.
            upper = max(weights["z"], m/F(3, 2))
        else:
            upper = m
        assert m/length <= upper <= 2
        J = volume(X)*weights[first]*weights[second]/length**2
        rows.append(J)
        print("  row (center,L,m,M_I upper,J_X per order)",
              (center, length, m, upper, J), "supports", sorted(marks))
    assert all(separated(a, b) for a, b in combinations(cores, 2))
    assert rows == [F(169, 51200), F(117, 40000), F(377, 204800)]
    # Both orders are present. On either fixed order slot the conditional
    # x-law at q (or z) is proportional to the same row's original J_X.
    ordered = {(i, a, b): rows[i] for i, (_, _, first, second) in enumerate(plans)
               for a, b in ((first, second), (second, first))}
    assert len(ordered) == 6
    laws = {}
    for anchor in ("q", "z"):
        law = {i: value for (i, a, _), value in ordered.items() if a == anchor}
        reverse = {i: value for (i, _, b), value in ordered.items() if b == anchor}
        assert len(law) == 2 and law == reverse and all(w > 0 for w in law.values())
        total = sum(law.values())
        laws[anchor] = {i: w/total for i, w in law.items()}
        assert sum(laws[anchor].values()) == 1
    print("  K_q and K_z (center indices 0,1,2):", laws["q"], laws["z"])
    raw = [[sum((weights[a] for a in S & T), F(0)) for T in supports] for S in supports]
    assert raw == [[F(13, 10), F(13, 20), F(13, 20)],
                   [F(13, 20), F(31, 20), F(0)],
                   [F(13, 20), F(0), F(21, 10)]]
    print("  exact true intersection matrix", raw)
    a, b = laws["q"], laws["z"]
    joint = {(i, j): p*q for i, p in a.items() for j, q in b.items()}
    assert len(joint) == 4 and sum(joint.values()) == 1
    assert joint[1, 2] > 0 and raw[1][2] == 0
    qz = sum(weight*raw[i][j]/masses[i] for (i, j), weight in joint.items())
    zq = sum(weight*raw[i][j]/masses[j] for (i, j), weight in joint.items())
    assert 0 < zq < qz < 1
    overlap = sum(weight*raw[i][j] for (i, j), weight in joint.items())
    private_forward = sum(weight*(masses[i]-raw[i][j]) for (i, j), weight in joint.items())
    private_reverse = sum(weight*(masses[j]-raw[i][j]) for (i, j), weight in joint.items())
    assert 0 < private_forward < private_reverse
    assert private_forward+overlap == sum(w*masses[i] for i, w in a.items())
    assert private_reverse+overlap == sum(w*masses[j] for j, w in b.items())
    print("  independent redraw weights", joint, "both genuinely redraw; private-private intersection zero")
    print("  W(q,z), W(z,q)", (qz, zq), (show(qz), show(zq)))
    print("  mean intersection", overlap, "directional mean private masses",
          (private_forward, private_reverse), (show(private_forward), show(private_reverse)))


def potential(K, r):
    if r <= K:
        return r, r
    lo, hi = log_bounds(r/K)
    return K*(1+lo), K*(1+hi)


def pay(K, levels):
    assert all(0 <= b < a for a, b in pairwise(levels))
    deltas = tuple(a-b for a, b in pairwise(levels))
    assert sum(deltas) == levels[0]-levels[-1]
    charge = sum(delta*min(F(1), K/a) for delta, a in zip(deltas, levels[:-1], strict=True))
    a, b = potential(K, levels[0]), potential(K, levels[-1])
    bound = a[0]-b[1], a[1]-b[0]
    assert charge <= bound[0]
    return charge, bound


def payments():
    K = F(1, 32)
    print("Separate algebraic deletion model, K=1/32, disjoint simultaneous deletion batches.")
    for end in (F(0), F(1, 1 << 32)):
        coarse, base_bound = pay(K, [F(1), K, end])
        assert min(F(1), K/K) == 1
        for d in (4, 16, 128):
            levels = [1-F(j, d)*(1-K) for j in range(d+1)] + [end]
            charge, bound = pay(K, levels)
            assert coarse < charge < bound[0] and bound == base_bound
            print("  terminal", end, "steps above K", d, "payment", show(charge),
                  "coarse payment", show(coarse), "potential difference", show(*bound))


def main():
    print("Replay:", sys.executable, "-B replay841.py > numbers841.txt")
    print("Python", sys.version.split()[0], "Fraction, log terms", TERMS, "endpoint bits", BITS)
    print("Actual positive-width boxes, disjoint positive receiver cores, lambda 1, entire window 1<M_I<=2.")
    print("J_X is integrated dx dmu(a)dmu(b)/L(x)^(2n); q is one physical full packet in all rows.")
    for n, delta in ((1, F(1, 4)), (2, F(1)), (4, F(1, 256)), (6, F(1, 4096))):
        assess(n, delta)
    payments()
    verify_two_anchor_redraw()
    print("Finite geometry and algebraic deletion model; no R813 historical eligibility.")
    print("PASS")


if __name__ == "__main__":
    main()
