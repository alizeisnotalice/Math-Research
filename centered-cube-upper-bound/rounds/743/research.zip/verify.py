"""Exact and interval checks for round 743. Run with python -B verify.py."""
from fractions import Fraction as Q
from itertools import product
from math import factorial
import json
import platform
import sys

import flint
from flint import arb, ctx

ctx.prec = 256


def interval_at_decimal_scale(value, digits=8):
    scale = 10 ** digits
    scaled = value * scale
    return [scaled.__floor__(), scaled.__ceil__()]


def genuine_residual():
    n, a = 64, 2048
    v = Q(3, 16) ** 4 * Q(21, 8) ** 60
    d0 = 2 ** n
    theta = 1 - Q(1, a ** 256)
    lower_d, upper_d = theta * d0, theta * d0 + v / a ** 192
    lower_m, upper_m = theta * (v - 6 * d0) - v / 32, theta * v
    fraction = n * Q(7, 16) ** 8
    old_lower = (1 - fraction) ** 2 * (lower_m - v / 8)
    assert old_lower > 8 * d0 and old_lower / v > Q(69969, 100000)
    remainder_lower = (old_lower - 8 * d0) ** 2 / old_lower
    remainder_upper = (upper_m - 8 * d0) ** 2 / upper_m
    assert remainder_lower / v > Q(68280, 100000)
    assert theta > Q(1, 4) and v / lower_d < 942 and v < 118 * 8 * lower_d
    return dict(V_T="(3/16)^4 (21/8)^60", pivot_volume="2^64",
                theta="1-2048^-256", D=["theta*2^64", "theta*2^64+V_T/2048^192"],
                R_high="theta*V_T", M=["theta*(V_T-6*2^64)-V_T/32","theta*V_T"],
                normalized_M_excess_outer=[
                    interval_at_decimal_scale((lower_m - v / 4) / (8 * upper_d))[0],
                    interval_at_decimal_scale((upper_m - v / 4) / (8 * lower_d))[1]],
                old_endpoint_fraction_upper=str(fraction),
                R741_over_V_lower=interval_at_decimal_scale(old_lower/v),
                R742_over_V_outer=[interval_at_decimal_scale(remainder_lower/v)[0],
                                   interval_at_decimal_scale(remainder_upper/v)[1]],
                observed_star_constant_upper=interval_at_decimal_scale(v/lower_d),
                decimal_scale=10**8, R743=0, R741_B="1/2", R742_B="1/2",
                receiver_radii=["1/2","3/4"], uniform_large_c_applies=False)


def projected_grid_check(n, radius):
    # Only the one-dimensional grid is materialized. All n coordinate factors are independent copies of this deterministic grid.
    a = 32*n
    count = Q(a) / radius
    assert count.denominator == 1
    m = int(count)
    offsets = tuple(-1 + Q(2*j+1, m) for j in range(m))
    centers = sorted(sign * radius + u for sign in (-1, 1) for u in offsets)
    assert len(set(centers)) == 2 * m
    assert all(y-x >= 2 * radius / a for x,y in zip(centers, centers[1:]))
    assert min(abs(y) for y in centers) > (radius+1)/a
    assert all(sum(abs(y + sign*radius) < 1 for sign in (-1,1)) == 1 for y in centers)
    # The maximum coverage of open equal intervals uses the descending endpoint before the ascending endpoint at a tie.
    changes = sorted([(y-radius, 1) for y in centers] + [(y+radius,-1) for y in centers])
    load = peak = 0
    for _, change in changes:
        load += change
        peak = max(peak,load)
    assert peak == m and load == 0
    # c=512 is fixed, above the R721 threshold for zeta=1/4. Use t>=512 to enclose the true irrational weights rationally.
    b = Q(1, a**n)
    ideal = (2/radius)**n
    factor = (1 - 1/(512*radius**n))*(1-b/1024)
    assert factor > Q(999,1000) and (1-1/(512*radius**n))*radius**n > 1
    if radius < 2:
        assert factor*ideal > 1
    elif radius > 2:
        assert ideal < 1
    return dict(n=n, radius=str(radius), offsets_per_sign=m, parent_count=f"({2*m})^{n}",
                vertex_patterns=f"2^{n}", max_pivot_depth_per_axis=peak,
                lower_t_weight_ratio_to_ideal=interval_at_decimal_scale(factor),
                exact_ideal=str(ideal), empty_T=True)


def allocation_check(n):
    # A finite test of the reverse weighted charge. There is no greedy or pairing claim for this tensor test.
    axes = tuple(product((-1,1),repeat=n))
    pivots = [(tuple(Q(v,2) for v in signs), Q(1)) for signs in axes]
    # Every pivot has weight 2^-n, with equality of their summed original weights near zero.
    weight = Q(1,len(pivots))
    sites = tuple(product((-1, 0, 1),repeat=n))
    sources = [(site,Q(1,4),Q(1,len(sites))) for site in sites]
    probes = [(tuple(Q(0) for _ in range(n)),Q(3,4),Q(1,3)),
              (tuple(Q(1,2) for _ in range(n)),Q(5,8),Q(1,7))]
    sources += probes
    reverse = [Q(0) for _ in sources]
    forward = Q(0)
    hits = 0
    for center,rad in pivots:
        local=[0 for _ in sources]
        for sgn in axes:
            z=tuple(c+rad*e/2 for c,e in zip(center,sgn))
            for k,(y,r,price) in enumerate(sources):
                if r<=rad/2 and all(abs(a-b)<r for a,b in zip(z,y)):
                    assert all(abs(a-b)<rad for a,b in zip(center,y))
                    local[k]+=1
                    hits+=1
                    forward+=weight*price
        assert max(local)<=1
        for k,count in enumerate(local):
            reverse[k]+=weight*count
    assert 0 < forward and hits == len(pivots)*len(axes)
    assert max(reverse)==1 and forward==sum(y[2]*val for y,val in zip(sources,reverse))
    return dict(n=n, pivots=len(pivots), possible_cells=len(pivots)*len(axes),
                exact_hits=hits, forward_charge=str(forward),
                largest_reverse_charge=str(max(reverse)))


def continuous_cap_check(n, rho, thin_height=False):
    h = arb(1) + 1/arb(32*n)
    height = (-arb(n).sqrt()).exp() if thin_height else arb(1)/4
    t = arb(512)*arb(n).sqrt()
    height_cost = (2*h**n/(height*t)).log()
    assert height_cost > 0 or height_cost < 0
    radius = arb(n+1).log() + (height_cost if height_cost > 0 else 0)
    width = arb(rho)*arb(n).sqrt()+2*h*radius
    log_bound = (2/height).log()+n*width.log()-arb(factorial(n)).log()
    log_threshold = -8*arb(n).sqrt()
    if n >= 1024 and not thin_height:
        assert log_bound < log_threshold
    if n >= 4096 and thin_height:
        assert log_bound < log_threshold
    return dict(n=n, rho=rho, zeta="exp(-sqrt(n))" if thin_height else "1/4",
                log_upper=str(log_bound), log_test_threshold=str(log_threshold),
                upper_below_threshold=bool(log_bound<log_threshold))


if __name__=="__main__":
    out=dict(python=sys.executable,python_version=platform.python_version(),flint=flint.__version__,
             arb_bits=ctx.prec, launch="python -B verify.py", true_two_scale=genuine_residual(),
             true_vertex_grids=[projected_grid_check(n,r) for n in (6,24,96,384)
                                for r in (Q(3,2),Q(2),Q(3))],
             atomic_allocations=[allocation_check(n) for n in (2,3,4,5)],
             continuous_bound=[continuous_cap_check(n,rho,thin) for n in (64,256,1024,4096)
                               for rho in (0,1) for thin in (False,True)])
    print(json.dumps(out,indent=2))
