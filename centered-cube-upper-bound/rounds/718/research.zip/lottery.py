"""Exhaustive integer-rate clock race, weighted pair and threshold-cut check."""
from fractions import Fraction as F
from itertools import permutations, combinations, product
from math import prod
from random import Random
from hashlib import sha256
import json

rng=Random(718)
answers=[]
for n in (2,3,4,5,6):
    sites=list(range(n))
    for _ in range(12):
        rate=[rng.randrange(1,6) for s in sites]
        price=[F(rng.randrange(5),4) for s in sites]
        W={i for i in sites if rng.randrange(2)} or {0}
        V=W|{s for s in sites if rng.randrange(2)}
        U=W|{s for s in sites if rng.randrange(2)}
        observed=F()
        for perm in permutations(sites):
            first=next(s for s in perm if s in U|V)
            if first in W:
                rem=sum(rate)
                prob=F(1)
                for s in perm:
                    prob*=F(rate[s],rem)
                    rem-=rate[s]
                observed+=prob*price[first]
        predicted=sum((price[s]*rate[s] for s in W),F())/sum(rate[s] for s in U|V)
        assert observed==predicted
        for S in (U,V,W,U|V):
            # Every source simultaneously sees the max of its incident site prices.
            layers=sorted(set(price+[F(0),F(1)]))
            assert sum((b-a for a,b in zip(layers,layers[1:]) if any(price[s]>=b for s in S)),F())==max(price[s] for s in S)
        answers.append(str(predicted))
# Direct folding on a two-dimensional grid, not just the categorical race.
sites2=[(-4,-3),(1,2),(5,4),(3,-2)]
offsets=list(product((-4,0,4),repeat=2)) # s=6,r=2
inside=lambda x,w,r:max(abs(x[i]-w[i]) for i in range(2))<=r
num=0
for base in product(range(-4,5,2),repeat=2):
    p=tuple(F(t)+F(1,3) for t in base)
    W={i for i,w in enumerate(sites2) if inside(p,w,2)}
    U=[{i for i,w in enumerate(sites2) if inside(tuple(p[a]+g[a] for a in range(2)),w,6)} for g in offsets]
    for j,k in combinations(range(len(offsets)),2):
        if not U[j] or not U[k]:
            continue
        expected=F(len(W),len(U[j]|U[k]))
        observed=0
        for order in permutations(range(4)):
            hit=True
            for ix in (j,k):
                w=sites2[next(i for i in order if i in U[ix])]
                x=tuple(p[a]+offsets[ix][a] for a in range(2))
                disp=tuple(next(g for g in (-4,0,4) if abs(x[a]-w[a]-g)<2) for a in range(2))
                hit &= tuple(x[a]-disp[a] for a in range(2))==p
            observed+=hit
        assert F(observed,24)==expected
        num+=1
cap=(F(2,5),F(2,5),F(1,5))
def gap(lam):
    return max(F(0),lam-cap[0]-cap[2],1-lam-cap[1]-cap[2],1-sum(cap))
assert gap(F(0))==gap(F(1))==F(2,5) and gap(F(1,2))==0
print(json.dumps(dict(cases=len(answers),actual_pair_tests=num,pair_digest=sha256(str(answers).encode()).hexdigest(),pure_gap="2/5",mixed_gap="0")))
