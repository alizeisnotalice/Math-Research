"""R718 common-ranked simultaneous coordinate folding and real prefix fibers.

Finite point grids use exact integer representations of rational coordinates.
Real-history continuous fibers use Arb256/384; MacBook independently checks
all finite grids and the real prefix formulas without importing flint.
"""
from pathlib import Path
from itertools import product
from collections import Counter,defaultdict
import hashlib,json,platform,socket,subprocess,sys


def point_tests():
    rows=[]
    for n,D in [(2,8),(3,6),(4,4)]:
        m=2*n
        # Physical sites and points have common rational denominator D.
        sites=[(0,)*n]+list(product([-D//2,D//2],repeat=n))+[(0,)*n]
        for pattern in ['all_repeated_ranks','reverse_with_ties','adversarial_alternation']:
            ranks=([0]*len(sites) if pattern=='all_repeated_ranks' else
                   [(len(sites)-1-i)//2 for i in range(len(sites))] if pattern=='reverse_with_ties' else
                   [(i*7+i//3)%4 for i in range(len(sites))])
            order=sorted(range(len(sites)),key=lambda i:(ranks[i],i))
            destination_owner={};fiber=Counter();per_site=defaultdict(int);digest=hashlib.sha256()
            collisions=0;assigned=0
            for x in product(range(-3*D//2,3*D//2+1),repeat=n):
                owner=next(i for i in order if all(abs(u-v)<=D for u,v in zip(x,sites[i])))
                w=sites[owner];p=[]
                for u,v in zip(x,w):
                    j=min(m-1,(m*(u-v+D))//(2*D))
                    assert 0<=j<m
                    # p_a = u/D -(2j+1-m)/m, denominator mD.
                    p.append(m*u-D*(2*j+1-m))
                p=tuple(p)
                assert all(abs(y-m*v)<=D for y,v in zip(p,w))
                if p in destination_owner and destination_owner[p]!=owner:collisions+=1
                destination_owner[p]=owner;fiber[(owner,p)]+=1;assigned+=1
                digest.update(repr((x,owner,p)).encode())
            for (owner,p),count in fiber.items():per_site[owner]=max(per_site[owner],count)
            high_mass=sum(count for count in fiber.values() if count>n*n)
            assert collisions==0
            assert max(fiber.values())>n*n
            rows.append({'dimension':n,'s_exact':'1','m':m,'point_denominator':D,
                         'rank_pattern':pattern,'rank_tie_rule':'global input index',
                         'site_count_with_duplicates':len(sites),'distinct_physical_sites':len(set(sites)),
                         'point_count':assigned,'different_site_collision_count':collisions,
                         'distinct_destinations':len(destination_owner),'max_within_site_fiber':max(fiber.values()),
                         'low_fiber_threshold':n*n,'input_points_in_high_fibers':high_mass,
                         'per_selected_site_max_fiber':{str(k):v for k,v in per_site.items()},'assignment_sha256':digest.hexdigest()})
    return rows


def remote_real_checks():
    from decimal import Decimal as D,localcontext
    rows=[]
    with localcontext() as c:
        c.prec=110
        for b in [32,48,64]:
            n=1<<b;a=32*n;h=1+D(1)/a;s=h*(D(2).ln()/n).exp()
            f,rem=divmod((b//4)*n,b+3)
            for factor in [1,2]:
                m=factor*n;qf=D(m)/(4*s);qp=D((1<<rem)*m)/(a*s)
                lf=int(qf);uf=lf+1;lp=max(1,int(qp));up=max(1,int(qp)+1)
                minimum=D(f)*D(lf).ln()+D(lp).ln()
                maximum=D(f)*D(uf).ln()+D(up).ln()
                image_ratio=D(f)*(4*s/m).ln()+min(D(0),(2*s/m).ln()-D(rem-b-4)*D(2).ln())
                capped=2*D(b)*D(2).ln()+image_ratio
                rows.append({'b':b,'factor':factor,'free_axes':str(f),'remainder':rem,
                             'floor_full_axis':str(lf),'ceil_full_axis':str(uf),
                             'values':[str(minimum),str(maximum),str(capped)]})
    return rows


if '--remote-grid' in sys.argv:
    print(json.dumps({'host':socket.gethostname(),'python':sys.version,
                      'exact_point_grids':point_tests(),'real_prefix_decimal110':remote_real_checks()}))
    raise SystemExit(0)


from flint import arb,ctx
BASE=Path(__file__).resolve().parent


def st(x):return x.str(38)


def floor_unique(x):
    value=x.floor().unique_fmpz();assert value is not None
    return int(value)


def real_prefix(b,factor,bits):
    ctx.prec=bits;A=arb;n=1<<b;a=32*n;m=factor*n;l2=A(2).log();L=b*l2
    h=1+A(1)/a;s=h*(l2/n).exp();r=s/m;tau=2*r
    f,rem=divmod((b//4)*n,b+3)
    assert 0<=rem<b+3 and f<n-1
    fixed=n-f-1
    tiny=A(2)/a;partial=(1<<rem)*tiny
    assert tiny<tau and A('.5')>tau and 2*r<s-A('.75')
    assert s>A('.75')
    qf=A(m)/(4*s);qp=partial/tau
    lf=floor_unique(qf);uf=-floor_unique(-qf)
    lp=max(1,floor_unique(qp));up=max(1,-floor_unique(-qp))
    assert lf>1 and uf>=lf and up>=lp
    logmin=f*A(lf).log()+A(lp).log()
    logmax=f*A(uf).log()+A(up).log()
    assert logmin>2*L
    # The prefix is exactly a product rectangle because all grid side counts
    # and N' are powers of two, not an assumption about an arbitrary prefix.
    exact_volume_exponent=-(b+4)*fixed+(rem-b-4)-f
    expected_exponent=-(3*b//4+4)*n
    assert exact_volume_exponent==expected_exponent
    logVR=expected_exponent*l2
    logimage=fixed*tiny.log()+min(partial,tau).log()+f*tau.log()
    image_ratio=logimage-logVR
    logcap=2*L+image_ratio
    assert logcap<0
    # Direct ratio expression avoids cancellation and independently checks it.
    ratio_alt=f*(2*tau).log()+min(A(0),(tau/partial).log())
    assert (image_ratio-ratio_alt).contains(0)
    # s contains2^(1/n), so no false exact alignment with rational tiny cores.
    return {'b':b,'n':f'2^{b}','m_exact':f'{factor}*n','factor':factor,'s':st(s),'r':st(r),
            'fold_period':st(tau),'full_free_axis_count':str(f),'partial_axis_grid_exponent':rem,
            'fixed_tiny_axis_count':str(fixed),'free_axis_fraction':st(A(f)/n),
            'partial_axis_core_count_exact':str(1<<rem),'partial_axis_side_length':st(partial),
            'tiny_core_side_length':st(tiny),'VR_exact':f'2^{expected_exponent}',
            'full_axis_floor_preimages':str(lf),'full_axis_ceil_preimages':str(uf),
            'partial_axis_essential_min_preimages':str(lp),'partial_axis_essential_max_preimages':str(up),
            'log10_continuous_essential_min_fiber':st(logmin/A(10).log()),
            'log10_continuous_essential_max_fiber':st(logmax/A(10).log()),
            'log10_low_fiber_threshold_n_squared':st(2*L/A(10).log()),
            'all_positive_measure_image_fibers_exceed_n_squared':True,
            'strict_low_fiber_kept_old_block_fraction':'0 (up to null faces)',
            'log10_optimal_density_capped_kept_old_block_fraction':st(logcap/A(10).log()),
            'folded_image_volume':st(logimage.exp()),
            'period_to_tiny_core_side_ratio':st(tau/tiny),
            'exact_period_alignment_assumed':False,
            'A_chosen_for_every_retained_point':True,'rank_tie_rule':'A first among all earliest legitimate A half-threshold representatives',
            'precision_bits':bits,'_values':(logmin,logmax,logcap),
            '_remote_values':[float(logmin),float(logmax),float(logcap)]}


def main():
    grids=point_tests();real=[]
    for b in [32,48,64]:
        for factor in [1,2]:
            low=real_prefix(b,factor,256);high=real_prefix(b,factor,384)
            assert low['full_axis_floor_preimages']==high['full_axis_floor_preimages']
            for x,y in zip(low['_values'],high['_values']):assert x.overlaps(y)
            del high['_values'];real.append(high)
    command=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=5','macbook-math',
             '/Users/zhengzhihao/.venv/bin/python -B - --remote-grid']
    run=subprocess.run(command,input=Path(__file__).read_text(),text=True,capture_output=True,timeout=50)
    remote={'command':command,'exit_code':run.returncode,'stderr':run.stderr}
    if run.returncode==0:
        remote['result']=json.loads(run.stdout)
        assert grids==remote['result']['exact_point_grids']
        for local,other in zip(real,remote['result']['real_prefix_decimal110']):
            assert local['b']==other['b'] and local['factor']==other['factor']
            assert local['full_axis_floor_preimages']==other['floor_full_axis']
            for x,y in zip(local['_remote_values'],other['values']):assert abs(x-float(y))<=max(1e-12,abs(x)*1e-12)
        remote['crosscheck_passed']=True
    else:remote['stdout']=run.stdout
    for row in real:del row['_remote_values']
    prior=json.loads((BASE/'ranked_history.json').read_text())
    history_rows=[{k:r[k] for k in ['b','K','VR','V','D','original_A_high_weight_lower_every_receiver_point',
                                   'original_R_high_integral_lower','original_R_high_integral_upper']} for r in prior['rows']]
    result={'host':socket.gethostname(),'python':sys.executable,'python_version':platform.python_version(),
            'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'prior_history_sha256':hashlib.sha256((BASE/'ranked_history.json').read_bytes()).hexdigest(),
            'exact_grid_rows':grids,'real_prefix_rows':real,'prior_true_history_rows':history_rows,'remote':remote,
            'exact_map':['Fix one receiving volume bin, common s and common integer m. Sort the finite physical half-threshold sites by one global rank, with a fixed global tie rule.',
                         'Choose the earliest eligible site w with ||x-w||_infty<=s. Each coordinate of g is the midpoint of the grid interval of[-s,s] containing x_a-w_a; all coordinates move simultaneously to p=x-g.',
                         'Use half-open intervals and put the rightmost endpoint in the last interval. This only changes null faces for real volume. The finite grids implement this convention exactly with integer numerators.',
                         'If p is shared by different selected sites w earlier than v, then ||p-w||<=r. The later point x_prime=p+g_prime has ||g_prime||<=s-r, hence ||x_prime-w||<=s: it was eligible for the earlier site, a contradiction. Distinct selected sites cannot collide.'],
            'true_prefix_proof':['The true R717 prefix has N_prime=2^(bn/4) labels, and the nonfirst grid axes each have2^(b+3) tiny cores. Writing bn/4=f(b+3)+rem shows exactly f full free trailing axes, one partial axis with2^rem cores, and n-f-1 fixed tiny axes.',
                                 'The first axis remains fixed because f<n-1. The actual retained owner union is consequently the corresponding product rectangle; its volume matches the original exact VR.',
                                 'The original A site is a genuine first-half positive-cell representative. Put A first in the tie among earliest-stage representatives; all retained points satisfy ||x-A||<=3/4<s=h*2^(1/n), so every point chooses A.',
                                 'Within one site the map is periodic with period tau=2s/m in each coordinate. A full side1/2 has floor(m/(4s)) or ceil(m/(4s)) preimages. Tiny fixed sides are shorter than tau; partial-side counts are bounded exactly as stated.',
                                 'All coordinates separate, so essential min/max fibers are products. The fixed-site image volume is tiny^(n-f-1)*min(partial,tau)*tau^f. No rational-grid alignment of the irrational period is assumed.',
                                 'Every positive-measure image fiber exceeds n^2. A rule retaining only original fibers of size<=n^2 pays none of the block. If arbitrary thinning to density n^2 is allowed, the exact maximum retained block fraction is n^2*image_volume/VR, still exponentially small.'],
            'scope':['The nine adversarial/repeated-rank finite-grid cases are physical rational point sets testing the folding map, not independent greedy histories.',
                     'The six continuous fiber cases refer to the actual R717 truncated two-center input for each b and both m=n,2n; the same geometry applies to all K4,8,16, whose true budgets and original high bounds are included from the recorded certified history.',
                     'No cross-site collision does not imply a bounded total pushforward density: this genuine block has enormous same-site fibers.',
                     'The old R717 uniform halo allocation can still pay this block; failure of this deterministic low-fiber rule does not refute the larger spatial allocation channel.',
                     'Arb256/384 and remote exact-grid/Decimal110 checks pass. Only this script, ranked.json and the local prior data copy ranked_history.json are written; no Git or remote files.']}
    output=BASE/'ranked.json';output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'output':str(output),'remote_exit':run.returncode,'remote_crosscheck':remote.get('crosscheck_passed',False),
                      'grid_summary':[{k:r[k] for k in ['dimension','rank_pattern','point_count','different_site_collision_count','max_within_site_fiber']} for r in grids],
                      'real_summary':[{k:r[k] for k in ['b','factor','full_free_axis_count','log10_continuous_essential_min_fiber','log10_optimal_density_capped_kept_old_block_fraction']} for r in real]},indent=2))


if __name__=='__main__':main()
