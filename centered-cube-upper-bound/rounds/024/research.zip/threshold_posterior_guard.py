"""Real receiver, continuous-window numerical guards; not a weak-bound proof."""
from fractions import Fraction as F
from decimal import Decimal as D, localcontext
from math import exp, log, factorial, comb, ceil
from pathlib import Path
import json


def radial():
 rows=[]
 for n in [1,2,8,32,128,1024]:
  B=F(2)**n
  for u in [F(1,2**40),F(1),F(2)**(n-1),F(2)**(n+1)]:
   # u=W/lambda, a=1,b=2. Integrate in s=(2||x||inf)^n.
   value=u*(2-1/B) if u<=1 else 2-u/B if u<B else B/u
   assert 0<value<=2
   rows.append(dict(n=n,u=str(u),normalized_floor_square=str(value)))
 return rows


def plateau(precision):
 out=[]
 with localcontext() as ctx:
  ctx.prec=precision
  for k in [1,4,16,64,256,1024]:
   p=(-D(k)).exp(); cdf=p
   for j in range(1,k+1):p*=D(k)/j;cdf+=p
   prob=1-cdf; lower=F(k,12*k+4)
   assert prob>D(lower.numerator)/D(lower.denominator)
   out.append(dict(kappa=k,positive_count_probability=format(prob,'.17g'),moment_lower=str(lower)))
 for n in [1,2,8,32,128,1024]:
  core=(1-F(1,16*n))**n
  assert core>=F(15,16)
 return out


def tail(k,j):
 assert j>k
 return exp(-k)*k**j/factorial(j)/(1-k/(j+1))


def kernel(x,y):
 r=2*abs(x-y)
 return 0.0 if r>2 else 1/max(1.0,r)


def phi(t):
 return t*log(t)-t+1 if t else 1.0


def posterior(k,d,K):
 # Two close atoms in one updated cell, one unchanged far cell.
 # Actual full-space envelope K for [1,2], with all jump/kink points split.
 y=[-d/4,d/4,1.25]; w=[.375,.125,.5]; Z=1+log(2); J=6*k+32
 cuts=sorted(set(v+s for v in y for s in [-1,-.5,.5,1]))
 length=cuts[-1]-cuts[0]; nodes=[]
 for a,b in zip(cuts,cuts[1:]):
  count=max(1,ceil(K*(b-a)/length))
  for j in range(count):
   x=a+(b-a)*(j+.5)/count
   kval=[kernel(x,v) for v in y]; g=sum(u*v for u,v in zip(w,kval))
   if g:nodes.append((kval,g,(b-a)/count/Z))
 totalJ=hist=cond=0.0; maxidentity=0.0; pn=exp(-k); states=0
 for N in range(J+1):
  if N:pn*=k/N
  mass=(1+N/k)/2
  for i in range(N+1):
   p=pn*comb(N,i)*(.75**i)*(.25**(N-i)); states+=1
   v=[.5*i/k,.5*(N-i)/k,.5]
   jj=cc=0.0
   for kval,g,dx in nodes:
    gn=sum(u*z for u,z in zip(v,kval)); ratio=gn/g
    jj+=g*phi(ratio)*dx
    # A nonnegative generalized KL integrand for normalized posteriors.
    cc+=mass*g*phi(ratio/mass)*dx
   hh=phi(mass)
   # The identity uses exact kernel mass Z; numerical integrals approximate it.
   maxidentity=max(maxidentity,abs(jj-hh-cc))
   totalJ+=p*jj;hist+=p*hh;cond+=p*cc
 # G>=1/16 wherever positive; |G'|<=2; Gn>=1/(4k) or zero.
 # Pointwise derivative of generalized KL integrand bounded after expectation.
 maxmass=(1+J/k)/2
 Llog=max(log(4*k),log(16*maxmass))
 lip=2*Llog+34
 # Each interval width mesh <= length/K; normalized midpoint error.
 first_error=lip*length*length/(4*K*Z)
 # On each split interval |Gprime/G|,|Gnprime/Gn|<=2 and
 # |Gsecond|<=8G, |Gnsecond|<=8Gn. Thus expected |Fsecond|<=8Llog+32.
 second_error=(8*Llog+32)*length**3/(24*K*K*Z)
 error=min(first_error,second_error)
 # phi(ratio)<= (ratio-1)^2 <= ratio^2+1; ratio<=16*mass.
 # For N>J, E mass^2 tail <= .5*(P_{J+1}+P_{J-1}+P_J/k).
 tailenergy=128*(tail(k,J+1)+tail(k,J-1)+tail(k,J)/k)+tail(k,J+1)
 c=2-2*d; c0=exp(2*d); edge=2*(2+2*d)/(c*c); Zc=1+log(c)
 bound=(c0*Zc+edge)/Z*.5/k
 assert totalJ<=bound+error+1e-10
 assert totalJ>=-1e-10 and cond>=-1e-10 and hist>=-1e-10
 # Integrated posterior chain identity; loose analytic spatial envelope.
 assert abs(totalJ-hist-cond)<=3*error+1e-10
 return dict(kappa=k,delta=d,target_midpoints=K,actual_midpoints=len(nodes),count_states=states,
  truncated_joint_Bregman=totalJ,truncated_history_Bregman=hist,truncated_posterior_KL=cond,
  chain_residual=totalJ-hist-cond,one_step_bound=bound,joint_midpoint_error_bound=error,
  omitted_joint_Bregman_bound=tailenergy,max_per_history_chain_residual=maxidentity,
  first_derivative_midpoint_bound=first_error,second_derivative_midpoint_bound=second_error)


def main():
 p70=plateau(70);p110=plateau(110);assert p70==p110
 rows=[posterior(k,d,K) for k in [1,4] for d in [1/32,1/128] for K in [128,512,2048]]
 for i in range(0,len(rows),3):
  for a,b in zip(rows[i:i+3],rows[i+1:i+3]):
   assert abs(a['truncated_joint_Bregman']-b['truncated_joint_Bregman'])<=a['joint_midpoint_error_bound']+b['joint_midpoint_error_bound']+1e-10
 out=dict(status='PASS finite guards',radial=radial(),plateau=p70,posterior=rows,
  scope='Exact radial integrals and L1 plateau core checks; real 1D full-space envelope posterior integrals. No high-weak-ratio, dimensional-order, or interval certification.')
 Path(__file__).with_name('results.json').write_text(json.dumps(out,indent=2)+'\n')
 print(json.dumps(dict(status=out['status'],radial=len(out['radial']),plateau=len(p70),posterior=len(rows))))

if __name__=='__main__':main()
