from fractions import Fraction as Q
from itertools import product
from pathlib import Path
import numpy as np
from scipy.optimize import linprog
import scipy,json,sys,platform
import sympy as sp
# Exact finite geometric LP, NOT a discretization certificate for Lebesgue receiving centers.
def run(k,caps,theta,layers):
 step=Q(1,2); w=step**2
 centers=[(step*(i-(k-1)//2),step*(j-(k-1)//2)) for i,j in product(range(k),repeat=2)]
 radii=[Q(1+(i+j)%2) if layers==2 else 1+Q((i+j)%layers,2) for i,j in product(range(k),repeat=2)];N=len(radii)
 roots=[(tuple(c-h/2 for c in B),tuple(c+h/2 for c in B)) for B,h in zip(centers,radii)]
 outer=[(tuple(c-t*h/2 for c in B),tuple(c+t*h/2 for c in B),(t*h)**2) for B,h in zip(centers,radii) for t in caps]
 boxes=roots+[(l,h) for l,h,v in outer]
 axes=[sorted(set(v[j] for box in boxes for v in box)) for j in range(2)]
 # Retain only arrangement cells in union of root cubes; outside contributes zero objective.
 patterns={}
 for ix,iy in product(range(len(axes[0])-1),range(len(axes[1])-1)):
  x=(axes[0][ix]+axes[0][ix+1])/2;y=(axes[1][iy]+axes[1][iy+1])/2
  bits=tuple(l[0]<x<h[0] and l[1]<y<h[1] for l,h in boxes)
  if not any(bits[:N]):continue
  if bits not in patterns:patterns[bits]=[x,y]
 pats=list(patterns);P=len(pats);a=[w/(r*r) for r in radii]
 pairs=[];background=Q(0)
 for i in range(N):
  for j in range(i+1,N):
   if radii[i]==radii[j]:continue
   H=Q(1)
   for d in range(2):H*=max(Q(0),min(roots[i][1][d],roots[j][1][d])-max(roots[i][0][d],roots[j][0][d]))
   vmin=min(radii[i]**2,radii[j]**2)
   if 2*H*H <vmin*vmin:
    pairs.append((i,j));background+=2*a[i]*a[j]*H
 objectives=[]
 for bits in pats:
  D=sum((a[i] for i in range(N) if bits[i]),Q(0))
  F=sum((2*a[i]*a[j] for i,j in pairs if bits[i] and bits[j]),Q(0))
  objectives.append(F-theta*D*D)
 mat=np.array(pats,dtype=float).T
 eqrhs=[r*r for r in radii];ubrhs=[v for l,h,v in outer]
 result=linprog(-np.array(list(map(float,objectives))),A_eq=mat[:N],b_eq=np.array(list(map(float,eqrhs))),A_ub=mat[N:] if outer else None,b_ub=np.array(list(map(float,ubrhs))) if outer else None,bounds=(0,None),method='highs')
 assert result.success,result.message
 # Negating minimization dual: free root prices u, nonnegative upper-cap prices v.
 u=[Q(float(-v)).limit_denominator(10**7) for v in result.eqlin.marginals]
 v=[max(Q(0),Q(float(-z)).limit_denominator(10**7)) for z in result.ineqlin.marginals] if outer else []
 slack=[sum((c for c,on in zip(u+v,bits) if on),Q(0))-g for bits,g in zip(pats,objectives)]
 repair=max(Q(0),-min(slack))
 # Each retained pattern belongs to >=1 root. Adding repair to every root repairs all constraints.
 u=[z+repair for z in u]
 slack=[sum((c for c,on in zip(u+v,bits) if on),Q(0))-g for bits,g in zip(pats,objectives)]
 assert min(slack)>=0 and all(z>=0 for z in v)
 dual=sum((c*t for c,t in zip(u,eqrhs)),Q(0))+sum((c*t for c,t in zip(v,ubrhs)),Q(0))
 X=w*N;K=(dual-background)/X
 # Only floating primal witness/residual. The dual upper bound above is rationally certified.
 eqerr=float(np.max(np.abs(mat[:N]@result.x-np.array(list(map(float,eqrhs))))))
 caperr=float(np.max(mat[N:]@result.x-np.array(list(map(float,ubrhs))))) if outer else None
 primal=[Q(float(z)).limit_denominator(10**7) for z in result.x]
 primal_eq=[sum((z for z,bits in zip(primal,pats) if bits[i]),Q(0)) for i in range(N)]
 primal_ub=[sum((z for z,bits in zip(primal,pats) if bits[N+i]),Q(0)) for i in range(len(outer))]
 primal_feasible=all(z>=0 for z in primal) and primal_eq==eqrhs and all(z<=rhs for z,rhs in zip(primal_ub,ubrhs))
 reconstruction='direct rationalization'
 if not primal_feasible:
  support=[i for i,z in enumerate(result.x) if z>1e-8]
  active=list(range(N))+[N+i for i,z in enumerate(result.ineqlin.residual) if abs(z)<1e-7]
  MM=sp.Matrix([[int(pats[j][i]) for j in support] for i in active]);allrhs=eqrhs+ubrhs
  bb=sp.Matrix([sp.Rational(allrhs[i].numerator,allrhs[i].denominator) for i in active])
  sol,params=MM.gauss_jordan_solve(bb)
  assert len(params)==0
  primal=[Q(0)]*P
  for j,z in zip(support,sol):primal[j]=Q(int(sp.numer(z)),int(sp.denom(z)))
  primal_eq=[sum((z for z,bits in zip(primal,pats) if bits[i]),Q(0)) for i in range(N)]
  primal_ub=[sum((z for z,bits in zip(primal,pats) if bits[N+i]),Q(0)) for i in range(len(outer))]
  primal_feasible=all(z>=0 for z in primal) and primal_eq==eqrhs and all(z<=rhs for z,rhs in zip(primal_ub,ubrhs))
  reconstruction='exact active-support linear solve'
 primal_exact=sum((g*z for g,z in zip(objectives,primal)),Q(0)) if primal_feasible else None
 exactgap=dual-primal_exact if primal_feasible else None
 dual_reconstruction='rationalized dual plus exact slack repair'
 if primal_feasible and exactgap>0:
  dual_raw=list(-result.eqlin.marginals)+(list(-result.ineqlin.marginals) if outer else [])
  support_dual=[i for i,z in enumerate(dual_raw) if abs(z)>1e-10]
  tight=[j for j,z in enumerate(primal) if z>0]
  MM=sp.Matrix([[int(pats[j][i]) for i in support_dual] for j in tight])
  bb=sp.Matrix([sp.Rational(objectives[j].numerator,objectives[j].denominator) for j in tight])
  try:
   sol,params=MM.gauss_jordan_solve(bb)
   if len(params)==0:
    alt=[Q(0)]*len(dual_raw)
    for i,z in zip(support_dual,sol):alt[i]=Q(int(sp.numer(z)),int(sp.denom(z)))
    alt_slack=[sum((c for c,on in zip(alt,bits) if on),Q(0))-g for bits,g in zip(pats,objectives)]
    if min(alt_slack)>=0 and all(z>=0 for z in alt[N:]):
     u=alt[:N];v=alt[N:];slack=alt_slack;repair=Q(0)
     dual=sum((c*t for c,t in zip(alt,eqrhs+ubrhs)),Q(0));K=(dual-background)/X;exactgap=dual-primal_exact
     dual_reconstruction='exact complementary-support linear solve'
  except ValueError:pass
 assert exactgap is None or exactgap>=0
 gap=float(dual)+float(result.fun)
 return {'dual_reconstruction':dual_reconstruction,'layers':layers,'primal_reconstruction':reconstruction,'exact_primal_feasible':primal_feasible,'exact_primal_objective':str(primal_exact),'exact_duality_gap':str(exactgap),'nonzero_primal_masses':[[i,str(z)] for i,z in enumerate(primal) if z],'grid':k,'parents':N,'caps':list(map(str,caps)),'patterns':P,'core_unordered_pairs':len(pairs),'theta':str(theta),'X':str(X),'background':str(background),'float_primal_objective':float(-result.fun),'float_eq_max_residual':eqerr,'float_cap_max_excess':caperr,'rational_dual_objective':str(dual),'dual_minus_float_primal':gap,'certified_K_upper':str(K),'K_float':float(K),'repair_per_root':str(repair),'min_exact_slack':str(min(slack)),'root_prices':list(map(str,u)),'cap_prices':list(map(str,v)),'positive_cap_prices':sum(z>0 for z in v),'centers':[[str(x) for x in c] for c in centers],'radii':list(map(str,radii)),'center_weight':str(w)}
results=[]
for layers in [2,3,5]:
 for theta in [Q(0),Q(1,2)]:
  for k in [3,5,7]:
   for caps in [[],[Q(5,4),Q(3,2),Q(2)]]:
    r=run(k,caps,theta,layers);results.append(r);print(layers,theta,k,len(caps),r['patterns'],r['K_float'],'cap-active',r['positive_cap_prices'],'exactgap',r['exact_duality_gap'],flush=True)
out={'scope':'Finite rational cube-arrangement source LP; finite weighted center atoms, NOT actual Lebesgue center theorem. Dual bounds exact for this finite model only; Primal reconstruction is checked exactly; consult exact_duality_gap per instance. Two, three or five radius levels; all unequal ratios lie in [6/5,3] and satisfy R531 n=2 middle-ratio condition. Core overlap selected by exact 2 H²<Vmin².','environment':{'python':platform.python_version(),'executable':sys.executable,'numpy':np.__version__,'scipy':scipy.__version__,'sympy':sp.__version__,'solver':'HiGHS via scipy.optimize.linprog'},'results':results}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2))
