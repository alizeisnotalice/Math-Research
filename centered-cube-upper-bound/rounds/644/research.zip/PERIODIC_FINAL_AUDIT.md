# R644 final periodic / rational transplant audit

PASS for the requested REPORT §§4–6 and repro/NUMERICS.md, bound to:

REPORT.tex SHA256: `56c908d6d584a5d10ccbd83fce318405e9a0cb3104eb52458a88d2ba9b9ff024`.

This is a limited consistency check against the already completed independent periodic and rational audits. No LP, search, 50-policy batch, dense certificate or barrier certificate was rerun. I used local Python only for exact saved-data comparisons, hashes and receipt arithmetic. No report or reproduction file was edited.

## PASS: periodic-to-finite theorem

The final text retains all essential hypotheses: fixed dimension and periodic data; full actual packing (with the a.e. convention fixed in §1); positive lambda_min and bounded radii; every actual label's normal moment; nonnegative AC periodic source; and source-a.e. saturation. Aggregate orbit equations alone are explicitly excluded.

The final proof correctly transplants the actual Voronoi-plus-exterior partition, positive v_j=h^n+u_j, and feasible restricted trial vector. The source-boundary estimate counts integer period cells, without assuming a density cap. The exact Gamma identity includes the entire epsilon sum u_j(1/lambda_j-1) surcharge; tau is correctly called a gradient cover rather than the actual finite KKT source.

The strong-concavity modulus epsilon h^n, distance estimate 2Gamma/(epsilon h^n), Qactual error exponent n-1/2 and constant

C_Q=dmax h^(-n) sqrt(2C_Gamma/epsilon)

are unchanged and correct. The threshold T>=(2C_Q/Qper)^2 and both terms of the explicit ratio error agree with the audited proof. The theorem controls the actual finite optimizer's linear part, not the logarithmic objective value.

The statement correctly requires a positive margin to both critical endpoints. Constants may depend on fixed periodic data. It neither proves near-supremum status nor transfers per-label relative control, the actual finite source, canonical radii or new actions. These limitations remain explicit.

## PASS: exact samples and numerical scope

The n=2 matrix, Qper=1, epsilon=64/4225 and Mper=4289/4225 are unchanged. The claims of 64 actual source cells, 64 actual row counts/moments and a nonconstant probe match the independent executed dense audit. The n=1 matrix, positive beta0 branch and Qepsilon=(163+sqrt(1093))/264 match the exact certificate. Independent actual-label integer-source counts were 1 and 2 by class, and all 64 normal residuals and saturation residual were zero. The report correctly invokes AC thickening only because the source phases avoid all faces. Both samples meet the conditional theorem and remain noncritical.

The reported floating values, condition numbers and two n=32 residual failures agree with frozen receipts. The two failures are not silently certified or merged with one of the 50 certified policies. No n=64 computation is claimed.

The report correctly states 58 observations, 50 mirrored policies, 14 outside decimal observations and maximum interval width about 2.19e-9. The one negative beta is explicitly clipped only to create a new feasible primal witness, not to certify the original floating weight. The upper/lower certificate directions are unchanged. NUMERICS.md correctly gives the global maximum outside distance as

155606927024783423221/5464915751952828800000000000000
= about 2.8473801626160288e-11,

at n=16 balanced iteration 3; the earlier 2.26e-11 belongs only to n=8. Neither text turns outside observations into true LP-optimum failures.

## PASS: relative paths, frozen data and receipts

I compared the transplanted scripts to the audited originals. The dense script changes only its adjacent dependency name and corresponding hash read from results.json to dense_input.json. The rational script changes only the two absolute input paths to Path(__file__).with_name(...). The barrier script is byte-identical. The three-field dense_input.json exactly equals the corresponding original fields. Both batch input JSONs and rational_original.json are byte-identical to the independently audited originals.

All 50 rational replay policies have exactly the original lower/upper endpoints, widths, scales, minimum slacks, normalizers, clipping information and observation records. The only harmless schema difference is that the new checker writes an explicit empty clipped_negative_beta list where 49 original first-pass records omit that key. No mathematical result differs.

The dense replay's entire mathematical payload equals the previous independent audited run after removing runtime metadata. The barrier replay's mathematical payload likewise agrees. Every entry of repro/SHA256SUMS matches its actual file. integration_receipt.json exactly matches the dense/barrier replay runtime records and the rational replay's total worker CPU, maximum RSS, configured/actual process counts and overlap peak. These are stored-record checks, not new executions.

NUMERICS.md properly separates the original first-pass/retry timings from the later portable replay timings, and identifies the original-container hash provenance. Its adjacent relative-path reproduction commands point to existing files. The optional floating exploration commands explicitly warn that they overwrite the original input files and are not part of the certified replay.

## Final scope

No mathematical correction is required in this audit's scope. The final report preserves the distinction between conditional initial-ratio transfer, exact fixed-policy linear certificates and the still-unpaid complete global action budget. It does not present the theorem, either nonhard sample or the 50 rational enclosures as a general root/polylog bound. The full canonical/action transfer and F_own remain OPEN. Audit complete; stop.
