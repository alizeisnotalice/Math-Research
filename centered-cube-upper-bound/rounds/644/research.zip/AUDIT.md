# R644 independent audit ledger

Final report SHA256: `56c908d6d584a5d10ccbd83fce318405e9a0cb3104eb52458a88d2ba9b9ff024`.

- `EULER_FINAL_AUDIT.md`: independent ownership/calibration and finite-face Euler proofs were completed before comparing author text. Final report §§1–3 PASS after explicit deletion-fee definition, c/eta range and nonempty retained family were added.
- `PERIODIC_FINAL_AUDIT.md`: independent full periodic-to-finite proof audit; n=2 dense and n=1 exact scripts executed once in separate scratch, plus all 64 n=1 actual-label moments checked. Final report §§4–6 PASS; portable replay input/outputs and exact 50-policy bounds matched.
- `repro/NUMERICS.md`: original bounded searches, rejected trajectories, exact first-pass/retry, portable replay and runtime receipts remain distinguished. Negative stored primal coordinate was explicitly clipped to make a new feasible witness. Two original failed trajectories remain uncertified.
- `FILE_AUDIT.md`: independent file integrity checkpoint before adding this ledger and the final structural verifier. Its listed 17 files and hashes refer to that checkpoint, not to the final archive count. `MANIFEST.json` lists final archived payloads.

The full F_own budget is OPEN. Small full receiver price error and exact source-packet cancellation are proved simultaneously at a selected real input; converting them into a single profitable geometric action remains unproved. No general root upper bound, uniform periodic boundary estimate, canonical/action transfer or MATLAB/Arb result is asserted for R644.
