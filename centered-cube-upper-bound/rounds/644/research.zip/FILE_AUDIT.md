# R644 final directory: file-integrity audit

Scope: `/tmp/ccu_r644_final` only. Inventory and hashes below were recorded before creating this file; `FILE_AUDIT.md` is intentionally excluded from its own count and digest set. No reproduction scripts or numerical calculations were run.

## Inventory

- Files counted: **17** (3 top-level report/audits, 14 files under `repro/`).
- Total bytes: **371,231**.
- Cache/temp/PDF payloads: **none found**. The directory contains `repro/` only; no cache or temporary subdirectory, and no `.pdf`, `.tmp`, `.cache`, or bytecode files.
- `REPORT.tex` SHA-256: `56c908d6d584a5d10ccbd83fce318405e9a0cb3104eb52458a88d2ba9b9ff024`.
- Binding check: both `EULER_FINAL_AUDIT.md` and `PERIODIC_FINAL_AUDIT.md` quote that exact REPORT SHA-256. Their report binding is consistent.
- `repro/SHA256SUMS`: all 12 listed entries verified `OK` with `shasum -a 256 -c`. It omits the manifest itself, `NUMERICS.md`, and the receipt JSON; these are included in the independent manifest below.

## Reproduction paths

All required script inputs are present in `repro/` and are resolved adjacent to the scripts using `Path(__file__).with_name(...)`:

- `dense_check.py` → `dense_input.json`.
- `rational_verify.py` → `initial.json`, `expanded.json`.
- `barrier_cert.py` has no external input file.

`experiment.py` is the optional floating exploration generator; it reads CLI arguments and emits JSON on stdout. `NUMERICS.md` gives commands using output redirection to adjacent filenames. No repro `.py` script contains an absolute `/tmp` input/dependency. `EULER_FINAL_AUDIT.md` does refer to `/tmp/ccu_r644/OWNERSHIP_AUDIT.md` and `/tmp/ccu_r644/EULER_AUDIT.md` as historical audit sources; these are audit provenance references, not replay-script dependencies. `NUMERICS.md` names the local Python environment path, but no `/tmp` path.

## Independent SHA-256 manifest

Sizes are exact bytes. Paths are relative to `/tmp/ccu_r644_final`.

| File | Bytes | SHA-256 |
|---|---:|---|
| `EULER_FINAL_AUDIT.md` | 5,653 | `d1344091b0256c3d058795fb974ec38405d1ed621f0ace9236b7647906539e4f` |
| `PERIODIC_FINAL_AUDIT.md` | 5,777 | `633c9b664e2aa8935d913f05aedfe993d3b6b64d832b41ba94c837b17add6917` |
| `REPORT.tex` | 18,916 | `56c908d6d584a5d10ccbd83fce318405e9a0cb3104eb52458a88d2ba9b9ff024` |
| `repro/NUMERICS.md` | 5,205 | `7ca126b6b4c8ea1c1100daeb44d2fa5b9371a215d4e7f633a70e3cd8fedbaa5a` |
| `repro/SHA256SUMS` | 1,085 | `f0aabaa338971b9e046271abe143160bb283c393a275e948254f724a01962382` |
| `repro/barrier_cert.py` | 2,674 | `46b490b6ae5f2a7fd31d5c083fac23b0d0e7409dbe1c8344d11b654cd78fd7b9` |
| `repro/barrier_replay.json` | 1,942 | `7cc37d74b8d31587bf3088c75a0b0ca6f3ff0db3fcfac2156717de59875c71e7` |
| `repro/dense_check.py` | 6,224 | `cb9313197052db840df36982a565967fff8f01e7d03e672d655cd7d749b488d2` |
| `repro/dense_input.json` | 424 | `c78757368d0873c397f62642398937f07596910d52b5f13729d4c233ae358fa2` |
| `repro/dense_replay.json` | 29,854 | `a6977f47fa15d99d3bee5bc8393d0b72c5b0d5d4269746d8faa1f758da18786e` |
| `repro/expanded.json` | 104,163 | `2ed0a04b3811ec446070f0d9592444cbb6908fe6298dc8877602d7930ce746ee` |
| `repro/experiment.py` | 4,520 | `eb55da668db1651eb391dc9dbe8b67454b0ea1167a2035d84f55660f9c720082` |
| `repro/initial.json` | 25,166 | `94ab5ee3498dd131bfdde61264c873bf4e0804c38e1a502742946d159903f275` |
| `repro/integration_receipt.json` | 1,458 | `21f7661b754d0cbde1933e3016d86644b0a4cc651beb7c3dcee5aae876e98e88` |
| `repro/rational_original.json` | 76,306 | `9465f0022f39eecc6674f4ca76e115d90876ef1560a3ab8d220509d0b72bb4ca` |
| `repro/rational_replay.json` | 77,625 | `382d2a021ffa2335517d2309ee0046a6516b30347f1a14ffe2d21d708636719c` |
| `repro/rational_verify.py` | 4,239 | `ce3d44bbf18d23f62ca2fd3cd0ed64373af7c8a3320ea882d89f23da5dabeb0b` |
