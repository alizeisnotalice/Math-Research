# R644 final report: ownership/Euler transplant audit

**Verdict: PASS for REPORT.tex §§1–3 after the scope clarifications recorded below. F_own and the general root/polylog weak bound remain unproved.**

Report: `/tmp/ccu_r644_final/REPORT.tex`

Verified SHA-256: `56c908d6d584a5d10ccbd83fce318405e9a0cb3104eb52458a88d2ba9b9ff024`

This is a bounded consistency comparison with `/tmp/ccu_r644/OWNERSHIP_AUDIT.md` and `/tmp/ccu_r644/EULER_AUDIT.md`, not a repetition of their derivations. I read §§1–3 and the report's scope statements. Periodic transfer and numerical sections are outside this audit's proof certification.

## 1. Fresh class, parameter and deletion fee

The report distinguishes actual measurable ownership from a single total order. The finite-cell realization and signed support-function identity are correct. The ε=0 equality of the two finite-class suprema uses the necessary ordered-zero-deletion argument and the correct direction of the linear-capacity inequality.

The ε>0 enlarged class is independent of ε and is freshly calibrated, with unique `ε_N Shat_N(ε_N)=4`. It is not equated to the ordered ε>0 class. The finite-N positive denominator, Lipschitz comparison, and `Shat_N(0)≤Shat_N(ε_N)≤5Shat_N(0)` are correctly inherited. The same N and ε remain fixed for ownership replacement, deletion, source reconstruction and any later comparison. No positive-domain attainment or zero-weight limit is used.

The universal deletion preserves real retained pieces, redistributes only the deleted pieces still in the retained union, and keeps retained weights positive. Its intermediate inherited-weight problem is explicitly only an algebraic comparison. The complete receiver-loss/regularized fee remains present. The final report now defines

`L_del=ell+Rε[h+sqrt((V−h)(h−ell))]`,

requires G nonempty, and states `0<c≤1`, `η>0` before using

`ch+5L_del≤ηV+(52+200/η)M`.

These conditions match the audited R642 proof. In the actual critical, sufficiently large-H application G is indeed nonempty. The report correctly claims only that a complete F_own would suffice for the original general L1 target; it does not identify F_own with the old ordered-action theorem.

## 2. Nonsmooth face orientation and common price

The compact truncation `C_ζ={v∈B:v≥ζv^0}` is strictly positive and contains v^0. Minimizing the actual linear part Q there yields a real partition and cannot decrease the ratio. Since it remains in the freshly calibrated class, its ratio still has εR≤4; an initial lower critical or near-supremum bound is preserved. Its λ, m, source and canonical radii must be recomputed, as the theorem states.

The report's tangent price uses `G=diag(v/λ²)` without ε. The branch formula is correctly oriented:

`∇Q_F=−εr_F`.

Consequently Q minimization yields a **maximum** price ownership condition. The finite-face/implicit-function argument and compact-gradient-hull versus polyhedral-dual-cone separation produce one common convex mixture. They do not require the minimizing point to have a stable face. All branch limits share one actual final λ. The mixed quadratic identity is correctly weakened to `Σv rbar²≤Σv rbar=E≤V`; it is not falsely kept as equality.

The same-price finite covariance argument gives exactly

`G_p≤κ sqrt[ζE(V−E)/(1−ζ)]≤κV/2 sqrt[ζ/(1−ζ)]`.

With κ≤4, `ζ=η²/(4+η²)` gives G_p≤ηV. The bound has no inverse minimum-weight, label-count or scale constant. Local regularity constants are expressly allowed to depend on the finite input and are not promoted to uniform bounds.

The pointwise maximum-price assertion on nonsaturated owners and exceptional volume ≤ζV are correctly retained as volume statements, not source-mass or trace estimates.

## 3. One final source and exact packet scope

The same final gradient m supports every genuine limiting face. The positive-packet argument therefore gives `Σ_K λ_jrbar_j=0` and `Σ_K λ_jp_j=1` for each packet carrying positive mass in a single actual final KKT source. The proof does not require a different favorable source for different faces or packets. In fact the argument applies to any one chosen actual final source with its own positive-packet decomposition. Zero-multiplier active cliques are correctly excluded from the asserted packet conclusion.

The report keeps the tangent price distinct from a later canonical action's actual new α, and allows p to be signed. Neither λp nor the packet zero mean is called a nonnegative physical source transfer. The missing simultaneous geometry, shared packet supply, compensation and actual new regularized credit remain explicit.

## 4. Corrections and open target

The initial draft needed three small self-contained scope additions in §2: define L_del, state the fee's `0<c≤1,η>0` range, and require G nonempty. These were requested and the corrected sentences were reread before recording the SHA above. No unresolved substantive error was found in the assigned sections.

The report explicitly retains the initial `RB_0≤4V` liability, distinguishes projection energy from raw growth variance, and says the mixed ownership price need not support arbitrary geometry variation. It does not assert F_own or a general dimension improvement. The new audited result is a selected real input with a small full receiver price-envelope deficit and simultaneous exact positive-source-packet cancellation. Turning those facts into the complete D budget remains unproved.

Only this audit was written. No report/other-agent edit, Git operation or numerical rerun was performed. Audit complete; stop.
