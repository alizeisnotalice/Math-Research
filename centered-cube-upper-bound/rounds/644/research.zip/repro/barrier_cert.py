#!/usr/bin/env python3
from fractions import Fraction as F
from math import isqrt
from hashlib import sha256
from pathlib import Path
import json,sys,time,resource
import sympy as S
T=time.perf_counter();cpu=time.process_time();n=1;a=32;u=64;M=u//2;eps=F(1,66);A=[[F(2),F(4,3)],[F(0),F(2,3)]]
# Exact LP primal/dual certificates: beta=(0,3/4), eta=(3/4,0).
beta=[F(0),F(3,4)];dual=[F(3,4),F(0)];assert all(sum(A[q][k]*beta[k] for k in range(2))<=1 for q in range(2));assert all(sum(dual[q]*A[q][k] for q in range(2))>=1 for k in range(2));assert sum(beta)==sum(dual)==F(3,4)
bits=192;z=isqrt(1093*2**(2*bits));sl=F(z,2**bits);sh=F(z+1,2**bits);assert sl*sl<1093<sh*sh
blo=(35-sh)/132;bhi=(35-sl)/132;assert F(0)<blo<bhi<F(1,2)
def poly(x):return x*x-(F(1,2)+2*eps)*x+eps/2
assert poly(blo)>0>poly(bhi)
b1lo=F(3,4)-F(3,2)*bhi;b1hi=F(3,4)-F(3,2)*blo;Qlo=F(3,4)-bhi/2;Qhi=F(3,4)-blo/2
assert F(0)<b1lo<b1hi<F(3,4) and Qlo<Qhi<F(3,4)
# q=0 constraint tight, q=1 has strict slack; q=0 dual is η=(1+eps/(2β0))/2.
eta_lo=(1+eps/(2*bhi))/2;eta_hi=(1+eps/(2*blo))/2;assert eta_lo>0 and F(2,3)*b1hi<1
# At exact root, 2β0+(4/3)β1=1 and algebraic polynomial implies both gradient equalities.
x=S.Symbol('x');ee=S.Rational(1,66);beta1=S.Rational(3,4)-S.Rational(3,2)*x;eta=(1+ee/(2*x))/2
res=S.together(1+ee/(2*beta1)-S.Rational(4,3)*eta);numer=S.fraction(res)[0];pol=x*x-(S.Rational(1,2)+2*ee)*x+ee/2
assert S.rem(numer,pol,x)==0
identity=S.together(eta-(S.Rational(3,4)-x/2+ee));assert S.rem(S.fraction(identity)[0],pol,x)==0
# The physical source uses integer phase points of mass η, each thickened by <1/(2u).
# All half-phase source masses are zero; source moments satisfy d+eps h/λ.
assert 2*blo+F(4,3)*b1hi==1 and 2*bhi+F(4,3)*b1lo==1
# Certify displayed coarse bounds without floating arithmetic.
assert F(74,100)<Qlo<Qhi<F(75,100)
print(json.dumps({'n':1,'a':a,'H':32,'epsilon':str(eps),'u':u,'radii':['1/4','3/4'],'matrix':[[str(v) for v in row] for row in A],'linear_primal':list(map(str,beta)),'linear_dual':list(map(str,dual)),'Qlin':'3/4','beta0_formula':'(35-sqrt(1093))/132','Qepsilon_formula':'(163+sqrt(1093))/264','beta0_bounds':[str(blo),str(bhi)],'beta1_bounds':[str(b1lo),str(b1hi)],'Qepsilon_bounds':[str(Qlo),str(Qhi)],'eta0_bounds':[str(eta_lo),str(eta_hi)],'source_phase_1_mass':'0','strict_KKT':'q0 tight, q1 slack; positive alpha and eta0; gradient difference polynomial verified','periodic_only':True,'cpu_s':time.process_time()-cpu,'wall_s':time.perf_counter()-T,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'python':sys.version,'sympy':S.__version__,'script_sha256':sha256(Path(__file__).read_bytes()).hexdigest()},indent=2))
