# R644 密集标签周期计算：精简复现包

本目录只复现已完成的密集 labels / 半格 source 相位计算。原先误将 labels 本身设为半格的模型属于不同对照，不是此处密集模型的证据。用户指定的有限初始转移已得到**条件性证明**；周期数值本身并不证明无条件有限边界 KKT，更不证明完整全局动作付款或一般根阶上界。

## 文件与命令

- `dense_input.json` 只含 `matrix_T_qk`、`primal_lambda_by_k`、`source_per_label_S_kq` 三个原始字段；`dense_check.py` 用其相邻相对路径读取，独立枚举 n=2,u=8 的64个实际 source cells 和64个labels，并检验对称周期正则 KKT。原 `compute/results.json` SHA256：`5a8748e32b1efad67bd97ee61047a2bb6d0ca35c8fbaa09f5db46c71f9c58e73`；精简输入哈希见 SHA256SUMS。
- `barrier_cert.py` 是 n=1、r=(1/4,3/4)、H=32 的有理线性 primal/dual 和代数正则 KKT 证书，得 Qlin=3/4、Qε=(163+√1093)/264≈0.74265。依赖 SymPy 与 Python Fraction；周期源在全空间总质量无穷，不能直接当有限 L1 来源。
- `experiment.py` 是原有限浮点 LP 生成程序；`initial.json` 和 `expanded.json` 是**原样复制**的已存结果。原始SHA256分别为 `94ab5ee3498dd131bfdde61264c873bf4e0804c38e1a502742946d159903f275`、`2ed0a04b3811ec446070f0d9592444cbb6908fe6298dc8877602d7930ce746ee`。它们包含 `numerical_ok` 及残差失败，不是严格全局最优证书。
- `rational_verify.py` 从相邻相对路径读取这两个原始文件，不调用 LP；原保存 β 经精确非负化和 primal 缩放、原 integer dual 经精确归一后，逐行逐列 Fraction 核验。n=16 一条 β 的原值为 −7.397557968254337e−10，显式改为0并记录；不补造缺失权。50个镜像去重策略可认证，两个原 n=32 `residual_fail` 仍未认证。
- `rational_original.json` 原样保留原批次所有严格 Fraction 上下端点与逐观测方向，SHA256 `9465f0022f39eecc6674f4ca76e115d90876ef1560a3ab8d220509d0b72bb4ca`。`rational_replay.json` 是本包移植后的独立集成运行，50个策略的全部上下端点与原文件**逐项完全相同**。
- `integration_receipt.json` 单独记录此包集成运行的时耗、PID并发与比对结果。`dense_replay.json`、`barrier_replay.json`、`rational_replay.json` 是相应实际运行结果，不能与原始批次时耗混同。

在本目录中，运行：

```sh
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1
python dense_check.py > dense_replay.json
python barrier_cert.py > barrier_replay.json
python rational_verify.py > rational_replay.json
```

本机实际使用 `/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python`。仅当明确要重做**浮点探索**而非复核已存输入时，可运行 `python experiment.py 1 2 4 > initial.json` 和 `python experiment.py 8 16 32 > expanded.json`；这会覆盖输入文件，求解器状态与平台有关，不属于本次集成核验。

## 原始运行收据

原 dense 检查 Python 3.12.14、SymPy 1.14.0，CPU 0.255196 s、wall 0.255519 s、RSS 68,894,720 bytes。原浮点初批 n=1,2,4 用3个单线程worker，wall 0.219895 s、worker CPU合计约0.0158 s、峰 RSS 74,006,528 bytes；扩展 n=8,16,32 同样3个worker，wall 0.516692 s、CPU合计约0.3561 s、峰 RSS 92,372,992 bytes。n32 两条原轨迹 dual residual fail，未被补证；n64 未运行。原单独 barrier 检查 CPU 0.009536 s、wall 0.009551 s、RSS 70,123,536 bytes。

原有理首轮使用15个独立PID，实际重叠峰15，wall 0.083027 s、worker CPU合计0.514010 s、峰 RSS 11,698,176 bytes；49策略通过、1条负β被拒。单独把已有负β显式置0后的这一策略复核 CPU 0.003372 s、wall 0.003377 s、RSS 25,083,904 bytes，最终50/50双边可行。两条缺失合格权的原 residual_fail 依然未认证。

58条原float观察有14条不落在精确有理最优夹逼区间内。**最大偏离**来自 n=16、balanced 第3轮，精确值

155606927024783423221/5464915751952828800000000000000 ≈ 2.8473801626160288e−11。

先前消息中的 2.26e−11 只是 n=8 组的最大值，并非全部观察的最大值。浮点目标不在严格区间内，表示浮点记录与有理夹逼不完全一致，**不意味着真实最优值超出有理区间**。50个认证策略的最大区间宽约 2.1848865e−9；区间端点和精确偏离保留在 `rational_original.json`。

## 本次相对路径集成收据

同一 Python 3.12.14、SymPy 1.14.0。dense replay CPU 0.248937 s、wall 0.253341 s、RSS 68,829,184 bytes；barrier replay CPU 0.009946 s、wall 0.014861 s、RSS 70,074,368 bytes；有理 replay 配置15个worker，实际15个PID、重叠峰15，wall 0.087003 s、worker CPU合计0.515540 s、worker峰RSS 11,698,176 bytes。它与原0.083027秒首轮是不同运行。所有50个精确原/新端点逐一相等；数字见 `integration_receipt.json`。

因周期源本身无限且最终完整同源位移、实际接收量与实际新权联合付款尚未证明，以上全部计算仅支持有限机制与条件性初始步骤，不能当作原一般根阶目标已解决。
