#!/usr/bin/env python3
from fractions import Fraction as F
from math import comb
from concurrent.futures import ProcessPoolExecutor
from hashlib import sha256
from pathlib import Path
from multiprocessing import get_context
import json,sys,os,time,resource,traceback
sys.set_int_max_str_digits(0)
def build(n,k,idx):
 N=idx//2;f=1 if idx%2==0 else 3;D=4*N+f;A=2*(2*N+1);B=2*(2*N+(2 if f==3 else 0));den=D**n*comb(n,k);col=[]
 for q in range(n+1):
  p=[1]
  for a,b in [(A,B)]*(n-q)+[(B,A)]*q:
   nxt=[0]*(len(p)+1)
   for j,x in enumerate(p):nxt[j]+=a*x;nxt[j+1]+=b*x
   p=nxt
  col.append(F(p[k],den))
 return col
def check(task):
 start=time.perf_counter();cpu=time.process_time()
 try:
  n=task['n'];h=task['representative'];policy=h['policy'];beta=list(map(lambda v:F(str(v)),h['beta']));dual=[F(int(x)) for x in h['dual_integer_weights']]
  if len(policy)!=n+1 or len(beta)!=n+1 or len(dual)!=n+1:raise ValueError('missing or wrong-length original weights')
  if any(x<0 for x in dual):raise ValueError('negative stored dual weight')
  clipped=[{'index':i,'original':str(x)} for i,x in enumerate(beta) if x<0]
  beta=[max(F(0),x) for x in beta]
  cols=[build(n,k,policy[k]) for k in range(n+1)];loads=[sum((cols[k][q]*beta[k] for k in range(n+1)),F(0)) for q in range(n+1)];factor=max(F(1),max(loads));pb=[x/factor for x in beta];pr=[sum((cols[k][q]*pb[k] for k in range(n+1)),F(0)) for q in range(n+1)]
  dl=[sum((cols[k][q]*dual[q] for q in range(n+1)),F(0)) for k in range(n+1)];normal=min(dl)
  if normal<=0:raise ValueError('zero dual-column load')
  y=[x/normal for x in dual];dy=[sum((cols[k][q]*y[q] for q in range(n+1)),F(0)) for k in range(n+1)]
  assert all(z<=1 for z in pr) and all(z>=1 for z in dy)
  L=sum(pb,F(0));U=sum(y,F(0));assert L<=U
  obs=[]
  for z in task['observations']:
   fv=F(str(z['Qlin_float']));obs.append({**z,'float_in_exact_interval':L<=fv<=U,'distance_below':str(max(F(0),L-fv)),'distance_above':str(max(F(0),fv-U))})
  result={'status':'certified','n':n,'policy':policy,'lower':str(L),'upper':str(U),'width':str(U-L),'lower_float':float(L),'upper_float':float(U),'width_float':float(U-L),'primal_min_slack':str(min(1-z for z in pr)),'dual_min_slack':str(min(z-1 for z in dy)),'primal_scale':str(factor),'dual_normalizer':str(normal),'clipped_negative_beta':clipped,'observations':obs}
 except Exception as e:result={'status':'failed','n':task['n'],'error':repr(e),'observations':task['observations']}
 result.update({'pid':os.getpid(),'started_monotonic':start,'ended_monotonic':time.perf_counter(),'cpu_s':time.process_time()-cpu,'wall_s':time.perf_counter()-start,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss});return result
if __name__=='__main__':
 start=time.perf_counter();files=[Path(__file__).with_name('initial.json'),Path(__file__).with_name('expanded.json')];tasks={};fail=[]
 for f in files:
  p=json.loads(f.read_text())
  for row in p['results']:
   n=row['n']
   for r in row['runs']:
    for h in r['history']:
     o={'input':f.name,'start':r['start'],'iteration':h['iteration'],'status':h['status']}
     if h['status']!='numerical_ok':fail.append(o|{'n':n,'original_record':h});continue
     o['Qlin_float']=h['Qlin_float'];policy=tuple(h['policy']);key=(n,min(policy,policy[::-1]))
     if key not in tasks:tasks[key]={'n':n,'representative':h,'observations':[]}
     tasks[key]['observations'].append(o)
 vals=list(tasks.values());workers=min(15,os.cpu_count() or 1,len(vals))
 with ProcessPoolExecutor(max_workers=workers,mp_context=get_context('fork')) as p:res=list(p.map(check,vals))
 events=sorted([(z['started_monotonic'],1) for z in res]+[(z['ended_monotonic'],-1) for z in res]);active=peak=0
 for t,delta in events:active+=delta;peak=max(peak,active)
 out={'files':{f.name:sha256(f.read_bytes()).hexdigest() for f in files},'input_numerical_ok':sum(len(t['observations']) for t in vals),'deduplicated_tasks':len(vals),'uncertified_original_failures':fail,'workers_configured':workers,'actual_max_overlapping_tasks':peak,'distinct_worker_pids':len(set(x['pid'] for x in res)),'results':res,'wall_s':time.perf_counter()-start,'python':sys.version,'script_sha256':sha256(Path(__file__).read_bytes()).hexdigest()}
 print(json.dumps(out,indent=2))
