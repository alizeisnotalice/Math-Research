#!/usr/bin/env python3
from fractions import Fraction as F
from math import comb
from scipy.optimize import linprog
from scipy import __version__ as sv
from pathlib import Path
from hashlib import sha256
from concurrent.futures import ProcessPoolExecutor
import sys,os,json,time,resource,warnings
import numpy as np
sys.set_int_max_str_digits(0)
def build(n):
 radii=[];raw=[];dens=[];floats=[]
 for N in range(2*n+1):
  for fourth in (1,3):
   D=4*N+fourth;r=F(D,4);A=2*(2*N+1);B=2*(2*N+(2 if fourth==3 else 0));den=D**n;rows=[];fr=[]
   for q in range(n+1):
    p=[1]
    for a,b in [(A,B)]*(n-q)+[(B,A)]*q:
     out=[0]*(len(p)+1)
     for j,x in enumerate(p):out[j]+=a*x;out[j+1]+=b*x
     p=out
    rows.append(p);fr.append([p[k]/(den*comb(n,k)) for k in range(n+1)])
   radii.append(r);raw.append(rows);dens.append(den);floats.append(fr)
 return radii,raw,dens,np.asarray(floats)
def maximizer(n,raw,dens,weights):
 policy=[]
 for k in range(n+1):
  best=0;bn=sum(weights[q]*raw[0][q][k] for q in range(n+1));bd=dens[0]
  for j in range(1,len(raw)):
   z=sum(weights[q]*raw[j][q][k] for q in range(n+1));
   if z*bd>bn*dens[j]:best=j;bn=z;bd=dens[j]
  policy.append(best)
 return tuple(policy)
def canon(p):return min(p,tuple(reversed(p)))
def run(n):
 start=time.perf_counter();cpu=time.process_time();r,raw,den,Af=build(n);u=2*32*n;assert u%4==0 and F(1,u)<=F(1,2*32*n)
 corner=[1]+[0]*n;balanced=[1]*(n+1);mixed=tuple((4*k+2*n)%len(r) for k in range(n+1));candidates=[('corner',maximizer(n,raw,den,corner)),('balanced',maximizer(n,raw,den,balanced)),('mixed',mixed)]
 starts=[];seenstarts=set()
 for label,p in candidates:
  if canon(p) not in seenstarts:starts.append((label,p));seenstarts.add(canon(p))
 runs=[]
 for label,initial in starts:
  policy=initial;hist=[];visited=set()
  for it in range(6):
   if canon(policy) in visited:break
   visited.add(canon(policy));A=np.column_stack([Af[policy[k],:,k] for k in range(n+1)])
   with warnings.catch_warnings():
    warnings.simplefilter('ignore');sol=linprog(-np.ones(n+1),A_ub=A,b_ub=np.ones(n+1),bounds=(0,None),method='highs',options={'threads':1,'primal_feasibility_tolerance':1e-9,'dual_feasibility_tolerance':1e-9})
   if not sol.success:
    hist.append({'iteration':it,'status':'solver_failed','message':sol.message,'policy':list(policy)});break
   beta=sol.x;eta=-sol.ineqlin.marginals;pres=max(0.,float(np.max(A@beta-1)));dres=max(0.,float(np.max(1-A.T@eta)));gap=abs(float(beta.sum()-eta.sum()));
   if min(eta)<-1e-9 or pres>1e-8 or dres>1e-8 or gap>1e-8:
    hist.append({'iteration':it,'status':'residual_fail','p_res':pres,'d_res':dres,'gap':gap,'policy':list(policy)});break
   # integer representation is an exact rational, followed by exact feasibility scaling.
   iw=[max(0,int(round(float(t)*10**15))) for t in eta]
   if not any(iw):hist.append({'iteration':it,'status':'dual_rounds_to_zero','policy':list(policy)});break
   scores=[F(sum(iw[q]*raw[policy[k]][q][k] for q in range(n+1)),den[policy[k]]*comb(n,k)) for k in range(n+1)]
   mn=min(scores)
   if mn<=0:hist.append({'iteration':it,'status':'rational_dual_not_scalable','policy':list(policy)});break
   certified_upper=F(sum(iw),1)/mn
   nxt=maximizer(n,raw,den,iw)
   # The same rescaled dual must remain feasible for every new column.
   for k in range(n+1):assert F(sum(iw[q]*raw[nxt[k]][q][k] for q in range(n+1)),den[nxt[k]]*comb(n,k))>=mn
   hist.append({'iteration':it,'status':'numerical_ok','policy':list(policy),'Qlin_float':float(beta.sum()),'float_dual':float(eta.sum()),'primal_violation':pres,'dual_violation':dres,'float_gap':gap,'exact_feasible_dual_upper':str(certified_upper),'dual_integer_weights':iw,'next_policy':list(nxt),'beta':beta.tolist(),'eta':eta.tolist()})
   if canon(nxt)==canon(policy):break
   policy=nxt
  runs.append({'start':label,'history':hist})
 return {'n':n,'u':u,'radii':list(map(str,r)),'distinct_starts':len(starts),'runs':runs,'cpu_s':time.process_time()-cpu,'wall_s':time.perf_counter()-start,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
if __name__=='__main__':
 start=time.perf_counter();ns=list(map(int,sys.argv[1:])) if len(sys.argv)>1 else [1,2,4];workers=min(os.cpu_count() or 1,15,len(ns))
 with ProcessPoolExecutor(max_workers=workers) as p:res=list(p.map(run,ns))
 out={'n':ns,'workers':workers,'results':res,'wall_s':time.perf_counter()-start,'python':sys.version,'scipy':sv,'numpy':np.__version__,'script_sha256':sha256(Path(__file__).read_bytes()).hexdigest()};print(json.dumps(out,indent=2))
