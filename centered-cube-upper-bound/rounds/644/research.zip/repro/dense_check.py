#!/usr/bin/env python3
from fractions import Fraction as F
from itertools import product
from math import floor,ceil,comb
from pathlib import Path
from hashlib import sha256
import json,sys,time,resource
import sympy as S
def mathprod(xs):
 ans=F(1)
 for x in xs:ans*=x
 return ans
T=time.perf_counter();cpu=time.process_time();n=2;u=8;M=u//2;a=32*n;r=[F(65,4),F(71,4),F(77,4)];assert u%4==0 and F(1,u)<=2*min(r)/a
old=json.loads(Path(__file__).with_name('dense_input.json').read_text());Tmat=old['matrix_T_qk'];lam0=list(map(F,old['primal_lambda_by_k']));lam=[v/M**n for v in lam0];d=[(2*x)**n for x in r];beta=[comb(n,k)*d[k]*M**n*lam[k] for k in range(n+1)];assert sum(beta)==1
A=[[F(Tmat[q][k],comb(n,k)*d[k]) for k in range(n+1)] for q in range(n+1)]
# All source cell representatives j/u in one period; all centerpoints on midpoint fine grid.
# For any radius each coordinate loop includes every possible contributing finite center.
def phase(x):
 f=x-floor(x);return 0 if f<F(1,4) or f>=F(3,4) else 1
def count1(x,r0):
 B=ceil(r0)+2;out=[0,0]
 for period in range(-B,B+1):
  for j in range(u):
   y=F(period)+F(2*j+1,2*u)
   if abs(x-y)<r0:out[phase(y)]+=1
 return out
probe_base=[F(1),F(2),F(5)];normalizer=max(sum(F(Tmat[q][k])*probe_base[k] for k in range(n+1)) for q in range(n+1));probe=[v/(normalizer*M**n) for v in probe_base]
rows=[];endpoint_loads=[];probe_endpoints=[]
for q in range(n+1):
 endpoint_loads.append(sum(F(Tmat[q][k])*M**n*lam[k] for k in range(n+1)));probe_endpoints.append(sum(F(Tmat[q][k])*M**n*probe[k] for k in range(n+1)))
assert len(set(probe_endpoints))>1
for index in product(range(u),repeat=n):
 xx=[F(j,u) for j in index];theta=[F(min(j,u-j),M) for j in index];counts=[];direct=F(0);direct_probe=F(0)
 for k in range(n+1):
  directaxes=[count1(x,r[k]) for x in xx]
  Nk=floor(r[k]);A0=2*Nk+1;B0=2*Nk+(2 if r[k]-Nk==F(3,4) else 0)
  for h in range(n):
   aa=F(M)*((1-theta[h])*A0+theta[h]*B0);bb=F(M)*((1-theta[h])*B0+theta[h]*A0);assert directaxes[h]==[aa,bb]
  coeff=[1]
  for ac,bc in directaxes:
   nxt=[0]*(len(coeff)+1)
   for j,v in enumerate(coeff):nxt[j]+=v*ac;nxt[j+1]+=v*bc
   coeff=nxt
  counts.append(coeff[k]);direct+=coeff[k]*lam[k];direct_probe+=coeff[k]*probe[k]
 # Multiaffine interpolation of actual endpoint loads for the fixed assignment.
 interp=F(0);probe_interp=F(0)
 for bits in product((0,1),repeat=n):
  wt=mathprod(theta[j] if bits[j] else 1-theta[j] for j in range(n));interp+=wt*endpoint_loads[sum(bits)];probe_interp+=wt*probe_endpoints[sum(bits)]
 assert direct==interp and direct<=max(endpoint_loads) and direct_probe==probe_interp and direct_probe<=max(probe_endpoints)
 rows.append({'cell_index':list(index),'theta':list(map(str,theta)),'class_counts':counts,'actual_fixed_load':str(direct),'nonconstant_probe_load':str(direct_probe)})
# Reverse source phase counts for one label of each class and all midpoint centers in that phase.
source_counts=old['source_per_label_S_kq']; reps=[(F(-1,16),F(-1,16)),(F(-1,16),F(5,16)),(F(5,16),F(5,16))];dual_checks=[]
for k,center in enumerate(reps):
 B=ceil(r[k])+2;counts=[0]*(n+1)
 for ix in product(range(-2*B,2*B+1),repeat=n):
  src=[F(z,2) for z in ix];q=sum(v.denominator==2 for v in src)
  if all(abs(src[j]-center[j])<r[k] for j in range(n)):counts[q]+=1
 assert counts==source_counts[k] and sum(F(counts[q],2**n) for q in range(n+1))==d[k]
 dual_checks.append({'k':k,'center':list(map(str,center)),'counts':counts,'moment':str(d[k])})
# Exhaustively check source-point moments for every actual fine-grid label in the period.
all_labels=[]
for ids in product(range(u),repeat=n):
 center=[F(2*j+1,2*u) for j in ids];k=sum(phase(x) for x in center);B=ceil(r[k])+2;one=[]
 for x in center:
  cc=[0,0]
  for j in range(-2*B,2*B+1):
   y=F(j,2)
   if abs(y-x)<r[k]:cc[0 if y.denominator==1 else 1]+=1
  one.append(cc)
 coeff=[1]
 for ac,bc in one:
  nxt=[0]*(len(coeff)+1)
  for j,v in enumerate(coeff):nxt[j]+=v*ac;nxt[j+1]+=v*bc
  coeff=nxt
 assert coeff==source_counts[k]
 all_labels.append({'index':list(ids),'class':k,'source_q_counts':coeff})
assert all(endpoint_loads[q]==1 for q in range(n+1)) and all(sum(A[q][k]*beta[k] for k in range(n+1))==1 for q in range(n+1))
# Exact KKT for the periodic same-epsilon logarithmic objective and Voronoi ownership.
eps=F(1,64)/F(a+1,a)**n;owner=[F(comb(n,k),2**n) for k in range(n+1)]
Amat=S.Matrix([[S.Rational(x.numerator,x.denominator) for x in row] for row in A]);grad=S.Matrix([S.Rational((1+eps*owner[k]/beta[k]).numerator,(1+eps*owner[k]/beta[k]).denominator) for k in range(n+1)]);dualS=Amat.T.inv()*grad;dual=[F(int(x.p),int(x.q)) for x in dualS];assert all(x>0 for x in dual)
source_dual=[dual[q]/comb(n,q) for q in range(n+1)];moments=[sum(F(source_counts[k][q])*source_dual[q] for q in range(n+1)) for k in range(n+1)]
assert all(moments[k]==d[k]+eps*F(1,u**n)/lam[k] for k in range(n+1));assert sum(dual)==1+eps
# True nearest-grid Voronoi cells are within all receiver cubes since 1/u <= 2r_min/a.
assert F(1,2*u)<=min(r)/a
out={'dimension':n,'u':u,'phase_count_each':M,'radii':list(map(str,r)),'T_qk':Tmat,'A_qk':[[str(x) for x in row] for row in A],'beta':list(map(str,beta)),'primal_lambda_per_label':list(map(str,lam)),'source_endpoint_loads':list(map(str,endpoint_loads)),'nonconstant_probe_endpoint_loads':list(map(str,probe_endpoints)),'all_64_actual_source_cells':rows,'source_moment_checks':dual_checks,'all_64_label_source_counts':all_labels,'ownership':'actual nearest-grid Voronoi cubes, volume 1/u^n per label','linear_primal_and_periodic_dual_value':'1','epsilon':str(eps),'regularized_alpha_equal_primal':True,'regularized_source_aggregate':list(map(str,dual)),'regularized_source_mass_per_point':list(map(str,source_dual)),'regularized_row_moments':list(map(str,moments)),'regularized_Q':'1','regularized_M':str(sum(dual)),'periodic_only':True,'run':{'python':sys.version,'sympy':S.__version__,'cpu_s':time.process_time()-cpu,'wall_s':time.perf_counter()-T,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'script_sha256':sha256(Path(__file__).read_bytes()).hexdigest(),'dependency_results_sha256':sha256(Path(__file__).with_name('dense_input.json').read_bytes()).hexdigest()}}
print(json.dumps(out,indent=2))
