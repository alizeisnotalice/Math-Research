from pathlib import Path
import hashlib,json,re,sys
import sympy as S
root=Path(__file__).parent
report=(root/'REPORT.tex').read_text()
sha=hashlib.sha256((root/'REPORT.tex').read_bytes()).hexdigest()
for name in ('EULER_FINAL_AUDIT.md','PERIODIC_FINAL_AUDIT.md','AUDIT.md'):
    assert sha in (root/name).read_text(),name
stack=[]
for typ,env in re.findall(r'\\(begin|end)\{([^}]+)\}',report):
    if typ=='begin':stack.append(env)
    else:assert stack.pop()==env
assert not stack
labels=re.findall(r'\\label\{([^}]+)\}',report)
assert len(labels)==len(set(labels))
assert set(re.findall(r'\\(?:eqref|ref)\{([^}]+)\}',report))<=set(labels)
z,E,V,eta=S.symbols('z E V eta',positive=True)
assert S.simplify(z*(1-z)*V*(E-E**2/V)/(1-z)**2-z*E*(V-E)/(1-z))==0
assert S.simplify((2*S.sqrt(z/(1-z))).subs(z,eta**2/(4+eta**2))-eta)==0
assert S.expand(V**2/4-E*(V-E)-(E-V/2)**2)==0
for line in (root/'repro/SHA256SUMS').read_text().splitlines():
    if not line.strip():continue
    h,name=line.split(maxsplit=1)
    assert hashlib.sha256((root/'repro'/name.lstrip('*')).read_bytes()).hexdigest()==h,name
print(json.dumps({'report_sha256':sha,'audit_bindings':3,'latex_environments_and_references':'pass','symbolic_identities':3,'repro_hashes':'pass','python':sys.version,'sympy':S.__version__,'compiled_pdf':False},ensure_ascii=False,indent=2))
