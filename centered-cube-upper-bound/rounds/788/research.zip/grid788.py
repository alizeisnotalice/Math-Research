"""R788: grid-blurred densities, product moments and a true two-axis envelope."""

import argparse
from bisect import bisect_left, bisect_right
from fractions import Fraction as F
from itertools import product
from math import comb, isqrt
import json
from pathlib import Path
import platform
import sys

import flint
from flint import arb, ctx, fmpq


ctx.prec = 256
ORDERS = (2, 3, 4)


def ar(x):
    x = F(x)
    return arb(fmpq(x.numerator, x.denominator))


def fsum(xs):
    return sum(xs, F(0))


def grid(b, shifts):
    K = len(shifts)
    edges = [-b + F(2 * j, K) * b for j in range(K + 1)]
    points = [(edges[j] + edges[j + 1]) / 2 + shifts[j] * b / K for j in range(K)]
    assert sorted(set(points)) == points
    # The common-rank coupling sends the whole j-th equiprobable interval to z_j.
    d = max(abs(points[j] - endpoint) for j in range(K) for endpoint in edges[j:j + 2])
    assert d == b / K * (1 + max(map(abs, shifts)))
    return points, d


def q_at(x, t, points):
    count = bisect_right(points, x + t) - bisect_left(points, x - t)
    return F(count, len(points)) / (2 * t)


def p_at(x, t, width):
    return max(F(0), min(2 * width, t + width - abs(x))) / (4 * t * width)


def q_breaks(t, points):
    return sorted({z + side * t for z in points for side in (-1, 1)})


def segments(t, points):
    bounds = q_breaks(t, points)
    return [(lo, hi, q_at((lo + hi) / 2, t, points))
            for lo, hi in zip(bounds, bounds[1:])]


def int_inv_linear(lo, hi, length, k):
    if lo == hi:
        out = length / lo**(k - 1)
        return ar(out) if k == 2 else out
    if k == 2:
        return ar(length / (hi - lo)) * ar(hi / lo).log()
    return length * (hi**(2 - k) - lo**(2 - k)) / ((2 - k) * (hi - lo))


def moment_test(t, width, points):
    assert t >= width > 0
    critical = {t + width, t - width, -t + width, -t - width}
    endpoints = sorted(critical | set(q_breaks(t, points)))
    qmass = pmass = max_ratio = F(0)
    m2_lower = m2_upper = F(0)
    moments = {2: arb(0), 3: F(0), 4: F(0)}
    divergence_segments = []
    positive_cells = 0
    for a, b in zip(endpoints, endpoints[1:]):
        length = b - a
        g = q_at((a + b) / 2, t, points)
        pa, pb = p_at(a, t, width), p_at(b, t, width)
        qmass += length * g
        pmass += length * (pa + pb) / 2
        if not g:
            continue
        positive_cells += 1
        if min(pa, pb) == 0:
            divergence_segments.append((a, b))
            continue
        max_ratio = max(max_ratio, g / min(pa, pb))
        for k in ORDERS:
            cell = int_inv_linear(pa, pb, length, k)
            moments[k] += (ar(g**k) if k == 2 else g**k) * cell
        # Independent convex quadrature for k=2 on each positive affine piece.
        m2_lower += length * g**2 * 2 / (pa + pb)
        m2_upper += length * g**2 * (1 / pa + 1 / pb) / 2
    assert qmass == pmass == 1
    if divergence_segments:
        return dict(width=width, q_p_essential_supremum="infinity",
                    moments={k: "infinity" for k in ORDERS}, diverging_cells=divergence_segments,
                    positive_step_cells=positive_cells), None
    assert ar(m2_lower) < moments[2] < ar(m2_upper)
    assert 1 < moments[2] and all(moments[k] > 1 for k in (3, 4))
    return dict(width=width, q_p_essential_supremum=max_ratio, moments=moments,
                chi_square=moments[2] - 1, moment_2_rational_brackets=[m2_lower, m2_upper],
                positive_step_cells=positive_cells), moments


def compare(name, n, b, shifts, t=None, enlarged=False):
    points, d = grid(b, shifts)
    B = b + 2 * d
    t = B if t is None else t
    ell = ar(n + 2).log()
    R = F(1)
    assert ar(b) >= 1 / (4 * ell**2) and t >= B
    assert d <= b / 2
    larger, moments = moment_test(t, B, points)
    old, _ = moment_test(t, b, points)
    rho = B / b
    assert larger["q_p_essential_supremum"] <= rho
    if "endpoint" in name:
        assert old["q_p_essential_supremum"] == "infinity" or old["q_p_essential_supremum"] > rho
    alpha = 3 * d / (2 * b)
    chi_upper = ar(B / t * alpha**2) * (1 + 2 * ar(1 / alpha).log())
    actual_chi = moments[2] - 1
    assert 0 < actual_chi < chi_upper
    product_report = {}
    for k, M in moments.items():
        M_ball = M if k == 2 else ar(M)
        coeff = comb(k, 2) * rho**(k - 2)
        # Taylor on [0,rho], from r=1. k=2 is the exact preexisting chi² identity.
        if k > 2:
            assert M_ball < 1 + ar(coeff) * actual_chi
        certified_upper = n * ar(coeff) * chi_upper
        actual_log = n * M_ball.log()
        assert 0 < actual_log < certified_upper
        dominance_only_log = n * (k - 1) * ar(rho).log()
        assert actual_log < dominance_only_log
        product_report[k] = dict(log_actual_moment=actual_log,
                                 actual_moment=M_ball**n,
                                 log_upper_via_chi_square=certified_upper,
                                 log_upper_via_density_ratio_only=dominance_only_log)
    window_scale = ar(d / R) * arb(n).sqrt() * ell**2
    if enlarged:
        assert ar(F(1, 4)) < window_scale < ar(1)
        assert product_report[4]["log_actual_moment"] < ar(1)
    return dict(name=name, n=n, R=R, ell_Arb=ell, b=b, grid_point_count=len(points),
                b_over_R=b / R, t=t, W_infty_exact=d, d_over_b=d / b,
                d_times_sqrt_n_ell_squared_over_R=window_scale,
                shift_units_of_half_cell=shifts, first_and_last_actual_grid_points=[points[0], points[-1]],
                density_cap_enlarged=rho, enlarged_reference=larger,
                original_width_reference=old,
                chi_square_upper_from_CDF_and_density_cap=chi_upper,
                n_axis_independent_tensor_moments=product_report)


def area(rect):
    x0, x1, y0, y1 = rect
    return max(F(0), x1 - x0) * max(F(0), y1 - y0)


def clip(a, b):
    return max(a[0], b[0]), min(a[1], b[1]), max(a[2], b[2]), min(a[3], b[3])


def rectangle_union_area(rects):
    if not rects:
        return F(0)
    result = F(0)
    xs = sorted({x for item in rects for x in item[:2]})
    for lo, hi in zip(xs, xs[1:]):
        ys = sorted((y0, y1) for a, b, y0, y1 in rects if a <= lo and hi <= b)
        length = F(0)
        top = None
        for y0, y1 in ys:
            if top is None or y0 >= top:
                length += y1 - y0
                top = y1
            elif y1 > top:
                length += y1 - top
                top = y1
        result += (hi - lo) * length
    return result


def true_envelope():
    b = F(1, 4)
    t = (F(1, 2), F(9, 16), F(11, 16))
    shifts = ((F(1, 2), F(-3, 4), F(1, 8), F(-1, 8)),
              (F(-1, 2), F(1, 4), F(-5, 8), F(3, 4), F(1, 2)))
    grid_data = [grid(b, axis) for axis in shifts]
    points = [x for x, d in grid_data]
    assert all(t[0] >= b + 2 * d for _, d in grid_data)
    breaks = [sorted({z for tau in t for z in q_breaks(tau, axis)}) for axis in points]
    xa, ya = [list(zip(v, v[1:])) for v in breaks]
    totals = [F(0)] * len(t)
    areas = [F(0)] * len(t)
    tie_area = F(0)
    checked = 0
    for (l, h), (u, v) in product(xa, ya):
        x, y = (l + h) / 2, (u + v) / 2
        values = [q_at(x, tau, points[0]) * q_at(y, tau, points[1]) for tau in t]
        winner = max(range(len(t)), key=lambda j: (values[j], -j))
        val = values[winner]
        if val:
            a = (h - l) * (v - u)
            totals[winner] += val * a
            areas[winner] += a
            if values.count(val) > 1:
                tie_area += a
            checked += 1
    # Independent partition: each candidate starts from its own rectangles.
    # Subtract the area where another candidate dominates or wins the fixed tie.
    raw = []
    for tau in t:
        own = []
        for (x0, x1, w), (y0, y1, z) in product(segments(tau, points[0]),
                                              segments(tau, points[1])):
            if w * z:
                own.append(((x0, x1, y0, y1), w * z))
        assert fsum(area(R) * density for R, density in own) == 1
        raw.append(own)
    recomputed = [F(0)] * len(t)
    winning_areas = [F(0)] * len(t)
    for j, own in enumerate(raw):
        for rect, val in own:
            excluded = []
            for k, block in enumerate(raw):
                if k == j:
                    continue
                for other, w in block:
                    if w > val or (w == val and k < j):
                        clipped = clip(rect, other)
                        if area(clipped):
                            excluded.append(clipped)
            kept = area(rect) - rectangle_union_area(excluded)
            assert kept >= 0
            winning_areas[j] += kept
            recomputed[j] += kept * val
    assert recomputed == totals and winning_areas == areas and min(totals) > 0
    joint = sum(totals)
    axis_envelope = [fsum((hi - lo) * max(q_at((lo + hi) / 2, tau, point) for tau in t)
                          for lo, hi in cells)
                     for cells, point in zip((xa, ya), points)]
    pointwise_separate = axis_envelope[0] * axis_envelope[1]
    assert 1 < joint < pointwise_separate < len(t)
    return dict(n=2, b=b, exact_candidate_t=t,
                true_independent_asymmetric_grid_points=points,
                exact_d_each_axis=[d for _, d in grid_data], positive_union_cells=checked,
                order_tie_rule="least index", positive_tie_area=tie_area,
                winning_set_Lebesgue_areas=areas, integral_over_each_actual_winner=totals,
                true_integral_max_of_same_t_products=joint,
                wrong_allow_different_scale_each_axis_integral=pointwise_separate)


def shifts_pattern(K):
    periodic = (F(1, 2), F(-3, 4), F(1, 8), F(-1, 8))
    return tuple(periodic[j % len(periodic)] for j in range(K))


def shell_exchange(points, delta):
    """One endpoint shell, both by price and by the mark that entered it."""
    K = len(points)
    cuts = sorted({z for x in points for z in (x, x + delta)})
    cells = []
    for lo, hi in zip(cuts, cuts[1:]):
        r = (lo + hi) / 2
        rank = F(bisect_right(points, r), K)
        load = F(bisect_right(points, r) - bisect_right(points, r - delta), K)
        if load:
            cells.append((lo, hi, load, rank))
    integral = fsum((hi - lo) * load**2 / rank for lo, hi, load, rank in cells)
    exchanged = fsum(
        fsum(max(F(0), min(hi, z + delta) - max(lo, z)) * load / rank
             for lo, hi, load, rank in cells) / K for z in points
    )
    assert integral == exchanged
    a = max(F(bisect_right(points, z + delta) - bisect_left(points, z), K)
            for z in points)
    rank_sum = fsum(min(F(1), a / F(i, K)) / K for i in range(1, K + 1))
    rank_integral = ar(a) * (1 + ar(1 / a).log())
    assert ar(rank_sum) < rank_integral and integral <= delta * rank_sum
    return integral, rank_sum, rank_integral, a


def one_sided_reference(name, n, b, shifts, delta):
    points, d = grid(b, shifts)
    t, T = F(1), 1 + delta
    ell = arb(n + 2).log()
    assert points[-1] - points[0] <= 2 * t
    assert ar(T - t) < 1 / (arb(n).sqrt() * ell**3)
    assert 1 <= t < T <= 2
    endpoints = sorted(set(q_breaks(t, points)) | set(q_breaks(T, points)))
    new_mass = old_mass = direct = m2 = shell = mean_shell = F(0)
    for lo, hi in zip(endpoints, endpoints[1:]):
        r = (lo + hi) / 2
        u, v = q_at(r, t, points), q_at(r, T, points)
        length = hi - lo
        assert u == 0 or v > 0
        new_mass += length * u
        old_mass += length * v
        if v:
            direct += length * (u - v)**2 / v
            m2 += length * u**2 / v
            H = 2 * T * v
            e = H - 2 * t * u
            assert 0 <= e <= H
            shell += length * e**2 / H
            mean_shell += length * e / (2 * T)
    assert new_mass == old_mass == 1 and m2 - 1 == direct > 0
    assert mean_shell == delta / T
    left, rank, rank_bound, a = shell_exchange(points, delta)
    right, reverse_rank, _, backwards_a = shell_exchange([-z for z in reversed(points)], delta)
    assert a == backwards_a and ar(a) <= ell / arb(n).sqrt()
    assert shell == left + right
    assert direct == T * shell / (2 * t**2) - (delta / t)**2
    rational_upper = T * delta * (rank + reverse_rank) / (2 * t**2) - (delta / t)**2
    bound = ar(T * delta / t**2) * rank_bound - ar((delta / t)**2)
    assert direct <= rational_upper and ar(rational_upper) < bound
    min_spacing = min(y - x for x, y in zip(points, points[1:]))
    single_point = None
    if delta < min_spacing:
        harmonic = fsum(F(1, k) for k in range(1, len(points) + 1))
        single_point = T * delta / t**2 * harmonic / len(points) - (delta / t)**2
        assert a == F(1, len(points)) and single_point == direct == rational_upper
    else:
        assert a > F(1, len(points)) and direct < rational_upper
    return dict(name=name, n=n, b=b, R=t, t=t, T=T, Delta=delta, W_infty_grid_to_uniform=d,
                grid_points=points, grid_min_spacing=min_spacing, max_Delta_window_mass=a,
                chi_square_q_t_relative_to_q_T_exact=direct,
                exact_left_and_right_shell_integrals=[left, right],
                exact_exchanged_rank_sums=[rank, reverse_rank],
                exact_weighted_rank_upper=rational_upper, Arb_integrated_rank_upper=bound,
                disjoint_windows_closed_form=single_point,
                n_axis_product_log_M2_Arb=n * ar(1 + direct).log(),
                a_over_sqrt_ell_over_n_Arb=ar(a) / (ell / n).sqrt())


def report():
    pressure_shift = list(shifts_pattern(8))
    pressure_shift[-1] = 1 - F(1, 2**14)
    boundary_shift = list(pressure_shift)
    boundary_shift[-1] = F(1)
    small = [
        compare("asymmetric_interior_grid", 2, F(1, 4), shifts_pattern(4), F(1, 2)),
        compare("near_right_endpoint_and_t_equals_expanded_b", 2, F(1, 4), pressure_shift),
        compare("exact_endpoint_makes_unexpanded_moments_diverge", 2, F(1, 4), boundary_shift)]
    large = []
    for n, L in ((64, 4), (1024, 6), (16384, 9), (65536, 11)):
        ell = arb(n + 2).log()
        assert L < ell < L + 1
        K = isqrt(n)
        assert K**2 == n
        large.append(compare("grid_spacing_R_over_sqrt_n_ell_squared", n, F(1, 4 * L**2),
                             shifts_pattern(K), F(1), enlarged=True))
    return dict(
        python={"executable": sys.executable, "version": platform.python_version(),
                "architecture": platform.machine(), "python_flint": flint.__version__},
        arithmetic="Exact Fraction and 256-bit Arb, with rational bounds on the log integrals",
        command="python -B grid788.py --check grid788.json",
        conventions=("U_t is the uniform probability density on [-t,t]. "
                     "Each gamma gives equal weight to one actual point per equiprobable cell; "
                     "its shifts can be asymmetric. Moments are E_p[(q/p)^k] and "
                     "chi-square=M_2-1. All large tensors have independent identical axes."),
        scope=("Finite analytic product reference tests. The candidate grid dimensions and "
               "couplings do not impose the high-dimensional original geometric gates."),
        small_and_boundary=small, enlarged_n_and_spacing=large,
        exact_two_axis_shared_scale_envelope=true_envelope(),
        one_sided_reference_shell_checks=[
            one_sided_reference("single_atom_windows", 2, F(1, 4), shifts_pattern(4), F(1, 128)),
            one_sided_reference("overlapping_shell_windows", 4, F(1, 4), pressure_shift, F(1, 20)),
            one_sided_reference("near_sqrt_log_over_n_atom_mass", 1024, F(1, 144),
                                shifts_pattern(12), F(1, 2**15))])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    out = parser.add_mutually_exclusive_group()
    out.add_argument("--output", type=Path)
    out.add_argument("--check", type=Path)
    args = parser.parse_args()
    value = (json.dumps(report(), sort_keys=True, indent=2, default=str) + "\n").encode()
    if args.output:
        args.output.write_bytes(value)
    elif args.check:
        if args.check.read_bytes() != value:
            raise SystemExit("certificate differs")
        print("grid788: three pressure cases, four grid products, the exact joint envelope and three shell tests agree")
    else:
        print(value.decode(), end="")


if __name__ == "__main__":
    main()

