"""R788. Coarse price settlement on actual two-arm cubes and the cited source model."""
import argparse
from fractions import Fraction as F
import json
from pathlib import Path
import platform
import sys
from flint import arb, ctx
from rows788 import model, mu1, total

ctx.prec = 256


def correlated(n, p, q, clone):
    tags, radii, boxes, owners, masses, receipts, intersections, mids, degree, down = model(n, p, q, clone)
    fine = F(1, 64 * n)
    # Product density of rows788 is constant in each microcell. On each adjacent
    # coordinate pair keep just the two equal half-cell signs, doubling density.
    sign_pairs = [(1, 1), (1, -1), (-1, 1), (-1, -1)]
    multipliers = [1 + s * h for s, h in sign_pairs]
    assert sum(multipliers) == 4 and multipliers.count(2) == 2
    assert (F(1, 64) / fine).denominator == 1
    count = 0
    for radius, box in zip(radii, boxes):
        for lo, hi in box:
            mid = (hi + lo) / 2
            assert all((x / fine).denominator == 1 for x in (lo, mid, hi))
            assert mu1(lo, mid) == mu1(mid, hi) == radius
            count += 2
    # Every actual cube and intersection is a union of complete fine cells, so
    # the correlated density has exactly the same true source masses on them.
    total_Q = total(total(arms.values())**2 * receipts[v] / degree[v] for v, arms in down.items())
    double_Q = F(0)
    cross = F(0)
    for v, arms in down.items():
        for u in arms:
            for g in arms:
                assert intersections[v, u] > 0 and intersections[v, g] > 0
                joint = (receipts[v] * receipts[u] * receipts[g] * intersections[v, u]
                         * intersections[v, g] / (degree[v] * masses[v]**2 * masses[u] * masses[g]))
                double_Q += joint
                if u != g:
                    cross += joint
    assert double_Q == total_Q and 0 < cross < double_Q
    # A physical price box decomposes into 2^n independent reference laws.
    # Each coordinate half has normalized density <= (3/2)/radius.
    ell = arb(n + 2).log()
    side_count = int((arb(n).sqrt() * ell**3).ceil().unique_fmpz())
    cap = ell / arb(n).sqrt()
    assert arb(3) / (2 * side_count) < cap
    reference_cost = total(receipts[u] * (2**n) * F(1, 2**n) for u in range(len(boxes)))
    assert reference_cost == sum(receipts)
    return dict(n=n, true_middles=len(mids), checked_one_dimensional_half_masses=count,
                relative_price_support_in_each_fine_cell=str(F(1, 2**(n//2))),
                physical_parents=len(boxes), reference_components=len(boxes) * 2**n,
                scale_blocks=side_count, max_atomic_window_upper=str(F(3, 2*side_count)),
                Y=str(reference_cost), complete_original_Q=str(total_Q),
                different_endpoint_Q=str(cross), captured_Q_over_Q="1",
                cross_endpoint_Q_over_Q=str(cross / total_Q))


def lower_shape(n):
    # One period, R=1. A positive-mass atom of size 1/(K+20) may be anywhere
    # in each 1/K stratum. The continuous density is at most 40/(K+20).
    ell = arb(n+2).log()
    nb = max(48, int(((arb(3*n)/(74*arb(n).log())).sqrt()+arb(1)/2).floor().unique_fmpz())-20)
    m = int((arb(n).sqrt()*ell**3).ceil().unique_fmpz())
    num = (nb + m - 1) // m + 1
    bound = (num + F(40, m)) / (nb + 20)
    cap = ell / arb(n).sqrt()
    cmp = arb(bound.numerator) / bound.denominator
    passes = cmp < cap
    assert passes or cmp > cap
    return dict(n=n, K=nb, one_over_delta=m, maximum_strata_intersected=num,
                mass_upper=str(bound), cap_as_decimal=cap.str(19), passes_sufficient_test=passes)


def ordered_case(k):
    from grid788 import grid, p_at, q_at, q_breaks
    t = F(1)
    b = F(1, 2)
    first, d1 = grid(b, [F(0)] * k)
    phases = [grid(b, [shift] * k) for shift in (F(-1, 2), F(1, 2))]
    second = [x for x, _ in phases]
    b1 = b + 2*d1
    b2 = b + 2*max(d for _, d in phases)

    def pieces(laws, width):
        switch = {t + width, t - width, -t + width, -t - width}
        for law in laws:
            switch.update(q_breaks(t, law))
        points = sorted(switch)
        result = []
        for lo, hi in zip(points, points[1:]):
            x = (lo + hi) / 2
            if any(q_at(x, t, law) for law in laws):
                # Integral of p(x)^(-2) for the affine, positive reference.
                w = (hi-lo)/(p_at(lo,t,width)*p_at(hi,t,width))
                result.append((x, hi-lo, w))
        return result

    xs = pieces([first], b1)
    ys = pieces(second, b2)
    one = total(w*q_at(x,t,first)**3 for x,_,w in xs)
    upper2 = max(total(w*q_at(y,t,row)**3 for y,_,w in ys) for row in second)
    joint = mixed = discrepancy = mass = F(0)
    for x, dx, wx in xs:
        active = [i for i,z in enumerate(first) if abs(x-z)<=t]
        first_out = F(len(active),k)/(2*t)
        for y,dy,wy in ys:
            actual = total(F(abs(x-z)<=t,k)*q_at(y,t,second[i%2])/(2*t)
                           for i,z in enumerate(first))
            post = total(q_at(y,t,second[i%2]) for i in active)/len(active)
            assert actual == first_out*post
            mass += dx*dy*actual
            joint += wx*wy*actual**3
            marginal_y = total(q_at(y,t,second[i%2]) for i in range(k))/k
            discrepancy += dx*dy*abs(actual-first_out*marginal_y)
            mixed += wx*wy*first_out**3*total(q_at(y,t,second[i%2])**3 for i in active)/len(active)
    assert mass==1 and 0<discrepancy and joint<mixed<=one*upper2
    return dict(k=k, cells=len(xs)*len(ys), total_variation_from_product_of_marginals=str(discrepancy/2),
                third_joint_moment=str(joint), conditional_Jensen_upper=str(mixed),
                factorized_moment_upper=str(one*upper2),
                scope="The second reference grid phase depends on the first latent index. Positive rational diagnostics at t=1; the asymptotic perturbation size is not imposed.")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--check", type=Path)
    args = parser.parse_args()
    results = dict(interpreter=sys.executable, python=platform.python_version(), precision_bits=ctx.prec,
                   price_cases=[correlated(8, 2, 1, False), correlated(16, 3, 2, True),
                                correlated(32, 4, 3, True)],
                   ordered_sources=[ordered_case(k) for k in (4,7,11)],
                   stratified_period=[lower_shape(2**k) for k in (8,12,16,24,32,40,64,96,144,256)],
                   scope="Correlated AC price inside microcells, finite physical parents, diagnostic hard edges. The lower-note test concerns only one normalized coordinate period at R=1. No full extremal cut or all-dimensional peak inferred.")
    payload = json.dumps(results, indent=2, sort_keys=True) + "\n"
    if args.check:
        assert args.check.read_text() == payload
        print("PASS settlement788, 3 true correlated prices, 3 ordered references, 10 certified lower-source tests")
    else:
        print(payload, end="")


if __name__ == "__main__":
    main()
