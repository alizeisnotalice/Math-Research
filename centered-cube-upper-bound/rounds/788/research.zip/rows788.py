"""R788: exact whole-row charges from real two-arm cube peaks."""

import argparse
from collections import defaultdict
from fractions import Fraction as F
from itertools import product
import json
from pathlib import Path
import platform
import sys


DELTA, PERIOD, ETA = F(1, 16), F(1, 32), F(1, 8)


def total(xs):
    return sum(xs, F(0))


def product_of(xs):
    result = F(1)
    for x in xs:
        result *= x
    return result


def mu1(lo, hi):
    if hi <= lo:
        return F(0)

    def primitive(x):
        q = x // PERIOD
        r = x - q * PERIOD
        return q * PERIOD + r / 2 + max(F(0), r - PERIOD / 2)

    return primitive(hi) - primitive(lo)


def cube(c, s):
    return tuple((z - s, z + s) for z in c)


def overlap(box1, box2, length):
    return product_of(length(max(a, c), min(b, d))
                      for (a, b), (c, d) in zip(box1, box2))


def volume_bin(m):
    b = m.numerator.bit_length() - m.denominator.bit_length()
    return b - (F(2) ** b > m)


def model(n, p, q, clone):
    # Same real sign cubes and periodic nonuniform AC price as R787 loads.
    tags = [(i,) for i in range(p + q)]
    tags += [(u, p + g) for u, g in product(range(p), range(q))]
    r = [F(1) + F(i, 8) for i in range(p)] + [F(1) + F(g, 16) for g in range(q)]
    r += [F(3, 2) + F((2 * u + g) % 7, 16) for u, g in product(range(p), range(q))]
    if clone:
        tags.append((0, p))
        r.append(F(31, 16))
    c = [tuple((s - DELTA) * (1 if j in tag else -1) if j < p + q else 0
               for j in range(n)) for s, tag in zip(r, tags)]
    a = 32 * n
    A = [cube(x, s) for x, s in zip(c, r)]
    E = [cube(x, s / a) for x, s in zip(c, r)]
    m = [(2 * s) ** n for s in r]
    I = [z / a**n for z in m]
    indices = range(len(m))
    assert all(1 <= s < 2 for s in r)
    assert all(all(lo < 0 < hi for lo, hi in pbox) for pbox in A)
    assert all(overlap(A[i], A[i], mu1) == m[i] for i in indices)
    lb = lambda lo, hi: max(F(0), hi - lo)
    for i, j in product(indices, repeat=2):
        assert overlap(E[i], E[j], lb) == (I[i] if i == j else 0)
    mids = list(range(p + q, len(m)))
    bins = list(map(volume_bin, m))
    J = {(i, j): overlap(A[i], A[j], mu1) for i, j in product(indices, repeat=2)}
    for (i, j), mass in J.items():
        split = len(set(tags[i]) ^ set(tags[j]))
        assert mass == (2 * DELTA)**split * (2 * min(r[i], r[j]))**(n - split)
    K = {(i, j): mass / (m[i] * m[j]) for (i, j), mass in J.items()
         if bins[i] != bins[j] and 0 < mass <= ETA * min(m[i], m[j])}
    degree = {v: total(I[j] * K[v, j] for j in indices if (v, j) in K) for v in mids}
    down = {v: {j: I[j] * K[v, j] for j in indices if (v, j) in K and m[j] < m[v]}
            for v in mids}
    assert all(0 < total(down[v].values()) <= degree[v] for v in mids)
    return tags, r, A, E, m, I, J, mids, degree, down


def price_members(A):
    """Product cell arrangement, with each membership mask collected exactly."""
    members = {(1 << len(A)) - 1: (F(1), ())}
    for axis in range(len(A[0])):
        intervals = [box[axis] for box in A]
        endpoints = sorted({x for pair in intervals for x in pair})
        local = []
        for lo, hi in zip(endpoints, endpoints[1:]):
            mask = sum(1 << i for i, (l, h) in enumerate(intervals) if l <= lo < hi <= h)
            if mask:
                local.append((mask, mu1(lo, hi), (lo + hi) / 2))
        new = {}
        for mask, (mass, point) in members.items():
            for other, length, z in local:
                keep = mask & other
                if keep:
                    old, repr_point = new.get(keep, (F(0), point + (z,)))
                    new[keep] = old + mass * length, repr_point
        members = new
    return members


def weights_for_scheme(count, isolated, soft=False):
    row = [F(3, 4) if u == isolated else F(1, 4) for u in range(count)] if soft else [
        F(u == isolated) for u in range(count)]
    return row, [1 - x for x in row]


def capacities(psi, I, m, N):
    # Largest source load occurs at the common positive-volume central box.
    alpha = [w / (N * z) for w, z in zip(I, m)]
    assert sum(alpha) <= 1 and all(x * z == w / N for x, z, w in zip(alpha, m, I))
    feasible_objective = [total(x * a * z for x, a, z in zip(part, alpha, m))
                          for part in psi]
    # Dual weights equal psi on the per-owner caps; source constraint gets zero.
    upper = [total(x * w / N for x, w in zip(part, I)) for part in psi]
    assert feasible_objective == upper and min(upper) > 0
    assert all(sum(x) == 1 for x in zip(*psi))
    return upper, sum(alpha)


def row_test(v, cost_psi, caps, m, I, d, arms):
    dminus = total(arms.values())
    prefix = I[v] / d[v]
    Q = prefix * dminus**2
    a_j = [total(part[u] * w for u, w in arms.items()) for part in cost_psi]
    assert sum(a_j) == dminus
    Aeff = 1 / total((aj / dminus)**2 / cap for aj, cap in zip(a_j, caps))
    expr = m[v] * I[v] * total(aj**2 / cap for aj, cap in zip(a_j, caps))
    pair_sum = weighted = cross_labels = zero_charge = F(0)
    for (u, x), (g, y) in product(arms.items(), repeat=2):
        raw = prefix * x * y
        pair_sum += raw
        q = total(part[u] * part[g] / cap for part, cap in zip(cost_psi, caps))
        weighted += d[v] * m[v] * raw * q
        if u != g:
            cross_labels += raw
        if not q:
            zero_charge += raw
    assert pair_sum == Q and weighted == expr == Q * d[v] * m[v] / Aeff
    assert cross_labels > 0
    return {"v": v, "d": d[v], "dminus": dminus, "true_volume": m[v],
            "normalized_arm_bins": [aj / dminus for aj in a_j],
            "Aeff": Aeff, "Aeff_over_m": Aeff / m[v], "Q": Q,
            "fee": weighted, "score": d[v] * m[v] / Aeff,
            "different_physical_endpoint_mass": cross_labels,
            "part_disjoint_endpoint_mass": zero_charge}


def threshold_test(rows):
    lo = min(row["score"] for row in rows)
    hi = max(row["score"] for row in rows)
    assert 0 < lo < hi
    threshold = (lo + hi) / 2
    paid_rows = [r for r in rows if r["score"] >= threshold]
    remaining = [r for r in rows if r["score"] < threshold]
    paid = total(r["Q"] for r in paid_rows)
    fee = total(r["fee"] for r in paid_rows)
    remainder = total(r["Q"] for r in remaining)
    invisible_to_same_class = total(r["part_disjoint_endpoint_mass"] for r in paid_rows)
    assert paid > 0 and remainder > 0 and paid <= fee / threshold
    return {"diagnostic_threshold_for_dv_mv_over_Aeff": threshold,
            "paid_centers": [r["v"] for r in paid_rows],
            "remainder_centers": [r["v"] for r in remaining],
            "paid_and_remaining_Q": [paid, remainder],
            "paid_fraction": paid / (paid + remainder),
            "paid_Q_without_a_same_class_witness": invisible_to_same_class,
            "weighted_fee_over_threshold_for_paid_set": fee / threshold}


def actual_observations(cells, m, I, J, mids, degree, down, partitions, cap, N, rows):
    V = total(I)
    observed = F(0)
    fee_by_v = {part: defaultdict(F) for part in partitions}
    pure = defaultdict(F)
    prices_Q = defaultdict(F)
    admissible_max = hidden_max = double_reference = F(0)
    k0 = F(0)
    single = multiple = conflict = None
    k0_formula = ETA * (2 * (1 + F(1, 32 * (N - 2)))**(N - 2) * N)**2
    pure_names = ("isolated_owner_0", "isolated_owner_1")
    a = {name: {v: [total(part[j] * w for j, w in down[v].items()) for part in psi]
                for v in mids} for name, psi in partitions.items()}
    for mask, (source, point) in sorted(cells.items()):
        # True source price, shared by every parent indicated in the actual cell.
        active = [i for i, M in enumerate(m) if mask & (1 << i)]
        for g in active:
            beta = I[g] * source / m[g]  # E_g probe is Lebesgue uniform, of mass 1.
            observed += beta
            possible = [v for v in mids if v in active and g in down[v]]
            if not possible:
                continue
            double_reference += 2 * beta
            # h_i is the true observed d_v m_v-weighted hidden demand divided by beta.
            h = {u: total(I[v] * down[v].get(u, 0) for v in possible)
                 for u in range(len(m))}
            K = max(total(h[u] / m[u] for u in h), max(N * h[u] / I[u] for u in h))
            assert 0 < K <= k0_formula
            k0 = max(k0, K)
            mixture = {}
            for name, psi in partitions.items():
                per_v = {v: I[v] * total(part[g] * aj / cj
                                         for part, aj, cj in zip(psi, a[name][v], cap[name]))
                         for v in possible}
                cell_total = total(per_v.values())
                exact_h = total(part[g] * total(part[u] * z for u, z in h.items()) / cj
                                for part, cj in zip(psi, cap[name]))
                assert cell_total == exact_h <= K
                mixture[name] = per_v
                pure[name] += beta * cell_total
                for v, amount in per_v.items():
                    fee_by_v[name][v] += beta * amount
            for v in possible:
                prices_Q[v] += beta * I[v] * total(down[v].values()) / (m[v] * degree[v])
            amounts = {name: total(mixture[name].values()) for name in pure_names}
            prechosen = max(amounts.values())
            after_hidden = total(max(mixture[name][v] for name in pure_names) for v in possible)
            admissible_max += beta * prechosen
            hidden_max += beta * after_hidden
            event = {"physical_visible_label_g": g, "true_price_representative": point,
                     "mu_mass_of_membership_cells": source, "beta_mass": beta,
                     "possible_centers": possible,
                     "allowed_partition_choose_once_before_center": beta * prechosen,
                     "choose_after_reading_hidden_center": beta * after_hidden}
            if len(possible) == 1 and single is None:
                single = event
            if len(possible) > 1 and multiple is None:
                multiple = event
            if after_hidden > prechosen and conflict is None:
                conflict = event
    assert observed == V and admissible_max <= k0 * observed
    assert all(prices_Q[row["v"]] == row["Q"] for row in rows[pure_names[0]])
    assert all(fee_by_v[name][row["v"]] == row["fee"]
               for name in rows for row in rows[name])
    row_oracle = total(max(rows[name][j]["fee"] for name in pure_names) for j in range(len(mids)))
    assert single and multiple and conflict
    assert row_oracle > max(pure[name] for name in pure_names)
    assert hidden_max > admissible_max
    return {"single_actual_center_at_visible_price": single,
            "multiple_centers_at_actual_visible_price": multiple,
            "strict_misuse_of_hidden_info_witness": conflict,
            "reference_Y_used_once": observed,
            "reference_Y_duplicated_if_both_partitions_are_run": 2 * observed,
            "duplicated_reference_mass_on_positive_rows_only": double_reference,
            "actual_joint_load_K0": k0, "geometry_K0_upper_diagnostic": k0_formula,
            "fixed_partition_fees": pure,
            "best_fixed_partition_fee": max(pure[name] for name in pure_names),
            "best_allowed_partition_of_two_after_only_visible_g_z": admissible_max,
            "row_only_hidden_oracle_fee": row_oracle,
            "after_reading_g_z_and_hidden_center_oracle_fee": hidden_max,
            "extra_fee_from_hidden_center_after_g_z": hidden_max - admissible_max}


def profile(name, n, p, q, clone):
    tags, r, A, E, m, I, J, mids, d, down = model(n, p, q, clone)
    cells = price_members(A)
    for (i, j), mass in J.items():
        mask = (1 << i) | (1 << j)
        assert total(z for bits, (z, point) in cells.items() if bits & mask == mask) == mass
    partitions = {"isolated_owner_0": weights_for_scheme(len(m), 0),
                  "isolated_owner_1": weights_for_scheme(len(m), 1),
                  "weighted_physical_partition": weights_for_scheme(len(m), 0, soft=True)}
    N = n + 2
    cap = {}
    for nm, psi in partitions.items():
        cap[nm], maxload = capacities(psi, I, m, N)
    rows = {nm: [row_test(v, psi, cap[nm], m, I, d, down[v]) for v in mids]
            for nm, psi in partitions.items()}
    assert any(d[v] > total(down[v].values()) for v in mids)
    T = {nm: threshold_test(value) for nm, value in rows.items()}
    assert all(T[nm]["paid_Q_without_a_same_class_witness"] > 0
               for nm in ("isolated_owner_0", "isolated_owner_1"))
    O = actual_observations(cells, m, I, J, mids, d, down, partitions, cap, N, rows)
    Q = total(row["Q"] for row in rows["isolated_owner_0"])
    paid = total(row["Q"] for row in rows["isolated_owner_0"] if row["v"] in T[
        "isolated_owner_0"]["paid_centers"])
    assert paid + T["isolated_owner_0"]["paid_and_remaining_Q"][1] == Q
    return {"case": name, "n": n, "N": N, "middle_labels": mids, "radii": r,
            "geometric_sign_tags": tags, "real_price_membership_cells": len(cells),
            "all_parent_true_mu_and_Leb_m": m, "E_true_disjoint_volumes": I,
            "max_primal_source_load": maxload, "partition_label_weights": partitions,
            "C_N_exact_primal_and_dual": cap, "rows": rows, "diagnostic_partitions": T,
            "raw_Q": Q, "Q_over_Y": Q / O["reference_Y_used_once"],
            "raw_energy_over_Y": {nm: x / O["reference_Y_used_once"]
                                  for nm, x in O["fixed_partition_fees"].items()},
            "original_Q_cross_label_share": total(
                row["different_physical_endpoint_mass"] for row in rows["isolated_owner_0"]) / Q,
            "real_visible_source_budget": O}


def report():
    return {"arithmetic": "fractions.Fraction; zero roundoff",
            "python": {"executable": sys.executable, "version": platform.python_version(),
                       "architecture": platform.machine()},
            "command": "python -B rows788.py --check rows788.json",
            "scope": ("Three finite real cube families in one absolute radius octave. "
                      "Price is product of period-1/32 positive densities 1/2 and 3/2. "
                      "K uses finite hard masks on true masses and different volume bins. "
                      "Original peaks use the full d and all downward neighbours. "
                      "Old observation is the true visible right endpoint and its exact price "
                      "in a constant membership cell, with its actual E probe; no extra path. "
                      "The diagnostic score cut only tests whole-row payment and the finite reference."),
            "parameters": {"eta": ETA, "a": "32*n", "N": "n+2", "M": DELTA},
            "cases": [profile("minimal", 8, 2, 1, False),
                      profile("real_price_and_row_conflict", 16, 3, 2, True),
                      profile("larger_real_owner_family", 32, 4, 3, True)]}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    output = p.add_mutually_exclusive_group()
    output.add_argument("--output", type=Path)
    output.add_argument("--check", type=Path)
    args = p.parse_args()
    value = (json.dumps(report(), sort_keys=True, indent=2, default=str) + "\n").encode()
    if args.output:
        args.output.write_bytes(value)
    elif args.check:
        if args.check.read_bytes() != value:
            raise SystemExit("certificate differs")
        print("rows788: all three real cube families agree exactly")
    else:
        print(value.decode(), end="")


if __name__ == "__main__":
    main()

