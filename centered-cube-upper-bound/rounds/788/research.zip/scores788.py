"""R788: exact trapezoid scale scores and independent-product variation."""

import argparse
from fractions import Fraction as F
from math import comb
import json
from pathlib import Path
import platform
import sys

import flint
from flint import arb, ctx, fmpq


ctx.prec = 256


def ar(q):
    q = F(q)
    return arb(fmpq(q.numerator, q.denominator))


def density(x, t, b):
    x = abs(x)
    if not b:
        return F(x < t, 2) / t
    return max(F(0), min(2 * min(t, b), t + b - x)) / (4 * t * b)


def dot_density(x, t, b):
    """Derivative with respect to log(t) on open smooth pieces, b fixed."""
    x = abs(x)
    if x >= t + b:
        return F(0)
    if x < abs(t - b):
        return -density(x, t, b) if t > b else F(0)
    return (x - b) / (4 * t * b)


def plateau(t, b):
    mass = 1 - min(t, b) / max(t, b)
    return mass, -int(t >= b)


def abs_one_axis(t, b):
    if b == 0:
        return F(2)
    end = min(t, 2 * b)
    return end * (2 * t - end) / (2 * t * b)


def linear_integral(f, breaks):
    # The input function is affine on each specified open interval.
    return sum((hi - lo) * f((lo + hi) / 2) for lo, hi in zip(breaks, breaks[1:]))


def rational_log_bracket(lo, hi):
    lower = upper = F(0)
    while lo < hi:
        z = min(hi, 3 * lo / 2)
        lower += (z - lo) / z
        upper += (z - lo) / lo
        lo = z
    return lower, upper


def truncate(t, b, edge):
    # Discard the edge, putting a zero in place of its score; also test a cap.
    r = 2 * min(t, b)
    assert 0 < edge < min(t, r)
    p0, s0 = plateau(t, b)
    prob = edge**2 / (4 * t * b)
    lost_abs = edge * (2 * t - edge) / (4 * t * b)
    log_width = ar(r / edge).log()
    a, z = rational_log_bracket(edge, r)
    assert ar(a) < log_width < ar(z)
    constant = p0 * s0**2 - (r - edge) / b + (r**2 - edge**2) / (4 * t * b)
    second = ar(t / (2 * b)) * log_width + ar(constant)
    assert ar(t * a / (2 * b) + constant) < second < ar(t * z / (2 * b) + constant)
    cut_mean = -lost_abs
    cut_variance = second - ar(cut_mean**2)
    keep = 1 - prob
    conditioned_var = second / ar(keep) - ar((cut_mean / keep)**2)
    cap = t / edge - 1
    cap_mean = cap * prob - lost_abs
    cap_var = second + ar(cap**2 * prob - cap_mean**2)
    assert cut_variance > 0 and conditioned_var > 0 and cap_var > 0
    assert -cap_mean == edge / (4 * b)
    return dict(edge=edge, dropped_probability=prob, dropped_abs_score=lost_abs,
                retained_nonrenormalized_score_mean=cut_mean, raw_second=second,
                centered_variance=cut_variance, conditioned_variance=conditioned_var,
                conditioned_mean=cut_mean / keep, winsorized_variance=cap_var,
                winsorized_score_mean=cap_mean, rational_log_bounds=[a, z])


def axis_test(name, t, b, level):
    end = t + b
    ends = sorted({F(0), abs(t - b), end, b})
    step = min(t, b) / (16 * t)
    for lo, hi in zip(ends, ends[1:]):
        x = (lo + hi) / 2
        eps = min(step, (hi - lo) / (4 * t))
        plus = density(x, t * (1 + eps), b)
        minus = density(x, t * (1 - eps), b)
        # On each piece p_t(x) has the form c0+c1/t. This identity is exact.
        assert (plus - minus) * (1 - eps**2) / (2 * eps) == dot_density(x, t, b)
        val = density(x, t, b)
        if x < abs(t - b):
            true_score = plateau(t, b)[1]
        else:
            true_score = t / (end - x) - 1
        assert val * true_score == dot_density(x, t, b)
    mass = 2 * linear_integral(lambda x: density(x, t, b), ends)
    mean = 2 * linear_integral(lambda x: dot_density(x, t, b), ends)
    variation = 2 * linear_integral(lambda x: abs(dot_density(x, t, b)), ends)
    assert mass == 1 and mean == 0 and variation == abs_one_axis(t, b)
    left = min(t, b) / level
    tr = truncate(t, b, left)
    tr_edge = [end - left, end]
    assert 2 * linear_integral(lambda x: density(x, t, b), tr_edge) == tr["dropped_probability"]
    assert 2 * linear_integral(lambda x: dot_density(x, t, b), tr_edge) == tr["dropped_abs_score"]
    tails = {}
    for s in (0, 1, 3, 31, 1023):
        cross = min(2 * min(t, b), t / (1 + s))
        true = cross**2 / (4 * t * b)
        assert true == 2 * linear_integral(lambda x: density(x, t, b), [end - cross, end])
        retained = 0 if cross <= left else 2 * linear_integral(
            lambda x: density(x, t, b), [end - cross, end - left])
        assert retained == max(F(0), cross**2 - left**2) / (4 * t * b)
        tails[s] = {"raw_right_tail": true, "edge_dropped_right_tail": retained}
    return dict(name=name, t=t, b=b, plateau_mass_and_score=plateau(t, b),
                mass_integral=mass, score_mean=mean, derivative_L1=variation,
                truncation=tr, exact_score_tails=tails)


def exact_product(n, hard, t, b, name):
    """Exact integration over independent plateau/ramp membership, incl. hard axes."""
    count = n - hard
    if count:
        assert t >= 2 * n * b > 0
        ramp = b / t
        smooth_plateau = 1 - ramp
        ramp_min_score = t / (2 * b) - 1
        # Integral on either slope sign, summed over both sides, of dp/dlog(t).
        ramp_conditional_mean = 2 * linear_integral(
            lambda x: dot_density(x, t, b), [t - b, t + b]) / ramp
    else:
        ramp, smooth_plateau = F(0), F(1)
        ramp_min_score = ramp_conditional_mean = F(0)
    interior_abs = sign_total = normalization = F(0)
    for q in range(count + 1):
        mass = comb(count, q) * ramp**q * smooth_plateau**(count - q)
        lower_score = q * ramp_min_score - (n - q)
        integrated_score = q * ramp_conditional_mean - (n - q)
        if q:
            assert lower_score >= 0 and integrated_score >= 0
            interior_abs += mass * integrated_score
        else:
            interior_abs -= mass * integrated_score
        sign_total += mass * integrated_score
        normalization += mass
    assert sign_total == -hard and normalization == 1
    variation = hard + interior_abs
    naive = 2 * hard + count * abs_one_axis(t, b)
    assert 0 < variation <= naive
    assert variation == 2 * n * smooth_plateau**count
    # Exact finite difference on the unsmoothed coordinates is the volume
    # of the exposed annulus plus the change of constant density on the old cube.
    hard_finite_diff = None
    if hard:
        ratio = F(17, 16)
        old = (2 * t)**hard
        new = (2 * ratio * t)**hard
        hard_finite_diff = old * (1 / old - 1 / new) + (new - old) / new
        assert hard_finite_diff == 2 * (1 - ratio**(-hard))
    return dict(name=name, n=n, hard_unsmoothed_coordinates=hard,
                b=b, t=t, nonnegative_ramp_score_lower_bound=ramp_min_score,
                independent_integrated_sum_score_minus_hard=sign_total,
                absolutely_continuous_interior_L1=interior_abs,
                moving_support_boundary_L1=hard, exact_product_first_variation_L1=variation,
                sum_of_absolute_coordinate_derivatives=naive,
                product_over_coordinate_sum=variation / naive,
                finite_difference_L1_on_hard_coordinates_at_t_new_over_t_17_over_16=hard_finite_diff)


def large_product(n, hard, width):
    count = n - hard
    assert count >= 2
    t, b = F(1), width
    tr = truncate(t, b, min(t, b) / n)
    chance = tr["dropped_probability"]
    union = count * chance
    bad = 1 - (1 - ar(chance))**count
    assert ar(union - comb(count, 2) * chance**2) < bad < ar(union)
    assert union <= F(1, 4 * n)
    centered_second = count * tr["centered_variance"]
    tail_L1 = count * tr["dropped_abs_score"]
    assert 0 < 2 * tail_L1 <= 1
    smooth_L1 = centered_second.sqrt() + ar(2 * tail_L1)
    hard_and_smooth_L1 = 2 * hard + smooth_L1
    crude_independent_bound = 2 * hard + (count * (
        2 + ar(t / (2 * b)) * ar(2 * n).log())).sqrt() + 1
    assert hard_and_smooth_L1 < crude_independent_bound
    naive = 2 * hard + count * abs_one_axis(t, b)
    assert hard_and_smooth_L1 < ar(naive)
    return dict(n=n, b_over_t=width, smooth_axes=count, hard_axes=hard,
                boundary_probability_per_axis_exact=chance,
                any_dropped_boundary_Arb=bad, union_bound=union,
                tail_L1_per_axis_exact=tr["dropped_abs_score"],
                sum_centered_variance_Arb=centered_second,
                upper_L1_from_variance_and_removed_scores_Arb=hard_and_smooth_L1,
                finite_sqrt_log_upper_Arb=crude_independent_bound,
                naive_sum_of_coordinate_L1=naive,
                L1_upper_over_naive_Arb=hard_and_smooth_L1 / ar(naive))


def report():
    return dict(
        arithmetic="Fraction exact; the transcendental results use python-flint Arb with 256-bit precision",
        python={"executable": sys.executable, "version": platform.python_version(),
                "architecture": platform.machine(), "python_flint": flint.__version__},
        command="python -B scores788.py --check scores788.json",
        conventions=("First variation is L1 norm, twice the probability TV convention. "
                     "b is held fixed in the log(t) derivative. At b>0 the raw score has "
                     "infinite second moment; cutoff removes a true boundary strip. "
                     "The exact product cases vary all t together. Hard axes are "
                     "unsmoothed moving supports, separate from the centered smooth scores."),
        scope=("Finite analytic checks and certified intervals on independent reference "
               "products; the input is not the actual conditioned geometry."),
        one_axis=[
            axis_test("trapezoid_t_greater_b", F(1), F(1, 4), 16),
            axis_test("triangle_t_equal_b", F(1), F(1), 16),
            axis_test("trapezoid_t_less_b", F(2, 3), F(5, 4), 16),
            axis_test("extremely_thin_blur", F(1), F(1, 2**20), 64)],
        exact_product=[
            exact_product(2, 0, F(1), F(1, 4), "two_smoothed_axes"),
            exact_product(3, 1, F(1), F(1, 8), "partially_smoothed"),
            exact_product(4, 4, F(1), F(0), "empty_smoothing_set"),
            exact_product(64, 0, F(1), F(1, 2**20), "extremely_thin_all_axes")],
        enlarged=[
            large_product(2**4, 0, F(1, 4)),
            large_product(2**8, 0, F(1, 8)),
            large_product(2**8, 16, F(1, 8)),
            large_product(2**16, 0, F(1, 16))])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    out = parser.add_mutually_exclusive_group()
    out.add_argument("--output", type=Path)
    out.add_argument("--check", type=Path)
    options = parser.parse_args()
    data = (json.dumps(report(), sort_keys=True, indent=2, default=str) + "\n").encode()
    if options.output:
        options.output.write_bytes(data)
    elif options.check:
        if options.check.read_bytes() != data:
            raise SystemExit("certificate differs")
        print("scores788: exact trapezoid, product and interval checks agree")
    else:
        print(data.decode(), end="")


if __name__ == "__main__":
    main()

