# 第485轮：配置几何分离与真实刷新能量的连接

日期2026-10-21。一般根阶一致弱型上界仍未闭合。本轮保持第484轮原场及成功流，不用固定尺度有限模型替代一般证明。新研究重心是：将实际成功族的几何分离与原父刷新算子的累计费用连接，明确哪些信息在父投影时被丢失。

## 1. 原始合同和完整目标

μ=f dx、W=∥f∥₁，f任意非负L¹。a≤R_A≤b≤2a，m_A=μ(Q_A)=q_A R_A^n，q≤q_A≤λ，r=λ/q，σ=q_A dA，ν=tσ，0≤t≤S，R=ν(E)，X=σ(E)。K为第483轮同一实际父刷新核：每一步重抽当前父的原条件记录、人工来源π_A=1_QA μ/m_A和独立mark，保原成功门；不继承上一步旧history。νK≤ν，K1≤1，质量非增，原质量带保持不跨。

原累计占用V=ν∑_{j≥0}K^j，停止率e=1−K1，完整停止R=∫e dV。第484轮窗内Green G及首次退出P给V=ηG，η=ν(I−P)⁻¹；η不是补偿参考注入量ν−νK。目标仍是完整剩余积分的εX加Cε√n log^A(n+2)W，并核清母账所有吸收项。本轮没有付款宽距离、低pe、原初始跳跃、删除、未来被删、极小尺度比等未付项。

## 2. 最大父刷新使实际见证捕获数下降

在第482轮同一成功配置中保留原低Gram族F₀，大小l，选择的父B是族内最大质量者。令
\[
 \gamma_{BC}=\frac{\mu(Q_B\cap Q_C)}{\sqrt{m_Bm_C}},\qquad
 \sum_{C\in F_0\setminus\{B\}}\gamma_{BC}\le\frac12,
 \quad m_C\le m_B.
\]
重新抽来源Z∼π_B是定义中真实的刷新步骤。它不要求来源有界密度。直接计算
\[
 \mathbb E_{\pi_B}\sum_{C\ne B}1_{Q_C}(Z)
 =\sum_{C\ne B}\gamma_{BC}\sqrt{m_C/m_B}\le\frac12. \tag{1}
\]
因此对于l≥2及共同核心C_F⊂∩_{C∈F₀}Q_C，
\[
 p_F:=\pi_B(C_F)\le\frac1{2(l-1)}. \tag{2}
\]
初始人工来源x属于共同核心，刷新Z却只有上述平均捕获。这是任意正L¹来源下的几何估计，非以薄层体积乘密度帽。

更精确地，给定实际输出父B及实际配置F：F只保A、其mark、raw父及其marks，旧pair按第482轮Janossy式积分；不把x或连续统计v_A(x)的数值作为条件标签。保留族与最大父由该配置确定。对这种配置，原来源的条件分布q_F支持C_F。Janossy表示以μ(dx)乘非负可测密度，故在正配置质量上q_F≪π_B；零质量配置不计。若p_F=0，该配置质量亦为零。在q_F有平方可积密度时，Cauchy给
\[
 \int\left(\frac{dq_F}{d\pi_B}\right)^2d\pi_B\ge p_F^{-1}
 \ge2(l-1),\quad
 \chi^2(q_F\Vert\pi_B)\ge2l-3. \tag{3}
\]
平方积分无限时(3)仍是扩展实数不等式，不能据此进行∞−∞相减。原成功门、void、旧pair及配置权都在q_F中，未假设核心内均匀。

## 3. 为什么几何分离尚不能自动转成原核能量

固定正输出父B，令λ_B为该实际输出下配置的条件概率，r(F,z)=dq_F/dπ_B(z)，\bar r(z)=∫r(F,z)λ_B(dF)。在联合平方积分有限时，条件方差精确分解为
\[
 \int\!\int(r(F,z)-1)^2\lambda_B(dF)\pi_B(dz)
 =\int(\bar r(z)-1)^2\pi_B(dz)
 +\int\!\int(r(F,z)-\bar r(z))^2\lambda_B(dF)\pi_B(dz). \tag{4}
\]
右侧第二项是配置与来源的相关，第一项才是配置投影后的来源密度差。式(3)下界的是两项之和。丢弃第二项会使右侧变小，故不能据(3)推第一项同样大的下界。没有假定实际λ_B与来源独立：λ_B×π_B仅是用来定义密度比较的参考。

附件的最大点void能量先在固定来源上做秩条件平均，再做反向指数Volterra，最后按输出父平均。它得到真实累计边界费、秩纤维方差及刷新方差。本节的r是成功配置条件密度，附件的g是输入测试函数的原raw-max伴随像；即使同为“刷新”，也不是同一密度或同一参考。把(3)的几何信息加入附件能量，需要保配置的扩展算子及同一可支付参考测度，或证明被投影掉的相关可由现有正信用控制。这条连接本轮没有证明，不能把新χ²符号称为已付余项。

## 4. 全路径信息和累计费用的保留

几何附件另保初始原旧pair作为永久测试标签，后续原记录仍刷新。借真实质量匹配，一切未来父重新捕获该初始pair的联合费用可按几何级数支付，无需按质量窗深度逐步收费。但这不授权把每次新抽pair都永久化后免费相加。

原始质量归一的未来cube来源列也有收敛界；它支付的是m_{A_j}/m_{A_0}权下的路径访问，不是完整停止。调大T后出现的根阶条件列价，必须同时重算原TNW等费用。未将这一带权结果回代成无权R。

互补附件保原raw最大点void，给一般v的平方能量恒等。用于真实累计occupation密度时可控制累计空点部分，但仍需全部非空停止费；用现有占用上界回代仍不能得到完整根阶价。式(1)–(4)说明下一步应保留什么几何信息，而不是继续仅靠抽象质量跨度。

## 5. 本机精确几何计算

以下三个二维cube族使用完整f=1_{[-2,2]^2}验证(1)–(3)；另以一维f=1_{[-4,4]}和固定B=[−1,1]，等权混合左右两种核心配置，在三个宽度下核(4)的两项，全部为有理算术。一般结论由上述证明给出；这些配置没有Lebesgue接收场及原历史门，不能认证原全流。

```python
from fractions import Fraction as F
from itertools import product
checks=0
for eps in (F(1,20),F(1,30),F(1,40)):
 boxes=[tuple((-eps,F(1)) if s>0 else (-F(1),eps) for s in signs) for signs in product((-1,1),repeat=2)]
 def inter(ids):
  out=F(1)
  for d in range(2):out*=max(F(0),min(boxes[i][d][1] for i in ids)-max(boxes[i][d][0] for i in ids))
  return out
 m=inter([0]);l=len(boxes)
 count=sum(inter([0,j])/m for j in range(1,l));p=inter(range(l))/m
 assert count<=F(1,2);checks+=1
 assert (l-1)*p<=count;checks+=1
 assert p<=F(1,2*(l-1));checks+=1
 assert 1/p-1>=2*l-3;checks+=1
# B=[-1,1], two configurations with another length-2 interval
# centered at +/-(2-eps). Full source f=1_[-4,4]. Each core has length eps.
for eps in (F(1,10),F(1,20),F(1,40)):
 p=eps/2
 joint=1/p-1
 marginal=1/(2*p)-1
 conditional=1/(2*p)
 assert p<=F(1,2);checks+=1
 assert joint==marginal+conditional;checks+=1
 assert marginal>=0 and conditional>0;checks+=1
print(f'PASS {checks} exact geometry and mixture assertions; no original-history or global-budget certification.')
```

## 6. 技能、验证与交付边界

采用64项工具E03跨层预算势的实际到达质量、初始/终端守恒要求，以及L03有理/区间证书的证据分级。未引用一个未经核对的新外部定理，也未套用树Bellman常数到非嵌套cube。指定本机独立Python运行符号、有理和Arb检查；实际范围、版本、输入与重放输出随包。有限parent测度的void实验不等于真实Lebesgue接收核；数值证据与一般恒等式分开。

交付详细LaTeX文本和必要复现，不编译PDF。实际额度数据不可获得，不猜测模型价格。完整上界未闭合，下一步必须解决同一真实配置来源相关与累计停止的连接，不能把以上单项工具当作根阶结论。

主代理已实际隔离重放21项核心几何、30项路径质量、18项符号能量和350项有限数值检查，共419项。指数残差区间含0只核相容性；一般恒等式不由该数值条件证明。
