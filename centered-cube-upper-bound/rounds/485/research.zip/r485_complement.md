# R485：保最大父 void 的累计停止能量及刷新方差

固定 R483 的同一实际父核 \(K\)、参考 \(\nu=t\sigma\)、总质量 \(R=\nu(E)\)。本稿不改变原接受权。得到一条保 void、质量原子和来源刷新的精确累计能量式；它同时显示空样本停止与额外成功筛选的不同价格。现有质量漂移代入仍只给线性维数来源价，尚未证明根阶总预算。

## 1. 实际 joint 测度、增广秩及 raw 核

记原不跨越的质量带为 \(j\)，\(\mu=f\,dx\)。在父—来源—标记空间使用有限测度
\[
\mathfrak m(dA,dx,ds)=\nu(dA)\pi_A(dx)ds
=\mu(dx)\frac{t(A)c_A(x)}{m_A}\sigma(dA)ds.
\tag{1}
\]
给定 \((x,j)\)，右侧的增广中心测度总量为 \(U_j(x)\)。按质量及 uniform mark 排序，其秩 \(u\) 的推前是 \(1_{0<u<U_j(x)}du\)。同质量原子并不只有一个实际中心；给定 \((x,j,u)\) 后，仍按原中心测度作条件分布。

对父函数 \(v\in L^2(\nu)\)，定义真正的秩条件平均
\[
\bar v_{x,j}(u)=\mathbb E_{\mathfrak m}[v(A)\mid x,j,u].
\]
因此
\[
\|v\|_{2,\nu}^2
=\int\mu(dx)\sum_j\int_0^{U_j(x)}|\bar v_{x,j}(u)|^2du
 +\mathcal V_{\rm rank}(v),\quad \mathcal V_{\rm rank}\ge0.
\tag{2}
\]
不能把同原子内不同中心的 \(v\) 当常数而删掉最后一项。

令 \(K_0\) 是只运行原 raw PPP、非空时取最大父、然后刷新当前状态的未筛父核。实际 \(K\le K_0\)。raw 最大父的反向秩算子准确为
\[
g_{x,j}(w)=\frac1T\int_w^{U_j(x)}e^{-(u-w)/T}\bar v_{x,j}(u)\,du.
\tag{3}
\]
把 \(g_{x,j}(u_B(x,s_B))\) 提回实际输出中心空间，再对给定 \(B\) 的 \(x\sim\pi_B,s_B\sim\mathrm{Unif}\) 条件平均，得到
\[
h(B):=(K_0^*v)(B)
=\int\pi_B(dx)\int_0^1g_{x,j(B)}(u_B(x,s))ds.
\tag{4}
\]
这里 \(*\) 始终相对于 \(\nu\)。由(1)换序可直接验证(4)，无需把来源刷新后路径视为固定秩纤维。各步实际 \(K\) 的旧记录门只用于当前新抽出的原记录；没有给输出父移植旧历史。

## 2. void 与两次条件压缩的精确能量

对几乎每个 \((x,j)\)，(3)满足
\[
Tg'=g-\bar v,\qquad g(U_j)=0.
\]
先对有界函数证明，或直接在一维 \(H^1\) 中分部积分，得到
\[
\int_0^{U_j}(\bar v^2-g^2)
=Tg(0)^2+T^2\int_0^{U_j}|g'|^2. \tag{5}
\]
所有项再对 \(\mu\) 积分。输出条件平均的方差为
\[
\mathcal V_{\rm refresh}(v)
=\|g\|_{2,\mathfrak m}^2-\|h\|_{2,\nu}^2
=\int|g-h(B)|^2d\mathfrak m\ge0.
\]
于是对于 \(v\ge0\)，因 \(0\le K^*v\le h\)，有精确恒等式
\[
\boxed{\begin{aligned}
\|v\|_{2,\nu}^2-\|K^*v\|_{2,\nu}^2
={}&\mathcal V_{\rm rank}(v)+\mathcal V_{\rm refresh}(v)
 +T\int\mu(dx)\sum_jg_{x,j}(0)^2\\
&+T^2\int\mu(dx)\sum_j\int_0^{U_j}|g'_{x,j}|^2
 +\mathcal D_{\rm acc}(v),
\end{aligned}}\tag{6}
\]
其中 \(\mathcal D_{\rm acc}(v)=\|h\|_2^2-\|K^*v\|_2^2\ge0\) 保留原全部成功正限制。该项不能在定义 \(K\) 时先放掉、随后又当信用扣除。式(6)不是质量共轭 Schur 界：它直接在无权父测度 \(\nu\) 中保留最大点的指数 void。

## 3. 真实 Green 占用与全部停止分解

令
\[
V=\sum_{i\ge0}(K^*)^i1.
\]
R483 的质量共轭收缩及 \(0<m_-\le m\le m_+<\infty\) 保证此级数在 \(L^2(\nu)\) 收敛；正性给 \(V\ge1\)、\(K^*V=V-1\)。故(6)左端恰为
\[
2\int V\,d\nu-R. \tag{7}
\]
这是真正累计到达，不是 \(\nu-\nu K\) 的注入测度。下面 \(g,h\) 均取输入 \(v=V\)。

raw 空停止概率为
\[
e_0(A)=\int\pi_A(dx)\int_0^1e^{-u_A(x,s)/T}ds.
\]
其累计通量有精确来源表达
\[
R_{\rm empty}:=\int Ve_0\,d\nu
=T\int\mu(dx)\sum_jg_{x,j}(0). \tag{8}
\]
实际额外拒绝通量及总停止则为
\[
R_{\rm reject}=\int V(K_0-K)1\,d\nu
=\int[h-K^*V]d\nu\ge0,
\qquad R=R_{\rm empty}+R_{\rm reject}. \tag{9}
\]
因此空停止不是全部原失败费；高门、短边、no-hit 等均留在第二项。

设 \(W_{\rm bands}=\int\sum_j1_{U_j(x)>0}\mu(dx)\le NW\)。只有采用原先合法构造的单完整质量带时，才可写 \(W_{\rm bands}\le W\)，不能对冻结的多带核默默去掉 \(N\)。Cauchy 及 \((h-K^*V)^2\le h^2-(K^*V)^2\) 给
\[
\boxed{\frac{R_{\rm empty}^2}{TW_{\rm bands}}
 +\frac{R_{\rm reject}^2}{R}
 +\mathcal V_{\rm rank}(V)+\mathcal V_{\rm refresh}(V)
 +T^2\int\sum_j\int|g'|^2d\mu
\le2\int Vd\nu-R.}\tag{10}
\]
零质量情形单列为零。这里没有把两份来源质量相乘，也没有以 \(\sigma\pi^2\) 替换原接受核。

量级仍不足：R483 的分数质量势取 \(p=2rS/T\le1\) 给
\[
\int Vd\nu\le H R,
\qquad H=3+\frac{2rS D_m}{T\log2}.
\]
故仅舍弃非负信用时
\[
R_{\rm empty}^2\le T W_{\rm bands}(2H-1)R.
\tag{11}
\]
当 \(R\le SX\) 时，这确给可核的
\[
R_{\rm empty}\le\eta X+
 \frac{ST(2H-1)}{4\eta}W_{\rm bands}\qquad(\eta>0),
\]
但单带 \(T\asymp\sqrt n\) 仍有 \(T(2H-1)=O(T+rS D_m)=O(n)\)，且没有支付 \(R_{\rm reject}\)。因此(10)是新的累计 void/刷新耗散接口，未构成原 \(R\) 的根阶收据。

## 4. 低 Gram 族为何尚未供给刷新方差下界

对保留的最大父 \(B\) 和低 Gram 族 \(\mathcal F\)，确有
\[
\mathbb E_{z\sim\pi_B}\sum_{C\ne B}c_C(z)
=\sum_{C\ne B}\gamma_{BC}\sqrt{m_C/m_B}\le\tfrac12,
\]
而原人工来源捕获所有族成员。这是配置—来源联合层面的分离。(6)中的 \(\mathcal V_{\rm refresh}\) 却已先积分所有配置，只保固定输出父的来源—标记密度 \(g\)。

即使已另外证明固定父下联合到达对产品参考 \(\Lambda_B(d\mathcal F)\pi_B(dx)\) 有平方可积密度 \(r(\mathcal F,x)\)，也只有
\[
\operatorname{Var}(r)
=\operatorname{Var}(\mathbb E[r\mid x])
 +\mathbb E\operatorname{Var}(r\mid x).
\]
族分离可能处于第二项，不能据此给第一项正下界；完整 raw 到达与成功到达还须另保接受删除。若记录包含确定的连续来源统计，产品绝对连续性本身也不能默认。

因此本机制唯一仍需的实质桥，是用同一实际接受族控制(10)中未抵消的累计占用，同时不把配置—来源相关信用丢在条件压缩中。当前低 Gram 行和、单次列帽和质量方向尚未给出该桥。本稿停止于(6)—(10)的严格累计账，不宣称逐配置方差已经支付混合后的原流。

## 5. 本机核验

指定 Python/SymPy 已实际执行以下脚本，输出：

```text
PASS 18 exact symbolic/rational assertions: void-energy ODE, boundary flux, conditional variances; not original-history simulation.
```

三个多项式来源秩负载核验一般 void 算子的精确能量和边界通量；三个有限数组核验条件方差方向。没有把这些模型称为原生完整历史。解析证明保任意有限原子及真实中心条件纤维。

```python
import sympy as s
u,w=s.symbols('u w', real=True)
checks=0
for U,T,v in [(s.Integer(1),s.Integer(1),1+u),
              (s.Integer(2),s.Integer(1),1+u*u),
              (s.Integer(1),s.Rational(1,2),s.Integer(3))]:
    g=s.integrate(s.exp(-(u-w)/T)*v/T,(u,w,U))
    assert s.simplify(g.subs(w,U))==0; checks+=1
    assert s.simplify(T*s.diff(g,w)-g+v.subs(u,w))==0; checks+=1
    lhs=s.integrate(v*v,(u,0,U))-s.integrate(g*g,(w,0,U))
    rhs=T*g.subs(w,0)**2+T*T*s.integrate(s.diff(g,w)**2,(w,0,U))
    assert s.simplify(lhs-rhs)==0; checks+=1
    flux=s.integrate(v*s.exp(-u/T),(u,0,U))
    assert s.simplify(flux-T*g.subs(w,0))==0; checks+=1
for vals in [[1,2,4,3],[0,5,1,2],[3,3,3,3]]:
    vals=list(map(s.Rational,vals))
    mean=[(vals[0]+vals[1])/2]*2+[(vals[2]+vals[3])/2]*2
    assert sum(v*v for v in vals)-sum(v*v for v in mean)==sum((a-b)**2 for a,b in zip(vals,mean)); checks+=1
    h=sum(mean)/4
    assert sum(v*v for v in mean)-4*h*h==sum((v-h)**2 for v in mean); checks+=1
print(f'PASS {checks} exact symbolic/rational assertions: void-energy ODE, boundary flux, conditional variances; not original-history simulation.')
```
