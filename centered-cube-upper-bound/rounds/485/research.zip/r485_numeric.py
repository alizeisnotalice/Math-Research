from fractions import Fraction as F
from pathlib import Path
import sys,platform,json,time
import sympy as sp
from flint import arb,arb_mat,ctx
ROOT=Path(__file__).resolve().parent;ctx.prec=256
start=time.perf_counter();checks=0

def ck(v):
 global checks
 assert v
 checks+=1

def ar(v):
 if isinstance(v,arb):return v
 v=F(v);return arb(v.numerator)/v.denominator

def dot(nu,v):return sum((ar(nu[i])*v[i] for i in range(len(nu))),arb(0))
def norm2(nu,v):return dot(nu,[z*z for z in v])
# Exact local ODE/primitive identities, with boundary at upper rank.
x,b,T,c,d=sp.symbols('x b T c d',real=True);Tpos=sp.symbols('Tp',positive=True)
g=c+d*sp.exp((x-b)/Tpos)
ck(sp.simplify(Tpos*sp.diff(g,x)-(g-c))==0)
ck(sp.simplify(sp.diff(c*x+d*Tpos*sp.exp((x-b)/Tpos),x)-g)==0)
prim=c*c*x+2*c*d*Tpos*sp.exp((x-b)/Tpos)+d*d*Tpos/2*sp.exp(2*(x-b)/Tpos)
ck(sp.simplify(sp.diff(prim,x)-g*g)==0)

cent=list(map(F,[-1,F(-3,5),F(-1,5),F(1,5),F(3,5),1]));mass=list(map(F,[1,1,F(3,2),F(3,2),2,2]))
def model(N):
 nu=[F(i+1,N*(N+1)//2) for i in range(N)]
 intervals=[(cent[i]-mass[i]/2,cent[i]+mass[i]/2) for i in range(N)]
 for lo,hi in intervals:ck(-4<=lo<hi<=4)
 endpoints=sorted(set(z for pair in intervals for z in pair));cells=[]
 for lo,hi in zip(endpoints,endpoints[1:]):
  mid=(lo+hi)/2;ids=[i for i,(a,b) in enumerate(intervals) if a<mid<b]
  if not ids:continue
  atoms=[];lower=F(0)
  for mm in sorted(set(mass[i] for i in ids)):
   group=[i for i in ids if mass[i]==mm];weights={i:nu[i]/mass[i] for i in group};width=sum(weights.values());upper=lower+width
   atoms.append(dict(ids=group,weights=weights,width=width,lower=lower,upper=upper));lower=upper
  cells.append(dict(lo=lo,hi=hi,length=hi-lo,ids=ids,atoms=atoms,U=lower))
 for i in range(N):ck(sum(cell['length'] for cell in cells if i in cell['ids'])==mass[i])
 ck(sum(nu)==1)
 return dict(N=N,nu=nu,intervals=intervals,cells=cells,Wbands=sum(q['length'] for q in cells))

def evaluate(mod,tt,v,verify=True):
 N=mod['N'];nu=mod['nu'];vv=list(map(ar,v));T=ar(tt)
 normv=norm2(nu,vv);ranknorm=arb(0);rankvar=arb(0);g2=arb(0);boundary=arb(0);derivative=arb(0);h=[arb(0)]*N;stored=[];empty_source=arb(0)
 rational=all(isinstance(z,(F,int)) for z in v);rankexact=F(0)
 for cell in mod['cells']:
  ell=cell['length'];gb=arb(0);local=[]
  for atom in reversed(cell['atoms']):
   width=atom['width'];ids=atom['ids'];coeff={i:atom['weights'][i]/width for i in ids}
   if rational:cex=sum(coeff[i]*v[i] for i in ids);cv=ar(cex);rankexact+=ell*sum(atom['weights'][i]*(v[i]-cex)**2 for i in ids)
   else:cv=sum((ar(coeff[i])*vv[i] for i in ids),arb(0));rankvar+=ar(ell)*sum((ar(atom['weights'][i])*((vv[i]-cv)*(vv[i]-cv)) for i in ids),arb(0))
   ranknorm+=ar(ell*width)*cv*cv
   decay=(-ar(width)/T).exp();dd=gb-cv
   ig=cv*ar(width)+dd*T*(1-decay)
   ig2=cv*cv*ar(width)+2*cv*dd*T*(1-decay)+dd*dd*T/2*(1-decay*decay)
   grad=dd*dd*T/2*(1-decay*decay)
   g2+=ar(ell)*ig2;derivative+=ar(ell)*grad
   for i in ids:h[i]+=ar(ell/(mass[i]*width))*ig
   local.append((atom,ig,ig2));gb=cv+dd*decay
  boundary+=T*ar(ell)*gb*gb;empty_source+=T*ar(ell)*gb
  stored.append((cell,local))
 if rational:rankvar=ar(rankexact)
 nh=norm2(nu,h);refresh=g2-nh
 # Independent conditional variance expression relative each output parent.
 refresh_variance=arb(0)
 for cell,local in stored:
  for atom,ig,ig2 in local:
   for i in atom['ids']:
    refresh_variance+=ar(cell['length']*atom['weights'][i]/atom['width'])*(ig2-2*h[i]*ig+h[i]*h[i]*ar(atom['width']))
 # One explicit positive deletion: reject output to the rightmost parent.
 ha=h[:];ha[-1]=arb(0);deleted=nh-norm2(nu,ha)
 rawgap=normv-nh;actualgap=normv-norm2(nu,ha)
 if verify:
  ck(all(z.is_finite() for z in [normv,ranknorm,rankvar,g2,boundary,derivative,nh,refresh,deleted,rawgap,actualgap]+h))
  ck((normv-ranknorm-rankvar).contains(0));ck((refresh-refresh_variance).contains(0))
  ck((rawgap-rankvar-boundary-derivative-refresh).contains(0))
  ck((actualgap-rankvar-boundary-derivative-refresh-deleted).contains(0))
  ck(boundary>0);ck(derivative>0);ck(refresh>0);ck(deleted>0)
  if rational:
   ck(rankexact>=0)
   if any(v[i]!=v[j] and mass[i]==mass[j] and max(mod['intervals'][i][0],mod['intervals'][j][0])<min(mod['intervals'][i][1],mod['intervals'][j][1]) for i in range(N) for j in range(N)):ck(rankexact>0)
  else:ck(rankvar>0)
 return dict(normv=normv,normh=nh,rankvar=rankvar,boundary=boundary,derivative=derivative,refresh=refresh,deleted=deleted,rawgap=rawgap,actualgap=actualgap,h=h,ha=ha,empty_source=empty_source)

cases=[];models=[];occupation=None
for N in (2,4,6):
 mod=model(N);models.append(dict(N=N,nu=list(map(str,mod['nu'])),parent_intervals=[[str(z) for z in pair] for pair in mod['intervals']],source_cells=[dict(interval=[str(q['lo']),str(q['hi'])],signature=q['ids'],rank_atoms=[dict(parent_ids=a['ids'],lower=str(a['lower']),upper=str(a['upper']),width=str(a['width'])) for a in q['atoms']]) for q in mod['cells']],Wbands=str(mod['Wbands'])))
 for tt in (F(1,4),F(1),F(4)):
  vectors=[('constant',[F(1)]*N),('by_mass',mass[:N]),('unequal_within_ties',[F(1+i%2) for i in range(N)])]
  for name,v in vectors:
   o=evaluate(mod,tt,v)
   cases.append(dict(N=N,T=str(tt),input_name=name,v=list(map(str,v)),norm_v_squared=str(o['normv']),norm_Kraw_adjoint_v_squared=str(o['normh']),V_rank=str(o['rankvar']),boundary_T_g0_squared=str(o['boundary']),derivative_T2_grad_squared=str(o['derivative']),V_refresh=str(o['refresh']),deletion_square_credit=str(o['deleted']),raw_energy_gap=str(o['rawgap']),actual_energy_gap=str(o['actualgap']),refresh_fraction_of_input_norm=str(o['refresh']/o['normv']),rank_fraction_of_input_norm=str(o['rankvar']/o['normv']),Kraw_adjoint_v=list(map(str,o['h'])),deleted_output_parent=N-1,scope='Finite parent measure, true interval cubes/source; not Lebesgue receivers or original success'))
  if N==6 and tt==1:
   # Six unit-basis analytic integrations reconstruct the actual finite raw
   # refreshed adjoint. These are auxiliary operator entries, not new scans.
   cols=[]
   for j in range(N):cols.append(evaluate(mod,tt,[F(int(i==j)) for i in range(N)],False)['h'])
   M=arb_mat([[cols[j][i] for j in range(N)] for i in range(N)])
   Ma=arb_mat([[M[i,j] if i!=N-1 else arb(0) for j in range(N)] for i in range(N)])
   eye=arb_mat([[int(i==j) for j in range(N)] for i in range(N)])
   Vmat=(eye-Ma).inv()*arb_mat([[1] for _ in range(N)]);V=[Vmat[i,0] for i in range(N)]
   for z in V:ck(z>0 and (z>=1 or (z-1).contains(0)))
   act=Ma*Vmat
   for i in range(N):ck(act[i,0]<V[i]/2)
   for i in range(N):ck((act[i,0]-(V[i]-1)).contains(0))
   o=evaluate(mod,tt,V)
   for i in range(N):ck((o['ha'][i]-act[i,0]).contains(0))
   nu=mod['nu'];cum=dot(nu,V);R=ar(sum(nu));left=2*cum-R
   ck((o['actualgap']-left).contains(0))
   # Raw empty probability: parent average of exp(-rank/T).
   e0=[arb(0)]*N
   for cell in mod['cells']:
    for atom in cell['atoms']:
     integ=ar(tt)*((-ar(atom['lower']/tt)).exp()-(-ar(atom['upper']/tt)).exp())
     for i in atom['ids']:e0[i]+=ar(cell['length']/(mass[i]*atom['width']))*integ
   re=dot(nu,[V[i]*e0[i] for i in range(N)]);rj=dot(nu,[o['h'][i]-o['ha'][i] for i in range(N)])
   ck((re-o['empty_source']).contains(0));ck((re+rj-R).contains(0));ck(re>0);ck(rj>0)
   ck(re*re<ar(tt*mod['Wbands'])*o['boundary'])
   lower=re*re/ar(tt*mod['Wbands'])+rj*rj/R+o['rankvar']+o['refresh']+o['derivative']
   ck(lower<left)
   occupation=dict(certified_Lyapunov_contraction='Kactual_adjoint V < V/2 componentwise; proves genuine finite Green convergence',N=N,T=str(tt),Kraw_adjoint=[[str(M[i,j]) for j in range(N)] for i in range(N)],Kactual_adjoint=[[str(Ma[i,j]) for j in range(N)] for i in range(N)],V=list(map(str,V)),cumulative_arrival=str(cum),R=str(R),energy_left_2integralV_minus_R=str(left),empty_total=str(re),reject_total=str(rj),Wbands=str(mod['Wbands']),boundary=str(o['boundary']),derivative=str(o['derivative']),V_rank=str(o['rankvar']),V_refresh=str(o['refresh']),deletion_credit=str(o['deleted']),combined_stopping_energy_lower=str(lower),scope='Finite raw PPP source-refresh operator and artificial rightmost-output deletion only; no original history/geometry success qualification')
result=dict(scope='Exact analytic rank/source-cell integrations on real interval cubes with FINITE parent measure, not Lebesgue receiver fields; finite energy interfaces only.',compute_index=dict(executable=sys.executable,python=platform.python_version(),sympy=sp.__version__,arb_precision_bits=ctx.prec,command='"'+sys.executable+'" r485_numeric.py',seconds=time.perf_counter()-start),checks=checks,geometry=dict(f='1_[-4,4]',W='8',centers=list(map(str,cent)),selected_R_and_complete_mass=list(map(str,mass)),parent_measure='nu_i=(i+1)/(N(N+1)/2), finite atoms, t=1',models=models),cases=cases,occupation=occupation,formula=dict(rank_average='rho_x weighted conditional mean, rho_i=nu_i*c_i/m_i',g='barv+(g_upper-barv)*exp((w-upper)/T) on each rank atom',identity='||v||nu^2-||Kactual* v||nu^2=Vrank+T int g(0)^2+T^2 int |g_prime|^2+Vrefresh+deletion_credit',Vrefresh='int g^2-||E[g|output_parent]||nu^2, also directly integrated conditional variance',actual_deletion='output-parent coordinate projection deleting rightmost parent; artificial positive subkernel, not original success'),exactness='Source interval partitions/rank weights/rank variances rational exact. All rank exponential primitive integrations analytic, validated with256-bit Arb; one finite matrix inverse uses rigorous arb_mat. No quadrature, Monte Carlo or solver.')
(ROOT/'r485_numeric.json').write_text(json.dumps(result,indent=2)+'\n')
print('PASS',checks,'checks;27 finite-parent true-cube energy cases and1 finite occupation certificate; not Lebesgue receivers/history')
