# R485 FINAL PASS（仅限所列几何与累计能量工具）

独立预审先于作者稿，终审核对全部七项冻结输入。PASS 认证最大父的共同核心分离、真实maxvoid/刷新能量恒等式、初始旧双源永久排斥费及质量归一的全路径来源列；不认证这些工具之间尚缺的恢复桥，一般根阶预算未闭合。

最大质量与低Gram行界给π_B(核心)≤1/[2(l−1)]。粗配置不包含人工x或其精确连续秩，Janossy保证实际条件人工来源q_F≪π_B；该来源不是被族排斥的原旧pair。χ²下界与配置混合的条件方差分解合法，但不能丢配置方差后给边缘同样下界；其参考与Volterra测试函数g不同，主稿未强接。

互补稿保质量原子的真实秩条件平均、两次条件压缩方差、void边界、导数与实际删除平方信用。V=Σ(K*)^j1的L²合法性及累计empty/reject分拆正确；H=3+2rS D_m/(Tlog2)、多带W_bands≤NW与Young费用均保留。一次ν费用未被当累计V费用。几何稿只永久保留一份初始旧pair；放首步至raw最大核后的级数给2S a₀²/(1−a₀)X，含最终失败raw族。ω=ν/m的统一列及更优总质量界仍保初始质量归一，不能免费恢复原无权R。原母账和刷新history边界完整保留。

实际独立复现：指定Python、新临时目录，运行三正文内嵌代码及numeric.py，21、30、18、350项均通过，四段stdout与replay逐字一致。numeric JSON仅剔除compute_index.seconds后全字段一致，canonical SHA256为5448d58263efa5b50da12be2c99863ce0210ce32f84b689e0f58d3c00ae0ce50。数值是有限原子parent、真实区间来源与人工输出删除模型，不是Lebesgue receiver或原success/history实例。Arb逆及正Lyapunov收缩给该有限Green的合法性；残差含0只与解析恒等式相容，不单独证明等式。未编译PDF。

冻结输入 SHA256：

- `r485_main.md`: `97f8c975ae074c4930b9372dcb83df20199ada2ff79ccac98962ec691be76902`
- `r485_geometry.md`: `c4f938673ccf6c5ee96663a6f166dcd38053419870668aadb193a1176ace303d`
- `r485_complement.md`: `73e540d8b525cc63a5dd7f80cdd57be56853b8def3a2139b07d7cc559c6cc2cc`
- `r485_numeric.md`: `ae4e146bc0184a85eb84f48f5b70395a141ac97d431da814df6267a496a9c445`
- `r485_numeric.py`: `6d85d94deb85c7ca5f899a4c224836bd099edd77b23f38dc446130d2ded8aaa1`
- `r485_numeric.json`: `0e5badc6219c2905f744dc484c0a7144397d10efa732e448e49b6987add5dbd9`
- `r485_replay.json`: `f735bdbf75e819ecd811bbb98ca20c43afaa94ee4930c97a2b0b7f1d1955b9a4`
