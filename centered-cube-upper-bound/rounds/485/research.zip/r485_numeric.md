# R485：maxvoid能量中rank、边界与refresh费用的有限证书

沿作者已冻结的R485 complement §§1–3接口独立核验，未重做一般证明。实际执行27个必要输入配置：2/4/6 parents×T=1/4,1,4×v=常数、质量函数、同质量不等值；另以6个单位basis解析积分构建一个有限算子、核一个occupation例。最终350项检查通过。

**范围：真实区间cube和完整连续L1来源，但parent测度是有限原子ν，不是Lebesgue receiver场。** 这些模型不认证原高门、实际success或history，也不作为一般预算定理的证明。

## 1. 几何、signature与正确rank均值

f=1_{[−4,4]}，W=8。parents中心为−1,−3/5,−1/5,1/5,3/5,1，R=(1,1,3/2,3/2,2,2)，取前2、4、6。每个完整cube均位于source支撑内，故完整m=R。有限parent权为ν_i=(i+1)/(N(N+1)/2)，总质量1。

来源按全部实际cube端点分割，开段上capture signature严格恒定；所有端点为μ零测。脚本精确核每个parent的signature长度总和等于完整m_A。每个signature内，质量atom的rank宽为Σ_{A同mass,c_A=1}ν_A/m_A，按升mass及uniform mark展开为连续rank区间。

同rank的父值平均按ρ_A=ν_A/m_A加权，不能作等权平均。同质量多个parent的ν不同，因此本模型确实检验了这个区别。三个输入为v_A=1、v_A=m_A、v_A=1+(A mod2)。前2个parent都m=1，故该最小模型的前两输入重合，未称它们为不同方向。

## 2. 解析积分及精确能量式

每个signature/质量atom的rank条件均值为常数c，区间[a,b]宽d。向下积分从g(U)=0开始，若g(b)=g_b，则

g(w)=c+(g_b−c)exp((w−b)/T)，Tg'=g−c。

SymPy核ODE和g、g²的原函数。实际采用

∫g=c d+(g_b−c)T(1−e^{-d/T})，
∫g²=c²d+2c(g_b−c)T(1−e^{-d/T})+(g_b−c)²T(1−e^{-2d/T})/2，
T²∫|g'|²=(g_b−c)²T(1−e^{-2d/T})/2。

全部来源长度/rank条件权为Fraction，指数部分由256-bit Arb严格计算，无数值求积。输出parent B上的h(B)=Kraw* v按实际π_B和uniform s_B平均，即每个rank atom的∫g除以atom宽，再乘来源长度/m_B。

实际核验

||v||ν²−||h||ν²=Vrank+T∫g(0)²dμ+T²∫|g'|²dμ+Vrefresh。

Vrank同时由原norm减rank norm与条件variance计算；有理输入的rank variance本身为精确有理数。Vrefresh同时由∫g²−||h||ν²与对输出parent的独立条件variance表达式计算，两者差的Arb区间含0。所有最终量额外核finite，未将NaN或不定区间当作等式通过。

## 3. 哪些信用确实被激活

常数和mass函数在同mass rank fiber内恒定，Vrank精确0；同mass不等值输入在所有N中Vrank严格正。边界项、导数项及Vrefresh在27配置中均严格正，故这些费用不能从精确等式中省去。

T=1时的若干结果（展示摘要，误差球在JSON）：

| N | 输入 | Vrank | Vrefresh / ||v||ν² |
|---:|---|---:|---:|
| 2 | 常数 | 0 | .03110840 |
| 2 | 同mass不等值 | .13333333 | .03147169 |
| 4 | 常数 | 0 | .01248774 |
| 4 | mass函数 | 0 | .01427118 |
| 4 | 同mass不等值 | .16571429 | .01214484 |
| 6 | 常数 | 0 | .00650053 |
| 6 | mass函数 | 0 | .00756440 |
| 6 | 同mass不等值 | .18280767 | .00628355 |

固定常数输入，T从1/4增至1再至4时，N2的refresh比例为.07122767、.03110840、.00369545；N4为.05571912、.01248774、.00114895；N6为.03867744、.00650053、.00054264。在这些固定配置中，更小T、较集中的小质量parent场给更大refresh信用。但随N同时改变了ν、质量和来源覆盖，不能从这3场推断纯几何的单调定律，更不能从低Gram逐配置分离自动推出混合后的refresh下界。

## 4. 正删除平方信用及一个实际有限occupation

每个输入另核一个明确的正subkernel：删除所有输出到最右parent的raw转移，记Ktest。它只用于测试额外拒绝信用，**不是本项目原success核**。此时(Ktest* v)(B)=h(B)1_{B非最右}，删除平方信用Dacc=ν_最右 h(最右)²严格正，并核

||v||ν²−||Ktest* v||ν²=Vrank+boundary+derivative+Vrefresh+Dacc。

只对N6,T1另外作一个occupation证书：用6个单位输入的同一解析积分重建Kraw*矩阵M，删除最右输出行得Mtest。Arb矩阵逆求V=(I−Mtest)^{-1}1，核残差Mtest V=V−1的区间相容性，严格核V>0及Mtest V<V/2。V≥1另由正核Neumann级数的解析结论得到，不能仅由区间包含1推断。后者给出正Lyapunov权下严格收缩，保证这是真实有限Green和，不只是形式逆。

| 量 | 近似 |
|---|---:|
| ∫Vdν | 1.1422314417 |
| 2∫Vdν−R | 1.2844628834 |
| Rempty | .9672016321 |
| Rreject | .0327983679 |
| Vrank(V) | .0019705726 |
| Vrefresh(V) | .0081338863 |
| boundary | .3262617160 |
| derivative | .9443316433 |
| 删除平方信用 | .0037650653 |

R=1，empty+reject=1；五项能量与左侧的数值包围相容（Arb残差含0）。raw empty概率也独立按每个来源/mark积分exp(−rank/T)得到，并核其累计量等于T∫g(0)dμ。单带实际W_bands为source并集长度7/2，没有误用有限parent个数；核Rempty²≤T W_bands·boundary。

进一步核

Rempty²/(T W_bands)+Rreject²/R+Vrank+Vrefresh+derivative
≈1.2227915486 < 1.2844628834。

这说明边界、秩压缩、来源/mark刷新及额外删除可在同一个明确有限刷新算子中完整记账。它没有给原cube Lebesgue中心场或原成功核的占用上界。

## 5. 复现与误差

命令：

`/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python r485_numeric.py`

实际Python3.12.14、SymPy1.14.0、Arb256-bit；环境和实际用时见JSON compute_index。输入/source partition/rank权及有理rank variance精确；指数原函数和一个有限逆有严格Arb区间，无MC、solver或数值积分。27输入、一个occupation及其6个basis积分均明确列出；350检查含支持/finite/方差/恒等断言，不是350个独立模型。

残差区间含0仅表示与解析恒等式相容，不单独认证残差严格为0；一般恒等式来自作者解析证明和符号计算。正性及严格不等式只在整个Arb球满足相应方向时作为证书。

脚本自含且输出自身目录，stdout固定摘要。归档仅r485_numeric.py、r485_numeric.json、r485_numeric.md。计算已停止。
