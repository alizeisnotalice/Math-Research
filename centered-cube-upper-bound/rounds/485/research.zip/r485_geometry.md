# R485：整条刷新路径的原双来源排斥与跨配置来源列

## 1. 唯一机制与准确输入

保持 R482 原成功长边首步 \(\Omega_0\) 和 R483 父刷新核 \(K\)。\(\nu=t\sigma\)、\(0\le t\le S\)、\(R=\nu(E)\)、\(\sigma=q_A\,dA\)、\(m_A=\mu(Q_A)=q_AR_A^n\)、\(r=\lambda/q\)。原首记录的 \((y,z)\) 密度为 \(\ell(A,y,z)\sigma\pi_A^2\)，\(0\le\ell\le S\)。首步后每个当前父重新抽原条件记录、人工来源和 mark，旧 \(y,z\) 仅作永久辅助标签，**不赋新记录旧历史**。

尝试的机制是把逐步的旧来源排斥升级到整条路径，然后对所有实际 raw 族共同结算来源列。下文得到一次性的整路径小 \(X\) 费用及真实跨配置列界；后者仍带初始质量归一，尚不能支付原无权停止量。

令
\[
 a_0=\frac{rS}{T},\qquad b_0=2a_0<1.
\]
\(S=0\) 单列零流。记 \(J\) 为每个父处 raw PPP 的计数核，\(Q\) 为非空 raw 最大父次概率核。可在每步先完成 raw 实验再应用成功门；不实际需要抽样的失败分支，这只作正上界中的扩展。由原真实中心匹配，
\[
 K\le Q\le J,\qquad
 J(A,dB)\le 1_{m_B\le m_A}\frac{I_{AB}}{Tm_Am_B}\nu(dB),
\quad Jm\le a_0m,
\tag{1}
\]
其中 \(I_{AB}=\mu(Q_A\cap Q_B)\)。\(J\) 是计数核，不能称为概率核。均匀质量 marks 和原不可跨质量带均保留。式 (1) 的质量矩来自
\(\{B:x\in Q_B,m_B\le m_A\}\) 的真实中心体积 \(\le m_A/q\)，不使用 \(f\) 的密度上界。

## 2. 同一旧来源对在全部未来 raw 族中不再被捕获

从 \(\Omega_0\) 首步成功记录出发，设当前父依次为 \(A_0,A_1,\ldots\)，\(\mathcal F_i\) 是在 \(A_i\) 抽出的 raw 族。原 \(y,z\) 不被 \(\mathcal F_0\) 捕获已经是首步实际门。后续 \(\mathcal F_i\) 包括最后一个活父在失败停止前抽出的 raw 配置；不是只统计成功跳。

固定初父 \(A\)，对 \(t(A)>0\)，原旧pair密度相对 \(\pi_A^2\) 不超过 \(S/t(A)\)。为估计第 \(i\ge1\) 个未来 raw 族命中旧pair的事件，仅在正上界中删去**首步全部旧记录成功门**，用 \(Q\) 输出首父；以后仍用真实 \(K\)。这样初始旧pair与该未筛首步及其后刷新过程条件独立。对任意实际族 \(\mathcal F\)，
\[
 \pi_A^2\{y\text{ 或 }z\in\cup_{B\in\mathcal F}Q_B\}
 \le\frac{2}{m_A}\sum_{B\in\mathcal F}m_B.
\tag{2}
\]
由 (1)，第 \(i\) 个未来族的总质量期望满足
\[
 QK^{i-1}Jm(A)\le a_0^{i+1}m_A.
\]
乘原 \(t(A)\sigma(dA)\) 后，\(t(A)\) 与条件密度帽精确相消，得到
\[
 \text{第 }i\text{ 族回捕原旧pair的质量}\le 2S a_0^{i+1}X.
\]
故删除发生任一次未来回捕的整条配置，得到首步流的正限制 \(\Omega_{\rm perm}\)，并有
\[
 \boxed{|\Omega_0|-|\Omega_{\rm perm}|
 \le\frac{2S a_0^2}{1-a_0}X.}
\tag{3}
\]
所有未来 raw 父因而都排斥同一初始旧pair；各成功步的低 Gram 子族当然也如此。这不是对各质量层另收一次费用，且没有遗漏终端失败配置。若希望新增局部费用不超过 \(\eta X\)，充分取
\[
 T\ge rS\max\{2,\,2\sqrt{S/\eta}\}.
\tag{4}
\]
冻结参数未满足时只使用 (3) 的实际常数，不能自动宣布吸收。原首步其它失败费与原母乘数全部保留。

**限制：**(3) 只永久保留一个初始旧pair。不能在每次刷新时把新pair也加入永久标签，然后不计次数地复用 (3)。新记录与旧记录是不同条件抽样。

## 3. 全部层、全部 raw 族的真实来源列

令 \(\omega(dA)=\nu(dA)/m_A\)。R483 的闭尾中心估计同时适用于 raw 计数核，给
\[
 \omega J\le b_0\omega,\qquad \omega K\le b_0\omega.
\tag{5}
\]
其证明保质量原子：对固定 \(x\) 及 \(m_B>0\)，
\[
 \int_{m_A\ge m_B}\frac{t(A)c_A(x)}{m_A^2}\sigma(dA)
 \le\frac{2rS}{m_B};
\]
再在 \(Q_B\) 内积分 \(\mu(dx)\)，即得 (5)。

对初父 \(A\) 的整条实际刷新路径，定义归一化 raw 来源列
\[
 \mathcal C(x)=\int\frac{\nu(dA)}{m_A}
  \mathbb E_A\sum_{i\ge0}\sum_{B\in\mathcal F_i}c_B(x).
\]
非负 Tonelli、真实 \(K\) 与 (5) 给
\[
 \boxed{\mathcal C(x)
 =\left[\omega\sum_{i\ge0}K^iJ\right](c_x)
 \le\frac{b_0}{1-b_0}\,u_t(x)
 \le\frac{b_0S A_n}{1-b_0},}
\tag{6}
\]
\[
 u_t(x)=\int\frac{t(A)c_A(x)}{m_A}\sigma(dA),
 \qquad A_n=1+n\log(b/a).
\]
这是**同一个测试来源 \(x\)** 接收所有父、所有层、所有配置后的点态列界。没有将成功后过程当 raw PPP，也没有给不同层分配独立的 \(W\)。永久排斥事件、原成功标签及任意子族的正限制只降低此列。它不要求测试来源等于任何一步实际抽样所用的人工来源。

积分后有两种合法价格；质量行估计给较好的总量：
\[
 \int\mathcal C\,d\mu
 =\int\frac{\nu(dA)}{m_A}\mathbb E_A
      \sum_{i,B\in\mathcal F_i}m_B
 \le\frac{a_0}{1-a_0}R
 \le\frac{a_0S A_n}{1-a_0}W.
\tag{7}
\]
若实际参数满足 \(T\gtrsim\sqrt n\)，(6)–(7) 确有根阶来源常数。但原其它费用含 \(TNW\)，调整 \(T\) 不能不重新核全部参数；对固定 \(T\)，此价仍是 \(O(A_n/T)W\)。

## 4. 并集恢复尚缺何物

将每条路径的所有 raw cubes 合成 \(U_\gamma\)，则
\[
 \frac{1_{U_\gamma}(x)}{m_{A_0}}\,d\mu(x)
 \le\frac{\sum_{i,B\in\mathcal F_i}c_B(x)}{m_{A_0}}\,d\mu(x).
\]
所以 (6) 同时支付真实路径并集的来源列。但是其期望总质量至多 \(a_0/(1-a_0)\)，而非每条原记录的一单位。若仅依这种分配恢复固定比例 \(\vartheta R\)，放大常数至少须达到 \(\vartheta(1-a_0)/a_0\)；它会抵消 (7) 的小因子。不能把这种上界恢复成下界。

原停止量
\[
 R=\int e\,dV,\qquad V=\nu\sum_{j\ge0}K^j
\]
不带初始 \(m_{A_0}^{-1}\) 归一；按每个到达父的完整 \(\pi_B\) 分配，又会出现 \(m_{A_0}/m_B\) 的恢复权。实际第一人工来源必捕获选中的首父，但它由该抽样选择，不能替换 (6) 中独立的测试来源。逐配置低 Gram 控制族的并集，却没有给不同生成时刻的这项恢复权共同容量。

因此本机制的实际进展是 (3) 的全路径原双来源排斥费，以及 (6) 的统一归一化来源列。**未证的唯一桥**是：在保原成功记录和永久排斥的同一测度下，能否恢复无权停止量而不花 \(a_0^{-1}\) 或 \(m_{A_0}/m_B\)；没有该恢复，(6) 不能作为 \(R\) 的根阶预算。本稿不继续另造抽样或声称目标闭合。

## 5. 实际精确核验

指定 Python `/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python` 已运行以下代码，输出 30 项 PASS。有限模型只核质量矩迭代、共同来源列及独立旧pair并集上界；不认证原生 Lebesgue 接收场、长边或成功历史。一般结论来自 (1)–(7) 的解析证明。

```python
import sympy as s
checks=0
m=s.Matrix([16,4,1]); D=s.diag(*m); nu=s.ones(1,3)
C=s.Matrix([[1,1,1],[1,1,0],[1,0,0]]); source=s.Matrix([1,3,12])
a=s.Rational(1,8);b=2*a
for p in (s.Rational(1,8),s.Rational(1,4),s.Rational(1,3)):
 K=s.Matrix([[0,p,s.Rational(1,16)],[0,0,s.Rational(1,4)],[0,0,0]])
 assert all(v>=0 for v in a*m-K*m);checks+=1
 h=nu*D.inv()
 assert all(v>=0 for v in b*h-h*K);checks+=1
 G=K+K**2
 col=h*G*C;bound=b/(1-b)*h*C
 assert all(v>=0 for v in bound-col);checks+=1
 assert C*source==m;checks+=1
 assert (col*source)[0]==(h*G*m)[0];checks+=1
 assert (h*G*m)[0]<=a/(1-a)*3;checks+=1
 for j in (1,2,3):
  cap=sum((K**j)[i,k]*(2*m[k]/m[i]-(m[k]/m[i])**2)
          for i in range(3) for k in range(i,3))
  assert cap<=2*a**j*3;checks+=1
 assert K**3==s.zeros(3);checks+=1
print(f'PASS {checks} exact mass/column/independent-pair checks; finite kernel diagnostic, not native-history certification.')
```
