"""Exact k-source span counts on both archived four-dimensional R814 histories."""
import argparse
from collections import defaultdict
from concurrent.futures import ProcessPoolExecutor
from fractions import Fraction as F
from functools import lru_cache
from hashlib import sha256
import json
from math import comb, prod
from pathlib import Path
from zipfile import ZipFile

from comb827 import density_parts, intersect_boxes

ZERO = F(0)
ONE = F(1)
PIN = "891d8cbcbd35537e6abc18c938e53b1b4f300327357c24c8d14a51a46ad5e190"
SAMPLE_COUNTS = (2, 3, 5, 9, 17, 33)
RELATIVE_WIDTHS = (F(1, 3), F(1, 8), F(1, 32))


def read_stages(path):
    assert sha256(path.read_bytes()).hexdigest() == PIN
    with ZipFile(path) as archive:
        module = {"__name__": "pinned_fixture"}
        exec(compile(archive.read("comb811.py"), "comb811.py", "exec"), module)
        previous = module["fixture"](*module["FIXTURES"][-1])
        rebuilt = json.loads(archive.read("comb814-rebuilt.json"))["stages"][0]
    return (("original", previous), ("rebuilt", rebuilt))


def as_box(parent):
    return tuple(tuple(map(F, interval)) for interval in parent["box"])


def law(axis, density):
    mass, parts = density_parts(axis, density)
    assert mass > 0
    # Original mixture representation is valid even when component supports overlap.
    intervals = tuple((center - width/2, center + width/2, prob/width)
                      for center, width, prob in parts)
    assert sum(((b-a)*w for a, b, w in intervals), ZERO) == 1
    return mass, intervals


@lru_cache(maxsize=32768)
def interval_share(law_, lo, hi):
    return sum((max(ZERO, min(hi, b)-max(lo, a))*w for a, b, w in law_), ZERO)


def density_at(law_, x):
    return sum((w for a, b, w in law_ if a < x < b), ZERO)


@lru_cache(maxsize=32768)
def average_linears(spec):
    """Beta integral of nonnegative linear factors on [0,1], in Bernstein coordinates."""
    weights = [ONE]
    degree = 0
    for left, right, multiplicity in spec:
        if not multiplicity:
            continue
        if left == 0 and right == 0:
            return ZERO
        factor = [comb(multiplicity, i) * left**(multiplicity-i) * right**i
                  for i in range(multiplicity+1)]
        updated = [ZERO] * (degree+multiplicity+1)
        for j, old in enumerate(weights):
            if old:
                for i, value in enumerate(factor):
                    updated[i+j] += old*value
        degree += multiplicity
        weights = updated
    return sum((v / ((degree+1)*comb(degree, j)) for j, v in enumerate(weights)), ZERO)


@lru_cache(maxsize=32768)
def range_probability(left, right, middle, s, k):
    """Continuous source laws for two original arms and k-2 fresh central draws."""
    law_counts = defaultdict(int)
    for law_, count in ((left, 1), (right, 1), (middle, k-2)):
        if count:
            law_counts[law_] += count
    laws = tuple(law_counts)
    # The minimum is unique almost surely. Once its value is fixed, the
    # other observations must all lie in the interval from the minimum to minimum+s.
    breaks = sorted({x + offset for law_ in laws for a, b, _ in law_
                     for x in (a, b) for offset in (ZERO, -s)})
    no_large_span = ZERO
    for x0, x1 in zip(breaks, breaks[1:]):
        xmid = (x0+x1)/2
        densities = [density_at(law_, xmid) for law_ in laws]
        if not any(densities):
            continue
        endpoints = [(interval_share(law_, x0, x0+s),
                      interval_share(law_, x1, x1+s)) for law_ in laws]
        for i, (law_, density) in enumerate(zip(laws, densities)):
            if density:
                spec = tuple((lo, hi, law_counts[other]-int(i == j))
                             for j, (other, (lo, hi)) in enumerate(zip(laws, endpoints)))
                no_large_span += (x1-x0)*density*law_counts[law_]*average_linears(spec)
    assert 0 <= no_large_span <= 1
    return 1-no_large_span


def poisson_binomial(probs):
    coefficients = [ONE]
    for p in probs:
        nxt = [ZERO] * (len(coefficients)+1)
        for i, old in enumerate(coefficients):
            nxt[i] += (1-p)*old
            nxt[i+1] += p*old
        coefficients = nxt
    assert sum(coefficients) == 1
    return coefficients


def uniform_check():
    uniform = ((ZERO, ONE, ONE),)
    cases = 0
    for k in SAMPLE_COUNTS:
        for width in (F(1, 11), F(2, 5), F(8, 9), ONE):
            expected = 1 - k*width**(k-1) + (k-1)*width**k
            assert range_probability(uniform, uniform, uniform, width, k) == expected
            cases += 1
    # Two translated disjoint unit intervals. The difference has a triangular density.
    shifted = ((F(2), F(3), ONE),)
    for width in (F(1), F(9, 8), F(3, 2), F(2), F(5, 2), F(3)):
        expected = (1-(width-1)**2/2) if width <= 2 else (3-width)**2/2
        assert range_probability(uniform, shifted, uniform, width, 2) == expected
        cases += 1
    print("Independent order-statistic and triangular-geometry checks", cases)


def prepare(stage):
    parent = {item["id"]: item for item in stage["parents"]}
    density = stage["density"]
    rows = []
    for row in stage["roots_cross"]:
        t, u, g = (parent[row[key]] for key in ("t", "u", "g"))
        core = as_box(t)
        left, right = intersect_boxes(core, as_box(u)), intersect_boxes(core, as_box(g))
        laws = tuple(tuple(law(interval, density) for interval in intervals)
                     for intervals in zip(left, right, core))
        mleft, mright, mcentral = (prod(axis[i][0] for axis in laws) for i in range(3))
        assert mleft*mright*F(row["coefficient"]) == F(row["root_mass"])
        assert mcentral > 0
        rows.append((2*F(t["radius"]), F(row["root_mass"]),
                     tuple(tuple(a[1] for a in axis) for axis in laws)))
    total = F(stage["benchmarks"]["cross"]["mother"])
    assert len(rows) == 34 and sum(w for _, w, _ in rows) == total
    return total, rows


def run_job(task):
    name, model, width, owner_factor, k = task
    total, rows = model
    tails = [ZERO]*4
    proof_hash = sha256()
    for side, mass, axes in rows:
        span = (1-width)*owner_factor*side
        probabilities = [range_probability(l, r, m, span, k) for l, r, m in axes]
        distribution = poisson_binomial(probabilities)
        for j in range(1, 5):
            tails[j-1] += mass * sum(distribution[j:]) / total
        proof_hash.update((";".join(map(str, distribution))+"\n").encode("ascii"))
    assert all(ONE >= tails[j] >= tails[j+1] >= 0 for j in range(3))
    return name, width, owner_factor, k, tuple(tails), proof_hash.hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--archive", type=Path, required=True)
    parser.add_argument("--jobs", type=int, default=6)
    args = parser.parse_args()
    assert 1 <= args.jobs <= 12
    uniform_check()
    models = [(name, prepare(stage)) for name, stage in read_stages(args.archive)]
    # Width is the allowed unfilled fraction. Under the actual owner comparison
    # h0=1+1/(32*4). Tests with h0=1 quantify the effect of omitting the owner shift.
    tasks = [(name, model, width, factor, k) for name, model in models
             for width in RELATIVE_WIDTHS for factor in (ONE, F(129, 128))
             for k in SAMPLE_COUNTS]
    cache = {}
    transcript = sha256()
    with ProcessPoolExecutor(max_workers=args.jobs) as pool:
        for name, width, factor, k, tails, cell_digest in pool.map(run_job, tasks):
            cache[name, width, factor, k] = tails
            transcript.update((" ".join(map(str, (name, width, factor, k, *tails, cell_digest)))+"\n").encode())
            if factor != ONE and width in (F(1, 8), F(1, 32)) and k in (3, 9, 33):
                print("REAL_SPAN", name, "gap", width, "owner", factor, "sources", k,
                      "Pr(at least 1,2,3,4 axes)", *(format(float(v), ".10g") for v in tails))
    for name, _ in models:
        for width in RELATIVE_WIDTHS:
            for factor in (ONE, F(129,128)):
                for previous, current in zip(SAMPLE_COUNTS, SAMPLE_COUNTS[1:]):
                    assert all(a <= b for a,b in zip(cache[name,width,factor,previous],
                                                      cache[name,width,factor,current]))
            for k in SAMPLE_COUNTS:
                assert all(a >= b for a,b in zip(cache[name,width,ONE,k],
                                                  cache[name,width,F(129,128),k]))
    print("Same-record rational range results", len(cache), "models x bandwidths x owner factors x source counts;",
          len(cache)*34, "full four-coordinate rows", "joint exact SHA256", transcript.hexdigest())
    print("R814 raw continuous source law is augmented by the central parent law, with all cap claims limited to the analytic hypotheses.")


if __name__ == "__main__":
    main()
