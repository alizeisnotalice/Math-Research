"""Replay R827 against its three immutable source bundles, retaining the original records."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import hashlib
from importlib.metadata import version
from pathlib import Path
import platform
import subprocess
import sys
from tempfile import TemporaryDirectory
from zipfile import ZipFile
import flint


ROOT = Path(__file__).resolve().parent
INPUTS = {
    "814": "891d8cbcbd35537e6abc18c938e53b1b4f300327357c24c8d14a51a46ad5e190",
    "819": "32f2508a5de3216421537fedb5d09011ed65052bb0af7f5eb153e75995a4cd10",
    "823": "49fb22a6274856e4c8d39af4cfb80b10265467bebac89c3ef30a305131a71ebd",
}


def execute(job):
    name, options = job
    result = subprocess.run([sys.executable, "-E", "-B", str(ROOT / name), *options],
                            cwd=ROOT, stdout=subprocess.PIPE, check=True)
    return name, result.stdout


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for number in INPUTS:
        parser.add_argument("--r" + number, type=Path, required=True)
    options = parser.parse_args()
    if not __debug__:
        raise RuntimeError("Enable assertions before running.")
    paths = {number: getattr(options, "r" + number).resolve() for number in INPUTS}
    for number, path in paths.items():
        assert hashlib.sha256(path.read_bytes()).hexdigest() == INPUTS[number]
    print("Python", platform.python_version(), "python-flint", flint.__version__,
          "FLINT", flint.__FLINT_VERSION__, "NumPy", version("numpy"), "SciPy", version("scipy"), flush=True)
    print("Pinned inputs", *INPUTS.items(), flush=True)
    with TemporaryDirectory(prefix="prices-", dir=ROOT) as directory, ZipFile(paths["823"]) as archive:
        file = Path(directory) / "replay823.py"
        module = {"__name__": "pinned_prices", "__file__": str(file)}
        exec(compile(archive.read(file.name), file.name, "exec"), module)
        module["prices"](paths["814"])
    fixture = ["--archive", str(paths["814"])]
    waves = (
        (("ranges827.py", [*fixture, "--jobs", "9"]), ("grid827.py", [])),
        (("tensor827.py", [*fixture, "--jobs", "9"]), ("comb827.py", fixture),
         ("energy827.py", ["--r819", str(paths["819"])]), ("geometry827.py", [])),
    )
    for wave in waves:
        with ThreadPoolExecutor(max_workers=len(wave)) as executor:
            for name, output in executor.map(execute, wave):
                print("\nRUN", name, flush=True)
                sys.stdout.buffer.write(output)
                sys.stdout.buffer.flush()
    print("PASS complete round 827 exact and interval replay")


if __name__ == "__main__":
    main()
