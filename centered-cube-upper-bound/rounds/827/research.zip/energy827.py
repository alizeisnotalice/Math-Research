"""Exact R827 all-scale common-source energy on positive-width inputs.

The two calculations enumerate (generating cell, source pair, receiving cell)
and (receiving cell, generating cell, source intersection), respectively.
No floating-point integration or random sampling is used.
"""

import argparse
from dataclasses import dataclass
from fractions import Fraction as Q
from hashlib import sha256
from io import BytesIO
from itertools import combinations, product
from math import prod
from pathlib import Path
from types import ModuleType
from zipfile import ZipFile


R819_SHA256 = "32f2508a5de3216421537fedb5d09011ed65052bb0af7f5eb153e75995a4cd10"
ENDPOINT_SHA256 = "8b8f1407a5b4732c2dee83180f03565c8398d8b86385967523c43b5c054d9e6a"
DEFAULT_R819 = Path(
    "/Volumes/data/CodexProjects/T/Math-Research-cube-sqrt-20261114/"
    "centered-cube-upper-bound/rounds/819/research.zip"
)


@dataclass(frozen=True)
class Box:
    lo: tuple
    hi: tuple

    @classmethod
    def centered(cls, center, radius):
        return cls(tuple(x - radius for x in center), tuple(x + radius for x in center))

    def volume(self):
        return prod(hi - lo for lo, hi in zip(self.lo, self.hi))

    def subblock(self, fraction):
        assert 0 < fraction <= 1
        first_end = self.lo[0] + fraction * (self.hi[0] - self.lo[0])
        return Box(self.lo, (first_end, *self.hi[1:]))


@dataclass(frozen=True)
class Cell:
    box: Box
    side: Q
    ids: tuple

    @property
    def volume(self):
        return self.box.volume()

    @property
    def price(self):
        return self.side ** len(self.box.lo)


@dataclass(frozen=True)
class Receipt:
    cell: Cell
    mass: Q
    g: Q
    f: Q
    p_mu: tuple
    p_cut: tuple

    @property
    def incidence(self):
        return self.f * self.cell.volume / self.cell.price

    @property
    def energy(self):
        return self.cell.volume * self.f * self.g


def read_r819(path):
    data = path.read_bytes()
    if sha256(data).hexdigest() != R819_SHA256:
        raise ValueError("R819 research.zip SHA-256 differs from the pinned source")
    with ZipFile(BytesIO(data)) as archive:
        code = archive.read("endpoint819.py")
    if sha256(code).hexdigest() != ENDPOINT_SHA256:
        raise ValueError("R819 endpoint819.py SHA-256 differs from the pinned member")
    module = ModuleType("pinned_endpoint819")
    exec(compile(code, str(path) + "/endpoint819.py", "exec"), module.__dict__)
    return module


def gap_vectors(left, right):
    lo = tuple(
        max(0, c - b, a - d)
        for a, b, c, d in zip(left.lo, left.hi, right.lo, right.hi)
    )
    hi = tuple(
        max(abs(a - d), abs(c - b))
        for a, b, c, d in zip(left.lo, left.hi, right.lo, right.hi)
    )
    return lo, hi


def membership(source, receiver, side):
    """1 and 0 mean all or none for every center in the receiving cell."""
    near, far = gap_vectors(source, receiver)
    if max(far) < side / 2:
        return 1
    if max(near) > side / 2:
        return 0
    raise AssertionError("A source face is not separated from the receiving cell")


def captured(source_boxes, receiver, side):
    return tuple(
        i for i, source in enumerate(source_boxes) if membership(source, receiver, side)
    )


def legacy_cells(module, centers, masses, clusters):
    # Reconstruct the original inner cells with boxes of positive source width.
    margin = Q(1, 5000)
    sources = tuple(Box.centered(center, margin / 2) for center in centers)
    for left, right in combinations(clusters, 2):
        for p, q in product(left, right):
            assert max(gap_vectors(sources[p], sources[q])[0]) > 1
    possible_masses = {
        sum(masses[i] for i in picked)
        for cluster in clusters
        for length in range(1, len(cluster) + 1)
        for picked in combinations(cluster, length)
    }
    assert possible_masses <= {module.LAM * side**2 for side in module.ROOTS}
    assert max(possible_masses) < module.LAM * Q(11, 20) ** 2
    assert sum(masses) < module.LAM

    grid = []
    for axis in range(2):
        cuts = sorted(
            {center[axis] + sign * side / 2
             for center, side, sign in product(centers, module.ROOTS, (-1, 1))}
        )
        grid.append(
            [(lo + margin, hi - margin) for lo, hi in zip(cuts, cuts[1:])
             if lo + margin < hi - margin]
        )
    cells = []
    for intervals in product(*grid):
        receiver = Box(tuple(v[0] for v in intervals), tuple(v[1] for v in intervals))
        candidates = []
        for side in module.ROOTS:
            ids = captured(sources, receiver, side)
            if sum(masses[i] for i in ids) == module.LAM * side**2:
                candidates.append(Cell(receiver, side, ids))
        if candidates:
            cells.append(candidates[-1])
    atom_list = [(*center, mass) for center, mass in zip(centers, masses)]
    assert [(c.side, c.ids, c.volume) for c in cells] == module.roots_and_cells(
        atom_list, margin
    )
    # If a larger scale <=1 were strictly successful, round it up to the
    # candidate determined by all blocks it touches. Whole-block membership at
    # that candidate permits iteration until it stabilizes. The candidate
    # would contradict choosing the largest recorded root. Above 1, total
    # source mass is strictly below the threshold volume.
    return sources, tuple(cells)


def four_dimensional_data():
    centers = (
        (Q(0), Q(0), Q(0), Q(0)),
        (Q(1, 20), Q(7, 20), -Q(7, 20), -Q(7, 20)),
        (Q(9, 10), Q(3, 20), Q(1, 4), -Q(1, 5)),
        (-Q(11, 10), -Q(3, 20), Q(1, 5), Q(1, 5)),
        (Q(5), -Q(1, 3), Q(1, 7), Q(1, 9)),
    )
    t_small, t_large = Q(21, 20), Q(5, 4)
    shared = Q(1, 4)
    masses = (Q(1, 10), Q(3, 20), t_small**4 - shared, t_large**4 - shared, Q(1, 8))
    sources = tuple(Box.centered(center, Q(1, 1000)) for center in centers)
    specifications = (
        ((Q(9, 20), Q(1, 50), Q(0), Q(0)), t_small, (0, 1, 2)),
        ((Q(9, 20), -Q(1, 40), Q(1, 50), Q(0)), t_small, (0, 1, 2)),
        ((-Q(21, 40), Q(1, 50), Q(0), Q(0)), t_large, (0, 1, 3)),
        ((-Q(21, 40), -Q(1, 40), -Q(1, 50), Q(0)), t_large, (0, 1, 3)),
    )
    cutoff = Q(3, 2)
    assert sum(masses) < cutoff**4
    cells = []
    for center, side, ids in specifications:
        receiver = Box.centered(center, Q(1, 200))
        assert captured(sources, receiver, side) == ids
        assert captured(sources, receiver, cutoff) == ids
        assert sum(masses[i] for i in ids) == side**4
        # Both exact roots also belong to the height band (1,2] on [1,2].
        if side == t_small:
            assert side**4 < 2
        else:
            assert membership(sources[3], receiver, Q(11, 10)) == 0
            assert shared < 1 and side**4 < 2 * Q(11, 10)**4
        cells.append(Cell(receiver, side, ids))
    # Strict containment at the recorded side gives superlevel points just
    # below it. No additional source can enter before cutoff, and above cutoff
    # the total mass makes strict reentry impossible.
    return sources, masses, tuple(cells)


def check_geometry(sources, cells):
    for group in (sources, [cell.box for cell in cells]):
        assert all(box.volume() > 0 for box in group)
        for left, right in combinations(group, 2):
            assert any(b <= c or d <= a for a, b, c, d in
                       zip(left.lo, left.hi, right.lo, right.hi))


def receipt_data(cells, masses, cut_masses, threshold):
    rows = []
    for cell in cells:
        assert sum(masses[i] for i in cell.ids) == threshold * cell.price
        mass = sum(cut_masses[i] for i in cell.ids)
        assert mass > 0
        g = mass / cell.price
        p_mu = tuple(masses[i] / (threshold * cell.price) if i in cell.ids else Q(0)
                     for i in range(len(masses)))
        p_cut = tuple(cut_masses[i] / mass if i in cell.ids else Q(0)
                      for i in range(len(masses)))
        assert sum(p_mu) == sum(p_cut) == 1 and g <= threshold
        rows.append(Receipt(cell, mass, g, g / (2 * threshold), p_mu, p_cut))
    return tuple(rows)


def exposure_and_far(rows, cut_boxes, b):
    chosen_sides = sorted({r.cell.side for r in rows})
    h = tuple(sum(r.incidence for r in rows if p in r.cell.ids)
              for p in range(len(cut_boxes)))
    far = {}
    for t, (p, q) in product(chosen_sides, product(range(len(cut_boxes)), repeat=2)):
        near_gap, far_gap = gap_vectors(cut_boxes[p], cut_boxes[q])
        lo, hi = sum(near_gap), sum(far_gap)
        assert hi <= b * t or lo > b * t, "near/far splits a positive-width block pair"
        far[t, p, q] = lo > b * t
    return h, far, chosen_sides


def from_generating_cell(rows, masses, h, far):
    size = len(masses)
    pi = [[Q(0)] * size for _ in range(size)]
    ordered = [Q(0), Q(0)]
    symmetric = [Q(0), Q(0)]
    original = [Q(0), Q(0)]
    reverse_leak = Q(0)
    triples = 0
    for y in rows:
        for p, q in product(y.cell.ids, repeat=2):
            kind = int(far[y.cell.side, p, q])
            raw = y.energy * y.p_cut[p] * y.p_cut[q]
            original[kind] += raw
            assert max(h[p], h[q]) > 0
            weight = raw / max(h[p], h[q])
            pi[p][q] += weight
            inner_incidence = Q(0)
            for x in rows:
                if p not in x.cell.ids or q not in x.cell.ids:
                    continue
                triples += 1
                amount = weight * x.incidence
                symmetric[kind] += amount * y.mass / max(x.mass, y.mass)
                if x.cell.side <= y.cell.side:
                    inner_incidence += x.incidence
                    ordered[kind] += amount
                    if kind:
                        assert far[x.cell.side, p, q]
                elif kind and not far[x.cell.side, p, q]:
                    reverse_leak += amount
            assert inner_incidence <= min(h[p], h[q])
    return pi, tuple(ordered), tuple(symmetric), tuple(original), reverse_leak, triples


def from_receiving_intersections(rows, masses, h, far):
    size = len(masses)
    pi = [[Q(0)] * size for _ in range(size)]
    h_check = [Q(0)] * size
    for p, q in product(range(size), repeat=2):
        if p == q:
            h_check[p] = sum(r.incidence for r in rows if p in r.cell.ids)
        if max(h[p], h[q]) > 0:
            pi[p][q] = masses[p] * masses[q] / max(h[p], h[q]) * sum(
                r.incidence / r.mass for r in rows
                if p in r.cell.ids and q in r.cell.ids
            )
    assert tuple(h_check) == h

    ordered = [Q(0), Q(0)]
    symmetric = [Q(0), Q(0)]
    pairs_equal_mass = 0
    pairs_inverse_mass = 0
    for x, y in product(rows, repeat=2):
        common = set(x.cell.ids).intersection(y.cell.ids)
        if not common:
            continue
        if x.cell.side < y.cell.side:
            pairs_equal_mass += x.mass == y.mass
            pairs_inverse_mass += x.mass > y.mass
        tensor = [Q(0), Q(0)]
        for p, q in product(common, repeat=2):
            tensor[far[y.cell.side, p, q]] += masses[p] * masses[q] / max(h[p], h[q])
        area = x.incidence * y.incidence
        for kind, mass in enumerate(tensor):
            symmetric[kind] += area * mass / max(x.mass, y.mass)
            if x.cell.side <= y.cell.side:
                ordered[kind] += area * mass / y.mass
    return pi, tuple(ordered), tuple(symmetric), pairs_equal_mass, pairs_inverse_mass


def far_receiving_budget(rows, sources, far, sides, pi):
    actual, geometric = Q(0), Q(0)
    for p, q in product(range(len(sources)), repeat=2):
        target = sum(r.cell.volume / r.cell.price for r in rows
                     if p in r.cell.ids and q in r.cell.ids and far[r.cell.side, p, q])
        times = [t for t in sides if far[t, p, q]]
        if not times:
            assert target == 0
            continue
        low_gaps = gap_vectors(sources[p], sources[q])[0]
        volumes = [prod(max(0, t - d) for d in low_gaps) for t in times]
        powers = [t ** (-len(low_gaps)) for t in times]
        # Abel summation has nonnegative coefficients in the shell volumes.
        # Coordinate gap lower bounds therefore safely enclose every true pair
        # in these positive-width blocks, with no need to choose its midpoint.
        cap = powers[-1] * volumes[-1] + sum(
            (powers[k] - powers[k + 1]) * volumes[k] for k in range(len(times) - 1)
        )
        assert target <= cap
        actual += pi[p][q] * target
        geometric += pi[p][q] * cap
    return actual, geometric


def price_bin(price):
    lower = Q(1)
    while price < lower:
        lower /= 2
    while price >= 2 * lower:
        lower *= 2
    return lower


def run(name, source_boxes, masses, fractions, cells, threshold, b):
    cut_boxes = tuple(box.subblock(a) for box, a in zip(source_boxes, fractions))
    cut_masses = tuple(m * a for m, a in zip(masses, fractions))
    check_geometry(source_boxes, cells)
    rows = receipt_data(cells, masses, cut_masses, threshold)
    h, far, sides = exposure_and_far(rows, cut_boxes, b)
    pi, order, sym, original, reverse, triples = from_generating_cell(
        rows, cut_masses, h, far
    )
    pi_2, order_2, sym_2, equal, inverse = from_receiving_intersections(
        rows, cut_masses, h, far
    )
    assert (pi, order, sym) == (pi_2, order_2, sym_2)
    totals = tuple(map(sum, pi))
    columns = tuple(map(sum, zip(*pi)))
    assert totals == columns and all(0 <= a <= b for a, b in zip(totals, cut_masses))
    assert all(load == 0 for load, exposure in zip(totals, h) if exposure == 0)
    assert order[0] <= original[0]
    # Original cut is still the original true P_x on mu, restricted to A.
    original_near = sum(
        threshold * r.cell.volume * r.p_mu[p] * r.p_mu[q] * fractions[p] * fractions[q]
        for r in rows for p, q in product(r.cell.ids, repeat=2)
        if not far[r.cell.side, p, q]
    )
    assert original_near == 2 * original[0]
    far_actual, far_geometry = far_receiving_budget(rows, cut_boxes, far, sides, pi)
    assert order[1] <= far_actual <= far_geometry
    assert sum(sym) <= 2 * sum(order)
    energy = sum(r.energy for r in rows)
    assert energy == sum(original) == sum(m * h_p for m, h_p in zip(cut_masses, h))
    assert threshold * 2 * energy == sum(r.cell.volume * r.g**2 for r in rows)
    if name.startswith("4d-"):
        assert reverse > 0 and h[-1] == 0
    if name == "4d-equal-cut":
        assert equal > 0
    if name == "4d-inverse-cut":
        assert inverse > 0

    bins = sorted({price_bin(r.cell.price) for r in rows})
    assert len(bins) >= 2
    print(
        f"{name} cells={len(rows)} roots={len(sides)} bins={len(bins)} shared_terms={triples}"
        f" zero_h={sum(not a for a in h)} equal_M={equal} inverse_M={inverse}"
        f" pi_total={sum(totals)} pi_max_ratio={max(a / m for a, m in zip(totals, cut_masses))}"
    )
    print(
        f"  Z={energy} C_order={sum(order)} C_sym={sum(sym)}"
        f" C_near={order[0]} C_far={order[1]}"
        f" near_budget={original[0]} far_Leb={far_actual}"
        f" far_geom={far_geometry} reverse_leak={reverse}"
    )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--r819", type=Path, default=DEFAULT_R819, help="pinned R819 zip")
    args = parser.parse_args()
    module = read_r819(args.r819)
    print(f"R819 sha256={R819_SHA256}; exact rational arithmetic")
    legacy = (
        ("r819-two-wide", ((Q(0), Q(0)), (Q(3, 20), Q(3, 20))),
         (Q(9), Q(16)), ((0, 1),), (Q(1), Q(1))),
        ("r819-three-wide-cut", ((Q(0), Q(0)), (Q(7, 20), Q(1, 20)), (Q(3), Q(0))),
         (Q(9), Q(16), Q(9)), ((0, 1), (2,)), (Q(3, 4), Q(1, 3), Q(2, 3))),
    )
    for name, centers, masses, clusters, fractions in legacy:
        sources, cells = legacy_cells(module, centers, masses, clusters)
        run(name, sources, masses, fractions, cells, module.LAM, Q(1, 2))

    sources, masses, cells = four_dimensional_data()
    for name, fractions in (
        ("4d-equal-cut", (Q(1), Q(1), Q(1, 2), masses[2] / (2 * masses[3]), Q(1))),
        ("4d-inverse-cut", (Q(1), Q(1), Q(1), masses[2] / (4 * masses[3]), Q(1))),
    ):
        run(name, sources, masses, fractions, cells, Q(1), Q(1))
    print("PASS: both orders, true marginals, near/far budgets and nonzero order reversal.")


if __name__ == "__main__":
    main()
