"""Check the near-face budget on actual tensor products of R814 source laws."""
import argparse
from concurrent.futures import ProcessPoolExecutor
from fractions import Fraction as F
from hashlib import sha256
from math import isqrt
from pathlib import Path
from flint import arb, ctx

from ranges827 import prepare, range_probability, read_stages

DIMS = (32, 128, 512, 2048, 8192, 2**15, 2**17, 2**19, 2**22, 2**26, 2**30)
COUNTS = (3, 9, 33)
GAPS = (1, 4)


def ar(x):
    return arb(x.numerator) / x.denominator


def lower_decimal(x, grid=10**12):
    return max(0, int((x*grid).lower().floor().unique_fmpz()))


def upper_decimal(x, grid=10**12):
    if x.upper() >= 1:
        return grid
    return min(grid, int((x*grid).upper().ceil().unique_fmpz()))


def axis_binomial(p, reps, cutoff):
    # Only compute coefficients of degrees 0,...,cutoff-1. The complement
    # is a rigorous interval. A Chernoff bound below controls cancellation in tiny upper tails.
    if p == 1:
        return [arb(int(i == reps)) for i in range(cutoff)]
    if p == 0:
        return [arb(1)] + [arb(0)]*(cutoff-1)
    pp = ar(p)
    qq = ar(1-p)
    result = [qq**reps]
    for j in range(1, cutoff):
        result.append(result[-1]*(reps-j+1)*pp/(j*qq) if j <= reps else arb(0))
    return result


def tail_bound(probs, reps, cutoff):
    old = [arb(1)] + [arb(0)]*(cutoff-1)
    for p in probs:
        axis = axis_binomial(p, reps, cutoff)
        old = [sum((old[j]*axis[i-j] for j in range(i+1)), arb(0)) for i in range(cutoff)]
    probability = arb(1)-sum(old, arb(0))
    lower = lower_decimal(probability)
    upper = upper_decimal(probability)
    # All candidates are positive and deterministic. The bound uses the generating
    # function of this exact four-type sum; no normal approximation is involved.
    for tilt in (F(3,2), F(2), F(4), F(8)):
        u = arb(1) / ar(tilt)**cutoff
        for p in probs:
            u *= ar(1+(tilt-1)*p)**reps
        upper = min(upper, upper_decimal(u))
    assert 0 <= lower <= upper <= 10**12
    return lower, upper


def large_tail(probs, reps, cutoff):
    # A multiplicative generating-function bound on both sides requires only O(1)
    # work in the dimension, and remains rigorous in the transition region.
    expectation = reps * sum(probs, F(0))
    if not expectation:
        return 0, 0
    lower, upper = 0, 10**12
    tilts = {F(1,4), F(1,2), F(2,3), F(3,4), F(7,8), F(15,16),
             F(17,16), F(9,8), F(5,4), F(3,2), F(2), F(4),
             F(cutoff)/expectation, F(cutoff-1)/expectation}
    for tilt in tilts:
        if tilt == 1 or tilt <= 0:
            continue
        degree = cutoff if tilt > 1 else cutoff-1
        value = ar(tilt)**(-degree)
        for prob in probs:
            value *= ar(1+(tilt-1)*prob)**reps
        if tilt > 1:
            upper = min(upper, upper_decimal(value))
        else:
            lower = max(lower, 10**12-upper_decimal(value))
    return lower, upper


def run_job(task):
    name, (total, rows), n, k, gap = task
    reps = n//4
    m = isqrt(n)
    scales = (F(1)+F(1,32*n))*(1-F(gap,n))
    weights = []
    for side, mass, axes in rows:
        ps = tuple(range_probability(l,r,mid,side*scales,k) for l,r,mid in axes)
        weights.append((mass/total, ps))
    out = []
    for bits in (192, 320):
        ctx.prec = bits
        bound = tail_bound if n <= 8192 else large_tail
        table = [bound(ps, reps, m) for wt, ps in weights]
        lower = sum(wt*l for (wt,_), (l,_) in zip(weights, table))
        upper = sum(wt*h for (wt,_), (_,h) in zip(weights, table))
        assert 0 <= lower <= upper <= 10**12
        out.append((lower.numerator//lower.denominator,
                    -((-upper.numerator)//upper.denominator)))
    lower, upper = max(lo for lo,hi in out), min(hi for lo,hi in out)
    assert lower <= upper
    if n <= 8192:
        assert upper-lower <= 5
    return name, n, k, gap, lower, upper


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--archive", required=True, type=Path)
    parser.add_argument("--jobs", default=8, type=int)
    args = parser.parse_args()
    assert 1 <= args.jobs <= 12
    models = [(name, prepare(stage)) for name,stage in read_stages(args.archive)]
    tasks = [(name, model, n, k, gap) for name,model in models for n in DIMS
             for k in COUNTS for gap in GAPS]
    transcript = sha256()
    rows = {}
    with ProcessPoolExecutor(max_workers=args.jobs) as pool:
        for name,n,k,gap,lo,hi in pool.map(run_job,tasks):
            rows[name,n,k,gap] = (lo,hi)
            transcript.update((str((name,n,k,gap,lo,hi))+"\n").encode())
            if gap == 1 and (n in (32,512,8192) or n >= 2**15):
                print("TENSOR", name, n, k, "relative gap 1/n", "P interval numerator/1e12", lo, hi)
    for name, _ in models:
        for n in DIMS:
            for gap in GAPS:
                for k1,k2 in zip(COUNTS,COUNTS[1:]):
                    assert rows[name,n,k1,gap][0] <= rows[name,n,k2,gap][1]
            for k in COUNTS:
                assert rows[name,n,k,1][0] <= rows[name,n,k,4][1]
    print("Tensor suites",len(rows), "conditional geometries",len(rows)*34,
          "actual witness parents repeated in 4D blocks; two Arb precisions, common rows weighted as in 4D diagnostic only.")
    print("All interval endpoints SHA256",transcript.hexdigest())


if __name__ == "__main__":
    main()
