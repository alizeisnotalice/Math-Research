"""Preassigned global midpoint couplings on the pinned R814 comb sources.

Sixteen disjoint constant-density physical source cubes are chosen before any
record is read. Each coupling has the same exact actual-mu submarginals, and
is applied unchanged to all 34 central-mother rows. Fixed public smoothing
parameter a=1/4 selects the optimized coupling; the same coupling is then
reported for every a. The owner-uniform central receiver is the explicit R814
fixture law, not an assertion about arbitrary full histories.
"""

import argparse, json, zipfile, hashlib, time
from collections import defaultdict
from fractions import Fraction as F
from functools import lru_cache
from itertools import product
from math import factorial, prod

PIN = "891d8cbcbd35537e6abc18c938e53b1b4f300327357c24c8d14a51a46ad5e190"
AS = (F(1, 32), F(1, 16), F(1, 8), F(1, 4))
CELL_SIDE = F(1, 2048)
CENTERS = tuple(
    tuple(F(s * 5, 4) for s in signs) for signs in product((-1, 1), repeat=4)
)


@lru_cache(None)
def knots(widths):
    terms = {F(0): 1}
    for w in widths:
        new = dict(terms)
        for p, c in terms.items():
            new[p + w] = new.get(p + w, 0) - c
        terms = {p: c for p, c in new.items() if c}
    half = sum(widths, F(0)) / 2
    return tuple(sorted((p - half, c) for p, c in terms.items()))


@lru_cache(None)
def spline(widths, x):
    if 2 * abs(x) >= sum(widths, F(0)):
        return F(0)
    degree = len(widths) - 1
    out = sum((c * (x - p) ** degree for p, c in knots(widths) if p < x), F(0)) / (
        factorial(degree) * prod(widths)
    )
    assert out >= 0
    return out


def verify_spline_recurrence():
    # Independent exact one-box integration via degree-five Newton-Cotes.
    for widths in (
        (F(1), F(1, 8), F(1, 8), F(1, 16), F(1, 4)),
        (F(1), F(1, 8), F(1, 8), F(1, 16), F(1, 4), F(1, 7)),
    ):
        rest, w = widths[:-1], widths[-1]
        for x in (F(0), F(1, 16), F(3, 8), F(1, 2), F(5, 8), F(2)):
            a, b = x - w / 2, x + w / 2
            breaks = sorted({a, b} | {k for k, _ in knots(rest) if a < k < b})
            integral = F(0)
            for lo, hi in zip(breaks, breaks[1:]):
                integral += (
                    (hi - lo)
                    / 90
                    * sum(
                        (
                            q * spline(rest, lo + (hi - lo) * i / 4)
                            for i, q in enumerate((7, 32, 12, 32, 7))
                        ),
                        F(0),
                    )
                )
            assert integral / w == spline(widths, x)
    print("SPLINE exact independent recurrence checks=12")


def hungarian(cost):
    """Exact rational min-assignment and primal/dual certificate."""
    n = len(cost)
    u = [F(0)] * (n + 1)
    v = [F(0)] * (n + 1)
    p = [0] * (n + 1)
    way = [0] * (n + 1)
    for i in range(1, n + 1):
        p[0] = i
        j0 = 0
        minimum = [None] * (n + 1)
        used = [False] * (n + 1)
        while True:
            used[j0] = True
            i0 = p[j0]
            delta = None
            j1 = 0
            for j in range(1, n + 1):
                if used[j]:
                    continue
                cur = cost[i0 - 1][j - 1] - u[i0] - v[j]
                if minimum[j] is None or cur < minimum[j]:
                    minimum[j] = cur
                    way[j] = j0
                if delta is None or minimum[j] < delta:
                    delta = minimum[j]
                    j1 = j
            assert delta is not None
            for j in range(n + 1):
                if used[j]:
                    u[p[j]] += delta
                    v[j] -= delta
                elif j:
                    minimum[j] -= delta
            j0 = j1
            if p[j0] == 0:
                break
        while True:
            j1 = way[j0]
            p[j0] = p[j1]
            j0 = j1
            if not j0:
                break
    assignment = [0] * n
    for j in range(1, n + 1):
        assignment[p[j] - 1] = j - 1
    assert sorted(assignment) == list(range(n))
    assert all(u[i + 1] + v[j + 1] <= cost[i][j] for i in range(n) for j in range(n))
    assert sum((cost[i][assignment[i]] for i in range(n)), F(0)) == sum(
        u[1:], F(0)
    ) + sum(v[1:], F(0))
    return assignment


def brightness(parent, a, left, right, diagonal=False):
    side = 2 * F(parent["radius"])
    out = F(1)
    for axis in range(4):
        lo, hi = map(F, parent["owner"][axis])
        width = hi - lo
        center = (lo + hi) / 2
        diff = center - (left[axis] + right[axis]) / 2
        sourcewidth = (CELL_SIDE,) if diagonal else (CELL_SIDE / 2, CELL_SIDE / 2)
        widths = tuple(sorted((side, side * a, side * a, width) + sourcewidth))
        out *= side * spline(widths, abs(diff))
    assert 0 <= out <= 1
    return out


def intersect_boxes(*boxes):
    return tuple(
        (max(box[j][0] for box in boxes), min(box[j][1] for box in boxes))
        for j in range(4)
    )


def box_volume(box):
    return prod(max(F(0), b - a) for a, b in box)


def owner_average_boxes(parent, a, left, right):
    side = 2 * F(parent["radius"])
    result = F(1)
    for axis in range(4):
        lo, hi = map(F, parent["owner"][axis])
        ow = hi - lo
        oc = (hi + lo) / 2
        l0, l1 = left[axis]
        r0, r1 = right[axis]
        widths = tuple(
            sorted((side, side * a, side * a, ow, (l1 - l0) / 2, (r1 - r0) / 2))
        )
        result *= side * spline(widths, abs(oc - (l0 + l1 + r0 + r1) / 4))
    return result


def density_parts(interval, density):
    lo, hi = interval
    support = tuple(map(F, density["support"]))
    lo = max(lo, support[0])
    hi = min(hi, support[1])
    if lo >= hi:
        return F(0), ()
    period = F(density["period"])
    phase = F(density["bump_center_mod_period"])
    half = F(density["bump_half_width"])
    base = F(density["density_floor_one_axis"])
    peak = F(density["density_peak_one_axis"])
    pieces = [(lo, hi, base)]
    for j in range(lo // period - 1, hi // period + 2):
        a = max(lo, j * period + phase - half)
        b = min(hi, j * period + phase + half)
        if a < b:
            pieces.append((a, b, peak - base))
    total = sum(((b - a) * h for a, b, h in pieces), F(0))
    return total, tuple(((a + b) / 2, b - a, (b - a) * h / total) for a, b, h in pieces)


def row_revealed_brightness(parent, a, left, right, density):
    side = 2 * F(parent["radius"])
    answer = F(1)
    lm = rm = F(1)
    for axis in range(4):
        lo, hi = map(F, parent["owner"][axis])
        ow = hi - lo
        oc = (lo + hi) / 2
        L, lp = density_parts(left[axis], density)
        R, rp = density_parts(right[axis], density)
        assert L > 0 and R > 0
        lm *= L
        rm *= R
        axisvalue = sum(
            (
                pl
                * pr
                * side
                * spline(
                    tuple(sorted((side, side * a, side * a, ow, wl / 2, wr / 2))),
                    abs(oc - (xl + xr) / 2),
                )
                for xl, wl, pl in lp
                for xr, wr, pr in rp
            ),
            F(0),
        )
        answer *= axisvalue
    return answer, lm, rm


def contact_check(name, stage, parents, chosen, selected_mass, interval_mass):
    roots = stage["roots_cross"]
    density = stage["density"]
    M = F(stage["benchmarks"]["cross"]["mother"])
    a = F(1, 4)

    def parentbox(p):
        return tuple(tuple(map(F, x)) for x in p["box"])

    sourceboxes = [
        tuple((x - CELL_SIDE / 2, x + CELL_SIDE / 2) for x in c) for c in CENTERS
    ]
    # The original predetermined reversed assignment and identical submarginals.
    fixed_hit = F(0)
    fixed_k = F(0)
    reveal = F(0)
    for root in roots:
        t, u, g = (parents[root[k]] for k in ("t", "u", "g"))
        Z = intersect_boxes(parentbox(t), parentbox(u))
        Q = intersect_boxes(parentbox(t), parentbox(g))
        rowmass = F(root["root_mass"])
        rh = F(0)
        rk = F(0)
        for i, j in enumerate(chosen):
            l = intersect_boxes(sourceboxes[i], Z)
            r = intersect_boxes(sourceboxes[j], Q)
            lv = box_volume(l)
            rv = box_volume(r)
            if not lv or not rv:
                continue
            fraction = lv * rv / CELL_SIDE**8
            rh += fraction / 16
            rk += fraction * owner_average_boxes(t, a, l, r) / 16
        revealed, cm, cp = row_revealed_brightness(t, a, Z, Q, density)
        assert cm * cp * F(root["coefficient"]) == rowmass
        fixed_hit += rowmass * rh / M
        fixed_k += rowmass * rk / M
        reveal += rowmass * revealed / M
        print(
            "CONTACT_ROW",
            name,
            (root["t"], root["u"], root["g"]),
            "prior_pair_fraction=",
            rh,
            "prior_brightness=",
            rk,
            "row_revealed_brightness~",
            float(revealed),
        )
    print(
        "RESTRICTED_ORIGINAL_PRIOR",
        name,
        "pair_fraction=",
        fixed_hit,
        "library_pair_mass=",
        selected_mass * fixed_hit,
        "actual_restricted_mK_mass=",
        selected_mass * fixed_k,
        "row_revealed_mean~",
        float(reveal),
        "row_revealed_exact=",
        reveal,
    )
    # A second explicitly different, still preassigned global prior, chosen
    # once on public fixture geometry: source boxes near a fixed t0,u0,u1.
    ref = next(r for r in roots if (r["t"], r["u"], r["g"]) == ("t0", "u0", "u1"))
    t, u, g = (parents[ref[k]] for k in ("t", "u", "g"))
    Z = intersect_boxes(parentbox(t), parentbox(u))
    Q = intersect_boxes(parentbox(t), parentbox(g))
    zc = tuple((x + y) / 2 for x, y in Z)
    qc = tuple((x + y) / 2 for x, y in Q)
    separation = max(abs(x - y) for x, y in zip(zc, qc))
    assert separation > 0
    side = min([y - x for x, y in Z + Q] + [separation]) / 8
    assert side > 0
    A = tuple((x - side / 2, x + side / 2) for x in zc)
    B = tuple((x - side / 2, x + side / 2) for x in qc)
    assert box_volume(intersect_boxes(A, B)) == 0

    def lower_density(box):
        period = F(density["period"])
        phase = F(density["bump_center_mod_period"])
        half = F(density["bump_half_width"])
        base = F(density["density_floor_one_axis"])
        peak = F(density["density_peak_one_axis"])
        factors = []
        for lo, hi in box:
            inside = any(
                phase + j * period - half <= lo and hi <= phase + j * period + half
                for j in range(lo // period - 2, hi // period + 3)
            )
            factors.append(peak if inside else base)
        return prod(factors)

    # Subdensity lower bound is valid pointwise in BOTH actual source boxes.
    lowerA, lowerB = lower_density(A), lower_density(B)
    library_mass = min(lowerA, lowerB) * side**4
    sourceA = prod(interval_mass(x, y, F(density["bump_half_width"])) for x, y in A)
    sourceB = prod(interval_mass(x, y, F(density["bump_half_width"])) for x, y in B)
    eu = F(u["owner_volume"])
    eg = F(g["owner_volume"])
    assert 0 < library_mass <= min(sourceA, sourceB, eu, eg)
    # These specific physical seed boxes have genuinely constant densities;
    # this exact identity lets the truncated K integral use uniform boxes.
    assert sourceA == lowerA * side**4 and sourceB == lowerB * side**4
    geom_weight = receiver_weight = F(0)
    restricted_weight = F(0)
    weighted_value = F(0)
    actual_original_subflow = F(0)
    actual_original_subflow_brightness = F(0)
    fixed_receiver_brightness = F(0)
    for root in roots:
        tt, uu, gg = (parents[root[k]] for k in ("t", "u", "g"))
        ZZ = intersect_boxes(parentbox(tt), parentbox(uu))
        QQ = intersect_boxes(parentbox(tt), parentbox(gg))
        aa = intersect_boxes(A, ZZ)
        bb = intersect_boxes(B, QQ)
        frac = box_volume(aa) * box_volume(bb) / side**8
        assert 0 <= frac <= 1
        rowmass = F(root["root_mass"])
        if frac:
            geom_weight += rowmass / M
            restricted_weight += rowmass * frac / M
            weighted_value += rowmass * frac * owner_average_boxes(tt, a, aa, bb) / M
            if root["u"] == "u0" and root["g"] == "u1":
                receiver_weight += rowmass * frac / M
                fixed_receiver_brightness += (
                    rowmass * frac * owner_average_boxes(tt, a, aa, bb) / M
                )
                actual_aa = prod(
                    interval_mass(x, y, F(density["bump_half_width"])) for x, y in aa
                )
                actual_bb = prod(
                    interval_mass(x, y, F(density["bump_half_width"])) for x, y in bb
                )
                actual_original_subflow += (
                    F(root["coefficient"]) * actual_aa * actual_bb
                )
                actual_original_subflow_brightness += (
                    F(root["coefficient"])
                    * actual_aa
                    * actual_bb
                    * owner_average_boxes(tt, a, aa, bb)
                )
    assert geom_weight > 0 and receiver_weight > 0 and restricted_weight > 0
    assert actual_original_subflow > 0 and actual_original_subflow_brightness > 0
    print(
        "FIXED_ALTERNATIVE_SUMMARY",
        name,
        "library_mass~",
        float(library_mass),
        "geom_original_fraction~",
        float(geom_weight),
        "fixed_receiver_geom_fraction~",
        float(receiver_weight),
        "true_original_restricted_fraction~",
        float(actual_original_subflow / M),
        "true_original_restricted_mass=",
        actual_original_subflow,
        "true_original_restricted_fraction_exact=",
        actual_original_subflow / M,
    )
    print(
        "FIXED_RECEIVER_BRIGHTNESS",
        name,
        "preassigned_library_mK_mass=",
        library_mass * fixed_receiver_brightness,
        "actual_original_subflow_mK=",
        actual_original_subflow_brightness,
        "actual_original_conditional_mK=",
        actual_original_subflow_brightness / actual_original_subflow,
        "conditional_approx=",
        float(actual_original_subflow_brightness / actual_original_subflow),
    )
    print(
        "FIXED_ALTERNATIVE",
        name,
        "public_boxes_built_from_fixed_t0_u0_u1",
        "side=",
        side,
        "one_library_mass=",
        library_mass,
        "actual_mu_A=",
        sourceA,
        "actual_mu_B=",
        sourceB,
        "Eu=",
        eu,
        "Eg=",
        eg,
        "geom_hit_original_fraction=",
        geom_weight,
        "mean_pair_capture_fraction=",
        restricted_weight,
        "actual_mK_library_mass=",
        library_mass * weighted_value,
        "fixed_receiver_kernel_geometry_hit_original_fraction=",
        receiver_weight,
        "note=record_support_hit_not_proved_full_payment",
    )


def evaluate(name, stage, interval_mass):
    parent = {p["id"]: p for p in stage["parents"]}
    roots = stage["roots_cross"]
    M = sum((F(r["root_mass"]) for r in roots), F(0))
    assert (
        len(roots) == 34
        and sum(len(r["z_masks"]) * len(r["q_masks"]) for r in roots) == 230
    )
    assert M == F(stage["benchmarks"]["cross"]["mother"])
    tweights = defaultdict(F)
    for r in roots:
        tweights[r["t"]] += F(r["root_mass"]) / M
    assert sum(tweights.values(), F(0)) == 1
    density = stage["density"]
    peak = F(density["density_peak_one_axis"])
    width = F(density["bump_half_width"])
    assert CELL_SIDE / 2 < width
    for center in CENTERS:
        for x in center:
            assert (
                (x - F(density["bump_center_mod_period"])) / F(density["period"])
            ).denominator == 1
    assert all(
        max(abs(x - y) for x, y in zip(a, b)) >= CELL_SIDE
        for i, a in enumerate(CENTERS)
        for b in CENTERS[i + 1 :]
    )
    mass_one = (peak * CELL_SIDE) ** 4
    mass = 16 * mass_one
    total_mu = sum((F(c["mass"]) for c in stage["cells"]), F(0))
    assert total_mu == F(16) ** 4 and 0 < mass < total_mu
    print(
        "\nFIXTURE",
        name,
        "34 physical mothers, 230 positive records",
        "source cubes=",
        len(CENTERS),
        "cube side=",
        CELL_SIDE,
        "density peak=",
        peak,
        "mass per cube=",
        mass_one,
        "total selected mass=",
        mass,
        "remaining actual mu=",
        total_mu - mass,
        "mother t probabilities=",
        {t: str(p) for t, p in tweights.items()},
    )
    # Each matrix entry is averaged over the real owner of each t and then
    # over the *unconditional original t marginal*. No current row read.
    matrices = {}
    diagonal = {}
    for a in AS:
        matrix = []
        for x in CENTERS:
            matrix.append(
                [
                    sum(
                        (
                            w * brightness(parent[t], a, x, y)
                            for t, w in tweights.items()
                        ),
                        F(0),
                    )
                    for y in CENTERS
                ]
            )
        matrices[a] = matrix
        diagonal[a] = sum(
            (
                w
                * sum((brightness(parent[t], a, x, x, True) for x in CENTERS), F(0))
                / 16
                for t, w in tweights.items()
            ),
            F(0),
        )
    chosen = hungarian([[-x for x in row] for row in matrices[F(1, 4)]])
    print(
        "PUBLIC_OPT a=1/4 exact Hungarian dual verified; common permutation=",
        chosen,
        "no current t,u,g,z,q read",
    )
    print(
        "CAPACITY for each physical cube: mu=",
        mass_one,
        "both left and right allocated exactly=",
        mass_one,
        "unused elsewhere=",
        total_mu - mass,
    )
    for a in AS:
        mat = matrices[a]
        iid = sum((mat[i][j] for i in range(16) for j in range(16)), F(0)) / 256
        assignment = sum((mat[i][chosen[i]] for i in range(16)), F(0)) / 16
        diagonal_value = diagonal[a]
        # Exact objective: total predetermined library mass times brightness.
        print(
            "BRIGHT",
            name,
            "a=",
            a,
            "diagonal=",
            float(diagonal_value),
            "independent=",
            float(iid),
            "fixed_global_opt=",
            float(assignment),
            "opt_gain_vs_independent=",
            float(assignment - iid),
            "actual_library_capture_opt=",
            float(mass * assignment),
            "exact=",
            diagonal_value,
            iid,
            assignment,
            mass * assignment,
        )
    contact_check(name, stage, parent, chosen, mass, interval_mass)
    for t, w in sorted(tweights.items()):
        vals = [
            sum(
                (
                    brightness(parent[t], a, CENTERS[i], CENTERS[chosen[i]])
                    for i in range(16)
                ),
                F(0),
            )
            / 16
            for a in AS
        ]
        print(
            "MOTHER",
            name,
            t,
            "record_weight=",
            w,
            "fixed_pairing_brightness=",
            *[float(v) for v in vals]
        )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--archive", required=True)
    args = parser.parse_args()
    verify_spline_recurrence()
    with zipfile.ZipFile(args.archive) as z:
        # The pin is the archived project artifact checksum from comb826.
        with open(args.archive, "rb") as f:
            assert hashlib.sha256(f.read()).hexdigest() == PIN
        rebuilt = json.loads(z.read("comb814-rebuilt.json"))["stages"][0]
        ns = {"__name__": "archived_comb811"}
        exec(compile(z.read("comb811.py"), "comb811.py", "exec"), ns)
        name, n, h, middle, old = ns["FIXTURES"][-1]
        original = ns["fixture"](name, n, h, middle, old)
        evaluate("original", original, ns["interval_mass"])
        evaluate("rebuilt", rebuilt, ns["interval_mass"])
    print("\nPASS actual source submarginals, deterministic global pairing, exact assignment dual")


if __name__ == "__main__":
    main()
