#!/usr/bin/env python3
"""True-price receiver-cell and sharp-width checks. Only scalar high-n tests."""
from collections import Counter
from concurrent.futures import ProcessPoolExecutor
from fractions import Fraction
from itertools import combinations, product
from math import isqrt, prod
import platform
import sys

import flint
from flint import arb, ctx

F = Fraction
ZERO = F(0)
ONE = F(1)
EPS = F(1, 8)
OMEGAS = (F(1, 8), F(1, 3), F(2, 3))
SIDES = (F(35, 32), F(5, 4), F(7, 5), F(31, 20), F(17, 10), F(37, 20))
CASES = ((2, 4, 3), (3, 5, 5), (4, 6, 7))
SCALAR_DIMS = (96, 160, 10**4, 10**8, 10**64, 10**96, 10**160)


def ar(value):
    return arb(value.numerator) / value.denominator


def convert(value, bits):
    return ar(value) if bits else value


def volume_equal(first, second, bits):
    if bits:
        assert (first - second).contains(0)
    else:
        assert first == second


def exact_order(symbols, multiplier, bits):
    """An endpoint is a+b*g. In interval mode g=(98/97)^(1/n) is irrational."""
    values = [
        (symbol, convert(symbol[0], bits) + convert(symbol[1], bits) * multiplier)
        for symbol in symbols
    ]
    if bits:
        values.sort(key=lambda entry: float(entry[1].mid()))
    else:
        values.sort(key=lambda entry: entry[1])
    positions = {}
    distinct = []
    for symbol, value in values:
        if distinct and not bits and value == distinct[-1]:
            positions[symbol] = len(distinct) - 1
            continue
        if distinct:
            assert value > distinct[-1], (symbol, value, distinct[-1])
        positions[symbol] = len(distinct)
        distinct.append(value)
    return positions, distinct


def fixture(n, atom_count, seed):
    sides = SIDES[:atom_count]
    coordinates, receiver = [], []
    for axis in range(n):
        first = sides[1] / 2 - F(3 + (axis + seed) % 7, 200)
        pos = [-first, first]
        for j in range(2, atom_count):
            offset = F(2 + (j + 2 * axis + seed) % 6, 200 + 50 * j)
            pos.append(sides[j] / 2 - offset)
        assert pos == sorted(pos)
        # Receiver coordinates lie on the negative side of the midpoint.
        # This makes the actual ordered sets of captured atoms prefixes.
        upper = -F((axis * (seed + 1) + seed) % 3, 150)
        lower = upper - F(1, 4)
        if (axis + seed) % 2:
            pos = [-value for value in pos]
            lower, upper = -upper, -lower
        coordinates.append(tuple(pos))
        receiver.append((lower, upper))
    return sides, tuple(coordinates), tuple(receiver)


def make_axis(sides, positions, receiver, multiplier, bits):
    endpoints = [
        [((atom, -side / 2), (atom, side / 2)) for atom in positions]
        for side in sides
    ]
    ends = ((receiver[0], ZERO), (receiver[1], ZERO))
    symbols = set(ends)
    for scale in endpoints:
        for lower, upper in scale:
            symbols.update((lower, upper))
    ranks, values = exact_order(symbols, multiplier, bits)
    block = tuple(ranks[end] for end in ends)
    bounds = [
        [(ranks[lower], ranks[upper]) for lower, upper in scale]
        for scale in endpoints
    ]
    cells = {}
    for j in range(block[0], block[1]):
        signature = tuple(
            sum(1 << i for i, (lo, hi) in enumerate(scale) if lo <= j < hi)
            for scale in bounds
        )
        length = values[j + 1] - values[j]
        cells[signature] = cells.get(signature, convert(ZERO, bits)) + length
    return block, bounds, values, cells


def box_intersection_volume(axes, requirements, bits):
    answer = convert(ONE, bits)
    for receiver, scales, values, _ in axes:
        lo, hi = receiver
        for scale, atoms in requirements:
            for atom in atoms:
                a, b = scales[scale][atom]
                lo, hi = max(lo, a), min(hi, b)
        if lo >= hi:
            return convert(ZERO, bits)
        answer *= values[hi] - values[lo]
    return answer


def check_gate(side, spans, omega, bits):
    eps = convert(EPS, bits)
    value = convert(ONE, bits)
    for span in spans:
        gap = side - convert(span, bits)
        if gap <= 0:
            return convert(ZERO, bits), True
        assert gap > 0
        if gap >= eps * side:
            continue
        assert gap < eps * side
        value *= gap / (eps * side)
    boundary = convert(omega, bits)
    if value <= boundary:
        return value, True
    assert value > boundary
    return value, False


def run_cell(n, atom_count, seed, bits):
    if bits:
        ctx.prec = bits
    multiplier = ((arb(98) / 97).log() / n).exp() if bits else ONE
    sides, coordinates, receiver = fixture(n, atom_count, seed)
    factor_mass = F(98, 97) if bits else ONE
    masses = []
    cumulative = ZERO
    for side in sides:
        new_total = factor_mass * side**n
        masses.append(new_total - cumulative)
        cumulative = new_total
    assert len(set(masses)) == atom_count and min(masses) > 0
    assert cumulative < 2**n

    actual_sides = [convert(side, bits) * multiplier for side in sides]
    axes = [
        make_axis(sides, coordinates[i], receiver[i], multiplier, bits)
        for i in range(n)
    ]
    zeros = convert(ZERO, bits)
    raw_masks = [dict() for _ in sides]
    root_masks = [dict() for _ in sides]
    sample_count = 0
    all_mask = (1 << atom_count) - 1
    for box_cells in product(*(tuple(axis[3].items()) for axis in axes)):
        vol = prod(cell[1] for cell in box_cells)
        masks = [all_mask] * atom_count
        for signature, _ in box_cells:
            masks = [mask & code for mask, code in zip(masks, signature)]
        sample_count += 1
        actual = None
        for j, mask in enumerate(masks):
            assert mask == (1 << mask.bit_count()) - 1
            raw_masks[j][mask] = raw_masks[j].get(mask, zeros) + vol
            if mask.bit_count() >= j + 1:
                actual = j
        if actual is not None:
            mask = masks[actual]
            # Any extra captured atom would validate a strictly later root.
            assert mask == (1 << (actual + 1)) - 1
            root_masks[actual][mask] = root_masks[actual].get(mask, zeros) + vol

    prefix = [tuple(range(j + 1)) for j in range(atom_count)]
    receiver_volume = box_intersection_volume(axes, (), bits)
    stats = Counter(product_cells=sample_count, true_prices=atom_count,
                    used_roots=sum(bool(row) for row in root_masks))
    for size in range(2, min(4, atom_count) + 1):
        for atoms in combinations(range(atom_count), size):
            spans = [max(axis[atom] for atom in atoms) - min(axis[atom] for atom in atoms)
                     for axis in coordinates]
            tuple_mask = sum(1 << atom for atom in atoms)
            raw_direct = []
            per_root = []
            for j in range(atom_count):
                product_lens = box_intersection_volume(axes, ((j, atoms),), bits)
                raw_partition = sum((vol for mask, vol in raw_masks[j].items()
                                     if mask & tuple_mask == tuple_mask), start=zeros)
                volume_equal(product_lens, raw_partition, bits)
                stats['axis_product_checks'] += 1
                if product_lens > 0 and product_lens < receiver_volume:
                    stats['partly_cut_lenses'] += 1
                raw_direct.append(product_lens)
                from_partition = sum((vol for mask, vol in root_masks[j].items()
                                      if mask & tuple_mask == tuple_mask), start=zeros)
                # Independently impose actual positive root j and subtract
                # all later actual roots by inclusion-exclusion of their boxes.
                base = ((j, prefix[j]), (j, atoms))
                from_lenses = zeros
                for count in range(atom_count - j):
                    for remaining in combinations(range(j + 1, atom_count), count):
                        requirements = base + tuple((later, prefix[later]) for later in remaining)
                        from_lenses += (-1)**count * box_intersection_volume(axes, requirements, bits)
                volume_equal(from_partition, from_lenses, bits)
                per_root.append(from_partition)
                stats['root_checks'] += 1
            for omega in OMEGAS:
                success = zeros
                last_gate = None
                rejected = False
                for j, side in enumerate(actual_sides):
                    _, accepted = check_gate(side, spans, omega, bits)
                    if not accepted:
                        rejected = True
                    else:
                        assert not rejected, "Sharp-width gate must be increasing in the side."
                    if accepted and per_root[j] > 0:
                        success += per_root[j]
                        last_gate = j
                stats['gate_queries'] += 1
                if last_gate is not None:
                    stats['positive_gates'] += 1
                    # Last *actually occupied* allowed root, no successor rounding.
                    assert actual_sides[last_gate] * convert(EPS, bits) < convert(F(1, 4), bits)
                    upper = receiver_volume * convert(omega, bits)
                    # This inequality has strict margin because each receiver
                    # side exceeds epsilon*s and at least one factor is below 1.
                    assert raw_direct[last_gate] < upper
                    gap = raw_direct[last_gate] - success
                    if bits:
                        assert gap > 0 or gap.contains(0)
                    else:
                        assert gap >= 0
    return stats


def suite(case):
    n, atom_count, cells = case
    result = {}
    for bits in (0, 256, 384):
        total = Counter()
        for seed in range(cells):
            total.update(run_cell(n, atom_count, seed, bits))
        result[bits] = total
    assert result[256] == result[384]
    return case, result


def budget_checks(bits):
    ctx.prec = bits
    for n in SCALAR_DIMS:
        nn, nn_plus = arb(n), arb(n + 2)
        ell = nn_plus.log()
        m = isqrt(n)
        target_t = arb(3) / 2
        bump = 1 / (32 * nn)
        h = 1 + bump
        log_h = bump.log1p()
        # Sign of n(1/32-n log(1+1/(32n))) from the alternating series,
        # without cancellation when n exceeds the Arb mantissa length.
        lower_scaled_gap = arb(1) / (2 * 32**2) - 1 / (3 * 32**3 * nn)
        assert lower_scaled_gap > 0 and log_h > 0
        if n <= 10**64:
            assert nn * log_h < arb(1) / 32
        n0 = 3 + nn * (64 * nn**2).log() / arb(2).log()
        for smoothing in (1, 8):
            if n <= 2 * smoothing:
                continue
            # T=2^(1/n) tau, and floor(1/epsilon) gives the actual grid side.
            eps = arb(smoothing) / nn
            grid_side = target_t / (n // smoothing)
            assert grid_side < 2 * eps * target_t
            pool_log_ratio = arb(4).log() + nn * (2 * grid_side / target_t).log1p()
            assert pool_log_ratio < arb(4).log() + 4 * smoothing
            ideal = 1 / arb(smoothing)
            inflated = (h - 1 + 1 / nn) / (h * eps)
            # Equivalent noncancelling expression for huge n, for which h-1
            # itself is smaller than the Arb mantissa precision.
            stable_inflated = arb(33) / (32 * smoothing * h)
            assert (inflated - stable_inflated).contains(0)
            if smoothing == 1:
                assert stable_inflated > 1
                h_log = arb(0)
            else:
                assert stable_inflated < arb(13) / 100
                shift_log = (arb(33) / 32).log()
                h_log = ideal.log() + shift_log - log_h
                assert shift_log - log_h > 0
                assert (h_log - stable_inflated.log()).contains(0)
            ideal_log = ideal.log()
            step_options = tuple(sorted({1, 3, max(1, m // (4 * (n + 2).bit_length())),
                                         max(1, m // 64)}))
            reports = []
            for k_minus_one in step_options:
                original = n0.log() + arb(8).log() + 4 * smoothing + m * ideal_log / k_minus_one
                # Include the additional two h0/base-center shifts even when
                # not covered by the generous single-pool factor 2048.
                history = (3 * ell + ell.log()
                           + k_minus_one * (arb(2048).log() + 4 * smoothing + arb(1) / 16)
                           + m * h_log + arb(1) / 16)
                original_sign = original.sgn().unique_fmpz()
                history_sign = history.sgn().unique_fmpz()
                assert original_sign is not None and history_sign is not None
                signs = int(original_sign), int(history_sign)
                assert all(sign in (-1, 1) for sign in signs)
                if smoothing == 1 or n <= 160:
                    assert signs == (1, 1)
                if smoothing == 8 and n >= 10**64:
                    if k_minus_one == m // 64:
                        assert signs == (1, -1)
                    else:
                        assert signs == (-1, -1)
                reports.append((k_minus_one + 1, *(
                    "paid" if sign == -1 else "unpaid" for sign in signs
                )))
            name = str(n) if n <= 160 else f"10^{len(str(n)) - 1}"
            print(f"Arb {bits} n={name} eps={smoothing}/n: "
                  f"eta_h0={stable_inflated.str(9)}; k: exact-gate/R813 bounds {reports}")


def main():
    print(f"Python {platform.python_version()}, python-flint {flint.__version__}; "
          "3 worker processes, disjoint dimension suites.", flush=True)
    with ProcessPoolExecutor(max_workers=3) as pool:
        for case, results in pool.map(suite, CASES):
            for bits, counts in results.items():
                print(f"n={case[0]} atoms={case[1]} actual receiver cells={case[2]} "
                      f"{'Fraction' if not bits else 'Arb ' + str(bits)}: {dict(counts)}", flush=True)
    for bits in (256, 384):
        budget_checks(bits)
    print("PASS. Exact cell data and certified scalar ranges only; failed sufficient gates are unpaid.")


if __name__ == "__main__":
    main()
