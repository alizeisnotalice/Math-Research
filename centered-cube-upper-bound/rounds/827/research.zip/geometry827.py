#!/usr/bin/env python3
"""Exact overlapping-root star and preselected-pair pressure test.

The receiver boxes are disjoint integration regions, while the associated
physical root cubes overlap and share the whole central source block.
Only small instances enumerate coordinates. Huge dimensions use scalar logs.
"""
from fractions import Fraction
from functools import lru_cache
from itertools import combinations, product
from math import factorial, prod

from flint import arb, ctx

F = Fraction
ZERO = F(0)
T0 = F(3, 2)
A = F(1, 8)
KAPPA = F(2, 3)
SMALL_DIMENSIONS = (6, 8, 12, 16)
LARGE_DIMENSIONS = (10**4, 10**64, 10**96, 10**160)


def ar(value):
    return arb(value.numerator) / value.denominator


def parameters(n):
    separation = T0 * (1 - F(1, 8 * n))
    source_radius = T0 / (128 * n)
    receiver_radius = T0 / (32 * n)
    mass = T0**n / 2
    first_success = T0 * (1 - F(3, 64 * n))
    return separation, source_radius, receiver_radius, mass, first_success


def cube_centers(n, spacing):
    active = n // 4
    signs = [word + (1,) * (n - active) for word in product((-1, 1), repeat=active)]
    sources = [(ZERO,) * n] + [tuple(spacing * sign for sign in word) for word in signs]
    receivers = [tuple(coordinate / 2 for coordinate in source) for source in sources[1:]]
    return sources, receivers


def capture_fraction(x, side, source, radius):
    return prod(
        (
            max(ZERO, min(p + radius, u + side / 2) - max(p - radius, u - side / 2))
            / (2 * radius)
            for u, p in zip(x, source)
        ),
        start=F(1),
    )


@lru_cache(maxsize=None)
def convolved_axis_value(offset, radius):
    """Five centered uniforms, by a derivative of box simplex volume."""
    widths = (F(1), A, A, radius / T0, radius / T0)
    shifted = offset / T0 + sum(widths) / 2
    order = len(widths) - 1
    numerator = ZERO
    for count in range(len(widths) + 1):
        for subset in combinations(widths, count):
            remainder = shifted - sum(subset)
            if remainder > 0:
                numerator += (-1)**count * remainder**order
    return numerator / (factorial(order) * prod(widths))


def midpoint_value(x, p, q, radius):
    return prod(
        (
            convolved_axis_value(abs(coordinate - (left + right) / 2), radius)
            for coordinate, left, right in zip(x, p, q)
        ),
        start=F(1),
    )


def diagonal_pairing(number_of_sources, mass):
    return {(i, i): mass for i in range(number_of_sources)}


def allocate_common_to(number_of_sources, mass, chosen):
    """Exact two original marginals, including unused mass paired in its own cell."""
    pair = {}
    selected = set(chosen)
    assert selected and 0 not in selected
    entry = mass / len(selected)
    for i in range(1, number_of_sources):
        if i in selected:
            pair[0, i] = entry
            pair[i, 0] = entry
            if entry < mass:
                pair[i, i] = mass - entry
        else:
            pair[i, i] = mass
    return pair


def local_independent(mass, index):
    # Total pair measure is 2m and each marginal is exactly the true two-block measure.
    return {key: mass / 2 for key in product((0, index), repeat=2)}


def local_adaptive(mass, index):
    return {(0, index): mass, (index, 0): mass}


def marginals(pair, number_of_sources):
    first = [ZERO] * number_of_sources
    second = [ZERO] * number_of_sources
    for (i, j), mass in pair.items():
        first[i] += mass
        second[j] += mass
    return first, second


def brightness(pair, values):
    return sum((weight * values[i][j] for (i, j), weight in pair.items()), start=ZERO)


def exact_checks(n):
    spacing, radius, receive_radius, mass, first_success = parameters(n)
    sources, receivers = cube_centers(n, spacing)
    r = len(receivers)
    assert r == 2**(n // 4)
    assert 2 * radius < spacing
    assert 1 < first_success < T0 < 2
    assert first_success / 2 == spacing / 2 + radius + receive_radius
    assert 3 * spacing / 2 - radius - receive_radius > 1
    assert 2 * spacing - 2 * radius > 2
    assert 2 * receive_radius < spacing
    assert T0 - spacing - 2 * receive_radius == T0 / (16 * n)

    source_mass = (r + 1) * mass
    assert source_mass < 2**n
    row_volume = (2 * receive_radius)**n
    selected_volume = r * row_volume
    assert selected_volume / source_mass == F(2 * r, r + 1) / (16 * n)**n

    # Pointwise-in-block bounds, which also apply to arbitrary position-dependent
    # couplings inside cells, not just the product couplings used for samples.
    assert (radius + receive_radius) / T0 < F(3, 8)
    assert (spacing - radius - receive_radius) / T0 > F(5, 8)
    minimum_nonmatch_distance = (spacing / 2 - radius - receive_radius) / T0
    assert minimum_nonmatch_distance == F(1, 2) - F(13, 128 * n)
    shoulder = 1 - F(13, 16 * n)
    assert 1 - shoulder**2 / 2 < KAPPA
    gamma = (r + 1) * KAPPA**n / 2
    assert gamma < F(1, 4)
    assert 2 * (F(3, 4) - gamma) > 1
    if n >= 13:
        assert 3 * (F(2, 5) - gamma) > 1

    # Pair capacities for actual source cells, without assuming stationarity
    # across receiver choices.
    diagonal = diagonal_pairing(r + 1, mass)
    preset_one = allocate_common_to(r + 1, mass, (1,))
    preset_two = allocate_common_to(r + 1, mass, (1, 2))
    balanced = allocate_common_to(r + 1, mass, range(1, r + 1))
    for pair in (diagonal, preset_one, preset_two, balanced):
        assert marginals(pair, r + 1) == ([mass] * (r + 1), [mass] * (r + 1))
        cross_mass = sum((value for (i, j), value in pair.items() if (i == 0) != (j == 0)), start=ZERO)
        assert cross_mass <= 2 * mass

    tests = 0
    paired_cells = 0
    minimum_independent = None
    center_balanced = None
    for i, center in enumerate(receivers, start=1):
        for j, other in enumerate(receivers[:i - 1], start=1):
            hamming = sum(a != b for a, b in zip(center, other))
            overlap_volume = prod(T0 - abs(a - b) for a, b in zip(center, other))
            assert overlap_volume == T0**n * F(1, 8 * n)**hamming > 0
            assert i != j

        adaptive = local_adaptive(mass, i)
        independent = local_independent(mass, i)
        active = [ZERO] * (r + 1)
        active[0] = active[i] = mass
        assert marginals(adaptive, r + 1) == marginals(independent, r + 1) == (active, active)

        points = (
            center,
            tuple(coordinate + receive_radius for coordinate in center),
            tuple(coordinate + (-1)**j * receive_radius for j, coordinate in enumerate(center)),
        )
        for point in points:
            for side in (first_success, T0, F(2)):
                marked = [
                    mass * capture_fraction(point, side, source, radius) for source in sources
                ]
                assert marked == active
                assert sum(marked) == 2 * mass
                tests += 1
            values = [
                [midpoint_value(point, left, right, radius) / T0**n for right in sources]
                for left in sources
            ]
            for left in range(r + 1):
                for right in range(r + 1):
                    if (left == 0) != (right == 0):
                        partner = max(left, right)
                        assert values[left][right] == (F(1, T0**n) if partner == i else ZERO)
                    else:
                        assert values[left][right] <= KAPPA**n / T0**n
                    paired_cells += 1
            assert brightness(adaptive, values) == 1
            independent_value = brightness(independent, values)
            assert F(1, 2) <= independent_value <= F(1, 2) + KAPPA**n / 2
            minimum_independent = independent_value if minimum_independent is None else min(
                minimum_independent, independent_value
            )
            assert (brightness(preset_one, values) >= F(3, 4)) == (i == 1)
            if n >= 13:
                assert (brightness(preset_two, values) >= F(2, 5)) == (i <= 2)
            assert brightness(diagonal, values) <= gamma
            balanced_value = brightness(balanced, values)
            assert F(1, r) <= balanced_value <= F(1, r) + gamma
            if i == 1 and point == center:
                center_balanced = balanced_value

    assert T0 + 2 * radius - spacing == 9 * T0 / (64 * n)
    print(
        f"Fraction n={n}, r={r}: {tests} true hard capture checks, "
        f"{paired_cells} actual soft pair cells. "
        f"Minimum tested local-independent={float(minimum_independent):.12g}; "
        f"balanced preselection at first center={float(center_balanced):.12g}."
    )
    print(f"  per-row true receiver volume={row_volume}, mass of shared block={mass}; "
          f"selected F/S={selected_volume / source_mass}. "
          "At theta=3/4 optimum is one whole row vs all r with row access.")


def scalar_checks(n, bits):
    ctx.prec = bits
    nn = arb(n)
    log_r = (n // 4) * arb(2).log()
    # r+1 <= 2r, so gamma <= r*(2/3)^n. No dense code in these dimensions.
    log_gamma_upper = log_r + nn * ar(KAPPA).log()
    assert log_gamma_upper < -nn / 10
    assert log_gamma_upper < -(arb(15).log())
    assert log_gamma_upper + nn.log() / 4 < -arb(2).log()
    # For threshold n^(-1/4), at most 2 n^(1/4) rows survive the preset gate.
    log_served_fraction = arb(2).log() + nn.log() / 4 - log_r
    assert log_served_fraction < -nn / 10
    # The whole hard success set, at lambda=1: single-block and paired rows.
    entire_weak_upper = (arb(1) / 32).exp() + 2 * (nn * (arb(9) / (64 * nn)).log()).exp()
    assert entire_weak_upper < arb(21) / 20
    name = f"10^{len(str(n)) - 1}"
    print(
        f"Arb {bits} bits n={name}: log(gamma upper)/n={(log_gamma_upper / nn).str(10)}, "
        f"log(preset served fraction upper)/n={(log_served_fraction / nn).str(10)}, "
        f"full lambda=1 hard weak ratio<{entire_weak_upper.str(10)}."
    )


def main():
    for n in SMALL_DIMENSIONS:
        exact_checks(n)
    for bits in (256, 384):
        for n in LARGE_DIMENSIONS:
            scalar_checks(n, bits)
    print("PASS. Actual positive source boxes, exact finite receiver volumes and "
          "scalar high-dimensional bounds; no linear weak-type lower bound.")


if __name__ == "__main__":
    main()
