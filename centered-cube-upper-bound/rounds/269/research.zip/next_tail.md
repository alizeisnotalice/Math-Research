# R269 auxiliary: forward off-core, the actual hard cap and its exact tail integral

Scope: R≥L and the full original source off-core r_y(x)=2||x-y||_∞>L. The original β,ν, two Π_yjt, true dx, all source/history gates and signed accounts remain unchanged. This note does **not** claim a new summable forward off-core row price. It supplies the exact cap-weighted tensor integral and identifies the first remaining kernel estimate. No guessed soft-label deficit bound is used as a theorem.

## O1. The actual cap and ratio comparison

Let d=a/(8√n), w=b+d, γ=1+1/n. Retain the raw near hard-source numerator

N(x;y,t,v,u)=∫h_R(x-z)1_{||z-y||_1≤d/2}A(x,y,z,t,v,u)ν(dz), 0≤A≤1.

The allowed hard sources satisfy r_y≤R+d and belong to Q_{r_*}(x), where

r_*=min(R,max(a,r_y+d)).

The inherited all-R receiver cap h_r*f≤4λ, a≤r≤b, therefore gives

N≤4λ(r_*/R)^n.

For off-core r_y>L≥a this is N≤4λ min(1,((r_y+d)/R)^n). It is a bound for the actual numerator, not for η=N/H_R alone. With tildeη=N/((16/3)q), q≥3λ/4, we have

(1) 0≤tildeη≤min(1,((r_y+d)/R)^n).

The actual forward ratio band gives R/L≥q_j:=γ^{2j}. Thus (1) is at most min(1,((r_y+d)/(q_jL))^n). Actual forward L belongs to [a,b/q_j]; an empty interval contributes zero. Replacing R by q_jL is an upper bound, not a new physical selector.

Original near also gives x∈W_y=Q_w(y). All off-core source values within that window remain; no soft tail has been dropped.

## O2. The completely explicit fixed-parameter tensor

Fix s,σ∈[0,1], a≤L≤A≤b and centers y,v. For a moving leg A=L or min(b,γL), σ=s; for J, A=b and σ=1. Keep the same original physical weight

Ω_i=min(1,b C(|y_i-v_i|/b)/L), barw_L=∏Ω_i,
F_L(x)=sqrt[P_{s,L}(x-y)P_{σ,A}(x-v)/barw_L(y,v)].

For p=2 or 3/2 and 0≤r≤w define

q_{p,i}(r)=L^{p/2-1}/(AΩ_i)^{p/2}
 ×∫_{-r/2}^{r/2}f_s(u/L)^{p/2}f_σ((u+y_i-v_i)/A)^{p/2}du,
Z_p(r)=∏_i q_{p,i}(r), T_p(r)=Z_p(w)-Z_p(r).

Every term is a genuine one-dimensional integral of the original φ/f_s. Tensor factorization is justified solely for this receiver kernel, not for the original source law. Precisely,

Z_p(r)=L^{n(p-1)}∫_{Q_r(y)}F_L(x)^p dx.

Put b_{j,L}(r)=min(1,((r+d)/(q_jL))^n) for r≥L. Monotone layer cake proves the exact upper-envelope formula

(2) L^{n(p-1)}∫_{W_y}1_{r_y>L} tildeη(x)^p F_L(x)^p dx
 ≤ b_{j,L}(L)^p T_p(L)
 + pn/(q_jL)^{pn} ∫_L^{min(w,q_jL-d)}(r+d)^{pn-1}T_p(r)dr.

If the upper endpoint is ≤L the integral is empty. If q_jL≤L+d, the first coefficient is one and (2)'s right side is just T_p(L). The right side equals the integral with the explicit radial comparison b_{j,L}(r_y)^p; it is not asserted equal to the actual masked hard-source quantity.

Proof: b(r)^p=b(L)^p+∫_L^r d(b(t)^p), and apply positive Tonelli over r_y>L. Its derivative below saturation is pn(r+d)^{pn-1}/(q_jL)^{pn}; afterwards it vanishes. All r_y level boundaries are dx-null, so original hard-core conventions do not alter the formula.

The tensor tail has the exact first-exit decomposition

(3) T_p(r)=Σ_i [q_{p,i}(w)-q_{p,i}(r)]
                  ∏_{k<i}q_{p,k}(r)∏_{k>i}q_{p,k}(w).

For r≥L its first-exit coordinate obeys, Lebesgue almost everywhere,

q_{p,i}(w)-q_{p,i}(r)
 =s^{p/2} L^{p/2-1}/(AΩ_i)^{p/2}
 ×∫_{r/2<|u|≤w/2}φ(u/L)^{p/2}
                       f_σ((u+y_i-v_i)/A)^{p/2}du.       (4)

Thus the required soft factor is retained at the coordinate which actually exits. It is s for p=2 and s^{3/4} for p=3/2. There is no identification between this soft label and the original posterior score k_t(y,v).


## 审核与下一步边界

本附件仅保O1/O2固定参数接口。后续实际选择尺度、soft网格、原后验clock及跨j费用尚须完整结算；未使用作者另拟的自适应Abel扩展作本轮依据。固定参数尾积分公式不是可求和上界。下一步要求在上述T_p(r)的有帽积分内保固定来源Δ_b阻尼，才能进入原后验clock；不能以T_p≤Z_p(w)而声称继承核心δ_j折扣。

该附件不参与本轮反向分支主证明。独审状态见audit.md；16个有理layercake模型的检验代码并入reproduce.py，不是实际φ核或FULL模型。
