#!/usr/bin/env python3
"""R269 reverse-band lower endpoint and finite scalar geometric prices."""
import argparse,hashlib,json
from fractions import Fraction as F
from pathlib import Path
import mpmath as mp

def enc(x):return mp.nstr(x,100)
def mm(x):
 q=F(x);return mp.mpf(q.numerator)/q.denominator

def numeric(dps):
 with mp.workdps(dps):
  rows=[];directcount=0
  for n in [1,2,8,16,64,512,4096,10**6,10**12]:
   lg=mp.log1p(mp.mpf(1)/n);h=n*lg
   for b in [F(1),F(3,2),F(2)]:
    J=int(mp.floor(mp.log(mm(b))/(2*lg)));count=J+1
    S2=(-mp.expm1(-2*h*count))/(-mp.expm1(-2*h));SJ=(-mp.expm1(-h*count))/(-mp.expm1(-h))
    assert S2<=mp.mpf(4)/3 and SJ<=2
    d2=dj=None
    if n<=512:
     d2=sum(mp.exp(-2*h*j) for j in range(count));dj=sum(mp.exp(-h*j) for j in range(count));assert abs(S2-d2)<mp.mpf('1e-45') and abs(SJ-dj)<mp.mpf('1e-45');directcount+=2
    rows.append({'stage':'initial' if n<=8 else 'stress' if n<=512 else 'expanded','n':n,'a':'1','b':str(b),'j_max':J,'term_count':count,'h':enc(h),'S2':enc(S2),'SJ':enc(SJ),'S2_margin_to_4_over3':enc(mp.mpf(4)/3-S2),'SJ_margin_to_2':enc(2-SJ),'S2_direct':enc(d2) if d2 is not None else None,'SJ_direct':enc(dj) if dj is not None else None,'S2_direct_absolute_residual':enc(abs(S2-d2)) if d2 is not None else None,'SJ_direct_absolute_residual':enc(abs(SJ-dj)) if dj is not None else None,'moving_source_factor_sqrt_n_S2':enc(mp.sqrt(n)*S2),'J_source_factor_n_quarter_SJ':enc(mp.root(n,4)*SJ),'tau_reverse_lambda1_a1':enc(mp.sqrt(n))})
  return {'cases':rows,'independent_direct_sum_checks':directcount}

def geometry():
 rows=[]
 for n in [1,2,8,16,64,512]:
  gamma=F(n+1,n)
  for b in [F(1),F(3,2),F(2)]:
   jmax=0
   while gamma**(2*(jmax+1))<=b:jmax+=1
   for j in sorted(set([0,min(1,jmax)])):
    # q is precisely c_j^2 L/R; endpoints and two strict band interiors.
    for label,q in [('lower',F(1)),('interior_one',1+(gamma**2-1)/3),('interior_two',1+2*(gamma**2-1)/3),('upper',gamma**2)]:
     L=gamma**(2*j)*q;R=F(1)
     if L>b:continue
     cj2=gamma**(-2*j);band=cj2*L/R
     assert F(1)<=R<=L<=b and 1<=band<=gamma**2 and L>=gamma**(2*j)
     # Put the same ratio at the opposite physical endpoint R<=L=b.
     L2=b;R2=b/L;band2=cj2*L2/R2
     assert 1<=R2<=L2<=b and 1<=band2<=gamma**2 and L2>=gamma**(2*j)
     rows.append({'n':n,'a':'1','b':str(b),'j':j,'profile':label,'gamma_exact':str(gamma),'c_j_squared_exact':str(cj2),'R_exact':str(R),'L_exact':str(L),'squared_band_ratio_exact':str(band),'lower_L_endpoint_exact':str(gamma**(2*j)),'L_lower_margin_exact':str(L-gamma**(2*j)),'second_R_exact':str(R2),'second_L_exact':str(L2),'second_squared_band_ratio_exact':str(band2)})
 return rows

def fields(obj,path=''):
 out={}
 if isinstance(obj,dict):
  for k,v in obj.items():
   if isinstance(v,str) and k not in ['stage','a','b']:
    try:out[path+k]=mp.mpf(v)
    except ValueError:pass
   elif isinstance(v,(dict,list)):out.update(fields(v,path+k+'/'))
 elif isinstance(obj,list):
  for i,v in enumerate(obj):out.update(fields(v,path+str(i)+'/'))
 return out

def main():
 p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=Path(__file__).with_suffix('.json'));a=p.parse_args();lo=numeric(50);hi=numeric(90);geo=geometry()
 with mp.workdps(120):
  x=fields(lo);y=fields(hi);assert x.keys()==y.keys();diff={k:abs(x[k]-y[k])/max(1,abs(y[k])) for k in x};worst=max(diff,key=diff.get);md=enc(diff[worst]);assert diff[worst]<mp.mpf('1e-44')
 out={'schema':'R269-reverse-source-price-v1','script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'counts':{'scalar_price_cases_per_precision':27,'price_stages':{'initial':9,'stress':9,'expanded':9},'direct_sum_checks_per_precision':hi['independent_direct_sum_checks'],'exact_AG2_ratio_cases':len(geo),'exact_AG2_placements':2*len(geo),'precision_fields_compared':len(diff)},'mp50':lo,'mp90':hi,'precision_max_relative_difference':md,'precision_worst_field':worst,'AG2_exact_geometry':geo,'scope':['Actual nonempty j0..floor(log(b/a)/(2loggamma)); a1,b1/1.5/2. Closed finite geometric sums use expm1/log1p. n<=512 also independently enumerates all legal j; large n uses formulas only.','S2 sums gamma^(-2nj) and SJ sums gamma^(-nj); constants4/3 and2 are only consistency checks here, not proved by sampling.','AG2 exact Fractions certify displayed finite samples R<=L in[1,b],c_j^2 L/R in[1,gamma^2],hence L>=gamma^(2j),without irrational square roots. Both band endpoints and two interiors are attempted when physically legal.','tau_reverse=lambda*a^n*sqrt n; tables set lambda=a1. Moving sqrt n*S2 and J n^(1/4)*SJ factors omit all other original constants and are not FULL traffic, complete source-payment, root or dimension-order conclusions.','50/90 ordinary mpmath is not outward interval certification. No source independence, histories, dense-complement payment, or universal theorem inferred.']}
 a.output.write_text(json.dumps(out,sort_keys=True,indent=2)+'\n');print(json.dumps({'counts':out['counts'],'maxdiff':md,'worst':worst}))
if __name__=='__main__':main()
