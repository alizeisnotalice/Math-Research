#!/usr/bin/env python3
"""Reproduce finite prices and exact lower-endpoint Abel diagnostics."""
from fractions import Fraction as F
from pathlib import Path
import argparse,hashlib,json,sys,subprocess,tempfile
ROOT=Path(__file__).resolve().parent

def exact_abel():
    moving=surrogate=0
    for n in (1,2,4,16,64,128):
        for ell in (F(1),F(3,2)):
            b=F(2);scales=[ell+(b-ell)*u for u in (F(0),F(1,4),F(1,2),F(1))]
            prev=F(0);integral=F(0)
            for L in scales:
                volume=L**n;integral+=(volume-prev)/L**(2*n);prev=volume
            assert integral<=2*ell**(-n)-b**(-n)
            moving+=1
    # Fixed HARD target surrogate: checks the finite profile Abel formula,
    # not the actual phi J kernel or its uniform deficit.
    for n in (4,8,16,32,64,128):
        for ell in (F(1),F(3,2)):
            b=F(2);scales=[ell+(b-ell)*u for u in (F(0),F(1,4),F(1,2),F(1))]
            prev=F(0);integral=F(0)
            for L in scales:
                volume=L**n;integral+=(volume-prev)/(L*b)**(3*n//4);prev=volume
            D=max((L/b)**(3*n//4) for L in scales)
            assert integral<=D*(F(3,2)*ell**(-n//2)-F(1,2)*b**(-n//2))
            surrogate+=1
    return {'actual_nested_hard_square_cases':moving,'fixed_hard_target_Abel_surrogate_cases':surrogate}

def exact_layercake():
    from math import comb
    checks=0
    for n in (2,4):
        for p in (F(2),F(3,2)):
            power=int(n*p);w=F(21,20);d=F(1,20);L=F(1,2)
            for q in (F(1),F(5,4),F(3,2),F(3)):
                R=q*L;cut=min(w,max(L,R-d));base=min(F(1),((L+d)/R)**power)
                direct=F(0)
                if base==1:direct=1-(L/w)**n
                else:
                    for j in range(power+1):
                        direct+=F(n*comb(power,j))*d**(power-j)*(cut**(j+n)-L**(j+n))/F(j+n)/R**power/w**n
                    if R-d<w:direct+=1-(cut/w)**n
                rhs=base*(1-(L/w)**n)
                if base<1:
                    for j in range(power):
                        c=F(power*comb(power-1,j))*d**(power-1-j)/R**power
                        rhs+=c*((cut**(j+1)-L**(j+1))/F(j+1)-(cut**(j+n+1)-L**(j+n+1))/F(j+n+1)/w**n)
                assert direct==rhs;checks+=1
    return checks

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--check-only',action='store_true');args=ap.parse_args()
    m=json.loads((ROOT/'manifest.json').read_text())
    for name,digest in m['sha256'].items():assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest,name
    result=exact_abel();assert result==m['exact_abel_counts'];print('Exact Abel checks PASS:',result)
    count=exact_layercake();assert count==m['exact_layercake_checks'];print('Exact layercake checks PASS:',count)
    if not args.check_only:
        with tempfile.TemporaryDirectory(prefix='r269-replay-') as d:
            output=Path(d)/'numeric.json'
            subprocess.run([sys.executable,str(ROOT/'numeric_checks.py'),'--output',str(output)],check=True)
            assert output.read_bytes()==(ROOT/'numeric_checks.json').read_bytes()
        print('Full numeric replay byte-identical PASS')
    else:print('Hashes/exact Abel only; price menu not rerun.')
if __name__=='__main__':main()
