# R643：实际正则 Q 的接触坏跳跃独立证书审核

**判定：四个指定 H 的真实 cube countercertificate 通过。** 同一个合法连续位移路径中，实际接收体积 W 不变，新正体积 clique 出现时实际 entropy-regularized 最优权的线性部分 Q 严格上跳，完整 D=W−RQ 严格下跳；完整含 log 的最优值却严格下降。该例非 critical/hard，只反驳“所有 contact jumps 对 D 无条件有利”，不反驳命题 F、其他好动作的存在或一般根阶目标。

冻结最终主稿 `/tmp/ccu_r643_final/REPORT.tex` SHA-256：
`5e90136324fc0e15c5a49161fad581252b2e48307305250437ce52ad47c0a106`。
本审对最终主稿的范围**仅为第4节 countercertificate**，不认证其他新证明。

## 1. 同一旧 KKT 来源与真实接收

独立核参数：n=2、a=64、P=(65/64)^2，ε=1/(2PH)，c=ε/a²=1/(8450H)，z=c/10。m=(1,1,1+z,1+z,1)，λ=(1/5,1/2,3/10,7/10,3/10)，d_j=m_j/(1+c/λ_j)，s_j=√d_j/2。

脚本用整数 isqrt 构造至少192位向外有理区间；中心 y1 使用这些**明确有理上界**定义，而非四舍五入的真实根。完整旧 maximal cliques 确为 012、23、34、04。前三个显式正体积 source 小盒严格包含于其各自成员的旧 cubes，并与每个非成员严格分离。独立检查了所有源盒的成员/非成员与正质量1、z、1。因此每行 μ(A_j)=m_j，总质量 M=2+z，且来源上的 λ-load 为1。

逐行 λ_j(m_j−d_j)=εd_j/a²。旧 receivers 两两不交，所以 v_j=d_j/a² 是实际增量，旧 log 目标严格凹、λ 全正，KKT 证书认证真实唯一旧最优。旧 Q=d·λ 与 raw 新 Q 不同，不能混用字段或分母。

## 2. 全连续路径、全部图和正体积约束

ρ_j=√m_j/2、δ_j=ρ_j−s_j>0。路径只令 row1 左移 tδ1、row4 右移 tδ4，t∈[0,1]。每行始终 A_j⊂C_j(t)，|C_j|=m_j；这是同一旧 KKT m 的合法 containment 动作，不冒称所有 shifted cubes 都是 last-strict-bad canonical cubes。

在独立 checker 中，以实际有理中心和认证半径区间重建 old/raw/post 图，并遍历全部32个 label subsets。完整 maximal cliques 为：

* old 和 t=0：012、23、34、04；
* post：012、014、23、34。

所以没有漏掉三方或更高阶 packing 约束。图不是从预设抽象图回填；实际两维 interval-distance 比较先产生图，再枚举 cliques。开 axis-box 的 Helly 性使这些正体积 cliques 完整表述 a.e. packing。

全路径的独立坐标包络认证：除14外，所有边状态固定；所有新 receivers 对全部 t 仍两两不交。因此每行 w_j=m_j/a²，W=Σm_j/a² 恒定且不依赖新顺序。

14 的 y 距离恒为0，正的 x 距离为 A−t(δ1+δ4)。认证区间给 A>1、0<A−δ1−δ4<1，故唯一 t*= (A−1)/(δ1+δ4)∈(0,1)。t=t* 只有边界接触、正体积约束尚未出现；t>t* 时14及由其触发的014 clique 才出现。其他 cliques 和 w 不变，故前后优化问题确是这两个固定 polytopes 的实际问题。

## 3. raw 新最优：真实权重与精确根

令 p,q 分别为

\[
f_p(p)=1/10+(1+z)/p-2/(1-p)=0,
\quad f_q(q)=1/10+(1+z)/q-1/(1-q)=0.
\]

二函数在(0,1)严格递减，端点有严格异号。等价的正根多项式为

\[
p^2+(29+10z)p-10(1+z)=0,
\quad q^2+(19+10z)q-10(1+z)=0.
\]

故唯一根满足 1/3<p<7/20、1/2<q<53/100。每个 H 的两根又各作96次独立 Fraction 二分，保留严格有理包络。

αpre=((1−p)/2,(1−p)/2,p,q,1−q) 全正；012、34紧，23、04严格松弛。真实梯度是 g_i=m_i(1+c/α_i)，包含实际 w_i=m_i/a²。两方程分别准确保证 g0=g1=g2、g3=g4，因此只需012与34的正乘子即可给全部行 KKT。独立检查了这些 tight cliques 的正 AC cores；严格凹性认证这就是实际唯一 raw 新最优。

\[
Q_{\rm pre}=2+z(p+q)=M-z(1-p-q),
\quad1-p-q>3/25.
\]

不是使用某个有利 packing 权代替实际最优。

## 4. post normal、两种最优值及完整 D

r=(2+z)/(5+2z)，αpost=((1−r)/2,(1−r)/2,r,1−r,r)。四个 post maximal cliques 全紧。按23、34、012、014顺序，证书乘子为

\[
\gamma=(1/2,\ g_3-1/2,\ g_2-1/2,\ g_4-g_3+1/2),
\]

g_i=m_i(1+c/αpost,i)。四个 H 均精确认证 γ>0、g0=g1=γ012+γ014，且全部行梯度/互补正确。独立 checker 还在每个实际 post clique 交内构造共同的正体积有理 core，并认证不进入外部行；将各 γ 均匀放入这些 cores 即是真实 AC 新 KKT 来源。它不是被误称为旧 μ。

故 post 实际唯一最优满足 Qpost=M=2+z，严格有

\[
\Delta Q=z(1-p-q)>3z/25,
\qquad\Delta D=-R\Delta Q<-3Rz/25<0.
\]

raw αpre 对014的 load=2−p−q>1，故不属于 post polytope；新的严格凹 log 最优完整值严格下降。这与 Q 的线性部分上升不矛盾。

更明确地，旧 λ 在 raw/post 两图均可行且 m·λ=M，同一旧 μ 又覆盖两图的需求，故**辅助线性 packing 最优值两边都=M**。此 contact 的线性容量节省为0，真正变化是 barrier deficit 从 M−Qpre>0 降为0。违反新增014的是上述 p,q raw 权，**不是旧 λ**；最终主稿已明确这个指代。

W 恒定的全部 receiver 费用已保留，old R 按真实 d、λ计算。λmin=1/5 直接给 εR≤5/(8450H)≪3，所以四例远离 critical F 域；也没有证明 Dpost 本身为负，只证明严格下跳。

## 5. 代码修正、独立复跑与最终稿对照

曾发现 JSON 的 duplicate `old_Q` 会用 raw 新公式覆盖真实旧 Q。已通知 root/Terra；作者修为独立字段 `raw_new_Q_formula`，保留真实有理 `old_Q`，并重生成四份 JSON 与 SHA256SUMS。该缺陷只影响序列化语义，R 和数学计算未被覆盖；但必须修复后才归档。本审复跑使用修正后脚本：

`1c416fe926b6656ef346fbe933bca0e6a92fde05669375fb6f497fbe1d6fa7a7`。

在独立 TemporaryDirectory 中复制脚本，H=32、64、128、1024 各实际执行**一次**，未覆盖作者文件。除时间、RSS、Python进程信息外，全部输出字段逐项与重生成收据一致。另作上述独立全部-subset clique 枚举、source/core 检查、全路径 interval 包络与精确根二分。

| H | 严格 ΔQ 下界 | 独立脚本 wall(s) |
|---:|---:|---:|
|32|3/67600000|0.001249|
|64|3/135200000|0.001117|
|128|3/270400000|0.001094|
|1024|3/2163200000|0.001077|

外层复跑与独立检查总 wall 约0.0883秒；四个独立脚本峰 RSS≤21,561,344 bytes。临时副本随后自动删除，未新增作者结果或重算探索搜索。没有用浮点图容差、没有重复 finite-graph 探路。

已只读最终 SHA 对应主稿第4节：旧来源、实际 w、raw 根、post KKT、ΔQ/ΔD、两边 linear optimum=M 与非hard范围均和本审一致；“而非旧 λ”的最后措辞修复已核。此审核不延伸为主稿其他章节的新证明审核。

**最终状态：** decisive actual-contact 反证书可归档；它排除无条件 good-jump 论证，但不排除只在 critical family 中有额外几何约束的命题，也不证明全局 F。完成停止。
