# R643 independent source/scale entropy audit

**PASS, in the stated finite-N scope.** After a legal global choice of an old AC KKT source with at most N positive active packets,

`A_{g≤9}≤PM[1+log(9N)]`,

`E≥(2/7)[(1+κ)V−PM(1+log(9N))]_+`,

and, for κ∈[7/2,4] and E≤V/7,

`N≥exp(56H/9−1)/9`.

These are finite-size/low-variance restrictions. They neither prove F nor pay a complete receiver/source budget. I derived the statements from the frozen contract before reading `source.md`, then compared its (1)–(14). No substantive difference was found.

## 1. Positive-volume clique bound at every scale

For any old positive-volume clique K, choose a common point x of its old cubes. For the labels with d_j≤t, their half-sides satisfy `s_j≤t^(1/n)/2`. Every corresponding small receiver is contained in

`Q(x,(1+1/a)t^(1/n)/2)`.

Its volume is exactly Pt. Each true old owned piece I_j lies in that receiver, and the I_j are pairwise disjoint even after restricting to an arbitrary subset of labels. Therefore

`F_K(t)=Σ_{j∈K,d_j≤t}v_j≤Pt`

for every real t>0, with no dyadic-scale assumption and no factor depending on |K|. The same bound applies to any subfamily of K. It controls Lebesgue volumes of receiver pieces, not the possibly unbounded density of μ. A common source point is not used to bound an arbitrary source mass by volume.

## 2. Stieltjes endpoint and the full row sum

Fix G≥1 and a packet with positive mass z_K. For every j∈K with g_j≤G,

`z_K≤m_j≤Gd_j`, hence `d_j≥b:=z_K/G>0`.

If this subfamily is nonempty, set D_K=max d_j in it and let F_{K,G}(t) include atoms with d_j≤t. It has no atoms below b. Finite integration by parts, including any atom at b, gives

`Σ_{j∈K,g_j≤G}v_j/d_j = F_{K,G}(D_K)/D_K + ∫_b^{D_K}F_{K,G}(t)/t² dt`.

The lower boundary term uses F(b−)=0, not F(b)=0. The expression also works when D_K=b: the integral vanishes and the terminal term contains all atoms. Consequently

`Σ v_j/d_j≤P[1+log(GD_K/z_K)]`.

Multiplying by z_K and using the complete old moments, not a row-dependent source, yields

`Σ_K z_K Σ_{j∈K,g_j≤G}v_j/d_j = Σ_{g_j≤G}(m_j/d_j)v_j=A_{g≤G}`.

Thus the author's local scale bound is valid. Empty subfamilies and zero packets are omitted; no logarithm at zero is taken. All logarithms are natural and have dimensionless arguments. Geometry rescaling multiplies d,v,m,z,M,E by the same volume factor and preserves the inequalities.

## 3. At most N packets without changing the KKT problem

Let the actual number of retained old labels be J≤N. The old AC source gives a finite nonnegative representation

`m=Σ_K z_K 1_K`

over positive-volume active cliques, all satisfying λ(K)=1. If more than J coefficients are positive, their incidence vectors in R^J are linearly dependent. Choose nonzero c with `Σc_K1_K=0`. Dotting with λ gives `Σc_K=0`, so c has both signs. Move the coefficients along this direction until one becomes zero, retaining nonnegativity and all moments. Repetition leaves at most J≤N positive packets.

The total mass is preserved automatically: `Σz_K=λ·m=M`. It is not an extra independent moment requiring N+1 packets. Every retained packet is an original positive-volume complete active intersection T_K. Putting its new mass uniformly on T_K gives an actual finite L1 density; all m_j, total M, λ-load saturation, and hence the old KKT relation remain unchanged. There is no atomic limit, new label, altered old geometry, or altered v. The disjointness of the active rectangles makes the uniform construction particularly direct.

This is one global source choice, made before any action depending on it. It is not permission to use a different source for each row or packet in one action. The scalar A_{g≤G} and E are independent of that choice, so existence of the sparse representation is enough to establish the claimed family inequality.

## 4. Entropy constant and tail calculation

For each nonempty subfamily, `D_K≤M`, because d_j<m_j≤M. With r≤N positive packets and p_K=z_K/M, the local sum is bounded by

`PM Σ_K p_K[1+log(G/p_K)]≤PM[1+log(Gr)]≤PM[1+log(GN)]`.

One can extend the nonempty-subfamily sum to all r packets since G≥1 makes each added upper-bound term nonnegative. The probability entropy estimate is `−Σp_Klog p_K≤log r`. Coarsening D_K to M is valid here specifically as an N-dependent bound. It is not a uniform entropy estimate in n, and it may introduce useless extra entropy under disjoint copies.

For the variance calculation put `q_j=λ_jd_j`, `u_j=g_j−1=εv_j/q_j`. Then

`E_j=εq_j(v_j/q_j−R)²=v_j(u_j−κ)²/u_j`,

and the exact total growth is

`A=Σg_jv_j=(1+κ)V+E`.

If g_j>9, then u_j>8 and κ≤4, so

`g_jv_j/E_j=u_j(u_j+1)/(u_j−κ)²≤u_j(u_j+1)/(u_j−4)²≤9/2`.

Thus `A_{>9}≤(9/2)E` and

`A_{≤9}≥(1+κ)V−(7/2)E`.

Combining with the entropy upper bound and E≥0 gives exactly

`E≥(2/7)[(1+κ)V−PM(1+log(9N))]_+`.

There is no division by a zero tail variance term: u_j>8 is separated from κ≤4. The cutoff g=9 belongs to the low part, and all nonstrict endpoint inequalities remain valid.

## 5. Necessary size of a low-variance critical instance

If E≤V/7 and κ≥7/2, then `A_{≤9}≥4V`. Also

`V/M=κ/[ε(1+κ)]=2PHκ/(1+κ)≥(14/9)PH`.

Hence

`1+log(9N)≥4V/(PM)≥56H/9`,

which proves the stated exponential lower bound on N. The exact real lower bound can of course be rounded upward for integer N. No source-density constant, smallest λ, smallest packet, scale ratio or unproved optimizer regularity enters it. Its explicit log N is the reason it is a computation gate rather than the desired dimension estimate. The estimate does not assert that the large-E branch has positive D.

## 6. Author comparison: shared supplies and simultaneous geometry

The author's (1)–(9) agree with the independent derivation, including the lower-end Stieltjes atom and preservation of M in sparse elimination.

Its (10)–(13) are also valid as conditional constructions, with their stated hypotheses kept:

- Every old packet has one shared supply `Σ_b f_bK≤z_K`; a batch needs row demand `r_bj=Σ_{K∋j}f_bK` and single-clique mass `h_b=max_j r_bj`. Since h_b≤t_b, the proposed net linear saving is nonnegative.
- Added AC mass on an actual common positive-volume intersection covers all of that batch's row demands. Different batches can overlap; they are not independently charged a fresh old source.
- Formula (12) expands exactly to S=M−m·α and retains all actual normal/barrier credit. Old α(K)≤1 follows from old-cube containment in new cubes; deleted rows are extended by zero.
- The centers in (13) must be one common choice for every occurrence of each row, and each x_b must be one common point for its batch. The strict cube inequalities ensure positive-volume intersections. Separate realizations of individual batches do not prove this simultaneous feasibility. Actual W and α must then be recomputed from those same centers.

No quantitative lower bound for (14) has been established. The entropy bound does not construct enough compatible, profitable batches, does not price repeated shared-row demands for free, and does not control the complete receiver loss. The author's stopping claim correctly preserves these gaps.

## 7. Actual auxiliary verification

A tiny actual local SymPy run independently returned the tail-ratio derivative `−(9u+4)/(u−4)^3`, its value 9/2 at u=8, zero residual for a two-atom Stieltjes identity with an atom at the lower endpoint, and the exact gate coefficient 56/9. These are auxiliary algebra checks. Positive-volume geometry, finite source elimination and simultaneous-action quantifiers are proved above, not inferred from numerical samples. No sweep, Git operation or other agent's file was changed.

Audit complete. Finite-N claims pass; F and (14) remain unproved. Stop.

## Final integrated report consistency pass

**PASS for source/scale consistency and the stated scope of the integrated report.**

Read the complete `/tmp/ccu_r643_final/REPORT.tex`, including its final clarification that the finite example's pre/post auxiliary linear capacities both equal M. Independently verified its SHA-256:

`5e90136324fc0e15c5a49161fad581252b2e48307305250437ce52ad47c0a106`.

The report's source section, equations (9)–(12), agrees with the independent proof above. Positive source packets mean z_K>0; zero packets are explicitly omitted from the summed logarithmic formula. The lower Stieltjes atom is retained. Sparse finite representation preserves every row moment and M and is realized on actual positive-volume old intersections. The entropy remains log N, the tail constant remains 9/2, and the low-variance exponential size threshold remains only a necessary finite-size condition. The subsequent shared-supply and simultaneous-center discussion preserves the actual complete target rather than treating packet supply as an exchange gain.

The report states the remaining F with absolute constants, for all universal-free critical families κ∈[7/2,4] and all H above a uniform threshold. It does not restrict F to near-free families or a fixed scale/source class. It consistently says that F, the complete joint receiver budget, and the general root/polylog weak bound remain unproved. The large-variance branch is not declared paid.

The four-example section explicitly confines its certification to four finite H values, identifies the old ratio as noncritical, and says it does not rule out favorable other actions or critical-family structure. The added linear-capacity clarification is logically consistent with the stated feasible old λ, mλ=M and common-source upper bound. The separate jump/path auditor owns the detailed four numerical certificates and path proof; this pass did not rerun or independently recertify those computations.

No further report correction was required for this assigned consistency pass. I changed only this audit, did not rerun historical calculations, and stopped after recording the final report hash.

Final wording freeze: reread the clarified sentence that it is the pre-contact new family’s unique p,q regularized optimizer, rather than old λ, that violates 014. This correct object agrees with the prior scope review. Independently checked final SHA-256 `5e90136324fc0e15c5a49161fad581252b2e48307305250437ce52ad47c0a106`; the final integrated-report binding above is updated. PASS unchanged; no new derivation or rerun. Stop.
