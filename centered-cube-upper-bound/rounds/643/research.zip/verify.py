#!/usr/bin/env python3
from pathlib import Path
from fractions import Fraction as F
from math import factorial
from itertools import combinations
import hashlib,json,os,re,subprocess,sys,tempfile,time
import sympy as S
root=Path(__file__).resolve().parent;start=time.perf_counter()
transient={'cpu_s','wall_s','peak_rss_bytes','python','script_sha256'}
def digest(r):return hashlib.sha256(json.dumps(r,sort_keys=True,separators=(',',':')).encode()).hexdigest()
if (root/'MANIFEST.json').exists():
 for name,h in json.loads((root/'MANIFEST.json').read_text()).items():
  assert hashlib.sha256((root/name).read_bytes()).hexdigest()==h,name
summary=json.loads((root/'RUN_SUMMARY.json').read_text());receipts=[]
with tempfile.TemporaryDirectory(prefix='ccu643-replay-') as tmp:
 for row in summary['cases']:
  out=subprocess.run([sys.executable,str(root/'cube_certificate.py'),str(row['H'])],cwd=tmp,check=True,capture_output=True,text=True,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'))
  r=json.loads(out.stdout)
  assert digest({k:v for k,v in r.items() if k not in transient})==row['semantic_sha256']
  # Independent exact clique enumeration from every subset of the full graph.
  def maximal(edges):
   edges={tuple(e) for e in edges};cs=[]
   for mask in range(1,32):
    vs=tuple(i for i in range(5) if mask>>i&1)
    if all(e in edges for e in combinations(vs,2)):cs.append(vs)
   return {v for v in cs if not any(set(v)<set(w) for w in cs)}
  assert maximal(r['old_graph'])=={(0,1,2),(2,3),(3,4),(0,4)}
  assert maximal(r['shift_new_graph'])=={(0,1,2),(0,1,4),(2,3),(3,4)}
  old_lam=list(map(F,r['old_lambda']));m=list(map(F,r['old_m']))
  assert sum(m[i]*old_lam[i] for i in range(5))==F(r['new_Q'])
  for K in maximal(r['shift_new_graph']):assert sum(old_lam[i] for i in K)<=1
  assert F(r['epsilon'])*F(r['old_R'])<F(7,2) # Never a critical-F counterexample.
  receipts.append({'H':row['H'],'run':{k:r[k] for k in transient}})
# Whole-path exact net budget, not sum of absolute jump costs.
W,R,Q,Qp,L0,L1,Lret,C,J=S.symbols('W R Q Qp L0 L1 Lret C J')
Z=L1-Lret;B0=L0-Q;B1=Lret-Qp;V=R*Q
res1=S.expand(W-R*Qp-((W-V)-R*(L1-L0)+R*Z+R*(B1-B0)))
res2=S.expand((W-V)-R*(L1-L0)+R*Z+R*(B1-B0)-((W-V)-R*C+R*J+R*Z+R*(B1-B0))).subs(L1,L0+C-J)
u=S.symbols('u');res3=S.expand(S.Rational(9,2)*(u-4)**2-u*(u+1)-(u-8)*(7*u-18)/2)
e,v,q,s2=S.symbols('e v q s2',positive=True)
res4=S.simplify(v+e*s2-((1+e*v/q)*v+e*(s2-v*v/q)))
assert all(S.simplify(x)==0 for x in [res1,res2,res3,res4])
# Rigorous readable consequence of N>=exp(56H/9-1)/9 at H=32.
# exp(.7)>sum_{k=0}^9(.7)^k/k!>2, so exp(56*32/9-1)>2^283.
taylor=sum(F(7,10)**k/factorial(k) for k in range(10))
assert taylor>2 and F(56*32,9)-1>283*F(7,10) and F(2**283,9)>10**84
tex=(root/'REPORT.tex').read_text();stack=[]
for m in re.finditer(r'\\(begin|end)\{([^}]+)\}',tex):
 k,n=m.groups()
 if k=='begin':stack.append(n)
 else:assert stack and stack.pop()==n
assert not stack
receipt={'passed':True,'geometric_cases':len(receipts),'symbolic_identities':4,'whole_subset_graph_audits':len(receipts),'finite_N_H32_lower_gt_10pow':84,'interpreter':sys.executable,'sympy':S.__version__,'report_sha256':hashlib.sha256((root/'REPORT.tex').read_bytes()).hexdigest(),'replay_runs':receipts,'wall_s':time.perf_counter()-start,'latex_structure_only':True}
print(json.dumps(receipt,ensure_ascii=False,indent=2))
