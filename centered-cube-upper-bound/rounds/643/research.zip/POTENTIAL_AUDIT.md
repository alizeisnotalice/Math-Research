# R643 whole-path barrier-deficit 势独审

先按主代理端点定义独立核账，再读 `/tmp/ccu_r643/variational.md`。不重跑数值、不重证 R642。

**判定：完整端点身份及线性路径分解通过。它结算有符号的净变化，不提供根阶净增益。一个需明确的适用限定是：稿中单事件式 (4) 若调用实际 barrier-gap 界，左右必须匹配同一正增量保留族；仅 w 连续不排除零行变化。主端点式不依赖该式跨越零行事件。**

## 1. 端点完整账与 scalar Q

旧 Q 是旧自身正则最优权的 **linear part**。全标签初始 linear capacity L0 与终点实际删零后的 Lret 给

\[
B_0=L_0-Q\in[0,\epsilon V],\quad
B_1=L_{\rm ret}-Q'\in[0,\epsilon W],\quad
J_{\rm del}=L_1-L_{\rm ret}\ge0.
\]

L1 是终点全部原标签的 linear capacity。删零是将那些变量设 0 的 face，故 Lret≤L1；不能把其差漏进“≤εW”的 barrier gap。

由 V=RQ、Q=L0−B0、Q′=L1−Jdel−B1，准确有

\[
\boxed{D=(W-V)-R(L_1-L_0)
+RJ_{\rm del}+R(B_1-B_0).}
\]

只对两个合法正增量端点使用已证 gap 界即可，不需要沿路径定义零增量行的 log barrier。Q 从未被含 log 的总目标替代。

## 2. 实际路径、包含与接触约定

作者使用的是

\[
C_j(t)=Q(y_j+t\delta_jz_j,s_j+t\delta_j),\quad
 d_j(t)=[2(s_j+t\delta_j)]^n.
\]

这是到冻结 moment-volume 动作端点的嵌套 star 路径；不自动是 μ 的 last-strict-bad canonical 半径路径，也不提供额外未来帽。每坐标 lower endpoint 的速度为 δ(z_i−1)≤0，upper 为 δ(z_i+1)≥0，故所有边界 z_i=±1 也合法嵌套。每个 Aj 包含于 Cj(t)，同一旧 μ 给 `μCj(t)≥mj≥d_j(t)`。

真实 positive-volume cliques 单增。每对盒的正交是全部坐标的严格 affine endpoint 条件；box Helly 正确补全高阶 cliques。因此 packing 改变次数有限。

**正确单侧记账：** 若 t_c 是首次边界接触，精确 t_c 的零体积交不加约束，约束只在 t>t_c 正交后加入。应定义右跳信用

\[
L(t_c)-L(t_c+)\ge0,\qquad 0\le t_c<1.
\]

包括可能的 t=0 右跳。若仅在 t=1 闭边界接触，不得收费一个 post-end jump；若终点 clique 正体积，则有限性保证它已在足够近的左侧存在。

大 stars 嵌套并不意味着小 receivers 嵌套：其中心速度仍是 δz，半径速度只有 δ/a。W−V 保持实际有符号值，不能作为自动非负增长。

## 3. chamber 正则性与辅助 linear integral

固定 packing polytope 的每个 chamber 内，L(t) 是其有限顶点对应多项式 `ν·d(t)` 的最大值。不同多项式只有有限交点（恒等者可固定选一个），故 L 分段 C¹、可积导数成立。选择分段顶点最优 ν(t) 即有 a.e.

\[
L'(t)=\sum_j\nu_j(t)\dot d_j(t)\ge0.
\]

只需这份 **辅助线性** ν(t)，不要求实际新 α 沿路光滑、唯一 active face 或 μ 变化可微。

令 C 为这些连续 chamber 变化的积分，J 为第 2 节全部右跳降之和，则

\[
L_1-L_0=C-J,\quad C,J\ge0,
\]

\[
\boxed{D=(W-V)-RC+RJ+RJ_{\rm del}+RB_1-RB_0.}
\]

有限事件数只用于合法精确 telescope；不表示 C、J 的量级已经独立于 N 被支付。没有额外“每个接触一次 M”的乘数，但它们仍是完整未付几何量。

## 4. 零事件与实际 regularized Q 的范围

路径内部新 receiver increments 可能变零或重新分配；本稿 L(t) 始终用全部标签做 linear 优化，因此这些事件不破坏辅助路径分解。实际 barrier 只在旧正 v 端点与终点删零正 w 族求解，处理正确。

作者单事件公式 `Q−−Q+=(L−−L+)+(B+−B−)` 是代数恒等式，但若 B±要使用≤εW 的 bound，需两侧的 L/Q 使用同一保留正标签集；或者把 deletion gap 单列。w 的连续性本身不够，因为零行删除会改变优化维数。主 (1)/(7) 已把 endpoint deletion 另列，且无需将该单事件式应用于内部零行事件，所以这是表述精度要求，不阻断主结算。

同样，端点势控制的是全部 signed net effect；不能宣称它上界了每一个不利 actual-Q 跳跃绝对值之和或 total variation。若只累加有利 activation 而漏掉 B 在 chambers 内的变化，仍会破坏账。

## 5. 初始费用与完整未证步骤

临界 x=εR∈[7/2,4] 只给

\[
0\le RB_0\le xV\le4V.
\]

这确实没有事件次数、λ_min 或尺度数因子，但仍是 V 级负费。因为 `V/M=2PHx/(1+x)`，而 F 要求所有充分大的 H，该负费不能无证改称 CLnM 或可吸收小量。

要达到 F，仍须同一 Z/order 下证明完整正向比较

\[
(W-V)+R(J+J_{\rm del}+B_1)-RC
\ge RB_0+cV-CL_nM.
\]

不能仅用线性 clique jumps 非负、gap 上界或 L1≤M 得出此式；也不能丢正 B1/deletion/source 信用后反过来声称它们无用。

**最终：主势正确、事件与零行范围可清楚限定；尚未得到决定 F 的净收益。上述单事件保留族限定应在使用 (4) 时明确。完成 bounded 独审，停止待候选。**

## 6. 最终 integrated REPORT 限定对照

已对照 `/tmp/ccu_r643_final/REPORT.tex` 最终冻结 SHA256：

`5e90136324fc0e15c5a49161fad581252b2e48307305250437ce52ad47c0a106`。

**限定最终判定通过，无需数学修正。**

- 式 (1)–(2) 正确区分 full-log 最优值与 actual linear part；单事件使用已明确限定为同一 retained 正标签集。
- 式 (3)–(7) 的路径、clique 正体积判据、`[0,1)` 右跳约定、含 t=0/排除 t=1 零面、chamber 积分、final deletion 与 B0/B1 一致，符合本独审。主稿明确只是 signed net effect，不声称不利 jumps 的绝对总变差有界。
- RB0≤4V 保留为 V 级未付费，没有冒称小费用或 root 来源费。νd 与 λd 权的初始势/方差比较也未免费互换。
- counter 只认证四个有限非临界实例；已明确 pre/post 的 linear cap 都等于 M，actual Q 上跳来自 barrier deficit 降低，而非 linear jump。违反新 014 的是 p,q 所给接触前新正则最优权，**不是**仍可行的旧 λ。这个修复消除了权的混淆，没有改变净账。
- source 包熵应用保留真实 Lebesgue receiver 分区、局部 D_K、来源 z_K 和所有尺度。选择≤N个 active 包只是保持旧矩的合法表示；logN 的必要门槛没有被替换成 logn，也没有被报告成一般上界。
- 完整来源批次模板保留共同 Z、全行补偿与同一旧包总支出；不把分别可达当共同实现或把批次/包数当净省。
- F 的全部临界无 universal 家族、所有充分大 H 与统一常数量词仍完整保留；最后章节明确尚缺整条联合预算，没有以 counter、包熵或单势恒等式宣称一般闭合。

本次仅作一致性/适用范围终验，复用前述独证；没有重复数值、修改主稿或 Git 操作。最终核验完成，停止待命。
