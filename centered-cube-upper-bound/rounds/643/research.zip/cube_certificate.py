#!/usr/bin/env python3
from fractions import Fraction as F
from itertools import combinations
from hashlib import sha256
from pathlib import Path
from math import isqrt
import json,time,sys,resource
T=time.perf_counter();cpu=time.process_time();a=64;H=int(sys.argv[1]) if len(sys.argv)>1 else 32;assert H>=32;eps=F(4096,8450*H);c=eps/a**2;z=c/10;N=5
m=[F(1),F(1),1+z,1+z,F(1)];lamold=[F(1,5),F(1,2),F(3,10),F(7,10),F(3,10)];d=[m[i]/(1+c/lamold[i]) for i in range(N)]
bits=max(192,H.bit_length()+128)
def root(q):
 k=isqrt((q.numerator<<2*bits)//q.denominator);l=F(k,2**bits);h=F(k+1,2**bits);assert l*l<=q<h*h;return l,h
S=[tuple(x/2 for x in root(q)) for q in d];R=[tuple(x/2 for x in root(q)) for q in m];D=[(R[i][0]-S[i][1],R[i][1]-S[i][0]) for i in range(N)];assert all(x>0 for x,y in D)
# Exact rational centers. Edge14 old gap lies strictly between 2c and 2c+2^-190.
centers=[(F(0),F(0)),(S[1][1]+S[4][1]+2*c-F(7,10),F(0)),(F(2,5),F(4,5)),(F(1,5),F(8,5)),(F(-7,10),F(4,5))]
old_expected={(0,1),(0,2),(1,2),(2,3),(3,4),(0,4)};new_expected=old_expected|{(1,4)}
def interval_distance(A,B):
 l=A[0]-B[1];h=A[1]-B[0];return (F(0) if l<=0<=h else min(abs(l),abs(h)),max(abs(l),abs(h)))
def graph(ranges,shift,scale=1):
 results={};
 for i,j in combinations(range(N),2):
  per=[]
  for k in range(2):
   Ai=(centers[i][k],centers[i][k]);Aj=(centers[j][k],centers[j][k])
   if shift and k==0:
    if i==1:Ai=(Ai[0]-D[i][1],Ai[1]-D[i][0])
    if i==4:Ai=(Ai[0]+D[i][0],Ai[1]+D[i][1])
    if j==1:Aj=(Aj[0]-D[j][1],Aj[1]-D[j][0])
    if j==4:Aj=(Aj[0]+D[j][0],Aj[1]+D[j][1])
   mn,mx=interval_distance(Ai,Aj);rl=(ranges[i][0]+ranges[j][0])/scale;rh=(ranges[i][1]+ranges[j][1])/scale;per.append((rl-mx,rh-mn))
  if all(lo>0 for lo,hi in per):results[(i,j)]=True
  elif any(hi<0 for lo,hi in per):results[(i,j)]=False
  else:raise ValueError('unresolved contact')
 return {e for e,v in results.items() if v}
assert graph(S,False)==old_expected
assert graph(R,False)==old_expected
assert graph(R,True)==new_expected
assert not graph(S,False,a) and not graph(R,False,a) and not graph(R,True,a)
# Bound the complete t-in-[0,1] path; only edge14 may change.
def path_class(i,j,scale):
 per=[]
 for h in range(2):
  ai=(centers[i][h],centers[i][h]);aj=(centers[j][h],centers[j][h])
  if h==0:
   if i==1:ai=(ai[0]-D[i][1],ai[1])
   if i==4:ai=(ai[0],ai[1]+D[i][1])
   if j==1:aj=(aj[0]-D[j][1],aj[1])
   if j==4:aj=(aj[0],aj[1]+D[j][1])
  mn,mx=interval_distance(ai,aj);per.append(((R[i][0]+R[j][0])/scale-mx,(R[i][1]+R[j][1])/scale-mn))
 if all(lo>0 for lo,hi in per):return True
 if any(hi<0 for lo,hi in per):return False
 return None
for i,j in combinations(range(N),2):
 assert path_class(i,j,a) is False
 if (i,j)!=(1,4):assert path_class(i,j,1)==((i,j) in old_expected)
oldcl=[(0,1,2),(2,3),(3,4),(0,4)];oldZ=[F(1),z,F(1),F(0)]
for i in range(N):
 assert sum(q for q,K in zip(oldZ,oldcl) if i in K)==m[i]
 assert lamold[i]*(m[i]-d[i])==c*d[i]
assert all(sum(lamold[i] for i in K)<=1 for K in oldcl)
assert all(q==0 or sum(lamold[i] for i in K)==1 for q,K in zip(oldZ,oldcl))
# Choose explicit positive source rectangles inside old clique intersections.
source=[]
for K,mass in zip(oldcl,oldZ):
 if not mass:continue
 lr=[]
 for h in range(2):
  left=max(centers[i][h]-S[i][0] for i in K);right=min(centers[i][h]+S[i][0] for i in K);assert left<right;lr.append((left,right))
 mid=[(u+v)/2 for u,v in lr];width=min((v-u)/4 for u,v in lr);assert width>0
 for j in set(range(N))-set(K):assert any(mid[h]+width<centers[j][h]-S[j][1] or mid[h]-width>centers[j][h]+S[j][1] for h in range(2))
 source.append({'old_clique':list(K),'center':list(map(str,mid)),'halfwidth':str(width),'mass':str(mass)})
# Raw new α has only clique012 and edge34 tight. Decoupled variables p,q solve monotone rational equations.
def fp(p):return F(1,10)+(1+z)/p-2/(1-p)
def fq(q):return F(1,10)+(1+z)/q-1/(1-q)
assert fp(F(1,3))>0>fp(F(7,20)) and fq(F(1,2))>0>fq(F(53,100))
assert F(7,20)+F(53,100)==F(22,25)
# After edge14 opens, explicit positive α saturates all four new maximal cliques.
q=(2+z)/(5+2*z);alpha=[(1-q)/2,(1-q)/2,q,1-q,q];newcl=[(2,3),(3,4),(0,1,2),(0,1,4)]
g=[m[i]*(1+c/alpha[i]) for i in range(N)];A=F(1,2);B=g[3]-A;C=g[2]-A;E=g[4]-B;duals=[A,B,C,E]
assert all(x>0 for x in duals) and C+E==g[0]==g[1]
for i in range(N):assert sum(h for h,K in zip(duals,newcl) if i in K)==g[i]
assert all(sum(alpha[i] for i in K)==1 for K in newcl)
M=2+z;Qnew=sum(m[i]*alpha[i] for i in range(N));assert Qnew==M
# ΔQ = z(1-p-q_old) > 3z/25. The regularized optimum value strictly falls
# since the unique raw optimizer violates new 014 by 1-p-q_old>3/25.
V=sum(d)/a**2;Q=sum(lamold[i]*d[i] for i in range(N));Rold=V/Q;W=sum(m)/a**2
result={'dimension':2,'a':a,'H':H,'sqrt_interval_bits':bits,'old_R':str(Rold),'old_V':str(V),'old_Q':str(Q),'new_W':str(W),'D_drop_strict_lower':str(Rold*3*z/25),'epsilon':str(eps),'c':str(c),'z_source':str(z),'old_lambda':list(map(str,lamold)),'old_m':list(map(str,m)),'old_d':list(map(str,d)),'radius_intervals':[[str(a),str(b)] for a,b in S],'rho_intervals':[[str(a),str(b)] for a,b in R],'delta_intervals':[[str(a),str(b)] for a,b in D],'centers':[[str(v) for v in row] for row in centers],'old_source':source,'old_graph':[list(q) for q in sorted(old_expected)],'raw_new_graph':[list(q) for q in sorted(old_expected)],'shift_new_graph':[list(q) for q in sorted(new_expected)],'new_alpha':list(map(str,alpha)),'new_dual':list(map(str,duals)),'raw_new_Q_formula':'M-z(1-p-q), 1/3<p<7/20, 1/2<q<53/100','new_Q':str(Qnew),'delta_Q_strict_lower':str(3*z/25),'W_continuous_and_constant':True,'full_regularized_value_strictly_decreases':True,'cpu_s':time.process_time()-cpu,'wall_s':time.perf_counter()-T,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'python':sys.version,'script_sha256':sha256(Path(__file__).read_bytes()).hexdigest()}
print(json.dumps(result,indent=2))
