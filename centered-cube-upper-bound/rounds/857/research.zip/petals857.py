"""R857: exact physical cross-bin common-source moments, with positive centres."""

from fractions import Fraction as F
from itertools import combinations, product
import sys

from flint import arb, ctx, __version__ as flint_version


SIDES=(F(1),F(5,4),F(3,2),F(7,4))
H=F(1,64)
PAIRS=tuple(combinations(SIDES,2))


def aq(x):
    x=F(x)
    return arb(x.numerator)/x.denominator


def bin_floor(v):
    j=v.numerator.bit_length()-v.denominator.bit_length()
    if F(2)**j>v:
        j-=1
    assert F(2)**j<=v<F(2)**(j+1)
    return j


def geometry(n):
    eps=F(1,128*n)
    # The actual centre coordinates given sign xi are
    # xi*(l/2-h-u), 0<=u<=eps, independently by receiving Lebesgue.
    # This is a true one-sided interior core of positive volume.
    R=tuple(l/2-H for l in SIDES)
    assert all(r-eps>0 for r in R)
    assert all(a< b-eps for a,b in zip(R,R[1:]))
    for l,r in zip(SIDES,R):
        assert eps<l/(64*n)
        assert r+l/2<4 and l-2*H>2*eps
        assert all(-H-u<=-H and H<=l-H-u for u in (F(0),eps))
    # q is any point in the same positive box [-h,h]^n at every bin;
    # the actual witness around every actual centre contains this box.
    bins=tuple(bin_floor(l**n) for l in SIDES)
    assert len(set(bins))==len(SIDES)
    return eps,bins


def p_1d(z,side,sign,eps):
    x=z*sign
    lower=max(F(0),-H-x)
    upper=min(eps,side-H-x)
    return max(F(0),upper-lower)/eps


def knots(side,sign,eps):
    return tuple(sign*x for x in (-H-eps,-H,side-H-eps,side-H))


def integrate(f,edges):
    points=sorted(set(edges))
    return sum((r-l)*(f(l)+4*f((l+r)/2)+f(r))/6
               for l,r in zip(points,points[1:]))


def physical_1d(lo,hi,eps):
    for l,s in product((lo,hi),(-1,1)):
        assert integrate(lambda x:p_1d(x,l,s,eps),knots(l,s,eps))==l
    M={}
    for s,t in product((-1,1),repeat=2):
        edges=knots(lo,s,eps)+knots(hi,t,eps)
        M[s,t]=integrate(lambda x:p_1d(x,lo,s,eps)*p_1d(x,hi,t,eps),edges)
    assert M[1,1]==M[-1,-1]==lo-eps/6
    assert M[1,-1]==M[-1,1]==2*H+eps
    return M[1,1]/lo,M[1,-1]/lo


def hamming_histograms(n):
    words=tuple(range(2**n))
    evens=tuple(w for w in words if w.bit_count()%2==0)
    odds=tuple(w for w in words if w.bit_count()%2)
    full=(0,2**n-1)
    out=[]
    for left,right in ((words,words),(evens,evens),(evens,odds),(full,full)):
        count=[0]*(n+1)
        for s,t in product(left,right):
            count[(s^t).bit_count()]+=1
        law=tuple(F(c,len(left)*len(right)) for c in count)
        assert sum(law)==1
        out.append(law)
    return tuple(out)


def overlaps(n,lo,hi,eps,hist):
    assert lo<hi and (hi-lo)>eps
    a,b=(lo-eps/6)/lo,(2*H+eps)/lo
    assert 0<b<a<1
    avg=((a+b)/2)**n
    bias=((a-b)/2)**n
    even=avg+bias
    odd=avg-bias
    locked=(a**n+b**n)/2
    forced=a**n
    if hist is not None:
        assert physical_1d(lo,hi,eps)==(a,b)
        values=tuple(sum(w*a**(n-k)*b**k for k,w in enumerate(law)) for law in hist)
        assert values==(avg,even,odd,locked)
    assert 0<odd<avg<even<2*avg and avg<F(13,25)**n
    assert F(767,1536)<=locked<forced
    assert F(767,768)<=forced<1
    # Given the same actual q and bin, all sign codes give
    # E[mu(A)] = l^n. For the two independent draws the common true
    # source integral is lo^n times the normalized expectation.
    return avg,even,odd,locked,forced


def replay(n):
    eps,bins=geometry(n)
    hist=hamming_histograms(n) if n<=8 else None
    values={pair:overlaps(n,*pair,eps,hist) for pair in PAIRS}
    print("n",n,"true absolute dyadic exponents",bins,"; each real core volume eps^n, eps",eps)
    print("  Physical q box has mass 2^(-"+str(5*n)+"); each integral p_i is exactly L_i^n.")
    if hist is not None:
        print("  Independent sign-pair enumeration and physical segmentation both checked in every cross-bin pair.")
        print("  Example L=(1,7/4), ratios independent/even-even/even-odd/locked/same sign:",
              values[1,F(7,4)])
    log2=arb(2).log()
    print("  Ranges over all six actual bin pairs, log2 normalized intersections:")
    labels=("iid signs","even-even","even-odd","locked coordinates, independent parents",
            "forced same signs, independent core jitter")
    for k,label in enumerate(labels):
        numbers=[row[k] for row in values.values()]
        low,high=min(numbers),max(numbers)
        print("   ",label,(aq(low).log()/log2).str(9),(aq(high).log()/log2).str(9))
    key=(F(3,2),F(7,4))
    base=values[key][0]
    actual=key[0]**n*base
    assert actual>0
    print("  Pair (3/2,7/4) actual iid common source integral",
          aq(actual).str(9),"; same sign probability under original iid law 2^(-"+str(n)+").")


if __name__=="__main__":
    ctx.prec=192
    print("Python",sys.version.split()[0],"python-flint",flint_version,"| exact Fraction and 192-bit Arb")
    print("True mu uniform density 1 on [-4,4]^n. Each comparison uses the same actual q in a positive common box.")
    print("Fixed bin probabilities condition on a real q; signs independent between the two parents unless explicitly coupled.")
    print("All actual receiving cores are mutually disjoint; physical jitter is retained in every integral.")
    for dim in (4,8,64,256,1024):
        replay(dim)
    print("All assertions passed. Scope: positive-width middle-parent geometry; the R813 old parents and degree are uninstantiated.")
