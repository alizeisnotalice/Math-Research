"""Validate a complete R857 release and byte-replay its four local experiments."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
from tempfile import TemporaryDirectory
from zipfile import ZipFile

PARENTS = {
    "814": "891d8cbcbd35537e6abc18c938e53b1b4f300327357c24c8d14a51a46ad5e190",
    "856": "16496077ed6ce4e48816dfb70d93a8251885db6ff03e033a3109eaa6e2f13fbb",
}
RUNS = {"cross857": True, "twin857": True, "petals857": False, "trim857": False}
SCRIPTS = {program + ".py" for program in RUNS}
MEMBERS = {"REPORT.tex", "replay857.py"} | SCRIPTS | {program + ".txt" for program in RUNS}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def read_distinct(pairs):
    result = dict(pairs)
    require(len(result) == len(pairs), "duplicate JSON keys")
    return result


def read_release(archive):
    with ZipFile(archive) as z:
        names = z.namelist()
        require(len(names) == len(MEMBERS) + 1 and set(names) == MEMBERS | {"MANIFEST.json"},
                "unexpected or duplicate archive member")
        require(z.testzip() is None, "archive CRC check failed")
        manifest = json.loads(z.read("MANIFEST.json"), object_pairs_hook=read_distinct)
        files = {name: z.read(name) for name in MEMBERS}
    require(set(manifest) == {"round", "parents", "sha256"} and type(manifest["round"]) is int
            and manifest["round"] == 857 and manifest["parents"] == PARENTS,
            "unexpected manifest or parent data")
    require(manifest["sha256"] == {name: digest(body) for name, body in files.items()},
            "archive member SHA mismatch")
    return files


def verify_parents(rounds):
    for number, pin in PARENTS.items():
        path = rounds / number / "research.zip"
        require(digest(path.read_bytes()) == pin, "parent hash mismatch " + str(path))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--rounds", required=True, type=Path)
    parser.add_argument("--work", required=True, type=Path)
    parser.add_argument("--archive", required=True, type=Path)
    args = parser.parse_args()
    rounds = args.rounds.resolve(strict=True)
    work = args.work.resolve(strict=True)
    archive = args.archive.resolve(strict=True)
    verify_parents(rounds)
    files = read_release(archive)
    require(Path(__file__).read_bytes() == files["replay857.py"], "driver differs from archived driver")
    print("Python", sys.version.split()[0], "archive SHA-256", digest(archive.read_bytes()), flush=True)
    env = dict(os.environ)
    for key in ("PYTHONPATH", "PYTHONHOME", "PYTHONOPTIMIZE"):
        env.pop(key, None)
    for key in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS",
                "VECLIB_MAXIMUM_THREADS", "NUMEXPR_NUM_THREADS"):
        env[key] = "1"
    with TemporaryDirectory(prefix="replay857-", dir=work) as tmp:
        clean = Path(tmp)
        for name in SCRIPTS:
            (clean / name).write_bytes(files[name])
        for program, uses_parents in RUNS.items():
            args = [sys.executable, "-B", "-s", program + ".py"]
            if uses_parents:
                args.extend(["--rounds", str(rounds)])
            result = subprocess.run(args, cwd=clean, env=env, capture_output=True, timeout=180)
            require(result.returncode == 0 and not result.stderr,
                    f"{program} exit {result.returncode}: {result.stderr.decode(errors='replace')}")
            expected = files[program + ".txt"]
            require(result.stdout == expected,
                    f"{program} stdout SHA {digest(result.stdout)} vs archive {digest(expected)}")
            print(f"{program}: exit 0, {len(expected)} stdout bytes verified", flush=True)
        require({p.name for p in clean.iterdir()} == SCRIPTS, "unexpected replay output files")
        require(all((clean / n).read_bytes() == files[n] for n in SCRIPTS), "script changed during replay")
    require(not clean.exists(), "temporary replay directory survived")
    verify_parents(rounds)
    print("Four complete outputs matched; all child processes exited; temporary directory removed.")


if __name__ == "__main__":
    main()
