"""Exact same-side twin reconstruction and common right-to-right menu audit."""
from argparse import ArgumentParser
from collections import defaultdict
from fractions import Fraction as F
from hashlib import sha256
from itertools import product
from pathlib import Path
from zipfile import ZipFile
import json
import sys

PIN856 = "16496077ed6ce4e48816dfb70d93a8251885db6ff03e033a3109eaa6e2f13fbb"


def total(weights):
    return sum(weights, F(0))


def dependencies(rounds):
    path = rounds / "856" / "research.zip"
    assert sha256(path.read_bytes()).hexdigest() == PIN856
    with ZipFile(path) as archive:
        assert archive.testzip() is None
        entries = json.loads(archive.read("MANIFEST.json"))["sha256"]
        modules = []
        for name in ("anchor856.py", "matching856.py"):
            src = archive.read(name)
            assert sha256(src).hexdigest() == entries[name]
            env = {"__name__": "twin857_input_dependency", "__file__": name}
            exec(compile(src, name, "exec"), env)
            modules.append(env)
    anchor, matching = modules
    stage, q95 = anchor["load"](rounds / "814" / "research.zip")
    parents, _, _, _, _, _, lam, _, raw, _, _ = anchor["reconstruct"](stage, q95)
    assert len(raw) == 920
    return parents, lam, raw, q95, anchor["PIN"], anchor["outward"], matching["maximum_assignment"]


def twin_law(raw, parents, old_cell):
    left_conditional = defaultdict(lambda: defaultdict(F))
    old_by_D = defaultdict(F)
    for (t, x, a), weight in raw.items():
        assert parents[x[0]]["volume_bin"] != parents[a[0]]["volume_bin"]
        assert all(F(1) <= parents[s]["radius"] < 2 for s in (t, x[0], a[0]))
        left_conditional[t, x][a] += weight
        old_by_D[parents[t]["volume_bin"], x, a] += weight
    records = {}
    new_by_D, table = defaultdict(F), defaultdict(F)
    marg0, marg1 = defaultdict(F), defaultdict(F)
    q_pair = F(0)
    for (t, x), row in left_conditional.items():
        m = total(row.values())
        D = parents[t]["volume_bin"]
        assert m > 0
        for (a, u), (b, v) in product(row.items(), repeat=2):
            weight = u * v / m
            assert weight > 0
            records[t, x, a, b] = weight
            marg0[t, x, a] += weight
            marg1[t, x, b] += weight
            new_by_D[D, a, b] += weight
            table[a, b] += weight
            if a[1] == b[1] == 95:
                q_pair += weight
    assert marg0 == marg1 == raw
    assert total(records.values()) == total(raw.values()) == total(table.values())
    assert total(new_by_D.values()) == total(old_by_D.values()) == total(raw.values())
    q1 = total(w for (t, x, a), w in marg0.items() if a[1] == 95)
    assert q1 == F(old_cell["subflow_original_mass"])
    assert 0 < q_pair < q1
    target = next((key, w) for key, w in sorted(records.items())
                  if (key[2][0], key[2][1], key[2][2]) == (key[3][0], 95, 0)
                  and key[3][1:] == (95, 1))
    (t, x, a, b), value = target
    assert a[0] == b[0] and a[1] == b[1] == 95 and a[2] != b[2]
    assert parents[x[0]]["volume_bin"] != parents[a[0]]["volume_bin"] == parents[b[0]]["volume_bin"]
    assert (raw[t, x, a] * raw[t, x, b]
            / total(left_conditional[t, x].values())) == value
    return records, new_by_D, old_by_D, table, left_conditional, q1, q_pair, target


def domination(by_D, lam, fmt):
    columns = defaultdict(list)
    for (D, a, b), weight in by_D.items():
        reference = lam[a] * lam[b] / D
        assert 0 < reference
        columns[D].append((weight / reference, a, b))
    for D, values in sorted(columns.items()):
        low, high = min(values), max(values)
        print("  D", D, "positive cells", len(values), "min/max ratio to true lambda(a)lambda(b)/D",
              fmt(low[0], high[0]), "; ratio>1 count", sum(value > 1 for value, _, _ in values),
              "; max pair", high[1:])


def verify_receivers(parents, records, menu):
    whole = [defaultdict(F), defaultdict(F), defaultdict(F)]
    paid = [defaultdict(F), defaultdict(F), defaultdict(F)]
    for (t, x, a, b), weight in records.items():
        allow = (a, b) in menu
        for j, branch in enumerate((x, a, b)):
            point = branch[0], branch[2]
            whole[j][point] += weight
            if allow:
                paid[j][point] += weight
    actual = total(w for (_, _, a, b), w in records.items() if (a, b) in menu)
    for j in range(3):
        assert total(paid[j].values()) == actual
        for (s, half), mass in whole[j].items():
            assert paid[j][s, half] <= mass <= parents[s]["owner_volume"] / 2
    return actual


def public_menus(records, table, conditional, parents, assignment, fmt):
    true_total = total(records.values())
    # Even when labels coincide, both points are still independent continuous
    # original observations. The diagonal label matching is admissible.
    assert all(a == b or 2 * value <= table[a, a] + table[b, b] for (a, b), value in table.items())
    diagonal = total(v for (a, b), v in table.items() if a == b)
    maximum, menu, _ = assignment(table)
    assert maximum == diagonal == verify_receivers(parents, records, menu)
    temporary = total(total(v ** 2 for v in x.values()) / total(x.values())
                      for x in conditional.values())
    assert temporary == maximum
    print("  diagonal-compatible common max vs temporary optimum:",
          fmt(maximum / true_total), fmt(temporary / true_total),
          "; exact match cardinality", len(menu))
    # The independent half law allows a common permutation even if the
    # full observed labels must differ. Two real positions remain distinct a.s.
    half_swap = frozenset((a, (a[0], a[1], 1 - a[2])) for a, b in menu)
    assert verify_receivers(parents, records, half_swap) == maximum
    for field, keep in (
        ("distinct-observed-label", lambda a, b: a != b),
        ("distinct-price-cell", lambda a, b: a[1] != b[1]),
    ):
        different = {key: value for key, value in table.items() if keep(*key)}
        fixed, alternative, _ = assignment(different)
        assert fixed == verify_receivers(parents, records, alternative)
        locals_ = defaultdict(lambda: defaultdict(F))
        for (t, x, a, b), mass in records.items():
            if keep(a, b):
                locals_[t, x][a, b] += mass
        private = total(assignment(row)[0] for row in locals_.values())
        assert fixed <= private <= total(different.values())
        if field == "distinct-observed-label":
            assert fixed == private == maximum
        print(" ", field, "diagnostic, common/temporary/unconstrained shares:",
              *(fmt(x / true_total) for x in (fixed, private, total(different.values()))))
    print("  All menus preserve first U and both separate true W half-box capacities.")


if __name__ == "__main__":
    parser = ArgumentParser()
    parser.add_argument("--rounds", required=True, type=Path)
    arg = parser.parse_args()
    parents, lam, raw, old95, pin814, fmt, assign = dependencies(arg.rounds)
    records, new, old, table, by_left, q1, q_pair, stress = twin_law(raw, parents, old95)
    print("Python", sys.version.split()[0], "Fraction exact; old archive pins:", pin814, PIN856)
    print("R814 original active-arm diagnostic, 4D same physical window [1,2),")
    print("two distinct original small-parent bins on each old left/right branch; large-J and original long-jump gates untested.")
    print("BASELINE: both complete (t,X,right) marginals agree term by term with 920 original records.")
    print("  frozen left histories", len(by_left), "; positive real product terms", len(records))
    print("  Original left/right:")
    domination(old, lam, fmt)
    print("  New right/right:")
    domination(new, lam, fmt)
    local_ratios = defaultdict(list)
    for (t, x, a, b), w in records.items():
        D = parents[t]["volume_bin"]
        local_ratios[D].append(w * D / (lam[a] * lam[b]))
    print("  max Xi ratio of a single full-xi product term:",
          [(D, fmt(max(row))) for D, row in sorted(local_ratios.items())])
    (t, x, a, b), paid = stress
    print("STRESS: same q=95 cell, actual complete histories (t,X,right,right):", t, x, a, b)
    print("  original arm masses on this same left history, twin share term, Xi ratio:",
          fmt(raw[t, x, a]), fmt(raw[t, x, b]), fmt(paid),
          fmt(paid * parents[t]["volume_bin"] / (lam[a] * lam[b])))
    print("  old left/right small-parent bins", parents[x[0]]["volume_bin"], parents[a[0]]["volume_bin"],
          "; new right/right bins", parents[a[0]]["volume_bin"], parents[b[0]]["volume_bin"])
    print("  marginal q95 mass, both-q95 mass divided by original marginal:",
          fmt(q1), fmt(q_pair / q1))
    print("FULL: one right-to-right maximum partial matching with original weights.")
    public_menus(records, table, by_left, parents, assign, fmt)
