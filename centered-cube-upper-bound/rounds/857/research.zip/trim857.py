"""R857: finite Minkowski-volume identity and deleted-axis bound.

For each set of exterior coordinates the excesses form a simplex.
A separate computation integrates the last coordinate as a physical
slice and evolves its polynomial in the L1 radius.

For the deleted-axis bound, pad the exceptional coordinates to
exactly k. Each freed coordinate has ambient width at most 3b.
The remaining cube-plus-L1-ball has dilation argument 2sR/b<=s.
The factorial majorant follows by comparing the diagonal sum
sum_j (ns)^j/(j!)^2 with the square of exp(sqrt(ns)).
"""

from fractions import Fraction as F
from itertools import product
from math import comb, factorial
import sys

from flint import arb, ctx, __version__ as flint_version


def aq(value):
    x=F(value)
    return arb(x.numerator)/x.denominator


def simplex_sum(d,b,r):
    return b**d*sum(F(comb(d,j),factorial(j))*(2*r/b)**j for j in range(d+1))


def slice_polynomial(d,b):
    # With V_{d-1} as a polynomial of r, slicing the last coordinate
    # contributes b*V plus the two integrals of V along the exterior rays.
    co=[F(1)]
    for _ in range(d):
        new=[F(0)]*(len(co)+1)
        for j,v in enumerate(co):
            new[j]+=b*v
            new[j+1]+=2*v/(j+1)
        co=new
    return tuple(co)


def evaluate(co,r):
    total=F(0)
    for v in reversed(co):
        total=total*r+v
    return total


def low_dimensions():
    checks=0
    for d,b,s,f in product(range(7),(F(1),F(3,2),F(5,3),F(2)),
                           (F(0),F(1,16),F(1),F(3,2)),(F(1,2),F(1,3))):
        R=f*b
        assert b>=2*R
        r=s*R
        assert evaluate(slice_polynomial(d,b),r)==simplex_sum(d,b,r)
        checks+=1
    assert checks==224
    print("Exact physical slicing and exterior-simplex sum agree on",checks,"rational cases (d=0..6).")
    print("  b=1, sR=1/16, d=1,2,3:",
          tuple(simplex_sum(d,F(1),F(1,16)) for d in (1,2,3)))

    tests=0
    # Fixed set of k deleted coordinates: the complementary ambient
    # widths are bounded by 3b. Use exactly k sets after padding.
    for n,b,s,k in product((2,3,4,6),(F(1),F(5,4)),(F(1,8),F(3,5)),(0,1,2)):
        assert k<=n
        R=b/2
        V=(3*b)**k*simplex_sum(n-k,b,s*R)
        union=comb(n,k)*V
        exponential=(2*(aq(n*s)).sqrt()).exp()
        bound=aq(b**n*(3*n)**k)*exponential
        assert aq(union)<bound
        tests+=1
    assert tests==48
    print("48 exact fixed-deletion products with Arb verification of the padded exponential union bound.")


def huge_dimensions():
    ctx.prec=192
    print("Arb at 192 bits. N=n+2, J=sqrt(n)*ln(N)^8, s=J^2/(1024n).")
    print("For every allowed k, divide the exponent by J: -15/16 + k*ln(3n)/J.")
    print("Upper bound using k<=J/(32ln N): -15/16 + ln(3n)/(32ln N) <= -7/8.")
    print("Window-capacity diagnostic uses C=1 and D <= (4R)^n, so it requires J/n <= ln 2.")
    for p in (64,96,98,100,102,128,256,512,4096):
        n=2**p
        N=n+2
        logn=arb(N).log()
        sqrt_n=arb(2)**(p//2)
        J=sqrt_n*logn**8
        s=J**2/(1024*arb(n))
        k_bound=J/(32*logn)
        assert (2*(arb(n)*s).sqrt()/J).overlaps(arb(1)/16)
        assert 3*n < N**2
        assert 0<k_bound
        if k_bound>n:
            effective=arb(n)
        else:
            assert k_bound<n
            effective=k_bound
        low=-arb(15)/16
        worst=low+effective*(3*arb(n)).log()/J
        analytic=low+(3*arb(n)).log()/(32*logn)
        assert worst< -arb(7)/8 and analytic< -arb(7)/8
        ratio=J/arb(n)
        ln2=arb(2).log()
        suitable=ratio<ln2
        assert suitable or ratio>ln2
        # All printed bounds are on normalized exponents; no enormous
        # factorial, exp(-J), source set or dimension array is formed.
        print("  n=2^"+str(p),"J/n",ratio.str(9),"; nominal k/n",(k_bound/n).str(9),
              "; s",s.str(8))
        print("     exponent/J lower",low.str(8),"upper at allowed k",worst.str(11),
              "; window capacity", "possible at sufficient D" if suitable else "infeasible for illustrative C=1")


if __name__=="__main__":
    ctx.prec=192
    print("Python",sys.version.split()[0],"python-flint",flint_version,"| Fraction and 192-bit Arb")
    low_dimensions()
    huge_dimensions()
    print("All assertions passed. For b >= 2R and b^n <= C D exp(-J), the union volume is at most C D exp(-7J/8).")
