"""Exact cross-bin true-source overlap conditioned on actual archived right data."""
from argparse import ArgumentParser
from collections import defaultdict
from fractions import Fraction as F
from hashlib import sha256
from itertools import product
from math import isqrt
from pathlib import Path
from zipfile import ZipFile
import json
import sys

PIN856 = "16496077ed6ce4e48816dfb70d93a8251885db6ff03e033a3109eaa6e2f13fbb"


def total(values):
    return sum(values, F(0))


def load(rounds):
    source = rounds / "856" / "research.zip"
    assert sha256(source.read_bytes()).hexdigest() == PIN856
    with ZipFile(source) as bundle:
        assert bundle.testzip() is None
        manifest = json.loads(bundle.read("MANIFEST.json"))["sha256"]
        loaded = []
        for name in ("anchor856.py", "shared856.py"):
            script = bundle.read(name)
            assert sha256(script).hexdigest() == manifest[name]
            env = {"__name__": "cross857_fixture", "__file__": name}
            exec(compile(script, name, "exec"), env)
            loaded.append(env)
    old_path = rounds / "814" / "research.zip"
    anchor, shared = loaded
    assert sha256(old_path.read_bytes()).hexdigest() == anchor["PIN"]
    stage, q95 = anchor["load"](old_path)
    parents, _, source, _, _, _, _, _, raw, _, _ = anchor["reconstruct"](stage, q95)
    return parents, source, raw, q95, anchor, shared


def groups(raw, parents):
    q_table = defaultdict(lambda: defaultdict(lambda: defaultdict(F)))
    right_table = defaultdict(lambda: defaultdict(lambda: defaultdict(F)))
    for (t, left, right), mass in raw.items():
        u = left[0]
        g, q, half = right
        assert all(1 <= parents[x]["radius"] < 2 for x in (t, u, g))
        assert q & parents[g]["bit"] and q & parents[t]["bit"]
        D = parents[t]["volume_bin"]
        assert D <= parents[t]["m"] < 2 * D
        q_table[q][D][t, u] += mass
        right_table[g, q, half][D][t, u] += mass
    assert total(raw.values()) == total(w for levels in q_table.values()
                                             for items in levels.values() for w in items.values())
    assert total(raw.values()) == total(w for levels in right_table.values()
                                             for items in levels.values() for w in items.values())
    for q, levels in q_table.items():
        for D, t_rows in levels.items():
            for key, row_mass in t_rows.items():
                assert row_mass == total(xs[D].get(key, 0) for (_, w, _), xs in right_table.items()
                                         if w == q and D in xs)
    return q_table, right_table


def records(weights, src, parents):
    mass = total(weights.values())
    actual = {root: amount / mass for root, amount in weights.items()}
    by_t = defaultdict(F)
    for (t, _), fraction in actual.items():
        by_t[t] += fraction
    assert total(by_t.values()) == 1
    coverage = {w: total(p for t, p in by_t.items() if w & parents[t]["bit"]) for w in src}
    return mass, actual, coverage


def half_exact(cost_function, density, src, summed):
    cost = cost_function(src, density, 1, summed)
    already = F(0)
    threshold = None
    for w in sorted(density, key=density.get, reverse=True):
        value = density[w]
        if already + value * src[w] >= summed / 2:
            threshold = value
            break
        already += value * src[w]
    assert threshold and cost <= total(src[w] for w in density if density[w] > 0)
    dual_gain = total(src[w] * max(0, z - threshold) for w, z in density.items())
    # Any proposed mass C carries at most threshold*C + dual_gain.
    assert cost * threshold + dual_gain == summed / 2
    return cost


def calculate_pair(low, high, src, parents, cost_function):
    a, law_a, p_a = low
    b, law_b, p_b = high
    density = {w: p_a[w] * p_b[w] for w in src}
    overlap = total(src[w] * value for w, value in density.items())
    verify = norm = normal = best_pair = F(0)
    fixed = defaultdict(F)
    for ((t, u), weigh_a), ((s, v), weigh_b) in product(law_a.items(), law_b.items()):
        both = parents[t]["bit"] | parents[s]["bit"]
        true_intersection = total(weight for w, weight in src.items() if w & both == both)
        denom = min(parents[t]["m"], parents[s]["m"])
        current = weigh_a * weigh_b
        verify += current * true_intersection
        norm += current * true_intersection / denom
        need = both | parents[u]["bit"] | parents[v]["bit"]
        actual = [w for w in src if w & need == need]
        normal += current * total(src[w] for w in actual) / denom
        best_pair += current * max((src[w] for w in actual), default=F(0)) / denom
        for w in actual:
            fixed[w] += current * src[w] / denom
    wbest, fixed_cost = max(fixed.items(), key=lambda z: (z[1], -z[0]), default=(None, F(0)))
    assert verify == overlap > 0 and 0 <= fixed_cost <= best_pair <= normal <= norm <= 1
    return {
        "mass_pair": a * b, "overlap": overlap, "actual": norm, "left_all": normal,
        "per_pair": best_pair, "fixed": fixed_cost, "fixed_cell": wbest,
        "fixed_scores": dict(fixed),
        "cost": half_exact(cost_function, density, src, overlap),
    }


def sqrt_interval(z):
    assert z >= 0
    base = 2 ** 52
    l = F(isqrt((z.numerator * base ** 2) // z.denominator), base)
    h = l if l ** 2 == z else l + F(1, base)
    assert l ** 2 <= z <= h ** 2
    return l, h


def spectrum(a, c, b, D_i, D_j):
    a, b = a / D_i, b / D_j
    cross_square = c ** 2 / (D_i * D_j)
    assert a * b >= cross_square
    lo, hi = sqrt_interval((a - b) ** 2 + 4 * cross_square)
    return ((max(F(0), (a + b - hi) / 2), (a + b - lo) / 2),
            ((a + b + lo) / 2, (a + b + hi) / 2))


def audit(table, src, parents, cost_function):
    output = {}
    same = []
    for key, levels in sorted(table.items()):
        laws = {D: records(rows, src, parents) for D, rows in levels.items()}
        diagonal = {}
        for D, law in laws.items():
            diag = calculate_pair(law, law, src, parents, cost_function)
            diagonal[D] = diag
            same.append((key, D, diag))
        assert len(laws) in (1, 2)
        if len(laws) == 2:
            D, E = sorted(laws)
            cross = calculate_pair(laws[D], laws[E], src, parents, cost_function)
            eig = spectrum(diagonal[D]["overlap"], cross["overlap"], diagonal[E]["overlap"], D, E)
            output[key] = (D, E, cross, eig)
    return same, output


def brief(key, row, fmt):
    D, E, result, roots = row
    print(" ", key, "D", D, E, "cross/minD", fmt(result["overlap"] / D),
          "true smaller-m mean", fmt(result["actual"]),
          "half-introduction cost/minD", fmt(result["cost"] / D),
          "Gram eigenvalues", [fmt(lo, hi) for lo, hi in roots])
    print("    genuine common left-support / choose one after both histories / fixed one:", *(
          fmt(result[name]) for name in ("left_all", "per_pair", "fixed")),
          "; fixed left cell", result["fixed_cell"])


def summarize(rows, src, parents, full_arm, fmt):
    weights = []
    for key, (D, _, row, _) in rows.items():
        if full_arm:
            g, q, _ = key
            base = src[q] * parents[g]["owner_volume"] / 2
        else:
            base = src[key]
        weights.append((row["mass_pair"] / base, D, row))
    z = total(w for w, _, _ in weights)
    assert z > 0
    print("  weighted by independent original pairs on the shared observation reference:",
          "cross/minD", fmt(total(w * r["overlap"] / D for w, D, r in weights) / z),
          "true smaller-m", fmt(total(w * r["actual"] for w, _, r in weights) / z),
          "half cost/minD", fmt(total(w * r["cost"] / D for w, D, r in weights) / z))
    print("  weighted common-left / per-history best / fixed-one:",
          *(fmt(total(w * r[name] for w, _, r in weights) / z)
            for name in ("left_all", "per_pair", "fixed")))


if __name__ == "__main__":
    parser = ArgumentParser()
    parser.add_argument("--rounds", type=Path, required=True)
    args = parser.parse_args()
    parents, src, raw, q95, anchor, shared = load(args.rounds)
    q_table, right_table = groups(raw, parents)
    fmt = anchor["outward"]
    same, cross = audit(q_table, src, parents, shared["half_cost"])
    same_arm, cross_arm = audit(right_table, src, parents, shared["half_cost"])
    assert sum(cross0 for x in q_table[95].values() for cross0 in x.values()) == F(q95["subflow_original_mass"])
    print("Python", sys.version.split()[0], "exact Fraction and dyadic Gram isolation.")
    print("R856/R814 pinned SHA-256:", PIN856, anchor["PIN"])
    print("Original 4D, 920 positive components, true radius octave [1,2), G=A.")
    print("Same-group parents sampled independently according to original masses; diagonals include iid same bin.")
    print("The left choice must be a true price cell in BOTH actual middle/small-parent intersections.")
    print("BASELINE: all positive q groups", len(q_table), "; q/bin rows", len(same),
          "; positive two-bin q groups", len(cross))
    for key, D, row in same:
        print("  diagonal q,D", key, D, "Gram", fmt(row["overlap"] / D),
              "true smaller-m mean", fmt(row["actual"]))
    for key, row in cross.items():
        brief(key, row, fmt)
    summarize(cross, src, parents, False, fmt)
    print("STRESS q=95: retained q original mass", fmt(F(q95["subflow_original_mass"])))
    brief(95, cross[95], fmt)
    print("FULL RIGHT ARM (g,q,W actual half):", len(right_table), "positive groups,",
          len(same_arm), "q/bin rows and", len(cross_arm), "two-bin groups")
    diagonal_values = [data["overlap"] / D for _, D, data in same_arm]
    print("  full-arm Gram diagonal range:", fmt(min(diagonal_values), max(diagonal_values)))
    for key, row in cross_arm.items():
        brief(key, row, fmt)
    summarize(cross_arm, src, parents, True, fmt)
    aggregate = inherited = reselected = F(0)
    for (g, q, half), (_, _, args, _) in cross_arm.items():
        frozen = cross[q][2]["fixed_cell"]
        keep = args["fixed_scores"].get(frozen, F(0))
        assert keep <= args["fixed"]
        weight = args["mass_pair"] / (src[q] * parents[g]["owner_volume"] / 2)
        aggregate += weight
        inherited += weight * keep
        reselected += weight * args["fixed"]
    print("  same full-arm draw: inherited fixed-q cell / refit after reading the full right arm:",
          fmt(inherited / aggregate), fmt(reselected / aggregate))
    print("Finite archived comb with exactly two central volume bins; full high-dimensional history is untested.")
