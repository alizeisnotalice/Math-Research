# R171 独立极值几何审计

责任范围：本文件；无 Git、无额外代理、不改作者文件。先只读本轮 task_contract，以下作者前检查点不借作者结论。一般正 L1 根阶上界仍未闭合。

## 1. 作者前检查点：Gamma 的正确归一化

固定同一输入 f、原冻结来源 nu≤beta≤f dx、receiver x 与原 block/j，q 和当前 p_y 对所有 y 共同。置

    M_x(dy)=p_y beta(dy)/q,     M_x(Y)≤1.

M 是子概率，不把 beta 或 nu 归一化。high 上 p_y>0、e_g>0、e_t≥e_g，且

    eta_t(y)=2Kq/(p_y e_t(y))≤1.

令 R_t=wt/wg。合同 Gamma 满足准确式

    Gamma_t(x,v)
      =(1/(2K)) integral M_x(dy) 1_H eta_t(y) R_t(y,v).

所以 unweighted high column 只控制同式的 `1_Z wt`；它不控制额外的 `1/wg`。原 filtered 项实际还可保留 `1_G(y,v)`，因为 G⊂Zg⊂Zt；上放时丢掉该门是合法正放松，但不能同时宣称保留了由此门提供的几何。

直接可得的正确比较是

    Gamma_t≤(1/(2K)) integral M_x 1_H R_t
            ≤sup_(y∈H) R_t(y,v)/(2K).

xi_t、xi_g∈[1/2,1] 时逐坐标比≤2，故至多有粗界 2^n/(2K)，不是根阶。当 xi_t≤xi_g，精确逐坐标比为：C_i≥xi_g 时1；xi_t≤C_i<xi_g 时xi_g/C_i；C_i<xi_t 时xi_g/xi_t。不能把近阈值计数、当前 wt 的 overlap 缺失或 high 归一化直接当成终端 wg 的下界。

对固定 x,v，high column 的 saturation deficit 的五项分解全部非负，使用的是同一个 M_x、同一 H/eta_t/支持/wt。尤其它只把小 `1-wt` 放在原 `M_x H eta_t 1_Z` 上；不自动控制后来更小的 wg，也不能把几个不同 y/v/时间的近等号分别实现后拼成一行。没有独立坐标假设。

## 2. 正对偶包络需要的共同测试量词

记合法共同 future menu

    Theta_x={(u,Lprime): s(x)≤u≤1, a≤Lprime≤b}.

其每个测试在同一 f、同一 x 上均有 `integral P_theta(x-y) beta(dy)≤q`。因此一个充分且可直接核查的正包络是：对固定 x,v,t，存在正有限测度 sigma_(x,v,t) 在 Theta_x 上，使

    1_H eta_t(y) R_t(y,v)
      ≤ integral [P_theta(x-y)/p_y] sigma_(x,v,t)(dtheta)

对 M_x-a.e. y 成立。只需在 p_y>0 的 high 上比较；p=0 的行左边为0，不能无定义地相除。sigma 可以依赖共同输入、原来源、x、v、t 和既定 block，但在此 y 积分中必须是同一个测度。然后 Tonelli 和共同 FIRST 严格给

    Gamma_t(x,v)≤||sigma_(x,v,t)||/(2K).

如果每个 y 自选 sigma_y 或 future 核，逐个 FIRST 上界不能逐 y 积分后仍只领一个 q。若改用 sup_theta P_theta，须显式使用并支付已证连续菜单容量；R168 的 Bernstein 平均加尺度网格给 e(n+1)(n+2)q，而不是 q。若用有限正包络，则支付全部正系数和节点数；不能把 signed 抵消当作正包络。

来源 v 依赖的共同包络是允许的：每个固定 v 先完成同一 y 积分，再正积分 v。可是其总质量 B(x,v,t) 必须在实际 `J_b(x-v) dx nu(dv)` 下支付；把 B 改名为 Gamma 或“极值常数”不构成估计。任何 sup/可测选择都要对同一菜单、有共同来源和可测总质量成立。

## 3. 真正边界包含 y 依赖的原删除测度

固定完整原行，A=1_G rho chiJ 在辅助时间内冻结。记原实际区间端点为 ell,r，使用原单侧值，定义正原子测度

    kappa_y(dt)=delta_(ell+)(dt)/e_(ell+)(y)
                +sum_(ell<t<r) Delta(1/e_t(y)) delta_t(dt).

kappa 含初始原子与每次真实删除的倒数跳；它不是 dt/t，也不是可随意换成共同时间分布的概率。原单调性给

    ||kappa_y||≤1/e_g(y),
    khat_y=e_g(y)kappa_y,  ||khat_y||≤1.

A 的分子在删除时不损失来源；在连续段随 wt 下降。因此精确边界量为

    B_y=F_(ell+)+sum Delta F
       =integral_G A(v) [integral wt(y,v) kappa_y(dt)] nu(dv).

good 给

    p_y B_y≤(K/3) integral J_b(x-v)1_G(y,v)
                               [integral R_t(y,v)kappa_y(dt)] nu(dv).

所以需要控制的真正联合列是

    mathcalGamma(x,v)=integral_H beta(dy)1_G(y,v)
                                 integral R_t(y,v)kappa_y(dt)
      =(1/(2K)) integral M_x(dy)1_H eta_g(y)1_G(y,v)
                                 integral R_t(y,v)khat_y(dt).

这个等式没有遗漏初始项、et、eg 或删除原子。单独对每个固定 t 的 Gamma_t 给界，不能自动给该量同样的界：kappa_y 随 y 改变，甚至删除时刻也随 y。交换积分只能得到原 joint measure `beta(dy)kappa_y(dt)`，不能改成 `beta(dy)` 乘一个共同免费时间测度。对每个 t 选择不同 future 包络后再按 y 自适应 khat_y 混合，也可能变成上述禁止的逐 y 测试。

一个足够的合法新包络必须对整个表达式共同成立，例如

    1_H eta_g(y)1_G(y,v) integral R_t(y,v)khat_y(dt)
      ≤ integral [P_theta(x-y)/p_y] sigma_(x,v)(dtheta),

其中同一 sigma_(x,v) 独立于 y。由此才得 `mathcalGamma≤||sigma||/(2K)`。统一 R_t≤exp(M) 是其最简单现有特例，恢复旧 exp(M) 费用；本轮若要替代它，必须给出新的总质量估计或真实 signed 补偿。

## 4. 从合法包络到真实 dx 的费用义务

假设上条共同包络具有可测总质量 B(x,v)，在原实际 unique j 保留时成立。则 beta 后边界价至多

    (1/6) integral J_b(x-v) B(x,v) nu(dv).

若 B 不依外 hard 来源/历史，或已有对这些参数统一的同一上界，可以一次用原 hard16/3，连同 signed2Lambda，得到

    (16Lambda/9) E sum_V integral_dx integral_nu J_b(x-v)B(x,v).

想登记 C sqrt(n) W_beta，必须证明最后的实际双积分≤C sqrt(n) W_beta。仅对固定 x 的列归一化、固定来源的一维尾界或数个 v 的极值，不是此结论。若 B 依赖外 hard 来源且未统一控制，则须保留原 `q^-1 h_R(x-zprime) a_omega nu(dzprime)`，不能先领硬帽再忘记其相关性。

固定 b 的 J 才有 `integral_x J_b(x-v)dx=1`。receiver 自适应的 p、L、g 并不能代替这一归一化；若 B 常数则此式可用，若 B 随 x,v 变化须真的积分该权。原 j(x) 唯一可在对 j 一致的行价之后合并；不一致的包络或对全部 j 的 sum 不能免费换成 max。辅助时间已包含在边界测度中，没有另加 log2，但也不免除任意新时间分段的新增端点。

## 5. signed 补偿的必要账本与停止点

原精确恒等式仍为

    R=B_y−F_final−integral(C_GG+C_GE+H_Z+R_rev+R_eta)dt/t−Ndel.

因此一个补偿证明可以不分别控制每个正项，但须在同一实际外测度中证明所需联合下界；不能从无权 high 列直接推出 y 依赖 A/k 的二次形式为正。same-alpha 的 R_rev 是原未消费负项的一部分，不能再从另一捕获预算扣同一份；H_Z 记的是已经消费的 suffix 信用，不可删除。

分支只能按完整原 `(omega,V,j,x,y,zprime,历史)` 的辅助时间独立共同指示同时切原正项和两类未消费负项，各信用一次。新构造若改来源、改变支持/et、按 t 另选 alpha/g，或逐对重新选择输入，则必须重新证明原合同和增加相应变化/尺度/历史费用。

作者前检查点完成。暂未阅读 terminal_ratio_geometry 或 signed_compensation_geometry，不扩展反例或数值搜索；等待指定准确冻结稿后审。


## 6. terminal_ratio_geometry 后审：具体 source-v 边界价通过

已先独立核量词，再实读证明。绑定当前成稿 SHA256：

    a415f2d929c09ae2f48dac26d8a17683a2bb5ee55a8372e77fccb8fcec2f002a

判定：TR1–TR14 的边界估计通过；TR15–TR16 是条件正混合证书，作为条件命题通过，但其一般前提未证明。以上均不是整个 signed 分支付款。

### 6.1 原共同窗口与跨 V 的 K_*，已亲读原稿核实

亲读 `/Users/zhengzhihao/Desktop/T/output/centered_cube_round107_20261013/integration.md` 9–15、77–104 行。先对整个 E 固定 a,b,q 和 receiver 选择器 s(x),Ls(x),R(x)，之后才引入共同随机格与终端叶 V。因此同一原窗口内，固定 x 后 `K_*=P_(s(x),b)` 的 b 与 s 不随 V、y、v 重选。

另实读 R117 `research.zip:proof.md` 564：R107→R113→R114→R115→R116 的原子交通链没有替换 x、s、Ls 或物理窗口 a,b。该引用与原 R107 定义一致。故本轮不是由“每个 V 各自有一个合法 future”猜出跨 V 共同测试；它有原参数来源支持。

合同原 `sum_V nu_V≤sum_V beta_V≤f dx`，与此同一个 K_* 联合给

    sum_V K_*nu_V≤K_*f≤q.

必须先保持共同窗口、seed、receiver x，再作这次来源合并。不能给每叶先领一个 q 再免除叶数，也不能把几个外部窗口块的不同 K_* 当成同一测试。作者已补明此范围；跨原窗口的总价仍须原账支付。

### 6.2 精确删除积分及指数比值

TR2 使用的 kappa 恰是本审计作者前 §3 的真实初始加删除倒数跳测度，非 dt/t。终端 G 来源不会被辅助删除，故分子在删除时连续，TR2 是精确线性式；连续 wt 下降不被误称为分子固定。TR3 的总质量≤1/e_g 正确。

由 wt 逐时递减，`Xi=e_g integral R_t dkappa≤R_initial`。原 R117 JG2、R128 RT4 明确 `ell≥a/c_j`、`g≤b c_j`，c_j≤1；因此

    g/ell≤(b/a)c_j²≤2.

作者写 g≤b c_j 符合原稿，不应误改成 b/c_j。逐坐标 clipped 比值≤g/t，得 TR4；重叠坐标无需 source 独立。这是一个指数粗帽，随后由 E_h 上同一个 K_*/J 放大抵消，没有宣称它本身已是根阶。

TR5 的 E_h 只依 x,v 和共同 s,b，对 y、辅助 t 及 V 共同。TR6 因 `Xi≤2^n` 与 `K_*/J≥2^n exp(h)` 成立，方向、h≥0 和所有维度因子正确。

### 6.3 真实 beta、hard、j 与 q dx 价格

由 good 和 A≤chiJ 得 `p A wg≤KJ/3`；在 E_h 上用 TR6，正好得到 TR8。high 给 `1/e_g≤p/(2Kq)`，再用同一当前核 `integral p beta_V≤q`，于是每 V 的边界 beta 积分≤`exp(−h) K_*nu_V/6`。这里没有 beta 概率化，也没有把 v 选择的核逐 y 选取。

合并 V 后至多 `exp(−h)q/6`。保留实际唯一 j(x) 到一致行价之后再合并，免去 n+2；使用的 future 就一个 P_s,b，不产生连续 soft/scale 菜单费用。一次 hard16/3、signed2Lambda 与上述1/6 合成为 `16Lambda/9`。

剩余积分是真实 `integral_D q(x)dx`，seed 依赖 D 时保留 `E integral_Domega q dx`；q≤lambda 后才可上放 lambda|D|。不是 W_beta 价格，也不自动产生一个可反向吸收的原信用。原 a_omega≤1 只作正上界放松，不独立领取历史质量。时间已在 kappa 中结算，不另乘 log2。

### 6.4 显式 phi 常数与正厚度几何

phi 偶且在正轴递减，内部坐标核比为 `a_s(z)=s+(1−s)/phi(z)`，外部则为 s。TR11 的闭 core 端点 z=1/2 正确，TR12 保留 O log s；s>0 使所有实际核正，不对 s=0 的外部 log 作隐含定义。

直接核算

    integral_(1/2)^(3/4) a da=5/32,
    integral_(3/4)^1 a da=7/32.

e²<8、e^(4/3)<4 给相应指数严格下界1/8、1/4，故

    phi(1/2)<1/2−5/256−7/128=109/256.

由 `phi'=w(z+1/2)−w(z−1/2)`、0≤w≤1 得全局1-Lipschitz，故

    phi(19/40)<109/256+1/40=577/1280.

a_s 对 s 递减；在0<s≤1/10、19/40≤z≤1/2 上，逐坐标至少

    1/10+(9/10)(1280/577)=12097/5770>2.

因此面带全源在 `E_h`，取 h=n log[(12097/5770)/2]，即得 TR14 的 `(11540/12097)^n`。给定 zeta 的显示维数阈值方向也正确。面带每侧宽 b/40；所有符号方向都由同一源积分与 K_* 覆盖，无额外2^n mask 费。

正厚度只说明这个几何集合不依赖 source 落在零测度面上。原严格 soft 下门、大维、high、rho>0 和 FULL/history 同时实现仍未认证，作者没有用面带正厚度代替这些门。

### 6.5 正混合证书和不可升级的部分

TR15 的 theta 对当前正在积分的 y 共同，且正质量≤C_theta。由 good，完整边界满足

    p B_y[A]≤K QJ,V M_y/(3e_g).

high 之后是 `QJ,V p M_y/(6q)`。TR15、共同 future FIRST 与 beta_V≤f 给 beta 积分≤`L_n C_theta QJ,V/6`，再一次 hard 帽、固定 b 的 J 真 dx 积分和原来源总质量给 TR16。其维数价格明确是 L_n C_theta；作者并未证明一般 TR15，不登记新一般预算。

至关重要：分解 A=A1_Eh+A1_Eh_complement 只使 TR2 的**正边界**线性分解，不会把原 N_Zc、Ndel 同时复制给两边。将 source-v gate 后的 A 塞回 covariance 恒等式还会改变 C_GG、C_GE、H_Z、R_rev，不能仅拿 TR7/14 说原 signed 分支已付。作者明确仅支付边界槽；与辅助稿 S17 合用时，仍须付款整个原 A 的边界，或另证完整行的兼容分区与所有剩余缺陷。当前 v 补集与 signed 缺陷保留未付，通过的是稿件准确声明的范围。

## 7. signed_compensation_geometry 后审：上尾容量构造通过

已先独立审单层命题，再实读证明。绑定 SHA256：

    d37e9323fbe4f3333d56b32d38208c39646ed5902144b5d8ce1c36f934675a55

判定：S1–S17 一般相关来源的条件比较通过；S18 是附加旧终端比值条件后的完整行 signed 价格，通过。未证明一般 middle 自动满足容量条件，不能登记 FULL 新覆盖。

### 7.1 三类负载的方向、二分之一与层恒等式

在同一个原 Pi_t² 中，仅交换 G×G 的哑变量，得

    C_GG=integral_G² (A_v−A_u)_+(k_v−k_u)_+
          −integral_G² (A_v−A_u)_+(k_u−k_v)_+.

两次方向的对称性正好消去原1/2，没有跨外 y/source 的交通转置。GE 与 H_Z 负部按同一个低 score 的 v 定向，H_Z 的负部是需要补偿的已消费 suffix 缺陷，绝不是新增可用信用。

同层直接计算

    L_v,m=A_v z_v,m−g_v,m−A_v b_v,m≥0.

G 项用 `A_v−min(A_v,A_u)=(A_v−A_u)_+`，E 项用 A_v，B 项保留1−Psi。原 R_rev 的同层容量是 `(1−A_v)b_v,m`。所以容量足够的充要比较正是

    b_v,m+g_v,m≥A_v z_v,m,

而 S2 是更强充分条件。S8/S9 的所有系数、支持和 et 均正确，不丢原后验归一化。S3 只是共同正 et 同乘的未归一表达式，不能据此换原来源。

### 7.2 不重复原 reverse 信用

S10 用同一 v、同一层、Psi=1 的原 bad 上尾池作辅助分配，分母 b 保留。总负载密度 L/b≤1−A_v；b=0 时 S5 与 L≥0 强制 L=0。对层求和恰为原 `(1−A_v)(k_w−k_v)_+`，所以每个 bad 对只有原 reverse 总信用，不是每层再领一次同额信用。

层枚举是整数 score 差的精确分解，没有 n 的新增费用，更无2^n masks。所有比较都在同一完整原行、原 nu、Pi、Z_t、alpha 与 Psi 内进行；不使用来源坐标独立。阈值等号下 k 取原严格 C_i<xi 的整数值，层恒等式逐点仍成立；未微分 k，不新增阈值面信用。

因此 `D_GG+D_GE+D_H≤R_rev`，保留三类正部后得到 S4。其意义确实强于逐个协方差非负的旧门：允许这三项各自有真正负部；但仍以明确的原上尾容量条件为前提。

### 7.3 terminal-weight anchor 与初始 E 分母

规范 B* 在原 B 内，全部 C_i<xi_0，且对活跃 A 的原 Psi 兼容。规范定义的积分零条件与 Tonelli 保证乘积 a.e. 的可测性，不另选新 posterior 支持。B*⊂Zg，故不被原未来删除；整窗 score=n，且

    wt(w)=(g/t)^n wg(w)  on B*.

任意来源只有 `wt(u)≤(g/t)^n wg(u)`。原 Z_t⊂Z_(t0+) 给

    e_t≤(g/t)^n integral_(Z_initial) wg dnu.

由此得 S13 的 `Pi_t(B*)≥p_*`。S12 分母必须是初始 Z 上的 wg 质量，含以后删除的 E；一般≥e_g。作者确实保留该 E 分母，没有用 e_g 偷换，也没有把它称为 Pi_g。

p_*≥A_v 后，有 b_v,m≥Pi_t(B*)≥A_v≥A_v z_v,m，对 m>k_v 成立；A=0 无负载，无需额外配对门。直接总容量比较亦正确，同样只用原 reverse 一次。

S15 的 `1−A=1−chiJ+chiJ r≥r=1−rho` 正确。只使用 r 子信用时，S16 的 `p_*≥A/(A+r)` 才保证 r pool≥A nonpool；由 A+r≤1，该门确比 p_*≥A 强。两种条件与两份可用信用没有混报。没有证明原 high/FIRST 自动给这个 B* 或 p_*，作者明确保留此点。

### 7.4 全行 signed 回代与费用范围

S2/S5 必须对整行几乎所有辅助时刻成立，整个 far 窗属性作为一个时间独立行指示，同时切原正项和两类未消费负项。不是只保留容量成功时刻的正交通。于是 S4 与未用的 R_eta、Ndel、F_terminal 给 S17；真实删除正跳完整留在待付边界，不是被负池一起消掉。

再有统一 `w_initial≤exp(M)wg` 于全部活跃 A，已审 R170 边界引理才给 S18：`(16Lambda/9)exp(M)W_beta`。M≤log(n)/2 才是显示 sqrt(n) 费。hard16/3一次、signed2Lambda、high/FIRST、固定 b 的 J 真 dx、unique j 及原来源总质量全部沿原结算，不另收 log2 或层数。

本稿不解决大 M 边界；TR7 只支付其中特定 source-v 槽，因此两稿并列并不自动完成整个一般 signed 分支。S19 是准确未付余量 `A_v z−g−b`；一般真实外测度下的统一价仍待证明。FULL/history、连续 L1 来源和正 dx 覆盖都不能由抽象坏块本身生成。

## 8. 有限 score-pool 实现的静态补核与最终停止

按来源同事转达的父级请求，静态读 `score_pool_check.py/json/md`，未重跑。初读版本中 p_star 已正确用 terminal wt(xi_final)，分母完整含 initial E；G、B 的删除时刻0.9大于终端0.8，只有 E 在窗内或右端删除。原 strict score、wt、存活支持、Pi 归一、原 R_rev 与 GG 对称1/2/单向分解的实现一致。

该 JSON 的脚本与当前 signed 稿 hash 在静态读取时均匹配；三组各9个阈值/中点节点：前两组9/9层容量通过，薄 anchor 组2/9通过。它们仅是有理 C 数组与原子测度的有限 ALGEBRA 检查，不是物理 C 求值、同 alpha/FIRST 实现或区间全部时间认证，不用于一般数学通过的依据。

另已向数值负责人指出：当时 `tail_pool_allocation_identity_pass` 把刚定义的同一个差再比较，属恒真字段；若作为 S8 独立检验，应单算 g 并逐层核 `load==A*z−g−A*b`。同时 R166 仅可作背景定位，当前 S6–S10 命题出处是 R171 signed 稿。此实现质量提醒不影响以上解析证明；后续数值修稿须由其负责人和父级重新绑定，不能用本段认证我尚未读取的新版本。

最终范围：TR7/TR14 是具有显式 q dx 价格的真实 source-v **边界槽**估计；S4/S17 是一般相关来源的条件 signed 补偿；TR16/S18 保留各自未自动满足的前提。共同窗口来源、原负信用、删除及所有显示尺度费用均通过核查；一般中间交通和一般根阶上界仍未闭合。指定独审完成，仅本文件落盘，停止。
