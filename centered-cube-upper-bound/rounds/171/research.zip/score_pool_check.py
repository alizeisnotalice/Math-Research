#!/usr/bin/env python3
"""Exact finite rational check of the R166 score upper-tail bad-pool identity.

All source masses, C coordinates, and A values below are explicit algebraic
inputs. This does not instantiate physical cube kernels or certify an original
FIRST/history row.
"""
from __future__ import annotations

from dataclasses import dataclass
from fractions import Fraction as Q
from pathlib import Path
import hashlib
import json
import platform
import sys

HERE = Path(__file__).resolve().parent
COMPENSATION_SOURCE = HERE / "signed_compensation_geometry.md"
XI_INITIAL = Q(1, 2)
XI_FINAL = Q(4, 5)


@dataclass(frozen=True)
class Atom:
    name: str
    group: str                    # G, B, or E
    nu: Q
    c: tuple[Q, ...]
    A: Q | None = None
    delete_at: Q = Q(1)
    is_anchor: bool = False


def frac(x: Q) -> str:
    return f"{x.numerator}/{x.denominator}"


def wt(a: Atom, xi: Q) -> Q:
    out = Q(1)
    for ci in a.c:
        out *= min(Q(1), ci / xi)
    return out


def score(a: Atom, xi: Q) -> int:
    return sum(ci < xi for ci in a.c)


def survives(a: Atom, xi: Q) -> bool:
    # A source is removed at its declared rational event time.
    return xi < a.delete_at


def psi(v: Atom, u: Atom) -> int:
    # The designated high-score B* anchor survives every pair gate.
    if u.group == "B" and u.is_anchor:
        return 1
    return 0


def make_atoms(n: int, anchor_mass: Q, variant: str) -> list[Atom]:
    assert n in (2, 3, 5)
    def vec(head: tuple[Q, ...], fill: Q = Q(3, 4)) -> tuple[Q, ...]:
        return (head + (fill,) * n)[:n]
    anchor = Atom("B_anchor", "B", anchor_mass, (Q(1, 4),) * n,
                  delete_at=Q(9, 10), is_anchor=True)
    # Scores at xi_initial are deliberately not ordered with A.
    if n == 2:
        gs = [
            Atom("G_lowscore_highA", "G", Q(1, 10), vec((Q(3, 5), Q(3, 4))), Q(2, 5), Q(9, 10)),
            Atom("G_highscore_lowA", "G", Q(1, 10), vec((Q(1, 4), Q(1, 4))), Q(1, 5), Q(9, 10)),
        ]
        es = [Atom("E_mid", "E", Q(1, 20), (Q(1, 4), Q(1, 4)), delete_at=Q(7, 10))]
        bs = [Atom("B_unselected_lowscore", "B", Q(1, 100), (Q(3, 4),) * n, delete_at=Q(9, 10)),
              Atom("B_unselected_highscore", "B", Q(1, 100), (Q(1, 4), Q(3, 4)), delete_at=Q(9, 10))]
    elif n == 3:
        gs = [
            Atom("G_a", "G", Q(1, 20), (Q(1, 4), Q(3, 5), Q(3, 4)), Q(2, 5), Q(9, 10)),
            Atom("G_b", "G", Q(1, 20), (Q(1, 4), Q(1, 4), Q(3, 5)), Q(1, 5), Q(9, 10)),
            Atom("G_c", "G", Q(1, 50), (Q(3, 5),) * n, Q(3, 10), Q(9, 10)),
        ]
        es = [Atom("E_highscore", "E", Q(1, 50), (Q(1, 4),) * n, delete_at=Q(7, 10))]
        bs = [Atom("B_unselected_lowscore", "B", Q(1, 100), (Q(3, 4),) * n, delete_at=Q(9, 10)),
              Atom("B_unselected_highscore", "B", Q(1, 100), (Q(1, 4), Q(1, 4), Q(3, 4)), delete_at=Q(9, 10))]
    else:
        gs = [
            Atom("G_a", "G", Q(1, 20), (Q(1, 4), Q(3, 5), Q(3, 4), Q(3, 4), Q(3, 4)), Q(2, 5), Q(9, 10)),
            Atom("G_b", "G", Q(1, 20), (Q(1, 4), Q(1, 4), Q(3, 5), Q(3, 4), Q(3, 4)), Q(1, 5), Q(9, 10)),
            Atom("G_c", "G", Q(1, 20), (Q(1, 4),) * 5, Q(3, 10), Q(9, 10)),
        ]
        es = [Atom("E_highscore", "E", Q(1, 20), (Q(1, 4),) * n, delete_at=Q(7, 10)),
              Atom("E_mid", "E", Q(1, 20), (Q(1, 4), Q(1, 4), Q(3, 5), Q(3, 4), Q(3, 4)), delete_at=Q(4, 5))]
        bs = [Atom("B_unselected_lowscore", "B", Q(1, 100), (Q(3, 4),) * n, delete_at=Q(9, 10)),
              Atom("B_unselected_highscore", "B", Q(1, 100), (Q(1, 4), Q(1, 4), Q(1, 4), Q(1, 4), Q(3, 4)), delete_at=Q(9, 10))]
    if variant == "thin_anchor":
        anchor = Atom(anchor.name, anchor.group, Q(1, 100), anchor.c,
                      anchor.A, anchor.delete_at, anchor.is_anchor)
    return [*gs, anchor, *bs, *es]


def threshold_nodes(atoms: list[Atom]) -> list[dict]:
    edges = sorted({XI_INITIAL, XI_FINAL,
                    *(c for a in atoms for c in a.c if XI_INITIAL < c < XI_FINAL),
                    *(a.delete_at for a in atoms if XI_INITIAL < a.delete_at < XI_FINAL)})
    nodes: list[tuple[str, Q]] = [("threshold", x) for x in edges]
    nodes += [("interval_midpoint", (l + r) / 2) for l, r in zip(edges, edges[1:])]
    # Preserve exact thresholds and midpoints, ordered by xi and with endpoint
    # semantics explicit; duplicate values cannot occur except distinct tags.
    nodes.sort(key=lambda item: (item[1], 0 if item[0] == "threshold" else 1))
    return [{"kind": kind, "xi": x} for kind, x in nodes]


def evaluate(atoms: list[Atom], xi: Q) -> dict:
    n = len(atoms[0].c)
    live = [a for a in atoms if survives(a, xi)]
    raw = {a.name: a.nu * wt(a, xi) for a in live}
    e = sum(raw.values(), Q(0))
    pi = {name: mass / e for name, mass in raw.items()} if e else {}
    live_names = set(pi)
    # p* is evaluated once on initial Z with terminal wg=wt(xi_final).
    initial = [a for a in atoms if survives(a, XI_INITIAL)]
    # Terminal wg is evaluated on the complete initial support; E remains in
    # this denominator even when it is removed at an auxiliary-time event.
    denom = sum((a.nu * wt(a, XI_FINAL) for a in initial), Q(0))
    anchor_mass = sum((a.nu * wt(a, XI_FINAL) for a in initial if a.is_anchor), Q(0))
    pstar = anchor_mass / denom if denom else Q(0)
    amax = max((a.A for a in atoms if a.group == "G" and a.A is not None), default=Q(0))

    levels = []
    negatives = {"GG": Q(0), "GE": Q(0), "HZ": Q(0)}
    negative_direct = {"GG": Q(0), "GE": Q(0), "HZ": Q(0)}
    rrev = Q(0)
    rrev_layers = Q(0)
    positives = {"GG": Q(0), "GE": Q(0), "HZ": Q(0)}
    signed = {"GG": Q(0), "GE": Q(0), "HZ": Q(0)}
    gg_symmetric = Q(0)
    positive_delta_mass = Q(0)
    # δ is recorded over actual live G×live source pairs, with the same Pi.
    for v in atoms:
        if v.group != "G" or v.name not in live_names:
            continue
        kv = score(v, xi)
        for u in atoms:
            if u.name in live_names:
                d = max(0, kv - score(u, xi))
                positive_delta_mass += pi[v.name] * pi[u.name] * d
        for u in atoms:
            if u.name not in live_names:
                continue
            ku = score(u, xi)
            pu = pi[u.name]
            if u.group == "B" and psi(v, u):
                rrev += pi[v.name] * pu * (1 - (v.A or Q(0))) * max(0, ku - kv)
            if u.group == "G":
                coeff = (v.A or Q(0)) - (u.A or Q(0))
                signed["GG"] += pi[v.name] * pu * max(Q(0), coeff) * (kv - ku)
                gg_symmetric += pi[v.name] * pu * coeff * (kv - ku) / 2
                positives["GG"] += pi[v.name] * pu * max(Q(0), coeff) * max(0, kv - ku)
                negative_direct["GG"] += pi[v.name] * pu * max(Q(0), coeff) * max(0, ku - kv)
            elif u.group == "E":
                Av = v.A or Q(0)
                signed["GE"] += pi[v.name] * pu * Av * (kv - ku)
                positives["GE"] += pi[v.name] * pu * Av * max(0, kv - ku)
                negative_direct["GE"] += pi[v.name] * pu * Av * max(0, ku - kv)
            elif u.group == "B":
                Av = v.A or Q(0)
                coeff = Av * (1 - psi(v, u))
                signed["HZ"] += pi[v.name] * pu * coeff * (kv - ku)
                positives["HZ"] += pi[v.name] * pu * coeff * max(0, kv - ku)
                negative_direct["HZ"] += pi[v.name] * pu * coeff * max(0, ku - kv)
        Av = v.A or Q(0)
        for ell in range(kv + 1, n + 1):
            z = sum((pi[u.name] for u in atoms
                     if u.name in live_names and score(u, xi) >= ell), Q(0))
            b = sum((pi[u.name] for u in atoms
                     if u.name in live_names and u.group == "B" and psi(v, u)
                     and score(u, xi) >= ell), Q(0))
            terms = {"GG": Q(0), "GE": Q(0), "HZ": Q(0)}
            for u in atoms:
                if u.name not in live_names or score(u, xi) < ell:
                    continue
                pu = pi[u.name]
                if u.group == "G":
                    terms["GG"] += max(Q(0), Av - (u.A or Q(0))) * pu
                elif u.group == "E":
                    terms["GE"] += Av * pu
                elif not psi(v, u):
                    terms["HZ"] += Av * pu
            load = sum(terms.values(), Q(0))
            gmin = sum((min(Av, u.A or Q(0)) * pi[u.name] for u in atoms
                        if u.group == "G" and u.name in live_names and score(u, xi) >= ell), Q(0))
            identity = load == Av * z - gmin - Av * b
            assert identity, (v.name, ell, xi)
            capacity = (1 - Av) * b
            levels.append({"v": v.name, "k_v": kv, "ell": ell,
                           "z_vell": frac(z), "b_vell": frac(b), "g_vell": frac(gmin),
                           "S8_independent_identity_pass": identity,
                           "GG_negative": frac(terms["GG"]), "GE_negative": frac(terms["GE"]),
                           "HZ_negative": frac(terms["HZ"]), "L_vell": frac(load),
                           "capacity_(1-A_v)b": frac(capacity),
                           "slack_capacity_minus_load": frac(capacity - load),
                           "pool_pass": load <= capacity})
            for key in negatives:
                negatives[key] += pi[v.name] * terms[key]
            rrev_layers += pi[v.name] * (1 - Av) * b
    complete_c_sum = sum(negatives.values(), Q(0))
    direct_negative_total = sum(negative_direct.values(), Q(0))
    complete_signed = sum(signed.values(), Q(0)) + rrev
    pool_leftover = rrev - complete_c_sum
    positive_total = sum(positives.values(), Q(0))
    return {"xi": frac(xi), "n": n,
            "live_Z": sorted(live_names), "strictly_decreasing_Z_event": True,
            "Pi_normalizer_e": frac(e),
            "source_rows": [{"name": a.name, "group": a.group, "nu": frac(a.nu),
                             "C": [frac(c) for c in a.c], "k": score(a, xi),
                             "wt": frac(wt(a, xi)), "live": survives(a, xi),
                             "A": frac(a.A) if a.A is not None else None,
                             "Psi_against_anchor": int(a.is_anchor)} for a in atoms],
            "anchor_B_star": {"names": [a.name for a in atoms if a.is_anchor],
                              "all_C_below_xi_initial": all(c < XI_INITIAL for a in atoms if a.is_anchor for c in a.c),
                              "p_star_terminal_wg_mass_fraction": frac(pstar),
                              "max_A_on_G": frac(amax),
                              "p_star_ge_max_A": pstar >= amax},
            "levels": levels,
            "negative_account_totals": {key: frac(value) for key, value in negatives.items()},
            "negative_account_direct_pair_totals": {key: frac(value) for key, value in negative_direct.items()},
            "negative_layer_vs_pair_identity_pass": complete_c_sum == direct_negative_total,
            "positive_account_totals": {key: frac(value) for key, value in positives.items()},
            "signed_C_totals": {key: frac(value) for key, value in signed.items()},
            "C_GG_symmetric_half_double_sum": frac(gg_symmetric),
            "C_GG_max_positive_part_form": frac(signed["GG"]),
            "C_GG_symmetric_identity_pass": gg_symmetric == signed["GG"],
            "R_rev": frac(rrev),
            "R_rev_layer_identity": frac(rrev_layers),
            "R_rev_direct_equals_layer_sum": rrev == rrev_layers,
            "R_rev_minus_total_negative_load": frac(pool_leftover),
            "complete_C_GG_plus_C_GE_plus_H_Z_plus_R_rev": frac(complete_signed),
            "complete_C_sum_nonnegative": complete_signed >= 0,
            "tail_pool_allocation_identity_pass": all(row["S8_independent_identity_pass"] for row in levels),
            "signed_decomposition_identity_pass": complete_signed == positive_total + pool_leftover,
            "any_GG_negative": negatives["GG"] > 0,
            "any_GE_negative": negatives["GE"] > 0,
            "any_HZ_negative": negatives["HZ"] > 0,
            "positive_delta_pair_mass": frac(positive_delta_mass),
            "positive_delta_nonzero": positive_delta_mass > 0,
            "all_tested_pool_levels_pass": all(row["pool_pass"] for row in levels)}


def run_case(name: str, n: int, anchor: Q, variant: str) -> dict:
    atoms = make_atoms(n, anchor, variant)
    return {"name": name, "dimension": n,
            "anchor_mass_actual": frac(next(a.nu for a in atoms if a.is_anchor)),
            "atoms": [{"name": a.name, "group": a.group, "nu": frac(a.nu),
                       "C": [frac(c) for c in a.c], "A": frac(a.A) if a.A is not None else None,
                       "delete_at": frac(a.delete_at), "B_star": a.is_anchor} for a in atoms],
            "thresholds_and_interval_midpoints": [evaluate(atoms, node["xi"]) | {"node_kind": node["kind"]}
                                                    for node in threshold_nodes(atoms)]}


def main() -> None:
    cases = [run_case("stage1_small_source_pool_pass", 2, Q(1), "pass"),
             run_case("stage2_unsorted_A_score_with_all_negative_terms", 3, Q(1), "pass"),
             run_case("stage3_higher_dimension_thin_anchor_control", 5, Q(1, 2), "thin_anchor")]
    out = {"title": "R171 exact finite score-pool check",
           "scope": "ALGEBRA only: exact rational finite measures and rational C-coordinate arrays; not physical kernels, FIRST, L1 densities, FULL, history, or a final lemma certificate.",
           "definitions": {"k_v(xi)": "#{i: C_vi < xi}",
                          "wt_v(xi)": "prod_i min(1,C_vi/xi)",
                          "Z_xi": "atoms with xi < delete_at; nested decreasing at declared rational deletion events",
                          "Pi_xi": "normalized nu*wt on Z_xi",
                          "L_vell": "sum_{k_u>=ell}[(A_v-A_u)_+ 1_G + A_v 1_E + A_v(1-Psi(v,u))1_B] Pi(u)",
                          "capacity": "(1-A_v) b_vell; only B sources with Psi=1 and k>=ell enter b",
                          "R_rev": "sum_{v in G,w in B} Pi(v)Pi(w)Psi(v,w)(1-A_v)(k_w-k_v)_+"},
           "proposition_source": {"exact_formula_checkpoint": "signed_compensation_geometry.md",
                                  "exact_formula_checkpoint_sha256": hashlib.sha256(COMPENSATION_SOURCE.read_bytes()).hexdigest()
                                      if COMPENSATION_SOURCE.exists() else None},
           "implementation": {"relative_name": "score_pool_check.py",
                              "sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest()},
           "construction_notes": ["Every anchor coordinate is 1/4 < xi_initial=1/2, hence k_anchor=n at xi_initial.",
                                  "p_star uses terminal wg=wt(xi_final) over the complete initial support, including E.",
                                  "Every G and B source survives throughout [xi_initial,xi_final]; only E sources can be deleted.",
                                  "Psi(v,B_star)=1 for each G anchor test; Psi(v,other B)=0.",
                                  "A values are fixed per G atom and intentionally not monotone in k.",
                                  "Each reported layer is an exact rational threshold or adjacent-breakpoint midpoint; no interval-wide statement is inferred from midpoint checks."],
           "cases": cases,
           "runtime": {"python": sys.version, "platform": platform.platform()}}
    (HERE / "score_pool_check.json").write_text(json.dumps(out, indent=2) + "\n")
    print(json.dumps({"out": str(HERE / "score_pool_check.json"),
                      "cases": [{"name": c["name"], "nodes": len(c["thresholds_and_interval_midpoints"]),
                                 "pool_pass_nodes": sum(node["all_tested_pool_levels_pass"]
                                                        for node in c["thresholds_and_interval_midpoints"])} for c in cases]}, indent=2))


if __name__ == "__main__":
    main()
