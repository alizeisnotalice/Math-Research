# R171 numeric design: joint terminal amplification and source deficit

Status: experiment specification, not a general bound or a certificate of an original source/history. The target is an integrated terminal-ratio envelope. A large isolated ratio is not a decision. Frozen R170 tools may be imported read-only; no software installation or parameter optimization is required.

## 1. Mandatory data and scope labels

Every case freezes one common input before receiver selection: nonnegative f, beta, nu with nu <= beta <= f and (if more than one seed) sum beta <= f. Store all source positions, exact masses/densities, fixed support rules, n,s,L,a,b,c_j,g,K and their provenance. Never put an outer y at a location with beta mass zero. In particular R170 beta=nu has zero outer mass at y=0. Its diagnostic row contributes ZERO to any beta integral. An added beta slot must also enter f and every current/future convolution test; it is not a free probe.

Use three explicit scope labels:

* ALGEBRA: rational arrays with arbitrary weights or masks. These test identities only.
* GEOMETRIC-NECESSARY: actual C and P/J kernels at common physical positions; fixed atomic common f,beta,nu; exact current q and all displayed necessary gates. Atomic cases have original finite beta/nu integrals, but no Lebesgue-density realization or full history. A future grid alone does not establish FIRST.
* L1/FIRST-CERTIFIED: piecewise constant nonnegative densities on specified positive-volume boxes, domination checked pointwise, q=P_{s,L}f(x) from that same f, and rigorous future supremum <= q on an explicitly certified positive-volume receiver region. Only this scope supports a real dx/beta/nu geometric conclusion. Full history remains a separate requirement unless supplied.

Do not promote a geometric necessary case to the third label by replacing atoms with boxes informally. Receiver quadrature is genuine numerical dx evidence, not a rigorous dx bound. A finite future test gives a rejection or an unresolved qualification, never a proof of the continuum condition. No new Z/deletion history is silently invented; Z=all is a stated conditional specialization.

## 2. Same-measure observables

For the mandatory experiment use beta equal to the full frozen R169 atomic F, including its positive completion atom r; nu remains the original three-source measure. Thus nu <= beta = f is exact and every outer beta atom is integrated, including r. Read the completion mass from its frozen interval data. No new beta slot is needed.

At each receiver x retain the original fixed common q (do not redefine q as a function of x), p_y=P_{s,L}(x-y), e_t(y)=int 1_Zt(y)(v) wt(y,v) nu(dv), and terminal e_g defined with the actual terminal Z_g,wg. Compute weights in log coordinates from C: log wt=-sum_i[log xi_t-log C_i]_+, xi_t=c_j t/b; zero C is a genuine zero weight. Keep g and all terminal masks fixed through auxiliary time.

Gate H_y=1{p_y e_g>=2Kq} AND the stated original eligibility; undefined q/e rows are excluded and counted. Store actual R_t=wt/wg on wg>0, E_t=e_t/e_g, and posterior amplification R_t/E_t. Report zero wg with positive wt separately: it cannot be assigned a finite ratio. The exact target column is

    Gamma_t(x,v)=int H_y R_t(y,v)/e_t(y) beta(dy).

Do NOT insert wt or Pi a second time into this definition. If an application requires terminal v in Z_g or G, insert that named mask explicitly. Record its mass separately.

At every x,v on the SAME beta measure set M_y=p_y beta_y/q, eta_y=2Kq/(p_y e_t), c_t=int H 1_Z wt/e_t beta. Record

    D0=1-int M;
    D1=int M(1-H);
    D2=int MH(1-eta);
    D3=int MH eta(1-1_Z);
    D4=int MH eta 1_Z(1-wt).

Check sum D=1-2K c_t, all D_i>=0, eta<=1 on H, e_t>=e_g, and int M<=1. A failed necessary check rejects that row; do not clip a negative deficit. Record all five components even if the row is not near saturated.

Compute real receiver/source diagnostics on a declared receiver box X:

    I_t(X)=int_X dx int nu(dv) J_b(x-v) Gamma_t(x,v),
    C_t(X)=2K I_t(X)/||nu||,
    B_t(X)=int_X dx int nu(dv) J_b(x-v) int_H beta(dy)/e_t(y).

The pointwise trivial benchmark is Gamma <= sup(R)/(2K), hence I_t <= sup(R)||nu||/(2K) when X is any subset of valid receivers. Compare C_t to sqrt(n), but never infer asymptotic order from finite n. Retain B_t: I_t/B_t is the actual J/e-weighted amplification (if B_t>0). It distinguishes large ratios of negligible original traffic from costly ratios.

Output weighted ratio tails for r in {1,2,4,8,sqrt(n)}: replace R by R 1{R>=r} in I_t. Also output the J nu weighted joint bins of (log R,log E,sum D), and the five D_i averaged with that exact tail traffic weight. This tests whether costly amplification coexists with near column saturation. Binning or selection must not change the underlying integral.

For a supplied terminal test A=rho chiJ 1_G, record the actual initial boundary int beta(dy) H p_y int A wt nu/e_t and all real deletion jumps with each exact e_before,e_after. Do not substitute I_t for this boundary: it is a good-condition upper envelope after multiplication by K/3. If no valid A/history/deletions are supplied, output boundary='not constructed' and the Gamma envelope separately. For supplied jumps record numerator continuity and int A wt nu*(1/e_after-1/e_before); integrate it in the original common beta and dx. No arbitrary deletion schedule counts as an actual boundary example.

## 3. Bounded three-stage execution

Stage 1: identity/scope calibration. Reuse the frozen n=4 R170 geometry and R169 common-input completion with beta=f=full four-atom F, nu=the original three atoms, and fixed q=9/2500. Report its y=0 row as a zero-beta negative control. Recompute p_y,e_g for ALL four actual beta atoms, especially completion atom r. Do not introduce a new beta slot or change q. Include one ALGEBRA rational-array unit check for the five-deficit identity; label it separately. Report all outer source rows of the actual beta support, not just the old distinguished external y. Evaluate xi=.51,.52,.53 and actual eligible endpoint limits; include g. This is primarily a wiring/rejection test, not a search.

Stage 2: joint geometry and real numerical receiver measure. Keep all source data frozen. Integrate all beta and nu atoms exactly as finite sums; receiver X is the declared product box [-2b,2b]^n after translation, with no source-dependent resampling. For n=4 use nested deterministic product quadrature orders 3,5,7 (2401 receiver nodes at order 7), evaluating the current upper qualification P_{s,L}beta(x)<=q and all common-input future necessary tests at each node. The column calculation needs this upper inequality, not current equality. Keep current-equality-at-x0 certification separate from the receiver-grid upper-qualification domain. Exclude invalid receivers by explicit gate and report their dx, Jnu, and high-traffic numerical masses. At each retained node test future u on {s,(s+1)/2,1}, L' on {a,(a+b)/2,b}; then refine to 9x9 only for survivors. This finite gate is an optimistic necessary-domain envelope, not a FIRST certificate. State that gate discontinuities can make quadrature convergence slow. No independent maximization over x,y,v permitted. Run the original time window with 8/16/32 log-time nodes split at all actual C thresholds; do not multiply a single-time maximum by window length. n=4 is the bounded mandatory run; any larger-dimensional design requires new explicitly supplied common geometry and is not created by duplicating arbitrary scalar arrays.

Stage 3: selected independent precision check. Choose by the largest integrated tail contribution, not largest R alone. Recompute its top contributing receiver/source cells and two low-traffic high-R controls using the existing directed Decimal interval runtime imported by R170 pair_certificate.py, with two refinements 64 and 128. Certify the five-deficit identity residual enclosure, R and E where denominators separate from zero, and high/current/future finite-grid margins. Use existing mp70 only as a cross-check, never as an interval certificate. If a continuous receiver bound is desired, a selected positive-volume receiver box and the full future u,L' rectangle must be interval-enclosed; otherwise retain the necessary-model label. A certificate of three time values is not a certificate of a whole interval.

## 4. Meaningful decisions and precision controls

Predeclare outcomes: (i) zero retained high traffic: inconclusive for compensation; (ii) positive traffic with ratio large but tail integral small: finite compensation evidence only; (iii) significant tail traffic with C_t or time envelope approaching the sqrt(n) benchmark: pressure on a proposed integrated envelope, not a counterexample to the theorem; (iv) failure of common-input/FIRST/normalization: rejected model or unresolved qualification. Do not describe a finite bound smaller than sqrt(n) as subpolynomial evidence at a single n.

Store numerator and denominator of every reported ratio; never normalize nu,beta or the traffic to one before recording raw masses. Include q_min, e_g_min, e_t_min, excluded zero-denominator mass, receiver-domain volume, outside-X status, all quadrature changes, input SHA256 hashes, Python/runtime versions, exact rational parameters, and the scope/qualification flags. Tail truncation outside X is not bounded unless analytically or interval controlled; X diagnostics are lower/partial-domain observations and cannot certify a global upper bound. For the necessary-gate receiver envelope with fixed q and current upper qualification, numerical integration error is also unresolved unless interval enclosed.

Use logsumexp for positive sums and log ratio differences to avoid underflow. Float gates with margin within 1e-10 of their own natural scale are 'ambiguous', not accepted; retain their possible traffic in a separate optimistic total. Keep strict and optimistic totals. Require relative change <1e-3 for positive totals between the last two spatial/time orders, with absolute tolerance 1e-12 times the displayed natural mass benchmark; failure reports unresolved quadrature. Interval bounds decide signs only when zero is excluded. No installation, global search, new standalone counterexample program, or new lemma claim is authorized by this plan.

## 5. Independent audit responsibilities

The implementer owns the bounded arithmetic implementation and outputs. Sol design reviewer independently checks exact finite-sum Gamma wiring, all five deficit formulas, same-input source domination/current q, receiver weights, and at least one selected high-tail row at higher precision. Frozen kernel libraries can be trusted as kernels, but imported paths and hashes must be recorded. Implementation success cannot certify the key integrated lemma; parent/Sol must review any mathematical inference. Current conclusion pending implementation: no new evidence yet. Parent correction incorporated: mandatory beta is full R169 atomic F; fixed q is retained across receivers; current upper qualification is sufficient for the measured column but is not renamed original FIRST.

## 6. Parent-selected primary average-future observable

Without enlarging the sample, at each actual high beta row use initial time ell+ and QJ=int J_b(x-v)nu(dv)>0 to compute

    a_y = int J_b(x-v) R_initial(y,v) nu(dv) / QJ,
    futuregain_y = J_b(x-y)/p_y,
    average_gate_y = a_y / (sqrt(n)*futuregain_y),
    old_sup_gate_y = sup_{v in actual nu support} R_initial(y,v)/sqrt(n).

Use all actual nu sources first; a separately labelled A>0 restriction is optional and cannot replace the all-source numerator. Compute initial from the original eligible interval left endpoint, not a favorable interior time. Report rows with average_gate<=1<old_sup_gate and their actual beta weight, receiver dx weight, and J/e weighted traffic contribution. This isolates whether the average future mechanism adds coverage beyond the old sup-ratio branch. Preserve futuregain itself so that a large J/p previously paid regime is not described as new coverage. The row comparison is finite evidence for the candidate branch, not its global proof. Any Rfuturegrid<exp(H) label (if defined by the author) is only a finite necessary unpriced label. Do not invent its missing H definition.

## 7. Independent arithmetic audit checkpoint

Sol independently evaluated the two actual high rows at frozen x0 with the frozen directed-Decimal kernel runtime, 128 subdivisions, g=sqrt(9/10) as an interval (not the probe's float g). This was a separate direct finite-sum calculation, without importing the probe implementation. At y=x0 (beta mass 1/3125), high ratio p_y e_g/(2Kq) lies in [2.49818,2.49871], a_y in [8.1704,8.1777], J_y/p_y in [.100859,.100871], and average_gate in [40.499,40.540]. At completion y=r (positive beta completion mass), high ratio lies in [12.4027,12.4046], a_y in [3.7844,3.7932], J_y/p_y in [.0425305,.0425362], and average_gate in [44.484,44.593]. Both rows have initial sup ratio greater than 12.94 and fail the old sqrt(n)=2 gate as well. Thus these genuine positive-beta x0 rows do not witness extra average-branch coverage. These intervals concern finite atomic geometry at one receiver, not positive dx mass or the global branch.

Initial probe audit found material wiring errors (receiver volume, source-index integration, duplicate time averaging, q in the normalization, time endpoint, and deficit weights); its pre-correction I/B/C values must not be used. The implementer was instructed to correct and refreeze. No numerical evidence is certified merely by a successful script execution. The independent x0 interval conclusions above are unaffected by those receiver-integration implementation errors.

Corrected-probe audit: source integration now uses each nu_v exactly once, receiver cell volume is 256/order^4, the [1/2,h] log-time quadrature factor appears once, and C=2K I/||nu|| without an extra q. The corrected 3/5/7 midpoint meshes give I approximately 4.0764e-4, 1.8894e-4, 1.3752e-5 and B approximately 2.00585e-4, 1.31886e-4, 6.76692e-6. The spatial differences are too large for an integrated numerical conclusion. The five-deficit identity's float residual is at most 2.22e-16, min D=0, max eta on sampled high rows approximately .381113. This verifies wiring numerically, not the analytic lemma.

No sampled positive-weight row passes the average gate while failing the old sup gate. `old_sup_gate_gt_1_only_weight` denotes avg_gate>1 AND old_sup_gate>1; it is failure of both sufficient tests, not coverage by the old branch. Missing threshold-split/time refinement, independent receiver-cell interval enclosure, tail-conditioned deficit distribution, full et/eg distribution, current/future continuum qualification, outside-X control, and real boundary/deletion construction remain explicit limitations. Thus the checkpoint is finite necessary-geometry diagnostics plus independently certified point-row arithmetic, with no new global bound or evidence of extra average-branch coverage in this sample.
