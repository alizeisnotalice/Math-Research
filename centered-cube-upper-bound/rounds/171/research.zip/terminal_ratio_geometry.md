# R171：好源槽的共同 future 放大与终端比值补偿

状态：证明一条具体的空间来源子支：当好源 v 在接收点 x 的共同 future 核中获得足够放大时，终端比值的初始项与全部删除项可以一起支付一个显式小的接收点价格。该放大发生在内来源 v，和 R168 已付的外中心 y 的大 future-gain 域不同。另给出完整外 beta 的正混合证书，但不把其尚未验证的条件算成一般估计。没有证明这些条件覆盖整个 nearmax middle，也没有认证新的 FULL 正交通实例。

仅用本轮合同、冻结 R170 `soft_threshold_energy.md` §§3–4 和 `uncaptured_pair_budget.md`。无外部定理、无 Git、无其他文件修改。下面的代数先在原有限截断上成立；所有新的来源分割均对辅助时间冻结。

## 1. 先筛命题：支付哪一个实际量

沿原完整行固定 `(omega,V,x,j,y,history)`，保持原终端 `g,G,B,alpha,rho`，令

    A_y(v)=1_G(v) rho_y(v) chiJ(x-v),  0<=A<=1,
    F_t=Pi_y,t A.

记 far 段初始时刻为 ell，终点为 r。初始侧值沿原约定；所有实际删除时刻及端点归属都按原账。本文要支付的是

    B_y[A]=F_{ell+}+sum_{ell<t<r}(F_t-F_{t-}),          (TR1)

以及它对固定来源子集的线性部分。它不是整项 signed 余量；R170 精确式中的 `C_GG,C_GE,H_Z,R_rev,R_eta,Ndel,F_final` 全部原位保留。

对终端支持上的源 v，定义原逆 e 正测度

    kappa_y(dt)=e_{ell+}^{-1} delta_{ell+}(dt)
       +sum_delete (e_t^{-1}-e_{t-}^{-1}) delta_t(dt).

删除的 A 分子连续，故精确地

    B_y[A]=int nu(dv) A_y(v) int w_t(y,v) kappa_y(dt).  (TR2)

同一递减 e_t 给

    kappa_y(total)<=e_g(y)^{-1}.                       (TR3)

(TR3) 包含初始与全部删除；连续的 e 下降只产生未用余量。不能另付每次删除一次 high 价格，也没有删除数、时间长度或 `log(e_ell/e_g)` 费用。

令 `R_t(y,v)=w_t/w_g`、`Xi_y(v)=e_g int R_t kappa_y(dt)`。则

    B_y[A]=e_g^{-1} int A_y(v) w_g(y,v) Xi_y(v)dnu(v),
    0<=Xi_y(v)<=R_{ell+}(y,v)<=(g/ell)^n<=2^n.         (TR4)

最后一界逐坐标成立：`min(1,C/xi_t)/min(1,C/xi_g)<=g/t`，且原 ell>=a/c_j、g<=bc_j、b<=2a。本文保留精确 Xi 供后续改善；主定理只用其统一上界 2^n，但用真实 source-v future 放大抵消这一指数，而不是对所有来源照付 2^n。

## 2. 一条由原条件推出的真实来源子支价格

取同一合法 future

    K_*(x-v)=P_{s(x),b}(x-v),  J_v=P_{1,b}(x-v).

它与当前核有相同 soft s，尺度扩大到 b，故在原完整 FIRST 下 `K_* f(x)<=q(x)`。固定 x 时它在 V、y、t 上共同；b 是当前原块的固定 b。

**跨 V 共同参数的原稿定位。** `/Users/zhengzhihao/Desktop/T/output/centered_cube_round107_20261013/integration.md:9` 在构造叶之前明确写“原软度 s(x)、两个原物理选择器 L_s(x),R(x)，以及整个 E 上的共同常数”；其 R1（行 11–15）列出共同 q 和 `a<=L_s(x),R(x)<=b<=2a`。该稿行 77 才引入共同嵌套格，行 82 才定义终端叶 V，行 102–104 固定 seed 并定义 sigma_V。因此当前窗口的 a,b 先于这些叶固定，s 只随 x 变化。继承链的独立核对见 `/Users/zhengzhihao/Desktop/T/output/centered_cube_round117_20261014/proof.md:564`：R107 到 R113、R114、R115、R116 的子交通沿链没有替换原 x、s、L_s 或物理窗口 a,b。本定理只对这个原共同窗口块求和 V；若另有多个独立窗口块，须保留其原总账，不能由 TR10 免费再作跨块合并。

定义真实 source-v 放大分数

    S_x(v)=log(K_*(x-v)/J_v).

原实际 s>0，核均正。对 h>=0，定义固定来源集合

    E_h(x)={v:S_x(v)>=n log 2+h}.                      (TR5)

这不是对来源尾质量另加假设；E_h 由实际核值明确选出。由 TR4 和 TR5，在该集合上对全部原时间、全部外 y 同时有

    J_v Xi_y(v)<=e^{-h} K_*(x-v).                      (TR6)

**命题（内来源 future 放大的接收点价格）。** 将 A 的边界部分限制为 `A 1_Eh`，原完整外 beta、真实来源 nu、dx 和 hard 源均保留。则

    RawBoundary(E_h)
       <=(16 Lambda/9)e^{-h} int_D q(x)dx,             (TR7)

其中 D 是所有相关合法接收行的一个共同接收域；若域依 seed，右端保留原期望 `E int_Domega q dx`。若 `q<=lambda` 且这些行包含在原共同目标集合 D，则进一步至多

    (16 Lambda/9)e^{-h} lambda |D|.

这是显式接收点价格；只有在总账确有对应的 lambda|D| 吸收信用时才能称为已吸收，不自行新增该信用。

证明：原 good 和 `A<=J/(3Q)` 给 `p_y A_y(v)w_g(y,v)<=K J_v/3`。TR4、TR6 因而给

    p_y B_y[A 1_Eh]
       <= K e^{-h}/(3e_g(y)) * K_*nu_V(x).             (TR8)

原 high 与同一当前 FIRST 给每个 V

    int_high beta_V(dy)/e_g(y)
       <=(2Kq)^{-1} int p_y beta_V(dy)<=1/(2K).        (TR9)

故该 V 的外 beta 行价至多 `e^{-h} K_*nu_V/6`。现在关键是先对 V 求和：

    sum_V K_*nu_V(x)<=K_*f(x)<=q(x),                  (TR10)

因为 `sum_V nu_V<=sum_V beta_V<=f dx`，且 K_* 是共同 future。不能对每个 V 分别以 q 上放后再求和；那样会产生未付叶数。

所以 fixed x 的总边界至多 `e^{-h}q/6`。原唯一 `j(x)` 在 x 行内保留合并；这里只选一个共同 K_*，没有尺度菜单或 soft 网格费用。hard 源使用一次 `q^{-1}h_Rnu<=16/3`，再乘外 `2Lambda`，得 TR7。原 history 权属于 [0,1]；按原顺序保留后作正上界不会引入独立 history 总预算。时间已由 TR2 结算，不再乘 log2。

更一般地，若实际所有初始时刻满足 `g/ell<=r_*<=2`，只需在 TR5 将 `n log2` 换为 `n log r_*`。r_* 必须对正在共同计价的行统一，不能每个 y 另选 future 然后仍用 TR10。

## 3. 明确的正体积空间子类与全部维度常数

TR5 可以直接由 receiver-source 坐标几何核验。令 `z_i=|x_i-v_i|/b`。逐坐标准确有

    K_*/J = product_i a_s(z_i),
    a_s(z)=s+(1-s)/phi(z),     0<=z<=1/2,
    a_s(z)=s,                 z>1/2.                 (TR11)

因此内部坐标贡献正放大，外部坐标贡献 log s 的损失；不得把后者删除。设 F 个坐标在面带 `d0<=z_i<=1/2`，C 个在 `0<=z_i<d0`，O 个在外面，F+C+O=n，则

    S_x(v)>=F log[s+(1-s)/phi(d0)]
             +C log[s+(1-s)/phi(0)]+O log s.          (TR12)

只要 TR12 右端超过 `n log2+h`，整个该空间子类属于 E_h。它对任意相关来源成立，不使用乘积来源或坐标独立性。

一个完全显式、非零厚度的例子是

    0<s<=1/10,
    19/40 <= |x_i-v_i|/b <= 1/2   for every i.          (TR13)

给出所需 phi 常数的初等证明。因

    phi(1/2)=int_0^1 a(1-exp(-1/a)) da,

在 `[1/2,3/4]` 上 `exp(-1/a)>1/8`，在 `[3/4,1]` 上大于 1/4，故

    phi(1/2)<1/2-(5/32)/8-(7/32)/4=109/256.

这里仅用 `e^2<8,e^(4/3)<4`。又 `phi'=w(z+1/2)-w(z-1/2)` 且 `0<=w<=1`，故 phi 的 Lipschitz 常数至多 1。因此

    phi(19/40)<109/256+1/40=577/1280.

TR13 上的每个坐标于是有

    a_s(z)>=1/10+(9/10)/(577/1280)=12097/5770=:a_*>2.

所以该源面带部分满足

    RawBoundary(face)
       <=(16 Lambda/9)(11540/12097)^n int_D q dx.      (TR14)

这给出了真正指数小的接收点价格，包含所有初始、删除、外 beta、hard 源和实际 dx。对指定吸收系数 zeta>0，足够取

    n >= log(16Lambda/(9zeta))/log(12097/11540)

（若分子为负，条件自动满足），即可把 TR14 右端上放为 `zeta int_D q dx`。这不是隐藏 n 依赖的常数。

该面带有正厚度 b/40，每个坐标两侧均可取；不依赖 L1 来源落在测度零的硬面上。原 s 的严格下门仍须保留，TR13 只与它在足够大维度上相交。本文没有声称全部好源都在面带，亦没有证明原 rho>0、high、历史与此面带同时存在 FULL 正交通。

## 4. 与外 y 的已付 future-gain 域严格区分

R168/R169 的 nearmax 条件是外中心 y 的

    R_ext(x,y)=sup_future P_future(x-y)/p_y < exp(H).

TR5、TR11–14 约束的是内好源 v 的 `K_*(x-v)/J_v`，不要求外 y 的 future gain 大。因此 TR7 可在原 nearmax 行上原样使用：始终保留该行指示，TR8–10 的正上界不变。费用仍然是 TR7，不多付 exp(H)。

这说明代数估计适用于 nearmax 与 source-face 的交集；不等于已经认证该交集有新的 FULL 正交通。若原更早门已完全排除该交集，它的实际贡献为零，不能登记新增覆盖。当前合同没有提供该排除或正覆盖证明。

相比之下，单用外 y 的条件

    J(x-y)/p_y >= (g/ell)^n/(C sqrt(n))

来抵消最坏比值，若右端已超过 exp(H)，就只回到旧已付 high-future 域。本稿不把这类外壳重新登记为 R171 的中间覆盖。

## 5. 完整剩余、逆 e 混合接口与正混合证书

本稿实际支付的是 TR1 的固定 source-v 部分。其补集仍为

    v notin E_h(x),

以及全部 signed 缺陷项。来源分割 `A=A1_Eh+A1_Eh^c` 不依辅助时间，边界 TR2 线性分开；但不能因此给两个部分各分配一遍原负项。若要把 TR7 升级为整行 signed 付款，仍须对同一完整行处理 R170 原 `C_GG,C_GE,H_Z,R_rev,R_eta,Ndel,F_final`，特别是已经消费的 suffix 信用不能再次使用。

另一个更细的、尚待构造证书的实际接口是

    M_y(x)=QJ(x)^{-1} int_{A_y>0} J_v Xi_y(v)nu_V(dv).

在 QJ=0 行边界为零。设固定 `(omega,x,j)` 的同一个正测度 theta 在合法 future 参数上，令

    K_theta(x-y)=int P_future(x-y) theta(dfuture),
    theta(total)<=C_theta.

theta 可以按 x 共同选择，但不得依正在积分的 y、v、V，且须可测。若某个完整行分支满足

    p_y M_y(x)<=L_n K_theta(x-y),                       (TR15)

则 high、TR4 和 good 给

    int_high,branch p_y B_y[A] beta_V(dy)
       <= L_n C_theta QJ,V(x)/6.

同样一次 hard 帽及 unique j 后，

    RawBoundary(branch)
       <=(16Lambda/9)L_n C_theta W_beta.              (TR16)

所有维度成本就是 L_n C_theta；没有免费的正混合总质量。若 `L_n C_theta=O(sqrt(n)n^{o(1)})`，这是目标来源价格。TR15 用真实 J 来源平均和精确删除逆 e 的 Xi，而不是 `sup_v R_initial`。但一般原条件尚未推出 TR15；把左侧定义成某个“已知矩”不能证明它。本文不将 TR15 本身计作新增独立几何估计。

按实际 log 比值来源壳假设指数尾，当然也能推出 TR15 的一个充分条件；若该尾并非从原 FIRST、共同来源或具体空间条件导出，它只是假设待估矩的另一种写法，本稿不作主成果。

## 6. 最具体的下一缺口

已证明的新具体估计是 TR7，及从物理 kernel 自证的正厚度面带 TR14。其 source-v future 放大通过 `sum nu<=f` 在同一个接收点结清，价格为可指定的小 `q dx` 项。它不依赖无权列界的误用，也不需要极值来源彼此独立。

尚缺的是 `S_x(v)<n log2+h` 的来源补集，特别是在外中心 y 仍 nearmax、Xi 的 J 来源平均又不能由 TR15 支配时，如何用同一输入与 UP5 同时饱和几何给来源 W_beta 价格或可吸收接收点价格。UP5 的五项亏损本身没有控制 y,v 相关的逆 w_g 倍数；本文未作这一推断。

本轮没有证明全体一般 middle；没有把形式壳尾或新范数当作已付款。已将具体源槽估计和剩余覆盖完整落盘，供独审后冻结。
