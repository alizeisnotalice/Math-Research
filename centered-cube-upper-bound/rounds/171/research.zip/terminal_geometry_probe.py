#!/usr/bin/env python3
"""Bounded R171 atomic terminal-ratio probe; finite numerical gates only."""
from pathlib import Path
from fractions import Fraction as F
from decimal import Decimal
import importlib.util, json, hashlib, math, platform, sys, time
HERE=Path(__file__).resolve().parent
SOURCE_DIR=Path('/Users/zhengzhihao/Desktop/T/output/centered_cube_round169_20261016_final_checkpoint')
R170=Path('/Users/zhengzhihao/Desktop/T/output/centered_cube_round170_20261016_final_checkpoint')
R168=Path('/Users/zhengzhihao/Desktop/T/output/centered_cube_round168_20261016_final_checkpoint')
COMPLETION=SOURCE_DIR/'completion_certificate.json'
RUNTIME=R168/'lp_candidate_certificate.py'
spec=importlib.util.spec_from_file_location('r171_frozen_r168',RUNTIME); ct=importlib.util.module_from_spec(spec);spec.loader.exec_module(ct)
iv=ct.iv; I=ct.I
NU=[F(3,25),F(2749,3125),F(1,3125)]
Q=F(9,2500); S=F(1,4); L=F(9,10); A=F(1,2); B=F(1); K=F(1)
X0=[F(51,100)]+[F(2,5)]*3
POS=[[F(53,50)]+[F(19,20)]*3,[F(-3,5)]*4,X0]
RPOS=[F(24,25)]+[F(17,20)]*3
G=math.sqrt(float(L)); GFR=F(str(G)); HHI=G*math.exp(-1/400)
XI=[F(51,100),F(52,100),F(53,100)]

def asI(x): return I(F(x)) if not hasattr(x,'lo') else x
def prod(vals):
    z=I(1)
    for v in vals:z=z*v
    return z

def kern_float(s,scale,deltas,N=64):
    # Frozen certified kernel, midpoint used only for the quadrature observation.
    z=ct.kern(F(s),F(scale),[F(abs(d)) for d in deltas],N); return float((z.lo+z.hi)/2)

def C_float(d,N=64):
    z=iv.C(abs(F(d)),N); return float((z.lo+z.hi)/2)
def wt(Crow,xi): return math.prod(min(1.0,c/xi) if c>0 else 0.0 for c in Crow)
def kernel_cache():
    # Fixed support pair C((y-v)/b), and receiver kernels indexed by rational coordinates.
    cs=[]
    for y in POS+[RPOS]:
        cs.append([[C_float((yi-vi)/B) for yi,vi in zip(y,v)] for v in POS])
    return cs

def receiver_nodes(order):
    # Midpoint product quadrature on declared X=[-2b,2b]^4, translated around x0.
    n=order
    vals=[-2+(4*(i+0.5)/n) for i in range(n)]
    return [[float(x)+z for x,z in zip(X0,v)] for v in __import__('itertools').product(vals,repeat=4)]

def run():
    started=time.monotonic(); comp=json.loads(COMPLETION.read_text())
    mlo,mhi=map(float,comp['refinements'][-1]['exact_added_mass_interval'])
    current_nu=sum(float(nu)*kern_float(S,L,[x-z for x,z in zip(X0,y)]) for nu,y in zip(NU,POS))
    completion_kernel=kern_float(S,L,[x-z for x,z in zip(X0,RPOS)])
    M=(float(Q)-current_nu)/completion_kernel
    assert mlo<=M<=mhi
    masses=list(map(float,NU))+[M]; sources=POS+[RPOS]
    cs=kernel_cache(); terminal=[[wt(crow,float(GFR)) for crow in row] for row in cs]
    eg=[sum(float(nu)*terminal[y][v] for v,nu in enumerate(NU)) for y in range(4)]
    # Stage 1 source table at x0, including actual completion beta atom. y=0 is a zero-beta negative control.
    stage1=[]
    for yi,y in enumerate(sources):
        p=kern_float(S,L,[x-z for x,z in zip(X0,y)])
        et=[sum(float(nu)*wt(cs[yi][v],float(xi)) for v,nu in enumerate(NU)) for xi in XI]
        row={'source_index':yi,'position':[str(z) for z in y], 'beta_mass':masses[yi], 'p_at_x0':p,
             'e_g':eg[yi], 'high':bool(p*eg[yi]>=2*float(K*Q)),
             'time_rows':[{'xi':float(xi),'e_t':e,'eta':(2*float(K*Q)/(p*e) if p*e else None)} for xi,e in zip(XI,et)],
             'zero_beta_negative_control':False}
        stage1.append(row)
    yzero=[F(0)]*4; czero=[[C_float(vi) for vi in v] for v in POS]; wgz=[wt(crow,float(GFR)) for crow in czero]
    egz=sum(float(nu)*wgz[v] for v,nu in enumerate(NU)); pz=kern_float(S,L,[x for x in X0])
    stage1_control={'source_index':'zero_beta_control','position':['0']*4,'beta_mass':0.0,'p_at_x0':pz,'e_g':egz,
        'high':bool(pz*egz>=2*float(K*Q)),'time_rows':[{'xi':float(xi),'e_t':sum(float(nu)*wt(czero[v],float(xi)) for v,nu in enumerate(NU))} for xi in XI],
        'zero_beta_negative_control':True,'excluded_from_all_beta_integrals':True}
    # A rational algebra-only identity check (separate from geometric measures).
    Mv=[F(1,4),F(1,3),F(1,5)]; Hv=[F(1),F(0),F(1)]; etav=[F(1,2),F(1),F(3,4)]; zv=[F(1),F(1),F(1)]; wv=[F(1),F(1,2),F(3,4)]
    Ds=[1-sum(Mv),sum((m*(1-h) for m,h in zip(Mv,Hv)),F(0)),sum((m*h*(1-e) for m,h,e in zip(Mv,Hv,etav)),F(0)),sum((m*h*e*(1-z) for m,h,e,z in zip(Mv,Hv,etav,zv)),F(0)),sum((m*h*e*z*(1-w) for m,h,e,z,w in zip(Mv,Hv,etav,zv,wv)),F(0))]
    assert sum(Ds)==1-sum((m*h*e*z*w for m,h,e,z,w in zip(Mv,Hv,etav,zv,wv)),F(0))
    # Cached kernels: all receiver/source and future grid pairs.
    kp={}
    def P(x,y,s=S,l=L):
        key=(tuple(round(z,12) for z in x),tuple(map(str,y)),str(s),str(l))
        if key not in kp:kp[key]=kern_float(s,l,[F(str(a))-b for a,b in zip(x,y)])
        return kp[key]
    rows=[]
    # Design calls for three spatial orders; keep execution bounded and reproducible.
    for order in (3,5,7):
        nodes=receiver_nodes(order);dx=256/(order**4)
        strict=optimistic=excluded=0.0; totals={str(r):0.0 for r in (1,2,4,8,2)}
        btot=0.0; highmass=0.0; qualmass=0.0; point_count=0; future_survivors=0
        deficits=[0.0]*5; deficit_identity_max_residual=0.0; minimum_deficit=float('inf'); maximum_eta_high=0.0; gamma_sum=0.0; ratio_max=0.0; zero_wg=0; gate_both=gate_avgonly=gate_oldonly=0.0; gate_rows=0
        for x in nodes:
            fcur=sum(m*P(x,y) for m,y in zip(masses,sources))
            # Current upper qualification is tested against fixed common q.
            if fcur>float(Q)*(1+1e-10):
                excluded+=dx;continue
            qualmass+=dx;point_count+=1
            future_ok=True
            for u in (S,F(5,8),F(1)):
                for ell in (A,F(3,4),B):
                    fu=sum(m*P(x,y,u,ell) for m,y in zip(masses,sources))
                    if fu>float(Q)*(1+1e-10): future_ok=False
            if future_ok:future_survivors+=1
            else: continue
            # R170 terminal-ratio decision pair, evaluated at initial xi=a/c=1/2.
            qj=sum(float(nuv)*P(x,v,F(1),B) for nuv,v in zip(NU,POS))
            for yi,y in enumerate(sources):
                py=P(x,y);
                if py*eg[yi] < 2*float(K*Q) or qj<=0: continue
                rs=[wt(cs[yi][vi],0.5)/terminal[yi][vi] for vi in range(3) if terminal[yi][vi]>0]
                if len(rs)!=3: continue
                av=sum(float(nuv)*P(x,v,F(1),B)*r for nuv,v,r in zip(NU,POS,rs))/qj
                gain=P(x,y,F(1),B)/py if py>0 else math.inf
                avg_gate=av/(math.sqrt(4)*gain) if gain>0 else math.inf
                old_gate=max(rs)/math.sqrt(4)
                w=dx*masses[yi]*qj
                gate_rows+=1
                if avg_gate<=1 and old_gate>1: gate_both+=w
                elif avg_gate<=1: gate_avgonly+=w
                elif old_gate>1: gate_oldonly+=w
            # Evaluate representative auxiliary time points. Time-window integration remains a finite quadrature.
            tlog=math.log(HHI/0.5); xis=[0.5*math.exp(tlog*(j+0.5)/32) for j in range(32)]
            for xi in xis:
                es=[sum(float(nu)*wt(cs[i][v],xi) for v,nu in enumerate(NU)) for i in range(4)]
                for i,y in enumerate(sources):
                    py=P(x,y); eg_i=eg[i]
                    if not (py*eg_i>=2*float(K*Q)): continue
                    if not (es[i]>0 and eg_i>0): continue
                    eta=2*float(K*Q)/(py*es[i]);
                    if eta>1+1e-10: continue
                    for vi,v in enumerate(POS):
                        wg=terminal[i][vi]; wt0=wt(cs[i][vi],xi)
                        if wg<=0:
                            if wt0>0:zero_wg+=1
                            continue
                        R=wt0/wg
                        bmass=masses[i]/es[i]
                        jval=P(x,v,F(1),B)
                        traffic=dx*float(NU[vi])*jval*bmass/32
                        if traffic==0:continue
                        gamma_sum+=traffic*R
                        btot+=traffic
                        ratio_max=max(ratio_max,R)
                        for rr in sorted(set((1,2,4,8,math.sqrt(4)))):
                            if R>=rr:totals[str(rr)]+=traffic*R
                            # Same-measure five deficits at v, weighted by column measure M=p beta/q.
                            # Accumulate pointwise deficit masses once per active v/time row below.
                    # deficit identity for this source/receiver/time, summed over beta sources.
                # Deficits are column quantities for each v and computed with common beta measure.
                for vi,v in enumerate(POS):
                    c=0.0; d=[0.0]*5; mvec=[]
                    for i,y in enumerate(sources):
                        py=P(x,y); Mcol=py*masses[i]/float(Q); hig=py*eg[i]>=2*float(K*Q)
                        ei=es[i]; zet=ei>0; wt0=wt(cs[i][vi],xi)
                        et=2*float(K*Q)/(py*ei) if py*ei>0 else 2.0
                        eta_h=et
                        onez=1.0 if zet else 0.0
                        mvec.append((Mcol,hig,eta_h,onez,wt0))
                    d[0]=1-sum(a[0] for a in mvec)
                    d[1]=sum(a[0]*(not a[1]) for a in mvec)
                    d[2]=sum(a[0]*a[1]*(1-a[2]) for a in mvec)
                    d[3]=sum(a[0]*a[1]*a[2]*(1-a[3]) for a in mvec)
                    d[4]=sum(a[0]*a[1]*a[2]*a[3]*(1-a[4]) for a in mvec)
                    c_high=sum(masses[i]*wt(cs[i][vi],xi)/es[i] for i in range(4) if mvec[i][1] and es[i]>0)
                    deficit_identity_max_residual=max(deficit_identity_max_residual,abs(sum(d)-(1-2*float(K)*c_high)))
                    minimum_deficit=min(minimum_deficit,*d)
                    for i in range(4):
                        if mvec[i][1]: maximum_eta_high=max(maximum_eta_high,mvec[i][2])
                    for k in range(5):deficits[k]+=dx*float(NU[vi])*P(x,v,F(1),B)*d[k]/32
        rows.append({'spatial_order':order,'node_count':len(nodes),'receiver_box_volume':256.0,
            'quadrature_dx':dx,'current_qualified_volume':qualmass,'excluded_volume':excluded,
            'current_qualified_nodes':point_count,'future_grid_survivors':future_survivors,
            'finite_future_grid_qualified_volume':future_survivors*dx,
            'future_grid':'u={1/4,5/8,1}; Lprime={1/2,3/4,1}; finite necessary tests only',
            'I_time_sampled':gamma_sum*math.log(HHI/0.5),'B_time_sampled':btot*math.log(HHI/0.5),
            'time_log_length_factor':math.log(HHI/0.5),'time_integral_is_midpoint_log_quadrature':True,
            'terminal_ratio_gate_rows':gate_rows,'avg_gate_le_1_and_old_sup_gate_gt_1_weight':gate_both,
            'avg_gate_le_1_only_weight':gate_avgonly,'old_sup_gate_gt_1_only_weight':gate_oldonly,
            'I_over_B':(gamma_sum/btot if btot else None),'C_t':2*float(K)*gamma_sum*math.log(HHI/0.5)/sum(map(float,NU)),
            'tail_I_time_sampled':{k:v*math.log(HHI/0.5) for k,v in totals.items()},'max_R_observed':ratio_max,'zero_wg_positive_wt_count':zero_wg,
            'Jnu_dt_weighted_deficit_integrals':[z*math.log(HHI/0.5) for z in deficits],
            'max_abs_deficit_identity_residual':deficit_identity_max_residual,'min_D_observed':minimum_deficit,'max_eta_on_high':maximum_eta_high,
            'tail_traffic_conditional_deficit_distribution':'not computed; reported deficits are Jnu dt weighted integrals','boundary':'not constructed',
            'all_integrals_are_finite_midpoint_quadrature_observations':True})
    out={'scope':'GEOMETRIC-NECESSARY atomic common-input numerical receiver study; no L1 density, rigorous dx bound, original history, or FULL claim.',
        'inputs':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in (COMPLETION,RUNTIME,ct.DEP,R170/'pair_certificate.py',R170/'task_contract.md')},
        'frozen_geometry':{'n':4,'nu':[str(z) for z in NU],'q':str(Q),'beta_equals_f':'nu plus R169 completion atom; mass recomputed from the frozen kernel formula at x0 in float arithmetic',
            'completion_mass_interval':[mlo,mhi],'completion_mass_used':M,'completion_mass_recomputed_same_frozen_kernel':True,'completion_mass_in_frozen_interval':mlo<=M<=mhi,'x0':[str(z) for z in X0],
            'positions':[[str(z) for z in y] for y in sources],'s':str(S),'L':str(L),'a':str(A),'b':str(B),'K':str(K),'g':str(GFR)},
        'parameters':{'terminal_g':'sqrt(9/10) from frozen R170 construction; time endpoint h=g*exp(-1/400)','xi_stage1':[str(z) for z in XI],'receiver_X':'x0+[-2b,2b]^4','time_xi':'32 midpoint nodes in [1/2,h] on log scale, h=sqrt(9/10) exp(-1/400); exact log-window factor applied; threshold splitting omitted',
            'kernel_interval_subdivisions':64,'future_grid_u':['1/4','5/8','1'],'future_grid_Lprime':['1/2','3/4','1']},
        'stage1_all_beta_rows':stage1,'stage1_zero_beta_negative_control':stage1_control,'algebra_unit_check':{'label':'ALGEBRA only','five_deficits':[str(z) for z in Ds],'identity_pass':True},
        'receiver_study':rows,'qualification':{'current':'P_{s,L} beta(x)<=fixed q','future':'displayed finite-grid upper tests; no continuum certification',
            'x0_current_equality':'R169 frozen F symbolic completion; same-kernel float recomputation is used here, without a new interval equality certificate','FIRST':'not asserted','Z':'conditional Z=all specialization only'},
        'runtime':{'python':sys.version,'platform':platform.platform(),'wall_seconds':round(time.monotonic()-started,3)},
        'limitations':['Float midpoint receiver and time quadrature; no interval-enclosed dx estimate.','Threshold-split time nodes were not constructed; temporal convergence is unresolved.','Future finite grid is a rejection/unresolved test, never a continuum FIRST proof.','R169 completion mass is recomputed from the same frozen kernel in floating point and checked against its frozen interval; no new interval equality certificate is produced.','Stage 3 Decimal interval cell refinement not performed.','No terminal A/history/deletions; boundary and deletion accounting not constructed.']}
    (HERE/'terminal_geometry_probe.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({'out':str(HERE/'terminal_geometry_probe.json'),'orders':[{'order':r['spatial_order'],'qualified_volume':r['current_qualified_volume'],'I':r['I_time_sampled'],'B':r['B_time_sampled'],'C':r['C_t']} for r in rows]},indent=2))
if __name__=='__main__':run()
