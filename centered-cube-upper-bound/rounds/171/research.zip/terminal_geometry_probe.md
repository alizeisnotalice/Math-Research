# R171 terminal-ratio probe

This is a finite numerical study of the frozen four-atom R169 input. It is labeled **GEOMETRIC-NECESSARY**: the atomic input is not an L1 density, receiver integration is midpoint quadrature, and the displayed future grid does not certify continuum FIRST or an original history/FULL claim.

Reproduce from the repository root with:

```sh
python3 -B centered-cube-upper-bound/rounds/171/work/terminal_geometry_probe.py
```

The script imports the frozen R168/R170 kernel runtime and writes its full record to [terminal_geometry_probe.json](terminal_geometry_probe.json). The R169 completion mass is recomputed from the same frozen kernel formula at x0: 0.004178206901786601, inside the frozen certified interval [0.004178172337729377, 0.004178208170400762]. This is a floating point recomputation of the symbolic completion, not a new interval certificate.

All four actual beta rows are present. At x0 the source at x0 (beta mass 0.00032) and completion atom r (mass about 0.004178207) pass the high gate. The other two actual beta atoms fail it. The separate y=0 negative control has zero beta mass; although its formal row passes high at x0, it is explicitly excluded from all beta integrals. The actual high rows have eta below 0.382 throughout the reported receiver/time cells.

The receiver box is x0+[-2b,2b]^4, with volume 256. Current qualification uses fixed q=9/2500 and all four beta atoms. The finite necessary future tests use u in {1/4,5/8,1} and L' in {1/2,3/4,1}. Current-qualified volume estimates at spatial orders 3/5/7 are 230.72/242.07/241.18; finite-future-qualified volumes are 208.59/217.09/220.49. Order 7 uses 2,401 receiver points. These are numerical volume observations only.

The time quadrature uses 32 midpoint nodes in xi in [1/2,h], with h=sqrt(9/10) exp(-1/400), and includes the log-window factor. On the current-and-finite-future-qualified receiver grid, the estimates are:

| Spatial order | I | B | I/B | C_t |
|---:|---:|---:|---:|---:|
| 3 | 4.0764e-4 | 2.0058e-4 | 2.0323 | 8.1528e-4 |
| 5 | 1.8894e-4 | 1.3189e-4 | 1.4326 | 3.7789e-4 |
| 7 | 1.3752e-5 | 6.7669e-6 | 2.0323 | 2.7504e-5 |

Here C_t=2K I/||nu||. The receiver totals change substantially with order, so spatial convergence fails the requested tolerance. Gate discontinuities and the product midpoint quadrature leave these estimates unresolved. The five reported deficit values per order are Jnu dt weighted integrals in the JSON; the maximum five-deficit identity residual is 2.3e-16, the minimum observed deficit is 0, and the tail-traffic conditional deficit distribution was not computed.

For the source-average versus old-sup comparison at xi=1/2, the grid found no positive weight with average_gate<=1 and old_sup_gate>1. Positive weight appeared where both average_gate>1 and old_sup_gate>1; that category fails both conditions and is not a paid sup branch. No terminal A or deletion history was supplied, so actual boundary and deletion-jump cost is `not constructed`.

The run does not split time nodes at all C thresholds and does not perform Stage-3 directed-Decimal cell refinement. The finite future gate, temporal and spatial quadrature, and floating midpoint kernels remain limitations. High beta traffic is nonzero, but these unstable finite totals provide no general compensation conclusion.
