#!/usr/bin/env python3
"""Independent R171 point-row interval calculation; no probe import or dx claim."""
from pathlib import Path
from fractions import Fraction as F
import hashlib, importlib.util, json, sys
HERE=Path(__file__).resolve().parent
FROZEN=Path('/Users/zhengzhihao/Desktop/T/output/centered_cube_round168_20261016_final_checkpoint/lp_candidate_certificate.py')
sp=importlib.util.spec_from_file_location('r171_point_frozen_interval',FROZEN)
ct=importlib.util.module_from_spec(sp);sp.loader.exec_module(ct)
I=ct.I
X=[F(51,100)]+[F(2,5)]*3
POS=[[F(53,50)]+[F(19,20)]*3,[F(-3,5)]*4,X]
R=[z+F(9,20) for z in X]
NU=[F(3,25),F(2749,3125),F(1,3125)]
Q=F(9,2500)

def run(N):
    g=I(F(9,10)).sqrt()
    def kernel(s,l,y):return ct.kern(s,l,[a-b for a,b in zip(X,y)],N)
    J=[kernel(F(1),I(1),v) for v in POS]
    QJ=sum((I(m)*z for m,z in zip(NU,J)),I(0))
    current_nu=sum((I(m)*kernel(F(1,4),I(F(9,10)),v) for m,v in zip(NU,POS)),I(0))
    completion_kernel=kernel(F(1,4),I(F(9,10)),R)
    completion_mass=(I(Q)-current_nu)/completion_kernel
    assert completion_mass.lo>0
    rows=[]
    for j,y,beta in ((2,X,I(NU[2])),(3,R,completion_mass)):
        C=[[ct.iv.C(abs(a-b),N) for a,b in zip(y,v)] for v in POS]
        wg=[ct.prod((c/g).capped_one() for c in row) for row in C]
        wi=[ct.prod((c/I(F(1,2))).capped_one() for c in row) for row in C]
        ratios=[a/b for a,b in zip(wi,wg)]
        av=sum((I(m)*z*r for m,z,r in zip(NU,J,ratios)),I(0))/QJ
        py=kernel(F(1,4),I(F(9,10)),y);jy=kernel(F(1),I(1),y)
        eg=sum((I(m)*w for m,w in zip(NU,wg)),I(0))
        high=py*eg/I(2*Q);gain=jy/py;gate=av/(I(2)*gain)
        # max enclosure is valid for a finite family of intervals.
        sup=I(max(r.lo for r in ratios),max(r.hi for r in ratios))
        assert high.lo>1 and gate.lo>1 and sup.lo>2 and beta.lo>0
        rows.append(dict(source_index=j,position=list(map(str,y)),beta_mass=beta.out(),
            high_ratio=high.out(),R_initial=[r.out() for r in ratios],
            e_g=eg.out(),a_y=av.out(),futuregain=gain.out(),average_gate=gate.out(),
            sup_ratio=sup.out(),old_sup_gate=(sup/I(2)).out(),
            decisions=dict(positive_beta=True,high=True,average_condition_fails=True,old_sup_condition_fails=True)))
    return dict(subdivisions=N,g_exact_interval=g.out(),QJ=QJ.out(),
                completion_mass_exact_formula_interval=completion_mass.out(),rows=rows)

def main():
    dependencies=[FROZEN,Path(ct.DEP)]
    # ct.DEP itself imports the frozen lower-level kernel; retain its path/hash too.
    for name in ('iv','old'):
        module=getattr(ct,name,None)
        filename=getattr(module,'__file__',None)
        if filename:dependencies.append(Path(filename))
    dependencies=list(dict.fromkeys(dependencies))
    out=dict(scope='Directed interval finite atomic geometry at one receiver x0; no positive-dx, FIRST/history, or global branch claim.',
        arithmetic='Frozen directed Decimal interval runtime; g=sqrt(9/10) interval, no float arithmetic in bounds.',
        inputs={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in dependencies},
        parameters=dict(n=4,x0=list(map(str,X)),positions=[list(map(str,v)) for v in POS],
            completion_position=list(map(str,R)),nu=list(map(str,NU)),q=str(Q),
            s='1/4',L='9/10',b='1',K='1',initial_xi='1/2',terminal_g='sqrt(9/10)',
            beta='full original nu plus positive completion mass (q-Pcurrent nu(x0))/Pcurrent delta_r(x0)'),
        refinements=[run(64),run(128)],python=sys.version,
        limitations=['Only two actual high beta rows at x0.','No receiver integration or whole-time interval certification.',
                    'Failure of these sufficient candidate tests does not disprove any general bound.'])
    target=HERE/'numeric_point_certificate.json';target.write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(dict(output=str(target),refinements=[dict(N=r['subdivisions'],average_gate=[z['average_gate'] for z in r['rows']]) for r in out['refinements']]),indent=2))
if __name__=='__main__':main()
