# R171 — common extremal geometry and terminal-ratio compensation

Start f0961dd91678a0d9dd1759389ec5f7f46d615aa9, clean main. R170 is verified progress and pushed. General positive-L1 root-order weak bound remains open. Priority is construction of global extremal geometry and its integrated traffic budget, not expansion of counterexample searches.

Frozen necessary context: /Users/zhengzhihao/Desktop/T/output/centered_cube_round170_20261016_final_checkpoint/{task_contract.md,uncaptured_pair_budget.md,soft_threshold_energy.md,proof.tex.txt}. Read only assigned excerpts. Earlier definitions only if cited there. No PDF compilation. Shared files: write only assigned paths, no Git/spawn, do not revert others. Deliver a bounded checkpoint and stop. Parent integrates, audits and pushes one complete round.

Core definitions unchanged: h=1[-.5,.5], phi=h*w, F=max(h,phi), C=h*F; w_time(y,v)=prod min(1,C((y_i-v_i)/b)/xi). C,F not probabilities. nu<=beta<=f dx, sum beta<=f per seed. p_y=P_s,L(x-y), current f=q, all future P_u,L'f<=q for u>=s,L' in[a,b]; q common. Sources frozen before x. Pi_y,t=1_Z wt nu/e_t is original, e_t>=e_g on eligible times. high p_y e_g>=2Kq. Terminal g/G/B/alpha/rho fixed during auxiliary time. Original positive and unconsumed negative accounts remain on common complete receiver/history row.

R170 verified: T_x(y,dv)=1_high Pi_y,t(dv) has beta T_x<=nu/(2K), and analytic beta T_x^m<=(2K)^-m nu. At fixed b, integrating terminal J_b(x-v) against true dx gives (2K)^-m||nu||, with zero extension outside valid receiver domain. This is not an original history chain or a weighted raw bound.

Exact extremal geometry: M_x=p_y beta/q subprobability, eta_t=2Kq/(p_y e_t) on high. 2K d(beta T)/dnu(v)=int M high eta_t 1_Z wt(y,v). Its deficit is the sum of five nonnegative terms: missing FIRST beta mass, nonhigh mass, eta gap, support gap, overlap gap (1-wt). Near saturation forces all simultaneously on the SAME measure. Soft overlap loss sum[log(xi/C)]_+ is not delta; near-threshold counts may be large while loss small.

Verified boundary theorem: A(v)=rho_y(v)chiJ_v 1_G, F_t=Pi_t A. If wt_initial/wg<=e^M on A>0, initial+all deletion jumps <=e^M C_A/e_g, C_A=int A wg nu. good gives p_y C_A<=K Jnu/3, high/FIRST gives int_high beta/e_g<=1/(2K). Real raw boundary cost (16Lambda/9)e^M Wbeta; M<=.5log n is root order. No extra unique-j/time/deletion count fee. Removing this SUP ratio cost by actual joint geometry is this round's main target, not asserting M small universally.

General signed account R=F_initial-F_final+sum jumps-int(C_GG+C_GE+H_Z+R_rev+R_eta)dt/t-Ndel. Same-alpha gives real R_rev credit via 1-A>=min(1,(DK0+alphaJ)/(TDelta)). H_Z tracks ALREADY consumed suffix credit, cannot reuse. Row branches must be independent of auxiliary time and multiply original positive/negative accounts together once.

Equivalent unproved raw column retains G_y(v)delta/A_y, A_y=alphaQJ/D and G_y=TDelta[1-DK0/(TDelta)]_+²/wg. Unweighted column contraction does not control this multiplier. Actual y-dependent uncaptured measure retains wt/(eK0); bad posterior mass alone does not cancel it. No normalization of beta/nu or new support allowed.

Main candidate quantity for terminal ratio: R_t(y,v)=wt(y,v)/wg(y,v), Gamma_t(x,v)=int_high R_t(y,v)/e_t(y) beta(dy). good gives p_y Pi_t A <=(K/3)int J_b(x-v)R_t(y,v)nu(dv)/e_t(y). Seek a joint integrated bound/positive dual envelope with common FIRST and source overlap; do not replace Gamma by its definition as an alleged bound. Deletion terms must retain their exact common inverse-e measure. A terminal ratio tail estimate must pay real dx, nu,beta and all time/scale costs. General claim remains unproved.

Staffing this round: Astra high x1 main bottleneck; Sol high x2 distinct auxiliary and independent audit; Sol medium x1 numeric/certificate design; at most four Luna medium for clearly distinct bounded support work. No need to fill slots. All key lemmas require parent/Sol independent verification. Three-stage tests for important numerical strategies, no new standalone counterexample program. Outcome must distinguish proved general/conditional statements and finite evidence.
