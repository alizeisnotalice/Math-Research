# Parent verification and version binding

Main inspected original R107 integration.md lines9–15 and77–104: a,b,q common over E precede leaves; R128 RT1 confirms s(x),L(x) dependence. TR price is confined to that common window. Main independently followed inverse-e telescoping, good/high integration, sum-before-FIRST, hard16/3 and outer2Λ, obtaining16Λ/9. The source split pays only boundary; signed credit is not split twice.

Main read both full manuscripts. S8 follows by independent min(A_v,A_u) decomposition of G, with actual E and Psi=0 B; capacity is the same v/score-layer original reverse. All-layer sum exactly reproduces count differences. No new n fee. Both manuscript scopes match the independent Sol audit. Complete proof and covering theorem remain absent.

Three numerical scripts were replayed outside the repository. Point-certificate outputs match every mathematical field under bundled Python3.12 and original Python3.14; Python-version metadata differs. Probe mathematics matches identically after removing runtime/platform metadata. Score final version replaces the audit-identified tautological field by separately computed g_vell and asserts S8 at each layer; removes the unused R166 archive dependency. This parent correction does not alter the mathematical model. The final packaged driver repeats all scripts and compares full non-runtime JSON.

No numeric mesh convergence is claimed: physical 3/5/7 receiver totals differ greatly. Threshold splitting/time convergence and outside-box control remain open. Exact abstract nodes do not prove continuous time or FULL. All scores use strict C_i<xi, and only E can be deleted in these algebraic models.

No PDF compilation. Audit hashes bind the versions explicitly named in the audit; final archive inventory binds parent corrections. The complete work directory is backed up byte-for-byte before repository work-folder removal. Three tracked paths only: round README, research.zip, project index. No actual per-model debit data was available.
