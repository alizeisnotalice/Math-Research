#!/usr/bin/env python3
"""Bounded joint objective probe from saved coefficients; no kernel rerun."""
from pathlib import Path
from fractions import Fraction as F
import sys,json,hashlib,datetime,time,traceback
sys.set_int_max_str_digits(0)
sys.path.insert(0,'/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor')
import mpmath as mp
from mpmath.calculus.quadrature import TanhSinh
ROOT=Path(__file__).resolve().parent
SRC=ROOT.parent/'centered_cube_round136_20261014/active_traffic_v2.json'
CAP=ROOT.parent/'centered_cube_round138_20261015/core_capacity_probe.json'
OUT=ROOT/'numeric_joint.json'
EXPECTED_SRC='1090fb2356abe035a997eb851a2f0252a3abe3edbeaf978e99900a38906392de'
EXPECTED_CAP='268bd6ca487de9111dec63085c81c9bfd2fc5eb8aa760483dd000581eae6900d'
ORDER=['I1','I2','P1','I3','I4','P2','P3','P4','E1','E2','E3','E4']
RULE=TanhSinh(mp.mp)
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def fr(x):return F(str(x))
def jf(x):return F(int(x['numerator']),int(x['denominator']))
def mf(q):return mp.mpf(q.numerator)/q.denominator
def fj(q):return dict(numerator=str(q.numerator),denominator=str(q.denominator))
def dec(x,dps=None):return mp.nstr(x,dps or mp.mp.dps)
def save(data):OUT.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
def line_at(line,m):return line[0]*m+line[1]
def rel(a,b):return abs(a-b)/max(abs(b),mp.mpf('1e-2000'))

class Model:
 def __init__(self,case,cap):
  self.case=case;self.cap=cap;self.at=case['atoms'];self.n=case['n'];self.sup=jf(cap['mass_supremum'])
  self.p=fr(case['derived']['p']);self.T=fr(case['derived']['T']);self.K=fr(case['parameters']['K']);self.D=fr(case['parameters']['D']);self.BFA=fr(case['parameters']['B_FA'])
  self.fixed=[fr(a['nu']) for a in self.at[:4]];self.f0=1-sum(self.fixed)
  self.lines={k:(jf(v['slope']),jf(v['intercept'])) for k,v in cap['affine_coefficients'].items()}
  self.W=jf(cap['heavy_saved_rational_coefficient']);self.U=[jf(a['rebuilt']) for a in cap['rebuilt_U_audit']]
  self.A=[fr(a['A']) for a in self.at];self.J=[fr(a['J']) for a in self.at];self.K0=[fr(a['K0']) for a in self.at]
  self.av=[max(1-self.D*self.K0[i]/(self.T*self.A[i]),F(0)) if self.A[i]>0 else F(0) for i in range(6)]
  self.lam=self.D*self.K0[5]-self.U[5];assert self.lam>0
  self.oldlam=max(self.D*self.T*(fr(case['derived']['H0'])/fr(case['derived']['Hhat']))**self.n-self.T,F(0));assert self.oldlam==0
  self.segs=[]
  for s in case['score_segments']:
   lo,hi=fr(s['lo']),fr(s['hi']);assert lo<hi and len(s['c'])==len(s['k'])==6
   ks=[sum(fr(al)**2<lo*hi for al in a['thresholds']) for a in self.at];assert ks==s['k']
   self.segs.append(dict(lo=lo,hi=hi,k=ks,c=[fr(x) for x in s['c']]))
  assert self.segs[0]['lo']==fr(case['derived']['tau']) and self.segs[-1]['hi']==fr(case['derived']['h'])
  assert all(self.segs[i-1]['hi']==s['lo'] for i,s in enumerate(self.segs) if i)
  self.pairs=[];self.psi_check=[];primitive_cache={}
  for i,v in enumerate(self.at):
   for j,u in enumerate(self.at):
    increments=[]
    for si,s in enumerate(self.segs):
     power=s['k'][i]+s['k'][j];diff=s['k'][i]-s['k'][j]
     key=(si,power)
     if key not in primitive_cache:primitive_cache[key]=(s['lo']**(-power)-s['hi']**(-power))/power if power else F(0)
     increments.append(diff*s['c'][i]*s['c'][j]*primitive_cache[key])
    suffix=[F(0)]*(len(increments)+1)
    for ii in range(len(increments)-1,-1,-1):suffix[ii]=suffix[ii+1]+increments[ii]
    psi=max(suffix)>0;old=case['pairs'][i*6+j]
    assert old['v']==v['name'] and old['z_prime']==u['name'] and not old['suffix_ambiguous']
    assert old['Psi']==psi,'Saved-coefficient Psi reconstruction mismatch'
    eligibility=v['good'] and u['bad'] and psi
    self.pairs.append(dict(pid=i*6+j,i=i,j=j,v=v['name'],u=u['name'],Psi=psi,eligible=eligibility))
    self.psi_check.append(dict(pid=i*6+j,Psi=psi,saved_agrees=True,max_suffix_sign=1 if max(suffix)>0 else 0))
  self.prep={};self.nodes={}

 def prepare(self,dps):
  if dps in self.prep:return self.prep[dps]
  mp.mp.dps=dps;pieces=[]
  for si,s in enumerate(self.segs):
   candidates=[];cuts=[mf(s['lo']),mf(s['hi'])]
   for pair in self.pairs:
    if not pair['eligible']:continue
    i,j=pair['i'],pair['j'];delta=max(s['k'][i]-s['k'][j],0)
    if not delta:continue
    kv=s['k'][i];assert kv>0
    Kfa=self.BFA*delta*self.p*s['c'][i]/fr(self.at[i]['Q'])
    if Kfa<=s['lo']**kv:continue
    cap=mf(s['hi']) if Kfa>=s['hi']**kv else mf(Kfa)**(mp.mpf(1)/kv)
    if cap<mf(s['hi']):cuts.append(cap)
    candidates.append(dict(**pair,delta=delta,N=s['k'][i]+s['k'][j],factor=delta*s['c'][i]*s['c'][j],cap=cap))
   cuts=sorted(set(cuts))
   for lo,hi in zip(cuts,cuts[1:]):
    if hi<=lo:continue
    mid=mp.sqrt(lo*hi);active=[p for p in candidates if mid<p['cap']]
    if not active:continue
    pieces.append(dict(index=len(pieces),segment=si,lo=lo,hi=hi,loglo=mp.log(lo),loghi=mp.log(hi),pairs=active,k=s['k'],c=[mf(x) for x in s['c']]))
  self.prep[dps]=pieces;return pieces

 def state(self,m):
  qvals={lab:line_at(self.lines[lab],m) for lab in ['Q0','QJ','Qstar']};q=max(qvals.values());QJ=qvals['QJ'];eg=line_at(self.lines['eg'],m);Ut=line_at(self.lines['Utotal'],m)
  alpha=(self.D*q-Ut)/QJ;nu=self.fixed+[self.f0-m,m]
  rho=[max(1-(self.U[i]+alpha*self.J[i])/(self.T*self.A[i]),F(0)) if self.at[i]['good'] and self.A[i]>0 else F(0) for i in range(6)]
  positive=[self.at[i]['name'] for i in range(6) if rho[i]>0 and self.at[i]['good']]
  gates=dict(m_positive=m>0,far_positive=self.f0-m>0,high=self.p*eg>=2*self.K*q,heavy=eg>self.W*q,hard_cap=m<=4*q,q_positive=q>0,alpha_nonnegative=alpha>=0,positive_good_rho=bool(positive))
  gamma=[];threshold=F(1,(self.n+1)**3)
  for i,a in enumerate(self.at):
   if not a['good'] or self.A[i]<=0:continue
   G=(QJ/q)*self.av[i]**2*self.T*self.A[i]/(4*self.J[i]*self.lam)
   actual=(m/q)*rho[i];assert actual<=G
   gamma.append(dict(v=a['name'],positive_rho=rho[i]>0,Gamma_support=dec(mf(G)),QJ_over_q=dec(mf(QJ/q)),threshold=dec(mf(threshold)),small_gain_pass=G<=threshold,actual_m_rho_over_q=dec(mf(actual)),support_bound_pass=True))
  assert alpha*QJ>=self.lam*m
  return dict(q=q,QJ=QJ,eg=eg,alpha=alpha,nu=nu,rho=rho,gates=gates,allowed=all(gates.values()),positive_good=positive,q_winners=[lab for lab,val in qvals.items() if val==q],hard=self.p*m/q,gamma=gamma)

 def node_shapes(self,piece,degree,dps,Ns):
  key=(dps,piece['index'],degree,tuple(Ns))
  if key in self.nodes:return self.nodes[key]
  ks=sorted(set(piece['k']));out=[]
  for x,w in RULE.get_nodes(piece['loglo'],piece['loghi'],degree,mp.mp.prec):
   powers={k:mp.exp(-k*x) for k in set(ks+Ns)}
   out.append((w,[powers[k] for k in ks],[powers[n] for n in Ns]))
  self.nodes[key]=(ks,out);return ks,out

 def kernel_vector(self,piece,nu,dps,Ns):
  coef={k:mp.fsum(nu[i]*piece['c'][i] for i in range(6) if piece['k'][i]==k) for k in set(piece['k'])}
  xm=(piece['loglo']+piece['loghi'])/2;em=mp.fsum(val*mp.exp(-k*xm) for k,val in coef.items());norm=[mp.exp(-N*xm)/(em*em) for N in Ns]
  prev=None;last_error=None;target=mp.mpf('1e-70') if dps==90 else mp.mpf('1e-100')
  for degree in range(1,10):
   ks,nodes=self.node_shapes(piece,degree,dps,Ns);sums=[[] for _ in Ns]
   for w,powers,nums in nodes:
    et=mp.fsum(coef[k]*power for k,power in zip(ks,powers));den=et*et
    for ni,num in enumerate(nums):sums[ni].append(w*num/(den*norm[ni]))
   h=mp.mpf(2)**(-degree);cur=[(prev[ni]/2 if prev is not None else 0)+h*mp.fsum(values) for ni,values in enumerate(sums)]
   if prev is not None:
    last_error=max(rel(cur[ni],prev[ni]) for ni in range(len(Ns)))
    if degree>=3 and last_error<=target:break
   prev=cur
  values={N:cur[ni]*norm[ni] for ni,N in enumerate(Ns)}
  return values,dict(degree=degree,last_relative_change=dec(last_error) if last_error is not None else None,target=dec(target),converged=last_error is not None and last_error<=target)

 def evaluate(self,m,dps,definition,stage,nodeid):
  mp.mp.dps=dps;start=time.monotonic();st=self.state(m);pieces=self.prepare(dps)
  nu=[mf(x) for x in st['nu']];rho=[mf(x) for x in st['rho']]
  contributions=[mp.mpf(0)]*36;records=[];warnings=0
  # Boundary with no rho has exact zero objective, not an eligible peak.
  for piece in pieces:
   active=[p for p in piece['pairs'] if rho[p['i']]>0 and nu[p['i']]>0 and nu[p['j']]>0]
   Ns=sorted(set(p['N'] for p in active));values={};conv=dict(degree=0,last_relative_change=None,target=None,converged=True)
   if Ns:values,conv=self.kernel_vector(piece,nu,dps,Ns)
   if not conv['converged']:warnings+=1
   part=[]
   for p in active:
    val=rho[p['i']]*nu[p['i']]*nu[p['j']]*mf(p['factor'])*values[p['N']]
    contributions[p['pid']]+=val;part.append(dict(pid=p['pid'],contribution=dec(val),shared_power=p['N']))
   def et(t):return mp.fsum(nu[i]*piece['c'][i]*t**(-piece['k'][i]) for i in range(6))
   records.append(dict(piece=piece['index'],segment=piece['segment'],lo=dec(piece['lo']),hi=dec(piece['hi']),e_t_lo=dec(et(piece['lo'])),e_t_mid=dec(et(mp.sqrt(piece['lo']*piece['hi']))),e_t_hi=dec(et(piece['hi'])),shared_kernels={str(N):dec(value) for N,value in values.items()},pair_contributions=part,quadrature=conv))
  good={a['name']:mp.fsum(contributions[i*6:(i+1)*6]) for i,a in enumerate(self.at) if a['good']};S=mp.fsum(contributions);total=mf(st['hard'])*S
  if st['allowed'] and not total>0:raise ArithmeticError('Allowed positive-rho model returned nonpositive objective')
  rec=dict(node_id=nodeid,stage=stage,precision=dps,mass_definition=definition,m=dec(mf(m)),fraction_of_sup=dec(mf(m/self.sup)),q=dec(mf(st['q'])),q_winners=st['q_winners'],alpha=dec(mf(st['alpha'])),QJ=dec(mf(st['QJ'])),QJ_over_q=dec(mf(st['QJ']/st['q'])),e_g=dec(mf(st['eg'])),nu=[dec(x) for x in nu],rho=[dec(x) for x in rho],positive_good=st['positive_good'],gates=st['gates'],eligible=st['allowed'],hard_prefactor=dec(mf(st['hard'])),internal_S=dec(S),objective_F=dec(total),good_contributions={key:dec(value) for key,value in good.items()},pair_contributions=[dec(v) for v in contributions],time_piece_records=records,quadrature_warning_count=warnings,Gamma_support_at_m=st['gamma'],status='positive_eligible' if st['allowed'] else 'excluded_boundary_or_gate',elapsed_seconds=time.monotonic()-start,FULL_certified=False)
  return rec,total

 def static_record(self):
  H=fr(self.case['derived']['Hhat']);y=fr(self.case['parameters']['y']);needed=abs(y)+H/2
  return dict(pair_masks=self.psi_check,score_segments=[dict(lo=str(s['lo']),hi=str(s['hi']),k=s['k'],c_saved=self.case['score_segments'][i]['c']) for i,s in enumerate(self.segs)],old_lambda0=fj(self.oldlam),old_Gamma_not_applicable=True,uniform_HM3=dict(computed=False,reason='Missing saved C at farthest box coordinate; kernel recomputation prohibited',required_C_distance=str(needed),omega_core=None,lambda_uniform=None),lambda_support=fj(self.lam),lambda_support_scope='Exact for saved coefficients on finite hard support CORE only; not a general box infimum',hard_R=1)

LABELS=['Q0','QJ','Qstar']
OLD=ROOT.parent/'centered_cube_round139_20261015/joint_objective_probe.json'
MASS=ROOT.parent/'centered_cube_round140_20261015/mass_direction.json'
EXPECTED_OLD='302321823f8b7ef6df3cff2ac6b9ad3ec3b3be0dc5ffe509602a4ca0643df27d'
EXPECTED_MASS='4ebd47e297561e5f39f7badb87842dcf17aebf255042fdd4da3b15152600e127'
MENU=[('initial',0,[F(1,2),F(1),F(2)]),('pressure',1,[F(1,4),F(1),F(4)]),('expanded',2,[F(1,4),F(2),F(8)])]
IDS=['I1','I2','P1']
def addl(a,b):return (a[0]+b[0],a[1]+b[1])
def scal(x,a):return (x*a[0],x*a[1])
def sub(a,b):return addl(a,scal(F(-1),b))
def affine(l):return dict(slope=fj(l[0]),intercept=fj(l[1]))
def intersect(items):
 lo,hi=F(0),None;lop=True;hip=False;fail=[];bounds=[]
 for name,(a,b),strict in items:
  if a==0:
   if b<0 or (b==0 and strict):fail.append(name)
   continue
  root=-b/a;bounds.append((name,a,root,strict))
  if a>0:
   if root>lo:lo,lop=root,strict
   elif root==lo:lop=lop or strict
  else:
   if hi is None or root<hi:hi,hip=root,strict
   elif root==hi:hip=hip or strict
 assert hi is not None
 empty=bool(fail) or lo>hi or (lo==hi and (lop or hip))
 return dict(feasible=not empty,lower=fj(lo),upper=fj(hi),lower_open=lop,upper_open=hip,constant_failures=fail,lower_active=[x[0] for x in bounds if x[1]>0 and x[2]==lo],upper_active=[x[0] for x in bounds if x[1]<0 and x[2]==hi])

class JointModel(Model):
 def __init__(self,case,cap,chosen,factor,shared):
  super().__init__(case,cap);self.chosen=chosen;self.factor=factor;self.oldfixed=list(self.fixed);self.oldf0=self.f0
  self.old_sigma=(self.lines['QJ'][1]-self.lines['Q0'][1])/(self.lines['Q0'][0]-self.lines['QJ'][0])
  self.fixed[chosen]*=factor;self.f0=1-sum(self.fixed)
  def line(values):return (values[5]-values[4],sum(self.fixed[i]*values[i] for i in range(4))+self.f0*values[4])
  self.lines={lab:line([fr(a[field]) for a in self.at]) for lab,field in [('Q0','K0'),('QJ','J'),('Qstar','Q'),('eg','wg')]};self.lines['Utotal']=line(self.U)
  self.prep=shared.setdefault('prep',{});self.nodes=shared.setdefault('nodes',{})
  self.effective_good=set();self.active_bad=set();self.FA_audit=[]
  for pair in self.pairs:
   if not pair['eligible']:continue
   i,j=pair['i'],pair['j']
   for si,s in enumerate(self.segs):
    delta=s['k'][i]-s['k'][j]
    if delta<=0:continue
    Kfa=self.BFA*delta*self.p*s['c'][i]/fr(self.at[i]['Q'])
    if Kfa<=s['lo']**s['k'][i]:continue
    assert Kfa>=s['hi']**s['k'][i],'Partial FA unexpectedly present; preserve failure instead of redefining'
    oldpiece=next(x for x in self.case['pairs'][pair['pid']]['pieces'] if x['score_segment']==si)
    assert oldpiece['FA_active'] and fr(oldpiece['FA_active_lo'])==s['lo'] and fr(oldpiece['FA_active_hi'])==s['hi']
    self.FA_audit.append(dict(pair=pair['pid'],segment=si,full_FA_margin=fj(Kfa-s['hi']**s['k'][i]),old_interval_agrees=True))
    self.effective_good.add(i);self.active_bad.add(j)
  self.candidates=[i for i in sorted(self.effective_good) if self.at[i]['good'] and self.T*self.A[i]-self.U[i]>0]
  assert self.candidates==[0,1,2]
  self.cells=[]
  for lab in LABELS:
   q=self.lines[lab];common=[('m_positive',(F(1),F(0)),True),('far_positive',(F(-1),self.f0),True)]
   for other in LABELS:
    if other!=lab:common.append((lab+'>='+other,sub(q,self.lines[other]),False))
   common += [('high',sub(scal(self.p,self.lines['eg']),scal(2*self.K,q)),False),('heavy',sub(self.lines['eg'],scal(self.W,q)),True),('hard_cap',sub(scal(F(4),q),(F(1),F(0))),False),('q_positive',q,True),('QJ_positive',self.lines['QJ'],True),('alpha_nonnegative',sub(scal(self.D,q),self.lines['Utotal']),False)]
   for i in self.candidates:
    N=addl(sub(scal((self.T*self.A[i]-self.U[i])/self.J[i],self.lines['QJ']),scal(self.D,q)),self.lines['Utotal'])
    cell=intersect(common+[(f'rho:{i}',N,True)]);cell.update(winner=lab,good=self.at[i]['name']);self.cells.append(cell)
  feasible=[jf(c['upper']) for c in self.cells if c['feasible']];self.sup=max(feasible) if feasible else None
 def state(self,m):
  st=super().state(m)
  st['gates']['QJ_positive']=st['QJ']>0
  st['gates']['positive_effective_good_rho']=any(st['rho'][i]>0 and st['nu'][i]>0 for i in self.candidates)
  st['gates']['all_masses_nonnegative']=min(st['nu'])>=0
  st['allowed']=all(st['gates'].values())
  Cout=sum(st['nu'][i]*self.K0[i] for i in self.active_bad if i!=5)
  for rec in st['gamma']:
   i=next(i for i,a in enumerate(self.at) if a['name']==rec['v']);ae=max(self.av[i]-self.D*Cout*self.J[i]/(self.T*self.A[i]*st['QJ']),F(0))
   rec.update(C_out=fj(Cout),active_bad_names=[self.at[j]['name'] for j in sorted(self.active_bad) if j!=5],a_original=fj(self.av[i]),a_eff=fj(ae),Gamma_eff_over_Gamma=fj((ae/self.av[i])**2) if self.av[i]>0 else None,scope='Candidate joint deduction diagnostic only; no change to target/gates')
  return st
 def evaluate(self,m,dps,definition,stage,nodeid):
  rec,value=super().evaluate(m,dps,definition,stage,nodeid);rec['mass_exact']=fj(m);rec['changed_source']=self.at[self.chosen]['name'];rec['source_multiplier_exact']=fj(self.factor)
  # Original baseline e_t at its exact sigma, just samples, no extra integration.
  oldnu=self.oldfixed+[self.oldf0-self.old_sigma,self.old_sigma]
  for piece in rec['time_piece_records']:
   ss=self.segs[piece['segment']];c=[mf(x) for x in ss['c']];lo,hi=mf(ss['lo']),mf(ss['hi']);oldet=[mp.fsum(mf(oldnu[i])*c[i]*t**(-ss['k'][i]) for i in range(6)) for t in [lo,mp.sqrt(lo*hi),hi]]
   piece['baseline_sigma_e_t_samples']=[dec(x) for x in oldet];piece['e_t_over_baseline_sigma_samples']=[dec(mp.mpf(piece[key])/x) for key,x in zip(['e_t_lo','e_t_mid','e_t_hi'],oldet)]
  return rec,value

def fr_to_mp(s):return mf(fr(s))
def main():
 if OUT.exists():raise SystemExit('Refuse second numeric_joint producer run')
 for path,expected in [(SRC,EXPECTED_SRC),(CAP,EXPECTED_CAP),(OLD,EXPECTED_OLD),(MASS,EXPECTED_MASS)]:assert sha(path)==expected
 src=json.loads(SRC.read_text());cap=json.loads(CAP.read_text());old=json.loads(OLD.read_text());sm={c['id']:c for c in src['cases']};cm={c['id']:c for c in cap['cases']};om={c['id']:c for c in old['cases']}
 out=dict(status='running',run_count=1,started_utc=utc(),input_sha256={str(p):sha(p) for p in [SRC,CAP,OLD,MASS]},sha256={str(p):sha(p) for p in [Path(__file__),ROOT/'numeric_plan.md']},scope='Bounded 2D finite saved-coefficient model, not global optimization/FULL/dx volume/order',slices=[],exceptions=[],verifications=[],limits=dict(evaluations_90=270,verifications_120=18),counters=dict(evaluations_90=0,verifications_120=0));save(out)
 shared={cid:{} for cid in IDS};models={};baseline_seen=set();serial=0
 for stage,chosen,factors in MENU:
  # factor first makes the first three completed slices exactly I1/I2/P1 G1 half.
  for factor in factors:
   for cid in IDS:
    start=time.monotonic();key=f'{stage}:{cid}:G{chosen+1}:{factor}';row=dict(id=key,case=cid,stage=stage,source=f'G{chosen+1}',multiplier=fj(factor),status='initializing',points=[],exceptions=[]);slot=len(out['slices']);out['slices'].append(row)
    def checkpoint():save(out)
    try:
     if factor==1:
      base=om[cid];row.update(status='old_baseline_reference',duplicate_baseline=cid in baseline_seen,source_json=str(OLD),old_summary=base['summary'],note='No old producer/integral rerun');baseline_seen.add(cid);checkpoint();continue
     model=JointModel(sm[cid],cm[cid],chosen,factor,shared[cid]);models[key]=model
     row.update(affine_coefficients={k:affine(v) for k,v in model.lines.items()},winner_rho_cells=model.cells,FA_audit=model.FA_audit,Psi_audit=model.psi_check,supremum=fj(model.sup) if model.sup is not None else None)
     if model.sup is None:row['status']='empty_necessary_domain';checkpoint();print(key,row['status'],flush=True);continue
     masses={};values={};index={}
     def add(m,definition,part):
      nonlocal serial
      if m in index:return
      st=model.state(m)
      if not st['allowed']:
       row.setdefault('excluded_nodes',[]).append(dict(mass_exact=fj(m),definition=definition,gates=st['gates']));checkpoint();return
      assert out['counters']['evaluations_90']<270
      nid=serial;serial+=1;out['counters']['evaluations_90']+=1
      try:
       rec,val=model.evaluate(m,90,definition,part,nid);row['points'].append(rec);masses[nid]=m;values[nid]=val;index[m]=nid
      except Exception:
       row['exceptions'].append(dict(node_id=nid,mass_exact=fj(m),traceback=traceback.format_exc()));out['exceptions'].append(dict(slice=key,node_id=nid,type='node'))
      checkpoint()
     for frac in [F(1,16),F(1,4),F(1,2),F(3,4),F(15,16)]:add(model.sup*frac,dict(kind='sup_fraction',x=fj(frac)),'coarse')
     roots={}
     for ii,lab in enumerate(LABELS):
      for other in LABELS[ii+1:]:
       a,b=sub(model.lines[lab],model.lines[other])
       if a:
        root=-b/a
        if 0<root<=model.sup:roots.setdefault(root,[]).append(dict(kind='q_crossing',labels=[lab,other]))
     rhoroots={}
     for i in model.candidates:
      for lab in LABELS:
       q=model.lines[lab];N=addl(sub(scal((model.T*model.A[i]-model.U[i])/model.J[i],model.lines['QJ']),scal(model.D,q)),model.lines['Utotal']);a,b=N
       if a:
        root=-b/a
        if 0<root<=model.sup and line_at(q,root)==max(line_at(model.lines[z],root) for z in LABELS):rhoroots.setdefault(root,[]).append(dict(kind='rho_zero',good=model.at[i]['name'],winner=lab))
     assert len(rhoroots)<=3,'More than three actual rho zeros; frozen structural budget failure'
     for m,defs in rhoroots.items():roots.setdefault(m,[]).extend(defs)
     roots.setdefault(model.sup,[]).append(dict(kind='supremum_endpoint'))
     for m,defs in sorted(roots.items()):add(m,dict(kind='structural',definitions=defs),'structural')
     if stage=='expanded' and values:
      ids=sorted(masses,key=masses.get);center=min(values,key=lambda i:(-values[i],masses[i]));pos=ids.index(center);proposals=[]
      for jj in [pos-1,pos+1]:
       if 0<=jj<len(ids):proposals.append(((masses[center]+masses[ids[jj]])/2,dict(kind='one_level_arithmetic_midpoint',neighbors=[center,ids[jj]])))
      for m,definition in proposals:add(m,definition,'local')
     row['status']='completed_samples' if values else 'no_eligible_sample';row['elapsed_seconds']=time.monotonic()-start
     if values:
      best=min(values,key=lambda i:(-values[i],masses[i]));row['summary']=dict(best_node_id=best,best_F=next(x['objective_F'] for x in row['points'] if x['node_id']==best),best_mass=fj(masses[best]),evaluations_90=len(row['points']),global_optimum_certified=False)
     checkpoint();print(key,row['status'],'points',len(row['points']),'best',row.get('summary',{}).get('best_F'),'elapsed',row['elapsed_seconds'],flush=True)
    except Exception:
     row.update(status='slice_exception',traceback=traceback.format_exc(),elapsed_seconds=time.monotonic()-start);out['exceptions'].append(dict(slice=key,type='slice'));checkpoint();print(key,'slice_exception',flush=True)
  # fixed stage best and best actual Q0=QJ for each case, ties explicitly marked.
  for cid in IDS:
   candidates=[(row,x) for row in out['slices'] if row['stage']==stage and row['case']==cid for x in row['points'] if x['eligible'] and mp.mpf(x['objective_F'])>0]
   crosses=[(row,x) for row,x in candidates if 'Q0' in x['q_winners'] and 'QJ' in x['q_winners']]
   selected=[]
   for pool,label in [(candidates,'stage_best'),(crosses,'stage_best_Q0_QJ')]:
    if not pool:continue
    mp.mp.dps=90;best=max(mp.mpf(x['objective_F']) for _,x in pool);tied=[(row,x) for row,x in pool if (best-mp.mpf(x['objective_F']))/max(abs(best),mp.mpf('1e-2000'))<=mp.mpf('1e-50')];tied.sort(key=lambda rx:(jf(rx[1]['mass_exact']),rx[0]['source'],jf(rx[0]['multiplier'])))
    out.setdefault('selection_records',[]).append(dict(stage=stage,case=cid,role=label,tied_nodes=[x['node_id'] for _,x in tied],representative=tied[0][1]['node_id']))
    if all(x['node_id']!=tied[0][1]['node_id'] for _,x in selected):selected.append(tied[0])
   for row,x in selected:
    assert out['counters']['verifications_120']<18
    out['counters']['verifications_120']+=1
    try:
     model=models[row['id']];rec,val=model.evaluate(jf(x['mass_exact']),120,x['mass_definition'],'verification',x['node_id']);errs={'F':rel(val,mp.mpf(x['objective_F'])),'S':rel(mp.mpf(rec['internal_S']),mp.mpf(x['internal_S']))}
     for name,v in rec['good_contributions'].items():
      if mp.mpf(v) or mp.mpf(x['good_contributions'][name]):errs['good:'+name]=rel(mp.mpf(v),mp.mpf(x['good_contributions'][name]))
     rec['verification']=dict(relative_errors={k:dec(v) for k,v in errs.items()},passed=all(v<=mp.mpf('1e-60') for v in errs.values()) and rec['gates']==x['gates'] and rec['positive_good']==x['positive_good']);rec['slice']=row['id'];out['verifications'].append(rec);save(out)
    except Exception:out['exceptions'].append(dict(slice=row['id'],node_id=x['node_id'],type='verification',traceback=traceback.format_exc()));save(out)
  print('stage_complete',stage,out['counters'],flush=True)
 out['summary']={}
 for cid in IDS:
  stable=[x for x in out['verifications'] if x['slice'].split(':')[1]==cid and x['verification']['passed']];mp.mp.dps=120
  best=max(stable,key=lambda x:mp.mpf(x['objective_F'])) if stable else None
  base=om[cid]['summary'];out['summary'][cid]=dict(best_verified_node_id=best['node_id'] if best else None,best_slice=best['slice'] if best else None,best_F=best['objective_F'] if best else None,old_baseline_F=base['best_verified_F'],best_over_old=dec(mp.mpf(best['objective_F'])/mp.mpf(base['best_verified_F'])) if best else None,best_q_winners=best['q_winners'] if best else None,global_optimization_certified=False)
 out['status']='completed_with_errors' if out['exceptions'] else 'completed_finite_samples';out['finished_utc']=utc();save(out);print('FINAL',json.dumps(out['summary']),out['counters'],flush=True)


def postrun_diagnostics():
 """Read-only algebra after producer; no model instantiation or quadrature."""
 out=json.loads(OUT.read_text());src=json.loads(SRC.read_text());cap=json.loads(CAP.read_text());sm={c['id']:c for c in src['cases']};cm={c['id']:c for c in cap['cases']};rows={r['id']:r for r in out['slices']};hits=[];counts=dict(positive_records=0,positive_good_records=0,threshold_crossing_good_records=0,old_Gamma_above_threshold=0)
 def calculate(row,rec,precision_label):
  c=sm[row['case']];ca=cm[row['case']];atoms=c['atoms'];m=jf(rec['mass_exact']);mult=jf(row['multiplier']);chosen=int(row['source'][1:])-1
  fixed=[fr(a['nu']) for a in atoms[:4]];fixed[chosen]*=mult;nu=fixed+[1-sum(fixed)-m,m]
  vals={lab:line_at((jf(row['affine_coefficients'][lab]['slope']),jf(row['affine_coefficients'][lab]['intercept'])),m) for lab in LABELS};q=max(vals.values());QJ=vals['QJ'];D=fr(c['parameters']['D']);T=fr(c['derived']['T']);U=[jf(a['rebuilt']) for a in ca['rebuilt_U_audit']];K0=[fr(a['K0']) for a in atoms];lam=D*K0[5]-U[5];activebad=set()
  for audit in row['FA_audit']:activebad.add(audit['pair']%6)
  # Definition has B=original activebad and U=0. This menu's B is G4 only.
  assert all(U[j]==0 for j in activebad)
  Rbad=D*(q-vals['Q0'])+sum((D*K0[j]-(lam if j==5 else 0))*nu[j] for j in activebad)
  threshold=F(1,(c['n']+1)**2);outv=[];positive=mp.mpf(rec['objective_F'])>0 and rec['eligible']
  if positive:counts['positive_records']+=1
  for i,a in enumerate(atoms):
   if not a['good'] or fr(a['A'])<=0:continue
   TA=T*fr(a['A']);J=fr(a['J']);av=max(1-D*K0[i]/TA,F(0));ae=max(av-J*Rbad/(TA*QJ),F(0));Gam=(QJ/q)*av**2*TA/(4*J*lam) if lam>0 else None;Ghat=(QJ/q)*ae**2*TA/(4*J*lam) if lam>0 else None
   eligible_v=positive and fr(rec['rho'][i])>0
   hit=eligible_v and Gam is not None and Gam>threshold and Ghat<=threshold
   if eligible_v:
    counts['positive_good_records']+=1
    if Gam is not None and Gam>threshold:counts['old_Gamma_above_threshold']+=1
   if hit:counts['threshold_crossing_good_records']+=1;hits.append(dict(slice=row['id'],node_id=rec['node_id'],precision=precision_label,v=a['name']))
   outv.append(dict(v=a['name'],a_original=fj(av),a_eff=fj(ae),Gamma=fj(Gam) if Gam is not None else None,Gammahat=fj(Ghat) if Ghat is not None else None,Gammahat_over_Gamma=fj((ae/av)**2) if av>0 else None,threshold=fj(threshold),positive_F_and_rho=eligible_v,old_Gamma_gt_threshold=Gam is not None and Gam>threshold,Gammahat_le_threshold=Ghat is not None and Ghat<=threshold,requested_crossing=hit))
  rec['joint_deduction_diagnostic_v2']=dict(R_bad=fj(Rbad),lambda_support=fj(lam),activebad=[atoms[j]['name'] for j in sorted(activebad)],core_in_activebad=5 in activebad,core_subtraction_term=fj(lam*m if 5 in activebad else F(0)),q_minus_Q0=fj(q-vals['Q0']),good=outv,scope='Postrun exact saved-coefficient diagnostic; target and integration unchanged; support-specific lambda')
 for row in out['slices']:
  for rec in row['points']:calculate(row,rec,90)
 for rec in out['verifications']:calculate(rows[rec['slice']],rec,120)
 out['postrun_diagnostic_v2']=dict(producer_not_rerun=True,no_additional_integration=True,original_diagnostic_retained_as_history=True,counts=counts,hits=hits,code_sha256=sha(Path(__file__)),formula='Rbad=D(q-Q0)+sum_activebad (D K0-lambda_support 1_CORE) nu; Gammahat/Gamma=(a_eff/a)^2',limitation='Finite nodes only; positive-F good rho criterion; no claim of FULL or coverage of general bad sets')
 old=json.loads(OLD.read_text());out['fee_comparisons_to_original_sigma']={}
 for cid,summary in out['summary'].items():
  rec=next(x for x in out['verifications'] if x['node_id']==summary['best_verified_node_id']);basecase=next(x for x in old['cases'] if x['id']==cid);base=next(x for x in basecase['verifications'] if x['node_id']==basecase['summary']['best_verified_node_id']);mp.mp.dps=120
  out['fee_comparisons_to_original_sigma'][cid]=dict(hard_ratio=dec(mp.mpf(rec['hard_prefactor'])/mp.mpf(base['hard_prefactor'])),internal_ratio=dec(mp.mpf(rec['internal_S'])/mp.mpf(base['internal_S'])),rho_G1_ratio=dec(mp.mpf(rec['rho'][0])/mp.mpf(base['rho'][0])),good_shares={k:dec(mp.mpf(v)/mp.mpf(rec['internal_S'])) for k,v in rec['good_contributions'].items()},e_t_ratio_samples=rec['time_piece_records'][0]['e_t_over_baseline_sigma_samples'],interpretation='Correlated factor accounting; no extra fixed-e counterfactual integral')
 out['execution_audit']=dict(producer_session_id=75465,producer_exit_code=0,producer_runs=1,completed_new_slices=sum(r['status']=='completed_samples' for r in out['slices']),baseline_reference_rows=sum(r['status']=='old_baseline_reference' for r in out['slices']),all_slice_sample_bests_on_Q0_QJ=all(next(p for p in r['points'] if p['node_id']==r['summary']['best_node_id'])['q_winners']==['Q0','QJ'] for r in out['slices'] if r.get('summary')),producer_exception_count=len(out['exceptions']),quadrature_warning_count=sum(p['quadrature_warning_count'] for r in out['slices'] for p in r['points']),failed_precision_comparisons=sum(not x['verification']['passed'] for x in out['verifications']),maximum_relative_comparison_error=dec(max(mp.mpf(e) for x in out['verifications'] for e in x['verification']['relative_errors'].values())),excluded_necessary_gate_nodes=sum(len(r.get('excluded_nodes',[])) for r in out['slices']),postrun_only=True)
 save(out);print(json.dumps(counts), 'hits',len(hits))
if __name__=='__main__':
 if '--postrun-diagnostics' in sys.argv:postrun_diagnostics()
 else:main()
