from fractions import Fraction as F
from pathlib import Path
import random,json,hashlib
rng=random.Random(141)
out={'scope':'necessary rational algebra only; not FULL, geometry, or dimension asymptotics','stages':[]}
for stage,count,ns,span in [('initial',12,4,5),('overlap_zero',120,8,20),('expanded',600,24,1000)]:
    stats=dict(stage=stage,cases=count,positive_lambda=0,zero_lambda=0,overlap=0,strict_improvement=0,positive_rho=0)
    digest=hashlib.sha256()
    for case in range(count):
        N=rng.randint(3,ns); D=F(rng.randint(1,4)); nu=[F(rng.randint(1,span),rng.randint(1,span)) for _ in range(N)]
        K=[F(rng.randint(1,span),rng.randint(1,span)) for _ in range(N)]
        J=[F(rng.randint(1,span),rng.randint(1,span)) for _ in range(N)]; J[0]=F(1,1000000)
        B={i for i in range(1,N) if rng.randrange(2)}
        if case%12==0:B=set()
        TA=[D*k*F(rng.randint(1,8),4) for k in K]; TA[0]=D*K[0]*2
        U=[F(0) if i in B else min(TA[i],D*K[i]) for i in range(N)]
        S={i for i in range(N) if rng.randrange(2)}
        if not S:S={N-1}
        d=[D*K[i]-U[i] for i in range(N)]
        lam=min(d[i] for i in S)
        Q0=sum(K[i]*nu[i] for i in range(N)); QJ=sum(J[i]*nu[i] for i in range(N))
        q=max(Q0,QJ)+F(rng.randrange(3),10); Ut=sum(U[i]*nu[i] for i in range(N)); alpha=(D*q-Ut)/QJ
        M=sum(nu[i] for i in S); debit=D*(q-Q0)+sum((D*K[i]-(lam if i in S else 0))*nu[i] for i in B)
        a=max(F(0),1-D*K[0]/TA[0]); b=J[0]/TA[0]
        ae=max(F(0),a-b*debit/QJ); rho=max(F(0),a-b*alpha)
        assert debit>=0 and alpha*QJ>=lam*M+debit
        assert rho<=ae
        stats['overlap']+=bool(S&B);stats['positive_rho']+=rho>0
        if lam>0:
            old=QJ*a*a/(4*q*lam*b); new=QJ*ae*ae/(4*q*lam*b)
            assert M*rho/q<=new<=old
            stats['positive_lambda']+=1;stats['strict_improvement']+=new<old
            mstar=ae*QJ/(2*b*lam)
            assert mstar*max(F(0),ae-b*lam*mstar/QJ)/q==new
        else:stats['zero_lambda']+=1
        digest.update(repr((nu,K,J,D,TA,U,sorted(B),sorted(S),q,lam,debit,ae,rho)).encode())
    stats['input_result_digest']=digest.hexdigest();out['stages'].append(stats)
out['pass']=True
out['script_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
out['protocol_sha256']=hashlib.sha256(Path('reserve_protocol.md').read_bytes()).hexdigest()
path=Path('reserve_check.json')
if path.exists():raise RuntimeError('refuse overwrite')
path.write_text(json.dumps(out,indent=2)); print(json.dumps(out,indent=2))
