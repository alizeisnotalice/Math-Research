from fractions import Fraction as F
from pathlib import Path
import json,sys,hashlib
sys.set_int_max_str_digits(0)
b=Path(__file__).resolve().parent
j=json.loads((b/'numeric_joint.json').read_text())
src={c['id']:c for c in json.loads((b.parent/'centered_cube_round136_20261014/active_traffic_v2.json').read_text())['cases']}
def fr(x):return F(str(x))
def jf(x):return F(int(x['numerator']),int(x['denominator']))
rows={r['id']:r for r in j['slices']};count=0;positive=0;hits=[];minimum=None
allrecords=[(r,p) for r in j['slices'] for p in r['points']]+[(rows[p['slice']],p) for p in j['verifications']]
for row,rec in allrecords:
 c=src[row['case']];at=c['atoms'];D=fr(c['parameters']['D']);T=fr(c['derived']['T']);m=jf(rec['mass_exact'])
 nu=[fr(a['nu']) for a in at[:4]];nu[int(row['source'][1:])-1]*=jf(row['multiplier']);nu +=[1-sum(nu)-m,m]
 K=[fr(a['K0']) for a in at];J=[fr(a['J']) for a in at];A=[fr(a['A']) for a in at]
 U=[min(T*A[i],D*K[i]) if a['good'] else F(0) for i,a in enumerate(at)]
 Q0=sum(nu[i]*K[i] for i in range(6));QJ=sum(nu[i]*J[i] for i in range(6));q=max(Q0,QJ,sum(nu[i]*fr(a['Q']) for i,a in enumerate(at)))
 alpha=(D*q-sum(nu[i]*U[i] for i in range(6)))/QJ;lam=D*K[5]-U[5];assert lam>0
 diag=rec['joint_deduction_diagnostic_v2'];assert diag['activebad']==['G4'] and U[3]==0
 Rbad=D*(q-Q0)+D*K[3]*nu[3];assert jf(diag['R_bad'])==Rbad
 for g in diag['good']:
  i=next(i for i,a in enumerate(at) if a['name']==g['v']);a=max(F(0),1-D*K[i]/(T*A[i]));bv=J[i]/(T*A[i]);ae=max(F(0),a-bv*Rbad/QJ)
  rho=max(F(0),a-bv*alpha);coef=bv*lam*q/QJ;CH=F(16,3)
  Ghat=ae*ae/(4*coef);assert jf(g['a_eff'])==ae and jf(g['Gammahat'])==Ghat
  theta=Ghat if ae<=2*coef*CH else CH*(ae-coef*CH)
  assert m*rho/q<=theta<=Ghat and theta<=CH*ae
  count+=1
  if rho>0:
   positive+=1;threshold=F(1,(c['n']+1)**2);ratio=theta/threshold
   minimum=ratio if minimum is None else min(minimum,ratio)
   if theta<=threshold:hits.append([row['id'],rec['node_id'],g['v']])
out=dict(passed=True,records=len(allrecords),good_records=count,positive_rho_records=positive,theta_threshold_hits=hits,minimum_theta_over_threshold_decimal=str(float(minimum)),minimum_theta_over_threshold_exact={'numerator':str(minimum.numerator),'denominator':str(minimum.denominator)},scope='exact saved-rational source diagnostic including sharper Theta; not FULL',script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),input_sha256=hashlib.sha256((b/'numeric_joint.json').read_bytes()).hexdigest())
p=b/'verify_joint_diagnostic.json';assert not p.exists();p.write_text(json.dumps(out,indent=2));print({k:v for k,v in out.items() if not k.endswith('_exact')})
