# R141 独立求积交叉核验（运行前）

仅核I1与P1各自已选120位最高节点，不改变producer菜单。直接从R136来源系数及本轮精确mass重建六份质量、q、U、alpha、rho、e_t，以70位mpmath Gauss–Legendre对原log时间段逐pair积分；不调用producer缓存、TanhSinh节点或kernel_vector。原固定FA全段与Psi资格用本轮已重建记录确认，时间端点从原score段取。相对差容限1e−55。此为保存系数浮点求积交叉检查，非向外舍入或FULL证书。
