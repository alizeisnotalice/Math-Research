"""Fresh-directory replay; old inputs are extracted from existing round archives."""
from pathlib import Path
import argparse,zipfile,tempfile,shutil,subprocess,sys,hashlib
p=argparse.ArgumentParser();p.add_argument('mode',choices=['checks','probe']);
for n in [138,139,140]:p.add_argument('--r'+str(n),required=True,type=Path)
a=p.parse_args();base=Path(__file__).resolve().parent;tmp=Path(tempfile.mkdtemp(prefix='cube-r141-'));run=tmp/'centered_cube_round141_20261015';run.mkdir()
def extract(zpath,name,dest,sha):
 with zipfile.ZipFile(zpath) as z:
  hits=[n for n in z.namelist() if Path(n).name==name];assert len(hits)==1,(name,hits)
  data=z.read(hits[0]);assert hashlib.sha256(data).hexdigest()==sha
 dest.parent.mkdir(exist_ok=True);dest.write_bytes(data)
extract(a.r139,'active_traffic_v2.json',tmp/'centered_cube_round136_20261014/active_traffic_v2.json','1090fb2356abe035a997eb851a2f0252a3abe3edbeaf978e99900a38906392de')
extract(a.r138,'core_capacity_probe.json',tmp/'centered_cube_round138_20261015/core_capacity_probe.json','268bd6ca487de9111dec63085c81c9bfd2fc5eb8aa760483dd000581eae6900d')
extract(a.r139,'joint_objective_probe.json',tmp/'centered_cube_round139_20261015/joint_objective_probe.json','302321823f8b7ef6df3cff2ac6b9ad3ec3b3be0dc5ffe509602a4ca0643df27d')
extract(a.r140,'mass_direction.json',tmp/'centered_cube_round140_20261015/mass_direction.json','4ebd47e297561e5f39f7badb87842dcf17aebf255042fdd4da3b15152600e127')
if a.mode=='checks':
 names=['numeric_joint.json','reserve_check.py','reserve_protocol.md','independent_numeric_check.py','independent_numeric_protocol.md','verify_joint_diagnostic.py']
 commands=[['reserve_check.py'],['independent_numeric_check.py'],['verify_joint_diagnostic.py']]
else:
 names=['numeric_joint.py','numeric_plan.md'];commands=[['numeric_joint.py'],['numeric_joint.py','--postrun-diagnostics']]
for name in names:shutil.copyfile(base/name,run/name)
print('Fresh replay directory:',run,flush=True)
for cmd in commands:subprocess.run([sys.executable,*cmd],cwd=run,check=True)
