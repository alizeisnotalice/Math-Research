# R141 active-bad 剩余容量与联合平方阈值独立先审

本稿先核主代理准确候选及其加强版，不读取本轮作者 `joint_geometry.md`。仅写本文件，不Git/PDF、不做数值。结论针对原同一合法有限截断行的正交通；不宣称一般根阶覆盖。

## RPA1. 原门、共同量词与零行

固定同一ω,V,j,x,y、原共同核/ν/q/Q₀/Q_J/T/D/α，再固定实际t和内good v。外hard z仍是另一变量。S⊂Q_R(x)及其认证常数λ_S≥0须在该外z积分前共同选定，并在整个积分中不变；可依共同数据及t,v，不得依正在积分的z逐源重选。

用𝓑_(t,v)表示active bad集合，避免与原硬B标志混淆：

\[
\mathcal B=\{u\in D_g\cap Z_t:\delta_t(v,u)>0,
\ \Psi(v,u)\chi_{FA}(t,v,u)=1\}.
\]

已实读R128 RT2、RT5–6：D_g是原p w_g>KQ*侧，S_g是≤侧，E=S_g∩{硬B=0,A>0}，因此D_g∩E=∅，**U=0于D_g**，亦于𝓑。这里没把bad集合附加到负项；它只用于分配原非负余额。𝓑的score/FA/Ψ是原门，可依t,v及当前x；其积分dummy u不等于外hard z，不在积分后根据当前z重选𝓑或S。

令d(z)=DK₀(z)−U(z)≥0，原容量

\[
\alpha Q_J=D(q-Q_0)+\int d\,d\nu,
\quad Q_0=\int K_0d\nu\le q.
\]

在S认证d≥λ_S，故若λ_S>0可使用联合平方界。有效商行要求q,Q_J,T,A_v,J_v>0；原实际s>0给正核。q/Q_J/A_v零行沿原零交通约定，不计算a,b,Γ中的0/0。λ_S=0另作硬帽，不计算含1/λ_S的Γ。α是同一原值，不按𝓑或S另优化。

## RPA2. 原候选：不交外bad容量

记m=ν(S)，C_out=∫_(𝓑\S)K₀dν。两域S与𝓑\S不交，在后者d=DK₀，因此

\[
\alpha Q_J\ge\lambda_Sm+DC_{out}.
\]

C_out允许依共同x,j,y,t,v,S和整份ν，但不依正在积分的外z。它不是Π质量或来源后验概率，不能以当前pair一个bad u的核值代替此整份积分。

实际good行记a=(1−DK_v/(TA_v))₊、b=J_v/(TA_v)>0、ρ_v=(a−bα)₊。对λ_S>0令a_eff=[a−bDC_out/Q_J]₊，β_S=bλ_S/Q_J，则

\[
\rho_v\le[a-bDC_{out}/Q_J-\beta_Sm]_+
=[a_{eff}-\beta_Sm]_+.
\]

后一恒等式使用m≥0；原未截断a−bDC_out/Q_J若≤0，两边都为0，**不能先平方该负值**。对固定实际a_eff,β_S用m(a_eff−β_Sm)₊≤a_eff²/(4β_S)，得到准确候选

\[
\boxed{\frac{\nu(S)}{qR^n}\rho_v
\le\frac{Q_J}{q}\frac{a_{eff}^2TA_v}{4\lambda_SJ_vR^n}.}
\]

没有对不同S累计α容量，也没有把外hard z与bad u识别。history≤1可在原正积分中放松后使用此未加权ν(S)界。

## RPA3. 加强版R_bad：重叠与FIRST松弛不重领

主代理后发加强候选为

\[
R_{bad}=D(q-Q_0)+\int_{\mathcal B}
[DK_0-\lambda_S1_S]d\nu.
\]

它确为非负：FIRST松弛≥0，𝓑\S上DK₀>0，𝓑∩S上因U=0而DK₀=d≥λ_S。且

\[
\begin{aligned}
\alpha Q_J-\lambda_Sm-R_{bad}
&=\int_{\mathcal B^c}[d-\lambda_S1_S]d\nu\ge0.
\end{aligned}
\]

在S∩𝓑ᶜ用d≥λ_S，其他点用d≥0。因此

\[
\boxed{\alpha Q_J\ge\lambda_S\nu(S)+R_{bad},
\qquad R_{bad}\ge DC_{out}.}
\]

这里𝓑∩S只记DK₀−λ_S，未同时领取整个DK₀及λ_S；FIRST松弛也只使用原一份。此式是严格合法的共同容量拆分，不是将重叠bad/full-hard容量双算。

将R_bad替换RPA2的DC_out，定义

\[
a_{eff}=\left[a-\frac{bR_{bad}}{Q_J}\right]_+,
\quad
\Gamma_{eff}=\frac{Q_J}{q}
\frac{a_{eff}^2TA_v}{4\lambda_SJ_vR^n}
\quad(\lambda_S>0),
\]

同一证明给hard×ρ≤Γ_eff。加强版a_eff不大于原候选，Γ_eff≤原Γ，其中原Γ使用同一S/λ及a而不扣R_bad。R_bad可以依实际ν(S)，标量最大化只是对当前行实值m的代数上界，不改变ν后冻结R_bad再伪装成跨质量的优化；若ν改变，一切共同量必须重算。

λ_S=0时仍有αQ_J≥R_bad，ρ≤a_eff。原RT1的q≥3λ/4、h_R f≤4λ及ν≤f给ν(S)/(qRⁿ)≤16/3，因此

\[
\boxed{\frac{\nu(S)}{qR^n}\rho_v\le(16/3)a_{eff}}
\]

合法，且与Γ=∞的伪零储备比较不同。λ_S=0不自动取得root付款，仍须明确的小硬帽条件或其他真实费用。

## RPA4. 真实正子支回代JT14与增量范围

对λ_S>0选原未付正交通中的门Γ_eff(t,v,S)≤θ_n=(n+1)⁻²。S/λ/𝓑/R_bad全部在外z积分前确定，不依当前z。逐t,v积分z并乘原ρ最多θ_n；之后可放松其余原正门、以δ≤n及原两Π概率总质量将内pair帽为共同B=n/(n+1)²。R_bad虽依t,v且使用active bad ν积分，但在这一步已由阈值消尽，不留下待付source/j能量。

继承已审R140 JT14的正确次序：完整消源后，将每列实际t窗放至同一[a,b]，用唯一j(x)指示之和≤1，然后支付真实soft/L联合接收包络3(2n+3)D_n及原β。故

\[
2\Lambda P_{\Gamma_{eff}\le\theta_n}
\le6\Lambda\log2\frac{n(2n+3)}{(n+1)^2}D_nW_\beta
\le36\Lambda\log2\sqrt nW_\beta
<25\Lambda\sqrt nW_\beta.
\]

所有外1/q、hard R⁻ⁿ、Q_J/q、J_v、λ_S、内两e_t分母、dx、β/ν、time/scale/soft及history费用均按原接口保留，ν相关无影响。没有新增负账或εX消费。

在同一S规则下，原Γ>θ_n而Γ_eff≤θ_n是未被原小Γ门覆盖的潜在增量；仍须先删除R140 large-j core及所有旧已付正支。重新选择S时必须按实际交通门去重，不能仅按旧Γ数字判断。证明不保证该增量非空、非零质量或覆盖原大Γ补集。无正λ域、Γ_eff大域、未选source、壳/lowerclamp及R≤L未付core仍待真实付款。

**独立先审：不交C_out候选及R_bad加强版均PASS，平方正截断与25Λ接合通过。** 已保存先行证据，等待作者冻结后再追加后审；不把共同余额身份本身登记为一般闭合。

## RPA5. 作者最终冻结后审与原记录绑定

RPA1–4先行记录保留不改。之后实读作者 `joint_geometry.md` 初冻结SHA256 `4c70dfdd8b1469d51ba570076bd0f52784dc4f0c4faf64f880527a62ef1cd94a`；最终作者只补实际行的R等数值固定、并非改变输入质量而冻结R的量词句。已核最终SHA256 **`76289ae4a63547bdc9acfdb75c05d47f2d40e0698fb5432b79ca80f865f76130`**，本后审绑定该版。

JG1–7与独立RPA1–3一致。可测active bad域使用原strict score、Ψ及FA，未将依外z的history塞入𝓑；S/λ在外z积分前选定，认证允许ν-a.e.，与所有后续ν积分相容。U=0于𝓑来自D_g∩S_g=∅，不是额外反例/来源假设。R定义只收费同一α容量中的FIRST松弛、S外bad核质量、S内bad超过底价λ的部分。JG6的精确余差是RPA3的非负Bᶜ积分，重叠没有双算。

JG4先扣R后正截断，再作联合平方；负的a−bR/Q_J不可直接平方。R在当前ν上计算，即使含−λν(𝓑∩S)，仍能固定其当前实值后用包含实际m的数值区间作上界；不意味着沿m改变输入时R不变。作者最终补句符合这一正确量词。

## RPA6. JG8精确有限硬帽、连续性及零储备

令C_H=16/3、h₁=m/(qRⁿ)∈[0,C_H]，c_S=b_vλ_SqRⁿ/Q_J。JG4逐点给h₁ρ≤h₁(ahat−c_Sh₁)₊，故最大值Θ是原外hard×ρ的合法上帽。

当c_S>0、ahat>0时，未截断抛物线在ahat/(2c_S)达到峰，超过ahat/c_S之后为0。若顶点在硬区间内，即ahat≤2c_SC_H，极值ahat²/(4c_S)；若顶点在区间外，则区间内递增，极值C_H(ahat−c_SC_H)>0。c_S=0时极值C_H ahat。ahat=0时任何c_S均给0。这与JG8全部三段吻合。

在ahat=2c_SC_H，两段皆等于c_SC_H²，连接连续；c_S→0、固定ahat>0时末段趋于C_H ahat，固定ahat=0时始终为0，故不存在λ=0除零端点。更一般由固定紧区间上连续函数的最大值可知Θ对(ahat,c_S)连续。λ>0时Θ≤ahat²/(4c_S)=Γhat，且更尖的末段不能被当成与未约束Γ相等。

JG9把history/截断/补集等z依赖门作非负≤1放松后，用同一ν(S)帽，准确保留外1/q、R⁻ⁿ及原hard质量上限；没有把hard来源改成概率。λ=0使用Θ=C_H ahat，付款门等价ahat≤3/[16(n+1)²]；A_v=0、v不属原允许E等零余量行直接Θ=0，不能计算b_v或Γ的商。JG8/9通过。

## RPA7. JG10–11各几何支与bad硬支持计数

R>H时，closed inside坐标为|x_i−z_i|≤H/2，outside严格>H/2；不交S_m按outside坐标数m分割Q_R。inside因子至少m_s，outside正soft因子至少sφ(R/(2H))，故

\[
K_0\ge H^{-n}m_s^{n-m}[s\phi(R/(2H))]^m
=T\kappa\vartheta^m.
\]

实际s>0、R>H及φ严格径向递减给0<ϑ<1；hard边界原子归inside，不遗漏质量。R≤H只取S₀=Q_R及K₀≥Tκ，不需要给未定义的ϑ赋值；对应m=0系数应直接读为DTκ。

R≤L时原hard B=1于全部Q_R，U=0于所选hard来源，所以λ_m=DTκϑ^m>0，包含H₀<a。此支不依赖外z存活；κ⁻¹及ϑ⁻ᵐ仍完整留在逆λ价格。R>L时U≤TA≤T(1−w_h)，与残余非负合并给λ_m=T[Dκϑ^m−1+ω_m]₊。该式在H₀≥a与H₀<a都合法，后者可为0；ω_m是实际inf，未给其维数无关下界。core的κ≥1只在H₀≥a使用，不能从H<L⁺推断全部下钳位已排除。壳并集取统一最小认证下界，未对各层分别领α。

对S=⋃_{m∈I}S_m，JG7的𝓑质量按Q_R外与每个S_m分割。Q_R外保持D∫K₀ν；每层被积函数为DK₀−λ_S1_{m∈I}，实际非负，又≥DTκϑ^m−λ_S1_{m∈I}，所以其下界是该数的正部。由此JG11成立，连同FIRST松弛恰是同一R的一次分割。

hard坐标计数m不是时间score k_t；作者在ν(𝓑∩S_m)中同时保留strict低score/Ψ/FA资格，没有用几何计数替换active bad门。ν可任意相关，几何距离或坐标占有率没有自动质量下界；远bad核项仍是真实K₀。JG10–11通过，但仅给可核下界，未证明任何统一占有量或覆盖比例。

## RPA8. JG12–16相对改善、增量门与原25Λ价格

λ>0、a_v>0时η=b_vR/(a_vQ_J)≥0，ahat=a_v(1−η)₊，故Γhat=Γ(1−η)₊²。Γ>0、R>0使其严格小于Γ；η≥1使ahat=0进而实际ρ=0。a_v=0为零行，不定义η。原Γ>θ_n=(n+1)⁻²时，JG13的η≥1−1/((n+1)√Γ)确是Γhat≤θ_n的充分条件（在此正Γ范围也等价）。条件可实际计算，但未由FIRST/high自动推出。

JG14使用更尖Θ≤θ_n，既包含λ>0平方门，也允许λ=0的小ahat支。对固定t,v先积分外z，JG9给Θ；再以𝓑上的δ≤n与两Π质量≤1，得到共同source帽n/(n+1)²。依u,z的其他原history/gates可以仅在正上界中≤1放松；定义𝓑及R没有把这些z依赖混入共同扣减。没有免费消去两e_t再改用未归一ν；source费用正是用真实两Π概率质量支付。

然后且仅然后套已审JT14：全时间窗上放同一[a,b]、唯一j指示之和≤1、接收菜单3(2n+3)D_n、D_n≤3√n，恢复原dx、β与2Λ，得

\[
2\Lambda P_{bad-margin}\le
\frac{6\Lambda n\log2(2n+3)}{(n+1)^2}D_nW_\beta
\le36\Lambda\log2\sqrt nW_\beta
<25\Lambda\sqrt nW_\beta.
\]

所以JG15及JG16实际回代通过。其登记对象必须是原R140全部已付正支补集，再选单一S/λ门；旧小Γ、large-j core及其他历史付款不能重复。若选S规则改变，按原实际交通门去重，不能只凭旧Γ值删除；多个active bad划分或多个候选S不能无条件累加各领一份价格。未消费负项原位保留，N_Z/N_del没有新附positive门，亦无新增εX槽。

## RPA9. 条件改善与样本覆盖边界

本轮是严格的共同容量**条件估计加强**以及由其门指定的一般原正子支定理，不只是完整α的重命名：扣减只用active bad与FIRST松弛的可确认份额，并扣掉hard底价重叠。不过，证明没有给R或η的全域下界，不能据此声称扩出的正子支有非零覆盖或多数覆盖。

主代理告知其另审数值：230条记录（含9复核）、606个positive good记录旧Γ均大于门，Γhat跨入门0例。本独审未重做这些数值，应将此作为主数值账的报告，不冒充本稿独立计算。尤其没有认证现有模型已由新平方门付清。Θ比Γhat更尖，是否命中Θ门必须另有实际样本检查；不能仅由Γhat的0命中推定任何未核Θ结论，也不能据有限菜单未命中否定一般条件定理。

尚未付的精确域是所选JG14子支的补集，含无认证/未选S、Θ>θ_n的低j大余量、未付外壳、下钳位及R≤L core等。FIRST仅给K₀总质量上界，没有保证原strict score/FA/Ψ所选bad域有足够K₀质量；Π_t中bad概率大也不能反向推出R大。一般闭合仍缺真实接收/来源联合下界或合法剩余负项匹配，不能以新的未付能量名代替。

**最终后审：冻结JG1–16（重点JG8、JG10–11、JG13及JG15）PASS。** λ=0/零行、连续极值、重叠容量、几何费用、唯一j与25Λ常数均无公式错误；不认证任何现有正样本已付款，不宣称一般大Γ补集闭合。已保留独立先审，仅追加本文件；交付冻结hash后停止。
