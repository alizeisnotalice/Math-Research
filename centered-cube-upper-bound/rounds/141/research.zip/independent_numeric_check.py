from pathlib import Path
from fractions import Fraction as F
import sys,json,hashlib
sys.set_int_max_str_digits(0)
sys.path.insert(0,'/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor')
import mpmath as mp
mp.mp.dps=70
base=Path(__file__).resolve().parent
srcpath=base.parent/'centered_cube_round136_20261014/active_traffic_v2.json'
src={c['id']:c for c in json.loads(srcpath.read_text())['cases']}
j=json.loads((base/'numeric_joint.json').read_text())
def f(v):return F(str(v))
def jf(v):return F(int(v['numerator']),int(v['denominator']))
def mf(v):return mp.mpf(v.numerator)/v.denominator
out=[]
for cid in ['I1','P1']:
 nid=j['summary'][cid]['best_verified_node_id'];rec=next(r for r in j['verifications'] if r['node_id']==nid)
 row=next(r for r in j['slices'] if r['id']==rec['slice']);c=src[cid];atoms=c['atoms']
 nu=[f(a['nu']) for a in atoms[:4]];nu[int(row['source'][1:])-1]*=jf(row['multiplier']);m=jf(rec['mass_exact']);nu+=[1-sum(nu)-m,m]
 T=f(c['derived']['T']);D=f(c['parameters']['D']);p=f(c['derived']['p'])
 Q={k:sum(nu[i]*f(a[v]) for i,a in enumerate(atoms)) for k,v in [('Q0','K0'),('QJ','J'),('Qstar','Q')]};q=max(Q.values())
 U=[min(T*f(a['A']),D*f(a['K0'])) if a['good'] else F(0) for a in atoms]
 alpha=(D*q-sum(nu[i]*U[i] for i in range(6)))/Q['QJ']
 rho=[max(F(0),1-(U[i]+alpha*f(a['J']))/(T*f(a['A']))) if a['good'] and f(a['A'])>0 else F(0) for i,a in enumerate(atoms)]
 total=mp.mpf(0);pairs=0
 for audit in row['FA_audit']:
  pid=audit['pair'];v,u=divmod(pid,6);s=c['score_segments'][audit['segment']];delta=s['k'][v]-s['k'][u]
  assert delta>0 and c['pairs'][pid]['Psi'] and rho[v]>=0
  cs=[mf(f(x)) for x in s['c']];ks=s['k'];mass=[mf(x) for x in nu]
  def integrand(logt):
   ws=[cs[i]*mp.exp(-ks[i]*logt) for i in range(6)];e=mp.fsum(mass[i]*ws[i] for i in range(6))
   return delta*ws[v]*ws[u]/(e*e)
  val=mp.quad(integrand,[mp.log(mf(f(s['lo']))),mp.log(mf(f(s['hi'])))],method='gauss-legendre')
  total+=mf(rho[v]*nu[v]*nu[u])*val;pairs+=1
 Fval=mf(p*m/q)*total;ref=mp.mpf(rec['objective_F']);err=abs(Fval-ref)/abs(ref)
 assert err<mp.mpf('1e-55')
 out.append(dict(case=cid,node=nid,pair_pieces=pairs,reference=rec['objective_F'],independent=mp.nstr(Fval,70),relative_error=mp.nstr(err,20),passed=True))
result=dict(cases=out,passed=True,scope='70-digit Gauss-Legendre saved-coefficient crosscheck, no certified intervals',script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),protocol_sha256=hashlib.sha256((base/'independent_numeric_protocol.md').read_bytes()).hexdigest())
p=base/'independent_numeric_check.json';assert not p.exists();p.write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
