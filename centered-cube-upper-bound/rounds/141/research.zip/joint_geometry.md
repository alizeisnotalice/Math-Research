# R141：同一容量中 active bad 对 hard–rho 余量的扣减

状态：先冻结命题及量词；只处理一个候选，不将来源接口或改名余项当作一般闭合。保留原RT2、R140已经支付子支的补集与所有原负账。以下将先证明一个共享容量的实际严格加强，再列其可付范围。

## JG1. 逐行命题与全部选择量词

固定实际ω,V,j,x,y,t及good来源v；共同s,L,R,g,H,T,D,q,ν,E,U,α,Q_J取原值。t∈J_far，v∈E、A(v)>0、q,Q_J,e_t>0；其他行按原零交通约定。原K₀,J,w_t严格正，ν可任意相关。令

\[
 a_v=[1-DK_0(x-v)/(TA(v))]_+,\qquad b_v=J(x-v)/(TA(v)),
 \qquad \rho_v=(a_v-b_v\alpha)_+.
\]

在外hard来源z积分之前，共同可测选定S⊂Q_R(x)和λ_S≥0，满足

\[
 DK_0(x-z)-U(z)\ge\lambda_S\quad\nu\text{-a.e. on }S.
\tag{JG1}
\]

S、λ_S可依上述行、t、v及共同容量数据，但不能依正在积分的z重选。对同一v,t，定义真实active bad域

\[
 \mathcal B_{t,v}=\{u\in D_g\cap Z_t:
 k_t(u)<k_t(v),\ \Psi(v,u)=1,\ \chi_{FA}(t;v,u)=1\}.
\tag{JG2}
\]

这是原正交通的严格score资格及原pair门，不将Ψ改为单来源门。对固定t,v它是一个可测来源集合；原外history、hard资格与其他正子支门继续保留，不假设其对u、z因子化。仅使用RT定义中不依外hard z的上述pair门来定义B；不把任何额外依z的history资格塞进这个共同集合。

记Q₀=∫K₀dν≤q，并定义可直接从同一实际ν计算的扣减量

\[
 R_{S,t,v}=D(q-Q_0)+
 \int_{\mathcal B_{t,v}}[DK_0(x-u)-\lambda_S1_S(u)]d\nu(u).
\tag{JG3}
\]

命题：R≥0，且令

\[
 \widehat a_v=[a_v-b_v R_{S,t,v}/Q_J]_+,
\]

则对同一个实际hard质量m_S=ν(S)，

\[
 \rho_v\le[\widehat a_v-b_v\lambda_Sm_S/Q_J]_+.
\tag{JG4}
\]

若λ_S>0，得到明确联合帽

\[
 \frac{m_S}{qR^n}\rho_v
 \le\widehat\Gamma_S(t,v):=
 \frac{Q_J}{q}\frac{\widehat a_v^2TA(v)}{4\lambda_SJ(x-v)R^n}.
\tag{JG5}
\]

该命题同时包括bad来源位于S内及S外的情形；不能只在两域不交时证明后将其推广到有重叠情形。R不是一份新reserve，只是原αQ_J中已能确认被FIRST松弛和active bad占用的部分。

## JG2. 共享容量证明：重叠来源的费用也扣除

令r_0(z)=DK₀(x−z)−U(z)≥0。由JG1，r₀−λ_S1_S≥0于全来源空间；由D_g∩S_g=∅及E⊂S_g，U=0于B_{t,v}。因此

\[
\begin{aligned}
\alpha Q_J
&=D(q-Q_0)+\int r_0d\nu\\
&=\lambda_S\nu(S)+D(q-Q_0)
 +\int(r_0-\lambda_S1_S)d\nu\\
&\ge\lambda_S\nu(S)+R_{S,t,v}.
\end{aligned}\tag{JG6}
\]

积分定义R中的被积函数在B上非负，故R≥0。尤其R≤αQ_J，未新造或复制储备。代入原ρ_v=(a_v−b_vα)₊即得JG4；利用[(a−c)₊−d]₊=(a−c−d)₊，c,d≥0，截零无歧义。

JG3可展开为

\[
R=D(q-Q_0)+D\int_{\mathcal B\setminus S}K_0d\nu
 +\int_{\mathcal B\cap S}(DK_0-\lambda_S)d\nu.
\tag{JG7}
\]

第三项正是重叠来源已付过hard底价λ_S后，仍可确认为bad占用的超额；不能对B∩S再收费一整份DK₀。只用第二项的不交版本亦成立，但丢失这份可确认费用。精确外部储备D(q−Q₀)+∫_{Sᶜ}r₀dν也可用于共享不等式；本文采用JG7是为了保留严格低score及真实FA/Ψ，而不是把完整α改名。

对m=m_S≥0，将JG4乘m/(qRⁿ)，再用sup_{m≥0}m(a−cm)₊=a²/(4c)，得到JG5。这里先把实际行的R、λ_S、q、Q_J等数值固定，再用一个包含实际m的标量区间取上界；并未假定改变输入质量时R保持不变。R中含−λ_Sν(B∩S)也不影响这种逐行上界。优化的是同一个实际hard质量与同一个原α所控制的余量，不将hard质量与ρ各自取独立上确界。

## JG3. 保留原hard帽，覆盖λ_S=0的精确极值

原硬帽给m_S/(qRⁿ)≤C_H=16/3。令

\[
 c_S=\frac{b_v\lambda_S qR^n}{Q_J}\ge0,
\qquad
\Theta_S(t,v)=\max_{0\le H_1\le C_H}
 H_1(\widehat a_v-c_SH_1)_+.
\]

可直接求极值：

\[
\boxed{
\Theta_S=\begin{cases}
C_H\widehat a_v,&c_S=0,\\
\widehat a_v^2/(4c_S),&c_S>0,\ \widehat a_v\le2c_SC_H,\\
C_H(\widehat a_v-c_SC_H),&c_S>0,\ \widehat a_v>2c_SC_H.
\end{cases}}
\tag{JG8}
\]

由JG4，实际正交通中的外hard积分满足

\[
\frac1q\int_S h_R(x-z)a_\omega(x,y,z)d\nu(z)\,\rho_v
\le\Theta_S(t,v).
\tag{JG9}
\]

原截断/history或已付款补集门即使还依赖z，只缩小非负积分。JG9不是把真实hard积分换成概率：R^{-n}、q及原hard帽都已计入c_S与C_H。λ_S=0时未写1/λ_S；可付款性取决于真实扣减后\widehat a_v是否小。A(v)=0、v不属E等零余量点贡献为零，直接定义其Θ=0。

## JG4. 全部真实几何分支的费用

以下仅使用R139已经核实的核下界，列出如何实际认证λ_S及R，而不假设它们有统一常数帽。记m_s=1−s+sφ(1/2)、κ=(H₀/H)^n，TH₀^n=m_s^n。

若R>H，按外硬支持计数定义S_m={z∈Q_R(x): #{i:|x_i−z_i|>H/2}=m}，并置ϑ=sφ(R/(2H))/m_s∈(0,1)。有

\[
K_0(x-z)\ge T\kappa\vartheta^m\quad(z\in S_m).
\tag{JG10}
\]

若R≤H，仅保留m=0，S₀=Q_R，K₀≥Tκ。可以选定一个壳层或壳层并集S；统一下界λ_S取所选层的最小认证值，所有选择均在外z积分前完成。

- **R≤L，包括H₀<a。** 原B=1于全部Q_R，所以U=0于hard来源。每层可取λ_m=DTκϑ^m>0。无需假设hard来源属于Z_t，R≤L没有遗漏。小κ或大m对应的κ^{-1}ϑ^{-m}真实费用仍在JG5中。
- **R>L、H₀≥a。** 可取λ_m=T[Dκϑ^m−1+ω_m]₊，其中ω_m=inf_{S_m}w_h∈[0,1]；来自A≤1−w_h。core也按此式计算，没有把H₀近似为大尺度乘m_s。
- **R>L、H₀<a以及任一外壳。** 同一公式仍是合法非负下界，但可能λ_m=0。这时用JG8首行，不能删除下钳位或声称逆λ有统一价。H<L⁺与H=a是不同条件。

R的可核几何下界也保留active bad门。对S=∪_{m∈I}S_m，JG7至少给

\[
\begin{aligned}
R\ge{}&D(q-Q_0)+D\int_{\mathcal B\setminus Q_R}K_0d\nu\\
&+\sum_{m=0}^n
 [DT\kappa\vartheta^m-\lambda_S1_{\{m\in I\}}]_+
 \nu(\mathcal B\cap S_m).
\end{aligned}\tag{JG11}
\]

R≤H时求和只取m=0。使用正部是因实际DK₀−λ_S1_S在B上已知非负；因此低核下界弱于λ_S时可取0。这里按同一ν的真实硬支持计数及严格低score资格求质量，不假设坐标独立或来源聚团。求和是唯一容量的一次分割，不是每层领取一个αQ_J。远处bad项保留真实K₀；不假设source距离矩有帽。

## JG5. 相对原HM的明确改善及真实外积分付款

λ_S>0、a_v>0时，原HM值为Γ_S=(Q_J/q)a_v²TA/(4λ_SJRⁿ)。令

\[
\eta_{S,t,v}=\frac{b_vR_{S,t,v}}{a_vQ_J}\ge0.
\]

则有明确、非渐近的价格缩减

\[
\widehat\Gamma_S=\Gamma_S(1-\eta_{S,t,v})_+^2,
\qquad \Theta_S\le\widehat\Gamma_S.
\tag{JG12}
\]

Γ_S>0且R>0时，上界严格降低；η≥1给该实际good v的ρ=0。这里η不是新分配的自由参数，而由原共同α余额的一部分、真实K₀和原active bad资格确定。原Γ大的点也可覆盖：当Γ_S>(n+1)^{-2}时，充分条件为

\[
 \eta_{S,t,v}\ge1-\frac1{(n+1)\sqrt{\Gamma_S}}.
\tag{JG13}
\]

这与再要求旧Γ变小不同；在低j、原Γ大的行也能实际核验。本文没有证明JG13在所有原行成立，也没有认证现有有限模型满足它。

**付款命题。** 在原R140全部已付正支的补集内，合法共同选S、λ_S，并保留z∈S及

\[
 \mathcal G_{bad} =\{\Theta_S(t,v)\le(n+1)^{-2}\}.
\tag{JG14}
\]

其余H<L⁺、C_J(v)≤3、ρ、严格低score、Ψ、FA、history、两份原e_t分母均保持。所得正交通P_{bad-margin}满足

\[
\boxed{2\Lambda P_{bad-margin}\le25\Lambda\sqrt n\,W_\beta.}
\tag{JG15}
\]

证明：固定t,v先积分外hard来源，JG9给Θ。再对同一Π_t的bad来源u积分；B_{t,v}正是δ_tΨFA可能非零的域，故保留原门的双来源积分至多

\[
 \int1_{\mathcal G_{bad}}(v)\Theta_S(t,v)
 \left[\int_{\mathcal B_{t,v}}\delta_t(v,u)d\Pi_t(u)\right]d\Pi_t(v)
 \le\frac{n}{(n+1)^2}.
\tag{JG16}
\]

没有把Π_t换成未归一ν，没有消去两份e_t后另假设源总质量有界；仅在最后使用两份真实概率质量≤1。S和R虽依v,t，但已在积分z之前共同固定，JG9在该v,t对所有u的积分合法。若额外history仍依u、z，先仅为正上界将其≤1；不能用这种放松来改造原负项。

现在且仅现在，使用R140 JT14：所有时间窗⊂[a,b]、唯一j指示求和≤1，固定尺度带接收包络费3(2n+3)D_n，D_n≤3√n，时间长度≤log2。因此

\[
2\Lambda P_{bad-margin}
\le\frac{6\Lambda n\log2(2n+3)}{(n+1)^2}D_n W_\beta
\le36\Lambda\log2\sqrt nW_\beta
<25\Lambda\sqrt nW_\beta.
\]

外测度始终是dx dβ_V(y)，再取原EΣ_V；未以β=ν替换来源，未使用dβ/e_t的免费质量帽。连续soft与L费用并未省略，父代理若证明更小接收包络可在此处另行替换；本文不重复研究该包络。

λ_S=0时JG14要求\widehat a_v≤3/[16(n+1)²]，依然是合法实际子支而非除零推论。这包括前述lowerclamp/外壳，但不保证该阈值覆盖它们多数。λ_S>0时JG13是易检查的充分条件；用JG8可能更尖。对原已支付支必须先剔除重合，不能在所有候选S或多个active bad划分上重复领取JG15。

## JG6. 成果边界与唯一待证步骤

本次新的严格加强是JG6–JG12：hard底价与严格低score、原FA/Ψ允许的bad占用放在同一份α容量中，重叠部分只收费超额DK₀−λ_S；它把旧HM价按一个真实可计算的平方因子降低。JG15把因此扩出的实际子支回代原dx、β、time/j/history，得到25Λ√nWβ。没有为此消费N_Zc或N_del，也没有返还旧负账。

一般中间层仍未闭合，准确还缺一步：对JG14的补集，证明实际接收积分使active bad占用R与hard质量及good余量形成足够大的扣减，或提供合法的剩余负项匹配。FIRST只给∫K₀ν上界；它不保证同一严格低score/FA/Ψ域有足够K₀质量。bad来源若有很低的K₀/w_t，其Π_t质量仍可大而JG3占用小；现有high给整体Q_J/e_t的比较，并不能反向支付这一受原pair门限制的质量。这是尚未得到的具体联合下界，不以新的未付能量名称替代它。

该缺口统一覆盖低j大Γ、外壳、下钳位以及R≤L的未达阈值部分。上述分支都已在JG10–JG11中列出真实费用，未借core结论排除它们。本文不造新的反例菜单，不声称JG15支付全部剩余，不假定来源独立/聚团/距离矩、e_t下界或负项可复用。完成一个可审检查点后停止；仅写本文件，无Git、无PDF。
