# 中心立方体第96轮：阈值占用容量、原门细化与势函数边界费用

2026-10-12。一般非负 L1 输入、真实勒贝格接收测度及全部尺度上的 C_n≤sqrt(n)n^{o(1)} 仍未证明。保留一般 O(n log n) 基准；本轮没有把条件性转移、特定帽规则失败或有限数值证书升级为整体闭合。

本轮主瓶颈是共同删集的子幂能量费用，以及原同输入、同接收点、原首次硬接触下的共同来源容量。第95轮低阈值未截断占用帽的进一步充分条件被真实输入否定；保留已证明的一般共同帽基准。阈值占用 h_a 的持续比较则严格成立，但其低水平集容量与实际弱型常数双向可比，不是已经解决的几何费用。

新增来源深度截取给出一个源侧可检查的条件性改进，但浅层剩余质量一般仍可能很大。新增边界条带 Fourier 转移与二次势证书能够支付同一帽的全尺度能量，不过任意输入的统一二次势常数没有建立，深部浓缩会使这一充分证书严重过计。原门路线中，额外支付全窗口粗软分支后，实际捕获后验满足贴面计数约束；直接锥分配仍付线性维数费用。全部未付分支及来源、尺度、层数费用保留。

三名 Astra high 路线、Astra high 与 Sol high 独审、两名 Sol high 数值及一名 Sol high 来源核验参与。发生流中断的路线按相同职责从已保存文本恢复，不重复计作新路线或新实验。作者先提交精确命题，审计者先检查量词和潜在反例，再读完整MD/对应TeX及必要程序。主代理独立审阅和重放，执行归属按验证节分别记录。原始文献阅读属于来源作者；主代理和两审没有据转述宣称重新通读该原文。

私人下界配方、相关程序和未公开定量下界只留本地。公开归档仅含明确PUBLIC片段、中性公开复现程序、必要结果及清单；五个归档成员，不编译PDF。


## 原目标、分支与维度账

f≥0属于L1，mu=f dy，W=||f||1，Q(x,L)=x+[-L/2,L/2]^n。原事件在L∈[1,2]保留单位锚点、原全窗口P1上门、严格后来硬见证、原最早硬接触L*及中间下限。原粗门P_(theta,L*)<alpha lambda只在选定尺度成立；不能继承为整个窗口的条件。theta=log^-2(n+2)，alpha=[10log(n+2)]^-1。所有输入限制和重选必须重新核验原门。

令H_n=1+nlog2，Bbase=4+2log2 sqrt(7n/3)，Bext=2H_n/sqrt(n+2)，Tsoft=1+log2 min{2n,sqrt[n(theta^-1+4theta/3)]}。保留原固定p>0、a=n^-p、rho=n^-1/2以及Pdom=[5+3log(1/a)]/rho。h*=(16n^(3/2))^-1、E*=exp(nh*)、B*=1+E*[1+(2n²+n)h*]，物理并集只付一次Pphys=2[E*+B*+2(1+E*)sqrt n]。Aold=Bbase+Bext+Tsoft/alpha+Pdom+Pphys。

只有覆盖全部余集的Dnew可代入 C_n≤C_loc log(n+2)[Aold+Dnew]。原中间强度 kappa_layer=1+log[lambda/(2P_(1,L*)f)] 按二进层计J_n=O(log n)，若逐层使用须另付J_n与重叠。能量阈值kappa与此层参数不同。第88轮逐主割方差假设R_n子幂、第94轮薄环累计预算仍未证明，不因本轮改写而获付。

|本轮接口|严格已得|未付条件或否定范围|
|---|---|---|
|未截断占用h低帽|真实输入否定该指定子幂体积前提|不否定任意共同帽或弱型目标；配方与定量留本地|
|h_a, a=1/6|actualexcess≤(4n/3)h_a；K_n(tau)≤6C_n，C_n≤(1+4tau/3)(4e+K_n(tau))|小容量前提与弱端点可比，不能循环支付|
|真实深度分布|B_def=sup_r[F(r)-kappa(2r)^n/6]_+；帽系数≤4e+1，能量≤c_nJ0J1 kappa B_def²/W|B_def/W一般并不小，全球深度分布会丢失空间位置|
|原门细化|另付Tsoft/alpha的全窗口粗高分支、Cnear≤1+sqrt n的近锚分支；后验多贴面约束与共同捕获分配|直接锥系数2H_n d_k仍为线性阶；不能把参考锥独立性用于真实后验|
|边界势转移|外帽近能量≤5∫|grad u|²[d_inf^-2−4/R²]_+；实际u≤Kkappa d_inf²时A≤1、B_energy≤10K+20K²|一般势的存在/有限能量/统一K均未付；深部势费用可过计|
|有界源二次势|K=(2^(n+2)+D)/2为有效显式值|要求连续代表在每个帽外点为零；保留指数维数及D，非一般目标|
|原私人粗门|同输入真实非线性检查约束特定全窗口概率方法|固定包含节点不能替代原最早接触，原粗门和完整Fnew仍UNKNOWN|

这里J0=log(16n²)，J1=log(32n²)，c_n=n/(1−2^-n)，深度B_def为来源质量。其能量系数是c_nJ0J1(B_def/W)²。势函数B_energy为无量纲能量系数，不能与来源质量或接收集合B混用。

共同帽重建：若对同一任意输入及每个kappa均有|Omega|≤A W/kappa与E≤B_energy kappa W，则对q=lambda/kappa≥4有弱费用≤qA+16n B_energy/(q log2)。一个固定模型或单阈值证书不能替代这个全称假设。R95普遍A≤4e+1、B_energy=O(nlog²n)只恢复O(nlog n)；本轮条件改进没有统一覆盖其剩余输入。

原门细化保守总账为Aold+Tsoft/alpha+Cnear+2H_n d_k。新增全窗口费用明确另付，原P1中间下限可能来自捕获立方体外来源，不能无证转移给捕获后验。若将该细化置于递推，必须在每个实际输入和阈值重付并证明累计可和；本轮没有此累计定理。

下一步须支付原门约束下角向扩大后仍计入的来源交通，或建立保留空间位置与真实超额阈值的共同分配；势路线须支付被截去的带符号余项。已否定的帽规则、已知beta核特例和被直接分解支配的旧递推不再作为新闭合候选。


## 1. Result and strategy scope

For arbitrary nonnegative $L^1$ sources, thresholding the R95 occupation gives a valid comparison with the actual cube excess. The precise dimension factor is retained. A uniform small-volume bound for a low level of this thresholded occupation, however, is quantitatively equivalent to a weak maximal bound; it is not an independent route to such a bound. In particular, a subpower capacity estimate of the proposed kind would imply a subpower cube weak constant, a stronger conclusion than the requested root-order scale. The following are proved comparison and equivalence statements, not a new volume theorem or a resolution of the original goal.

Let $n\ge2$, $f\ge0$ belong to $L^1(\mathbb R^n)$, $W=\int f$, and $\kappa>0$. Write
\[
 A_Lf(x)=L^{-n}\int_{x+[-L/2,L/2]^n}f(y)\,dy,
 \qquad Mf(x)=\sup_{L>0}A_Lf(x).
\]
All receiver sets use actual Lebesgue measure and every positive scale is retained. For fixed $x$, $A_Lf(x)$ is continuous for $L>0$: absolute continuity of the integral controls the shrinking symmetric difference of cubes, and the normalizing power is continuous. Thus the supremum can be taken over rational positive scales and is measurable. We use strict maximal superlevels throughout.

## 2. The retained actual source construction

Use exactly the R95 cyclic binary rectangle grid: at generation $k=qn+r$, $0\le r<n$, side lengths are $2^{-q-1}$ in the first $r$ coordinates and $2^{-q}$ in the others. Take its maximal rectangles with average greater than $\kappa/4$. Their countable disjoint family $\mathcal B$ obeys
\[
 \kappa/4<W_Q/|Q|\le\kappa/2,\qquad
 W_b=\sum_QW_Q\le W,\qquad
 \sum_Q|Q|\le4W_b/\kappa,
 \quad W_Q=\int_Qf.
 \tag{1}
\]
Ancestors have volumes tending to infinity, so maximal bad ancestors exist; their nonbad parents have twice their volume, giving the upper density bound. Bounded-eccentricity differentiation gives $f_g=f1_{(\cup Q)^c}\le\kappa/4$ almost everywhere. Let $\ell_Q$ be the maximum side, so all sides lie in $[\ell_Q/2,\ell_Q]$, and put $f_b=\sum_Q f1_Q$.

Replace each $f1_Q$ by its average on $Q$, using the product coupling inside $Q$. Together with the unchanged good source this gives one reference density at most $\kappa/2$. At scale $L$, the good part and all labels with $\ell_Q\le L/(8n)$ have displacement at most $L/(8n)$ to a common submeasure of that reference. Their combined cube average is at most $(\kappa/2)(1+1/(4n))^n<2\kappa/3$. Therefore the actual fields
\[
 N(x,L)=\sum_{\ell_Q>L/(8n)}A_L(f1_Q)(x),\qquad
 \widehat N(x,L)=\sum_{\ell_Q>L/(16n)}A_L(f1_Q)(x)
 \tag{2}
\]
satisfy
\[
 (A_Lf(x)-\kappa)_+\le(N(x,L)-\kappa/3)_+.
 \tag{3}
\]
These are countable sums of jointly measurable nonnegative functions, each at most $A_Lf\le WL^{-n}$. Neither the source partition nor its transport is selected afresh for different receivers or scales.

Let $\Omega_0=\bigcup_Q(1+1/n)Q$, using closed concentric dilations. It is one cap, with $|\Omega_0|\le4eW_b/\kappa$. An exterior receiver can capture the source in $Q$ only for $L\ge\ell_Q/(2n)$: in at least one coordinate its distance from $Q$ exceeds $\ell_Q/(4n)$. A label of $N$ ends at $8n\ell_Q$, while a label of $\widehat N$ ends at $16n\ell_Q$. Nonnegative Tonelli and the identity $\int A_L(f1_Q)\,dx=W_Q$ give
\[
 \int_{\Omega_0^c}\int_0^\infty N\,\frac{dL}{L}\,dx\le J_0W_b,
 \qquad
 \int_{\Omega_0^c}\int_0^\infty\widehat N\,\frac{dL}{L}\,dx\le J_1W_b,
 \quad J_0=\log(16n^2),\quad J_1=\log(32n^2).
 \tag{4}
\]
Each source piece is paid once over one finite ratio of scales. These are the fully proved R95 construction facts; their assumptions are not altered here.

## 3. Exact thresholded persistence

Fix $a=1/6$ and define the extended nonnegative spatial function
\[
 h_a(x)=\int_0^\infty(\widehat N(x,L)-a\kappa)_+\,\frac{dL}{L}.
 \tag{5}
\]
In particular $h_a\le h$, where $h$ is the R95 unthresholded occupation, and $\int_{\Omega_0^c}h_a\le J_1W_b$. The function is finite almost everywhere outside $\Omega_0$; infinite values inside that cap need not be excluded from its definition.

For every $L>0$, write $v=N(x,L)/\kappa$. Then
\[
 h_a(x)\ge\frac\kappa n G_{n,a}(v),\qquad
 G_{n,a}(v)=\int_0^{n\log2}(ve^{-s}-a)_+\,ds
 =\begin{cases}
 0,&0\le v\le a,\\
 v-a-a\log(v/a),&a<v\le a2^n,\\
 (1-2^{-n})v-an\log2,&v>a2^n.
 \end{cases}
 \tag{6}
\]
To prove it, for $u\in[L,2L]$ every old label $\ell_Q>L/(8n)$ remains a label of $\widehat N(x,u)$, including $u=2L$. Positivity and nested centered cubes imply $\widehat N(x,u)\ge(L/u)^nN(x,L)$. Apply the increasing positive-part function and integrate over this interval. The substitution $s=n\log(u/L)$ yields (6). The piecewise formula follows by stopping the positive integrand at $s=\log(v/a)$ when that point lies in the interval. All statements remain valid with countably many labels and $h_a=\infty$.

The exact scalar function has the useful bound
\[
 G_{n,a}(v)\ge\frac34(v-2a)_+\quad(n\ge2),
 \qquad
 (A_Lf-\kappa)_+\le(N-\kappa/3)_+\le\frac{4n}{3}h_a.
 \tag{7}
\]
Here is a direct proof of the scalar bound. Since the integration interval grows with $n$, it is enough to use $n=2$. There is nothing to prove for $v\le2a$. Put $t=v/a$. For $2\le t\le4$, subtracting $3a(t-2)/4$ from (6) leaves $a(t/4+1/2-\log t)$. Its derivative is nonpositive up to four, so its minimum on this interval is $a(3/2-\log4)>0$. The last strict inequality follows, for example, by integrating the strict chord bound for the strictly convex function $1/x$ on $[1,2]$, which gives $\log2<3/4$. For $t\ge4$ the same difference is the constant $a(3/2-\log4)$. This proves (7); the second statement then uses (3).

Equation (7) pays actual excess amplitude, rather than an unthresholded height. It retains a factor proportional to dimension. Thresholding by itself does not give a volume estimate for a level set of $h_a$, nor does positivity of $h_a$ assert that the actual cube maximal function exceeds $\kappa$.

## 4. A single cap and its precisely priced conditional energy

For any $\tau>0$, let
\[
 F_\tau(f,\kappa)=\{x\notin\Omega_0:h_a(x)>\tau\kappa/n\},
 \qquad\Omega_\tau=\Omega_0\cup F_\tau(f,\kappa).
 \tag{8}
\]
The same set is used at every scale. Infinite values of $h_a$ are included; their exterior measure is zero by (4). Without an additional capacity estimate, the proved volume bound is only
\[
 |\Omega_\tau|\le\left(4e+\frac{nJ_1}{\tau}\right)\frac{W_b}{\kappa}.
 \tag{9}
\]
Outside this cap, (7) bounds the true excess amplitude by $4\tau\kappa/3$. Hence the complete all-scale energy has the paid bound
\[
 \begin{aligned}
 \mathcal E_\kappa(f;\Omega_\tau)
 &=\int_{\Omega_\tau^c}\int_0^\infty(A_Lf-\kappa)_+^2\,\frac{dL}{L}\,dx\\
 &\le\frac{4\tau\kappa}{3}
       \int_{\Omega_0^c}\int_0^\infty(N-\kappa/3)_+\,\frac{dL}{L}\,dx
 \le\frac{4\tau J_0}{3}\,\kappa W_b.
 \end{aligned}
 \tag{10}
\]
A first moment has not silently become a second moment: the added cap supplies the pointwise amplitude bound. Its cost in (9) still contains dimension. The displayed proof budget has product $(4e+nJ_1/\tau)(4\tau J_0/3)=(4J_0/3)(4e\tau+nJ_1)$. Changing $\tau$ alone does not eliminate that term. This is a statement about the proved coefficients, not an operator lower bound.

If one had a genuinely proved uniform bound $|F_\tau(f,\kappa)|\le K W_b/\kappa$, then (9) would improve to $A\le4e+K$ while (10) keeps $B\le4\tau J_0/3$. The next section identifies exactly how strong such a capacity premise already is.

## 5. Quantitative equivalence with a weak maximal bound

Define the actual cube weak constant and the source-constructed occupation capacity by
\[
 C_n=\sup_{g\ge0,\ 0<\|g\|_1<\infty,\ \lambda>0}
 \frac{\lambda|\{Mg>\lambda\}|}{\|g\|_1},\qquad
 K_n(\tau)=\sup_{f,\kappa:\ W_b>0}\frac{\kappa|F_\tau(f,\kappa)|}{W_b}.
 \tag{11}
\]
The latter supremum uses exactly the stopped rectangles and cap of sections 2–4 for each original source and threshold. If $W_b=0$, its exceptional set is empty and contributes zero. Extended-real constants are permitted. For every fixed $\tau>0$,
\[
 K_n(\tau)\le6C_n,
 \qquad
 C_n\le\left(1+\frac{4\tau}{3}\right)\left(4e+K_n(\tau)\right).
 \tag{12}
\]
For the first inequality, $h_a(x)>0$ implies that $\widehat N(x,L)>\kappa/6$ for some scale. Since $\widehat N(x,L)\le A_Lf_b(x)$, the entire cap $F_\tau$ is contained in $\{Mf_b>\kappa/6\}$. Apply the weak bound to the actual nonnegative $L^1$ source $f_b$, whose mass is $W_b$, and then take the supremum. This uses the already stated weak constant as a hypothesis; it is not a new proof of that bound.

Conversely, outside $\Omega_\tau$, inequality (7) gives $A_Lf\le(1+4\tau/3)\kappa$ for every $L$. Therefore the strict maximal superlevel at that height is contained in the one cap. Its volume is at most $(4e+K_n(\tau))W_b/\kappa\le(4e+K_n(\tau))W/\kappa$. Given any $\lambda>0$, apply the construction at $\kappa=\lambda/(1+4\tau/3)$ and take the supremum over $f,\lambda$. If $W_b=0$, $f\le\kappa/4$ almost everywhere and the same superlevel is empty. This proves the second inequality, including zero-mass cases.

There is an exact low level at which the cap catches the whole original maximal superlevel. Set
\[
 \theta_0=\frac{1-\log2}{6}>0.
 \qquad
 \{Mf>\kappa\}\subset\Omega_0\cup F_{\theta_0}(f,\kappa),
 \qquad
 C_n\le4e+K_n(\theta_0)\le4e+6C_n.
 \tag{13}
\]
Indeed, $G_{n,1/6}(1/3)=\theta_0$ for all $n\ge2$, and $G_{n,1/6}$ is strictly increasing above $1/6$. If $Mf(x)>\kappa$, some actual scale has $A_Lf(x)>\kappa$, hence $N(x,L)>\kappa/3$ by the strict short-source bound. Equation (6) gives $h_a(x)>\theta_0\kappa/n$. The inclusion and the sharper weak bound follow. In particular, if $0<\tau\le\theta_0$, the energy outside $\Omega_\tau$ is actually zero; paying that cap is precisely where the weak-type difficulty remains.

Thus, for any fixed positive $\tau$, a subpower bound on $K_n(\tau)$ is equivalent, up to absolute constants and the harmless additive $4e$, to a subpower bound on $C_n$. A root-order bound on one is likewise comparable to a root-order bound on the other. Asking specifically for subpower low-level occupation capacity is stronger than merely asking for the original root-order weak target. The equivalence audits the strategy; it supplies no new uniform capacity estimate. It does not rule out a different common cap or a more efficient integrated energy argument that avoids a pointwise maximal bound.

## 6. Verification and remaining obligation

The mathematical manuscript passed two independent full reviews before the execution appendix was added. The author then executed the following three bounded, nonoverlapping stages using Python standard-library rational arithmetic and rigorous logarithm bounds. Incremental review of this appendix is recorded separately from those earlier mathematical reviews.

|Stage|Exact scalar parameter cases|Actual source--dimension models|Actual receiver profiles|Full persistence windows|Elapsed seconds|
|---|---:|---:|---:|---:|---:|
|Pilot|16|1|4|24|0.002101333|
|Stress|18|2|8|52|0.006697167|
|Expanded|27|2|8|52|0.023762416|

All stages passed. The 61 scalar cases use $n=2,3,4,8,16,64,128$ and test the threshold, the exact branch junction, nearby rational perturbations, and the linear tail. They check the clipped-integral formula against (6), the bound (7), the value at $v=1/3$, and monotonicity in dimension. They are scalar formula checks, not spatial experiments. The five genuine compactly supported step-source models have dimensions $2,3,4,8,16$. Their twenty pointwise receiver profiles retain the original maximal stopping block and both strict label cutoffs. Exact affine capture factors cover the entire positive scale axis; their monotonicity verifies persistence over all $u\in[L,2L]$ for each listed window, rather than sampling intermediate scales. There are 44 affine scale pieces, 128 windows, and 70 windows with positive retained $N$; these are dependent subdivisions and checks, not independent experiments. At 23 window starts the true excess is positive, so the profile suite is not confined to zero-excess sources.

These local profiles check actual hard averages and label persistence; they do not numerically integrate $h_a$ or energy, enclose global cap volume, or certify any original gate. Independent full-scale, full-space cap pressure tests belong to this round's companion numerical report, `energy_numeric.md`; those runs are cited as independent work and are not counted in this author's execution totals. The complete code, exact parameter lists, stable certificate digests, and execution receipt are retained in the private appendix. Timing is display-only. Neither the finite scalar checks nor the finite-dimensional profiles replace the proofs above or extend their quantifiers.

The minimum unpaid step in this proposed cap strategy is a uniform estimate for the actual spatial set in (8). Positivity or a jump count does not provide it. Equation (12) shows why using a weak maximal theorem to pay that set simply spends the endpoint statement being sought. A cutoff below the true threshold also need not remove every low-height background; any stronger claim requires actual-source pressure tests. The parent separately owns the unthresholded-cap counterexample, and that construction is not duplicated here. The general root-order goal remains unproved.

## 1. Scope and retained construction

Let \(n\ge2\), \(f\ge0\) be integrable, \(W=\int f\), and \(\kappa>0\). Retain the R95 canonical cyclic binary maximal bad rectangles \(Q\), their original labels \(\ell_Q\), the actual bad source \(\mu=f1_U\,dy\), and the single padded cap \(\Omega=\bigcup_Q(1+1/n)Q\). Thus \(|\Omega|\le4eW_{\rm bad}/\kappa\), and the original common reference and transport absorb all short labels at less than \(2\kappa/3\). Put
\[
 J_0=\log(16n^2),\quad J_1=\log(32n^2),\quad c_n=\frac{n}{1-2^{-n}}.
\]
All receivers retain Lebesgue measure, all scales are kept, and all source restrictions below are restrictions of this same actual measure. No new stopping rectangles or transport are constructed for the restricted source.

The new certificate uses the distribution of actual source depth inside this one cap. It can reduce the source mass in both the cap and energy budgets. Its general smallness is not proved, and the expanded pressure checks show that its remaining mass can be almost the entire source mass on simple admissible inputs. The general root-order weak bound remains open.

## 2. A scalar deficit selects one simultaneously absorbable source

Suppose \(W>0\) and \(W_{\rm bad}>0\); otherwise the original short-density bound already gives zero excess energy. The complement of \(\Omega\) is nonempty because the cap has finite volume. Define
\[
 d(y)=\operatorname{dist}_\infty(y,\Omega^c),\qquad
 F(r)=\mu\{y:d(y)\le r\},\qquad
 B=\sup_{r\ge0}\left[F(r)-\frac\kappa6(2r)^n\right]_+ . \tag{1}
\]
Distance is the infimum over the actual complement; it is a continuous function even when the countable union defining the cap is not closed. For \(y\in Q\), \(d(y)\ge\ell_Q/(4n)>0\), up to irrelevant source boundaries. Consequently \(F(0)=0\), \(F\) is right-continuous and nondecreasing, and \(F(r)\to W_{\rm bad}\). In particular \(0\le B\le W_{\rm bad}\).

There is a measurable source restriction \(b\le\mu\), of mass exactly \(B\), consisting of the shallowest source mass. If \(B=0\), set \(b=0\); if \(B=W_{\rm bad}\), set \(b=\mu\). Otherwise take a depth quantile \(r_*\) satisfying
\[
 \mu\{d<r_*\}\le B\le\mu\{d\le r_*\},
\]
and set \(b=\mu1_{\{d<r_*\}}+\alpha\mu1_{\{d=r_*\}}\), with \(0\le\alpha\le1\) chosen to obtain mass \(B\). This is a density restriction, so no point-mass or atomic splitting assumption is used. For \(g=\mu-b\), its cumulative depth mass is exactly
\[
 g\{d\le r\}=(F(r)-B)_+\le\frac\kappa6(2r)^n \quad(r\ge0). \tag{2}
\]
Indeed, before the quantile all mass is assigned to \(b\), at the quantile precisely \(B\) is assigned, and after it all the assigned mass remains \(B\). The inequality follows directly from (1).

If \(x\in\Omega^c\) and \(y\in Q(x,L)\), then \(d(y)\le\|y-x\|_\infty\le L/2\). Thus (2) yields the simultaneous, all-scale bound
\[
 T_Lg(x)\le L^{-n}g\{d\le L/2\}\le\kappa/6
 \qquad(x\in\Omega^c,\ L>0). \tag{3}
\]
One fixed restriction \(g\) is used for every receiver and every scale. Its mass is not reallocated or charged separately as the scale varies.

Moreover, \(B\) is the exact least residual mass among all restrictions \(g'\le\mu\) satisfying the scalar depth-capacity condition in (2). If \(b'=\mu-g'\), then
\[
 \|b'\|\ge b'\{d\le r\}\ge F(r)-\frac\kappa6(2r)^n
\]
for every \(r\); hence \(\|b'\|\ge B\). This optimality is only for the sufficient scalar condition, not for the original geometric energy problem.

## 3. The reduced mass pays both occupations

Retain the original source labels and write \(b_Q=b1_Q\). Define
\[
 N_b(x,L)=\sum_{\ell_Q>L/(8n)}T_Lb_Q(x),\qquad
 \widehat N_b(x,L)=\sum_{\ell_Q>L/(16n)}T_Lb_Q(x). \tag{4}
\]
These are jointly measurable nonnegative fields. The exact original partition is the original short source plus the near restrictions of \(g\) and \(b\). The short source is still controlled by the original common reference; the near part of \(g\) is at most \(T_Lg\). Therefore, outside \(\Omega\),
\[
 (T_Lf-\kappa)_+^2\le(N_b-\kappa/6)_+^2. \tag{5}
\]
The threshold loss is explicit: the former \(\kappa/3\) residual threshold becomes \(\kappa/6\).

For each original label, an exterior contribution requires \(L\ge\ell_Q/(2n)\). The two upper label cutoffs in (4) are respectively \(8n\ell_Q\) and \(16n\ell_Q\). Tonelli and mass preservation of cube averages therefore give
\[
 \int_{\Omega^c}\int_0^\infty N_b\,\frac{dL}{L}\,dx\le BJ_0,
 \qquad
 \int_{\Omega^c}\int_0^\infty\widehat N_b\,\frac{dL}{L}\,dx\le BJ_1. \tag{6}
\]
This is the R95 occupation argument applied to restrictions of its labels, with total mass \(B\), not to a newly stopped source. No original gate is claimed to survive an unrelated reclassification.

## 4. One final cap and a quadratic deficit improvement

Put \(h_b(x)=\int_0^\infty\widehat N_b(x,s)\,ds/s\). For \(s\in[L,2L]\), every label in \(N_b(x,L)\) occurs in \(\widehat N_b(x,s)\), and the centered receiving cubes are nested. Hence
\[
 \widehat N_b(x,s)\ge(L/s)^nN_b(x,L),\qquad
 h_b(x)\ge\frac{1-2^{-n}}nN_b(x,L). \tag{7}
\]
This explicitly recovers the retained R95 persistence constant; it asserts no improved scale-persistence exponent.

If \(B=0\), (5) gives zero exterior energy with the base cap. If \(B>0\), choose
\[
 T=J_1B/W,\qquad
 \Omega^*=\Omega\cup\{x\in\Omega^c:h_b(x)>T\kappa\}. \tag{8}
\]
By (6), the additional volume is at most \(BJ_1/(T\kappa)=W/\kappa\). On the complement of this one final cap, (7) gives \(N_b^2\le c_nT\kappa N_b\). Thus
\[
 |\Omega^*|\le(4e+1)W/\kappa,\qquad
 \mathcal E_\kappa(f;\Omega^*)
 \le c_nJ_0J_1\,\kappa\frac{B^2}{W}. \tag{9}
\]
The energy here is \(\int_{(\Omega^*)^c}\int_0^\infty(T_Lf-\kappa)_+^2\,dL/L\,dx\). In particular, the raw-square estimate used at this final step is only on the common cap complement. It is never an unrestricted whole-space raw-square assertion.

For a family of inputs with the independently verified source-depth condition \(B/W\le n^{-1/2+o(1)}\), (9) has a subpower energy coefficient and a bounded cap coefficient. The condition contains no unknown receiver energy or selected exceptional set beyond the explicit original cap, so it is a noncircular sufficient certificate. It has not been proved for general inputs. When \(B\) is comparable to \(W\), (9) has the same linear-in-dimension logarithmic energy cost as the R95 baseline.

## 5. The remaining general branch and finite-check scope

The scalar depth condition forgets the location of source mass along each depth surface. It places all shallow mass into one cumulative constraint, even when different shallow portions cannot be captured together by a receiving cube. Its exact residual \(B\) can consequently be large for a source whose actual positive-excess energy is zero. This demonstrates a limitation of this certificate, not a counterexample to an adaptively chosen common-cap theorem.

The preliminary pair-kernel route was not retained as a new estimate. The all-coordinate beta discount was already contained in the R93 overlap estimate. A pair-conditioned lens screen is a valid upper bound but can combine sources that are not simultaneously capturable, leaving another unpaid capacity. Neither observation is counted as new progress here.

The outstanding general task is to control the energy contributed by the shallow residual without requiring its entire mass to satisfy a scalar depth condition, or to replace that condition with a payable geometry-sensitive one. Equations (1)–(9) do not resolve that task. No finite source test is used to infer a general dimensional exponent.

The three stages have now actually run on 33 distinct continuous-source fixtures: pilot 6, stress 12, and expanded 15. Dimensions were 4, 8, 16 in the pilot; 4, 8, 16, 32 in the stress stage; and 64, 128, 256 in the expansion. One exploratory execution and one final receipt-format replay were performed on each fixture, for 66 fixture executions in total; these are 33 distinct tests, not 66 new inputs. The same 33 physical sources also passed exact label-splitting invariance checks in each run. Both runs used the embedded rational algorithm, and every source-mass bracket had width below \(10^{-16}\).

These checks evaluate the actual source-depth deficit and the squared factor \((B/W)^2\) in (9); they do not measure receiver energy or occupation. The source families include low background, narrow spikes, two physical scales, unchanged-density label splitting, and separated copies. The general branch remained significant: several expanded families leave essentially the full source mass in the residual, and separated copies show that a global depth distribution can lose spatial additivity. The special deep-source success cases do not extend to arbitrary input.

Both auditors passed the precise statement before proof drafting and then completed full Markdown/TeX proof, private-source, algorithm, and execution-scope reviews with PASS. The Astra auditor independently extracted and executed the embedded code; all mathematical JSON fields matched after excluding elapsed time. That independent replay is not counted as a new fixture or author experiment. The Sol auditor reported full proof and algorithm review without claiming an author-code replay.

## 1. Result and scope

A root-order paid refinement of the original residual forces a quantitative many-face condition on its **actual captured source posterior**. The input, receiver and original earliest hard selector stay fixed throughout. The direct angular-envelope payment of that condition, however, still has linear dimension order: the required count is of order sqrt(n), whereas the corresponding reference cone typically has order n/log(n) coordinates in the rather broad face layer. This is a precise limitation of the count-to-cone method, not a lower bound for the maximal operator. The general square-root-order theorem remains unproved.

There is an important gate distinction. The frozen Fnew has a coarse-noise upper bound only at its selected scale. It does not have that upper bound on the full window. We explicitly pay the additional full-window coarse-high branch below. The original full-window eta=1 gate, original middle condition, packet and physical-collision deletions remain in force; none is silently replaced or inherited by a changed source. This argument proves a new necessary posterior profile using hard contact and the newly paid coarse gate. It does not yet extract an additional capacity gain from the original middle lower bound.

## 2. Same input, selector and fully charged refinement

Let n>=2, mu=f dy with f>=0 in L1, W=mu(R^n), Q(x,L)=x+[-L/2,L/2]^n, and

    A_L f(x)=L^(-n)mu(Q(x,L)), H_n=1+n log2,
    theta=log^(-2)(n+2), alpha=1/[10log(n+2)].                 (1)

Use the original actual earliest contact L(x) in [1,2] on Fnew, so A_L f(x)=lambda, with its original anchor, later strict witness and all retained gates. The original middle lower bound concerns the full P_(1,L), not just the part captured by Q(x,L). We never transfer that lower bound to a captured convolution.

The scalar density and its smoothing are

    w(u)=integral_0^1 exp(-|u|/v)dv,
    phi_eta=1_[-1/2,1/2]*[eta^(-1)w(./eta)],
    Phi_eta=phi_eta^tensor n, P_(eta,s)=f*(Phi_eta)_s.

The established physical-dilation estimate, valid for 0<theta<=1, is

    integral sup_(1<=s<=2) P_(theta,s)(x)dx <= Tsoft W,
    Tsoft=1+(log2)min(2n,sqrt(n(theta^(-1)+4theta/3))).          (2)

Delete from Fnew the NEW branch Hwin={sup_[1,2] P_(theta,s)>=alpha lambda}. Its original demand costs at most (Tsoft/alpha)W. This is charged in addition to the old selected coarse branch; one could instead enlarge that earlier branch, but we make no such accounting substitution here.

Put delta=n^(-1/2), t=1+delta. The further branch {L<t} costs at most

    Cnear W, Cnear=1+n log(1+delta)<=1+sqrt(n).                  (3)

Indeed the sourcewise hard envelope over [1,t] is 1 up to full radius 1 and R^(-n) from full radius 1 to t; its integral is 1+n log t. This pays the actual demand at each of these original contact scales. Let B be any measurable subset of the remaining Fplus={x in Fnew\Hwin:L(x)>=t}. Define the legal shorter scale s(x)=L(x)/t in [1,2], keeping f,x,L unchanged. It obeys P_(theta,s)(x)<alpha lambda by the explicitly paid refinement.

## 3. Actual captured posterior theorem

Define the probability law

    pi_x(dy)=1_Q(x,L)(y) dmu(y)/(lambda L^n).

Let

    r=log(8/delta), a_r=-log(1-delta/8),
    b=log3+2delta/theta, B_r=b-a_r,
    K(x,y)=#{j: |x_j-y_j|/s > 1/2-r theta}.                   (4)

Here B_r>6/7>0, since log3>1 and a_r<=delta/7<=1/7. If the threshold in (4) is nonpositive the count is n almost surely and the statement is allowed to be trivial. No independence assumption is made on pi_x. Then

    E_pi exp(-B_r K)<alpha exp[-n(log t-a_r)],
    E_pi K>[n(log t-a_r)+log(1/alpha)]/B_r.                  (5)

In particular, with

    q=[n(log t-a_r)+log(1/(2alpha))]/B_r,
    k=floor(q)+1,
    pi_x{K>=k}>1/2.                                        (6)

If k>n, this proves that B is empty. All these statements concern the actual original captured posterior at every retained receiver, not a product reference law. Moreover

    log t-a_r >=5delta/14.                                 (7)

Thus the numerator giving the count is at least a constant times sqrt(n). As n tends to infinity B_r tends to log3 and k is asymptotic to (7/(8log3))sqrt(n). This asymptotic describes the explicit scalar threshold, not any maximal constant.

Proof of the scalar bounds and (5). For eta<=1 the boundary value is

    phi_eta(1/2)=integral_0^1 v(1-exp[-1/(eta v)])dv>1/3.

For the last bound, exp(-1/v)<=v/e on (0,1], so the subtracted integral is at most 1/(3e)<1/6. At u=1/2+eta z, z>=0, let F=phi_eta(u), G=eta|phi_eta'(u)|. The mixture formulas give G<=w(z), while

    F>= (1/2)integral_0^1 v exp(-z/v)dv >=w(z)/4.

The second inequality follows by integrating the nonnegative product (v-v')(exp(-z/v)-exp(-z/v')) over two independent uniform variables; this is a scalar integral identity, not an assumption on f. Hence |phi_eta'|/phi_eta<=4/eta outside the interval. Consequently, for |u|<=t/2,

    phi_theta(u)>=(1/3)exp(-2delta/theta).

When |u|<=1/2-r theta, the two omitted tails have sum at most exp(-r): explicitly they are the integral of v times the sum of two exponentials with distances at least r theta. Thus phi_theta(u)>=1-exp(-r). Multiplication gives Phi_theta((x-y)/s)>=exp[-n a_r-B_r K]. The actual captured part of the full convolution yields

    P_(theta,s)(x)/lambda
      >=t^n E_pi Phi_theta((x-Y)/s)
      >=exp[n(log t-a_r)] E_pi exp(-B_r K).

Apply the paid gate. Jensen proves the mean assertion. On {K<=k-1}, exp(-B_r K)>=exp[-B_r(k-1)]; the first inequality in (5) and the definition of k give probability strictly below 1/2. Finally a_r<=delta/(8-delta)<=delta/7 and log(1+delta)>=delta/2 prove (7). This completes the proof without replacing L by a deterministic node.

## 4. Common-source angular payment and its exact dimension cost

Write omega=(x-y)/(2||x-y||_infinity) off the diagonal, so omega lies on the boundary of the unit full-side cube. Put

    p=min(1,(delta+2r theta)/(1+delta)),
    d_k=Pr{1+Bin(n-1,p)>=k}.                                (8)

Use d_k=0 if k>n. The binomial law in (8) belongs ONLY to the uniform reference cone: condition on its first dominant face, and its other n-1 coordinates are uniform on [-1/2,1/2]. It is not asserted for pi_x.

For a captured point z=(x-y)/L, angular normalization only increases absolute coordinates. Therefore K(x,y)>=k implies at least k coordinates of omega have absolute value greater than (1-p)/2. Let Gamma_k be this angular event and define the genuine captured subkernel

    h_x(y)=L(x)^(-n)1_Q(x,L)(y)1_Gamma_k(omega),
    d(x)=integral h_x dmu >lambda/2.                        (9)

The normalized rows lambda h_x/d(x) pay full demand lambda and retain the original capture support. Their source columns are bounded by 2H_n d_k. To prove this, pointwise dominate h_x by the sourcewise radial envelope

    max(1,2||x-y||_infinity)^(-n)
       1_{2||x-y||_infinity<=2}1_Gamma_k(omega).

Cube-polar integration gives its integral exactly (1+n log2)d_k. This consists of cone volume d_k inside full radius 1 and n d_k integral_1^2 dR/R outside. Tonelli and the multiplier at most 2 prove the claim. In particular every measurable subcut A of B has the original-capture Hall payment

    lambda|A|<=2H_n d_k mu(N_A),                            (10)

where N_A is the essential union of its original capture cubes. This is a common physical-source allocation. No source label copies or independent capacities are used.

The coefficient in (10) does not have root order for the parameters above. For every n>=2^24,

    k<=4sqrt(n),
    m:=1+(n-1)p >=n/[8log(n+2)]>=2k,
    d_k>=1-32log(n+2)/n>=1/2.                               (11)

Here is a uniform proof. The inequality log(5log(n+2))<=sqrt(n) holds for n>=16: it holds at 16, and the derivative of sqrt(n)-log(5log(n+2)) is positive there and afterwards. Since B_r>6/7 and n log t<=sqrt(n), k<=7sqrt(n)/3+1<=4sqrt(n). Also p>=r theta unless it is clipped to 1, in which case the following weaker bound still holds. The relations r>=log(n)/2>=log(n+2)/4 give p>=1/[4log(n+2)] and hence the stated lower bound on m. The ratio sqrt(n)/log(n+2) increases for n>=2^24, and at 2^24 it exceeds 64 (use log(n+2)<25 and sqrt(n)=4096). Thus m>=8sqrt(n)>=2k. For X=1+Bin(n-1,p), Var X<=m; Chebyshev gives Pr(X<k)<=4/m. This proves (11).

Accordingly the explicitly obtained upper-fee coefficient 2H_n d_k is between H_n and 2H_n in this range. This is a lower estimate for this **method's coefficient**, not a lower estimate for the norm or for any actual gated receiver demand. The angular enlargement has discarded the crucial source dependence: a face layer of width r theta, of order 1/log(n), is too broad for a sqrt(n) count to be a rare reference event. Replacing this width by 1/n is not justified; the omitted captured traffic would require a separate paid estimate.

## 5. Full ledger, terminal and missing use of the original middle gate

Let A_old be the retained fee for the classifications before Fnew. To make the constants explicit, retain

    Bbase=4+2log2 sqrt(7n/3), Bext=2H_n/sqrt(n+2),
    a0=n^(-p0), rho0=n^(-1/2) (fixed p0>0),
    Pdom=(5+3log(1/a0))/rho0,
    h*=1/(16n^(3/2)), E*=exp(nh*),
    B*=1+E*[1+(2n^2+n)h*],
    Pphys=2[E*+B*+2(1+E*)sqrt(n)],
    A_old=Bbase+Bext+Tsoft/alpha+Pdom+Pphys.                  (12)

Pphys is the single already-paid union, not two repeated charges. Keeping every old branch and paying the new full-window branch separately gives the local-event bound

    lambda|E_initial|
      <=[A_old+Tsoft/alpha+Cnear+2H_n d_k]W.                 (13)

Empty residuals contribute zero. There is no recursive source restriction, no changed threshold, no new kappa splitting and no terminal in this one-input argument. Thus no beta^(-i) occupation or favorable terminal is being suppressed. If this refinement is inserted into a recursive proof, it must be recomputed and its Tsoft/alpha fee paid on each actual current source/threshold; this note proves no summability of those repeated fees. The retained all-scale return still costs C_loc log(n+2). Any separately used original kappa-layer decomposition still costs its actual J_n and overlaps. A separate R83 registered-width deletion, if used, carries its additional Bext fee.

All gates defining Fnew are retained. Their joint use remains incomplete: (5) uses actual hard contact plus a paid full-window coarse upper bound; the original P1 middle lower bound may receive source mass outside the original cube and does not supply the missing capture concentration for free. A genuine new joint estimate must control the angularly enlarged source traffic, or pay the complement after narrowing its layer, at the original same input and selector. The current result is a strict necessary posterior profile and an audited failure of its most direct cone-capacity conversion. It is not the R95 equivalent initial-bank reduction and is not a solution of the general theorem.

## 6. Method and verification scope

Updated F01 and J01 were checked: no undefined GP branch or stochastic generator is invoked. H05 was read and its dependence requirement is enforced: product/binomial independence appears only in the explicitly constructed reference cone; (5)--(7) hold for arbitrary correlated captured laws. The final reference lower-tail estimate is proved directly by variance and Chebyshev, with no unverified large-deviation theorem.

Three stages were actually executed in this round. Seven distinct dimensions were checked with outward rational logarithm intervals and exact rational arithmetic, in groups 2/2/3. There were 116 assertions (32/32/52), with elapsed time 2.376047209 seconds. These are finite algebra/reference-geometry and actual first-contact-posterior checks, not samples of an originally fully gated residual. The separate private phase author reports no certified original-root captured posterior; its fixed-node result is not substituted for L. Concrete test sources, parameters and replay code remain outside this public extraction. Both independent auditors subsequently read the complete MD and matching TeX and passed all equations (1)--(13), original-gate accounting, the private diagnostic scope and the final limitation. Astra independently extracted and replayed the embedded program: PASS 116, stages 32/32/52, internal 2.314934125 seconds and external 2.331753458 seconds. This replay is not a new experiment. Sol's full-proof receipt does not claim those author counts as independent guard units.

## S0. Result and retained limits

The new transfer pays the actual all-scale cube excess outside ONE physical cap when its actual obstacle potential satisfies a pointwise quadratic distance bound. It does not assume the desired excess-energy inequality. The coefficient is explicit: cap volume \(W/\kappa\), energy \((10K+20K^2)\kappa W\). The unproved general hypothesis is a uniformly affordable quadratic certificate for arbitrary positive \(L^1\) inputs. The bounded-density consequence below has exponential dimension cost, so it does not close the project target. Original gates, selectors, sources and thresholds have not been modified or certified by this source calculation.

Write \(A_L\nu=L^{-n}1_{[-L/2,L/2]^n}*\nu\), with full side \(L\), Fourier convention \(e^{-2\pi i x\cdot\xi}\), and
\[
\mathcal E_\Omega(\kappa,\nu)=\int_{\Omega^c}\int_0^\infty(A_L\nu-\kappa)_+^2\,\frac{dL}{L}\,dx.
\]
Throughout, a cap is the SAME set at every scale and its full Lebesgue volume is charged. The R94 scalar cube multiplier bound is retained, not a new source reading:
\[
m_L(\xi)=\prod_j\operatorname{sinc}(\pi L\xi_j),\qquad |m_L(\xi)|^2\le\frac1{1+\pi^2L^2|\xi|^2/10}.
\tag{1}
\]

## S1. Actual near-energy localization, including irregular boundaries

Let \(n\ge1\), \(\Omega\subset\mathbb R^n\) be open with nonempty complement, \(u\in H^1(\mathbb R^n)\), and \(u=0\) almost everywhere on \(\Omega^c\). Put \(g=\nabla u\), \(d(y)=\operatorname{dist}_\infty(y,\Omega^c)\). Suppose \(b=-\operatorname{div}g\) is a finite signed Borel measure. For every \(R>0\),
\[
\int_{\Omega^c}\int_0^R|A_Lb|^2\,\frac{dL}{L}\,dx
\le5\int_\Omega |g(y)|^2\left[d(y)^{-2}-4/R^2\right]_+\,dy.
\tag{2}
\]
The right side may be infinite. No regularity or zero-volume assumption on \(\partial\Omega\) is made.

Proof. For every vector field \(v\in L^2(\mathbb R^n;\mathbb R^n)\), (1) and Plancherel give
\[
\|\operatorname{div}(A_Lv)\|_2^2\le 40L^{-2}\|v\|_2^2.
\tag{3}
\]
Indeed the Fourier divergence is \(2\pi i\xi\cdot\widehat v\), and \(4\pi^2|\xi|^2|m_L|^2\le40/L^2\). The same bound for each derivative shows that every component of \(A_Lv\) is in \(H^1\). This avoids dividing the potential Fourier transform at zero.

Fix \(L\) and split \(g=v_L+w_L\), where \(v_L=g1_{\{d>L/2\}}\), \(w_L=g1_{\{d\le L/2\}}\). If \(x\in\Omega^c\), its cube cannot contain a point with \(d(y)>L/2\), so the actual convolution \(A_Lv_L(x)\) is zero. By Sobolev locality, each weak derivative of an \(H^1\) function vanishes almost everywhere on its zero set. Therefore \(\operatorname{div}(A_Lv_L)=0\) almost everywhere on \(\Omega^c\), even when the boundary has positive measure. Distributional support alone would not justify this step. Also \(g=0\) almost everywhere on \(\Omega^c\), by the same locality applied to \(u\).

Consequently (3) bounds the exterior \(L^2\) norm of \(A_Lb=-\operatorname{div}(A_Lw_L)\) by \(40L^{-2}\int_{\{0<d\le L/2\}}|g|^2\). The finite-measure convolution agrees with this distributional \(L^2\) representative: its Fourier transform is \(m_L\widehat b\), and distributional equality followed by Plancherel identifies it. Convolution with a bounded cube kernel and a finite measure is an ordinary measurable function. The fields and kernels are jointly measurable in \((L,x,y)\); Tonelli and the fixed-scale almost-everywhere identifications therefore apply to the scale integral. Finally,
\[
40\int_{2d}^R L^{-3}\,dL=5(d^{-2}-4/R^2)_+.
\]
This proves (2). Sending \(R\uparrow\infty\) yields the all-scale upper bound \(5\int_\Omega |\nabla u|^2/d^2\).

## S2. A complete conditional common-cap excess-energy theorem

Let \(\kappa>0\), \(\Omega\) bounded and open, \(u\in H^1(\mathbb R^n)\) compactly supported, nonnegative, and zero almost everywhere on \(\Omega^c\). Let \(f\ge0\) belong to \(L^1\cap L^2\), \(W=\int f\), and set
\[
s=\kappa1_\Omega+f1_{\Omega^c},\qquad 0\le s\le\kappa,
\qquad -\Delta u=f-s.
\tag{4}
\]
These are actual identities for the same physical input. Suppose additionally that a finite \(K\ge0\) satisfies
\[
0\le u(y)\le K\kappa\,d(y)^2\quad\hbox{almost everywhere.}
\tag{5}
\]
Then
\[
\kappa|\Omega|\le W,\qquad
\int_\Omega\frac{|\nabla u|^2}{d^2}\le(2K+4K^2)\kappa W,
\qquad
\mathcal E_\Omega(\kappa,f\,dx)\le(10K+20K^2)\kappa W.
\tag{6}
\]
In particular (6) treats both arbitrarily small scales and the large-scale tail on one cap.

Proof. A smooth compactly supported cutoff equal to one near the compact support of \(u\) gives \(\int(f-s)=\langle-\Delta u,1\rangle=0\). Thus \(\int s=W\), and the first inequality follows. If \(W=0\), nonnegativity forces \(f=s=0\); \(\int|\nabla u|^2=0\) and compact support give \(u=0\), so all conclusions are zero. The empty-cap case is likewise trivial.

For \(\varepsilon>0\), put \(d_\varepsilon=d+\varepsilon\). Distance in the maximum norm is Euclidean 1-Lipschitz, so \(|\nabla d|\le1\) almost everywhere. The compactly supported function \(u/d_\varepsilon^2\) belongs to \(H^1\); since \(f-s\in L^2\), it is an admissible weak test for (4). With \(E_\varepsilon=\int|\nabla u|^2/d_\varepsilon^2\),
\[
E_\varepsilon-2\int\frac{u\nabla u\cdot\nabla d}{d_\varepsilon^3}
=\int\frac{u(f-s)}{d_\varepsilon^2}\le K\kappa W.
\tag{7}
\]
The negative reference term was dropped using \(s\ge0\). Young's inequality and (5) bound the absolute cross term by
\[
\tfrac12 E_\varepsilon+2\int_\Omega u^2/d_\varepsilon^4
\le\tfrac12 E_\varepsilon+2K^2\kappa^2|\Omega|.
\]
Hence \(E_\varepsilon\le(2K+4K^2)\kappa W\). Monotone convergence as \(\varepsilon\downarrow0\), together with \(\nabla u=0\) on the complement, proves the middle bound in (6). Apply (2) at \(R=\infty\) to the finite density measure \(b=(f-s)dx\). Since \(A_Ls\le\kappa\), pointwise
\[
(A_Lf-\kappa)_+\le|A_L(f-s)|.
\]
The last inequality in (6) follows. This is an exterior comparison for actual positive excess, not a cancelled-square estimate masquerading as one.

The new missing hypothesis is (5), along with existence of (4) in the stated finite-energy class. It is pointwise and independently checkable for a proposed potential, rather than an assumption of the target maximal inequality or target energy. No universal \(K\), no compact support or finite-energy extension for arbitrary \(L^1\), and no retained middle/coarse gate qualification is supplied. The pointwise certificate can overcharge sources deep inside the cap: a private actual positive-input pressure calculation shows that weighted potential energy can be unbounded while exterior all-scale energy stays uniformly finite. Thus a failed quadratic certificate does not imply failure of a good physical cap or of the maximal target.

## S3. Bounded-density certificate with its full dimension cost

Under (4), suppose \(f\le D\kappa\) on \(\Omega\), for a finite \(D\ge0\). In addition, require that the continuous representative of \(u\) vanish at EVERY point of \(\Omega^c\), for example when \(\Omega=\{u>0\}\). Then (5) holds with the safe explicit value
\[
K=\frac{2^{n+2}+D}{2}.
\tag{8}
\]
Bounded distributional Laplacian gives such a continuous representative: locally subtract the Newtonian potential of the bounded right side; its first-derivative kernel is locally integrable, and the remaining distribution is harmonic. No \(C^{1,1}\) conclusion from merely bounded \(f\) is used. Almost-everywhere vanishing from S2 alone does not identify the pointwise zero-contact set of an arbitrary open cap. The extra pointwise condition is essential for the nearest-contact argument; it is not inferred from continuity and an almost-everywhere identity. Choosing another cap requires checking (4) and its volume again.

Here is a direct proof, with every geometry fee. For \(x\in\Omega\), let \(r=\operatorname{dist}_2(x,\Omega^c)\), and choose a nearest contact \(z\), so \(u(z)=0\). Globally \(\Delta u=s-f\le\kappa\). Apply the superharmonic mean inequality to \(u(y)-\kappa|y-z|^2/(2n)\) in \(B_{2r}(z)\), obtaining
\[
\dashint_{B_{2r}(z)}u\le 2\kappa r^2/n.
\]
On \(B_r(x)\subset\Omega\), \(\Delta u\ge-D\kappa\). The subharmonic mean inequality for \(u(y)+D\kappa|y-x|^2/(2n)\) gives
\[
u(x)\le\dashint_{B_r(x)}u+D\kappa r^2/(2n)
\le\frac{2^{n+2}+D}{2n}\kappa r^2.
\]
The last step uses \(u\ge0\), ball inclusion \(B_r(x)\subset B_{2r}(z)\), and the actual volume ratio \(2^n\). Finally \(r\le\sqrt n\,d(x)\), proving (8). Distributional mean inequalities follow by mollification and continuity; limiting radii handle touching boundaries. A slightly sharper \(n+2\) denominator is possible but unnecessary.

This certificate is genuine for bounded sources in the qualified class, but its energy constant in (6) is exponential in \(n\) and depends on \(D\). Truncating an arbitrary input to enforce \(D\) would change (4) and leave its signed remainder unpaid. Thus this corollary is not an all-input root-order estimate.

## S4. Primary theorem and exact reading boundary

One new primary source was read: [Figalli, Free boundary regularity in obstacle problems](https://people.math.ethz.ch/~afigalli/lecture-notes-pdf/Free-boundary-regularity-in-obstacle-problems.pdf), author lecture notes for Journées EDP 2018. Sections 2–5, printed pp. 2–9, including Proposition 2.1, the Euler–Lagrange proofs, Theorem 4.1, Lemma 4.2 and their proofs, were read. The source setting has a bounded \(C^1\) domain \(\mathcal D\), a \(C^1\) obstacle \(\varphi\), and \(C^1\) boundary data above the obstacle; \(U\) is its Dirichlet-energy minimizer and \(v=U-\varphi\). Lemma 4.2 assumes \(\Delta\varphi\in L^\infty\), and gives \(v(x)\le C_0 d_2(x,\partial\{v>0\})^2\) only when \(d_2(x,\partial\{v>0\})\le d_2(x,\partial\mathcal D)/3\). The paper leaves \(C_0\) dependent on \(n\) and \(\|\Delta\varphi\|_\infty\); unpacking its displayed mean-value proof gives the safe value \(C_0=(1+2^{n+2})\|\Delta\varphi\|_\infty/(2n)\), including the \(2^n\) volume fee. Theorem 4.1 additionally requires a \(C^{1,1}\) obstacle and yields local \(C^{1,1}\) regularity. Its cited harmonic interior estimates were not independently reread. Later free-boundary classification was not used. These are classical results proved in the notes, not claims of first discovery.

Equations (2), (6), and (8) are our transfers with different hypotheses and explicit constants, not printed theorems from those notes. In particular the actual forcing \(\kappa-f\) can change sign; the later normalized positive-forcing free-boundary classification does not apply automatically. No dimension-free constant, global weighted-gradient budget, universal compact potential, or original-gate theorem is attributed to the paper. R95 partial-balayage readings and R94 square-function readings are retained and are not new R96 reading counts.

Updated64 scope: this round F05 entry, method and cube interface were read; G01 entry was checked against the retained geometry boundary. F05 requires a genuine parameter measure and two-sided Schur/spectral hypotheses; the proof here is the direct cube Fourier bound (3), not an imported Schur constant. G01 requires actual box/tent or all-node packing bounds, so it cannot infer (5) or the weighted strip norm from a tool name. The previously audited J03 distinction between a physical potential and exit/redistribution identities remains in force. The authorized read-only package root is `/Users/zhengzhihao/Desktop/T/数学工具64项_最终交付验收_20261011/f-zip/fresh-extraction/zip-root/数学工具64项_完整验收提升_20261007`; the old registry root remains missing and the global registry was not changed. The new paper was read directly from the author's PDF. Hashes are not reading evidence.

## S5. Three stages on a new actual potential/source model

These checks are distinct from R95's cubic product model. Set \(\phi(t)=(1-t^2)_+^2\), \(u_A(x)=A\prod_{j=1}^n\phi(x_j)\), \(\Omega=(-1,1)^n\), \(\kappa=9An\), \(s=\kappa1_\Omega\), and \(f=s-\Delta u_A\). The first derivative of \(\phi\) vanishes at both endpoints, so no surface Laplacian measure is omitted. Since \(-4\le\phi''\le8\), one has \(An\le f\le13An\) on \(\Omega\), zero outside. This is a true positive finite \(L^1\cap L^2\) input with \(W=\kappa2^n\). Furthermore \(u_A\le4A d^2\), so \(K=4/(9n)\). This potential is also a genuine obstacle minimizer: for nonnegative compactly supported \(H^1\) competitors with finite functional,
\[
J(v)=\int|\nabla v|^2+2\int(\kappa-f)v,
\qquad J(v)-J(u_A)=\|\nabla(v-u_A)\|_2^2+2\kappa\int_{\Omega^c}v\ge0.
\]
These benign inputs do not model or certify the original retained gates.

The ACTUAL weighted gradient integral, rather than a discrete scale proxy, is computed exactly by polynomial integration. Put
\[
a(z)=2(z-4z^3/3+6z^5/5-4z^7/7+z^9/9),\quad
b(z)=32(z^3/3-2z^5/5+z^7/7).
\]
Partition by the coordinate attaining \(\max_j|x_j|=z\); ties have measure zero. The integral equals
\[
I_n(A)=2nA^2\int_0^1\left[16z^2(1+z)^2a(z)^{n-1}
+(n-1)(1-z)^2(1+z)^4b(z)a(z)^{n-2}\right]dz.
\tag{9}
\]
This follows by separating the gradient component in the maximal coordinate from the remaining components and dividing by \(d^2=(1-z)^2\). Every coefficient and integral was evaluated as a rational number.

| Stage | Dimensions | Amplitudes | Actual quantity checked |
|---|---|---|---|
| Pilot | 2, 3 | 1/7, 1, 3 | \(I_n(A)/(\kappa W)\le2K+4K^2\) |
| Admissibility/parameter stress | 5, 9, 12 | 1/7, 1, 3 | Same physical integral and positivity; a separate oversized amplitude is rejected as signed input |
| Expanded | 16, 24 | 1/7, 1, 3 | Same exact integral, mass units and certificate |

For dimensions 2, 3, 5, 9, 12, 16, 24, respectively, displayed decimal ratios are approximately 0.04246035, 0.01174593, 0.001206814, 0.00001938735, 0.000001011795, 0.00000002157370, 0.00000000001145017. The decisions used rational comparisons, not these decimal displays. The ratio is amplitude independent because both physical sides scale as \(A^2\); this is a units check, not three independent shapes. Twenty-one qualified models and seven positivity-rejection checks produced 91 exact assertions in 0.023077 seconds. There were no random draws, float quadratures, original-gate certifications, or direct receiver-energy integrations. The all-scale receiver conclusion is analytic (6). Replaying these checks is not a new experiment.

Reproduction uses Python's standard-library Fraction, with the following complete primitive; it writes no extra file:

```python
from fractions import Fraction as F

def add(a,b):
 c=[F(0)]*max(len(a),len(b))
 for i,v in enumerate(a): c[i]+=v
 for i,v in enumerate(b): c[i]+=v
 return c

def mul(a,b):
 c=[F(0)]*(len(a)+len(b)-1)
 for i,x in enumerate(a):
  if x:
   for j,y in enumerate(b):
    if y: c[i+j]+=x*y
 return c

def power(a,n):
 p=[F(1)]
 for _ in range(n): p=mul(p,a)
 return p

def integral(p): return sum((v/F(i+1) for i,v in enumerate(p)),F(0))
a=[F(0),F(2),F(0),-F(8,3),F(0),F(12,5),F(0),-F(8,7),F(0),F(2,9)]
b=[F(0),F(0),F(0),F(32,3),F(0),-F(64,5),F(0),F(32,7)]
p1=[F(0),F(0),F(16),F(32),F(16)]
p2=mul([F(1),F(-2),F(1)],power([F(1),F(1)],4))
count=0
for n in [2,3,5,9,12,16,24]:
 I=2*n*integral(add(mul(p1,power(a,n-1)),
                  [v*(n-1) for v in mul(mul(p2,b),power(a,n-2))]))
 for A in [F(1,7),F(1),F(3)]:
  kappa=9*A*n; W=kappa*2**n; K=4*A/kappa
  ratio=A*A*I/(kappa*W)
  assert ratio>0 and ratio<=2*K+4*K*K; count+=2
  assert 9*A*n-8*A*n>0 and K==F(4,9*n); count+=2
 # Holding kappa=9n while enlarging A may lose positive-source status.
 z=F(99,100); phi=(1-z*z)**2
 dd=-4+12*z*z-4*(n-1)*phi
 assert 9*n-F(9*n,4)*dd<0; count+=1
assert count==91
print(count)
```

## S6. Exact remaining general boundary

For the retained reconstruction theorem, a cap/potential family must be available for EVERY \(\kappa\) for the SAME input, with uniform \(K_n\); one successful neutral model or one threshold is insufficient. Under that additional family hypothesis, the already proved reconstruction gives, with \(B_n=10K_n+20K_n^2\) and \(q=\lambda/\kappa\ge4\),
\[
\lambda|\{M_{\rm cube}f>\lambda\}|/W
\le q+\frac{16nB_n}{q\log2}
\le4+8\sqrt{nB_n/\log2}
\]
by choosing \(q=\max\{4,4\sqrt{nB_n/\log2}\}\). This is a retained consequence, not a new proof of the target. A subpower \(K_n\) would be useful; neither the primary notes nor this round constructs it for general physical inputs. Arbitrary density spikes violate bounded \(D\); a source-dependent cancellation or truncation cannot be discarded. Generic Carleson, partial-balayage existence, finite transport duality and regularity names do not pay the strip integral or its dimension cost.

Both auditors received (2), (6), and (8) before proofs. Their independent full mathematical reviews of MD and matching TeX passed after they identified the necessary pointwise zero-contact hypothesis in S3 and it was added explicitly. Their review certifies our transfers and scope, not an independent rereading of the primary notes or replay of the author arithmetic. Primary reading provenance, our own transfer proof and executed arithmetic are separate claims. The general root-order target and original coarse-gate qualification remain unresolved.

## Parent scope audit of the R95 conditional cap proposal

The R95 all-input cyclic decomposition and its proved common-cap baseline remain valid. The further proposal to use the unthresholded occupation field at threshold \(\kappa/n\) cannot carry a uniform subpower cap-volume bound: a family of actual, finite, positive \(L^1\) inputs violates that particular sufficient condition. This is a failure of a prescribed deletion rule. It is not a counterexample to the desired weak-type bound, and it does not exclude a different common cap or a threshold-preserving proof.

The obstruction is accumulated source occupation at scales where the actual averages are below the target height. All source labels, maximal stopping rectangles, the single globally measured cap, a positive-volume set of receivers and an entire continuum scale window are retained. No atoms, Gaussian limit, sampling-to-volume conversion, or replacement of the original receiver measure is used. The construction, quantitative obstruction and reconstruction program remain in the local private appendix.

Three executed stages used a preliminary domain, known failure-mode pressure, and an enlarged parameter domain. Their 30 actual input laws, 600 exact point/scale captures, 315 exact ancestor-average checks, ten global cap geometries and twelve explicitly enumerated one-dimensional union checks have different units and are not summed. The all-dimension conclusion rests on the proof, not on this finite evidence. The program does not compute the whole occupation integral: a rigorous lower bound over a full scale interval suffices. Hashes and the independent replay receipts identify the final tested bytes. This use follows L02's real-input requirement and A02's separation of a valid relaxation from the cost of that relaxation.

The resulting change of strategy is to preserve an actual excess threshold throughout any replacement occupation or pair estimate, and to check whether a proposed small-cap premise already assumes a weak-type bound at least as strong as the goal. Neither modification by itself supplies the missing general capacity estimate.

本轮计算的是实际正 L1 来源的全尺度占用量，不是有限尺度采样，也不是原 Fnew 门控实验。固定 kappa=1、a=1/6，定义

```text
Nhat_L(x) = sum over stopped Q with L < 16*n*ell_Q of A_L(f restricted to Q)(x),
h_a(x) = integral_0^infinity (Nhat_L(x)-1/6)_+ dL/L,
h_plain(x) = integral_0^infinity Nhat_L(x) dL/L,
Omega_base = union_Q (1+1/n)*Q,
Omega_a = Omega_base union {x outside Omega_base : h_a(x)>1/n}.
```

这里所有帽都是同一个、与 L 无关的可测空间集合；体积在全空间收费。来源、阈值、停止块和网格在比较前固定。计算返回真正超水平集的内外体积区间，不能判定的体积保留为 UNKNOWN。没有计算普通 RAW 平方能量，没有用数值拟合一般维数指数。

最有判别力的结果是：阈值扣除确实能消去某些未扣除占用帽，但它没有消去所有低于 kappa 的背景。在八维半密度单位立方体上，同一真实小盒处 h_plain>1/8，而整个基础帽外 h_a<1/8。在十六维同一半密度来源上，存在基础帽外真正正体积小盒，其 h_a>1/16；该来源的真实超额能量却在全空间、全尺度恒等于零。这个小盒并不证明帽过费：本例全部新增帽体积的严格上界仍只有 7/32768。本轮没有发现中性模型中的体积过费证书，也没有证明一般廉价帽条件。

## 实际执行的三个阶段

1. 初探：f=(1/2) times indicator of [-1/2,1/2]^2。W=1/2，一个实际最大坏块 Q。36 个全二维反射/置换轨道，15 个在基础帽外。
2. 障碍压力：二维实际两尺度来源。两个均匀正方形各有质量 1/2，中心分别为 (0,0)、(3/2,0)，半边长分别为 1/16、1/2。循环二分实际产生 8 个最大坏块；来源质量全部逐块限制而非按原混合标签分配。400 个二维接收格、544 个帽外面分割片。
3. 扩大参数：同一个半密度单位立方体模型，分别在 n=4,8,16 计算；全维轨道数为 70、495、4845。不是二维轮廓代替高维接收测度。

因此共有 5 个来源—维数组合、5446 个反射/置换格轨道，以及单独的 400 个直接接收格。格细分产生的 544 个压力片不是额外来源，也不是额外独立实验。两次初步包络改进没有作为新输入重复计数。

下表数字只用于阅读；严格证书是 JSON 的 Fraction 字段。第三列是实际基础帽全空间体积，第四列是全空间新增超水平集体积区间。

|模型|n|基础帽体积|新增 h_a>1/n 帽体积|
|---|---:|---:|---:|
|半密度单位立方体|2|9/4|0|
|实际两尺度循环限制|2|25/8|0|
|半密度单位立方体|4|625/256|0|
|半密度单位立方体|8|43046721/16777216|0|
|半密度单位立方体|16|48661191875666868481/18446744073709551616|[1/2^209, 7/32768]|

最后一行的下界来自明确的完整十六维小盒，不能把它归一化成大接收区域。其每个横向边长、纵向边长和全维乘积都保留。十六维基础帽加新增帽的上界约为 2.638143，与 W=1/2 同时保留；不把小盒的单位体积占用量当作总体帽费用。

二维压力来源的 8 个停止块均有平均密度 1/2，参考质量为 1，保留好来源质量为 0。各膨胀帽体积的和为 9/2；实际并集体积为 25/8，重叠只收费一次。本例没有遗漏帽在接收计算域之外的体积。

## 坏块与真实来源

均匀模型的 Q 是单位立方体，平均密度 1/2；在兼容的平移循环二分格中，其直接父块只倍增一条边，平均密度为 1/4。更高祖先密度更低，故 Q 正是最大坏块。aspect=1，ell_Q=1。实际近标签在 L=16n 离开。因为 f<=1/2，所有真实硬平均 A_L f<=1/2；所以 (A_L f-1)_+^2 恒为零。这是原平均的逐点事实，不依赖空间或尺度离散化。

压力模型的根是 [-2,2]^2，实际平均密度 1/16。每个节点用真实来源与矩形的精确交体积计算质量，遇到 average>1/4 就停止。父块 average<=1/4，二分保证停止块 average<=1/2。来源面都是二进有理面；最大允许深度 12 足以把所有面切开。实际访问 55 个树节点，并验证坏质量与好质量之和为 1。每个来源在坏块上的限制进一步表示为均匀矩形，质量等于原来源密度乘实际交体积；相交部分的质量严格加回对应坏块质量。每条限制继承该坏块 ell_Q 和离开尺度 16n*ell_Q。本例 8 个块的 ell_Q 均为 1/2，但其内部实际来源仍有两种不同宽度。

## 全尺度区间证书

对均匀矩形来源，单坐标归一化捕获函数为

```text
q(L,t,e) = length([-e,e] intersection [t-L/2,t+L/2]) / (2e),
```

其中 t 是接收坐标到来源中心的绝对距离。对整个接收矩形，t_near 是最小可能距离，t_far 是最大可能距离。q 在 t 上不增；故用所有 t_far 的乘积给捕获质量下界，用所有 t_near 的乘积给上界。所有限制来源按其真实质量加权，不重复来源质量。

时间区间显式包含每一个标签离开尺度，以及相关捕获分段点。相邻区间间没有间隙；在一个区间内部活动标签固定。捕获质量随 L 不减，但平均值不必单调。程序使用两个独立有效的包络，然后取下界的最大值、上界的最小值。

第一种包络使用区间左端的最小捕获质量和右端的最大捕获质量。对常数 m，令 u=L^n，则

```text
integral_l^h (m/L^n-a)_+ dL/L
 = [m*(1/u0-1/u1)-a*log(u1/u0)]/n,
u0=l^n, u1=min(h^n,m/a),
```

若 u1<=u0，值为零。a=0 时不截断、没有对数项。因此不需要把 m/a 的 n 次根冒充精确有理数。捕获质量在 56 位二进格上向外舍入，其误差已经进入区间。

第二种包络直接包围坐标平均 q(L,t,e)/L。t<=e 时，该函数先恒定再不增；t>e 时先增加，达到全捕获点 L=2(t+e) 后下降。因此区间最小值在两个端点，最大值在两个端点或包含的全捕获点。不同坐标的极值不必发生在同一尺度；极值乘积依然是合法的统一上下界。把各来源乘积加权，得到整个区间统一平均值 v_lower、v_upper，再积分 (v-a)_+ times log(h/l)。这一步避免第一种包络在高维造成的人工尺度放大，并未假设平均本身单调。

比例网格固定为 9/8，所有捕获折点与标签离开点同时加入。网格是上、下包络的划分，不是把有限节点积分称作真实值。h_plain 的积分一直延伸到全部标签离开为止，后面的近标签占用量严格为零。h_a 另用实际总质量 W 推出 W/L^n<=1/6 的有理截止上界；截止以后的正部严格为零。完整积分中没有未支付尺度尾。

对数全部用整数和 Fraction 证明型计算。先按 2 的整数幂把参数归一到 [1,2]，再用 atanh 的 30 个正项；绝对参数不超过 1/3，剩余项统一上界是

```text
(2/61)*(1/3)^61/(1-1/9).
```

每次乘法、除法在 64 位二进格上分别向下和向上舍入，幂次乘 log(2) 按系数正负选择端点，最后向外舍入到 48 位。正部积分中的负对数系数同样正确交换端点。Python 任意精度整数避免溢出。仅 display_only 和运行时间用浮点数，浮点数不参加资格判断。

## 真正的全空间体积

每个半密度立方体来源、基础帽和占用量都对坐标反射及置换对称。若正绝对坐标分格的宽度是 w_j，计数为 k_j，则对应整个反射/置换轨道的体积恰为

```text
n! / product_j k_j! * product_j (2*w_j)^k_j.
```

所有 k_j 的和恰为 n；零坐标面是零测集。程序验证所有轨道体积之和为 (2R)^n，并验证基础帽内轨道之和为其真实立方体体积。完整 n 维宽度和全部正交象限已经计入，不是条件相位分布或低维代理测度。

基础帽面被加入每个坐标分格，故每个轨道不是整个位于基础帽内，就是整个位于其外。压力模型则把每个接收格按所有真实帽面继续切开，精确保留帽外片；基础帽实际并集用全局面安排计算，帽重叠只计一次。

空间域之外不需要设置未支付的零尾。来源支撑最大绝对坐标半径为 b，若 receiver maxnorm为r>b，任何捕获都要 L>=2(r-b)，因此

```text
h_a(x) <= h_plain(x) <= W/[n*(2(r-b))^n].
```

W<=1 且 R=b+1/2 就使域外值 <=1/n，所以严格超水平集在域外为空。这里仅证明超水平集为空，绝不声称 h_a 本身在域外为零。均匀模型 R=1，压力模型 R=5/2。全空间帽体积按基础帽的全空间体积加上域内新增集计算；不扣去基础帽位于计算域外的部分。

整个接收片若 h_a_lower>1/n 就是 IN；若 h_a_upper<=1/n 就是 OUT；其余整个片为 UNKNOWN。所有 UNKNOWN 体积进入上界，等号约定与严格超水平集一致。

## 最小保留结论与限制

八维的基础帽外占用量上确界由面中心的外侧极限控制。其 h_a 区间约为 [0.027549,0.034073]，严格小于 1/8；同一真实微盒的 h_plain 下界约为 0.317919，严格大于 1/8。因此本模型中阈值扣除确实改变了原占用帽，而非只改变公式名字。

十六维基础帽半边长 B=17/32。在点 (B,0,...,0)，h_a 区间约为 [0.068559,0.076748]。取 epsilon=1/(1024n)，真实盒

```text
[B,B+epsilon] times [-epsilon,epsilon]^(n-1)
```

的统一 h_a 下界约为 0.068419，严格大于 1/16。其体积为 epsilon*(2epsilon)^(n-1)=2^-209。该盒除零测边界面外位于基础帽外。完整空间包络却给新增集总体积不超过 7/32768。由此只能得出阈值占用量仍会给某些真实零超额能量点收费；不能推出一般帽费用增长，更不能把本轮有限维背景压力升级为未发表下界或原 Fnew 反例。

十六维粗轨道仍有 UNKNOWN，总可能体积为 7/32768；显式小盒下界是对其中一部分的额外证书，不代表所有粗轨道已分类。原一般弱型目标、一般 h_a 低阈值帽体积预算、原门控及全维参数族都没有在本程序中闭合。

## 复现与冻结

```text
python3 /Users/zhengzhihao/Desktop/T/output/centered_cube_round096_20261012/energy_probe.py
```

标准库、自包含，无旧轮导入，不操作 Git。最终实际运行 9.148151333 秒，输出 284080 字节；JSON 不保存波动的运行时间，可逐字节重放。压缩证书字段为 base85(zlib(compact JSON))，解码后的记录数、SHA256 和尺度记录字段顺序全部保存。保存的记录是真实区间与几何见证，不是蒙特卡洛样本。

代码 SHA256：`26ad1ee8504c8da470caa98e4fb8f96fc75209eeb8a8a606ab8bbb897d993256`。
结果 SHA256：`baf255ac0c5a5597a8c8c62b5a9dc7c445f308c3441e5b9d1c6dfe3e34b7afdc`。

The bounded nonlinear check identifies an obstruction to the specified unconditioned uniform-window probability bound. It does not determine the original coarse gate at first contact. Earlier hard-plus-smooth qualification remains valid; complete residual and general weak-type conclusions remain open.

Independent Astra review: general root weak-type closure remains OPEN. Exact statements and counterpressure were checked before completed proofs; all five theoretical MD/TeX modules were then read in full, with the qualifications below.

- The thresholded occupation persistence theorem and both weak-capacity comparison directions pass. For a fixed positive threshold parameter, the proposed capacity is quantitatively equivalent to the actual weak endpoint. It has not received a subpower bound.
- The source-depth truncation gives one source restriction for all scales, one common cap, and a valid energy bound proportional to the square of the retained deficit mass. Uniformly small deficit is unproved; its scalar criterion can lose spatial information.
- The original-gate posterior theorem passes after paying an additional full-window coarse branch. The original coarse predicate alone is selected-scale only. Near-anchor demand is paid separately. The resulting reference-cone allocation is valid, but its proved coefficient remains linear rather than supplying a general root improvement. Physical and localization/layer fees remain explicit.
- Near-Dirichlet localization and the quadratic-potential transfer pass. The bounded-source growth corollary required a substantive correction: the continuous potential must vanish at every point of the cap complement, not merely almost everywhere. Uniform quadratic control for every input and threshold remains unpaid. Primary-paper reading is attributed to the source author, not to this auditor.
- The private parent cap-rule certificate and private nonlinear interval certificate pass within their stated scopes. The latter concerns a fixed included node, not the original earliest-contact coarse predicate. Original residual qualification remains UNKNOWN. The sign-specific exponential-certificate obstruction does not exclude opposite-sign or conditional methods. No private recipe or quantified lower construction is public evidence here.
- Public numerical verification uses five actual source-dimension instances, 5446 histogram cells, and a separate 400 direct cells with 544 retained fragments. Whole-space cap bounds and unknown cells are retained. A positive-volume occupation charge for a zero-excess source is verified, but no growing cap fee follows. This audit reproduced the producer JSON byte exactly and independently verified one continuum occupation witness. It did not reconstruct producer receiver energy.

Independent replays also verified the parent certificate, private nonlinear certificate, and selected embedded exact programs. Replays are not new experiments; different native units are not summed. All-scope mathematical PASS does not assert the unresolved geometric budgets. The parent explanatory correction and alternative execution appendix are verified. Alternative's independent extracted replay matches all stable certificates: 61 scalar cases and five actual source models with twenty pointwise receiver profiles. Those profiles verify all-scale capture/persistence, not occupation or energy integration. No author-owned correction or execution receipt remains pending at this snapshot.

## Independent R96 mathematical audit

The complete contract and precise candidate claims were independently checked before author proofs. The general root-order centered-cube weak target remains unproved. Full Markdown and matching TeX reviews passed for the thresholded-persistence/capacity equivalence, fixed-depth source debit, paid actual-posterior refinement and corrected boundary-strip/obstacle transfers. The bounded-density quadratic corollary required an actual hypothesis repair: continuous potentials must vanish at every complement point, rather than merely almost everywhere. The fixed-depth debit remains conditional on its actual residual mass; the thresholded low-level capacity is comparable to the original weak maximal bound and gives no independent volume payment. The broad reference-cone conversion of the posterior profile still pays linear dimension cost.

Frozen private nonlinear code and report passed full review and one isolated replay, with every mathematical and descriptive field equal after excluding only the two timing keys. Its certificate concerns an included node and the stated unconditioned probability method; original coarse qualification at first contact remains UNKNOWN. Public occupation code and final report passed complete review and one copied-code replay with the entire JSON byte-identical and no exclusions. Producer replay units are separate from independent reconstruction units.

The public standalone guard independently rebuilds one new asymmetric actual compact obstacle/source weighted-gradient integral and one exact scalar persistence certificate. It imports no producer, reconstructs zero producer occupation cells and zero cube receiver-energy certificates, and contains no private lower recipe. Author arithmetic, reviewed numerical enclosures, independent guard reconstructions and general proofs have distinct scopes. Source-uniform affordable potential/capacity or joint original-gate geometry remains unpaid. Parent P4’s private prose correction has passed exact delta review. The recovered alternative appendix has now passed full incremental review and one independent extracted replay. No author completion remains pending; the four final integration range files have passed scope review, which is not a new experiment. Git/archive completion remains parent-owned.

## 数值、审读和实际复现范围

本轮没有凭有限维计算判定一般指数。公开占用计算给整个连续接收单元上的全尺度上下包络和全空间超水平集体积；PRIVATE计算的配方、程序及未公开量化下界不进入归档。所有复核均为相同实验的重放，不计为新增来源或新实验。

|组件|作者实际执行|独立审核执行|主代理隔离执行|
|---|---|---|---|
|公开阈值占用|最终9.148151333秒；5个来源—维数组合，5446全维轨道、另400直接格及544片|两审全文和逐字节重放；Sol内部8.248913500秒、Astra内部8.322085917秒|8.677466834秒，284080字节结果完全相同，无删除字段|
|PRIVATE非线性原核|同一来源和接收律，两次阶段包络；44.481820375秒|Astra44.172549542秒、Sol44.868685541秒，数学及描述字段相同，只排除两种时间键|46.927981750秒；11项只读旧依赖前后哈希相同，只排除runtime_seconds及runtime_seconds_diagnostic|
|PRIVATE父代理帽规则|30个真实来源律，600实际点尺度捕获、315祖先平均、10帽几何、12逐轴并集枚举；1.017604792秒|两审完整MD/TeX/程序；Astra内部0.993438083秒、Sol内部0.994673209秒重放相同，仅排除顶层时间|1.128170917秒，相同数学和描述JSON，仅排除顶层runtime_seconds|
|来源深度截取|33不同连续来源，三阶段6/12/15；两次作者执行不计66个新来源，33同源标签拆分|两审全文；Astra独立嵌入重放；Sol未声称执行该程序|0.440757916秒，33条实际CDF有理包络结果与记录一致，仅排除seconds|
|原门后验|7维度，116精确/外向断言，三阶段32/32/52；2.376047209秒|两审全文；Astra内部2.314934125秒实际重放，Sol未执行这116项|2.378645334秒，116项通过；这些不是完整Fplus合格样本|
|势函数来源|21个合格模型和7个拒绝正性检查，91 EXACT；另8 PRIVATE浓缩模型48 EXACT|两审全文；Astra分别0.033712042和0.014786042秒实际重放；Sol未重跑作者算术|公开0.033588625秒与私人0.014556208秒分别通过；无接收超额能量积分|
|阈值占用策略审计|恢复作者0.032560916秒；61标量案例、5实际来源、20接收点、128完整窗口、44仿射片、70正N窗、23正超额起点|数学正文全文已双审；Astra新增程序/收据完整增量与重放通过，外部0.052378042秒；Sol完整增量及一次重放通过，外部0.047260083秒，三阶段计时和0.029019082秒；均无h/能量/全空间体积重建|0.046146834秒，三阶段证书及汇总SHA一致；无占用积分/能量/全空间体积重建|
|独立公开守卫|Sol独立新程序，1个实际非对称紧支撑源的连续加权梯度积分及1个标量持续常数|Astra核读算法，未声称执行守卫；Sol最终独立复制运行内部0.000665208秒|0.015939041秒，exit0、stderr空|

独立公开守卫不导入生产程序，重建生产占用单元数为0、立方体接收能量数为0、保存结果算术检查数为0。其新实际加权梯度积分为132334348/3828825，对照预算768；普通梯度积分6029312/1576575。它验证的是这一实际势输入和标量常数，不能替代一般帽预算。Astra另以连续尺度解析积分独立验证公开16维占用正体积见证；这也不是一般过费或弱型下界。

公开中性来源中，n=2/4/8与两尺度压力例新增阈值占用帽为空。n=16的实际超额在全空间全尺度恒零，但新增占用帽体积有严格区间[2^-209,7/32768]；除零测边界外的完整小盒给下界，所有未分类体积保留在上界。这只证实替代占用仍可能过多删点，不证明帽总费用增长。

三个实质修正保留：原粗门是选定尺度条件，全窗口细化必须另付Tsoft/alpha；势增长必须连续代表逐点零接触；父反例截面补偿说明已修正左右端点，公式和程序始终一致。作者程序的早期包络改进和文字修订没有重复计作新输入。流中断前尚未执行的工作没有捏造收据。

主代理实际读完五个MD的数学论证与PRIVATE关键证明、三项核心程序、已执行嵌入代码、公开守卫及数值报告；对应TeX完整双审，主代理做结构静态核验。来源作者直接读Figalli原文§§2–5有关证明；主代理和两审没有据此宣称自己重新通读。更新64skill中针对性的实际读取与条目SHA快照分开，快照不等于全部技能逐条数学验收。

公开复现：解压research.zip后运行python3 energy_probe.py；结果与energy_results.json逐字节对照。proof.md的S5公开代码块可单独运行91项有理检查；在“独立公开审核程序”节保存其代码为audit_guard.py并运行。只有这一指定节的块是独立守卫，不把所有Python块混同。inventory.json列成员SHA、实际收据和完整范围。PRIVATE嵌入与原核依赖不在公开包。


## 独立公开审核程序

```python
#!/usr/bin/env python3
"""Independent R96 exact guard; standard library, no producer imports.
One new actual Dirichlet integral, one scalar persistence certificate.
No receiver-energy reconstruction, private recipe, or generic assertion target.
"""
from fractions import Fraction as F
from math import comb
import json
from time import perf_counter


def multiply(a, b):
    out = [F(0)] * (len(a) + len(b) - 1)
    for i, x in enumerate(a):
        for j, y in enumerate(b):
            out[i+j] += x*y
    return out


def power(a, k):
    out = [F(1)]
    for _ in range(k):
        out = multiply(out, a)
    return out


def differentiate(a):
    return [F(i)*a[i] for i in range(1, len(a))]


def integrate(a, lo=F(-1), hi=F(1)):
    return sum((v*(hi**(i+1)-lo**(i+1))/F(i+1)
                for i,v in enumerate(a)), F(0))


def triangle_product(px, py, y_below_x):
    # Exact continuum integral over one half of the positive unit square.
    return sum((a*b/F((j+1 if y_below_x else i+1)*(i+j+2))
                for i,a in enumerate(px) for j,b in enumerate(py)), F(0))


def actual_dirichlet():
    # u=(1-x²)^2(1-y²)^3 on (-1,1)^2, zero outside.
    # Both normal first derivatives vanish: no boundary Laplacian charge.
    z = [F(1), F(0), F(-1)]
    p = power(z, 2); q = power(z, 3)
    ddp = differentiate(differentiate(p))
    ddq = differentiate(differentiate(q))
    assert sum(differentiate(p)) == sum(differentiate(q)) == 0
    assert integrate(ddp) == integrate(ddq) == 0
    kappa=F(16); volume=F(4); W=kappa*volume; K=F(1,4)
    # p''=-4+12x²<=8. q''=-6+36y²-30y⁴<=24/5.
    # Each other factor lies in [0,1], so Delta u<=8+24/5<13.
    # A safe actual density bound is f=kappa-Delta u>=3.
    assert kappa-(8+F(24,5)) > 3
    mass=kappa*volume-integrate(ddp)*integrate(q)-integrate(p)*integrate(ddq)
    assert mass == W
    # d_inf=1-max(|x|,|y|); u<=4d_inf²=K*kappa*d_inf².
    # Divide the gradient-square by the appropriate distance BEFORE expanding.
    plus=[F(1),F(1)]; minus=[F(1),F(-1)]
    x2=[F(0),F(0),F(1)]
    ax=multiply([16*v for v in x2],power(plus,2))
    ay=power(z,6)
    bx=multiply(power(minus,2),power(plus,4))
    by=multiply([36*v for v in x2],power(z,4))
    cx=multiply([16*v for v in x2],power(z,2))
    cy=multiply(power(minus,4),power(plus,6))
    dx=power(z,4)
    dy=multiply([36*v for v in x2],multiply(power(minus,2),power(plus,4)))
    I=4*(triangle_product(ax,ay,True)+triangle_product(bx,by,True)
         +triangle_product(cx,cy,False)+triangle_product(dx,dy,False))
    budget=(2*K+4*K*K)*kappa*W
    assert 0<I<=budget
    # Independent ordinary gradient integral from separated variables.
    ordinary=(integrate(multiply(differentiate(p),differentiate(p)))*integrate(multiply(q,q))
              +integrate(multiply(p,p))*integrate(multiply(differentiate(q),differentiate(q))))
    assert ordinary<=I
    return {'actual_source_laws':1,'actual_continuum_weighted_gradient_integrals':1,
            'dimension':2,'actual_cap_volume':str(volume),'actual_source_mass':str(W),
            'kappa':str(kappa),'quadratic_K':str(K),'weighted_integral':str(I),
            'ordinary_gradient_integral':str(ordinary),'weighted_budget':str(budget),
            'scope':'new asymmetric compact obstacle input; no cube receiver-energy integration'}


def scalar_persistence():
    # Exact atanh expansion of log2, with strict outward positive remainder.
    z=F(1,3); terms=12
    lo=2*sum((z**(2*j+1)/F(2*j+1) for j in range(terms)),F(0))
    hi=lo+2*z**(2*terms+1)/((2*terms+1)*(1-z*z))
    assert F(2,3)<lo<hi<F(3,4)
    # The global G_n>=3/4(v-1/3)+ proof reduces to G_2:
    # on t in[2,4], derivative of t/4+1/2-logt is <=0;
    # beyond4 the difference is constant, at least (3/2-log4)/6.
    margin=(F(3,2)-2*hi)/6
    assert margin>0
    theta_lo=(1-hi)/6; theta_hi=(1-lo)/6
    assert 0<theta_lo<theta_hi
    return {'scalar_certificates':1,'log2_interval':[str(lo),str(hi)],
            'G_coefficient':'3/4','minimum_G2_margin_lower':str(margin),
            'sharp_capacity_level_interval':[str(theta_lo),str(theta_hi)],
            'scope':'exact scalar persistence constant, not a source or capacity theorem'}


def main():
    started=perf_counter()
    out={'PASS':True,'dirichlet':actual_dirichlet(),'persistence':scalar_persistence(),
         'producer_receiver_energy_reconstructions':0,'saved_result_arithmetic_checks':0,
         'private_recipes':0,'producer_imports':0}
    out['runtime_seconds']=perf_counter()-started
    print(json.dumps(out,indent=2))


if __name__=='__main__':
    main()
```
