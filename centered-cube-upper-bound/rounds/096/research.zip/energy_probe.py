"""R96 neutral genuine-L1 thresholded occupation: all scales and true dx.
No private recipe, Fnew assertion, sampling, or dimension fit.
"""
from fractions import Fraction as F
from functools import lru_cache
from itertools import product
from math import prod, factorial
from pathlib import Path
import json,time,hashlib,zlib,base64

D=1<<64
OUT=1<<48
A=F(1,6)
def fl(q):return q.numerator//q.denominator
def ce(q):return -fl(-q)
def down(q,d=OUT):return F(fl(q*d),d)
def up(q,d=OUT):return F(ce(q*d),d)
def iv(l,u):
    assert 0<=l<=u
    return {'lower':str(l),'upper':str(u),'display_only':[float(l),float(u)]}

def log_unit(q):
    assert 1<=q<=2
    t=(q-1)/(q+1);tl=fl(t*D);tu=ce(t*D)
    vl=tl*tl//D;vu=(tu*tu+D-1)//D
    pl=tl;pu=tu;sl=su=0
    for j in range(30):
        sl+=2*pl//(2*j+1);su+=(2*pu+2*j)//(2*j+1)
        pl=pl*vl//D;pu=(pu*vu+D-1)//D
    tail=ce(D*F(2,61)*F(1,3)**61/F(8,9))
    return F(sl,D),F(su+tail,D)
L2=log_unit(F(2))
@lru_cache(None)
def logs(q):
    assert q>0
    k=q.numerator.bit_length()-q.denominator.bit_length();p=F(2)**k
    z=q/p
    if z<1:k-=1;z*=2
    if z>=2:k+=1;z/=2
    l,u=log_unit(z)
    if k>=0:l+=k*L2[0];u+=k*L2[1]
    else:l+=k*L2[1];u+=k*L2[0]
    return down(l),up(u)

@lru_cache(None)
def primitive(n,m,lo,hi,a):
    """Exact integral (m/L^n-a)+, with rational u=L^n cutoff."""
    assert 0<lo<hi and m>=0 and a>=0
    u0=lo**n;u1=hi**n
    if a:u1=min(u1,m/a)
    if m==0 or u1<=u0:return F(0),F(0)
    r=m*(1/u0-1/u1)/n
    if not a:return down(r),up(r)
    ll,lu=logs(u1/u0)
    return max(F(0),down(r-a*lu/n)),max(F(0),up(r-a*ll/n))

def volume(b):return prod((u-l for l,u in b),start=F(1))
def meet(a,b):
    x=tuple((max(l,s),min(u,t)) for (l,u),(s,t) in zip(a,b))
    return None if any(l>=u for l,u in x) else x

def contains(x,b):return all(l<=v<=u for v,(l,u) in zip(x,b))
def union_atoms(caps):
    n=len(caps[0]);edges=[sorted({z for b in caps for z in b[j]}) for j in range(n)]
    out=[]
    for ids in product(*(range(len(e)-1) for e in edges)):
        b=tuple((edges[j][i],edges[j][i+1]) for j,i in enumerate(ids))
        if any(contains(tuple((l+u)/2 for l,u in b),c) for c in caps):out.append(b)
    return out

def fragments(b,caps):
    ed=[sorted({l,u}|{v for c in caps for v in c[j] if l<v<u}) for j,(l,u) in enumerate(b)]
    out=[]
    for ids in product(*(range(len(e)-1) for e in ed)):
        s=tuple((ed[j][i],ed[j][i+1]) for j,i in enumerate(ids))
        if not any(contains(tuple((l+u)/2 for l,u in s),c) for c in caps):out.append(s)
    return out

@lru_cache(None)
def qfactor(L,t,e):
    return max(F(0),min(e,t+L/2)-max(-e,t-L/2))/(2*e)

@lru_cache(None)
def ratio_bounds(lo,hi,t,e):
    values=[qfactor(lo,t,e)/lo,qfactor(hi,t,e)/hi]
    peak=2*(t+e)
    if lo<peak<hi:values.append(qfactor(peak,t,e)/peak)
    return min(values[:2]),max(values)

def distances(b,c):
    return tuple(max(F(0),l-z,z-u) for (l,u),z in zip(b,c)),tuple(max(abs(l-z),abs(u-z)) for (l,u),z in zip(b,c))

def scale_grid(start,end,breaks=()):
    assert 0<start<end
    p={start,end}|{b for b in breaks if start<b<end}
    x=start
    while x<end:
        x=min(end,x*F(9,8));p.add(x)
    return tuple(sorted(p))

def capture(parts,ds,L,active):
    return sum((parts[i][2]*prod((qfactor(L,t,e) for t,e in zip(ds[i],parts[i][1])),start=F(1)) for i in active),F(0))

def potential_box(n,b,parts,threshold=A,save=False):
    """parts=(center, vector halfwidth, restriction mass,16n ell departure)."""
    near=[];far=[];start=None;breaks=[]
    for c,es,m,dep in parts:
        ne,fa=distances(b,c);near.append(ne);far.append(fa)
        r=2*max(max(t-e,F(0)) for t,e in zip(ne,es))
        if start is None or r<start:start=r
        breaks.append(dep)
        for ts in (ne,fa):
            for t,e in zip(ts,es):breaks.extend((2*max(F(0),t-e),2*(t+e)))
    if start==0:return None
    W=sum(p[2] for p in parts)
    end=max(p[3] for p in parts)
    if threshold:
        # Rational upper root: above this scale W/L^n<=threshold.
        cut=F(1)
        while W>threshold*cut**n:cut+=1
        end=min(end,cut)
    if start>=end:return (F(0),F(0),[]) if save else (F(0),F(0))
    grid=scale_grid(start,end,breaks);total_l=total_u=F(0);records=[]
    for lo,hi in zip(grid,grid[1:]):
        active=tuple(i for i,p in enumerate(parts) if (lo+hi)/2<p[3])
        ml=capture(parts,far,lo,active);mu=capture(parts,near,hi,active)
        # Round mass outwards; final error is included, not treated as exact.
        ml=down(ml,1<<56);mu=up(mu,1<<56)
        ll=primitive(n,ml,lo,hi,threshold)[0];uu=primitive(n,mu,lo,hi,threshold)[1]
        avl=sum((parts[i][2]*prod((ratio_bounds(lo,hi,t,e)[0] for t,e in zip(far[i],parts[i][1])),start=F(1)) for i in active),F(0))
        avu=sum((parts[i][2]*prod((ratio_bounds(lo,hi,t,e)[1] for t,e in zip(near[i],parts[i][1])),start=F(1)) for i in active),F(0))
        gl,gu=logs(hi/lo)
        ll=max(ll,down(max(F(0),avl-threshold)*gl))
        uu=min(uu,up(max(F(0),avu-threshold)*gu))
        total_l+=ll;total_u+=uu
        if save:records.append([str(lo),str(hi),list(active),str(ml),str(mu),str(ll),str(uu),str(avl),str(avu)])
    assert total_l<=total_u
    return (total_l,total_u,records) if save else (total_l,total_u)

def codec(rows):
    p=json.dumps(rows,separators=(',',':')).encode()
    return {'codec':'base85 zlib compact JSON','payload':base64.b85encode(zlib.compress(p,9)).decode(),'sha256':hashlib.sha256(p).hexdigest(),'record_count':len(rows)}

def compositions(n,k):
    if k==1:yield(n,);return
    for i in range(n+1):
        for tail in compositions(n-i,k-1):yield(i,)+tail

def uniform_case(n,stage):
    B=(1+F(1,n))/2;R=F(1);W=F(1,2)
    parts=((tuple(F(0) for _ in range(n)),tuple(F(1,2) for _ in range(n)),W,F(16*n)),)
    if n==2:edges=sorted({F(i,8) for i in range(9)}|{B})
    else:edges=sorted({F(0),F(1,4),F(1,2),B,F(3,4),F(1)})
    bins=tuple(zip(edges,edges[1:]));rows=[];inside=possible=total=F(0);base=F(0);native=0
    # Store genuinely n-dimensional sign/permutation orbits, not sampled points.
    for ks in compositions(n,len(bins)):
        v=F(factorial(n),prod(factorial(k) for k in ks))*prod(((2*(u-l))**k for (l,u),k in zip(bins,ks)),start=F(1))
        total+=v;native+=1
        if all(k==0 or u<=B for k,(l,u) in zip(ks,bins)):
            base+=v;continue
        box=tuple(x for x,k in zip(bins,ks) for _ in range(k))
        h=potential_box(n,box,parts)
        assert h is not None
        l,u=h;state='IN' if l>F(1,n) else 'OUT' if u<=F(1,n) else 'UNKNOWN'
        if state=='IN':inside+=v
        if state!='OUT':possible+=v
        rows.append([list(ks),str(v),str(l),str(u),state])
    assert total==(2*R)**n and base==(2*B)**n
    point=tuple([(B,B)]+[(F(0),F(0))]*(n-1))
    face=potential_box(n,point,parts,save=True);plain=potential_box(n,point,parts,F(0),save=True)
    eps=F(1,1024*n);witness=tuple([(B,B+eps)]+[(-eps,eps)]*(n-1))
    wh=potential_box(n,witness,parts,save=True)
    whplain=potential_box(n,witness,parts,F(0),save=True)
    lower=inside
    if wh[0]>F(1,n):lower=max(lower,volume(witness))
    # Monotonicity in each absolute coordinate: face is the exterior maximum.
    if face[1]<=F(1,n):assert inside==0;possible=F(0)
    f_record={'whole_cartesian_box':[[str(l),str(u)] for l,u in witness], 'actual_dx_volume':str(volume(witness)), 'h_a':iv(wh[0],wh[1]),'strict_inside_level':wh[0]>F(1,n),'scale_segments':codec(wh[2]),'h_plain':iv(whplain[0],whplain[1]),'plain_strict_inside_level':whplain[0]>F(1,n),'plain_scale_segments':codec(whplain[2])}
    return {'stage':stage,'name':'neutral_half_density_cube','dimension':n,'source_density':'1/2','source_box':[['-1/2','1/2']]*n,'W':'1/2','kappa':'1','a':'1/6','T':'1/'+str(n),'bad_Q_average':'1/2','bad_Q_parent_average':'1/4','compatible_cyclic_grid':'translated dyadic grid with unit source cube as cell; immediate cyclic parent doubles one side, further ancestors dilute, so first-bad qualification is exact','label_departure':str(16*n),'actual_excess_all_space_all_scale':'0','base_cap_volume':str(base),'superlevel_domain_radius':'1','outside_domain_proof':'h_a<=h<=W/(n*[2(dist to source)]^n)<=1/n; only superlevel, not h_a, is absent','native_histogram_cells':native,'retained_histogram_orbits':len(rows),'bins':[[str(l),str(u)] for l,u in bins],'histogram_witness':codec(rows),'added_level_global_volume':iv(lower,possible),'base_union_level_global_volume':iv(base+lower,base+possible),'unknown_histogram_volume':str(possible-inside),'face_h_a':iv(face[0],face[1]),'face_h_plain':iv(plain[0],plain[1]),'face_h_a_scale_segments':codec(face[2]),'face_h_plain_scale_segments':codec(plain[2]),'positive_whole_box_witness':f_record,'thresholded_removed_every_exterior_level_point':face[1]<=F(1,n),'not_a_general_dimension_bound':True}

def source_mass(b,sources):
    total=F(0)
    for c,e,m in sources:
        s=tuple((z-e,z+e) for z in c);x=meet(b,s)
        if x:total+=m*volume(x)/(2*e)**len(c)
    return total

def cyclic(sources):
    n=len(sources[0][0]);W=sum(m for c,e,m in sources);b=max(abs(z)+e for c,e,m in sources for z in c);r=F(1)
    while r<b or W/(2*r)**n>F(1,4):r*=2
    root=tuple((-r,r) for _ in range(n));den=max(v.denominator for c,e,m in sources for z in c for v in (z-e,z+e))
    assert den&(den-1)==0
    maxdepth=n*(int(2*r).bit_length()-1+den.bit_length()-1)
    stack=[(root,0)];bad=[];good=F(0);visited=0
    while stack:
        box,d=stack.pop();visited+=1;m=source_mass(box,sources)
        if not m:continue
        avg=m/volume(box)
        if avg>F(1,4):assert avg<=F(1,2);bad.append((box,m,d));continue
        if d==maxdepth:good+=m;continue
        j=d%n;mid=sum(box[j])/2;l=list(box);u=list(box);l[j]=(box[j][0],mid);u[j]=(mid,box[j][1]);stack.extend(((tuple(u),d+1),(tuple(l),d+1)))
    assert sum(m for b,m,d in bad)+good==W
    parts=[];caps=[];records=[]
    for box,m,d in bad:
        ell=max(u-l for l,u in box);assert ell<=2*min(u-l for l,u in box)
        cap=tuple(((l+u)/2-(1+F(1,n))*(u-l)/2,(l+u)/2+(1+F(1,n))*(u-l)/2) for l,u in box);caps.append(cap)
        records.append({'Q':[[str(l),str(u)] for l,u in box],'mass':str(m),'average':str(m/volume(box)),'ell':str(ell),'depth':d,'cap':[[str(l),str(u)] for l,u in cap]})
        assigned=F(0)
        for c,e,w in sources:
            x=meet(box,tuple((z-e,z+e) for z in c))
            if x:
                mw=w*volume(x)/(2*e)**n;assigned+=mw
                parts.append((tuple((l+u)/2 for l,u in x),tuple((u-l)/2 for l,u in x),mw,16*n*ell))
        assert assigned==m
    assert sum(p[2] for p in parts)==W-good
    return parts,caps,records,{'root':[[str(l),str(u)] for l,u in root],'visited_cells':visited,'bad_count':len(bad),'bad_mass':str(W-good),'good_mass':str(good),'maximum_depth':maxdepth}

def stress_case():
    n=2;sources=(((F(0),F(0)),F(1,16),F(1,2)),((F(3,2),F(0)),F(1,2),F(1,2)))
    parts,caps,bad,meta=cyclic(sources);assert meta['good_mass']=='0'
    atoms=union_atoms(caps);base=sum((volume(c) for c in atoms),F(0));R=F(5,2);mesh=4
    inner=outer=F(0);base_in=F(0);rows=[];native=0;frags=0
    for ids in product(range(-10,10),repeat=2):
        b=tuple((F(i,mesh),F(i+1,mesh)) for i in ids);native+=1
        subs=fragments(b,caps);v=sum((volume(s) for s in subs),F(0));base_in+=volume(b)-v
        for s in subs:
            frags+=1;h=potential_box(n,s,parts);assert h is not None
            l,u=h;state='IN' if l>F(1,n) else 'OUT' if u<=F(1,n) else 'UNKNOWN'
            if state=='IN':inner+=volume(s)
            if state!='OUT':outer+=volume(s)
            rows.append([[[str(l),str(u)] for l,u in s],str(l),str(u),state])
    assert base_in<=base
    return {'stage':'stress','name':'two_scale_actual_cyclic_restrictions','dimension':2,'sources':[{'center':[str(v) for v in c],'halfwidth':str(e),'mass':str(m)} for c,e,m in sources],'W':'1','kappa':'1','a':'1/6','T':'1/2','cyclic':meta,'bad_records':bad,'restriction_pieces':[{'center':[str(z) for z in c],'halfwidths':[str(v) for v in e],'mass':str(m),'departure':str(d)} for c,e,m,d in parts],'base_global_union_volume':str(base),'base_volume_in_receiver_domain':str(base_in),'individual_cap_volume_sum':str(sum(volume(c) for c in caps)),'native_receiver_cells':native,'retained_face_fragments':frags,'receiver_domain_radius':str(R),'global_superlevel_added_volume':iv(inner,outer),'base_union_level_global_volume':iv(base+inner,base+outer),'unknown_volume':str(outer-inner),'receiver_witness':codec(rows),'outside_domain_proof':'support maxradius2,W1 gives h_a<=1/[2*(2*(2.5-2))^2]=1/2; strict superlevel absent','actual_occupation_not_energy_or_RAW':True}

def build():
    rows=[uniform_case(2,'pilot'),stress_case()]
    for n in (4,8,16):rows.append(uniform_case(n,'expanded'))
    return {'round':96,'public_neutral_only':True,'scope':'actual positive L1 sources; full continuous receiver cells; all scales; no Fnew qualification/general weak bound','arithmetic':'Fraction with directed 64-bit atanh/log and outward 48-bit primitive bounds; captured masses rounded outward at56bits','fixed_scale_ratio':'9/8','interval_tightening':'coordinate q(L,t,e)/L minimum endpoints, maximum endpoints or L=2(t+e); bounds constant average, no average-monotonicity assumption','a':'1/6','level':'kappa/n','cases':rows,'counts':{'actual_source_dimension_instances':5,'uniform_density_instances':4,'two_scale_cyclic_instances':1,'histogram_native_cells':sum(x.get('native_histogram_cells',0) for x in rows),'stress_native_cells':400},'scale_segment_schema':['Llo','Lhi','active restriction indices','lower captured mass rounded56','upper captured mass rounded56','integral lower','integral upper','lower uniform average','upper uniform average'],'gaps':'Exact global level volume is enclosed, not assumed; UNKNOWN volume is retained. No ordinary RAW integral is computed.'}
if __name__=='__main__':
    t=time.perf_counter();data=build();path=Path(__file__).with_name('energy_results.json');path.write_text(json.dumps(data,ensure_ascii=False,sort_keys=True,indent=2)+'\n');print(json.dumps({'elapsed_seconds':time.perf_counter()-t,'cases':len(data['cases']),'bytes':path.stat().st_size}))
