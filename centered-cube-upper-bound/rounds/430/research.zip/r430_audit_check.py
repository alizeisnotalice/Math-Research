"""R430 reviewer reproduction of already-executed bounded checks.
Finite risk trees are not native/history fixtures. The annular window model
is native center matching at a fixed source, not an original full flow.
The weak/exact risk checks reuse the same 144 paired tree profiles.
"""
from fractions import Fraction as F
from math import factorial
from itertools import product

def far_paths(depth,seed):
    paths=[(F(1),F(0),0)]
    for j in range(depth):
        out=[]
        for mass,H,state in paths:
            p=[F(0),F(1,4),F(1,2),F(3,4),F(1)][(seed+j+state)%5]
            for bit,q in [(0,F(1,3)),(1,F(2,3))]:
                if p<1:out.append((mass*(1-p)*q,H+p,2*state+bit))
        paths=out
    return paths
laws=[far_paths(N,seed) for N in [2,3,4] for seed in range(4)]
checks=0
for P,Q in product(laws,laws):
    for L in [F(0),F(1,2),F(1),F(2),F(3)]:
        lower=sum(((-L)**k/F(factorial(k)) for k in range(82)),F(0))
        paid=sum(p*q for p,H,_ in P for q,H2,_ in Q if H+H2>=L)
        assert paid<=lower
        checks+=1
print('PASS',checks,'exact two-chain all-far/high-predictable-risk tail comparisons')

def loglo(x):
    k=0
    while x>=2:x/=2;k+=1
    def a(y):
        t=(y-1)/(y+1)
        return 2*sum((t**(2*j+1)/F(2*j+1) for j in range(80)),F(0))
    return k*a(F(2))+a(x)
windows=0
for n,N in product([1,4,16],[4,8]):
    levels=[(1+F(i,N))**n for i in range(N+1)]
    vols=[levels[0]]+[levels[i]-levels[i-1] for i in range(1,N+1)]
    rho=[v/m for v,m in zip(vols,levels)]
    for i in range(N+1):
        for j in range(i,N+1):
            cap=sum(rho[i:j+1]);assert cap<=1+loglo(levels[j]/levels[i]);windows+=1
print('PASS',windows,'native matched annular-field closed mass-window capacity checks')

def law(depth,seed):
    paths=[(F(1),F(1),F(1),0)]
    for j in range(depth):
        out=[]
        for orig,aux,lik,state in paths:
            p=[F(0),F(1,4),F(1,2),F(3,4),F(1)][(seed+j+state)%5]
            if p==1:continue
            for bit,q in [(0,F(1,3)),(1,F(2,3))]:
                out.append((orig*(1-p)*q,aux*q,lik*(1-p),2*state+bit))
        paths=out
    assert sum(a for _,a,_,_ in paths)<=1
    assert all(o==a*l for o,a,l,_ in paths)
    return paths
laws=[law(N,seed) for N in [2,3,4] for seed in range(4)]
count=0
for P,Q in product(laws,laws):
    for t in [F(1,16),F(1,8),F(1,4),F(1,2),F(3,4)]:
        paid=sum(o*o2 for o,a,l,_ in P for o2,a2,l2,_ in Q if l*l2<=t)
        assert paid<=t;count+=1
print('PASS',count,'exact original/auxiliary path-likelihood and low-product union configurations')
print('Finite predictable-risk trees and native pointwise window diagnostics only; no original full-history instance or general closure.')
