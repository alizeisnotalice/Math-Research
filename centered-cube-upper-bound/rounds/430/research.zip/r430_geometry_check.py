from fractions import Fraction as F

def far_paths(masses, rho, K, h, start, seed):
    """Exact original and auxiliary sublaws, with fixed source at every step."""
    past = [[u for u, m in enumerate(masses) if m < mv/K]
            for mv in masses]
    Z = [sum((rho[u] for u in us), F(0)) for us in past]
    assert Z[start] > h
    answer = []
    killed = [0]
    def walk(v, j, orig, aux, likelihood, hit_sum, path):
        if Z[v] <= h:
            assert orig == aux*likelihood
            assert 0 < likelihood <= 1
            assert likelihood*(1+hit_sum) <= 1
            answer.append((orig, aux, likelihood, tuple(path)))
            return
        near = (set(past[v]) if seed == -1 else
                {u for u in past[v] if (u+2*j+seed) % 5 < seed % 4})
        p = sum((rho[u] for u in near), F(0))/Z[v]
        if p == 1:
            killed[0] += 1
            return
        for u in past[v]:
            if u not in near:
                transition = rho[u]/Z[v]
                walk(u, j+1, orig*transition,
                     aux*transition/(1-p), likelihood*(1-p),
                     hit_sum+p, path+[u])
    walk(start, 0, F(1), F(1), F(1), F(0), [start])
    assert sum((p[1] for p in answer), F(0)) <= 1
    assert sum((p[0]/p[2] for p in answer), F(0)) <= 1
    return answer, killed[0]

def joint_check(left, right, salt):
    counts = 0
    positive = 0
    for threshold in [F(1,8), F(1,4), F(1,2), F(3,4)]:
        paid = F(0)
        original_total = F(0)
        remaining = F(0)
        for i, x in enumerate(left):
            for j, z in enumerate(right):
                # An arbitrary full-future joint mark; not assumed to factor.
                mark = F((3*i+2*j+salt) % 7, 6)
                original = x[0]*z[0]*mark
                likelihood = x[2]*z[2]
                original_total += original
                if likelihood <= threshold:
                    paid += original
                else:
                    remaining += original
        assert paid+remaining == original_total
        assert paid <= threshold
        counts += 1
        positive += int(paid > 0)
    return counts, positive

# Stage 1: strict-mass prefix laws, including zero hazard and p=1 killing.
models = pairs = positive = killed = 0
for seed in range(12):
    masses = [F(2**i) for i in range(7)]
    rho = [F(1+(i+seed) % 4, 3) for i in range(7)]
    x, a = far_paths(masses, rho, F(2), F(1,3), 6, seed)
    z, b = far_paths(masses, rho[::-1], F(2), F(1,3), 6, seed+1)
    c, p = joint_check(x, z, seed)
    models += 1
    pairs += c
    positive += p
    killed += a+b
# An explicit all-near transition certifies the p=1 branch separately.
empty, killed_one = far_paths(masses, rho, F(2), F(1,3), 6, -1)
assert not empty and killed_one == 1
killed += killed_one
assert positive > 0 and killed > 0
print("Stage 1 PASS:", models, "joint prefix models;", pairs,
      "threshold checks;", positive, "positive paid checks;", killed, "p=1 stops")

# Stage 2: real Lebesgue center intervals, full f=1_[-4,4], q=1.
# Parent side 2, center A in [-.005,.005]; source windows near +/- .7.
# Initial side 1.8, center near +/-1.35. Terminal side 1 has two
# actual center intervals near +/-.35 and +/-1.05 (near/far respectively).
# All groups are disjoint. Proper K=1.5 prefix contains exactly the
# corresponding two terminal intervals; children have Z=0.
native = 0
for near_length in [F(1,50), F(1,25), F(3,50)]:
    for far_length in [F(1,50), F(1,20), F(2,25)]:
        assert F(9,5)/F(3,2) > 1
        assert F(7,20)+near_length/2+F(1,200) < F(3,5)
        assert F(21,20)-far_length/2-F(1,200) > F(3,5)
        assert abs(F(7,10)-F(7,20))+near_length/2 < F(1,2)
        assert abs(F(21,20)-F(7,10))+far_length/2 < F(1,2)
        Z = near_length+far_length  # m_terminal=1, so actual rho=du
        assert Z > F(1,1000)
        p = near_length/Z
        # Opposite source has the same exact actual center construction.
        original_far = (far_length/Z)**2
        likelihood = (1-p)**2
        assert original_far == likelihood > 0
        for threshold in [F(1,4), F(1,2), F(3,4)]:
            assert (original_far if likelihood <= threshold else 0) <= threshold
        native += 1
print("Stage 2 PASS:", native, "continuous native-center/full-matching risk cases")
print("Stage 2 parameters are diagnostic, not the original high-dimensional history.")

# Stage 3: repeated masses, strict-prefix endpoint pressure and full-future marks.
models = pairs = positive = 0
for seed in range(12):
    masses = list(map(F, [1,1,2,2,3,4,8,9,16]))
    K = [F(3,2), F(2), F(3)][seed % 3]
    rho = [F(1+(2*i+seed) % 5, 4) for i in range(len(masses))]
    x, _ = far_paths(masses, rho, K, F(1,4), 8, seed+2)
    z, _ = far_paths(masses, rho[::-1], K, F(1,4), 8, seed+3)
    c, p = joint_check(x, z, seed+7)
    models += 1
    pairs += c
    positive += p
assert positive > 0
print("Stage 3 PASS:", models, "atomic repeated-mass joint models;", pairs,
      "threshold checks;", positive, "positive paid checks")
print("Exact likelihood, p=1 killing, terminal stopping and nonfactorized future marks verified.")
print("General epsilon-X receipt is analytic; no full-history nonemptiness or W closure claimed.")
