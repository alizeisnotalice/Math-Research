% R430 floating parameter exploration; not an interval certificate.
r430_rows = zeros(27,8); r430_idx = 0;
for r430_n = [16 64 256 1024 4096 65536 1048576 1073741824 1099511627776]
 for r430_eps0 = [0.5 0.125 0.03125]
  r430_idx = r430_idx + 1;
  r430_s=1+sqrt(r430_n); r430_M=r430_eps0*(1+r430_n*log(2))/r430_s;
  if r430_M<=1
   r430_theta=2*r430_M;
  else
   r430_L=ceil(log2(r430_M)); r430_theta=r430_L+2*r430_M*2^(-r430_L);
  end
  r430_B=sqrt(r430_n); r430_S=2; r430_r=1;
  r430_Omega=2*r430_S*r430_r*(1+r430_eps0)*(1+r430_B)*r430_theta;
  r430_target=1/1024; r430_riskL=log(r430_S/r430_target);
  r430_rows(r430_idx,:)=[r430_n r430_eps0 r430_M r430_theta r430_Omega r430_Omega/(r430_s*log(r430_n+2)) r430_riskL r430_S*exp(-r430_riskL)];
 end
end
writematrix(r430_rows,'/tmp/r430_matlab_parameters.csv');
r430_text=sprintf('R430 float parameters: n eps0 M Theta Omega normalized L price\n');
for r430_idx=1:size(r430_rows,1)
 r430_text=[r430_text sprintf('%.12g %.12g %.12g %.12g %.12g %.12g %.12g %.12g\n',r430_rows(r430_idx,:))];
end
r430_text=[r430_text version newline];
r430_fid=fopen('/tmp/r430_matlab.result.txt','w'); assert(r430_fid>=0);
fwrite(r430_fid,uint8(r430_text),'uint8'); fclose(r430_fid); disp(r430_text);
