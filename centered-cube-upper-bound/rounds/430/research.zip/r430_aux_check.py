from fractions import Fraction as F
from pathlib import Path
import json

def logs(x,N=120):
    assert x>=1
    z=(x-1)/(x+1)
    # Scale by powers of 2 to keep the rational tail uniformly small.
    if x>2:
        k=0;y=x
        while y>2:y/=2;k+=1
        a,b=logs(y,N);c,d=logs(F(2),N)
        return a+k*c,b+k*d
    p=z;lo=F(0)
    for j in range(N):lo+=2*p/F(2*j+1);p*=z*z
    tail=2*p/(F(2*N+1)*(1-z*z)) if z else F(0)
    return lo,lo+tail

def native_radial(n,H,ratio):
    U=H*ratio;cap=F(2)**n
    # f=1 on [-4,4]^n; E=Q_2(0), R(A)=max(1,2||A||infty).
    # Actual q=1 and m=max(1,t), t=(2||A||infty)^n.
    base=F(int(H<1<=U))
    low=max(H,F(1));up=min(U,cap)
    if up>low:alo,ahi=logs(up/low)
    else:alo=ahi=F(0)
    blo,bhi=logs(ratio)
    assert base+ahi<=1+blo
    return {'n':n,'H':str(H),'ratio':str(ratio),'base_atom':int(base),'positive':base>0 or up>low}

def native_atoms(spike,H,U):
    # One real single-valued interval selector, three disjoint center intervals.
    # Complete f=1[-4,4]+(10*spike)1[-1/20,1/20]; added mass=spike.
    source_spike=(-F(1,20),F(1,20))
    rows=[((-F(3,10),-F(1,5)),F(1)),((-F(1,10),F(0)),F(3,2)),((F(1,5),F(3,10)),F(2))]
    val=F(0);hits=0
    for (left,right),side in rows:
        assert right-side/2<=source_spike[0] and left+side/2>=source_spike[1]
        assert left-side/2>=-4 and right+side/2<=4
        assert right-side/2<=0<=left+side/2
        mass=side+spike;q=mass/side
        assert 1<=q<=F(4,3)
        if H<mass<=U:
            val+=(right-left)*q/mass;hits+=1
    if U<=H:assert val==0
    else:
        l,_=logs(U/H)
        assert val<=F(4,3)*(1+l)
    return {'spike':str(spike),'H':str(H),'U':str(U),'captured_atoms':hits,'weighted_center_integral':str(val)}

initial=[native_radial(n,H,R) for n,H,R in [(1,F(1,2),F(2)),(2,F(1),F(2)),(9,F(2),F(3)),(16,F(1,4),F(5)),(25,F(3,2),F(101,100)),(9,F(1),F(1))]]
atoms=[]
for spike in [F(0),F(1,10),F(1,4)]:
    m1=1+spike;m2=F(3,2)+spike;m3=2+spike
    for H,U in [(m1,m2),(m1/2,m1),(m2,m3),(m3,m3),(m3,m3+1)]:atoms.append(native_atoms(spike,H,U))
expanded=[native_radial(root*root,H,F(2)**root) for root in [3,4,8,16,32] for H in [F(1,2),F(2),F(2)**root]]
# Exact owner/tie decomposition for one joint window; no claim these are history fixtures.
ties=0
for hy in [F(1),F(2),F(5)]:
    for hz in [F(1),F(2),F(5)]:
        H=max(hy,hz)
        for ratio in [F(1),F(3,2),F(3)]:
            for m in [H,H*ratio,(H+H*ratio)/2,H*ratio+1]:
                event=int(H<m<=ratio*H)
                old=int(hy>=hz and hy<m<=ratio*hy)
                new=int(hz>hy and hz<m<=ratio*hz)
                assert event==old+new;ties+=1
# Exact theta sum, including M<=1 and power-of-two breakpoints.
profiles=0
for M in [F(0),F(1,4),F(1),F(3,2),F(2),F(7),F(8),F(100),F(10000)]:
    N=40
    partial=sum(min(F(1),M/F(2)**j) for j in range(N))
    assert M/F(2)**N<=1
    exact=partial+2*M/F(2)**N
    if M<=1:formula=2*M
    else:
        L=0
        while F(2)**L<M:L+=1
        formula=L+2*M/F(2)**L
    assert exact==formula;profiles+=1
summary={'native_initial':len(initial),'native_mass_atom':len(atoms),'native_expanded':len(expanded),'native_total':len(initial)+len(atoms)+len(expanded),'owner_tie_checks':ties,'profile_checks':profiles,'PASS':True}
print(json.dumps(summary))
print('Native radial/interval selectors use full f and exact matching. Fixed-source center-window certificates, not complete high/history/hazard fixtures.')
print(json.dumps({'initial':initial,'mass_atom':atoms,'expanded':expanded},indent=2))
