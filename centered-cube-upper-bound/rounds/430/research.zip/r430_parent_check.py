"""R430 exact series/ledger checks and separate floating MATLAB comparison.
Finite parameter tests do not certify general geometry or global absorption.
"""
from fractions import Fraction as F
from pathlib import Path
import math,csv

def theta(m):
    if m<=1:return 2*m
    l=0
    while F(2)**l<m:l+=1
    return F(l)+2*m/F(2)**l

phases=[[F(1,4),F(1),F(2),F(3),F(4),F(7)],
        [F(15,16),F(17,16),F(31,8),F(33,8),F(127,16),F(129,16)],
        [F(2)**k+F(d,3) for k in [8,16,32] for d in [-1,1]]]
count=0
for phase in phases:
 for m in phase:
    # Explicit exact sum plus the infinite geometric tail, not a float fit.
    assert m<F(2)**80
    series=sum((min(F(1),m/F(2)**k) for k in range(80)),F())+2*m/F(2)**80
    assert theta(m)==series
    # Independently substitute actual ordered positive splits into all three mother equations.
    t=F(1,1024); S=F(2); dq=S*t
    r=F(3,2); eps0=F(1,8); B=F(9)
    omega=2*S*r*(1+eps0)*(1+B)*theta(m)
    C=F(7,1000); V=F(41); X=F(17); W=F(13); R=F(19)
    delta=F(1,128); eta=F(1,256); fh=1/(1-32*delta-16*eta)
    lam=F(128,119); E=F(1,30); S390=F(23); s=F(10)
    oldR=R+dq*X+omega*W
    assert 16*fh*(oldR+C*X+V*W)==16*fh*(R+(C+dq)*X+(V+omega)*W)
    assert 32*fh*oldR+(E+32*fh*C)*X+(S390+8*s+32*fh*V)*W == 32*fh*R+(E+32*fh*(C+dq))*X+(S390+8*s+32*fh*(V+omega))*W
    assert lam*(64*fh*oldR+(2*E+64*fh*C)*X+(2*S390+16*s+64*fh*V)*W)==lam*(64*fh*R+(2*E+64*fh*(C+dq))*X+(2*S390+16*s+64*fh*(V+omega))*W)
    assert lam*64*fh*dq>0  # This is a cost, never a refund.
    count+=1
print('exact checks:',count,'parameter cases in phases',list(map(len,phases)),'; infinite Theta tail and three mother ledgers PASS')
rows=list(csv.reader((Path(__file__).parent/'r430_matlab_parameters.csv').open()))
assert len(rows)==27
norm=[]
for row in rows:
 n,eps0,m,th,om,no,L,price=map(float,row)
 targetm=eps0*(1+n*math.log(2))/(1+math.sqrt(n))
 th2=sum(min(1.,targetm/(2.**k)) for k in range(80))+2*targetm/(2.**80)
 om2=4*(1+eps0)*(1+math.sqrt(n))*th2
 expected=[targetm,th2,om2,om2/((1+math.sqrt(n))*math.log(n+2)),math.log(2048),1/1024]
 for actual,want in zip([m,th,om,no,L,price],expected):
    assert math.isclose(actual,want,rel_tol=3e-13,abs_tol=1e-14),(n,actual,want)
 norm.append(no)
print('MATLAB float cross-check: 27 rows PASS; n 16 through 2^40; not an interval certificate')
print('normalized window-cost range: %.9g to %.9g'%(min(norm),max(norm)))
print('No global absorption, native history, or full residual bound certified by this script.')
