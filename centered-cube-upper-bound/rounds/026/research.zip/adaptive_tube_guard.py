from fractions import Fraction as F
from itertools import combinations, product
from math import comb, factorial
from decimal import Decimal as D, localcontext
from pathlib import Path
import json

# Finite exact guards, followed by independently repeated Decimal calculations.
def geometry():
    out=[]
    for n in (1,2,3):
      for count in (3,5,7):
       for pattern in (0,1,2):
        ys=[tuple(F(((i+1)*(j+2)+pattern*i*i)%9-4,4) for j in range(n)) for i in range(count)]
        caps=[F(3+(i*3+pattern)%7,4) for i in range(count)]
        a,b=F(1),F(2)
        for k in (1,2,3):
         boxes=[]
         for ids in combinations(range(count),k):
          c=min([b]+[caps[i] for i in ids])
          if c<a: continue
          lo=tuple(max(ys[i][j]-c/2 for i in ids) for j in range(n))
          hi=tuple(min(ys[i][j]+c/2 for i in ids) for j in range(n))
          if all(l<=h for l,h in zip(lo,hi)): boxes.append((lo,hi))
         axes=[sorted(set([F(-3),F(3)]+[box[h][j] for box in boxes for h in (0,1)])) for j in range(n)]
         volume=F(0); cells=0
         for js in product(*[range(len(v)-1) for v in axes]):
          x=tuple((axes[j][i]+axes[j][i+1])/2 for j,i in enumerate(js))
          radii=[2*max(abs(x[j]-y[j]) for j in range(n)) for y in ys]
          candidates=set([a,b]+[r for r in radii if a<=r<=b]+[c for c in caps if a<=c<=b])
          hit=any(sum(r<=L<=c for r,c in zip(radii,caps))>=k for L in candidates)
          boxhit=any(all(l<=z<=h for l,z,h in zip(lo,x,hi)) for lo,hi in boxes)
          assert hit==boxhit
          if hit:
           v=F(1)
           for j,i in enumerate(js):v*=axes[j][i+1]-axes[j][i]
           volume+=v
          cells+=1
         out.append(dict(n=n,marks=count,pattern=pattern,k=k,boxes=len(boxes),cells=cells,volume=str(volume)))
    return out

def transitions():
    out=[]
    for p in (F(1,16),F(1,4),F(1,2),F(3,4),F(15,16)):
     for j in range(9):
      ps=[F(comb(j,i))*p**i*(1-p)**(j-i) for i in range(j+1)]
      mean=sum(i*z for i,z in enumerate(ps)); second=sum(i*i*z for i,z in enumerate(ps))
      assert sum(ps)==1 and mean==j*p and second-mean*mean==j*p*(1-p)
      out.append(dict(survival=str(p),old_count=j,mean=str(mean),variance=str(second-mean*mean)))
    return out

def pair_moments():
    def mul(a,b):
      out={}
      for x,c in a.items():
       for y,d in b.items():
        z=tuple(i+j for i,j in zip(x,y));out[z]=out.get(z,F(0))+c*d
      return out
    def pm(q,r):
      st=[[0]*5 for _ in range(5)];st[0][0]=1
      for i in range(1,5):
       for j in range(1,i+1):st[i][j]=st[i-1][j-1]+j*st[i-1][j]
      return sum(F(st[r][j])*q**j for j in range(r+1))
    def choose2(a):
      out=mul(a,a)
      for x,c in a.items():out[x]=out.get(x,F(0))-c
      return {x:c/2 for x,c in out.items()}
    left=choose2({(1,0,0):F(1),(0,1,0):F(1)})
    right=choose2({(1,0,0):F(1),(0,0,1):F(1)})
    poly=mul(left,right);out=[]
    for qs in (F(1,16),F(1,4),F(1)):
     for survival in (F(1,16),F(1,2),F(1)):
      v=qs*survival
      for fraction in (F(0),F(1,2),F(1)):
       qt=v+(1-v)*fraction;means=(v,qs-v,qt-v)
       joint=F(0)
       for powers,c in poly.items():
        for q,r in zip(means,powers):c*=pm(q,r)
        joint+=c
       cov=joint-qs**2*qt**2/4
       assert cov==v*qs*qt+v*v/2
       assert cov<=qs**2*(survival+survival**2/2)
       out.append(dict(qs=str(qs),qt=str(qt),shared=str(v),covariance=str(cov)))
    return out

def ptail(q,k):
    term=(-q).exp()*q**k/D(factorial(k)); total=term; j=k
    while term>abs(total)*D(10)**(-__import__('decimal').getcontext().prec+8):
      j+=1;term*=q/D(j);total+=term
    return total

def mm(a,b):
    return [[sum(a[i][l]*b[l][j] for l in range(len(a))) for j in range(len(a))] for i in range(len(a))]

def hit(q,T,k):
    rate=q+D(k-1); h=T; squarings=0
    while rate*h>D('0.125'):h/=2;squarings+=1
    P=[[D(i==j) for j in range(k)] for i in range(k)]
    for i in range(k):
      P[i][i]-=(q+i)/rate
      if i+1<k:P[i][i+1]+=q/rate
      if i:P[i][i-1]+=D(i)/rate
    power=[[D(i==j) for j in range(k)] for i in range(k)]
    weight=(-rate*h).exp(); E=[[weight*z for z in row] for row in power]
    r=0
    while weight>D(10)**(-__import__('decimal').getcontext().prec+8):
      r+=1;power=mm(power,P);weight*=rate*h/r
      for i in range(k):
       for j in range(k):E[i][j]+=weight*power[i][j]
    for _ in range(squarings):E=mm(E,E)
    pi=[(-q).exp()*q**i/D(factorial(i)) for i in range(k)]
    return 1-sum(pi[i]*sum(E[i]) for i in range(k))

def diagnostics(prec):
 with localcontext() as ctx:
  ctx.prec=prec
  out=[]
  for n in (8,32,128,512,2048,8192):
   T=D(n)*D(2).ln();J=int(T);core=(1-D(1)/(2*n))**n
   for k,alpha in ((1,D(2)),(2,D(1)),(3,D(1)/2),(4,D(1)/3)):
    q=(-T.ln()/k).exp();assert alpha*q<1
    p=ptail(q*(1-(-D(1)).exp()),k)
    lower=1-(1-p)**J
    exact=hit(q,T,k)
    upper=min(D(1),ptail(q,k)+T*q*(-q).exp()*q**(k-1)/D(factorial(k-1)))
    assert lower<=exact<=upper and core>=D('0.5')
    const=1-(-(-D(1)).exp()*(1-(-D(1)).exp())**k/D(2*factorial(k))).exp()
    assert lower>=const
    out.append(dict(n=n,k=k,alpha=format(alpha,'.18g'),q=format(q,'.18g'),block_lower=format(lower,'.18g'),hit_probability=format(exact,'.18g'),upcross_upper=format(upper,'.18g'),core_weak_ratio=format(core*exact/(alpha*q),'.18g'),analytic_ratio_lower=format(const/(2*alpha*q),'.18g')))
  atoms=[]
  for n in (1,4,16,64,256,1024):
   B=D(2)**n
   for c in (D('0.0001'),D(1),D(4)):
    for k in (2,3,4):
     lo=c/B;hi=c
     # Integral of exp(-s)s^(k-2)/(k-1)! via finite gamma polynomial.
     def g(s):return (-s).exp()*sum(s**j/D(factorial(j)) for j in range(k-1))/D(k-1)
     v=B*ptail(lo,k)+c*(g(lo)-g(hi))
     assert -D('1e-50')<=v<=c/D(k-1)+D('1e-50')
     atoms.append(dict(n=n,c=str(c),k=k,expected_volume_over_c=format(v/c,'.18g'),universal_cap=str(F(1,k-1))))
  for row in out+atoms:
   for key,value in list(row.items()):
    if isinstance(value,str) and key != "universal_cap": row[key]=str(D(value).normalize())
  return out,atoms

def main():
 g=geometry();tr=transitions();mom=pair_moments();d,a=diagnostics(70);d2,a2=diagnostics(110)
 assert d==d2 and a==a2
 result=dict(status='PASS finite guards; no general covering bound certified',geometry=g,transitions=tr,pair_moments=mom,flat_source=d,single_atom=a,notes=['Exact Fraction geometry; count includes distinct marks at coincident source locations.','Decimal 70/110 repeat agrees at 18 displayed significant digits; not outward-rounded interval certification.','Flat-source matrix computes continuous-time hit, not just sampled times.','No random seed: all parameters and marks deterministic.'])
 Path(__file__).with_name('results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps(dict(status='PASS',geometry_cases=len(g),geometry_cells=sum(x['cells'] for x in g),transition_cases=len(tr),pair_moment_cases=len(mom),flat_cases=len(d),single_atom_cases=len(a))))
if __name__=='__main__':main()
