#!/usr/bin/env python3
"""R180 finite Fraction checks; arrays are algebraic, never original FIRST inputs."""
from pathlib import Path
from fractions import Fraction as F
from itertools import product,combinations
import json,sys,hashlib
HERE=Path(__file__).resolve().parent
OLD=Path('/Users/zhengzhihao/Desktop/T/output/centered_cube_round179_20261016_final_checkpoint/mixed_kernel_probe.json')
VENDOR=Path('/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor')
# Minimal verbatim frozen R179 inputs; the full external JSON is not required.
FROZEN_SOURCE_SHA='13e18332b23437adbbf7c8ab80f707ad1a085e13161885166790fb57a17fcbd9'
FROZEN_ROWS=json.loads('{"0": {"lambda_value": "1", "D": "0", "dps": 50, "N": [64, 128], "C": "1.0", "hard_overlap": "0.50545831598245478983796125495426669528685832288554", "displacement": "0.59392159920938620064585897931891738789677102953907", "soft_overlap": "0.34625693790983938299310519722559848802561130712376", "relative_refinement_indicator": "0.00000000000024471782844283606824845797704886907804512269993455"}, "1": {"lambda_value": "1", "D": "1", "dps": 30, "N": [32, 64], "C": "0.186231191897872178668385294723", "hard_overlap": "0.186231191897872178668385294723", "displacement": "0.299769333849536785123493698811", "soft_overlap": "0.206704541904628477266743412113", "relative_refinement_indicator": "3.16720687505648011908023907233e-11"}}')
def fs(xs):return [F(x) for x in xs]
def sm(xs):return sum(xs,F(0))
def prod(xs):
 z=F(1)
 for x in xs:z*=x
 return z
def fixture(name,stage,nu,J,K,q,D,a,ap,E,Ep,bb=None,bp=None):
 n=len(nu);return dict(name=name,stage=stage,nu=fs(nu),J=fs(J),K=fs(K),q=F(q),D=F(D),a=fs(a),a_prime=fs(ap),E=E,E_prime=Ep,b=fs(bb if bb is not None else [F(i+1,n+1) for i in range(n)]),b_prime=fs(bp if bp is not None else [F(n-i,n+1) for i in range(n)]))
def fixtures():
 ep=F(1,1024);tiny=F(1,2**20)
 return [
 fixture('identical','initial',[F(1,2)]*2,[1,2],[1,1],2,1,[3,0],[3,0],[1,0],[1,0],[0,1],[0,1]),
 fixture('capture_and_active_change','initial',[1,1],[1,1],[2,1],3,1,[1,6],[F(3,2),F(13,2)],[1,1],[1,1]),
 fixture('positive_small_K_mask_exchange','initial',[1],[1],[F(1,100)],1,1,[4],[4],[0],[1]),
 fixture('alpha_zero_saturated_capture','initial',[F(1,2)]*2,[1,2],[1,2],F(3,2),1,[3,6],[4,7],[1,1],[1,1]),
 fixture('zero_a_to_active','mask_zero_stress',[1],[1],[1],1,1,[0],[2],[1],[1]),
 fixture('all_zero_a_mask_changes','mask_zero_stress',[F(1,3),F(2,3)],[1,2],[1,3],3,1,[0,0],[0,0],[0,1],[1,0]),
 fixture('zero_mass_slot_ignored','mask_zero_stress',[0,1],[100,1],[100,1],1,1,[999,2],[0,3],[0,1],[1,1]),
 fixture('zero_K_exchange_necessity','mask_zero_stress',[1],[1],[0],1,1,[4],[4],[0],[1]),
 fixture('b_exchange_necessity','mask_zero_stress',[1],[1],[0],1,1,[4],[4],[1],[1],[0],[1]),
 fixture('near_sharp_2A','expanded',[1,1],[ep,1],[1,ep],1+ep,1,[F(1,2),1024],[F(5,8),1024],[1,1],[1,1],[1,1],[1,1]),
 fixture('D_and_J_range','expanded',[F(1,8),F(7,8)],[F(1,16),16],[F(1,4),2],2,F(7,3),[F(1,100),100],[F(1,10),101],[1,1],[0,1]),
 fixture('threshold_and_mask_crossing','expanded',[1,2,3],[1,F(1,8),8],[0,1,2],10,F(1,3),[0,F(1,3),4],[F(1,10),0,F(9,2)],[1,0,1],[0,1,1]),
 fixture('unequal_mass_and_large_a','expanded',[tiny,1-tiny],[1024,F(1,1024)],[1,1],2,1,[10000,100000],[10001,100003],[1,0],[0,1])]
def normalized(a,t):return F(0) if a==0 or a<=t else (a-t)**2/a
def norm_expanded(a,t):return F(0) if a==0 or a<=t else a-2*t+t*t/a

def check_same(c):
 nu,J,K=c['nu'],c['J'],c['K'];D,q=c['D'],c['q'];a,ap,E,Ep=c['a'],c['a_prime'],c['E'],c['E_prime'];QJ=sm(j*m for j,m in zip(J,nu));assert D>=0 and q>=0 and all(v>=0 for v in nu+K+a+ap) and all(j>0 for j in J) and all(e in (0,1) for e in E+Ep) and all(0<=v<=1 for v in c['b']+c['b_prime']);assert QJ>0 and sm(k*m for k,m in zip(K,nu))<=q
 cap=[F(e)*min(x,D*k) for e,x,k in zip(E,a,K)];capp=[F(e)*min(x,D*k) for e,x,k in zip(Ep,ap,K)];capture=sm(x*m for x,m in zip(cap,nu));capturep=sm(x*m for x,m in zip(capp,nu));alpha=(D*q-capture)/QJ;alphap=(D*q-capturep)/QJ;assert alpha>=0 and alphap>=0
 t=[D*k+alpha*j for k,j in zip(K,J)];tp=[D*k+alphap*j for k,j in zip(K,J)];N=[normalized(x,y) for x,y in zip(a,t)];Np=[normalized(x,y) for x,y in zip(ap,tp)];act=[F(e)*v for e,v in zip(E,N)];actp=[F(e)*v for e,v in zip(Ep,Np)]
 A=sm(abs(x-y)*m for x,y,m in zip(a,ap,nu));B=sm(k*abs(e-f)*m for k,e,f,m in zip(K,E,Ep,nu));X=sm(min(x,y)*abs(e-f)*m for x,y,e,f,m in zip(N,Np,E,Ep,nu));Y=sm(min(x,y)*abs(bb-bp)*m for x,y,bb,bp,m in zip(act,actp,c['b'],c['b_prime'],nu))
 lhsalpha=abs(alpha-alphap)*QJ;lhsbar=sm(abs(x-y)*m for x,y,m in zip(N,Np,nu));lhsact=sm(abs(x-y)*m for x,y,m in zip(act,actp,nu));lhsb=sm(abs(x*bb-y*bp)*m for x,y,bb,bp,m in zip(act,actp,c['b'],c['b_prime'],nu));base=2*A+2*D*B
 identities=dict(signed_capture_alpha=(alphap-alpha)*QJ==capture-capturep,normalization_expansion=all(x==norm_expanded(aa,tt) for x,aa,tt in zip(N,a,t)) and all(x==norm_expanded(aa,tt) for x,aa,tt in zip(Np,ap,tp)),pointwise_binary_mask_expansion=all(abs(e*x-f*y)==min(e,f)*abs(x-y)+max(e-f,0)*x+max(f-e,0)*y for x,y,e,f in zip(N,Np,E,Ep)),positive_homogeneity=all(normalized(F(3,2)*aa,F(3,2)*tt)==F(3,2)*nn for aa,tt,nn in zip(a,t,N)))
 checks=dict(alpha_capture_bound=lhsalpha<=A+D*B,smooth_2A_bound=lhsbar<=base,masked_with_exchange=lhsact<=base+X,weighted_b_with_exchange=lhsb<=base+X+Y,all_identities=all(identities.values()),Nbar_le_a=all(0<=v<=x for v,x in zip(N,a)) and all(0<=v<=x for v,x in zip(Np,ap)))
 return dict(input=c,QJ=QJ,alpha=alpha,alpha_prime=alphap,capture=capture,capture_prime=capturep,Nbar=N,Nbar_prime=Np,Nact=act,Nact_prime=actp,A=A,B=B,X=X,b_exchange=Y,lhs_alpha=lhsalpha,lhs_smooth=lhsbar,lhs_masked=lhsact,lhs_b=lhsb,bound_2A_2DB=base,checks=checks,identities=identities,smooth_over_A=lhsbar/A if A else None,without_X_pass=lhsact<=base,without_b_exchange_pass=lhsb<=base+X,scope='Finite algebraic arrays satisfying the stated hypotheses; not original physical/FIRST rows')

def union(d,z,b=F(1),closed=False):return any(abs(x-y)<=b if closed else abs(x-y)<b for x,y in zip(d,z))
def atomic_law(law):
 return [(F(x),F(m)) for x,m in law]
def union_example(name,stage,d,law):
 d=fs(d);laws=[atomic_law(law) for _ in d];k=[sm(m for z,m in L if abs(x-z)<1) for x,L in zip(d,laws)];formula=1-prod(1-x for x in k);direct=F(0);closed=F(0);correction=F(0);identities=True
 for picks in product(*laws):
  z=[a[0] for a in picks];mass=prod(a[1] for a in picks);inside=[abs(x-y)<1 for x,y in zip(d,z)];c0=[F(1,4)]*len(d);r=[F(1,2)*int(v) for v in inside];c=[a+b for a,b in zip(c0,r)]
  diff=prod(c)-prod(c0);sub=sm(prod(r[i] if i in S else c0[i] for i in range(len(d))) for count in range(1,len(d)+1) for S in combinations(range(len(d)),count));first=sm(r[i]*prod(c[:i])*prod(c0[i+1:]) for i in range(len(d)));identities &=diff==sub==first and 0<=diff<=int(any(inside));direct+=mass*int(union(d,z));closed+=mass*int(union(d,z,closed=True));correction+=mass*diff
 return dict(name=name,stage=stage,d=d,product_atomic_W=laws,kappa=k,union_direct=direct,union_product_formula=formula,closed_event_probability=closed,strict_closed_differ=direct!=closed,formal_compact_correction=correction,checks=dict(union_formula=direct==formula,compact_subset_firsthit=identities,compact_union_bound=correction<=direct),scope='Exact product-atomic probability and formal compact kernels C0=1/4,R=1/2 on strict strips; not physical C or original FIRST')
def source_sum(n,incomparable=False):
 coords=[tuple([F(0)]*n),tuple([F(1)]*n)];beta=[F(1,4),F(3,4)] if incomparable else [F(1),F(1)];nu=[F(2,3),F(1,3)];law=[(F(0),F(3,4)),(F(-1,2),F(1,8)),(F(1,2),F(1,8))];price=F(0);energy=F(0)
 for y,by in zip(coords,beta):
  for v,nv in zip(coords,nu):
   d=[a-b for a,b in zip(y,v)];k=[sm(p for z,p in law if abs(x-z)<1) for x in d];price+=by*nv*(1-prod(1-a for a in k))
   for picks in product(law,repeat=n):
    zz=[a[0] for a in picks];pp=prod(a[1] for a in picks);inside=[abs(x-z)<1 for x,z in zip(d,zz)];corr=prod(F(1,4)+F(1,2)*int(i) for i in inside)-F(1,4)**n;energy+=by*nv*pp*corr
 return dict(n=n,beta=beta,nu=nu,ordered_nu_le_beta=all(v<=b for v,b in zip(nu,beta)),joint_union_price=price,formal_correction_energy=energy,pass_exact=energy<=price,scope='Direct positive beta x nu double sum; no signed zeta identity or source ordering assumption')
def physical_checks():
 # No new quadrature: reuse two already frozen R179 physical convolution rows.
 sys.path.insert(0,str(VENDOR));import mpmath as mp
 mp.mp.dps=50;rows={int(k):v for k,v in FROZEN_ROWS.items()};s=mp.mpf(1)/4;tables={}
 for d,r in rows.items():
  cc=mp.mpf(r['C']);c0=mp.mpf(r['hard_overlap']);wc=mp.mpf(r['displacement']);wc0=mp.mpf(r['soft_overlap']);primitive=lambda z:mp.sign(z)*(mp.mpf('.5')-mp.expint(3,abs(z))) if z else mp.mpf(0);kap=(1-s)*int(abs(d)<1)+s*(primitive(d+1)-primitive(d-1));tables[d]=dict(C=cc,C0=c0,R=cc-c0,smooth_C=(1-s)*cc+s*wc,smooth_C0=(1-s)*c0+s*wc0,kappa=kap,source_dps=r['dps'],source_N=r['N'])
 out=[]
 for d in [(0,),(1,),(0,1),(1,1)]:
  z=[tables[v] for v in d];corr=mp.fprod(q['smooth_C'] for q in z)-mp.fprod(q['smooth_C0'] for q in z);price=1-mp.fprod(1-q['kappa'] for q in z);raw=mp.fprod(q['C'] for q in z)-mp.fprod(q['C0'] for q in z);out.append(dict(d=list(d),s='1/4',lambda_value='1',b='1',compact_tensor=mp.nstr(raw,40),convolved_compact=mp.nstr(corr,40),joint_union_probability=mp.nstr(price,40),numeric_pass=bool(-mp.mpf('1e-25')<=corr<=price+mp.mpf('1e-25')),source_resolution=[dict(D=v,dps=tables[v]['source_dps'],N=tables[v]['source_N']) for v in d]))
 return dict(rows=out,frozen_input_rows=FROZEN_ROWS,mpmath_version=mp.__version__,kappa_formula='(1-s)*1{|d|<1}+s*integral_(d-1)^(d+1) w(z)dz; primitive sign(z)*(1/2-E3(|z|))',scope='Actual fixed physical kernels, numerical frozen quadrature values with empirical refinement indicators only; no new quadrature, interval or FIRST certificate')
def main():
 exact=[check_same(c) for c in fixtures()];law=[(0,F(3,4)),(F(-1,2),F(1,8)),(F(1,2),F(1,8))];unions=[union_example('center_n1','initial',[0],law),union_example('inside_n2','initial',[F(1,2)]*2,law),union_example('strict_boundary_dirac','mask_zero_stress',[1],[(0,1)]),union_example('outside_1p1','mask_zero_stress',[F(11,10)],law),union_example('outside2','mask_zero_stress',[2],law),union_example('mixed_union_n2','expanded',[0,2],law),union_example('joint_boundary_n2','expanded',[1,1],law)];sources=[source_sum(1),source_sum(2,True)];physical=physical_checks()
 expected=dict(without_X_fails_at_zeroK=not next(c for c in exact if c['input']['name']=='zero_K_exchange_necessity')['without_X_pass'],without_X_fails_at_positiveK=not next(c for c in exact if c['input']['name']=='positive_small_K_mask_exchange')['without_X_pass'],without_b_cost_fails=not next(c for c in exact if c['input']['name']=='b_exchange_necessity')['without_b_exchange_pass'],strict_vs_closed_probability_differs=next(c for c in unions if c['name']=='strict_boundary_dirac')['strict_closed_differ']);failures=[c['input']['name'] for c in exact if not all(c['checks'].values())]+[c['name'] for c in unions if not all(c['checks'].values())]+['source_sum' for c in sources if not c['pass_exact']]+[k for k,v in expected.items() if not v]
 data=dict(scope='Finite exact algebra plus reused physical-kernel numerics, not original full FIRST/history/traffic examples or a general theorem.',proposition=dict(alpha='(Dq-sum E min(a,DK)nu)/QJ',Nbar='(a-DK-alpha J)_+^2/a; zero if a=0',A='sum |a-a_prime|nu',B='sum K|E-E_prime|nu',X='sum min(Nbar,Nbar_prime)|E-E_prime|nu',smooth_bound='2A+2DB (final improved coefficient; authors independently confirmed)',actual_bound='2A+2DB+X',b_bound='actual_bound+sum min(Nact,Nact_prime)|b-b_prime|nu',source_cap='arbitrary positive beta,nu; no nu<=beta needed'),same_alpha=exact,union=unions,source_double_sums=sources,physical=physical,physical_numeric_failures=[r['d'] for r in physical['rows'] if not r['numeric_pass']],expected_failures_of_omitted_costs=expected,unexpected_failures=failures,all_exact_pass=not failures,frozen_input_provenance=dict(original_path=str(OLD),original_sha256=FROZEN_SOURCE_SHA,embedded_minimal_rows=True,external_file_required=False),dependencies=dict(mpmath_vendor=str(VENDOR),standard_library='Fraction/json/pathlib/hashlib/itertools'),local_inputs={'task_contract.md':hashlib.sha256((HERE/'task_contract.md').read_bytes()).hexdigest()},runtime=dict(python=sys.version),limitations=['Fraction arrays certify their finite identities/inequalities only, not a general original-predicate realization.','Masks b and E here are abstract; original b_H retains its full Pi/source/history masks separately.','The compact union price retains the joint event, not a sum of coordinate caps.','Physical convolution values are reused from R179 and remain numerical, not rigorously enclosed.','No new quadrature, receiver scan, optimization, or asymptotic fit.'])
 (HERE/'weighted_geometry_checks.json').write_text(json.dumps(data,indent=2,default=str)+'\n');print(json.dumps(dict(exact_same_alpha=len(exact),exact_union=len(unions),source_sums=len(sources),physical=len(physical['rows']),all_exact_pass=not failures,near_sharp_ratio=str(next(c for c in exact if c['input']['name']=='near_sharp_2A')['smooth_over_A']),expected_omissions=expected,failures=failures)))
 if failures or data['physical_numeric_failures']:raise SystemExit(1)
if __name__=='__main__':main()
