# R180：原同 α 残余权重的稳定性及加权桥缺口

状态：本稿不证明原 middle companion 的 polylog(n)W 预算，也不领取新的 raw 价格。得到的是针对原同 α 构造的、无维度常数损失的稳定机制：连续核变化与 capture 门变化可以明确分开；原 bad 后验和删除门的交换另有准确费用。该机制说明 R179 共同来源补偿若要作用于实际权重，须支付什么，而非把任意加权能量假设成已知界。

本引理仅使用固定 ν 与 FIRST 给出的 K0ν≤q。它**不需要 ν≤β**，不定义 β−ν。父级正在修复该来源支配关系的原文继承，本稿不依赖尚未定位的支配合同。以下实际 companion 的外 β 仍原样保留，未作来源替换。

## 1. 原量词与可比较的两行

固定原 (ω,V,x,j) 及同一合法终端参数。于是 q、D、T、J_v、K0_v、Q_v、τ、h 对外 y 共同。取两条均可定义的原外来源行 y、y′；整个比较使用**同一个 ν**，不得重新选择来源或将删后的 ν 当新测度。原各行删除集及资格门可以不同，以下显式计入这些差异。

记
\[
a_y(v)=T\Delta_y(v)\ge0,\qquad Q_J=\int J_v\,\nu(dv)>0,
\quad \varepsilon_y(v)=1_{E_y}(v),
\]
其中 E_y 是原 U 的完整 capture 资格集，包括其 good、存活和正差资格。ε_y 与后验归一 e_t 不同。准确构造为
\[
U_y(v)=\varepsilon_y(v)\min\{a_y(v),DK0_v\},\qquad
\alpha_yQ_J=Dq-\int U_y\,d\nu.
\tag{WB1}
\]
由 U_y≤DK0_v 与 K0ν≤q，α_y≥0。Q_J=0 的零来源行不进入正目标。原 D 是同一个固定常数；本稿不比较使用不同 D、q 或接收点 x 的行。

定义全域辅助延拓
\[
\overline N_y(v)=
\begin{cases}
\dfrac{(a_y(v)-DK0_v-\alpha_yJ_v)_+^2}{a_y(v)},&a_y(v)>0,\\
0,&a_y(v)=0,
\end{cases}
\qquad N_y=\varepsilon_y\overline N_y.
\tag{WB2}
\]
只有在原 capture E_y 上，\(\overline N_y=a_y\rho_y^2\) 对应实际残余；不能在 E_y 外把辅助延拓认作原 traffic。N_y 是实际 capture 限制后的残余分子。

此身份依据原 RC 定义而非 R175 的简写：冻结 `/Users/zhengzhihao/Desktop/T/output/centered_cube_round126_20261014/proof.md` RC3（574–583 行）取 F_rec=U+αJ，RC6（608–620 行）定义 E 上 b_rec=min(1,F_rec/(TA))、E 外保持 b_D；冻结 R127 `proof.md`（同目录规则 `centered_cube_round127_20261014`，294、708 行；亦见其 `research.zip::proof.md`）明确沿用该定义，714 行保留真实余权 1−b_rec。于是 E 上 a≤DK0 时 U=a、b_rec=1，两边残余都为零；a>DK0 时 U=DK0，故真实 ρ=1−b_rec=[1−(DK0+αJ)/a]_+，得到 WB2。若之后额外捕获产生任意更小余权，点态支配不使其自动继承本稳定性定理；本稿只比较该同一 RC 构造的余权。

## 2. 同 α 的无维度稳定命题

对两行定义明确的核与门差
\[
A(y,y')=\int|a_y-a_{y'}|\,d\nu,\qquad
B(y,y')=\int K0_v|\varepsilon_y-\varepsilon_{y'}|\,d\nu,
\]
\[
X(y,y')=\int\min(\overline N_y,\overline N_{y'})
|\varepsilon_y-\varepsilon_{y'}|\,d\nu.
\tag{WB3}
\]
则
\[
|\alpha_y-\alpha_{y'}|Q_J\le A+DB,
\tag{WB4}
\]
\[
\int|\overline N_y-\overline N_{y'}|\,d\nu\le2A+2DB,
\tag{WB5}
\]
\[
\boxed{\int|N_y-N_{y'}|\,d\nu\le2A+2DB+X.}
\tag{WB6}
\]

这些结论适用于任意原删除和 capture 门，不假定这些门在 y 下连续。X 是真实的 off-capture 交换费用，不得以 2DB 代替。具体有
\(0\le X\le\int\min(a_y,a_{y'})|\varepsilon_y-\varepsilon_{y'}|d\nu\)；在低 capture 区，a 与 DK0 的比值没有本稿可用的统一上界。

证明：截断函数 a↦min(a,DK0) 是 1-Lipschitz，且取值不超过 DK0，因此
\[
|U_y-U_{y'}|\le|a_y-a_{y'}|+DK0_v|\varepsilon_y-\varepsilon_{y'}|.
\]
积分并用同一个 WB1 得 WB4。对 a,c≥0 定义 F(a,c)=(a−c)_+²/a，a=0 时取零。在活跃支 a>c 上，
\[
\partial_aF=1-(c/a)^2\in[0,1],\qquad
\partial_cF=-2(1-c/a)\in[-2,0].
\]
非活跃支为零；沿水平、竖直线段积分，连同 a=0 的连续延拓，得到全象限不等式
\[
|F(a,c)-F(a',c')|\le|a-a'|+2|c-c'|.
\tag{WB7}
\]
直接使用 WB7 与 WB4 会给 3A；同 α 构造可进一步改成 2A。先固定 E，取 a_θ=(1−θ)a_y+θa_y′，k=DK0，并始终按 WB1 定义 α_θ。因为 ∫kν≤Dq，全线段 α_θ≥0。记点为 θ 导数，则几乎处处
\[
\dot\alpha_\theta Q_J=-\int_E1_{a_\theta<k}\dot a\,d\nu.
\]
直接 a 导数仅在 a_θ>k+α_θJ≥k 的活跃支出现，而 α 的变化由 E∩{a_θ<k} 产生。两支不交；用 0≤ρ_θ≤1 和 ∫Jρ_θν≤Q_J，得到
\[
\int|\dot{\overline N}_\theta|d\nu
\le\int_{a_\theta>k}|\dot a|d\nu
+2\int_{E\cap\{a_\theta<k\}}|\dot a|d\nu
\le2\int|\dot a|d\nu.
\]
积分 θ 给固定 E 的 2A 界。a_θ=k 的折点对每个非零 dot a 的槽至多一个；dot a=0 槽没有相应项，故 Fubini 与绝对连续链式法覆盖等号集。a=0、k=0、α=0 通过上述连续延拓包含。再固定 a_y′ 改变 E，WB7 与 WB1 给额外 2DB，因此得到 WB5。最后，对 N,N′≥0 和 ε,ε′∈{0,1}，
\[
|\varepsilon N-\varepsilon'N'|
\le|N-N'|+\min(N,N')|\varepsilon-\varepsilon'|.
\]
这给 WB6，且准确保留了 capture 交换项。所有常数独立于 n、ν 的分布及删除次数。

## 3. 连续物理核项可直接量化

原 C=h*F，F=max(h,φ)，且 0≤F≤1。写 C(r)=∫_{r−1/2}^{r+1/2}F，由绝对连续性，几乎处处 C′(r)=F(r+1/2)−F(r−1/2)∈[−1,1]，因此
\[
|C(r)-C(r')|\le|r-r'|.
\tag{WB8}
\]
对共同 ξ∈[1/2,1]，每个 min(1,C/ξ) 因子不超过 1 且对 C 为 2-Lipschitz。乘积望远镜展开给
\[
|w_\xi(y,v)-w_\xi(y',v)|
\le\min\{1,\|y-y'\|_1/(b\xi)\}
\le\min\{1,2\|y-y'\|_1/b\}.
\tag{WB9}
\]
原 Δ=w_τ−w_h；在本合法共同终端窗，ξ_τ、ξ_h∈[1/2,1]，且 Δ∈[0,1]。因此
\[
A(y,y')\le T\|\nu\|
\min\{1,4\|y-y'\|_1/b\}.
\tag{WB10}
\]
若比较的辅助窗口没有 ξ_τ、ξ_h≥1/2，则 WB10 中的 4 必须改为 ξ_τ⁻¹+ξ_h⁻¹。当前非空原 far 窗有 τ=a/c_j≤h≤bc_j，故 ξ_τ=a/b≥1/2，ξ_h≥ξ_τ，且两者≤1，以上常数合法。

由 ∥y−y′∥₁≤√n∥y−y′∥₂，固定 E 时实际 N 的欧氏位移敏感度为
\[
\int|N_y-N_{y'}|d\nu
\le {8T\|\nu\|\sqrt n\over b}\|y-y'\|_2.
\tag{WB10a}
\]
若整个所比较行族具有共同 E，取任意两个有限正外来源 η₀、η₁，质量相等且一阶矩有限，并以任意耦合 π 配对这些原行。积分 WB10a，再取欧氏 W₁ 输运费用的下确界，得到
\[
\int\left|\int N_y(v)\eta_0(dy)-\int N_y(v)\eta_1(dy)\right|\nu(dv)
\le {8T\|\nu\|\sqrt n\over b}W_1(\eta_0,\eta_1).
\tag{WB10b}
\]
这里 W₁ 指未归一的等质量测度之间的运输费用；这是固定接收参数下的来源几何结论，不把接收点也作平移。一般 E 随行变化时，对每个耦合另加 ∫(2DB+X)dπ；这些费用不能从 W₁ 中省掉。第 4 节加入 b_H 后，也须另加那里明确的后验交换费用。

这是实际物理核项的显式费用，而非假设某未知矩很小。它仍乘原 ν 总质量；本稿没有 λbⁿ 的来源质量帽，也不把 T∥ν∥ 视为已付 q 或 W_β 价格。B≤K0ν≤q 只给粗接收量，不能给所需任意小吸收系数；X 仍须保留。

## 4. 原 bad 后验和支持的准确交换费用

固定上述 x,V,j 及一个两行都合法且 e_t>0 的原时间 t。令
\[
m_y(du)=1_{Z_{y,t}}(u)w_t(y,u)\nu(du),\quad
e_y=m_y(\mathbb R^n),\quad\Pi_y=m_y/e_y.
\]
这里 e_y 仅在本节表示原 e_t(y)，不是新的归一。把实际 H、bad、低 score 指示合并为
\[
L_y(v,u)=H(x,y,v,u,t)1_{\mathsf B_y}(u)1_{k_t(y,u)<k_t(y,v)}\in[0,1],
\quad b_y(v)=\int L_y(v,u)\Pi_y(du).
\tag{WB11}
\]
这就是原 b_H；不能将 H 的 u 相关部分提到积分外。取总变差范数为有限符号测度的总质量范数，有
\[
\|\Pi_y-\Pi_{y'}\|_{TV}
\le {2\|m_y-m_{y'}\|_{TV}\over\max(e_y,e_{y'})},
\tag{WB12}
\]
\[
\|m_y-m_{y'}\|_{TV}
\le\int|w_t(y,u)-w_t(y',u)|\nu(du)
+\int\min(w_t(y,u),w_t(y',u))
|1_{Z_{y,t}}-1_{Z_{y',t}}|\nu(du).
\tag{WB13}
\]
WB12 例如在 e_y≥e_y′ 时，将两测度差写为
\((m_y-m_{y'})/e_y+m_{y'}(1/e_y-1/e_{y'})\)，再用 |e_y−e_y′|≤∥m_y−m_y′∥ 即得。WB13 是逐点的非负乘积不等式，原删除支持从未省去。

由 WB11，
\[
|b_y(v)-b_{y'}(v)|
\le\|\Pi_y-\Pi_{y'}\|_{TV}
+\int|L_y(v,u)-L_{y'}(v,u)|\Pi_{y'}(du).
\tag{WB14}
\]
还可将右侧截断到 1。两项分别保留原归一/删除变化与原 history/bad/score 门变化；不存在无费重新归一。由 0≤b≤1 和相同乘积不等式，WB6 进一步给实际残余分子与 bad 槽的联合比较
\[
\boxed{
\int|N_yb_y-N_{y'}b_{y'}|\,d\nu
\le2A+2DB+X
+\int\min(N_y,N_{y'})|b_y-b_{y'}|\,d\nu.}
\tag{WB15}
\]

这已经作用于原同 α、原 bad 质量及原支持，不是任意来源能量的重复命名。最后一项由 WB12–14 展开为明确物理核/删除/门差，尚未给出全球接收积分价格。

## 5. 回到原 MC12：尚未支付的乘子及首次断点

因为原正目标支撑于 E_y，原 companion 在 a_y>0 上准确包含
\[
\mathbb E\sum_{V,j}\int dx\,\beta(dy){dt\over t}\nu(dv)
\underbrace{{p_y^2J_v w_t(y,v)\over
9Q_v^2e_t(y)a_y(v)}}_{\text{原实际乘子}}
\,1_{Z_{y,t}}(v)N_y(v)b_y(v).
\tag{WB16}
\]
a_y=0 时原正项为零，不能先将乘子单独取值为无穷再使用不等式。重复的支持/capture 门只取一次或保留为幂等指示，不改变原量。

WB15 是 ν 下残余分子的稳定式。将它用于 WB16，不能把框外乘子移到积分外，也不能将其改为统一常数。good 仅给
\[
{p_y^2J_v w_t\over9Q_v^2e_t a_y}
\le {K^2J_v w_t\over9w_g(y,v)^2e_t a_y};
\tag{WB17}
\]
这保留倒 a_y、倒 w_g² 和实际 e_t，未产生一个已归一的接收核。乘子本身在 y 平移下还产生乘积交换差；没有一个单纯 WB15 的 L¹ 结论可以删去它。

另一处具体断点是：same-α 稳定式控制的是 K0 加权的 capture 门差 B；WB13–14 中删除及 bad 门差由 w_t/e_t 的实际后验加权。要直接把后者逐点付给前者，需要控制 w_t/(e_tK0)，这正是低 capture 区尚无统一上界的真实密度比。本稿既不对该比值取独立上确界，也不把其未知矩改名为新预算。X 的 a 加权门差也不能换成 K0 加权门差。

因此，R179 平移能量补偿若要用于此处，下一步所需的是：在 WB16 的真实 dx、β、ν、原时间与 j/history 测度下，同时支付 WB15 的连续项、X 及 WB12–14 的门差，并控制 WB16 乘子的交换；不能仅证明一个无权共同来源收缩。原 physical 乘子与这几类门差的联合接收积分是准确剩余位置。

## 6. 费用边界与检查点

WB4–15 均为固定 x,V,j、同一 ν 下的两行结论，不借用 ν≤β。它们没有消费 signed 负信用，没有更换 α、Π、Z、bad 或 current 参数。标量常数 2、4、8 不随 n 增长，欧氏运输版明确支付 √n；但尺度费用 T∥ν∥/b、B、X 及后验门差尚未全局支付。逐 j 求和和窗口/history 均须原样保留，不能因该固定行结论取消菜单费用。

本轮没有证明原 middle companion≤polylog(n)W_β，因而没有使用已付 EJ 来领取根阶来源价格，也没有领取 ε∫q 吸收。交付是可核验的实际同 α 权重稳定机制及其完整交换账。此处停止本轮范围，不增加条件小矩门或反例搜索。
