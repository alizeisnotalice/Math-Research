# R180：实际阈值 C 的紧修正、联合条带价格与能量边界

本稿只处理实际 C 的修正，不处理父级/Astra 的原 weighted traffic 线性化。已读 R180 合同、R179 MC9–12及 F02 SKILL/provenance；F02仅用于区分点态非负与正定、核对张量范围，不借未经阅读的外部正定性定理。其外部 ledger 的 registry 目录不完整，未作回退或引用。以下全部计算自证，并先送独审筛查。

重要来源修正：本稿允许**任意两份有限正测度 β、ν，不预设排序关系，不假设 ν≤β**。若出现 ζ=β−ν，它是有限实符号测度；只有 TV 费用可用，不能把它叫作实际正剩余来源。全稿仅写本文件，不 Git/spawn/PDF。

## TK1. 实际核和全部物理单位

一维 h=1[-1/2,1/2]，w(r)=∫₀¹exp(−|r|/a)da，φ=h*w，F=max(h,φ)，C=h*F。a 在此为 dummy。h,w,φ 质量1；0<φ≤1，F,C 非概率核。定义

\[
C_0=h*\phi=h*h*w,\quad B=h(1-\phi),\quad R=h*B,\quad C=C_0+R.
\tag{TK1}
\]

B,R≥0，supp B⊂[-1/2,1/2]，R 连续且 R(r)=0 对 |r|≥1。因 F 在硬区间内等于1、外部等于φ，上述身份逐点成立。0<C≤1、C(0)=1；C₀>0。

对固定 b>0，记

\[
K_b(d)=b^{-n}\prod_iC_0(d_i/b),\quad
\widehat K_b(d)=b^{-n}\prod_iC(d_i/b),\quad
\mathcal R_b=\widehat K_b-K_b\ge0.
\tag{TK2}
\]

所有 source centers 固定后才作能量积分。b不允许随 receiver免费变动；W先取固定概率测度。正修正价格本身不要求W偶，与基准对称能量合并时才要求偶。

## TK2. 不漏 tensorcross 的首次命中身份

定义准确一维比例 r_i(d)=R(d_i/b)/C(d_i/b)∈[0,1)，并按固定坐标顺序置

\[
f_i(d)=r_i(d)\prod_{j<i}(1-r_j(d)).
\]

则

\[
\boxed{\mathcal R_b(d)=b^{-n}\prod_jC(d_j/b)
\sum_{i=1}^nf_i(d),\quad
\sum_if_i=1-\prod_i(1-r_i)\le1.}
\tag{TK3}
\]

这把完整 ∏C−∏C₀ 的所有交叉项准确收入同一个首次命中和，不是只保留一次修正或每个坐标各领取一次单位费用。f_i非零要求 |d_i|<b；闭面 |d_i|=b 时 R=0。

记真实联合条带集合

\[
U_b(a)=\{y:\exists i,\ |y_i-a_i|<b\}.
\]

由 TK3 与每个 C≤1，得到无需指数 tensor 常数的点态正比较

\[
\boxed{0\le\mathcal R_b(d)\le
b^{-n}1_{U_b(0)}(d)\le b^{-n}.}
\tag{TK4}
\]

U是n个无限条带的并，不是边长2b立方体；将并误写为坐标交集会错。主结果保留联合并事件，不以 n 倍或逐坐标 worst-case 作为付款。

## TK3. 实际可积分的联合 compact-collision 价格

对任意固定 Borel 概率测度W（本节不需偶），定义

\[
\mathfrak C_{b,W}(\beta,\nu)
=\int\beta(dy)\nu(dv)W(dz)\,
1\{\exists i:\ |y_i-v_i-z_i|<b\}.
\tag{TK5}
\]

这是实际 β–ν–W 的联合质量，单位为来源质量平方；不是来源独立或某个新概率假设。积分对任意有限正 β、ν 有限，≤∥β∥∥ν∥。由TK4非负Tonelli，

\[
\boxed{
E^R_W(\beta,\nu):=\iint(\mathcal R_b*W)(y-v)\beta(dy)\nu(dv)
\le b^{-n}\mathfrak C_{b,W}(\beta,\nu).}
\tag{TK6}
\]

准确保留原修正的负账则为

\[
E^R_W-E^R_0\le b^{-n}\mathfrak C_{b,W}-E^R_0,
\qquad (E^R_W-E^R_0)_+\le b^{-n}\mathfrak C_{b,W}.
\tag{TK7}
\]

E^R₀≥0来自两个实际正来源和正核，不是PSD。右端联合条带价可测且可直接回代或计算；它没有把 C 换成 C₀，也没有按 ∥R∥₁或(1+∫B)^n计费。若负 E^R₀已在别处消费，TK7不可再领第二次。

作为次级上界而非主结果，定义

M_union^b(β)=sup_a β(U_b(a))，M_i^b(β)=sup_t β{|y_i−t|<b}。

开放集合及Fatou给a↦β(U_b(a))下半连续，其sup可用可数有理a计算。于是

\[
\mathfrak C_{b,W}\le
\min\{\|\nu\|M_{union}^b(\beta),\,
\|\beta\|M_{union}^b(\nu)\},\qquad
M_{union}^b(\beta)\le\min\{\|\beta\|,\sum_iM_i^b(\beta)\}.
\tag{TK8}
\]

两槽上界对任意W成立，第二槽只需将z换符号；没有要求来源或位移坐标独立。主价TK5保留共同z和事件并集，比先付各条带总和准确。原合同尚无这些容量小于总质量的统一结论；TK8不是新增原已付分支。

## TK4. 物理 soft 位移的可复现测量公式

若W确为固定物理产品位移

\[
W=\bigotimes_i[(1-s)\delta_0+s w_{r b}(z_i)dz_i],
\quad 0\le s\le1,\quad\tfrac12\le r\le1,
\tag{TK9}
\]

这里r是位移尺度比，非原halo阈值λ。对固定d=y−v，定义

\[
\kappa_i(d)=(1-s)1_{\{|d_i|<b\}}
+s\int_{d_i-b}^{d_i+b}w_{rb}(z)dz.
\]

那么

\[
W\{z:d-z\in U_b(0)\}
=1-\prod_i[1-\kappa_i(d)].
\tag{TK10}
\]

这是该物理位移核的准确产品公式，不是 β、ν坐标独立。Σβ_atomν_atom乘TK10给原子诊断的准确质量公式；一般测度使用TK5。硬原子在 |d_i|=b 时严格指示为0，连续w端点无质量。s=0退化为原联合条带指示，s=1无硬原子。不得用 1−∏(1−κ_i)≤Σκ_i 后忘记其n价格；TK10本身无binomial菜单。

本节给数值代理的是测量/方向检查，不给有限模型认证原L1/history/FIRST的资格。若W随receiver或来源对重新选，须先重建固定卷积与共同测度条件；TK6不自动允许对每个y单独选择把它移入条带的W。

## TK5. 与PSD基准能量的合并：signed差额也合法

现在要求W为固定偶概率测度。记E_W^0使用基准K_b，D_W^0=E_0^0−E_W^0。R179的初等自相关证明对任意有限实符号来源成立：K_b是h*Laplace单侧因子自相关的正概率混合，因而

\[
D_W^0(\sigma,\sigma)=\tfrac12\int\pi(da)W(dz)
\|g_{a,b}*\sigma(\cdot+z)-g_{a,b}*\sigma\|_2^2\ge0.
\tag{TK11}
\]

其中g_{a,b}=∏(h_b*ell_{a_i b})、ell_t(x)=t^(−1)e^(−x/t)1_{x≥0}，π(da)=∏2a_i da_i；这些正概率因子给K_b，且∥g∥₂²≤b^(−n)。此处不使用实际C的PSD。

令ζ=β−ν为signed。偶W使D对称，直接完成平方仍有准确身份

\[
\begin{aligned}
E_W^{\widehat K}(\beta,\nu)-E_0^{\widehat K}(\beta,\nu)
={}&\tfrac14D_W^0(\zeta,\zeta)
-D_W^0(\nu+\zeta/2,\nu+\zeta/2)\\
&+E_W^R(\beta,\nu)-E_0^R(\beta,\nu).
\end{aligned}
\tag{TK12}
\]

将TK6代入给实际阈值C的可用比较

\[
\boxed{
E_W^{\widehat K}-E_0^{\widehat K}
\le\tfrac14D_W^0(\zeta,\zeta)
+b^{-n}\mathfrak C_{b,W}(\beta,\nu)-E_0^R(\beta,\nu).}
\tag{TK13}
\]

所有n维cross项已在TK3/TK5，价格非指数核质量；β、ν为任意两份正来源时可直接使用。另因0≤K_b,K_b*W≤b^(−n)，核差绝对值≤b^(−n)，所以

\[
0\le D_W^0(\zeta,\zeta)\le b^{-n}\|\zeta\|_{TV}^2.
\tag{TK14}
\]

这对signed ζ也成立；不能引用只对正ζ成立的中间步D≤E₀，更不能用∥β−ν∥当作正剩余质量或由∥β∥免费控制它。若没有来源排序，最多∥ζ∥TV≤∥β∥+∥ν∥。TK13不把两种平方来源价格转成线性W_beta。

## TK6. 备选signed-tent能量工具及其准确张量费用

为说明可用PSD构件及不能免费跨过的费用，一维令T_a(r)=(1−|r|/a)_+。它是 a h_a*tilde h_a，PSD且T_a(0)=1、∫T_a=a，不是质量1概率核。R在0<r<1满足

R′(r)=−[1−φ(r−1/2)]，R″(r)=φ′(r−1/2)。

因此准确表示为

\[
R=(1-\phi(1/2))T_1
+\int_0^{1/2}a\phi'(a-1/2)T_a\,da
-\int_{1/2}^{1}a[-\phi'(a-1/2)]T_a\,da=:P-N.
\tag{TK15}
\]

可核：T_a在正半轴的二阶分布为δ_a/a；R在r=1有导数跳原子1−φ(1/2)，两者在1外为0，故二阶导数与边界值决定等式。P、N为非负tent混合PSD核；φ′在正半轴为负，因此N(0)=n₀:=∫₁/₂¹a[−φ′(a−1/2)]da>0。

令A=C₀+P，C=A−N，A(0)−N(0)=C(0)=1。完整n维signed tensor必须取所有偶/奇负标签：

∏C=P_n−N_n，P_n=Σ_{|S|even}(⊗_{i∉S}A⊗_{i∈S}N)，N_n同式对odd S。

每个构件PSD，但负构件的准确对角价格是

\[
N_n(0)={ (1+2n_0)^n-1\over2},\qquad
P_n(0)={ (1+2n_0)^n+1\over2}.
\tag{TK16}
\]

这不是可忽略的O(1)。构件均为非负自相关混合，故0≤N_n(x)≤N_n(0)，其与概率W卷积仍处于该范围。例如对signed σ，负Dirichlet项可保守控制为 b^(−n)N_n(0)∥σ∥TV²；该费用属于此signed-tent机制，不能领成根阶付款。TK15仅给可追踪的紧尺度能量工具；本稿主价格用TK5的真实联合collision，避免把TK16作为默认费用，但没有证明任何一般PSD修复无此成本。

## TK7. 原合同已核到哪里、下一步的准确位置

父级及source_caps_index已核：检查的R113/R117/R128来源合同没有β的统一每窗λb^n帽，更无本稿signed ζ的TV帽；born/tree资格限于相应ν来源，不能转给β。本稿也不使用未获继承的ν≤β。对TK5，目前由实际正测度条件只能确定0≤mathfrak C≤∥β∥∥ν∥；没有证据把联合条带容量或signed TV平方降成线性来源费用。条带宽2b并非来源立方体体积帽，∑β≤f也不限制任意L1输入在条带内的质量。

因此TK13是真实C能量的新几何比较及可测、可检验的compact修正价格，不是原middle的已付分支。可行动的接缝是：保留TK3的首次命中或TK10共同位移并事件，用同一个原weighted receiver/source结构估计其联合collision；必须同时保留负E₀^R及原same-alpha，不可另加一个“小strip cap”当合同。

原companion尚含p_y²rho²J_v/(9Q_v²)、两槽wt/et、真实bad/低score、H的u依赖、Pi_g、唯一j/history和middle门。固定(omega,V,j,y,t)的Pi_t可以与dx换序，但这些joint/terminal乘子不等于固定β、ν之间的平移不变双线性型。TK13仅在其写明的固定b、固定偶W能量范围成立；自适应W_x、改基准尺度、不同j核或把乘子并进依v/x/t的“β”都需真实额外费用。

本稿未付原fractionalraw，未声称实际C为PSD，未丢tensorcross或另加sourcecap，未把signed ζ叫正来源。完成本有界检查点并交独审后停止，不扩反例、数值扫参或全局路线。
