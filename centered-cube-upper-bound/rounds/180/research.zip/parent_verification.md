# R180 父级核验

已完整读最终 WB 与 TK 理论，独立核对2A的互斥导数支、C的1-Lipschitz、TV归一分母、first-hit联合并事件、signed来源能量与tent费用。Sol先审命题再审作者稿，来源原句由审计直接读R113/R117归档复核。

最后窄核直接定位 R127 research.zip::proof.md 294、708、714 的 b_rec=min(1,Frec/a) 于E，补足R128窄段未展开的定义。独审直接复核，WB2原RC身份成立；任意额外捕获缩小余权仍需交换费。

理论冻结：
- weighted_middle_bridge.md: b30d69aca61006cd00ce25f7c49013f56f301c841ee86b600d01d20ade4382ab
- threshold_kernel_geometry.md: bf0ddacf259f8990e48659939f95cd19e531c73b434e673414e5736fa0da5b6f
- weighted_geometry_checks.py: 18734545b69c02d00c5e0a06e539f0d0cd30e42880f062ad70be60f81645c52a

实际独立重放目录：/Users/zhengzhihao/Desktop/T/output/r180_parent_replay_20261016。
命令使用 /Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 运行复制后的 weighted_geometry_checks.py。
退出0，13/7/2精确检查及4物理诊断通过，所有非runtime输出字段匹配冻结JSON。父级静态审过脚本的两种Nbar公式、符号capture恒等式、jointunion枚举及实际核数据来源。没有重跑R179求积。

来源纠错是本轮必要结果：ν≤β的继承未核定，R173/R175/R179相关README已加指向本轮的明确范围修订，未重写旧ZIP。当前新WB/TK不需要来源排序。原根阶预算及全部输入覆盖尚未证明。

只归档最终证明、审计、最小代码/结果/来源及本说明；工作稿冻结后先仓库外逐字节备份，再压缩验证。不会编译PDF，不会把数值诊断升级成一般证明。最终归档字节核验及复现驱动运行结果记录于 archive_verification.md。
