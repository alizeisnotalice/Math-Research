# R180 原加权联合几何独审

仅负责本文件；不Git、不spawn、不跑数值、不编译PDF、不改作者稿。以下先读R180合同、R179 MC9–12、R173独审§§2–3、R175 CJ1–11及R128 RT1/RT4–6窄段，未读本轮作者证明。一般上界仍未闭合。

## 1. 作者前：原实际来源与平方槽

原未付companion以同一正积分测度E sum_(V,j)1_j dx β(dy)ν(dv)ν(du)dt/t承载。H包括真实high、eligible、两个Z_t、bad/low-score/history和middle门，只是[0,1]门；不吸收密度。积分u后的精确系数是

    p_y²rho_y(v)² J_v/(9Q_v²) · wt(y,v)/et(y) · b_H(x,y,v,t),
    b_H=∫H(x,y,v,u,t)1_bad(u)1_(ku<kv)Π_(y,t)(du).

b_H可正上界为普通bad低score后验质量，不能作为等式删除u-history。全ν定义κ_x=J_uν/QJ时准确Π_t=(QJ/et)1_Zt(wt/Ju)κ_x；actual et>0行才作此换密度，J严格正保证QJ>0。固定(omega,V,j,y,t)的Π_t不依x，不代表其y-v联合密度可并成固定外来源；Π_g、s/L、rho/alpha、Q、b_H、terminal/receiver门仍依x。

已付EJ≤nWβ/(2K)只覆盖原v槽J_v δ_plus²。若得到C_rem≤B_n Wβ，才可领取(32Λ/3)sqrt[nB_n/(2K)]Wβ。hard16/3、outer2Λ均一次；不能给两个CS因子各领一次硬帽，不能借新几何再消费原signed负信用。

## 2. 作者前：samealpha储备与质量归一的准确代价

R128 RT6和R175 CJ3–5确证同一actualK0对整段y积分共同，且

    gamma_y=alpha_y QJ/D_y
      =G0+∫(K0−U_y/D_y)dν,
    G0=q−K0ν≥K0ζ,    gamma_y≥K0bad_yν,
    ζ=β−ν≥0.

这里控制的是带K0的实际质量，不是未加权||ζ||、bad质量或对x的列积分。原严格s>1−2^(−1/n)>0使K0在有限点正，但仅点态正不提供整个source support上的维数一致下界。若要据此推出masscap，须实核原V支持、a/b与实际K0最小值；不能把tau、mu的subprob质量改称独立来源概率。gamma0/bad0与G00/ζ0按严格正K0分别处理，不重选alpha。

R128 RT1窄段只明载ν≤f、q∈[3lambda/4,lambda]、硬核帽等；未在此段看到||β_V||≤A lambda b^n一类精确V质量帽。因此本检查点不认证这类帽。父级另查原β/ν/V定义后，需以原定义及定位补证。

R179无权能量的D_W(ζ,ζ)≤b^(−n)||ζ||²是二次齐次。若另有已证||ζ||≤A q b^n，则只是

    b^(−n)||ζ||²/q ≤ A||ζ||.

若已证的是||ζ||≤A lambda b^n，则由q≥3lambda/4至多得到右侧4A||ζ||/3。两式均须先解释原待估积分为何真的带同一份1/q；不能给MC能量免费补一个1/q，再把q另算成常数。原high仅在实际eligible行给1/et≤1/eg≤p_y/(2Kq)，代入MC12后会留下额外p_y及原rho²/Q²/wt/b_H，不会自动化为无权MC能量。其后还须处理真实dx、所有V求和与唯一j；逐V质量帽不自动给sum_j/window线性价。

齐次核验：f/β/ν同时乘c时q/et/gamma乘c、alpha/rho/Π不变，原companion及raw乘c；无权MC能量和b^(−n)||ζ||²乘c²。任何接桥必须显示补偿这一次质量的真实归一分母，不能以无量纲PSDbound掩盖。

## 3. 作者前：能量合法加权的最小边界

R179 MC只对固定b、固定偶概率W和实际固定来源成立。若权重能明确写成共同的、独立x的非负source multiplier a(y)a(v)，则可对aβ、aν应用MC，保留aζ及其平方能量；若是多个这样的固定共同正项，则逐项保留补偿并求和。这是可合法接口，不是断言原MC12具有该结构。

若两槽乘子不同a(y)、b(v)，一般并无bν≤aβ；即使使用符号测度的完成平方，修正项也变为D_W(aβ−bν,aβ−bν)/4，不能继续把它写成D_W(aζ,aζ)/4。若jointweight依x,y,v，或H/b_H含另一槽，必须给精确的交换差/正分解及其价格；不能仅说核正定就乘任意原门。原C=C_base+h*[h(1−phi)]的compact正差也不能从空间非负推出PSD或平移收缩，tensor全部交叉项须留。

最小receiverweight诊断式：固定实L²函数f和有界非负a(x)，对固定偶W有

    ∫a f²−∫a f(W*f)
      =1/2 ∫W(dz)∫a(x)[f(x)−f(x−z)]²dx
       +1/2 ∫W(dz)∫[a(x)−a(x+z)]f(x)²dx.

后一交换差无自动符号；删门、依x的参数及归一分母至少须覆盖这种准确余项。此式仅说明最小义务，不登记为实际原weighted新估计或付款。原W_x与L/b变化还需另证共同正包络或真实参数/窗口费用，不能直接继承fixedW的MC。

## 4. 后审计划与本检查点停止

后续只核作者给出的准确命题：真实β/ν/a/b质量帽与同一q如何匹配；samealpha、1_Zt和b_H是否完整；新分解是否真的控制MC12的jointweight；C实际修正的符号及tensor项；全dx/clock/j/window/历史成本。父级和作者数值只作为有限证据，不认证一般PSD或完整raw付款。作者前独立检查点完成，等待准确命题后一次后审；本文件暂不作新全局付款认证。


## 5. actualC两种修正候选：作者前独筛

令B=h(1−phi)、R=h*B。r∈(0,1)有R'(r)=−[1−phi(r−1/2)]、R''(r)=phi'(r−1/2)，r1的导数跳原子为1−phi(1/2)。T_a(r)=(1−|r|/a)_+，故R的准确signedtent表示为

    R=(1−phi(1/2))T_1
       +∫_0^(1/2) a phi'(a−1/2)T_a da
       −∫_(1/2)^1 a[−phi'(a−1/2)]T_a da.

在r>0核二阶测度及r0导数均匹配，端点R1=0；候选正确。T_a=a h_a*tilde h_a，质量a而非1；正负部分各为PSD非负核，但R本身及tensor差不因此PSD。直接tensor须留全部符号parity交叉项及真实质量，不能把系数当作概率。

另令r_i=R(D_i)/C(D_i)∈[0,1]，firsthit weights f_i=r_i product_(j<i)(1−r_j)，则

    Cprod−Cbaseprod=Cprod sum_i f_i,
    sum_i f_i=1−product_i(1−r_i)≤1.

每个f_i非零必须|D_i|<1；这是保留真实compact来源碰撞的一次正分解，未按2^n菜单扩张。它不证明任意相关来源的碰撞质量小，也不允许每个坐标独领无费列预算。等待最终命题后审。

## 6. samealpha残余稳定候选：作者前独筛

固定同一x,V,j以及原共同q/J/K0/T/D、同一ν，令a_y(v)=TDelta_y(v)≥0、I_y=1_(原captureE_y)、U_y=I_y min(a_y,DK0)。alpha_y QJ=Dq−U_yν、QJ=Jν>0。则

    QJ |alpha_y−alpha_y'|
      ≤∫|a_y−a_y'|dν+D∫K0|I_y−I_y'|dν.

alpha非负由Uν≤DK0ν≤Dq。对全域虚拟Nbar(a,c)=(a−c)_+²/a（a0取0，c≥0），活跃区∂a=1−(c/a)²∈[0,1]、∂c=−2(1−c/a)∈[−2,0]；跨a=c及a0连续，所以全象限|δNbar|≤|δa|+2|δc|。c_y=DK0+alpha_yJ，积分给

    ∫|Nbar_y−Nbar_y'|dν
      ≤3∫|δa|dν+2D∫K0|δI|dν.

该式固定同一来源测度，未免费比较删除后换过的ν或Z。关键限定：Nbar_y=a_y rho_y²只在原captureE_y上成立；offE原U0通常不能加入DK0。若比较实际I_y Nbar_y，还须加mask差，例如∫a_y'|δI|dν的安全上界；原history/H变化亦各留交换差。已在作者前将此限制反馈作者，不能称无门全actual残余稳定。

0≤F≤1给C的2-Lipschitz安全界；固定xi≥1/2时产品阈值|δw_xi|≤4||y−y'||_1/b，故固定τ/h/T的a=T(wτ−wh)满足|δa|≤8T||y−y'||_1/b。这些常数对任意相关ν成立；只是局部变化，不是将原MC12中的1/a、rho/Q²、et和支持归一已经付掉。等待全文和准确scope后审。


## 7. 原source帽定位的实读核对与继承资格问题

已读source_caps_index.md，并直接打开rounds/113/research.zip::proof.md B2/B4/B5（27–54行）及rounds/117/research.zip::proof.md JG1–2/JG14（29–52、155–162行），没有只以提取稿为证据。核对结果：β_V=ζ_(alpha,V)是预冻结软残余，受输入质量支配；JG2的B_j=ell q c_j^(−n/2)是heavy硬源测试系数；JG14的born/node资格只给ν，明确不赋予β。所查窄段没有||β||或||ζ||≤A lambda b^n的uniform窗口帽，故不能据这些符号线性化R179的二次费用。此为所检来源范围内‘未建立’，不声称任何未来原几何推论都不可能。

同时实读发现精确继承资格待澄清：R113 B2第34行明确没有假定ν≤β；当前R175/R180合同却直接采用ν≤β。此时本审可以相对当前合同核验ζ=β−ν≥0的条件命题，但若声称它是原actual来源的正差，必须另给R113以后建立ν≤β的准确继承定位。已告父级，不广泛追链，不擅自替换ν或β。即便原ν不被β支配，MC的符号测度配方仍成立，但ζ将是符号差，正储备tau、samealpha正外源分割及||ζ||质量解释不能原样继承；这不属于可默略的符号修订。等待父级确认该来源资格的范围。


## 8. 来源继承澄清后的影响范围（覆盖上文继承接口）

父级确认：目前无已知精确原定位建立ν≤β，R175直接声明不构成原证明。不声称该支配关系不可能；本轮停止追链并按独立正β、ν审新机制。

不受影响：R179 ES/MG物理fixedb核界不依赖来源排序；原OT尾支用β≤f及Π概率也不依赖ν≤β；新samealpha稳定只固定ν并用K0ν≤q。R179 MC的双线性/完成平方对signed ζ=β−ν仍成立，但不能再称ζ正soft残余。对signed ζ，采用|K_b−K_b*W|≤b^(−n)直接得D_W(ζ,ζ)≤b^(−n)||ζ||TV²；不能沿用正ζ才有的D≤E0步骤或||ζ||≤||β||。

受影响的准确继承：R173 audit§2.1由n/(2K) E sum||νV||到n/(2K)Wβ的最后质量比较用了ν≤β或另需已证Wν≤Wβ。因此在未补该来源资格时，上文§1调用的Wβ能量接口只作为冻结合同的条件接口；原独立推导可认证的是EJ≤nWν/(2K)，Wν=E sum||νV||。若companion另外有C_rem≤B_n Wβ，实际CS价为(32Λ/3)sqrt[n B_n Wν Wβ/(2K)]，不能把两种来源质量无证同化。若companion也以Wν计价，则据实保留相应因子。R175把β−ν当正外源并构成subprob τ的原继承亦未闭合；signed测度不能保持其正容量解释。本轮不默改ν/β来修旧证明。

本项是实读来源捕获的真实资格缺口，不由有限实验关闭；新候选若完全不需ν≤β，明确删去该假设即可独立核证。

## 9. actualC联合碰撞容量：作者前精确筛查

对物理差d=y−v，mathcalR_b(d)=b^(−n)[product_i C(d_i/b)−product_i Cbase(d_i/b)]满足

    0≤mathcalR_b(d)≤b^(−n)1_{存在i:|d_i|<b}.

原R_i在|d_i|≥b时为0；firsthit分解保留所有tensor交叉项，且总权≤1，无须按sum_i重复领价。任意固定概率W均有

    E^R_W(β,ν)≤b^(−n) C_W,
    C_W=∫β(dy)ν(dv)W{z:存在i |y_i−v_i−z_i|<b}.

C_W≤min{||ν|| M_union(β),||β|| M_union(ν)}仅为secondary上界，M_union为同一b下的平移union-of-slabs最大质量；它不使此双来源量变线性。与baseMC的cross完成平方合并时，W还须偶；独立正β、ν合法，ζ用signed差与TV费用。

物理productW的每坐标κ_i=(1−s)1_(|d_i|<b)+s∫_(d_i−b)^(d_i+b)w_(lambda b)(r)dr，联合概率为1−product_i(1−κ_i)，正确保留所有collision重叠，不作独立source假设。product仅是指定W自身结构。actualW_x/基准L差与原MC12 jointweight仍需另付，不能把该新jointcapacity作为原raw已付结论。


## 10. 两作者全文后审

threshold_kernel_geometry.md TK1–16与全部范围结论已完整实读，通过。TK3firsthit全tensor、TK4严格开条带/闭面零修正、TK5任意probW正价、TK8可数sup可测性、TK10指定productW的union公式均正确。TK11–14只在base对称能量合并时用偶W，signedζ合法，TV²上界直接用核差幅度而不误用正ζ的D≤E0。TK15 tent系数/端点分布、T_a质量a、TK16完整偶奇parity与对角价格((1+2n0)^n−1)/2均准确。实际C没有被声明PSD，新条带联合容量没有被变成线性原source价。

weighted_middle_bridge.md WB1–17与全篇已完整实读，通过。最终改进为2A+2DB（覆盖§6中保守3A），固定E路径alpha合法、a=k非零导数的折点Fubini与a0/k0/alpha0延拓均充分。实际capture的X及bad后验的min(N,N')交换项完整保留。C由AC得到1-Lipschitz，wt常数2、Delta常数4、固定E欧氏运输常数8T||ν||sqrt(n)/b正确。WB12的分母max(e_y,e_y')由较大质量分解得，方向正确；WB13–15全部保留原支持1_Zt、真实门与归一差。

WB16把N=a rho²精确回原companion时保留1_Zt(v)、b_H、倒a/Q²/et及其他receiver乘子；a0原正项设零，不制造0乘无穷。WB15不能直接乘以未控的WB16密度，稿中明确保留此交换和真实dx/j/window费用。两稿均已删除不必要ν≤β假设，仅固定同一ν或任意独立正β、ν；没有消费原signed负信用，没有登记新的raw付款。无待修项。

当前作者实算绑定：

| 文件 | SHA256 |
| --- | --- |
| threshold_kernel_geometry.md | bf0ddacf259f8990e48659939f95cd19e531c73b434e673414e5736fa0da5b6f |
| weighted_middle_bridge.md | 7a235c33cfe54761b5c84e39b4a3389138c2bf3582191dbc7b45f110a057680e |

理论后审完成，等待父级数值方案实际检验范围与主整合文本作最后一次有限核对；不重复运行实验。


## 11. 主整合及数值方案的有限核验

已实读最终proof.tex.txt/report.md关键整合。来源继承修订、Wν/Wβ混合CS价、WB的2A/2DB/X、后验支持与归一交换、固定E运输8T||ν||sqrt(n)/b、TK联合并事件和signed TV²范围均与已审稿一致。主tex已用‘任意两份’正来源避免把来源独立当作假设。actual乘子1_Zt p²Jwt/(9Q²et a)、variableb/W_x、原时间/j/history与原负信用均明确保留；不因摘要删掉费用，不称一般上界闭合。

静态完整核对weighted_geometry_checks.py并读JSON的小范围命题/失败标志及weighted_geometry_checks.md、numerical_validation.md、parent_verification.md。13个Fraction fixture确实实现最终2A+2DB、X、b交换与同alpha恒等式；nearsharp仅有限比值1074330623/537920000。零K/抽象b门用于一般代数边界，明确不认证strictsoft原核实现。7个union例用直接product原子枚举与1−product(1−κ)交叉核对，形式C0/R的三种tensor计算准确，严格/闭条带差异保留。2个βν双和含不可比较正来源，未用ν≤β。4个physical例仅复用R179 D0/D1近似卷积，primitive sign(z)(1/2−E3(|z|))的导数确为w；它们是数值诊断，不是定向区间或FIRST/history证书。

最终脚本把两行原数据最小嵌入，保留路径/SHA与分辨率来源；没有新求积、维数拟合或receiver扫参。所有exact/physical失败标志独立记录，任一意外失败均退出非零。JSON当前all_exact_pass真、unexpected_failures和physical_numeric_failures空，13/7/2/4计数与说明一致。去掉X/b交换的失败只作有限必要性例，不外推全维付款。父级已报告隔离实际重放退出0、非runtime全字段一致；本独审依分工不重复执行数值，不把父级重放当作一般解析证明。

## 12. 最终冻结结论与绑定

本轮两新机制及整合在明示范围内通过，无待修作者数学项：固定同ν的同alpha残余稳定与全部门交换账；实际C的完整tensor紧修正及jointcollision价格。独审实读捕获ν≤β原继承未闭合，已在本轮合同、来源索引、两作者稿、主tex/report中作准确资格修订；此前Wβ能量/正残余应用只能在补足质量资格后使用。该缺口不否定本轮无需排序的新引理，也不证明排序关系不可能。

一般middle companion/原raw未付；没有新增普遍root来源价、epsilon receiver吸收或完整输入覆盖认证。本审仅写本文件，未Git、未spawn、未数值重跑、未编译PDF；最终冻结后停止，不扩展研究。下表是最终实算SHA256，取代前述中间绑定；本文件自身hash另行报告。

| 文件 | SHA256 |
| --- | --- |
| task_contract.md | eb82776a3852a31e2faf31f00e66691659daa659d23ec155c8e53595c41ab510 |
| source_caps_index.md | 8aee096147d6beff49d3778f1d1f8cd94e3024431de4cb36cd0c6c079c0f8634 |
| weighted_middle_bridge.md | 7a235c33cfe54761b5c84e39b4a3389138c2bf3582191dbc7b45f110a057680e |
| threshold_kernel_geometry.md | bf0ddacf259f8990e48659939f95cd19e531c73b434e673414e5736fa0da5b6f |
| proof.tex.txt | 5bf1506cb6de8df25ba90b6714a1d4c82cbc8dc900a6f4f30552c359e8132841 |
| report.md | 53e9360bed2e0a5ba073d7eb8b6404c544926ed308b4cef1faabfc3774d19d21 |
| weighted_geometry_checks.py | 18734545b69c02d00c5e0a06e539f0d0cd30e42880f062ad70be60f81645c52a |
| weighted_geometry_checks.json | a0a35d723c3313aae14085798b1a5758c8b0739cf484a58db6ac1044817bff43 |
| weighted_geometry_checks.md | 10d49137229c6dec19e463564e887afb2d17c2e842db2fd30e603e3e8b427c02 |
| numerical_validation.md | 0b442fcc935668920642d52c2d23cb854592a7838d1a44e86005b50b01b30f37 |
| parent_verification.md | e42312799c0ef29fa8c0dc9d61cd33d81106e635ef79b103bc107957ffaa2288 |


## 13. 指定原RC余权的最后窄核及最终冻结

父级最后提出RT2 rho=1−b_rec与显式WB2身份是否仅正上界的问题。本审不凭R128 RT6的b_rec≥b_D推恒等式，而直接打开rounds/127/research.zip::proof.md 280–303及698–719行。原第294、708行明确E上b_rec=min(1,(U+alphaJ)/a)，第714行明确当前真实余权1−b_rec；因此足以补R128摘要未展开的定义。

分两支核验：E上a≤DK0时U=a，alpha≥0使b_rec1，故真实rho和WB2皆零；a>DK0时U=DK0，真实rho恰为[1−(DK0+alphaJ)/a]_+。所以WB2/WB16对该指定原RC余权有精确身份，无须降为未核envelope。额外捕获若另产生任意更小余权，仅点态支配不保证同一稳定式；必须计额外门/权交换差。当前WB正文、主tex及parent_verification已补准确来源定位和此限制，本审实读确认。此窄核不改变2A或数值脚本的命题，无需重跑。

最终无待修项，新的原RC稳定与actualC jointcollision均保持前述完整范围；ν≤β来源继承与一般raw预算缺口仍明确未闭合。本审至此最终冻结并停止。以下全表取代§12表中已更新的hash，其他数学字段不再重审或扩展。

| 文件 | 最终SHA256 |
| --- | --- |
| task_contract.md | eb82776a3852a31e2faf31f00e66691659daa659d23ec155c8e53595c41ab510 |
| source_caps_index.md | 8aee096147d6beff49d3778f1d1f8cd94e3024431de4cb36cd0c6c079c0f8634 |
| weighted_middle_bridge.md | b30d69aca61006cd00ce25f7c49013f56f301c841ee86b600d01d20ade4382ab |
| threshold_kernel_geometry.md | bf0ddacf259f8990e48659939f95cd19e531c73b434e673414e5736fa0da5b6f |
| proof.tex.txt | fca992581c9bf3b1d167b5f1e93cd33e88286bde374391e2d193a3f40b95719e |
| report.md | 53e9360bed2e0a5ba073d7eb8b6404c544926ed308b4cef1faabfc3774d19d21 |
| weighted_geometry_checks.py | 18734545b69c02d00c5e0a06e539f0d0cd30e42880f062ad70be60f81645c52a |
| weighted_geometry_checks.json | a0a35d723c3313aae14085798b1a5758c8b0739cf484a58db6ac1044817bff43 |
| weighted_geometry_checks.md | 10d49137229c6dec19e463564e887afb2d17c2e842db2fd30e603e3e8b427c02 |
| numerical_validation.md | 0b442fcc935668920642d52c2d23cb854592a7838d1a44e86005b50b01b30f37 |
| parent_verification.md | 08f369793073cdd1f50b18df55b74008398f213082a8230756092560847a8c41 |
