# 归档及复现验证

最终 reproduce.py 已在仓库外 r180_driver_replay_20261016 执行，退出0，全部非runtime数学输出一致。新增本说明后重新生成清单，仅核验文件字节，不重复无变化的数值。

包装脚本逐字节比较最终工作目录与仓库外 centered_cube_round180_20261016_final_checkpoint 备份，再逐成员比较 research.zip 与相同备份。只有全部断言通过才移除已备份的仓库内 work 副本。无PDF或缓存，归档仅最终材料。

ZIP自哈希、成员数与大小记在轮次README；自身不嵌入自己的哈希。inventory.json列出除自身外每个文件的SHA256与字节数，reproduce.py可用 --verify-only 检查。数值重放仍需代码所列现有mpmath依赖。
