# R180 finite weighted-geometry checks

The final same-alpha coefficient2A survives all13 exact fixtures, including a finite near-sharp ratio1.99719405. The off-capture exchange cost X and the masked b exchange cost are necessary: removing either fails an explicit Fraction example. Seven joint-union checks retain the strict strip boundary and tensor cross terms. These are finite algebraic certificates, not original FIRST/source/history realizations or a general weighted payment.

Run `python3 weighted_geometry_checks.py` from any directory. It writes the JSON beside the script. Fraction checks use only the Python standard library. The optional-in-scope physical section uses existing vendor mpmath1.3.0 and embeds two minimal physical convolution rows verbatim from frozen R179; it performs no new quadrature. The contract hash and original R179 file provenance SHA are recorded. The full R179 JSON is not a runtime dependency; row parameters, values and source resolution are embedded and preserved in the output. Unexpected exact failures and physical numerical failures are emitted separately in JSON; either causes a nonzero exit status. Physical success remains numerical, not interval-certified.

## Final same-alpha proposition and cases

For nonnegative nu,K,a,a', positive J, QJ=sum Jnu>0, D>=0 and Knu<=q, set

`alpha=(Dq-sum E min(a,DK)nu)/QJ`,
`Nbar=(a-DK-alpha J)_+^2/a`, with Nbar=0 at a=0,
`Nact=E Nbar`.

Both binary E masks may change. Define

`A=sum |a-a'|nu`,
`B=sum K|E-E'|nu`,
`X=sum min(Nbar,Nbar')|E-E'|nu`.

The author and independent auditor confirmed the improved final bounds

- |alpha-alpha'|QJ<=A+DB;
- sum |Nbar-Nbar'|nu<=2A+2DB;
- sum |Nact-Nact'|nu<=2A+2DB+X.

For actual numerical coefficients b,b' in[0,1], the last bound gains `sum min(Nact,Nact')|b-b'|nu`. Here these are abstract finite coefficients. They do not instantiate the original b_H, whose full Pi, support and eligibility masks remain outside this checker. The earlier3A coefficient is not treated as final.

The13 selected fixtures are split into three stages:

1. Four initial cases: identical data, simultaneous capture/active-a change, positive-small-K mask exchange, and saturated capture with alpha=0.
2. Five mask/zero-a pressure cases: zero a entering activity, all-zero a with mask changes, a zero-nu slot, zero-K off-capture exchange, and b-only exchange.
3. Four expanded cases: the prescribed near-sharp2A fixture, unequal D/J scales, threshold/mask crossing, and tiny source mass with large a/J contrast. No parameter grid is used.

Independent exact formulas check the signed relation `(alpha'-alpha)QJ=capture-capture'`; the normalization expansion `Nbar=a-2t+t^2/a` on a>t, t=DK+alpha J; the exact binary-mask decomposition; and positive homogeneity. Every hypothesis, every target inequality and Nbar<=a is verified with Fractions. No floating tolerance enters these checks.

In the prescribed near-sharp case, nu=(1,1), J=(1/1024,1), K=(1,1/1024), q=1+1/1024, D=1, E=E'=1, a=(1/2,1024), a'=(5/8,1024). The exact ratio is

`sum |Nbar-Nbar'|nu/A = 1074330623/537920000 ≈1.9971940493`.

This supports confidence in the algebraic coefficient2. It is not an original traffic lower bound or a statement about dimensional order.

## Failures of omitted costs

The checker records these intended failures, rather than silently discarding them:

- With one slot nu=J=D=q=1, K=0, a=a'=4 and E0->E'1, alpha remains1 and Nbar=9/4. Thus A=B=0, but actual masked variation is9/4. X=9/4 pays it exactly.
- The same failure persists with positive K=1/100: the masked variation is9/4, while2DB=1/50. The retained X=89401/40000 makes the final bound valid. Thus necessity is not confined to the zero-K edge.
- With the zero-K slot already captured in both rows, changing b0->b'1 gives weighted variation9/4 while A=B=X=0. Its b exchange cost is exactly9/4.

The corrected final inequalities pass all cases. No unexpected failure remains.

## Compact correction and strict joint strip

The geometry author's decomposition is C=C0+R, where C0=h*phi, R=h*[h(1-phi)]. The tensor correction is product C_i minus product C0_i and is bounded by the strict union indicator `exists i: |d_i|<b`. It is zero when every coordinate is on or outside the boundary. Convolution by a fixed product probability W retains the joint event; it is not replaced by a sum of coordinate prices.

Seven exact n1/n2 product-atomic-W fixtures check the event probability by two independent methods: Cartesian enumeration of z and `1-product_i(1-kappa_i)`. They include d=0,1/2,1,1.1,2 and mixed vectors. The exact boundary d=1,W=delta0 has strict probability0 and closed probability1. A closed event remains a looser upper bound, but it is not the same measurable joint-price event.

For formal compact kernels C0=1/4, R=(1/2)1{|d|<1}, each shifted tensor correction is independently computed three ways: product difference, expansion over every nonempty subset, and first-hit telescoping sum. All agree exactly and remain below the joint union indicator. These are formal finite kernels, not claims that those arrays equal physical C.

Two direct positive beta-times-nu double sums check the resulting energy price with all original finite masses retained. One has beta and nu incomparable atomwise. The inequality needs only positivity, not nu<=beta. No zeta=beta-nu positivity or signed-energy identity is used.

## Small physical reuse

For physical lambda=b=1 and s=1/4, reuse R179's D0 (50-digit,64/128 nodes) and D1 (30-digit,32/64 nodes) rows. They supply C,C0,w*C,w*C0. The physical strip mass is evaluated analytically as

`kappa(d)=(1-s)1{|d|<1}+s integral_(d-1)^(d+1) w(z)dz`,

using primitive sign(z)*(1/2-E3(|z|)). Product independence gives the exact-form union expression. The resulting comparisons are numerical because the reused convolutions are quadrature values, not directed intervals:

|d|Convolved compact tensor|Joint union probability|
|---|---:|---:|
|(0)|.43282243|.94515402|
|(1)|.02326620|.11746666|
|(0,1)|.10372459|.95159659|
|(1,1)|.00944527|.22113490|

All four comparisons pass numerically. At d1 the unshifted compact correction is zero but its convolution is positive, as required by the shifted joint event. This prevents incorrectly retaining the unshifted strip after convolution. No physical FIRST input, weighted source history, actual companion payment or general theorem is certified by these four numbers.

## Isolated replay

Copied only the final checker and task contract to `/tmp/r180_weighted_review/` and ran it. The full JSON matches exactly, including the embedded two-row R179 provenance, all Fraction results and physical diagnostics. The full historical R179 JSON is not accessed at runtime. Both exact and physical failure lists are empty. No repository replay directory or extra case was created.
