# 共同权审核：前缀势、有限断点与能量缺口

## 结论及必要约定

Astra 的指数共同权和 Jensen 下界有效。更强的是一个可直接有限计算的剪除版本：令
\[
b=a^{-n},\quad v_j=|E_j|,\quad w_j=v_j/d_j\le b,\quad
H_{<j}=\sum_{i<j}w_i\mathbf1_{A_i},\quad
L_j=\operatorname*{ess\,sup}_{A_j}H_{<j},
\]
\[
S=\sum_jv_jL_j,\qquad R=\sum_jv_jw_j\le bV.
\]
只需在有限个正断点 \(L_j,L_j+w_j\) 中选一个 \(t\)，即可构造共同可行权，并保证
\[
\boxed{P\ge \frac{V^2}{2S+R}\ge\frac{V^2}{2S+bV}.}
\tag{1}
\]
这一步没有 \(e\) 成本，没有无限维对偶，也不需要连续参数优化。

这里 owners 必须可测、两两不交，并满足 \(E_j\subset B_j\)、\(\bigcup_jE_j=\bigcup_jB_j\) a.e.，从而 \(\sum_jv_j=V\)。如果 owners 仅是任意互不交子集，则所有公式中的 \(V\) 应替换为 \(W=\sum_jv_j\)，不能直接使用 \(|\bigcup B_j|\)。标准按顺序归属 \(E_j=B_j\setminus\bigcup_{i<j}B_i\) 总能给出完整 owners。零 owner 的 \(w_j=0\)，对应共同权置零即可。

所有可行性结论对任意固定 order 成立；但所需的几何能量上界不能对任意 order 成立，见最后的真实方体例子。

## 1. 原指数权：有效；字面逐点性须处理边界

取 \(\tau>0\)，设
\[
\theta_j=\frac{w_j}{\tau}\exp\left[-\frac{L_j+b}{\tau}\right].
\]
有限族允许去掉一个共同零测集，使每个 \(x\in A_j\) 都满足 \(H_{<j}(x)\le L_j\)。固定这样的 \(x\)，按原顺序只列出含 \(x\) 的指标，记相应 active prefix 为 \(h=H_{<j}(x)\)。因 \(w_j\le b\)，
\[
\theta_j\le \frac{w_j}{\tau}e^{-(h+w_j)/\tau}
\le\int_h^{h+w_j}\tau^{-1}e^{-u/\tau}\,du.
\]
这些 active prefix 区间顺次拼成 \([0,H_{\rm total}(x)]\)，故
\(\sum_j\theta_j\mathbf1_{A_j}(x)\le1\)。这正是 \(P\) 要求的全空间 a.e. 共同可行性。

Jensen 给出
\[
\sum_jd_j\theta_j
=\tau^{-1}\sum_jv_j e^{-(L_j+b)/\tau}
\ge \frac V\tau\exp\left[-\frac{S/V+b}{\tau}\right].
\]
取 \(\tau=S/V+b>0\)，得到原声称
\[
P\ge\frac{V^2}{e(S+bV)}.
\]
还可将指数中的 \(b\) 逐项换成 \(w_j\)，证明完全相同，相应 Jensen 分母成为 \(e(S+R)\)。

**闭方体的“每一点”版本并不自动成立。** 例如 \(n\ge2\) 时，取 \(2^n\) 个等大、分居各坐标正负方向的闭方体，内部互不交且具有公共顶点；取完整的小方体作 owners，则 \(w_j=b,L_j=0\)。当 \(\tau=b\) 时，共同顶点总权为 \(2^n/e>1\)。这不影响 a.e. packing。若确实要求每一点，可把所有方体统一取半开约定 \(\prod_k[y_k-s,y_k+s)\)：有限族中每个点的 membership 与沿全正坐标微移后的一个正体积 cell 一致，因而前缀比较在每点都成立。所有体积、积分和 \(P\) 均不变。

## 2. 共同凹势引理与显式剪除权

设 \(F:[0,\infty)\to[0,1]\) 递增、凹且 \(F(0)=0\)。定义
\[
\theta_j=F(L_j+w_j)-F(L_j).
\tag{2}
\]
在上述共同满测集上，\(h=H_{<j}(x)\le L_j\)。凹函数的固定长度增量随起点递减，故
\[
0\le\theta_j\le F(h+w_j)-F(h).
\]
沿含 \(x\) 的 active prefixes 望远镜求和，得到
\(\sum_{j:x\in A_j}\theta_j\le F(H_{\rm total}(x))\le1\)。因此 (2) 是全族共同可行权。这里 \(L_j\) 是固定标量，\(\theta_j\) 不随被测试点 \(x\) 改变。

取 \(F_t(u)=\min(u/t,1)\)，\(t>0\)，得到
\[
\boxed{\theta_j(t)=\frac{\min\{w_j,(t-L_j)_+\}}{t}.}
\tag{3}
\]
于是 \(L_j\ge t\) 者权为零；\(L_j+w_j\le t\) 者保留 \(w_j/t\)；跨越阈值者仅保留剩余增量。这是带部分截断的真实共同权，直接逐点前缀证明可行，不能只用“好指标总质量”代替它。

## 3. 有限正断点最大值，以及 (1) 的独立证明

记其目标函数
\[
g(t)=\sum_jd_j\theta_j(t)
=\frac1t\sum_jd_j\min\{w_j,(t-L_j)_+\}.
\]
删去 \(w_j=0\) 的行。每行仅在 \(L_j,L_j+w_j\) 改变表达式，因此在任意相邻正断点之间，\(g(t)=A+B/t\)，必单调或常值。\(g\) 在所有正断点连续，且 \(g(t)\to0\) 当 \(t\to\infty\)。在最小正断点之前，所有 \(L_j=0\) 的活跃行贡献 \(d_j\)，其他行贡献零，所以该段也是常值，并在首个正断点取得。故
\[
\kappa:=\sup_{t>0}g(t)
=\max_{t\in\mathcal B}g(t),\qquad
\mathcal B=\{L_j>0\}\cup\{L_j+w_j>0\},
\tag{4}
\]
其中集合只包括实际出现的数值，数量至多 \(2m\)。选使 (4) 最大的一个断点并使用 (3)，即得一个共同权证书。若原方体坐标及标准 owners 的体积为有理数，membership cells、\(L_j\)、断点和共同权均可用有限有理运算精确核验；对任意实数据，结论仍是有限实数运算，不应无条件称其有理。

为证明 (1)，令
\[
Z(u)=\sum_jd_j\mathbf1_{[L_j,L_j+w_j]}(u),\qquad
G(t)=\int_0^tZ(u)\,du=tg(t).
\]
端点取值无关积分。有限和直接给出
\[
\int_0^\infty Z=\sum_jd_jw_j=V,
\qquad
M:=\int_0^\infty uZ(u)\,du
=\sum_jd_j(L_jw_j+w_j^2/2)=S+R/2.
\]
Tonelli 给出尾积分恒等式
\[
M=\int_0^\infty(V-G(t))\,dt.
\]
因 \(G(t)\le\kappa t\)，且 \(0\le G(t)\le V\)，
\[
M\ge\int_0^{V/\kappa}(V-\kappa t)\,dt
=\frac{V^2}{2\kappa}.
\]
因此 \(P\ge\kappa\ge V^2/(2S+R)\)，完成 (1)。\(V>0\) 时 \(R>0\)、\(M>0\)、\(\kappa>0\)，没有零分母问题。

系数 \(2\) 在只保留 \(S,R,V\) 的这种普适不等式中已是尖锐的：取 \(m\ge2\) 个重复的大方体 \(A\)，把同一个 \(B\) 等体积分为 \(m\) 个 owners。此时 \(P=d,V=bd,w_j=b/m,L_j=(j-1)b/m\)，并且 \(2S+R=db^2\)，(1) 恰给出 \(P\ge d\)。将 \(2S\) 换成任何 \(cS\)、\(c<2\)，都会在此真实几何例中给出错误的严格更大下界。

## 4. 有目的的几何筛查：顺序必要，下降顺序仍未解决

**任意 order 的根阶能量界不可能成立。** 固定任意 \(n\ge1\)、\(a=32n\)，取
\[
s_j=4^{j-1},\quad y_j=s_j(1,\ldots,1),\quad
A_j=[0,2s_j]^n,\quad E_j=B_j.
\]
各 \(B_j\) 两两不交，因此这是完整、真实的 owners，不是抽象图模型。按此半径递增 order，\(w_j=b\)，所有此前 \(A_i\) 在 \(A_j\) 内有共同正体积交，从而 \(L_j=(j-1)b\)。设 \(q=4^n\)，则 \(v_j\) 按比率 \(q\) 增长，故
\[
\frac SV\ge (1-q^{-1})(m-1)b\longrightarrow\infty\qquad(m\to\infty).
\]
因此不存在对所有 order 成立的 \(S\le C\sqrt n\,V\)。反转为半径递减 order 时，同一个例子满足 \(S/V\le b/(4^n-1)\)，所以它没有否定指定递减 order 的目标。

**递减 order 中也不能把 \(L_j\) 免费替换成 owner 上的平均或中心值。** 在一维取若干半径递减且至少为 \(4\) 的前置区间
\(A_i=[-2s_i-1/2,-1/2]\)，半径按足够大的几何比相隔；最后取 \(A_*=[-1,1]\)。取各自完整且互不交的 \(B_i,B_*\) 作 owners，便有 \(w_i=b\)。所有前置区间在 \([-1,-1/2]\) 重叠，所以 \(L_*=mb\)；但它们全都避开 \(B_*=[-1/a,1/a]\)，故 \(H_{<*}=0\) 在整个 owner \(E_*\) 上成立。这个例子只否定“远处 esssup 可直接变成 owner 平均”的操作，不否定全族能量预算，因为早先大尺度 owners 的体积可能承担代价。

所以新权确实把目标归约为真实方体、完整 owners 和合适 order 下的全族能量/容量预算；目前尚未证明 \(S\lesssim\sqrt n\,V\)。若此预算以常数 \(C\) 成立，则 (1) 才推出
\[
P\ge\frac{V}{2C\sqrt n+b},\qquad
T_a\le2C\sqrt n+b,
\]
继而由已证 packing 入口得到纯 \(O(\sqrt n)\)。这是假设后的条件推论，不是已经完成的根阶证明。

## 5. 实际工具核对

已运行本机 Python `Fraction` 作精确有理核验；计算证据不替代以上证明。

- 一维 \(a=32\)，依次取 \(A_1=[-3,1],A_2=[0,2],A_3=[3/2,5/2]\)，各自完整小方体 owners 两两不交。实际得到 \(L=(0,1/32,1/32)\)，最佳正断点 \(t=1/32\)，共同权 \((1,0,0)\)，各正体积 membership cell 的最大负载恰为 \(1\)；目标值 \(4\ge49/13=V^2/(2S+R)\)。
- 上述真实嵌套区间族取 \(n=1,m=256\)，递增 order 的 \(S/V\) 约为 \(7.958333333333\)，递减 order 约为 \(0.010416666667\)。递增例的下界 \(S/V\ge765/128\) 已用精确有理比较核对。

文件在此冻结；不把局部、单尺度或抽象图估计替代所需的全族纯根阶预算。


## 补记：二次势的同一代数下界（2026-11-15 最终冻结）

令 \(T=(2S+R)/V=2M/V>0\)，取
\[
F_T(u)=1-(1-u/T)_+^2,\qquad
\theta_j^{\rm quad}=F_T(L_j+w_j)-F_T(L_j).
\]
其导数 \(k_T(u)=\frac2T(1-u/T)_+\) 非负递减且积分为 \(1\)，因此第 2 节的共同可行性适用。并且对所有 \(u\ge0\)，\(k_T(u)\ge\frac2T(1-u/T)\)，故
\[
\sum_jd_j\theta_j^{\rm quad}
=\int_0^\infty k_T(u)Z(u)\,du
\ge\frac2T\left(V-\frac MT\right)
=\frac{V^2}{2M}=\frac{V^2}{2S+R}.
\]
这是显式二次势的代数证书。有限断点版本已经由第 3 节独立证明达到相同下界，不需要额外证明二次势是 ramp 的混合。

同一个 3 区间实际样例已另运行 `Fraction` 精确核验：\(T=13/224\)，二次势权为 \((133,36,36)/169\)，最大 a.e. 负载为 \(1\)，目标 \(640/169\)，下界 \(49/13=637/169\)，差为 \(3/169\)。此补记只核验新二次势算术，未重复运行已有检查。至此源码最终冻结。
