Print["VERSION=", $Version];
Clear[s, w, b, t, A, V, d, e, f];
ass = s >= 0 && 0 <= w <= b && b > 0 && t > 0;
i = Integrate[Exp[-(s+x)/t]/t,{x,0,w},Assumptions->ass];
Print["prefix_integral=",FullSimplify[i,ass]];
Print["prefix_derivative=",FullSimplify[D[1-(1+w/t)Exp[-w/t],w],w>=0&&t>0]];
Print["optimal_tau_derivative=",Factor[D[(V/t)Exp[-A/t],t]]];
Print["calibration_residual=",FullSimplify[(V+d/e)(V-d/f)-V^2-d*((f-e)*V-d)/(e*f)]];
Print["gain_residual=",FullSimplify[(V-d)+d-V]];
