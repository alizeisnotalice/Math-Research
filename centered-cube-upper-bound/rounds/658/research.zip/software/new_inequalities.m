disp(version);
syms s w b t A V real
assumeAlso(t>0); assumeAlso(w>=0); assumeAlso(A>0); assumeAlso(V>0);
f=(V/t)*exp(-A/t);
df=simplify(diff(f,t)); disp(df);
assert(isAlways(simplify(subs(df,t,A))==0));
res=simplify(int(exp(-(s+w)/t)/t,w,0,b)-(exp(-s/t)-exp(-(s+b)/t)));
disp(res); assert(isAlways(res==0));
res2=simplify(diff(1-(1+w/t)*exp(-w/t),w)-w*exp(-w/t)/t^2);
disp(res2); assert(isAlways(res2==0));
q=(1+1./(32*(1:512))).^(1:512);
assert(all(q<32/31));
fid=fopen(fullfile(fileparts(mfilename('fullpath')),'matlab_result.txt'),'w');
fprintf(fid,'MATLAB %s\nSymbolic derivative and two residual assertions passed.\nFloating q check n=1:512 passed; not a general proof.\n',version); fclose(fid);
