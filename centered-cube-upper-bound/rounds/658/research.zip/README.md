# R658 可复核研究包

纯 C_n≤K√n 与旧一般目标均未证明。先读 REPORT.tex，再读两份 FINAL 独审。未编译 PDF。

本包是一个完整研究轮次。新严格结果是共同权证书和一次来源付款；恢复/动作权限是历史工具独立重推。656份README仅等于摘要通读；重点原证明的实际读取范围在 reading_*.json。SOURCE_INDEX.json 支持按原仓库逐字节核对，但哈希不认证证明。历史笔记中的 sources 本地提取路径只作审读追踪；网页链接指向固定版本原ZIP，成员及行号写在标签中，未重复打包历史原稿。

## 验证

```sh
python verify.py --replay --scratch /Volumes/data/CodexTemp/ccu-r658-replay
python verify.py --source-repo /path/to/Math-Research
```

便携精确重放使用Python标准库Fraction；不重求浮点LP，不使用MATLAB许可证，不验证一般上界。原生产器的额外依赖见记录。local_payment只保留再生代码及关键输入/摘要，多数KKT残差未达标准，不属于数学证书。

实际工具：指定Python数学环境；Wolfram15.0符号输入/输出；MATLAB R2026b Update1命令行符号断言。MCP脚本接口曾报jupyter.Idler，之后通过命令行完成。无可靠API扣额记录；12-worker配置不等于持续占满CPU。
