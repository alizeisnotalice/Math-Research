# R261—R390：共同来源、对称差、二次捕获与终端预算

本次通读130份README（283226字节），全文读取31个ZIP证明/审计成员。逐件SHA256、读取范围及解出路径见[reading_261_390.json](/Volumes/data/CodexTemp/centered-cube-sqrt-20261114/reading_261_390.json)。下述“已复核”限于这些实际读取的原证明；其余历史工具明确标为README级索引，没有用旧PASS收据代替本次验算。本次只运行R302主证明内嵌的有界Fraction检查，共504项通过：对称差24、clip264、低累计层108、联合预算108；没有重跑全部历史数值，也没有昂贵计算。

**结论：本范围没有证明一般弱型上界，旧的 $n^{1/2+o(1)}$ 也未完成。** 最有价值的成果是：(i) 把原低pe交通接到一个共同可实现的截断捕获费用；(ii) 将费用分成根阶来源主项和准确的 $B_H$ 对称差；(iii) 在严格硬匹配合同下，以真实接收中心容量支付质量可比及若干远质量分支；(iv) 用一个来源势支付任意长剥离，但仍留下自维持核心；(v) 后期完整来源见证可以支付实际整行/入列的正份额，尚无统一覆盖比例。对纯 $\sqrt n$ 目标，历史中的 $\sqrt n\log^A n$、$\sqrt{n\log n}$、以及外层全尺度拼接费用都还必须重新处理，不能只处理最后一个余项。

## 1. 合同先行：三个对象不能按名称相接

1. **R301—R305一般软槽。** 固定一份原外层场，任意有限正L1来源 $\beta,\nu$，$a\le L,R\le b\le2a$，$q_-=3\lambda/4\le q\le\lambda$。原FIRST只作用于实际接收点；硬帽是同一实际接收点、合法半径上的帽。来源/历史掩码保持完整，接收积分是实际 $dx$。一般估计不假设 $\nu\le\beta$，不能把核包络的Lebesgue质量当作任意 $\beta\times\nu$ 的来源预算。
2. **R329以后硬匹配槽。** 明确要求 $\beta=f\,dy,\ \nu\le f\,dy,\ s=0,\ L=R,\ \alpha=1$，真实 $q_u=R_u^{-n}f(Q_u)$，$m_u=q_uR_u^n$，$\mu(du)=du/m_u$。这一合同提供可交换的同源匹配和真实接收中心几何；这些条件不是R302一般软槽自动具有的。见[336 core \1 [336/core.md:17]](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/336/research.zip)。
3. **完整原始事件/新native入口。** R316得到 $X_{band}\le(768/767)(P_{104}+H_{native})$，不是 $H_{native}=R_{out}=B_H$。后续出生、粗包、根网格等支付的是其明确子支。不能将新入口与旧R_out的来源费或接收吸收系数相加后宣称全事件闭合。索引见[316 README](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/316/README.md)、[321 README](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/321/README.md)。

R304重新核回的旧总账仍含

\[
\Lambda T_{small}\le E_5X+C_G\sqrt n W_\beta+\Lambda T_{low}
+2\Lambda(I_{rem}+J_{rem}+D_{rem}+P_{suffix}-N_{Z^c}-N_{del}),
\quad\Lambda=128/119.
\]

原已组装接收误差是

\[
19/768+\Lambda(\varepsilon_{tree}+\delta_{tail}+k_0\kappa_n+\varepsilon_{LP})
+\varepsilon_{neartime}+\varepsilon_{FA}+\varepsilon_{IJ}+\varepsilon_D+\varepsilon_G.
\]

本次读到的R304原件明确：这不是完整采用清单，不认证全局误差和小于一；原全事件到R_out连接也未完成。$T_{low}$ 只乘一次 $\Lambda$，没有高连续槽的额外2或 $dt/t$。$J_{rem}$ 是真正删除时间原子；$D_{rem}$ 的未来被删来源不是终端good；两项负信用只能在原共同测度上各用一次。详见[304 global ledger §C—F [304/r304_global_ledger.md:47]](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/304/research.zip)。

## 2. 近来源和核几何：可复用的局部工具，不能消灭宽距离

这组为README级机制索引，未逐篇重新认证其ZIP证明。

- **R261—262后缀恢复。** 将恢复精确拆成初始 $Q/e^2$、真实删除Q原子、连续 $2\int e^{-2}\sum(m-k_c)Q$。初始项可与同一bad边界合并付款，不能将旧H表示和新Q表示逐项择优免费混用；signed连续恢复、删除净超额和互补分支未付。见[262 README](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/262/README.md)。
- **R263—270全尺度核与局部来源容量。** 嵌套接收族可去尺度菜单数；Abel保真实下端与末端clock。两移动腿有平方质量缺口，J腿只有半密度/分数次方工具，不能假装同样L2 gap。R267实际抽取局部容量份额，费用 $O(\sqrt n\log^3 n)$，高局部质量互补未付；R268—270按正向核心、反向、核心外划分扩展可付份额，仍无全部饱和补源付款。见[264 README](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/264/README.md)、[267 README](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/267/README.md)、[270 README](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/270/README.md)。
- **R271—279共同存活/终端加载。** Schur压缩和中心转移减少双clock与近位移费用，仍留下同一来源对主量。集中尾/J认证/移动大缺口可支付明确正子支；R279余域限制 $ns+R_2\le C_0+C_1\log(n+2)$，$R_2=\sum\min(|y_i-v_i|^2/b^2,1)$。常数极大，不能推出有限维非空覆盖或bad槽也有同样帽。见[273 README](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/273/README.md)、[279 README](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/279/README.md)。
- **R280—287两帽与守恒分配。** 核心标量是 $I(A,B)=\min(A,B)[2+\log(\max/\min)]\le2\sqrt{AB}$。不交来源胞内部由此避免单来源极大尺度包络的n损失；单切割、潜在软矩形、单侧细化保覆盖，却有形状熵、细胞地址或实际选择器费用。R283消掉细化深度nK，仍有 $\kappa_0=2+\sqrt n/8$，乘原score后回到线性量级。R284—287以低份额、双侧低邻域质量、实际双捕获及大质量随机包支付正份额；其补集可以承载全部交通。见[280 README](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/280/README.md)、[283 README](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/283/README.md)、[286 README](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/286/README.md)。
- **R288局部线性位移改进，R289范围纠偏。** 小soft时硬支撑对称差给一阶 $\sum\min(|y_i-v_i|/b,1)$ 缺口，能支付当前moving的tiny-near正祖先。真实原near只推出来源距离 $\|y-z\|_1\le17na$，并不推出 $a/(16\sqrt n)$。故仍有真实宽距离low-pe、高连续、I/J/D。R289确认的是范围修正，不是R288局部不等式失效。见[288 README](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/288/README.md)、[289 README](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/289/README.md)。

R290—300转向全域共同覆盖：矩形容量 $2+\sum_i\log(1+d_i/a)$、固定跨胞偏移双射、实际低pe截断、逆向变差只对未饱和尾收费、自身尺度见证和Poisson覆盖。共同问题一直是**未知偏移/方向的选择成本、来源集中费用、覆盖失败的实际交通**。R296全方向高度界给单对数局部来源积分，远尾可直接付 $\varepsilon W_\beta$；R298—300有限分式覆盖、容量停止有严格证书，却没有全部输入的根阶覆盖成本。见[290 README](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/290/README.md)、[296 README](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/296/README.md)、[300 README](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/300/README.md)。

## 3. R301—302：原证明已复核的最小有用链

定义合法且与硬来源z无关的原行门 $\alpha$，必须支配同一目标掩码；

\[
U_y(x)=\alpha(x,y)1_E(x)p_y(x)/q(x),\quad
A_{yz}(r)=\int_{R(x)\le r}1_{Q_{R(x)}(x)}(z)U_y(x)dx,
\quad J_y(r)=\int_{R\le r}U_y dx.
\]

取辅助层测度和原aspect价格

\[
\ell_n=b^{-n}\delta_b+nr^{-n-1}1_{(a,b)}dr,\quad
\ell_n([s,b])=s^{-n},\quad
d=\frac{\kappa_0\psi_\infty}{q_-v_0},\quad
\kappa_0=\frac{2K}{(1+\log n)M},\quad
\psi_\infty=3-\frac2{3(1+1/n)^n}.
\]

这不是用 $\ell_n$ 替代接收dx，而是实际最小见证容量的层蛋糕恒等式。原目标仍限 $v(L,R)=\min(1,(L/R)^{n/2})\ge v_0$。

**共同Poisson率。** 在每行用强度 $tU_y dx$，不先除以行质量 $I_y$。令

\[
C(t)=\int\beta(dy)\nu(dz)\ell_n(dr)(1-e^{-tA_{yz}(r)}),
\qquad O_d=\int\beta\nu\ell_n\min(d,A_{yz}).
\]

R301给

\[
T_{target}\le(d+1/t)C(t),\qquad
O_d\le\inf_{t>0}(d+1/t)C(t)\le2O_d,
\qquad T_{target}\le2O_d
\]

最后一步由**一个可实现共同率 $t=1/d$** 得出。$O_d$ 是这族上界费用的下界，不是交通的下界。包含式CDF的原子亏损非负，真实rank积分是 $dA$，若误用归一CDF会漏掉 $I_y$。合法缩小同一目标的z无关行门会使C、O下降；不能把依z的资格当作共同采样行门。证据：[301 geometry §2—4 [301/r301_geometry.md:40]](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/301/research.zip)、[301 common rate §1 [301/r301_common_rate.md:20]](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/301/research.zip)、[301 audit §2 [301/r301_audit.md:22]](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/301/research.zip)。

**对称差与二次捕获。** 令 $M_y(r)=\int A_{yz}(r)\nu(dz)$，

\[
Q_y(r)=\tfrac12\iint_{R(u),R(v)\le r}U_y(u)U_y(v)\nu(Q_u\triangle Q_v)dudv
=J_y(r)M_y(r)-\int A_{yz}(r)^2\nu(dz),
\]

\[
B_H=\int\beta(dy)\ell_n(dr)1_{J_y(r)\ge H}\frac{Q_y(r)}{J_y(r)}.
\]

原证明的核心只有点态clip不等式

\[
\min(d,A)\le(d/J)A+A(1-A/J),\quad0\le A\le J.
\]

因此

\[
O_d\le4\lambda H W_\beta+\frac dH A_nW_\nu+B_H,
\quad A_n=1+n\log(b/a).
\]

小J层利用实际同半径硬帽与 $\ell_n([s,b])=s^{-n}$，只付一次 $4\lambda H$，**不乘尺度层数**。跨H原子整颗排除在严格低侧；b终端原子保留。大J层FIRST共同支付一份 $A_nW_\nu$。取 $H=\sqrt{dA_n/(4\lambda)}$，

\[
T_{target}\le4\sqrt{\lambda dA_n}(W_\beta+W_\nu)+2B_H.
\]

对质量不等的来源也可选 $H_*=\sqrt{dA_nW_\nu/(4\lambda W_\beta)}$，但必须在同一H*重新计算BH。该root主项只在 $\lambda d$ 受控时根阶；小 $v_0$ 的逆价格完整保留。**无条件仍只有 $B_H\le A_nW_\nu$**；高行质量并未强迫捕获一致。BH是上界中的辅助费用，不是原交通精确剩余掩码。详见[302 geometry §1—5 [302/r302_geometry.md:30]](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/302/research.zip)、[302 audit §5 [302/r302_scale_audit.md:78]](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/302/research.zip)。

**双尺度点值与来源积分的分离。** R302两套实际选择器先正包络再卷积，得到

\[
\int P=A_n^2C_{soft,n},\qquad
\|P\|_\infty\le C_{soft,n}(2a^{-n}-b^{-n}),\quad
C_{soft,n}\le1+\pi\sqrt n/2.
\]

关键精确抵消是

\[
\iint\max(L,R)^{-n}\mu(dL)\mu(dR)=2a^{-n}-b^{-n},
\quad\mu=\delta_b+n\,dL/L.
\]

点值没有 $A_n^2$，但L1质量仍有。只有真实局部列质量 $\beta(Q_{2Db}(z))\le q_-a^nL_0$ 时，才得 $T_{light}\le2C_{soft,n}L_0\nu(Z_{light})$。R303严格软坐标收缩进一步把点值Csoft改为 $1/(1-\rho)$，仍不支付重局部列。R302另有固定共同soft卷积尺度包络 $O(\sqrt{n\log n})$：三角分布score二阶矩无限，Winsor截断保留 $2n/B$ 尾费；它不能用作任意接收点选择器卷积或任意来源积分。详见[302 pair kernel §2—5 [302/r302_pair_kernel.md:42]](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/302/research.zip)、[302 scale geometry [302/r302_scale_geometry.md:1]](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/302/research.zip)。

## 4. $B_H$ 的勘误与资格变化：不能省掉的内部差

**R304的真实资格版本。** 用同一Poisson接收器加uniform标记保留 $b_y(x,z)=I_0/\alpha$，可得真实捕获A*和

\[
O_d^*\le T\le2O_d^*,\qquad
T\le64\lambda dW_\beta+4B^*_{4d}.
\]

这是同一有限T的内部吸收，未新增全局 $\varepsilon X$。但独立标记下，源y、两接收器u,v及硬源z的差为

\[
c_u(1-c_v)b_u+c_v(1-c_u)b_v+c_uc_v(b_u+b_v-2b_ub_v).
\]

最后一项在共同立方体内部也可非零；即使两立方体相同仍有资格/标记方差。**$A^*\le A$ 只使O*变小，不能推出 $B_H^*\le B_H$**。这一点是后续最重要的范围修正之一。R305共同阈值使差缩为 $|c_ub_u-c_vb_v|$，可去掉人工独立标记方差，却保留真实二值资格差。取整m层权总和为1，误差每份至多 $A_nW_\nu/m$；多个误差必须各计系数。详见[304 geometry §4—5 [304/r304_geometry.md:114]](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/304/research.zip)、[305 README](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/305/README.md)。

**物理半径势与真正时间原子。** 令 $V(J,A)=\int(A-A^2/J)d\nu$，则

\[
V(J+h,A+a)=V(J,A)+V(h,a)+\frac{Jh}{J+h}\int(A/J-a/h)^2d\nu.
\]

V随前缀非减，$B_H=\int s^{-n}d[1_{J\ge H}V]$。新增块内方差与块间平方是正费用；不能把“平方”字样当作新负信用。首次跨阈值原子、并列半径及终端b原子全保留。R313初始化、R327硬核单原子帽、R328大相对原子付款只处理物理半径原子，不能代付旧历史的初始项或真正删除时间跳跃。见[304 joint potential [304/r304_joint_potential.md:6]](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/304/research.zip)、[313 README](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/313/README.md)、[328 README](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/328/README.md)。

**窗口与低次数不保证实际付款非空。** R306—310支付远尺度失捕、快速增长、高次数/高soft子支，剩近尺度、新捕获、低次数/浅外深度。森林临界尺度应为 $\min((h/q)^{1/n},\sqrt b(h/(q\sqrt n))^{1/(2n)})$，不是第二根前乘b。R311指出canonical FIRST有 $s>1-2^{-1/n}\ge1/(2n)$，旧极小soft门在该合同为空；R310多数组合证书门也为空或旧主价超root。不能把这些条件子支当作困难余项普遍减少。见[306 README](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/306/README.md)、[310 README](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/310/README.md)、[311 README](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/311/README.md)。

## 5. 硬匹配中真正可用的全源质量比估计

R314—335经过赢家接触、薄壳、来源容量、完整平方/Gram、共同接收势与极值特征接口，逐渐转入硬匹配。赢家不能免费替换旧冻结选择器，真实缺额 $D_{eff}$ 必须付；$B_k\to0$ 的边界来源近似无输入一致网格精度。有限LP/QP或极值特征强收敛证明均不提供root系数；合并来源的并型可实现性及重数也需独立核验。索引见[314 README](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/314/README.md)、[332 README](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/332/README.md)、[335 README](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/335/README.md)。

R336—338原证明已复核，得到更直接的真实du结论。记 $c_u=1_{Q_u}$，在硬匹配合同中

\[
B_H(f,\nu)=\int\ell_n(dr)\int\frac{f(y)1_{J_y(r)\ge H}}{J_y(r)}
\iint_{E_r^2}c_u(y)c_v(y)\nu(Q_u\setminus Q_v)d\mu(u)d\mu(v)dy.
\]

固定u,y的近质量接收容量精确为

\[
\int1_{K^{-1}\le m_v/m_u\le K}c_v(y)d\mu(v)
\le\frac{1+2\log K}{q_-}.
\]

证明只积分真实中心密度 $\min(K/m_u,1/(q_-t))1_{t\le Km_u/q_-}$，$t=(2\|v-y\|_\infty)^n$ 是体积坐标，没有来源密度帽。原strict low-J停止只计一次 $\lambda T W$，得近质量全支

\[
B_{near}\le\delta X_q+\frac{\lambda(1+2\log K)}{q_-\delta}W.
\]

小质量捕获→大质量漏失的有利方向另有 $\delta X_q+\lambda W/(Kq_-\delta)$；逆方向不能沿用。见[336 core §1—2 [336/core.md:32]](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/336/research.zip)、[336 directional [336/directional.md:18]](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/336/research.zip)。

R337精确保留 $I_{uv}=f(Q_u\cap Q_v)$，只有正支配到全f槽以后才可相消：

\[
B_H(f,f)=B_{near}+2B_{fav}+G_K,
\quad G_K=\int\ell\frac{f1_{J\ge H}}J c_uc_v(m_u-m_v)1_{m_u>Km_v}d\mu d\mu dy.
\]

**有利方向出现两次**；旧一次付款不能复用两次。联合低clock可避免重复低层来源费。再付全局严格过去 $Z_y(m_u/K-)\le h$，得到

\[
B_H(f,\nu)\le G_{K,>h}+\varepsilon X_q+
\left\{\frac\lambda{q_-\varepsilon}(1+2\log K+2/K)
+\lambda h+\frac\lambda{q_-}(1+\log K)\right\}W.
\]

取 $K=e^{\sqrt n}$、$h=\sqrt n/q_-$ 付root来源价，仍留高过去。质量远比不是空间远离：同octave中它对应约 $e^{1/\sqrt n}$ 的半径比。见[337 main [337/main.md:34]](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/337/research.zip)。

R338若与y无关的中心关系D逐u满足 $|\{v:(u,v)\in D,m_v<m_u/K\}|\le LR_u^n$，则 $G_D\le LX_q/(q_-h)$。用 $h=(1+\sqrt n)/(\varepsilon q_-)$、$\alpha=(1+\sqrt n)^{1/n}$，中心区域 $\|v-u\|_\infty\le\alpha R_u/2$ 可付 $\varepsilon X_q$，**只要求小cube中心位于膨胀大cube内，不要求小cube整颗包含**。所以

\[
B_H(f,\nu)\le G_{out}+2\varepsilon X_q+C_{\varepsilon,n}W,
\quad C_{\varepsilon,n}=\frac\lambda{q_-}
\left[\frac{2+3\sqrt n+2e^{-\sqrt n}}\varepsilon+1+\sqrt n\right].
\]

这是全硬槽的一般有效部分预算；Gout仍有高过去、远质量比、原H/J/clock、共同来源及中心外侧。见[338 main [338/main.md:12]](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/338/research.zip)。直接正pair路线不另加 $\lambda HW$ 的“补齐费”；若选 $a_H-Q_{all}$ 的另一放松才保留其补齐费用，原入口 $8\lambda HW$ 则仍在。

## 6. 重来源与终端预算：真实来源边缘才是瓶颈

R339—349局部化全局heavy为局部增长good，真实源格完整分割可付更大集合；伴随L4矩仅支付外层截平来源。任何来源拆分都保持m、q、J及全部门按完整f计算。闭质量窗的真实容量 $(1+\log K)/q_-$ 允许严格上尾、相对终端上尾和Top-hit的明确分支付款，仍留late/high-density。**共同捕获流的来源边缘通常是 $fJ_b$，不是f**；$\int fJ_b=|E|$ 可以结算接收预算，不能当成W。熵、后验换源、Schur小范数或每源质量漂移都未自动控制重复费用。见[343 README](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/343/README.md)、[346 README](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/346/README.md)、[349 README](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/349/README.md)。

**R350—351共享来源势（已复核）。** 真实质量秩路由给新见证入列 $\kappa(w)\le q_w$，后验换源只选完整f。几何占用 $D_A(z)=\int_A c_w(z)R_w^{-n}dw$ 满足外部固定指数强型所给伴随矩 $\int D_E^4\le C^4|E|$。本次未重新验证该外部文献定理；以下是其明确条件下的直接推导。定义

\[
\Psi_z(d)=f(z)\min(d,s)+\min(f(z),T)(d-s)_+.
\]

逐轮删除非浓缩见证，可望远镜结算

\[
\theta X_q(E\setminus E_\infty)
\le\int[\Psi_z(D_E)-\Psi_z(D_{E_\infty})]
\le sW+TC^4X_q/(q_-s^3).
\]

$s=1+\sqrt n,\theta=1/4,T=\varepsilon q_-s^3/(64C^4)$ 时，**整个可数级联**只付一次 $(\varepsilon/16)X_q+4(1+\sqrt n)W$，替换R350单轮费用，不叠加。极限只能得到闭门 $D_{E_\infty}\ge s$ 及后验比例 $\ge3/4$，不能声称严格阈值固定点。核心以自身占用维持浓缩，但未证明为空或可付。见[350 main [350/r350_main.md:35]](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/350/research.zip)、[351 geometry §1—5 [351/r351_geometry.md:41]](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/351/research.zip)。

**R352—362路径与正常终端。** 首次祖先回捕、内缩source、方向集中、高面数可付正支；剩余路径薄边界且每tuple低面数，不等于每代可重复根阶来源费。R355证明同步旧hard高过去门首次可能n=1458，过必要门不证明困难输入存在；少半径均匀格点族highpast为空，不能继续放大此族冒充核心实测。R358能量 $F_{low}^2\le2\Delta WJ_{inj}$ 保留注入重复；Jinj尚无对数预算。见[355 README](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/355/README.md)、[358 README](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/358/README.md)。

本次复核R360—361终端证明：canonical续跳分A（内目标/共享活跃面）与D（不交面），共同列预算 $\sigma(A+D)\le\sigma$，高维 $\sigma A\le c\sigma, c\le3/8$。初始注入I≤σ，native正常终止β满足 $\sigma\beta\le b_*W$。**首次D之前所有终端**一次付 $b_*W/(1-c)\le(8/5)b_*W$。这只给首次D目标入流上界，不能在其后每次重新收费或重新赋旧历史资格。

R361正确更新次序是 $R=(I-A)^{-1}, H=RD, h=R\beta, \eta=\sigma-\sigma A$，满足 $\eta H\le\eta$、$\eta h\le b_*W$。于是恰k次D的终端 $T_k\le b_*W/(1-c)$；加到 $L=\lceil\log(n+2)\rceil$ 得 $O(\sqrt n\log n)W$，**没有 $\sum_{k>L}T_k$ 的免费预算**，因为η仅次不变、不严格收缩。删除部分终端后必须重新计算终端方向来源列，否则旧比例未必保留。见[360 terminal §3—5 [360/r360_terminal.md:42]](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/360/research.zip)、[361 renewal [361/r361_renewal.md:7]](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/361/research.zip)。

R363—365是另一替代路线：远来源第一矩+近来源方差可乘法比较BH，双高共同来源core仍未付。R364若采用 $F_{far}\le F_{core}+3\lambda HW$，原入口8λH改成14λH，不能叠加旧路径的平方信用或终端付款。见[363 README](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/363/README.md)、[364 README](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/364/README.md)。

## 7. R368后期勘误：恢复较强路线，避免在已付区域继续细分

R366/367近包含N与联合外突A的解析付款有效，但R368重新核R338后确认：**N/A及中心回捕候选C均在R338已付中心内侧，不能当成较强路线的新增覆盖，也不能额外加费。** 真正新支是中心外侧上允许 $R_v\ge3R_u/4, \sum_i(2|u_i-v_i|-(R_u-R_v))_+\le nR_v/64$ 的D。实际小端半径至多n箱，每箱真实中心容量 $\le e^{-n/4}/q_-$，合并 $d_n=ne^{-n/4}<2$，由原高过去门直接付 $\varepsilon_0d_nX_q/(1+\sqrt n)$，无需新增来源费。该式替换旧费用。见[368 history correction [368/r368_history.md:26]](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/368/research.zip)、[368 main [368/r368_main.md:3]](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/368/research.zip)。

R369扩到全半径比B+，总中心容量常数<72（不能借较小备选门的<5常数）；R370进一步得到全较小半径的均匀交叠包络，原证明已复核：

\[
p_s(x)=\frac{|Q_R\cap(x+Q_s)|}{R^ns^n},\qquad
\int\sup_{0<s\le R}p_s\le1+\frac n{2(\sqrt n+1)}+2\sqrt n\sqrt{\tfrac14+\tfrac12\log(1+\sqrt n)}.
\]

是 $O(\sqrt{n\log n})$，无额外 $\log(R/a)$。独立性只来自Lebesgue归一梯形中心密度，不施加于f；score二阶矩发散，截尾中心化保留真实半径比才消掉scale-log。

对原source-dependent mark $\omega_u(y)$ 完整保留，精确

\[
G_{rem}=T+D_+-D_-=G_{floor}+D_+,
\quad G_{floor}:f\mapsto\min(f,q_v),\quad D_+:f\mapsto(f-q_v)_+.
\]

这里只在外层来源积分拆分，所有m/q/J/strictpast仍按完整f。均值零 $\int_{Q_v}(f-q_v)=0$ 不能消除有y依赖权重的偏差。为把新接收系数压到ε，要同步缩小ε0、提高h，来源价遂成为 $O_\varepsilon(\sqrt{n\log n})W$。所以纯root目标仍有实际 $\sqrt{\log n}$ 损失；这不是不可能性证明。见[370 geometry §2—7 [370/r370_geometry.md:47]](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/370/research.zip)。

R371—379围绕 $D_+$ 做共同匹配/二次捕获：先付 $\min(f,q_v)+p_{uv}(f-q_v)_+$，再以共同来源耦合平方Delta、行中心化及共享目标容量改进；模板从2Γ升3Γ或$O(\log n)$目标容量，费用必须同时更新。收益非零 iff余项非零，并不提供统一正比例。R378稀疏外突及R379浅总截断可付，但高密度、稠密、深截断、指数小几何交叠的共同Hall缺口仍在。有限运输LP零gap只认证冻结有限模型，不认证一般容量2/4或一般维数阶。索引见[373 README](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/373/README.md)、[375 README](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/375/README.md)、[379 README](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/379/README.md)。

## 8. 最终保留交集：来源质量窗、整行见证与中间秩

R380—387从全局来源簇改为来源可测参照/质量窗口，再到大端、小端共同付款。单个窗口宽度√n可付root来源，但未证明所有成本质量谱有统一窄窗。完整f见证可以支付窗口外的当前来源交通，不能只看当前来源的窗口命中。小端失败/相对秩筛选仍留下严格远质量和中间来源秩比。见[381 README](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/381/README.md)、[384 README](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/384/README.md)、[387 README](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/387/README.md)。

R388—390本次已复核原证明的闭合前沿如下。定义包含式来源质量秩

\[
T_y(t)=\int c_w(y)1_{m_w\le t}\mu(dw),\quad
F_u=\int\frac h{h+T_y(m_u)}\pi_u(dy),\quad
\pi_u(dy)=f(y)c_u(y)dy/m_u.
\]

含整颗质量原子的Stieltjes不等式给 $\int q_uF_udu\le\lambda h\int f\log(1+J_b/h)\le\lambda h\log(1+J_{max}/h)W$。R388若实际剩余行密度为 $a_u^{mid}\le1$，整行付 $\min(a_u^{mid},DF_u)$，准确余量 $\int q_u[a_u^{mid}-DF_u]_+du$。这是实际原计划的分数保留，不是把新源计划免费接回旧历史。正余行迫使完整后验多数来源高秩，但其空间相关性仍缺预算。见[388 geometry §1—5 [388/r388_geometry.md:11]](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/388/research.zip)。

R389付真实半径/质量错序

\[
P_{order}\le(\lambda/q_-)\log(\lambda/q_-)\log_+(J_{max}/h)W.
\]

保留因子 $\min(1,J/T_u)$ 后真实分母是 $\max(J,T_u)$，不是直接替换J。终端b原子的错序为零，不能拿点态正包络在b重复收费。精确clock平均后的实际核K有 $G_{order}=\int q_u(K1)(u)du$，不是较大的prefix上界被误认为等式。见[389 geometry §1—5 [389/r389_geometry.md:18]](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/389/research.zip)。

R390当前中间秩支持 $\alpha<T_v(y)/T_u(y)<\beta, \alpha=\tau/2, \beta=(1+d)^{-1}$，入列相对于 $q_vdv$ 的真实容量

\[
C_{col}=\frac\lambda{q_-}[1-\beta+\log(\beta/\alpha)].
\]

其中 $1-\beta$ 是首个跨阈值原子成本，不能删成纯log。用小端完整来源见证支付 $\min(1,F_v/t_{cold})$，$t_{cold}=1/8$，新来源价格

\[
P_{390}=8C_{col}\lambda h\log(1+J_{max}/h)W.
\]

这是一笔新增来源费，不能以R388已花的同一见证费抵消。准确 $G_{cold}$ 是当前原交通乘 $(1-8F_v)_+$，所以每个留下的小端Fv<1/8，且其**超过一半完整f质量有 $T_z(m_v)>3h$**。大端保留R388 shortage，阈值必须用原pre-R388 $a_u^{mid}$，不能改用当前更小行密度。见[390 aux §1—5 [390/r390_aux.md:24]](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/390/research.zip)。

R390外部共同捕获还给（原证明已读）

\[
p_{uv}=\pi_u(Q_v^c)\ge1-1/K,\quad
E_{uv}=\frac1{m_u}\int_{m_w<m_u/K}f(Q_u\cap Q_w\setminus Q_v)\mu(dw),
\]

\[
E_{uv}\ge h p_{uv}^2/F_u-(h+B_K)p_{uv},\quad B_K=(1+\log K)/q_-.
\]

冻结D=2、ε0≤1/2且live时可得 $E_{uv}>9h/49$。但以它正规化的外部源/接收器lift使新源被不同旧边重复使用；新源边缘 $f(z)L_{ext}(z)$ 的总列预算未证。低几何交叠、高后验秩、远质量、外部共同捕获同时成立并未推出root W付款。有限strict-far链长、Lp收缩、入列常数（通常>1）都不能代替终端或跨边共享来源预算。见[390 geometry §3—4 [390/r390_geometry.md:64]](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/390/research.zip)。

最终明确账为

\[
B_H\le G_{cold}+E_{387}X_q+(C_{338}+S_{386}+P_{388}+P_{389}+P_{390})W,
\]

\[
T_{entrance}\le8\lambda HW+2d_{eff}A_nW_\nu/H+2G_{cold}
+2E_{387}X_q+2(C_{338}+S_{386}+P_{388}+P_{389}+P_{390})W,
\]

整个入口再乘 $\Lambda=128/119$。h与ε0同步，历史采用 $\varepsilon_0^{-1}=O(\log^{3/2}n)$ 时P390为 $O(\sqrt n\log^{5/2}n)$。此处只能说当前硬槽接收系数未新增，不能说完整总账吸收完成。精确原件：[390 ledger [390/r390_ledger.md:1]](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/390/research.zip)。

## 9. 对本轮纯 √ n 攻坚可携带的最小结论

- 可以携带R301共同率与R302 clip/对称差恒等式，但必须带低pe、高m、aspect、外层原来源账及BH未付费用。它没有一般平方根结论。
- 若新入口从一开始建立硬匹配，可以携带R336—338真实中心容量与完整Gout分解。不能将它反向授给旧软核/来源资格。
- 可以携带R351共享来源势的任意长级联结算；外部固定指数强型工具仍须作为独立依赖验证。保留最后势和闭门核心，不能把稳定核心自动判空。
- 可以携带R360—361 canonical共同列预算和固定D次数终端付款，不能把所有D次数之和免费化；原能量注入与终端源重复仍是实质问题。
- 最后硬槽的未付交集是实际G_cold及其全源双端高秩、严格远质量、原outside/dense/deep、实际clock和完整旧fractional marks。外部Cauchy给的是可核验需求，无新负信用。
- 全部历史初始/删除/未来被删时间项、一般软层、极端aspect、宽距离low/high、原入口身份、H选择、阈值补集、全尺度与极限接口都还独立存在。不能只做G_cold就宣布原算子完成。历史全尺度桥还带logn，纯root任务需单独改变桥或支付它。

报告到此停止；没有把有限证书、正覆盖非空实例、必要条件或旧收据里的PASS提升为一般证明。
