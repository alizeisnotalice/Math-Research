# 中心方体极大常数与有限分数 packing 入口：独立证明

## 命题、约定与结论

设整数 \(n\ge1\)，\(Q(y,s)=y+[-s,s]^n\)，所有半边长满足 \(0<s<\infty\)，并定义
\[
Mf(x)=\sup_{r>0}\frac1{(2r)^n}\int_{Q(x,r)}|f(u)|\,du,
\qquad
C_n=\sup_{0\ne f\in L^1,\ \lambda>0}
\frac{\lambda|\{Mf>\lambda\}|}{\|f\|_1}.
\]
先允许任意 \(a>0\)，最后取 \(a=32n\)。对每个非空有限族 \(j=1,\dots,m\)，令
\[
A_j=Q(y_j,s_j),\quad B_j=Q(y_j,s_j/a),\quad d_j=|A_j|,
\]
\[
P=\max\left\{\sum_jd_j\theta_j:\theta_j\ge0,
\ \sum_j\theta_j\mathbf1_{A_j}\le1\ \text{Lebesgue-a.e.}\right\},
\qquad V=\left|\bigcup_jB_j\right|,
\quad T_a=\sup_{\text{非空有限族}}\frac VP.
\]
允许重复方体；不允许零半边长。所有方体取闭集，改成开集不改变 \(P,V\)。下面证明
\[
\boxed{C_n\le T_a\le (1+1/a)^n C_n.}
\]
事实上上界只需要连续紧支输入的弱型常数 \(C_n^{\mathrm{cont}}\)，即
\(T_a\le(1+1/a)^nC_n^{\mathrm{cont}}\)。全程没有使用无限维对偶或任何根阶上界。

## 1. 真正有限的 LP，以及其连续输入实现

记 \(F=\bigcup_j\partial A_j\)，则 \(|F|=0\)。对非空指标集 \(I\subset\{1,\ldots,m\}\)，定义
\[
E_I=\left(\bigcap_{j\in I}\operatorname{int}A_j\right)
\cap\left(\bigcap_{j\notin I}(\mathbb R^n\setminus A_j)\right).
\]
只保留 \(|E_I|>0\) 的指标集，组成有限集合 \(\mathcal I\)。各 \(E_I\) 是互不相交的有界开集；它们覆盖 \((\bigcup_j A_j)\setminus F\)。非空开集必有正体积，因此这里没有把只出现在边界的 membership pattern 加入约束。

于是原 packing 约束**恰好**等价于有限个约束
\[
\sum_{j\in I}\theta_j\le1\qquad(I\in\mathcal I).
\]
每个 \(j\) 属于至少一个这样的 \(I\)，故 \(0\le\theta_j\le1\)，可行集紧，最大值达到且 \(P>0\)。有限 LP 强对偶给出
\[
P=\min\left\{\sum_{I\in\mathcal I}z_I:
 z_I\ge0,\quad \sum_{I\ni j}z_I\ge d_j\ (1\le j\le m)\right\}.
\tag{D}
\]
这是有限矩阵的普通强对偶。对偶可行性还可直接看出：取 \(z_I=|E_I|\)，则每个对应和恰为 \(|A_j|\)。因此 (D) 有最优解 \(z\)。

对每个 \(I\in\mathcal I\)，在 \(E_I\) 中选闭小方体 \(Q(c_I,\rho_I)\subset E_I\)，并令
\[
h_I(x)=\rho_I^{-n}\prod_{k=1}^n
\left(1-\frac{|x_k-c_{I,k}|}{\rho_I}\right)_+.
\]
则 \(h_I\ge0\)、\(h_I\in C_c(\mathbb R^n)\)、\(\int h_I=1\)，且
\(\int_{A_j}h_I=\mathbf1_{\{j\in I\}}\)。所以
\[
g=\sum_{I\in\mathcal I}z_Ih_I\in C_c(\mathbb R^n),\qquad
 g\ge0,\quad \|g\|_1=P,\quad
 \int_{A_j}g\ge d_j\quad(1\le j\le m).
\tag{1}
\]
这是精确实现对偶质量的**真实连续函数**，没有使用原子测度、无穷族极限或连续逼近误差。

## 2. 上界 \(T_a\le(1+1/a)^n C_n\)

固定任意有限族，并取 (1) 中的 \(g\)。设 \(q=(1+1/a)^n\)。若 \(x\in B_j\)，则由无穷范数三角不等式
\[
A_j\subset Q\bigl(x,s_j(1+1/a)\bigr),
\]
因此
\[
Mg(x)\ge
\frac{\int_{A_j}g}{(1+1/a)^n d_j}\ge q^{-1}.
\]
阈值这里是非严格的，不能直接声称 \(\bigcup B_j\subset\{Mg>q^{-1}\}\)。正确处理为：对任意 \(0<\varepsilon<1\)，
\[
\bigcup_j B_j\subset
\{Mg>(1-\varepsilon)q^{-1}\}.
\]
应用弱型定义得到
\[
\frac{1-\varepsilon}{q}\,V
\le C_n\|g\|_1=C_n P.
\]
令 \(\varepsilon\downarrow0\)，再对有限族取上确界，即得 \(T_a\le qC_n\)。因为这里 \(g\in C_c\)，同一证明也给出 \(T_a\le qC_n^{\mathrm{cont}}\)。若右端为无穷，上界按扩展实数理解，自动成立。

## 3. 下界 \(C_n\le T_a\)：连续空间输入、紧集及有限见证

取任意 \(0\ne f\in L^1\)、\(\lambda>0\)，令 \(H=\{Mf>\lambda\}\)。对固定 \(r>0\)，函数
\[
x\longmapsto \int_{Q(x,r)}|f|
\]
连续：当 \(x'\to x\) 时，两方体的对称差体积趋零，再用 Lebesgue 积分的绝对连续性即可。因此 \(M f\) 下半连续，\(H\) 是开集，特别是可测集。

取任意紧集 \(K\subset H\)。对每个 \(x\in K\)，由严格超水平条件选一个有限见证半边长 \(s_x>0\)，使
\[
\int_{A_x}|f|>\lambda|A_x|,
\qquad A_x=Q(x,s_x).
\tag{2}
\]
各开小方体 \(\operatorname{int}Q(x,s_x/a)\) 覆盖 \(K\)。紧性给出有限子覆盖，记对应的大、小方体为 \(A_j,B_j\)。这时 \(K\subset\bigcup_jB_j\)，所以 \(|K|\le V\)。这里无需可测半边长选择器，也没有把无限族直接送入 LP。

对此有限族的任意可行共同权 \(\theta\)，由 (2) 和 packing 约束，
\[
\lambda\sum_jd_j\theta_j
\le\sum_j\theta_j\int_{A_j}|f|
=\int |f(u)|\sum_j\theta_j\mathbf1_{A_j}(u)\,du
\le\|f\|_1.
\]
取有限 LP 的最优值，得到 \(\lambda P\le\|f\|_1\)。若 \(T_a<\infty\)，于是
\[
\lambda|K|\le\lambda V\le\lambda T_aP\le T_a\|f\|_1.
\]
对所有紧集 \(K\subset H\) 取上确界，Lebesgue 内正则性给出
\(\lambda|H|\le T_a\|f\|_1\)，包括潜在的无限测度情形。再对 \(f,\lambda\) 取上确界，即 \(C_n\le T_a\)。若 \(T_a=\infty\)，这一不等式本来就成立。

附带地，以上证明对每个 \(a>0\) 均成立，故
\[
C_n\le T_a\le(1+1/a)^nC_n^{\mathrm{cont}}.
\]
令 \(a\to\infty\)，结合 \(C_n^{\mathrm{cont}}\le C_n\)，也得到连续紧支测试函数定义的常数恰为 \(C_n\)；不需额外引用稠密性定理。

## 4. 常数与费用核对

取 \(a=32n\)，则
\[
C_n\le T_{32n}\le
\left(1+\frac1{32n}\right)^nC_n
\le \frac{32}{31}C_n.
\]
最后一个不等式可纯代数验证：二项式展开中 \(\binom nk/n^k\le1\)，故展开和小于无穷几何级数 \(\sum_{k\ge0}32^{-k}=32/31\)。更精细的标准界为 \(q\le e^{1/32}\)。

**没有隐藏的 \(a^n\) 费用。** 虽然 \(|B_j|=a^{-n}|A_j|\)，证明从未用 \(B_j\) 的归一化密度承载质量；对偶输入总质量恰为 \(P\)，大方体覆盖从 \(B_j\) 中的点移心后只扩大到 \((1+1/a)A_j\)。membership cells 的数目可能随有限族大小增长，但不进入比较常数。

实际调用本机 Python `Fraction` 作了精确有理数检查（仅作计算核对，证明已在上文给出）：\(n=1,2,3,10,100\) 时的 \(q\) 分别约为
\(1.03125,1.031494140625,1.031576651114,1.031693135337,1.031738370751\)，均通过精确比较 \(q\le32/31\)。

## 5. 一个无需 LP 的全族共同可行权；根阶缺口仍在

作为独立的可行构造，定义体积加权的相交总量
\[
D_j=\sum_{k:\ |A_j\cap A_k|>0}d_k,
\qquad \theta_j=\frac{d_j}{D_j}.
\tag{3}
\]
所有 \(D_j\ge d_j>0\)。若 \(x\notin F\)，令 \(I(x)=\{j:x\in A_j\}\)。对任何 \(j\in I(x)\)，所有 \(k\in I(x)\) 都与 \(A_j\) 有正体积交，因为 \(x\) 是二者的内点。因此
\[
D_j\ge\sum_{k\in I(x)}d_k,\qquad
\sum_{j\in I(x)}\theta_j\le
\frac{\sum_{j\in I(x)}d_j}{\sum_{k\in I(x)}d_k}=1
\]
（\(I(x)=\varnothing\) 时和为零）。这确实是同时适用于全族的一组共同权，并给出可直接计算的证书
\[
P\ge\sum_j\frac{d_j^2}{D_j}.
\]
目前没有证明该证书对任意族满足 \(\sum_jd_j^2/D_j\gtrsim V/\sqrt n\)，因此 (3) 不能被当成根阶结果。要由本入口证明目标 \(C_n=O(\sqrt n)\)，仍须对**每一有限族**构造共同可行权并证明 \(\sum_jd_j\theta_j\ge V/(K\sqrt n)\)，其中 \(K\) 与维数、族大小和尺度范围无关。上面的等价比较只定位了这个缺口，没有填补它。
