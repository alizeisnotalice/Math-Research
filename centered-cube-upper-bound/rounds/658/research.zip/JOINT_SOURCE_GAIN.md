# 同一次完整 D 的局部源质量付款与唯一未付义务

状态：严格证明了真实邻域分母的负旧质量项可一次支付，且该证书可逐样本回代原完整 D；未证明纯 √n 增益。不把下面的局部证书本身计为根阶进展。

输入仅使用 R657 原包 REPORT.tex 第 1–3 节的完整合同。a=32n，m_j=μ(A_j)=|C_j|，κ=εR≤4，M=(1+κ)Q，V=RQ；旧源 μ 为实际 AC KKT 源。每次 realization 的 p 来自合法实际 disjoint owners J_j⊂B'_j，α 是该 p 的实际熵最优解。所有定义保留旧行；可用新行之外的旧行不被删除。本文中“邻域”只在当前可用新行之间取。

## 1. 半动作几何：候选付款正确

写 s=s_j，t=t_j，b=(t−1)/2，ρ=ts，c=y+b(y−X)。若 z∈A_j、x∈B'_j，则

    ||x−z||∞ ≤ s+bs+ts/a
                = [(t+1)/2+t/a]s
                ≤ (1+1/a)ts
                = (1+1/a)m_j^(1/n)/2.

最后一个不等式的余量恰为 (t−1)s/2≥0。这里实际半动作的位移已经计入；没有把 c 当作 y。

令 P_a=(1+1/a)^n<exp(1/32)。给定任意一批行 S，若 m_j≤T（j∈S），则对每个 z，所有满足 j∈S 且 z∈A_j 的实际 owners J_j 均在同一 Q(z,(1+1/a)T^(1/n)/2) 内。由于 J_j 真正不交，

    Σ_{j∈S:z∈A_j} p_j ≤ P_a T.

于是 Tonelli 给 Σ_{j∈S}p_jm_j≤P_a T μ(∪_{j∈S}A_j)。这比全局 M 的版本略强；关键是只有一次 μ 积分。

## 2. 邻域分母也可一次付款，不需要整个 component

令

    N_j={i: |C_i∩C_j|>0}，含 j；
    P_{N_j}=该子族的 linear volume packing 最优值；
    W_{N_j}=|∪_{i∈N_j} B'_i|；
    B_j=P_{N_j}+εW_{N_j}。

R657 的实际固定 p 一阶方向严格给

    α_j ≥ εp_j/(B_j−m_j).

对当前 C 正体积相交图的 component b，记 N_b=Q'_b+εW_b。packing 和固定 p 熵目标跨 component 分解，因此也有 α_j≥εp_j/(N_b−m_j)。取

    Γ_j=min(N_{b(j)},B_j)>m_j。

则同一实际 α 满足 α_j≥εp_j/(Γ_j−m_j)≥εp_j/Γ_j。

对 μ-a.e. z，设 S_z={j:z∈A_j}，T(z)=max_{i∈S_z}m_i。若 S_z 非空，AC 保证除去有限个 μ-null 交集后，i,j∈S_z 蕴含 |A_i∩A_j|>0，从而 i∈N_j，且它们属于同一 C component。于是

    B_j≥P_{N_j}≥m_i，  N_{b(j)}>m_i，
    Γ_j≥T(z)                  (j∈S_z)。

第 1 节几何和一次 Tonelli 因而给出

    Σ_j p_jm_j/Γ_j
      =∫ Σ_{j:z∈A_j}p_j/Γ_j dμ(z)
      ≤∫ [Σ_{j:z∈A_j}p_j]/T(z) dμ(z)
      ≤P_a M.                                      (PAY)

空纤维取零。无需质量分带、邻域预算相加或按 component 重新支付 M。这同时排除了全局 N 在远分离复制中的稀释问题。

可选的更强实际分母为

    h_i=m_iα_i+εp_i， H_j=Σ_{i∈N_j}h_i；
    T_j=max{m_i: μ(A_i∩A_j)>0}；
    Γ*_j=max(H_j,T_j)。

清空 N_j 并置第 j 系数为 1 的一阶方向给 m_j+εp_j/α_j≤H_j，故 Γ*_j>m_j，且 Γ*_j≤Γ_j。相同源纤维证明 PAY 对 Γ* 也成立。Γ* 涉及实际 α；Γ 是可用 local packing 求得的版本。

## 3. 可逐 realization 回代完整 D 的证书

令 ν 是当前 linear packing 的任意最优 AC cover，ν(全空间)=P，ν(C_j)≥m_j，且

    U_ν=∫(1−Σ_j α_j 1_{C_j})dν≥0。

精确恒等式为

    P−Q'=U_ν+Σ_j α_j[ν(C_j)−m_j]。

代入实际一阶下界及 PAY 得

    D ≥ W−RP+R U_ν
           +κ Σ_j p_j ν(C_j)/Γ_j −P_a κM。          (CERT-ν)

所有项均属于同一次 realization、同一 owner、同一实际 α。没有把 μ 识别为最优 ν，也没有给 ν 添加旧行约束。Γ* 可代 Γ 获得更强证书。

对原源 μ 本身直接使用 μ(C_j)≥m_j，令 U_μ=∫(1−Σα_j1_{C_j})dμ≥0，得到

    D ≥ W−RM+R U_μ
           +κ Σ_j p_j μ(C_j)/Γ_j −P_a κM           (CERT-μ)
      = E−O+F+R U_μ
           +κ Σ_j p_j μ(C_j)/Γ_j −P_a κM。

此式无需 packing gap g，也无 optimal-dual old-row mismatch。更锋利、无显式负项但不方便几何付款的形式是

    D ≥ E−O+F+R U_μ
           +κ Σ_j p_j[μ(C_j)−m_j]/(Γ_j−m_j)。     (EXCESS)

CERT-μ 从 EXCESS 换取一次 O(M) 后得到可直接测量的总捕获质量。量纲一致：最后付款 ≤4exp(1/32)M<4.127M。

## 4. 全有限校准让分母由纯旧源局部质量控制

令 Ω_j=∪_{i∈N_j}A_i。μ|Ω_j 对此真实 C 子族的每个 demand m_i 都是合法 cover，因为 A_i⊂C_i 且 A_i⊂Ω_j。因此

    P_{N_j}≤μ(Ω_j)。

对同一 ε* 的该有限 C 子族应用全有限校准。其全 receiver union 可作真实正 owner partition；其熵体积值不超过 P_{N_j}。故

    εW_{N_j}≤4P_{N_j}，
    Γ_j≤B_j≤5P_{N_j}≤5μ(Ω_j)。

这里确实使用了全有限校准，不是仅使用原状态 κ≤4。于是 CERT-μ 蕴含

    D ≥ W−(1+κ)V+R U_μ
           +(κ/5)Σ_j p_j μ(C_j)/μ(Ω_j)
           −P_a κM。                              (GEO)

分母 μ(Ω_j) 是正的。这个式子只在最后一步把可计算邻域分母粗化；Γ 版本更强。Γ 及 Ω 都对远分离复制逐分量可加，单个长 component 不会把所有遥远质量强制塞入每个分母。

## 5. 冻结范围与单一瓶颈；没有新的完整几何机制

上述结果只冻结 PAY、CERT-ν、CERT-μ、EXCESS、GEO。它没有产生一个已证明的全局 loss 支付机制，也没有产生可供全局验证的新短构造。把 CERT-μ 中的正项再命名、然后要求其期望 ≥cV−C√nM，只是重述剩余目标；不另立该目标或把它写成新候选报告。

单一瓶颈是：实际失像 O 的总量尚未与同一 realization 中接收者的局部捕获效率 μ(C_j)/Γ_j 及未使用源负载 U_μ 建立足够强的全局联系。当前付款消除了全局 N 在远分离复制中的稀释，也把 total capture 中的负 m_j 项一次支付；它没有证明实际失像来源必在高效率捕获者那里聚合。邻域中有大量旧源而 receiver 未捕获这些源时，Γ_j 可以大而捕获效率小；一阶条件和 μ|Ω_j 的 cover 性质只提供分母上界，不能推出所需的失像对应捕获下界。

近 F 极值性尚未在本文件中用于强制上述联系。因此本文不能导出纯 √n 增益。现阶段没有额外的完整构造与全局估计可交付；停止增加局部工具，不将这些证书当作 general improvement。

## 6. 实际工具核验与范围

- 已阅读原 research.zip/REPORT.tex 第 1–3 节；未改原包、未重新校准、未作反例扫描。
- 使用 math-b01-lagrange-farkas 技能核对一阶方向与 cover gap 的符号。
- 本机 python3 无 SymPy；连接 MATLAB 当前返回“无法解析名称 jupyter.Idler”，两者未产出计算证据。
- 本机 Python fractions 实际精确核验半动作余量和 excess/total 比率代数；选定有理输入的余量分别为 7/20、3/22。Decimal 实际计算 4exp(1/32)=4.12697362999641068375499126112。它们仅为 sanity checks；上面的不等式证明是符号推导，并不依赖数值实验。
