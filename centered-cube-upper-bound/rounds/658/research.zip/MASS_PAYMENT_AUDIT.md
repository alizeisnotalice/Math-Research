# Mass-payment 与局部 entropy 分母的独立审计

审计日期：2026-11-14–15。范围：本文件所列有限模型。审计先独立推导命题，未读取任何作者证明文件。符号计算证据与严格证明在文末分列。

## 审计结论

1. 立方体付款式
   \[
   \sum_{j\in H}p_jm_j\le P_a\,\mu\Bigl(\bigcup_{j\in H}A_j\Bigr)\max_{j\in H}m_j,
   \qquad P_a=(1+a^{-1})^n,
   \]
   成立，因而原式 \(\sum p_jm_j\le P_aMT\) 成立。这是来源点与实际不交 owner 的一次 Tonelli 付款，不是边界密度帽。
2. 固定 owner 权重后，entropy 的单位向量一阶条件与“清空邻域、置该标签为 1”的局部一阶条件均成立。零 owner 标签可按第 1 节在 full-owner 预处理阶段删除；若保留，则只对 \(p_j>0\) 声称严格分母。
3. 对下文的局部分母 \(\Gamma_j\)，更强的一次付款为
   \[
   \boxed{\sum_j\frac{p_jm_j}{\Gamma_j}\le P_aM.}
   \]
   它导出要求的局部 \(D\) 不等式。原分量分母是其特例；分量分母和局部分母都不会在分离复制时稀释正项。
4. 有限 AC cover 的对偶实现完整成立，但 packing 必须采用 Lebesgue-a.e. 约束。开立方体的逐点约束与此等价；闭立方体含边界的逐点约束可能不同。
5. \(B_j\le5P_{N_j}\) 由已核全有限 calibration 的 \(\varepsilon W_{N_j}\le4Q_{\varepsilon,N_j}\le4P_{N_j}\) 自动得到；单独 \(\kappa\le4\) 不充分。系数 5 不进入一次付款误差常数。
6. PAY 只把同一来源、所有层的负项一次支付，不含 sqrt 机制；已得到局部 D 下界，但完整 D 的正性尚未闭合。所有付款和 entropy 论证均适用于同一固定对称凸体的同位似体，因此本身不产生立方体独有的根阶收益。若“任意 \(C_j\)”只要求包含与体积，统一付款式不成立；变化长宽比的矩形已给出反例。

## 1. 精确模型与边界约定

令 \(n\ge1\)，有限非空标签集 \(\mathcal J\)，\(L=|\mathcal J|\)，\(s_j>0\)，
\[
A_j=Q(y_j,s_j),\quad d_j=(2s_j)^n,
\quad m_j=\mu(A_j)\ge d_j>0,
\quad t_j=(m_j/d_j)^{1/n}\ge1.
\]
\(\mu\) 是有限非负 Lebesgue 绝对连续测度，\(M=\mu(\mathbb R^n)\)。取 \(X_j\in A_j\)，并定义
\[
c_j=\frac{t_j+1}{2}y_j-\frac{t_j-1}{2}X_j,
\quad C_j=Q(c_j,t_js_j),
\quad B'_j=Q(c_j,t_js_j/a),\quad a=32n.
\]
于是 \(|C_j|=m_j\)，\(|B'_j|=m_j/a^n\)。实际 owners \(J_j\subset B'_j\) 可测且两两不交，\(p_j=|J_j|\)。只需 a.e. 不交。特别地，\(0\le p_j\le m_j/a^n\)。

**Full-owner 的零行预处理。** 若 \(\cup_jJ_j=\cup_jB'_j\) a.e.，删去所有 \(p_j=0\) 标签后，正 owner 的并集仍等于原 receiver 并集 a.e.；又正 owner 均包含在保留 receiver 内，所以保留 receiver 的并集也与原并集 a.e. 相同。因此可在建模前删除零行并重新建立 packing、entropy、cover 与邻域。这里不声称删除约束后原有 \(P,Q',\alpha\) 数值不变。若模型已经固定，以下证明也完整处理零行，无需删除。

下文 entropy 优化时 \(p_j\) 必须固定。若 owners 随优化变量 \(\alpha\) 重新分配，则不能直接把 \(p_j\) 当常数求导；需先冻结 owners，或另证相应的包络/变分结论。

真实几何 packing 定义为
\[
K_C=\left\{\alpha\in[0,\infty)^L:
  \sum_j\alpha_j1_{C_j}\le1\quad\text{Lebesgue-a.e.}\right\}.
\tag{1.1}
\]
“真实”在这里指由实际 \(C_j\) 的所有正体积 membership atoms 给出的可行域，并非任意抽象图的松弛。仅用两两相交图的 clique 或 edge 约束替代 (1.1) 需另证等价，本文未作这种替代。

## 2. 原几何包含与全局/子集付款

先有完整来源包含：对 \(z\in A_j\)，
\[
\|z-c_j\|_\infty
\le \|z-y_j\|_\infty
 +\frac{t_j-1}{2}\|X_j-y_j\|_\infty
\le \frac{t_j+1}{2}s_j\le t_js_j.
\]
因此 \(A_j\subset C_j\)。开集版本同样成立。

对任意 \(x\in B'_j\)、\(z\in A_j\)，
\[
\begin{aligned}
\|z-x\|_\infty
&\le s_j+\frac{t_j-1}{2}s_j+\frac{t_j}{a}s_j\\
&=\left(\frac{t_j+1}{2}+\frac{t_j}{a}\right)s_j
\le(1+a^{-1})t_js_j
=\frac{1+a^{-1}}2m_j^{1/n}.
\end{aligned}
\tag{2.1}
\]
这里最后一个不等式的精确松弛量是 \((t_j-1)s_j/2\)，没有额外 \(2^n\) 因子。

给定非空子集 \(H\subset\mathcal J\)，令 \(T_H=\max_{j\in H}m_j\)。对固定来源点 \(z\)，所有满足 \(z\in A_j\)、\(j\in H\) 的 \(J_j\)，由 (2.1) 均落在同一个立方体
\[
Q\left(z,\frac{1+a^{-1}}2T_H^{1/n}\right),
\]
且互不交。因此
\[
\sum_{j\in H:z\in A_j}p_j\le P_aT_H,
\qquad P_a=(1+a^{-1})^n.
\tag{2.2}
\]
一次 Tonelli 即得
\[
\begin{aligned}
\sum_{j\in H}p_jm_j
&=\int_{\cup_{j\in H}A_j}\sum_{j\in H}p_j1_{A_j}(z)\,d\mu(z)\\
&\le P_a\,\mu\Bigl(\bigcup_{j\in H}A_j\Bigr)T_H
\le P_aMT_H.
\end{aligned}
\tag{2.3}
\]
空子集的两边约定为 0。若已知 \(m_j\le T\)，直接取 \(T_H\le T\)。

等价地，对 \(x\in J_j\)，有 \(A_j\subset Q(x,(1+a^{-1})T^{1/n}/2)\)，先在不交 owners 上积分，再 Tonelli 也得到同式。不能在这一步分别估计每一个 \(j\) 后再把共同来源质量反复支付。

付款引理本身不需要 \(\mu\ll dx\)。绝对连续性用于后续正体积相交图、a.e. packing 与 cover 的接口。

**来源限制规则。** 可将 \(\mu\) 替换为 \(\mu|_E\)，前提是对参与付款的每个标签都满足 \(\mu(A_j\setminus E)=0\)。因此 \(E=\cup_{j\in H}A_j\) 总是可用；\(E=\cup_{j\in H}C_j\) 由 \(A_j\subset C_j\) 可用。不能无证明地换成 receiver 的并集。

## 3. 常数

当 \(a=32n\) 时，
\[
P_a=\left(1+\frac1{32n}\right)^n
 <e^{1/32}<\frac{32}{31}.
\tag{3.1}
\]
第一个上界由 \(\log(1+u)<u\)；第二个由 \(e^x=\sum x^k/k!<\sum x^k=(1-x)^{-1}\)，\(0<x<1\)。故也有 \(P_a-1<1/31\)。近似值仅作阅读辅助：\(n=1,2,8,32\) 时依次为 1.031250000000、1.031494140625、1.031680600303、1.031727674706。

本文证明的常数是 \(P_a\)，未声称它是考虑所有额外模型约束后的最优常数。它是统一半径包络的确切体积系数。

## 4. 有限 LP、AC cover 的实现与零体积标签

对每个非空 \(I\subset\mathcal J\)，令
\[
E_I=\{x\in\cup_jC_j:\{j:x\in C_j\}=I\}.
\]
只保留 \(|E_I|>0\) 的 atoms，记其有限集合为 \(\mathcal A\)。所有 \(C_j\) 有界、正体积，所以每个 \(j\) 至少出现在一个 \(I\in\mathcal A\) 中。由此 (1.1) 精确等价于有限 LP 约束
\[
\alpha_j\ge0,\qquad \sum_{j\in I}\alpha_j\le1\quad(I\in\mathcal A).
\tag{4.1}
\]
特别地，\(e_j\in K_C\)，\(0\le\alpha_j\le1\)，且全正向量如 \((1/(2L),\dots,1/(2L))\) 可行。

线性 packing 与 cover 的原、对偶为
\[
P=\max_{\alpha\in K_C}\sum_jm_j\alpha_j
 =\min\left\{\sum_{I\in\mathcal A}v_I:
 v_I\ge0,\ \sum_{I\ni j}v_I\ge m_j\ (\forall j)\right\}.
\tag{4.2}
\]
两个有限 LP 可行且有有限最优值。左边可行域紧；右边可例如由足够大的常密度 \(h1_{\cup C_j}\,dx\) 得到可行解。有限 LP 强对偶给出等值与最优解存在。

对任意右侧最优向量 \(v\)，定义
\[
d\nu(x)=\sum_{I\in\mathcal A}\frac{v_I}{|E_I|}1_{E_I}(x)\,dx.
\tag{4.3}
\]
这是有限 AC 非负测度，满足
\[
\nu(\mathbb R^n)=P,\qquad \nu(C_j)=\sum_{I\ni j}v_I\ge m_j.
\]
反之，任何有限 AC cover \(\nu\) 可先删去 \(\cup C_j\) 外的质量，再以 \(v_I=\nu(E_I)\) 转成可行有限 LP，且质量相同。故 (4.2) 的值确为 AC cover 的最优值，绝非仅有松弛。

**边界警告与修复。** 若 \(C_1=[-1,0]\)、\(C_2=[0,1]\)，\(m_1=m_2=1\)，a.e. packing 的值为 2，AC cover 的最小质量也为 2；若把闭集公共端点加入逐点 packing，则额外要求 \(\alpha_1+\alpha_2\le1\)，值降为 1，对应的 cover 是质量 1 的原子 \(\delta_0\)，不再是 AC cover。正体积相交图也不会记录这个端点约束。

如果 \(C_j\) 是开立方体，\(\sum\alpha_j1_{C_j}>1\) 的任意点均有一个仍然违反约束的开邻域，因此 a.e. packing 与逐点 packing 等价。选择开立方体，或明确采用 (1.1)，即可完整修复此接口。

## 5. Entropy 最优解、一阶条件与零 owner 标签

固定 \(\varepsilon>0\)，令
\[
F_\varepsilon(\alpha)=m\cdot\alpha
 +\varepsilon\sum_{j:p_j>0}p_j\log\alpha_j,
\qquad \alpha\in K_C.
\tag{5.1}
\]
在 \(p_j>0,\alpha_j=0\) 时目标为 \(-\infty\)；\(p_j=0\) 的标签不加入 log 项。全正可行点提供有限目标值，紧性及这个扩展目标的上半连续性给出最优解 \(\alpha\)，且所有 \(p_j>0\) 的坐标满足 \(\alpha_j>0\)。零 owner 坐标允许为 0，无需删掉对应标签。

定义
\[
Q'=m\cdot\alpha,\quad W=\sum_jp_j,\quad N=Q'+\varepsilon W,
\qquad
g_j=\begin{cases}m_j+\varepsilon p_j/\alpha_j,&p_j>0,\\m_j,&p_j=0.\end{cases}
\]
对任意 \(\beta\in K_C\)，由最优点沿线段的一侧导数，
\[
g\cdot(\beta-\alpha)\le0,
\qquad g\cdot\alpha=Q'+\varepsilon W=N.
\tag{5.2}
\]
取 \(\beta=e_j\) 得 \(g_j\le N\)。因此：

- 若 \(p_j>0\)，则 \(N-m_j\ge\varepsilon p_j/\alpha_j>0\)，且
  \[
  \alpha_j\ge\frac{\varepsilon p_j}{N-m_j}
     >\frac{\varepsilon p_j}{N}.
  \tag{5.3}
  \]
- 若 \(p_j=0\)，仅声称 \(m_j\le N\)，以及平凡下界 \(\alpha_j\ge0\)。不能无条件写 \(m_j<N\)。

取线性 packing 的最优 \(\beta\) 于 (5.2)，再用 \(g\ge m\)，还得到更强的
\[
P\le N,\qquad 0\le P-Q'\le\varepsilon W.
\tag{5.4}
\]
所以 \(N>0\)，并且 \(T=N\) 确实可用于全标签付款，包括零 owner 标签。

## 6. 局部清空变动与来源重叠阈值

定义真实正体积邻域
\[
N_j=\{i:|C_i\cap C_j|>0\},
\tag{6.1}
\]
其中含 \(j\)。记
\[
q_{N_j}=\sum_{i\in N_j}m_i\alpha_i,
\quad p_{N_j}=\sum_{i\in N_j}p_i,
\quad H_j=q_{N_j}+\varepsilon p_{N_j}.
\tag{6.2}
\]
构造 \(\beta_j=1\)，\(\beta_i=0\) 对 \(i\in N_j\setminus\{j\}\)，对 \(i\notin N_j\) 取 \(\beta_i=\alpha_i\)。此 \(\beta\in K_C\)：在 \(C_j\) 上，邻域外的所有 \(C_i\) 与其仅有零体积交，故 a.e. 负载恰为 1；在 \(C_j\) 外，负载没有增加。将此变动代入 (5.2)，得到
\[
g_j\le\sum_{i\in N_j}g_i\alpha_i=H_j.
\tag{6.3}
\]
因此 \(p_j>0\) 时
\[
H_j>m_j,\qquad
\boxed{\alpha_j\ge\frac{\varepsilon p_j}{H_j-m_j}.}
\tag{6.4}
\]
零 owner 标签仍有 \(m_j\le H_j\)，不引入除法。

再定义来源重叠阈值
\[
T_j=\max\{m_i:\mu(A_i\cap A_j)>0\}.
\tag{6.5}
\]
集合含 \(j\)，因为 \(m_j>0\)。由 \(A_i\subset C_i\)、\(\mu\ll dx\)，若 \(\mu(A_i\cap A_j)>0\)，则 \(|C_i\cap C_j|>0\)。于是
\[
T_j\le\max_{i\in N_j}m_i.
\tag{6.6}
\]
删去有限个满足 \(\mu(A_i\cap A_j)=0\) 的 pair intersections 的并集，得到一个 \(\mu\)-零测异常集。对其外任意 \(z\)，若 \(z\in A_j\)，则所有 \(i\) 满足 \(z\in A_i\) 都具有 \(\mu(A_i\cap A_j)>0\)。从而，定义
\[
T(z)=\max_{i:z\in A_i}m_i
\]
时，有
\[
T_j\ge T(z)\quad(\mu\text{-a.e. }z\in A_j).
\tag{6.7}
\]
此有限异常集步骤不能省成“逐点自动正测相交”；同处一个边界点并不意味着正测相交。

## 7. 局部分母的一次付款

取任意正数 \(\Lambda_j\)，满足
\[
\Lambda_j\ge\max(H_j,T_j).
\tag{7.1}
\]
则 (6.4) 给出对所有标签有效的下界
\[
\alpha_j\ge\frac{\varepsilon p_j}{\Lambda_j};
\tag{7.2}
\]
其中零 owner 标签两边右侧为 0。

对 \(\mu\)-a.e. 来源点 \(z\in\cup A_j\)，(2.1) 与实际 owners 不交性直接给出
\[
\sum_{j:z\in A_j}p_j\le P_aT(z).
\tag{7.3}
\]
又因每一个参与该和的 \(\Lambda_j\ge T_j\ge T(z)>0\)，
\[
\sum_{j:z\in A_j}\frac{p_j}{\Lambda_j}
\le\frac1{T(z)}\sum_{j:z\in A_j}p_j\le P_a.
\]
故只用一次 Tonelli，
\[
\boxed{
\sum_j\frac{p_jm_j}{\Lambda_j}
=\int\sum_j\frac{p_j1_{A_j}(z)}{\Lambda_j}\,d\mu(z)
\le P_a\mu(\cup_jA_j)\le P_aM.
}
\tag{7.4}
\]
可取最小的已证明局部分母 \(\Lambda_j=\max(H_j,T_j)\)。后文的 \(\Gamma_j\) 是另一个可计算上包络；分母变大不会破坏 (7.4)。

## 8. 可计算的 \(B_j\)、\(\Gamma_j\) 及 calibration 接口

对任意非空标签子集 \(S\)，令 \(P_S\) 是只保留 \(S\) 标签、仍按实际 \(C_i\) 定义的线性 packing 最优值。令
\[
W_S=\left|\bigcup_{i\in S}B'_i\right|.
\tag{8.1}
\]
注意 \(W_S\) 是 receiver 并集体积，不是 \(\sum_{i\in S}|B'_i|\)。由于实际 owners 不交，
\[
\sum_{i\in S}p_i\le W_S.
\tag{8.2}
\]
\(\alpha|_S\) 是子族 packing 的可行点，所以
\[
\sum_{i\in S}m_i\alpha_i\le P_S,
\qquad P_S\ge\max_{i\in S}m_i.
\tag{8.3}
\]
定义
\[
B_j=P_{N_j}+\varepsilon W_{N_j}.
\tag{8.4}
\]
由 (8.2)–(8.3)，有
\[
B_j\ge H_j,\qquad B_j\ge T_j.
\tag{8.5}
\]

令 \(b(j)\) 为真实正体积相交图的连通分量，设
\[
N_b=\sum_{i\in b}m_i\alpha_i+\varepsilon\sum_{i\in b}p_i.
\tag{8.6}
\]
第 10 节证明 \(N_b\ge P_b\ge\max_{i\in b}m_i\)。显然 \(N_b\ge H_j\) 对 \(j\in b\)，因此
\[
\boxed{\Gamma_j=\min\bigl(N_{b(j)},B_j\bigr)
       \ge\max(H_j,T_j)>0.}
\tag{8.7}
\]
于是第 7 节对 \(\Lambda=\Gamma\) 全部适用。

同时，来源限制测度
\[
\rho_S=\mu\bigm|_{\cup_{i\in S}A_i}
\]
是 \(S\) 的合法 AC cover：对 \(i\in S\)，\(A_i\subset C_i\)，所以 \(\rho_S(C_i)\ge\mu(A_i)=m_i\)。弱对偶即给出
\[
P_S\le\mu\Bigl(\bigcup_{i\in S}A_i\Bigr).
\tag{8.8}
\]

为得到系数 5，使用主流程另处已核的全有限 calibration 输入
\[
\varepsilon W_{N_j}\le4Q_{\varepsilon,N_j}\le4P_{N_j}
\qquad(\forall j).
\tag{8.9}
\]
这里 \(Q_{\varepsilon,N_j}\) 必须是该 calibration 实际控制的子族可行 packing 的线性部分，或为其已证明的上界接口；不能仅因符号相近而与任意局部量相认。本审计不重审生成 (8.9) 的 calibration，只独立核验从该已核输入到当前结论的接口。由 (8.4)、(8.8)、(8.9) 自动得到
\[
\boxed{\Gamma_j\le B_j\le5P_{N_j}
\le5\mu\Bigl(\bigcup_{i\in N_j}A_i\Bigr).}
\tag{8.10}
\]
仅有 \(\kappa=R\varepsilon\le4\) 本身并不蕴含 \(\varepsilon W_{N_j}\le4P_{N_j}\)：还必须有把 \(R\)、receiver 并集体积和子族 packing 值连接起来的 calibration。本文不作这个未证明跳步。系数 5 来自已校准的 \(\varepsilon W\le4P\)，不是新的几何常数。

## 9. Cover gap 恒等式与最终局部不等式

设 \(\nu\) 是任意有限非负 AC cover，质量 \(V=\nu(\mathbb R^n)\)，行松弛
\[
\sigma_j=\nu(C_j)-m_j\ge0,
\quad U_\nu=\int\left(1-\sum_j\alpha_j1_{C_j}\right)d\nu\ge0.
\tag{9.1}
\]
由有限求和积分交换，严格恒等式为
\[
V-Q'=U_\nu+\sum_j\sigma_j\alpha_j.
\tag{9.2}
\]
取同一个 \(R\ge0\)，设 \(\kappa=R\varepsilon\)、\(D=W-RQ'\)。由 (7.2)、(7.4)，
\[
\begin{aligned}
D
&=W-RV+RU_\nu+R\sum_j\sigma_j\alpha_j\\
&\ge W-RV+RU_\nu
  +\kappa\sum_j\frac{p_j\sigma_j}{\Gamma_j}\\
&=W-RV+RU_\nu
  +\kappa\sum_j\frac{p_j\nu(C_j)}{\Gamma_j}
  -\kappa\sum_j\frac{p_jm_j}{\Gamma_j}\\
&\ge\boxed{W-RV+RU_\nu
  +\kappa\sum_j\frac{p_j\nu(C_j)}{\Gamma_j}
  -P_a\kappa M.}
\end{aligned}
\tag{9.3}
\]
所有 \(\sigma_j\alpha_j\) 非负，故零 owner 行即使产生正贡献，舍去它们也是合法下界；零 owner 标签并未从 cover 或 packing 中删除。

取第 4 节实现的最优 \(\nu\)，\(V=P\)，得到要求的
\[
\boxed{D\ge W-RP+RU_\nu
 +\kappa\sum_j\frac{p_j\nu(C_j)}{\Gamma_j}
 -P_a\kappa M.}
\tag{9.4}
\]

也可直接取原来源测度 \(\nu=\mu\)：因为 \(A_j\subset C_j\)，它本身就是 AC cover。于是 \(V=M\)，且
\[
\boxed{D\ge W-RM+RU_\mu
 +\kappa\sum_j\frac{p_j\mu(C_j)}{\Gamma_j}
 -P_a\kappa M.}
\tag{9.5}
\]
这个版本无需把最优 cover 的质量与原来源质量相认，也不要求原 \(\mu\) 是最优 cover。此式无 dual mismatch。

若用 (8.10) 降低正项，则系数 \(1/5\) 出现在正项下界中；付款误差依然是 \(P_a\kappa M\)，无需改为 \(5P_a\kappa M\)。

## 10. 原分量式作为特例

图的不同连通分量 \(b\ne b'\) 满足 \(|U_b\cap U_{b'}|=0\)，其中 \(U_b=\cup_{j\in b}C_j\)。这是有限个跨分量 pair intersections 的并集。由于 \(\mu\ll dx\)，
\[
\mu_b=\mu|_{U_b},\quad M_b=\mu(U_b),\quad \sum_bM_b\le M.
\tag{10.1}
\]
而 \(A_j\subset C_j\subset U_b\) 证明 \(\mu_b(A_j)=m_j\) 对 \(j\in b\)。这就是限制来源所需的包含证明。

A.e. packing 精确分解为 \(K_C=\prod_bK_b\)：a.e. 点最多属于一个分量。固定同一个 \(\varepsilon\) 的 entropy 目标也分解，所以每一分量的限制向量都是对应 entropy 最优解。第 5 节在各分量给出
\[
P_b\le N_b=Q'_b+\varepsilon W_b,
\quad m_j\le N_b\ (j\in b),
\tag{10.2}
\]
且 \(p_j>0\) 时 \(m_j<N_b\)。

最优 AC cover 亦分解：每一分量取第 4 节的最优 cover \(\nu_b\)，支持在 \(U_b\)，则 \(\nu=\sum_b\nu_b\) 最优，\(P=\sum_bP_b\)；反向分解任意 AC cover 的限制也证明不能更便宜。边界重叠不造成 AC 质量重复。

现在取第 7 节分母 \(\Lambda_j=N_b\) 对 \(j\in b\)，或直接在分量应用 (2.3) 并令 \(T=N_b\)，就有
\[
\sum_{j\in b}p_jm_j\le P_aM_bN_b.
\tag{10.3}
\]
记 \(X_b=\sum_{j\in b}p_j\nu_b(C_j)\)，则
\[
\boxed{D\ge W-RP+R\sum_bU_{\nu_b}
 +\kappa\sum_b\frac{X_b}{N_b}-P_a\kappa M.}
\tag{10.4}
\]
局部 \(\Gamma_j\le N_b\)，因而 (9.4) 保留至少同样大的正项。它们均在分离复制时按复制数线性放大：每一副本的局部/分量分母不随其它副本增加。相比之下，把 \(X\) 与 \(N\) 都在全部副本求和后使用 \(X/N\)，该比值不随复制数增加。

若某一分量 \(W_b=0\)，entropy 在该分量只是线性 packing，故 \(Q'_b=P_b=N_b>0\)；最优 \(\nu_b\) 的 gap 为 0，\(U_{\nu_b}=0\)，且 \(X_b=0\)。所有公式仍有意义，不需要丢掉该分量。


所有分量必须使用同一 \(R\)，才能得到同一个 \(D=W-RQ'\)；本文也固定同一 \(\varepsilon\)，故 \(\kappa=R\varepsilon\) 公共。若每分量使用不同 \(\varepsilon_b\)，应保留 \(R\sum_b\varepsilon_bM_b\) 等加权误差，不能未经解释合并成一个 \(\kappa M\)。

## 11. 可以放宽哪些几何假设

### 11.1 任意来源集合、任意包含它们的等质量立方体

第 2、7 节实际只使用：
\[
A_j\subset C_j=Q(c_j,r_j),\qquad
|C_j|=(2r_j)^n=m_j=\mu(A_j),\qquad
J_j\subset Q(c_j,r_j/a),
\tag{11.1}
\]
以及 owners 不交。此时 \(z\in A_j\subset C_j\)、\(x\in C_j/a\) 直接给出
\[
\|z-x\|_\infty\le(1+a^{-1})r_j.
\]
因此无需 \(A_j\) 本身是立方体，也无需特定 half-motion、Euler 或 capture 生成规则。原 half-motion 公式只是保证 \(A_j\subset C_j\)、\(|C_j|=m_j\) 的一个已核验构造。

不要求 owners 覆盖全部 receiver 并集。若另外有 full-owner 条件 \(\cup_jJ_j=\cup_jB'_j\) a.e.，则 \(W=|\cup B'_j|\)；对局部子集仍只需 (8.2)，无需把局部 owner 总体积误认成该局部 receiver 并集体积。

### 11.2 同一固定对称凸体

令 \(K=-K\) 是满维有界凸体，\(C_j=c_j+r_jK\)，\(|K|r_j^n=m_j\)，receiver 为 \(c_j+(r_j/a)K\)，且 \(A_j\subset C_j\)。则
\[
x-z\in r_j(a^{-1}K-K)=(1+a^{-1})r_jK.
\]
对固定来源点，所有相关 owners 仍被同一个 \(T(z)\) 尺度的同位似体包住，其体积正好是 \(P_aT(z)\)。所以所有付款式、局部 KKT、LP/AC cover、分量与 \(D\) 式完全不变。\(W_S\le a^{-n}\sum_{i\in S}m_i\) 也不变，故显式 \(\varepsilon_*\) 仍有效。

若把原 \(A_j\)、half-motion 构造一起推广成 \(A_j=y_j+s_jK\)，其 \(A_j\subset C_j\) 也由 \(K\) 的凸性及 \(0\in K\) 直接成立；对称性用于保持付款常数恰为 \(P_a\)。

### 11.3 同一固定非对称凸体

若 \(0\in K\)、\(K\) 不对称，仍可做同一论证，但真实几何常数变为
\[
P_{a,K}=\frac{|a^{-1}K-K|}{|K|}
       =\frac{|K-a^{-1}K|}{|K|},
\tag{11.2}
\]
而不是自动等于 \((1+a^{-1})^n\)。因 \(a^{-1}K-K\) 凸且包含 0，各个不超过共同最大尺度的差体都嵌在最大尺度差体中，故 Tonelli 付款成立。此处不调用未经核验的差体体积界；保留 (11.2) 即为准确结论。

### 11.4 只有包含与体积的任意形状：反例

统一形状不可直接删除。在 \(n=2\)、\(a=64\) 中，取任意有限 \(L\)，\(k=1,\dots,L\)，令
\[
C_k=[-2^k/4,3\cdot2^k/4]\times
    [-2^{-k}/4,3\cdot2^{-k}/4].
\]
每个 \(C_k\) 都是面积 1 的轴平行矩形，并包含一个共同正面积小正方形 \(A=Q(0,2^{-L}/8)\)。令所有 \(A_k=A\)，\(\mu=|A|^{-1}1_A\,dx\)，所以 \(M=m_k=1=|C_k|\)。

以各 \(C_k\) 的中心作比例 \(1/a\) 收缩，所得 receiver 的 x 区间为
\[
2^k\left[\frac{a-2}{4a},\frac{a+2}{4a}\right].
\]
由于 \(2(a-2)>a+2\)，这些 x 区间两两不交，故可以取 full owners，\(p_k=1/a^2\)。于是
\[
\sum_kp_km_k=L/a^2,
\]
而 \(P_aMT=P_a\)。取 \(L=5000\)，左侧为 \(625/512\)，右侧为 \(4225/4096\)，严格违反统一付款式。故“任意 \(C_j\supset A_j,|C_j|=m_j\)”若不再保留统一形状，是错误推广；即使每个 \(C_j\) 都对称凸也不够。

## 12. 没有由这些式子自动得到根阶主项

第 11.2 节说明付款机制与 entropy 机制对所有固定对称凸体都相同。因此若要得到立方体特有的 \(n^{-1/2}\)、\(\sqrt n\) 或其它根阶因子，必须再输入能区分立方体的几何估计，或对 (9.4)/(9.5) 正项建立额外下界。局部/分量化修复的是分离复制稀释，并未提供这个新下界。

甚至在一个标签的例子中：取 \(t=1\)，\(A=C\)，\(\mu=1_A\,dx\)，\(M=m=|A|\)，full owner \(J=C/a\)，则
\[
p=M/a^n,\quad \alpha=1,\quad P=Q'=M,
\quad \Gamma=N=M+\varepsilon M/a^n,
\quad U_\mu=0.
\]
从而
\[
\frac{p\mu(C)}\Gamma=\frac{M}{a^n+\varepsilon}.
\tag{12.1}
\]
这个原始正项可以远小于 \(P_aM\)。因此不能仅从当前通用不等式宣称正项覆盖付款误差，更不能据此宣称完成根阶结论。这个例子只是说明现有估计的闭合缺口，不是否定一个另有几何输入的目标定理。

## 13. 本机计算记录与证据范围

先尝试系统 `python3` 的 SymPy，实际返回 `ModuleNotFoundError: No module named 'sympy'`。随后使用同一系统 Python 的内置 `fractions.Fraction`，没有安装依赖，也没有重算原项目。实际运行的精确有理数检查包括：

- \(t\in\{1,3/2,7\}\)、\(a\in\{32,64,1024\}\) 的 9 组几何松弛恒等式；全部通过。
- gap 分解与付款替换代数的精确 Fraction 实例；通过。
- \(n=1,2,8,32\) 的 \(P_a<32/31\) 精确比较；全部通过。
- 单标签 \(X/N=M/(a^n+\varepsilon)\) 的实例，以及 1、2、7 个分离副本的归一化；全部通过。
- 局部分母的一个有限来源-cell模型：来源 cells \(\{1,2\},\{2,3\},\{3\}\) 质量为 2、1、2，\(m=(2,3,3)\)，\(p=(1,1,2)\)，\(\Gamma=(3,3,3)\)，精确得到 \(\sum pm/\Gamma=11/3\)，付款上界成立。
- 变化矩形反例 \(625/512>4225/4096\) 与 receiver x 区间不交的精确比较；通过。
- 标签数 1、2、17、5000 时显式 \(\varepsilon\le4a^n/L\) 的代数；通过。

上述有限精确计算只复核所编码的代数/实例，不替代第 2–11 节的普遍严格证明。本文没有把浮点求解器输出、数值趋势或未读文献当成证明依据。

## 可直接复用的最终版本

在固定有限 full-dimensional 立方体容器 \(C_j\supset A_j\)、\(|C_j|=m_j=\mu(A_j)>0\)，固定实际不交 owners \(J_j\subset C_j/a\)，\(\mu\ll dx\)，真实 a.e. packing、固定 \(\varepsilon>0\) entropy 最优解的条件下，定义 (6.1)、(8.4)、(8.6)、(8.7)。对任意有限 AC cover \(\nu\) 及任意公共 \(R\ge0\)，有
\[
\boxed{
W-RQ'\ge W-R\nu(\mathbb R^n)+RU_\nu
+R\varepsilon\sum_j\frac{p_j\nu(C_j)}{\Gamma_j}
-\left(1+\frac1a\right)^nR\varepsilon M.
}
\]
所有零 owner 标签保留在模型内；所有分母严格为正。取最优 cover 得 (9.4)，取 \(\nu=\mu\) 得 (9.5)，取分量常数分母得 (10.4)。若再输入已核 calibration (8.9)，同时有 (8.10)。本文已独立证明 PAY、局部 KKT 与 D 下界及该 calibration 接口；PAY 不含 sqrt 机制，完整 D 的正性与根阶主项仍需要额外论证。
