# Primary source check: arXiv:2609.05377

Checked 2026-11-14 against the official [abstract](https://arxiv.org/abs/2609.05377) and [v1 HTML full text](https://arxiv.org/html/2609.05377v1).

Daniel Spector and Cody B. Stockdale, *The weak-type (1,1) bound for the Hardy–Littlewood maximal function is O(√n log n)*. Official record: v1 submitted 2026-09-04, 27 pages; no later version appears in its submission history. DOI: https://doi.org/10.48550/arXiv.2609.05377.

The operator in Section 1 is explicitly centered averaging over Euclidean balls, with Lebesgue measure. Theorem 1.1 states, for every positive integer n and every f∈L¹(Rⁿ), ||Mf||₁,∞ ≤ C√n log(1+n)||f||₁, with absolute C. Theorem 1.2 gives the Euclidean heat maximal bound C log(1+n). Section 6 proves their transfer through M f ≤ C√n H_*|f|; the kernel comparison specifically uses normalized Euclidean balls and t=r²/(2n).

This is a real, accessible arXiv preprint with a full proof presented. This check establishes its stated scope, not an independent proof audit or publication status. It supplies neither a cube theorem nor a pure O(√n) theorem. The introduction explicitly leaves logarithm removal open. Whitney cubes inside the proof do not change the operator's averaging geometry. Therefore it cannot certify the current centered-cube O(√n) target.

Tool limitation: shell and node execution failed before starting because the configured writable root contains a symlink. The literature skill file could not be read; no claim of applying that skill. No PDF was downloaded.
