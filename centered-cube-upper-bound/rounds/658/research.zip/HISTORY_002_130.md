# R002—R130：真实共同来源几何、已付分支与不可省略的余额

本报告于2026-11-14针对现有归档重读。129份 README（R002至R130）已全部实际通读；重点原证明、勘误及审计的实际读取范围见 `reading_002_130.json`。非重点轮次仅完成 README 层面的机制定位，不能因表格写“该轮证明”就视为本次已独立验收其 ZIP 内定理。本次没有运行旧数值 producer、Git、昂贵搜索或 TeX 编译。

结论是：本范围没有证明一般 `C_n≤K√n`，也没有证明旧 `n^(1/2+o(1))`。真正可保留的是来源一次计费、明确的已付子交通、固定输入的几何公式以及完整保留余额的条件返回链。许多局部根阶估计已经成立；欠项不等于零，原子数、来源熵、尺度深度和真实接收测度也不能被换掉。纯平方根目标还要求去掉已付账中现存的对数损失。

## 1. 最初的几何主量是什么

本范围的起点已经继承了很长的原母框架，不是从无门的方体重叠问题出发。原对象包含同一 `μ=fdy`、实际 Lebesgue 接收点、soft 首触选择器 `(σ,L_s)`、hard 赢家 `R_h`、共同森林及唯一 distinct-child LCA、出生格、原失败币、strict CP/GP，以及完整实际 history。不能把 `geom`、`heavy`、`sharp`、`angle` 因名字相近认作同一个量。

原母框架的可读规范化见 [actual_signed_bridge… L7—17 [002/actual_signed_bridge_reassessment_20261007.md:7]](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/002/research.zip)：

\[
P_{\sigma,L_s}f=q,\quad P_{s,L}f\le q\;(s\ge\sigma,L\in[a,b]),\quad
2\lambda<u=h_{R_h}*f\le4\lambda,\quad q\in[3\lambda/4,\lambda].
\]

完整来源后验是 `p_x(dy)=P_{σ,L_s}(x−y)μ(dy)/q` 和 `r_x(dz)=h_{R_h}(x−z)μ(dz)/u(x)`。实际接受门先保留在其共同联合律里，再作诊断 mask 分配；原 FIRST/history 与诊断标签不能当作独立。经软端积分后，R104实际接入的原 `R_out` 写为

\[
dT=G(x,z,\omega)h_{R_h(x)}(x-z)\,dx\,d\nu_{h,\omega}(z)\,dP(\omega),
\quad0\le G\le1,\quad \nu_{h,\omega}\le\mu_{hi}\le fdy.
\]

这里 `ν` 在接收点选择之前冻结；`G` 保存全部原门。这个公式揭示主困难：固定来源在很多真实接收点和自适应尺度下的联合重复负担。单行捕获约束或自由核包络不提供其空间积分预算。R104的 `R_out` 与R100另一条 earliest-contact `F2` 图也没有逐门等价关系，见 [R104 L707—815 [104/proof.md:707]](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/104/research.zip)。

R002累计主账L7—102把已显示费用合成

\[
\lambda|E|\le4\mathcal B_{paid}+\frac{8192}{49}
 \{[F_n+(\delta^{-1}-1)JA_n]W+R_{lowS,\ell<\delta}\},
\quad\ell=p+r-pr.
\]

显示费用仍是 `√n polylog(n)W`，而最后一项未付。后续仅把一类 **unforced-hit 且低K** 的子交通吸收，得到

\[
\lambda|E|\le\gamma_n[4\mathcal B_{paid}+(8192/49)\mathcal F_nW+(8192/49)R_{angle}],
\qquad\gamma_n\le147/143.
\]

`R_angle` 是精确角门补集，仍含forced-hit、nonhit及允许的高K。不是“全部角向交通均有小概率”。本次完整回读并核查 [面mask独审 L1—156 [002/actual_face_mask_root_absorption_audit_20261007.md:1]](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/002/research.zip)，其中 `M0=floor(n/65536)`、`α_n=32M0/(3n+5M0)`；n<65536时这个新删支为空。累计账不是旧上游全部理论的重新证明。

## 2. 按机制压缩129轮

下表是通读 README 后的导航，除了随后四项重点外，不提升为本次完整证明验收。

|机制与轮次|真正留下的工具/诊断|必须保留的未付量或失效范围|
|---|---|---|
|完整packet、局部时钟和物理合并 R002—008|删除减增长的signed费用；三角核曲率、阈值抵扣、赢家重选；合法P/Q律及终端|小格正费用、完整删除独立集和统一逐对价格可付线性n；背景平台使小被并质量不能支付单步弱损失；不能丢终端|
|经验来源、局部化、捕获方差及扰动 R009—019|降阈抽样保值；真实捕获向量/后验差；完整尺度共同扰动；质量时钟最大估计|样本数含ζ=W/(λa^n)；整格质量证书最优仍nlogn；方差×熵可被真实薄片迫使线性n；局部面通量不能跨分支重复收费|
|Poisson噪声与信息账 R020—025|窗口噪声平方预算可按W支付，包含顶部到达、重新选赢家与真实接收点|噪声小不强迫有用的选择增益；同阈值平台禁止免费迁移新接收集；趋细分割/高弱比不能强迫绝对增益|
|多标记、见证和价格 R026—038|精确盒交集表示、最后退出、Palm、全参与池、Hall割/价格对偶、半见证；首次命中平方合同|R027否定R026固定双标记平方根覆盖；对数触发后与原窗口问题常数等价；逐来源列线性反例不否定μ加权平均；R037剩Kcrit，R038确定性短峰值与原问题等价|
|归一化谱、可认证水平集及极值几何 R039—049|实际共同来源重叠核；捕获质量归一化谱；全部原子子集盒并；共同阈值分簇；固定N联合取到与位置应力|谱接口与原弱界同阶；Markov精确粗化只支持整数比例，一般小步误差min(nδ,1)；分簇/投影/连通性不支付密集相互作用；极值条件不控制总通量|
|分裂与正则化 R050—052|固定源固定核的一阶耗散；质量自适应正则化消去N和最小质量依赖|分裂余项不一致；恢复覆盖另付最小质量或N^(1/n)；强逆尺度稳定要求nlogn级对数密度，不得对熵取平方根冒充预算|
|尺度平方函数、cap能量及重分配 R053—070|真实带符号Gram/到达曲率，尖锐L2相邻体积尺度常数；全空间有符号替换；多数捕获尾；条件完整弱型返回|正变差、正Gram、局部容量、完整历史正漂移等强式被反例否定；R059修正正测度并列到达，不能沿用R055单原子跳公式；远尺度负交叉项必须保留；一般cap混合作用未付|
|真实赢家、共同分区和E2连续工具 R071—088|高后验质量/低熵支付；共同指数时钟舍入；Fisher≤7/3、连续动态O(√n)；低似然/来源块/Hall支付|R072高熵余项保有完整难度；R077否定无例外代表平均覆盖；原短时低占用硬首达/高容量割未付；R081从[1,2]返回全尺度还付logn|
|通量、部分需求、共同删帽和实际障碍 R089—103|有限厚度通量；长尺度尾；全尺度正超额的删帽返回；同帽源对抵消、OT/晶体实际分解|R095一般共同删帽只恢复nlogn；R096低帽容量与原问题等价；R100存在性含L2(f)，保留截断占用P(T)；R102—103剩近对/浅层共同帽费用|
|显式来源所有权与双侧容量 R104—116|宏包系数ν(A)/ν(B)消去空间重叠费；强L2截顶；有限轻组件；核列、比例条带、软硬共同提取|R104实际T_heavy；之后依次转为深出生/高列重尾/低占比/高几何平均/带权局部重质量/双侧余交通。非零可提取量无统一比例，不得无限免费迭代|
|来源变差、共同测试与混合核 R117—130|近时连续项uX；高测试门初始/跳跃共用FIRST容量；删源耗散；统一捕获、后缀signed消去、容量回收；正软度联合核估计|低pe、低测试、大耗散及低核存活补域仍在；N_Z已消费而N_Zc/Ndel各只保留一次；R128撤回与严格正软度域不相交的纯硬付款；R130仍欠bad端联合容量及自适应尺度预算|

## 3. 四项重点的独立核查

### R002：真正锐化的是完整来源块的删除余费

完整阅读 [packet主证明 [002/multi_packet_terminal_geometry_20261007.md:1]](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/002/research.zip)、[整组时钟主证明 [002/grouped_source_clock_20261007.md:1]](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/002/research.zip)、零时刻勘误和根验收。设固定窗口 `[a,b]`，`Z=1+nlog(b/a)`，

\[
\Phi_\tau(\nu)=\tau\int\log_+(M_{[a,b]}\nu/\tau)dx,
\quad K(\sigma)=\sup_{\rho>0}\Phi_\rho(\sigma)/\|\sigma\|.
\]

完整packet `0≤σ≤ν`、原真赢家后验p给真实删除D与冻结增长L。标量优化在 `u=v+1,p=v/(1+v)`取最大，严格推出

\[
D-L\le\Gamma_\tau(\sigma)=\tau\int G(M_\sigma/\tau)dx
\le K(\sigma)\|\sigma\|,
\quad G(v)=\log(1+v)-v/(1+v).
\]

第二步的自含关键是

\[
\Gamma_\tau(\sigma)=\int_0^\infty\frac2{(1+t)^3}\Phi_{\tau t}(\sigma)dt,
\qquad\int_0^\infty2(1+t)^{-3}dt=1.
\]

非负Tonelli合法；来源正性、完整packet和原窗口不能放松。小直径d包有 `κ=exp[nlog(1+2d/a)]`；一般包只知 `K≤Z/e`。有限共捕获图政策的停时和UI在原文另证，故

\[
\Phi_\tau(\mu)\le\sum_Bw_B\kappa_B(1+H_{deg(B)}).
\]

静态预合并能否降低这个总价须同时重核新包own-fee、邻居度和终端。把全源当一包只把未知K(μ)放回右边。途中合并不改变原细标签熵，粗熵下降转为组内条件熵。勘误规定：0时预处理已经计入初始分组，合并和只计 `0<s≤T`，不能双记0时奖励。此工具正确但不是根阶几何存在定理。

### R050：一阶耗散可保留，其方向与一致性不能反读

完整阅读 [MD [050/proof.md:1]](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/050/research.zip) 和 [详细英文证明 [050/proof.tex.txt:16]](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/050/research.zip)。对有限正原子，严格全尺度超水平集是所有非空子集J的开盒并，盒边由真实完整质量 `(m_J/λ)^(1/n)` 决定。固定有限正分裂的补全支配要求

\[
2\epsilon w< b_*/[n\lambda^{1/n}W^{(n-1)/n}].
\]

`b_*`是最小细质量。证明中增半径的一半必须覆盖极值位置位移，因子2和最小质量不能删。共同profile的每个盒先内缩ε再取并，接触缝必须保留。两粗原子/四微原子的真实公式为 `Fε=5/4−9ε/2`，不是只看外周长得到的 `−3ε/2`。

任意Borel固定profile的夹逼依赖极端cap质量 `β(h)>0`：`Ecore(ε)⊂Econv(ε)⊂Ecore((1−h)ε)`，范围 `ε<a_*β(h)/(4nλ^(1/n))`。先ε→0再h→0才得固定输入一阶式；不能与所有输入/核的上确界交换。核族 `p(1−|z|)^(p−1)/2`准确展示无统一o(ε)。阈值最优性只给 **耗散下界** `λP≥2nλ^(1/n)F*`。没有P上界不能界住F*。降阈修复含最小质量，补质量修复含N^(1/n)，均未形成一般可求和误差。

### R100：实际障碍构造成立，真正待证的是同帽删后能量

完整读取 [proof.md L1—775 [100/proof.md:1]](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/100/research.zip)，包括两条构造、实际通量、接触测试、占用删帽、共同剖面及独审。对 `f≥0∈L1∩L2`、晶体能量 `E(w)=1/2∫||∇w||_1²`，零阻尼实际最小者给

\[
\Omega=\{w>0\},\quad |\Omega|\le W/\lambda,
\quad f=g-\operatorname{div}Z,\quad0\le g\le\lambda,\quad\int g=W,
\quad Z\in\partial(\|\cdot\|_1²/2)(\nabla w).
\]

核查要点：support-Poincaré由真实cube卷积证明；阻尼单调性用min/max竞争；Huber误差按可积分`ελW`计，不乘全空间体积；Hahn–Banach延拓产生同一真实Z；全空间散度是函数而无遗漏界面测度；质量用cutoff。接触结论由 `φ(1−w/ε)+`测试的负能量项给 `f≤g` 于Ωc，不能假设任意H(div)可测零集局部性，也不升级为f=g。

这些存在性界显式包含 `||f||2`，不能当端点费用。取障碍高κ/2，μ=f1Ω，β=1+1/(2n)，

\[
N_0=A_L\mu\,1_{A_Lf>\kappa},\quad
N_1=A_L\mu\,1_{A_Lf>\kappa\beta^{-n}},\quad
H(x)=\int N_1(x,L)dL/L.
\]

嵌套性严格给 `N0≤c_nβ H`，`c_nβ=n/(1−β^(−n))≤4n`。同一帽的准确接口是

\[
U_T=\Omega\cup\{x\notin\Omega:H>T\},\quad
|U_T|\le2W/\kappa+|\{x\notin\Omega:H>T\}|,
\quad\mathcal E_\kappa(f;U_T)\le c_{n,\beta}T P(T),
\]

`P(T)`只积分**删除后留存的接收点**。用未截断P、Q乘积替换会丢失这个选择。一般T的体积/能量联合好价未证明；所存公开/私人有限例不能填补。

保留的全尺度返回（依R98，本次未重新验收R98 ZIP证明）是

\[
|U|\le AW/\kappa,\quad\mathcal E_\kappa(f;U)\le B\kappa W
\Longrightarrow C_n\le4A+8\sqrt{nAB/\log2}.
\]

对纯√n而言，`A,B=O(1)`是直接充分目标；仅`n^{o(1)}`仍不够。现存有偿fallback把OT帽与晶体帽取并，`A=5`、`B=n/(1−2^(−n))log(4n)log(8n)`，只恢复nlogn。不能把不同帽认作同一帽来省费。一般L1最终只能在统一弱界已经成立后由单调截断返回，不能先假定其有有限能量障碍。

### R104：共同所有权确实支付一个真实分支，重组件仍正

本次完整核查 [L1—932六模块和总账 [104/proof.md:1]](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/104/research.zip) 及 [最终独审 [104/proof.md:34972]](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/104/research.zip)。未把1MB原始stdout或producer整段当成数学证明阅读。

固定边长a所有权格Ai互不交，宏包Bi全边长5a。若Ai正捕获于Qx、a≤R≤2a，则Qx⊂Bi。设 `v_i=ν(Ai),m_i=ν(Bi)`，取共同系数 `u_i=Dv_i/m_i`（零质量项0）。单包资格为捕获≥m_i/D且≥δλR^n；其来源费为 `m_i[1+min(nlog2,log(4D/δ))]`。因

\[
\sum_i u_im_i=D\sum_i\nu(A_i)=D\|\nu\|,
\]

没有5^n空间重叠费用。这是实际构造，不是“假设存在便宜覆盖”。`F=Σν(Ai∩Qx)/mi`，`F−FD≤1/D`，D=2√n时F≥1/√n的行完全被共同Γ覆盖。严格余项仍乘 `(1−Γ)+`；有限样例不能证明其小。

先保留原G/R对密度做真实截顶 `gcap=min(g,√nλ),gres=(g−√nλ)+`。维数一致强L2（外部已知定理）与Young给 `Tcap≤εX+C2²√n Wcap/(4ε)`。须在gres上重算全部包量和资格，不能搬用旧ν的好门。

再冻结有限格盒K0使原f尾≤t；保持b≥δλR^n后，删K0外来源和截断后低b0行共只付2Hnt。以原f正质量格建有限邻接图，R≤2a的cube只正捕获一个组件。轻组件 `mC≤λa^n exp(√n)`付 `[1+log(4/β²)+√n]Wres`，重组件保留实际G1、当前gres、F<1/√n和b0≥βλR^n。

最终准确式为

\[
R_{out}\le\frac{C_2²}{4\epsilon}\sqrt n\,Wcap+
\{D[1+\log(4D/\delta)]+1+\log(4/\beta²)+\sqrt n\}Wres
+X/768+T_{heavy},
\]

其中 ε=δ=1/3072、β=δ/2，`Wcap+Wres≤W`。Wres在两个付款步骤中重复使用，所以两个来源系数必须相加。`T_heavy≤(1+nlog2)Wheavy`只是线性终端。最终独审中的n16夹具明确保留正T_heavy；n64为零只表示这个固定夹具的轻组件实际付清，不表明一般高维收缩。原FULL/FIRST完整资格没有在三个夹具中认证。强L2引用的外部论文全文不是本次重新阅读范围。

## 4. 关键更正与证据降级

- R002零时刻合并勘误已纳入；粗熵不是被物理耗散的细熵。
- R027撤销R026固定双标记的平方根强目标；只保留表示和点态比较。修正模型与原问题常数等价，不能循环用未知C。
- R059保留正测度同时到达的整批质量；从R055旧单原子公式直接求和会漏真实能量。正项与负项分别发散而差可有界，不可取正部抹掉抵消。
- R077反驳“所有真实分支均有一致平均代表覆盖”，并保留可直接按W支付的例外；失败覆盖前提不是弱型反例。
- 在本范围截至R130的记录中，R117最大菜单仍是中断/未完成历史状态；不能以R118—120成功替代。R121扩大菜单保留52个未判定字段，R122阶段3有NP2充分证书失败，零退出不等于付款资格。
- R123以后N_Z已消费，N_Zc与Ndel各一次；R126、127不同signed账互斥，不能拼接剩余负量。
- R127正交通32块全落失败块，16合格块交通全零，不能称作实际覆盖增益。
- R128纯硬拟付款与原严格软度域不相交，已撤回；R129两份混合核/实现性协议未执行；R130核积分高精度稳定不是FIRST/FULL或自适应空间预算。

## 5. 为纯平方根目标保留的最小工具

1. **固定来源、真实核的正积分和窗口包络。** `∫sup_[a,b]h_R=1+nlog(b/a)`，以及将单包捕获比例转为log价格的半径带。只作为明确线性基线/局部分支价格，绝不把它叫根阶。
2. **来源一次计费的显式共同构造。** R104所有权系数、固定来源密度拆分、有限尾转移可独立复用；其共同性与当前来源重算规则应保留。不必携带所有历史LP/随机分区名称。
3. **真正的符号与完整终端。** R002删除余费G混合公式、signed运行账、或R100同帽留存能量接口可选用；避免同时背负全部互不等价框架。R050固定输入盒并和耗散公式可作检验工具，不能充作主维数预算。
4. **一条完整返回链，参数明确。** 对纯√n，优先检查全尺度同帽正超额链能否把A、B付到绝对常数；若走局部窗口，先正视已有logn返回费和R104的√nlogn来源费。仅证明旧T_heavy根阶polylog，不自动得到新纯√n。

尚缺的是对所有来源、同一实际接收集合的共同几何估计。可以保留的具体核心候选为“同一收费帽外的全尺度正超额能量≤CκW且帽费≤CW/κ”，或“当前原正软度域、原FIRST/history下bad端联合来源容量有绝对根阶总预算”。这两项本报告均未证明；将其叫引理不降低其难度。最终证明只应调用实际复核通过的那一套必要工具。

## 6. 本次实际计算与阅读证据

主动调用本机Python标准库Fraction，独立枚举R050四微原子的全部15个非空子集并精确求区间并：ε=1/100、1/200、1/1000分别得到241/200、491/400、2491/2000，均等于5/4−9ε/2。另精确核验R002吸收因子147/143及R104遗漏1/768。结果见 [independent_small_checks.json [002/independent_small_checks.json]](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/002/research.zip)。可选SymPy在本次解释器不可用，未安装；有理核验实际完成。上述有限运算是公式/常数交叉核验，不是一般维数证明。

阅读清单对每份README给完整SHA256，对确实打开的ZIP成员给原成员SHA、实际行/节范围，区分“全文主证明”“只读理论/审计部分”“只看定位行”。没有声称重读全部外部论文、所有TeX版本、旧producer或私人材料。
