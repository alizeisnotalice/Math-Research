import os
for n in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','VECLIB_MAXIMUM_THREADS'):os.environ[n]='1'
import numpy as np, scipy, cvxpy as cp, clarabel
from scipy.optimize import linprog
from concurrent.futures import ProcessPoolExecutor
from multiprocessing import get_context
from itertools import combinations
from pathlib import Path
import time,json,subprocess,threading,platform,hashlib,sys
PTH=Path(__file__).parent

def volume(box): return float(np.prod(np.maximum(0,box[1]-box[0])))
def intersect(boxes):
 return np.array([np.max([b[0] for b in boxes],axis=0),np.min([b[1] for b in boxes],axis=0)])
def union(boxes):
 s=0.
 for k in range(1,len(boxes)+1):
  for ix in combinations(range(len(boxes)),k):s+=(-1)**(k+1)*volume(intersect([boxes[i] for i in ix]))
 return s

def case(k):
 rng=np.random.default_rng(659000+k); n=1+k%4; N=(4,6,8,10)[(k//4)%4]; mode=(k//16)%5; level=(.01,.1,1.,4.)[(k//20)%4]
 if mode==0: y=rng.uniform(-1,1,(N,n)); side=rng.uniform(.4,1.2,N)
 elif mode==1: y=rng.normal(0,.25,(N,n)); side=2**rng.uniform(-2,1,N)
 elif mode==2:
  y=rng.normal(0,.2,(N,n)); y[:,0]=np.linspace(-1.4,1.4,N); side=rng.uniform(.5,1.3,N)
 elif mode==3: y=rng.uniform(-.2,.2,(N,n));side=rng.uniform(.8,1.5,N)
 else:
  y=rng.normal(0,.12,(N,n)); y[:,0]+=np.where(np.arange(N)%2,1.5,-1.5);side=rng.uniform(.5,1.,N)
 A=np.array([[z-s/2,z+s/2] for z,s in zip(y,side)])
 # Each A has density one, plus several independently weighted source boxes.
 sources=[(b,1.) for b in A]
 for t in range(3):
  a=rng.integers(N); b=rng.integers(N); low=np.minimum(A[a,0],A[b,0]); high=np.maximum(A[a,1],A[b,1]); sources.append((np.array([low,high]),float(rng.choice([.05,.5,2.,8.]))))
 M=sum(volume(b)*d for b,d in sources);m=np.array([sum(volume(intersect([a,b]))*d for b,d in sources) for a in A]);assert np.all(m+1e-9>=side**n)
 r=m**(1/n)/2; c=y+rng.uniform(-1,1,(N,n))*(r-side/2)[:,None]
 C=np.array([[x-z,x+z] for x,z in zip(c,r)]); B=np.array([[x-z/(32*n),x+z/(32*n)] for x,z in zip(c,r)])
 edges=np.eye(N,dtype=bool)
 for i,j in combinations(range(N),2):edges[i,j]=edges[j,i]=volume(intersect([C[i],C[j]]))>1e-14
 cl=[]
 for mask in range(1,1<<N):
  ix=[i for i in range(N) if mask>>i&1]
  if all(edges[i,j] for i,j in combinations(ix,2)) and not any(all(edges[t,i] for i in ix) for t in range(N) if t not in ix):cl.append(ix)
 mat=np.array([[int(i in ix) for i in range(N)] for ix in cl],float)
 pack=linprog(-m,A_ub=mat,b_ub=np.ones(len(cl)),bounds=(0,None),method='highs',options={'threads':1}); assert pack.success
 p=np.array([volume(b)-sum((-1)**(q+1)*volume(intersect([b]+[B[j] for j in ix])) for q in range(1,i+1) for ix in combinations(range(i),q)) for i,b in enumerate(B)])
 p[np.abs(p)<1e-13]=0; assert min(p)>-1e-9;p=np.maximum(p,0);W=sum(p);eps=level*(-pack.fun)/W
 x=cp.Variable(N,nonneg=True); pos=np.flatnonzero(p>1e-12); constr=mat@x<=1
 scale=max(float(max(m)),float(eps*W));prob=cp.Problem(cp.Maximize((m@x+eps*cp.sum(cp.multiply(p[pos],cp.log(x[pos]))))/scale),[constr]);prob.solve(solver='CLARABEL',tol_gap_abs=1e-9,tol_feas=1e-9,tol_gap_rel=1e-9,max_iter=300)
 if prob.status not in ('optimal','optimal_inaccurate'):raise ValueError('solver '+str(prob.status))
 alpha=np.asarray(x.value); dual=np.asarray(constr.dual_value)*scale; grad=m.copy();grad[pos]+=eps*p[pos]/alpha[pos];slack=1-mat@alpha
 residual=max(max(0.,-min(slack)), max(abs(dual*slack)),max(abs((grad-mat.T@dual)[alpha>1e-7]),default=0),max(np.maximum((grad-mat.T@dual)[alpha<=1e-7],0),default=0))/max(1.,max(m),eps*W)
 v=m*alpha+eps*p;H=edges@v;T=np.array([max(m[i] for i in range(N) if volume(intersect([A[i],A[j]]))>1e-14) for j in range(N)]); LL=np.maximum(H,T)
 fac=(1+1/(32*n))**n*M; S=float(sum(p*m/H));SL=float(sum(p*m/LL))
 return {'k':k,'n':n,'N':N,'mode':mode,'level':level,'ratio_H':S/fac,'ratio_L':SL/fac,'H_over_L_min':float(min(H/LL)),'residual':float(residual),'M':M,'W':W,'P':-pack.fun,'epsilon':eps,'source_boxes':[{'box':b.tolist(),'density':d} for b,d in sources],'A':A.tolist(),'C':C.tolist(),'B':B.tolist(),'m':m.tolist(),'p':p.tolist(),'alpha':alpha.tolist(),'H':H.tolist(),'T':T.tolist(),'cliques':cl,'solver':prob.status}

def sample(stop):
 path=PTH/'resource_samples.csv';path.write_text('time,tree_processes,cpu_percent,rss_mib\n')
 with path.open('a') as f:
  while not stop.is_set():
   z=subprocess.run(['ps','-axo','pid=,ppid=,pcpu=,rss='],capture_output=True,text=True).stdout.splitlines(); records=[]
   for line in z:
    try:
     a=line.split();records.append((int(a[0]),int(a[1]),float(a[2]),int(a[3])))
    except:pass
   ids={os.getpid()}; changed=True
   while changed:
    new=ids|{pid for pid,par,cpu,rss in records if par in ids};changed=new!=ids;ids=new
   chosen=[r for r in records if r[0] in ids];cpu=sum(r[2] for r in chosen);rss=sum(r[3] for r in chosen)/1024
   f.write(f'{time.time():.3f},{len(chosen)},{cpu:.1f},{rss:.1f}\n');f.flush()
   if rss>10240:os._exit(99)
   stop.wait(.5)
if __name__=='__main__':
 stop=threading.Event();threading.Thread(target=sample,args=(stop,),daemon=True).start();t=time.monotonic(); results=[];errors=[]
 print('PID',os.getpid(),'workers',12,'stages pilot20 stress200 max2000',flush=True)
 with ProcessPoolExecutor(max_workers=12,mp_context=get_context('fork')) as pool:
  for stage,start,end in [('pilot',0,20),('stress',20,220),('expanded',220,2020)]:
   for k,z in zip(range(start,end),pool.map(case,range(start,end),chunksize=1)):
    results.append(z)
    if z['ratio_H']>1.000001 and z['residual']<1e-6:
     print('CANDIDATE',k,z['ratio_H'],flush=True);break
   print('STAGE',stage,'count',len(results),'max H',max(z['ratio_H'] for z in results),'max residual',max(z['residual'] for z in results),'min H/L',min(z['H_over_L_min'] for z in results),flush=True)
   if any(z['ratio_H']>1.000001 and z['residual']<1e-6 for z in results):break
   if stage=='stress' and (max(z['ratio_H'] for z in results)<.7 or min(z['H_over_L_min'] for z in results)>.98):break
 stop.set();out={'results':results,'errors':errors,'elapsed_seconds':time.monotonic()-t,'python':platform.python_version(),'versions':{'numpy':np.__version__,'scipy':scipy.__version__,'cvxpy':cp.__version__,'clarabel':clarabel.__version__},'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'command':'OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 /Users/zzh/.local/share/math-research-tools/venv/bin/python payment.py'};(PTH/'results.json').write_text(json.dumps(out,indent=2)+'\n');print('DONE',len(results),flush=True)
