import os
for n in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'): os.environ[n]='1'
from fractions import Fraction as F
from itertools import permutations
from concurrent.futures import ProcessPoolExecutor
from multiprocessing import get_context
from pathlib import Path
from collections import Counter
import zipfile,hashlib,json,time,resource,platform
import numpy as np,scipy,sympy,flint
from scipy.optimize import linprog
P=Path(__file__).parent
Z=Path('/Volumes/data/CodexProjects/T/Math-Research-cube-sqrt-20261114/centered-cube-upper-bound/rounds/657/research.zip')
with zipfile.ZipFile(Z) as z: raw=z.read('numeric/race_compare.py')
src=raw.decode().split("out={'python':platform.python_version()")[0].replace('range(96)','range(64)')
ctx={'__name__':'r658_evaluator'};exec(compile(src,'race_compare.py','exec'),ctx);evaluate=ctx['evaluate']
L=(-F(19,20),-F(1,4)); C=L+(F(1,4),F(19,20)); R=(F(1,4),F(19,20))
seqL=sorted(set(permutations(L*2)));seqC=list(permutations(C));seqR=sorted(set(permutations(R*2)))
combos=[tuple((l[i],c[i],r[i]) for i in range(4)) for l in seqL for c in seqC for r in seqR]
assert len(combos)==864
for t in combos:
 assert all(sum((w for row in t for x,w in zip(row,(F(7,5),F(6,5),F(7,5))) if x==v),F())==4 for v in C)
def work(i): return i,evaluate(4,combos[i])
if __name__=='__main__':
 start=time.monotonic(); c0=resource.getrusage(resource.RUSAGE_SELF);ch0=resource.getrusage(resource.RUSAGE_CHILDREN)
 with ProcessPoolExecutor(max_workers=8,mp_context=get_context('fork')) as pool: rows=sorted(pool.map(work,range(864),chunksize=4))
 W=[F(z['W']) for i,z in rows]; H=[F(z['p_high_mass']) for i,z in rows]; common=[F(z['common_C_length']) for i,z in rows]
 assert len(set(W))==1 and min(common)>0
 pairs=Counter((w,h) for w,h in zip(W,H)); Qlo=[F(z['Q_bounds'][0]) for i,z in rows];Qhi=[F(z['Q_bounds'][1]) for i,z in rows]
 out={'count':864,'common_min':str(min(common)),'W_values':list(map(str,sorted(set(W)))),'high_p_min':str(min(H)),'high_p_max':str(max(H)),'high_p_counts':{str(h):n for (w,h),n in sorted(pairs.items())},'Q_min_bounds':list(map(str,(min(Qlo),min(Qhi)))),'Q_max_bounds':list(map(str,(max(Qlo),max(Qhi)))),'rows':[]}
 if len(set(H))>1:
  A=[[1]*864]; b=[F(1)]
  for rep in range(4):
   for g,cat in enumerate((L,C,R)):
    for v in cat[:-1]: A.append([int(t[rep][g]==v) for t in combos]);b.append(F(1,len(cat)))
  q=np.array([float((a+z)/2) for a,z in zip(Qlo,Qhi)])
  lp=linprog(q,A_eq=np.array(A,float),b_eq=np.array(b,float),bounds=(0,None),method='highs',options={'threads':1})
  assert lp.success
  ids=np.flatnonzero(lp.x>1e-9).tolist(); M=sympy.Matrix([[a[i] for i in ids] for a in A]);bb=sympy.Matrix([sympy.Rational(x.numerator,x.denominator) for x in b]); sol,free=M.gauss_jordan_solve(bb);assert free.rows==0
  ws=[F(int(x.p),int(x.q)) for x in sol];assert all(w>0 for w in ws)
  assert all(sum((w*a[i] for w,i in zip(ws,ids)),F())==v for a,v in zip(A,b))
  candlo=sum((w*Qlo[i] for w,i in zip(ws,ids)),F());candhi=sum((w*Qhi[i] for w,i in zip(ws,ids)),F()); unilo=sum(Qlo,F())/864;unihi=sum(Qhi,F())/864
  out['lp']={'solver':lp.message,'support':[{'index':i,'weight':str(w),'anchors':[[str(x) for x in row] for row in combos[i]],'high_p':str(H[i]),'Q_bounds':[str(Qlo[i]),str(Qhi[i])]} for i,w in zip(ids,ws)],'candidate_bounds':[str(candlo),str(candhi)],'uniform_bounds':[str(unilo),str(unihi)],'gain_lower':str(unilo-candhi),'gain_lower_float':float(unilo-candhi),'strict_gain':unilo>candhi}
 out['rows']=[{'i':i,'high_p':str(H[i]),'W':str(W[i]),'common':str(common[i]),'Q_bounds':[str(Qlo[i]),str(Qhi[i])]} for i in range(864)]
 c1=resource.getrusage(resource.RUSAGE_SELF);ch1=resource.getrusage(resource.RUSAGE_CHILDREN)
 out.update({'elapsed_seconds':time.monotonic()-start,'cpu_seconds':c1.ru_utime+c1.ru_stime-c0.ru_utime-c0.ru_stime+ch1.ru_utime+ch1.ru_stime-ch0.ru_utime-ch0.ru_stime,'worker_limit':8,'blas_threads':1,'python':platform.python_version(),'versions':{'numpy':np.__version__,'scipy':scipy.__version__,'sympy':sympy.__version__,'flint':flint.__version__},'hashes':{'archive_sha256':hashlib.sha256(Z.read_bytes()).hexdigest(),'source_sha256':hashlib.sha256(raw).hexdigest(),'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()},'command':'OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 /Users/zzh/.local/share/math-research-tools/venv/bin/python pool_compute.py','scope':'finite atomic fixed low-R old state; not a global calibration or AC result'})
 (P/'pool_results.json').write_text(json.dumps(out,indent=2)+'\n')
 print(json.dumps({k:v for k,v in out.items() if k not in ('rows','high_p_counts')},indent=2),flush=True)
