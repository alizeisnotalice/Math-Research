# R658 balanced-pool independent finite audit

Verdict: PASS for the specified 864-action atomic finite model. The seven-support law is exactly feasible and lowers expected actual entropy-optimized linear score Q by strictly more than 0.11073235 relative to the uniform 864-action law. This is not a global transport-optimality certificate, an absolutely continuous source certificate, an epsilon-star calibrated state, or a dimension theorem.

## Independent procedure

I read POOL_TASK.md and the supplied proposition before pool_compute.py and the embedded R657 evaluator. I then wrote pool_audit.py from the affine map and interval definitions; it imports or executes neither author program. Its geometry uses Python Fraction throughout. The author results are loaded only after independently constructing all 864 geometries. The entropy certificate uses an independently derived quadratic polynomial, rather than the author's rational-pole bisection. No LP or floating optimization is needed for this verification: the seven supports and rational weights are treated as a proposed certificate and verified exactly.

Files are colocated here: pool_audit.py, pool_audit.json, POOL_INDEPENDENT_AUDIT.md. No other person's files were modified; no Git operation was used.

## Old state and source

Old open intervals are A_L=(-2,0), A_C=(-1,1), A_R=(0,2). Their small B and ownership I coincide, each has length v=1/16; d=2. The weights (7/10,3/10,7/10) have load one on both source-bearing overlap cells. All other open incidence cells have load at most one. The four mass-4 source sites are strictly inside these cells, so the source has row masses (8,16,8) and is supported on load one. The exact stationarity equations are

m_j = 2 + (336/5)(1/16)/lambda_j.

Thus strict concavity supplies the actual old entropy optimizer under this atomic witness. The independently checked totals are Q=17/5, V=3/16, M=16=Q+epsilon V, R=15/272. Old geometry uses open cubes or Lebesgue-a.e. packing: a closed-cube pointwise constraint at the shared boundary 0 would incorrectly add a triple constraint and change the problem. None of the four source points lies on a boundary.

Outer anchor marginals are uniform on their two source sites; the middle is uniform on all four. Each assignment has each outer point twice and each middle point once. A clone contributes lambda_j m_j/4, namely 7/5 or 6/5; at every site these contributions sum to 2(7/5)+6/5=4 in every assignment. This identity does not require expectation. The full uniform pool and the candidate law also have every one of their 12 slot marginals exactly equal to the prescribed Euler marginal.

## True geometry, eligibility, baseline

For slot i=0,1,2,3, old ownership is [y-1/32+i/64,y-1/32+(i+1)/64]. Put t=m/2, b=(t-1)/2 and c=y+b(y-X). The independently implemented affine image is c+t(I-y), the new receiver B is [c-t/32,c+t/32], and the new full interval C is [c-t,c+t]. All 12 images are contained in their own B. The sum of individual image lengths is exactly 1.

The sweep partitions at every image and B endpoint, considers every open interval atom, and explicitly recomputes all incoming image labels and all containing B labels. With incoming images, a candidate must itself be incoming and its full C must contain every incoming label's entire old A. Without incoming images, candidates are all containing B labels. No old min-price rule or nominal receiver relation substitutes for these tests. Every positive-length atom has nonempty eligibility. All 864 intersections of full C have positive length; the minimum is 15/4. All 864 unions of B have W=53/20. Boundary assignments are irrelevant to ownership volumes; capture uses exact weak endpoint comparisons for containment of intervals.

On each atom, the 1/100 baseline is divided uniformly among the actual eligible labels; the remaining 99/100 is divided among eligible labels having minimum m. All resulting 12 ownership volumes are positive, with global minimum 1099/16000. Their sum equals W exactly. The high-mass ownership ranges from 4951/3000 to 15001/8000. There are 93 distinct high-mass values. Every independently computed row, common length, group count, support anchor tuple, high-mass value, and reported entropy interval matches the author's JSON.

## Why minimum mass is valid here, and the actual entropy Q

The positive common intersection of all C makes the complete packing polytope exactly the simplex sum alpha<=1: necessity follows on that positive-length intersection; sufficiency holds everywhere. Positive p and positive m make the entropy optimum interior with active simplex constraint. It is uniquely characterized by

alpha_k=epsilon p_k/(nu-m_k),   nu>16,
sum_k epsilon p_k/(nu-m_k)=1,
Q=sum_k m_k alpha_k=nu-epsilon W.

Let h be the total p at m=16. At fixed W the root equation is F(nu,h)=epsilon[(W-h)/(nu-8)+h/(nu-16)]-1=0. Here F_nu<0 and F_h=8 epsilon/[(nu-8)(nu-16)]>0. Therefore dnu/dh>0, and Q strictly increases with h. The minimum-mass free allocation minimizes h separately on each atom subject to the fixed baseline, hence minimizes the actual Q in this two-mass simplex problem. This is the justification needed for that allocation rule; a general overlapping packing problem would not inherit it. The statement concerns the linear score at the actual entropy optimizer, not minimization of the entropy objective itself over ownership choices.

## Exact intervals and strict gap

Clearing the positive denominator gives

P(nu)=nu^2-(24+epsilon W)nu+128+epsilon(16W-8h),
F(nu)=-P(nu)/[(nu-8)(nu-16)].

Because 0<h<W, P(16)<0 and there is exactly one root above 16. The audit bisects the upper root with rational arithmetic for 100 steps, starting from [16,16+epsilon W+1]. It verifies the final endpoints satisfy 16<nu_lo<nu_hi, P(nu_lo)<0<P(nu_hi). Subtracting epsilon W preserves endpoint direction for Q. Separately, every author row's reported Q endpoints has the same strict polynomial signs, independently certifying each interval without trusting the author's loop.

The candidate supports are 128,207,303,429,512,639,722; weights are 1/8 except support 512 with 1/4. All weights are positive, sum to one, and every anchor category has its correct marginal at each slot. The candidate mean interval and the uniform mean interval are obtained by positive rational weighted sums of row intervals. The gap lower endpoint is uniform_lower minus candidate_upper, the correct direction. The independently certified interval is

[757997652157595094529504910499337 / 6845313241232438768082197309030400,
 757997652157595094529504912433401 / 6845313241232438768082197309030400].

Its lower endpoint is strictly greater than the rational 11073235/100000000. Floating display is approximately 0.11073235445119298; the rational comparison is the evidence. The author's aggregate interval sums and gain_lower are also reproduced exactly from its independently validated row certificates.

## Reproduction and limits

Run in this directory:

OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 /Users/zzh/.local/share/math-research-tools/venv/bin/python pool_audit.py

Actual audit: Python 3.12.14, one process, no worker pool, no NumPy/SciPy/BLAS computations; BLAS environment limits all one. Final run elapsed 0.4045 s, CPU 0.4020 s. Input and audit SHA-256 hashes are recorded in pool_audit.json. The preexisting author program/results record eight workers; this audit did not rerun that program and complied with the at-most-three-worker instruction using one process.

Only a finite atomic fixed low-R state has been verified. No positive-width perturbation or AC lift has been constructed or audited for these ±19/20 sites. No all-finite epsilon-star calibration, near-score condition, global optimum of the coupling LP, or general square-root bound follows. The fixed-pool gain is a valid exact finite certificate within those stated limits.
