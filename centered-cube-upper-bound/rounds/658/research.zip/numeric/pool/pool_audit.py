"""Independent exact finite audit; never imports/executes the author evaluator."""
import os
for name in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):
    os.environ[name]='1'
from fractions import Fraction as F
from itertools import permutations
from collections import Counter
from pathlib import Path
import json, hashlib, platform, resource, time
P=Path(__file__).resolve().parent
start=time.monotonic(); cpu0=resource.getrusage(resource.RUSAGE_SELF)
eps=F(336,5); delta=F(1,100); r=4
Y=(-1,0,1); masses=(8,16,8); lam=(F(7,10),F(3,10),F(7,10))
points=(F(-19,20),F(-1,4),F(1,4),F(19,20)); cats=(points[:2],points,points[2:])
# Old KKT: source mass 4 at every site; nonempty open incidence cells.
oldA=[(F(y-1),F(y+1)) for y in Y]
v=F(1,16); oldQ=sum(2*x for x in lam); oldV=3*v
assert oldQ==F(17,5) and oldV==F(3,16)
assert all(2+eps*v/weight==m for weight,m in zip(lam,masses))
for x in points:
    assert sum(weight for weight,(a,b) in zip(lam,oldA) if a<x<b)==1
for j in range(3):
    assert sum(4 for x in points if oldA[j][0]<x<oldA[j][1])==masses[j]
assert sum(weight*m for weight,m in zip(lam,masses))==16==oldQ+eps*oldV
# Packing feasibility on every open incidence cell, including source-free ones.
ends=sorted({a for ab in oldA for a in ab})
assert all(sum(weight for weight,(a,b) in zip(lam,oldA) if a<(l+h)/2<b)<=1 for l,h in zip(ends,ends[1:]))
sequences=[sorted(set(permutations(cat*(2 if j!=1 else 1)))) for j,cat in enumerate(cats)]
assignments=[tuple(zip(left,mid,right)) for left in sequences[0] for mid in sequences[1] for right in sequences[2]]
assert len(assignments)==864 and len(set(assignments))==864
for slot in range(4):
    for j,cat in enumerate(cats):
        assert Counter(t[slot][j] for t in assignments)==Counter({x:864//len(cat) for x in cat})

def geometric_state(tup):
    small=[]; large=[]; images=[]; oldlabel=[]; mm=[]
    for slot,row in enumerate(tup):
        for j,anchor in enumerate(row):
            y=F(Y[j]); m=F(masses[j]); scale=m/2
            b=(scale-1)/2; center=y+b*(y-anchor)
            # Partition old I=B into four equal slots before applying homothety.
            ia=y-F(1,32)+F(slot,64); ib=ia+F(1,64)
            small.append((center-scale/32,center+scale/32))
            large.append((center-scale,center+scale))
            images.append((center+scale*(ia-y),center+scale*(ib-y)))
            oldlabel.append(j); mm.append(m)
    assert all(a<=c<d<=b for (a,b),(c,d) in zip(small,images))
    common=min(b for a,b in large)-max(a for a,b in large)
    assert common>0
    ep=sorted({x for ab in small+images for x in ab})
    baseline=[F(0) for _ in mm]; allocation=[F(0) for _ in mm]
    W=F(0); image_union=F(0); atoms=0
    for a,b in zip(ep,ep[1:]):
        mid=(a+b)/2; width=b-a
        owners=[k for k,(lo,hi) in enumerate(small) if lo<mid<hi]
        incoming=[k for k,(lo,hi) in enumerate(images) if lo<mid<hi]
        if not owners:
            assert not incoming
            continue
        W+=width; atoms+=1
        assert set(incoming)<=set(owners)
        if incoming:
            image_union+=width
            eligible=[k for k in incoming if all(large[k][0]<=oldA[oldlabel[z]][0] and oldA[oldlabel[z]][1]<=large[k][1] for z in incoming)]
        else:
            eligible=owners
        assert eligible
        winners=[k for k in eligible if mm[k]==min(mm[z] for z in eligible)]
        for k in eligible: baseline[k]+=width/len(eligible)
        for k in winners: allocation[k]+=width/len(winners)
    pp=[delta*a+(1-delta)*b for a,b in zip(baseline,allocation)]
    assert sum(pp)==W and all(x>0 for x in pp)
    assert sum(b-a for a,b in images)==1
    h=sum(x for x,m in zip(pp,mm) if m==16)
    # Every assignment has exactly the desired empirical source, not just in mean.
    empirical={x:sum(lam[j]*masses[j]/4 for row in tup for j,vv in enumerate(row) if vv==x) for x in points}
    assert all(z==4 for z in empirical.values())
    return W,h,common,image_union,min(pp),atoms

# Algebraically independent root certificate: polynomial after clearing denominators.
# F(nu)=eps[(W-h)/(nu-8)+h/(nu-16)]-1 = -P(nu)/((nu-8)(nu-16)).
def poly(nu,W,h):
    return nu*nu-(24+eps*W)*nu+128+eps*(16*W-8*h)
def bracket(W,h):
    lo=F(16); hi=16+eps*W+1
    assert 0<h<W and poly(lo,W,h)<0<poly(hi,W,h)
    for _ in range(100):
        mid=(lo+hi)/2
        if poly(mid,W,h)<0:lo=mid
        else:hi=mid
    assert lo>16 and poly(lo,W,h)<0<poly(hi,W,h)
    return lo-eps*W,hi-eps*W

states=[geometric_state(t) for t in assignments]
assert {z[0] for z in states}=={F(53,20)}
rootcache={}
for W,h,*_ in states:
    rootcache.setdefault((W,h),None)
for key in rootcache:rootcache[key]=bracket(*key)
reported=json.loads((P/'pool_results.json').read_text())
assert len(reported['rows'])==864
for i,(W,h,common,*_) in enumerate(states):
    row=reported['rows'][i]
    assert row['i']==i and F(row['high_p'])==h and F(row['W'])==W and F(row['common'])==common
    qa,qb=map(F,row['Q_bounds']); na,nb=qa+eps*W,qb+eps*W
    assert 16<na<nb and poly(na,W,h)<0<poly(nb,W,h)
assert reported['high_p_counts']==dict(Counter(str(z[1]) for z in states))
assert list(map(F,reported['W_values']))==[F(53,20)]
assert F(reported['common_min'])==min(z[2] for z in states)
assert F(reported['high_p_min'])==min(z[1] for z in states) and F(reported['high_p_max'])==max(z[1] for z in states)
weights={item['index']:F(item['weight']) for item in reported['lp']['support']}
assert len(weights)==7 and sum(weights.values())==1 and all(w>0 for w in weights.values())
for item in reported['lp']['support']:
    i=item['index']; assert tuple(tuple(map(F,row)) for row in item['anchors'])==assignments[i]
    assert F(item['high_p'])==states[i][1]
    assert item['Q_bounds']==reported['rows'][i]['Q_bounds']
for slot in range(4):
    for j,cat in enumerate(cats):
        for x in cat:
            assert sum(w for i,w in weights.items() if assignments[i][slot][j]==x)==F(1,len(cat))
qs=[rootcache[(z[0],z[1])] for z in states]
uni=[sum(q[k] for q in qs)/864 for k in (0,1)]
cand=[sum(w*qs[i][k] for i,w in weights.items()) for k in (0,1)]
gain=[uni[0]-cand[1],uni[1]-cand[0]]
assert gain[0]>F(11073235,10**8)
# Reported aggregate endpoints must also follow from reported row certificates.
reported_q=[tuple(map(F,row['Q_bounds'])) for row in reported['rows']]
ru=[sum(q[k] for q in reported_q)/864 for k in (0,1)]
rc=[sum(w*reported_q[i][k] for i,w in weights.items()) for k in (0,1)]
assert ru==list(map(F,reported['lp']['uniform_bounds']))
assert rc==list(map(F,reported['lp']['candidate_bounds']))
assert ru[0]-rc[1]==F(reported['lp']['gain_lower'])
usage=resource.getrusage(resource.RUSAGE_SELF)
output={'pass':True,'scope':'finite atomic fixed-state model only; no AC lift, epsilon-star calibration, global optimum or dimension theorem','independent_method':'Fraction affine interval sweep and independently derived quadratic root brackets; no author evaluator imports or calls','old_KKT':{'Q':str(oldQ),'V':str(oldV),'M':'16','R':str(oldV/oldQ),'packing_convention':'open cubes / Lebesgue-a.e.'},'assignments':864,'slots_per_assignment':12,'every_source_empirical_mass':'4','every_slot_marginal_exact':True,'candidate_support':{str(i):str(w) for i,w in weights.items()},'common_min':str(min(z[2] for z in states)),'W':'53/20','high_p_range':[str(min(z[1] for z in states)),str(max(z[1] for z in states))],'high_p_counts':dict(Counter(str(z[1]) for z in states)),'minimum_individual_p':str(min(z[4] for z in states)),'distinct_entropy_roots':len(rootcache),'uniform_bounds':list(map(str,uni)),'candidate_bounds':list(map(str,cand)),'gain_bounds':list(map(str,gain)),'gain_lower_float':float(gain[0]),'certified_gain_greater_than':'0.11073235','reported_rows_and_aggregate_certificates_verified':True,'workers':1,'blas_threads':1,'python':platform.python_version(),'elapsed_seconds':time.monotonic()-start,'cpu_seconds':usage.ru_utime+usage.ru_stime-cpu0.ru_utime-cpu0.ru_stime,'command':'OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 /Users/zzh/.local/share/math-research-tools/venv/bin/python pool_audit.py','hashes':{name:hashlib.sha256((P/name).read_bytes()).hexdigest() for name in ('pool_compute.py','pool_results.json','pool_audit.py','POOL_TASK.md')}}
(P/'pool_audit.json').write_text(json.dumps(output,indent=2)+'\n')
print(json.dumps({k:v for k,v in output.items() if k!='high_p_counts'},indent=2))
