"""R658 integrity and bounded exact-certificate replay; never certifies a general theorem."""
import argparse,ast,hashlib,json,re,shutil,subprocess,sys,tempfile,zipfile
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--replay',action='store_true');p.add_argument('--scratch',type=Path);p.add_argument('--source-repo',type=Path);a=p.parse_args()
root=Path(__file__).resolve().parent
manifest=json.loads((root/'manifest.json').read_text())['files']
for name,want in manifest.items():
 assert hashlib.sha256((root/name).read_bytes()).hexdigest()==want,name
 if name.endswith('.py'):ast.parse((root/name).read_text(),filename=name)
s=(root/'REPORT.tex').read_text();begin=re.findall(r'\\begin\{([^}]+)\}',s);end=re.findall(r'\\end\{([^}]+)\}',s)
assert sorted(begin)==sorted(end),'TeX environment multiset'
assert not any(ord(c)<32 and c not in '\n\t\r' for c in s)
labels=re.findall(r'\\label\{([^}]+)\}',s);assert len(labels)==len(set(labels))
assert set(re.findall(r'\\(?:eqref|ref)\{([^}]+)\}',s))<=set(labels)
h=hashlib.sha256((root/'REPORT.tex').read_bytes()).hexdigest()
for name in ['FINAL_BRIDGE_SIGNOFF.md','FINAL_INTEGRATION_AUDIT.md']:assert h in (root/name).read_text(),name
result={'files_verified':len(manifest),'report_sha256':h,'tex_basic_structure':'pass; no PDF compilation','general_bound':'unproved'}
if a.source_repo:
 idx=json.loads((root/'SOURCE_INDEX.json').read_text());assert sorted(r['round'] for r in idx['readme_records'])==list(range(2,658))
 for r in idx['readme_records']:
  q=a.source_repo/f"centered-cube-upper-bound/rounds/{r['round']:03d}/README.md"
  assert hashlib.sha256(q.read_bytes()).hexdigest()==r['sha256'],r
 for r in idx['proof_member_records']:
  z=zipfile.ZipFile(a.source_repo/f"centered-cube-upper-bound/rounds/{r['round']:03d}/research.zip")
  assert hashlib.sha256(z.read(r['member'])).hexdigest()==r['sha256'],r
 result['source_readmes_verified']=len(idx['readme_records']);result['source_member_records_verified']=len(idx['proof_member_records'])
if a.replay:
 scratch=a.scratch or root/'_verify_runtime';scratch.mkdir(parents=True,exist_ok=True)
 with tempfile.TemporaryDirectory(dir=scratch,prefix='exact_') as tmp:
  target=Path(tmp)/'pool';shutil.copytree(root/'numeric/pool',target)
  proc=subprocess.run([sys.executable,str(target/'pool_audit.py')],capture_output=True,text=True,timeout=120)
  assert proc.returncode==0,proc.stdout+proc.stderr
  actual=json.loads((target/'pool_audit.json').read_text());saved=json.loads((root/'numeric/pool/pool_audit.json').read_text())
  skip={'elapsed_seconds','cpu_seconds','python','command'}
  for k,v in saved.items():
   if k not in skip:assert actual[k]==v,('replay',k)
  result['exact_replay']={'assignments':actual['assignments'],'gain_lower':actual['gain_bounds'][0],'scope':actual['scope']}
print(json.dumps(result,ensure_ascii=False,indent=2))
