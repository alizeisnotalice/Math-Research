# R521—R657：完整历史的机制压缩与可复用边界

范围：137份逐轮 README 全部通读；重点 research.zip 原文按 `reading_521_657.json` 所列成员和行段实际读取。工作基线为项目末轮657；本轮不运行历史昂贵实验、不操作Git。原仓库前缀为 `/Volumes/data/CodexProjects/T/Math-Research-cube-sqrt-20261114/centered-cube-upper-bound/rounds/`。本文引文 `R657/REPORT.tex:506` 指该轮 ZIP 中该成员的实读行；可读副本在本目录 `sources/657/REPORT.tex`。未明确实读原证明的早期成果只按 README 归档记录，不作为本轮新证明的依赖。

**总判断：历史未证明一般 `n^(1/2+o(1))`，更未证明纯 `C_n≤K√n`。** 可以复用的实际收益包括全局一次付款、合法替换、某些正分支付款、全族来源容量、以及准确的有限证书。它们与完整主量的统一正增幅是不同结论。当前最短主对象已经是一般真实有限方体族、实际全覆盖所有权、实际熵最优者及完整 `D=W−RQ′`；Euler采样、capture资格、δ基线和经验相关项是特定构造的附加机制，不能误当所有合法动作的必要条件。

## 1. 全范围机制地图

| 轮次 | 对象和真正推进 | 主要未付量／范围限制 |
|---|---|---|
| 521—529 | 原阶段完整父对、共同质量时钟、同步剥离、辅助父到达、合法极值和首次接触容量；522把换窗费按同一端点平方吸收，525剥离费一次结算，529接触窗容量保留横向减项 | 同来源跨父对重复、双来源放大因子及柱来源／端点费用；不是完整根阶容量。此段本轮仅README级 |
| 530—549 | 最外等高根把历史主量改为全尺度协方差；531远尺度／极近尺度／高交叠已付，535外部请求付费，545平方捕获付费；548完整根归一替换；549完整成员场保留平台 | 中尺度低交叠共同来源主量仍在；运输、熵或Dirichlet重写不等于吸收；548—549原文已核 |
| 550—554 | 共同packing路线与原弱型目标等价；全空间可行权、扫边合法性、捕获熵及支持来源通量 | 可行权缺收益、熵仍跨尺度重复、完整有符号面流仍等原列价。550原文已核，其余README级 |
| 555—558 | 合法障碍核／首次大跳切换／Gaussian混合和共同时间；558归档给出整个特定核族达不到目标的范围定理 | 不是一般目标反例；不涵盖内部非恒定杀死、其他生成元或一般路径依赖。此段本轮仅README级，未纳最小证明依赖 |
| 559—570 | 真实质量—相位筛父产生额外p；560纠正逆体积矩恢复；561—570共同簇、累计冻结、near吸收、共享价格、尺度轮廓、记录簇、外父整序 | 旧质量层在同来源上的正总和、真实逆L终端和far／不同赢家仍未付；559与560关键恢复段原文已核 |
| 571—582 | 新一般输入入口，完整单质量带／完整halo，森林、高半质量核心、分位载体、共同切分与实际闭循环 | 森林化、跨参考／跨核心重复、修正势的切分存在性；同源嵌套链和循环无统一漏出。此段本轮仅README级 |
| 583—601 | 全真实体积列覆盖／全动作来源分配；共同删源、所有子集出生、双副本严格增益、微填充、完整外部余量H；601真实有限高q输入证书 | 质量代理费用可以指数差；新生/遮挡净益未付；严格有限增益非统一增幅；H全空间下界仍缺。此段本轮仅README级 |
| 602—615 | 完整势有限差分、外部新生信用上价、实际半径图、概率桥、共同尺度张量和坏包 | 固定双点／单段根阶范数不恢复真实选择图；同步张量仍携完整高维难度；多包弱预算未付。611已纠正全尺度定位不是新缺口；612已纠正610单段工具历史重复 |
| 616—632 | 同一合法selection多见证、完整star来源packing、全局择源、菜单/近远/占用核、contact heavy；628真实近满载历史，630—631完整contact与必要取消 | 任意供应族点态load帽过强；全局输入相关选择和坏星松弛不可丢；heavy列容量及统一吸收未证。628、630—631原文和审计已核 |
| 633—641 | 同一KKT来源的完整新见证／新容量联合更新，固定N终端，分数容量，独立位移，实际Qε和全局跨来源交换 | `D≥cV−CL_nM`未证；整行指派过强，接触非必利、捕获Jensen保证过弱；有限正例皆非困难族。此段本轮README级 |
| 642—654 | 已付删universal、扩为真实fullowners、源剥离、远信用、中心矩／联合score、接触通道、capture所有权及产品源 | 同次物理丢失副本重数、新源需求和实际熵净反弹未付；局部来源容量≠接收面积付款。重点原证明按清单选段读取 |
| 655—657 | 全有限参数后复制合法，完整high相关费可任意小；MAX压力；固定owner的受约束packing；平衡耦合与同步细分 | 同一合法联合律同时有小来源误差和完整正增幅仍未证；direct fullD支可绕开相关项。原文及终审按清单读取 |

以上地图覆盖全部137轮，并不宣称表中所有README结论均由本任务重新证明。下文把实读原文中可直接复用的内容单列。

## 2. 原外根能量：替换已付，联合主量未付

冻结 `μ=f dx`、真实Lebesgue中心E、最外根 `μ(Q_B)=λV_B`，令 `D(x)=∫_E1_QB/V_B dB`、`X=λ|E|=∫D dμ`、`A=∫D²dμ`。R548沿用的核心是有序中尺度低几何交叠父对K+，付过的补集为 `A−A_core≤B_nX`、`B_n=O(√n)`；本任务没有重核该补集全部前史。

R548的可复用新付款是：对**同一个全局来源集合H和同一个父对集合S⊂K+**，令 `i_H=μ(Q_B∩Q_C∩H)`、`m_H=μ(Q_C∩H)`，则条件平方项

`R_H=2∬ i_H²/(m_HV_BV_C)≤2qX`，`q=e^(−√n/4)`，零分母项取零。

证明在固定C后对真实B中心径向积分，把 `i_H≤min(m_H,λV_B)` 同时保留，所得 `mJ≤qλV_C`；没有来源密度帽。随后完整大根抽终点得到 `O_H=S_H+T_H`、`0≤S_H≤2qX`，与旧分解比较为

`T_H−L_H=R_H−S_H`，所以 `|T_H−L_H|≤2qX`。

取H={D>t}时直接有 `A_core≤(t+2q)X+T_H`，**不另加第二笔2qX**。这是消除人工小条件质量分母的真实收益；不是T_H的主量预算。[原证明 [548/r548_main.tex:18]](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/548/research.zip)、[归一化原稿 [548/r548_root_normalization.md:37]](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/548/research.zip)、[独审 [548/r548_good_centres_audit.md:69]](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/548/research.zip)。

未付的是保留双根、共同起点与排除终点的完整核。先逐点包络小父再积共同大父，虽能得到 `2/[(n+1)||x−y||∞^n]`，却引入对非零L1密度通常近对角发散的临界能量；这只是有损上界发散，不是原T_H发散。[来源对几何 [548/r548_root_normalization.md:79]](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/548/research.zip)。good-centres候选若对a=2以polylog成立，直接推出弱常数≤4L_n；不能当温和辅助估计。无权L2不提供该带权结论。[强度审查 [548/r548_good_centres_audit.md:23]](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/548/research.zip)。

R549真实可逆源链合法，但原有序净流使用父依赖F_C。替成完整D要保留无已证符号的协方差残差；余场平均 `A−A_core/2≥A/2`，不是已付补集。`A<∞`只给D∈L1(Ddμ)，不保证D的来源三阶矩；有界截断测试才合法。完整Hilbert成员场 `Φ(x)(B)=1_QB(x)/√V_B` 的能量身份合法且 `A_core≤2qX+2E(Φ)`，但已知 `E(Φ)≤A`不能吸收。标量谱隙不付来源均值或高平台内部吞吐量。[完整推导 [549/r549_transport.md:47]](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/549/research.zip)、[成员场 [549/r549_main.tex:52]](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/549/research.zip)。有限六来源负前缀净流仅属尺度分离正上包络，不是原低交叠core反例。

## 3. 共同packing、探索折扣与恢复：不重领来源预算

R550给一般可测正半径场上的共同packing：`w≥0`且对**全空间每个x**有 `∫w(B)1_QB(x)dB≤1`。则 `λ∫wV_B≤M`。其统一几何下界的最佳常数下确界等于原弱范数；反向桥只需有限LP和几何分组，保留边界incidence、正测度中心组及 `κ=(a/(a+5η))^n`，再细化趋1，不假设无限维强对偶或连续最优权取得。[原文 [550/r550_main.tex:18]](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/550/research.zip)、[完整审计 [550/r550_cover_audit.md:20]](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/550/research.zip)。

实际候选 `w_s=s^(−1)e^(−V_B/s)` 全空间可行；全局s概率混合的收益不超最佳单s。空间自适应拼接的共同来源容量仍缺。32个真实二维cube的packing=cover=1是有限全空间证书；该族含体积1单父，因此没有联合收益，且不是连续权w证书。

R559完整探索律 `ν_G=p(dg/g+δ_G)`、`p=(1+lnG)^(−1)`，真实质量窗/相位先筛旧父质量到一个固定比带，再丢窗积分，严格得到

`Z_ij≤p C_*(G)`，`||Z||²≤p² C_* S A_n W`，`A_n=1+n ln(b/a)`。

它保留端点、全部Gram交叉和真实Lebesgue中心，的确比未筛父的原帽好。但旧绝对质量层虽中心互斥，同一来源可被多层捕获；至多三层窗口重叠不付正同层和。[原证明 [559/REPORT.tex:81]](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/559/research.zip)、[明确未付积分 [559/REPORT.tex:203]](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/559/research.zip)。

**必须连R560读取。** 真正恢复量是 `C_eta=||∫F_B/η_B dB||²`，不是原场平方；`η_B=E(1/g)`，`N_Bη_B=I_B`。共同律恰η=p，所以R559的p²在精确恢复中与p^(−2)**完全相消**；自适应展开分母是I_BI_C，不能恢复后再用N_BN_C折扣。吸收旧信用须先在Q_g层做，不能从 `Q_g≥b0²Q`反向误用。[最小恢复原证 [560/REPORT.tex:1646]](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/560/research.zip)。这纠正了把raw能量下降当最终常数改善的常见误读。

## 4. 核路线、contact路线的失败范围

R555—558这部分本任务只逐份README读取，未将其核族定理加入严格新证明依赖。归档范围明确：R556顶点谱首次大跳切换核H_k是合法非负L1，占用质量 `5/(k+4)`，归一核为 `(P_k+F*P_k)/5`；质量变小本身不改善归一接收成本。R557同一随机矩阵的横向密度、径向阈值和共同时间相关不能拆乘；显式1/√n是Jacobian而非已得接收收益。

R558归档声称对全部有限k的完整切换核及其概率混合，有与k无关的大体积接收域阻止根阶固定对数预算；另对特定全空间resolvent／正时间混合有至少线性成本。其失败范围**不含Q内非恒定杀死、其他生成元或一般空间/路径权重**，更不否定极大算子目标。本轮不重复其数值或把README当证明。原文件为 `rounds/555—558/README.md`。

R628则已核原证明：`ν(dz)=2^(−n)max(1,||z||∞)^(−n)1_{||z||<t}dz` 是**选择历史增量测度，不是原f**。在 `n≥2^24`、`t=n/(c ln n)`、`c∈[1/2,1]`、`τ≥1`，完整低内段＋高捕获外段 `<3n`；角帽质量 `B≥n ln n/4`。固定n后允许足够大a和相应有限族，可在原最大半径选择算法中实现全部前缀累计资格及最后未捕获角点，`sup W_uncaptured(0)≥n ln n/8`（n≥2^36）。它确实超出静态放松，但量词是每个误差可另选a和有限族。[真实历史生成 [628/REPORT.tex:113]](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/628/research.zip)、[最终独审 [628/AUDIT.md:159]](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/628/research.zip)。

这只排除任意供应族统一点态load根阶付款。它没有大弱型比值，因为同一L1输入下必须保留坏星松弛：`Σv_i=∫fW−Σv_i(h_i−1)`，共同星交例中该松弛正好抵消高负载。不可由“存在坏供应族”换成“同f所有合法选择都坏”。

R630对光滑紧支撑f的联合outer-contact映射 `(y,v)→(x,β)` 的Jacobian是 `(a0−β)/v`；使用完整future约束确定外根，避免非法丢固定level折叠分支。light费用一次为 `(60/7)LM`，完整剩余是heavy trace。质量时钟 `∫_G A′dv=τ|G|` 对L1有效，却只付dv/B，不付trace的dv/v；原子经典导数不能套用。[完整contact [630/REPORT.tex:63]](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/630/research.zip)、[审计 [630/AUDIT.md:15]](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/630/research.zip)。

R631同射线全部旧接触可共享一次未来父和fresh质量，但全来源/方向的incoming列帽仍缺，递推落Eτ要支付1/τ，fresh条件化还可能支付γ_L。角向Green式必须保留 `A−W−R−N` 的共同截断：光滑平台上正面通量A与负bulk W各自对数发散、trace为零。旧只保face−normalizer的稿已被修正。[必要取消 [631/REPORT.tex:90]](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/631/research.zip)、[修正审计 [631/ccu_r631_flux_audit.md:11]](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/631/research.zip)。两条完整余项不能免费相互转账。

## 5. 最新完整族中的实付部分及其用途

R642全源行等价于旧正体积交图的universal顶点；一次删全部universal后，真实余owner重新分配，须重求KKT源。完整费用保留平方根，统一有

`ch+5L_del≤ηV+(52+200/η)M`（η>0，0<c≤1）。

这是可吸收的一次费用，未付主步F仍是无universal临界族的完整同动作收益。R644—645扩为任意真实fullowners、重新校准；接触标签桥只恢复已有严格内部动作收益，不创造好动作。R645删任意小体积行仍须带source变化和lift费用。[原删行付款 [642/REPORT.tex:117]](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/642/research.zip)、[所有权扩类 [644/REPORT.tex:66]](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/644/research.zip)、[严格恢复 [645/REPORT.tex:132]](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/645/research.zip)。固定N／全有限统一参数的最终正确性另由bridge_audit专查，本文不重复其代数。

R643实际正则Q是含log最优者的**线性部分**，不是整个目标值。新接触可使Q上跳而W不变、D下跳；四个严格反证书都远离困难窗，只否定无条件好跳跃。全路径恒等式

`D=(W−V)−R C_cont+R J_contact+R Z_delete+R B1−R B0`

无事件数损失，但 `RB0≤4V`是主阶负费。一次包熵界导致低方差临界支必要规模 `N≥exp(56H/9−1)/9`；不能换成log n，少量方体例很难测试该支。[完整路径 [643/REPORT.tex:54]](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/643/research.zip)、[来源熵 [643/REPORT.tex:196]](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/643/research.zip)、[接触反证书审计 [643/JUMP_AUDIT.md:1]](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/643/research.zip)。

R646对全部旧行的同源运输τ非负、覆盖所有m_j、总质量B≤2M；从实际含有的Lebesgue密度剥离再归一，给真实容量信用。**同一次动作**若满足O≤V且B≤M+V/(2R)，可实付 `D≥V/2−M`。存在这种动作的一般定理未证。[原源构造/条件分支 [646/REPORT.tex:52]](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/646/research.zip)。R647低增长输入片对完整 `2O+R(B−M)+` 由其增长方差支付并余 `3A_L/(2ε)`；远来源信用带实际receiver load w，不能付所有无权物理cut，且不允许再外领同一容量信用。[原文 [647/REPORT.tex:50]](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/647/research.zip)。

R648—649全尺度中心尾按一次来源根覆盖可付，H改为真实ownership加权后 `0≤H≤4M`，实际归一后 `H_next=εΣp_jh′_j`。这消除了单独α/λ换权和随机归一分母，但旧来源prototype不是新来源。Young/Cauchy独立处理放松标量相关项需要Θ(n)增长预算；这是该放松的成本，不是方体必需损失。[一次尾覆盖 [648/REPORT.tex:243]](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/648/research.zip)、[真实原型 [649/REPORT.tex:49]](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/649/research.zip)。

R651完整源势极小集是轴矩形，有唯一最优半径向量和显式距离模数；模数依赖实际权，可能很大。接触pattern的分数覆盖给全族 `Στ_e≤√(2n)μ`，无标签/尺度数，但这只付**来源单位**，没有消掉物理价u/ε和新来源行需求。[矩形证明 [651/REPORT.tex:123]](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/651/research.zip)、[分数覆盖 [651/REPORT.tex:260]](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/651/research.zip)。R652联合选真正owner及actual α，除δW基线外取所有合资格中的最低实际u′；R656改min-Q后不得继承该规则。R653强侵入owner**面积**付 `V_B≤(2/3)RS+(15/64)E_next,C`，C只含u′>8κ/3；这不是丢失副本重数界，未来O仍未付。[capture与联合选择 [652/REPORT.tex:120]](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/652/research.zip)、[系数及两步总账 [653/REPORT.tex:243]](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/653/research.zip)。

R654来源可选为饱和坐标格内的产品型正宽AC混合，保持全部旧m、所有权和实际λ，并任意逼近源势下确界。产品性仅在格tag条件下；碰撞／owner条件化后不独立，宽度无统一下界。完整loss窗口必须保留真实丢失指示，不能换成incoming。[合法源选择及实际核 [654/REPORT.tex:137]](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/654/research.zip)。

## 6. R655—R657：来源平衡、完整熵收益与同步细分

R655是在同一全有限ε_*下改变**整个合法实验**：真实I_j等分、λ_j等分，旧Q,V,M,R,κ,H,E及score精确保留；新锚独立重采样，全部新几何/owner/α都重算。actual新α聚合β后仍在固定旧packing多面体；共同旧cell测试 `f_r=Σβ_j1_Aj∈[0,1]`。有限旧cell数B只决定后来选的有限r，可得

`E|μhat_H,r(f_r)−μ_H(f_r)|≤(M/2)√(B/r)`，`r≥25B/ζ² ⇒ R|Γ_H,r|≤ζV`。

这是真正可付的整个high相关费，既不要求α稳定也不需good/bad拆分；不能说原r=1的费已减小，更不能说完整D已正。[原证明 [655/REPORT.tex:178]](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/655/research.zip)、[独审量词 [655/CLONE_INDEPENDENT_AUDIT.md:1]](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/655/research.zip)。正探索先固定，再有限克隆，使receiver union趋W_reach；并不推出Q′或D趋好值。

R656固定tuple的真实min-Q ownership可改善D。最优**线性**dual ν的row slack σ和actual entropy deficit d满足 `d=U_ν+Σσ_jα_j`，local replacement给ν(C_j)≤P_Nj，故MAX压力的端点/凸弦和有限owner见证合法。保留未使用U_ν不等于它已付。[MAX原证明 [656/REPORT.tex:163]](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/656/research.zip)。

R657的实质新工具是**固定同一个owner试验p**的floors `ell_j(p,t)≤α_j(p)`，令

`L(ell)=max{m·β:Aβ≤1,β≥ell}`，`G_p(t)=P−L(ell(p,t))`。

从t0=0迭代tk+1=G_p(tk)，每个有限步可行、非降且≤真实d(p)。其对偶

`G_p(t)=max_y{(Aᵀy−m)·ell(p,t)−(||y||−P)}`

必须扣非最优dual额外质量。它可检测所有最优dual row slack为零却整个线性最优面被floor排除的负载损失；三twin真实二维receiver模型给G(0)=169/22，而R656全部最优row价格皆零。该模型没有旧KKT/Euler/近score/ε_*认证。[原LP和严格有限例 [657/REPORT.tex:135]](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/657/research.zip)、[终审 [657/FINAL_GEOMETRY_AUDIT.md:16]](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/657/research.zip)。floor在εW端点可不可行，**不能每步换owner取MAX**；可分别完成固定trial链，再比较实际Q′。下证G必须用L的对偶上证，只有可行primal方向错误。

来源相关联合律有三个不同机制，不能拼成一个免费推论：

1. 正确row边际的first-hit或有限block coupling是合法新实验；路径几何、全owner、actual entropy、fullD和score桥不需跨row独立。独立block的有效样本数是block数N，不是总clone数bN；旧单row ghost及row乘积公式不能沿用。旧cell误差≤(M/2)√(B/N)，receiver可趋W_reach，但小block优化D没有已证持久性。
2. systematic旧cell标签计数每格floor/ceiling，再从每格真实条件AC源采点，**与phases独立**，保正确连续row边际。其共同旧代数TV≤BM_H/(2r)，控制自适应共同f_Z；不控制全连续TV、loss窗口、new-C probe或行依赖probe。它会改变D。
3. 同倍数k、嵌套真实I细分、每child沿用parent锚，是精确同步refinement。image每parent恰一child、fill每parent恰k child，因此uniform baseline聚合精确保留，owner-volume多面体投影满射。固定fine p时 `α_bh=β_b p_bh/p_b`，故实际聚合Q′、W、D及min-Q值逐tuple相同；未来owner可重切，不保证旧pointwise切法原样保留。加权经验源及high限制也完全相同。它不造新独立样本、不降低旧TV、不驱动T_r→0，也不修复不在ε_*校准类的粗模型。[完整三机制 [657/REPORT.tex:372]](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/657/research.zip)、[同步原证 [657/REPORT.tex:450]](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/657/research.zip)、[独立同步审计 [657/REFINEMENT_AUDIT.md:7]](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/657/research.zip)。

有限证据：r=2、h=10^−12的真实正宽AC六tuple耦合相对独立law的fullD优势≥48987491/125000000；误差定理仅r=2。r=3/4/5完整原子枚举和有理候选支持不能外推正宽或一般阶数；r=5全百万均值未由第二程序独立重算，audit只复核汇总/候选支持。r=4平衡14点law每个源原子经验质量恰4，支撑级别严格核验；它仍是原子低R例，W=3强迫κ′≥63/5>4，排除在全有限ε_*域外。[数值原文边界 [657/REPORT.tex:575]](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/657/research.zip)、[平衡审计 [657/BALANCED_AUDIT.md:1]](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/657/research.zip)。

## 7. 已明确存在的更短一般动作权限：不可冒充新结果

父线程追加定点核验的答案是：**历史已经明确允许该一般动作**，不是必须继承Euler/capture/δ资格。

R644 REPORT:38—41、R645:32—35、R646:32—39均直接写：任取z_j∈[−1,1]^n，ρ_j=m_j^(1/n)/2=t_js_j，`c_j=y_j+(ρ_j−s_j)z_j`，所以完整中心窗

`||c_j−y_j||∞≤(t_j−1)s_j`，`C_j⊃A_j`，`|C_j|=m_j`。

新receiver是C_j/a；可取任意真实fullownership，删真实零owner后重求actual entropy，旧μ覆盖每行m_j给Q′≤M。R646的通用完整D账在§1即成立；half/Euler限制到§4才加入。[最早实读明确条款 [644/REPORT.tex:23]](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/644/research.zip)、[完整通用动作与D账 [646/REPORT.tex:20]](https://github.com/alizeisnotalice/Math-Research/blob/592365ec900ac8fadf4808a3ab00452a314a8adc/centered-cube-upper-bound/rounds/646/research.zip)。

R650:123—127的校准类是所有实际fullowner状态，并非某一个选择器可达状态；原始输入恢复没有额外a^n。R655全有限ε_*使任意有限后继/克隆保持同类（细节另由bridge_audit复核）。因此直接证明同类任意合法全族更新的 `D≥cV−CK√n M`，可不使用Euler边际、capture、δ、Γ。R657:101—109的唯一终端源势费用至多4LM；direct fullD不应再扣未使用Γ。**这只是去掉历史非必要资格的旧权限，不提供所需正增量。**

## 8. 最小依赖和纯平方根的新验收线

建议主证明只用：真实有限全owner/实际熵KKT；同一全有限ε_*及无最终a^n的原f恢复（bridge_audit）；上述一般中心窗动作、actualQ′≤M与D；必要的一次终端4LM。是否用克隆／平衡／floor证书取决于新几何是否实质受益。若直接fullD可闭，不必带入R548、R559旧时钟、Euler资格和经验误差账。

仍未证的是对全部困难near-score状态，选择**同一次**真实有限新族及全owner，使完整接收和actual熵费用达到正cV减统一来源费。若走R657指定联合律，则必须同一law同时有来源准确性和fullD收益，并保留 `K=T0Π−W_reach`、`T_r=W_reach−EW_r`；同步细分只保存一个已成功粗law。

纯平方根目标不能由旧 `√n polylog n` 条件回代自动得到：L必须最终≤C√n，或者所有log由已证补偿消除；R571的N_n≈log n局部化、R611历史octave定位及任何时间／来源层数都要实际结算。full有限族直接入口是目前最短的无额外log入口，但核心几何预算仍无证明。不能把来源通道√(2n)容量直接当物理接收√n，因为u/ε和actual新源需求尚在。

本任务实际本机计算只做6个SymPy零残差和3个Fraction常数重建，结果在读表内：R548局部差、commonη、完整G因子导数、低增长分解、同步熵梯度及后继源质量D身份全部残差0；169/22、48987491/125000000、15/64准确重建。最初系统Python无SymPy，切换用户已有3.12.14数学venv后完成。没有重跑历史几何/优化/百万枚举，也不以这些标量检查认证一般定理。
