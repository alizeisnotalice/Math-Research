"""R626: exact rational event sweep, importing performs no computation."""
from fractions import Fraction as F
from itertools import groupby
from math import prod
from time import monotonic

def rational(x):
    if isinstance(x,float):raise TypeError('supply exact rational values, not float')
    return F(x)
def floor(q):return q.numerator//q.denominator
def ceil(q):return -((-q.numerator)//q.denominator)
class BudgetExceeded(RuntimeError):pass

def strict_count(R,u,a):
    """Count lattice points in open moving cube exactly, R>0."""
    R=rational(R);u=list(map(rational,u));a=list(map(rational,a));
    if R<=0 or len(u)!=len(a) or any(v<=0 for v in a) or any(abs(v)>=1 for v in u):raise ValueError('invalid arguments')
    return prod(1+(ceil(R*(1+v)/w)-1)+(ceil(R*(1-v)/w)-1) for v,w in zip(u,a))

def scan_exit(u,a,tau=F(3,4),*,max_events=200000,seconds=30,current_R=None):
    u=tuple(map(rational,u));a=tuple(map(rational,a));tau=rational(tau);n=len(a)
    if not n or len(u)!=n or any(v<=0 for v in a) or any(abs(v)>=1 for v in u) or tau<=0:raise ValueError('invalid geometry')
    delta=1/prod(a)
    if not delta<tau:raise ValueError('delta must be strictly below tau')
    if max_events<1 or seconds<=0:raise ValueError('invalid resource budget')
    start=monotonic();v=tau/delta;w=(v-1)/(v+1)
    # log(v)>2w for v>1: this rational cutoff is safely beyond all bad radii.
    cut=sum(a)/(4*w)
    events=[];total=0
    for axis in range(n):
        for sign in (-1,1):
            step=a[axis]/(1+sign*u[axis]); kmax=floor(cut/step);total+=kmax
            if total>max_events:raise BudgetExceeded('full event list exceeds budget')
            events.extend((step*k,axis) for k in range(1,kmax+1))
            if monotonic()-start>seconds:raise BudgetExceeded('time budget exceeded')
    events.sort();groups=[(r,[axis for _,axis in group]) for r,group in groupby(events,key=lambda x:x[0])]
    counts=[1]*n;left=F(0);Vstar=F(0);bad_count=0;win=None
    for right,axes in groups+[(cut,[])]:
        if monotonic()-start>seconds:raise BudgetExceeded('time budget exceeded')
        if left<right:
            A=prod(counts)
            if A>tau*(2*left)**n:
                candidate=min(F(A,1)/tau,(2*right)**n)
                bad_count+=1
                if candidate>Vstar:Vstar=candidate;win={'left':str(left),'right':str(right),'count':A,'sup_volume':str(candidate)}
        for axis in axes:counts[axis]+=1
        left=right
    current=None
    if current_R is not None:
        R=rational(current_R);A=strict_count(R,u,a);V=(2*R)**n
        current={'r':str(R),'strict_count':A,'V':str(V),'one_bad':A>V,'one_bad_slack':str(F(A)-V),'tau_bad':A>tau*V,'dominated_by_Vstar':V<=Vstar}
    return {'n':n,'u':list(map(str,u)),'a':list(map(str,a)),'tau':str(tau),'delta':str(delta),'rational_safe_cutoff':str(cut),'events_including_ties':total,'event_groups':len(groups),'bad_plateaus':bad_count,'Vstar_exact':str(Vstar),'winner':win,'current':current,'elapsed_seconds':monotonic()-start}

if __name__=='__main__':
    # n=1, a=2, u=0: A=1 on (0,2), tau=3/4.
    # The first interval has sup volume 4/3, later event intervals have
    # sup A/tau with A=3 at R just above 2: count 3 <= tau*4, so not bad.
    z=scan_exit([0],[2],current_R=F(1,4));assert z['Vstar_exact']=='4/3'
    assert z['current']['one_bad'] and z['current']['dominated_by_Vstar']
    assert strict_count(2,[0],[2])==1 and strict_count(F(2001,1000),[0],[2])==3
    # Check exact swept upper bound and an interior point near its optimum.
    cases=[([0,0],[2,2]),([F(1,3),F(-1,5)],[2,3]),([F(1,2),0],[2,2])]
    for u,a in cases:
        result=scan_exit(u,a);V=F(result['Vstar_exact']);cut=F(result['rational_safe_cutoff'])
        for k in range(1,1000):
            R=cut*F(k,1000);A=strict_count(R,u,a)
            if A>F(3,4)*(2*R)**len(a):assert (2*R)**len(a)<=V
    print('open-boundary ties, rational cut, plateau-grid samples passed')
