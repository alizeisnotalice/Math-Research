#!/usr/bin/env python3
"""RECONSTRUCTED audit checker; the original 192-record stdin code was not saved.

Replays exactly one stored record. It uses source scripts for event interval
construction and compares weights independently using 60-digit mpmath;
receiver E is checked by a separate rational full-event search.
"""
import argparse, importlib.util, json, math, sys
from fractions import Fraction as F
from pathlib import Path
import numpy as np
import mpmath as mp

def e_exact(a,x):
    n=len(a); v=F(3,4)*math.prod(a); cut=sum(a)/(4*(v-1)/(v+1)); events=[]
    def ceil(q):return -((-q.numerator)//q.denominator)
    for axis,(step,z) in enumerate(zip(a,x)):
        km=ceil((cut+abs(z))/step)+1
        events.extend((abs(k*step-z),axis) for k in range(-km,km+1) if abs(k*step-z)<=cut)
    events.sort(); counts=[0]*n;i=0
    while i<len(events):
        t=events[i][0]
        while i<len(events) and events[i][0]==t:counts[events[i][1]]+=1;i+=1
        if t and math.prod(counts)>(2*t)**n:return 1
    return 0

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--module-dir',type=Path,default=Path(__file__).resolve().parent)
    p.add_argument('--occupation-script',type=Path,default=Path(__file__).resolve().parent/'occupationview.py')
    p.add_argument('--source',type=Path,default=Path(__file__).resolve().parent/'sourceview.json')
    p.add_argument('--occupation',type=Path,default=Path(__file__).resolve().parent/'occupationview.json')
    p.add_argument('--n',type=int,default=7);p.add_argument('--block',type=int,default=0);p.add_argument('--row',type=int,default=0)
    a=p.parse_args();assert 0<=a.row<64
    sys.path.insert(0,str(a.module_dir));import ccu_r626_numeric as base
    import ccu_r626_sourceview as old
    spec=importlib.util.spec_from_file_location('occ_check_dependency',a.occupation_script);occ=importlib.util.module_from_spec(spec);spec.loader.exec_module(occ)
    src=json.loads(a.source.read_text());dst=json.loads(a.occupation.read_text())
    row=next(v for v in src['results'] if v['n']==a.n and v['block']==a.block)
    saved=next(v for v in dst['results'] if v['n']==a.n and v['block']==a.block)
    spacing=base.geom(a.n);rng=np.random.default_rng(row['seed']);new=np.random.default_rng(row['seed']+8626000)
    for _ in range(a.row+1): draw=rng.random(a.n+1);uniforms=new.random(2)
    u=2*draw[:a.n]-1;parts,_=occ.intervals(u,spacing,base.cutoff(spacing));R=max(b for _,b in parts);mp.mp.dps=60
    wf=[];wm=[]
    for lo,hi in parts:
        wf.append((hi/R)**a.n if lo==0 else math.exp(a.n*math.log(hi/R))*(-math.expm1(a.n*math.log(lo/hi))))
        wm.append((mp.mpf(float(hi))/mp.mpf(float(R)))**a.n-(mp.mpf(float(lo))/mp.mpf(float(R)))**a.n)
    total=math.fsum(wf);high=mp.fsum(wm);index=min(int(np.searchsorted(np.cumsum(wf),uniforms[0]*total,side='right')),len(parts)-1)
    hindex=len(parts)-1; acc=mp.mpf(0)
    for j,w in enumerate(wm):
        acc+=w
        if acc>mp.mpf(float(uniforms[0]))*high:hindex=j;break
    lo,hi=parts[index];z=max(np.finfo(float).tiny,min(1-np.finfo(float).eps,float(uniforms[1])));fraction=z if lo==0 else math.exp(a.n*math.log(lo/hi))*(1-z)+z;r=hi*math.exp(math.log(fraction)/a.n)
    sp=[F.from_float(float(v)) for v in spacing];uq=[F.from_float(float(v)) for v in u];rq=F.from_float(float(r))
    def ceil(q):return -((-q.numerator)//q.denominator)
    counts=[1+ceil(rq*(1+q)/s)-1+ceil(rq*(1-q)/s)-1 for q,s in zip(uq,sp)]
    tau_bad=F(math.prod(counts))>F(3,4)*(2*rq)**a.n
    x=(-r*u+spacing/2)%spacing-spacing/2; E=e_exact(sp,[F.from_float(float(v)) for v in x]);float_E,_=old.E1(x,spacing,base.cutoff(spacing))
    relative=float(abs(mp.mpf(total)-high)/high)
    outcome={'n':a.n,'block':a.block,'row':a.row,'source_seed':row['seed'],'float_and_highprec_interval_equal':index==hindex,'weight_relative_error':relative,'replayed_ratio':min(1.,total),'saved_ratio':saved['occupation_ratios'][a.row],'strict_tau_bad':tau_bad,'E_rational':E,'E_float':float_E,'saved_state':saved['states'][a.row]}
    assert index==hindex and tau_bad and E==float_E==saved['states'][a.row] and outcome['replayed_ratio']==outcome['saved_ratio']
    print(json.dumps(outcome,indent=2))
if __name__=='__main__':main()
