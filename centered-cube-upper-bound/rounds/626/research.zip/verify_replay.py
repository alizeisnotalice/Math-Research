#!/usr/bin/env python3
"""Compare saved 3-block replays and exact certificates; no simulations are run."""
import json,hashlib
from pathlib import Path
P=Path(__file__).resolve().parent
load=lambda q:json.loads((P/q).read_text())
a=load('sourceview.json');b=load('replay/sourceview.json');errors=[]
assert {(z['n'],z['block']) for z in b['results']}=={(7,0),(32,0),(128,0)}
for r in b['results']:
 q=next(z for z in a['results'] if (z['n'],z['block'])==(r['n'],r['block']))
 for k in ('n','block','seed','N','Z_hits','Z_ambiguous','E_hits','E_ambiguous','source_cube_reject','source_cube_ambiguous','Z_values','E_values','max_forward_events'):
  if r[k]!=q[k]:errors.append(('source',r['n'],k))
a=load('occupationview.json');b=load('replay/occupationview.json')
assert {(z['n'],z['block']) for z in b['results']}=={(7,0),(32,0),(128,0)}
for r in b['results']:
 q=next(z for z in a['results'] if (z['n'],z['block'])==(r['n'],r['block']))
 for k in ('n','block','same_u_seed','independent_v_seed','samples','Z_hits','Z_ambiguous','guard_ambiguous','occupation_ratios','states','old_Z_values','same_u_paired','interval_count_max','pilot_exit_relative_difference'):
  if r[k]!=q[k]:errors.append(('occupation',r['n'],k))
a=load('statistics_original.json');b=load('replay/statistics_replay.json');assert a['results']==b['results'],'exact tail results changed'
a=load('certificate_original.json');b=load('replay/certificate_replay.json');assert a['cases']==b['cases'] and a['samples']==b['samples'],'Arb/rational certificate changed'
assert not errors,errors
out={'status':'passed','replayed_blocks':[7,32,128],'sourceview_fields':'all stable computational fields identical','occupationview_fields':'all stable computational fields identical','exact_statistics':'all final9 exact-tail result fields identical','arb_cutoffs':'all five Arb cases identical','rational_exit_samples':'both saved cases identical','executed_script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
(P/'verification_receipt.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
