import json,sys,platform,time,resource,hashlib,argparse
from pathlib import Path
from flint import arb,fmpq,ctx
start=time.perf_counter();cpu=time.process_time();ctx.prec=256
A=lambda p,q=1:arb(fmpq(p,q))
def root(z,n):return (z.log()/n).exp()
def ep(z):
 l=z.lower().man_exp();u=z.upper().man_exp();return {'lower':[str(l[0]),int(l[1])],'upper':[str(u[0]),int(u[1])],'display':z.str(30)}
tau=A(3,4);a1=(root(A(8),7)+root(A(288),7))/2;at=(1+root(A(2),7))/2
cases=[('anisotropic7',7,[a1]+[at]*6)]
for n in (16,32,64,128):cases.append(('balanced',n,[root(A(4)*root(A(n),4),n)]*n))
rows=[]
for label,n,axes in cases:
 prod=arb(1)
 for x in axes:prod*=x
 delta=1/prod;gap=tau-delta;assert gap>0
 R=sum(axes,arb(0))/(2*(tau/delta).log());assert R>0
 rows.append({'family':label,'n':n,'axis_first':ep(axes[0]),'axis_other':ep(axes[-1]),'delta':ep(delta),'tau_minus_delta':ep(gap),'Rmax':ep(R)})
# Cross-check two representative serialized binary64 inputs with exact rational event sweep.
import importlib.util
from fractions import Fraction as F
ROOT=Path(__file__).resolve().parent
parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,default=ROOT/'certificate_replay.json');args=parser.parse_args()
samplepath=ROOT/'sample_input.json'
gpath=ROOT/'ccu_r626_geometry.py';spec=importlib.util.spec_from_file_location('r626geom',gpath);g=importlib.util.module_from_spec(spec);sys.dont_write_bytecode=True;spec.loader.exec_module(g)
sampledata=json.loads(samplepath.read_text());samples=[]
for n in (7,16):
 z=next(v for v in sampledata if v['n']==n)
 result=g.scan_exit(z['u_exact_binary64'],z['a_exact_binary64'],current_R=z['sample_r_exact_binary64'],seconds=20)
 vv=F(result['Vstar_exact']); aa=A(vv.numerator,vv.denominator);exit_r=root(aa,n)/2
 r0=F(z['r0_exact_binary64']);rat=(2*r0)**n/vv
 samples.append({'n':n,'seed':z['seed'],'category':z.get('category'),'input_semantics':'exact rationals representing serialized binary64 spacing and u, not ideal irrational spacing or unrounded direction','Vstar_exact':str(vv),'exit_radius_enclosure':ep(exit_r),'saved_exit_float':z['exit_radius_recovered'],'ratio_exact':str(rat),'saved_ratio_float':z['ratio_saved'],'current':result['current'],'event_groups':result['event_groups']})
out={'precision_bits':ctx.prec,'tau':'3/4','cases':rows,'samples':samples,'sample_input_sha256':hashlib.sha256(samplepath.read_bytes()).hexdigest(),'event_algorithm_sha256':hashlib.sha256(gpath.read_bytes()).hexdigest(),'scope':'rigorous Arb intervals for density/cutoff; exact-event sample checks for rounded binary64 inputs only, not original irrational spacings or sampling error','script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'python':sys.version,'python_flint':__import__('flint').__version__,'sys_executable':sys.executable,'platform':platform.platform(),'argv':[sys.executable]+sys.argv,'wall_seconds':time.perf_counter()-start,'cpu_seconds':time.process_time()-cpu,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_text(json.dumps(out,indent=2)+'\n');print([(r['family'],r['n'],r['delta']['display'],r['Rmax']['display']) for r in rows]);print('sha',out['script_sha256'])
