# R626 独立终审

日期：2026-10-28。依据当前`/tmp/ccu_r626_main.md`，重点独审strict B_τ occupation核及§4固定维数finite-L1转移。未运行新计算、未复算Monte Carlo或浮点事件，不修改作者文件。历史逐步审查保留在`/tmp/ccu_r626_audit.md`；本文件只记当前有效结论。

## 最终判断

**当前核的完整source预算、周期公式及固定维数finite-L1转移通过。一般receiver积分下界仍未证明，因此没有一般根阶弱型或finitepacking改进。** 转移的窗口应明确为连续K×…×K个基本胞的矩形block；任意散置K^n胞不能使用O(K^(n−1))边界误差。

## 已核的当前数学对象

统一使用strict bad m(x,r)>τV(r)，V(r)=(2r)^n，τ∈(0,1)。令

B_τ(y,u)=∫1{μ(Q(y−ru,r))>τV(r)}dV(r)，u∈(−1,1)^n。

它可测；有限来源下0≤B_τ≤Vstar≤M/τ。strict bad非空即有正右侧r区间，故B_τ>0，原子entry不造成活跃项零分母。以B_τ为分母、n dr/r为径向权的K_occ满足

∫K_occ(x,y)dx=2^(−n)|{u:B_τ(y,u)>0}|≤1，
∫C_occ≤M，C_occ(x)=∫K_occ(x,y)dμ(y)。

换元是x=y−ru，dx=V(r)du/2^n；没有丢失归一化因子。零方向贡献取0，不丢失strict bad活跃项。相同μ、τ及全部半径菜单下，C_occ≥C_exit。这是候选的真实强化，但仍是source-dependent joint kernel，不能把分母提出来源积分。

## 周期合同及finite-L1转移

单位atom矩形lattice、胞F体积1/δ、τ>δ时，完整计数cutoff使全部occupation有限。周期展开给

q_occ=∫_(F∩E1)C_occ
 =E_u E_(v uniform实际strict bad V区间并)1{M_μ(−v^(1/n)u/2)>1}。

无额外δ。若p=P_(uniform F)(E1)，则receiver平均信用为δq_occ/p。必须按V长度抽interval，不能按r长度或等概率选interval。τ=1时该条件抽样的事件恒真、q_occ=1，只是source守恒校验，不给receiver体积界。

主稿§4的转移链已核：

* bump source y=ηw及bump偏移共至多2η，给atomic半径r±2η夹逼；Rbar=Σ_i(ℓ_i+4η0)/(2log(τ/δ))统一控制全部η≤η0的τ-bad及1-level菜单。
* 固定interior u只需排除有限entry半径与platform阈值根。整批slab同时进入仍按真实jump处理。dV-DCT给B_τ,η(ηw,u)→B_τ,0(0,u)，后者≥1/τ；不假设方向共享同一个稳定η。
* atomic E1在胞内为有限开轴平行boxes之并，边界零测。卷积膨胀包含及strict内部稳定给receiver指示收敛；(u,v)映射不奇异，边界对联合flow零测。归一化occupation比例在[0,1]内，故联合DCT合法，无需未经证明的inverse-B支配。
* 连续矩形core外保留全部格点bumps，collar>3Rbar+2η0。core内完整E1、B_τ、K、C与周期bump严格一致；截断是子来源，不产生新outer bad半径。质量及体积边界O(K^(n−1))，receiver信用边界用一次source预算支付同阶。

因此固定维数下，η→0、K→∞的相应对角序列确给有限光滑L1输入，并保存完整occupation信用与receiver体积的每source质量极限。此为模型转移定理，不是维数统一误差估计；不加density cap或坐标独立假设。

## 证据范围与仍未证目标

旧exit数据与新occupation数据属于不同normalizer，必须分开。有限512样本及其条件统计只描述实现的诊断：没有认证浮点count、exit、strict事件或完整菜单。二值iid抽样可用binomial口径；每方向积分所得[0,1]比例平均则不是Bernoulli。finite-L1转移不把未区间化的样本结果升级为严格积分数值。

仍未证明对全部真实L1来源有

∫_(E1)C_occ≥κ_n|E1|−εM，κ_n≈1/(√n polylog n)，

或等价的低信用体积严格吸收。局部annulus、逐pair mass growth、τ=1恒等式及周期有限样本都不替代它。该完整lower若将来成立，可通过最优来源及已付P=(1+1/a)^n≤e回到原finitepacking；本轮尚不能替换R559母账。终审完成，停止。
