# R626：复现与证据边界

解释器：`/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python`。
实际版本见原始结果与 computational_provenance.json：Python 3.12.14、NumPy 2.5.4、SciPy 1.18.1、python-flint 0.9.0。以下在解压目录执行，`python` 应替换为上述绝对解释器。没有编译 PDF。

## 最小重放

```sh
python ccu_r626_sourceview.py --phase pilot --workers 3 --output-dir replay
python occupationview.py --phase parity --workers 3 --output-dir replay
python certificate.py --output replay/certificate_replay.json
python statistics_exact.py --output replay/statistics_replay.json
python verify_replay.py
python occupation_check_reconstructed.py --n 7 --block 0 --row 0
```

前两条有依赖，应顺序执行；每条内部并行计算 7、32、128 维的一个批次。原完整计算每维 8 批、每批 64 条，后续 21/23 个独立批次实际使用 12 个进程。所有数值进程的 BLAS/OMP 线程数为 1，避免嵌套并发。源视角旧核、占用新核及独立接收点各维均为 512 条。保留最小重放结果，不重复存储可生成的全部中间薄层扫描。

新旧模拟的原始 JSON 中含早期区间，已经由 `statistics_original.json` 的统一九项区间替代；原计数保持不变。`STATISTICS.md` 给最终口径。`verify_replay.py` 比较稳定字段，不将运行时间或文件路径作为数学字段。

## 各类证据不可混同

- REPORT.tex / FINAL_AUDIT.md：来源预算、逐点支配、周期积分身份、固定维数平滑/截断转移；未证明一般根阶接收下界。
- certificate_original.json：五组真正无理格距的 Arb 密度及全尺度截断包围；两条退出证书仅针对保存的二进制近似输入。
- statistics_original.json：十八个二项尾概率用整数精确验证，每个不超过 1/360。九区间同时覆盖至少 95% 的结论以理想 iid、准确事件为条件；不包含随机数离散、格距和事件的浮点误差。
- sourceview.json / occupationview.json：有限周期原子模型浮点试算。不能由 n=7,32,128 外推维数阶。
- occupation_audit_historical.json：实际完成过的 192 条有限核验记录。原标准输入源码未保存。`occupation_check_reconstructed.py` 明确为事后重建、只实际复跑一条，不能冒充原 192 条的完整独立可复现脚本。

原始代码哈希与便携修改后代码哈希分别列在 computational_provenance.json。便携版已运行最小重放并逐项比较。报告中的“严格”只用于实际证明或有理/区间证书覆盖的对象；有限计算不认证一般 L1 定理。

## 资源与下一步

实测硬件为 15 逻辑核心、24 GiB 内存。原占用主批使用 12 个进程，任务很短；记录的 CPU 时间与墙钟不能解释为持续满载。当前没有以延长无关扫描来提高占用率。MATLAB 本轮未运行，也未宣称提供交叉认证。

下一决定性问题是对任意真实 L1 来源证明完整接收积分的根阶下界，或构造可求和、可吸收的低信用集合递推。未付来源复用仍须统一结算；不退回薄层/单点信用替代全体积分。
