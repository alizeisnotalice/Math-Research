import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[k]='1'
import argparse,concurrent.futures,hashlib,json,math,platform,resource,shlex,sys,time
from pathlib import Path
import numpy as np,scipy
from scipy.stats import beta
import ccu_r626_numeric as base,ccu_r626_sourceview as old
TAU=.75;LT=math.log(TAU)

def intervals(u,a,Rmax):
 n=len(a);events=[]
 for axis,(v,d) in enumerate(zip(u,a)):
  for h in (1+v,1-v):
   if h<=1e-15:continue
   for k in range(1,int(math.floor(Rmax*h/d+1e-12))+1):events.append((d*k/h,axis))
 events.sort();counts=[1]*n;logm=0.;last=0.;i=0;parts=[]
 while True:
  nxt=events[i][0] if i<len(events) else Rmax;root=.5*math.exp((logm-LT)/n);end=min(nxt,root,Rmax)
  if end>last:parts.append((last,end))
  if i>=len(events) or nxt>=Rmax:break
  last=nxt
  while i<len(events) and events[i][0]==nxt:
   axis=events[i][1];c=counts[axis];counts[axis]+=1;logm+=math.log((c+1)/c);i+=1
 return parts,len(events)

def run(task):
 n,block,oldrow=task;start=time.monotonic();cpu=time.process_time();a=base.geom(n);cut=base.cutoff(a);rng=np.random.default_rng(oldrow['seed']);newrng=np.random.default_rng(oldrow['seed']+8626000);hits=amb=0;ratios=[];states=[];guards=0;eventnum=[];maxdiff=0.;oldz=oldrow['Z_values']
 for ix in range(64):
  draw=rng.random(n+1);u=2*draw[:n]-1;parts,nev=intervals(u,a,cut);assert parts;R=max(z[1] for z in parts)
  if n==7 and block==0:
   R0,_=base.anchored_exit(u,a,cut);maxdiff=max(maxdiff,abs(R-R0)/R0)
  weights=[]
  for lo,hi in parts:
   w=(hi/R)**n if lo==0 else math.exp(n*math.log(hi/R))*(-math.expm1(n*math.log(lo/hi)))
   weights.append(max(0.,w))
  occ=math.fsum(weights);assert 0<occ<=1+1e-10;ratios.append(min(1.,occ));cum=np.cumsum(weights);v=newrng.random(2);ii=min(int(np.searchsorted(cum,v[0]*occ,side='right')),len(parts)-1);lo,hi=parts[ii];z=max(np.finfo(float).tiny,min(1-np.finfo(float).eps,float(v[1])));fraction=z if lo==0 else math.exp(n*math.log(lo/hi))*(1-z)+z;r=hi*math.exp(math.log(fraction)/n)
  counts=1+np.floor(r*(1+u)/a).astype(int)+np.floor(r*(1-u)/a).astype(int);margin=float(np.log(counts).sum())-LT-n*math.log(2*r)
  if margin<=1e-10:guards+=1;states.append(-1);amb+=1;continue
  x=(-r*u+a/2)%a-a/2;e,_=old.E1(x,a,cut)
  if e==1:hits+=1;states.append(1)
  elif e==0:states.append(0)
  else:amb+=1;states.append(-1)
  eventnum.append(nev)
 return {'n':n,'block':block,'same_u_seed':oldrow['seed'],'independent_v_seed':oldrow['seed']+8626000,'samples':64,'Z_hits':hits,'Z_ambiguous':amb,'guard_ambiguous':guards,'occupation_ratios':ratios,'states':states,'old_Z_values':oldz,'same_u_paired':True,'interval_count_max':max(eventnum) if eventnum else 0,'pilot_exit_relative_difference':maxdiff,'elapsed_seconds':time.monotonic()-start,'cpu_seconds':time.process_time()-cpu,'peak_rss_bytes_macos':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}

def cp(k,N,alpha,upper=False):
 if upper:return 1. if k==N else float(beta.ppf(1-alpha/2,k+1,N-k))
 return 0. if k==0 else float(beta.ppf(alpha/2,k,N-k+1))

def main():
 p=argparse.ArgumentParser();p.add_argument('--phase',choices=('pilot','remaining','parity'),required=True);p.add_argument('--workers',type=int,default=12);p.add_argument('--output-dir',type=Path,default=Path(__file__).resolve().parent/'replay');a=p.parse_args();assert 1<=a.workers<=12;a.output_dir.mkdir(parents=True,exist_ok=True);source=a.output_dir/'sourceview.json';oldout=json.loads(source.read_text());path=a.output_dir/'occupationview.json';md=a.output_dir/'occupationview.md';t=time.monotonic()
 if a.phase in ('pilot','parity'):out={'sourceview_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'base_sha256':hashlib.sha256(Path(base.__file__).read_bytes()).hexdigest(),'python':sys.version,'numpy':np.__version__,'scipy':scipy.__version__,'platform':platform.platform(),'commands':[],'results':[]};tasks=[(n,0) for n in (7,32,128)] if a.phase=='parity' else [(7,0)]
 else:out=json.loads(path.read_text());tasks=[(n,k) for n in (7,32,128) for k in range(8) if (n,k)!=(7,0)]
 out['commands'].append(shlex.join([sys.executable]+sys.argv))
 def save():
  summaries=[]
  for n in (7,32,128):
   r=[x for x in out['results'] if x['n']==n];N=64*len(r)
   if not N:continue
   k=sum(x['Z_hits'] for x in r);q=sum(x['Z_ambiguous'] for x in r);v=[t for x in r for t in x['occupation_ratios']];source_summary=next(z for z in oldout['summaries'] if z['n']==n);delta=source_summary['delta'];PE=source_summary['P_E_estimate'];lo=cp(k,N,.05/6);hi=cp(k+q,N,.05/6,True);el,eu=source_summary['P_E_sampling_only_bonferroni_CP'];summaries.append({'n':n,'N':N,'new_Z_hits':k,'new_Z_ambiguous':q,'new_Z_estimate':k/N,'Z_sampling_only_CP':[lo,hi],'old_E_hits':source_summary['E_hits'],'P_E_old':PE,'delta':delta,'average_new_credit_estimate':delta*(k/N)/PE,'average_new_sampling_only_outer_interval':[delta*lo/eu,delta*hi/el] if el>0 else None,'B_over_Vstar_mean':float(np.mean(v)),'B_over_Vstar_min':min(v),'B_over_Vstar_max':max(v),'guard_ambiguous':sum(x['guard_ambiguous'] for x in r)})
  out['summaries']=summaries;path.write_text(json.dumps(out));L=['# R626 occupied-radius source budget','','For each previously sampled u, all anchored τ-bad radius plateaus are scanned and selected proportional to their occupied volume. New independent within-plateau uniforms are used, while directions are paired with the previous source-view sample. Binary event and CP intervals describe random sampling only, not floating geometric error. The new kernel dominates the old one analytically, but individual paired 0/1 observations need not be ordered.','','| n | N | new Z hits (ambig.) | new Z sampling interval | old P(E) | δ Z/P(E) | Bτ/Vstar mean | min–max |','|---:|---:|:---|:---|---:|---:|---:|:---|']
  for q in summaries:L.append('| %d | %d | %d (%d) | [%.6g, %.6g] | %.6g | %.6g | %.6g | %.6g–%.6g |'%(q['n'],q['N'],q['new_Z_hits'],q['new_Z_ambiguous'],*q['Z_sampling_only_CP'],q['P_E_old'],q['average_new_credit_estimate'],q['B_over_Vstar_mean'],q['B_over_Vstar_min'],q['B_over_Vstar_max']))
  L+=['','Retained source-view P(E) is independently sampled. All observations share the old u directions but use a separate seeded v uniform. The strengthened kernel and the old kernel are pointwise ordered analytically; sample means may reverse. No finite-L1 or general-dimensional conclusion follows.'];md.write_text('\n'.join(L)+'\n')
 with concurrent.futures.ProcessPoolExecutor(max_workers=a.workers) as pool:
  for f in concurrent.futures.as_completed([pool.submit(run,(n,k,next(z for z in oldout['results'] if z['n']==n and z['block']==k))) for n,k in tasks]):
   r=f.result();out['results'].append(r);save();print('done',r['n'],r['block'],'Z',r['Z_hits'],'guard',r['guard_ambiguous'],flush=True)
 out['last_phase_wall_seconds']=time.monotonic()-t;out['worker_cpu_sum_seconds']=sum(r['cpu_seconds'] for r in out['results']);out['max_worker_rss_bytes']=max(r['peak_rss_bytes_macos'] for r in out['results']);out['workers_last']=a.workers;save()
if __name__=='__main__':main()
