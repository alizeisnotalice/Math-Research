import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[k]='1'
import argparse,concurrent.futures,hashlib,json,math,platform,resource,shlex,sys,time
from pathlib import Path
import numpy as np
TAU=.75; LOGTAU=math.log(TAU)

def geom(n):
 if n==7:return np.array([(8**(1/7)+288**(1/7))/2]+[(1+2**(1/7))/2]*6)
 return np.full(n,(4*n**.25)**(1/n))

def cutoff(a):
 ld=-float(np.log(a).sum());assert ld<LOGTAU
 return float(a.sum())/(2*(LOGTAU-ld))*1.00000000001

def entry_events(x,a,R):
 ev=[]
 for i,(z,d) in enumerate(zip(x,a)):
  kmax=math.ceil((R+abs(z))/d)+1
  for k in range(-kmax,kmax+1):
   t=abs(k*d-z)
   if t<=R:ev.append((t,i))
 ev.sort();return ev

def find_bad(x,a):
 n=len(x);ev=entry_events(x,a,cutoff(a));counts=np.zeros(n,dtype=int);logm=0.;zero=n;i=0;best=None;sup=-float('inf')
 while i<len(ev):
  r=ev[i][0]
  while i<len(ev) and ev[i][0]==r:
   ax=ev[i][1];old=int(counts[ax]);counts[ax]+=1
   if old==0:zero-=1
   else:logm+=math.log((old+1)/old)
   i+=1
  if zero or r<=0 or r>=cutoff(a):continue
  exactlim=logm-n*math.log(2*r);sup=max(sup,exactlim)
  r0=(math.floor(r*10**6)+1)/10**6
  if i<len(ev) and r0>=ev[i][0]:continue
  margin=logm-n*math.log(2*r0)
  if margin>1e-8 and (best is None or margin>best['log_density']):best={'r0':r0,'m0':int(math.prod(map(int,counts))),'log_density':margin,'origin':'period_cell_search'}
 if best:best['float_max_log_average']=sup;best['finite_grid_max_log_gap']=max(0.,sup-best['log_density'])
 return best

def find_dimension(n):
 a=geom(n);near=[];ordinary=[];hits=0;attempts=0
 for k in range(512):
  attempts+=1;seed=626000+n*1000+k;rng=np.random.default_rng(seed);x=np.round((rng.random(n)-.5)*a,6);ans=find_bad(x,a)
  if ans is None:continue
  hits+=1;M=math.exp(ans['float_max_log_average']);target=(near if len(near)<4 else None) if M<=1.2 else (ordinary if len(ordinary)<4 else None)
  if target is None:continue
  target.append({'n':n,'seed':seed,'x':[format(z,'.6f') for z in x],'spacing':a.tolist(),'delta':float(math.exp(-np.log(a).sum())),'Rmax':cutoff(a),'search_trial':k,'category':'near_critical' if target is near else 'ordinary',**ans})
  if len(near)>=4 and len(ordinary)>=4:break
 return near+ordinary,{'n':n,'attempted':attempts,'hit_E1':hits,'near_critical_count':len(near),'ordinary_count':len(ordinary),'limit':512}

def anchored_exit(u,a,Rmax):
 n=len(a);events=[]
 for ax,(ui,ai) in enumerate(zip(u,a)):
  for denom in (1+ui,1-ui):
   if denom<=1e-15:continue
   kmax=int(math.floor(Rmax*denom/ai+1e-12))
   for k in range(1,kmax+1):events.append((ai*k/denom,ax))
 events.sort();counts=[1]*n;logm=0.;best=min(.5*math.exp(-LOGTAU/n),events[0][0] if events else Rmax);i=0
 while i<len(events):
  r=events[i][0]
  while i<len(events) and events[i][0]==r:
   ax=events[i][1];old=counts[ax];counts[ax]+=1;logm+=math.log((old+1)/old);i+=1
  nex=events[i][0] if i<len(events) else Rmax
  root=.5*math.exp((logm-LOGTAU)/n)
  if root>r:best=max(best,min(root,nex,Rmax))
 return best,len(events)

def task(arg):
 item,start_idx,end_idx=arg;n=item['n'];a=np.array(item['spacing']);x=np.array([float(t) for t in item['x']]);r0=item['r0'];V0=(2*r0)**n;m0=item['m0'];Rmax=item['Rmax'];rng=np.random.default_rng(item['seed']+6260000);rat=[];ev=[];guards=0;start=time.monotonic();cpu=time.process_time()
 # Stateless stream in fixed batches allows continuation without recalculation.
 for k in range(end_idx):
  draw=rng.random(n+1)
  if k<start_idx:continue
  r=r0*math.exp(draw[0]*math.log(1/TAU)/n);lo=np.ceil((x-r0)/a-1e-13).astype(int);hi=np.floor((x+r0)/a+1e-13).astype(int);counts=hi-lo+1;assert math.prod(map(int,counts))==m0
  pos=lo+np.minimum((draw[1:]*counts).astype(int),counts-1);y=pos*a;u=(y-x)/r;assert np.max(np.abs(u))<=1+1e-10
  R,N=anchored_exit(u,a,Rmax);guards+=int(R<r*(1-1e-11));assert R>=r*(1-1e-11);val=math.exp(n*math.log(r0/R));assert -1e-12<=val<=1+1e-10;rat.append(min(1.,val));ev.append(N)
 factor=(m0/V0)*math.log(1/TAU);mean=float(np.mean(rat)) if rat else None;alpha=.05/(40*3);eps=math.sqrt(math.log(2/alpha)/(2*len(rat))) if rat else 1
 return {'n':n,'seed':item['seed'],'start':start_idx,'end':end_idx,'samples':len(rat),'ratios':rat,'mean_ratio':mean,'L_estimate':factor*mean if rat else None,'hoeffding_confidence':'exploratory fixed-N Hoeffding interval, nominal union bound over 40 centers and three prespecified sample sizes; sampling error only, does not cover floating spacing, event or exit error','hoeffding_L_interval':[factor*max(0,mean-eps),factor*min(1,mean+eps)] if rat else None,'sample_min':min(rat) if rat else None,'sample_max':max(rat) if rat else None,'mean_events':float(np.mean(ev)) if ev else 0,'max_events':max(ev) if ev else 0,'guard_violations':guards,'elapsed_seconds':time.monotonic()-start,'cpu_seconds':time.process_time()-cpu,'peak_rss_bytes_macos':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}

def forward_plateaus(item):
 n=item['n'];a=np.array(item['spacing']);x=np.array([float(t) for t in item['x']]);Rmax=item['Rmax'];ev=entry_events(x,a,Rmax);counts=np.zeros(n,dtype=int);logm=0.;zero=n;i=0;out=[]
 while i<len(ev):
  lo=ev[i][0]
  while i<len(ev) and ev[i][0]==lo:
   ax=ev[i][1];old=int(counts[ax]);counts[ax]+=1
   if old==0:zero-=1
   else:logm+=math.log((old+1)/old)
   i+=1
  if zero or lo<=0:continue
  hi=min(ev[i][0] if i<len(ev) else Rmax,Rmax,.5*math.exp((logm-LOGTAU)/n))
  if hi<=lo:continue
  w=math.exp(logm-n*math.log(2*lo))*(-math.expm1(-n*math.log(hi/lo)))
  if w>0:out.append({'lo':lo,'hi':hi,'logm':logm,'m':str(math.prod(map(int,counts))),'B':w})
 return out

def fulltask(item):
 n=item['n'];a=np.array(item['spacing']);x=np.array([float(t) for t in item['x']]);rng=np.random.default_rng(item['seed']+7260000);start=time.monotonic();cpu=time.process_time();intervals=forward_plateaus(item);B=math.fsum(z['B'] for z in intervals);assert B>0;cdf=np.cumsum([z['B'] for z in intervals]);vals=[];events=[];mismatch=0
 for sample in range(32):
  draw=rng.random(n+2);k=min(int(np.searchsorted(cdf,draw[0]*B,side='right')),len(intervals)-1);z=intervals[k];lo=z['lo'];hi=z['hi'];u=max(np.finfo(float).eps,min(1-np.finfo(float).eps,draw[1]));r=lo*math.exp(-math.log1p(-u*(-math.expm1(-n*math.log(hi/lo))))/n)
  low=np.ceil((x-r)/a-1e-13).astype(int);high=np.floor((x+r)/a+1e-13).astype(int);counts=high-low+1
  if math.prod(map(int,counts))!=int(z['m']):mismatch+=1;continue
  points=low+np.minimum((draw[2:]*counts).astype(int),counts-1);y=points*a;direction=(y-x)/r;exitR,ne=anchored_exit(direction,a,item['Rmax']);assert exitR>=r*(1-1e-10);v=math.exp(n*math.log(r/exitR));assert -1e-12<=v<=1+1e-9;vals.append(min(1.,v));events.append(ne)
 if len(vals)!=32:return {'n':n,'seed':item['seed'],'status':'mismatch','samples':len(vals),'mismatched_plateau_counts':mismatch,'intervals':intervals,'B':B}
 mean=float(np.mean(vals));eps=math.sqrt(math.log(2/(.05/6))/(2*len(vals)))
 return {'n':n,'seed':item['seed'],'category':item['category'],'status':'complete','sampling_seed':item['seed']+7260000,'samples':len(vals),'ratios':vals,'B':B,'C_estimate':B*mean,'sampling_only_hoeffding_interval':[B*max(0,mean-eps),B*min(1,mean+eps)],'sampling_note':'fixed 6 centers, union bound 95%, independent Monte Carlo sampling only; floating geometry/exit error not covered','mean_ratio':mean,'min_ratio':min(vals),'max_ratio':max(vals),'std_ratio':float(np.std(vals,ddof=1)),'interval_count':len(intervals),'intervals':intervals,'mean_anchor_events':float(np.mean(events)),'guard_violations':0,'elapsed_seconds':time.monotonic()-start,'cpu_seconds':time.process_time()-cpu,'peak_rss_bytes_macos':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}

def main():
 p=argparse.ArgumentParser();p.add_argument('--phase',choices=('prepare','pilot','expand','refine','focus','full'),required=True);p.add_argument('--workers',type=int,default=12);p.add_argument('--output-dir',type=Path,default=Path(__file__).resolve().parent/'replay');a=p.parse_args();assert 1<=a.workers<=14;a.output_dir.mkdir(parents=True,exist_ok=True);cp=a.output_dir/'ccu_r626_compute';cp.mkdir(exist_ok=True);path=a.output_dir/'ccu_r626_numeric.json';md=a.output_dir/'ccu_r626_numeric.md';t=time.monotonic()
 if a.phase=='prepare':
  trials=[find_dimension(n) for n in (7,16,32,64,128)];inputs=[x for seq,_ in trials for x in seq];out={'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'command_prepare':shlex.join([sys.executable]+sys.argv),'python':sys.version,'numpy':np.__version__,'platform':platform.platform(),'inputs':inputs,'search_stats':[z for _,z in trials],'results':[]};path.write_text(json.dumps(out));print('inputs',len(inputs),'search_stats',out['search_stats']);return
 if a.phase=='full':
  original=json.loads(path.read_text());inputs=original['inputs'];previous=original['results'];items=[]
  for n in (7,32,128):
   near=[q for q in inputs if q['n']==n and q['category']=='near_critical'];near.sort(key=lambda q:next(z['L_estimate'] for z in previous if z['seed']==q['seed']));items.extend([near[0],near[-1]])
  fullpath=cp/'full_results.json';fullmd=cp/'full_report.md';out={'input_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'command':shlex.join([sys.executable]+sys.argv),'python':sys.version,'numpy':np.__version__,'platform':platform.platform(),'workers':a.workers,'centers':[{k:q[k] for k in ('n','seed','category')} for q in items],'results':[]}
  def fullsave():
   fullpath.write_text(json.dumps(out));lines=['# R626 complete τ-bad radius contribution','','For every original forward lattice count plateau, intersect with the actual strict τ-bad range. Sample a plateau proportional to its B_j, then sample r^-n uniformly and choose y uniformly from all source lattice points in Q(x,r). The quantity C=B E[V(r)/Vstar] is the complete atomic-periodic kernel load. Results are numerical pilot estimates; intervals account only for sampling, not floating event/spacing/exit errors.','','| n | seed | plateaus | B | samples | C estimate | sampling-only interval | sample standard deviation |','|---:|---:|---:|---:|---:|---:|:---|---:|']
   for r in sorted(out['results'],key=lambda r:(r['n'],r['seed'])):
    if r['status']=='complete':lines.append('| %d | %d | %d | %.8g | %d | %.8g | [%.6g, %.6g] | %.6g |'%(r['n'],r['seed'],r['interval_count'],r['B'],r['samples'],r['C_estimate'],*r['sampling_only_hoeffding_interval'],r['std_ratio']))
    else:lines.append('\nIncomplete '+str(r))
   fullmd.write_text('\n'.join(lines)+'\n')
  with concurrent.futures.ProcessPoolExecutor(max_workers=min(a.workers,len(items))) as pool:
   for f in concurrent.futures.as_completed([pool.submit(fulltask,q) for q in items]):
    r=f.result();out['results'].append(r);fullsave();print('full',r['n'],r['seed'],r['status'],'B',r['B'],flush=True)
  out['wall_seconds']=time.monotonic()-t;out['worker_cpu_sum_seconds']=sum(r.get('cpu_seconds',0) for r in out['results']);out['max_worker_rss_bytes']=max(r.get('peak_rss_bytes_macos',0) for r in out['results']);fullsave();return
 out=json.loads(path.read_text());out.setdefault('commands',[]).append(shlex.join([sys.executable]+sys.argv));items=[q for q in out['inputs'] if q['n'] in (7,16)] if a.phase=='pilot' else [q for q in out['inputs'] if q['n'] in (32,64,128)];samples=32
 if a.phase=='refine':
  items=[]
  for n in (7,16,32,64,128):
   subset=[q for q in out['inputs'] if q['n']==n];near=[q for q in subset if q['category']=='near_critical'];ordinary=[q for q in subset if q['category']=='ordinary'];ordinary.sort(key=lambda q:next(z['L_estimate'] for z in out['results'] if z['seed']==q['seed']),reverse=True);items+=near+ordinary[:2]
 if a.phase=='focus':
  items=[]
  for n in (7,16,32,64,128):
   near=[q for q in out['inputs'] if q['n']==n and q['category']=='near_critical'];items.append(max(near,key=lambda q:next(z['L_estimate'] for z in out['results'] if z['seed']==q['seed'])))
 def save():
  path.write_text(json.dumps(out));L=['# R626 actual harmonic exit pilot','','Each input is a rational center with a strictly 1-bad radius; samples use the same periodic atomic source and count lattice points by products. Each anchored exit scans all entry-event intervals up to the stated cutoff. Floating event values are exploratory, not a strict certificate; Monte Carlo confidence intervals address sampling only.','','| n | seed | center class | samples | m0 | L estimate | 95% simultaneous sampling interval | mean events |','|---:|---:|:---|---:|---:|---:|:---|---:|']
  for r in sorted(out['results'],key=lambda v:(v['n'],v['seed'])):
   x=next(z for z in out['inputs'] if z['n']==r['n'] and z['seed']==r['seed']);L.append('| %d | %d | %s | %d | %d | %.8g | [%.6g, %.6g] | %.5g |'%(r['n'],r['seed'],x['category'],r['samples'],x['m0'],r['L_estimate'],*r['hoeffding_L_interval'],r['mean_events']))
  L+=['','L is a lower bound on the full kernel load under the stated idealized periodic model; it is not an equality. Periodic atomic data are not a finite-L1 proof. A finite bump/cutoff transfer remains to be justified.'];md.write_text('\n'.join(L)+'\n')
 with concurrent.futures.ProcessPoolExecutor(max_workers=a.workers) as pool:
  for f in concurrent.futures.as_completed([pool.submit(task,(item,32,128) if a.phase=='refine' else (item,128,512) if a.phase=='focus' else (item,0,samples)) for item in items]):
   r=f.result()
   if a.phase in ('refine','focus'):
    prev=next(z for z in out['results'] if z['seed']==r['seed']); item=next(z for z in out['inputs'] if z['seed']==r['seed']);prev.setdefault('history',[]).append({k:prev[k] for k in ('samples','mean_ratio','L_estimate','hoeffding_L_interval')});oldN=prev['samples'];rat=prev['ratios']+r['ratios'];N=len(rat);mean=float(np.mean(rat));factor=(item['m0']/(2*item['r0'])**item['n'])*math.log(1/TAU);e=math.sqrt(math.log(2/(.05/(40*3)))/(2*N));prev.update({'samples':N,'end':512 if a.phase=='focus' else 128,'ratios':rat,'mean_ratio':mean,'L_estimate':factor*mean,'hoeffding_L_interval':[factor*max(0,mean-e),factor*min(1,mean+e)],'sample_min':min(rat),'sample_max':max(rat),'mean_events':(prev['mean_events']*oldN+r['mean_events']*r['samples'])/N,'max_events':max(prev['max_events'],r['max_events']),'guard_violations':prev['guard_violations']+r['guard_violations'],'elapsed_seconds':prev['elapsed_seconds']+r['elapsed_seconds'],'cpu_seconds':prev['cpu_seconds']+r['cpu_seconds'],'peak_rss_bytes_macos':max(prev['peak_rss_bytes_macos'],r['peak_rss_bytes_macos'])});r=prev
   else:out['results'].append(r)
   (cp/('n%d_seed%d.json'%(r['n'],r['seed']))).write_text(json.dumps(r));save();print('done',r['n'],r['seed'],r['samples'],r['L_estimate'],flush=True)
 out['last_phase']=a.phase;out['last_wall_seconds']=time.monotonic()-t;out['worker_cpu_sum_seconds']=sum(r['cpu_seconds'] for r in out['results']);out['max_worker_rss_bytes']=max(r['peak_rss_bytes_macos'] for r in out['results']);save()
if __name__=='__main__':main()
