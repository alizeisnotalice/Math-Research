import json,math,sys,time,platform,resource,hashlib,argparse
from pathlib import Path
from fractions import Fraction as Q
from scipy.stats import beta
import scipy
ROOT=Path(__file__).resolve().parent
parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,default=ROOT/'statistics_replay.json');args=parser.parse_args()
start=time.perf_counter();cpu=time.process_time();src=ROOT/'sourceview.json';cert=ROOT/'certificate_original.json';d=json.loads(src.read_text());c=json.loads(cert.read_text());occpath=ROOT/'occupationview.json';occ=json.loads(occpath.read_text());assert occ['sourceview_sha256']==hashlib.sha256(src.read_bytes()).hexdigest();den=10**6

def tail(n,k,p,upper):
 # Exact integer numerator with common denominator 10^(6n); no probability library in the proof.
 lo,hi=(k,n+1) if upper else (0,k+1)
 num=sum(math.comb(n,j)*p**j*(den-p)**(n-j) for j in range(lo,hi));return Q(num,den**n)
def interval(n,k):
 L=math.floor(beta.ppf(1/360,k,n-k+1)*den) if k else 0
 U=math.ceil(beta.ppf(1-1/360,k+1,n-k)*den) if k<n else den
 while k and tail(n,k,L,True)>Q(1,360):L-=1
 while k<n and tail(n,k,U,False)>Q(1,360):U+=1
 ltail=tail(n,k,L,True) if k else Q(0);utail=tail(n,k,U,False) if k<n else Q(0)
 assert 0<=L<=U<=den and ltail<=Q(1,360) and utail<=Q(1,360)
 return L,U,ltail,utail
def ep(e):return Q(int(e[0]))*Q(2)**int(e[1])
def rational_out(q,upper):return -((-q.numerator*den)//q.denominator) if upper else q.numerator*den//q.denominator
f=lambda x:[str(x.numerator),str(x.denominator)]
expected={7:(163,473,440),32:(288,431,136),128:(262,491,181)};rows=[]
for n,(ez,en,ee) in expected.items():
 r=[z for z in d['results'] if z['n']==n];N=sum(z['N'] for z in r);Z=sum(z['Z_hits'] for z in r);E=sum(z['E_hits'] for z in r);assert N==512 and (Z,E)==(ez,ee) and all(z['Z_ambiguous']==z['E_ambiguous']==0 for z in r)
 rr=[v for v in occ['results'] if v['n']==n];NN=sum(v['samples'] for v in rr);Znew=sum(v['Z_hits'] for v in rr);assert NN==N and Znew==en and all(v['Z_ambiguous']==v['guard_ambiguous']==0 for v in rr);zl,zu,zlt,zut=interval(N,Z);nl,nu,nlt,nut=interval(N,Znew);el,eu,elt,eut=interval(N,E);dr=next(z['delta'] for z in c['cases'] if z['n']==n);dl=ep(dr['lower']);du=ep(dr['upper']);assert 0<dl<=du and el>0
 low=dl*Q(zl,eu);high=du*Q(zu,el);rl=rational_out(low,False);ru=rational_out(high,True);nrl=rational_out(dl*Q(nl,eu),False);nru=rational_out(du*Q(nu,el),True)
 rows.append({'n':n,'N':N,'Z_hits':Z,'occupation_Z_hits':Znew,'E_hits':E,'Z_interval_millionths':[zl,zu],'occupation_Z_interval_millionths':[nl,nu],'E_interval_millionths':[el,eu],'tail_checks':{'Z_lower_exact':f(zlt),'Z_upper_exact':f(zut),'occupation_Z_lower_exact':f(nlt),'occupation_Z_upper_exact':f(nut),'E_lower_exact':f(elt),'E_upper_exact':f(eut)},'delta_lower':f(dl),'delta_upper':f(du),'ratio_outward_millionths':[rl,ru],'occupation_ratio_outward_millionths':[nrl,nru]})
out={'results':rows,'tail_threshold':'1/360','familywise_failure_at_most':'1/20','sampling_scope':'conditional on ideal iid exact Bernoulli outcomes; not a deterministic integral enclosure and excludes PRNG/discretization/spacing/event errors','source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'occupation_sha256':hashlib.sha256(occpath.read_bytes()).hexdigest(),'delta_certificate_sha256':hashlib.sha256(cert.read_bytes()).hexdigest(),'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'runtime':{'python':sys.version,'scipy':scipy.__version__,'sys_executable':sys.executable,'platform':platform.platform(),'argv':[sys.executable]+sys.argv,'wall_seconds':time.perf_counter()-start,'cpu_seconds':time.process_time()-cpu,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}}
args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_text(json.dumps(out,indent=2)+'\n');print([(r['n'],r['Z_interval_millionths'],r['E_interval_millionths'],r['ratio_outward_millionths'],r['occupation_Z_interval_millionths'],r['occupation_ratio_outward_millionths']) for r in rows]);print('sha',out['script_sha256'],'wall',out['runtime']['wall_seconds'])
