import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[k]='1'
import argparse,concurrent.futures,hashlib,json,math,platform,resource,shlex,sys,time
from pathlib import Path
import numpy as np,scipy
from scipy.stats import beta
import ccu_r626_numeric as base
TAU=.75;EPS=1e-10

def E1(x,a,Rmax):
 n=len(a);ev=base.entry_events(x,a,Rmax);counts=np.zeros(n,dtype=int);zero=n;logm=0.;ambiguous=False;i=0
 while i<len(ev):
  r=ev[i][0]
  while i<len(ev) and ev[i][0]==r:
   j=ev[i][1];old=counts[j];counts[j]+=1
   if not old:zero-=1
   else:logm+=math.log((old+1)/old)
   i+=1
  if zero or r<=0:continue
  margin=logm-n*math.log(2*r)
  if margin>EPS:return 1,i
  if margin>=-EPS:ambiguous=True
 return (-1 if ambiguous else 0),i

def run(arg):
 n,block=arg;t=time.monotonic();cpu=time.process_time();a=base.geom(n);Rmax=base.cutoff(a);rng=np.random.default_rng(626900000+n*100+block);hits=amb=ehits=eamb=source_reject=source_amb=0;maxev=0;zrows=[];erows=[]
 for _ in range(64):
  draw=rng.random(n+1);u=2*draw[:n]-1;R,nev=base.anchored_exit(u,a,Rmax);v=draw[n];r=R*math.exp(math.log(v)/n);c=1+np.floor(r*(1+u)/a).astype(int)+np.floor(r*(1-u)/a).astype(int);margin=float(np.log(c).sum())-math.log(TAU)-n*math.log(2*r)
  status=1 if margin>EPS else -1 if margin>=-EPS else 0
  if status==0:source_reject+=1;zrows.append(0);continue
  if status<0:source_amb+=1
  x=(-r*u+a/2)%a-a/2;e,k=E1(x,a,Rmax);maxev=max(maxev,k)
  if status==1 and e==1:hits+=1;zrows.append(1)
  elif e==0:zrows.append(0)
  else:amb+=1;zrows.append(-1)
 for _ in range(64):
  x=(rng.random(n)-.5)*a;e,k=E1(x,a,Rmax);maxev=max(maxev,k);ehits+=int(e==1);eamb+=int(e==-1);erows.append(e)
 return {'n':n,'block':block,'seed':626900000+n*100+block,'N':64,'Z_hits':hits,'Z_ambiguous':amb,'E_hits':ehits,'E_ambiguous':eamb,'source_cube_reject':source_reject,'source_cube_ambiguous':source_amb,'Z_values':zrows,'E_values':erows,'max_forward_events':maxev,'elapsed_seconds':time.monotonic()-t,'cpu_seconds':time.process_time()-cpu,'peak_rss_bytes_macos':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}

def cp(k,N,alpha,upper=False):
 if upper:return 1. if k==N else float(beta.ppf(1-alpha/2,k+1,N-k))
 return 0. if k==0 else float(beta.ppf(alpha/2,k,N-k+1))

def main():
 p=argparse.ArgumentParser();p.add_argument('--phase',choices=('pilot','remaining'),required=True);p.add_argument('--workers',type=int,default=3);p.add_argument('--output-dir',type=Path,default=Path(__file__).resolve().parent/'replay');a=p.parse_args();assert 1<=a.workers<=12;a.output_dir.mkdir(parents=True,exist_ok=True);path=a.output_dir/'sourceview.json';md=a.output_dir/'sourceview.md';start=time.monotonic()
 if a.phase=='pilot':out={'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'base_sha256':hashlib.sha256(Path(base.__file__).read_bytes()).hexdigest(),'python':sys.version,'numpy':np.__version__,'scipy':scipy.__version__,'platform':platform.platform(),'commands':[],'results':[],'scope':'periodic atomic float computation; source-view identity pending independent proof; no finite L1 theorem'};tasks=[(n,0) for n in (7,32,128)]
 else:out=json.loads(path.read_text());tasks=[(n,k) for n in (7,32,128) for k in range(1,8)]
 out['commands'].append(shlex.join([sys.executable]+sys.argv))
 def save():
  summaries=[]
  for n in (7,32,128):
   r=[z for z in out['results'] if z['n']==n];N=sum(z['N'] for z in r)
   if not N:continue
   k=sum(z['Z_hits'] for z in r);q=sum(z['Z_ambiguous'] for z in r);p0=sum(z['E_hits'] for z in r);pq=sum(z['E_ambiguous'] for z in r);alpha=.05/6;zl=cp(k,N,alpha);zu=cp(k+q,N,alpha,True);el=cp(p0,N,alpha);eu=cp(p0+pq,N,alpha,True);a0=base.geom(n);delta=math.exp(-float(np.log(a0).sum()));summaries.append({'n':n,'samples':N,'Z_hits':k,'Z_ambiguous':q,'Z_estimate':k/N,'Z_sampling_only_bonferroni_CP':[zl,zu],'E_hits':p0,'E_ambiguous':pq,'P_E_estimate':p0/N,'P_E_sampling_only_bonferroni_CP':[el,eu],'delta':delta,'delta_Z_over_PE_estimate':None if p0==0 else delta*k/p0,'ratio_sampling_only_outer_interval':None if el==0 else [delta*zl/eu,delta*zu/el]})
  out['summaries']=summaries;path.write_text(json.dumps(out));L=['# R626 source-view full receiver integral pilot','','Values are Bernoulli event counts for the periodic atomic float model. The source-view identity must be independently verified before interpreting Z as a receiver integral. Intervals are Bonferroni Clopper–Pearson for sampling error only; binary64 geometry and event ambiguity are not certified.','','| n | N | Z hits (ambig.) | Z sampling interval | E hits (ambig.) | P(E) sampling interval | δ Z/P(E) |','|---:|---:|:---|:---|:---|:---|---:|']
  for q in summaries:L.append('| %d | %d | %d (%d) | [%.6g, %.6g] | %d (%d) | [%.6g, %.6g] | %s |'%(q['n'],q['samples'],q['Z_hits'],q['Z_ambiguous'],*q['Z_sampling_only_bonferroni_CP'],q['E_hits'],q['E_ambiguous'],*q['P_E_sampling_only_bonferroni_CP'],str(q['delta_Z_over_PE_estimate'])))
  L+=['','A negative E1 determination requires all forward events through the safe cutoff; positive determinations may stop early. Strict comparisons within 1e-10 are marked ambiguous, but other floating rounding remains unbounded.'];md.write_text('\n'.join(L)+'\n')
 with concurrent.futures.ProcessPoolExecutor(max_workers=a.workers) as pool:
  for f in concurrent.futures.as_completed([pool.submit(run,q) for q in tasks]):
   r=f.result();out['results'].append(r);save();print('done',r['n'],r['block'],'Z',r['Z_hits'],'E',r['E_hits'],flush=True)
 out['last_phase_wall_seconds']=time.monotonic()-start;out['workers_last']=a.workers;out['worker_cpu_sum_seconds']=sum(q['cpu_seconds'] for q in out['results']);out['max_worker_rss_bytes']=max(q['peak_rss_bytes_macos'] for q in out['results']);save()
if __name__=='__main__':main()
