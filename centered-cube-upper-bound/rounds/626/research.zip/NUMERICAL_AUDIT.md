# R626 占用尺度抽样：有限独立核验

已只读检查 `/tmp/ccu_r626_compute/occupationview.py`，并对已保存数据每个维度的 block 0 各重放 64 条，共 192 条；没有重跑 24 个 block。输入为原 `sourceview.json` 的 block 0 种子和 `occupationview.json` 中的保存结果。旧完整试算的实际命令记录为：

```sh
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/ccu_r626_compute/occupationview.py --phase pilot --workers 1
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/ccu_r626_compute/occupationview.py --phase remaining --workers 12
```

本次核验使用 `/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python -`，通过一次性标准输入脚本独立重建指定三批；它没有保存为独立脚本。逐批结果和输入哈希保存在 `/tmp/ccu_r626_occupation_audit.json`。因此该 JSON 是本次检查记录，并非一个自包含的重放程序。

## 权重与抽样

对每个固定 u，代码排序完整锚点入盒事件；每段计数 A 恒定，以 `min(下个事件, (A/τ)^(1/n)/2, Rcut)` 截取 τ-bad 区间，并从初始的零半径区间开始。取各区间最高端点的最大值为 Rstar，`w_j=(b_j/Rstar)^n−(a_j/Rstar)^n` 正比于该区间在体积 V=(2r)^n 坐标下的长度。先按 `w_j/Σw` 选区间，再令 `r=b_j[((1−U)(a_j/b_j)^n+U)]^(1/n)`，在所选区间的体积坐标内均匀。`expm1` 用于减轻相近端点权重相消；因连续采样落在边界的概率为零，严格端点对理想连续分布无影响，实际有限精度采样另有严格 τ-bad guard 和歧义标记。

该占用菜单的归一化是 `Bτ=Σ_j[(2b_j)^n−(2a_j)^n]`，选择权重 `w_j` 的公共分母为 `Vstar=(2Rstar)^n`，因此占用比 `Σw_j=Bτ/Vstar`；条件于占用菜单后求 E 的命中率，不应再把 `Σw_j` 错当作抽样概率额外乘一次。此点仅核对代码对应的归一化，相关积分恒等式的数学前提仍由独立理论审核负责。

## 已执行检查

| n | 样本 | 保存 / 重放命中 | 状态、占用比逐条一致 | 60 位精度权重相对差最大值 | 改变选中区间数 | 精确 τ-bad / E 分歧数 |
|---:|---:|---:|---|---:|---:|---:|
| 7 | 64 | 60 / 60 | 是 | 1.99e-14 | 0 | 0 / 0 |
| 32 | 64 | 56 / 56 | 是 | 2.98e-14 | 0 | 0 / 0 |
| 128 | 64 | 63 / 63 | 是 | 7.03e-13 | 0 | 0 / 0 |

每条都用浮点端点转换后的多精度数独立重算占用权与区间选择，所有占用比有限；精确有理地检查采样半径的 τ-bad，并对生成的浮点 receiver 坐标做独立完整入点事件判断。每维前两条另外进行完整精确有理锚点 exit 事件扫描，退出半径与浮点结果相对差分别至多约 3.34e-16、6.67e-16、1.27e-14。精确事件扫描使用保守有理 cutoff，false E 扫完全部事件；true E 有严格正裕度见证。

这些检查覆盖保存的 binary64 近似值和指定的 192 条样本；60 位权重比较以浮点区间端点为输入，不消除端点自身误差，也不能保证其他样本的判定。原始无理间距不在本次精确证书范围内。保存结果的抽样置信区间是有条件的统计区间，不是确定性积分界，也不自动提供有限 L1 桥接。


归档更新：已补充 occupation_check_reconstructed.py；这是事后重建版本，只复验过一条，原192条代码仍未保存。见 REPRODUCE.md。
