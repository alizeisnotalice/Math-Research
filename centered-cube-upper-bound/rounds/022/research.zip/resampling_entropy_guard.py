"""Registered round22 count-law component checks. No spatial simulation.

Decimal calculations at 70/110 digits are numerical guards, not outward intervals.
Poisson omitted tails below are analytic upper bounds evaluated in Decimal.
"""
from decimal import Decimal as D, localcontext
from fractions import Fraction as F
from math import factorial, ceil
from functools import lru_cache
import json
from pathlib import Path



def dec(x):
    if isinstance(x,F): return D(x.numerator)/D(x.denominator)
    return D(x)

def allocations(total,n):
    if n==1:
        yield (total,); return
    for k in range(total+1):
        for rest in allocations(total-k,n-1): yield (k,)+rest

def exact_checks():
    checks=0
    for p in ((F(1,3),F(2,3)),(F(1,2),F(1,3),F(1,6))):
        old=1-sum(x*x for x in p)
        for n in range(1,7):
            mass=F(0); h2=F(0); support=F(0)
            for counts in allocations(n,len(p)):
                prob=F(factorial(n),1)
                for pi,k in zip(p,counts): prob*=pi**k/factorial(k)
                mass+=prob
                h2+=prob*(1-sum(F(k,n)**2 for k in counts))
                support+=prob*sum(k>0 for k in counts)
            assert mass==1
            assert h2==old*F(n-1,n)
            assert support==sum(1-(1-pi)**n for pi in p)
            checks+=3
    return checks

def run(precision):
  with localcontext() as ctx:
    ctx.prec=precision
    tol=D(10)**(-precision+12)
    @lru_cache(None)
    def pmf(lam,j):
        ld=dec(lam); vals=[(-ld).exp()]
        for k in range(1,j+1): vals.append(vals[-1]*ld/k)
        return tuple(vals)
    def tail(lam,j):
        # P(Poi(lam)>=j), geometric ratio upper bound; j>lam.
        assert j>lam
        ld=dec(lam)
        return pmf(lam,j)[j]/(1-ld/(j+1))
    @lru_cache(None)
    def ell(lam):
        j=ceil(6*lam)+32; ld=dec(lam)
        probs=pmf(lam,j)
        value=sum((probs[k]*(D(k+1)/ld).ln() for k in range(j+1)),D(0))
        bound=tail(lam,j)+tail(lam,j+1)/ld
        assert value>0 and value<=(1+1/ld).ln()+tol
        for n in (1,2,j):
            assert abs(D(n)*probs[n]/ld-probs[n-1])<tol
        return value,bound,j
    scalar=[]
    for k in (1,4,16,64,256):
        e,et,j=ell(F(k)); r=1-(1-D(-k).exp())/k
        scalar.append({'kappa':k,'ell':str(e),'ell_tail':str(et),
                       'ell_jensen_upper':str((1+D(1)/k).ln()),
                       'heterozygosity_factor':str(r),
                       'nonatomic_first_entropy':str(D(k).ln()+e),'cutoff':j})
    coarse=[]
    cases=[(1,('1/3','2/3')),(1,('1/2','1/3','1/6')),
           (4,('1/3','2/3')),(4,('1/2','1/3','1/6')),
           (16,('1/2','1/2'))]
    for k,raw in cases:
        p=tuple(map(F,raw)); n=len(p); j=6*n*k+32
        probs=pmf(F(k),j); logn=[D(0)]+[D(i).ln() for i in range(1,j+1)]
        pd=tuple(map(dec,p)); lp=tuple(x.ln() for x in pd)
        den=1
        from math import lcm
        for x in p: den=lcm(den,x.denominator)
        nums=[int(x*den) for x in p]
        # S numerator is an integer; cache all possible log S.
        logs=[D(0)]+[(D(i)/den).ln() for i in range(1,max(nums)*j+1)]
        dk=ik=eh=D(0); states=0
        for total in range(1,j+1):
          for counts in allocations(total,n):
            pv=D(1)
            for cnt in counts: pv*=probs[cnt]
            sn=sum(ni*ci for ni,ci in zip(nums,counts)); s=D(sn)/den
            r=s/k; ls=logs[sn]
            aa=sum((pi*cnt*logn[cnt] for pi,cnt in zip(pd,counts)),D(0))
            bb=sum((pi*cnt*lpi for pi,cnt,lpi in zip(pd,counts,lp)),D(0))
            dk+=pv*r*(ls-D(k).ln())
            ik+=pv*(aa-s*ls)/k
            eh+=pv*(s*ls-aa-bb)/k
            states+=1
        lam=F(n*k); qt=tail(lam,j)
        dt=(dec(lam)**2*tail(lam,j-1)+dec(lam)*tail(lam,j))/D(k*k)
        it=(-min(lp))*qt; ht=D(n).ln()*qt
        ev,eb,_=ell(F(k)); hp=-sum(pi*lpi for pi,lpi in zip(pd,lp))
        assert abs(dk+ik-ev)<=dt+it+eb+tol
        assert abs(hp-eh-ik)<=ht+it+tol
        coarse.append({'kappa':k,'prior':list(raw),'states':states,'cutoff':j,
            'marginal_KL':str(dk),'information':str(ik),'posterior_entropy':str(eh),
            'prior_entropy':str(hp),'entropy_reduction':str(hp-eh),
            'joint_KL_expected_ell':str(ev),'joint_identity_residual':str(dk+ik-ev),
            'joint_omitted_bound':str(dt+it+eb),'entropy_identity_residual':str(hp-eh-ik),
            'entropy_omitted_bound':str(ht+it),'Q_omitted_mass_bound':str(qt)})
    inside=[]
    for k,raw in [(1,('1/2','1/2')),(4,('1/3','1/3','1/3')),(16,('1/3','2/3'))]:
        p=tuple(map(F,raw)); pd=tuple(map(dec,p)); n=len(p); j=6*k+33
        # Q count-vector has P independent Poi(k*p_i), tilted by total/k.
        probs=[pmf(F(k)*pi,j) for pi in p]
        logs=[D(0)]+[D(i).ln() for i in range(1,j+1)]
        eh=h2=support=D(0); states=0
        for total in range(1,j+1):
          for counts in allocations(total,n):
            pv=D(total)/k
            for pp,cnt in zip(probs,counts): pv*=pp[cnt]
            eh+=pv*(logs[total]-sum((D(cnt)*logs[cnt] for cnt in counts),D(0))/total)
            h2+=pv*(1-sum(D(cnt*cnt) for cnt in counts)/D(total*total))
            support+=pv*sum(cnt>0 for cnt in counts)
            states+=1
        hp=-sum(pi*pi.ln() for pi in pd)
        ek,eb,_=ell(F(k)); expected=hp+ek
        formula_tail=eb
        for pi in p:
            ev,et,_=ell(F(k)*pi)
            expected-=dec(pi)*ev; formula_tail+=dec(pi)*et
        qt=tail(F(k),j) # N*=1+Poi(k)>j iff Poi(k)>=j.
        r=1-(1-D(-k).exp())/k
        expected_h2=r*(1-sum(pi*pi for pi in pd))
        expected_support=sum(1-(1-pi)*(-k*pi).exp() for pi in pd)
        assert abs(eh-expected)<=D(n).ln()*qt+formula_tail+tol
        assert abs(h2-expected_h2)<=qt+tol
        assert abs(support-expected_support)<=n*qt+tol
        inside.append({'kappa':k,'prior':list(raw),'states':states,'cutoff':j,
            'expected_entropy':str(eh),'entropy_formula':str(expected),
            'entropy_residual':str(eh-expected),'entropy_omitted_bound':str(D(n).ln()*qt+formula_tail),
            'expected_heterozygosity':str(h2),'heterozygosity_formula':str(expected_h2),
            'expected_support':str(support),'support_formula':str(expected_support),
            'Q_omitted_mass_bound':str(qt)})
    return {'precision':precision,'scalar':scalar,'coarse':coarse,'inside':inside}

def displayed(data):
    # Compare substantive estimates, excluding cancellation residuals/tail rounding.
    fields={'scalar':('ell','heterozygosity_factor','nonatomic_first_entropy'),
      'coarse':('marginal_KL','information','posterior_entropy','prior_entropy'),
      'inside':('expected_entropy','entropy_formula','expected_heterozygosity','expected_support')}
    return {kind:[[format(D(row[key]),'.18g') for key in keys] for row in data[kind]]
            for kind,keys in fields.items()}


from fractions import Fraction as F
from itertools import product
import json


def geometry_checks():
    cases=top=hidden=0
    max_ratio=F(0)
    for n,depth,pattern in product([1,2,4,16,64,256],[0,12,40],[0,1,2]):
        a,b=F(1),F(4)
        d=F(1,32*n); c=b-2*d
        if pattern==0:
            ys=[F(0),-d/4,-d/2]; x=b/2-d/4
            mass=[F(1,2**depth),F(1,2**(depth+1)),F(1)]
        elif pattern==1:
            ys=[F(0),-d/4,F(1)]; x=b/2-d/8
            mass=[F(1,2**depth),F(1),F(1,7)]
        else:
            ys=[F(0),-d/4,-d/2]; x=b/2+2*d
            mass=[F(1),F(1,3),F(1,2**depth)]
        cells=[(y+3*d/4)//d for y in ys]
        rs=[max(a,2*abs(x-y)) for y in ys]
        candidates=sorted(set([a,b]+[r for r in rs if r<=b]))
        values={r:sum(m for m,s in zip(mass,rs) if s<=r)/r**n for r in candidates}
        M=max(values.values())
        cases+=1
        if not M: continue
        R=min(r for r in candidates if values[r]==M)
        if R<=c: continue
        top+=1
        m=M*R**n; tau=M*F(3,4)
        for cell in set(cells):
            w=sum(z for z,k in zip(mass,cells) if k==cell)
            cap=sum(z for z,k,r in zip(mass,cells,rs) if k==cell and r<=R)
            pi=cap/m
            lhs=tau*w*cap/m**2
            assert lhs<=w*pi/c**n<=w/c**n
            if cap:
                lo=cell*d-3*d/4
                assert lo-b/2<=x<=lo+d+b/2
                # n-dimensional support box contains actual capture support.
                assert (b+d)**n/c**n<=(b+2*d)**n/c**n
                max_ratio=max(max_ratio,w/m)
                if w>m: hidden+=1
    # Verify the global scalar log-loss guard without evaluating logarithms:
    # for eta<-1/2 its polynomial RHS is nonpositive; the complementary
    # Taylor inequality is proved in the note, not by this finite check.
    scalar=0
    for eta,z in product([F(-1),F(-3,4),F(-2,3),F(-51,100)],
                         [F(1,100),F(1),F(100)]):
        assert z+eta-(2+4*z)*eta**2<=0
        scalar+=1
    return dict(fixtures=cases,top_winners=top,hidden_cell_mass_cases=hidden,
                max_cell_to_captured_mass=str(max_ratio),scalar_bad_branch_checks=scalar,
                dimensions=[1,2,4,16,64,256],depths=[0,12,40])



if __name__ == '__main__':
    geometry=geometry_checks()
    exact=exact_checks()
    low=run(70)
    high=run(110)
    assert displayed(low)==displayed(high)
    result={'status':'PASS', 'scope':'finite geometry and count-law checks; no spatial weak-type proof; Decimal is not outward-rounded',
            'geometry':geometry,'exact_count_fraction_assertions':exact,
            'precisions':[70,110],'matching_display_digits':18,
            'count_vectors_per_precision':sum(x['states'] for x in high['coarse']+high['inside']),
            'count_results':high}
    Path(__file__).with_name('results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({k:result[k] for k in ('status','geometry','count_vectors_per_precision')},ensure_ascii=False))
