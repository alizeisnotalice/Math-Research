#!/usr/bin/env python3
"""R319 actual positive-L1 two-ownership random-tag diagnostic."""
from fractions import Fraction as F
from pathlib import Path
from collections import Counter
import json
counts=Counter()
def ck(key,b):
 counts[key]+=1
 assert b,key

def contains(I,J):return I[0]<=J[0] and J[1]<=I[1]
def run(k):
 n=k*k;fine=F(1,n);micro=fine/2;D=F(1,k);density=3*2**n;remote_density=8100*2**n
 local_micro_union_volume=F(1,2**n);remote_volume=F(1,2**n)
 eta=1-F(k,density);localres=F(3)-F(k,2**n);remoteres=F(8100)-F(k,2**n);totalres=localres+remoteres
 ck('local_full_mass',density*local_micro_union_volume==3)
 ck('remote_full_mass',remote_density*remote_volume==8100)
 ck('positive_residual_factor',0<eta<1 and localres==3*eta)
 ck('residual_cap_exact',totalres==8103-F(2*k,2**n))
 # Every fine cell carries one centered microcube of half its side.
 ck('micro_tensor_count',n**n*micro**n==local_micro_union_volume)
 fine_mass=F(3,n**n)
 ck('fine_cell_full_mass',density*micro**n==fine_mass)
 recvhalf=F(1,8*n);local_extent=F(1,2)-F(1,4*n)
 ck('continuous_local_capture',local_extent+recvhalf<F(1,2))
 ck('continuous_remote_exclusion',F(7,4)-recvhalf>1)
 ck('positive_receiver_volume',F(1,4*n)**n>0)
 # These two inequalities apply to ALL x in V and ALL R in [1,2].
 # Thus the response is 3/R^n, with selected true winner R=1.
 for R in [F(1),F(3,2),F(2)]:ck('rational_winner_comparison',F(3)/R**n<=3)
 ck('selected_native_hardband',2<3<=4)
 ck('normalised_transport_gate',F(1,3)*3==1)
 # Ai side1 centered0 and2e1; Bi side5 contain both complete sources.
 for axis in range(n):
  local=(-local_extent,local_extent)
  remote=(F(7,4),F(9,4)) if axis==0 else (F(-1,4),F(1,4))
  owner0=(F(-1,2),F(1,2));owner2=(F(3,2),F(5,2)) if axis==0 else owner0
  ck('local_ownership',contains(owner0,local))
  ck('remote_ownership',contains(owner2,remote))
  for macrocenter in [F(0),F(2) if axis==0 else F(0)]:
   macro=(macrocenter-F(5,2),macrocenter+F(5,2))
   ck('macro_contains_local',contains(macro,local));ck('macro_contains_remote',contains(macro,remote))
 ck('ownership_graph_connected',2<=3)
 ck('ownership_capture_ratio_failure',localres/totalres<F(1,2*k))
 ck('harmonic_F_failure',localres/totalres<F(1,k))
 ck('component_heavy_integer_certificate',totalres>8100>3**k)
 ck('source_tail_zero',F(8103)-F(8103)==0)
 # Packet root is a union of k consecutive ORIGINAL fine cells per axis.
 lower=F(-1,2)+F((n+1)//2,n);upper=lower+D
 ck('packet_alignment',(lower+F(1,2))*n==int((lower+F(1,2))*n))
 ck('packet_fine_count',D/fine==k)
 packetmass=F(3,k**n)
 ck('packet_mass_exact',k**n*fine_mass==packetmass)
 ck('packet_low_average',packetmass<=k*D**n)
 ck('packet_strict_deep_integer_certificate',3*k*3**k<k**n)
 ck('fine_old_deep_integer_certificate',3*k*3**(k-2)<n**n)
 ck('whole_packet_capture_all_receivers',lower-recvhalf>F(-1,2) and upper+recvhalf<F(1,2))
 theta=F(1);tagmass=eta*packetmass;V=F(1,4*n)**n;traffic=F(1,3)*tagmass*V
 ck('uniform_tag_probability',theta==1)
 ck('tag_acceptance_positive',traffic==eta*D**n*V>0)
 return dict(k=k,n=n,source='Local unit cube fine-grid centered half-side microcubes mass3; remote side1/2 cube at2e1 mass8100.',local_density=density,remote_density=remote_density,local_residual=localres,remote_residual=remoteres,total_residual=totalres,local_residual_factor=eta,receiver_side=F(1,4*n),receiver_volume=V,selected_winner=F(1),selected_response=F(3),normalised_gate=F(1,3),macro_capture_ratio=localres/totalres,ownership_Gamma=0,packet_lower=lower,packet_upper=upper,packet_side=D,packet_full_mass=packetmass,packet_average=F(3),packet_low_average_is_equality=k==3,tag_probability=theta,packet_residual_mass=tagmass,accepted_packet_traffic=traffic,deep_integer_left=3*k*3**k,deep_integer_right=k**n)
def serial(x):
 if isinstance(x,F):return str(x)
 if isinstance(x,dict):return {k:serial(v) for k,v in x.items()}
 if isinstance(x,(tuple,list)):return [serial(v) for v in x]
 return x

def main():
 models=[];stages=[]
 for stage,k in [('initial',3),('boundary',4),('expanded',8)]:
  before=sum(counts.values());models.append(run(k));stages.append(dict(stage=stage,k=k,n=k*k,checks=sum(counts.values())-before))
 result=dict(status='PASS',arithmetic='Fraction/integer',check_counts=dict(counts),total_checks=sum(counts.values()),stages=stages,models=models,analytic_scope='Actual finite L1 source and positive-volume native accepted receiver subset with true hard winnerR1, no complete full-hardband enumeration or FULL/history reconstruction. Continuous all-R local capture/remote exclusion follows the coordinate distance inequalities, not the finite R samples. Deep exp gates use elementary e<3.',tag_definition='Freeze each source packetP. Lift original sourcez by uniform markU onP without movingz or its kernel/masks. Accept iff U inQ_R(x); thetaP=volume(P intersectQ_R)/volumeP. This example has wholeP insideQ1 for all x inV, hence theta1.',change_from_initial_request='Per parent instruction, uses the simpler ledger two-ownership construction instead of an extended micro-lattice source. n16 matches ledger exactly; n9 aligned packet lower1/18 handles odd fine grid.',spectral_scope='Separate spectral finite stress was run by joint_mass and is not duplicated or certified here.')
 Path(__file__).with_suffix('.json').write_text(json.dumps(serial(result),sort_keys=True,indent=2)+'\n')
 print(json.dumps({k:result[k] for k in ['status','check_counts','total_checks','stages']},sort_keys=True))
if __name__=='__main__':main()
