# R319 — a positive random-tag receipt for low coarse averages

**Proved:** on the exact R318 aggregate-packet-deep remainder, low-coarse-average source traffic admits a receiver-independent Markov source lift. Its tag-accepted part has an explicit root-order L2 receipt. This applies to the concentrated original residual source without assuming any L2 bound for the original f, and without enlarging a receiver cube. A probability mixture of frozen partitions settles overlapping allocations with the SAME source budget. High-average traffic and tag-rejected traffic remain exact positive unpaid terms.

Only `/tmp/r319_entry.md` was written. This is a local finite-octave receipt, not a completed weak bound or an all-physical-scales argument.

## 1. Keep the current full input and exact original remainder

Use the complete R316 full-f input and R318 main result. The frozen original input is f>=0 inL1, `X=lambda|E_band|`, `E_band={2lambda<M<=4lambda}`, `M=sup_[a,b]h_r*f`, `0<a<=b<=2a`, and R=R*(x) is its fresh hard maximizer. The frozen hard residual source is

`nu=(f-sqrt(n)lambda)_+ dz`.

Let P denote the R318 source-frozen terminal partition, each member being a finite-volume union of whole original fine cells, and let `m_P=integral_P f`. The CURRENT remaining measure is exactly

`dT=A(x,z)h_R(x-z)dx nu(dz)`,

`||T||=H_packetdeep`, `0<=A<=1_E lambda/M<=1/2`. (1)

A includes every original native factor AND the already-established aggregate-deep gate

`m_(P(z)) < lambda R^n exp(-sqrt(n))/sqrt(n)`.

No factor is changed or reconstructed below. This includes the fixed source, original dx, K0, ownership and capture tests, harmonic deficiency and fixed connected-component labels. In particular new auxiliary variables cannot alter A or the original maximizer.

Write `S318=sum_P c_P||nu|P||` for the complete authorized packet source price in R318(7)/(16). The exact complete-band entrance is

`X <= (768/767)[P104(f,lambda)+S318+H_packetdeep]`. (2)

The R317 source fee is not additionally present. The sole output loss already included in(2) is R104's1/768.

## 2. Exact low/high split; the L2 input is a new upper-bound density

For every positive-volume packet set

`v_P=nu(P)`, `rho_P=m_P/|P|`.

Classify source packets, before receivers are selected, by

`L={P:rho_P<=sqrt(n)lambda}`, `H={P:rho_P>sqrt(n)lambda}`.

Zero-source packets may be ignored. Let `dT_lo=1_{P(z) in L}dT` and `dT_hi=1_{P(z) in H}dT`. These are exact disjoint positive submeasures; T=T_lo+T_hi.

Define the SPREAD auxiliary density

`g(u)=sum_(P in L) [v_P/|P|]1_P(u)`, `W_lo=integral g=sum_(P in L)v_P`. (3)

Since nu<=f and the packets partition space,

`0<=g<=sqrt(n)lambda`,

`||g||_2^2=sum_(P in L)v_P^2/|P|<=sqrt(n)lambda W_lo`. (4)

This is a genuine L2 bound on g. It asserts no pointwise density cap or L2 bound on f or nu. Concentrated original source remains in(1). The accepted actual traffic will be positively dominated by a hard response of g; that comparison is proved next and is not inferred from coarse averages alone.

One could enlarge the low class by testing residual average `v_P/|P|<=sqrt(n)lambda` instead of full-f average. The same proof would hold with that explicitly changed source classification; the original deep mass field m_P would remain unchanged. The main version here uses full-f coarse averages exactly as requested.

## 3. A receiver-independent source lift pays a real positive subtraffic

For original source z in packet P, attach an auxiliary U with the uniform distribution on P. The frozen joint source is the Markov kernel

`sum_P nu|P(dz) [1_P(u)/|P|]du`. (5)

Its z marginal is exactly the original nu. The law depends on the fixed label P(z); it is not asserted independent of z. It is independent of receivers conditional on that fixed source label. Original A(x,z), R(x) and all previous masks are unchanged and do not depend on the newly introduced U.

On the low-average actual traffic accept the tag if U belongs to the ACTUAL original cube Q_R(x), and reject it otherwise. Integrating out U defines

`theta_P(x)=|P intersect Q_R(x)|/|P|`,

`dT_lo,acc=theta_(P(z))(x)dT_lo`,

`dT_lo,rej=[1-theta_(P(z))(x)]dT_lo`. (6)

These are exact nonnegative allocations of the original traffic. In the lifted space they are literal indicator branches; no source has been conditioned on a receiver before the integral is formed. In particular

`H_packetdeep=H_hi+H_lo,acc+H_lo,rej` EXACTLY. (7)

For a fixed receiver, retain the original masks until taking a positive upper bound. Since A<=1/2, then `nu(P intersect Q_R)<=v_P`, the actual accepted row satisfies

`integral theta_(P(z))(x)1_L(P(z)) A(x,z)h_R(x-z)nu(dz)`

` <=(1/2)R^(-n)sum_(P in L)theta_P(x)nu(P intersect Q_R)`

` <=(1/2)R^(-n)sum_(P in L)theta_P(x)v_P`

` =(1/2)[h_R*g](x)`. (8)

This is the required actual-traffic comparison. There is no enlargement factor `(1+delta/R)^n`. It pays every whole-packet-captured low-average row with weight1, and also pays the tag-accepted positive fraction of partially captured rows. It does NOT assert that the rejected part is small.

Use the same accepted dimension-uniform hard-cube strong-L2 constant C2 used in R104 (`104::proof.md:429–487`, archive location as recorded in R316). Equations(4),(8) and Cauchy-Schwarz on the ORIGINAL E give

`H_lo,acc <= (C2/2)|E|^(1/2)||g||_2`

` <=(C2/2)n^(1/4)sqrt(X W_lo)`

` <= epsilon X + [C2^2/(16epsilon)]sqrt(n)W_lo` for every epsilon>0. (9)

More precisely the source term is `C2^2||g||_2^2/(16epsilon lambda)`. Thus the actual coarse energy may be retained rather than replaced by its upper bound. The strong L2 theorem is applied to g as an upper-bound test density; this is not a replacement of f inside the definition of E, R, nu, or A.

## 4. What extra information pays the ENTIRE low-average part

Coarse average alone supplies(4). It does not supply the comparison of the entire concentrated source response with g. The exact packetwise obstruction can be expressed without guessing a missing theorem. For `v_P>0` define

`a_P(x)=nu(P intersect Q_R(x))/v_P`.

A uniform packetwise positive domination of the unweighted captured source by C times its spread source holds IF AND ONLY IF

`a_P(x)<=C theta_P(x)` on the active rows. (10)

Indeed these two captured masses are respectively `v_P a_P` and `v_P theta_P`; (10) is exactly their comparison. The analogous criterion for the ACTUAL A-weighted packet traffic replaces a_P by `2v_P^(-1) integral_(P intersect Q_R) A(x,z)nu(dz)` (including the existing masks). This is a necessary-and-sufficient criterion for this particular packetwise positive L2 transfer, not a claim that it characterizes all possible global estimates.

Useful sufficient extra information is:

- A source-capture balance `a_P<=C theta_P` on a specified actual branch. Then that branch is at most `(C/2)integral_E M_hard g`, so it costs `epsilon X+C^2 C2^2 sqrt(n)W_lo/(16epsilon)`.
- A geometric overlap lower bound `theta_P>=tau>0` on a specified actual branch. Since a_P<=1, (10) holds with C=1/tau. Its entire actual traffic is paid at `epsilon X+C2^2 sqrt(n)W_lo/(16tau^2 epsilon)`. Whole-packet capture gives tau=1.
- A direct actual receipt for the positive rejected integral in(6). In combination with(9), this completes the entire low-average part.

These are alternatives. One must not charge the same low traffic under each receipt and silently combine them as disjoint branches. In the absence of such information the EXACT missing low-average integral is

`H_lo,rej=integral_E dx integral 1_L(P(z))`

`       [1-|P(z) intersect Q_R(x)|/|P(z)|]A(x,z)h_R(x-z)nu(dz)`. (11)

No dimension-free lower bound on theta, no capture-fraction assumption and no zero boundary error is asserted here. The full-radius cap does not by itself turn a low coarse average into (10).

## 5. Overlapping allocations: common probability settlement works

For an arbitrary frozen overlapping cover, assign source weights `psi_P(z)>=0` supported in P, with `sum_P psi_P=1` source-a.e. Let `v_P=integral psi_P nu`; attach U uniform on that P. The accepted actual row is bounded by `(1/2)h_R*g` with

`g(u)=sum_P[v_P/|P|]1_P(u)`.

Its total mass is source-once, `integral g=sum_Pv_P=||nu||` (or the mass of the selected low suballocation). Its L2 energy is NOT implied by that identity. The exact cross-term accounting is

`||g||_2^2=sum_(P,Q) v_P v_Q |P intersect Q|/(|P||Q|)`. (12)

Thus any such cover with proved energy `||g||_2^2<=B sqrt(n)lambda W_alloc` has the valid actual receipt

`H_acc<=epsilon X+[B C2^2/(16epsilon)]sqrt(n)W_alloc`.

An unweighted multiplicity M can give B<=M when each constituent mean is bounded, but M cannot be omitted. Allocating source mass once does not alone bound the cross terms. Packet masses for previous deep predicates stay the original masses; introducing psi does not change their definitions.

There IS a constructive way to combine overlapping covers at no number-of-partitions fee. Let omega be a frozen probability seed selecting a DISJOINT partition `P_omega`, for example a finite probability mixture or a uniform grid shift at a chosen physical packet size. Keep the ORIGINAL remainder(1), including its original P-deep mask, independent of this new seed. For each omega, classify its new cells by full-f low average and form g_omega exactly as in(3). Every g_omega has the cap `g_omega<=sqrt(n)lambda`. Apply the tag lift conditional on its new packet, retaining all original fields.

Average the actual high/accepted/rejected allocations over omega. Their positive sum is still exactly T, because omega has total probability1. Their accepted row satisfies

`row_acc <=(1/2)h_R*bar_g`, `bar_g=E_omega g_omega`.

Moreover

`bar_g<=sqrt(n)lambda`, `integral bar_g=E_omega W_lo,omega`.

Consequently(9) holds unchanged with `W_lo` replaced by `E W_lo,omega`. This is a genuine source-once mass-weighted settlement of the overlapping partitions; it uses probability averaging, not summing independent copies. A countable source grid and measurable shifts give a jointly measurable Markov construction. Uncovered or unnormalized allocations would leave an explicit positive remainder or incur their actual total weight. No lower bound on the accepted proportion is claimed for the random-shift scheme.

## 6. Positive actual native diagnostic INSIDE the remaining R318 slot

This construction checks that(9) pays nonzero traffic that R318 did not already pay. It is a receipt diagnostic, not a counterexample search.

Set n=16, k=4, a=lambda=1, b=2. In the integer-centered ownership cell `A0=Q_1(0)`, use the original fine grid of side1/16. In EACH fine cell put a centered microcube of half that cell's side, with density

`D=3*2^16=196608`.

Each fine cell has full source mass `3/16^16`; total local mass is3. Use coarse roots side1/4 aligned with the ownership boundaries. Every local root contains4^16 fine cells and has

`m_P=3/4^16`, `m_P/|P|=3<4=sqrt(n)lambda`. (13)

Uniform mass across its children makes the R318 adaptive rule freeze that root. It is strictly aggregate-deep for EVERY R>=1:

`3/4^16 < exp(-4)/4 <=R^16 exp(-4)/4`. (14)

For an exact sufficient check, use e<3 and `3/4^16<1/(4*3^4)`.

Add an external cube `Q_(1/2)(2e_1)` with constant density `8100*2^16`, hence rational full source mass8100. It lies entirely in the ownership cell A2 centered at2e_1. On the LOCAL source the original residual is nu=eta f, with

`eta=1-4/D=49151/49152`;

the external residual mass is exactly `v_ext=8100-4*2^(-16)`.

Take receivers `x in V=Q_(1/(4n))(0)`. All local microcubes are inside Q_1(x): the outermost source has margin1/(4n) from the boundary of A0, while receiver displacement is at most1/(8n). The external cube lies at coordinate distance at least7/4 before receiver displacement, so it is excluded by EVERY r in[1,2]. Thus

`h_r*f(x)=3/r^16`, `M=3`, `R*=1`, `G_N=1/3` on V. (15)

Choose K0 containing both source ownership cells; the outside source tail is zero. These two cells are connected in the R104 graph (index distance2). Their side5 macro-packages both contain the ENTIRE source. Each captured mass is at most3eta, whereas macro mass is `3eta+v_ext`; division by D104=8 is still larger than3eta. Hence every contributing macro capture gate fails, Theta=0, and G1=1/3. The harmonic sum is `3eta/(3eta+v_ext)<1/4`. The actual captured residual mass is3eta, satisfying the non-small capture gate, and the fixed component mass is larger than81>exp(4), satisfying the heavy gate. Thus the exact native masks in(1) retain the stated positive traffic.

Choose the interior coarse packet `P=[0,1/4)^16`. It is contained in Q_1(x) for all x in V, so theta_P=1. By(13)–(14) this packet belongs to the low-average ORIGINAL aggregate-deep remainder. Its accepted actual mass alone is

`(1/3)nu(P)|V|=eta(1/4)^16|V|>0`. (16)

The original point density D is vastly larger than the coarse cap4. This verifies precisely why the proof bounds g, rather than falsely treating f as an L2-capped input. Other packets touching receiver boundaries contribute only their exact tag-accepted fractions, with rejection retained in(11).

## 7. Complete ledger and actual new absorption coefficient

Combine(2),(7),(9), with no change to the previous source receipts:

`X <=(768/767){P104+S318+[C2^2/(16epsilon)]sqrt(n)W_lo`

`                       +epsilon X+H_hi+H_lo,rej}`.

For `0<epsilon<767/768`, the actual new complete-band inequality is

`X <= [768/(767-768epsilon)]`

`       {P104+S318+[C2^2/(16epsilon)]sqrt(n)W_lo+H_hi+H_lo,rej}`. (17)

Equivalently the raw total output loss is `1/768+epsilon`; no previously absorbed loss is charged twice. As an explicit budget choice, epsilon=1/128 gives

`X <=(768/761){P104+S318+8C2^2 sqrt(n)W_lo+H_hi+H_lo,rej}`. (18)

This epsilon is a NEW receipt parameter, not an assertion that some other branch has already reserved it. Any additional output losses must be combined with it in the actual ledger. All source fees add even if they use the same original residual source. The probability-mixture version replaces W_lo by its seed average and uses its exact averaged high/rejected residuals.

The high-average original source integral H_hi and the positive rejected integral(11) are still unpaid. Neither the spectral route nor historical FULL/history is implicitly imported to price them. The spectral author `/root/r286_joint_mass` confirmed compatibility: the present proof uses existing hard maximal L2 only after the actual positive comparison(8); its g is a legitimate L2 input, whereas arbitrary native masks would prevent assuming cancellation for original f.

## 8. Executed checks and audit scope

Local Python/Fraction execution checked D=196608, eta=49151/49152, m_P=3/4294967296, the exact e<3 sufficient packet-deep inequality, and the rational external residual mass and macro/heavy inequalities for the mass8100 cube. It also checked the exact Young coefficient `1/(16epsilon)=8` at epsilon1/128, the raw loss `1/768+1/128=7/768`, and absorption coefficient768/761. The diagnostic mass lower bound in(16) was exactly

`49151/16725558898897967356151788704486271129485312 >0`.

These executed arithmetic checks support constants; the containment, source-kernel and L2 arguments above are the proofs. `/root/r285_final_audit` independently screened the Markov lift, exact accepted/rejected allocation, receiver-row comparison and absorption, reporting PASS. The numeric author independently froze `/tmp/r319_allocation_checks.py` and `/tmp/r319_allocation_checks.json`, reporting618 exact checks and fresh double-run PASS for n=9,16,64. Their n16 fixture is exactly the rational external-mass8100 fixture above. The other stages use explicitly fine-aligned packet phases (n9 uses lower corner1/18). This is not a historical FULL audit or enumeration of the entire band. The returned artifact hashes were verified locally: Python `a3220e8fc7cefd8deda73d00f79b40cc6e459deef75d560f73e0a487ae0a2b8e`; JSON `b10c7931306b668fb51f5f382a116b6e0f882d9060eeaf467100d80087a25050`. Those files were not modified here.
