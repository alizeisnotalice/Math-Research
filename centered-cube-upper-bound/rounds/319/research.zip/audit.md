# R319 independent preauthor screen

Saved BEFORE reading any R319 author proof. Own only this audit; no Git or other-author edits. Original tools from R302/315/316/317/318 are retained without reauditing their entire proofs.

## 1. Self-contained cube Fourier estimate — independent PASS

Use Fourier transform exp(-ix dotxi), so the fullsideR cube average has multiplier m_R(xi)=product_j sinc(R xi_j/2), sinc(t)=sin(t)/t. A self-contained dimension-free product bound is available:

 |sinc(t)|²<=1/(1+t²/10),
 |m_R(xi)|<=(1+R²|xi|²/40)^(-1/2).

For|t|<=2, sinc>=0 and the alternating sine Taylor bound gives sinc<=1-t²/6+t⁴/120<=1-(2/15)t². The latter is nonnegative, and its square is<=1-(2/15)t². Multiplying by1+t²/10 gives a polynomial<=1. For|t|>=2 use|sinc|<=1/|t| and1+t²/10<=t². Product_j(1+u_j)>=1+sumu_j completes the product estimate. No asymptotic dimension estimate or external cube multiplier theorem is needed for this bound.

LetZ be uniform on the centered sidedelta cube. Then |1-m_delta(xi)|<=E|xi dotZ|<=delta|xi|/sqrt(12), using its isotropic covariance. Combining with the product estimate yields

 ||h_R*(I-h_delta)*g||_2<=sqrt(10/3)(delta/R)||g||_2

by Plancherel. Atxi=0 the multiplierzero is handled directly. The bound is uniform in dimension and valid in particular0<delta<=R. The specific constant is only one safe explicit choice. A quadratic lowfrequency estimate and trivialbound2 can also be retained; none changes the qualification below.

## 2. Fixedscale is NOT actual moving maximal scale, and L1 is NOT L2

The operator statement applies tog∈L2 and FIXED R,delta. Uniform fixedscale norms do not automatically bound the selectedR(x) operator orsup_[a,b]|h_R*(I-h_delta)g|. A frozen FINITE menu ofN radii admits the explicit square-sum factor sqrt(N) times the fixedscale bound; passing to the continuum needs a separately proved maximal/squarefunction/variation argument and its actual costs. Original cube strongL2 only gives the coarse2C2||g||2 bound for the smoothed difference; it does not by itself give a small delta/a factor.

An arbitrary original nonnegativeL1 input or capped highdensity residual need not beL2. Smoothing can make a new marginalL2 but does not remove the original signed/capped remainder or its L2 assumption. Replacing||g||2 by a mass bound requires a genuine density/energy estimate, possibly with dimension-exponential scalevolume costs. No arbitraryL1/nativeweak traffic price, full maxscale result, FULL or history transfer follows from the fixedscale Fourier lemma alone.

## 3. What the actual coarse average density cap can pay

For frozen disjoint finite-positive-volume packetsP, original nu=(f-sqrt(n)lambda)_+ andv_P=nu(P), their cellaverage g=sum(v_P/|P|)1_P satisfies||g||1=sumv_P. If the COMPLETE packet averages m_P/|P|<=sqrt(n)lambda on a fixed lowaverage packet class, then g<=sqrt(n)lambda there and||g||2²<=sqrt(n)lambda W_low. This is a density cap on the actual averaged residual, not on originalf/nu. The R318 deepmass bound alone only yields m_P/|P|<lambda R^n exp(-sqrt(n))/(sqrt(n)|P|), still with its full volume ratio; it need not give this lowaverage qualification. Highaverage packets remain a genuine positive complement.

A direct replacement of originalnu by this average is invalid without residual/transport/ancestral marks. Capping and averaging do not commute; nor do originalsource-dependent masks atz equal those at a newzprime. A safe crude upper bound after dropping masks is half the average hardresponse plus half the actual selected-response error. Its L1 envelope bound costs(A_n/2)||nu-nubar||1, not automatically small. Exact cellboundary/transport errors from R318 may be retained instead, with all legal radius/top qualifications. Whole-tent energy cannot be used to erase these source cross terms.

## 4. NEW random-allocation positive branch — independent PASS before proof

The supplied ledger candidate gives a legitimate alternative to replacing the source. On the exact original R318 packetdeep traffic, restrict to the fixed lowaverage packetsm_P/|P|<=sqrt(n)lambda. Adjoin a frozen auxiliary marku with Markovsource kernelUnif(P(z)); keep actual originalz, ALL masks, dx andR. Accept only ifu∈Q_R(x), reject its exact complement. The joint source measure nu(dz)du/|P(z)| is fixed before evaluating an individualreceiver; it is not conditioned on capture or resampledfavorably perx. At|P|=0 there is no positiveL1source; skip zero-mass packets.

After integrating the mark, accepted original traffic is multiplied bytheta_P(x)=|P∩Q_R(x)|/|P|. Originalz was already captured, so dropping gates only positively gives its row<=

 one-half R^(-n)sum_P theta_P(x)nu(P∩Q_R(x))
 <=one-half R^(-n)sum_P theta_P(x)nu(P)
 =one-half(h_R*g)(x).

Thus dimensionfree cube strongL2 and Young give the genuine positive branch payment

 H_accept<= (C2/2)sqrt(|E|)||g||2
          <=epsilon X+[C2²/(16epsilon)]sqrt(n)W_low.

No original fL2 or small Fourier multiplier is required. Original fullpacketcontained traffic has theta=1 and is included, while partial packets may have very smalltheta. Rejected(1-theta) lowaverage traffic and ALL highaverage packetdeep traffic remain EXACT and unpriced by this branch; no uniform capture fraction is asserted. The source labels/fullm_P and cappednu packets are unchanged. Arbitrary overlapping covers do not retain g∞ or itsL2energy merely from perpacket lowaverages and source-once allocation; their ACTUAL aggregate g must be bounded.

At epsilon=1/128, the original raw outputloss1/768 plus epsilon is7/768, hence the full entry multiplier is768/761. If working from the already absorbed768/767 form, the identical algebra gives the same result; do not apply two independent original absorptions. The new source fee is added to the chosen packetreceipt, not maximized against unrelated sources. This is an actual positive further native branch, not a FULL/history reconstruction or payment of the entire packetdeep remainder.

## 5. Actual bounded diagnostics

{'sinc_mp60': 68, 'multiplier_mp60': 147, 'allocation_Fraction': 27, 'entry_Fraction': 1}

Executed ordinary60-digit pointwise sinc/product multiplier tests, separate exactFraction allocation row and absorption arithmetic. AllPASS. The Fourier tests are finite frequency diagnostics, not an operatornorm certificate; its general proof is analytic above. Exact rowtests are algebraic weights, not full-native spatial inputs. No broad counterexample or input-family search. New author proofs have not yet been read; final comparisons and bindings pending.


## 6. Actual-soft pointheight localization — independent screen before proof

At original highJ>=H with minimumtent weightv<=1, the true fullsoft profile has pointheightP_(s,L)<=a^(-n), so U_y(w)<=1/(q_- a^n). Ifdelta(u,w)<=h, then||u-w||infinity<=h. The neighbor mass is therefore<=min(J,(2h/a)^n/q_-), and its fraction of fullJ is<=zeta=min(1,(2h/a)^n/(q_-H)). This estimate bounds BOTH actual near capture/miss loss AND capture/capture overlap, and even their sum(the entire near baseline), byzeta F1. WithF1<=AnWnu this is a legitimate sourceprice; alternativelyF1<=4X gives4zetaX. There is no covariance agreement/FULL/density assumption.

Chooseh=(a/2)min{1/n,(epsilon q_-H/An)^(1/n)} for epsilon>0. ThenzetaAn<=epsilon and the full top layer r>=max(a,b-2h) costs<=2Wnu. This remains valid in narrowband/t=a cases. The near price is a direct softpointheight/largeJ probability bound; it can REPLACE contact-shell/winner-defect fees in a new positive allocation. It is not added as another disjoint credit to a previously fixed fullcontact budget. The matchedfullsourceallradius cap remains needed for deep source-interior, but winner equality is not needed for this near estimate.

## 7. Whole-low energy with paid omissions and exact baseline merge

Independently checked the localization candidate before its proof. LetE_full,low=integral_LOW beta nu ell v A²/J, withLOWr<t_h. Its omitted captured-u bottom/deep overlap has the R315 firstmoment upperprices; collar-near overlap haszetaF1. Thus one valid inequality is Ecf>=E_full,low-paidomissions. Reusing wholelow projection requires those positive omitted-overlap expenses, not pretending the projectedwholeenergy<=localEcf.

There is a sharper exact merger that charges the relevant firstmoments ONCE. Partition TOP FIRST. OnLOW, originaltent=C_v-E_full at eachz,r; partition the FULL positive baselineC_v into captured-u bottom, deep, collar-near and collar-farNcf. Therefore EXACTLY

 Rtent=TopLoss+Nbottom,low+Ndeep,low+Nnear,low+Ncf-E_full,low.

The firstthreeLOW baselines have prices(1+lnAn)Wnu,(16/3)CsoftWbeta,epsilonWnu, witheta^n=1/An(a<b), andTopLoss<=2Wnu. For any genuine R317 whole-receiver projectionP_low<=E_full,low,

 Rtent<=(3+lnAn+epsilon)Wnu+(16/3)CsoftWbeta
                  +integral_LOW(Ncf-P_low).

The signedlastterm may be replaced by the integral of its pointwise positivepart as a safe nonnegative auxiliary remainder. This gives legal wholelowenergy reuse with no duplicate bottom/deep/near sourcefees, noX and no winnerdefect. All originalfullJ,v, FIRST, source and layer variables remain. Atb=a use the fixedscale directbound instead ofetaroot=1.

IMPORTANT: the new positivepart remainder is a fee in a bound for the WHOLE tent after paying omitted BASELINES. It need NOT dominate actual collarfar loss by itself, sinceP_full may exceedEcf; it is not a positive originalfartraffic allocation. R318's covariance-corrected local certificate had a different standaloneRcf domination interface. The present jointbaseline bound cannot be described as silently dropping its localcovariance defect or replacingEcf bywholeenergy. A quantitative source-root price for the new auxiliary remainder remains unproved.


## 8. Spectral author comparison — PASS, including its proved maximal extension

Read /tmp/r319_spectral.md after the independent screen. Its fixedscale3delta/R theorem has a different self-contained sinc-split proof from this reviewer's safe productbound, and is correct: smallcoordinate Taylor/exponential sum<=epsilon²/2; k largecoordinates cost<=4epsilon/sqrt(3); total<3epsilon. Large sinc factors<=7/8 and the exactk(7/8)^(k-1)<4 maximum at7/8 are uniform. The one-coordinateepsilon/pi sequence proves linear-rate sharpness for this multiplier only, not a native-input model.

Importantly the author actually PROVES the continuum selected-scale bound that the initial screen said did not follow automatically. Its logscale derivative multiplier has smallpart<2 and largepart<8, hence||Rpartial_Rh_R||2<=10 and smootheddifference derivative<=20. The pointwise Sobolev identity with the fixedscale3delta/R norm givesB²=9(delta/a)²+120ln(b/a)(delta/a). L2 differentiability and actual cube-response continuity justify the allscale representative/ties, includinga=b. This is a genuine result for originalL2 inputs, with a square-root loss in the norm; it does not retain the fixedscale linear rate for the maximal family. Delta is fixed before selectingR.

The real source truncation receipt and constants(7)–(8) are correct, includinga0², Young epsilonX, and2a0AnW_high. The exact kernelTV/L2 tensor identities and their coarse n^-1/2-scale limits are also correct. Originalf energy, convolved packet cross terms and source-mask commutator remain explicit; the new maximalestimate does not pay the entire arbitraryL1/native marked source or permit replacing its energy by averaged energy. Ordinary floating multiplier/derivative tests are not presented as uniform proofs. No correction requested.

## 9. Random-allocation author comparison — PASS

Read final /tmp/r319_entry.md after the independent screen. The exact frozen Markov source lift, accepted/rejected originalsubtraffic, low/high packet split, actual rowcomparison and Youngcoefficient agree with the screen. The lowclass may alternatively be enlarged using residualaverage, but the main full-f mean test is a sufficient fixed source qualification and the originaldeepmass field stays unchanged. The exact criterion for paying an ENTIRE lowpacket response compares its actualcaptured fraction with geometric theta; its weighted version and sufficientthetabound are correctly stated as extra conditions, not granted by coarseaverages or fullcaps.

The arbitrary overlapping-allocation energy includes allcross terms; source-onceL1 mass does not implyL2energy. The probabilitymixture of DISJOINT frozen partitions does provide a valid densitycapped averaged upper-sourcegbar without a numberofpartitions fee: eachg_omega has the cap, originalremainder/selector remainsindependentofnewseed, and high/accepted/rejected average to exactly the same actual traffic. No acceptedfraction or uniformly small rejection is assumed. The new originalentryloss is1/768+epsilon, soepsilon1/128 yields768/761 andsource8C2²sqrt(n)Wlow exactly; this is a NEW explicit outputbudget, not an assertion it was already reserved elsewhere.

Verified the rational actualnative fixture in §6: local microcubesD=196608 havefullmass3, coarseaverage3<4 butpointdensity≫4. Localresidual ratio49151/49152 is correct. The remote mass8100 cube inside the ownership cell at2e1 supplies macrodeficiency/heavy component while being excluded from every selectedcube at the stated actualreceiver box. Both source ownership cells lie in one index-distance2 component; all contributing macro capturegates fail. ActualnativeG1=1/3, residualcapture3eta, and original packetdeep/lowaverage/interiorpackettheta=1 conditions hold. The positive acceptedmass follows on that specified receiver SUBSET, not allhardband and not historicalFULL. The remote residualmass correctly differs from the localratio-scaledf because its density differs. No source cancellation or originalfL2 cap is used. No correction requested.


## 10. Geometry final author comparison — PASS

Read the complete frozen /tmp/r319_geometry.md after the independent screens in §§6–7. Its actual-profile height, near-volume quotient, inclusive layer tail, strict LOW/closed TOP convention, source-interior all-radius condition, projection and complete conditional continuation all pass. The near bound pays the ENTIRE first moment (capture plus miss) once. With the stated h0, the TOP mass is at most 2 even when t_h=a; the chosen eta gives r0<b for a<b by strict 1+log t<t. Deep requires the matched nu<=f and full all-radius cap at the same original receiver; no winner identity is needed and no such cap is inferred from same-selected-radius alone.

The critical identity (7) is exactly TOP true loss plus LOW full positive baseline minus LOW whole capture square. Bottom/deep/near source bills are charged once in this identity, and the shared projection is taken only on LOW. Pi_local is a finite signed integral because both nonnegative parts are bounded by the original first moment. Its whole-tent compensated interface is stated correctly: even its positive relaxation need not dominate standalone actual collar-far traffic. This is a legitimate new source-paid baseline localization, not zero covariance, local-energy domination or a new positive flow allocation. A root bound for Pi_local remains unproved.

At H0=sqrt(d An/(4lambda))>=d, the original positive entry gives exactly 4sqrt(lambda d An)(Wbeta+Wnu)+(32/3)Csoft Wbeta+(6+2log An+2epsilon)Wnu+2Pi_local. If H0<d the original coarse bound suffices; H=d has zero tent; a=b uses the fixed-scale branch. All lambda d, aspect, K/M, source and outer-clock costs remain. No mathematical correction requested to the final author proof.

## 11. Primary fresh-run evidence and integration scope

Read all three primary checkpoint logs, and inspected the actual allocation code and positive-volume fixture. The primary fresh runs record allocation 618 exact Fraction checks, geometry 606 exact Fraction checks, and spectral 652 checks (48 exact one-dimensional kernel plus 120 exact tensor kernel checks; 240 ordinary floating multiplier, 240 ordinary floating derivative and 4 floating sharp-sequence diagnostics). Thus primary total is 1876 counted assertions/diagnostics, not 1876 original inputs or all exact arithmetic. These primary runs are distinct from this reviewer's own bounded §5 calculations. No test was rerun merely to repeat this evidence; no numerical finite sample substitutes for the analytic operator/capture proofs.

Static review of research.tex confirms the native absorption 768/761 and source 8C2²sqrt(n)Wlow, the tent continuation, and the spectral source-truncation receipt. The two entrances remain separate. The native high-average and low-average rejected packet traffic are exact unpaid positive terms. Pi_local is a compensated auxiliary tent fee with no established root bound; it is not a decomposition of actual far traffic. Source-mask commutator/high L1 truncation costs remain for the spectral route. The full original broad/low-pe/aspect/history/initial/deletion/future-deleted/physical-scale ledger is not closed or silently identified with the new native entry. The new native output loss is explicitly 1/128 in addition to the original 1/768; no general budget closure is asserted.

Before binding the final TeX, requested two contract-only clarifications: explicitly state 0<=alpha<=1 and q<=lambda in §2, and restrict the displayed R_tent integral to {J>=H,0<A<H} (or zero its integrand elsewhere). The author proof already contains these guards. No new mathematical computation is required for those notation fixes.


## 12. Final byte binding and bounded verdict — FROZEN

The final TeX now explicitly states 0<=alpha<=1 and q_-<=q<=lambda and restricts R_tent to {J>=H,0<A<H}; read these corrected lines and verified its final SHA below. Both requested integration clarifications are resolved. No mathematical proof or numerical test changed. No compilation was requested or performed. At this freeze the checkpoint contains research.tex and the three proof attachments with scripts/logs; no separate README or combined.md was part of this final R319 integration request.

PASS for the three proved bounded results and the final static integration, under the explicit hypotheses and with the remaining fees described above. This is NOT approval of an arbitrary-source root bound, Pi_local root pricing, full native packet-deep pricing, identity between native and historical target integrals, or complete global ledger closure. In particular B_H remains the principal geometric gap. No auxiliary signed compensation certificate is relabelled as actual traffic.

The following SHA256 values bind the exact bytes reviewed. All three checkpoint proof copies were checked byte-identical to their author /tmp originals.

- `/tmp/r319_entry.md`: `d7fd38151dc91019b838eb5d79b84d944ac08fba4ef1c75fb445505645da9171`
- `/tmp/r319_geometry.md`: `dc4d9d84aaed2add3acf36de42f6d726c86d57055949a57e04a74afc385fa9bc`
- `/tmp/r319_spectral.md`: `e90a961401391cff0807514ace3405d40a6b9a4f78c17def61907283c15548f3`
- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round319_20261018_final_checkpoint/research.tex`: `79f70beb00c86e845db8b101c5259d667384f24bc4d7fb4d3c976767f6e2f8ca`
- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round319_20261018_final_checkpoint/allocation_checks.py`: `a3220e8fc7cefd8deda73d00f79b40cc6e459deef75d560f73e0a487ae0a2b8e`
- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round319_20261018_final_checkpoint/allocation_checks.json`: `b10c7931306b668fb51f5f382a116b6e0f882d9060eeaf467100d80087a25050`
- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round319_20261018_final_checkpoint/allocation_checks.log`: `ace86bd5d7df4db4f08401dc17681ca234a75b362d2d3736b02577e42b1800de`
- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round319_20261018_final_checkpoint/geometry_checks.py`: `13c288bb633caf2f58656416e798405b66650477b44721eeb2e921305f06a22b`
- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round319_20261018_final_checkpoint/geometry_checks.log`: `0365c84a1ecd7d945c1339af1ff3198b0a059dce1e052bbfb6bdf1c2c2d0c683`
- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round319_20261018_final_checkpoint/spectral_checks.py`: `1e8a4b90412bd76c1dcaca642578c1989b5b3cf8dc89d4dacdb0fd413f9e6307`
- `/Users/zhengzhihao/Desktop/T/output/centered_cube_round319_20261018_final_checkpoint/spectral_checks.log`: `3ebd59725973ef25c4e3a3defa237b8de0782b015881a59dfbba160af4037e89`

Audit ownership respected: only /tmp/r319_audit.md was written by this reviewer. No Git/repository/source-author edit, external communication, PDF or additional research run. This receipt is frozen.
