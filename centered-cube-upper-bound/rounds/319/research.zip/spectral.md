# R319 — fixed-scale smoothing gain, actual maximal cost, and the L1 source gap

## 1. A dimension-free fixed-scale theorem

Let h_R=R^(-n)1_(Q_R) be the centered full-cube probability kernel, with full side R. For every n>=1 and 0<delta<=R,

    ||h_R*(I-h_delta)||_(L2 to L2)<=3 delta/R.       (1)

Thus the proposed estimate holds in particular when delta<=a/sqrt(n) and R in[a,b]. It is a FIXED-scale operator statement. The rate cannot be uniformly improved to a higher power of delta/R.

Here is a self-contained multiplier proof, with Fourier convention giving hat(h_R)(xi)=product_i sinc(R xi_i/2), sinc(t)=sin(t)/t. Put t_i=R xi_i/2 and epsilon=delta/R<=1. Elementary bounds are

    |sinc t|<=exp(-t^2/8)                     if |t|<=1,
    |sinc t|<=alpha=7/8                       if |t|>1,
    |sinc t|<=1/|t|                           if t!=0,
    |1-sinc u|<=min(u^2/6,2).                         (2)

For the first inequality use sin(t)/t<=1-t^2/6+t^4/120<=1-t^2/8. For the second, sinc is decreasing on[1,pi], sin(1)<=101/120<7/8, and |sinc t|<=1/pi thereafter. The last inequality follows from sinc u=integral_0^1 cos(vu)dv. These arguments also cover negative arguments by symmetry.

Let S=sum_(|t_i|<=1)t_i^2 and k=#{i:|t_i|>1}. Telescope 1-product_i sinc(epsilon t_i), using |sinc|<=1. Multiply by |product_i sinc t_i|. The small-coordinate terms sum to at most

    (epsilon^2/6) S exp(-S/8)alpha^k
                                      <=4epsilon^2/(3e)<=epsilon^2/2.

For a large coordinate use min(epsilon^2 t_i^2/6,2)/|t_i|<=epsilon/sqrt(3); the remaining k-1 large factors cost alpha^(k-1). Their sum is at most

    (epsilon/sqrt(3)) k alpha^(k-1)<=4epsilon/sqrt(3).

The last bound holds because k alpha^(k-1) has its maximum at k=7,8 and is <4. Hence the multiplier has absolute value <=epsilon^2/2+4epsilon/sqrt(3)<3epsilon. Plancherel proves (1).

For sharp order, in one coordinate take t=pi/2+2pi j and epsilon=pi/t. Then sinc(epsilon t)=0, sin(t)=1, and the multiplier is exactly epsilon/pi. Extra coordinates can be zero. These epsilon tend to zero and can satisfy epsilon<=1/sqrt(n). This is a sharp-rate multiplier calculation, not a model of native traffic.

## 2. A proved continuum maximal estimate, with its extra cost

The smoothing delta is FIXED before the receiver/scale is chosen. Set T_R=h_R*(I-h_delta), e0=delta/a<=1 and ell=log(b/a). The following genuinely covers arbitrary measurable selected R(x) in[a,b]:

    ||sup_(a<=R<=b)|T_R g|||_2^2
          <=B^2 ||g||_2^2,
    B^2=9e0^2+120ell e0.                            (3)

For b<=2a this is <=100e0 ||g||_2^2. It loses a square root in the norm compared with (1); that loss is explicitly paid, not silently omitted. When a=b, (3) retains the fixed-scale coefficient 9e0^2.

To prove it, the same split gives the dimension-free derivative bound

    ||R partial_R h_R||_(2 to 2)<=10.               (4)

Indeed its multiplier is sum_i[cos(t_i)-sinc(t_i)]product_(j!=i)sinc(t_j). The small terms are bounded by e^(1/8)S exp(-S/8)/3<2, since |cos t-sinc t|<=t^2/3; the large terms total at most 2k alpha^(k-1)<8. Thus ||R partial_R T_R||_(2 to 2)<=20. For log-scale t in[0,ell], the pointwise Sobolev identity and Cauchy-Schwarz give

    ||sup_t |T_(a exp(t))g|||_2^2
       <=||T_a g||_2^2
           +2 integral_0^ell ||T_(a exp(t))g||_2
                              ||partial_t T_(a exp(t))g||_2 dt,

which is (3) by (1). The Fourier derivative bounds imply strong L2 differentiability and a W^(1,2) representative in log scale; the argument follows first for smooth inputs and then by L2 approximation. For L1 intersect L2 inputs the actual cube responses are continuous in R, so this maximal representative also covers the original selected radii, ties and endpoints. No finite-menu approximation cost is hidden.

Choosing delta separately for each R would change this derivative calculation; (3) does not license that modification.

## 3. A true source-linear truncation receipt, and its unpaid high source

For a FIXED actual g in L1 intersect L2 and a finite receiver set E, (3) gives

    integral_E sup_R |T_R g|dx
       <=epsilon lambda|E|+B^2||g||_2^2/(4epsilon lambda). (5)

For arbitrary positive f in L1, possibly not in L2, make the REAL frozen source decomposition

    f0=min(f,K), f1=(f-K)_+, K>0,
    W0=integral f0, W1=integral f1, W0+W1=||f||_1.

Then ||f0||_2^2<=K W0. The high source has the valid positive estimate

    integral sup_R |T_R f1|dx<=2A_n W1,
    A_n=1+n log(b/a).                              (6)

For its proof, |T_R f1|<=h_R*f1+h_R*h_delta*f1; the second maximum is <=h_delta*(sup_R h_R*f1). Each term has L1 norm <=A_n W1. This is a global translation-invariant positive envelope argument, not FIRST at shifted receivers.

Combining these facts, for any receiver-only coefficient 0<=a(x)<=a0,

    integral_E a(x)sup_R |T_R f|dx
       <=epsilon X+a0^2 B^2 K W0/(4epsilon lambda)
                                      +2a0 A_n W1,
    X=lambda|E|.                                   (7)

All source masses are those of the real decomposition, once each. At delta=a/sqrt(n), K=lambda sqrt(n), a0=1/2, this becomes the explicit finite bound

    <=epsilon X+[9/sqrt(n)+120log(b/a)]W0/(16epsilon)
                                      +A_n W1
    <=epsilon X+25W0/(4epsilon)+A_n W1.             (8)

This pays the low-density smoothing response with a dimension-free source coefficient. The high residual STILL has linear A_n cost. Neither (7) nor (8) pays the entire R318 deep-birth traffic. An epsilon-X absorption requires its independently established same finite-X entry. The original outer factor multiplies every term.

The scalar maximal responses satisfy |sup_R h_R*f-sup_R h_R*h_delta*f|<=sup_R|T_R f|. Thus (7) is an actual maximal RESPONSE comparison. It does not identify a source-qualified native traffic with that unmarked scalar response difference.

## 4. Original source energy, packet cross terms and mask cancellation

Coarse source-cell averaging does not give ||f||_2 an upper bound. For disjoint finite-volume source packets P_i, m_i=integral_(P_i) f and g=sum_i(m_i/|P_i|)1_(P_i),

    ||g||_2^2=sum_i m_i^2/|P_i|<=||f||_2^2,

the opposite direction from the desired substitution. If f is in L2, the exact orthogonal projection identity is ||f-g||_2^2=||f||_2^2-||g||_2^2; arbitrary L1 inputs may have infinite original energy. A fine/coarse-cell mass upper bound alone does not repair this.

For finite packet sums, the output energy includes EVERY cross term

    ||sum_i T_R f_i||_2^2
      =sum_i||T_R f_i||_2^2+2sum_(i<j)<T_R f_i,T_R f_j>.

Disjoint source support does not make these convolved terms orthogonal. The global L2 theorem legitimately controls their full sum when the ORIGINAL input is in L2; summing only individual output energies is not that theorem.

There is also an exact mass-only diagnostic. For delta<=R, K_(R,delta)=h_R-h_R*h_delta has

    ||K_(R,delta)||_1=2[1-(1-delta/(4R))^n],
    ||K_(R,delta)||_2^2
       =R^(-n)[1-2(1-delta/(4R))^n+(1-delta/(3R))^n]. (9)

In one dimension, <h_R,h_R*h_delta>=R^(-1)-delta/(4R^2) and ||h_R*h_delta||_2^2=R^(-1)-delta/(3R^2); tensorization proves (9). For L1 inputs the full fixed-scale energy is the signed Gram integral

    ||T_R f||_2^2=integral f(dy)f(dz)
          <K_(R,delta)(.-y),K_(R,delta)(.-z)>.

Its absolute bound is ||K||_2^2 ||f||_1^2, not a source-linear energy estimate. All local packet interactions remain in this Gram integral. At delta/R of order n^(-1/2), the L1 kernel norm in (9) tends to2 and its normalized L2 kernel energy tends to1. These are rigorous kernel facts, not counterexamples to the native operator theorem. They explain why the dimension-free L2 MULTIPLIER gain is not an L1 source-mass gain.

Finally native A(x,z) depends on the source. For a receiver-only reference a(x), the exact marked smoothing discrepancy is

    integral A(x,z)K_(R(x),delta)(x-z)f(z)dz
       =a(x)T_(R(x))f(x)
          +integral [A(x,z)-a(x)]K_(R(x),delta)(x-z)f(z)dz. (10)

The second term is an actual mask/cancellation error. Packetwise references likewise produce source-dependent coefficient sums and all their cross terms. Original FIRST, source conservation and winner caps do not remove (10). A cancellation-preserving comparison or a separate fee for that error is necessary before (7) can settle native marked traffic. No component FIRST, source-density cap or coarse-average energy cap is inserted here.

## 5. Executed bounded diagnostics

The code below passed 48 exact one-dimensional kernel assertions, 120 exact tensor assertions, 240 floating multiplier bounds, 240 floating derivative bounds and4 sharp-sequence checks. The largest sampled fixed multiplier divided by delta/R was0.3068197055237119; the largest sampled log-scale derivative was1.0405324731885162. Floating samples are diagnostics, not proofs of the uniform constants. The exact kernel formulas, uniform estimates and source receipts are proved above. No native selector/source-mask realization is claimed by these tests.

```python
from fractions import Fraction as F
from math import sin,cos,pi,sqrt,prod
from random import Random
rng=Random(319);ct={'one_dim_kernel':0,'tensor_kernel':0,'fixed_multiplier':0,'scale_derivative':0,'sharp_sequence':0}
for R in (F(1),F(3,2),F(2)):
 for eps in (F(1),F(1,2),F(1,4),F(1,16)):
  delta=R*eps
  def q(x):return max(F(0),min(R/2,x+delta/2)-max(-R/2,x-delta/2))/(R*delta)
  pts=sorted(set((-R/2-delta/2,-R/2,-R/2+delta/2,R/2-delta/2,R/2,R/2+delta/2)))
  mass=q2=cross=tv=F(0)
  for a,b in zip(pts,pts[1:]):
   qa,qb=q(a),q(b);w=b-a;inside=int(abs((a+b)/2)<R/2)
   mass+=w*(qa+qb)/2;q2+=w*(qa*qa+qa*qb+qb*qb)/3
   cross+=inside*w*(qa+qb)/(2*R)
   tv+=w*(abs(F(inside)/R-qa)+abs(F(inside)/R-qb))/2
  assert mass==1 and q2==1/R-delta/(3*R*R) and cross==1/R-delta/(4*R*R)
  assert tv==2*(1-(1-eps/4));ct['one_dim_kernel']+=4
  for n in (1,2,8,64,256):
   z=1-2*(1-eps/4)**n+(1-eps/3)**n
   assert z>=0 and 0<=2*(1-(1-eps/4)**n)<=2;ct['tensor_kernel']+=2
maxfixed=maxder=0.0
for n in (1,2,4,16,64,256):
 for eps in (1/sqrt(n),1/n,1/16,1/128,1/2):
  vecs=[[c/sqrt(n)]*n for c in (.5,1,2)]
  vecs += [[pi/eps]+[0.]*(n-1),[2.5]*min(n,8)+[0.]*(n-min(n,8)),
           [rng.uniform(-2,2)/sqrt(n) for _ in range(n)],
           [rng.choice((-1,1))*10**rng.uniform(-2,2) for _ in range(n)],
           [sqrt(12)/eps]+[.5/sqrt(n)]*(n-1)]
  for t in vecs:
   sinc=lambda x:sin(x)/x if x else 1.
   a=[sinc(x) for x in t];pre=[1.]
   for x in a:pre.append(pre[-1]*x)
   suf=[1.]*(n+1)
   for i in range(n-1,-1,-1):suf[i]=suf[i+1]*a[i]
   m=pre[-1];sm=prod(sinc(eps*x) for x in t)
   ratio=abs(m*(1-sm))/eps
   der=abs(sum((cos(t[i])-a[i])*pre[i]*suf[i+1] for i in range(n)))
   assert ratio<=3+1e-12 and der<=10+1e-12
   maxfixed=max(maxfixed,ratio);maxder=max(maxder,der)
   ct['fixed_multiplier']+=1;ct['scale_derivative']+=1
for k in (1,2,16,256):
 t=pi/2+2*pi*k;eps=pi/t
 value=abs((sin(t)/t)*(1-sin(eps*t)/(eps*t)))/eps
 assert abs(value-1/pi)<1e-12;ct['sharp_sequence']+=1
print('PASS',ct,'max_fixed_ratio',maxfixed,'max_logscale_derivative',maxder)
```

Only `/tmp/r319_spectral.md` is authored here; other authors' files and Git are unchanged.
