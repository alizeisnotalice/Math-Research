from fractions import Fraction as F
from math import sin,cos,pi,sqrt,prod
from random import Random
rng=Random(319);ct={'one_dim_kernel':0,'tensor_kernel':0,'fixed_multiplier':0,'scale_derivative':0,'sharp_sequence':0}
for R in (F(1),F(3,2),F(2)):
 for eps in (F(1),F(1,2),F(1,4),F(1,16)):
  delta=R*eps
  def q(x):return max(F(0),min(R/2,x+delta/2)-max(-R/2,x-delta/2))/(R*delta)
  pts=sorted(set((-R/2-delta/2,-R/2,-R/2+delta/2,R/2-delta/2,R/2,R/2+delta/2)))
  mass=q2=cross=tv=F(0)
  for a,b in zip(pts,pts[1:]):
   qa,qb=q(a),q(b);w=b-a;inside=int(abs((a+b)/2)<R/2)
   mass+=w*(qa+qb)/2;q2+=w*(qa*qa+qa*qb+qb*qb)/3
   cross+=inside*w*(qa+qb)/(2*R)
   tv+=w*(abs(F(inside)/R-qa)+abs(F(inside)/R-qb))/2
  assert mass==1 and q2==1/R-delta/(3*R*R) and cross==1/R-delta/(4*R*R)
  assert tv==2*(1-(1-eps/4));ct['one_dim_kernel']+=4
  for n in (1,2,8,64,256):
   z=1-2*(1-eps/4)**n+(1-eps/3)**n
   assert z>=0 and 0<=2*(1-(1-eps/4)**n)<=2;ct['tensor_kernel']+=2
maxfixed=maxder=0.0
for n in (1,2,4,16,64,256):
 for eps in (1/sqrt(n),1/n,1/16,1/128,1/2):
  vecs=[[c/sqrt(n)]*n for c in (.5,1,2)]
  vecs += [[pi/eps]+[0.]*(n-1),[2.5]*min(n,8)+[0.]*(n-min(n,8)),
           [rng.uniform(-2,2)/sqrt(n) for _ in range(n)],
           [rng.choice((-1,1))*10**rng.uniform(-2,2) for _ in range(n)],
           [sqrt(12)/eps]+[.5/sqrt(n)]*(n-1)]
  for t in vecs:
   sinc=lambda x:sin(x)/x if x else 1.
   a=[sinc(x) for x in t];pre=[1.]
   for x in a:pre.append(pre[-1]*x)
   suf=[1.]*(n+1)
   for i in range(n-1,-1,-1):suf[i]=suf[i+1]*a[i]
   m=pre[-1];sm=prod(sinc(eps*x) for x in t)
   ratio=abs(m*(1-sm))/eps
   der=abs(sum((cos(t[i])-a[i])*pre[i]*suf[i+1] for i in range(n)))
   assert ratio<=3+1e-12 and der<=10+1e-12
   maxfixed=max(maxfixed,ratio);maxder=max(maxder,der)
   ct['fixed_multiplier']+=1;ct['scale_derivative']+=1
for k in (1,2,16,256):
 t=pi/2+2*pi*k;eps=pi/t
 value=abs((sin(t)/t)*(1-sin(eps*t)/(eps*t)))/eps
 assert abs(value-1/pi)<1e-12;ct['sharp_sequence']+=1
print('PASS',ct,'max_fixed_ratio',maxfixed,'max_logscale_derivative',maxder)
