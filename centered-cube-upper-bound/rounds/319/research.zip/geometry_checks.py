from fractions import Fraction as F
from itertools import product
counts={"joint_identity":0,"near_first_moment":0,"receiver_volume":0}

def ck(test,key):
    assert test, key
    counts[key]+=1

# Exact prescribed-kernel fixture: L=2, R=9/5, q=1, lambda=4/3.
# Two beta rows of unit mass; four disjoint receiver intervals of width l.
# Their centers are -19/20,-7/10,7/10,19/20. Inner two capture z~0.
# All source/receiver incidences are constant on positive-volume boxes.
l=F(1,50); R=F(9,5); b=F(2); th=F(99,50)
U=[[F(1,2)]*4,[F(1,2),F(1,2),F(0),F(1,2)]]
c=[0,1,1,0]; H=F(1,40); d=F(3,200)
J=[l*sum(row) for row in U]
A=[l*sum(row[i]*c[i] for i in range(4)) for row in U]
v=[(min(d,Ai)-d*Ai/H)/(Ai*(1-Ai/Ji)) for Ai,Ji in zip(A,J)]
Cv=sum(vi*Ai for vi,Ai in zip(v,A))
Ef=sum(vi*Ai*Ai/Ji for vi,Ai,Ji in zip(v,A,J))
Tent=sum(min(d,Ai)-d*Ai/H for Ai in A)
ck(Cv-Ef==Tent==F(7,1000),"joint_identity")
lowmass=1/R-1/th; topmass=1/th
for h in [F(1,k) for k in (100,125,150,200,250,400,1000)]:
    # For h<=l the area inside one interval with |u-w|<=h is 2lh-h^2.
    neararea=2*l*h-h*h
    Nnear=sum(v[y]/J[y]*sum(U[y][i]**2*c[i]*neararea for i in range(4))
              for y in range(2))
    Nfar=Cv-Nnear
    ck(Tent/R==Tent*topmass+(Nnear+Nfar-Ef)*lowmass,"joint_identity")
    zeta=min(F(1),2*h/H) # q_-=a=1; true full-soft upper bound is 1.
    ck(Nnear<=zeta*sum(A),"near_first_moment")
    # Refined common-receiver projection uses the same low-layer full fields.
    P=F(0)
    for i in range(4):
        mass=l*sum(v[y]*U[y][i] for y in range(2))
        mean=l*sum(v[y]*U[y][i]*A[y]/J[y] for y in range(2))
        P+=mean*mean/mass if mass else 0
    ck(P<=Ef,"joint_identity")
    ck(Tent/R<=Tent*topmass+(Nnear+Nfar-P)*lowmass,"joint_identity")
# A diagnostic whole low energy may exceed a selected local overlap; we
# never infer standalone local loss <= Nfar-P from the preceding identity.
ck(lowmass==F(5,99) and topmass==F(50,99),"joint_identity")

# Exact actual receiver-volume intersection checks in dimensions 1..64.
# U=1 on Q_1(0), so J=1; H<=J and q_-=a=1. No source-density assumption.
for n,h,Hh,center in product((1,2,4,8,16,64),
          (F(1,100),F(1,10),F(1,2),F(3,4)),
          (F(1,100),F(1,4),F(1)),
          (F(0),F(1,3),F(1,2),F(3,4))):
    width=max(F(0),min(F(1,2),center+h)-max(F(-1,2),center-h))
    mass=width**n
    ck(mass<=min(F(1),(2*h)**n),"receiver_volume")
    ck(mass<=min(F(1),(2*h)**n/Hh),"receiver_volume")
print(counts)
print("PASS",sum(counts.values()),"exact Fraction checks")
