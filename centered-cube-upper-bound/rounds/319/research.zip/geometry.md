# R319 — paid localization of the common-receiver capture square

## 1. Claim and original contract

This note proves a source-paid transfer of the **whole low-layer capture square** to the R315 collar-far baseline. The excluded baseline pieces are paid once, including a new actual-receiver-volume payment for every near pair. It does not prove a root bound for the resulting compensated far certificate, and does not assert that a whole-row projection is bounded by the local far overlap.

Keep the original fields, sources and qualifications:

    U_y(x)=1_E(x) alpha(x,y) P_(s(x),L(x))(x-y)/q(x),
    J_y(r)=integral_{R(x)<=r} U_y(x) dx,
    A_yz(r)=integral_{R(x)<=r} U_y(x)c_x(z) dx,
    c_x(z)=1_{Q_(R(x))(x)}(z),
    rho(x)=integral U_y(x) beta(dy)<=1.

Here Q_R is the centered cube of side R, a<=L,R<=b<=2a, q_-=3lambda/4<=q<=lambda, and 0<=alpha<=1 retains the actual low-pe, m, full e_g, aspect and history qualifications. The finite positive L1 sources beta and nu are not assumed comparable. All positive outer factors and clock integrations remain outside every displayed estimate, with the same multiplicity on its terms. Use

    ell_n(dr)=b^(-n)delta_b(dr)+n r^(-n-1)1_(a,b)dr,
    A_n=1+n log(b/a),
    W_beta=beta(R^n), W_nu=nu(R^n), X=lambda |E|.

Thus ell_n([R,b])=R^(-n), including radius atoms. Assume the original same-receiver hard cap nu(Q_R(x))<=4lambda R^n. For the deep-interior payment alone, assume the matched source domination nu<=f and original all-radius cap

    sup_{a<=t<=b} h_t*f(x)<=4lambda, x in E.       (1)

These two hypotheses are available for the matched R237/R244 slot recorded by R314 provenance. No hard-winner equality is needed here. They are not consequences of the abstract same-radius cap alone.

Fix H>=d>0. On Y_z(r)={y:J_y(r)>=H, 0<A_yz(r)<H}, put

    g(A)=min(d,A)-(d/H)A,
    v_y(z,r)=g(A)/[A(1-A/J)], p_y=A/J;

put v=p=0 elsewhere. Then 0<=v<=1. The full original J is never recomputed after a restriction. Write

    R_tent=integral nu(dz) ell_n(dr) beta(dy) 1_Y g(A).

The original R316 entry is

    T_target <=8lambda H W_beta+2(d/H)A_n W_nu+2R_tent. (2)

All subsequent improvements concern exactly this auxiliary tent in (2), not an assertion that it equals original positive traffic.

## 2. New near-pair payment from actual receiver volume

The original profile is h=1_[-1/2,1/2], w(t)=integral_0^1 exp(-|t|/u)du, phi=h*w, and f_s=(1-s)h+s phi. Since w<=1 and integral h=1, phi<=1; hence f_s<=1 and

    U_y(x)<=1/(q_- a^n).                           (3)

This uses the actual full-soft kernel, not a component FIRST or a source-density bound.

For actual endpoints u,w let

    delta(u,w)=||u-w||_infinity+|R(u)-R(w)|/2.

Fix an outer h_0>0. On every high-J row and every prefix,

    [integral_{R(w)<=r} U_y(w)1_{delta(u,w)<=h_0}dw]/J_y(r)
       <= zeta:=min(1,(2h_0/a)^n/(q_- H)).          (4)

Indeed delta<=h_0 implies w lies in the actual cube Q_(2h_0)(u), of Lebesgue volume (2h_0)^n. Apply (3), J>=H, and the trivial bound by J. No FIRST is evaluated at a virtual receiver or at z.

Consequently the entire near-pair first moment, with any further capturing-u restriction and with v retained, is at most

    zeta F1 <=zeta A_n W_nu,
    F1:=integral beta(dy)nu(dz)ell_n(dr) A_yz(r)
       =integral_E rho(x) h_(R(x))*nu(x)dx.        (5)

The equality follows by the inclusive ell tail; FIRST and the hard scale envelope give F1<=A_n W_nu. Also F1<=4X. Both the near loss c_u(1-c_w) and near overlap c_uc_w are covered, but their SUM is paid by (5) once, not twice.

## 3. Exact baseline partition; no illegal local square subtraction

For fixed z,r let E_r={x in E:R(x)<=r}, and define

    C_v(z,r)=integral beta(dy) v_y A_yz(r),
    E_full(z,r)=integral beta(dy) v_y A_yz(r)^2/J_y(r).

The true tent layer equals C_v-E_full. The full positive baseline has the exact endpoint representation

    C_v=integral beta(dy) v_y/J_y(r)
             integral_(E_r x E_r) U_y(u)U_y(w)c_u(z) du dw. (6)

Zero v rows contribute zero throughout. Fix 0<eta<1 and define r_0=a/eta and t_h=max(a,b-2h_0). First partition layers into TOP r>=t_h and LOW r<t_h. On LOW, partition the capturing endpoint in (6), in this order:

* bottom: R(u)<=r_0;
* deep: R(u)>r_0 and z in Q_(eta R(u))(u);
* near collar: R(u)>r_0, z in Q_R(u)(u) minus Q_(eta R(u))(u), and delta(u,w)<=h_0;
* far collar: the same collar condition and delta(u,w)>h_0.

Let N_bottom, N_deep, N_near, N_cf be these nonnegative baseline integrals. These are first moments in the second endpoint: N_cf has no factor 1-c_w. Let TopLoss be the true tent integrated on TOP. Then

    R_tent=TopLoss+integral_LOW (N_bottom+N_deep+N_near+N_cf-E_full). (7)

This is an exact identity with all original v,J and endpoint measures. Equivalently, loss plus excluded overlap is the corresponding excluded first moment. The local far loss itself is N_cf-E_cf, where E_cf retains c_w. We do NOT claim E_full<=E_cf or that a whole-row projection can be subtracted from N_cf without paying the other baselines.

The separate receipts in (7) are

    TopLoss <=[1+n log(b/t_h)]W_nu,
    integral_LOW N_bottom <=[1+n log(min(b/a,1/eta))]W_nu,
    integral_LOW N_deep <=min(4eta^n X,
                         (16/3)eta^n A_n Csoft_n W_beta),
    integral_LOW N_near <=zeta A_n W_nu.            (8)

For the first two, drop v, integrate the second endpoint to J, and use FIRST followed by the hard scale envelope. More explicitly TOP has weight max(t_h,R)^(-n), whose receiver envelope has mass 1+n log(b/t_h). The bottom scale window is [a,min(b,r_0)].

For deep, eta R(u)>a and eta R(u)<=b, so (1), at the SAME actual receiver, gives nu(Q_(eta R(u))(u))<=4lambda eta^n R(u)^n. Cancel the full J only after bounding v<=1, and integrate ell to obtain 4lambda eta^n integral beta(dy)I_y, where I_y=integral_E U_y dx. FIRST gives integral beta I_y<=|E|. Alternatively the full-soft common-parameter envelope gives

    I_y<=A_n Csoft_n/q_-,
    Csoft_n=sum_(k=0)^n max_(0<=s<=1) binom(n,k)s^k(1-s)^(n-k)
           <=1+(pi/2)sqrt(n).                     (9)

Csoft_n is a coefficient-sum upper bound, not an asserted equality with integral sup_s P_s. The physical common-softness and scale-envelope provenance is recorded in /tmp/r315_soft_envelope_provenance.md. The factor 16/3 in (8) is 4lambda/q_-. The near receipt is (4)-(5), including both capture and miss of w. Thus (8) introduces no hard-winner defect and no additional source copy per receiver cell.

## 4. Legal shared projection and a root-priced localization theorem

For fixed z,r define on E_r

    rho_v(x)=integral beta(dy)v_y U_y(x),
    b_v(x)=integral beta(dy)v_y U_y(x)p_y.

For any fixed finite or countable measurable common receiver partition {Omega_i}, set

    M_i=integral_(Omega_i)rho_v dx,
    B_i=integral_(Omega_i)b_v dx,
    P_grid(z,r)=sum_i B_i^2/M_i,                    (10)

where zero M_i contributes zero. The R317 two Cauchy-Schwarz inequalities give

    0<=P_grid<=integral b_v^2/rho_v dx<=E_full.      (11)

For completeness, at an actual receiver the probability beta(dy)v_yU_y(x)/rho_v(x) has second moment at least the square of its mean p_y. Integrate this inequality and then apply Cauchy-Schwarz inside each Omega_i. All fields use the SAME full prefix and actual v. One may refine a fixed dyadic partition, but no uncountable selector or new FIRST is needed.

Assume a<b, and choose the outer auxiliary parameters

    eta^n=1/A_n,
    h_0=(a/2) min(1/n,(epsilon q_- H/A_n)^(1/n)), epsilon>0. (12)

Then r_0<b: with t=(b/a)^n>1, 1+log t<t. Also zeta A_n<=epsilon and

    1+n log(b/t_h)<=1+n log(1+2h_0/a)<=2.

The chosen h_0 changes only the auxiliary geometric split, never the actual scales or original row. Define the finite signed certificate

    Pi_local=integral nu(dz)ell_n(dr)1_{r<t_h}
                       [N_cf(z,r)-P_grid(z,r)].    (13)

Both positive terms in (13) have integrals at most F1<=A_n W_nu. Thus (13) is a legitimate finite signed integral, not infinity minus infinity. From (7)-(12),

    R_tent <=(3+log A_n+epsilon)W_nu
                  +(16/3)Csoft_n W_beta+Pi_local.  (14)

This is the claimed new paid localization: the whole low-layer capture projection is retained at source cost O(log A_n)W_nu+O(sqrt(n))W_beta. In particular, it avoids charging R318 covariance errors edge by edge. It does not declare those errors zero or prove positive covariance.

One may replace Pi_local by max(Pi_local,0), or by the larger integral_LOW (N_cf-P_grid)_+, and state the chosen relaxation explicitly. Neither positive relaxation necessarily bounds the standalone original far loss. It is a compensated remainder for the WHOLE tent after (8), not a positive original-traffic allocation.

At H=sqrt(d A_n/(4lambda))>=d, (2) yields the complete conditional continuation

    T_target <=4sqrt(lambda d A_n)(W_beta+W_nu)
              +(32/3)Csoft_n W_beta
              +(6+2log A_n+2epsilon)W_nu+2Pi_local. (15)

The original lambda d=(4/3)kappa_0 psi_infinity/v_0, kappa_0=2K/(ell M), and psi_infinity=3-2/(3gamma^n), gamma=1+1/n, remain unchanged when this is the matched R302 normalization. No aspect, K/M, v_0, outer-clock or source multiplicity has been suppressed. If this choice of H is below d, the existing coarse bound T_target<=2A_n W_nu already gives T_target<=4sqrt(lambda d A_n)W_nu; (14) is unnecessary. If a=b, use the fixed-scale bound B_H<=W_nu rather than (12). If H=d the true tent is zero. Zero source mass is immediate.

## 5. What is paid, and the precise remaining gap

Equation (14) pays the excluded bottom, deep, top and entire near FIRST MOMENT using their actual shared-source or actual dx bounds. It legally retains whole low-layer common-receiver overlap in the remaining signed expression. This improves the interface beyond R318's local rectangle correction: it permits whole low-layer projection after a finite, root-sized source payment, with no hard-winner hypothesis and no contact defect.

It does not prove a root source price for Pi_local. A sufficient next inequality is, for the SAME original masks and fields,

    Pi_local <=epsilon' X+C_(epsilon')sqrt(A_n) log^A(n+2)
                              (W_beta+W_nu),       (16)

with all original aspect and lambda d dependencies displayed. No estimate (16) is asserted here. Small receiver cells do not by themselves prove it: receiver projection still loses conditional cross-row variance. Nor does the source all-radius cap control arbitrary posterior variation. The outstanding geometric task is a quantitative comparison of the actual far-collar baseline N_cf with its **whole low-layer** shared capture projection, after the baseline costs already paid in (14). This proof must not be reinterpreted as local-energy domination.

Measurability follows from the original measurable fields, positive integration and a fixed countable partition. Inclusive prefixes retain all physical radius atoms; the strict LOW/TOP split assigns t_h to TOP. The spatial collar assigns the inner boundary to deep. For L1 sources cube boundaries are null, and in any event the displayed partition convention is exhaustive. Countable partition sums are nonnegative and bounded by E_full; common finite truncations and Tonelli justify all preceding operations.

## 6. Reproducible finite checks (diagnostics, not the proof)

The Python block below uses only standard-library exact Fractions. It checks the exact top-first identity, the near-pair first-moment bound and positive-volume receiver intersections. The fixture uses an endpoint hard profile s=0 and prescribed actual row caps. For a literal positive-volume realization, take the two unit beta masses uniform on intervals of length 1/1000 centered at -1/200 and 1/200; take unit nu uniform on [-1/1000,1/1000]. The four receiver intervals have the centers and lengths specified in the code. The first row has alpha=1 throughout; the second has alpha=0 on the third interval and 1 on the other three. On all these source-receiver products P_(0,2)=1/2, and rho<=1. The inner two receiver intervals capture all of nu at R=9/5 and the outer two miss it. With eta=3/5 those captures are in the collar. The all-radius nu cap holds since a=1 and W_nu=1. These checks require no atomic-source idealization. It is NOT a certification of native positive-softness FIRST or the historical low-pe/m/aspect gates. The proof above, rather than this fixture, retains those qualifications for original inputs. No new script file is required: extract this single Python block and execute it in a fresh interpreter.

```python
from fractions import Fraction as F
from itertools import product
counts={"joint_identity":0,"near_first_moment":0,"receiver_volume":0}

def ck(test,key):
    assert test, key
    counts[key]+=1

# Exact prescribed-kernel fixture: L=2, R=9/5, q=1, lambda=4/3.
# Two beta rows of unit mass; four disjoint receiver intervals of width l.
# Their centers are -19/20,-7/10,7/10,19/20. Inner two capture z~0.
# All source/receiver incidences are constant on positive-volume boxes.
l=F(1,50); R=F(9,5); b=F(2); th=F(99,50)
U=[[F(1,2)]*4,[F(1,2),F(1,2),F(0),F(1,2)]]
c=[0,1,1,0]; H=F(1,40); d=F(3,200)
J=[l*sum(row) for row in U]
A=[l*sum(row[i]*c[i] for i in range(4)) for row in U]
v=[(min(d,Ai)-d*Ai/H)/(Ai*(1-Ai/Ji)) for Ai,Ji in zip(A,J)]
Cv=sum(vi*Ai for vi,Ai in zip(v,A))
Ef=sum(vi*Ai*Ai/Ji for vi,Ai,Ji in zip(v,A,J))
Tent=sum(min(d,Ai)-d*Ai/H for Ai in A)
ck(Cv-Ef==Tent==F(7,1000),"joint_identity")
lowmass=1/R-1/th; topmass=1/th
for h in [F(1,k) for k in (100,125,150,200,250,400,1000)]:
    # For h<=l the area inside one interval with |u-w|<=h is 2lh-h^2.
    neararea=2*l*h-h*h
    Nnear=sum(v[y]/J[y]*sum(U[y][i]**2*c[i]*neararea for i in range(4))
              for y in range(2))
    Nfar=Cv-Nnear
    ck(Tent/R==Tent*topmass+(Nnear+Nfar-Ef)*lowmass,"joint_identity")
    zeta=min(F(1),2*h/H) # q_-=a=1; true full-soft upper bound is 1.
    ck(Nnear<=zeta*sum(A),"near_first_moment")
    # Refined common-receiver projection uses the same low-layer full fields.
    P=F(0)
    for i in range(4):
        mass=l*sum(v[y]*U[y][i] for y in range(2))
        mean=l*sum(v[y]*U[y][i]*A[y]/J[y] for y in range(2))
        P+=mean*mean/mass if mass else 0
    ck(P<=Ef,"joint_identity")
    ck(Tent/R<=Tent*topmass+(Nnear+Nfar-P)*lowmass,"joint_identity")
# A diagnostic whole low energy may exceed a selected local overlap; we
# never infer standalone local loss <= Nfar-P from the preceding identity.
ck(lowmass==F(5,99) and topmass==F(50,99),"joint_identity")

# Exact actual receiver-volume intersection checks in dimensions 1..64.
# U=1 on Q_1(0), so J=1; H<=J and q_-=a=1. No source-density assumption.
for n,h,Hh,center in product((1,2,4,8,16,64),
          (F(1,100),F(1,10),F(1,2),F(3,4)),
          (F(1,100),F(1,4),F(1)),
          (F(0),F(1,3),F(1,2),F(3,4))):
    width=max(F(0),min(F(1,2),center+h)-max(F(-1,2),center-h))
    mass=width**n
    ck(mass<=min(F(1),(2*h)**n),"receiver_volume")
    ck(mass<=min(F(1),(2*h)**n/Hh),"receiver_volume")
print(counts)
print("PASS",sum(counts.values()),"exact Fraction checks")
```

Actual fresh-process execution: PASS, 606 exact Fraction checks: 23 joint-identity/projection checks, 7 near-first-moment checks, and 576 receiver-volume checks. No floating-point or interval claim is involved. No finite diagnostic establishes the missing inequality (16).

Reproduce without creating or modifying any other file:

```sh
python3 - <<'PY'
from pathlib import Path
s=Path("/tmp/r319_geometry.md").read_text()
code=s.split("```python\n",1)[1].split("\n```",1)[0]
exec(compile(code,"r319_embedded_checks","exec"), {"__name__":"__main__"})
PY
```

The original unmatched time/scale branches and complete global entry ledger remain outside this auxiliary improvement and are not discharged by it.
