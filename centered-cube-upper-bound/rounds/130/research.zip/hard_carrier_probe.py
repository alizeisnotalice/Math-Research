"""R130: 12 frozen HC5/HC6/V kernel cases, 30/50 digit observations only.

Uses existing mpmath vendor through PYTHONPATH. No computation at import.
No interval certificate, FIRST/FULL realization, or source-budget conclusion.
"""
from argparse import ArgumentParser
from fractions import Fraction as Q
from pathlib import Path
import hashlib
import json
import sys
import time

N = 6561
DIGITS = (30, 50)
MAXDEGREE = 6
MAX_EVALS = 20000
VENDOR = '/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor'
HERE = Path(__file__).resolve().parent
NOTE = HERE / 'hard_carrier_numeric_note.md'
EXPECTED_NOTE_SHA = '4f4bad3c8d246bd627a7779d440817e9cf49d34df5fbbb6ead5dcc72d985fb85'  # pre-execution frozen note, including V


def sha_bytes(data):
    return hashlib.sha256(data).hexdigest()


def rational(x):
    return {'$q': [str(x.numerator), str(x.denominator)]}


def encode_input(x):
    if isinstance(x, Q): return rational(x)
    if isinstance(x, dict): return {str(k): encode_input(v) for k,v in x.items()}
    if isinstance(x, (list,tuple)): return [encode_input(v) for v in x]
    return x


def group(name):
    gamma = 1 + Q(1,N)
    if name == 'A':
        return dict(group=name,n=N,j=0,gamma=gamma,cj=Q(1),g=Q(1),
                    a=Q(1,2),b=Q(1),L=Q(1),R=Q(1),y=Q(0))
    cj = 1/gamma
    L = (cj+cj/gamma)/2
    R = 1/L
    return dict(group=name,n=N,j=1,gamma=gamma,cj=cj,g=Q(1),
                a=R/2,b=R,L=L,R=R,y=Q(0))


def menu(stage):
    A,B = group('A'),group('B')
    # (ID, group, z, v, zprime, m, physical-softness-formula, theta)
    if stage == 1:
        rows=[(1,A,Q(2),Q(2),Q(-1),1,'near',Q(1,2)),
              (2,A,Q(0),Q(0),Q(0),1,'near',Q(1,2)),
              (3,A,Q(63,64),Q(2),Q(0),2,'near',Q(1,2)),
              (4,A,Q(0),Q(2),Q(2),3,'one',Q(1))]
    elif stage == 2:
        rows=[(5,A,Q(63,64),Q(1,2),Q(2),1,'one',Q(1,2)),
              (6,A,Q(0),Q(1,4096),Q(1,2),2,'one',Q(1)),
              (7,A,Q(0),Q(4),Q(4),3,'near',Q(1,2)),
              (8,A,Q(1,2),Q(-3,4),Q(3,4),1,'very_near',Q(1,2))]
    else:
        L,R,b=B['L'],B['R'],B['b']
        rows=[(9,B,Q(0),Q(1,4096),Q(0),1,'near',Q(1,2)),
              (10,B,(R+L)/2-Q(1,64),2*b,-b,2,'one',Q(1,2)),
              (11,B,R/2,b/2,2*b,3,'very_near',Q(1)),
              (12,B,Q(0),4*b,-4*b,2,'near',Q(1,2))]
    return [dict(**params,id=case_id,stage=stage,z=z,v=v,zprime=zp,m=m,
                 softness=soft,theta=theta) for case_id,params,z,v,zp,m,soft,theta in rows]


def legality(case):
    a,b,L,R,g,cj,gamma=(case[k] for k in ('a','b','L','R','g','cj','gamma'))
    return dict(physical_scale_window=(0<a<=L<=b and a<=R<=b and b<=2*a),
                exact_g_relation=L*R==g*g,
                ratio_band=cj/gamma*g<=min(L,R)<=cj*g,
                original_g_window=a/cj<=g<=b*cj,
                cj_definition=cj==gamma**(-case['j']),
                dimension_at_least_6561=case['n']>=6561,
                softness_structural=(case['softness'] in ('one','near','very_near')),
                theta_range=0<case['theta']<=1)


class BudgetError(RuntimeError):
    pass


class Probe:
    def __init__(self,mp):
        self.mp=mp
        self.evaluations=0
        self.phi_calls=0
        self.phi_cache={}
        self.C_cache={}

    def number(self,q):
        if isinstance(q,Q): return self.mp.mpf(q.numerator)/q.denominator
        return self.mp.mpf(q)

    def string(self,x):
        return self.mp.nstr(x,n=self.mp.dps)

    def phi(self,x):
        self.phi_calls+=1
        r=abs(x)
        if r in self.phi_cache: return self.phi_cache[r]
        half=self.mp.mpf(1)/2
        def E3(a):
            return half if a==0 else self.mp.expint(3,a)
        value=(1-E3(half-r)-E3(half+r) if r<=half else E3(r-half)-E3(r+half))
        if not self.mp.isfinite(value) or value<=0:
            raise ArithmeticError('nonpositive/nonfinite floating original phi')
        self.phi_cache[r]=value
        return value

    def integrate(self,func,lo,hi,cuts):
        if hi<=lo:
            return self.mp.mpf(0),self.mp.mpf(0),[]
        points=sorted({lo,hi,*(c for c in cuts if lo<c<hi)})
        total,error=self.mp.mpf(0),self.mp.mpf(0)
        pieces=[]
        def wrapped(x):
            self.evaluations+=1
            if self.evaluations>MAX_EVALS:
                raise BudgetError('per-case/per-precision integrand request budget exceeded')
            return func(x)
        for left,right in zip(points,points[1:]):
            value,estimate=self.mp.quad(wrapped,[left,right],method='gauss-legendre',
                                        maxdegree=MAXDEGREE,error=True)
            total+=value
            error+=abs(estimate)
            pieces.append(dict(lo=self.string(left),hi=self.string(right),
                               value=self.string(value),quad_error_estimate=self.string(estimate)))
        return total,error,pieces

    def C(self,d):
        if d in self.C_cache: return self.C_cache[d]
        half=self.mp.mpf(1)/2
        def F(u):
            r=abs(u-d)
            return self.mp.mpf(1) if r<=half else self.phi(r)
        result=self.integrate(F,-half,half,[d-half,d,d+half])
        self.C_cache[d]=result
        if result[0]<=0 or not self.mp.isfinite(result[0]):
            raise ArithmeticError('nonpositive/nonfinite floating original C')
        return result


def observe(mp,case,digits):
    start=time.monotonic()
    with mp.workdps(digits):
        probe=Probe(mp)
        val={k:probe.number(case[k]) for k in ('a','b','L','R','g','cj','gamma','y','z','v','zprime','theta')}
        a,b,L,R,g,cj,gamma,y,z,v,zp,theta=(val[k] for k in ('a','b','L','R','g','cj','gamma','y','z','v','zprime','theta'))
        n=case['n']
        lower=1-mp.power(2,-mp.mpf(1)/n)
        soft=(mp.mpf(1) if case['softness']=='one' else lower+mp.power(2,-(24 if case['softness']=='near' else 40)))
        Hq=(case['L'] if case['m']==1 else (min(case['b'],case['gamma']*case['L']) if case['m']==2 else case['b']))
        H=probe.number(Hq)
        kernel_s=mp.mpf(1) if case['m']==3 else soft
        legal=legality(case)
        legal['Hm_in_physical_window']=case['a']<=Hq<=case['b']
        legal['strict_softness_observed']=soft>lower and soft<=1
        output=dict(input=encode_input(case),digits=digits,legality=legal,
                    s_lower=probe.string(lower),s_actual=probe.string(soft),
                    s_margin=probe.string(soft-lower),kernel_s=probe.string(kernel_s),
                    Hm=rational(Hq),status='EXPLORATORY_MPMATH_NOT_INTERVAL')
        if not all(legal.values()):
            output.update(status='PARAMETER_LEGALITY_UNDETERMINED',reason='declared menu failed its structural/observed gate')
            return output
        cv,cv_error,cv_pieces=probe.C(abs(y-v)/b)
        cb,cb_error,cb_pieces=probe.C(abs(y-zp)/b)
        raw_v=b*cv/(cj*g); raw_b=b*cb/(cj*g)
        omega_v=min(mp.mpf(1),raw_v); omega_b=min(mp.mpf(1),raw_b)
        def kernel(u,center):
            radius=abs((u-center)/H)
            hard=mp.mpf(1) if radius<=mp.mpf(1)/2 else mp.mpf(0)
            return ((1-kernel_s)*hard+kernel_s*probe.phi(radius))/H
        Iloq=max(case['z']-case['R']/2,case['y']-case['L']/2)
        Ihiq=min(case['z']+case['R']/2,case['y']+case['L']/2)
        ellq=max(Q(0),Ihiq-Iloq)
        ilo,ihi,ell=probe.number(Iloq),probe.number(Ihiq),probe.number(ellq)
        hard_cuts=[v-H/2,v,v+H/2,zp-H/2,zp,zp+H/2]
        integral5,error5,pieces5=probe.integrate(lambda u:kernel(u,v),ilo,ihi,hard_cuts)
        lhs5=integral5/omega_v; rhs5=cj*g/H; ratio5=lhs5/rhs5
        output.update(C_v=probe.string(cv),C_zprime=probe.string(cb),
             C_error_estimates=dict(v=probe.string(cv_error),zprime=probe.string(cb_error)),
             C_pieces=dict(v=cv_pieces,zprime=cb_pieces),raw_weight_v=probe.string(raw_v),
             raw_weight_zprime=probe.string(raw_b),omega_v=probe.string(omega_v),omega_zprime=probe.string(omega_b),
             I=dict(lo=rational(Iloq),hi=rational(Ihiq),length=rational(ellq),empty=ellq==0),
             HC5=dict(integral=probe.string(integral5),quad_error_estimate=probe.string(error5),
                      lhs=probe.string(lhs5),rhs=probe.string(rhs5),ratio=probe.string(ratio5),
                      ratio_minus_one=probe.string(ratio5-1),observed_le=bool(ratio5<=1),pieces=pieces5))
        if ellq==0:
            output['HC6']=dict(status='N/A_EMPTY_I',hard_anchor_lhs='0',reason='no d or empty-domain 0^0 defined')
        else:
            farq=max(abs(Iloq-case['zprime']),abs(Ihiq-case['zprime']))
            radiusq=farq/Hq
            # Essential infimum is the inner one-sided value at a limiting
            # hard face; exact rational geometry decides the closed hard term.
            hard_far=mp.mpf(1) if radiusq<=Q(1,2) else mp.mpf(0)
            d=(1-kernel_s)*hard_far+kernel_s*probe.phi(probe.number(radiusq))
            if d<=0: raise ArithmeticError('nonpositive denominator essinf observation')
            integral6,error6,pieces6=probe.integrate(lambda u:mp.power(kernel(u,v)/kernel(u,zp),theta),ilo,ihi,hard_cuts)
            lhs6=mp.power(omega_b/omega_v,theta)*integral6/(R*L)
            rhs6a=mp.power(H*omega_b/d,theta)*mp.power(ell,1-theta)*mp.power(cj*g/H,theta)/(R*L)
            m0=min(L,R)
            rhs6b=m0/(R*L)*mp.power(gamma*omega_b/d,theta)*mp.power(ell/m0,1-theta)
            output['HC6']=dict(d=probe.string(d),far_radius=rational(radiusq),
                integral=probe.string(integral6),quad_error_estimate=probe.string(error6),lhs=probe.string(lhs6),
                rhs_first=probe.string(rhs6a),rhs_boxed=probe.string(rhs6b),
                ratio_first=probe.string(lhs6/rhs6a),ratio_boxed=probe.string(lhs6/rhs6b),
                observed_le_first=bool(lhs6<=rhs6a),observed_le_boxed=bool(lhs6<=rhs6b),pieces=pieces6)
        # V uses the FULL hard-z interval, including the HC5-empty case.
        exponent=mp.mpf(1)/2**14
        jlo,jhi=z-R/2,z+R/2
        vcuts=[y-L/2,y,y+L/2,v-H/2,v,v+H/2]
        integralV,errorV,piecesV=probe.integrate(lambda u:probe.phi((u-y)/L)*mp.power(H*kernel(u,v)/omega_v,exponent),jlo,jhi,vcuts)
        V=integralV/min(L,R); target=mp.mpf(63)/64
        output['V']=dict(exponent=rational(Q(1,2**14)),J_lo=probe.string(jlo),J_hi=probe.string(jhi),
                 value=probe.string(V),target=rational(Q(63,64)),ratio=probe.string(V/target),
                 observed_le=bool(V<=target),quad_error_estimate=probe.string(errorV/min(L,R)),pieces=piecesV,
                 interval_certificate=False)
        output.update(integrand_requests=probe.evaluations,phi_calls=probe.phi_calls,
                      elapsed_seconds=f'{time.monotonic()-start:.3f}',interval_certificate=False,
                      FIRST_FULL_or_root_claim=False)
        return output


def compare(mp,observations):
    if len(observations)!=2 or any(o.get('status')!='EXPLORATORY_MPMATH_NOT_INTERVAL' for o in observations):
        return dict(status='NOT_COMPARABLE',reason='one or both precisions failed/not applicable')
    lo,hi=observations
    with mp.workdps(50):
        result={}
        for label,path in [('HC5_ratio',('HC5','ratio')),('V_ratio',('V','ratio')),
                           ('HC6_first_ratio',('HC6','ratio_first')),('HC6_boxed_ratio',('HC6','ratio_boxed'))]:
            if all(path[1] in o[path[0]] for o in observations):
                result[label+'_50_minus_30']=mp.nstr(mp.mpf(hi[path[0]][path[1]])-mp.mpf(lo[path[0]][path[1]]),50)
            else: result[label+'_50_minus_30']=None
        result['interpretation']='finite precision difference only; not interval error or analytic certification'
        return result


def main():
    parser=ArgumentParser(description=__doc__)
    parser.add_argument('--stage',required=True,choices=('1','2','3','all'))
    parser.add_argument('--output',type=Path)
    args=parser.parse_args()
    try:
        import mpmath as module
        if module.__version__!='1.3.0' or not Path(module.__file__).resolve().is_relative_to(Path(VENDOR)):
            raise RuntimeError('expected existing mpmath 1.3.0 vendor')
        if not NOTE.exists(): raise RuntimeError('frozen note missing')
        note_bytes=NOTE.read_bytes()
        if EXPECTED_NOTE_SHA is not None and sha_bytes(note_bytes)!=EXPECTED_NOTE_SHA:
            raise RuntimeError('pre-execution frozen note SHA mismatch')
    except Exception as error:
        print(json.dumps(dict(status='ENVIRONMENT_ERROR',error=str(error))))
        return 2
    stages=(1,2,3) if args.stage=='all' else (int(args.stage),)
    cases=[case for stage in stages for case in menu(stage)]
    result=dict(header=dict(version='R130-hard-carrier-v1',case_count=len(cases),digits=DIGITS,
                 maxdegree=MAXDEGREE,max_integrand_requests_per_case_precision=MAX_EVALS,
                 python=sys.executable,python_version=sys.version,mpmath_version=module.__version__,
                 mpmath_path=module.__file__,code_sha=sha_bytes(Path(__file__).read_bytes()),
                 frozen_note_sha=sha_bytes(note_bytes),frozen_note_text=note_bytes.decode('utf-8'),
                 interval_certificate=False,FIRST_FULL_or_root_claim=False),cases=[])
    failures=0
    for case in cases:
        observations=[]
        for digits in DIGITS:
            try:
                observation=observe(module.mp,case,digits)
            except Exception as error:
                failures+=1
                observation=dict(input=encode_input(case),digits=digits,status='EXCEPTION_PRESERVED',
                                 error_type=type(error).__name__,error=str(error),interval_certificate=False)
            observations.append(observation)
        result['cases'].append(dict(id=case['id'],stage=case['stage'],input=encode_input(case),
                    observations=observations,precision_comparison=compare(module.mp,observations)))
    result['summary']=dict(case_count=len(cases),observation_count=2*len(cases),exceptions=failures,
                stages=stages,no_menu_expansion=True,no_bound_clipping=True,
                interval_certificate=False,FIRST_FULL_or_root_claim=False)
    serialized=json.dumps(result,ensure_ascii=False,indent=2,sort_keys=True)
    if args.output:
        args.output.write_text(serialized+'\n',encoding='utf-8')
        print(json.dumps(dict(status='SAVED',output=str(args.output.resolve()),**result['summary'])))
    else:
        print(serialized)
    return 1 if failures else 0


if __name__=='__main__':
    sys.exit(main())
