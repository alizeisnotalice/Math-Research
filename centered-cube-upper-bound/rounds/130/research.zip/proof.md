# 附件：main_integration.md

# 第130轮：共同来源几何与共同阈值积分

一般中心立方体极大算子 n^(1/2+o(1)) 一致弱型上界仍未闭合。原非负L1、真实接收Lebesgue测度、任意维度及全尺度要求不变；没有将局部恒等式或条件几何表示列作一般付款。

## 本轮相对于上轮的改变

R129的移动尺度面积桥需要另核临界接收集合是否携带原质量。本轮使用真实ν_C≤f dx和固定参考尺度的共同退出测度，证明退出位置在积分初始来源标签后具有全维绝对连续边缘。在尺度图局部Lipschitz且不依退出来源标签时，固定接收点的临界来源位置为仿射超平面，故联合原交通临界质量为零。该结论不能在固定初始y后套用：那时退出位置仍可能在一条轴线上。

即使实际尺度仅可测，也可先对来源w做逐接收点的非退化仿射变换，消去核的尺度归一化，完整保留接受加权截面积分。这不需要除以接收Jacobian；但它并未减小未知积分。剩余定量目标是IS10的E加权来源截面预算，尚未证明FIRST能提供该预算。当前signed余项与旧early交通接口的识别仍未完成。

来源联合倾斜保留eta=theta可消去p和K的纯幂，却不会自动支付逆权。若把双门全部删除，同Π下完整成对矩为E R^theta E R^-theta≥1（由Cauchy，或对称cosh表达）；因此不能将该无门矩声称为捕获增益。来源权只取Jensen与theta≈1/log(M/e)会同时削弱good门，仍须联合付费。

主代理提出共同log K随机化，由作者/独审核其准确成对门平均；不是逐source挑K。必须保留原high的截断、终端来源子概率平方、Ψ补域及已消费N_Z的位置。旧α²dθ/删除变差账已经存在，不能改名重记新付款。共同K在整算法上的可测选择及统一价格亦未获一般证明。

## 技能和证据边界

读取更新D04与N04的主说明、课题接口及来源记录的相关部分，仅使用共同联合参考的链式条件、明确的有限求和和误差预算要求。没有声称本轮阅读其所有外部论文，也不把技能名当作来源预算定理。

保留原N_Zc与Ndel各一次，已消费N_Z不返还；β−ν、硬z、ν³/e_t²、所有history/尺度费用不删。局部Lipschitz本身不由FIRST保证；绝对连续性不给任意近临界厚度的维数一致速率。

## 未解决的主目标

需要新的定量几何或共同来源估计支付IS10，或直接支付RT2/3完整signed槽。只换积分顺序、给核积分有限性、阈值平均或固定尺度预算均不够。继续研究应针对这一个全局预算，避免将新符号当作闭合。

本轮复用现有Agent，未运行域外低维物理菜单。实际额度无法按模型/子任务精确分拆，不猜成本比例。所有最终数值与独审状态以相应附件为准，不编译PDF。

## 保留硬载体的新核估计

HC5对原真实核及全部合法尺度证明 ∫_I k_m(x−v)dx/ω(v)≤c_jg/H_m，其中I是hard y与hard z区间的交。HC6由此抵消good端的C逆权，比例带费用跨n坐标仅为γ^{nθ}≤exp(θ)。这属于原p_s乘积分解中的hard-anchor项，并非把s设为0；所有soft-anchor项仍保留。bad端局部逆核及score未获得共同来源价格。核引理是新增可用工具，不能独立视为实际付款分支。

## 已执行的精确验证

共同阈值公式采用Fraction三阶段4/6/6共16例。独立折点积分oracle给561个成对残差为零；12个有定义的无mask协方差核对一致，2个mask及2个零终端质量例正确不套协方差。主代理在隔离目录恢复执行前协议后复现，完整JSON一致。高整数score仅为代数压力，未称高维原核、FIRST或一般费用证据。归档仅保留代码和精简结果；全量可重建段表留在本地。

## 从hard-anchor到全部混合分量的扩展

主代理提出并由作者独立复核的soft-anchor引理采用θ0=2^-14、κ=63/64。其核心是在完整hard-z窗口J上证明

\[
\frac1{\min(L,R)}\int_J \phi((u-y)/L)
 \left[\frac{H_m k_m(u-v)}{\omega(v)}\right]^{\theta_0}du\le\kappa.
\]

证明方向利用φ≤F≤4φ、已审logφ的4-Lipschitz性和φ的指数矩；θ=0窗口软质量已有统一缺口，正小幂扰动用全线矩控制。全部常数由解析不等式产生，不靠有限数据拟合维数阶。最终证明独审通过并绑定作者稿SHA；详见独审附件。

合并HC7时必须将bad分母改为完整J上的essential infimum；在hard交区I上的下界不能用于soft积分。这个更弱分母会被如实保留。最终核验已通过，混合系数按坐标乘积可给exp(θ0)exp(−ns/64)，从而对原正软度完整混合分量抵消good逆权；bad来源费用、接收自适应、δ及外层积分仍未支付，不能仅从这一指数因子宣称一般上界。

## 真实核数值观察

冻结菜单三阶段4/4/4共12例，各30与50位，单进程24条观察完成、退出0且无异常。HC5最大比值1；非空HC6两层比值均不超过1。完整J的SA2左侧除以63/64最大约0.513663。30/50位比较最大差约7.62e-19，积分程序误差估计最高约1.01e-12；二者都不是区间证书。采用本机既有mpmath1.3.0和冻结代码/协议，无额外扩大菜单；不认证FIRST、完整交通可实现性或根阶总预算。


# 附件：TASK_CONTEXT.md

# R130：联合来源预算，不展开特殊族

一般目标仍任意非负L1的中心cube弱型n^(1/2+o(1))；R129已推送41bba3c，无新增一般付款。原定义严格继承R129/TASK_CONTEXT.md及R128 joint_receiver_tail.md §1–2。此处所有路径前缀为 /Users/zhengzhihao/Desktop/T/output/centered_cube_roundNNN_20261014/（R128/129同日期）。本轮只写分配的scratch文件，不Git/PDF、不覆盖他人。

准确待付RT2/3：外层真实dT=q^-1 p(x,y)h_R(x-z)a_history dx dβ(y)dν(z)，期望ΣV,j；内层∫dt/t ∫Dg×Sg Ψ{χ_FA ρ[k(v)−k(z')]_+−[k(z')−k(v)]_+} dΠt(z')dΠt(v)，另Ndel一次。Ψ=1_Zcal^c，N_Z已消费不可取回。Πt=e_t^-1 1_Zt w_tν；固定ω,V,j,y,t后Πt不依x，Dg/Sg及g/RC/history依x。源质量β−ν、硬z不删。

R129联合矩MR4–14通过独审，条件可积域eta≥0,xi<1/2不能替代root价格。good倾斜产生w_g(v)^-theta，bad产生w_g(z')^eta；同源双门不可分开后假称费用可控。θ∈(0,1]、η≥0、ξ≥0，Q*为三个整维核和。αrec(x)一般不冻结，合法α_-=0丢捕获收益。自适应x核费用未付。

初始代数检查（不登记新进展）：M=ν(Zt)>0,e=∫Zt wtν，0<e≤M，Jensen给 e^-1∫wt^(1−θ)dν≤(M/e)^θ。θ≈1/(1+log(M/e))只控制孤立负权，会削弱good倾斜；必须联合分析。保留η=θ时来源对的权比，而非分别使用最坏值。未知是否能被原负项支付；不能随意补N_Z或改变Ψ。

允许工具：已审MR4–14、RT4Πt、有限Tonelli/Holder/Jensen，实际核φ~2sinh(.5)e^-r/r；D04共同联合分布KL链式、N04有限望远镜且误差预算必须明确。严格soft s>1−2^-1/n，原n门及FIRST/history不能删。

任务先准确命题/量词再证明。局部恒等式或条件桥若无全局收益明确标记，不把余项改名当进展。不做一般性长反例搜索。数值必须有原对象、初探/压力/扩大及复现，域外低维不承担原高维策略判断。


# 附件：integrated_scale_geometry.md

# R130：共同来源积分下的临界质量与移动尺度负载

**准确交付。** 在 R129 MB2 的原共同早首跳来源中，ν_C≤f dx 使退出位置 w 的边缘绝对连续。由此可证明：若实际 L(x,θ) 局部 Lipschitz 且不依赖退出来源标签，则径向 Jacobian 恰为零的原联合交通质量为零；无需逐标签假设接受权在临界域消失。仅要求 L 可测时，还可先对共同来源 w 变元，得到不含 Jacobian 除零的完整积分表达。

这些结论不提供近临界负载的统一价格，也不证明 FIRST 产生 Lipschitz 尺度图。**一般根阶付款仍未得到。** 本稿不要求 sup 反像帽，不删除原临界域，不以一份测度恒等式登记新付款。

## 1. 原接口及先行命题筛查

沿用 `R129/moving_scale_bridge.md` MB1–5，维数与接入旧早首跳账的范围仍由该接口规定；n<512 的回退不由本稿支付。固定原 f≥0、W=∥f∥₁<∞、θ、共同参数 a≤b≤2a，以及同一次来源分配 ν_C≤f dx。原实际 L=L(x,θ)∈[a,b]，不随退出 w、初始 y 或其余来源标签重新选择。

保留原共同测度 \(\bar\kappa\) 的全部标签 ζ、真实接受权 a_ζ(x)∈[0,1]、原硬源积分与 history。已审接口是
\[
\mathcal R_{early}^{act}
\le C_h\int d\bar\kappa(\zeta)\int a_\zeta(x)
J_{\sigma(x),t,L(x)}(x-w)\,dx,
\qquad C_h=16/3,
\qquad\|\bar\kappa\|\le2W.
\tag{IS1}
\]
a_ζ 仍包含 t≤σ、G_L/(2G_b)、h_R/q、出生/live、原 x,y,z/history 等限制。此处不重新判定这些门，也不把 MB1 之外的 signed 存活余项自动认作 IS1。

按固定参考尺度 b 的已审软时间包络，记
\[
\mathcal E_t(v)=E_{t,b}(v)\ge0,
\qquad \int\mathcal E_t(v)\,dv=D_n,
\qquad D_n\le1+\frac\pi2\sqrt n.
\tag{IS2}
\]
令 h_θ(x)=L(x,θ)/b∈[a/b,1]。核缩放给需要控制的正上界
\[
\mathcal I=
\int d\bar\kappa(\zeta)\int a_\zeta(x)h_\theta(x)^{-n}
\mathcal E_t\!\left(\frac{x-w}{h_\theta(x)}\right)dx,
\qquad \mathcal R_{early}^{act}\le C_h\mathcal I.
\tag{IS3}
\]
目标是控制这个 E 加权积分，而非先要求每个 ζ 的反像数或其加权帽一致有界。

## 2. 共同退出位置确有绝对连续边缘

**命题 1。** 固定 θ、t，先对 MB2 的初始 y、格 C、坐标 i 等来源标签积分后，w 边缘有密度 ρ_{θ,t}(w)。同时
\[
\int d\mathbb P(\theta)\int dt\int\rho_{\theta,t}(w)\,dw
=\|\bar\kappa\|=:M\le2W.
\tag{IS4}
\]
若原记录另带限制，以下密度表达对应其上方共同 measure；对实际子测度仍成立绝对连续性和质量帽。

证明：写 dν_C(y)=f_C(y;θ)dy。MB2 中 w_{−i}=y_{−i}，但 y_{−i} 本身按 Lebesgue 密度积分。非负 Fubini 给
\[
\begin{aligned}
\rho_{\theta,t}(w)
={}&2(1-t)^{n-1}1_{\{0\le t<\min(T_n,1/2)\}}\\
&\times\sum_{C,i}1_{\{w_i\notin C_i\}}
\int_{\mathbb R}G_{1-t,b}(w_i-y_i)
f_C(y_i,w_{-i};\theta)\,dy_i.
\end{aligned}
\tag{IS5}
\]
这是原共同来源的边缘公式，未复制任何 L 或 history 的源质量。IS4 继承 MB3。

这里不能声称“固定全部 ζ 标签后 w 仍有 n 维密度”：保留固定 y 时，w_{−i}=y_{−i} 仍是奇异约束。绝对连续性只在先共同积分这些标签后使用。有限 L¹ 输入在此有实质作用，而不仅是 M≤2W 的数值帽。

完整接受权可以保留在一个共同可测密度中。定义 H_{θ,t}(x,w)，使
\[
H_{\theta,t}(x,w)\,dx\,dw
=dx\int a_\zeta(x)\,\bar\kappa_{\theta,t}(d\zeta)\,\delta_{w(\zeta)}(dw),
\qquad 0\le H_{\theta,t}(x,w)\le\rho_{\theta,t}(w).
\tag{IS6}
\]
该联合密度由右侧对 dx ρ(w)dw 的支配得到；可先在有限 x 与标签截断上构造，再一致扩展。它是保留所有原 marks 的接受加权析出，不能被一个重新选择的裸来源密度替代。

## 3. 恰临界域的联合原质量为零

**命题 2。** 另假定原 L(x,θ) 局部 Lipschitz，且仍不依来源标签。定义其几乎处处导数及
\[
\Delta_\theta(x,w)
=1-(x-w)\cdot\nabla_x\log L(x,\theta).
\tag{IS7}
\]
那么 \(\{\Delta_\theta=0\}\) 在原 dx d\barκ 下为零测集，在 IS3 的接受加权交通下也无贡献。

证明先固定一个可微的 x、θ。若 ∇log L=0，则 Δ=1，没有临界位置。若 ∇log L≠0，则 Δ=0 等价于 w 落在一个仿射超平面。由命题 1，该超平面的共同 w 边缘质量为零。再对 x、θ、t 用非负 Tonelli；不可微的 x 集为零测，亦没有联合交通。因此先保留整个临界域再共同积分，得到其质量严格为零。

乘上 IS3 的非负核因子不会使零测集产生质量。等价地，按原标签重新析出后，对 \barκ-几乎处处 ζ，临界接受域的原 dx 贡献为零。这个结论改善了 MB 对临界域的独立假设，但**没有**提供实际 L 的 Lipschitz 性、非临界反像帽或任何近临界衰减速率。

近临界集合 {|Δ|≤δ} 在有限正交通截断上随 δ↓0 的质量趋零，但该结论没有依 n 的统一 δ—费用关系。不能选择一个未经证明的 δ≈1/polylog(n)，再把 |Δ|^{-1} 当成已付常数。若采用更一般、未必来自 ν_C≪dx 的出口测度，命题 2 不能仅凭其总质量帽沿用。

## 4. 仅可测尺度下的完整积分几何表达

**命题 3。** 不需要命题 2 的 Lipschitz 假设。只要实际 L 可测、a≤L≤b，IS3 精确等于
\[
\boxed{
\mathcal I=
\int d\mathbb P(\theta)\int dt\int\mathcal E_t(v)
\,\mathcal G_{\theta,t}(v)\,dv,
\qquad
\mathcal G_{\theta,t}(v)
=\int H_{\theta,t}\bigl(x,x-h_\theta(x)v\bigr)\,dx.
}
\tag{IS8}
\]
证明在 IS3 中先使用 IS6，然后固定 x、θ 作来源变量的仿射变换
\[
w=x-h_\theta(x)v,\qquad dw=h_\theta(x)^n dv.
\tag{IS9}
\]
它在每个 x 上均非退化，与核因子 h^{-n} 恰好配平。非负 Tonelli 即给 IS8；没有对接收变量 x 使用面积公式，也没有除以 Δ。原临界域全部留在此变元内。

H 取共同可测的联合密度版本。对不同版本，差异为 dx dw 零集；固定 x 的 IS9 把它变成 dx dv 零集。因此 \(\mathcal G\) 只需在几乎处处 v 上解释，IS8 不依赖版本。不能任意规定 H 在某个单独斜截面上的值后声称对每个 v 有同一结论。

这个式子正是要求保留的 E 加权负载，而不是 sup_v G。原接受权、硬源、σ 和全部 history 仍在 H 的原 x 处求值；没有在新 v 处重判 FIRST。共同质量 M 只在 IS4 使用一次。

在命题 2 的正则条件下，IS8 也等于先按每个 ζ 使用 MB12 的正则反像密度，再共同积分所得的
\(\int d\bar\kappa(\zeta)\int E_{t,b}(u-w)\mathcal B_\zeta(u)du\)。这不是为每个 ζ 强制一个 B_n 帽；临界项的缺失由命题 2 的联合零质量证明承担。仅可测尺度则直接使用 IS8，无须先建立该反像表示。

## 5. 具体未证项与停止范围

IS8 已把潜在的 Jacobian 奇异表示换为一个无除零的接受加权来源截面积分。**它没有减小未知交通的总量。** 为通过此路线支付早首跳部分，仍需从原 FIRST 及其与 H 的实际关联证明，例如
\[
\boxed{
\int d\mathbb P(\theta)\int dt\int
\frac{\mathcal E_t(v)}{D_n}\,
\mathcal G_{\theta,t}(v)\,dv
\le C(1+\log n)^A M.
}
\tag{IS10}
\]
若 IS10 得证，才有
\[
\mathcal R_{early}^{act}
\le2C_h C(1+\log n)^A D_n W.
\tag{IS11}
\]
此处列出的是准确待证估计，不是本稿假定成立的新条件付款分支。

已知 H≤ρ 与 ∫ρ=M 只控制固定来源位置上的质量；IS8 取的是 w=x−h(x)v 的联合截面，不能把对 w 的积分帽直接套到它上面。正接受权可能压低该截面，但必须使用它与同一原 f、FIRST 参数接触以及 hard/history 的实际联系。当前没有给出这种定量估计。

FIRST 的参数最优性并未在本稿变成 IS10：即使附加足够光滑性，内点物理尺度的驻点条件会令接触等式的一阶 ∇L 系数为零；要获得量化尺度几何，仍需另证曲率、混合导数或某种接受加权积分控制。实际合同也未承诺 L 的正则性。本稿不以这项一阶观察否定更深的 FIRST 推论，只是不将未证推论当作已付量。

**结果范围。** 新证明的控制是：真实共同 L¹ 来源使恰临界联合质量为零；来源积分还允许在仅可测实际尺度下完整保留 E 加权负载，无面积公式除零。尚无对近临界/多反像交通的维数统一费用，IS10 未证，所以没有新增一般根阶付款。旧 R129 MB 到早首跳交通的接口仍完整保留；本稿没有把它自动接到 R130 的全部 signed 余项，也不复用任何负项。没有新的已冻结量化猜想可供数值验证，因此不运行数值、不扩自由尺度反例，完成后停止。


# 附件：source_ac_geometry_audit.md

# R130 共同退出来源的AC与几何零集：先行独立接口审计

SOURCE_AC_STATUS: PASS_WITH_STATED_LABEL_QUANTIFIERS
CRITICAL_MASS_STATUS: PASS_CONDITIONAL_ON_SOURCE_INDEPENDENT_LOCALLY_LIPSCHITZ_L
MEASURABLE_SOURCE_CHANGE_STATUS: PASS_FOR_JOINT_INTEGRALS
ROOT_BUDGET_STATUS: UNPROVED

本稿先核父任务给出的命题，未读取新作者证明。必要原件仅用R130 TASK_CONTEXT、R129 moving_scale_bridge MB2/3/5及已审旧首跳测度：ν_C=f_C(y)dy、Σ_Cν_C≤fdy，一次共同参考b及首跳密度(1−t)^{n−1}G_{1−t,b}。这里审真实dx与共同退出来源接口；没有把当前ν³/e_t² signed槽识别为旧early交通。旧实际FJL范围n≥512及小维回退保留。

## 1. 固定θ,t后的w边缘确为全维AC

取联合可测版本f_C(θ,y)≥0，及C/i等可数原标记。若给定的是随机测度ν_{θ,C}而非密度，由其被同一fdy支配，在dP(θ)dy层取联合RN密度，不对每个θ各选互不兼容版本。记κ_{θ,t}为下述**有限测度而非条件概率**：

\[
2(1-t)^{n-1}\sum_{C,i}1_{w_i\notin C_i}
G_{1-t,b}(w_i-y_i)\,dw_i\,
\delta_{y_{-i}}(dw_{-i})\, f_C(\theta,y)dy,
\]

时间窗口及其余可测固定来源资格可附指示或保留在接受权，均不增质量。对非负可测ψ(w)，先用δ代w_-i=y_-i，再对dy_i dw_i dy_-i使用Tonelli，可得

\[
\int\psi(w)d\kappa_{\theta,t}
=\int\psi(w)r_{\theta,t}(w)dw,
\quad
r_{\theta,t}(w)=2(1-t)^{n-1}\sum_{C,i}1_{w_i\notin C_i}
\int G_{1-t,b}(w_i-y_i)f_C(\theta,y_i,w_{-i})dy_i.
\]

因此对dP(θ)dt几乎处处θ,t，w边缘≪Lebesgue。Σ_Cν_C≤f及G概率性给 `∫r_{θ,t}≤2n(1−t)^{n−1}W`；积分原early窗≤2W。零质量切片直接零，不归一化；没有为每个i/C/L另领W。若以κ投影到θ,t的测度表达“几乎处处”，同样成立。附额外来源mark时可以用原边缘支配，不要求源对/坐标独立。

**不能强化成：固定y,C,i等全部ζ后w仍全维AC。** 此时w_-i=y_-i，条件分布在一条轴上；对于n>1它是奇异的。全维AC利用了原ν_C的dy质量并积分原y标签。若ν_C只是允许原子的有限测度，此结论一般失败；当前真实L¹密度假设不可省略。

## 2. 临界原质量：联合零集的准确Fubini证明

假设L=L(x,θ)>0，联合可测，且对几乎处处θ在接收开域局部Lipschitz；它不依退出点w及其他参与来源混合的隐含标记。梯度可用可测差商极限取共同版本，可微性失败集在dP(θ)dx层为零。原尺度a≤L≤b提供严格正界。

固定一个可微x,θ，令g=∇logL(x,θ)。若g=0，则Δ=1，无临界点；若g≠0，则

\[
\{w:\Delta(x,\theta,w)=0\}
=\{w:w\cdot g=x\cdot g-1\}
\]

为Lebesgue零超平面。由上一节w边缘AC，该集合对κ_{θ,t}为零；此时已经积分原y/C/i标记。非负Tonelli给

\[
\int dP(\theta)dt\int dx\int d\kappa_{\theta,t}(\zeta)
1_{\{\Delta(x,\theta,w(\zeta))=0\}}=0.
\]

同理不可微集的联合质量为零。于是对共同κ几乎处处ζ，临界x集dx零；任何可测非负实际接受/核权乘上该指示仍无贡献。R129 MB临界原质量可以在这些假设下自动消失，不再需要独立证明接受权在临界点逐点等于0。它给的是a.e.质量结论，不是每个w/ζ逐点结论；保留原y的奇异条件测度不影响已证联合零集。

**尚未解除：** FIRST没有给实际L局部Lipschitz；也没有给反像和Σa/|Δ|帽、近临界|Δ|很小的量化或polylog价格。若L依w或隐含来源标记，不能固定x把其梯度当不随来源变化的常向量，这个超平面证明失效。若来源本身随x重新构造，亦不能使用同一dx⊗κ的Fubini。只在部分标签/接收域证正则，则只解除该部分临界质量，其他部分原位保留。

## 3. 仅可测L时按源变量换元：精确联合恒等式

不要求∇L。取L(x,θ)为严格正有限的联合可测函数，不依w/被积分原mark；固定b>0，σ(x,θ)、t为同形核的合法参数。设a_ζ(x)∈[0,1]共同可测，核对mark的依赖仅通过w和已固定θ,t。令联合接受测度

\[
dx\int a_\zeta(x)d\kappa_{\theta,t}(\zeta)\,\delta_{w(\zeta)}(dw)
=H_{\theta,t}(x,w)\,dx\,dw,
\quad 0\le H_{\theta,t}(x,w)\le r_{\theta,t}(w)\quad\text{a.e.}
\]

H须在dP(θ)dt dx dw层选共同RN可测版本，而非先对每个x取任意截面密度。若要写H=r∫a dκ(mark|w)，须有标准Borel标签及合法可测disintegration；固定原y并不能代替该条件核。直接使用上述联合RN定义已足够，不必另假定来源mark独立。

同形核满足 `J_{σ,t,L}(x−w)=L^{−n}j_{σ,t}((x−w)/L)`。在固定x,θ,t对w作普通仿射变元 `w=x−L(x,θ)v/b`，dw=(L/b)^n dv，准确得到非负扩展积分恒等式

\[
\int dx\int H_{\theta,t}(x,w)J_{\sigma(x,\theta),t,L(x,\theta)}(x-w)dw
=\int dv\int dx\,
J_{\sigma(x,\theta),t,b}(v)
H_{\theta,t}\left(x,x-\frac{L(x,\theta)}b v\right).
\]

它只对固定x的w仿射变元，不使用x尺度图Jacobian或临界Δ。σ/t若还有源mark依赖，须保留在联合条件核中，不能强写成此共同J；真实同形关系亦须原核认证。θ,t外层继续Tonelli，不复制共同来源。

版本独立性也在联合层成立：H两个版本的差异对dx dw零，由Fubini对dx几乎处处x的w差异集为零；固定这样的x，严格正L的仿射变元保持w/v零集，故拉回差异对dx dv零。再Fubini，图上x积分只对dv几乎处处v定义。**不能对任意固定v、任意固定x/θ/t取一个未定截面版本的点值，不能将该图值宣布逐点成立。** 此法不证明图负载 `∫H(x,x−L(x)v/b)dx` 有有限统一帽；等式甚至可两侧同为∞。

## 4. 对接与停点

已向adaptive_joint_audit_resume发送上述独立筛查；其反馈使用相同联合H≤r定义，明确仅积分原y/C/i后w AC、图公式只a.e.v及共同版本、临界零集依来源无关局部Lip L。尚未读取其新作者文件，故无作者证明/hash复审结论。

**本接口核准：真实L¹共同首跳来源的w边缘AC；在来源无关局部Lip尺度下临界联合质量自动为零；仅可测正尺度下按w变元的联合积分恒等式。** 实际L正则、反像/图负载根阶预算、当前signed剩余识别及FULL新覆盖均未证。原N_Zc/N_del各一次、RC/SP/MA价格和外层截断限制不改变。到此停止等待后审。

## 5. 冻结作者稿的增量证明复核

FINAL_PROOF_AUDIT_STATUS: PASS_FOR_AC_CRITICAL_NULLITY_AND_JOINT_IDENTITY
IS10_STATUS: UNPROVED
NEW_ACTUAL_PAYMENT_STATUS: NONE

先行筛查和对接完成后才读取 `integrated_scale_geometry.md`。最终实读、复核SHA-256：`1ac817a717bcd18a8edc7b596c1c7b30cc78eafe034125381cf3c05095eceba3`。不修改作者文件；以下仅复核新增声明和证明，不重新检索旧历史。

1. **IS4–5的显式密度PASS。** 时间窗、因子2(1−t)^{n−1}、退出指示、G密度及f_C(y_i,w_-i;θ)的dy_i积分均与原κ一致，C/i只求和一次。IS4总质量继承同一MB3≤2W。第47、62行准确区分共同测度及其子测度，未把固定原y后的轴条件测度当全维AC。量词应按共同RN/Fubini的标准意义读为dP(θ)dt几乎处处切片；不是对任意人为指定的零质量/异常θ,t版本逐点认证。零质量切片取零即可，不归一化。

2. **IS6的联合接受密度PASS。** 由a≤1，接受加权联合测度被dx ρ(w)dw支配，可在dP(θ)dt dx dw的共同σ有限层取RN版本H；有限x截断可一致扩展。H≤ρ仅a.e.，允许不整合任何未认证mark|w条件核。作者明确H保留全部原marks而不是重选裸来源。κ与L没有因接收x重新构造，原σ/t/history仍在a/H的原x处。

3. **IS7临界零质量PASS，仍是条件正则结果。** 第9、75行明确L不依w、原y及其他来源标签。固定可微x后非零梯度给w超平面，零梯度给Δ=1；先积分原标签的AC足够。对不可微集、θ/t及x用Tonelli，得到联合dxκ零，再析出κ-a.e.ζ的dx零集。乘任何非负核因子仍无质量。第85、87行没有把它升级为FIRST给Lip、近临界统一速率或反像帽；有限正交通截断的近临界质量随δ↓0趋零也正确，但不提供可按n选择的δ价格。

4. **IS8–9精确联合换元及版本边界PASS。** h=L/b∈[a/b,1]，在固定x的源仿射变元dw=h^n dv恰好消去h^{−n}；无x导数，无Δ分母。第110行“固定x”按Fubini须读为几乎处处x：两个H版本差异对联合dx dw零，对a.e.x仿射保零，故拉回对联合dx dv零，G只对dv几乎处处解释。作者明确禁止单独斜截面任意赋值后声称每个v有效，IS8外层E加权积分确不依版本。第114–115行在来源无关局部Lip条件下的反像表达也成立：对IS3的E上包络用面积公式是等式，临界项由本稿联合零集消失；不把原J≤E的不等式反写成等式。

5. **IS10–11预算范围PASS；费用未证。** IS10明确只列待证的E_t/D_n加权图负载预算，不取sup_v G，也未从H≤ρ或M≤2W推出它。若未来IS10成立，IS1、IS3、IS8及M≤2W确给IS11的2C_h C polylog(n)D_n W，C_h和M各使用一次。现在IS10没有证明，IS11仅条件推论，不登记实际价格。第20、141行明确没有将旧early接口自动接入本轮全部ν³/e_t² signed余项，不复用负项，旧n≥512及小维回退也保留。

**最终复核结论：作者冻结稿与先行独审在正确a.e.切片/共同可测版本量词下吻合；AC、条件临界零质量和源变量联合恒等式PASS。** 实际Lip、近临界/反像/图负载的统一费用、IS10及当前signed剩余识别仍未证。原账不变；绑定上述最终SHA后停止。


# 附件：joint_source_budget.md

# R130 联合来源检查点：共同阈值平均的精确接口

**状态：证明了共同 log 阈值平均的行内恒等式；未证明新的根阶来源预算，也未认证可将整个原算法的 K 替换为随机 K。** 当前停点是 JSB8 的显式联合剩余，以及所有原 K 相关价格的一致性。矩可积和旧 SO 端点式不能免费支付它们。

定向查重依据：R130 `signed_transport_history.md`（SHA256 `8c8f26d5a81b25d26ac3460d59065999a6bd03d249708437bab6d141ddff91b4`），以及 R118 `causal_audit.md` A2/A4、R121 `signed_outside_progress_private.md` SO5–12、R122 `weighted_suffix_integration_private.md`。全补集协方差、终端子概率 BV 式及其余来源误差均是旧工具。定向检索未定位到下述共同 log K 平均的已审付款结论，不声称全历史不存在。

## 1. 原对象与范围

保留任意原合法输入、整数 n、严格 `s>1−2^(−1/n)`、原 FIRST/FULL/history、同一点上的自适应尺度与软度。固定实际行 `(ω,V,j,x,y,z,g)`，记

\[
p=P_{s,L}(x-y),\quad Q(\xi)=Q_x^*(\xi)
 ={P_{s,L}(x-\xi)+P_{s,L^+}(x-\xi)+P_{1,b}(x-\xi)\over3},
\quad L^+=\min(b,(1+1/n)L).
\]

三个整维乘积之和没有改成逐坐标混合。沿原

\[
d\Pi_t(\xi)={1_{Z_t}(\xi)w_t(y,\xi)\over e_t(y)}d\nu_V(\xi),
\quad e_t=\int_{Z_t}w_t\,d\nu_V,\qquad
-\partial_{\log t}w_t=k_tw_t.
\tag{JSB1}
\]

取原非空完整远窗 `[τ,h]`，`h=g exp(−u/n)`，且 `Z_g⊂Z_t`、`e_t≥e_g>0`。实际 heavy 条件保证整窗合法。空窗整行取零；后缀步骤不得改用任意时间子窗。有限 ν、`0≤k_t≤n` 和有限对数窗保证逐行 signed 积分绝对收敛；全局使用保留整条行内窗的共同有限外层截断。

原 C 严格正，故有限位置处 `w_g>0`；合法 s>0 使 p、Q 严格正。定义真实比

\[
\mathcal R(\xi)={Q(\xi)\over p w_g(\xi)}.
\tag{JSB2}
\]

此 ℛ 不代表硬尺度 R。来源坐标无独立性假设。RC 的 `α_rec(x)`、`Q_J=0`、`A=0`、硬 B 和 shared-low 约定全部保留，不冻结 α_rec。

MR4 的 η=θ 共同倾斜为

\[
H_\theta(z',v)=\left({\mathcal R(v)\over\mathcal R(z')}\right)^\theta
=\left({Q(v)w_g(z')\over Q(z')w_g(v)}\right)^\theta.
\tag{JSB3}
\]

在原绝对 D×S 门上 Hθ>1，保留全部门的正联合矩随 θ 非减。若反而丢掉双门，裸共同来源矩为 `EΠℛ^θ EΠℛ^(−θ)=EΠ⊗Π cosh(θ(logℛ(v)−logℛ(z′)))≥1`（扩展值成立），也没有小于1的增益。这不是反例，只说明真正收益必须使用绝对门、RC 或接收几何。

同时，设 `a=χ_FA ρ∈[0,1]`、`Δ=k_v−k_z′`，有

`a Δ⁺−Δ⁻ ≤ Hθ(a Δ⁺−Δ⁻)+(Hθ−1)Δ⁻`。

非负修正不可省略；不能乘倾斜后仍免费使用原负部。仅控制孤立 `(M/e)^θ` 不解决此问题。以下另检验共同阈值平均。

## 2. 含 high 门的共同 K 平均

固定 `K_lo>0`，一个共同种子给出 `log K∼Unif[log K_lo,log(2K_lo)]`。同一次 K 用于全部行、来源对和时间，种子在输入与来源选择前固定；禁止逐行或逐来源择优。

**命题的先行范围：** 在上述共同几何、ν、Z_t、w_t、e_t 和时间窗上构造阈值测试族

\[
D_K=Z_g\cap\{\mathcal R<1/K\},\quad S_K=Z_g\setminus D_K,
\qquad H_K=1_{\{p e_g\ge2Kq\}}.
\tag{JSB4}
\]

若原算法换 K 后改变共同基对象或外层 history，须先证明统一耦合，不能直接用本命题。仅是 K 依赖的正项 FA/RC/已付块指示，可以在下文保留准确依赖。

写 `L₀=log2`。若 `p e_g/(2q)≤K_lo`，定义 λ=0、u≡0，平均交通为零；等号仅是 K 的零测端点。否则令

\[
K_{hi}=\min\{2K_{lo},p e_g/(2q)\},\quad
\lambda={\log(K_{hi}/K_{lo})\over L_0}\in(0,1],\quad
u(\xi)=\left[{\log\mathcal R(\xi)+\log K_{hi}\over L_0}\right]_0^\lambda,
\tag{JSB5}
\]

其中 `[r]₀^λ=max(0,min(λ,r))`。全部终端来源对满足

\[
\boxed{\mathbb E_K[H_K1_{D_K}(z')1_{S_K}(v)]
       =[u(v)-u(z')]_+=:G(z',v).}
\tag{JSB6}
\]

尤其 `G≤min{λ,[logℛ(v)−logℛ(z′)]_+/log2}`。跨阈值的小对数间隔自动乘上其穿过随机阈值的概率；无须先假设此层来源质量小。宽间隔层和接收积分仍无价格。

**证明。** 设 `rξ=logℛ(ξ)`、`a=log K_lo`、`b=log K_hi`。双门要求 `−r_v≤log K<−r_z′`。与 `[a,b]` 的交长度除以 log2 恰为 JSB6；若 `r_v≤r_z′`，两侧均零。严格/非严格端点对连续 K 分布零测，即使 ν 有原子也成立。没有重抽两端 K，也没有删除 high 门。

## 3. 当前 Ψ/RC signed 槽的准确修正

原后缀集合 𝒵 对所有终端来源对定义：

\[
F_{z',v}(r)=\int_r^h(k_t(v)-k_t(z'))w_t(z')w_t(v){dt\over t}\le0
\quad\text{对每个 }r\in[\tau,h].
\]

`Ψ=1_𝒵ᶜ`；此资格独立于新 K。令 `a_K=χ_FA,K ρ_K(v)`，若已有互斥已付正块，再乘未付指示。始终 `0≤a_K≤1`，负部不乘 a_K。定义

\[
\overline S=\mathbb E_K\int_\tau^h{dt\over t}
 \iint_{Z_g^2}H_K1_{D_K}(z')1_{S_K}(v)\Psi
 \{a_K\Delta_t^+-\Delta_t^-\}\,d\Pi_t(z')d\Pi_t(v),
\quad \Delta_t=k_t(v)-k_t(z').
\]

以及

\[
\begin{aligned}
C_G&=\int_\tau^h{dt\over t}\iint_{Z_g^2}G\Delta_t\,d\Pi_t\,d\Pi_t,\\
R_{\mathcal Z,G}&=-\int_\tau^h{dt\over t}\iint_{Z_g^2}1_{\mathcal Z}G\Delta_t\,d\Pi_t\,d\Pi_t,\\
L_{cap}&=\mathbb E_K\int_\tau^h{dt\over t}\iint_{Z_g^2}
 H_K1_{D_K}(z')1_{S_K}(v)\Psi(1-a_K)\Delta_t^+
 \,d\Pi_t(z')d\Pi_t(v).
\end{aligned}
\]

则准确恒等式为

\[
\boxed{\overline S=C_G+R_{\mathcal Z,G}-L_{cap},\qquad
R_{\mathcal Z,G}\ge0,\quad L_{cap}\ge0.}
\tag{JSB7}
\]

等式用 `a_K Δ⁺−Δ⁻=Δ−(1−a_K)Δ⁺`。对每个属于 𝒵 的来源对，已审后缀式给 `∫Δ wt(z′)wt(v)e_t⁻²dt/t≤0`；G 对 t 固定，所以 R_𝒵,G≥0。逐行有界 score 和有限窗保证 signed Fubini 合法。

R_𝒵,G 不是新可消费负量：它精确补回“去掉已消费 𝒵 后仍借全来源协方差”的缺项。删掉它就是再次借 N_𝒵。L_cap 是正项已经削减的准确量，不再领取 FA/RC 费用。N_𝒵ᶜ 在 S̄ 中完整使用一次。

## 4. 终端子概率仅回到旧 SO 接口

令 `U_t=∫Zg wt dν`、`α_t=U_t/e_t`、`b_t=e_t−U_t`，以及

\[
d\overline\Pi_t^g=1_{Z_g}w_t\,d\nu_V/U_t,\qquad
m_t^u=\int u\,d\overline\Pi_t^g.
\]

`U_t≥e_g>0`。实际 `Π_t|Zg=α_t Π̄_t^g` 是子概率，不能当全 Π_t。只对 C_G 中全部终端来源对作对称化，得

\[
\iint G\Delta_t\,d\Pi_t\,d\Pi_t
=\alpha_t^2\operatorname{Cov}_{\overline\Pi_t^g}(k_t,u),
\qquad C_G=-\int_\tau^h\alpha_t^2\,dm_t^u.
\]

对称化的 1/2 被两种方向抵消；没有交换 Ψ/RC 后假定对称。u 对 t 固定，mᵘ 连续且绝对连续；α 在删除时向上跳。这是旧 R121 SO 的有界测试版本，给

\[
\boxed{\overline S\le m_\tau^u-m_h^u
       +{2\lambda b_\tau\over e_h}+R_{\mathcal Z,G}-L_{cap}.}
\tag{JSB8}
\]

具体地，置 `d_t=λ−m_t^u∈[0,λ]`，则 `C_G=∫α² dd`。b_t、e_t 非增，`(−α′)_+≤b_τ(−e′)/e²`，删除跳的 `−d_t Δ(α²)` 非正。旧 BV 计算给

`C_G−(d_h−d_τ)≤λ(1−α_τ²)+2λ b_τ(1/e_h−1/e_τ)≤2λ b_τ/e_h`。

不能由 α≤1 直接缩放 signed `−dmᵘ`。这里 `b_τ=∫(Z_τ\Z_g)w_τdν` 是未来删源质量。若借旧 light/heavy 帽，只能沿 SO10 的未来删源部分保留尚不小的 ρ_j(g)，不能套硬捕获帽。原 N_del 是另一资格下的连续反向来源对，不等于 α 删除跳或 b_τ/e_h；本式尚未消费 N_del。

端点的具体原核形式为

\[
m_\tau^u-m_h^u={1\over U_\tau U_h}
\iint_{Z_g^2}u(v)[w_\tau(v)w_h(z')-w_h(v)w_\tau(z')]
\,d\nu_V(v)d\nu_V(z').
\tag{JSB9}
\]

它是同一 Q*/(p w_g) 截断测试与原 C 两尺度保留比的相关量。`|m_τᵘ−m_hᵘ|≤λ≤1` 只给 O(X)，不是任意 εX 或根阶 Wβ 价格。

## 5. 费用与准确停止点

若未来证明全算法的共同 K 版本合法，且 JSB4 high 之外可用相同外交通

\[
d\mathcal T_I=1_I1_{j(x)=j}q^{-1}p(x,y)h_R(x-z)a_{history}
\,dx\,d\beta_V(y)d\nu_V(z),
\]

则可把 JSB7/8 乘此交通，保留原 `E_ωΣV,j`、唯一 j、β−ν、硬 z 和真实 `ν³/e_t²`。准确槽是

\[
2\Lambda\{\int\overline S\,d\mathcal T_I
 -\mathbb E_KN_{I,del}(K)\},\qquad\Lambda=128/119.
\tag{JSB10}
\]

外积分记号含期望及求和。若 K 改变 history/共同基对象，JSB10 暂不适用；不能平均不同基测度后仍使用同一 u/Π_t。

**本轮未证的最小内容：** 在 JSB8 的真实外积分中，JSB9 正端点、未来删源误差和非负 R_𝒵,G，是否可被同一现有 L_cap、一次 N_del 及 `εX+Cε n^(1/2+o(1))Wβ` 联合控制。无需各粗正项分别根阶，但 FIRST 的 `∫Qν≤q` 尚未给此联合比较。后缀定理只给 R_𝒵,G 的符号，不给抵扣关系。

共同阈值平均无网格层数费，常数是准确的 1/log2；它不令其它选择免费。原 s/L/尺度仍依 x，未离散接收参数，未将 Π_g 移出 x 积分。用于原算法之前，还须证明所有 K 相关 low-pe、初始、跳跃、FA、捕获、旧吸收槽在 `[K_lo,2K_lo]` 的统一价格及同一对象耦合。本文未完成该接口，不能登记已有算法收益。

**封存结论：** 新接口仅是 JSB6 及当前余槽的 JSB7。它削弱小阈值间隔交通，但尚未控制宽间隔的原联合几何。JSB8–9 明确回到旧 SO，并保留不可遗漏的已消费后缀修复量。没有新增一般可付款分支，没有使用 s=0 边界或自由核表。完成后停止。


# 附件：joint_source_statement_audit.md

# R130 联合来源倾斜：先行独立命题审查

本稿完成于阅读本轮作者新稿之前。只读 R130/TASK_CONTEXT、所继承的 R129/TASK_CONTEXT、R128 RT1–6 与旧 statement audit，以及已审 R129 MR4–14；使用 D04 的共同联合参考测度链式接口。没有新增数值、没有预认证一般根阶结论。

**先行结论：η=θ 确实消去 K 与 p 的倾斜幂，留下同一来源对的核/来源权比；同 Π 与绝对双门本身不提供该矩的上界，更不提供原负项的消费权。** 最弱可直接提交的成果是以下局部联合矩恒等式/正支配，外加一个单独、定量的原交通预算桥。不得把两层合并称为已付。

## JS1. 原对象、零质量与可测域

量词为任意非负 f∈L¹、原允许的整数 n 和合法实际构造；保留严格 s>1−2^(−1/n)、FIRST、原高门、唯一比例带、出生/删除及全部 history。原参数选择可随 x 变化。固定 (ω,V,j,y,t) 时，ν、Z_t、w_t、e_t 与 Π_t 在 x 之前构造；g(x)、w_g、D_g/S_g、RC、FA 与 Ψ 并不因此独立于 x。

记完整原外交通为

`d𝒯_I=1_I 1_{j(x)=j} q⁻¹ p(x,y)h_R(x−z)a_history dx dβ_V(y)dν_V(z)`，

并在非负积分记号中含 E_ωΣ_{V,j}。定义共同基测度

\[
d\mu_I=1_{A_{hi}}d\mathcal T_I\,1_{J_{far}}(t)\frac{dt}{t}
\,d\Pi_t(z')d\Pi_t(v).
\tag{JS1}
\]

只对 0<e_t=∫_{Z_t}w_t dν≤M_t=ν(Z_t)<∞ 的纤维使用 Π_t。e_t=0 的原加权交通按零纤维处理，不能计算 0/0。原物理 C>0、有限正尺度使 w_t,w_g>0；合法 s>0 使 p 和三个测试核严格正。原 Q_J=0、A=0、硬 B=1 的零余支依旧按原约定处理。M_t=0 不定义 log(M_t/e_t)。

所有来源集、门、θ 选择器及 integrands 要相对完整标签联合可测；可数 V,j 的和按原构造理解。若只用 Tonelli，非负量可取 +∞；若使用概率/KL，先选同一合法有限截断，使 0<μ_I(Ω)<∞，并保留正负项的共同截断。不能分别截断两端后相减；无限回账须有统一上界与合法的 signed 极限。若 ω 空间未给标准 Borel 表示，条件核存在性需另交代；可以先逐 ω 在欧氏标签上应用，再积分。

## JS2. η=θ 的准确消去与最弱核命题

写 Q_x^*=(K₁+K₂+J)/3，保持三个**整维**核及其原尺度。令

\[
\ell_x(\xi)=\frac{Q_x^*(\xi)}{p(x,y)w_g(y,\xi)},\qquad
H_\theta(x,z',v)
=\left(\frac{\ell_x(v)}{\ell_x(z')}\right)^\theta
=\left(\frac{Q_x^*(v)w_g(z')}{Q_x^*(z')w_g(v)}\right)^\theta.
\tag{JS2}
\]

其中 0<θ≤1，允许 θ 是完整标签上的同一个可测函数；两端不得分别优化后仍称 η=θ。若要把 θ 提到积分外、取乘积矩或使用一个统一指数 Markov 界，则须在对应积分域固定 θ，或证明分区后的费用。原 D_g×S_g 给

`ℓ_x(z′)<1/K≤ℓ_x(v)`，故在此域 H_θ>1。

令 χ_old 表示仍未支付正项的不交选择器（若没有另外删除已付块则取 1），并置

\[
F_+=1_{D_g}(z')1_{S_g}(v)\Psi\,\chi_{FA}\chi_{old}\rho_r(v)\delta_t^+,
\quad
F_-=1_{D_g}(z')1_{S_g}(v)\Psi\,\delta_t^-.
\tag{JS3}
\]

则 P_I=∫F_+dμ_I，N_{I,𝒵ᶜ}=∫F_-dμ_I。最弱无需新几何的联合倾斜结论为

\[
P_I\le\widetilde P_{I,\theta}:=\int F_+H_\theta d\mu_I,
\qquad
\widetilde P_{I,\theta}-P_I
=\int F_+(H_\theta-1)d\mu_I\ge0.
\tag{JS4}
\]

此式保留实际 ρ、δ、FA、Ψ、尾域和全部原参数，允许右侧无穷；有限时等式直接成立。它不要求冻结 α_rec(x)，也不产生乘积接收积分。若另外用 MR9 的 RC 矩上界，则增加 `[TA/(DK₀+α_rec J)]^ξ/(1+ξ)`，并明确这是替代 ρ 的较粗支配；α_-＝0 合法但丢失补核收益，不能称为精确保留 RC。

η=θ 后 MR4 的外幂为 `w_g(z′)^θ/w_g(v)^θ`，接收核为 `p·Q(v)^θ/Q(z′)^θ`。源权不抵消。甚至对任意固定 x 的同一 Π，在相关矩有限时，未加门的纯权比满足

\[
\iint (w_g(z')/w_g(v))^\theta d\Pi_t(z')d\Pi_t(v)
=(\mathbb E_{\Pi_t}w_g^\theta)(\mathbb E_{\Pi_t}w_g^{-\theta})\ge1.
\tag{JS5}
\]

这只是 Cauchy–Schwarz 的方向检查，不是物理反例。双门在固定 x 的裸矩下给两个截断边缘，但加入 Ψ、δ、FA、history 和 RC 后一般不再因子化；跨 x 更不能把 D_g/S_g 当固定来源事件。交换 z′、v 虽保留裸 Π⊗Π，却把 D×S 变成 S×D，并改动正门/余权；不能由交换对称免费取得原 N_{𝒵ᶜ}。

## JS3. 可积条带、尾域与尺度费用

双源倾斜讨论的是原 `t∈J_far=I_{j,V,y}∩[τ_j,g exp(−u/n)]`、D_g×S_g、Ψ、未付正块及 δ⁺ 的真实尾域。u 在来源前已固定。若扩大这些正域，必须把结果标为正上界；负项不能随之添门或扩大。

固定合法 s,L,R 等参数时，MR6 在有限硬区间可积。移除硬 z 必须先付原硬帽，不能同时保留旧 R^(−n)；其因子化整线版本在 η=θ 时有

\[
\kappa_m=\frac1L+\frac\theta{H_m}
-\theta\sum_r\frac{\pi_r}{H_r}
-\xi\left(\frac\zeta{\widehat H}+\frac{1-\zeta}{b}\right).
\tag{JS6}
\]

准确条件为 κ_m>0；0≤ξ<1/2 是全合法尺度的充分域，κ_m≥(1−2ξ)/(2a)。这只保证每个固定位置/参数的一维尾积分有限，不控制随后来源位置积分、θ 的小值损失、参数网格费用或完整 x 自适应矩。取 θ≈1/(1+log(M_t/e_t)) 只给孤立 w_t 逆权的有界损失；w_g 与 w_t 还有 `(g/t)^(nθ)` 比较费，且小 θ 会改变所用双门尾估计。所有这些必须在同一个 JS4/JS7 中合计。

## JS4. 可交付的最弱实际付款接口

一般目标仍为所有原输入、全部合法自适应参数和共同有限截断，统一证明

\[
2\Lambda\{P_I-N_{I,\mathcal Z^c}-N_{I,del}\}
\le\varepsilon X+C_\varepsilon n^{1/2+o(1)}W_\beta.
\tag{JS7}
\]

o(1)、C_ε 与误差分配不得依输入、来源位置数、history 长度或截断增长。这是原目标；不要求每一来源对或每一行都单独根阶。因而最弱合理的**新桥命题**可以仅对一个可测真实子支 F_+1_B 给出带价的聚合 signed 上界，不强求整个粗正矩统一小。

若使用 JS4 直接推进，一个可检验的充分桥是：构造原存活负项的非负分配 N_B≤N_{𝒵ᶜ}+N_del（测度意义的子量），以及可积分成本 c_B，使

\[
\int F_+1_BH_\theta d\mu_I\le N_{B,I}+\int c_Bd\mu_I,
\quad
2\Lambda\int c_Bd\mu_I\le\varepsilon_B X+C_B n^{1/2+o(1)}W_\beta.
\tag{JS8}
\]

JS8 是充分而可能较强的桥；也可直接估计实际 F_+，不强制承担整份倾斜松弛损失。仅写“联合矩有限”或把未估计的矩命名为 c_B，不算证明 JS8。若由多个分支使用负项，须给可测分配系数总和≤1，或显式负槽匹配，其总推前负测度受原存活负测度支配；原剩余正支保持不交。N_{𝒵} 已消费，不得返回。N_{𝒵ᶜ} 本来不带正 FA/ρ/未付块门；N_del 的删除资格也不能改成 terminal-good。负值不是任意 KL 的存款：必须证明其数值足以控制本次实际 KL/倾斜损失。

外层费用保持真实 dx、β−ν、硬 z、q⁻¹、ν³/e_t²、EΣ_{V,j}、scale/history。若删除硬 z 或接收参数离散化，应在 c_B 的真实回代中计入已证明的常数；不以“同 Π”免除这些费用。

## JS5. 熵链式若使用，必须从同一联合律开始

在 JS1 的有限非零截断上取 Q₀=μ_I/μ_I(Ω)。可先给 Q₀ 乘入某些原门再归一化，但必须明确新正常化常数；两种参考不可混用。若 F≥0、0<Z=E_{Q₀}F<∞，定义 P_F=(F/Z)Q₀。这是合法联合倾斜，且在相应对数可积时

`D(P_F‖Q₀)=E_{P_F}log F−log Z`。

F=0 的点不贡献 P_F；Z=0 的支为零交通；Z=∞ 不可称为概率倾斜。扩展实数 KL 用非负链式定义，不形式计算 ∞−∞。即使取 F=H_θ，Z 仍是待控来源矩，而非自动等于 1。

令 X 包含接收点及足以确定依 x 门的外层标签，U=(z′,v)。在标准 Borel 表示及正规条件律存在时，唯一可直接使用的链式为

\[
D(P_{XU}\Vert Q_{XU})
=D(P_X\Vert Q_X)+\int D(P_{U|X=x}\Vert Q_{U|X=x})P_X(dx).
\tag{JS9}
\]

参考必须就是同一个联合 Q 的真实条件律。若 Q 先附 D_g×S_g，它的条件参考依 x，且带 Π_t(D_g(x))Π_t(S_g(x)) 的截断归一；再附 Ψ、δ、history 等通常使两源条件相关。若 Q 尚未附门，则把门作为 F 的一部分，其事件正常化费用仍留在 log Z 中。不能先条件化丢掉小概率成本，再把 Q_{U|X} 换成独立的全局来源边缘；对 U 再链式分解也须使用 Q_{v|X,z′}。

源对相同 Π 只描述门之前的共同抽样核。它不使按 x 选出的来源联合律独立于 x，也不提供 KL 上界。JS9 是恒等分账，未给预算；需要作者另证同一联合律下 KL 或 log Z 的量化控制，以及其如何由 JS8 的未消费负槽或显式 c_B 支付。若引入有限 history 望远镜，必须写初末势、每步耗散、误差总和及原负槽总消费≤1；不能凭形式链式宣布无限层费用消失。

**停点：独立命题域审完成。η=θ 的局部联合支配合法；原来源费用、联合熵预算与存活负项匹配均未证明。等待作者具体稿后再做后审，本稿不预认证 root。**

## JS6. 新共同 K 平均接口的独立先审（仍未读作者新稿）

此节根据主代理给定候选公式独立核算；不以其后作者稿倒填先行判断。固定一行及时间，要求来源核比值 R(ξ)=Q_x^*(ξ)/(p w_g(ξ))、终端共同域 Z_g、原 Π_t、k_t 和所用基准外测度在本次 K 平均中固定。若实际构造中另有 K 依赖，须保留在积分内，不能直接适用以下裸协方差恒等式。

取 K=K₀2^a、a∈[0,1]，即平均测度 `da=dK/(K log 2)`。这里 r(ξ)=log(K₀R(ξ))/log 2；r 与原行标签 r 不同，以下有限记号用 r_i 区分。bad 与 good 是 `a+r_i<0`、`a+r_i≥0`。高门若确为 a≤c_raw，则截断 c=min(1,max(0,c_raw)) 后，在 da 几乎处处可用 a∈[0,c]；原等号对连续 K 平均无影响。不可把该平均误作在保留高门后归一化的 da/c。

设 `u_i=clip(c+r_i,0,c)`。它恰等于第 i 个来源在 [0,c] 内的 good 门长度。两端由同一个 a 决定，故

\[
\int_0^c1_{\{a+r_i<0\le a+r_j\}}\,da
=(u_j-u_i)_+.
\tag{JS10}
\]

这是两个嵌套阈值区间的交长；不能用两端边缘概率的乘积。c=0 时全部为零。若另采用条件平均 da/c，所有下式右边另除 c，仅在 c>0 时定义。

令 p_i 为 Π_t 限制到共同终端域 Z_g 后的离散子质量，m=Σp_i≤1。原 `S_g=Z_g\D_g` 只在该终端域内补集，不是 Π_t 全空间的补集。全 signed 核为 `(k_j−k_i)_+−(k_i−k_j)_+=k_j−k_i`。对有限来源，由 JS10 与指标交换得

\[
\begin{aligned}
\sum_{i,j}p_ip_j(k_j-k_i)(u_j-u_i)_+
&=\tfrac12\sum_{i,j}p_ip_j(k_j-k_i)(u_j-u_i)\\
&=m\sum_i p_i k_i u_i
 -(\sum_i p_i k_i)(\sum_i p_i u_i)\\
&=m^2\operatorname{Cov}_{p/m}(k,u),\qquad m>0.
\end{aligned}
\tag{JS11}
\]

m=0 时左侧零，不定义条件分布。原 k_t∈{0,…,n}，0≤u≤c≤1，故连续来源版本在 λ_t=1_{Z_g}Π_t 下由有界积分同样成立，无需来源原子假设。系数必须为 m²；若改用 λ_t/m 计算条件协方差，不得删除回乘的 m²。协方差无一般非正结论；仅由范围可得 `|m²Cov(k,u)|≤m²nc/4`，这只是线性 n 的粗界，且未支付完整外交通。

### 实际 Ψ/FA/RC 剩余如何接回

设 A_a=1_{D_{K(a)}}(z′)1_{S_{K(a)}}(v)，d=k_t(v)−k_t(z′)，h_a=χ_FA χ_old ρ∈[0,1]。在同一固定基准来源对上，原存活 integrand 是 `A_a Ψ_a(h_a d_+−d_−)`。它与裸 signed 核有准确恒等式

\[
\Psi_a(h_a d_+-d_-)
=d-(1-\Psi_a)d-\Psi_a(1-h_a)d_+.
\tag{JS12}
\]

乘 A_a 并对共同 a、来源积分，可得原实际平均存活项不超过

\[
m^2\operatorname{Cov}_{\lambda_t/m}(k,u)
+\int_0^c\iint A_a(1-\Psi_a)d_-\,d\lambda_t^{\otimes2}da.
\tag{JS13}
\]

第二项是**为使用裸协方差而新出现的缺失负项修正**，不是一份可领取的 N_𝒵。已消费 N_𝒵 不恢复；若不另证该修正的价格，JS13 不能登记付款。更准确可保留 JS12 的全部修正及 RC 节约，但不得只抹掉不利项。Ψ、h_a 可以依赖 a；它们存在这种依赖时也不影响 JS12，却不能从 a 积分中提出。χ_old 的不交化和所有其他既有分支消费仍按 JS4 执行。

若外层 history、β/ν、Π_t、g、p 或高门之外的外权随 K 重建，则 JS11 尚不适用于完整实际平均；需提供同一个 K 无关母测度及带权版本，或证明这些量在本次 K 区间固定。K 变动导致 E/α_rec 改变的影响可留在 h_a，但不能用一个 K 的 ρ 替另一个 K。

### 平均的量词与目前边界

此接口先证明的是对一个**所有来源端、所有行共用**的 K 的对数平均。要推出可选单个 K 的全局价格，应先对完整共同有限截断证明聚合平均上界，再在同一允许参数区间选全局 K；逐行各选最有利 K 不合法。若只对每个截断存在 K_I，不能未经额外紧性/统一控制便宣称同一 K 适用于全部截断。原问题若要求预先固定 K，输入依赖选 K 的许可亦须由母归约给出；平均恒等式本身不提供。

独立预审结论：JS10–11 正确，JS12–13 给原账的必要修正，未证明一般协方差根阶价或 Ψ 修正预算。有限 Fraction 折点积分可独立校验门长/符号/零质量，但不认证物理 FIRST、来源支撑或一般 root。等待最终作者稿的路径与 SHA，再单列后审。

## JS7. 冻结作者稿及有限精确检查的后审

**后审结论：PASS（限作者明确声明的行内共同阈值接口与有限标量验证）；无新增根阶付款认证。** 本节在 JS1–JS6 独立声明全部落盘后才读取作者稿，时间顺序不混同。实际读取文件的 SHA-256 为：

| 文件 | SHA-256 |
|---|---|
| joint_source_budget.md | `5f8d6d2ccf3ea53206db1fd6af893aed4da872476e05397d16fc34f0dca983df` |
| threshold_exact_check.py | `b02b1681c12caf572a88ee66259ac48f8d00bc908704d62d80a6ae9361cc66af` |
| threshold_exact_results.json | `ec8822e0836e0f7c9faf72ad303e82f51e8f03dc2028bf8d8a27a68881327f2f` |
| threshold_numeric_note.md（执行后笔记） | `38e10827a429d0e8324a7f917c69d3feb29fdad619a9a2dc97618c839d16ef15` |

### 作者证明核对

1. JSB3 的 η=θ 化简、双门内 Hθ>1 与非负正矩随 θ 非减均成立。裸来源矩的 cosh 表示利用同一 Π⊗Π 的交换对称；允许扩展值，不声称其小于 1。signed 倾斜式右侧减左侧为 `(Hθ−1)aΔ⁺≥0`，其负部修正没有省略。
2. JSB5–6 与独立 JS10 完全一致：作者 λ 对应 c，阈值均匀于完整宽度 log 2，high 只截短有贡献区间，不条件归一化。高门临界端点和来源原子均不妨碍连续 K 平均；小 log 比值间隔的上界是 clip 的单调 1-Lipschitz 性，未据此推出来源质量小。
3. JSB7 是 JS12 保留全部项后的准确版本。这里作者的 Ψ、G 都与 t 无关，来源对属于原完整后缀集合 𝒵，且整个 [τ,h] 未被任意时间子窗替代。因此 R_{𝒵,G} 的非负性合法：若 F(r)=∫_r^hΔ_t w_t(z′)w_t(v)dt/t≤0、W=e_t⁻² 非减，则 Stieltjes 分部积分给 `∫WΔww dt/t=W(τ)F(τ)+∫F dW≤0`。这只确定补偿量符号，不给其价格；作者明确保留它，没有重新领取 N_𝒵。
4. JSB8 的 α_t²Cov 与 JS11 的 m²Cov 相同，来源条件化没有丢质量。固定终端域、固定 u 下，`∂logt m_t^u=−Cov(k_t,u)`；原 e_t 含删源，α 的删除向上跳不能直接忽略。作者使用 d=λ−m、保留 b_τ/e_h 的旧 BV 余项，与独立核算一致：`(−α′)_+≤b_τ(−e′)/e²`，向上删除跳在 `−∫d d(α²)` 中非正。所得 `2λ b_τ/e_h` 未被声称免费，N_del 仍未消费。
5. JSB9 的两尺度端点差可直接展开 U_h∫u w_τ−U_τ∫u w_h 验证。它与 JSB8 均被明确标为旧 SO 接口，没有将再表达登记为新根阶进展。JSB10 仅在共同 K 无关基对象/外层交通得到认证后适用；全算法 K 一致性与各原价格仍是待证条件。原真实 dx、β−ν、硬 z、ν³/e_t²、全部尺度/history 账没有被门长公式代替。

### 数值代码与已保存结果静审

本审未执行或导入 producer；只静读代码，并用标准 JSON 读取汇总已保存字段与 SHA。主代理及笔记报告原脚本已执行一次、exit 0；这里不另作独立执行声明。

oracle 独立取 0、1、c 及全部内部 −r_i 折点，每个开区间内严格 bad/non-strict good/high 门常值，用有理中点判门再乘精确区间长度。它不调用 clip、闭式门长或协方差，故与待验闭式不是同一实现的复述。端点逐点真值另存，但零测端点不加入长度。所有 r、c、p、区间运算使用 Fraction；k 用受界整数。

固定菜单为初探/压力/扩大 4/6/6，共 16 例、561 个有序来源对。已保存结果核得：所有成对残差分子为 0、16 项加权和残差为 0、失败列表全部为空；12 项有定义且无 mask 的 m²Cov 残差为 0。两个零终端质量案例不执行 p/m，两个任意 mask 案例仅认证成对加权公式，协方差正确标 N/A。空终端、终端真子集、零概率、c=0/1、等号/饱和、正负协方差及常 k 都在菜单内。扩大到 12 原子与 k 上界 6561/10000 只是标量整数压力，不是 6561/10000 维物理核。

异常会逐例以 ERROR_RETAINED 保留，非零残差进入 failures；没有失败后删行机制。结果内 source_sha256 与当前源码一致。JSON 所保存执行前协议文本的实际 SHA 为 `63cec6026b583e640ecba2954032a3e0bcdb474d7eab3981195d727252f14a62`，与其 pre_execution 字段一致；执行后笔记另有上表哈希，未冒充同一前置冻结输入。

这些检查**没有**验证真实 φ/C 可实现性、原 FIRST/FULL、后缀 Ψ 的物理来源、JSB7 的时间积分或 R_{𝒵,G} 的非负性、全算法共用 K 的耦合、任何一般预算。两个 mask 是标量占位，并不认证其为原后缀补域；这些边界在协议/代码布尔字段中均明确。作者的分析证明与有限门长检查各自承担其正确范围。

**最终停点：冻结稿的 JSB6–7 接口和上述有限标量证据通过；JSB8–9 只回到旧工具。一般联合来源价格、R_{𝒵,G} 的付款及全算法共同 K 的合法性仍未证明。完成后停止，不扩展菜单或特殊族。**


# 附件：signed_transport_history.md

# R130：Π漂移、signed来源对与负项账的定向历史定位

**准确结论：Π的中心化导数、精确删除跳、全补集signed协方差，以及固定存活子集的BV端点式都已证。它们尚未支付R130的Ψ补域、FA/RC削减后真实接收signed槽。** 当前可用负项仍为整个原Ψ=1_{𝒵ᶜ}存活负项和原N_del，各一次；N_𝒵已消费，不可取回。下面只定位必要旧片段，不重审全历史、不跑数值、不登记新付款。

本轮按 [R130 TASK_CONTEXT](/Users/zhengzhihao/Desktop/T/output/centered_cube_round130_20261014/TASK_CONTEXT.md:5) 固定同一个完整实际行，保留真实d𝒯、β−ν、硬z、唯一j、history、全部时间/来源门；先在原共同有限正负截断上操作。取非空合法[τ,h]，D=D_g⊂Z_g、S=S_g=Z_g\D。所有行内终端门对积分t固定，不把它们从x积分移出。

| 已证接口 | 独审定位及条件 |
|---|---|
| 在Z恒定段，∂_{log t}Π_t=−(k_t−m_t)Π_t，m_t=∫k_t dΠ_t；e′_t=−e_tm_t/t。 | [R117 audit_normalized](/Users/zhengzhihao/Desktop/T/output/centered_cube_round117_20261014/audit_normalized.md:27)，第31–43行：原权重逐源AC、e_h>0、a.e.求导。阈值折点可在连续来源下稠密，但w连续，不产生删除跳或额外奇异变差。第85行要求禁块跳间不变；一般连续删除不能套无通量公式。 |
| 删除跳必须单列。令η_u=1_{Z_{u−}\Z_u}w_uν、r_u=η_u(Ω)，e_u=e_{u−}−r_u>0，则ΔΠ_u=(r_u/e_{u−})Π_u−η_u/e_{u−}。跳正变差质量恰r_u/e_{u−}。 | [R117精确删除跳](/Users/zhengzhihao/Desktop/T/output/centered_cube_round117_20261014/audit_normalized.md:57)。这是其第59–67行公式的同义写法；分母为删除前e，不是删除后e。右连续约定包含(τ,h]跳，初始τ已经初始化；其它点值约定须逐有序删除阶段计量。 |
| 全当前补集G_t=Z_t\D给C_all(t)=∫_D∫_{G_t}(k_t(v)−k_t(z′))dΠ_t(v)dΠ_t(z′)=−Cov_{Π_t}(k_t,1_D)=∂_{log t}Π_t(D)。无额外1/2。 | [R118 causal_audit A2](/Users/zhengzhihao/Desktop/T/output/centered_cube_round118_20261014/causal_audit.md:29)，第64–84行核双来源/e_t²及原外交通。只在固定D、禁块恒定段成立为a.e.导数。 |
| G_t=S_g ⊔ (Z_t\Z_g)，故C_all=C_surv+C_future-del。D×S_g的signed差**单独不是**∂_{log t}Π_t(D)。 | [R118独审 A4/A5](/Users/zhengzhihao/Desktop/T/output/centered_cube_round118_20261014/causal_audit.md:97)，第124–133行精确拆分。未来删源没有terminal-good门。删除跳不删D，ΔΠ_u(D)≥0，但这不是N_del。 |
| 固定存活D、O时，U_t=∫_{D∪O}w_tν、α_t=U_t/e_t、θ_t=∫_Dw_tν/U_t，∫D×O signed dt/t=∫α_t²dθ_t=[α²θ]_τ^h−∫θd(α²)。保守上界θ_h−θ_τ+2b_τ/e_h，b=e−U。 | [R121先行独审](/Users/zhengzhihao/Desktop/T/output/centered_cube_round121_20261014/signed_statement_audit.md:13)；[全文独审端点/误差仍未付](/Users/zhengzhihao/Desktop/T/output/centered_cube_round121_20261014/signed_proof_audit.md:45)。α有删除上跳，θ连续；两份e分母完整保留。b_τ不必小，端点差≤1不是εX或来源价。O换为其它固定存活集时，原O专属质量帽不能照搬。 |

因此，对**未切任何pair/正负门的全补集**，有限窗确有
\[
\int_\tau^h C_{all}(t)\frac{dt}{t}
=\Pi_h(D)-\Pi_\tau(D)-\sum_{u\in(\tau,h]}\Delta\Pi_u(D).
\]
这个有限望远镜是已审CJ导数加跳公式的直接整理。不能删掉初始/终端、未来删源或删除通量后仍称同一式；也不能把JG的log(e_τ/e_h)归一化变差预算当已付真实接收空间费。[R117第93行](/Users/zhengzhihao/Desktop/T/output/centered_cube_round117_20261014/audit_normalized.md:93) 和 [R118第62行](/Users/zhengzhihao/Desktop/T/output/centered_cube_round118_20261014/causal_audit.md:62) 已明确这种范围。

**Ψ为什么破坏免费望远镜。** 原后缀通过域𝒵上的pair满足F(r)=∫ᵣʰ(k_v−k_z′)w_vw_z′dt/t≤0。e^−2非减，准确分部积分为
\[
\int_\tau^h f(t)e_t^{-2}dt
=e_\tau^{-2}F(\tau)+\int_{(\tau,h]}F(r)d(e_r^{-2})\le0.
\]
[R122后缀独审](/Users/zhengzhihao/Desktop/T/output/centered_cube_round122_20261014/suffix_sign_statement_audit_private.md:29) 已核删除跳符号及端点；仅限pair整个窗存活。其 [第116行及作者审第150行](/Users/zhengzhihao/Desktop/T/output/centered_cube_round122_20261014/suffix_sign_statement_audit_private.md:116) 明确：同一个pair划分同时切正负项，𝒵上的N_𝒵消耗一次，之后只留𝒵ᶜ上的负项。把全signed积分记C，已消去部分记C_𝒵≤0，则C_{𝒵ᶜ}=C−C_𝒵≥C；所以全域望远镜上界不能直接上界补域。Ψ是来源对门，不能把它误作Π_t(D)的一元测试。后缀未通过只表示该充分条件失败，不认证正净交通或FULL。

**FA/RC后的准确剩余与可用负项。** 在当前原pair上写a_t=k_t(v)−k_t(z′)，χ=χ_FA，ρ=1−b_rec，则
\[
\Psi\{\chi\rho\,a_t^+-a_t^-\}
=\Psi a_t-\Psi(1-\chi\rho)a_t^+.
\]
这个代数减少量是原正项已经削减的部分，不能再把FA已付正项或捕获项领第二份费用。早期 [FA19–22](/Users/zhengzhihao/Desktop/T/output/centered_cube_round119_20261014/quantitative_future.md:186) 已证完整signed=足测试正项+不足正项−完整负项；负项不附正FA门。当前定义由 [R128 RT2/3](/Users/zhengzhihao/Desktop/T/output/centered_cube_round128_20261014/joint_receiver_tail.md:29) 与 [对应命题审第31–39行](/Users/zhengzhihao/Desktop/T/output/centered_cube_round128_20261014/joint_tail_statement_audit.md:31) 固定为
\[
2\Lambda\{P^{rem}-N_{\mathcal Z^c}-N_{del}\}.
\]
N_𝒵ᶜ是原S_g域整个Ψ存活反向score负部，不补χ_FA、ρ、低核门或SP/MA失败门；N_del是原当前存活/未来删除资格下的连续反向pair项，不能补terminal-good，也不等于Π归一化删除跳。SP/MA只删互斥已付正子项，未消费这两份负项。若改用SF/AS的原密度c(v)局部或全行抵消，须在母式中删去已用的N_𝒵ᶜ部分，不能再保留它扣第二次；见 [AS消费规则](/Users/zhengzhihao/Desktop/T/output/centered_cube_round127_20261014/aggregate_signed_candidate.md:34)。N_𝒵不可返回，初始/跳跃、其它前缀及β−ν费用也不可凭此重算为免费。signed交换仍限共同有限截断，逐行有限不能定义全局∞−∞。

**追加定向查重：logℛ/KL与小margin层。** 用ℛ(v)=Q_x^*(v)/(p w_g(v))记题中的R，避免与硬尺度R混名；D={ℛ<1/K}、S为其终端补集。固定行中X(v)=logℛ(v)不随t变。在可积有限截断及Z恒定段，已审JG测试函数导数直接给∂_{log t}E_{Π_t}X=−Cov_{Π_t}(k_t,X)；删除时还须加其测试函数跳通量。对有界截断X，层蛋糕仅把Cov(k,X)写成阈值指示协方差积分；pair展开带的是额外权X(v)−X(z′)。跨D/S的该log margin可任意小，且全协方差还有D/D、S/S组内项，不能由此免费控制当前无margin的signed kt差。

本次限定检索了R117/R118已审导数、R121/R122 signed/后缀、R127 score门筛查及R129 MR审查，并对旧 `nearmax_conditional_covariance`、`ordered_capped_test_energy`、`root_bounded_entropy_review` 的相关关键词作片段定位；**未定位到把上述Cov(k,logℛ)或阈值1/K附近小margin层转成原Ψ/FA/RC联合来源价的已审付款。** 不声称全历史不存在此命题。最接近的现行 [R129 D02/KL范围审查](/Users/zhengzhihao/Desktop/T/output/centered_cube_round129_20261014/mixed_receiver_statement_audit.md:47) 只认证有限规范化/可积条件，明确更换参考需付熵价、Π_t不是dx参考概率；其joint倾斜核矩的可积域也未给根阶价格。若继续该候选，仍需独立的小margin层预算、组内/删除/Ψ修正、一次未消费负量分配及真实d𝒯外层价格，不能把固定期望导数或KL名词登记为已付。

给主代理的最短复用入口为JG归一化漂移/删除跳 → CJ全补集signed → SO固定存活BV → SS后缀一次消费 → RT2/3当前母式。缺口仍是同一真实来源/接收历史下的空间预算，而非恒等式不存在。


# 附件：hard_carrier_joint_geometry.md

# R130：保留 hard z 的四来源交叠筛查

**结论。** 得到一个原 C 权重与 hard-carrier 交叠的精确抵消引理 HC6；它解释了为何不能先删 hard z。但没有得到所需的一般来源价格。双绝对门的共同倾斜留下 bad 端逆核因子和真实 soft-anchor 部分，现有同源 FIRST/high-pe 只控制其正测试质量，未控制这些费用与原 score 的联合积分。本稿在此停止，不把核引理登记为根阶付款，不新增假设或特殊族子支。

## 1. 准确候选：先固定一个共同倾斜，不改原交通

继承 R130 TASK_CONTEXT 与 R129 MR1–6 的全部对象。原待付量仍是
\[
2\Lambda(P_{rem}-N_{\mathcal Z^c}-N_{del}),
\]
其中真实外交通是 q^(−1)p(x,y)h_R(x−z)a_history dx dβ(y)dν(z)，内层为原 dt/t、ν(z′)ν(v)、w_t(z′)w_t(v)/e_t²、Ψ、FA 不足、RC 余权和 δ_t=[k_t(v)−k_t(z′)]_+。原 high 门 pe_g≥2Kq、FIRST、same ν、β−ν、唯一 j 及全部 history 不变；负项不加正门，已消费 N_Z 不返回。

**先筛固定参数核命题。** 固定原合法 s,L,R,g,j,t 及 y,z,z′,v，s>1−2^(−1/n)，H₁=L、H₂=L⁺、H₃=b，k_m=q_(s,H_m)（m≤2）、k₃=q_(1,b)。取同一个 θ∈(0,1]，在 MR4 中仅先取 η=θ、ξ=0；这是保留两门权比的最低费用筛查，不进一步加入新的逆低核因子。定义
\[
\omega_i(\xi)=\min\{1,bC(|y_i-\xi_i|/b)/(c_jg)\},
\quad w_g(\xi)=\prod_i\omega_i(\xi),
\]
\[
\mathcal T_{m,i}(y_i,z_i,z'_i,v_i)=
\left(\frac{\omega_i(z')}{\omega_i(v)}\right)^\theta
\frac1R\int_{z_i-R/2}^{z_i+R/2}
q_{s,L}(u-y_i)
\left(\frac{k_m(u-v_i)}{k_m(u-z'_i)}\right)^\theta du.
\tag{HC1}
\]
这是一个四来源的一维候选；三个 m 必须各自在整维共同使用，不能坐标间重选赢家。

对任一原贡献接收域 O_E，保留原门在左侧，有
\[
\begin{split}
&\int_{O_E}p h_R\rho\,
1_{\{p w_g(v)\le KQ^*(v),\ p w_g(z')>KQ^*(z')\}}dx\\
&\hspace{1cm}\le\sum_{m=1}^3\prod_{i=1}^n\mathcal T_{m,i}.
\end{split}
\tag{HC2}
\]
**标量费用是一次三项和，外系数为1。** 证明：双门使
(Q*(v)w_g(z′)/(Q*(z′)w_g(v)))^θ≥1；Q*(v)/Q*(z′) 是三个 K_m(v)/K_m(z′) 的正加权平均，故其 θ 次幂≤Σ_m(K_m(v)/K_m(z′))^θ。乘 p h_R，并仅在正上界中用 ρ≤1、扩大 O_E 至原 hard 盒，Tonelli 得 HC2。K 的幂因 η=θ 恰好相消。这里没有声称 RC 余权等于1，也没有改变未付正项的实际权重。

HC2 本身只是 MR 的一个较简共同权比实现，**不算新收益**。它仍为固定参数核引理，不能把实际 x 依赖参数移出积分。固定参数下 δ_t 是原坐标阈值确定的同一数，乘回 δ_t 不改变 HC2，却也没有给它费用。

## 2. hard-anchor 部分的 C 权重精确抵消

记 m₀=min(L,R)、γ=1+1/n，原比例带给
\[
m_0\le c_jg\le\gamma m_0.
\tag{HC3}
\]
在坐标 i，令 I_i=[z_i−R/2,z_i+R/2]∩[y_i−L/2,y_i+L/2]，长度 l_i≤m₀。若 l_i=0，以下 hard 部分为0。否则设
\[
d_{m,i}=H_m\operatorname*{ess\,inf}_{u\in I_i}k_m(u-z'_i)>0.
\tag{HC4}
\]
正性来自实际 s>0；该量一般不具有维数无关下界。

原核单调性及 H_m≤b 给
\[
k_m(u-v_i)\le H_m^{-1},\qquad
k_m(u-v_i)\le H_m^{-1}F((u-v_i)/b),
\]
而 I_i⊂[y_i−b/2,y_i+b/2]，故
\[
\int_{I_i}k_m(u-v_i)du
\le H_m^{-1}\min\{l_i,bC(|y_i-v_i|/b)\}.
\]
按 ω_i(v) 是否饱和分两种情况，得到关键抵消
\[
\boxed{\frac1{\omega_i(v)}\int_{I_i}k_m(u-v_i)du
\le\frac{c_jg}{H_m}.}
\tag{HC5}
\]
饱和时用 l_i≤m₀≤c_jg，未饱和时 bC/ω_i(v)=c_jg。它使用了同一个 hard z 载体与 hard y 区间；不是全线 p_s 的 Hellinger 缺口。

将 HC1 中 q_(s,L)(u−y_i) 换成 h_L(u−y_i)，记所得为 \mathcal H_(m,i)。Hölder 与 HC4–5 给
\[
\begin{split}
\mathcal H_{m,i}
&\le\frac1{RL}
\left(\frac{H_m\omega_i(z')}{d_{m,i}}\right)^\theta
l_i^{1-\theta}
\left(\frac{c_jg}{H_m}\right)^\theta\\
&\le\boxed{\frac{m_0}{RL}
\left(\frac{\gamma\omega_i(z')}{d_{m,i}}\right)^\theta
\left(\frac{l_i}{m_0}\right)^{1-\theta}.}
\end{split}
\tag{HC6}
\]
因此 hard-anchor 部分确实消除了 v 端 ω_i(v)^(−θ)；把 HC6 乘过坐标时，比例带因子只为 γ^(nθ)≤e^θ，不是常数的 n 次幂。

这也修正一个过粗的直觉：hard z 盒可以落在两个硬核交集内，但此时原 c_jg≈min(L,R) 与 C 中的硬重叠会使对应权重接近饱和；不能忽略 c_jg 后宣称抵消必然失败。

## 3. 抵消尚未变成原来源费用：两个保留项

定义 \mathcal S_(m,i) 为 HC1 中把 q_(s,L)(u−y_i) 换成 L^(−1)φ((u−y_i)/L) 后的积分。因 η=θ 时 p 的幂恰为1，准确有
\[
\mathcal T_{m,i}=(1-s)\mathcal H_{m,i}+s\mathcal S_{m,i}.
\tag{HC7}
\]
这是原核的恒等分解，不假设 f 或 ν 为产品。不得把实际正软度改为0；也不能只保留所有坐标都选 \mathcal H 的项。soft-anchor 部分没有 I_i⊂y 的硬区间这个条件，故 HC5 的证明不适用于它。

另外，即使只看 HC6，仍有
\[
\prod_i\left(\frac{\omega_i(z')}{d_{m,i}}\right)^\theta
\tag{HC8}
\]
这一 **bad 端逆核费用**。它不能由“核局部严格正”改写成统一常数。原 bad 门给的是 Q*(z′)<p w_g(z′)/K，方向上允许测试核小；它并不提供 HC4 所需的下界。FIRST 给同一 ν 的正核积分帽，也不直接给这种逆核矩。HC8 的费若要支付，必须在原接收域和原 z′ 来源积分中，与 HC7、δ_t、high-pe/RC 一起估计，不能单独取最坏值后宣称费用已控。

HC6 本身也没有 δ_t 的指数衰减：活动坐标中被消去的是 ω_i(v)^(−θ)，不是 [k_t(v)−k_t(z′)]_+。因此即使忽略 HC8/soft 部分，尚不能从 e^θ 的比例带价格推得 √n 总费用，更不能免费支付 Σj 和实际尺度选择。

## 4. 共同 FIRST/high-pe 实际提供了什么

在每个原实际 x 上，用同一 ν、同一个 Q* 和 e_g=∫_(Z_g)w_gdν，严格有
\[
\int_{S_g}w_g(v)d\nu(v)
\le\frac Kp\int_{S_g}Q_x^*(v)d\nu(v)
\le\frac{Kq}p\le\frac{e_g}{2}.
\tag{HC9}
\]
同样 J 是合法共同测试，∫Jdν≤q。以上两式始终保留，未用不同来源/不同接收点替代。

它们控制 good 端的真实加权质量及正测试质量；HC8 却涉及 bad 端局部逆核，HC7 涉及 y 的真实 soft-anchor 响应。没有已证不等式把这些量的共同核积转为 HC9 的质量帽，更没有已证结论说大 HC8 必使 pe_g/q<2K，或使该 good 端被原 RC 捕获。**本稿不推断这些结论。** 相反，在缺少它们时继续优化一维交叠常数不能支付原交通，因此这里停止。

精确剩余义务是：在保留实际 high-pe、绝对门、RC 与全部 history 的接收域上，证明 HC7 中未由 HC6 控制的 soft-anchor 项及 HC8 bad 费用，经过同一 ν 的原 ν³/e_t² 积分后，能由 HC9/J 的共同容量与未消费负项合法控制；或者证明这些大费用域被原 high/RC 排除。原 N_Zc 没有随正项变窄，本稿未消费它或 N_del，也未取回 N_Z。

**交付范围。** HC5–6 是任意维数、原真实 φ/C、合法原尺度上的载体交叠引理；HC2 的四来源候选和标量费用明确，但尚未给一般实际付款。当前 x 自适应、β−ν、Σj/time/history 和共同来源预算均未删去。没有新增假设、实际新覆盖实例、数值实验或主账费用。本轮不把更复杂的未付矩继续包装为进展。


# 附件：hard_carrier_geometry_audit.md

# R130 hard carrier HC5–6：先行独立核验与证明审计

## 先行筛查（读作者稿之前）

固定合法正尺度L,R,b,H，m=min(L,R)、γ=1+1/n，m≤c_jg≤γm，0<H≤b。I是原hard-z与hard-y区间交，长度ℓ≤m且I⊂[y−b/2,y+b/2]。完整 `F=max(h₁,φ)`、`C(d)=∫_{−1/2}^{1/2}F(u−d)du`。对k=q_{s,H}（0≤s≤1）或φ_b（H=b），令ω(v)=min(1,bC(|y−v|/b)/(c_jg))。

φ由非负偶径向递减w与h₁卷积而偶递减，h₁也偶递减；φ≤1。H≤b给逐点 `Hk(u−v)≤F((u−v)/b)`。因此∫I k≤(b/H)C(|y−v|/b)，同时峰值界∫I k≤ℓ/H。

ω<1时以前一界除ω得 `∫I k/ω≤c_jg/H`；ω=1时以前值峰界及ℓ≤m≤c_jg得同界。饱和等号归ω=1分支，方向正确，不要求H≥m。

若ℓ>0、d=H essinf_I k(u−z′)>0，0<θ≤1，则固定坐标hardanchor积分

\[
\frac1{RL}\int_I
\left(\frac{k(u-v)/\omega(v)}{k(u-z')/\omega(z')}\right)^\theta du
\le\frac1{RL}\left(\frac{c_jg\,\omega(z')}d\right)^\theta\ell^{1-\theta}
\le\frac m{RL}\left(\frac{\gamma\omega(z')}d\right)^\theta
(\ell/m)^{1-\theta}.
\]

第一步用bad端essinf和凹幂Hölder，第二步用c_jg≤γm，H尺度因子恰好消去。ℓ=0直接置零不定义空集essinf；d=0只给∞型上界，不能人为填正值。θ=1按有效正长度分支解释零次幂。n维各坐标乘积产生γ^{nθ}≤e^θ一次，不能遗漏 `(m/(RL))^n` 或比例/essinf费用。

此固定hard-y anchor核结论成立。它不把真实P_{s,L}整体换成h_L；未审soft anchor、坏端d^{-θ}或score/source预算。下面再读冻结稿。

## 冻结作者稿后审

绑定实读 `hard_carrier_joint_geometry.md` SHA-256：`218d3f46ce9fac9c0c2b5b70393fc433895e1a8ea2fa537423e2feb311e3991e`。先完成上述独立核筛查后才读该稿。未运行数值，未修改作者文件。

HC5_6_AUDIT_STATUS: PASS_FOR_FIXED_PARAMETERS
GLOBAL_PAYMENT_STATUS: UNPROVED
NEW_ACTUAL_PAYMENT_STATUS: NONE

### HC3–6核方向及常数：PASS

- **真实单调性。** 原w非负、偶且随|u|递减，φ(r)=∫_{r−1/2}^{r+1/2}w(u)du；r≥0时φ′=w(r+1/2)−w(r−1/2)≤0。故h₁与φ均为偶径向递减，且φ≤∫w=1。H_m≤b将缩放后的核逐点压在H_m^(−1)F((u−v)/b)下；不是对φ作错误的硬截断，也不是改用CDF局部分支。
- **完整C及两个质量界。** I_i⊂[y_i−b/2,y_i+b/2]来自L≤b。平移/缩放及F偶性恰给b C(|y_i−v_i|/b)，峰值界给l_i，因此作者第64行min界正确。ω未饱和时bC/ω=c_jg；饱和及饱和等号时ω=1，用l_i≤m₀≤c_jg。HC5两分支没有漏额外b/H_m或维度费用。
- **尺度比例。** 原比例带c_(j+1)g≤m₀≤c_jg且c_(j+1)=c_j/γ，确给m₀≤c_jg≤γm₀。H₁=L、H₂=min(b,γL)、H₃=b都≤b。HC5不需要H_m≥m₀；实际这些测试尺度合法且正。
- **bad essinf与Hölder。** l_i>0时，固定实际s>0使q_(s,H_m)在紧I_i有严格正下界，φ_b也严格正，所以d_(m,i)>0；只表示固定参数局部正性，不是统一下界。Hölder/凹幂给∫I f^θ≤l_i^(1−θ)(∫I f)^θ，0<θ≤1；分母k_m≥d/H_m a.e.。相乘后H_m^θ与(H_m^(−1))^θ抵消，HC6正是先行推导，没有错误方向。l_i=0作者直接置hard项零，避免空集essinf；θ=1亦无0^0漏洞。
- **整维费用。** HC6乘坐标得到 `(m₀/(RL))^n γ^{nθ} ∏(ω_i(z′)/d_(m,i))^θ ∏(l_i/m₀)^(1−θ)`，γ^{nθ}≤e^θ正确。没有把γ常数按来源层再免费复制，也没有消去hard尺度因子或bad逆核乘积。

### HC1–2、HC7–9的附属核验：PASS于所述范围

HC2同门相乘给 `(Q*(v)w_g(z′)/(Q*(z′)w_g(v)))^θ≥1`，K抵消一次。Q*(v)/Q*(z′)是以K_m(z′)/ΣK_r(z′)为权重的正平均，因此其θ次幂≤max_m(K_m(v)/K_m(z′))^θ≤Σ_m该比值^θ。此处可由max直接证明，不能反用凹函数Jensen的方向；作者最终的三项和上界方向正确，外系数1且没有额外3。整维m共同选一次，正扩大O_E至原hard盒后Tonelli给HC1产品。ρ≤1只在正上界中使用，不改原余项。

HC7对每个坐标是原q_(s,L)的线性恒等分解，整维仍是 `∏[(1−s)H_(m,i)+sS_(m,i)]`，包含全部混合掩码。不能将它误写为 `(1−s)∏H+s∏S`，不能只保留全hard项或令s=0；s=1时全hard项权重零。soft-anchor没有I_i⊂y的hard支持条件，HC5–6未覆盖它。作者第99行准确保留此缺口。

HC9也正确：S_g原good门给 `w_g≤KQ*/p`，ν≤f及同一FIRST给∫Q*ν≤q；pe_g≥2Kq进一步给 `Kq/p≤e_g/2`。该行只控制正测试/加权good质量，不能推出bad核的点下界或逆核矩。它没有消费N_Zc/N_del。

### 未付对象及停止范围

HC6仅消掉hard-anchor的v端ω_i(v)^(−θ)。`∏(ω_i(z′)/d_(m,i))^θ`的bad逆核费用、所有soft及混合anchor项、δ/score、同源ν³/e_t²、β−ν、q、dt/t、唯一j的放松费用、实际x依赖选择与history均仍需回代。绝对bad门允许Q*(z′)小，不给d正下界；FIRST正核质量帽或high-pe半good质量帽不直接给这些逆核费用。局部核正性不能登记统一常数。

作者明确未证这些量与原RC/score/负项的联合预算，也没有声称HC6给δ指数尾或一般来源价格。原N_Zc负项不随正子支变窄，各存活负项仍一次，已消费N_Z不返回。**最终结论：HC5–6及附属固定参数分解PASS；softanchor、bad逆核与score/source价格未付，无新增实际root付款或FULL覆盖。** 绑定上述SHA后停止。


# 附件：soft_anchor_extension.md

# R130：soft-anchor 的统一逆权抵消与混合核缺口

**结论。** 以下 SA1–SA12 给出真实 φ/C 上、所有位置和合法尺度通用的一维 soft-anchor 逆权抵消。取 θ₀=2^(−14)、κ=63/64，可把冻结 HC 稿的 hard-anchor 引理扩展到完整 p_s 锚点，并在固定参数整维四来源矩中得到 e^(θ₀)exp(−ns/64) 因子。good 端 w_g(v)^(−θ₀) 完全消去；bad 端逆核费用、score、同源总预算及自适应参数仍未支付，因此尚无一般实际付款。

已先把精确命题和常数发送 source_budget_tools_r124 独审。本文不改冻结 hard_carrier_joint_geometry.md；特别修正合并时的下确界域：soft 部分须用整个 hard-z 区间 J 的 bad 核下确界，不能沿用仅在 J∩hard-y 上的 HC4。

## 1. 精确一维命题

令 h₁=1_[−1/2,1/2]、w(r)=∫₀¹exp(−|r|/t)dt、φ=h₁*w、F=max(h₁,φ)，以及
\[
C(d)=\int_{-1/2}^{1/2}F(u-d)du.
\]
所有函数都是原真实核。设 a≤L,R≤b≤2a、L≤H≤b，m₀=min(L,R)，J=[z−R/2,z+R/2]。令 k=q_(s,H) 或 q_(1,b)（后一种取 H=b）。本一维正核引理对 0≤s≤1 也成立；回原交通仍必须保留严格实际 s>1−2^(−1/n)。

设原权重
\[
\omega(v)=\min\{1,bC(|y-v|/b)/(c_jg)\}.
\tag{SA1}
\]
原 c_jg≤b 和 0<C≤1 保证 ω(v)≥C(|y−v|/b)。定义
\[
\theta_0=2^{-14},\qquad\kappa=\frac{63}{64}.
\]
**命题。** 对任意 y,z,v∈R，及任意 0<θ≤θ₀，
\[
\boxed{\frac1{m_0}\int_J
\phi\!\left(\frac{u-y}{L}\right)
\left[\frac{Hk(u-v)}{\omega(v)}\right]^\theta du
\le\kappa.}
\tag{SA2}
\]
这里不是来源概率平均；积分相对于真实一维接收 Lebesgue 测度，没有位置限制、源质量可比假设或对称性假设。

## 2. 原核包络：常数不依赖位置和尺度

φ 是偶、非增的概率密度，φ≤1。由已审 φ(1/2)>1/4，
\[
\phi\le F\le4\phi.
\tag{SA3}
\]
结合已审 logφ 的 4-Lipschitz 性，对全部实数 d、r、h，有
\[
C(d)\ge e^{-2}\phi(d)\ge\frac{e^{-2}}4F(d),
\qquad\frac{F(r-h)}{F(r)}\le4e^{4|h|}.
\tag{SA4}
\]
H≤b 与原核单调性给 Hk(u−v)≤F((u−v)/b)。由 ω≥C，进而
\[
\frac{Hk(u-v)}{\omega(v)}
\le A\exp\!\left(4\frac{|u-y|}{b}\right)
\le A\exp\!\left(4\frac{|u-y|}{L}\right),
\qquad A=16e^2.
\tag{SA5}
\]
此处只是保守常数；不需要优化。特别 SA5 对实际原混合核、m=1,2,3 都成立，不把 q_s 换成纯硬核。

## 3. θ=0 的统一 soft 质量缺口

先给完整显式常数。由 w(u)≤e^(−|u|) 和偶单调性，
\[
\|\phi\|_\infty=\phi(0)
\le2\int_0^{1/2}e^{-u}du
\le2\int_0^{1/2}(1-u+u^2/2)du
=\frac{19}{24}<\frac56.
\tag{SA6}
\]
对 x≥1/2，直接展开原卷积可得
\[
\phi(x)=\int_0^1t\bigl(e^{-(x-1/2)/t}-e^{-(x+1/2)/t}\bigr)dt.
\]
故双尾准确等于
\[
\begin{split}
\int_{|x|>1}\phi(x)dx
&=2\int_0^1t^2e^{-1/(2t)}(1-e^{-1/t})dt\\
&>2\cdot\frac12\cdot\frac14\cdot\frac13\cdot\frac12
=\frac1{24}.
\end{split}
\tag{SA7}
\]
末步只限制 t∈[1/2,1]，用 2<e<3；端点不影响积分。

当 R≤L 时，(1/m₀)∫_Jφ((u−y)/L)du 是 φ 在长 R/L 区间上的平均，至多19/24。当 R≥L 时，m₀=L、R/L≤2，由偶单调性其积分不超过∫_[−1,1]φ<23/24。因此统一采用较宽松常数
\[
\frac1{m_0}\int_J\phi((u-y)/L)du\le\rho_0:=\frac{31}{32}.
\tag{SA8}
\]
这一步不依赖 y,z，且 L/m₀≤2。

## 4. 小正 θ 的一致扰动界

令 X=U+Y，其中 U 为 [−1/2,1/2] 上均匀变量，Y 密度为 w，二者独立；这只是原 φ 的卷积表示，不对原来源 ν 作任何独立性假设。对 0≤a<1，
\[
\mathbb E e^{a|Y|}=2\int_0^1\frac{t}{1-at}dt\le\frac1{1-a},
\quad
\mathbb E|Y|e^{a|Y|}=2\int_0^1\frac{t^2}{(1-at)^2}dt
\le\frac{2}{3(1-a)^2}.
\]
由于 e^(1/4)<4/3，得到
\[
\mathbb E e^{|X|/2}<\frac83,
\qquad\mathbb E|X|e^{|X|/2}<\frac43\left(1+\frac83\right)
=\frac{44}{9}<5.
\tag{SA9}
\]
定义 F_θ=A^θ E exp(4θ|X|)。对 0≤θ≤1/8，A^(1/8)<2、log A<5，且可由 SA9 支配微分，因此
\[
F'_\theta
=A^\theta\mathbb E[(\log A+4|X|)e^{4\theta|X|}]
<2\left(5\cdot\frac83+4\cdot5\right)=\frac{200}3<67.
\tag{SA10}
\]
由 SA5，换元 r=(u−y)/L，并把非负的包络扰动扩大至整线，原 SA2 左侧至多
\[
\rho_0+\frac L{m_0}\int_{\mathbb R}\phi(r)
[A^\theta e^{4\theta|r|}-1]dr
\le\rho_0+2(F_\theta-1)
\le\rho_0+134\theta.
\tag{SA11}
\]
134·2^(−14)<1/64，而 31/32+1/64=63/64，证得 SA2。即使实际比值 Hk/ω 小于1，所用包络扰动仍非负，故扩大积分方向合法。

## 5. 与冻结 HC 的完整混合合并：必须换成全 J 下确界

回到 HC1 的四来源候选。对每个坐标 i 和同一个整维 m∈{1,2,3}，令 J_i=[z_i−R/2,z_i+R/2]，并定义
\[
d^J_{m,i}=H_m\operatorname*{ess\,inf}_{u\in J_i}k_m(u-z'_i)>0.
\tag{SA12}
\]
实际 s>0 保证正性。通常 d^J≤d^I，其中 d^I 是冻结 HC4 在 J_i∩hard-y 上的下确界；不能以较大的 d^I 替代 SA12。

记 HC1 的一维核为 \mathcal T_(m,i)，其准确线性分解仍是
\[
\mathcal T_{m,i}=(1-s)\mathcal H_{m,i}+s\mathcal S_{m,i}.
\]
冻结 HC6 的证明用更小的 d^J 仍合法，丢掉不超过1的区间交叠因子后给
\[
\mathcal H_{m,i}\le\frac{m_0}{RL}
\left(\frac{\omega_i(z')}{d^J_{m,i}}\right)^\theta\gamma^\theta,
\qquad\gamma=1+1/n.
\tag{SA13}
\]
soft 部分由 SA2 直接给
\[
\mathcal S_{m,i}
\le\frac1{RL}\left(\frac{\omega_i(z')}{d^J_{m,i}}\right)^\theta
\int_{J_i}\phi((u-y_i)/L)
\left[\frac{H_mk_m(u-v_i)}{\omega_i(v)}\right]^\theta du
\le\frac{m_0}{RL}\left(\frac{\omega_i(z')}{d^J_{m,i}}\right)^\theta\kappa.
\tag{SA14}
\]
于是完整原 p_s 锚点满足
\[
\boxed{\mathcal T_{m,i}\le\frac{m_0}{RL}
\left(\frac{\omega_i(z')}{d^J_{m,i}}\right)^\theta
[(1-s)\gamma^\theta+s\kappa].}
\tag{SA15}
\]
相乘时 θ 和 m 均为整维共同选择。由 γ^(nθ)≤e^θ、1−x≤e^(−x)，
\[
[(1-s)\gamma^\theta+s\kappa]^n
\le\gamma^{n\theta}e^{-ns(1-\kappa)}
\le e^\theta e^{-ns/64}.
\tag{SA16}
\]
因此冻结参数 HC2 的四来源接收矩被明确上界
\[
\boxed{e^\theta e^{-ns/64}\left(\frac{m_0}{RL}\right)^n
\sum_{m=1}^3
\left[\frac{w_g(z')}{\prod_i d^J_{m,i}}\right]^\theta.}
\tag{SA17}
\]
good 端 v 的全部逆权已消去，且 RHS 不再依赖 v；三个原整维测试的和仍保留。SA17 没有把 ν 乘积化，也没有把 hard z 移出。这里仍是固定共同参数的原核估计，不能以此免费冻结实际 x 依赖参数。

## 6. 费用与当前边界

SA17 的改善是完整 p_s 的统一 soft-anchor 缺口，不能把它称为已付源价格。原 bad 端费用 [w_g(z′)/∏d^J]^{θ} 仍在；全 J 下确界可能比冻结 HC 的交集下确界更小，不能隐去这项代价。真实 δ_t、Π_t 的双来源积分、外层 hard z 和 β、q、Σj/time/history 仍按 HC/RT 原账保留。

原 high-pe 与共同 FIRST 继续给 ∫_(S_g)w_gdν≤Kq/p≤e_g/2 及∫Jdν≤q，但本文未把 SA17 的 bad 费用与这些容量耦合成一般预算，也没有证明其大费用域必被 high/RC 排除。SA2–17 不消费 N_Zc 或 N_del，不取回已消费 N_Z。

尤其原下门 s>1−2^(−1/n) 允许 ns 仅为常数量级；此时 exp(−ns/64) 仅是常数下降，不能据此宣称自动吸收维度、尺度或 bad 端费用。原 RC 余权在 HC2 左侧完整保留，本核上界仅用其≤1，未新增 RC 覆盖或费用。

**最终范围。** SA2 是所有位置/合法尺度的一般真实核引理，SA15–17 是其对完整四来源固定参数矩的推论。一般根阶来源付款、当前自适应交通及最终 signed 吸收仍未证明。本稿完成后停止，等待独审。


# 附件：soft_anchor_statement_audit.md

# R130 soft-anchor：保守常数命题先行独审

STATEMENT_AUDIT_STATUS: PASS_FOR_FIXED_PARAMETER_LEMMA
ROOT_PAYMENT_STATUS: UNPROVED

仅审父任务给出的准确命题及常数，未读取新作者证明。采用最终候选 θ₀=2^(−14)、κ=63/64、A=16e²；此前较锐常数不参与本审。真实φ=h₁*w，w(u)=∫₀¹e^(−|u|/t)dt，F=max(h₁,φ)，C为完整单位区间F质量。

## 1. 命题与尺度量词

固定a≤L,R≤b≤2a，L≤H≤b，m=min(L,R)，0<c_jg≤b。J为任意长度R的实区间，来源y,v任意有限实位置。k=q_(s,H)，全部s∈[0,1]（或k=φ_H=q_(1,H)）；ω(v)=min(1,b C(|y−v|/b)/(c_jg))。结论

\[
\frac1m\int_J\phi((u-y)/L)
\left[\frac{Hk(u-v)}{\omega(v)}\right]^{\theta_0}du\le\kappa
\]

成立且常数独立全部位置/尺度/s。纯硬s=0核在零点取0^θ₀=0，该局部核引理可含边界s；不授予原实际s=0交通。原P_s的实际strictsoftness保持。

## 2. 核包络与饱和权：PASS

φ偶径向递减，0<φ≤1；原尾及核公式给φ(1/2)>1/4，故F≤4φ：硬区间内F=1≤4φ，外部F=φ。可直接证明全局logφ的Lipschitz常数4：核心区用|φ′|≤1及φ≥φ(1/2)>1/4；尾部负log导数是1/t的正指数倾斜均值，其随r下降，最大边界值≤1/φ(1/2)<4。

完整C及log-Lipschitz给

\[
C(d)=\int_{d-1/2}^{d+1/2}F(u)du
\ge\int_{d-1/2}^{d+1/2}\phi(u)du
\ge e^{-2}\phi(d)\ge e^{-2}F(d)/4.
\]

C≤1且c_jg≤b，因此ω(v)≥C(|y−v|/b)，包括权重饱和分支。H≤b及核单调性给Hk(u−v)≤F((u−v)/b)。再用F(r)/F(d)≤4exp(4|r−d|)及b≥L，得到

\[
\frac{Hk(u-v)}{\omega(v)}
\le16e^2\exp(4|u-y|/b)
\le A\exp(4|u-y|/L).
\]

不漏饱和情况，也不需要v相对y/J的额外位置限制。

## 3. θ=0的全窗口基线：PASS，独立更强界

令r=R/L∈[1/2,2]，X具有概率密度φ。零倾斜基线是 `(1/min(1,r))∫_{J'}φ`，J′长r。

r≤1时不超过φ(0)。原卷积给φ(0)=1−2∫₀¹t e^(−1/(2t))dt；限制t∈[1/2,1]得该积分≥3/(8e)>1/8，故φ(0)<3/4<5/6。这独立证明父任务所用宽松峰值界。

r>1时m=L；偶递减φ使任意长≤2区间质量不超过∫_{−1}¹φ。由真实尾积分直接积分得

\[
2\int_1^\infty\phi(x)dx
=2\int_0^1t^2e^{-1/(2t)}(1-e^{-1/t})dt.
\]

限制t∈[1/2,1]，用e<3、1−e^(−1)>1/2，得到双尾> `2·(7/24)·(1/3)·(1/2)=7/72>1/24`。因此基线<23/24<31/32。两种尺度顺序合并可安全用统一31/32；不是只在居中J检验。

## 4. 指数扰动与数值常数：PASS

写X=U+Y，U均匀于[−1/2,1/2]、Y密度w，独立卷积得φ。这里是核表示的辅助概率，不假定原f/ν为产品。由w真实指数混合，

\[
\mathbb E e^{|Y|/2}=2\int_0^1\frac{t}{1-t/2}dt<2,
\qquad
\mathbb E |Y|e^{|Y|/2}=2\int_0^1\frac{t^2}{(1-t/2)^2}dt<8/3.
\]

e^(1/4)<4/3，|U|≤1/2和三角不等式给

\[
\mathbb E e^{|X|/2}<8/3,\qquad
\mathbb E |X|e^{|X|/2}<\frac43(1+8/3)=44/9<5.
\]

令Z(θ)=A^θ E exp(4θ|X|)。对0≤θ≤1/8，logA=log16+2<5且A^θ≤A^(1/8)=√2 e^(1/4)<2；可在更大有限指数矩域内微分，或用点态 `e^{θV}−1≤θV e^{θV}`。于是

\[
Z'(\theta)\le2[5\cdot(8/3)+4\cdot5]
=200/3<67,
\quad Z(\theta)-1\le67\theta.
\]

由L/m≤2，将J内的正扰动扩大到整线，得候选积分≤基线+2[Z(θ)−1]≤31/32+134θ。θ₀=1/16384满足134θ₀<1/64（134<256），所以最终积分<63/64。不使用浮点边界猜测，全部常数方向正确。θ₀≤1/8也满足指数矩域。

## 5. full mixed anchor合并的正确bad域及未付价格

若接下来用于HC1，应令 `d^J_(m,i)=H_m essinf_{u∈J_i}k_m(u−z′_i)`，J_i为**整个hard-z区间**。实际s>0及有限J/位置保证d^J>0，但不给统一下界。HC4的交集I=J∩hard-y上的d^I≥d^J，不能控制J\I上的soft-anchor；直接复用d^I会反向放大坏核下界。

使用正确d^J，softanchor项S_(m,i)满足

\[
S_{m,i}\le\frac{m}{RL}\kappa
\left(\frac{\omega_i(z')}{d^J_{m,i}}\right)^{\theta_0}.
\]

hard项可用HC6但换成较小d^J并删交叠损失≤1；在原比例带c_jg≤γm下，原混合核的每坐标完整线性分解给

\[
T_{m,i}\le\frac m{RL}
\left(\frac{\omega_i(z')}{d^J_{m,i}}\right)^{\theta_0}
[(1-s)\gamma^{\theta_0}+s\kappa].
\]

同一个整维测试m各坐标相乘，不重选坐标赢家，且

\[
[(1-s)\gamma^{\theta_0}+s\kappa]^n
\le e^{\theta_0}\exp(-ns/64).
\]

因此确可在full product mixture上消掉good端逆权，而非只保留全hard掩码；但仍有 `(m/(RL))^n [w_g(z′)/∏_i d^J_(m,i)]^{θ₀}` 的bad逆核费、一次三测试求和及原δ/score/RC/FA/history来源积分。原合法软度下端s约为log2/n，ns只为常数量级，不能据此宣称统一e^(−cn)衰减或根阶预算。

**最终声明PASS：** 上述全位置单坐标soft lemma及正确全J下确界下的mixedanchor条件合并成立。bad source费用、score和ν³/e_t²/β−ν/自适应层价仍未付；N_Zc/N_del各一次未消费，原账不变。未读作者长证明、未执行数值；先行审查到此停止。

## 冻结作者证明的增量独审

FINAL_PROOF_AUDIT_STATUS: PASS_FOR_SA2_AND_FIXED_PARAMETER_SA15_17
GLOBAL_SOURCE_PAYMENT_STATUS: UNPROVED

先行常数/域审查完成后读取 `soft_anchor_extension.md`，最终实读并复核SHA-256：`c9138233454c720c14c9147ac963fb11fab4169a4dc5bafe4206aca25d4908e6`。未修改作者稿、未重跑数值。以下对照实际冻结稿，不以主代理结论作为证明依据。

- **SA3–5核包络PASS。** F≤4φ、logφ的4-Lipschitz、完整C≥e^(−2)φ及ω≥C给A=16e²；H≤b与b≥L两次缩放方向正确。适用于所有s∈[0,1]的本核引理，也包含纯soft测试H=b；没有把实际strictsoftness换为0。
- **SA6–8作者保守基线PASS。** w(u)≤e^(−|u|)，φ(0)≤2∫₀^{1/2}e^(−u)du≤2∫₀^{1/2}(1−u+u²/2)du=19/24，合法且足够。SA7在t∈[1/2,1]用区间长1/2、t²≥1/4、e^(−1/(2t))>1/3、1−e^(−1/t)>1/2，双尾>1/24正确。任意长R/L≤2的区间质量由偶递减性受居中长2区间控制；R≤L时按平均峰值界，R≥L时按概率质量界，统一31/32没有漏L/m因子。与先行更强界一致，无需改常数。
- **SA9–11扰动PASS。** 两个真实w矩公式、三角不等式、e^(1/4)<4/3给X矩<8/3及44/9<5；θ≤1/8的导数受这些有限指数矩控制，A^(1/8)<2且logA<5给F′<200/3<67。包络扰动A^θexp(4θ|r|)−1非负，扩大至整线方向正确，L/m≤2只出现一次；134·2^(−14)<1/64是严格有理比较。作者SA2对整个0<θ≤θ₀均成立，非只θ₀单点。
- **SA12–15全J bad下确界与完整mixed分解PASS。** d^J在整个hard-z区间取essinf，实际s>0及紧区间保证局部正性。d^J≤d^I，故换较小d^J的hard bound只是变粗；soft项分母以全J下界控制、H_m因子由SA2正确抵消，正是SA14。完整每坐标 `(1−s)H+sS` 相乘保留全部mixed掩码，不能只留全hard项。原m、θ为整维共同选择，不按坐标重选测试。
- **SA16–17乘积下降及费用PASS于固定参数。** 因γ^θ≥1，`(1−s)γ^θ+sκ≤γ^θ[1−s(1−κ)]≤γ^θexp(−s/64)`；取n次方再用γ^(nθ)≤e^θ，得到e^θexp(−ns/64)合法，s=0或1的边界也没有遗漏。SA17保留 `(m₀/(RL))^n`、三整维测试和及 `[w_g(z′)/∏d^J]ᶿ`，good端v逆权确已消去。没有用来源坐标独立或把hard z帽重复领取。

作者第177–183行准确保留了全J下确界更小的bad逆核价格、原δ/score、RC、FA/Ψ、ν³/e_t²、β−ν、q、Σj/time/history及自适应共同参数费用。实际软度下端允许ns常数量级，exp(−ns/64)不足以自动支付多项式或未知bad费用；FIRST/high-pe的正质量帽没有被误用为逆核/score预算。N_Zc/N_del各一次均未消费，已消费N_Z不返回，原账不变。

**最终绑定稿PASS范围：SA2全位置soft核lemma与SA15–17固定参数完整mixed推论。一般根阶来源付款和最终signed吸收仍UNPROVED。** 审查到此停止。


# 附件：threshold_numeric_note.md

协议先冻结：Fraction三阶段4/6/6，共16例。a均匀于[0,1]，D_i为a+r_i<0，S_j为a+r_j≥0，high为a≤c。oracle按0、1、c及所有合法−r_i折点独立切分，用区间中点判门、乘长度；不调用clip闭式。核成对平均=(u_j−u_i)_+，u_i=clip(c+r_i,0,c)。无mask时核T子概率质量m及原始中心矩，m=0不除法；有Ψ仅核成对加权和，协方差N/A。菜单含等号、c=0/1、饱和、T非全源、零质量及k最高6561/10000，r/c为有理；扩大原子数至12，不算真实高维kernel。所有失败/残差保留。只认证有限精确代数，不认证一般费用。

执行完成：仅一次脚本运行，退出0，16/16 PASS；561对残差均为0，12项有定义无mask协方差一致，2个mask/2个零m为N/A。JSON保留执行前协议快照和SHA，未用执行后笔记冒充前置协议。


# 附件：hard_carrier_numeric_note.md

# R130 HC5–6：12例双精度有限核观察协议

**菜单冻结后运行，不追加、不按结果调参。** 原对象为 `hard_carrier_joint_geometry.md` §2：I是同一hard-z与hard-y区间交叠，ω(v)=min(1,bC(|y−v|/b)/(cjg))，k_m=q_(s,Hm)（m1/2）、k3=q_(1,b)。本任务仅固定参数的一维真实核观察，不授FIRST/FULL、真实来源付款或根阶结论。

全部n=6561、y=0、g=1。γ=1+1/n；组A：j=0,cj=1,L=R=b=1,a=1/2；组B：j=1,cj=1/γ，L=(cj+cj/γ)/2，R=1/L,b=R,a=b/2。后者L≤cjg≤γL且a≤L,R≤b，故保留真实比例。H1=L、H2=min(b,γL)、H3=b。实际软度下门s0=1−2^(−1/n)，记s近=s0+2^−24，s极近=s0+2^−40；两者严格在原软度域内，m3核软度仍固定1。θ全坐标共同，仅核标量。

## 冻结菜单（每阶段4例）

所有位置均为原一维坐标，不是自由核值；组B的位置中b/R/L取本组实际值。

|ID|阶段/组|z（hard载体中心）|v|z′|m|实际s|θ|目的|
|---|---|---|---|---|---|---|---|---|
|1|初探/A|2|2|−1|1|s近|1/2|I空；HC5=0，HC6不定义d|
|2|初探/A|0|0|0|1|s近|1/2|I满、ω(v)饱和|
|3|初探/A|63/64|2|0|2|s近|1/2|I短、低ω|
|4|初探/A|0|2|2|3|1|1|满I、全软小ω，HC5紧侧|
|5|压力/A|63/64|1/2|2|1|1|1/2|短I、全软|
|6|压力/A|0|1/4096|1/2|2|1|1|接近饱和、硬面切分|
|7|压力/A|0|4|4|3|s近|1/2|极小ω、第三分量仍全软|
|8|压力/A|1/2|−3/4|3/4|1|s极近|1/2|半I、正软度近下门、分母硬面|
|9|扩大/B|0|1/4096|0|1|s近|1/2|真实j=1、饱和、H1|
|10|扩大/B|(R+L)/2−1/64|2b|−b|2|1|1/2|短I、H2|
|11|扩大/B|R/2|b/2|2b|3|s极近|1|半I、H3全软|
|12|扩大/B|0|4b|−4b|2|s近|1/2|满I、H2、小ω与bad逆核费用|

每例用既有vendor mpmath1.3.0分别30、50digits；24条观察完整保存。原φ由J(A)=E3(A)两分支计算，J(0)=1/2。C独立计算∫[-1/2,1/2]F(u−d)du，F=max(h1,φ)，切分F的硬面；不用HC5理论min或C替代真实核积分。

I再按v/z′的核硬面、φ分支面及中心切分。Gauss–Legendre quad maxdegree=6，每例每精度总积分被积函数请求数上限20000；超限/异常原样保存，不升阶重跑。quad误差只是程序估计，不是区间证书。

保存HC5实际左值、右值cjg/Hm、未裁比值；HC6用d=Hm·essinf_I k_m(u−z′)（非空I由径向单调取最远端点的一侧值）计算实际hard-anchor积分及HC6两层右边/比值，保存ω(v/z′)、raw权重、l、d、所有实际参数和合法性检查。I空时hard积分为0、HC6为N/A，不制造0^0或空集essinf。

双精度差仅为稳定性观察；比值若浮点略大于1仍原样输出，不以容差/min裁成通过，也不称解析反例。所有结果保存 `hard_carrier_results.json`。Python使用既有bundled路径，PYTHONPATH指向既有vendor，不安装包。执行完仍不授予全维交通、FIRST/FULL或根阶界。

## 同菜单新增V观察（开跑前重新冻结）

主代理确认m=min(L,R)，J为完整hard-z区间[z−R/2,z+R/2]，不是I。每例另算

`V=m^−1∫_J φ((u−y)/L)[Hm k_m(u−v)/ω(v)]^(2^−14)du`，

保存V、V/(63/64)、原始比较及两精度差。使用同一φ/C缓存，按anchor与分量核的中心/分支面切分；不新增例、不删区间，不把V截到63/64。该候选仍待解析审查；有限V观察不认证全参数常数。
