"""16 frozen exact scalar checks; not a physical high-dimensional kernel test."""
import hashlib
import json
from fractions import Fraction as F
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def case(name, stage, c, r, k, p, terminal=None, masked=False, n=None):
    return dict(case_id=name, stage=stage, c=F(c), r=[F(x) for x in r], k=list(k),
                p=[F(x) for x in p], terminal=list(range(len(r))) if terminal is None else list(terminal),
                psi=None if not masked else [[(i + 2 * j) % 3 != 0 for j in range(len(r))] for i in range(len(r))],
                n_integer_score_cap=n)


def menu():
    r, p = [F(-1, 2), 0, F(1, 2)], [F(1, 4), F(1, 2), F(1, 4)]
    configs = [case("positive_cov", 1, F(3, 4), r, [0, 1, 2], p, n=2),
               case("negative_cov", 1, F(3, 4), r, [2, 1, 0], p, n=2),
               case("constant_k", 1, F(3, 4), r, [1, 1, 1], p, n=2),
               case("proper_terminal", 1, F(3, 4), r, [0, 1, 2], p, terminal=[0, 2], n=2),
               case("zero_high_cap", 2, 0, [-1, 0, 1], [0, 1, 2], [F(1, 3)] * 3, n=2),
               case("unit_cap_and_equalities", 2, 1, [-2, -1, F(-1, 2), 0, 1],
                    [0, 2, 4, 1, 3], [F(1, 5)] * 5, n=4),
               case("tied_scores", 2, F(1, 2), [F(-1, 4)] * 3,
                    [0, 2, 1], [F(1, 3)] * 3, n=2),
               case("zero_probability", 2, F(1, 2), r, [0, 1, 2], [0, 0, 0], terminal=[0, 2], n=2),
               case("empty_terminal", 2, F(1, 3), r, [0, 1, 2], p, terminal=[], n=2),
               case("masked_proper_terminal", 2, F(1, 2), [F(-3, 4), F(-1, 2), 0, F(1, 2)],
                    [0, 3, 1, 2], [F(1, 4)] * 4, terminal=[0, 2, 3], masked=True, n=3)]
    for size in (4, 8, 12):
        for n in (6561, 10000):
            scale = F(1) if n == 6561 else F(1, 2)
            total = size * (size + 1) // 2
            probabilities = [scale * F(i + 1, total) for i in range(size)]
            scores = [F(i - size // 2, size // 2) for i in range(size)]
            counts = [n * i // (size - 1) for i in range(size)]
            terminal = list(range(size)) if n == 6561 else [i for i in range(size) if i % 3 != 1]
            configs.append(case(f"expanded_{size}_kcap{n}", 3, F(4, 5), scores, counts, probabilities,
                                terminal=terminal, masked=(n == 10000 and size == 8), n=n))
    return configs


def encode(value):
    if isinstance(value, F):
        return dict(numerator=value.numerator, denominator=value.denominator)
    if isinstance(value, dict):
        return {k: encode(v) for k, v in value.items()}
    if isinstance(value, (tuple, list)):
        return [encode(v) for v in value]
    return value


def threshold_oracle(c, scores):
    """Direct threshold integration: no use of u, clip, covariance or pair formula."""
    cuts = sorted({F(0), F(1), c, *[-r for r in scores if 0 < -r < 1]})
    averages = [[F(0) for _ in scores] for _ in scores]
    segments = []
    for left, right in zip(cuts, cuts[1:]):
        middle = (left + right) / 2
        dark = [middle + r < 0 for r in scores]
        surviving = [middle + r >= 0 for r in scores]
        high = middle <= c
        for i in range(len(scores)):
            for j in range(len(scores)):
                if high and dark[i] and surviving[j]:
                    averages[i][j] += right - left
        segments.append(dict(left=left, right=right, midpoint=middle,
                             D=dark, S=surviving, high=high))
    endpoints = [dict(a=a, D=[a + r < 0 for r in scores], S=[a + r >= 0 for r in scores], high=a <= c)
                 for a in cuts]
    return averages, cuts, segments, endpoints


def check(config):
    c, r, k, p, terminal = (config[name] for name in ("c", "r", "k", "p", "terminal"))
    size = len(r)
    assert 0 <= c <= 1 and size == len(k) == len(p)
    assert all(isinstance(x, int) and not isinstance(x, bool) and 0 <= x <= config["n_integer_score_cap"] for x in k)
    assert all(x >= 0 for x in p) and sum(p, F(0)) <= 1
    assert len(set(terminal)) == len(terminal) and all(0 <= i < size for i in terminal)
    oracle, cuts, segments, endpoints = threshold_oracle(c, r)
    u = [min(c, max(F(0), c + x)) for x in r]
    pairs, fail = [], []
    closed = [[F(0) for _ in r] for _ in r]
    for i in range(size):
        for j in range(size):
            closed[i][j] = max(F(0), u[j] - u[i])
            residual = oracle[i][j] - closed[i][j]
            pairs.append(dict(i=i, j=j, oracle=oracle[i][j], closed=closed[i][j], residual=residual,
                              status="PASS" if residual == 0 else "FAIL"))
            if residual != 0:
                fail.append(f"pair_{i}_{j}")
    mask = config["psi"]
    allowed = lambda i, j: mask is None or mask[i][j]
    weighted_oracle = sum((p[i] * p[j] * (k[j] - k[i]) * oracle[i][j]
                           for i in terminal for j in terminal if allowed(i, j)), F(0))
    weighted_closed = sum((p[i] * p[j] * (k[j] - k[i]) * closed[i][j]
                           for i in terminal for j in terminal if allowed(i, j)), F(0))
    aggregate_residual = weighted_oracle - weighted_closed
    if aggregate_residual != 0:
        fail.append("weighted_pair_sum")
    mass = sum((p[i] for i in terminal), F(0))
    covariance = dict(status="N/A", value=None, m_squared_covariance=None, residual=None)
    if mask is not None:
        covariance["reason"] = "Psi masked: only the pairwise formula is claimed, not covariance"
    elif mass == 0:
        covariance.update(reason="zero terminal mass: normalized p/m is undefined", zero_mass_identity=weighted_oracle == 0)
        if weighted_oracle != 0:
            fail.append("zero_mass")
    else:
        Ek = sum((p[i] * k[i] for i in terminal), F(0)) / mass
        Eu = sum((p[i] * u[i] for i in terminal), F(0)) / mass
        Eku = sum((p[i] * k[i] * u[i] for i in terminal), F(0)) / mass
        cov = Eku - Ek * Eu
        residual = weighted_oracle - mass ** 2 * cov
        covariance = dict(status="PASS" if residual == 0 else "FAIL", Ek=Ek, Eu=Eu, Eku=Eku,
                          value=cov, m_squared_covariance=mass ** 2 * cov, residual=residual)
        if residual != 0:
            fail.append("covariance")
    return dict(input=config, cuts=cuts, threshold_segments=segments, endpoint_gate_truth=endpoints,
                u=u, pairs=pairs, terminal_mass=mass, weighted_oracle=weighted_oracle,
                weighted_closed=weighted_closed, weighted_pair_residual=aggregate_residual,
                covariance=covariance, failures=fail, status="PASS" if not fail else "FAIL")


def main():
    configs = menu()
    counts = {stage: sum(c["stage"] == stage for c in configs) for stage in (1, 2, 3)}
    assert len(configs) <= 20 and counts == {1: 4, 2: 6, 3: 6}
    rows = []
    for config in configs:
        try:
            rows.append(check(config))
        except Exception as exc:
            rows.append(dict(input=config, status="ERROR_RETAINED", error_type=type(exc).__name__, error=str(exc)))
    passed = sum(row["status"] == "PASS" for row in rows)
    note = ROOT / "threshold_numeric_note.md"
    report = dict(schema="FINITE_EXACT_THRESHOLD_CERTIFICATE_V1", arithmetic="Fraction", seed=None,
                  source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                  protocol_pre_execution_sha256=hashlib.sha256(note.read_bytes()).hexdigest(),
                  protocol_pre_execution_text=note.read_text(), stage_counts=counts, results=rows,
                  expected_cases=len(configs), observed_cases=len(rows), passed_cases=passed,
                  failed_or_error_cases=len(rows) - passed,
                  status="PASS_FINITE_EXACT_ALGEBRA" if passed == len(configs) else "FAILURES_RETAINED",
                  physical_high_dimension_kernel_certified=False, general_fee_evidence=False)
    output = ROOT / "threshold_exact_results.json"
    output.write_text(json.dumps(encode(report), ensure_ascii=False, sort_keys=True, indent=2) + "\n")
    print(json.dumps(dict(status=report["status"], cases=len(rows), passed=passed,
                          output=str(output), sha256=hashlib.sha256(output.read_bytes()).hexdigest()), sort_keys=True))
    return 0 if passed == len(configs) else 1


if __name__ == "__main__":
    raise SystemExit(main())
