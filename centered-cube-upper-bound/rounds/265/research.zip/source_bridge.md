# R265: fixed-original-time source bridge and its remaining heavy price

This is a bounded conditional source-use result for the **two moving legs only**. It neither repeats the J payment nor closes the original traffic. Its time estimate is an application of the existing R245 weighted energy; the remaining heavy ratio is the same previously unpaid source obstruction, not a new payment.

## S1. Authentic objects and allowed-scale cut

Fix the original seed, leaf V, j, soft source y and original time t. R128 frozen `proof.md:637,646–650` gives τ=a/c_j, g≤bc_j, J_far⊂[τ,h], h≤g and Π_{y,j,t}=1_{Z_t}w_tν/e_t independent of x. Actual physical parameters remain functions of x. The original ratio band gives

c_jt≤c_jg≤γ min(L,R)≤γL,  γ=1+1/n.

Hence every permitted receiver has

L≥ℓ_t:=max(a,c_jt/γ).

The posterior remains Π_{y,j,t} throughout; no substitution t=u g(x) is made. The heavy set I_y is an initial interval with endpoint T_y≤bc_j, and

e_t>B_jt^n,  B_j=ell q c_j^{-n/2},  ell=1+log n.

These are R117 `joint_geometry.md:25–32`. Empty and singleton I_y have zero continuous contribution. At an open endpoint use inner limits; no extra endpoint deletion is added.

## S2. A concrete fixed-t square column from the already-proved kernel tools

Use the R222 already-hardcapped near remainder, retaining its exact conditional mask η and its receiver support. Put d=a/(8√n), W_y=Q_{b+d}(y), ε=d/b. The near gate is ||y-z||_1≤d/2. R264 frozen `proof.tex.txt`, common-window formula (5), Abel formula (1), and its low-soft upper menu apply on this W_y.

Assume the actual low-soft receiver has 0≤s(x)≤s_0≤1/2. Let

c_n=(1+1/n)^n,   M≤2(n+1)s_0+2,
D=8 c_n² M exp(n ε s_0²).

Here M is the actual finite upper-soft menu size, or M=1 when s_0=0. The number 8 is two moving legs, each with Abel constant 2, followed by (u+v)²≤2(u²+v²); there is one shared upper menu, not M². The square of its half-kernel comparison costs c_n². No node FIRST is claimed.

Let K_1=P_{s,L}(x-v), K_2=P_{s,min(b,γL)}(x-v), p_y=P_{s,L}(x-y), and define

F_{y,v}(x)=1_{W_y}(x) [sqrt(p_y(x)K_1(x,v))+sqrt(p_y(x)K_2(x,v))]/sqrt(barw_{L(x)}(y,v)).

For arbitrary measurable selectors L(x)≥ℓ_t, both moving legs satisfy the genuine Lebesgue column bound

(1)  ∫F_{y,v}(x)²dx≤D ℓ_t^{-n},

uniformly in v. Proof: apply common-window (5) to each fixed upper-soft node, discard its favorable gap, apply Abel on the restricted scale set [ℓ_t,b], then sum the leg/node squares and apply the displayed factor 2. Restricting the scale interval changes the factor a^{-n} in Abel to ℓ_t^{-n}. If ℓ_t>b the allowed set is empty. Thus (1) is an actual proved kernel bound, not a newly defined column-norm assumption. It sacrifices the R264 gap/relative-clock gain deliberately to keep original t and Π fixed before dx.

The R222 positive outside constant is

C_out=(32Λ/3)sqrt(K/3) γ^{n/2}.

It already contains the one comparison w_g^{-1/2}≤γ^{n/2}barw_L^{-1/2}. It must not receive another copy of this comparison. No hard source, q^{-1}, or h_R is reinserted after R222. All original near/high/good/capture/history restrictions stay in a mask 0≤χ≤1 below; positive removal in a bound does not assign their restrictions to a negative term.

## S3. Same-posterior score, exact energy, and the explicit row price

For independent copies k,k' under the **same original** Π_t define

G_t=E_{Π_t⊗Π_t}(k-k')_+,
V_t=Var_{Π_t}(k),   0≤k≤n.

The elementary identities are

E(k-k')_+²=V_t,    G_t²≤V_t/2,    G_t≤n/4.

For arbitrary original positive masks χ(x,y,t,v,u)≤1 put (when the actual L(x)<ℓ_t, the valid-clock mask is zero; extend F by zero there)

B_{y,t}(x)=∬χ (k_t(v)-k_t(u))_+ F_{y,v}(x) Π_t(dv)Π_t(du),
H_{y,j}(x)=∫_{I_y} B_{y,t}(x)dt/t,

where χ is zero outside the actual J_far and receiver leaf/j domain. Minkowski at fixed t is legal since Π_t does not depend on x. Formula (1) implies ||B_{y,t}||_2≤sqrt(D)ℓ_t^{-n/2}G_t.

R245 `score_flux.md`, SF7, proves with all actual coordinate births and deletion losses retained

∫_{I_y}e_t V_t dt/t≤n e_τ.

Therefore, writing R_yj=e_τ(y)/(B_jτ^n)>1 on a nonempty heavy row and L_y=log(T_y/τ), Cauchy gives

(2) ||H_{y,j}||_2²
 ≤ D n e_τ/2 · ∫_{I_y}ℓ_t^{-n}/e_t dt/t
 ≤ (D γ^n/4) a^{-n} R_yj [1-(τ/T_y)^{2n}].

Indeed ℓ_t^{-n}≤γ^n c_j^{-n}t^{-n} and the last integral is at most γ^n c_j^{-n}(1-(τ/T_y)^{2n})/(2n B_jτ^{2n}). This is the exact cancellation of n in this particular time Cauchy. The γ^n here comes from ℓ_t≥c_jt/γ, not from another w_g comparison.

The direct Gini bound is available at the same time:

(3) ||H_{y,j}||_2≤sqrt(D)a^{-n/2} n L_y/4.

Consequently set

r_yj=min{n L_y/4, (1/2)sqrt[γ^n R_yj(1-e^{-2nL_y})]}.

Then ||H_{y,j}||_2≤sqrt(D)a^{-n/2}r_yj. This is a data-adaptive minimum of two fully proved prices. It must not be described as a new source-root bound. A singleton heavy row has L_y=r_yj=0, regardless of its endpoint value. No negative traffic is used in (1)-(3).

## S4. Full-source square-row criterion, with all prices

The preceding bounds retain the authentic source β_V. Let

Z_{ω,V}²=Σ_j [∫ r_yj β_V(dy)]²,

where empty rows are zero and the j sum is over the original permitted finite set. Actual j(x) is unique and independent of source integration. Thus its disjoint receiver masks give an ℓ² sum, rather than declaring Σ_j Π_j a probability. Minkowski in β, followed by this disjointness and receiver Cauchy, proves for the sum P_mov of the two original moving-leg half-density positive upper bounds

P_mov≤C_out sqrt(D)a^{-n/2}
       E_ω Σ_V |E_{ω,V}|^{1/2} Z_{ω,V}.

The displayed receiver sum is the unconditional conclusion used here. Source leaves being disjoint does not alone make the transformed receiver sets E_{ω,V} disjoint. In the original unexpanded positive traffic R112 frozen `proof.tex.txt:520,528` explicitly retains the common-leaf gate and says Q_x is contained in the unique leaf; R107 frozen `proof.md:980` defines Good_2 by Q_x∪{y} lying in one finest cell; `:1005` explicitly inserts near/Good_2/terminal eligibility, and `:1016` states that every x has at most one nonzero leaf row, retained for subsequent hard submeasures. Only if that receiver gate is explicitly retained in the current transformed quantity may one additionally infer E_{ω,V}⊂V and use Σ_V|E_{ω,V}|≤|E|. That inheritance is not presumed for a relaxed/enlarged receiver quantity.

Without that extra verification, individual Young gives only

(4) P_mov≤ε_Y λ E_ωΣ_V|E_{ω,V}|
 + [256Λ²K γ^n D/(27 ε_Y)]
       E_ω Σ_V Z_{ω,V}²/(λ a^n).

Its first term is a **receiver-multiplicity price**, not ε_Y X unless the original common-leaf receiver gate has been retained. The numerical constant is C_out²/4. If one declines this Young relaxation, keep the preceding exact full receiver sum instead. No leaf-source disjointness is substituted for receiver disjointness.

P_mov is not the whole original positive remainder: its J upper-bound component is excluded and assigned no price here. If working with an actual allocated source subtraffic, the original allocation λ_i=√K_i/(√K_1+√K_2+√J) gives λ_1+λ_2 times the original positive at most this same two-leg upper bound; zero total kernel is assigned zero. All β masses, actual heavy ratios, finite j prices, a dimensions and the one seed expectation remain visible. Infinite right sides give an extended nonnegative bound, not an indeterminate subtraction. Finite truncation then Tonelli/Minkowski supplies the general version. If one uses (2) alone instead of r_yj, its additional 1/4 and γ^n appear inside Z, not again outside.

Thus an actual square-row budget for EΣZ²/(λa^n), **together with the real receiver multiplicity price**, is a specific sufficient source criterion at exactly (4)'s displayed cost. It is not an assertion that either follows from FIRST. R224 TR2/SB9 still gives A_x,t≤q and C_x,t≤min(1/(2K),||β||/(B_jt^n)) at a fixed receiver, but it does not bound this β-integral of initial heavy ratios after the positive receiver relaxation. Applying the independent-target source Cauchy would remove the anchor factor p_y needed by (1); it cannot be combined as though both factors survived unchanged.

## S5. Relation to the old gap and available negative accounts

The factor R_yj in (2) is precisely the old heavy-conversion obstacle of R245 SF4, now expressed after a physical-column t^{-n} integration. The calculation is a legal fixed-t source bridge; it is not registered as a new generally paid estimate. In particular nothing here proves a small Z budget from sourceborn cut, hard rank, low-neighborhood occupation, or coupled ν≤β.

There is no presently established negative-budget estimate controlling R_yj or Z. R223 `negative_contract.md` NC4/NC10 separates N_del (continuous reverse pairs involving future-deleted sources) from actual jumps of e_t. The original negatives multiply the raw p_y h_R a_ω βν/q mother; NC5 explains why changing only the positive term to the R222 half-density coefficient does not transfer those negatives. R262's paid initial/bad-boundary account is already consumed, not storage for the initial degree. Any new cancellation would have to return to that full common mother with all actual gates. Thus the sufficient square-row criterion in S4 remains unproved by the allowed accounts.

## S6. Bounded arithmetic verification

The embedded check below uses exact Fraction posterior laws to verify Eδ²=Var and G²≤Var/2 (12 laws), and local mpmath quadrature to verify the heavy power-integral primitive (4 cases). It diagnoses only the budget algebra, not original history or a source/FULL instance. Analytic proofs above establish the measure statements.

Actual output: `PASS 16 exact_posterior_laws 12 power_integrals 4 max_abs_error 1.43492962747e-42`, exit 0. Complete bounded replay:

```python
from fractions import Fraction as F
import sys
sys.path.insert(0,'/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor')
import mpmath as m
m.mp.dps=40
checks=0
for n in (1,2,8,32):
    for probs in ([F(1,2),F(1,3),F(1,6)],[F(1,7),F(2,7),F(4,7)],[F(0),F(1),F(0)]):
        ks=[F(0),F(n,2),F(n)]
        mean=sum(p*k for p,k in zip(probs,ks))
        var=sum(p*(k-mean)**2 for p,k in zip(probs,ks))
        g=sum(p*q*max(k-l,0) for p,k in zip(probs,ks) for q,l in zip(probs,ks))
        sec=sum(p*q*max(k-l,0)**2 for p,k in zip(probs,ks) for q,l in zip(probs,ks))
        assert sec==var and 2*g*g<=var and g<=F(n,4)
        checks+=1
err=m.mpf(0)
for n in (1,2,8,32):
    tau=m.mpf('1.3');T=m.mpf('1.7')
    val=m.quad(lambda t:t**(-2*n)/t,[tau,T])
    formula=(tau**(-2*n)-T**(-2*n))/(2*n)
    err=max(err,abs(val-formula))
    assert abs(val-formula)<m.mpf('1e-38')
    checks+=1
print('PASS',checks,'exact_posterior_laws',12,'power_integrals',4,
      'max_abs_error',m.nstr(err,12))
```
