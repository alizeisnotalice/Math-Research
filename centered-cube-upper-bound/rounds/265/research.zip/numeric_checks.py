#!/usr/bin/env python3
"""R265 actual fractional square-window J diagnostics. No interval/FULL claim."""
import argparse,hashlib,json
from pathlib import Path
from fractions import Fraction as Rat
import mpmath as mp

def enc(x):return mp.nstr(x,80)
def phi(u):
 u=abs(u)
 if u<=mp.mpf('.5'):return 1-mp.expint(3,mp.mpf('.5')-u)-mp.expint(3,mp.mpf('.5')+u)
 return mp.expint(3,u-mp.mpf('.5'))-mp.expint(3,u+mp.mpf('.5'))
def C(d):
 d=abs(d)
 if d<=1:return 1-d+mp.mpf(1)/3-mp.expint(4,d)-mp.expint(4,1)+mp.expint(4,d+1)
 return mp.expint(4,d-1)-2*mp.expint(4,d)+mp.expint(4,d+1)
def P(s,L,x):return ((1-s)*(1 if abs(x)<L/2 else 0)+s*phi(x/L))/L
def quad(fn,a,b,knots):
 pts=sorted(set([a,b]+[x for x in knots if a<x<b]));return sum(mp.quad(fn,[x,y]) for x,y in zip(pts,pts[1:]))
def mm(s):
 f=Rat(s);return mp.mpf(f.numerator)/f.denominator

def run(dps):
 with mp.workdps(dps):
  eta=mp.mpf(25)/2**69;geometry=[];rows=[]
  for n,l,vv,ss in [(1,'1/2','3/5','1/100'),(8,'3/4','11/10','1/5'),(128,'1','4','1/100')]:
   L,v,s=map(mm,[l,vv,ss]);d=mp.mpf('.5')/(8*mp.sqrt(n));h=(1+d)/2;om=min(mp.mpf(1),C(v)/L);gap=1-om
   knots=[-L/2,L/2,v-mp.mpf('.5'),v+mp.mpf('.5')]
   def fun(x):return mp.sqrt(P(s,L,x)*phi(x-v)/om)
   core1=quad(fun,-mp.mpf('.5'),mp.mpf('.5'),knots)
   common1=quad(fun,-h,h,knots);common2=quad(lambda x:fun(x)**2,-h,h,knots)
   collar=quad(fun,-h,-mp.mpf('.5'),knots)+quad(fun,mp.mpf('.5'),h,knots)
   assert core1<=mp.exp(-eta*gap)*(1+mp.mpf('1e-35'))
   assert L*common2<=mp.exp(d*s)*(1+mp.mpf('1e-35'))
   assert collar<=d*mp.sqrt(2*s)*(1+mp.mpf('1e-35'))
   geometry.append({'n':n,'L':l,'v':vv,'s':ss,'d':enc(d),'Omega':enc(om),'Delta':enc(n*gap),'core_L1':enc(core1),'core_log_margin':enc(-eta*gap-mp.log(core1)),'common_L1':enc(common1),'common_L2_square_integral':enc(common2),'L2_log_margin':enc(d*s-mp.log(L*common2)),'collar_integral':enc(collar),'collar_bound':enc(d*mp.sqrt(2*s)),'collar_margin':enc(d*mp.sqrt(2*s)-collar)})
   for pp in ['5/4','3/2','7/4']:
    p=mm(pp);ip=quad(lambda x:fun(x)**p,-h,h,knots)
    interp=(2-p)*mp.log(common1)+(p-1)*mp.log(common2)
    logip=mp.log(ip);logD=n*((p-1)*mp.log(L)+logip)
    Ep=(2-p)*n*mp.exp(eta)*d*mp.sqrt(2*s)+(p-1)*n*d*s
    rhs=Ep-eta*(2-p)*n*gap
    assert logip<=interp+mp.mpf('1e-34') and logD<=rhs+mp.mpf('1e-32')
    rows.append({'stage':'initial' if n==1 else 'stress' if n==8 else 'expanded','n':n,'p':pp,'integral_F_power_p':enc(ip),'log_D_product':enc(logD),'E_p':enc(Ep),'gap_payment':enc(eta*(2-p)*n*gap),'proposed_log_rhs':enc(rhs),'proposed_log_margin':enc(rhs-logD),'interpolation_log_margin':enc(interp-logip)})
  clocks=[];p=mp.mpf('1.5');qp=eta*(2-p)/p
  for n in [1,128,10**6,10**20,10**24,10**30]:
   gamma=1+mp.mpf(1)/n;cut=1/(mp.e*qp*n)
   pts=sorted(set([mp.mpf('.5'),mp.mpf(1)]+[x for x in [1/gamma,(1-cut)/gamma] if mp.mpf('.5')<x<1]))
   def env(u):
    defect=max(mp.mpf(0),1-gamma*u)
    return mp.mpf(n) if defect==0 else min(mp.mpf(n),1/(mp.e*qp*defect))
   val=sum(mp.quad(lambda u:env(u)/u,[a,b]) for a,b in zip(pts,pts[1:]));closed=mp.mpf(0)
   for a,b in zip(pts,pts[1:]):
    if 1-gamma*(a+b)/2<=cut:closed+=n*mp.log1p((b-a)/a)
    else:closed+=(mp.log1p((b-a)/a)-mp.log((1-gamma*b)/(1-gamma*a)))/(mp.e*qp)
   bound=1+2/(mp.e*qp)*(1+max(mp.mpf(0),mp.log(mp.e*qp*n)))
   relative=abs(val-closed)/max(1,abs(closed));assert relative<mp.mpf('1e-32') and val<=bound
   clocks.append({'stage':'initial' if n<=128 else 'stress' if n<=10**20 else 'expanded','n':n,'p':'3/2','q_p':enc(qp),'transition_defect':enc(cut),'log_regime_nonempty':cut<max(mp.mpf(0),1-gamma/2),'envelope_integral':enc(val),'closed_integral':enc(closed),'quad_closed_relative_residual':enc(relative),'bound':enc(bound),'ratio_to_bound':enc(val/bound),'split_points':[enc(x) for x in pts]})
  return {'eta':enc(eta),'kappa':enc(2*eta),'geometries':geometry,'fractional_tests':rows,'clock_envelopes':clocks}

def fields(obj,path=''):
 out={}
 if isinstance(obj,dict):
  for k,v in obj.items():
   if isinstance(v,str) and k not in ['stage','L','v','s','p']:
    try:out[path+k]=mp.mpf(v)
    except ValueError:pass
   elif isinstance(v,(list,dict)):out.update(fields(v,path+k+'/'))
 elif isinstance(obj,list):
  for i,v in enumerate(obj):out.update(fields(v,path+str(i)+'/'))
 return out

def main():
 p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=Path(__file__).with_suffix('.json'));a=p.parse_args();lo=run(50);hi=run(80)
 with mp.workdps(100):
  x=fields(lo);y=fields(hi);assert x.keys()==y.keys();diff={k:abs(x[k]-y[k])/max(1,abs(y[k])) for k in x};worst=max(diff,key=diff.get);md=enc(diff[worst]);assert diff[worst]<mp.mpf('1e-32')
 print('precision_worst',worst,md,flush=True)
 out={'schema':'R265-J-fractional-actual-v1','script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'counts':{'actual_geometries_per_precision':3,'fractional_actual_tests_per_precision':9,'fractional_stages':{'initial':3,'stress':3,'expanded':3},'core_collar_L2_checks_per_precision':9,'clock_envelope_cases_per_precision':6,'precision_fields_compared':len(diff)},'mp50':lo,'mp80':hi,'precision_max_relative_difference':md,'precision_worst_field':worst,'provenance':'Analytic E3/E4 actual phi,C definitions reused from R264, self-contained here.','scope':['Actual positive continuous J kernels with sigma=1, y=0,b=1,a=.5; Omega=min(1,C(abs(v))/L). Hard discontinuities at source and target cores explicitly split.','Repeated-coordinate n-dimensional products computed by n times one-coordinate log integrals. Wcommon side1+d,d=.5/(8sqrt n); actual scalar collar is separately integrated.','All quadratures and tiny-kappa prices use ordinary mpmath50/80, not directed intervals. Finite passing inequalities do not prove a universal theorem, FULL qualification, history, root gain or dimension order.','Clock quantities are upper-envelope integrals, not original traffic. n1e20,1e24,1e30 are scalar formulas only; no physical high-dimensional integral computed.','Core gap is tiny eta times Delta; the reported margins are ordinary arithmetic, not a rigorous certification of the tiny constant.']}
 a.output.write_text(json.dumps(out,sort_keys=True,indent=2)+'\n');print(json.dumps({'counts':out['counts'],'maxdiff':md,'worst':worst}))
if __name__=='__main__':main()
