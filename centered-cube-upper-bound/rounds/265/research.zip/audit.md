# R265 independent audit: the J leg by Lp interpolation

Verdict: PASS for the receiver-kernel theorem below. This is not an original-source budget or a general root bound. Statement screening preceded reading the author's R265 proof. Only the frozen R224 affinity statement and the already independently audited R264 tools were used.

## 1. Exact R224 normalization and scope

Let 0<a≤b≤2a, n≥1, L∈[a,b], target A=b, softness σ=1, and s∈[0,1]. Define

\[
 F_L(x)=1_W(x)\frac{\sqrt{P_{s,L}(x-y)P_{1,b}(x-v)}}{\sqrt{\bar w_L(y,v)}},\quad
 \Delta_L=\sum_i(1-\min(1,bC(|y_i-v_i|/b)/L)).
\]

In the frozen R224 threshold_gap.md QG16, choose R=b, hence M=b and m=L. Its h_b=b^{-n}1_Qb(z) is essential. Multiplying QG16 by b^n gives exactly

\[
 \int_{Q_b(z)}F_L\le e^{-\eta\Delta_L},\qquad \eta=\kappa/2=25/2^{69}.
\]

This is valid for arbitrary z and all s; the R224 hypotheses L,R∈[b/2,b], A∈[L,b] hold because a≥b/2. No residual b^{-n}, hard-source cap, or original-source mass has been discarded. This is an integrated fixed-window estimate, not a pointwise receiver estimate.

R264 gives on the SAME window

\[
 \int_{Q_b(z)}F_L^2\le L^{-n}e^{\delta_{yz}},\qquad
 \delta_{yz}=12\|y-z\|_1/b.
\]

Therefore for 1<p<2, Holder between powers 1 and 2 yields

\[
 \boxed{\int F_L^p\le L^{-n(p-1)}
 e^{(p-1)\delta_{yz}-\eta(2-p)\Delta_L}.}
\]

The interpolation coefficients are 2−p and p−1; there is no L2 gap claim.

## 2. The correct Lp Abel factor

For the J leg write F_L=ρ_L B_L, where

\[
 \rho_L^p=(Lb)^{-np/2}\bar w_L^{-p/2},\qquad
 B_L^p=1_W\prod_i f_s((x_i-y_i)/L)^{p/2}\phi((x_i-v_i)/b)^{p/2}.
\]

The profile B_L^p is nondecreasing, ρ_L^p is nonincreasing, and for L<L′,

\[
 \rho_{L'}^p/\rho_L^p\ge(L/L')^{np/2}.
\]

Put β=n(p−1), κ_p=np/2, so κ_p/β=C_p=p/[2(p−1)]≥1. If at every allowed L,

\[
 \int F_L^p\le D L^{-\beta},
\]

finite-scale positive-profile summation and Abel give

\[
 \int\sup_LF_L^p
 \le D\left[L_m^{-\beta}+\sum_{j<m}L_j^{-\beta}
 (1-(L_j/L_{j+1})^{\kappa_p})\right]
 \le C_p D a^{-\beta}.
\]

Here 1−r^{κ_p}≤(κ_p/β)(1−r^β), 0≤r≤1. Thus the Lp norm factor is

\[
 \boxed{C_p^{1/p}a^{-n(1-1/p)}D^{1/p}.}
\]

The same proof applies to N_{γuL}^p B_L^p since N_{γuL} is nondecreasing in L. Arbitrary allowed sets require the same countable-reduction and joint-measurability qualification as R264. It is not sufficient to state fiberwise measurability and silently integrate over sources. The constants deteriorate at p→1 or p→2; p=3/2 is a fixed admissible choice.

## 3. Common window: core plus collar

Let W_y=Q_{b+d}(y), δ_geo=d/b. In one coordinate split its central side-b interval from the two collars of total length d. The central integral has the exact R224 bound e^{-η(1−Ω)}, Ω=min(1,bC(|y_i-v_i|/b)/L). On the collar |x-y_i|>b/2≥L/2, so the hard anchor factor vanishes and f_s=sφ. By radial monotonicity φ((x-y_i)/L)≤φ((x-y_i)/b), and the established φ(t)φ(t−D)≤V(D) gives

\[
 \int_{\rm collar}\frac{\sqrt{L^{-1}s\phi((x-y_i)/L)b^{-1}\phi((x-v_i)/b)}}{\sqrt\Omega}dx
 \le \frac d{\sqrt{Lb}}\sqrt{s}\sqrt{V(D)/\Omega}
 \le\delta_{\rm geo}\sqrt{2s}.
\]

The last steps use V≤C≤Ω (because L≤b), and L≥b/2. Hence the whole coordinate integral is at most

\[
 e^{-\eta(1-\Omega)}+\delta_{\rm geo}\sqrt{2s}
 \le e^{-\eta(1-\Omega)+e^\eta\delta_{\rm geo}\sqrt{2s}}.
\]

Tensorization yields the common-window L1 estimate

\[
 \int_{W_y}F_L\le
 \exp\{n e^\eta\delta_{\rm geo}\sqrt{2s}-\eta\Delta_L\}.
\]

R264 common-window J L2 is L^{-n}exp(nδ_geo s). Interpolation on this same window therefore gives

\[
 \boxed{\int_{W_y}F_L^p\le L^{-n(p-1)}e^{E_p(s)-\eta(2-p)\Delta_L},}
\]

\[
 E_p(s)=(2-p)n e^\eta\delta_{\rm geo}\sqrt{2s}+(p-1)n\delta_{\rm geo}s.
\]

For d=a/(8√n), s≤s0=C log(n)/n≤1/2 and fixed p, E_p=O(√log(n+2)); exp(E_p/p)=n^{o(1)}. This is a kernel prefactor; it is not a source payment. After a prior legal hard-source integration, near support can be retained in W_y. No hard density may be reinserted and no second hardcap may be claimed.

## 4. Full relative clock, including terminal strip

Let γ=1+1/n, N_r=#\{i:bC_i<r\}. The original far relation τ=a/c_j≤t≤g≤bc_j implies u=t/g∈[1/2,1], with k_t=N_{c_jt}≤N_{γuL(x)}. The profile multiplier N_{γuL}^p is nondecreasing. For γu<1, Δ_L≥(1−γu)N_{γuL}. Put a_p=η(2−p). Optimization gives

\[
 \|\sup_LN_{\gamma uL}F_L\|_p
 \le C_p^{1/p}a^{-n(1-1/p)}e^{E_p/p}
 \begin{cases}
 \min\{n,p/[e a_p(1-\gamma u)]\},&\gamma u<1,\\
 n,&\gamma u\ge1.
 \end{cases}
\]

For the fixed-z version replace E_p by (p−1)δ_yz. Let A=p/(e a_p). The terminal strip costs nlogγ≤1; on the other part q=γu≥1/2 gives dq/q≤2dq. Thus

\[
 \int_{1/2}^1\min\{n,A/(1-\gamma u)\}\frac{du}{u}
 \quad\hbox{with the terminal-strip convention above}\quad
 \le\mathcal C_{n,p},
\]

\[
 \boxed{\mathcal C_{n,p}=1+\frac{2p}{e\eta(2-p)}
 [1+\log_+(e\eta(2-p)n/p)].}
\]

For n=1 the inner region is empty. Minkowski also bounds the Lp norm of the clock-integrated envelope. All constants are absolute for fixed p=3/2 and the fixed audited η, although numerically large.

## 5. Final clipped rational grid and remaining source issue

Use the R264 final rational grid q_n=n/(n+1), J least q_n^J≤1−s0, nodes 1−q_n^j for j<J and final node s_J=s0. There are M=J+1=O(log n) nodes in the low-soft range. Since only the anchor of J moves in soft parameter,

\[
 F_{s,L}\le\sqrt{c_n}F_{s_j,L},\qquad c_n=(1+1/n)^n<e.
\]

The maximum over nodes costs M^{1/p} in Lp, not M, M², or a new FIRST claim. E_p(s) can be uniformly replaced by E_p(s0). Consequently the all-soft/scale/clock J envelope costs explicitly

\[
 \sqrt{c_n}M^{1/p}C_p^{1/p}a^{-n(1-1/p)}
 e^{E_p(s_0)/p}\mathcal C_{n,p}.
\]

The original barw_(c_jg) to barw_L comparison still costs at most √e, only if not already charged in the R222 bridge. Crucially u=t/g(x) makes actual Π_(y,j,ug(x)) receiver-dependent. The result does not permit moving it outside Lp, inventing a common source probability, paying J normalization, or splitting signed negative credit. It solves the stated J receiver-kernel issue in Lp<2, not in L2 and not the full original traffic budget.

## 6. Actual bounded diagnostics

Executed locally: 10 exact Fraction checks of the p=3/2 Abel scalar inequality (n4/16, five rational adjacent-scale ratios), and 18 ordinary mp60 closed-primitive checks of the clock constant (n1/16/512; p1.25/1.5/1.75; η=.02 and exact25/2^69). All PASS. These are finite arithmetic diagnostics, not interval evidence or physical/FULL/source certification. The general result is the analytic argument above.


## 7. Author J manuscript and auxiliary source criterion: narrow final read

Author /tmp/r265_j.md SHA256 `7952103e7c101b029bdff45baaaec7914ce7f38b38ee45c4066d06a4cc2f01ff` agrees with the independent proof above: J1 normalization, J3 collar, J6 Abel constant, J8 clock, J9 clipped rational grid and J10 p=3/2 constant all PASS. It preserves the actual receiver-dependent posterior obstruction and makes no L2-gap or general payment assertion.

For /tmp/r265_source.md S3–S4, the fixed-t Minkowski and energy Cauchy give exactly

\[
 \|H_{y,j}\|_2^2\le (D\gamma^n/4)a^{-n}R_{yj}(1-e^{-2nL_y}).
\]

The C_out²/4 coefficient in its conditional Young bound is exactly 256Λ²Kγ^n/27. The heavy ratio and the proposed square-row Z budget remain unpaid.

The leaf receiver-volume qualification has a direct original basis, not a deduction from disjoint source supports. R107 frozen proof.md lines 980–1018 (R10–R14) defines Good2 by the complete actual Q_x and y lying in the same finest cell, then states that the terminal Q_x is wholly in the unique leaf and that each x has at most one nonzero leaf row. N3 lines 545–610 gives the same geometry and retention in J2. Therefore, PROVIDED the current χ continues to retain that original Good2/terminal receiver support, one may define E_(ω,V)⊂E∩V and obtain Σ_V|E_(ω,V)|≤|E| at every seed. Original j(x) masks must also be retained for the stated index ℓ2 sum. This support must be cited explicitly in S4; if it is dropped, only the earlier bound with the explicit sum of leaf receiver measures is certified, and its displayed εX Young consequence is not authorized. Source V disjointness by itself would be insufficient.

These are conditional source-use criteria, not a new paid source budget. No second hardcap, posterior replacement, or negative credit is introduced. No previously passed numeric checks were rerun for this narrow review.


## 8. Main integration final read

PASS for the final integrated proof.tex.txt, SHA256 `3cda22b3d821d9b9f7ba339d4d6e2bd2e492e30a85511208b1c6176b468d7bf0`. Its formulas (1)–(10) agree with the independently audited J1–J10 chain: exact R224 normalization, the same-window collar interpolation, C_p^(1/p), a^(-n(1−1/p)), full clock including terminal strip, clipped rational grid with sqrt(c_n)M^(1/p), and explicit p=3/2 constants. The low-soft n^o(1) statement retains its dimensional factor and is limited to the receiver kernel. The actual Π_(y,j,ug(x)) coupling, original β/clock/leaf costs, signed recovery and deletion net excess remain unpaid, and there is no global/root-payment claim.

The auxiliary source manuscript now has SHA256 `5c19139d58f3cc289c77a45a426f6721a0ef8689d7db869e18d68467adcf6f87`. Its revised S4 conservatively retains the full receiver sum and ελ EΣ_V|E_(ω,V)| multiplicity price, permitting εX only when the original common-leaf receiver support has explicitly been retained. This is consistent with the qualification in §7 above and removes the risk of inferring receiver disjointness from source disjointness. No repeated computation or project-file modification was made in this final read.
