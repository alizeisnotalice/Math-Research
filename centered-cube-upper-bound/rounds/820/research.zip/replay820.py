"""Reproduce round 820 using Python 3.10+ and python-flint."""
from pathlib import Path
import platform
import subprocess
import sys
import flint

if __name__ == "__main__":
    base = Path(__file__).resolve().parent
    print("Python",platform.python_version(),"python-flint", flint.__version__,
          "FLINT", getattr(flint,"__FLINT_VERSION__","unknown"), flush=True)
    for name in ("ray820.py","packing820.py","multisource820.py"):
        print("Running",name,flush=True)
        subprocess.run([sys.executable,"-B",str(base/name)],check=True,cwd=base)
    print("All three experiments completed")
