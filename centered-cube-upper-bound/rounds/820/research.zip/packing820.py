"""Exact audit of the finite partial order used for real ray records.
Integer radial volume levels give exp(-(u_l-u_i)) = r_i/r_l exactly.
These lists test the combinatorial step, separately from the positive densities.
"""
from fractions import Fraction as Q
from itertools import product, combinations
from random import Random


def choose_antichain(vertices, successors, size):
    def extend(selected, available):
        if len(selected) == size:
            return tuple(selected)
        for pos, node in enumerate(available):
            if len(available) - pos < size - len(selected):
                break
            later = [other for other in available[pos + 1:] if other not in successors[node]]
            group = extend(selected + [node], later)
            if group is not None:
                return group
        return None
    return extend([], list(vertices))


def chain_cover(vertices, successors):
    right_match = {}
    def augment(left, seen):
        for right in sorted(successors[left].intersection(vertices)):
            if right in seen:
                continue
            seen.add(right)
            if right not in right_match or augment(right_match[right], seen):
                right_match[right] = left
                return True
        return False
    for left in sorted(vertices):
        augment(left, set())
    next_node = {left: right for right, left in right_match.items()}
    chains = []
    for node in sorted(vertices.difference(right_match)):
        chain = [node]
        while chain[-1] in next_node:
            chain.append(next_node[chain[-1]])
        chains.append(chain)
    assert sorted(i for chain in chains for i in chain) == sorted(vertices)
    return chains


def audit(level, slack, k, eta, span_ratio):
    size = len(level)
    assert size == len(slack) and all(a < b for a, b in zip(level, level[1:]))
    successors = [set() for _ in range(size)]
    for i, j in combinations(range(size), 2):
        if (slack[i] - slack[j]) * level[j] > eta * level[i]:
            successors[i].add(j)
    for i in range(size):
        for j in successors[i]:
            assert successors[j] <= successors[i]
    blocks, chains = [], []
    begin = 0
    while begin < size:
        end = begin + 1
        while end < size and level[end] < level[begin] * span_ratio:
            end += 1
        remaining = set(range(begin, end))
        while True:
            block = choose_antichain(sorted(remaining), successors, k+1)
            if block is None:
                break
            for i, j in combinations(block, 2):
                assert (slack[i] - slack[j]) * level[j] <= eta * level[i]
            assert level[block[-1]] < level[block[0]] * span_ratio
            blocks.append(block)
            remaining.difference_update(block)
        cover = chain_cover(remaining, successors)
        assert len(cover) <= k
        for chain in cover:
            ratios = [Q(level[i], level[j]) for i, j in zip(chain, chain[1:])]
            if ratios:
                assert slack[chain[0]] - slack[chain[-1]] > eta * sum(ratios)
            assert all(j in successors[i] for i, j in combinations(chain, 2))
        chains.extend(cover)
        begin = end
    visited = [i for group in blocks + chains for i in group]
    assert sorted(visited) == list(range(size))
    return len(blocks), sum(map(len,chains))


def main():
    # Equality at the boundary is admissible in an antichain.
    assert audit([1,2], [Q(1,2),Q(0)], 1,Q(1),8) == (1,0)
    assert audit([1,2], [Q(3,4),Q(0)], 1,Q(1),8) == (0,2)
    trials = blocks = unmatched = 0
    for gap_pattern in ((1,1,1,1,1), (2,1,3,1,2)):
        levels = [1]
        for gap in gap_pattern:
            levels.append(levels[-1] << gap)
        for b in product((Q(0),Q(1,4),Q(1,2)), repeat=6):
            for k in (1, 2, 3):
                good, rem = audit(levels, b, k, Q(1,2), 64)
                trials += 1
                blocks += good
                unmatched += rem
    print("Exact exhaustive lists:", trials, "blocks:",blocks,"unmatched slots:",unmatched)
    rng = Random(820)
    for size in (20, 64, 160):
        levels = [1]
        for i in range(1,size):
            levels.append(levels[-1] << rng.choice((1,1,2,3)))
        schedules = {
            "descending": [Q(size-i,4*size) for i in range(size)],
            "flat": [Q(0)] * size,
            "sawtooth": [Q((size-i) % 11,13) for i in range(size)],
            "random": [Q(rng.randrange(97),96) for i in range(size)],
        }
        for kind, schedule in schedules.items():
            results = [audit(levels,schedule,k,Q(1,3),1 << 15) for k in (1,2,4,6)]
            print("Extended list", size, kind, "k=1,2,4,6 (blocks,unmatched):", results)
    print("PASS exact order, all earlier/later pairs, slot capacities and residual chain certificates")


if __name__ == "__main__":
    main()
