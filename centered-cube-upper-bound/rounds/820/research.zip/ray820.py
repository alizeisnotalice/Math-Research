"""Positive-L1 same-ray last roots in two and higher dimensions.

All geometric comparisons and source masses use exact Fraction arithmetic.
Run with Python 3.9 or later.
"""

from fractions import Fraction as F
from itertools import combinations

LAMBDA = F(100)
DELTA = F(1, 100000)
ATOMS = ((F(0), F(16)), (F(-19, 100), F(9)), (F(35, 100), F(11)), (F(55, 100), F(22)))
WINDOW = (F(9, 20), F(9, 10))
POINTS = ((F(1, 25), F(1, 2)), (F(9, 100), F(3, 5)), (F(201, 1000), F(7, 10)))


def box_sources(center, side):
    """Return fully included block ids, asserting every block is all-in/out."""
    out = []
    for i, (position, mass) in enumerate(ATOMS):
        distance = abs(center - position)
        if distance + DELTA < side / 2 and DELTA < side / 2:
            out.append(i)
        else:
            assert distance - DELTA > side / 2
    return tuple(out)


def true_roots(center):
    """Check all 15 mass candidates by squared rational comparisons.

    Away from every candidate face, a later successful partial-block cube
    would give a later candidate with all touched blocks captured, impossible
    after the largest listed root. All densities are constant on blocks.
    """
    roots = []
    for mask in range(1, 1 << len(ATOMS)):
        mass = sum((w for i, (_, w) in enumerate(ATOMS) if mask >> i & 1), F(0))
        if not LAMBDA * WINDOW[0] ** 2 < mass < LAMBDA * WINDOW[1] ** 2:
            continue
        included = []
        for i, (p, w) in enumerate(ATOMS):
            dist = abs(center - p)
            inside = (
                4 * (dist + DELTA) ** 2 < mass / LAMBDA and 4 * DELTA**2 < mass / LAMBDA
            )
            outside = dist > DELTA and 4 * (dist - DELTA) ** 2 > mass / LAMBDA
            assert inside or outside, (center, mask, i, "candidate face too close")
            if inside:
                included.append(i)
        capture = sum(1 << i for i in included)
        if capture == mask and LAMBDA * WINDOW[0] ** 2 < mass < LAMBDA * WINDOW[1] ** 2:
            roots.append((mass, mask))
    return sorted(roots)


def geometry():
    assert WINDOW[1] / WINDOW[0] == 2
    assert sum(w for p, w in ATOMS) < LAMBDA * WINDOW[1] ** 2
    out = []
    print(
        "GEOMETRY dimension=2 lambda=",
        LAMBDA,
        "window=",
        WINDOW,
        "delta=",
        DELTA,
        "theta=(1/2,0)",
    )
    for x, t in POINTS:
        roots = true_roots(x)
        assert roots and roots[-1][0] == LAMBDA * t * t
        selected = box_sources(x, t)
        assert sum(ATOMS[i][1] for i in selected) == LAMBDA * t * t
        s = 2 * x
        b = 2 * (t - s)
        assert 0 < s < t and F(1, 4) <= t * t < F(1, 2)
        out.append((x, t, s, b, selected))
        print(
            "  x=",
            x,
            "s=",
            s,
            "t=",
            t,
            "v=",
            t * t,
            "b=",
            b,
            "x_faces=",
            (x - t / 2, x + t / 2),
            "sources=",
            selected,
            "root_candidates=",
            roots,
        )
    assert all(
        out[i][2] < out[i + 1][2] and out[i][1] < out[i + 1][1]
        for i in range(len(out) - 1)
    )
    for i, j in combinations(range(len(out)), 2):
        x, tx, sx, bx, src = out[i]
        c, tc, sc, bc, target = out[j]
        d = max(F(0), bx - bc) / 2
        assert tc + d < WINDOW[1]
        capids = box_sources(c, tc + d)
        cap = sum(ATOMS[k][1] for k in capids)
        capbound = LAMBDA * (tc + d) ** 2
        assert cap <= capbound
        retained = sum((ATOMS[k][1] for k in src if k in target), F(0)) / (
            LAMBDA * tx**2
        )
        bound = 1 - ((tc + d) ** 2 - tc**2) / tx**2
        assert retained >= bound
        print(
            "  PAIR x,c=",
            i,
            j,
            "gap_v=",
            tc**2 / tx**2,
            "b_drop=",
            bx - bc,
            "d=",
            d,
            "cap=",
            cap,
            "cap_bound=",
            capbound,
            "retained=",
            retained,
            "lower=",
            bound,
            "slack=",
            retained - bound,
        )


def dyadic_exponent(value):
    """Exact floor(log2(value)) for positive Fraction; no floating logs."""
    assert value > 0
    k = value.numerator.bit_length() - value.denominator.bit_length()
    while F(2) ** k > value:
        k -= 1
    while F(2) ** (k + 1) <= value:
        k += 1
    return k


def many_price_bins():
    """Five same-ray true roots with positive L1 sources and receiver balls.

    For receiver x_i, its rightmost cube face at t_i is t_i-d/2.
    Source j>i cannot be touched until side >t_j. Between successive
    touches, available mass is at most the last touched prefix t_j**n.
    Thus no later side is superthreshold. These are deterministic
    finite-dimensional constructions, not an asymptotic weak-type proof.
    """
    d = F(1, 5)
    for n in (32, 64, 128, 512):
        growth = 1 + F(2, n)
        sides = [F(9, 8) * growth**i for i in range(5)]
        assert F(1) < sides[0] < sides[-1] < F(2)
        delta = F(1, 10000 * n)
        epsilon = delta / 4
        receiver_radius = delta / 8
        assert delta < min(sides[i] - sides[i - 1] for i in range(1, 5)) / 4
        assert epsilon > 0 and receiver_radius > 0
        positions = [F(0)] + [sides[j] - d / 2 - delta for j in range(1, 5)]
        masses = [sides[0] ** n] + [
            sides[j] ** n - sides[j - 1] ** n for j in range(1, 5)
        ]
        assert all(mass > 0 for mass in masses)
        assert all(positions[j] - positions[j - 1] > 2 * epsilon for j in range(1, 5))
        assert sum(masses, F(0)) == sides[-1] ** n < F(2) ** n
        bins = [dyadic_exponent(t**n) for t in sides]
        assert all(F(2) ** k <= t**n < F(2) ** (k + 1) for k, t in zip(bins, sides))
        assert len(set(bins)) == 5
        assert (sides[-1] / sides[0]) ** n > 2
        print(
            "\nMULTI-BIN n=",
            n,
            "dyadic exponents=",
            bins,
            "t4/t0 exact=",
            sides[-1] / sides[0],
            "price ratio=",
            f"({growth})^{4*n}",
            "approximately",
            float((sides[-1] / sides[0]) ** n),
            "source halfwidth=",
            epsilon,
            "receiver halfwidth=",
            receiver_radius,
        )
        for i, t in enumerate(sides):
            s = t - d
            center = s / 2
            assert 0 < s < t
            # Every earlier source block is wholly contained for all receiver
            # centers in the full n-dimensional l-infinity eta-neighborhood.
            for j in range(i + 1):
                assert abs(positions[j] - center) + epsilon + receiver_radius < t / 2
                assert epsilon + receiver_radius < t / 2
            assert sum(masses[: i + 1], F(0)) == t**n
            # First possible touch of future source j occurs strictly after
            # t_j, even after receiver and source block perturbations.
            for j in range(i + 1, 5):
                first_touch_lower = 2 * (
                    positions[j] - epsilon - center - receiver_radius
                )
                assert first_touch_lower > sides[j]
            assert n * (t - s) == n * d
        # Positive source blocks and receiver neighborhoods are actual,
        # not point masses. p=0 supplies the displayed central ray.
        for i in range(5):
            for j in range(i + 1, 5):
                assert all(
                    abs(positions[h] - (sides[j] - d) / 2) + epsilon < sides[j] / 2
                    for h in range(i + 1)
                )
                share = sum(masses[: i + 1], F(0)) / sides[i] ** n
                assert share == 1
                # b_i=b_j=n*d, so forward cap inflation parameter is zero.
                print(
                    "  pair",
                    i,
                    j,
                    "bin",
                    bins[i],
                    bins[j],
                    "actual retained=",
                    share,
                    "cap inflation=0 cap equality=true",
                    "exact price ratio=",
                    f"({growth})^{n*(j-i)}",
                )
        print(
            "  all five positive receiver neighborhoods verified; upper t=2 subthreshold; p=0 on same ray"
        )


if __name__ == "__main__":
    geometry()
    many_price_bins()
    print(
        "\nPASS exact rational physical geometry and different price bins; no general proof"
    )
