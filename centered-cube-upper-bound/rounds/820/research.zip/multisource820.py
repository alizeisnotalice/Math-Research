"""Actual maximal-root reception cells and posterior repeated-source test.

Exact rational volumes and conditional probabilities, with Arb for logarithms.
For each D the reference X is Lebesgue restricted to the stated actual F.
Ordered source samples are conditional iid from P_x. No result here is
extrapolated beyond these selected finite inputs.
"""

from collections import defaultdict
from fractions import Fraction as F
from itertools import product
from math import prod
import flint
from flint import arb, ctx


def cells(n, atoms, lam, roots, D, must_contain=None):
    edges = []
    for axis in range(n):
        edges.append(
            sorted(
                {a[axis] + s * t / 2 for a, w in atoms for s in (-1, 1) for t in roots}
            )
        )
    out = []
    for spans in product(*(list(zip(e, e[1:])) for e in edges)):
        center = tuple((a + b) / 2 for a, b in spans)

        def captured(t):
            return tuple(
                i
                for i, (x, w) in enumerate(atoms)
                if all(abs(y - z) < t / 2 for y, z in zip(center, x))
            )

        possible = []
        for t in roots:
            ids = captured(t)
            if sum((atoms[i][1] for i in ids), F(0)) == lam * t**n:
                possible.append((t, ids))
        if not possible:
            continue
        t, ids = max(possible)
        if not (D <= t**n < 2 * D):
            continue
        if must_contain is not None and must_contain not in ids:
            continue
        volume = prod(b - a for a, b in spans)
        p = tuple(
            atoms[i][1] / (lam * t**n) if i in ids else F(0) for i in range(len(atoms))
        )
        assert sum(p, F(0)) == 1
        out.append({"volume": volume, "t": t, "p": p, "spans": spans, "capture": ids})
    return out


def rational_arb(x):
    return arb(x.numerator) / x.denominator


def statistics(name, atoms, selected, precision):
    ctx.prec = precision
    volume = sum((r["volume"] for r in selected), F(0))
    assert volume > 0
    types = defaultdict(F)
    for r in selected:
        types[r["p"]] += r["volume"]
    types = sorted(types.items())
    print(
        "\nCASE",
        name,
        "precision=",
        precision,
        "actual cells=",
        len(selected),
        "volume=",
        volume,
        "conditional types=",
        [(tuple(map(str, p)), str(v)) for p, v in types],
    )
    assert len(atoms) == 2
    coords = [x for x, w in atoms]
    rows = []
    first_info = None
    for m in range(1, 9):
        tail = F(0)
        bbox = F(0)
        rootprob = F(0)
        norm = F(0)
        info = arb(0)
        source_info = arb(0)
        for sequence in product(range(len(atoms)), repeat=m):
            weighted = []
            for p, v in types:
                likelihood = prod(p[i] for i in sequence)
                weighted.append(v * likelihood)
            W = sum(weighted, F(0))
            if not W:
                continue
            post = [a / W for a in weighted]
            predictive = [
                sum((post[h] * types[h][0][q] for h in range(len(types))), F(0))
                for q in range(len(atoms))
            ]
            first_weights = [v * p[sequence[0]] for p, v in types]
            first_sum = sum(first_weights)
            first_predictive = [
                sum(w * p[q] for w, (p,v) in zip(first_weights, types)) / first_sum
                for q in range(len(atoms))
            ]
            assert sum(predictive, F(0)) == sum(first_predictive) == 1
            assert all(first_predictive[q] or not predictive[q] for q in range(len(atoms)))
            lower = [
                min(coords[i][axis] for i in sequence) for axis in range(len(coords[0]))
            ]
            upper = [
                max(coords[i][axis] for i in sequence) for axis in range(len(coords[0]))
            ]
            for q in range(len(atoms)):
                prob = W / volume * predictive[q]
                norm += prob
                if prob:
                    source_info += rational_arb(prob) * rational_arb(
                        predictive[q] / first_predictive[q]
                    ).log()
                # Root-hit posterior is membership in independent Y's actual Q_Y,
                # not the posterior predictive probability of drawing q.
                psi = sum((post[h] for h, (p, v) in enumerate(types) if p[q] > 0), F(0))
                if psi <= F(1, 2):
                    tail += prob
                rootprob += prob * psi
                if all(a <= z <= b for z, a, b in zip(coords[q], lower, upper)):
                    bbox += prob
                if predictive[q] > 0:
                    for h, (p, v) in enumerate(types):
                        if p[q] and weighted[h]:
                            joint = weighted[h] / volume * p[q]
                            info += (
                                rational_arb(joint)
                                * (rational_arb(p[q] / predictive[q])).log()
                            )
        assert norm == 1 and 0 <= tail <= 1 and 0 <= bbox <= 1 and 0 <= rootprob <= 1
        assert info >= 0 or info.contains(0)
        if m == 1:
            first_info = info
        assert (info+source_info-first_info).contains(0)
        rows.append((tail,bbox,rootprob,info,source_info))
        print(
            "m=",
            m,
            "tail=",
            tail,
            "P_B=",
            bbox,
            "posterior_root_hit=",
            rootprob,
            "difference=",
            rootprob - bbox,
            "I_nats=",
            info.str(18), "source_only_J_nats=", source_info.str(18),
        )

    return rows


def both_precisions(name, atoms, selected):
    low = statistics(name, atoms, selected, 256)
    high = statistics(name, atoms, selected, 384)
    for x,y in zip(low,high):
        assert x[:3] == y[:3] and x[3].overlaps(y[3]) and x[4].overlaps(y[4])


def main():
    atoms2 = [((F(0), F(0)), F(9)), ((F(7, 20), F(1, 20)), F(16))]
    roots2 = (F(3, 10), F(2, 5), F(1, 2))
    D2 = F(4, 25)
    # Top 11/20 is subthreshold since 25 < 100*(11/20)^2.
    assert F(25) < 100 * F(11, 20) ** 2 and F(11, 40) < min(roots2)
    rec2 = cells(2, atoms2, F(100), roots2, D2)
    both = next(r for r in rec2 if len(r["capture"]) == 2)
    both_precisions("single actual 2D cell", atoms2, [both])
    both_precisions("2D all actual D cells (fixed shifted grid)", atoms2, rec2)
    # Actual 4D rational roots: singleton a has t=1/2, pair has t=7/13.
    # Other singleton has mass 9855 and a root <1/2, so cannot be a later
    # root for a receiver already capturing a. All larger roots are tested.
    n = 4
    lam = F(16 * 13**4)
    a = F(13**4)
    b = F(16 * 7**4) - a
    assert a + b == lam * F(7, 13) ** 4 and a == lam * F(1, 2) ** 4 and b < a
    atoms4 = [((F(0),) * 4, a), ((F(2, 5), F(0), F(0), F(0)), b)]
    D4 = F(1, 16)
    rec4 = cells(n, atoms4, lam, (F(1, 2), F(7, 13)), D4, must_contain=0)
    assert sum(a["volume"] for a in rec4 if len(a["capture"]) == 2) > 0
    assert sum(a["volume"] for a in rec4 if len(a["capture"]) == 1) > 0
    both_precisions("4D actual roots, source-0 reception", atoms4, rec4)
    print(
        "\nPASS: exact cell volumes and rational probability; mutual information in overlapping 256- and 384-bit Arb balls; natural logs"
    )


if __name__ == "__main__":
    main()
