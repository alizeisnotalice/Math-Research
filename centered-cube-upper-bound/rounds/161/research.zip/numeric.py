#!/usr/bin/env python3
"""R161 actual 1D normalized kernel overlaps; quadrature is exploratory."""
from pathlib import Path
from fractions import Fraction as F
import argparse,hashlib,json,math,sys,warnings
ROOT=Path(__file__).resolve().parent
COUNTS={'phi_float':0,'C_float':0,'quad_pieces':0,'phi_mp':0,'C_mp':0}
SP=MP=None
GL={}

def Cfun(d):
    COUNTS['C_float']+=1;d=abs(float(d))
    if d==0:return 1.
    E=lambda x:float(MP.expint(4,MP.mpf(x))) if x else 1/3
    return 1-d+1/3-E(1)-E(d)+E(d+1) if d<=1 else E(d-1)-2*E(d)+E(d+1)
def phi(x):
    COUNTS['phi_float']+=1;r=abs(float(x));E=lambda x:float(MP.expint(3,MP.mpf(x))) if x else .5
    return 1-E(.5-r)-E(.5+r) if r<=.5 else E(r-.5)-E(r+.5)
def mp_phi(x):
    COUNTS['phi_mp']+=1;r=abs(x);h=MP.mpf('.5');E=lambda k,x:MP.mpf(1)/(k-1) if not x else MP.expint(k,x)
    return 1-E(3,h-r)-E(3,h+r) if r<=h else E(3,r-h)-E(3,r+h)
def mp_C(d):
    COUNTS['C_mp']+=1;d=abs(d);E=lambda x:MP.mpf(1)/3 if not x else MP.expint(4,x)
    if not d:return MP.mpf(1)
    return 1-d+MP.mpf(1)/3-E(1)-E(d)+E(d+1) if d<=1 else E(d-1)-2*E(d)+E(d+1)
def root_upper(q,den=8,digits=80):
    scale=10**digits;lo=0;hi=max(scale,(q.numerator*scale**den//q.denominator)+1)
    while lo+1<hi:
        mid=(lo+hi)//2
        if mid**den*q.denominator<=q.numerator*scale**den:lo=mid
        else:hi=mid
    r=F(lo,scale);return r if r**den==q else F(lo+1,scale)
def exp_negative_upper(x,N=256):
    assert x>=0;t=a=F(1)
    for j in range(1,N+1):t*=x/j;a+=t
    return 1/a

def tail_bound(s,L,d,R,theta=F(1,8),remote=False):
    # Rigorous analytic majorant using C(d)>=1/4 exp[-4(d+1)/3].
    if not s:return F(0)
    a=1-theta;coeff=root_upper((s/L)**a.numerator,a.denominator)
    if not remote:
        rate=a/L+theta;X=rate*R-F(1,2)-theta*d-F(4,3)*theta*(d+1);assert X>0
        return 2*coeff*root_upper(F(4)**theta.numerator,theta.denominator)*exp_negative_upper(X)/rate
    # 2 sinh(1/2)>1, so its negative theta power <=1.
    rates=[a/L-theta,a/L+theta];assert min(rates)>0
    return coeff*sum(exp_negative_upper(r*R-a/2)/r for r in rates)

def integrate(s,L,d,theta=F(1,8),remote=False):
    sf,Lf,df,tf=map(float,[s,L,d,theta]);a=1-tf;c=Cfun(df);assert c>0
    if sf==0:R=L/2
    elif remote:R=F(80)/(1-theta)/L if False else F(48)/( (1-theta)/L-theta )
    else:R=max(d+F(1,2),L/2)+40
    rf=float(R);breaks=sorted({-rf,rf,0.,-Lf/2,Lf/2}|({df-.5,df+.5} if not remote else set()));breaks=[x for x in breaks if -rf<=x<=rf]
    def f(x):
        p=((1-sf)*(1 if abs(x)<=Lf/2 else 0)+sf*phi(x/Lf))/Lf
        if p<=0:return 0.
        ratio=math.exp(x)/(2*math.sinh(.5)) if remote else phi(x-df)/c
        return p**a*ratio**tf
    value=error=0.;warn=[]
    for l,r in zip(breaks,breaks[1:]):
        if l==r:continue
        estimates=[]
        for order in [48,96]:
            nodes,weights=GL[order]
            estimates.append((r-l)/2*sum(float(w)*f((l+r)/2+(r-l)/2*float(t)) for t,w in zip(nodes,weights)))
        COUNTS['quad_pieces']+=1;value+=estimates[1];error+=abs(estimates[1]-estimates[0])
    tail=tail_bound(s,L,d,R,theta,remote);tail=F(-(-tail.numerator*10**30//tail.denominator),10**30);out=dict(s=str(s),L=str(L),d=str(d),theta=str(theta),C_float=c,value=value,quad_error_estimate=error,analytic_tail_upper_rational=str(tail),analytic_tail_upper_float=float(tail),R=str(R),quad_warnings=warn,quad_is_interval_certified=False,remote_limit_integrand=remote)
    out['heuristic_total_lower']=value-error;out['heuristic_total_upper']=value+error+float(tail)
    return out

def mp_control(row,dps=50):
    MP.mp.dps=dps;s,L,d,theta=[MP.mpf(str(F(row[k]).numerator))/F(row[k]).denominator for k in ['s','L','d','theta']];a=1-theta;c=mp_C(d);R=MP.mpf(str(F(row['R']).numerator))/F(row['R']).denominator
    def f(x):
        p=((1-s)*(1 if abs(x)<=L/2 else 0)+s*mp_phi(x/L))/L
        return p**a*(mp_phi(x-d)/c)**theta if p>0 else MP.mpf(0)
    cuts=sorted({-R,R,MP.mpf(0),-L/2,L/2,d-MP.mpf('.5'),d+MP.mpf('.5')});cuts=[x for x in cuts if -R<=x<=R]
    nodes,weights=GL[96]
    value=MP.fsum((r-l)/2*MP.fsum(MP.mpf(float(w))*f((l+r)/2+(r-l)/2*MP.mpf(float(t))) for t,w in zip(nodes,weights)) for l,r in zip(cuts,cuts[1:]) if l<r)
    return dict(dps=dps,value=MP.nstr(value,dps),C=MP.nstr(c,dps),absolute_difference_from_float=MP.nstr(abs(value-row['value']),20),certified_interval=False,note="50-digit integrand reevaluation on same 96-point binary64 Gauss nodes; not independent quadrature")

def log_upper(x,N=96):
    # x>=1: exact atanh series with a geometric positive remainder.
    assert x>=1
    z=(x-1)/(x+1);part=sum((2*z**(2*j+1)/F(2*j+1) for j in range(N)),F(0))
    return part+2*z**(2*N+1)/(F(2*N+1)*(1-z*z))
def certificates():
    delta=F(847,4193408);assert delta>F(1,5000)
    x=F(7,4);term=partial=F(1)
    for j in range(1,33):term*=x/j;partial+=term
    expupper=partial+term*x/33/(1-x/34)
    assert expupper<6 and log_upper(F(2))<1
    assert 2*F(1,8)*F(7,8)*F(11,362)**2==delta
    assert 1-F(1,5000)+32*F(1,320000)==F(9999,10000)
    assert sum((F(1,math.factorial(k)) for k in range(5)),F(0))>F(8,3)
    bound=128*9375**2*97;assert 9375<97**2 and bound<2**40
    def ln(n):
        k=n.numerator.bit_length()-n.denominator.bit_length()
        while F(2)**k>n:k-=1
        return k*log_upper(F(2))+log_upper(n/F(2)**k)
    n0=2**19;margin=F(n0,10000)-F(5,2)*ln(F(n0+2))-log_upper(F(8,3))
    assert margin>0 and F(1,10000)>F(5,2)/F(n0+2)
    table=[]
    for n in [1,2,8,128,10000,n0-1,n0,n0+1,1000000,1000000000]:
        if n>=n0:assert F(n,10000)-F(5,2)*ln(F(n+2))-log_upper(F(8,3))>0
        table.append(dict(n=n,large_branch_checked=n>=n0))
    return dict(status='PASS_EXACT_RATIONAL',exp_7_over_4_upper=str(expupper),log2_upper=str(log_upper(F(2))),binary_gap=str(delta),gap_minus_one_over_5000=str(delta-F(1,5000)),soft_exponent_identity='(320000^(-8/7))^(7/8)=1/320000',mixed_target='9999/10000',cost_majorant='128*n^3*exp(-n/10000)',all_n_normalized_upper=bound,all_n_constant=2**40,large_n_start=n0,large_n_constant=48,large_log_margin_exact=str(margin),analytic_reduction='max n^(5/2)exp(-n/10000) at25000; e>8/3 gives25000/e<9375,sqrt9375<97. For n>=2^19, n/10000-2.5log(n+2)>log(8/3) with positive derivative, so128n^3exp(-n/10000)<=48sqrt(n)',table=table)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=ROOT/'numeric.json');ap.add_argument('--vendor',default='/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor');args=ap.parse_args();sys.path.insert(0,args.vendor)
    global SP,MP
    import numpy as np
    import mpmath as mp
    import time
    started=time.monotonic();SP,MP=np,mp;MP.mp.dps=35
    for order in [48,96]:GL[order]=np.polynomial.legendre.leggauss(order)
    cert=certificates();D=2**100;lo,hi=0,D
    while lo+1<hi:
        mid=(lo+hi)//2
        if mid**7*320000**8<=D**7:lo=mid
        else:hi=mid
    sstar=F(lo,D);assert sstar**7<=F(1,320000**8) and F(lo+1,D)**7>F(1,320000**8)
    stages={};cache={}
    def run(s,L,d):
        key=(s,L,d)
        if key not in cache:cache[key]=integrate(s,L,d)
        return cache[key]
    stages['initial']=[run(s,L,d) for s in [F(0),sstar] for L in [F(1,2),F(1)] for d in [F(0),F(1,2),F(1)]]
    print('initial12 completed',flush=True)
    stages['threshold_and_remote']=[run(sstar,F(1),d) for d in [F(1,2)-F(1,10000),F(1,2)+F(1,10000),F(8),F(32)]]
    stages['expanded']=[run(s,F(3,4),d) for s in [F(0),sstar/2,sstar] for d in [F(2),F(16)]]
    controls=[]
    for s,L,d in [(F(0),F(1),F(1,2)),(sstar,F(1),F(32)),(sstar,F(3,4),F(16))]:
        controls.append(dict(s=str(s),L=str(L),d=str(d),mp50_same_nodes_precision=mp_control(run(s,L,d))))
    rows=list(cache.values());out=dict(status='EXACT_SCALARS_PASS_FINITE_KERNEL_DIAGNOSTIC',source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),author_sha256=hashlib.sha256((ROOT/'uniform_core_gap.md').read_bytes()).hexdigest(),certificates=cert,soft_gate=dict(algebraic='320000^(-8/7)',s_used_exact=str(sstar),s_used_float=float(sstar),s_lower_and_adjacent_upper_checked=True),stages=stages,precision_controls=controls,summary=dict(objects=len(rows),max_hard_normalized=max(r['value'] for r in rows if F(r['s'])==0),max_soft_normalized=max(r['value'] for r in rows if F(r['s'])>0),max_48_96_difference=max(r['quad_error_estimate'] for r in rows),max_tail_upper=max(r['analytic_tail_upper_float'] for r in rows)),runtime=dict(python=sys.executable,numpy_version=np.__version__,numpy_path=np.__file__,mpmath_version=mp.__version__,mpmath_path=mp.__file__,vendor=args.vendor,elapsed_seconds=time.monotonic()-started),execution=dict(producer_invocations=2,successful_invocations=2,failed_invocations=0,prewrite_missing_backup_path_attempt=1,function_counts=COUNTS,new_original_receiver_points=0),scope=['Actual E3/E4 1D kernels only; no original FULL traffic simulated','Exact rational scalar certificates separate from finite quadrature','48/96 difference not certified error; mp50 same nodes arithmetic precision only','Rational analytic omitted-tail upper bound; finite integral not interval-certified','All-n assertions use analytic calculus reduction, not table interpolation'])
    args.output.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(json.dumps(out['summary']))
if __name__=='__main__':main()
