#!/usr/bin/env python3
"""Verify archived sources and replay the finite R161 menu. No PDF compilation."""
import argparse,ast,hashlib,json,re,subprocess,sys
from pathlib import Path
root=Path(__file__).resolve().parent
ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,required=True);ap.add_argument('--vendor');args=ap.parse_args()
assert not args.output.exists(),'Use a new output path'
manifest=json.loads((root/'manifest.json').read_text())
for name,digest in manifest['sha256'].items():
    assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
for name in ['numeric.py','reproduce.py']:ast.parse((root/name).read_text())
stack=[]
for kind,name in re.findall(r'\\(begin|end)\{([^}]+)\}',(root/'research.tex').read_text()):
    if kind=='begin':stack.append(name)
    else:assert stack.pop()==name
assert not stack
cmd=[sys.executable,str(root/'numeric.py'),'--output',str(args.output)]
if args.vendor:cmd+=['--vendor',args.vendor]
subprocess.run(cmd,check=True)
a=json.loads((root/'numeric.json').read_text());b=json.loads(args.output.read_text())
def compare(x,y,path=''):
    if isinstance(x,dict):
        assert x.keys()==y.keys(),path
        for k in x:
            if path=='' and k=='runtime':continue
            compare(x[k],y[k],path+'/'+k)
    elif isinstance(x,list):
        assert len(x)==len(y),path
        for i,(u,v) in enumerate(zip(x,y)):compare(u,v,path+'/'+str(i))
    elif isinstance(x,float):assert abs(x-y)<=1e-10*max(1,abs(x)),path
    else:assert x==y,path
compare(a,b)
print('PASS: archive hashes, Python syntax, TeX environment balance, exact certificate equality, finite replay comparison. Float tolerance is NOT an integration error certificate.')
