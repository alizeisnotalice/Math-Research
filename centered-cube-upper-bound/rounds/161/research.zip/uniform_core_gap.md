# R161：全部源位移的一致 hard 归一化分数矩缺口

筛查结论：所需全域缺口成立，可以显式取
\[
\boxed{\theta=1/8,\qquad \delta_\theta=1/5000.}
\]
证明不依赖 R128 的微小缺口。与 R160 已证的 normalized soft moment 32 拼接后，得到全部 \(z_g\le1\) 适用的严格正 soft 带；不再要求 \(z_g<Z<1\)。本文件只负责真实核几何，不证明原交通的来源、共同时间或负账接口。

## 1. 对象与命题

令
\[
h=\mathbf1_{[-1/2,1/2]},\qquad
w(u)=\int_0^1e^{-|u|/r}dr,\qquad
\varphi=h*w,\qquad F=\max(h,\varphi),
\]
\[
C(d)=\int_{-1/2}^{1/2}F(x-d)dx,
\qquad h_\lambda(x)=\lambda^{-1}\mathbf1_{[-\lambda/2,\lambda/2]}(x).
\]
Here \(\int w=1\); \(\varphi\) is positive, even, and nonincreasing on the positive half-line, with \(\varphi\le1\). Consequently \(C\) is even and \(0<C\le1\).

For every \(1/2\le\lambda\le1\), every \(d\in\mathbb R\), and \(\theta=1/8\),
\[
\boxed{\quad
\int_{\mathbb R}h_\lambda(x)^{1-\theta}
\left(\frac{\varphi(x-d)}{C(d)}\right)^\theta dx
\le1-\frac1{5000}.
\quad} \tag{1}
\]
The denominator is the original \(C(d)\), not the \(\varphi\)-mass of the restricted receiver interval. Symmetry allows us to assume \(d\ge0\).

Put
\[
I=[-\lambda/2,\lambda/2],\quad j(x)=\varphi(x-d),\quad
q_I=\int_Ij(x)dx.
\]
Always \(q_I\le C(d)\), since \(I\subset[-1/2,1/2]\) and \(\varphi\le F\).

## 2. Near-source case: \(0\le d\le1/2\)

Direct convolution gives
\[
\varphi(0)=\int_0^1 2r(1-e^{-1/(2r)})dr
=1-\int_0^1 2r e^{-1/(2r)}dr.
\]
On \(r\in[1/2,1]\), \(e^{-1/(2r)}\ge e^{-1}\), so
\[
1-\varphi(0)\ge\frac34e^{-1}\ge\frac14,
\qquad \varphi(x)\le\varphi(0)\le\frac34.
\tag{2}
\]
The weak inequality uses \(e<3\).

The intervals \([-1/2,1/2]\) and \([d-1/2,d+1/2]\) overlap in length \(1-d\ge1/2\). On that overlap, \(h(x-d)=1\), so \(F(x-d)-\varphi(x-d)\ge1/4\). Thus
\[
C(d)-q_I
\ge C(d)-\int_{-1/2}^{1/2}\varphi(x-d)dx
\ge\frac18.
\]
Since \(C(d)\le1\), this implies \(q_I/C(d)\le7/8\). Hölder on \(I\), followed by the concave tangent bound at 1, gives
\[
\int h_\lambda^{1-\theta}(j/C(d))^\theta
\le(q_I/C(d))^\theta
\le(7/8)^\theta\le1-\theta/8
=1-\frac1{64}.
\tag{3}
\]

## 3. Far-source case: \(d\ge1/2\)

For \(u\ge1/2\), the original convolution has the tail representation
\[
\varphi(u)=\int_0^1r(1-e^{-1/r})e^{-(u-1/2)/r}dr.
\]
Its negative logarithmic derivative is a positive weighted average of \(1/r\), hence
\[
-\frac{d}{du}\log\varphi(u)\ge1\quad(u\ge1/2).
\tag{4}
\]
The endpoint follows by continuity of the first derivative. On the whole interval \(I\), \(d-x\ge0\), so \(j(x)\) is nondecreasing. On the left half \([-\lambda/2,0]\), we have \(d-x\ge1/2\), and (4) gives \((\log j)'\ge1\).

Write \(t=\lambda/2\in[1/4,1/2]\) and \(j_0=j(0)>0\). Integrating the logarithmic slope and using monotonicity on the right half,
\[
\int_{-t}^0j(x)dx\le j_0(1-e^{-t}),
\qquad
\int_0^tj(x)dx\ge t j_0.
\tag{5}
\]
There is a convenient rational upper bound
\[
\frac{1-e^{-t}}t=\int_0^1e^{-tu}du
\le4(1-e^{-1/4})\le\frac{85}{96}.
\tag{6}
\]
The first inequality uses \(t\ge1/4\). For the second, the elementary third-order Taylor lower bound
\(e^{-x}\ge1-x+x^2/2-x^3/6\), at \(x=1/4\), gives
\(1-e^{-1/4}\le85/384\). Its remainder is nonnegative, so no asymptotic approximation is being used.

Let \(Q\) be the probability density \(j/q_I\) on \(I\), and \(U\) the uniform probability density \(h_\lambda\). If \(A=[-t,0]\), then \(U(A)=1/2\); equations (5), (6) imply
\[
u:=Q(A)\le\frac{85}{181},
\qquad \frac12-u\ge\frac{11}{362}.
\tag{7}
\]
Thus the normalized restriction cannot become nearly uniform, even when \(d\) is arbitrarily large.

## 4. A binary fractional-moment gap with explicit curvature

For any probability densities \(U,Q\) and an event with \(U(A)=1/2\), Hölder separately on \(A,A^c\) gives
\[
\int U^{1-\theta}Q^\theta
\le B_\theta(u):=2^{-(1-\theta)}
\{u^\theta+(1-u)^\theta\},\qquad u=Q(A).
\]
For \(0<u<1\), convexity of \(v^{\theta-2}\) gives
\[
\begin{aligned}
B_\theta''(u)
&=-2^{-(1-\theta)}\theta(1-\theta)
\{u^{\theta-2}+(1-u)^{\theta-2}\}\\
&\le-4\theta(1-\theta).
\end{aligned}
\]
As \(B_\theta(1/2)=1\), \(B_\theta'(1/2)=0\), integrating this curvature bound twice yields
\[
B_\theta(u)\le1-2\theta(1-\theta)(u-1/2)^2.
\tag{8}
\]
Endpoint cases follow by continuity. This direct fractional-moment estimate avoids losing constants by first converting through Hellinger affinity.

The actual hard normalized moment factors as
\[
\int h_\lambda^{1-\theta}(j/C(d))^\theta
=\left(\frac{q_I}{C(d)}\right)^\theta
\int U^{1-\theta}Q^\theta
\le\int U^{1-\theta}Q^\theta.
\]
Using (7), (8), and \(\theta=1/8\), its deficit is at least
\[
2\theta(1-\theta)\left(\frac{11}{362}\right)^2
=\frac7{32}\frac{121}{131044}
=\frac{847}{4193408}>\frac1{5000}.
\tag{9}
\]
The final comparison is exact: \(847\cdot5000-4193408=41592>0\). Combining the far-source estimate (9) with the stronger near-source estimate (3) proves (1). No compactness claim or local Taylor expansion in the source displacement is needed.

## 5. Positive soft extension for the entire \(z_g\le1\) range

R160 established, directly from the original kernel, the uniform soft moment
\[
\int\varphi_\lambda(x)^{7/8}
\left(\frac{\varphi(x-d)}{C(d)}\right)^{1/8}dx\le32,
\quad 1/2\le\lambda\le1,\quad d\in\mathbb R.
\tag{10}
\]
For clarity, its short proof uses the global 4-Lipschitz bound for \(\log\varphi\), implying
\(\varphi(x-d)/C(d)\le e^2e^{4|x|}\), and the true receiver tail bound
\(\varphi_\lambda(x)\le4e^{-|x|}\). The resulting integral is
\(4^{7/8}e^{1/4}\int e^{-3|x|/8}dx<32\). These are the R160 elementary kernel inequalities; (10) is not a source-moment assumption.

Set
\[
\delta=\frac1{5000},\qquad
S_*:=\left(\frac\delta{64}\right)^{8/7}
=320000^{-8/7},\qquad q_*:=1-\frac\delta2=\frac{9999}{10000}.
\]
Using \((A+B)^{7/8}\le A^{7/8}+B^{7/8}\), (1), (10), for all \(0\le s\le S_*\),
\[
\begin{aligned}
\int p_{s,\lambda}^{7/8}(j_d/C(d))^{1/8}
&\le(1-s)^{7/8}(1-\delta)+32s^{7/8}\\
&\le1-\delta+32S_*^{7/8}
=1-\delta/2=q_*<1.
\end{aligned}
\tag{11}
\]
Since \(0<C(d)\le1\), every \(0<z_g\le1\) satisfies
\[
\min\{1,C(d)/z_g\}\ge C(d).
\]
Consequently (11) holds, with the same \(q_*\), when the denominator \(C(d)\) is replaced by the actual one-coordinate core weight. There is no cutoff \(z_g\le Z<1\) and no source-displacement floor.

## 6. Kernel consequences and applicability limits

For \(P_{s,L}(x-y)=L^{-n}\prod_i p_s((x_i-y_i)/L)\), \(J_v(x)=b^{-n}\prod_i\varphi((x_i-v_i)/b)\), and
\[
w_1(y,v)=\prod_i C((y_i-v_i)/b),
\]
coordinate scaling and Tonelli give, for \(b/2\le L\le b\),
\[
\boxed{\quad
\int P_{s,L}(x-y)^{7/8}
\left(\frac{J_v(x)}{w_1(y,v)}\right)^{1/8}dx
\le q_*^n\le e^{-n/10000},\quad0\le s\le S_*.
\quad} \tag{12}
\]
The original \(w_g=\prod_i\min(1,C_i/z_g)\) satisfies \(w_g\ge w_1\) throughout \(z_g\le1\), so it can replace \(w_1\) on the left. Tensorization here is only with respect to receiver coordinates for each fixed source; it assumes no independent source measure.

The same \(s\)-grid and upward scale grid as R160 preserve \(s\le S_*\), cost at most \(n(n+1)\) terms, and give a factor \(e^{7/4}\) after taking the \(7/8\) power. Thus the kernel-only min estimate for fixed \(A,B\ge0\) has the explicit selector price
\[
\int\sup_{\substack{0\le s\le S_*\\a\le L\le b}}
\min\{B P_{s,L},A J_v/w_1\}\,dx
\le e^{7/4}n(n+1)B^{7/8}A^{1/8}q_*^n,
\qquad b/a\le2.
\tag{13}
\]
This is a kernel corollary, not the proof of the original source/time interface. In particular an \(x\)-dependent posterior, score, common-\(\alpha\) factor or source coefficient cannot be placed outside this integral without its own valid argument.

Finally the original strict lower soft gate remains in force. If it is \(s>1-2^{-1/n}\), then \(n>(\log2)/S_*\) is a sufficient condition for the positive band to intersect that gate, because \(1-e^{-u}\le u\). Smaller dimensions are not declared paid by the present exponential kernel tool. The original full traffic, all complementary soft branches, and the general weak-type objective remain outside the claim of this file.

