# R310 historical cap check: same-receiver larger hard scales

## Finding

The original FULL hard-band event does provide a hard-source cap at the **same receiver (x), for every physical scale (R'\in[a,b])**, not just at selected (R(x)). The cap is valid only on the original retained receiver event (E) and only within that original octave. It does not license enlarging (E), using (R'>b), or inferring an all-scale cap from the selected-radius inequality alone.

R302/R303 state only SAME-receiver/SAME-radius caps in their abstract geometric hypotheses (`rounds/302/research.zip::r302_geometry.md:5`; `rounds/303/research.zip::r303_geometry.md:5`). For an application to the original event, the stronger all-scale cap is separately available from the inherited hard-band definition, as R244 explicitly records. This is a historical applicability observation, not an extension of the R302 theorem.

## Exact original cap and its scope

1. The original complete input is (f\ge0), with common (q\in[3\lambda/4,\lambda]), original receiver event `2lambda<G0<=4lambda`, and `G0=sup_(a<=L<=b) P_(0,L)*f` (`/Users/zhengzhihao/Desktop/T/output/cube_general_20261003/GENERAL_CURRENT_REDUCTION.md:5–13`). Since `P_(0,R')=h_(R')`, on every original (x\in E) and every (R'\in[a,b]),
   `h_(R')*f(x) <= G0(x) <= 4lambda <= (16/3)q`.
   Here `h_(R')` is the normalized hard cube kernel (cube side (R')); equivalently
   `integral_(Q_(R')(x)) f <= 4lambda (R')^n`.
2. The historical independent receiver-ledger audit states this exact consequence as RL1: `rounds/244/research.zip::receiver_ledger.md:9–29`, especially lines 13–19, and emphasizes lines 24–29 that rounded (R_i\in[a,b]) inherits it, the proof is not pointwise comparison from a selected-radius cap, and no cap transfers to added receivers or scales outside `[a,b]`.
3. The earlier selected-scale formulation is weaker: `rounds/112/research.zip::proof.md:401–409` (J1) states only `h_(R(x))*f(x)<=4lambda` alongside `a<=L_s(x),R(x)<=b`; R128 RT1 likewise records only selected `h_R f<=4lambda` at `rounds/128/research.zip::proof.md:604–611`. Those displays alone must not be used to infer a larger-scale cap. The inference is justified by the separately retained original G0 event above.
4. Original FIRST is a distinct soft condition. The same full-event reduction gives `P_(sigma,L)*f=q` and `P_(s,R)*f<=q` for every `s>=sigma`, (R\in[a,b]) (`GENERAL_CURRENT_REDUCTION.md:9–13`). R302's source-facing FIRST is instead `integral p_y beta(dy)<=q(x)` (`rounds/296/research.zip::joint_envelope.md:4–7`, with R302 same-instance setup at `302::r302_geometry.md:5–7`). Keep FIRST and the hard (h_{R'}f) cap distinct.

## Source domination and what it buys

- In the original source ancestry, `mu_hi=f_hi dy<=f dy` (`GENERAL_CURRENT_REDUCTION.md:19`), `alpha_V=mu_hi|V`, and the later coupled soft source satisfies `beta^c=alpha-eta_alpha^c<=alpha` while retaining the original hard ν (`rounds/237/research.zip::source_ledger.md:21–26`; the explicit coupled chain is at line 25). Thus for that **specific original coupled beta**, `beta^c<=mu_hi<=f`. The original hard source also satisfies `nu_V<=sigma_V<=alpha_V<=f`, recorded at `rounds/112/research.zip::proof.md:401–402` and `rounds/128/research.zip::proof.md:611`. A positive restriction such as `nu_h<=nu` keeps the same domination.
- R302's standalone statement permits arbitrary finite positive L1 β,ν (`302::r302_geometry.md:5`) and by itself does **not** assume β,ν are dominated by the original (f). Importing the original cap is valid only after identifying those generic measures with the original dominated sources above. Do not silently apply (f)-domination to an unrelated generic R302 pair.
- If an original hard source point (z) is captured at (x), so (z\in Q_{R(x)}(x)), and (Q_{2Db}(z)) denotes a cube of side (2Db), then coordinatewise
  `Q_(2Db)(z) subset Q_(R(x)+2Db)(x)`.
  The all-scale cap therefore yields the exact conditional column bound
  `beta(Q_(2Db)(z)) <= 4lambda (R(x)+2Db)^n`
  **provided** `R(x)+2Db<=b` (and this scale lies in the original `[a,b]`). Relative to R302's heavy/light threshold `q_- a^n L0`, the ratio is at most
  `(16/(3 L0))*((R(x)+2Db)/a)^n`, with `q_-=3lambda/4`. If only use `R(x)+2Db<=b<=2a`, the ratio is at most `(16/(3 L0))*2^n`; that is an exponential-in-dimension scale cost, not a root-order price.
- If `R(x)+2Db>b`, the inclusion reaches outside the original hard-band scale range, and the archive supplies no cap for the part outside (Q_b(x)). The same-radius cap `h_(R(x))*f(x)` cannot fill this gap: it controls only mass in (Q_{R(x)}(x)). R244 explicitly rules out scales outside `[a,b]` and added receiver points (lines 24–29).

## Consequence for the R302 column split

R303's frozen partition uses `Z_l={z: beta(Q_(2D0 b)(z))<=q_-a^n L0}` and `Z_h=Z_l^c` (`rounds/303/research.zip::r303_combined_budget.md:5–12`). The source-pair geometric inclusion above shows how the original all-scale cap could pay a captured column **only when** the enlarged cube is contained within some allowed same-receiver hard cube, e.g. `R(x)+2D0b<=b`. No cited archive establishes that containment for all captured (z), all relevant (x), or the full (Q_{2D0b}(z)); in the stated octave it can fail, and even when it holds the ratio to `q_-a^nL0` has the crude factor `(16/(3L0))*((R+2D0b)/a)^n`. Therefore the R302/R303 heavy-column term is not automatically erased by the all-scale cap. Any sharper use would need a new, explicit overlap/receiver-scale allocation; none is claimed here.

## Additional narrow check: higher-softness FIRST versus R292/R309's actual softness

**What the stronger original FIRST actually says.** `/Users/zhengzhihao/Desktop/T/output/cube_general_20261003/GENERAL_CURRENT_REDUCTION.md:9–13` retains `G_s=sup_(a<=L<=b)P_(s,L)*f` on `2lambda<G0<=4lambda`, and states the original interior condition `P_(sigma,L)*f=q`, `P_(s',R')*f<=q` for every `s'>=sigma` and `R' in [a,b]`. If the row's actual softness is exactly this FIRST crossing σ(x), and the row's `q(x)` is the same `q`, then positivity plus `beta<=f` immediately gives `P_(s',R')*beta(x)<=q(x)` at every higher softness and every octave scale. This is a conditional implication, not itself a separate FIRST assumption.

**Mapping not established by the cited R292/R309 source definitions.** R107's actual input equation labels its selected kernel `P_(s(x),L_s(x))f(x)=q` (`rounds/107/research.zip::proof.md:905–911`). A separate R107 formula N1 writes `P_(sigma(x),L_s(x))` (`:455–465`), but the inspected lines do not state the identity `sigma(x)=s(x)` or define N1's sigma there. R112 continues to specify only `P_(s(x),L_s(x))f=q` (`rounds/112/research.zip::proof.md:401–409`). R292's clipped-kernel note explicitly chooses a frozen upper envelope parameter “covering the actual softness” and says `sigma=1` always works (`rounds/292/research.zip::lowpe_geometry.md:25–30`); that σ is a majorant parameter, not evidence that actual softness equals the FIRST crossing. R309 defines the actual parameter as `s(x)` and uses `P_(s(x),L(x))` (`rounds/309/research.zip::r309_geometry.md:7–10`; also `r309_combined.md:7,14–17`), while its cited setup states FIRST and same-R hard cap but does not state the all-higher-softness/all-scales property.

**Historical conclusion.** There is an authoritative all-higher-softness cap relative to the named σ crossing in the full-event reduction. In the inspected original R107/R112 and R292/R309 definitions, however, no explicit mapping identifies R309's actual `s(x)` with that σ, or its `q(x)` with the common `q` in that cap. Therefore do not yet claim that R309 owns `P_(s',L')*f(x)<=q(x)` for every `s'>=s(x), L' in[a,b]`. The exact missing bridge is that selector/level identity. Once supplied, β≤f makes the higher-softness cap available to the original soft source; without it, the proposed two-component response payment is not justified by the located FIRST statements. The usual positivity consequence would control each nonnegative weighted tensor component by the total cap at the same `s',L'`; it would not give a componentwise cap after changing softness or scale independently.
