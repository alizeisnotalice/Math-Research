# R310 main: a true small-softness endpoint source receipt

General root weak-(1,1) remains unproved. All original qualifications, q>=q_-=3lambda/4, a<=L,R<=b<=2a, actual dx, source beta,nu_*, common theta and SAME-R hard cap <=4lambda are retained. Use the real kernel and the inherited positive component scale envelope from R308. No independent component FIRST is used.

Let s0<=1/n be fixed within the original outer instance, independent of x,y,z. For k>=1, b_nk(s)=binom(n,k)s^k(1-s)^(n-k) is nondecreasing on [0,s0], since on (0,1) its derivative has sign k-ns>=0. Endpoints follow by continuity, including n=k=1. Thus the actual positive-soft part on s(x)<=s0 is dominated by

  (1/q_-) sum_{k=1}^n b_nk(s0) [Q_{k,b}(x-y)+n integral_a^b Q_{k,L}(x-y)dL/L].

The integral over x is at most A_n[1-(1-s0)^n]/q_- <= A_n n s0/q_-, A_n=1+n log(b/a). We have not replaced the actual component weights on the left or changed their original source gates.

For ANY positive capturing component of the original pair residual with these soft degrees, drop the fixed mask M<=1 and the noncapture-prefix factor (J-A)/J<=1. The remaining integral is bounded by its actual capture target. Drop qualifications only positively, then use the SAME selected-radius hard-source cap <=4lambda. Tonelli over beta gives the actual source receipt

  R_soft,s<=s0 <= (16/3) A_n[1-(1-s0)^n]W_beta
               <= (16/3) A_n n s0 W_beta.                    (1)

The common theta integral has total mass one. This does not assume density bounds on either source, a cap at virtual receivers, or independent per-degree FIRST. If two components form disjoint original prefix domains, or partition actual degrees at a shared prefix, their union uses (1) once, not separately.

## When the pure hard part vanishes from the original qualified capture

At a point in Q_L(y), the full original kernel satisfies P_{s,L}(x-y)L^n >= (1-s)^n >=1-n s0 for s<=s0. Let tau(x,y,z) be an ACTUALLY applicable original dimensionless upper height on qualified captures: P_{s,L}L^n<=tau. Define the original tuple event

  Z={s(x)<=s0, tau(x,y,z)<1-n s0}.

There are no qualified captures in Z lying in Q_L(y). Hence the k=0 component vanishes on Z, and the ENTIRE original capturing kernel on Z consists of k>=1. Formula (1) therefore pays any original positive residual restricted to Z, including both retained R309 degree branches. The strict height condition is essential; its equality and complement are retained. When s=0, Z has no qualified capture at all, so no division by s is made.

For any desired eta>0 choose

  s0=min(1/(2n),3eta/(16 A_n n)).

Then (1)<=eta W_beta and 1-n s0>=1/2. This is an explicit source payment of the endpoint branch, not a claim that all s<=s0 qualifies for that branch. High tau remains unpaid. Original scale/aspect/height factors must stay in tau; in the applicable original band one may take the min of the two audited heights, but never apply a height outside its support assumptions.

## Original ledger use and no duplicate fees

Start with the exact R309 residual

  R1=R_lowp(U_hi), R2=R_allp(U_lo 1_Gc).

On the low-p prefix their two capturing densities sum to at most U; on the middle prefix only the second exists. Restrict both to Z, sum first, and use (1) once. The unpaid terms are exactly R1 restricted to Z^c and R2 restricted to Z^c. If the new total-exterior-depth tail is subsequently removed from R2, apply it only on Z^c, or retain a nonnegative upper bound while keeping the exact unremoved allocation explicit. Do not pay the same component twice.

The adopted R309 outer coefficient is (128/5)Lambda, so the new source payment in the actual target inequality is (128/5)Lambda eta W_beta. It is NOT eta X. Other R304 ledger slots and all original outer integration remain separate. This endpoint lemma does not bound low-p high-degree at larger s, nor shallow-depth low-degree traffic, nor the high-tau tiny-softness complement.

## Executed numerical evidence

r310_endpoint.py ran locally with Python standard-library Fraction: 4354 exact checks across small n=1,2,4, boundary n=8,16, expanded n=32,64,128, plus aggregate tests n=256,1024,4096. It checks component monotonicity, binomial mass and hard lower bounds, source-price thresholds and a rational exponential Taylor comparison. It does not simulate full original history; the analytic argument above proves the continuum statements. No PDF compiled.
