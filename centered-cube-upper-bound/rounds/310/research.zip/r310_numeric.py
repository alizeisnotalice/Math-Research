#!/usr/bin/env python3
"""R310 actual 1D phi/h-mixture capture and outside-coordinate count moments."""
import json,sys,itertools,math,hashlib
from pathlib import Path
from fractions import Fraction as F
try:import mpmath as mp
except ImportError:
 sys.path.insert(0,'/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor')
 import mpmath as mp
COUNTS={};FAIL=[];DPS=45;mp.mp.dps=DPS
RVALUES=[F(1,2),F(1),F(2)];DVALUES=[F(0),F(1,4),F(1,2),F(1),F(2),F(4)];SVALUES=[F(0),F(1,1024),F(1,64),F(1,4),F(1)]
def ck(ok,label,data):
 COUNTS[label]=COUNTS.get(label,0)+1
 if not ok:FAIL.append({'test':label,'data':data})
def mm(q):return mp.mpf(q.numerator)/q.denominator
def fmt(q,d=DPS):return mp.nstr(q,d)
def phi(x):
 x=abs(x)
 if x<=mp.mpf('.5'):return 1-mp.expint(3,mp.mpf('.5')+x)-mp.expint(3,mp.mpf('.5')-x)
 return mp.expint(3,x-mp.mpf('.5'))-mp.expint(3,x+mp.mpf('.5'))
def cdfphi(x):
 if x<0:return 1-cdfphi(-x)
 if x<=mp.mpf('.5'):return mp.mpf('.5')+x+mp.expint(4,mp.mpf('.5')+x)-mp.expint(4,mp.mpf('.5')-x)
 return 1-mp.expint(4,x-mp.mpf('.5'))+mp.expint(4,x+mp.mpf('.5'))
def moments(R,d,quad=True):
 lo=mm(d-R/2);hi=mm(d+R/2);points=sorted(set([lo,hi]+[v for v in [-mp.mpf('.5'),mp.mpf('.5')] if lo<v<hi]));A=cdfphi(hi)-cdfphi(lo);B=mp.mpf(0);AQ=BQ=mp.mpf(0)
 for left,right in zip(points,points[1:]):
  outside=abs((left+right)/2)>mp.mpf('.5')
  if outside:B+=cdfphi(right)-cdfphi(left)
  if quad:
   q=mp.quad(phi,[left,right]);AQ+=q
   if outside:BQ+=q
 hard=max(F(0),min(d+R/2,F(1,2))-max(d-R/2,F(-1,2)))
 return A,B,AQ,BQ,hard,points
GEOMETRIES=[(F(1),F(0)),(F(1),F(1,4)),(F(1),F(1,2)),(F(1),F(2)),(F(1,2),F(4)),(F(2),F(0))]
base={};geometry_records=[];capture_records=[]
for R,d in GEOMETRIES:
 A,B,AQ,BQ,hard,points=moments(R,d);tol=mp.mpf('1e-36')
 ck(abs(A-AQ)<tol and abs(B-BQ)<tol,'actual_phi_capture_E4_vs_segmented_quad45',{'R':str(R),'d':str(d)})
 base[R,d]=(A,B,AQ,BQ,hard);geometry_records.append({'R':str(R),'d':str(d),'phi_capture_A':fmt(A),'phi_capture_outside_B':fmt(B),'hard_overlap_exact':str(hard),'split_points':list(map(fmt,points))})
 for s in [F(0),F(1,4),F(1)]:
  a=(1-mm(s))*mm(hard)+mm(s)*A;b=mm(s)*B
  ck(0<=b<=a<=1 and abs(a-((1-mm(s))*mm(hard)+mm(s)*AQ))<tol,'actual_mixture_joint_moment_ranges_and_quad45',{'R':str(R),'d':str(d),'s':str(s)})
  capture_records.append({'R':str(R),'d':str(d),'s':str(s),'a_capture':fmt(a),'b_capture_outside':fmt(b),'inside_a_minus_b':fmt(a-b)})
# Actual phi depth moment: one independent x-integral and the Tonelli t-integral.
momentvalues=[]
for dp in [45,60]:
 with mp.workdps(dp):
  inside=1-2*(mp.mpf(1)/3-mp.expint(4,1))
  moment=inside+2*mp.quad(lambda t:t*t*(1-mp.exp(-1/t))/(1-t/2),[0,mp.mpf('.5'),1])
  direct=2*mp.quad(phi,[0,mp.mpf('.5')])+2*mp.quad(lambda e:mp.exp(e/2)*phi(mp.mpf('.5')+e),[0,1,4,16,mp.inf])
  Wmoment=8*mp.log(2)-4
  ck(abs(moment-direct)<mp.mpf('1e-34'),'actual_phi_depth_moment_Tonelli_vs_direct_x_quad',{'precision':dp})
  ck(1<=moment<=Wmoment<2,'actual_phi_depth_moment_le_W_moment_le_two_ordinary_mp',{'precision':dp})
  momentvalues.append((moment,Wmoment))
with mp.workdps(70):
 momenterr=abs(momentvalues[0][0]-momentvalues[1][0]);ck(momenterr<mp.mpf('1e-34'),'actual_depth_moment_45_60_refinement',{})
 momentrecord={'M_phi_exp_depth_over2':fmt(momentvalues[1][0],60),'M_W_exp_abs_over2_8log2_minus4':fmt(momentvalues[1][1],60),'absolute_45_60_error':fmt(momenterr,15),'scope':'ordinary highprecision integrals, not interval certification'}
pointchecks=[]
for x in [F(0),F(1,4),F(1,2),F(3,4),F(1),F(2),F(4),F(8)]:
 value=phi(mm(x));E=max(F(0),x-F(1,2))
 if x<=F(1,2):ck(mp.mpf('.25')<=value<=1,'actual_phi_inside_lower_quarter45',{'x':str(x)})
 else:ck(value>=mp.exp(-2*mm(E))/8,'actual_phi_outside_depth_lower_bound45',{'x':str(x)})
 pointchecks.append({'x':str(x),'E':str(E),'phi':fmt(value),'outside_lower_e_minus_2E_over8':fmt(mp.exp(-2*mm(E))/8) if x>F(1,2) else None})
VECTORS=[('inside_ties_n1',[F(1,2)]),('mixed_n4',[F(0),F(1,2),F(3,4),F(-2)]),('sparse_n16',[F(0)]*14+[F(1),F(-4)]),('dense_boundary_n16',[F(3,4),F(-3,4)]*8),('sparse_n64',[F(0)]*63+[F(8)]),('diffuse_n64',[F(1),F(-1)]*32)]
dilation=[];height=[]
for name,vs in VECTORS:
 n=len(vs);m=sum(abs(v)>F(1,2) for v in vs);EL=sum(max(F(0),abs(v)-F(1,2)) for v in vs)
 for r in [F(1,2),F(3,4),F(1)]:
  Eb=sum(max(F(0),r*abs(v)-F(1,2)) for v in vs)
  ck(Eb>=r*EL-m*(1-r)/2,'exact_coordinate_depth_dilation_bound',{'profile':name,'L_over_b':str(r)})
  for K in sorted(set([m,min(n,m+2)])):
   ck(Eb>=EL/2-F(K,4),'exact_b_le_2L_depth_transfer',{'profile':name,'K':K,'L_over_b':str(r)})
   dilation.append({'profile':name,'n':n,'outside_m':m,'K':K,'L_over_b':str(r),'E_L':str(EL),'E_b':str(Eb),'coarse_depth_lower':str(EL/2-F(K,4))})
 for s in SVALUES:
  if not s:
   P=math.prod(int(abs(v)<=F(1,2)) for v in vs)
   ck(P==int(m==0),'s_zero_height_separate_hard_support',{'profile':name});height.append({'profile':name,'s':'0','outside_m':m,'actual_P':str(P),'positive_s_bound_applied':False});continue
  logP=sum(mp.log((1-mm(s))*int(abs(v)<=F(1,2))+mm(s)*phi(mm(v))) for v in vs)
  for K in sorted(set([m,min(n,m+2)])):
   exactpref=(1-3*s/4)**n*(s/8)**K
   sharperpref=(1-3*s/4)**(n-m)*(s/8)**m
   ck(sharperpref>=exactpref>0,'exact_rational_height_prefactor_weakening',{'profile':name,'s':str(s),'K':K})
   loglower=mp.log(mm(exactpref))-2*mm(EL)
   ck(logP+mp.mpf('1e-33')>=loglower,'actual_tensor_height_depth_lower_bound_log_checked45',{'profile':name,'s':str(s),'K':K})
   height.append({'profile':name,'n':n,'s':str(s),'outside_m':m,'K':K,'E_L':str(EL),'log_actual_P':fmt(logP),'log_height_lower':fmt(loglower),'positive_s_bound_applied':True})
# c_nk is the exact common-soft binomial coefficient maximum. Dyadic depth
# levels D=2M log2 make the exponential threshold decision rational.
coefficient_cases=[];thresholds=[]
for n in [1,4,16,64,256]:
 for K in sorted(set([0,min(1,n),min(4,n),min(8,n)])):
  coeff=[]
  for k in range(K+1):
   c=F(1) if k in [0,n] else F(math.comb(n,k))*(F(k,n)**k)*(1-F(k,n))**(n-k)
   coeff.append(c)
   for s in [F(0),F(1,64),F(1,4),F(1)]:
    raw=F(math.comb(n,k))*(s**k)*((1-s)**(n-k))
    ck(raw<=c,'exact_common_soft_coefficient_maximum_on_sample_softness',{'n':n,'k':k,'s':str(s)})
  weighted=sum(c*2**k for k,c in enumerate(coeff));Arat=F(1+n);epsilon=F(1,32);M=0
  while Arat*weighted/F(2)**M>epsilon:M+=1
  tail=Arat*weighted/F(2)**M
  ck(tail<=epsilon and (M==0 or 2*tail>epsilon),'exact_dyadic_depth_threshold_minimal_integer_M',{'n':n,'K':K,'M':M})
  with mp.workdps(60):
   An=1+n*mp.log(2);ck(An<mm(Arat),'actual_An_b_over_a_le2_rational_upper_ordinary_mp',{'n':n})
   for k in range(K+1):ck(momentvalues[1][0]**k<=2**k,'actual_Qk_product_depth_moment_le_two_power_k_ordinary_mp',{'n':n,'k':k})
   depth=2*M*mp.log(2)
  coefficient_cases.append({'n':n,'K':K,'c_nk':[str(c) for c in coeff],'sum_c_nk_two_power_k':str(weighted)})
  thresholds.append({'n':n,'K':K,'epsilon':str(epsilon),'An_rational_upper_1_plus_n':str(Arat),'minimal_M':M,'D_symbolic':'2*'+str(M)+'*log(2)','D_60digit_display':fmt(depth,60),'rational_certified_tail':str(tail)})
# Fixed actual product-position moments: only two small common-scale profiles.
product_profiles=[]
for name,ds in [('aligned_n4',[F(0)]*4),('mixed_position_n4',[F(0),F(1,4),F(1,2),F(2)])]:
 ab=[]
 for d in ds:
  A,B,AQ,BQ,hard=base[F(1),d];s=F(1,4);ab.append(((1-mm(s))*mm(hard)+mm(s)*A,mm(s)*B))
 coeff=[mp.mpf(1)]
 for a,b in ab:
  new=[mp.mpf(0)]*(len(coeff)+1)
  for k,c in enumerate(coeff):new[k]+=c*(a-b);new[k+1]+=c*b
  coeff=new
 total=math.prod(a for a,b in ab);ck(abs(sum(coeff)-total)<mp.mpf('1e-34')*total,'actual_fixed_product_outside_count_PGF45',{'profile':name})
 product_profiles.append({'name':name,'common_R':'1','common_s':'1/4','offsets':list(map(str,ds)),'capture_mass':fmt(total),'outside_count_coefficients_unnormalized':list(map(fmt,coeff))})
for ab in [[(F(1,2),F(1,4)),(F(3,4),F(1,4)),(F(1),F(0)),(F(1,3),F(1,3))],[(F(0),F(0)),(F(1),F(1,2))]]:
 coeff=[F(1)]
 for a,b in ab:
  new=[F(0)]*(len(coeff)+1)
  for k,c in enumerate(coeff):new[k]+=c*(a-b);new[k+1]+=c*b
  coeff=new
 direct=[F(0)]*(len(ab)+1)
 for bits in itertools.product([0,1],repeat=len(ab)):direct[sum(bits)]+=math.prod(ab[i][1] if bit else ab[i][0]-ab[i][1] for i,bit in enumerate(bits))
 ck(coeff==direct and sum(coeff)==math.prod(a for a,b in ab),'exact_rational_outside_count_tensor_identity',{'n':len(ab)})
# Final combined height gate: exact scalar arithmetic, conditional on the
# author's analytic endpoint/depth lemmas, not a full original traffic proof.
def rational_summary(q):
 a=abs(q.numerator).to_bytes(max(1,(abs(q.numerator).bit_length()+7)//8),'big');b=q.denominator.to_bytes(max(1,(q.denominator.bit_length()+7)//8),'big')
 out={'exact_binary_rational_sha256':hashlib.sha256(bytes([q.numerator<0])+len(a).to_bytes(8,'big')+a+b).hexdigest(),'numerator_bits':q.numerator.bit_length(),'denominator_bits':q.denominator.bit_length(),'log10_display45':fmt(mp.log10(mm(q))) if q>0 else None}
 if q.numerator.bit_length()+q.denominator.bit_length()<=1000:out['exact_fraction']=str(q)
 return out
def common_c(n,k):return F(1) if k in [0,n] else F(math.comb(n,k))*F(k,n)**k*(1-F(k,n))**(n-k)
combined=[];eta=F(1,128)
for n in [16,64,256,1024]:
 for K in sorted(set([0,1,4,(n-1).bit_length(),min(n,32)])):
  An=F(n+1);Smax=min(F(1),F(28*(K+7),5*n));s0=min(F(1,2*n),3*eta/(16*An*n));CK=sum((common_c(n,k)*F(8,5)**k for k in range(1,K+1)),F(0));M=0
  while F(16,3)*An*CK/F(2)**M>eta:M+=1
  endpoint_price=F(16,3)*An*n*s0;tail_price=F(16,3)*An*CK/F(2)**M
  ck(endpoint_price<=eta and tail_price<=eta and endpoint_price+tail_price<=2*eta,'exact_combined_endpoint_tail_one_eta_each',{'n':n,'K':K})
  ck(M==0 or 2*tail_price>eta,'exact_combined_minimal_nonnegative_M',{'n':n,'K':K,'M':M})
  if K==0:ck(CK==0 and M==0 and tail_price==0,'K_zero_separate_no_depth_tail',{'n':n})
  empty=Smax<=s0
  row={'n':n,'K':K,'eta':str(eta),'An_rational_upper':str(An),'Smax':str(Smax),'s0':str(s0),'core_empty_Smax_le_s0':empty,'C_K':rational_summary(CK),'minimal_M':M,'D_symbolic':'2*'+str(M)+'*log(2)','small_endpoint_price_bound':str(endpoint_price),'depth_tail_price_bound':rational_summary(tail_price),'union_price_bound':rational_summary(endpoint_price+tail_price)}
  if not empty:
   pref=(1-3*Smax/4)**n*(s0/8)**K;taucert=pref*F(2)**(-8*M)*F(3)**(-K);smallhard=1-n*s0;gate=min(smallhard,taucert)
   ck(taucert>0 and smallhard>=F(1,2),'exact_combined_positive_gate_and_small_s_hard_height',{'n':n,'K':K})
   ck((1-s0)**n>=smallhard,'exact_small_s_hard_product_Bernoulli_height',{'n':n,'K':K})
   for sval in [s0,(s0+Smax)/2,Smax]:
    ck((1-3*sval/4)**n*(sval/8)**K>=pref,'exact_combined_core_height_prefactor_monotonic_s_bounds',{'n':n,'K':K,'s':str(sval)})
   logstar=mp.log(mm(pref))-8*M*mp.log(2)-K
   ck(mp.log(mm(taucert))<=logstar+mp.mpf('1e-32'),'combined_tau_cert_le_analytic_tau_star_ordinary_mp',{'n':n,'K':K})
   for tau in [F(0),gate/2,gate,2*gate]:
    sufficient=tau<gate
    ck(sufficient==(tau<smallhard and tau<taucert),'exact_combined_strict_height_gate_and_complement',{'n':n,'K':K})
    if tau==gate:ck(not sufficient,'combined_height_gate_equality_is_excluded',{'n':n,'K':K})
   row.update({'tau_cert':rational_summary(taucert),'one_minus_n_s0':str(smallhard),'sufficient_tau_upper_strict':rational_summary(gate),'tau_star_log10_display45':fmt(logstar/mp.log(10))})
  else:row['tau_cert']=None
  combined.append(row)
ck(momentvalues[1][0]<=mp.mpf(8)/5 and momentvalues[1][1]<mp.mpf(8)/5,'actual_phi_and_W_depth_moments_below_eight_fifths_ordinary_mp',{})
out={'status':'PASS' if not FAIL else 'FAIL','scope':'Bounded actual1D phi depth/capture moments and fixed tensor height checks, ordinary45/60digit evidence, not interval certification. Exact Fraction checks cover dilation, common-soft coefficients and dyadic tail thresholds conditional on the analytic moment bound. No selected variable-scale payment, full-history or general dimension-order claim.','moment_formula':'E_phi exp(E(v)/2)=inside_phi_mass+2 int_0^1 t²(1-exp(-1/t))/(1-t/2)dt; inside_phi_mass=1-2(1/3-E4(1)). It is compared to a direct segmented x integral. E_W exp(|W|/2)=8log2-4<2.','depth_geometry':'E(v)=(|v|-1/2)+. For L/b=r in[1/2,1], m outside coordinates: E_b>=r E_L-m(1-r)/2>=E_L/2-K/4 ifm<=K. All dilation decisions are exact rational.','height':'For s>0,m<=K, actualP>= (1-3s/4)^n(s/8)^K exp(-2E_L), using insidephi>=1/4,outsidephi>=exp(-2E)/8. Actual tensor product is checked in log space; s0 is a separate hard-support case.','tail_threshold':'Conditional on analytic Qk depth moment<=2^k, envelope tail<=An sum_(k<=K)c_nk2^k exp(-D/2). For b/a<=2,An<=1+n. D=2Mlog2 gives exact rational upper(1+n)sum c2^k/2^M; minimal integer M is certified without a floating exponential payment decision.','combined_gate_scope':'Conditional scalar gate arithmetic withAn<=n+1,eta1/128,Smax=min(1,28(K+7)/(5n)),s0=min(1/(2n),3eta/(16An n)),CK=sum_(k1..K)c_nk(8/5)^k. Small-s endpoint and depthtail budgets each<=eta. M minimal with(16/3)An CK2^-M<=eta,D=2Mlog2. Remaining core height lower tauStar=pref*2^-8M*exp(-K),pref=(1-3Smax/4)^n(s0/8)^K; rational tauCert=pref2^-8M3^-K<=tauStar sincee<3. tau<min(1-ns0,tauCert) is strict. Empty Smax<=s0 core needs no heightgate. This verifies arithmetic and sampled actual kernel inputs, not the author analytic lemmas or complete original selected-scale payment.','combined_height_gate_cases':combined,'shrunk_capture_table':'Parent pivot shrank the initial90-entry capture menu to6 geometries x3softness=18 entries. Old large table is not retained.','check_counts':COUNTS,'failures':FAIL,'stages':[{'name':'initial_actual_phi_moment','moment':momentrecord,'pointwise_phi_checks':pointchecks,'capture_geometry_integrals':geometry_records,'capture_mixture_cases':capture_records},{'name':'boundary_dilation_and_height','dilation':dilation,'height':height},{'name':'expanded_exact_coefficients_and_dyadic_thresholds','coefficients':coefficient_cases,'thresholds':thresholds}],'fixed_product_position_profiles':product_profiles}
basefile=Path(__file__);basefile.with_suffix('.json').write_text(json.dumps(out,sort_keys=True,indent=2)+'\n');lines=['# R310 actual depth geometry diagnostics','',out['scope'],'',out['moment_formula'],'','Actual phi depth moment: '+momentrecord['M_phi_exp_depth_over2']+'. W-moment upper: '+momentrecord['M_W_exp_abs_over2_8log2_minus4']+'.','',out['depth_geometry'],'',out['height'],'',out['tail_threshold'],'','The capture table is deliberately reduced to18 mixtures. Fixed product profiles use common R=1,s=1/4 and dimension4; their outside-count PGF is product[(a_i-b_i)+b_i z].','','|n|K|minimal M|D=2M log2|','|---:|---:|---:|---:|']
for t in thresholds:lines.append(f"|{t['n']}|{t['K']}|{t['minimal_M']}|{float(t['D_60digit_display']):.8g}|")
lines+=['','Combined height gate diagnostics (eta=1/128; rational thresholds summarized by exact binary hash):','','|n|K|minimal M|log10 tauCert|','|---:|---:|---:|---:|']
for row in combined:lines.append(f"|{row['n']}|{row['K']}|{row['minimal_M']}|{row['tau_cert']['log10_display45'] if row['tau_cert'] else 'empty core'}|")
lines+=['',out['combined_gate_scope'],'','All threshold and dilation decisions are exact Fraction. Actual special-function integrals and tensor height inequalities are ordinary highprecision checks. These finite results do not certify the original selected-scale/source payment.']
basefile.with_suffix('.md').write_text('\n'.join(lines)+'\n');print(json.dumps({'status':out['status'],'check_counts':COUNTS,'failures':FAIL,'actual_depth_moment':momentrecord,'capture_entries':len(capture_records),'dilation_cases':len(dilation),'height_cases':len(height),'threshold_cases':len(thresholds),'combined_height_gate_cases':len(combined)},indent=2));assert not FAIL,FAIL
