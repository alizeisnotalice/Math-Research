#!/usr/bin/env python3
"""R310 feasibility of the original R309 cutoffs against weakened heights."""
import json,math,hashlib
from pathlib import Path
from fractions import Fraction as F
from decimal import Decimal,localcontext
COUNTS={};FAIL=[]
def ck(ok,label,data):
 COUNTS[label]=COUNTS.get(label,0)+1
 if not ok:FAIL.append({'test':label,'data':data})
SOURCE_PATH="/tmp/r309_cutoff_probe.json"
SOURCE_SHA256='e1851971919ff9ad4e02e42be9a5272f8ce1ba4343fa146123411871b071f9ee'
ORIGINAL_RECORDS=[{'stage': 'parameter_pressure', 'n': 256, 'qH': '1/65536', 'K': 222, 'high_softness_threshold': '1603/320', 'nonempty': False}, {'stage': 'parameter_pressure', 'n': 256, 'qH': '1', 'K': 111, 'high_softness_threshold': '413/160', 'nonempty': False}, {'stage': 'parameter_pressure', 'n': 256, 'qH': '65536', 'K': 12, 'high_softness_threshold': '133/320', 'nonempty': True}, {'stage': 'expanded', 'n': 1024, 'qH': '1/1048576', 'K': 251, 'high_softness_threshold': '903/640', 'nonempty': False}, {'stage': 'expanded', 'n': 1024, 'qH': '1', 'K': 122, 'high_softness_threshold': '903/1280', 'nonempty': True}, {'stage': 'expanded', 'n': 1024, 'qH': '1048576', 'K': 3, 'high_softness_threshold': '7/128', 'nonempty': True}]
ck(len(ORIGINAL_RECORDS)==6,'embedded_original_R309_cutoff_snapshot_six_records',{})
input_note='Self-contained exact six-record snapshot embedded from the original source JSON; no runtime read of old files.'

def exact(q):
 num=abs(q.numerator).to_bytes(max(1,(abs(q.numerator).bit_length()+7)//8),'big');den=q.denominator.to_bytes(max(1,(q.denominator.bit_length()+7)//8),'big');canonical=bytes([q.numerator<0])+len(num).to_bytes(8,'big')+num+den
 with localcontext() as ctx:
  ctx.prec=60;log10=str((Decimal(q.numerator)/Decimal(q.denominator)).log10()) if q>0 else None
 result={'exact_binary_rational_sha256':hashlib.sha256(canonical).hexdigest(),'numerator_bits':q.numerator.bit_length(),'denominator_bits':q.denominator.bit_length(),'log10_diagnostic60':log10}
 if q.numerator.bit_length()+q.denominator.bit_length()<1000:result['exact_fraction']=str(q)
 return result
def CK_exact(n,K):
 if not K:return F(0)
 # One common denominator avoids repeated huge rational additions.
 numerator=sum(math.comb(n,k)*k**k*(n-k)**(n-k)*8**k*5**(K-k) for k in range(1,K+1))
 return F(numerator,n**n*5**K)
eta=F(1,128);results=[]
for original in ORIGINAL_RECORDS:
 n=original['n'];qH=F(original['qH']);K=original['K'];gamma=1+F(1,n);An=F(n+1)
 ck(n%4==0 and 0<=K<=n,'original_dimension_and_cutoff_retained',{'n':n,'K':K})
 ck(qH in [F(1,n*n),F(1),F(n*n)],'original_qH_menu_retained',{'n':n,'qH':str(qH)})
 Smax=min(F(1),F(28*(K+7),5*n));s0=min(F(1,2*n),3*eta/(16*An*n));C=CK_exact(n,K);M=0
 while F(16,3)*An*C/F(2)**M>eta:M+=1
 endpoint=F(16,3)*An*n*s0;tail=F(16,3)*An*C/F(2)**M
 ck(endpoint<=eta and tail<=eta,'exact_endpoint_tail_budget_with_original_K',{'n':n,'K':K})
 ck(M==0 or 2*tail>eta,'exact_original_K_minimal_M',{'n':n,'K':K})
 empty_core=Smax<=s0
 if empty_core:
  results.append({'n':n,'qH':str(qH),'K':K,'core_empty':True,'height_gate_needed':False});continue
 tau_cert=(1-3*Smax/4)**n*(s0/8)**K*F(2)**(-8*M)*F(3)**(-K);hardgate=1-n*s0;gate=min(tau_cert,hardgate);psi=3-F(2)/(3*gamma**n)
 ck(0<psi<=3 and tau_cert>0 and gate>0,'exact_positive_height_parameters_and_safe_psi',{'n':n,'K':K})
 for v0 in [F(1),F(2)**(-n//2)]:
  tmin=F(1) if v0==1 else F(1,2)
  kappa=qH*v0/(8*psi);safe_kappa=qH*v0/24
  def height(t,kap):return kap*min(t**(n//2),gamma**(n//2)*t**(3*n//4))
  floor=height(tmin,kappa);safe_floor=height(tmin,safe_kappa)
  ck(safe_floor<=floor,'exact_safe_psi_three_gives_lower_height_floor',{'n':n,'K':K})
  for t in [tmin,(tmin+2)/2,F(2)]:ck(height(t,kappa)>=floor,'exact_height_monotone_endpoint_minimum_samples',{'n':n,'K':K,'t':str(t)})
  gate_empty=gate<=floor;safe_empty=gate<=safe_floor
  ck(not safe_empty or gate_empty,'safe_psi_empty_implication',{'n':n,'K':K})
  # At exact equality, strict tau<gate still makes the gate impossible.
  ck((floor<gate)==(not gate_empty),'strict_height_gate_feasibility_necessary_condition',{'n':n,'K':K})
  results.append({'n':n,'qH':str(qH),'K_original_unmodified':K,'known_lambda_d_qH_over6':str(qH/6),'known_lambda_d_over_sqrt_n':str(qH/(6*math.isqrt(n))),'known_beta_base_exceeds_sqrt_n':qH/6>math.isqrt(n),'R309_high_softness_threshold':original['high_softness_threshold'],'R309_high_softness_nonempty':original['nonempty'],'v0':str(v0),'v0_convention':'unit' if v0==1 else '2^(-n/2)','legal_t_min':str(tmin),'legal_t_max':'2','Smax':str(Smax),'s0':str(s0),'core_empty':False,'minimal_M':M,'D_symbolic':'2*'+str(M)+'*log(2)','C_K':exact(C),'tau_cert':exact(tau_cert),'strict_gate_min_hard_tau_cert':exact(gate),'psi_actual':exact(psi),'kappa_actual':exact(kappa),'tau_at_legal_tmin_actual_psi':exact(floor),'tau_at_legal_tmin_safe_psi3':exact(safe_floor),'tau_cert_less_equal_height_min':tau_cert<=floor,'height_gate_empty_for_weakened_height_version':gate_empty,'safe_psi3_already_proves_height_gate_empty':safe_empty,'height_gate_status':'EMPTY for this weakened two-height version' if gate_empty else 'not excluded by these weakened height lower bounds; no actual feasibility or c_j claim','log10_tau_cert_over_height_min':exact(tau_cert/floor)['log10_diagnostic60']})
ck(all(r.get('height_gate_empty_for_weakened_height_version',True) or r['known_beta_base_exceeds_sqrt_n'] for r in results),'every_nonexcluded_probe_already_has_large_known_beta_base',{})
out={'status':'PASS' if not FAIL else 'FAIL','scope':'Necessary height-gate feasibility diagnostic only for the stated weakened two-height formula. Original R309 n,qH,K are kept exactly. Empty here does NOT imply the actual finer c_j height gate is empty, because missing c_j/aspect conditions may produce a different stronger height expression. A nonempty necessary window is not a realized original selector/source construction. No full-history or general dimension-order claim.','input_provenance':{'path':SOURCE_PATH,'sha256_at_snapshot':SOURCE_SHA256,'note':input_note,'embedded_original_records':ORIGINAL_RECORDS},'formula':'psi=3-2/(3 gamma^n),kappa=qH v0/(8psi),tau(t)=kappa min(t^(n/2),gamma^(n/2)t^(3n/4)); both terms increase, so minimum at legal tmin. v0=1 requires tmin1, v0=2^(-n/2) uses tmin1/2. Gamma=1+1/n,all n multiples4,so every comparison is exact Fraction. Safe psi3 lowers kappa and gives an even smaller floor.','known_main_price':'qH=q_minus H, H=8d,q_minus=3lambda/4 imply lambda d=qH/6. Thus prescribed qH=n² cases already have a known beta main scale n²/6. The only nonexcluded weakened gate in this table has lambda d/sqrt n=16384/3, so it is not overall root-budget improvement evidence.','gate_formula':'eta1/128,An=n+1,Smax=min(1,28(K+7)/(5n)),s0=min(1/(2n),3eta/(16An n));M minimal with(16/3)An CK2^-M<=eta,CK=sum_(1..K)c_nk(8/5)^k. tauCert=(1-3Smax/4)^n(s0/8)^K2^-8M3^-K. Gate strict tau<min(1-ns0,tauCert).','serialization':'Rational comparisons are exact. Large fractions stored as canonical binary SHA256(sign byte,8byte numerator-length,absolute numerator bytes,denominator bytes); log10 Decimal60 is diagnostic only. Script embeds the original six-record cutoff snapshot and provenance hash; no old file is read or imported at runtime.','check_counts':COUNTS,'failures':FAIL,'records':results}
path=Path(__file__);path.with_suffix('.json').write_text(json.dumps(out,sort_keys=True,indent=2)+'\n');lines=['# R310 original-cutoff height feasibility','',out['scope'],'',out['formula'],'',out['gate_formula'],'','|n|qH|original K|v0|legal tmin|log10 tauCert|log10 min height|weakened gate|','|---:|---:|---:|---|---:|---:|---:|---|']
for r in results:
 if r['core_empty']:lines.append(f"|{r['n']}|{r['qH']}|{r['K']}|—|—|—|—|empty core; no gate needed|")
 else:lines.append(f"|{r['n']}|{r['qH']}|{r['K_original_unmodified']}|{r['v0_convention']}|{r['legal_t_min']}|{float(r['tau_cert']['log10_diagnostic60']):.6g}|{float(r['tau_at_legal_tmin_actual_psi']['log10_diagnostic60']):.6g}|{'EMPTY' if r['height_gate_empty_for_weakened_height_version'] else 'not excluded'}|")
empty=sum(r.get('height_gate_empty_for_weakened_height_version',False) for r in results);lines+=['',f'{empty} of{len(results)} tested weakened height gates are empty. This materially limits the use of the small threshold table: a sufficient threshold is not automatically reachable. The remaining case(s) only survive this necessary comparison.','', 'These judgments use the original cutoffs, without choosing a more favorable K. The c_j-refined original gate remains unclassified by this diagnostic.','',out['known_main_price']]
path.with_suffix('.md').write_text('\n'.join(lines)+'\n');print(json.dumps({'status':out['status'],'check_counts':COUNTS,'failures':FAIL,'records':len(results),'empty_weakened_height_gates':empty,'summary':[{'n':r['n'],'qH':r['qH'],'K':r.get('K_original_unmodified'),'v0':r.get('v0_convention'),'tmin':r.get('legal_t_min'),'logtau':r.get('tau_cert',{}).get('log10_diagnostic60'),'logfloor':r.get('tau_at_legal_tmin_actual_psi',{}).get('log10_diagnostic60'),'empty':r.get('height_gate_empty_for_weakened_height_version')} for r in results]},indent=2));assert not FAIL,FAIL
