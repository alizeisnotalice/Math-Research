# R310 independent preauthor audit

Independent screen: PASS for the proposed deep-exterior payment, tiny-softness endpoint payment and their stated conditional height implications. This independent derivation was saved BEFORE reading any new R310 author proof. Own file only; no repository/Git/PDF work.

## 1. True coordinate-depth exponential moment and actual pair price

Let e(u)=(|u|-1/2)_+, E_L(v)=sum_i e(v_i/L), and E_b use the physical upper scale b. For X=H+W with H density h=1_[-1/2,1/2] and W density w, e(X)<=|W|. The original w is normalized and

E exp(|W|/2)=2 integral_0^1 v/(1-v/2)dv=8 ln2-4<8/5<2.

The last strict bound follows from the already exact positive Taylor certificate ln2<7/10. Thus a k-soft-coordinate tensor has exponential total-depth moment <=(8/5)^k (or the original weaker 2^k). Averaging normalized coordinate subsets introduces NO extra binomial multiplicity. At k=0 the strict E_b>D tail is identically zero for D>=0 because L<=b and its hard support lies in Q_b.

Since E_b(Lu)<=E_1(u) for L<=b, each fixed-scale component tail is <=e^(-D/2)(8/5)^k. Apply the ORIGINAL positive ray-decreasing scale envelope Q_k,b+n integral_a^b Q_k,L dL/L BEFORE extending actual receiver selectors. Its total tail is <=A_n e^(-D/2)(8/5)^k, A_n=1+n ln(b/a). Actual common b_nk(s(x))<=c_nk<=1, so the degree<=K tail uses C_K=sum_{k=1}^K c_nk(8/5)^k. The original candidate with sum_{k=0}^K c_nk 2^k is a valid weaker version, bounded by 2^(K+1)-1.

For any positive suballocation of the original oriented pair fee with combined M<=1, split ONLY its degree<=K capturing endpoint by E_b(w-y)>D. The full original bad U, missed capture, J and every prefix/history gate stay fixed. Integrating bad mass <=J and the layer identity shows this component <=its qualified capturing traffic T_V. On original accepted receivers FIRST is NOT transferred to components: use sigma<=hard capture and the SAME-R nu cap first, giving <=4lambda integral beta(dy) integral_E U_lo 1_depth dx. Only then positively extend receiver space and apply the scale/tail envelope. Therefore

R_deep(D)<=(16/3)A_n C_K e^(-D/2) W_beta.

This is source price for an actual positive low-degree CAPTURING component, not for full low-p high degree or the whole operator. For price eta W_beta choose D=2 ln_+[(16/3)A_n C_K/eta], eta>0, D>=0. When C_K=0 define D=0 and the tail is exactly zero rather than taking an undefined logarithm. Root choice eta=sqrt(A_n) pays ONLY this new component. Lambda and the original residual incidence coefficient must multiply this source fee once; source and any alternative estimates of the SAME component cannot be added as separate payments.

## 2. Actual full-height lower bound and depth conversion

Inside a hard soft-coordinate interval, f_s>=1-3s/4. For exterior coordinate depth d>=0, the TRUE phi satisfies

phi(1/2+d)=integral_0^1 v e^(-d/v)(1-e^(-1/v))dv >=(1/8)e^(-2d),

by restricting v to [1/2,1]. If m exterior coordinates occur on a nonzero degree<=K component then m<=K. For s>0, the ORIGINAL FULL kernel obeys

P_s,L L^n >=(1-3s/4)^(n-m)(s/8)^m e^(-2E_L)
          >=(1-3s/4)^n(s/8)^K e^(-2E_L).

The geometric identity gives E_b>= (L/b)E_L-m(1-L/b)/2 >=E_L/2-K/4 because 1/2<=L/b<=1. Hence original full-height upper tau STRICTLY below (1-3s/4)^n(s/8)^K exp(-4D-K) forces E_b>D. An equality tau=threshold cannot be silently assigned to the strict depth tail. The more precise actual-m/actual-L version follows directly from the first inequalities; it cannot discard s^m or aspect costs. The s=0 cases are separate: no logarithm of zero is allowed; positive hard kernel is interior, and positive exterior low-degree response vanishes. K=0 has no positive-depth component.

## 3. Independent tiny-softness endpoint candidate

For 0<=s(x)<=s0<=1/n and k>=1, b_nk(s) is nondecreasing on [0,s0], since its derivative has sign k-ns>=0. Thus actual soft-positive capturing density is dominated by the original scale envelopes with FIXED weights b_nk(s0), whose sum is 1-(1-s0)^n<=n s0. SAME-R cap before receiver extension gives

R_soft-positive,S<=s0 <=(16/3)A_n[1-(1-s0)^n]W_beta <=(16/3)A_n n s0 W_beta.

No unweighted component FIRST or coordinate source copy is used. On actual original height tau<1-ns0, a hard-cube interior capture is impossible because FULL P L^n>=(1-s)^n>=1-ns0. Therefore the k=0 capturing density is zero on this ORIGINAL gate and the ENTIRE restricted capturing endpoint is paid by the displayed soft-positive bound. The complements tau>=1-ns0 and S>s0 remain. s0=0 yields zero response on this height gate; s0=1/n makes its nonnegative-height trigger empty.

This endpoint gate may cover BOTH R309 retained terms without source duplication: at low p their capturing densities U_hi+U_lo 1_low-softness<=U, and at middle p only U_lo 1_low-softness<=U. These p domains are disjoint at every original prefix; their union is dominated by one full capturing density. Thus a single eta W_beta endpoint fee covers their UNION. Depth then applies only to the low-degree term on the endpoint complement. At the R309 coefficient 128/5, each explicitly chosen eta W_beta source receipt is multiplied by (128/5)Lambda; it is not a new epsilon X error.

## 4. Combined height support implication

Let Smax=min(1,28(K+7)/(5n)), reflecting the actual low-degree/low-softness remainder. If Smax<s0, the intermediate s>s0 core is empty. Otherwise, on s>s0, E_b<=D and m<=K,

E_L<=2D+K/2,
P L^n >=tau_star=(1-3Smax/4)^n(s0/8)^K exp(-4D-K).

For s0>0,D>=0, original tau<min(1-ns0,tau_star) forces every surviving low-degree capture into tiny softness or strict deep depth. The boundary s=s0 belongs to tiny; E_b=D is shallow and is still excluded by STRICT tau<tau_star; equality in the height test remains in the complement. This is at most the already displayed two eta W_beta fees. If endpoint and depth have already been paid sequentially, this is a support description under their EXISTING budget, not two additional receipts. Low-p high degree is not covered by the m<=K argument and stays intact. tau_star may be extremely small; no coverage fraction or general root closure follows.

## Actual bounded diagnostics

Executed 2418 exact Fraction depth/scale conversion cases, 279 exact binomial small-softness monotonicity cases, and 5 ordinary 55-digit TRUE phi tail-lower checks. Also evaluated the true phi depth moment and original w moment at high precision, obtaining M_phi<=M_W<8/5; all checks PASS. Numerical values support but do not replace the analytic moment, lower-tail and source-price proofs above. Finite data do not realize the complete original low/e/m/history.

Remaining gap: shallow low-degree captured traffic outside the tiny-softness height gate, low-p high degree, the exact high-height/aspect complements, and all independent original source/outer/entry ledger obligations.

## Author comparison and bounded auxiliary review

Read the frozen depth proof `/tmp/r310_geometry.md`, endpoint note, main combined note and source-crossing auxiliary after saving the independent derivation above. PASS: the depth proof retains the rational R309 Gamma, exact full bad endpoint/J/M, k=0 zero tail, same-R cap order and actual aspect/softness height factors. The endpoint note pays the union before splitting the depth part on its complement. Main combined gives exactly

Lambda T <= Lambda[(4096/5)lambda d+(128/5)(eta+zeta)]W_beta
 + (128/5)Lambda[R1|Zc+R2|Zc,E_b<=D].

The combined tau_cert is conservative: with D=2M ln2, exp(-4D)=2^(-8M), and 3^(-K)<=exp(-K). The combined height implication is a corollary of the EXISTING endpoint/depth payments, not a third receipt. Arbitrarily small tau_star, K=n, K=0, equality boundaries, and original outer costs remain visible.

The source-crossing auxiliary is also valid in its declared conditional scope. Endpoint-monotone coordinate inequalities give an interval of capture indices for each source point, so the exact chain crossing sum is 2nu(union)-nu(first)-nu(last). For affine positive-side cube paths, the distributional moving-face formula is legitimate for L1 sources; density slices, rather than zero face masses, control flux. Sourcewise variation bounds scalar total-mass variation from above, not conversely. Each directed flow cut has load <=J_left J_right/J<=J/4 under the stated original prefix product domination. Oriented physical and common-cube history disagreement are distinct. No original cross-row/scale cut-load certificate, endpoint-monotone routing, cap on virtual cubes, or payment of qualification variation is supplied; the text explicitly retains these gaps. This auxiliary does not enter the main new source payment.

The historical note's principal hard-band implication was directly compared to GENERAL_CURRENT_REDUCTION.md sections 1--2: G0=sup over the original hard octave and G0<=4lambda indeed gives every same-original-receiver octave hard cap. The note correctly distinguishes this additional provenance from a standalone selected-radius hypothesis, and does not transfer caps beyond b or to added receivers. Its historical selector-identity caveat is conservative; I do not independently certify every cited archive transcription in this round. No stronger future-softness cap or heavy-column elimination is used by the present proof.

Frozen author bindings at comparison:
- depth geometry: b8671435c95f75c41835afdb950a927018221ddffea1423f738e41c667a4aad3
- endpoint note: 6f29de1fa668b84d2b91c4d6dd4acd6b9f4e046e02bfdff85e3cc9b9b5932c73
- crossing auxiliary: 9fbfc56255ef4429184ede082930c42809fb6820c5f4531c66d9f3227a625305
- combined note (before final delivery docs): a754b32b3fd17b45f1bb7939f31d3e79a56450394343c2f62b45457cd0f2f6e1
- cap-history note: 24e6b88163562bc05666706fad1037f54ae328ee215529910bdf3cb34c5683c4

The inspected endpoint JSON reports 4354 exact scalar checks. Numeric JSON distinguishes exact Fraction decisions and ordinary high precision actual-phi evidence; it is not an interval proof or complete original-history realization. Final delivery text/hash binding remains pending.

## Final delivery comparison and parameter feasibility scope

Read R310 README, combined note, TeX source (without compilation), feasibility source/JSON/note and final numeric scope. PASS for the mathematical formulas and exact remaining allocation. The TeX now explicitly states 0<=alpha<=1, q_-=3lambda/4, the C_K>0 condition for its logarithmic D choice (K=0 uses D=0), and s<=Smax on R2. Its two-source-fee reentry and zero-new-epsilon-X statement agree with the author proofs.

The original-parameter diagnostic is an important limitation, not evidence of general closure. It preserves the six original R309 n/qH/K records, checks two v0/aspect menus for 12 configurations, and reports 11 EMPTY strict rational-certificate gates. Precisely, the computed gate is tau<min(1-ns0,tau_cert) using the weakened two-height expression and the legitimate t_min; it does not alone classify the larger analytic tau_star gate or the finer actual c_j height gate. Source constants are linked correctly: H=8d and q_-=3lambda/4 give lambda d=q_-H/6. The sole nonexcluded n=1024,q_-H=n^2,K=3,v0=2^(-512) case has lambda d/sqrt(n)=16384/3, so it cannot serve as an overall root-budget improvement example. Nonempty necessary aspect windows are not realized original selectors/history/source constructions.

The README distinguishes 771 finite numeric checks: 593 exact rational/integer and 178 ordinary high-precision checks; this split agrees with the inspected labeled check counts. The exact exponential moment interval in the geometry appendix is a genuine rational scalar certificate, while the actual phi quadratures remain ordinary high precision. The parent reports fresh separate-process reruns of geometry 668, crossing 270, endpoint 4354, and numeric 771, with endpoint/numeric JSON byte equality. I inspected their script/output scope rather than repeating those already passed runs. The independent calculations executed by this auditor are recorded above. The feasibility author reports 104 exact checks and fresh identical runs; final parent rerun/status is recorded separately by the parent.

Final residual and gap remain exactly R1|Zc plus R2|Zc,E_b<=D, including original low-p high degree and shallow larger-height low-degree capture against full bad rows. The chain routing and qualification-variation fees, global source/outer ledger, original entry connector and all other prior unpaid slots are unchanged. No general root certificate, root coverage fraction or full theorem closure is asserted.

### Final byte bindings (supersede earlier intermediate bindings)
- /tmp/r310_geometry.md: b8671435c95f75c41835afdb950a927018221ddffea1423f738e41c667a4aad3
- /tmp/r310_endpoint.md: 6f29de1fa668b84d2b91c4d6dd4acd6b9f4e046e02bfdff85e3cc9b9b5932c73
- /tmp/r310_boundary.md: 9fbfc56255ef4429184ede082930c42809fb6820c5f4531c66d9f3227a625305
- /tmp/r310_caps_history.md: 24e6b88163562bc05666706fad1037f54ae328ee215529910bdf3cb34c5683c4
- /tmp/r310_combined.md: f700d8730c16441ec951b771650b71ab27bf0e14658aaf14f56c72cb6dad65bd
- /tmp/r310_README.md: 6ca3ca35093a83395ebc59d36866ddc904ca393ab3de9c1e36688a99e03c6456
- /Users/zhengzhihao/Desktop/T/output/centered_cube_round310_20261018_final_checkpoint/research.tex: 0f6d73858949860c68bd3727c0242aed1977aaffd443ff87d256b28f541c58cd
- /tmp/r310_endpoint.py: e635c97021658c98b7b6006c9d038b5521b670fdfd0d9682d1cbf1918fa568d6
- /tmp/r310_endpoint.json: f7bfc7d9ce72129aaf094dab36874a4f3e216df61a58f6fff02b6dbab9686cdd
- /tmp/r310_numeric.py: 00736c88ffc723d63eaa24facb0c463114624729ead580987e5bf9f88ea9687b
- /tmp/r310_numeric.json: 8e9cab399246d5f5d9b3e7ab0c2a8765d0928d7cce3cf2bf62ebb2e6701e3b1e
- /tmp/r310_numeric.md: bae0c7ce231984024f9c5daf1a2757dd1f8aabe24f9f170dead3563e4585ad4b
- /tmp/r310_feasibility.py: 4c47d127723b692970204b9c30b9b753ab14e92ae1daf5e0c8c2d7ac6ab0c896
- /tmp/r310_feasibility.json: 53ad353fe8d88b01d3fc80128401b2effc4aca2a5dd537b4fdd02c74062925e8
- /tmp/r310_feasibility.md: 6fc40a869d1bc9c050f804ae78741b570c4d0cba29fa4d95c876e742c4d1fd65

Final clarification receipt: re-read the final three delivery documents after the requested wording correction. Each now identifies the 11 empty cases as the pure rational tau_cert certificate gate, and explicitly withholds an inference for larger analytic tau_star or finer c_j gates. The parent confirms the final 104-check feasibility script was rerun in a separate process with byte-identical JSON. README records 104 actual checks. PASS; audit frozen with the above remaining gap, without any theorem-closure claim.
- Final clarified /tmp/r310_combined.md: f700d8730c16441ec951b771650b71ab27bf0e14658aaf14f56c72cb6dad65bd
- Final clarified /tmp/r310_README.md: 6ca3ca35093a83395ebc59d36866ddc904ca393ab3de9c1e36688a99e03c6456
- Final clarified /Users/zhengzhihao/Desktop/T/output/centered_cube_round310_20261018_final_checkpoint/research.tex: 0f6d73858949860c68bd3727c0242aed1977aaffd443ff87d256b28f541c58cd
