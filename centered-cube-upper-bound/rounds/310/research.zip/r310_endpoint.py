from fractions import Fraction as F
from math import comb
from pathlib import Path
import json
counts={}
def check(name,b):
 assert b,name
 counts[name]=counts.get(name,0)+1
for stage,ns in [('initial',[1,2,4]),('boundary',[8,16]),('expanded',[32,64,128])]:
 for n in ns:
  for m in [1,2,16,128]:
   s0=F(1,n*m)
   b0=[F(comb(n,k))*s0**k*(1-s0)**(n-k) for k in range(n+1)]
   check(stage+'_sum',sum(b0[1:])==1-(1-s0)**n)
   check(stage+'_mass',sum(b0[1:])<=n*s0)
   for factor in [F(0),F(1,4),F(1,2),F(1)]:
    s=s0*factor
    for k in range(1,n+1):
     b=F(comb(n,k))*s**k*(1-s)**(n-k)
     check(stage+'_coefficient',b<=b0[k])
    check(stage+'_hard_lower',(1-s)**n>=1-n*s0)
for n in [256,1024,4096]:
 for m in [2,16,128]:
  s0=F(1,n*m)
  check('expanded_large_mass',1-(1-s0)**n<=n*s0)
# Exact exp moment bound: e^(.7)>2 implies log2<.7 and 8log2-4<8/5.
check('taylor',sum(F(7,10)**j/F([1,1,2,6][j]) for j in range(4))>2)
# scalar cost substitution, arbitrary An represented exactly.
for An in [F(1),F(2),F(17),F(1000)]:
 for n in [1,16,1024]:
  for eta in [F(1,128),F(1),F(100)]:
   s0=min(F(1,2*n),3*eta/(16*An*n))
   check('source_price',F(16,3)*An*n*s0<=eta)
   check('nondegenerate_height',1-n*s0>=F(1,2))
obj={'status':'PASS','counts':counts,'total':sum(counts.values()),'scope':'Finite exact coefficient monotonicity and scalar threshold checks; analytic proof separate; no original histories simulated.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(obj,indent=2)+'\n');print(json.dumps(obj,indent=2))
