# R310 — source-paid total exterior depth of the actual low-degree capturing endpoint

## 1. Exact original target and proved new payment

Keep the complete R309 input and its remaining positive pair integral: original arbitrary positive L1 sources beta,nu; fixed restriction nu_*<=nu without recomputing full e_g,m, history, low-pe or any gate; actual common softness s(x), a<=L(x),R(x)<=b<=2a, q_-=3lambda/4<=q(x)<=lambda; original FIRST, SAME-R hard cap, aspect and outer data. Let

    U_y(x)=alpha(x,y)1_E(x)P_(s(x),L(x))(x-y)/q(x),
    U_y,lo=alpha1_E/q sum_(k=0)^K b_(n,k)(s(x))Q_(k,L(x))(x-y),
    b_(n,k)(s)=binom(n,k)s^k(1-s)^(n-k).

K is exactly the R308 degree cutoff (K_* in R309), not a new row/source choice. For the actual R309 ledger used in this round, Gamma is exactly the rational gate {n s(x)>=28(K+7)/5}; its complement is retained below. Thus Gamma^c implies s(x)<28(K+7)/(5n), and one may use Smax=min(1,28(K+7)/(5n)). If the threshold exceeds n this sufficient gate is empty, and if K=n no low-degree source reduction is inferred. The estimates below also hold with the sharper CDF gate when a separate ledger explicitly starts with that gate, but no such substitution is made in any exact residual identity here. All source/history qualifications remain in the binary qualified capture sigma_theta(x,y,z), and all old gain/near/quiet/rapid restrictions remain in M_theta, with 0<=M_theta<=1. The original J_y(t),A_theta,p_theta,chi_theta=1{J>=H,p<7/8} and denominator J are unchanged. The complete noncapturing factor is still U_y(u)[1-sigma_theta(u,y,z)]. Use the original scale measure

    ell_n(dt)=b^(-n)delta_b(dt)+n t^(-n-1)1_(a,b)dt,
    A_n=1+n log(b/a).

The exact R309 remainder is

    R_rem=R_lowp,hi + R_lo,Gamma^c,                    (1)

with the common theta average understood. The first term has p<eta_mid and the capturing density U_hi, with ALL actual softness values. In the second term the capturing density is

    V_y(w)=U_y,lo(w)1_(Gamma^c)(w),

on all original p<7/8 levels. In particular the bad endpoint in this term is NOT truncated to degree K or small s.

For an actual receiver row define the COMMON-b exterior depth

    E_b(w-y)=sum_(i=1)^n (|w_i-y_i|/b-1/2)_+ .        (2)

For D>=0 split ONLY V into V 1{E_b>D} and V 1{E_b<=D}, producing the exact positive split

    R_rem=R_lowp,hi+R_lo,shallow(D)+R_lo,deep(D).       (3)

No other residual is relabelled or dropped. Put

    c_(n,k)=max_(0<=s<=1) b_(n,k)(s),
    C_(n,K)=sum_(k=1)^K c_(n,k)(8/5)^k, C_(n,0)=0.

The new general geometric payment is

    R_lo,deep(D)
       <=(16/3) A_n C_(n,K) exp(-D/2) W_beta.          (4)

It holds on arbitrary original inputs, with the exact actual scales and all full bad-endpoint/history masks. No component FIRST, source density or nu<=beta is assumed. The soft components have their actual common-soft coefficients until positive domination, and their entire coefficient sum C_(n,K) is paid explicitly.

For any desired source coefficient zeta>0, if C_(n,K)>0 choose

    D_zeta=2 log_+[(16/3)A_n C_(n,K)/zeta].            (5)

Then R_lo,deep(D_zeta)<=zeta W_beta. If C_(n,K)=0 take D_zeta=0; the deep part is identically zero. In particular

    D_root=2 log_+[(16/3)sqrt(A_n) C_(n,K)]

pays this positive part by sqrt(A_n)W_beta. The threshold retains the whole degree cost; there is no claim that all remaining traffic has large depth or that K is always small.

## 2. A true-profile exterior-depth moment with no coordinate-set multiplicity

Use the original one-dimensional profile

    h=1_[-1/2,1/2],
    w(t)=integral_0^1 exp(-|t|/u)du,
    phi=h*w.

Both h and w have integral one. If H has density h and W has density w independently, X=H+W has density phi. Define e(v)=(|v|-1/2)_+. Since |H|<=1/2,

    e(H+W)<=|W|.

Consequently

    integral exp(e(v)/2)phi(v)dv
      <= E exp(|W|/2)
       =2 integral_0^1 u/(1-u/2)du
       =8 log2-4 <8/5.                               (6)

The last rational upper bound follows from log2<7/10, already proved by the positive Taylor lower sum exp(7/10)>12013/6000>2. Thus it uses the actual w and phi, not a modified exponential surrogate for the kernel.

Let E(v)=sum_i e(v_i). Each product term in Q_k has exactly k phi coordinates and n-k hard coordinates. The hard coordinates contribute zero to E, and their exponential moment equals one. By product integration, every such term has moment at most (8/5)^k. Q_k is the NORMALIZED AVERAGE over its coordinate sets, so averaging does not introduce binom(n,k) extra copies:

    integral exp(E(v)/2)Q_k(v)dv <=(8/5)^k.             (7)

The combinatorial coefficient remains correctly in b_(n,k), and later in c_(n,k); it has not been discarded.

## 3. The common-b event survives the actual scale selection

For each fixed L<=b and x=Lv,

    E_b(x)=sum_i (L|v_i|/b-1/2)_+ <=E(v).

Thus (7), after the true change of variables x=Lv, proves

    integral exp(E_b(x)/2)Q_(k,L)(x)dx <=(8/5)^k        (8)

uniformly for every physical L in [a,b]. This is the key reason for using the SAME b in the tail event. An actual moving-scale event E_(L(x))(x)>D cannot simply be substituted for it.

The full profile Q_k is ray-nonincreasing. Apply the previously established positive scale envelope to the FULL profile, before any tail restriction:

    Q_(k,L(x))(x)
       <=Q_(k,b)(x)+n integral_a^b Q_(k,L)(x)dL/L.      (9)

For completeness, along a fixed ray Q_k(x/L) is nondecreasing in L. The Stieltjes derivative of L^(-n)Q_k(x/L) has its negative part bounded by n L^(-n)Q_k(x/L)dL/L. Integrating from any L to b proves (9), including positive profile jumps at hard-coordinate endpoints. The truncated tail profile itself is NOT asserted to be ray-decreasing.

Now restrict the RIGHT side of (9) to the fixed event E_b(x)>D. Markov's inequality and (8) give, for k>=1,

    integral_{E_b(x)>D}
       [Q_(k,b)(x)+n integral_a^b Q_(k,L)(x)dL/L]dx
         <=A_n (8/5)^k exp(-D/2).                    (10)

For k=0 the same tail integral is exactly zero whenever D>=0: every Q_(0,L) is supported on Q_L, contained in Q_b where E_b=0. This accounts for the missing k=0 term in C_(n,K), not an omitted source cost.

Use b_(n,k)(s(x))<=c_(n,k) only after retaining its actual coefficient in V. Since alpha<=1 and q>=q_-, equations (9),(10) imply, for every source row y,

    integral V_y(w)1{E_b(w-y)>D}dw
       <=q_-^(-1) A_n C_(n,K) exp(-D/2).              (11)

The original Gamma^c, E and alpha have only been dropped in this positive upper estimate. The actual pair component was defined with them intact.

## 4. Actual hard cap first, then the row-source charge

Write the deep pair contribution at a fixed theta. Its defining integrand is

    chi_theta/J_y(t) integral_{R(w),R(u)<=t}
       V_y(w)1{E_b(w-y)>D}sigma_theta(w,y,z)
       U_y(u)[1-sigma_theta(u,y,z)]M_theta dwdu.

The entire bad prefix integral is bounded by J_y(t). Thus, without altering the original deep component, it is bounded above by its capturing prefix. Positive Tonelli and the exact identity ell_n([R(w),b])=R(w)^(-n) then give

    R_lo,deep,theta
      <=integral beta(dy)dw V_y(w)1{E_b(w-y)>D}
             R(w)^(-n) integral sigma_theta(w,y,z)nu_*(dz).

At this SAME original accepted receiver w, apply the original hard cap:

    integral sigma_theta(w,y,z)nu_*(dz)
       <=nu(Q_(R(w))(w))<=4lambda R(w)^n.

Only after using that cap do we drop the accepted set in the row envelope (11). Therefore

    R_lo,deep,theta
       <=4lambda integral beta(dy)dw V_y(w)1{E_b(w-y)>D}
       <=(4lambda/q_-) A_n C_(n,K)e^(-D/2)W_beta.

Since 4lambda/q_-=16/3, this proves (4). The common theta has total weight one, and the same threshold/constant works at every theta. Averaging costs one beta source price, not one per theta, source coordinate, degree or physical scale.

This is an explicit analytic row-source certificate for the new positive component: its per-row fee is the constant in (4), so the R308 signed-FIRST formalism could use C_beta equal to that constant and P=0. The substantive estimate is the true-profile depth moment and cap order above, not the fact that one can name such a certificate. No receiver-volume epsilon error is introduced.

## 5. Degree, scale and original outer costs remain explicit

Since c_(n,k)<=1,

    C_(n,K)<=sum_(k=1)^K(8/5)^k
             =(8/3)[(8/5)^K-1].                     (12)

Thus D_zeta=O(K+log_+(A_n/zeta)+1), with the explicit formula (5), rather than an unspecified price for choosing exterior coordinate sets. If the original R308 parameter conditions yield K=O(log n), this threshold is logarithmic for polynomial zeta. If K is large, its full cost remains in (5),(12); no unconditional logarithmic cutoff is presumed.

The original R309 entry was

    Lambda T<=(4096/5)Lambda lambda d W_beta
                           +(128/5)Lambda R_rem.

Substitute only the exact split (3) and the source payment (5):

    Lambda T <=Lambda[(4096/5)lambda d+(128/5)zeta]W_beta
       +(128/5)Lambda[R_lowp,hi+R_lo,shallow(D_zeta)]. (13)

Here d=kappa0 psi_inf/(q_-v0), kappa0=2K_orig/(ell M), and all original aspect, low-m and outer costs remain. The source charge is placed inside the original outer integral; it has not been normalized away. The choice zeta=sqrt(A_n) supplies a genuine new root beta payment. The alternative zeta=epsilon supplies epsilon W_beta at the larger threshold (5). No internal T absorption is needed for this step.

The term R_lowp,hi is completely untouched, so it is false that the entire residual is now shallow. The shallow low-degree term still retains original actual-softness restriction Gamma^c, complete bad endpoint, J, M, chi, qualification, radius atoms and true dx. Neither term is proved root-priced here.

## 6. Original low height can trigger this paid component, with all softness/aspect factors retained

This section links the actual height to a PAID position event; it does not assume that every remaining edge triggers that event. At a positive low-degree capturing point w,y let

    v_i=(w_i-y_i)/L(w),
    m=#{i:|v_i|>1/2}<=K,
    E_L(w-y)=sum_i (|v_i|-1/2)_+,
    eta=L(w)/b in [a/b,1].

The inequality m<=K is exact: every exterior hard coordinate forces a soft label, so if m>K the low-degree capturing density is zero.

For |v|=1/2+t with t>=0, the actual profile has

    phi(v)=integral_0^1 u(1-e^(-1/u))e^(-t/u)du
       >=(1/8)e^(-2t).                               (14)

Restrict u to [1/2,1], use u>=1/2, 1-e^(-1/u)>=1/2 and e^(-t/u)>=e^(-2t). Inside the hard interval phi>=1/4, as established in R309. Therefore for s=s(w)>0,

    L^n p_y(w)
      >=(1-3s/4)^(n-m)(s/8)^m exp(-2E_L(w-y)).        (15)

The original two point heights give, on the SAME qualified positive support,

    L^n p_y(w)<=tau(L/R),
    tau(t)=kappa0 min(t^(n/2),G t^(3n/4)),
    G=gamma^(n/2).                                    (16)

No scale orientation has been swapped, and both aspect factors remain. Put

    B(s,m)=(1-3s/4)^(n-m)(s/8)^m,
    E_forced=(1/2)log_+[B(s,m)/tau(L/R)].

Then (15),(16) imply E_L>=E_forced. The coordinatewise dilation inequality is

    E_b(w-y)>=eta E_L(w-y)-m(1-eta)/2.                (17)

For an exterior coordinate this follows from max(eta|v|-1/2,0)>=eta(|v|-1/2)-(1-eta)/2; interior coordinates contribute zero. In particular, if

    (eta/2)log_+[B(s,m)/tau(L/R)]-m(1-eta)/2>D,         (18)

the capturing point belongs to the already PAID event E_b>D. This is a concrete sufficient height-triggered geometric branch, not merely an energy definition.

A weaker bound displaying only K and b/a<=2 is

    E_b>= (1/4)log_+[
          (1-3s/4)^n(s/8)^K/tau(L/R)]-K/4.            (19)

For example, the strict condition

    tau(L/R)<(1-3s/4)^n(s/8)^K exp(-(4D+K))            (20)

also triggers the payment. Its potentially severe s^K and aspect costs are displayed, not discarded. As s tends to zero these conditions may fail: small actual softness alone does not force deep exterior mass.

When s=0 and m>0, the full kernel and low-degree density are zero, so no positive capture is being claimed. When s=0,m=0, use B(0,0)=1; actual p_y L^n=1, and (16) forces tau>=1. Thus no fictitious positive-depth payment follows at the hard interior. If K=0 all nonzero low-degree capture has m=0 and the common-b deep component is identically zero, exactly as section 3 requires.

## 7. Source-pair geometry and the precise remaining obstruction

There is also a fixed source-pair subbranch of the same payment. Define

    D_pair(y,z)=sum_i (|y_i-z_i|/b-1)_+.

At a qualified hard capture w, |w_i-z_i|<=R(w)/2<=b/2 implies D_pair(y,z)<=E_b(w-y). Thus the part of the original low-degree capturing residual on D_pair>D is covered by (4), with the same single beta source charge. This source-pair subbranch is not claimed to be equivalent to the full receiver-row depth event: large E_b need not force large D_pair.

Unlike the older infinity-distance tail receipts, the present bound accumulates moderate exterior deviations across coordinates. The moment uses exactly k soft coordinates and hence avoids an additional binom(n,k) coordinate-set price. The scoped comparison against R296 spatial, R303 geometry, R308 capacity, R309 geometry and R288 linear-gap notes found only the old infinity tails, unpriced exterior-count condition, or normalized-affinity displacement estimates, not this common-b total-exterior-depth payment. No exhaustive historical novelty claim is needed for the proof.

After (13), the remaining geometric obstruction is twofold and explicit: the unmodified low-p high-degree traffic, and the low-degree/small-actual-softness capturing endpoint with E_b<=D_zeta coupled to a full untruncated noncapturing row. The latter may still have many possible choices of up to K exterior coordinates; shallow total depth does not imply cheap overlap, source density, or a free K-dimensional maximal bound. Conditions (18),(20) show exactly when original height does force escape from that shallow part. A general source-root price for the shallow part, or a proof that original qualifications force enough such escape, is still missing.

## 8. Actual local diagnostics and bounded reproduction

A fresh standard-library Fraction run proved a rational interval for the W exponential moment by integrating its positive geometric series and bounding the tail. Its interval endpoints have decimal displays approximately 1.5451774444666089 and 1.5451774444799136, both below 8/5; the underlying comparison was exact rational arithmetic. The same run checked 620 coordinate-depth dilation cases (including hard boundaries, eta=1/2 and eta=1) and 47 exact coefficient-sum bounds, including K=0. These are scalar/algebraic diagnostics, not evidence that the unpaid root budget is solved. The profile and original pair integration are proved above. Reproduction writes no files:

```python
from fractions import Fraction as F
from itertools import product
from math import comb
ct={'W_mgf_interval':0,'depth_dilation':0,'coefficient_sum':0}
N=32
lo=2*sum(F(1,2)**j/F(j+2) for j in range(N+1))
hi=lo+4*F(1,2)**(N+1)/F(N+3)
assert F(1)<lo<hi<F(8,5);ct['W_mgf_interval']+=1
vals=(F(0),F(1,2),F(3,4),F(3,2),F(-5,2))
for n in (1,2,3):
 for v in product(vals,repeat=n):
  E=sum(max(abs(x)-F(1,2),F(0)) for x in v)
  m=sum(abs(x)>F(1,2) for x in v)
  for eta in (F(1,2),F(2,3),F(3,4),F(1)):
   Eb=sum(max(eta*abs(x)-F(1,2),F(0)) for x in v)
   assert 0<=Eb<=E and Eb>=eta*E-F(m)*(1-eta)/2
   ct['depth_dilation']+=1
for n in (1,2,8,32):
 for K in range(n+1):
  c=[F(1) if k in (0,n) else
     F(comb(n,k))*F(k,n)**k*F(n-k,n)**(n-k) for k in range(n+1)]
  C=sum(c[k]*F(8,5)**k for k in range(1,K+1))
  bound=F(8,3)*(F(8,5)**K-1)
  assert 0<=C<=bound and (C==0)==(K==0)
  ct['coefficient_sum']+=1
print('PASS',ct)
print('W mgf rigorous rational interval:',float(lo),float(hi))
```

Only /tmp/r310_geometry.md was written. Other authors' files, prior frozen proofs and Git were not modified.
