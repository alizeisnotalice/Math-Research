# R310 actual depth geometry diagnostics

Bounded actual1D phi depth/capture moments and fixed tensor height checks, ordinary45/60digit evidence, not interval certification. Exact Fraction checks cover dilation, common-soft coefficients and dyadic tail thresholds conditional on the analytic moment bound. No selected variable-scale payment, full-history or general dimension-order claim.

E_phi exp(E(v)/2)=inside_phi_mass+2 int_0^1 t²(1-exp(-1/t))/(1-t/2)dt; inside_phi_mass=1-2(1/3-E4(1)). It is compared to a direct segmented x integral. E_W exp(|W|/2)=8log2-4<2.

Actual phi depth moment: 1.30037051459956668321589485000090987330392405449020356810972. W-moment upper: 1.54517744447956247533785697166541254460400107488204203296544.

E(v)=(|v|-1/2)+. For L/b=r in[1/2,1], m outside coordinates: E_b>=r E_L-m(1-r)/2>=E_L/2-K/4 ifm<=K. All dilation decisions are exact rational.

For s>0,m<=K, actualP>= (1-3s/4)^n(s/8)^K exp(-2E_L), using insidephi>=1/4,outsidephi>=exp(-2E)/8. Actual tensor product is checked in log space; s0 is a separate hard-support case.

Conditional on analytic Qk depth moment<=2^k, envelope tail<=An sum_(k<=K)c_nk2^k exp(-D/2). For b/a<=2,An<=1+n. D=2Mlog2 gives exact rational upper(1+n)sum c2^k/2^M; minimal integer M is certified without a floating exponential payment decision.

The capture table is deliberately reduced to18 mixtures. Fixed product profiles use common R=1,s=1/4 and dimension4; their outside-count PGF is product[(a_i-b_i)+b_i z].

|n|K|minimal M|D=2M log2|
|---:|---:|---:|---:|
|1|0|6|8.3177662|
|1|1|8|11.090355|
|4|0|8|11.090355|
|4|1|9|12.476649|
|4|4|12|16.635532|
|16|0|10|13.862944|
|16|1|10|13.862944|
|16|4|13|18.021827|
|16|8|16|22.18071|
|64|0|12|16.635532|
|64|1|12|16.635532|
|64|4|15|20.794415|
|64|8|18|24.953299|
|256|0|14|19.408121|
|256|1|14|19.408121|
|256|4|16|22.18071|
|256|8|20|27.725887|

Combined height gate diagnostics (eta=1/128; rational thresholds summarized by exact binary hash):

|n|K|minimal M|log10 tauCert|
|---:|---:|---:|---:|
|16|0|0|-9.63295986124739824683964463118377685658207621|
|16|1|13|-47.5890682536313779914559596819002631523088091|
|16|4|16|-74.760754679556733003748103153395730330250322|
|16|16|25|-176.222780487322604367786943565989766399579816|
|64|0|0|-17.0946480122310759365225097512959517477930328|
|64|1|15|-64.6487217336087623529494476009384902290641499|
|64|4|18|-110.251010642502774269938248122039316199571094|
|64|6|19|-131.289478405449611529452155469104223131645188|
|64|32|36|-375.900902833735520513476793252035369197177773|
|256|0|0|-13.5628953048246068671746808955360054477064916|
|256|1|17|-65.61559913310872668295536923638947696411879|
|256|4|20|-106.422398670296004248435531543265444480803333|
|256|8|22|-156.648783474215142097383417599692748690027705|
|256|32|37|-491.686170940686997086853103447432887004946531|
|1024|0|0|-12.9551377854523533244820567368225397413405788|
|1024|1|19|-70.8290718651521186137930958993384259517210183|
|1024|4|22|-114.45417616325302871083029321115326710784984|
|1024|10|25|-194.70316131745149697365729303432570570485193|
|1024|32|39|-498.972889873497072737335044729702394351431966|

Conditional scalar gate arithmetic withAn<=n+1,eta1/128,Smax=min(1,28(K+7)/(5n)),s0=min(1/(2n),3eta/(16An n)),CK=sum_(k1..K)c_nk(8/5)^k. Small-s endpoint and depthtail budgets each<=eta. M minimal with(16/3)An CK2^-M<=eta,D=2Mlog2. Remaining core height lower tauStar=pref*2^-8M*exp(-K),pref=(1-3Smax/4)^n(s0/8)^K; rational tauCert=pref2^-8M3^-K<=tauStar sincee<3. tau<min(1-ns0,tauCert) is strict. Empty Smax<=s0 core needs no heightgate. This verifies arithmetic and sampled actual kernel inputs, not the author analytic lemmas or complete original selected-scale payment.

All threshold and dilation decisions are exact Fraction. Actual special-function integrals and tensor height inequalities are ordinary highprecision checks. These finite results do not certify the original selected-scale/source payment.
