# R310 original-cutoff height feasibility

Necessary height-gate feasibility diagnostic only for the stated weakened two-height formula. Original R309 n,qH,K are kept exactly. Empty here does NOT imply the actual finer c_j height gate is empty, because missing c_j/aspect conditions may produce a different stronger height expression. A nonempty necessary window is not a realized original selector/source construction. No full-history or general dimension-order claim.

psi=3-2/(3 gamma^n),kappa=qH v0/(8psi),tau(t)=kappa min(t^(n/2),gamma^(n/2)t^(3n/4)); both terms increase, so minimum at legal tmin. v0=1 requires tmin1, v0=2^(-n/2) uses tmin1/2. Gamma=1+1/n,all n multiples4,so every comparison is exact Fraction. Safe psi3 lowers kappa and gives an even smaller floor.

eta1/128,An=n+1,Smax=min(1,28(K+7)/(5n)),s0=min(1/(2n),3eta/(16An n));M minimal with(16/3)An CK2^-M<=eta,CK=sum_(1..K)c_nk(8/5)^k. tauCert=(1-3Smax/4)^n(s0/8)^K2^-8M3^-K. Gate strict tau<min(1-ns0,tauCert).

|n|qH|original K|v0|legal tmin|log10 tauCert|log10 min height|weakened gate|
|---:|---:|---:|---|---:|---:|---:|---|
|256|1/65536|222|unit|1|-2559.13|-6.15958|EMPTY|
|256|1/65536|222|2^(-n/2)|1/2|-2559.13|-102.272|EMPTY|
|256|1|111|unit|1|-1373.49|-1.3431|EMPTY|
|256|1|111|2^(-n/2)|1/2|-1373.49|-97.456|EMPTY|
|256|65536|12|unit|1|-210.129|3.47338|EMPTY|
|256|65536|12|2^(-n/2)|1/2|-210.129|-92.6395|EMPTY|
|1024|1/1048576|251|unit|1|-3633.54|-7.36375|EMPTY|
|1024|1/1048576|251|2^(-n/2)|1/2|-3633.54|-392.465|EMPTY|
|1024|1|122|unit|1|-1822.06|-1.34315|EMPTY|
|1024|1|122|2^(-n/2)|1/2|-1822.06|-386.445|EMPTY|
|1024|1048576|3|unit|1|-99.9044|4.67745|EMPTY|
|1024|1048576|3|2^(-n/2)|1/2|-99.9044|-380.424|not excluded|

11 of12 tested weakened height gates are empty. This materially limits the use of the small threshold table: a sufficient threshold is not automatically reachable. The remaining case(s) only survive this necessary comparison.

These judgments use the original cutoffs, without choosing a more favorable K. The c_j-refined original gate remains unclassified by this diagnostic.

qH=q_minus H, H=8d,q_minus=3lambda/4 imply lambda d=qH/6. Thus prescribed qH=n² cases already have a known beta main scale n²/6. The only nonexcluded weakened gate in this table has lambda d/sqrt n=16384/3, so it is not overall root-budget improvement evidence.
