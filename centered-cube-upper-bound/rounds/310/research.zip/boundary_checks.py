from fractions import Fraction as F
from itertools import combinations,product
from math import prod
ct_chain=ct_flow=0
for n,R1,shift in product([1,2,4],[F(1),F(3,2),F(2)],
                           [F(0),F(1,2),F(3,2)]):
 ts=[F(k,4) for k in range(5)];cubes=[]
 for t in ts:
  side=1+t*(R1-1);center=t*shift
  cubes.append([(center-side/2,center+side/2)]*n)
 cells=[([(q-F(1,8),q+F(1,8))]*n,w)
   for q,w in zip([F(0),F(3,4),F(3,2)],[F(1,3),F(1,5),F(1,7)])]
 def measure(indices):
  out=F(0)
  for cell,m in cells:
   v=prod(max(F(0),
      min([cell[k][1]]+[cubes[i][k][1] for i in indices])
       -max([cell[k][0]]+[cubes[i][k][0] for i in indices]))
      for k in range(n))
   out+=m*v/(F(1,4)**n)
  return out
 masses=[measure([i]) for i in range(5)]
 union=sum(((-1)**(len(I)+1)*measure(I)
     for k in range(1,6) for I in combinations(range(5),k)),F(0))
 change=sum(masses[i]+masses[i+1]-2*measure([i,i+1]) for i in range(4))
 assert change==2*union-masses[0]-masses[-1]
 N=sum(m for cell,m in cells)
 assert change<=2*N
 ct_chain+=1
 for cutoff,kind in product([F(1),F(3,2),F(2)],range(3)):
  mu=[F(i+1,15)*int(1+ts[i]*(R1-1)<=cutoff) for i in range(5)]
  J=sum(mu)
  if not J: continue
  pi=[[mu[i]*mu[j]/J*(1 if kind==0 else
       ((i+j)%2 if kind==1 else int(i<=j)))
       for j in range(5)] for i in range(5)]
  physical=sum(pi[i][j]*(masses[i]-measure([i,j]))
               for i in range(5) for j in range(5))
  right=[sum(pi[i][j] for i in range(k+1) for j in range(k+1,5))
          for k in range(4)]
  left=[sum(pi[i][j] for j in range(k+1) for i in range(k+1,5))
          for k in range(4)]
  routed=sum(right[k]*(masses[k]-measure([k,k+1]))
       +left[k]*(masses[k+1]-measure([k,k+1])) for k in range(4))
  assert physical<=routed<=N*(max(right)+max(left))
  assert max(right)<=J/4 and max(left)<=J/4
  ct_flow+=1
print('PASS',dict(chain_union_overlap=ct_chain,
                 directed_cut_settlement=ct_flow))  # actual: 27, 243
