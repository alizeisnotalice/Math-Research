# R310 — source crossing variation and the missing weighted-chain connection

## 1. Concrete source-conserving proposition

Let nu be any finite positive measure (the later face formula assumes its original L1 density). Let C_0,...,C_m be axis-aligned cubes, with lower and upper coordinate endpoints l_i(k),u_i(k). Suppose EACH scalar sequence l_i(k),u_i(k) is monotone in k, with its own permitted direction. Then, for every source point z, {k:z in C_k} is an interval of indices, possibly empty. Consequently

    sum_(k=0)^(m-1)nu(C_k Delta C_(k+1))
       =2nu(union_(k=0)^m C_k)-nu(C_0)-nu(C_m)
       <=2 W_nu.                                     (1)

The equality retains the overlap saving; it does not replace each boundary by two independent cube masses. For a nested chain the sharper bound is nu(largest)-nu(smallest)<=W_nu.

Proof: each inequality l_i(k)<=z_i or z_i<=u_i(k) holds on an initial or terminal index segment, because that scalar endpoint is monotone. Their intersection is an index interval. Membership can therefore change at most once from zero to one and at most once from one to zero. Pointwise its number of changes is 2*1_union-1_C0-1_Cm. Integrate against the ORIGINAL nu. This proves (1) with no density, source ordering or boundary-volume assumption.

There is a genuine increasing joint potential. Set V_k=union_(i<=k)C_i and

    P_k=2nu(V_k)-nu(C_0)-nu(C_k).

Interval membership implies C_k intersect V_(k-1)=C_k intersect C_(k-1), so

    P_k-P_(k-1)=nu(C_k Delta C_(k-1))>=0.             (2)

Thus new captured source mass and lost source mass are each charged only once on this chain. Formula (2) is a valid source budget for the whole monotone chain, not a claim about an arbitrary sequence of originally selected cubes.

## 2. True BV distributional derivative along an affine cube path

For two cubes with positive sides R_0,R_1, take

    c(t)=(1-t)c_0+t c_1, R(t)=(1-t)R_0+tR_1,
    C_t=Q_(R(t))(c(t)), 0<=t<=1.

All endpoints are affine, so every source point's capture times are an interval. With S=union_(0<=t<=1)C_t, the SOURCEWISE crossing variation is

    integral nu(dz) Var_t 1_(C_t)(z)
       =nu(C_0 Delta C_1)+2nu(S\(C_0 union C_1))
       =2nu(S)-nu(C_0)-nu(C_1)<=2W_nu.                (3)

For every finite time partition this bounds the sum of the actual symmetric-difference source masses. When nu has an L1 density, tangencies/face coincidences do not create an extra source mass at an isolated time. The scalar mass t->nu(C_t) has total variation at most (3); equality with its scalar variation is NOT asserted, since entry and exit fluxes at different source points can cancel.

There is also a precise face-flux formula. Write nu(dz)=v(z)dz, l_i(t)=c_i(t)-R(t)/2, u_i(t)=c_i(t)+R(t)/2. Then nu(C_t) is absolutely continuous and, for almost every t,

    d/dt nu(C_t)
      =sum_i [u_i'(t) integral_(product_(j!=i)[l_j(t),u_j(t)])
                                    v(z_-i,u_i(t))dz_-i
             -l_i'(t) integral_(product_(j!=i)[l_j(t),u_j(t)])
                                    v(z_-i,l_i(t))dz_-i]. (4)

Zero-velocity terms are zero without choosing a trace. For a moving face, t->z_i is affine with nonzero derivative, so the face integral is defined almost everywhere by Fubini; its integrated absolute flux is finite. Differentiating cube indicators in distributions gives (4). Equivalently each source point contributes its signed entry/exit measures. Simultaneous face crossings occur on a nu-null set, so the TOTAL internal crossing flux is bounded by (3). This proves absolute continuity and the variation bound without a bounded-density assumption.

Crucially the face integrals in (4) are density SLICES, not nu-measures of fixed faces. Fixed faces have zero nu mass for L1 sources but their moving flux need not vanish. Neither the original hard cap nor FIRST bounds these slices by a uniform boundary density.

## 3. Weighted actual-pair settlement requires cut congestion

The original R309/R307 binary pair has captured endpoint w, missed endpoint u and fixed original multiplier M in [0,1]. With c_x(z)=1_(Q_(R(x))(x))(z) and the remaining binary qualification b_x, its exact split is

    c_w b_w(1-c_u b_u)
       =c_w(1-c_u)b_w+c_wc_u b_w(1-b_u).              (5)

Only the FIRST term is physical boundary loss. The second is genuine qualification/history disagreement inside the common cube, and remains completely unpaid by (1)–(4). It can be nonzero when the cubes coincide. All original prefix p,H, low/m, aspect and history gates remain in the actual pair multiplier.

Here is a precise weighted connection if an ordered monotone chain IS available. Let pi_ij(z)>=0 be any original directed pair flow on C_0,...,C_m, including its original receiver weights, normalization, masks and qualifications such as b_w. For cut k define

    L_k^right(z)=sum_(i<=k<j)pi_ij(z),
    L_k^left(z)=sum_(j<=k<i)pi_ij(z).

A captured i and missed j must cross an exit edge if i<j, or an entry edge if j<i. Thus

    sum_ij pi_ij(z)1_(C_i)(z)[1-1_(C_j)(z)]
      <=sum_k [L_k^right(z)1_(C_k)(z)[1-1_(C_(k+1))(z)]
               +L_k^left(z)1_(C_(k+1))(z)[1-1_(C_k)(z)]]
      <=max_k L_k^right(z)+max_k L_k^left(z).          (6)

Each direction has at most one source crossing. This is a true directed-overlap budget, retaining original source locations rather than a boundary-volume approximation. Nested chains need only their one possible direction.

For the ACTUAL receiver prefix flow bounded by pi_ij<=mu_i mu_j/J, each direction satisfies

    L_k^direction<=J_left J_right/J<=J/4.             (7)

There is no missing factor 1/2: (6) is for the oriented captured/missed form (5). A symmetric un-oriented convention would instead carry its own half. Zero rows have no flow.

For a family of actual chains indexed by y and original prefix r, retain the original beta(dy)ell_n(dr) and source-dependent masks in pi. A verifiable source settlement would be the cut-load certificate

    integral beta(dy)ell_n(dr)
        [sup_cuts L_(y,r,z)^right+sup_cuts L_(y,r,z)^left]
                       <=C_nu for nu_*-almost every z. (8)

Then integrating (6) pays the physical boundary piece by C_nu W_(nu_*), once. If each direction is separately <=C, the fee is 2C W_(nu_*). The same statement holds on an existing measurable ordered continuum chain: take suprema over both open and closed initial cuts, so atoms at entry/exit or equal selected radii are included. Finite monotone discretizations are a sufficient implementation only when their actual flow loads are controlled uniformly; no such discretization is presumed for arbitrary receiver fields.

Equation (8) is an ADDITIONAL weighted routing certificate, not a proved consequence of FIRST and not a renamed paid fee. It specifies exactly which shared source crossing must be controlled. All R^(-n) scale weights remain in the original ell_n flow; they have not been discarded using the unweighted count (1).

## 4. The original-input connection is still missing

Any ONE endpoint pair admits the affine path in Section 2. Applying its 2W_nu bound separately to all original pairs would multiply by their total row/prefix flow and is NOT a source-linear payment. Joint cut congestion across y and r is the missing step. FIRST bounds the actual aggregate receiver density integral_beta U_y(x)<=1; it does not supply a monotone-chain routing of receiver pairs with (8). The naive load estimate (7) still contains J, and no root cross-row/scale budget follows from it. Keeping only the usual column capture capacity leads back to integral r^n ell_n(dr)=A_n, the old linear-scale expense.

The original selected centers and scales need not arrive as any endpoint-monotone chain. An affine path inserts virtual cubes whose centers need not be accepted receivers. Even if its radii stay in [a,b], SAME-radius hard caps at the original endpoints do NOT authorize caps at those virtual centers. Original FIRST is also not available there. No external chain decomposition or embedding theorem is invoked to fill that gap.

If one attaches a scale-dependent weight to the BV derivative, its entry/exit values must be retained in (3); a crude bound is 2sup_t R(t)^(-n)W_nu, not 2W_nu. Thus even one chain's crossing count cannot erase its physical scale normalization. The actual formulation (8) deliberately includes the original scale measure before making a source claim.

The proved contribution is the exact union/overlap source potential (1)–(3) and its directed weighted settlement (6). It gives a dimension-free source budget on a genuine monotone chain. A root-priced actual routing certificate and the common-cube qualification term in (5) are both unresolved for the original arbitrary-input pair integral. No new full root estimate or global entry is claimed.

## 5. Actual L1-source diagnostics and reproduction

The following exact-Fraction calculation was actually run. It passed 27 chain union/overlap identities and 243 directed-flow settlements, using piecewise constant L1 source densities in dimensions 1,2,4. The tests include translations, changing cube sizes, receiver-prefix restrictions and asymmetric flow masks. They validate the chain theorem, not existence of an original routing certificate (8).

```python
from fractions import Fraction as F
from itertools import combinations,product
from math import prod
ct_chain=ct_flow=0
for n,R1,shift in product([1,2,4],[F(1),F(3,2),F(2)],
                           [F(0),F(1,2),F(3,2)]):
 ts=[F(k,4) for k in range(5)];cubes=[]
 for t in ts:
  side=1+t*(R1-1);center=t*shift
  cubes.append([(center-side/2,center+side/2)]*n)
 cells=[([(q-F(1,8),q+F(1,8))]*n,w)
   for q,w in zip([F(0),F(3,4),F(3,2)],[F(1,3),F(1,5),F(1,7)])]
 def measure(indices):
  out=F(0)
  for cell,m in cells:
   v=prod(max(F(0),
      min([cell[k][1]]+[cubes[i][k][1] for i in indices])
       -max([cell[k][0]]+[cubes[i][k][0] for i in indices]))
      for k in range(n))
   out+=m*v/(F(1,4)**n)
  return out
 masses=[measure([i]) for i in range(5)]
 union=sum(((-1)**(len(I)+1)*measure(I)
     for k in range(1,6) for I in combinations(range(5),k)),F(0))
 change=sum(masses[i]+masses[i+1]-2*measure([i,i+1]) for i in range(4))
 assert change==2*union-masses[0]-masses[-1]
 N=sum(m for cell,m in cells)
 assert change<=2*N
 ct_chain+=1
 for cutoff,kind in product([F(1),F(3,2),F(2)],range(3)):
  mu=[F(i+1,15)*int(1+ts[i]*(R1-1)<=cutoff) for i in range(5)]
  J=sum(mu)
  if not J: continue
  pi=[[mu[i]*mu[j]/J*(1 if kind==0 else
       ((i+j)%2 if kind==1 else int(i<=j)))
       for j in range(5)] for i in range(5)]
  physical=sum(pi[i][j]*(masses[i]-measure([i,j]))
               for i in range(5) for j in range(5))
  right=[sum(pi[i][j] for i in range(k+1) for j in range(k+1,5))
          for k in range(4)]
  left=[sum(pi[i][j] for j in range(k+1) for i in range(k+1,5))
          for k in range(4)]
  routed=sum(right[k]*(masses[k]-measure([k,k+1]))
       +left[k]*(masses[k+1]-measure([k,k+1])) for k in range(4))
  assert physical<=routed<=N*(max(right)+max(left))
  assert max(right)<=J/4 and max(left)<=J/4
  ct_flow+=1
print('PASS',dict(chain_union_overlap=ct_chain,
                 directed_cut_settlement=ct_flow))  # actual: 27, 243
```

Only /tmp/r310_boundary.md was written. Other authors and Git were preserved.
