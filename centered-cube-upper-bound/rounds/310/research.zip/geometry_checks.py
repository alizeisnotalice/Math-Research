from fractions import Fraction as F
from itertools import product
from math import comb
ct={'W_mgf_interval':0,'depth_dilation':0,'coefficient_sum':0}
N=32
lo=2*sum(F(1,2)**j/F(j+2) for j in range(N+1))
hi=lo+4*F(1,2)**(N+1)/F(N+3)
assert F(1)<lo<hi<F(8,5);ct['W_mgf_interval']+=1
vals=(F(0),F(1,2),F(3,4),F(3,2),F(-5,2))
for n in (1,2,3):
 for v in product(vals,repeat=n):
  E=sum(max(abs(x)-F(1,2),F(0)) for x in v)
  m=sum(abs(x)>F(1,2) for x in v)
  for eta in (F(1,2),F(2,3),F(3,4),F(1)):
   Eb=sum(max(eta*abs(x)-F(1,2),F(0)) for x in v)
   assert 0<=Eb<=E and Eb>=eta*E-F(m)*(1-eta)/2
   ct['depth_dilation']+=1
for n in (1,2,8,32):
 for K in range(n+1):
  c=[F(1) if k in (0,n) else
     F(comb(n,k))*F(k,n)**k*F(n-k,n)**(n-k) for k in range(n+1)]
  C=sum(c[k]*F(8,5)**k for k in range(1,K+1))
  bound=F(8,3)*(F(8,5)**K-1)
  assert 0<=C<=bound and (C==0)==(K==0)
  ct['coefficient_sum']+=1
print('PASS',ct)
print('W mgf rigorous rational interval:',float(lo),float(hi))
