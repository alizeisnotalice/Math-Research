# R212：基线的动态 J 阈值付款与剩余交叉时钟

状态：证明原完整 far 正余项的一个实际时间子域具有来源价
`16Λ L0/(3K) Wν`，故预定 `L0=sqrt(n)` 给根阶来源价。这里支付的是完整 `rho0` 权，不只 J-share。全部负余额留在其补集一次。本稿没有支付整个 baseline；补集是同一终端 good 目标在当前时刻仍超过 J 阈值的交通。常数 good 势及其 suffix 账是 R170 已有恒等式的精确继承，不登记为新的付款定理。

## 1. 原式、来源及量词

实际窄读以下材料：

- R128 `/Users/zhengzhihao/Desktop/T/output/centered_cube_round128_20261014/proof.md` RT1–6，约604–667行：原外测度、完整 rho 权、两个原负项、实际 far 区间、物理时钟及 capture。
- R211 冻结 `joint_capacity.md` JC19–30：在同一实际 capture 集、同一 remaining 域和全部原门上，将完整 rho 换成 rho0；恢复价单独支付，未消费负余额仅归 baseline。
- R170 冻结 `soft_threshold_energy.md` §§1–4：终端集合分解、删除负交通及 constant-good/filtered 势。其旧来源排序 `Wν<=Wβ` 不继承；本稿只用后来修复的共同父预算 `Wν<=WA`。
- R181 common-parent 来源修复与原固定窗口 J 列预算：仅共同父控制，不假定 `ν<=β`。

固定一个原合法共同窗口和有限正负交通截断。保留完整行
`(ω,V,j,x,y,硬源z,history)`，以及原共同 selector `s(x),L(x),R(x)`。写
\[
 p_y=P_{s,L}(x-y),\quad J_v=P_{1,b}(x-v),\quad
 Q_v^*=(P_{s,L}(x-v)+P_{s,L^+}(x-v)+J_v)/3.
\tag{BG1}
\]
同一窗口 b 固定，`Lplus=min(b,(1+1/n)L)`。原外测度为
\[
 d\mathcal T=1_I1_{\{j(x)=j\}}q^{-1}p_yh_R(x-z)a_\omega
 \,dx\,\beta_V(dy)\nu_V(dz).
\tag{BG2}
\]
其 high、历史和接收域均保留。q 是原共同阈值，不改成新函数；只用原 FIRST 上界，不假定等号。所有新增接收域积分先在原接收域上进行，作非负 J 列上界时才扩大到全空间。

终端 `G=S_g`、`B=D_g` 满足 `G disjoint-union B=Z_g`，而
\[
 E_t=Z_t\setminus Z_g,\quad
 d\Pi_t(v)=1_{Z_t}(v)w_t(v)d\nu(v)/e_t,\quad
 w_t(v)=\prod_i\min(1,\alpha_i(y,v)/t),\quad
 \alpha_i(y,v)=(b/c_j)C(|y_i-v_i|/b).
\tag{BG3}
\]
`G,B` 在辅助 t 中固定且都存活至 g。固定 `(ω,V,j,y,t)` 后完整 `Pi_t` 不依 x；本稿不替换它，也不需要对原 selector 冻结网格。物理权连续、单调、局部绝对连续，并有
`−d w_t(v)/d log t=k_t(v)w_t(v)`，`k_t(v)>=0`。

实际 far 是原初段 I 与 `[tau,h]` 的交，记其非空内部为 `(l,r)`，其中 `r<=h<g`。端点取相应的一侧权值。所有零 `p_y,e_g,Q_J` 或空 far 行先按原约定隔离；正交通行使用正分母。

实际 capture 集另记为
\[
 E_{cap}=G\cap\{B_{hard}=0,\ \Delta_v=w_\tau(v)-w_h(v)>0\},
 \quad a_v=T\Delta_v,\quad Q_J=\int J_vd\nu(v).
\]
\[
 \rho_{0v}=1_{E_{cap}}(v)
 \left(1-\frac{D K_{0v}+(Dq/Q_J)J_v}{a_v}\right)_+.
\tag{BG4}
\]
外面的实际门即使依赖原 rho，也不以 rho0 重选。令 `M_t(v,u)` 包含原 remaining 指示和 FA 门，取值于 `[0,1]`；原 suffix 指示 Ψ 单列。

## 2. 主要新命题：动态 J 阈值支付完整 rho0 正交通

预先固定 `L0>0`，对每条实际行、每个终端目标定义
\[
 c_v=\frac{L_0J_v}{p_y},\qquad
 \mathcal L=\{(t,v,u): w_t(v)\le c_v\}.
\tag{BG5}
\]
这是用原同一时钟与真实接收核测试的可测时间子域，不重选 alpha、来源、selector 或后验。门可以依 x,y,v；它不依赖 u。定义原正 baseline 在此子域的行量
\[
 P_{0,\mathcal L}^{row}
 =\int_l^r\iint_{G\times B}
 \Psi M_t\rho_{0v}1_{\mathcal L}
 (k_t(v)-k_t(u))_+\,d\Pi_t(v)d\Pi_t(u)\frac{dt}{t}.
\tag{BG6}
\]
则其完整原外积分满足
\[
 \boxed{2\Lambda\,\mathbb E\sum_{V,j}
 \int1_{high}P_{0,\mathcal L}^{row}\,d\mathcal T
 \le \frac{16\Lambda L_0}{3K}\,W_\nu
 \le\frac{16\Lambda L_0}{3K}\,W_A.}
\tag{BG7}
\]
特别 `L0=sqrt(n)` 给该实际完整 rho0 子支的根阶来源预算。式中没有使用任何原负信用，也不另消耗 R211 已分配的恢复 epsilon。

**证明：先时间，后共同 high 列，最后固定 J 的真实 dx。** 因终端目标 v 在整个区间存活，逐 v 的未归一 FTC 精确给
\[
 \begin{split}
 D_v(c_v;l,r)
 &:=\int_l^r1_{\{w_t(v)\le c_v\}}k_t(v)w_t(v)\frac{dt}{t}\\
 &=\big[\min(w_l(v),c_v)-w_r(v)\big]_+\le c_v.
 \end{split}
\tag{BG8}
\]
等号层上若权在一段内恒定，则 `k_t w_t=0` a.e.；单一跨越时刻无时间原子。纯硬退化零权可直接用同一 AC 恒等式。

仅作正放松：`rho0,Ψ,M<=1`、`(kv-ku)+<=kv`、原 u 后验概率不超过1，以及 `e_t>=e_g`，得到
\[
 P_{0,\mathcal L}^{row}
 \le\frac1{e_g}\int_G\rho_{0v}D_v(c_v;l,r)d\nu(v)
 \le\frac{L_0}{p_y e_g}\,J\nu_V(x).
\tag{BG9}
\]
这个步骤完整保留 target 的一份归一分母；没有将双后验当成独立的自由来源概率，也没有支付倒 `w_g`。

原 high 门给 `p_y e_g>=2Kq`。在固定 x,j,V 下，FIRST 对同一个当前 selector 给
\[
 \int1_{high}\frac{d\beta_V(y)}{e_g(y)}
 \le\frac1{2Kq}\int p_y\,d\beta_V(y)
 \le\frac1{2K}.
\tag{BG10}
\]
其它原门可以继续留在左侧。原 hard 源只在这里用一次
`q^{-1}h_R nu_V<=16/3`，并用 `a_omega<=1`。把 BG9–10 代入 BG2 得
\[
 \frac{32\Lambda}{3}\frac{L_0}{2K}
 \mathbb E\sum_{V,j}\int1_{\{j(x)=j\}}J\nu_V(x)\,dx.
\]
先保原唯一 j 指示至此，J 已不依 j，才求和消去它；随后 `int J nu_V dx=||nu_V||`。这正是 BG7。时间已经由 BG8 完整结算，没有再乘 `log 2`、删除次数或 j 菜单大小。若先删唯一 j，便必须支付菜单费，不能引用本式常数。独立窗口须按原窗口来源账累加；本稿不对每窗免费重复同一 `W_A`。

## 3. 精确跨越损失及 J-share 推论

设 `t_c` 为该物理权首次下降至 c_v 的时刻；若未跨越，使用相应空域。BG8 不是用一个假设的首次时刻代替原历史，而是原连续单调权的直接推论。互补的未归一损失为
\[
 E_v(c_v;l,r)
 :=\int_l^r1_{\{w_t(v)>c_v\}}k_t(v)w_t(v)\frac{dt}{t}
 =\big[w_l(v)-\max(w_r(v),c_v)\big]_+,
\]
\[
 D_v+E_v=w_l(v)-w_r(v).
\tag{BG11}
\]
因此原前跨越正交通仍有严格上界
\[
 P_{0,\mathcal L^c}^{row}
 \le\frac1{e_g}\int_G\rho_{0v}E_v(c_v;l,r)d\nu(v).
\tag{BG12}
\]
它保留真实损失而不是整 `w_l`；但是 BG12 的外积分尚未被本稿支付。不能再将其积分来源称作概率或凭 `nu<=beta` 删除归一分母。

自然的 J-share `A_J=rho0 J/(3Q*)` 在动态门
`p_y w_t(v)<=K Q_v*` 上同理满足
\[
 p_y P_{J,inst-good}^{row}\le\frac K{3e_g}\,J\nu_V(x),
 \qquad Raw_{J,inst-good}^+\le\frac{16\Lambda}{9}W_\nu.
\tag{BG13}
\]
BG13 不是完整 rho0 付款；完整权主结论是 BG7。两式如同时使用，要先把它们覆盖的正交通不交化，不重复给同一交通领价。

R170 `soft_threshold_energy.md` §4–5 的证明要求初始/终端权比 `w_l/w_g<=exp(M)`，并在 signed 结论中保排序、suffix 条件。BG7/13 不要求初始权比有界，直接支付在跨越后发生的正交通。这里仅确认证明范围不同；没有用代数范围差自动宣称一条新的 FULL 严格覆盖实例。R170 §2 的常数 good 势则就是下一节所继承的旧恒等式。

## 4. 同一负余额上的常数 good 势：完整门与删除

令 `d_t(v,u)=k_t(v)-k_t(u)`，`b_t=Pi_t(B)`。在无删除连续时间，
\[
 b'_t=\iint_{G\times B}d_t\,d\Pi_t^2
       +\iint_{E_t\times B}d_t\,d\Pi_t^2.
\tag{BG14}
\]
一般递减来源的删除还给一个非负变差测度 `db_del`；它包括 AC 删除、奇异连续删除和跳跃。在一批删除占原概率 δ 时，B 存活，故 `Delta b=b_- delta/(1-delta)>=0`。正 `e_g` 行不会在当前段发生完全灭行。

对任何实际正权 `0<=m_t(v,u)<=1`，保原两个完整未消费负项，定义
\[
 q_t(m)=\iint_{G B}\Psi(m_t d_t^+-d_t^-)d\Pi_t^2
            -\iint_{E_t B}d_t^-d\Pi_t^2.
\]
精确测度恒等式为
\[
 \begin{split}
 q_t(m)\,d\log t={}&db_t-db_{del}(t)\\
 &+\left\{\iint_{GB}(1-\Psi)d_t^-d\Pi_t^2
 -\iint_{E_tB}d_t^+d\Pi_t^2
 -\iint_{GB}(1-\Psi m_t)d_t^+d\Pi_t^2\right\}d\log t.
 \end{split}
\tag{BG15}
\]
当前 baseline 用 `m=M_t rho0`；若把 rho0 换成 `1_Ecap`，右侧恒等式对应正上放后的泛函，不再是原 baseline 的等式。若剔除 BG7 已付片，取
`m=M_t rho0 1_{w_t>c_v}`。所有原负余额仍只在这个前跨越泛函中出现一次。

积分 BG15 的端点是 `b_r-b_l`，不是 `b_g-b_tau`。原 `r<=h<g`，不得无价延长 signed 时间段。后缀泄漏
\[
 L_{suffix}=\int_l^r\iint_{GB}(1-\Psi)d_t^-d\Pi_t^2\frac{dt}{t}
\tag{BG16}
\]
必须保留：补 suffix 上的反向信用已被旧账消费，不能重新使用。若当前实际可用负余额比 BG15 的完整 RT2/删除负项更少，还须精确加回其已消费差 `N_full-N_avail>=0`。不以任何新势隐去这笔差。

目标 capture 集不等于 G：硬捕获 `B_hard=1` 的目标被正权删除，其缺失保在 BG15 最后一个非负耗散中；若 `Delta_v=0`，物理权在 `[tau,h]` 恒定，故 `k_t(v)=0` a.e.，其正 `d_t^+` 本身为零。原 already-paid 正子域同样只能作为正项缺额保留，不能据此重领负余额。

BG15 在前跨越泛函中出现的跨越后 `d_t^+` 缺额只是恒等式中被删掉的正交通，不能单独命名为原负信用再使用。有限正负截断先成等式；极限须有原可积控制，不能解释 `infinity-infinity`。

## 5. 与实际 good/bad 似然排序的接缝

终端绝对门是
\[
 p_yw_g(v)\le KQ_v^*\ (v\in G),\qquad
 p_yw_g(u)>KQ_u^*\ (u\in B).
\tag{BG17}
\]
由 FIRST 与 high，得到实际全 bad 集合的终端质量结论
\[
 \Pi_g(G)\le\frac{Kq}{p_y e_g}\le\tfrac12,
 \qquad\Pi_g(B)\ge\tfrac12.
\tag{BG18}
\]
它不要求 reciprocal bad；也不给每个 bad 来源的统一 `w_g(u)>kappa`，更不推出较早的 `Pi_t(B)>=1/2`。

在正核行，令
\[
 L_t(v,u)=\log\frac{Q_v^*/w_t(v)}{Q_u^*/w_t(u)}.
\]
实际 good/bad 给 `L_g(v,u)>0`，物理时钟给
\[
 \frac{dL_t}{d\log t}=d_t(v,u),\qquad
 L_t=L_g-\int_t^g d_s\frac{ds}{s}.
\tag{BG19}
\]
因此终端似然排序只约束未来 signed score 积分，不推出逐时 `d_t>=0`。原 remaining 中的 `Psi`、FA 及两腿概率仍须在积分内。尤其不能将 BG19 的无权时间积分当作已支付的 `Pi_t^2` 交通。

BG13 剩余的目标是 terminal-good 但当前仍满足 `p_yw_t(v)>KQ_v*` 的时段。BG7 的完整权剩余则为
\[
 p_yw_t(v)>L_0J_v,\qquad
 a_v>D[K_{0v}+(q/Q_J)J_v],
\tag{BG20}
\]
再交同一实际 E、所有原门及已付片的补集。它们不是同一个门，不能混称 full 权只剩 instantaneous-bad。

## 6. 原阈值基线与无衰减 capture 权只差一个有价量

此节是判断基线支持作用的短比较，不代替 BG7。始终使用同一实际 E 和全部原门。定义 `P_E(1)` 为正权 `1_E`，`P_E(rho0)` 为实际基线。由
\[
 a_v(1-\rho_{0v})=\min\{a_v,DK_{0v}+(Dq/Q_J)J_v\}\quad(v\in E),
\]
以及原未归一 far FTC，
\[
 0\le P_E(1)^{row}-P_E(\rho_0)^{row}
 \le\frac{2Dq}{Te_g}\le\frac{2D}{\sqrt\ell}.
\tag{BG21}
\]
所以完整原外账给
\[
 0\le2\Lambda(P_E(1)-P_E(\rho_0))
 \le\frac{16\Lambda D}{\sqrt\ell}X.
\tag{BG22}
\]
这里保留原 X，不将其另认作任意 `int q dx`。若另要 epsilon 加有限维来源表达，必须在预定参数时另分配比较额度，并用 R211 相同母核回退；不能自动重领已经支付给 rho 到 rho0 恢复的额度。同一个 `N_avail` 在这两个 signed 表达中各出现一次，差仍仅为 BG22 的非负正权变化。比较不授 `1_G` 代 `1_E` 的双向等价。

## 7. 当前实际全局剩余与第一处未付关系

令 `P_early` 是 BG20 上的完整原正 baseline 交通。BG7 严格给
\[
 2\Lambda(P_0-N_{avail})
 \le \frac{16\Lambda L_0}{3K}W_A
       +2\Lambda(P_{early}-N_{avail}).
\tag{BG23}
\]
未付量仍是原共同 RT1 测度上的前跨越 signed 交通；不是另造的概率模型。可用于下一步的两项精确输入是 BG11–12 的真实损失与 BG15 的共同终端分类势。需要证明的是这些同源量在同一个外积分中可以结算，而不是分别上放：
\[
 2\Lambda\,\mathbb E\sum_{V,j}\int1_{high}
 \left[b_r-b_l-\int db_{del}+L_{suffix}
 -\int E_tB\,d_t^+d\Pi_t^2\frac{dt}{t}
 -\int GB(1-\Psi M_t\rho_0 1_{w_t>c_v})d_t^+d\Pi_t^2\frac{dt}{t}
 +N_{spent}^{row}\right]d\mathcal T.
\tag{BG24}
\]
括号就是该实际前跨越 signed 泛函（在有完整可比负账的截断上）；`N_spent` 只在需要时精确加回。BG18 单独只给 O(X) 的粗端点价，不能吸收。BG19 单独只给无权排序，不能支付后缀泄漏或归一化来源重用。BG12 中的 `e_g^{-1}rho0 E_v` 也没有由 FIRST 的上容量获得独立的空间列价。

因此本稿的新实付结论是 BG7（及 BG13 的 share 推论），而非一般根阶闭合。其补集准确保留真实 receiver/source/clock 与 signed 余额；没有假定 ν、β 相互支配，没有新增 per-leaf 质量帽，没有删除 selector 或窗口成本，也没有将数值 score 的双向出现解释成一般上界反例。
