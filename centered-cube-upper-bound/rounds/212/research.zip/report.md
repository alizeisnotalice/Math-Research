# R212 最终研究报告：动态核比值截断与完整正交通来源预算

一般 n^(1/2+o(1)) 一致弱型上界尚未闭合。本轮将第211轮的原 far 高初始参数基线推进为一个有根阶价格的实际动态子域；没有用该子域替代一般目标。

## 主结果

在同一原 remaining 正域上，保全部真实来源、receiver dx、history、Pi_t、外 hard 来源及唯一 j，增加门 p_y w_t(v)≤L0 J_v，其中 L0>0 在构造外共同预定。完整正交通（不是仅 J-share）的 raw 价格为

    2Λ P_low ≤ (16Λ L0/(3K)) Wν ≤ (16Λ L0/(3K)) WA.

取 L0=K sqrt(n) 得 (16Λ/3)sqrt(n) WA。证明关键为实际 min-product clock 的精确截断损失

    ∫_[l,r] 1_{w_t≤H} k_t w_t dt/t = [min(w_l,H)−w_r]_+.

先对实际完整两槽后验作正上界，坏槽质量≤1、et≥eg，后使用该损失，得到 p_y R_low≤L0 Q_J/eg。只使用一次原 hard 帽16/3，再用 high/FIRST 的 ∫high β/eg≤1/(2K)。固定窗口共同 J=P1,b 和唯一 j 保留到最后，∫Jν dx=||ν||。无额外时间菜单、分层或来源数费用。不用ν≤β，最后采用已核同一共同父来源 Wν≤WA。若另有独立窗口菜单，必须累加各自 W_A,m 和真实系数，不能逐窗重复领取同一 W_A；本轮没有新增跨窗口免费归并。

已付正域先删除，新低比值片只在 remaining 域收费；原可用负余额完整留给补域一次。该正界实际上对所有0≤rho≤1成立，不依赖rho0的特别支持。没有认证新FULL非空实例，也不因此声称全部一般输入已被覆盖。

## 补充结论与不重复旧结果

同源真实捕获在 C0={rho0>0} 上给 U=κ，因此 ∫a rho0(1−rho0)ν≤Dq+GU≤2Dq。它给明确的中间残余片0<rho0≤1−η价格16ΛD/(ηsqrt(ell))X；只有原先预留的独立误差槽符合要求时才可吸收。不能重复R211的恢复额度或事后缩小固定epsilon_RC。

先付动态低比值片，再付其补域中的中间残余片，可把未付正域限定到同时满足 p_yw_t>Ksqrt(n)J 和 rho0>1−η，并保留全部原门及原负余额。此交集的来源列预算仍未知。归一pi=Jν/Q与Pi_t不同；J矩只控大J/w_t尾，而这里需要小J/w_t后验占用，不能从一阶矩直接反向推导。

constant-good势的基本协方差恒等式在R170已经存在，本轮仅对原rho0及动态门重写可用账，不登记成新理论。原删除负交通是Et×B上的反向dt密度，不是删除时b=Pi(B)的上跳。完整账保真实端点、正删除变差、suffix泄漏、实际正亏损；任何已消费negative必须加回。单位行端点不是任意小epsilon费用。R170的终端w_l/w_g条件与signed排序条件，不直接涵盖本轮动态正片付款。

## 实际本机计算

1. geometry_probe.py：20个固定种子配置，每个12000个receiver；n=1、4、16及对应s=.25/.75、三种固定来源几何、两方向、三个瞬时时刻。实际采样p_s张量密度，保指定两来源的完整后验。原FIRST/high/history未认证，K=1和64均为诊断。
2. 720个固定近似门的同时99% Hoeffding/Bonferroni区间半宽.02224631859。表域32和log-band .001预先固定。八项高精度核检查、有限网格插值敏感性已运行，但没有全域区间误差证书，故统计区间不能直接认证真实门。
3. capped_clock_checks.py：9个Fraction精确时钟案例，按初步3例、平台/重复阈值/零支压力3例、扩大至n=64的3例组织；独立分段积分与截断端点恒等逐例相同。另2个完整两源后验例实际flux为2/45和1/28，分别≤帽损失/eg的4/45、4/75。仅条件时钟证书，不是空间FULL构造。
4. 主代理已实际运行两份脚本，exit 0；与参考JSON逐字节相同。最终归档由reproduce.py再次校验清单并迁移运行两份脚本，最终执行结果在轮次README记录。

有限几何样本中good/bad门内可见两种score方向，因此本轮采用带原负交通的联合估计，而未用逐点排序作为一般证明。不同配置的正/负最大值不相减，不据n=4/16拟合渐近阶。

## 复现

先解压同目录文件，运行 `python3 reproduce.py --verify-only`。完整复现要求Python带numpy和mpmath。实际本机命令：

    PYTHONPATH=/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor /Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 reproduce.py --output-dir <全新目录>

驱动将脚本及task_contract复制到临时目录运行；校验全部JSON字节、前后文件哈希，不覆盖参考结果。纯Fraction脚本也可独立用标准库Python运行。解释器和PYTHONPATH路径记录于numeric_notes.md，依赖版本与入口文件哈希记录于几何JSON的环境账，换依赖版本导致字节差异必须说明，不伪称同环境复现。

## 证据、工具与剩余问题

使用64工具中的A01技能，范围仅为实际正分母、共同来源及换权纪律，没有调用未核CCT/SOS或外部定理。原式定位和作者推导见baseline_geometry.md，辅助容量及准确时钟条件见baseline_coupling.md，最终详细LaTeX见proof.tex.txt，独审见audit.md；不编译PDF。

下一步必须直接处理剩余高p_yw_t/J、近单位rho0域的来源/receiver联合几何，并将原负余额、suffix泄漏与端点一同结算。near及其他未涉原块仍须保留。不能把改写势、重复归约或已有精确时钟例当作完成这一缺口。

本轮记录的是实际工具运行及文件成果，未获得可归属各Agent的真实扣额数据，不估计模型成本比例。
