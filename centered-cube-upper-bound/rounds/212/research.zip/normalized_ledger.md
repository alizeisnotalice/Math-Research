# R212 基线的共同来源比值与终端测度（精确账，非新付款）

采用A01技能的正分母/原可行域纪律，不外引优化定理。固定原实际行，Q=int Jnu>0、q>0、D>0、0<eg<infinity；实际J=P1,b严格正，零来源按原零支处理。所有原门保持，不重算。

在同一完整来源上令pi_J(dv)=J_v nu(dv)/Q，X_v=a_v Q/(Dq J_v)，Y_v=K0_v Q/(q J_v)。则pi_J是概率，但其与Pi_t不同。终端实际target E上a>0，rho0=(1−(1+Y)/X)+，a rho0=(Dq/Q)J (X−1−Y)+。因此原非负target时钟FTC只给
 Rbaseline_plus <= (Dq/(Teg)) int_E (X−1−Y)+ dpi_J。
heavy使前系数<D/sqrtell。这里EπY=int K0nu/q<=1，不能因此给(X−1−Y)+的上界；EπX=int a nu/(Dq)须保真实定义及实际有效支持，未被FIRST或heavy直接上界。若a只在原终端/合法time域定义，以上X应仅在其域定义，并用指示保留，不自行外推成全source变量。

完整终端归一mu(dv)=1_Zg wg(v)nu(dv)/eg是概率。定义在Zg上的L_v=(w_tau−w_h)/wg>=0，r_v=eg J/(Q wg)，c=Dq/(Teg)，d_v=D K0/(T wg)。则
 int_E a rho0 nu/(Teg) = int_E (L−c r−d)+ dmu。
并且int_Zg r dmu=int_Zg Jnu/Q<=1；这是终端受限的pi_J质量，不得把它改称1或source独立。各密度都来自同一原nu；支持外不形成1/wg，有限正窗ratio<= (g/tau)^n保证该行必要可积量。

实际正交通比这个单腿FTC上界更细，仍含bad后验、score差和Hrem。不能因为后者正尾大便宣称实际signed基线大；原负余额保持一次，也不能用某个正上界的负项去抵消原负账。以上两个准确归一只是共同极值可行域的输入，未成立新的source预算，不计为本轮主要数学成果。
