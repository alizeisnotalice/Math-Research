# R212：高初始系数基线的共同来源容量与时钟耦合

状态：给出实际来源上的缺陷容量、其可付中间残余份，以及接近单位残余时的精确 score/likelihood 必要条件。主要结论不是再把 rho 换成 rho 的幂后声称余项消失：容量只证明连续残余中间份可付；高 rho 余域仍需要真实几何。没有证明一般目标闭合。未读本轮 Astra 空间稿。

使用 A01 技能仅限实际正分母、零支、共同可行域和比值换权纪律；已读其 SKILL 与 provenance，不调用 CCT、SOS 或未读外部文献定理。

## BC1　同一原最终行与两种不同概率

使用冻结 R211 JC19--30 的实际最终行，完整 remaining far 域、原 Hrem/Ψ/FA/high/history/selector、硬来源和真实 dx 保持原值。此前已付正子集仍删去，原负余额只留基线一次。

固定真实 nu、J、K0、q、D 及共同 min-product clock：
\[
 Q=\int J_v\nu(dv)>0,\quad
 a_v=\mathsf T(w_\tau(v)-w_h(v)),\quad
 \kappa_v=DK_{0v},\quad
 U_v=1_E(v)\min(a_v,\kappa_v),
\]
\[
 G_U=\int U\,d\nu\le Dq,\qquad
 \alpha=(Dq-G_U)/Q\ge0,\qquad \alpha_0=Dq/Q>0.
 \tag{BC1}
\]
原 E 包含于终端 good G⊂Zg；只在实际 a>0 的目标上写比值。实际 baseline 为
\[
 \rho_0=1_E\left(1-\frac{\kappa+\alpha_0J}{a}\right)_+.
 \tag{BC2}
\]
E外的原零/旧余权保持R211准确资格，不从一个新定义E重新建历史。零a/Q/eg、空far先按原零对象处置。

在J>0来源上定义
\[
 \pi(dv)=J_v\nu(dv)/Q,\qquad
 X_v=\frac{a_vQ}{DqJ_v},\qquad
 Y_v=\frac{K_{0v}Q}{qJ_v}.
 \tag{BC3}
\]
Q>0且q>0为这些比值的资格；若J0槽存在，仅在Jν有效支作归一，不能逆除J0。原实际软J为严格正时无需额外删源。X0按rho0=0先处理，不写(1+Y)/0。有效E上
\[
 \rho_0=\left(1-\frac{1+Y}{X}\right)_+,
 \qquad a\rho_0=(Dq/Q)J(X-1-Y)_+.
 \tag{BC4}
\]
这只是同一nu的正密度重写，不是将来源变成独立坐标。pi与原
\[
 \Pi_t(dv)=1_{Z_t}(v)w_t(v)\nu(dv)/e_t
 \tag{BC5}
\]
不同，不能互换，也不能将EpiX当成已经有界的矩。

## BC2　实际正支上的捕获身份与缺陷容量

令C0={v∈E:rho0(v)>0}。在此a>kappa+alpha0J≥kappa，故实际U=kappa。这一点使用原实际E，而不是只用任意正函数的形式。
因此
\[
 \int Y\,d\pi=\frac{\int K_0d\nu}{q}\le1,
 \qquad \int_{C_0}Y\,d\pi
 =\frac{\int_{C_0}U\,d\nu}{Dq}\le\frac{G_U}{Dq}.
 \tag{BC6}
\]
第一式用共同合法K0的FIRST容量；第二式进一步保同一capture。没有nu≤beta假设。

令L_v=kappa_v+alpha0J_v。C0上a(1−rho0)=L，故精确
\[
 \boxed{a\rho_0(1-\rho_0)=L\rho_0
       =(\kappa+\alpha_0J)\rho_0\quad\text{于 }C_0.}
 \tag{BC7}
\]
积分得到可保相关的实际容量
\[
 \begin{split}
 \mathcal C_{def}
 &:={\int}_{C_0}a\rho_0(1-\rho_0)\,d\nu\\
 &=Dq\int_{C_0}\rho_0\,d\pi
   +\int_{C_0}U\rho_0\,d\nu\\
 &\le Dq\pi(C_0)+\int_{C_0}U\,d\nu
 \le Dq+G_U=2Dq-\alpha Q\le2Dq.
 \end{split}\tag{BC8}
\]
其两个正项是同一来源的J成本和真实已捕获成本，不能逐target/ancestor/cut各领一份。alpha0固定由全Q生成，既未自由选alpha，也未独立优化X/Y。

该容量只控制rho0(1−rho0)，不控制a rho0本身。仅使用这些标量来源条件时，1+G_U/(Dq)常数一般不能统一改善：在辅助一原子模型nu=J=q=D=1、kappa=g∈[0,1]、E全域、a=A>1+g中，Q=1、G_U=g、alpha0=1、rho0=1−(1+g)/A，BC8精确值为(1+g)rho0，A→∞趋1+g。此为扩展字段可行域的sharp性，不是原空间核/FIRST/history可实现性声明；不据此声称实际EpiX可任意独立变化。

## BC3　原剩余signed量的一项可付款中间份

固定0<eta<1，沿原来源积分及辅助time预先共同，置
Ceta={v∈C0:rho0(v)≤1−eta}，Chigh=C0\Ceta。原正泛函对rho线性，所有真实gate保持，故
\[
 P_{rem}(\rho_0)-N_{avail}
 =P_{rem}(\rho_0 1_{C_{high}})-N_{avail}
  +P_{rem}(\rho_0 1_{C_\eta}).
 \tag{BC9}
\]
负余额全留第一项一次；没有新分区重算good/bad、capture或history。

对中间份，从同一原双Pi积分先用bad概率≤1、D+≤k_t(v)、et≥eg，再扩大非负far到[τ,h]，物理FTC给
\[
 \begin{split}
 R_\eta&\le\frac1{\mathsf T e_g}\int_{C_\eta}a\rho_0\,d\nu\\
 &\le\frac{\mathcal C_{def}}{\eta\mathsf T e_g}
 \le\frac{Dq+G_U}{\eta\mathsf T e_g}
 \le\frac{2D}{\eta\sqrt\ell}.
 \end{split}\tag{BC10}
\]
最后只对保原heavy Teg>sqrtell q的实际行成立。没有把pi代入Pi，也没有先独立估计1/a时间。

保R211原2Lambda完整外测度及Tsmall≤4X，得到该明确片的实际费用
\[
 \Delta Raw_\eta\le\frac{16\Lambda D}{\eta\sqrt\ell}X.
 \tag{BC11}
\]
这不是免费误差：若要将其吸入新epsilon_eta槽，需要在构造前预选epsilon_RC≤eta epsilon_eta/2；R211原恢复槽不能重复使用。D=1小维回退的行密度上界为2/eta而不是1，有限维母核价格也须带该倍数。可按R211相同两支法补为显式有限C(epsilon_eta,eta)sqrt n WA；本文不重复那段母核证明，不把系数放大漏掉。若旧参数不满足预分配，只保BC11实际价格。

更简短的稳定性陈述是：对该实际time-weighted正交通，rho0≤1−eta的部分受BC10控制；因此尚未由该价结算的大baseline必须来自rho0接近1的目标。没有从BC8反推其总体交通必小。

## BC4　可付换权仅为容量的校验，不作为主要闭合成果

同一真实背景中，rho0−rho0²=rho0(1−rho0)，其恢复FTC至多Cdef/(Teg)。因而rho0→rho0²有价，但较小权的原signed基线仍在，不称一般付款改善已闭合。

同理，对一个预选共同lambda≥1，令rho_lambda=(1−lambda L/a)+于同E，则
\[
 a(\rho_0-\rho_\lambda)
 =\min\{(a-L)_+,(\lambda-1)L\}
 \le(\lambda-1)L1_{C_0},
\]
\[
 \int a(\rho_0-\rho_\lambda)d\nu
 \le(\lambda-1)(Dq+G_U).
 \tag{BC12}
\]
lambda1零差先处置；一般lambda须共同预选或保其实际来源权，不得逐slot优化后不付其选择。它确实加强支持到a>lambda L，但只是沿已证FTC/heavy机制的有价换权，不能迭代免费复用误差额度，也不作为本轮主要结果。实际新困难仍是近单位残余的来源/时钟/receiver几何。

## BC5　接近单位残余与真实clock/score的非独立关系

以下在C0中对原后验有效的正时钟槽成立；wg0而Pi恒零的来源先隔离。定义实际累计score
\[
 \mathcal L_v=\int_\tau^h k_t(v)\,dt/t
 =\log\frac{w_\tau(v)}{w_h(v)}\ge0.
\]
物理loss给精确联合式
\[
 a_v=\mathsf T w_h(v)(e^{\mathcal L_v}-1),\qquad
 \boxed{1-\rho_0(v)=
 \frac{\kappa_v+\alpha_0J_v}
 {\mathsf T w_h(v)(e^{\mathcal L_v}-1)}.}
 \tag{BC13}
\]
rho0≥1−eta必须同时满足
\[
 \mathcal L_v\ge
 \log\left(1+\frac{\kappa_v+\alpha_0J_v}
 {\eta\mathsf T w_h(v)}\right).
 \tag{BC14}
\]
不能将分子J与loss、终端w或score独立取极值。

对任意τ≤t≤h，k_r(v)非减且≤n，故
\[
 \frac{w_\tau(v)}{w_t(v)}\le(t/\tau)^{k_t(v)},\qquad
 \frac{w_h(v)}{w_t(v)}\ge(t/h)^n.

\]
因此实际点态
\[
 \frac{\Delta_v}{w_t(v)}
 \le(t/\tau)^{k_t(v)}-(t/h)^n.
 \tag{BC15}
\]
特别，rho0≥1−eta且k_t(v)≤m（0≤m≤n整数）强制
\[
 \frac{\kappa_v+\alpha_0J_v}{w_t(v)}
 \le\eta\mathsf T[(t/\tau)^m-(t/h)^n],
\]
\[
 \boxed{\frac{J_v}{w_t(v)}
 \le\frac{\eta\mathsf TQ}{Dq}
 [(t/\tau)^m-(t/h)^n].}
 \tag{BC16}
\]
可保前式的非负kappa项得到更强必要条件。右端为零而J>0时该交集为空，不能将空支的零比值继续使用。n、clock比值和来源实际likelihood全部保留；没有坐标独立假设。

若某个已核互反子域另有wg(u)>kappa_R∈(0,1)，则t<g时
\[
 k_t(u)\log(g/t)\le\int_t^gk_r(u)dr/r
 \le\log(1/w_g(u))<\log(1/\kappa_R).
 \tag{BC17}
\]
所以bad score有真实整数上界，可代入BC16分析同一时刻的反向信用支持。这里必须真正具有该terminal下界；若某互反合同只给别的比值，不可冒充BC17。本稿没有用该条件替换原bad槽，也不假来源排序。

## BC6　第一处尚缺的是低likelihood的后验列，而非pi矩

在原存活支上准确换权为
\[
 \pi(dv)=\frac{e_tJ_v}{Qw_t(v)}\Pi_t(dv),\quad
 \Pi_t(dv)=\frac{Qw_t(v)}{e_tJ_v}\pi(dv),
\]
\[
 \int_{Z_t}\frac{J_v}{w_t(v)}\Pi_t(dv)
 =\frac{Q}{e_t}\pi(Z_t)\le Q/e_t.
 \tag{BC18}
\]
因此已有的J来源容量只对较大的J/w_t尾给Markov方向的上界。BC16推到的是小J/w_t尾，RN反而含w_t/J；不能由BC18或pi质量≤1得到其Pi质量上界。eg、原实际outer py/hard source、window/j/selector及negative score池也都仍在。需要真实空间核与同来源占用控制这一低likelihood区域，不能以一个未知pi矩或新的归一概率将它删去。

原negative balance对k_t(v)−k_t(u)的符号仍由同一Pi和真实门决定；BC6/8不强制capture蕴含score排序。所有low/high残余切片均在同一原正泛函中作系数拆分，剩余negative只留未付部分一次。BC13--18提供可回代的共同clock限制，不是已付的新source列或所有far交通的闭合。

## BC7　最小三阶段Fraction核验方案与范围

建议复用一个完整两source条件clock家族，m=1、2、16各一例，不作空间quad：n1,τ1,h3/2,g2,Tcap1/2；nu=(m,m)，阈值(1,2)，G=E={v},B={u},Z固定、无删除。取D1,q1/6，J=kappa=(1/(24m),1/(24m))。直接重算
\[
 a=(1/6,0),\ Q=1/12,\ G_U=1/24,\alpha=3/2,
 \alpha_0=2,\ e_g=3m/2,
\]
\[
 \pi=(1/2,1/2),\ X=(2m,0),\ Y=(1/2,1/2),\
 \rho_0(v)=1-3/(4m),\qquad\rho_0(u)=0.
 \tag{BC19}
\]
piY=1/2，EpiX=m，scalar heavy Teg=3m/4>q。实际score差D=1，无reverse，Pi_vPi_u/t=1/(1+t)^2，pair核积分恰1/10。全baseline正交通为rho0(v)/10；缺陷容量精确为rho0(v)/8，等于BC8的两个相关项之和，且≤Dq+GU=5/24。eta1/2的中间片只含m1目标；m2、m16进入高rho余域。

应分别用端点clock、普通t有理积分、pi归一与原Pi直接算法核验，测试a_u0/Q0辅助支不除零；可在τ/t/h三点核BC15--16，明确完整a不是自由赋值。若补给定current字段pv=pplusv=7/(48m)、pu=pplusu=1/(48m)，则两个current容量均=q；outer py=2/(9m)、K1、Sv=1/(3m)使标量high/good等号成立。但这些值尚非同一空间phi/K0/current核实现，不授原history、互反、FA或FULL资格。

本方案用于检查相关容量、Pi/pi换权方向、clock和反向信用保留；m增大时EpiX不受此标量合同统一限制，而baseline pairflux趋1/10，说明不能从这些source矩自动推消失交通。它不是原中心立方体反例，不否认额外真实空间约束可能支付该区域。数值只按实际执行记载；制定方案不预报运行通过。

结论：BC8为实际same-source缺陷容量，BC9--11给明确中间残余片的有条件receiver付款；BC13--18准确连接高残余、真实score和原Pi所见likelihood。尚无低likelihood occupation的全局价，未证明高rho余域、负项耦合及一般目标已闭合。
