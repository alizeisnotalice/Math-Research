# R212 高alpha0基线的全局极值几何

目标仍是任意正L1输入的一般中心立方体 n^(1/2+o(1)) 一致弱型上界。R211已独审并推送，其冻结材料在 /Users/zhengzhihao/Desktop/T/output/centered_cube_round211_20261016_final_checkpoint/。

准确剩余：R128 RT2同一实际remaining far域、原全部Hrem/Ψ/FA/high/history/selector、完整后验Pi_t、硬源z与真实dx不动。原负余额N_avail仅归baseline一次。由R211 JC28–30可将rho替换为rho0=(1−D K0/a−Dq J/(Q a))_+，a=T(w_tau−w_h)，Q=int Jnu，T=cj^(n/2)/(g^n sqrtell)。已有恢复价εrec X+Crec sqrt n WA；其额度不能重复领。原heavy Teg>sqrtell q，Q<=q、int K0nu<=q，D为原εRC预定公式。零a/Q/eg、空far先处理。

本轮要证明该baseline带原剩余负项的全局预算，或形成真正改变其付款条件的新几何估计；不得以重复归约、特殊固定尺度或新命名未知余项冒充闭合。精确正支a>D[K0+(q/Q)J]。允许工具R211已核FTC/heavy、R209有利/负交通账、R181真实核及共同父支配；引用旧稿必须核实际条件。不得nu<=beta、独立来源、自由receiver核、重新选择门、重复负信用。

分工：Astra baseline_geometry.md，唯一核心路线为该高阈值正支的真实receiver/source几何及signed预算；Sol baseline_coupling.md，保同一Jnu/Q归一、比值/零支/联合来源的可证明极值与原门耦合，不与Astra重复空间推导；Sol audit.md先独筛准确命题及常数/量词，再读证明；Sol medium数值在明确公式形成后实施。主代理normalized_ledger.md、report/TeX/driver及整合。所有人只改责任文件，不Git/编译/新建agent；不是独自编辑，不动他人文件，交付后停止。

技能：A01齐次归一化与分式规划用于正分母/原可行域/共同缩放纪律；本轮暂不外引CCT/SOS定理，更不能借技能名认证一般估计。必要的准确文献工具须实际读原来源并逐条件核验。

数值三阶段：初步探索、已有压力参数、扩大范围。所有证据仅用实际本机运行；模型若没有原FIRST/history等资格必须明说，不猜维数阶。每轮结束精简归档、全文独审、复现后单独commit并push，未结束不提交草稿。
