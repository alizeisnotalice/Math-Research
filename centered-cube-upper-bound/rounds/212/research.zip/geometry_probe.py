#!/usr/bin/env python3
"""Finite physical kernel likelihood/clock geometry diagnostics, no FULL claim."""
import argparse,hashlib,json,math
from pathlib import Path
import numpy as np
import mpmath as mp
HERE=Path(__file__).resolve().parent
N=12000
LOG_GATE_BAND=.001
TOTAL_PROBABILITY_TESTS=20*3*2*2*3
HOEFFDING_EPS=math.sqrt(math.log(2*TOTAL_PROBABILITY_TESTS/.01)/(2*N))

def phi_mp(r):
    r=abs(mp.mpf(r));h=mp.mpf('.5')
    return 1-mp.expint(3,h-r)-mp.expint(3,h+r) if r<=h else mp.expint(3,r-h)-mp.expint(3,r+h)

def c_mp(d):
    d=abs(mp.mpf(d))
    return 1-d+mp.mpf(1)/3-mp.expint(4,1)-mp.expint(4,d)+mp.expint(4,d+1) if d<=1 else mp.expint(4,d-1)-2*mp.expint(4,d)+mp.expint(4,d+1)

def grid(maxr,count):
    core=.25*(1-np.cos(np.linspace(0,math.pi,count+1)))
    outside=.5+(maxr-.5)*np.linspace(0,1,2*count+1)**2
    radii=np.unique(np.concatenate([core,outside]));radii[-1]=maxr
    with mp.workdps(25): values=np.array([float(mp.log(phi_mp(float(r)))) for r in radii])
    return radii,values

def logphi(x,table):
    return np.interp(np.abs(x),table[0],table[1])

def logp(x,s,table):
    lp=logphi(x,table)+math.log(s)
    return np.where(np.abs(x)<=.5,np.logaddexp(math.log1p(-s),lp),lp)

def pairs(n):
    a=np.full(n,.25); b=np.full(n,.75)
    out=[('aligned',a,b)]
    if n>1:
        far=a.copy();far[0]=2.
        u=a.copy();v=a.copy();v[0]=.75;u[1]=.75
        out += [('one_far_coordinate',a,far),('swapped_coordinates',v,u)]
    return out

def metrics(lv,lu,delta,pairweight):
    out=[]
    for kval in (1,64):
        threshold=-math.log(kval)
        for label,va,ub,score in [('v_good_u_bad',lv,lu,delta),('u_good_v_bad',lu,lv,-delta)]:
            mask=(va>=threshold)&(ub<threshold)
            probability=float(np.mean(mask));weighted=probability*pairweight
            inner=(va>=threshold+LOG_GATE_BAND)&(ub<threshold-LOG_GATE_BAND)
            outer=(va>=threshold-LOG_GATE_BAND)&(ub<threshold+LOG_GATE_BAND)
            assert np.all(~inner|mask) and np.all(~mask|outer)
            lower_count=int(np.sum(inner));upper_count=int(np.sum(outer))
            point_ci=[max(0.,probability-HOEFFDING_EPS),min(1.,probability+HOEFFDING_EPS)]
            band_ci=[max(0.,lower_count/N-HOEFFDING_EPS),min(1.,upper_count/N+HOEFFDING_EPS)]
            out.append({'K':kval,'K_is_diagnostic':True,'orientation':label,'gate_count':int(np.sum(mask)),
                'empirical_p_y_dx_gate_mass':probability,'integer_score_difference':score,
                'simultaneous_99pct_Hoeffding_fixed_approximate_gate_interval':point_ci,
                'critical_band_inner_count':lower_count,'critical_band_outer_count':upper_count,
                'sampling_interval_with_empirical_numeric_band':band_ci,
                'positive_traffic_sampling_interval_with_empirical_numeric_band':[z*pairweight*max(score,0) for z in band_ci],
                'negative_traffic_sampling_interval_with_empirical_numeric_band':[z*pairweight*max(-score,0) for z in band_ci],
                'posterior_pair_weight':pairweight,'empirical_positive_traffic_density_dlogt':weighted*max(score,0),
                'empirical_negative_traffic_density_dlogt':weighted*max(-score,0),
                'gate_conditional_logratio_good_mean':float(np.mean(va[mask])) if np.any(mask) else None,
                'gate_conditional_logratio_bad_mean':float(np.mean(ub[mask])) if np.any(mask) else None})
    return out

def run():
    # phi sample: hard with probability 1-s; otherwise H+Laplace(sqrt(U)).
    setups=[(1,.75,'initial'),(4,.25,'stress'),(16,.25,'expanded'),(16,.75,'expanded')]
    data=[];maximum=.5
    for n,s,stage in setups:
        for repeat in (0,1):
            seed=2026101600+100*n+int(s*100)+repeat
            rng=np.random.Generator(np.random.PCG64(seed))
            x=rng.uniform(-.5,.5,size=(N,n))
            choose=rng.random(size=(N,n))<s
            x += choose*rng.laplace(0,np.sqrt(rng.random(size=(N,n))),size=(N,n))
            maximum=max(maximum,float(np.max(np.abs(x)))+2)
            data.append((n,s,stage,repeat,seed,x))
    observed_maximum=maximum
    maximum=32.
    assert observed_maximum<maximum
    coarse=grid(maximum,512);fine=grid(maximum,1024)
    controls=[]
    with mp.workdps(40):
        for r in (mp.mpf('0'),mp.mpf('.25'),mp.mpf('.5'),mp.mpf('2')):
            if r<=.5:
                independent=mp.quad(lambda t:t*(2-mp.exp(-(.5-r)/t)-mp.exp(-(.5+r)/t)),[0,1])
            else:
                independent=mp.quad(lambda t:t*(mp.exp(-(r-.5)/t)-mp.exp(-(r+.5)/t)),[0,1])
            controls.append({'kind':'phi_E3_vs_direct_scale_mixture','r':str(r),'closed':str(phi_mp(r)),'direct':str(independent),'absolute_difference':str(abs(phi_mp(r)-independent))})
        for d in (mp.mpf('0'),mp.mpf('.25'),mp.mpf('.75'),mp.mpf('2')):
            lo=d-.5;hi=d+.5
            cuts=sorted(set([lo,hi]+[z for z in [-mp.mpf('.5'),mp.mpf('.5'),mp.mpf('0')] if lo<z<hi]))
            independent=mp.quad(lambda t:mp.mpf(1) if abs(t)<=.5 else phi_mp(t),cuts)
            controls.append({'kind':'C_E4_vs_direct_h_max_h_phi','d':str(d),'closed':str(c_mp(d)),'direct':str(independent),'absolute_difference':str(abs(c_mp(d)-independent))})
    samplepoints=np.concatenate([np.abs(item[-1]).ravel()[::max(1,item[-1].size//12)] for item in data])[:96]
    checks=[]
    with mp.workdps(40):
        for r in np.concatenate([samplepoints,[0,.5,maximum,.5-1e-7,.5+1e-7]]):
            exact=float(mp.log(phi_mp(float(r))))
            checks.append({'r':float(r),'coarse_logphi_error':abs(float(np.interp(r,*coarse))-exact),'fine_logphi_error':abs(float(np.interp(r,*fine))-exact)})
    rows=[];sampling=[]
    for n,s,stage,repeat,seed,x in data:
        sampling.append({'n':n,'s':s,'repeat':repeat,'seed':seed,'sample_sha256':hashlib.sha256(np.asarray(x,dtype='<f8').tobytes()).hexdigest(),
            'sample_coordinate_mean':float(np.mean(x)),'sample_coordinate_second_moment':float(np.mean(x*x)),
            'theoretical_coordinate_second_moment':float((1-s)/12+s*13/12),'strictsoft_holds':s>1-2**(-1/n)})
        py=np.sum(logp(x,s,coarse),axis=1)
        for structure,v,u in pairs(n):
            with mp.workdps(40):
                cvs=np.array([float(c_mp(float(z))) for z in v]);cus=np.array([float(c_mp(float(z))) for z in u])
            logwg_v=float(np.sum(np.log(cvs)));logwg_u=float(np.sum(np.log(cus)))
            jv=np.sum(logphi(x-v,coarse),axis=1);ju=np.sum(logphi(x-u,coarse),axis=1)
            pv=np.sum(logp(x-v,s,coarse),axis=1);pu=np.sum(logp(x-u,s,coarse),axis=1)
            qv=np.logaddexp(math.log(2)+pv,jv)-math.log(3);qu=np.logaddexp(math.log(2)+pu,ju)-math.log(3)
            lv=qv-py-logwg_v;lu=qu-py-logwg_u
            small=x[::47]
            fpy=np.sum(logp(small,s,fine),axis=1)
            fq=[]
            for target,logwg in ((v,logwg_v),(u,logwg_u)):
                sj=np.sum(logphi(small-target,fine),axis=1);sp=np.sum(logp(small-target,s,fine),axis=1)
                fq.append(np.logaddexp(math.log(2)+sp,sj)-math.log(3)-fpy-logwg)
            sensitivity=max(float(np.max(np.abs(fq[0]-lv[::47]))),float(np.max(np.abs(fq[1]-lu[::47]))))
            gate_sensitivity=[]
            for kval in (1,64):
                th=-math.log(kval)
                for label,cv,cu,fv,fu in [('v_good_u_bad',lv[::47],lu[::47],fq[0],fq[1]),('u_good_v_bad',lu[::47],lv[::47],fq[1],fq[0])]:
                    gate_sensitivity.append({'K':kval,'orientation':label,'sample_count':len(small),'gate_classification_changes':int(np.sum(((cv>=th)&(cu<th))!=((fv>=th)&(fu<th))))})
            clocks=[]
            for t in (.5,.75,1.):
                kv=int(np.sum(cvs<t));ku=int(np.sum(cus<t))
                wv=float(np.prod(np.minimum(1,cvs/t)));wu=float(np.prod(np.minimum(1,cus/t)))
                pi=wv/(wv+wu)
                clocks.append({'t':t,'evaluation_scope':'strict interior score diagnostic; t=1 is terminal only, not far integral','k_v':kv,'k_u':ku,'right_trace_k_v':int(np.sum(cvs<=t)),'right_trace_k_u':int(np.sum(cus<=t)),'minimum_numeric_distance_C_to_t':float(min(np.min(np.abs(cvs-t)),np.min(np.abs(cus-t)))),'w_v':wv,'w_u':wu,'e_t':wv+wu,'Pi_v':pi,'Pi_u':1-pi,
                    'observables':metrics(lv,lu,kv-ku,pi*(1-pi))})
            rows.append({'stage':stage,'n':n,'s':s,'repeat':repeat,'structure':structure,'v':v.tolist(),'u':u.tolist(),'nu':[1,1],
                'C_v':cvs.tolist(),'C_u':cus.tolist(),'log_wg_v':logwg_v,'log_wg_u':logwg_u,
                'logratio_v_quantiles':np.quantile(lv,[0,.01,.5,.99,1]).tolist(),'logratio_u_quantiles':np.quantile(lu,[0,.01,.5,.99,1]).tolist(),
                'selected_256_or_fewer_grid_sensitivity_max_logratio':sensitivity,'selected_grid_gate_sensitivity':gate_sensitivity,'clocks':clocks})
    return {'schema':'R212_physical_pair_geometry_MC_v1','inputs':{'task_contract.md':hashlib.sha256((HERE/'task_contract.md').read_bytes()).hexdigest()},
        'dependencies':{'numpy_version':np.__version__,'mpmath_version':mp.__version__,'numpy_entry_sha256':hashlib.sha256(Path(np.__file__).read_bytes()).hexdigest(),'mpmath_entry_sha256':hashlib.sha256(Path(mp.__file__).read_bytes()).hexdigest()},'samples_per_setup_seed':N,'repeat_seeds':2,'case_count':len(rows),
        'kernel_controls':controls,'interpolation':{'coarse_core_intervals':512,'coarse_outer_intervals':1024,'fine_core_intervals':1024,'fine_outer_intervals':2048,
          'maximum_covered_radius':maximum,'observed_maximum_radius_plus_shift_margin':observed_maximum,'table_endpoint_fixed_before_sampling':True,'table_dps':25,'independent_validation_dps':40,'max_coarse_logphi_error':max(z['coarse_logphi_error'] for z in checks),'max_fine_logphi_error':max(z['fine_logphi_error'] for z in checks),'validation':checks},
        'source_sampling':sampling,'cases':rows,'scope':['Physical p_s product receiver sampling with actual phi/C/source offsets; fixed two-source conditional posterior nu=(1,1) fully normalized.',
        'K=1 and K=64 are diagnostic gates; no original permitted K, alpha, high/FIRST/history or full physical common input is certified.',
        'Empirical masses integrate p_y(x) dx by sampling; no receiver grid volume or one-dimensional-curve surrogate.',
        'Scores count C<t; right traces count C<=t separately. C values are 40dps evaluations converted to float, not interval comparisons; no sampled clock threshold is coincident. Terminal t=1 does not stand for far h<g.',
        'Reported traffic is the instantaneous dlogt density, not an integrated time flux. Pair posterior is only this complete two-source conditional model.',
        'Finite interpolation checks do not certify exact physical gates. Simultaneous sampling intervals apply only to the predeclared fixed approximate gates; zero observed events do not establish empty domains.'],
        'statistical_certification_for_exact_physical_gate':False,
        'sampling_uncertainty':{'scope':'Simultaneous 99pct Hoeffding for fixed approximate point/inner/outer gate functions; table radius32 and band .001 fixed before sample. Transfer to exact physical gates is not certified without a rigorous interpolation bound.',
            'total_tests_Bonferroni':TOTAL_PROBABILITY_TESTS,'family_failure_probability':.01,'probability_half_width':HOEFFDING_EPS,'predeclared_log_gate_band_width':LOG_GATE_BAND}}

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=HERE/'geometry_probe.json');args=ap.parse_args()
    result=run();args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
    print(json.dumps({'case_count':result['case_count'],'max_logphi_validation_error':result['interpolation']['max_coarse_logphi_error']},sort_keys=True))
