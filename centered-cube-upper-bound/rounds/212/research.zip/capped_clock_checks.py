#!/usr/bin/env python3
"""Finite Fraction certificates for capped min-product clock loss."""
import argparse,hashlib,json
from fractions import Fraction as F
from pathlib import Path
HERE=Path(__file__).resolve().parent
Z=F(0)
def w(c,t):
    value=F(1)
    for x in c:value*=min(F(1),x/t)
    return value

def clock_case(name,stage,c,l,r,star=None,h=None):
    assert 0<l<r and all(x>0 for x in c)
    h=w(c,star) if h is None else h
    assert h>0
    cuts=sorted(set([l,r]+[x for x in c if l<x<r]+([star] if star is not None and l<star<r else [])))
    total=Z;segments=[]
    for a,b in zip(cuts,cuts[1:]):
        mid=(a+b)/2;active=[x for x in c if x<mid];k=len(active)
        prod=F(1)
        for x in active:prod*=x
        assert w(c,mid)==prod/mid**k
        # Threshold roots are included in cuts; prove each open segment has a constant gate.
        inside=w(c,mid)<=h
        if inside:assert w(c,a)<=h
        else:assert w(c,b)>=h
        # Integrate k*prod*t^(-k-1), not the capped endpoint expression.
        integral=prod*(a**(-k)-b**(-k)) if inside and k else Z
        assert integral>=0
        total+=integral
        segments.append({'left':a,'right':b,'k':k,'active_product':prod,'cap_gate_interior':inside,'integral':integral})
    endpoint=max(Z,min(w(c,l),h)-w(c,r))
    assert total==endpoint
    return {'name':name,'stage':stage,'n':len(c),'C':c,'l':l,'r':r,'H':h,'specified_rational_crossing':star,
            'w_l':w(c,l),'w_r':w(c,r),'segments':segments,'direct_piecewise_integral':total,'capped_endpoint_loss':endpoint,'passed':True}

def pair_case(c):
    # Full two-source clock, both masses1; u clock1 throughout [l,g].
    l=F(1,2);r=F(3,4);g=F(1);star=F(5,8)
    v=[c];u=[F(1)];h=w(v,star);eg=w(v,g)+w(u,g)
    assert c<=l and r<=1
    # Pi_v Pi_u dt/t = c/(t+c)^2 dt; cap restricts t>=star.
    actual=c/(star+c)-c/(r+c)
    loss=clock_case('pair_target_loss','pair',[c],l,r,star)['direct_piecewise_integral']
    bound=loss/eg
    assert actual>=0 and actual<=bound
    probes=[]
    for t in (star,(star+r)/2,r):
        wv=w(v,t);wu=w(u,t);e=wv+wu;pv=wv/e;pu=wu/e
        assert pv+pu==1 and pv*pu/t==c/(t+c)**2
        probes.append({'t':t,'e':e,'Pi_v':pv,'Pi_u':pu,'positive_flux_density_dt':pv*pu/t})
    return {'nu':[F(1),F(1)],'v_C':v,'u_C':u,'l':l,'r':r,'g':g,'H':h,'cap_start':star,'e_g':eg,
            'exact_full_two_Pi_positive_flux':actual,'capped_clock_loss':loss,'loss_over_e_g':bound,'posterior_controls':probes,'passed':True,
            'scope':'Complete stated two-source conditional clock model; no original geometry/high/history/FIRST input.'}

def encode(x):
    if isinstance(x,F):return str(x)
    if isinstance(x,dict):return {k:encode(v) for k,v in x.items()}
    if isinstance(x,list):return [encode(v) for v in x]
    return x

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=HERE/'capped_clock_checks.json');args=ap.parse_args()
    cases=[clock_case('one_crossing','initial',[F(1,4)],F(1,2),F(1),F(3,4)),
           clock_case('cap_above_initial','initial',[F(1,4)],F(1,2),F(1),h=F(2)),
           clock_case('cap_at_terminal_zero','initial',[F(1,4)],F(1,2),F(1),F(1)),
           clock_case('two_thresholds','stress',[F(1,3),F(2,3)],F(1,4),F(1),F(3,4)),
           clock_case('initial_platform_H_one','stress',[F(3,4),F(3,4)],F(1,2),F(1),h=F(1)),
           clock_case('cap_below_terminal_zero','stress',[F(1,4),F(1,2)],F(1,2),F(1),F(2)),
           clock_case('eight_repeated_thresholds','expanded',[F(i,10) for i in range(1,9)],F(1,2),F(1),F(7,8)),
           clock_case('sixteen_mixed','expanded',[F(1,2),F(3,4),F(1),F(1,64)]*4,F(1,2),F(1),F(5,8)),
           clock_case('sixtyfour_dynamic_range','expanded',[F(1,2**(i%12+1)) for i in range(64)],F(1,2),F(1),F(3,4))]
    pairs=[pair_case(F(1,2)),pair_case(F(1,4))]
    result={'schema':'R212-capped-clock-Fraction-v1','inputs':{'task_contract.md':hashlib.sha256((HERE/'task_contract.md').read_bytes()).hexdigest()},
            'counts':{'clock_cases':len(cases),'full_two_source_cases':len(pairs)},'clock_cases':cases,'full_two_source_cases':pairs,
            'scope':'Finite positive min-product clocks; exact rational crossing roots. Independent piecewise derivative integral vs capped endpoint identity. No FULL geometry or general theorem certification.',
            'threshold_convention':'k counts C<t; equality and cap platforms carry zero derivative or measure-zero endpoints. No endpoint jump atoms.',
            'all_passed':True}
    args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_text(json.dumps(encode(result),sort_keys=True,indent=2)+'\n')
    print(json.dumps(result['counts'],sort_keys=True)+' PASS')
if __name__=='__main__':main()
