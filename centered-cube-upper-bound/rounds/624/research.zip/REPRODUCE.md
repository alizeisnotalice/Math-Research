# R624 reproduction notes

## Environment and commands

Recorded environment: Python 3.12.14, macOS 27.2 arm64; NumPy 2.5.4 and SciPy 1.18.1 for the numeric script. The exact certificate uses Python `Fraction`; the root-side constant check used `python_flint` 0.9.0 / Arb at 192-bit precision.

From an extracted archive directory, these commands reproduce the final checks. Keep a copy of the archive receipts before rerunning, since the scripts write their sibling JSON files.

```sh
PY=/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python
"$PY" ccu_r624_numeric.py --case 0 --output-dir replay
"$PY" ccu_r624_certificate.py
"$PY" ccu_r624_cone.py --level 6 --workers 4
"$PY" verify.py
```

For the cone integration CLI, levels 0–6 and workers 1–14 are available. The portable script reads/writes sibling files. The final recorded run used level 6, 4 workers, 64 subdivisions, and took 0.5101 s wall time. Four workers are the recommended reproduction setting under the conservative memory budget. The recorded sum of worker peak RSS values (472,956,928 bytes) is a sum of separate peaks, not measured simultaneous RSS. An older 14-worker version did not satisfy the conservative memory budget and is not a certification receipt; do not use its output as evidence. The final short run is a completed computation, not evidence of sustained machine-wide full load.

## Source changes and replay status

`PORTABILITY.json` records that certificate and cone changes were limited to sibling input/output paths. Their portable versions were actually rerun by the root agent. The certificate archive SHA is `541076ff…`; the cone archive SHA is `690140b4…`. The numeric result was initially not recomputed after its scope correction: its original SHA is `2eaef965…`, and the corrected archived source SHA is `dd5a054e…`. The correction removed unrelated R618 progressive-freeze fields; that edit did not itself recompute the finite family or LP. The root subsequently ran the corrected script in a separate replay directory; cubes, stars, exact receiver volume and the complete Qstar certificate matched the archived input exactly. This replay is recorded in CONVERGENCE.json. The input numeric receipt retains both its historical execution hash and corrected source hash. Exact full hashes are in `SOURCES.json`.

`ROOT_CHECK.json` records a 192-bit Arb check of the saved exact integral endpoints (including a certified positive max-first minus saturation endpoint difference for this finite family). The root agent also reran the portable certificate and cone scripts. This archival step ran no computation.

## What the finite evidence says

The example uses 84 actual two-dimensional receiver cubes, with Lebesgue union area (V=573/4), and an absolutely continuous rectangular source. The exact primal/dual certificate gives (Q^*=85), hence (V/Q^*=573/340). This ratio is **not** itself a weak-type lower bound. After making the original stars strictly bad by scaling the source and accounting for the larger centered cube needed to cover every receiver point, the certified weak-type lower ratio is only (191/255).

The cone run integrates over the complete continuous receiver union using exact rational outward bounds on a finite subdivision. It records bounds for (J_{min},J_{sat},J_{maxfirst},J_T); the resulting q quantities divide by (9\log 2). It is finite-family evidence, not a general theorem. The root-side 192-bit Arb intervals check the saved integral endpoints and comparisons; they do not extend the result beyond this input.

A prior saturation computation incorrectly used the global radius menu without requiring that the current receiver cube make each radius available. That computation and its interval are invalid and superseded. The corrected code checks both local availability and ρ≤S; the corrected `J_sat` interval overlaps `J_min`, so no strict saturation/minimum gain is certified. The exact root replay's positive comparison is between corrected saturation and max-first for this finite family only.

The saved certificate's (V/Q^*) and weak-ratio statements concern a real continuous receiver union and an absolutely continuous source, not a sampled or periodic point-source model. Conversely, these finite data do not prove the general weak-type theorem. The root also actually ran levels 2, 4 and 6 on the same finite family. All four exact integral intervals nest under refinement; this checks the numerical enclosure, not any dimensional extrapolation.

## Coarse-to-fine evidence and scope corrections

`CONVERGENCE.json` records actual subdivisions 4, 16 and 64 per coordinate within every receiver quarter-cell. The retained interval endpoints and source hashes permit exact nesting checks; all four intervals became nested. The corrected numeric-generator replay also matched the four mathematical fields listed there. These are three resolution levels of one family, not three dimensions or independent source models.

Audit corrections retained for future work:

- A source star A_j is not a receiver B_j. The implementation was corrected before a mathematical result from that mismatch was accepted; V=573/4 is an explicit invariant.
- The global radius menu is not the pointwise admissible menu. Only radii of original B_j containing the receiver are eligible. Earlier saturation endpoints from the unrestricted menu are invalid and are not archived as evidence.
- A ratio V/Q* for the finite packing contract is not automatically a maximal-operator weak lower bound. The automatically justified centered-radius enlargement costs P=9/4 in this example.
- A count of live workers is not sustained CPU use. The accepted four-worker integrations were short and below the conservative memory bound; no claim of full-load occupancy is made this round.

No MATLAB, SCIP, or PDF compilation was run for this round. The general far-scale proof used explicit analytic estimates and a recorded author-side SymPy identity check; finite cone certificates and Arb calculations do not prove the unresolved all-family fresh-source capacity bound.
