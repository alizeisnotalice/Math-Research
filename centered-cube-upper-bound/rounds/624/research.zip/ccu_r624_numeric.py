import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[k]='1'
import argparse,hashlib,json,math,platform,resource,shlex,sys,time,random
from pathlib import Path
from fractions import Fraction as F
import numpy as np,scipy
from scipy.optimize import linprog
A=2

def family(case):
 # Explicit finite families: four genuinely separated scales with interlocking source regions.
 configs=[[(0,0,8),(20,0,4),(10,18,2),(-15,8,1)],[(0,0,8),(16,0,4),(8,13,2),(-10,6,1)],[(0,0,8),(18,3,4),(9,15,2),(-13,7,1)]]
 cubes=[]
 for ox,oy,R in configs[case]:
  values=sorted(set([-2*R+1,-R,0,R,2*R-1]))
  for x in values:
   for y in values:cubes.append((R,ox+x,oy+y))
 return cubes

def receiver(cubes):
 a=np.asarray(cubes,np.int64);R=a[:,0];xy=a[:,1:];lo=(xy-R[:,None]).min(axis=0);hi=(xy+R[:,None]).max(axis=0);shape=tuple(hi-lo);ids=np.full(shape,-1,np.int32);Vcount=0;out={}
 for policy,order in [('r_max',np.argsort(-R,kind='stable')),('r_min',np.argsort(R,kind='stable'))]:
  own=ids.copy()
  for j in order:
   x,y=xy[j];r=R[j];block=own[x-r-lo[0]:x+r-lo[0],y-r-lo[1]:y+r-lo[1]];block[block<0]=j
  counts=np.bincount(own[own>=0],minlength=len(cubes));V=int(counts.sum());out[policy]=counts;Vcount=V
 assert sum(out['r_min'])==sum(out['r_max'])
 return Vcount,out

def arrangement(cubes):
 arr=np.array(cubes,np.int64);R=arr[:,0];xy=arr[:,1:];lo=xy-A*R[:,None];hi=xy+A*R[:,None];edges=[np.unique(np.r_[lo[:,k],hi[:,k]]) for k in (0,1)];low=np.stack([np.searchsorted(edges[k],lo[:,k]) for k in (0,1)],axis=1);high=np.stack([np.searchsorted(edges[k],hi[:,k]) for k in (0,1)],axis=1);shape=(len(edges[0]),len(edges[1]));return R,xy,lo,hi,edges,low,high,shape

def field(low,high,shape,w):
 z=np.zeros(shape,dtype=w.dtype);a,b=low[:,0],low[:,1];c,d=high[:,0],high[:,1];np.add.at(z,(a,b),w);np.add.at(z,(c,b),-w);np.add.at(z,(a,d),-w);np.add.at(z,(c,d),w);np.cumsum(z,axis=0,out=z);np.cumsum(z,axis=1,out=z);return z

def lp(R,xy,lo,hi,edges,low,high,shape):
 n=len(R);points=[];mp={};own=[]
 for z in xy:
  point=tuple(min(max(np.searchsorted(edges[k],z[k],side='right')-1,0),shape[k]-2) for k in (0,1))
  if point not in mp:mp[point]=len(points);points.append(point)
  own.append(mp[point])
 def incidence(pts):
  p=np.array(pts);return (low[:,0,None]<=p[None,:,0])&(p[None,:,0]<high[:,0,None])&(low[:,1,None]<=p[None,:,1])&(p[None,:,1]<high[:,1,None])
 volumes=(A*R/2)**2;iterations=0;sol=None
 while iterations<200:
  M=incidence(points);sol=linprog(np.ones(len(points)),A_ub=-M.astype(float),b_ub=-volumes,bounds=(0,None),method='highs');assert sol.success
  dual=np.maximum(-sol.ineqlin.marginals,0);v=field(low,high,shape,dual)[:-1,:-1];k=np.unravel_index(int(np.argmax(v)),v.shape);iterations+=1
  if v[k]<=1+1e-9:break
  k=tuple(map(int,k))
  if k in mp:break
  mp[k]=len(points);points.append(k)
 assert len(points)==len(sol.x);scale=1<<30;pr=np.ceil(np.maximum(sol.x,0)*scale).astype(np.int64);covered=M.astype(np.int64)@pr;ivol=np.rint(volumes*4).astype(int) # volumes may quarters; exact in 1/4 units.
 for i in range(n):
  lack=max(0,(int(ivol[i])*scale+3)//4-int(covered[i]))
  if lack:pr[own[i]]+=lack;covered+=M[:,own[i]].astype(np.int64)*lack
 assert np.all(4*covered>=ivol*scale)
 dq=1<<38;dy=np.floor(dual*dq).astype(np.int64);f=field(low,high,shape,dy);md=int(np.max(f[:-1,:-1]));dq=max(dq,md);L=sum((F(int(v)*int(d),4*dq) for v,d in zip(dy,ivol)),F());U=F(int(pr.sum()),scale)
 assert L<=U
 cells=[]
 for k in np.flatnonzero(pr):
  i,j=points[k];cells.append([str(F(int(edges[0][i]),4)),str(F(int(edges[0][i+1]),4)),str(F(int(edges[1][j]),4)),str(F(int(edges[1][j+1]),4)),str(F(int(pr[k]),scale))])
 return {'dual_lower':str(L),'primal_upper':str(U),'relative_gap':float((U-L)/U),'iterations':iterations,'patterns_used':len(points),'source_cells':cells,'dual_weights':[str(F(int(v),dq)) for v in dy],'pricing_cells':int((shape[0]-1)*(shape[1]-1))}

def packing(R,counts,low,high,shape,Vcells):
 weights=counts/(4*A*A*R.astype(float)**2);h=field(low,high,shape,weights);H=float(h[:-1,:-1].max());q=float(F(Vcells,16))/H
 return {'V_over_maxH':q,'max_H':H,'owner_cells_by_scale':{str(int(r)):int(sum(counts[R==r])) for r in sorted(set(R))},'numeric_note':'owner and areas integer exact; max load floating; no R624 cone saturation computed'}

def main():
 p=argparse.ArgumentParser();p.add_argument('--case',type=int,default=0,choices=(0,1,2));p.add_argument('--output-dir',type=Path,default=Path('/tmp'));a=p.parse_args();a.output_dir.mkdir(parents=True,exist_ok=True);t=time.monotonic();cpu=time.process_time();cubes=family(a.case);V,own=receiver(cubes);R,xy,lo,hi,edges,low,high,shape=arrangement(cubes);opt=lp(R,xy,lo,hi,edges,low,high,shape);rr={k:packing(R,v,low,high,shape,V) for k,v in own.items()};Qhi=F(opt['primal_upper']);Qlo=F(opt['dual_lower']);Vexact=F(V,16);threshold=Vexact>Qhi;stars=[[str(F(int(lo[i,0]),4)),str(F(int(hi[i,0]),4)),str(F(int(lo[i,1]),4)),str(F(int(hi[i,1]),4))] for i in range(len(R))]
 out={'case':a.case,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'command':shlex.join([sys.executable]+sys.argv),'python':sys.version,'numpy':np.__version__,'scipy':scipy.__version__,'platform':platform.platform(),'a':A,'n':2,'N':len(R),'receiver_V':str(Vexact),'cubes_quarter_units':cubes,'stars':stars,'Qstar':opt,'V_over_Qstar_certified_lower':str(Vexact/Qhi),'V_over_Qstar_certified_upper':str(Vexact/Qlo),'threshold_V_over_Q_gt_1_certified':threshold,'scale_ratio':str(F(max(R),min(R))),'owners':rr,'elapsed_seconds':time.monotonic()-t,'cpu_seconds':time.process_time()-cpu,'peak_rss_bytes_macos':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
 path=a.output_dir/'ccu_r624_numeric.json';path.write_text(json.dumps(out));L=['# R624 finite multiscale cube family diagnostic','','All coordinates are quarter-grid aligned; receiver area and owner assignments count whole positive-area cells. Source constraints cover every open-cell incidence of the original supplied stars; the source LP lower and upper bounds are explicit rational feasible dual and primal. Uniform owner-load maxima are floating point; the requested global cone saturation is not calculated here.','','| case | N | scale ratio | V | Q* interval | certified V/Q* lower | r_min q_uniform | r_max q_uniform |','|---:|---:|---:|---:|:---|---:|---:|---:|',f"| {a.case} | {len(R)} | {out['scale_ratio']} | {Vexact} | {opt['dual_lower']}–{opt['primal_upper']} | {float(Vexact/Qhi):.8g} | {rr['r_min']['V_over_maxH']:.8g} | {rr['r_max']['V_over_maxH']:.8g} |",'',f"N/a^n={len(R)/A**2:g}; owner cells per scale: min {rr['r_min']['owner_cells_by_scale']}, max {rr['r_max']['owner_cells_by_scale']}. Source cells and dual weights are in JSON. Finite example only; no dimension asymptotic conclusion."]
 (a.output_dir/'ccu_r624_numeric.md').write_text('\n'.join(L)+'\n');print(json.dumps({'case':a.case,'N':len(R),'V':str(Vexact),'Qlo':str(Qlo),'Qhi':str(Qhi),'V_over_Q':float(Vexact/Qhi),'owner_scales':{k:v['owner_cells_by_scale'] for k,v in rr.items()},'elapsed':out['elapsed_seconds'],'rss_mib':out['peak_rss_bytes_macos']/2**20}))
if __name__=='__main__':main()
