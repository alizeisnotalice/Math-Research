# R624 单cone充分目标：独立有界预审

日期：2026-10-28。先独立核父任务准确命题，不读R624作者新稿；只写本文件，不改repo、不启动Agent、重计算或实例扫描。以下给解析判断及可供作者使用的真实family约束。

## 1. 短判断与准确量词

对每个完整有限family选一次排列，再在其真实increments I_j上定义ρ=(a+1)r_j、E=∪B_j。选k约√n和可测F⊂E，令S_Fk为R623的完整d_k-majorant。已证原row packing给

Q*≥q=(C_nk P)^(−1)J(F)，
J(F)=∫_F(ρ/S_Fk)^n，C_nk≤2n/(k−1)，P=(1+1/a)^n。

若对所有有限family统一证明存在排列、k、F使J(F)≥V/L_n、L_n为polylog，则a≥n时P≤e、C_nk=O(√n)，确实得到根阶完整packing及一般L1全尺度入口。这里无额外Ccov，因为E本来就是全部supplied receiver。

但这是对一个具体cone构造的充分目标，比单纯Q*≥V/K_n更强；当前没有逆比较。单个cube上J(E)=V而cone q=V/(C_nkP)，完整Q*=a^nV，已说明cone不近似完整Q*的大小。该例不反对J的充分目标，只阻止将Q*的好值自动归于同一cone。允许“已付款，或在未付分支找好cone/共同repair”的机制更准确，不能强求所有容易family都以同一中间方式获益。

量词必须独立于N和半径跨度。a可按n选择，但须在处理任意family前固定；固定N再任意增a的容易现象不提供该统一目标。

## 2. 真实increments排除了任意字段的许多假障碍

按半径降序排列（同半径任意tie）时，准确有

ρ_desc(x)=(a+1)max_(j:x∈B_j)r_j，
{x∈E:ρ_desc(x)≥t}=∪_(r_j≥t/(a+1))B_j。

因此一个大row即使自身新increment很小，其整个B_j仍由不小于该半径的字段覆盖。不能拿任意指定的小体积高尖峰radius字段，当作这种真实降序family而不核整块B_j的实现。若大cube大部分已被更大cubes覆盖，这部分并未变成低ρ。

降序下F=E的envelope还有准确的whole-box表达式

S_desc(x)=max_j[ρ_j−dist_dk(x,B_j)]_+，
dist_dk(x,B_j)=d_k(w)，其中w_i=(|x_i−y_(j,i)|−r_j)_+。

这是由sup与有限max交换及coordinate-clamp最小距离得到，不是用centre seed代替整row。特别若S_desc(x)>tρ_desc(x)、t≥1，某个贡献row j必须不覆盖x、满足ρ_j>tρ_desc(x)，并有

dist_dk(x,B_j)<ρ_j−tρ_desc(x)。

这比完整正cone halo更精确：inflation来自更大但不实际覆盖x的rows及其scale-difference shadow。它是可使用的真实几何约束，尚没有给这些shadows的无重复体积/source收费。

一般排列的ρ≤ρ_desc点态成立，但S也随之变化；J的分子/分母一起变化，不能据此断言降序使J最优。小尺度先覆盖有时会使某大row的increment为零；任何排序比较均须保持其相应I_j、ρ、F和objective一致。

## 3. 已知family与无条件基线

若全部r_j同r，任何排列下ρ常数，F=E时S=ρ于E，故J=V。旧tensor C4属于同尺度情形，fixed-source分组障碍不构成本目标的障碍。R623的未裁剪周期max-selector诊断既未优化F，也未证明它等于某个重排后的真实increment字段，不能否定当前存在性命题。

更一般，r_j∈[r,R]时S_E≤(a+1)R，故

J(E)≥(r/R)^nV。

R/r≤exp(c/n)已给J≥e^(−c)V。这些容易带不是新推进。若把所有实际radius levels分成这种窄bands，选receiver体积最大的一带作为F，可得e^(−c)V/(band数)的基线；但band数可依赖n及log(Rmax/Rmin)，不能当polylog(n)常数。当前真正未付款的是空间上相互作用的跨band选择，而不是再验一个band。

## 4. 下一候选必须跨过的缺口

具体证明可以利用降序level-set/whole-box结构，或明确的共同交换，但至少须做到：

* 用真实全family而非任意外加radius字段；任何删除F都保留被删的实际receiver费用。
* 不将单point cone体积当whole I_j halo；top-k root load只付Jacobian，未付inflation。
* 不从Q*已大反推同一cone J已大；也不把粗模板C_nkH_k>2n误读为实际trim不可能。
* 若以旧packing共同repair推进，需原source全部cell的可行性与实际d_j移除成本，不能把receiver shadow体积直接当repair价格。
* 若先排除N/a^n、同尺度/窄band或其他显式已付分支，应写明剩余family条件；这种“已付或推进”不要求每个容易family都满足更强中间引理。

当前没有从已知原family约束推出J≥V/polylog，也没有已核反例否定该存在性目标。它是准确、有内容但仍很强的几何充分命题。上述whole-box/scale-difference约束可供作者使用；不能只重命名为exchange后宣称已获改善。

本轮仅作有界解析预审，无新数值或重算；等待作者候选后只核其是否支付这一跨band缺口。停止。

## 5. 作者稿后审：菜单饱和合法，但须区分排列与一般分区

本次新增只读核验`/tmp/ccu_r624_main.md`及`/tmp/ccu_r624_bridge.md`的分离尺度附录；无新计算、实例扫描或Agent。以下均为解析核验。桥稿前部的联合barrier不是本次要求新增独审的对象，不借本节给其额外证书。

以全部原B边界作有限arrangement，只保留正体积开cells，得到E_reg，且|E\E_reg|=0。按小半径及固定tie排序的min-owner确是一个真实排列产生的increment分区（去掉边界）。一个非essential row没有任何正体积min-owner cell；删除它作为生成菜单不改变m或E的a.e.覆盖。有限多个零体积分片不能合起来产生遗漏的正体积receiver。删除生成菜单不等于从原packing/source合同删除原row约束；后者在需要完整Q*及共同最小来源时仍须全部保留。

S_min由有限cell的距离函数取max，故连续、critical d_k-Lipschitz。开cell的距离可用closure计算，是实际内点的逼近；不能另给某零测边界任意较高菜单。ρ_sat=max{ρ_j:x∈B_j,ρ_j≤S_min(x)}可测且非空，m≤ρ_sat≤S_min。最小Lipschitz majorant的单调性及S_min自身的majorization严格给S_(ρ_sat)=S_min；因此作者(4)–(5)的同一分母下信用不减成立。

**范围区别：** 饱和owner以及后文最大essential owner一般只是可测P_j⊂B_j分区，尚无证明其由一个统一排列的真实increments产生。该扩展对原row packing完全合法：R623的包含关系只需x∈P_j⊂B_j，最终仍回填原A_j，所有P_j共同使用一个global envelope。它不能被直接表述为已证明本审计§1中“存在排列、k、F”的较窄充分目标。作者目前已明确允许一般partition，按这一扩展读法无数学错误。

## 6. Min-witness、T与全部原source的共同可行性

每个essential j有实际z_j∈C_j⊂B_j，故对每个x∈B_j，d_k(x−z_j)≤||x−z_j||∞<2r_j。于是S_min≥(a−1)r_j，作者(6)成立。取L=(a+1)/(a+3)，T=T_L/L=sup[(a+3)r_min−d_k]_+后，同一witness给

T(x)≥(a+3)r_j−2r_j=(a+1)r_j。

因此T确实支持覆盖receiver的全部剩余essential原rows。选最大essential菜单回填时，q_T=C_nk^(−1)∫(a r_max^ess/T)^n；在T≤(1+2/n)(a+3)r_max^ess上，q_T的密度至少e^(−2)/(C_nk P_3)，P_3=(1+3/a)^n≤e³。这里是同一个critical envelope，C_nk不额外改变。以上是可行packing及good域信用，不是整个E上inflation已获控制。

R623原row load估计对所有source位置共同成立；有限原开cubes上的正权load是下半连续函数，a.e.≤1还可提升为处处≤1。因此receiver arrangement的a.e.忽略不导致某个原source点另领预算。对有限L1来源，超平面边界本身亦零质量。F及其代表可依赖完整有限family乃至一次选定的共同来源，但一旦选定必须全局冻结；不可按被测试source位置更换F或owner。

若T的某个winning cell所属seed row j覆盖x，其height≤(a+3)r_max^ess(x)，不能造成上述bad域。bad点因此由r_j>(1+2/n)r_i且x∉B_j的远大seed造成；距离inf未在开cell内取得时，严格bad不等式允许实际内点逼近。此结论正确消除了覆盖同点的internal-menu跳跃，却没有支付远seed在多个receiver处的复用。

删除J_0的C_j后，只在F=E_reg\∪C_j重新生成T，剩余owner保证每个x∈F仍有剩余essential代表，每个保留row仍有真实min-witness。被删row不能继续作为该witness；可在另一独立饱和候选中使用它，但不能混用不同envelope的证明。窄band费用(11)的fractional packing来自不交C_j的几何体积，objective至少该band删除量/(Pe)；逐band收费得到|D_0|≤sPeQ*。与good域信用合并，作者(12)的分母e²C_nkP_3+sPe准确，无免费叠加不同band的source预算。

## 7. 同一个最小来源的增长结论及仍未付的复用

完整有限row系统可由全部原A_j的正体积source arrangement cells化为有限LP，原始最优来源可取各cell上常密L1函数，mass=Q*。作者这里确须选该完整系统的一次最小来源μ，而不是删row后或每个pair分别最优化。对h_i=μ(A_i)/d_i及任一上述远seed j，μ(A_j)/μ(A_i)≥(r_j/r_i)^n/h_i。由于n≥2时(1+2/n)^n≥4，h_i≤2给μ(A_j)≥2μ(A_i)，继而

μ(A_j\A_i)≥μ(A_j)−μ(A_i)≥μ(A_i)>0。

这是对同一μ的实际质量结论，不要求Ai、Aj不交或source均匀。它仅逐pair成立；不同pairs的A_j\A_i可高度重叠。作者(15)–(16)正确保留了这笔复用账：只有证明共同B_μ的本质上界G_n，或另一项可求和的同源收费，才能推出低h坏域体积≤G_nQ*。逐pair质量增长或每条链的增长不能替代这一联合界。

h_i>2的全部所选receiver属于高h原row的union；同一个μ/2使这些原stars严格bad，故其体积≤D_n(a)Q*/2。结合删带、good域及低h收费后，作者(17)的条件性吸收方向及系数2正确，前提是对每个未被easy分支支付的完整family确有统一s_n、G_n，且仍使用同一个完整最小μ。这两个前提本稿没有证明。未引入重新优化barrier的near假设，也不能把该条件式当作本轮root定理。

## 8. 分离尺度附录：完整disjoint packing已付到O(n log n)

A1通过一套共同平移lattice抽取原rows，间距ell=2(a+1)βR。每个B_j最多包含一个lattice点；不同点选出的原centers在某坐标至少相距ell−r_j−r_l≥a(r_j+r_l)，所以原开stars逐outcome两两不交。对任意不交可测I_j⊂B_j，平移平均的精确系数是E S_bin=Σd_j|I_j|/ell^n≥V_bin/(Pβ^n)。这不要求source均匀；也没有将lattice点处辅助cube当作原bad动作。

A2的外包同样正确：若低row与seed A_k相交且r_j≤ηr_k/n，则I_j⊂Q(y_k,a r_k+(a+1)r_j)。对原本不交的I_j取union，再按seed外包体积次可加，得D≤C_f S_bin，C_f=[1+η(a+1)/(an)]^n。这里支付真实receiver删除体积，不声称source在薄壳内稀少；冲突row删一次即可，外包cubes无需source不交。

A3归纳令K=C_0+C_f。对每个top-bin outcome，剩余低rows全部与已选seed stars不交，归纳packing可拼成一套全局disjoint原star packing。其目标至少V_low/K+(1−C_f/K)S_bin。因1−C_f/K=C_0/K>0，取A1平均得到(V_low+V_bin)/K。可对每个有限被选row子集直接选一个最优剩余packing，故不需要额外的不可测随机选择假设。最后只取某个实现此下界的outcome，所有层的source预算只付一次。

按bin index mod m分组，m=1+ceil(log(n/η)/logβ)，同class相邻bin最大/最小半径比≤β^(1−m)≤η/n，满足归纳前提。各class用原不交I_j记账，ΣV_c=V；只取最佳class，不能相加m套packing。由此Q*≥V/[m(C_0+C_f)]。β=1+1/n、η=1、a≥n时，C_0,C_f≤e²且m≤2+(n+1)log n，确得完整O(n log n)付款。无须barrier或新增Ccov；若随后引入M=Q+εV，才另按稿中条件吸收一次ε。

这是一个已闭合的全族基线，不是root改进。归纳要求每个outcome的seed stars真实disjoint；任意宽band期望load≤1的fractional packing不能直接替代它。仍缺的是跨近尺度classes的共同选择/overload repair，或主稿远seed复用的统一收费。当前通过范围是：内部菜单饱和及min-witness/T连接、精确删带账、同源逐pair增长、分离尺度disjoint拼接和O(n log n)全族基线；一般根阶以及最初较窄排列目标均未闭合。本次审查到此停止。
