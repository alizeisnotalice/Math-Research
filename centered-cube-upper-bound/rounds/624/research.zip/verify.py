"""Exact receipt checks plus Arb conversion; does not certify general bounds."""
from pathlib import Path
from fractions import Fraction as F
import argparse, hashlib, json, sys, time
import flint
from flint import arb, ctx

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--receipt',type=Path);args=ap.parse_args()
    p=Path(__file__).parent;t=time.perf_counter();ctx.prec=192
    raw=json.loads((p/'ccu_r624_numeric.json').read_text())
    cert=json.loads((p/'ccu_r624_certificate.json').read_text())
    cone=json.loads((p/'ccu_r624_cone.json').read_text())
    h=hashlib.sha256((p/'ccu_r624_numeric.json').read_bytes()).hexdigest()
    assert cert['input_sha256']==cone['input_sha256']==h
    for name,d in [('certificate',cert),('cone',cone)]:
        assert d['script_sha256']==hashlib.sha256((p/f'ccu_r624_{name}.py').read_bytes()).hexdigest()
    assert raw['N']==84 and F(raw['receiver_V'])==F(573,4)
    assert F(*map(int,cert['source_mass']))==F(*map(int,cert['dual_objective']))==85
    assert F(*map(int,cert['ratio']))==F(573,340)
    assert F(4,9)*F(573,340)==F(191,255)
    q={};end={k:list(map(F,v)) for k,v in cone['intervals_exact'].items()}
    def ball(x):return arb(x.numerator)/x.denominator
    factor=9*arb(2).log()
    for k,(lo,hi) in end.items():
        assert 0<=lo<=hi<=F(573,4)
        q[k]={'lower_endpoint_interval':str(ball(lo)/factor),'upper_endpoint_interval':str(ball(hi)/factor)}
    gap=end['J_maxfirst'][0]-end['J_sat'][1]
    assert gap>0
    assert not end['J_sat'][0]>end['J_min'][1]
    assert cone['bad_T_gt_10_ress_area_interval']==['0','0']
    assert len(cone['essential_rows'])==82 and cone['zero_min_owner_rows']==[21,22]
    if (p/'MANIFEST.json').exists():
        for f,sha in json.loads((p/'MANIFEST.json').read_text()).items():
            assert hashlib.sha256((p/f).read_bytes()).hexdigest()==sha,f
    result={'python':sys.version,'interpreter':sys.executable,'flint_version':flint.__version__,
            'arb_precision_bits':ctx.prec,'q_endpoint_intervals':q,
            'certified_J_maxfirst_minus_J_sat_lower':str(gap),
            'q_difference_lower_endpoint_interval':str(ball(gap)/factor),
            'comparison':'Frozen-min-envelope saturation is strictly below max-first on this finite family; no certified strict sat/min gain.',
            'scope':'Finite family and saved exact integral endpoints only; V/Q* is not an automatic weak-type lower bound.',
            'elapsed_seconds':time.perf_counter()-t,
            'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    if args.receipt:args.receipt.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result))

if __name__=='__main__':main()
