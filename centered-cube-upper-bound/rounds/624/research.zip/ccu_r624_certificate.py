import json,hashlib,sys,time,resource,platform
from fractions import Fraction as Q
from pathlib import Path
start=time.perf_counter();cpu=time.process_time();p=Path(__file__).with_name('ccu_r624_numeric.json');d=json.loads(p.read_text());assert d['n']==2 and d['a']==2 and d['N']==84
cubes=d['cubes_quarter_units'];assert len(cubes)==84
stars=[tuple(map(Q,z)) for z in d['stars']];assert len(stars)==84
occ=set();reconstructed=[]
for r,x,y in cubes:
 assert all(isinstance(k,int) for k in (r,x,y)) and r>0
 occ.update((i,j) for i in range(x-r,x+r) for j in range(y-r,y+r))
 reconstructed.append((Q(x-2*r,4),Q(x+2*r,4),Q(y-2*r,4),Q(y+2*r,4)))
assert stars==reconstructed;V=Q(len(occ),16);assert V==Q(d['receiver_V'])==Q(573,4)
def area(r):return (r[1]-r[0])*(r[3]-r[2])
def inter(a,b):return max(Q(),min(a[1],b[1])-max(a[0],b[0]))*max(Q(),min(a[3],b[3])-max(a[2],b[2]))
source=[(*map(Q,z[:4]),Q(z[4])) for z in d['Qstar']['source_cells']];dual=list(map(Q,d['Qstar']['dual_weights']));assert len(source)==6 and len(dual)==84 and all(z>=0 for z in dual) and all(area(c)>0 and c[4]>=0 for c in source);assert [c[4] for c in source]==[16,1,47,16,4,1]
coverage=[sum((c[4]*inter(c,r)/area(c) for c in source),Q()) for r in stars];targets=[area(r) for r in stars];assert all(x>=y for x,y in zip(coverage,targets))
xs=sorted({v for r in stars for v in r[:2]});ys=sorted({v for r in stars for v in r[2:]});cell_loads=[]
for x0,x1 in zip(xs,xs[1:]):
 for y0,y1 in zip(ys,ys[1:]):
  cx=(x0+x1)/2;cy=(y0+y1)/2;val=sum((v for r,v in zip(stars,dual) if r[0]<cx<r[1] and r[2]<cy<r[3]),Q());assert val<=1;cell_loads.append(val)
primal=sum((c[4] for c in source),Q());dualobj=sum((v*t for v,t in zip(dual,targets)),Q());assert primal==dualobj==85 and V/primal==Q(573,340)>1
f=lambda x:[str(x.numerator),str(x.denominator)]
out={'V':f(V),'occupied_quarter_cells':len(occ),'star_count':len(stars),'source_mass':f(primal),'dual_objective':f(dualobj),'ratio':f(V/primal),'source_cells':[[*map(str,c[:4]),str(c[4])] for c in source],'source_star_coverage':list(map(f,coverage)),'star_area':list(map(f,targets)),'dual_weights':list(map(f,dual)),'dual_arrangement_shape':[len(xs)-1,len(ys)-1],'dual_arrangement_cells':len(cell_loads),'dual_max_load':f(max(cell_loads)),'strict_bad_note':'scaling source by 1+epsilon makes original stars strictly bad at their centers only; all receiver points instead have centered radius (a+1)r and threshold (a/(a+1))^2=4/9, so weak lower bound is at least 191/255 in the epsilon limit, not 573/340','input_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'python':sys.version,'sys_executable':sys.executable,'platform':platform.platform(),'argv':[sys.executable]+sys.argv,'wall_seconds':time.perf_counter()-start,'cpu_seconds':time.process_time()-cpu,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'scope':'finite real receiver cubes, absolutely continuous rectangle source and exact dual; no claim for periodic source'}
Path(__file__).with_name('ccu_r624_certificate.json').write_text(json.dumps(out,indent=2)+'\n');print('V',V,'source',primal,'dual',dualobj,'ratio',V/primal,'dual cells',len(cell_loads),'seconds',out['wall_seconds'],'hash',out['script_sha256'])
