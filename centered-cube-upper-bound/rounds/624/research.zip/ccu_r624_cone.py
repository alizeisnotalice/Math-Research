import json,math,hashlib,sys,time,os,resource
from fractions import Fraction as F
from collections import defaultdict
from concurrent.futures import ProcessPoolExecutor
import numpy as np
from pathlib import Path
SOURCE=Path(__file__).with_name('ccu_r624_numeric.json'); OUT=Path(__file__).with_name('ccu_r624_cone.json'); REPORT=Path(__file__).with_name('ccu_r624_cone.md')
Q=1<<24

def rects(grid,x0,y0):
    # Merge identical horizontal runs through consecutive rows, separately for each scale.
    active={};out=[]
    for iy in range(grid.shape[1]):
        col=grid[:,iy]; runs=[]; i=0
        while i<len(col):
            v=int(col[i]);j=i+1
            while j<len(col) and col[j]==v:j+=1
            if v:runs.append((v,x0+i,x0+j))
            i=j
        now=set(runs)
        for key in list(active):
            if key not in now:
                start=active.pop(key);v,a,b=key;out.append((v,a,b,y0+start,y0+iy))
        for key in now:
            if key not in active:active[key]=iy
    for (v,a,b),start in active.items():out.append((v,a,b,y0+start,y0+grid.shape[1]))
    return out

def construct(data):
    cubes=data['cubes_quarter_units'];stars=data['stars'];assert len(cubes)==len(stars)==84
    B=[]
    for (r,x,y),star in zip(cubes,stars):
        expanded=[x-2*r,x+2*r,y-2*r,y+2*r];assert [F(z) for z in star]==[F(z,4) for z in expanded]
        B.append((r,x-r,x+r,y-r,y+r))
    x0=min(z[1] for z in B);x1=max(z[2] for z in B);y0=min(z[3] for z in B);y1=max(z[4] for z in B)
    shape=(x1-x0,y1-y0);owner=np.full(shape,-1,dtype=np.int32);mx=np.zeros(shape,dtype=np.int32); available=np.zeros(shape,dtype=np.int32)
    for j,(r,xl,xh,yl,yh) in sorted(enumerate(B),key=lambda z:(z[1][0],z[0])):
        v=owner[xl-x0:xh-x0,yl-y0:yh-y0];v[v<0]=j
        w=mx[xl-x0:xh-x0,yl-y0:yh-y0];np.maximum(w,r,out=w)
        available[xl-x0:xh-x0,yl-y0:yh-y0] |= r
    mask=owner>=0;essential=set(map(int,np.unique(owner[mask])));rvals=np.array([b[0] for b in B]);mn=np.zeros(shape,dtype=np.int32);mn[mask]=rvals[owner[mask]]
    essmax=np.zeros(shape,dtype=np.int32)
    for j,(r,xl,xh,yl,yh) in enumerate(B):
        if j in essential:
            w=essmax[xl-x0:xh-x0,yl-y0:yh-y0];np.maximum(w,r,out=w)
    assert np.all((essmax>0)==mask)
    area=F(int(mask.sum()),16);assert area==F(data['receiver_V'])
    return {'x0':x0,'y0':y0,'min':mn,'maxfull':mx,'maxess':essmax,'available':available,'minrects':rects(mn,x0,y0),'maxrects':rects(mx,x0,y0),'essential':sorted(essential),'zero_owner':[j for j in range(len(B)) if j not in essential],'area':str(area)}

def envelope(rectangles,weight,lox,hix,loy,hiy,k):
    # In 2*S/h units: weight*(r/h)*2 - L1 distance in grid units.
    Slo=np.zeros_like(lox);Shi=np.zeros_like(lox)
    for r,x1,x2,y1,y2 in rectangles:
        x1*=k;x2*=k;y1*=k;y2*=k
        nearx=np.maximum(0,np.maximum(x1-hix,lox-x2));neary=np.maximum(0,np.maximum(y1-hiy,loy-y2))
        farx=np.maximum(np.maximum(x1-lox,lox-x2),np.maximum(x1-hix,hix-x2));farx=np.maximum(0,farx)
        fary=np.maximum(np.maximum(y1-loy,loy-y2),np.maximum(y1-hiy,hiy-y2));fary=np.maximum(0,fary)
        np.maximum(Slo,2*weight*r*k-farx-fary,out=Slo)
        np.maximum(Shi,2*weight*r*k-nearx-neary,out=Shi)
    return Slo,Shi

def quot(num,den,up):
    a=Q*num*num;d=den*den
    return (a+d-1)//d if up else a//d

def run_slice(arg):
    geom,k,ixs=arg;x0=geom['x0'];y0=geom['y0'];mn=geom['min'];mx=geom['maxfull'];em=geom['maxess'];ny=mn.shape[1]
    out=np.zeros(10,dtype=np.int64); min_dom=10**15
    for ix in ixs:
        active=np.flatnonzero(mn[ix]);
        if not len(active):continue
        xx,yy,dx,dy=np.meshgrid(np.array([ix],dtype=np.int64),active,np.arange(k,dtype=np.int64),np.arange(k,dtype=np.int64),indexing='ij')
        xx=xx.ravel();yy=yy.ravel();dx=dx.ravel();dy=dy.ravel()
        lx=(x0+xx)*k+dx;ly=(y0+yy)*k+dy;hx=lx+1;hy=ly+1
        R=mn[xx,yy].astype(np.int64);RF=mx[xx,yy].astype(np.int64);RE=em[xx,yy].astype(np.int64); AV=geom['available'][xx,yy]
        low,high=envelope(geom['minrects'],3,lx,hx,ly,hy,k);low=np.maximum(low,6*R*k)
        tl,th=envelope(geom['minrects'],5,lx,hx,ly,hy,k);tl=np.maximum(tl,10*R*k)
        fl,fh=envelope(geom['maxrects'],3,lx,hx,ly,hy,k);fl=np.maximum(fl,6*RF*k)
        smin=6*R*k;fmin=6*RF*k;tmin=6*RE*k
        satlo=np.zeros_like(low);sathi=np.zeros_like(low)
        # ρ menu = 3*r, numeric in same units as cone S
        for a in (1,2,4,8):
            rho=6*a*k;satlo=np.where(((AV & a)!=0)&(low>=rho),rho,satlo);sathi=np.where(((AV & a)!=0)&(high>=rho),rho,sathi)
        assert np.all(satlo>0)
        for idx,(num,lower,upper) in enumerate(((smin,low,high),(satlo,low,high),(fmin,fl,fh),(tmin,tl,th))):
            numhi=sathi if idx==1 else num
            out[2*idx]+=np.sum(quot(num,upper,False),dtype=np.int64)
            out[2*idx+1]+=np.sum(quot(numhi,lower,True),dtype=np.int64)
        out[8]+=np.count_nonzero(tl>20*RE*k)
        out[9]+=np.count_nonzero(th>20*RE*k)
        min_dom=min(min_dom,int(np.min(tl-6*RE*k)))
    return out.tolist(),min_dom,resource.getrusage(resource.RUSAGE_SELF).ru_maxrss

def main():
    import argparse
    ap=argparse.ArgumentParser();ap.add_argument('--level',type=int,default=4);ap.add_argument('--workers',type=int,default=14);args=ap.parse_args(); assert 0<=args.level<=6 and 1<=args.workers<=14
    t0=time.monotonic();data=json.loads(SOURCE.read_text());g=construct(data);k=2**args.level;nx=g['min'].shape[0]
    # Every output summand is at most 64*Q; enforce signed int64 bounds.
    assert Q*(48*k)**2+(80*k)**2 < 2**63
    assert g['min'].size*k*k*64*Q < 2**63
    # More equal work by active cell counts and longest-first scheduling.
    bins=[[] for _ in range(args.workers)];loads=[0]*args.workers
    for ix in sorted(range(nx),key=lambda j:int(np.count_nonzero(g['min'][j])),reverse=True):
        b=min(range(args.workers),key=lambda i:loads[i]);bins[b].append(ix);loads[b]+=int(np.count_nonzero(g['min'][ix]))
    with ProcessPoolExecutor(max_workers=args.workers) as pool: results=list(pool.map(run_slice,[(g,k,b) for b in bins if b]))
    z=np.sum([r[0] for r in results],axis=0,dtype=np.int64);unit=16*k*k;den=unit*Q
    labels=('J_min','J_sat','J_maxfirst','J_T');bounds={name:[str(F(int(z[2*i]),den)),str(F(int(z[2*i+1]),den))] for i,name in enumerate(labels)}
    bad=[str(F(int(z[8]),unit)),str(F(int(z[9]),unit))]
    out={'input_sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'command':sys.argv,'python':sys.version,'numpy':np.__version__,'n':2,'a':2,'V':g['area'],'essential_rows':g['essential'],'zero_min_owner_rows':g['zero_owner'],'min_seed_rectangles':len(g['minrects']),'max_seed_rectangles':len(g['maxrects']),'level':args.level,'subdivisions':k,'workers':args.workers,'intervals_exact':bounds,'bad_T_gt_10_ress_area_interval':bad,'uniform_margin_lower_2T_over_h_minus_2_3ress_over_h':min(r[1] for r in results),'integer_Q':Q,'elapsed_wall_seconds':time.monotonic()-t0,'peak_parent_rss':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'sum_worker_peak_rss':sum(r[2] for r in results),'worker_peak_rss':[r[2] for r in results],'notes':'Exact rational sums of outward rounded pointwise bounds, assuming int64 intermediate checks; q denominators are 9 log(2), no log approximations included.'}
    assert out['peak_parent_rss']+out['sum_worker_peak_rss'] < 1536*1024*1024, 'aggregate peak RSS budget exceeded'
    OUT.write_text(json.dumps(out,indent=2));
    with REPORT.open('w') as f:
        f.write('# R624 完整接收域全局锥积分\n\n')
        f.write(f"原数据 84 盒，精确接收面积 {g['area']}；小尺度优先正面积 owner 行 {len(g['essential'])}，零面积行 {len(g['zero_owner'])}。每个面积为 1/16 的格继续细分 {k}×{k}；分母、舍入和 bounds 详见 JSON。\n\n")
        f.write('| 量 | 严格下界 | 严格上界 |\n|---|---:|---:|\n')
        for name,(a,b) in bounds.items():f.write(f'| {name} | {float(F(a)):.8f} | {float(F(b)):.8f} |\n')
        f.write(f'| T > 10 rmax 的面积 | {float(F(bad[0])):.8f} | {float(F(bad[1])):.8f} |\n')
        f.write('\n表中十进制为显示值，严格端点是 JSON 中有理数；所有 q 为对应 J/(9 log 2)。J_sat 的 menu 只含该点由原 B 覆盖的尺度。J_maxfirst 使用独立 max-first 的全局锥及其逐点 max owner；J_T 使用 essential 行逐点 max，绝不采用删前 max owner。T 坏域依题设为逐点 T>10 rmax。区间由每小矩形对每个种子矩形的最近/最远 L1 距离上下界、max 包络与向外定点整数舍入给出，不依赖浮点或 probe。只研究此有限族。\n')
    print(json.dumps({'bounds':bounds,'bad':bad,'elapsed':out['elapsed_wall_seconds'],'ess':len(g['essential']),'zero':len(g['zero_owner']),'rects':[len(g['minrects']),len(g['maxrects'])],'dominance':out['uniform_margin_lower_2T_over_h_minus_2_3ress_over_h']}))
if __name__=='__main__':main()
