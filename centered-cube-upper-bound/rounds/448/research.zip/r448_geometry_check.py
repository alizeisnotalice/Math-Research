from fractions import Fraction as F

# Disjoint source pieces with complete full-source masses, assigned to cells.
mass = [F(1, 3), F(1, 2), F(2, 3), F(1, 4), F(3, 4)]
cell = [0, 0, 1, 1, 2]
parent = [1, 1, 1, 1, 0]
cases = [
    ([1, 0, 1, 0, 0], set(), F(2, 3), F(1, 2)),
    ([1, 1, 0, 0, 1], {0, 2}, F(3, 5), F(2, 5)),
    ([1, 1, 1, 1, 1], {0, 1, 2}, F(4, 7), F(3, 8)),
]
for number, (capture, whole_cells, center_weight, psi) in enumerate(cases, 1):
    mw = sum(mass[i] for i in range(len(mass)) if capture[i])
    intersection = sum(mass[i] for i in range(len(mass))
                       if parent[i] and capture[i])
    exact = center_weight * psi * intersection / mw
    reconstructed = F(0)
    whole = F(0)
    partial = F(0)
    for c in sorted(set(cell)):
        fc = sum(mass[i] for i in range(len(mass))
                 if parent[i] and cell[i] == c)
        ic = sum(mass[i] for i in range(len(mass))
                 if parent[i] and capture[i] and cell[i] == c)
        lam = ic / fc if fc else F(0)
        reconstructed += center_weight * psi * fc * lam / mw
        if c in whole_cells:
            assert ic == fc
            whole += center_weight * psi * fc / mw
        else:
            partial += center_weight * psi * ic / mw
    assert exact == reconstructed
    assert exact == whole + partial
    assert whole <= exact
    print(f"case {number}: full={exact}, whole-cell={whole}, "
          f"partial={partial}: PASS")
print("Scope: exact full-source capture bookkeeping; not a native center/history model or entropy-budget test.")
