from fractions import Fraction as F
checks=0

def ck(x):
    global checks
    assert x
    checks+=1

# Finite clipped-source schedules; all tests are interface algebra, not native history.
cases=[
    dict(f=F(5),Ts=list(map(F,[0,1,2,4,6])),D=list(map(F,[8,6,3,1])),a=[F(1),F(3,4),F(1,2),F(1,4)],s=F(2),cap=F(1,3),kap=[F(1,4),F(1),F(1,2),F(1)]),
    dict(f=F(2),Ts=list(map(F,[1,2,3,5])),D=list(map(F,[6,2,0])),a=[F(1),F(1),F(0)],s=F(2),cap=F(1,4),kap=[F(1),F(1),F(0)]),
    dict(f=F(7,3),Ts=[F(0),F(1,3),F(2),F(3)],D=[F(9),F(7),F(5)],a=[F(1),F(3,4),F(1,2)],s=F(2),cap=F(0),kap=[F(0),F(1),F(1,3)])]
outputs=[]
for case in cases:
    f,Ts,D,a,s,c,k=(case[z] for z in ['f','Ts','D','a','s','cap','kap'])
    clip=[min(f,t) for t in Ts]
    d=[max(F(0),1-s/x) if x else F(0) for x in D]
    u=[x*y for x,y in zip(d,a)]
    v=[max(F(0),x-c) for x in u]
    g=[x*y for x,y in zip(u,k)]
    direct=sum((clip[i+1]-clip[i])*v[i] for i in range(len(u)))
    terminal=clip[-1]*v[-1]
    initial=-clip[0]*v[0]
    deletion=sum(clip[i+1]*(v[i]-v[i+1]) for i in range(len(u)-1))
    ck(direct==terminal+initial+deletion)
    actual=sum((clip[i+1]-clip[i])*max(F(0),g[i]-c) for i in range(len(u)))
    weighted=sum((clip[i+1]-clip[i])*g[i]*max(F(0),1-c/u[i]) for i in range(len(u)) if u[i])
    ck(actual<=weighted<=direct)
    for i in range(len(u)-1):
        ck(u[i]>=u[i+1])
        ck(u[i]-u[i+1]==d[i]*(a[i]-a[i+1])+a[i+1]*(d[i]-d[i+1]))
        crossing=max(F(0),u[i]-max(u[i+1],c))
        ck(v[i]-v[i+1]==crossing)
    outputs.append(tuple(map(str,(actual,weighted,direct,initial,terminal,deletion))))
# An actual retained density can rise while its monotone envelope falls.
ck(cases[0]['kap'][0]*F(3,4)<cases[0]['kap'][1]*F(1,2))
# Normalized-law Hellinger sees no proportional positive-mass deletion.
p=[F(1,3),F(2,3)];Dold,Dnew=F(9),F(4)
alpha=[Dold*x for x in p];anew=[Dnew*x for x in p]
ck([x/Dold for x in alpha]==[x/Dnew for x in anew])
ck(sum(x-y for x,y in zip(alpha,anew))==5)
# With s=1 and a=D, u=D-1, the positive capacity-crossing jump is still 5.
ck(max(F(0),Dold-1-1)-max(F(0),Dnew-1-1)==5)
print('PASS',checks,'exact Fraction assertions across three fixed schedules.')
print('(actual deficit, accepted-weight bound, envelope bound, initial, terminal, deletion):')
for out in outputs: print(out)
print('Scope: clipped-profile and stage-jump identities only; no cube/history realization or root-budget evidence.')
