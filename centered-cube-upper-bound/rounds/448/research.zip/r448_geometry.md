# R448 — testing a source-cell route to the free-column deficit

**Outcome.** No new global bound for \(D_{\rm free}\) was proved. The single
mechanism examined was to lower-bound the full-parent auxiliary capacity
using actual cell capture, and then charge its shortage to the already
proved clipping entropy dissipation. The exact capture decomposition is
valid; the required comparison with dissipation is not established.
Neither decomposition is counted as a payment.

## 1. Fixed object and proposed geometric mechanism

Keep the complete original projected demand \(\widetilde g(e,A,z,t,v)\),
including every current, early, rank, low-common, deletion and future gate.
The R447 auxiliary column is
\[
k_{\rm free}(A,e,v)=\frac{B_e}{h m_A}
 \int_{\{m_w<m_A/K^2\}}
       \bar\psi(w,v)\frac{I_{Aw}}{m_w}\,dw,
\qquad I_{Aw}=\int f c_Ac_w .
\tag{1}
\]
Here \(dw\) is actual Lebesgue receiver measure; the selected side length
and \(m_w=f(Q_w)=q_wR_w^n\) are not independent variables.
The new-terminal reference \(\nu_z\) and base \(\mathcal L\) are exactly
those of R447 §3. The remaining quantity is
\[
D_{\rm free}=\int(\widetilde g-\sqrt n\,k_{\rm free})_+
                  \,d\nu_z\,d\mathcal L .
\tag{2}
\]
The intended mechanism was a **lower** coverage estimate in (1), localized
to the same source cells used by the clipping entropy. A capacity upper
bound, already available, cannot serve this purpose.

## 2. Exact full-source localization and a valid lower bound

Fix the existing measurable half-open source-cell partition \(\{C\}\).
Set
\[
F_{AC}=\int_{Q_A\cap C}f,\qquad
\lambda_{AC}(w)=
\frac{\int_{Q_A\cap C\cap Q_w}f}{F_{AC}},
\]
using zero if \(F_{AC}=0\). Thus \(0\le\lambda_{AC}\le1\), and Tonelli gives
\[
k_{\rm free}
=\frac{B_e}{h m_A}\sum_C F_{AC}
 \int_{\{m_w<m_A/K^2\}}
       \frac{\bar\psi(w,v)}{m_w}\lambda_{AC}(w)\,dw .
\tag{3}
\]
This keeps all partial captures, the full source, and the real center
selector. In particular it is not a thin-boundary source estimate.

A concrete sufficient lower bound is
\[
k_{\rm free}\ge\frac{B_e}{h m_A}\sum_C F_{AC}\,
 \int_{\{m_w<m_A/K^2,\ C\subset Q_w\}}
             \frac{\bar\psi(w,v)}{m_w}\,dw .
\tag{4}
\]
Cube inclusion is measurable, including its endpoints; no null-boundary
assumption is required. The nonnegative difference between (3) and (4)
is precisely the contribution of partially captured cells (and cells
whose irrelevant portion outside \(Q_A\) prevents full inclusion).
Thus a failure to use (4) would not invalidate the larger capacity (3).

## 3. The decisive unproved comparison

The available entropy theorem concerns
\[
m_C(t)=\int_C\min(f,t),\quad
N_C(t)=\sum_{D\sim C}m_D(t),\quad
\phi(u)=u-1+e^{-u},
\]
and yields the already certified stage budget
\[
\sum_i\int\delta g_i(x)\,\eta_i(x)\,dx\le n\log5\,W.
\tag{5}
\]
To finish this attempted route, one would need a lower-coverage/shortage
comparison for the **actual retained demand** against the center integrals
in (3), whose positive error, after the original stage/source integration,
is controlled by \(s^{-1}\) times (5), together with an absorbable
multiple of \(\sum_i\int\delta g_iD_i\).
Such a comparison has not been derived.

The precise obstacle in the attempted calculation is that the coefficients
\[
\int_{\{m_w<m_A/K^2\}}
       \bar\psi(w,v)\lambda_{AC}(w)\,\frac{dw}{m_w}
\tag{6}
\]
depend jointly on the parent, the new terminal, actual small-mass centers
and their partial full-source captures. The local ratios
\(N_C(t)/m_C(t)\) do not include those receiver restrictions. Matching gives
\(\int f c_w=m_w\), and hence useful **upper** capture estimates, but no
lower bound on (6) where the original retained load is large.
Replacing the restricted centers by all centers only enlarges (6);
that cannot prove the lower comparison needed in (2).

There is also a time/weight distinction that cannot be suppressed:
\(F_{AC}\) in (3) is full source mass, while (5) is weighted by the actual
clipping increment and uses clipped neighbor masses. The original current
and future acceptance can couple these variables. No replacement of the
actual demand by an independent parent posterior, nor an entropy bound for
that replacement, has been proved here.

This does not assert that the desired comparison is false. It identifies
where this one constructive proof attempt stops: an estimate linking
the actual retained demand to the restricted partial-capture center
coefficient (6), with a correctly integrated dissipation error.
The full-cell lower bound alone is too weak to settle that question;
retaining \(\lambda_{AC}\) is essential. No new density gate, receiver law,
history qualification, or fee is introduced. The R447 free-column receipt
and its entire unpaid complement remain unchanged.

## 4. Actual local check

The designated local Python executed
`/tmp/r448_geometry_check.py`; stdout is
`/tmp/r448_geometry.result.txt`.
Three exact Fraction bookkeeping cases verify the full-source identity
(3), the direction of (4), and the exact nonnegative partial-capture
difference. They include partial capture with positive capacity despite
zero whole-cell contribution.
These finite checks are not native Lebesgue-center/history realizations,
not tests of the entropy bridge, and not evidence for a new global budget.
There was no geometric counterexample scan. This bounded attempt stops here.
