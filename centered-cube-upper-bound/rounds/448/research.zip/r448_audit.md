# R448 independent final audit

FINAL PASS（限定范围）：通过实际当前接受率包络、有限stage正删除/初始/终端恒等式及可积粗价；通过cell捕获分解与Hellinger接口的范围说明。没有新增Dfree全局付款，未证明熵/形状预算控制原weighted删除费，母账保持R447。无必要修复项。以下绑定最终13文件，独立PRE保留。

## 1. 实际需求包络的资格

式(1)必须从原stage endpoint a_i的disintegration出发：在完整原initial record归一之前保其实际进入质量；给定原active起点，old generated path总概率≤1、新端wholeterminal law≤共同ν_Az，两个未过滤生成路径给定原起点条件独立。随后只正删原early/clock/current/future门，故存在κ_i∈[0,1]，gtilde=d_i∫π_A a_iκ_i。strict terminal mass/own-low留在ν与实际支撑，old-y相关门留κ。此推论不能只由Γ≤μν得到，作者已明确使用较强的原路径概率合同。未对过滤后的路径重新独立化或归一，所有原history仍在。

因此gtilde≤u_i=d_i s_i^e，标量(g−c)_+≤g(1−c/u_i)_+≤(u_i−c)_+正确，u_i=0零约定完整。单调的是原s_i和D_i给出的u_i包络，非κ_i或实际g；稿与计算均保这一区别。

## 2. 账、可积性与未付桥

c=Ckfree由原full-f parent/真实terminal确定，不依stage或level。v_i=(u_i−c)_+随stage递减；有限Abel式ΣΔF_i v_i=F_Nv_N−F_0v_1+ΣF_i(v_i−v_{i+1})、容量crossing积分及u_i差分的两个非负项均正确。F0、terminal、正删除项未丢。乘数仍是原Σ_eσ c_A(z)dz/m_A·ν_Az(dv)，不能换成无权空间积分。

ν_Az(E)≤1+ε₀与ΣΔF_i(D_i−s)_+≤∫fD0=2G0≤SX给粗价(1+ε₀)SX。各有限边界/删除项点态≤f u1，在该真实测度下可积，有限至无限不构成∞−∞。此粗价不等于任意小εX，更不是根阶来源价。

cell identity保持完整F_AC与真实部分捕获比例λ_AC(w)；fullcell子集仅给容量下界，遗漏partialcapture会失信息，不能用上放全部receiver证明需求下覆盖。现有nlog5 W熵预算不含该父/终端/receiver联合乘数，整体比较未证。Hellinger耗散属于归一形状；比例删除可有非零幅度而H²为0，shape一般仅给线性H，转平方需未有duration因子，方向依赖测试也需resolved law。稿未将这些旧工具重作原付款。

主稿维持R447入口64Λ₀Fhat[ΩW+Dfree]及所有旧费用，未增新R分支或错误退款。Luna仅locator，不作为原history/几何认证。PRE列出的整体桥及ε/反馈公式仍仅充分条件，不是本轮已证结果。

## 3. 实际复现与证据范围

指定 `/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python` 在新目录 `/var/folders/lq/2c4qbz2n0354_tnttkv_qsz00000gn/T/r448_audit_isolated__svpepgg` 实际执行白名单三脚本：三stdout逐字节匹配，numeric生成JSON逐字节匹配。未改作者文件。资源文件只为原实际运行记录，复现不重复计覆盖。

mainproof 31 Fraction断言涵盖3固定profile及比例删除代数；geometry 3有限mass/capture bookkeeping；numeric自含3独立有理schedule、11stages、77 Fraction检查，核accepted envelope、零u/c、阈值跳跃、非零initial/terminal及正删除费。三类均非native cube/原stage-history构型，也不认证κ原始资格或熵桥；通用资格依原合同和上述分析证明。没有LP/扫描，无质量门失败旧fixture移植为本轮证据。

## 4. SHA256 byte bindings

- `r448_main.md`: `41d59cb79990ad9bbbbead2dc041afa2751d8a776fe9586cfd6457faea91f6b5`
- `r448_geometry.md`: `6b60ef6110a4e27de276ed8a4605ab776a1b2b180db90653b89ece933f00c90c`
- `r448_geometry_check.py`: `3d23d06f9a36346e4f343f0055b2e276dd3b8012e7ae626a688f70cfa24014b3`
- `r448_geometry.result.txt`: `4b5c2ebac80499143b63b096f48c9c4f38bc53020e1e62c91a5ccbc731ed5d84`
- `r448_mainproof.md`: `785d9ecc571ae475568c14dba88d90c3ea448d169cfec27c1b25cdf5e0ad9f39`
- `r448_mainproof_check.py`: `483af0c38acfb97cd6e97973422484304bee933a95ac52c6b084c8de03cd146a`
- `r448_mainproof.result.txt`: `660908239f7a21c4698af322d2f563fcb38b4859c6be42c68a131ed8c5c10e8b`
- `r448_numeric.md`: `595c69266836746e608caf54ad3c9154a85ecd326adb2d4a28f61f5a27bc342e`
- `r448_numeric.py`: `1cd997ac946ac8da876dde82b692a8cfff9482091f651725e4d8143d7de3de30`
- `r448_numeric_certificate.json`: `23bdfedf37f4c27dc4543b4fc3a6281b2b4449dd92b15ab9304b635198fa6f52`
- `r448_numeric_run.txt`: `3fc5ab40e081ae257ae060b872fdfeeb3cefdc77c5f3fea1398730ee59212063`
- `r448_numeric_resources.txt`: `91d02681c0b886aa8210872d88e6d5bdc812791c2559df989e23e7a6f9bd7bf9`
- `r448_compute_index.md`: `6ee86c90e743f6115895ea5af5af217d08db47a3d06fd3af88ec3bcd65f9f90a`

## 5. 独立 PRE 留档

# R448 independent audit — PRE

PRE ONLY。独立读取R435 exact-load合同、R434已证熵耗散及R440保原mask的分部积分，并核继承R447§3；尚未读本轮作者新稿。目标是同一原R433的Dfree整体预算，以下只给准确充分桥与已付工具，不声称桥成立。

## 1. Dfree仍有同一原阶段密度展开

原Δg_i(z)=min(f(z),T_i)−min(f(z),T_{i−1})，c_i(z)=(1−s/D_i(z))_+，fD_i=0取0。原R433=Σ_i∫Δg_i L_i，0≤L_i≤c_iD_i=(D_i−s)_+。

R447将old source精确推前后，令θ₀=(e,A,z,t)，原实际需求gtilde、辅助纯父列kfree不变。定义原记录上的残余乘子

r_free(θ₀,v)=(1−Ckfree_Ae(v)/gtilde(θ₀,v))_+，gtilde=0时0。

故Dfree=∫r_free dP是真正原P的正部分，而非以cap重建的流。把该乘子留在原history/终端积分内，在每个原stage区间(T_{i−1},T_i]展开一次level，精确可写

Dfree=Σ_i∫dz∫_{T_{i−1}}^{T_i}1_{f(z)>t} L_i^free(t,z)dt，
L_i^free(t,z)=c_i(z)Σ_e∫σ(dA)c_A(z)/m_A∫π_A(dy)a_i^e(A,y) Θ_i,free^e(A,y,z,t)。

Θ_i,free是原保留核乘r_free的真实条件积分，0≤Θ_i,free≤原对应核≤1；包括首次删除、stage-averaged early、原initialactive、fixed-full-f路径、soft、future等所有标签。这里只作同记录正限制，不假设筛后终端独立、不重算D_i/a_i/s_i。因而0≤L_i^free(t,z)≤(D_i(z)−s)_+。

可定义平均barL_i^free=Δg_i⁻¹∫stage 1_{f>t}L_i^free dt；零Δg_i取0，则Dfree=Σ∫Δg_i barL_i^free。这个平均是准确推前，不能把r_free换成另一个stage或刷新来源的概率。

## 2. 已证且可一次使用的nW耗散

固定原辅助a-grid的m_C(t)=∫Cmin(f,t)、N_C(t)为自身及至多5ⁿ邻格之和，ℓ_C=log(N_C/m_C)、φ(ℓ)=ℓ−1+e^(−ℓ)。R434已证

H_ent=Σ_i∫Δg_i(z) η_i(z)dz≤n log5 W，
η_i(z)=Δg_i(z)⁻¹∫stage 1_{f(z)>t}φ(ℓ_C(z)(t))dt。

零mass格/零Δg取0，原子阈值按同stage区间，有限端点E(T_N)−E(T_0)保留；无限格和stage的非负极限不增预算。无需∫f logf有限。此熵只用clipped full-f作辅助分析，不重建原cube mass/q/rank/history。

另有已证真实原容量

T_D=Σ_i∫Δg_iD_i≤∫fD_0=2G_0≤S X。

这里S已含两端，没有再乘2。对原正子流还可上放同T_D。上述两预算都不是Dfree或原load本身的预算。

## 3. 足以结算Dfree的正确全积分桥

一个准确可审核的WHOLE充分命题是：每个0<α<1存在受控C_α，使同一原测度上的

Dfree≤α T_D+(C_α/s) H_ent+C_α sW。                    (B)

也可把左边写为上述真实level/oldsource/terminal展开；右边不能改成带任意接收/历史乘子的熵。若(B)成立，则

Dfree≤α S X+C_α[s+n log5/s]W。

因n/s≤s，此为显式根阶来源价；若使用细grid，须保实际log邻格数，不能沿用log5。取α=ε/S（S>0且ε<S；S=0原流为空），得到εX+Q_εW。需给C_α的参数依赖以核目标polylog及最终ε余额。此处(B)仍未证，不能把“右边可支付”当作证明。

occupancy折扣确可严谨处理一个低区：D_i≤s/(1−α)时c_iD_i≤αD_i，故其Dfree贡献≤αT_D。高区D_i>s/(1−α)上必须另证真实barL_i,free的整体熵/来源比较。折扣本身不控制该高区；这只是(B)的合法缩小待证范围，不另命名原余量或宣称新全付款。

不必证明点态L_i^free≤η_i；即使作者提出它，也须另有几何证明。已证H_ent不含D_i或oldsource arrival乘数。若只以D_i≤SAn乘该耗散，得到SAn·nlog5 W，再除s仍约n^(3/2)W，达不到目标。真正桥必须保原几何、actual需求/cap关系，不能以弱掉原乘数后逆向退款。

## 4. 不能免费调用的耗散/单调性

原D_i递减与辅助密度t增大是两个方向。c_i折扣未给L_i对η_i的支配；原stage下降也未给旧熵source的自动结算。R440原ML和分部积分保了fill收益、实际marked删除成本及终端，后两项从未根阶付款。不能只见负fill项就当它覆盖删除/terminal，也不能把上界当可再次扣取信用。

尤其r_free依实际gtilde及t，未证明它关于level的单调或BV。若在共同记录上将其作为固定(t,record)正乘子，须保持该同一函数，才能借原stage嵌套；但在t方向做IBP仍须核它产生的变差/跳项，不能假设stage内“只有filled开启”。原stage-averaged early应继续冻结，不能改true-level cutoff再丢closing原子。单凭RN平均Θ≤1亦不能得Θ_i递减。

如果作者只使用整体(B)而不对残余乘子求导，这些额外变差可避免；相应整体几何比较仍须实际证明。

## 5. 完整ε母账

R447原R≤Ω(C)W+Dfree，Ω(C)=CSε₀²AnΦ/s²，正式C=√n。若(B)给Dfree≤εX+Q_εW，则

R≤εX+[Ω+Q_ε]W。

原16Fhat G₀槽、32Fhat BH槽、64Λ₀Fhat入口槽分别增加对应倍数的εX及(Ω+Q_ε)W来替换原R；旧C433/V433、初始/删除/尺度及外费保持，不叠旧匹配价。入口明确为原其余项加64Λ₀Fhat εX+64Λ₀Fhat(Ω+Q_ε)W。其X系数必须纳入原最终ε吸收余额。

若改用更尖T_D≤2G₀而不放成SX，则(B)只给Dfree≤2αG₀+QW；代G₀≤16Fhat[R+C433X+V433W]必须保(1−32Fhatα)G₀，需32Fhatα<1，且整式旧费用都同除该反馈分母。不能只添来源价而漏掉反馈。当前并未得到(B)，故母账尚不可作上述最终替换。

## 6. 实际本机辅助与停止

指定math-research-tools Python/Fraction实际核α=1/10,1/3,3/4的occupancy低区边界及零D约定；SymPy核同R槽费用代换的符号恒等式。仅是接口审查，不是原native/history构型或新实验覆盖。未做扫描、未读本轮作者证明，未修改其他文件。

PRE结论：现有nW耗散和原T_D容量都是有效工具；能结算Dfree的是同原weighted source/level load的整体(B)，不是未经证明的L≤η，也不是无权熵在失去D_i后可逆地退款。未独立证明该整体桥。交付后停止，待冻结作者稿再FINAL。
