# R448 — current acceptance versus the R447 parent-column capacity

**Outcome.** Keeping the original current density gives an acceptance-weighted upper bound for the exact column deficit. Its finite-stage summation exposes a positive, clipped-mass-weighted deletion cost. The available occupancy and matching bounds do not pay that cost at root scale. No new full budget, positive fraction, or entropy comparison is claimed.

## 1. Exact demand before the current density is discarded

Use the same original P and R447 §3 projection. Put theta=(e,A,z,t), i=i(t),

    F_i(z)=min(f(z),T_i),   d_i(z)=(1−s/D_i(z))_+,
    s_i^e(A)=∫π_A(dy)a_i^e(A,y).

When D_i=0 set d_i=0. All original fields use full f. The base is

    dΛ0=σ(dA)c_A(z)/m_A 1{f(z)>t} dz dt,

and the common new-terminal hat is

    ν_Az(dv)=1{Z_v(z)≤h,m_v<m_A/K²}c_v(z)dv/(h m_v).

Optional old-y-dependent gates remain in the actual density, not in this common hat. R435's exact source increment is (F_i−F_{i−1})d_i; the original endpoint density is a_i^e. At a normalized original starting record the generated old path has total probability at most one, and the generated new terminal law is bounded by ν_Az. Integrating the old path and retaining all positive original masks therefore gives a jointly measurable density κ_i with

    0≤κ_i(A,y,z,t;v)≤1,
    gtilde(theta,v)=d_i(z)∫π_A(dy)a_i^e(A,y)κ_i(A,y,z,t;v).       (1)

This uses the original whole-terminal bound record by record, as in R445 geometry §1. It is **not** inferred solely from θ_i≤1 or from Γ≤μ⊗ν. Factors with zero a_i d_i contribute zero. The original old source, clock, low-common soft factor, early, path and future gates remain in κ_i. In particular stage-averaged early factors remain frozen as such; they are not replaced by a newly varying level-t early event.

Let u_i(A,z)=d_i(z)s_i^e(A). Then gtilde≤u_i. For the R447 capacity

    kfree_Ae(v)=B_e/(h m_A)∫_{m_w<m_A/K²}ψbar(w,v)I_Aw/m_w dw,
    c(A,e,v)=C kfree_Ae(v),

we obtain the actual accepted-weight inequality

    (gtilde−c)_+ ≤ gtilde(1−c/u_i)_+ ≤ (u_i−c)_+.                (2)

At u_i=0 all three quantities are zero. The first inequality is (a−x)_+≤a(1−x)_+ for 0≤a≤1. This preserves the true demand on its right; replacing it by u_i is a further positive relaxation, not a claim of coverage.

## 2. Finite-stage accounting, including crossings and terminals

The current a_i, hence s_i and D_i, decrease in i. Thus u_i decreases. Set v_i=(u_i−c)_+. Capacity c is independent of stage and clipping level: m_A,I_Aw and the auxiliary raw geometry remain frozen. For every finite N, pointwise in A,z,v,

    Σ_{i=1}^N (F_i−F_{i−1})v_i
       = F_N v_N − F_0 v_1 + Σ_{i=1}^{N−1} F_i(v_i−v_{i+1}).   (3)

This retains a nonzero initial clipping level if present. The drop at an arbitrary jump, including a crossing of capacity, is exactly

    v_i−v_{i+1}=∫_{u_{i+1}}^{u_i}1{r>c}dr≥0.                  (4)

Moreover

    u_i−u_{i+1}
      =d_i(s_i^e−s_{i+1}^e)+s_{i+1}^e(d_i−d_{i+1}).           (5)

Both terms are nonnegative. Formula (5) remains valid through D=s and D=0; one need not divide by a vanished occupancy. The first term is actual endpoint deletion; the second is the fall in the occupancy retention factor. Neither is a negative credit in (3). Even if the final v_N vanishes, the positive weighted deletion sum remains.

Multiply (3) by the **actual** measure

    Σ_e σ(dA)c_A(z)dz/m_A · ν_Az(dv).

Together with (1)–(2), this bounds the exact Dfree on the corresponding finite clipping range. No demand, parent, terminal denominator or original history is regenerated. The actual κ_i need not decrease as a density in v; monotonicity was used only for its certified envelope u_i.

The crude integrable domination is explicit. Native own-low capacity gives ν_Az(E)≤1+epsilon0. Consequently the envelope integral is at most

    (1+epsilon0)Σ_i∫(F_i−F_{i−1})(D_i−s)_+ dz
      ≤(1+epsilon0)∫f D_0 ≤(1+epsilon0) S Xq.                 (6)

This justifies finite-to-infinite limiting where required, but is an X-scale price, not the desired root-source price. All terms in (3) are integrable under this domination (the deletion sum is bounded by f u_1 pointwise). No infinite positive-minus-infinite expression is used.

## 3. The specific missing comparison

The candidate would succeed if the right side of (3), integrated with its displayed original measure, could be bounded by epsilon Xq plus a root-polylog source fee, or if the actual acceptance factor κ_i in (2) supplied a quantitatively comparable discount. This is stronger than merely estimating an unmarked capacity. It asks that columns with small parent-overlap capacity c cannot retain large current acceptance until a large amount F_i of source density has already been accumulated.

Current monotonicity gives (3)–(6), but no relation between the clipping level F_i and the spatial column kfree at the deletion time. The source increments restrict t to its own stage interval; they do not control the terminal-to-parent mass ratio. Original early averaging cannot supply a missing pointwise t gate. R434's cumulative clipped entropy has a proven n log(5)W budget, but no comparison between that entropy and the weighted jump integrand F_i(v_i−v_{i+1}) or the retained κ_i in (2) has been proved. Charging every such jump by an unweighted occupancy drop would discard its indispensable F_i multiplier.

Thus (2) is a valid connection of the actual accepted demand to current occupancy, and (3) decides the sign and location of its remaining charge. It does not prove Dfree≤epsilon Xq+Cepsilon sqrt(n)polylog(n+2)W, does not replace the original demand by an arbitrary raw upper bound and declare success, and adds no new mother-ledger receipt.

## 4. Why the existing temporal Hellinger budget is not yet the bridge

R408 main §3, equation (5), already proves

    T_H=∫f Σ_i sqrt(D_i) H²(p_i,p_{i+1})≤2 sqrt(S An) W,
    α_i^z(dA)=s_i(A)c_A(z)R_A^(−n)dA, p_i=α_i/D_i.

This is a real root-source budget. It is not inserted as a new potential here. The unresolved issue is domination of the weighted deletion charge in (3) by this existing quantity and allowable errors.

For a bounded test a on actual receivers, at two positive occupancies the exact decomposition is

    ∫a d(α_i−α_{i+1})
      =(D_i−D_{i+1}) E_{p_i}a
          +D_{i+1}∫a d(p_i−p_{i+1}).                    (7)

For 0≤a≤1, the second term is at most D_{i+1} TV(p_i,p_{i+1})≤D_{i+1}H(p_i,p_{i+1}). The first is a genuine amplitude term. Pure proportional deletion with positive occupancies leaves p_i unchanged, so H²=0 while this amplitude term can be positive. This is an interface observation, not a native counterexample to the desired full estimate. The threshold factor d_i in (5) also responds to that amplitude and cannot be discarded.

Even the generic shape estimate does not have the required square weight: Cauchy–Schwarz on Σ D_{i+1}H introduces the extra factor

    [Σ_i D_{i+1}²/sqrt(D_i)]^(1/2),

beside [Σ_i sqrt(D_i)H²]^(1/2). No stage-duration bound for that factor is available. If a test distinguishes the direction e, one must moreover keep a direction-resolved endpoint law; the aggregate p_i over A alone cannot bound an arbitrary direction-dependent test. A direction-resolved monotone law has the same elementary root Hellinger budget, but does not eliminate either amplitude or duration issue.

Thus an actual comparison cancelling the amplitude term using the original retained acceptance, and converting its remaining shape forcing to the square-weighted energy, is still missing. Equations (1)–(5) do not establish it. This agrees with the explicit limitation already recorded in R408 §3 and does not count that limitation as a new negative result.

## 5. Actual bounded computation

The designated local Python ran `r448_mainproof_check.py`; stdout is `r448_mainproof.result.txt`. Three fixed rational clipping schedules passed **31 Fraction assertions**: (1) a capacity-crossing deletion with zero terminal and positive deletion cost; (2) nonzero initial clipping and an occupancy crossing through s to zero; (3) a nonzero terminal and level-dependent acceptance. It checks (2)–(5) exactly and includes a retained density rising while its envelope falls. Three additional exact assertions verify proportional positive-mass deletion with unchanged normalized law and nonzero amplitude/capacity-jump charge.

These are clipping/current-interface algebra checks, not native cube fields or full-history certificates. In the first schedule the envelope cost 7/12 is entirely the positive deletion term despite zero final occupancy. This illustrates the accounting necessity of that term, not a counterexample to the general geometric target. No further search was undertaken.
