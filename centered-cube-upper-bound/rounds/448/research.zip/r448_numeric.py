#!/usr/bin/env python3
"""Exact sequence-only audit. No geometry, original-stage records, or LP."""
from fractions import Fraction as Q
from pathlib import Path
import json, platform, sys
ROOT = Path(__file__).resolve().parent
CASES = [
    dict(name='nonzero_initial_and_terminal', f='7/2', T=['1/4','1','2','4'], u=['5','4','3'], c='1'),
    dict(name='jump_across_threshold_zero_terminal', f='5', T=['0','1/2','3/2','3','6'], u=['3','5/2','1/3','0'], c='1'),
    dict(name='zero_load_tail_zero_capacity', f='11/4', T=['1/5','3/5','6/5','2','3'], u=['7/5','3/5','0','0'], c='0'),
]
checks = 0
def check(b):
    global checks
    assert b
    checks += 1

def run(spec):
    f, c = Q(spec['f']), Q(spec['c'])
    T, u = list(map(Q,spec['T'])), list(map(Q,spec['u']))
    N = len(u)
    check(len(T) == N+1)
    check(f >= 0 and c >= 0 and all(t >= 0 for t in T))
    check(all(T[i] <= T[i+1] for i in range(N)))
    check(all(x >= 0 for x in u) and all(u[i] >= u[i+1] for i in range(N-1)))
    F = [min(f,t) for t in T]
    v = [max(Q(0),x-c) for x in u]
    stage, jumps = [], []
    for i in range(N):
        delta = F[i+1]-F[i]
        check(delta >= 0)
        scalar = []
        for fraction in (Q(0),Q(1,2),Q(1)):
            g = fraction*u[i]
            left = max(Q(0),g-c)
            middle = g*max(Q(0),1-c/u[i]) if u[i] else Q(0)
            check(left <= middle <= v[i])
            scalar.append(dict(g=g, positive_part=left, product=middle, envelope=v[i]))
        stage.append(dict(i=i+1, Fprev=F[i], F=F[i+1], deltaF=delta, u=u[i], v=v[i], contribution=delta*v[i], scalar=scalar))
        if i < N-1:
            drop = v[i]-v[i+1]
            integral = max(Q(0),u[i]-max(u[i+1],c))
            check(drop >= 0 and drop == integral)
            jumps.append(dict(i=i+1, drop=drop, threshold_integral=integral, F=F[i+1], deletion_cost=F[i+1]*drop))
    lhs = sum((r['contribution'] for r in stage),Q(0))
    terminal, initial = F[-1]*v[-1], F[0]*v[0]
    deletion = sum((r['deletion_cost'] for r in jumps),Q(0))
    rhs = terminal-initial+deletion
    check(lhs == rhs)
    check(lhs-deletion == terminal-initial)
    check(lhs-(terminal-initial) == deletion)
    return dict(**spec, F=F, v=v, stages=stage, jumps=jumps, lhs=lhs, terminal=terminal,
                initial=initial, deletion=deletion, rhs=rhs,
                lhs_minus_deletion=lhs-deletion,
                wrong_rhs_if_deletion_discarded=terminal-initial,
                omission_error=deletion)

results = [run(s) for s in CASES]
check(results[0]['terminal'] > 0 and results[0]['initial'] > 0)
check(results[1]['terminal'] == 0 and results[1]['lhs'] > 0 and results[1]['deletion'] > 0)
check(Q(CASES[1]['u'][1]) > Q(CASES[1]['c']) > Q(CASES[1]['u'][2]))
check(results[2]['stages'][-1]['u'] == 0 and results[2]['stages'][-2]['u'] == 0)
output = dict(scope='exact sequence interface only; no original geometry/history or root-cost bound',
              executable=sys.executable, python=platform.python_version(), arithmetic='fractions.Fraction; exact, no rounding',
              cases=len(results), stages=sum(len(x['u']) for x in results), checks=checks, results=results)
def encode(x):
    if isinstance(x,Q): return str(x)
    raise TypeError(type(x).__name__)
(ROOT/'r448_numeric_certificate.json').write_text(json.dumps(output,default=encode,ensure_ascii=False,indent=2)+'\n')
print('executable:',sys.executable)
print('python:',platform.python_version())
print('scope:',output['scope'])
for r in results:
    print(r['name'], 'lhs=',r['lhs'],'terminal=',r['terminal'],'initial=',r['initial'],'deletion=',r['deletion'],'rhs=',r['rhs'])
print('PASS:',len(results),'cases,',output['stages'],'stages,',checks,'exact checks')
print('certificate: r448_numeric_certificate.json')
