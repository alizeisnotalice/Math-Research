# R449 — checking whether terminal mass loss supplies the missing demand discount

**Result.** No additional payment for the original \(D_{\rm free}\) is proved.
The bounded attempt tested a specific proposed bridge: obtain a demand
discount in the parent/terminal mass ratio from the original strict
mass-decreasing path, then compare it with the nonradial capacity in the
parent's `r449_rearrangement.md`. The unfiltered path does not provide this
discount by its known rank estimates. The exact last-transition formula
below identifies the missing acceptance-dependent step. This conclusion
is not a counterexample to the full geometric target.

## 1. The quantitative comparison being tested

Use the unchanged R447 projected demand \(\widetilde g\), its actual source,
stage and future labels, and the full matched masses. Put
\[
B=\frac{m_A}{K^2m_v}>1,\qquad
\alpha_0=K^{2/n}=\exp(2/\sqrt n).
\]
The parent establishes the optimal nonradial capacity for the class
\[
0\le\kappa_A\le1,\qquad
|\{w:\kappa_A(w,v)>t\}|\le K^2R_v^n/t,\quad 0<t<1.
\]
Its proved strength bound, used here without repeating that proof, is
\[
\sqrt n\,k^\kappa_{Ae}(v)
\le B_e\frac{\varepsilon_0\sqrt n}{s}\,
              \frac{1+\log(A_nB)}{B}.
\tag{1}
\]
No factor \(\lambda/q\) is needed. Formula (1) is a capacity
**upper** bound, not a bound on the original demand.

The construction would yield pointwise coverage if the actual retained
demand obeyed a compatible bound relative to the **achieved** capacity.
An upper bound on \(\widetilde g\) with just the right side of (1) would
not itself suffice, since (1) is not a lower bound on capacity.
The question examined here was whether strict descent at least supplies
the required mass-ratio decay of the actual demand. A global source
comparison could succeed without such pointwise decay; it is not
declared a necessary condition for the original theorem.

## 2. Exact last-transition formula, with the kernel scope checked

The archived original unfiltered kernel is explicitly
\[
P_x(u,dv)=
\frac{1_{\{m_v<m_u/K\}}\rho_x(dv)}{Z_u(x)},\qquad
\rho_x(dv)=c_v(x)\frac{dv}{m_v},
\quad Z_u(x)>h.
\tag{2}
\]
See `r431_main.md` §1, also `r423_geometry.md` §1.
The parent-near exclusions, low-risk tests and other future masks are
restrictions of the generated paths, not factors in (2).
This distinction is essential to the statement below.

Fix the original parent, the fixed source \(x\), all initial-record
parameters, and their subprobability initial law \(Q_0\), supported on
\(Z>h\). Generate by (2), stopping at the first \(Z\le h\).
Let
\[
\mathcal G_x(du)=
\mathbb E_{Q_0}\sum_{j<T}1_{\{V_j\in du\}}
\]
be its active visit measure. The positive lower and upper mass bounds
and strict \(K\)-descent give finite depth; this is used only to justify
the finite sum, not to charge a source budget.
There is no initial terminal atom because \(Q_0\) is own-high.

Disintegrating by the unique last transition gives the exact terminal law
\[
Q^{\rm term}_x(dv)
=1_{\{Z_v(x)\le h\}}\rho_x(dv)
 \int_{\{m_u>K m_v\}}\frac{\mathcal G_x(du)}{Z_u(x)}.
\tag{3}
\]
All denominators in this integral are \(>h\). Equation (3) also applies
to a subprobability start: total terminal mass equals the entering mass.
Strict inequalities retain mass atoms correctly.
Against the raw terminal hat \(1_{\{Z_v\le h\}}\rho_x/h\), its density is
\[
r_x(v)=h\int_{\{m_u>K m_v\}}
                 \frac{\mathcal G_x(du)}{Z_u(x)}.
\tag{4}
\]
For this unfiltered law, on receivers capturing the fixed source and
satisfying own-low, (4) is a nonincreasing function of \(m_v\).
Making the terminal mass smaller enlarges the integration set.
Thus the known raw path normalization and rank Green estimate cannot
be read as a decay of this density like \(\log B/B\).
Probability of a set of small terminals still includes its real
\(\rho_x\)-measure; it must not be confused with this density.

**No monotonicity of the original \(\widetilde g\) is asserted.**
If the proper-near or other future conditions are kept in the last-jump
integral, they contribute a terminal-dependent acceptance factor inside
the integral. Then (4)'s mass monotonicity need not hold. The original
demand has precisely these factors. Dropping them yields a valid
positive upper envelope, but loses the possible mechanism that could
give the required decay. Neither a refreshed source nor a new history
qualification is used in (3).

The specific missing comparison is therefore an integrated control of
that **actual acceptance factor**, weighted by the last-transition
measure in (3), on large-\(B\) columns of insufficient achieved
parent-overlap capacity. The existing rank moment and whole-terminal
hat alone do not give it.

## 3. Brief signed-mass-gap check

In the already certified R443 notation, \(u\) is the cumulative
**actual** accepted overlap, \(0\le u\le m_v\), and
\[
U=\int u[1+\log(m_A/u)]\,d\nu_{\rm ent}-\mathcal F,
\]
where \(\mathcal F\ge0\) denotes the existing fit, parent and terminal
defects, counted once. Because the mass ratio is constant on this
fiber, its exact original contribution is
\(\int u\log(m_A/m_v)d\nu_{\rm ent}\). Subtraction gives
\[
U-\int u\log(m_A/m_v)d\nu_{\rm ent}
=\int u[1+\log(m_v/u)]\,d\nu_{\rm ent}-\mathcal F.
\tag{5}
\]
At \(u=0\) use the continuous zero convention. The archived finite-field
integrability conditions justify this subtraction; it is not
\(\infty-\infty\).
The parent mass cancels exactly. Consequently replacing the old coarse
\(2\sqrt n\) mass-gap estimate by the full gap does not by itself create
an additional coercive coefficient. A useful proof would still need a
global comparison with the remaining actual acceptance entropy and
defects. Equation (5) is a scope check on this attempted route, not a
new identity being sold as a payment or a second capture-square credit.

## 4. Computation and decision

The specified local Python ran `/tmp/r449_geometry_check.py`; stdout is
`/tmp/r449_geometry.result.txt`. SymPy verifies the scalar cancellation
in (5). Three small Fraction strict-mass-prefix models verify the last
transition identity, total terminal mass, and the monotonicity in (4),
including strict-cut equality cases. They test the unfiltered kernel
algebra only: they are not actual Lebesgue cube fields and do not satisfy
or test the complete original future/history contract.

The next useful calculation would retain actual future acceptance while
comparing its last-transition density with the achieved nonradial
parent-overlap capacity. More tests of the raw terminal law, or more
optimization within the same capacity class, cannot certify that
comparison. No new branch is paid here; the original \(D_{\rm free}\)
and all mother-ledger coefficients remain unchanged by this attachment.
This bounded attempt stops.
