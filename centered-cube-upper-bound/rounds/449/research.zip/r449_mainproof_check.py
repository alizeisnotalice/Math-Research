"""Finite clipping/current algebra only; no native history or capacity realization."""
import sympy as S
Q=S.Rational
t=S.Symbol('t',positive=True)
atoms=[(Q(1),Q(2),1,1,0),(Q(1,2),Q(5),1,1,1),
       (Q(1,3),Q(40),1,0,0),(Q(2,3),Q(3),0,1,1)]
breaks=list(map(Q,[0,1,2,3,5,40]))
M=sum(v*f for v,f,a,b,c in atoms if a)
m=sum(v*f for v,f,a,b,c in atoms if b)
p=[sum(v*f for v,f,a,b,c in atoms if b and c==j)/m for j in range(2)]
def mass(cell,side,lo):
    return S.expand(sum(v*(f if f<=lo else t) for v,f,a,b,c in atoms if (a if side=='A' else b) and (cell is None or c==cell)))
def lint(x,lo,hi):
    x=S.expand(x);a=S.diff(x,t);b=x.subs(t,0)
    if a==0:return (hi-lo)*S.log(b)
    def F(r):
        y=S.simplify(a*r+b)
        return Q(0) if y==0 else (y*S.log(y)-y)/a
    return S.expand(F(hi)-F(lo))
def zero(x):return S.simplify(S.expand_log(S.expand(x),force=True))==0
checks=0
def ck(x):
    global checks
    assert x;checks+=1

def run(table):
    cum=[Q(0),Q(0)];J=bulk=ep=et=cap=Q(0)
    for j,(lo,hi) in enumerate(zip(breaks,breaks[1:])):
        A=mass(None,'A',lo)
        for C in range(2):
            rate=sum(v*table[j][C] for v,f,a,b,c in atoms if a and b and c==C and f>lo)
            if not rate:continue
            X,Y=mass(C,'A',lo),mass(C,'V',lo)
            cc=cum[C]+rate*(t-lo)
            ia,ix,iy,ic=[lint(x,lo,hi) for x in [A,X,Y,cc]]
            length=hi-lo
            J+=rate*(ia+iy-ix-length*S.log(m))
            bulk+=rate*(length*S.log(M)-ia)
            ep+=rate*(ix-ic)
            et+=rate*(length*S.log(m*p[C])-iy)
            cap+=rate*(ix-iy)
            cum[C]+=rate*length
    u=sum(cum)
    if not u:return u,Q(0),Q(0)
    fit=sum(x*S.log(x/(u*p[C])) for C,x in enumerate(cum) if x)
    GM=u*(1+S.log(M/u));Gm=u*(1+S.log(m/u))
    ck(zero(J-(GM-fit-bulk-ep-et)))
    ck(zero(fit+ep+et-Gm-cap))
    ck(zero(u*S.log(M/m)-bulk-J-cap))
    return u,GM,cap
patterns=[[[Q(1),Q(1)] for _ in range(5)],
 [[Q(1),Q(1)],[Q(1,2),Q(1)],[Q(1,2),Q(1,3)],[Q(0),Q(1,3)],[Q(0),Q(0)]],
 [[Q(0),Q(1,4)],[Q(2,3),Q(0)],[Q(0),Q(3,4)],[Q(0),Q(1,5)],[Q(0),Q(0)]]]
for j,pat in enumerate(patterns,1):
    residual=[[max(Q(0),x-Q(1,4)) for x in row] for row in pat]
    u,GM,cap=run(pat);v,GMr,capr=run(residual)
    d=u-v;x=d/u
    phi=x+(1-x)*S.log(1-x) if x<1 else Q(1)
    ck(zero(GM-GMr-d*S.log(M/u)-u*phi))
    ck(0<=d<=u)
    print('case',j,'parent/terminal masses',M,m,'original/residual/removed',u,v,d)
    print(' exact full-defect cancellation and reference-gain identities PASS')
print('PASS',checks,'exact symbolic/Fraction assertions; no floating sign evidence.')
print('Scope: three finite full-f clipping tables and synthetic column clipping; no native selector/history certification.')
