#!/usr/bin/env python3
"""Finite genuine packet/cube field, plus exact finite capacity rearrangement."""
from fractions import Fraction as Q
from pathlib import Path
import json,sys,platform
import sympy as sp
from flint import arb,ctx
ctx.prec=256
ROOT=Path(__file__).resolve().parent
checks=0
def ck(x):
 global checks
 assert x
 checks+=1
def ar(x): return arb(x.numerator)/x.denominator
K=arb(2).exp()
ck(K>arb(7) and K<ar(Q(37,5)))
# General top-rank primitive when total volume M >= budget B.
r,B,M=sp.symbols('r B M',positive=True)
primitive=B+sp.integrate(B/r,(r,B,M))
ck(sp.simplify(primitive-B*(1+sp.log(M/B)))==0)

def case(R,subdiv,v):
 # Uniform packets: every listed terminal cell has a fixed complete capture set.
 packet_half=R/100
 packets=[(Q(0),Q(100))]+[(Q(sign*k*14,100),Q(1)) for sign in (-1,1) for k in range(1,7)]
 packets += [(1-R/5,Q(1)),(1+R/5,Q(3))]+[(Q(x,10),Q(2)) for x in (13,16,19)]
 ck(all(abs(x-y)>2*packet_half for k,(x,m) in enumerate(packets) for y,mm in packets[k+1:]))
 parent_mass=sum((m for x,m in packets if -1+packet_half<=x<=1-packet_half),Q(0))
 ck(parent_mass==113)
 cells=[]
 for sign in (-1,1):
  for k in range(1,7): cells.append((Q(sign*k*14,100),2*R/5,'inside'))
 cells.append((Q(1),R/5,'mixed'))
 cells += [(Q(x,10),2*R/5,'outside') for x in (13,16,19)]
 ck(all(abs(x-y)>hx+hy for k,(x,hx,l) in enumerate(cells) for y,hy,ll in cells[k+1:]))
 # The fixed parent also has a positive-volume center block: halfwidth R/20.
 ck(all(abs(x)+R/20+packet_half<1 or abs(x)-R/20-packet_half>1 for x,m in packets))
 native=[]
 for center,half,label in cells:
  cap=[]
  for x,m in packets:
   # Whole center block captures full packet or misses it with strict margin.
   captures=abs(x-center)+half+packet_half < R/2
   misses=abs(x-center)-half-packet_half > R/2
   ck(captures or misses)
   if captures: cap.append((x,m))
  mass=sum((m for x,m in cap),Q(0))
  overlap=sum((m for x,m in cap if abs(x)+packet_half<1),Q(0))
  ck(mass>0 and ar(mass)*K<ar(parent_mass))
  H=overlap/mass
  ck(H=={'inside':Q(1),'mixed':Q(1,4),'outside':Q(0)}[label])
  native.append(dict(center=center,halfwidth=half,volume=2*half,mass=mass,overlap=overlap,H=H,label=label))
 # v is an actual positive-volume terminal cell center with m_v=1,R_v=R.
 ck(any(a['center']==v and a['mass']==1 for a in native))
 budget=7*R # strictly smaller than actual K^2 R, verified with Arb
 atoms=[]
 for a in native:
  for k in range(subdiv):
   atoms.append(dict(H=a['H'],volume=a['volume']/subdiv))
 atoms.sort(key=lambda a:a['H'],reverse=True)
 rank=Q(0); gain=Q(0); atoms_out=[]
 for a in atoms:
  rank+=a['volume']; weight=min(Q(1),budget/rank)
  gain+=a['H']*a['volume']*weight
  atoms_out.append(dict(**a,rank=rank,kappa=weight))
 # Every distinct superlevel has at most its rank-prefix volume; strict/closed
 # endpoints are safe because rank*kappa<=budget. Also inspect every prefix.
 for a in atoms_out: ck(a['rank']*a['kappa']<=budget)
 for a,b in zip(atoms_out,atoms_out[1:]): ck(a['kappa']>=b['kappa'])
 # Bathtub: independent budget b top-H exact selection including split cell.
 left=budget; top=Q(0)
 for a in atoms:
  take=min(left,a['volume']);top+=take*a['H'];left-=take
 ck(left==0 and top==budget)
 # Certified upper bound on actual radial psi for every whole block.
 # n=1, identical terminal lengths, psi=min(1,e^2 R/(2|w-v|)).
 radial_upper=Q(0)
 for a in native:
  distance=max(Q(0),abs(a['center']-v)-a['halfwidth'])
  weight=Q(1) if distance==0 else min(Q(1),Q(37,5)*R/(2*distance))
  radial_upper+=a['H']*a['volume']*weight
 ck(gain>radial_upper)
 high_volume=sum((a['volume'] for a in native if a['H']==1),Q(0))
 mixed_volume=sum((a['volume'] for a in native if a['H']==Q(1,4)),Q(0))
 # Exact ideal weak-L1 optimum on H-levels: integral H*(r)*min(1,B/r) dr.
 ideal=ar(budget)*(1+(ar(high_volume)/ar(budget)).log())+ar(budget)/4*((ar(high_volume+mixed_volume)/ar(high_volume)).log())
 ck(ideal>ar(gain))
 totalvol=sum((a['volume'] for a in native),Q(0))
 # Top-rank kernel volume envelope, not an assertion of the global source price.
 volume_envelope=ar(budget)*(1+(ar(totalvol)/ar(budget)).log())
 return dict(R=R,receiver=v,subdiv=subdiv,parent_mass=parent_mass,actual_K2=str(K),budget=budget,
   total_volume=totalvol,high_volume=high_volume,mixed_volume=mixed_volume,cells=native,
   atoms=atoms_out,rearranged_gain_lower=gain,radial_gain_upper=radial_upper,
   strict_improvement_lower=gain-radial_upper,ideal_gain_interval=str(ideal),
   kernel_volume_envelope_interval=str(volume_envelope),top_budget_capture=top)
results=[case(Q(1,10),2,Q(84,100)),case(Q(1,10),4,Q(14,100)),case(Q(3,25),8,Q(84,100))]
# Dimension/massgap coefficient: symbolic M>=V branch, retaining all inputs.
x,a,b=sp.symbols('x a b',positive=True)
ck(sp.simplify(sp.diff((1+sp.log(a*x))/x,x)+sp.log(a*x)/x**2)==0)
# Saturated global layercake primitive (regime x>=1).
t,xpos=sp.symbols('t xpos',positive=True)
ck(sp.simplify(sp.integrate(xpos,(t,0,1/xpos))+sp.integrate(1/t,(t,1/xpos,1))-(1+sp.log(xpos)))==0)
coefficients=[]
for n,rAn,Bmass in [(16,Q(2),Q(2)),(64,Q(8),Q(16)),(256,Q(32),Q(256))]:
 root=arb(n).sqrt()
 value=root/(1+root)*(1+(ar(rAn*Bmass)).log())/ar(Bmass)
 ck(value>0)
 coefficients.append(dict(n=n,rAn=rAn,Bmass=Bmass,coefficient_after_dividing_Be_eps0=str(value)))
out=dict(scope='finite capacity model with exact native packet masses; not original full history/octave contract',
 executable=sys.executable,python=platform.python_version(),sympy=sp.__version__,arb_precision_bits=ctx.prec,
 checks=checks,cases=results,normalized_massgap_coefficients=coefficients,
 symbolic_top_rank_integral=str(sp.simplify(primitive)),
 massgap_coefficient='Be*eps0*sqrt(n)/s * (1+log(r*An*Bmass))/Bmass; M<V use M, no demand coverage inferred')
def encode(x):
 if isinstance(x,Q):return str(x)
 raise TypeError(type(x).__name__)
(ROOT/'r449_numeric_certificate.json').write_text(json.dumps(out,default=encode,indent=2)+'\n')
print('executable:',sys.executable,'Python:',platform.python_version(),'SymPy:',sp.__version__,'Arb bits:',ctx.prec)
for i,c in enumerate(results,1):
 print('stage',i,'R=',c['R'],'v=',c['receiver'],'subdiv=',c['subdiv'])
 for key in ('rearranged_gain_lower','radial_gain_upper','strict_improvement_lower','ideal_gain_interval','kernel_volume_envelope_interval'): print(' ',key,'=',c[key])
for a in coefficients: print('normalized_massgap_coefficient:',a)
print('PASS',checks,'checks; 3 fixtures; no original-history certification')
print('certificate: r449_numeric_certificate.json')
