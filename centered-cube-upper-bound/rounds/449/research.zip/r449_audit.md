# R449 independent final audit

FINAL PASS（限定范围）：通过实际中心逐列体积重排、可测达到及其directed容量价、旧核union的一次原流拉回与完整母账；通过同一Pf的loggap全缺陷抵消、凹性增益界及未过滤last-jump公式的范围。未证明Dfree/Dunion来源预算、原需求深度衰减或一般根阶弱型闭合。无必要修复项。以下绑定最终14文件，独立PRE及受邀理论审读保留。

## 1. 非径向重排与原receiver资格

H_A=1_masscut I_Aw/m_w∈[0,1]为实际E上的完整匹配密度，其正支撑在有限真实中心盒内，M=∫H_A≤m_AAn/q。逐列Leb超水平帽|{κ>t}|≤V/t，V=K²R_vⁿ，正layercake/bathtub给精确最优∫H_A*(r)min(1,V/r)dr。按H递减、等值层按w₁的rank可达：有限正支撑与Leb超平面零测使rank均匀，两个定义积分联合可测；零H/rank约定完整。只是对实际中心排序，未独立积分选择半径、未将cell体积当来源密度。

用I_Aw≤m_w后施固定v的体积帽，directed Q-CDF≤1/(q²t)，再与total≤An²/q²积分给Ψ价；此核非对称，常数1正确，不重复旧distance union2。source/freecap仍是ΣB_e=S一次，clipping一次。真实X≤AnW给C=√n的source价Sε₀²√nΨW。T(M,V)同时对M,V单调，插入M≤m_AAn/q、V≤K²m_v/q得到[1+log(An B)]/B强度，无r。它是该明确体积帽类的供给上界，不是actual需求或取得供给的下界。

新κ*未证明逐列胜旧ψ，所以k_union=kfree+k*而非替换旧核后声称单调改善。same pooled gtilde、ν及base不变；列min及RN乘原P只一次，Dunion≤Dfree。来源价Φ+Ψ是两容量的联合上价，旧Φ不再额外重扣。未赋辅助w原history或反用cheapplan成本方向。

## 2. 同流质量差、缺陷及last-jump

原R425 K²支持及后续正限制给Pf实际newterminal log(m_A/m_v)>2√n；α₀=exp(2/√n)，α₀ⁿ=K²正确。Pf=bfreeP保完整history，θf≤θ但无level单调假设。其实际累积c、Fit、Eparent、Eterminal与signedCap同流重算；逐fiber G_mA(u)=u log(m_A/m_v)+G_mv(u)使质量差精确抵消，(1)等价(2)。不能只改G而保旧负缺陷值。

零u和所有primitive连续约定完整。固定原q aⁿ正下界、finite X/E及已证capture绝对可积支持各截断极限：例如entropy参考ν下∫m_A dν由固定m_min和有限E控制，G_mA(u)≤m_A；结合Cap可积与非负缺陷，未作∞−∞。这只保证合法性，不收取隐藏root费用。

凹性φ(x)=x+(1−x)log(1−x)满足x²/2≤φ≤x，故额外gain≤原已移除mass≤ΩcolW；是有利量的上界，非Dfree付款。原旧loggap已计入线性项，同缺陷抵消后不剩新的2√n净强制项。

last-jump(3)/(4)仅是原unfiltered固定source strict-K过程。initial own-high排除初始terminal Dirac，finite positive massband保证finite active visit和，strict cut保质量原子。相对ρ_low/h的raw密度随terminal质量非增，绝非对原gtilde的单调结论。proper-near、early、paired/future等原限制含terminal依赖接受核；删除它们得到上包络，不能再将该包络的单调或generation衰减转授actual需求。严格K下降给可能代数上限，不能反推大质量差必经多代。附件保留了此关键限制，没有泛称原需求无深度衰减。

## 3. 原母账与范围

root将原64Λ₀Fhat R槽替为64Λ₀Fhat{Sε₀²√n[Φ+Ψ]W+Dunion}，或保R447较低Φ价及Dfree，均是替代账。原C433/V433、初始/跳跃/删除/尺度及其余入口费用保持。未核Dunion≤εX+QεW及最终ε吸收，不能称新核完成目标。mainproof/geometry没有新增原付款，只有root非径向capacity扩展的已证费用接口。

## 4. 实际复现与数值范围

指定 `/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python` 在新目录 `/var/folders/lq/2c4qbz2n0354_tnttkv_qsz00000gn/T/r449_audit_isolated_3hnxcy2l` 实际复跑三脚本，三stdout及numeric生成JSON逐字节一致。未改作者代码、结果或资源；复现不增加样本覆盖。

mainproof 24 exact SymPy/Fraction断言为3有限clipping表及人工残余，几何为scalar cancellation和3有限原子prefix核；均不认证native全history。numeric 1436检查涵盖3明确一维packet/cube场的完整质量113、真实正w-center cell全捕获/排斥、sorted step核的连续weak-L1容量、radial整w块有理upper与重排Fraction lower。固定v列为真实receiver cell中心，未将其当全v块积分或原flow实例。目标∫Hκdw有体积单位，不误当概率；step核是可行lower，非连续最优本身。

数值parent/terminal不在同一octave，未实现原stage/rank/history，尽管单独strict masscut成立仍不能代入原native全预算。报告明确M=∫H与总体积L不同；已计算rAn强度表只核早期较弱式，最终解析log(An B)无r，未以旧数表冒充最终常数。全局几何与深度预算不由有限改善推断。

## 5. SHA256 byte bindings

- `r449_main.md`: `8131ec223858360cf8cc2d9ab26105a7b52a80ef085f5ce34448d2ecba2b6795`
- `r449_rearrangement.md`: `c0353cf10968dff7ba546366ff2e36ea78c06a7d0eecd2efb451347f5ee050dc`
- `r449_geometry.md`: `2b36e6474d26afee4c77cfe68eeeaffcec7b02c77138dee61605baf32addef40`
- `r449_geometry_check.py`: `3c6bf79e2fbf9658d12567de5ad0926dd7bc73df40e612e36ea2a9eb24f530e0`
- `r449_geometry.result.txt`: `87147a90a996dd78ab4c2f30377b73d152b2e8451f846f8b2eb33c3f43b6a92d`
- `r449_mainproof.md`: `d6e676d416bd638e2037d9985e6c70e3e0f541f5ab797842a60b2979559e6e52`
- `r449_mainproof_check.py`: `f1977052609ad9949dc5c74470ec89c8928d5561540b012501e69914219bc29b`
- `r449_mainproof.result.txt`: `3ec07e2b6ba69c175f5a9edc1fbfc6c9f59f7a71eaebb94440be380829860fa6`
- `r449_numeric.md`: `26a0ee9a4093129cc2718dc2a8c0302dda35cb604858502ef75a1a39277463e0`
- `r449_numeric.py`: `9a42321acc077043d7b1eba5b99c5a5ffdc6608b15ea9f21afa97046ae0f0237`
- `r449_numeric_certificate.json`: `2144cd74b543449054f5f08dce56d66f05ec9ad358fe9761719e049367adfef6`
- `r449_numeric_run.txt`: `5481f4da47e96ffc58aac7b26affd150967a2be546c20ff05cfc912a1e63fb4d`
- `r449_numeric_resources.txt`: `e14bcfd57d80b324ba6ddb6e761b2c9adea06f797b8dc40f445badfef1071e27`
- `r449_compute_index.md`: `41a5aa8d157aae13d4693e0aba7edc021c0cd48f086fa34ddb8d1c61a4c35ac4`

## 6. 独立 PRE 及受邀理论审读留档

# R449 independent audit — PRE

PRE ONLY。独立先读R447 mainproof、R448 main，并只为核原质量门读取R425 main§4(7)、R428 main§1/3；未读本轮作者新稿。冻结目标仍是同一Dfree≤εX+Cε√n polylog(n+2)W，以下没有证明新几何矩或全付款。

## 1. 原质量差确实在实际流上成立

记ℓ₀=√n、K=e^ℓ₀。R425原第二软权正支已使两条真实固定来源链的全部initial、proper及terminal节点m_u<m_A/K²，后续R433及R447 RN拉回只是原记录的正限制，不修改生成核。R428原初始active说明终端包含至少一次proper步；其更强κ_j门也保留，但本PRE仅使用已足够的K²门。因此对原新终端v及原P的任何正部分都有

ℓ_m(A,v)=log(m_A/m_v)>2√n，

从而可用≥2√n作积分下界。ρ/质量原子或严格门等号不会削弱这个非严格下界；严格门全空时结论仅为零流，不提供非空资格。free辅助w本身按定义保masscut，但不因此得到原history，不能把它与实际v路径等同。

原中心边长同一octave，完整匹配给ℓ_m=log(q_A/q_v)+nlog(R_A/R_v)≤ℓ_max:=log(λ/q)+nlog(b/a)<∞。故此非负对数矩在有限原P及其正部分上可积，无需额外∫f logf假设。此为合法性及粗界，不是新root价格。

必须防摘要错误：α₀=K^(2/n)=exp(2/√n)，α₀ⁿ=K²=exp(2√n)，而不是α₀=exp(2√n)。距离Δ=2||w−v||∞/max(R_w,R_v)已是无量纲。

## 2. 需要支付的真实对数矩

保原pooled记录θ=(e,A,z,t)，
𝓛=Σ_eσ(dA)c_A(z)1_{f(z)>t}dzdt/m_A，
ν_{Az}(dv)=1_{ownlow(z),m_v<m_A/K²}c_v(z)dv/(hm_v)，
q_free(θ,v)=(gtilde(θ,v)−√n kfree_Ae(v))_+。

原P上的残余乘子为r_free=q_free/gtilde（gtilde=0取0），故精确Dfree=∫q_free dνd𝓛=∫r_free dP。对数矩必须是

J_log=∫ℓ_m(A,v) q_free(θ,v) ν_{Az}(dv)𝓛(dθ)
     =∫ℓ_m(A,v) r_free dP，
2√n·Dfree≤J_log≤ℓ_max·Dfree。

这是同一原不足列的质量矩，不是以μfree或自由静态g替换需求的矩。其意义是：若实际证明

J_log≤2ε√n X+2Cε n log^A(n+2)W，

便得到冻结目标。该上界目前未证，不能仅凭loggap下界、有限性或一个raw capacity上界获得。原R448 envelope只给J_log≤ℓ_max(1+ε₀)SX，仍无所需小ε/来源节省。

质量对数与oldsource y、oldterminal w无关，故原精确pooling保持这个矩；但实际gtilde仍保全部y-dependent接受/历史。ν必须继续为共同(A,z)帽，不能平均不同底测度下的数值密度。

## 3. 合法的联合几何换序

J_log的被积量非负，Tonelli允许先t、z或真实A/v中心积分，须完整保q_free、ν的ownlow、完整m_A/m_v及σ=q_A dA。固定t所属原stage i(t)后，R448真实表达是gtilde=d_i(z)∫π_A a_i^e κ_i，κ_i≤1来自原path概率合同；不允许仅用rawμν推更强概率结论。

一个直接核查联合比较的精确写法是令Bad={gtilde>√n kfree}，则

J_log=∫Bad ℓ_m gtilde dνd𝓛 − √n∫Bad ℓ_m kfree dνd𝓛。

两项均有限：第一≤ℓ_max R，第二≤ℓ_max乘R447已证capacity价；在Bad上更有第二≤第一。展开kfree时旧来源已精确成为I_Aw=f(Q_A∩Q_w)，Bad不再依辅助w，故可合法按真实dw/m_w、dv/m_v、父σ、来源z及t联合积分。此处是可用的源消去，不是把gtilde或Bad刷新。capacity积分上界不能逆向用作第二项足够大的下界。

例如∫f(z)c_v(z)dz=m_v只可在其余z权独立时完全消去。当前q_free、D_i(z)、ownlow及原接受都依z；正确式仍需∫_{Q_A∩Q_v}1_{f>t}(gtilde−√n kfree)_+…dz。把它变成无权m_v或I_Av后又保原Bad/接受，会丢失关键匹配及选择偏差。receiver R_v是原单值selector，不可另积分自由半径。

## 4. 不可混淆的signed U与阶段账

当前signed Urecord=ℓ_m+log(B_vC(t)/B_AC(t))。cell比项没有固定有利符号，故U既不自动≥ℓ_m，也不自动≤ℓ_m。loggap本身不能把原U已知比较反转成J_log上界；任何captureloss、cell KL或entropy补偿都要在同一r_free P上保精确权、可积性与已收费范围。

ℓ_m不随stage改变，因此可以乘R448有限Abel恒等式；但这会保留ℓ_m F_i(v_i−v_i+1)正删除费、初始与terminal。终端零仍不能删除jump费。原nW耗散不含这些父/terminal/log权，现有Hellinger也未付幅度与duration。不能把对数门视作已提供一次1/√n净节省，除非联合矩上界确实只有O(nW)而不是O(nX)或更大。

## 5. 后审清单与完整母账

后审必须核：（i）v为实际原newterminal，非aux；（ii）K²门为原正支支持，初始active与terminal原子不丢；（iii）α₀指数及全域ψ定义；（iv）实际gtilde与pooledbase，commonν及B_e一次S；（v）positivepart不能与源平均/换序无条件交换；（vi）真实full-f质量匹配与所有receiver分母；（vii）signedcell项/初始/删除/terminal以及ε参数依赖。

若获得上节足够的J_log估计，原R433≤Ω447W+Dfree的入口只将原Dfree槽替为64Λ₀Fhat[εX+Cε√nlog^A W]，Ω447=Sε₀²√nΦ(An²)及所有旧费用仍保留，不再叠一个logmass收据；16/32层分别带相应原系数。全局ε吸收需核原剩余余额，没有由局部矩条件自动完成。

指定math-research-tools Python/SymPy实际核α₀ⁿ=K²指数、完整matching的logratio分解及U/cellratio分离恒等式。仅符号接口审查，不是native/原历史样本，不计新实验。未扫描反例或修改他人。PRE停止，等待本轮冻结作者稿再FINAL。

## 7. PRE后受邀理论审读：逐列体积重排（非FINAL）

PRE保存后，按root指令读取`/tmp/r449_rearrangement.md`。当前重排命题数学通过，范围严格限所列Lebesgue超水平体积帽类，未提供Dfree预算。

H_A(w)=1_{m_w<m_A/K²}I_Aw/m_w满足0≤H≤1，正支撑在A中心边长R_A+b的有限盒内，M=∫H≤m_AAn/q。对V=K²R_vⁿ、κ∈[0,1]且|{κ>t}|≤V/t，正layercake逐t给上界∫₀^{V/t}H*；Tonelli得最优J_A(V)=∫H*(r)min(1,V/r)dr。以H递减排序、等值层按w₁排序的rank可达：任何固定H>0等值层上w₁没有原子（超平面Leb零），有限正支撑的Leb rank推送为[0,|suppH|]均匀。rank的两个积分均对(A,w)联合可测，V_v可测；零H取κ0、rank0取κ1，未改变任何真实中心或radius。可先取原Leb可测字段的Borel版本；只改零测representative不改原积分。

单向rawQ的证明确可先用I_Aw≤m_w，再对κ>t的实际w体积施界，给

Q_A{κ>t}≤K²/(t m_A²)∫ I_Av R_vⁿ/m_v dv≤1/(q²t)。

其余用完整匹配∫far I_Av dv≤m_A²/(K²q)及total≤An²/q²。故∫κdQ≤q⁻²Ψ(An²)，Ψ(x)=x(x≤1)、1+logx(x≥1)，常数1不另乘对称union2。κ无须对称；它仅辅助free-old column，原实际g及history保持。native费ΣB_e只S一次。

重排核未证明逐列支配旧ψ；用k_union=kfree+k*保证余量不增，价格为两容量上界之和。对应是同原new-v列一次min(g,√n k_union)及一次RN拉回，不把两个独立matched质量加在原R上。新的总RHS不因此保证逐输入更小。

H≤1及质量M给J≤T(M,V)=∫₀¹min(M,V/t)dt；M≤V时T=M，否则T=V[1+log(M/V)]。T双单调，代M≤m_AAn/q、V≤K²m_v/q、B=m_A/(K²m_v)>1，得

√n k*≤B_e ε₀√n/s ·[1+log(An B)]/B。

系数无r。指定SymPy实际核该base+tail公式及h=s/(ε₀q)后的强度抵消。此上界不是反例或一般不可能性；它只限制该体积帽类的最大列供给，原实际需求尚未证明有对应B衰减。

另按root提醒保留后审警戒：last-jump表达若将原proper-near、all-node父远、paired-path/future等v依赖gate删去，所得纯mass-prefix Green积分只能是未过滤上包络。实际终端密度须保这些标记的条件核，不得从未过滤函数的小mass单调推实际g单调。作者尚未交此证明，本处不预先认证。

理论审读至此，无必要修订项；等待冻结作者/主稿与最终白名单后再FINAL。
