# R449 密度重排的有限容量证书（冻结）

候选值得计算。三个真实 packet/cube 有限容量场均证明：按父捕获密度排序的一个可行核，严格优于原全 soft 径向核，且使用更小的逐列超水平体积预算。不过重排本身不能保证覆盖实际需求；质量比带来的容量衰减仍需原需求同步折扣。本轮不认证原 history 或全局阶数。

## 1. 变分接口与一般容量价

令 H(w)∈[0,1]，有限 Lebesgue 单元总体积 L，预算 V>0，0≤κ≤1 且 |{κ>t}|≤V/t（0<t<1）。对固定体积的集合，交换低 H 与高 H 的部分，说明 top-H 集合最优。对整个 weak-L1 核约束，需要进一步按 H 的递减秩 r 排序：

`κ*(r)=min(1,V/r)`，最优值为 `∫_0^L H*(r) min(1,V/r)dr`。

这是可在单元内部切分的 Lebesgue 容量结论，不是按单元数排序。证明：任意 κ 的递减重排逐点不超过 min(1,V/r)，Hardy–Littlewood 重排后与 H* 同序配对即得上界；秩核本身满足超水平约束，故达到上界。H 并列时任意可测内部排序均可。脚本使用细分后的 step 核，其下界全为精确 Fraction，未把 step 核称为连续最优。

当 H≤1 时，按总体积给出的顶层界为 L（L≤V），或 V[1+log(L/V)]（L≥V）。SymPy 实跑核后一分支的积分恒等式；脚本里的符号 M 仅表示该总体积 L。

最终主证明使用更强的质量顶层：令 M=∫H(w)dw，则每个超水平集合上 ∫H≤min(M,V/t)，直接 layercake 得 T(M,V)=M（M≤V），或 V[1+log(M/V)]（M≥V）。这里 M 是 H 的积分，不是单元总体积 L；两者不可混用。T 对 M、V 均单调，故可分别代入其合法上界。

父候选的统一原价可直接从超水平约束恢复：若 V_v=K²R_v^n，则原真实 Q_A 行上，使用 H_w≤1、m_v≥qR_v^n 和原 matched-mass Tonelli，得 `Q_A{κ>t}≤1/(q²t)`；再与总量 `An²/q²` 取 min。因此 layercake 是 `q^-2 Ψ(An²)`，其中 Ψ(x)=x（x≤1），1+log x（x≥1）。这个一般解析推导使用原匹配假设；有限样本只核其积分算术，不能替代原假设核验。核若依 H 重排，联合可测选择仍是一般稿需要明确的条件。

## 2. 三阶段实际输入与资格

只构造一个结构化一维 packet 家族。parent Q_A=[−1,1]，R_A=2，m_A=113。每 packet 是半宽 R/100 的区间，密度为其指定质量除区间长度：

- 0 处质量100；±.14,±.28,…,±.84 各质量1；
- 1−R/5 处质量1；1+R/5 处质量3；
- 1.3、1.6、1.9 处各质量2。

所有 terminal side 均为 R。12 个 inside center cells 以 ±.14,…,±.84 为中心、半宽2R/5；mixed cell 中心1、半宽R/5；3个 outside cells 中心1.3、1.6、1.9、半宽2R/5。每 cell 内全部 packet 均严格全捕获或全不捕获，脚本逐一检查；cell/packet 均互不相交。parent 也可取以0为中心半宽R/20的正体积 center block，其完整质量仍113。

由同一个完整 f 得 inside `(m,I,H)=(1,1,1)`，mixed `(4,1,1/4)`，outside `(2,0,0)`。所有 terminal 满足真实严格质量门 `m<113/e²`，Arb 精确区间判定。没有用任意关联矩阵替代 geometry。

但 parent/terminal 不在同一个 octave，且没有原 stage/rank/soft/path/history 数据。因此这是有真实全质量的有限容量模型，**不是完整原合同模型**；不能把以下收益代入真实费用定理，不能声称原流非空或已覆盖。

每列取真实 receiver v 为 inside cell 的中心。原全 soft 径向核为 `ψ=min(1,e²R/(2|w−v|))`，两端 terminal side 相同，故没有 maxside 歧义。比较用更小预算 V=7R<e²R。H 递减排序后，每个细分 atom 取 `κ=min(1,V/累计体积)`；所有前缀均核 `体积×κ≤V`，故每个 superlevel 都合法。径向核用每个整块最短距离及严格有理 e²<37/5 得到整块上界，不是浮点近似积分。

| 阶段 | R；receiver v；每cell细分 | 重排捕获严格下界 | 径向捕获严格上界 | 严格改善下界 |
|---|---|---:|---:|---:|
| 初步 | 1/10；21/25；2 | .922555387150 | .572372182509 | .350183204642 |
| 径向压力（receiver移向内侧） | 1/10；7/50；4 | .925518543998 | .752226720834 | .173291823164 |
| 有限扩大（side及体积变化） | 3/25；21/25；8 | 1.112248948598 | .751500288459 | .360748660139 |

表中小数仅显示用，严格比较使用 JSON 中完整有理数。目标是 `∫Hκ dw`，具有 center 体积单位，故可以超过1；未将其误称概率。第一例理想连续重排值的 Arb 区间约 .928240913634；第三例约1.113889096361。step 核均低于理想值。

## 3. 质量比折扣仍是决策点

保留作者给定全部参数：`Bmass=m_A/(K²m_v)>1`，`r=λ/q`，`s=1+sqrt(n)`；在相应原 top-level 总量估计下，作者候选系数为

`√n k* ≤ B_e ε0 √n/s · [1+log(r An Bmass)]/Bmass`。

本轮只核这个早期保留 r 的较弱表达式的标量强度，不补造其原几何假设。最终主证明已由作者去掉 r：利用 T(M,V) 双单调，并代入 M≤m_A An/q、V≤K²m_v/q，得到 log(An Bmass)，无需 r。以下已运行数字仍对应早期 log(r An Bmass) 较弱界，未重算，不作为最终常数。除以 B_e ε0 后，三组明确输入 `(n,rAn,Bmass)` 的256-bit Arb 区间中心为：

| 输入 | 归一系数 |
|---|---:|
| (16,2,2) | .9545177444479562 |
| (64,8,16) | .3251127924399787 |
| (256,32,256) | .03680482848264444 |

完整带误差区间在 JSON；这些不同参数行不用于推断维数渐近。对早期较弱表达式固定 rAn，导数为 `−log(rAn Bmass)/Bmass²`（再乘固定正因子），SymPy 已核，故质量比增大时上界衰减。不能仅从“重排优于径向”推出 `gtilde≤Ck*`；仍需要实际需求随该质量比或 current/history occupancy 衰减。这条桥未闭合。

## 4. 实跑与复现

指定解释器 `/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python`，Python3.12.14，SymPy1.14.0，python-flint Arb 256 bits。1436 项检查通过。Fraction 判断全质量、捕获、排序核容量及严格收益；Arb 仅用于 e² 夹界、log及系数区间；SymPy检查一般积分/导数。实际运行 .23秒，最大RSS 74,383,360 bytes。无LP、随机或批量扫描，无 repo/他人修改。

```sh
/Users/zhengzhihao/.local/share/math-research-tools/venv/bin/python /tmp/r449_numeric.py
```

脚本将 JSON 写在自身目录；输入内置，无旧轮文件依赖。冻结白名单：`r449_numeric.py`、`r449_numeric_certificate.json`、`r449_numeric_run.txt`、`r449_numeric_resources.txt`、`r449_numeric.md`、`r449_compute_index.md`。本次最终修订仅澄清 L/M 符号及最终去 r 改进，未改脚本、证书或重跑。完成停止。
