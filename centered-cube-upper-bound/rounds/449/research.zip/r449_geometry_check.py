from fractions import Fraction as F
import sympy as sp

M, m, u = sp.symbols("M m u", positive=True)
residual = u * (1 + sp.log(M/u)) - u * sp.log(M/m) - u * (1 + sp.log(m/u))
assert sp.expand_log(residual, force=True).simplify() == 0
print("Signed exact-mass-gap cancellation: PASS")

models = [
    (F(2), F(1), [1, 3, 9, 27],
     [F(1, 2), F(1, 2), F(2), F(1)]),
    (F(2), F(1), [1, 2, 4, 8, 16, 40],
     [F(1, 4), F(3, 4), F(1, 2), F(1), F(2), F(1)]),
    (F(3), F(1), [1, 3, 9, 27, 81, 300],
     [F(1, 3), F(2, 3), F(1, 2), F(3, 2), F(1), F(1)]),
]

for number, (K, h, masses, weights) in enumerate(models, 1):
    masses = list(map(F, masses))
    count = len(masses)
    Z = [sum((weights[j] for j in range(count) if masses[j] < masses[i]/K), F(0))
         for i in range(count)]
    assert Z[-1] > h
    visits = [F(0)] * count
    active_visits = [F(0)] * count
    terminal = [F(0)] * count
    visits[-1] = F(1)
    for i in reversed(range(count)):
        if Z[i] <= h:
            terminal[i] += visits[i]
        else:
            active_visits[i] = visits[i]
            for j in range(count):
                if masses[j] < masses[i]/K:
                    visits[j] += visits[i] * weights[j]/Z[i]
    assert sum(terminal) == 1
    densities = []
    for j in range(count):
        if Z[j] > h:
            continue
        rj = h * sum((active_visits[i]/Z[i]
                      for i in range(count)
                      if Z[i] > h and masses[i] > K*masses[j]), F(0))
        assert terminal[j] == weights[j] * rj/h
        densities.append(rj)
    assert all(densities[i] >= densities[i+1] for i in range(len(densities)-1))
    print(f"model {number}: terminal mass=1, exact last-jump and strict atoms PASS; "
          f"raw densities={[str(x) for x in densities]}")
print("Scope: unfiltered finite prefix-kernel algebra only; no native cube or full future/history claim.")
