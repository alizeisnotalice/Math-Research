# R449 — strict mass loss with the full retained capture defects

**Decision.** The R447 positive residual can be inserted into the exact retained-current capture calculation without changing sources or histories. Keeping all defects reveals an exact cancellation of the parent/terminal log-mass term, not an additional root-scale gain. The extra concavity gain from the capacity removal is quantified below but does not supply a bound for the remaining demand. No new Dfree receipt is proved.

## 1. Same residual, same original labels

Let P be the complete original measure, and use the R447 projected demand gtilde and fixed parent-overlap capacity C kfree. Define

    bfree(e,A,z,t,v)=(1−C kfree_Ae(v)/gtilde(e,A,z,t,v))_+,
    Pf=bfree P,       |Pf|=Dfree,

with zero density contributing zero. This is the actual positive residual, not a new terminal law. All original source, current, stage, clock, early and future gates remain. In particular m_A>K²m_v is still valid, so ell=log(m_A/m_v)>2sqrt(n).

Use the R443 mainproof §1 positive reference ν on the fixed fiber (e,A,y,v). Its actual density θ is replaced by θf=bfree θ∈[0,1]. Neither density is assumed monotone in clipping level. For a fixed grid cell C put

    c_C(t)=∫_0^t∫_{C∩Q_A∩Q_v}1{f(z)>r}w(y,z)θf(z,r) dz dr,
    u_C=c_C(∞), u=Σ_Cu_C,
    X_C(t)=B_AC(t), Y_C(t)=B_vC(t), p_C=Y_C(∞)/m_v.

These are the exact residual cumulants. In particular 0≤u≤I_Av≤m_v, and Dfree=∫u dν. Static necessary masks w stay as in R443; none are inserted into new receivers.

## 2. Exact comparison before any positive bulk relaxation

Let G_M(x)=x[1+log(M/x)], with G_M(0)=0. Define, on this same residual,

    Fit=∫u KL((u_C/u)_C || (p_C)_C)dν,
    Eparent=∫dν Σ_C∫c'_C log(X_C/c_C)dt,
    Eterminal=∫dν Σ_C∫c'_C log(Y_C(∞)/Y_C(t))dt,
    Cap=∫dν Σ_C∫c'_C log(X_C/Y_C)dt.

The first three quantities are nonnegative; Cap is signed. The R443 primitive proof applies to arbitrary retained θf and gives the full same-flow relation

    ∫ell dPf = ∫G_mA(u)dν − Fit−Eparent−Eterminal + Cap.       (1)

It follows either by its cellwise logarithmic identity or by combining its exact bulk cancellation with the original log-mass identity. No prior BH square credit is deducted again.

At each fiber, ell is constant in z,t and

    G_mA(u)=u ell+G_mv(u).

Therefore (1) is equivalently the exact identity

    Fit+Eparent+Eterminal = ∫G_mv(u)dν + Cap.                  (2)

Thus retaining all three negative terms does not leave an extra 2sqrt(n) coefficient after the log-mass change of normalization. The mass gap remains true, but its u ell term appears on both sides **exactly**, not just in a loose inequality.

These identities are first computed on finite original receiver/grid truncations. All masses have the original positive q a^n lower bound and finite upper bound. The primitive G_mA(u)≤m_A and the existing capture integrability ensure the nonnegative terms are integrable, as in R443 §2. The original Cap is integrable by R441, and restricting to Pf preserves absolute integrability. Truncations are retained until these bounds apply; there is no infinity-minus-infinity step.

## 3. Can the newly paid capacity generate extra deletion gain?

Compare the original and residual scalar cumulants at the same fiber: u0 is the original retained total, u≤u0 is the residual, and d=u0−u is removed mass. For u0>0, x=d/u0,

    G_mA(u0)−G_mA(u)
      =d log(m_A/u0)+u0 φ(x),
    φ(x)=x+(1−x)log(1−x),  0≤x≤1.                           (3)

At x=1 take φ(1)=1; zero u0 contributes zero. Since φ'(x)=−log(1−x)≥x and (1−x)log(1−x)≤0,

    x²/2≤φ(x)≤x.                                           (4)

The first term in (3) contains the known strict mass-gap credit. The genuinely additional concavity gain satisfies

    0≤∫u0 φ(d/u0)dν≤∫d dν=|P−Pf|≤Ωcol(C)W.                 (5)

This is an **upper** bound on a favorable gain, not a bound on Dfree. It cannot supply a uniform fraction of the remaining mass. Moreover Fit, Eparent and Eterminal change together with the cumulants. Their old values cannot be kept while replacing only G_mA(u0) by G_mA(u). The exact linear signed integral is still (1)–(2).

## 4. The remaining geometric comparison and ledger direction

R441's capture argument can also be applied to Pf, since its arrival density is bounded by the original one. Its existing estimate yields

    Cap ≤ 2log_+(M*) Dfree +4r C_delta An W,

and hence

    2(sqrt(n)−log_+M*)Dfree
       ≤∫G_mA(u)dν−Fit−Eparent−Eterminal+4r C_delta An W.     (6)

This is the existing same-flow comparison on the actual R447 submeasure, not a new source receipt. Applying (2) to its right side merely returns the original weighted log-mass minus signed capture; it does not close (6).

A geometric lower control of signed capture on the capacity-deficient accepted columns, or an independent upper control of the full negative-defect combination in (6), is still missing. Full matching bounds the R447 capacity from above but supplies neither comparison. The exact residual cumulant contains the old-source low-common and current acceptance; dropping that dependence would change the problem. The scalar concavity calculation (3) does not turn that dependence into a capacity lower bound.

Accordingly there is no added mother-ledger price. The already proved Ωcol(C)W receipt and the complete Dfree term remain unchanged. This bounded mechanism is stopped because the strict mass ratio alone cancels under exact terminal normalization; further scalar mass-gap or concavity tuning cannot replace the missing actual capture comparison.

## 5. Decision for the new nonradial capacity: depth is not generation

After reading `r449_rearrangement.md`, its new deficit is a further positive restriction of the same P. The present identities remain valid there, but supply no new depth decay. In particular set B=m_A/(K²m_v). For a fixed original source z and active node u, the **unfiltered generated path's** one-step normal-terminal kernel is

    1{Z_v(z)≤h, m_v<m_u/K} ρ_z(dv)/Z_u(z).

This is exactly the transition rule in `/tmp/r431_main.md` lines 22–27. It is not the transition law conditioned on the retained future. The actual one-step contribution has an additional density omega_r(v)∈[0,1], obtained by retaining/averaging the original proper-near spatial, early, and future marks in the original acceptance measure. No such restriction is renormalized. This distinction is expressly required by that file's lines 44–71.

Relative to the original terminal hat ρ_z|own-low/h, the unfiltered density is h/Z_u(z), and the accepted contribution has density omega_r(v)h/Z_u(z). The raw factor has no further B factor; omega_r may contain additional geometric suppression, which has not been estimated here. This formula does not assert that arbitrary B is realizable in the full native history. It shows exactly that a B-dependent improvement does not follow from the whole-terminal law alone.

Strict-K descent gives m_j<m_0/K^j. Thus a large total mass ratio allows many generations but does not force them: a single allowed jump may skip intermediate mass scales. A decay with generation in the exact-j estimate therefore cannot be substituted as a decay in B. The full parent posterior and actual acceptance may impose an additional constraint, but none is established here. In particular the demand bound gtilde≤d_i s_i cannot be changed to O((1+log B)/B) without a new source/parent/current comparison. This is the precise additional mechanism needed by the nonradial-capacity candidate; no such estimate is claimed.

## 6. Actual local computation

The designated local Python ran `r449_mainproof_check.py`; output is `r449_mainproof.result.txt`. Three finite full-f clipping tables and their synthetic column-clipped residuals passed **24 exact SymPy/Fraction assertions**, checking (1)–(3) without floating sign tests. Parent/terminal masses are 107/6 and 13/2. Original/residual totals are (9/2,27/8), (3,15/8), and (41/30,2/3).

These verify the retained-current algebra, including changing all defects together. They do not realize the original native selector, K² mass gap or full history and are not evidence for the unproved global geometric comparison. Inequality (4) is proved analytically above.
