#!/usr/bin/env python3
"""R135 real product kernels, finite common-source necessary-gate screening."""
import sys,json,hashlib,datetime,time,traceback,pathlib,functools
ROOT=pathlib.Path(__file__).resolve().parent
VENDOR=pathlib.Path('/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor')
sys.path.insert(0,str(VENDOR))
import mpmath as mp
OUT=ROOT/'real_joint_numeric.json'
MENU=[('initial','I1',4,'.25','.9','.3','.8','4',1,1),('initial','I2',16,'.25','.9','.3','.8','4',1,1),('initial','I3',16,'.5','.9','.3','.8','4',1,1),('initial','I4',16,'.75','.9','.3','.8','4',1,1),('pressure','P1',32,'.25','.9','.3','.8','8',1,1),('pressure','P2',64,'.25','.9','.3','.8','16',1,1),('pressure','P3',64,'.5','.9','.3','1.5','8',1,1),('pressure','P4',64,'.75','.9','.3','1.5','16',1,1),('expanded','E1',128,'.25','.9','.3','.8','16',1,1),('expanded','E2',64,'.25','.75','.3','.8','8',2,1),('expanded','E3',64,'.5','.55','.2','.8','8',4,2),('expanded','E4',128,'.75','.9','.4','1.5','16',4,4)]
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def enc(x):
    if isinstance(x,dict):return {k:enc(v) for k,v in x.items()}
    if isinstance(x,(list,tuple)):return [enc(v) for v in x]
    if isinstance(x,mp.mpf):return mp.nstr(x,mp.mp.dps)
    return x
@functools.lru_cache(None)
def phi_cached(precision,x):
    r=abs(x); half=mp.mpf('.5')
    E=lambda k,z:mp.mpf(1)/(k-1) if z==0 else mp.expint(k,z)
    return 1-E(3,half-r)-E(3,half+r) if r<=half else E(3,r-half)-E(3,r+half)
def phi(x):return phi_cached(mp.mp.dps,mp.mpf(x))
@functools.lru_cache(None)
def prim_cached(precision,x):
    if x<0:return -prim_cached(precision,-x)
    h=mp.mpf('.5'); E=lambda k,z:mp.mpf(1)/(k-1) if z==0 else mp.expint(k,z)
    return x-E(4,h-x)+E(4,h+x) if x<=h else h-E(4,x-h)+E(4,x+h)
def mass(a,b):return prim_cached(mp.mp.dps,b)-prim_cached(mp.mp.dps,a)
@functools.lru_cache(None)
def C_cached(precision,d):
    h=mp.mpf('.5'); lo,hi=-h-d,h-d; p,q=max(lo,-h),min(hi,h)
    return mass(lo,hi)+(q-p-mass(p,q) if p<q else 0)
def Cfun(d):return C_cached(mp.mp.dps,abs(mp.mpf(d)))
def kernel(s,H,z):return mp.fprod(((1-s)*(1 if abs(v/H)<=mp.mpf('.5') else 0)+s*phi(v/H))/H for v in z)
def calc(row,precision):
    mp.mp.dps=precision
    stage,cid,n,st,Lt,yt,dt,ft,Ki,Di=row
    s,L,y0,d,far=map(mp.mpf,(st,Lt,yt,dt,ft)); K,D=map(mp.mpf,(Ki,Di))
    a=mp.mpf('.5'); b=Rhard=mp.mpf(1); eps=mp.mpf('1e-8'); u=mp.mpf('.01')
    gamma=1+mp.mpf(1)/n; g=mp.sqrt(L); j=int(mp.floor(mp.log(g/L)/mp.log(gamma))); cj=gamma**(-j)
    Lp=min(b,gamma*L); ell=1+mp.log(n); ms=1-s+s*phi(mp.mpf('.5'))
    H0=g*cj**(-mp.mpf('.5'))*ms*ell**(mp.mpf(1)/(2*n)); Hhat=max(a,min(b,H0))
    T=cj**(mp.mpf(n)/2)/(g**n*mp.sqrt(ell)); tau=a/cj; h=g*mp.exp(-u/n)
    p=kernel(s,L,[-y0]*n); positions=[[-d]*n,[-2*d]*n,[-d if i%2==0 else -2*d for i in range(n)],[d]*n,[far]*n]
    weights=[eps]*4+[1-4*eps]; names=['G1','G2','G3','G4','B']; atoms=[]
    for name,v,massnu in zip(names,positions,weights):
        thresholds=[b/cj*Cfun((y0-z)/b) for z in v]
        wt=lambda t:mp.fprod(min(mp.mpf(1),al/t) for al in thresholds)
        wg,wta,wh=wt(g),wt(tau),wt(h); A=wta-wh
        K0=kernel(s,Hhat,[-z for z in v]); K1=kernel(s,L,[-z for z in v]); K2=kernel(s,Lp,[-z for z in v]); J=kernel(mp.mpf(1),b,[-z for z in v]); Q=(K1+K2+J)/3
        good=p*wg<=K*Q; B_hard=Rhard<=L and all(abs(z)<=Rhard/2 for z in v)
        E=good and not B_hard and A>0
        U=min(T*A,D*K0) if E else mp.mpf(0)
        atoms.append(dict(name=name,v=v,nu=massnu,alpha_i=thresholds,C_i=[Cfun((y0-z)/b) for z in v],phi_x_i=[phi(z/b) for z in v],wg=wg,wtau=wta,wh=wh,A=A,R=A/wg,K0=K0,K1=K1,K2=K2,J=J,Q=Q,good=good,bad=not good,B_hard=B_hard,E=E,U=U,good_signed_margin=K*Q-p*wg,score_g=sum(al<g for al in thresholds)))
    integ=lambda key:sum(z['nu']*z[key] for z in atoms)
    eg=integ('wg'); QJ=integ('J'); q=max(integ('K0'),QJ,integ('Q')); alpha=(D*q-integ('U'))/QJ
    badK0=sum(z['nu']*z['K0'] for z in atoms if z['bad']); kappa=badK0/(T*eg)
    Cr=(Hhat/L)**n+(Hhat/Lp)**n; M=3*D*min(p/(K*T*Cr),2*kappa*q/QJ)
    high=p*eg>=2*K*q; branch=Hhat>=Lp; tol=mp.mpf('1e-65')
    for z in atoms:
        z['rhoA']=max(z['A']-(z['U']+alpha*z['J'])/T,mp.mpf(0)) if z['E'] else mp.mpf(0)
        z['rho']=z['rhoA']/z['A'] if z['A']>0 else mp.mpf(0)
        z['RG20_rhs']=max(z['A']-M*z['wg'],mp.mpf(0))
        z['R_gt_M_good']=z['good'] and z['R']>M
        z['RG17_margin']=Cr*z['K0']-z['K1']-z['K2']
        z['RG20_margin']=z['RG20_rhs']-z['rhoA']
    timelegal=tau<h<=g
    gates=dict(strict_s=s>1-mp.power(2,-mp.mpf(1)/n),tau_h_g=timelegal,D_ge_1=D>=1,K_positive=K>0,scale=a<=L<=b and L<=cj*g<=gamma*L,high=high,FIRST_three=all(integ(k)<=q for k in ('K0','J','Q')),RG16=branch)
    qualification=all(gates.values())
    flux=sum(z['nu']*max(z['A']-M*z['wg'],mp.mpf(0)) for z in atoms if z['good'])/eg
    residual=integ('rhoA')/eg
    consistency=dict(alpha_nonnegative=alpha>=-tol,
      alpha_lower=alpha+tol>=D*T*eg*kappa/QJ,
      high_bad_mass=(not high) or sum(z['nu']*z['wg'] for z in atoms if z['bad'])+tol>=eg/2,
      RG17=(not branch) or all(z['RG17_margin']>=-tol*max(1,Cr*z['K0']) for z in atoms),
      RG20=(not qualification) or all(z['RG20_margin']>=-tol*max(1,z['A']) for z in atoms if z['good']))
    return dict(stage=stage,id=cid,n=n,parameters=dict(s=s,L=L,y0=y0,d=d,far=far,K=K,D=D,a=a,b=b,R_hard=Rhard,u=u,epsilon=eps),derived=dict(gamma=gamma,g=g,j=j,cj=cj,Lplus=Lp,ell=ell,ms=ms,H0=H0,Hhat=Hhat,T=T,tau=tau,h=h,p=p,eg=eg,q=q,QJ=QJ,intK0=integ('K0'),intQ=integ('Q'),intU=integ('U'),badK0=badK0,kappa=kappa,Cr=Cr,M=M,alpha=alpha,alpha_lower=D*T*eg*kappa/QJ,high_ratio=p*eg/(2*K*q)),atoms=atoms,gates=gates,necessary_gates_pass=qualification,checks=consistency,
       statistics=dict(good_R_gt_M_nu_mass=sum(z['nu'] for z in atoms if z['R_gt_M_good']),good_R_gt_M_wg_mass=sum(z['nu']*z['wg'] for z in atoms if z['R_gt_M_good'])/eg,good_tail_flux=flux,actual_RC_residual=residual,qualified_tail_flux=flux if qualification else mp.mpf(0),qualified_RC_residual=residual if qualification else mp.mpf(0)),FULL_certified=False)
def save(data):OUT.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
def main():
    if OUT.exists():raise SystemExit('Refuse second run; retain existing record')
    sources=[ROOT/'numeric_protocol.md',pathlib.Path(__file__),ROOT.parent/'centered_cube_round133_20261014/third_numeric.py',ROOT.parent/'centered_cube_round134_20261014/receiver_rc_geometry.md',ROOT.parent/'centered_cube_round116_20261014/integration.md',ROOT.parent/'centered_cube_round116_20261014/astra_first.md']
    data=dict(status='running',run_count=1,started_utc=utc(),menu=MENU,precision_dps=[80,100],mpmath_path=mp.__file__,mpmath_version=mp.__version__,sha256={str(p):sha(p) for p in sources},scope='Actual kernels, finite common nu, necessary gates only; no FULL/history/outer measure certification',cases=[],exceptions=[])
    save(data)
    for row in MENU:
        start=time.monotonic()
        try:
            low=calc(row,80); high=calc(row,100)
            keys=['eg','q','QJ','kappa','M','alpha','high_ratio']; errors={k:abs(high['derived'][k]-low['derived'][k])/max(abs(high['derived'][k]),mp.mpf('1e-2000')) for k in keys}
            stable=low['gates']==high['gates'] and [z['good'] for z in low['atoms']]==[z['good'] for z in high['atoms']] and max(errors.values())<mp.mpf('1e-65')
            high['precision_comparison']=dict(relative_errors=errors,gate_and_good_signs_agree=low['gates']==high['gates'] and [z['good'] for z in low['atoms']]==[z['good'] for z in high['atoms']],stable=stable)
            high['status']='checks_passed' if all(high['checks'].values()) and stable else 'check_failed'
            high['elapsed_seconds']=time.monotonic()-start
            data['cases'].append(enc(high))
            print(row[1],high['status'],'qualified',high['necessary_gates_pass'],'highratio',mp.nstr(high['derived']['high_ratio'],6),'tail',mp.nstr(high['statistics']['qualified_tail_flux'],6),'rhoA',mp.nstr(high['statistics']['qualified_RC_residual'],6),flush=True)
        except Exception as exc:
            rec=dict(id=row[1],status='exception',exception=repr(exc),traceback=traceback.format_exc());data['cases'].append(rec);data['exceptions'].append(rec);print(rec,flush=True)
        save(data)
    qualified=[r for r in data['cases'] if r.get('necessary_gates_pass')]
    positive=[r for r in qualified if mp.mpf(r['statistics']['qualified_RC_residual'])>0]
    data['summary']=dict(cases_completed=len(data['cases']),numerical_checks_passed=sum(r.get('status')=='checks_passed' for r in data['cases']),necessary_gates_pass_ids=[r['id'] for r in qualified],positive_qualified_RC_ids=[r['id'] for r in positive],positive_qualified_tail_ids=[r['id'] for r in qualified if mp.mpf(r['statistics']['qualified_tail_flux'])>0],next_step='Inspect listed qualified positive rows and kappa/R geometry; if none, this menu supplies no positive common-tail evidence; do not infer general capture.',FULL_certified=False)
    data['status']='completed_with_failures' if data['exceptions'] or any(r.get('status')!='checks_passed' for r in data['cases']) else 'completed_numerical_checks'
    data['finished_utc']=utc();save(data);print(data['summary'],flush=True)
if __name__=='__main__':main()
