#!/usr/bin/env python3
"""Portable replay of frozen calc functions, bypassing producer-only local provenance paths."""
from pathlib import Path
import argparse, importlib.util, json, sys
ROOT=Path(__file__).resolve().parent
ap=argparse.ArgumentParser(); ap.add_argument('mode',choices=['v1','v2','joint','imports']); ap.add_argument('--case',default='I1'); ap.add_argument('--dps',type=int,default=90); args=ap.parse_args()
def load(name):
    spec=importlib.util.spec_from_file_location(name,ROOT/(name+'.py')); m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m); return m
names={'v1':'active_traffic_numeric','v2':'active_traffic_v2','joint':'joint_kernel_probe'}
if args.mode=='imports':
    for name in [*names.values(),'tail_probe']: load(name)
    print('All four frozen modules imported; numerical calculations not rerun.'); sys.exit()
m=load(names[args.mode]); row=next(row for row in m.MENU if row[1]==args.case)
res=m.calc(row,args.dps)
out=ROOT/('replay_'+args.mode+'_'+args.case+'_'+str(args.dps)+'.json')
with out.open('x') as f: json.dump(m.enc(res),f,ensure_ascii=False,indent=2)
print(out)
