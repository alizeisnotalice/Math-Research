#!/usr/bin/env python3
"""Finite true-kernel source traffic with FA and weighted suffix Psi, not FULL."""
from pathlib import Path
import importlib.util,json,hashlib,datetime,time,traceback
ROOT=Path(__file__).resolve().parent; OLD=ROOT.parent/'centered_cube_round135_20261014'
spec=importlib.util.spec_from_file_location('kernels',OLD/'real_joint_numeric.py'); m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
mp=m.mp
OUT=ROOT/'active_traffic_v2.json'
MENU=[('initial','I1',4,'.25',['.8'],'4'),('initial','I2',16,'.25',['.8'],'4'),('initial','I3',16,'.5',['.8'],'4'),('initial','I4',16,'.75',['.8'],'4'),('mixed','P1',16,'.25',['.6','1.1'],'4'),('mixed','P2',32,'.25',['.6','.8','1','1.2'],'8'),('mixed','P3',64,'.25',['.8','1.1'],'16'),('mixed','P4',16,'.25',['.3','1.5'],'4'),('expanded','E1',32,'.25',['.8'],'16'),('expanded','E2',64,'.25',['.8'],'16'),('expanded','E3',128,'.25',['.8'],'16'),('expanded','E4',64,'.5',['.6','.8','1','1.2'],'8')]
KEYS=['raw_delta','rho_delta','FA_delta','rho_FA_delta','rho_FA_Psi_delta']
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def enc(x):
 if isinstance(x,dict):return {k:enc(v) for k,v in x.items()}
 if isinstance(x,(list,tuple)):return [enc(v) for v in x]
 if isinstance(x,mp.mpf):return mp.nstr(x,mp.mp.dps)
 return x
def calc(row,dps):
 mp.mp.dps=dps
 phase,cid,n,st,template,fartext=row; s=mp.mpf(st); L=mp.mpf('.9'); y=mp.mpf('.3'); a=mp.mpf('.5'); b=mp.mpf(1); K=D=mp.mpf(1); eps=mp.mpf('1e-8'); u=mp.mpf('.01')
 gamma=1+mp.mpf(1)/n; g=mp.sqrt(L); j=int(mp.floor(mp.log(g/L)/mp.log(gamma))); cj=gamma**(-j); Lp=min(1,gamma*L); ell=1+mp.log(n); ms=1-s+s*m.phi(mp.mpf('.5')); H0=g*cj**(-mp.mpf('.5'))*ms*ell**(mp.mpf(1)/(2*n)); Hhat=max(a,min(b,H0)); T=cj**(mp.mpf(n)/2)/(g**n*mp.sqrt(ell)); tau=a/cj; h=g*mp.exp(-u/n)
 BFA=4*(mp.mpf(128)/119)*mp.log(2)/(K*mp.mpf('.01')); p=m.kernel(s,L,[-y]*n)
 pos=[[-mp.mpf('.8')]*n,[-mp.mpf('1.6')]*n,[-mp.mpf('.8') if i%2==0 else -mp.mpf('1.6') for i in range(n)],[mp.mpf(template[i%len(template)]) for i in range(n)],[mp.mpf(fartext)]*n]
 core_mass=mp.mpf('1e-300'); pos.append([mp.mpf(0)]*n)
 masses=[eps]*4+[1-4*eps-core_mass,core_mass]; atoms=[]
 def wt(th,t):return mp.fprod(min(mp.mpf(1),z/t) for z in th)
 for name,v,nu in zip(['G1','G2','G3','G4','B','CORE'],pos,masses):
  th=[b/cj*m.Cfun((y-z)/b) for z in v]; wg=wt(th,g); wta=wt(th,tau); wh=wt(th,h); A=wta-wh
  K0=m.kernel(s,Hhat,[-z for z in v]); K1=m.kernel(s,L,[-z for z in v]); K2=m.kernel(s,Lp,[-z for z in v]); J=m.kernel(mp.mpf(1),b,[-z for z in v]); Q=(K1+K2+J)/3; good=p*wg<=K*Q; E=good and A>0
  U=min(T*A,D*K0) if E else mp.mpf(0)
  atoms.append(dict(name=name,position=v,nu=nu,thresholds=th,wg=wg,wtau=wta,wh=wh,A=A,K0=K0,K1=K1,K2=K2,J=J,Q=Q,good=good,bad=not good,E=E,U=U,terminal_good_margin=K*Q-p*wg))
 integ=lambda key:mp.fsum(z['nu']*z[key] for z in atoms)
 eg=integ('wg'); QJ=integ('J'); q=max(integ('K0'),QJ,integ('Q')); alpha=(D*q-integ('U'))/QJ
 for z in atoms:
  z['rhoA']=max(z['A']-(z['U']+alpha*z['J'])/T,mp.mpf(0)) if z['E'] else mp.mpf(0)
  z['rho']=z['rhoA']/z['A'] if z['A']>0 else mp.mpf(0)
 # The global grid contains every source threshold: no score jumps inside a piece.
 breaks=sorted(set([tau,h]+[al for z in atoms for al in z['thresholds'] if tau<al<h]))
 segments=[]
 for lo,hi in zip(breaks,breaks[1:]):
  mid=mp.sqrt(lo*hi); powers=[sum(al<mid for al in z['thresholds']) for z in atoms]; coeff=[mp.fprod(al for al in z['thresholds'] if al<mid) for z in atoms]
  segments.append(dict(lo=lo,hi=hi,k=powers,c=coeff,log_length=mp.log(hi/lo)))
 # Fixed pair Psi from all UNNORMALIZED suffixes, independent of FA and rho.
 pairs=[]; totals={k:mp.mpf(0) for k in KEYS}; activepieces=0; ambig=[]
 for i,v in enumerate(atoms):
  for zidx,z in enumerate(atoms):
   increments=[]
   for seg in segments:
    diff=seg['k'][i]-seg['k'][zidx]; power=seg['k'][i]+seg['k'][zidx]
    val=diff*seg['c'][i]*seg['c'][zidx]*(seg['lo']**(-power)-seg['hi']**(-power))/power if power else mp.mpf(0)
    increments.append(val)
   suffix=[mp.mpf(0)]*(len(increments)+1)
   for ii in range(len(increments)-1,-1,-1):suffix[ii]=suffix[ii+1]+increments[ii]
   scale=mp.fsum(abs(z) for z in increments); maxsuffix=max(suffix); epssign=mp.mpf('1e-70')*scale
   psi=maxsuffix>epssign; ambiguous=0<maxsuffix<=epssign
   if ambiguous:ambig.append([v['name'],z['name']])
   pairtot={k:mp.mpf(0) for k in KEYS}; pieces=[]
   eligible=v['good'] and z['bad']
   for segno,seg in enumerate(segments):
    delta=max(seg['k'][i]-seg['k'][zidx],0)
    if not eligible or not delta:continue
    kv=seg['k'][i]; assert kv>=1
    cap=(BFA*delta*p*seg['c'][i]/v['Q'])**(mp.mpf(1)/kv)
    flo=seg['lo']; fhi=min(seg['hi'],cap)
    def func(logt):
     t=mp.exp(logt); w=[cc*t**(-kk) for cc,kk in zip(seg['c'],seg['k'])]; et=mp.fsum(a['nu']*ww for a,ww in zip(atoms,w))
     return delta*v['nu']*z['nu']*w[i]*w[zidx]/(et*et)
    lo,hi=seg['lo'],seg['hi']
    def normalized_quad(lft,rgt):
     if rgt<=lft:return mp.mpf(0)
     zl,zr=mp.log(lft),mp.log(rgt); factor=func((zl+zr)/2)
     return factor*mp.quad(lambda zz:func(zz)/factor,[zl,zr],method='tanh-sinh',maxdegree=9)
    raw=normalized_quad(lo,hi)
    fa=normalized_quad(flo,fhi)
    vals=dict(raw_delta=raw,rho_delta=raw*v['rho'],FA_delta=fa,rho_FA_delta=fa*v['rho'],rho_FA_Psi_delta=fa*v['rho'] if psi else mp.mpf(0))
    for key in KEYS:pairtot[key]+=vals[key]
    if vals['rho_FA_Psi_delta']>0:activepieces+=1
    pieces.append(dict(score_segment=segno,lo=lo,hi=hi,kv=kv,kz=seg['k'][zidx],delta=delta,FA_cutoff=cap,FA_active_lo=flo,FA_active_hi=fhi,FA_active=fhi>flo,integrals=vals))
   for key in KEYS:totals[key]+=pairtot[key]
   pairs.append(dict(v=v['name'],z_prime=z['name'],good_bad_eligible=eligible,Psi=psi,Z_all_suffix_nonpositive=not psi,suffix_ambiguous=ambiguous,suffix_breaks=breaks,suffix_values=suffix,max_suffix=maxsuffix,suffix_abs_increment_scale=scale,suffix_max_relative=maxsuffix/scale if scale else mp.mpf(0),segment_signed_increments=increments,pieces=pieces,integrals=pairtot))
 hardmass=mp.fsum(z['nu'] for z in atoms if all(abs(vv)<=mp.mpf('.5') for vv in z['position']))
 lam=q
 gates=dict(hard_positive=hardmass>0,hard_cap=hardmass<=4*lam,q_lambda_range=mp.mpf('.75')*lam<=q<=lam,strict_s=s>1-2**(-mp.mpf(1)/n),scale=a<=L<=b and L<=cj*g<=gamma*L,tau_h_g=tau<h<=g,high=p*eg>=2*K*q,FIRST_three=all(integ(k)<=q for k in ['K0','J','Q']),heavy=eg>ell*q*cj**(-mp.mpf(n)/2)*g**n)
 qualified=all(gates.values())
 ratios=dict(rho_retention=totals['rho_delta']/totals['raw_delta'] if totals['raw_delta'] else None,FA_after_rho_retention=totals['rho_FA_delta']/totals['rho_delta'] if totals['rho_delta'] else None,Psi_after_rho_FA_retention=totals['rho_FA_Psi_delta']/totals['rho_FA_delta'] if totals['rho_FA_delta'] else None)
 checks=dict(gates_evaluated=True,suffix_sign_unambiguous=not ambig,alpha_nonnegative=alpha>=0,raw_ge_rho=totals['rho_delta']<=totals['raw_delta']*(1+mp.mpf('1e-65')),rho_ge_rhoFA=totals['rho_FA_delta']<=totals['rho_delta']*(1+mp.mpf('1e-65')),rhoFA_ge_active=totals['rho_FA_Psi_delta']<=totals['rho_FA_delta']*(1+mp.mpf('1e-65')))
 return dict(id=cid,stage=phase,n=n,parameters=dict(s=s,L=L,y=y,G4_template=template,far=fartext,K=K,D=D,epsilon_FA=mp.mpf('.01'),B_FA=BFA,a=a,b=b,u=u,source_epsilon=eps,core_mass=core_mass),derived=dict(j=j,cj=cj,g=g,tau=tau,h=h,ell=ell,H0=H0,Hhat=Hhat,Lplus=Lp,T=T,p=p,eg=eg,q=q,QJ=QJ,alpha=alpha,hard_source_mass=hardmass,lambda_test=lam,nu_total=mp.fsum(masses),nu_total_rounding_error=mp.fsum(masses)-1,high_ratio=p*eg/(2*K*q),heavy_ratio=eg/(ell*q*cj**(-mp.mpf(n)/2)*g**n)),atoms=atoms,time_breakpoints=breaks,score_segments=segments,pairs=pairs,integrals=totals,retentions=ratios,gates=gates,base_necessary_gates_pass=qualified,qualified_active_integral=totals['rho_FA_Psi_delta'] if qualified else mp.mpf(0),active_pair_count=sum(z['integrals']['rho_FA_Psi_delta']>0 for z in pairs),active_time_piece_count=activepieces,checks=checks,Psi_ambiguous_pairs=ambig,FULL_certified=False)
def save(data):OUT.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
def main():
 if OUT.exists():raise SystemExit('Refuse second producer run')
 sources=[ROOT/'protocol_v2.md',ROOT/'numeric_protocol.md',ROOT/'active_traffic_numeric.py',ROOT/'active_traffic_numeric.json',Path(__file__),OLD/'score_gate_probe.py',OLD/'score_gate_probe.json',OLD/'numeric_audit.md',OLD/'real_joint_numeric.py',ROOT.parent/'centered_cube_round119_20261014/quantitative_future.md',ROOT.parent/'centered_cube_round122_20261014/weighted_suffix_integration_private.md',ROOT.parent/'centered_cube_round122_20261014/mixed_capacity_proof_audit_private.md',ROOT.parent/'centered_cube_round128_20261014/joint_receiver_tail.md']
 data=dict(status='running',run_count=2,version='v2',v1_preserved=True,started_utc=utc(),menu=MENU,precision_dps=[90,120],sha256={str(p):sha(p) for p in sources},scope='true kernels, necessary finite-source FA/Psi model; no FULL/history/outer integral certification',cases=[],exceptions=[])
 save(data)
 for row in MENU:
  start=time.monotonic()
  try:
   low=calc(row,90); high=calc(row,120)
   errs={k:abs(high['integrals'][k]-low['integrals'][k])/max(abs(high['integrals'][k]),mp.mpf('1e-2000')) for k in KEYS}
   signs=low['gates']==high['gates'] and [z['good'] for z in low['atoms']]==[z['good'] for z in high['atoms']] and [z['Psi'] for z in low['pairs']]==[z['Psi'] for z in high['pairs']]
   high['precision_comparison']=dict(integral_relative_errors=errs,gate_good_Psi_agreement=signs,stable=signs and max(errs.values())<mp.mpf('1e-60'))
   high['status']='checks_passed' if all(high['checks'].values()) and high['precision_comparison']['stable'] else 'check_failed'
   high['elapsed_seconds']=time.monotonic()-start;data['cases'].append(enc(high))
   print(row[1],high['status'],'rawrho',mp.nstr(high['integrals']['rho_delta'],8),'active',mp.nstr(high['integrals']['rho_FA_Psi_delta'],8),'FAretain',mp.nstr(high['retentions']['FA_after_rho_retention'],8),'Psiretain',mp.nstr(high['retentions']['Psi_after_rho_FA_retention'],8),'gates',high['base_necessary_gates_pass'],flush=True)
  except Exception as exc:
   rec=dict(id=row[1],status='exception',exception=repr(exc),traceback=traceback.format_exc());data['cases'].append(rec);data['exceptions'].append(rec);print(rec,flush=True)
  save(data)
 valid=[r for r in data['cases'] if 'integrals' in r]
 data['summary']=dict(hard_source_positive_in_v2=True,v1_hard_source_zero=True,numerical_conditioning='piecewise positive midpoint scaling before quadrature',cases_completed=len(data['cases']),checks_passed=sum(r['status']=='checks_passed' for r in valid),positive_raw_rho_ids=[r['id'] for r in valid if mp.mpf(r['integrals']['rho_delta'])>0],positive_active_ids=[r['id'] for r in valid if mp.mpf(r['integrals']['rho_FA_Psi_delta'])>0],positive_qualified_active_ids=[r['id'] for r in valid if mp.mpf(r['qualified_active_integral'])>0],FULL_certified=False,no_rate_fit=True)
 data['status']='completed_with_failures' if data['exceptions'] or any(r['status']!='checks_passed' for r in valid) else 'completed_numerical_checks';data['finished_utc']=utc();save(data);print(data['summary'],flush=True)
if __name__=='__main__':main()
