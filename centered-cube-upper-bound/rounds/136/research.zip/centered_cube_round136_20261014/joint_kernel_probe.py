#!/usr/bin/env python3
"""Finite true-dx FK4 integral plus separate analytic tail formula."""
from pathlib import Path
from fractions import Fraction as F
import importlib.util,json,hashlib,datetime,time,traceback
ROOT=Path(__file__).resolve().parent; OLD=ROOT.parent/'centered_cube_round135_20261014/real_joint_numeric.py'
spec=importlib.util.spec_from_file_location('real_kernels',OLD); k=importlib.util.module_from_spec(spec);spec.loader.exec_module(k);mp=k.mp
OUT=ROOT/'joint_kernel_probe.json';R=512
MENU=[('initial','I1','.5','.5','.1','.2',0,0),('initial','I2','1','1','.5','.25',0,1),('initial','I3','.5','1','1','.3',1,-1),('initial','I4','1','.5','.5','.2',-1,1),('pressure','P1','1','.5','.1','.3',4,-4),('pressure','P2','1','.5','.5','.25',-4,4),('pressure','P3','1','.5','1','.2',1,-1),('pressure','P4','1','.5','.1','.3',0,4),('expanded','E1','.5','.5','1','.25',4,4),('expanded','E2','.5','1','.1','.3',-4,-4),('expanded','E3','1','1','1','.3',4,-4),('expanded','E4','1','.5','1','.3',-4,0)]
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def enc(x):
 if isinstance(x,dict):return {key:enc(val) for key,val in x.items()}
 if isinstance(x,(list,tuple)):return [enc(val) for val in x]
 if isinstance(x,mp.mpf):return mp.nstr(x,mp.mp.dps)
 return x
def save(x):OUT.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def Ctrue(x):
 x=abs(mp.mpf(x))
 if x>=1:
  E=lambda z:mp.mpf(1)/3 if z==0 else mp.expint(4,z)
  return E(x-1)-2*E(x)+E(x+1)
 return k.Cfun(x)
def calc(row,dps):
 mp.mp.dps=dps;stage,cid,Lt,Ht,st,tt,vi,zi=row
 L,H,s,theta=map(mp.mpf,[Lt,Ht,st,tt]);v,z=mp.mpf(vi),mp.mpf(zi); Cv,Cz=Ctrue(v),Ctrue(z)
 fixed=Cz*Cv**(1+theta)
 def mixed(x,length):return ((1-s)*(1 if abs(x)<=length/2 else 0)+s*k.phi(x/length))/length
 def integrand(d):
  receiver=mixed(d,L); bad=mixed(d-z,H); good=k.phi(d-v)
  return mp.exp(mp.log(receiver)+mp.log(fixed)-theta*(mp.log(bad)+mp.log(good)))
 special=[-L/2,L/2,z-H/2,z+H/2,v-mp.mpf('.5'),v+mp.mpf('.5')]
 auxiliary=[mp.mpf(0),v,z]+[mp.mpf(sign*j) for sign in [-1,1] for j in [8,16,32,64,128,256]]
 breaks=sorted(set([mp.mpf(-R),mp.mpf(R)]+special+auxiliary));pieces=[]
 for lo,hi in zip(breaks,breaks[1:]):
  factor=integrand((lo+hi)/2)
  val=factor*mp.quad(lambda d:integrand(d)/factor,[lo,hi],method='tanh-sinh',maxdegree=8)
  pieces.append(dict(lo=lo,hi=hi,midpoint_scale=factor,integral=val))
 finite=mp.fsum(a['integral'] for a in pieces)
 a0=2/(5*mp.sqrt(mp.e));A0=2*mp.sqrt(mp.e);C0=4*mp.e
 Cstar=C0**(2+theta)*a0**(-2*theta)*s**(-theta)
 Sz=mp.exp(-(1-theta/H)*abs(z))/(1+abs(z))**(1-theta); Sv=mp.exp(-abs(v))/(1+abs(v)); beta=1/L-3*theta
 tail=2*s*A0*Cstar*Sz*Sv*mp.exp(-beta*R)/(L*beta)
 M=Cstar*(mp.exp(3*theta/2)*mp.mpf('1.5')**(2*theta)+2*A0/(1-3*theta))
 checks=dict(parameter_range=mp.mpf('.5')<=L<=1 and mp.mpf('.5')<=H<=1 and 0<s<=1 and 0<theta<mp.mpf(1)/3,positive_integral=finite>0,positive_decay_beta=beta>0,finite_estimate_below_FK5=finite<M,estimate_plus_tail_below_FK5=finite+tail<M,all_pieces_nonnegative=all(a['integral']>=0 for a in pieces))
 return dict(stage=stage,id=cid,parameters=dict(L=L,H=H,s=s,theta=theta,r_exact=str(F(1)/(1-F(tt))),v=v,z=z,R=R),Cv=Cv,Cz=Cz,hard_and_phi_breakpoints=special,all_breakpoints=breaks,pieces=pieces,finite_integral=finite,analytic_tail_bound_formula='2*s*A0*Cstar*Sz*Sv*exp(-(1/L-3theta)*R)/(L*(1/L-3theta))',analytic_tail_bound_value=tail,tail_parameters=dict(a0=a0,A0=A0,C0=C0,Cstar=Cstar,Sz=Sz,Sv=Sv,beta=beta),FK5_M=M,finite_estimate_plus_analytic_tail=finite+tail,estimate_plus_tail_over_M=(finite+tail)/M,checks=checks,interval_certified=False,FULL_certified=False)
def main():
 if OUT.exists():raise SystemExit('Refuse second producer run')
 sources=[ROOT/'joint_kernel_protocol.md',Path(__file__),ROOT/'fractional_kernel_envelope.md',OLD,ROOT.parent/'centered_cube_round133_20261014/third_numeric.py']
 data=dict(status='running',run_count=1,started_utc=utc(),menu=MENU,precision_dps=[60,90],finite_R=R,sha256={str(p):sha(p) for p in sources},scope='Finite real Lebesgue dx integration of both inverse-kernel factors, with separate symbolic analytic tail; no global sup/rate/FULL certificate',cases=[],exceptions=[])
 save(data)
 for row in MENU:
  start=time.monotonic()
  try:
   low=calc(row,60);high=calc(row,90)
   err=abs(high['finite_integral']-low['finite_integral'])/high['finite_integral'];piece_errors=[abs(a['integral']-b['integral'])/max(abs(b['integral']),mp.mpf('1e-2000')) for a,b in zip(low['pieces'],high['pieces'])]
   high['precision_comparison']=dict(total_relative_error=err,max_piece_relative_error=max(piece_errors),piece_count_agree=len(low['pieces'])==len(high['pieces']),total_pass=err<mp.mpf('1e-40'))
   high['status']='passed' if all(high['checks'].values()) and high['precision_comparison']['total_pass'] else 'failed';high['elapsed_seconds']=time.monotonic()-start
   data['cases'].append(enc(high));print(row[1],high['status'],'finite',mp.nstr(high['finite_integral'],9),'tailbound',mp.nstr(high['analytic_tail_bound_value'],6),'relerr',mp.nstr(err,6),flush=True)
  except Exception as exc:
   rec=dict(id=row[1],status='exception',exception=repr(exc),traceback=traceback.format_exc());data['cases'].append(rec);data['exceptions'].append(rec);print(rec,flush=True)
  save(data)
 valid=[a for a in data['cases'] if 'finite_integral' in a]
 data['summary']=dict(case_count=len(data['cases']),passed=sum(a['status']=='passed' for a in valid),failed_ids=[a['id'] for a in data['cases'] if a['status']!='passed'],max_total_relative_error=mp.nstr(max(mp.mpf(a['precision_comparison']['total_relative_error']) for a in valid),90) if valid else None,all_FK5_numerical_comparisons_pass=all(a['checks']['estimate_plus_tail_below_FK5'] for a in valid),interval_certified=False,FULL_certified=False,interpretation='Finite 60/90 precision consistency and separate symbolic tail formula only. Numerical finite estimate plus analytic tail is not a rigorous quadrature enclosure or a proof of the uniform bound.')
 data['status']='completed_with_failures' if data['exceptions'] or data['summary']['failed_ids'] else 'completed_numerical_checks';data['finished_utc']=utc();save(data);print(data['summary'],flush=True)
if __name__=='__main__':main()
