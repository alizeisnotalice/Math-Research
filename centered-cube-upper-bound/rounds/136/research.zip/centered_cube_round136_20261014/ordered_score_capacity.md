# R136：有序 score 的一次性 bad 余额

状态：先筛查准确命题，再证明。只处理同一实际接收行、原来源概率和原 RC 余额；不把未付量改名为成果，不构造抽象反例，不修改负项。只写本文件，不操作 Git/PDF。

## 1. 量词、准确分解与候选

固定任意原合法有限交通截断、完整实际行 \(r=(\omega,V,j,x,y,z,\mathrm{history})\) 与原时间 t。原 \(D_g,S_g,\rho,\alpha_{rec},Q_J,p,g,T\) 皆按该行实际值固定；原 \(\Pi_t=e_t^{-1}1_{Z_t}w_t\nu\) 可随 t 变化，来源向量任意相关、各坐标阈值任意不同。原终端 \(D_g,S_g\subset Z_g\subset Z_t\)。记
\[
 k=k_t(v),\quad b=k_t(z'),\quad \delta=(k-b)_+.
\]
对整数 \(0\le k,b\le n\)，准确有
\[
 \delta=\sum_{\ell=1}^n1_{\{k\ge\ell\}}1_{\{b<\ell\}}.
\tag{OS1}
\]
它是带重数的有序分解，不是不交来源分割。低 score bad 点在 \(\ell=b+1,\ldots,n\) 会被重复计入。

候选 A：各层均调用 \(\alpha Q_J\ge D_{RC}\int_{D_g}K_0\nu\) 然后把各层捕获量相加。筛查为不合法的容量计数：同一个 bad 原子在低 score 时贡献 n−b 份，不可因层标号不同而当成 n 份余额。

候选 B：对每个 actual good score \(m=k_t(v)>0\)，先平均其 m 个相关层，再将外面的 m 留作原 FTC 下降导数。令
\[
 f_m(b)=(1-b/m)_+,\quad
 C_m(t)=\int_{D_g}f_m(k_t(z'))K_0(z')\nu(dz'),
\]
\[
 W_m(t)=\int_{D_g}f_m(k_t(z'))w_t(z')\nu(dz').
\tag{OS2}
\]
预期同时有 \(D_{RC}C_m\le\alpha Q_J\)，并且正交通的坏端精确为 \(mW_m/e_t\)。这是一次性容量表示，必须进一步检验 \(W_m\) 与 \(C_m\) 的**真实核比较**，才能将其转成交通价格。不能把该比较的未知费用称作已经付款。

## 2. 一般不同坐标、相关来源下的一次性恒等式

OS1 直接数出 \(b<\ell\le k\) 的整数个数，适用于原全部不同坐标阈值；不使用来源独立。低 score 累积余额若直接求和，则
\[
 \sum_{\ell=1}^n\int_{D_g}1_{\{k_t(z')<\ell\}}K_0(z')\nu(dz')
 =\int_{D_g}(n-k_t(z'))K_0(z')\nu(dz').
\tag{OS3}
\]
与原 \(\int_{D_g}K_0\nu\) 不同，不能把 OS3 的右端自动叫作 n 个新容量。

对 m≥1，恰有 \(m^{-1}\sum_{\ell=1}^m1_{\{b<\ell\}}=f_m(b)\)，故 OS2 满足
\[
 0\le C_m(t)\le C_B:=\int_{D_g}K_0\nu,
 \qquad D_{RC}C_m(t)\le D_{RC}C_B\le\alpha Q_J.
\tag{OS4}
\]
最后一步是原同 x 的 RG13 余额。它对所有 m 同时成立，不是准许将右端相加。令原 good score 单元 \(H_m(t)=S_g\cap\{k_t(v)=m\}\) 和 \(J_m(t)=\int_{H_m(t)}J(v)\nu(dv)\)。这些 good 单元不交，且 \(\sum_mJ_m\le Q_J\)，所以平均余额运输有真正的一次性证书
\[
 \frac{D_{RC}}{Q_J}\sum_{m=1}^n C_m(t)J_m(t)
 \le D_{RC}C_B\le\alpha Q_J.
\tag{OS5}
\]
可在 \(J_m\) 中保留 \(0\le\rho\le1\) 得同一结论；没有复制 \(\alpha J\) 的原密度。这只是核余额的正确收费结构，不是实际 score 交通已由该余额支付。

在原同一 \(\Pi_t\) 下，对 score m 的 good v，准确有
\[
 \int_{D_g}\delta_t(v,z')d\Pi_t(z')
 =\frac{mW_m(t)}{e_t}.
\tag{OS6}
\]
因此仅作合法的正放松删除 \(\Psi\chi_{FA}\le1\) 后，保留真实 \(\rho\) 的时点交通恰为
\[
 I_t=\frac1{e_t^2}\sum_{m=1}^n mW_m(t)
 \int_{H_m(t)}\rho(v)w_t(v)\nu(dv).
\tag{OS7}
\]
外面的 m 留给原 \(k_tw_t\) 的 FTC；OS5 的 J 权重则与 OS7 的 \(m\rho w_t/e_t^2\) 权重不同。将二者当作相同权重，是层分解仍未消除的具体测度错配。

## 3. 一条可证明的联合核层估计：不取 n 份 α

为给错配一个实际几何代价，固定 u>0、d≥0，只给**正项坏端**增加真实层
\[
 B_{u,d}(t)=D_g\cap\{Z(z')\ge u,\ \Delta_{t,g}(z')\le d\},\qquad
 Z(z')=K_0(z')/(Tw_g(z')).
\tag{OS8}
\]
其核比满足 \(w_t(z')/K_0(z')=e^{\Delta(z')}/(TZ(z'))\le e^d/(Tu)\)。用同一个非负 score 平均因子 \(f_m\)，同时限制 OS2 的 W 和 C 到 OS8，便有
\[
 W_m^{u,d}(t)\le\frac{e^d}{Tu}C_m^{u,d}(t)
 \le\frac{e^d\alpha Q_J}{D_{RC}Tu}.
\tag{OS9}
\]
这是一次性的原 \(K_0\) 余额比较；不同 m 没有各申请一份 \(\alpha Q_J\)。将 OS9 放入 OS7，仅对 good v 的不交 score 单元求和，得到
\[
 I_t^{u,d}\le
 \frac{e^d\alpha Q_J}{D_{RC}Tu e_t^2}
 \int_{S_g}\rho(v)k_t(v)w_t(v)\nu(dv).
\]
原 \(e_t\ge e_g\) 保留来源分母，\(\rho\) 在整行时间中固定，原 FTC \(\int_\tau^h k_tw_tdt/t=A=w_\tau-w_h\) 给
\[
 \mathcal F_r^{u,d}\le
 \frac{e^d\alpha Q_J}{D_{RC}Tu e_g^2}
 \int_{S_g}\rho A\,d\nu.
\tag{OS10}
\]
原禁块或更小 far 时间窗只使左侧减小。没有把来源向量换成产品分布，没有取 \(\Pi_g\) 冒作 \(\Pi_t\)。

进一步联合真实 \(\rho\) 与同一 α，避免将 α 和余量分别取最坏值。原 RC 的正余来源满足
\[
 \rho A=(A-D_{RC}K_0/T-\alpha J/T)_+.
\]
对非负 α，用初等二次极值
\[
 \alpha\rho A
 \le\frac{T}{4J}(A-D_{RC}K_0/T)_+^2.
\tag{OS11}
\]
这是在原 positive RC 域的严格点态不等式；A=0 或捕获约定下无正余项，不引入除以 A 的退化。于是得到一般相关来源的联合层估计
\[
 \boxed{\mathcal F_r^{u,d}\le
 \frac{e^dQ_J}{4D_{RC}u e_g^2}
 \int_{S_g}\frac{(A-D_{RC}K_0/T)_+^2}{J}\,d\nu.}
\tag{OS12}
\]
它使用原 bad 余额一次、原下降通量一次，并显式保留 good 余量与 α 的相互抑制，不产生 n 倍重复容量。J>0 来自原全软核，Q_J=0 行按原零交通处理。OS12 不是右端已经有外预算的声明。

反向尺度比较 JG135.10--18 可以保持在 OS10--12 中：原 good 点有 \(J\ge3pwg/(KC_J(v))\)，且实际 \(\rho A\) 已受 \([A-\widetilde M(v)wg]_+\) 限制。在可检查硬计数层 \(C_J\le3\) 没有新增指数比较费；其补集的原 \(B_H\) 仍须付。不能把这些点态门再删除后声称 J 的下界对全部来源自由成立。

## 4. 全部外费用与具体停点

对一个预先指定的坏端几何层 OS8，把 OS12 恢复原完整 raw 外行测度，signed 正项价格至多
\[
 2\Lambda P_I^{u,d}\le
 \frac{\Lambda e^d}{2D_{RC}u}
 \mathbb E\sum_{V,j}\int1_{A_{hi}}d\mathcal T_I(r)
 \frac{Q_J(r)}{e_g(r)^2}
 \int_{S_g(r)}\frac{(A(v)-D_{RC}K_0(v)/T)_+^2}{J(v)}\nu(dv).
\tag{OS13}
\]
这不是一个已付新矩的命名，而是必须核验的完整原积分。实际 \(dx\)、\(q^{-1}p h_R\)、硬 z、\(\beta-\nu\)、唯一 j、种子/history 与连续 soft/scale 选择器都留在 \(d\mathcal T_I\)，时间已仅由一次原 FTC 上界处理。若改用 SI5 的硬来源先积分形式才出现其 \(16/3\)；不能额外叠加在 OS13 的 raw 价格上。D_RC 是原参数，不新领 D_RC q 捕获容量。

在真实 good 硬计数层 \(C_J\le3\)，high 与 \(Q_J\le q\) 可将 OS12 的系数进一步估为
\[
 \mathcal F_{r,\mathcal G}^{u,d}\le
 \frac{e^d}{8D_{RC}u e_g}
 \int_{S_g\cap\mathcal G}
 \frac{(A-D_{RC}K_0/T)_+^2}{w_g}\,d\nu.
\tag{OS14}
\]
该式明确保留了 \(w_g(R-D_{RC}Z)_+^2\) 的真实联合尾。它仍无 Wβ 外预算；比起原线性余量，二次估计甚至可能在大 R 上更粗。不能因没有 n 层显式相加，就将 OS13--14 右端称作根阶费用。

当前缺口有精确的位置：

- 坏端 \(Z<u\) 或 \(\Delta>d\) 的正配对仍在原母式。低 score 的累计层不能为 \(Z=K_0/(Tw_g)\) 提供正下界；R135 的实际核尾深度分析已说明，固定 score 可以丢失决定 K₀ 比值的连续距离信息。这里没有给任何位置授予新 bad/history 身份。
- OS5 以 \(J\nu\) 收费，实际 OS7 用 \(m\rho w_t\nu/e_t^2\)。OS9 给一个显式 \(e^d/(Tu)\) 比较代价，OS11 处理 α 与 ρ 的相互抑制；但该代价和 OS13 的实际接收/来源交叉积分没有根阶上界。把它们整体取 supremum，或假设有界，就是尚未证明的那一步。
- 如按 u、d 或硬计数另分壳，必须保留不交交通与相应价格并证明总和；每壳单独套 OS13 后复用完整 \(T_{small}\) 或 \(\alpha Q_J\) 会再次重复收费。OS5 只解决 score 层的 n 份余额问题，不自动解决新的几何壳总账。

从 OS13 还不能得 \(\varepsilon X+C\sqrt n\operatorname{polylog}(n)W_\beta\)。逐行给 \(\sqrt n\) 常数再乘 \(T_{small}\le4X\) 也只会得到 \(\sqrt nX\)，不能冒作目标。这里未领取新 ε 槽、未退回旧费、未消费 \(N_Z\)；\(N_{Z^c}\)、\(N_{del}\) 均按原负门留在母式一次。

## 5. 最终结论

OS1--7 证明了有序 score 分解的正确一次性容量结构：bad 累积层须先按 actual good score 平均，外 score 因子保留给下降通量。OS10--12 给出实际坏端核层上、同一 α 与真实 ρ 的联合上界，不产生 n 份捕获容量。这是一般不同坐标和任意相关来源的严格估计；没有依赖有限数值或抽象反例。

但它没有为原全部正交通提供外预算。具体未付处是低 K₀ 比值 bad 层与 good 余量的核测度匹配，以及 OS13 的真实接收/来源交叉积分。本稿不将这些右端改名登记为进展，一般中间硬层与根阶目标仍 UNPROVED。到此具体检查点停止。
