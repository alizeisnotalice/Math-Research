# R136：严格低-score bad 余额的分数矩优化与真实接收费用

状态：推导冻结，待独审。目标仍为εX+C√n polylog(n)Wβ；本稿不将逐行√nX登记为目标。固定原同一实际行，始终保留硬来源z的外交通、β−ν、实际选择器及原负项身份。R135有限菜单的内部正ρδ不等于实际外交通正；无硬载体质量的配置不能认证外层实现性。

## 1. 命题量词与严格低-score bad 来源

固定实际x,y,s,L,R,g、H=Hhat、T、A、α=α_rec、q、ν及history，取原合法t。实际s>0，Q_J=∫Jdν>0；零来源行按零处理。对原good来源v且A(v)>0，令k=k_t(v)，并定义

\[
\mathcal L_{t,k}=\int_{D_g}[k-k_t(z')]_+d\Pi_t(z'),
\]
\[
\mathcal B_{t,k}(x,y)=\int_{D_g\cap Z_t\cap\{k_t(z')<k\}}
 [k-k_t(z')]^2\frac{w_t(y,z')^2}{K_0(x-z')}d\nu(z').
\tag{AB1}
\]

此处D_g⊂Z_g⊂Z_t；冗余Z_t只为显出实际资格。k=0时两量均为0，不以正RC余量代替正score资格。Π_t仍是同一概率测度，未改为Π_g。

令

\[
a_v=\left(1-\frac{D K_0(x-v)}{T A(v)}\right)_+.
\]

则有真实同行上界

\[
\boxed{\rho(v)\mathcal L_{t,k}
\le\frac{2}{3\sqrt3}\,a_v^{3/2}
\sqrt{\frac{T A(v)Q_J}{D J(x-v)}}
\frac{\sqrt{\mathcal B_{t,k}(x,y)}}{e_t(y)}.}
\tag{AB2}
\]

证明：同一bad来源余额给αQ_J≥D∫_{D_g}K₀dν。对AB1的真正低score来源用CS，

\[
\mathcal L_{t,k}\le\frac1{e_t}
\sqrt{\int_{D_g}K_0d\nu}\sqrt{\mathcal B_{t,k}}
\le\frac{\sqrt{\alpha Q_J/D}}{e_t}\sqrt{\mathcal B_{t,k}}.
\]

在E上原ρ=(a_v−αJ/(TA))_+；a_v=0时直接为0。对a≥0,b>0，
max_{u≥0}(a−bu)_+√u=2a^{3/2}/(3√(3b))，最大点u=a/(3b)。取u=α、b=J/(TA)即得AB2。E外相关good交通按原A=0或B=1约定为0。

AB2允许保留原χ_FA与Ψ：在原正积分中先保持它们，再只用其≤1取得上界。真实δ并未被n替换，而是以严格低score来源及[k−k_t(z′)]²留在B中。α的共同容量只用于这个一次同行不等式，不重领一份Dq。

## 2. 原核平方权重对逆K₀的准确尾抵消

本节先说明量词：λ=b/H∈[1,2]，d∈R，所有来源位置r∈R。定义**真实一维最佳包络**

\[
\mathcal E_\lambda(d)=\sup_{r\in\mathbb R}
 \frac{C(|r|)^2}{\phi(\lambda|d-r|)}.
\tag{AB3}
\]

这是原C与φ的函数，不是对完整来源/接收交通取sup。令k₀=2sinh(1/2)。有：

\[
\boxed{\frac{(1+\lambda|d|)e^{\lambda|d|}}{4e^{1/2}}
\le\mathcal E_\lambda(d)
\le243e^{7/2}(1+\lambda|d|)e^{\lambda|d|}<\infty.}
\tag{AB4}
\]

证明所需的全域实核比较为

\[
\frac{e^{-r}}{3e^{3/2}(1+r)}\le\phi(r)
\le\frac{4e^{1/2}e^{-r}}{1+r},\qquad
C(r)\le\frac{9e\,e^{-r}}{1+r}\quad(r\ge0).
\tag{AB5}
\]

从w(r)=e^{-r}∫₀∞e^{-ru}(1+u)^{-2}du，限制u≤1/(1+r)给w≥e^{-r}/[2e(1+r)]，直接积分给w≤2e^{-r}/(1+r)。对h₁卷积，G(r)=e^{-r}/(1+r)在长度1/2平移下满足(2/3)e^{-1/2}G(r)≤G(|r-u|)≤2e^{1/2}G(r)，于是得到φ界。又F=max(h₁,φ)≤h₁+φ，故C≤(1-r)_++h₁*φ≤eG+8eG=9eG。

将AB5代入AB3，利用λ≤2，

\[
\frac{C(|r|)^2}{\phi(\lambda|d-r|)}
\le243e^{7/2}e^{\lambda|d|}
\frac{1+\lambda|d|+\lambda|r|}{(1+|r|)^2}
\le243e^{7/2}(1+\lambda|d|)e^{\lambda|d|}.
\]

下界取r=0，使用C(0)=1及φ上界。常数粗但严格，未把常数的n次幂省略。

原精确尾φ(r)∼k₀e^{-r}/r、C(r)∼k₀²e^{-r}/r还给固定d的来源尾

\[
\frac{C(|r|)^2}{\phi(\lambda|d-r|)}
\sim\lambda k_0^3 e^{-\lambda\operatorname{sgn}(r)d}
\frac{e^{-(2-\lambda)|r|}}{|r|}\quad(r\to\pm\infty).
\tag{AB6}
\]

所以H>b/2时指数衰减，**临界H=b/2仍以1/|r|衰减**；不是临界无界。λ>2则发散，但不在原H≥a≥b/2域内。这真正消除了单个任意深bad坐标在wt²/K₀中的指数增长。

更尖的接收位移渐近也可指定给后续一维核验证：令

\[
S_\lambda=\sup_{r\ge0}C(r)^2e^{\lambda r}<\infty.
\]

则

\[
\mathcal E_\lambda(d)\sim
\frac{\lambda S_\lambda}{k_0}|d|e^{\lambda|d|}
\quad(|d|\to\infty).
\tag{AB7}
\]

固定r先取极限给该候选；AB5使尾部误差被常数乘[(1+|r|)^{-2}+|d|^{-1}(1+|r|)^{-1}]一致控制，先截|r|≤R再令R→∞证明sup与极限可交换。所有渐近均是解析结论，没有以有限数值认证。

## 3. 非临界分数矩：共同余额的准确优化

以下命题量词为每一个实际合法行、每个合法t、每个good v；不要求来源坐标独立，不要求H≥L₊，故覆盖R135反向尺度及其全部硬支持计数层。固定r>1，θ=(r−1)/r，令

\[
 \mathcal B_{r,t,k}=\int_{D_g\cap Z_t\cap\{k_t(z')<k\}}
 [k-k_t(z')]^r\frac{w_t(y,z')^r}{K_0(x-z')^{r-1}}d\nu(z'),
 \qquad c_\theta=\frac{\theta^\theta}{(1+\theta)^{1+\theta}}.
 \tag{AB8}
\]

则在扩展非负数意义下

\[
 \boxed{\rho(v)\mathcal L_{t,k}\le
 c_\theta a_v^{1+\theta}
 \left(\frac{T A(v)Q_J}{D J(x-v)}\right)^\theta
 \frac{\mathcal B_{r,t,k}^{1/r}}{e_t}.}
 \tag{AB9}
\]

证明：对严格低score bad集合，Hölder指数r和r/(r−1)给

\[
 \mathcal L_{t,k}\le e_t^{-1}
 \left(\int_{D_g}K_0d\nu\right)^\theta
 \mathcal B_{r,t,k}^{1/r}
 \le e_t^{-1}(\alpha Q_J/D)^\theta\mathcal B_{r,t,k}^{1/r}.
\]

原ρ=(a_v−b_vα)₊，b_v=J/(TA)>0。若a_v>0，函数(a_v−b_vu)₊u^θ在u=θa_v/[(1+θ)b_v]达到最大值c_θa_v^{1+θ}b_v^{-θ}。a_v=0时两边按零计，得到AB9。α=0时原低score bad质量为零（K₀>0）；无需在0·∞上作约定。k=0时亦为零。r=2恢复AB2。这里r不是维数或新的删门概率。

新实质是共同α同时出现在bad来源质量与good剩余中，随后wt的r次幂抵消逆K₀的r−1次幂。这个优化只用一次原余额，不按score层另领Dq。由于舍弃其他bad来源只发生在Hölder的第二因子中，原严格资格k_t(z′)<k没有丢失。

## 4. 接回原正交通：保持全部外因素

令P₊为原RT2中尚未付款的正交通（可进一步限制到任意中间重尾、反向尺度或硬计数可测分支）。以d𝒯表示原完整外行测度

\[
 d\mathcal T=q^{-1}p(x-y)h_R(x-z)\,a_{\rm history}
 \,dx\,d\beta(y)\,d\nu(z),
\]

并保留其原期望、唯一j、种子/history求和和合法时间区间；下式的∫d𝒯dt/t包括这些原操作。原good/bad、FA及Ψ按原行取值。只对正项用0≤χ_FAΨ≤1，AB9给

\[
\begin{split}
 P_+&\le c_\theta\int d\mathcal T\int\frac{dt}{t}
 \frac{(TQ_J/D)^\theta}{e_t^2}\,
 \int_{S_g\cap Z_t} w_t(y,v)a_v^{1+\theta}
 \frac{A(v)^\theta}{J(x-v)^\theta}
 \mathcal B_{r,t,k_t(v)}^{1/r}\,d\nu(v).
\end{split}\tag{AB10}
\]

这是直接代入式，不是新的独立预算假设。两份e_t分母显式保留：一份来自bad端Hölder，另一份来自good端dΠ_t。δ以严格低score的r次幂留在AB8中。若保留χ_FAΨ可取得更小原项；AB10没有主张它们在余下积分中自动产生额外衰减。

signed价格为2ΛP₊。不能在AB10中把外硬来源z换成内bad来源z′，也不能把β替换成ν。若先按SI2/SI5积分硬z，须携带其16/3和原接收依赖；它不能与仍带h_R的raw公式重复领取。N_Z不返回；N_Zc与N_del保持原负门各一次，不附本稿正项分层。

## 5. 全位置包络怎样合法进入Br的根号外

本节引用同目录[fractional_kernel_envelope.md](fractional_kernel_envelope.md)的FK1–5；其证明由主代理维护。本节只做接口与费用核对。取1<r<3/2，0<θ<1/3；固定b,c_j,t和来源中心y。设

\[
 G_y(v)=\prod_{i=1}^n\frac{e^{-|v_i-y_i|/b}}{1+|v_i-y_i|/b},\qquad
 V_{\theta,y}(z')=\prod_{i=1}^n
 \frac{e^{-(1-2\theta)|z'_i-y_i|/b}}
 {(1+|z'_i-y_i|/b)^{1-\theta}},
\]
\[
 N_{r,t,k}(y)=\int_{Z_t(y)\cap\{k_t(z')<k\}}
 [k-k_t(z')]^r V_{\theta,y}(z')^r\,d\nu(z').
 \tag{AB11}
\]

AB11只在已得AB9之后删除D_g门，保留严格score门及Z_t；其对x不再有bad集合依赖。它不是ν总质量被当作常数：任意有限ν时0≤N≤n^r\|ν\|，但这个粗价仍须支付。实际来源加权量可更小，且k=0严格给N=0。

写d_i=(x_i−y_i)/b，U_q(d)=∏(1+|d_i|)^θe^{qθ|d_i|}。真实H/b∈[1/2,1]，FK2逐坐标给

\[
 \mathcal B_{r,t,k}^{1/r}
 \le b^{n\theta}\left(\frac b{c_jt}\right)^n
 (C_0a_0^{-\theta}s^{-\theta})^n
 U_2(d)\,N_{r,t,k}(y)^{1/r}.
 \tag{AB12}
\]

这里用wt≤(b/(c_jt))ⁿ∏C，K₀≥实际soft乘积，并用1−θb/H≥1−2θ。来源核尾V保留在积分内，不需来源坐标独立。

good端用A≤w_τ以及τ=a/c_j，FK3给

\[
 w_t(y,v)\frac{A(v)^\theta}{J(x-v)^\theta}
 \le b^{n\theta}\left(\frac b{c_jt}\right)^n
 \left(\frac ba\right)^{n\theta}
 (C_0^{1+\theta}a_0^{-\theta})^n
 U_1(d)G_y(v).
 \tag{AB13}
\]

AB12–13是逐点估计，故可合法相乘再作真实dx积分。**不能仅对每个固定z′使用FK4后将dx与Br^{1/r}交换：通常Minkowski方向不支持该步骤。** 此处用FK2给出的统一逐点来源尾解决这个交换问题，代价是AB11的完整加权来源量。

若参数s,L,H固定（或先在同一参数块上使用合法统一包络），并只将a_v^{1+θ}、S_g等正门上放为1，则FK4–5的接收证明给

\[
 \int_{\mathbb R^n}p(x-y)
 w_t(y,v)\frac{A(v)^\theta}{J(x-v)^\theta}
 \mathcal B_{r,t,k_t(v)}^{1/r}\,dx
 \le\mathcal K_{r,n}\,G_y(v)N_{r,t,k_t(v)}(y)^{1/r},
 \tag{AB14}
\]
\[
 \mathcal K_{r,n}=
 b^{2n\theta}\left(\frac b{c_jt}\right)^{2n}
 \left(\frac ba\right)^{n\theta}M_{\theta,s}^n.
 \tag{AB15}
\]

所有尺度前因子来自两份wt、A和两个逆核。M_{θ,s}含s^{-θ}，故其n次幂含s^{-nθ}。AB14覆盖H<L₊与全部硬支持计数，不要求零硬坐标。它消除了任意深bad来源和good来源位置引起的指数失控，且θ<1/3使接收尾留出1−3θ>0的严格可积间隙。AB3–7是r=2的独立来源包络，不属于FK4接收可积范围；不能据AB4有限推出r=2的完整接收费用有限。

## 6. 核参数自适应的显式价格

AB14的固定核形式不直接允许将L(x)、H(x)、s(x)移出积分。不过，对**同一固定[a,b]块、同一y,j,t及来源存活集合**，核本身的选择器可以用显式指数维数费用覆盖。设s(x)≥s₀>0、a≤L(x),H(x)≤b≤2a。归一ℓ=L/b∈[1/2,1]，有一维逐点包络

\[
 p_{s,\ell}(d)\le
 2\mathbf1_{|d|\le1/2}+2A_0\frac{e^{-|d|}}{1+|d|}.
 \tag{AB16}
\]

证明：hard项由ℓ^{-1}≤2及其支撑给界；soft项由φ上界、ℓ≤1及ℓ^{-1}≤2给界。这是实核逐点上界，不需在来源后验中张量化。n维即取该一维包络乘积，虽同一选择器可依所有坐标，逐点乘积界仍成立。

AB12–13中用s₀代s，H/b的全区间已经统一。对AB16乘U₁U₂积分，hard项≤2e^{3θ/2}(3/2)^{2θ}，soft项≤4A₀/(1−3θ)。故将AB15中的M_{θ,s}替换为

\[
 \widetilde M_{\theta,s_0}=
 C_0^{2+\theta}a_0^{-2\theta}s_0^{-\theta}
 \left[2e^{3\theta/2}(3/2)^{2\theta}
       +\frac{4A_0}{1-3\theta}\right]
 \tag{AB17}
\]

后，AB14对这些可测核参数选择器仍成立。此处A(x,v)可随其实际h变化，因为仅用了统一A≤wτ；a_v与good门已上放。H<L₊或H≥L₊都覆盖，全部硬支持计数也覆盖。

这个统一价只覆盖p、K₀、J中的核参数；**不**把T(x)、Q_J(x)、q(x)、h_{R(x)}(x−z)、a_history(x)或者原允许集变成常数。特别是把AB17接入AB10时，这些接收乘子仍在原真实dx积分中。若来源中心、Z_t、b或c_j亦随x改变，AB11不能直接拔出，应继续按原相应块/唯一j/history保留；跨块没有免费重用容量。真实s₀可取原严格soft下门的下确界，但s₀^{-nθ}必须计入；不允许称为维数无关。

## 7. 费用与停止检查点

本轮得到两个严格改进：AB9把原共同RC余额与严格低score bad来源作非线性联合优化；AB12–17在真实核、实际尺度域和真实Lebesgue接收积分下证明深尾可积，并保留可计算的来源尾衰减。这比把κ或R_h重命名为新矩强：全位置的深尾发散已经被一个明确有限核常数替代，且核的自适应可以按AB17显式支付。

但目标εX+C√n polylog(n)Wβ尚未闭合。准确剩余费用为：

1. 核价b^{2nθ}(b/(c_jt))^{2n}(b/a)^{nθ}M^n，或自适应版本\widetilde M^n；含s₀^{-nθ}，没有根阶维数估计。
2. 实际加权来源费用e_t(y)^{-2}∫_{Z_t}G_y(v)N_{r,t,k_t(v)}(y)^{1/r}dν(v)。不假定e_t下界，不把ν总质量/q视为常数，也不把严格score差换成免费√n。
3. AB10内(TQ_J/D)^θ与原q^{-1}h_R a_history的真实接收耦合，以及β−ν、时间、唯一j/种子/history和跨块求和。FIRST的Q_J≤q可用于同一实际行，但仍留下T^θq^{θ−1}，不能据此删除接收或来源质量费用。

这三项须在**同一个完整原积分**中合并支付到Wβ及允许εX槽；不能各按不同删门交通重复领容量。AB14/17仅证明其中核尾的有限包络，未认证完整原积分有根阶价格。对r=4/3、θ=1/4可固定一个非临界检查点，接收尾间隙至少1/4；其余费用原样不变。此处停止，不另造标量反例或无限延伸，不登记新的ε槽，不改负项。
