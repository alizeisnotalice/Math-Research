#!/usr/bin/env python3
"""Finite soft-quotient tail log probes; no sup or asymptotic certification."""
from pathlib import Path
from fractions import Fraction as F
import sys,json,hashlib,datetime,traceback,importlib.util
ROOT=Path(__file__).resolve().parent
OLD=ROOT.parent/'centered_cube_round135_20261014/real_joint_numeric.py'
spec=importlib.util.spec_from_file_location('real_kernel',OLD); k=importlib.util.module_from_spec(spec);spec.loader.exec_module(k)
mp=k.mp
OUT=ROOT/'tail_probe.json'
RS=[F(4,3),F(3,2),F(2)]; HS=[F(1,2),F(3,5),F(1)]
GROUPS=[('initial',r,H,0,[2,4,8]) for r in RS for H in HS]+[('pressure',r,F(1,2),d,[2,4,8]) for r in RS for d in [-1,0,1]]+[('expanded',r,H,d,[16,64,256]) for r in RS for H in HS for d in [-1,0,1]]
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def qstr(q):return str(q)
def mf(q):return mp.mpf(q.numerator)/q.denominator
def dec(q):return mp.nstr(q,mp.mp.dps)
def save(data):OUT.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
def point(r,H,d,u,precision):
 mp.mp.dps=precision; rr,HH=mf(r),mf(H); uu=mp.mpf(u); dist=abs(mp.mpf(d)-uu)/HH
 E=lambda n,x:mp.expint(n,x)
 C=E(4,uu-1)-2*E(4,uu)+E(4,uu+1)
 phi=E(3,dist-mp.mpf('.5'))-E(3,dist+mp.mpf('.5'))
 logB=rr*mp.log(C)-(rr-1)*(mp.log(phi)-mp.log(HH)); rate=-r+(r-1)/H
 assert C>0 and phi>0
 return dict(C=C,phi=phi,logB=logB,rate=rate,logB_minus_rate_u=logB-mf(rate)*uu,logu=mp.log(uu),soft_density=phi/HH)
def main():
 if OUT.exists():raise SystemExit('Refuse second probe run; retain first record')
 sources=[ROOT/'tail_protocol.md',Path(__file__),OLD,ROOT.parent/'centered_cube_round133_20261014/third_numeric.py']
 out=dict(status='running',run_count=1,started_utc=utc(),precision_dps=[90,120],sha256={str(p):sha(p) for p in sources},scope='One-dimensional true phi/C finite soft quotient; K0 not equated to soft kernel; no full sup/asymptotic/FULL certification',groups=[],exceptions=[])
 save(out)
 for stage,r,H,d,us in GROUPS:
  group=dict(stage=stage,r=qstr(r),H=qstr(H),d=d,rate_exact=qstr(-r+(r-1)/H),points=[],finite_differences=[])
  try:
   points=[]
   for u in us:
    low=point(r,H,d,u,90); high=point(r,H,d,u,120)
    error=abs(high['logB']-low['logB'])/max(1,abs(high['logB']))
    origin_check=None
    if u==2:
     original=k.Cfun(mp.mpf(u)); origin_check=abs(high['C']-original)/high['C']
    checks=dict(logB_precision=error<mp.mpf('1e-75'),C_positive=high['C']>0,phi_positive=high['phi']>0,C_original_agreement=origin_check is None or origin_check<mp.mpf('1e-110'))
    rec=dict(u=u,C=dec(high['C']),phi_at_scaled_displacement=dec(high['phi']),soft_density=dec(high['soft_density']),logB=dec(high['logB']),logB_minus_rate_u=dec(high['logB_minus_rate_u']),logu=dec(high['logu']),logB_precision_relative_error=dec(error),C_original_relative_error=dec(origin_check) if origin_check is not None else None,checks=checks,status='passed' if all(checks.values()) else 'failed')
    group['points'].append(rec);points.append(high)
   for ii in range(2):
    slope=(points[ii+1]['logB']-points[ii]['logB'])/(us[ii+1]-us[ii]); rate=points[ii]['rate']
    group['finite_differences'].append(dict(u_left=us[ii],u_right=us[ii+1],log_secant_slope=dec(slope),predicted_rate_exact=qstr(rate),slope_minus_predicted_rate=dec(slope-mf(rate)),finite_slope_negative=bool(slope<0),critical_predicted_rate_zero=rate==0))
   group['status']='passed' if all(p['status']=='passed' for p in group['points']) else 'failed'
  except Exception as exc:
   group.update(status='exception',exception=repr(exc),traceback=traceback.format_exc());out['exceptions'].append(dict(stage=stage,r=qstr(r),H=qstr(H),d=d,exception=repr(exc),traceback=group['traceback']))
  out['groups'].append(group);save(out)
  print(stage,qstr(r),qstr(H),d,group['status'],'secants',[(p['u_left'],p['u_right'],p['log_secant_slope'][:18]) for p in group['finite_differences']],flush=True)
 points=[p for g in out['groups'] for p in g['points']];diffs=[p for g in out['groups'] for p in g['finite_differences']]
 out['summary']=dict(group_count=len(out['groups']),point_record_count=len(points),points_passed=sum(p['status']=='passed' for p in points),finite_difference_count=len(diffs),noncritical_finite_slopes_all_negative=all(p['finite_slope_negative'] for p in diffs if not p['critical_predicted_rate_zero']),critical_finite_slopes_all_negative=all(p['finite_slope_negative'] for p in diffs if p['critical_predicted_rate_zero']),max_relative_log_error=dec(max(mp.mpf(p['logB_precision_relative_error']) for p in points)),interpretation='All sign checks are finite-point evidence only. Negative noncritical rates are an analytic candidate supplied by parent, not proved by this probe; no global supremum or fitted order.',FULL_certified=False)
 out['status']='completed_with_failures' if out['exceptions'] or any(p['status']!='passed' for p in points) else 'completed_numerical_checks';out['finished_utc']=utc();save(out);print(out['summary'],flush=True)
if __name__=='__main__':main()
