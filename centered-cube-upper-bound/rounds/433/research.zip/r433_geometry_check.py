"""R433: rigorous rational interval checks and continuous-center examples.
No test certifies the full original stage/path history.
"""
from fractions import Fraction as F
from math import isqrt


def exp_interval(x, terms=160):
    assert 0 <= x < terms
    if x == 0:
        return F(1), F(1)
    term = total = F(1)
    for k in range(1, terms+1):
        term *= x/k
        total += term
    first = term*x/(terms+1)
    return total, total+first/(1-x/(terms+2))


def log_interval(x, terms=100):
    assert 1 <= x <= 2
    z = (x-1)/(x+1)
    lo = sum((2*z**(2*k+1)/F(2*k+1) for k in range(terms)), F(0))
    return lo, lo+2*z**(2*terms+1)/(F(2*terms+1)*(1-z*z))


def sqrt_interval(x, bits=100):
    assert x > 0
    scale = 2**bits
    k = isqrt(x.numerator*scale*scale//x.denominator)
    lo, hi = F(k, scale), F(k+1, scale)
    assert lo*lo <= x <= hi*hi
    return lo, hi


def product(values):
    out = F(1)
    for value in values:
        out *= value
    return out


def box_capture_volume(center_halfwidth, side, differences):
    # source y=0, z=d >=0 and actual center box [-halfwidth,halfwidth]^n
    return product(max(F(0), min(center_halfwidth, side/2)
                       - max(-center_halfwidth, d-side/2))
                   for d in differences)


# Stage 1: genuinely continuous center selector, side a in a central box,
# side b outside it. This stage tests the geometry, not full-f matching.
selector_cases = truncations = 0
a, b = F(1), F(2)
loglo, loghi = log_interval(b/a)
for n in [1,2,4,8]:
    for displacement in [F(1,10), F(1,2), F(3,2)]:
        d = [displacement/F(i % 3+1) for i in range(n)]
        D = sum(d, F(0))
        va = box_capture_volume(a/4, a, d)
        vb_outer = (box_capture_volume(b/2, b, d)
                    - box_capture_volume(a/4, b, d))
        assert va >= 0 and vb_outer >= 0
        ea, eb = exp_interval(D/a), exp_interval(D/b)
        actual_hi = va*ea[1]/a**n+vb_outer*eb[1]/b**n
        assert actual_hi <= 1+2*n*loglo
        for R in [a, (a+b)/2, b]:
            capture = product(max(F(0), R-di) for di in d)
            if capture == 0:
                truncations += 1
                continue
            assert D/R <= n
            exphi = exp_interval(D/R)[1]
            assert exphi*capture/R**n <= 1
            assert F(n)/R+D/R**2 <= F(2*n)/R
        selector_cases += 1
assert truncations > 0
print("Stage 1 PASS:", selector_cases,
      "continuous two-side selector kernels; zero-intersection truncations retained")


def packet_exp_mean(c1, c2, width, side):
    if c1 == c2:
        lo, hi = exp_interval(width/side)
        factor = 2*side**2/width**2
        return factor*(lo-1-width/side), factor*(hi-1-width/side)
    d = abs(c1-c2)
    assert d > width
    ep = exp_interval((d+width)/side)
    em = exp_interval((d-width)/side)
    ec = exp_interval(d/side)
    factor = side**2/width**2
    return factor*(ep[0]-2*ec[1]+em[0]), factor*(ep[1]-2*ec[0]+em[1])


# All subsequent models are actual full-f fields in n=1,2,4.
# Three disjoint uniform source packets. Positive-volume father blocks
# near -.3 and +.35 select side 1.2 and 1.5, respectively.
# Their capture sets are exactly {left,middle} and {middle,right}.
# A fourth packet at 1.3 is never captured by any actual receiver.
centers = [F(-3,5), F(0), F(3,5), F(13,10)]
parent_centers = [F(-3,10), F(7,20)]
sides = [F(6,5), F(3,2)]
captures = [[0,1], [1,2]]
models = []
graph_cases = inflation_cases = 0
for n in [1,2,4]:
    left_total, right_total = sides[0]**n, sides[1]**n
    source_mass_base = [left_total/2, left_total/2, right_total-left_total/2]
    for width, center_width, outside_mass in [(F(1,100), F(1,100), F(0)),
                                             (F(1,50), F(1,50), F(2)),
                                             (F(1,25), F(1,25), F(20))]:
        masses = source_mass_base+[outside_mass]
        for p, side in enumerate(sides):
            for k, source_center in enumerate(centers):
                farthest = abs(parent_centers[p]-source_center)+(center_width+width)/2
                nearest = abs(parent_centers[p]-source_center)-(center_width+width)/2
                if k in captures[p]:
                    assert farthest < side/2
                else:
                    assert nearest > side/2
            m = sum((masses[k] for k in captures[p]), F(0))
            assert m == side**n  # actual matching q=1, no density cap
        graph = [[any(i in cap and j in cap for cap in captures)
                  for j in range(4)] for i in range(4)]
        U = [sum((masses[j] for j in range(4) if graph[i][j]), F(0))
             for i in range(4)]
        assert U == [left_total, sum(source_mass_base), right_total, F(0)]
        # Center-block Lebesgue measure, not an arbitrary incidence declaration:
        for i in range(4):
            for j in range(4):
                common_center_volume = sum((center_width**n for cap in captures
                                            if i in cap and j in cap), F(0))
                assert graph[i][j] == (common_center_volume > 0)
        # Both middle and right local b-neighborhoods contain the external packet.
        for i in [1,2]:
            assert abs(centers[i]-centers[3])+width < max(sides)
        if outside_mass:
            inflation_cases += 1
            assert U[1] == sum(source_mass_base)
            assert sum(masses) > U[1]  # local volume mass changes; U does not
        models.append((n, width, center_width, masses, graph, U))
        graph_cases += 1
print("Stage 2 PASS:", graph_cases, "full-f native common-parent graphs;",
      inflation_cases, "external-packet inflations leave U unchanged")


# Stage 3: exact packet integrals up to certified exponent/square-root intervals.
# Evaluate the full source-Schur integral and the matched static moment.
moment_cases = marked_checks = positive_branch = 0
for n, width, center_width, masses, graph, U in models:
    W_active = sum(masses[:3])
    schur_hi = F(0)
    for i in range(4):
        for j in range(4):
            if graph[i][j]:
                denom_lo = sqrt_interval(U[i]*U[j])[0]
                schur_hi += masses[i]*masses[j]/denom_lo
    assert schur_hi <= W_active
    moment_lo = moment_hi = F(0)
    for p, side in enumerate(sides):
        for i in captures[p]:
            for j in captures[p]:
                root_lo, root_hi = sqrt_interval(U[i]*U[j])
                elo, ehi = packet_exp_mean(centers[i], centers[j], width, side)
                same_lo, same_hi = packet_exp_mean(F(0), F(0), width, side)
                elo *= same_lo**(n-1)
                ehi *= same_hi**(n-1)
                assert 0 < elo <= ehi
                scale = center_width**n*masses[i]*masses[j]/side**n
                moment_lo += scale*elo/root_hi
                moment_hi += scale*ehi/root_lo
    c_lo, c_hi = log_interval(max(sides)/min(sides))
    assert 0 < moment_lo <= moment_hi <= (1+2*n*c_lo)*W_active
    # Positive retained factors are diagnostic static restrictions, not histories.
    for mark in [F(1,4), F(1,2), F(1)]:
        assert mark*moment_hi <= (1+2*n*c_lo)*W_active
        marked_checks += 1
    # Every middle/right packet pair in the right father block has positive
    # static branch T_G >= C_G/(1+sqrt(n)); this is not original path history.
    branch_lo = (sides[1]**n
                 * exp_interval((centers[2]-centers[1]-width)/sides[1])[0]
                 / sqrt_interval(U[1]*U[2])[1])
    threshold_hi = (1+2*n*c_hi)/F(1+isqrt(n))
    assert branch_lo > threshold_hi
    positive_branch += 1
    moment_cases += 1
print("Stage 3 PASS:", moment_cases,
      "native full-source static moments and source-Schur bounds;",
      marked_checks, "positive-restriction checks;",
      positive_branch, "positive static payment branches")
print("All calculations use Fraction with analytic outward exp/log/sqrt intervals.")
print("No complete original stage, two-path history, or global root closure certified.")
