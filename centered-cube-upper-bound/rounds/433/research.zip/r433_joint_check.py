from fractions import Fraction as F
from itertools import product

def ln_bounds(x,N=100):
    assert x>0
    if x<1:
        l,u=ln_bounds(1/x,N);return -u,-l
    if x>2:
        k=0;y=x
        while y>2:y/=2;k+=1
        l,u=ln_bounds(y,N);a,b=ln_bounds(F(2),N)
        return l+k*a,u+k*b
    z=(x-1)/(x+1);p=z;lo=F(0)
    for j in range(N):lo+=2*p/F(2*j+1);p*=z*z
    return lo,lo+2*p/(F(2*N+1)*(1-z*z))
def exp_bounds(x,N=100):
    assert 0<=x<N+2
    term=lo=F(1)
    for k in range(1,N+1):term*=x/k;lo+=term
    first=term*x/(N+1)
    return lo,lo+first/(1-x/F(N+2))
def vol_intersection(cell,y,R):
    out=F(1)
    for k,x in zip(cell,y):out*=max(F(0),min(F(k+1),x+R)-max(F(k),x-R))
    return out

def grid_test(n,items):
    # Continuous f: constant mass/density items[C] on unit cubes C.
    assert all(m>0 for m in items.values())
    W=sum(items.values());entropy_upper=F(0);neighbor_total=F(0);pointchecks=0
    for C,m in items.items():
        N=sum(v for D,v in items.items() if max(abs(c-d) for c,d in zip(C,D))<=2)
        neighbor_total+=N
        _,logu=ln_bounds(N/m);entropy_upper+=m*logu
        for offset in [F(1,4),F(1,2),F(3,4)]:
            y=[F(c)+offset for c in C]
            Va=sum(v*vol_intersection(D,y,F(1)) for D,v in items.items())
            Vb=sum(v*vol_intersection(D,y,F(2)) for D,v in items.items())
            assert m<=Va<=Vb<=N;pointchecks+=1
    assert neighbor_total<=5**n*W
    ln5lo,_=ln_bounds(F(5))
    assert entropy_upper<=W*n*ln5lo
    return pointchecks
stages=[
 [(1,{(0,):F(1)}),(1,{(0,):F(1),(1,):F(2),(2,):F(3)}),(2,{(0,0):F(1),(1,0):F(2),(0,1):F(3),(1,1):F(4)})],
 [(1,{(-3,):F(1,100),(0,):F(100),(3,):F(1)}),(2,{(0,0):F(1,1000),(3,3):F(1000),(4,0):F(2)}),(3,{(0,0,0):F(1),(3,3,3):F(100),(1,0,2):F(1,7)})],
 [(1,{(k,):F((k+9)**2) for k in range(-8,9)}),(2,{(k,l):F(1+3*k+l,7) for k in range(4) for l in range(4)}),(3,{p:F(1+sum((i+1)*x for i,x in enumerate(p)),13) for p in product(range(3),repeat=3)})]
]
points=sum(grid_test(n,cells) for batch in stages for n,cells in batch)
print(f'PASS: 9 continuous finite-grid entropy certificates (3/3/3), {points} exact local-volume containments.')
# Native receiver field: parent centers [-1/20,1/20], actual side R.
# f=1[-4,4] + remote mass Q in [17R/10,17R/10+1/100].
# Every actual parent matches m=R, q=1. All of its source points have V_R=2R.
# Its full static joint moment is |E|*(e-2), analytically integrated in y,z.
native=0
for R,Q in [(F(1),F(0)),(F(1),F(1)),(F(1),F(1000)),
            (F(5,4),F(1,100)),(F(5,4),F(100)),(F(5,4),F(10000)),
            (F(3,2),F(1)),(F(3,2),F(100)),(F(3,2),F(1000000))]:
    E=(-F(1,20),F(1,20));remote=(17*R/10,17*R/10+F(1,100))
    assert E[1]+3*R/2<remote[0] and remote[1]<4
    y=-2*R/5;z=2*R/5
    assert E[1]-R/2<=y<z<=E[0]+R/2
    assert y+2<remote[0] and remote[1]<=z+2
    actual_local=2*R;old_local=4+Q
    # Exact rational lower certificate for T_actual/T_b.
    exlo,_=exp_bounds(F(4,5)-2*R/5)
    ratio_lo=old_local/actual_local*exlo
    assert ratio_lo>=1
    elo,ehi=exp_bounds(F(1))
    moment_upper=F(1,10)*(ehi-2)
    assert moment_upper<=8+Q # even the sharper fixed-R static price W
    native+=1
    print(f'native R={R}, remote_mass={Q}, local_actual={actual_local}, local_b={old_local}, rational_ratio_lower_as_float={float(ratio_lo):.8g}')
print(f'PASS: {native} native positive-center/full-source matching models (3/3/3); q=1, true full double-source integral, no original stage/history claim.')
print('Entropy and moment inequalities use exact Fraction bounds. Printed decimal ratios are diagnostics only; no root closure asserted.')
