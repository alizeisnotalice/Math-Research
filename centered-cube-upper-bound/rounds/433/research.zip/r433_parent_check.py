from fractions import Fraction as F
from itertools import product
from math import prod

def log_small(x,N=120):
 z=(x-1)/(x+1)
 assert F(1)<=x<=F(2)
 lo=sum((2*z**(2*k+1)/F(2*k+1) for k in range(N)),F(0))
 return lo,lo+2*z**(2*N+1)/(F(2*N+1)*(1-z*z))
L2=log_small(F(2))
def logbox(x):
 k=0
 while x<1:x*=2;k-=1
 while x>2:x/=2;k+=1
 lo,hi=log_small(x)
 return (lo+k*L2[0],hi+k*L2[1]) if k>=0 else (lo+k*L2[1],hi+k*L2[0])
def expbox(x,N=180):
 t=lo=F(1)
 for k in range(1,N+1):t*=x/k;lo+=t
 return lo,lo+t*x/F(N+1)/(1-x/F(N+2))
# Three stages: balanced, concentrated, and very small masses.
count=0
for phase in range(3):
 for n in [1,2,3]:
  cells=list(product(range(3),repeat=n))
  for seed in range(3):
   if phase==0:mass=[F(1+(i+seed)%5) for i in range(len(cells))]
   elif phase==1:mass=[F(2)**((i*7+seed)%41-20) for i in range(len(cells))]
   else:mass=[F(3)**((i*11+seed)%61-30) for i in range(len(cells))]
   # Exact finite subset of the actual lattice; each point has <=5^n neighbors globally.
   N=[sum((m for y,m in zip(cells,mass) if max(abs(a-b) for a,b in zip(x,y))<=2),F(0)) for x in cells]
   W=sum(mass,F(0));assert sum(N,F(0))<=5**n*W
   upper=sum((m*logbox(v/m)[1] for m,v in zip(mass,N)),F(0))
   lower=W*n*logbox(F(5))[0]
   assert upper<=lower
   count+=1
 print(f'phase {phase+1}: 9 rational interval lattice entropy checks PASS')
print(f'{count} lattice entropy certificates PASS; these validate the Jensen interface, not full original history')
# The exponential factor is canceled by real common-center intersection volume.
count=0
for n in [1,2,4,8,16,32]:
 for d in [F(1,100),F(1,4),F(3,4)]:
  upper=expbox(n*d)[1]*(1-d)**n
  assert upper<=1
  assert n+n*d<=2*n
  count+=1
print(f'{count} rational exponential/common-center volume checks PASS')
