r433_rows=[];
for nn=[16 64 256 1024 4096 16384 65536 1048576 1099511627776]
 for band=[1 1.01 2]
  ss=1+sqrt(nn);cg=1+2*nn*log(band);
  if band==1,cl=1;else,cl=cg+2*nn*log(5);end
  S=2;price=2*S*ss;
  r433_rows(end+1,:)=[nn band cg cl cg/ss cl/ss price price/sqrt(nn)];
 end
end
writematrix(r433_rows,'/tmp/r433_matlab_parameters.csv');
fid=fopen('/tmp/r433_matlab.result.txt','w');
fprintf(fid,'MATLAB %s\n27 parameter rows; floating diagnostics only\nnew price/sqrt(n): min=%.17g max=%.17g\n',version,min(r433_rows(:,8)),max(r433_rows(:,8)));
fclose(fid);
disp(fileread('/tmp/r433_matlab.result.txt'));
