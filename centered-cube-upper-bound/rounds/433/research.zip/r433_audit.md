# R433 独立最终审查

FINAL PASS（限定本轮静态矩和顺序正分支付款）。已审最终主稿、共同父图稿、实际尺度局部质量稿、README及三脚本；未发现必须修订的问题。两项一般静态矩成立，接原Π432的两支合计新增2SsW。完整低指标剩余交集、全尺度与最终一般一致弱型上界仍未证明。

## 关键证明与原费用接口

1. 对非负静态F(A,y,z)，由原a_i^e(A,y)≤B_e、同z上的Σ_i b_i(z)≤1以及原early阶段上包络，实际推前≤Sσπ_A²。原初始有效记录及条件核先保留，再把总概率≤1的路径/未来部分正积分；不用总量SX替代sourcewise支配。F不依未积分路径，因此无需terminal exact-j、Θ²或τ，不刷新来源。
2. G由正Lebesgue父中心测度定义，可测且对称。Tonelli给G=1及U(y)≥m_A仅在真实父—来源支撑a.e成立；零U处核取0，不把孤立零测父添加进图。完整匹配消去m_A后，R^−n exp(d/R)的b端base和负导数结合真实共同捕获中心体积，得C_G=1+2nlog(b/a)。保G支持至两向归一积分，静态矩≤C_GW_G≤C_GW。
3. 局部V_R=f(Q_{2R})对R绝对连续，fdy-a.e V_a>0；max亦AC。连续层叠完整保base、普通导数与正局部质量恢复项。恢复项≤2∫f log(V_b/V_a)。a半开格的5^n邻格计数、零格跳过及可数Jensen合法，有限期望足够，不需额外LlogL假设；故C_loc=1+2nlog(b/a)+2nlog5（b=a单独取1）。实际选择器可在某边长有正中心测度，证明未删除该原子。结论依赖f为L1密度，不扩展为任意带边界原子来源测度。
4. 两静态指标不需点态比较。在同一原流上先付T_G高门，再在其补集付T_loc高门，每支≤SsW。C433=C432、V433=V432+2Ss；旧Fhat和16/32/64母账保留，入口仅增128ΛFhatSsW，无新增X_q、旧退款、终端重复价或平方信用。未保证各输入上支非空或固定比例；两个低指标不能改称完整无权付款。

## 实际复现与有限证据范围

在新隔离目录以系统python3分别执行三脚本，退出码均0，三个stdout与冻结结果逐字一致。geometry：12连续选择器核、9完整来源共同父图（6外部包膨胀不改U）、9完整静态矩、27正限制及9正静态分支；joint：9连续网格熵证书、231体积包含、9连续中心匹配模型；parent：27有理区间网格熵及18指数—共同中心体积检查。重跑不新增样本，临时prescreen核验不计主统计或打包。

核查了原生模型的来源包捕获、完整匹配、正中心体积以及指数包积分；它们不认证当前n≥9原远质量、占用阶段、两路径及完整历史资格。joint输出的小数比值仅展示其精确有理下证书，不作一般阶数拟合。

已检查MATLAB脚本、实际结果与27行CSV，并用Python独立核全部C_G/C_loc阈值及新增价格公式。本审查未另行执行MATLAB。MATLAB参数表为浮点诊断，不是区间证书；普遍证明来自上述解析界。实际stage推前合同已核R413原a_i包络及R411阶段求和来源；不重新认证全部历史归约。

## 最终SHA-256绑定

- `r433_main.md`: `1915262e23420c163a10dfb805def02917a7d652d78f59d4447e3101ed7b3566`
- `r433_geometry.md`: `88d99bd3cd9bf6adc26458c143015df41ee3e83d9ff3f9655b3f60154074a0f2`
- `r433_joint.md`: `5066f6c93e2df950c0c695c4a57a918d152017bfc52d3f32ed433d1bfdcce5b7`
- `r433_readme.md`: `388eb485c20f7de4870f39e352325a008b0efc4eb82c33fcf39bf278e0d0f044`
- `r433_geometry_check.py`: `640f49f42e1c0282d899325c9cdeb18a20d4f363f893f6199a59e62b2107914c`
- `r433_geometry.result.txt`: `6a7291216835dcca937d569e6b6a537211ce9238f7100d07616e767dfeeaa8f9`
- `r433_joint_check.py`: `510c3558c38d21f2acdcba532f452b61c555e317652d783bd446800c72ff9b7d`
- `r433_joint.result.txt`: `1d71088350ba31621dae9be15a5ec2fb6f3d05acc48d36e6a9c4a7070bee7e9d`
- `r433_parent_check.py`: `331bac7e09e12756a9eb9de59924b5f4d7972b31cc8a875708d3ca2849c21616`
- `r433_parent.result.txt`: `d0267a528d532cef2ece4ef797339d23cdfc1974085ae9f0944e63321d1adefa`
- `r433_parameters.m`: `f3aee77d9dddf606f5912bb5113fcb54ddb656093d4c72b1afaa607757df8428`
- `r433_matlab_parameters.csv`: `1e659ac2fbd0b41a4a5c34ed0e37b9197b7e6aa70dccf0f2968bd06282fdbe84`
- `r433_matlab.result.txt`: `125a46d302a62570299e14bf07964beb4676c55fa3110190b28203c77c611099`
