# R353 — The old physical clock and actual-source spatial crossing

## Proved new branch payment

Keep the original late marked measure and its R350 actual rank witness w. Restricting it to the R351 core, or to any further already defined marked subflow, does not change that witness or any original field. This note pays two disjoint pieces: first the part whose old clock is near the witness's scale; then the part whose original source lies inside an inner cube about that witness. The remainder has a genuine source-specific spatial crossing condition at the original time.

Let x=√n, s=1+x, and

    A_n=1+n log(b/a)≤1+n log 2,
    σ^n=min(1,s/A_n),   0<σ≤1,
    c_n=(λ/q_-)e^{-x} max(1,A_n/s).

For the already marked core flow G_core[g], with g=g_ex in the ledger, there is an exact nonnegative partition

    G_core[g]=G_clock[g]+G_inner[g]+G_cross[g],          (1)

with

    G_clock[g]≤c_n X_q,
    G_inner[g]≤σ^n A_n ∫g≤s∫g.                       (2)

The unpriced term has the two simultaneous conditions

    r<σR_w,    ||w−y||∞>σR_w/2.                       (3)

In particular y is captured by the full witness Q_w, but

    y∉Q_r(w),   Q_r(w):=w+[-r/2,r/2]^n.               (4)

The old source has not yet been spatially captured at the witness center at the old physical clock r. We do not replace r by R_w, or replace any original clock denominator by a terminal quantity.

The two payments in (2) are genuine parts of the original marked traffic. This note does not bound all of G_cross or claim that the two paid parts contain a fixed positive fraction of every input.

## 1. Frozen full-f field and exact marked measure

Use the actual receiver set E with Lebesgue du and centered cubes Q_u of side R_u∈[a,b], b≤2a. Keep

    m_u=∫f c_u=q_u R_u^n,
    q_-=3λ/4≤q_u≤λ,   c_u(y)=1_{Q_u}(y),
    ρ_y(du)=c_u(y)du/m_u,
    ν_y(du)=q_uρ_y(du)=c_u(y)R_u^{-n}du.

Here f≥0 is arbitrary L¹; all masses, radii, q, J and gates use the same full f. Set K=e^{√n}. The old clock is

    ell=b^{-n}δ_b+n r^{-n-1}dr on [a,b],
    ell([R,b])=R^{-n}.

Let the original late amplitude be

    H_y(u,r)=η_y(u)Ω_y(u,r)
      1_{U_y(Km_u)>εJ_y}
      1_{U_y^r(Km_u)≤1/q_-}.

All original small-endpoint, high-past, far-mass, outside-center, H and full J_y(r) factors remain inside Ω. We use only the already proved bound 0≤H≤1; H is not redefined after any new restriction.

The R350 rank kernel Q_y(u,dw) depends only on (y,u), not on r. It has the three proved properties

    Q_y(u,E)≤1,
    Q_y(u,{w:c_w(y)=1, m_w>Km_u})=Q_y(u,E),
    ∫ν_y(du)Q_y(u,dw)≤ν_y(dw).                        (5)

It is a probability on positive original late rows. After dropping the old gates in an upper estimate, only its subprobability property in (5) is used; we do not assert row mass one for every u.

Before the core restriction, the exact joint measure is

    dF=g(y)c_u(y)H_y(u,r)1_{r∈[R_u,b]}
          dy du ell(dr)Q_y(u,dw).                    (6)

For G_core insert the fixed R351 core indicator 1_{w∈C}. More generally, the proof below permits any additional already defined measurable mask M(y,u,r,w,...)∈[0,1]. Any further history labels are retained in their actual conditional measure. Bounding by (6) is legitimate because their total conditional weight is at most one. No core, rank order, posterior, or old time is recomputed.

Define the disjoint masks in (1) by

    clock: r≥σR_w;
    inner: r<σR_w and ||w−y||∞≤σR_w/2;
    cross: r<σR_w and ||w−y||∞>σR_w/2.                 (7)

Equality at the spatial inner boundary belongs to inner; equality at the clock threshold belongs to clock. These exhaust the original measure.

## 2. Actual physical-clock tail pays the near-scale piece

For every pair with m_w>Km_u and every 0<σ≤1,

    ∫_[R_u,b]1_{r≥σR_w}ell(dr)≤(σR_w)^{-n}.           (8)

If σR_w≤R_u, the left side is R_u^{-n}≤(σR_w)^{-n}. If R_u<σR_w≤b, the inclusive tail identity gives equality with (σR_w)^{-n}. If the threshold exceeded b, the left side would be zero. In particular, a threshold equal to b contributes its b atom and is not discarded.

The true mass/average relation gives

    (R_u/R_w)^n=(m_u/m_w)(q_w/q_u)
          < λ/(Kq_-).

Combining this with (8),

    ∫_[R_u,b]1_{r≥σR_w}ell(dr)
          ≤[λ/(q_-Kσ^n)]R_u^{-n}.                    (9)

Delete only nonnegative factors bounded by one, including H and the core mask, and use that Q is independent of r. Tonelli, (5), and (9) yield

    G_clock[g]
      ≤[λ/(q_-Kσ^n)]∫g(y)∫_E c_u(y)R_u^{-n}du dy
      ≤[λ/(q_-Kσ^n)]X_q.                             (10)

The last inequality is exact full-f accounting:

    ∫g(y)D_E(y)dy
       =∫_E q_u [∫g c_u/m_u]du≤∫_E q_u du=X_q,

since 0≤g≤f. Equation (10) proves the first payment in (2). It uses the original old clock and the real mass-separated upper witness. It does not infer a time distribution from the terminal upper occupancy or substitute terminal witnesses into the old prefix gate.

## 3. Actual-center inner capture capacity

For any fixed y and 0<σ≤1,

    ∫_E 1_{||w−y||∞≤σR_w/2}R_w^{-n}dw≤σ^n A_n.     (11)

To prove it, let z=(2||w−y||∞)^n. A receiver contributing to (11) has z≤σ^nR_w^n≤σ^n b^n and R_w^n≥max(a^n,z/σ^n). Its density is at most

    1/max(a^n,z/σ^n).

The true Lebesgue volume of {w:(2||w−y||∞)^n≤z} is exactly z. Enlarging E to the full admissible center region therefore bounds (11) by

    ∫_0^{σ^n a^n} dz/a^n
       +∫_{σ^n a^n}^{σ^n b^n} σ^n dz/z
      =σ^n[1+n log(b/a)].                            (12)

This is an integral in the actual receiver centers. It is not a bound on the mass of an arbitrary f in a thin shell or in an inner cube.

Now drop the clock condition r<σR_w and the other masks when bounding G_inner. Contracting the unchanged clock gives, for each (y,u), a factor at most R_u^{-n}. The sourcewise column domination in (5) then gives

    G_inner[g]
      ≤∫g(y)∫ν_y(du)∫Q_y(u,dw)
                    1_{||w−y||∞≤σR_w/2}dy
      ≤∫g(y)∫ν_y(dw)1_{||w−y||∞≤σR_w/2}dy
      ≤σ^n A_n ∫g.                                  (13)

The original source y remains the same source in this calculation; there is no independent new posterior. For g=g_ex the fee is W_ex, not full W. The selected inner region is centered at the actual upper witness w, rather than the old small-center neighborhood paid in R338.

This derivation uses the R350 sourcewise column, not just its integrated κ≤q consequence. Without that sourcewise statement, preserving the original y label in (13) would require additional justification.

## 4. Choice of shrink factor and effective clock coefficient

Taking σ^n=min(1,s/A_n) proves σ^n A_n≤s and the announced c_n. For x=√n≥1,

    max(1,A_n/s)≤x,

because A_n≤1+x² and (1+x²)/(1+x)≤x. Thus

    c_n≤(λ/q_-)x e^{-x}=(4/3)x e^{-x}.               (14)

The original high-past gate can be nonempty only if

    A_n>(1+x)/ε.

Indeed its threshold is h=(1+x)/(εq_-), whereas the original terminal capture obeys J_y≤A_n/q_-. Since A_n≤1+x²≤x(1+x), this forces x>1/ε. The elementary strict exponential inequality e^x>x^4/24 gives

    c_n<32/x³<32ε³<ε/16                              (15)

at ε=119/3072. The last numerical comparison is exact:

    512ε²=14161/18432<1.

If the necessary high-past condition fails, the original traffic in this note is zero; define c_eff=0 there. Otherwise set c_eff=c_n, retaining its exact value in the ledger instead of replacing it by ε/16.

Hence the new core estimate is

    G_core[g_ex]≤G_cross[g_ex]+c_eff X_q+sW_ex.        (16)

This is the sum of two disjoint paid branches, each counted once. The core mask from R351 remains on every term. In the edge case σ=1, y∈Q_w makes the cross branch empty; the proof still applies without assigning an artificial boundary contribution.

## 5. Geometry of the actual remaining source crossing

Every retained marked tuple has c_u(y)=c_w(y)=1, all old core/ηΩ/high-past/outside/prefix gates, and

    ||w−y||∞>σR_w/2>r/2,
    r<σR_w≤R_w.

Thus there is a coordinate in which the original source y lies beyond the face of Q_r(w), although y belongs to Q_{R_w}(w). This is the source-specific spatial crossing asserted in (3)–(4). The coordinate may depend on the tuple; the proof does not take a free union of separately paid coordinate regions.

The condition is only geometric. It does not bound the full f-mass of that boundary layer, nor does it make crossing events on distinct source/receiver paths disjoint. A general budget for their total G_cross is not established here. The result narrows the original late core by an actual payment, rather than changing the old time or replacing its denominator.

The notes R338 and R345 provide related center or source-window tools. The present proof uses a different marked upper-witness spatial condition together with the original physical clock and the R350 sourcewise rank column. Only those local notes were checked for this distinction; no exhaustive historical novelty claim is made.

## 6. Exact composition with ancestor recapture and the hard-slot ledger

The composition order is fixed. Start with the R351 marked G_core. First perform the clock-near and old-source inner split (7), obtaining the remaining measure R=G_cross. Only then apply the R352 first-ancestor-recapture partition to R. Its old upper bound applies at the same price because R is a restriction of the existing marked measure: its incoming initial-witness density κ_R is still at most q, and all original ancestor mass guards remain in place.

Write R=R_rec+F_edgefresh. The R352 estimate gives R_rec≤α_rec X_q with its already proved coefficient α_rec; this is a newly restricted application of that theorem, not an extra copy of its previous whole-G_core payment. The exact composed estimate is therefore

    G_core≤F_edgefresh+(c_eff+α_rec)X_q+sW_ex.          (17)

The crossing guard r<σR_{w0} and y∉σQ_{w0} always refers to the initial R350 witness w0. Later current endpoints w1,w2,... in the R352 marked path do not inherit this old-clock relation. In particular, the old r is never paired with a later endpoint's radius merely because its mass is larger.

Thus the complete hard-slot ledger, at this entry, is

    B_H≤F_edgefresh
       +[(13/3)ε+γ_eff+ε/16+c_eff+α_rec]X_q
       +[C_{ε,n}+4s]W+(C_top+C_hit+s)W_ex.             (18)

Each fee is counted once. The two new terms from this note are exactly c_eff X_q+sW_ex. The R351 peeling fee remains once; the R352 recapture fee is used only in the restricted composition just described. No separate posterior inner-rich payment is included.

Entrance factor two and the historical exterior Λ=128/119 apply to these terms. If the historical CZ 1/256 belongs to the same certified outer X ledger, its combined receiver coefficient is

    853/2304+2Λ(γ_eff+α_rec+c_eff)<889/2304,

using the already proved three strict ε/16 bounds. The unallocated amount exceeds 1415/2304; it is not claimed to pay any other archived slot. This arithmetic is conditional on the same historical CZ placement as the parent ledger. All other unpriced terms remain unchanged.

## 7. Executed exact checks

The following code was actually run with fractions.Fraction. It verifies the exact ε comparison and 96 physical-clock tail identities, including the terminal atom. These are algebra checks of the proof's tail calculation, not simulations of the original high-past/core contract.

```python
from fractions import Fraction as F
from itertools import product
eps=F(119,3072)
assert 512*eps*eps<1
print('512 eps^2 =',512*eps*eps,
      '; 32eps^3 < eps/16:',32*eps**3<eps/16)
checks=0
for n,Ru,Rw,b,alpha in product(
    [1,2,4,8], [F(1),F(5,4)], [F(3,2),F(2)],
    [F(2),F(5,2)], [F(1,2),F(3,4),F(1)]):
 if not (Ru<=Rw<=b): continue
 t=alpha*Rw
 threshold=max(Ru,t)
 tail=threshold**(-n) if threshold<=b else F(0)
 assert tail<=alpha**(-n)*Rw**(-n)
 if threshold<=b:
  continuous=threshold**(-n)-b**(-n)
  atom=b**(-n)
  assert tail==continuous+atom
 checks+=1
print('PASS',checks,
      'exact clock-tail inequalities and terminal-atom decompositions')
```

Output: 512ε²=14161/18432; the strict ε comparison is true; all 96 tail checks passed. Only /tmp/r353_geometry.md was authored. The general core traffic bound remains open.
