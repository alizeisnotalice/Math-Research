# R353 final independent audit — PASS for the stated marked subreceipts

Reviewed the final geometry proof (including its corrected composition Section 6), main, complete ledger, README, numeric code/result/notes, and standalone geometry checks. Only owned audit files were changed; no author files or Git state were modified. The entire historical reduction and its outer aggregation are inherited, not exhaustively re-audited here. General root-order weak-type closure is not certified.

## 1. Original joint measure and clock-near payment: PASS

The proof retains the original full f, actual receiver Lebesgue measure, m=qR^n, q_-<=q<=lambda, old y/u/small endpoint/r, all eta-Omega/high-past/outside/relative-upper/late gates, and the ORIGINAL rank witness w_0. The kernel Q_y(u,dw_0) is independent of r; its full rows need only be subprobabilities after positive original gates are dropped. It preserves capture of the same original y, has m_w>K m_u, and has the sourcewise nu_y column bound. The R351 core is a fixed gate on w_0.

For sigma^n=min(1,s/A_n), s=1+sqrt(n), the first mask is r>=sigma R_w. Tonelli over the unchanged clock gives ell([max(R_u,sigma R_w),b])<=sigma^{-n}R_w^{-n}, including the real b atom. The true mass gap bounds this by [lambda/(q_-K sigma^n)]R_u^{-n}. Integrating the kernel row and then original g<=f uses int g D_E<=X_q. Therefore G_clock<=c_n X_q with c_n=(lambda/q_-)K^{-1}max(1,A_n/s). No extra scale factor or source mass copy is needed. The proof does not substitute the new witness into the original prefix denominator or claim it was already active at old r.

On nonzero original high-past traffic, A_n>(1+sqrt(n))/epsilon forces x=sqrt(n)>1/epsilon. Since max(1,A_n/s)<=x, c_n<32/x^3<32epsilon^3<epsilon/16. The exact last condition is 512epsilon^2=14161/18432<1. Empty original traffic has effective coefficient zero. The sigma=1 case, a=b edge case, thresholds below a, and equality at b are valid without an invented lower-end atom.

## 2. Old-source inner payment: PASS

Only on the remaining r<sigma R_w branch is y inside sigma Q_w paid next. Its upper estimate drops that r restriction, contracts the original clock, and uses the SOURCEWISE column int nu_y(du)Q_y(u,dw)<=nu_y(dw). The integrated marginal kappa<=q alone would not justify preserving the old y; the stronger inherited column statement is explicitly used.

For fixed y, the actual receiver-center density integrates to at most sigma^n A_n: the volume variable z=(2||w-y||_infty)^n has Lebesgue volume z, the contributing centers satisfy z<=sigma^n b^n, and their density is bounded by 1/max(a^n,z/sigma^n). The resulting two integrals give sigma^n[1+n log(b/a)]. Variable actual radii and selector-boundary sets do not invalidate this full positive envelope. This is receiver geometry, not a density cap on f or a thin-shell source-mass estimate.

Consequently G_inner<=sigma^n A_n int g<=s int g. With g=g_ex the new price is s W_ex, not full W. The inner mask is taken after clock-near removal, so the two actual paid subbranches are disjoint even though their upper bounds use positive supersets.

## 3. Exact composition with R352: PASS

The final documents reconstruct from G_core rather than replace a residual by a smaller expression inside an old inequality. The exact order is
 G_core=G_clock+G_inner+R,
 followed by R=B_rec,R+F_edgefresh under the R352 marked extension.
The remaining input R is a restriction of the original joint law, its incoming w_0 marginal is still <=q, and all original old-v/u/w_0 mass-chain guards remain. Hence the R352 first-recapture coefficient applies at the same price to R. It is not simultaneously charged again for the old whole G_core. All later source draws and transitions retain their original labels and their genuine conditional laws.

The surviving original geometry is r<sigma R_{w0} and ||w0-y||_infty>sigma R_{w0}/2, so y is outside Q_r(w0), while it is captured by the full Q_{Rw0}(w0). Clock equality is assigned to clock-near and spatial equality to inner. These gates refer only to initial w_0. They are not transferred to later current endpoints of the R352 chain. Fresh terminal source regions remain disjoint only along individual paths, with cross-path occupation still unbounded at root scale. No universal positive proportion of either new paid piece is asserted.

## 4. Ledger, multipliers and unresolved terms: PASS with inherited aggregation condition

The hard slot is correctly
 B_H<=F_edgefresh+[(13/3)epsilon+gamma_eff+beta+alpha_rec+c_eff]X_q
       +[C_epsilon,n+4s]W+(D_top+C_hit+s)W_ex.
Only c_eff X_q+s W_ex are new relative to R352. The old R350/351 beta, the restricted R352 recapture alpha, source peeling, source clipping, and older clock fees each occur once. All source fees receive the entrance factor two and exterior Lambda.

With epsilon=119/3072 and Lambda=128/119, the conditional same-certified-X CZ coefficient is 853/2304+2Lambda(gamma_eff+alpha_rec+c_eff)<889/2304. Each of the three latter terms is strictly below its epsilon/16 ceiling on nonempty original traffic. Unallocated headroom exceeds 1415/2304; the documents correctly do not present it as a bound on any remaining integral. The historical CZ placement is explicitly conditional and is not re-certified by this local audit.

The ledger preserves all outstanding general soft/crossing terms, hard-contract-exterior coupled tails, distance/low-pe/extreme-scale/threshold complements, the three chronological source-history atom classes, H and full source/layer/physical-scale/outer-integration/truncation-limit costs. The physical ell terminal atom and rank termination do not replace chronological atoms. Negative overlap credit cannot be reused. Main and README clearly state that neither all B_H nor the arbitrary-input weak-type theorem is proved.

## 5. Code and evidence scope: PASS

Read numeric.py, its exact result and notes. The physical clock probabilities are normalized inverse-power interval differences plus the separate b atom; the inner threshold is inserted in the partition, so open complementary clock intervals and the inclusive near tail conserve exactly. The code covers threshold below/at R_u, at b, and sigma=1.

The actual positive receiver-dx capacity checks are one-dimensional piecewise-radius interval integrations. Their log comparisons use rational atanh-series enclosures; checking against the lower endpoint is a valid stronger comparison. The high-dimensional module instead integrates source tensor volume with source-sign-dependent finite receiver labels, preserving that dependence and the three-way source/clock partition. It is NOT receiver-dx quadrature certification of the native Q column, and does not realize original high-past/core qualifications or root K. Those limits are explicitly stated in the notes and main.

The stored result agrees with 470 Fraction checks =101 initial+134 boundary+226 expanded+9 strict complement checks. The parent reports a fresh complete numeric run PASS 470 and execution of the geometry's 96 clock-tail cases. The standalone geometry_checks.py is byte-identical to the proof's unique embedded Python block. I did not repeat those complete pipelines. I separately executed four exact epsilon/exterior-ledger checks and the 134 preliminary scalar/clock checks; these are auditor algebra evidence and are not added to the parent counts.

Unadopted Astra/Gram exploration is not certified as a paid tool by this audit; the final main records only its explicit lack of payment, and those auxiliary files are outside the adopted archive scope.

## 6. Conclusion

PASS for the two new actual marked payments, their sourcewise/clock derivations, correctly restricted reuse of R352, final ledger and numeric scope. The spatial-crossing fresh complement and the full historical/global task remain unpaid. No further calculations or edits are required for this bounded audit.

## Frozen SHA256 bindings

Current adopted files and necessary inherited interfaces reviewed. Binding previous contracts does not mean the whole historical reduction was re-audited.

```
95a767796d420f9f812c985e920b49d3d2b69c9143e1008fd6424b957c9fbd35  /tmp/r353_main.md
77250864bef33b7df84c46fe0fff6353b91b6a566ec5a436388112ab08624eae  /tmp/r353_ledger.md
3fbb5e459d76a3318a44d9bcdd7e4f4e8c585252590dc036dfee4fb594416b91  /tmp/r353_readme.md
c0a99aa47c05f0425bb89596a82698682fc92b462320146fbf373a7ee4fdba42  /tmp/r353_geometry.md
4dfce3f92ec596af19454c0a6a2f86e71ae7f46e6b6015dd921d56ff381c44f1  /tmp/r353_geometry_checks.py
9058bc520b49382c6b69d3fe79cbfacadc1dec67d5e34b71e674a0050a2e4581  /tmp/r353_numeric.py
a4701fbe83c982dae76ef240d59cf08e42d098724d2248a85a701d6ac981ad6c  /tmp/r353_numeric_result.json
134bc6bd9aba255615939c6a9e4bac4780509939f9a783db73833d950f741ffb  /tmp/r353_numeric.md
df49526c3572f55da8bf87d29f032056560b75b4e4abc503a78c430c364b11a7  /tmp/r353_audit_pre.md
eef2a5ba2e20828387aab0ac8a8d3b58a55196229a44ae63f8870804b5b74b20  /tmp/r350_geometry.md
c8d688467593892e84608eb40774d62d61112284b40c18c261dee54f8effe4a3  /tmp/r351_geometry.md
27421b0a4fcacfbd10f89f0707be35514f3c349af8097c77753a98b0d6d6c48b  /tmp/r351_core.md
b07aa6f09f20a06d09fb2dfc79459dc6e6f74aedd6f3e882e4876c615b16f253  /tmp/r351_ledger.md
3ffe96d2acab960535e236abf7fcf2a0ee0d351d7755d49501a3175dd69cfdcc  /tmp/r352_core.md
dab3b0867d53feb46ee2c4a465f267e6a778059674ba302f3155338c44bc0228  /tmp/r352_ledger.md
393031c46f3227fc144dfe6d678d9a934b04a7cd1378435a81276d2c5bdc6fb7  /tmp/r352_audit.md
```
