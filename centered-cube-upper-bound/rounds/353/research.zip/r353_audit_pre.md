# R353 independent preliminary audit — PASS for the two stated subreceipts

No R353 author proof was read. The necessary original joint law was checked against the frozen R350 geometry contract. The original full-f field, all old source y/receiver u/small endpoint/time r masks, incoming rank witness w, and the R351 core gate on that witness remain fixed. This audit does not certify general closure or a uniformly positive size of either paid subbranch.

## 1. Exact old clock and rank variables

The original late law before adding the witness has density
 g(y)c_u(y) eta_y(u) Omega_y(u,r) 1_oldgates 1_{r>=R_u} dy du ell(dr),
where 0<=g<=f, eta/Omega/old gates are bounded by one, and ell([t,b])=t^{-n}, including its terminal b atom. Its witness kernel Q_y(u,dw) is independent of r, has row mass at most one, preserves the same y, has m_w>K m_u on every surviving edge, and satisfies int nu_y(du)Q_y(u,dw)<=nu_y(dw), nu_y(du)=c_u(y)R_u^{-n}du. Restricting to the old core subset of w is harmless positive contraction. No new w is granted the old prefix qualification.

## 2. Pay the branch r>=c R_w

For 0<c<=1, integrate the original physical clock on [max(R_u,cR_w),b]. Dropping the positive masks is an upper bound. The tail is at most (cR_w)^{-n}; this remains valid when cR_w<a or at the terminal atom. Strict mass growth gives
 R_w^{-n}< (q_w/(K q_u))R_u^{-n} <= (lambda/(K q_u))R_u^{-n}.
Since Q is an r-independent subprobability, Tonelli yields
 G_{r>=cR_w} <= (lambda/K)c^{-n} int_E [R_u^{-n}/q_u]int g c_u du
 <=(lambda/K)c^{-n}|E| <=(lambda/q_-)K^{-1}c^{-n} X_q.
All original restrictions may be restored in this positive paid subterm. No extra A_n or source copy is introduced.

## 3. Pay the remaining branch y in c Q_w

On the complement r<cR_w, restrict further to the original source satisfying y in the centered cube c Q_w of side cR_w. First integrating the original clock gives an input density t_y(u)nu_y(du) with 0<=t<=1. The actual sourcewise column domination of Q, followed by dropping the remaining masks, gives
 G_{r<cR_w, y in cQ_w} <=int g(y) int_{E:y in cQ_w} R_w^{-n}dw dy.
For a fixed y, put w=y+c v. Actual R_{y+cv} may vary arbitrarily, but
 1_{y in cQ_w} R_w^{-n} <= sup_{a<=R<=b} h_R(v).
The receiver Jacobian is c^n and the exact full-scale hard envelope has mass A_n=1+n log(b/a). Hence this branch is <=c^n A_n int g. This is a receiver-center envelope, not a bound on the source density f or its boundary mass. For g=g_ex the fee uses W_ex, not full W.

Choose s=1+sqrt(n), c^n=min(1,s/A_n). Then this source fee is min(A_n,s)W_ex<=sW_ex. The second branch is taken only after the first is removed, so the two fees are not competing estimates of one shared cost.

## 4. Small receiver coefficient and remaining geometry

On any nonzero original high-past entrance, x=sqrt(n)>1/epsilon as in the frozen prior contract. Since A_n/s<=x for x>=1 and c^{-n}=max(1,A_n/s)<=x,
 (lambda/q_-)K^{-1}c^{-n} <=(4/3)x e^{-x} <32/x^3 <32 epsilon^3 <epsilon/16.
The last implication is 512 epsilon^2<1, satisfied by epsilon=119/3072<1/24. Empty original high-past means zero input and zero effective fee. The formula also has a valid c=1 boundary when A_n<=s, including a=b.

The exact remaining old-marked law has r<cR_w and y not in cQ_w. Therefore y is outside the cube of side r centered at the INITIAL rank witness w. This says nothing about a later endpoint of a resampling chain. It does not remove all other old masks, source concentration, or chronological atoms.

## 5. Composition with R352 and earlier receipts

These are new positive restrictions of the existing G_core input; previously deleted R351 receivers are not charged again. To combine them with R352, reconstruct the exact decomposition from G_core, or append these tests to the ORIGINAL initial-w marks of the R352 extension. Apply the R352 recapture theorem to the remaining input with those initial labels retained. Its input is smaller and still dominated by q. It is not legitimate to pair the old r with a later chain endpoint, or replace a prior residual by a smaller quantity merely because the latter is smaller. The old actual-clock prefix payment and source-peeling costs are not added again. No claim is made that all these paid pieces cover a fixed proportion in every input.

## 6. Local computation

Executed one fresh Python Fraction process: 134 exact checks of inclusive clock tails (including b endpoints), c^n scalar budgets, and the actual epsilon inequality. This is independent algebraic evidence, not a continuous original-flow simulation and not part of the parent/author totals.

Status: both proposed subreceipts pass under the frozen R350/R351 original marked-law contract. Final author/main/ledger and numeric scope remain to be read when delivered. General root-order control of the remaining marked traffic is not proved here.
