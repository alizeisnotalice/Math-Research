#!/usr/bin/env python3
"""Physical clock and actual contracted-cube diagnostics; exact Fraction only."""
from fractions import Fraction as F
from collections import Counter
from pathlib import Path
import json
BASE=Path(__file__).resolve().parent;COUNTS=Counter()
def ck(k,v):
 COUNTS[k]+=1
 assert v,k
def log_interval(x,terms=80):
 assert x>0
 z=(x-1)/(x+1)
 if z<0:
  lo,hi=log_interval(1/x,terms);return -hi,-lo
 lower=2*sum((z**(2*j+1)/F(2*j+1) for j in range(terms)),F(0))
 return lower,lower+2*z**(2*terms+1)/(F(2*terms+1)*(1-z*z))
def tail(u,b,t,n):return F(1) if t<=u else (u/t)**n if t<=b else F(0)
def clockcheck(n,u,w,c,K):
 b=F(2);t=c*w
 ck('physical_radius_octave',1<=u<=w<=b and 0<c<=1)
 ck('actual_uniform_source_q_mass_growth',w**n>K*u**n)
 points=sorted(set([u,b]+[x for x in [t,F(5,4),F(3,2),F(7,4)] if u<x<b]))
 bins=[(a,z,(u/a)**n-(u/z)**n) for a,z in zip(points,points[1:])];atom=(u/b)**n
 ck('physical_clock_continuous_plus_terminal_atom',sum(p for a,z,p in bins)+atom==1)
 computed=sum((p for a,z,p in bins if a>=t),F(0))+(atom if b>=t else 0)
 if t<=u:computed=sum(p for a,z,p in bins)+atom
 ck('clock_tail_from_exact_interval_integrals',computed==tail(u,b,t,n))
 ck('clock_near_actual_q1_bound',computed<=1/(K*c**n))
 ck('clock_near_generic_qminus_bound',computed<=F(4,3)/(K*c**n))
 # Below threshold the terminal atom never enters; complement is open at t.
 farclock=sum((p for a,z,p in bins if z<=t),F(0)) if t>u else F(0)
 ck('two_clock_branches_conserve_including_boundary',computed+farclock==1)
 if t==b:ck('tail_at_b_is_true_terminal_atom',computed==atom)
 if t==u:ck('tail_at_initial_radius_is_one',computed==1)
 return dict(n=n,Ru=str(u),Rw=str(w),c=str(c),threshold=str(t),tail=str(computed),terminal_atom=str(atom),generic_bound=str(F(4,3)/(K*c**n)))
def interval_capacity(c,y,field):
 return sum((max(F(0),min(hi,y+c*r/2)-max(lo,y-c*r/2))/r for lo,hi,r in field),F(0))
def real_dx(stage):
 before=sum(COUNTS.values());fields=[[(F(-1),F(-1,4),F(2)),(F(-1,4),F(1,4),F(1)),(F(1,4),F(1),F(2))]]
 if stage!='initial':fields.append([(F(-3,2),F(-1,2),F(2)),(F(-1,2),F(0),F(1)),(F(0),F(3,4),F(3,2)),(F(3,4),F(3,2),F(2))])
 cs=[F(1,2),F(2,3),F(3,4),F(1)];ys=[F(0),F(1,4)] if stage=='initial' else [F(-3,2),F(-1,4),F(0),F(1,3),F(3,2)]
 lo,hi=log_interval(F(2));rows=[]
 for field in fields:
  ck('actual_receiver_intervals_disjoint_positive',all(a<b and 1<=r<=2 for a,b,r in field) and all(field[j][1]<=field[j+1][0] for j in range(len(field)-1)))
  for c in cs:
   for y in ys:
    val=interval_capacity(c,y,field)
    ck('true_receiver_dx_contracted_capacity',val<=c*(1+lo)) # stronger than outward upper target
    rows.append(dict(c=str(c),y=str(y),capacity=str(val),certified_envelope_upper=str(c*(1+hi))))
 return dict(stage=stage,exact_checks=sum(COUNTS.values())-before,rows=rows,scope='Exact positive receiver interval dx integral, piecewise constant physical R in [1,2]. This is n=1 capacity evidence, not a tensor receiver-dx integration.')
def dependent_receiver(stage,n,c):
 before=sum(COUNTS.values());u=F(1);K=F(5,4) if n==1 else F(4);b=F(2)
 # Old source posterior uniform Q1; receiver depends on source first-coordinate sign.
 # All other source coordinates are integrated by tensor volume, not point sampled.
 options=[(F(-1,2),F(0),F(3,2),F(-1,10)),(F(0),F(1,2),F(2),F(1,10))]
 totalnear=F(0);totalcontracted=F(0);totalremainder=F(0)
 for ya,yb,w,centre in options:
  sourceprob=yb-ya
  ck('dependent_receiver_captures_entire_old_source',w/2-abs(centre)>=u/2)
  ck('dependent_receiver_true_q_growth',w**n>K*u**n and w/2+abs(centre)<2)
  pclock=tail(u,b,c*w,n);totalnear+=sourceprob*pclock
  firstinside=max(F(0),min(yb,centre+c*w/2)-max(ya,centre-c*w/2))
  otherinside=min(u,c*w)**(n-1);pin=firstinside*otherinside
  ck('old_source_contracted_event_actual_tensor_volume',0<=pin<=sourceprob)
  # Clock distribution depends on selected w only through the threshold; do not replace it by an independent unconditional event.
  totalcontracted+=pin*(1-pclock);totalremainder+=(sourceprob-pin)*(1-pclock)
  # Coordinate endpoints of outside intervals and lower radii certify whole residual geometry.
  for y in [ya,yb,(ya+yb)/2,centre-c*w/2,centre+c*w/2]:
   if not ya<=y<=yb:continue
   for rr in [u,(u+c*w)/2,c*w]:
    if u<=rr<c*w and abs(y-centre)>c*w/2:
     ck('residual_source_outside_actual_clock_cube',abs(y-centre)>rr/2)
 ck('dependent_receiver_all_three_branches_conserve',totalnear+totalcontracted+totalremainder==1)
 ck('dependent_receiver_clock_bound_after_joint_averaging',totalnear<=F(4,3)/(K*c**n))
 return dict(stage=stage,n=n,c=str(c),K=str(K),clock_near=str(totalnear),old_source_contracted_after_clock_far=str(totalcontracted),residual=str(totalremainder),exact_checks=sum(COUNTS.values())-before,scope='Exact source-volume integration with source-dependent finite receiver labels. Not actual receiver dx and not the native Q_y or original highpast path.')
def main():
 clocks=[];dx=[];joint=[];stages=[]
 for stage,ns in [('initial',[1]),('boundary_stress',[4]),('expanded',[16,64])]:
  before=sum(COUNTS.values())
  for n in ns:
   K=F(5,4) if n==1 else F(4)
   for w in [F(3,2),F(2)]:
    for c in [F(1,2),1/w,F(3,4),F(1)]:clocks.append(clockcheck(n,F(1),w,c,K))
   for c in [F(1,2),F(2,3),F(3,4),F(1)]:joint.append(dependent_receiver(stage,n,c))
  dx.append(real_dx(stage));stages.append(dict(stage=stage,exact_checks=sum(COUNTS.values())-before))
 # Algebraic geometric complement: one coordinate witnesses outside cQ; r<cR preserves it.
 for R in [F(1),F(3,2),F(2)]:
  for c in [F(1,2),F(2,3),F(1)]:
   for d in [c*R/2,c*R/2+F(1,100)]:
    for r in [c*R/2,c*R]:
     if r<c*R and d>c*R/2:ck('strict_geometric_complement_algebra',d>r/2)
 out=dict(status='PASS',total_exact_checks=sum(COUNTS.values()),check_counts=dict(COUNTS),stages=stages,clock=clocks,positive_receiver_dx=dx,dependent_source_receiver=joint,scope='Physical clock tail includes true b atom. Exact 1D positive receiver dx capacity is separate from tensor source geometry with finite receiver labels. No original highpast simulation, native Q kernel certificate, universal proof, or dimension-order inference.')
 (BASE/'r353_numeric_result.json').write_text(json.dumps(out,sort_keys=True,indent=2)+'\n');print(json.dumps(dict(status='PASS',total_exact_checks=sum(COUNTS.values()),stages=stages),sort_keys=True))
if __name__=='__main__':main()
