R353 physical-clock / contracted-source diagnostic

Fresh standard-library local Python runs returned PASS 470 exact Fraction assertions: initial 101, boundary stress 134, expanded 226, plus 9 strict geometric-complement checks. All log comparisons use rational outward bounds from the atanh series; no float comparison is a certificate.

Reproduce using:

```
/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 r353_numeric.py
```

The script is self-contained and writes r353_numeric_result.json beside itself. Deliverables are this note, that result, and r353_numeric.py.

Clock. The actual normalized clock on [Ru,b] has continuous density n Ru^n r^(-n-1) and terminal atom (Ru/b)^n at b=2. At every inserted rational menu breakpoint the code integrates continuous intervals exactly by differences of inverse powers. It adds the terminal atom separately, verifies total probability 1, and sums the actual tail at cRw. The resulting tail equals min(1,(Ru/(cRw))^n), with cRw<=b. Cases include cRw<Ru, cRw=Ru, cRw=b, and c=1. In particular, tail at b is the true terminal atom, not zero, and there is no new atom at an interior compressed menu endpoint.

The fixed-cube source checks use f=1 on Q4, actual receiver side R in [1,2], m=R^n, q=lambda=1. Diagnostic K=5/4 in n=1 and K=4 in n=4,16,64 satisfy strict mass growth for the tested Ru=1, Rw=3/2 or 2. Both the sharper q=1 bound 1/(Kc^n) and the generic q_-=3/4 bound 4/(3Kc^n) are checked. These K choices are not claimed to be the original root exp(sqrt(n)).

Actual receiver dx capacity is tested separately in n=1. Two declared piecewise-constant-radius positive receiver interval fields have disjoint interiors. For rational c in {1/2,2/3,3/4,1} and source positions including endpoints and exterior positions, exact interval intersections compute

Xi_c(y)=sum_fields length(E intersect [y-cR/2,y+cR/2])/R.

Every value is bounded by c[1+log 2], with a rational lower log endpoint already sufficient for the comparisons; the output also records an outward upper envelope. This is genuine continuous receiver integration, not point weights. It does not certify a high-dimensional tensor receiver dx capacity by sampling.

Dependent receiver selection is a separate exact source-volume calculation. The old source is uniform Q1. Its first-coordinate sign selects either Rw=3/2 centered at -1/10 or Rw=2 centered at +1/10. Both actual cubes contain all old-source points, lie inside the full source Q4, and retain q=1. Conditional on the selected receiver, the physical clock-near probability uses its own cRw. The contracted old-source fraction is integrated by a first-coordinate interval length times min(1,cRw)^(n-1). The code verifies that clock-near, subsequent contracted-old-source, and residual probabilities sum exactly to 1. Thus source and receiver choice dependence is retained rather than replaced by independent unconditional events. These selected receivers are finite labels, not receiver dx, and this selection is not the native Q_y kernel.

On the residual branch, r<cRw and y is outside cQw. Any coordinate witnessing the latter has distance strictly greater than cRw/2 and hence greater than r/2. The script checks rational endpoint/interior configurations and a separate scalar coordinate witness inequality. The source-volume residual calculation includes all coordinates through the tensor volume; the finite coordinate probes are only additional algebra checks, not a replacement for that exact integral. Null boundary points and the strict r<cRw condition are distinguished from the closed clock-near tail.

Scope: finite clock identities, actual 1D receiver dx integrals, and actual compact-source cube geometry with source-dependent finite receiver labels are separately identified. The test does not implement original highpast qualifications or all historical labels, prove the general geometric bound from examples, estimate a dimension exponent, or declare the residual traffic paid.
