from fractions import Fraction as F
from itertools import product
eps=F(119,3072)
assert 512*eps*eps<1
print('512 eps^2 =',512*eps*eps,
      '; 32eps^3 < eps/16:',32*eps**3<eps/16)
checks=0
for n,Ru,Rw,b,alpha in product(
    [1,2,4,8], [F(1),F(5,4)], [F(3,2),F(2)],
    [F(2),F(5,2)], [F(1,2),F(3,4),F(1)]):
 if not (Ru<=Rw<=b): continue
 t=alpha*Rw
 threshold=max(Ru,t)
 tail=threshold**(-n) if threshold<=b else F(0)
 assert tail<=alpha**(-n)*Rw**(-n)
 if threshold<=b:
  continuous=threshold**(-n)-b**(-n)
  atom=b**(-n)
  assert tail==continuous+atom
 checks+=1
print('PASS',checks,
      'exact clock-tail inequalities and terminal-atom decompositions')
