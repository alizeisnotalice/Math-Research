import sys
sys.path.insert(0,'/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor')
import mpmath as m
from fractions import Fraction as F
from math import comb,isqrt
count=0;maxratio=m.mpf(0)
for prec in (30,50,70):
    m.mp.dps=prec
    for pp in ('0.0001','0.1','1'):
        p=m.mpf(pp); r0=m.mpf(1)
        vals=[-r0,m.mpf(0),r0]; probs=[p/2,1-p,p/2]
        for ww in ('0.1','1','10','100'):
            w=m.mpf(ww)
            ends=sorted(set([v-w/2 for v in vals]+[v+w/2 for v in vals]))
            gain=m.mpf(0)
            for l,r in zip(ends[:-1],ends[1:]):
                x=(l+r)/2
                t=sum(pr for v,pr in zip(vals,probs) if abs(x-v)<w/2)
                if t:gain-=(r-l)/w*t*m.log(t)
            bound=p/w*(1+m.log(2/p))
            assert gain<=bound+m.mpf(10)**(-prec+8)
            maxratio=max(maxratio,gain/bound);count+=1
# Here n is a square, so d and all tail/mean computations are exact rational.
for n in (1,4,64):
    d=F(1,8*isqrt(n))
    for L in (F(1),F(3,2)):
        # Half the latent law has all R_i=1, half all R_i=2.
        # This even allows dependence among R coordinates.
        mean=F(0)
        for R in (F(1),F(2)):
            z=d/(L*R)
            mean+=F(1,2)*sum((F((-1)**(j+1)*comb(n,j))*z**j/(1-F(1,2**j)) for j in range(1,n+1)),F(0))
        A=F(3,4)*n*d/L # actual E1/R_i=3/4
        aa=m.mpf(A.numerator)/A.denominator
        mm=m.mpf(mean.numerator)/mean.denominator
        bound=2*aa if A<=1 else m.log(aa,2)+2
        assert mm<=bound+m.mpf('1e-50');count+=1
print('PASS',count,'max_entropy_shape_ratio',m.nstr(maxratio,12))
