# R283 inverse-radius tilt and exact marking

Completed six actual D cases in three phases: initial0,1,4; stress16,64; expanded256. The final40/60 run evaluated4683 included bins per precision, independent whole-line inverse moments, three exact correlated marking models with9 probability reconstructions, and12 elementary rectangle-guard checks. Maximum scaled difference across124 numerical fields is8.01378632818900e-37, at D0's conditional included-bin marked entropy. These are finite diagnostics with ordinary multiprecision and separately identified Fraction arithmetic, not interval/FULL/source-budget certification.

## Actual inverse moments

The actual phi=h*w E3 formula, its E4 primitive, and mu-density g(r)=-(r/2)phi'(r/2) are copied into the self-contained script from the R281 method. No old numerical result is reused. Positive E3/E4 tail expressions avoid subtraction of an almost unit CDF at large r. Direct quadrature, split at0,.5,1,2,8,32,infinity, independently gives

a=int r^-1 mu(dr)=.556791271449643085261401247675638464472329209677318143346481,

b=int r^-1 |logr| mu(dr)=.339466146145580999029865196548028304366479176273214579695533.

The first equals the independently evaluated phi(0), as expected from integration of-.5phi'(r/2). Infinite quadrature tails are evaluated, not cut off. Precision refinement is not a rigorous quadrature error certificate.

## Rounded inverse bins and the complete tail

For zeta=1+1/(D+1), bins are(zeta^(j-1),zeta^j] and rounded R_j=zeta^j. The included index range runs from floor(log(1e-4)/logzeta)+1 through ceil(log64/logzeta). Let p_j be the exact-CDF-expression mass, m_j=p_j/R_j and a_zeta=sum_all m_j. Each included term is nonnegative. Since r<=R(r)<=zeta r, analytically

phi(0)/zeta <= a_zeta <= phi(0).

The finite included sum is retained together with an explicit positive upper for both omitted inverse tails. In every tested row the entire resulting enclosure lies within the theoretical band, not just its midpoint.

|D|included inverse sum|omitted inverse upper|conditional included marked entropy|complete marked entropy enclosure (approx)|
|---:|---:|---:|---:|---:|
|0|.401250770282|9.73e-10|1.480382477449|[1.48038247165,1.48038255925]|
|1|.457669981175|2.07e-9|1.981313511459|[1.98131349895,1.98131366017]|
|4|.508978582580|2.19e-9|2.764899907734|[2.76489989294,2.76490005104]|
|16|.541177454056|2.37e-9|3.921068062790|[3.92106804297,3.92106821243]|
|64|.552562420699|2.55e-9|5.240774675321|[5.24077464837,5.24077483886]|
|256|.555711518786|2.60e-9|6.609733588890|[6.60973355517,6.60973376097]|

These are ordinary evaluated analytical enclosures, not outward-rounded interval certificates. Their bounds explicitly include omitted infinite bins. The included conditional entropy is a separate quantity and is not mislabeled as complete entropy.

For r<=1/2, -w'(x)=E1(x) and x>=1/4 give g(r)<=.5 E1(1/4)r². Thus the small inverse tail is at most E1(1/4)rlo²/4, and its inverse absolute-log moment at most that number times[-log(rlo)+1/2]. The large inverse tail is at most mu((rhi,infinity))/rhi. Since rhi>=64>e, log(r)/r is decreasing there, so the corresponding log moment is at most log(rhi)mu((rhi,infinity))/rhi. Positive exact tail expressions are used for that mu mass. Rounded inverse weights are bounded by these continuous inverse tails because1/R<=1/r.

Let M be the omitted sum of marked weights, bounded by Mbar, and Lbar its omitted inverse-log moment bound. The same geometric reference q_j=exp(-h|j|)/Z, h=logzeta,Z=(1+exp(-h))/(1-exp(-h)), yields

E_tail=-sum_omitted m_j logm_j
 <=Lbar+(h+logZ)Mbar-Mbar logMbar.

Here Mbar<1/e, so replacing unknown M by Mbar in-MlogM is legitimate. For all included m_j, their sum is below phi(0)<1, hence their entropy terms are positive. If E0=-sum_included m_j logm_j and a_lo<=a_zeta<=a_hi, then

log(a_lo)+E0/a_hi <= H({m_j/a_zeta})
 <=log(a_hi)+(E0+E_tail_upper)/a_lo.

This is the complete entropy enclosure saved in JSON. There is no source-coordinate independence assumption in these tail estimates.

## Exact marking without independent source coordinates

Three finite joint laws have1,2 or4 soft coordinates plus one hard coordinate whose inverse is0. Their only three radius values are1/2,1,2. State probabilities are1/4,1/2,1/4, and the radius vectors are coupled cyclically by the state, so coordinates are not independently sampled. Write a_i=E(1/R_i), V=1+sum_i1/R_i, Z=1+sum_i a_i. Base-label probability1/Z and mark-label probabilities a_i/Z sum exactly to1; the hard mark has probability0. Conditional on mark i, the full joint state is tilted by(1/R_i)/a_i, not replaced by a product law. Every state verifies exactly

p(state)V(state)/Z = p(state)/Z
 +sum_i[a_i/Z]*[p(state)(1/R_i)/a_i].

All9 Fraction reconstructions passed. This is probability algebra for a finite coupled law, not an original physical source/FULL construction.

The12 optional rectangle checks only use an explicit elementary guard, avoiding any invented transfer theorem. For n1,4,64,1024, a1,d=1/(8sqrt n) is rational. Homogeneous R values d/2,d,2d are tested. If minR>=d/a, then product_i(1+d/(aR_i))<=2^n exactly; the below-guard homogeneous examples have3^n>2^n and are explicitly unqualified for this bound. Taking logs would give only the associated aspect-entropy bound. This is not a source payment or a proof that small radii can be discarded.

## Reproduction

Python3.12.14, mpmath1.3.0 plus standard library; no dependency installation:

```sh
PYTHONPATH=/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor \
/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 \
r283_numeric.py --output r283_numeric.json
```

The script is self-contained, and deterministic JSON binds its SHA256 without timestamps/runtime/output path. Saved90-digit strings preserve40/60 working results, not90-digit accuracy. The final complete menu was actually run after adding the exact elementary guards. No old suite, repository file, Git or PDF was touched. No general depth-independent source theorem, dimension order, original FIRST/high/history or FULL qualification is certified.
