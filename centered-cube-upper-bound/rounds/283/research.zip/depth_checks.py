import sys
sys.path.insert(0,'/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor')
import mpmath as mp
from fractions import Fraction as F
mp.mp.dps=55
checks=0
def w(x):
    x=abs(x)
    return mp.mpf(1) if x==0 else mp.exp(-x)-x*mp.e1(x)
def mdensity(r):
    return r/2*(w(abs(r/2-mp.mpf('.5')))-w(r/2+mp.mpf('.5')))
phi0=2*mp.quad(w,[0,mp.mpf('.5')])
inv=mp.quad(lambda r:mdensity(r)/r if r else mp.mpf(0),[0,1,2,4,8,16,mp.inf])
assert abs(phi0-inv)<mp.mpf('1e-45') and 0<inv<1;checks+=1
for aa in [F(1,64),F(1,2),F(1),F(3,2),F(2),F(31),F(32),F(1000)]:
    A=mp.mpf(aa.numerator)/aa.denominator
    if A<1:exact=2*A
    else:
        m=int(mp.floor(mp.log(A,2)))
        exact=m+1+A/(2**m)
    bound=mp.log(max(mp.mpf(1),A),2)+2
    assert exact<=bound+mp.mpf('1e-45');checks+=1
# Exact anisotropic containment probabilities for fixed shape and grid.
for sides in [(F(1),F(1)),(F(1,8),F(2)),(F(1,64),F(1,32))]:
    delta=F(1,16);success=F(1)
    for ell in sides:success*=max(F(0),1-delta/ell)
    assert F(0)<=1-success<=min(F(1),sum(delta/ell for ell in sides));checks+=1
print('PASS',checks,'shape/depth checks; E_inverse_side=',mp.nstr(inv,24))
