import sys
sys.path.insert(0,'/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor')
import mpmath as mp
cases=[(1,'near'),(2,'near'),(512,'near'),(8,'near'),(64,'near'),(8,'tiny')]
answers={}; checks=0
for prec in [45,75]:
    mp.mp.dps=prec
    for n,kind in cases:
        eps=1/(16*mp.sqrt(n)) if kind=='near' else mp.mpf('1e-6')
        p=2*eps
        extra=mp.fsum(mp.binomial(n,k)*p**k*(1-p)**(n-k)
              *(1-mp.mpf(k)/(2*n))*mp.log(1/(1-mp.mpf(k)/(2*n)))
              for k in range(n+1))
        I=eps*mp.log(2*n)+extra
        assert eps*mp.log(2*n)<=I<=eps*(1+mp.log(2*n))+mp.mpf('1e-40')
        assert 0<=extra<=eps+mp.mpf('1e-40')
        if prec==45:answers[(n,kind)]=I
        else:assert abs(I-answers[(n,kind)])<mp.mpf('1e-40');checks+=1
        checks+=2
        if prec==75:print(n,kind,'I=',mp.nstr(I,20),'upper=',mp.nstr(eps*(1+mp.log(2*n)),20))
print('PASS',checks,'fixed-channel checks')
