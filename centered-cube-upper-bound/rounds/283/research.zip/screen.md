# R283 independent statement screen

**PASS for a depth-independent full-soft raw near bound of the proposed form, with the guarded transformation and a fully normalized marked-label entropy argument below. It does not give a root-order bound for the complete score-clock traffic.** No R283 author proof has been read for this screen. Current R281 actual caps, mixture law and already proved entropy tool are the inputs.

## 1. Fixed aspect: transformation and small-side guard

Fix a coarse cube C of full side d=a/(8sqrt(n)), original positive L1 restriction rho_C of mass m_C, and a rounded latent aspect vector r with hard coordinates r_i=1. Write T_r=diag(r_i), det T_r=V. The pushforward source rho'=T_r^(-1)#rho_C has the same mass, remains L1, and is supported in an axis rectangle with widths d/r_i. The physical convolution satisfies

H_(r,L)*rho_C(x)=V^(-1)(h_L*rho')(T_r^(-1)x).

Thus its weak constant has no determinant loss: receiver volume contributes V while the threshold becomes Vt. Let r_min=min_i r_i, J(r)=1+sum_{soft i}1/r_i, kappa0=2+sqrt(n)/8.

If d/r_min<=a, enclose the transformed support in a cube of full side d/r_min and apply the established R251 single-cluster theorem. Its weak constant is <=[2+nlog(1+d/(a r_min))]m_C <=[2+(sqrt(n)/8)/r_min]m_C <=kappa0 J(r)m_C. Here 1/r_min<=J(r), including hard coordinates and the case of all soft sides larger than one.

If d/r_min>a, do NOT apply a version of the historical theorem whose hypotheses require a support side <=a. Instead the all-L strong envelope of a fixed normalized aspect rectangle has L1 mass A=1+nlog(b/a), by a diagonal change of variables from the cube envelope. Positive convolution gives weak constant at most A m_C for the actual source. The offending small side must be soft, so J(r)>=1/r_min>8sqrt(n). Consequently kappa0 J(r)>n+16sqrt(n)>=1+nlog2>=A. The same proposed kappa0 J(r)m_C bound follows. This explicitly covers arbitrarily small rounded sides. There is no free replacement of the source by a uniform rectangle.

The profile used in the weak sum can be sup_[a,b] H_(r,L)*rho_C divided by kappa0 J(r)m_C, with zero-mass cases omitted. It has weak constant at most one and is fixed in x. It need not have any component FIRST cap.

## 2. Inverse-radius law: finite normalization and entropy

Let mu_phi be R281's probability law and p_j its upward-zeta rounded-side law, R_j=zeta^j, eta=log zeta, zeta=1+1/(D+1)<=2. As already proved, mu_phi has density <=r/2 near zero and second moment 13. In particular

integral (1/r)mu_phi(dr)=phi(0)<=1,
integral (|log r|/r)mu_phi(dr)<=1/2+13=13.5.

The latter estimate follows by integration on (0,1) using the density bound and on [1,infinity) using (log r)/r<=r^2. These are the needed inverse-weighted moments, not just the ordinary R281 log moment.

For an explicit uniform positive lower normalization, w(x)>=.5 exp(-2|x|) from u in [1/2,1], so phi(0)>=.5(1-exp(-1))>1/4. Let z=sum_j p_j/R_j. Upward rounding gives phi(0)/zeta<=z<=phi(0), hence 1/8<z<=1. The normalized inverse law q_j=p_j/(R_j z) is therefore genuine. The same geometric reference exp(-eta|j|)/(2D+3) and eta|j|<=|log r|+eta give

H(q)<=log(2D+3)+13.5/z+eta
     <=log(2D+3)+109.

This can be proved by finite-partition Gibbs inequalities and increasing entropy limits, without assuming entropy finiteness first. No radius-zero atom exists; the inverse law has no undefined zero normalization. The constants are deliberately loose and finite.

## 3. Marking and all normalizations

Retain the same coefficientwise common-soft nodes and upward-radius domination as R281; they cost the two separate factors e. At fixed node the normalized label law is a product with soft probability tilde_sigma, n tilde_sigma<=D+2. The weighting J(r)=1+sum_soft 1/r_i has total mass

V_node=1+n tilde_sigma z<=D+3.

It is represented exactly as a mixture of: (i) the original product label law of mass 1; (ii) for each coordinate, a mark of mass tilde_sigma z forcing that coordinate soft with inverse law q, leaving all other coordinates in their original product label laws. After dividing by V_node these are probability weights. No unnormalized marked law can be silently treated as a probability law.

Its normalized entropy is at most

H_aug<=log(n+1)+H_*+H_inv,
H_inv=log(2D+3)+109,

where H_* is the already proved R281 product-label entropy bound. Indeed the outer base/mark choice has at most n+1 states, each marked law has at most H_* entropy in the remaining coordinates plus H_inv in its marked coordinate, and the base law has at most H_*. Distinguishing duplicate geometric shapes by their labels only overcounts entropy. The M-node outer choice adds at most log M even when the V_node differ.

Thus one explicit valid full-soft weak factor, chosen >=1, is

B_(n,D)=e^2 M(D+3)[3+2log2+2log M+2log(n+1)+2H_*+2H_inv].

The countable weak-sum theorem then bounds the actual F_C=integral_C p_y rho by a common positive envelope with weak constant <=kappa0 B_(n,D)m_C. The actual FIRST cap F_C/q(x)<=1 is retained independently, on the actual total source response; component weak bounds do not supply FIRST. When D=O(log(n+2)), B_(n,D)=O(log(n+2)^4) with inherited constants. A sharper author constant is permissible if proved, but is not needed to validate the candidate's polylog claim.

## 4. Two caps and exact full raw near price

The actual hard coarse response has cap 4lambda and weak constant <=kappa0 nu(C) by R251. With q_-=3lambda/4, the capped product therefore costs

4lambda I(kappa0 B m_C/q_-,kappa0 nu(C)/(4lambda))
 <=kappa0[(16/3)m_C+(1+log B)nu(C)],

using homogeneity and the earlier I(B A,B0)<=A+(1+log B)B0, valid for B>=1. This switches the B factor into a logarithm; replacing it by a geometric-mean bound would be unnecessarily expensive. No comparison between rho and nu is used.

On the original near pair the coarse same-cell probability remains >=1/2, so the normalized exact allocation of ALL source pairs is bounded by twice the positive same-cell sum. Here there is no latent-containment mask at all: sum_C integral_C p_y rho times integral_C h_R nu contains every pair in that coarse cell. Consequently the proposed FULL raw near bound is valid:

T_near<=2 kappa0[(16/3)W_rho+(1+log B)W_nu].

It has no depth-K entropy and no fine same-cell constraint. The original near pair can be off-diagonal in any finer source partition. This is a source estimate for the raw mother; it is not yet the full score-clock traffic. The original good-slot R2<=D bound gives complete positive price at most 4Lambda B_D kappa0 times the displayed bracket. Since B_D<=4sqrt(nD) and kappa0=O(sqrt n), this is generally n times polylog, not root order. Actual source/leaf ledger hypotheses and the variable-outer-data qualifiers remain necessary. No posterior, original selector or negative credit is replaced.

## 5. Joint concavity does not create a hard-budget disintegration

I(A,B) is jointly concave and homogeneous of degree one on the positive quadrant, with its continuous zero-boundary convention. For A<=B its Hessian quadratic form is

-(x/sqrt(A)-sqrt(A)y/B)^2<=0,

and by symmetry on A>=B; gradients match at equality. Hence I(sum A_i,sum B_i)>=sum I(A_i,B_i) for any conserved positive child split, by concavity plus homogeneity and then limits.

This is a correct algebraic superadditivity fact. It does not prove that the actual hard response G_C can be split into child responses with the required conserved B_i while preserving every original off-diagonal source pair. Merely splitting input rho into children still leaves the whole hard G_C in each product. Allocating its source mass arbitrarily among those products can drop or misweight actual interactions. A useful application needs a genuine positive joint/source-pair disintegration, not only the scalar concavity identity. This observation alone is not a new traffic payment or a root improvement.

## Actual bounded tool evidence

I ran ordinary 50-digit mpmath quadratures of the actual mu_phi inverse mass and inverse log moment (splitting at 0,1,2,4,8,16,infinity), plus four scalar superadditivity checks. Output:

inverse_mass 0.556791271449643085
inverse_logmoment 0.339466146145580999
PASS 4 superadditivity checks

These support the finite moment bookkeeping but do not prove the inequalities, are not interval certificates, and are not FULL original inputs. The analytic bounds above establish the proposition.

```python
import mpmath as m
m.mp.dps=50
def w(x):
 x=abs(x)
 return m.mpf(1) if x==0 else m.exp(-x)-x*m.e1(x)
def mu(r):
 return r/2*(w(abs(r/2-m.mpf('.5')))-w(r/2+m.mpf('.5')))
inv=m.quad(lambda r:mu(r)/r,[0,1,2,4,8,16,m.inf])
logmom=m.quad(lambda r:abs(m.log(r))*mu(r)/r,[0,1,2,4,8,16,m.inf])
assert inv>m.mpf('.25') and inv<=1
assert logmom<=m.mpf('13.5')
def I(a,b):
 if a==0 or b==0:return m.mpf(0)
 return min(a,b)*(2+m.log(max(a,b)/min(a,b)))
N=0
for pairs in [[(1,2),(3,1)],[(1,100),(100,1)],[(1,1),(0,3)],[(1,2),(2,4),(4,8)]]:
 assert sum(I(m.mpf(a),m.mpf(b)) for a,b in pairs)<=I(m.mpf(sum(a for a,b in pairs)),m.mpf(sum(b for a,b in pairs)))+m.mpf('1e-45')
 N+=1
print('inverse_mass',m.nstr(inv,18),'inverse_logmoment',m.nstr(logmom,18),'PASS',N,'superadditivity checks')
```

Screen complete. Awaiting the parent's specified frozen author proof for the distinct final audit; no R283 author file has been read here.
