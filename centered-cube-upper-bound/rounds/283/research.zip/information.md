# R283 — a small-information near-source channel and its exact selection costs

The fixed-kernel information estimate below is valid for arbitrary source laws, including singular laws, and for every fixed soft parameter. It is not a weak-maximal estimate. The actual adaptive-selector and source-ledger gaps are explicitly retained in §§5–6.

## 1. Precise channel theorem

Let n>=1, L>0, z in R^n, and 0<=r<L. Let Y have any Borel probability law pi supported on {||y-z||_1<=r}. Let U be independent of Y, uniform on Q_L(0), and set X=Y+U. The independence here constructs the input kernel; it is not an independence assumption on the original source measure.

Write
\[
\epsilon=r/L,\qquad p_i=\frac{\mathbb E|Y_i-z_i|}{L},\qquad t=\sum_i p_i\le\epsilon.
\]
With natural logarithms and the value zero at t=0,
\[
\boxed{\quad
I(Y;X)\le t\left[1+\log\frac{2nr}{Lt}\right]
\le\frac rL\,[1+\log(2n)].\quad}                         \tag{1}
\]
For the original r=d/2=a/(16sqrt(n)), L>=a, this is at most
\[
\frac{1+\log(2n)}{16\sqrt n}.                            \tag{2}
\]
No source density, product-source structure, or bound on the entropy of Y is required.

### Proof

For r=0, Y=z almost surely and the result is immediate. Suppose r>0. X has density f(x)=integral h_L(x-y) pi(dy), bounded by L^{-n} and supported in Q_(L+2r)(z). Its differential entropy and all marginal entropies are finite. The conditional channel entropy is n log L, so
\[
I(Y;X)=h(X)-n\log L\le\sum_i[h(X_i)-\log L].              \tag{3}
\]
The equality follows directly from the relative-entropy definition of mutual information; the source law itself need not have a differential entropy. The inequality is nonnegativity of the relative entropy of f relative to the product of its marginals.

Put J_i=[z_i-L/2,z_i+L/2]. Conditional on Y_i=y_i, the uniform interval of length L leaves J_i in length |y_i-z_i|, since that displacement is at most r<L. Consequently P(X_i outside J_i)=p_i exactly. The inside support has length L. The outside support is contained in two intervals of combined length 2r. The maximum-entropy bound on a set of finite length, obtained by comparing to its uniform density, gives
\[
h(X_i)-\log L\le h_2(p_i)+p_i\log(2r/L).                \tag{4}
\]
The terms with zero probability are interpreted by continuity. Since
\(h_2(p)\le p\log(e/p)\), and entropy of the normalized vector (p_i/t) is at most log n, summing (4) gives the first inequality in (1). The function
\(t[1+\log(2nr/(Lt))]\)
has derivative log(2nr/(Lt))>=log(2n)>0 on 0<t<=r/L. This proves the second inequality. These arguments are independent of coordinate dependence in pi.

## 2. The same estimate holds for every fixed soft kernel

Use the original one-dimensional kernels
\[
h=1_{[-1/2,1/2]},\quad w(x)=\int_0^1e^{-|x|/u}du,\quad
\phi=h*w,\quad f_s=(1-s)h+s\phi.
\]
The measure (1-s)delta_0+s w(x)dx is a probability measure. Therefore, for fixed s in [0,1],
\[
P_{s,L}=h_L*\mathcal N_{s,L},
\]
where N_(s,L) is the law of a vector whose coordinates independently choose zero with probability 1-s and L times a w-distributed variable with probability s. This is an independent noise representation of a product kernel, not a product assumption on Y.

Let Z_s have this noise law, independent of (Y,U), and X_s=Y+U+Z_s. The Markov chain Y -> Y+U -> X_s yields
\[
\boxed{\ I(Y;X_s)\le I(Y;Y+U)\le(r/L)[1+\log(2n)].\ }     \tag{5}
\]
For completeness, the data-processing inequality follows from the chain rule:
I(Y;Y+U,X_s)=I(Y;Y+U), whereas it is also
I(Y;X_s)+I(Y;Y+U|X_s)>=I(Y;X_s).
Thus no tail entropy estimate and no soft-coordinate menu is needed for (5). The result is uniform in fixed s, including s=0 and s=1. It does not permit s to be chosen as a function of the output without a separate selection argument.

## 3. Source labels and receiver-only gates

For either fixed channel let p_y(x) be its density and f(x)=integral p_y(x) pi(dy). At f(x)>0 define the input-source posterior
\[
\pi_x(dy)=p_y(x)\pi(dy)/f(x).
\]
This posterior is not the original auxiliary clock posterior Pi_(j,y,t). It must never replace that posterior.

For any finite or countable measurable source partition J=J(Y), relative entropy contracts under the partition map, giving
\[
\int f(x)\,\mathrm{KL}(\operatorname{law}(J|x)\|\operatorname{law}(J))dx
=I(J;X)\le I(Y;X)\le\frac rL[1+\log(2n)].                \tag{6}
\]
The formula controls posterior-to-prior information, not the prior partition entropy H(J), which can be arbitrarily large or infinite.

If a(x) in [0,1] is a receiver-only gate, introduce a Bernoulli acceptance A with probability a(X), using randomness independent conditional on X. Put p=P(A=1). Then
\[
\int a(x)f(x)\mathrm{KL}(\pi_x\|\pi)dx
=p\{I(Y;X|A=1)+\mathrm{KL}(\pi^{\rm acc}\|\pi)\}
\le I(Y;X).                                               \tag{7}
\]
Here pi^acc is the actual accepted source law. The equality is the relative-entropy chain rule. The inequality also follows by integrating the nonnegative conditional KL over a(x)<=1. Equivalently,
I(Y;X)=I(Y;A)+p I(Y;X|A=1)+(1-p)I(Y;X|A=0).
Thus conditioning costs 1/p if a normalized conditional information is requested, while its unnormalized information has the budget (7). The change in the source marginal is explicitly present; it is not declared stationary.

There is an exact extension to a gate a(x,y) which depends on the source. Let A be Bernoulli with that conditional probability, and let bar a(x)=integral a(x,y) pi_x(dy). Then
\[
p\{I(Y;X|A=1)+\mathrm{KL}(\pi^{\rm acc}\|\pi)\}
\le I(Y;X)+\mathcal S_a,                                  \tag{8}
\]
\[
\mathcal S_a=I(Y;A|X)
=\int f(x)\left[h_2(\bar a(x))-\int h_2(a(x,y))\pi_x(dy)\right]dx
\le h_2(p)\le\log2.                                      \tag{9}
\]
To prove (8), expand I(Y;X,A) first as I(Y;X)+I(Y;A|X), and then as I(Y;A)+I(Y;X|A). The rejected terms are nonnegative. Formula (9) is the binary conditional-entropy identity followed by concavity of h_2. For p=0 the left side is zero; the p=1 case is interpreted by its actual accepted law. In particular, first-containment or latent-interior weights depending on a source cell label cannot silently use the zero-penalty receiver-only formula (7). They have the concrete selection-information term (9), even though a binary split itself requires no fine-label entropy.

## 4. A quantified finite-selector statement

Take a finite list of fixed parameters (s_j,L_j), j=1,...,N, with L_j>=a and s_j in [0,1], and measurable disjoint receiver bins E_j. Let f_j and pi_(j,x) be the mixture density and posterior for that fixed channel. The exact selected raw measure is
\[
\mathsf M(dy,dx,dj)=1_{E_j}(x)p_{j,y}(x)\pi(dy)dx,
\qquad Z=\|\mathsf M\|.
\]
Then
\[
\boxed{\quad
\sum_j\int_{E_j}f_j(x)\mathrm{KL}(\pi_{j,x}\|\pi)dx
\le\sum_j\frac r{L_j}[1+\log(2n)]
\le\frac{Nr}{a}[1+\log(2n)].\quad}                       \tag{10}
\]
This follows from (7) separately, without assigning new FIRST caps to any j. If Z>0, its left side equals
\[
Z\{I_{\mathsf M/Z}(Y;(X,j))+\mathrm{KL}(\pi_{\mathsf M}\|\pi)\}.
\]
Thus both the selected source tilt and the actual normalization Z are retained. For the original near radius and N=O(n), the information cost in (10) is O(sqrt(n)log(n)). This is a valid information cost, not a bound for the selected response mass Z or original traffic.

An arbitrary continuous selector L(x),s(x) is not a finite list. Nor does upward kernel domination automatically transfer (10): the rejection which changes h_B(x-y) to the actual h_(L(x))(x-y) contains a source-dependent support indicator. It requires (8)--(9), with its actual normalization and coefficients. In general the selected kernel has column
\[
Z(y)=\int P_{s(x),L(x)}(x-y)dx
\]
rather than column one. Even in the hard case, the established positive maximal bound only gives Z(y)<=1+n log(b/a). Normalizing by Z(y) changes the original source to a Z(y)-weighted source. This note does not make that change for free or assert the same hard bound for the full adaptive soft family.

## 5. Precise relation to the original caps and near-source ledger

Fix an original hard source z and let
\[
m_z=\rho(B_1(z,r)),\qquad
\pi_z=\rho|_{B_1(z,r)}/m_z
\]
when m_z>0. This is a diagnostic conditional source law, not a replacement of rho in the traffic. For fixed s,L, the restricted source response equals m_z f_(z,s,L)(x). On receiver bins where these are the actual input parameters, original FIRST bounds this response; no such cap is asserted for arbitrary fixed nodes. The original hard-window multiplier, including a receiver-only E gate, can be tested by
\[
a_z(x)=\frac{q_-a^n}{q(x)}1_E(x)h_{R(x)}(x-z)\in[0,1].
\]
For this fixed input channel, (7) rigorously yields the following bound without using FIRST:
\[
\int \nu(dz)\int_E\frac{m_z h_{R(x)}(x-z)}{q(x)}
 f_{z,s,L}(x)\,\mathrm{KL}(\pi_{z,x}\|\pi_z)dx
\le\frac{r[1+\log(2n)]}{q_-a^{n+1}}
 \iint_{\|y-z\|_1\le r}d\rho(y)d\nu(z).                  \tag{11}
\]
The variable hard selector R(x) is allowed in a_z because its height is at most a^{-n}. The input s,L in (11) remain fixed; for a finite list the sum of r/L_j replaces r/a. Zero m_z fibers contribute zero. The original sources need not be comparable.

Equation (11) exposes the still-unpaid source-pair mass. Its right side is not linear in W_rho+W_nu. FIRST bounds m_z f_z only on receiver bins where its s,L are the actual input parameters; it does not by itself turn the conditional information bound, after integration in z, into a linear source budget. The original hard cap likewise does not bound m_z. Source/history gates depending on y require the selection penalty (9), and signed log likelihoods cannot simply be multiplied by arbitrary masks and then treated as positive terms.

The first-containment weak estimate uses actual positive responses, not merely KL information. To use (6) instead of a prior label-entropy cost, one still needs a proved response/weak-level inequality in which the label fee is posterior-to-prior KL, with the actual joint receiver/source weights and adaptive-selector normalization. No such inequality is proved here. Small channel information alone does not bound a maximal response, a containment-failure probability, or the original clock-normalized traffic. These are the exact missing links; no root payment is claimed from (1), (5), or (10).

## 6. Sharp order and bounded local calculations

The log n in (1) is genuine at the fixed-channel level. Take L=1,z=0 and let Y be uniform on the 2n points +/-epsilon e_i, with 0<epsilon<=1/2. Then ||Y||_1=epsilon. The output leaves Q_1(0) with probability epsilon. On that event the outside coordinate and its sign identify Y uniquely. Hence
\[
I(Y;X)\ge\epsilon\log(2n).
\]
More exactly, for K distributed as Binomial(n,2epsilon),
\[
I(Y;X)=\epsilon\log(2n)
+\mathbb E\left[(1-K/(2n))\log\frac1{1-K/(2n)}\right].    \tag{12}
\]
Inside the base cube each coordinate in an edge interval excludes one source label; K counts excluded labels under uniform Lebesgue measure on that cube. The density is (2n-K)/(2n), which gives (12). Since (1-x)log(1/(1-x))<=x, the second term is at most epsilon. Thus the upper and lower bounds differ by at most epsilon. This is an exact channel example establishing the order of the information lemma, not a counterexample to the original receiver-budget problem. It makes no claim about original FULL histories or receiver caps.

The following small initial/stress/expanded check evaluates (12) at 45 and 75 digits. The theorem is proved analytically above; these are numerical diagnostics, not interval certificates.

```python
import sys
sys.path.insert(0,'/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor')
import mpmath as mp
cases=[(1,'near'),(2,'near'),(512,'near'),(8,'near'),(64,'near'),(8,'tiny')]
answers={}; checks=0
for prec in [45,75]:
    mp.mp.dps=prec
    for n,kind in cases:
        eps=1/(16*mp.sqrt(n)) if kind=='near' else mp.mpf('1e-6')
        p=2*eps
        extra=mp.fsum(mp.binomial(n,k)*p**k*(1-p)**(n-k)
              *(1-mp.mpf(k)/(2*n))*mp.log(1/(1-mp.mpf(k)/(2*n)))
              for k in range(n+1))
        I=eps*mp.log(2*n)+extra
        assert eps*mp.log(2*n)<=I<=eps*(1+mp.log(2*n))+mp.mpf('1e-40')
        assert 0<=extra<=eps+mp.mpf('1e-40')
        if prec==45:answers[(n,kind)]=I
        else:assert abs(I-answers[(n,kind)])<mp.mpf('1e-40');checks+=1
        checks+=2
        if prec==75:print(n,kind,'I=',mp.nstr(I,20),'upper=',mp.nstr(eps*(1+mp.log(2*n)),20))
print('PASS',checks,'fixed-channel checks')
```

The §6 block was actually run at both precisions in this round and returned `PASS 30 fixed-channel checks`. For n=512 at the original near radius it gave I=0.021902639114523366849 and upper=0.021907802728630013605.

## 7. Keeping the latent soft rectangle and its first-containment depth

This extension preserves the latent kernel shape as an observed output, rather than discarding it by data processing.

### 7.1. Shape inverse moment and conditional information

The original phi has the positive centered-interval mixture
\[
\phi(x)=\int_0^\infty r^{-1}1_{\{|x|\le r/2\}}\,\mu_\phi(dr),
\qquad \mu_\phi(dr)=-\frac r2\phi'(r/2)dr.
\]
The measure is a probability: integrate the identity in x. Moreover
\[
\int r^{-1}\mu_\phi(dr)
=-\frac12\int_0^\infty\phi'(r/2)dr=\phi(0)\le1.          \tag{13}
\]
Let the shape vector B=(B_i) have independent coordinates with law (1-s)delta_1+s mu_phi, independent of Y. Conditional on (Y,B), let X be uniform on the rectangle with center Y and coordinate side lengths L B_i. Its marginal channel is exactly the original P_(s,L). All sides are strictly positive almost surely.

To avoid confusing the source radius with a latent side, write r0 for the support radius of Y and mu_i=E|Y_i-z_i|. Conditional on B=b, the coordinate outside probability satisfies
\[
p_i(b)=\mathbb E\min\{|Y_i-z_i|/(Lb_i),1\}
\le\min\{\mu_i/(Lb_i),1\}.
\]
The outside support still has length at most 2r0. The argument of (4) gives
\[
h(X_i|B=b)-\log(Lb_i)
\le p_i(b)[1+\log(2r_0/(Lb_i p_i(b)))].
\]
For mu_i>0, let x_i=mu_i/(Lb_i) and A_i=2r0/(Lb_i). The function u[1+log(A_i/u)] is increasing for 0<u<=x_i because x_i<=A_i/2. Therefore, even when x_i>1,
\[
h(X_i|B=b)-\log(Lb_i)
\le\frac{\mu_i}{Lb_i}\left[1+\log\frac{2r_0}{\mu_i}\right].
\]
If mu_i=0, that coordinate carries no information and contributes zero. Conditional entropy subadditivity and (13), with B independent of Y, now give
\[
\begin{split}
I(Y;X,B)&=\mathbb E_B I(Y;X|B)\\
&\le\sum_i\frac{\mu_i}{L}\,\mathbb E(B_i^{-1})
             [1+\log(2r_0/\mu_i)]\\
&\le\frac{r_0}{L}[1+\log(2n)].
\end{split}                                                    \tag{14}
\]
This retains the shape output, uniformly for fixed s in [0,1]. A finite logarithmic moment of mu_phi follows, for example, from its density bound r/2 near zero and its second moment 13; hence the differential-entropy manipulations can also be justified by finite shape truncation. The mutual-information formulation and the nonnegative bound in (14) pass to the limit directly.

### 7.2. Exact first-depth law

Represent X=Y+L B\odot U with U uniform on the unit cube and independent of (Y,B). Let xi be a random translated coarse grid of side d, independent of the ENTIRE channel construction (Y,B,U), not merely independent of Y. Subdivide every coarse cell dyadically, retaining one nested grid; the side at level k is delta_k=d 2^{-k}. Let C_k(Y) be the unique half-open cell containing Y. Define
\[
J=\min\{k\ge0:\overline{C_k(Y)}\subset
             \prod_i[X_i-LB_i/2,X_i+LB_i/2]\}.
\]
For any fixed Y=y, B=b, and grid xi, the allowed values of X_i for containment have length (Lb_i-delta_k)_+ inside the original conditional interval of length Lb_i. This is independent of y's offset inside the cell: the two excluded lengths add exactly to delta_k. Since the conditional rectangle noise coordinates are independent,
\[
\boxed{\quad
\mathbb P(J>k\mid Y,B,\xi)
=1-\prod_i(1-\delta_k/(LB_i))_+
\le\min\left(1,\frac{\delta_k}{L}\sum_iB_i^{-1}\right).
\quad}                                                         \tag{15}
\]
Nestedness makes J<=k equivalent to containment at level k. Since (15) specifies every tail probability without Y or xi, it proves the stronger conditional independence
\[
J\ \perp\ (Y,\xi)\mid B.
\]
In particular define
\[
\beta_k(B)=\prod_i(1-d2^{-k}/(LB_i))_+,\quad
\beta_{-1}(B)=0,\quad \alpha_k(B)=\beta_k(B)-\beta_{k-1}(B).
\]
The exact first-depth subkernel is the uniform rectangle density multiplied by the event that level k contains the whole cell and no earlier level does. For every fixed y,B,xi its dx integral is alpha_k(B), independent of y and xi. The coefficients are nonnegative and sum to one. Thus, when alpha_k>0, dividing this subkernel by alpha_k gives a genuine fixed-parameter probability channel with the same original input law pi; zero coefficients contribute zero. This is a mass-conserving stopping disintegration, not an assertion about receiver-dependent L(x). One must retain the alpha_k weights rather than sum independently normalized depths for free.

Averaging (15) and using (13),
\[
\mathbb P(J>k)\le\min(1,A2^{-k}),\qquad A=nd/L.            \tag{16}
\]
Thus J is finite almost surely. Summing its tails gives
\[
\mathbb E J\le\log_2\max(1,A)+2=:m_* .                   \tag{17}
\]
For A<1 the tail sum is at most 2A. If A>=1, write A=2^m t with integer m>=0 and 1<=t<2. The sum is m+1+t, which is at most log_2 A+2 because t-1<=log_2 t on [1,2]. This also checks the endpoints of the dyadic split.

A nonnegative integer variable with mean m has entropy at most
\((m+1)\log(m+1)-m\log m\le\log(e(m+1))\),
by relative entropy against the geometric law with mean m. Hence
\[
H(J)\le\log(e(m_*+1)).                                    \tag{18}
\]
Finally xi is independent of (Y,X,B), so the chain rule yields the full fixed-channel stopping-information theorem
\[
\boxed{\quad
I(Y;X,B,\xi,J)
\le\frac{r_0}{L}[1+\log(2n)]+\log\!\left(e\{3+\log_2\max(1,nd/L)\}\right).
\quad}                                                         \tag{19}
\]
For d=a/(8sqrt(n)), L>=a, r0=d/2, the right side is O(log log(n+2)), with the explicit expression (19). The first term is actually O(log(n+2)/sqrt(n)). The law of J conditional on (Y,B,xi), as displayed in (15), depends only on B. The bound does not depend on the density or a fine-partition entropy of the source.

### 7.3. Exactly what this stopping theorem does not settle

The output in (19) contains the depth J, not the complete address of C_J(Y). It does not give a bound on that address's prior entropy. Posterior-to-prior information for any fixed source partition can be controlled as in (6), but replacing a weak-response cost by such information still needs a response inequality.

Original same-coarse-cell conditioning between Y and the hard anchor z is a source/grid-dependent event. It is not silently included in the independence of xi and Y used above; if applied, its accepted source law and the binary selection term from (8)--(9) must be retained. Likewise actual s(x),L(x) do not define the fixed channel of this theorem. The exact formulas establish a small-information first-stopping mechanism; they do not supply a new FIRST cap to latent rectangles, normalize the actual selector column, or pay the original high local source-pair mass in (11).

### 7.4. Small additional checks

The next block checks the inverse-side moment and (17) at bounded finite test points. It checks no actual FULL selector or source-ledger conclusion.

```python
import sys
sys.path.insert(0,'/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor')
import mpmath as mp
from fractions import Fraction as F
mp.mp.dps=55
checks=0
def w(x):
    x=abs(x)
    return mp.mpf(1) if x==0 else mp.exp(-x)-x*mp.e1(x)
def mdensity(r):
    return r/2*(w(abs(r/2-mp.mpf('.5')))-w(r/2+mp.mpf('.5')))
phi0=2*mp.quad(w,[0,mp.mpf('.5')])
inv=mp.quad(lambda r:mdensity(r)/r if r else mp.mpf(0),[0,1,2,4,8,16,mp.inf])
assert abs(phi0-inv)<mp.mpf('1e-45') and 0<inv<1;checks+=1
for aa in [F(1,64),F(1,2),F(1),F(3,2),F(2),F(31),F(32),F(1000)]:
    A=mp.mpf(aa.numerator)/aa.denominator
    if A<1:exact=2*A
    else:
        m=int(mp.floor(mp.log(A,2)))
        exact=m+1+A/(2**m)
    bound=mp.log(max(mp.mpf(1),A),2)+2
    assert exact<=bound+mp.mpf('1e-45');checks+=1
# Exact anisotropic containment probabilities for fixed shape and grid.
for sides in [(F(1),F(1)),(F(1,8),F(2)),(F(1,64),F(1,32))]:
    delta=F(1,16);success=F(1)
    for ell in sides:success*=max(F(0),1-delta/ell)
    assert F(0)<=1-success<=min(F(1),sum(delta/ell for ell in sides));checks+=1
print('PASS',checks,'shape/depth checks; E_inverse_side=',mp.nstr(inv,24))
```

The §7.4 block was actually executed in this round and returned `PASS 12 shape/depth checks; E_inverse_side= 0.556791271449643085261401`. Together with §6 there are 42 actual bounded checks; numerical moment integrations are not interval certificates.
