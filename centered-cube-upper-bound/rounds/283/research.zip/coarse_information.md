# R283 parent extension: original coarse same-cell normalization costs at most log 2 information

Use the frozen fixed-parameter channel and the exact first-depth construction of r283_near_channel.md. Fix the original hard anchor z and a probability pi supported on B_1(z,d/2). Fix s,L and an independent latent shape B with E(1/B_i)<=1. Let g have the uniform coarse shift law dg, independent of Y,B and the uniform rectangle noise. Denote their original joint law by P. Set

\[
 w(y,g)=\frac{\mathbf1_{\{y,z\text{ in the same coarse cell of }g\}}}{P_d(y-z)},\qquad dQ=w(Y,g)dP.
\]
The original near condition gives P_d>=1/2. For every y, integral w(y,g)dg=1, so Q is a probability and its Y marginal is the ORIGINAL pi, with no tilt. Also 0<=w<=2. The B marginal is unchanged and remains independent of (Y,g); the conditional X law given (Y,B,g) is the original uniform rectangle channel. This construction exactly retains the coarse normalization used in A_K, and all fine off-diagonal hard pairs remain allowed.

Since the weight depends only on (Y,g),
\[
 D(Q_{Y,g}\|\pi\otimes dg)
 =\int\log(P_d(y-z)^{-1})\pi(dy)\le\log2.
\]
The entropy chain rule, with finite nonnegative relative entropies, therefore gives
\[
 I_Q(Y;g)+D(Q_g\|dg)\le\log2,\qquad I_Q(Y;g)\le\log2.
\]
For Q_g-almost every g, its conditional Y law remains supported on the SAME near ball. The latent shape is still independent, and the fixed-channel information theorem applies conditionally on g, with the same bound
\[
 I_Q(Y;X,B\mid g)\le C_{\rm near}:=\frac{d}{2L}(1+\log(2n)).
\]
Consequently I_Q(Y;X,B,g)<=log2+C_near. This does not infer that g remains independent of Y; its information cost has been paid explicitly.

The exact conditional first-depth law is also unchanged, because conditioning on (Y,B,g) leaves the channel noise unchanged:
\[
 Q(J>k\mid Y,B,g)=1-\prod_i(1-d2^{-k}/(LB_i))_+.
\]
It depends only on B, so J is independent of (Y,g) conditional on B under Q as well. The unconditional B law is unchanged, hence E_Q J<=m_*=log_2 max(1,nd/L)+2 and H_Q(J)<=log(e(m_*+1)). Thus
\[
 \boxed{I_Q(Y;X,B,g,J)\le\log2+\frac{d}{2L}(1+\log(2n))
 +\log\!\left(e\{3+\log_2\max(1,nd/L)\}\right).}
\]
This is a uniform arbitrary-prior theorem for the fixed normalized near channel with the ORIGINAL coarse 1/P_d factor. Zero-mass conditional fibers can be skipped; all underlying spaces are standard Borel, so regular conditional laws exist. At dyadic cell endpoints use the half-open convention; boundary choices do not alter the uniform receiver-noise probabilities.

This removes the coarse-pair conditioning qualification of the earlier information tool by an explicit constant, rather than an unproved free independence claim. It does NOT normalize the actual receiver-dependent s(x),L(x), pay the real dx-weighted source-pair mass, replace the original auxiliary posterior Pi, or bound the original score-clock traffic. All those remaining issues are unchanged. The theorem's source posterior is only the diagnostic channel posterior.

The proof is analytic, requiring no additional numerical experiment beyond the already replayed exact coarse pairing and shape/depth calculations. It is submitted for an independent audit before any claim of acceptance.
