# R283 independent fixed-channel information audit

## A1. Verdict and independent order

**PASS, finally bound to the repaired author version identified in A5.** No new raw-traffic or root payment is certified by this audit.

The independent proof screen was written and frozen before reading the author file:

- `/tmp/r283_info_screen.md`, SHA256 `8a1e42431dd6df4f60566d2ecda204285873f79840b664036c9221e756d94bbe`.
- Author version first audited: `/tmp/r283_near_channel.md`, SHA256 `4e2479e429e8f1fad4d0afd47793aa7cfa8206590317b6a0a42beb36d696bdfc`.

The parent explicitly supplied that author version after the independent screen. Only the two owned audit/screen files were written. No repository, author file, Git state or PDF was modified.

## A2. Exact claims checked

1. **Coordinate entropy and arbitrary source laws.** The bounded output density and finite support justify the hard-channel entropy calculation even for singular Y. Equations (1)–(4) have the correct constants. The source entropy h(Y) is never used. The soft-channel data-processing step in (5) is valid for fixed s,L.

2. **Retained latent rectangle.** The interval-mixture density `-(r/2) phi'(r/2)` is nonnegative and integrates to one. Its inverse moment is phi(0)<=1. Conditional on each positive finite shape vector, the same coordinate lemma remains valid even if an individual side LB_i is shorter than the source support. This is the potentially delicate case: the outside probability is at most mu_i/(LB_i), and the entropy function is increasing up to that value because mu_i<=r0. Equation (14) follows by nonnegative conditional-information integration; no subtraction of infinite integrated differential entropies is required. The auxiliary density bound near zero and second moment 13 are consistent with the original kernel.

3. **Grid independence.** The author explicitly samples the shifted nested grid independently of the entire (Y,B,U) construction. Independence from Y alone would not suffice. This qualification is essential and is present.

4. **Exact first-depth law and conditional independence.** For fixed (Y,B,xi), a depth-k source cell has side delta_k. The allowed receiver-center interval in coordinate i is contained in the original channel interval and has length `(LB_i-delta_k)_+`, regardless of the source point's offset in its cell. Product uniform noise gives exactly (15), not merely a union bound. Nestedness gives the first-depth interpretation. Therefore `J independent of (Y,xi) given B` is correct. The depth subkernel has source-independent mass alpha_k(B), and retaining those weights preserves the original source prior; independently normalizing and summing all depths would be invalid, and the author does not do so.

5. **Mean and entropy of depth.** The tail constant is A=nd/L, with no factor 2. For A>=1, the exact dyadic phase sum is m+1+A2^-m with m=floor(log2 A); it is at most log2 A+2. For A<1 the upper sum is 2A. Thus (17) has no missing ceiling term. A finite mean gives the geometric maximum-entropy bound, including arbitrary countable laws: finite truncations justify the bound without initially assuming entropy finite. Equation (19) correctly keeps H(J). Independence of J from Y before observing X does not make its conditional information after X vanish.

6. **Receiver-only and source-dependent gates.** Formula (7) retains the accepted source tilt and acceptance probability. For a source-dependent gate, (8)–(9) retain the exact binary conditional-information cost; it is not zero. Such gates do not preserve the original source law automatically.

7. **Finite selector accounting.** The local posterior KL density is nonnegative only after integrating the source. Formula (10) legitimately restricts that density to receiver-only bins and pays N fixed-channel bounds. Its selected raw mass Z and selected source tilt are explicitly retained. It does not give information for an arbitrary continuum selector at N=1, or bound the selected response mass.

8. **Original source integration.** Equation (11) has the right gate and prefactor. The gate is `(q_- a^n/q(x)) 1_E h_{R(x)}(x-z)` and is in [0,1] using only R>=a and q>=q_-. Multiplication by m_z/(q_-a^n), followed by integration in z, gives the displayed source-pair mass. There is no comparison nu<=rho, no new node FIRST, and no assertion that the quadratic source-pair budget is linear. The auxiliary input-source posterior is expressly distinguished from the original clock posterior Pi.

## A3. The only requested wording repair

In the initially audited version, section 5 says that for fixed s,L, FIRST bounds the corresponding conditional response on its actual receiver domain. Read as a claim on the entire original selector-dependent E, that could grant a cap to every fixed node. The parent and auditor agreed to qualify it as follows:

- original FIRST applies on receiver bins where s,L are the actual input parameters;
- no FIRST is asserted for arbitrary fixed diagnostic nodes;
- equation (11) itself uses only the gate-height bound and the fixed-channel information theorem, so no formula or constant needs changing.

No other mathematical correction was requested. The repaired section was subsequently read and passed; A5 binds the final author version.

## A4. Actual independent executions

The author's two embedded Python blocks were independently extracted and run, without edits, using the local mpmath vendor path. The first returned:

```text
1 near I= 0.086643397569993163677 upper= 0.10582169878499658184
2 near I= 0.098744080402387297057 upper= 0.10546030779094341976
512 near I= 0.021902639114523366849 upper= 0.021907802728630013605
8 near I= 0.082428345501547860159 upper= 0.08336322087886380962
64 near I= 0.045658033583702454364 upper= 0.045718986436872009109
8 tiny I= 3.7406660722902534737e-6 upper= 3.7725887222397812377e-6
PASS 30 fixed-channel checks
```

The second returned:

```text
PASS 12 shape/depth checks; E_inverse_side= 0.556791271449643085261401
```

The independent screen's separate exact-mixture/Fraction code also actually ran and returned:

```text
PASS 42 max_entropy_shape_ratio 0.999997707117
```

The author's 30+12 checks are ordinary 45/75-digit channel calculations and a 55-digit moment/depth block. The screen uses ordinary 30/50/70-digit entropy comparisons and exact rational finite-depth means. These are bounded diagnostics, not interval certificates, independent FULL constructions, or evidence of original traffic closure. The analytic proofs establish the universal statements.

The author replay can be reproduced by the following exact extraction, which does not write the author file:

```python
from pathlib import Path
import hashlib
p=Path('/tmp/r283_near_channel.md')
s=p.read_text()
print('AUTHOR_SHA256',hashlib.sha256(s.encode()).hexdigest())
blocks=[chunk.split('\n```')[0] for chunk in s.split('```python\n')[1:]]
assert len(blocks)==2
for i,code in enumerate(blocks,1):
    print('BLOCK',i)
    exec(compile(code,str(p)+' block '+str(i),'exec'),{})
```


## A5. Final binding and freeze

The repaired author section 5 was actually reread. It now grants original FIRST only on receiver bins where s,L are the actual input parameters, disclaims arbitrary fixed-node caps, and explicitly states that equation (11) does not use FIRST. This resolves the only requested wording repair; all formulas and numerical blocks remain unchanged.

**Final audited author:** `/tmp/r283_near_channel.md`, SHA256
`02b670f094ba6f73fb1d30c9415a267838ab457cdf7317ac233b6a39193b1bea`.

The independent fixed-channel, latent-shape, stopping-depth, gate and finite-selector claims pass within their stated normalized-law scope. Original adaptive input selection, response-to-information conversion and the source-pair ledger remain unproved by these statements, as expressly retained in the author note. Audit scope is frozen; no additional numerical or research work is needed for this deliverable.
