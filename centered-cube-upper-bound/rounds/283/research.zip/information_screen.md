# R283 independent screen: fixed normalized near-source channel

**Screen verdict: the information/depth bounds are valid with the qualifications below.** This file was written without reading `/tmp/r283_near_channel.md`. It is a fixed normalized-channel theorem, not a budget for original adaptive raw traffic.

## IS1. Quantifiers and essential independence

Let n>=1, L>=a>0 and s be fixed. Let Y have any Borel probability law supported in the l1 ball B1(z,r0), r0=d/2. Let R=(R_i) have any law on (0,infinity)^n, independent of Y, with E(1/R_i)<=1 for every i. Conditional on (Y,R), generate X=Y+U, where U has independent uniform coordinates on [-LR_i/2,LR_i/2]. The law of R need not have independent coordinates. Let G be the uniform shift of a side-d dyadic cube grid, sampled independently of the entire (Y,R,U).

Independence of G from (Y,R) **alone** is insufficient: G could encode U and let (X,G) recover continuous Y. The theorem uses the stronger stated independence, or equivalently the same uniform conditional channel X|(Y,R,G).

All information and discrete entropy below use natural logarithms; depth bounds use log base 2. Source laws may be singular and have infinite differential entropy. No differential entropy of Y, R or G is used. For an original conditional near prior, fix z and normalize rho restricted to B1(z,r0) when its mass is positive; skip the zero-mass case. This does not normalize the original entire mother measure or establish its required source/receiver budget.

## IS2. One-coordinate entropy lemma, including arbitrarily small side lengths

Let V be supported in [-r0,r0], mu=E|V|, and W uniform on an interval of length ell>0, independently. The output density g of V+W obeys 0<=g<=1/ell and is supported on an interval of length ell+2r0. Thus its differential entropy is finite, between log ell and log(ell+2r0).

Let I0 be the centered noise interval and p=P(V+W outside I0). Translation geometry gives p<=mu/ell. On I0, -t log t<=1-t for t=ell g in [0,1], so

`integral_I0 -g log(ell g) <=p`.

The outside support has length at most 2r0. Jensen gives

`integral_outside -g log(ell g) <=p log(2r0/(ell p))`.

Consequently

`h(V+W)-log ell <=p[1+log(2r0/(ell p))]`

`                         <=(mu/ell)[1+log(2r0/mu)].`        (IS1)

The last function increases for p<=mu/ell<=r0/ell<2r0/ell. These statements remain valid when ell<2r0 or mu/ell>1. Zero mu means V=0 almost surely and gives zero; all zero-mass logarithmic terms are defined by continuity. If r0=0 the whole information statement is zero directly.

For a fixed R, output entropy subadditivity and the conditional product uniform channel yield

`I(Y;X|R) <=sum_i mu_i/(LR_i) [1+log(2r0/mu_i)]`,

where mu_i=E|Y_i-z_i|. This does not assume independence of Y's coordinates. Integrate the nonnegative conditional relative entropy over R; do not subtract unconditional potentially infinite entropies. Since sum mu_i<=r0,

`I(Y;X,R,G) <= (1/L)sum_i mu_i[1+log(2r0/mu_i)]`

`             <= (r0/L)[1+log(2n)] =: C_near.`             (IS2)

For M=sum mu_i>0, the last sum is M[1+log(2r0/M)+H(mu_i/M)]<=M[1+log(2nr0/M)], an increasing function for M<=r0. This proves IS2 for arbitrary Borel priors without infinite-entropy subtraction.

## IS3. Exact first-depth law, improved factor one

At depth K>=0 let C_K(Y) be the half-open grid cell of side delta_K=d 2^-K containing Y. Use the same nested shifted grid at every depth. Let J be the first K for which the closed source cell is contained in the actual receiver rectangle centered at X with sides ell_i=LR_i.

Fix Y,R,G. In coordinate i, if the source cell has endpoints l_i,u_i, the permitted receiver centers are

`[u_i-ell_i/2, l_i+ell_i/2]`.

This is an interval of length (ell_i-delta_K)_+ contained in the channel's original center interval [Y_i-ell_i/2,Y_i+ell_i/2]. Conditional product uniformity therefore gives

`P(J>K|Y,R,G)=1-product_i (1-delta_K/(LR_i))_+`.           (IS3)

The equality uses nested cells, so containment at depth K is equivalent to J<=K. Exact endpoints have zero conditional uniform-noise mass. In particular J is conditionally independent of (Y,G) given R, is finite almost surely, and

`P(J>K)<=min(1,A 2^-K), A=nd/L`.                          (IS4)

This follows from 1-product(1-x_i)_+<=min(1,sum x_i) and E1/R_i<=1. It improves the screened candidate's factor 2.

The precise tail sum satisfies, for A<=1, EJ<=2A; for A>1, m=floor(log2 A) gives

`EJ<=m+1+A 2^-m <=log2 A+2`.                             (IS5)

Writing A=2^(m+theta), the second inequality is 2^theta<=1+theta for theta in [0,1]. Thus the convenient uniform bound is EJ<=max(0,log2 A)+2; no extra ceiling constant is missing.

For a nonnegative integer variable with mean v, the geometric maximum-entropy bound is

`H(J)<=(v+1)log(v+1)-v log v <=1+log(v+1)`.               (IS6)

It applies without initially assuming finite entropy: apply finite Gibbs inequality to min(J,N), using geometric reference masses, then let N increase. The finite mean makes the reference cross entropy finite. At v=0 use H=0.

Finally the conditional-information chain rule gives

`I(Y;X,R,G,J)<=C_near+H(J)`

`             <=C_near+1+log(3+max(0,log2(nd/L))).`        (IS7)

J's independence from Y before observing X does not imply that attaching J after X is information-free. The H(J) allowance in IS7 is retained. With d=a/(8sqrt(n)), the added fee is O(log log(n+2)); C_near is O(log(n+2)/sqrt(n)). These are normalized-channel statements only.

## IS4. What a finite selector fee actually means

For N fixed normalized channels with common prior mu(dy), let p_i(o|y) be their laws, pbar_i(o)=integral p_i(o|y)mu(dy), and let B_i be measurable disjoint bins depending only on the observed output o. Source integration gives the nonnegative local density

`k_i(o)=pbar_i(o) D(mu_i(.|o)||mu)>=0`.

Therefore

`sum_i integral_Bi k_i(o)do <=sum_i I_i <=N C`            (IS8)

if each fixed channel has information bound C. Bins depending on the unobserved Y do not have this justification. One must integrate Y first: the individual signed log-likelihood integrand need not decrease on restriction.

The spliced law has total mass M=sum_i integral_Bi pbar_i, generally not one. If it is normalized and its channel index retained as output, then IS8 says

`M[I_selected(Y;O,index)+D(mu_selected||mu)]<=N C`.

In particular its mutual information is at most NC/M, not automatically NC; its source marginal can be biased by the selection. This is the exact finite-bin accounting. It does not authorize N=1 for an adaptive continuum of physical parameters or identify this normalized information with the original raw dx traffic, posterior Pi, or source cost.

## IS5. Bounded actual local computation

The following tests the one-coordinate entropy lemma for exact finite source mixtures and the first-depth tail-sum formula for a two-point latent rectangle law. It does not simulate original sources or certify raw traffic.

```python
import sys
sys.path.insert(0,'/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor')
import mpmath as m
from fractions import Fraction as F
from math import comb,isqrt
count=0;maxratio=m.mpf(0)
for prec in (30,50,70):
    m.mp.dps=prec
    for pp in ('0.0001','0.1','1'):
        p=m.mpf(pp); r0=m.mpf(1)
        vals=[-r0,m.mpf(0),r0]; probs=[p/2,1-p,p/2]
        for ww in ('0.1','1','10','100'):
            w=m.mpf(ww)
            ends=sorted(set([v-w/2 for v in vals]+[v+w/2 for v in vals]))
            gain=m.mpf(0)
            for l,r in zip(ends[:-1],ends[1:]):
                x=(l+r)/2
                t=sum(pr for v,pr in zip(vals,probs) if abs(x-v)<w/2)
                if t:gain-=(r-l)/w*t*m.log(t)
            bound=p/w*(1+m.log(2/p))
            assert gain<=bound+m.mpf(10)**(-prec+8)
            maxratio=max(maxratio,gain/bound);count+=1
# Here n is a square, so d and all tail/mean computations are exact rational.
for n in (1,4,64):
    d=F(1,8*isqrt(n))
    for L in (F(1),F(3,2)):
        # Half the latent law has all R_i=1, half all R_i=2.
        # This even allows dependence among R coordinates.
        mean=F(0)
        for R in (F(1),F(2)):
            z=d/(L*R)
            mean+=F(1,2)*sum((F((-1)**(j+1)*comb(n,j))*z**j/(1-F(1,2**j)) for j in range(1,n+1)),F(0))
        A=F(3,4)*n*d/L # actual E1/R_i=3/4
        aa=m.mpf(A.numerator)/A.denominator
        mm=m.mpf(mean.numerator)/mean.denominator
        bound=2*aa if A<=1 else m.log(aa,2)+2
        assert mm<=bound+m.mpf('1e-50');count+=1
print('PASS',count,'max_entropy_shape_ratio',m.nstr(maxratio,12))
```

Actual local execution returned `PASS 42 max_entropy_shape_ratio 0.999997707117`. The mean/tail inputs are exact Fraction computations; logarithmic entropy comparisons are ordinary 30/50/70-digit numerical diagnostics, not outward interval certificates. The analytic argument above establishes the universal claims.
