#!/usr/bin/env python3
"""R283 actual inverse-radius tilt, finite bins with explicit omitted tails."""
import argparse,hashlib,json,math
from fractions import Fraction as F
from pathlib import Path
import mpmath as m

def enc(x):return m.nstr(x,90)
def phi(x):
 x=abs(x);return 1-m.expint(3,m.mpf('.5')-x)-m.expint(3,m.mpf('.5')+x) if x<=m.mpf('.5') else m.expint(3,x-m.mpf('.5'))-m.expint(3,x+m.mpf('.5'))
def prim(x):return x-m.expint(4,m.mpf('.5')-x)+m.expint(4,m.mpf('.5')+x) if x<=m.mpf('.5') else m.mpf('.5')-m.expint(4,x-m.mpf('.5'))+m.expint(4,x+m.mpf('.5'))
def w(x):
 x=abs(x);return m.mpf(1) if x==0 else m.exp(-x)-x*m.expint(1,x)
def g(r):return r/2*(w(r/2-m.mpf('.5'))-w(r/2+m.mpf('.5')))
def cdf(r):return 2*prim(r/2)-r*phi(r/2)
def tail(r):return 2*(m.expint(4,r/2-m.mpf('.5'))-m.expint(4,r/2+m.mpf('.5')))+r*phi(r/2)
MENU=[('initial',0),('initial',1),('initial',4),('stress',16),('stress',64),('expanded',256)]
def run(dps):
 with m.workdps(dps):
  phi0=phi(0);inv=m.quad(lambda r:g(r)/r,[0,m.mpf('.5'),1,2,8,32,m.inf]);invlog=m.quad(lambda r:g(r)/r*abs(m.log(r)),[0,m.mpf('.5'),1,2,8,32,m.inf]);tol=m.mpf(10)**(-dps+12);assert abs(inv-phi0)<tol
  rows=[]
  for stage,D in MENU:
   zeta=1+1/m.mpf(D+1);h=m.log(zeta);jlo=int(m.floor(m.log(m.mpf('1e-4'))/h));jhi=int(m.ceil(m.log(64)/h));rlo=m.exp(jlo*h);rhi=m.exp(jhi*h);prev=cdf(rlo);suma=m.mpf(0);E=m.mpf(0);minm=m.inf
   for j in range(jlo+1,jhi+1):
    R=m.exp(j*h);cur=cdf(R) if R<1 else 1-tail(R);p=cur-prev;marked=p/R;assert marked>=-tol
    if marked>0:E-=marked*m.log(marked)
    suma+=marked;minm=min(minm,marked);prev=cur
   # For r<=.5: g(r)<=.5 E1(.25) r², from -w'=E1 and the mean-value bound.
   smallinv=m.expint(1,m.mpf('.25'))*rlo*rlo/4;largeinv=tail(rhi)/rhi;tailinv=smallinv+largeinv
   logtail=smallinv*(-m.log(rlo)+m.mpf('.5'))+m.log(rhi)/rhi*tail(rhi)
   Z=(1+m.exp(-h))/(1-m.exp(-h));Etail=logtail+(h+m.log(Z))*tailinv-tailinv*m.log(tailinv)
   alo=suma;ahi=suma+tailinv
   assert alo>=phi0/zeta-tol and ahi<=phi0+tol and tailinv<m.exp(-1)
   Hconditional=m.log(suma)+E/suma
   Hlower=m.log(alo)+E/ahi;Hupper=m.log(ahi)+(E+Etail)/alo
   assert Hlower<=Hupper
   row={'phase':stage,'D':D,'included_bins':jhi-jlo,'first_j':jlo+1,'last_j':jhi}
   for key,value in [('zeta',zeta),('r_low',rlo),('r_high',rhi),('a_zeta_included',suma),('a_zeta_tail_upper',tailinv),('a_zeta_lower',alo),('a_zeta_upper',ahi),('theoretical_phi0_over_zeta',phi0/zeta),('theoretical_phi0',phi0),('lower_band_margin',alo-phi0/zeta),('upper_band_margin',phi0-ahi),('small_inverse_tail_upper',smallinv),('large_inverse_tail_upper',largeinv),('inverse_abslog_tail_upper',logtail),('unnormalized_mark_entropy_included',E),('unnormalized_mark_entropy_tail_upper',Etail),('conditional_included_mark_entropy',Hconditional),('full_mark_entropy_lower',Hlower),('full_mark_entropy_upper',Hupper),('minimum_marked_bin_mass',minm)]:row[key]=enc(value)
   rows.append(row);print('completed',dps,D,flush=True)
  return {'phi0':enc(phi0),'inverse_moment_quad':enc(inv),'inverse_absolute_log_moment_quad':enc(invlog),'inverse_moment_difference':enc(abs(inv-phi0)),'bins':rows}
def exact_marking():
 p=[F(1,4),F(1,2),F(1,4)];radii=[F(1,2),F(1),F(2)];models=[];checks=0
 for soft in [1,2,4]:
  # Three completely coupled radius vectors, plus one hard coordinate with inverse0.
  R=[[radii[(state+i)%3] for i in range(soft)]+[None] for state in range(3)]
  iv=[[F(0) if r is None else 1/r for r in row] for row in R]
  a=[sum((p[t]*iv[t][i] for t in range(3)),F(0)) for i in range(soft+1)];normal=1+sum(a);base=1/normal;markprob=[x/normal for x in a];assert base+sum(markprob)==1 and markprob[-1]==0
  rows=[]
  for t in range(3):
   V=1+sum(iv[t]);target=p[t]*V/normal
   mixture=base*p[t]+sum((markprob[i]*(p[t]*iv[t][i]/a[i]) for i in range(soft) if a[i]>0),F(0))
   assert target==mixture;checks+=1
   rows.append({'state':t,'joint_probability_exact':str(p[t]),'radii_exact':['hard_inverse0' if r is None else str(r) for r in R[t]],'V_exact':str(V),'reweighted_joint_probability_exact':str(target),'base_plus_mark_probability_exact':str(mixture)})
  models.append({'soft_coordinates':soft,'hard_coordinates':1,'expected_inverse_by_coordinate_exact':[str(x) for x in a],'expected_V_exact':str(normal),'base_label_probability_exact':str(base),'mark_label_probabilities_exact':[str(x) for x in markprob],'cases':rows})
 return {'models':models,'reconstruction_checks':checks,'scope':'General finite joint law: mark conditional law is joint p(state)*inverse_i/E inverse_i; no independent source-coordinate hypothesis. Hard coordinate has inverse0 and is never selected.'}
def exact_rectangle_guards():
 rows=[]
 for n in [1,4,64,1024]:
  sq=math.isqrt(n);assert sq*sq==n;d=F(1,8*sq)
  for factor in [F(1,2),F(1),F(2)]:
   radius=factor*d;guard=radius>=d;product=(1+d/radius)**n
   if guard:assert product<=2**n
   else:assert product>2**n
   rows.append({'n':n,'a_exact':'1','d_exact':str(d),'homogeneous_radius_exact':str(radius),'min_radius_at_least_d_over_a':guard,'aspect_entropy_product_exact':str(product),'product_bound_2_to_n_exact':str(2**n),'scope':'Only elementary guard product<=2^n when all radii>=d/a; below-guard examples do not qualify for that bound. No physical/source or full entropy theorem.'})
 return rows

def main():
 p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=Path(__file__).with_suffix('.json'));a=p.parse_args();low=run(40);high=run(60);exact=exact_marking();guards=exact_rectangle_guards()
 with m.workdps(110):
  diff={}
  for key in ['phi0','inverse_moment_quad','inverse_absolute_log_moment_quad','inverse_moment_difference']:diff[key]=abs(m.mpf(low[key])-m.mpf(high[key]))/max(1,abs(m.mpf(high[key])))
  for i,(x,y) in enumerate(zip(low['bins'],high['bins'])):
   for key,value in x.items():
    if not isinstance(value,str) or key=='phase':continue
    diff[str(i)+'/'+key]=abs(m.mpf(value)-m.mpf(y[key]))/max(1,abs(m.mpf(y[key])))
  worst=max(diff,key=diff.get);maximum=enc(diff[worst]);assert diff[worst]<m.mpf('1e-27')
 out={'schema':'R283-actual-inverse-radius-tilt-v1','script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'counts':{'D_geometries':6,'stages':{'initial':3,'stress':2,'expanded':1},'included_bins_per_precision':sum(r['included_bins'] for r in high['bins']),'exact_correlated_mark_models':3,'exact_probability_reconstructions':exact['reconstruction_checks'],'exact_rectangle_guard_checks':len(guards),'precision_fields':len(diff)},'mp40':low,'mp60':high,'exact_marking':exact,'exact_rectangle_guards':guards,'precision_max_scaled_difference':maximum,'precision_worst_field':worst,'scope':['Actual E3/E4 phi and interval-mixture density copied from R281; old menu results not reused. Independent infinite-line inverse-moment and inverse-abslog quadrature, ordinary40/60 not interval.','Rounded R=zeta^ceil(log_zeta r); finite included inverse sums plus explicit omitted inverse bounds enclose full a_zeta within phi0/zeta..phi0 in tested cases.','Conditional included-bin entropy is not called full entropy. Full marked entropy bounds use the positive omitted inverse/logmoment bounds and a normalized geometric reference; evaluation is ordinary mp.','Exact correlated3-state marking reconstruction is finite algebra, not a physical FULL source model. No dimension-order, source-budget or final theorem certificate.','Rectangle checks use only the explicit elementary product guard: min radius>=d/a implies product(1+d/(a radius))<=2^n; below-guard cases do not qualify. No wider rectangle-transform/source theorem asserted.']}
 a.output.write_text(json.dumps(out,sort_keys=True,indent=2)+'\n');print(json.dumps({'counts':out['counts'],'maxdiff':maximum,'worst':worst}))
if __name__=='__main__':main()
