import sys
import math
import random

sys.path.insert(0, '/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor')
import mpmath as mp

mp.mp.dps = 40

# Actual mixture inverse moments.
def w(x):
    x = abs(x)
    return mp.mpf(1) if x == 0 else mp.exp(-x) - x * mp.e1(x)


def dens(r):
    return r / 2 * (w(abs(r / 2 - mp.mpf('.5'))) - w(r / 2 + mp.mpf('.5')))


phi0 = 2 * mp.quad(w, [0, mp.mpf('.5')])
inv = mp.quad(lambda r: dens(r) / r, [0, 1, 2, 4, 8, 16, mp.inf])
logmom = mp.quad(lambda r: dens(r) * abs(mp.log(r)) / r, [0, 1, 2, 4, 8, 16, mp.inf])
assert abs(inv - phi0) < mp.mpf('1e-30')
assert 1 / (2 * mp.e) <= phi0 <= 1
assert logmom <= mp.mpf('13.5')

count = 0
for n in [1, 4, 64, 1024]:
    d = 1 / (8 * math.sqrt(n))
    kap = 2 + n * d
    A = 1 + n * math.log(2)
    for rmin in [1e-4, .01, .1, 1., 10.]:
        ell = d / rmin
        kr = min(A, 2 + n * math.log1p(ell)) if ell <= 1 else A
        U = 1 + 1 / rmin
        assert kr <= kap * U + 1e-12
        count += 1

rng = random.Random(283)


def I(a, b):
    return min(a, b) * (2 + math.log(max(a, b) / min(a, b))) if min(a, b) > 0 else 0.


for _ in range(200):
    aa = [10**rng.uniform(-4, 4) for j in range(5)]
    bb = [10**rng.uniform(-4, 4) for j in range(5)]
    left = I(sum(aa), sum(bb))
    right = sum(I(a, b) for a, b in zip(aa, bb))
    assert right <= left + 1e-10 * max(1, left)
    count += 1
    B = 10**rng.uniform(0, 5)
    a = sum(aa)
    b = sum(bb)
    assert I(B * a, b) <= a + (1 + math.log(B)) * b + 1e-10 * max(1, a, b)
    count += 1

print({
    'checks': count + 3,
    'phi_zero': mp.nstr(phi0, 20),
    'inverse_log_moment': mp.nstr(logmom, 20),
    'inverse_moment_residual': mp.nstr(abs(inv - phi0), 5),
    'status': 'PASS',
})
