import mpmath as m
m.mp.dps=50
def w(x):
 x=abs(x)
 return m.mpf(1) if x==0 else m.exp(-x)-x*m.e1(x)
def mu(r):
 return r/2*(w(abs(r/2-m.mpf('.5')))-w(r/2+m.mpf('.5')))
inv=m.quad(lambda r:mu(r)/r,[0,1,2,4,8,16,m.inf])
logmom=m.quad(lambda r:abs(m.log(r))*mu(r)/r,[0,1,2,4,8,16,m.inf])
assert inv>m.mpf('.25') and inv<=1
assert logmom<=m.mpf('13.5')
def I(a,b):
 if a==0 or b==0:return m.mpf(0)
 return min(a,b)*(2+m.log(max(a,b)/min(a,b)))
N=0
for pairs in [[(1,2),(3,1)],[(1,100),(100,1)],[(1,1),(0,3)],[(1,2),(2,4),(4,8)]]:
 assert sum(I(m.mpf(a),m.mpf(b)) for a,b in pairs)<=I(m.mpf(sum(a for a,b in pairs)),m.mpf(sum(b for a,b in pairs)))+m.mpf('1e-45')
 N+=1
print('inverse_mass',m.nstr(inv,18),'inverse_logmoment',m.nstr(logmom,18),'PASS',N,'superadditivity checks')
