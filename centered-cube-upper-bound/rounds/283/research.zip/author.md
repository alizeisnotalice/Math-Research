# R283 — an actual tree capacity disintegration and a depth-independent full-soft cluster payment

## Proposition: what is proved

Retain R281/R282's original sources, actual FIRST and hard cap, actual measurable s,L,R, a<=L,R<=b<=2a, ns<=D, d=a/(8sqrt(n)), and original near traffic. All full original posterior laws are unchanged. Let M, H_* be the explicit R281 S2 constants and put

    kappa0 = 2+n d/a = 2+sqrt(n)/8,
    E_* = H_*+log(n+1)+log(2D+3)+60e,
    B_* = e^2 M(D+3)[3+2log 2+2log M+2E_*].                    (P0)

B_*>=1. For every original coarse grid cell C and its unrestricted full soft response F_C, there is an x-independent positive weak envelope with

    ||F_C||_{1,infinity} <= kappa0 B_* rho(C).                  (P1)

The actual full near mother, hence the entire sum of first-contained increments on (Ab-Asc), satisfies

    T_near <= 2 kappa0[(16/3)W_rho+(1+log B_*)W_nu].           (P2)

This is a depth-independent, genuinely source-paid bound; it has no H_K, no source-density tail parameter, no unpriced adjacency term, and covers full soft off-core contributions. For D=O(log(n+2)), B_*=O((log(n+2))^4), so P2 is O(sqrt(n)[1+loglog(n+2)]) times source masses, with constants inherited through D. It is an improvement over the finite-depth nK entropy estimate. It is NOT the desired raw polylog bound; multiplication by the old 4sqrt(nD) row estimate gives order n times polylog, not the sought root order.

A separate actual disintegration of hard-source mass along the first-contained tree is constructed below. Its global hard marginal is bounded by A nu|C, A=1+n log(b/a). This yields a genuine local linear capacity potential with price A and no depth loss. The concave capped-product potential I is also checked exactly, but no missing polylog local potential inequality is claimed.

## The first-contained tree and a real hard-source disintegration

Fix an original shifted d-cell C. For every descendant P other than C let P^- be its parent, and define the original first-contained response

    f_P(x)=integral_P rho(dy) integral
                (J_{P,r}(x)-J_{P^-,r}(x)) H_{r,L(x)}(x-y) pi_{s(x)}(dr).

Let f_C be the full-cell latent response at the root. Because full containment is nested, all f_P>=0. The R282 limit and L1 source assumption give

    sum_{P in tree(C)} f_P(x)=F_C(x)=integral_C p_y(x)rho(dy)

for dx-almost every actual receiver, and F_C/q<=1. This identity is before any artificial component cap.

Define finite positive measures on the ORIGINAL hard source by

    Gamma_P(dz)=1_C(z)nu(dz) integral_E
                         h_{R(x)}(x-z) f_P(x)/q(x) dx.          (1)

The integrated original receiver cost of this node is exactly ||Gamma_P||. Tonelli and actual FIRST imply the pointwise hard marginal bound

    sum_P Gamma_P(dz)
       <=1_C(z)nu(dz) integral_E h_{R(x)}(x-z)dx
       <= A 1_C(z)nu(dz),      A=1+n log(b/a).                 (2)

The last bound is the exact L1 mass of the common-window hard kernel envelope, not a newly granted FIRST. Thus nu_P=Gamma_P/A is an ACTUAL substochastic split of the original hard source: sum_P nu_P<=nu|C. It was constructed from the real dx-integrated response, not postulated from desired masses.

For a subtree rooted at P set b_P=sum_{Q descendant-or-equal P}||nu_Q||. Then

    b_P=||nu_P||+sum_{D child of P}b_D,
    actual stop cost at P = A||nu_P||.

The linear potential Phi_P=A b_P therefore pays the local stop cost plus child potentials with equality, and b_C<=nu(C). It gives the honest bound sum stop costs<=A nu(C) at every depth and in the monotone limit. This is a proved capacity mechanism, but A is of order n, not polylog. The additional source geometry in P1-P2 improves its GLOBAL price; it does not automatically strengthen the pointwise marginal (2).

If all original auxiliary posterior variables and clock are retained in (1), the same construction remains an exact positive disintegration, but the integrand contains its actual score factor depending on y. Replacing that factor by a scalar row bound is an additional step, not part of (2). No unproved clock/source marginal is asserted.

## The natural two-mass Bellman candidate and its exact scope

Let

    I(A,B)=min(A,B)[2+log(max(A,B)/min(A,B))], I(A,0)=I(0,B)=0.

This candidate is jointly concave and positively homogeneous. On A<=B,

    d^2 I = -(dA-(A/B)dB)^2/A,

and the symmetric formula holds on B<=A. The first derivatives agree at A=B. Hence for any genuine mass-conserving child split,

    sum_i I(A_i,B_i)<=I(sum_i A_i,sum_i B_i).                 (3)

It is therefore a valid terminal aggregation potential once both marginals are actually conserved. Proportional splitting B_i/B=A_i/A gives equality. It cannot by itself pay an additional positive stop cost in the same split: a local theorem would need a stopping/capacity state, not only the two original masses. The actual b_P above is one such state, with the proved price A. The spatial source masses rho(P) also cannot be silently assigned to stopping nodes: the stopping node depends on the actual receiver and latent rectangle.

This identifies precisely what is and is not supplied by (3), without replacing the actual first-contained partition by a fixed source label.

## Full-soft fixed-shape cluster envelope

The following estimates remove the nK label cost before invoking any stopping selection.

R281's common-soft discretization provides M fixed tilted probability laws pi_k^disc on labelled rounded shape vectors R. It gives, for every actual s,L,

    P_{s,L} <= e^2 sum_{k=1}^M integral H_{R,L} pi_k^disc(dR).

Under each law the soft-label probability t_k satisfies nt_k<=D+2; soft sides R_j=zeta^j, zeta=1+1/(D+1), have masses p_j. Hard labels have side 1. For a fixed shape define

    U_R = 1+sum_{i labelled soft} R_i^(-1).

For sigma=rho|C, consider K_R sigma=sup_{a<=L<=b}(H_{R,L}*sigma). Under the diagonal coordinate change x_i -> x_i/R_i, this is the ordinary cube-scale maximal operator applied to the pushforward source. Its support fits a cube of side ell=d/min_i R_i. The determinant factors cancel in its weak L1 constant.

If ell<=a, the audited R251 cluster bound gives

    ||K_R sigma||_{1,infinity} <= [2+n log(1+ell/a)]||sigma||.

If ell>a, use instead the universal strong-L1 scale envelope of mass A=1+n log(b/a). Combining the two cases and using (min_i R_i)^(-1)=max_i R_i^(-1)<=U_R gives, in ALL cases,

    ||K_R sigma||_{1,infinity} <= kappa0 U_R ||sigma||.          (4)

For ell<=a this follows from log(1+ell/a)<=ell/a and U_R>=1. For ell>a, n(d/a)(min_i R_i)^(-1)>n, so kappa0 U_R>=2+n>A, since b/a<=2. No cluster theorem is used outside its allowed support-side hypothesis.

## Paying the random short side by a fixed marked law

The weak-sum entropy lemma needs the entropy of weights pi_k^disc(R)U_R. It is important not to replace U_R by a supremum, since a rounded soft side can be arbitrarily small.

Set

    z1=sum_j p_j/R_j.

The original interval mixture gives integral r^(-1)mu_phi(dr)=phi(0)<=1, and upward rounding gives

    1/(4e)<=z1<=1.                                           (5)

Indeed phi(0)=integral_{-1/2}^{1/2}w(t)dt>=1/(2e): on that interval use u in [1/2,1] in w(t)=integral_0^1 exp(-|t|/u)du. Also R_j<=zeta r<=2r, so z1>=phi(0)/2.

The inverse-side tilted law p_j^inv=p_j/(R_j z1) has controlled entropy. With eta=log zeta, the reference probability proportional to exp(-eta|j|) has normalization 2D+3. The mixture density bound mu_phi'(r)<=r/2 on (0,1), and its second moment 13, give

    integral r^(-1)|log r|mu_phi(dr) <=1/2+13=13.5.

For the large-r part we used (log r)/r<=r^2. Since eta|j|<=|log r|+eta on the rounded bin and eta<=log2, (5) implies

    eta E_pinv |j| <=60e,
    H(p^inv)<=log(2D+3)+60e.                                (6)

All these are kernel-label facts, not independence assumptions on rho or nu.

Now introduce an auxiliary MARK with labels 0,1,...,n. At a shape R, mark 0 has unnormalized weight 1, and mark i has weight 1{coordinate i is soft}/R_i. The total marked mass is U_R. For each soft node its mean is

    Z_k=E U_R=1+nt_k z1<=D+3.

Conditionally on mark 0, the original rounded product label law remains. Conditionally on mark i>0, coordinate i is forced soft with side law p^inv; the other coordinates retain their original independent KERNEL-label law. Therefore the entropy of the normalized marked shape law is at most

    log(n+1)+H_*+H(p^inv) <= E_*.

This is an explicit fixed label construction independent of the actual receiver. Across the M soft nodes, total weak mass is at most e^2 kappa0 rho(C) M(D+3), and normalized entropy is at most log M+E_*.

To apply the weak-sum lemma literally, one may split each function K_R sigma into the nonnegative fractions 1/U_R and [1{soft i}/R_i]/U_R. These fractions sum to one. By (4), each fraction has weak constant bounded by kappa0 rho(C) times its unnormalized mark weight. Thus the enlarged label law does not duplicate the function or its source; it is an exact decomposition with assigned weak constants.

R281 S15 now gives an x-independent envelope of the full actual F_C with weak constant kappa0 B_*rho(C), proving P1. Countably many shape labels follow by monotone truncation and the finite entropy estimate (6).

## Two actual caps and the depth-independent payment

The actual hard response has weak constant at most kappa0 nu(C) by R251, and the actual FIRST/hard caps imply F_C/q<=1 and G_C/(4lambda)<=1. Apply the already-proved two-layer capped product integral, then the amplification inequality:

    integral_E F_C G_C/q dx
      <=4lambda I(kappa0 B_*rho(C)/q_-, kappa0 nu(C)/(4lambda))
      <=kappa0[(16/3)rho(C)+(1+log B_*)nu(C)].                 (7)

The last inequality uses homogeneity and I(B_*A,B)<=A+(1+log B_*)B. Sum coarse cells and average the SAME original coarse shifts. The only random-grid factor is P_d^(-1)<=2 on near, which proves P2. There is no refinement depth, count of children, receiver-dependent stopping law, or duplicated hard source in (7).

All first-contained increments are nonnegative and sum to a suballocation of the full original near mother. Thus (7) pays their complete raw sum, including the specific (Ab-Asc) weight, at this stated sqrt(n) times iterated-log cost. Original terminal source masses are summed once, with their original outer expectation. No new source comparison or spent signed credit occurs.

## Keeping the common physical clock qualification explicit

The proof can retain the known actual scale qualification at physical clock xi:

    a_xi=max(a,b xi/gamma),
    A_xi=1+n log(b/a_xi),
    kappa_xi=min(A_xi, 2+n d/a_xi).

For each fixed shape, both the global scale envelope A_xi and the transformed-source estimate (4) are available. Since U_R>=1,

    min(A_xi,(2+n d/a_xi)U_R)<=kappa_xi U_R.

Therefore P1-P2 at a fixed physical clock hold with kappa0 replaced by kappa_xi. This is a valid joint scale/source qualification rather than a repeated full-window fee. If the actual upper-slot condition R2<=D is then bounded by f_D(xi)=min(n,D/(1-xi)^2), one obtains the concrete original positive-traffic estimate

    P_rem <=4Lambda[(16/3)W_rho+(1+log B_*)W_nu]
                      integral_middle f_D(xi)kappa_xi dxi/xi.  (8)

The original full posterior is used before the pointwise f_D bound, and the actual unique j mask is retained until then. Formula (8) is not asserted to be root order. It still loses the correlation of the exact first-contained face and the original auxiliary upper slot when replacing its score by f_D. No further joint geometric inequality is established here.

Consequently the bounded outcome is: a valid capacity split exists with an explicit order-n hard marginal, and a new full-soft global cluster budget improves the nK refinement entropy to a depth-independent order-sqrt(n) raw source price. The desired general root-polylog positive-traffic payment remains open; this note does not claim the stronger raw-polylog statement was necessary or proved.

## Actual local checks

A local 40-digit mpmath calculation verified the inverse mixture moment identity and bounds used in (5)-(6): phi(0)=0.55679127144964308526 and integral r^(-1)|log r|mu_phi(dr)=0.33946614614558099903; the inverse-moment residual was 0.0 at that precision. Twenty n/shape cases checked the two-branch fixed-shape bound (4). Two hundred random finite positive mass splits checked joint concavity/superadditivity of I, and two hundred checked the amplification inequality used in (7). Output: checks=423, status=PASS. These are numerical diagnostics of the analytic arguments, not interval proofs or FULL original-history simulations.
