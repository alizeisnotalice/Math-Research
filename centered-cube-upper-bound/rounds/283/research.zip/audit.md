# R283 final independent audit

**PASS, with the explicit scope of the Gamma accounting and physical-clock gate recorded below. No necessary mathematical correction. No root-order closure is certified.**

## Bound versions and chronology

- Author `/tmp/r283_bellman.md`: SHA256 `b557ed8a5e62c89da8cf036003f07922cf5f7d9a86b962cc8a1c5a8f1fc7124c`.
- Executable diagnostics `/tmp/r283_bellman_checks.py`: SHA256 `62a24bc753bb591d8fa279b501ccaf80e700159a1487ee006297ea6438e61b56`.
- Independent pre-author screen `/tmp/r283_screen.md`: SHA256 `83052dfacef5b2302b87ffdeeae06645dcb41af3178ffaae145196764288f6a9`.

The screen preceded author reading. Both author and script hashes were checked before their complete read; the script was actually executed afterward. No other author files or repository files were needed or changed.

## 1. Actual Gamma marginals and the tree potential

The first-contained f_P are nonnegative because whole-cell containment is nested. The R282 almost-everywhere limit for an L1 input source gives sum_P f_P=F_C at almost every actual receiver. Actual FIRST gives F_C/q<=1. The measures Gamma_P in (1) are therefore finite positive measures on the original hard source, and Tonelli gives exactly

sum_P Gamma_P(dz)
 =1_C(z)nu(dz) integral_E h_R(x-z)F_C(x)/q(x)dx
 <=A 1_C(z)nu(dz),  A=1+nlog(b/a).

The last step is the actual adaptive-scale hard-kernel envelope, whose full dx column has mass A. It is not an additional FIRST estimate. Thus nu_P=Gamma_P/A is a genuine substochastic hard-source measure split, and the defined subtree masses satisfy the stated recursion. Phi_P=A b_P pays its stop cost plus its child potentials with equality; all depths and limits are legitimate by nonnegative sums. No additional budget beyond the order-n A price is established by this identity.

Precise meaning of “actual cost”: Gamma_P represents exactly the whole-coarse-cell raw PRODUCT response specified in (1). That product has already discarded the original near and other positive pair masks; it is a majorant for the corresponding masked original response, not an equality to the complete original near/history/score traffic at each node. If those variables are retained, their factors must be inserted before the source integration. The author's subsequent paragraph explicitly keeps that further score/clock marginal unproved. No extra original negative credit or score budget may be inferred from (2).

The spatial masses rho(P) are not automatically stopping-node input masses: first-containment stopping depends on receiver and latent shape. The author explicitly warns against that substitution.

## 2. Bellman candidate

The displayed Hessian of I is correct on A<=B, with the symmetric version on B<=A and matching gradients at equality. Its continuous zero-boundary convention gives joint concavity and degree-one homogeneity. Hence every actually conserved child split satisfies sum I(A_i,B_i)<=I(sum A_i,sum B_i). Proportional mass splits give equality. This is not a proof of an additional positive stop cost, a desired hard-source child disintegration, or a smaller marginal price. The author's distinction between algebraic aggregation and the proved order-n capacity state is correct.

## 3. Full-soft fixed-shape weak estimate

The diagonal coordinate transformation preserves the source mass and cancels its determinant in the receiver weak constant. Its transformed source is an arbitrary L1 measure supported in a rectangle of widths d/R_i and can be enclosed in a cube of side ell=d/min R_i.

When ell<=a the historical R251 support-qualified weak theorem applies. When ell>a, the author correctly switches to the strong all-L shape envelope of mass A rather than invoking the small-cluster theorem outside its hypotheses. The identity (min R_i)^(-1)=max R_i^(-1) and the upper bound by U_R=1+sum_soft R_i^(-1) are correct, including all-hard and all-soft sides larger than one. In the large-ell case, kappa0 U_R>=2+n>A; thus (4) covers every positive rounded shape, including arbitrarily small sides. There is no shape-uniform minimum-radius assumption and no component FIRST.

## 4. Marked inverse law and all constants

The underlying interval-mixture probability and its density/second moment are already independently established in R281. Upward rounding gives phi(0)/zeta<=z1<=phi(0). The explicit lower bound phi(0)>=1/(2e) follows by restricting u to [1/2,1] and |x|<=1/2, so (5)'s z1>=1/(4e) is valid.

The inverse logarithmic moment bound 13.5 follows from the density <=r/2 near zero and the second moment 13 in the tail. With eta|j|<=|log r|+eta and eta<=log2, division by z1>=1/(4e) yields at most 54e+4e log2<60e, proving the loose bound in (6). Finite-partition Gibbs inequalities and entropy limits justify the countable inverse law without circularly assuming its entropy is finite.

The base-plus-one-mark construction has exactly total mass U_R. After normalization, mark zero leaves the original product label law; mark i forces its soft coordinate to the inverse-side law and leaves all remaining coordinates in the original product label law. Thus the entropy bound log(n+1)+H_*+H(p_inv) is valid. This is independence of auxiliary kernel labels, never of original sources.

The mean marked mass Z_k=1+nt_k z1<=D+3 is correct. Across M nodes, total assigned weak mass is bounded by e^2 kappa0 rho(C) M(D+3); the node-choice entropy is at most log M. Splitting each K_R rho_C into its mark fractions is an exact nonnegative decomposition. Its assigned weak constants sum with the marked weights, so it does not duplicate the response or source. R281's fixed-weight weak-sum lemma gives precisely B_* in P0 and P1. All weights are receiver independent. The actual full response alone retains its separate FIRST cap.

## 5. P2 actual full raw near budget

At the actual receiver, use F_C/q<=1 and G_C/(4lambda)<=1, the full-soft weak constant kappa0 B_*rho(C), and the hard-cluster weak constant kappa0 nu(C). The exact capped-product I and its logarithmic amplification give (7) with exactly 16/3=4lambda/q_-; variable q(x) is permitted because the actual ratio is retained before using q_-.

Summing coarse cells charges each true source mass once. The original near same-cell probability is at least 1/2, giving the sole factor two and proving P2 for the full raw near mother. No fine same-cell event, depth entropy, hard-source copy, or source comparison is used. P2 also bounds the specific remaining first-contained allocation by positivity. When applying it after previous paid portions, only the actual still-unpaid positive restriction is registered; the available bound on the larger full mother does not license recharging already paid traffic.

For uniform D=O(log(n+2)), B_*=O(log(n+2)^4), so its logarithm is an iterated-log factor in the full raw source price. Multiplication by the existing good-score clock bound contributes sqrt(nD), on top of kappa0=O(sqrt n), giving n times polylog in general. The author correctly does not call this root-order positive traffic, general weak-(1,1) closure, or a complete signed payment. Original terminal-source and outer-data uniformity qualifications remain required.

## 6. Physical clock formula (8)

At a fixed physical xi=c_jt/b, original scale qualification gives min(L,R)>=bxi/gamma. One must retain the actual clock-domain receiver gate E_xi until this inequality is applied. On that receiver subset, actual FIRST and hard caps remain valid; then one may use the weak envelopes over the smaller window [a_xi,b], a_xi=max(a,bxi/gamma). This order is essential: dropping the clock gate first and imposing a_xi on unrelated receivers would not be justified.

Within that subset, the preceding transformed-source proof works with a_xi in place of a and the same actual coarse d. The strong envelope A_xi is also available. Thus fixed-shape weak constants are bounded by

min(A_xi,(2+nd/a_xi)U_R)<=min(A_xi,2+nd/a_xi)U_R=kappa_xi U_R.

The hard cluster has the same kappa_xi bound. The marked-label probabilities, M, B_* and their entropy remain fixed and unchanged; no new xi menu is introduced. Applying the capped-product bound at each xi yields the stated source bracket times 2kappa_xi. Outside 2Lambda and the scalar score f_D then give exactly 4Lambda times the integral in (8).

The complete posterior must be bounded pointwise by f_D BEFORE its transformed time becomes receiver dependent. The actual unique j indicator remains until that step; hence no copied source sum or extra j clock factor occurs. “Middle” is the original middle physical-clock domain, enlarged only positively to its common valid interval if needed. Variable outer parameters must remain in their corresponding source sums until uniformly bounded. Under these qualifications (8) is a correct explicit refinement, not an additional root estimate or an eliminated face/score correlation.

## Actual bounded diagnostic replay

After reading the complete hash-bound script I ran it on the local computer. Output:

`{'checks': 423, 'phi_zero': '0.55679127144964308526', 'inverse_log_moment': '0.33946614614558099903', 'inverse_moment_residual': '0.0', 'status': 'PASS'}`

The count is three ordinary 40-digit moment assertions, twenty scalar n/r_min guard checks using standard floating values, two hundred deterministic-seed finite superadditivity checks and two hundred amplification checks. The shape checks are scalar guard diagnostics, not actual high-dimensional profile or FULL history constructions. A displayed zero mpmath residual does not certify symbolic equality or 40 correct digits. None of these diagnostics is interval arithmetic or the proof of the countable/continuous statements above. The independent screen also records its own bounded inverse-moment calculation and code.

Audit complete. The genuine remaining issue is the joint source/score/receiver budget needed to improve the full positive-traffic order, not the depth-independent raw bound or existence of the order-n Gamma split.
