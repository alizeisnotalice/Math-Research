# R283 independent audit: normalized coarse same-cell information

**Verdict: PASS.** This certifies the stated fixed normalized-channel extension only. It does not certify an adaptive-selector, raw-source, score-clock, or root-order traffic budget.

## CA1. Source/version and independent order

Audited author file:

`/tmp/r283_coarse_information.md`

SHA256 `5a61950c93cf200d5891406f34029d345a72cb42c2374aa736a7ad670b9a8acb`.

The mathematical statement was independently checked from the parent's message before reading this file. The file was then read in full and its actual SHA verified. The fixed-channel theorem used as an input was independently screened before its author draft was read, and finally audited at:

- `/tmp/r283_info_screen.md`, SHA256 `8a1e42431dd6df4f60566d2ecda204285873f79840b664036c9221e756d94bbe`;
- `/tmp/r283_infoaudit.md`, SHA256 `214d003f26c8c1d10a9ec31736d59234ef8d1230db0aad51fcb89ebd37b9915b`;
- its final author `/tmp/r283_near_channel.md`, SHA256 `02b670f094ba6f73fb1d30c9415a267838ab457cdf7317ac233b6a39193b1bea`.

Only this new audit file is written for this extra task. No author file, repository, Git state or PDF is changed.

## CA2. Exact normalization and unchanged source prior

Fix z and a Borel probability pi supported in B1(z,d/2). Under P, the coarse shift g is independent of the whole source/shape/noise construction. The factor

`w(y,g)=1_samecoarse(y,z;g)/P_d(y-z)`

is measurable, lies in [0,2], and satisfies integral w(y,g)dg=1 for every y in the prior support. The same-cell probability is exactly the product of one-dimensional overlap fractions, and the l1 near condition implies P_d>=1/2. Therefore Q=wP is a probability and Q_Y=pi, exactly; there is no source-prior tilt in this change of law.

Since w is a function only of (Y,g), Q_B=P_B and B is independent of (Y,g) under Q. Conditional on (Y,B,g), the original rectangle-noise law is unchanged. In fact the noise remains independent of (Y,B,g). The grid generally becomes dependent on Y, which is explicitly charged next rather than assumed away.

## CA3. The coarse information cost

On Q's support log w=-log P_d(Y-z). Thus

`D(Q_Yg || pi tensor dg)=E_pi[-log P_d(Y-z)]<=log 2`.

This is a finite ordinary relative entropy, including arbitrary singular pi. The entropy chain rule gives exactly

`D(Q_Yg || pi tensor dg)=I_Q(Y;g)+D(Q_g||dg)`,

since Q_Y=pi. Consequently I_Q(Y;g)<=log 2. No differential entropy of Y or g is used, and the grid marginal is not silently replaced by dg under Q.

## CA4. Conditional shape channel and stopping depth

For Q_g-almost every g, the conditional Y law is still supported in the same fixed near ball. B remains independent of that law and has the same inverse-side moments. The conditional rectangle channel is the original one. Therefore the already proved arbitrary-prior fixed-shape theorem applies conditionally on g and yields

`I_Q(Y;X,B | g)<=d/(2L)[1+log(2n)]`.

This bound is uniform in the changed conditional source law; it does not invoke entropy of that law. Integrating over Q_g is valid because the conditional relative entropy is nonnegative and bounded by the displayed finite constant.

For each fixed (Y,B,g), the probability that the depth-k cell is wholly in the receiver rectangle remains

`product_i (1-d 2^-k/(LB_i))_+`.

The same-center interval geometry and the same nested grid are unchanged by Q's source/grid reweighting. Therefore

`Q(J>k |Y,B,g)=1-product_i (1-d 2^-k/(LB_i))_+`.

Every conditional tail depends only on B, which proves `J independent of (Y,g) given B` under Q. It is not inferred merely from a name or from the unconditional source marginal. The B law is unchanged, so both the tail/mean bound

`E_Q J<=m_*=log2 max(1,nd/L)+2`

and the entropy bound

`H_Q(J)<=log(e(m_*+1))`

are unchanged. The finiteness of H(J), the exact dyadic phase constant and the latent inverse-side moment were already independently established in the base audit.

The full information chain therefore proves exactly the boxed extension:

`I_Q(Y;X,B,g,J)`

` <=log 2+d/(2L)[1+log(2n)]`

`        +log(e{3+log2 max(1,nd/L)}).`

The H(J) increment is retained even though J is independent of Y before X is observed. No claim is made about the full fine-cell address or its prior entropy.

## CA5. Exact scope and remaining payment qualifications

The same-cell/P_d reweighting has been integrated into the **fixed normalized** information result without a free grid-independence assumption. It does not crop fine off-diagonal pairs inside the original coarse cell. The original source prior is preserved, and the new grid dependence has the explicit finite fee log 2.

The following costs are still outside the result, exactly as the author states:

- output-dependent physical L(x),s(x), whose spliced kernels need not have unit source columns;
- integration of the normalized conditional prior back into the original unnormalized rho(dy)nu(dz) and real dx traffic;
- conversion of a posterior-to-prior information bound into a positive weak-response or containment-remainder payment;
- the original auxiliary posterior Pi, terminal/process masks and score-clock normalization.

In particular Q's weight is independent of X/noise because parameters are fixed. Multiplying it by actual selector/history weights does not automatically preserve any of the conditional channel statements. Source-dependent rejection and finite-selector fees remain those in the base theorem. The extension does not erase the unpaid source-pair mass of its equation (11), supply backward FIRST, or establish general closure.

No additional numerical experiment is needed for this finite algebraic extension. Its proof uses the exact normalization, KL chain rule and the already independently replayed 30+12 base diagnostics; those diagnostics were ordinary finite mathematical-tool checks, not interval certificates or FULL original inputs. No new numerical result is claimed here.

**Final status: PASS, frozen at the author hash in CA1. No further correction requested.**
