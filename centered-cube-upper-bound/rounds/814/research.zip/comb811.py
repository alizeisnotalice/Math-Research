#!/usr/bin/env python3
"""Exact periodic-comb cube fixtures and a same-membership subtransport benchmark."""
import argparse
from collections import defaultdict
from fractions import Fraction as F
from itertools import combinations, product
from math import prod
import json
from pathlib import Path
import platform

SUPPORT = F(8)
PERIOD = F(1, 2)
PHASE = F(1, 4)
FLOOR = F(1, 64)


def total(values):
    return sum(values, F(0))


def cube(center, radius):
    return tuple((x - radius, x + radius) for x in center)


def intersection(left, right):
    return tuple((max(a, c), min(b, d)) for (a, b), (c, d) in zip(left, right))


def volume(box):
    return prod(max(F(0), hi - lo) for lo, hi in box)


def period_bump_primitive(x, half_width):
    cycle = x // PERIOD
    phase = x - cycle * PERIOD
    return cycle * 2 * half_width + min(2 * half_width, max(F(0), phase - PHASE + half_width))


def comb_density_peak(half_width):
    return FLOOR + (1 - FLOOR) * PERIOD / (2 * half_width)


def interval_mass(lo, hi, half_width):
    lo, hi = max(lo, -SUPPORT), min(hi, SUPPORT)
    if hi <= lo:
        return F(0)
    high = period_bump_primitive(hi, half_width) - period_bump_primitive(lo, half_width)
    return FLOOR * (hi - lo) + (comb_density_peak(half_width) - FLOOR) * high


def mass(box, half_width):
    return prod(interval_mass(lo, hi, half_width) for lo, hi in box)


def direct_box_mass(box, half_width):
    def one(lo, hi):
        lo, hi = max(lo, -SUPPORT), min(hi, SUPPORT)
        if hi <= lo:
            return F(0)
        start, end = (-SUPPORT) // PERIOD, SUPPORT // PERIOD
        high = total(max(F(0), min(hi, PHASE + k * PERIOD + half_width)
                         - max(lo, PHASE + k * PERIOD - half_width)) for k in range(start, end))
        return FLOOR * (hi - lo) + (comb_density_peak(half_width) - FLOOR) * high
    return prod(one(lo, hi) for lo, hi in box)


def dyadic_left(x):
    d = F(1)
    while d > x:
        d /= 2
    while 2*d <= x:
        d *= 2
    return d


def corner(label, radius, signs, gaps, transverse):
    radius = F(radius)
    center = tuple(sgn * (F(7, 4) + radius - F(gap)) for sgn, gap in zip(signs, gaps))
    return (label, center + (F(transverse),), radius)


# Each tuple for an old parent fixes its exact thin intersection widths with T0.
FIXTURES = [
    ("one_thin_axis", 2, F(1, 1024),
     [("t0", (0, 0), "7/4"), ("t1", (0, "3/8"), "7/4")],
     [corner("u0", 1, (-1,), ("1/1024",), "-1/4"),
      corner("u1", "3/2", (1,), ("3/2048",), "-3/8")]),
    ("two_thin_axes", 3, F(1, 2048),
     [("t0", (0, 0, 0), "7/4"), ("t1", (0, 0, "3/8"), "7/4"), ("t2", (0, 0, "-3/8"), "7/4")],
     [corner("u0", 1, (-1, -1), ("1/2048", "1/4096"), "-1/2"),
      corner("u1", "5/4", (-1, 1), ("1/4096", "3/4096"), "1/2"),
      corner("u2", "3/2", (1, 1), ("3/4096", "1/4096"), "-3/8"),
      corner("u3", "3/2", (1, -1), ("1/2048", "1/2048"), "1/2")]),
    ("three_thin_axes", 4, F(1, 2048),
     [("t0", (0, 0, 0, 0), "7/4"), ("t1", (0, 0, 0, "3/8"), "7/4"),
      ("t2", ("-1/4", "1/4", "-1/4", "-3/8"), "3/2")],
     [corner("u0", 1, (-1, 1, -1), ("1/4096", "1/2048", "1/4096"), "-1/2"),
      corner("u1", "5/4", (-1, 1, -1), ("1/2048", "1/4096", "3/4096"), "-1/8"),
      corner("u2", "3/2", (1, -1, 1), ("3/4096", "1/4096", "1/2048"), "3/8"),
      corner("u3", "3/2", (-1, 1, -1), ("3/4096", "1/2048", "1/4096"), "-3/8"),
      corner("u4", 1, (1, 1, -1), ("1/2048", "1/2048", "1/4096"), "1/2")]),
]


def make_parents(n, wide, middle_specs, old_specs):
    h = 1 + F(1, 32*n)
    out = []
    shares = {"middle": (1, F(3, 4), F(5, 8)), "old": (1, F(7, 8), F(3, 4), F(5, 8), F(1, 2))}
    for role, family in (("middle", middle_specs), ("old", old_specs)):
        for (label, center, radius), share in zip(family, shares[role], strict=False):
            center, s = tuple(map(F, center)), F(radius)
            A, expanded = cube(center, s), cube(center, h*s)
            E = cube(center, s/(32*n))
            halves = tuple(((a, b),)+E[1:] for a,b in ((E[0][0],center[0]),(center[0],E[0][1])))
            m,j = volume(A),share*volume(E)
            assert len(center) == n and 1 <= s < 2 and 2*s % PERIOD == 0
            assert all(-SUPPORT < a < b < SUPPORT for a, b in expanded)
            assert m == mass(A, wide) == direct_box_mass(A, wide)
            assert volume(E) == 2*volume(halves[0]) == 2*volume(halves[1])
            assert 0 < j <= volume(E)
            out.append(dict(id=label, bit=1 << len(out), role=role, center=center, radius=s,
                            box=A, expanded_box=expanded, m=m, j=j, volume_bin=dyadic_left(m),
                            owner=E, owner_volume=volume(E), owner_halves=halves))
    assert len(out) == len(middle_specs) + len(old_specs)
    assert all(volume(intersection(x["owner"], y["owner"])) == 0 for x,y in combinations(out,2))
    return out


def geometric_cells(boxes, wide):
    """Partition on true face cuts, then intersect the per-axis masks by bitwise AND."""
    n, mask_all = len(boxes[0]), (1 << len(boxes)) - 1
    cells = {mask_all: (F(1), F(1))}
    counts = []
    for axis in range(n):
        edges = sorted({-SUPPORT, SUPPORT, *(v for box in boxes for v in box[axis])})
        axis_cells = defaultdict(lambda: [F(0), F(0)])
        for a,b in zip(edges, edges[1:]):
            mid = (a+b)/2
            mask = sum(1 << i for i, box in enumerate(boxes) if box[axis][0] < mid < box[axis][1])
            axis_cells[mask][0] += b-a
            axis_cells[mask][1] += interval_mass(a,b,wide)
        new = defaultdict(lambda: [F(0), F(0)])
        for (i,(v,m)), (j,(w,l)) in product(cells.items(), axis_cells.items()):
            target = new[i&j]
            target[0] += v*w
            target[1] += m*l
        cells = new
        counts.append(len(edges)-1)
    assert total(v for v,_ in cells.values()) == total(m for _,m in cells.values()) == (2*SUPPORT)**n
    assert all(v > 0 and m > 0 for v,m in cells.values())
    return dict(sorted(cells.items())), counts


def verify_by_intersection_inversion(cells, boxes, wide):
    # Möbius inversion of all inclusive intersections, independent of the face partition.
    support = ((-SUPPORT,SUPPORT),)*len(boxes[0])
    intersections = [support]
    for mask in range(1,1 << len(boxes)):
        bit = mask & -mask
        intersections.append(intersection(intersections[mask^bit],boxes[bit.bit_length()-1]))
    exact = [[volume(B),mass(B,wide)] for B in intersections]
    for k in range(len(boxes)):
        bit = 1 << k
        for mask, weights in enumerate(exact):
            if mask & bit == 0:
                v,m = exact[mask|bit]
                weights[0] -= v
                weights[1] -= m
    assert all(v >= 0 and m >= 0 for v,m in exact)
    assert {i:[v,m] for i,(v,m) in enumerate(exact) if v or m} == cells


def measure_containing(cells, required, k):
    return total(entry[k] for name, entry in cells.items() if name & required == required)


def row_degrees(parents, cells, wide):
    degrees, intersections = {}, {}
    for t in parents:
        tag = t["id"]
        exact_terms, active_terms, intersections[tag] = {}, {}, {}
        for u in parents:
            label = u["id"]
            H = intersection(t["box"],u["box"])
            mask = t["bit"] | u["bit"]
            weight = measure_containing(cells, mask, 1)
            assert volume(H) == measure_containing(cells, mask, 0)
            assert weight == mass(H,wide) == direct_box_mass(H,wide)
            intersections[tag][label] = weight
            term = F(0) if tag == label else u["j"]*weight/(t["m"]*u["m"])
            exact_terms[label] = term
            if u["role"] == "old" and u["radius"] < t["radius"] and term:
                active_terms[label] = term
        d_full, d_old = total(exact_terms.values()),total(active_terms.values())
        assert d_full > 0 and d_old <= d_full
        degrees[tag] = dict(full_d=d_full,old_d=d_old,full_terms=exact_terms,old_terms=active_terms,
                            true_mu_intersections=intersections[tag])
        t["full_d"],t["old_d"] = d_full,d_old
    return degrees, intersections


def layer_min(z_masks, q_masks, cells, acceptance):
    levels = sorted({F(0), *(acceptance[i] for i in z_masks+q_masks)})
    return total((high-low)*total(cells[i][1] for i in z_masks if acceptance[i] >= high)
                 *total(cells[j][1] for j in q_masks if acceptance[j] >= high)
                 for low,high in zip(levels, levels[1:]))


def build_roots(parents, cells, degrees, pair_intersections):
    all_roots, cross_roots, arm_geometry = [], [], []
    by_label = {p["id"]:p for p in parents}
    acceptance = {mask:min(F(1), v/m) for mask,(v,m) in cells.items()}
    for t in (p for p in parents if p["role"] == "middle"):
        tag = t["id"]
        row = degrees[tag]
        active = tuple(row["old_terms"])
        assert len({by_label[i]["volume_bin"] for i in active}) >= 2
        for u in (by_label[label] for label in active):
            H = intersection(t["box"], u["box"])
            L,M = volume(H),pair_intersections[tag][u["id"]]
            arm_geometry.append(dict(t=tag,u=u["id"],intersection=H,axis_lengths=[b-a for a,b in H],
                                     leb=L,mu=M,mu_over_leb=M/L,mu_over_old_mass=M/u["m"]))
        for uk,gk in product(active, repeat=2):
            u,g = by_label[uk],by_label[gk]
            masks = [[mask for mask in cells if mask & (t["bit"]|p["bit"]) == t["bit"]|p["bit"]] for p in (u,g)]
            z,q = masks
            factor = t["j"]/row["full_d"]*(u["j"]/u["m"]/t["m"])*(g["j"]/g["m"]/t["m"])
            mu_z,mu_q = (total(cells[i][1] for i in arm) for arm in masks)
            root_mass = factor*mu_z*mu_q
            cross = u["volume_bin"] != g["volume_bin"]
            assert root_mass == t["j"]/row["full_d"]*row["old_terms"][uk]*row["old_terms"][gk] > 0
            sector_mothers = [
                factor*total(cells[a][1]*cells[b][1] for a,b in product(z,q))
                *volume(U)/u["owner_volume"]*volume(W)/g["owner_volume"]
                for U,W in product(u["owner_halves"],g["owner_halves"])
            ]
            assert sum(sector_mothers,F(0)) == root_mass and all(w==root_mass/4 for w in sector_mothers)
            z_hit,q_hit = (total(cells[i][1]*acceptance[i] for i in arm) for arm in masks)
            independent = total(cells[a][1]*cells[b][1]*acceptance[a]*acceptance[b] for a,b in product(z,q))
            synchronous = total(cells[a][1]*cells[b][1]*min(acceptance[a],acceptance[b]) for a,b in product(z,q))
            assert independent == z_hit*q_hit
            assert synchronous == layer_min(z,q,cells,acceptance)
            assert 0 < independent <= synchronous <= mu_z*mu_q
            record = dict(t=tag,u=uk,g=gk,coefficient=factor,root_mass=root_mass,z_masks=z,q_masks=q,
                          sectors_00_01_10_11=sector_mothers,
                          z_success=factor*z_hit*mu_q,q_success=factor*mu_z*q_hit,
                          independent_success=factor*independent,synchronous_success=factor*synchronous)
            all_roots.append(record)
            if cross:
                cross_roots.append(record)
    return all_roots,cross_roots,arm_geometry,acceptance


def summarize(roots):
    keys = ("root_mass","z_success","q_success","independent_success","synchronous_success")
    data = {key:total(e[key] for e in roots) for key in keys}
    M = data["root_mass"]
    out = {key:val/M for key,val in data.items() if key != "root_mass"}
    assert out["z_success"] == out["q_success"]
    assert out["synchronous_success"] > out["independent_success"]
    return dict(records=len(roots), mother=M, exact_mass=data, rates=out,
                synchronous_over_independent=out["synchronous_success"]/out["independent_success"],
                independent_root_joint_minus_global_marginal_product=out["independent_success"]-out["z_success"]*out["q_success"])


def fixture(name,n,wide,middle_specs,old_specs):
    parents = make_parents(n,wide,middle_specs,old_specs)
    boxes = [p["box"] for p in parents]
    target_boxes = [p["expanded_box"] for p in parents]
    cells, shape = geometric_cells(boxes,wide)
    expanded, expanded_shape = geometric_cells(target_boxes,wide)
    verify_by_intersection_inversion(cells,boxes,wide)
    verify_by_intersection_inversion(expanded,target_boxes,wide)
    for p in parents:
        bit = p["bit"]
        assert measure_containing(cells,bit,0) == measure_containing(cells,bit,1) == p["m"]
        assert measure_containing(expanded,bit,0) == volume(p["expanded_box"])
    d,J = row_degrees(parents,cells,wide)
    all_roots,cross,arms,a = build_roots(parents,cells,d,J)
    assert all(sum(F(0)<x<=3*wide/2 for x in arm["axis_lengths"]) == n-1
               for arm in arms if arm["t"] == "t0")
    mid_labels = [p["id"] for p in parents if p["role"] == "middle"]
    for p in (p for p in parents if p["role"] == "middle"):
        tag = p["id"]
        j,d_v = p["j"],d[tag]
        mother = j*d_v["old_d"]**2/d_v["full_d"]
        assert total(r["root_mass"] for r in all_roots if r["t"] == tag) == mother
        assert d_v["full_d"] > d_v["old_d"]
        by_bin = defaultdict(F)
        for u in parents:
            by_bin[u["volume_bin"]] += d_v["old_terms"].get(u["id"],F(0))
        cross_mother = j/d_v["full_d"]*(d_v["old_d"]**2-total(v*v for v in by_bin.values()))
        assert cross_mother == total(r["root_mass"] for r in cross if r["t"] == tag) > 0
    retained = total(min(v,m) for v,m in cells.values())
    supply_loss = total(m*(1-a[mask]) for mask,(v,m) in cells.items())
    target_loss = total(v-m*a[mask] for mask,(v,m) in cells.items())
    assert supply_loss == target_loss == (2*SUPPORT)**n-retained > 0
    assert len({p["volume_bin"] for p in parents if p["role"] == "old"}) >= 2
    if n==4:
        assert len({p["volume_bin"] for p in parents if p["role"] == "middle"}) >= 2
    return dict(stage=name, dimension=n, h=1+F(1,32*n), parent_order=[p["id"] for p in parents],
                middle_labels=mid_labels, parents=parents, degrees=d,
                density=dict(support=[-SUPPORT,SUPPORT], period=PERIOD,bump_center_mod_period=PHASE,bump_half_width=wide,
                             density_floor_one_axis=FLOOR,density_peak_one_axis=comb_density_peak(wide),
                             n_dimensional_density="product of the n one-dimensional densities"),
                true_face_intervals_per_axis=shape,expanded_face_intervals_per_axis=expanded_shape,
                cells=[dict(mask=mask,volume=v,mass=m,expanded_target_volume=expanded.get(mask,(0,0))[0],
                            same_membership_acceptance=a[mask]) for mask,(v,m) in cells.items()],
                expanded_target_cells=[dict(mask=mask,volume=v) for mask,(v,_) in expanded.items()],
                roots_all=all_roots,roots_cross=cross,arm_geometry=arms,
                kernel_same_membership=dict(maximal_retained_mass=retained,
                                            residual_source_and_target_mass=supply_loss,
                                            supplemental_completion="normalized product of the balanced residual source and target measures"),
                benchmarks=dict(all=summarize(all_roots),cross=summarize(cross)))


def certificate():
    return dict(schema_version=1, interpreter=platform.python_version(), machine=platform.machine(),
                arithmetic="exact fractions.Fraction; no rounded comparison",
                cross_law="strictly downward old arms from distinct dyadic volume bins; full original degree includes all positive non-self parents",
                mask_layout="bit i indicates membership in parent_order[i]; expansion masks use the same bits with separately expanded parents; mask zero retained on source support",
                root_measure="ordered u/z and g/q price slots with their original joint weight; conditional on (t,u,g) each is the true normalized intersection price, the two actual disjoint owner cubes are independently uniform",
                kernel="within membership cell C keep min(1,volume(C)/mu(C)) of its input; send kept mass uniformly inside C. Mark only these successful events.",
                scope="Finite genuine cube and continuous product comb reproductions, with prescribed diagnostic edge criteria and no high-dimensional screening.",
                command="python -B comb811.py --check comb811.json",
                stages=[fixture(*args) for args in FIXTURES])


def main():
    parser=argparse.ArgumentParser()
    modes=parser.add_mutually_exclusive_group()
    modes.add_argument("--output",type=Path)
    modes.add_argument("--check",type=Path)
    args=parser.parse_args()
    data=certificate()
    encoded=(json.dumps(data,default=str,sort_keys=True,indent=2)+"\n").encode()
    if args.check:
        assert args.check.read_bytes()==encoded
    elif args.output:
        args.output.write_bytes(encoded)
    else:
        print(encoded.decode(),end="")
        return
    for stage in data["stages"]:
        for name,b in stage["benchmarks"].items():
            r=b["rates"]
            print(stage["dimension"],name,len(stage["cells"]),len(stage["expanded_target_cells"]),
                  b["records"],*(f"{float(r[k]):.10g}" for k in ("z_success","independent_success","synchronous_success")),
                  f"{float(b['synchronous_over_independent']):.10g}")
    if args.check:
        print("byte-identical")


if __name__ == "__main__":
    main()
