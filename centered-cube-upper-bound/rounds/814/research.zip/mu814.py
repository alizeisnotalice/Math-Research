#!/usr/bin/env python3
"""R813 four-dimensional one-arm, cell-resolved capacity diagnostics."""
from fractions import Fraction as F
from collections import defaultdict
from itertools import product
from pathlib import Path
import sys,json,hashlib,argparse
import numpy as np
from scipy.optimize import linprog
from scipy.sparse import lil_matrix
parser=argparse.ArgumentParser()
parser.add_argument('--comb',type=Path,required=True); parser.add_argument('--trade-dir',type=Path,required=True); parser.add_argument('--factor',required=True); parser.add_argument('--out',type=Path,required=True); parser.add_argument('--check',action='store_true'); args=parser.parse_args()
sys.path.insert(0,str(args.trade_dir))
from trade813 import source_law, box, volume, intersection
P=args.comb
stage=json.loads(P.read_text())['stages'][-1]
parents,supply,lam,a,contacts,events,joint,mark=source_law(stage)
cells={c['mask']:(F(c['mass']),F(c['volume'])) for c in stage['cells']}
bits={i:parents[i]['bit'] for i in supply}
owners=list(parents)
factor=F(args.factor); cap={k:F(parents[k]['owner_volume'])*factor for k in owners}
OUT=args.out
AMP=1; D=512
# z cell is retained; selection of the left mark sums to one, exactly.
# Right mark is lambda / F(q), and is retained individually.
weights=defaultdict(F)
for e in stage['roots_cross']:
 t,u,g=(e[k] for k in ('t','u','g'))
 coef=F(e['coefficient'])
 for z,q in product(e['z_masks'],e['q_masks']):
  live=[j for j in supply if q&bits[j]]
  for j in live:
   weights[(t,g,z,q,j)]+=coef*cells[z][0]*cells[q][0]/len(live)
assert sum(weights.values(),F(0))==sum(joint.values(),F(0))
M=sum(weights.values(),F(0))
keys=list(sorted(weights)); groups=sorted(set((z,q,j) for t,g,z,q,j in keys))
# R813 two-slot uniform-product reception with original right arm g,t.
coeff={}
for t,g,z,q,j in keys:
 for k,l in product(owners,repeat=2):
  K,L=box(parents[k],'owner'),box(parents[l],'owner')
  tfrac=volume(intersection(K,box(parents[t],'expanded_box')))/volume(K)
  gfrac=volume(intersection(L,box(parents[g],'expanded_box')))/volume(L)
  if tfrac and gfrac: coeff[t,g,k,l]=tfrac*gfrac
cols=[]
for z,q,j in groups:
 for k,l in product(owners,repeat=2):
  if any(zz==z and qq==q and jj==j and (t,g,k,l) in coeff for t,g,zz,qq,jj in keys):
   cols.append((z,q,j,k,l))
print('events',len(keys),'columns',len(cols),'groups',len(groups),flush=True)
# q-source unit is lambda times true mu mass; denominator is original unthinned contact c[t,g,j].
src_cap={q:lam*cells[q][0] for q in cells}
sc={q:min(src_cap[q],F(1,1024)) for q in cells}
G=defaultdict(list)
for ei,(t,g,z,q,j) in enumerate(keys):
 for ci,(zz,qq,jj,k,l) in enumerate(cols):
  if (z,q,j)==(zz,qq,jj) and (t,g,k,l) in coeff:
   G[ci].append((ei,D*sc[q]*coeff[t,g,k,l]/(lam*contacts[t,g,j])))

def aggregate_global(x):
 plan=defaultdict(F)
 for ci,(z,q,j,k,l) in enumerate(cols):
  if x[ci]: plan[j,k,l]+=x[ci]*sc[q]
 source={j:sum(v for (jj,k,l),v in plan.items() if jj==j) for j in supply}
 owners_use=[{k:sum(v for (j,kk,ll),v in plan.items() if (kk if side==0 else ll)==k) for k in owners} for side in (0,1)]
 source_ratios={j:source[j]/a[j] for j in supply}
 owner_ratios=[{k:owners_use[side][k]/F(parents[k]['owner_volume']) for k in owners} for side in (0,1)]
 global_hits={}
 for t,g,z,q,j in keys:
  global_hits[t,g,j]=D*sum(v*coeff.get((t,g,k,l),F(0)) for (jj,k,l),v in plan.items() if jj==j)/(lam*contacts[t,g,j])
 global_rate=sum(weights[e]*min(F(1),global_hits[e[0],e[1],e[4]]) for e in keys)/M
 return {'global_one_arm_rate':str(global_rate),'global_one_arm_rate_float':float(global_rate),'source_ratios':{k:str(v) for k,v in source_ratios.items()},'owner_ratios':[{k:str(v) for k,v in row.items()} for row in owner_ratios], 'moves':[[*k,str(v)] for k,v in sorted(plan.items())]}

def solve(mode):
 src=sorted(set((z,q,j) if mode==0 else (q,j) for z,q,j,k,l in cols))
 srci={v:i for i,v in enumerate(src)}
 nr=len(src)+(2*len(owners) if mode==2 else 0); n=len(cols); ne=len(keys)
 A=lil_matrix((nr+ne,n+ne),dtype=float); b=np.r_[np.ones(len(src)),np.ones(nr-len(src)),np.zeros(ne)]
 for ci,(z,q,j,k,l) in enumerate(cols):
  A[srci[(z,q,j) if mode==0 else (q,j)],ci]=float(sc[q]/src_cap[q])
  if mode==2:
   A[len(src)+owners.index(k),ci]=float(sc[q]/cap[k]); A[len(src)+len(owners)+owners.index(l),ci]=float(sc[q]/cap[l])
  for ei,gain in G[ci]: A[nr+ei,ci]=-float(AMP*gain)
 for ei in range(ne): A[nr+ei,n+ei]=1
 obj=np.r_[np.zeros(n),[-float(weights[e]/M) for e in keys]]
 res=linprog(obj,A_ub=A.tocsr(),b_ub=b,bounds=[(0,None)]*n+[(0,AMP)]*ne,method='highs',options={'time_limit':30})
 assert res.success,res.message
 # exact feasibility by rational shrink; dual repair using exact column maxima.
 x=[F(round(max(0.,float(v))*10**12),10**12) for v in res.x[:n]]
 used=[F(0)]*nr
 for ci,(z,q,j,k,l) in enumerate(cols):
  v=x[ci]; used[srci[(z,q,j) if mode==0 else (q,j)]]+=v*sc[q]/src_cap[q]
  if mode==2:
   used[len(src)+owners.index(k)]+=v*sc[q]/cap[k];used[len(src)+len(owners)+owners.index(l)]+=v*sc[q]/cap[l]
 shrink=max([F(1)]+used);x=[v/shrink for v in x]; used=[v/shrink for v in used]
 hit=[F(0)]*ne
 for ci,v in enumerate(x):
  if v:
   for ei,g in G[ci]: hit[ei]+=v*g
 pay=[min(F(1),h) for h in hit]
 lo=sum((weights[e]/M)*pay[i] for i,e in enumerate(keys))
 dual=[F(round(max(0.,float(-v))*10**12),10**12) for v in res.ineqlin.marginals]
 delta=[min(weights[e]/M,dual[nr+i]) for i,e in enumerate(keys)]
 prices=[v/AMP for v in dual[len(src):nr]]; source=[F(0)]*len(src)
 for ci,(z,q,j,k,l) in enumerate(cols):
  gain=sum(delta[ei]*v for ei,v in G[ci]); cost=F(0)
  if mode==2: cost=prices[owners.index(k)]*sc[q]/cap[k]+prices[len(owners)+owners.index(l)]*sc[q]/cap[l]
  si=srci[(z,q,j) if mode==0 else (q,j)];source[si]=max(source[si],(gain-cost)*src_cap[q]/sc[q])
 hi=sum(weights[e]/M-delta[i] for i,e in enumerate(keys))+sum(source)+sum(prices)
 assert lo<=hi
 byq={}
 for q,j in sorted(set((q,j) for z,q,j in groups)):
  ii=[i for i,e in enumerate(keys) if e[3:]==(q,j)]; total=sum(weights[keys[i]] for i in ii)
  byq[f'{q}:{j}']={'mass':str(total),'paid':str(sum(weights[keys[i]]*pay[i] for i in ii)),'partners':len({keys[i][2] for i in ii})}
 agg=aggregate_global(x) if mode==2 else None
 if agg:
  assert F(agg['global_one_arm_rate'])>=lo
  assert all(F(v)<=1 for v in agg['source_ratios'].values())
  assert all(F(v)<=factor for row in agg['owner_ratios'] for v in row.values())
 return {'aggregated_global':agg,'mode':mode,'lower':str(lo),'upper':str(hi),'lower_float':float(lo),'upper_float':float(hi),'by_right_cell':byq,'saturated_sources':[str(src[i]) for i,v in enumerate(used[:len(src)]) if v==1], 'saturated_owner_rows':[f'{side}:{owners[i]}' for side in (0,1) for i in range(len(owners)) if mode==2 and used[len(src)+side*len(owners)+i]==1], 'primal_positive':[[*cols[i],str(v)] for i,v in enumerate(x) if v], 'dual_delta':[str(d) for d in delta], 'dual_source':[str(d) for d in source], 'dual_target':[str(d) for d in prices], 'source_order':[str(s) for s in src]}
if args.check:
 data=json.loads(OUT.read_text())
 assert data['input_sha256']==hashlib.sha256(P.read_bytes()).hexdigest()
 assert data['trade813_sha256']==hashlib.sha256((args.trade_dir/'trade813.py').read_bytes()).hexdigest()
 assert data['D']==D and F(data['receiver_capacity_multiplier'])==factor
 for out in data['results']:
  mode=out['mode']; src=sorted(set((z,q,j) if mode==0 else (q,j) for z,q,j,k,l in cols)); srci={v:i for i,v in enumerate(src)}
  assert out['source_order']==[str(v) for v in src]
  pmap={tuple(row[:-1]):F(row[-1]) for row in out['primal_positive']}; assert all(c in cols and v>0 for c,v in pmap.items())
  used=[F(0)]*(len(src)+(2*len(owners) if mode==2 else 0)); hits=[F(0)]*len(keys)
  for ci,(z,q,j,k,l) in enumerate(cols):
   x=pmap.get((z,q,j,k,l),F(0)); used[srci[(z,q,j) if mode==0 else (q,j)]]+=x*sc[q]/src_cap[q]
   if mode==2:
    used[len(src)+owners.index(k)]+=x*sc[q]/cap[k]; used[len(src)+len(owners)+owners.index(l)]+=x*sc[q]/cap[l]
   for ei,g in G[ci]: hits[ei]+=x*g
  assert max(used)<=1
  lo=sum(weights[e]/M*min(F(1),hits[i]) for i,e in enumerate(keys)); assert lo==F(out['lower'])
  if mode==2:
   xvec=[pmap.get(c,F(0)) for c in cols]; agg=aggregate_global(xvec); assert agg==out['aggregated_global'] and F(agg['global_one_arm_rate'])>=lo
   assert all(F(v)<=1 for v in agg['source_ratios'].values()) and all(F(v)<=factor for row in agg['owner_ratios'] for v in row.values())
  delta=list(map(F,out['dual_delta'])); source=list(map(F,out['dual_source'])); target=list(map(F,out['dual_target']))
  assert all(0<=delta[i]<=weights[e]/M for i,e in enumerate(keys)) and all(v>=0 for v in source+target)
  for ci,(z,q,j,k,l) in enumerate(cols):
   cost=source[srci[(z,q,j) if mode==0 else (q,j)]]*sc[q]/src_cap[q]
   if mode==2: cost+=target[owners.index(k)]*sc[q]/cap[k]+target[len(owners)+owners.index(l)]*sc[q]/cap[l]
   assert cost>=sum(delta[ei]*g for ei,g in G[ci])
  hi=sum(weights[e]/M-delta[i] for i,e in enumerate(keys))+sum(source)+sum(target)
  assert hi==F(out['upper']) and lo<=hi
  print('verified exact primal and dual',mode,float(lo),float(hi),flush=True)
 sys.exit(0)

result={'schema':'r814 actual mu source-cell budgets v1', 'D':D, 'receiver_capacity_multiplier':str(factor), 'source_budget':'lambda times true mu mass of the q membership cell; shared for each j,q', 'trade813_sha256':hashlib.sha256((args.trade_dir/'trade813.py').read_bytes()).hexdigest(), 'input_sha256':hashlib.sha256(P.read_bytes()).hexdigest(),'scope':'one right arm only; original joint weights, with the left mark summed; original unthinned right-arm c[t,g,j] denominators, receiver capacities factor * actual owner volumes; D=512; true mu q-cell budget','events':len(keys),'columns':len(cols),'original_mass':str(M),'results':[]}
for mode in range(3):
 r=solve(mode);result['results'].append(r);print(mode,r['lower_float'],r['upper_float'],flush=True)
OUT.write_text(json.dumps(result,indent=2)+'\n')
