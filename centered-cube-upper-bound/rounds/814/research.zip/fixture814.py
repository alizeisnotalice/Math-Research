#!/usr/bin/env python3
"""Rebuild the wider continuous comb and check the true q-cell 95 records."""
import argparse
from collections import defaultdict
from fractions import Fraction as F
from itertools import product
import json
from pathlib import Path

from comb811 import FIXTURES, fixture


def trace(stage, q):
    parents = {parent["id"]: parent for parent in stage["parents"]}
    cells = {cell["mask"]: F(cell["mass"]) for cell in stage["cells"]}
    full_degree = {t: F(parent["full_d"]) for t, parent in parents.items()
                   if parent["role"] == "middle"}
    records = defaultdict(F)
    for root in stage["roots_cross"]:
        t, u, g = (root[key] for key in ("t", "u", "g"))
        middle, left, right = (parents[key] for key in (t, u, g))
        coefficient = F(middle["j"]) * F(left["j"]) * F(right["j"]) / (
            full_degree[t] * F(middle["m"])**2 * F(left["m"]) * F(right["m"])
        )
        assert coefficient == F(root["coefficient"])
        z_cells, q_cells = root["z_masks"], root["q_masks"]
        assert sum(coefficient * cells[z] * cells[r]
                   for z, r in product(z_cells, q_cells)) == F(root["root_mass"])
        if q in q_cells:
            for z in z_cells:
                key = (t, str(middle["volume_bin"]), u, str(left["volume_bin"]), g, z)
                records[key] += coefficient * cells[z] * cells[q]
    assert len({key[1] for key in records}) >= 2
    assert len({key[3] for key in records}) >= 2
    assert len({key[5] for key in records}) >= 2
    mass = sum(records.values())
    total = F(stage["benchmarks"]["cross"]["mother"])
    return {
        "q_mask": q,
        "q_mass": str(cells[q]),
        "subflow_original_mass": str(mass),
        "subflow_original_mass_float": float(mass),
        "total_original_cross_mass": str(total),
        "subflow_share": str(mass / total),
        "rows": [
            dict(t=t, middle_volume_bin=d, left_parent=u, left_volume_bin=du,
                 right_parent=g, z_mask=z, weight=str(weight))
            for (t, d, u, du, g, z), weight in sorted(records.items())
        ],
        "t_full_degrees": {t: str(value) for t, value in full_degree.items()},
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--comb", type=Path, required=True)
    parser.add_argument("--rebuilt", type=Path, required=True)
    parser.add_argument("--cell", type=Path, required=True)
    args = parser.parse_args()
    name, dimension, _, middles, olds = FIXTURES[-1]
    stage = fixture(name + "_wider_bumps", dimension, F(1, 1024), middles, olds)
    rebuilt = json.loads(json.dumps({"stages": [stage]}, default=str))
    assert rebuilt == json.loads(args.rebuilt.read_bytes()), "wider comb mathematical object differs"
    original = json.loads(args.comb.read_bytes())["stages"][-1]
    expected = json.loads(args.cell.read_bytes())
    for key, model in (("original", original), ("rebuilt", rebuilt["stages"][0])):
        values = trace(model, 95)
        assert values == expected[key], f"q-cell records differ for {key}"
        print(f"q-cell 95 {key}: {len(values['rows'])} exact rows, share={values['subflow_share']}")
    print("The wider comb was independently rebuilt from its exact geometric inputs.")


if __name__ == "__main__":
    main()
