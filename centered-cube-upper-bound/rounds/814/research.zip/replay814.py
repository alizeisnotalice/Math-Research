#!/usr/bin/env python3
"""Replay the round 814 archive without older checkouts or absolute input paths."""
import argparse
from hashlib import sha256
from importlib.metadata import version
import json
from pathlib import Path
import platform
import subprocess
import sys


FROZEN = {
    "comb811.py": "f573f0725c3b1364a5e600123d373fb2d737c6194718f20e967b52ba81dd2837",
    "trade813.py": "c5385fef3b410bb47a2ca1013835e26aad65c5ab933db9bdd07e389d9253da77",
    "info813.json": "f803b3e07fb854eb509d4fc4792128d65fcc001bd4992118e913cee0070ff342",
    "comb814-rebuilt.json": "d0e3ed7f50bc7f1d02df4c50b2a669b73938da862359360efaa2234932a031b0",
    "fixture814.py": "8e22c0a2d8adfb86b43d8bd1b4fb52222a0e5ac7c9030bb3640f5a7745c62910",
    "cell814.json": "5f458f9af30a571ad1f85fdfb9a70093de63c4f77b59695d1ab25aa49eac1f1f",
    "decode814.py": "83093b1fd0e856a7ca24c26bdd43f05537f3aa4f030342ea3be5cbbc9c29f5eb",
    "decode814.json": "674cc052e1f33f7707c1ed68b63f0e12dd67d096972792728e0d9dc691939fad",
    "mu814.py": "f37137dfdaa3b6171c1eeebbf693affec7178ae7a79f75dbecc5f0e4187e95dc",
    "mu814-original-1.json": "940233505f4b5ac6f013baedb7ceb34d60d73426c4e9ce54f64ddc5f242bc1a9",
    "mu814-original-tight.json": "30bfd70f4f1f74d93fa46564c0117484e62de8532875cb7da9e25624e098156a",
    "mu814-rebuilt-1.json": "538a254e1b91d95a165ad5d760dce3fd6e98908493f3dc7d49ae173781df0341",
    "mu814-rebuilt-tight.json": "e14e8841a599b3ebbf89dace16481168be132836622e2f56cae16581b5cef2fe",
    "common814.py": "2f0fe87b5e6269685cd1282bf05718d41f45db63d7bf72e0e24696f165dd0dfa",
    "common814.json": "8832b32907399816f30084aeb0e136cbfe78e805630f636317e1db4f09ee0156",
    "cover814.py": "6c02fd8af86253c66c28f38a8feca7ebeb75deef991b1c7c5ef95331f7156fb5",
    "cover814.json": "7b27073bf7ca32134790634bc70484838354fdf9b380e3d2f172599d55777ccc",
    "scales814.py": "2cc1a794f0f2e4a1461957e2e5d05313e7a2224e3b4dfbadcae4ee3ebc34a741",
    "scales814.json": "ec9104c4b7bba56bcdb57d210288c8321827c9546afd863aa660d3ab1c179c8b",
}
REBUILT_COMB_SHA = "42696dc8a5cb4bbf871500c4bfd66063a3853fcde4f00a0ba876fffa90469ae1"
ARCHIVE_NAMES = frozenset(FROZEN) | {"REPORT.tex", "replay814.py"}


def digest(data):
    return sha256(data).hexdigest()


def verify(path, expected):
    data = path.read_bytes()
    actual = digest(data)
    if actual != expected:
        raise ValueError(f"SHA-256 mismatch: {path.name}: {actual} != {expected}")
    return data


def runtime():
    return {
        "python": platform.python_version(),
        "architecture": platform.machine(),
        "numpy": version("numpy"),
        "scipy": version("scipy"),
        "sympy": version("sympy"),
        "python-flint": version("python-flint"),
    }


def main():
    if not __debug__:
        raise RuntimeError("The exact certificate checks require assertions to be enabled.")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--work", type=Path, required=True, help="fresh output directory")
    args = parser.parse_args()
    here = Path(__file__).resolve().parent
    files = {name: verify(here / name, expected) for name, expected in FROZEN.items()}
    manifest = here / "MANIFEST.json"
    if manifest.exists():
        archived = json.loads(manifest.read_bytes())
        members = archived["members"]
        if (archived["round"] != 814 or set(members) != ARCHIVE_NAMES
                or any(members[name] != value for name, value in FROZEN.items())
                or archived["rebuilt_comb811_sha256"] != REBUILT_COMB_SHA):
            raise ValueError("Archive manifest does not match the frozen round 814 inputs.")
        for name in ("REPORT.tex", "replay814.py"):
            verify(here / name, members[name])
    current = runtime()
    work = args.work.resolve()
    work.mkdir(exist_ok=False)
    for name, data in files.items():
        (work / name).write_bytes(data)
    outcomes = []

    def run(label, script, *arguments):
        print(f"Checking {label}", flush=True)
        subprocess.run([sys.executable, "-E", "-B", script, *arguments],
                       cwd=work, check=True)
        outcomes.append(label)

    run("round 811 continuous comb rebuild", "comb811.py", "--output", "comb811.json")
    verify(work / "comb811.json", REBUILT_COMB_SHA)
    run("wider comb and actual q-cell 95", "fixture814.py", "--comb", "comb811.json",
        "--rebuilt", "comb814-rebuilt.json", "--cell", "cell814.json")
    for model, fixture in (("original", "comb811.json"), ("rebuilt", "comb814-rebuilt.json")):
        for name, factor in (("1", "1"), ("tight", "1/1048576")):
            certificate = f"mu814-{model}-{name}.json"
            run(certificate, "mu814.py", "--comb", fixture, "--trade-dir", ".",
                "--factor", factor, "--out", certificate, "--check")
    run("shared right plan", "common814.py", "--comb", "comb811.json",
        "--previous-scripts", ".", "--check", "common814.json")
    run("finite covering prices", "cover814.py", "--comb", "comb811.json",
        "--rebuilt", "comb814-rebuilt.json", "--check", "cover814.json")
    run("exact and interval scale tests", "scales814.py", "--check", "scales814.json")
    run("both observed arms decoder", "decode814.py", "--r813-dir", ".",
        "--check", "decode814.json")
    for name, expected in FROZEN.items():
        verify(work / name, expected)
    receipt = {"round": 814, "verified": outcomes, "runtime": current,
               "rebuilt_comb811_sha256": REBUILT_COMB_SHA,
               "verified_members": {name: digest((here / name).read_bytes())
                                    for name in sorted(ARCHIVE_NAMES) if (here / name).exists()}}
    (work / "REPLAY.json").write_text(json.dumps(receipt, sort_keys=True, indent=2) + "\n")
    print(f"Verified {len(outcomes)} steps. Receipt: {work / 'REPLAY.json'}")


if __name__ == "__main__":
    main()
