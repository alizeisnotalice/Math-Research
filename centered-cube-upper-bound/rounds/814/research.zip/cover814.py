"""Fractional covers of the true left contacts at a fixed right source, with rational certificates."""
import argparse
from fractions import Fraction as F
from itertools import product
from pathlib import Path
import json
import platform
import numpy as np
from scipy.optimize import linprog

def total(values):
    return sum(values, F(0))

def certified_table(stage):
    parents = {p["id"]: p for p in stage["parents"]}
    masses = {int(c["mask"]): F(c["mass"]) for c in stage["cells"]}
    all_rows = {}
    for root in stage["roots_cross"]:
        t, u, g = (parents[root[name]] for name in ("t", "u", "g"))
        coefficient = F(t["j"])*F(u["j"])*F(g["j"])/(F(t["full_d"])*F(t["m"])**2*F(u["m"])*F(g["m"]))
        assert coefficient == F(root["coefficient"])
        assert all(F(1) <= F(p["radius"]) < F(2) for p in (t,u,g))
        contact = tuple(s for s in masses if (s & t["bit"]) and (s & u["bit"]))
        assert set(contact) == set(root["z_masks"])
        for q in root["q_masks"]:
            records = all_rows.setdefault(q, {})
            key = t["id"],u["id"]
            contribution = coefficient*masses[q]*total(masses[s] for s in contact)
            old = records.get(key, F(0))
            records[key] = old+contribution
    original = total(total(r.values()) for r in all_rows.values())
    assert original == F(stage["benchmarks"]["cross"]["mother"])
    def solve(q, raw):
        pairs = sorted(raw)
        covers = sorted(masses)
        target = []
        rows = []
        for t,u in pairs:
            flags = parents[t]["bit"] | parents[u]["bit"]
            incidence = [int((s & flags) == flags) for s in covers]
            req = total(masses[s]*v for s,v in zip(covers,incidence))/F(parents[t]["m"])
            assert req > 0 and any(incidence)
            rows.append(incidence)
            target.append(req)
        matrix = np.asarray(rows,dtype=float)
        opt = linprog(np.ones(len(covers)),A_ub=-matrix,b_ub=-np.asarray(target,dtype=float),bounds=(0,None),method="highs")
        assert opt.success, opt.message
        # Solve with exact tight rows in the proposed basis. Never infer exactness from simplex status.
        from sympy import Matrix, Rational
        def reconstruct(numbers, a, exact_rhs):
            support = [k for k,x in enumerate(numbers) if x>1e-11]
            result = [F(0)]*len(numbers)
            if not support:
                return result
            active = [j for j,(row,rhs) in enumerate(zip(a,exact_rhs))
                      if abs(sum(row[k]*numbers[k] for k in support)-float(rhs)) < 1e-8]
            m = Matrix([[a[j][k] for k in support] for j in active])
            independent = list(m.T.rref()[1])
            assert len(independent)==len(support)
            eqs = [active[j] for j in independent]
            m = Matrix([[a[j][k] for k in support] for j in eqs])
            b = Matrix([Rational(exact_rhs[j].numerator,exact_rhs[j].denominator) for j in eqs])
            for k,val in zip(support,m.inv()*b):
                result[k] = F(int(val.p),int(val.q))
            return result
        x = reconstruct(opt.x,rows,target)
        dual_rows = list(zip(*rows))
        y = reconstruct(-opt.ineqlin.marginals,dual_rows,[F(1)]*len(covers))
        assert all(v>=0 for v in x+y)
        assert all(total(a*b for a,b in zip(row,x))>=b for row,b in zip(rows,target))
        assert all(total(a*b for a,b in zip(row,y))<=1 for row in dual_rows)
        capacity = total(x)
        assert capacity==total(b*v for b,v in zip(target,y))
        private = total(target)
        # The direct density envelope pays all contacts on the original source, including overlaps.
        envelope = total(masses[s]*max([F(1)/F(parents[pairs[j][0]]["m"])
                                        for j in range(len(pairs)) if rows[j][k]] or [F(0)])
                         for k,s in enumerate(covers))
        assert capacity <= envelope and capacity <= private
        return dict(q=q,original=total(raw.values()),source_mass=masses[q],requests=len(pairs),
                    private=private,union_envelope=envelope,capacity=capacity,
                    primal_atoms={str(s):v for s,v in zip(covers,x) if v},
                    dual_packing=[(t,u,v) for (t,u),v in zip(pairs,y) if v],
                    demands=[(t,u,v) for (t,u),v in zip(pairs,target)])
    rows=[solve(q,r) for q,r in sorted(all_rows.items())]
    agg={k:total(row[k]*row["source_mass"] for row in rows)
         for k in ("private","union_envelope","capacity")}
    return dict(stage=stage["stage"],dimension=stage["dimension"],root_mass=original,rows=rows,
                integrated_over_true_q=agg,
                ratio_to_private=agg["capacity"]/agg["private"],
                ratio_to_envelope=agg["capacity"]/agg["union_envelope"])

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--comb",required=True,type=Path)
    parser.add_argument("--rebuilt",required=True,type=Path)
    group=parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--output",type=Path)
    group.add_argument("--check",type=Path)
    args=parser.parse_args()
    original=json.loads(args.comb.read_bytes())["stages"]
    wider=json.loads(args.rebuilt.read_bytes())["stages"][-1]
    result=dict(scope="Positive true-source membership cells, actual cross-bin witnesses in one physical octave, zero diagnostic long-jump threshold; finite pricing problem only.",
                stages=[certified_table(stage) for stage in original+[wider]])
    out=(json.dumps(result,indent=2,sort_keys=True,default=str)+"\n").encode()
    if args.check:
        old=json.loads(args.check.read_bytes())
        # Recompile the exact LP and compare optimal values and feasibility. Basis choices may vary between HiGHS versions.
        for a,b in zip(json.loads(out)["stages"],old["stages"],strict=True):
            for key in ("stage","root_mass","integrated_over_true_q","ratio_to_private","ratio_to_envelope"):
                assert a[key]==b[key]
            assert a["rows"]==b["rows"]
    else:
        args.output.write_bytes(out)
    for stage in result["stages"]:
        print(stage["stage"],len(stage["rows"]),float(stage["ratio_to_private"]),float(stage["ratio_to_envelope"]))
if __name__=="__main__":
    main()
