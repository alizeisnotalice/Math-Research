#!/usr/bin/env python3
"""Common one- and two-position auxiliary supply plans on true R812 comb peaks."""
import argparse
from collections import defaultdict
from fractions import Fraction as F
from hashlib import sha256
from itertools import combinations, product
import json
from math import prod
from pathlib import Path
import platform

ZERO=F(0)
ONE=F(1)
D_VALUES=(1,8,64,512)


def total(x):
    return sum(x,ZERO)


def box(P,key):
    return tuple(tuple(map(F,interval)) for interval in P[key])


def intersection(*boxes):
    return tuple((max(q[0] for q in axis),min(q[1] for q in axis)) for axis in zip(*boxes))


def volume(B):
    return prod(max(ZERO,b-a) for a,b in B)


def comb_mass(B,density):
    support=F(density["support"][1])
    period=F(density["period"])
    phase=F(density["bump_center_mod_period"])
    wide=F(density["bump_half_width"])
    base=F(density["density_floor_one_axis"])
    extra=F(density["density_peak_one_axis"])-base
    def integral(a,b):
        a,b=max(a,-support),min(b,support)
        if b<=a:
            return ZERO
        in_bumps=total(max(ZERO,min(b,k*period+phase+wide)-max(a,k*period+phase-wide))
                       for k in range(a//period,(b//period)+1))
        return base*(b-a)+extra*in_bumps
    return prod(integral(a,b) for a,b in B)


def source_law(stage):
    parents={p["id"]:p for p in stage["parents"]}
    supply=tuple(u for u,p in parents.items() if p["role"]=="old")
    bits={i:p["bit"] for i,p in parents.items()}
    cells={s["mask"]:F(s["mass"]) for s in stage["cells"]}
    auxmask=sum(bits[i] for i in supply)
    multiplicity=max((s&auxmask).bit_count() for s in cells)
    lam=F(1,multiplicity)
    a={i:lam*F(parents[i]["m"]) for i in supply}
    for i,p in parents.items():
        assert F(p["m"])==volume(box(p,"box"))==total(w for s,w in cells.items() if s&bits[i])
        if i in supply:
            assert all(F(p["m"])<=F(q["m"]) for q in parents.values() if q["role"]=="middle")
    assert all(lam*(s&auxmask).bit_count()<=1 for s in cells)
    assert all(volume(intersection(box(p,"owner"),box(q,"owner")))==0 for p,q in combinations(parents.values(),2))
    contacts,mark_law={},{}
    joint=defaultdict(F)
    independent=defaultdict(F)
    for e in stage["roots_cross"]:
        t,u,g=(e[k] for k in ("t","u","g"))
        T,U,G=(parents[k] for k in (t,u,g))
        coeff=F(T["j"])*F(U["j"])*F(G["j"])/(F(T["full_d"])*F(T["m"])**2*F(U["m"])*F(G["m"]))
        assert coeff==F(e["coefficient"]) and U["volume_bin"]!=G["volume_bin"]
        assert sum(map(F,e["sectors_00_01_10_11"]))==F(e["root_mass"])
        for small,masks in ((u,e["z_masks"]),(g,e["q_masks"])):
            needed=bits[small]|bits[t]
            assert masks==sorted(s for s in cells if s&needed==needed)
            if (t,small) not in mark_law:
                local=defaultdict(F)
                for s in masks:
                    live=[i for i in supply if s&bits[i]]
                    assert live
                    height=lam*len(live)
                    assert height<=1
                    for i in live:
                        local[i]+=cells[s]*lam/height
                for i,selected in local.items():
                    c=total(cells[s] for s in masks if s&bits[i])
                    exact=comb_mass(intersection(box(parents[i],"box"),box(T,"box"),
                                                 box(parents[small],"box")),stage["density"])
                    assert 0<selected<=c==exact
                    contacts[t,small,i]=c
                assert total(local.values())==total(cells[s] for s in masks)
                mark_law[t,small]=local
        left,right=mark_law[t,u],mark_law[t,g]
        z_mass,q_mass=total(left.values()),total(right.values())
        assert coeff*z_mass*q_mass==F(e["root_mass"])
        for (i,l),(j,r) in product(left.items(),right.items()):
            joint[(t,u,i),(t,g,j)]+=coeff*l*r
        for i,l in left.items():
            independent[t,u,i]+=coeff*l*q_mass
    raw=F(stage["benchmarks"]["cross"]["mother"])
    actual=defaultdict(F)
    for (x,y),w in joint.items():
        actual[x]+=w
        assert joint[y,x]==w
    assert dict(actual)==dict(independent) and total(actual.values())==total(joint.values())==raw
    return parents,supply,lam,a,contacts,dict(sorted(actual.items())),dict(joint),mark_law


def destination_model(parents,supply,a,contacts,mode):
    if mode=="supplier_boxes":
        names=supply
        sets={k:box(parents[k],"box") for k in names}
        caps={k:a[k] for k in names}
    else:
        names=tuple(parents)
        sets={k:box(parents[k],"owner") for k in names}
        caps={k:volume(sets[k]) for k in names}
        assert all(caps[k]==F(parents[k]["owner_volume"]) for k in names)
    expanded={t:box(p,"expanded_box") for t,p in parents.items()}
    point,split={},{}
    for t,u,i in contacts:
        point[t,u,i]={k:volume(intersection(sets[k],expanded[t],expanded[u]))/volume(sets[k]) for k in names}
        left={k:volume(intersection(sets[k],expanded[t]))/volume(sets[k]) for k in names}
        right={l:volume(intersection(sets[l],expanded[u]))/volume(sets[l]) for l in names}
        split[t,u,i]={(k,l):left[k]*right[l] for k,l in product(names,repeat=2)}
        assert all(0<=v<=1 for v in point[t,u,i].values()) and all(0<=v<=1 for v in split[t,u,i].values())
    return caps,point,split


def required_columns(supply,caps,events,coefs,arity):
    left=tuple(caps)
    possible=product(left,repeat=arity)
    dests=tuple(q[0] if arity==1 else q for q in possible)
    columns=[]
    for i,k in product(supply,dests):
        if not any(coefs[e][k]>0 for e in events if e[2]==i):
            continue
        columns.append((i,k) if arity==1 else (i,*k))
    return columns


def payoff(plan,a,caps,contacts,events,coefs,lam,D,arity):
    used=defaultdict(F)
    hit={e:ZERO for e in events}
    for key,w in plan.items():
        i,k,*later=key
        assert w>0 and i in a and k in caps and len(key)==arity+1
        used[0,i]+=w
        used[1,k]+=w
        idx=k
        if later:
            assert later[0] in caps
            used[2,later[0]]+=w
            idx=k,later[0]
        for e in events:
            if e[2]==i:
                hit[e]+=w*coefs[e][idx]/lam
    assert all(used[0,i]<=v for i,v in a.items())
    assert all(used[page,k]<=v for page in range(1,arity+1) for k,v in caps.items())
    p={e:min(ONE,D*hit[e]/contacts[e]) for e in events}
    return p,used


def weighted_rates(p,events,joint):
    M=total(events.values())
    one=total(events[e]*v for e,v in p.items())
    separate=total(w*p[e]*p[f] for (e,f),w in joint.items())
    same=total(w*min(p[e],p[f]) for (e,f),w in joint.items())
    assert 0<=separate<=same<=one<=M
    return dict(one_side=one/M,both_separate_coins=separate/M,both_shared_coin=same/M)


def dual_value(column_keys,a,caps,contacts,events,coefs,lam,D,arity,delta,dest_prices):
    assert set(delta)==set(events) and all(0<=v<=events[e] for e,v in delta.items())
    assert len(dest_prices)==arity and all(
        set(m)==set(caps) and all(x>=0 for x in m.values()) for m in dest_prices)
    phi={i:ZERO for i in a}
    for col in column_keys:
        i,ds=col[0],col[1:]
        idx=ds[0] if arity==1 else ds
        column_gain=total(v*D*coefs[e][idx]/(lam*contacts[e]) for e,v in delta.items() if e[2]==i)
        give=total(dest_prices[s][k] for s,k in enumerate(ds))
        phi[i]=max(phi[i],column_gain-give)
    value=total(a[i]*v for i,v in phi.items())
    value+=total(caps[k]*d for prices in dest_prices for k,d in prices.items())
    value+=total(w-delta[e] for e,w in events.items())
    return value


def solve_candidate(columns,a,caps,contacts,events,coefs,lam,D,arity):
    import numpy as np
    import scipy
    from scipy.optimize import linprog
    from scipy.sparse import coo_matrix

    sides=[(0,i) for i in a]+[(p,k) for p in range(1,arity+1) for k in caps]
    event_ids=tuple(events)
    position={k:j for j,k in enumerate(sides)}
    ceiling={(0,i):v for i,v in a.items()}
    ceiling.update({(q,k):v for q in range(1,arity+1) for k,v in caps.items()})
    costs=[0.]*len(columns)+[-float(events[e]/total(events.values())) for e in event_ids]
    ai,aj,av=[],[],[]
    scales=[]
    for j,col in enumerate(columns):
        i,ds=col[0],col[1:]
        used=[(0,i)]+[(p,k) for p,k in enumerate(ds,1)]
        scale=min(ceiling[k] for k in used)
        scales.append(scale)
        for k in used:
            ai.append(position[k]); aj.append(j); av.append(float(scale/ceiling[k]))
        ix=ds[0] if arity==1 else ds
        for k,e in enumerate(event_ids):
            if e[2]==i and coefs[e][ix]:
                ai.append(len(sides)+k); aj.append(j)
                av.append(-float(D*scale*coefs[e][ix]/(lam*contacts[e])))
    for j,e in enumerate(event_ids):
        ai.append(len(sides)+j); aj.append(len(columns)+j); av.append(1.)
    A=coo_matrix((av,(ai,aj)),shape=(len(sides)+len(event_ids),len(costs))).tocsr()
    rhs=np.r_[np.ones(len(sides)),np.zeros(len(event_ids))]
    bounds=[(0,None)]*len(columns)+[(0,1)]*len(event_ids)
    result=linprog(costs,A_ub=A,b_ub=rhs,bounds=bounds,method="highs",
                   options={"primal_feasibility_tolerance":1e-10,"dual_feasibility_tolerance":1e-10})
    assert result.success
    draft={col:s*F(float(v)).limit_denominator(10**12)
           for col,s,v in zip(columns,scales,result.x) if v>0}
    draft={col:v for col,v in draft.items() if v>0}
    used=defaultdict(F)
    for (i,*ds),w in draft.items():
        used[0,i]+=w
        for page,k in enumerate(ds,1):
            used[page,k]+=w
    shrink=max(ONE,max(used[k]/cap for k,cap in ceiling.items()))
    feasible={col:w/shrink for col,w in draft.items()}
    M=total(events.values())
    shadow=[F(max(0.,float(x)))*M for x in -result.ineqlin.marginals]
    delta={e:min(events[e],shadow[len(sides)+j]) for j,e in enumerate(event_ids)}
    target_prices=[{k:shadow[position[page,k]]/caps[k] for k in caps} for page in range(1,arity+1)]
    return feasible,delta,target_prices,scipy.__version__


def experiment(a,caps,contacts,events,joint,coefs,lam,D,arity,mode,saved):
    columns=required_columns(tuple(a),caps,events,coefs,arity)
    baseline={((i,i) if arity==1 else (i,i,i)):w for i,w in a.items()} if mode=="supplier_boxes" else {}
    p,_=payoff(baseline,a,caps,contacts,events,coefs,lam,D,arity)
    diagonal=weighted_rates(p,events,joint)
    if saved is not None:
        h=saved["certificate"]
        plan={tuple(row[:-1]):F(row[-1]) for row in h["positive_moves"]}
        delta={tuple(row[:-1]):F(row[-1]) for row in h["event_slopes"]}
        prices=[{k:F(v) for k,v in row.items()} for row in h["target_prices"]]
        solver_version=saved["proposal_scipy"]
    elif columns and diagonal["one_side"]<1:
        plan,delta,prices,solver_version=solve_candidate(columns,a,caps,contacts,events,coefs,lam,D,arity)
    else:
        plan=baseline if columns else {}
        delta={e:(ZERO if columns else w) for e,w in events.items()}
        prices=[{k:ZERO for k in caps} for _ in range(arity)]
        solver_version=None
    cand,_=payoff(plan,a,caps,contacts,events,coefs,lam,D,arity)
    rates=weighted_rates(cand,events,joint)
    # The fixed Lebesgue baseline is feasible on both pages for real supplier boxes.
    if rates["one_side"]<diagonal["one_side"]:
        plan,rates=baseline,diagonal
    ub=min(ONE,dual_value(columns,a,caps,contacts,events,coefs,lam,D,arity,delta,prices)/total(events.values()))
    assert diagonal["one_side"]<=rates["one_side"]<=ub
    witness=None
    if mode=="true_receiving_owners" and arity==2:
        choices=[]
        for (i,k,l),v in plan.items():
            for e in events:
                if e[2]==i and coefs[e][k,l]:
                    fraction=min(ONE,D*v*coefs[e][k,l]/(lam*contacts[e]))
                    choices.append((events[e]*fraction,e,k,l,v,fraction))
        if choices:
            _,e,k,l,v,fraction=max(choices)
            witness=dict(event=e,targets=[k,l],physical_move=v,true_contact=contacts[e],
                         conditional_fraction_from_move_alone=fraction)
    return dict(destination_family=mode,count_distinct_positions=arity,positive_variable_count=len(columns),
                fixed_supplier_Lebesgue_rates=diagonal,shared_flow_rates=rates,
                shared_flow_upper_one_side=ub,one_side_certified_gap=ub-rates["one_side"],
                one_side_certified_gain_over_fixed=rates["one_side"]-diagonal["one_side"], positive_owner_witness=witness,
                proposal_scipy=solver_version,certificate=dict(positive_moves=[[*k,v] for k,v in sorted(plan.items())],
                event_slopes=[[*e,v] for e,v in sorted(delta.items())],target_prices=prices))


def stage_check(stage,old):
    parents,supply,lam,a,c,events,joint,mark_law=source_law(stage)
    ready={mode:destination_model(parents,supply,a,c,mode) for mode in ("supplier_boxes","true_receiving_owners")}
    old_cases={} if old is None else {d["D"]:d for d in old["D_tests"]}
    tests=[]
    for D in D_VALUES:
        report={}
        for mode,(caps,point,split) in ready.items():
            for arity,coefs in enumerate((point,split),1):
                name=mode+("_same_point" if arity==1 else "_two_positions")
                previous=old_cases.get(D,{}).get("plans",{}).get(name)
                report[name]=experiment(a,caps,c,events,joint,coefs,lam,D,arity,mode,previous)
        assert report["true_receiving_owners_same_point"]["shared_flow_upper_one_side"]==0
        assert report["true_receiving_owners_two_positions"]["shared_flow_rates"]["one_side"]>0
        tests.append(dict(D=D,plans=report))
    return dict(dimension=stage["dimension"],law="cross",original_Gamma=total(events.values()),
                true_original_pair_count=len(joint),supply_weight=lam,max_old_parent_multiplicity=int(1/lam),
                supply_budget=a,owner_budgets=ready["true_receiving_owners"][0],
                contact_and_event_data=[dict(t=t,u=u,i=i,true_contact=c[t,u,i],selected_source_mass=mark_law[t,u][i],
                                             original_marginal_Gamma=events[t,u,i]) for t,u,i in sorted(c)],
                D_tests=tests)


def certificate(path,saved):
    original=json.loads(path.read_text())
    past={} if saved is None else {s["dimension"]:s for s in saved["stages"]}
    return dict(runtime={"python":platform.python_version(),"architecture":platform.machine()},
                input_sha256=sha256(path.read_bytes()).hexdigest(),D_values=D_VALUES,
                source_reference="A_i star is A_i for the actual old parents. A price selects a containing i with weight lambda_i/F(z), where lambda_i is the reciprocal of the global multiplicity. The payment uses the unthinned true triple contact c_tui, separate from this mark weight.",
                routing="For same-point routes sigma_i mixes uniform Lebesgue distributions on the displayed physical destinations. Split routes use uniform products on destination pairs. Each i spends at most lambda_i m_i; each side has a separate common target ledger. The two-slot rates use the original cross-bin root, with independent or common final acceptance marks as labeled.",
                zero_baseline_owners="The fixed supplier-box Lebesgue plan belongs to the supplier-box target family. The baseline entry in owner-budget scenarios denotes the zero feasible plan under those separate constraints.",
                proof="HiGHS supplies a proposal, rounded and shrunk under exact source and target capacities. Rational event slopes and nonnegative destination prices give a certified dual bound. Replay verifies the stored witnesses without HiGHS.",
                scope="Finite true two-, three-, and four-dimensional continuous comb models, with G=A and B the fixed expanded parents; these examples do not certify the general high-dimensional gate.",
                replay="python -B trade813.py --comb <comb811.json> --check trade813.json",
                stages=[stage_check(s,past.get(s["dimension"])) for s in original["stages"]])


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--comb",type=Path,required=True)
    mode=parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--output",type=Path)
    mode.add_argument("--check",type=Path)
    args=parser.parse_args()
    old=json.loads(args.check.read_text()) if args.check else None
    data=certificate(args.comb,old)
    text=(json.dumps(data,default=str,indent=2,sort_keys=True)+"\n").encode()
    if args.output:
        args.output.write_bytes(text)
    else:
        assert args.check.read_bytes()==text
    for d in data["stages"]:
        for s in d["D_tests"]:
            print(d["dimension"],s["D"],[(name,*(f"{float(p[k]['one_side']):.9g}" for k in
                                                   ("fixed_supplier_Lebesgue_rates","shared_flow_rates")),
                                                    f"{float(p['one_side_certified_gap']):.3g}") for name,p in s["plans"].items()])
    if args.check:
        print("byte-identical rational certificate replay")


if __name__=="__main__":
    main()
