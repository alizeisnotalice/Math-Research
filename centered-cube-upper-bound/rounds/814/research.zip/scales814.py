"""Exact and interval checks for the two distinct central scale sums."""
from fractions import Fraction as F
from math import comb
from pathlib import Path
import argparse
import json
import flint
from flint import arb,ctx

def geometry():
    # Exact trapezoidal integration between all breaks of the two piecewise linear lengths.
    def length(w,alpha):
        return max(F(0),F(1)-max(abs(w)-alpha,F(0))/2)
    rows=[]
    for alpha in (F(1,4),F(1,2),F(1)):
        for delta in (F(0),F(1,4),F(2,3),F(1)):
            cuts=sorted({F(0),alpha,alpha+2*(1-delta),alpha+2})
            def integrate(cap):
                return sum((y-x)*(min(cap,length(x,alpha))+min(cap,length(y,alpha)))/2 for x,y in zip(cuts,cuts[1:]))
            a,b=integrate(delta),integrate(F(1))
            assert a==delta*(2+alpha-delta) and b==1+alpha
            rows.append([str(alpha),str(delta),str(a),str(b)])
    # Markov e-tilt parameter 1/32 for at most n/20 errors and alpha<=1.
    assert 2*373**4*8**4 < (7*512)**4
    tails=[]
    for n in (4,20,64,128,512):
        k=n//20
        v=sum(F(comb(n,j)*21**j*11**(n-j),16**n) for j in range(k+1))
        assert v<=(F(7,8)**n)
        tails.append([n,k,float(v),float((F(7,8)**n))])
    return dict(piecewise_integrals=rows, exact_integer_sign=(7*512)**4-2*373**4*8**4, exact_binomial=tails)

def scale_tests(bits):
    ctx.prec=bits
    out=[]
    for n in (64,256,1024):
        log2=arb(2).log()
        # Physical radius R=1, side s_d=(2D)^(1/n) h0 for D=2^(n+j), j=0,...,n-1.
        # A nonzero diagnostic price jump d=sqrt(n)log(n+2); this is not the original b0 threshold.
        h0=1+arb(1)/(32*n)
        ell=arb(n+2).log()
        dist=arb(n).sqrt()*ell
        maxs=4*h0
        def endpoint(j):
            return 2*h0*(log2*(j+1)/n).exp()
        for pattern in ("spread","half_axes"):
            active=n if pattern=="spread" else n//2
            a=dist/active
            terms=[]
            for j in range(n):
                delta=1-a/endpoint(j)
                assert delta>0
                terms.append(delta**active)
            ratio=sum(terms,arb(0))/terms[-1]
            bound=1/(-( -dist*log2/(n*maxs)).expm1())
            assert ratio<bound and terms[-1]<(-dist/maxs).exp()
            m=10**7
            def bracket(x):
                lo=int((x*m).lower().floor().unique_fmpz())
                hi=int((x*m).upper().ceil().unique_fmpz())
                return [lo,hi]
            out.append(dict(n=n,shape=pattern,ratio=bracket(ratio),upper=bracket(bound),denominator=m))
    return out

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    group=parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--output",type=Path)
    group.add_argument("--check",type=Path)
    a=parser.parse_args()
    one=scale_tests(192)
    assert one==scale_tests(384)
    result=dict(cube=geometry(),scale=one,precision_bits=[192,384],flint=flint.__version__)
    data=(json.dumps(result,indent=2,sort_keys=True)+"\n").encode()
    if a.output: a.output.write_bytes(data)
    else: assert a.check.read_bytes()==data
    print("12 rational piecewise integrals, 5 exact tails and 6 scale sums at both precisions")
if __name__=="__main__":
    main()
