#!/usr/bin/env python3
"""Exact central-label posterior with the original one-arm and two-arm observations."""
import argparse
from collections import defaultdict
from fractions import Fraction as F
from hashlib import sha256
from itertools import product
import json
from pathlib import Path
import platform

ZERO=F(0)
ONE=F(1)


def total(v):
    return sum(v,ZERO)


def box_volume(box):
    w=ONE
    for lo,hi in box:
        w*=F(hi)-F(lo)
    return w


def build_geometry(stage):
    parents={p["id"]:p for p in stage["parents"]}
    middle={t for t,p in parents.items() if p["role"]=="middle"}
    old={u for u,p in parents.items() if p["role"]=="old"}
    mu={c["mask"]:F(c["mass"]) for c in stage["cells"]}
    bits={i:p["bit"] for i,p in parents.items()}
    b={i:F(p["j"])/F(p["m"]) for i,p in parents.items()}
    full_d={}
    exact_arms={}
    candidate={}
    for t in sorted(middle):
        m=F(parents[t]["m"])
        H={u:total(w for z,w in mu.items() if z&bits[t] and z&bits[u]) for u in parents}
        assert H[t]==m
        deg=total(b[u]*h/m for u,h in H.items() if u!=t)
        assert deg==F(parents[t]["full_d"])==F(stage["degrees"][t]["full_d"])
        full_d[t]=deg
        arms={u:{z:w for z,w in mu.items() if z&bits[t] and z&bits[u]}
              for u in old if F(parents[u]["radius"])<F(parents[t]["radius"]) and H[u]>0}
        assert set(arms)==set(stage["degrees"][t]["old_terms"])
        for u,z in arms.items():
            assert total(z.values())==H[u] and b[u]*H[u]/m==F(stage["degrees"][t]["old_terms"][u])
        exact_arms[t]=arms
        candidate[t]=[(u,g) for u,g in product(sorted(arms),repeat=2)
                      if parents[u]["volume_bin"]!=parents[g]["volume_bin"]]
    for u in sorted(old):
        p=parents[u]
        assert all(box_volume(H)*2==F(p["owner_volume"]) for H in p["owner_halves"])
    return parents,bits,mu,b,full_d,exact_arms,candidate


def reconstruct(stage,parents,bits,mu,b,full_d,arms,eligible):
    # One construction from frozen true roots, one from independently rebuilt physical arms.
    frozen=defaultdict(lambda:defaultdict(F))
    all_coef={}
    for e in stage["roots_cross"]:
        t,u,g=(e[k] for k in ("t","u","g"))
        d=parents[t]["volume_bin"]
        c=F(e["coefficient"])
        a,b0=tuple(e["z_masks"]),tuple(e["q_masks"])
        mother=c*total(mu[z] for z in a)*total(mu[q] for q in b0)
        assert mother==F(e["root_mass"]) and all(F(x)*4==mother for x in e["sectors_00_01_10_11"])
        assert set(a)==set(arms[t][u]) and set(b0)==set(arms[t][g])
        all_coef[t,u,g]=c
        for z,q in product(a,b0):
            frozen[u,g,d,z,q][t]+=c*mu[z]*mu[q]
    again=defaultdict(dict)
    want_coef={}
    for t,pairs in eligible.items():
        T=parents[t]
        d=T["volume_bin"]
        for u,g in pairs:
            c=F(T["j"])*b[u]*b[g]/(full_d[t]*F(T["m"])**2)
            want_coef[t,u,g]=c
            for (z,v),(q,w) in product(arms[t][u].items(),arms[t][g].items()):
                assert z&bits[u] and q&bits[g]
                again[u,g,d,z,q][t]=c*v*w
    assert dict(frozen)==dict(again) and all_coef==want_coef
    M=total(total(row.values()) for row in frozen.values())
    assert M==F(stage["benchmarks"]["cross"]["mother"])
    return dict(frozen),all_coef,M


def accumulate(by_key,key,count):
    for t,w in count.items():
        by_key[key][t]+=w


def collapse(fine,allowed,coef,parents,bits,mu):
    left_pool=defaultdict(int)
    both_pool=defaultdict(int)
    for t,edges in allowed.items():
        d=parents[t]["volume_bin"]
        for u,g in edges:
            left_pool[u,d]|=bits[t]
            both_pool[u,g,d]|=bits[t]
    left,both=defaultdict(lambda:defaultdict(F)),defaultdict(lambda:defaultdict(F))
    left_fine=defaultdict(lambda:defaultdict(F))
    full_base,left_base=defaultdict(F),defaultdict(F)
    left_profile={}
    full_profile={}
    links={}
    n_fine=defaultdict(int)
    for key,w in fine.items():
        u,g,d,z,q=key
        L=u,d,z&left_pool[u,d]
        R=u,g,d,z&q&both_pool[u,g,d]
        subtotal=mu[z]*mu[q]
        assert set(w)=={t for t in allowed if R[3]&bits[t]}
        density={t:v/subtotal for t,v in w.items()}
        assert density=={t:coef[t,u,g] for t in w}
        if R in full_profile:
            assert density==full_profile[R]
        full_profile[R]=density
        full_base[R]+=subtotal
        links[key]=(L,R)
        accumulate(left_fine,(u,d,z),w)
        accumulate(both,R,w)
    for (u,d,z),w in left_fine.items():
        L=u,d,z&left_pool[u,d]
        density={t:v/mu[z] for t,v in w.items()}
        assert set(density)=={t for t in allowed if L[2]&bits[t]}
        if L in left_profile:
            assert density==left_profile[L]
        left_profile[L]=density
        left_base[L]+=mu[z]
        n_fine[L]+=1
        accumulate(left,L,w)
    assert all({t:v*left_base[key] for t,v in p.items()}==left[key] for key,p in left_profile.items())
    assert all({t:v*full_base[key] for t,v in p.items()}==both[key] for key,p in full_profile.items())
    return left,both,left_base,full_base,links,n_fine


def compare_info(left,left_base,n_fine,old):
    reported={(x["u"],x["d"],x["own_price_middle_mask"]):x for x in old["all_conditioning_rows"]}
    assert set(reported)==set(left)
    for key,value in left.items():
        rec=reported[key]
        assert left_base[key]==F(rec["true_mu_of_conditioning_cell"])
        assert total(value.values())==F(rec["mass"])
        assert set(value)==set(rec["middle_parents"]) and n_fine[key]==rec["fine_masks_merged"]


def rates(rows,base,M):
    out=[]
    top1,top2,disagree,multi=ZERO,ZERO,ZERO,ZERO
    assert total(total(v.values()) for v in rows.values())==M
    for key,w in sorted(rows.items()):
        Z=total(w.values())
        nz=sorted(w.items(),key=lambda item:(-item[1],item[0]))
        p=tuple((t,x/Z) for t,x in nz)
        c1=p[0][1]
        c2=total(x for _,x in p[:2])
        diff=ONE-total(x*x for _,x in p)
        assert 0<=diff<=1 and total(x for _,x in p)==1
        top1+=Z*c1
        top2+=Z*c2
        disagree+=Z*diff
        if len(p)>1:
            multi+=Z
        out.append(dict(observation=key,original_mass=Z,true_price_reference_mass=base[key],
                        posterior=p,top1=c1,top2=c2,two_posterior_draws_different=diff))
    return dict(conditional_cells=len(out),multiple_middle_cells=sum(len(x["posterior"])>1 for x in out),
                original_mass_fraction_on_multiple_middle_cells=multi/M,
                top1_success=top1/M,top2_success=top2/M,independent_replica_disagreement=disagree/M,
                all_exact_rows=out)


def linf(a,b):
    return max(abs(F(x)-F(y)) for x,y in zip(a,b))


def spatial(fine,left,both,links,eligible,parents,bits,M):
    Lside=defaultdict(F)
    Rside=defaultdict(F)
    eligible={t:set(L) for t,L in eligible.items()}
    far_L,far_R=ZERO,ZERO
    labels=tuple(sorted(eligible))
    dist={(t,s):linf(parents[t]["center"],parents[s]["center"]) for t,s in product(labels,repeat=2)}
    witness=None
    maximum=ZERO
    for key,w in fine.items():
        L,R=links[key]
        u,g,d,z,q=key
        pool=left[L]
        root_mass=total(w.values())
        den=total(pool.values())
        tv_halved=total(abs(w.get(s,ZERO)/root_mass-x/den) for s,x in pool.items())/2
        if tv_halved>maximum:
            maximum=tv_halved
            witness=dict(fine_true_observation=[u,g,d,z,q],before=tuple((s,x/den) for s,x in sorted(pool.items())),
                         after=tuple((s,x/root_mass) for s,x in sorted(w.items())),
                         original_mass=root_mass,total_variation=tv_halved)
        for (t,m),(s,k) in product(w.items(),pool.items()):
            weight=m*k/den
            if s==t:
                reason="same_central"
            elif not q&bits[s]:
                reason="different_and_actual_q_outside_competing_middle"
            elif (u,g) not in eligible[s]:
                reason="different_and_q_inside_but_original_pair_ineligible"
            else:
                reason="different_and_physically_and_label_compatible"
            Lside[reason]+=weight
            far_L+=weight*dist[t,s]
        alt=both[R]
        alt_den=total(alt.values())
        for (t,m),(s,k) in product(w.items(),alt.items()):
            assert q&bits[s] and z&bits[s] and (u,g) in eligible[s]
            Rside["same_central" if t==s else "different_and_physically_and_label_compatible"]+=m*k/alt_den
            far_R+=m*k/alt_den*dist[t,s]
    assert total(Lside.values())==total(Rside.values())==M
    return dict(independent_central_draws_using_left_then_testing_true_right={k:w/M for k,w in Lside.items()},
                independent_central_draws_after_both={k:w/M for k,w in Rside.items()},
                expected_center_separation_linf_before=far_L/M,expected_center_separation_linf_after=far_R/M,
                maximum_true_posterior_shift=witness)


def example(stage,info):
    parents,bits,mu,b,degree,arms,eligible=build_geometry(stage)
    fine,coef,M=reconstruct(stage,parents,bits,mu,b,degree,arms,eligible)
    L,R,lbase,rbase,links,count=collapse(fine,eligible,coef,parents,bits,mu)
    assert M==F(info["original_Gamma"])
    compare_info(L,lbase,count,info)
    pre,post=rates(L,lbase,M),rates(R,rbase,M)
    d1=post["top1_success"]-pre["top1_success"]
    d2=post["top2_success"]-pre["top2_success"]
    assert d1>=0 and d2>=0 and pre["independent_replica_disagreement"]>=post["independent_replica_disagreement"]
    where=spatial(fine,L,R,links,eligible,parents,bits,M)
    a,b=(where[k] for k in ("independent_central_draws_using_left_then_testing_true_right",
                             "independent_central_draws_after_both"))
    assert pre["independent_replica_disagreement"]==ONE-a.get("same_central",ZERO)
    assert post["independent_replica_disagreement"]==ONE-b.get("same_central",ZERO)
    return dict(dimension=stage["dimension"],original_Gamma=M,fine_actual_two_price_cell_rows=len(fine),
                original_full_middle_degree=degree,before_full_left=pre,after_both_full_arms=post,
                top1_gain=d1,top2_gain=d2,space_mismatch_using_original_right=where)


def audit(root):
    true_file=root/"comb811.json"
    info_file=root/"info813.json"
    comb=json.loads(true_file.read_text())
    info=json.loads(info_file.read_text())
    assert sha256(true_file.read_bytes()).hexdigest()==info["inputs_sha256"]["comb811.json"]
    stages=info["examples"]
    examples=[example(d,s) for d,s in zip(comb["stages"],stages,strict=True)]
    return dict(runtime={"python":platform.python_version(),"architecture":platform.machine()},
                input_sha256={p.name:sha256(p.read_bytes()).hexdigest() for p in (true_file,info_file)},
                scope="Three finite calibrated continuous comb fixtures in 2, 3 and 4 dimensions. Both old arms follow the original cross-bin list, with full degree, both original prices and the actual receiver probe laws. No extra distance gate is used.",
                left_condition="Given u, z, U and the absolute middle volume bin, t weights share the conditional uniform actual E_u probe law. Only z membership in genuinely eligible mid parents in the bin is relevant. The reduced true observation cells agree with the frozen info813 certificate.",
                two_arm_condition="Given both fully observed old arms, all atomic tables share the actual E_u and E_g probe laws. Both actual price memberships are retained through the mask of joint eligible middle parents. Exact constant profiles on every finer original atom pair make this mask sufficient for the posterior.",
                mismatch="A competing label is drawn from the same true conditional posterior. Spatial failures test the original right price q against the competitor parent while holding the original old label and actual receiver probe. Center separations use actual parent centers.",
                arithmetic="Exact rational throughout. Original root expansion equals the independent geometry reconstruction, and posterior mismatches are verified again by routing all fine observations.",
                replay="python -B decode814.py --r813-dir <verified-output> --check decode814.json",
                examples=examples)


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--r813-dir",required=True,type=Path)
    modes=p.add_mutually_exclusive_group(required=True)
    modes.add_argument("--output",type=Path)
    modes.add_argument("--check",type=Path)
    args=p.parse_args()
    data=audit(args.r813_dir)
    text=(json.dumps(data,default=str,sort_keys=True,indent=2)+"\n").encode()
    if args.output:
        args.output.write_bytes(text)
    else:
        assert args.check.read_bytes()==text
    for item in data["examples"]:
        numeric=lambda x:f"{float(x):.10g}"
        print(item["dimension"],"fine",item["fine_actual_two_price_cell_rows"],
              "L,R",[(name,row["conditional_cells"],*(numeric(row[k]) for k in
                     ("top1_success","top2_success","independent_replica_disagreement")))
                     for name,row in (("L",item["before_full_left"]),("LR",item["after_both_full_arms"]))])
        local=item["space_mismatch_using_original_right"]["independent_central_draws_using_left_then_testing_true_right"]
        print("  true right mismatch",[(k,numeric(v)) for k,v in sorted(local.items())])
    if args.check:
        print("byte-identical rational replay")


if __name__=="__main__":
    main()
