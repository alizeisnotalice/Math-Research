#!/usr/bin/env python3
"""Replay a single shared-right-source plan on the continuous comb811 cross-bin records."""
import argparse
from collections import defaultdict
from fractions import Fraction as F
from functools import lru_cache
from hashlib import sha256
from itertools import combinations
import json
from math import prod
from pathlib import Path
import runpy

ZERO, ONE = F(0), F(1)
FACTORS = (1, 8, 64, 512)


def total(values):
    return sum(values, ZERO)


def box(item):
    return tuple(tuple(map(F, axis)) for axis in item)


def intersect(*boxes):
    return tuple((max(interval[0] for interval in axis),
                  min(interval[1] for interval in axis)) for axis in zip(*boxes))


def volume(bounds):
    return prod((max(ZERO, b - a) for a, b in bounds), start=ONE)


def dilated(parent, factor):
    half = factor * F(parent["radius"])
    return tuple((F(c) - half, F(c) + half) for c in parent["center"])


def comb_mass(bounds, density):
    left, right = map(F, density["support"])
    period = F(density["period"])
    phase = F(density["bump_center_mod_period"])
    half = F(density["bump_half_width"])
    base = F(density["density_floor_one_axis"])
    extra = F(density["density_peak_one_axis"]) - base

    def one_dim(lo, hi):
        lo, hi = max(lo, left), min(hi, right)
        if lo >= hi:
            return ZERO
        bumps = total(max(ZERO, min(hi, k*period+phase+half) - max(lo, k*period+phase-half))
                      for k in range(lo//period - 1, hi//period + 2))
        return base*(hi-lo) + extra*bumps

    return prod((one_dim(lo, hi) for lo, hi in bounds), start=ONE)


def fixture(stage, all_fixture_degree, old_trade):
    n = stage["dimension"]
    assert n in (2, 3, 4)
    p = {x["id"]: x for x in stage["parents"]}
    old = sorted(i for i in p if p[i]["role"] == "old")
    middle = sorted(i for i in p if p[i]["role"] == "middle")
    bits = {i: x["bit"] for i, x in p.items()}
    prices = {x["mask"]: F(x["mass"]) for x in stage["cells"]}
    assert all(m > 0 for m in prices.values())
    cubes = {i: box(x["box"]) for i, x in p.items()}
    owners = {i: box(x["owner"]) for i, x in p.items()}
    m = {i: F(x["m"]) for i, x in p.items()}
    j = {i: F(x["j"]) for i, x in p.items()}
    owner_capacity = {i: volume(owners[i]) for i in old}

    for i in p:
        assert volume(cubes[i]) == comb_mass(cubes[i], stage["density"]) == m[i]
        assert total(amount for mask, amount in prices.items() if mask & bits[i]) == m[i]
        assert volume(owners[i]) == F(p[i]["owner_volume"])
        assert all(2*volume(box(half)) == volume(owners[i]) for half in p[i]["owner_halves"])
    assert all(volume(intersect(owners[a], owners[b])) == ZERO for a, b in combinations(p, 2))
    # Calculate the continuous (Lebesgue-a.e.) packing cap independently from the price masks.
    mult = max(len(subset) for k in range(1, len(old)+1) for subset in combinations(old, k)
               if volume(intersect(*(cubes[i] for i in subset))) > 0)
    live = {z: tuple(i for i in old if z & bits[i]) for z in prices}
    assert mult == max(map(len, live.values()))
    lam = ONE / mult
    cover = {z: lam*len(suppliers) for z, suppliers in live.items()}
    tags = {z: {i: ONE/len(suppliers) for i in suppliers} for z, suppliers in live.items() if suppliers}
    supply_capacity = {i: m[i] for i in old}
    assert all(0 <= value <= 1 for value in cover.values())
    for z in tags:
        assert total(tags[z].values()) == 1
        assert all(w == lam/cover[z] for w in tags[z].values())

    @lru_cache(None)
    def contact(t, u, i):
        need = bits[t] | bits[u] | bits[i]
        value = total(v for z, v in prices.items() if z & need == need)
        assert value == comb_mass(intersect(cubes[t], cubes[u], cubes[i]), stage["density"])
        return value

    full_d = {}
    for t in middle:
        value = ZERO
        for k in p:
            if k != t:
                overlap = total(amount for z, amount in prices.items() if z & bits[t] and z & bits[k])
                value += (j[k]/m[k])*overlap/m[t]
        assert value == F(p[t]["full_d"]) == F(stage["degrees"][t]["full_d"]) and value > 0
        full_d[t] = value

    rows = defaultdict(lambda: defaultdict(F))
    for root in stage["roots_cross"]:
        t, u, g = (root[k] for k in ("t", "u", "g"))
        coef = j[t]*(j[u]/m[u])*(j[g]/m[g])/(full_d[t]*m[t]**2)
        assert coef == F(root["coefficient"])
        assert p[u]["volume_bin"] != p[g]["volume_bin"]
        zz = [z for z in prices if z & bits[t] and z & bits[u]]
        qq = [q for q in prices if q & bits[t] and q & bits[g]]
        assert sorted(zz) == root["z_masks"] and sorted(qq) == root["q_masks"]
        actual = coef*total(prices[z] for z in zz)*total(prices[q] for q in qq)
        assert actual == F(root["root_mass"])
        assert all(4*F(w) == actual for w in root["sectors_00_01_10_11"])
        for q in qq:
            for z in zz:
                rows[q][t, u, g, z] += coef*prices[q]*prices[z]
    mass = {q: total(row.values()) for q, row in rows.items()}
    raw = total(mass.values())
    assert raw == F(stage["benchmarks"]["cross"]["mother"])

    # Given the actual continuous r in source membership cell q, the conditional law
    # is constant across the cell. Z is drawn from the normalized true source in z.
    # The two genuine receiver positions are independent uniform within their owners
    # once the sampled original root is fixed.
    pair_load = defaultdict(F)
    before_u = defaultdict(F)
    before_w = defaultdict(F)
    for q, row in rows.items():
        for (_, a, b, _), w in row.items():
            used = prices[q]*cover[q]*w/mass[q]
            pair_load[a, b] += used
            before_u[a] += used
            before_w[b] += used
    throttle = {(a, b): min(ONE, owner_capacity[a]/before_u[a], owner_capacity[b]/before_w[b])
                for a, b in pair_load}

    left = defaultdict(F)
    right = defaultdict(F)
    supply = defaultdict(F)
    q_receipts = []
    for q, row in sorted(rows.items()):
        columns = []
        q_mass = ZERO
        for (t, a, b, z), w in sorted(row.items()):
            baseline = w/mass[q]
            kept = baseline*throttle[a, b]
            if kept:
                columns.append([t, a, b, z, baseline, kept])
            used = prices[q]*cover[q]*kept
            left[a] += used
            right[b] += used
            q_mass += used
            for supplier in live[q]:
                supply[supplier] += prices[q]*kept
        assert q_mass <= prices[q]*cover[q] <= prices[q]
        assert total(c[4] for c in columns) == 1
        assert total(c[5] for c in columns) <= 1
        q_receipts.append(dict(q_mask=q, true_mu=prices[q], original_mass=mass[q],
                               original_density=mass[q]/prices[q], supplier_members=live[q],
                               total_packing_density=cover[q], weighted_shared_mass=q_mass,
                               finite_conditional_columns=columns))
    assert all(left[a] <= owner_capacity[a] and right[a] <= owner_capacity[a] for a in old)
    assert all(supply[i] <= supply_capacity[i] for i in old)
    assert total(left.values()) == total(right.values()) == total(lam*supply[i] for i in old)
    assert total(left.values()) == total(x["weighted_shared_mass"] for x in q_receipts)

    saved_contacts = {}
    for q, row in rows.items():
        for t, u, g, z in row:
            for arm, price in ((u, z), (g, q)):
                for i in live[price]:
                    c = contact(t, arm, i)
                    assert 0 < c <= m[arm]
                    saved_contacts[t, arm, i] = c
    if old_trade:
        old_parents, old_supply, old_lambda, _, old_contact, _, _, _ = old_trade(stage)
        assert set(old_parents) == set(p) and set(old_supply) == set(old) and old_lambda == lam
        assert old_contact == saved_contacts

    orders = defaultdict(F)
    for q, row in rows.items():
        for (t, _, _, z), first in row.items():
            ordered = reciprocal = distinct = ZERO
            for (s, _, _, w), second in row.items():
                pr = second/mass[q]
                if m[s] >= m[t] and w & bits[t]:
                    ordered += pr
                    if t != s:
                        distinct += pr
                if w & bits[t] and z & bits[s]:
                    reciprocal += pr
            orders["ordered"] += first*ordered
            orders["ordered_distinct_middle"] += first*distinct
            orders["reciprocal"] += first*reciprocal
            orders["ordered_conditional_at_least_1_over_16"] += first*(ordered >= F(1, 16))
        assert mass[q] > 0

    degree_factor = {"formula_without_extra_degree": {t: ONE for t in middle},
                     "fixture_min_full_degree": {t: full_d[t]/min(full_d.values()) for t in middle},
                     "all_fixtures_min_full_degree": {t: full_d[t]/all_fixture_degree for t in middle}}
    h0 = 1 + F(1, 32*n)
    hn = 1 + F(1, 2*n)
    assert F(stage["h"]) == h0
    haloes = {}
    for name, h in (("R811_archived_h0", h0), ("R813_gamma_zero_hn", hn)):
        target = {i: dilated(p[i], h) for i in p}
        if name == "R811_archived_h0":
            assert all(target[i] == box(p[i]["expanded_box"]) for i in target)

        @lru_cache(None)
        def hit_owner(a, *targets):
            probability = volume(intersect(owners[a], *(target[k] for k in targets)))/owner_capacity[a]
            assert 0 <= probability <= 1
            return probability

        @lru_cache(None)
        def conditional(q, t, u, g, i, clipped):
            need = bits[t] | bits[u] | bits[i] if i else 0
            return total((w/mass[q])*(throttle[a, b] if clipped else ONE)*hit_owner(a, u)*hit_owner(b, g)
                         for (_, a, b, z), w in rows[q].items() if z & need == need)

        @lru_cache(None)
        def averaged(t, u, g, i, k, clipped):
            need = bits[t] | bits[g] | bits[k]
            den = contact(t, g, k)
            return total(mu*conditional(q, t, u, g, i, clipped) for q, mu in prices.items()
                         if q & need == need and q in rows)/den

        raw_hit = defaultdict(F)
        # Each target below is a frozen original pair of donor labels. Fractions are
        # clipped BEFORE averaging over the original independently sampled donor labels.
        pay = defaultdict(F)
        min_unit = {}
        for q, row in rows.items():
            for (t, u, g, z), w in row.items():
                for clipped in (False, True):
                    label = "feasible" if clipped else "unthrottled_diagnostic"
                    raw_hit[label] += w*conditional(q, t, u, g, None, clipped)
                for i, zi in tags[z].items():
                    left_ratio = m[t]/contact(t, u, i)
                    hit = conditional(q, t, u, g, i, True)
                    for k, qk in tags[q].items():
                        terms = {"fixed_actual_q": left_ratio*hit,
                                 "independent_true_right_fibre": left_ratio*averaged(t, u, g, i, k, True)}
                        tagged_weight = w*zi*qk
                        for law, unit in terms.items():
                            min_unit[law] = min(unit, min_unit.get(law, unit))
                            for calibration, factors in degree_factor.items():
                                v = factors[t]*unit
                                for D in FACTORS:
                                    pay[law, calibration, D] += tagged_weight*min(ONE, D*v)
        rates = {}
        for (law, calibration, D), value in sorted(pay.items()):
            assert 0 <= value <= raw
            rates.setdefault(law, {}).setdefault(calibration, {})[str(D)] = dict(
                paid_original_mass=value, fraction=value/raw, full=(value == raw))
        haloes[name] = dict(exact_factor=h, raw_joint_probe_fractions={k: v/raw for k,v in raw_hit.items()},
                            minimum_unit_mass_multiplier_without_extra_degree=min_unit, payoff=rates)

    capacities = dict(source=[dict(supplier=i, lambda_j=lam, true_mu=supply_capacity[i],
                                   raw_T_j_mass=supply[i], lambda_times_T_j_mass=lam*supply[i],
                                   lambda_j_source_cap=lam*supply_capacity[i]) for i in old],
                      receivers=[dict(owner=i, Lebesgue_capacity=owner_capacity[i],
                                      left_before=before_u[i], right_before=before_w[i],
                                      left_after=left[i], right_after=right[i],
                                      left_saturated=left[i]==owner_capacity[i],
                                      right_saturated=right[i]==owner_capacity[i]) for i in old],
                      pair_throttle=[[a,b,w,throttle[a,b]] for (a,b),w in sorted(pair_load.items())],
                      maximum_overload_left=max(before_u[i]/owner_capacity[i] for i in old),
                      maximum_overload_right=max(before_w[i]/owner_capacity[i] for i in old),
                      total_lambda_times_T_j_mass=total(left.values()))
    return dict(dimension=n, original_cross_bin_mass=raw, full_degrees=full_d,
                L_diag_fixture=min(full_d.values()), L_diag_all_fixtures=all_fixture_degree,
                lambda_common=lam, source_contacts=[[t,u,i,v] for (t,u,i),v in sorted(saved_contacts.items())],
                capacities=capacities, q_rows=q_receipts,
                ordered_source_exchange_fractions={k:v/raw for k,v in orders.items()}, haloes=haloes)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--comb", type=Path, required=True, help="unmodified original R811 comb JSON")
    parser.add_argument("--previous-scripts", type=Path,
                        help="optional directory containing R813 trade813.py for an additional exact cross-check")
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--output", type=Path)
    mode.add_argument("--check", type=Path)
    args = parser.parse_args()
    earlier = None
    if args.previous_scripts:
        earlier = runpy.run_path(str(args.previous_scripts/"trade813.py"))["source_law"]
    original = args.comb.read_bytes()
    stages = json.loads(original)["stages"]
    assert sorted(x["dimension"] for x in stages) == [2,3,4]
    global_degree = min(F(p["full_d"]) for s in stages for p in s["parents"] if p["role"]=="middle")
    results = [fixture(s, global_degree, earlier) for s in stages]
    out = dict(
        original_comb_sha256=sha256(original).hexdigest(), arithmetic="fractions.Fraction throughout",
        source_model="All marked donors are the benchmark old parents with constant lambda=1/(essential maximum multiplicity). On an actual price cell the donor law is lambda/F, separately for the two original arms. C(t,u,i) is checked both by true cell masses and by integration of the continuous product-comb density.",
        receiver_model="Each conditional column specifies (t', old left a, old right b, true source cell Z, probability before, probability after thinning). Given the column draw Z from the true normalized comb measure on that cell and independently draw U' and W' uniformly on E_a and E_b. Actual r lies in the displayed q cell. Kernels vanish on right price cells without original records; T_j=1_{A_j*}(r) mu(dr) K_r and each T_j is multiplied by lambda_j ONCE for the receiver capacity tests.",
        formulas="With f(i,q,t,u,g)=K_q[Z in A_i* intersect A_t intersect A_u, U' in H_u, W' in H_g], fixed_actual_q=min(1,D factor m_t f/c^-). Independent_true_right_fibre=min(1,D factor m_t integral_{A_j* intersect A_t intersect A_g} f(i,r,t,u,g) dmu(r)/(c^- c^+)). Both are then averaged in the original marked cross-bin law. The complete original d_t always occurs in its mother coefficient; an OPTIONAL extra factor d_t/L_diag is displayed separately.",
        long_jump_scope="For n=2,3,4, b0=0 exactly: log(n+2)>1 and r0<=ceil(sqrt(n)(n+2)^2)<=72, so floor(r0/(65536 log(n+2)))=0. Given price membership cells the comb is non-atomic, including on equal source cells; the shared right point r and resampled left source Z coincide with probability zero. The large-n separation and degree filters are not realized by these examples.",
        stages=results)
    encoded=(json.dumps(out, default=str, ensure_ascii=False, sort_keys=True, indent=2)+"\n").encode()
    if args.check:
        assert args.check.read_bytes()==encoded, "saved certificate differs from complete exact replay"
    else:
        args.output.write_bytes(encoded)
    for item in results:
        for nm, row in item["haloes"].items():
            data=row["payoff"]["fixed_actual_q"]["formula_without_extra_degree"]
            print(item["dimension"],nm,"D=1,8,64,512",*[format(float(data[str(d)]["fraction"]),".10g") for d in FACTORS])
    print("certificate",sha256(encoded).hexdigest(),"bytes",len(encoded),
          "verified against previous script" if earlier else "self-contained replay")


if __name__ == "__main__":
    main()
