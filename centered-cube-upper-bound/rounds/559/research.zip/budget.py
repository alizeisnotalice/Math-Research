"""R559: actual mother-ledger factor; no cube inequality certified here."""
import json
import sys
import sympy as sp
import flint
from flint import arb, ctx

ctx.prec = 192
x, c = sp.symbols('x c', positive=True)
F = sp.exp(2*x)*(c+x)/(1+x)**2
numerator = 1+x+2*x*(c+x)
assert sp.simplify(sp.diff(F,x)-sp.exp(2*x)*numerator/(1+x)**3) == 0
# F is the G-dependent part of G^2 C_*(G)/(1+log G)^2;
# fixed positive S, J, theta, beta, h, A_n are NOT claimed free.
# J(G) is nondecreasing when it varies and only worsens this result.
stages = {
    'initial': [('4/3','1'), ('2','2'), ('4','3')],
    'boundary_pressure': [('1000000000001/1000000000000','1'),
                          ('1000000001/1000000000','1000000')],
    'expanded': [('100','1'), ('1000000','10'), ('1000000000000','100')],
}
def rational_ball(s):
    q=sp.Rational(s)
    return arb(int(q.p))/arb(int(q.q))
rows=[]
for stage,cases in stages.items():
    for gs,cs in cases:
        G,C=rational_ball(gs),rational_ball(cs)
        X=G.log()
        derivative_log=2+1/(C+X)-2/(1+X)
        ratio=G**2*(C+X)/(C*(1+X)**2)
        assert derivative_log > 0
        assert ratio > 1
        rows.append(dict(stage=stage,G=gs,c0=cs,
                         log_derivative=str(derivative_log),
                         cost_relative_to_G1=str(ratio)))
print(json.dumps(dict(
    executable=sys.executable,python=sys.version.split()[0],
    sympy=sp.__version__,python_flint=flint.__version__,arb_precision_bits=ctx.prec,
    symbolic_derivative='exp(2*x)*(1+x+2*x*(c0+x))/(1+x)^3',
    domain='x=log(G)>0; c0>=1; derivative positive analytically',
    interpretation='8 finite Arb checks supplement exact algebra; no n-exponent fit, no general cube certificate',
    rows=rows),ensure_ascii=False,indent=2))
