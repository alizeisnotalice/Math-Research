# R559｜Spector–Stockdale v1 条件核验（一页）

原文：[arXiv:2609.05377v1，2026-09-04](https://arxiv.org/html/2609.05377v1)。先用 F04 已存来源卡 `references/papers/ROOT-S-986768affaa80a44.json` 定位，再定点核 §3–5；未重复下载、未跑实验。结论：**层的平方函数付款具有可抽象的核心；Thm1.2整体不只依赖对称 Markov。现在不能据它取得 cube 完整预算。**

约定：\(L\ge0\)、\(H_t=e^{-tL}\)、\(A_s=s(s+L)^{-1}\)，\(m=\int f\)。下表的“可迁移”均是条件判断，不是论文声称的一般生成元定理。

|环节与准确位置|实际必要输入／边界|
|---|---|
|§3.1 Lemma3.1；PDF pp.11–12|保留同一 Ω 的原子正则化用 Newton 势在小球外不变，属局部 Laplacian。一般跳过程不能照抄；可另从 R555 的正则数据开始，但需重接其余接口。|
|§3.2 (3.2)，PDF pp.12–13|\(Ku=f\)、\(K=L_\Omega+V\)、\(V=\kappa/u\) 和正闭形式，使 \(0\le z_j\le u\)。此步可抽象，但要证明 u 在实际 part-form/operator 域内。|
|§3.2 Lemma3.2，(3.3)–(3.6)，PDF pp.13–14|零延拓后**无退出输出**的等式，用局部性及 \(u=O(d^2)\)；这是直接搬运的断点。跳过程会在整个 Ωᶜ产生正退出输出，不能删掉。|
|§3.3 Lemma3.3，(3.7)–(3.11)，PDF pp.14–15|只需正 killed 演化、\(K^{-1}f=u\)、正输出算子 T 及 \(Tu=\mu\le\kappa\)：Poisson/Gamma、Tonelli、Stirling；常数无维数损失。|
|§3.4 Thm3.4，(3.13)–(3.18)，PDF pp.15–17|在正层精确展开成立后，收缩、自伴谱演算、Beta重参数、Schur足够；late-layer中的空间 Fourier 可由 L 的谱分解代替。还需零谱端点消失／另计投影。|
|§4低频，(4.7)–(4.9)，PDF pp.19–21|Gamma–Mellin乘子及 \(\int\!\|tLH_t\mu\|_2^2dt/t\le\|\mu\|_2^2/4\) 是抽象谱事实；先证外域 log-time orbit 可积。已取得外域 Abel 平方界时，取 \(N\asymp B^2\) 得低频 \(\lesssim B\kappa m\)。|
|§4高频 Lemma4.1 (4.1)–(4.6)，PDF pp.17–19；另依赖 Prop2.3|**必须新增核估计**：Gaussian 的复 Mellin公式、Laplacian作用于径向幂、\(\int_{\Omega^c}\int_\Omega u(y)|x-y|^{-n-2}dy,dx\lesssim n\omega_nC^nm\)。Gamma衰减在 \(\Lambda\asymp n\) 消掉该指数成本；一般 Markov 性没有给这一机制。|
|§5 Lemma5.1，PDF pp.21–22；§6|给定低频预算后，dyadic壳求和得 \(\|T_\Lambda\|_2^2\lesssim\log^2(e\Lambda)\kappa m\)，属标量 Fourier预算。取 cap \(\kappa\asymp\alpha/\log(e\Lambda)\) 收 weak bound；仍须高频 L¹ 和 Fourier inversion。球到 heat 的 (1.4) 比较不提供 cube 比较。|

**最关键的可迁移付款**（§3.3–3.4，Haar测度 ds/s 不可省）：
\[
 \rho_j=T\!\int_0^\infty e^{-st}(st)^j/j!\;e^{-tK}f\,dt,
 \quad\sum_j\rho_j=\mu,\quad
 \rho_j\lesssim(j+1)^{-1/2}\mu,\quad
 \int_0^\infty\|\rho_j\|_1\frac{ds}{s}=\frac mj\ (j\ge1).
\]
因此层能量为 \(\lesssim\kappa m j^{-3/2}\)；在精确 free/killed层展开下，平方积分为 \(\lesssim\sqrt N\kappa m\)，不是范数为该阶。

**可改变决策的条件性新入口：把 overshoot 并入全空间输出，而非要求它消失。** 对纯跳 \(L=-A\)，零延拓 z 在远离边界的 Ωᶜ上有
\[
 Lz(x)=-E z(x),\qquad E z(x)=\int z(x+h)\,\nu(dh)\ge0.
\]
若另证全分布／part-form接口，则可试 \(Tz=Vz\,1_\Omega+(Ez)1_{\Omega^c}\)。R555给 \(Lu=f-\mu\)、\(\mu\le\kappa\)，若 f 支持于 Ω，则 \(Tu=\mu\)，正退出层与内杀死层一起满足上述全部 Poisson付款，并恢复
\[
 (A_s^N-B_s^N)f=\sum_{j<N}A_s^{N-j}\rho_j.
\]
若 f 在 Ωᶜ仍有质量，先核 \(f1_{\Omega^c}\le\kappa\) 及相应有界部分拆分，不能直接假定源都在 Ω。此建议**未认证**：须核退出输出是合法有限测度／密度、T与Gamma积分交换、\(Tu=\mu\)、闭形式域和全部零延拓分布等式；不允许仅改符号沿用 (3.3)。

停止结论：值得主代理只深入这个“正退出输出＋内杀死”接口；若通过，可能取得一般生成元的外域 Abel 平方预算。它仍不支付 §4的高 Mellin频率或 cube 的全 Q接收／平均核比较；这两项没有原文可直接移植的根阶预算。
