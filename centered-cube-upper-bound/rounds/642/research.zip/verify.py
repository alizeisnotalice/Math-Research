#!/usr/bin/env python3
from pathlib import Path
import hashlib,json,os,subprocess,sys,tempfile,time,re
import sympy as S
root=Path(__file__).resolve().parent
start=time.perf_counter()
def digest(x): return hashlib.sha256(json.dumps(x,sort_keys=True,separators=(',',':')).encode()).hexdigest()
manifest=root/'MANIFEST.json'
if manifest.exists():
 for name,h in json.loads(manifest.read_text()).items():
  assert hashlib.sha256((root/name).read_bytes()).hexdigest()==h,name
summary=json.loads((root/'RUN_SUMMARY.json').read_text())
with tempfile.TemporaryDirectory(prefix='ccu642-replay-') as tmp:
 env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1')
 out=subprocess.run([sys.executable,str(root/'check.py')],cwd=tmp,env=env,check=True,capture_output=True,text=True)
 r=json.loads(out.stdout)
assert r['analytic_certificate']==summary['analytic_certificate']
for p,q in zip(r['phases'],summary['phases'],strict=True):
 assert (p['name'],p['count'],digest(p['rows']))==(q['name'],q['count'],q['exact_rows_sha256'])
assert sum(p['count'] for p in r['phases'])==247
# Exact algebraic Young identities, positive substitutions V=u^2, M=v^2, eta=t^2.
u,v,t=S.symbols('u v t',positive=True)
r1=S.expand(t*t*u*u+8*v*v/(t*t)-4*S.sqrt(2)*u*v-(t*u-2*S.sqrt(2)*v/t)**2)
r2=S.expand(t*t*u*u+200*v*v/(t*t)-20*S.sqrt(2)*u*v-(t*u-10*S.sqrt(2)*v/t)**2)
assert r1==0 and r2==0
tex=(root/'REPORT.tex').read_text()
stack=[]
for match in re.finditer(r'\\(begin|end)\{([^}]+)\}',tex):
 kind,name=match.groups()
 if kind=='begin': stack.append(name)
 else: assert stack and stack.pop()==name
assert not stack
assert '\\boxed{\\ ch+5L' in tex and 'H_*' in tex
receipt={'passed':True,'cases':247,'symbolic_identities':2,'latex_structure_only':True,'report_sha256':hashlib.sha256((root/'REPORT.tex').read_bytes()).hexdigest(),'interpreter':sys.executable,'replay':r['run'],'verification_wall_s':time.perf_counter()-start}
print(json.dumps(receipt,ensure_ascii=False,indent=2))
