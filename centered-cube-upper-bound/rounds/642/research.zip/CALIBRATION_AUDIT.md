# R642 final calibration and conditional-proof audit

**Verdict: PASS for the corrected report's mathematical reduction and conditional implication. Proposition F and the general root/polylog upper bound remain unproved.**

Audited file: `/tmp/ccu_r642_final/REPORT.tex`

SHA-256: `97e03a1a3f6d790bd2d0742e7b2d1e971b786bede642ff3b18a04056f0ffba4d`

This hash was read from the final corrected file after independently reading the report against `/tmp/ccu_r642/CALIBRATION_AUDIT.md`. I modified only this audit. No broad computation, historical sweep, compilation, repository or Git operation was performed.

## Calibration endpoints and finite-N quantifiers

The report uses the fixed class of all nonempty true ordered geometric families with at most N positive receiver increments, independent of ε and without a fixed input/source restriction. Its zero-end quantity is the scalar linear optimum Q_0, so uniqueness or positivity of a selected λ_0 is not assumed.

The per-family comparison `0≤Q_e1−Q_e2≤(e2−e1)V`, including e1=0, is correctly proved. Infimizing over the same class preserves monotonicity and 1-Lipschitz continuity. The weighted-log maximizer γ is positive and satisfies γ_j≥v_j/V by testing e_j. Its large-ε limit yields the uniform fixed-N bound `Q_e≥a^nV/N`, while the single cube gives the other endpoint. Hence

`a^n/N≤A_N(e)≤a^n`, `S_N(e)=1/A_N(e)`.

Consequently e/A_N(e) is continuous, strictly increasing from zero to infinity, giving one unique positive ε_N with ε_NS_N(ε_N)=4. There is no infimum/limit interchange and no geometric or source compactness assumption. The supplementary bound `S_N(0)≤S_N(ε_N)≤5S_N(0)` follows from `A_N(0)≤A_N(ε_N)+ε_N=5A_N(ε_N)`.

The actual near family satisfies `ε_NR>4−c/100≥3.99`, not necessarily ε_NR=4. Every later comparison keeps ε_N and at most N labels. This distinction is correctly retained.

## Universal deletion, full fee and actual target

The equivalence between full-source rows m_j=M and universal vertices uses actual AC moments, old positive λ and box Helly correctly. One deletion removes all such vertices, preserves positive retained increments, and leaves a graph without universal vertices. No free induction or repeated deletion is assumed.

The report retains the actual increment reassignment fee in (9), the true receiver loss ell and the recomputed G problem. Its critical interval, bounds M_G≤2M, and coefficient absorption agree with the previous independent audit. The complete fee form

`ch+5L≤ηV+(52+200/η)M`

is valid and covers the actual lift cost, since 1+εR_G≤5. It retains all mean/source terms and the actual regularized new Q, rather than replacing them by a favorable linear optimizer.

The final G-based action need not be an original-m canonical action. The report explicitly makes this distinction. It is a legitimate complete finite update in the same class used for the original near-supremum cap. Its cap uses `Q_new≤M_G≤2M`, not original-source coverage.

## Precise remaining F and complete contradiction

The corrected F explicitly requires absolute constants c_0,C,B,H_* with H_*≥32, and covers **all** universal-free finite families with `7/2≤εR_G≤4` and H≥H_*. Its constants must be uniform in n,N, source, scales and minimum weights. It is not restricted to near-free families. One actual AC KKT source chosen globally for each G suffices; rowwise different sources would not.

The corrected constant

`A=16{(100/c)^2+H_*}+96C/c`, `c=min(c_0,1)`,

ensures all required H thresholds when S_N(0)>A L_n. With the actual near choice ζ=c/(100ε_N), the lift gives D≥cV/4, whereas the same-ε, ≤N class gives

`D≤(S_N−R)Q_new<ζQ_new≤ζM_G≤2ζM`.

The first inequality is correctly nonstrict; only the old near choice supplies the strict upper bound. The lower bound `V/M>3/(4ε_N)` yields the stated contradiction without attainment. Thus F would imply S_N(0)≤A L_n uniformly in N. Dependence of ε_N on N is confined to a contradiction parameter, not the final bound.

The general nonnegative L1 recovery is valid: strict centered witnesses at centers of a compact subset give an open receiver cover; a finite subcover gives a finite family. Deleting zero increments preserves its union measure. Every packing vector obeys `α d·λ≤||f||_1`, so the linear capacity bound controls the compact subset's measure. Inner regularity then gives the full strict superlevel bound at arbitrary threshold and all scales. This proves the conditional recovery, not F itself.

## Corrections found and resolved

Two issues were identified on the initially read version, SHA-256 `a7808aee5e1cf925e450b808ecaf567956bd690bad3a2b0dca1128f50f7acfe8`:

1. F's unspecified “sufficiently large H” threshold was absent from A, so the claim that G lay in F's domain did not follow. The final version explicitly quantifies an absolute H_* and includes 16H_* in A and H≥H_* in (16).
2. The original fee display used ch+(1+x)L, but the lift has ch+(1+εR_G)L and εR_G≤x was not proved. The final version strengthens the display to ch+5L; the same proof gives exactly its stated constant.

Both changes were reread and their final hash verified. No unresolved substantive calibration or conditional-recovery error remains. The sole decisive open claim is the complete joint budget F. Audit complete; stop.

Final freeze update: the theorem introducing (9) now explicitly assumes G nonempty, which is necessary for its independently stated regularized problem and is already ensured in the application. I reread that sentence and independently verified the final SHA-256 above. This scope clarification does not change the PASS verdict. The preceding audited checkpoint had SHA-256 `8fd3cca36fbf6fac978337179d309ea048462bdc954328db19c48a6cdd6664b5`. No further work remains in this bounded audit.
