# R642 最终主稿：全源删除、真实费用与回代终审

审核对象：`/tmp/ccu_r642_final/REPORT.tex`。
最终 SHA-256：`97e03a1a3f6d790bd2d0742e7b2d1e971b786bede642ff3b18a04056f0ffba4d`。

**结论：通过本文所述参数校准、universal 一次删除、改变真实接收权的费用证明、Young 预算及条件性一般输入回代；未发现剩余实质错误。命题 F 仍未证明，不认证一般根阶弱型上界。** 复用本支前次独立证明后逐式核最终稿；只写本审核，不修改主稿、仓库或他人文件，不作重复扫描。

## 1. universal 判别与一次删除

m_j=M⇒μ 几乎处处支持 A_j，每个其他 m_i>0 及 AC 性给 A_i∩A_j 正体积。反向中，universal j 若不属于一个承载来源的 old active clique K，box Helly 使 K∪{j} 共同正交，违反 λ(K)+λ_j>1。λ 全正、正体积约定和真实 AC 均保留。因此 full-source 与 universal 精确等价，不依赖同一 KKT 来源类中的内部密度选择。

每个原 nonuniversal 的一个 nonneighbor 也 nonuniversal，删去全部 universal 后非邻关系仍在。保留原相对顺序使 v_j^G≥v_j>0，没有额外零行删除，也不在这次固定几何重求 KKT 时生成 full-source。主稿正确不将此结论外推到以后改变几何的动作。

0≤ℓ≤h≤PM 的证明有效：h 是删除标签原先拥有的真实增量，不是随意用被删 union 代替；全源 stars 共同包含一个来源点且各 d_j≤M，其小 receivers 的 union 容量≤PM。在主临界窗口及大 H 下 G 非空。最终定理(9)已明确这个条件，故其 t<1 和除以1−t没有空族漏洞。

## 2. 参数与实际增量改变的费用

固定几何的 Q_e 非增且1-Lipschitz（归一后）的证明通过。两支持梯度界与 weighted Cauchy 给 Δ≤(e2−e1)V；零端只测试 scalar linear optimum，没有假设正的 λ0。log-only 最优 γ_j≥v_j/V 及逐族 λ_e→γ 给 Q_e/V≥a^n/N；这里没有交换无限族 infimum 与 limit。

因此同一个≤N、与 e 无关的几何类上，A_N 连续正且非增，e/A_N(e) 连续严格增加并从0到∞；唯一 ε_NS_N(ε_N)=4 合法。S_N(0)≤S_N(ε_N)≤5S_N(0) 的新增比较也正确：A_N(0)≤A_N(ε_N)+ε_N=5A_N(ε_N)。实际 near family 只取 x=εR≤4 且足够接近4，没有假定 supremum 达到。

对 G 非空，universal 集与余图构成 join。t=Σ_Hλ_j<1，继承余行权除1−t正是参数 ε/(1−t)、原余行增量下的正则最优。其线性值为 M−ε(V−h)/(1−t)；借已证参数比较降回同一个最终 ε，得到继承增量下的成本≤Q+εh。该参数比较是证明内部的精确比较，不是沿实际更新重新调 ε。

重算余行真实增量时 u_j≥0、U=Σu_j=h−ℓ。令 V0=V−h，z=(d·q−d·p)/ε。最终稿的支持梯度方向准确：

\[
X\le V_0-z,\quad Y\le V_0+U+z,
\quad XY\ge(\sum\sqrt{v_j(v_j+u_j)})^2\ge V_0^2.
\]

于是 z²+Uz≤V0U，确给 z≤√(V0U)，无须假设改变接收权使线性成本单调。故

\[
Q_G\le Q+E,\quad E=\epsilon[h+\sqrt{(V-h)(h-\ell)}]
\]

是完整真实费用；M_G=Q_G+ε(V−ℓ) 是重求的自身来源总量，不是旧 μ 的简单限制。

## 3. 临界窗口、Young 付款与 lift

最终稿保留 x∈[15/4,4] 与 b=h/V≤(1+x)/(2Hx) 的关联，正确得到

\[
L/V\le25/(8H)+\sqrt{10/H}\le7/(2\sqrt H),\quad L=\ell+RE.
\]

不能独立最大化 x、b 后仍引用25/8；主稿没有这样做。H≥(100/c)²、0<c≤1 确保 εR_G≥7/2、M_G≤2M、ch+5L≤cV/2。εR_G≤4 来自同 ε、≤N 的全类 supremum，正确地没有从删除下界推上界，也没有声称 G 任意 near S_N。

最终(13)已强化为实际可用的系数5：

\[
ch+5L\le(50+2c)M+20\sqrt{2VM}
\le\eta V+(52+200/\eta)M.
\]

4√2 和20√2 的 Young 常数分别为8与200。这个估计确支付删除和返回原 R 的全部费用，是无维数的实际部分预算；并非只描述 O(V/√H)。它限于合法校准的 x≤4，不无条件覆盖任意大的 εR。

若 F 给 G 的完整输出，则 Qnew≤M_G、同 ε、标签数不增。比率差严格使用

\[
(R-R_G)_+Q_{\rm new}\le(1+\epsilon R_G)L\le5L.
\]

所以 Dhat=Wnew−RQnew≥cV/2−2CL_nM，或保留 Young 形式 (c−η)V−[2CL_n+52+200/η]M，均准确。G 的动作和来源一般不是原 m_j/μ 的一次完整 Z；最终稿明确其作用域为全几何 finite-sup 后继比较。

## 4. F 的阈值、最终常数及一般输入

最终 F 已加入绝对 H_*≥32，要求全部 universal-free、7/2≤εR_G≤4、H≥H_* 的有限族，而不是仅 near-free 族。取 c=min(c0,1) 和

\[
\mathsf A=16\{(100/c)^2+H_*\}+96C/c.
\]

若 S_N(0)>A L_n，由 P≤2、L_n≥1 得 H>(100/c)²、H≥H_*、H≥6CL_n/c，所有先前域条件都被覆盖，没有“足够大”依族退化。

ζ=c/(100ε_N) 给实际旧 x>4−c/100≥3.99。在同 ε、≤N 的全类中，G 输出满足

\[
\widehat D\le(S_N-R)Q_{\rm new}
<\zeta Q_{\rm new}\le2\zeta M=cM/(50\epsilon_N).
\]

首个比较为非严格≤，不假设输出不达 supremum。F 的 lower bound 与 H≥6CL_n/c 则给

\[
\widehat D\ge cV/4>3cM/(16\epsilon_N),
\]

矛盾。这一常数链通过；保持真实 receiver、重新构造的 M_G 和全部删除损失，不需 G 任意 near，也没有新增标签或按子问题再校准 ε。

由此得到的只是**F 若成立，则**所有 S_N(0)≤A L_n。原 f 的严格平均 witnesses、同心1/a小 receivers 的有限开子覆盖、linear packing 与 ∫fL≤||f||1，再经紧集内正则性恢复，确给任意非负 L1、任意阈值和全部正半径的一般弱型界。它不是 F 已成立的证明。

## 5. 最终边界与证据

完整交换账(19)展开正确：net linear saving 加 remaining-old slack、new-clique slack 与逐row excess，恰为 S；非负性没有被误当统一正收益。仍保留实际新 α 的 barrier 信用，未将主步限成纯正 linear exchange。其他 receiver/contact 尝试在最终稿只作为未获足量好配置的探索，不拿来填补 F。

主稿247例有理检查与连续域证书的作用仅为公式、常数和平方根包络核验；本次终审未重复运行这些扫描，没有数值计算未知 S_N，也没有制造 hard geometry。前次独审实际的符号与 Fraction 证据仍只辅助本审解析链，不证明 F。

**最终判定：** universal 删除和真实费用付款已证，且其回原目标的量词与常数通过。唯一决定性主步仍是 F：对全部无 universal 的临界几何族给足量同动作全局收益并支付完整接收亏损。该项未证明，因此本审核不认证一般根阶上界、不将条件性化简当作完整闭合。审核完成停止。
