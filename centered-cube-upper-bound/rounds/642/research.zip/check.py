#!/usr/bin/env python3
from fractions import Fraction as F
from math import isqrt
from hashlib import sha256
from pathlib import Path
import json,sys,time,resource
import sympy as S
start=time.perf_counter();cpu=time.process_time()
def sqrt_bounds(x,bits=160):
 assert x>=0
 z=isqrt((x.numerator<<2*bits)//x.denominator);lo=F(z,2**bits);hi=F(z+1,2**bits)
 assert lo*lo<=x and hi*hi>x
 return lo,hi
x=S.Symbol('x',positive=True);b_expr=(1+x)/(2*x);f_expr=(1+x)**2/(2*x)
assert S.simplify(S.diff(b_expr,x)+1/(2*x**2))==0
assert S.simplify(S.diff(f_expr,x)-(x*x-1)/(2*x*x))==0
assert F(111,32)**2-10==F(2081,1024)>0
kbound=F(15,4)*(1-F(19,300000))/(1+F(7,200));assert kbound-F(7,2)==F(10181,82800)>0
assert F(1,2)-(F(19,300000)+F(7,40))==F(97481,300000)>0
assert F(1,4)-F(19,90)==F(7,180)>0

def check(stage,c,H,x,b,l):
 assert 0<c<=1 and H>=F(10000)/(c*c) and F(15,4)<=x<=4 and 0<=l<=b<1 and b<=(1+x)/(2*H*x)
 lo,hi=sqrt_bounds((1-b)*(b-l));Llo=l+x*b+x*lo;Lhi=l+x*b+x*hi
 # Coarse analytic bound L<=25/(8H)+sqrt(10/H), using exact root enclosure.
 _,rt10hi=sqrt_bounds(F(10,H));_,rtHhi=sqrt_bounds(F(1,H))
 coarse=F(25,8*H)+rt10hi
 assert Lhi<=coarse and coarse<=F(7,2)*rtHhi
 kappa_lower=x*(1-l)/(1+x*b+x*hi)
 assert kappa_lower>F(7,2)
 beta=x/(1+x);mg_ratio_upper=1+beta*(b-l+hi);assert mg_ratio_upper<2
 loss_over_c=b+5*Lhi/c;assert loss_over_c<F(1,2)
 return {'stage':stage,'c':str(c),'H':str(H),'x':str(x),'b':str(b),'l':str(l),'kappa_lower':str(kappa_lower),'MG_over_M_upper':str(mg_ratio_upper),'loss_over_c_upper':str(loss_over_c)}
phases=[]
# Endpoint tests (saturate b) and l endpoints.
rows=[]
for x0 in (F(15,4),F(4)):
 c=F(1);H=10000;b=(1+x0)/(2*H*x0)
 for l in (F(0),b):rows.append(check('endpoints',c,H,x0,b,l))
phases.append({'name':'endpoints','count':len(rows),'rows':rows})
# Interior/endpoint pressure, all valid b/l combinations.
rows=[]
for x0 in (F(15,4),F(31,8),F(4)):
 H=10000;c=F(1);bmax=(1+x0)/(2*H*x0)
 for scale in (F(0),F(1,2),F(1)):
  b=bmax*scale
  for q in (F(0),F(1,2),F(1)):rows.append(check('pressure',c,H,x0,b,b*q))
phases.append({'name':'pressure','count':len(rows),'rows':rows})
# Smaller c and larger H relative to the threshold.
rows=[]
for c in (F(1,2),F(1,10),F(1,100),F(1,1000)):
 for factor in (1,100):
  H=int(F(10000)*factor/(c*c))
  for x0 in (F(15,4),F(31,8),F(4)):
   bmax=(1+x0)/(2*H*x0)
   for bs in (F(0),F(1,2),F(1)):
    b=bs*bmax
    for ls in (F(0),F(1,2),F(1)):rows.append(check('expanded',c,H,x0,b,b*ls))
phases.append({'name':'expanded','count':len(rows),'rows':rows})
out={'analytic_certificate':{'max_b':'19/(30H)','max_linear_L':'25/(8H)','max_sqrt_L':'sqrt(10/H)','sqrt_rational_square_residual':'2081/1024','kappa_lower':'299981/82800','kappa_margin':'10181/82800','MG_upper':'10101/10000','loss_over_c_upper':'52519/300000','loss_margin':'97481/300000','post_absorb_ratio':'19/90','post_absorb_margin':'7/180'},'phases':phases,'run':{'python':sys.version,'sympy':S.__version__,'cpu_s':time.process_time()-cpu,'wall_s':time.perf_counter()-start,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'script_sha256':sha256(Path(__file__).read_bytes()).hexdigest()}}
print(json.dumps(out,indent=2))
