#!/usr/bin/env python3
"""Smoothed atom-safe rank kernel and full finite marked killed chain."""
from fractions import Fraction as F
from collections import Counter,defaultdict
from itertools import product
from pathlib import Path
import json
BASE=Path(__file__).resolve().parent;C=Counter()
DATA=[{'name': 'distinct_masses_small_shift', 'n': 1, 'Delta': '1/4', 'source_masses': ['1', '2'], 'source_centres': [['0'], ['1']], 'source_box_side': '1/50', 'receivers': [{'R': '2/5', 'centre': ['0'], 'm': '1', 'q': '5/2', 'quadrature_dx': '1/10'}, {'R': '2/5', 'centre': ['1'], 'm': '2', 'q': '5', 'quadrature_dx': '1/10'}, {'R': '6/5', 'centre': ['1/2'], 'm': '3', 'q': '5/2', 'quadrature_dx': '1/5'}], 'input_I': ['1/8', '1/6', '1/8']}, {'name': 'same_mass_atom_and_selfloops', 'n': 1, 'Delta': '1/4', 'source_masses': ['1', '2'], 'source_centres': [['0'], ['1']], 'source_box_side': '1/50', 'receivers': [{'R': '2/5', 'centre': ['0'], 'm': '1', 'q': '5/2', 'quadrature_dx': '1'}, {'R': '1/2', 'centre': ['1/100'], 'm': '1', 'q': '2', 'quadrature_dx': '3/4'}, {'R': '2/5', 'centre': ['1'], 'm': '2', 'q': '5', 'quadrature_dx': '1'}, {'R': '6/5', 'centre': ['1/2'], 'm': '3', 'q': '5/2', 'quadrature_dx': '1'}], 'input_I': ['5/4', '1/2', '5/4', '1/2']}, {'name': 'two_dimensional_full_source', 'n': 2, 'Delta': '1/5', 'source_masses': ['1', '2', '3', '5'], 'source_centres': [['0', '0'], ['1', '0'], ['0', '1'], ['1', '1']], 'source_box_side': '1/50', 'receivers': [{'R': '2/5', 'centre': ['0', '0'], 'm': '1', 'q': '25/4', 'quadrature_dx': '1/20'}, {'R': '2/5', 'centre': ['1', '0'], 'm': '2', 'q': '25/2', 'quadrature_dx': '1/20'}, {'R': '2/5', 'centre': ['0', '1'], 'm': '3', 'q': '75/4', 'quadrature_dx': '1/20'}, {'R': '2/5', 'centre': ['1', '1'], 'm': '5', 'q': '125/4', 'quadrature_dx': '1/20'}, {'R': '6/5', 'centre': ['1/2', '0'], 'm': '3', 'q': '25/12', 'quadrature_dx': '1/2'}, {'R': '6/5', 'centre': ['1/2', '1'], 'm': '8', 'q': '50/9', 'quadrature_dx': '1/2'}, {'R': '3/2', 'centre': ['1/2', '1/2'], 'm': '11', 'q': '44/9', 'quadrature_dx': '1/2'}], 'input_I': ['5/32', '5/24', '15/64', '5/16', '25/144', '25/63', '11/36']}]
def ck(k,v):
 C[k]+=1
 assert v,k
def pos(x):return max(F(0),x)
def tailarea(a,b,c,d,h):return (pos(d-a-h)**2-pos(d-b-h)**2-pos(c-a-h)**2+pos(c-b-h)**2)/2
def loss(D,l,h):return D if D<=l else (l+h)/2 if D>=h else D-(D-l)**2/(2*(h-l))
def run(stage,data,N):
 before=sum(C.values());n=data['n'];f=list(map(F,data['source_masses']));centres=[list(map(F,z)) for z in data['source_centres']];h=F(data['source_box_side'])/2;rec=[(list(map(F,r['centre'])),F(r['R']),F(r['quadrature_dx'])) for r in data['receivers']];nr=len(rec);nz=len(f);upper=F(data['Delta']);lower=upper/2;window=upper-lower;inner=F(1,100)
 inc=[];m=[];sig=[]
 for x,R,dx in rec:
  row=[]
  for z in centres:
   inside=all(abs(a-b)+h<=R/2 for a,b in zip(x,z));outside=any(abs(a-b)-h>=R/2 for a,b in zip(x,z));ck('actual_whole_source_box_capture',inside or outside);row.append(int(inside))
  mm=sum(a*b for a,b in zip(f,row));inc.append(row);m.append(mm);sig.append(mm*dx/R**n)
 pi=[[f[z]*inc[u][z]/m[u] for z in range(nz)] for u in range(nr)];xi=[[F(inc[u][z])*rec[u][2]/rec[u][1]**n for u in range(nr)] for z in range(nz)];Q=[[[F(0) for v in range(nr)] for u in range(nr)] for z in range(nz)];D=[];groups=[]
 for z in range(nz):
  gs=[];block={};a=F(0)
  for mass in sorted(set(m[u] for u in range(nr) if inc[u][z])):
   ids=[u for u in range(nr) if inc[u][z] and m[u]==mass];b=a+sum(xi[z][u] for u in ids);gs.append((a,b,ids))
   for u in ids:block[u]=(a,b)
   a=b
  D.append(a);groups.append(gs)
  for u in block:
   aa,b=block[u]
   for v in block:
    c,d=block[v];area=tailarea(aa,b,c,d,lower)-tailarea(aa,b,c,d,upper)
    knots=sorted(set([lower,upper]+[t for t in [c-b,c-aa,d-b,d-aa] if lower<t<upper]));overlap=lambda t:pos(min(b+t,d)-max(aa+t,c));independent=sum(((y-x)*(overlap(x)+overlap(y))/2 for x,y in zip(knots,knots[1:])),F(0))
    ck('strip_area_independent_exact_integral',area==independent>=0);k=area/(window*(b-aa)*(d-c));Q[z][u][v]=xi[z][v]*k;ck('smoothed_density_bound',k<=1/window)
  primitive=lambda t:(pos(t-lower)**2-pos(t-upper)**2)/(2*window)
  for u in block:
   aa,b=block[u];expected=(primitive(D[z]-aa)-primitive(D[z]-b))/(b-aa)
   ck('exact_smoothed_row_survival',sum(Q[z][u])==expected)
   for v in block:ck('paired_density_direction_bound',Q[z][u][v]/xi[z][v]+Q[z][v][u]/xi[z][u]<=1/window)
  for aa,b,ids in gs:
   if len(ids)>1:ck('same_mass_whole_atom_kernel',all(Q[z][u]==Q[z][ids[0]] for u in ids))
  ck('exact_source_averaged_rank_loss',sum(xi[z][u]*(1-sum(Q[z][u])) for u in range(nr))==loss(D[z],lower,upper))
  for v in range(nr):
   col=sum(xi[z][u]*Q[z][u][v] for u in range(nr));expected=F(0)
   if v in block:
    aa,b=block[v];expected=xi[z][v]*(primitive(b)-primitive(aa))/(b-aa)
   ck('smoothed_source_column_subinvariance',col==expected<=xi[z][v])
 P=[[sum(pi[u][z]*Q[z][u][v] for z in range(nz)) for v in range(nr)] for u in range(nr)];nativeb=[1-sum(r) for r in P]
 for v in range(nr):ck('full_matched_reference_subinvariance',sum(sig[u]*P[u][v] for u in range(nr))<=sig[v])
 B0=sum(sig[u]*nativeb[u] for u in range(nr));ck('full_source_smoothed_loss_fee',B0==sum(f[z]*loss(D[z],lower,upper) for z in range(nz))<=(lower+upper)/2*sum(f))
 # Complete source-box partition by all contracted-cube coordinate faces.
 atoms=[]
 for z,centre in enumerate(centres):
  cuts=[]
  for j in range(n):
   lo=centre[j]-h;hi=centre[j]+h;cuts.append(sorted(set([lo,hi]+[t for x,R,dx in rec for t in [x[j]-inner*R/2,x[j]+inner*R/2] if lo<t<hi])))
  total=F(0)
  for intervals in product(*[list(zip(c,c[1:])) for c in cuts]):
   volume=F(1)
   for a,b in intervals:volume*=b-a
   mass=f[z]*volume/(2*h)**n;total+=mass;ins=[];faces=[]
   for x,R,dx in rec:
    inside=all(a>=x[j]-inner*R/2 and b<=x[j]+inner*R/2 for j,(a,b) in enumerate(intervals));fl=[]
    for j,(a,b) in enumerate(intervals):
     if b<=x[j]-inner*R/2:fl.append((j,-1))
     elif a>=x[j]+inner*R/2:fl.append((j,1))
    ck('source_atom_exact_inner_or_face_partition',inside or bool(fl));ins.append(inside);faces.append(fl)
   atoms.append((z,mass,ins,faces))
  ck('positive_source_atom_partition_mass_once',total==f[z])
 I=list(map(F,data['input_I']));states={(u,tuple(),z):I[u]*pi[u][z] for u in range(nr) for z in range(nz) if pi[u][z]};G=[F(0)]*nr;flux=[[F(0) for v in range(nr)] for u in range(nr)];normal_u=[F(0)]*nr;totals=Counter();sourcefees=[F(0)]*nz;facefees=Counter();origfees=Counter();marked=Counter();generations=[];overlap=F(0)
 for depth in range(N):
  incoming=[F(0)]*nr;nextstates=defaultdict(F);g=Counter();normal_z=[F(0)]*nz
  for (u,hist,orig),weight in states.items():
   incoming[u]+=weight;G[u]+=weight
   local=F(0)
   for z,mass,ins,faces in atoms:
    if not inc[u][z]:continue
    prob=mass/m[u];w=weight*prob;local+=prob;oldhit=any(inc[a][z] for a in hist)
    if ins[u]:
     g['inner']+=w;marked[('inner',orig)]+=w
     if oldhit:overlap+=w
     continue
    ck('retained_source_is_actual_contracted_shell',bool(faces[u]))
    if oldhit:g['ancestor']+=w;marked[('ancestor',orig)]+=w;continue
    term=w*(1-sum(Q[z][u]));g['normal']+=term;marked[('normal',orig)]+=term;normal_u[u]+=term;normal_z[z]+=term;sourcefees[z]+=term;origfees[orig]+=term;coord,sign=faces[u][0];facefees[(z,coord,sign)]+=term
    for v in range(nr):
     e=w*Q[z][u][v]
     if not e:continue
     if depth+1==N:g['unfinished']+=e;marked[('unfinished',orig)]+=e
     else:nextstates[(v,hist+(u,),orig)]+=e;flux[u][v]+=e;g['continue']+=e
   ck('posterior_draw_full_source_not_reset',local==1)
  ck('generation_complete_marked_conservation',sum(g.values())==sum(incoming))
  for u in range(nr):ck('generation_receiver_marginal_cap',incoming[u]<=sig[u])
  for z in range(nz):ck('generation_normal_terminal_source_column',normal_z[z]<=f[z]*loss(D[z],lower,upper))
  for k,v in g.items():
   if k!='continue':totals[k]+=v
  generations.append(dict(depth=depth,incoming=list(map(str,incoming)),branches={k:str(v) for k,v in g.items()},normal_source_mass=list(map(str,normal_z))))
  states=nextstates
 ck('path_first_stops_plus_unfinished_conserve',not states and sum(totals.values())==sum(I))
 ck('terminal_faces_partition_normal_only',sum(facefees.values())==totals['normal']==sum(sourcefees)==sum(origfees.values()))
 for z in range(nz):ck('aggregate_normal_source_cap_N',sourcefees[z]<=N*f[z]*loss(D[z],lower,upper))
 ck('aggregate_normal_fee_N_average_shift',totals['normal']<=N*(lower+upper)/2*sum(f))
 for (z,coord,sign),fee in facefees.items():ck('terminal_direction_group_source_cap',fee<=sourcefees[z]<=N*f[z]*loss(D[z],lower,upper))
 # Independent age-augmented linear propagation, retaining old source and visited set.
 dist={(u,frozenset(),z):I[u]*pi[u][z] for u in range(nr) for z in range(nz) if pi[u][z]};other=Counter();othermarked=Counter()
 for age in range(N):
  new=defaultdict(F)
  for (u,history,orig),weight in dist.items():
   for z,mass,ins,faces in atoms:
    if not inc[u][z]:continue
    w=weight*mass/m[u]
    if ins[u]:other['inner']+=w;othermarked[('inner',orig)]+=w
    elif any(inc[a][z] for a in history):other['ancestor']+=w;othermarked[('ancestor',orig)]+=w
    else:
     other['normal']+=w*(1-sum(Q[z][u]));othermarked[('normal',orig)]+=w*(1-sum(Q[z][u]))
     for v in range(nr):
      e=w*Q[z][u][v]
      if age+1==N:other['unfinished']+=e;othermarked[('unfinished',orig)]+=e
      elif e:new[(v,history|{u},orig)]+=e
  dist=new
 ck('path_tuple_enumeration_matches_age_set_aggregate',all(other[k]==totals[k] for k in set(other)|set(totals)))
 ck('full_original_source_mark_matches_independent_aggregate',all(marked[k]==othermarked[k] for k in set(marked)|set(othermarked)))
 T=[[flux[u][v]/G[u] if G[u] else F(0) for v in range(nr)] for u in range(nr)];g=[G[u]/sig[u] for u in range(nr)];i=[I[u]/sig[u] for u in range(nr)];beta=[normal_u[u]/G[u] if G[u] else F(0) for u in range(nr)]
 for u in range(nr):ck('effective_killed_kernel_below_native_and_selected_beta',all(T[u][v]<=P[u][v] for v in range(nr)) and beta[u]<=nativeb[u]<=1-sum(T[u]))
 for v in range(nr):ck('aggregate_occupation_includes_unfinished_loss',G[v]==I[v]+sum(G[u]*T[u][v] for u in range(nr)))
 J=sum(sig[u]*i[u]*g[u] for u in range(nr));Dir=sum(sig[u]*T[u][v]*(g[u]-g[v])**2 for u in range(nr) for v in range(nr));Row=sum(sig[u]*(1-sum(T[u]))*g[u]**2 for u in range(nr));Col=sum((sig[v]-sum(sig[u]*T[u][v] for u in range(nr)))*g[v]**2 for v in range(nr))
 ck('full_killed_energy_with_unfinished',2*J==Dir+Row+Col and min(Dir,Row,Col)>=0)
 ck('selected_normal_energy_sourcecap_bound',totals['normal']**2<=2*B0*J)
 # Reuse the same full-posterior arrays for a rich-first/nonrich-arrival aggregate.
 theta=F(3,20);pinner=[sum((mass/m[u] for z,mass,ins,faces in atoms if inc[u][z] and ins[u]),F(0)) for u in range(nr)];rich=[p>=theta for p in pinner];Inr=[I[u] if not rich[u] else F(0) for u in range(nr)]
 nrstates={(u,tuple(),z):Inr[u]*pi[u][z] for u in range(nr) for z in range(nz) if Inr[u]*pi[u][z]};Gn=[F(0)]*nr;nf=[[F(0)]*nr for u in range(nr)];nn=[F(0)]*nr;nb=Counter()
 for age in range(N):
  ns=defaultdict(F)
  for (u,hist,orig),wt in nrstates.items():
   Gn[u]+=wt
   for z,mass,ins,faces in atoms:
    if not inc[u][z]:continue
    ww=wt*mass/m[u]
    if ins[u]:nb['inner']+=ww
    elif any(inc[a][z] for a in hist):nb['ancestor']+=ww
    else:
     normal=ww*(1-sum(Q[z][u]));nn[u]+=normal;nb['normal']+=normal
     for v in range(nr):
      ee=ww*Q[z][u][v]
      if not ee:continue
      if rich[v]:nb['target_rich']+=ee
      elif age+1==N:nb['unfinished']+=ee
      else:ns[(v,hist+(u,),orig)]+=ee;nf[u][v]+=ee
  nrstates=ns
 Kn=[[nf[u][v]/Gn[u] if Gn[u] else F(0) for v in range(nr)] for u in range(nr)];gn=[Gn[u]/sig[u] for u in range(nr)];Jn=sum(Inr[u]*gn[u] for u in range(nr));bn=[nn[u]/Gn[u] if Gn[u] else F(0) for u in range(nr)]
 for u in range(nr):
  ck('nonrich_arrivals_exact_equation_and_domination',Gn[u]==Inr[u]+sum(Gn[v]*Kn[v][u] for v in range(nr)) and Gn[u]<=G[u])
  ck('nonrich_target_kernel_and_selected_normal',all(Kn[u][v]<=P[u][v] and (not rich[v] or Kn[u][v]==0) for v in range(nr)) and bn[u]<=nativeb[u]<=1-sum(Kn[u]))
 ck('nonrich_initial_and_target_rich_stop_conservation',sum(nb.values())==sum(Inr))
 if stage=='ties_stress':ck('nonempty_diagnostic_target_rich_stop',nb['target_rich']>0)
 DN=sum(sig[u]*Kn[u][v]*(gn[u]-gn[v])**2 for u in range(nr) for v in range(nr));RN=sum(sig[u]*(1-sum(Kn[u]))*gn[u]**2 for u in range(nr));CN=sum((sig[v]-sum(sig[u]*Kn[u][v] for u in range(nr)))*gn[v]**2 for v in range(nr))
 ck('nonrich_energy_including_unfinished_rowloss',2*Jn==DN+RN+CN and min(DN,RN,CN)>=0)
 ck('nonrich_energy_no_larger_than_all',0<=Jn<=J)
 ck('nonrich_selected_normal_energy_bound',nb['normal']**2<=2*B0*Jn)
 ck('nonrich_normal_restricts_original_selected_branch',nb['normal']<=totals['normal'])
 nonrich=dict(theta=str(theta),posterior_inner=list(map(str,pinner)),rich_receiver_ids=[u for u in range(nr) if rich[u]],I_nr=list(map(str,Inr)),G_nr=list(map(str,Gn)),initial_rich_stopped_mass=str(sum(I)-sum(Inr)),branches={k:str(v) for k,v in nb.items()},J_nr=str(Jn),J_all=str(J),normal_F_nr=str(nb['normal']),Dirichlet=str(DN),rowloss=str(RN),column_deficit=str(CN),scope='Diagnostic theta-rich test before each receiver source draw, target-rich arrivals stopped. Same posterior/source masks and finite horizon; not a native rich qualification.')
 return dict(stage=stage,name=data['name'],n=n,N_diagnostic_horizon=N,rank_window=[str(lower),str(upper)],sigma_inner=str(inner),source_masses=list(map(str,f)),source_atoms=len(atoms),source_rank_groups=[[[str(a),str(b),ids] for a,b,ids in gs] for gs in groups],P_smoothed=[[str(x) for x in r] for r in P],initial_mass=str(sum(I)),first_stop_and_unfinished={k:str(v) for k,v in totals.items()},inner_ancestor_overlap_only_inner=str(overlap),normal_fraction=str(totals['normal']/sum(I)),unfinished_fraction=str(totals['unfinished']/sum(I)),all_stops_by_original_source={str(k):str(v) for k,v in marked.items()},normal_by_original_source={str(k):str(v) for k,v in origfees.items()},normal_by_current_source=list(map(str,sourcefees)),normal_by_unique_first_face={str(k):str(v) for k,v in facefees.items()},source_capacity_per_generation=[str(f[z]*loss(D[z],lower,upper)) for z in range(nz)],native_B0=str(B0),N_average_shift_W_budget=str(N*(lower+upper)/2*sum(f)),generations=generations,nonrich_arrival_check=nonrich,energy=dict(J=str(J),Dirichlet=str(Dir),rowloss=str(Row),column_deficit=str(Col),effective_selected_normal_beta=list(map(str,beta))),exact_checks=sum(C.values())-before,scope='Actual compact positive source boxes/cube geometry; finite receiver quadrature. Diagnostic smoothed window does NOT exceed native D0 and cannot test native strict K gap or hard entrance. Finite unfinished is separate, never called native terminal. Ordered source kills/history and original source label retained.')
def main():
 rows=[run(st,m,N) for st,m,N in zip(['initial','ties_stress','expanded_2D'],DATA,[1,2,3])]
 out=dict(status='PASS',total_exact_checks=sum(C.values()),check_counts=dict(C),models=rows,scope='Finite smoothed rank and full marked ordered killed-chain accounting only. Not a general root bound or native hard admissibility. Every normal terminal has a unique actual contracted-face assignment; unfinished is distinct and enters aggregate rowloss.')
 (BASE/'r359_numeric_result.json').write_text(json.dumps(out,sort_keys=True,indent=2)+'\n');print(json.dumps(dict(status='PASS',total_exact_checks=sum(C.values()),models=[dict(name=x['name'],checks=x['exact_checks'],normal=x['normal_fraction'],unfinished=x['unfinished_fraction']) for x in rows]),sort_keys=True))
if __name__=='__main__':main()
