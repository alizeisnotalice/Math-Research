R359 smoothed rank and complete marked killed-chain diagnostic

Fresh local standard-library Python processes returned PASS 2,899 exact Fraction assertions: initial 122, same-mass pressure 233, expanded 2D 2,544. These are new checks on the smoothed mechanism and ordered finite path, not a rerun of the old exploration. Reproduce:

```
/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 r359_numeric.py
```

The script is self-contained and writes r359_numeric_result.json beside itself. It embeds the actual source-box and cube fixture parameters rather than importing old temporary scripts. All arithmetic deciding kernel entries, probabilities and budgets is rational; no optimizer or random search is used.

Actual source/cube model. Initial and tie-pressure models have positive source intervals centered at 0,1, masses 1,2, side 1/50. The 2D model has four positive source boxes centered at the unit-square corners, masses 1,2,3,5. Every full receiver cube is checked to capture or miss whole source boxes. All actual m and q are recomputed from the same full f. Receiver weights are finite QUADRATURE weights, not continuous receiver dx; no original hard admissibility is claimed.

Smoothed rank. For each source, equal matched masses form ONE rank atom. Current rank is uniform over that entire block, and target disintegration weights receiver v by xi_z(v)/target-block width. The diagnostic open smoothing windows are (1/8,1/4) in 1D and (1/10,1/5) in 2D. The area of the strip lower<t-s<upper in two rank rectangles is computed by the squared-positive-part formula and independently by exact piecewise-linear overlap integration. Every row survival and target-column formula, source subinvariance, k<=1/window and k(u,v)+k(v,u)<=1/window is checked. These small windows do NOT exceed native D0; therefore no native strict K-gap, availability/hard-entrance, or mass-growth conclusion is tested or forced.

The exact source rank loss is F(D), averaged over the single smoothing window. It is checked against both the total kernel deficit and the piecewise formula. The native full-reference loss B0 is 9/16,9/16,33/20 in the three fixtures, equal here to average-shift times W. It is not charged once per shift in the continuum window.

Complete finite marked path. The original source label is sampled initially from the full posterior and then retained in every state and every stop record. Every later draw uses the SAME full-source posterior at the current receiver, rather than a posterior renormalized after exclusions. Each positive source box is partitioned by all contracted-cube coordinate faces, using inner factor 1/100. Thus source probabilities, shell membership, and direction signs are integrated on complete positive-volume atoms, not point probes.

At each step the order is inner-source stop; ancestor-cube stop; smoothed-rank normal loss or continuation. All visited receiver labels remain in history. A successful continuation beyond the diagnostic horizon is recorded as UNFINISHED. It is neither native normal terminal nor free mass. The path enumeration with ordered history tuples is compared to independent age propagation with history sets, including EVERY first-stop category separately by the retained original-source label. Generation marginal caps and full conservation hold exactly.

| Fixture | Horizon | Normal fraction of initial mass | Unfinished fraction |
|---|---:|---:|---:|
| Initial | 1 | 1259/3600 = 0.349722 | 1837/3600 = 0.510278 |
| Same-mass/self-loop | 2 | 13131/358400 = 0.036638 | 5549/358400 = 0.015483 |
| 2D | 3 | 1043848593/6193515625 = 0.168539 | 44425017/6193515625 = 0.007173 |

The remaining input is inner/ancestor-stopped mass, fully output. In the last two fixtures there is positive inner/ancestor overlap, assigned only to inner according to the priority. No stop category is double charged.

Terminal source and faces. Every selected normal terminal has passed the inner exclusion and therefore has at least one actual contracted-face coordinate. It is assigned uniquely to its first such coordinate and sign. The normal mass summed by these direction groups equals the normal mass summed by current source, and also by original source. Each generation's normal current-source mass is at most f_z F(D_z); each direction subgroup is at most the same source's N-generation cap. Total normal fee is at most N times average-shift times W. Those finite bounds are recorded with the actual fees; no native dimension-dependent root estimate is inferred.

Aggregate energy with unfinished. Summing finite arrivals gives G. Successful edges before the horizon give an effective K<=Pbar. The exact identity G=I+GK holds only when inner, ancestor, normal AND unfinished all remain in its row deficit. The selected normal beta is normal mass at u divided by G_u; it obeys beta<=native rank loss b<=1-K1. The program verifies the three-term energy identity (Dirichlet, row loss, column deficit) and F_normal^2<=2 B0 J for J=sum I_u G_u/sigma_u. Unfinished is not dropped from row loss or silently converted into a native terminal.

Additional nonrich-arrival interface. On the SAME arrays, a diagnostic rich test uses full posterior-inner probability p>=theta with theta=3/20 before a receiver source draw. Rich initial arrivals are excluded from I_nr; transitions to rich targets are stopped. Only nonrich target edges enter K_nr. The code checks G_nr=I_nr+G_nr K_nr, K_nr<=Pbar, G_nr<=G, J_nr<=J_all, and the normal-selected energy inequality F_nr^2<=2 B0 J_nr. The normal part is also a restriction of the original normal branch. Horizon unfinished remains row loss here too.

The initial case has rich receivers 0,1 and J_nr/J_all=9/43, approximately 0.209302. The tie-pressure case has rich receivers 0,2, a genuinely nonzero target-rich stop 2135/8192, and J_nr/J_all approximately 0.187028. The 2D case has no rich receiver and the interface reduces honestly to the all-arrival case. Theta=1/4 was first checked and found empty on these exact offset geometries; the declared 3/20 diagnostic gives a nontrivial target-rich test without claiming the native rich contract.

Scope. This is exact finite actual-source/cube geometry plus receiver quadrature, atom-safe smoothing, full source/history marks, ordered kills, unfinished accounting and selected energy. It is not actual receiver du, the native large shift or hard-entry model, a finite horizon justified by native mass growth, a general occupation bound, or a root theorem. No new remainder is declared paid by changing witness labels or forgetting unfinished paths.
