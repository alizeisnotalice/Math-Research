# R359 — Rebuild the original late-flow ledger with the smoothed rank kernel

**Migration theorem.** In the same certified hard-matched slot and at the same original B_H, the R357 bound remains valid with a newly constructed remainder Fbar_low:

    B_H <= Fbar_low +[(13/3)epsilon+gamma_eff+beta+alpha_rec+c_eff]X_q
       +[C_epsilon,n+8s+C_dir,n+C_multi,n]W
       +(D_top,n+C_hit,n+s)W_ex.                              (1)

The constants are exactly the R357 constants below. Fbar_low is defined by a new witness extension and new marked path; it is NOT identified with the old F_low. In particular its terminal source densities and threshold sets are recomputed. No comparison of the sizes of these two remainders is claimed. This is a migration of an existing bound, not a payment of the remaining integral.

## 1. Start before any old rank witness was chosen

Keep the original full f, g=g_ex<=f, W=integral f, W_ex=integral g, E, real Lebesgue du, and

    c_u(y)=1_(Q_(R_u)(u))(y),  m_u=integral f c_u=q_u R_u^n,
    q_-=3lambda/4<=q_u<=lambda,  a<=R_u<=b<=2a,
    rho_y(du)=c_u(y)du/m_u,  xi_y(du)=q_u rho_y(du),
    J_y(r)=rho_y{R<=r},  U_y(t)=rho_y{m>t},
    ell=b^(-n)delta_b+n r^(-n-1)1_(a,b)dr,
    X_q=integral_E q_u du,  A_n=1+n log(b/a).

All data are still defined from full f. Set x=sqrt(n), s=1+x, K=exp(x), B=s/q_-, epsilon=119/3072. The ORIGINAL quantities are

    omega_y(u)=R_u^n integral_[R_u,b] Omega_y(u,r)ell(dr),
    a_y(u)=q_u omega_y(u),
    eta_y(u)=(1-2lambda B/[a_y(u)U_y(Km_u)])_+,
    chi_y(u,r)=1_{U_y(Km_u)>epsilon J_y(b)}
                 1_{U_y^r(Km_u)<=1/q_-}.

Retain the original zero convention and 0<=Omega<=1. The full small-endpoint v, high-past, outside-center, far-mass, H, full J_y(r), and history qualifications remain inside Omega or in their original conditional marks. Define the ORIGINAL pre-witness measure by its projection

    dF(y,u,r)=g(y)c_u(y)eta_y(u)Omega_y(u,r)chi_y(u,r)
                 1_{r in[R_u,b]}dy du ell(dr),
    |F|=G_late[g].                                            (2)

We work on its full marked extension, preserving v and every old history label; (2) only suppresses those labels in notation. Nothing below resamples or recalculates them. The established pre-routing R348/R349 estimate is the starting input:

    B_H<=G_late[g]+[(13/3)epsilon+gamma_eff]X_q
                     +C_epsilon,n W+(D_top,n+C_hit,n)W_ex.    (3)

This is read before the R350 witness insertion, not inferred by subtracting a fee from a later inequality. Its historical entrance certification is retained as an input; this note does not reprove the whole earlier reduction.

## 2. New witness and its exact mark-preserving capacity

Use precisely the R358 smoothed COMPLETE rank kernel, with

    D0=1+x+log(4/3),  Delta=2(1+x),  w=Delta-D0,
    Qbar_y(u,dv)=average_(h in(D0,Delta)) Q_y^h(u,dv).

The interval is open and its endpoints have zero shift measure. R358 proves, with all mass atoms included:

    Qbar_y(u,E)<=1,
    Qbar_y(u,{v:c_v(y)=1,m_v>Km_u})=Qbar_y(u,E),
    xi_y Qbar_y<=xi_y.                                       (4)

If eta_y(u)>0, then U_y(Km_u)>2B and xi_y{m>Km_u}>Delta, so Qbar_y(u,E)=1. Hence the extension

    dFbar_0=dF Qbar_y(u,dw_0)                                 (5)

has EXACTLY the same total G_late as (2). One may keep the sampled shift and randomized source/target ranks as further marks. The new kernel is independent of the original physical clock r; that clock is not shifted.

Contracting only the old clock gives

    t_y(u)=R_u^n integral_[R_u,b]eta_y(u)Omega_y(u,r)
                                       chi_y(u,r)ell(dr),
    0<=t_y(u)<=1.

The sourcewise column in (4) gives the new actual incoming marginal

    kappa_bar_0(w)dw=integral g(y)integral t_y(u)xi_y(du)
                                      Qbar_y(u,dw)dy,
    kappa_bar_0(w)<=q_w integral g(y)c_w(y)dy/m_w<=q_w.         (6)

Also G_late<=integral g(y)xi_y(E)dy<=X_q. These facts concern the newly constructed measure (5), not the archived fixed-shift witness.

## 3. Rebuild the peeling split, with only one deletion bill

Let C4 be the fourth power of the already audited dimension-independent L^(4/3) maximal constant, and fix

    theta=1/4,  beta=epsilon/16,  T=beta theta q_-s^3/C4.

For A subset E define

    D_A(z)=integral_A c_w(z)R_w^(-n)dw,
    e_A(z)=1_{D_A(z)>s}(1-T/f(z))_+,
    p_A(w)=integral e_A(z)pi_w(dz),
    pi_w(dz)=f(z)c_w(z)dz/m_w,

with e_A=0 where f=0. Start E_0=E and set

    E_(j+1)={w in E_j:p_(E_j)(w)>1-theta},
    C=intersection_j E_j.

These sets are determined by full f and E, not by either old or new kappa. Their occurrence in the new flow is nonetheless reconstructed by the restriction w_0 in C. Exactly

    G_late=Gbar_del+Gbar_core.                                (7)

For completeness the R351 source potential is

    Psi_z(d)=f(z)min(d,s)+min(f(z),T)(d-s)_+.

For a deleted set E_j\E_(j+1), its q mass times theta is bounded by
integral [Psi_z(D_(E_j))-Psi_z(D_(E_(j+1)))]dz. The nonnegative increments telescope, including occupancy crossing s. The actual adjoint bound integral D_E^4<=C4 X_q/q_- therefore gives

    X_q(E\C)<=beta X_q+4sW.

Using (6) yields Gbar_del<=beta X_q+4sW. This is one countable peeling bill, incorporating the first R350 diffuse-witness deletion; no separate low-D, clipped-source, or one-round diffuse fee is added.

The actual retained initial witnesses satisfy the honest limiting guard

    pi_(w_0){D_C>=s, f>2T}>=1/2.                              (8)

The occupancy gate is closed and the posterior inequality non-strict. No later receiver is automatically required to lie in C.

## 4. Repartition the NEW initial witness by the OLD physical time

Set sigma_353^n=min(1,s/A_n). On Gbar_core use the disjoint tests

    clock: r>=sigma_353 R_(w_0);
    inner: r<sigma_353 R_(w_0), y in sigma_353 Q_(w_0);
    cross: r<sigma_353 R_(w_0), y notin sigma_353 Q_(w_0).

Equality belongs to clock or inner as displayed. Let their masses be Gbar_clock, Gbar_inner, and |Rbar|. Then

    Gbar_core=Gbar_clock+Gbar_inner+|Rbar|.                    (9)

The old inclusive tail ell([t,b])=t^(-n), including its b atom, and m_(w_0)>K m_u give

    integral_[R_u,b]1_{r>=sigma_353 R_(w_0)}ell(dr)
      <=[lambda/(q_-K sigma_353^n)]R_u^(-n).

Deleting only positive bounded gates and using (4) and g<=f proves

    Gbar_clock<=c_eff X_q,
    c_eff=(lambda/q_-)exp(-x)max(1,A_n/s)                     (10)

on a potentially nonempty original branch. The actual-center inner envelope and sourcewise columns give

    Gbar_inner<=sigma_353^n A_n W_ex<=sW_ex.                  (11)

Here the envelope is integral 1_{y in sigma_353 Q_w}R_w^(-n)dw<=sigma_353^n A_n. This is real receiver integration, not a source density bound.

Every Rbar tuple keeps (y,v,u,r,w_0) and satisfies

    m_(w_0)>K m_u>K^2 m_v,
    r<sigma_353 R_(w_0),  y notin sigma_353 Q_(w_0).           (12)

The original source y still lies in Q_(w_0). The clock and source crossing in (12) bind ONLY w_0. None is transferred to later path receivers.

## 5. New full path, precise stopping order, and conservation

Define the full-f transition Pbar(u,dw)=integral pi_u(dz)Qbar_z(u,dw). By (4) and q_u du pi_u(dz)=f(z)dz xi_z(du),

    (q du)Pbar<=q dw.                                         (13)

Set

    N=max(1,ceil(log[(lambda/q_-)(b/a)^n]/log K)),
    sigma_*^n=min(1,s/(N A_n)),
    p(w)=pi_w(sigma_*Q_w),  theta=1/4.

Start at the actual Rbar witness w_0 with all old marks. At visit j:

1. If p(w_j)>=theta, stop the entire path as its first rich visit.
2. Otherwise draw z_j from the unchanged full-f pi_(w_j).
3. If z_j lies in sigma_*Q_(w_j), stop at its first inner-source visit.
4. Otherwise, if z_j lies in Q_v union Q_u union union_(i<j)Q_(w_i), stop at its first ancestor recapture.
5. Otherwise apply the COMPLETE Qbar_(z_j)(w_j,.). Its missing probability terminates the path normally; its surviving edge gives w_(j+1), with all marks retained.

These are successive positive restrictions, without conditioning on any later success and without renormalizing a rejected probability. The original positive-late availability is NOT reused after changing sources. In step 5 one may sample the actual uniform shift and the source rank, retaining them on continuation and on missing-rank termination.

Every surviving edge has strict mass growth K. All masses are in [q_-a^n,lambda b^n], so N surviving edges are impossible, including an exact-power endpoint. There are at most N visits. Termination at the last visit is actual missing-rank termination, not an artificially added horizon stop.

The ordered process is dominated at every generation by (13). Thus its actual arrival density kappa_bar_j(w)<=q_w, even after all preceding history-dependent deletions. It gives the exact terminal partition

    |Rbar|=Bbar_joint+Bbar_rec+Fbar_shell,                     (14)

where joint combines rich and inner-source stops and Fbar_shell consists of normal rank terminals that passed all prior tests.

The conditional joint stopping probability is

    1_{p>=theta}+p1_{p<theta}<=p/theta.

The actual-center inner envelope and (13), summed over at most N visits, therefore prove

    Bbar_joint<=N sigma_*^n A_n W/theta<=4sW.                  (15)

The two stopping types share this ONE bill. For ancestor recapture, given a live history BEFORE the current source tests, the genuine posterior obeys

    pi_(w_j)(Q_v union Q_u union union_(i<j)Q_(w_i))
      <=[m_v+m_u+sum_(i<j)m_(w_i)]/m_(w_j)<1/(K-1).

Restricting this event by the preceding non-inner test only decreases its probability. Consequently

    Bbar_rec<=[N/(K-1)]|Rbar|<=alpha_rec X_q,
    alpha_rec=N/(exp(x)-1).                                  (16)

This replaces, rather than adds to, the earlier whole-R recapture use. No per-generation Delta W terminal bill is added: the normal terminals remain Fbar_shell to be split next.

Every visited receiver on Fbar_shell satisfies pi_w(Q_w\sigma_*Q_w)>3/4. Every sampled z_j, including the last one, lies in that shell and avoids all previous ancestor cubes. The former is a full-f posterior condition; the latter is a sample-level condition enforced by steps 3–4. Both hold without asserting cross-path source disjointness.

## 6. Recompute the terminal source densities and direction split

Let Tbar_j be the actual NORMAL-terminal measure at visit j after all of the preceding tests. Disintegrating its still-retained history gives

    dTbar_j(z,w)=f(z)c_w(z)kbar_j(z,w)dz dw/m_w,
    0<=kbar_j(z,w)<=kappa_bar_j(w)<=q_w.                      (17)

The factor kbar_j contains the nonrich predicate, actual inner and ancestor tests, and the missing Qbar rank probability. The full-f draw is made BEFORE these restrictions. In particular no terminal-conditioned posterior is substituted for pi_w.

Define NEW functions, using these new terminal measures,

    Lbar(z)=sum_(j<N) integral c_w(z)kbar_j(z,w)dw/m_w,
    Lbar_i(z)=sum_(j<N) integral c_w(z)kbar_j(z,w)
                       1_{|w_i-z_i|>sigma_*R_w/2}dw/m_w.     (18)

Then Fbar_shell=integral f Lbar, 0<=Lbar_i<=Lbar<=sum_i Lbar_i. Every terminal source is in its receiver shell, hence at least one face event holds. Set L_n=log(n+2),

    B_1=(1-sigma_*)+[n(1-sigma_*)+sigma_*]log(b/a),
    C_dir,n=N B_1 L_n.

The real one-face center envelope from R356, applied to (17), gives Lbar_i(z)<=N B_1 for each i, so also max_i Lbar_i<=N B_1. Define the NEW source set

    Sbar_dir={z:Lbar(z)>0, max_i Lbar_i(z)>=Lbar(z)/L_n}.

Restricting the existing terminal measure by this set yields exactly

    Fbar_shell=Fbar_dir+Fbar_disp,
    Fbar_dir<=C_dir,n W.                                    (19)

Let Lbar^d,Lbar_i^d be the density factors after this restriction. On their positive columns,

    Lbar_i^d<Lbar^d/L_n for all i.                            (20)

These are new flow-dependent ratios. No old R356 source set, density or ratio is transferred to the new process.

## 7. Recompute the high-face source threshold and the final remainder

Let d(z,w)=#{i:|w_i-z_i|>sigma_*R_w/2}, and set

    m=1+ceil(8L_n), t=1-sigma_*,
    C_m=P{Bin(n,t)>=m}+n log(b/a)P{Bin(n-1,t)>=m-1},
    C_multi,n=4N C_m.

Tails above the number of trials are zero. These binomial expressions are exact product-VOLUME coefficients in the real receiver-center envelope; no source or path coordinate independence is assumed. The center-capacity proof has a flat contribution P{Bin(n,t)>=m} and a radial shell contribution n log(b/a)P{Bin(n-1,t)>=m-1}. Together with (17), it applies equally to the newly restricted terminal measure.

Define Hbar(z) to be the NEW source density factor of the event d(z,w)>=m inside Fbar_disp. Then

    0<=Hbar<=Lbar^d,  Hbar<=N C_m.                            (21)

First pay every terminal tuple over a source with Lbar^d>0 and Hbar>=Lbar^d/4. On the complementary source set pay just its tuples with d>=m. These two positive pieces have combined density

    Pbar_multi=Lbar^d 1_{Lbar^d>0,Hbar>=Lbar^d/4}
                        +Hbar 1_{Hbar<Lbar^d/4}<=4Hbar,

with zero on Lbar^d=0. They are disjoint and give the exact partition

    Fbar_disp=Fbar_multi+Fbar_low,
    Fbar_multi<=C_multi,n W.                                 (22)

This DEFINES Fbar_low. At every positive remaining source column,

    Lbar_low=Lbar^d-Hbar>3Lbar^d/4,
    Lbar_(i,low)<=Lbar_i^d<4Lbar_low/(3L_n).                  (23)

Every final tuple has 1<=d<m. Equation (23) includes the normalization loss; the old threshold 1/L_n is not asserted unchanged. Low face count and (23) concern terminal tuples/terminal source columns only, not earlier draws. All earlier whole-path shell/freshness qualifications and the old initial crossing marks remain.

For sigma_*=1 the process stops rich immediately, so Fbar_shell=0; the endpoint center estimates may simply be taken as harmless upper bounds. All zero-density source columns are treated without division.

## 8. Exact accounting back to the same original B_H

Equations (7),(9),(14),(19),(22) are an exact partition of the newly extended original measure:

    G_late=Gbar_del+Gbar_clock+Gbar_inner
             +Bbar_joint+Bbar_rec+Fbar_dir+Fbar_multi+Fbar_low. (24)

The eight terms are nonnegative and the stopped-path construction is mass preserving through its finite terminal partition. Its total costs, in the same order, are

    beta X_q+4sW;  c_eff X_q;  sW_ex;
    4sW;  alpha_rec X_q;  C_dir,n W;  C_multi,n W;
    and the unpaid Fbar_low.

Insert (24) into the pre-witness estimate (3). This proves (1) for the SAME original B_H. It does not replace a residual in an old upper bound merely because another residual is smaller.

The constants are

    beta=epsilon/16,
    C_epsilon,n=(lambda/q_-)[(2+3x+2exp(-x))/epsilon+1+x],
    D_top,n=s+log(4/3),
    C_hit,n=2(lambda/q_-)s[1+log(1/epsilon)].

If the original high-past necessary condition fails, G_late and every new flow above vanish; set gamma_eff,c_eff,alpha_rec,C_dir,n,C_multi,n to zero for that branch. Otherwise the unchanged original guard yields x>1/epsilon, N<=x and n(1-sigma_*)<=log n. The existing analytic bounds give

    gamma_eff=2(lambda/q_-)exp(-x)<epsilon/16,
    c_eff<epsilon/16,  alpha_rec<epsilon/16,
    C_dir,n<=3sqrt(n)log^2(n+2),
    C_multi,n<=4sqrt(n)A_n/(n+2)^4<=4sqrt(n).                 (25)

These guards belong to the initial original branch, not to newly sampled sources. The exact coefficients, rather than only their coarse upper bounds, are retained in (1).

The original entrance remains

    T_entrance<=8lambda H W+2d_eff A_n W_nu/H+2B_H.

Entrance factor 2 and historical exterior Lambda=128/119 multiply every term in (1). The receiver coefficient is

    13/36+2Lambda(beta+gamma_eff+alpha_rec+c_eff).

ONLY if the historical CZ 1/256 lies in this same certified X ledger, the combined coefficient is

    853/2304+2Lambda(gamma_eff+alpha_rec+c_eff)<889/2304.

That unallocated balance does not pay any other integral. No extra R350 new-source clipping charge, R351 per-round terminal charge, former recapture charge, or second use of negative overlap is added.

The independent unpaid slots remain: general soft C_H-S_H, crossing I_H, hard-contract complements and heavy comparable-mass terms; wide-distance/low-pe/extreme-aspect and other threshold complements; original initial I_time, deleted-jump J_time, future-deleted-source D_time; H choice, all source/physical-scale/outer-integral aggregation, truncation and limits. The original ell endpoint is preserved; auxiliary rank termination does not settle historical time atoms.

## 9. Scope of the migration and local verification

The R358 absolutely continuous edge and its source-product upper comparisons are now available for this newly rebuilt process. They have NOT been used to pay Fbar_low in (1). The terminal cap average_h min(D,h)<=Delta is valid but is not charged in addition to (24). No lower capture-square bound, logarithmic injection energy bound, or general root weak-type theorem follows from this migration.

The following exact checks verify the unchanged outer constants, the ordered rich/inner split, the combined high-face source split and its normalization guard. They do not simulate the original difficult continuum field. Analytic migration of the real marked process is given above; the R358 self-contained 401 rank-block checks separately certify its kernel formulas.

~~~python
from fractions import Fraction as F
counts={'outer':0,'joint_stop':0,'source_split':0,'ratio':0}
eps=F(119,3072);Lam=F(128,119);beta=eps/16
assert 2*Lam*F(13,3)*eps==F(13,36);counts['outer']+=1
assert F(13,36)+2*Lam*beta+F(1,256)==F(853,2304);counts['outer']+=1
assert F(853,2304)+2*Lam*3*eps/16==F(889,2304);counts['outer']+=1
assert 1-F(889,2304)==F(1415,2304);counts['outer']+=1
for den in range(2,21):
    for j in range(den+1):
        p=F(j,den);theta=F(1,4)
        rich=F(1) if p>=theta else F(0)
        inner=F(0) if rich else p
        assert rich+inner<=p/theta
        assert rich+inner+(1-rich)*(1-p)==1
        counts['joint_stop']+=1
for total in [F(0),F(1,7),F(1),F(17,3)]:
    for j in range(101):
        high=total*F(j,100)
        whole=total>0 and high>=total/4
        paid=total if whole else high
        low=F(0) if whole else total-high
        assert paid+low==total and paid<=4*high
        counts['source_split']+=1
        if low:
            assert low>3*total/4
            for Ln in [F(3,2),F(2),F(5)]:
                face=total/Ln-F(1,1000)*total/Ln
                assert face<4*low/(3*Ln)
                counts['ratio']+=1
print('PASS migration checks',counts,'total',sum(counts.values()))
~~~

Actual execution passed 861 checks: 4 outer-ledger identities, 228 ordered rich/inner probability checks, 404 merged source splits and 225 normalization inequalities. These are exact algebra checks, not numerical proof of a general dimension bound or realization of the original high-past field. Only `/tmp/r359_migration.md` was written; no other-author files or Git state were changed.
