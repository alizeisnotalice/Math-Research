# R359 — Causal nonrich support for the actual-flow energy

This lemma applies to the newly reconstructed R359 process, and separately to the old process if desired. It does not identify their inputs or remainders. It improves the support of the energy quantity without conditioning on future terminal success.

Keep the complete actual source f and receiver measure sigma=q du. Let p(u)=pi_u(sigma_* Q_u), theta=1/4, and A={u:p(u)<theta}. The process tests this deterministic receiver predicate before drawing its next genuine full-f source. At a rich receiver outside A it stops immediately, as already charged in the joint rich/inner budget.

Let I=i sigma, G=g sigma be the pre-rich input and total pre-rich arrivals of this same process; let T be all real surviving continuation edges. Since a rich arrival never continues, T has its first coordinate in A. For the alive-at-source-draw measures set

    I_A=1_A I, G_A=1_A G, T_A=1_(A x A) T.

Every noninitial arrival in A comes from exactly one surviving edge with target in A. Thus

    G_A=I_A+(T_A)_target.

This identity discards no continuation leading to an unpaid selected normal terminal: a path that arrives outside A stops rich and cannot contribute to that terminal. The old rich stopping measure remains exactly where previously charged; it is not charged a second time. No posterior is conditioned on passing a source test. All old sources, old clock and history labels can be retained in T_A before projecting.

The genuine source draw and subsequent positive restrictions give

    T_A(du,dv)<=G_A(du) Pbar(u,dv)1_A(v).

Disintegrate T_A=G_A K_A and take K_A=0 on {g_A=0}. Then K_A<=Pbar, its two endpoints are in A, and sigma K_A<=sigma. In fact sigma_A K_A<=sigma_A with sigma_A=1_A sigma. The exact balance is

    G_A=I_A+G_A K_A,  i_A=1_A i, g_A=1_A g.

The selected R359 normal-terminal receiver measure Zbar_low is supported in A. Its density beta_A relative to G_A satisfies

    0<=beta_A<=bbar,  beta_A<=1-K_A1,

because it is a positive restriction of genuine native rank termination, disjoint from continuation to A. Continuations to rich targets are additional effective row loss, but are not relabelled normal termination. Zero-density conventions are harmless.

For C_term=(D0+Delta)/2, the source-rank loss formula gives

    B_A=int beta_A d sigma<=int bbar d sigma<=C_term W.

On the finite native horizon, g_A<=N. The exact R358 energy calculation, now for K_A, yields

    2 J_A = int sigma(du)K_A(u,dv)[g_A(u)-g_A(v)]^2
            +int (1-K_A1)g_A^2 d sigma
            +int g_A^2 d(sigma-sigma K_A),
    J_A=int i_A g_A d sigma=int_A i g d sigma<=J_inj.

All terms are finite and nonnegative. Cauchy for beta_A sigma gives

    Fbar_low^2<=2 B_A J_A<=2 C_term W J_A.

Thus a sufficient new geometry target is J_A<=C log^B(n+2)X_q. It is weaker than demanding the corresponding bound for all pre-rich arrivals, but is not yet proved. There is no guaranteed strict or fixed-percentage decrease from J_inj to J_A.

What is now legal on EVERY state of this energy is the actual full-f posterior condition

    pi_u(Q_u minus sigma_*Q_u)>3/4.

This is a present-state predicate certified before the next source draw. It is not the terminal low-face predicate, terminal source-direction dispersion, a source-density cap, or a condition that the old clock crossing has migrated to later receivers. The previous R358 energy had not imposed this support. Current-source inner exclusion and history ancestor exclusions enter the labelled continuation measure after the source draw, not a changed posterior.

The statement is also a general finite-horizon causal support identity. Finite diagnostic computations in r359_numeric.py retain any unfinished horizon mass as a separate stopped output when testing energy. Original native strict mass growth instead makes that artificial output identically zero at N. These two scopes must not be confused. Independent finite support-algebra tests and the full proof review are recorded in the audit; no numerical fit is used to infer a dimension exponent.
