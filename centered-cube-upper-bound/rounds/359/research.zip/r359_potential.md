# R359: actual inner-target contraction and the remaining shell source energy

**Status.** A new, unconditionally valid sector estimate is proved below: after the causal nonrich restriction, all actual continuations whose common source is inner at the target have L2 operator norm at most c_*<=1/2, with the stronger geometric value c_*=sqrt(theta min(1,alpha^n A_n/w)). They can be summed without a path-length factor. This gives a coercive inequality and an injection-anchored mixed-source inequality for the actual remaining shell-to-shell traffic. The required shell quadratic estimate is not proved. There is no new ledger payment and no unconditional polylogarithmic bound for J in this note.

Only this file is written. No change to the original clock, labels, full f, rank construction, or receiver measure is made.

## 1. Actual nonrich process and notation

Use the rebuilt averaged-rank process of R359, with

    sigma(du)=q_u du,  Xq=sigma(E),  W=integral f,
    pi_u(dz)=f(z)c_u(z)dz/m_u,
    xi_z(du)=c_u(z)R_u^(-n)du,
    sigma(du)pi_u(dz)=f(z)dz xi_z(du).

Write alpha for the R355 spatial shrink scalar (to distinguish it from sigma), and set

    L_z(u)=1_{z in alpha Q_u},
    H_z(u)=1_{z in Q_u \ alpha Q_u}.

The parameter alpha is the actual one already fixed by the process; it is not optimized here. With theta=1/4, let

    E_nr={u: pi_u(alpha Q_u)<theta}.

At each generation the deterministic rich predicate is tested before counting an arrival into the present G. Keep only the nonrich arrivals. Actual continuation into a rich target is treated as the already existing rich stop. This gives exactly the parent's causal restriction

    I=i sigma,  G=g sigma,  G=I+G K,  0<=i<=1,
    g supported on E_nr,  K<=Pbar,  sigma K<=sigma.

Here I is the original late entrance after cascade and clockcross, restricted to E_nr. It is not replaced by an arbitrary injection. G is all these nonrich arrivals, not just those with eventual selected low-face termination. The known finite horizon ensures g is in L2(sigma); no numerical horizon estimate will enter the result.

The full old marks, including original source, clock and ancestor list, remain on histories. The sampled source at each continuation is the true full-f posterior pi_u. Inner-source stopping happens before rank continuation, so every continued edge has H_z(u)=1.

The R358 averaged kernel satisfies

    Qbar_z(u,dv)=k_z(u,v)xi_z(dv),
    xi_z Qbar_z<=xi_z,
    0<=k_z(u,v),  k_z(u,v)+k_z(v,u)<=1/w,
    w=1+sqrt(n)-log(4/3).

All rank atoms use the original randomized full-atom intervals.

## 2. Source-labelled aggregation: no hidden independence assertion

Let A_j(dh,du) be the actual alive nonrich history measure at generation j. Its u marginal is G_j and sum_j G_j=G. Conditional on (h,u), actual continued traffic is a submeasure of

    pi_u(dz) H_z(u) Qbar_z(u,dv) 1_{E_nr}(v).

The submeasure retains all ancestor-recapture and other history gates. In particular these gates can depend on h,z,v and rank marks; independence of gates from the rank kernel is not assumed. Sum the actual continued measures over j and histories to obtain T(du,dz,dv). Then

    T <= G(du) pi_u(dz) H_z(u) Qbar_z(u,dv) 1_{E_nr}(v).   (2.1)

Its (u,v) marginal is the actual aggregate transition traffic G(du)K(u,dv). Disintegrate T with respect to G, setting the resulting kernel to zero on {g=0}. Define the two positive receiver subkernels C,S by retaining respectively L_z(v), H_z(v) in that disintegration. Since Qbar only routes to cubes containing z,

    K=C+S.                                                 (2.2)

C means the sampled source is inner at the target. S means it is shell at both endpoints. This is a partition of actual edge traffic, not a relabelling of future terminals. On rows where g=0, all three kernels may be taken zero. Inequality (2.1), rather than any assertion about posterior distributions after conditioning on survival, proves all the domination statements below.

## 3. Inner-target traffic is a strict L2 contraction

The row estimate is C1<=1. The sourcewise column estimate gives, as measures in v,

    sigma C(dv)
      <= integral f(z)dz L_z(v) 1_{E_nr}(v)
                          integral xi_z(du) Qbar_z(u,dv)
      <= integral f(z)dz L_z(v) xi_z(dv) 1_{E_nr}(v)
       = sigma(dv) pi_v(alpha Q_v)1_{E_nr}(v)
      <= theta sigma(dv).                                  (3.1)

Dropping H_z(u) and the actual gates here is legitimate because everything is nonnegative. The use of full f in the incidence identity is essential.

For every real h in L2(sigma), row Cauchy--Schwarz and (3.1) yield

    integral |Ch|^2 d sigma
      <= integral C1(u) C(h^2)(u)d sigma(u)
      <= integral h^2 d(sigma C)
      <= theta integral h^2 d sigma.

Thus

    ||C||_(2->2)<=sqrt(theta)=1/2.                          (3.2)

No source-density lower bound or unspent BH square is used. This is an unconditional estimate for a real portion of actual repeated traffic.

### 3a. Stronger row estimate from actual inner-center geometry

The parent supplied a further geometric strengthening. Put d=alpha^n and A_n=1+n log(b/a). For every fixed source z, the R355 actual-center estimate is

    integral L_z(v)xi_z(dv)<=d A_n.                         (3.3)

For completeness, writing t=(2||v-z||_infinity)^n, contributing centers have t<=d b^n and R_v^n>=max(a^n,t/d). The volume of {v:(2||v-z||_infinity)^n<=t} equals t. Therefore the integral is bounded by

    integral_0^(d a^n)dt/a^n
      + integral_(d a^n)^(d b^n)d dt/t = d A_n.

This is receiver geometry, not a cap on f. Combining k<=1/w, (2.1), (3.3), and the actual full-f probability pi_u gives

    C1(u)<= (1/w)integral pi_u(dz)integral L_z(v)xi_z(dv)
          <=d A_n/w.

Thus C1<=r_*=min(1,d A_n/w). Repeating the preceding L2 proof retains r_* in the row Cauchy--Schwarz step:

    ||C||_(2->2)<=c_*:=sqrt(theta r_*)<=1/2.                (3.4)

For the actual R355 choice d=min(1,s/(N A_n)), s=1+sqrt(n),

    c_*<=sqrt(theta min(1,s/(N w))).                       (3.5)

Since w=s-log(4/3), this is of order 1/(2 sqrt(N)) when N is large. No inverse mass moment occurs: pi_u is integrated as a full-f probability. N appears only in the already fixed shrink geometry, and improves the coefficient instead of multiplying a fee.

## 4. Coercivity with one explicitly unpaid shell square

Define the geometric shell incidence operator on nonnegative receiver functions by

    (Sh h)(z)=integral H_z(u)h(u)xi_z(du).

The notation Sh denotes this source map; S remains the shell-to-shell receiver kernel. From the actual flow balance,

    J:=integral i g d sigma = ||g||_2^2-<g,Kg>_sigma.

Equations (2.2)--(3.2) imply

    J >= (1-sqrt(theta))||g||_2^2-<g,Sg>_sigma.             (4.1)

Positive domination in (2.1), the actual incidence identity, and symmetrization of g(u)g(v)H_z(u)H_z(v) give

    <g,Sg>_sigma
      <= integral f(z)dz integral xi_z(du)xi_z(dv)
                     g(u)g(v)H_z(u)H_z(v)k_z(u,v)
      <= (1/(2w)) integral f(z)[Sh g(z)]^2 dz.              (4.2)

The actual history-dependent kernel need not itself be symmetric. Only its positive upper envelope is symmetrized in (4.2). Consequently

    J >= (1/2)||g||_2^2-(1/(2w)) integral f(Sh g)^2.        (4.3)

The upper bound in (4.2) is used in the correct direction in (4.1); it is not declared a lower capture bound.

A precise payable conditional branch is now available: if, for this actual g,

    integral f(Sh g)^2 <= rho w ||g||_2^2,  0<=rho<1,        (4.4)

then J>0 and Cauchy--Schwarz imply (the zero case is immediate)

    J >= ((1-rho)/2)||g||_2^2,
    J^2 <= ||i||_2^2 ||g||_2^2 <= Xq ||g||_2^2,
    J <= 2Xq/(1-rho).                                     (4.5)

If 1/(1-rho)<=C log^A(n+2), this is the requested scale. Throughout this note Fbar_low denotes the new R359 selected terminal mass. With b_*=(D0+Delta)/2, the R358 energy identity applied through the R359 process migration gives Fbar_low^2<=2b_*W J; (4.5) gives, for every epsilon>0,

    Fbar_low <= epsilon Xq + b_* W/((1-rho)epsilon).           (4.6)

These are the full constants for Fbar_low in its own units; any outer ledger normalization multiplies (4.6) as already specified there.

The sharper (3.4) replaces 1/2 in (4.3) by 1-c_*. Under the same square condition (4.4), set

    gamma=1-c_*-rho/2.

Whenever gamma>0, including the wider range rho<2(1-c_*), one has

    J<=Xq/gamma,
    Fbar_low<=epsilon Xq + b_* W/(2gamma epsilon).            (4.7)

Thus the geometric row estimate enlarges the admissible shell-square threshold from rho<1 toward rho<2. It does not establish that threshold for the actual g.

Condition (4.4) is UNPROVED. In particular, shell volume does not bound arbitrary f mass, and pi_u(inner)<1/4 is not a bound on the source-side density Sh g. This square is an occupation-weighted shell source square, not the old BH prefix capture square. It cannot spend the old negative-square credit again.

## 5. A version anchored to the actual injection

The same contraction eliminates inner-target excursions while retaining original i. Let

    R_C=(Id-C)^(-1)=sum_(j>=0) C^j,  a=R_C i.

The series converges in L2 by (3.2), a>=0, and

    ||a||_2 <= 2||i||_2 <= 2 sqrt(Xq).                      (5.1)

There is NO assertion a<=2 pointwise. Rearranging g=i+C^*g+S^*g gives

    g=R_C^*i+R_C^*S^*g,
    J=<i,R_C^*i>+<g,S a>.                                 (5.2)

The first term is at most 2||i||_2^2. For the second, the nonsymmetric product uses only k<=1/w, so

    J <= 2||i||_2^2+(1/w) integral f(z)Sh g(z)Sh a(z)dz
      <= 2Xq+(1/w) integral f Sh g Sh[(Id-C)^(-1)i].         (5.3)

Using (3.4) improves every factor 2 in (5.1) and the first term of (5.3) to L_*=(1-c_*)^(-1):

    ||a||_2<=L_*||i||_2,
    J<=L_*||i||_2^2+(1/w)integral f Sh g Sh a.              (5.4)

The coefficient of the mixed source term is 1/w, not 1/(2w). Equation (5.2) is algebra for the actual aggregate kernel; it does not restart paths or move original clock labels. Original late gates remain in i, and all actual history gates remain in C and S.

A bound on this particular mixed square by B w Xq would yield J<=(2+B)Xq. This is potentially weaker than demanding an operator norm bound for every receiver amplitude: the second factor is generated from the actual entrance. It is still an unpaid term. No extra late-entrance estimate has been established here.

## 6. Exact finite algebra diagnostic actually executed

Python 3 Fraction arithmetic was run locally. This verifies signs and resolvent orientation on a finite substochastic DAG; it is not numerical evidence of the unproved cube/source estimate (4.4). Six states have reference weights one,

    C[u,u+1]=1/4,  S[u,u+2]=1/2,
    i=(1,1/2,0,1/3,0,1/4),

with nonexistent entries zero. Exact forward/backward substitutions give

    g=(1,3/4,11/16,169/192,433/768,851/1024),
    J=69163/36864,
    <i,R_C^*i>=57883/36864,
    <g,S R_C i>=235/768.

The last two numbers sum exactly to J. The complete energy identity, the bound <i,R_C^*i><=2||i||^2, and (4.1) all pass. Reproducible code:

```python
from fractions import Fraction as Q
n=6
C=[[Q(0) for _ in range(n)] for _ in range(n)]
S=[[Q(0) for _ in range(n)] for _ in range(n)]
for u in range(n-1):
    C[u][u+1]=Q(1,4)
    if u+2<n: S[u][u+2]=Q(1,2)
K=[[C[u][v]+S[u][v] for v in range(n)] for u in range(n)]
i=[Q(1),Q(1,2),Q(0),Q(1,3),Q(0),Q(1,4)]
g=[]
for v in range(n):
    g.append(i[v]+sum(g[u]*K[u][v] for u in range(v)))
def dot(x,y): return sum(a*b for a,b in zip(x,y))
def mul(A,x): return [dot(row,x) for row in A]
a=[Q(0)]*n
for u in reversed(range(n)):
    a[u]=i[u]+sum(C[u][v]*a[v] for v in range(u+1,n))
J=dot(i,g)
energy=sum(K[u][v]*(g[u]-g[v])**2
           for u in range(n) for v in range(n))
energy+=sum((1-sum(K[u]))*g[u]**2 for u in range(n))
energy+=sum((1-sum(K[u][v] for u in range(n)))*g[v]**2
            for v in range(n))
assert J==dot(i,a)+dot(g,mul(S,a))
assert energy==2*J
assert dot(i,a)<=2*dot(i,i)
assert J>=dot(g,g)/2-dot(g,mul(S,g))
for x in ([Q((-1)**j*(j+1)) for j in range(n)],g,i):
    assert dot(mul(C,x),mul(C,x))<=dot(x,x)/4
print('PASS', J, dot(i,a), dot(g,mul(S,a)))
```

## 7. Decision consequence and exact scope

The inner-at-target sector of actual occupation is rigorously summable at L2 cost L_*=(1-c_*)^(-1)<=2, despite arbitrary histories and source resets. Actual inner-center geometry makes c_* of order N^(-1/2) with the already fixed shrink, so this is a genuine geometric improvement over column contraction alone. Subsequent common-source geometry may therefore focus on true shell-to-shell traffic, with either the coercivity threshold (4.4) or the injection-anchored mixed term (5.3). Neither condition is presently proved. In particular this result alone does not remove N from J, does not attach low-face terminal hypotheses to all alive arrivals, and does not pay any additional portion of the original BH ledger. This bounded candidate is complete; no further rank-potential expansion is proposed here.
