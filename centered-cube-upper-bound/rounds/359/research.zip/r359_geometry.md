# R359 — Actual common-source fractional-mass Schur estimate

## Outcome and screening

For the R358 smoothed common-source transition Pbar, this note proves a two-sided weighted kernel estimate using actual receiver-center volume and the actual overlap ∫f c_u c_v. It applies as well to every actual aggregate effective kernel K_eff≤Pbar. It gives an additional factor of order 1/√n for the mass-weighted kernel at exponent one. It does not give a polylog bound for the unweighted injection overlap J_inj.

The distinction matters: strict mass growth and subinvariance alone already imply a weighted contraction. Merely displaying that contraction would not be new geometry. The stronger coefficient below explicitly uses the common-source overlap and Lebesgue center capacity. Removing the mass weight leaves two specified injection moments, not a free cancellation.

The archived fixed-shift R357 ledger is unchanged. The assertions below are for an actual process constructed with the smoothed kernel, as stipulated in the R359 contract; the migration caveat in R358_smoothing remains in force.

## 1. Frozen fields and exact common-source kernel

Write q0=q_-=3λ/4, σ(du)=q_u du, X_q=σ(E), and

    m_u=∫ f c_u=q_u R_u^n,  q0≤q_u≤λ,
    a≤R_u≤b≤2a,  K=exp(√n),
    D0=1+√n+log(4/3), Δ=2(1+√n),
    w=Δ−D0=1+√n−log(4/3)>√n.

The full-f posterior is π_u(dz)=f(z)c_u(z)dz/m_u. The actual smoothed source kernel has density

    Qbar_z(u,dv)=k_z(u,v) ξ_z(dv),
    ξ_z(dv)=q_v c_v(z)dv/m_v,
    0≤k_z(u,v)≤1/w,
    k_z(u,v)+k_z(v,u)≤1/w.

Here k is the R358 average over genuine rank displacements in (D0,Δ), with atom randomization. In particular it vanishes unless m_v>K m_u. Set

    Pbar(u,dv)=∫π_u(dz)Qbar_z(u,dv).

Its density relative to σ(dv) is exactly

    p(u,v)=1/(m_u m_v) ∫ f(z)c_u(z)c_v(z)k_z(u,v)dz. (1)

The source and rank window in (1) are unchanged. Both Pbar1≤1 and σPbar≤σ hold. The proof below obtains an upper envelope by replacing k with 1/w, and keeps its strict mass-gap support. This positive relaxation is stated explicitly; it is not an assertion that the original k is constant on all far pairs.

Let G=gσ be actual aggregate arrivals and I=iσ their actual injection, with

    0≤i≤1, 0≤g≤N, G=I+G K_eff, 0≤K_eff≤Pbar.        (2)

All history kills, physical-clock marks and full-f posterior qualifications remain in K_eff. No terminal low-face property is assigned to g or K_eff.

## 2. Real center capacity and its two Stieltjes consequences

For a fixed actual source z, define the receiver-center mass distribution

    F_z(t)=|{v∈E:c_v(z)=1, m_v≤t}|,  t>0.

Every contributing receiver has R_v^n=m_v/q_v≤t/q0 and |v−z|∞≤R_v/2. Hence its center lies in the cube centered at z of volume t/q0. Thus

    F_z(t)≤t/q0.                                   (3)

This is a Lebesgue estimate on receiver centers. It gives no source-density or thin-shell f-mass cap.

For 0<α≤1 and M>0, (3) implies

    ∫_{c_v(z)=1,m_v>M} m_v^(−1−α)dv
      ≤(1+α)/(α q0) M^(−α),                        (4)

    ∫_{c_u(z)=1,m_u<M} m_u^(α−1)du
      ≤M^α/(α q0).                                 (5)

For (4), write the decreasing function t^(−1−α) as the integral of (1+α)s^(−2−α) over s>t. Tonelli gives the integral of F_z(s)−F_z(M) for s>M; dropping the nonnegative subtracted term and using (3) proves (4). This handles the strict lower cut and mass atoms.

For α<1, integration by parts, or the analogous layer-cake identity, bounds the left side of (5) by

    M^(α−1)F_z(M)+(1−α)∫_0^M F_z(t)t^(α−2)dt
      ≤ M^α/q0+(1−α)M^α/(αq0)=M^α/(αq0).

For α=1 it is directly (3). Strict versus inclusive upper cuts only improves the bound. Because the actual receiver masses lie in [q0 a^n,λb^n], there are no endpoint-integrability difficulties; the displayed estimates also hold by monotone truncation.

## 3. Fractional-mass kernel and both Schur constants

Define the positive conjugated kernel

    T_α(u,dv)=(m_u/m_v)^α Pbar(u,dv),  0<α≤1,
    Cq=λ/q0=4/3.

The actual common-source geometry gives

    sup_u T_α1(u) ≤ Cq(1+α)K^(−α)/(wα),             (6)
    σT_α ≤ [Cq K^(−α)/(wα)] σ.                      (7)

To prove (6), use (1), k≤1/w and q_v≤λ, then (4) with M=K m_u:

    T_α1(u)
    ≤ (λ/w)m_u^(α−1)∫ f(z)c_u(z)
           [∫_{c_v(z)=1,m_v>K m_u}m_v^(−1−α)dv]dz
    ≤ [λ(1+α)/(wαq0)]m_u^(α−1)(K m_u)^(−α)
          ∫f c_u
    = Cq(1+α)K^(−α)/(wα).

The equality ∫f c_u=m_u uses the same actual f as the kernel. It is not an upper bound by W.

For the column density relative to σ(dv), use q_u≤λ and (5) with M=m_v/K:

    d(σT_α)/dσ(v)
    ≤ (λ/w)m_v^(−1−α)∫ f(z)c_v(z)
           [∫_{c_u(z)=1,m_u<m_v/K}m_u^(α−1)du]dz
    ≤ [λ/(wαq0)]m_v^(−1−α)(m_v/K)^α∫f c_v
    = Cq K^(−α)/(wα).

Thus both sides use genuine common-source integration, actual du, and the matched mass identities. No two occurrences of ∫f are replaced by two independent copies of W.

Strict mass growth and subinvariance independently give the baseline row and column bounds K^(−α). Combining the two estimates, define

    r_α=K^(−α) min(1,Cq(1+α)/(wα)),
    c_α=K^(−α) min(1,Cq/(wα)),
    ρ_α=sqrt(r_α c_α).

The positive-kernel Schur argument gives

    ||T_α||_{L²(σ)→L²(σ)}≤ρ_α
      ≤K^(−α) min(1,Cq sqrt(1+α)/(wα)).             (8)

For completeness, Cauchy–Schwarz in each row gives

    |T_α h(u)|²≤r_α∫T_α(u,dv)|h(v)|²;

integration and the column estimate give r_α c_α||h||². Every inequality remains valid for T_eff,α=(m_u/m_v)^α K_eff by positive domination.

At α=1, the geometric estimate reads

    ||T_eff,1||≤sqrt(2) Cq/(wK).                    (9)

When w>sqrt(2)Cq, this improves the mass-gap-only bound 1/K by a factor sqrt(2)Cq/w. In the original nonempty high-past dimensions this condition holds. Formula (8), rather than (9) alone, covers every n≥1.

The factor 1/w here is the actual smoothing-width factor, not a new row probability. The density identity (1) and strict mass ordering are essential to its proof. The antisymmetric rank bound k+k^T≤1/w does not justify halving (6) or (7): these row and column tests are asymmetric in the receiver masses.

## 4. Exact weighted arrival energy and the remaining cost

All masses are bounded above and below by positive constants on the fixed scale slab. Therefore multiplication by m^±α is legitimate in L²(σ). Put

    h=m^(−α)g,  h_I=m^(−α)i.

The actual balance (2), not an invented replacement path, becomes

    h=h_I+T_eff,α^*h.                               (10)

Indeed g(v)=i(v)+∫g(u)k_eff(u,v)σ(du); multiplying by m_v^(−α) inserts exactly (m_u/m_v)^α. Since ρ_α≤K^(−α)<1, (8) yields

    ||m^(−α)g||₂≤(1−ρ_α)^(−1)||m^(−α)i||₂.         (11)

In particular the weighted injection overlap satisfies

    ∫m^(−2α)ig dσ
      ≤(1−ρ_α)^(−1)∫m^(−2α)i² dσ.                 (12)

For the desired unweighted J_inj=∫ig dσ, the valid consequence is

    J_inj ≤ [M_+(α)M_−(α)]^(1/2)/(1−ρ_α),           (13)
    M_±(α)=∫m^(±2α)i²dσ.

It follows by pairing m^αi with m^(−α)g in (11). These are actual injection moments; their mass-power units cancel under the product, which is invariant under a common rescaling of all masses, while sqrt(M_+M_−) retains the units of σ-mass. Dropping one of them would erase the exact cost of undoing the weight.

If all injection masses lie in [m_*,m^*], H=log(m^*/m_*), then the elementary estimate is

    [M_+M_−]^(1/2)≤exp(αH)∫i²dσ≤exp(αH)X_q.       (14)

The available whole-slab range is only H≤n log(b/a)+log(λ/q0). At exponent one, (9) is a strong kernel improvement but (14) can cost exp(H). Taking α small reduces the moment cost but also loses the common-source improvement: its extra coefficient is Cq sqrt(1+α)/(wα). For instance α of order 1/H in a full dyadic slab has wα of order 1/√n; then only the baseline contraction is effective. Equations (13)–(14) do not give a general polylog J_inj bound.

This is a precise remaining mass-moment cost, not a claim that the original target is impossible. Additional control of the actual injection moment product, or a genuinely coupled mass-band comparison avoiding that product, would be needed to finish this route. Terminal directional dispersion does not furnish such control for the full arrival field in (2).

For any fully migrated smoothed terminal process with the R358 energy argument, its terminal capacity is at most Bbar W, where

    Bbar=(D0+Δ)/2.

Thus the conditional implication from (13) is

    F²≤2Bbar W [M_+M_−]^(1/2)/(1−ρ_α).

Only if the moment expression divided by (1−ρ_α) is independently bounded by C log^A(n+2) X_q does Young's inequality give

    F≤δX_q + [C Bbar/(2δ)]log^A(n+2)W.

No such independent bound is supplied here, and no archived F_low is replaced by a newly generated smoothed residual.

## 5. The current nonrich-state restriction

The parent task's causal nonrich-state version is directly admissible: let G_nr include arrivals after the current receiver's rich test but before its true full-f source draw, and let I_nr be the injection restricted by that same current test. Count only continuation edges whose next state also passes the rich test. Then

    G_nr=I_nr+G_nr K_nr,  K_nr≤Pbar,  I_nr≤σ.

Thus (6)–(14) apply with the nr subscripts. This does not condition on eventual terminal survival. Its support additionally satisfies

    π_v(σ_*Q_v)<θ,  θ=1/4.

There is a precise extra kernel estimate for the component whose actual common source is in the target's inner cube. Let Pbar_in retain the source mark in (1) and insert 1_{z∈σ_*Q_v}, restricting both receivers to the nonrich state set. Put d=σ_*^n. The center-capacity step for its target variable improves to

    |{v:z∈σ_*Q_v,m_v≤t}|≤d t/q0.

The row proof of (6) therefore gains d. In the column proof, the final integral is now ∫_{σ_*Q_v}f<θm_v, so (7) gains θ. Consequently

    ||(m_u/m_v)^α Pbar_in||₂
      ≤ Cq sqrt(d θ(1+α)) K^(−α)/(wα).             (15)

Any actual source-labelled effective subkernel on this event satisfies the same bound. The derivation uses the actual restricted common-source integral; domination of an unlabelled receiver marginal would not by itself identify this component.

The complementary target-outer component remains, and its mass is not small merely because d is small. Equation (15) is a useful component bound, not a whole-process payment. In particular the nonrich condition says most posterior mass is outer, so we make no small-source-mass claim about that complement. No terminal face-count or terminal direction-spread property is assigned to G_nr.

## 6. Exact finite checks and ledger

The following standard-library Python code was actually run and passed 28,428 exact Fraction checks of (4)–(5), with atoms, strict cuts, empty tails and α∈{1/2,1}. The test distributions obey F(t)≤t by construction. They check the scalar Stieltjes inequalities only; they are not full-f realizations of the original cube/history process. Integer square roots avoid floating arithmetic.

```python
from fractions import Fraction as F
from itertools import product
from math import isqrt
count=0
for length in range(1,7):
    masses=[F((j+1)**2) for j in range(length)]
    increments=[masses[0]]+[masses[j]-masses[j-1]
                            for j in range(1,length)]
    for factors in product([F(0),F(1,2),F(1)],repeat=length):
        weights=[a*b for a,b in zip(increments,factors)]
        for M in [F(k*k) for k in range(1,length+2)]:
            for alpha in [F(1),F(1,2)]:
                root=lambda x:F(isqrt(x.numerator),isqrt(x.denominator))
                power=lambda x:x if alpha==1 else root(x)
                tail=sum((wt/(mass*power(mass))
                          for mass,wt in zip(masses,weights) if mass>M),F(0))
                head=sum((wt*power(mass)/mass
                          for mass,wt in zip(masses,weights) if mass<M),F(0))
                assert tail<=(1+alpha)/alpha/power(M)
                assert head<=power(M)/alpha
                count+=2
print('Exact scalar Stieltjes capacity checks:',count,'PASS')
```

There is no new paid source/receiver branch in this note. The R358/R357 ledger stays unchanged, including all original entrance and exterior factors, other unpaid slots, and the condition on the historical CZ charge. The proved addition is (6)–(9), a quantitative actual common-source kernel improvement, with the weighted balance and the full cost of reverting to J_inj displayed in (10)–(14).
