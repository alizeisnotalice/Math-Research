# R359 independent preliminary audit — migrating the averaged rank kernel

Status: FINAL PASS for the bounded migration, causal-support energy, actual target-inner contraction, weighted Schur comparison, numerical scope and unchanged-price ledger. The chronological preliminary screens and author reviews below culminate in the final freeze section. Only this audit file is owned/modified; no author or Git file is changed. This is a valid reconstruction route, not a claim that the new terminal measure equals or is dominated by the archived one, and not a new general root-order payment.

## Exact kernel contract sufficient for the charged chain

Freeze the original full-f actual Lebesgue cube field, old sources, m=q R^n, q_-, full prefixes/J, old physical ell including b atom, eta/Omega, and all original entrance masks. Let Qbar_z be the complete averaged noncyclic rank subkernel from R358, on ALL capturing rows. Its required properties are jointly measurable kernels; row<=1; row=1 on every positive original late input; same-source capture and strict m_target>K m_input; sourcewise xi_z Qbar_z<=xi_z; independence of the old physical r; and the full-f posterior pi_u=f c_u/m_u. Zero/noncapturing rows have harmless zero versions. The averaged shifts are sampled as part of the kernel at each invocation, retaining their ranks/shifts as history marks if desired; no successful source/rank test is renormalized.

R358 supplies all these properties, including atom-safe strict gap from the CLOSED mass-window cap D0 and the OPEN displacement interval (D0,Delta). Positive late input has strict upper xi-tail>Delta, so its initial row probability is exactly one. A later arbitrary row remains only substochastic. Source sections exceptional for Lebesgue disintegration have zero original source density f dz as well. No new q, source, E or radius field is selected.

## Step-by-step independent comparison with the old receipts

- R350 probability insertion: insert Qbar into the ORIGINAL late measure before restricting its newly generated witness. Initial row one preserves total late mass with every old y,u,v,r mark. Contract the unchanged clock only for the upper estimate. Sourcewise columns give kappa_bar(w)<=q_w p_w^(gex)<=q_w. This proves a new joint witness law; it does not use an archived residual inequality to replace its old remainder by a smaller unrelated measure.
- R350 source split / R351 peeling: resample the same full-f pi_w. The new source marginal is f Lbar with Lbar<=D_E. The source occupancy D_A and the receiver concentration cascade E_j/E_infinity depend only on the original field and deterministic receiver sets, so their potential proof and L4 input are unchanged. Restrict the new witness to that core, and pay all cascade deletions ONCE by beta X_q+4sW. Do not also charge the superseded one-round R350 fee. Closed limiting D>=s and non-strict posterior>=3/4 remain exactly the old limiting claims.
- R351 legal iteration: define Pbar=pi*Qbar on all capturing rows. sigma Pbar<=sigma proves each generation's q-cap even with history-dependent extra kills. Strict factor-K mass growth gives the same finite visit horizon N, including exact-power endpoints. Per-generation cap does not bound cumulative occupation. The only fixed-Delta equality used here is int xi b=min(D,Delta). Its correct replacement is int xi bbar=E_h min(D,h)<=(D0+Delta)/2<=Delta. Any old conservative terminal-cap bound therefore survives. This does not pay all native terminal generations for free, and no N*Delta W term is newly added to the principal ledger.
- R353 clock first, then old-source inner: the clock proof uses Q independent of old r, row<=1, strict mass gap, and inclusive ell tail. The inner proof needs SOURCEWISE xi-column domination, not merely integrated kappa<=q. Both hold for Qbar, so the same c_eff X_q and s W_ex apply. The new old-time crossing is attached solely to its own initial witness wbar_0. It is not an inherited crossing for old w_0 or a later endpoint.
- R355 ordered path: after that split, start the NEW marked killed process. At each new receiver stop rich first, otherwise draw genuine full-f pi; stop inner-source, then ancestor recapture, then apply Qbar with its true missing probability as normal termination. Rich/inner combined price uses only per-generation q-cap, actual-center inner capacity and N; it is still 4sW. Ancestor recapture uses the original v,u plus new earlier witnesses, all separated by the same strict K gap, so the same N/(K-1) bound holds. This replaces the old recapture allocation instead of stacking a second one. Every actual draw remains shell/fresh on the new residual. No old source draw is conditioned on future kernel survival.
- R356 normal-terminal source columns: from the NEW full path law first obtain dTbar_j=f(z)c_w(z) kbar_j(z,w) dz dw/m_w with 0<=kbar_j<=kappa_bar_j<=q_w. Define Lbar and Lbar_i from this joint law. The old single-face actual-center envelope and N then prove the same C_dir. The source-heavy set MUST be computed from Lbar_i/Lbar, including zero Lbar handling. Old L_i or old source-heavy membership cannot be reused simply because full f stayed fixed.
- R357 count/whole-source merge: define the high-face column Hbar only inside the NEW direction-diffuse terminal law. The same binomial CENTER-VOLUME capacity C_m applies independently of the source/path law, so Hbar<=N C_m. Recompute the Hbar>=Lbar/4 whole-source split; the new remainder has Lbar_new>3 Lbar/4 and directions<4/[3 log(n+2)]. Do not retain the old normalized threshold without this factor. Shell endpoints sigma_*=1, m>n and zero source columns are handled as in the old proof.

Thus there exists a reconstructed positive marked remainder Fbar_low with the R357 source/receiver upper fees unchanged. It need not equal F_low and need not be smaller than F_low. The original B_H is the same because the reconstruction starts at its original late entrance, and each subsequent paid/remainder decomposition is redone in order.

## Fixed-shift facts that cannot be transferred verbatim

The exact deterministic rank relation target=start+Delta becomes target=start+h with h in (D0,Delta). Lost top rank is averaged min(D,h); sourcewise incoming rank fraction is the ramp from R358 rather than 1{rank>Delta}. Any bottom-defect/top-defect identification, fixed-shift potential reset, a prescribed path pairing, or archived rank/source terminal set must therefore be reconstructed, not cited unchanged. The charged R350--357 chain above does not need these exact fixed-shift formulas beyond the safely dominated native terminal capacity. Unused R351 partial-terminal/occupation identities can be restated with bbar, but are not new root receipts.

Likewise, newly retained terminal labels must not be used as assumptions on all earlier transitions. The old time never moves to later witnesses; old J and source masks are not rebuilt from a posterior/excess source. Full W pays newly resampled-source fees, while the original-source inner fee remains W_ex. Continuum shifts are averaged once, not charged as separate source copies.

## Ledger conclusion and remaining obligations

The anticipated inequality is the R357 form with Fbar_low replacing F_low, retaining receiver coefficient [(13/3)epsilon+gamma_eff+beta+alpha_rec+c_eff]X_q, source [C_epsilon,n+8s+C_dir+C_multi]W and excess-source (D_top+C_hit+s)W_ex. Kernel migration adds no extra fee if the stated reconstruction is performed. Entrance two, exterior Lambda, the conditional historical-CZ same-X qualification, and every unrelated soft/threshold/time-atom/source/scale/outer-limit slot remain intact. No budget for Fbar_low is obtained here.

The R358 energy theorem can subsequently be reproved for the NEW full unconditioned arrival aggregate, with its own injection overlap Jbar_inj and native capacity E_h min(D,h). Its old numerical J_inj or old terminal beta cannot be identified with the new ones. The R358 source-product density tool is available for Qbar, but its right-hand side still has no proved root budget. Quantitative comparison of old and new unpaid total is not inferred.

## Evidence and read scope

Reviewed the mathematical kernel/receipt sections of the eight specified old interfaces below, after the independent proposition was received, and the already independently audited R358 smoothing contract. No R359 migration author proof read. No old pipeline was repeated: the reviewer's previously executed R358 rank-rectangle Fraction checks (16 models, 634 assertions) already cover the averaged row/column and terminal identities; they remain finite algebra, not a native-path realization and not a R359 parent test count. The migration conclusion above is analytic from the stated contracts, not an inference from those finite cases.

### Byte bindings at preliminary review

- /tmp/r350_geometry.md: `eef2a5ba2e20828387aab0ac8a8d3b58a55196229a44ae63f8870804b5b74b20`
- /tmp/r350_core.md: `133d639819177b06cf4c5078cd6471bfbb9c37a27f9669fdd235e4b353804064`
- /tmp/r351_geometry.md: `c8d688467593892e84608eb40774d62d61112284b40c18c261dee54f8effe4a3`
- /tmp/r351_core.md: `27421b0a4fcacfbd10f89f0707be35514f3c349af8097c77753a98b0d6d6c48b`
- /tmp/r353_geometry.md: `c0a99aa47c05f0425bb89596a82698682fc92b462320146fbf373a7ee4fdba42`
- /tmp/r355_geometry.md: `42febb6f3d8a479db4799f30a9be06cb3d87e2a8011a752321d8f2f7deb0ae64`
- /tmp/r356_geometry.md: `fdd9f88782dad7028ebe8004e3e75148f3e72770a502eb185dc216124bef3394`
- /tmp/r357_geometry.md: `5d954e2b627ba7504e78df7bdc1ce69f94dd0c63c7fb2de5e52c2e303db3f66c`
- /tmp/r358_smoothing.md: `666c186f1459c53f236f863a2bea5b3c2e3cd9f3e91b7889f4a1e2c66beebc93`

Preliminary waiting status superseded by the author reviews and final freeze below.

## Additional independent screen: causal nonrich energy support

PASS. Let A={w:pi_w(sigma_*Q_w)<1/4} be the deterministic CURRENT nonrich receiver set from the newly constructed process, with the original full-f posterior. It is not a set defined by eventual Fbar_low survival, nor the R351 initial receiver core. Write M=1_A. The full pre-test arrivals satisfy G=I+T_2. Since rich is tested before any source draw or continuation, T is supported on A at its SOURCE coordinate. Thus restricting T also at its target gives T_nr=(M tensor M)T and exactly

    G_nr=M G=M I+(T_nr)_2=I_nr+G_nr K_nr.

Joint domination T_nr<=G_nr(du)Pbar(u,dv) allows the same RN/disintegration construction as R358, with K_nr<=Pbar and zero version on {G_nr=0}. Its targets lie in A; one may choose it zero outside A at its source. Therefore sigma K_nr<=sigma, and in fact sigma_A K_nr<=sigma_A for sigma_A=1_A sigma. Edges entering rich are now an effective row loss; they remain the already priced joint-stop event, not a new fee or a new posterior law.

The selected NEW normal-terminal remainder is supported at A. Defining Z_low=beta_nr G_nr still gives beta_nr<=bbar_native and beta_nr<=1-K_nr1. Additional source/ancestor/face gates only restrict the genuine full posterior draw; normal termination is not confused with the newly effective rich-target loss. The original (averaged) native terminal cap over full sigma dominates the restricted cap, so

    Fbar_low^2 <=2 Cterm W J_nr,
    Cterm=(D0+Delta)/2<=Delta,
    J_nr=int i_nr g_nr d sigma=int_A i g d sigma<=J_inj.

All arrival-energy states now have actual full-f posterior shell mass>3/4, because A is a current deterministic rich test. This qualification is legitimate. It still does not transfer terminal low-face/source-direction/freshness or initial old-clock crossing to every energy state, nor prove a logarithmic J_nr bound. No whole-flow fee or receiver absorption is added. If the rich predicate depended on history instead of only the current field, a projected fixed set M could not be used without a marked-state proof; the current R355 predicate is deterministic, so that issue does not arise.

Local exact calculation actually executed: 15 finite nonreversible models varying every nonempty current nonrich subset; 165 Fraction assertions PASS for supported balance, subinvariance, J_nr<=J, the three-part energy identity and selected-terminal Cauchy bound. Finite algebra only, not a native cube realization or a parent pipeline count. No R359 energy-support author file was read for this screen.

## Migration author proof: file-level review

Read /tmp/r359_migration.md in full after the independent screen. PASS. Its pre-witness starting estimate (3) is an explicitly retained historical input, rather than a subtraction from the archived post-witness bound. New probability insertion (5), incoming cap (6), peeling (7), old-clock/inner split (9), ordered terminal partition (14), new source direction split (19), and new whole-source/high-tuple split (22) form the exact eight positive pieces in (24). Their declared costs sum to (1) with the old coefficients, keeping the actual original B_H and all old marks.

The proof does not import availability after changing source, does not renormalize failed tests, and uses actual missing-rank probability at the last possible visit. It keeps old v/u ancestors and the old physical crossing only at the new w_0. Flow-dependent Lbar, Lbar_i, Hbar and both threshold sets are newly constructed; final source ratios include the proper 4/3 renormalization. Terminal-cap averaging is not charged on top of the eight pieces. Full W and W_ex locations, entrance two, exterior Lambda, and conditional historical-CZ scope agree with the preliminary audit. The receipt coefficients are unchanged, not a proof that Fbar_low decreased.

Read the embedded check code for scope. Its 861 recorded count is finite split/normalization/outer algebra, not original high-past continuum evidence; no repeat run was needed. R358 smoothing remains the analytic kernel input. No author correction requested.

Binding: /tmp/r359_migration.md SHA256 `be3c0ab278c6553c004d1ec263b39514cbc80afdddf1cbde5c8531d337cb617f`.

Interim status superseded by the final integration review below.

## Causal energy-support author proof

Read /tmp/r359_energy_support.md in full. PASS: its current deterministic nonrich set, original pre-test arrival convention, exact supported edge balance, native normal-terminal reward restriction, Cterm=(D0+Delta)/2 and J_A<=J_inj match the independent derivation above. Continuation to a rich target is an effective row loss and remains the previously priced rich event, not reclassified normal rank loss or an added fee. The statement does not confer terminal/source-history/old-clock predicates on all energy states. It explicitly distinguishes a finite diagnostic unfinished horizon stop from the genuine native finite strict-mass horizon.

## Independent weighted Schur screen and author geometry review

Before reading the author geometry proof, independently derived the estimates for 0<alpha<=1 from the actual center capacity F_z(t)<=t/q_-. The strict upper integral is bounded by (1+alpha)M^-alpha/(alpha q_-) after dropping its nonnegative boundary subtraction; the strict lower integral is bounded by M^alpha/(alpha q_-), including alpha=1 and atoms. Integrating the SAME f c_u and f c_v produces the stated row and column constants Cq(1+alpha)K^-alpha/(w alpha) and Cq K^-alpha/(w alpha). No duplicate source mass or assumed source density is introduced. Baseline K^-alpha row/column caps can be separately minimized with these constants; their geometric mean is the L2 Schur norm bound. Alpha=1 has a genuine additional 1/w improvement beyond strict mass gap alone.

Read /tmp/r359_geometry.md in full. Its exact density (1), actual-volume capacity (3), Stieltjes bounds (4)--(5), the constants (6)--(9), adjoint-weighted balance (10) and moment cost (13) agree with the independent screen. With M denoting multiplication by m, P=M^-alpha T_alpha M^alpha and g=m^alpha h. Therefore the unweighted overlap necessarily retains sqrt(M_+ M_-)/(1-rho_alpha). Its whole-slab moment bound can be exponential in the mass logarithmic range; no general logarithmic energy or root payment follows. Positive domination also applies to the actual history-aggregate effective kernel; reversibility is not assumed.

For the labelled target-inner component, actual center capacity improves to F_inner,z(t)<=sigma_*^n t/q_-, giving the geometric row bound its factor d. The nonrich target posterior gives int_inner f<theta m_v, giving the geometric column bound its factor theta. Formula (15) follows; these factors are not simply multiplied into the unrelated baseline row-one bound. The labelled effective subkernel needs its actual source joint domination, which the note explicitly requires. Target-outer and undo-weight moments remain unpriced.

Minor wording clarification sent to parent: the statement that M_+M_- “has no dimensional units” should mean that the mass-weight units cancel under a common rescaling of all m. The square root still has the units/scale of sigma mass. This does not affect any inequality or the stated rescaling invariance. Resolved by final geometry revision SHA53413995... below; no inequality changed.

Read the embedded scalar-check code for scope, without rerunning it: squared mass/cut inputs make its isqrt powers exact for alpha=1/2. The reported 28,428 are finite Stieltjes-capacity tests, not original cube/path realizations. No count is used as proof of the analytic kernel estimate.

Reviewed bindings at this stage:

- /tmp/r359_energy_support.md: `c46381c901c16a1a39118e0afce84b1a4bd6aaa294425f0efb5c6665f78f7aae`
- /tmp/r359_geometry.md: `b00fdf5900040502c3357b624342208afc01786a24f6e9eb688e048c24189968`

Interim waiting status superseded by the final freeze below.

## Independent screen: target-inner elimination and shell-square remainder

PASS as a conditional comparison, not a new payment. Work on the causal nonrich support A, using the ACTUAL source-labelled continuation joint measure prior to forgetting the sampled source. Its joint density is a positive restriction of G_A(du) pi_u(dz) Qbar_z(u,dv); since inner-source stopping precedes continuation, all surviving labels satisfy z outside sigma_*Q_u. Separate its effective kernel into C (z in target inner sigma_*Q_v) and S (z outside both inner cubes). An unlabelled domination K_A<=Pbar alone would not justify assigning the source-side exclusion; the labelled domination from the actual process does.

Sourcewise columns and target nonrich give sigma C<=theta sigma, theta=1/4. Baseline C1<=1. Using k<=1/w and the actual inner-center capacity int 1_inner xi_z<=d A_n additionally gives C1<=d A_n/w, d=sigma_*^n. Therefore norm C<=c_*:=sqrt(theta min(1,d A_n/w))<=1/2. No theta or d is artificially multiplied into the unrelated baseline row cap.

For the shell-both effective part, symmetry of its allowed shell-both pair domain and the pointwise k+k^T<=1/w imply, for the actual nonnegative arrival density g,

    <g,Sg> <= (1/(2w)) int f(z) [int g(u)1_shell(z,u) xi_z(du)]^2 dz.

Actual history acceptance can be asymmetric; its factors <=1 preserve this upper comparison after symmetrization. Writing this shell square Q_shell, the exact balance gives

    J_A >= (1-c_*) norm(g)^2 - Q_shell/(2w).

If, and only as an additional sufficient condition, Q_shell<=rho w norm(g)^2 with a=1-c_*-rho/2>0, Cauchy--Schwarz with J_A=<i,g> proves J_A<=norm(i)^2/a<=X_q/a. Such a shell-square bound is not established. Neither the target-inner norm nor energy equality alone supplies it.

For the Duhamel form the orientation is important. Let R=(I-C)^-1 act on functions and h=R i. From g=i+(C+S)^*g one gets J_A=<h,i>+<g,S h>. Positivity and norm(C)<1 give h>=0, norm(h)<=norm(i)/(1-c_*). The source-density upper bound gives

    J_A <= norm(i)^2/(1-c_*)
           +(1/w) int f(z) B_g(z) B_h(z) dz,
    B_j(z)=int j(u)1_shell(z,u) xi_z(du).

The bilinear comparison uses 1/w, not the symmetric same-amplitude factor 1/(2w). These shell integrals are not the receiver operator S j; notation must distinguish them. Their finite second moments follow from D(z)<=A_n and int f xi_z=sigma, so the displayed comparisons are well-defined for L2(sigma) amplitudes. A norm bound for h is not a pointwise bound nor a geometric source budget. No total-flow/root receipt is claimed by this elimination.

No author potential proof was read for this additional screen. Interim waiting status superseded by the potential review and final freeze below.

## Potential author proof review

Read /tmp/r359_potential.md in full after the independent C/S screen. PASS for its mathematical statements: the actual labelled continuation (2.1) retains ancestor/rank/history acceptance before disintegrating; C/S is an honest partition. Both target-inner contraction proofs, the stronger c_* row estimate, symmetrized shell square, conditional coercive coefficient gamma=1-c_*-rho/2, conditional Young price b_*W/(2 gamma epsilon), and injection-anchored Duhamel direction agree with the independent derivation. The mixed source term has 1/w and no unwarranted pointwise resolvent cap. The square comparison is only an upper bound in the direction needed for the energy lower bound; original B_H capture-square credit is not reused. No shell square bound is established.

The only notified pending author edits are provenance/notation (rebuilt R359 rather than R358, Fbar for the new low-terminal flow), not an inequality correction. The conditional result may be used only after a genuinely quantitative bound on its own occupation shell square or injection-anchored mixed source term; the contraction of C alone is not such a bound. Embedded finite DAG algebra was read, not rerun. Its norm and resolvent identities are algebra only, not source/cube realizations.

## Numerical code, notes and result scope review

Read /tmp/r359_numeric.py and /tmp/r359_numeric.md in full, and inspected the result metadata and declared fractions. PASS 2899 exact assertions split 122/233/2544 is consistent. The source geometry consists of actual compact positive-volume full-f boxes, wholly captured/missed by the finite receiver cubes, with derived m/q. Receiver weights remain finite quadrature. Source atoms are cut at all contracted-cube faces so inner/shell probabilities and unique first-face signs are volume integrated, not probes. Same-mass ranks use the entire grouped interval; exact strip areas are independently checked by piecewise-linear overlap integration. The tiny diagnostic smoothing windows do not exceed native D0, may retain ties/self loops, and do not certify strict native mass growth or hard entrance.

The finite complete path retains an initial diagnostic source label and all actual receiver history, draws from the full current posterior before each source test, assigns inner/ancestor overlap only to inner, and records successful beyond-horizon edges as unfinished. The tuple-history propagation is checked against a separate visited-set/age propagation, including every first-stop category by original label. This verifies these declared finite mechanisms; it does not simulate historical old y,u,v,r admissibility or all native rich/source gates.

The aggregate energy drops beyond-horizon edges from the actual continuation matrix and keeps their mass in the row deficit. Normal-selected beta stays bounded by native smoothing loss; normal mass is not conflated with unfinished. The added nonrich test explicitly uses theta=3/20, not native 1/4, and yields nonzero target-rich stopping in the tie fixture. It is an additional rich-killed subprocess on the same arrays, dominated by the primary no-rich diagnostic chain; it does NOT assert G_nr=mask G for that different no-rich baseline. This is compatible with the analytic causal-support theorem, where the comparison G is the pre-test arrival field of the SAME rich-stopped process.

Output fractions inspected: first normal/unfinished 1259/3600 and 1837/3600; tie 13131/358400 and 5549/358400; 2D 1043848593/6193515625 and 44425017/6193515625. Nonrich J ratios are 9/43, 492002/2630639 and 1. No parent pipeline repeated, no finite diagnostic ratio promoted to an asymptotic or uniform estimate.

Current byte bindings (pending notified potential wording):

- /tmp/r359_potential.md: `92a09d0d3a1041df263b41efc3dc06dd3e92a4d19b605377e427c651fdcc615a`
- /tmp/r359_numeric.py: `e4979a42cddf0f8fe9c3d22223240d896863364d497f5be115bfdade56568236`
- /tmp/r359_numeric.md: `a82fa068807e0215c43d54056f3a2d102118f299af235c0db4a5941a614506da`
- /tmp/r359_numeric_result.json: `2e10bbed2f39d49e6113ef22cd2526915dc316042be3f579390eb9b99e62be25`

Interim waiting status superseded by the final freeze below.

## Final integration audit and freeze — 2026-10-18

Conclusion: PASS. All requested R359 final mathematical notes, main, ledger, readme, numerical code/notes/output, and three extracted proof scripts were read at the scope recorded above. No mathematical correction remains. The geometry mass-unit sentence was corrected; the potential note now consistently names the rebuilt R359 process and Fbar_low. These revisions change no proof/script arithmetic. Only /tmp/r359_audit.md was edited by this reviewer; no author file, repository, or Git state was changed.

### Final mathematical and accounting findings

- The new flow is attached to the SAME original B_H by restarting at its original PRE-witness late measure. Initial row one, sourcewise xi columns, original-r independence and strict K growth suffice to rebuild all eight positive pieces. Their constants reproduce R357. Old flow-dependent source direction and high-face sets are not reused: new Lbar, Lbar_i, Hbar and 4/3 normalization are defined from the new terminal joint. Neither equality nor domination between old and new unpaid totals is asserted. All old full-f m/q/J/source/clock/history masks remain frozen.
- The causal nonrich restriction uses the current deterministic full posterior test before source resampling, not eventual terminal success. Exact restricted balance and native selected-terminal rate hold; transitions into rich are already priced stops. Every energy state is genuinely posterior shell-rich, while terminal face/direction/ancestor and old-clock predicates are not granted to all states. The new averaged native cap Cterm W is valid without an additional per-generation fee.
- Source-labelled C/S is an exact actual continuation split. The target-inner component has row min(1,d A_n/w), column theta and L2 norm c_*<=1/2; its inverse (I-C)^-1 is bounded at L2 cost (1-c_*)^-1, not pointwise. This is a real component estimate beyond baseline row/column contraction. It does not pay the entire original remainder. The true shell-square condition, or the entrance-anchored mixed source term, remains unproved. Conditional gamma=1-c_*-rho/2 and source Young coefficient b_*/(2 gamma delta) are correct. As the main ledger states, if later proved its outer additions would be 2 Lambda delta X_q and Lambda b_*W/(gamma delta). They are not currently charged or absorbed.
- The fractional-mass estimate uses actual source overlap and actual receiver volume, with row/column constants independently checked. The baseline minimum and 1/w gain at exponent one are legitimate. Undoing the mass similarity retains sqrt(M_+M_-)/(1-rho_alpha); both moments and the target-outer component remain unpriced. The corrected text keeps sigma-mass units. It cannot turn small inner volume into a small arbitrary-f shell mass.
- The final main/readme accurately distinguish finite receiver quadrature, true positive-volume source/cube incidence, small diagnostic smoothing windows, nonnative rich threshold 3/20, and unfinished horizon output. Its numerical rich-killed comparison is not mistaken for a mask on the different no-rich baseline. No native strict mass-growth/hard-history field, general occupation rate, source-square condition, or asymptotic is certified by those finite runs.
- The final ledger preserves [(13/3)epsilon+gamma_eff+beta+alpha_rec+c_eff]X_q, [C_epsilon,n+8s+C_dir+C_multi]W and (D_top+C_hit+s)W_ex with the same entrance two and Lambda. No duplicate old source clip, peeling deletion, recapture, native-terminal-per-generation or negative-square credit is added. The <889/2304 receiver bound and >1415/2304 balance retain the explicit SAME certified-X condition for historical CZ 1/256. That balance is not a bound for an unpriced slot.
- All remaining general-soft/crossing/hard-contract exterior, width/distance/low-pe/extreme-scale/threshold complements, original chronological initial/deletion/future-source atoms, H/source/layer/scale/outer-integral/truncation/limit fees are retained. Kernel normal termination does not settle historical time atoms. The general weak-type/root target and the whole B_H budget remain unresolved. This review is not a fresh complete-history certification, nor a check of the parent's eventual TeX typesetting.

### Actual computation evidence and reproducibility scope

The parent reports fresh local execution PASS: numeric2899 + migration861 + scalar-Stieltjes28428 + potential-DAG7 = 32195 exact Fraction assertions. Counts agree with code and stored result metadata; they are assertions, not independent geometric instances. The three extracted proof scripts agree with their unique embedded blocks up to outer whitespace. No unnecessary repeated pipeline was run by this reviewer. The reviewer's new R359 causal-support check actually executed 15 finite nonreversible models and 165 Fraction assertions, separately recorded above and not included in the parent's count. Previously executed R358 checks cited as background likewise are not counted anew.

### Final frozen SHA256 bindings

- /tmp/r359_main.md: `ce6aa8dcc43e5c46d90d25b85d7d14a4ad66fbbad16913f1205891537bcd163d`
- /tmp/r359_ledger.md: `02b043d1847ff4ef556bd2e4018b0036fc9a739be934109c529cf12796fb8004`
- /tmp/r359_readme.md: `bad787447d58818f974fceeca56a82ee3e248daead5fc2cf6d05943ba2737cb1`
- /tmp/r359_migration.md: `be3c0ab278c6553c004d1ec263b39514cbc80afdddf1cbde5c8531d337cb617f`
- /tmp/r359_energy_support.md: `c46381c901c16a1a39118e0afce84b1a4bd6aaa294425f0efb5c6665f78f7aae`
- /tmp/r359_geometry.md: `53413995b205a52e4dc86f5f4533b2ab990fda87f7c9c47a7bdfbe4cc0a9e54f`
- /tmp/r359_potential.md: `ab19743a44ac968e3fe1b254b6bb082a533e609c5001e7db6f2248854c463c19`
- /tmp/r359_numeric.py: `e4979a42cddf0f8fe9c3d22223240d896863364d497f5be115bfdade56568236`
- /tmp/r359_numeric.md: `a82fa068807e0215c43d54056f3a2d102118f299af235c0db4a5941a614506da`
- /tmp/r359_numeric_result.json: `2e10bbed2f39d49e6113ef22cd2526915dc316042be3f579390eb9b99e62be25`
- /tmp/r359_migration_checks.py: `38c5aaa7ab6d8f8ae90bc8369fbb2e26704eb3732e0bb4276ba07212406ffe06`
- /tmp/r359_geometry_checks.py: `70971622a8f70ada793d08cb6974822c44068ef9aeeea9f2872fa7cd469f7929`
- /tmp/r359_potential_checks.py: `c1378dd4a7cff446b2cc43b6b83f6eaca303cdf98ef394e4f97a89ab4803879e`

Necessary earlier-interface final bindings (dependency identity, not a claim of repeating all historical reductions):

- /tmp/r358_smoothing.md: `666c186f1459c53f236f863a2bea5b3c2e3cd9f3e91b7889f4a1e2c66beebc93`
- /tmp/r358_energy.md: `6249b9ee9fb7ad3aa1d17961c05f77c2a26f072b4df99bacf16da05d4b7561b0`
- /tmp/r358_audit.md: `1ba4bdf6a7d0df87e120db1b9b7c309e3d70701730f08f1bb5e3ebcf6a921020`
- /tmp/r357_ledger.md: `2ed62fbf2d32e3d4293281f1d9ed4417aab78653f6e094b6e806a4a10f8c89aa`
- /tmp/r357_geometry.md: `5d954e2b627ba7504e78df7bdc1ce69f94dd0c63c7fb2de5e52c2e303db3f66c`
- /tmp/r350_geometry.md: `eef2a5ba2e20828387aab0ac8a8d3b58a55196229a44ae63f8870804b5b74b20`
- /tmp/r350_core.md: `133d639819177b06cf4c5078cd6471bfbb9c37a27f9669fdd235e4b353804064`
- /tmp/r351_geometry.md: `c8d688467593892e84608eb40774d62d61112284b40c18c261dee54f8effe4a3`
- /tmp/r351_core.md: `27421b0a4fcacfbd10f89f0707be35514f3c349af8097c77753a98b0d6d6c48b`
- /tmp/r353_geometry.md: `c0a99aa47c05f0425bb89596a82698682fc92b462320146fbf373a7ee4fdba42`
- /tmp/r355_geometry.md: `42febb6f3d8a479db4799f30a9be06cb3d87e2a8011a752321d8f2f7deb0ae64`
- /tmp/r356_geometry.md: `fdd9f88782dad7028ebe8004e3e75148f3e72770a502eb185dc216124bef3394`

Final freeze complete. No outstanding correction or additional experiment is required for this bounded audit.

Final nonmathematical main-byte update checked: the statement that reliable per-agent quota deductions are unavailable and no model-cost ratio is guessed has no effect on the mathematics or counts. The main binding above uses its latest frozen bytes. Proof scripts are audited standalone extraction copies; archive may retain them only in the corresponding embedded proof blocks without losing reproducibility.
