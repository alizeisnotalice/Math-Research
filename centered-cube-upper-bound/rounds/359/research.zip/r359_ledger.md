# 第359轮完整总账：从原入口迁移，新增付款为零

本账对应与历史相同的原始 \(B_H\)。新 \(\bar F_{\rm low}\) 来自重新扩展原晚交通，非旧余项直接改名。八项正分解及逐项证明见 `r359_migration.md`。本轮新增能量、内目标收缩和加权Schur均为工具；剩余来源平方或混合量未付。

设 \(x=\sqrt n,s=1+x,W=\int f,W_{ex}=\int g_{ex},X_q=\int_Eq\le X=\lambda|E|\)，\(\varepsilon=119/3072,\Lambda=128/119,\beta=\varepsilon/16,q_-=3\lambda/4\)。
\[
B_H\le\bar F_{\rm low}+
[(13/3)\varepsilon+\gamma_{eff}+\beta+\alpha_{rec}+c_{eff}]X_q
+[C_{\varepsilon,n}+8s+C_{dir}+C_{multi}]W
+(D_{top}+C_{hit}+s)W_{ex}.
\]
这里
\[
C_{\varepsilon,n}=\frac\lambda{q_-}\left[\frac{2+3x+2e^{-x}}\varepsilon+1+x\right],\quad
D_{top}=s+\log(4/3),\quad C_{hit}=2(\lambda/q_-)s(1+\log(1/\varepsilon)).
\]
保留 \(A_n=1+n\log(b/a)\)、\(N=\max(1,\lceil\log[(\lambda/q_-)(b/a)^n]/x\rceil)\)、\(\alpha^n=\min(1,s/(NA_n))\)、\(L_n=\log(n+2)\)，
\[
C_{dir}=N[(1-\alpha)+(n(1-\alpha)+\alpha)\log(b/a)]L_n,
\]
\[
C_{multi}=4NC_m,\quad C_m=\Pr\{\operatorname{Bin}(n,1-\alpha)\ge m\}
+n\log(b/a)\Pr\{\operatorname{Bin}(n-1,1-\alpha)\ge m-1\},
\quad m=1+\lceil8L_n\rceil.
\]
这些binomial项来自真实接收体积，不是实际来源独立性。非空原highpast分支上，
\[
\gamma_{eff}=2(\lambda/q_-)e^{-x}<\varepsilon/16,\quad
c_{eff}=(\lambda/q_-)e^{-x}\max(1,A_n/s)<\varepsilon/16,\quad
\alpha_{rec}=N/(e^x-1)<\varepsilon/16,
\]
且 \(C_{dir}\le3\sqrt n L_n^2\)，\(C_{multi}\le4\sqrt n\)。原必要条件使入口为空时相应新流与这些有效分支系数置零，不给后续新来源重新授予原资格。

准确八项分解及费用如下：

|新流部分|费用|
|---|---|
|级联删除|\(\beta X_q+4sW\)|
|初始旧clock近端|\(c_{eff}X_q\)|
|初始旧来源inner|\(sW_{ex}\)|
|首次rich或实际inner来源联合停止|\(4sW\)|
|首次祖先回捕|\(\alpha_{rec}X_q\)|
|终端方向集来源|\(C_{dir}W\)|
|终端高面来源与tuple联合|\(C_{multi}W\)|
|剩余正常终端|\(\bar F_{\rm low}\)，未付|

不另加逐代正常秩终止费用；不再次收费旧回捕、旧单轮来源删除或负重叠信用。当前nonrich能量筛选和内目标预解不改变以上费用。

原始入口与外乘不变：
\[
T_{entrance}\le8\lambda HW+2d_{eff}A_nW_\nu/H+2B_H.
\]
入口2和外乘 \(\Lambda\) 作用于全体新旧费用。接收系数为
\[
13/36+2\Lambda(\beta+\gamma_{eff}+\alpha_{rec}+c_{eff}).
\]
仅当历史CZ项 \(1/256\) 属于同一认证 \(X\) 账时，合计才有
\[
853/2304+2\Lambda(\gamma_{eff}+\alpha_{rec}+c_{eff})<889/2304.
\]
其余 \(1415/2304\) 以上的吸收空间不是任何未付积分的预算。若未来以 \(\bar F_{\rm low}\le\delta X_q+b_*W/(2\gamma\delta)\) 回代，新增接收系数将是 \(2\Lambda\delta\)，新增来源费是 \(\Lambda b_*W/(\gamma\delta)\)；本轮没有证明条件 \(\gamma>0\) 对实际来源平方成立，因此没有插入该项。

独立未付槽：一般软层 \(C_H-S_H\)、越阈 \(I_H\)、硬层合同之外的质量可比重尾；宽距离、低pe、极端尺度比及全部阈值补集；原初始时间原子、删除跳跃、未来被删来源；H选择、来源及物理尺度分层、外积分、截断和极限。旧物理时钟末端原子完整保留，新秩核正常终止不替代任何历史时间原子。

一般一致弱型上界与整个 \(B_H\) 仍未闭合。
