"""Exact finite translation-group check of SC algebra, not the real C kernel."""
from fractions import Fraction as F
from itertools import product
from pathlib import Path
import json
rows=[]
# Frozen menu: dimensions 1,2,4,6; no deletion, correlated deletion, sparse deletion.
for n in (1,2,4,6):
 for mode in ('all','correlated','sparse'):
  energy=F(0); flux=F(0); mass=F(0)
  for y in product(range(3),repeat=n):
   terms=[]
   for v in range(3):
    k=sum((a-v)%3!=0 for a in y)
    wt=F(1,2**k); mu=F(v+1,6)
    keep=mode=='all' or (mode=='correlated' and (sum(y)+v)%2==0) or (mode=='sparse' and (sum(y)+2*v)%3==0)
    if keep: terms.append((mu*wt,k))
   e=sum((q for q,k in terms),F(0))
   if not e: continue
   first=sum((q*k for q,k in terms),F(0))
   energy+=sum((q*k*k for q,k in terms),F(0))-first*first/e
   flux+=sum((q*r*max(k-l,0) for q,k in terms for r,l in terms),F(0))/e
   mass+=e
  bound=F(2**n*n,4)
  assert energy<=bound
  assert mass<=2**n
  assert flux*flux<=F(2**(2*n)*n,8)
  rows.append(dict(n=n,mode=mode,energy=str(energy),bound=str(bound),flux=str(flux),mass=str(mass),passed=True))
p=Path(__file__).with_suffix('.json')
if p.exists(): raise RuntimeError('Refuse overwrite')
p.write_text(json.dumps(dict(scope='Finite three-point translation group; exact algebra only, not original C/history/FULL',menu='n=1,2,4,6 x all/correlated/sparse',cases=rows),indent=2)+'\n')
print('12 exact cases passed; finite-group SC1/SC3 checks only')
