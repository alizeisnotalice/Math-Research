<!-- SOURCE main_integration.md SHA256 668570a10cf2f987e70cd18576832214b3043eaf457930500d6077846db0ec5a -->
# 第135轮：删源 score 几何能量与反向尺度软尾比较

## 目标与当前结论

仍以任意正L1输入的一般中心立方体弱型n^(1/2+o(1))上界为目标，未闭合。上一轮第134轮已独立推送e3ef8ed。本轮不把新增小误差条带或人工指数权重当作主进展，也不把sqrt(n)X误作最终费用：原账需要可吸收εX与C sqrt(n)polylog(n) Wβ。

主代理重新核当前main干净状态，复用1个Astra high、2个Sol high、1个Sol medium、1个Luna medium，均按明确任务工作，无凑数启动。未取得模型实际扣额数据，不推算价格比例。读取M03与N04技能；M03未提供适用的一般稳定性定理，未借其名称授予结论；N04用于跨层/误差及势能条件核对。

## 实质结果和几何转向

SC1–4对任意有限相关来源ν和任意非乘积删源成立：在真实来源中心Lebesgue积分下，归一化来源score的加权方差至多nθ(1−θ)z^n||ν||，正score时间交通为根阶。先独立命题审核再核证明通过。关键是固定v后的dy乘积几何，不是声称Π_t内部坐标独立。实际β(dy)和接收dx仍不匹配，跨测度费用未支付，故不登记一般中间层预算。

真实核三阶段12例的结果改变路线：10行基础必要门通过且有positive RC余量，全部Hhat<L+；RG16通过的两行没有good来源。此结果不能认证FULL/history，也不能证明一般反向分支一定最困难，但足以要求优先补此前核比较遗漏的分支。Hhat<L+是尺度比较分支，不能一概称作Hhat=a的下钳位分支。

据此新推导K_H/J≤(sb/H)^n[1+(1−s)/(sφ(H/(2b)))]^{m_H(v)}，m_H是真实硬支持坐标数。这个源点依赖比较保留所有指数费用，用共同RC余额转回good剩余阈值，不要求Hhat≥L+。当m_L+=0且L≥sb时CJ≤3，避免在该可检查分支强收指数尺度费。它沿用原RC捕获，不重复领取Dq。联合κ/R重尾预算仍未给出。

## 实际验证及边界

1. channel_numeric.py：固定n=1,2,4,6，各3种删源规则，共12例，Fraction准确核SC1/SC3有限三点平移群版本。n=1,2为初探；相关/稀疏删源提供压力；n=4,6扩参。代码菜单先写后运行一次；没有独立事前散列协议。该实验只验证代数，不是原C核或连续输入证书。
2. real_joint_numeric.py：独立冻结协议三阶段12例，n=4–128，真实φ/C/共同ν，全12例已实现基础必要门成立。原producer运行一次，80/100位核主要派生量与符号；无FULL、连续输入、原history/全future FIRST认证。
3. 主代理replay_real_joint.py以120位重放同菜单，补比全部残量、tail及atom核字段，相对差<10^-65，门和good符号一致。不是区间算术。原producer的run_count只记它自身，不能误说本会话仅一次计算。
4. 新不等式出现后运行reverse_scale_numeric.py，原同菜单60个来源点的两个核比较、适用RC上界（未加D·K0/(Twg)的较弱版本）及纯软尾CJ≤3均通过。30个positive RC来源点全在纯软尾条件内，CJ最大约1.074592；不等式未消除全部余量，残量/较弱新上界最大仍约为1（未核精确取等），禁止称重尾已付款。

5. score_gate_probe.py对原菜单恢复实际δ、ρ、good/bad与同一Π_t：7行I1–I4/P1/P2/E1有正的原始score时间积分；P3/P4/E4虽RC余量为正，但score全相同导致δ=0。利用G4唯一未饱和原子的logistic闭式，脚本逐项核其前提；仍缺FA/Ψ/history与外接收测度，不是完整正交通证书。不得将10行RC正余量写成10行实际正交通。

6. kernel_count_probe.py另列三阶段12个核级样本，n=1–64、s=.01–1、H=.5–1，含非零硬坐标、闭硬端点、紧邻外侧与H<sb，120位核B_H比较均过。仅核比较式，不赋予FULL资格，也不是区间证书；代码固定菜单先写后跑一次。

复算脚本只读取冻结数据，不覆盖原JSON；首次有限群与复算均保留结果。数值审核另文记录真正核查范围，不把重复计算当独立数学证明。

## 未解决且直接决定下一轮的命题

需要在Hhat<L+的纯软尾及其余硬支持坐标层上，利用同一接收点的bad比较质量κ与good R=A/wg的关联，把保留全部原门的正余交通减未消费负项，支付为εX+C sqrt(n)polylog(n)Wβ。当前源中心信道能量的交叉密度费尚无共同来源/history预算；任意ν≤β或∫pdx=1都不能消除它。新数值进一步要求保留真正参与δ>0的低score bad来源：全score饱和的远bad来源不产生该正交通。下一轮应围绕这一配对资格与真实软尾交通的接收几何，而非再次人工加e^-aΔ或重复阈值穿越归约。

原负项N_Z已消费不返回；N_Zc、N_del各一次原位；β−ν、真实dx、唯一j、硬来源及所有尺度/分层/误差仍在。一般定理保持UNPROVED。

## 复现

归档解压后安装mpmath==1.3.0。冻结producer的main保存原历史来源哈希，直接运行依赖原本机路径；便携复现请在无相应输出JSON的新目录，复制real_joint_numeric.py、real_joint_numeric.json及replay_real_joint.py并运行python3 -I replay_real_joint.py。另以同样方式运行reverse_scale_numeric.py。channel_numeric.py仅依赖标准库，在无channel_numeric.json目录运行即可。不要覆盖冻结结果。没有编译PDF。


<!-- SOURCE source_channel.md SHA256 4257331717b8ed7253549670b1ed208229ff87581b4ab74d84d49f5ce0ca1010 -->
# R135 主推导：删源稳健的真实尺度 score 几何能量

状态：待独审。一般弱型上界未闭合；以下证明的积分变量是来源中心 y 的真实 Lebesgue 测度，不能冒作 RT1 的接收 x 或 β(dy)。

## 准确命题 SC1

固定 n≥1,b>0,c>0,t>0。沿原真实 C 定义 α(u)=(b/c)C(|u|/b)，a(u)=min(1,α(u)/t)，χ(u)=1_{α(u)<t}。令 z=∫a(u)du，θ=z^{-1}∫aχ。C>0 且可积，故0<z<∞，0≤θ≤1。有限非负 Borel 测度 ν 任意，无坐标独立假设。令 Z⊂R^n_y×R^n_v 为任意可测删源资格，

\[
w(y,v)=\prod_{i=1}^n a(y_i-v_i),\quad k(y,v)=\sum_i\chi(y_i-v_i),\quad
 e(y)=\int1_Z(y,v)w(y,v)d\nu(v).
\]

e>0 时 Π_y=1_Zwν/e；e=0时以下乘e的项约定0。则

\[
\int_{\mathbb R^n}e(y)\operatorname{Var}_{\Pi_y}k\,dy
\le z^n\|\nu\|n\theta(1-\theta).\tag{SC1}
\]

更精确右侧可以保留实际删源后二阶矩积分

\[
e(y)\operatorname{Var}_{\Pi_y}k
\le\int1_Zw(k-n\theta)^2d\nu.\tag{SC2}
\]

## 证明

任意概率变量的方差等于以所有常数为中心的二阶矩下确界。选择全局常数nθ即得SC2，删掉1_Z只增加非负量。固定v后，z^{-n}w(y,v)dy为n份同一平移一维概率a(u)du/z的乘积；χ_i独立Bernoulli(θ)，所以k均值nθ、方差nθ(1−θ)。Tonelli后对ν积分即得SC1。此独立性属于固定来源后的Lebesgue乘积积分，不属于Π_y的来源坐标。删源Z可以依赖y、t、原历史，均未要求是乘积集合。

## 正 score 交通的伴随界

对两份独立Π_y抽样，δ=[k(v)−k(v′)]_+，有Eδ=(1/2)E|k−k′|≤sqrt(Var(k)/2)。又∫e(y)dy≤z^n||ν||，Cauchy与SC1给

\[
\int e(y)E_{\Pi_y^2}\delta\,dy
\le z^n\|\nu\|\sqrt{n\theta(1-\theta)/2}
\le z^n\|\nu\|\sqrt{n/8}.\tag{SC3}
\]

任何0≤门≤1可留于原正score积分。若时间窗J⊂(0,∞)具有有限对数长度L，参数b,c固定，且每t使用对应z_t、e_t与任意可测Z_t，则Tonelli给

\[
\int_J\frac{dt}{t}\int dy\,\frac{e_t(y)}{z_t^n}
 E_{\Pi_{y,t}^2}(G\delta_t)
\le L\|\nu\|\sqrt{n/8}.\tag{SC4}
\]

这里未选择固定尺度模型，时间和删源可一般变化，但积分测度仍明确为e_t(y)dy/z_t^n。若原ν不有限，先截断ν并保留其质量，不能将无限右端登记为有限费用。

## 对原一般问题的费用缺口

RT1使用q^{-1}p(x,y)h_R(x−z)a_history dx dβ(y)dν(z)，而SC4使用dy e_t(y)/z_t^n。没有假定β对dy绝对连续，更没有已证其密度被这一量支配。β−ν、接收自适应参数、唯一j以及总来源质量||ν||不能改成Wβ。即使β绝对连续，Radon–Nikodym比也可能无界。因此SC4是任意来源/删源的准确几何能量定理，尚不是原中间硬层付款。

下一步连接的准确要求：在保留RT2真实门或一次允许的正放松后，将外测度中的来源中心与时间分布控制为SC4的信道测度，且总价格为O(Wβ)或另有可吸收εX，而非未定的密度比、||ν||或每j重复一次。没有此连接不宣称根阶闭合。该连接需要真实几何与history，而非仅把后验方差称作乘积方差。

来源：R128 joint_receiver_tail.md RT1–6定义；R131 score_energy_history.md提示Π_t坐标不独立与阈值注入未付。本推导直接证明，不调用未经核验外部定理。N04技能用于检查跨时间/层收费边界；M03技能未给本问题稳定性定理，本稿不援引其不存在的一般稳定结论。


<!-- SOURCE score_injection_audit.md SHA256 25fd268c99f8c84e2975c2561312b86d26faf0d9db352669067a7a42875cabe9 -->
# R135 score阈值注入独立先审

本稿先读必要历史，不读取任何本轮作者新稿。任务是核对含阈值原子的变测试公式及判断原实际几何是否已经支付穿越量；只写本文件，无git/PDF。原一般根阶目标仍未证明。

## SIA1. 历史定位：归约已经保存，不能重登记

实际读取R131 `score_energy_history.md`。其第2节“均值导数=穿越−方差+删除”的准确待查形式已经明确保存：

\[
\int_\tau^h\operatorname{Var}_{\Pi_t}(k_t)\frac{dt}{t}
=C_j+\sum_u\Delta_u^{del}m-(\bar m_h-\bar m_\tau),
\quad
\mathcal E_j\le C_j+n+n\sum_u r_u/e_{u-}.
\]

同一原文已区分严格score与右极限score、来源阈值原子/连续阈值测度、同点先删除后穿越、删除均值的有符号项以及Cauchy条件推论。其来源为R117的Π中心化漂移及删除公式；R131没有认证阈值总收费O(n)的一般付款。该原文明确“每个来源最多n次”不能推出漂移概率加权穿越≤n。

因此本轮候选不是新的方差耗散归约。下面只补精确Stieltjes书写与原实际阈值 incidence 结构，不重复长证，不把旧条件推论登记为新预算。

## SIA2. Stieltjes形式、阈值原子及端点

先固定有限正来源ν、有限n、0<τ<g，α_i>0；固定支持情形取e_g>0，u=log t。严格score k_t=#{α_i<t}是左连续版本，取右态\bar k_t=#{α_i≤t}用于端点和Stieltjes均值。二者仅在各来源有限阈值点不同，经ν与du的Tonelli，在时间Lebesgue积分下相同。w_t连续且局部绝对连续，分布导数为−k_tw_t du；在[τ,g]上e_t≥e_g>0。

定义正阈值注入测度dC，固定支持时为

\[
\boxed{\int f(u)dC(u)=\sum_{i=1}^n\int
1_{\{\log\tau<\log\alpha_i(v)\le\log g\}}
 f(\log\alpha_i(v))\frac{w_{\alpha_i(v)}(v)}{e_{\alpha_i(v)}}\,d\nu(v).}\tag{SIA1}
\]

重复阈值按坐标次数收费；阈值来源原子给C的原子，连续来源可给连续或奇异穿越测度。由于w≤1且e≥e_g，C总量≤nν(Rⁿ)/e_g有限；这只是允许测度交换的粗有限性，并非维数一致预算。w连续，所以阈值原子不带额外Π跳。

令\bar m(u)=E_{Π_t}\bar k_t。固定支持上的准确测度恒等式为

\[
\boxed{d\bar m=dC-\operatorname{Var}_{\Pi_t}(k_t)du.}\tag{SIA2}
\]

起点u0=logτ已用右态初始化，不再收费α_i=τ；终点采用右态并计α_i=g，所以积分域为(u0,u1]。若使用原严格score的终点k_g，应改成不计终点穿越的版本或明确加回E_{Π_g}#{α_i=g}，不能混用。时间dt/t对单端点不敏感，但均值余额对端点原子敏感。

实际Π_t含原Z_t删除，不能直接用固定支持SIA2替代。沿R131已保存的右连续Z约定，在同点先按旧score删除，再以删除后Π计穿越；SIA1的被积项应添1_{Z_{α_i(v)}}(v)。总公式另加有符号删除均值测度dM_del。删除前加权质量r_u及总量e_{u−}给

\[
\Delta_u^{del}m=(r_u/e_{u-})(m_{keep}-m_{removed}),
\quad |\Delta_u^{del}m|\le n r_u/e_{u-}.
\]

因此d\bar m=dC−Var du+dM_del。有限原交通/有限删除模型先逐区间使用，再非负测度极限；若扩展为连续删除，必须另给对应补偿/BV变动，不能直接抄纯离散跳公式。当前原模型及R131量词已经保留这一边界。

## SIA3. 原真实C核的阈值incidence与high/RC现有信息

固定实际行，原α_i=(b/c_j)C(d_i)、d_i=|y_i−v_i|/b、τ=a/c_j。一次可收费穿越τ<α_i≤g准确对应

\[
\frac ab<C(d_i)\le\frac{c_jg}b,\qquad
\theta_i(v)=\frac b{c_j}C(d_i),
\]

且阈值时的真实权重为

\[
\boxed{w_{\theta_i(v)}(v)=\prod_{l=1}^n
\min\{1,C(d_l)/C(d_i)\}.}\tag{SIA3}
\]

第i坐标因子为1。将SIA3放入SIA1并保留1_Zθ，得到完全基于原核位置的正incidence测度；没有Gaussian、坐标独立或无原子假设。其积分仍含e_θ的当前总来源分母及其随θ变化，不等于一个固定概率下的至多n次穿越。

原high/FIRST只给e_g≥2Kq/p及e_θ≥e_g，因此允许粗界

\[
C_r\le\frac p{2Kq}\sum_i\int
1_{\{\tau<\theta_i\le g\}}1_{Z_{\theta_i}}w_{\theta_i}\,d\nu.
\tag{SIA4}
\]

这一步保留同一个实际p、q、g，却**不是**一个O(n polylog n)预算：FIRST约束实际K1,K2,J,K0核积分，没有将SIA4中的坐标slab权w_θ变成这些核的统一可积支配。一般w_θ≤(g/θ)ⁿwg≤2ⁿwg只给指数级价格。核几何需另证，不能由high分母下界改名为完成。

已读R134 `receiver_rc_geometry.md` 的冻结RG13–24（本代理上轮已独审），其中实际bad余额κ_r=(Te_g)⁻¹∫_Dg K0ν，在Hhat≥L⁺分支给actual good余量ρA≤[A−M_rwg]_+；附加核心条件可捕获A/wg≤3D/(2K)。这确实删除了特定good余量来源，但C_r是**所有当前Π_t来源**的阈值注入，包含bad及未来删除来源，不能把该good捕获阈值自动作用到整个C_r。RG20仍欠κ_r与good比A/wg的实际联合尾付款，亦无全行κ_r统一下界。故已有RG13–24没有提供SIA4所需全部穿越预算。

同x结构也必须保持：θ_i由y与v决定；K0,J、bad/good及κ_r由实际x及同一g决定。不能把x删掉后以FIRST统一盖住所有θ_i位置。若定义带原good/RC/FA门的过滤incidence，其门须在穿越时以当前原状态计算；**不能仅将方差余额乘门**而把−Var变成所需过滤交通。一个随时间变测试G_t k_t会新增EΠ[k_t dG_t]并把漂移改成−CovΠ(G_tk_t,k_t)du；有跳门时还需相应同点约定。对时间固定的RC/good权虽无dG项，协方差仍非原无条件Var。保留两Π的真实δ与各门，则需另证明相应过滤能量/注入比较，不能凭C_r的形式推得。

## SIA4. Cauchy的准确交通价格与外层币种

令L_r=log(g/τ)≤log2，R_del,r=Σ_u r_u/e_{u−}（同一实际来源过程的原删除量）。R131余额给

\[
\mathcal E_r:=\int_\tau^g Var_{\Pi_t}(k_t)\frac{dt}{t}
\le S_r:=C_r+n+nR_{del,r}.
\]

对同一Π_t的两份抽样，Eδ_t=E|k_t(v)−k_t(z′)|/2≤√(Var/2)。因此原门与ρ≤1下的完整行正交通满足

\[
\mathscr F_r\le\sqrt{L_r\mathcal E_r/2}
\le\sqrt{(\log2)S_r/2}.
\tag{SIA5}
\]

这是条件行内价格；实际删除不能免费省掉nR_del。固定支持情形只用Var≤n²/4与端点0≤m≤n，已有无条件粗注入帽C_r≤n+n²L_r/4；它的阶仍为n²，不能改写成O(n polylog n)。含删除时还需相应nR_del，已有无n的删除跳质量帽不能直接充当score能量帽。

保留原完整外测度

\[
d\mathcal T_I=1_I1_{\{j(x)=j\}}q^{-1}p(x,y)h_{R(x)}(x-z)
 a_{history}\,dx\,d\beta_V(y)d\nu_V(z),
\]

记原期望及Σ_V,j隐含在以下∫外账。准确raw价格为

\[
\boxed{2\Lambda P_I^{rem}
\le2\Lambda\sqrt{\log2/2}\int1_{Ahi}\sqrt{S_r}\,d\mathcal T_I.}\tag{SIA6}
\]

若此处只再用Tsmall≤4X，则

\[
2\Lambda P_I^{rem}
\le2\Lambda\sqrt{2\log2\,X\int1_{Ahi}S_r\,d\mathcal T_I}.
\tag{SIA7}
\]

故即使另证**逐行**C_r+n+nR_del,r≤Cn polylog n，SIA6仅给O(√n polylog n)X。它没有自动转成母式所需εX+C_ε√n polylog n W_β；外真实dx、β−ν、hard z、唯一j、history及选择器费用仍须支付。若先采用SI5形式，应恢复同一实际cξ与16/3；不能再把raw硬帽和SI硬帽双领。

一个真正足以推进的下一证据，应是对SIA6的**真实外行平方根负载**建立输入质量付款，或在原双门/RC过滤交通上建立相应注入—能量价格并保留所有新门变动项。仅给坐标穿越次数n、阈值测度总质量有限、每行O(n)形式或删除概率总帽，均未达到这一付款要求。

## SIA5. 本轮决定与交付范围

1. 候选d均值=阈值穿越−方差(+实际删除)准确；含阈值原子的Stieltjes形式、端点及交换已核准，且归约已在R131原文保存。本轮不登记重复新成果。
2. 新保存SIA3–4是原真实C核位置的注入incidence与same-x high的准确粗上界；它们明确暴露当前需要比较的阈值slab权、e_θ及核容量，不把FIRST/RC的既有门推成全注入帽。
3. 已有R134 high/RC耦合没有给出一般O(n polylog n)总阈值注入预算；本审未证明该预算，也未声称它不可能。最直接的下一步是保留真实门，在阈值incidence上证明核比较/捕获支持的联合外层价格，或证明对应过滤能量关系；不是再重证−Var归约。
4. R134 FA面积小层已有独立ε_DX局部付款，应在当前余项先不交删除后再研究其补集。它不支付全部注入，也不赋予新的ε余额。原N_Z已消费不返还，N_Zc/Ndel各一次且不附正项过滤门。

**最终判定：精确独审完成，通用注入预算仍未证明。** 输出的是历史定位、原子/端点合法性、实际核阈值结构与下一付款证据的准确要求；未读取任何R135作者新稿，未把条件行内根阶价格登记为一般闭合。完成停。

## SIA6. 来源通道命题独立先审（未读本轮作者SC稿）

本节在SIA1–5独立结论落盘后，收到主代理指定的新命题，仍先不读取 `source_channel.md`。先固定有限正来源ν，令一维α(u)>0、a_t(u)=min(1,α(u)/t)，假设0<z_t=∫a_t(u)du<∞，并定义

\[
\theta_t=z_t^{-1}\int a_t(u)1_{\{\alpha(u)<t\}}du.
\]

在Rⁿ上w_t(y,v)=∏_i a_t(y_i−v_i)，k_t(y,v)=Σ_i1_{α(y_i−v_i)<t}。删源Z_t(y,v)可以是**任意共同可测的非乘积集合**，乃至删源接受因子η_t(y,v)∈[0,1]；定义e_t(y)=∫η_t w_tν，Π_t=η_t w_tν/e_t于e_t>0处。e_t=0处把e_t Var贡献定义为0，不作0/0；ν=0时全式为0。

条件方差是固定中心平方误差的最小值，因此点态

\[
e_t(y)Var_{\Pi_t}(k_t)
\le\int\eta_t w_t(k_t-n\theta_t)^2d\nu
\le\int w_t(k_t-n\theta_t)^2d\nu.
\]

对每个固定v，以u=y−v平移，w_tdy/z_tⁿ是真实Lebesgue通道的产品概率；k_t是此**通道变量**下n个独立同分布Bernoulli(θ_t)之和。ν本身及η_t均不需产品结构。非负Tonelli得准确上界

\[
\boxed{\int_{R^n}e_t(y)Var_{\Pi_t}(k_t)dy
\le z_t^n\|\nu\|\,n\theta_t(1-\theta_t).}\tag{SIA8}
\]

严格α<t应同时用于k_t与θ_t；本证明不需把它改成≤，所以阈值原子约定无歧义。dy通道中的某阈值等值层是否零测也不是前提。e_t≤‖ν‖；完整通道∫e_tdy≤z_tⁿ‖ν‖，故上述二阶积分有限，条件概率及Tonelli合法。

原α(u)=(b/c_j)C(|u|/b)时，F=max(h₁,φ)≤h₁+φ给∫C≤2，故z_t≤2b²/(c_jt)<∞且z_t>0。该z_t是**一维Lebesgue质量**，不是e_t，不是概率归一化后的1；右侧必须保留z_tⁿ与真实ν总质量‖ν‖。SIA8只付e_tdy加权通道方差，不付β(y)、实际dx或q⁻¹ph_R外测度。

若同一Π_t两份来源拷贝构成真实产品抽样，则EΠ²δ_t≤√(VarΠ/2)，这里1/√2来自E(k−k′)²=2Var与δ=|k−k′|/2的均值身份，不能误记1/2。该推论仍须留原e_t权或另付改变权重的价格；不把e_tdy上界冒作无权Π时间预算。

**独立先审：SIA8通过。** 先保存以上证明后，才允许读取作者SC1–4核对规范及外账。

## SIA7. 作者source_channel.md的SC1–4实读后审

SIA6独立证据已落盘后，才读取 `source_channel.md`。实读SHA-256为 `4257331717b8ed7253549670b1ed208229ff87581b4ab74d84d49f5ce0ca1010`。其SC1–2的a,z,θ、任意有限ν及任意共同可测Z规范与SIA6完全一致，方差最小中心的方向正确，非乘积删源只作为[0,1]资格放松，不被误认作来源独立性。

**SC1–2 PASS。** z>0有限；实际C可积给上游合法性。严格χ=1_{α<t}同时用于k与θ，无阈值约定混用。ν=0或删源使e(y)=0时贡献定义0，未计算0/0；e≤‖ν‖且∫e dy≤zⁿ‖ν‖，非负Tonelli及有限二阶矩合法。产品独立性仅在每个固定来源v后的a(y_i−v_i)dy_i/z通道中成立，作者明确区分Π_y的来源坐标。

**SC3 PASS。** 两Π是同一后验概率的两份独立来源抽样；不要求该后验内部坐标独立。δ的期望等于E|k−k′|/2，其二阶Cauchy给√(Var/2)，继而

\[
\int eE\delta\,dy\le
\sqrt{\left(\int e\,dy\right)\left(\int eVar\,dy\right)/2}
\le z^n\|\nu\|\sqrt{n\theta(1-\theta)/2}.
\]

θ(1−θ)≤1/4给最后√(n/8)常数正确。右侧保留一维Lebesgue质量的n次方zⁿ以及真实来源总质量‖ν‖，没有将其抹成1或替换β质量。

**SC4 PASS（信道测度下的时间预算）。** b,c固定、每t采用对应z_t,e_t及任意可测删源Z_t，非负0≤G≤1可依赖原两个来源与history；直接点态放松并Tonelli，得到长度L乘‖ν‖√(n/8)。原时间权明确是dt/t、dy e_t(y)/z_tⁿ，这个归一化不能移植到原RT1/RT2的β(dy)、真实dx及e_t⁻²来源对因子。作者完整列明连接缺口，未以时间积分的规范化抵消原未知密度比。

实际ν不有限时需先指定有限截断，定理只以截断后真实质量收费；作者没有声称无限右端是有限支付，也未以截断后的Π自动替代原Π的完整交通。

**后审最终判定：SC1–4 PASS。** 得到任意来源/任意删源的准确e_tdy信道方差及正score时间预算，这属于独立成立的来源中心Lebesgue几何定理。尚未支付原β−ν、实际接收dx、q⁻¹ph_R、唯一j/history/参数选择与来源质量到W_β的连接；不能登记为原一般弱型闭合。SIA1–5的阈值注入历史定位与未付外账仍成立，不被这条不同测度的通道定理取消。完成停。


<!-- SOURCE joint_geometry.md SHA256 f3ec5be1ab0929bb8d55601312a4c4683bd58bb556e4b8b7011b7eaeb40c207f -->
# R135：RG 阈值之后的同接收点联合尾

状态：检查点完成；R>M_r后的联合尾未付，不把小误差条带作为一般根阶付款。

## 1. 量词和原交通

固定原完整实际行r，包含同一x、实际s,L,R,g、历史、硬来源z；原Π_t、δ、good/bad、Ψ、χ_FA、ρ全保持。只在RG16分支Hhat≥L⁺使用

\[
R(v)=A(v)/w_g(v),\quad
\kappa_r=(Te_g)^{-1}\int_{D_g}K_0\,d\nu,\quad
M_r=3D\min\{p/(KTC_r),2\kappa_r q/Q_J\},
\]
\[
\rho(v)A(v)\le[A(v)-M_rw_g(v)]_+.
\tag{JG135.1}
\]

所有量随实际x变化，R、M、ρ不随随后积分的t重选。α_rec>0只在非零high行逐行成立，不提供统一下界。D始终是原RC参数，不另分配新的捕获容量。

## 2. 一个可付的小条带，仅作辅助检查

对确定η>0，加入原正交通的终端来源指示0<R−M_r≤η。该指示与ρ均不依t；原FTC给该行内正交通

\[
\mathcal F_{r,\eta}\le e_g^{-1}\int_{S_g}
1_{0<R-M_r\le\eta}\rho A\,d\nu
\le\eta e_g^{-1}\int_{S_g}w_gd\nu\le\eta/2.
\tag{JG135.2}
\]

最后一步严格在同一x用good/FIRST/high。恢复完整raw外测度d𝒯、signed因子2Λ，只用一次T_small≤4X，得价格4ΛηX。故η≤ε/(4Λ)可用显式ε槽支付该条带；该层允许任意W_g。若已删FT11面积层，必须在其补集中取本条带，不能重收两份同一交通。

这只是RG20阈值上方的有价窄层，不是本轮主成果，也不推断覆盖了任何固定比例的实际剩余交通。接下来只考虑R>M_r+η。

## 3. 进一步联合估计所需的几何：score 不保留尾深度

为检查“正δ迫使bad端K₀比较质量可付”这一候选命题，固定原同一实际x、y与参数，考察真实比值

\[
Z_r(z')=K_0(z')/(T w_g(z')).
\tag{JG135.3}
\]

当Hhat<b时，即使其余坐标保持固定且有限，仅让一个坐标z'_i趋于±∞，原尾
φ(r)∼k e^{-r}/r、C(r)∼k²e^{-r}/r（k=2sinh(1/2)）给

\[
\log Z_r(z')=
-|z'_i|(1/\widehat H-1/b)+O(1),
\tag{JG135.4}
\]

其中O(1)依赖该实际行及固定其余坐标，不依赖趋于无穷的坐标。因为尾分母和分子各有同阶1/|z'_i|，这里没有残留log|z'_i|。而该坐标进入α_i<t后对k_t(z')的贡献恒为1；它对Δ_t(z')的贡献恒为log(g/t)。所以单凭δ、k_t或Δ_t的数值，不能恢复这个丢失的尾深度。

这不是抽象来源反例，也没有替上述位置授予原bad/live/history资格。它只是对实际核候选推论的量词检查：任何把Z_r的正下界仅写成k_t或Δ_t函数的全位置引理在Hhat<b时都不成立；需要额外原门/接收积分信息。Hhat=b时JG135.4的指数退化，此诊断不能移植到该边界。

原bad门未直接修复该缺失：在上述一坐标极限，J/wg趋于正的有限行依赖值；K1/wg、K2/wg在相应尺度严格小于b时趋于0。bad的核比比较于是可能具有有限极限，而Z_r继续指数下降。是否真的通过原bad门须检验该极限与p/K，不能由尾位置本身断定失败。原high/FIRST控制同源积分，仍可能排除某些共同配置，本稿没有将这一步省略。

## 4. 没有偷换外费用的来源分解检查

记κ_r=(1/e_g)∫_{D_g}Z_r wg dν。对u>0及d≥0，将bad端取真实层

\[
B_{u,d}(t)=D_g\cap\{Z_r\ge u,\ \Delta_t(z')\le d\}.
\tag{JG135.5}
\]

因wt=wg e^{Δ_t}及e_t≥e_g，准确有

\[
\Pi_t(B_{u,d}(t))
\le e^d\frac{e_g}{e_t}\frac{\kappa_r}{u}
\le e^d\kappa_r/u.
\tag{JG135.6}
\]

这保留同一Π_t，未拿Π_g替换它。因δ≤n，单行该部分粗价最多n log(g/τ)min(1,e^dκ_r/u)，而log(g/τ)≤log2。它在κ很小且bad比较比值≥u、未来面积≤d时提供抑制；但κ小的剩余bad质量可以落在Z_r<u或Δ_t>d，JG135.4显示前者不能被score自动排除。因此JG135.6没有闭合联合尾，更不能将各u,d壳分别用同一4X或Dq付款。

此检查使剩余义务更具体：需要在原high/good/bad及χ_FA共同限制下，对**good端R>M_r+η，同时bad端Z_r低且对δ有贡献**的真实来源对，利用其尾深度支付接收积分。单独估计κ_r、单独估计R、或单独使用FT8的低面积价格都没有给这笔交叉项。

## 5. Lebesgue 产品能量与真实 dx 的匹配检查

主代理的来源信道引理给出真实Π_t（允许任意y依赖删源）下

\[
\int e_t(y)\operatorname{Var}_{\Pi_t}(k_t)dy
\le Z_1(t)^n\|\nu\|\,n\theta_t(1-\theta_t)
\le nZ_1(t)^n\|\nu\|/4.
\tag{JG135.7}
\]

这里Z₁为无删源一维权重的Lebesgue质量，θ_t为该归一化核的活动概率；本稿不重复其产品证明。检查重点是能否由真实dx积分把原来源中心β匹配到e_t(y)dy。

由于ν≤β≤f且f∈L¹，写b_V(y)=dβ/dy。固定V,j,t，令

\[
H_{j,t}(y)=b_V(y)\iint q^{-1}p_x(y)h_{R(x)}(x-z)
 a_r\,1_{\{t\text{在该实际行的合法时间域}\}}dx\,d\nu(z),
\tag{JG135.8}
\]

a_r在此保留全部只依外行的原接受因子及high，所有量取实际接收选择器。只为检验能量路线，暂在**正上界**中删去来源对门、ρ、χ_FA。因为同一Π_t的D_t=Eδ≤√(Var(k_t)/2)，得到固定层的严格上界

\[
\mathcal P_{j,t}\le\int H_{j,t}(y)
\sqrt{\operatorname{Var}_{\Pi_t}(k_t)/2}\,dy
\]
\[
\le\sqrt{\frac{nZ_1(t)^n\|\nu\|}{8}}
\left(\int_{e_t>0}\frac{H_{j,t}(y)^2}{e_t(y)}dy\right)^{1/2}.
\tag{JG135.9}
\]

零e_t行不贡献。第二行由JG135.7及加权CS给出；截断下可取扩展非负值，不能默认新交叉积分有限。这明确暴露了**β与ν后验不匹配的交叉费用**，没有把它改称常数。

此处真实dx已完整进入H。固定(y,j,t)后的Π_t、k_t不依x；如果进一步删门后仅用固定核∫p dx=1，结果仍是β(dy)，绝不会变成e_t(y)dy。ν≤β≤f也不给b_V/e_t的统一上界；β−ν不能删，即使额外β=ν也没有得到该密度比帽。若试图平移来源中心y到x，w_t可用原C的平移比较，但原Z_t(y)的删源集合同时变化，不能据无删源权重比推出原e_t或后验的比较。粗指数平移价还需单独积分，不能隐藏。

因此JG135.9没有完成目标εX+C√n polylog(n)Wβ。它的√n系数乘着尚未付款的实际交叉费用；即使取得逐行O(√n)再套T_small≤4X，也只得到√nX，量纲仍不对。要保留RG20带来的same-x收益，就必须在尚未删来源对门的联合积分内支付JG135.9对应的交叉匹配，或找到直接运输到产品能量的共同测度；本稿没有这个证书。

## 6. 本轮结果与唯一停点

没有证明R>M_r+η中间重尾交通的一般根阶费用。JG135.2是有明确外价格的小条带，按要求只作辅助记录，不作为本轮主成果。JG135.4–6核验了按score/面积补足RG20的路线；JG135.9明确记录了接入O(n)来源信道能量时的真实β—ν交叉费用。

唯一剩余的共同缺口是：**利用实际good/high/bad/χ_FA/RC几何，把低Z_r的bad来源与R>M_r+η的good正交通，在真实dx积分后匹配到可由Wβ支付的来源中心能量。** 尾深度与β—ν交叉费用是这个匹配的两个具体部分，而不是两个可独立免费估计的常数。现有式子只描述或重新分解该交通，没有给出其一般预算。

全部费用采用完整raw d𝒯：真实dx、β−ν、硬z、q⁻¹、唯一j、种子/history和时间都在；若转SI5才使用其外16/3，不能叠加到已由T_small≤4X支付的raw价格。未取得的新一般预算不登记为已付。N_Z不返回，N_Zc/Ndel各一次且不附本稿正项分层。没有构造抽象否定例，没有数值或git/PDF。到这一具体检查点停止。

## 7. 补充几何结果：覆盖 Hhat<L⁺ 的真实硬支撑计数比较

本节继续前述检查点，给出对遗漏分支有效的新点态联合不等式；前述一般根阶未闭合的结论仍成立。记h=Hhat。条件h<L⁺只是原低测试尺度小于第二测试尺度，**不等于下钳位h=a**。冻结数值中相应正余量行的h均仍大于a；两种分支不得混称。

### 7.1 全位置核比较与全部费用

固定同一实际x，取H∈{L,L⁺}⊂[a,b]，令

\[
K_H(v)=P_{s,H}(x-v),\quad J(v)=P_{1,b}(x-v),\quad
m_H(v)=\#\{i:|x_i-v_i|\le H/2\}.
\]

实际严格s>0，φ>0，因此可定义

\[
G_H=1+\frac{1-s}{s\phi(H/(2b))},\qquad
B_H(v)=\left(\frac{sb}{H}\right)^n G_H^{m_H(v)},
\quad C_J(v)=1+B_L(v)+B_{L^+}(v).
\tag{JG135.10}
\]

则对所有原参数和所有来源位置（不要求h≥L⁺）严格有

\[
\boxed{K_H(v)\le B_H(v)J(v),\qquad
Q_x^*(v)\le\frac{C_J(v)}3J(v).}
\tag{JG135.11}
\]

证明逐坐标进行，但不逐坐标重选整维测试。写r=|x_i−v_i|。由于H≤b和φ偶单调，φ(r/H)≤φ(r/b)。在硬支撑r≤H/2内还有φ(r/b)≥φ(H/(2b))。故

\[
\frac{H^{-1}[(1-s)1_{r\le H/2}+s\phi(r/H)]}
 {b^{-1}\phi(r/b)}
\le\frac{sb}{H}
\left[1+\frac{1-s}{s\phi(H/(2b))}1_{r\le H/2}\right].
\tag{JG135.12}
\]

将n个原坐标相乘恰得JG135.11第一式；再按原三个整维测试求和得第二式。不存在2^n项展开、坐标独立来源假设或新FIRST核。全部n、s与尺度费用已在B_H中显式保存；特别sb/H>1时即使m_H=0，仍有指数费用，不能省略。

### 7.2 同一 bad 来源余额转成新捕获阈值

保留原RG13–15的实际行余额与bad比较质量：

\[
\alpha\ge DT e_g\kappa_r/Q_J,\qquad
\kappa_r=(Te_g)^{-1}\int_{D_g}K_0d\nu,
\qquad p e_g\ge2Kq.
\tag{JG135.13}
\]

Q_J=0为零来源行，不作除法。对原good来源，JG135.11与pwg≤KQ给

\[
J(v)\ge\frac{3p}{K C_J(v)}w_g(v).
\tag{JG135.14}
\]

定义实际来源点的低核比较比值Z_r(v)=K₀(v)/(Twg(v))，并令

\[
\boxed{\widetilde M_r(v)=D Z_r(v)
+\frac{6D\kappa_r}{C_J(v)}\frac q{Q_J}.}
\tag{JG135.15}
\]

由JG135.13–14，在同一实际x上的原good来源满足

\[
\frac{DK_0(v)+\alpha J(v)}{T}
\ge\left[D Z_r(v)+\frac{3p e_gD\kappa_r}{KQ_JC_J(v)}\right]w_g(v)
\ge\widetilde M_r(v)w_g(v).
\]

因此真实RC余量有

\[
\boxed{\rho(v)A(v)\le[A(v)-\widetilde M_r(v)w_g(v)]_+,}
\]
\[
\boxed{R(v)\le\widetilde M_r(v)\ \Longrightarrow\ \rho(v)=0}
\quad\text{在原good且A>0的来源上。}
\tag{JG135.16}
\]

在E上ρA=(A−(DK₀+αJ)/T)_+：当DK₀≥TA时两边都为0，当DK₀<TA时这正是原U=DK₀的定义。good的E外按A=0或B=1原捕获约定处理。因此JG135.16对原正交通全部相关来源成立。它保留DK₀本身的贡献，没有为利用J而丢掉该项。

与RG20不同，JG135.16**覆盖h<L⁺**，也覆盖其他h；用的是全位置硬支撑计数和原纯软测试J的几何，未以接收积分后的sup补回FIRST。C_J、Z_r及Mtilde虽随v变化，但均由原实际行及终端来源定义，不随t重选。因而可乘原χ_FA、Ψ、真实δ和Π_t²；它没有给负项添加任何门。

### 7.3 无指数损失的可检查分支

定义真实几何层

\[
\mathcal G_r=\left\{v:\
 n\log(sb/H)+m_H(v)\log G_H\le0
 \text{ 对 }H=L,L^+\text{ 均成立}\right\}.
\tag{JG135.17}
\]

其条件正是B_L≤1且B_L⁺≤1，故C_J≤3。在该层，保留q/Q_J≥1，得到

\[
\widetilde M_r(v)\ge D Z_r(v)+2D\kappa_r q/Q_J
\ge D Z_r(v)+2D\kappa_r.
\tag{JG135.18}
\]

这是原行可直接检查的几何分支，不是对全类的新增假设。特别，若m_L⁺(v)=0且L≥sb，则v∈𝒢_r；此时两个混合测试在该来源的所有坐标均无硬贡献，真实费用C_J=1+(sb/L)^n+(sb/L⁺)^n≤3。条件JG135.17更允许一定数量的硬坐标，其数量费用已精确保留，不能未经估计便把该计数视为典型小量。

严格软端s=1仍可直接用JG135.10、17，其中G_H=1；没有除以logG_H。若L<sb或硬坐标过多，则继续使用原B_H全费用，不声称这部分维数价格已付。

本节只读取冻结`real_joint_numeric.json`及其`post_run_interpretation`，未新增或重跑样本。其10个base-necessary正余量行位于h<L⁺；列出的good来源坐标均满足|x_i−v_i|≥0.8>b/2=0.5，且L=0.9≥sb，故它们落在上述m_L⁺=0的可检查分支。这只是对**新比较适用域**的检查；数值仍未认证FULL/history、连续来源或一般维数率，也不能据此断言Mtilde已捕获这些正余量点。原文件的qualified门包含旧RG16，不能把其qualified全零误解为base-necessary不成立。

## 8. 新结果的预算身份与最后缺口

JG135.16给出了覆盖先前遗漏尺度分支的实际联合捕获阈值。JG135.18在明确的真实硬支撑计数层去掉了比较式的指数维数损失。凡R≤Mtilde的原交通均已有ρ=0，因此仍属于原RC已付捕获，不申请第二份Dq，也不将小条带作为主结果。

对其余来源，FTC仅给

\[
\int\rho\,d\mu_r\le e_g^{-1}
\int_{S_g}[A(v)-\widetilde M_r(v)w_g(v)]_+d\nu(v).
\tag{JG135.19}
\]

JG135.19尚未付清，不能登记为一般根阶费用。下一步准确缺口现在是：在𝒢_r内控制R相对D Z_r+2Dκ_r的真实联合尾，并在𝒢_r外支付显式B_H硬坐标费用；二者须与原good/bad/χ_FA及真实dx共同作用，最终给εX+C√n polylog(n)Wβ，不能给√nX后宣称完成。

本节没有消除先前记录的β—ν交叉匹配费用，但已提供缺失分支可用的实际核比较及捕获阈值。全部外d𝒯、β−ν、q、时间、j、选择器、signed2Λ以及SI5次序下的16/3按前文保留；负项均不改变。至此冻结本文件，等待主代理审计。


<!-- SOURCE reverse_scale_audit.md SHA256 e5d8960625370890a5dc667f7e602ef20d0338a08aff99b5f081850bde485ca6 -->
# R135 反向尺度真实核界独立先审

本先行稿先核主代理提供的准确命题，不读取 `joint_geometry.md` 新节。仅写本审文件，不改作者，无git/PDF。结果用于扩大实际同接收点的条件捕获范围，不登记一般根阶预算。

## RSA1. 对J的真实混合核比：每个硬端点都保留

固定实际同一个x、b>0、0<s≤1，r=1−s，0<H≤b。令J(v)=b⁻ⁿ∏φ((x_i−v_i)/b)>0，K_H=P_(s,H)(x−v)。定义

\[
m_H(x,v)=\#\{i:|x_i-v_i|\le H/2\},\qquad
B_H(x,v)=\left(\frac{sb}H\right)^n
\left[1+\frac{r}{s\phi(H/(2b))}\right]^{m_H(x,v)}.
\tag{RSA1}
\]

φ偶且在[0,∞)上非增。因为H≤b，每坐标软项有φ((x_i−v_i)/H)≤φ((x_i−v_i)/b)。硬支撑外(|x_i−v_i|>H/2)，密度比至多sb/H；硬支撑内及端点，φ((x_i−v_i)/b)≥φ(H/(2b))，故比至多

\[
\frac bH\left[s+\frac r{\phi(H/(2b))}\right]
=\frac{sb}H\left[1+\frac r{s\phi(H/(2b))}\right].
\]

逐坐标乘积，准确得

\[
\boxed{K_H(v)/J(v)\le B_H(x,v).}\tag{RSA2}
\]

这是所有位置的真实点态核上界，不需ν或x积分、来源独立或Hhat条件。s>0保证式中分母合法；s=1时仍成立。若s=0，应另作纯硬表达，不能在RSA1中计算0·∞；本原模型实际s>0，无需这种延拓。硬帽若采用闭端点支撑，≤端点计数完全正确；即便原帽开/闭仅差Lebesgue零集，为面对任意原子来源的点态比较仍必须保守用≤。

L⁺=min(b,γL)且L≤L⁺≤b，两个原混合测试有

\[
K_1+K_2+J\le C_J(x,v)J(v),\quad
C_J(x,v)=1+B_L(x,v)+B_{L^+}(x,v).\tag{RSA3}
\]

C_J是随实际x、原参数和**当前来源v**变化的函数，不是整行常数；后续不可未经控制把它提出来源积分。

## RSA2. 同x good/high/RC余额的正部阈值

固定非零实际高支行，保留原good p w_g(v)≤KQ*(v)，Q*=(K1+K2+J)/3；K>0、p>0、e_g>0、Q_J=∫Jν>0。沿原R134共同余额，κ_r=(Te_g)⁻¹∫_Dg K0ν、α≥DT e_gκ_r/Q_J，且high p e_g≥2Kq。

在actual good来源上，RSA3给

\[
J(v)\ge\frac{3p}{K C_J(x,v)}w_g(v).
\]

在E上原ρA=(A−(DK0+αJ)/T)_+；舍去非负DK0只放大余量。于是

\[
\rho A\le\left[A-\frac{3p\alpha}{KT C_J}w_g\right]_+
\le\boxed{\left[A-\frac{6D\kappa_r q}{Q_J C_J(x,v)}w_g\right]_+.}\tag{RSA4}
\]

最后一步的常数6准确来自good的3与high的2，T、K均消去，分母Q_J与C_J完整保留。E外actual good正交通余权按原约定为0，故同一上界仍成立。所有量在同一个真实接收点x及同一g、p、ν、Q*上定义，α与κ_r仍依整份实际来源而非逐v重选。

这里完全不需要Hhat≥L⁺，因为用的是K1,K2对J的比较，而K0只通过已有bad余额κ_r进入。它因此覆盖原Hhat<L⁺的反向尺度分支，但不使κ_r或C_J变成来源无关的固定常数。可乘原χ_FA、δ、Π_t²、history等非负正因子，不能将这些门添到负项，也不重复领取Dq捕获容量。

## RSA3. 零硬坐标且L≥sb的准确阈值与付款边界

若m_{L^+}(x,v)=0，则所有坐标严格在L⁺硬支撑外，亦有m_L=0。因此

\[
C_J=1+(sb/L)^n+(sb/L^+)^n.
\]

附加实际尺度条件L≥sb，因L⁺≥L，有C_J≤3；RSA4阈值至少2Dκ_r q/Q_J。故这个**实际good、零硬坐标且L≥sb**来源层满足

\[
\rho A\le[A-2D\kappa_r(q/Q_J)w_g]_+,
\quad \rho=0\ \text{若}\ A/w_g\le2D\kappa_r q/Q_J.
\tag{RSA5}
\]

硬端点|x_i−v_i|=L⁺/2应计入m_{L^+}，故不属于零硬坐标层。L≥sb不能省略；若L<sb，则(sb/L)^n可指数增长，即便没有硬坐标也不能宣称C_J≤3。一般正m_H还保留真实硬加成的m_H次幂，不把有限数值观察当成通用费用帽。

**独立先行判定：RSA1–5 PASS。** 所有核比较、6与2的系数、源依赖和硬端点约定准确；不需Hhat≥L⁺。新结果扩大了真实same-x条件捕获范围，不支付κ_r与good来源A/wg、硬计数m_H的联合尾；实际dx、β−ν、唯一j、history、选择器及母式外系数仍保留。先行证据已落盘，等待作者新增节后实读后审。

## RSA4. 冻结作者§7–8后审绑定与DK0加项

RSA1–5独立先行全部落盘后才读取 `joint_geometry.md` 新增§7–8。实读SHA-256=`f3ec5be1ab0929bb8d55601312a4c4683bd58bb556e4b8b7011b7eaeb40c207f`，与主代理冻结通知一致。本后审只核新§7–8的数学命题及费用边界，前文的诊断历史不重复长审；数值行数及样本资格不作为本审代数证明的前提。

**JG135.10–14 PASS。** G_H、B_H、C_J与先行RSA1–3完全一致；φ偶单调，H≤b，硬端点≤H/2均正确。逐坐标比较后各自完整乘积，仍是原两个整维混合测试，不作逐坐标测试赢家选择。所有s,n与尺度费用显式保留，尤其sb/H>1时零硬坐标仍可有指数价格。J>0、实际s>0使除法合法；Q_J=0作为零来源行不除。good、bad余额及high均在同一实际x、g、ν上调用，没有先放松接收积分后补回FIRST。

作者比独立先行更强，保留Z_r(v)=K0(v)/(Twg(v))。wg>0，故

\[
\frac{DK_0(v)+\alpha J(v)}T
\ge D Z_r(v)w_g(v)
+\frac{3p\alpha}{KT C_J(v)}w_g(v)
\ge\left[D Z_r(v)+\frac{6D\kappa_rq}{Q_JC_J(v)}\right]w_g(v).
\]

因此JG135.15的Mtilde=DZ_r+6Dκ_rq/(Q_JC_J)及JG135.16正部上界准确。加项DK0只是原被减项的完整保留，新J阈值只消耗αJ的比较，不在该证明中重复利用同一DK0。不能把原RG20已同时使用DK0和αJ的阈值再无条件加DZ_r；当前作者没有这种重复扣除。

在E上统一身份ρA=(A−(DK0+αJ)/T)_+正确，即使U=min(TA,DK0)：若TA≤DK0，原F≥TA，ρA=0，统一正部亦为0；若TA>DK0，U=DK0给准确身份。作者关于“当DK0≥TA时两边都为0”亦正确，因为Mtilde w_g≤(DK0+αJ)/T并非单凭该不等式能保证上界右边0，但**Mtilde w_g自身包含DK0/T≥A**，所以右边确为0。good的E外余ρ依原A=0/B=1约定为0；R≤Mtilde且A>0时必ρ=0。

**反向尺度与源依赖 PASS。** 本证明不要求h=Hhat≥L⁺，故覆盖h<L⁺且也覆盖其他h；h<L⁺不等同下钳位h=a。C_J、Z_r、Mtilde依赖当前v及实际行，κ_r与α依整份ν，均在终端g定义而不随随后t重选。可乘原正χ_FA、Ψ、δ及Π_t²，不能把新门附给原负项。

## RSA5. B_H≤1硬计数层、FTC尾与最终判定

实际s>0时B_H>0且G_H≥1，故

\[
B_H\le1\quad\Longleftrightarrow\quad
n\log(sb/H)+m_H\log G_H\le0.
\]

JG135.17对H=L与L⁺同时要求此条件，等价于两比较费用均≤1，因而C_J≤3。它既包含先行m_L⁺=0且L≥sb层，也允许一定的硬坐标数；每个硬计数费用保留在m_H logG_H中，没有声称它普遍很小。s=1时G_H=1、logG_H=0，作者不除以logG_H，因此端点仍合法。

在此层，Q_J≤q且Q_J>0给

\[
\widetilde M_r\ge D Z_r+2D\kappa_r(q/Q_J)
\ge D Z_r+2D\kappa_r,
\]

即JG135.18系数2准确。零硬层硬端点仍按≤计数；L<sb或硬计数太大时只能保留全B_H费用，不能免费裁成1。作者清楚将这些作为原行可检查的来源条件，未当成全类新假设或输入独立捕获比例。

同一实际终端来源下Mtilde不依t，既有FTC测度支配μ_r≤1_S Aν/e_g给JG135.19

\[
\int\rho\,d\mu_r\le e_g^{-1}\int_{S_g}[A-\widetilde M_r w_g]_+d\nu.
\]

原来源对门、χ_FA、history可继续留在原正交通上使用JG135.16；FTC放松本身不认证右侧的统一尾价格。下一未付量是𝒢_r内R相对DZ_r+2Dκ_r的联合尾，以及𝒢_r外显式B_H硬计数/尺度费用，连同真实接收dx及β−ν、q、时间、唯一j、参数/soft选择、种子/history和外2Λ。若转SI5只能在该次序使用其16/3，不能与raw硬帽重复收费。

本条界只描述已付原RC捕获的更准确支持，没有申请第二份Dq；未捕获尾仍留账。N_Z已消费不返还，N_Zc/Ndel各一次且不附新捕获/计数正门。冻结数值段只被作者作为适用域诊断，本审未复核其十行原始数值、不以其FULL/history资格支持数学证明；代数及适用域的通过不依赖这些样本。

**冻结后审最终判定：JG135.10–19 PASS（全位置核比较与真实条件捕获界）。** 新Mtilde保留DK0自身贡献，覆盖旧遗漏h<L⁺分支；硬计数层去指数比较费用的条件及常数正确，未发现需修改的数学错误。它是新实际同x核几何结果，不是原一般根阶总预算。完成停。


<!-- SOURCE area_flux.md SHA256 60fc3bd5a20e51dfbe4f68b1e2c5e1358e9d588f94cc77b70bc0bf339f44be84 -->
# R135：真实下降通量与归一化面积权重

状态：先审命题，再证明。只写本文件，保留原时间、同一来源概率、真实接收点和所有选择器；不修改负门，不重复领取各层总质量。不操作 Git/PDF。

已读取 N04 `SKILL.md`、`references/provenance.md`、`references/cube-interface.md` 和 `references/method.md`。其条件望远镜要求势能有统一下界、下降项非负、误差部分和有预算。本稿不引用其邻接题录为原定理，也不把技能名称当成中心立方体结论；以下是对原乘积权重的独立迁移推导。

## 1. 量词与候选审查

固定原合法有限交通截断 I 及完整实际接收行 \(r=(\omega,V,j,x,y,z,\mathrm{history})\)。保留同一行的 \(p,Q_x^*,g=g(x),D_g,S_g,\Psi,\chi_{FA},\rho_{rec}\)，以及真实 \(\Pi_t=e_t^{-1}1_{Z_t}w_t\nu\)。令 \(\tau=a/c_j\)、\(h=g e^{-u_{old}/n}\)、原 \(J_{far}\subset[\tau,h]\)，以及
\[
 k_t(v)=\#\{i:\alpha_i(y,v)<t\},\quad
 \delta_t(v,z')=[k_t(v)-k_t(z')]_+,
\]
\[
 \Delta_{t,g}(v)=\log(w_t(v)/w_g(v))
 =\int_t^g k_u(v)\frac{du}{u}.
\tag{AF1}
\]
原 \(Z_g\subset Z_t\)、\(e_t\ge e_g>0\)、\(\tau\le g\le2\tau\)。所有原 soft/history 限制仍在原外行测度 \(d\mathcal T_I\) 中，\(T_{small}\le4X\)。来源向量可以相关；两份 \(\Pi_t\) 同分布，且可随 t 改变。

候选 A：由 \(w_t\) 沿 t 下降，原未加权的 \(\Delta\ge d\) 正交通是否能自动得到 \(Ce^{-cd}X\)？先不采纳；高 \(\Delta\) 表示未来尚有大量下降，而非该时刻原质量已小。

候选 B：对预先固定 \(a>1,d\ge0\)，给原正项增加明确权重 \(e^{-a\Delta}1_{\{\Delta\ge d\}}\)。所有实际门不变。预期存在一次性的通量价格
\[
 2\Lambda P_{I;a,d}^{rem}
 \le\frac{4\Lambda}{a-1}e^{-(a-1)d}X.
\tag{AF2}
\]
这是量纲与原外测度一致的**加权**候选，不是未加权高面积层的预算。必须查明原 \(\rho\)、FA 或其他已保留门是否实际提供这种衰减，才能用它支付原项。

候选 C：把所有面积层绑定到同一正下降测度，望远镜总和只收一次端点通量；不得给每个壳重新领取 \(T_{small}\)。若端点通量经过 \(e_g\) 归一化仍无统一预算，则明确记录失败，不将其改名为新来源矩。

## 2. 精确通量剖面：先望远镜，再来源积分

对每个实际 v，\(w_t(v)>0\) 连续，分段可微且几乎处处满足
\[
 -dw_t(v)=k_t(v)w_t(v)\frac{dt}{t},\qquad
 -d\Delta_{t,g}(v)=k_t(v)\frac{dt}{t}.
\tag{AF3}
\]
所有阈值端点组成有限集合，其上不存在额外权重跳跃。固定 g 后 \(w_t=w_ge^\Delta\)。对任意非负 Borel 权重 f，写 \(\Delta_\tau=\Delta_{\tau,g}\)、\(\Delta_h=\Delta_{h,g}\)，有准确换元恒等式
\[
 \int_\tau^h k_t(v)w_t(v)f(\Delta_{t,g}(v))\frac{dt}{t}
 =w_g(v)\int_{\Delta_h(v)}^{\Delta_\tau(v)}e^z f(z)dz.
\tag{AF4}
\]
若 \(k_t=0\) 导致 \(\Delta\) 平台，该段两侧通量均为零，不要求严格可逆。原 \(J_{far}\) 可能有禁块或空段，把它放大到 \([\tau,h]\) 仅用于正上界。AF4 是准确的原 FTC 扩展，未改变来源支持或负门。

对不交 Borel 壳 \(E_m\subset[0,\infty)\)，若 \(\sum_m1_{E_m}=1\)，则按非负 Tonelli
\[
 \sum_m w_g\int_{\Delta_h}^{\Delta_\tau}e^z1_{E_m}(z)dz
 =w_\tau-w_h.
\tag{AF5}
\]
所有壳只消费一次下降端点。N04 的真实映射是 \(H(t)=w_t(v)\ge0\)、下降增量 \(w_{t_i}-w_{t_{i+1}}\ge0\)、误差 0；有限壳望远镜合法。它不证明除以 \(e_g\) 并对来源/实际行积分后仍有统一有限预算。

AF4 对面积权重的方向十分明确。未加权高面积通量是
\[
 \int_\tau^h k_tw_t1_{\{\Delta\ge d\}}\frac{dt}{t}
 =w_g\big(e^{\Delta_\tau}-e^{\max(d,\Delta_h)}\big)_+.
\tag{AF6}
\]
没有 \(e^{-d}\) 因子；大的未来下降面积对应较大的原早期质量。对 \(a>1\)，则恰有
\[
 \int_\tau^h k_tw_te^{-a\Delta}1_{\{\Delta\ge d\}}\frac{dt}{t}
 =\frac{w_g}{a-1}
 \big(e^{-(a-1)\max(d,\Delta_h)}-e^{-(a-1)\Delta_\tau}\big)_+
 \le\frac{w_g}{a-1}e^{-(a-1)d}.
\tag{AF7}
\]
临界 \(a=1\) 时是 \(w_g(\Delta_\tau-\max(d,\Delta_h))_+\)；\(0\le a<1\) 时保留 \(e^{(1-a)\Delta_\tau}\) 增长。不能把平方根或一次反权重的临界情形误当作严格指数衰减。

## 3. 同一来源概率与真实外行的一次性加权预算

定义 \(\mathscr F_f(r)\) 为该完整行的原正来源/时间积分，额外乘 \(f(\Delta_{t,g}(v))\)，其他原门和 \(\rho\) 全部原样保留。用 \(\delta_t\le k_t(v)\) 对正项作上界：先对原坏来源 \(z'\) 积分，\(\Pi_t(D_g)\le1\) 消费的是第一份**同一**概率，不是来源坐标独立性。第二份保留 \(w_t/e_t\)，再仅用 \(e_t\ge e_g\)。因此
\[
 \mathscr F_f(r)
 \le\frac1{e_g}\int_{S_g}\nu(dv)
 \int_\tau^h k_tw_tf(\Delta)\frac{dt}{t}
 =\frac1{e_g}\int_{S_g}w_g(v)
 \int_{\Delta_h(v)}^{\Delta_\tau(v)}e^zf(z)dz\,\nu(dv).
\tag{AF8}
\]
这里原 \(S_g\subset Z_g\subset Z_t\) 是终端存活 good 支持；没有给未来删源补造同一资格。\(\Psi\)、FA、\(\rho\) 的删除只用于该正上界，任何负项均不变。

若预先给定
\[
 C_f=\int_0^\infty e^zf(z)dz<\infty,
\]
实际 good/high/FIRST 保持在同一 x 上，给
\[
 \int_{S_g}w_g\,d\nu\le\frac{Kq}{p},\qquad
 \frac{Kq}{pe_g}\le\frac12,
 \qquad \mathscr F_f(r)\le\frac{C_f}{2}.
\tag{AF9}
\]
这使用 FIRST 的共同测试容量只一次，不使用已付 RC 捕获容量。完整 \(dx\)、\(\beta-\nu\)、硬 z、唯一 j、种子、连续 s/L/R/g 选择器保持在原 \(d\mathcal T_I\) 中；不需要先固定块覆盖，因为 AF9 对每个实际行同常数成立。按 \(T_{small}\le4X\) 与原 signed 外系数 \(2\Lambda\)，
\[
 \boxed{2\Lambda P_{I;f}^{rem}\le4\Lambda C_fX.}
\tag{AF10}
\]
取 \(f(z)=e^{-az}1_{\{z\ge d\}}\)，\(C_f=e^{-(a-1)d}/(a-1)\)，得到候选 AF2。所有时间、来源对、实际选择器均在同一个外预算内；没有逐层重复 \(T_{small}\)，量纲为 X。此处使用原 RT1--2 未硬来源先积分的形式，不能在 \(4\Lambda\) 上再次乘 \(16/3\)；原硬来源费用已在 \(d\mathcal T_I\) 中。

AF10 确实证明了带衰减面积权重的完整原积分，但没有证明原正项自身含这个权重。若把 \(e^{-a\Delta}\) 从上界中删掉，AF2 不再成立。FA/good 只给 \(L_g<B_{FA}\delta e^\Delta\)，其方向相反；原 \(\rho=(1-F/(TA))_+\) 也没有已证的 \(\rho\le Ce^{-a\Delta}\) 比较。将此缺失比较设成一个未知来源矩的“预算”，不会解决它，本稿不这样做。

## 4. 真实终端 RC 余权的层通量与不足

不更换 \(\rho\)。在原 RC 的有效剩余域，
\[
 A=w_\tau-w_h=w_g(e^{\Delta_\tau}-e^{\Delta_h}),\qquad
 \rho A=(A-F_{rec}/T)_+.
\tag{AF11}
\]
\(\rho=\rho_r(v)\) 在完整行的时间积分中固定，并没有随 t 增加 \(e^{-a\Delta_{t,g}}\) 因子。保留它，准确高面积下降通量为
\[
 \int_\tau^h\rho k_tw_t1_{\{\Delta\ge d\}}\frac{dt}{t}
 =\rho w_g(e^{\Delta_\tau}-e^{\max(d,\Delta_h)})_+
 =(A-F_{rec}/T)_+\,
 \frac{(e^{\Delta_\tau}-e^{\max(d,\Delta_h)})_+}
 {e^{\Delta_\tau}-e^{\Delta_h}}.
\tag{AF12}
\]
当 A=0 时整式按零解释。这个精确比例在 \(d\le\Delta_h\) 时为 1，\(\Delta_\tau\) 很大且 d 固定时也接近 1。RC 本身不生成高面积尾的指数小因子；捕获容量 \(\int F_{rec}\nu\le D_{RC}q\) 已用于捕获项，不能将它复制给正余量 \((A-F_{rec}/T)_+\)。

AF12 是原终端 \(\rho\) 的准确 tradeoff，而非新的未付来源矩命名。它指出需要的具体连接：在当前实际核/门的剩余支持，必须再证明 \(F_{rec}\) 接近 TA 的定量覆盖，或证明真实来源配对因子在大 \(\Delta\) 上衰减。现有 \(F_{rec}<TA\) 仅给 \(\rho>0\)，方向不足。若要调用 AF10，一个充分的点态条件是对原来源对在 \(k_t(v)>0\) 上证明
\[
 \rho_r(v)\Psi\chi_{FA}\frac{\delta_t(v,z')}{k_t(v)}
 \le C e^{-a\Delta_{t,g}(v)},\qquad a>1,
\tag{AF13}
\]
其中 C 必须有实际外预算；本稿没有证明 AF13，也不把它作为新增假设纳入一般原交通。

## 5. 归一化势能为何留下实际误差

取一个保持 \(Z_t\) 不变的连续时间区间，定义
\[
 H(t)=\frac{\int_{S_g}\rho_r(v)w_t(v)\nu(dv)}{e_t}\in[0,1].
\]
其原始分子是下降势能，但归一化后几乎处处有
\[
 \int_{S_g}\rho k_t\,d\Pi_t
 =-\frac{dH}{d\log t}+H(t)\mathbb E_{\Pi_t}k_t.
\tag{AF14}
\]
右侧第二项非负；不能将 \(e_t\) 视为常数而丢掉它。来源删除导致 \(e_t\) 跳降时，终端存活分子连续，H 跳升；这些正跳变也须计入望远镜误差。它们至多按相应 \(\log(e_{t-}/e_{t+})\) 收费，而不是自动为零。连续误差在固定支持区间至多为 \(\log(e_{start}/e_{end})\)，若只用 \(k_t\le n\) 则给 n 乘时间长度的旧粗价。

因此 N04 的归一化映射虽然有统一下界 H≥0，却缺少误差总和的根阶外预算。\(e_\tau/e_g\) 的相对单调性不提供其输入无关上界；high 给 \(e_g\) 的行内下界，FIRST 不给整个 \(Z_\tau\) 的反向来源质量帽。AF14 的误差是原有归一化产生的明示项，不可仅以“熵下降”之名删去。

保留 \(\Psi\) 与原负项并不会自动消去 AF14 的误差：原正项带 \(\chi_{FA}\rho\)，原 \(N_{Z^c}\)、\(N_{del}\) 没有这些门，且 \(\Psi\) 是原来源对资格。没有一个已证明的共同可微势能将当前正门与原负门一并表示为 AF3 的下降。把正门移植到负项、使用已消费 \(N_Z\)，或将双来源配对替换为无门完整 signed 导数，均越出原账。本稿不做这些替换。

## 6. 收束结论与费用

成功：AF4--5 是原完整时间的精确通量剖面与一次性望远镜；AF11--12 保留真实 RC 终端余权；AF14 明确了归一化势能的实际误差。它们避免给每个面积壳重复领取端点通量或 \(T_{small}\)。

失败：未加权高 \(\Delta\) 没有由下降通量自动产生指数衰减；现有 RC/FA/\(\Psi\) 未证明提供 AF13 所需权重或共同 signed 势能。AF10 只是辅助的**人为加权**积分定理，不是原交通的实质付款，不计入一般目标进展。没有再构造抽象压力例。

原全部 \(dt/t\)、两份 \(\nu/e_t\)、硬 z、真实 \(dx\)、\(\beta-\nu\)、唯一 j、连续 soft/scale 选择器及 signed \(2\Lambda\) 在 AF8--10 的成功加权界中只按完整行预算使用一次；无输入无关 \(e_t\) 下界。未加权目标仍须支付 AF12 的真实余通量或 AF14 的归一化误差，并证明其和实际核/RC/history 的连接。已付捕获容量未复制，旧误差槽未返还，负项仍各在原母式一次。

最终：一般中间硬层及根阶目标仍 UNPROVED。本稿只交付恒等式、真实 \(\rho\) 的精确层比例、归一化误差以及缺失连接的明确位置；完成即停止。


<!-- SOURCE history_score_channel.md SHA256 e87e0e5d54f89863c729e6bbca2ccb37f761d0d6318e9cf880cc949af72f8529 -->
# R135 历史检索：接收 Lebesgue 加权的来源 score 方差

检索结论（限本次范围）：没有找到历史文档已经陈述并核验了如下准确形式的估计：对任意来源测度 ν、依接收点可测的删源集 Z_t(y)，先有 e_t(y) Var_{Π_t}(k) 被 ∫_{Z_t(y)}w_t(y,v)(k_t(y,v)−nθ)^2dν(v) 控制，再对真实接收 Lebesgue dy 积分而得到 Z_1^n ν-mass nθ(1−θ)。历史中有相邻但不同的结果：归一化来源 score 的独立双抽样界、score 时间漂移/删除记账，以及真实接收积分下的其他核方差估计。它们没有登记这一来源 score 的 e_tdy 加权通道。本结论是限定检索未命中，不声称全历史不存在。

## 搜索范围与可复核命中

只对 R128–R134 中和 receiver/source、score/variance、integrability、time audit 相关的 Markdown 文件作关键词检索，并追读命中行的必要上下文；重点文件如下：

- R128 joint_receiver_tail.md、joint_receiver_tail_proof_audit.md；
- R131 source_integrability.md、score_energy_history.md；
- R134 fa_time_audit.md。

检索词围绕 w_t、e_t、Π_t、Var/“方差”、score、dy/Lebesgue 接收积分、删源和 Z_1。R131 的 source_integrability.md 明确承接 RT1–6 与原真实 Lebesgue 接收积分（第5行）；下述是本次最相关的历史命中。

### 1. R131：归一化来源 score 的双样本界，不是所问的接收加权界

R131 source_integrability.md:110–121，式 SI9，定义同一 Πξ 下两个独立 score 的
Dξ = 1/2 E_{Πξ²}|k_t(v)−k_t(z′)|
= Σ_{r=0}^{n−1}F_r(1−F_r) ≤ n/4，
并给 Dξ≤√(Var_{Πξ}(k_t)/2)。随后明确任意原 ν 可使坐标相关，未证明 Var k_t=O(n)；high 门与 FIRST 也不能直接给无条件 Π_t 方差界（第121行）。这是归一化后的来源 score 比较基线；没有 e_t(y)dy，也没有任意删源指示函数或以 nθ 为中心的积分上界。

同文件 :12–17 定义 Πξ=e_t(y)⁻¹1_{Z_t}(v)w_t(y,v)ν(dv)，δ=[k_t(v)−k_t(z′)]_+，并说明固定层级的 ν、Z_t、w_t、e_t、Πξ、k_t 不依赖接收点 x 或硬来源 z；这仍不对 y 积分。:68–70 还明确 SI5 保留两份 ν 和 e_t⁻²，且联合对象尚需双门、score、RC、history 条件。

### 2. R131：时间 score 方差账仍是未闭合量

R131 score_energy_history.md:1–3 的有限搜索结论是：已审 Π 中心化漂移、连续正变差、删除跳、近时 εX 预算和存活子域端点式；没有定位到一般的“阈值穿越总收费 O(n)，故 ∫Var(k_t)dt/t≤O(n)+删除项”付款定理，且文件特别声明不声称全历史不存在。

同文件 :34–50 写出变测试函数所需的阈值穿越 C_j 与删除记账，并定义 E_j=∫Var_{Π_t}(k_t)dt/t；要得 O(n)+删除费，还须证明 C_j≤Cn 或等效联合收费。此为固定 (ω,V,j,y) 的时间积分账，不是把 e_t 乘回并对接收点 y 积分后的来源方差估计。

### 3. R128：保留双来源实际交通，没有提出该单来源方差松弛

R128 joint_receiver_tail.md:62–66 给 Π_t=e_t(y)⁻¹1_{Z_t}w_t(y,·)ν_V，并界定哪些对象在固定 (ω,V,j,y,t) 后可移出 x 积分；D_g、S_g、w_g、RC、FA/Ψ、尺度/软度和历史门仍保留。

R128 joint_receiver_tail.md:267 明确保留禁块删除、来源总质量及 e_t 变化在同一 Π_t 中，并指出没有作 ∫dx/e_t(x) 的非法抽取。R128 joint_receiver_tail_proof_audit.md:15 也记录 RT2 保留双来源 δ、FA、Z^c、RC 余权与 ν³/e_t²。两处均不是所问的、对单来源中心化平方误差以 e_tdy 加权并利用固定来源后 dy 乘积化简的界。

### 4. R134：FA 时间费用也不是来源 score 方差通道

R134 fa_time_audit.md:7–13 的 FT1–7 使用尺度变量上的恒等式 Δ=log(w_t/w_g)=∫_t^g k_u du/u、双独立抽样给 Eδ≤n/4，以及 FA 与实际时间支持；核查对象是 δ_t 与时间窗。该节没有以 e_tdy 积分来源 score 的中心化平方误差。

## 与待查命题的区别

待查式的关键权重与积分顺序是：先对每个 y 固定被删后的未归一化来源质量 e_t(y)=∫1_{Z_t(y)}w_t(y,v)dν(v)，使用中心化最小二乘比较；之后才对真实 Lebesgue dy 积分，并在每个固定 v 下利用 w_t 的坐标乘积核及阈值 score 的接收坐标分布。历史命中 SI9 则先归一化为 Π_t，讨论来源两份独立抽样；score_energy_history 讨论的是 dt/t 时间漂移；R128 保留实际双来源交通和门。三者的对象、权重和积分顺序都不同，故不能记为该准确估计的既有先例。

本文件只记录受限历史检索；没有在此复核或认证待查不等式本身。


<!-- SOURCE numeric_audit.md SHA256 4fe1f1b16425cf0b240739ed4b133e60248af406b19c701af3946438ad4993fe -->
# R135 数值独立审核

范围：先读 `source_channel.md` SC1/SC3，再审精确有限群代码/结果与真实核必要条件筛查；纳入 120 位回放和新增反向尺度测试。只写本文件，不修改作者文件，不重跑完整菜单，不操作 Git/PDF。

## 1. SC1/SC3 与有限三点平移群

SC1 使用真实一维 \(a(u)=\min(1,(b/c)C(|u|/b)/t)\)，\(z=\int a\)、\(\theta=z^{-1}\int a\chi\)，积分测度是来源中心的 Lebesgue \(dy\)，不是接收 \(dx\) 或原 \(\beta(dy)\)。SC3 是 \(\int e\mathbb E\delta\,dy\) 的伴随界。数值审核不为这些测度之间提供新连接。

`channel_numeric.py` 实现的是有限群 \((\mathbb Z/3\mathbb Z)^n\) 上的代数类比：单坐标权重 \(a(0)=1,a(1)=a(2)=1/2\)，活动指标在非零点为 1，故 \(z=2,\theta=1/2\)。三个来源是完全相关的对角原子 \((v,\ldots,v)\)，质量 \((v+1)/6\) 之和为 1。删源模式 all/correlated/sparse 均直接作用于相同有限群，并未以来源坐标独立替换后验。

代码的 `energy` 为 \(\sum_y e(y)\operatorname{Var}_{\Pi_y}k\)；`flux` 的分母是 e，准确等于 \(\sum_y e(y)\mathbb E_{\Pi_y^2}\delta\)，不是没有 e 的归一化后验流量。三个断言分别核对
\[
 \mathrm{energy}\le2^n n/4,\quad
 \mathrm{mass}\le2^n,\quad
 \mathrm{flux}^2\le4^n n/8.
\]
与 SC1/SC3 的有限群类比一致。JSON 保存 12 项（n=1,2,4,6，各三删源模式），全部精确 Fraction 通过。独立复算仅取 (2,all)、(4,correlated)、(6,sparse)，用不同的双来源配对公式
\[
 e\operatorname{Var}k=\frac1{2e}\sum_{i,j}q_iq_j(k_i-k_j)^2,
 \qquad e\mathbb E\delta=\frac1{2e}\sum_{i,j}q_iq_j|k_i-k_j|
\]
核 energy/flux/mass，三个样本均与 JSON 精确相等。

**结论 PASS，仅限有限群精确代数。** 它没有使用原 C，不能认证真实核共同实现、连续输入、FULL/history 或一般 SC 定理的数值证书。sparse 后验仅余一个原子，四个零方差/零流量行不是一般捕获证据。

## 2. 真实核代码、K 与 q 的含义

`real_joint_numeric.py` 的 \(\phi\) 使用 E3 指数积分表达，奇原函数使用 E4，边界值 E_k(0)=1/(k−1)。由 \(\phi\le1\)，C 的实现“原 \(\phi\) 区间质量 + hard overlap − overlap 内 \(\phi\) 质量”确实等于 \(\int\max(h_1,\phi)\)。所有 \(K_0,K_1,K_2,J,Q\)、p、\(w_\tau,w_h,w_g\) 在同一 x=0、同一 y、同一五原子相关 \(\nu\) 上求值，未把核比自由指定。

K=1,2,4 是预先给定菜单参数；直接核对 R116 `integration.md` 首段和 `astra_first.md` F13 均使用任意给定 K>0，没有误用 R125 的同名预算系数。D=1,2,4 是显式 RC 筛查参数；代码并未认证对应历史 \(\varepsilon_{RC}\) 预算。

q 在每行取 \(\max(\int K_0\nu,\int J\nu,\int Q\nu)\)。12 行实际最大项均为 \(Q_J=\int J\nu\)，所以 `FIRST_three=True` 是按 q 构造得到的**必要三项不等式**。它不是原停止机制、全 future test 合同或任意完整 FIRST 事件的认证。Z_g 取全部五原子只是协议模拟约定；没有构造真实存活规则或绝对连续 \(\nu\le f\,dv\)。

高门使用原 \(pe_g\ge2Kq\)。\(\gamma,g,c_j,L^+,H_0,\widehat H,T,\tau,h\) 的代码与协议一致，且 q、共同 \(\nu\) 没有在每个来源上重选。\(\alpha_{rec}=(Dq-\int U\nu)/Q_J\)、\(\kappa\)、M、\(\rho A\) 也按整行共同积分计算。

## 3. 关键分支判别与少数独立复核

原 RG16 仅为 \(\widehat H\ge L^+\)。JSON 的 `necessary_gates_pass` 同时要求 RG16 与其他筛查门，不能仅凭 high=True 叫作该分支合格。

|行|RG16|未截断诊断 RC 余量|是否提供 RG16 正尾证据|
|---|---|---|---|
|I1--I4、P1--P4、E1、E4|False（\(\widehat H<L^+\)）|10 行均正|否|
|E2、E3|True|均为 0|否|

报告的 qualified_RC/qualified_tail 为空正确。10 个正行的原 `good_tail_flux` 用 RG20 形式的 M 计算，但该字段在反向分支只是诊断；原代码的 qualified 值均置零，未将其冒作 RG20 的已适用上界。相应 `checks.RG17`/`checks.RG20` 在不适用分支是条件断言，`checks_passed` 不表示这些式子已对 12 行无条件认证。

少数独立复核采用 \(w\) 的原 t 积分，未调用 producer `calc`：

- \(\phi(1/2)=\int_0^1t(1-e^{-1/t})dt\approx0.39030803280223986316\)；
- 用该积分复算 I1/E2/E3 的 Hhat，差不超过约 \(9.1\cdot10^{-72}\)，Hhat−L⁺ 分别约 −0.103570946059、0.035498821186、0.0464633446112；
- I1/G4 的 C(0.5) 与 E2/G1 的 C(1.1) 以独立 t 积分复算，相对差分别在本次 70 位输出中为 0、约 \(1.43\cdot10^{-71}\)。

这些复核确认实现与关键分支，仍不是向外舍入区间证明。全部菜单 n≤128，也不满足原近 TOP 大维分支；strict-s 检查不能授予实际剩余 FULL 身份。

## 4. 80/100 位报告与便携 120 位回放

原报告为 12/12 `checks_passed`、异常 0。80/100 比较显式核对 eg/q/QJ/κ/M/α/high_ratio，最大相对差约 \(1.19\cdot10^{-78}\)，门和 good 符号一致。原比较未包含 \(\rho A\)、整行 residual/tail 或每个 atom 的全部核字段，不能把它概括成所有派生量均已作双精度核验。

`replay_real_joint.py` 跳过 producer main 的外部历史文件 SHA 依赖，直接在相同菜单调用 `calc(...,120)`，对已存 100 位结果核对 residual/tail 和全部 atom 的 rhoA/A/wg/K0/K1/K2/J，并检查 gates/good 一致。收据有 12 行，最大所存相对差约 \(4.71\cdot10^{-92}\)，补足上述派生量精度比对。静态检查中菜单及 JSON 行数均为 12，未发生 zip 截断遗漏。

回放复用了同一 producer 算法，是更高精度一致性验证；本审核另作的少数 t 积分复核具有独立表达。二者均不是区间证书、一般积分误差界或 FULL 证明。代码容差是浮点判据，特别 RG17/20 部分使用绝对尺度 `tol*max(1,...)`，不能把微小量上的通过称为严格相对符号认证。

## 5. 新反向尺度数值的静态审核

`reverse_scale_numeric.py` 复用未改的同 12 行菜单、120 dps，对 60 个 atom 各计算两条核比上界。令 \(m_H=\#\{|x_i-v_i|\le H/2\}\)，代码使用
\[
 B_H=(sb/H)^n\left(1+\frac{1-s}{s\phi(H/(2b))}\right)^{m_H},\qquad
 C_J=1+B_L+B_{L^+}.
\]
对 H≤b，硬窗外 \(P_{s,H}\) 与 J 的单坐标比至多 sb/H；硬窗内利用 \(\phi(|x_i-v_i|/b)\ge\phi(H/(2b))\)，得到代码中的附加因子。故检查对象确实是两个真实核比较，而非 RG16 的错误延用。

阈值为 \(6D\kappa q/(Q_JC_J)\)。由 good 的 \(J\ge3pwg/(KC_J)\) 和原 \(\alpha\ge2DKTq\kappa/(pQ_J)\)，该阈值正好给 \(\rho A\le[A-6D\kappa q\,wg/(Q_JC_J)]_+\)。此处数值只检查未再扣除 \(DK_0/T\) 项的弱版；不能据此声称后来保留该项的更强 RC 界也已由本菜单验证。脚本仅在原 E 资格上检查 RC 不等式；非 E atom 的 `passed` 主要表示核比较已通过，不能将其叫作额外正交通。

JSON 保存 12 行、60 atom，所有核比较与适用 RC 判据通过；60 个 atom 都在所测纯软尾，30 个 positive_RC atom 也全部如此。纯软尾条件 \(m_{L^+}=0,L\ge sb\) 蕴含两个 \(B_H\le1\)，故代码的 CJ≤3 检查方向正确。positive atom 的最大 CJ 为 1.0745918197774142903，未超过 1.075。

30 个正 atom 仍有正余量；存储的最大 residual_ratio 为
`0.99999999999999999999975806898701678`，可写“约 1”，不能写成精确取等证书。该检查支持新界在这份冻结菜单上的数值一致性，没有消除余量，也不认证反向尺度一般定理、实际 FULL 或根阶闭合。本审核只静态读其代码/JSON，未重复运行 60 atom 菜单。

## 6. 版本绑定与结论

真实核 JSON 中所记协议、producer、R133 核源、R134 RG 源与两份 R116 K 来源的 SHA，均与本次磁盘实际文件一致。以下是本次审核的主文件 SHA-256：

|文件|SHA-256|
|---|---|
|source_channel.md|4257331717b8ed7253549670b1ed208229ff87581b4ab74d84d49f5ce0ca1010|
|channel_numeric.py|34fcc558b3490cafe04c8fe9ddf8cd56f9456c87f766343f259ed914537d5b8d|
|channel_numeric.json|3f8c4cb1e183879706bdb3d44a9d43f22eb2137798ca1f5522b74599eda4419d|
|numeric_protocol.md|44325718b1bbcf57e867fec2ce2ed34ed9f6d1c93297585ce3ebb50acf92fc9f|
|real_joint_numeric.py|23117f5f271dbfef5b086a3d8f9f355730449f3d22799529105fc53883922220|
|real_joint_numeric.json|c541164cc6f489a21ad6f008935be97bbe077e9ddd290a3753bed5f0afdf94e9|
|replay_real_joint.py|64a4cb48788dae75d8c2d2f1343bd1637b2e43cb7a0384f03e4ed2552afb79be|
|replay_real_joint.json|d1ca8869eceff7b2608d4484fa09974369407151b233c4a5a4265020e4bbd89f|
|reverse_scale_numeric.py|cb64cb1652c3b7fadc8d8cdd676653d4e6926233e384e648194755e4adbc1bfe|
|reverse_scale_numeric.json|eb3ee6a51b00a9a19f30eb139b336806b810475a9bb57f4f73f203294d9415a1|

**审核结论 PASS，限于明确证据范围。** 有限群检验为精确代数；真实核菜单、120 位回放与反向尺度菜单为有限浮点一致性证据。关键判别“10 个正行全在反向分支”已独立确认，原 RG16 分支没有正尾样本；新增反向尺度比较能覆盖这些菜单点但余量仍正。未发现把这些结果合法提升为真实连续 FULL 或一般付款的证书，作者报告也保留相应限制。

无完整菜单重跑、无作者文件修改、无 Git/PDF。只交付本审核文件，完成停止。

## 7. 冻结后追加：RC 余量与真实 score 窗口分开核验

本节是前一审核冻结后的新增补核。追加前实际验证本文件前一版本 SHA-256 为
`81c8dede93d4ceb0b832ac101d67897503afc35ee2e88751ab6d6f9f94c36a9d`。
保留此散列为前一版本身份，不将新增 probe 冒作原审核已经完成的工作。

新增 `score_gate_probe.py/json` 在原同一冻结菜单保留 \(\rho\delta\)、good/bad 与相同 \(\Pi_t\)，但不实现 FA、\(\Psi\)、history、实际来源删源规则或接收积分。它在 \([\tau,h]\) 上计算必要离散模型，不认证原 \(I_{j,V,y}\) 限制下的实际交通。新增文件 SHA-256：

- `score_gate_probe.py`：`a2ed26df87aff041bc1758c9c23fa5867cd2b46f4c216525f097fd33b9c64742`；
- `score_gate_probe.json`：`9fad8b09e20630d8dadcd670799887030140bb776638d08ab80c186993ab4077`。

### 闭式独证

脚本利用的结构是：G4 为 bad，所有坐标同一阈值 \(\alpha_4\)；其余四个 atom 的每个阈值都严格小于 \(\tau\)。在 \(\tau\le t\le e:=\min(h,\alpha_4)\) 的非空窗口，G4 的权重为 1、score 为 0，其他 atom 的权重为 \(w_\tau(\tau/t)^n\)、score 为 n。定义
\[
 S=\sum_{v\ne G4}\nu(v)w_\tau(v)\tau^n>0,\quad
 R=\sum_{v\in good}\nu(v)\rho(v)w_\tau(v)\tau^n,\quad
 c=\nu(G4)>0.
\]
G4 本身 bad，不在 R 中；其他 bad 的 score 也为 n，和 good 的正 score 差为 0。因此仅 G4 能作为此窗口的正差坏端，真实同一概率的来源配对积分恰为
\[
 \iint_{good\times bad}\rho(v)\delta_t(v,z')\,d\Pi_t(v)d\Pi_t(z')
 =\frac{ncRt^{-n}}{(c+St^{-n})^2}.
\]
\(P(t)=c/(c+St^{-n})\) 满足
\[
 \frac{dP}{d\log t}=\frac{ncSt^{-n}}{(c+St^{-n})^2},
\]
故当 e>τ 时完整时间积分为
\[
 \boxed{\frac RS\left[\frac c{c+Se^{-n}}-\frac c{c+S\tau^{-n}}\right].}
\tag{NP1}
\]
此处 e 是窗口端点，\(e^{-n}\) 表示端点的 −n 次幂，不是自然指数。S/R 均具有“来源质量乘长度的 n 次方”的量纲，P 与最终 dt/t 积分无量纲，公式一致。端点阈值采用严格 score 定义只影响零时间测度；跨越 \(\alpha_4\) 后所有 score=n，\(\delta=0\)。若 \(\alpha_4\le\tau\)，整个时间窗正 score 交通为 0；若 R=0，也为 0。

### 静态与少样本复核

脚本按上述 S/R/c 计算，分支 e>τ 且存在正 rhoA 的 good atom 才给正值，逻辑与 NP1 一致。独立读取原真实核 JSON 的全部 12 行，核对 G4 身份与 bad、其余阈值<τ、G4 坐标阈值相等，并重新判定窗口分支，均与 probe JSON 相符。没有调用 producer 完整菜单。另仅取 I1，用直接 log-time 积分核验被积函数，其值约
`0.001380311182257410029075599688`，与所存闭式值相对差约 \(7.43\cdot10^{-71}\)。这是一项有限浮点复核，非区间证书。

补核准确区分如下：

|行|RC 诊断余量|带 rho/δ/good/bad/Π 的必要窗口积分|
|---|---|---|
|I1--I4、P1、P2、E1|正|正，共七行|
|P3、P4、E4|正|0：G4 阈值也低于 τ，所有 score=n|
|E2、E3|0|0：虽有非空 score 窗口，但 rhoA=0|

**追加结论 PASS，限此必要模型。** 先前“10 个 positive_RC 行全反向分支”仍然正确，但 RC>0 本身不意味着 \(\rho\delta\) 来源交通为正；本 probe 进一步将其中三行排为零 score。七个正必要窗口也不能叫作原正余交通非空：FA/\(\Psi\)/history、真实连续输入及原接收积分可能继续删去它们。没有赋予这些样本 FULL 身份，没有新增一般付款，负项仍原位。本次追加完成后再次冻结并停止。

## 8. 最后追加：硬计数因子的独立菜单范围

本节新增前，含第7节的审核版本 SHA-256 为
`462dd971661516fe50c75292434ec4fa8db3669a084d3e0a39308217e4cc194b`。
仍保留第7节所记最初冻结版本，不覆盖版本来源。

原反向尺度 60 atom 都为硬计数 m=0，没有测试 m>0 的附加因子。新增 `kernel_count_probe.py/json` 只针对该缺口：代码直接先列三阶段菜单、再按 120 dps 顺序计算 12 例；没有单独事前协议 SHA，不能追述为独立事前协议已经冻结或经过审核。脚本拒绝覆盖既有 JSON；本审核只作静态快检，未重跑或扩样。

范围为 n=1--64、s=0.01--1、H=0.5--1、b=1；包括 inside、mixed、闭硬边界 edge、距边界 \(10^{-30}\) 的 outside_edge，含 m>0 与 H<sb。公式正是第5节的
\[
 B_H=(s/H)^n\left(1+\frac{1-s}{s\phi(H/2)}\right)^m,
 \qquad m=\#\{|v_i|\le H/2\}.
\]
硬计数和实际 kernel 使用同一非严格闭盒边界；外侧偏移在 120 位精度下可分辨。所有样本 s>0，避免该表达在 s=0 的除法退化。H<sb 行仅检查核比较，没有错误调用纯软尾 CJ≤3 的额外条件。s=1、H=b=1 的比为 1 与同核身份一致。

JSON 为初探/边界压力/扩参各四例，12/12 浮点比值判据通过。它补足有限菜单对硬计数因子的覆盖，不认证一般核定理的严格误差、FULL、high/FIRST/RC、正 score 交通或外预算。最后新增文件 SHA-256：

- `kernel_count_probe.py`：`5ebddeae1a70452f796f778741a141d055c906bf29a41837e698561ae30f4066`；
- `kernel_count_probe.json`：`491288429a192e88525339c45a62f6d1f06ff834dc3d4d4ce61cb246e246ee5c`。

最终证据范围不变：精确有限群代数、有限真实核与硬计数浮点检查，以及缺 FA/\(\Psi\)/history/接收预算的必要 score 模型；没有一般付款或 FULL 认证。附加验证到此停止。
