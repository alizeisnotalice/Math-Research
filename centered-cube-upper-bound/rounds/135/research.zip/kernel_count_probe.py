"""Three-stage check of hard-count comparison, not original FULL traffic."""
from pathlib import Path
import importlib.util,json
p=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('r135',p/'real_joint_numeric.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
mp=m.mp;mp.mp.dps=120
menu=[('initial',1,'.25','.75','inside'),('initial',2,'.5','.75','mixed'),('initial',4,'.75','.5','inside'),('initial',4,'1','1','mixed'),('boundary',2,'.25','.5','edge'),('boundary',4,'.5','.75','edge'),('boundary',8,'.9','1','outside_edge'),('boundary',8,'.9','.5','mixed'),('expanded',16,'.01','.5','mixed'),('expanded',32,'.5','.75','mixed'),('expanded',32,'.99','.5','edge'),('expanded',64,'1','1','outside_edge')]
rows=[]
for stage,n,st,ht,pattern in menu:
 s,H=mp.mpf(st),mp.mpf(ht)
 v=([H/4]*n if pattern=='inside' else [H/2]*n if pattern=='edge' else [H/2+mp.mpf('1e-30')]*n if pattern=='outside_edge' else [H/4 if i%2==0 else mp.mpf(3) for i in range(n)])
 count=sum(abs(x)<=H/2 for x in v)
 B=(s/H)**n*(1+(1-s)/(s*m.phi(H/2)))**count
 ratio=m.kernel(s,H,v)/(m.kernel(mp.mpf(1),mp.mpf(1),v)*B)
 assert ratio<=1+mp.mpf('1e-65')
 rows.append(dict(stage=stage,n=n,s=st,H=ht,pattern=pattern,hard_count=count,bound=mp.nstr(B,50),ratio=mp.nstr(ratio,60),passed=True))
out=p/'kernel_count_probe.json'
if out.exists():raise RuntimeError('Refuse overwrite')
out.write_text(json.dumps(dict(precision=120,scope='Kernel comparison only, finite floating data, no FULL or interval certification',cases=rows),indent=2)+'\n')
print('12 hard-count kernel cases passed, including exact closed endpoints and s=1')
