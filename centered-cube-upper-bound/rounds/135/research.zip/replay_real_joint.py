"""Portable replay: install mpmath; keep the frozen producer and JSON beside this file.
Does not invoke producer main or overwrite its historical record.
"""
from pathlib import Path
import importlib.util,json
p=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('frozen_r135',p/'real_joint_numeric.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
data=json.loads((p/'real_joint_numeric.json').read_text())
records=[]
for menu,old in zip(m.MENU,data['cases']):
 new=m.calc(menu,120); mp=m.mp
 pairs=[('residual',new['statistics']['actual_RC_residual'],old['statistics']['actual_RC_residual']),('tail',new['statistics']['good_tail_flux'],old['statistics']['good_tail_flux'])]
 for a,b in zip(new['atoms'],old['atoms']):
  pairs.extend((a['name']+'_'+k,a[k],b[k]) for k in ('rhoA','A','wg','K0','K1','K2','J'))
 errors={k:mp.nstr(abs(a-mp.mpf(b))/max(abs(a),mp.mpf('1e-2000')),12) for k,a,b in pairs}
 assert all(mp.mpf(v)<mp.mpf('1e-65') for v in errors.values()),menu[1]
 assert new['gates']==old['gates']
 assert [a['good'] for a in new['atoms']]==[a['good'] for a in old['atoms']]
 records.append(dict(id=menu[1],max_relative_error=str(max(map(mp.mpf,errors.values()))),gates_match=True,positive_residual=new['statistics']['actual_RC_residual']>0,RG16=new['gates']['RG16']))
out=p/'replay_real_joint.json'
if out.exists():raise RuntimeError('Refuse overwrite')
out.write_text(json.dumps(dict(precision=120,compared_to=100,scope='Floating precision replay, not interval certification',cases=records),indent=2)+'\n')
print('12 rows replayed at 120 dps, including residual and atom kernel fields; gates match')
