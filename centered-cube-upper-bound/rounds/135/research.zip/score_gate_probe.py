"""Retain actual score on the frozen menu; no FA/Psi/history certification."""
from pathlib import Path
import importlib.util,json
p=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('r135',p/'real_joint_numeric.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
mp=m.mp;rows=[]
for menu in m.MENU:
 r=m.calc(menu,120);t=r['derived']['tau'];h=r['derived']['h'];n=r['n'];atoms=r['atoms'];g4=atoms[3]
 assert all(max(a['alpha_i'])<t for a in atoms if a['name']!='G4')
 assert all(x==g4['alpha_i'][0] for x in g4['alpha_i'])
 assert g4['bad']
 end=min(h,g4['alpha_i'][0]);good=[a for a in atoms if a['good'] and a['rhoA']>0]
 value=mp.mpf(0)
 if end>t and good:
  S=sum(a['nu']*a['wtau']*t**n for a in atoms if a['name']!='G4')
  R=sum(a['nu']*a['rho']*a['wtau']*t**n for a in good)
  c=g4['nu']
  # Before G4 threshold, all others k=n and G4 k=0.
  P=lambda u:c/(c+S*u**(-n))
  value=(R/S)*(P(end)-P(t))
  assert value>0
 rows.append(dict(id=menu[1],positive_RC=bool(good),score_window_positive=bool(end>t and good),tau=mp.nstr(t,40),end=mp.nstr(end,40),raw_rho_delta_integral=mp.nstr(value,70),scope='Retains rho, delta, good/bad, actual same Pi_t; omits FA/Psi/history and receiver integration'))
out=p/'score_gate_probe.json'
if out.exists():raise RuntimeError('Refuse overwrite')
out.write_text(json.dumps(dict(precision=120,cases=rows),indent=2)+'\n')
print('positive raw-score IDs:',[r['id'] for r in rows if r['score_window_positive']])
print('positive RC but zero score IDs:',[r['id'] for r in rows if r['positive_RC'] and not r['score_window_positive']])
