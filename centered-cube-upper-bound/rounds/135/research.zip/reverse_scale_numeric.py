"""Check newly proposed reverse-scale bound on the unchanged R135 menu."""
from pathlib import Path
import importlib.util,json
p=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('r135',p/'real_joint_numeric.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
mp=m.mp; rows=[]
for menu in m.MENU:
 r=m.calc(menu,120); par=r['parameters']; d=r['derived']; s=par['s']; b=par['b']; checks=[]
 for a in r['atoms']:
  bs=[]; ratios=[]; counts=[]
  for H,Kkey in ((par['L'],'K1'),(d['Lplus'],'K2')):
   count=sum(abs(z)<=H/2 for z in a['v']);counts.append(count)
   bound=(s*b/H)**r['n']*(1+(1-s)/(s*m.phi(H/(2*b))))**count
   ratio=a[Kkey]/(a['J']*bound)
   assert ratio<=1+mp.mpf('1e-65')
   bs.append(bound);ratios.append(mp.nstr(ratio,35))
  cj=1+sum(bs); threshold=6*par['D']*d['kappa']*d['q']/(d['QJ']*cj)
  rhs=max(a['A']-threshold*a['wg'],mp.mpf(0))
  if a['E']:
   assert a['rhoA']<=rhs*(1+mp.mpf('1e-65'))
  tail=counts[1]==0 and par['L']>=s*b
  if tail: assert cj<=3+mp.mpf('1e-65')
  checks.append(dict(name=a['name'],hard_counts=counts,kernel_bound_ratios=ratios,CJ=mp.nstr(cj,35),threshold=mp.nstr(threshold,35),good=a['good'],positive_RC=a['rhoA']>0,all_soft_tail=tail,residual_ratio=(mp.nstr(a['rhoA']/rhs,35) if rhs>0 else 'zero_rhs'),passed=True))
 rows.append(dict(id=menu[1],RG16=r['gates']['RG16'],atoms=checks))
out=p/'reverse_scale_numeric.json'
if out.exists():raise RuntimeError('Refuse overwrite')
out.write_text(json.dumps(dict(precision_dps=120,scope='Same frozen finite menu, floating numerical test of new bound only; not interval/FULL/global proof',rows=rows),indent=2)+'\n')
print('60 source atoms: kernel comparisons, applicable RC bounds and soft-tail costs passed')
