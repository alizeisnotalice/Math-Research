# R326 independent preauthor screen — redundant hard caps versus genuine joint-source information

Ownership: only /tmp/r326_audit.md. No Git or other-author edits. No new R326 author proof was read before this screen. Use R325's frozen original full-square cost b(z), same beta,f,q,alpha,U,J,A,E,R and fixed source-packet masses. The original negative square remains in b throughout.

## 1. Exact redundancy theorem in the authentic matched slot

Suppose nu<=beta<=f as MEASURES on the actual source space and, for each original accepted receiver x in its common full-measure set, f(Q_R(x)(x))<=4lambda R(x)^n. Every trial sigma in R325's feasible class0<=sigma<=beta (with the frozen packet masses and outside source fixed) then automatically satisfies

 sigma(Q_R(x)(x))<=beta(Q_R(x)(x))<=f(Q_R(x)(x))<=4lambda R(x)^n.

This is simultaneous over all trial sources: the full-measure set is supplied by the ORIGINAL full-f cap, and measure domination applies to every measurable cube. There is no trial-dependent exceptional set or need to recompute q. If original full f has an all-radius cap on the same E, the same conclusion holds for all those radii as well. Every nonnegative weighted integral or positive linear combination of these cap rows is likewise redundant. Adding them to the exact dominated-source feasible class cannot lower its exact supremum; it may only tighten a loose numerical bound, whose apparent improvement is not an actual smaller optimization class.

Similarly, if actual q=P_s,L*f, every positive response constraint P_s,L*sigma<=q follows already from sigma<=beta<=f. Original FIRST for beta remains frozen and unchanged; it is not an extra constraint on sigma. A hard winner for f need not be a winner for sigma, and equality q for f does not imply response equality for sigma. Neither condition may be falsely imposed as an inherited trial-source constraint.

For an abstract slot where beta has NOT been identified with a same-cap dominating source, actual nu's cap is not automatically inherited by every sigma<=beta. In that different class such caps may strengthen the relaxation, but the source identity and cap provenance must be stated. Do not transfer the matched conclusion to arbitrary beta merely from Wnu<=Wbeta.

## 2. Sharp test for a cap row when the dominating prior itself is not known capped

Let nu0 be the fixed source outside disjoint packets D, packet masses m_D, and sigma_D<=beta|D with sigma_D(D)=m_D. For a measurable set Q, the exact maximum possible trial mass in Q is

 nu0(Q)+sum_D min(m_D,beta(D intersect Q)).

Each packet achieves its summand by filling Q first with a fractional tie if needed; countably many disjoint packets sum without copying source mass. Thus a cap sigma(Q)<=C is redundant if and only if this displayed maximum<=C. Failure gives a genuinely smaller feasible class, provided actual nu still satisfies the cap. Under the authentic beta<=f cap the expression is<=beta(Q)<=C, so redundancy follows as a strict special case. More generally a positive kernel's maximum uses the same R325 bathtub formula with that kernel as cost.

This exact criterion avoids both errors: calling every actual-nu cap useful, or calling it redundant in an unmatched abstract source class. It retains packet masses and fixed outside source; no new independent source per receiver is allowed.

## 3. A genuine source-history mass refinement with quantified possible saving

If authenticated original source labels supply a frozen measurable partition D=disjoint union S_j and exact masses m_j=nu(S_j), keep these constraints for EVERY trial source. The exact refined optimum is

 Psi_D,strat=sum_j Psi_(beta|S_j),b(m_j)<=Psi_D,b(sum_j m_j).

This is a common source refinement across all y,r and clocks; it is not a separate optimizer for each row/scale. It changes no q,U,J or original cost. Strict improvement occurs whenever no aggregate optimum realizes the required stratum masses. A concrete quantitative sufficient condition is: on S, b>=b_hi; on D minus S, b<=b_lo<b_hi. The unconstrained optimum puts min(m,beta(S)) mass in S, while the actual constraint fixes m_S there. Then

 Psi_D-Psi_D,strat >=(b_hi-b_lo)[min(m,beta(S))-m_S].

The proof exchanges that excess S mass with the forced outside mass; the density caps remain satisfied. Such a refinement is useful only when the strata and their masses come from actual original source geometry/history, not from choosing favorable b labels and inventing their masses. Counting a source in overlapping histories without an original conservative allocation is invalid.

A second genuine refinement is an authenticated smaller source envelope nu<=w beta,0<=w<=1, with the SAME packet mass. Its exact cost uses capacities C_D^w(t)=integral_(D,b>t)w d beta and

 Psi_D^w(m)=integral_0^An min(m,C_D^w(t))dt.

The exact nonnegative reduction is integral[min(m,C_D(t))-min(m,C_D^w(t))]dt. It is not automatically positive or root-sized. If original nu is exactly beta restricted to a known set, then imposing that exact support and mass may even force sigma=nu; this recovers the actual cost, not a new upper estimate on it. Any claimed legacy residual/deletion envelope must first be verified from its actual source identity; no beta+nu<=f or source density premise is supplied here.

## 4. Genuine weighted original constraints and an explicit weak-dual certificate

An actual original weighted source inequality may be imposed if its original kernel/labels are FROZEN and actual nu satisfies it. Examples include a separately authenticated original e_g weighted cap or recorded source-stratum moment. Low-pe/high-m bounds must use their actual domain and original frozen source sets/weights; they cannot be asserted for arbitrary z or all future receivers without provenance. Relax strict inequalities to closed upper constraints for an upper relaxation. The optimizer still need not realize the full original history, which is acceptable for a proven upper relaxation but not an operator counterexample.

For a finite collection of actual constraints integral k_l d sigma<=c_l, take nonnegative multipliers theta_l and packet scalar levels t_D. Subtract fixed outside-source contributions from c_l first. Then the elementary source inequality gives the valid weak-dual upper certificate

 sum_D integral_D b d sigma
 <=sum_l theta_l c_l' +sum_D[m_D t_D
      +integral_D(b-sum_l theta_l k_l-t_D)_+d beta].

Subtract the unchanged sum_D m_D p_D for the R324 signed surplus. For finitely many packets this is direct; countable use requires the displayed integrals/series finite or an explicit tail bound as in R325. Levels t_D need not lie in[0,An] after kernel multipliers are subtracted. Finite LP feasible primal/dual zero gaps can certify their computed finite optimum; no unproved infinite strong-duality assertion is used.

To improve root order, an ACTUAL jointly valid family must produce a root-size right side after all source/outer weights, or a corresponding root-size bound on shared high-b capacities. Positive combinations of already redundant f-cap constraints cannot do this by shrinking the exact feasible set. A structural estimate on b itself using actual shared soft/hard kernels would be another route, distinct from adding constraints on sigma. FIRST and all original f constraints are already retained in those coefficients, so they cannot be counted as a second new source payment.

## 5. Actual local tool evidence and screen verdict

A fresh standard-library Fraction run checked324 inherited-cap comparisons on finite source allocations,16 exact indicator-capacity maxima, and2 strict-stratum-saving identities, total342 assertions PASS. The strict-saving allocation is a scalar capacity certificate, not an original cube/low-pe/history realization. No R325 run or broad counterexample search was repeated.

Initial verdict: the proposed actual hard-capture constraints are REDUNDANT in the authentic capped beta<=f slot. The exact maximum test above characterizes other abstract slots. Source-history stratum masses, tighter proved source envelopes or actual weighted source constraints can genuinely strengthen the extremal problem, with explicit quantified savings/weak certificates; none is assumed available or root-sized without original provenance and a new estimate. Await authors for bounded comparison, while all original global entry and unpriced core obligations remain intact.

## 6. Independent follow-up: exact minimal variance is a contiguous quantile-window problem

This screen precedes the new variance author proof. Fix ONE original row/scale capture function0<=A<=J on packet D, prior beta_D of finite mass B, and required hard-source mass0<m<=B. Let Q:(0,B)->[0,J] be its nondecreasing mass quantile (push beta_D forward by A). Then the UNNORMALIZED variance minimum is exactly

 V_min=min_{0<=s<=B-m}{integral_s^(s+m) Q(t)^2dt
             -[integral_s^(s+m)Q(t)dt]^2/m}.

Proof: for any feasible sigma<=beta_D of mass m, choose c=mean_sigma A. Minimizing integral(A-c)^2 d sigma for fixed c fills the nearest A-values first. That is an interval of A-values with full interior and fractional endpoint level sets; it can be represented by one contiguous quantile-mass window. Ties on either/both sides can be assigned proportional fractions of the original beta level set, and a window inside one atom is legitimate. The resulting window's variance is no larger than its quadratic cost about c, which is no larger than sigma's variance. Conversely every such mass window lifts to a feasible theta(A)beta_D with fractional boundary atoms. This proves equality without assuming any spatial contiguity or nonatomic A-values. Value gaps give jumps in Q but cause no lost mass.

The two window moments are continuous in s because Q,Q² are bounded; compactness of[0,B-m] gives an attained minimum. For m=B there is only the full window, m=0 is separately zero (no division), and J=0 is zero. This is UNNORMALIZED variance; the normalized Var is V_min/m, and the negative packet variance credit in R324 is V_min/J. None of these factors may be lost.

For a finite value menu, window moments are affine between start-position breakpoints s equal to a cumulative atom mass or that mass minus m. Its variance is concave there, so a minimum occurs among those endpoints. A fresh Fraction diagnostic compared that finite-window minimum to ALL feasible extreme-point source allocations for80 menus with3..5 values, repeated value atoms, gaps, unequal capacities and partial/full masses. All80 exact comparisons PASS. The finite-polytope variance is concave, so this is an exhaustive finite diagnostic; the continuous-input theorem is the analytic nearest-fill proof above.

This formula is a local quantitative certificate for actual variance, not a new feasible source constraint or a general source-root estimate. The SAME actual sigma must work for every(y,r); independently minimizing each local variance provides valid lower bounds, but the separate minimizing windows cannot be declared one common source optimizer. The packet mean/drift remains coupled to its variance. In particular maximal full-square cost and minimal variance are different optimizations, since the square cost also rewards a mean near J/2. Use the bound only inside the original exact formula or a proved upper certificate; do not exchange it for R325's common integrated-column extremum without justification.

Status: contiguous quantile-window formula PASS with these endpoint, normalization and common-source guards. Await author comparison; neither this local formula nor the earlier strata/dual contracts are counted as a new root payment.

## 7. Full author theorem comparison

Read /tmp/r326_aux.md in full after the independent screens above. PASS. Its initial hard-cap redundancy qualification matches §1: actual beta<=f plus SAME original full-f cap is required, and nu-only cap is insufficient for that conclusion. No new generic dual/strata reformulation is counted as root progress.

The author correctly centers the primary quadratic credit at J/2:

 R_D=[m(a-J/2)²-integral(A-J/2)²dnu]/J.

It therefore retains both source mean displacement and variance, rather than treating minimal free variance as the entire credit. The fixed-half nearest-fill layer-cake formula, lower-dual bound, inclusive atom fractions and m=0/full cases are correct. The free-center minimization and contiguous quantile-window formula agree with §6, with unnormalized variance and division by J preserved.

The crucial joint-source direction is correct: minimum of the shared-source SUM is>=the integral of independent row minima. Equality/one common set of independent minimizers is not asserted. d_D(z)=C-b(z) identifies this as a lower certificate for the SAME R325 exact optimum; it does not shrink its feasible set or license another square subtraction. C is finite because original integral rho is finite and the physical ell has finite mass. All source envelopes and row fields are original; no actual source density cap is assumed in the general theorem.

Finite capacity quadrature bounds use the decreasing clipped mass integrand; error<=m times maximum s mesh and the displayed divided-by-J row weighting are correct. A finite center grid needs its2mJh Lipschitz loss and cannot replace the fixed-half mean information.

For the actual1D fixture ONLY, each full-prefix capture branch has slope2/3 or-1 and prior density<=5, so the actual pushforward density is<=25/2, without atoms. The exact lower bound m³/(12L²)=1/120000 for m=1/4 is correct for every y in D. Full-prefix ell mass2/3, beta(D)=1/2, and1/J>=6/7 give integrated quadratic credit1/420000. That is credit ALREADY INSIDE the original square, and the uniform-reference mean term still remains. It is not a general dimension or root theorem.

## 8. Independent actual-pushforward numeric code audit (without replaying full run)

Read /tmp/r326_numeric.py completely and /tmp/r326_numeric.md completely. The physical A formulas and true source profiles are the frozen R324/R325 ones. The pushforward splits at z=y, divides prior densities by the actual nonzero affine slope, and aggregates a real flat-capture A atom for the first prefix. This atom is a pushforward of positive-volume L1 source, not an atomic original input. The quantile builder orders all interval/atom values and preserves both moments and mass.

For the free variance algorithm, rank-start cuts include each quantile knot and that knot minus m. Thus both window endpoints remain on fixed quantile polynomial pieces in each interval. Cumulative moment polynomials and their shifted difference are correct; the variance degree is at most4. Bernstein coefficients rigorously lower-bound the polynomial on each interval, while endpoint/midpoint rank starts produce genuinely feasible upper values. Clipping lower bounds at0 uses the proved nonnegative variance. Pruning a region whose lower bound exceeds a feasible best cannot lose the minimum when that best later decreases. The exact heap gap criterion and direct feasible-window verification therefore certify the reported brackets, without assuming the minimum is at sampled starts.

The fixed-half solver separately orders distances from J/2 to all pushforward intervals/atoms. Between events the accumulated continuous mass is affine in distance; atoms are filled only fractionally at the tied threshold. Its nearest-fill cost is exact for those rational profiles. The original selected R325 source masses and beta domination are checked; its mean/variance identity is compared to the SAME fixed-half objective. No pointwise bound from an unrelated source replaces the original square.

The separate anti-concentration lower bound uses the maximum mass of a sliding interval; a piecewise-constant plus atomic law attains that maximum at a support-breakpoint/atom aligned with one endpoint. The full-prefix density lower certificate is used only when the pushforward is atom-free. Both lower credits are valid independent lower bounds and may be maxed with the Bernstein lower bound; they are not added together.

The686 reported exact checks consist of456 preparation/global checks and72,76,82 refinement checks over18 fixed rows. The sole non-exact free minimum retains its rational bracket; descriptive decimals are not strict endpoints. Three fixed-half rows have nonpositive worst-debt certificates, while15 positive upper bounds stay unpaid. Rowwise minima cannot be claimed jointly attainable. This is actual1D kernel/source geometry but not original hard lower band/history/full core. Primary's fresh execution is its evidence; this reviewer did not rerun a script that writes another author's JSON.

Status before final integration: author theorem/numeric mechanism PASS at this bounded scope. The unresolved quantity is the original integrated mean-minus-forced-credit surplus or the sharper shared-source joint minimum, not merely computation of local variance. No general root payment or global entry has been proved.

## 9. Final author amendment: genuinely common-source positive-block occupancy

The final /tmp/r326_aux.md c1a5383c3dbe3b5b701d3ea70cc76518e6ab91239b23dca0d83498e900feca61 supersedes initial24a10b... above. Read the new(9a),(9b), actual twin construction and second reproduction code in full. PASS. For DISJOINT positive row/scale blocks T_i of actual measure w_i, a verified original quadratic kernel lower bound d_i1{z not in S_i} yields d_D(z)>=sum_i w_i d_i1{z not in S_i}. One shared sigma of mass m cannot put more than beta(intersection S_i) in the common zero region, giving the displayed min_i(w_i d_i)[m-beta(intersection S_i)]_+ lower credit. The finite membership-pattern capacities are actual beta masses; their nearest-cost fill and elementary lower dual are valid. Overlapping row blocks require an original nonnegative allocation with total weight<=1. No virtual row optimizer or source copy appears.

The twin fixture certificate is correct: source halves each have beta mass1/4; Y_L,Y_R have actual density5 and beta mass5/64 each, so their full-prefix row/scale measure is5/96. Piecewise-affine inequalities across the diagonal y=z can be proved by vertices of each triangular/rectangular piece; the code includes rectangle corners and diagonal endpoints. Minimum quoted ratios25/28 and50/53 exceed7/8; J>=1. Thus(A-J/2)²/J>=(3/8)²J>=9/64 on the stated two positive rectangles. The source-set intersection is null and the resulting shared lower credit is(5/96)(9/64)(1/4)=15/8192.

This is a real nonzero analytic credit for the documented actual1D profile. It is not claimed stronger than the sum of exact rowwise Lhalf minima; only the chosen coarse enlarged-set independent bounds vanish. The existing1/420000 and new15/8192 estimate OVERLAPPING original credit and are alternatives unless disjoint allocations are constructed; they must not be added or subtracted again from R325's exact square. The final author count is70=43 prior+27 new vertex/mass assertions; the old43-only count above describes the earlier version.

## 10. Independent screen and author comparison: priced source weak-L2 capacity target

Before reading /tmp/r326_core.md, independently verified its new conditional criterion. In the SAME matched source slot, x(z)=lambda J_z(b) has integral x d beta=X_rho by Tonelli. Because nu<=beta, integral x dnu<=X_rho. With h=(bcost-epsilon x)_+ and D=sup_{t>0}t² beta{h>t}/Wbeta, source domination and layer cake give

 Bnu<=epsilon X_rho+integral_0^An min(Wnu,beta{h>t})dt
 <=epsilon X_rho+2sqrt(D Wbeta Wnu).

The last integral bound follows by splitting min(Wnu,DWbeta/t²) at sqrt(DWbeta/Wnu), with zero-mass cases separate. Since h<=An, the only currently proved general bound is D<=An². A root bound requires the new quantitative source-tail improvement D<=C_epsilon n polylog²; it is not derived here.

Read /tmp/r326_core.md, SHA25662afc56597df0bf4456130f3f1a9caab4ea55af31e9307fe10197cb4c604374a, in full. PASS for its exact source-budget identity, finite-tail/binary tie endpoint formula and conditional outer factors. The finite discrete supremum uses >= at one-sided limits of strict high-level sets, correctly retaining atoms. Matched q remains fixed; no alpha restart or new common source is presumed. The theorem is a sufficient route, not claimed necessary for all possible root proofs.

The hard matched s=0,L=R,alpha=1 affinity calculation is also correct: A is a Gram kernel, affinity=A/sqrt(JyJz), and p-affinity²=A(Jz-A)/(JyJz)>=0. This recovers only A<=Jz, no new square payment. Source-row compression is the exact original weighted variance identity; its leftover covariance is already in E_full and cannot be counted twice. The core note honestly books no new paid contribution. Its1296+75 finite scalar checks are author/primary evidence, not reviewer replay or a proof of the missing weak-L2 geometry.

Status: final aux/core/numeric analytic mechanisms PASS at their exact scope; still awaiting corrected final combined-ledger text and hash binding. None changes R325's exact feasible optimum or pays the general core.

## 11. Final combined-ledger and evidence audit

Read the complete final checkpoint combined.md and compared it to final geometry.md(auxiliary theorem), core.md, numeric_notes.md and necessary numeric/geometry/tail code. PASS for the bounded integration. The full B_H/source-profile tools are ALTERNATIVE original-entrance certificates and are not combined with the already-decomposed Phi_next history line. The existing R325 absorption1/256 remains unchanged; this round adds no already-paid epsilon slot or general source-root receipt.

The new common-source row-block credit15/8192 and all-row conservative credit1/420000 estimate overlapping parts of the ORIGINAL quadratic cost; the final text explicitly forbids adding them and forbids subtracting either once again from R325's exact Psi. It does not claim the common-block certificate beats exact independent Lhalf minima. The three isolated nonpositive row certificates are not booked as positive-beta-row-measure traffic payment; the separate positive-block rectangles have their own analytic geometry proof.

The priced-source D_epsilon condition is properly sufficient and stronger than the desired single-input bound, not claimed necessary for every proof. The only proved general D bound remains A_n². Its source price lambda J_z(b), actual source order and original alpha are fixed. A new alpha=1 route must restart the authorized whole entrance and all its own fields; it cannot replace a negative square in current Phi_next. Same historical source-slot identities, M3 and all other original coefficients/independent obligations remain conditional on their authenticated original ranges.

Inspected primary_checks.log and numeric.json's reported scope/counts. Primary's fresh1062 exact counted checks=686 actual-row certificates+162 explicit interval-cube overlap checks+144 finite priced-tail inequalities+70 author certificates. The tail144 are finite source algebra, not a geometric tail estimate; geometry162 check the actual existing1D capture formulas, not a general dimension theorem. The numeric minimization stages use rational tolerance/brackets, not floating minima. Reviewer did not replay these full scripts. Reviewer's own342+80=422 bounded independent Fraction comparisons above are separate and NOT added to primary's1062. No prior-round tests or extensive history audit were repeated.

The main remaining estimate is the original integrated mean-minus-forced-credit surplus, its sharper joint shared-source quadratic minimum, or the actual priced-column weak-L2 tail. Computing local variances/certifying a low-dimensional credit is not that estimate. General Phi_next rejected triples, complete extreme ratios and wide low-pe terms, independent initial/deletion/future-deleted/suffix/history-entry/native/all-scale and outer-error obligations remain unproved. No claim that only constants/logarithms remain is certified.

## 12. Final frozen SHA256 bindings

- /Users/zhengzhihao/Desktop/T/output/centered_cube_round326_20261018_final_checkpoint/certificate_checks.py: c82ec9acd09fc02254eb322a8c44b2e91bf3efe5ab3b77904ce16288f66165b5

- /Users/zhengzhihao/Desktop/T/output/centered_cube_round326_20261018_final_checkpoint/combined.md: 2432647c382b6fb272abf8ba7f8bb72283cf19e1404cfba7596a297b9127f438

- /Users/zhengzhihao/Desktop/T/output/centered_cube_round326_20261018_final_checkpoint/core.md: 62afc56597df0bf4456130f3f1a9caab4ea55af31e9307fe10197cb4c604374a

- /Users/zhengzhihao/Desktop/T/output/centered_cube_round326_20261018_final_checkpoint/geometry.md: c1a5383c3dbe3b5b701d3ea70cc76518e6ab91239b23dca0d83498e900feca61

- /Users/zhengzhihao/Desktop/T/output/centered_cube_round326_20261018_final_checkpoint/geometry_checks.py: 8b819632cc8ff81ff63ae8e268a2ccfe972d3fe7f66b8c03d5216d9ad844385d

- /Users/zhengzhihao/Desktop/T/output/centered_cube_round326_20261018_final_checkpoint/numeric.json: 8c5493294b34994c5a1871119d53068561be6d11b78c478c77dd8cc0881d54c7

- /Users/zhengzhihao/Desktop/T/output/centered_cube_round326_20261018_final_checkpoint/numeric.py: 33d48effa269a93d823d1153c0f2b42fd3c3034eba6680dde863c651c4dd382e

- /Users/zhengzhihao/Desktop/T/output/centered_cube_round326_20261018_final_checkpoint/numeric_notes.md: c5b2d7d63941ae179034f9cbd2522ea4dc7e2927e6d18706af92effb3de625d4

- /Users/zhengzhihao/Desktop/T/output/centered_cube_round326_20261018_final_checkpoint/numeric_summary.json: c16f672951b66b2cbd146455c9f0e54b2b8e905a357fc3c956eb0d78f7925a10

- /Users/zhengzhihao/Desktop/T/output/centered_cube_round326_20261018_final_checkpoint/primary_checks.log: bde163f5cc0b0830bb8dbc5afdacbf032f3088b7dfa81a1007b4152487b10117

- /Users/zhengzhihao/Desktop/T/output/centered_cube_round326_20261018_final_checkpoint/requirements.txt: a699f46ed76bd216f1081b6b2330e4fb45d7c8c5a5354b208694d6590a5a8645

- /Users/zhengzhihao/Desktop/T/output/centered_cube_round326_20261018_final_checkpoint/tail_checks.py: feaab7a66074467a4ca6fa3ed573f4b7c54794edd9baafd9bc091a00430d1383


Final verdict: PASS for hard-cap redundancy under the exact matched contract, atom-correct quantile-window/fixed-half formulas, original source-once quadratic-credit certificates, actual numeric bracket algorithm and scoped integration. No general root payment or complete global absorption has been established. No later unread TeX/PDF is covered. Freeze these proof/integration bytes; changed mathematics or hash-bound text requires an explicit amended receipt.
