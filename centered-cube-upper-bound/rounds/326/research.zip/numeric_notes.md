# R326 actual pushforward variance and fixed-half capacity certificates

The standalone script executes in under one second locally and passes686 exact checks. It prepares18 fixed actual row problems once, then refines free-variance certificates at tolerances2^-16,2^-24,2^-32 (72,76,82 checks;456 preparation/global checks). It does not rerun R325's9,258 checks. Files are self-contained, with actual R324 source/profile helpers copied into the script; no old temporary script is imported.

## Fixed actual sources and rows

Use exactly the R325 frozen initial, reverse/narrow and twin beta profiles on D=[-1/2,-1/4], each beta(D)=1/2, and allocated massm=1/4. Select y=-49/100,-2/5,-13/50, at prefixR1 and the full prefixR3/2:3 profiles x3 actual rows x2 prefixes=18 problems. Original q=1, U,J,beta and all actual interval capture formulas are unchanged.

The actual A(z) formulas are

    prefix1: A=1/2-max(y,z), J=1/2-y;
    full:    A=1-max(y,z)+(2/3)min(y,z), J=1-y/3.

Beta is a genuine piecewise-constant L1 source. Its A-pushforward consists of exactly computed constant-density intervals and, for prefix1, an atom at A=J from the positive-volume source region z<=y. This pushforward atom is not an atomic original source. Source masses and first/second moments are checked against the exact quantile representation.

## Free-center variance minimum

For fixed row, minimize S=integral(A-mean_sigma A)^2 sigma over0<=sigma<=beta|D, sigma(D)=m. The justified quantile-window lemma follows by jointly minimizing over c and sigma: for fixedc, fill the m nearest A values to c, with fractions only at tied distance. A joint minimizer exists; its best c is its selected mean. Such a selected pushforward is a contiguous mass-quantile window, including partial endpoint atoms. Therefore

    S*=min_(0<=t<=B-m) [integral_t^(t+m) Q²
                           -(integral_t^(t+m) Q)²/m].

This is a value-quantile interval, NOT a claim that selected source locations form one physical interval. Tied A levels can be filled by a fraction of their original beta preimage.

The script constructs the exact piecewise-affine Q. Breakpoints are quantile knots and knots shifted by-m. On each rank-start interval, window moments are polynomial and variance is degree at most4. Exact Bernstein coefficient bounds give global lower bounds, while rational window starts give attainable upper bounds. A branch-and-bound refines only the unresolved rank intervals. Every reported upper bound is checked against direct quantile-window integration. No floating optimization or unverified continuum grid minimum is used.

At the finest tolerance,17 of18 minima are EXACT rational values, including four zero minima caused by sufficiently large prefix atoms. The only non-exact case is twin,y=-2/5,full:

    4521812159/118747255799808 <= S*
      <=18087252629/474989023199232,

approximately[.0000380792981576,.0000380793065641]. Its rational feasible upper window is stored; the gap is about8.41e-12. No exact minimum is claimed for this final case.

## Fixed-half nearest-fill cost: the stronger primary comparison

Also minimize Lhalf=integral(A-J/2)^2 sigma under the SAME source capacity. This keeps mean information rather than discarding it in a free-center variance. Its exact nearest-fill threshold is solved in distance space: between distances to pushforward interval endpoints/atoms, the included mass is affine in the radius. The required radius is rational; boundary atoms are filled fractionally. Exact mass/tie checks certify all18 minima.

For the original uniform-D reference a=E_uniform A, the worst per-row source debt obeys

    debt <= [m(a-J/2)^2-Lhalf]/J.

The script checks the actual R325 selected-source identity

    integral(A-J/2)^2 sigma
      =S_sigma+m(mean_sigma A-J/2)^2,

and compares its fixed-half cost with the attainable minimum. This is not an additional subtraction from R325's optimized full-square column: that column ALREADY includes the source variance and mean terms.

Meaningful actual examples:

|profile,row,prefix|free S*|fixed-half minimum|variance of R325 feasible source|worst fixed-half debt bound|
|---|---:|---:|---:|---:|
|initial,-2/5,R1|0|.041072916667|.000571354167|-1/13500|
|initial,-49/100,full|3457/27000000|.050306712963|.000956946953|+.003489955428|
|reverse,-49/100,R1|1/19200|.019652083333|.002069384446|+.016575683502|
|twin,-2/5,full|certified bracket above|.054942169053|.000188191732|+.008522228287|

In the first row, free variance can vanish, yet retaining the fixed half gives a strictly negative worst-debt bound for EVERY permitted source allocation. Initial and twin,y=-13/50,R1 are two further strictly negative bounds. The other15 rows have positive upper bounds and are NOT declared paid. Hence fixed-half source capacity gives additional real row information, but it does not close the remaining shared-source problem.

The compared R325 sources are the previously frozen mesh256 feasible allocations, represented as beta restricted to their actual intervals with the exact boundary fractions2/3 (initial) and4/5 (reverse), and the full right half in twin. Their masses are checked to remain exactly1/4 and their densities remain<=beta. Their source-only row variance often exceeds S*, showing that a source selected to maximize the SHARED column need not minimize every row variance.

## Conservative all-row credit on this actual profile class

Full-prefix A has two nonzero z slopes2/3 and-1, and the actual beta densities are<=5. Its pushforward has no atom and density at most(3/2+1)5=25/2. Thus the standard bounded-density extremizer inequality gives

    S*>=m³/[12(25/2)²]=1/120000.

Selected-row pushforward densities independently verify this cap. The argument applies to every actual y inD using the displayed slopes and profile cap. With full-prefix ell mass2/3, beta(D)=1/2, and J<=7/6, the integrated negative variance credit is at least1/420000 for ANY one shared feasible source. The scalar coefficient is checked exactly. The script also computes elementary anti-concentration credits h²[m-sup_c beta{|A-c|<=h}]_+ using exact interval/atom masses for four fixed h values; all are consistent with the global minimum certificates.

Rowwise minima can only LOWERBOUND the minimum of the SUM under one shared sigma. They are not simultaneously attainable by a single source unless a separate compatibility argument is supplied. In particular these positive credits do not improve R325's already exact feasible-optimum objective by double counting, nor force its positive supremal debt to disappear.

## Reproduction and scope

```
/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 /tmp/r326_numeric.py
```

It writes deterministic `/tmp/r326_numeric.json`. Fractions decide all brackets, signs, ties and allocations. Existing vendored mpmath is used only for descriptive decimals. These are18 fixed actual1D source-row diagnostics and a conservative profile-specific analytical credit. They do not certify the original hard lower band, complete history admissibility, joint source minimization equality or a general root estimate.
