from fractions import Fraction as F
import numeric as n
checks=0
for name in ['initial','reverse_narrow','twin']:
 beta=n.fixture(name)['beta']
 for y in [F(-49,100),F(-2,5),F(-13,50)]:
  cuts=sorted({v for a,b,d in beta for v in [a,b]}|{y})
  zs=cuts+[(a+b)/2 for a,b in zip(cuts,cuts[1:])]
  for full in [False,True]:
   for z in zs:
    formula=1-max(y,z)+F(2,3)*min(y,z) if full else F(1,2)-max(y,z)
    assert n.Aactual(y,z,full)==formula
    checks+=1
print({'explicit_cube_overlap_checks':checks,'status':'PASS','scope':'exact actual continuous-piece geometry; not general dimension test'})
