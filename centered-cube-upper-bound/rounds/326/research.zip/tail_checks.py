from fractions import Fraction as F
from itertools import product
count=0
for size in (3,7,15):
 B=[F(i+1,size*(size+1)//2) for i in range(size)]
 for eps in (F(0),F(1,16),F(1,4)):
  costs=[F((i*7+3)%17,5) for i in range(size)]
  occupancy=[F((i*11+2)%13,3) for i in range(size)]
  h=[max(F(0),b-eps*x) for b,x in zip(costs,occupancy)]
  D=max([F(0)]+[t*t*sum(B[i] for i in range(size) if h[i]>=t) for t in h])
  for j in range(1,17):
   m=F(j,16);rem=m;v=F(0)
   for i in sorted(range(size),key=lambda i:h[i],reverse=True):
    take=min(rem,B[i]);v+=take*h[i];rem-=take
   assert rem==0 and v*v<=4*D*m
   count+=1
print({'occupancy_shifted_weak_L2_checks':count,'status':'PASS','scope':'finite exact layer-cake algebra; not geometric tail estimate'})
