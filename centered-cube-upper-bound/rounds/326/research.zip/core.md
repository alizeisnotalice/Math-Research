# R326 — same-source receiver price and a precise remaining capacity estimate

## Bounded conclusion

No new general root budget is proved. Two plausible shortcuts were screened: reciprocal posterior affinity is already redundant in the exact hard shared-kernel case, and source-row compression only exposes part of the original negative square. Neither is booked as a payment.

There is a useful exact, budget-aware criterion for the next geometric test. It allocates the receiver budget to the SAME source through its actual original row occupancy, instead of testing raw high-cost columns alone. It retains fixed alpha and the entire original square. Its remaining parameter is a weak-L2 SOURCE capacity of columns after this legitimate receiver charge. The trivial estimate for that parameter is order A_n^2; the missing geometric estimate must reduce it to order n polylog(n+2). This criterion is a reduction and a test specification, not a solved geometric bound.

## 1. Fixed original full-square target

Use precisely the source-matched slot with nu<=beta<=f and q=P*f; the order must hold for the SAME beta defining the rows. Keep the original alpha, U, scales, q, E, all inclusive prefixes and terminal atoms. In particular

    U_y(u)=1_E(u)alpha(u,y)P_(s(u),L(u))(u-y)/q(u),
    J_y(r)=integral_(R(u)<=r) U_y(u)du,
    A_yz(r)=integral_(R(u)<=r) U_y(u)c_u(z)du,
    rho(u)=integral U_y(u)beta(dy)<=1_E(u),
    X_rho=lambda integral rho,
    ell_n=b^(-n)delta_b+n r^(-n-1)1_(a,b)dr,
    A_n=1+nlog(b/a),  a<=R,L<=b<=2a.

Set

    bcost(z)=integral beta(dy)ell_n(dr)1_(J_y(r)>=H)
                 A_yz(r)[1-A_yz(r)/J_y(r)],
    B_nu=integral bcost(z)nu(dz).

As proved in R325, 0<=bcost<=A_n. The negative square in this definition is never replaced. There is no new tag law, acceptance reduction, or reset of alpha. Assume the original finite-occupancy truncation X_rho<infinity; otherwise the desired receiver-budget statement is vacuous. Zero source mass gives a zero target.

## 2. Exact source allocation of the receiver budget

Define the price of source z by its OWN original row,

    x(z)=lambda J_z(b).

Tonelli and the SAME source order give the exact identity and inequality

    integral x(z)beta(dz)=lambda integral rho=X_rho,
    integral x(z)nu(dz)<=X_rho.                          (1)

The full terminal prefix b is essential. It includes every actual receiver, rather than rebuilding the high-J denominator or truncating J according to a column gate. No source density bound enters (1). The equality would fail if the beta used in the source domination were a different historical slot. The additional q=P*f relation is not needed for (1); it remains available, without change, for a future geometric capacity proof.

For epsilon>0 set

    h_epsilon(z)=[bcost(z)-epsilon lambda J_z(b)]_+,
    C_epsilon(t)=beta({z:h_epsilon(z)>t}),
    D_epsilon=sup_(t>0) t^2 C_epsilon(t)/W_beta.          (2)

Take D_epsilon=0 if W_beta=0. Since h_epsilon<=A_n,

    0<=D_epsilon<=A_n^2.                                (3)

Then the following source-once receipt is rigorous:

    B_nu <= epsilon X_rho
             + integral_0^(A_n) min{W_nu,C_epsilon(t)}dt
          <= epsilon X_rho
             +2 sqrt(D_epsilon W_beta W_nu).             (4)

**Proof.** Pointwise bcost<=epsilon x+h_epsilon. Integrate against nu and use (1). Layer cake and nu<=beta imply nu({h_epsilon>t})<=min(W_nu,C_epsilon(t)). By (2), this minimum is at most min(W_nu,D_epsilon W_beta/t^2). Integrate that last bound over (0,infinity), splitting at sqrt(D_epsilon W_beta/W_nu). The value is 2sqrt(D_epsilon W_beta W_nu). Zero mass or D=0 follows directly. This proves (4). All level-set atoms use the strict capacity definition; layer cake is unaffected, while a finite diagnostic must include the one-sided limits at cost ties. ∎

A genuinely geometric estimate

    D_epsilon <= C_epsilon^geom n log^(2A)(n+2)           (5)

would therefore give the requested type of bound, since

    2sqrt(D_epsilon W_beta W_nu)
      <=sqrt(C_epsilon^geom) sqrt(n)log^A(n+2)
                                     (W_beta+W_nu).

Equation (5) is NOT proved. It is stronger than the desired single-input first-moment bound and should not be called necessary for every possible proof. It is the precise remaining parameter for this particular capacity route. The unproved quantitative improvement is A_n^2 -> n polylog^2, rather than an omitted constant or logarithm.

Unlike a raw high-bcost capacity check, (2) discounts columns whose OWN actual row occupancy has already consumed receiver budget. This discount is globally affordable by (1). A source with J_z(b)=0 receives no discount; fixed alpha can produce such rows, and neither nu<=beta nor the shared q identity alone licenses replacing them by unmasked rows.

## 3. Why reciprocal affinity did not supply (5)

Screen the favorable genuine subclass in which the ORIGINAL fields themselves have alpha=1, s=0 and L=R. This is a subclass check, not an alteration of the current target. For each prefix r,

    U_y(u)=1_E(u)c_u(y)/(q(u)R(u)^n),
    A_yz(r)=integral_(R(u)<=r)
              1_E(u)c_u(y)c_u(z)/(q(u)R(u)^n)du.

Consequently A is a symmetric positive Gram kernel and A_yy=J_y. If J_y,J_z>0, the actual normalized receiver posteriors P_y=U_y/J_y and P_z=U_z/J_z have affinity

    G_yz=integral sqrt(dP_y dP_z)=A_yz/sqrt(J_y J_z).

Their capture probability is p_yz=A_yz/J_y. The proposed affinity certificate p_yz>=G_yz^2 becomes exactly

    p_yz-G_yz^2=A_yz(J_z-A_yz)/(J_y J_z)>=0.             (6)

Thus it is only the already known bound A_yz<=J_z. It does not add a new square gain even in the clean shared-q, self-capturing case. For general fields a posterior self-capture leakage term can be included, but that weakens a certificate which was already redundant in this favorable subclass. This is why no conditional affinity class is presented as progress here.

For general fixed alpha, source-row block compression has the similarly exact identity, at fixed z,r and for any block D with J_D=integral_D J_y beta(dy)>0,

    integral_D A_yz^2/J_y beta(dy)
       = A_Dz^2/J_D
          +integral_D J_y[p_yz-A_Dz/J_D]^2 beta(dy),
    A_Dz=integral_D A_yz beta(dy).                       (7)

The second term is already in E_full. Keeping only the first term weakens the original square; adding the second term again double-counts it. Without an independent geometric lower estimate for this actual covariance, (7) does not improve the budget. Rows with J_y=0 contribute zero. This observation is separate from the auxiliary agent's source-allocation variance optimization, which is not reproduced here.

## 4. A focused constructive next test

The next test for (5) should retain a single actual input f, the same dominating beta and fixed alpha, actual q=P*f, selected scales, high-J threshold, and all prefix atoms. Compute both the full-square column bcost(z) and the independently priced original row lambda J_z(b). Then examine the worst threshold of the priced source capacity (2), not just the maximum of bcost or an unweighted Lebesgue level volume.

For finite source cells with certified cost intervals and exact beta capacities, the threshold supremum is evaluated at one-sided limits of positive h_epsilon levels. In a truly piecewise constant profile with values h_i and cell masses beta_i,

    D_epsilon = max_(h_i>0)
                h_i^2 [sum_(j:h_j>=h_i) beta_j]/W_beta. (8)

With interval profiles, use upper h_i endpoints to get a conservative capacity bound; preserve the source mass of ties. Source quadrature and receiver/prefix approximation errors must be certified as in R325, rather than inferred from a plot. The critical diagnostic is whether high-cost columns with low own-row price actually retain large SAME-beta mass after the full capture square. Formula (8) is a test of that question, not evidence of (5).

If an alternative alpha=1 entrance is used, it must be a separate reconstruction of the original low-J/high-J bridge authorized by R302. Then recompute bcost, J, X_rho and (2) for that entrance. None of the old fixed-residual squares can be replaced during this operation. In that fresh setting the exact Gram calculation (6) shows that a proof still needs quantitative spatial source capacity, beyond posterior affinity.

At the old target multiplier 2 and recovery Lambda=128/119, (4) contributes 2Lambda epsilon L_out[X_rho] plus 4Lambda L_out[sqrt(D_epsilon W_beta W_nu)]. Only the authentic M3/source-conservation rules can aggregate these. The octave dependence remains inside A_n and hence inside the crude (3); no lambda d, aspect, history, or leaf multiplier is suppressed. This note books no new root-sized source receipt because (5) remains open.

## 5. Executed local exact checks

Two standard-library Fraction checks were actually run. They passed 1,296 exact instances of the redundancy identity (6), and 75 priced-tail certificates for dominated finite allocations. These are algebraic diagnostics, not realizations of original cube fields and not evidence for (5). Minimal reproduction follows.

```python
from fractions import Fraction as F
count=0
for iy in range(1,13):
    for iz in range(1,13):
        jy,jz=F(iy,4),F(iz,4)
        for k in range(9):
            a=min(jy,jz)*F(k,8)
            p=a/jy; g2=a*a/(jy*jz)
            assert p-g2==a*(jz-a)/(jy*jz)
            assert p>=g2
            count+=1
print('affinity checks',count)
profiles=[([F(1),F(3),F(2),F(0)],[F(2),F(0),F(1),F(4)]),
          ([F(1)]*4,[F(0)]*4),
          ([F(0),F(1,2),F(1),F(3,2)],[F(1)]*4)]
beta=[F(1,2),F(2,3),F(3,4),F(4,5)]; W=sum(beta); count=0
for costs,price in profiles:
    for eps in [F(0),F(1,10),F(1,2),F(1),F(2)]:
        h=[max(F(0),costs[i]-eps*price[i]) for i in range(4)]
        D=max([F(0)]+[t*t*sum(beta[i] for i in range(4)
                            if h[i]>=t)/W for t in h if t])
        for m in [F(0),W/5,W/2,4*W/5,W]:
            nu=[F(0)]*4; rem=m
            for i in sorted(range(4),key=lambda i:h[i],reverse=True):
                nu[i]=min(beta[i],rem); rem-=nu[i]
            tail=sum(nu[i]*h[i] for i in range(4))
            assert tail*tail<=4*D*W*m
            assert sum(nu[i]*costs[i] for i in range(4)) <= (
                eps*sum(beta[i]*price[i] for i in range(4))+tail)
            count+=1
print('priced-tail certificates',count)
```
