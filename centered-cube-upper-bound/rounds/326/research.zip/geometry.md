# R326 — a constructive source-profile quadratic credit, with mean retained

**Decision after screening.** On a certified matched receiver contract with `β≤f` and `f(Q_R(u))≤4λR(u)^n`, adding `σ(Q_R(u))≤4λR(u)^n` to `σ≤β` adds no constraint. A generic receiver-price dual would therefore give no improvement there. If only the original `ν` cap is known, the redundancy conclusion is conditional on the missing `β`-cap interface. Following the parent refinement, this note instead develops an explicit source anti-concentration certificate for the existing full-square cost.

This certificate does **not** reduce R325's exact feasible optimum. It is an analytic way to price a lower quadratic credit within that optimum. It retains distance of the source mean from capture probability `1/2` together with source variance. General root payment still requires a bound for the remaining certified surplus.

## 1. Keep the original square, source prior, and full row

Use the same actual fields as R324/R325: `ν≤β≤f`, fixed complete input/shared `q`, actual row `U_y`, full prefix `J=J_y(r)`, capture function `A(z)=A_yz(r)∈[0,J]`, and gate `J≥H>0`. The physical `ell_n` and its inclusive terminal atom stay unchanged. No endpoint restriction rebuilds `J`, no altered source is inserted into `q` or an old gate, and no source density bound is assumed.

Freeze one original source packet `D` with `m=ν(D)>0`, actual prior `β_D=β|D`, and `B=β(D)≥m`. At this row/scale set

\[
 a=|D|^{-1}\int_D A(z)dz,\quad
 \mu=m^{-1}\int_D A(z)\nu(dz),\quad
 V=m^{-1}\int_D(A-\mu)^2\nu(dz).
\]

The original packet cost and the R324 signed surplus satisfy EXACTLY

\[
 \int_D(A-A^2/J)\,d\nu
 =\frac{mJ}{4}-\frac1J\int_D(A-J/2)^2d\nu,               \tag{1}
\]
\[
 \boxed{\ R_D=
 \frac{m(a-J/2)^2-\int_D(A-J/2)^2d\nu}{J}.\ }            \tag{2}
\]

Indeed `∫(A−J/2)²dν=m(μ−J/2)²+mV`; expanding (2) recovers both negative terms `−m(μ−a)²/J−mV/J` in R324. Thus a free-center variance estimate alone is incomplete: a flat packet with `A=c≠J/2` has zero variance but a nonzero fixed-center quadratic cost.

## 2. Sharp fixed-half cost from actual source interval capacities

Let `η=A_#β_D` be the actual pushforward source measure on `[0,J]`. It may have atoms even though `β` is L¹: a flat capture region creates an atom. Define

\[
 L_{1/2}(\eta,m)=\min_{0\le\sigma\le\beta_D,\ \sigma(D)=m}
                       \int_D(A-J/2)^2d\sigma.
\]

Then

\[
 \boxed{\ L_{1/2}(\eta,m)=
 \int_0^{J^2/4}\left[m-
          \beta_D\{(A-J/2)^2\le s\}\right]_+ds.\ }       \tag{3}
\]

The minimizer fills the original prior's nearest-to-`J/2` capture values first: it is `β_D` on `{(A−J/2)²<t_*}`, zero on `{(A−J/2)²>t_*}`, and a proportion in `[0,1]` on the threshold level chosen to give total mass `m`. This is an explicit feasible source allocation. It follows directly by exchanging any occupied higher-cost mass with available lower-cost mass, or by the elementary lower certificate

\[
 \int w\,d\sigma\ge tm-\int_D(t-w)_+d\beta,
 \qquad w=(A-J/2)^2.
\]

The threshold allocation attains that bound. Layer cake gives (3). Fractional level sets cover all ties and flat atoms; no infinite-dimensional strong-duality theorem is invoked. `m=0` has zero cost; `m=B` takes the full prior.

Since the ACTUAL `ν|D` is feasible,

\[
 \int_D(A-J/2)^2d\nu\ge L_{1/2}(\eta,m),\qquad
 R_D\le\frac{m(a-J/2)^2-L_{1/2}(\eta,m)}J.               \tag{4}
\]

This is independent of the sign of the source mean shift. It is not an additional source fee or an extra subtraction from the original square; it is a certified lower estimate of credit already present in (2).

A convenient analytic lower certificate for any `h≥0` is

\[
 L_{1/2}\ge h^2
   [m-\beta_D\{|A-J/2|\le h\}]_+.                       \tag{5}
\]

The integrated form (3) is sharper than using one `h`. All capacities here are actual `β` SOURCE masses, never Lebesgue level volumes applied to an arbitrary source.

## 3. Sharp free variance as a secondary diagnostic

The exact smallest possible variance numerator under source domination is

\[
 S_*(\eta,m)=\min_{\sigma\le\beta_D,\ \sigma(D)=m}
      \left[\int A^2d\sigma-\frac{(\int A\,d\sigma)^2}{m}\right]
 =\min_{c\in[0,J]}\int_0^{J^2}
            [m-\beta_D\{(A-c)^2\le s\}]_+ds.             \tag{6}
\]

For fixed `c`, use the same nearest-value fill as in §2. The inner optimum is continuous in `c`, with Lipschitz constant at most `2mJ`, so the compact minimum exists. A jointly optimal center equals the mean of its chosen source measure; otherwise recentering would strictly reduce the cost. Hence (6) is the sharp variance minimum and `mV≥S_*`.

Equivalently let `Q:[0,B]→[0,J]` be the mass quantile of `η`. Then

\[
 S_* =\min_{0\le s\le B-m}
 \left[\int_s^{s+m}Q(t)^2dt
       -\frac1m\left(\int_s^{s+m}Q(t)dt\right)^2\right]. \tag{7}
\]

To justify the interval-window statement, an optimal nearest-center fill selects a central interval of A-values, with possible partial endpoint atoms. Its pushforward is a contiguous mass-quantile window, including the appropriate rank fractions of those atoms. Conversely every such window gives a feasible dominated source. This is a value/quantile interval, not necessarily a connected physical subset of `D`. The minimum exists since the bounded quantile's window moments are continuous in `s`.

Free variance never replaces fixed-half information: `S_*≤L_{1/2}`. For example a prior atom at `A=c≠J/2` gives `S_*=0` and `L_{1/2}=m(c−J/2)²`; this exactly cancels the corresponding mean term in (4), as it should.

## 4. All rows share one source; no independent-optimizer equality

For the original packet define its L² capture-profile cost

\[
 d_D(z)=\int\beta(dy)\ell_n(dr)1_{J_y(r)\ge H}
                     \frac{(A_{yz}(r)-J_y(r)/2)^2}{J_y(r)}.
                                                               \tag{8}
\]

The sharp joint dominated-source minimum is

\[
 L_D^{\rm joint}=
  \inf_{\sigma\le\beta_D,\ \sigma(D)=m}\int_D d_D(z)d\sigma(z).
\]

The SAME `σ` must serve all original rows and scales. Therefore

\[
 \boxed{\quad L_D^{\rm joint}\ge
 \int\beta(dy)\ell_n(dr)1_{J\ge H}
                  L_{1/2}(A_{yz\#}\beta_D,m)/J.\quad}    \tag{9}
\]

Equality is not asserted. Independent row minimizers can be incompatible; the inequality can be strict. All quantities are finite on the original finite-band row interface. In particular the positive row total `∫β ell1_{J≥H}J/4` is finite under its original finite envelope; no root estimate for that row total is inferred.

There is a constructive genuinely joint **lower certificate** which does not select a different source optimizer per row. Choose finitely many disjoint positive-measure row/scale blocks `T_i⊂{J≥H}`, of actual measure `w_i=∫_(T_i)β(dy)ell_n(dr)`, and source sets `S_i⊂D`. Suppose the ORIGINAL fields certify

\[
 (A_{yz}(r)-J_y(r)/2)^2/J_y(r)\ge d_i1_{z\notin S_i}
 \quad\text{on }T_i,\qquad d_i\ge0.                    \tag{9a}
\]

Then `d_D(z)≥k(z):=Σ_iw_id_i1_(z∉S_i)`. For every one shared feasible source `σ≤β_D` of mass `m`,

\[
 \int_Dd_D\,d\sigma\ge\int_Dk\,d\sigma
 \ge\min_i(w_id_i)\,[m-\beta(D\cap\bigcap_iS_i)]_+.      \tag{9b}
\]

Indeed outside `⋂S_i` at least one term of `k` is present, and the single source cannot place more than `β(⋂S_i)` mass in that intersection. A sharper finite certificate partitions `D` into its at most `2^k` membership patterns, with ACTUAL prior masses `B_I`, and minimizes `Σ_Ic_Ix_I` subject to `0≤x_I≤B_I,Σx_I=m`, where `c_I=Σ_(i violated)w_id_i`. Its exact elementary weak lower dual is

`t m−Σ_I B_I(t−c_I)_+`, for any real `t`;

nearest-cost fill attains its maximum. Thus this is a source-once weighted occupancy certificate built from verified positive row blocks and geometric intersections, not a renaming of `b`. Overlapping row blocks cannot be added unless a stated nonnegative allocation has total weight at most one. Finite alternative certificates may be maximized, but their credits cannot be summed across overlapping row allocations.

Indeed `b(z)=C-d_D(z)`, where `C=∫β ell1_{J≥H}J/4` is independent of `z`. Thus minimizing (8) over one shared source is exactly R325's full-square bathtub problem reflected about `C`. There is no smaller feasible optimum here. Equations (3), (5), (9) provide concrete analytic lower certificates for that existing optimum, using actual source variation instead of evaluating all full columns first.

Summing the certified packet credits gives the useful alternative R324 receipt

\[
 B_\nu\le\varepsilon X_\rho+
  \frac{C_2^2K}{2\varepsilon\lambda}W_\nu+
 \int\beta(dy)\ell_n(dr)1_{J\ge H}
     \sum_D\frac{m_D(a_D-J/2)^2-L_{1/2,D}}{J}.           \tag{10}
\]

It keeps the uniform-reference mean term AND the forced quadratic credit. The one reference payment uses the same mass-preserving `g≤2K`; it is not repeated for packets, interval thresholds, rows or scales. A root bound on the final displayed certified surplus remains a genuine missing geometric estimate. Same-source order alone does not prove it.

## 5. Finite certificates, atoms, and quantitative error

For a fixed actual row/packet set `F(s)=β_D{(A−J/2)²≤s}`. At knots `0=s₀<⋯<s_N=J²/4`, monotonicity gives explicit lower and upper certificates for (3):

\[
 \sum_i(s_{i+1}-s_i)[m-F(s_{i+1})]_+
 \le L_{1/2}\le
 \sum_i(s_{i+1}-s_i)[m-F(s_i)]_+ .                       \tag{11}
\]

Their gap is at most `m max_i(s_{i+1}−s_i)`, by telescoping the decreasing integrand. Source atoms at a threshold are handled by the inclusive CDF; single threshold values do not change the Lebesgue `ds` integral. Certified upper bounds on `F` give valid lower credits, with their exact bound errors retained. A uniform capacity error at most `e` changes the integral by at most `(J²/4)e`.

For (6), a finite center set within distance `h` of every `c∈[0,J]` gives a lower certificate `min_grid lower_inner−2mJh`; clip it below by zero. This is only a diagnostic for free variance. The mean information in (10) uses the fixed-half cost instead.

After division by `J` and original row/scale integration, numerical errors must be summed with their actual weights. For example (11)'s error is at most

`∫β ell1_{J≥H} Σ_D m_D max_i Δs_(D,y,r)/J`.

It is not automatically a source-root fee; dropping `J` or summing independent source copies would be invalid. For finite actual piecewise-affine profiles, interval masses and quantile-window moments can instead be evaluated exactly. No general source density bound or selector regularity is assumed in (3)–(11).

## 6. A quantitative credit on the existing actual one-dimensional fixtures

The frozen R324/R325 fixtures have `D=[−1/2,−1/4]`, `β=f|D`, `β(D)=1/2`, `ν=(1/2)β`, hence `m=1/4`. All three relevant profiles have actual prior density at most `5`. On the full physical prefix,

\[
 A_{yz}=1-\max(y,z)+(2/3)\min(y,z),\qquad J_y=1-y/3.
\]

For each actual `y∈D`, the z-slopes are `2/3` on `z<y` and `−1` on `z>y`. Thus the pushforward `A_#β_D` has no atom and density at most

\[
 L=5(3/2+1)=25/2.                                       \tag{12}
\]

This is a bound derived from the REAL prior profile and its capture map, not a cap assumed for arbitrary input. Any source allocation of mass `m` dominated by this prior satisfies, for every center,

\[
 \int(A-c)^2d\sigma\ge
 \int_0^{m/(2L)}2h(m-2Lh)dh
 =\frac{m^3}{12L^2}=\frac1{120000}.                     \tag{13}
\]

So both `L_{1/2}` and the free-variance minimum have this strictly positive lower bound for every full-prefix row. All these rows have `J≥H=3/4`, `J≤7/6`; their original ell weight is `2/3`, including the terminal contribution. Integrating the actual `β` row mass gives a rigorous negative quadratic credit of at least

\[
 \int_{\rm full\ prefix}\beta(dy)\ell_n(dr)
                  L_{1/2}/J
 \ge(2/3)(1/2)(6/7)/120000=1/420000.                    \tag{14}
\]

The mean term in (10) is still retained, so (14) does not certify nonpositive total surplus. These actual endpoint-kernel/positive-L¹ fixtures do not realize the original full lower hard band/history/core; their documented scope is unchanged. They demonstrate genuine quantitative quadratic credit, not a general dimension estimate.

There is also a direct positive-block instance of (9b) in the SAME twin profile. Its prior density is `1` on `D`, plus `4` on peaks `[-1/2,-15/32]` and `[-5/16,-9/32]`. The source halves `D_L=[-1/2,-3/8]`, `D_R=[-3/8,-1/4]` each have prior mass `m=1/4`. Take full-prefix row intervals

`Y_L=[-32/64,-31/64]`, `Y_R=[-20/64,-19/64]`.

Both have ACTUAL row density `5` and mass `5/64`; multiply by the full-prefix ell weight `2/3` to obtain `w_L=w_R=5/96`. Set `S_L=D_R`, `S_R=D_L`. On `Y_L×D_L` and `Y_R×D_R`, the exact actual formulas give `A/J≥7/8` and `J≥1`. Each assertion follows by checking the vertices of the two affine regions separated by `y=z`; minimum vertex ratios are respectively `25/28` and `50/53`. Hence (9a) holds with `d_L=d_R=9/64`. The intersection `S_L∩S_R` has zero prior mass, so the shared-source quadratic cost satisfies

\[
 L_D^{\rm joint}\ge(5/96)(9/64)(1/4)=15/8192.            \tag{15}
\]

This is a nonzero legitimate positive-row-block credit. The individual **coarse bounds from these chosen enlarged sets** give zero because `β(S_i)=m`; that does not mean the exact individual `L_{1/2}` minima vanish. Indeed the actual posterior is already above `1/2` throughout this fixture. No improvement over the sum of exact individual minima, nor necessity of the joint mechanism in this fixture, is claimed without a separate comparison. Equation (15) and (14) estimate overlapping original credit and are alternatives unless disjoint underlying allocations are supplied; they are not added as independent savings.

The independent numerical packet `/tmp/r326_numeric.py`, `.json`, `.md` is frozen with 686 exact certificate checks and fresh double-run PASS. It computes actual pushforward/quantile minima on selected original one-dimensional rows, including flat-atom cases, exact fixed-half nearest-fill costs, and rational enclosures of the non-polynomial free-variance minimum. These are separately scoped actual-row diagnostics, not a global root certificate. Python SHA256: `33d48effa269a93d823d1153c0f2b42fd3c3034eba6680dde863c651c4dd382e`; JSON: `8c5493294b34994c5a1871119d53068561be6d11b78c478c77dd8cc0881d54c7`; note: `c5b2d7d63941ae179034f9cbd2522ea4dc7e2927e6d18706af92effb3de625d4`.

## 7. Executed minimal exact checks

A local Fraction run passed 43 assertions: 12 nearest-fill/layer-cake identities, 12 feasible lower-dual equalities, 12 comparisons of fixed-half cost with sharp finite-prior variance, 4 joint-versus-independent-row inequalities, one strictly incompatible two-row example, and the two rational constants in (13),(14). The finite arrays are source-profile algebra diagnostics, not new original-kernel realizations; §6's actual map and derivative calculation supply its analytical certificate.

```python
from fractions import Fraction as F
from itertools import product
ct=dict(fill_layer=0,fill_dual=0,half_vs_variance=0,
        joint_lower=0,strict_joint=0,actual_constant=0)
profiles=[([F(0),F(1,3),F(2,3),F(1)],[F(1,4)]*4),
          ([F(1,2)]*2+[F(0),F(1)],[F(1,4)]*4),
          ([F(1,4)]*4,[F(1,8),F(1,4),F(3,8),F(1,4)])]
def fill(cost,B,m):
    out=F(0); rem=m
    for i in sorted(range(len(cost)),key=lambda i:cost[i]):
        x=min(rem,B[i]); out+=cost[i]*x; rem-=x
    assert rem==0
    return out
for A,B in profiles:
    for m in (F(1,4),F(1,2),F(3,4),F(1)):
        cost=[(a-F(1,2))**2 for a in A]; L=fill(cost,B,m)
        knots=sorted(set([F(0),F(1,4)]+cost))
        layer=sum((v-u)*max(F(0),m-sum(B[i] for i,c in enumerate(cost)
                  if c<=u)) for u,v in zip(knots,knots[1:]))
        assert L==layer; ct['fill_layer']+=1
        dual=max(m*t-sum(B[i]*max(F(0),t-cost[i]) for i in range(4))
                 for t in knots)
        assert L==dual; ct['fill_dual']+=1
        vertices=[]
        for free in range(4):
            rest=[i for i in range(4) if i!=free]
            for bits in product((0,1),repeat=3):
                x=[F(0)]*4
                for i,b in zip(rest,bits): x[i]=b*B[i]
                x[free]=m-sum(x)
                if 0<=x[free]<=B[free]: vertices.append(x)
        S=min(sum(x[i]*A[i]**2 for i in range(4))
              -sum(x[i]*A[i] for i in range(4))**2/m for x in vertices)
        assert 0<=S<=L; ct['half_vs_variance']+=1
A1=[F(1,2),F(1,2),F(0),F(1)]
A2=[F(0),F(1),F(1,2),F(1,2)]; B=[F(1,4)]*4
for m in (F(1,4),F(1,2),F(3,4),F(1)):
    c1=[(v-F(1,2))**2 for v in A1]
    c2=[(v-F(1,2))**2 for v in A2]
    joint=fill([a+b for a,b in zip(c1,c2)],B,m)
    assert joint>=fill(c1,B,m)+fill(c2,B,m); ct['joint_lower']+=1
    if m==F(1,2):
        assert joint==F(1,8)>0==fill(c1,B,m)+fill(c2,B,m)
        ct['strict_joint']+=1
m=F(1,4); L=F(25,2); S=m**3/(12*L**2)
assert S==F(1,120000); ct['actual_constant']+=1
assert F(2,3)*F(1,2)*S/F(7,6)==F(1,420000)
ct['actual_constant']+=1
print('PASS',ct,'total',sum(ct.values()))
```

The following independently executed actual-profile vertex/mass code passed **27 further exact assertions**, so the two embedded reproductions total **70**. Affinity on each side of `y=z`, rather than samples alone, proves the inequalities throughout the positive rectangles.

```python
from fractions import Fraction as F
from itertools import product
ct={'mass':0,'profile_vertices':0,'high_gate':0,'joint_constant':0}
D=(F(-1,2),F(-1,4)); mid=F(-3,8)
peaks=[(F(-1,2),F(-15,32)),(F(-5,16),F(-9,32))]
def length(I,K):
    return max(F(0),min(I[1],K[1])-max(I[0],K[0]))
def beta(I):
    return length(I,D)+4*sum(length(I,P) for P in peaks)
YL=(F(-32,64),F(-31,64)); YR=(F(-20,64),F(-19,64))
ZL=(D[0],mid); ZR=(mid,D[1])
for Z in (ZL,ZR):
    assert beta(Z)==F(1,4); ct['mass']+=1
for Y in (YL,YR):
    assert beta(Y)==F(5,64); ct['mass']+=1
mins=[]
for Y,Z in ((YL,ZL),(YR,ZR)):
    points=set(product(Y,Z))
    lo=max(Y[0],Z[0]); hi=min(Y[1],Z[1])
    if lo<=hi: points.update(((lo,lo),(hi,hi)))
    minratio=F(100)
    for y,z in points:
        J=1-y/3; A=1-max(y,z)+F(2,3)*min(y,z)
        assert 8*A-7*J>=0; ct['profile_vertices']+=1
        assert J>=1>F(3,4); ct['high_gate']+=1
        minratio=min(minratio,A/J)
    mins.append(str(minratio))
w=F(2,3)*F(5,64); credit=w*F(9,64)*F(1,4)
assert w==F(5,96) and credit==F(15,8192)
ct['joint_constant']+=1
print('PASS',ct,'total',sum(ct.values()),
      'minimum_vertex_ratios',mins,'credit',str(credit))
```

The stopping point is exact: this supplies constructively certified mean-plus-variance credit for the full-square problem, not a new feasible restriction or a general root bound. The remaining required estimate is the last signed sum in (10), or the sharper shared-source joint minimum in (9), under the original geometry. No generic hard-cap dual is counted as new progress.
