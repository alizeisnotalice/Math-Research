from fractions import Fraction as F
from itertools import product
ct=dict(fill_layer=0,fill_dual=0,half_vs_variance=0,
        joint_lower=0,strict_joint=0,actual_constant=0)
profiles=[([F(0),F(1,3),F(2,3),F(1)],[F(1,4)]*4),
          ([F(1,2)]*2+[F(0),F(1)],[F(1,4)]*4),
          ([F(1,4)]*4,[F(1,8),F(1,4),F(3,8),F(1,4)])]
def fill(cost,B,m):
    out=F(0); rem=m
    for i in sorted(range(len(cost)),key=lambda i:cost[i]):
        x=min(rem,B[i]); out+=cost[i]*x; rem-=x
    assert rem==0
    return out
for A,B in profiles:
    for m in (F(1,4),F(1,2),F(3,4),F(1)):
        cost=[(a-F(1,2))**2 for a in A]; L=fill(cost,B,m)
        knots=sorted(set([F(0),F(1,4)]+cost))
        layer=sum((v-u)*max(F(0),m-sum(B[i] for i,c in enumerate(cost)
                  if c<=u)) for u,v in zip(knots,knots[1:]))
        assert L==layer; ct['fill_layer']+=1
        dual=max(m*t-sum(B[i]*max(F(0),t-cost[i]) for i in range(4))
                 for t in knots)
        assert L==dual; ct['fill_dual']+=1
        vertices=[]
        for free in range(4):
            rest=[i for i in range(4) if i!=free]
            for bits in product((0,1),repeat=3):
                x=[F(0)]*4
                for i,b in zip(rest,bits): x[i]=b*B[i]
                x[free]=m-sum(x)
                if 0<=x[free]<=B[free]: vertices.append(x)
        S=min(sum(x[i]*A[i]**2 for i in range(4))
              -sum(x[i]*A[i] for i in range(4))**2/m for x in vertices)
        assert 0<=S<=L; ct['half_vs_variance']+=1
A1=[F(1,2),F(1,2),F(0),F(1)]
A2=[F(0),F(1),F(1,2),F(1,2)]; B=[F(1,4)]*4
for m in (F(1,4),F(1,2),F(3,4),F(1)):
    c1=[(v-F(1,2))**2 for v in A1]
    c2=[(v-F(1,2))**2 for v in A2]
    joint=fill([a+b for a,b in zip(c1,c2)],B,m)
    assert joint>=fill(c1,B,m)+fill(c2,B,m); ct['joint_lower']+=1
    if m==F(1,2):
        assert joint==F(1,8)>0==fill(c1,B,m)+fill(c2,B,m)
        ct['strict_joint']+=1
m=F(1,4); L=F(25,2); S=m**3/(12*L**2)
assert S==F(1,120000); ct['actual_constant']+=1
assert F(2,3)*F(1,2)*S/F(7,6)==F(1,420000)
ct['actual_constant']+=1
print('PASS',ct,'total',sum(ct.values()))


from fractions import Fraction as F
from itertools import product
ct={'mass':0,'profile_vertices':0,'high_gate':0,'joint_constant':0}
D=(F(-1,2),F(-1,4)); mid=F(-3,8)
peaks=[(F(-1,2),F(-15,32)),(F(-5,16),F(-9,32))]
def length(I,K):
    return max(F(0),min(I[1],K[1])-max(I[0],K[0]))
def beta(I):
    return length(I,D)+4*sum(length(I,P) for P in peaks)
YL=(F(-32,64),F(-31,64)); YR=(F(-20,64),F(-19,64))
ZL=(D[0],mid); ZR=(mid,D[1])
for Z in (ZL,ZR):
    assert beta(Z)==F(1,4); ct['mass']+=1
for Y in (YL,YR):
    assert beta(Y)==F(5,64); ct['mass']+=1
mins=[]
for Y,Z in ((YL,ZL),(YR,ZR)):
    points=set(product(Y,Z))
    lo=max(Y[0],Z[0]); hi=min(Y[1],Z[1])
    if lo<=hi: points.update(((lo,lo),(hi,hi)))
    minratio=F(100)
    for y,z in points:
        J=1-y/3; A=1-max(y,z)+F(2,3)*min(y,z)
        assert 8*A-7*J>=0; ct['profile_vertices']+=1
        assert J>=1>F(3,4); ct['high_gate']+=1
        minratio=min(minratio,A/J)
    mins.append(str(minratio))
w=F(2,3)*F(5,64); credit=w*F(9,64)*F(1,4)
assert w==F(5,96) and credit==F(15,8192)
ct['joint_constant']+=1
print('PASS',ct,'total',sum(ct.values()),
      'minimum_vertex_ratios',mins,'credit',str(credit))
