#!/usr/bin/env python3
"""R326 actual source-pushforward variance and fixed-half certificates. Self-contained copied R324 source helpers."""
from fractions import Fraction as F
from math import comb
from collections import Counter
from pathlib import Path
import json,sys
try:import mpmath as mp
except ImportError:
 sys.path.insert(0,'/Users/zhengzhihao/Desktop/T/output/hl_cube_paper_20261013/numerics/vendor');import mpmath as mp
counts=Counter()
def ck(k,b):
 counts[k]+=1
 assert b,k

def trim(p):
 p=list(p)
 while len(p)>1 and p[-1]==0:p.pop()
 return p

def add(a,b):return trim([(a[i] if i<len(a) else 0)+(b[i] if i<len(b) else 0) for i in range(max(len(a),len(b)))])
def scale(p,c):return trim([x*c for x in p])
def sub(a,b):return add(a,scale(b,-1))
def mul(a,b):
 out=[F(0)]*(len(a)+len(b)-1)
 for i,x in enumerate(a):
  for j,y in enumerate(b):out[i+j]+=x*y
 return trim(out)
def val(p,x):return sum((v*x**i for i,v in enumerate(p)),F(0))
def integ(p,l,h):return sum((v*(h**(i+1)-l**(i+1))/(i+1) for i,v in enumerate(p)),F(0))
def mass(profile):return sum(((h-l)*d for l,h,d in profile),F(0))
def imass(profile,l,h):return sum((max(F(0),min(h,b)-max(l,a))*d for a,b,d in profile),F(0))
def fprofile(local):return [(a+j*F(1,2),b+j*F(1,2),d) for j in range(-3,5) for a,b,d in local]
def overlap(*intervals):return max(F(0),min(i[1] for i in intervals)-max(i[0] for i in intervals))
def Aactual(y,z,full):
 out=overlap((F(-1),F(0)),(y-F(1,2),y+F(1,2)),(z-F(1,2),z+F(1,2)))
 if full:out+=F(2,3)*overlap((F(0),F(1)),(y-F(3,4),y+F(3,4)),(z-F(3,4),z+F(3,4)))
 return out

def fixture(name):
 D=(F(-1,2),F(-1,4))
 if name=='twin':
  d1=(F(-1,2),F(-7,16));d2=(F(-5,16),F(-1,4))
  knots=sorted({*D,*d1,*d2,(d1[0]+d1[1])/2,(d2[0]+d2[1])/2});beta=[];nu=[]
  for a,b in zip(knots,knots[1:]):
   mid=(a+b)/2;inpacket=any(l<mid<h for l,h in [d1,d2]);peak=any(l<mid<(l+h)/2 for l,h in [d1,d2]);density=F(5) if peak else F(1)
   beta.append((a,b,density))
   if inpacket:nu.append((a,b,density))
  packets=[d1,d2]
 else:
  width={'initial':F(1,8),'reverse_narrow':F(1,16),'wide':F(3,16)}[name];height=1+F(1,4)/width
  peak=(D[1]-width,D[1]) if name=='reverse_narrow' else (D[0],D[0]+width)
  knots=sorted({*D,*peak});beta=[(a,b,height if peak[0]<(a+b)/2<peak[1] else F(1)) for a,b in zip(knots,knots[1:])];nu=list(beta);packets=[D]
 return dict(name=name,beta=beta,nu=nu,f=fprofile(beta),packets=packets)
# Bivariate polynomial integration of A and A² over z, yielding y-polynomials.
def moments(profile,full,ymid):
 out=[]
 for power in [1,2]:
  poly=[F(0)]
  for lo,hi,density in profile:
   pieces=[(lo,hi,hi<=ymid)] if not lo<ymid<hi else [(lo,None,True),(None,hi,False)]
   for lower,upper,zless in pieces:
    # A=ay(y)+az*z on the relevant side of z=y.
    ay=([F(1),F(-1)] if zless else [F(1),F(2,3)]) if full else ([F(1,2),F(-1)] if zless else [F(1,2)])
    az=(F(2,3) if zless else F(-1)) if full else (F(0) if zless else F(-1))
    for j in range(power+1):
     yp=[F(1)]
     for _ in range(power-j):yp=mul(yp,ay)
     coeff=comb(power,j)*az**j*density/F(j+1)
     for bound,sign in [(upper,1),(lower,-1)]:
      term=([F(0)]*(j+1)+yp) if bound is None else scale(yp,bound**(j+1))
      poly=add(poly,scale(term,coeff*sign))
  out.append(poly)
 return out

def integrate_ratio(numer,J,lo,hi):
 q=[F(0)]*max(1,len(numer)-1);r=trim(numer)
 while len(r)>=len(J) and any(r):
  degree=len(r)-len(J);c=r[-1]/J[-1];q[degree]+=c;r=sub(r,[F(0)]*degree+scale(J,c))
 constant=integ(q,lo,hi);coef=r[0]/J[1] if r else F(0);arg=val(J,hi)/val(J,lo)
 return constant,{arg:coef} if coef else {}
def expr_add(a,b):
 c=a[0]+b[0];logs=dict(a[1])
 for arg,v in b[1].items():logs[arg]=logs.get(arg,F(0))+v
 return c,{a:c for a,c in logs.items() if c}
def expression(P,S,J,lo,hi):
 c,l=integrate_ratio(S,J,lo,hi);return integ(P,lo,hi)-c,{a:-v for a,v in l.items()}
def evaluate(e,dps):
 with mp.workdps(dps):
  cv=lambda x:mp.mpf(x.numerator)/x.denominator
  return cv(e[0])+sum((cv(c)*mp.log(cv(a)) for a,c in e[1].items()),mp.mpf(0))
def log_interval(x,terms=32):
 if x==1:return F(0),F(0)
 if x<1:
  lo,hi=log_interval(1/x,terms);return -hi,-lo
 t=(x-1)/(x+1);lo=2*sum((t**(2*j+1)/F(2*j+1) for j in range(terms)),F(0));rem=2*t**(2*terms+1)/((2*terms+1)*(1-t*t))
 return lo,lo+rem
def expression_interval(e):
 lo=hi=e[0]
 for arg,c in e[1].items():
  a,b=log_interval(arg)
  if c>=0:lo+=c*a;hi+=c*b
  else:lo+=c*b;hi+=c*a
 return lo,hi
def encoded(e):return dict(rational=str(e[0]),logs=[dict(argument=str(a),coefficient=str(c)) for a,c in sorted(e[1].items())])
def bernstein_coefficients(poly,lo,hi):
 degree=len(poly)-1;shift=[F(0)]*(degree+1)
 for i,v in enumerate(poly):
  for j in range(i+1):shift[j]+=v*comb(i,j)*lo**(i-j)*(hi-lo)**j
 b=[sum((shift[i]*F(comb(j,i),comb(degree,i)) for i in range(j+1)),F(0)) for j in range(degree+1)]
 return b
def bernstein_sign(poly,lo,hi):
 b=bernstein_coefficients(poly,lo,hi)
 return 'nonpositive' if max(b)<=0 else 'nonnegative' if min(b)>=0 else 'mixed'

import heapq

def distribution(profile,y,full):
 intervals=[];atoms={}
 for lo,hi,density in profile:
  cuts=sorted({lo,hi}|({y} if lo<y<hi else set()))
  for a,b in zip(cuts,cuts[1:]):
   less=(a+b)/2<y
   slope=(F(2,3) if less else F(-1)) if full else (F(0) if less else F(-1))
   intercept=(1-y if less else 1+F(2,3)*y) if full else (F(1,2)-y if less else F(1,2))
   if not slope:atoms[intercept]=atoms.get(intercept,F(0))+(b-a)*density
   else:
    aa=intercept+slope*a;bb=intercept+slope*b
    intervals.append((min(aa,bb),max(aa,bb),density/abs(slope)))
 knots=sorted({v for lo,hi,d in intervals for v in [lo,hi]}|set(atoms));pieces=[]
 for lo,hi in zip(knots,knots[1:]):
  density=sum((d for a,b,d in intervals if a<(lo+hi)/2<b),F(0))
  if density:pieces.append((lo,hi,density))
 return pieces,atoms

def dmom(dist,power):
 pieces,atoms=dist
 return sum((d*(hi**(power+1)-lo**(power+1))/(power+1) for lo,hi,d in pieces),F(0))+sum((m*x**power for x,m in atoms.items()),F(0))
def interval_mass(dist,c,r,closed=True):
 pieces,atoms=dist
 return sum((d*max(F(0),min(hi,c+r)-max(lo,c-r)) for lo,hi,d in pieces),F(0))+sum((m for x,m in atoms.items() if abs(x-c)<=r if closed or abs(x-c)<r),F(0))
def half_integral(dist,c,r,m):
 pieces,atoms=dist;selected=F(0);cost=F(0)
 for lo,hi,d in pieces:
  a=max(lo,c-r);b=min(hi,c+r)
  if a<b:selected+=d*(b-a);cost+=d*((b-c)**3-(a-c)**3)/3
 for x,weight in atoms.items():
  if abs(x-c)<r:selected+=weight;cost+=weight*(x-c)**2
 tie=m-selected
 ck('fixed_half_threshold_tie',0<=tie<=sum((weight for x,weight in atoms.items() if abs(x-c)==r),F(0)))
 return cost+tie*r*r

def fixed_center(dist,m,c):
 events=sorted({F(0)}|{abs(x-c) for lo,hi,d in dist[0] for x in [lo,hi]}|{abs(x-c) for x in dist[1]})
 for i,r in enumerate(events):
  before=interval_mass(dist,c,r,False);closed=interval_mass(dist,c,r,True)
  if before<=m<=closed:return half_integral(dist,c,r,m),r
  if closed<m and i+1<len(events):
   nxt=events[i+1];end=interval_mass(dist,c,nxt,False)
   if end>=m:
    slope=(end-closed)/(nxt-r);radius=r+(m-closed)/slope
    ck('fixed_half_linear_mass_solution',interval_mass(dist,c,radius)==m)
    return half_integral(dist,c,radius,m),radius
 raise AssertionError('no fixed center fill')

def quantile(dist):
 pieces,atoms=dist;points=sorted({x for lo,hi,d in pieces for x in [lo,hi]}|set(atoms));rank=F(0);Q=[]
 for i,x in enumerate(points):
  atom=atoms.get(x,F(0))
  if atom:Q.append((rank,rank+atom,[x]));rank+=atom
  if i+1<len(points):
   z=points[i+1];density=sum((d for lo,hi,d in pieces if lo<(x+z)/2<hi),F(0))
   if density:
    end=rank+density*(z-x);Q.append((rank,end,[x-rank/density,1/density]));rank=end
 return Q,rank

def primitive(p):return [F(0)]+[c/F(i+1) for i,c in enumerate(p)]
def shift(poly,a):
 out=[F(0)]*len(poly)
 for i,c in enumerate(poly):
  for j in range(i+1):out[j]+=c*comb(i,j)*a**(i-j)
 return trim(out)
def cumulative_poly(Q,power,t):
 past=F(0)
 for lo,hi,p in Q:
  pp=p if power==1 else mul(p,p);prim=primitive(pp)
  if lo<=t<=hi:return add(prim,[past-val(prim,lo)])
  past+=integ(pp,lo,hi)
 raise AssertionError('quantile outside')
def window_moment(Q,power,s,m):
 return sum((integ(p if power==1 else mul(p,p),max(lo,s),min(hi,s+m)) for lo,hi,p in Q if max(lo,s)<min(hi,s+m)),F(0))
def variance_pieces(Q,B,m):
 cuts=sorted({F(0),B-m}|{v for lo,hi,p in Q for v in [lo,hi,lo-m,hi-m] if 0<v<B-m});rows=[]
 for lo,hi in zip(cuts,cuts[1:]):
  mid=(lo+hi)/2;mom=[]
  for power in [1,2]:
   p=sub(shift(cumulative_poly(Q,power,mid+m),m),cumulative_poly(Q,power,mid));mom.append(p)
   ck('quantile_window_polynomial',val(p,mid)==window_moment(Q,power,mid,m))
  variance=sub(mom[1],scale(mul(mom[0],mom[0]),1/m))
  ck('feasible_window_nonnegative',val(variance,mid)>=0)
  rows.append((lo,hi,variance))
 return rows
class Minimum:
 def __init__(self,rows):
  self.heap=[];self.serial=0;self.best=None;self.start=None;self.splits=0
  for lo,hi,p in rows:self.add(lo,hi,p)
 def add(self,lo,hi,p):
  for x in [lo,(lo+hi)/2,hi]:
   v=val(p,x)
   if self.best is None or v<self.best:self.best=v;self.start=x
  lower=max(F(0),min(bernstein_coefficients(p,lo,hi)))
  ck('Bernstein_lower_below_feasible',lower<=self.best or lower<=min(val(p,lo),val(p,hi)))
  if lower<self.best:
   heapq.heappush(self.heap,(lower,self.serial,lo,hi,p));self.serial+=1
 def solve(self,tolerance):
  while self.heap and self.best-self.heap[0][0]>tolerance:
   lower,_,lo,hi,p=heapq.heappop(self.heap)
   if lower>=self.best:continue
   mid=(lo+hi)/2;self.add(lo,mid,p);self.add(mid,hi,p);self.splits+=1
   assert self.splits<5000
  lower=min(self.best,self.heap[0][0]) if self.heap else self.best
  ck('free_variance_minimum_bracket',0<=lower<=self.best and self.best-lower<=tolerance)
  return lower,self.best,self.start

def selected_profile(name,beta):
 if name=='initial':windows=[(F(-1,2),F(-504,1024),F(1)),(F(-504,1024),F(-503,1024),F(2,3)),(F(-209,512),F(-1,4),F(1))]
 elif name=='reverse_narrow':windows=[(F(-1,2),F(-215,512),F(1)),(F(-291,1024),F(-290,1024),F(4,5)),(F(-290,1024),F(-1,4),F(1))]
 else:windows=[(F(-3,8),F(-1,4),F(1))]
 out=[(max(a,l),min(b,h),d*t) for a,b,d in beta for l,h,t in windows if max(a,l)<min(b,h)]
 ck('R325_source_mass_preserved',mass(out)==F(1,4));ck('R325_source_capacity',all(0<=t<=1 for l,h,t in windows))
 return out

def anti_concentration(dist,m,J):
 points={x for lo,hi,d in dist[0] for x in [lo,hi]}|set(dist[1]);best=F(0);besth=F(0);supat=F(0)
 for h in [J/128,J/64,J/32,J/16]:
  centers={x+s*h for x in points for s in [-1,1]};sup=max(interval_mass(dist,c,h) for c in centers)
  credit=h*h*max(F(0),m-sup)
  if credit>best:best,besth,supat=credit,h,sup
 return best,besth,supat

def prepare(name,y,full):
 beta=fixture(name)['beta'];m=F(1,4);J=1-y/3 if full else F(1,2)-y;dist=distribution(beta,y,full);Q,B=quantile(dist)
 ck('actual_pushforward_mass',B==mass(beta)==F(1,2))
 ck('quantile_first_moment',sum((integ(p,lo,hi) for lo,hi,p in Q),F(0))==dmom(dist,1))
 ck('quantile_second_moment',sum((integ(mul(p,p),lo,hi) for lo,hi,p in Q),F(0))==dmom(dist,2))
 half,radius=fixed_center(dist,m,J/2);selected=distribution(selected_profile(name,beta),y,full);Sselected=dmom(selected,2)-dmom(selected,1)**2/m;Chalf=dmom(selected,2)-J*dmom(selected,1)+m*J**2/4
 ck('actual_source_half_free_identity',Chalf==Sselected+m*(dmom(selected,1)/m-J/2)**2)
 ck('fixed_half_no_more_than_R325_source',half<=Chalf)
 uniform=distribution([(F(-1,2),F(-1,4),F(4))],y,full);a=dmom(uniform,1);debtupper=(m*(a-J/2)**2-half)/J;actualdebt=(m*(a-J/2)**2-Chalf)/J
 ck('fixed_half_debt_bound',actualdebt<=debtupper)
 simple,h,sup=anti_concentration(dist,m,J)
 density=max(d for lo,hi,d in dist[0]) if dist[0] else F(0);densitycredit=m**3/(12*density*density) if full else F(0)
 if full:
  ck('full_pushforward_no_atom',not dist[1]);ck('full_density_bound',density<=F(25,2));ck('full_uniform_variance_credit',densitycredit>=F(1,120000))
 rows=variance_pieces(Q,B,m);minimum=Minimum(rows)
 return dict(name=name,y=y,full=full,J=J,m=m,dist=dist,Q=Q,minimum=minimum,fixed_half=half,half_radius=radius,R325_variance=Sselected,R325_half=Chalf,reference_half=m*(a-J/2)**2,fixed_half_debt_upper=debtupper,R325_actual_debt=actualdebt,anti_credit=simple,anti_h=h,anti_sup=sup,density_credit=densitycredit)
def pretty(x):
 with mp.workdps(40):return mp.nstr(mp.mpf(x.numerator)/x.denominator,18)
def main():
 problems=[prepare(name,y,full) for name in ['initial','reverse_narrow','twin'] for y in [F(-49,100),F(-2,5),F(-13,50)] for full in [False,True]]
 stages=[];summaries=[]
 for bits in [16,24,32]:
  before=sum(counts.values());rows=[]
  for p in problems:
   lo,hi,start=p['minimum'].solve(F(1,2**bits));lo=max(lo,p['anti_credit'],p['density_credit'])
   ck('source_variance_credits_consistent',lo<=hi and lo<=p['R325_variance'])
   ck('free_center_below_fixed_half',lo<=p['fixed_half'])
   attainable=window_moment(p['Q'],2,start,p['m'])-window_moment(p['Q'],1,start,p['m'])**2/p['m']
   ck('free_upper_attainable',hi==attainable)
   rows.append(dict(fixture=p['name'],y=str(p['y']),prefix='full' if p['full'] else 'R1',free_min_lower=str(lo),free_min_upper=str(hi),free_min_lower_decimal=pretty(lo),free_min_upper_decimal=pretty(hi),attainable_rank_start=str(start),fixed_half=str(p['fixed_half']),fixed_half_decimal=pretty(p['fixed_half']),fixed_half_radius=str(p['half_radius']),R325_source_variance=str(p['R325_variance']),R325_source_half=str(p['R325_half']),fixed_half_debt_upper=str(p['fixed_half_debt_upper']),fixed_half_debt_upper_decimal=pretty(p['fixed_half_debt_upper']),R325_actual_debt=str(p['R325_actual_debt']),anti_concentration_credit=str(p['anti_credit']),density_credit=str(p['density_credit']),atom_mass={str(a):str(w) for a,w in p['dist'][1].items()},subdivisions=p['minimum'].splits))
  summaries.append(dict(bits=bits,rows=rows));stages.append(dict(tolerance_bits=bits,rows=18,checks=sum(counts.values())-before))
 ck('uniform_integrated_credit',F(2,3)*F(1,2)*F(1,120000)/F(7,6)==F(1,420000))
 result=dict(status='PASS',check_counts=dict(counts),total_checks=sum(counts.values()),stages=stages,results=summaries,uniform_full_variance_numerator_lower='1/120000',uniform_integrated_variance_credit_lower='1/420000',scope='18 fixed actual R324 rows, original beta masses and R325 frozen feasible source retained. Quantile-window minimization is rowwise; these minima cannot be simultaneously attributed to one shared source. Credit is already inside R325 full-square objective and must not be subtracted again.')
 Path(__file__).with_suffix('.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
 print(json.dumps({k:result[k] for k in ['status','check_counts','total_checks','stages']},sort_keys=True))
if __name__=='__main__':main()
