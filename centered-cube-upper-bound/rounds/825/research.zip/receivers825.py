"""Integrate the true R814 owners and the continuous calibrated probe on each cube."""
import argparse
from fractions import Fraction as F
from itertools import product
import json
from math import prod
from zipfile import ZipFile


def cdf(x, interval):
    a, b = interval
    return min(F(1), max(F(0), (x-a)/(b-a)))


def section(parent, left, right, density):
    start, end = parent
    phase, width, period = (F(density[k]) for k in
                            ("bump_center_mod_period", "bump_half_width", "period"))
    support = tuple(map(F,density["support"]))
    low, high = max(start,support[0]), min(end,support[1])
    floor, peak = F(density["density_floor_one_axis"]), F(density["density_peak_one_axis"])
    cuts = {low,high}
    cuts.update(x for x in left+right if low<x<high)
    for k in range(low//period-2, end//period+2):
        for boundary in (k*period+phase-width,k*period+phase+width):
            if low<boundary<high:
                cuts.add(boundary)
    xs = sorted(cuts)
    total = plus = minus = F(0)
    for lo,hi in zip(xs,xs[1:]):
        mid=(lo+hi)/2
        rho=peak if abs(mid%period-phase)<width else floor
        total+=(hi-lo)*rho
        for direction in (1,-1):
            def values(x):
                u,w = cdf(x,left),cdf(x,right)
                return (1-u,w) if direction==1 else (u,1-w)
            a,b = values(lo)
            c,d = values(hi)
            m,n = values(mid)
            simpson=(hi-lo)*(a*b+4*m*n+c*d)/6
            # Direct integration of the product of two affine factors.
            explicit=(hi-lo)*(a*b+(a*(d-b)+b*(c-a))/2+(c-a)*(d-b)/3)
            assert explicit == simpson
            if direction==1:
                plus+=rho*simpson
            else:
                minus+=rho*simpson
    assert 0<=plus+minus<=total
    return total,plus/total,minus/total


def failures_at_most(ps, missing):
    law = [F(1)]
    for p in ps:
        nxt=[F(0)]*(len(law)+1)
        for j,w in enumerate(law):
            nxt[j]+=w*p
            nxt[j+1]+=w*(1-p)
        law=nxt
    assert sum(law)==1
    if not missing:
        assert law[0]==prod(ps)
    return sum(law[:missing+1])


def run(label,stage,lib):
    parents={p["id"]:p for p in stage["parents"]}
    n=stage["dimension"]
    choices=list(product((1,-1),repeat=n))
    roots=stage["roots_cross"]
    total=sum(F(row["root_mass"]) for row in roots)
    assert total==F(stage["benchmarks"]["cross"]["mother"])
    unsigned=[F(0),F(0)]
    directed={e:[F(0),F(0)] for e in choices}
    rowwise=F(0)
    gate=F(0)
    for row in roots:
        t,u,g=(parents[row[k]] for k in ("t","u","g"))
        wt=F(row["root_mass"])/total
        sec=[section(box_t,box_u,box_g,stage["density"]) for box_t,box_u,box_g in
             zip(lib["box"](t,"box"),lib["box"](u,"owner"),lib["box"](g,"owner"))]
        assert prod(x[0] for x in sec)==F(t["m"])
        if max(F(u["radius"]),F(g["radius"]))<=F(13,25)*F(t["radius"]):
            gate+=wt
        for h in (0,1):
            unsigned[h]+=wt*failures_at_most([x[1]+x[2] for x in sec],h)
        row_scores=[]
        for e in choices:
            ps=[axis[1] if sign==1 else axis[2] for sign,axis in zip(e,sec)]
            for h in (0,1):
                directed[e][h]+=wt*failures_at_most(ps,h)
            row_scores.append(prod(ps))
        assert sum(row_scores)==prod(x[1]+x[2] for x in sec)
        rowwise+=wt*max(row_scores)
    assert sum(x[0] for x in directed.values())==unsigned[0]
    for h in (0,1):
        best=max(choices,key=lambda e:directed[e][h])
        optimal=directed[best][h]
        print("TRUE_OWNERS",label,"allowed_failed_axes",h,"unsigned",float(unsigned[h]),
              "best_frozen_sign",best,"best",float(optimal),"exact",unsigned[h],optimal)
    print("CHECK_DIRECTION",label,"anticipating_per_parent",float(rowwise),
          "frozen",float(max(x[0] for x in directed.values())),
          "two_radii_le_13_25_original_fraction",float(gate),"exact",rowwise,gate)
    assert rowwise >= max(x[0] for x in directed.values())


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--archive", required=True)
    args=p.parse_args()
    with ZipFile(args.archive) as z:
        comb,lib={"__name__":"frozen_comb"},{"__name__":"frozen_trade"}
        for fname,ns in (("comb811.py",comb),("trade813.py",lib)):
            exec(compile(z.read(fname),fname,"exec"),ns)
        data=comb["fixture"](*comb["FIXTURES"][-1])
        run("original",data,lib)
        run("rebuilt",json.loads(z.read("comb814-rebuilt.json"))["stages"][0],lib)
    print("PASS true continuous probe and pair of actual owner measures")


if __name__=="__main__":
    main()
