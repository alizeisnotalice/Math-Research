#!/usr/bin/env python3
"""Exact reference-box integrals and Arb checks for R825 scalar budgets.

No high-dimensional box, original record, stopping history, or posterior is
constructed.  All huge-dimension comparisons are scalar and use logarithms.
"""
from fractions import Fraction
from itertools import combinations, product
from math import comb, factorial, prod

from flint import arb, ctx

F = Fraction
ZERO = F(0)
DIMENSIONS = (1, 2, 3, 4, 7)
WIDTHS = (F(1), F(3, 2), F(5, 7))
HIGH_DIMENSIONS = (10**64, 10**96, 10**160)
MID_DIMENSIONS = (96, 160)


def positive_power_cdf(point, shift, order):
    if point < shift:
        return ZERO
    if order == 0:
        return F(1)
    return (point - shift) ** order / factorial(order)


def convolution_cdf(width, distances):
    """Convolve atoms and differences of shifted step densities."""
    terms = {(ZERO, 0): F(1)}
    for distance in distances:
        atom = max(ZERO, width - distance) / width
        density_left = max(ZERO, distance - width)
        updated = {}
        for (shift, order), weight in terms.items():
            for new_shift, new_order, multiplier in (
                (shift, order, atom),
                (shift + density_left, order + 1, 1 / width),
                (shift + distance, order + 1, -1 / width),
            ):
                key = (new_shift, new_order)
                updated[key] = updated.get(key, ZERO) + weight * multiplier
        terms = {key: weight for key, weight in updated.items() if weight}

    def cdf(point):
        return sum(
            (weight * positive_power_cdf(point, shift, order)
             for (shift, order), weight in terms.items()),
            start=ZERO,
        )
    return cdf


def point_interval_distance(point, lo, hi):
    return max(ZERO, lo - point, point - hi)


def geometric_pieces(reference_center, endpoint, width):
    """Split the physical W coordinate at the two possible capture faces."""
    left, right = reference_center - width / 2, reference_center + width / 2
    cuts = {left, right}
    for face in (endpoint - width / 2, endpoint + width / 2):
        if left < face < right:
            cuts.add(face)
    cuts = sorted(cuts)
    pieces = []
    for lo, hi in zip(cuts, cuts[1:]):
        d0 = point_interval_distance(endpoint, lo - width / 2, lo + width / 2)
        d1 = point_interval_distance(endpoint, hi - width / 2, hi + width / 2)
        span = abs(d1 - d0)
        assert span in (ZERO, hi - lo)
        pieces.append((min(d0, d1), span, hi - lo))
    return pieces


def cut_cell_volume(residual, active_lengths):
    """Exact geometric simplex clipping in a single physical rectangle."""
    if residual < 0:
        return ZERO
    if not active_lengths:
        return F(1)
    if residual >= sum(active_lengths):
        return prod(active_lengths)
    order = len(active_lengths)
    answer = ZERO
    for count in range(order + 1):
        for chosen in combinations(active_lengths, count):
            height = residual - sum(chosen)
            if height > 0:
                answer += (-1) ** count * height ** order
    return answer / factorial(order)


def reference_box_volume(width, reference_center, endpoint, threshold):
    """Direct Fraction integral over the moving centers of actual boxes."""
    axis_pieces = [
        geometric_pieces(r, y, width) for r, y in zip(reference_center, endpoint)
    ]
    answer = ZERO
    for pieces in product(*axis_pieces):
        floors, spans, widths = zip(*pieces)
        static_volume = prod((length for span, length in zip(spans, widths) if span == 0),
                             start=F(1))
        active_lengths = [span for span in spans if span]
        answer += static_volume * cut_cell_volume(threshold - sum(floors), active_lengths)
    return answer


def test_reference_volumes():
    measurements = 0
    tail_checks = []
    for n in DIMENSIONS:
        for width in WIDTHS:
            templates = (
                (F(0), -F(1, 8), F(3, 8), -F(1), F(5, 4), -F(2), F(7, 16)),
                (-F(2), F(1), F(1, 9), -F(5, 4), F(0), F(1, 2), -F(7, 8)),
                (F(1), F(0), -F(1), F(1, 4), F(1), -F(1, 3), F(0)),
                (F(1, 7), -F(3, 7), F(5, 7), -F(1, 2), F(3, 5), -F(1), F(2)),
            )
            for template in templates:
                center = tuple(F(i - 2, 3) for i in range(n))
                shifts = tuple(width * value for value in template[:n])
                endpoint = tuple(r + shift for r, shift in zip(center, shifts))
                distances = tuple(map(abs, shifts))
                d = sum(distances)
                base = sum(max(ZERO, value - width) for value in distances)
                h = 1 + F(1, 32 * n)
                physical_width = width / h
                tail_threshold = d * min(F(1), d / (n * physical_width)) / 128
                thresholds = sorted({
                    -width, ZERO, width / 11, width / 2, width,
                    base, base + width / 5, d / 2, d, d + width, tail_threshold,
                })
                cdf = convolution_cdf(width, distances)
                results = []
                for threshold in thresholds:
                    exact_volume = reference_box_volume(width, center, endpoint, threshold)
                    expected = cdf(threshold)
                    assert exact_volume == width**n * expected
                    assert 0 <= expected <= 1
                    results.append(expected)
                    measurements += 1
                assert results == sorted(results)
                assert cdf(0) == prod(max(ZERO, 1 - value / width) for value in distances)
                assert cdf(d) == 1
                if d:
                    tail_checks.append((cdf(tail_threshold), d / (32 * physical_width)))
    print(f"Fraction reference geometry: {measurements} exact volume/CDF equalities.")
    return tail_checks


def minkowski_ratio(n, side, radius):
    return sum(
        (F(comb(n, j), factorial(j)) * (2 * radius / side)**j for j in range(n + 1)),
        start=ZERO,
    )


def minkowski_from_cells(side_lengths, radius):
    """Sum independently over which coordinates lie outside the box."""
    answer = ZERO
    n = len(side_lengths)
    for count in range(n + 1):
        for outside in combinations(range(n), count):
            outside = set(outside)
            face = prod((length for i, length in enumerate(side_lengths) if i not in outside),
                        start=F(1))
            answer += face * 2**count * radius**count / factorial(count)
    return answer


def test_minkowski():
    comparisons = []
    for n in DIMENSIONS:
        for side in WIDTHS:
            for radius in (ZERO, F(1, 19), side / 2, 3 * side):
                ratio = minkowski_ratio(n, side, radius)
                assert side**n * ratio == minkowski_from_cells((side,) * n, radius)
                assert minkowski_from_cells((2 * side,) * n, 2 * radius) == (2 * side)**n * ratio
                if radius == 0:
                    assert ratio == 1
                comparisons.append((ratio, F(n) * 2 * radius / side))
    print(f"Fraction Minkowski geometry: {len(comparisons)} exact cell-sum and scaling checks.")
    return comparisons


def ar(value):
    return arb(value.numerator) / value.denominator


def test_finite_arb(tails, minkowski, bits):
    ctx.prec = bits
    for probability, exponent in tails:
        assert ar(probability) <= (-ar(exponent)).exp()
    for ratio, squared in minkowski:
        if squared == 0:
            assert ratio == 1
        else:
            assert ar(ratio) < (2 * ar(squared).sqrt()).exp()
    print(f"Arb {bits} bits: {len(tails)} reference-tail inequalities and "
          f"{len(minkowski)} Minkowski bounds passed.")


def check_high_dimension(n, bits, expected_jump):
    ctx.prec = bits
    nn = arb(n)
    ell = arb(n + 2).log()
    jump = nn.sqrt() * ell**8
    d = jump**2 / (1024 * nn)
    assert (d - ell**16 / 1024).contains(0)
    assert (2 * (nn * d).sqrt() - jump / 16).contains(0)

    jump_gate = nn * (arb(3) / 2).log()
    if expected_jump:
        assert jump < jump_gate < nn * arb(2).log()
    else:
        assert jump > nn * arb(2).log() > jump_gate
        print(f"Arb {bits} bits n={n}: J/n={(jump / nn).str(12)}; "
              "mass jump fails, no high-dimensional budget asserted.")
        return

    size_log = 1 + (nn / jump).log()
    b_upper = jump / (1024 * size_log)
    b_lower = b_upper - 1  # b=floor(b_upper) lies between these exact real bounds.
    assert b_lower > 2
    assert b_upper * (1 + (1024 * nn / b_upper).log()) < jump / 512
    tau_log_interval = -b_upper.union(b_lower) / 64

    # Illustrative polynomial factor (n+2)^10.  The rank tail includes 1+n/P.
    poly_log = 10 * ell
    full_log_at_b = poly_log + (1 + nn / b_lower).log() - b_lower / 128
    near_log = poly_log - 15 * jump / 16
    closure_log = poly_log - b_lower / 8
    assert full_log_at_b < -b_lower / 256
    assert near_log < -jump / 2
    assert closure_log < -b_lower / 16
    assert near_log + b_upper / 64 < -jump / 2
    assert closure_log + b_upper / 64 < -b_lower / 16

    # P=b does not pay the reciprocal tau factor; P=4b does.
    exact_worst_tail_over_tau_log_lower = b_lower / 128
    stronger_log_over_tau = poly_log + (1 + nn / (4 * b_lower)).log() - b_lower / 64
    assert exact_worst_tail_over_tau_log_lower > 0
    assert stronger_log_over_tau < -b_lower / 128

    name = f"10^{len(str(n)) - 1}"
    print(
        f"Arb {bits} bits n={name}: J/n={(jump / nn).str(12)} "
        f"d={d.str(12)} b/J<={(b_upper / jump).str(12)} "
        f"log(tau) in {tau_log_interval.str(12)}"
    )
    print(
        f"  ln[n-polynomial rank tail at P=b]/b ≤ {(full_log_at_b / b_upper).str(12)}; "
        f"ln[near budget]/J ≤ {(near_log / jump).str(12)}; "
        f"ln[closure budget]/b ≤ {(closure_log / b_upper).str(12)}."
    )
    print("  Dividing by tau: near/closure survive; rank tail survives at P=4b, not at P=b.")


def oriented_length(center, half_width, anchor, sign):
    lo, hi = center - half_width, center + half_width
    if sign == 1:
        lo = max(lo, anchor)
    else:
        hi = min(hi, anchor)
    return max(ZERO, hi - lo)


def triple_slice_integral(width, anchor, rho_left, rho_right, sign_left, sign_right):
    # Integrate the actual intersected half-lines in physical coordinates.
    # The integrand is piecewise quadratic, so rational Simpson slices are exact.
    half_left = (1 + rho_left) * width / 2
    half_right = (1 + rho_right) * width / 2
    start, end = anchor - width / 2, anchor + width / 2
    cuts = {start, end}
    for half_width in (half_left, half_right):
        for transition in (anchor - half_width, anchor + half_width):
            if start < transition < end:
                cuts.add(transition)

    def slice_area(center):
        return (
            oriented_length(center, half_left, anchor, sign_left)
            * oriented_length(center, half_right, anchor, sign_right)
        )

    points = sorted(cuts)
    return sum(
        ((hi - lo) * (slice_area(lo) + 4 * slice_area((lo + hi) / 2) + slice_area(hi)) / 6
         for lo, hi in zip(points, points[1:])),
        start=ZERO,
    )


def test_triple_occupancy():
    rhos = (F(0), F(1, 2), F(13, 25), F(3, 4), F(1))
    sample_count = 0
    for width, anchor, left, right in product(WIDTHS, (F(0), F(4, 9)), rhos, rhos):
        product_width = (1 + left) * (1 + right)
        reverse_total = ZERO
        for sign_left, sign_right in product((-1, 1), repeat=2):
            volume = triple_slice_integral(width, anchor, left, right, sign_left, sign_right)
            assert volume / width**3 == product_width / 4 + F(sign_left * sign_right, 12)
            if sign_left != sign_right:
                reverse_total += volume
            sample_count += 1
        assert reverse_total / width**3 == product_width / 2 - F(1, 6)

    unordered_good = F(38, 25)**2 / 2 - F(1, 6)
    unordered_bad = F(38, 25)**2
    directed_good = F(11, 12)
    directed_bad = F(4)
    assert unordered_good == F(3707, 3750) < 1
    assert directed_good < 1
    gates = (
        ("unordered straddling", unordered_good, unordered_bad, F(1, 2000), F(1, 160)),
        ("fixed opposite signs", directed_good, directed_bad, F(1, 200), F(1, 24)),
    )
    print(f"Fraction triple receiving geometry: {sample_count} exact oriented slice integrals.")
    for bits in (256, 384):
        ctx.prec = bits
        for label, good, bad, fraction, exponent in gates:
            p = ar(fraction)
            entropy = -p * p.log() - (1 - p) * (1 - p).log()
            log_rate = ar(good).log() + entropy + p * ar(bad / good).log()
            assert log_rate < -ar(exponent)
            print(f"Arb {bits} bits {label}: log rate/n ≤ {log_rate.str(12)}, "
                  f"certified e^(-n/{exponent.denominator}).")
    print("A predetermined language of M sign branches costs at most M times "
          "the directed bound; the unordered straddling bound already sums its two signs per axis.")


def main():
    tails = test_reference_volumes()
    minkowski = test_minkowski()
    test_triple_occupancy()
    for bits in (256, 384):
        test_finite_arb(tails, minkowski, bits)
        for n in HIGH_DIMENSIONS:
            check_high_dimension(n, bits, expected_jump=True)
        for n in MID_DIMENSIONS:
            check_high_dimension(n, bits, expected_jump=False)
    print("PASS. Scalar and finite exact verification only; no high-dimensional original path.")


if __name__ == "__main__":
    main()
