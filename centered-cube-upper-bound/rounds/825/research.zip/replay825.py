"""Replay the R825 tests and the shared R814 receiver-price certificates."""
import argparse
import hashlib
from importlib.metadata import version
from pathlib import Path
import platform
import subprocess
import sys
from tempfile import TemporaryDirectory
from zipfile import ZipFile
import flint
from flint import arb, ctx

ROOT=Path(__file__).resolve().parent
INPUTS={"814":"891d8cbcbd35537e6abc18c938e53b1b4f300327357c24c8d14a51a46ad5e190",
        "823":"49fb22a6274856e4c8d39af4cfb80b10265467bebac89c3ef30a305131a71ebd"}


def rates():
    for precision in (256,384):
        ctx.prec=precision
        for power in (64,96,160):
            n=arb(10**power)
            ell=(n+2).log()
            jump=n.sqrt()*ell**8
            x=jump/(1024*(1+(n/jump).log()))
            assert x>1 and jump<n*arb(2).log()
            # Every tested bound is monotonically decreasing in b after bounding
            # the stated polynomial prefactors by (n+2)^10.
            for name,amount in (("far-all-scales",8),("priced-rows",1),
                                ("moving-pair",5),("parent-supply",4)):
                bound=10*ell/(x-1)-arb(amount)/64
                assert bound<0
                print("JOINT_RATE",precision,"n=10^"+str(power),name,"log/b <=",bound.str(14))


def main():
    p=argparse.ArgumentParser(description=__doc__)
    for k in INPUTS:
        p.add_argument("--r"+k,type=Path,required=True)
    args=p.parse_args()
    if not __debug__:
        raise RuntimeError("Enable assertions before running.")
    paths={k:getattr(args,"r"+k).resolve() for k in INPUTS}
    for k,filename in paths.items():
        assert hashlib.sha256(filename.read_bytes()).hexdigest()==INPUTS[k]
    print("Python",platform.python_version(),"python-flint",flint.__version__,
          "FLINT",flint.__FLINT_VERSION__,"NumPy",version("numpy"),"SciPy",version("scipy"),flush=True)
    print("R814",INPUTS["814"],"R823",INPUTS["823"],flush=True)
    with TemporaryDirectory(prefix="prices-",dir=ROOT) as folder, ZipFile(paths["823"]) as z:
        file=Path(folder)/"replay823.py"
        ns={"__name__":"pinned_prices","__file__":str(file)}
        exec(compile(z.read(file.name),file.name,"exec"),ns)
        ns["prices"](paths["814"])
    for name in ("reverse825.py","joint825.py","receivers825.py","geometry825.py"):
        print("\nRUN",name,flush=True)
        cmd=[sys.executable,"-E","-B",str(ROOT/name)]
        if name!="geometry825.py":
            cmd+=["--archive",str(paths["814"])]
        subprocess.run(cmd,cwd=ROOT,check=True)
    rates()
    print("PASS complete round 825 exact replay")


if __name__=="__main__":
    main()
