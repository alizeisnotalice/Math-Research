"""Exact stationary (omega,r) reverse posterior and two-step predictions.

The R814 real weighted record omega=(t,u,g,z-cell,q-cell) is augmented by
r~mu|A_t/m_t. Actual source cells allow all tested membership events. Original
right/left joint is never replaced by the product of its marginals. Resampling
r is a Gibbs move and preserves the augmented stationary law. The n=4 fixture
has no positive sample in the original high-dimensional long-jump gate.
"""

from collections import defaultdict
from fractions import Fraction as F
from functools import lru_cache
from itertools import product
import argparse, json, zipfile


def test(label, stage):
    parents = {p["id"]: p for p in stage["parents"]}
    cells = {c["mask"]: F(c["mass"]) for c in stage["cells"]}
    records = []
    for root in stage["roots_cross"]:
        for z, q in product(root["z_masks"], root["q_masks"]):
            records.append(
                (
                    root["t"],
                    root["u"],
                    root["g"],
                    z,
                    q,
                    F(root["coefficient"]) * cells[z] * cells[q],
                )
            )
    M = sum((r[-1] for r in records), F(0))
    assert len(records) == 230 and M == F(stage["benchmarks"]["cross"]["mother"])
    ts = sorted({r[0] for r in records})
    mt = {t: F(parents[t]["m"]) for t in ts}
    assert all(
        mt[t] == sum((m for r, m in cells.items() if r & parents[t]["bit"]), F(0))
        for t in ts
    )
    prior = [(*r[:-1], r[-1] / M) for r in records]
    rdist = {
        r: sum((e[-1] / mt[e[0]] for e in prior if r & parents[e[0]]["bit"]), F(0))
        for r in cells
    }
    rdist = {r: v for r, v in rdist.items() if v}
    assert sum((cells[r] * v for r, v in rdist.items()), F(0)) == 1
    post = {}
    for r, gamma in rdist.items():
        post[r] = [
            (*e[:-1], e[-1] / mt[e[0]] / gamma)
            for e in prior
            if r & parents[e[0]]["bit"]
        ]
        assert sum((e[-1] for e in post[r]), F(0)) == 1
    distribution_r_given_t = {
        t: {r: cells[r] / mt[t] for r in rdist if r & parents[t]["bit"]} for t in ts
    }
    assert all(sum(v.values(), F(0)) == 1 for v in distribution_r_given_t.values())

    @lru_cache(maxsize=None)
    def overlap(a, b):
        bits = parents[a]["bit"] | parents[b]["bit"]
        return sum((mass for mask, mass in cells.items() if mask & bits == bits), F(0))

    Tprob = {
        r: {t: sum((e[-1] for e in post[r] if e[0] == t), F(0)) for t in ts}
        for r in rdist
    }
    new_labels = {}
    for r, es in post.items():
        for tp in ts:
            by_u, by_g = defaultdict(F), defaultdict(F)
            for e in es:
                if e[0] == tp:
                    by_u[e[1]] += e[-1]
                    by_g[e[2]] += e[-1]
            assert sum(by_u.values(), F(0)) == Tprob[r][tp]
            assert sum(by_g.values(), F(0)) == Tprob[r][tp]
            new_labels[r, tp] = (by_u, by_g)
    # All source and right measures below are actual mu memberships; no dx proxy.
    sums = defaultdict(lambda: defaultdict(F))
    target_keys = sorted({(e[1], e[2]) for e in prior})
    hits = {}
    for r, es in post.items():
        for u, g in target_keys:
            ub = parents[u]["bit"]
            gb = parents[g]["bit"]
            uni = ub | gb
            hits[r, u, g] = {
                "q_to_u": sum((e[-1] for e in es if e[4] & ub), F(0)),
                "z_to_g": sum((e[-1] for e in es if e[3] & gb), F(0)),
                "q_union": sum((e[-1] for e in es if e[4] & uni), F(0)),
                "z_union": sum((e[-1] for e in es if e[3] & uni), F(0)),
                "both_union": sum(
                    (e[-1] for e in es if e[4] & uni and e[3] & uni), F(0)
                ),
                "both_cross": sum((e[-1] for e in es if e[4] & ub and e[3] & gb), F(0)),
            }
    origins = defaultdict(F)
    for r, es in post.items():
        wr = cells[r] * rdist[r]
        for t, u, g, z, q, pe in es:
            old = wr * pe
            origins[r, u, g] += old
            small = overlap(u, g) / min(F(parents[u]["m"]), F(parents[g]["m"]))
            for tp, prob in Tprob[r].items():
                if not prob:
                    continue
                branch = (
                    "same_t" if t == tp else "different_t",
                    (
                        "same_bin"
                        if parents[t]["volume_bin"] == parents[tp]["volume_bin"]
                        else "different_bin"
                    ),
                )
                w = old * prob
                S = sums[branch]
                S["mass"] += w
                # Conditional future q/z statistics are restricted to tp.
                new = [e for e in post[r] if e[0] == tp]
                ub = parents[u]["bit"]
                gb = parents[g]["bit"]
                S["q_to_u"] += old * sum((e[-1] for e in new if e[4] & ub), F(0))
                S["z_to_g"] += old * sum((e[-1] for e in new if e[3] & gb), F(0))
                S["both_cross"] += old * sum(
                    (e[-1] for e in new if e[4] & ub and e[3] & gb), F(0)
                )
                S["g_parent_score"] += (
                    w * overlap(g, tp) / F(parents[g]["m"]) * min(F(1), mt[t] / mt[tp])
                )
                S["small_inter_over_min"] += w * small
                # Unlike the preceding within-old-record u,g control,
                # these are genuinely from two independent records given r.
                for kind, distribution in zip(
                    ("old_g_new_u", "old_g_new_g"), new_labels[r, tp]
                ):
                    for new_parent, pnew in distribution.items():
                        piece = old * pnew
                        fraction = overlap(g, new_parent) / min(
                            F(parents[g]["m"]), F(parents[new_parent]["m"])
                        )
                        tag = "same" if g == new_parent else "different"
                        S[kind + "_" + tag + "_mass"] += piece
                        S[kind + "_" + tag + "_overlap"] += piece * fraction
    assert sum(origins.values(), F(0)) == 1
    assert sum(x["mass"] for x in sums.values()) == 1
    print(
        "\nFIXTURE",
        label,
        "records=",
        len(records),
        "total original mass=",
        M,
        "positive r cells=",
        len(rdist),
        "target pairs=",
        len(target_keys),
    )
    for branch, vals in sorted(sums.items()):
        w = vals["mass"]
        print(
            "PAIR_SUMMARY",
            branch,
            "mass=",
            float(w),
            "q_to_u=",
            float(vals["q_to_u"] / w),
            "z_to_g=",
            float(vals["z_to_g"] / w),
            "both_cross=",
            float(vals["both_cross"] / w),
            "g_parent_score=",
            float(vals["g_parent_score"] / w),
            "small_overlap=",
            float(vals["small_inter_over_min"] / w),
        )
        for kind in ("old_g_new_u", "old_g_new_g"):
            same = vals[kind + "_same_mass"]
            different = vals[kind + "_different_mass"]
            assert same + different == w
            same_fraction = vals[kind + "_same_overlap"] / same if same else None
            different_fraction = (
                vals[kind + "_different_overlap"] / different if different else None
            )
            if same:
                assert same_fraction == 1
            print(
                "TWO_RECORD_SMALL",
                branch,
                kind,
                "same/branch=",
                float(same / w),
                "different/branch=",
                float(different / w),
                "different_overlap_mean=",
                float(different_fraction) if different else None,
                "exact same,different,different_weighted=",
                same,
                different,
                vals[kind + "_different_overlap"],
            )
        print(
            "PAIR",
            branch,
            "denominator=",
            w,
            "~",
            float(w),
            "qprime_in_old_u=",
            float(vals["q_to_u"] / w),
            "zprime_in_old_g=",
            float(vals["z_to_g"] / w),
            "both_cross=",
            float(vals["both_cross"] / w),
            "g_inter_tprime_score=",
            float(vals["g_parent_score"] / w),
            "old_small_inter_over_min=",
            float(vals["small_inter_over_min"] / w),
        )
    # F_h(r): no target hit in h iterations; for changed-r, after each
    # failure sample r_new from real mu|A_tnew. Fixed-r is exactly (1-p)^h.
    for kind in ("q_union", "z_union", "both_union"):
        fixed = [F(0)] * 4
        changed = [F(0)] * 4
        for u, g in target_keys:
            p = {r: hits[r, u, g][kind] for r in rdist}
            Ft = {r: F(1) for r in rdist}
            for h in range(1, 5):
                updated = {}
                for r in rdist:
                    value = F(0)
                    for tp in ts:
                        ub = parents[u]["bit"]
                        gb = parents[g]["bit"]
                        uni = ub | gb

                        def hit(e):
                            qin = bool(e[4] & uni)
                            zin = bool(e[3] & uni)
                            return (
                                qin
                                if kind == "q_union"
                                else zin if kind == "z_union" else qin and zin
                            )

                        fail = sum(
                            (e[-1] for e in post[r] if e[0] == tp and not hit(e)), F(0)
                        )
                        value += fail * sum(
                            (
                                prob * Ft[r2]
                                for r2, prob in distribution_r_given_t[tp].items()
                            ),
                            F(0),
                        )
                    updated[r] = value
                Ft = updated
                for (r, uu, gg), weight in origins.items():
                    if (uu, gg) == (u, g):
                        fixed[h - 1] += weight * (1 - (1 - p[r]) ** h)
                        changed[h - 1] += weight * (1 - Ft[r])
        assert all(0 <= v <= 1 for v in fixed + changed)
        assert fixed == sorted(fixed) and changed == sorted(changed)
        print(
            "PREDICT",
            kind,
            "fixed_r=",
            *[float(x) for x in fixed],
            "update_r=",
            *[float(x) for x in changed]
        )
        print(
            " PREDICT_EXACT",
            kind,
            "fixed=",
            *[str(x) for x in fixed],
            "update=",
            *[str(x) for x in changed]
        )
    # Independent direct two-step check on one actual r and one target pair.
    r = next(iter(post))
    u, g = target_keys[0]
    bits = parents[u]["bit"] | parents[g]["bit"]
    direct = F(0)
    for e in post[r]:
        for f in post[r]:
            hit = bool(e[4] & bits) or bool(f[4] & bits)
            direct += e[-1] * f[-1] * hit
    assert direct == 1 - (1 - hits[r, u, g]["q_union"]) ** 2
    # Two-step independent record enumeration with a real source refresh.
    updated_direct = F(0)
    for e in post[r]:
        first_hit = bool(e[4] & bits)
        after = sum(
            (
                p * hits[r2, u, g]["q_union"]
                for r2, p in distribution_r_given_t[e[0]].items()
            ),
            F(0),
        )
        updated_direct += e[-1] * (F(1) if first_hit else after)
    kernel_fail = sum(
        (
            e[-1]
            * sum(
                (
                    p * (1 - hits[r2, u, g]["q_union"])
                    for r2, p in distribution_r_given_t[e[0]].items()
                ),
                F(0),
            )
            for e in post[r]
            if not e[4] & bits
        ),
        F(0),
    )
    assert updated_direct == 1 - kernel_fail
    print(
        "CHECK direct two-step fixed/update at r=",
        r,
        "target=",
        (u, g),
        "=",
        direct,
        updated_direct,
    )


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--archive", required=True)
args = parser.parse_args()
with zipfile.ZipFile(args.archive) as z:
    rebuilt = json.loads(z.read("comb814-rebuilt.json"))["stages"][0]
    ns = {"__name__": "archived_comb811"}
    exec(compile(z.read("comb811.py"), "comb811.py", "exec"), ns)
    name, n, h, middle, old = ns["FIXTURES"][-1]
    original = ns["fixture"](name, n, h, middle, old)
    test("original", original)
    test("rebuilt", rebuilt)
print("\nPASS exact stationary reverse posterior; n=4 high-dimensional gate empty")
