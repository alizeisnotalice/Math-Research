"""Finite R814 conditional joint/independent library charge diagnostics.

Freeze actual membership cell r and central dyadic D; use the exact posterior
from the original 230 weighted records. C is either the actual candidate-cell
product or its restriction to distinct cell labels. U,W are uniform in
actual disjoint owner boxes under the explicit R814 receiver model. The
same-owner corrections use m/|E|; j is printed separately and never silently
substituted. These 4D inputs have no original high-dimensional long-jump sample.
"""

import argparse, json, zipfile
from collections import defaultdict
from fractions import Fraction as F
from itertools import product


def run(name, stage):
    parents = {p["id"]: p for p in stage["parents"]}
    cells = {c["mask"]: F(c["mass"]) for c in stage["cells"]}
    roots = {(r["t"], r["u"], r["g"]): r for r in stage["roots_cross"]}
    records = []
    for root in stage["roots_cross"]:
        t, u, g = (root[k] for k in ("t", "u", "g"))
        D = F(parents[t]["volume_bin"])
        mt = F(parents[t]["m"])
        assert D <= mt < 2 * D
        zm, qm = root["z_masks"], root["q_masks"]
        cm = sum((cells[z] for z in zm), F(0))
        cp = sum((cells[q] for q in qm), F(0))
        same = sum((cells[z] ** 2 for z in set(zm) & set(qm)), F(0))
        assert cm * cp > same
        print(
            "CONTACT",
            name,
            (t, u, g),
            "c_minus=",
            cm,
            "c_plus=",
            cp,
            "c_product=",
            cm * cp,
            "c_offlabel=",
            cm * cp - same,
            "owner_u=",
            parents[u]["owner_volume"],
            "j_u=",
            parents[u]["j"],
            "owner_g=",
            parents[g]["owner_volume"],
            "j_g=",
            parents[g]["j"],
        )
        for z, q in product(zm, qm):
            records.append(
                (t, u, g, z, q, D, F(root["coefficient"]) * cells[z] * cells[q])
            )
    assert len(records) == 230
    M = sum((e[-1] for e in records), F(0))
    assert M == F(stage["benchmarks"]["cross"]["mother"])
    # m/|E| is a physical Lebesgue correction; j is the separate archived
    # marking weight in the original mother coefficient.
    correction = {
        x: F(parents[x]["m"]) / F(parents[x]["owner_volume"]) for x in parents
    }
    for parent_id, parent in sorted(parents.items()):
        if parent["role"] != "old":
            continue
        owner = F(parent["owner_volume"])
        marking = F(parent["j"])
        print(
            "OWNER_VS_J",
            name,
            parent_id,
            "j/owner=",
            marking / owner,
            "owner_correction_m/owner=",
            F(parent["m"]) / owner,
            "marking_correction_m/j=",
            F(parent["m"]) / marking,
            "corrections_equal=",
            owner == marking,
        )
    groups = defaultdict(list)
    for t, u, g, z, q, D, w in records:
        for r, mr in cells.items():
            if r & parents[t]["bit"]:
                groups[r, D].append((t, u, g, z, q, w / M * mr / F(parents[t]["m"])))
    assert sum((e[-1] for values in groups.values() for e in values), F(0)) == 1
    highest = max(groups, key=lambda k: sum(e[-1] for e in groups[k]))
    highest_weight = sum(e[-1] for e in groups[highest])
    print(
        "\nFIXTURE",
        name,
        "records=",
        len(records),
        "original_mass=",
        M,
        "posterior_(r,D)_groups=",
        len(groups),
        "highest group=",
        highest,
        "relative mass=",
        float(highest_weight),
        "source_cell_mass=",
        cells[highest[0]],
    )
    # Each row's full original joint is aggregated only after freezing r,D.
    stats = defaultdict(
        lambda: {
            "eligible": F(0),
            "score": F(0),
            "hit1": F(0),
            "hit10": F(0),
            "hit1000": F(0),
        }
    )
    highstats = defaultdict(
        lambda: {
            "eligible": F(0),
            "score": F(0),
            "hit1": F(0),
            "hit10": F(0),
            "hit1000": F(0),
        }
    )
    for rD, es in groups.items():
        r, D = rD
        groupweight = sum(e[-1] for e in es)
        joint = defaultdict(F)
        left = defaultdict(F)
        right = defaultdict(F)
        for t, u, g, z, q, w in es:
            p = w / groupweight
            joint[z, u, q, g] += p
            left[z, u] += p
            right[q, g] += p
        assert (
            sum(joint.values(), F(0))
            == sum(left.values(), F(0))
            == sum(right.values(), F(0))
            == 1
        )
        for t, u, g, z, q, w in es:
            root = roots[t, u, g]
            Z = set(root["z_masks"])
            Q = set(root["q_masks"])
            cm = sum((cells[a] for a in Z), F(0))
            cp = sum((cells[b] for b in Q), F(0))
            for C in ("product", "different_cell"):
                if C == "different_cell" and z == q:
                    continue
                denom = sum(
                    (
                        cells[a] * cells[b]
                        for a, b in product(Z, Q)
                        if C == "product" or a != b
                    ),
                    F(0),
                )
                assert denom > 0 and (z in Z and q in Q)
                if C == "product":
                    assert denom == cm * cp
                for library in ("joint", "independent"):
                    for mode in ("none", "one", "two"):
                        for varied in (False, True):
                            P = F(0)
                            if library == "joint":
                                iterator = (
                                    (a, uu, b, gg, p)
                                    for (a, uu, b, gg), p in joint.items()
                                )
                            else:
                                iterator = (
                                    (a, uu, b, gg, pl * pr)
                                    for (a, uu), pl in left.items()
                                    for (b, gg), pr in right.items()
                                )
                            for a, uu, b, gg, p in iterator:
                                if (
                                    a not in Z
                                    or b not in Q
                                    or (C == "different_cell" and a == b)
                                ):
                                    continue
                                if varied and (a, b) == (z, q):
                                    continue
                                if mode in ("one", "two") and uu != u:
                                    continue
                                if mode == "two" and gg != g:
                                    continue
                                P += p
                            if mode in ("one", "two"):
                                P *= correction[u]
                            if mode == "two":
                                P *= correction[g]
                            score = D * D * P / denom
                            key = (
                                C,
                                library,
                                mode,
                                "changed_labels" if varied else "all_labels",
                            )
                            for target in (
                                (stats, highstats) if rD == highest else (stats,)
                            ):
                                entry = target[key]
                                entry["eligible"] += w
                                entry["score"] += w * score
                                for cut in (1, 10, 1000):
                                    if score >= cut:
                                        entry["hit" + str(cut)] += w
    for scope, table in [("all", stats), ("highest_rD", highstats)]:
        for key, v in sorted(table.items()):
            E = v["eligible"]
            assert E > 0
            print(
                "SCORE",
                name,
                scope,
                *key,
                "eligible_orig_fraction=",
                float(E),
                "mean=",
                float(v["score"] / E),
                "ge1,10,1000=",
                *[float(v["hit" + str(cut)] / E) for cut in (1, 10, 1000)],
                "eligible_exact=",
                E,
                "score_numerator_exact=",
                v["score"]
            )
    print(
        "LABEL NOTE different_cell excludes all (z,q) with the same membership-cell label, including distinct continuous source points; changed_labels is label change only, never a test of exact point inequality."
    )


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--archive", required=True)
args = parser.parse_args()
with zipfile.ZipFile(args.archive) as z:
    rebuilt = json.loads(z.read("comb814-rebuilt.json"))["stages"][0]
    ns = {"__name__": "archived_comb811"}
    exec(compile(z.read("comb811.py"), "comb811.py", "exec"), ns)
    name, n, h, middle, old = ns["FIXTURES"][-1]
    original = ns["fixture"](name, n, h, middle, old)
    run("original", original)
    run("rebuilt", rebuilt)
print(
    "\nPASS exact joint/posterior and independent-marginal library comparison; n=4 high-dimensional gate empty"
)
