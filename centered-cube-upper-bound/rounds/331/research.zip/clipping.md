# R331 — source-paid clipping of small active-pair denominators

**Bounded conclusion.** In the frozen R330 hard-matched slot, every active-pair denominator `j_*` may be increased to `max(j_*,T)`, `T≥H`, at an explicit source-linear undercoverage price. The original gate `J≥H`, actual receivers, all pair masks and all physical clocks remain unchanged. This removes the need for pointwise coverage at the smallest overlapping high-row mass. The remaining clipped pair bill is not proved root bounded. The source estimate uses the old stopped low-row mechanism; it is not counted as a second new low-row theorem.

## 1. Exact statement

Use the actual definitions and common feasible source `g∈G` from `/tmp/r330_core.md`: `m_u=q(u)R(u)^n`, `dμ=1_Edu/m_u`, `q_-≤q≤λ`, `a≤R≤b≤2a`, `J,A,V`, `Y_r={J(r)≥H}`, and `ell=b^-nδ_b+nr^-n-1dr`. In particular `∫g(z)A_yz(r)dz=V_y(r)`. Set `W_g=||g||₁`, `X=λ|E|`.

Retain the actual prefix-dependent active mask `χ_r(u,v)` and essential minimum `j_*(r,u,v)` of R330, defined on `Y_r∩Q_u∩Q_v`. For every captured high row, `j_*≤J_y(r)` for almost every corresponding pair, by the original essential-infimum/Fubini argument. Inactive pairs have zero reference. For a fixed `T≥H`, define

\[
 D_T=\max(j_*,T),\qquad
 h_T(r,u,v)=\frac{m_u+m_v}{4\sqrt{D_T}}\chi_r(u,v),
\]
\[
 \mathcal C_T=\|h_T\|_{L^2(\xi)}^2
 =\int\ell(dr)\iint_{E_r^2}
 \frac{\chi_r(u,v)}{16\max(j_*,T)}
 \left(\frac{m_u}{m_v}+\frac{m_v}{m_u}+2\right)dudv.             \tag{1}
\]

This is finite by the R330 bill bound. Large local denominators are retained exactly. No source is distributed independently to different values of `T` or clocks.

Define the original stopped coefficient

\[
 l_t(y)=\int\ell(dr)1_{J_y(r)<t}V_y(r),\qquad
 L_t(g)=\int g(y)l_t(y)dy.
\]

The old stopping/Fubini estimate gives `0≤l_t≤λt` for every `t>0`. Then the following full-slot inequality holds:

\[
 \boxed{\quad B_H(g,g)\le\mathcal C_T+\mathcal R_{H,T}(g),\quad}
                                                                    \tag{2}
\]
\[
 \mathcal R_{H,T}(g)=\int g(y)dy\int\ell(dr)
 1_{H\le J_y(r)<T}V_y(r)\left(1-\sqrt{J_y(r)/T}\right)
 =\int_H^T\frac{L_t(g)-L_H(g)}{2\sqrt{Tt}}dt,                 \tag{3}
\]
\[
 0\le\mathcal R_{H,T}(g)
 \le\lambda\frac{T-H^{3/2}/\sqrt T}{3}W_g
       -\left(1-\sqrt{H/T}\right)L_H(g).                     \tag{4}
\]

In particular, discarding only the explicit nonnegative credit in (4),

\[
 B_H(g,g)\le\mathcal C_T+
       \frac\lambda3\left(T-\frac{H^{3/2}}{\sqrt T}\right)W_g. \tag{5}
\]

At `T=H`, the deficiency vanishes, and this yields `B_H≤C_*` for this nonnegative reference. The `λH` completion fee in the generic all-row dual is unnecessary for this particular positive covering reference; the stronger completed kernel remains available for general signed receiver potentials/reference constructions.

## 2. Proof and clock/atom checks

Use the HIGH-only PSD feature map, not an unnecessarily completed one:

\[
 \varphi^H_y(r,u,v)=1_{Y_r}(y)c_u(y)c_v(y)/\sqrt{J_y(r)},
 \qquad Q_{HH}(g)=\|\Phi_Hg\|^2.
\]

The original square energy `E_H` satisfies `E_H≥Q_HH`: high/high symmetrization gives the geometric reciprocal plus a nonnegative reciprocal-clock square, and high/low terms are also nonnegative. Hence

\[
 B_H\le\int a_Hg-Q_{HH}
 \le\|h_T\|^2+\int g(y)[a_H(y)-2\langle h_T,\varphi^H_y\rangle]dy.
                                                                    \tag{6}
\]

For a high row with `H≤J<T`, almost every captured active pair has `j_*≤J<T`; its clipped denominator is exactly `T`. The same actual pair calculation as R330 therefore gives coverage `V√(J/T)`. For `J≥T`, every captured pair has `D_T≤J`, giving coverage at least `V`. Low rows have both `a_H=0` and `φ^H=0`. Thus the positive deficit is bounded by the integrand in (3), proving (2). This argument retains all actual `dx` and receiver weights.

For `H≤j<T`,

\[
 1-\sqrt{j/T}=\int_j^T\frac{dt}{2\sqrt{Tt}}.
\]

Positive Fubini gives (3), since `1_{J<t}−1_{J<H}=1_{H≤J<t}`. Using `L_t≤λtW_g` inside this exact identity yields (4). No continuous distribution of `J` is assumed: values `J=H` are included, values `J=T` contribute zero, and any physical-radius atom enters in its entirety. `ell` has its explicit `b` atom; its inclusive tail also covers `R=a`. The old `l_t` proof handles a first crossing at either endpoint and rows that never cross. Original prefixes are not reset and no atom is internally sorted.

## 3. What is paid, and what is not

For any chosen `T`, the entire undercoverage is genuinely paid by (4), without a small-bad-fraction hypothesis, a density cap, or a receiver potential. The original high gate has not been raised to `T`. The bill in (1) is nonincreasing in `T`, and `C_T≤C_H H/T` for the original denominator-`H` bill `C_H` (not necessarily for `C_*`). One may take the infimum of the right side of (5) over `T≥H` as alternative bounds on the same traffic. These are not separate source payments to sum.

For example, if `λT≤C√A_n log^p(n+2)`, the undercoverage is a root/polylog source fee. To deduce `εX+C'√A_n log^p W_g` for the whole slot still requires `C_T≤εX`, or a further valid receiver-dual settlement. No such general estimate is supplied. Equation (5) is a priced denominator truncation, not a renamed already-small remainder.

Comparison with simply raising the gate: that alternative changes the active mask to `Y_T`, leaves an explicit `H≤J<T` variance branch, and pays it using `L_T−L_H`. Here the gate and its active pairs remain `Y_H`, including original near-threshold traffic; their undercoverage is a square-root ramp, with the smaller exact integral (3). The two pair bills are different and no universal ordering of their TOTAL bounds is asserted. Both source costs are of order `λT`; this is not a new dimension exponent or a global root theorem.

## 4. Actual local computation

A standard-library Python `decimal` run at 70 digits passed **1,062** assertions over 30 finite-incidence cumulative fields and `T/H=1,2,4`. It checked actual clipped coverage, (4), (2), and bill monotonicity. These are finite algebra diagnostics with tolerance `10^-58`, not interval certificates, literal cube examples, or a root-bound test. The proof above does not depend on them. The following is the executed minimal reproduction.

```python
from decimal import Decimal as D, getcontext
getcontext().prec=70
tol=D('1e-58'); count=0
for case in range(1,31):
    n=1+case%4; radii=[D(1),D(5)/4,D(3)/2,D(2)]
    g=[D(1+(case+i)%4)/7 for i in range(4)]
    bits=[[1,int((case+j)%2==0),int((case+2*j)%3!=0),1]
          for j in range(4)]
    mu=[D(1+(case+j)%5)/9 for j in range(4)]
    masses=[sum(g[y]*bits[u][y] for y in range(4)) for u in range(4)]
    lam=max(masses[u]/radii[u]**n for u in range(4))
    H=D(2+case%5)/8
    for mult in [D(1),D(2),D(4)]:
        T=mult*H; B=Cstar=Cclip=R=Llow=D(0)
        for k,r in enumerate(radii):
            ell=r**(-n)-(radii[k+1]**(-n) if k<3 else D(0))
            J=[sum(mu[u]*bits[u][y] for u in range(k+1)) for y in range(4)]
            V=[sum(mu[u]*masses[u]*bits[u][y] for u in range(k+1))
               for y in range(4)]
            A=[[sum(mu[u]*bits[u][y]*bits[u][z] for u in range(k+1))
                for z in range(4)] for y in range(4)]
            high=[j>=H for j in J]; cover=[D(0)]*4
            for u in range(k+1):
                for v in range(k+1):
                    active=[y for y in range(4)
                            if high[y] and bits[u][y] and bits[v][y]]
                    if not active: continue
                    js=min(J[y] for y in active); den=max(js,T)
                    coeff=(masses[u]+masses[v])/(4*den.sqrt())
                    Cclip+=ell*mu[u]*mu[v]*coeff**2
                    Cstar+=ell*mu[u]*mu[v]*(masses[u]+masses[v])**2/(16*js)
                    for y in active:
                        cover[y]+=2*mu[u]*mu[v]*coeff/J[y].sqrt()
            for y in range(4):
                if high[y]:
                    B+=ell*g[y]*sum(g[z]*(A[y][z]-A[y][z]**2/J[y])
                                    for z in range(4))
                    deficit=V[y]*max(D(0),1-(J[y]/T).sqrt())
                    R+=ell*g[y]*deficit
                    assert V[y]-cover[y]<=deficit+tol; count+=1
                else: Llow+=ell*g[y]*V[y]
        c=(T-H*(H/T).sqrt())/3
        upper=lam*c*sum(g)-(1-(H/T).sqrt())*Llow
        assert R<=upper+tol; count+=1
        assert B<=Cclip+R+tol; count+=1
        assert Cclip<=Cstar+tol; count+=1
print('PASS',count)
```

Only `/tmp/r331_aux.md` is authored. No other research file or Git state is changed.
