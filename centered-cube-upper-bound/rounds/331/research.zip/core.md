# R331 — a coupled receiver-capacity reference with an exact signed-potential bill

**Status.** An explicit class of jointly constructed Hilbert references and signed receiver potentials is given below. The reference bill is paid exactly by the SAME local-mean constraint; the construction does not require the Hilbert norm alone to be small. The remaining source-profile estimate is not proved at root size. In particular, neither the capacity class nor its Gibbs member is presented as a general root receipt. The concrete next geometric problem is to choose a symmetric actual-receiver coupling within the displayed capacities, not merely to thin the R330 reference or rename its residual.

## 1. Preserve the original frozen slot

Use the R330 hard-matched contract, with actual `β=f dx`, `ν≤f dx`, `T f=q`, `q_-≤q≤λ`, `q_-=3λ/4`, `a≤R≤b≤2a`, `E` finite, and full original `J,A`. Write

\[
 m_u=q(u)R(u)^n,\quad d\mu(u)=1_E(u)du/m_u,\quad
 E_r=E\cap\{R\le r\},\quad c_u(y)=1_{Q_{R(u)}(u)}(y),
\]
\[
 J_y(r)=\int_{E_r}c_u(y)d\mu(u),\quad
 A_{yz}(r)=\int_{E_r}c_u(y)c_u(z)d\mu(u),\quad
 V_y(r)=\int_{E_r}c_u(y)du.
\]

Keep `ell=b^{-n}δ_b+nr^{-n-1}1_[a,b]dr`, `Y_r={J_y(r)≥H}`, and

\[
 a_H(y)=\int\ell(dr)1_{Y_r}(y)V_y(r),\quad
 l_H(y)=\int\ell(dr)1_{Y_r^c}(y)V_y(r)\le\lambda H.
\]

Thus `a_H+l_H=T*1_E`, with no scale-envelope factor. The previously proved all-row completion, used as an alternative bound on the full original slot, is

\[
 B_H(g,g)\le\int a_Hg-Q_{\rm all}(g)+\lambda H\|g\|_1,
 \qquad Tg=q.                                                \tag{1}
\]

For the actual target, positivity gives `B_H(f,ν)≤B_H(f,f)`; a bound from (1) replaces the full original slot and is not added to already-paid crossing or large-atom costs.

Its features are `φ_y(r,u,v)=c_u(y)c_v(y)/√J_y(r)` under
`dξ=ell(dr)1_(u,v∈E_r)dμ(u)dμ(v)`, with zero rows assigned zero. No physical atom, low/high source, or already-paid receiver block is removed from these definitions.

## 2. The actual receiver row-capacity class

Choose a jointly measurable, symmetric kernel `S_r(u,v)≥0` on `E_r²` such that

\[
 a_r(u):=\int_{E_r}S_r(u,v)d\mu(v)\le m_u
 \quad\text{for }\ell(dr)d\mu(u)\text{-a.e. }(r,u).             \tag{2}
\]

Here `a_r` is a row marginal, distinct from the source coefficient `a_H`. This capacity uses the real `q,R,E`. It is not a bound on source density, and does not change the selected receivers. A positive symmetric subkernel of a feasible `S` remains feasible, but coverage need not survive such a deletion.

Let `θ∈L∞(E)` be real and independent of the prefix parameter `r`. Set

\[
 x_u=\theta(u)\sqrt{m_u},\qquad
 h_\theta(r,u,v)=\frac12\sqrt{S_r(u,v)}(x_u+x_v),\qquad
 \psi_0(u)=-\theta(u)^2.                                     \tag{3}
\]

Define the nonnegative capacity slack and edge-energy credits

\[
 L_\theta=\int\ell(dr)\int_{E_r}\theta(u)^2m_u[m_u-a_r(u)]d\mu(u),
\]
\[
 D_\theta=\frac14\int d\xi\,S_r(u,v)(x_u-x_v)^2.               \tag{4}
\]

Then the exact budget identity is

\[
 \boxed{\quad
 \|h_\theta\|_{L^2(\xi)}^2+\int_E\psi_0(u)q(u)du
       =-L_\theta-D_\theta\le0.
 \quad}                                                       \tag{5}
\]

Indeed, symmetry gives
`||hθ||²=∫ell∫ θ²m a_r dμ−Dθ`. The original inclusive tail gives

\[
 \int\ell(dr)\int_{E_r}\theta(u)^2m_u^2d\mu(u)
 =\int_E\theta(u)^2m_uR(u)^{-n}du
 =\int_E\theta(u)^2q(u)du.
\]

Subtracting proves (5). In particular, (2) implies all terms are finite and `hθ∈L²(ξ)`. The potential `ψ₀` is integrable because `E` is finite. The crucial tail computation would not remain this formula if an independently chosen `θ_r(u)` were silently substituted.

Thus the reference can have norm comparable with `X`; the signed receiver potential pays it using `Tg=q`. This addresses the norm-only obstruction directly, but (5) alone says nothing about the required source coefficient.

## 3. Exact source defect, including the adjustable geometric term

For `J_y(r)>0`, define

\[
 e_S(y,r)=V_y(r)-\iint_{E_r^2}S_r(u,v)c_u(y)c_v(y)d\mu(u)d\mu(v),
\]
\[
 R_{S,\theta}(y,r)=\iint_{E_r^2}c_u(y)c_v(y)
 \left[\frac{\theta(u)\sqrt{m_u}}{\sqrt{J_y(r)}}
                       -\sqrt{S_r(u,v)}\right]^2d\mu(u)d\mu(v).
                                                                    \tag{6}
\]

Zero rows contribute zero. The row-capacity condition yields the exact positive decomposition

\[
 e_S(y,r)=\int_{E_r}c_u(y)[m_u-a_r(u)]d\mu(u)
 +\frac12\iint_{E_r^2}S_r(u,v)[c_u(y)-c_v(y)]^2d\mu(u)d\mu(v)
 \ge0.                                                         \tag{7}
\]

The second term is a true cube-membership cut of the chosen actual receiver coupling. It is measured with the same `S_r` as the edge-energy credit in (4).

Expanding the square in (6), and using symmetry for its cross term, gives

\[
 \boxed{\quad
 a_H(y)+T^*(\theta^2)(y)-2\langle h_\theta,\varphi_y\rangle
 =\int\ell(dr)[e_S(y,r)+R_{S,\theta}(y,r)]-l_H(y).
 \quad}                                                       \tag{8}
\]

The norm of the first vector in that square is `∫_(E_r)θ(u)²c_u(y)du`; the norm of the second is `V_y(r)−e_S(y,r)`. This proves (8) without a correlation lower bound. The pointwise terms are finite for almost every source position; bounded `θ`, the capacity bound, and `∫ell V_y≤T*1_E(y)<∞` suffice. Standard absolute Fubini also follows from the bounded feature norm and, for receiver potentials, `∫g T*|ψ|=∫|ψ|q`.

If a further signed `ζ∈L¹(E)` is chosen, use the JOINT potential
`ψ=−θ²+ζ`. A sufficient actual geometric certificate is

\[
 \int\ell(dr)[e_S(y,r)+R_{S,\theta}(y,r)]-l_H(y)
                 \le c+T^*\zeta(y)\quad\text{a.e. }y,\qquad
 \int_E\zeta q\le L_\theta+D_\theta+\varepsilon X.              \tag{9}
\]

Equations (1), (5), and Hilbert's square inequality then prove

\[
 B_H(g,g)\le\varepsilon X+(c+\lambda H)\|g\|_1.                 \tag{10}
\]

This is the remaining task, with the available compensation explicitly quantified. For root `λH`, one needs `c` of root/polylogarithmic size. No such general choice of `S,θ,ζ` is constructed here. Choosing a kernel with small cut escape but large square-fit error does not verify (9); neither does deleting high-source positions on the basis of their Lebesgue measure.

## 4. A genuinely matched feasible kernel, and the limitation of fixing it

The original shared source supplies a saturated member of (2):

\[
 S_r^{\rm G}(u,v)=\int f(z)\frac{c_u(z)c_v(z)}{J_z(r)}dz.        \tag{11}
\]

The zero-denominator integrand is defined as zero. Positive Fubini and `Tf=q` prove

\[
 \int_{E_r}S_r^{\rm G}(u,v)d\mu(v)
 =\int f(z)c_u(z)1_{J_z(r)>0}dz=m_u\quad\text{a.e. }u.
\]

The exceptional zero-row part has zero `μ` integral, since `∫_(E_r)c_u(z)dμ(u)=J_z(r)`. This argument works under the full `ell` measure and at its atoms. Thus (11) is a legitimate initial coupling and has `Lθ=0`.

For this particular kernel only,

\[
 e_{S^{\rm G}}(y,r)=V_y(r)-\int f(z)\frac{A_{yz}(r)^2}{J_z(r)}dz.
                                                                    \tag{12}
\]

Its `ell` integral is the already-existing all-row column price, with the reverse denominator `J_z`, not a new geometric remainder. Keeping (11) fixed and varying only `θ` leaves this term unchanged; a uniform root bound on the resulting defect would require a strong bound on that old column quantity or a paid `ζ` cover. Equation (12) is therefore a scope warning, not the claimed advance.

In the full capacity class (2), the escape term DOES change with `S`. The next specific geometry to investigate is a symmetric receiver coupling that simultaneously has small cube-cut energy (7) and small fit error (6), or for which the excess can be covered by an actual receiver potential within the credits in (9). Unlike a prescribed Gibbs posterior or independent pair thinning, (2) permits changing the coupling while retaining an exact bill. Any proposed construction must preserve every real-prefix capacity and certify the source inequality over all positions, including the unrepresented complement. A finite receiver/source discretization can test this tradeoff, but does not by itself certify the continuum inequalities.

## 5. Verification and bounded conclusion

Local Python `Decimal` arithmetic at 70 digits checked the row balance, signed-potential budget, and source-defect identity for finite incidence fields. A second run checked symmetric row-subcapacity kernels and the cut/slack decomposition. These are numerical algebra diagnostics at tolerance `10^-58`, not interval certificates, actual-cube extremizers, or evidence of a root estimate. The exact proofs above are independent of those checks.

The constructive result is (5) for the entire actual row-capacity class, together with the precise geometric obligations (6)–(9). It removes the requirement that a Hilbert reference have a small norm by itself. It does not yet pay the original general small/continuous innovation residual. Only `/tmp/r331_core.md` is authored; no Git or other agent's files are changed. Bounded delivery ends here.
