# R331 — exact full-source bins with local J denominators

Reproduce with standard-library Python:

```
/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 /tmp/r331_numeric.py
```

No earlier script is imported. The owned files are `/tmp/r331_numeric.py`, `.json`, `.md`. All arithmetic and assertions are exact `Fraction`. Large values are compressed in JSON using an explicitly specified signed numerator/denominator digest; decimal values are descriptive only.

## Actual geometry and validity of the J bound

Keep the R328/R330 actual field: f=β=ν=1_Q4; δ=1/(4n); r_j=1+j/n; s_j=r_j−δ; receiver shells Ej=Q_sj minus Q_s(j−1), with s_−1=0; s=0,L=R=r_j,q=λ=1,α=1. Kernel cubes lie wholly in Q4, hence actual q=1 and FIRST density1_E. Wf=4^n is retained. This does not assert complete original history/winner qualification.

For each cut t=1/2 or1 partition the FULL β source into boxes according to which coordinates have |y_i|≤t and which have |y_i|>t. The union with k inner coordinates has binomial(n,k) equivalent coordinate patterns. The denominator upper bound J_k(m) is the actual prefix occupation at the profile y=(0,...,0,t,...,t), with k zeros.

This upper bound requires an actual geometric argument; arbitrary annular convolutions need not be monotone. Here reflection of receiver shells allows y_i≥0. Since u∈Ej implies u_i≤s_j/2<r_j/2≤y_i+r_j/2, the upper face of the capture interval is AUTOMATICALLY satisfied. The capture condition is exactly u_i≥y_i−r_j/2 in every coordinate. On the fixed shell Ej these lower-halfspace conditions are nested as y increases. Therefore its nonnegative capture integral, and their weighted prefix sum J_y(m), are coordinatewise nonincreasing in |y|. Every point of the k-bin is bounded by J_k(m). This proves the bound on the full boxes, not merely at tested profiles. The script also exactly checks several within-bin profiles, retaining their actual shell integrals. Bin boundaries are source-null. Some early J_k=0; the corresponding exact S_k=0 is checked before division.

## Exact source-bin second moments

Write l(s,t;x) for the centered-interval overlap trapezoid. For a receiver pair at positions u,v and radii r_i,r_j, let p(u,v) be the length of their kernel intersection clipped to the inner source interval [−t,t], and q(u,v) its full intersection length. Define

W_inner=∫_receiver-intervals p(u,v)q(u,v) du dv,
W_total=∫ l(receiver_sides;x) l(r_i,r_j;x)^2 dx,
W_outer=W_total−W_inner.

The first overlap restricts source y, while the second integrates the COMPLETE source z. Source kernel support lies within Q4, so the complement outer y region is exactly the remaining true source measure; no source tail is dropped.

The receiver rectangle is partitioned by all vertical/horizontal lines where u±r_i/2 or v±r_j/2 equals±t, and diagonal lines u−v=±(r_i+r_j)/2 or±|r_i−r_j|/2. On each polygon p and q are affine (including zero pieces). Triangulation integrates their product exactly:

integral_triangle p q = area * [(Σp_vertex)(Σq_vertex)+Σ(p_vertex q_vertex)]/12.

For n1/2, cut2 recovers W_total by an independent displacement-trapezoid cubic integral; 72 such comparisons include zero receiver-side terms. All nonzero clipped integrals are checked between0 and W_total.

After four signed outer/inner receiver-shell terms and actual factors(r_i r_j)^−n, bin k contributes

binomial(n,k) W_inner^k W_outer^(n−k)

to S_k(m)=∫_(β source bin k)∫ν A_yz(m)^2. Every shell pair and prefix sum is checked to satisfy Σ_k S_k=Z from the full-source moment, exactly. Both source integrations remain continuum integrations; source probes do not replace them.

Consequently the original square term satisfies

Eall_m=∫βν A_yz(m)^2/J_y(m) ≥ Σ_(k:J_k>0) S_k(m)/J_k(m).

This dominates the old Z_m/Jcentral_m lower bound. The full ell sum retains the terminal b atom. The actual first-moment account is X=Σ|Ej|=(2−δ)^n. Thus the computed true fixed-fixture bound is

BH≤B_all≤X−Σ_m ell_m Σ_k S_k(m)/J_k(m).

The exact reciprocal integral is not evaluated; this remains a lower relaxation of the square term and an upper bound on B_all. There is no general-input/root-budget claim.

## Actual diagnostic results

Entries below are the fraction of X saved by the square-term lower bound. The last column uses the better of the two tested local partitions and is a descriptive comparison, not a freely optimized source partition.

|n|old Jcentral saving|cut1/2 local saving|cut1 local saving|best improvement factor|
|---|---:|---:|---:|---:|
|1|0.438690476|0.516100810|0.552976190|1.26052|
|2|0.164647689|0.249333917|0.243243316|1.51435|
|4|0.0254931083|0.0613695464|0.0582996603|2.40730|
|8|0.000841140577|0.00489270580|0.00476889903|5.81675|
|16|1.70223445e−6|4.67381051e−5|4.55876159e−5|27.4569|

Local occupations improve the R330 denominator relaxation substantially as a relative factor. Nevertheless at n16 the best computed upper bound remains approximately0.999953262 X, so this tested coarse binning still gives little absolute budget saving. No exponent, asymptotic conclusion or extremal input assertion is drawn.

## Execution record

Two fresh standalone processes passed the same **11,934 exact checks**. Three stages: n1/2 initial-independent358; n4/8 geometry/boundary2,464; n16 expanded9,112; both cuts in every dimension. Counts include444 exact source-bin shell-pair partition identities,72 full-prefix partition identities,6,210 nonnegative source-bin shell-pair moments,816 zero-denominator guards,2,448 actual geometric J probes and72 local-versus-global denominator comparisons. Source partition and local-J proofs above explain why the finite exact calculations yield valid continuum bounds for these specified inputs. Dimensions32/64 were deliberately not added; the requested bounded n16 expansion sufficed to diagnose the remaining weakness.
