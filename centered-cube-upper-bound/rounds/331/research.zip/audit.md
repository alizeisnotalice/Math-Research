# R331 independent preauthor screen — source-bin normalization for the actual shell fixture

Ownership only /tmp/r331_audit.md; no Git or other-author edits. No R331 author proof/code has been read. Retain R330 actual f=beta=nu=1_Q4, delta=1/(4n), r_j=1+j/n, s_j=r_j-delta, actual E_j=Q_sj\Q_s(j-1), q=lambda1,alpha1,s0,L=R. Full actual receiver cubes lie in Q4. The result below is a fixture-specific complete-source bound, not a general input/history or exact B_all theorem.

## 1. Monotone actual source-row mass and bin upper bounds

For y_i>=0 and u in E_j, u_i<=s_j/2<r_j/2<=y_i+r_j/2. Thus the U_y capture condition in that coordinate is ONLY u_i>=y_i-r_j/2; its upper face never restricts the actual shell. Increasing y_i nests these lower halfspace cuts. This proves actual shell captured volume and every prefix J_y are nonincreasing in each NONNEGATIVE y_i. It does not infer monotonicity from two separately decreasing outer/inner volumes, whose difference would not suffice. Coordinate reflection symmetry then gives coordinatewise monotonicity in |y_i|. The argument crucially uses r_j>s_j for EACH actual shell and constant q1; it is not valid automatically for arbitrary f/receiver fields.

Let c=cut with0<=c<=2. The inner coordinate interval is[-c,c], FULL SIDE2c, inside the original source interval[-2,2]. The outer set is[-2,-c) union(c,2], up to null faces. For a bin with k inner coordinates and n-k outer coordinates, its actual J_prefix(y)<=J_prefix(0^k,c^(n-k))=:J_k. Permutation/reflection symmetry makes this bound common to all coordinate choices/signs. Strict outer coordinates use the limiting boundary c for a valid supremum; equality at a bin face is a null convention. At c0/c2 some bins have zero measure and must be handled by zero numerator, not extra sign factors.

## 2. Full numerator split and exact normalization direction

For a fixed receiver pair(u,v), let I=Q_ri(u) intersection Q_rj(v) in ONE coordinate. Full source supports make the other source factor |I| exact. Define Wtotal for each receiver outer/inner interval rectangle as integral du dv |I|², Win=integral du dv |I intersection[-c,c]| |I|, Wout=Wtotal-Win>=0. Win is a TWO-DIMENSIONAL receiver integral in one spatial coordinate; finite c breaks translation invariance, so it cannot generally be reduced to only the displacement u-v by the R330 difference-density formula without extra clipping.

The complete source-bin second moment is

 S_k=comb(n,k) sum_(i,j in prefix)(r_i r_j)^(-n) sum_(sigma,tau=+,-) sign_sigma sign_tau Win_(i,sigma,j,tau)^k Wout_(i,sigma,j,tau)^(n-k).

The FOUR shell signs are applied AFTER the tensor powers for each outer/inner rectangle pair. Subtracting signed one-dimensional shell values first and then taking their n-th power would be wrong. Binomial coefficient counts which coordinates are inner. NO additional2^(n-k) is needed: Win uses both signs of the inner interval and Wout includes both outer components already. Each S_k is the genuine nonnegative integral over all y in that bin family and all z in the full Q4 source. Summing k gives the exact R330 global numerator Z by the binomial theorem and the same four signed shell terms. No y or z mass is omitted or copied.

Since J_y<=J_k on each bin and A_yz0 whenever J_y0, the original whole reciprocal square Eall>=sum_(k:J_k>0)S_k/J_k. If J_k0, the bin's true numerator is0 and the contribution is defined0; this must be checked without dividing0. The complete ell sum includes the b atom, and full first-moment ell sum remains X, so BH<=B_all<=X-sum_prefix ell sum_k S_k/J_k. This retains source-dependent normalization more closely than a single Jcentral, but is still an UPPER BOUND, not exact B_all/BH or general-root payment. A lower bound for the completed symmetric Qall, if later claimed, needs its own argument; this directional denominator step directly concerns Eall.

## 3. Actual independent bounded checks

Reviewer executed617 exact Fraction assertions: {'monotone_actual_shell': 160, 'bin_maximum': 425, 'tensor_partition': 32}. Actual n1/2 shell-prefix clipped volumes check monotonicity and bin supremum for all prefixes, cuts0,1/2,1,3/2,2 and signed source grids. The additional tensor partition tests check the nonnegative binomial arithmetic only; they are not substitute Win receiver integrals. No R331 author file/code has been read or full author run repeated.

Initial verdict PASS for this fixture-specific source-bin normalization strategy and stated integral formula, with the exact denominator/zero-bin/sign conventions above. Await actual Win integration implementation and final scope.

## 4. Independent screen of two general hard-field feature contracts

These are distinct from the uniform-source numeric fixture. Freeze the R329 hard shared field, actual f>=0 in L1 with Tf=q, finite E, m_u=q(u)R(u)^n and dmu=1_Edu/m_u. Keep original U,J,A,H, full ell and all prefixes.

(A) Signed-potential full-feature reference. Let S_r(u,v)=integral f(z)c_u(z)c_v(z)/J_z(r)dz, zero for J0. For mu-a.e.u in the actual r prefix,

 integral_prefix S_r(u,v)dmu(v)=integral f(z)c_u(z)1{J_z(r)>0}dz=m_u.

The zero-J exception vanishes by positive Tonelli: integral_prefix c_u(z)dmu(u)=J_z(r)0 there. Thus no pointwise assertion for exceptional receiver u or source atoms is needed. S is measurable, nonnegative and integrable on the actual pair feature measure. For a FIXED bounded real measurable theta(u), independent of r, set h_theta=sqrt(S_r)(theta_u sqrt(m_u)+theta_v sqrt(m_v))/2 and psi(u)=-theta(u)^2. Positivity/symmetry and the marginal identity give EXACTLY

 ||h_theta||²+integral_E psi q=-1/4 integral ell dmu_udmu_v S_r(u,v)[theta_u sqrt(m_u)-theta_v sqrt(m_v)]²<=0.

The final diagonal uses the inclusive ell tail R(u)^(-n): integral ell1{R(u)<=r}theta_u²m_u²dmu(u)=integral theta_u²q(u)du. This requires the same theta across r; a scale-dependent theta would need a different receiver potential. Bounded theta, finite E and bounded m make h finite-energy and signed psi in L1(E). No high-only restriction may be inserted into S/marginal while claiming it still equals m_u.

This is a FULL-feature reference. Applying it to B_H uses the R330 completion source bill ONCE, unless a separate high-feature proof is supplied. Its remaining pointwise certificate is the actual defect a_H+T*(theta²)-2Phi*h_theta<=c, with root c still unproved. The nonpositive receiver bill alone is not a source-root estimate. Reference f in S is fixed; comparison sources g with Tg=q do not recompute it or the original field.

(B) Positive high-only truncated reference. Use the HIGH-only R329 feature 1_Y c_uc_v/sqrt(J_y), not the completed full feature. Retain original active pairs and j_*=essinf J over their common high region. For T>=H set Dpair=max(j_*,T), h_T=(m_u+m_v)active/(4sqrt(Dpair)). For a.e. high row with H<=J<T, all its active captured pairs have j_*<=J<T, so per-clock coverage is EXACTLY V sqrt(J/T). For J>=T, denominator Dpair<=J gives coverage AT LEAST V. Hence the original high-row defect is at most

 R_H,T=integral ell integral g 1{H<=J<T} V(1-sqrt(J/T))
      =integral_H^T [L_t(g)-L_H(g)]/(2sqrt(Tt)) dt,

 where L_t=integral ell1{J<t}Vg is the original STRICT low-row coefficient. All H/physical atoms remain in this identity; the t-integral equality convention is irrelevant on a zero dt set. OriginalH is not raised. Using the already proved L_t<=lambda t||g||1 gives

 R_H,T<=lambda/3 [T-H^(3/2)/sqrt(T)]||g||1-(1-sqrt(H/T))L_H(g).

The squared high-Gram tangent therefore yields B_H<=||h_T||²+R_H,T, with NO lambda H completion fee: only the high-only feature was used. At T=H the defect vanishes; inactive/zero rows are defined0. This is an alternative whole-slot bound, not an addition to full-feature completion or already-paid crossing fees. Actual active-pair norm still has no general root/small-X estimate. No general-soft A symmetry or source-density cap is inferred. Await final author proofs.

## 5. Author clipping proof and actual numeric implementation comparison

Read complete /tmp/r331_aux.md after the independent screen. PASS. It uses HIGH-only features, E_H>=Q_HH and the same actual active/j_* fields; therefore its particular nonnegative reference needs no generic full-completion lambda H source fee. Coverage is exactly V sqrt(J/T) on H<=J<T and at least V aboveT. The stopped-coefficient integral for R_H,T and its lambda/3 upper fee minus the original L_H credit are exact. T=H, zero/inactive rows, inclusive physical atoms and b tail are handled. C_T decreases with T, and C_T<=C_H H/T refers to the FIXED-H denominator bill, not generally C_*. Raising the original gate toT is not claimed equivalent; the two total bounds are not ordered for free. The remaining C_T norm has no general root/output price. Author1062 Decimal70/tolerance1e-58 tests are noninterval finite-incidence diagnostics; the reviewer did not replay them.

Read /tmp/r331_numeric.py/md completely. PASS actual continuum integration. inner() partitions the two-receiver interval rectangle by all vertical/horizontal kernel-face/source-cut equalities ±cut±radius/2 and diagonal endpoint/overlap switch lines u-v=±(r+s)/2,±|r-s|/2. On each resulting convex polygon, the clipped source overlap p and full overlap q are affine (including0 pieces). Its triangle formula Area[(sum p)(sum q)+sum p_i q_i]/12 is exact. Cells outside full-overlap support contribute0. This directly handles the source-window position dependence identified in section2. The cut2 comparison correctly recovers full overlap because actual kernel cubes stay within Q4.

Code retains the four shell signs AFTER tensor powers, binomial coefficient without sign copies, full-prefix cross terms, all source bins and complete z integral. It verifies sum_k S_k=Z, nonnegative bin shell products, exact zero-numerator guards before J division, and local<=true first moment. Actual profile J_k is computed from nested clipped shell volumes with the correct current radius; the analytic halfspace proof, not its finite probes alone, certifies each whole bin. Baseline Jks[n] is Jcentral. Ell includes b and its sum yields the stated full-source B_all upper bound. This does not evaluate the reciprocal integral exactly.

Notes report11934 exact checks n1,2,4,8,16, two cuts, with correct source-mass/root/history limitations. Their relative improvement factors are finite-fixture descriptions; even testedn16 leaves little absolute saving and yields no dimension exponent or general lower/upper theorem. The reviewer did not repeat the full numeric run. Reviewer617 independent preauthor checks remain separate from primary/author counts.

Current hashes:
- /tmp/r331_aux.md — fe017fc16ae7ed499823980d71749055830d5f6cdbc61d90236235ead2ca50b9
- /tmp/r331_numeric.py — c9566b2e2389952ba4cee54e20b5192cb80b86d5407eadb1291cf42a233fecb9
- /tmp/r331_numeric.md — f7aa5cc2a864da8d9e1d3d4b96c116a866a16ca259c592e8fa9c8411dc9380cb

## 6. Final general row-subcapacity core — PASS

Read /tmp/r331_core.md in full after independent section4. The extension from saturated S to any jointly measurable symmetric NONNEGATIVE row-subcapacity kernel is correct. Its actual marginal a_r(u)<=m_u is distinct from source coefficient a_H. Symmetry gives ||h_theta||²=integral ell theta²m a_r dmu-D_theta. The inclusive tail turns integral ell theta²m²dmu into integral theta²q; hence the exact identity(5) is -L_theta-D_theta. The positive slack/edge credits, bounded theta independent ofr, finite E and actual subcapacity make all terms finite and psi0=-theta² integrable. Removing a subkernel preserves feasibility but need not preserve coverage, as stated.

The escape decomposition(7) follows from binary c²=c and symmetric S: its slack plus half the S-weighted membership cut equals V-integral S c_uc_v. It is a source-position identity for actual cubes, without density/correlation assumptions. For fit-square(6), the first squared term equals the actual prefix theta² receiver mass; the second equals V-e_S. Symmetry makes its cross term exactly the feature pairing. Consequently(8) holds with the complete original -l_H credit. This does not silently change a source/receiver mask or discard the fit error.

With a common signed zeta in L1(E), condition(9) is precisely the pointwise deficit certificate and its actual receiver bill. Combining it with(5) gives a total signed bill <=epsilon X; the R330 completion source cost lambda H W_g is added ONCE in(10). All pairings obey absolute Fubini from bounded source feature norm/subcapacity and Tg=q, q<=lambda. No pointwise/source deficit of root size is established merely by the nonpositive norm-potential bill. The norm alone need not be small; the claimed advance is the legal JOINT compensation contract, not an achieved root estimate.

The Gibbs kernel(11) is a valid saturated member only because the original actual f satisfies Tf=q. The zero-J exceptional mass vanishes by joint Tonelli; the identity holds under the full ell measure including physical/terminal atoms. Its e_S formula(12) has the reverse denominator J_z, and correctly identifies an existing all-row column price; varying theta alone leaves it unchanged. The general S class may alter the cut but must preserve all real-prefix capacities and certify its simultaneous fit error/pointwise deficit. No arbitrary row/source reweighting is called a new admissible original input.

Source applicability is precise: original beta=f and nu<=f permit the positive upper bound B_H(f,nu)<=B_H(f,f), with ORIGINAL U,J,A,H frozen. The quadratic theorem thereafter concerns the SAME source g in both positions, restricted to the common feasible cone g>=0,L1,Tg=q. It is neither an identity for arbitrary unequal beta,nu nor a general-soft Gram theorem. Competing g need not realize the original history; any successful certificate bounds the entire full slot as an alternative, never an addition to its previously separated crossing/large-atom fees. No general certificate satisfying(9) at root c is constructed.

Final bounded verdict: PASS for the original uniform-shell bin normalization/formula implementation, high-only priced clipping theorem, and symmetric actual row-capacity signed-potential/defect identities. There is no completed general root budget, no exact reciprocal B_all computation in the numeric module, and no global-history/entry/outer closure. This audit does NOT include the later dyadic source-partition limit proposal, per primary instruction. No further correction is requested.

## 7. Final SHA256 bindings and execution scope

- /tmp/r331_aux.md — fe017fc16ae7ed499823980d71749055830d5f6cdbc61d90236235ead2ca50b9
- /tmp/r331_core.md — 1858c2eb422b64acc9796a53cbbac30efbe6be1fd58a9786f84ced40b9f9c227
- /tmp/r331_numeric.py — c9566b2e2389952ba4cee54e20b5192cb80b86d5407eadb1291cf42a233fecb9
- /tmp/r331_numeric.md — f7aa5cc2a864da8d9e1d3d4b96c116a866a16ca259c592e8fa9c8411dc9380cb

Execution attribution: reviewer617 exact preauthor cases are separate. Numeric author reports11934 exact continuum-fixture checks; auxiliary1062 Decimal70 tolerance diagnostics and core Decimal70 finite-incidence diagnostics are noninterval, not additional reviewer executions or literal-cube/root certificates. This reviewer read their formulas and code as stated above and did not repeat the complete runs. No final parent integration/ledger or later TeX is certified by this limited source-proof receipt.

Frozen after this append. Only /tmp/r331_audit.md was written; no Git, other-author edits, expanded dyadic task, repeated full numeric run or TeX/PDF compilation.
