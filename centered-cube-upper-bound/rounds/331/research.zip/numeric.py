#!/usr/bin/env python3
"""Exact local-J source-bin budget in the actual uniform-shell fixture."""
from fractions import Fraction as F
from functools import lru_cache
from collections import Counter
from math import comb
from pathlib import Path
import json,hashlib
C=Counter()
def ck(k,v):
 C[k]+=1
 assert v,k
def brief(x):
 if max(abs(x.numerator).bit_length(),x.denominator.bit_length())<1300:return str(x)
 a=abs(x.numerator);raw=(str(x.numerator<0)+':'+str(a.bit_length())+':').encode()+a.to_bytes((a.bit_length()+7)//8,'big')+b'/'+x.denominator.to_bytes((x.denominator.bit_length()+7)//8,'big')
 return dict(decimal=float(x),sha256=hashlib.sha256(raw).hexdigest(),encoding='negative_flag:numerator_bitlength:unsigned_numerator_bytes/unsigned_denominator_bytes')
def trap(a,b,x):return max(F(0),min(a,b,(a+b)/2-abs(x)))
def clip(poly,bound,above):
 out=[]
 for p,q in zip(poly,poly[1:]+poly[:1]):
  vp=p[0]-p[1]-bound;vq=q[0]-q[1]-bound;ip=vp>=0 if above else vp<=0;iq=vq>=0 if above else vq<=0
  if ip:out.append(p)
  if ip!=iq:
   t=vp/(vp-vq);out.append(tuple(p[j]+t*(q[j]-p[j]) for j in range(2)))
 return out
@lru_cache(None)
def total(s,t,r,v):
 if not s or not t:return F(0)
 pts=sorted(set([F(0),abs(s-t)/2,(s+t)/2,abs(r-v)/2,(r+v)/2]));out=F(0)
 for a,b in zip(pts,pts[1:]):
  f=lambda x:trap(s,t,x)*trap(r,v,x)**2
  out+=(b-a)*(f(a)+4*f((a+b)/2)+f(b))/6
 return 2*out
@lru_cache(None)
def inner(s,t,r,v,cut):
 if not s or not t:return F(0)
 xs=sorted(set([-s/2,s/2]+[p for sign in [-1,1] for e in [-r/2,r/2] if -s/2<(p:=sign*cut+e)<s/2]))
 ys=sorted(set([-t/2,t/2]+[p for sign in [-1,1] for e in [-v/2,v/2] if -t/2<(p:=sign*cut+e)<t/2]))
 ds=sorted(set([-(r+v)/2,-abs(r-v)/2,abs(r-v)/2,(r+v)/2]))
 out=F(0)
 for xa,xb in zip(xs,xs[1:]):
  for ya,yb in zip(ys,ys[1:]):
   for da,db in zip(ds,ds[1:]):
    poly=clip(clip([(xa,ya),(xb,ya),(xb,yb),(xa,yb)],da,True),db,False)
    if len(poly)<3:continue
    a=poly[0]
    for b,c in zip(poly[1:-1],poly[2:]):
     area=abs((b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0]))/2
     ps=[];qs=[]
     for u,w in [a,b,c]:
      low=max(u-r/2,w-v/2);high=min(u+r/2,w+v/2)
      ps.append(max(F(0),min(high,cut)-max(low,-cut)));qs.append(max(F(0),high-low))
     out+=area*(sum(ps)*sum(qs)+sum(p*q for p,q in zip(ps,qs)))/12
 ck('clipped_overlap_integral_bounds',0<=out<=total(s,t,r,v))
 return out

def occupation(rs,ss,n,k,cut):
 ans=[];J=F(0)
 for j,r in enumerate(rs):
  def vol(s):return trap(s,r,0)**k*trap(s,r,cut)**(n-k) if s else F(0)
  J+=(vol(ss[j])-vol(ss[j-1] if j else 0))/r**n;ans.append(J)
 return ans

def model(n,cut):
 delta=F(1,4*n);rs=[1+F(j,n) for j in range(n+1)];ss=[r-delta for r in rs];vs=[s**n-(ss[j-1]**n if j else 0) for j,s in enumerate(ss)]
 Jks=[occupation(rs,ss,n,k,cut) for k in range(n+1)];Sks=[F(0)]*(n+1);Z=F(0);local=[];old=[];prefix=[]
 for j,r in enumerate(rs):
  ck('actual_monotone_capture_upperface',ss[j]<r and (ss[j]+r)/2<2)
  row=[F(0)]*(n+1);zrow=F(0)
  for i in range(j+1):
   terms=[F(0)]*(n+1);zterm=F(0)
   for s,sign in [(ss[i],1),(ss[i-1] if i else F(0),-1)]:
    for t,sgn in [(ss[j],1),(ss[j-1] if j else F(0),-1)]:
     W=total(s,t,rs[i],r);I=inner(s,t,rs[i],r,cut);O=W-I
     if n<=2:ck('large_cut_recovers_unclipped',inner(s,t,rs[i],r,F(2))==W)
     zterm+=sign*sgn*W**n
     for k in range(n+1):terms[k]+=sign*sgn*comb(n,k)*I**k*O**(n-k)
   scale=rs[i]**n*r**n;zterm/=scale;terms=[v/scale for v in terms]
   ck('exact_source_partition_pair',sum(terms)==zterm)
   for k,v in enumerate(terms):
    ck('sourcebin_shell_pair_nonnegative',v>=0);row[k]+=(1 if i==j else 2)*v
   zrow+=(1 if i==j else 2)*zterm
  Z+=zrow;Sks=[s+v for s,v in zip(Sks,row)]
  ck('full_source_partition_prefix',sum(Sks)==Z)
  bound=F(0)
  for k in range(n+1):
   J=Jks[k][j]
   ck('local_J_guard',J>0 or Sks[k]==0)
   if J:bound+=Sks[k]/J
   # Exact geometry probes of monotonic bound; the proof is nested halfspaces.
   for shift in [F(0),F(1,2),F(1)]:
    yinner=shift*cut;youter=cut+shift*(2-cut)
    def V(s):return trap(s,r,yinner)**k*trap(s,r,youter)**(n-k) if s else F(0)
    # Prefix independently re-evaluated at an actual within-bin coordinate profile.
    val=F(0)
    for m in range(j+1):
     rm=rs[m]
     def B(s):return trap(s,rm,yinner)**k*trap(s,rm,youter)**(n-k) if s else F(0)
     val+=(B(ss[m])-B(ss[m-1] if m else 0))/rm**n
    ck('local_J_geometric_probe',0<=val<=J)
  baseline=Z/Jks[n][j];ck('local_denominator_improves_global',bound>=baseline)
  M=sum(vs[m]*rs[m]**n for m in range(j+1));ck('local_square_within_actual_first_moment',bound<=M)
  local.append(bound);old.append(baseline);prefix.append(dict(radius=str(r),local_Eall_lower=brief(bound),Jcentral_Eall_lower=brief(baseline)))
 ell=[r**(-n)-(rs[j+1]**(-n) if j<n else 0) for j,r in enumerate(rs)];X=sum(vs)
 L=sum(w*v for w,v in zip(ell,local));G=sum(w*v for w,v in zip(ell,old))
 ck('full_ell_budget_valid',0<=G<=L<=X)
 return dict(n=n,cut=str(cut),W_f=str(4**n),X=brief(X),local_square_lower=brief(L),Jcentral_square_lower=brief(G),B_all_upper=brief(X-L),BH_upper_same=brief(X-L),saving_fraction=brief(L/X),saving_decimal=float(L/X),old_saving_decimal=float(G/X),improvement_factor=float(L/G),upper_over_X=float((X-L)/X),prefixes=prefix)
def main():
 models=[];stages=[]
 for stage,ns in [('initial_independent',[1,2]),('geometry_boundary',[4,8]),('expanded',[16])]:
  before=sum(C.values())
  for n in ns:
   for cut in [F(1,2),F(1)]:models.append(model(n,cut))
  stages.append(dict(stage=stage,dimensions=ns,cuts=['1/2','1'],checks=sum(C.values())-before))
 result=dict(status='PASS',total_checks=sum(C.values()),check_counts=dict(C),stages=stages,models=models,scope='Exact full beta/nu tensor bin moments, local-J upper bounds and true fixed-fixture budget upper. No point sampling replaces source integrals; finite J probes supplement the analytic nested-halfspace proof. No full history or root bound.')
 Path(__file__).with_suffix('.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n');print(json.dumps({k:result[k] for k in ['status','total_checks','check_counts','stages']},sort_keys=True))
if __name__=='__main__':main()
