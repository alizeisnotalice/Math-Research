#!/usr/bin/env python3
"""R76: standard-library certificates for the specified near-vertex subevent U.

Explicit subsets are enumerated only for n=2,3,4. Larger product cubes are
implicit mathematical models; their 2**n vertices are never materialized.
This is a fullness-obstruction diagnostic on U, not a full-band counterexample.
"""
from fractions import Fraction as F
from functools import lru_cache
from collections import Counter
from pathlib import Path
import hashlib, json, math, random, time

BITS=100
LOG_TERMS=30


def clean(x):
    if isinstance(x,F): return str(x)
    if isinstance(x,dict): return {str(k):clean(v) for k,v in x.items()}
    if isinstance(x,(tuple,list)): return [clean(v) for v in x]
    return x


@lru_cache(None)
def log_unit_interval(x):
    """Exact atanh series on [1,2], positive rational remainder bound."""
    x=F(x); assert 1<=x<=2
    z=(x-1)/(x+1); power=z; total=F(0)
    for j in range(LOG_TERMS):
        total+=2*power/(2*j+1); power*=z*z
    remainder=2*power/((2*LOG_TERMS+1)*(1-z*z))
    return total,total+remainder


@lru_cache(None)
def log_interval(x):
    x=F(x); assert x>0
    shifts=0
    while x<1: x*=2; shifts-=1
    while x>=2: x/=2; shifts+=1
    a,b=log_unit_interval(x); l,u=log_unit_interval(F(2))
    return (a+shifts*l,b+shifts*u) if shifts>=0 else (a+shifts*u,b+shifts*l)


def multiply_interval(w,iv):
    return (w*iv[0],w*iv[1]) if w>=0 else (w*iv[1],w*iv[0])


def sum_intervals(intervals):
    ans=[F(0),F(0)]
    for a,b in intervals: ans[0]+=a; ans[1]+=b
    return tuple(ans)


D0=sum_intervals([multiply_interval(F(2,3),log_interval(F(4,3))),multiply_interval(F(1,3),log_interval(F(2,3)))])
assert D0[0]>0


@lru_cache(None)
def root_interval(s,k,bits=BITS):
    """Bracket s**(1/k), 100 rational bisections on [0,1]."""
    s=F(s); assert 0<=s<=1 and k>=1
    if s in (0,1) or k==1: return s,s
    lo,hi=F(0),F(1)
    for _ in range(bits):
        mid=(lo+hi)/2
        if mid**k<=s: lo=mid
        else: hi=mid
    assert lo**k<=s<=hi**k and hi-lo==F(1,2**bits)
    return lo,hi


@lru_cache(None)
def q_power(s,k):
    s=F(s); a,b=root_interval(s,k)
    return s*a,s*b


@lru_cache(None)
def divergence_interval(theta):
    theta=F(theta); terms=[]
    for z in (theta,1-theta):
        if z: terms.append(multiply_interval(z,log_interval(2*z)))
    return sum_intervals(terms)


@lru_cache(None)
def signature_entropy(n,size,biases):
    """biases are absolute integer 2*c_j-size; sign symmetry is exact."""
    p=F(size,2**n); h=sum(3*b>size for b in biases)
    rhs=log_interval(1/p)
    div=sum_intervals([divergence_interval(F(size+b,2*size)) for b in biases])
    # A uniform product packet is exactly a subcube: all coordinates either
    # fixed or balanced and size=2**number_balanced. Symbolic equality prevents
    # interval uncertainty from being misreported as an entropy proof.
    fixed=sum(b==size for b in biases); balanced=sum(b==0 for b in biases)
    product=(fixed+balanced==n and size==2**balanced)
    subadditivity_margin=rhs[0]-div[1]
    subadditivity_certified=product or subadditivity_margin>=0
    goodness_margin=rhs[0]-h*D0[1]
    goodness_certified=goodness_margin>=0
    return dict(p=p,good_coordinate_count=h,product_subcube=product,
                log_inverse_mass=rhs,sum_coordinate_divergences=div,
                subadditivity_residual_lower=subadditivity_margin,
                subadditivity_status='symbolic_product_equality' if product else ('rational_interval_certified' if subadditivity_certified else 'NOT_CERTIFIED'),
                goodness_residual_lower=goodness_margin,
                goodness_status='rational_interval_certified' if goodness_certified else 'NOT_CERTIFIED')


@lru_cache(None)
def signature_score(n,size,biases,k,fullness=True):
    # Exactly one sign can pass strict theta>2/3 at a coordinate.
    terms=[]
    for b in biases:
        if not fullness or 3*b>size:
            majority_count=(size+b)//2
            terms.append(q_power(F(majority_count,2**(n-1)),k))
    a,b=sum_intervals(terms)
    return a/(2*n),b/(2*n)


def simplex(coeff,N):
    masks=list(coeff); K=len(masks); total=K+N
    rows=[[F(bool(m>>i&1)) for m in masks]+[F(j==i) for j in range(N)]+[F(1)] for i in range(N)]
    reduced=[coeff[m] for m in masks]+[F(0)]*N; basis=list(range(K,total)); value=F(0); pivots=0
    while True:
        eligible=[j for j,z in enumerate(reduced) if z>0]
        if not eligible: break
        entering=max(eligible,key=lambda j:(reduced[j],-j))
        eligible=[i for i,row in enumerate(rows) if row[entering]>0]; assert eligible
        leaving=min(eligible,key=lambda i:tuple([rows[i][-1]/rows[i][entering]]+[z/rows[i][entering] for z in rows[i][K:K+N]]))
        row=rows[leaving]; pivot=row[entering]; row=[z/pivot for z in row]; rows[leaving]=row
        for i in range(N):
            if i!=leaving and rows[i][entering]:
                factor=rows[i][entering]; rows[i]=[a-factor*b for a,b in zip(rows[i],row)]
        factor=reduced[entering]; value+=factor*row[-1]; reduced=[a-factor*b for a,b in zip(reduced,row[:-1])]; basis[leaving]=entering; pivots+=1
        assert pivots<10000
    primal={m:F(0) for m in masks}
    for i,b in enumerate(basis):
        if b<K: primal[masks[b]]=rows[i][-1]
    dual=[-reduced[K+i] for i in range(N)]
    loads=[sum(primal[m] for m in masks if m>>i&1) for i in range(N)]
    slacks=[sum(dual[i] for i in range(N) if m>>i&1)-coeff[m] for m in masks]
    assert all(z>=0 for z in primal.values()) and all(z>=0 for z in dual) and all(z<=1 for z in loads) and all(z>=0 for z in slacks)
    assert sum(coeff[m]*primal[m] for m in masks)==value==sum(dual)
    return dict(value=value,primal={m:z for m,z in primal.items() if z},dual=dual,loads=loads,
                min_dual_slack=min(slacks),pivots=pivots,exact_primal_dual_equality=True)


def vertex(label,n): return tuple(F(1 if label>>j&1 else -1) for j in range(n))


def actual_winner(vertices,x):
    events={}; N=len(vertices); n=len(x)
    for i,y in enumerate(vertices):
        radius=max(abs(a-b) for a,b in zip(x,y)); events.setdefault(radius,[]).append(i)
    best=F(0); captured=[]; stages=[]
    for r,ids in sorted(events.items()):
        captured.extend(ids); density=F(len(captured),N)/(2*r)**n
        stages.append(dict(radius=r,entering_count=len(ids),capture_count=len(captured),density=density))
        if density>best: best=density; chosen=(r,tuple(captured))
    return dict(radius=chosen[0],captured=chosen[1],density=best,stages=stages)


def geometry_small(n):
    eps=F(1,100*n); lam=F(3,4)*F(1,2)/(2*(1+3*eps))**n
    vertices=[vertex(i,n) for i in range(2**n)]; records=[]
    for j in range(n):
        for sigma in (-1,1):
            for a in (F(2)+2*eps,F(2)+F(5,2)*eps,F(2)+3*eps):
                x=[eps*(1 if l%2 else -1) for l in range(n)]; x[j]=sigma*a
                r=actual_winner(vertices,tuple(x)); expected=tuple(i for i in range(2**n) if (1 if i>>j&1 else -1)==sigma)
                assert len(r['stages'])==2 and all(s['entering_count']==2**(n-1) for s in r['stages'])
                assert r['radius']==a-1 and r['captured']==expected and lam<r['density']<=2*lam
                c=tuple(F(sigma) for _ in range(n))
                assert max(abs(xx-cc) for xx,cc in zip(x,c))<=r['radius']
                plus_gate=max(abs(xx-1) for xx in x)<=r['radius']
                minus_gate=max(abs(xx+1) for xx in x)<=r['radius']
                assert plus_gate==(sigma==1) and minus_gate==(sigma==-1)
                records.append(dict(j=j,sigma=sigma,x=x,winner=r,density_over_lambda=r['density']/lam,
                                    physical_vertex_gate_verified=True,all_plus_representative_gate=plus_gate,all_minus_representative_gate=minus_gate))
    band_min=F(4,3)
    band_max=F(4,3)*((1+3*eps)/(1+2*eps))**n
    assert 1<band_min<=band_max<2
    # Equal integrals follow coordinate/sign symmetry, not sample averaging.
    return dict(n=n,epsilon=eps,lambda_value=lam,records=records,
                band_ratio_bounds=[band_min,band_max],all_U_band_by_exact_extrema=True,
                equal_U_integrals_reason='Coordinate permutations and sign reflections preserve M and Lebesgue measure.',
                normalized_physical_whole_packet_score=F(1,2),physical_witness='alpha_whole=1, c=(1,...,1); all positive-sign U gates, all negative-sign U fails.')


def partition_interval(n,kfix,kroot):
    assert 1<=kfix<=n
    base=F(1,2**(kfix-1)); a,b=root_interval(base,kroot)
    return F(kfix,n)*a,F(kfix,n)*b


def enumerate_small(n,kroot=2):
    N=2**n; signs=[sum(1<<i for i in range(N) if i>>j&1) for j in range(n)]
    signatures=Counter(); representatives={}; lower={}; upper={}; physlo={}; physhi={}; bestlo=F(0); besthi=F(0); bestmask=None
    for mask in range(1,1<<N):
        size=mask.bit_count(); biases=tuple(sorted(abs(2*(mask&pm).bit_count()-size) for pm in signs))
        signature=(size,biases); signatures[signature]+=1; representatives.setdefault(signature,mask)
        score=signature_score(n,size,biases,kroot)
        p=F(size,N); lo,hi=score[0]/p,score[1]/p
        if lo>bestlo: bestlo=lo; bestmask=mask
        besthi=max(besthi,hi)
        if n<=3:
            lower[mask],upper[mask]=score
            physlo[mask],physhi[mask]=signature_score(n,size,biases,kroot,False)
    entropy=[]; failures=[]
    for (size,biases),multiplicity in sorted(signatures.items()):
        e=signature_entropy(n,size,biases)
        if e['subadditivity_status']=='NOT_CERTIFIED' or e['goodness_status']=='NOT_CERTIFIED': failures.append((size,biases))
        entropy.append(dict(size=size,absolute_bias_numerators=biases,multiplicity=multiplicity,representative_mask=representatives[(size,biases)],certificate=e))
    assert not failures
    partitions=[dict(fixed_coordinates=j,packet_mass=F(1,2**j),packet_count=2**j,score_interval=partition_interval(n,j,kroot)) for j in range(1,n+1)]
    out=dict(n=n,N=N,t=F(1,kroot),q=1+F(1,kroot),all_nonempty_subsets=(1<<N)-1,
             enumeration='Every subset mask 1..2**N-1; coordinate counts from exact bit_count.',
             entropy_signature_count=len(signatures),entropy_signature_certificates=entropy,
             entropy_all_subsets_certified=True,partition_certificates=partitions,
             maximum_packet_score_over_mass_interval=[bestlo,besthi],best_ratio_packet_mask=bestmask,
             full_capacity_optimum_interval_by_translation_orbit=[bestlo,besthi],
             translation_orbit_certificate=dict(primal='All 2**n XOR translations of a maximizing packet, each alpha=1/|P|, counting repetitions.',source_load=F(1),dual_per_atom_upper=besthi/N,
               justification='Sign translation permutes the 2n receiver signs, preserves each packet coefficient; each atom appears |P| times.'),
             LP_enumerated=(n<=3),LP_fullness=None,LP_physical_vertex_library=None)
    if n<=3:
        loLP=simplex(lower,N); hiLP=simplex(upper,N)
        assert loLP['value']==bestlo and hiLP['value']==besthi
        out['LP_fullness']=dict(lower=loLP,upper=hiLP,coefficient_root_brackets=True)
        plo=simplex(physlo,N); phi=simplex(physhi,N)
        assert plo['value']>=F(1,2)
        out['LP_physical_vertex_library']=dict(lower=plo,upper=phi,whole_packet_lower=F(1,2))
    return out


def explicit_packet(n,labels,name,seed=None):
    labels=sorted(set(labels)); size=len(labels); assert size>0
    counts=[sum(i>>j&1 for i in labels) for j in range(n)]
    biases=tuple(sorted(abs(2*c-size) for c in counts)); cert=signature_entropy(n,size,biases)
    assert cert['subadditivity_status']!='NOT_CERTIFIED' and cert['goodness_status']!='NOT_CERTIFIED'
    digest=hashlib.sha256(','.join(map(str,labels)).encode()).hexdigest()
    return dict(n=n,name=name,seed=seed,explicit_packet_cardinality=size,implicit_universe_cardinality=2**n,
                coordinate_plus_counts=counts,absolute_bias_numerators=biases,labels_sha256=digest,entropy=cert,
                labels=labels if size<=128 else None,enumerated_full_universe=False)


def larger_packets():
    result=[]
    for n in (6,8,12):
        # This stage explicitly loops over the bounded universe, at most 4096.
        N=2**n
        result.append(explicit_packet(n,[i for i in range(N) if i&3==3],'subcube_first_two_plus'))
        result.append(explicit_packet(n,[i for i in range(N) if i.bit_count()>n//2],'strict_hamming_majority'))
        seed=760000+n; rng=random.Random(seed)
        result.append(explicit_packet(n,rng.sample(range(N),min(128,N//2)),'uniform_random_128',seed))
        result[-1]['enumerated_full_universe']=False
        for row in result[-3:-1]: row['enumerated_full_universe']=True; row['full_universe_loop_size']=N
    for n in (16,32):
        seed=760000+n; rng=random.Random(seed)
        result.append(explicit_packet(n,rng.sample(range(2**n),128),'uniform_random_128',seed))
        seed=761000+n; rng=random.Random(seed)
        # Four fixed plus coordinates, sampled on the remaining product cube.
        labels=[(i<<4)|15 for i in rng.sample(range(2**(n-4)),128)]
        result.append(explicit_packet(n,labels,'random_128_with_four_fixed_plus',seed))
    return result


def exp_one_interval(terms=40):
    total=F(0); factorial=1
    for j in range(terms+1):
        if j: factorial*=j
        total+=F(1,factorial)
    # Tail first term, subsequent ratios <=1/(terms+2).
    first=F(1,factorial*(terms+1)); remainder=first/(1-F(1,terms+2))
    return total,total+remainder


def implicit_products():
    e=exp_one_interval(); ans=[]
    for k in (2,3,4,8,16,32,64,128):
        n=k*k; t=F(1,k); eps=F(1,100*n)
        bestlower=F(0); bestupper=F(0); bestfix=None
        # Find the maximizer among all kfix=1..n without large integers or roots:
        # ratio successive values is (j+1)/j * 2**(-1/k).
        # Integer-power comparison certifies which side of 1 this lies on.
        j=1
        while j<n and (j+1)**k>2*j**k: j+=1
        optimum_candidates=sorted(set([max(1,j-1),j,min(n,j+1)]))
        records=[]
        for fixed in sorted(set([1,k,*optimum_candidates])):
            iv=partition_interval(n,fixed,k)
            assert iv[0]>0 and iv[0]<=iv[1]
            records.append(dict(fixed_coordinates=fixed,score_interval=iv,scaled_by_sqrt_n_interval=[k*iv[0],k*iv[1]],packet_mass_exponent=-fixed,packet_count_power_two=fixed))
            if fixed in optimum_candidates:
                if iv[0]>bestlower: bestlower=iv[0]; bestfix=fixed
                bestupper=max(bestupper,iv[1])
        numerator=root_interval(F(1,2),k) # 2**t = 1/(2**(-t)).
        bound=(F(1)/(numerator[1]*e[1]*D0[1]*n*t),F(1)/(numerator[0]*e[0]*D0[0]*n*t))
        assert numerator[0]>0 and D0[0]>0
        # Binomial(n,l)<=n**l gives (1+delta)**n<=1/(1-n*delta),
        # delta=1/(100n+2). Retain a short exact certificate instead of emitting
        # a numerator and denominator with O(n log n) decimal digits.
        bandmax=F(4,3)*F(100*n+2,99*n+2)
        assert F(4,3)<bandmax<2
        sqrtmatched=partition_interval(n,k,k)
        # Since 2**(-(k-1)/k)>=1/2, fixing k gives >=1/(2sqrt(n)).
        assert sqrtmatched[0]>=F(1,2*k)
        ans.append(dict(n=n,sqrt_n=k,t=t,epsilon=eps,universe='implicit uniform product on {+1,-1}^n; no vertices materialized',
                        vertex_count_power_two=n,subcube_formula='(fixed/n)*2**(-(fixed-1)/sqrt_n)',
                        checked_partitions=records,all_fixed_coordinate_counts_optimized_by_exact_ratio=True,
                        ratio_test='(fixed+1)^sqrt_n > 2*fixed^sqrt_n',
                        optimum_partition_interval=[bestlower,bestupper],best_fixed_coordinates=bestfix,
                        analytic_fullness_capacity_bound_interval=bound,
                        global_fullness_capacity_upper=bound[1],
                        fullness_upper_less_than_physical_witness=bound[1]<F(1,2),
                        matched_order_lower=F(1,2*k),physical_whole_packet_lower=F(1,2),
                        U_band_ratio_bounds=[F(4,3),bandmax],all_U_band_by_exact_extrema=True,
                        band_upper_enclosure='(4/3)*(1+1/(100n+2))**n <= (4/3)*(100n+2)/(99n+2) < 2'))
    return dict(e_interval=e,d0_interval=D0,root_bits=BITS,models=ans)


def main():
    start=time.monotonic(); geometry=[]; small=[]
    for n in (2,3,4):
        geometry.append(geometry_small(n)); small.append(enumerate_small(n))
        print('small n',n,'subsets',small[-1]['all_nonempty_subsets'],'signatures',small[-1]['entropy_signature_count'],'seconds',round(time.monotonic()-start,2),flush=True)
    large=larger_packets(); implicit=implicit_products()
    out=dict(status='VERIFIED',scope='Specified near-vertex subevent U only: fullness packets versus physical whole-packet witness. Not a full-band or actual soft-branch counterexample.',
             dependencies='Python standard library only',arithmetic='Fraction; rational atanh-log remainder enclosures, Taylor e enclosure, rational roots, exact LP primal/dual',
             normalized_receiver_model='Each of 2n U_j,sigma has equal integral of M; scores divided by T=integral_U M.',
             fullness_gate='theta>2/3 strictly; sigma*m_j>1/3; posterior pi=2p*theta',
             small_t_note='n=2,3,4 exhaustive LP/subset diagnostics use rational t=1/2. Square-dimension implicit models use target t=1/sqrt(n) exactly.',
             entropy_constant=dict(formula='d0=(2/3)log(4/3)+(1/3)log(2/3)',interval=D0,positive_certified=True,log_terms=LOG_TERMS,
                                   log_remainder='2*z**(2L+1)/((2L+1)*(1-z*z)), z=(x-1)/(x+1), x reduced to [1,2) with exact log2 intervals'),
             geometry=geometry,all_subsets=small,larger_explicit_packets=large,implicit_product_models=implicit,
             counts=dict(actual_geometry_rows=sum(len(g['records']) for g in geometry),exhaustive_nonempty_subsets=sum(s['all_nonempty_subsets'] for s in small),
                         exact_LPs=8,larger_explicit_packets=len(large),implicit_square_dimensions=len(implicit['models'])),
             limitations=['Near-subevent U is not the entire beta=2 band.', 'No claim against the complete physical or soft branch.',
                          'Large product dimensions use closed-form certificates, not enumeration of 2**n atoms.',
                          'Small n2,n3 use t=1/2 rather than irrational 1/sqrt(n).'])
    target=Path(__file__).with_name('majority_results.json'); target.write_text(json.dumps(clean(out),indent=2,sort_keys=True)+'\n')
    print('DONE',out['counts'],'seconds',round(time.monotonic()-start,2),'bytes',target.stat().st_size,flush=True)


if __name__=='__main__': main()
