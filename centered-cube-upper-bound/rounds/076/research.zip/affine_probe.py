#!/usr/bin/env python3
"""R76 actual E2 finite-domain affine-gate exploration.
Exact LP certificates apply ONLY to archived rationalized floating coefficients.
Actual phi quadrature and integration are diagnostics, not interval certificates.
All source subsets, representatives, fees, selectors and domains are registered.
"""
from fractions import Fraction as Q
from pathlib import Path
from functools import lru_cache
import math,itertools,random,json,time,argparse,hashlib
SCALES=(Q(1),Q(5,4),Q(3,2),Q(7,4),Q(2))
GRID=1<<40

def clean(o):
    if isinstance(o,Q):return str(o)
    if isinstance(o,dict):return {str(k):clean(v) for k,v in o.items()}
    if isinstance(o,(list,tuple)):return [clean(v) for v in o]
    return o

def determinant(a):
    a=[list(map(Q,r)) for r in a];v=Q(1);n=len(a)
    for j in range(n):
        k=next((i for i in range(j,n) if a[i][j]),None)
        if k is None:return Q(0)
        if k!=j:a[j],a[k]=a[k],a[j];v=-v
        z=a[j][j];v*=z
        for i in range(j+1,n):
            f=a[i][j]/z
            for k in range(j+1,n):a[i][k]-=f*a[j][k]
    return v

def fee(b):return 1+sum((max(Q(0),abs(v)-Q(1,2)) for v in b),Q(0))/len(b)

def hull2(points):
    points=sorted(set(points))
    def cross(a,b,c):return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
    lo=[];hi=[]
    for p in points:
        while len(lo)>1 and cross(lo[-2],lo[-1],p)<=0:lo.pop()
        lo.append(p)
    for p in reversed(points):
        while len(hi)>1 and cross(hi[-2],hi[-1],p)<=0:hi.pop()
        hi.append(p)
    p=lo[:-1]+hi[:-1]
    return abs(sum(p[i][0]*p[(i+1)%len(p)][1]-p[i][1]*p[(i+1)%len(p)][0] for i in range(len(p))))/2

def geometry_guard():
    counts=dict(exact_interval_hull=0,exact_polygon_hull=0,exact_visible_face_simplex=0,homothetic_containment=0)
    values=[Q(-3),Q(-1),Q(-1,2),Q(0),Q(1,2),Q(3,4),Q(2)]
    for v in values:
        length=max(Q(0),v+Q(1,2))-min(Q(0),v-Q(1,2))
        assert length==fee((v,));counts['exact_interval_hull']+=1
    for b in itertools.product(values,repeat=2):
        vertices=[(b[0]+s,b[1]+t) for s,t in itertools.product((Q(-1,2),Q(1,2)),repeat=2)]
        assert hull2([(Q(0),Q(0))]+vertices)==fee(b);counts['exact_polygon_hull']+=1
    for n in (2,3,4):
        for b in [(Q(2),)*n,tuple(Q((-1)**i*(i+1),2) for i in range(n)),(Q(1,4),)*n]:
            extra=Q(0)
            for axis in range(n):
                if abs(b[axis])<=Q(1,2):continue
                side=-1 if b[axis]>0 else 1;other=[i for i in range(n) if i!=axis]
                for order in itertools.permutations(other):
                    v=[b[i]-Q(1,2) for i in range(n)];v[axis]=b[axis]+side*Q(1,2);vertices=[v[:]]
                    for i in order:v[i]+=1;vertices.append(v[:])
                    extra+=abs(determinant(vertices))/math.factorial(n);counts['exact_visible_face_simplex']+=1
            assert 1+extra==fee(b)
    for n in (1,2,3,4,8):
        b=tuple(Q((-1)**i*(i+1),3) for i in range(n))
        for L,r in itertools.product(SCALES,(Q(0),Q(1,3),Q(1))):
            z=tuple(r*L*(b[i]+Q((-1)**i,2)) for i in range(n))
            # z belongs to L conv(0,b+[-1/2,1/2]^n), witnessed by r.
            assert all(abs(z[i]/(r*L)-b[i])<=Q(1,2) for i in range(n)) if r else all(v==0 for v in z)
            counts['homothetic_containment']+=1
    return dict(status='PASS',counts=counts,scope='Exact rational hull/visible-face-volume checks; no kernel quadrature certification.')

@lru_cache(maxsize=200000)
def phi(x,panels=256):
    x=abs(float(x))
    def f(t):
        if not t:return 0.
        if x>=.5:return t*math.exp(-((x-.5)/t))*(-math.expm1(-1/t))
        return t*(2-math.exp(-(.5-x)/t)-math.exp(-(.5+x)/t))
    return (f(0)+f(1)+sum((4 if j%2 else 2)*f(j/panels) for j in range(1,panels)))/(3*panels)

def kernels(n,delta,z,panels):
    h=[float(abs(v)<=Q(1,2)) for v in z];p=[phi(float(v),panels) for v in z]
    # D computed from endpoint products; K and J retain their exact mask definition.
    aa=math.prod((1-delta/2)*h[i]+delta/2*p[i] for i in range(n));bb=math.prod((1-delta)*h[i]+delta*p[i] for i in range(n))
    K=J=0.
    for mask in range(1<<n):
        s=mask.bit_count();a=(delta/2)**s*(1-delta/2)**(n-s);b=delta**s*(1-delta)**(n-s);q=(a+b)/2
        prod=math.prod(p[i] if mask>>i&1 else h[i] for i in range(n));K+=q*prod;J+=(a-b)**2/q*prod if q else 0.
    return K,J,aa-bb

def evaluate(src,x,panels=256):
    n=src['n'];delta=float(src['delta']);rows=[]
    for L in src['scales']:
        uK=[];uJ=[];T=0.
        for y,p in zip(src['y'],src['p']):
            z=tuple((x[i]-y[i])/L for i in range(n));K,J,D=kernels(n,delta,z,panels);factor=float(p)/float(L)**n
            uK.append(factor*K);uJ.append(factor*J);T+=factor*D
        F=sum(uK);C=sum(uJ)
        assert F>0 and C>=0 and C/F<=4+1e-12
        assert T*T/(F*C)<=1+1e-12 if C else T==0
        rows.append(dict(L=L,F=F,C=C,T=T,uK=uK,uJ=uJ))
    return rows

def fixture(name,n,y,weights,domain,lam,B=4,groups=None,slopes=None,scales=SCALES):
    weights=list(map(Q,weights));p=[w/sum(weights) for w in weights];y=[tuple(map(Q,z)) for z in y]
    return dict(name=name,n=n,y=y,p=p,weights=weights,delta=Q(1,max(n,2)),domain=domain,lam=float(lam),B=B,groups=groups or [],extra_slopes=slopes or [],scales=scales)

def fixtures(pilot=False):
    out=[]
    for n in (1,2,3,4):
        if n==1:y=[(Q(j,16),) for j in (-3,-1,1,3)]
        else:
            bits=list(itertools.product((-1,1),repeat=min(n,3)))
            y=[tuple(Q(s,8) for s in (b if n<=3 else b+(math.prod(b),))) for b in bits]
        out.append(fixture('near_box_grid_n'+str(n),n,y,[1]*len(y),dict(kind='box',lo=Q(-2),hi=Q(2)),.015,B=8))
    for n in (2,4):
        y=[tuple(Q(c)+Q((-1)**(i+j),16) for i in range(n)) for c in (-Q(3,2),Q(0),Q(3,2)) for j in range(2)]
        out.append(fixture('correlated_three_groups_n'+str(n),n,y,[1,2,2,4,4,8],dict(kind='tube',lo=Q(-3),hi=Q(3),halfwidth=Q(1,4)),.004,B=8,groups=[[0,1],[2,3],[4,5]]))
    for R in (8,24):
        n=2;N=8;y=[(Q(i*2-7,16384),Q((i*3)%8*2-7,16384)) for i in range(N)]
        slopes=[(Q(R*j,12),Q(R*(6-j),12)) for j in range(2,5)]
        out.append(fixture('actual_tail_strip_R'+str(R),n,y,[1]*N,dict(kind='strip',R=Q(R),width=Q(1,100)),.04*phi(R/4,1024)**2,B=2,slopes=slopes))
    # Added after initial pressure to test actual scale tracking in a one-sided
    # subdomain. The large fixed B is disclosed; this is not a modest-B result.
    for n in (1,2):
        y=[(Q(j,64),)*n for j in (-3,-1,1,3)]
        out.append(fixture('one_sided_scale_tracking_n'+str(n),n,y,[1]*4,dict(kind='box',lo=-Q(3,64),hi=Q(7,4)),.001,B=1024))
    return out[:3] if pilot else out

def library(src):
    n=src['n'];anchors=list(src['y']);anchors.append(tuple((min(y[i] for y in src['y'])+max(y[i] for y in src['y']))/2 for i in range(n)))
    for g in src['groups']:anchors.append(tuple((min(src['y'][j][i] for j in g)+max(src['y'][j][i] for j in g))/2 for i in range(n)))
    anchors=list(dict.fromkeys(anchors));slopes=[(Q(0),)*n]
    for i in range(n):
        for v in (-2,-1,-Q(1,2),Q(1,2),1,2):slopes.append(tuple(Q(v) if j==i else Q(0) for j in range(n)))
    for v in (-2,-1,-Q(1,2),Q(1,2),1,2):slopes.append((Q(v),)*n)
    slopes=list(dict.fromkeys(slopes+src['extra_slopes']))
    affine=[dict(a=a,b=b,fee=fee(b)) for a in anchors for b in slopes]
    fixed_positions=list(dict.fromkeys(tuple(a[i]+L*b[i] for i in range(n)) for a in anchors for b in slopes for L in src['scales']))
    fixed=[dict(a=c,b=(Q(0),)*n,fee=Q(1)) for c in fixed_positions]
    # Augmented affine class contains the entire fair fixed baseline.
    registered={(r['a'],r['b']):r for r in fixed+affine}
    return fixed,list(registered.values())

def draw(src,S,seed):
    rng=random.Random(seed);d=src['domain'];n=src['n'];rows=[]
    if d['kind']=='box':volume=(d['hi']-d['lo'])**n
    elif d['kind']=='tube':volume=(d['hi']-d['lo'])*(2*d['halfwidth'])**(n-1)
    else:volume=d['R']/3*d['width']
    for _ in range(S):
        U=lambda:Q.from_float(rng.random())
        if d['kind']=='box':x=tuple(d['lo']+(d['hi']-d['lo'])*U() for i in range(n))
        elif d['kind']=='tube':
            z=d['lo']+(d['hi']-d['lo'])*U();x=(z,)+tuple(z+(2*U()-1)*d['halfwidth'] for i in range(n-1))
        else:
            z=d['R']/3*(1+U());x=(z,d['R']-z+d['width']*U())
        rows.append(dict(x=x,scales=evaluate(src,x),volume=volume))
    return rows

def selected(src,row,selector):
    crossing=[v for v in row['scales'] if abs(v['T'])>src['lam']]
    if not crossing:return None
    if selector=='first_crossing':return crossing[0]
    return max(row['scales'],key=lambda v:abs(v['T']))

def event_rows(src,rows,selector,branch):
    out=[]
    for row in rows:
        v=selected(src,row,selector)
        if v is None:continue
        if branch=='low':flag=v['F']<=src['B']*src['lam'];u=v['uJ'];G=v['C']
        else:flag=src['B']*src['lam']<v['F']<=2*src['B']*src['lam'];u=v['uK'];G=v['F']
        if flag and G>0:out.append(dict(x=row['x'],L=v['L'],F=v['F'],C=v['C'],T=v['T'],posterior=[z/G for z in u],weight=G/src['lam']*float(row['volume'])/len(rows)))
    return out

def gate(rep,row):return all(abs(row['x'][i]-rep['a'][i]-row['L']*rep['b'][i])<=row['L']/2 for i in range(len(rep['a'])))

def coefficients(rows,reps,N,q,ignore_fee=False,singletons=False):
    K=(1<<N)-1;values=[]
    for row in rows:
        p=row['posterior'];s=[0.]*(K+1)
        for m in range(1,K+1):bit=m&-m;s[m]=s[m^bit]+p[bit.bit_length()-1]
        values.append([row['weight']*min(1.,s[m])**q for m in range(K+1)])
    patterns={}
    for rid,rep in enumerate(reps):
        ix=tuple(i for i,r in enumerate(rows) if gate(rep,r));f=Q(1) if ignore_fee else rep['fee']
        if ix not in patterns or f<patterns[ix][0]:patterns[ix]=(f,rid)
    best=[0.]*(K+1);chosen=[-1]*(K+1)
    for ix,(f,rid) in patterns.items():
        z=[sum(values[i][m] for i in ix)/float(f) for m in range(K+1)]
        for m in range(1,K+1):
            if z[m]>best[m]:best[m]=z[m];chosen[m]=rid
    if singletons:
        for i in range(N):
            m=1<<i;z=sum(v[m] for v in values)
            if z>best[m]:best[m]=z;chosen[m]=-2
    coeff={m:Q(math.floor(best[m]*GRID),GRID) for m in range(1,K+1)}
    return coeff,{m:chosen[m] for m in range(1,K+1)},len(patterns)

# R75 exact small-N simplex copied without the large-N floating warm-start path.
def simplex(coeff,N):
    masks=list(coeff);K=len(masks);rows=[[Q(bool(mask>>i&1)) for mask in masks]+[Q(j==i) for j in range(N)]+[Q(1)] for i in range(N)]
    reduced=[coeff[m] for m in masks]+[Q(0)]*N;basis=list(range(K,K+N));value=Q(0);pivots=0
    while True:
        candidates=[j for j,z in enumerate(reduced) if z>0]
        if not candidates:break
        entering=max(candidates,key=lambda j:(reduced[j],-j));eligible=[i for i,row in enumerate(rows) if row[entering]>0]
        assert eligible
        leaving=min(eligible,key=lambda i:tuple([rows[i][-1]/rows[i][entering]]+[z/rows[i][entering] for z in rows[i][K:K+N]]))
        row=rows[leaving];pivot=row[entering];row=[z/pivot for z in row];rows[leaving]=row
        for i in range(N):
            if i!=leaving and rows[i][entering]:
                factor=rows[i][entering];rows[i]=[a-factor*b for a,b in zip(rows[i],row)]
        factor=reduced[entering];value+=factor*row[-1];reduced=[a-factor*b for a,b in zip(reduced,row[:-1])];basis[leaving]=entering;pivots+=1;assert pivots<10000
    primal={m:Q(0) for m in masks}
    for i,b in enumerate(basis):
        if b<K:primal[masks[b]]=rows[i][-1]
    dual=[-reduced[K+i] for i in range(N)];loads=[sum(primal[m] for m in masks if m>>i&1) for i in range(N)]
    slack=[sum(dual[i] for i in range(N) if m>>i&1)-coeff[m] for m in masks]
    assert all(z>=0 for z in primal.values()) and all(0<=z<=1 for z in loads) and all(z>=0 for z in dual) and min(slack)>=0
    assert sum(coeff[m]*primal[m] for m in masks)==value==sum(dual)
    return dict(value=value,primal={m:z for m,z in primal.items() if z},dual=dual,loads=loads,min_dual_slack=min(slack),pivots=pivots,rational_coefficient_rounding_objective_error_bound=Q(N,GRID))

def stats(z):
    S=len(z);mean=sum(z)/S;se=math.sqrt(sum((v-mean)**2 for v in z)/(S*(S-1))) if S>1 else 0.
    return dict(mean=mean,SE=se,samples=S)

def validate(src,rawrows,selector,branch,q,reps,result,chosen,ignore_fee=False):
    rows=event_rows(src,rawrows,selector,branch);scores=[];occupation=[];index={r['x']:r for r in rows}
    for raw in rawrows:
        row=index.get(raw['x'])
        if row is None:scores.append(0.);occupation.append(0.);continue
        f=0.
        for m,alpha in result['primal'].items():
            rid=chosen[m];rep=reps[rid] if rid>=0 else None
            if rid==-2 or (rep is not None and gate(rep,row)):
                p=sum(v for i,v in enumerate(row['posterior']) if m>>i&1);f+=float(alpha)*min(1.,p)**q/(1. if ignore_fee or rid==-2 else float(rep['fee']))
        assert f<=1+1e-10 and f>=0
        # row weight used training/validation S already; recover per-draw contribution.
        scores.append(row['weight']*len(rawrows)*f);occupation.append(row['weight']*len(rawrows))
    return dict(packing=stats(scores),occupation=stats(occupation),band_receivers=len(rows),selected_scale_counts={str(L):sum(r['L']==L for r in rows) for L in src['scales']},_scores=scores)

def quadrature_check(src,rows):
    delta=0.;relative=0.;selectors=events=0;minimum_margin=math.inf
    for row in rows[:12]:
        refined=evaluate(src,row['x'],512);old=row['scales'];rr=dict(row,scales=refined)
        for v,w in zip(old,refined):
            for key in ('F','C','T'):
                d=abs(v[key]-w[key]);delta=max(delta,d);relative=max(relative,d/max(abs(w[key]),1e-300))
            minimum_margin=min(minimum_margin,abs(abs(w['T'])-src['lam']),abs(w['F']-src['B']*src['lam']),abs(w['F']-2*src['B']*src['lam']))
        for selector in ('max_abs','first_crossing'):
            a=selected(src,row,selector);b=selected(src,rr,selector)
            selectors+=((a is None)!=(b is None)) or (a is not None and b is not None and a['L']!=b['L'])
            for branch in ('low','high'):
                events+=bool(event_rows(src,[row],selector,branch))!=bool(event_rows(src,[rr],selector,branch))
    return dict(points=min(12,len(rows)),panels=[256,512],max_absolute_kernel_change=delta,max_relative_kernel_change=relative,selector_changes=selectors,event_changes=events,min_sampled_threshold_margin=minimum_margin,certified_quadrature=False)

def run_stage(pilot=False):
    S=64 if pilot else 256;V=128 if pilot else 512;out=[];tot=dict(training_draws=0,heldout_draws=0,LP_certificates=0)
    for sid,src in enumerate(fixtures(pilot)):
        rows=draw(src,S,761000+sid);held=[draw(src,V,762000+10*sid+j) for j in range(2)];fixed,affine=library(src);N=len(src['y']);results=[]
        print(('PILOT' if pilot else 'PRESSURE'),src['name'],flush=True)
        for selector in (('max_abs',) if pilot else ('max_abs','first_crossing')):
            for branch in ('low','high'):
                selectedrows=event_rows(src,rows,selector,branch);T=sum(r['weight'] for r in selectedrows)
                for q in ([2.] if pilot else sorted(set([2.,1+1/math.sqrt(src['n'])]))):
                    comparisons={}
                    for label,reps,ignore_fee in [('fixed',fixed,False),('affine_paid',affine,False),('affine_free_diagnostic',affine,True)]:
                        coeff,chosen,patterns=coefficients(selectedrows,reps,N,q,singletons=True,ignore_fee=ignore_fee);lp=simplex(coeff,N);tot['LP_certificates']+=1
                        validation=[validate(src,h,selector,branch,q,reps,lp,chosen,ignore_fee) for h in held]
                        comparisons[label]=dict(coefficients=coeff,chosen_representative=chosen,LP=lp,gate_patterns=patterns,training_ratio_approx=float(lp['value'])/T if T else None,heldout=validation)
                    assert comparisons['fixed']['LP']['value']<=comparisons['affine_paid']['LP']['value']<=comparisons['affine_free_diagnostic']['LP']['value']
                    differences=[stats([a-b for a,b in zip(comparisons['affine_paid']['heldout'][j]['_scores'],comparisons['fixed']['heldout'][j]['_scores'])]) for j in range(2)]
                    for c in comparisons.values():
                        for h in c['heldout']:h.pop('_scores')
                    results.append(dict(selector=selector,branch=branch,q=q,training_occupation_approx=T,training_band_receivers=len(selectedrows),selected_scale_counts={str(L):sum(r['L']==L for r in selectedrows) for L in src['scales']},comparisons=comparisons,heldout_paired_affine_minus_fixed=differences))
        out.append(dict(source=src,training_seed=761000+sid,training_samples=S,heldout_seeds=[762000+10*sid+j for j in range(2)],heldout_samples_per_batch=V,fixed_library=fixed,affine_library=affine,quadrature_diagnostic=quadrature_check(src,rows),results=results,training_receivers=rows if not pilot else []))
        tot['training_draws']+=S;tot['heldout_draws']+=2*V
    return out,tot

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--pilot-only',action='store_true');args=parser.parse_args();start=time.monotonic();guard=geometry_guard();pilot,pc=run_stage(True)
    pilot_summary=[dict(name=s['source']['name'],training_samples=s['training_samples'],quadrature=s['quadrature_diagnostic'],cases=[dict(selector=r['selector'],branch=r['branch'],q=r['q'],band=r['training_band_receivers'],ratios={k:v['training_ratio_approx'] for k,v in r['comparisons'].items()}) for r in s['results']]) for s in pilot]
    pressure,counts=([],{}) if args.pilot_only else run_stage(False)
    original=[r for s in pressure[:8] for r in s['results']]
    history=dict(initial_pressure_sources=8,initial_pressure_training_draws=2048,initial_pressure_heldout_draws=8192,initial_pressure_LP_certificates=180,initial_pressure_paid_gain_cases=sum(r['comparisons']['affine_paid']['LP']['value']>r['comparisons']['fixed']['LP']['value'] for r in original),initial_pressure_unpaid_extra_gain_cases=sum(r['comparisons']['affine_free_diagnostic']['LP']['value']>r['comparisons']['affine_paid']['LP']['value'] for r in original),amendment='After zero paid gain in the initial eight sources, register two one-sided actual crossing subdomains with disclosed B=1024; freeze before independent held-out validation.')
    data=dict(status='PASS',scope='Exact rational LP witnesses for rationalized floating actual-E2 finite-domain coefficients; no certified phi/spatial integration or continuum upper bound.',coefficient_grid=GRID,geometric_guard=guard,pilot_counts=pc,pilot=pilot_summary,development_history=history,pressure_counts=counts,sources=pressure)
    path=Path(__file__).with_name('affine_results.json');path.write_text(json.dumps(clean(data),sort_keys=True,separators=(',',':'))+'\n');print('PASS',json.dumps(counts),'elapsed',time.monotonic()-start,'sha256',hashlib.sha256(path.read_bytes()).hexdigest())
if __name__=='__main__':main()
