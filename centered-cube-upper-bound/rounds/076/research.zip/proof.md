# 中心立方体第76轮：仿射费用、共同随机代表与高捕获代理障碍

2026-10-11。**一般目标 C_n^square ≤ sqrt(n)n^{o(1)} 尚未证明；保留全一般基准仍为 O(n log n)。** 本轮扩大有严格支付的覆盖类，并建立一种新共同源 LP。支付定理、舍入定理与有限数值证书均不等于一致覆盖下界。

## 本轮目标及完整结果账

1. **精确仿射费用，已证。** 对跨所有接收点固定的代表轨迹 a+Lb，费用恰由星形包络体积 C(b)=1+(1/n)∑(|b_i|−1/2)_+ 控制。任意真实硬赢家带和实际软层后验均有统一正积分支付。位移费用随平均坐标位移线性增长；分散源包能否由这种代表有效覆盖仍是独立问题。平移乘积核也有线性射线包络费用，但不能凭此删除逐源支配假设。
2. **实际噪声提升及随机代表 LP，已证。** 以固定共同源 η=μ⊗ρ 表示实际 E2 软层，在每包中只抽一次 (y,z)，跨所有接收点使用同一轨迹 y+Lz，保留原始 dx 及实际选尺。若包捕获质量 a、包质量 w、总捕获 F，则平均列为 ∫a^(2+t)/(L^n F^t w)。其共同容量总支付不超过 H_t∫C(z)dη；K 的预算≤(1+δ/2)W，J 的未归一化预算≤7IW。有限列表可精确转换为 Boolean 成员格 LP，且一般非原子共同源也有 O_avg≤B_avg≤(1+t)O_avg 的同钟舍入。端点 t=0 的上确界为全部流量；这不给任何一致有限 t 的逼近速度。
3. **严格排除高捕获代理，已证。** 对均匀立方体顶点源构造真实全尺度赢家子事件 U。只准使用自身捕获率>2/3 的包，t=1/√n 时最优共同覆盖恰为 Θ(n^−1/2)，证明允许分数源包。实际整源几何代表却覆盖至少一半；它也是合法坐标中心点。故应保留实际门或随机代表，不能把高捕获充分条件当必要门。U 体积很小；这不是完整带覆盖或弱型反例。
4. **远噪声尾统一支付，已证。** 同一噪声截断半径 R=3/2+2log[2n(1+nlog2)]+2a，对任意有限尺度族⊂[1,2]，全部软层噪声尾一次强 L1 支付≤2e^(−a)W。与上轮源位移截断不同，此截断确保保留源的噪声坐标有界，方便共同仿射代表；未默认无限物理窗口结算。
5. **数值探路及适用界限。** 先导、已有障碍压力和扩大试验共10个真实E2输入：n=1..4、4..8源，2,560训练点及10,240独立保留点。216有理 LP 证书仅认证浮点核/采样后量化的有限泛函；没有认证连续积分。最初8组未见付费仿射增益；追加的两组单侧 B=1024 子域见到扣费后的增益。固定尺度深尾障碍保留。报告保留设计变化、随机种子、保留样本标准误及全部范围限制。

## 多轮探路、独立检查与复现

多数代理程序核验54个真实几何案例、65,805个小维全子集、8份精确LP见证、13个扩大显式源包、8个隐式平方维（最高n=16384）。大维度仅通过已证乘积公式及有理根区间计算，没有枚举2^n个源。其数量级由前述解析上下界确定。独立审计使用整数平方根重新构建小维系数，核验1,080条对偶不等式；仿射数值另独立核验28,584条对偶约束及同数系数、14,772个共同容量分数。

父代理将主程序复制到独立目录重放，两个JSON均逐字节一致；覆盖、软层及最终独审守卫均实际运行通过。真实耗时、stdout和源哈希在 inventory.json，不能把小维守卫当高维证明。仅做LaTeX静态源检查，未编译、未生成PDF。

本包依赖Python标准库。先在临时目录解压并备份两个结果JSON，执行 `python3 -B affine_probe.py` 与 `python3 -B majority_guard.py`。proof.md 恰有三个Python块，按顺序为 coverage_guard.py、soft_guard.py、audit_guard.py；用标准库 re 模式 `r"```python\n(.*?)\n```"`、flags=re.S提取后按顺序运行。独审守卫与主代码/JSON须在同目录。不要在冻结副本运行 pilot-only，因为它会替换结果文件。

## 技能、证据与未解决接口

重新读取适用技能边界，并检查64个canonical入口及437处直接引用，合计277108字节；入口哈希与第75轮一致。具体使用A02/A04共同源与预算、D04有限KL分解、M04选择范围、N04误差结算和L03有理证书边界。入口可读不等于64项全部验收，也不等于所有原文读完。本轮新命题使用自包含论证，不用未读文献替代假设。

覆盖与软层由Astra medium处理，数值与独立审核由6.1 Sol high处理。正文中的“未操作Git”是子任务职责；主代理在整理完成后单独提交和推送本轮。仓库只新增轮次README和research.zip、更新项目总览；中间稿与缓存留在仓库外，历史依赖未经核清不删除。

**最小剩余接口：** 对实际截断软层分支证明共同随机代表（或更强的付费仿射代表）在适当有限t上的维数一致覆盖，或者给未覆盖事件完整弱体积预算；随后核对每层衰减、阈值分配及全尺度回代。已有未截断物理门反例不能被当作已修复，R=O(log n)的尾支付也不自动解决核心。未证明根号n级geom总余项，目标保持未完成。

以下给出全部数学证明、数值笔记与独立审计。

# Round 76 coverage: affine representatives, exact star-hull prices, and the limits of the soft translation lift

Status: the general centered-cube target C_n<=sqrt(n)n^{o(1)} remains UNPROVED. The affine-representative price conjecture is proved exactly. Its cost is linear in the average coordinate displacement, not exponential in dimension. A new normalized source-capacity interface is consequently available. Uniform coverage is not proved, and the R75 untruncated soft full-branch counterexample survives unchanged at a single physical scale.

## 1. Input, units, and audit scope

Fix a finite positive physical source mu=sum_i p_i delta_{y_i}, total W, and the original centered-cube band Omega={lambda<Mmu<=beta lambda}. Use the actual all-scale complete-distance-batch winner Q(x)=x+L(x)[-1/2,1/2]^n, choosing smallest volume on ties. Write F=mu(Q), M=F/L^n, and T=int_Omega M dx. Receiver measure is Lebesgue measure. All original selectors, bands and posteriors remain fixed while packets are optimized.

An affine representative is the physical trajectory c(L)=a+Lb, where a has spatial units and b is dimensionless. Its gate is

    g_{a,b}(x)=1{a+L(x)b in Q(x)}
             =1{(x-a)/L(x) in K_b},
    K_b=b+[-1/2,1/2]^n.

The supplied objective and R75 proof, coverage, soft and envelope notes were read. A02, M04 and N04 canonical boundaries and relevant method/interface records were checked. Positive domination is proved before transfer; no general measurable-selection theorem is invoked; no unbudgeted layer errors or averaged weak norms appear. The elementary proofs below do not import external literature results. Source-code tests do not stand in for the continuum arguments. No Git operation or TeX compilation is performed.

## 2. Exact star-hull volume of a shifted cube or rectangle

For a compact convex set K, define its star hull from zero by S=union_{0<=s<=1}sK. It equals conv({0} union K): every convex combination of zero and points of K is s times a point of K, and conversely every such product is a convex combination. This statement does not require zero in K.

For a cube K_b and Euclidean direction theta, set

    R_b(theta)=sup{r>=0:r theta in K_b},

with value zero if the positive ray misses the cube. A ray may enter and later leave K_b; the supremum is the outer intersection radius. Its radial interval inside S_b=conv(0,K_b) is [0,R_b(theta)]. Consequently polar integration gives

    (1/n)int_sphere sup_{r>0} r^n 1_{K_b}(r theta)d sigma(theta)
        =|S_b|.

For the actual cube the exact value is

    P(b):=|S_b|=1+(1/n)sum_i (|b_i|-1/2)_+.                 (76.1)

Proof of the volume formula: a face is visible from zero precisely when zero lies strictly outside its supporting coordinate slab. For each coordinate there is then exactly one visible face, at distance (|b_i|-1/2)_+ from zero, with area one. The exterior part S_b\K_b is, up to null boundaries, the disjoint union of pyramids with apex zero and these visible faces as bases. Each exterior ray first enters K_b through a unique visible face except when it meets a lower-dimensional face. A pyramid has volume base-area times perpendicular height divided by n. Adding its volume to |K_b|=1 proves (76.1). Tangent faces contribute zero. This proof includes n=1 with the usual zero-dimensional face measure equal to one.

More generally, for a rectangle K=b+product_i[-r_i,r_i] with all r_i>0,

    |conv(0,K)|=product_i(2r_i)
       +(1/n)sum_i (|b_i|-r_i)_+ product_{j!=i}(2r_j).       (76.2)

The same visible-face argument proves this formula. In particular ||b||_infinity<=R gives P(b)<=1+(R-1/2)_+. Using the centered containing cube instead would give (1+2R)^n; that is a valid but needlessly expensive outer bound for this ray problem.

Measurability is elementary here. For theta_i!=0, intersect the intervals between (b_i-1/2)/theta_i and (b_i+1/2)/theta_i, then intersect with r>=0. For theta_i=0, the condition is either vacuous or impossible according as zero belongs to the coordinate interval. The positive outer endpoint, or zero for an empty ray, is a finite Borel formula on finitely many coordinate-sign cases. No unverified argmax selector is needed.

## 3. Affine-gated payment for the true hard winner

Let z<=mu be any fixed positive source packet of total mass w, with captured mass A(x)=z(Q(x)) and posterior pi=A/F. Define the gauge of the star hull by

    gamma_b(z)=inf{s>0:z in s S_b},

taking infinity off the cone generated by S_b. For every s>0, {gamma_b<=s}=s S_b, up to harmless zero/boundary conventions. Therefore the pushforward of Lebesgue measure on its cone by v=gamma_b(x-a)^n is P(b)dv. Outside the cone the affine gate is zero. The anchor x=a is a null receiver. On the affine gate gamma_b(x-a)<=L(x), hence

    M pi^q <= min(beta lambda,
                   w/v,
                   w^q/(lambda^(q-1) v^q)),  q=1+t.

The first bound uses M<=beta lambda and pi<=1; the second uses A<=w and L^n>=v; the third uses F>lambda L^n. The three radial pieces meet at v=w/(beta lambda) and v=w/lambda. Integration gives

    int_Omega M g_{a,b} pi^(1+t) dx
       <=P(b)[1+log beta+1/t]w.                            (76.3)

The statement is valid for arbitrary fixed fractional packets as well as whole-source subsets. The gate may capture only part of a packet. It does not require a to be a median, a source atom or a packet center. The representative depends on scale through one fixed pair (a,b); it is not chosen separately at each receiver.

For any common source-capacity family of packets z_J and coefficients alpha_J>=0 with sum_J alpha_J z_J<=mu, the same proof and Tonelli give

    int_Omega M sum_J alpha_J g_{a_J,b_J} pi_J^q
       <=C_t sum_J alpha_J w_J P(b_J),
    C_t=1+log beta+1/t.                                    (76.4)

Source mass is charged once through the displayed capacity inequality. Countable families follow by nonnegative truncation. There is no multiplication by the number of scales or packets.

## 4. A normalized affine capacity LP with the old payment constant

Fix R>=0. For each nonempty whole-site subset J define

    b^aff_{J,R}=max_{a in R^n, ||b||_infinity<=R}
        P(b)^(-1) int_Omega M g_{a,b} pi_J^q dx,
    B^aff_{t,R}=max_{alpha>=0, sum_{J contains i}alpha_J<=1}
                     sum_J alpha_J b^aff_{J,R}.

These are new coefficients on the original hard winner. Maxima exist: the band is bounded and L<=(W/lambda)^(1/n); a positive gate forces a into a common bounded box once b is bounded. Outside this box the score is zero. On the resulting compact parameter set, closedness of the affine gate and reverse Fatou give upper semicontinuity; P(b)>0 is continuous. Thus one may choose a maximizing pair for each of finitely many J without a receiver-dependent measurable-selection problem.

The old fixed-representative class is included by b=0, P(0)=1. Payment and the pointwise source-capacity bound give

    B_t <= B^aff_{t,R} <= min(T,C_t W).                     (76.5)

Indeed g/P<=1, so the packed score is at most sum_J alpha_J pi_J<=1. The finite dual has the usual constraints u(J)>=b^aff_{J,R}, u_i>=0. The same common exponential-clock rounding from R73 applies while keeping each pair (a_J,b_J) and its price fixed. Conditional Jensen is unchanged by the deterministic multiplier g/P, and yields

    O^aff_{t,R}<=B^aff_{t,R}<=(1+t)O^aff_{t,R},             (76.6)

where O^aff is the best actual common whole-site partition with these normalized scores. Source packets after rounding need not retain any median property; none is required.

A source-uniform lower bound B^aff_{1/sqrt(n),R_n}>=kappa_n T with kappa_n>=n^{-o(1)} would close the same hard-band objective at the old paid constant. Neither this lower bound nor such an R_n is proved. Formula (76.5) enlarges the honest feasible coverage class; payment is not coverage.

## 5. Affine gates also pay true soft posteriors

This version does not require a ray-decreasing soft kernel. Let k>=0 have height at most m, let G=mu*k_{L(x)}, and let a<G<=b on a measurable receiver set E, with 0<a<b<infinity. Use the same arbitrary measurable selector for every packet. For a physical source packet z of mass w, set u=z*k_L and pi=u/G. On its affine gate,

    u<=mw/L^n<=mw/v,
    G pi^q<=min(b,u,u^q/a^(q-1)).

The same gauge integration gives

    int_E G g_{a0,b0} pi^(1+t) dx
      <=P(b0)[1+log(b/a)+1/t]m w.                           (76.7)

Here a0,b0 denote the trajectory parameters; a,b in the logarithm are amplitude endpoints. The actual E2 kernels have K<=1 and J<=I, so one may take m=1 or m=I. Their truncated cores retain the same height bounds. The common source-capacity extension is identical to (76.4), on the actual chosen soft band or branch. No physical hard posterior is substituted for the soft posterior.

## 6. Shifted product kernels have a linear ray-envelope price

Let k_i be even, nonnegative, bounded upper-semicontinuous functions, nonincreasing on [0,infinity), right-continuous at zero, with positive finite mass m_i and height M_i=k_i(0). These explicit regularity assumptions cover the actual h, phi and their mixtures. Put

    k_b(z)=product_i k_i(z_i-b_i),    m=product_i m_i,
    D(k_b)=(1/n)int_sphere sup_{r>0}r^n k_b(r theta)d sigma.

The ray envelope is Borel: on each compact radial interval [1/j,j] its supremum is upper semicontinuous in theta, as follows by taking a convergent maximizing-radii subsequence; then take the countable supremum over j. This uses bounded upper semicontinuity and compactness, not a general measurable-selection theorem.

Layer cake writes k_i(s)=int_0^{M_i}1_{[-r_i(h),r_i(h)]}(s)dh using the closed superlevel intervals. For almost every layer height r_i(h) is positive and finite under the stated assumptions. Each product layer is a shifted rectangle. Supremum of a nonnegative integral is at most the integral of suprema, and Tonelli plus (76.2) give

    D(k_b)<=int_layers |conv(0,rectangle_layer)| dh
       <=m+(1/n)sum_i |b_i| M_i product_{j!=i}m_j
        =m[1+(1/n)sum_i |b_i| M_i/m_i].                    (76.8)

The equality form with m[1+(1/n)sum|b_i|k_i(0)] requires each m_i=1. Omitting the ratios for unnormalized factors would be incorrect. When the factors are probability kernels of height at most one and ||b||_infinity<=R, the bound is at most 1+R.

For any nonnegative kernel e with a measurable ray envelope and finite ray price D(e) (as verified for the kernels above), the envelope e_L(r theta)<=A_e(theta)/r^n, A_e=sup_s s^n e(s theta), and the usual three-piece integral prove the following genuine positive-domination statement. If an ACTUAL packet contribution u obeys both u<=G and u<=w e_L(x-a0), on E subset {a<G<=b}, then

    int_E G(u/G)^(1+t)dx <=[1+log(b/a)+1/t]w D(e).          (76.9)

Thus (76.8) pays an ungated shifted-product envelope when that pointwise packet domination has really been established. It does not establish the domination for an arbitrary dispersed physical packet. In particular translation cost has become linear; the separate bbox inflation cost for a packet with spatial extent can still be exponential. One must not drop that distinction.

Positive mixtures of the actual E2 mask products inherit (76.8) by sup-integral subadditivity. Their factors h and phi each have mass one and height at most one, so a fixed shift b costs at most m(1+||b||_infinity), where m=1 for K and m=I for J. The central ray price already costs at most m; the new fact is the shifted estimate.

## 7. The exact soft translation lift, and what it fails to transfer

For the actual E2 kernel,

    h=1_{[-1/2,1/2]},
    w(s)=int_0^1 exp(-|s|/v)dv,
    phi=h*w.

Tonelli gives int w=2 int_0^1 v dv=1 and int |s|w(s)ds=2 int_0^1 v^2 dv=2/3. Let nu_delta be the product probability law with coordinate law (1-delta)delta_0+delta w(s)ds. Then, exactly,

    psi_delta^tensor n(z)=int h^tensor n(z-b) dnu_delta(b),
    mu*(psi_delta^tensor n)_L(x)
       =int sum_i p_i L^(-n)
               1{y_i+Lb in x+L[-1/2,1/2]^n} dnu_delta(b).  (76.10)

The same identity holds for each mask and for the positive K and J mixtures after normalizing J by I when I>0. The physical source measure is not altered; (76.10) is a joint positive representation with latent shift b.

Every such normalized mask mixture obeys

    E[(1/n)sum_i |B_i|]<=2/3,
    E P(B)<=5/3.                                           (76.11)

For nu_delta the first bound sharpens to 2delta/3. This is an average of geometric single-shift prices. It is not permission to average weak quasi-norms or the coverage of private source decompositions.

There are two distinct remaining obstacles.

First, recentering x to x-L(x)b in (76.10) need not preserve Lebesgue measure for a variable selector L(x). Even the elementary map in dimension one with b=1 and L(x)=x on x in (1,2) collapses that entire interval to zero. This example only diagnoses the invalid general change of variables; it is not asserted to be a cube winner selector. No such change of observation law is used in (76.3), (76.7) or (76.9).

Second, on the joint source space (y,b), common source allocations must be fixed across all receivers and scales and consume the SAME joint capacity. A partition chosen separately after each receiver's shift conditioning is not a common partition. Nor do posterior powers commute with mixing. Infinitely refining a latent shift cloud that is fully captured can create arbitrary artificial power loss: K equal distinct latent shift labels have sum pi_label^(1+t)=K^(-t), while their merged physical packet has posterior one. This happens already at one fixed scale when all latent shifts lie in a small cube and the receiver captures them all. It does not show optimized joint packet coverage is small; it shows that labelwise ray payment and (76.11) do not supply that coverage.

For a general physical packet, the lifted shifts and original positions occupy a family of different trajectories y+Lb. A single affine representative and a small mean trajectory price do not prove a lower bound for the packet's true posterior traffic. Any proposed compression still has to establish common-source capacity, an actual gate or dominating envelope, and coverage of the full selected event with any exceptions paid. No hard-winner-to-soft coverage transfer is proved here.

## 8. A realizable obstruction that affine representatives do not remove

R75 soft.md proves a counterexample using the actual E2 kernel, n=2, delta=1/2, the physical scale family {1}, B=2, N distinct equal-weight sources in [-1/1024,1/1024]^2, and a threshold lambda_R tending to zero. On the FULL actual low branch E_R it gives

    B_t(E_R)/int_{E_R}C
       <=1800*50^(1+t)/R+(50/N)^t,                       (76.12)

where the class permits arbitrary fixed physical-cube packet representatives and also ungated singletons. Its denominator is controlled on a genuine long tail strip, while the numerator estimate holds on the entire branch and for every common capacity family. It is a failure of coverage, not a weak-constant lower bound.

At L=1, an affine representative is just c=a+b. Since a was already unrestricted, the family of gates obtained by allowing any b is exactly the old fixed-representative family. Choosing b=0 realizes every fixed representative at price one; P(b)>=1 never improves a normalized score at this one scale. Consequently the same full-branch counterexample and (76.12) apply unchanged to affine representatives, with or without a bound on b, and with the new price normalization.

Thus affine representatives do not resurrect the disproved UNTRUNCATED soft coverage target. The R75 strong far-tail payment at radius O(log n) must remain in the dependency chain. The truncated core and genuinely varying physical scales may still benefit from (76.3)--(76.9), but their uniform common-source coverage is unproved. This is an actual-kernel, actual-event obstruction, not a substitute test family.

## 9. Verification and exact remaining goal

Three-stage geometry guards use dimensions 1,2; then 3,4,8; then 16,32. Independent one-dimensional interval length and two-dimensional convex-hull polygon area agree exactly with the star formula. Visible-face pyramid determinants, step-product layer prices and finite-ray envelopes are checked with Fraction. Further actual complete-batch winner tests vary n=1,2,4,8,16 and N=2,4,8; they verify affine-gated three-piece bounds. The guard separately verifies positive translation lifts at three physical scales and artificial latent-label power loss. Seed is 760211.

The guard originally encountered zero-distance source receivers and the anchor x=a; these are null cases excluded by the analytic proof. The final code offsets its rational receivers away from sources and explicitly omits the zero anchor from gauge division. This is a domain correction, not a hidden failed inequality. Finite receiver checks do not certify spatial integrals or general coverage. Product tests use exact step kernels to test the layer-cake algebra; the actual E2 identities and kernel assumptions are verified analytically above.

The original hard route now has the honest larger interface (76.5); the soft core has honest affine-gated and shifted-envelope payments. The missing quantity is a source- and threshold-uniform coverage fraction, with all original-source and latent-shift allocations common and all exceptions paid. No such fraction is proved. Consequently there is no new general weak bound and no completed sqrt(n)n^{o(1)} theorem.

```python
from fractions import Fraction as F
from itertools import product
from math import factorial
from random import Random
import json
rng=Random(760211)
counts=dict(polygon_area=0,pyramid_determinant=0,ray_layers=0,product_price=0,winners=0,affine_envelope=0,fixed_scale=0,lift_identity=0)
def det(A):
 A=[list(row) for row in A];z=F(1);n=len(A)
 for j in range(n):
  i=next((i for i in range(j,n) if A[i][j]),None)
  if i is None:return F(0)
  if i!=j:A[i],A[j]=A[j],A[i];z=-z
  d=A[j][j];z*=d
  for k in range(j,n):A[j][k]/=d
  for i in range(j+1,n):
   d=A[i][j]
   for k in range(j,n):A[i][k]-=d*A[j][k]
 return z
def hull2(pts):
 pts=sorted(set(pts))
 def cross(o,a,b):return (a[0]-o[0])*(b[1]-o[1])-(a[1]-o[1])*(b[0]-o[0])
 lo=[]
 for x in pts:
  while len(lo)>1 and cross(lo[-2],lo[-1],x)<=0:lo.pop()
  lo.append(x)
 hi=[]
 for x in reversed(pts):
  while len(hi)>1 and cross(hi[-2],hi[-1],x)<=0:hi.pop()
  hi.append(x)
 return lo[:-1]+hi[:-1]
def area(poly):return abs(sum(poly[i][0]*poly[(i+1)%len(poly)][1]-poly[i][1]*poly[(i+1)%len(poly)][0] for i in range(len(poly))))/2
def starvol(b,r):
 n=len(b);ans=F(1)
 for v in r:ans*=2*v
 for i in range(n):
  z=max(F(0),abs(b[i])-r[i])/n
  for j in range(n):
   if j!=i:z*=2*r[j]
  ans+=z
 return ans
def ray_interval(v,b,r):
 lo=F(0);hi=None
 for a,c,d in zip(v,b,r):
  if a==0:
   if not c-d<=0<=c+d:return None
  else:
   l,u=sorted([(c-d)/a,(c+d)/a]);lo=max(lo,l);hi=u if hi is None else min(hi,u)
 if hi is None or hi<=0 or hi<lo:return None
 return lo,hi
stages=[]
for name,dims in [('pilot',[1,2]),('stress',[3,4,8]),('expanded',[16,32])]:
 before=dict(counts)
 for n in dims:
  for case in range(5):
   b=[F(rng.randrange(-15,16),4) for j in range(n)]
   r=[F(rng.randrange(1,7),4) for j in range(n)]
   V=starvol(b,r)
   if n==1:
    assert V==max(F(0),b[0]+r[0])-min(F(0),b[0]-r[0]);counts['polygon_area']+=1
   if n==2:
    poly=hull2([(F(0),F(0))]+[tuple(b[j]+sgn[j]*r[j] for j in range(2)) for sgn in product([-1,1],repeat=2)])
    assert area(poly)==V;counts['polygon_area']+=1
   for i in range(n):
    if abs(b[i])<=r[i]:continue
    c=[b[j]-r[j] for j in range(n)];c[i]=b[i]-r[i] if b[i]>0 else b[i]+r[i]
    vertices=[c]
    for j in range(n):
     if j!=i:
      z=list(c);z[j]+=2*r[j];vertices.append(z)
    simplex=abs(det([[vertices[k][j] for k in range(n)] for j in range(n)]))/factorial(n)
    face_pyramid=(abs(b[i])-r[i])/n
    for j in range(n):
     if j!=i:face_pyramid*=2*r[j]
    assert simplex*factorial(n-1)==face_pyramid;counts['pyramid_determinant']+=1
   # Two-step normalized product kernels; enumerate layers only up to n=8.
   if n<=8:
    terms=[[(F(1,3),F(1,2)),(F(1,3),F(1))] for j in range(n)] # each factor mass 1, height 2/3
    total=F(0);layers=[]
    for choice in product([0,1],repeat=n):
     coeff=F(1);rs=[]
     for j,k in enumerate(choice):
      a,d=terms[j][k];coeff*=a;rs.append(d)
     total+=coeff*starvol(b,rs);layers.append((coeff,rs))
    bound=1+sum(abs(v)*F(2,3) for v in b)/n
    assert total<=bound;counts['product_price']+=1
    for trial in range(8):
     direction=[F(rng.randrange(-7,8)) for j in range(n)]
     if not any(direction):direction[0]=F(1)
     envelope=F(0);breaks=set()
     for a,rs in layers:
      interval=ray_interval(direction,b,rs)
      if interval:
       lo,hi=interval;envelope+=a*hi**n;breaks.update([lo,hi])
     actual=F(0)
     for s in breaks:
      if s<=0:continue
      kernel=F(1)
      for j in range(n):kernel*=sum(a for a,d in terms[j] if abs(s*direction[j]-b[j])<=d)
      actual=max(actual,s**n*kernel)
     assert actual<=envelope;counts['ray_layers']+=1
 stages.append(dict(stage=name,dimensions=dims,counts={k:counts[k]-before[k] for k in counts}))
def winner(pts,p,x):
 d=[max(abs(a-z) for a,z in zip(y,x)) for y in pts];assert min(d)>0
 ans=None
 for r in sorted(set(d)):
  S=[i for i,a in enumerate(d) if a<=r];mass=sum(p[i] for i in S);M=mass/(2*r)**len(x)
  if ans is None or M>ans[0]:ans=M,2*r,S,mass
 counts['winners']+=1;return ans
for n in [1,2,4,8,16]:
 for N in [2,4,8]:
  pts=[tuple(F(i*(j+1),3) for j in range(n)) for i in range(N)];p=[F(i+1) for i in range(N)]
  for trial in range(8):
   x=tuple(F(rng.randrange(-20,41),7)+F(j+1,103) for j in range(n));M,L,S,Fcap=winner(pts,p,x)
   lam=M/F(3,2);beta=F(2)
   b=[F(rng.randrange(-8,9),4) for j in range(n)]
   # Force an actual contained affine representative, with a shared constant pair at this witness.
   c=pts[S[0]];a=[c[j]-L*b[j] for j in range(n)]
   z=[x[j]-a[j] for j in range(n)]
   if not any(z):continue  # the fixed anchor is a Lebesgue-null receiver
   interval=ray_interval(z,b,[F(1,2)]*n)
   assert interval is not None
   vmax=interval[1];gauge=1/vmax;assert gauge<=L
   v=gauge**n
   for q in [2,3]:
    J=[i for i in range(N) if rng.randrange(2)]
    w=sum((p[i] for i in J),F(0));capt=sum((p[i] for i in J if i in S),F(0));score=M*(capt/Fcap)**q
    assert score<=beta*lam and score<=w/v and score<=w**q/(lam**(q-1)*v**q)
    counts['affine_envelope']+=1
   a=[F(rng.randrange(-10,11),3) for j in range(n)]
   left=all(abs(a[j]+b[j]-x[j])<=F(1,2) for j in range(n))
   right=all(abs((a[j]+b[j])-x[j])<=F(1,2) for j in range(n))
   assert left==right;counts['fixed_scale']+=1
# Positive translation lift on the same source and same physical scale.
for n in [1,2,4,8]:
 pts=[tuple(F(i*(j+1),11) for j in range(n)) for i in range(5)];p=[F(i+1,15) for i in range(5)]
 shifts=[tuple(F((k+1)*(j+1)%7-3,7) for j in range(n)) for k in range(7)];weights=[F(1,7)]*7
 for L in [F(1),F(3,2),F(2)]:
  x=tuple(F(j+1,13) for j in range(n))
  hard=lambda z:all(abs(a)<=F(1,2) for a in z)
  mixed=sum(p[i]*sum(weights[k]*hard([(x[j]-pts[i][j])/L-shifts[k][j] for j in range(n)]) for k in range(7))/L**n for i in range(5))
  lifted=sum(weights[k]*sum(p[i]*hard([(x[j]-(pts[i][j]+L*shifts[k][j]))/L for j in range(n)]) for i in range(5))/L**n for k in range(7))
  assert mixed==lifted;counts['lift_identity']+=1
# Refining a fully captured latent shift cloud can create arbitrary artificial power loss.
for K in [2,4,16,64]:
 for q in [2,3]:assert K*F(1,K)**q==F(1,K)**(q-1)
# Exact w moment: 2 integral_0^1 t^2 dt=2/3, hence expected shift price<=5/3.
assert 1+F(2,3)==F(5,3)
print(json.dumps(dict(status='PASS',seed=760211,scope='exact geometry, step-product envelope and actual-winner guards; no Monte Carlo volume or uniform coverage inference',counts=counts,stages=stages),indent=2))
```

Actual stdout:

```json
{
  "status": "PASS",
  "seed": 760211,
  "scope": "exact geometry, step-product envelope and actual-winner guards; no Monte Carlo volume or uniform coverage inference",
  "counts": {
    "polygon_area": 10,
    "pyramid_determinant": 248,
    "ray_layers": 200,
    "product_price": 25,
    "winners": 120,
    "affine_envelope": 236,
    "fixed_scale": 118,
    "lift_identity": 12
  },
  "stages": [
    {
      "stage": "pilot",
      "dimensions": [
        1,
        2
      ],
      "counts": {
        "polygon_area": 10,
        "pyramid_determinant": 13,
        "ray_layers": 80,
        "product_price": 10,
        "winners": 0,
        "affine_envelope": 0,
        "fixed_scale": 0,
        "lift_identity": 0
      }
    },
    {
      "stage": "stress",
      "dimensions": [
        3,
        4,
        8
      ],
      "counts": {
        "polygon_area": 0,
        "pyramid_determinant": 55,
        "ray_layers": 120,
        "product_price": 15,
        "winners": 0,
        "affine_envelope": 0,
        "fixed_scale": 0,
        "lift_identity": 0
      }
    },
    {
      "stage": "expanded",
      "dimensions": [
        16,
        32
      ],
      "counts": {
        "polygon_area": 0,
        "pyramid_determinant": 180,
        "ray_layers": 0,
        "product_price": 0,
        "winners": 0,
        "affine_envelope": 0,
        "fixed_scale": 0,
        "lift_identity": 0
      }
    }
  ]
}
```

Guard SHA-256 including final newline: `e1709948f087dea057bcb733f4bef98384e176c9b2a452c957acebc993ad0f3c`.
Stdout SHA-256: `9b32fa2f9594bafde032fca2c78332308b90f3e0f95c60ce002d368831b3ab88`.


# Round 76: a common random-representative LP on the exact affine noise lift

**Status.** The exact joint lift, affine packet payment, noise-moment budget, random-representative functional, Boolean-cell finite LP, and common-partition rounding below are proved. The resulting finite-t coverage lower bound is NOT proved. This is a new precise sufficient interface, not a completed general cube upper bound. R75's untruncated original-source physical-gate coverage counterexample and R74's raw-source entropy counterexample remain valid. The current construction changes the common source to the actual joint source/noise measure; it does not relabel an unchanged kernel profile. No Git operation or TeX compilation occurred.

The canonical A04/A02 entries were checked for common choices and correct relaxation/payment directions, and the current D04 scope was retained: all conditional probabilities below come from one actual joint measure. No external theorem is imported for a weak-norm mixture. The original actual selector is fixed throughout; affine particles are not declared winners of a new maximal problem.

## 1. Exact lift, including the nonnormalized J measure

Write H=h^tensor n, h=1_{[-1/2,1/2]}, phi=h*w with the actual E2 density w. For a mask m let rho_m be the product law with delta_0 in hard coordinates and w(z)dz in soft coordinates. Then k_m=H*rho_m. The endpoint mask probabilities are alpha=Bernoulli(delta/2)^n, beta=Bernoulli(delta)^n; q_m=(alpha_m+beta_m)/2, zeta_m=(alpha_m-beta_m)/q_m and j_m=q_m zeta_m^2. Omit zero q terms. Define finite noise measures

    rho_K=sum_m q_m rho_m,   rho_J=sum_m j_m rho_m,
    rho_D=sum_m (alpha_m-beta_m)rho_m.

Their masses are 1, I=sum j_m, and 0 respectively. rho_J is deliberately NOT normalized: its mass I belongs in the source budget. For k=K or J and mu=|nu| of mass W, let

    eta_k(dy,dz)=mu(dy)rho_k(dz),
    A_x={(y,z): y+L(x)z in Q(x,L(x))},
    Fcap_k(x)=eta_k(A_x),  G_k(x)=Fcap_k(x)/L(x)^n.

Then G_K=mu*K_L and G_J=mu*J_L exactly. The map (y,z)->y+Lz is affine in L; its source labels and their measure are fixed before receivers are evaluated. The original receiver measure remains Lebesgue dx. For signed/complex nu the earlier same-joint-measure Cauchy remains |T|^2<=G_K G_J.

We work on an actual finite-window band E subset {a<G<=b}, 0<a<b<infinity, with one fixed measurable selector L(x) in a finite family in [1,2]. This selector may be the actual first contrast crossing and may depend on nu and the threshold. No hard-maximizer property is assumed for the lifted particles. The band occupation T_E=integral_E G is finite: the unlifted K/J finite-window envelope from R75 provides an integrable majorant. The proofs also apply whenever this integrability is supplied separately.

## 2. Affine representative payment and its noise moment

A packet P is a fixed measurable subset of the joint source space, of mass w_P=eta(P)>0. Its captured mass is a_P(x)=eta(P intersect A_x), its posterior share is pi_P=a_P/Fcap, and its prior capture fraction is f_P=a_P/w_P. A common affine representative is a fixed pair (a_P^rep,b_P^rep), with receiver gate

    g_P(x)=1{a_P^rep+L(x)b_P^rep in Q(x,L(x))}.

The parameters are fixed across all receivers, even though the representative's physical location moves with the selected scale.

Put Q0=[-1/2,1/2]^n and

    C(b)=|conv({0} union (b+Q0))|
        =1+(1/n)sum_j (|b_j|-1/2)_+.                    (1)

To verify the volume formula, retain the translated cube (volume one) and adjoin the pyramids from the origin to its visible faces. Their interiors outside the cube are disjoint, and the visible face normal to coordinate j contributes height (|b_j|-1/2)_+ times face area one divided by n. Boundary cases follow directly or by continuity.

The star hull in (1) supplies a radial envelope for the gate. On g_P=1, a_P/L^n<=w_P/L^n; using the star-hull gauge and the three-piece minimum on a<G<=b gives, for every t>0,

    integral_E G g_P pi_P^(1+t) dx
       <=Ct C(b_P^rep)w_P,   Ct=1+log(b/a)+1/t.          (2)

Explicitly the gauge v satisfies |{v<=s}|=C(b)s and g_P implies L^n>=v(x-a_P^rep). Bound the integrand by min(b,w_P/v,w_P^(1+t)/(a^t v^(1+t))) and integrate in v. Directions outside the star hull's cone contribute nothing. This uses neither an original-source representative nor a change of receiver variables.

The noise average of this cost is small. The actual density has E_w|Z|=2/3. Hence

    M_K:=integral C(z)eta_K(dy,dz) <=(1+delta/2)W,
    M_J:=integral C(z)eta_J(dy,dz) <=(I+2delta)W<=7IW.    (3)

For K, the mean soft-coordinate probability is 3delta/4. For J, use j_m<=4q_m, giving sum j_m|m|<=3n delta. Finally I is at least the one-coordinate triangular discrimination

    I>=4delta/[3(4-3delta)]>=delta/3.

This marginal lower bound follows by Cauchy on each group with the first mask bit fixed: sum 2(alpha-beta)^2/(alpha+beta) dominates the same expression for its marginals. Thus (3) contains no hidden source-count or dimension factor. If delta=0, the contrast and J vanish; handle that case separately.

## 3. One common random representative per packet

For each packet P, sample ONE point U_P=(Y_P,Z_P) from eta restricted to P, divided by w_P. This point is then used for every receiver, with representative Y_P+L(x)Z_P. It is not resampled after x is observed. Its gate probability is exactly

    E g_P(x)=eta(P intersect A_x)/w_P=f_P(x).

Define the deterministic averaged-representative score

    b_t(P)=integral_E G pi_P^(1+t) f_P dx
          =integral_E a_P^(2+t)/[L^n Fcap^t w_P] dx.     (4)

For a zero-mass packet set b_t(P)=0 and omit the representative. On the band Fcap>0; terms with a_P=0 vanish. Formula (4) is the expectation of the genuine common affine-gate score, not an entropy proxy and not a per-receiver choice. It retains the whole capture fraction f_P, rather than demanding f_P>2/3 or another fixed threshold.

A common finite source-capacity family consists of fixed measurable packets P_l and alpha_l>=0 with

    sum_l alpha_l 1_{P_l}(y,z)<=1   for eta-almost every (y,z).

Average the POSITIVE integral inequality (2), then use Tonelli and the actual capacity constraint. This proves

    sum_l alpha_l b_t(P_l)
       <=Ct sum_l alpha_l integral_{P_l}C(z)deta
       <=Ct M_k.                                      (5)

This is legal averaging of paid positive spatial integrals. No conditional weak norms are averaged. Also the score is pointwise <=1 after division by G, since f_P<=1 and the capacity sum gives sum_l alpha_l pi_P<=1.

Let B_t^avg(E) be the supremum of the left side of (5) over finite feasible families, and O_t^avg(E) the supremum over finite actual common measurable source partitions. Then

    B_t^avg(E)<=min(T_E,Ct M_k),   O_t^avg<=B_t^avg.      (6)

A deterministic choice of representatives has at least the averaged score for each finite family, by the definition of expectation. Conversely an optimally chosen representative can improve on this average. No equality with the full unrestricted affine-representative optimum is asserted.

## 4. An exact finite LP, with no private receiver-dependent source allocations

For any prescribed finite packet list P_1,...,P_m, form its Boolean membership cells

    C_S={u: {l:u in P_l}=S}, S subset {1,...,m}.

Keep exactly those cells with positive eta measure. The source-capacity condition is equivalent to the finite system

    alpha_l>=0,   sum_{l in S}alpha_l<=1
                       for every positive-measure C_S. (7)

Thus maximizing sum_l alpha_l b_t(P_l) is an exact finite packing LP, with at most 2^m membership constraints. Each nonnull packet gives alpha_l<=1, so the feasible polytope is compact and this fixed-list LP attains its optimum. Coefficients b_t are actual spatial integrals from (4); numerical cubature is not declared exact. This statement does not claim that a finite predetermined packet list attains the global supremum. Countable feasible families add no larger supremum than finite truncations, by nonnegative monotone convergence.

Packet membership can split the same original source among different noise tags. Projecting P back to the original source with allocation mu(dy)rho(P_y) does NOT preserve its kernel profile: its captured contribution is the integral of H over P_y, not rho(P_y) times the unconditioned soft kernel. For example, at n=1 a packet containing only the noise atom z=0 produces a hard kernel, whereas its projected source allocation convolved with K has positive soft tails. The R73 same-profile fractional-label invariance theorem cannot identify these two problems.

## 5. Exact common-clock rounding on the nonatomic joint source

**Theorem [proved].** For every t>=0,

    O_t^avg(E)<=B_t^avg(E)<=(1+t)O_t^avg(E).              (8)

The right inequality does not assume a finite number of joint-source atoms.

**Capacity completion.** Start with a finite feasible family. Its load ell(u)=sum_l alpha_l 1_{P_l}(u) is constant on each Boolean cell C_S. Add the cell itself as an extra packet with coefficient 1-ell_S whenever this is positive. The resulting finite family has load exactly one eta-almost everywhere and objective at least the original objective, because (4) is nonnegative. Ignore null cells and zero coefficients. Every coefficient is at most one.

**Common race.** Independently sample exponential clocks of rates alpha_l for all completed columns, once for the entire source. Assign each joint point u to its incident column whose clock is earliest. There are finitely many clocks; the resulting assigned packets P'_l form a measurable common partition up to eta-null sets, with no atom assumption and no receiver-dependent membership. Ties have probability zero. Empty assigned packets contribute zero.

Condition on column l's clock being s. On every u in P_l, the TOTAL rate of all other incident clocks is exactly 1-alpha_l, because capacities were completed. Therefore every point in P_l survives with the same probability r=exp(-(1-alpha_l)s). Correlations between different points need not vanish. Tonelli gives

    E[a'_l(x)|s]=r a_l(x),    E[w'_l|s]=r w_l.

Let p=2+t and Phi(a,w)=a^p/w for 0<=a<=w, w>0, extended by Phi(0,0)=0. Its Hessian is positive semidefinite: the aa entry is p(p-1)a^(p-2)/w and its determinant is p(p-2)a^(2p-2)/w^4>=0. At the zero boundary, 0<=Phi(a,w)<=w^(p-1) supplies the continuous convex extension. Phi has homogeneity degree p-1=1+t. Conditional Jensen thus gives

    E[Phi(a'_l,w'_l)|s]>=Phi(r a_l,r w_l)
                                  =r^(1+t)Phi(a_l,w_l).

Multiply by the fixed receiver factor 1/(L^n Fcap^t), integrate in x and then in the clock time. All terms are nonnegative. The column's expected score is at least

    alpha_l/[1+t-t alpha_l] * b_t(P_l)
       >=alpha_l b_t(P_l)/(1+t).

Summing shows that some actual common partition has score at least the original feasible objective divided by 1+t. Taking suprema proves (8). The convexity involves BOTH captured mass and total packet mass; replacing the random denominator w'_l by w_l would give a weaker and unnecessary loss. The completed-load step is essential to the displayed common scaling of both expectations.

## 6. The endpoint is a supremum, not a uniform finite-t coverage estimate

For a finite measure eta on the standard Borel joint source space, take refining finite measurable partitions whose sigma-algebras generate its Borel sigma-algebra modulo eta. For each fixed receiver, conditional expectations of 1_{A_x} converge in L2(eta) to 1_{A_x}. Consequently, at t=0,

    sum_{P in partition} a_P(x)^2/w_P ->Fcap(x).

By (4), the corresponding averaged score integrands tend to G(x); they are bounded by G. Dominated convergence on E therefore proves

    O_0^avg(E)=B_0^avg(E)=T_E,                            (9)

as suprema, without asserting attainment by a finite partition. One can justify the L2 convergence by approximation with simple functions from the union of the finite sigma-algebras and the contraction property of conditional expectation. For noise-truncated sources, representatives sampled from each packet automatically have bounded noise coordinates. Boundary capture atoms do not invalidate this conditional-expectation argument.

At t>0 refinement pays the factor pi_P^t and can destroy the score. Neither (9), rounding, nor a noise moment bound proves B_t^avg/T_E>=kappa_n. R74's raw-label entropy obstruction is respected; no number-of-noise-cells entropy is silently declared dimension-free.

The parent R76 majority/fullness analysis gives a separate reason not to replace f_P by 1{f_P>2/3}: that stronger surrogate can lose useful common packets. For its half-vertex captures, the whole packet has pi=1 and f=1/2, so (4) retains one half of its occupation instead of discarding it. This observation does not prove general coverage; it only establishes that the present interface is strictly less restrictive than that fullness certificate.

## 7. Optional affine centerpoints: a sufficient certificate, not the score definition

There is also a deterministic moment-controlled representative for each packet. In each two-dimensional marginal (y_j,z_j), intersect all closed halfplanes carrying packet probability greater than 2/3. Any three of them intersect, since the union of their complements has probability less than one. Planar Helly and compactness give a common point (a_j,b_j); compactness may be enforced with four sufficiently large coordinate halfplanes of mass greater than 2/3. The finite planar Helly assertion has an elementary proof: four points admit a Radon partition by an affine dependence; choose one point in every triple intersection, use Radon to get a fourfold intersection, then induct by merging two sets. Thus no input moment in the y-coordinate is required.

For this common affine representative, f_P>2/3 implies every coordinate capture halfplane contains (a_j,b_j), so a+Lb lies in Q(x,L). Also the halfplane condition implies P(z_j>=b_j)>=1/3 when b_j>1/2, and its negative analogue. Hence

    C(b)<=1+(3/n)E_P sum_j(|z_j|-1/2)_+<=3 E_P C(Z).

This gives a paid actual-gate column class with total moment budget at most 3M_k. The actual gate must be retained; the fullness condition is only sufficient, and its failure does not force the gate closed. Rounding is NOT automatically claimed within a restricted centerpoint representative class, since an inherited representative need not remain a centerpoint of an assigned subpacket. The averaged functional (4)--(8) avoids that issue altogether.

## 8. A common bounded-noise truncation and the weak return

To bound noise itself, restrict every rho measure to {||z||infinity<=R}. If H(v-z) is nonzero while ||z||infinity>R, then ||v||infinity>R-1/2. Thus the omitted positive K noise kernel is bounded by K(v)1{||v||infinity>R-1/2}. The signed contrast noise law has total variation at most 2rho_K. R75's finite-window ray envelope consequently gives

    ||max_L |T_noise-tail,L nu|||_1
       <=2n(1+n log2)delta exp(3/4-R/2)W.                (10)

Choose R=3/2+2log[2n(1+n log2)]+2a, a>=0. The fee is at most delta exp(-a)W, and summing all delta_s=2^(-s) pays the ENTIRE noise-tail remainder by 2exp(-a)W in strong L1, with almost-everywhere absolute convergence. This is a finite physical-family statement, not an unchecked continuous-scale limit.

The retained joint source has ||z||infinity<=R. Every sampled representative then satisfies C(b)<=R+1/2=O(log n+a). Thus even the unrestricted common affine-representative LP with this bounded b has a paid O(log n+a) cost per source mass, and its usual inherited-representative clock rounding is valid. The sharper averaged functional still uses the moment budgets (3), without that logarithmic loss. The truncated actual kernels retain positive product-mixture structure: replace w by w1_{[-R,R]} in each soft noise coordinate, so their h-convolutions remain even decreasing. They also preserve the latent restricted Cauchy inequality. They are not probability-normalized anew.

For the averaged J score, suppose an actual low branch at core contrast threshold lambda and F_core<=B lambda satisfies B_t^avg>=kappa T_E, where T_E=integral_E C_core. Then

    lambda |E_low| <=(7B/kappa)[1+log(4B^2)+1/t] I W.

For each high-background K band, suppose the corresponding averaged coverage fraction is at least the same kappa. Summing its dyadic positive background bands gives

    lambda |E_high| <=(3/(B kappa))[1+log2+1/t] W.

These are sufficient conditional returns, using (3), the actual Cauchy inequality and the fixed band definitions. Exceptions require their own volume budget. A dimension-only lower bound for the actual B_t^avg at t near 1/sqrt(n), or another sufficient tuning, remains UNPROVED. The base kernel and full-scale localization also remain explicit debts. The random lift, LP and rounding do not finish the main theorem.

## 9. Executed guard record and scope

The embedded standard-library guard below was actually executed. Stage one uses exact rational arithmetic for the noise-moment bound, marginal discrimination and clock-ratio inequality. Three genuine E2 stages use n=1,2,3, three original sites, the actual w density, noise cutoff R=2, and the actual maximum-absolute-contrast selector from L in {1,1.5,2}. Noise rectangles are integrated against w by its exponential-mixture formula, not replaced by noise atoms. The guard checks restricted Cauchy, both forms of (4), and all six common-clock orders for a capacity-complete three-packet family. An independent latent-noise sampler checks the common representative gate probability. Its analytic formula has the exact target law under ideal continuous random numbers; the actual random.random, log and sqrt computation is a finite-machine diagnostic. The gate_quad label denotes Simpson quadrature, not an exact or interval-certified probability.

The 128/256-panel refinement differences and Monte Carlo errors are diagnostics, not certified interval bounds. Receiver sums check algebra and rounding on these actual fixtures, not a continuous spatial integral or a uniform finite-t coverage bound. The proof of rounding is Section 5, not the numerical experiment. No desired weak endpoint bound is claimed from these tests.

Guard SHA-256: `fdcb10775c337f211e12ecdd6d2b6ddcf1ddd0ae52cc4368edb43f1fa866c392`.

Executed stdout:

```text
stage n=1 receivers=4 actual_scales=3 E2_refinement=1.48e-08 clock_ratio=0.990775 gate_quad=0.832829 gate_MC=0.830500 peak_abs_T=0.123995
stage n=2 receivers=16 actual_scales=3 E2_refinement=3.27e-08 clock_ratio=0.988024 gate_quad=0.703888 gate_MC=0.712167 peak_abs_T=0.198788
stage n=3 receivers=64 actual_scales=3 E2_refinement=3e-08 clock_ratio=0.967035 gate_quad=0.448059 gate_MC=0.450500 peak_abs_T=0.15982
PASS assertions=5726; exact noise-moment and clock guards; numerical true-E2 checks are diagnostic only
```

Replay: extract the following single Python fence and run with Python 3; only the standard library is required.

```python
from fractions import Fraction as Q
from math import comb, exp, prod
from itertools import product, permutations
from functools import lru_cache
import random
checks=0
def ck(v):
 global checks
 assert v
 checks+=1
for n in (1,2,3,8,16,32):
 for d in (Q(1,64),Q(1,8),Q(1,2),Q(1)):
  I=Q(0); moment=Q(0)
  for k in range(n+1):
   a=(d/2)**k*(1-d/2)**(n-k); b=d**k*(1-d)**(n-k)
   j=2*(a-b)**2/(a+b) if a+b else Q(0)
   I+=comb(n,k)*j; moment+=comb(n,k)*k*j
  ck(I>=4*d/(3*(4-3*d))>=d/3)
  ck(moment<=3*n*d)
  ck(I+Q(2,3*n)*moment<=I+2*d<=7*I)
# Exact perspective convexity and clock-ratio arithmetic, including t=0.
for t in (Q(0),Q(1,4),Q(1),Q(3)):
 p=2+t
 ck(p*(p-2)>=0)
 for alpha in (Q(1,100),Q(1,4),Q(1,2),Q(1)):
  ck(alpha/(1+t-t*alpha)>=alpha/(1+t))
# Actual w-interval integration: integrate the exact exponential mixture in t.
# Simpson error comparisons below are diagnostics, NOT interval certificates.
@lru_cache(None)
def wint(lo,hi,steps):
 if hi<=lo:return 0.
 def inner(t):
  if t==0:return 0.
  if hi<=0:return t*(exp(hi/t)-exp(lo/t))
  if lo>=0:return t*(exp(-lo/t)-exp(-hi/t))
  return t*(2-exp(lo/t)-exp(-hi/t))
 return (inner(0)+inner(1)+sum((4 if k%2 else 2)*inner(k/steps) for k in range(1,steps)))/(3*steps)
bins=((-2.,-.25),(-.25,.25),(.25,2.))
def experiment(n,steps):
 d=.5; masks=list(product((0,1),repeat=n)); cells=list(product(range(3),repeat=n))
 ys=[tuple(0.07*(j+1) for j in range(n)),tuple(-.11*(j+1) for j in range(n)),tuple(.45*(-1)**j for j in range(n))]
 ps=(.2,.3,.5); co=[]
 for m in masks:
  k=sum(m); a=(d/2)**k*(1-d/2)**(n-k); b=d**k*(1-d)**(n-k)
  co.append(((a+b)/2,2*(a-b)**2/(a+b),a-b))
 def masses(x=None,L=1):
  out=[[0.]*3 for _ in range(3)]
  for y,p0 in zip(ys,ps):
   for cell in cells:
    g=sum(cell)%3
    for m,c in zip(masks,co):
     val=p0
     for j in range(n):
      lo,hi=bins[cell[j]]
      if x is not None:lo=max(lo,(x[j]-y[j])/L-.5);hi=min(hi,(x[j]-y[j])/L+.5)
      if hi<=lo:val=0.;break
      val*=wint(lo,hi,steps) if m[j] else float(lo<=0<=hi)
     for typ in range(3):out[typ][g]+=c[typ]*val
  return out
 ws=masses(); rows=[]
 for x in product((-.8,-.2,.35,.9),repeat=n):
  choices=[]
  for L in (1.,1.5,2.):
   aa=masses(x,L); vals=[sum(a)/L**n for a in aa]
   ck(vals[2]**2<=vals[0]*vals[1]+2e-13)
   choices.append((abs(vals[2]),L,aa,vals))
  _,L,aa,vals=max(choices,key=lambda v:v[0]) # ONE actual contrast selector
  rows.append((x,L,aa,vals))
 worst=1.; peak=0.; witness=None
 for typ in (0,1):
  # Receiver quadrature weights are all one: algebra/rounding witness only.
  def score(groups):
   value=0.
   w=sum(ws[typ][g] for g in groups)
   if w==0:return 0.
   for x,L,aa,vals in rows:
    F=sum(aa[typ]);a=sum(aa[typ][g] for g in groups)
    if F:
     direct=vals[typ]*(a/F)**2*(a/w)
     formula=a**3/(L**n*F*w)
     ck(abs(direct-formula)<=1e-12)
     value+=formula
   return value
  packets=({0,1},{1,2},{0,2}); objective=sum(score(p) for p in packets)/2
  rounded=[]
  for order in permutations(range(3)):
   seen=set(); total=0.
   for k in order:
    assigned=packets[k]-seen; seen|=packets[k];total+=score(assigned)
   ck(seen=={0,1,2});rounded.append(total)
  ck(sum(rounded)/6>=objective/2-1e-12)
  ratio=(sum(rounded)/6/objective) if objective else 1.
  worst=min(worst,ratio)
  for x,L,aa,vals in rows:
   peak=max(peak,abs(vals[2]))
  if typ==0:witness=max(rows,key=lambda row:abs(row[3][2]))
 return ws,rows,worst,peak,witness
for n in (1,2,3):
 coarse=experiment(n,128); fine=experiment(n,256)
 err=max(abs(x-y) for a,b in zip(coarse[0],fine[0]) for x,y in zip(a,b))
 err=max(err,max(abs(v-w) for r,s in zip(coarse[1],fine[1]) for v,w in zip(r[3],s[3])))
 ck(err<2e-5)
 # Independent common representative gate Monte Carlo using exact latent sampler.
 random.seed(76011+n); x,L,aa,vals=fine[4]; ntrials=6000; got=0; accepted=0
 while accepted<ntrials:
  endpoint=random.randrange(2);prob=.25 if endpoint==0 else .5
  z=[]
  for j in range(n):
   if random.random()>=prob:z.append(0.)
   else:
    from math import sqrt,log
    z.append((1 if random.randrange(2) else -1)*sqrt(random.random())*(-log(max(random.random(),1e-300))))
  if max(map(abs,z))>2:continue
  u=random.random();idx=0 if u<.2 else 1 if u<.5 else 2
  y=[tuple(.07*(j+1) for j in range(n)),tuple(-.11*(j+1) for j in range(n)),tuple(.45*(-1)**j for j in range(n))][idx]
  got+=all(abs(x[j]-y[j]-L*z[j])<=L/2 for j in range(n));accepted+=1
 expected=sum(aa[0])/sum(fine[0][0]); observed=got/ntrials
 ck(abs(expected-observed)<.055)
 print('stage n=%d receivers=%d actual_scales=3 E2_refinement=%.3g clock_ratio=%.6f gate_quad=%.6f gate_MC=%.6f peak_abs_T=%.6g'%(n,len(fine[1]),err,fine[2],expected,observed,fine[3]))
print('PASS assertions=%d; exact noise-moment and clock guards; numerical true-E2 checks are diagnostic only'%checks)
```


# R76：真实赢家上的 fullness-only 覆盖障碍

状态：以下命题给出完整解析证明。它否定一种充分条件代理的统一覆盖，不否定实际几何门、中心点代表类、完整阈值带覆盖或目标弱型上界。数值程序 `majority_guard.py` 仅核验有限实例和解析公式，不代替证明。此处使用更新 D04 的有限概率 KL 分解、L03 的有理证书边界；不引用未经阅读的外部定理。

## 1. 定义与实际赢家

令 n≥2，μ 为 {−1,1}^n 上均匀概率，ε=1/(100n)。对 j=1,…,n 和 σ∈{−1,1}，取正体积矩形 U_{jσ}：x_j=σs，2+2ε≤s≤2+3ε，其余坐标 |x_k|≤ε。不同矩形不交。记 U 为它们的并，观察测度始终为原始 dx。

固定 x∈U_{jσ}。全部 σy_j=1 的顶点在同一 ℓ∞ 距离 r₁=s−1 到达，全部 σy_j=−1 的顶点在 r₂=s+1 到达。因为其他坐标距离≤1+ε<r₁，没有额外到达批次。半径之间累计质量不变而平均下降；故完整全尺度最大值只能在两个批次后取得。两候选为

    M₁=(1/2)/[2(s−1)]^n,  M₂=1/[2(s+1)]^n.

有 M₂/M₁=2[(s−1)/(s+1)]^n<1（s≤2.015，n≥2 已足够），所以第一批次为唯一最大赢家。真实 Q(x)=x+[-r₁,r₁]^n，F=μ(Q)=1/2，M=M₁。批次内部不允许逐原子累积制造伪赢家。

令 m_min=1/[2^(n+1)(1+3ε)^n]，λ=3m_min/4。U 上 M 的最大/最小比为 [(1+3ε)/(1+2ε)]^n≤exp(nε)<100/99<3/2。因此 λ<M≤2λ，U 真正包含于原始全尺度阈值带。各矩形的 T-流量 ∫M dx 完全相等（坐标置换及符号翻转保持 μ 和 M）。记总流量 T_U>0。

## 2. 被审计的代理，不是实际几何覆盖

允许共同选择的分数源包 f_P μ，0≤f_P≤1，质量 p_P=∫f_P dμ>0；整顶点子集对应指标函数。包跨接收点固定。给定非负系数 α_P，要求源容量 ∑_P α_P f_P(y)≤1 对每个顶点成立。先处理任意有限族，结论再取所有有限族上确界。

在 x∈U_{jσ} 定义包的自身捕获比例

    θ_P(x)=∫_Q f_P dμ/p_P,

及接收端后验 π_P(x)=∫_Q f_P dμ/F=2p_P θ_P(x)。两者不可混同。对 t>0，定义 fullness-only 目标

    M_t(U)=sup_α ∫_U M(x)∑_P α_P 1_{θ_P(x)>2/3} π_P(x)^(1+t) dx.

这个指标是保证二维坐标中心点落入条带的一种充分条件。把它强行作为所有有效覆盖的必要门会损失如下数量级。

## 3. 熵预算给出严格上界

令 Q_P=f_P μ/p_P，m_j=E_{Q_P} y_j。则 θ_{jσ}=(1+σm_j)/2，因此好的有向坐标面数量为 h_P=#{(j,σ):σm_j>1/3}。每个 j 至多一个 σ 好。

令 d₀=D(Ber(2/3)||Ber(1/2))=(2/3)log(4/3)+(1/3)log(2/3)>0。KL 方向固定为包的条件分布相对于原始均匀乘积律。有限空间上所有涉及的 KL 都有限，0log0=0。因为 f_P≤1，

    D(Q_P||μ)=E_Q log(f_P/p_P)≤log(1/p_P).

另一方面，精确展开有限和得

    D(Q_P||μ)=D(Q_P||⊗_j Q_{P,j})+∑_j D(Q_{P,j}||Ber(1/2))
               ≥∑_j D(Q_{P,j}||Ber(1/2)).

Q_P 在某个边缘概率为零的坐标值上也为零，故第一项绝对连续且定义合法。非负性由 log u≤u−1 直接得到。此分解不假设 Q_P 的坐标独立，只用参考 μ 为乘积律。二元 KL 关于 |m_j| 单调；每个好坐标贡献至少 d₀，故 h_P d₀≤log(1/p_P)。

每个矩形上的 π_P 恒定且≤2p_P，流量相等，故该列的归一化收益至多

    (h_P/(2n))(2p_P)^(1+t)
    ≤[2^t/(n d₀)] p_P^(1+t)log(1/p_P).

容量积分给 ∑α_P p_P≤1，而 sup_{0<p≤1} p^t log(1/p)=1/(et)。于是

    M_t(U)/T_U ≤ min{1, 2^t/(e d₀ n t)}.                    (P76.1)

上界 1 来自 π_P^(1+t)≤π_P 和 ∑α_P π_P≤1。即使允许任意分数源包，上界仍成立。

## 4. 同阶下界，不依赖数值拟合

用前 k 个坐标的符号把全源分为 2^k 个等质量子立方体，1≤k≤n，给每包 α=1。包质量为 2^−k。对 j≤k，在相符的有向面有 θ=1、π=2^(1−k)，不相符则 θ=0；j>k 时所有包 θ=1/2，被代理门排除。因此直接求和得

    M_t(U)/T_U ≥ (k/n)2^(−t(k−1)).                        (P76.2)

特别地 t=1/√n，取 k=⌊√n⌋。有 k≥√n/2 且 t(k−1)≤1，故下界≥1/(4√n)；n=k² 时更精确≥1/(2√n)。与 (P76.1) 合并，得到 fullness-only 代理在该真实赢家子事件上恰为 Θ(n^−1/2)。常数绝对，指数由证明而非拟合确定。因此它不能单独提供所需 n^−o(1) 覆盖比例。

## 5. 实际几何门没有这一障碍

取整个源作为一个包，质量1，其后验 π≡1。固定代表 c₊=(1,…,1) 属于全部 Q(x)，x∈U_{j,+}：第 j 坐标距离恰为 r₁，其余坐标距离≤1+ε<r₁。负面不属于该门。于是单个完整源列已获得 T_U/2；实际固定代表覆盖至少为1/2，对所有 t≥0 成立。

在零噪声提升 z=0 时，(a_j,b_j)=(1,0) 本身也是 (y_j,z_j) 的深度至少1/3中心点：任意含此点的闭半平面包含至少 y_j=1 那一半质量。因此本例没有否定允许优化中心点的实际门覆盖；只是证明“θ>2/3”不能取代实际几何门。随机源代表的全包平均门同样恰给 1/2，也避开该代理反例。

## 6. 弱型与范围结算

U 只是完整阈值带的一部分，不能据此声称完整带的代理比例亦小。更不能把局部覆盖损失写成弱型下界。事实上 |U|=n2^n ε^n，故

    λ|U|=3n ε^n/[8(1+3ε)^n]≤3n ε^n/8.

其弱型费用极小。若未来选择删去此类区域，必须对全部任意输入提供删除预算；本例的计算本身并不提供这种一般结算。

结论：保留实际仿射门或随机源代表门；中心点的高捕获充分判据可作为一个分支，但必须给其余分支独立覆盖及预算。当前一般近核覆盖仍未证明，C_n 的全一般已保留上界仍为 O(n log n)。


# Round 76: actual E2 affine-gate exploration

The completed experiment finds a paid affine-gate gain in two controlled actual-scale-selection examples, while the original eight near-field, correlated-group and tail-strip examples show no paid gain. The gain comes from a common whole-source packet moving across selected scales with slope `b=(1/2,…,1/2)` and geometric fee one. It is retained on two independent held-out batches. These examples use a one-sided receiver subdomain and the large fixed low-background parameter `B=1024`; they do not establish general core coverage. Fixed-scale deep-tail obstructions also survive the affine enlargement. The general centered-cube target remains unproved.

The rational LP witnesses certify the archived, rounded **floating finite receiver functional only**. Actual E2 kernel evaluation uses ordinary Simpson quadrature and floating arithmetic without an outward interval enclosure. No certified continuous-kernel coefficient, spatial integral, full-event upper bound or asymptotic order is claimed.

## Actual source, kernels and selectors

Each fixture is one original positive finite atomic probability measure `mu=nu=sum_i p_i delta_yi`, with distinct rational sites, positive rational weights and no receiver-dependent source grouping. Dimension is `n=1,…,4`, source count `N=4,6,8`, and `delta=1/max(n,2)`. Use the actual E2 definitions

`h=1_[−1/2,1/2]`, `phi(x)=integral_0^1 integral_[−1/2,1/2] exp(−|x−u|/t) du dt`.

For every hard/soft mask with s soft coordinates, `a=(delta/2)^s(1−delta/2)^(n−s)`, `b=delta^s(1−delta)^(n−s)`, `qmask=(a+b)/2` and `jmask=(a−b)^2/qmask`. The kernels are `K=sum qmask kmask`, `J=sum jmask kmask`, and the contrast is the difference of the two endpoint tensor products. All three use the same original source and the same physical scale. `K` has mass one, `J` has mass `I=sum jmask`, and the actual identities give `J≤4K` and `|T|²≤FC`. The code checks the latter ratios at every evaluated point, including the small tail values. These are the physical E2 kernels, not independently assigned posterior vectors or an auxiliary radial proxy.

The registered physical family is `{1,5/4,3/2,7/4,2}`. Two Borel selectors are tested: the smallest scale maximizing actual `|T_L|`, and the smallest scale with `|T_L|>lambda`. The first retains the earliest scale on a tie. Receivers with no crossing are omitted. For low tests, the event is the actual selected crossing intersected with `F≤B lambda`, and the posterior/occupation use `C`. For high tests, the event is the crossing intersected with the first high band `B lambda<F≤2B lambda`, and the posterior/occupation use `F`. No private packet scale or independently optimized packet selector is used.

Receivers are uniform in a registered box, correlated tube or thin strip. Coordinates are saved as exact binary rationals, so physical gate comparisons and all geometric fees are exact. The kernel values and selector decisions are floating diagnostics. The observed domain is explicitly part of each fixture: these objectives are not integrals over the entire selected low/high branch. Each sampled contribution is `volume(domain)·G/lambda`, times the normalized packet score, averaged over the full sample count; non-event draws contribute zero.

## Common affine library and capacity accounting

An affine representative is fixed as `(a,b)` across all receivers, with gate

`g_(a,b)(x)=1{ |x_i−a_i−L(x)b_i|≤L(x)/2 for every i }`.

Its geometric fee is the exact rational number `C(b)=1+sum_i (|b_i|−1/2)_+/n`. The paid column coefficient is the finite average of `G/lambda·g·pi_P^q/C(b)`, where `pi_P` is the actual K- or J-posterior of the same source subset P. All nonempty source subsets are enumerated. The tested exponents are `q=2` and `q=1+1/sqrt(n)`; coincident exponents at n=1 are not repeated. Irrational powers are floating evaluations before coefficient rounding.

Anchors are source sites, the whole-source bounding-box center, and registered group bounding-box centers. Slopes include zero, each coordinate direction with magnitude `1/2,1,2`, diagonal directions of those magnitudes, and three preregistered positive tail slopes for the strip fixtures. The fixed comparison contains **every** position `a+L_j b` along these registered trajectories. The paid affine class contains that entire fixed comparison as zero-slope columns as well as the moving columns. Thus an apparent gain cannot arise from merely omitting fixed trajectory positions. The unpaid affine comparison uses the identical enlarged library but deliberately omits the fee; it is only a diagnostic.

All three families also include ungated original-source singleton columns with fee one. Thus they are hybrid singleton/gated families, not purely affine-gated families. Singleton and nonsingleton columns share the same capacities `sum_(P contains i) alpha_P≤1`; no source is charged separately to each representation type. Since all fees are at least one and q≥1, the aggregate score is at most one pointwise. The archived checks confirm this for the chosen primal families. No representative, subset, coefficient or source assignment is chosen anew on a held-out receiver.

## Exact finite LP scope and error

For each subset, the best registered representative is selected using the training average, after applying its fee. The resulting nonnegative binary floating coefficient is rounded downward to denominator `2^40`. A copied small-N rational simplex solves the complete source-capacity master. Exact Fraction arithmetic checks nonnegative primal/dual values, every site load, every subset dual inequality and equal primal/dual objectives. There is no floating basis proposal in this round.

The coefficient-floor objective error is at most `N/2^40` for the **computed floating functional**, because each nonempty column consumes at least one site and `sum alpha≤N`. This controls neither quadrature, floating sums/powers, event selection nor the approximation of a Lebesgue integral. The training ratios printed below divide the rounded optimum by the floating training occupation and are decimal diagnostics, not certified actual-kernel ratio enclosures.

The geometric guard independently checks exact interval hull length (7), planar convex-hull area (49), visible-face simplex determinants (55), and homothetic containment (75). For a cube translated by b, the cube plus the visible pyramids from the origin has volume C(b); the determinant checks verify the fee for n≤4. These exact geometry checks do not certify E2 quadrature or supply a coverage theorem. The physical soft bound `u_P≤I w_P/L^n` for J, or `u_P≤w_P/L^n` for K, follows from the actual kernel height bound; the parent theory supplies the affine envelope/payment argument.

## Development, registration and numerical outcome

The first pilot used three near-box sources with 64 training and two 128-draw validation batches each: 192 training draws, 768 held-out draws and 18 exact rounded-coefficient LP witnesses. The completed original eight-source pressure stage enlarged training to 256 draws and validation to two 512-draw batches: 2,048 training draws, 8,192 held-out draws and 180 witnesses, in 38.1419 seconds. It found no paid affine gain in any of its 60 objective cases. Four cases improved only when the affine fee was omitted. Pilot samples are prefixes of the enlarged registered samples, not extra independent replications.

An exploratory actual-kernel test then motivated two one-sided scale-tracking sources. Their source/domain/threshold registration was frozen before the final two held-out batches, using new training seeds. This is adaptive exploratory design, not a preregistered universal search. An earlier incomplete pressure attempt was interrupted to make the affine library contain the complete enriched fixed baseline; it is not counted as a completed final result.

The final archive has 10 sources, 2,560 training draws, 10,240 held-out draws and 216 equal-objective rational LP witnesses across 72 objective cases. Sixteen cases have no training event receivers and are retained as empty finite witnesses; this does not certify an empty spatial event. Three objective cases have paid gain: the n1 scale-tracking q2 case and both exponents of the n2 scale-tracking case. The latter two use the same whole-source packet and therefore have identical values. All other cases have equal paid and fixed training optima. There is no dimension-order fit or numerical n8 extrapolation.

The table reports the max-|T| low branch at q=2. All training ratios are approximate rounded-floating-functional values. Held-out packing and occupation are shown separately for each 512-draw batch, in units of the domain integral divided by lambda; they need not be below one.

| Source | n/N | lambda; B | training event count | fixed → paid affine training ratio | affine packing, seed 1; seed 2 | occupation, seed 1; seed 2 |
|---|---:|---|---:|---:|---|---|
| near box grid | 1/4 | .015; 8 | 154 | .50705 → .50705 | 2.13874±.14858; 1.98133±.14467 | 4.12035±.15928; 4.08267±.15776 |
| near box grid | 2/4 | .015; 8 | 46 | .40423 → .40423 | 1.45685±.31997; 1.77762±.36949 | 5.07146±.57535; 4.99478±.54952 |
| near box grid | 3/8 | .015; 8 | 11 | .73508 → .73508 | 5.41887±1.12251; 3.89121±1.00701 | 8.09561±1.33071; 7.68377±1.32918 |
| near box grid | 4/8 | .015; 8 | 4 | ≈1 → ≈1 | 3.04091±1.51600; 3.78490±1.68615 | 4.54555±1.84665; 4.52473±1.83834 |
| correlated three groups | 2/6 | .004; 8 | 19 | .98169 → .98169 | .39098±.07667; .56758±.08874 | .40169±.07797; .58207±.09028 |
| correlated three groups | 4/6 | .004; 8 | 38 | .82324 → .82324 | .13735±.01717; .12869±.01638 | .15853±.01911; .14809±.01833 |
| tail strip R8 | 2/8 | 6.54291e−5; 2 | 256 | .73985 → .73985 | .02947±.00069; .02840±.00072 | .03801±.000028; .03807±.000028 |
| tail strip R24 | 2/8 | 4.50973e−9; 2 | 256 | .25171 → .25171 | .02853±.00216; .03006±.00220 | .11505±.000116; .11499±.000118 |
| one-sided scale tracking | 1/4 | .001; 1024 | 256 | .96862 → ≈1 | 163.21820±5.35280; 173.48460±5.48754 | 163.21820±5.35280; 173.48460±5.48754 |
| one-sided scale tracking | 2/4 | .001; 1024 | 256 | .90936 → .93194 | 187.81695±13.33259; 205.91184±14.34487 | 199.37037±13.03887; 219.22132±13.99742 |

Three findings give the mechanism and its limits. In the n1 scale-tracking example, the four sites are `j/64`, j=−3,−1,1,3, and the receiver interval is `[−3/64,7/4]`. The fixed whole-packet representative is `29/64`, while the paid affine winner is `a=−3/64,b=1/2,C=1`. The selected-scale counts are 72,20,25,28,111. Its paired held-out affine-minus-fixed gains are `5.75133±.56398` and `5.00332±.53165` (one sample SE).

In n2 the sites are `(j/64,j/64)` and the receiver box is the square with those same bounds. The analogous diagonal affine packet also has fee one. Selected-scale counts are 61,38,34,24,99. The paired held-out gains are `3.67369±.37124` and `3.34305±.36239`. Under the first-crossing selector, almost all points use L=1 and the gain disappears in both dimensions. These are diagnostic finite-library gains; they do not compare with every fixed representative in the continuum. The large B admits near and far traffic to the same low event and must not be hidden.

In the actual E2 tail strips, all selected scales are L=2. The normalized occupation grows from about .0380 to .1150 while the best frozen packing stays near .029. Their training ratios fall from .73985 to .25171. R=8 and 24 avoid underflow and are finite exploratory analogues, not evaluations of the R75 proved R≥1000 asymptotic bound. More generally, on a singleton physical family `{L0}`, every affine gate is the fixed gate at `a+L0 b`, with fee at least one. Thus the R75 full actual low-branch fixed-scale counterexample applies to normalized affine-only coverage as well, including the same ungated singleton baseline. Moving gates cannot repair that universal obstruction by themselves.

## Quadrature, sampling and reproduction

For the first 12 training receivers per source, all physical-scale F,C,T values were recomputed with 512 rather than 256 Simpson panels. The largest absolute change was `3.56081e−8`, the largest relative change `7.77868e−7`; no tested selector or event changed. The smallest tested threshold margin in the tail examples was about `7.65e−10`, still much larger than their observed refinement change. These are refinement diagnostics on 120 points, not error intervals or checks of every training/validation point. Small changes can affect hard-boundary/threshold decisions elsewhere, and SEs do not cover that uncertainty.

The two held-out batches use the same event, source, selector and frozen trained primal representatives. Their differences are paired on identical receivers. Means and SEs are ordinary floating sampling diagnostics. A formal ideal-law bounded-sample range is `4B·volume(domain)` for low scores and `2B·volume(domain)` for the first high band; resulting Hoeffding radii would be wide, especially for B=1024. Exact finite-machine pseudorandom generation, quadrature and threshold evaluation are not certified continuous sampling/integration laws, so no rigorous confidence statement is inferred from the displayed SEs.

All fixture definitions and libraries, training receiver coordinates and actual evaluated kernels, complete rational coefficient tables, chosen representatives, primal/dual witnesses, per-batch held-out statistics, paired differences and replay seeds are archived. For source index sid=0,…,9, training seed is `761000+sid`, and held-out seeds are `762000+10sid` and `762001+10sid`. Held-out receiver coordinates are regenerated, not stored. The final JSON uses compact formatting and is 7,048,010 bytes.

Final production exited zero in 42.892251167 seconds. The independent audit checked 216 equal-value LP witnesses and 28,584 dual inequalities, directly reconstructed all 28,584 coefficients from archived actual-kernel rows with separate subset sums and rational common gates, and checked 14,772 training pointwise packing scores. Independent geometry checks also passed. Its full temporary-copy replay exited zero in 43.6196 seconds and produced byte-identical JSON with the frozen results hash. No SciPy, network, Git, compilation or old-round modification was used.

Reproduce from a temporary copy so the archived JSON remains intact:

```sh
stage_dir=$(mktemp -d)
cp /Users/zhengzhihao/Desktop/T/output/centered_cube_round076_20261011/affine_probe.py "$stage_dir/affine_probe.py"
/Users/zhengzhihao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 "$stage_dir/affine_probe.py"
cmp "$stage_dir/affine_results.json" /Users/zhengzhihao/Desktop/T/output/centered_cube_round076_20261011/affine_results.json
```

The script is standard-library Python and was run under bundled Python 3.12.14. `--pilot-only` is available on a temporary copy. Runtime is printed and excluded from the deterministic final JSON. Source SHA256: `78b934af40b2516c8b302c55be3fc3f96fe1fa8d51576abd9296cbcf642062dc`. Results SHA256: `6bfa0bf0fd3b7ebf0ae1cfa978650e09aabda21814079ecc40cf3450562dbbb3`.


# 第 76 轮独立审计

本轮的共同仿射代表成本和产品核平移包络公式成立；它们提供质量支付接口，不自动给出用于原弱型结论的覆盖定理。主目标的统一 `sqrt(n)` 上界仍未证明。数值证书已完成冻结哈希检查、独立有限泛函重建与临时副本完整重放；范围见文末。

## 全维立方体成本与共同选择

令 `B_b=b+[-1/2,1/2]^n`。以球面面积测度 `dσ` 计，

`C(b)=(1/n)∫ sup_{r>0} r^n 1_{B_b}(rθ) dσ(θ)=|conv({0},B_b)|=1+(1/n)Σ_i(|b_i|−1/2)_+`。

第一等式来自极坐标：`conv({0},B_b)=⋃_{0≤s≤1}sB_b`，每条射线上的最大半径决定星形包络体积。原点在立方体内时体积为 1；在外时增加的是原点与所有可见面的棱锥。除零测边界外，这些棱锥互不相交：射线首次进入立方体只能经过一个可见面。第 i 个可见面的面积为 1、垂直高度为 `(|b_i|−1/2)_+`，贡献高度除以 n。该证明适用于每个 n，无需高维数值积分。

分包的 `(a_P,b_P)` 必须作为一个共同列参数固定。允许任意共同可测选择 `L(x)>0`，包括无界选择；门

`g_P(x)=1{|x−a_P−L(x)b_P|∞≤L(x)/2}`

等价于 `(x−a_P)/L(x)∈B_{b_P}`。若实际分包贡献 `u_P≤G`，且在门内 `u_P≤m w_P L(x)^(−n)`，则

`G g_P (u_P/G)^(1+t) ≤ min(B,v,v^(1+t)/A^t)`，其中 `v=m w_P L(x)^(−n)1_{B_b}((x−a_P)/L(x))`，实际带为 `A<G≤B`。

固定射线并用角向上确界支配后，径向积分为 `H=1+log(B/A)+1/t`，故总支付不超过 `H m w_P C(b_P)`。门外贡献是零，不能把门内质量上界当成无门支配。`b_P=b_P(x)` 的私有接收点选择也不属于此固定成本结论。

由于 `C(b)≥1`，原有共同容量 `Σ_{P:s∈P}α_P≤1` 给出 `Σ_P α_P g_P π_P^(1+t)/C(b_P)≤Σ_P α_P π_P≤1`。每一归一化列支付 `H m w_P`；共同容量使总质量支付不超过 `H m W`。允许新提升源上的固定列，不要求其先投影到旧物理整点分包列；但若声称两个 LP 相等或引用旧 LP 的下界，则须证明投影关系。

## 平移产品核

令 `k=m∏_i k_i`，各因子取偶、非增的正规代表，`∫k_i=1`、`k_i(0)<∞`。其层蛋糕分解是对中心区间的正混合。半宽 `s_i>0` 的平移盒体积为 `V=∏2s_i`，星形包络体积为

`V[1+(1/n)Σ_i (|b_i|−s_i)_+/(2s_i)]`。

`sup_r` 的正次可加性和 Tonelli 因而给出

`C(k(·−b)) ≤ m[1+(1/n)Σ_i (|b_i| k_i(0)−∫_0^{|b_i|}k_i(v)dv)] ≤ m[1+(1/n)Σ_i |b_i|k_i(0)]`。

对单位立方体因子，较紧的中间项恰为 `(|b_i|−1/2)_+`。平移后核一般不再沿原点射线单调，因此不能直接套用旧的“角向包络成本≤核质量”；以上正混合论证才给出合法替代。因子高度无限时粗界允许为无限；点值应使用单调正规代表或相应本质上确界，不能任意修改零测集上的核值后仍引用点态包络。

## 随机平移提升、相平面中心点与覆盖边界

若 `K=H*ρ` 且 `ρ` 为固定概率测度，则

`F_L(x)=∫ H_L(x−y−Lz)dμ(y)dρ(z)`

是原 `dx` 上的精确恒等式，源测度为固定的 `η=μ⊗ρ`，质量仍为 `μ(ℝ^n)`，选择器仍是同一个 `L(x)`。这一步没有对接收点做变量代换。选择器依赖 x 时，`x↦x−L(x)z` 一般不保 Lebesgue 测度：`n=1,z=1,L(x)=x` 在 `[1,2]` 上塌缩为 0。

弱 L1 准范数不满足平均的 Jensen 不等式。在两个各测度 1 的区域上取 `f_1=(2,1),f_2=(1,2)`，各自弱 L1 准范数为 2，平均函数的为 3。因此提升恒等式不能通过平均各随机平移的弱型估计直接闭合目标。

对任意正质量分包 P，每个相平面边缘 `(y_i,z_i)` 存在半空间深度至少 `1/3` 的中心点 `(a_i,b_i)`。可直接用平面 Helly 定理证明：任意三个质量严格大于 `2/3` 的闭半平面交集具有正质量；加入一个质量大于 `2/3` 的紧凸球处理无限族，得到共同交点。若一个含中心点的闭半平面质量小于 `1/3`，其开放补集可内逼近为质量大于 `2/3` 的闭半平面，矛盾。

定义原分包捕获率 `θ_P=η_P{(y,z):x−y−Lz∈L[-1/2,1/2]^n}/w_P`。若 `θ_P>2/3`，每个坐标条带质量也严格大于 `2/3`。中心点在条带外将产生一个含中心点且与条带分离的闭半平面，质量至少 `1/3`，矛盾；故 `a_P+Lb_P∈Q(x,L)`。严格大于阈值不能改成大于等于。

深度也给出 `P(z_i≥b_i)≥1/3` 和 `P(z_i≤b_i)≥1/3`。逐坐标得到

`C(b_P)≤1+3 E_P(C(z)−1)=3 E_P C(z)−2≤3 E_P C(z)`。

共同容量使 `Σ α_P w_P C(b_P)≤3∫C(z)dη`。这是合法的分包费用矩估计。`θ_P` 是原分包质量捕获率，而接收点后验是 `π_P=F_P/F`；后验大不能推出分包充分捕获。细分能够改善原质量捕获，但可能让 `Σπ_P^(1+t)` 消失。因此中心点存在、门的充分条件和矩价格均未自动证明后验覆盖。

精确提升后的源可以包含模式与随机平移联合标签；若模式条件下平移律不同，应使用实际共同联合参考测度和相应密度，不能私自拆成独立后验。合法扩大源空间上的 LP 可以直接构成新证明接口；它与旧 whole-physical-site LP 的关系是另一个问题。

## 已实际运行的独立守卫

`audit_guard.py` 使用标准库有理算术。已运行 PASS：309 个 n=1,2,3 的独立凸包体积案例（3D 由全部支持平面和面三角剖分重建），32 个 n≤128 的闭式成本案例，150 个产品盒正混合较紧/粗成本比较，500 个共同源容量归一化案例。已显式检查选择器变量代换塌缩及弱准范数平均反例。当前单次实测 0.3199 秒；这些是数学回归与独立小维几何复核，非一般连续覆盖证书。

适用审计边界：A02 的正支配与预算、L03 的有理/区间证书范围、D04 的同一共同源与条件标签。本文没有把外部未核验定理或浮点采样当成主目标证明。

## 多数捕获接口的实际赢家子事件反例

独立核验了父任务的结构性构造。`μ` 是 `{−1,1}^n` 上均匀概率测度，`ε=1/(100n)`；`U_{j,σ}` 上 `x_j=σ[2+2ε,2+3ε]`，其余坐标在 `[−ε,ε]`。完整 arrival 只有 `r_1=|x_j|−1` 与 `r_2=|x_j|+1`；前者捕获 `y_j=σ` 的一半源，且密度严格胜出。因此实际赢家贡献 `M=(1/2)/(2r_1)^n`。各 `2n` 区域的交通量相等。`max_U M/min_U M<4/3`，以 `λ=(3/4)min_U M` 可使全部 U 落入真实 `λ<M≤2λ` 带。

对于分包质量 `p`、条件边缘均值 `m_j`，严格多数捕获要求 `σm_j>1/3`。设 `h` 为好定向坐标数，`d_0=D(Ber(2/3)||Ber(1/2))`。产品参考源的相对熵满足

`h d_0≤Σ_j D(Ber((1+m_j)/2)||Ber(1/2))≤D(μ_P/p||μ)≤log(1/p)`。

若允许分数分包 `dν_P=f_P dμ,0≤f_P≤1`，最后一步仍由 `log f_P≤0` 得到；共同容量 `Σα_P f_P≤1` 仍给 `Σα_P p_P≤1`。因此该结论不限于整点子集。

实际后验为 `π_P=2pθ_{j,σ}`。逐区域以 `θ≤1` 支配，严格多数分包覆盖交通比满足

`M_t(U)/T_U≤[2^t/(n d_0)]Σ_P α_P p_P^(1+t)log(1/p_P)≤2^t/(e d_0 n t)`。

这里没有遗漏定向区域的因子 2：每个区域交通为 `T_U/(2n)`，而后验幂提供 `2^(1+t)`。固定 k 个坐标的子立方体共同分区给出下界 `(k/n)2^(−t(k−1))`，取 `k≈1/(t log 2)` 与该阶匹配。于是 `t=1/sqrt(n)` 时此多数接口在 U 上只有 `O(1/sqrt(n))` 覆盖，而旧物理整源列取 `c=(1,…,1)` 或 `c=(−1,…,−1)` 各覆盖一半区域，给 `B_t(U)/T_U≥1/2`。

这是实际完整赢家与真实带内的子事件障碍，不是全带覆盖反例，更不是弱型常数下界，也未自动反驳 soft-full branch。`audit_guard.py` 独立枚举小维实际 arrivals：90 个精确赢家/代表门检查和 3 个精确带检查；另检查 782 个整点分包与 300 个分数分包的熵不等式。后两类日志计算明确属于浮点诊断，解析熵证明承担结论。

## 冻结数值证书与重放

归档生产代码 `affine_probe.py` 的 SHA-256 为 `78b934af40b2516c8b302c55be3fc3f96fe1fa8d51576abd9296cbcf642062dc`；`affine_results.json` 为 `6bfa0bf0fd3b7ebf0ae1cfa978650e09aabda21814079ecc40cf3450562dbbb3`。守卫检查此二哈希后才读取数值资料。

独立守卫没有调用生产 `coefficients`、`simplex` 或 `gate`：从归档实际 K/J/T 分量重新确定事件、共同物理选尺与后验，用 Fraction 重建仿射门和价格，直接求每个源子集的后验和，再遍历共同代表门图案。它核验全部 216 个精确有理原/对偶等值证书、28,584 条对偶不等式、28,584 个系数重建和 14,772 个训练接收点共同容量分数。涵盖 10 输入、2,560 个训练接收点。全部 PASS，包含数学与多数构造守卫的该次实测耗时 8.8184 秒。浮点泛函与其向下网格系数的最大重建差为 `9.09365898554837e−13`；比较容许不同合法浮点求和顺序的微小误差，此容许误差不参与精确 LP 证书。

另在独立临时目录复制冻结主代码，实际执行其几何先导、pilot 与完整压力三阶段，退出码 0、43.6196 秒。输出的 7,048,010-byte JSON 与冻结结果逐字节相同。主报告中的独立保留批次来自另设固定随机种子；重放覆盖其生成与保存，但重放本身不是独立积分证明。

证书认证的是归档的有理化有限泛函：K/φ 的 Simpson 积分、空间采样、选尺阈值和非整数幂先经过浮点计算。`N/2^40` 只控制该已计算有限泛函的向下量化 LP 误差，不控制实际核积分、真实阈值分类或连续域积分误差。π 被截到 1 的步骤也属于该有限浮点泛函。选尺仅覆盖注册的五个物理尺度；代表仅覆盖注册的有限库。不同分包可优化各自共同代表，所有分包共享实际选尺及源容量。另有明示的无门 singleton 基线，所以数值列族不是纯仿射门族。免费仿射列是诊断，不享有支付证明；收费仿射收益来自明确单侧子事件，并非统一覆盖结论。

已独立执行 `coverage.md` 内嵌守卫，退出码 0，guard hash `e1709948f087dea057bcb733f4bef98384e176c9b2a452c957acebc993ad0f3c`、stdout hash `9b32fa2f9594bafde032fca2c78332308b90f3e0f95c60ce002d368831b3ab88` 与报告一致；其支持平面/盒正混合、实际赢家、共同门三段上界与正提升测试全部通过。该报告的 §8 一尺度归约也成立：L=1 时 `a+b` 遍历原固定代表，而 `C(b)≥1` 且 b=0 实现最优收费归约，所以增加仿射参数不能绕开 R75 已证明的一尺度全 soft branch 障碍。旧障碍的积分常数本轮未重新推导。

父任务的 `majority_guard.py` 另经独立代码审查：atanh 对数正尾界与负 log2 倍数的区间方向、100 步有理根夹逼、e 的正 Taylor 尾界均正确。源子立方体熵等号使用明示的符号证书；一般分包使用有理日志上下界。XOR 平移轨道把最大单包 score/mass 实现为共同容量 LP，并以均匀源价格给出同值上界，故 n=4 没有伪称调用完整 LP 求解器。大维度是明确的隐式产品模型，分区优化用相邻比的整数幂比较，并未物化 `2^n` 顶点。

最终澄清字段后的临时副本实际重放退出码 0，496,515-byte 结果逐字节一致，结果 SHA-256 为 `bd067678798ba5ac23f67dacebd562a2007c7fa72cceffdce6dff935cb6fb827`，父守卫为 `1d4ba2e15e93a1c16f5c795f6173997681a43775e9aec3533a7aa48dd76d69eb`。本审计守卫另外使用整数 `isqrt` 独立重建全部 65,805 个小维子集的有理幂夹逼系数（没有调用父守卫的二分算法），核验 8 个有理 LP 原对偶等值证书与 1,080 条对偶不等式，以及全部子集最大 score/mass 区间。父解析终稿的非平方维下界 `1/(4sqrt(n))`、平方维 `1/(2sqrt(n))` 也正确；特别是原完整源代表 `(1,0)` 本来就是每坐标相平面的合法深度中心点，故本例没有反驳实际中心点门覆盖。

最终数值报告 `affine_numeric.md` 的 SHA-256 为 `e6026ff559d11d188ce6278b57c83064b49fca1c74158db0dd2805ddee776adf`。已独立阅读其解释、范围与复现指令，未发现额外实质问题。

## 随机共同代表新接口的关键审计

`soft.md` 的随机代表从固定共同源分包 `η|P/w_P` 抽取一次，再用于所有接收点。其平均门是 `a_P/w_P`，故实际分数为 `a_P^(2+t)/(L^n Fcap^t w_P)`；这正是对正空间积分的合法平均，没有平均弱准范数。

原质量和捕获质量的联合函数 `Φ(a,w)=a^p/w,p=2+t≥2` 是凸的，其 Hessian 行列式为 `p(p−2)a^(2p−2)/w^4≥0`，同质次数为 `p−1=1+t`，在 `0≤a≤w` 的零边界连续延拓。有限共同分包的 Boolean 单元上补齐容量至 1，才使条件在某列时钟 s 下，所有源点具有相同存活率 `r=exp(−(1−α)s)`。因此随机子包的捕获质量和总质量均按 r 缩放期望；联合 Jensen 加积分得到 `α/[1+t−tα]≥α/(1+t)`。只有有限共同时钟，故 nonatomic 提升源没有不可测独立随机场问题。这证明 `O_t^avg≤B_t^avg≤(1+t)O_t^avg`，不证明覆盖下界。

噪声矩预算也通过：K 的平均软坐标率 `3δ/4` 给 `M_K≤(1+δ/2)W`；`j≤4q` 给 `M_J≤(I+2δ)W`。一坐标 marginal discrimination 为 `4δ/[3(4−3δ)]`，所以 `I≥δ/3` 与 `M_J≤7IW` 正确。噪声截断 `|z|∞>R` 强迫实际 kernel 位移大于 `R−1/2`，因此旧尾界的指数变成 `3/4−R/2`，预算选半径 `3/2+2log[2n(1+nlog2)]+2a` 正确。实际低支返回的 `7B` 与高背景返回的 `3/B` 常数也核验无误。

`t=0` 通过共同生成分区的条件期望 L2 收敛得到 `O_0^avg=B_0^avg=T_E`，是 supremum 结论；不能把它转成统一有限 t 覆盖。原物理源投影不保噪声条件 kernel profile，本文与 soft 终稿均保留此边界。实际中心点门可优化，但继承代表未必仍为缩小子包的中心点；soft 没有错误套用受限类的 clock rounding。

本审计守卫补充独立正提升例与 exact generic 检查：600 个有理联合凸性/同质检查、100 个 Boolean 容量补齐案例、1,890 个实际硬仿射提升的共同随机代表积分恒等式。与上述所有数学、数值和多数构造检查合并，实测 9.4727 秒、PASS。

soft 最终内嵌守卫另经独立阅读与提取执行：5726 assertions 全部 PASS，实测 0.1775 秒，guard SHA-256 `fdcb10775c337f211e12ecdd6d2b6ddcf1ddd0ae52cc4368edb43f1fa866c392`。它在 n=1,2,3 使用真实 E2 的固定原源、噪声区间积分、同一个三尺度对比选择器，以及等速率三个共同包的六种时钟顺序；有限接收点数为 4、16、64。噪声生成公式 `Z=±sqrt(U) Exp(1)` 在理想连续随机数下确实给出密度 w；等概率选择两个 Bernoulli 端点再拒绝 `|z|∞>2` 给出正确截断 K 噪声律。实际执行的 random/log/sqrt 与 Simpson 概率均是有限机器浮点诊断，无连续采样或积分证书。终稿已把误导性的 `gate_exact` 标签改为 `gate_quad`，并说明理想采样公式与机器执行范围。此项没有从有限 receiver 测试推断主覆盖。

本次最终审读源稿 SHA-256：coverage.md 为 `0f9e7f2dc9ace095e4ba5319113344efff0e7ed33752a64ec7e666709104d672`；parent_majority.md 为 `4f1b3f53d40067de7febb43d3d50e1b57c44176847e4d07c7f8ad5eb4f7dab14`；soft.md 为 `fc6e6bd9be943c27ed441de343bda483cec459a7404e6554dbbab72b74cac09f`，其完整 LaTeX 源为 `fcc1f462e3a807e4caff4a310f2f9899c6b148fa7042a60fc8be136d78456ce7`。最终独立 audit_guard.py 为 `e60321733e93c138d621a8b0aeedf20e56f3d37048140cfed13f0be1667dccab`。

本审计只修改 audit.md、audit_guard.py；其余代码、结果与报告均只读，所有重放写入临时副本，无 Git 操作。


## 最终独立守卫 audit_guard.py

```python
#!/usr/bin/env python3
"""Independent R76 guard. Exact hull checks; no high-dimensional cubature."""
from fractions import Fraction as F
from itertools import combinations, product
from pathlib import Path
import hashlib
import json
import math
import random
import time

BASE = Path(__file__).resolve().parent

def sub(a, b):
    return tuple(x-y for x,y in zip(a,b))

def dot(a, b):
    return sum(x*y for x,y in zip(a,b))

def cross(a,b):
    return (a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0])

def hull2(points):
    p=sorted(set(points))
    def turn(a,b,c):
        return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
    lo=[]
    for x in p:
        while len(lo)>1 and turn(lo[-2],lo[-1],x)<=0: lo.pop()
        lo.append(x)
    hi=[]
    for x in reversed(p):
        while len(hi)>1 and turn(hi[-2],hi[-1],x)<=0: hi.pop()
        hi.append(x)
    return lo[:-1]+hi[:-1]

def independent_volume(b):
    """Convex hull of cube vertices and origin; exact supporting planes in 3D."""
    n=len(b)
    pts=sorted(set([tuple(F(0) for _ in b)]+[
        tuple(b[i]+v[i] for i in range(n))
        for v in product((F(-1,2),F(1,2)), repeat=n)]))
    if n==1: return pts[-1][0]-pts[0][0]
    if n==2:
        h=hull2(pts)
        return abs(sum(h[i][0]*h[(i+1)%len(h)][1]-h[i][1]*h[(i+1)%len(h)][0] for i in range(len(h))))/2
    assert n==3
    faces={}
    for a,c,d in combinations(range(len(pts)),3):
        normal=cross(sub(pts[c],pts[a]),sub(pts[d],pts[a]))
        if not any(normal): continue
        levels=[dot(normal,sub(p,pts[a])) for p in pts]
        if not (max(levels)<=0 or min(levels)>=0): continue
        face=frozenset(i for i,v in enumerate(levels) if v==0)
        faces[face]=normal
    volume=F(0)
    for indices,normal in faces.items():
        drop=next(i for i,x in enumerate(normal) if x)
        keep=[i for i in range(3) if i!=drop]
        lookup={tuple(pts[j][i] for i in keep):pts[j] for j in indices}
        h=[lookup[x] for x in hull2(lookup)]
        for i in range(1,len(h)-1):
            volume+=abs(dot(h[0],cross(h[i],h[i+1])))/6
    return volume

def cube_cost(b):
    return 1+sum(max(F(0),abs(x)-F(1,2)) for x in b)/len(b)

def math_checks():
    rng=random.Random(760311)
    counts={"exact_hull_cases":0,"high_dimension_formula_cases":0,"product_box_mixture_cases":0,"common_capacity_cases":0}
    for n in (1,2,3):
        fixtures=[tuple(F(0) for _ in range(n)),tuple(F(1,2) for _ in range(n)),tuple(F(2) for _ in range(n))]
        fixtures += [tuple(F(rng.randint(-12,12),4) for _ in range(n)) for _ in range(100)]
        for b in fixtures:
            assert independent_volume(b)==cube_cost(b),(n,b)
            counts["exact_hull_cases"]+=1
    for n in (1,2,4,8,16,32,64,128):
        for s,expected in ((F(0),F(1)),(F(1,2),F(1)),(F(1),F(3,2)),(F(2),F(5,2))):
            assert cube_cost((s,)*n)==expected
            counts["high_dimension_formula_cases"]+=1
    # Product mixtures of two normalized, even, monotone uniform factors.
    # Each product box has exact hull mass; compare its positive-mixture bound
    # to the sharper layer-cake formula and the stated coarser height bound.
    for n in range(1,7):
        for _ in range(25):
            b=[F(rng.randint(-16,16),4) for _ in range(n)]
            factors=[]
            for i in range(n):
                p=F(rng.randint(1,7),8)
                factors.append([(p,F(rng.randint(1,8),4)),(1-p,F(rng.randint(1,8),4))])
            mixed=F(0)
            for choices in product(*factors):
                weight=F(1)
                for p,s in choices: weight*=p
                mixed+=weight*(1+sum(max(F(0),abs(b[i])-s)/(2*s) for i,(p,s) in enumerate(choices))/n)
            height=[sum(p/(2*s) for p,s in factor) for factor in factors]
            integral=[sum(p*min(abs(b[i]),s)/(2*s) for p,s in factor) for i,factor in enumerate(factors)]
            sharp=1+sum(abs(b[i])*height[i]-integral[i] for i in range(n))/n
            coarse=1+sum(abs(b[i])*height[i] for i in range(n))/n
            assert mixed==sharp and sharp<=coarse
            counts["product_box_mixture_cases"]+=1
    # Arbitrary packet gates may depend on one common selector; normalization
    # preserves pointwise physical-source capacities because C(b)>=1.
    for _ in range(500):
        post=[F(rng.randint(1,20)) for i in range(8)]
        post=[x/sum(post) for x in post]
        packets=[(1<<i) for i in range(8)]
        rng.shuffle(packets)
        value=F(0)
        for mask in packets:
            p=sum(post[i] for i in range(8) if mask>>i&1)
            c=cube_cost(tuple(F(rng.randint(-12,12),4) for i in range(4)))
            gate=rng.randint(0,1)
            value+=gate*p*p/c
        assert value<=1
        counts["common_capacity_cases"]+=1
    # Fixed Lebesgue receiver measure is retained by a product lift, not by
    # a selector-dependent change of coordinates. Weak L1 has no Jensen rule.
    assert all(F(x)-F(x)*1==0 for x in (1,F(3,2),2))
    weak=lambda values:max(v*sum(w>=v for w in values) for v in values)
    assert weak([F(2),F(1)])==2 and weak([F(1),F(2)])==2
    assert weak([F(3,2),F(3,2)])==3
    return counts

def main():
    start=time.perf_counter()
    result={"status":"PASS", "independent_math":math_checks()}
    result['averaged_representative']=average_checks()
    result['majority_counter_diagnostics']=majority_checks()
    result['finite_functional']=numeric_checks()
    result['majority_rational_archive']=majority_archive_checks()
    result["elapsed_seconds"]=round(time.perf_counter()-start,4)
    print(json.dumps(result,sort_keys=True))

def majority_checks():
    rng=random.Random(760412)
    count={'exact_actual_winner_cases':0,'exact_band_checks':0,'packet_entropy_diagnostics':0,'fractional_packet_entropy_diagnostics':0}
    d0=(2/3)*math.log(4/3)+(1/3)*math.log(2/3)
    for n in (2,3,4):
        eps=F(1,100*n)
        atoms=list(product((-1,1),repeat=n))
        minM=F(1,2)/(2*(1+3*eps))**n
        maxM=F(1,2)/(2*(1+2*eps))**n
        lam=F(3,4)*minM
        assert lam<minM and maxM<=2*lam and maxM/minM<F(4,3)
        count['exact_band_checks']+=1
        for j,sign in product(range(n),(-1,1)):
            for step in range(5):
                x=[F(rng.randint(-4,4),4)*eps for i in range(n)]
                x[j]=sign*(2+2*eps+F(step,4)*eps)
                radii={max(abs(x[i]-y[i]) for i in range(n)) for y in atoms}
                scores={r:F(sum(all(abs(x[i]-y[i])<=r for i in range(n)) for y in atoms),len(atoms))/(2*r)**n for r in radii}
                winner=max(scores,key=scores.get)
                r1=abs(x[j])-1
                assert sorted(radii)==[r1,abs(x[j])+1] and winner==r1
                inside=[y for y in atoms if all(abs(x[i]-y[i])<=r1 for i in range(n))]
                assert len(inside)==len(atoms)//2 and all(y[j]==sign for y in inside)
                c=(sign,)*n
                assert all(abs(x[i]-c[i])<=r1 for i in range(n))
                count['exact_actual_winner_cases']+=1
        masks=range(1,1<<len(atoms)) if n<4 else [rng.randint(1,(1<<len(atoms))-1) for _ in range(512)]
        for mask in masks:
            subset=[y for i,y in enumerate(atoms) if mask>>i&1]
            p=F(len(subset),len(atoms));h=0;entropy=0.
            for j in range(n):
                theta=F(sum(y[j]==1 for y in subset),len(subset))
                h+=(theta>F(2,3) or theta<F(1,3))
                entropy+=sum(float(v)*math.log(2*float(v)) for v in (theta,1-theta) if v)
            assert h*d0<=entropy+1e-13 and entropy<=math.log(1/float(p))+1e-13
            count['packet_entropy_diagnostics']+=1
        for _ in range(100):
            f=[F(rng.randint(0,8),8) for y in atoms]
            p=sum(f)/len(atoms)
            if p==0:continue
            marginal=0.
            for j in range(n):
                theta=sum(v for v,y in zip(f,atoms) if y[j]==1)/(len(atoms)*p)
                marginal+=sum(float(v)*math.log(2*float(v)) for v in (theta,1-theta) if v)
            joint=sum(float(v/(len(atoms)*p))*math.log(float(v/p)) for v in f if v)
            assert marginal<=joint+1e-13 and joint<=math.log(1/float(p))+1e-13
            count['fractional_packet_entropy_diagnostics']+=1
    count['scope']='Winner and band checks exact; logarithmic inequalities numerical diagnostics accompanying the analytic entropy proof.'
    return count

def majority_archive_checks():
    frozen={'majority_guard.py':'1d4ba2e15e93a1c16f5c795f6173997681a43775e9aec3533a7aa48dd76d69eb',
            'majority_results.json':'bd067678798ba5ac23f67dacebd562a2007c7fa72cceffdce6dff935cb6fb827'}
    for name,digest in frozen.items():
        assert hashlib.sha256((BASE/name).read_bytes()).hexdigest()==digest,(name,'frozen hash mismatch')
    data=json.loads((BASE/'majority_results.json').read_text())
    count={'exact_subset_coefficients':0,'exact_LP_witnesses':0,'exact_dual_inequalities':0}
    cache={}
    def independent_power(s):
        if s not in cache:
            if s in (0,1):cache[s]=(s,s)
            else:
                # Integer square root, independent of production bisection.
                integer=math.isqrt(s.numerator*(1<<200)//s.denominator)
                lo=F(integer,1<<100);hi=lo+F(1,1<<100)
                assert lo*lo<=s<hi*hi
                cache[s]=(s*lo,s*hi)
        return cache[s]
    for case in data['all_subsets']:
        n=case['n'];N=1<<n
        assert F(case['t'])==F(1,2)
        plus=[sum(1<<i for i in range(N) if i>>j&1) for j in range(n)]
        coef={'fullness':({},{}),'physical':({},{})}
        best=[F(0),F(0)]
        for mask in range(1,1<<N):
            size=mask.bit_count();scores={'fullness':[F(0),F(0)],'physical':[F(0),F(0)]}
            for j in range(n):
                high=max((mask&plus[j]).bit_count(),size-(mask&plus[j]).bit_count())
                v=independent_power(F(2*high,N))
                for k in (0,1):scores['physical'][k]+=v[k]/(2*n)
                if 3*high>2*size:
                    for k in (0,1):scores['fullness'][k]+=v[k]/(2*n)
            for k in (0,1):best[k]=max(best[k],scores['fullness'][k]*N/size)
            if n<=3:
                for label in coef:
                    for k in (0,1):coef[label][k][mask]=scores[label][k]
            count['exact_subset_coefficients']+=1
        assert best==list(map(F,case['full_capacity_optimum_interval_by_translation_orbit']))
        if n>3:continue
        for label,key in [('fullness','LP_fullness'),('physical','LP_physical_vertex_library')]:
            for k,endpoint in enumerate(('lower','upper')):
                lp=case[key][endpoint];alpha={int(m):F(v) for m,v in lp['primal'].items()};dual=list(map(F,lp['dual']))
                coefficients=coef[label][k]
                assert all(v>=0 for v in alpha.values()) and all(v>=0 for v in dual)
                loads=[sum(v for m,v in alpha.items() if m>>i&1) for i in range(N)]
                assert loads==list(map(F,lp['loads'])) and all(v<=1 for v in loads)
                for mask,c in coefficients.items():
                    assert sum(dual[i] for i in range(N) if mask>>i&1)>=c
                    count['exact_dual_inequalities']+=1
                assert sum(alpha[m]*coefficients[m] for m in alpha)==F(lp['value'])==sum(dual)
                count['exact_LP_witnesses']+=1
    return count

def average_checks():
    rng=random.Random(760513)
    counts={'exact_joint_convexity_checks':0,'exact_capacity_completion_checks':0,'exact_common_random_representative_checks':0}
    for p in (2,3,4):
        for _ in range(200):
            w1=F(rng.randint(1,20),4);w2=F(rng.randint(1,20),4)
            a1=w1*F(rng.randint(0,8),8);a2=w2*F(rng.randint(0,8),8)
            z=F(rng.randint(0,8),8)
            assert (z*a1+(1-z)*a2)**p/(z*w1+(1-z)*w2)<=z*a1**p/w1+(1-z)*a2**p/w2
            assert F(2,3)**(p-1)*a1**p/w1==(F(2,3)*a1)**p/(F(2,3)*w1)
            counts['exact_joint_convexity_checks']+=1
    for _ in range(100):
        N=8;P=[rng.randint(1,(1<<N)-1) for i in range(5)]
        alpha=[F(rng.randint(1,4),32) for p in P]
        patterns={}
        for i in range(N):
            pattern=tuple(j for j,m in enumerate(P) if m>>i&1)
            patterns.setdefault(pattern,[]).append(i)
        completed=list(zip(P,alpha))
        for pattern,sites in patterns.items():
            load=sum(alpha[j] for j in pattern)
            completed.append((sum(1<<i for i in sites),1-load))
        for mask,rate in completed:
            for i in range(N):
                if mask>>i&1:
                    assert sum(a for m,a in completed if m>>i&1)==1
                    assert sum(a for m,a in completed if m>>i&1)-rate==1-rate
        counts['exact_capacity_completion_checks']+=1
    # An actual hard affine lift: a fixed source/noise point generates the
    # same gate at every scale; average its score over one fixed packet law.
    labels=[(F(-1,4),F(-3,4)),(F(-1,4),F(0)),(F(-1,4),F(3,4)),(F(1,4),F(-3,4)),(F(1,4),F(0)),(F(1,4),F(3,4))]
    weights=[F(i+1,21) for i in range(6)]
    for L in (F(1),F(3,2),F(2)):
        for x in (F(-1),F(-1,2),F(0),F(1,2),F(1)):
            gate=[abs(x-y-L*z)<=L/2 for y,z in labels]
            Fcap=sum(w for w,g in zip(weights,gate) if g)
            if not Fcap:continue
            G=Fcap/L
            for mask in range(1,64):
                mass=sum(weights[i] for i in range(6) if mask>>i&1)
                capture=sum(weights[i] for i in range(6) if mask>>i&1 and gate[i])
                for t in (1,2):
                    direct=sum(weights[i]/mass*G*(capture/Fcap)**(1+t) for i in range(6) if mask>>i&1 and gate[i])
                    assert direct==capture**(2+t)/(L*Fcap**t*mass)
                    counts['exact_common_random_representative_checks']+=1
    return counts

def numeric_checks():
    frozen={'affine_probe.py':'78b934af40b2516c8b302c55be3fc3f96fe1fa8d51576abd9296cbcf642062dc',
            'affine_results.json':'6bfa0bf0fd3b7ebf0ae1cfa978650e09aabda21814079ecc40cf3450562dbbb3'}
    for name,digest in frozen.items():
        assert hashlib.sha256((BASE/name).read_bytes()).hexdigest()==digest,(name,'frozen hash mismatch')
    data=json.loads((BASE/'affine_results.json').read_text())
    grid=data['coefficient_grid']
    counts={'sources':0,'training_rows':0,'LP_witnesses':0,'exact_dual_inequalities':0,'direct_coefficient_checks':0,'common_training_score_checks':0}
    max_float_difference=0.
    for src in data['sources']:
        counts['sources']+=1
        N=len(src['source']['y'])
        masks=list(range(1,1<<N))
        raw=src['training_receivers']
        counts['training_rows']+=len(raw)
        libraries={}
        for label,key in [('fixed','fixed_library'),('affine_paid','affine_library'),('affine_free_diagnostic','affine_library')]:
            reps=[]
            for rep in src[key]:
                a=tuple(map(F,rep['a']));b=tuple(map(F,rep['b']));cost=F(rep['fee'])
                assert cost==cube_cost(b)
                reps.append((a,b,F(1) if label=='affine_free_diagnostic' else cost))
            libraries[label]=reps
        for case in src['results']:
            selected=[]
            for row in raw:
                scales=row['scales']
                crossing=[v for v in scales if abs(v['T'])>src['source']['lam']]
                if not crossing: continue
                v=crossing[0] if case['selector']=='first_crossing' else max(scales,key=lambda w:abs(w['T']))
                boundary=src['source']['B']*src['source']['lam']
                flag=v['F']<=boundary if case['branch']=='low' else boundary<v['F']<=2*boundary
                G=v['C'] if case['branch']=='low' else v['F']
                if not flag or G<=0:continue
                u=v['uJ'] if case['branch']=='low' else v['uK']
                p=[z/G for z in u]
                assert abs(sum(p)-1)<1e-12
                x=tuple(map(F,row['x']));L=F(v['L'])
                intervals=[(xx-L/2,xx+L/2) for xx in x]
                weight=G/src['source']['lam']*float(F(row['volume']))/len(raw)
                selected.append((p,L,intervals,weight))
            assert len(selected)==case['training_band_receivers']
            occupation=sum(row[3] for row in selected)
            assert abs(occupation-case['training_occupation_approx'])<=1e-12*max(1.,occupation)
            # Direct subset sums; intentionally independent of production's DP.
            values={m:[w*min(1.,sum(p[i] for i in range(N) if m>>i&1))**case['q'] for p,L,intervals,w in selected] for m in masks}
            for label,rec in case['comparisons'].items():
                coeff={int(m):F(v) for m,v in rec['coefficients'].items()}
                lp=rec['LP'];alpha={int(m):F(v) for m,v in lp['primal'].items()};dual=list(map(F,lp['dual']))
                assert set(coeff)==set(masks) and len(dual)==N
                assert all(v>=0 for v in alpha.values()) and all(v>=0 for v in dual)
                loads=[sum(v for m,v in alpha.items() if m>>i&1) for i in range(N)]
                assert all(v<=1 for v in loads) and loads==list(map(F,lp['loads']))
                for m in masks:
                    assert sum(dual[i] for i in range(N) if m>>i&1)>=coeff[m]
                    counts['exact_dual_inequalities']+=1
                value=sum(coeff[m]*v for m,v in alpha.items())
                assert value==F(lp['value'])==sum(dual)
                assert F(lp['rational_coefficient_rounding_objective_error_bound'])==F(N,grid)
                counts['LP_witnesses']+=1
                reps=libraries[label]
                patterns={}
                # Exact rational gate comparisons, with one center per scale.
                center_cache={}
                rep_gates=[]
                for rid,(a,b,cost) in enumerate(reps):
                    ix=[]
                    for j,(p,L,intervals,w) in enumerate(selected):
                        key=(rid,L)
                        center=center_cache.get(key)
                        if center is None:
                            center=tuple(a[i]+L*b[i] for i in range(len(a)));center_cache[key]=center
                        if all(lo<=c<=hi for c,(lo,hi) in zip(center,intervals)):ix.append(j)
                    ix=tuple(ix);rep_gates.append(ix)
                    if ix not in patterns or cost<patterns[ix]:patterns[ix]=cost
                assert len(patterns)==rec['gate_patterns']
                for m in masks:
                    best=max((sum(values[m][j] for j in ix)/float(cost) for ix,cost in patterns.items()),default=0.)
                    if m&(m-1)==0:best=max(best,sum(values[m]))
                    saved=float(coeff[m])
                    discrepancy=abs(best-saved)
                    max_float_difference=max(max_float_difference,discrepancy)
                    # Only floor of the already floating functional is claimed;
                    # different legal floating subset-sum orders can differ by ulps.
                    assert -2e-13*max(1,best)<=best-saved<=1/grid+2e-13*max(1,best),(label,m,best,saved)
                    rid=rec['chosen_representative'][str(m)]
                    if rid==-2:
                        assert m&(m-1)==0
                        chosen=sum(values[m])
                    elif rid<0:chosen=0.
                    else:chosen=sum(values[m][j] for j in rep_gates[rid])/float(reps[rid][2])
                    assert abs(chosen-best)<=2e-12*max(1,best)
                    counts['direct_coefficient_checks']+=1
                for j,(p,L,intervals,w) in enumerate(selected):
                    score=0.
                    for m,v in alpha.items():
                        rid=rec['chosen_representative'][str(m)]
                        if rid==-2 or rid>=0 and j in rep_gates[rid]:
                            cost=1. if rid==-2 else float(reps[rid][2])
                            score+=float(v)*min(1.,sum(p[i] for i in range(N) if m>>i&1))**case['q']/cost
                    assert -1e-12<=score<=1+1e-10
                    counts['common_training_score_checks']+=1
            vals=[F(case['comparisons'][label]['LP']['value']) for label in ('fixed','affine_paid','affine_free_diagnostic')]
            assert vals==sorted(vals)
    assert counts['LP_witnesses']==data['pressure_counts']['LP_certificates']
    assert counts['training_rows']==data['pressure_counts']['training_draws']
    counts['maximum_float_reconstruction_difference']=max_float_difference
    counts['scope']='Exact archived LP witnesses and gates; floating functional reconstruction is diagnostic, not interval integration.'
    return counts

if __name__=="__main__": main()
```
