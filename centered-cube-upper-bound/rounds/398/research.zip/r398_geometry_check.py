from fractions import Fraction as F
Q=[set(range(8)),set(range(6)),set(range(2,8))]
Q += [set(range(i,i+2)) for i in range(7)]
checks=0
for k in range(1,8):
    f=[F(1+(k*i)%3) for i in range(8)]
    m=[sum(f[z] for z in q) for q in Q]
    mu=[F(i+1,20)/m[i] for i in range(len(Q))]
    for u in range(3):
        for v in range(3,len(Q)):
            if not m[u]>2*m[v]: continue
            for z in range(8):
                Tv=sum(mu[w] for w in range(len(Q))
                       if m[w]<=m[v] and z in Q[w])
                Zu=sum(mu[w] for w in range(len(Q))
                       if m[w]<m[u]/2 and z in Q[w])
                assert Tv<=Zu
                assert not (z in Q[v] and z in Q[u]-Q[v])
                checks+=1
print('PASS rank_inclusion_and_disjoint_support',checks)
