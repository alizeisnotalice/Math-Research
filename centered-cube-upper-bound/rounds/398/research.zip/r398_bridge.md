# R398 — one cumulative low-rank receipt for the density-switching cost

**Result.** The common-overlap portion of the original switching cost is at most G0/K. Its cumulative large-end external low-rank and small-end low-rank portions have the single source price

C_L W,  C_L=λh[β(L+ε0)+C_col L].                           (1)

There is no additional logarithm, no factor counting density stages, and no new X_q fee. This pays components of the original switching bill B. It is not automatically a paid positive subflow of the original γ cost. Two explicit high-rank components remain unpaid.

## 1. Freeze the original measures and stage marks

Use the original R390–R391 field and its core γ0, G0=γ0(E²), with all original source/time/history and fractional marks. Put

m_u=f(Q_u)=q_uR_u^n, q_-≤q_u≤λ, μ(du)=du/m_u,
σ(du)=q_u du, π_u(dz)=f(z)c_u(z)dz/m_u,
K=exp(√n), m_u>K m_v on γ0,
γ0,out≤βσ, γ0,in≤C_col σ.

Every stage is the actual nested restriction γ_i=1_{A_i²}γ0 from R397. All f, m, q, π, selected cubes, original ranks and clock fields stay frozen. Write D_i for its two-endpoint occupancy. For increasing density thresholds T_i,

b_i(z)=[min(f(z),T_i)−min(f(z),T_{i−1})]/f(z)
                       ·(1−s/D_i(z))_+, i≥1,              (2)

with zero values when f=0 or D_i=0. Crucially,

0≤b_i,  Σ_i b_i(z)≤1                                      (3)

by positive telescoping of the numerator, even though D_i varies. The exact original switching bill is

B=Σ_i∫γ_i(du,dv)[π_u(b_i)+π_v(b_i)].                       (4)

For every finite sum the arguments below are ordinary positive integrals; monotone convergence then proves the infinite-stage statements. The additional witness z in (4) does not replace the original transported source.

## 2. Native closed-window and inclusive-rank capacities

For a fixed source z define ρ_z(dw)=c_w(z)μ(dw), and keep the original inclusive mass rank

T_w(z)=ρ_z{m≤m_w},
Z_u(z)=ρ_z{m<m_u/K}.

The actual center geometry gives, for every 0<L0≤U0,

ρ_z{L0≤m≤U0}≤[1+log(U0/L0)]/q_-.                         (5)

Indeed capture implies m_w≥q_-(2||w−z||∞)^n. On that mass window the density 1/m_w is at most 1/max(L0,q_-(2||w−z||∞)^n), supported where q_-(2||w−z||∞)^n≤U0. Integrating this envelope in real dw gives (5). It includes both endpoints and mass atoms and uses no source-density bound. For L0=m_u/K,U0=m_u,

T_u(z)≤Z_u(z)+B_K,
B_K=(1+log K)/q_-=(1+√n)/q_-=ε0 h.                        (6)

The last equality uses the original synchronized h=(1+√n)/(ε0q_-). The strict-left Z and closed mass window partition the original inclusive prefix exactly.

For any finite mass distribution ρ and its inclusive CDF T(m),

∫1_{T(m)≤a}ρ(dm)≤a, a≥0.                                 (7)

One proof spreads each mass atom over its complete rank interval (T(m−),T(m)]. Every point of an included interval lies below its endpoint T(m)≤a. Non-atomic ranks obey the same inclusion. Thus their total rank length is at most a. A crossing atom is excluded in full, not charged without its overshoot. The assertion at a=0 gives zero mass. Equivalently the set of included mass levels is an initial segment whose total mass cannot exceed a.

Positive Tonelli, original full-f matching, and q_u≤λ now give the native source-price identity and bound

∫σ(du)π_u{z:T_u(z)≤a}
 =∫f(z)∫q_uc_u(z)1_{T_u(z)≤a}μ(du)dz
 ≤λ a W.                                                 (8)

Unlike the logarithmic full witness h/(h+T), the indicator of a closed rank sublevel has price linear in a. No first-crossing additive constant is needed in (7).

## 3. Exact five-part split of the switching bill

Fix L≥0. Split (4) as the following nonnegative exact sum:

B=B_cap+P_ext,low+H_ext+P_small,low+H_small,                 (9)

where each symbol denotes the sum over i against the SAME γ_i, and its source integrand is respectively

B_cap:       π_u(b_i c_v),
P_ext,low:   π_u(b_i(1−c_v)1_{Z_u≤Lh}),
H_ext:       π_u(b_i(1−c_v)1_{Z_u>Lh}),
P_small,low: π_v(b_i1_{T_v≤Lh}),
H_small:     π_v(b_i1_{T_v>Lh}).                            (10)

These are existing endpoint/source costs of the original B. No auxiliary flow is substituted.

For the common overlap, the strict far-mass gate gives pointwise on each edge

π_u(b_i c_v)=(m_v/m_u)π_v(b_i c_u)≤K^−1π_v(b_i).

By nestedness and (3),

B_cap≤K^−1 B_small≤K^−1G0,
B_small=P_small,low+H_small.                               (11)

The stronger first inequality is retained if useful; the last bound uses
Σ_i1_{A_i²}(u,v)π_v(b_i)≤π_v(Σ_i b_i)≤1.

For the external low-rank part, dropping only positive restrictions and summing the source marks FIRST gives

P_ext,low≤∫γ0(du,dv)π_u{Z_u≤Lh}
 ≤β∫σ(du)π_u{T_u≤(L+ε0)h}
 ≤βλ(L+ε0)h W.                                           (12)

The source event in the middle line follows from (6). It is not inherited from the old transported source. Similarly the actual incoming-column bound gives

P_small,low≤∫γ0(du,dv)π_v{T_v≤Lh}
 ≤C_col λ Lh W.                                          (13)

Together,

B≤K^−1G0+C_L W+H_ext+H_small.                              (14)

All zero-external-rank switching costs are included even at L=0, with price βλε0hW. The small-end zero-rank contribution is zero by (7). For any fixed L>0, both retained terms in (10) have genuine high rank on the additional witness source. This does not confer any other original history, spatial or outgoing-row qualification on that source or on another receiver.

## 4. What the external lift now represents, and what is still unpaid

If the original external witness is used, define its frozen normalization

E_uv=π_u[(1−c_v)Z_u],
dν_uv^z=(1−c_v)Z_u dπ_u/E_uv.

On the original core its established positive normalization applies; zero normalizations otherwise contribute nothing to H_ext. For L>0 the precise remaining identity is

H_ext=Σ_i∫γ_i(du,dv) E_uv∫ [b_i(z)/Z_u(z)]
                           1_{Z_u>Lh} dν_uv^z(z).         (15)

The zero-rank term from the advice's equation (18) has now been paid in (12). However the factor E_uv/Z_u remains in (15). A lower bound on E_uv does not make that factor one or bound the total high-rank bill. Neither H_ext nor H_small has been given a root price here.

Historically, (5),(7),(8) are existing actual-center/rank-capacity tools, and the row/column bounds are R390. R388 paid an outgoing original witness branch, and R390 paid an incoming one. The new application here is (12)–(14) for the distinct cumulative R397 switching measure: sourcewise Σb_i≤1 and nested γ_i permit one price across ALL stages. It is an additional explicitly priced fee for this bill, not reuse of an earlier charge for free. The stronger closed-CDF receipt avoids the unnecessary logarithm that would arise from using h/(h+T) again.

## 5. Honest core and entrance accounting

R397 gives, with its fixed θ=1/4,ρ=1/2,s=1+√n,

G0/8≤sW+B.

For n≥9, K=e^√n≥e³>16 (e>8/3 suffices), so (14) yields

(1/8−1/K)G0≤(s+C_L)W+H_ext+H_small,
G0≤16[(s+C_L)W+H_ext+H_small].                             (16)

This is a residual bound; it is not a direct receipt for a positive subflow of γ0. The two high-rank terms still require a separate budget. The exact coefficient 1/(1/8−1/K) can be retained instead of 16.

For the full low-dimensional complement n≤8, the actual center bound and ∫fD0=2G0 directly give

G0≤S(1+8log2)W/2.                                         (17)

No dimension range is discarded and no density-cascade factor is needed for (17).

The R392 BH ledger contains 2G0. Substitution of (16) therefore gives 32(H_ext+H_small)+32(s+C_L)W in that slot. At the original entrance multiplier 4Λ on G0, the corresponding terms are 64Λ(H_ext+H_small)+64Λ(s+C_L)W; all old terms remain unchanged. There is no new X_q coefficient. With the synchronized h,

C_L=(λ/q_-)(1+√n)[β(1+L/ε0)+C_col L/ε0].                  (18)

Thus a fixed L costs root dimension times the already frozen ε0^−1 and rank-window constants, without an additional logarithm. The result closes the zero/low-rank gap in the cumulative bridge, not the general core bound.

## 6. Local verification

`/tmp/r398_exactcheck.py` is a three-stage standard-library Fraction check. The first stage verifies the nested marked switching split and its cumulative row/column prices on finite matched incidence models. The second stresses inclusive CDF atoms, threshold equalities and zero rank. The third expands atom counts and threshold ranges. Finite incidence is an algebraic diagnostic, not a native real-du realization of all original history and synchronized high-rank gates. The native geometric bound is proved in (5), not inferred from a sampled model.

Actual local run:

`PASS {'marked_nested': 432, 'atomic_boundary': 384, 'expanded_atoms': 2187} total 3003`

All arithmetic is exact Fraction. The marked tests use rational strict gap K=2 and compute their own finite closed-window capacity to stress the implication T_u≤Z_u+B_window. They do not claim to realize the original K=exp(√n), synchronized ε0,h or real-cube history. They include genuinely positive external and small-end costs and exact nested endpoint restrictions. The native no-log receipt follows analytically from (5)–(8); these finite checks audit its algebra and boundary conventions only. No further exploration is undertaken.
