# R398 — Screening the high-small versus high-external bridge

**Outcome: no new source price.** Keep the actual decreasing restrictions γ_i≤γ_0, their actual D_i, and the PDF page-7 marks b_i. Thus b_i≥0 and ∑_i b_i(z)≤1. None of f,m,q,π,J,T,Z, the original clock or history marks is rebuilt. This note does not repeat the parent's one-time low-rank witness receipts.

The candidate screened was a genuinely coupled comparison, with constants A and C independent of n,f and a sufficiently small relative η:

 H_small ≤ ηG_0 + A H_ext + C sqrt(n)log^k(n+2)W,          (1)

where, for the same fixed L and stages,

 H_small=∑_i∫γ_i(du,dv)π_v[b_i 1_{T_v>Lh}],
 H_ext=∑_i∫γ_i(du,dv)π_u[b_i(1−c_v)1_{Z_u>Lh}].          (2)

These are the actual two retained endpoint costs, not masses of unmarked new receivers. Even (1), if proved with A>0, would still need a price for H_ext. No proof of (1) was obtained; it is not entered as an estimate.

## Exact screening of what the geometry presently supplies

For every actual strict-far pair m_u>K m_v and every source z,

                         T_v(z)≤Z_u(z).                 (3)

Indeed m_w≤m_v implies m_w<m_u/K. The left CDF is closed and the right cutoff is strict; strict far makes this inclusion valid even at mass atoms. Consequently every source in the high-small term has high Z_u as well. There is no missing rank-threshold implication here.

There is instead a source-support and weight problem. The small posterior is supported on Q_v. The R390 external source marginal is

 ν_uv^z(dz)=1_{Q_v^c} Z_u(z)π_u(dz)/E_uv.

These supports are disjoint. Thus (3) does not let one transfer π_v[b_i 1_{T_v>Lh}] into that external marginal at the same source z. Some small-posterior sources may also lie outside Q_u. None is counted by the external marginal while it lies in Q_v.

On the shared part the exact direction of the mass factor is

 π_u(b_i c_v)=(m_v/m_u)π_v(b_i c_u)
             ≤K^(-1)π_v(b_i).                           (4)

This correctly makes the **big-end shared cost** cheap. Reversing (4) to pay a small-end cost introduces m_u/m_v>K and is not an available saving.

For comparison, the actual high-external cost does have the exact reweighting

 π_u[b_i(1−c_v)1_{Z_u>Lh}]
   =E_uv ∫ [b_i/Z_u]1_{Z_u>Lh} dν_uv^z.                 (5)

There is no zero-rank term in (5). The lower bound E_uv>9h/49 does not upper-bound E_uv/Z_u. Neither the normalization nor (3) changes that fact.

Full matching guarantees f(Q_u\Q_v)≥m_u−m_v. It supplies no lower bound for the **b_i-weighted** mass of that set. Sending small-end source mass there would require a jointly controlled, cross-source transport preserving or pricing the b_i marks over all stages and all old edges. The inequality ∑b_i≤1 is a budget at each fixed source point, not a coupling between different source points. The actual dependence b_i=[min(f,T_i)−min(f,T_{i−1})]/f ·(1−s/D_i)_+ must therefore be used in any such proof; replacing it by an arbitrary unmarked external source law loses the quantity being paid.

This is the precise unproved bridge for (1). It is not a claim that such a comparison is impossible. No new w is assigned history, no old square is reused, and no statement about a source density from boundary volume is made. The original high-small and high-external costs remain in full.

## Local check and accounting

Executed the following exact Fraction diagnostic locally; output was `PASS rank_inclusion_and_disjoint_support 1176`.

```python
from fractions import Fraction as F
Q=[set(range(8)),set(range(6)),set(range(2,8))]
Q += [set(range(i,i+2)) for i in range(7)]
checks=0
for k in range(1,8):
    f=[F(1+(k*i)%3) for i in range(8)]
    m=[sum(f[z] for z in q) for q in Q]
    mu=[F(i+1,20)/m[i] for i in range(len(Q))]
    for u in range(3):
        for v in range(3,len(Q)):
            if not m[u]>2*m[v]: continue
            for z in range(8):
                Tv=sum(mu[w] for w in range(len(Q))
                       if m[w]<=m[v] and z in Q[w])
                Zu=sum(mu[w] for w in range(len(Q))
                       if m[w]<m[u]/2 and z in Q[w])
                assert Tv<=Zu
                assert not (z in Q[v] and z in Q[u]-Q[v])
                checks+=1
print('PASS rank_inclusion_and_disjoint_support',checks)
```

These checks use exact interval incidences, full source-cell masses and receiver quadrature with rational K=2. They check only (3) and the support statement, not the original exponential far gate, actual Lebesgue receiver integration, stage deletion/core history, or (1). Equations (3)–(5) have the direct analytic proofs above; the test is not evidence for a new budget.

No fee or absorption is added by this note. The parent's newly established low-rank/shared receipts retain their own exact coefficients and complements; this screening neither strengthens them nor counts them again. In particular, (1) remains unproved and is not substituted into the clearing inequality. Work stops at the specific cross-source, stage-mark-preserving comparison above.
